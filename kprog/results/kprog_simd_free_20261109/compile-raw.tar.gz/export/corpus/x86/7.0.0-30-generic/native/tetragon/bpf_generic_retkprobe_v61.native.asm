
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_retkprobe_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	pushq	%rax
       1:      	movl	0x4(%rdi), %ecx
       4:      	xorl	%eax, %eax
       6:      	cmpq	$0x20, %rcx
       a:      	ja	0x45 <filter_64ty+0x45>
       c:      	movl	$0x101e, %edx           # imm = 0x101E
      11:      	btq	%rcx, %rdx
      15:      	jae	0x1e <filter_64ty+0x1e>
      17:      	callq	0x140 <filter_64ty_selector_val>
      1c:      	popq	%rcx
      1d:      	retq
      1e:      	movl	$0xc00, %edx            # imm = 0xC00
      23:      	btq	%rcx, %rdx
      27:      	jb	0x40 <filter_64ty+0x40>
      29:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      33:      	btq	%rcx, %rdx
      37:      	jae	0x45 <filter_64ty+0x45>
      39:      	callq	0x400 <filter_64ty_range>
      3e:      	popq	%rcx
      3f:      	retq
      40:      	callq	0x380 <filter_64ty_map>
      45:      	popq	%rcx
      46:      	retq
      47:      	nopw	(%rax,%rax)

0000000000000050 <filter_32ty>:
      50:      	pushq	%rax
      51:      	movl	0x4(%rdi), %ecx
      54:      	xorl	%eax, %eax
      56:      	cmpq	$0x20, %rcx
      5a:      	ja	0x95 <filter_32ty+0x45>
      5c:      	movl	$0x101e, %edx           # imm = 0x101E
      61:      	btq	%rcx, %rdx
      65:      	jae	0x6e <filter_32ty+0x1e>
      67:      	callq	0x5e0 <filter_32ty_selector_val>
      6c:      	popq	%rcx
      6d:      	retq
      6e:      	movl	$0xc00, %edx            # imm = 0xC00
      73:      	btq	%rcx, %rdx
      77:      	jb	0x90 <filter_32ty+0x40>
      79:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      83:      	btq	%rcx, %rdx
      87:      	jae	0x95 <filter_32ty+0x45>
      89:      	callq	0x890 <filter_32ty_range>
      8e:      	popq	%rcx
      8f:      	retq
      90:      	callq	0x800 <filter_32ty_map>
      95:      	popq	%rcx
      96:      	retq
      97:      	nopw	(%rax,%rax)

00000000000000a0 <filter_16ty>:
      a0:      	pushq	%rax
      a1:      	movl	0x4(%rdi), %ecx
      a4:      	xorl	%eax, %eax
      a6:      	cmpq	$0x20, %rcx
      aa:      	ja	0xe5 <filter_16ty+0x45>
      ac:      	movl	$0x101e, %edx           # imm = 0x101E
      b1:      	btq	%rcx, %rdx
      b5:      	jae	0xbe <filter_16ty+0x1e>
      b7:      	callq	0xa50 <filter_16ty_selector_val>
      bc:      	popq	%rcx
      bd:      	retq
      be:      	movl	$0xc00, %edx            # imm = 0xC00
      c3:      	btq	%rcx, %rdx
      c7:      	jb	0xe0 <filter_16ty+0x40>
      c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      d3:      	btq	%rcx, %rdx
      d7:      	jae	0xe5 <filter_16ty+0x45>
      d9:      	callq	0xd00 <filter_16ty_range>
      de:      	popq	%rcx
      df:      	retq
      e0:      	callq	0xc70 <filter_16ty_map>
      e5:      	popq	%rcx
      e6:      	retq
      e7:      	nopw	(%rax,%rax)

00000000000000f0 <filter_8ty>:
      f0:      	pushq	%rax
      f1:      	movl	0x4(%rdi), %ecx
      f4:      	xorl	%eax, %eax
      f6:      	cmpq	$0x20, %rcx
      fa:      	ja	0x135 <filter_8ty+0x45>
      fc:      	movl	$0x101e, %edx           # imm = 0x101E
     101:      	btq	%rcx, %rdx
     105:      	jae	0x10e <filter_8ty+0x1e>
     107:      	callq	0xec0 <filter_8ty_selector_val>
     10c:      	popq	%rcx
     10d:      	retq
     10e:      	movl	$0xc00, %edx            # imm = 0xC00
     113:      	btq	%rcx, %rdx
     117:      	jb	0x130 <filter_8ty+0x40>
     119:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     123:      	btq	%rcx, %rdx
     127:      	jae	0x135 <filter_8ty+0x45>
     129:      	callq	0x1170 <filter_8ty_range>
     12e:      	popq	%rcx
     12f:      	retq
     130:      	callq	0x10e0 <filter_8ty_map>
     135:      	popq	%rcx
     136:      	retq
     137:      	nopw	(%rax,%rax)

0000000000000140 <filter_64ty_selector_val>:
     140:      	movl	0x4(%rdi), %ecx
     143:      	movl	$0x1, %eax
     148:      	cmpq	$0x25, %rcx
     14c:      	ja	0x1c4 <filter_64ty_selector_val+0x84>
     14e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     158:      	btq	%rcx, %rdx
     15c:      	jae	0x15f <filter_64ty_selector_val+0x1f>
     15e:      	retq
     15f:      	movl	$0x18, %edx
     164:      	btq	%rcx, %rdx
     168:      	jae	0x180 <filter_64ty_selector_val+0x40>
     16a:      	movq	(%rsi), %rdx
     16d:      	cmpq	0x10(%rdi), %rdx
     171:      	jne	0x2a2 <filter_64ty_selector_val+0x162>
     177:      	xorl	%eax, %eax
     179:      	cmpl	$0x3, %ecx
     17c:      	sete	%al
     17f:      	retq
     180:      	cmpq	$0xc, %rcx
     184:      	jne	0x1c4 <filter_64ty_selector_val+0x84>
     186:      	movq	(%rsi), %rcx
     189:      	testq	%rcx, 0x10(%rdi)
     18d:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     18f:      	movl	0x8(%rdi), %edx
     192:      	cmpl	$0x11, %edx
     195:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     19b:      	testq	%rcx, 0x18(%rdi)
     19f:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1a1:      	cmpl	$0x19, %edx
     1a4:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1aa:      	testq	%rcx, 0x20(%rdi)
     1ae:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1b0:      	cmpl	$0x21, %edx
     1b3:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1b9:      	testq	%rcx, 0x28(%rdi)
     1bd:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1bf:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     1c4:      	cmpl	$0x1, %ecx
     1c7:      	je	0x23a <filter_64ty_selector_val+0xfa>
     1c9:      	cmpl	$0x2, %ecx
     1cc:      	jne	0x36f <filter_64ty_selector_val+0x22f>
     1d2:      	movl	0xc(%rdi), %ecx
     1d5:      	cmpl	$0xc, %ecx
     1d8:      	ja	0x332 <filter_64ty_selector_val+0x1f2>
     1de:      	movl	$0x1402, %edx           # imm = 0x1402
     1e3:      	btl	%ecx, %edx
     1e6:      	jae	0x332 <filter_64ty_selector_val+0x1f2>
     1ec:      	movq	(%rsi), %rcx
     1ef:      	cmpq	0x10(%rdi), %rcx
     1f3:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     1f9:      	movl	0x8(%rdi), %edx
     1fc:      	cmpl	$0x11, %edx
     1ff:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     205:      	cmpq	0x18(%rdi), %rcx
     209:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     20f:      	cmpl	$0x19, %edx
     212:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     218:      	cmpq	0x20(%rdi), %rcx
     21c:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     222:      	cmpl	$0x21, %edx
     225:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     22b:      	cmpq	0x28(%rdi), %rcx
     22f:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     235:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     23a:      	movl	0xc(%rdi), %ecx
     23d:      	cmpl	$0xc, %ecx
     240:      	ja	0x2f3 <filter_64ty_selector_val+0x1b3>
     246:      	movl	$0x1402, %edx           # imm = 0x1402
     24b:      	btl	%ecx, %edx
     24e:      	jae	0x2f3 <filter_64ty_selector_val+0x1b3>
     254:      	movq	(%rsi), %rcx
     257:      	cmpq	0x10(%rdi), %rcx
     25b:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     261:      	movl	0x8(%rdi), %edx
     264:      	cmpl	$0x11, %edx
     267:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     26d:      	cmpq	0x18(%rdi), %rcx
     271:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     277:      	cmpl	$0x19, %edx
     27a:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     280:      	cmpq	0x20(%rdi), %rcx
     284:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     28a:      	cmpl	$0x21, %edx
     28d:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     293:      	cmpq	0x28(%rdi), %rcx
     297:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     29d:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2a2:      	movl	0x8(%rdi), %esi
     2a5:      	cmpl	$0x11, %esi
     2a8:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2aa:      	cmpq	0x18(%rdi), %rdx
     2ae:      	je	0x177 <filter_64ty_selector_val+0x37>
     2b4:      	cmpl	$0x19, %esi
     2b7:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2b9:      	cmpq	0x20(%rdi), %rdx
     2bd:      	je	0x177 <filter_64ty_selector_val+0x37>
     2c3:      	cmpl	$0x21, %esi
     2c6:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2c8:      	cmpq	0x28(%rdi), %rdx
     2cc:      	je	0x177 <filter_64ty_selector_val+0x37>
     2d2:      	cmpl	$0x25, %ecx
     2d5:      	ja	0x36f <filter_64ty_selector_val+0x22f>
     2db:      	movl	%ecx, %ecx
     2dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     2e7:      	btq	%rcx, %rdx
     2eb:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     2f1:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2f3:      	movq	(%rsi), %rcx
     2f6:      	cmpq	0x10(%rdi), %rcx
     2fa:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     300:      	movl	0x8(%rdi), %edx
     303:      	cmpl	$0x11, %edx
     306:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     308:      	cmpq	0x18(%rdi), %rcx
     30c:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     312:      	cmpl	$0x19, %edx
     315:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     317:      	cmpq	0x20(%rdi), %rcx
     31b:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     321:      	cmpl	$0x21, %edx
     324:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     326:      	cmpq	0x28(%rdi), %rcx
     32a:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     330:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     332:      	movq	(%rsi), %rcx
     335:      	cmpq	0x10(%rdi), %rcx
     339:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     33f:      	movl	0x8(%rdi), %edx
     342:      	cmpl	$0x11, %edx
     345:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     347:      	cmpq	0x18(%rdi), %rcx
     34b:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     351:      	cmpl	$0x19, %edx
     354:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     356:      	cmpq	0x20(%rdi), %rcx
     35a:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     360:      	cmpl	$0x21, %edx
     363:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     365:      	cmpq	0x28(%rdi), %rcx
     369:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     36f:      	xorl	%eax, %eax
     371:      	retq
     372:      	nopw	%cs:(%rax,%rax)

0000000000000380 <filter_64ty_map>:
     380:      	pushq	%r14
     382:      	pushq	%rbx
     383:      	subq	$0x18, %rsp
     387:      	movq	%rsi, %r14
     38a:      	movq	%rdi, %rbx
     38d:      	movzbl	0x10(%rdi), %eax
     391:      	movl	%eax, 0xc(%rsp)
     395:      	movq	(%rip), %rdi            # 0x39c <filter_64ty_map+0x1c>
     39c:      	leaq	0xc(%rsp), %rsi
     3a1:      	movl	$0x1, %eax
     3a6:      	callq	*%rax
     3a8:      	testq	%rax, %rax
     3ab:      	je	0x3d9 <filter_64ty_map+0x59>
     3ad:      	movq	%rax, %rdi
     3b0:      	movq	(%r14), %rax
     3b3:      	movq	%rax, 0x10(%rsp)
     3b8:      	leaq	0x10(%rsp), %rsi
     3bd:      	movl	$0x1, %eax
     3c2:      	callq	*%rax
     3c4:      	movl	0x4(%rbx), %ecx
     3c7:      	cmpl	$0xb, %ecx
     3ca:      	je	0x3e3 <filter_64ty_map+0x63>
     3cc:      	cmpl	$0xa, %ecx
     3cf:      	jne	0x3eb <filter_64ty_map+0x6b>
     3d1:      	testq	%rax, %rax
     3d4:      	setne	%al
     3d7:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3d9:      	xorl	%eax, %eax
     3db:      	addq	$0x18, %rsp
     3df:      	popq	%rbx
     3e0:      	popq	%r14
     3e2:      	retq
     3e3:      	testq	%rax, %rax
     3e6:      	sete	%al
     3e9:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3eb:      	xorl	%eax, %eax
     3ed:      	movzbl	%al, %eax
     3f0:      	addq	$0x18, %rsp
     3f4:      	popq	%rbx
     3f5:      	popq	%r14
     3f7:      	retq
     3f8:      	nopl	(%rax,%rax)

0000000000000400 <filter_64ty_range>:
     400:      	movl	0x4(%rdi), %ecx
     403:      	movl	0xc(%rdi), %eax
     406:      	cmpl	$0xc, %eax
     409:      	ja	0x500 <filter_64ty_range+0x100>
     40f:      	movl	$0x1402, %edx           # imm = 0x1402
     414:      	btl	%eax, %edx
     417:      	jae	0x500 <filter_64ty_range+0x100>
     41d:      	movq	(%rsi), %rsi
     420:      	cmpl	$0x1f, %ecx
     423:      	jne	0x493 <filter_64ty_range+0x93>
     425:      	movl	$0x1, %eax
     42a:      	cmpq	%rsi, 0x10(%rdi)
     42e:      	jg	0x43a <filter_64ty_range+0x3a>
     430:      	cmpq	0x18(%rdi), %rsi
     434:      	jle	0x519 <filter_64ty_range+0x119>
     43a:      	movl	0x8(%rdi), %edx
     43d:      	cmpl	$0x19, %edx
     440:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     446:      	cmpq	%rsi, 0x20(%rdi)
     44a:      	jg	0x456 <filter_64ty_range+0x56>
     44c:      	cmpq	0x28(%rdi), %rsi
     450:      	jle	0x519 <filter_64ty_range+0x119>
     456:      	cmpl	$0x29, %edx
     459:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     45f:      	cmpq	%rsi, 0x30(%rdi)
     463:      	jg	0x46f <filter_64ty_range+0x6f>
     465:      	cmpq	0x38(%rdi), %rsi
     469:      	jle	0x519 <filter_64ty_range+0x119>
     46f:      	cmpl	$0x39, %edx
     472:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     478:      	xorl	%edx, %edx
     47a:      	cmpq	%rsi, 0x40(%rdi)
     47e:      	jg	0x5c9 <filter_64ty_range+0x1c9>
     484:      	cmpq	0x48(%rdi), %rsi
     488:      	jle	0x519 <filter_64ty_range+0x119>
     48e:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     493:      	movl	0x8(%rdi), %eax
     496:      	cmpq	%rsi, 0x10(%rdi)
     49a:      	setle	%r8b
     49e:      	cmpq	0x18(%rdi), %rsi
     4a2:      	setle	%dl
     4a5:      	andb	%r8b, %dl
     4a8:      	cmpl	$0x19, %eax
     4ab:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4b1:      	cmpq	%rsi, 0x20(%rdi)
     4b5:      	setle	%r8b
     4b9:      	cmpq	0x28(%rdi), %rsi
     4bd:      	setle	%r9b
     4c1:      	andb	%r8b, %r9b
     4c4:      	orb	%r9b, %dl
     4c7:      	cmpl	$0x29, %eax
     4ca:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4d0:      	cmpq	%rsi, 0x30(%rdi)
     4d4:      	setle	%r8b
     4d8:      	cmpq	0x38(%rdi), %rsi
     4dc:      	setle	%r9b
     4e0:      	andb	%r8b, %r9b
     4e3:      	orb	%r9b, %dl
     4e6:      	cmpl	$0x39, %eax
     4e9:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4ef:      	cmpq	%rsi, 0x40(%rdi)
     4f3:      	setle	%al
     4f6:      	cmpq	0x48(%rdi), %rsi
     4fa:      	setle	%sil
     4fe:      	jmp	0x57d <filter_64ty_range+0x17d>
     500:      	movq	(%rsi), %rsi
     503:      	cmpl	$0x1f, %ecx
     506:      	jne	0x51a <filter_64ty_range+0x11a>
     508:      	movl	$0x1, %eax
     50d:      	cmpq	%rsi, 0x10(%rdi)
     511:      	ja	0x585 <filter_64ty_range+0x185>
     513:      	cmpq	0x18(%rdi), %rsi
     517:      	ja	0x585 <filter_64ty_range+0x185>
     519:      	retq
     51a:      	movl	0x8(%rdi), %eax
     51d:      	cmpq	%rsi, 0x10(%rdi)
     521:      	setbe	%r8b
     525:      	cmpq	0x18(%rdi), %rsi
     529:      	setbe	%dl
     52c:      	andb	%r8b, %dl
     52f:      	cmpl	$0x19, %eax
     532:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     538:      	cmpq	%rsi, 0x20(%rdi)
     53c:      	setbe	%r8b
     540:      	cmpq	0x28(%rdi), %rsi
     544:      	setbe	%r9b
     548:      	andb	%r8b, %r9b
     54b:      	orb	%r9b, %dl
     54e:      	cmpl	$0x29, %eax
     551:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     553:      	cmpq	%rsi, 0x30(%rdi)
     557:      	setbe	%r8b
     55b:      	cmpq	0x38(%rdi), %rsi
     55f:      	setbe	%r9b
     563:      	andb	%r8b, %r9b
     566:      	orb	%r9b, %dl
     569:      	cmpl	$0x39, %eax
     56c:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     56e:      	cmpq	%rsi, 0x40(%rdi)
     572:      	setbe	%al
     575:      	cmpq	0x48(%rdi), %rsi
     579:      	setbe	%sil
     57d:      	andb	%al, %sil
     580:      	orb	%sil, %dl
     583:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     585:      	movl	0x8(%rdi), %edx
     588:      	cmpl	$0x19, %edx
     58b:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     58d:      	cmpq	%rsi, 0x20(%rdi)
     591:      	ja	0x599 <filter_64ty_range+0x199>
     593:      	cmpq	0x28(%rdi), %rsi
     597:      	jbe	0x519 <filter_64ty_range+0x119>
     599:      	cmpl	$0x29, %edx
     59c:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     59e:      	cmpq	%rsi, 0x30(%rdi)
     5a2:      	ja	0x5ae <filter_64ty_range+0x1ae>
     5a4:      	cmpq	0x38(%rdi), %rsi
     5a8:      	jbe	0x519 <filter_64ty_range+0x119>
     5ae:      	cmpl	$0x39, %edx
     5b1:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     5b3:      	xorl	%edx, %edx
     5b5:      	cmpq	%rsi, 0x40(%rdi)
     5b9:      	ja	0x5c9 <filter_64ty_range+0x1c9>
     5bb:      	cmpq	0x48(%rdi), %rsi
     5bf:      	jbe	0x519 <filter_64ty_range+0x119>
     5c5:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     5c7:      	xorl	%edx, %edx
     5c9:      	cmpl	$0x20, %ecx
     5cc:      	sete	%al
     5cf:      	xorb	$0x1, %dl
     5d2:      	andb	%al, %dl
     5d4:      	movzbl	%dl, %eax
     5d7:      	retq
     5d8:      	nopl	(%rax,%rax)

00000000000005e0 <filter_32ty_selector_val>:
     5e0:      	movl	0x4(%rdi), %ecx
     5e3:      	movl	$0x1, %eax
     5e8:      	cmpq	$0x25, %rcx
     5ec:      	ja	0x65d <filter_32ty_selector_val+0x7d>
     5ee:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     5f8:      	btq	%rcx, %rdx
     5fc:      	jae	0x5ff <filter_32ty_selector_val+0x1f>
     5fe:      	retq
     5ff:      	movl	$0x18, %edx
     604:      	btq	%rcx, %rdx
     608:      	jae	0x61e <filter_32ty_selector_val+0x3e>
     60a:      	movl	(%rsi), %edx
     60c:      	cmpl	0x10(%rdi), %edx
     60f:      	jne	0x731 <filter_32ty_selector_val+0x151>
     615:      	xorl	%eax, %eax
     617:      	cmpl	$0x3, %ecx
     61a:      	sete	%al
     61d:      	retq
     61e:      	cmpq	$0xc, %rcx
     622:      	jne	0x65d <filter_32ty_selector_val+0x7d>
     624:      	movl	(%rsi), %ecx
     626:      	testl	%ecx, 0x10(%rdi)
     629:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     62b:      	movl	0x8(%rdi), %edx
     62e:      	cmpl	$0xd, %edx
     631:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     637:      	testl	%ecx, 0x14(%rdi)
     63a:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     63c:      	cmpl	$0x11, %edx
     63f:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     645:      	testl	%ecx, 0x18(%rdi)
     648:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     64a:      	cmpl	$0x15, %edx
     64d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     653:      	testl	%ecx, 0x1c(%rdi)
     656:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     658:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     65d:      	cmpl	$0x1, %ecx
     660:      	je	0x6ce <filter_32ty_selector_val+0xee>
     662:      	cmpl	$0x2, %ecx
     665:      	jne	0x7f1 <filter_32ty_selector_val+0x211>
     66b:      	movl	0xc(%rdi), %ecx
     66e:      	cmpl	$0xc, %ecx
     671:      	ja	0x7b9 <filter_32ty_selector_val+0x1d9>
     677:      	movl	$0x1402, %edx           # imm = 0x1402
     67c:      	btl	%ecx, %edx
     67f:      	jae	0x7b9 <filter_32ty_selector_val+0x1d9>
     685:      	movl	(%rsi), %ecx
     687:      	cmpl	0x10(%rdi), %ecx
     68a:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     690:      	movl	0x8(%rdi), %edx
     693:      	cmpl	$0xd, %edx
     696:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     69c:      	cmpl	0x14(%rdi), %ecx
     69f:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6a5:      	cmpl	$0x11, %edx
     6a8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ae:      	cmpl	0x18(%rdi), %ecx
     6b1:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6b7:      	cmpl	$0x15, %edx
     6ba:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6c0:      	cmpl	0x1c(%rdi), %ecx
     6c3:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6c9:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     6ce:      	movl	0xc(%rdi), %ecx
     6d1:      	cmpl	$0xc, %ecx
     6d4:      	ja	0x77f <filter_32ty_selector_val+0x19f>
     6da:      	movl	$0x1402, %edx           # imm = 0x1402
     6df:      	btl	%ecx, %edx
     6e2:      	jae	0x77f <filter_32ty_selector_val+0x19f>
     6e8:      	movl	(%rsi), %ecx
     6ea:      	cmpl	0x10(%rdi), %ecx
     6ed:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     6f3:      	movl	0x8(%rdi), %edx
     6f6:      	cmpl	$0xd, %edx
     6f9:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ff:      	cmpl	0x14(%rdi), %ecx
     702:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     708:      	cmpl	$0x11, %edx
     70b:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     711:      	cmpl	0x18(%rdi), %ecx
     714:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     71a:      	cmpl	$0x15, %edx
     71d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     723:      	cmpl	0x1c(%rdi), %ecx
     726:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     72c:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     731:      	movl	0x8(%rdi), %esi
     734:      	cmpl	$0xd, %esi
     737:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     739:      	cmpl	0x14(%rdi), %edx
     73c:      	je	0x615 <filter_32ty_selector_val+0x35>
     742:      	cmpl	$0x11, %esi
     745:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     747:      	cmpl	0x18(%rdi), %edx
     74a:      	je	0x615 <filter_32ty_selector_val+0x35>
     750:      	cmpl	$0x15, %esi
     753:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     755:      	cmpl	0x1c(%rdi), %edx
     758:      	je	0x615 <filter_32ty_selector_val+0x35>
     75e:      	cmpl	$0x25, %ecx
     761:      	ja	0x7f1 <filter_32ty_selector_val+0x211>
     767:      	movl	%ecx, %ecx
     769:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     773:      	btq	%rcx, %rdx
     777:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     77d:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     77f:      	movl	(%rsi), %ecx
     781:      	cmpl	0x10(%rdi), %ecx
     784:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     78a:      	movl	0x8(%rdi), %edx
     78d:      	cmpl	$0xd, %edx
     790:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     792:      	cmpl	0x14(%rdi), %ecx
     795:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     79b:      	cmpl	$0x11, %edx
     79e:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7a0:      	cmpl	0x18(%rdi), %ecx
     7a3:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7a9:      	cmpl	$0x15, %edx
     7ac:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7ae:      	cmpl	0x1c(%rdi), %ecx
     7b1:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7b7:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     7b9:      	movl	(%rsi), %ecx
     7bb:      	cmpl	0x10(%rdi), %ecx
     7be:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7c4:      	movl	0x8(%rdi), %edx
     7c7:      	cmpl	$0xd, %edx
     7ca:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7cc:      	cmpl	0x14(%rdi), %ecx
     7cf:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7d5:      	cmpl	$0x11, %edx
     7d8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7da:      	cmpl	0x18(%rdi), %ecx
     7dd:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7e3:      	cmpl	$0x15, %edx
     7e6:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7e8:      	cmpl	0x1c(%rdi), %ecx
     7eb:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7f1:      	xorl	%eax, %eax
     7f3:      	retq
     7f4:      	nopw	%cs:(%rax,%rax)

0000000000000800 <filter_32ty_map>:
     800:      	pushq	%r14
     802:      	pushq	%rbx
     803:      	subq	$0x18, %rsp
     807:      	movq	%rsi, %r14
     80a:      	movq	%rdi, %rbx
     80d:      	movzbl	0x10(%rdi), %eax
     811:      	movl	%eax, 0xc(%rsp)
     815:      	movq	(%rip), %rdi            # 0x81c <filter_32ty_map+0x1c>
     81c:      	leaq	0xc(%rsp), %rsi
     821:      	movl	$0x1, %eax
     826:      	callq	*%rax
     828:      	testq	%rax, %rax
     82b:      	je	0x860 <filter_32ty_map+0x60>
     82d:      	movq	%rax, %rdi
     830:      	movl	(%r14), %eax
     833:      	movq	%rax, 0x10(%rsp)
     838:      	leaq	0x10(%rsp), %rsi
     83d:      	movl	$0x1, %eax
     842:      	callq	*%rax
     844:      	movl	0x4(%rbx), %edx
     847:      	xorl	%ecx, %ecx
     849:      	cmpl	$0x1d, %edx
     84c:      	ja	0x87a <filter_32ty_map+0x7a>
     84e:      	movl	$0x30038400, %esi       # imm = 0x30038400
     853:      	btl	%edx, %esi
     856:      	jae	0x86a <filter_32ty_map+0x6a>
     858:      	testq	%rax, %rax
     85b:      	setne	%cl
     85e:      	jmp	0x87a <filter_32ty_map+0x7a>
     860:      	xorl	%eax, %eax
     862:      	addq	$0x18, %rsp
     866:      	popq	%rbx
     867:      	popq	%r14
     869:      	retq
     86a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     86f:      	btl	%edx, %esi
     872:      	jae	0x87a <filter_32ty_map+0x7a>
     874:      	testq	%rax, %rax
     877:      	sete	%cl
     87a:      	movzbl	%cl, %eax
     87d:      	addq	$0x18, %rsp
     881:      	popq	%rbx
     882:      	popq	%r14
     884:      	retq
     885:      	nopw	%cs:(%rax,%rax)

0000000000000890 <filter_32ty_range>:
     890:      	movl	0x4(%rdi), %ecx
     893:      	movl	0xc(%rdi), %eax
     896:      	cmpl	$0xc, %eax
     899:      	ja	0x97f <filter_32ty_range+0xef>
     89f:      	movl	$0x1402, %edx           # imm = 0x1402
     8a4:      	btl	%eax, %edx
     8a7:      	jae	0x97f <filter_32ty_range+0xef>
     8ad:      	movl	(%rsi), %esi
     8af:      	cmpl	$0x1f, %ecx
     8b2:      	jne	0x91a <filter_32ty_range+0x8a>
     8b4:      	movl	$0x1, %eax
     8b9:      	cmpl	%esi, 0x10(%rdi)
     8bc:      	jg	0x8c7 <filter_32ty_range+0x37>
     8be:      	cmpl	0x14(%rdi), %esi
     8c1:      	jle	0x995 <filter_32ty_range+0x105>
     8c7:      	movl	0x8(%rdi), %edx
     8ca:      	cmpl	$0x11, %edx
     8cd:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8d3:      	cmpl	%esi, 0x18(%rdi)
     8d6:      	jg	0x8e1 <filter_32ty_range+0x51>
     8d8:      	cmpl	0x1c(%rdi), %esi
     8db:      	jle	0x995 <filter_32ty_range+0x105>
     8e1:      	cmpl	$0x19, %edx
     8e4:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8ea:      	cmpl	%esi, 0x20(%rdi)
     8ed:      	jg	0x8f8 <filter_32ty_range+0x68>
     8ef:      	cmpl	0x24(%rdi), %esi
     8f2:      	jle	0x995 <filter_32ty_range+0x105>
     8f8:      	cmpl	$0x21, %edx
     8fb:      	jb	0xa35 <filter_32ty_range+0x1a5>
     901:      	xorl	%edx, %edx
     903:      	cmpl	%esi, 0x28(%rdi)
     906:      	jg	0xa37 <filter_32ty_range+0x1a7>
     90c:      	cmpl	0x2c(%rdi), %esi
     90f:      	jle	0x995 <filter_32ty_range+0x105>
     915:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     91a:      	movl	0x8(%rdi), %eax
     91d:      	cmpl	%esi, 0x10(%rdi)
     920:      	setle	%r8b
     924:      	cmpl	0x14(%rdi), %esi
     927:      	setle	%dl
     92a:      	andb	%r8b, %dl
     92d:      	cmpl	$0x11, %eax
     930:      	jb	0xa37 <filter_32ty_range+0x1a7>
     936:      	cmpl	%esi, 0x18(%rdi)
     939:      	setle	%r8b
     93d:      	cmpl	0x1c(%rdi), %esi
     940:      	setle	%r9b
     944:      	andb	%r8b, %r9b
     947:      	orb	%r9b, %dl
     94a:      	cmpl	$0x19, %eax
     94d:      	jb	0xa37 <filter_32ty_range+0x1a7>
     953:      	cmpl	%esi, 0x20(%rdi)
     956:      	setle	%r8b
     95a:      	cmpl	0x24(%rdi), %esi
     95d:      	setle	%r9b
     961:      	andb	%r8b, %r9b
     964:      	orb	%r9b, %dl
     967:      	cmpl	$0x21, %eax
     96a:      	jb	0xa37 <filter_32ty_range+0x1a7>
     970:      	cmpl	%esi, 0x28(%rdi)
     973:      	setle	%al
     976:      	cmpl	0x2c(%rdi), %esi
     979:      	setle	%sil
     97d:      	jmp	0x9f1 <filter_32ty_range+0x161>
     97f:      	movl	(%rsi), %esi
     981:      	cmpl	$0x1f, %ecx
     984:      	jne	0x996 <filter_32ty_range+0x106>
     986:      	movl	$0x1, %eax
     98b:      	cmpl	%esi, 0x10(%rdi)
     98e:      	ja	0x9f9 <filter_32ty_range+0x169>
     990:      	cmpl	0x14(%rdi), %esi
     993:      	ja	0x9f9 <filter_32ty_range+0x169>
     995:      	retq
     996:      	movl	0x8(%rdi), %eax
     999:      	cmpl	%esi, 0x10(%rdi)
     99c:      	setbe	%r8b
     9a0:      	cmpl	0x14(%rdi), %esi
     9a3:      	setbe	%dl
     9a6:      	andb	%r8b, %dl
     9a9:      	cmpl	$0x11, %eax
     9ac:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9b2:      	cmpl	%esi, 0x18(%rdi)
     9b5:      	setbe	%r8b
     9b9:      	cmpl	0x1c(%rdi), %esi
     9bc:      	setbe	%r9b
     9c0:      	andb	%r8b, %r9b
     9c3:      	orb	%r9b, %dl
     9c6:      	cmpl	$0x19, %eax
     9c9:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9cb:      	cmpl	%esi, 0x20(%rdi)
     9ce:      	setbe	%r8b
     9d2:      	cmpl	0x24(%rdi), %esi
     9d5:      	setbe	%r9b
     9d9:      	andb	%r8b, %r9b
     9dc:      	orb	%r9b, %dl
     9df:      	cmpl	$0x21, %eax
     9e2:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9e4:      	cmpl	%esi, 0x28(%rdi)
     9e7:      	setbe	%al
     9ea:      	cmpl	0x2c(%rdi), %esi
     9ed:      	setbe	%sil
     9f1:      	andb	%al, %sil
     9f4:      	orb	%sil, %dl
     9f7:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     9f9:      	movl	0x8(%rdi), %edx
     9fc:      	cmpl	$0x11, %edx
     9ff:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a01:      	cmpl	%esi, 0x18(%rdi)
     a04:      	ja	0xa0b <filter_32ty_range+0x17b>
     a06:      	cmpl	0x1c(%rdi), %esi
     a09:      	jbe	0x995 <filter_32ty_range+0x105>
     a0b:      	cmpl	$0x19, %edx
     a0e:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a10:      	cmpl	%esi, 0x20(%rdi)
     a13:      	ja	0xa1e <filter_32ty_range+0x18e>
     a15:      	cmpl	0x24(%rdi), %esi
     a18:      	jbe	0x995 <filter_32ty_range+0x105>
     a1e:      	cmpl	$0x21, %edx
     a21:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a23:      	xorl	%edx, %edx
     a25:      	cmpl	%esi, 0x28(%rdi)
     a28:      	ja	0xa37 <filter_32ty_range+0x1a7>
     a2a:      	cmpl	0x2c(%rdi), %esi
     a2d:      	jbe	0x995 <filter_32ty_range+0x105>
     a33:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     a35:      	xorl	%edx, %edx
     a37:      	cmpl	$0x20, %ecx
     a3a:      	sete	%al
     a3d:      	xorb	$0x1, %dl
     a40:      	andb	%al, %dl
     a42:      	movzbl	%dl, %eax
     a45:      	retq
     a46:      	nopw	%cs:(%rax,%rax)

0000000000000a50 <filter_16ty_selector_val>:
     a50:      	movl	0x4(%rdi), %ecx
     a53:      	movl	$0x1, %eax
     a58:      	cmpq	$0x25, %rcx
     a5c:      	ja	0xacf <filter_16ty_selector_val+0x7f>
     a5e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     a68:      	btq	%rcx, %rdx
     a6c:      	jae	0xa6f <filter_16ty_selector_val+0x1f>
     a6e:      	retq
     a6f:      	movl	$0x18, %edx
     a74:      	btq	%rcx, %rdx
     a78:      	jae	0xa8f <filter_16ty_selector_val+0x3f>
     a7a:      	movzwl	(%rsi), %edx
     a7d:      	cmpl	%edx, 0x10(%rdi)
     a80:      	jne	0xba5 <filter_16ty_selector_val+0x155>
     a86:      	xorl	%eax, %eax
     a88:      	cmpl	$0x3, %ecx
     a8b:      	sete	%al
     a8e:      	retq
     a8f:      	cmpq	$0xc, %rcx
     a93:      	jne	0xacf <filter_16ty_selector_val+0x7f>
     a95:      	movzwl	(%rsi), %ecx
     a98:      	testl	%ecx, 0x10(%rdi)
     a9b:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     a9d:      	movl	0x8(%rdi), %edx
     aa0:      	cmpl	$0xd, %edx
     aa3:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     aa9:      	testl	%ecx, 0x14(%rdi)
     aac:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aae:      	cmpl	$0x11, %edx
     ab1:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ab7:      	testl	%ecx, 0x18(%rdi)
     aba:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     abc:      	cmpl	$0x15, %edx
     abf:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ac5:      	testl	%ecx, 0x1c(%rdi)
     ac8:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aca:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     acf:      	cmpl	$0x1, %ecx
     ad2:      	je	0xb41 <filter_16ty_selector_val+0xf1>
     ad4:      	cmpl	$0x2, %ecx
     ad7:      	jne	0xc67 <filter_16ty_selector_val+0x217>
     add:      	movl	0xc(%rdi), %ecx
     ae0:      	cmpl	$0xc, %ecx
     ae3:      	ja	0xc2e <filter_16ty_selector_val+0x1de>
     ae9:      	movl	$0x1402, %edx           # imm = 0x1402
     aee:      	btl	%ecx, %edx
     af1:      	jae	0xc2e <filter_16ty_selector_val+0x1de>
     af7:      	movswl	(%rsi), %ecx
     afa:      	cmpl	%ecx, 0x10(%rdi)
     afd:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b03:      	movl	0x8(%rdi), %edx
     b06:      	cmpl	$0xd, %edx
     b09:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b0f:      	cmpl	%ecx, 0x14(%rdi)
     b12:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b18:      	cmpl	$0x11, %edx
     b1b:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b21:      	cmpl	%ecx, 0x18(%rdi)
     b24:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b2a:      	cmpl	$0x15, %edx
     b2d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b33:      	cmpl	%ecx, 0x1c(%rdi)
     b36:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b3c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     b41:      	movl	0xc(%rdi), %ecx
     b44:      	cmpl	$0xc, %ecx
     b47:      	ja	0xbf3 <filter_16ty_selector_val+0x1a3>
     b4d:      	movl	$0x1402, %edx           # imm = 0x1402
     b52:      	btl	%ecx, %edx
     b55:      	jae	0xbf3 <filter_16ty_selector_val+0x1a3>
     b5b:      	movswl	(%rsi), %ecx
     b5e:      	cmpl	%ecx, 0x10(%rdi)
     b61:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b67:      	movl	0x8(%rdi), %edx
     b6a:      	cmpl	$0xd, %edx
     b6d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b73:      	cmpl	%ecx, 0x14(%rdi)
     b76:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b7c:      	cmpl	$0x11, %edx
     b7f:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b85:      	cmpl	%ecx, 0x18(%rdi)
     b88:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b8e:      	cmpl	$0x15, %edx
     b91:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b97:      	cmpl	%ecx, 0x1c(%rdi)
     b9a:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     ba0:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     ba5:      	movl	0x8(%rdi), %esi
     ba8:      	cmpl	$0xd, %esi
     bab:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bad:      	cmpl	%edx, 0x14(%rdi)
     bb0:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bb6:      	cmpl	$0x11, %esi
     bb9:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bbb:      	cmpl	%edx, 0x18(%rdi)
     bbe:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bc4:      	cmpl	$0x15, %esi
     bc7:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bc9:      	cmpl	%edx, 0x1c(%rdi)
     bcc:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bd2:      	cmpl	$0x25, %ecx
     bd5:      	ja	0xc67 <filter_16ty_selector_val+0x217>
     bdb:      	movl	%ecx, %ecx
     bdd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     be7:      	btq	%rcx, %rdx
     beb:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bf1:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     bf3:      	movzwl	(%rsi), %ecx
     bf6:      	cmpl	%ecx, 0x10(%rdi)
     bf9:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bff:      	movl	0x8(%rdi), %edx
     c02:      	cmpl	$0xd, %edx
     c05:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c07:      	cmpl	%ecx, 0x14(%rdi)
     c0a:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c10:      	cmpl	$0x11, %edx
     c13:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c15:      	cmpl	%ecx, 0x18(%rdi)
     c18:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c1e:      	cmpl	$0x15, %edx
     c21:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c23:      	cmpl	%ecx, 0x1c(%rdi)
     c26:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c2c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     c2e:      	movzwl	(%rsi), %ecx
     c31:      	cmpl	%ecx, 0x10(%rdi)
     c34:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c3a:      	movl	0x8(%rdi), %edx
     c3d:      	cmpl	$0xd, %edx
     c40:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c42:      	cmpl	%ecx, 0x14(%rdi)
     c45:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c4b:      	cmpl	$0x11, %edx
     c4e:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c50:      	cmpl	%ecx, 0x18(%rdi)
     c53:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c59:      	cmpl	$0x15, %edx
     c5c:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c5e:      	cmpl	%ecx, 0x1c(%rdi)
     c61:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c67:      	xorl	%eax, %eax
     c69:      	retq
     c6a:      	nopw	(%rax,%rax)

0000000000000c70 <filter_16ty_map>:
     c70:      	pushq	%r14
     c72:      	pushq	%rbx
     c73:      	subq	$0x18, %rsp
     c77:      	movq	%rsi, %r14
     c7a:      	movq	%rdi, %rbx
     c7d:      	movzbl	0x10(%rdi), %eax
     c81:      	movl	%eax, 0xc(%rsp)
     c85:      	movq	(%rip), %rdi            # 0xc8c <filter_16ty_map+0x1c>
     c8c:      	leaq	0xc(%rsp), %rsi
     c91:      	movl	$0x1, %eax
     c96:      	callq	*%rax
     c98:      	testq	%rax, %rax
     c9b:      	je	0xcd1 <filter_16ty_map+0x61>
     c9d:      	movq	%rax, %rdi
     ca0:      	movzwl	(%r14), %eax
     ca4:      	movq	%rax, 0x10(%rsp)
     ca9:      	leaq	0x10(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	movl	0x4(%rbx), %edx
     cb8:      	xorl	%ecx, %ecx
     cba:      	cmpl	$0x1d, %edx
     cbd:      	ja	0xceb <filter_16ty_map+0x7b>
     cbf:      	movl	$0x30038400, %esi       # imm = 0x30038400
     cc4:      	btl	%edx, %esi
     cc7:      	jae	0xcdb <filter_16ty_map+0x6b>
     cc9:      	testq	%rax, %rax
     ccc:      	setne	%cl
     ccf:      	jmp	0xceb <filter_16ty_map+0x7b>
     cd1:      	xorl	%eax, %eax
     cd3:      	addq	$0x18, %rsp
     cd7:      	popq	%rbx
     cd8:      	popq	%r14
     cda:      	retq
     cdb:      	movl	$0xc0800, %esi          # imm = 0xC0800
     ce0:      	btl	%edx, %esi
     ce3:      	jae	0xceb <filter_16ty_map+0x7b>
     ce5:      	testq	%rax, %rax
     ce8:      	sete	%cl
     ceb:      	movzbl	%cl, %eax
     cee:      	addq	$0x18, %rsp
     cf2:      	popq	%rbx
     cf3:      	popq	%r14
     cf5:      	retq
     cf6:      	nopw	%cs:(%rax,%rax)

0000000000000d00 <filter_16ty_range>:
     d00:      	movl	0x4(%rdi), %ecx
     d03:      	movl	0xc(%rdi), %eax
     d06:      	cmpl	$0xc, %eax
     d09:      	ja	0xdf0 <filter_16ty_range+0xf0>
     d0f:      	movl	$0x1402, %edx           # imm = 0x1402
     d14:      	btl	%eax, %edx
     d17:      	jae	0xdf0 <filter_16ty_range+0xf0>
     d1d:      	movswl	(%rsi), %esi
     d20:      	cmpl	$0x1f, %ecx
     d23:      	jne	0xd8b <filter_16ty_range+0x8b>
     d25:      	movl	$0x1, %eax
     d2a:      	cmpl	%esi, 0x10(%rdi)
     d2d:      	jg	0xd38 <filter_16ty_range+0x38>
     d2f:      	cmpl	%esi, 0x14(%rdi)
     d32:      	jge	0xe07 <filter_16ty_range+0x107>
     d38:      	movl	0x8(%rdi), %edx
     d3b:      	cmpl	$0x11, %edx
     d3e:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d44:      	cmpl	%esi, 0x18(%rdi)
     d47:      	jg	0xd52 <filter_16ty_range+0x52>
     d49:      	cmpl	%esi, 0x1c(%rdi)
     d4c:      	jge	0xe07 <filter_16ty_range+0x107>
     d52:      	cmpl	$0x19, %edx
     d55:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d5b:      	cmpl	%esi, 0x20(%rdi)
     d5e:      	jg	0xd69 <filter_16ty_range+0x69>
     d60:      	cmpl	%esi, 0x24(%rdi)
     d63:      	jge	0xe07 <filter_16ty_range+0x107>
     d69:      	cmpl	$0x21, %edx
     d6c:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d72:      	xorl	%edx, %edx
     d74:      	cmpl	%esi, 0x28(%rdi)
     d77:      	jg	0xea9 <filter_16ty_range+0x1a9>
     d7d:      	cmpl	%esi, 0x2c(%rdi)
     d80:      	jge	0xe07 <filter_16ty_range+0x107>
     d86:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     d8b:      	movl	0x8(%rdi), %eax
     d8e:      	cmpl	%esi, 0x10(%rdi)
     d91:      	setle	%r8b
     d95:      	cmpl	%esi, 0x14(%rdi)
     d98:      	setge	%dl
     d9b:      	andb	%r8b, %dl
     d9e:      	cmpl	$0x11, %eax
     da1:      	jb	0xea9 <filter_16ty_range+0x1a9>
     da7:      	cmpl	%esi, 0x18(%rdi)
     daa:      	setle	%r8b
     dae:      	cmpl	%esi, 0x1c(%rdi)
     db1:      	setge	%r9b
     db5:      	andb	%r8b, %r9b
     db8:      	orb	%r9b, %dl
     dbb:      	cmpl	$0x19, %eax
     dbe:      	jb	0xea9 <filter_16ty_range+0x1a9>
     dc4:      	cmpl	%esi, 0x20(%rdi)
     dc7:      	setle	%r8b
     dcb:      	cmpl	%esi, 0x24(%rdi)
     dce:      	setge	%r9b
     dd2:      	andb	%r8b, %r9b
     dd5:      	orb	%r9b, %dl
     dd8:      	cmpl	$0x21, %eax
     ddb:      	jb	0xea9 <filter_16ty_range+0x1a9>
     de1:      	cmpl	%esi, 0x28(%rdi)
     de4:      	setle	%al
     de7:      	cmpl	%esi, 0x2c(%rdi)
     dea:      	setge	%sil
     dee:      	jmp	0xe63 <filter_16ty_range+0x163>
     df0:      	movzwl	(%rsi), %esi
     df3:      	cmpl	$0x1f, %ecx
     df6:      	jne	0xe08 <filter_16ty_range+0x108>
     df8:      	movl	$0x1, %eax
     dfd:      	cmpl	%esi, 0x10(%rdi)
     e00:      	ja	0xe6b <filter_16ty_range+0x16b>
     e02:      	cmpl	%esi, 0x14(%rdi)
     e05:      	jb	0xe6b <filter_16ty_range+0x16b>
     e07:      	retq
     e08:      	movl	0x8(%rdi), %eax
     e0b:      	cmpl	%esi, 0x10(%rdi)
     e0e:      	setbe	%r8b
     e12:      	cmpl	%esi, 0x14(%rdi)
     e15:      	setae	%dl
     e18:      	andb	%r8b, %dl
     e1b:      	cmpl	$0x11, %eax
     e1e:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e24:      	cmpl	%esi, 0x18(%rdi)
     e27:      	setbe	%r8b
     e2b:      	cmpl	%esi, 0x1c(%rdi)
     e2e:      	setae	%r9b
     e32:      	andb	%r8b, %r9b
     e35:      	orb	%r9b, %dl
     e38:      	cmpl	$0x19, %eax
     e3b:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e3d:      	cmpl	%esi, 0x20(%rdi)
     e40:      	setbe	%r8b
     e44:      	cmpl	%esi, 0x24(%rdi)
     e47:      	setae	%r9b
     e4b:      	andb	%r8b, %r9b
     e4e:      	orb	%r9b, %dl
     e51:      	cmpl	$0x21, %eax
     e54:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e56:      	cmpl	%esi, 0x28(%rdi)
     e59:      	setbe	%al
     e5c:      	cmpl	%esi, 0x2c(%rdi)
     e5f:      	setae	%sil
     e63:      	andb	%al, %sil
     e66:      	orb	%sil, %dl
     e69:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     e6b:      	movl	0x8(%rdi), %edx
     e6e:      	cmpl	$0x11, %edx
     e71:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e73:      	cmpl	%esi, 0x18(%rdi)
     e76:      	ja	0xe7d <filter_16ty_range+0x17d>
     e78:      	cmpl	%esi, 0x1c(%rdi)
     e7b:      	jae	0xe07 <filter_16ty_range+0x107>
     e7d:      	cmpl	$0x19, %edx
     e80:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e82:      	cmpl	%esi, 0x20(%rdi)
     e85:      	ja	0xe90 <filter_16ty_range+0x190>
     e87:      	cmpl	%esi, 0x24(%rdi)
     e8a:      	jae	0xe07 <filter_16ty_range+0x107>
     e90:      	cmpl	$0x21, %edx
     e93:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e95:      	xorl	%edx, %edx
     e97:      	cmpl	%esi, 0x28(%rdi)
     e9a:      	ja	0xea9 <filter_16ty_range+0x1a9>
     e9c:      	cmpl	%esi, 0x2c(%rdi)
     e9f:      	jae	0xe07 <filter_16ty_range+0x107>
     ea5:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     ea7:      	xorl	%edx, %edx
     ea9:      	cmpl	$0x20, %ecx
     eac:      	sete	%al
     eaf:      	xorb	$0x1, %dl
     eb2:      	andb	%al, %dl
     eb4:      	movzbl	%dl, %eax
     eb7:      	retq
     eb8:      	nopl	(%rax,%rax)

0000000000000ec0 <filter_8ty_selector_val>:
     ec0:      	movl	0x4(%rdi), %ecx
     ec3:      	movl	$0x1, %eax
     ec8:      	cmpq	$0x25, %rcx
     ecc:      	ja	0xf3f <filter_8ty_selector_val+0x7f>
     ece:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     ed8:      	btq	%rcx, %rdx
     edc:      	jae	0xedf <filter_8ty_selector_val+0x1f>
     ede:      	retq
     edf:      	movl	$0x18, %edx
     ee4:      	btq	%rcx, %rdx
     ee8:      	jae	0xeff <filter_8ty_selector_val+0x3f>
     eea:      	movzbl	(%rsi), %edx
     eed:      	cmpl	%edx, 0x10(%rdi)
     ef0:      	jne	0x1015 <filter_8ty_selector_val+0x155>
     ef6:      	xorl	%eax, %eax
     ef8:      	cmpl	$0x3, %ecx
     efb:      	sete	%al
     efe:      	retq
     eff:      	cmpq	$0xc, %rcx
     f03:      	jne	0xf3f <filter_8ty_selector_val+0x7f>
     f05:      	movzbl	(%rsi), %ecx
     f08:      	testl	%ecx, 0x10(%rdi)
     f0b:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f0d:      	movl	0x8(%rdi), %edx
     f10:      	cmpl	$0xd, %edx
     f13:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f19:      	testl	%ecx, 0x14(%rdi)
     f1c:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f1e:      	cmpl	$0x11, %edx
     f21:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f27:      	testl	%ecx, 0x18(%rdi)
     f2a:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f2c:      	cmpl	$0x15, %edx
     f2f:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f35:      	testl	%ecx, 0x1c(%rdi)
     f38:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f3a:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     f3f:      	cmpl	$0x1, %ecx
     f42:      	je	0xfb1 <filter_8ty_selector_val+0xf1>
     f44:      	cmpl	$0x2, %ecx
     f47:      	jne	0x10d7 <filter_8ty_selector_val+0x217>
     f4d:      	movl	0xc(%rdi), %ecx
     f50:      	cmpl	$0xc, %ecx
     f53:      	ja	0x109e <filter_8ty_selector_val+0x1de>
     f59:      	movl	$0x1402, %edx           # imm = 0x1402
     f5e:      	btl	%ecx, %edx
     f61:      	jae	0x109e <filter_8ty_selector_val+0x1de>
     f67:      	movsbl	(%rsi), %ecx
     f6a:      	cmpl	%ecx, 0x10(%rdi)
     f6d:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f73:      	movl	0x8(%rdi), %edx
     f76:      	cmpl	$0xd, %edx
     f79:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f7f:      	cmpl	%ecx, 0x14(%rdi)
     f82:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f88:      	cmpl	$0x11, %edx
     f8b:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f91:      	cmpl	%ecx, 0x18(%rdi)
     f94:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f9a:      	cmpl	$0x15, %edx
     f9d:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fa3:      	cmpl	%ecx, 0x1c(%rdi)
     fa6:      	jg	0xede <filter_8ty_selector_val+0x1e>
     fac:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     fb1:      	movl	0xc(%rdi), %ecx
     fb4:      	cmpl	$0xc, %ecx
     fb7:      	ja	0x1063 <filter_8ty_selector_val+0x1a3>
     fbd:      	movl	$0x1402, %edx           # imm = 0x1402
     fc2:      	btl	%ecx, %edx
     fc5:      	jae	0x1063 <filter_8ty_selector_val+0x1a3>
     fcb:      	movsbl	(%rsi), %ecx
     fce:      	cmpl	%ecx, 0x10(%rdi)
     fd1:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fd7:      	movl	0x8(%rdi), %edx
     fda:      	cmpl	$0xd, %edx
     fdd:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fe3:      	cmpl	%ecx, 0x14(%rdi)
     fe6:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fec:      	cmpl	$0x11, %edx
     fef:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     ff5:      	cmpl	%ecx, 0x18(%rdi)
     ff8:      	jl	0xede <filter_8ty_selector_val+0x1e>
     ffe:      	cmpl	$0x15, %edx
    1001:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1007:      	cmpl	%ecx, 0x1c(%rdi)
    100a:      	jl	0xede <filter_8ty_selector_val+0x1e>
    1010:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1015:      	movl	0x8(%rdi), %esi
    1018:      	cmpl	$0xd, %esi
    101b:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    101d:      	cmpl	%edx, 0x14(%rdi)
    1020:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1026:      	cmpl	$0x11, %esi
    1029:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    102b:      	cmpl	%edx, 0x18(%rdi)
    102e:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1034:      	cmpl	$0x15, %esi
    1037:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    1039:      	cmpl	%edx, 0x1c(%rdi)
    103c:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1042:      	cmpl	$0x25, %ecx
    1045:      	ja	0x10d7 <filter_8ty_selector_val+0x217>
    104b:      	movl	%ecx, %ecx
    104d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1057:      	btq	%rcx, %rdx
    105b:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1061:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1063:      	movzbl	(%rsi), %ecx
    1066:      	cmpl	%ecx, 0x10(%rdi)
    1069:      	jb	0xede <filter_8ty_selector_val+0x1e>
    106f:      	movl	0x8(%rdi), %edx
    1072:      	cmpl	$0xd, %edx
    1075:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1077:      	cmpl	%ecx, 0x14(%rdi)
    107a:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1080:      	cmpl	$0x11, %edx
    1083:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1085:      	cmpl	%ecx, 0x18(%rdi)
    1088:      	jb	0xede <filter_8ty_selector_val+0x1e>
    108e:      	cmpl	$0x15, %edx
    1091:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1093:      	cmpl	%ecx, 0x1c(%rdi)
    1096:      	jb	0xede <filter_8ty_selector_val+0x1e>
    109c:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    109e:      	movzbl	(%rsi), %ecx
    10a1:      	cmpl	%ecx, 0x10(%rdi)
    10a4:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10aa:      	movl	0x8(%rdi), %edx
    10ad:      	cmpl	$0xd, %edx
    10b0:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10b2:      	cmpl	%ecx, 0x14(%rdi)
    10b5:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10bb:      	cmpl	$0x11, %edx
    10be:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10c0:      	cmpl	%ecx, 0x18(%rdi)
    10c3:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10c9:      	cmpl	$0x15, %edx
    10cc:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10ce:      	cmpl	%ecx, 0x1c(%rdi)
    10d1:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10d7:      	xorl	%eax, %eax
    10d9:      	retq
    10da:      	nopw	(%rax,%rax)

00000000000010e0 <filter_8ty_map>:
    10e0:      	pushq	%r14
    10e2:      	pushq	%rbx
    10e3:      	subq	$0x18, %rsp
    10e7:      	movq	%rsi, %r14
    10ea:      	movq	%rdi, %rbx
    10ed:      	movzbl	0x10(%rdi), %eax
    10f1:      	movl	%eax, 0xc(%rsp)
    10f5:      	movq	(%rip), %rdi            # 0x10fc <filter_8ty_map+0x1c>
    10fc:      	leaq	0xc(%rsp), %rsi
    1101:      	movl	$0x1, %eax
    1106:      	callq	*%rax
    1108:      	testq	%rax, %rax
    110b:      	je	0x1141 <filter_8ty_map+0x61>
    110d:      	movq	%rax, %rdi
    1110:      	movzbl	(%r14), %eax
    1114:      	movq	%rax, 0x10(%rsp)
    1119:      	leaq	0x10(%rsp), %rsi
    111e:      	movl	$0x1, %eax
    1123:      	callq	*%rax
    1125:      	movl	0x4(%rbx), %edx
    1128:      	xorl	%ecx, %ecx
    112a:      	cmpl	$0x1d, %edx
    112d:      	ja	0x115b <filter_8ty_map+0x7b>
    112f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1134:      	btl	%edx, %esi
    1137:      	jae	0x114b <filter_8ty_map+0x6b>
    1139:      	testq	%rax, %rax
    113c:      	setne	%cl
    113f:      	jmp	0x115b <filter_8ty_map+0x7b>
    1141:      	xorl	%eax, %eax
    1143:      	addq	$0x18, %rsp
    1147:      	popq	%rbx
    1148:      	popq	%r14
    114a:      	retq
    114b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1150:      	btl	%edx, %esi
    1153:      	jae	0x115b <filter_8ty_map+0x7b>
    1155:      	testq	%rax, %rax
    1158:      	sete	%cl
    115b:      	movzbl	%cl, %eax
    115e:      	addq	$0x18, %rsp
    1162:      	popq	%rbx
    1163:      	popq	%r14
    1165:      	retq
    1166:      	nopw	%cs:(%rax,%rax)

0000000000001170 <filter_8ty_range>:
    1170:      	movl	0x4(%rdi), %ecx
    1173:      	movl	0xc(%rdi), %eax
    1176:      	cmpl	$0xc, %eax
    1179:      	ja	0x1260 <filter_8ty_range+0xf0>
    117f:      	movl	$0x1402, %edx           # imm = 0x1402
    1184:      	btl	%eax, %edx
    1187:      	jae	0x1260 <filter_8ty_range+0xf0>
    118d:      	movsbl	(%rsi), %esi
    1190:      	cmpl	$0x1f, %ecx
    1193:      	jne	0x11fb <filter_8ty_range+0x8b>
    1195:      	movl	$0x1, %eax
    119a:      	cmpl	%esi, 0x10(%rdi)
    119d:      	jg	0x11a8 <filter_8ty_range+0x38>
    119f:      	cmpl	%esi, 0x14(%rdi)
    11a2:      	jge	0x1277 <filter_8ty_range+0x107>
    11a8:      	movl	0x8(%rdi), %edx
    11ab:      	cmpl	$0x11, %edx
    11ae:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11b4:      	cmpl	%esi, 0x18(%rdi)
    11b7:      	jg	0x11c2 <filter_8ty_range+0x52>
    11b9:      	cmpl	%esi, 0x1c(%rdi)
    11bc:      	jge	0x1277 <filter_8ty_range+0x107>
    11c2:      	cmpl	$0x19, %edx
    11c5:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11cb:      	cmpl	%esi, 0x20(%rdi)
    11ce:      	jg	0x11d9 <filter_8ty_range+0x69>
    11d0:      	cmpl	%esi, 0x24(%rdi)
    11d3:      	jge	0x1277 <filter_8ty_range+0x107>
    11d9:      	cmpl	$0x21, %edx
    11dc:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11e2:      	xorl	%edx, %edx
    11e4:      	cmpl	%esi, 0x28(%rdi)
    11e7:      	jg	0x1319 <filter_8ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x2c(%rdi)
    11f0:      	jge	0x1277 <filter_8ty_range+0x107>
    11f6:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    11fb:      	movl	0x8(%rdi), %eax
    11fe:      	cmpl	%esi, 0x10(%rdi)
    1201:      	setle	%r8b
    1205:      	cmpl	%esi, 0x14(%rdi)
    1208:      	setge	%dl
    120b:      	andb	%r8b, %dl
    120e:      	cmpl	$0x11, %eax
    1211:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1217:      	cmpl	%esi, 0x18(%rdi)
    121a:      	setle	%r8b
    121e:      	cmpl	%esi, 0x1c(%rdi)
    1221:      	setge	%r9b
    1225:      	andb	%r8b, %r9b
    1228:      	orb	%r9b, %dl
    122b:      	cmpl	$0x19, %eax
    122e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1234:      	cmpl	%esi, 0x20(%rdi)
    1237:      	setle	%r8b
    123b:      	cmpl	%esi, 0x24(%rdi)
    123e:      	setge	%r9b
    1242:      	andb	%r8b, %r9b
    1245:      	orb	%r9b, %dl
    1248:      	cmpl	$0x21, %eax
    124b:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1251:      	cmpl	%esi, 0x28(%rdi)
    1254:      	setle	%al
    1257:      	cmpl	%esi, 0x2c(%rdi)
    125a:      	setge	%sil
    125e:      	jmp	0x12d3 <filter_8ty_range+0x163>
    1260:      	movzbl	(%rsi), %esi
    1263:      	cmpl	$0x1f, %ecx
    1266:      	jne	0x1278 <filter_8ty_range+0x108>
    1268:      	movl	$0x1, %eax
    126d:      	cmpl	%esi, 0x10(%rdi)
    1270:      	ja	0x12db <filter_8ty_range+0x16b>
    1272:      	cmpl	%esi, 0x14(%rdi)
    1275:      	jb	0x12db <filter_8ty_range+0x16b>
    1277:      	retq
    1278:      	movl	0x8(%rdi), %eax
    127b:      	cmpl	%esi, 0x10(%rdi)
    127e:      	setbe	%r8b
    1282:      	cmpl	%esi, 0x14(%rdi)
    1285:      	setae	%dl
    1288:      	andb	%r8b, %dl
    128b:      	cmpl	$0x11, %eax
    128e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1294:      	cmpl	%esi, 0x18(%rdi)
    1297:      	setbe	%r8b
    129b:      	cmpl	%esi, 0x1c(%rdi)
    129e:      	setae	%r9b
    12a2:      	andb	%r8b, %r9b
    12a5:      	orb	%r9b, %dl
    12a8:      	cmpl	$0x19, %eax
    12ab:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12ad:      	cmpl	%esi, 0x20(%rdi)
    12b0:      	setbe	%r8b
    12b4:      	cmpl	%esi, 0x24(%rdi)
    12b7:      	setae	%r9b
    12bb:      	andb	%r8b, %r9b
    12be:      	orb	%r9b, %dl
    12c1:      	cmpl	$0x21, %eax
    12c4:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12c6:      	cmpl	%esi, 0x28(%rdi)
    12c9:      	setbe	%al
    12cc:      	cmpl	%esi, 0x2c(%rdi)
    12cf:      	setae	%sil
    12d3:      	andb	%al, %sil
    12d6:      	orb	%sil, %dl
    12d9:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    12db:      	movl	0x8(%rdi), %edx
    12de:      	cmpl	$0x11, %edx
    12e1:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12e3:      	cmpl	%esi, 0x18(%rdi)
    12e6:      	ja	0x12ed <filter_8ty_range+0x17d>
    12e8:      	cmpl	%esi, 0x1c(%rdi)
    12eb:      	jae	0x1277 <filter_8ty_range+0x107>
    12ed:      	cmpl	$0x19, %edx
    12f0:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12f2:      	cmpl	%esi, 0x20(%rdi)
    12f5:      	ja	0x1300 <filter_8ty_range+0x190>
    12f7:      	cmpl	%esi, 0x24(%rdi)
    12fa:      	jae	0x1277 <filter_8ty_range+0x107>
    1300:      	cmpl	$0x21, %edx
    1303:      	jb	0x1317 <filter_8ty_range+0x1a7>
    1305:      	xorl	%edx, %edx
    1307:      	cmpl	%esi, 0x28(%rdi)
    130a:      	ja	0x1319 <filter_8ty_range+0x1a9>
    130c:      	cmpl	%esi, 0x2c(%rdi)
    130f:      	jae	0x1277 <filter_8ty_range+0x107>
    1315:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    1317:      	xorl	%edx, %edx
    1319:      	cmpl	$0x20, %ecx
    131c:      	sete	%al
    131f:      	xorb	$0x1, %dl
    1322:      	andb	%al, %dl
    1324:      	movzbl	%dl, %eax
    1327:      	retq
    1328:      	nopl	(%rax,%rax)

0000000000001330 <filter_file_buf>:
    1330:      	pushq	%rbx
    1331:      	movq	%rdi, %rbx
    1334:      	movl	(%rsi), %edx
    1336:      	movl	0x4(%rdi), %ecx
    1339:      	testl	%edx, %edx
    133b:      	jne	0x134b <filter_file_buf+0x1b>
    133d:      	movl	%ecx, %eax
    133f:      	andl	$-0x2, %eax
    1342:      	cmpl	$0x24, %eax
    1345:      	je	0x134b <filter_file_buf+0x1b>
    1347:      	xorl	%eax, %eax
    1349:      	popq	%rbx
    134a:      	retq
    134b:      	cmpl	$0x25, %ecx
    134e:      	ja	0x138a <filter_file_buf+0x5a>
    1350:      	movl	%ecx, %eax
    1352:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1357:      	btq	%rax, %rdi
    135b:      	jb	0x13be <filter_file_buf+0x8e>
    135d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1362:      	btq	%rax, %rdi
    1366:      	jb	0x13a8 <filter_file_buf+0x78>
    1368:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1372:      	btq	%rax, %rdi
    1376:      	jae	0x138a <filter_file_buf+0x5a>
    1378:      	movq	%rbx, %rdi
    137b:      	callq	0x1e20 <filter_file_type>
    1380:      	movl	0x4(%rbx), %ecx
    1383:      	cmpl	$0x25, %ecx
    1386:      	jbe	0x13db <filter_file_buf+0xab>
    1388:      	jmp	0x13f1 <filter_file_buf+0xc1>
    138a:      	leal	-0x3(%rcx), %eax
    138d:      	cmpl	$0x2, %eax
    1390:      	jae	0x13d4 <filter_file_buf+0xa4>
    1392:      	addq	$0x4, %rsi
    1396:      	movq	%rbx, %rdi
    1399:      	callq	0x18b0 <filter_char_buf_equal>
    139e:      	movl	0x4(%rbx), %ecx
    13a1:      	cmpl	$0x25, %ecx
    13a4:      	jbe	0x13db <filter_file_buf+0xab>
    13a6:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13a8:      	addq	$0x4, %rsi
    13ac:      	movl	0x10(%rbx), %edi
    13af:      	callq	0x1cd0 <filter_char_buf_postfix>
    13b4:      	movl	0x4(%rbx), %ecx
    13b7:      	cmpl	$0x25, %ecx
    13ba:      	jbe	0x13db <filter_file_buf+0xab>
    13bc:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13be:      	addq	$0x4, %rsi
    13c2:      	movl	0x10(%rbx), %edi
    13c5:      	callq	0x1c30 <filter_char_buf_prefix>
    13ca:      	movl	0x4(%rbx), %ecx
    13cd:      	cmpl	$0x25, %ecx
    13d0:      	jbe	0x13db <filter_file_buf+0xab>
    13d2:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13d4:      	xorl	%eax, %eax
    13d6:      	cmpl	$0x25, %ecx
    13d9:      	ja	0x13f1 <filter_file_buf+0xc1>
    13db:      	movl	%ecx, %ecx
    13dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    13e7:      	btq	%rcx, %rdx
    13eb:      	jae	0x13f1 <filter_file_buf+0xc1>
    13ed:      	xorq	$0x1, %rax
    13f1:      	popq	%rbx
    13f2:      	retq
    13f3:      	nopw	%cs:(%rax,%rax)

0000000000001400 <filter_char_buf>:
    1400:      	pushq	%rbx
    1401:      	movq	%rsi, %rax
    1404:      	movq	%rdi, %rbx
    1407:      	movslq	%edx, %rcx
    140a:      	movl	-0x4(%rsi,%rcx), %edx
    140e:      	movl	%ecx, %esi
    1410:      	addq	%rax, %rsi
    1413:      	movl	0x4(%rdi), %ecx
    1416:      	xorl	%eax, %eax
    1418:      	cmpl	$0x19, %ecx
    141b:      	jg	0x1431 <filter_char_buf+0x31>
    141d:      	leal	-0x3(%rcx), %edi
    1420:      	cmpl	$0x2, %edi
    1423:      	jb	0x1468 <filter_char_buf+0x68>
    1425:      	cmpl	$0x8, %ecx
    1428:      	je	0x145e <filter_char_buf+0x5e>
    142a:      	cmpl	$0x9, %ecx
    142d:      	je	0x1440 <filter_char_buf+0x40>
    142f:      	jmp	0x147f <filter_char_buf+0x7f>
    1431:      	cmpl	$0x20, %ecx
    1434:      	jg	0x144a <filter_char_buf+0x4a>
    1436:      	cmpl	$0x1a, %ecx
    1439:      	je	0x145e <filter_char_buf+0x5e>
    143b:      	cmpl	$0x1b, %ecx
    143e:      	jne	0x147f <filter_char_buf+0x7f>
    1440:      	movl	0x10(%rbx), %edi
    1443:      	callq	0x1cd0 <filter_char_buf_postfix>
    1448:      	jmp	0x147c <filter_char_buf+0x7c>
    144a:      	cmpl	$0x21, %ecx
    144d:      	je	0x1472 <filter_char_buf+0x72>
    144f:      	cmpl	$0x22, %ecx
    1452:      	jne	0x147f <filter_char_buf+0x7f>
    1454:      	movq	%rbx, %rdi
    1457:      	movl	$0x1, %ecx
    145c:      	jmp	0x1477 <filter_char_buf+0x77>
    145e:      	movl	0x10(%rbx), %edi
    1461:      	callq	0x1c30 <filter_char_buf_prefix>
    1466:      	jmp	0x147c <filter_char_buf+0x7c>
    1468:      	movq	%rbx, %rdi
    146b:      	callq	0x18b0 <filter_char_buf_equal>
    1470:      	jmp	0x147c <filter_char_buf+0x7c>
    1472:      	movq	%rbx, %rdi
    1475:      	xorl	%ecx, %ecx
    1477:      	callq	0x1ed0 <filter_char_substring>
    147c:      	movl	0x4(%rbx), %ecx
    147f:      	cmpl	$0x25, %ecx
    1482:      	ja	0x14a1 <filter_char_buf+0xa1>
    1484:      	movl	%ecx, %ecx
    1486:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1490:      	btq	%rcx, %rdx
    1494:      	jae	0x14a1 <filter_char_buf+0xa1>
    1496:      	xorl	%ecx, %ecx
    1498:      	testq	%rax, %rax
    149b:      	sete	%cl
    149e:      	movq	%rcx, %rax
    14a1:      	popq	%rbx
    14a2:      	retq
    14a3:      	nopw	%cs:(%rax,%rax)

00000000000014b0 <filter_inet>:
    14b0:      	pushq	%r15
    14b2:      	pushq	%r14
    14b4:      	pushq	%r12
    14b6:      	pushq	%rbx
    14b7:      	subq	$0x48, %rsp
    14bb:      	movq	$0x0, 0x40(%rsp)
    14c4:      	movq	$0x0, 0x38(%rsp)
    14cd:      	movq	$0x0, 0x30(%rsp)
    14d6:      	movq	$0x0, 0x28(%rsp)
    14df:      	movq	$0x0, 0x20(%rsp)
    14e8:      	movl	$0x0, (%rsp)
    14ef:      	movl	$0x0, 0x4(%rsp)
    14f7:      	movl	0xc(%rdi), %edx
    14fa:      	xorl	%eax, %eax
    14fc:      	cmpl	$0x27, %edx
    14ff:      	jg	0x1517 <filter_inet+0x67>
    1501:      	cmpl	$0x5, %edx
    1504:      	je	0x159c <filter_inet+0xec>
    150a:      	movq	%rsi, %r8
    150d:      	cmpl	$0x7, %edx
    1510:      	je	0x1528 <filter_inet+0x78>
    1512:      	jmp	0x17ad <filter_inet+0x2fd>
    1517:      	cmpl	$0x28, %edx
    151a:      	je	0x1574 <filter_inet+0xc4>
    151c:      	movq	%rsi, %r8
    151f:      	cmpl	$0x29, %edx
    1522:      	jne	0x17ad <filter_inet+0x2fd>
    1528:      	movl	0x4(%rdi), %ecx
    152b:      	xorl	%eax, %eax
    152d:      	cmpl	$0x13, %ecx
    1530:      	jle	0x15a9 <filter_inet+0xf9>
    1532:      	cmpl	$0x17, %ecx
    1535:      	jg	0x1554 <filter_inet+0xa4>
    1537:      	leal	-0x14(%rcx), %edx
    153a:      	cmpl	$0x2, %edx
    153d:      	jb	0x15fa <filter_inet+0x14a>
    1543:      	leal	-0x16(%rcx), %edx
    1546:      	cmpl	$0x2, %edx
    1549:      	jb	0x15f4 <filter_inet+0x144>
    154f:      	jmp	0x17ad <filter_inet+0x2fd>
    1554:      	cmpl	$0x1b, %ecx
    1557:      	jg	0x1637 <filter_inet+0x187>
    155d:      	cmpl	$0x18, %ecx
    1560:      	je	0x166a <filter_inet+0x1ba>
    1566:      	cmpl	$0x19, %ecx
    1569:      	je	0x1660 <filter_inet+0x1b0>
    156f:      	jmp	0x17ad <filter_inet+0x2fd>
    1574:      	movzwl	(%rsi), %eax
    1577:      	movw	%ax, 0x46(%rsp)
    157c:      	movzwl	0x2(%rsi), %eax
    1580:      	movw	%ax, 0x40(%rsp)
    1585:      	movq	0x8(%rsi), %rax
    1589:      	movq	%rax, 0x20(%rsp)
    158e:      	movq	0x10(%rsi), %rax
    1592:      	movq	%rax, 0x28(%rsp)
    1597:      	leaq	0x20(%rsp), %rsi
    159c:      	xorl	%r8d, %r8d
    159f:      	movl	0x4(%rdi), %ecx
    15a2:      	xorl	%eax, %eax
    15a4:      	cmpl	$0x13, %ecx
    15a7:      	jg	0x1532 <filter_inet+0x82>
    15a9:      	cmpl	$0xf, %ecx
    15ac:      	jle	0x15ca <filter_inet+0x11a>
    15ae:      	cmpl	$0x11, %ecx
    15b1:      	jg	0x15e6 <filter_inet+0x136>
    15b3:      	cmpl	$0x10, %ecx
    15b6:      	je	0x15f4 <filter_inet+0x144>
    15b8:      	cmpl	$0x11, %ecx
    15bb:      	jne	0x17ad <filter_inet+0x2fd>
    15c1:      	movzwl	0x24(%rsi), %eax
    15c5:      	jmp	0x17a2 <filter_inet+0x2f2>
    15ca:      	cmpl	$0xd, %ecx
    15cd:      	je	0x166a <filter_inet+0x1ba>
    15d3:      	cmpl	$0xe, %ecx
    15d6:      	je	0x1660 <filter_inet+0x1b0>
    15dc:      	cmpl	$0xf, %ecx
    15df:      	je	0x15fa <filter_inet+0x14a>
    15e1:      	jmp	0x17ad <filter_inet+0x2fd>
    15e6:      	cmpl	$0x12, %ecx
    15e9:      	je	0x15fa <filter_inet+0x14a>
    15eb:      	cmpl	$0x13, %ecx
    15ee:      	jne	0x17ad <filter_inet+0x2fd>
    15f4:      	movzwl	0x22(%rsi), %edx
    15f8:      	jmp	0x15fe <filter_inet+0x14e>
    15fa:      	movzwl	0x20(%rsi), %edx
    15fe:      	movl	%edx, 0x4(%rsp)
    1602:      	xorl	%ebx, %ebx
    1604:      	xorl	%r15d, %r15d
    1607:      	xorl	%r14d, %r14d
    160a:      	xorl	%eax, %eax
    160c:      	cmpl	$0x11, %ecx
    160f:      	jg	0x1681 <filter_inet+0x1d1>
    1611:      	leal	-0xd(%rcx), %edx
    1614:      	cmpl	$0x2, %edx
    1617:      	jb	0x16a8 <filter_inet+0x1f8>
    161d:      	leal	-0xf(%rcx), %edx
    1620:      	cmpl	$0x2, %edx
    1623:      	jb	0x16fd <filter_inet+0x24d>
    1629:      	cmpl	$0x11, %ecx
    162c:      	je	0x17a5 <filter_inet+0x2f5>
    1632:      	jmp	0x17ad <filter_inet+0x2fd>
    1637:      	cmpl	$0x1c, %ecx
    163a:      	je	0x179e <filter_inet+0x2ee>
    1640:      	cmpl	$0x1d, %ecx
    1643:      	jne	0x17ad <filter_inet+0x2fd>
    1649:      	cmpl	$0x7, %edx
    164c:      	jne	0x17d1 <filter_inet+0x321>
    1652:      	testq	%r8, %r8
    1655:      	jne	0x17db <filter_inet+0x32b>
    165b:      	jmp	0x17a5 <filter_inet+0x2f5>
    1660:      	movq	0x10(%rsi), %rbx
    1664:      	movq	0x18(%rsi), %r14
    1668:      	jmp	0x1671 <filter_inet+0x1c1>
    166a:      	movq	(%rsi), %rbx
    166d:      	movq	0x8(%rsi), %r14
    1671:      	movq	%rbx, %r15
    1674:      	shrq	$0x20, %r15
    1678:      	xorl	%edx, %edx
    167a:      	xorl	%eax, %eax
    167c:      	cmpl	$0x11, %ecx
    167f:      	jle	0x1611 <filter_inet+0x161>
    1681:      	cmpl	$0x19, %ecx
    1684:      	ja	0x16f1 <filter_inet+0x241>
    1686:      	movl	$0x500000, %r8d         # imm = 0x500000
    168c:      	btl	%ecx, %r8d
    1690:      	jb	0x1707 <filter_inet+0x257>
    1692:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1698:      	btl	%ecx, %r8d
    169c:      	jb	0x1717 <filter_inet+0x267>
    169e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    16a3:      	btl	%ecx, %edx
    16a6:      	jae	0x16f1 <filter_inet+0x241>
    16a8:      	movzwl	0x26(%rsi), %eax
    16ac:      	cmpl	$0xa, %eax
    16af:      	je	0x1727 <filter_inet+0x277>
    16b1:      	cmpl	$0x2, %eax
    16b4:      	jne	0x1797 <filter_inet+0x2e7>
    16ba:      	movq	%rdi, %r12
    16bd:      	movl	0x10(%rdi), %eax
    16c0:      	movl	%eax, 0x8(%rsp)
    16c4:      	movq	(%rip), %rdi            # 0x16cb <filter_inet+0x21b>
    16cb:      	leaq	0x8(%rsp), %rsi
    16d0:      	movl	$0x1, %eax
    16d5:      	callq	*%rax
    16d7:      	testq	%rax, %rax
    16da:      	je	0x17b9 <filter_inet+0x309>
    16e0:      	movq	%rax, %rdi
    16e3:      	movl	$0x20, 0xc(%rsp)
    16eb:      	movl	%ebx, 0x10(%rsp)
    16ef:      	jmp	0x176b <filter_inet+0x2bb>
    16f1:      	addl	$-0x12, %ecx
    16f4:      	cmpl	$0x2, %ecx
    16f7:      	jae	0x17ad <filter_inet+0x2fd>
    16fd:      	leaq	0x4(%rsp), %rsi
    1702:      	jmp	0x17a8 <filter_inet+0x2f8>
    1707:      	xorl	%eax, %eax
    1709:      	cmpl	$0x400, %edx            # imm = 0x400
    170f:      	setb	%al
    1712:      	jmp	0x17ad <filter_inet+0x2fd>
    1717:      	xorl	%eax, %eax
    1719:      	cmpl	$0x400, %edx            # imm = 0x400
    171f:      	setae	%al
    1722:      	jmp	0x17ad <filter_inet+0x2fd>
    1727:      	movq	%rdi, %r12
    172a:      	movl	0x14(%rdi), %eax
    172d:      	movl	%eax, 0x8(%rsp)
    1731:      	movq	(%rip), %rdi            # 0x1738 <filter_inet+0x288>
    1738:      	leaq	0x8(%rsp), %rsi
    173d:      	movl	$0x1, %eax
    1742:      	callq	*%rax
    1744:      	testq	%rax, %rax
    1747:      	je	0x17b9 <filter_inet+0x309>
    1749:      	movq	%rax, %rdi
    174c:      	movl	$0x80, 0xc(%rsp)
    1754:      	movl	%ebx, 0x10(%rsp)
    1758:      	movl	%r15d, 0x14(%rsp)
    175d:      	movl	%r14d, 0x18(%rsp)
    1762:      	shrq	$0x20, %r14
    1766:      	movl	%r14d, 0x1c(%rsp)
    176b:      	leaq	0xc(%rsp), %rsi
    1770:      	movl	$0x1, %eax
    1775:      	callq	*%rax
    1777:      	movl	0x4(%r12), %ecx
    177c:      	leal	-0x18(%rcx), %edx
    177f:      	cmpl	$0x2, %edx
    1782:      	jb	0x17c6 <filter_inet+0x316>
    1784:      	addl	$-0xd, %ecx
    1787:      	cmpl	$0x1, %ecx
    178a:      	ja	0x1797 <filter_inet+0x2e7>
    178c:      	testq	%rax, %rax
    178f:      	setne	%al
    1792:      	movzbl	%al, %eax
    1795:      	jmp	0x17ad <filter_inet+0x2fd>
    1797:      	xorl	%eax, %eax
    1799:      	movzbl	%al, %eax
    179c:      	jmp	0x17ad <filter_inet+0x2fd>
    179e:      	movzwl	0x26(%rsi), %eax
    17a2:      	movl	%eax, (%rsp)
    17a5:      	movq	%rsp, %rsi
    17a8:      	callq	0x800 <filter_32ty_map>
    17ad:      	addq	$0x48, %rsp
    17b1:      	popq	%rbx
    17b2:      	popq	%r12
    17b4:      	popq	%r14
    17b6:      	popq	%r15
    17b8:      	retq
    17b9:      	movl	0x4(%r12), %eax
    17be:      	andl	$-0x2, %eax
    17c1:      	cmpl	$0x18, %eax
    17c4:      	jmp	0x17c9 <filter_inet+0x319>
    17c6:      	testq	%rax, %rax
    17c9:      	sete	%al
    17cc:      	movzbl	%al, %eax
    17cf:      	jmp	0x17ad <filter_inet+0x2fd>
    17d1:      	cmpl	$0x29, %edx
    17d4:      	jne	0x17e3 <filter_inet+0x333>
    17d6:      	testq	%r8, %r8
    17d9:      	je	0x17e3 <filter_inet+0x333>
    17db:      	movzbl	0x3a(%r8), %eax
    17e0:      	movl	%eax, (%rsp)
    17e3:      	cmpl	$0x29, %edx
    17e6:      	je	0x17a5 <filter_inet+0x2f5>
    17e8:      	cmpl	$0x7, %edx
    17eb:      	je	0x17a5 <filter_inet+0x2f5>
    17ed:      	xorl	%eax, %eax
    17ef:      	jmp	0x17ad <filter_inet+0x2fd>
    17f1:      	nopw	%cs:(%rax,%rax)

0000000000001800 <filter_sockaddr_un>:
    1800:      	pushq	%rbx
    1801:      	subq	$0x10, %rsp
    1805:      	movq	%rsi, %rcx
    1808:      	addq	$0x4, %rsi
    180c:      	movzbl	0x3(%rcx), %edx
    1810:      	movl	0x4(%rdi), %r8d
    1814:      	xorl	%eax, %eax
    1816:      	cmpl	$0x19, %r8d
    181a:      	jg	0x1850 <filter_sockaddr_un+0x50>
    181c:      	leal	-0x3(%r8), %ecx
    1820:      	cmpl	$0x2, %ecx
    1823:      	jae	0x185e <filter_sockaddr_un+0x5e>
    1825:      	movq	%rdi, %rbx
    1828:      	callq	0x18b0 <filter_char_buf_equal>
    182d:      	movl	0x4(%rbx), %ecx
    1830:      	cmpq	$0x25, %rcx
    1834:      	ja	0x184a <filter_sockaddr_un+0x4a>
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x184a <filter_sockaddr_un+0x4a>
    1846:      	xorq	$0x1, %rax
    184a:      	addq	$0x10, %rsp
    184e:      	popq	%rbx
    184f:      	retq
    1850:      	cmpl	$0x1c, %r8d
    1854:      	je	0x1894 <filter_sockaddr_un+0x94>
    1856:      	cmpl	$0x1a, %r8d
    185a:      	je	0x1864 <filter_sockaddr_un+0x64>
    185c:      	jmp	0x184a <filter_sockaddr_un+0x4a>
    185e:      	cmpl	$0x8, %r8d
    1862:      	jne	0x184a <filter_sockaddr_un+0x4a>
    1864:      	movl	0x10(%rdi), %eax
    1867:      	movq	%rdi, %rbx
    186a:      	movl	%eax, %edi
    186c:      	callq	0x1c30 <filter_char_buf_prefix>
    1871:      	movl	0x4(%rbx), %ecx
    1874:      	cmpq	$0x25, %rcx
    1878:      	ja	0x184a <filter_sockaddr_un+0x4a>
    187a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1884:      	btq	%rcx, %rdx
    1888:      	jae	0x184a <filter_sockaddr_un+0x4a>
    188a:      	xorq	$0x1, %rax
    188e:      	addq	$0x10, %rsp
    1892:      	popq	%rbx
    1893:      	retq
    1894:      	movzwl	(%rcx), %eax
    1897:      	movl	%eax, 0xc(%rsp)
    189b:      	leaq	0xc(%rsp), %rsi
    18a0:      	callq	0x800 <filter_32ty_map>
    18a5:      	addq	$0x10, %rsp
    18a9:      	popq	%rbx
    18aa:      	retq
    18ab:      	nopl	(%rax,%rax)

00000000000018b0 <filter_char_buf_equal>:
    18b0:      	pushq	%rbp
    18b1:      	pushq	%r15
    18b3:      	pushq	%r14
    18b5:      	pushq	%r13
    18b7:      	pushq	%r12
    18b9:      	pushq	%rbx
    18ba:      	subq	$0x28, %rsp
    18be:      	movl	$0x0, 0x14(%rsp)
    18c6:      	cmpl	$0x1000, %edx           # imm = 0x1000
    18cc:      	ja	0x1c1e <filter_char_buf_equal+0x36e>
    18d2:      	movl	%edx, %ebp
    18d4:      	movzwl	%bp, %eax
    18d7:      	cmpl	$0x90, %eax
    18dc:      	ja	0x1925 <filter_char_buf_equal+0x75>
    18de:      	testw	%bp, %bp
    18e1:      	je	0x18f4 <filter_char_buf_equal+0x44>
    18e3:      	movl	$0x18, %ecx
    18e8:      	movl	%ebp, %eax
    18ea:      	cltd
    18eb:      	idivl	%ecx
    18ed:      	movl	%ebp, %r14d
    18f0:      	testl	%edx, %edx
    18f2:      	je	0x1914 <filter_char_buf_equal+0x64>
    18f4:      	movl	$0x18, %ecx
    18f9:      	movl	%ebp, %eax
    18fb:      	cltd
    18fc:      	idivl	%ecx
    18fe:      	shll	$0x3, %eax
    1901:      	leal	(%rax,%rax,2), %eax
    1904:      	addl	$0x18, %eax
    1907:      	movzwl	%ax, %r14d
    190b:      	cmpl	$0x90, %r14d
    1912:      	ja	0x1963 <filter_char_buf_equal+0xb3>
    1914:      	movl	%r14d, %eax
    1917:      	cltd
    1918:      	idivl	%ecx
    191a:      	movl	%eax, %r15d
    191d:      	decl	%r15d
    1920:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1925:      	movl	$0x100, %r14d           # imm = 0x100
    192b:      	cmpl	$0x101, %eax            # imm = 0x101
    1930:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    1932:      	movl	$0x200, %r14d           # imm = 0x200
    1938:      	cmpl	$0x201, %eax            # imm = 0x201
    193d:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    193f:      	movl	$0x400, %r14d           # imm = 0x400
    1945:      	cmpl	$0x401, %eax            # imm = 0x401
    194a:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    194c:      	xorl	%r14d, %r14d
    194f:      	cmpl	$0x801, %eax            # imm = 0x801
    1954:      	setae	%r14b
    1958:      	shll	$0xb, %r14d
    195c:      	addl	$0x800, %r14d           # imm = 0x800
    1963:      	leal	-0x100(%r14), %eax
    196a:      	rorxl	$0x8, %eax, %eax
    1970:      	cmpl	$0x2, %eax
    1973:      	jg	0x1986 <filter_char_buf_equal+0xd6>
    1975:      	testl	%eax, %eax
    1977:      	je	0x19a0 <filter_char_buf_equal+0xf0>
    1979:      	cmpl	$0x1, %eax
    197c:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    197e:      	movl	$0x7, %r15d
    1984:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1986:      	cmpl	$0x3, %eax
    1989:      	je	0x19a8 <filter_char_buf_equal+0xf8>
    198b:      	cmpl	$0x7, %eax
    198e:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    1990:      	movl	$0x9, %r15d
    1996:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1998:      	movl	$0xa, %r15d
    199e:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a0:      	movl	$0x6, %r15d
    19a6:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a8:      	movl	$0x8, %r15d
    19ae:      	movl	%r15d, %eax
    19b1:      	andl	$0xf, %eax
    19b4:      	movl	0x10(%rdi,%rax,4), %r13d
    19b9:      	cmpl	$-0x1, %r13d
    19bd:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    19c3:      	movq	%rsi, 0x20(%rsp)
    19c8:      	movq	(%rip), %rdi            # 0x19cf <filter_char_buf_equal+0x11f>
    19cf:      	leaq	0x14(%rsp), %r12
    19d4:      	movl	$0x1, %eax
    19d9:      	movq	%r12, %rsi
    19dc:      	callq	*%rax
    19de:      	movq	%rax, %rbx
    19e1:      	movq	(%rip), %rdi            # 0x19e8 <filter_char_buf_equal+0x138>
    19e8:      	movl	$0x1, %eax
    19ed:      	movq	%r12, %rsi
    19f0:      	callq	*%rax
    19f2:      	movq	%rax, %rcx
    19f5:      	xorl	%eax, %eax
    19f7:      	movq	%rbx, 0x8(%rsp)
    19fc:      	testq	%rbx, %rbx
    19ff:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a05:      	testq	%rcx, %rcx
    1a08:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a0e:      	movq	%rcx, 0x18(%rsp)
    1a13:      	cmpl	$0x5, %r15d
    1a17:      	jg	0x1a5a <filter_char_buf_equal+0x1aa>
    1a19:      	movq	0x8(%rsp), %rax
    1a1e:      	movb	%bpl, (%rax)
    1a21:      	leaq	0x1(%rax), %rdi
    1a25:      	movl	%ebp, %r12d
    1a28:      	movl	$0x4, %eax
    1a2d:      	movq	0x20(%rsp), %rdx
    1a32:      	movl	%ebp, %esi
    1a34:      	callq	*%rax
    1a36:      	subl	%ebp, %r14d
    1a39:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a3b:      	movq	0x8(%rsp), %rax
    1a40:      	leaq	(%rax,%r12), %rdi
    1a44:      	incq	%rdi
    1a47:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a4e:      	movl	$0x4, %eax
    1a53:      	movq	0x18(%rsp), %rdx
    1a58:      	jmp	0x1a9a <filter_char_buf_equal+0x1ea>
    1a5a:      	movq	0x8(%rsp), %rax
    1a5f:      	movw	%bp, (%rax)
    1a62:      	leaq	0x2(%rax), %rdi
    1a66:      	movl	%ebp, %r12d
    1a69:      	movl	$0x4, %eax
    1a6e:      	movq	0x20(%rsp), %rdx
    1a73:      	movl	%ebp, %esi
    1a75:      	callq	*%rax
    1a77:      	subl	%ebp, %r14d
    1a7a:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a7c:      	movq	0x8(%rsp), %rax
    1a81:      	leaq	(%rax,%r12), %rdi
    1a85:      	addq	$0x2, %rdi
    1a89:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a90:      	movl	$0x4, %eax
    1a95:      	movq	0x18(%rsp), %rdx
    1a9a:      	movl	%r14d, %esi
    1a9d:      	callq	*%rax
    1a9f:      	movl	%r13d, 0x4(%rsp)
    1aa4:      	cmpl	$0x4, %r15d
    1aa8:      	jle	0x1ae4 <filter_char_buf_equal+0x234>
    1aaa:      	cmpl	$0x7, %r15d
    1aae:      	jg	0x1b1e <filter_char_buf_equal+0x26e>
    1ab0:      	cmpl	$0x5, %r15d
    1ab4:      	je	0x1bd2 <filter_char_buf_equal+0x322>
    1aba:      	cmpl	$0x6, %r15d
    1abe:      	je	0x1b99 <filter_char_buf_equal+0x2e9>
    1ac4:      	cmpl	$0x7, %r15d
    1ac8:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1ace:      	movq	(%rip), %rdi            # 0x1ad5 <filter_char_buf_equal+0x225>
    1ad5:      	leaq	0x4(%rsp), %rcx
    1ada:      	movl	$0x1, %eax
    1adf:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1ae4:      	cmpl	$0x1, %r15d
    1ae8:      	jle	0x1b4e <filter_char_buf_equal+0x29e>
    1aea:      	cmpl	$0x2, %r15d
    1aee:      	je	0x1bbf <filter_char_buf_equal+0x30f>
    1af4:      	cmpl	$0x3, %r15d
    1af8:      	je	0x1b86 <filter_char_buf_equal+0x2d6>
    1afe:      	cmpl	$0x4, %r15d
    1b02:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b08:      	movq	(%rip), %rdi            # 0x1b0f <filter_char_buf_equal+0x25f>
    1b0f:      	leaq	0x4(%rsp), %rcx
    1b14:      	movl	$0x1, %eax
    1b19:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b1e:      	cmpl	$0x8, %r15d
    1b22:      	je	0x1be5 <filter_char_buf_equal+0x335>
    1b28:      	cmpl	$0x9, %r15d
    1b2c:      	je	0x1bac <filter_char_buf_equal+0x2fc>
    1b2e:      	cmpl	$0xa, %r15d
    1b32:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b38:      	movq	(%rip), %rdi            # 0x1b3f <filter_char_buf_equal+0x28f>
    1b3f:      	leaq	0x4(%rsp), %rcx
    1b44:      	movl	$0x1, %eax
    1b49:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b4e:      	testl	%r15d, %r15d
    1b51:      	je	0x1b73 <filter_char_buf_equal+0x2c3>
    1b53:      	cmpl	$0x1, %r15d
    1b57:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b5d:      	movq	(%rip), %rdi            # 0x1b64 <filter_char_buf_equal+0x2b4>
    1b64:      	leaq	0x4(%rsp), %rcx
    1b69:      	movl	$0x1, %eax
    1b6e:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b73:      	movq	(%rip), %rdi            # 0x1b7a <filter_char_buf_equal+0x2ca>
    1b7a:      	leaq	0x4(%rsp), %rcx
    1b7f:      	movl	$0x1, %eax
    1b84:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b86:      	movq	(%rip), %rdi            # 0x1b8d <filter_char_buf_equal+0x2dd>
    1b8d:      	leaq	0x4(%rsp), %rcx
    1b92:      	movl	$0x1, %eax
    1b97:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b99:      	movq	(%rip), %rdi            # 0x1ba0 <filter_char_buf_equal+0x2f0>
    1ba0:      	leaq	0x4(%rsp), %rcx
    1ba5:      	movl	$0x1, %eax
    1baa:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bac:      	movq	(%rip), %rdi            # 0x1bb3 <filter_char_buf_equal+0x303>
    1bb3:      	leaq	0x4(%rsp), %rcx
    1bb8:      	movl	$0x1, %eax
    1bbd:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bbf:      	movq	(%rip), %rdi            # 0x1bc6 <filter_char_buf_equal+0x316>
    1bc6:      	leaq	0x4(%rsp), %rcx
    1bcb:      	movl	$0x1, %eax
    1bd0:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bd2:      	movq	(%rip), %rdi            # 0x1bd9 <filter_char_buf_equal+0x329>
    1bd9:      	leaq	0x4(%rsp), %rcx
    1bde:      	movl	$0x1, %eax
    1be3:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1be5:      	movq	(%rip), %rdi            # 0x1bec <filter_char_buf_equal+0x33c>
    1bec:      	leaq	0x4(%rsp), %rcx
    1bf1:      	movl	$0x1, %eax
    1bf6:      	leaq	0x4(%rsp), %rsi
    1bfb:      	callq	*%rax
    1bfd:      	testq	%rax, %rax
    1c00:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    1c02:      	movq	%rax, %rdi
    1c05:      	movl	$0x1, %eax
    1c0a:      	movq	0x8(%rsp), %rsi
    1c0f:      	callq	*%rax
    1c11:      	movq	%rax, %rcx
    1c14:      	xorl	%eax, %eax
    1c16:      	testq	%rcx, %rcx
    1c19:      	setne	%al
    1c1c:      	jmp	0x1c20 <filter_char_buf_equal+0x370>
    1c1e:      	xorl	%eax, %eax
    1c20:      	addq	$0x28, %rsp
    1c24:      	popq	%rbx
    1c25:      	popq	%r12
    1c27:      	popq	%r13
    1c29:      	popq	%r14
    1c2b:      	popq	%r15
    1c2d:      	popq	%rbp
    1c2e:      	retq
    1c2f:      	nop

0000000000001c30 <filter_char_buf_prefix>:
    1c30:      	pushq	%rbp
    1c31:      	pushq	%r15
    1c33:      	pushq	%r14
    1c35:      	pushq	%rbx
    1c36:      	pushq	%rax
    1c37:      	movl	%edx, %ebp
    1c39:      	movq	%rsi, %rbx
    1c3c:      	movl	%edi, 0x4(%rsp)
    1c40:      	movl	$0x0, (%rsp)
    1c47:      	movq	(%rip), %rdi            # 0x1c4e <filter_char_buf_prefix+0x1e>
    1c4e:      	leaq	0x4(%rsp), %rsi
    1c53:      	movl	$0x1, %eax
    1c58:      	callq	*%rax
    1c5a:      	movq	%rax, %r14
    1c5d:      	xorl	%eax, %eax
    1c5f:      	testl	%ebp, %ebp
    1c61:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c63:      	testq	%r14, %r14
    1c66:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c68:      	movq	(%rip), %rdi            # 0x1c6f <filter_char_buf_prefix+0x3f>
    1c6f:      	movq	%rsp, %rsi
    1c72:      	movl	$0x1, %eax
    1c77:      	callq	*%rax
    1c79:      	testq	%rax, %rax
    1c7c:      	je	0x1cc3 <filter_char_buf_prefix+0x93>
    1c7e:      	cmpl	$0xff, %ebp
    1c84:      	movl	$0xff, %esi
    1c89:      	cmovbl	%ebp, %esi
    1c8c:      	leal	(,%rsi,8), %ecx
    1c93:      	movl	%ecx, (%rax)
    1c95:      	movq	%rax, %rdi
    1c98:      	addq	$0x4, %rdi
    1c9c:      	movq	%rax, %r15
    1c9f:      	movl	$0x4, %eax
    1ca4:      	movq	%rbx, %rdx
    1ca7:      	callq	*%rax
    1ca9:      	movl	$0x1, %eax
    1cae:      	movq	%r14, %rdi
    1cb1:      	movq	%r15, %rsi
    1cb4:      	callq	*%rax
    1cb6:      	movq	%rax, %rcx
    1cb9:      	xorl	%eax, %eax
    1cbb:      	testq	%rcx, %rcx
    1cbe:      	setne	%al
    1cc1:      	jmp	0x1cc5 <filter_char_buf_prefix+0x95>
    1cc3:      	xorl	%eax, %eax
    1cc5:      	addq	$0x8, %rsp
    1cc9:      	popq	%rbx
    1cca:      	popq	%r14
    1ccc:      	popq	%r15
    1cce:      	popq	%rbp
    1ccf:      	retq

0000000000001cd0 <filter_char_buf_postfix>:
    1cd0:      	pushq	%r15
    1cd2:      	pushq	%r14
    1cd4:      	pushq	%rbx
    1cd5:      	subq	$0x10, %rsp
    1cd9:      	movl	%edx, %ebx
    1cdb:      	movq	%rsi, %r14
    1cde:      	movl	%edi, 0xc(%rsp)
    1ce2:      	movl	$0x0, 0x8(%rsp)
    1cea:      	movq	(%rip), %rdi            # 0x1cf1 <filter_char_buf_postfix+0x21>
    1cf1:      	leaq	0xc(%rsp), %rsi
    1cf6:      	movl	$0x1, %eax
    1cfb:      	callq	*%rax
    1cfd:      	movq	%rax, %r15
    1d00:      	xorl	%eax, %eax
    1d02:      	testl	%ebx, %ebx
    1d04:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d0a:      	testq	%r15, %r15
    1d0d:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d13:      	movq	(%rip), %rdi            # 0x1d1a <filter_char_buf_postfix+0x4a>
    1d1a:      	leaq	0x8(%rsp), %rsi
    1d1f:      	movl	$0x1, %eax
    1d24:      	callq	*%rax
    1d26:      	testq	%rax, %rax
    1d29:      	je	0x1e0e <filter_char_buf_postfix+0x13e>
    1d2f:      	movq	%rax, %rsi
    1d32:      	cmpl	$0x7f, %ebx
    1d35:      	movl	$0x7f, %eax
    1d3a:      	cmovbl	%ebx, %eax
    1d3d:      	shll	$0x3, %eax
    1d40:      	movl	%eax, (%rsi)
    1d42:      	movl	%ebx, %eax
    1d44:      	leal	-0x4(%rbx), %ecx
    1d47:      	movq	%rsi, %rdx
    1d4a:      	addq	$0x7, %rdx
    1d4e:      	leal	-0x3(%rbx), %edi
    1d51:      	leal	-0x2(%rbx), %r8d
    1d55:      	decl	%ebx
    1d57:      	movq	$-0x3, %r9
    1d5e:      	nop
    1d60:      	leal	(%rbx,%r9), %r10d
    1d64:      	addl	$0x3, %r10d
    1d68:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1d6f:      	movzbl	(%r14,%r10), %r10d
    1d74:      	movb	%r10b, -0x3(%rdx)
    1d78:      	leaq	(%rax,%r9), %r10
    1d7c:      	cmpq	$-0x2, %r10
    1d80:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1d82:      	leal	(%r8,%r9), %r11d
    1d86:      	addl	$0x3, %r11d
    1d8a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1d91:      	movzbl	(%r14,%r11), %r11d
    1d96:      	movb	%r11b, -0x2(%rdx)
    1d9a:      	cmpq	$-0x1, %r10
    1d9e:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1da0:      	leal	(%rdi,%r9), %r10d
    1da4:      	addl	$0x3, %r10d
    1da8:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1daf:      	movzbl	(%r14,%r10), %r10d
    1db4:      	movb	%r10b, -0x1(%rdx)
    1db8:      	movq	%rax, %r10
    1dbb:      	addq	%r9, %r10
    1dbe:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc0:      	cmpq	$-0x7f, %r9
    1dc4:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc6:      	leal	(%rcx,%r9), %r10d
    1dca:      	addl	$0x3, %r10d
    1dce:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1dd5:      	movzbl	(%r14,%r10), %r10d
    1dda:      	movb	%r10b, (%rdx)
    1ddd:      	addq	$0x4, %rdx
    1de1:      	leaq	(%rax,%r9), %r10
    1de5:      	addq	$-0x4, %r10
    1de9:      	addq	$-0x4, %r9
    1ded:      	cmpq	$-0x3, %r10
    1df1:      	jne	0x1d60 <filter_char_buf_postfix+0x90>
    1df7:      	movl	$0x1, %eax
    1dfc:      	movq	%r15, %rdi
    1dff:      	callq	*%rax
    1e01:      	movq	%rax, %rcx
    1e04:      	xorl	%eax, %eax
    1e06:      	testq	%rcx, %rcx
    1e09:      	setne	%al
    1e0c:      	jmp	0x1e10 <filter_char_buf_postfix+0x140>
    1e0e:      	xorl	%eax, %eax
    1e10:      	addq	$0x10, %rsp
    1e14:      	popq	%rbx
    1e15:      	popq	%r14
    1e17:      	popq	%r15
    1e19:      	retq
    1e1a:      	nopw	(%rax,%rax)

0000000000001e20 <filter_file_type>:
    1e20:      	pushq	%rbx
    1e21:      	subq	$0x10, %rsp
    1e25:      	movw	$0x0, 0xe(%rsp)
    1e2c:      	movl	(%rsi), %eax
    1e2e:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1e34:      	ja	0x1ebc <filter_file_type+0x9c>
    1e3a:      	movq	%rdi, %rbx
    1e3d:      	leaq	(%rsi,%rax), %rcx
    1e41:      	addq	$0x8, %rcx
    1e45:      	leaq	0xe(%rsp), %rdi
    1e4a:      	movl	$0x2, %edx
    1e4f:      	movl	$0x4, %eax
    1e54:      	movl	(%rsi), %ecx
    1e56:      	leaq	(%rsi,%rcx), %rdx
    1e5a:      	addq	$0x8, %rdx
    1e5e:      	movl	$0x2, %esi
    1e63:      	callq	*%rax
    1e65:      	movl	0x10(%rbx), %edx
    1e68:      	testl	%edx, %edx
    1e6a:      	je	0x1ebc <filter_file_type+0x9c>
    1e6c:      	movzwl	0xe(%rsp), %ecx
    1e71:      	andl	$0xf000, %ecx           # imm = 0xF000
    1e77:      	movl	$0x1, %eax
    1e7c:      	cmpl	%ecx, %edx
    1e7e:      	je	0x1ebe <filter_file_type+0x9e>
    1e80:      	movl	0x8(%rbx), %edx
    1e83:      	cmpl	$0xc, %edx
    1e86:      	jbe	0x1ebc <filter_file_type+0x9c>
    1e88:      	movl	0x14(%rbx), %esi
    1e8b:      	testl	%esi, %esi
    1e8d:      	je	0x1ebc <filter_file_type+0x9c>
    1e8f:      	cmpl	%ecx, %esi
    1e91:      	je	0x1ebe <filter_file_type+0x9e>
    1e93:      	cmpl	$0x11, %edx
    1e96:      	jb	0x1ebc <filter_file_type+0x9c>
    1e98:      	movl	0x18(%rbx), %esi
    1e9b:      	testl	%esi, %esi
    1e9d:      	je	0x1ebc <filter_file_type+0x9c>
    1e9f:      	cmpl	%ecx, %esi
    1ea1:      	je	0x1ebe <filter_file_type+0x9e>
    1ea3:      	cmpl	$0x15, %edx
    1ea6:      	jb	0x1ebc <filter_file_type+0x9c>
    1ea8:      	movl	0x1c(%rbx), %edx
    1eab:      	testl	%edx, %edx
    1ead:      	je	0x1ebc <filter_file_type+0x9c>
    1eaf:      	xorl	%eax, %eax
    1eb1:      	cmpl	%ecx, %edx
    1eb3:      	sete	%al
    1eb6:      	addq	$0x10, %rsp
    1eba:      	popq	%rbx
    1ebb:      	retq
    1ebc:      	xorl	%eax, %eax
    1ebe:      	addq	$0x10, %rsp
    1ec2:      	popq	%rbx
    1ec3:      	retq
    1ec4:      	nopw	%cs:(%rax,%rax)

0000000000001ed0 <filter_char_substring>:
    1ed0:      	pushq	%rbp
    1ed1:      	pushq	%r15
    1ed3:      	pushq	%r14
    1ed5:      	pushq	%r13
    1ed7:      	pushq	%r12
    1ed9:      	pushq	%rbx
    1eda:      	pushq	%rax
    1edb:      	movq	%rsi, %r15
    1ede:      	movq	%rdi, %r14
    1ee1:      	movl	%edx, %ebp
    1ee3:      	testl	%ecx, %ecx
    1ee5:      	je	0x1fbd <filter_char_substring+0xed>
    1eeb:      	testl	%edx, %edx
    1eed:      	je	0x206d <filter_char_substring+0x19d>
    1ef3:      	leaq	0x4(%rsp), %r13
    1ef8:      	xorl	%ebx, %ebx
    1efa:      	xorl	%r12d, %r12d
    1efd:      	nopl	(%rax)
    1f00:      	movl	0x10(%r14,%rbx,4), %eax
    1f05:      	movl	%eax, 0x4(%rsp)
    1f09:      	movl	$0x1, %eax
    1f0e:      	movq	(%rip), %rdi            # 0x1f15 <filter_char_substring+0x45>
    1f15:      	movq	%r13, %rsi
    1f18:      	callq	*%rax
    1f1a:      	testq	%rax, %rax
    1f1d:      	je	0x2100 <filter_char_substring+0x230>
    1f23:      	movq	%r15, %rdx
    1f26:      	xorl	%ecx, %ecx
    1f28:      	jmp	0x1f3b <filter_char_substring+0x6b>
    1f2a:      	nopw	(%rax,%rax)
    1f30:      	incq	%rcx
    1f33:      	incq	%rdx
    1f36:      	cmpq	%rbp, %rcx
    1f39:      	je	0x1f98 <filter_char_substring+0xc8>
    1f3b:      	xorl	%esi, %esi
    1f3d:      	nopl	(%rax)
    1f40:      	leaq	(%rcx,%rsi), %rdi
    1f44:      	cmpq	%rbp, %rdi
    1f47:      	jae	0x1f30 <filter_char_substring+0x60>
    1f49:      	movsbl	(%rax,%rsi), %edi
    1f4d:      	testl	%edi, %edi
    1f4f:      	je	0x1f90 <filter_char_substring+0xc0>
    1f51:      	movsbl	(%rdx,%rsi), %r9d
    1f56:      	leal	-0x41(%r9), %r10d
    1f5a:      	movl	%r9d, %r8d
    1f5d:      	orl	$0x20, %r8d
    1f61:      	cmpl	$0x1a, %r10d
    1f65:      	cmovael	%r9d, %r8d
    1f69:      	leal	-0x41(%rdi), %r10d
    1f6d:      	movl	%edi, %r9d
    1f70:      	orl	$0x20, %r9d
    1f74:      	cmpl	$0x1a, %r10d
    1f78:      	cmovael	%edi, %r9d
    1f7c:      	cmpq	$0x62, %rsi
    1f80:      	ja	0x1f30 <filter_char_substring+0x60>
    1f82:      	incq	%rsi
    1f85:      	cmpl	%r9d, %r8d
    1f88:      	je	0x1f40 <filter_char_substring+0x70>
    1f8a:      	jmp	0x1f30 <filter_char_substring+0x60>
    1f8c:      	nopl	(%rax)
    1f90:      	testl	%ecx, %ecx
    1f92:      	jns	0x2111 <filter_char_substring+0x241>
    1f98:      	leal	0xc(%r12), %eax
    1f9d:      	cmpl	0x8(%r14), %eax
    1fa1:      	jae	0x2100 <filter_char_substring+0x230>
    1fa7:      	addl	$0x4, %r12d
    1fab:      	incq	%rbx
    1fae:      	cmpq	$0x64, %rbx
    1fb2:      	jne	0x1f00 <filter_char_substring+0x30>
    1fb8:      	jmp	0x2100 <filter_char_substring+0x230>
    1fbd:      	testl	%edx, %edx
    1fbf:      	je	0x20b2 <filter_char_substring+0x1e2>
    1fc5:      	leaq	0x4(%rsp), %r13
    1fca:      	xorl	%ebx, %ebx
    1fcc:      	xorl	%r12d, %r12d
    1fcf:      	nop
    1fd0:      	movl	0x10(%r14,%rbx,4), %eax
    1fd5:      	movl	%eax, 0x4(%rsp)
    1fd9:      	movl	$0x1, %eax
    1fde:      	movq	(%rip), %rdi            # 0x1fe5 <filter_char_substring+0x115>
    1fe5:      	movq	%r13, %rsi
    1fe8:      	callq	*%rax
    1fea:      	testq	%rax, %rax
    1fed:      	je	0x2100 <filter_char_substring+0x230>
    1ff3:      	movq	%r15, %rdx
    1ff6:      	xorl	%ecx, %ecx
    1ff8:      	jmp	0x200b <filter_char_substring+0x13b>
    1ffa:      	nopw	(%rax,%rax)
    2000:      	incq	%rcx
    2003:      	incq	%rdx
    2006:      	cmpq	%rbp, %rcx
    2009:      	je	0x2048 <filter_char_substring+0x178>
    200b:      	xorl	%esi, %esi
    200d:      	nopl	(%rax)
    2010:      	leaq	(%rcx,%rsi), %rdi
    2014:      	cmpq	%rbp, %rdi
    2017:      	jae	0x2000 <filter_char_substring+0x130>
    2019:      	movzbl	(%rax,%rsi), %edi
    201d:      	testb	%dil, %dil
    2020:      	je	0x2040 <filter_char_substring+0x170>
    2022:      	cmpq	$0x62, %rsi
    2026:      	ja	0x2000 <filter_char_substring+0x130>
    2028:      	leaq	0x1(%rsi), %r8
    202c:      	cmpb	%dil, (%rdx,%rsi)
    2030:      	movq	%r8, %rsi
    2033:      	je	0x2010 <filter_char_substring+0x140>
    2035:      	jmp	0x2000 <filter_char_substring+0x130>
    2037:      	nopw	(%rax,%rax)
    2040:      	testl	%ecx, %ecx
    2042:      	jns	0x2111 <filter_char_substring+0x241>
    2048:      	leal	0xc(%r12), %eax
    204d:      	cmpl	0x8(%r14), %eax
    2051:      	jae	0x2100 <filter_char_substring+0x230>
    2057:      	addl	$0x4, %r12d
    205b:      	incq	%rbx
    205e:      	cmpq	$0x64, %rbx
    2062:      	jne	0x1fd0 <filter_char_substring+0x100>
    2068:      	jmp	0x2100 <filter_char_substring+0x230>
    206d:      	movl	$0x10, %ebx
    2072:      	movq	(%rip), %r15            # 0x2079 <filter_char_substring+0x1a9>
    2079:      	leaq	0x4(%rsp), %r12
    207e:      	nop
    2080:      	movl	(%r14,%rbx), %eax
    2084:      	movl	%eax, 0x4(%rsp)
    2088:      	movl	$0x1, %eax
    208d:      	movq	%r15, %rdi
    2090:      	movq	%r12, %rsi
    2093:      	callq	*%rax
    2095:      	testq	%rax, %rax
    2098:      	je	0x2100 <filter_char_substring+0x230>
    209a:      	addq	$0x4, %rbx
    209e:      	leal	-0x8(%rbx), %eax
    20a1:      	cmpl	0x8(%r14), %eax
    20a5:      	jae	0x2100 <filter_char_substring+0x230>
    20a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20ae:      	jne	0x2080 <filter_char_substring+0x1b0>
    20b0:      	jmp	0x2100 <filter_char_substring+0x230>
    20b2:      	movl	$0x10, %ebx
    20b7:      	movq	(%rip), %r15            # 0x20be <filter_char_substring+0x1ee>
    20be:      	leaq	0x4(%rsp), %r12
    20c3:      	nopw	%cs:(%rax,%rax)
    20d0:      	movl	(%r14,%rbx), %eax
    20d4:      	movl	%eax, 0x4(%rsp)
    20d8:      	movl	$0x1, %eax
    20dd:      	movq	%r15, %rdi
    20e0:      	movq	%r12, %rsi
    20e3:      	callq	*%rax
    20e5:      	testq	%rax, %rax
    20e8:      	je	0x2100 <filter_char_substring+0x230>
    20ea:      	addq	$0x4, %rbx
    20ee:      	leal	-0x8(%rbx), %eax
    20f1:      	cmpl	0x8(%r14), %eax
    20f5:      	jae	0x2100 <filter_char_substring+0x230>
    20f7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20fe:      	jne	0x20d0 <filter_char_substring+0x200>
    2100:      	xorl	%eax, %eax
    2102:      	addq	$0x8, %rsp
    2106:      	popq	%rbx
    2107:      	popq	%r12
    2109:      	popq	%r13
    210b:      	popq	%r14
    210d:      	popq	%r15
    210f:      	popq	%rbp
    2110:      	retq
    2111:      	movl	$0x1, %eax
    2116:      	jmp	0x2102 <filter_char_substring+0x232>
    2118:      	nopl	(%rax,%rax)

0000000000002120 <do_action>:
    2120:      	pushq	%rbp
    2121:      	pushq	%r15
    2123:      	pushq	%r14
    2125:      	pushq	%r13
    2127:      	pushq	%r12
    2129:      	pushq	%rbx
    212a:      	subq	$0x78, %rsp
    212e:      	movl	%r8d, %ebp
    2131:      	movq	%rcx, 0x38(%rsp)
    2136:      	movq	%rdx, %r15
    2139:      	movl	%esi, %ebx
    213b:      	movq	%rdi, %r14
    213e:      	movl	%esi, %eax
    2140:      	movslq	0x4(%rdx,%rax,4), %r12
    2145:      	movl	$0x0, 0x50(%rsp)
    214d:      	movq	(%rip), %rdi            # 0x2154 <do_action+0x34>
    2154:      	leaq	0x50(%rsp), %rsi
    2159:      	movl	$0x1, %eax
    215e:      	callq	*%rax
    2160:      	movq	%rax, %r13
    2163:      	xorl	%eax, %eax
    2165:      	testq	%r13, %r13
    2168:      	je	0x2980 <do_action+0x860>
    216e:      	cmpl	$0x7, %r12d
    2172:      	jg	0x219c <do_action+0x7c>
    2174:      	cmpl	$0x3, %r12d
    2178:      	jg	0x21d4 <do_action+0xb4>
    217a:      	cmpl	$0x1, %r12d
    217e:      	jg	0x2307 <do_action+0x1e7>
    2184:      	testl	%r12d, %r12d
    2187:      	je	0x25ac <do_action+0x48c>
    218d:      	cmpl	$0x1, %r12d
    2191:      	je	0x2320 <do_action+0x200>
    2197:      	jmp	0x2978 <do_action+0x858>
    219c:      	cmpl	$0xb, %r12d
    21a0:      	jg	0x22d9 <do_action+0x1b9>
    21a6:      	leal	-0xa(%r12), %ecx
    21ab:      	cmpl	$0x2, %ecx
    21ae:      	jb	0x242b <do_action+0x30b>
    21b4:      	cmpl	$0x8, %r12d
    21b8:      	je	0x2518 <do_action+0x3f8>
    21be:      	cmpl	$0x9, %r12d
    21c2:      	jne	0x2978 <do_action+0x858>
    21c8:      	incl	%ebx
    21ca:      	movl	0x4(%r15,%rbx,4), %eax
    21cf:      	jmp	0x24e4 <do_action+0x3c4>
    21d4:      	leal	-0x6(%r12), %eax
    21d9:      	cmpl	$0x2, %eax
    21dc:      	jb	0x2508 <do_action+0x3e8>
    21e2:      	cmpl	$0x4, %r12d
    21e6:      	je	0x2525 <do_action+0x405>
    21ec:      	cmpl	$0x5, %r12d
    21f0:      	jne	0x2978 <do_action+0x858>
    21f6:      	leal	0x1(%rbx), %eax
    21f9:      	movl	0x4(%r15,%rax,4), %eax
    21fe:      	addl	$0x2, %ebx
    2201:      	andl	$0x7, %eax
    2204:      	cmpl	$0x4, %eax
    2207:      	ja	0x2978 <do_action+0x858>
    220d:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    2216:      	jne	0x2978 <do_action+0x858>
    221c:      	movl	0x4(%r15,%rbx,4), %r14d
    2221:      	movq	0x5e78(%r13,%rax,8), %rax
    2229:      	movl	$0x0, 0xc(%rsp)
    2231:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2236:      	movl	0x90(%r13,%rax), %eax
    223e:      	movl	%eax, 0x8(%rsp)
    2242:      	movl	$0xe, %eax
    2247:      	callq	*%rax
    2249:      	shrq	$0x20, %rax
    224d:      	movq	%rax, (%rsp)
    2251:      	movq	(%rip), %rdi            # 0x2258 <do_action+0x138>
    2258:      	movq	%rsp, %rsi
    225b:      	movl	$0x1, %eax
    2260:      	callq	*%rax
    2262:      	testq	%rax, %rax
    2265:      	je	0x2978 <do_action+0x858>
    226b:      	andl	$0x7, %r14d
    226f:      	cmpl	$0x4, %r14d
    2273:      	ja	0x2978 <do_action+0x858>
    2279:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    2282:      	jne	0x2978 <do_action+0x858>
    2288:      	movq	0x5e78(%r13,%r14,8), %rcx
    2290:      	movl	$0x0, 0xc(%rsp)
    2298:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    229e:      	movl	0x90(%r13,%rcx), %ecx
    22a6:      	movl	%ecx, 0x8(%rsp)
    22aa:      	movq	%rax, %r15
    22ad:      	movl	$0xe, %eax
    22b2:      	callq	*%rax
    22b4:      	shrq	$0x20, %rax
    22b8:      	movq	%rax, (%rsp)
    22bc:      	movq	(%rip), %rdi            # 0x22c3 <do_action+0x1a3>
    22c3:      	xorl	%ecx, %ecx
    22c5:      	movq	%rsp, %rsi
    22c8:      	movl	$0x2, %eax
    22cd:      	movq	%r15, %rdx
    22d0:      	xorl	%ecx, %ecx
    22d2:      	callq	*%rax
    22d4:      	jmp	0x2978 <do_action+0x858>
    22d9:      	cmpl	$0xc, %r12d
    22dd:      	je	0x2668 <do_action+0x548>
    22e3:      	cmpl	$0xd, %r12d
    22e7:      	je	0x2534 <do_action+0x414>
    22ed:      	cmpl	$0xe, %r12d
    22f1:      	jne	0x2978 <do_action+0x858>
    22f7:      	addl	$0x2, %ebx
    22fa:      	movzbl	%bpl, %r14d
    22fe:      	xorq	$0x9, %r14
    2302:      	jmp	0x2673 <do_action+0x553>
    2307:      	movl	$0x9, %eax
    230c:      	cmpl	$0x2, %r12d
    2310:      	je	0x24e4 <do_action+0x3c4>
    2316:      	cmpl	$0x3, %r12d
    231a:      	jne	0x2978 <do_action+0x858>
    2320:      	leal	0x1(%rbx), %eax
    2323:      	movl	0x4(%r15,%rax,4), %ebp
    2328:      	addl	$0x2, %ebx
    232b:      	movl	0x4(%r15,%rbx,4), %r14d
    2330:      	movl	$0x0, 0x10(%rsp)
    2338:      	movq	(%rip), %rdi            # 0x233f <do_action+0x21f>
    233f:      	leaq	0x10(%rsp), %rsi
    2344:      	movl	$0x1, %eax
    2349:      	callq	*%rax
    234b:      	xorl	%r15d, %r15d
    234e:      	testq	%rax, %rax
    2351:      	je	0x272b <do_action+0x60b>
    2357:      	movq	%rax, 0x38(%rsp)
    235c:      	andl	$0x7, %ebp
    235f:      	cmpl	$0x4, %ebp
    2362:      	movl	$0x0, %eax
    2367:      	ja	0x272d <do_action+0x60d>
    236d:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2376:      	jne	0x272d <do_action+0x60d>
    237c:      	movq	0x5e78(%r13,%rbp,8), %rax
    2384:      	movl	$0x0, 0xc(%rsp)
    238c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2391:      	movl	0x90(%r13,%rax), %eax
    2399:      	movl	%eax, 0x8(%rsp)
    239d:      	movl	$0xe, %eax
    23a2:      	callq	*%rax
    23a4:      	shrq	$0x20, %rax
    23a8:      	movq	%rax, (%rsp)
    23ac:      	cmpl	$0x1, %r12d
    23b0:      	jne	0x2704 <do_action+0x5e4>
    23b6:      	andl	$0x7, %r14d
    23ba:      	cmpl	$0x4, %r14d
    23be:      	ja	0x272b <do_action+0x60b>
    23c4:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    23cd:      	movl	$0x0, %eax
    23d2:      	jne	0x272d <do_action+0x60d>
    23d8:      	movq	0x5e78(%r13,%r14,8), %rax
    23e0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    23e5:      	leaq	(%rax,%r13), %rdx
    23e9:      	addq	$0x90, %rdx
    23f0:      	movl	0x90(%r13,%rax), %esi
    23f8:      	andl	$0xfff, %esi            # imm = 0xFFF
    23fe:      	addq	$0x8, %rsi
    2402:      	movl	$0x4, %eax
    2407:      	movq	0x38(%rsp), %r14
    240c:      	movq	%r14, %rdi
    240f:      	callq	*%rax
    2411:      	movq	(%rip), %rdi            # 0x2418 <do_action+0x2f8>
    2418:      	xorl	%r15d, %r15d
    241b:      	movq	%rsp, %rsi
    241e:      	movl	$0x2, %eax
    2423:      	movq	%r14, %rdx
    2426:      	jmp	0x24db <do_action+0x3bb>
    242b:      	incl	%ebx
    242d:      	movl	0x4(%r15,%rbx,4), %ecx
    2432:      	andl	$0x7, %ecx
    2435:      	xorl	%r15d, %r15d
    2438:      	cmpl	$0x4, %ecx
    243b:      	ja	0x272d <do_action+0x60d>
    2441:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    244a:      	jne	0x272d <do_action+0x60d>
    2450:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2458:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    245e:      	movq	0xb8(%r13,%rcx), %rcx
    2466:      	movq	%rcx, 0x10(%rsp)
    246b:      	testq	%rcx, %rcx
    246e:      	je	0x272d <do_action+0x60d>
    2474:      	cmpl	$0xa, %r12d
    2478:      	jne	0x2715 <do_action+0x5f5>
    247e:      	movl	$0xe, %eax
    2483:      	callq	*%rax
    2485:      	movq	%rax, %r14
    2488:      	shrq	$0x20, %rax
    248c:      	movl	%eax, (%rsp)
    248f:      	movq	(%rip), %rdi            # 0x2496 <do_action+0x376>
    2496:      	movq	%rsp, %rsi
    2499:      	movl	$0x1, %eax
    249e:      	callq	*%rax
    24a0:      	movq	%rax, %rcx
    24a3:      	testq	%rax, %rax
    24a6:      	movl	$0x0, %eax
    24ab:      	je	0x272d <do_action+0x60d>
    24b1:      	movl	(%rcx), %eax
    24b3:      	movl	%eax, (%rsp)
    24b6:      	movl	%r14d, 0x4(%rsp)
    24bb:      	movq	0x8(%rcx), %rax
    24bf:      	movq	%rax, 0x8(%rsp)
    24c4:      	movq	(%rip), %rdi            # 0x24cb <do_action+0x3ab>
    24cb:      	xorl	%r15d, %r15d
    24ce:      	leaq	0x10(%rsp), %rsi
    24d3:      	movq	%rsp, %rdx
    24d6:      	movl	$0x2, %eax
    24db:      	xorl	%ecx, %ecx
    24dd:      	callq	*%rax
    24df:      	jmp	0x272b <do_action+0x60b>
    24e4:      	movl	$0x3, %r14d
    24ea:      	testb	%bpl, %bpl
    24ed:      	je	0x2673 <do_action+0x553>
    24f3:      	movslq	%eax, %rdi
    24f6:      	movl	$0x6d, %eax
    24fb:      	callq	*%rax
    24fd:      	movl	$0x2, %r14d
    2503:      	jmp	0x2673 <do_action+0x553>
    2508:      	incl	%ebx
    250a:      	movl	0x4(%r15,%rbx,4), %eax
    250f:      	movl	%eax, 0x78(%r13)
    2513:      	jmp	0x2978 <do_action+0x858>
    2518:      	movq	0x38(%rsp), %rax
    251d:      	movb	$0x0, (%rax)
    2520:      	jmp	0x2978 <do_action+0x858>
    2525:      	incl	%ebx
    2527:      	movzbl	%bpl, %r14d
    252b:      	xorq	$0x5, %r14
    252f:      	jmp	0x2673 <do_action+0x553>
    2534:      	movl	$0xe, %eax
    2539:      	callq	*%rax
    253b:      	movq	%rax, 0x20(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <do_action+0x427>
    2547:      	leaq	0x20(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2978 <do_action+0x858>
    255c:      	movq	0x4(%rax), %rax
    2560:      	movq	%rax, 0x10(%rsp)
    2565:      	movl	$0x2, 0x18(%rsp)
    256d:      	movq	(%rip), %rdi            # 0x2574 <do_action+0x454>
    2574:      	leaq	0x10(%rsp), %rsi
    2579:      	movl	$0x1, %eax
    257e:      	callq	*%rax
    2580:      	movl	$0x1, 0x2c(%rsp)
    2588:      	testq	%rax, %rax
    258b:      	je	0x269e <do_action+0x57e>
    2591:      	lock
    2592:      	incl	(%rax)
    2594:      	movq	(%rip), %rdi            # 0x259b <do_action+0x47b>
    259b:      	leaq	0x20(%rsp), %rsi
    25a0:      	movl	$0x3, %eax
    25a5:      	callq	*%rax
    25a7:      	jmp	0x2978 <do_action+0x858>
    25ac:      	leal	0x1(%rbx), %eax
    25af:      	movl	0x4(%r15,%rax,4), %ebp
    25b4:      	leal	0x2(%rbx), %eax
    25b7:      	movl	0x4(%r15,%rax,4), %eax
    25bc:      	movl	%eax, 0x30(%rsp)
    25c0:      	movl	$0x7d, %eax
    25c5:      	callq	*%rax
    25c7:      	movq	%rax, 0x68(%rsp)
    25cc:      	movq	%rax, (%rsp)
    25d0:      	movl	$0x0, 0x20(%rsp)
    25d8:      	movq	%rbp, 0x70(%rsp)
    25dd:      	testq	%rbp, %rbp
    25e0:      	je	0x290a <do_action+0x7ea>
    25e6:      	movq	(%rip), %rdi            # 0x25ed <do_action+0x4cd>
    25ed:      	leaq	0x20(%rsp), %rsi
    25f2:      	movl	$0x1, %eax
    25f7:      	callq	*%rax
    25f9:      	testq	%rax, %rax
    25fc:      	je	0x290a <do_action+0x7ea>
    2602:      	movq	%rax, 0x48(%rsp)
    2607:      	movq	%rax, %rbp
    260a:      	movq	(%rip), %rdi            # 0x2611 <do_action+0x4f1>
    2611:      	leaq	0x20(%rsp), %rsi
    2616:      	movl	$0x1, %eax
    261b:      	callq	*%rax
    261d:      	movq	%rax, %rdx
    2620:      	movq	0x60(%r13), %rax
    2624:      	movq	%rax, (%rbp)
    2628:      	movq	0x70(%r13), %rax
    262c:      	movq	%rbp, 0x40(%rsp)
    2631:      	movq	%rax, 0x8(%rbp)
    2635:      	xorl	%eax, %eax
    2637:      	movq	%rax, 0x60(%rsp)
    263c:      	movl	$0x0, %eax
    2641:      	movl	0x30(%rsp), %ecx
    2645:      	cmpl	$0x2, %ecx
    2648:      	je	0x273f <do_action+0x61f>
    264e:      	cmpl	$0x1, %ecx
    2651:      	je	0x273b <do_action+0x61b>
    2657:      	testl	%ecx, %ecx
    2659:      	jne	0x290a <do_action+0x7ea>
    265f:      	movl	0x7c(%r13), %eax
    2663:      	jmp	0x273f <do_action+0x61f>
    2668:      	addl	$0x3, %ebx
    266b:      	movzbl	%bpl, %r14d
    266f:      	xorq	$0x7, %r14
    2673:      	movl	$0x0, (%rsp)
    267a:      	movq	(%rip), %rdi            # 0x2681 <do_action+0x561>
    2681:      	movq	%rsp, %rsi
    2684:      	movl	$0x1, %eax
    2689:      	callq	*%rax
    268b:      	testq	%rax, %rax
    268e:      	je	0x2978 <do_action+0x858>
    2694:      	lock
    2695:      	incq	(%rax,%r14,8)
    2699:      	jmp	0x2978 <do_action+0x858>
    269e:      	movq	(%rip), %rdi            # 0x26a5 <do_action+0x585>
    26a5:      	leaq	0x10(%rsp), %rsi
    26aa:      	leaq	0x2c(%rsp), %rdx
    26af:      	movl	$0x1, %ecx
    26b4:      	movl	$0x2, %eax
    26b9:      	callq	*%rax
    26bb:      	testq	%rax, %rax
    26be:      	je	0x2594 <do_action+0x474>
    26c4:      	movq	%rax, %r15
    26c7:      	negl	%eax
    26c9:      	movw	%ax, (%rsp)
    26cd:      	movw	$0x3, 0x2(%rsp)
    26d4:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    26de:      	movq	%rax, 0x4(%rsp)
    26e3:      	movq	(%rip), %rdi            # 0x26ea <do_action+0x5ca>
    26ea:      	movq	%rsp, %rsi
    26ed:      	movl	$0x1, %eax
    26f2:      	callq	*%rax
    26f4:      	testq	%rax, %rax
    26f7:      	je	0x298f <do_action+0x86f>
    26fd:      	incl	(%rax)
    26ff:      	jmp	0x29b1 <do_action+0x891>
    2704:      	movq	(%rip), %rdi            # 0x270b <do_action+0x5eb>
    270b:      	movq	%rsp, %rsi
    270e:      	movl	$0x3, %eax
    2713:      	jmp	0x2726 <do_action+0x606>
    2715:      	movq	(%rip), %rdi            # 0x271c <do_action+0x5fc>
    271c:      	leaq	0x10(%rsp), %rsi
    2721:      	movl	$0x3, %eax
    2726:      	callq	*%rax
    2728:      	movq	%rax, %r15
    272b:      	xorl	%eax, %eax
    272d:      	testl	%r15d, %r15d
    2730:      	jne	0x2980 <do_action+0x860>
    2736:      	jmp	0x2978 <do_action+0x858>
    273b:      	movl	0x10(%r13), %eax
    273f:      	movq	%r14, 0x30(%rsp)
    2744:      	movl	%eax, %eax
    2746:      	movq	0x40(%rsp), %rcx
    274b:      	movq	%rax, 0x10(%rcx)
    274f:      	movq	0x48(%rsp), %rdi
    2754:      	addq	$0x18, %rdi
    2758:      	movl	$0xc8, %ecx
    275d:      	movl	$0x4, %eax
    2762:      	movq	%rdi, 0x48(%rsp)
    2767:      	movl	$0xc8, %esi
    276c:      	callq	*%rax
    276e:      	xorl	%r14d, %r14d
    2771:      	movq	%r13, 0x58(%rsp)
    2776:      	jmp	0x2786 <do_action+0x666>
    2778:      	addq	$0x4, %r14
    277c:      	cmpq	$0x14, %r14
    2780:      	je	0x28b3 <do_action+0x793>
    2786:      	movl	$0x0, 0x10(%rsp)
    278e:      	movl	$0x1, %eax
    2793:      	movq	(%rip), %rdi            # 0x279a <do_action+0x67a>
    279a:      	leaq	0x10(%rsp), %rsi
    279f:      	callq	*%rax
    27a1:      	testq	%rax, %rax
    27a4:      	je	0x28b3 <do_action+0x793>
    27aa:      	movq	%rax, %rsi
    27ad:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    27b4:      	movl	$0x1, %eax
    27b9:      	movq	(%rip), %rdi            # 0x27c0 <do_action+0x6a0>
    27c0:      	callq	*%rax
    27c2:      	testq	%rax, %rax
    27c5:      	je	0x28b3 <do_action+0x793>
    27cb:      	cmpl	$-0x1, 0x40(%rax,%r14)
    27d1:      	je	0x28b3 <do_action+0x793>
    27d7:      	movq	0x5e78(%r13,%r14,2), %rax
    27df:      	movl	0x4(%r13), %ecx
    27e3:      	cmpq	%rcx, %rax
    27e6:      	jge	0x28b3 <do_action+0x793>
    27ec:      	cmpq	$0x10, %r14
    27f0:      	je	0x2853 <do_action+0x733>
    27f2:      	movl	$0x0, 0x10(%rsp)
    27fa:      	movl	$0x1, %eax
    27ff:      	movq	(%rip), %rdi            # 0x2806 <do_action+0x6e6>
    2806:      	leaq	0x10(%rsp), %rsi
    280b:      	callq	*%rax
    280d:      	testq	%rax, %rax
    2810:      	je	0x284b <do_action+0x72b>
    2812:      	movq	%rax, %rsi
    2815:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    281c:      	movl	$0x1, %eax
    2821:      	movq	(%rip), %rdi            # 0x2828 <do_action+0x708>
    2828:      	callq	*%rax
    282a:      	testq	%rax, %rax
    282d:      	je	0x284b <do_action+0x72b>
    282f:      	cmpl	$-0x1, 0x44(%rax,%r14)
    2835:      	movq	0x5e78(%r13,%r14,2), %rax
    283d:      	je	0x2853 <do_action+0x733>
    283f:      	movl	0x5e80(%r13,%r14,2), %ebp
    2847:      	subl	%eax, %ebp
    2849:      	jmp	0x285c <do_action+0x73c>
    284b:      	movq	0x5e78(%r13,%r14,2), %rax
    2853:      	movl	0x4(%r13), %ebp
    2857:      	subl	%eax, %ebp
    2859:      	addl	$0x4, %ebp
    285c:      	testl	%ebp, %ebp
    285e:      	jle	0x2778 <do_action+0x658>
    2864:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2869:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    286e:      	cmpl	$0x28, %ebp
    2871:      	movl	$0x28, %ecx
    2876:      	cmovgel	%ecx, %ebp
    2879:      	movzbl	0x60(%rsp), %r13d
    287f:      	movq	0x48(%rsp), %rcx
    2884:      	leaq	(%rcx,%r13), %rdi
    2888:      	movq	0x58(%rsp), %rcx
    288d:      	leaq	(%rcx,%rax), %rdx
    2891:      	addq	$0x90, %rdx
    2898:      	movl	$0x4, %eax
    289d:      	movl	%ebp, %esi
    289f:      	callq	*%rax
    28a1:      	addl	%r13d, %ebp
    28a4:      	movq	0x58(%rsp), %r13
    28a9:      	movq	%rbp, 0x60(%rsp)
    28ae:      	jmp	0x2778 <do_action+0x658>
    28b3:      	movq	(%rip), %rdi            # 0x28ba <do_action+0x79a>
    28ba:      	movl	$0x1, %eax
    28bf:      	movq	0x40(%rsp), %rsi
    28c4:      	callq	*%rax
    28c6:      	testq	%rax, %rax
    28c9:      	je	0x28eb <do_action+0x7cb>
    28cb:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    28d4:      	movq	0x68(%rsp), %rdx
    28d9:      	addq	%rcx, %rdx
    28dc:      	cmpq	%rdx, (%rax)
    28df:      	jbe	0x28eb <do_action+0x7cb>
    28e1:      	movq	0x38(%rsp), %rax
    28e6:      	movb	$0x0, (%rax)
    28e9:      	jmp	0x2905 <do_action+0x7e5>
    28eb:      	movq	(%rip), %rdi            # 0x28f2 <do_action+0x7d2>
    28f2:      	xorl	%ecx, %ecx
    28f4:      	movq	%rsp, %rdx
    28f7:      	movl	$0x2, %eax
    28fc:      	movq	0x40(%rsp), %rsi
    2901:      	xorl	%ecx, %ecx
    2903:      	callq	*%rax
    2905:      	movq	0x30(%rsp), %r14
    290a:      	leal	0x3(%rbx), %eax
    290d:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2913:      	je	0x2936 <do_action+0x816>
    2915:      	orb	$0x2, 0x1(%r13)
    291a:      	movq	(%rip), %rsi            # 0x2921 <do_action+0x801>
    2921:      	xorl	%ecx, %ecx
    2923:      	movl	$0x1b, %eax
    2928:      	movq	%r14, %rdi
    292b:      	xorl	%edx, %edx
    292d:      	callq	*%rax
    292f:      	movq	%rax, 0x80(%r13)
    2936:      	leal	0x4(%rbx), %eax
    2939:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    293f:      	je	0x2968 <do_action+0x848>
    2941:      	orb	$0x4, 0x1(%r13)
    2946:      	movq	(%rip), %rsi            # 0x294d <do_action+0x82d>
    294d:      	movl	$0x100, %ecx            # imm = 0x100
    2952:      	movl	$0x1b, %eax
    2957:      	movl	$0x100, %edx            # imm = 0x100
    295c:      	movq	%r14, %rdi
    295f:      	callq	*%rax
    2961:      	movq	%rax, 0x88(%r13)
    2968:      	addl	$0x5, %ebx
    296b:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2971:      	je	0x2978 <do_action+0x858>
    2973:      	orb	$0x8, 0x1(%r13)
    2978:      	movq	%r12, 0x70(%r13)
    297c:      	incl	%ebx
    297e:      	movl	%ebx, %eax
    2980:      	addq	$0x78, %rsp
    2984:      	popq	%rbx
    2985:      	popq	%r12
    2987:      	popq	%r13
    2989:      	popq	%r14
    298b:      	popq	%r15
    298d:      	popq	%rbp
    298e:      	retq
    298f:      	movl	$0x1, 0x54(%rsp)
    2997:      	movq	(%rip), %rdi            # 0x299e <do_action+0x87e>
    299e:      	xorl	%ecx, %ecx
    29a0:      	movq	%rsp, %rsi
    29a3:      	leaq	0x54(%rsp), %rdx
    29a8:      	movl	$0x2, %eax
    29ad:      	xorl	%ecx, %ecx
    29af:      	callq	*%rax
    29b1:      	testl	%r15d, %r15d
    29b4:      	je	0x2594 <do_action+0x474>
    29ba:      	movq	(%rip), %rdi            # 0x29c1 <do_action+0x8a1>
    29c1:      	leaq	0x10(%rsp), %rsi
    29c6:      	movl	$0x1, %eax
    29cb:      	callq	*%rax
    29cd:      	testq	%rax, %rax
    29d0:      	je	0x2594 <do_action+0x474>
    29d6:      	movl	0x2c(%rsp), %ecx
    29da:      	lock
    29db:      	addl	%ecx, (%rax)
    29dd:      	jmp	0x2594 <do_action+0x474>

Disassembly of section kprobe:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <generic_retkprobe_filter_arg+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x398 <generic_retkprobe_filter_arg+0x398>
      35:      	movq	%rax, %r14
      38:      	movl	0x5f00(%rax), %r12d
      3f:      	leaq	0x5ef8(%rax), %rsi
      46:      	movq	(%rip), %rdi            # 0x4d <generic_retkprobe_filter_arg+0x4d>
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x37d <generic_retkprobe_filter_arg+0x37d>
      5d:      	cmpb	$0x0, 0x5ee0(%r14)
      65:      	je	0x37d <generic_retkprobe_filter_arg+0x37d>
      6b:      	movq	%rax, %r15
      6e:      	movl	%r12d, %eax
      71:      	andl	$0x7, %eax
      74:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      7d:      	je	0xb7 <generic_retkprobe_filter_arg+0xb7>
      7f:      	movl	%eax, %eax
      81:      	movl	0x4(%r15,%rax,4), %ecx
      86:      	leaq	(%rcx,%rax,4), %r13
      8a:      	addq	$0x8, %r13
      8e:      	movq	%r13, %rax
      91:      	movq	%r13, 0x10(%rsp)
      96:      	andl	$0x3ff, %r13d           # imm = 0x3FF
      9d:      	cmpl	$0x19, (%r15,%r13)
      a2:      	jae	0x10c <generic_retkprobe_filter_arg+0x10c>
      a4:      	cmpq	$0x1, %r13
      a8:      	je	0x37d <generic_retkprobe_filter_arg+0x37d>
      ae:      	testl	%r13d, %r13d
      b1:      	jne	0x35b <generic_retkprobe_filter_arg+0x35b>
      b7:      	cmpl	$0x1, %r12d
      bb:      	jg	0xdc <generic_retkprobe_filter_arg+0xdc>
      bd:      	cmpl	$-0x1, %r12d
      c1:      	je	0x3a9 <generic_retkprobe_filter_arg+0x3a9>
      c7:      	testl	%r12d, %r12d
      ca:      	je	0x3b6 <generic_retkprobe_filter_arg+0x3b6>
      d0:      	cmpl	$0x1, %r12d
      d4:      	je	0x3c6 <generic_retkprobe_filter_arg+0x3c6>
      da:      	jmp	0xfa <generic_retkprobe_filter_arg+0xfa>
      dc:      	cmpl	$0x2, %r12d
      e0:      	je	0x3d6 <generic_retkprobe_filter_arg+0x3d6>
      e6:      	cmpl	$0x3, %r12d
      ea:      	je	0x3e6 <generic_retkprobe_filter_arg+0x3e6>
      f0:      	cmpl	$0x4, %r12d
      f4:      	je	0x3f6 <generic_retkprobe_filter_arg+0x3f6>
      fa:      	cmpl	$0x4, %r12d
      fe:      	jg	0x428 <generic_retkprobe_filter_arg+0x428>
     104:      	incl	%r12d
     107:      	jmp	0x406 <generic_retkprobe_filter_arg+0x406>
     10c:      	leaq	(%r15,%r13), %rax
     110:      	movq	%rax, 0x8(%rsp)
     115:      	movl	$0x1, %ebp
     11a:      	nopw	(%rax,%rax)
     120:      	movq	0x8(%rsp), %rax
     125:      	movl	(%rax,%rbp,4), %edi
     128:      	testl	$0x3ff, %edi            # imm = 0x3FF
     12e:      	je	0xa4 <generic_retkprobe_filter_arg+0xa4>
     134:      	addl	0x10(%rsp), %edi
     138:      	andl	$0x3ff, %edi            # imm = 0x3FF
     13e:      	movl	0x4(%r15,%rdi), %ecx
     143:      	cmpl	$0x23, %ecx
     146:      	je	0xb7 <generic_retkprobe_filter_arg+0xb7>
     14c:      	addq	%r15, %rdi
     14f:      	movl	(%rdi), %eax
     151:      	cmpq	$0x4, %rax
     155:      	ja	0xb7 <generic_retkprobe_filter_arg+0xb7>
     15b:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
     164:      	jne	0xb7 <generic_retkprobe_filter_arg+0xb7>
     16a:      	movq	0x5e78(%r14,%rax,8), %rax
     172:      	andl	$0x7ff, %eax            # imm = 0x7FF
     177:      	leaq	(%r14,%rax), %rsi
     17b:      	addq	$0x90, %rsi
     182:      	movl	0xc(%rdi), %eax
     185:      	cmpl	$0x1b, %eax
     188:      	jle	0x1a9 <generic_retkprobe_filter_arg+0x1a9>
     18a:      	cmpl	$0x25, %eax
     18d:      	jg	0x1d9 <generic_retkprobe_filter_arg+0x1d9>
     18f:      	leal	-0x1c(%rax), %edx
     192:      	cmpl	$0x9, %edx
     195:      	jb	0x21f <generic_retkprobe_filter_arg+0x21f>
     19b:      	cmpl	$0x25, %eax
     19e:      	je	0x302 <generic_retkprobe_filter_arg+0x302>
     1a4:      	jmp	0x349 <generic_retkprobe_filter_arg+0x349>
     1a9:      	cmpl	$0x9, %eax
     1ac:      	jle	0x1ff <generic_retkprobe_filter_arg+0x1ff>
     1ae:      	leal	-0xa(%rax), %edx
     1b1:      	cmpl	$0x4, %edx
     1b4:      	jb	0x21f <generic_retkprobe_filter_arg+0x21f>
     1b6:      	leal	-0xf(%rax), %ecx
     1b9:      	cmpl	$0x2, %ecx
     1bc:      	jb	0x302 <generic_retkprobe_filter_arg+0x302>
     1c2:      	cmpl	$0x11, %eax
     1c5:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     1cb:      	addq	$0x4, %rsi
     1cf:      	callq	0x1d4 <generic_retkprobe_filter_arg+0x1d4>
     1d4:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     1d9:      	cmpl	$0x29, %eax
     1dc:      	jg	0x2f1 <generic_retkprobe_filter_arg+0x2f1>
     1e2:      	leal	-0x26(%rax), %ecx
     1e5:      	cmpl	$0x2, %ecx
     1e8:      	jb	0x2ac <generic_retkprobe_filter_arg+0x2ac>
     1ee:      	addl	$-0x28, %eax
     1f1:      	cmpl	$0x2, %eax
     1f4:      	jb	0x2a2 <generic_retkprobe_filter_arg+0x2a2>
     1fa:      	jmp	0x349 <generic_retkprobe_filter_arg+0x349>
     1ff:      	cmpl	$0x4, %eax
     202:      	jg	0x28f <generic_retkprobe_filter_arg+0x28f>
     208:      	cmpl	$0x1, %eax
     20b:      	je	0x21f <generic_retkprobe_filter_arg+0x21f>
     20d:      	cmpl	$0x2, %eax
     210:      	je	0x31f <generic_retkprobe_filter_arg+0x31f>
     216:      	cmpl	$0x4, %eax
     219:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     21f:      	cmpl	$0xb, %eax
     222:      	jle	0x26c <generic_retkprobe_filter_arg+0x26c>
     224:      	cmpl	$0x24, %eax
     227:      	ja	0x309 <generic_retkprobe_filter_arg+0x309>
     22d:      	movl	%eax, %edx
     22f:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
     239:      	btq	%rdx, %r8
     23d:      	jb	0x2b3 <generic_retkprobe_filter_arg+0x2b3>
     23f:      	movl	$0x60000000, %ecx       # imm = 0x60000000
     244:      	btq	%rdx, %rcx
     248:      	jb	0x318 <generic_retkprobe_filter_arg+0x318>
     24e:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
     258:      	btq	%rdx, %rcx
     25c:      	jae	0x309 <generic_retkprobe_filter_arg+0x309>
     262:      	callq	0x267 <generic_retkprobe_filter_arg+0x267>
     267:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     26c:      	leal	-0xa(%rax), %ecx
     26f:      	cmpl	$0x2, %ecx
     272:      	jb	0x330 <generic_retkprobe_filter_arg+0x330>
     278:      	cmpl	$0x1, %eax
     27b:      	je	0x311 <generic_retkprobe_filter_arg+0x311>
     281:      	cmpl	$0x4, %eax
     284:      	je	0x311 <generic_retkprobe_filter_arg+0x311>
     28a:      	jmp	0x349 <generic_retkprobe_filter_arg+0x349>
     28f:      	cmpl	$0x5, %eax
     292:      	je	0x2a2 <generic_retkprobe_filter_arg+0x2a2>
     294:      	cmpl	$0x6, %eax
     297:      	je	0x2ac <generic_retkprobe_filter_arg+0x2ac>
     299:      	cmpl	$0x7, %eax
     29c:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     2a2:      	callq	0x2a7 <generic_retkprobe_filter_arg+0x2a7>
     2a7:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     2ac:      	movl	$0x4, %edx
     2b1:      	jmp	0x324 <generic_retkprobe_filter_arg+0x324>
     2b3:      	cmpl	$0x1e, %ecx
     2b6:      	jne	0x330 <generic_retkprobe_filter_arg+0x330>
     2b8:      	movl	0x10(%rdi), %eax
     2bb:      	andl	$0x7, %eax
     2be:      	movl	%eax, %ecx
     2c0:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2c9:      	jne	0xb7 <generic_retkprobe_filter_arg+0xb7>
     2cf:      	movq	(%rsi), %rcx
     2d2:      	movq	0x5e78(%r14,%rax,8), %rdx
     2da:      	andl	$0x7ff, %edx            # imm = 0x7FF
     2e0:      	xorl	%eax, %eax
     2e2:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
     2ec:      	setne	%al
     2ef:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     2f1:      	cmpl	$0x2a, %eax
     2f4:      	je	0x302 <generic_retkprobe_filter_arg+0x302>
     2f6:      	cmpl	$0x2c, %eax
     2f9:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     2fb:      	callq	0x300 <generic_retkprobe_filter_arg+0x300>
     300:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     302:      	callq	0x307 <generic_retkprobe_filter_arg+0x307>
     307:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     309:      	leal	-0xc(%rax), %ecx
     30c:      	cmpl	$0x2, %ecx
     30f:      	jae	0x32b <generic_retkprobe_filter_arg+0x32b>
     311:      	callq	0x316 <generic_retkprobe_filter_arg+0x316>
     316:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     318:      	callq	0x31d <generic_retkprobe_filter_arg+0x31d>
     31d:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     31f:      	movl	$0x8, %edx
     324:      	callq	0x329 <generic_retkprobe_filter_arg+0x329>
     329:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     32b:      	cmpl	$0x1c, %eax
     32e:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     330:      	callq	0x335 <generic_retkprobe_filter_arg+0x335>
     335:      	nopw	%cs:(%rax,%rax)
     340:      	testq	%rax, %rax
     343:      	je	0xb7 <generic_retkprobe_filter_arg+0xb7>
     349:      	incq	%rbp
     34c:      	cmpq	$0x6, %rbp
     350:      	jne	0x120 <generic_retkprobe_filter_arg+0x120>
     356:      	jmp	0xa4 <generic_retkprobe_filter_arg+0xa4>
     35b:      	movl	%r13d, 0x5f04(%r14)
     362:      	movq	(%rip), %rsi            # 0x369 <generic_retkprobe_filter_arg+0x369>
     369:      	movl	$0x4, %ecx
     36e:      	movl	$0xc, %eax
     373:      	movq	%rbx, %rdi
     376:      	movl	$0x4, %edx
     37b:      	callq	*%rax
     37d:      	movq	(%rip), %rsi            # 0x384 <generic_retkprobe_filter_arg+0x384>
     384:      	movl	$0x5, %ecx
     389:      	movl	$0xc, %eax
     38e:      	movq	%rbx, %rdi
     391:      	movl	$0x5, %edx
     396:      	callq	*%rax
     398:      	xorl	%eax, %eax
     39a:      	addq	$0x28, %rsp
     39e:      	popq	%rbx
     39f:      	popq	%r12
     3a1:      	popq	%r13
     3a3:      	popq	%r14
     3a5:      	popq	%r15
     3a7:      	popq	%rbp
     3a8:      	retq
     3a9:      	xorl	%r12d, %r12d
     3ac:      	cmpb	$0x0, 0x5ec1(%r14)
     3b4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3b6:      	movl	$0x1, %r12d
     3bc:      	cmpb	$0x0, 0x5ec2(%r14)
     3c4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3c6:      	movl	$0x2, %r12d
     3cc:      	cmpb	$0x0, 0x5ec3(%r14)
     3d4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3d6:      	movl	$0x3, %r12d
     3dc:      	cmpb	$0x0, 0x5ec4(%r14)
     3e4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3e6:      	movl	$0x4, %r12d
     3ec:      	cmpb	$0x0, 0x5ec5(%r14)
     3f4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3f6:      	movl	$0x5, %r12d
     3fc:      	cmpb	$0x0, 0x5ec6(%r14)
     404:      	je	0x428 <generic_retkprobe_filter_arg+0x428>
     406:      	movl	%r12d, 0x5f00(%r14)
     40d:      	movq	(%rip), %rsi            # 0x414 <generic_retkprobe_filter_arg+0x414>
     414:      	movl	$0x3, %ecx
     419:      	movl	$0xc, %eax
     41e:      	movq	%rbx, %rdi
     421:      	movl	$0x3, %edx
     426:      	callq	*%rax
     428:      	movq	0x60(%r14), %rbx
     42c:      	movl	$0xe, %eax
     431:      	callq	*%rax
     433:      	movq	%rbx, 0x18(%rsp)
     438:      	movq	%rax, 0x20(%rsp)
     43d:      	movq	(%rip), %rdi            # 0x444 <generic_retkprobe_filter_arg+0x444>
     444:      	leaq	0x18(%rsp), %rsi
     449:      	movl	$0x1, %eax
     44e:      	callq	*%rax
     450:      	testq	%rax, %rax
     453:      	je	0x398 <generic_retkprobe_filter_arg+0x398>
     459:      	movq	(%rip), %rdi            # 0x460 <generic_retkprobe_filter_arg+0x460>
     460:      	leaq	0x18(%rsp), %rsi
     465:      	movl	$0x3, %eax
     46a:      	callq	*%rax
     46c:      	jmp	0x398 <generic_retkprobe_filter_arg+0x398>
     471:      	nopw	%cs:(%rax,%rax)

0000000000000480 <generic_retkprobe_actions>:
     480:      	pushq	%rbp
     481:      	pushq	%r14
     483:      	pushq	%rbx
     484:      	subq	$0x10, %rsp
     488:      	movq	%rdi, %rbx
     48b:      	movl	$0x0, 0x8(%rsp)
     493:      	movq	(%rip), %rdi            # 0x49a <generic_retkprobe_actions+0x1a>
     49a:      	leaq	0x8(%rsp), %rsi
     49f:      	movl	$0x1, %eax
     4a4:      	callq	*%rax
     4a6:      	testq	%rax, %rax
     4a9:      	je	0x5b2 <generic_retkprobe_actions+0x132>
     4af:      	movq	%rax, %rsi
     4b2:      	movl	0x5f04(%rax), %r14d
     4b9:      	cmpl	$0x2, %r14d
     4bd:      	jl	0x5b2 <generic_retkprobe_actions+0x132>
     4c3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     4ca:      	movq	(%rip), %rdi            # 0x4d1 <generic_retkprobe_actions+0x51>
     4d1:      	movl	$0x1, %eax
     4d6:      	callq	*%rax
     4d8:      	testq	%rax, %rax
     4db:      	je	0x5b2 <generic_retkprobe_actions+0x132>
     4e1:      	movl	%r14d, %ecx
     4e4:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     4ea:      	addl	(%rax,%rcx), %r14d
     4ee:      	movb	$0x1, 0x7(%rsp)
     4f3:      	movl	$0x0, 0xc(%rsp)
     4fb:      	movq	(%rip), %rdi            # 0x502 <generic_retkprobe_actions+0x82>
     502:      	leaq	0xc(%rsp), %rsi
     507:      	movq	%rax, %rcx
     50a:      	movl	$0x1, %eax
     50f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
     516:      	addq	%rcx, %r14
     519:      	callq	*%rax
     51b:      	testq	%rax, %rax
     51e:      	je	0x52e <generic_retkprobe_actions+0xae>
     520:      	cmpb	$0x0, (%rax)
     523:      	sete	%al
     526:      	cmpl	$0x5, (%r14)
     52a:      	jae	0x536 <generic_retkprobe_actions+0xb6>
     52c:      	jmp	0x590 <generic_retkprobe_actions+0x110>
     52e:      	movb	$0x1, %al
     530:      	cmpl	$0x5, (%r14)
     534:      	jb	0x590 <generic_retkprobe_actions+0x110>
     536:      	movzbl	%al, %ebp
     539:      	leaq	0x7(%rsp), %rcx
     53e:      	movq	%rbx, %rdi
     541:      	xorl	%esi, %esi
     543:      	movq	%r14, %rdx
     546:      	movl	%ebp, %r8d
     549:      	callq	0x54e <generic_retkprobe_actions+0xce>
     54e:      	leal	0x4(,%rax,4), %ecx
     555:      	cmpl	(%r14), %ecx
     558:      	jae	0x590 <generic_retkprobe_actions+0x110>
     55a:      	leaq	0x7(%rsp), %rcx
     55f:      	movq	%rbx, %rdi
     562:      	movl	%eax, %esi
     564:      	movq	%r14, %rdx
     567:      	movl	%ebp, %r8d
     56a:      	callq	0x56f <generic_retkprobe_actions+0xef>
     56f:      	leal	0x4(,%rax,4), %ecx
     576:      	cmpl	(%r14), %ecx
     579:      	jae	0x590 <generic_retkprobe_actions+0x110>
     57b:      	leaq	0x7(%rsp), %rcx
     580:      	movq	%rbx, %rdi
     583:      	movl	%eax, %esi
     585:      	movq	%r14, %rdx
     588:      	movl	%ebp, %r8d
     58b:      	callq	0x590 <generic_retkprobe_actions+0x110>
     590:      	cmpb	$0x0, 0x7(%rsp)
     595:      	je	0x5b2 <generic_retkprobe_actions+0x132>
     597:      	movq	(%rip), %rsi            # 0x59e <generic_retkprobe_actions+0x11e>
     59e:      	movl	$0x5, %ecx
     5a3:      	movl	$0xc, %eax
     5a8:      	movq	%rbx, %rdi
     5ab:      	movl	$0x5, %edx
     5b0:      	callq	*%rax
     5b2:      	xorl	%eax, %eax
     5b4:      	addq	$0x10, %rsp
     5b8:      	popq	%rbx
     5b9:      	popq	%r14
     5bb:      	popq	%rbp
     5bc:      	retq
     5bd:      	nopl	(%rax)

00000000000005c0 <generic_retkprobe_output>:
     5c0:      	pushq	%r15
     5c2:      	pushq	%r14
     5c4:      	pushq	%rbx
     5c5:      	subq	$0x10, %rsp
     5c9:      	movq	%rdi, %r14
     5cc:      	movl	$0x0, 0x8(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <generic_retkprobe_output+0x1b>
     5db:      	leaq	0x8(%rsp), %rsi
     5e0:      	movl	$0x1, %eax
     5e5:      	callq	*%rax
     5e7:      	testq	%rax, %rax
     5ea:      	je	0x6c3 <generic_retkprobe_output+0x103>
     5f0:      	movq	%rax, %rbx
     5f3:      	movl	$0x90, %eax
     5f8:      	addl	0x4(%rbx), %eax
     5fb:      	andl	$0x7fff, %eax           # imm = 0x7FFF
     600:      	cmpl	$0x2328, %eax           # imm = 0x2328
     605:      	movl	$0x2328, %r15d          # imm = 0x2328
     60b:      	cmovbl	%eax, %r15d
     60f:      	movl	$0x0, 0xc(%rsp)
     617:      	movq	(%rip), %rdi            # 0x61e <generic_retkprobe_output+0x5e>
     61e:      	leaq	0xc(%rsp), %rsi
     623:      	movl	$0x1, %eax
     628:      	callq	*%rax
     62a:      	testq	%rax, %rax
     62d:      	je	0x681 <generic_retkprobe_output+0xc1>
     62f:      	cmpb	$0x0, 0x28(%rax)
     633:      	je	0x681 <generic_retkprobe_output+0xc1>
     635:      	movq	(%rip), %rsi            # 0x63c <generic_retkprobe_output+0x7c>
     63c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     641:      	movl	$0x19, %eax
     646:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     64b:      	movq	%r14, %rdi
     64e:      	movq	%rbx, %rcx
     651:      	movq	%r15, %r8
     654:      	callq	*%rax
     656:      	testq	%rax, %rax
     659:      	js	0x71e <generic_retkprobe_output+0x15e>
     65f:      	movl	$0x0, 0x4(%rsp)
     667:      	movq	(%rip), %rdi            # 0x66e <generic_retkprobe_output+0xae>
     66e:      	leaq	0x4(%rsp), %rsi
     673:      	movl	$0x1, %eax
     678:      	callq	*%rax
     67a:      	testq	%rax, %rax
     67d:      	jne	0x6be <generic_retkprobe_output+0xfe>
     67f:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     681:      	movq	(%rip), %rdi            # 0x688 <generic_retkprobe_output+0xc8>
     688:      	xorl	%ecx, %ecx
     68a:      	movl	$0x82, %eax
     68f:      	movq	%rbx, %rsi
     692:      	movq	%r15, %rdx
     695:      	xorl	%ecx, %ecx
     697:      	callq	*%rax
     699:      	testq	%rax, %rax
     69c:      	js	0x6cf <generic_retkprobe_output+0x10f>
     69e:      	movl	$0x0, 0x4(%rsp)
     6a6:      	movq	(%rip), %rdi            # 0x6ad <generic_retkprobe_output+0xed>
     6ad:      	leaq	0x4(%rsp), %rsi
     6b2:      	movl	$0x1, %eax
     6b7:      	callq	*%rax
     6b9:      	testq	%rax, %rax
     6bc:      	je	0x6c3 <generic_retkprobe_output+0x103>
     6be:      	lock
     6bf:      	incq	0x8(%rax)
     6c3:      	xorl	%eax, %eax
     6c5:      	addq	$0x10, %rsp
     6c9:      	popq	%rbx
     6ca:      	popq	%r14
     6cc:      	popq	%r15
     6ce:      	retq
     6cf:      	movq	%rax, %rbx
     6d2:      	movl	$0x0, 0x4(%rsp)
     6da:      	movq	(%rip), %rdi            # 0x6e1 <generic_retkprobe_output+0x121>
     6e1:      	leaq	0x4(%rsp), %rsi
     6e6:      	movl	$0x1, %eax
     6eb:      	callq	*%rax
     6ed:      	testq	%rax, %rax
     6f0:      	je	0x6c3 <generic_retkprobe_output+0x103>
     6f2:      	cmpq	$-0xc, %rbx
     6f6:      	jg	0x762 <generic_retkprobe_output+0x1a2>
     6f8:      	cmpq	$-0x1c, %rbx
     6fc:      	je	0x7a4 <generic_retkprobe_output+0x1e4>
     702:      	cmpq	$-0x16, %rbx
     706:      	je	0x753 <generic_retkprobe_output+0x193>
     708:      	cmpq	$-0x10, %rbx
     70c:      	jne	0x795 <generic_retkprobe_output+0x1d5>
     712:      	addq	$0x2f0, %rax            # imm = 0x2F0
     718:      	lock
     719:      	incq	(%rax)
     71c:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     71e:      	movq	%rax, %rbx
     721:      	movl	$0x0, 0x4(%rsp)
     729:      	movq	(%rip), %rdi            # 0x730 <generic_retkprobe_output+0x170>
     730:      	leaq	0x4(%rsp), %rsi
     735:      	movl	$0x1, %eax
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x6c3 <generic_retkprobe_output+0x103>
     741:      	cmpq	$-0xc, %rbx
     745:      	jg	0x783 <generic_retkprobe_output+0x1c3>
     747:      	cmpq	$-0x1c, %rbx
     74b:      	je	0x7a4 <generic_retkprobe_output+0x1e4>
     74d:      	cmpq	$-0x16, %rbx
     751:      	jne	0x708 <generic_retkprobe_output+0x148>
     753:      	addq	$0x2f8, %rax            # imm = 0x2F8
     759:      	lock
     75a:      	incq	(%rax)
     75d:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     762:      	cmpq	$-0xb, %rbx
     766:      	je	0x7b3 <generic_retkprobe_output+0x1f3>
     768:      	cmpq	$-0x7, %rbx
     76c:      	je	0x7c2 <generic_retkprobe_output+0x202>
     76e:      	cmpq	$-0x2, %rbx
     772:      	jne	0x795 <generic_retkprobe_output+0x1d5>
     774:      	addq	$0x2e0, %rax            # imm = 0x2E0
     77a:      	lock
     77b:      	incq	(%rax)
     77e:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     783:      	cmpq	$-0xb, %rbx
     787:      	je	0x7b3 <generic_retkprobe_output+0x1f3>
     789:      	cmpq	$-0x7, %rbx
     78d:      	je	0x7c2 <generic_retkprobe_output+0x202>
     78f:      	cmpq	$-0x2, %rbx
     793:      	je	0x774 <generic_retkprobe_output+0x1b4>
     795:      	addq	$0x2d8, %rax            # imm = 0x2D8
     79b:      	lock
     79c:      	incq	(%rax)
     79f:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     7a4:      	addq	$0x300, %rax            # imm = 0x300
     7aa:      	lock
     7ab:      	incq	(%rax)
     7ae:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     7b3:      	addq	$0x308, %rax            # imm = 0x308
     7b9:      	lock
     7ba:      	incq	(%rax)
     7bd:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     7c2:      	addq	$0x2e8, %rax            # imm = 0x2E8
     7c8:      	lock
     7c9:      	incq	(%rax)
     7cc:      	jmp	0x6c3 <generic_retkprobe_output+0x103>

Disassembly of section kprobe/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movq	0x50(%rdi), %rax
      18:      	movq	%rax, 0xc0(%rsp)
      20:      	movl	$0x0, 0xe0(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <generic_retkprobe_event+0x32>
      32:      	leaq	0xe0(%rsp), %rsi
      3a:      	movl	$0x1, %eax
      3f:      	callq	*%rax
      41:      	xorl	%ebp, %ebp
      43:      	testq	%rax, %rax
      46:      	je	0x1dea <generic_retkprobe_event+0x1dea>
      4c:      	movq	%rax, %r15
      4f:      	movq	%rax, %rbx
      52:      	leaq	0x5ef8(%rax), %rsi
      59:      	movl	$0x0, 0x5ef8(%r15)
      64:      	movq	(%rip), %rdi            # 0x6b <generic_retkprobe_event+0x6b>
      6b:      	movl	$0x1, %eax
      70:      	callq	*%rax
      72:      	testq	%rax, %rax
      75:      	je	0x1dea <generic_retkprobe_event+0x1dea>
      7b:      	movq	%rax, %r13
      7e:      	movl	(%rax), %eax
      80:      	movq	%rax, 0x60(%rbx)
      84:      	movl	$0xe, %eax
      89:      	callq	*%rax
      8b:      	cmpq	$-0x16, %rax
      8f:      	jne	0xb1 <generic_retkprobe_event+0xb1>
      91:      	leaq	0x20(%r12), %rdx
      96:      	leaq	0x30(%rsp), %rdi
      9b:      	movl	$0x8, %ecx
      a0:      	movl	$0x4, %eax
      a5:      	movl	$0x8, %esi
      aa:      	callq	*%rax
      ac:      	movq	0x30(%rsp), %rax
      b1:      	movq	%rax, 0x68(%rbx)
      b5:      	movl	$0xe, %eax
      ba:      	callq	*%rax
      bc:      	movl	%eax, 0x7c(%rbx)
      bf:      	movq	0x60(%rbx), %rax
      c3:      	movq	0x68(%rbx), %rcx
      c7:      	movq	%rax, 0x30(%rsp)
      cc:      	movq	%rcx, 0x38(%rsp)
      d1:      	movq	(%rip), %rdi            # 0xd8 <generic_retkprobe_event+0xd8>
      d8:      	leaq	0x30(%rsp), %rsi
      dd:      	movl	$0x1, %eax
      e2:      	callq	*%rax
      e4:      	testq	%rax, %rax
      e7:      	je	0x1dea <generic_retkprobe_event+0x1dea>
      ed:      	movq	(%rax), %r14
      f0:      	movq	0x8(%rax), %rcx
      f4:      	movq	%rcx, 0x98(%rsp)
      fc:      	movq	0x10(%rax), %rax
     100:      	movq	%rax, 0xa8(%rsp)
     108:      	movq	(%rip), %rdi            # 0x10f <generic_retkprobe_event+0x10f>
     10f:      	leaq	0x30(%rsp), %rsi
     114:      	movl	$0x3, %eax
     119:      	callq	*%rax
     11b:      	movq	%r14, 0x90(%rbx)
     122:      	movl	0x58(%r13), %eax
     126:      	movl	0x5c(%r13), %r14d
     12a:      	testl	%r14d, %r14d
     12d:      	movq	%r13, 0x18(%rsp)
     132:      	je	0x1f1 <generic_retkprobe_event+0x1f1>
     138:      	movl	%eax, 0x28(%rsp)
     13c:      	movl	$0x0, 0x5ea0(%rbx)
     146:      	movq	0xc0(%rsp), %rbp
     14e:      	movl	$0x0, 0xe4(%rsp)
     159:      	movq	(%rip), %rdi            # 0x160 <generic_retkprobe_event+0x160>
     160:      	leaq	0xe4(%rsp), %rsi
     168:      	movl	$0x1, %eax
     16d:      	callq	*%rax
     16f:      	testq	%rax, %rax
     172:      	je	0x2e3 <generic_retkprobe_event+0x2e3>
     178:      	movl	0x5ea0(%rax), %ecx
     17e:      	movl	%ecx, 0x98(%rax)
     184:      	movq	$0xc, 0x5e78(%rax)
     18f:      	testl	%ecx, %ecx
     191:      	je	0x3b1 <generic_retkprobe_event+0x3b1>
     197:      	movl	$0x4, %ebp
     19c:      	addq	$0x8, %rbp
     1a0:      	movl	0x60(%r13), %eax
     1a4:      	cmpl	$0xb, %eax
     1a7:      	je	0x2f6 <generic_retkprobe_event+0x2f6>
     1ad:      	cmpl	$0xa, %eax
     1b0:      	jne	0x30c <generic_retkprobe_event+0x30c>
     1b6:      	movl	0x10(%rbx), %eax
     1b9:      	movl	%eax, 0x30(%rsp)
     1bd:      	movl	0x7c(%rbx), %eax
     1c0:      	movl	%eax, 0x34(%rsp)
     1c4:      	movq	0x18(%rbx), %rax
     1c8:      	movq	%rax, 0x38(%rsp)
     1cd:      	movq	(%rip), %rdi            # 0x1d4 <generic_retkprobe_event+0x1d4>
     1d4:      	xorl	%ecx, %ecx
     1d6:      	leaq	0xc0(%rsp), %rsi
     1de:      	leaq	0x30(%rsp), %rdx
     1e3:      	movl	$0x2, %eax
     1e8:      	xorl	%ecx, %ecx
     1ea:      	callq	*%rax
     1ec:      	jmp	0x30c <generic_retkprobe_event+0x30c>
     1f1:      	movl	$0x8, %ebp
     1f6:      	addq	$0x90, %r15
     1fd:      	cmpl	$0x3, %eax
     200:      	jne	0x326 <generic_retkprobe_event+0x326>
     206:      	movl	$0x0, (%r15,%rbp)
     20e:      	leaq	0x4(%rbp), %r14
     212:      	cmpq	$0x0, 0xa8(%rsp)
     21b:      	movq	%r12, 0xb8(%rsp)
     223:      	je	0x418 <generic_retkprobe_event+0x418>
     229:      	movq	%r14, 0x28(%rsp)
     22e:      	movq	0xc0(%rsp), %r14
     236:      	leaq	0x30(%rsp), %rdi
     23b:      	movl	$0x4, %r12d
     241:      	movl	$0x10, %ecx
     246:      	movl	$0x4, %eax
     24b:      	movq	0x98(%rsp), %rdx
     253:      	movl	$0x10, %esi
     258:      	callq	*%rax
     25a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     25f:      	testl	%eax, %eax
     261:      	js	0x1b35 <generic_retkprobe_event+0x1b35>
     267:      	movq	0x38(%rsp), %rsi
     26c:      	cmpq	%r14, %rsi
     26f:      	movq	%r14, %rax
     272:      	movq	%r14, %r13
     275:      	cmovbq	%rsi, %r13
     279:      	testq	%r14, %r14
     27c:      	cmovneq	%r13, %rsi
     280:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     285:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     28c:      	ja	0x1b35 <generic_retkprobe_event+0x1b35>
     292:      	addq	$0xc, %rbp
     296:      	movq	%rbp, 0x8(%rsp)
     29b:      	leaq	(%r15,%rbp), %rdi
     29f:      	movq	0x30(%rsp), %rcx
     2a4:      	movl	$0x4, %eax
     2a9:      	movq	0x30(%rsp), %rdx
     2ae:      	movq	%rsi, %rbp
     2b1:      	callq	*%rax
     2b3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2b8:      	testl	%eax, %eax
     2ba:      	js	0x1b35 <generic_retkprobe_event+0x1b35>
     2c0:      	movq	%rbp, %rdx
     2c3:      	testq	%r14, %r14
     2c6:      	je	0xce3 <generic_retkprobe_event+0xce3>
     2cc:      	subq	%r13, %r14
     2cf:      	movq	%r14, (%rsp)
     2d3:      	movq	0x28(%rsp), %r14
     2d8:      	jne	0xcee <generic_retkprobe_event+0xcee>
     2de:      	jmp	0x41b <generic_retkprobe_event+0x41b>
     2e3:      	xorl	%ebp, %ebp
     2e5:      	addq	$0x8, %rbp
     2e9:      	movl	0x60(%r13), %eax
     2ed:      	cmpl	$0xb, %eax
     2f0:      	jne	0x1ad <generic_retkprobe_event+0x1ad>
     2f6:      	movq	(%rip), %rdi            # 0x2fd <generic_retkprobe_event+0x2fd>
     2fd:      	leaq	0xc0(%rsp), %rsi
     305:      	movl	$0x3, %eax
     30a:      	callq	*%rax
     30c:      	andl	$0x1fff, %ebp           # imm = 0x1FFF
     312:      	movl	0x28(%rsp), %eax
     316:      	addq	$0x90, %r15
     31d:      	cmpl	$0x3, %eax
     320:      	je	0x206 <generic_retkprobe_event+0x206>
     326:      	cmpl	$0x2, %eax
     329:      	jne	0x1b51 <generic_retkprobe_event+0x1b51>
     32f:      	movq	%rbx, 0x8(%rsp)
     334:      	movq	%r12, %rbx
     337:      	movl	$0x0, (%r15,%rbp)
     33f:      	movq	0xc0(%rsp), %r14
     347:      	cmpq	$0xfff, %r14            # imm = 0xFFF
     34e:      	movl	$0xfff, %r12d           # imm = 0xFFF
     354:      	cmovbq	%r14, %r12
     358:      	leaq	(%r15,%rbp), %rdi
     35c:      	addq	$0xc, %rdi
     360:      	movl	$0x4, %eax
     365:      	movq	0x98(%rsp), %rdx
     36d:      	leaq	0x4(%rbp), %r13
     371:      	addq	%rbp, %r15
     374:      	addq	$0x4, %r15
     378:      	movl	$0x4, %ebp
     37d:      	movl	%r12d, %esi
     380:      	callq	*%rax
     382:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     387:      	testl	%eax, %eax
     389:      	js	0x399 <generic_retkprobe_event+0x399>
     38b:      	movl	%r12d, 0x4(%r15)
     38f:      	addq	$0x8, %r12
     393:      	movl	%r14d, %ecx
     396:      	movq	%r12, %rbp
     399:      	addq	%r13, %rbp
     39c:      	movl	%ecx, (%r15)
     39f:      	movq	%rbx, %r12
     3a2:      	movq	0x18(%rsp), %r13
     3a7:      	movq	0x8(%rsp), %rbx
     3ac:      	jmp	0x1b51 <generic_retkprobe_event+0x1b51>
     3b1:      	leaq	0x9c(%rax), %r13
     3b8:      	movq	%rbp, 0x30(%rsp)
     3bd:      	movq	$0x0, 0x70(%rsp)
     3c6:      	cmpl	$0x17, %r14d
     3ca:      	movq	%rax, (%rsp)
     3ce:      	movq	%r15, 0x20(%rsp)
     3d3:      	movq	%r12, 0xb8(%rsp)
     3db:      	jle	0x430 <generic_retkprobe_event+0x430>
     3dd:      	cmpl	$0x18, %r14d
     3e1:      	je	0x44b <generic_retkprobe_event+0x44b>
     3e3:      	cmpl	$0x25, %r14d
     3e7:      	je	0x489 <generic_retkprobe_event+0x489>
     3ed:      	cmpl	$0x2a, %r14d
     3f1:      	jne	0xb2c <generic_retkprobe_event+0xb2c>
     3f7:      	movq	$0x0, 0x88(%rsp)
     403:      	movq	%rbp, 0x90(%rsp)
     40b:      	leaq	0x88(%rsp), %rax
     413:      	jmp	0x4b6 <generic_retkprobe_event+0x4b6>
     418:      	xorl	%r13d, %r13d
     41b:      	movl	%r13d, (%r15,%r14)
     41f:      	movl	%r13d, 0x4(%r15,%r14)
     424:      	addq	$0x8, %r13
     428:      	movq	%r13, %r12
     42b:      	jmp	0x1b3e <generic_retkprobe_event+0x1b3e>
     430:      	cmpl	$0xf, %r14d
     434:      	je	0xa69 <generic_retkprobe_event+0xa69>
     43a:      	cmpl	$0x10, %r14d
     43e:      	jne	0xb2c <generic_retkprobe_event+0xb2c>
     444:      	leaq	0x10(%rsp), %r12
     449:      	jmp	0x473 <generic_retkprobe_event+0x473>
     44b:      	leaq	0x10(%rsp), %r12
     450:      	movl	$0x8, %ecx
     455:      	movl	$0x4, %eax
     45a:      	movq	0x30(%rsp), %rdx
     45f:      	movq	%r12, %rdi
     462:      	movl	$0x8, %esi
     467:      	callq	*%rax
     469:      	movq	0x10(%rsp), %rax
     46e:      	movq	%rax, 0x30(%rsp)
     473:      	leaq	0x30(%rsp), %rdx
     478:      	movl	$0x8, %ecx
     47d:      	movl	$0x4, %eax
     482:      	leaq	0x10(%rsp), %rdi
     487:      	jmp	0x4a6 <generic_retkprobe_event+0x4a6>
     489:      	addq	$0x40, %rbp
     48d:      	movq	%rbp, 0x30(%rsp)
     492:      	leaq	0x10(%rsp), %rdi
     497:      	movl	$0x8, %ecx
     49c:      	movl	$0x4, %eax
     4a1:      	movq	0x30(%rsp), %rdx
     4a6:      	movl	$0x8, %esi
     4ab:      	callq	*%rax
     4ad:      	movq	0x10(%rsp), %rax
     4b2:      	addq	$0x40, %rax
     4b6:      	movq	%rax, 0x80(%rsp)
     4be:      	movl	$0x0, 0xb4(%rsp)
     4c9:      	movq	(%rip), %rdi            # 0x4d0 <generic_retkprobe_event+0x4d0>
     4d0:      	leaq	0xb4(%rsp), %rsi
     4d8:      	movl	$0x1, %eax
     4dd:      	callq	*%rax
     4df:      	testq	%rax, %rax
     4e2:      	je	0x595 <generic_retkprobe_event+0x595>
     4e8:      	movq	%rax, %r12
     4eb:      	addq	$0x1000, %rax           # imm = 0x1000
     4f1:      	movq	%rax, 0x8(%rsp)
     4f6:      	movl	$0x23, %eax
     4fb:      	callq	*%rax
     4fd:      	leaq	0xd50(%rax), %rdx
     504:      	leaq	0xc8(%rsp), %rdi
     50c:      	movl	$0x8, %ecx
     511:      	movl	$0x4, %eax
     516:      	movl	$0x8, %esi
     51b:      	callq	*%rax
     51d:      	movq	0xc8(%rsp), %rbp
     525:      	movq	0x80(%rsp), %rax
     52d:      	leaq	0x8(%rax), %rdx
     531:      	leaq	0xd0(%rsp), %rdi
     539:      	movl	$0x8, %ecx
     53e:      	movl	$0x4, %eax
     543:      	leaq	0x18(%rbp), %rcx
     547:      	movq	%rcx, 0xf0(%rsp)
     54f:      	movl	$0x8, %esi
     554:      	movq	%rdx, 0xe8(%rsp)
     55c:      	callq	*%rax
     55e:      	movq	0xd0(%rsp), %r13
     566:      	leaq	0x10(%r13), %rdx
     56a:      	leaq	0x30(%rsp), %rdi
     56f:      	movl	$0x8, %ecx
     574:      	movl	$0x4, %eax
     579:      	movl	$0x8, %esi
     57e:      	callq	*%rax
     580:      	cmpq	$0x0, 0x30(%rsp)
     586:      	movl	$0x1000, %r14d          # imm = 0x1000
     58c:      	je	0x5a2 <generic_retkprobe_event+0x5a2>
     58e:      	movq	0x8(%rsp), %rcx
     593:      	jmp	0x5f5 <generic_retkprobe_event+0x5f5>
     595:      	xorl	%r12d, %r12d
     598:      	movq	0x18(%rsp), %r13
     59d:      	jmp	0x1491 <generic_retkprobe_event+0x1491>
     5a2:      	leaq	0x18(%r13), %rdx
     5a6:      	leaq	0x30(%rsp), %rdi
     5ab:      	movl	$0x8, %ecx
     5b0:      	movl	$0x4, %eax
     5b5:      	movl	$0x8, %esi
     5ba:      	callq	*%rax
     5bc:      	cmpq	%r13, 0x30(%rsp)
     5c1:      	movq	0x8(%rsp), %rcx
     5c6:      	je	0x5f5 <generic_retkprobe_event+0x5f5>
     5c8:      	movq	%r12, %rcx
     5cb:      	addq	$0xff6, %rcx            # imm = 0xFF6
     5d2:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     5dc:      	movq	%rax, 0xff6(%r12)
     5e4:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     5ef:      	movl	$0xff6, %r14d           # imm = 0xFF6
     5f5:      	movq	$0x0, 0x38(%rsp)
     5fe:      	movq	$0x0, 0x30(%rsp)
     607:      	movq	%r12, 0x40(%rsp)
     60c:      	movq	$0x0, 0x48(%rsp)
     615:      	movq	$0x0, 0x50(%rsp)
     61e:      	movq	$0x0, 0x58(%rsp)
     627:      	movq	%rcx, 0x8(%rsp)
     62c:      	movq	%rcx, 0x60(%rsp)
     631:      	movl	%r14d, 0x68(%rsp)
     636:      	movb	$0x0, 0x6c(%rsp)
     63b:      	addq	$0x20, %rbp
     63f:      	leaq	0x30(%rsp), %rdi
     644:      	movl	$0x8, %ecx
     649:      	movl	$0x4, %eax
     64e:      	leaq	0x38(%rsp), %r14
     653:      	leaq	0x48(%rsp), %r13
     658:      	leaq	0x50(%rsp), %r12
     65d:      	movl	$0x8, %esi
     662:      	movq	%rbp, %rdx
     665:      	callq	*%rax
     667:      	movl	$0x8, %ecx
     66c:      	movl	$0x4, %eax
     671:      	movq	0xf0(%rsp), %rdx
     679:      	movq	%r14, %rdi
     67c:      	movl	$0x8, %esi
     681:      	callq	*%rax
     683:      	movl	$0x8, %ecx
     688:      	movl	$0x4, %eax
     68d:      	movq	0xe8(%rsp), %rdx
     695:      	movq	%r13, %rdi
     698:      	movl	$0x8, %esi
     69d:      	callq	*%rax
     69f:      	movl	$0x8, %ecx
     6a4:      	movl	$0x4, %eax
     6a9:      	movq	0x80(%rsp), %rdx
     6b1:      	movq	%r12, %rdi
     6b4:      	movl	$0x8, %esi
     6b9:      	callq	*%rax
     6bb:      	movq	0x50(%rsp), %rax
     6c0:      	addq	$-0x20, %rax
     6c4:      	movq	%rax, 0x58(%rsp)
     6c9:      	movq	(%rip), %rax            # 0x6d0 <generic_retkprobe_event+0x6d0>
     6d0:      	cmpb	$0x0, (%rax)
     6d3:      	je	0x8a7 <generic_retkprobe_event+0x8a7>
     6d9:      	movl	$0x800, %ebp            # imm = 0x800
     6de:      	movl	$0x8, %r14d
     6e4:      	movq	0x48(%rsp), %r13
     6e9:      	movq	0x50(%rsp), %rdx
     6ee:      	movq	0x58(%rsp), %r12
     6f3:      	cmpq	0x30(%rsp), %r13
     6f8:      	jne	0x705 <generic_retkprobe_event+0x705>
     6fa:      	cmpq	0x38(%rsp), %rdx
     6ff:      	je	0xbd4 <generic_retkprobe_event+0xbd4>
     705:      	movl	$0x4, %eax
     70a:      	leaq	0xa0(%rsp), %rdi
     712:      	movl	$0x8, %esi
     717:      	callq	*%rax
     719:      	cmpq	0xa0(%rsp), %r13
     721:      	movl	$0x8, %r15d
     727:      	je	0x839 <generic_retkprobe_event+0x839>
     72d:      	leaq	0x18(%r13), %r14
     731:      	movl	$0x4, %eax
     736:      	leaq	0x10(%rsp), %rdi
     73b:      	movl	$0x8, %esi
     740:      	movq	%r14, %rdx
     743:      	callq	*%rax
     745:      	cmpq	%r13, 0x10(%rsp)
     74a:      	je	0x839 <generic_retkprobe_event+0x839>
     750:      	movl	$0x4, %eax
     755:      	leaq	0xd8(%rsp), %rdi
     75d:      	movl	$0x8, %esi
     762:      	movq	%r14, %rdx
     765:      	callq	*%rax
     767:      	addq	$0x20, %r13
     76b:      	movl	$0x4, %eax
     770:      	leaq	0x70(%rsp), %rdi
     775:      	movl	$0x10, %ecx
     77a:      	movl	$0x10, %esi
     77f:      	movq	%r13, %rdx
     782:      	callq	*%rax
     784:      	movq	0x40(%rsp), %r14
     789:      	movq	0x60(%rsp), %rax
     78e:      	movl	0x74(%rsp), %r12d
     793:      	subq	%r14, %rax
     796:      	movl	0x68(%rsp), %r13d
     79b:      	movl	%r12d, %edx
     79e:      	subl	%r13d, %edx
     7a1:      	movl	$0x0, %ecx
     7a6:      	cmovbl	%ecx, %edx
     7a9:      	addq	0x78(%rsp), %rdx
     7ae:      	xorl	%esi, %esi
     7b0:      	cmpl	%r12d, %r13d
     7b3:      	seta	%sil
     7b7:      	movl	%r12d, %ecx
     7ba:      	cmovbl	%r13d, %ecx
     7be:      	addl	%ecx, %esi
     7c0:      	movl	%r13d, %edi
     7c3:      	subl	%esi, %edi
     7c5:      	movl	%edi, 0x68(%rsp)
     7c9:      	subq	%rsi, %rax
     7cc:      	movq	0x20(%rsp), %r15
     7d1:      	jb	0xbd9 <generic_retkprobe_event+0xbd9>
     7d7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     7dd:      	ja	0xbd9 <generic_retkprobe_event+0xbd9>
     7e3:      	cmpl	%r12d, %r13d
     7e6:      	jbe	0x7ed <generic_retkprobe_event+0x7ed>
     7e8:      	movb	$0x2f, (%r14,%rax)
     7ed:      	xorl	%edi, %edi
     7ef:      	cmpl	%r12d, %r13d
     7f2:      	seta	%dil
     7f6:      	movzbl	%cl, %esi
     7f9:      	addq	%rax, %r14
     7fc:      	addq	%r14, %rdi
     7ff:      	movl	$0x4, %eax
     804:      	callq	*%rax
     806:      	movq	%r14, 0x60(%rsp)
     80b:      	cmpl	%r12d, %r13d
     80e:      	jbe	0xbd9 <generic_retkprobe_event+0xbd9>
     814:      	movq	0xd8(%rsp), %rax
     81c:      	movq	%rax, 0x48(%rsp)
     821:      	movq	0x18(%rsp), %r13
     826:      	movl	$0x8, %r14d
     82c:      	decl	%ebp
     82e:      	jne	0x6e4 <generic_retkprobe_event+0x6e4>
     834:      	jmp	0xbde <generic_retkprobe_event+0xbde>
     839:      	leaq	0x10(%r12), %rdx
     83e:      	movl	$0x4, %eax
     843:      	leaq	0x10(%rsp), %rdi
     848:      	movl	$0x8, %esi
     84d:      	callq	*%rax
     84f:      	movq	0x58(%rsp), %rax
     854:      	cmpq	0x10(%rsp), %rax
     859:      	movl	$0x8, %r14d
     85f:      	je	0xdc7 <generic_retkprobe_event+0xdc7>
     865:      	addq	$0x18, %r12
     869:      	movl	$0x4, %eax
     86e:      	leaq	0x48(%rsp), %rdi
     873:      	movl	$0x8, %esi
     878:      	movq	%r12, %rdx
     87b:      	callq	*%rax
     87d:      	movq	0x10(%rsp), %rax
     882:      	movq	%rax, 0x58(%rsp)
     887:      	addq	$0x20, %rax
     88b:      	movq	%rax, 0x50(%rsp)
     890:      	movq	0x18(%rsp), %r13
     895:      	movq	0x20(%rsp), %r15
     89a:      	decl	%ebp
     89c:      	jne	0x6e4 <generic_retkprobe_event+0x6e4>
     8a2:      	jmp	0xbde <generic_retkprobe_event+0xbde>
     8a7:      	movl	$0x800, %ebp            # imm = 0x800
     8ac:      	movl	$0x8, %r14d
     8b2:      	jmp	0x8bc <generic_retkprobe_event+0x8bc>
     8b4:      	decl	%ebp
     8b6:      	je	0xbde <generic_retkprobe_event+0xbde>
     8bc:      	movq	0x48(%rsp), %r13
     8c1:      	movq	0x50(%rsp), %rdx
     8c6:      	movq	0x58(%rsp), %r12
     8cb:      	cmpq	0x30(%rsp), %r13
     8d0:      	jne	0x8dd <generic_retkprobe_event+0x8dd>
     8d2:      	cmpq	0x38(%rsp), %rdx
     8d7:      	je	0xbd4 <generic_retkprobe_event+0xbd4>
     8dd:      	movl	$0x4, %eax
     8e2:      	leaq	0xa0(%rsp), %rdi
     8ea:      	movl	$0x8, %esi
     8ef:      	callq	*%rax
     8f1:      	cmpq	0xa0(%rsp), %r13
     8f9:      	movl	$0x8, %ecx
     8fe:      	je	0xa08 <generic_retkprobe_event+0xa08>
     904:      	leaq	0x18(%r13), %r14
     908:      	movl	$0x4, %eax
     90d:      	leaq	0x10(%rsp), %rdi
     912:      	movl	$0x8, %esi
     917:      	movq	%r14, %rdx
     91a:      	callq	*%rax
     91c:      	movl	$0x8, %ecx
     921:      	cmpq	%r13, 0x10(%rsp)
     926:      	je	0xa08 <generic_retkprobe_event+0xa08>
     92c:      	movl	$0x4, %eax
     931:      	leaq	0xd8(%rsp), %rdi
     939:      	movl	$0x8, %esi
     93e:      	movq	%r14, %rdx
     941:      	callq	*%rax
     943:      	addq	$0x20, %r13
     947:      	movl	$0x4, %eax
     94c:      	leaq	0x70(%rsp), %rdi
     951:      	movl	$0x10, %ecx
     956:      	movl	$0x10, %esi
     95b:      	movq	%r13, %rdx
     95e:      	callq	*%rax
     960:      	movq	0x40(%rsp), %r14
     965:      	movq	0x60(%rsp), %rax
     96a:      	movl	0x74(%rsp), %r12d
     96f:      	subq	%r14, %rax
     972:      	movl	0x68(%rsp), %r13d
     977:      	movl	%r12d, %edx
     97a:      	subl	%r13d, %edx
     97d:      	movl	$0x0, %ecx
     982:      	cmovbl	%ecx, %edx
     985:      	addq	0x78(%rsp), %rdx
     98a:      	xorl	%esi, %esi
     98c:      	cmpl	%r12d, %r13d
     98f:      	seta	%sil
     993:      	movl	%r12d, %ecx
     996:      	cmovbl	%r13d, %ecx
     99a:      	addl	%ecx, %esi
     99c:      	movl	%r13d, %edi
     99f:      	subl	%esi, %edi
     9a1:      	movl	%edi, 0x68(%rsp)
     9a5:      	subq	%rsi, %rax
     9a8:      	jb	0xbd9 <generic_retkprobe_event+0xbd9>
     9ae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     9b4:      	ja	0xbd9 <generic_retkprobe_event+0xbd9>
     9ba:      	cmpl	%r12d, %r13d
     9bd:      	jbe	0x9c4 <generic_retkprobe_event+0x9c4>
     9bf:      	movb	$0x2f, (%r14,%rax)
     9c4:      	xorl	%edi, %edi
     9c6:      	cmpl	%r12d, %r13d
     9c9:      	seta	%dil
     9cd:      	movzbl	%cl, %esi
     9d0:      	addq	%rax, %r14
     9d3:      	addq	%r14, %rdi
     9d6:      	movl	$0x4, %eax
     9db:      	callq	*%rax
     9dd:      	movq	%r14, 0x60(%rsp)
     9e2:      	cmpl	%r12d, %r13d
     9e5:      	jbe	0xbd9 <generic_retkprobe_event+0xbd9>
     9eb:      	movq	0xd8(%rsp), %rax
     9f3:      	movq	%rax, 0x48(%rsp)
     9f8:      	movq	0x18(%rsp), %r13
     9fd:      	movl	$0x8, %r14d
     a03:      	jmp	0x8b4 <generic_retkprobe_event+0x8b4>
     a08:      	leaq	0x10(%r12), %rdx
     a0d:      	movl	$0x4, %eax
     a12:      	leaq	0x10(%rsp), %rdi
     a17:      	movl	$0x8, %esi
     a1c:      	callq	*%rax
     a1e:      	movq	0x58(%rsp), %rax
     a23:      	cmpq	0x10(%rsp), %rax
     a28:      	movl	$0x8, %r14d
     a2e:      	je	0xbd4 <generic_retkprobe_event+0xbd4>
     a34:      	addq	$0x18, %r12
     a38:      	movl	$0x4, %eax
     a3d:      	leaq	0x48(%rsp), %rdi
     a42:      	movl	$0x8, %esi
     a47:      	movq	%r12, %rdx
     a4a:      	callq	*%rax
     a4c:      	movq	0x10(%rsp), %rax
     a51:      	movq	%rax, 0x58(%rsp)
     a56:      	addq	$0x20, %rax
     a5a:      	movq	%rax, 0x50(%rsp)
     a5f:      	movq	0x18(%rsp), %r13
     a64:      	jmp	0x8b4 <generic_retkprobe_event+0x8b4>
     a69:      	leaq	0x70(%rsp), %rdi
     a6e:      	leaq	0x30(%rsp), %rdx
     a73:      	movl	$0x8, %ecx
     a78:      	movl	$0x4, %eax
     a7d:      	movl	$0x8, %esi
     a82:      	callq	*%rax
     a84:      	movq	0x70(%rsp), %rax
     a89:      	movq	%rax, 0x80(%rsp)
     a91:      	testq	%rax, %rax
     a94:      	jne	0x4be <generic_retkprobe_event+0x4be>
     a9a:      	movl	$0x0, 0x88(%rsp)
     aa5:      	movq	(%rip), %rdi            # 0xaac <generic_retkprobe_event+0xaac>
     aac:      	leaq	0x88(%rsp), %rsi
     ab4:      	movl	$0x1, %eax
     ab9:      	callq	*%rax
     abb:      	testq	%rax, %rax
     abe:      	je	0xcd6 <generic_retkprobe_event+0xcd6>
     ac4:      	movq	%r13, 0x8(%rsp)
     ac9:      	xorl	%r12d, %r12d
     acc:      	cmpl	$0x19, %r14d
     ad0:      	movq	0x18(%rsp), %r13
     ad5:      	movq	(%rsp), %rcx
     ad9:      	jg	0x1017 <generic_retkprobe_event+0x1017>
     adf:      	cmpl	$0x12, %r14d
     ae3:      	jle	0x1173 <generic_retkprobe_event+0x1173>
     ae9:      	cmpl	$0x14, %r14d
     aed:      	jle	0x14d3 <generic_retkprobe_event+0x14d3>
     af3:      	cmpl	$0x15, %r14d
     af7:      	je	0x219e <generic_retkprobe_event+0x219e>
     afd:      	cmpl	$0x16, %r14d
     b01:      	je	0x2106 <generic_retkprobe_event+0x2106>
     b07:      	cmpl	$0x17, %r14d
     b0b:      	jne	0x1487 <generic_retkprobe_event+0x1487>
     b11:      	movl	$0x0, 0xa0(%rcx)
     b1b:      	movl	%ebp, 0x9c(%rcx)
     b21:      	movl	$0x8, %r12d
     b27:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
     b2c:      	cmpl	$0x2c, %r14d
     b30:      	ja	0xa9a <generic_retkprobe_event+0xa9a>
     b36:      	movl	%r14d, %eax
     b39:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     b43:      	btq	%rax, %rcx
     b47:      	jae	0xa9a <generic_retkprobe_event+0xa9a>
     b4d:      	movq	%rbp, 0x10(%rsp)
     b52:      	movl	$0x0, 0xd8(%rsp)
     b5d:      	movq	(%rip), %rdi            # 0xb64 <generic_retkprobe_event+0xb64>
     b64:      	leaq	0xd8(%rsp), %rsi
     b6c:      	movl	$0x1, %eax
     b71:      	callq	*%rax
     b73:      	testq	%rax, %rax
     b76:      	je	0xcd6 <generic_retkprobe_event+0xcd6>
     b7c:      	movq	%r13, %rbp
     b7f:      	xorl	%r12d, %r12d
     b82:      	cmpl	$0x10, %r14d
     b86:      	jle	0xddb <generic_retkprobe_event+0xddb>
     b8c:      	cmpl	$0x1e, %r14d
     b90:      	movq	0x18(%rsp), %r13
     b95:      	jle	0xf5b <generic_retkprobe_event+0xf5b>
     b9b:      	cmpl	$0x26, %r14d
     b9f:      	jg	0x104d <generic_retkprobe_event+0x104d>
     ba5:      	leal	-0x1f(%r14), %eax
     ba9:      	cmpl	$0x2, %eax
     bac:      	jae	0x15a7 <generic_retkprobe_event+0x15a7>
     bb2:      	leaq	0x10(%rsp), %rdx
     bb7:      	movl	$0x4, %r12d
     bbd:      	movl	$0x1, %ecx
     bc2:      	movl	$0x4, %eax
     bc7:      	movq	%rbp, %rdi
     bca:      	movl	$0x1, %esi
     bcf:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
     bd4:      	movb	$0x1, 0x6c(%rsp)
     bd9:      	movq	0x18(%rsp), %r13
     bde:      	movq	0x60(%rsp), %rax
     be3:      	movq	0x8(%rsp), %rdx
     be8:      	xorl	%ebp, %ebp
     bea:      	cmpq	%rdx, %rax
     bed:      	je	0xc1d <generic_retkprobe_event+0xc1d>
     bef:      	cmpb	$0x0, 0x6c(%rsp)
     bf4:      	sete	%cl
     bf7:      	movl	0x68(%rsp), %edx
     bfb:      	movl	$0x1000, %r12d          # imm = 0x1000
     c01:      	subl	%edx, %r12d
     c04:      	testl	%edx, %edx
     c06:      	cmovlel	%edx, %r12d
     c0a:      	testq	%rax, %rax
     c0d:      	je	0xcce <generic_retkprobe_event+0xcce>
     c13:      	movb	%cl, %bpl
     c16:      	addl	%ebp, %ebp
     c18:      	movq	%rax, %rdx
     c1b:      	jmp	0xc20 <generic_retkprobe_event+0xc20>
     c1d:      	xorl	%r12d, %r12d
     c20:      	movq	(%rsp), %r14
     c24:      	movq	%r14, %rdi
     c27:      	addq	$0xa0, %rdi
     c2e:      	andl	$0xfff, %r12d           # imm = 0xFFF
     c35:      	movl	$0x4, %eax
     c3a:      	movl	%r12d, %esi
     c3d:      	callq	*%rax
     c3f:      	movl	%r12d, 0x9c(%r14)
     c46:      	leaq	0x30(%rsp), %rdi
     c4b:      	movl	$0x8, %ecx
     c50:      	movl	$0x4, %eax
     c55:      	movq	0xe8(%rsp), %rdx
     c5d:      	movl	$0x8, %esi
     c62:      	callq	*%rax
     c64:      	movq	0x30(%rsp), %rcx
     c69:      	addq	$0x30, %rcx
     c6d:      	leaq	0x70(%rsp), %rdi
     c72:      	movl	$0x8, %edx
     c77:      	movl	$0x4, %eax
     c7c:      	movq	0x30(%rsp), %rdx
     c81:      	addq	$0x30, %rdx
     c85:      	movl	$0x8, %esi
     c8a:      	callq	*%rax
     c8c:      	movq	0x70(%rsp), %rcx
     c91:      	leaq	0x10(%rsp), %rdi
     c96:      	movl	$0x2, %edx
     c9b:      	movl	$0x4, %eax
     ca0:      	movq	0x70(%rsp), %rdx
     ca5:      	movl	$0x2, %esi
     caa:      	callq	*%rax
     cac:      	movq	%r14, %rcx
     caf:      	movl	%ebp, 0xa0(%r14,%r12)
     cb7:      	movzwl	0x10(%rsp), %eax
     cbc:      	movw	%ax, 0xa4(%r14,%r12)
     cc5:      	addl	$0xa, %r12d
     cc9:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
     cce:      	xorl	%r12d, %r12d
     cd1:      	jmp	0x1491 <generic_retkprobe_event+0x1491>
     cd6:      	xorl	%r12d, %r12d
     cd9:      	movq	0x18(%rsp), %r13
     cde:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
     ce3:      	xorl	%eax, %eax
     ce5:      	movq	%rax, (%rsp)
     ce9:      	movq	0x28(%rsp), %r14
     cee:      	cmpq	$0x1, 0xa8(%rsp)
     cf7:      	jne	0xd01 <generic_retkprobe_event+0xd01>
     cf9:      	movq	%rdx, %r13
     cfc:      	jmp	0x41b <generic_retkprobe_event+0x41b>
     d01:      	movq	0x98(%rsp), %rax
     d09:      	leaq	0x10(%rax), %rdx
     d0d:      	leaq	0x30(%rsp), %rdi
     d12:      	movl	$0x4, %r12d
     d18:      	movl	$0x10, %ecx
     d1d:      	movl	$0x4, %eax
     d22:      	movl	$0x10, %esi
     d27:      	callq	*%rax
     d29:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     d2e:      	testl	%eax, %eax
     d30:      	js	0x1b3a <generic_retkprobe_event+0x1b3a>
     d36:      	movq	0x38(%rsp), %rsi
     d3b:      	movq	(%rsp), %rax
     d3f:      	cmpq	%rax, %rsi
     d42:      	movq	%rax, %r13
     d45:      	cmovbq	%rsi, %r13
     d49:      	testq	%rax, %rax
     d4c:      	cmovneq	%r13, %rsi
     d50:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     d55:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     d5c:      	ja	0x1b3a <generic_retkprobe_event+0x1b3a>
     d62:      	movq	0x8(%rsp), %rax
     d67:      	addq	%rbp, %rax
     d6a:      	movq	%rax, 0x8(%rsp)
     d6f:      	leaq	(%r15,%rax), %rdi
     d73:      	movq	0x30(%rsp), %rcx
     d78:      	movl	$0x4, %eax
     d7d:      	movq	0x30(%rsp), %rdx
     d82:      	movq	%rsi, 0x80(%rsp)
     d8a:      	movq	0x80(%rsp), %rsi
     d92:      	callq	*%rax
     d94:      	movq	0x80(%rsp), %rdx
     d9c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     da1:      	testl	%eax, %eax
     da3:      	js	0x1b3a <generic_retkprobe_event+0x1b3a>
     da9:      	addq	%rdx, %rbp
     dac:      	movq	(%rsp), %r14
     db0:      	testq	%r14, %r14
     db3:      	je	0x1a60 <generic_retkprobe_event+0x1a60>
     db9:      	subq	%r13, %r14
     dbc:      	jne	0x1a63 <generic_retkprobe_event+0x1a63>
     dc2:      	jmp	0x1dfe <generic_retkprobe_event+0x1dfe>
     dc7:      	movb	$0x1, 0x6c(%rsp)
     dcc:      	movq	0x18(%rsp), %r13
     dd1:      	movq	0x20(%rsp), %r15
     dd6:      	jmp	0xbde <generic_retkprobe_event+0xbde>
     ddb:      	cmpl	$0x9, %r14d
     ddf:      	movq	0x18(%rsp), %r13
     de4:      	jg	0xf8c <generic_retkprobe_event+0xf8c>
     dea:      	cmpl	$0x4, %r14d
     dee:      	movq	(%rsp), %rcx
     df2:      	jle	0x11c9 <generic_retkprobe_event+0x11c9>
     df8:      	cmpl	$0x5, %r14d
     dfc:      	je	0x17a1 <generic_retkprobe_event+0x17a1>
     e02:      	cmpl	$0x6, %r14d
     e06:      	je	0xff4 <generic_retkprobe_event+0xff4>
     e0c:      	movq	%rax, 0x8(%rsp)
     e11:      	cmpl	$0x7, %r14d
     e15:      	jne	0x1487 <generic_retkprobe_event+0x1487>
     e1b:      	movq	0x10(%rsp), %r12
     e20:      	movq	%r12, 0xc4(%rcx)
     e27:      	leaq	0xc2(%rcx), %rdi
     e2e:      	leaq	0x10(%r12), %rdx
     e33:      	movq	%rcx, %r14
     e36:      	movl	$0x2, %ecx
     e3b:      	movl	$0x4, %eax
     e40:      	movl	$0x2, %esi
     e45:      	callq	*%rax
     e47:      	leaq	0xd6(%r14), %rdi
     e4e:      	leaq	0x12(%r12), %rdx
     e53:      	movl	$0x1, %ecx
     e58:      	movl	$0x4, %eax
     e5d:      	movl	$0x1, %esi
     e62:      	callq	*%rax
     e64:      	leaq	0xd4(%r14), %rdi
     e6b:      	leaq	0x226(%r12), %rdx
     e73:      	movl	$0x2, %ecx
     e78:      	movl	$0x4, %eax
     e7d:      	movl	$0x2, %esi
     e82:      	callq	*%rax
     e84:      	leaq	0xc0(%r14), %rdi
     e8b:      	leaq	0x224(%r12), %rdx
     e93:      	movl	$0x2, %ecx
     e98:      	movl	$0x4, %eax
     e9d:      	movl	$0x2, %esi
     ea2:      	callq	*%rax
     ea4:      	leaq	0xcc(%r14), %rdi
     eab:      	leaq	0x21c(%r12), %rdx
     eb3:      	movl	$0x4, %ecx
     eb8:      	movl	$0x4, %eax
     ebd:      	movl	$0x4, %esi
     ec2:      	callq	*%rax
     ec4:      	leaq	0xd0(%r14), %rdi
     ecb:      	leaq	0x218(%r12), %rdx
     ed3:      	movl	$0x4, %ecx
     ed8:      	movl	$0x4, %eax
     edd:      	movl	$0x4, %esi
     ee2:      	callq	*%rax
     ee4:      	leaq	0xac(%r14), %r13
     eeb:      	movq	%rbp, %rax
     eee:      	movq	$0x0, (%rbp)
     ef6:      	movq	$0x0, 0x8(%rbp)
     efe:      	movq	$0x0, 0x10(%rbp)
     f06:      	movq	$0x0, 0x18(%rbp)
     f0e:      	movzwl	0xc2(%r14), %eax
     f16:      	cmpl	$0xa, %eax
     f19:      	je	0x2519 <generic_retkprobe_event+0x2519>
     f1f:      	cmpl	$0x2, %eax
     f22:      	jne	0x254b <generic_retkprobe_event+0x254b>
     f28:      	leaq	0x4(%r12), %rdx
     f2d:      	movl	$0x4, %ecx
     f32:      	movl	$0x4, %eax
     f37:      	movq	%rbp, %rdi
     f3a:      	movl	$0x4, %esi
     f3f:      	callq	*%rax
     f41:      	movl	$0x4, %ecx
     f46:      	movl	$0x4, %eax
     f4b:      	movq	%r13, %rdi
     f4e:      	movl	$0x4, %esi
     f53:      	movq	%r12, %rdx
     f56:      	jmp	0x2549 <generic_retkprobe_event+0x2549>
     f5b:      	cmpl	$0x1c, %r14d
     f5f:      	jg	0x11a7 <generic_retkprobe_event+0x11a7>
     f65:      	cmpl	$0x11, %r14d
     f69:      	je	0x15e4 <generic_retkprobe_event+0x15e4>
     f6f:      	cmpl	$0x19, %r14d
     f73:      	je	0x16b0 <generic_retkprobe_event+0x16b0>
     f79:      	cmpl	$0x1c, %r14d
     f7d:      	movq	(%rsp), %rcx
     f81:      	je	0x11d9 <generic_retkprobe_event+0x11d9>
     f87:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
     f8c:      	leal	-0xa(%r14), %eax
     f90:      	cmpl	$0x2, %eax
     f93:      	movq	(%rsp), %rcx
     f97:      	jb	0x11d9 <generic_retkprobe_event+0x11d9>
     f9d:      	leal	-0xc(%r14), %eax
     fa1:      	cmpl	$0x2, %eax
     fa4:      	jb	0x11fb <generic_retkprobe_event+0x11fb>
     faa:      	cmpl	$0xe, %r14d
     fae:      	jne	0x1487 <generic_retkprobe_event+0x1487>
     fb4:      	leaq	0x30(%rsp), %rdi
     fb9:      	leaq	0x10(%rsp), %r14
     fbe:      	movl	$0x8, %ecx
     fc3:      	movl	$0x4, %eax
     fc8:      	movl	$0x8, %esi
     fcd:      	movq	%r14, %rdx
     fd0:      	callq	*%rax
     fd2:      	movq	0x30(%rsp), %rcx
     fd7:      	movl	$0x8, %edx
     fdc:      	movl	$0x4, %eax
     fe1:      	movq	0x30(%rsp), %rdx
     fe6:      	movq	%r14, %rdi
     fe9:      	movl	$0x8, %esi
     fee:      	callq	*%rax
     ff0:      	movq	(%rsp), %rcx
     ff4:      	movq	0x10(%rsp), %rdx
     ff9:      	movq	%rcx, %rdi
     ffc:      	addq	$0xa0, %rdi
    1003:      	movl	$0x1001, %ecx           # imm = 0x1001
    1008:      	movl	$0x2d, %eax
    100d:      	movl	$0x1001, %esi           # imm = 0x1001
    1012:      	jmp	0x19a6 <generic_retkprobe_event+0x19a6>
    1017:      	cmpl	$0x20, %r14d
    101b:      	jle	0x139e <generic_retkprobe_event+0x139e>
    1021:      	leal	-0x21(%r14), %edx
    1025:      	cmpl	$0x4, %edx
    1028:      	jae	0x121d <generic_retkprobe_event+0x121d>
    102e:      	movl	$0x8, %r12d
    1034:      	movl	$0x8, %ecx
    1039:      	movl	$0x4, %eax
    103e:      	movq	0x8(%rsp), %rdi
    1043:      	movl	$0x8, %esi
    1048:      	jmp	0x147e <generic_retkprobe_event+0x147e>
    104d:      	cmpl	$0x27, %r14d
    1051:      	je	0x1982 <generic_retkprobe_event+0x1982>
    1057:      	cmpl	$0x28, %r14d
    105b:      	je	0x19c5 <generic_retkprobe_event+0x19c5>
    1061:      	cmpl	$0x2c, %r14d
    1065:      	movq	(%rsp), %rcx
    1069:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    106f:      	movq	0x10(%rsp), %r12
    1074:      	movb	$0x0, 0x30(%rsp)
    1079:      	movq	$0x0, 0x68(%rbp)
    1081:      	movq	$0x0, 0x60(%rbp)
    1089:      	movq	$0x0, 0x58(%rbp)
    1091:      	movq	$0x0, 0x50(%rbp)
    1099:      	movq	$0x0, 0x48(%rbp)
    10a1:      	movq	$0x0, 0x40(%rbp)
    10a9:      	movq	$0x0, 0x38(%rbp)
    10b1:      	movq	$0x0, 0x30(%rbp)
    10b9:      	movq	$0x0, 0x28(%rbp)
    10c1:      	movq	$0x0, 0x20(%rbp)
    10c9:      	movq	$0x0, 0x18(%rbp)
    10d1:      	movq	$0x0, 0x10(%rbp)
    10d9:      	movq	$0x0, 0x8(%rbp)
    10e1:      	movq	$0x0, (%rbp)
    10e9:      	movl	$0x2, %ecx
    10ee:      	movl	$0x4, %eax
    10f3:      	movq	%rbp, %rdi
    10f6:      	movl	$0x2, %esi
    10fb:      	movq	%r12, %rdx
    10fe:      	callq	*%rax
    1100:      	testq	%rax, %rax
    1103:      	js	0x2785 <generic_retkprobe_event+0x2785>
    1109:      	leaq	0x2(%r12), %r13
    110e:      	leaq	0x30(%rsp), %rdi
    1113:      	movl	$0x1, %ecx
    1118:      	movl	$0x4, %eax
    111d:      	movl	$0x1, %esi
    1122:      	movq	%r13, %rdx
    1125:      	callq	*%rax
    1127:      	testq	%rax, %rax
    112a:      	js	0x2785 <generic_retkprobe_event+0x2785>
    1130:      	movq	(%rsp), %rax
    1134:      	movq	%rax, %rdi
    1137:      	addq	$0xa0, %rdi
    113e:      	cmpb	$0x0, 0x30(%rsp)
    1143:      	sete	0x9e(%rax)
    114a:      	je	0x275a <generic_retkprobe_event+0x275a>
    1150:      	movl	$0x6c, %ecx
    1155:      	movl	$0x2d, %eax
    115a:      	movl	$0x6c, %esi
    115f:      	movq	%r13, %rdx
    1162:      	callq	*%rax
    1164:      	testl	%eax, %eax
    1166:      	js	0x2785 <generic_retkprobe_event+0x2785>
    116c:      	decb	%al
    116e:      	jmp	0x277b <generic_retkprobe_event+0x277b>
    1173:      	cmpl	$0x7, %r14d
    1177:      	jg	0x145f <generic_retkprobe_event+0x145f>
    117d:      	cmpl	$0x2, %r14d
    1181:      	je	0x1e0b <generic_retkprobe_event+0x1e0b>
    1187:      	cmpl	$0x3, %r14d
    118b:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    1191:      	movq	$0x0, 0x9c(%rax)
    119c:      	movl	$0x8, %r12d
    11a2:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    11a7:      	leaq	0x10(%rsp), %rdx
    11ac:      	movl	$0x4, %r12d
    11b2:      	movl	$0x2, %ecx
    11b7:      	movl	$0x4, %eax
    11bc:      	movq	%rbp, %rdi
    11bf:      	movl	$0x2, %esi
    11c4:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    11c9:      	cmpl	$0x1, %r14d
    11cd:      	je	0x11fb <generic_retkprobe_event+0x11fb>
    11cf:      	cmpl	$0x4, %r14d
    11d3:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    11d9:      	movl	$0x8, %r12d
    11df:      	leaq	0x10(%rsp), %rdx
    11e4:      	movl	$0x8, %ecx
    11e9:      	movl	$0x4, %eax
    11ee:      	movq	%rbp, %rdi
    11f1:      	movl	$0x8, %esi
    11f6:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    11fb:      	leaq	0x10(%rsp), %rdx
    1200:      	movl	$0x4, %r12d
    1206:      	movl	$0x4, %ecx
    120b:      	movl	$0x4, %eax
    1210:      	movq	%rbp, %rdi
    1213:      	movl	$0x4, %esi
    1218:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    121d:      	cmpl	$0x2b, %r14d
    1221:      	je	0x22a9 <generic_retkprobe_event+0x22a9>
    1227:      	cmpl	$0x29, %r14d
    122b:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    1231:      	movq	%rax, 0x80(%rsp)
    1239:      	addq	$0x18, %rbp
    123d:      	leaq	0x30(%rsp), %rdi
    1242:      	movl	$0x4, %r14d
    1248:      	movl	$0x8, %ecx
    124d:      	movl	$0x4, %eax
    1252:      	movl	$0x8, %esi
    1257:      	movq	%rbp, %rdx
    125a:      	callq	*%rax
    125c:      	movq	0x30(%rsp), %r12
    1261:      	testq	%r12, %r12
    1264:      	je	0x2821 <generic_retkprobe_event+0x2821>
    126a:      	movq	(%rsp), %rbp
    126e:      	movq	%r12, 0xc4(%rbp)
    1275:      	leaq	0xc2(%rbp), %rdi
    127c:      	leaq	0x10(%r12), %rdx
    1281:      	movl	$0x2, %ecx
    1286:      	movl	$0x4, %eax
    128b:      	movl	$0x2, %esi
    1290:      	callq	*%rax
    1292:      	leaq	0xd6(%rbp), %rdi
    1299:      	leaq	0x12(%r12), %rdx
    129e:      	movl	$0x1, %ecx
    12a3:      	movl	$0x4, %eax
    12a8:      	movl	$0x1, %esi
    12ad:      	callq	*%rax
    12af:      	leaq	0xd4(%rbp), %rdi
    12b6:      	leaq	0x226(%r12), %rdx
    12be:      	movl	$0x2, %ecx
    12c3:      	movl	$0x4, %eax
    12c8:      	movl	$0x2, %esi
    12cd:      	callq	*%rax
    12cf:      	leaq	0xc0(%rbp), %rdi
    12d6:      	leaq	0x224(%r12), %rdx
    12de:      	movl	$0x2, %ecx
    12e3:      	movl	$0x4, %eax
    12e8:      	movl	$0x2, %esi
    12ed:      	callq	*%rax
    12ef:      	leaq	0xcc(%rbp), %rdi
    12f6:      	leaq	0x21c(%r12), %rdx
    12fe:      	movl	$0x4, %eax
    1303:      	movl	$0x4, %esi
    1308:      	callq	*%rax
    130a:      	leaq	0xd0(%rbp), %rdi
    1311:      	leaq	0x218(%r12), %rdx
    1319:      	movl	$0x4, %eax
    131e:      	movl	$0x4, %esi
    1323:      	callq	*%rax
    1325:      	leaq	0xac(%rbp), %r13
    132c:      	movq	0x8(%rsp), %rax
    1331:      	movq	$0x0, (%rax)
    1338:      	movq	$0x0, 0x8(%rax)
    1340:      	movq	$0x0, 0x10(%rax)
    1348:      	movq	$0x0, 0x18(%rax)
    1350:      	movzwl	0xc2(%rbp), %eax
    1357:      	cmpl	$0xa, %eax
    135a:      	je	0x2795 <generic_retkprobe_event+0x2795>
    1360:      	cmpl	$0x2, %eax
    1363:      	jne	0x27c9 <generic_retkprobe_event+0x27c9>
    1369:      	leaq	0x4(%r12), %rdx
    136e:      	movl	$0x4, %ecx
    1373:      	movl	$0x4, %eax
    1378:      	movq	0x8(%rsp), %rdi
    137d:      	movl	$0x4, %esi
    1382:      	callq	*%rax
    1384:      	movl	$0x4, %ecx
    1389:      	movl	$0x4, %eax
    138e:      	movq	%r13, %rdi
    1391:      	movl	$0x4, %esi
    1396:      	movq	%r12, %rdx
    1399:      	jmp	0x27c7 <generic_retkprobe_event+0x27c7>
    139e:      	cmpl	$0x1a, %r14d
    13a2:      	je	0x2353 <generic_retkprobe_event+0x2353>
    13a8:      	cmpl	$0x1b, %r14d
    13ac:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    13b2:      	movq	0x8(%rsp), %rax
    13b7:      	movq	$0x0, 0x48(%rax)
    13bf:      	movq	$0x0, 0x40(%rax)
    13c7:      	movq	$0x0, 0x38(%rax)
    13cf:      	movq	$0x0, 0x30(%rax)
    13d7:      	movq	$0x0, 0x28(%rax)
    13df:      	movq	$0x0, 0x20(%rax)
    13e7:      	movq	$0x0, 0x18(%rax)
    13ef:      	movq	$0x0, 0x10(%rax)
    13f7:      	movq	$0x0, 0x8(%rax)
    13ff:      	movq	$0x0, (%rax)
    1406:      	leaq	0xac(%rcx), %rdi
    140d:      	leaq	0x18(%rbp), %rdx
    1411:      	movl	$0x3f, %ecx
    1416:      	movl	$0x2d, %eax
    141b:      	movl	$0x3f, %esi
    1420:      	callq	*%rax
    1422:      	testq	%rax, %rax
    1425:      	js	0x272c <generic_retkprobe_event+0x272c>
    142b:      	movq	(%rsp), %r14
    142f:      	movq	%r14, %rdi
    1432:      	addq	$0xa4, %rdi
    1439:      	addq	$0x348, %rbp            # imm = 0x348
    1440:      	movl	$0x8, %ecx
    1445:      	movl	$0x4, %eax
    144a:      	movl	$0x8, %esi
    144f:      	movq	%rbp, %rdx
    1452:      	callq	*%rax
    1454:      	movq	%r14, %rcx
    1457:      	movl	$0x50, %r12d
    145d:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    145f:      	cmpl	$0x8, %r14d
    1463:      	je	0x1eb8 <generic_retkprobe_event+0x1eb8>
    1469:      	cmpl	$0x12, %r14d
    146d:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    146f:      	xorl	%r12d, %r12d
    1472:      	movl	$0x4, %eax
    1477:      	movq	0x8(%rsp), %rdi
    147c:      	xorl	%esi, %esi
    147e:      	movq	%rbp, %rdx
    1481:      	callq	*%rax
    1483:      	movq	(%rsp), %rcx
    1487:      	testl	%r12d, %r12d
    148a:      	movl	$0x4, %ebp
    148f:      	js	0x14a1 <generic_retkprobe_event+0x14a1>
    1491:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    1498:      	addq	$0x4, %r12
    149c:      	movq	%r12, %rbp
    149f:      	jmp	0x14b5 <generic_retkprobe_event+0x14b5>
    14a1:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    14ab:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    14b5:      	movq	0xb8(%rsp), %r12
    14bd:      	addq	$0x8, %rbp
    14c1:      	movl	0x60(%r13), %eax
    14c5:      	cmpl	$0xb, %eax
    14c8:      	jne	0x1ad <generic_retkprobe_event+0x1ad>
    14ce:      	jmp	0x2f6 <generic_retkprobe_event+0x2f6>
    14d3:      	cmpl	$0x13, %r14d
    14d7:      	je	0x224a <generic_retkprobe_event+0x224a>
    14dd:      	cmpl	$0x14, %r14d
    14e1:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    14e3:      	movq	$0x0, 0x30(%rsp)
    14ec:      	leaq	0x110(%rbp), %rdx
    14f3:      	leaq	0x30(%rsp), %rdi
    14f8:      	movl	$0x8, %ecx
    14fd:      	movl	$0x4, %eax
    1502:      	leaq	0xd8(%rbp), %r12
    1509:      	movl	$0x8, %esi
    150e:      	callq	*%rax
    1510:      	movq	0x30(%rsp), %rcx
    1515:      	movl	$0x80, %edx
    151a:      	movl	$0x2d, %eax
    151f:      	movq	0x8(%rsp), %rdi
    1524:      	movq	0x30(%rsp), %rdx
    1529:      	movl	$0x80, %esi
    152e:      	callq	*%rax
    1530:      	movq	(%rsp), %rax
    1534:      	leaq	0x12c(%rax), %rdi
    153b:      	movl	$0x4, %ecx
    1540:      	movl	$0x4, %eax
    1545:      	movl	$0x4, %esi
    154a:      	movq	%r12, %rdx
    154d:      	callq	*%rax
    154f:      	movq	(%rsp), %rax
    1553:      	leaq	0x11c(%rax), %rdi
    155a:      	leaq	0xe0(%rbp), %rdx
    1561:      	movl	$0x8, %ecx
    1566:      	movl	$0x4, %eax
    156b:      	movl	$0x8, %esi
    1570:      	callq	*%rax
    1572:      	movq	(%rsp), %rdi
    1576:      	addq	$0x124, %rdi            # imm = 0x124
    157d:      	addq	$0x118, %rbp            # imm = 0x118
    1584:      	movl	$0x8, %ecx
    1589:      	movl	$0x4, %eax
    158e:      	movl	$0x8, %esi
    1593:      	movq	%rbp, %rdx
    1596:      	callq	*%rax
    1598:      	movq	(%rsp), %rcx
    159c:      	movl	$0x98, %r12d
    15a2:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    15a7:      	cmpl	$0x26, %r14d
    15ab:      	movq	(%rsp), %rcx
    15af:      	jne	0x1487 <generic_retkprobe_event+0x1487>
    15b5:      	movq	0x10(%rsp), %rsi
    15ba:      	movzwl	%si, %edx
    15bd:      	addq	0xb8(%rsp), %rdx
    15c5:      	shrl	$0x10, %esi
    15c8:      	andl	$0xfff, %esi            # imm = 0xFFF
    15ce:      	movq	%rcx, %rdi
    15d1:      	addq	$0xa0, %rdi
    15d8:      	incl	%esi
    15da:      	movl	$0x2d, %eax
    15df:      	jmp	0x19a6 <generic_retkprobe_event+0x19a6>
    15e4:      	movq	$0x0, 0x38(%rsp)
    15ed:      	movq	$0x0, 0x30(%rsp)
    15f6:      	movl	$0xe, %eax
    15fb:      	callq	*%rax
    15fd:      	shrq	$0x20, %rax
    1601:      	movq	%rax, 0x30(%rsp)
    1606:      	leaq	0x70(%rsp), %rdi
    160b:      	leaq	0x10(%rsp), %rdx
    1610:      	movl	$0x4, %ecx
    1615:      	movl	$0x4, %eax
    161a:      	movl	$0x4, %r14d
    1620:      	movl	$0x4, %esi
    1625:      	callq	*%rax
    1627:      	movl	0x70(%rsp), %eax
    162b:      	movl	%eax, 0x38(%rsp)
    162f:      	movq	(%rip), %rdi            # 0x1636 <generic_retkprobe_event+0x1636>
    1636:      	leaq	0x30(%rsp), %rsi
    163b:      	movl	$0x1, %eax
    1640:      	callq	*%rax
    1642:      	testq	%rax, %rax
    1645:      	je	0x23d1 <generic_retkprobe_event+0x23d1>
    164b:      	movl	(%rax), %r12d
    164e:      	leaq	0x70(%rsp), %rdx
    1653:      	movq	%rax, %r13
    1656:      	movl	$0x4, %eax
    165b:      	movq	%rbp, %rdi
    165e:      	movl	$0x4, %esi
    1663:      	callq	*%rax
    1665:      	andl	$0xfff, %r12d           # imm = 0xFFF
    166c:      	movq	(%rsp), %rdi
    1670:      	addq	$0xa0, %rdi
    1677:      	leaq	0x4(%r12), %rsi
    167c:      	movl	$0x4, %eax
    1681:      	movq	%r13, %rdx
    1684:      	callq	*%rax
    1686:      	leaq	(%r12,%rbp), %rdi
    168a:      	addq	$0x8, %rdi
    168e:      	leaq	(%r12,%r13), %rdx
    1692:      	addq	$0x4, %rdx
    1696:      	movl	$0x4, %eax
    169b:      	movl	$0x4, %esi
    16a0:      	callq	*%rax
    16a2:      	addq	$0xc, %r12
    16a6:      	movq	0x18(%rsp), %r13
    16ab:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    16b0:      	movq	%rax, %r14
    16b3:      	movq	0x10(%rsp), %r13
    16b8:      	leaq	0xa0(%rsp), %rdi
    16c0:      	movl	$0x1, %ecx
    16c5:      	movl	$0x4, %eax
    16ca:      	movl	$0x1, %esi
    16cf:      	movq	%r13, %rdx
    16d2:      	callq	*%rax
    16d4:      	movzbl	0xa0(%rsp), %eax
    16dc:      	testl	%eax, %eax
    16de:      	je	0x23e2 <generic_retkprobe_event+0x23e2>
    16e4:      	cmpl	$0x1, %eax
    16e7:      	jne	0x25ed <generic_retkprobe_event+0x25ed>
    16ed:      	addq	$0x10, %r13
    16f1:      	leaq	0x30(%rsp), %rdi
    16f6:      	movl	$0x4, %r12d
    16fc:      	movl	$0x8, %ecx
    1701:      	movl	$0x4, %eax
    1706:      	movl	$0x8, %esi
    170b:      	movq	%r13, %rdx
    170e:      	callq	*%rax
    1710:      	movq	0x30(%rsp), %rdx
    1715:      	leaq	0x70(%rsp), %rdi
    171a:      	movl	$0x8, %ecx
    171f:      	movl	$0x4, %eax
    1724:      	movl	$0x8, %esi
    1729:      	callq	*%rax
    172b:      	movq	0x30(%rsp), %rdx
    1730:      	addq	$0x8, %rdx
    1734:      	leaq	0x88(%rsp), %rdi
    173c:      	movl	$0x8, %ecx
    1741:      	movl	$0x4, %eax
    1746:      	movl	$0x8, %esi
    174b:      	callq	*%rax
    174d:      	movq	0x70(%rsp), %rdx
    1752:      	movq	0x88(%rsp), %rbp
    175a:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1761:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1767:      	cmovbq	%rbp, %r13
    176b:      	movq	%r14, %rdi
    176e:      	addq	$0xa4, %rdi
    1775:      	movl	$0x4, %eax
    177a:      	movl	%r13d, %esi
    177d:      	callq	*%rax
    177f:      	testl	%eax, %eax
    1781:      	js	0x2734 <generic_retkprobe_event+0x2734>
    1787:      	movl	%ebp, 0x9c(%r14)
    178e:      	movl	%r13d, 0xa0(%r14)
    1795:      	addq	$0x8, %r13
    1799:      	movq	%r13, %r12
    179c:      	jmp	0x286a <generic_retkprobe_event+0x286a>
    17a1:      	movq	0x10(%rsp), %r12
    17a6:      	leaq	0xc4(%rcx), %rdi
    17ad:      	leaq	0x98(%r12), %rdx
    17b5:      	movq	%rcx, %r14
    17b8:      	movl	$0x4, %ecx
    17bd:      	movl	$0x4, %eax
    17c2:      	movl	$0x4, %esi
    17c7:      	callq	*%rax
    17c9:      	leaq	0xc8(%r14), %rdi
    17d0:      	leaq	0x70(%r12), %rdx
    17d5:      	movl	$0x4, %ecx
    17da:      	movl	$0x4, %eax
    17df:      	movl	$0x4, %esi
    17e4:      	callq	*%rax
    17e6:      	leaq	0xcc(%r14), %rdi
    17ed:      	leaq	0x90(%r12), %rdx
    17f5:      	movl	$0x4, %ecx
    17fa:      	movl	$0x4, %eax
    17ff:      	movl	$0x4, %esi
    1804:      	callq	*%rax
    1806:      	leaq	0xd0(%r14), %rdi
    180d:      	leaq	0xa8(%r12), %rdx
    1815:      	movl	$0x4, %ecx
    181a:      	movl	$0x4, %eax
    181f:      	movl	$0x4, %esi
    1824:      	callq	*%rax
    1826:      	movq	$0x0, 0x30(%rsp)
    182f:      	leaq	0xc8(%r12), %rdx
    1837:      	leaq	0x30(%rsp), %rdi
    183c:      	movl	$0x8, %ecx
    1841:      	movl	$0x4, %eax
    1846:      	movl	$0x8, %esi
    184b:      	callq	*%rax
    184d:      	movq	%r12, 0x80(%rsp)
    1855:      	leaq	0xb8(%r12), %rdx
    185d:      	leaq	0xa0(%rsp), %rdi
    1865:      	movl	$0x2, %ecx
    186a:      	movl	$0x4, %eax
    186f:      	movl	$0x2, %esi
    1874:      	callq	*%rax
    1876:      	movzwl	0xa0(%rsp), %r12d
    187f:      	addq	0x30(%rsp), %r12
    1884:      	leaq	0xb4(%rsp), %rdi
    188c:      	movl	$0x1, %ecx
    1891:      	movl	$0x4, %eax
    1896:      	movl	$0x1, %esi
    189b:      	movq	%r12, %rdx
    189e:      	callq	*%rax
    18a0:      	movzbl	0xb4(%rsp), %eax
    18a8:      	shrl	$0x4, %eax
    18ab:      	cmpl	$0x6, %eax
    18ae:      	je	0x246d <generic_retkprobe_event+0x246d>
    18b4:      	cmpl	$0x4, %eax
    18b7:      	jne	0x31d7 <generic_retkprobe_event+0x31d7>
    18bd:      	movq	%rbx, 0x8(%rsp)
    18c2:      	leaq	0x9(%r12), %rdx
    18c7:      	leaq	0xc8(%rsp), %rdi
    18cf:      	movl	$0x1, %ecx
    18d4:      	movl	$0x4, %eax
    18d9:      	movl	$0x1, %esi
    18de:      	callq	*%rax
    18e0:      	movzbl	0xc8(%rsp), %eax
    18e8:      	movq	(%rsp), %rsi
    18ec:      	movw	%ax, 0xc0(%rsi)
    18f3:      	movw	$0x2, 0xc2(%rsi)
    18fc:      	leaq	0xc(%r12), %rdx
    1901:      	movq	$0x0, (%rbp)
    1909:      	movq	$0x0, 0x8(%rbp)
    1911:      	movq	$0x0, 0x10(%rbp)
    1919:      	movq	$0x0, 0x18(%rbp)
    1921:      	movl	$0x4, %ecx
    1926:      	movl	$0x4, %eax
    192b:      	leaq	0xac(%rsi), %r14
    1932:      	movq	%rbp, %rdi
    1935:      	movl	$0x4, %esi
    193a:      	callq	*%rax
    193c:      	addq	$0x10, %r12
    1940:      	movl	$0x4, %ecx
    1945:      	movl	$0x4, %eax
    194a:      	movq	%r14, %rdi
    194d:      	movl	$0x4, %esi
    1952:      	movq	%r12, %rdx
    1955:      	callq	*%rax
    1957:      	movq	0x80(%rsp), %rax
    195f:      	leaq	0xb6(%rax), %rdx
    1966:      	leaq	0xd0(%rsp), %rdi
    196e:      	movl	$0x2, %ecx
    1973:      	movl	$0x4, %eax
    1978:      	movl	$0x2, %esi
    197d:      	jmp	0x303f <generic_retkprobe_event+0x303f>
    1982:      	movl	$0x120, %edx            # imm = 0x120
    1987:      	addq	0x10(%rsp), %rdx
    198c:      	movq	(%rsp), %rdi
    1990:      	addq	$0xa0, %rdi
    1997:      	movl	$0x11, %ecx
    199c:      	movl	$0x2d, %eax
    19a1:      	movl	$0x11, %esi
    19a6:      	callq	*%rax
    19a8:      	movq	%rax, %r12
    19ab:      	testq	%rax, %rax
    19ae:      	js	0x1483 <generic_retkprobe_event+0x1483>
    19b4:      	leal	-0x1(%r12), %eax
    19b9:      	movl	%eax, (%rbp)
    19bc:      	addq	$0x3, %r12
    19c0:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    19c5:      	movq	0x10(%rsp), %r12
    19ca:      	movq	$0x0, 0x10(%rbp)
    19d2:      	movq	$0x0, 0x8(%rbp)
    19da:      	movq	$0x0, (%rbp)
    19e2:      	movl	$0x2, %ecx
    19e7:      	movl	$0x4, %eax
    19ec:      	movq	%rbp, %rdi
    19ef:      	movl	$0x2, %esi
    19f4:      	movq	%r12, %rdx
    19f7:      	callq	*%rax
    19f9:      	testq	%rax, %rax
    19fc:      	movq	(%rsp), %rcx
    1a00:      	js	0x2668 <generic_retkprobe_event+0x2668>
    1a06:      	movzwl	(%rbp), %eax
    1a0a:      	cmpl	$0xa, %eax
    1a0d:      	je	0x2608 <generic_retkprobe_event+0x2608>
    1a13:      	cmpl	$0x2, %eax
    1a16:      	jne	0x264a <generic_retkprobe_event+0x264a>
    1a1c:      	leaq	0x4(%r12), %rdx
    1a21:      	leaq	0x30(%rsp), %rdi
    1a26:      	movl	$0x4, %ecx
    1a2b:      	movl	$0x4, %eax
    1a30:      	movl	$0x4, %esi
    1a35:      	callq	*%rax
    1a37:      	movl	0x30(%rsp), %eax
    1a3b:      	movq	(%rsp), %rdi
    1a3f:      	movq	%rax, 0xa4(%rdi)
    1a46:      	addq	$0x9e, %rdi
    1a4d:      	addq	$0x2, %r12
    1a51:      	movl	$0x2, %ecx
    1a56:      	movl	$0x4, %eax
    1a5b:      	jmp	0x2640 <generic_retkprobe_event+0x2640>
    1a60:      	xorl	%r14d, %r14d
    1a63:      	cmpq	$0x3, 0xa8(%rsp)
    1a6c:      	jb	0x1dfe <generic_retkprobe_event+0x1dfe>
    1a72:      	movq	0x98(%rsp), %rax
    1a7a:      	leaq	0x20(%rax), %rdx
    1a7e:      	leaq	0x30(%rsp), %rdi
    1a83:      	movl	$0x4, %r12d
    1a89:      	movl	$0x10, %ecx
    1a8e:      	movl	$0x4, %eax
    1a93:      	movl	$0x10, %esi
    1a98:      	callq	*%rax
    1a9a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a9f:      	testl	%eax, %eax
    1aa1:      	js	0x1b35 <generic_retkprobe_event+0x1b35>
    1aa7:      	movq	0x38(%rsp), %rax
    1aac:      	cmpq	%r14, %rax
    1aaf:      	movq	%r14, %rcx
    1ab2:      	cmovbq	%rax, %rcx
    1ab6:      	movq	%r14, (%rsp)
    1aba:      	testq	%r14, %r14
    1abd:      	movq	%rax, %r14
    1ac0:      	movq	%rcx, %r13
    1ac3:      	cmovneq	%rcx, %r14
    1ac7:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1acc:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1ad3:      	ja	0x1b35 <generic_retkprobe_event+0x1b35>
    1ad5:      	movq	0x80(%rsp), %rdi
    1add:      	addq	0x8(%rsp), %rdi
    1ae2:      	movq	%rdi, 0x80(%rsp)
    1aea:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1af0:      	addq	%r15, %rdi
    1af3:      	movq	0x30(%rsp), %rcx
    1af8:      	movl	$0x4, %eax
    1afd:      	movq	0x30(%rsp), %rdx
    1b02:      	movl	%r14d, %esi
    1b05:      	callq	*%rax
    1b07:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b0c:      	testl	%eax, %eax
    1b0e:      	js	0x1b35 <generic_retkprobe_event+0x1b35>
    1b10:      	movq	%r15, 0x20(%rsp)
    1b15:      	movq	%r14, %r15
    1b18:      	addq	%r14, %rbp
    1b1b:      	cmpq	$0x0, (%rsp)
    1b20:      	je	0x28b9 <generic_retkprobe_event+0x28b9>
    1b26:      	subq	%r13, (%rsp)
    1b2a:      	jne	0x28bf <generic_retkprobe_event+0x28bf>
    1b30:      	jmp	0x28ca <generic_retkprobe_event+0x28ca>
    1b35:      	movq	0x28(%rsp), %r14
    1b3a:      	movl	%ecx, (%r15,%r14)
    1b3e:      	addq	%r14, %r12
    1b41:      	movq	%r12, %rbp
    1b44:      	movq	0xb8(%rsp), %r12
    1b4c:      	movq	0x18(%rsp), %r13
    1b51:      	movl	$0x23, %eax
    1b56:      	callq	*%rax
    1b58:      	movq	%rax, %rcx
    1b5b:      	movq	%rax, 0x30(%rsp)
    1b60:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1b67:      	leaq	0x88(%rsp), %rdi
    1b6f:      	movl	$0x4, %edx
    1b74:      	movl	$0x71, %eax
    1b79:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1b7e:      	addq	0x30(%rsp), %rdx
    1b83:      	movl	$0x4, %esi
    1b88:      	callq	*%rax
    1b8a:      	movl	0x88(%rsp), %eax
    1b91:      	movl	%eax, 0x70(%rsp)
    1b95:      	movq	(%rip), %rdi            # 0x1b9c <generic_retkprobe_event+0x1b9c>
    1b9c:      	leaq	0x70(%rsp), %rsi
    1ba1:      	movl	$0x1, %eax
    1ba6:      	callq	*%rax
    1ba8:      	testq	%rax, %rax
    1bab:      	je	0x1bbb <generic_retkprobe_event+0x1bbb>
    1bad:      	movq	%rax, %r15
    1bb0:      	cmpq	$0x0, 0x8(%rax)
    1bb5:      	jne	0x1d91 <generic_retkprobe_event+0x1d91>
    1bbb:      	movl	$0xb00, %edx            # imm = 0xB00
    1bc0:      	movq	0x30(%rsp), %rcx
    1bc5:      	addq	%rdx, %rcx
    1bc8:      	leaq	0x30(%rsp), %rdi
    1bcd:      	movl	$0x8, %esi
    1bd2:      	movl	$0x71, %eax
    1bd7:      	addq	0x30(%rsp), %rdx
    1bdc:      	movl	$0x8, %esi
    1be1:      	callq	*%rax
    1be3:      	movq	0x30(%rsp), %rcx
    1be8:      	testq	%rcx, %rcx
    1beb:      	je	0x1d8e <generic_retkprobe_event+0x1d8e>
    1bf1:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1bf8:      	leaq	0x88(%rsp), %rdi
    1c00:      	movl	$0x4, %edx
    1c05:      	movl	$0x71, %eax
    1c0a:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1c0f:      	addq	0x30(%rsp), %rdx
    1c14:      	movl	$0x4, %esi
    1c19:      	callq	*%rax
    1c1b:      	movl	0x88(%rsp), %eax
    1c22:      	movl	%eax, 0x70(%rsp)
    1c26:      	movq	(%rip), %rdi            # 0x1c2d <generic_retkprobe_event+0x1c2d>
    1c2d:      	leaq	0x70(%rsp), %rsi
    1c32:      	movl	$0x1, %eax
    1c37:      	callq	*%rax
    1c39:      	testq	%rax, %rax
    1c3c:      	je	0x1c4c <generic_retkprobe_event+0x1c4c>
    1c3e:      	movq	%rax, %r15
    1c41:      	cmpq	$0x0, 0x8(%rax)
    1c46:      	jne	0x1d91 <generic_retkprobe_event+0x1d91>
    1c4c:      	movl	$0xb00, %edx            # imm = 0xB00
    1c51:      	movq	0x30(%rsp), %rcx
    1c56:      	addq	%rdx, %rcx
    1c59:      	leaq	0x30(%rsp), %rdi
    1c5e:      	movl	$0x8, %esi
    1c63:      	movl	$0x71, %eax
    1c68:      	addq	0x30(%rsp), %rdx
    1c6d:      	movl	$0x8, %esi
    1c72:      	callq	*%rax
    1c74:      	movq	0x30(%rsp), %rcx
    1c79:      	testq	%rcx, %rcx
    1c7c:      	je	0x1d8e <generic_retkprobe_event+0x1d8e>
    1c82:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1c89:      	leaq	0x88(%rsp), %rdi
    1c91:      	movl	$0x4, %edx
    1c96:      	movl	$0x71, %eax
    1c9b:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1ca0:      	addq	0x30(%rsp), %rdx
    1ca5:      	movl	$0x4, %esi
    1caa:      	callq	*%rax
    1cac:      	movl	0x88(%rsp), %eax
    1cb3:      	movl	%eax, 0x70(%rsp)
    1cb7:      	movq	(%rip), %rdi            # 0x1cbe <generic_retkprobe_event+0x1cbe>
    1cbe:      	leaq	0x70(%rsp), %rsi
    1cc3:      	movl	$0x1, %eax
    1cc8:      	callq	*%rax
    1cca:      	testq	%rax, %rax
    1ccd:      	je	0x1cdd <generic_retkprobe_event+0x1cdd>
    1ccf:      	movq	%rax, %r15
    1cd2:      	cmpq	$0x0, 0x8(%rax)
    1cd7:      	jne	0x1d91 <generic_retkprobe_event+0x1d91>
    1cdd:      	movl	$0xb00, %edx            # imm = 0xB00
    1ce2:      	movq	0x30(%rsp), %rcx
    1ce7:      	addq	%rdx, %rcx
    1cea:      	leaq	0x30(%rsp), %rdi
    1cef:      	movl	$0x8, %esi
    1cf4:      	movl	$0x71, %eax
    1cf9:      	addq	0x30(%rsp), %rdx
    1cfe:      	movl	$0x8, %esi
    1d03:      	callq	*%rax
    1d05:      	movq	0x30(%rsp), %rcx
    1d0a:      	testq	%rcx, %rcx
    1d0d:      	je	0x1d8e <generic_retkprobe_event+0x1d8e>
    1d0f:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1d16:      	leaq	0x88(%rsp), %rdi
    1d1e:      	movl	$0x4, %edx
    1d23:      	movl	$0x71, %eax
    1d28:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1d2d:      	addq	0x30(%rsp), %rdx
    1d32:      	movl	$0x4, %esi
    1d37:      	callq	*%rax
    1d39:      	movl	0x88(%rsp), %eax
    1d40:      	movl	%eax, 0x70(%rsp)
    1d44:      	movq	(%rip), %rdi            # 0x1d4b <generic_retkprobe_event+0x1d4b>
    1d4b:      	leaq	0x70(%rsp), %rsi
    1d50:      	movl	$0x1, %eax
    1d55:      	callq	*%rax
    1d57:      	testq	%rax, %rax
    1d5a:      	je	0x1d66 <generic_retkprobe_event+0x1d66>
    1d5c:      	movq	%rax, %r15
    1d5f:      	cmpq	$0x0, 0x8(%rax)
    1d64:      	jne	0x1d91 <generic_retkprobe_event+0x1d91>
    1d66:      	movl	$0xb00, %edx            # imm = 0xB00
    1d6b:      	movq	0x30(%rsp), %rcx
    1d70:      	addq	%rdx, %rcx
    1d73:      	leaq	0x30(%rsp), %rdi
    1d78:      	movl	$0x8, %esi
    1d7d:      	movl	$0x71, %eax
    1d82:      	addq	0x30(%rsp), %rdx
    1d87:      	movl	$0x8, %esi
    1d8c:      	callq	*%rax
    1d8e:      	xorl	%r15d, %r15d
    1d91:      	movl	$0x10d, (%rbx)          # imm = 0x10D
    1d97:      	movl	%ebp, 0x4(%rbx)
    1d9a:      	movl	$0x7d, %eax
    1d9f:      	callq	*%rax
    1da1:      	movq	%rax, 0x8(%rbx)
    1da5:      	testq	%r15, %r15
    1da8:      	je	0x1db8 <generic_retkprobe_event+0x1db8>
    1daa:      	movl	(%r15), %eax
    1dad:      	movl	%eax, 0x10(%rbx)
    1db0:      	movq	0x8(%r15), %rax
    1db4:      	movq	%rax, 0x18(%rbx)
    1db8:      	movl	$0x0, 0x14(%rbx)
    1dbf:      	movl	(%r13), %eax
    1dc3:      	movq	%rax, 0x60(%rbx)
    1dc7:      	movl	%ebp, 0x4(%rbx)
    1dca:      	movq	(%rip), %rsi            # 0x1dd1 <generic_retkprobe_event+0x1dd1>
    1dd1:      	movl	$0x3, %ecx
    1dd6:      	movl	$0xc, %eax
    1ddb:      	movq	%r12, %rdi
    1dde:      	movl	$0x3, %edx
    1de3:      	callq	*%rax
    1de5:      	movl	$0x1, %ebp
    1dea:      	movl	%ebp, %eax
    1dec:      	addq	$0xf8, %rsp
    1df3:      	popq	%rbx
    1df4:      	popq	%r12
    1df6:      	popq	%r13
    1df8:      	popq	%r14
    1dfa:      	popq	%r15
    1dfc:      	popq	%rbp
    1dfd:      	retq
    1dfe:      	movq	%rbp, %r13
    1e01:      	movq	0x28(%rsp), %r14
    1e06:      	jmp	0x41b <generic_retkprobe_event+0x41b>
    1e0b:      	movq	$0x0, 0x70(%rsp)
    1e14:      	movq	$0x0, 0x30(%rsp)
    1e1d:      	movq	%rax, %r14
    1e20:      	leaq	0x70(%rsp), %rdi
    1e25:      	leaq	0x30(%rsp), %rdx
    1e2a:      	movl	$0x8, %ecx
    1e2f:      	movl	$0x4, %eax
    1e34:      	movl	$0x4, %r12d
    1e3a:      	movl	$0x8, %esi
    1e3f:      	callq	*%rax
    1e41:      	movq	0x70(%rsp), %rax
    1e46:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1e4c:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1e52:      	movq	%rax, 0x8(%rsp)
    1e57:      	cmovbq	%rax, %r13
    1e5b:      	movq	%r14, 0x80(%rsp)
    1e63:      	addq	$0xa4, %r14
    1e6a:      	movl	$0x4, %eax
    1e6f:      	movq	%r14, %rdi
    1e72:      	movl	%r13d, %esi
    1e75:      	movq	%rbp, %rdx
    1e78:      	callq	*%rax
    1e7a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1e7f:      	testl	%eax, %eax
    1e81:      	js	0x1ea0 <generic_retkprobe_event+0x1ea0>
    1e83:      	movq	0x80(%rsp), %rax
    1e8b:      	movl	%r13d, 0xa0(%rax)
    1e92:      	addq	$0x8, %r13
    1e96:      	movq	0x8(%rsp), %rax
    1e9b:      	movl	%eax, %ecx
    1e9d:      	movq	%r13, %r12
    1ea0:      	movq	0x80(%rsp), %rax
    1ea8:      	movl	%ecx, 0x9c(%rax)
    1eae:      	movq	0x18(%rsp), %r13
    1eb3:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    1eb8:      	leaq	0xc4(%rcx), %r13
    1ebf:      	leaq	0xdc(%rcx), %r12
    1ec6:      	leaq	0x8(%rbp), %rdx
    1eca:      	movl	$0x4, %ecx
    1ecf:      	movl	$0x4, %eax
    1ed4:      	movq	0x8(%rsp), %rdi
    1ed9:      	movl	$0x4, %esi
    1ede:      	callq	*%rax
    1ee0:      	movq	(%rsp), %rax
    1ee4:      	leaq	0xa0(%rax), %rdi
    1eeb:      	leaq	0xc(%rbp), %rdx
    1eef:      	movl	$0x4, %ecx
    1ef4:      	movl	$0x4, %eax
    1ef9:      	movl	$0x4, %esi
    1efe:      	callq	*%rax
    1f00:      	movq	(%rsp), %rax
    1f04:      	leaq	0xac(%rax), %rdi
    1f0b:      	leaq	0x18(%rbp), %rdx
    1f0f:      	movl	$0x4, %ecx
    1f14:      	movl	$0x4, %eax
    1f19:      	movl	$0x4, %esi
    1f1e:      	callq	*%rax
    1f20:      	movq	(%rsp), %rax
    1f24:      	leaq	0xb0(%rax), %rdi
    1f2b:      	leaq	0x1c(%rbp), %rdx
    1f2f:      	movl	$0x4, %ecx
    1f34:      	movl	$0x4, %eax
    1f39:      	movl	$0x4, %esi
    1f3e:      	callq	*%rax
    1f40:      	movq	(%rsp), %rax
    1f44:      	leaq	0xa4(%rax), %rdi
    1f4b:      	leaq	0x10(%rbp), %rdx
    1f4f:      	movl	$0x4, %ecx
    1f54:      	movl	$0x4, %eax
    1f59:      	movl	$0x4, %esi
    1f5e:      	callq	*%rax
    1f60:      	movq	(%rsp), %rax
    1f64:      	leaq	0xa8(%rax), %rdi
    1f6b:      	leaq	0x14(%rbp), %rdx
    1f6f:      	movl	$0x4, %ecx
    1f74:      	movl	$0x4, %eax
    1f79:      	movl	$0x4, %esi
    1f7e:      	callq	*%rax
    1f80:      	movq	(%rsp), %rax
    1f84:      	leaq	0xb4(%rax), %rdi
    1f8b:      	leaq	0x20(%rbp), %rdx
    1f8f:      	movl	$0x4, %ecx
    1f94:      	movl	$0x4, %eax
    1f99:      	movl	$0x4, %esi
    1f9e:      	callq	*%rax
    1fa0:      	movq	(%rsp), %rax
    1fa4:      	leaq	0xb8(%rax), %rdi
    1fab:      	leaq	0x24(%rbp), %rdx
    1faf:      	movl	$0x4, %ecx
    1fb4:      	movl	$0x4, %eax
    1fb9:      	movl	$0x4, %esi
    1fbe:      	callq	*%rax
    1fc0:      	movq	(%rsp), %rax
    1fc4:      	movl	$0x0, 0xc0(%rax)
    1fce:      	movq	(%rsp), %rax
    1fd2:      	leaq	0xbc(%rax), %rdi
    1fd9:      	leaq	0x28(%rbp), %rdx
    1fdd:      	movl	$0x4, %ecx
    1fe2:      	movl	$0x4, %eax
    1fe7:      	movl	$0x4, %esi
    1fec:      	callq	*%rax
    1fee:      	movq	(%rsp), %rax
    1ff2:      	leaq	0xcc(%rax), %rdi
    1ff9:      	leaq	0x40(%rbp), %rdx
    1ffd:      	movl	$0x8, %ecx
    2002:      	movl	$0x4, %eax
    2007:      	movl	$0x8, %esi
    200c:      	callq	*%rax
    200e:      	movq	(%rsp), %rax
    2012:      	leaq	0xd4(%rax), %rdi
    2019:      	leaq	0x30(%rbp), %rdx
    201d:      	movl	$0x8, %ecx
    2022:      	movl	$0x4, %eax
    2027:      	movl	$0x8, %esi
    202c:      	callq	*%rax
    202e:      	leaq	0x38(%rbp), %rdx
    2032:      	movl	$0x8, %ecx
    2037:      	movl	$0x4, %eax
    203c:      	movq	%r13, %rdi
    203f:      	movl	$0x8, %esi
    2044:      	callq	*%rax
    2046:      	addq	$0x90, %rbp
    204d:      	leaq	0x30(%rsp), %rdi
    2052:      	movl	$0x8, %ecx
    2057:      	movl	$0x4, %eax
    205c:      	movl	$0x8, %esi
    2061:      	movq	%rbp, %rdx
    2064:      	callq	*%rax
    2066:      	movq	0x30(%rsp), %r13
    206b:      	leaq	0xc8(%r13), %rdx
    2072:      	movl	$0x4, %ecx
    2077:      	movl	$0x4, %eax
    207c:      	movq	%r12, %rdi
    207f:      	movl	$0x4, %esi
    2084:      	callq	*%rax
    2086:      	movq	(%rsp), %rax
    208a:      	leaq	0xe0(%rax), %rdi
    2091:      	leaq	0xcc(%r13), %rdx
    2098:      	movl	$0x4, %ecx
    209d:      	movl	$0x4, %eax
    20a2:      	movl	$0x4, %esi
    20a7:      	callq	*%rax
    20a9:      	movq	(%rsp), %rax
    20ad:      	leaq	0xe4(%rax), %rdi
    20b4:      	leaq	0xd0(%r13), %rdx
    20bb:      	movl	$0x4, %ecx
    20c0:      	movl	$0x4, %eax
    20c5:      	movl	$0x4, %esi
    20ca:      	callq	*%rax
    20cc:      	movq	(%rsp), %rdi
    20d0:      	addq	$0xe8, %rdi
    20d7:      	addq	$0x158, %r13            # imm = 0x158
    20de:      	movl	$0x4, %ecx
    20e3:      	movl	$0x4, %eax
    20e8:      	movl	$0x4, %esi
    20ed:      	movq	%r13, %rdx
    20f0:      	movq	0x18(%rsp), %r13
    20f5:      	callq	*%rax
    20f7:      	movq	(%rsp), %rcx
    20fb:      	movl	$0x50, %r12d
    2101:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    2106:      	leaq	0xc8(%rbp), %rdx
    210d:      	movl	$0x4, %ecx
    2112:      	movl	$0x4, %eax
    2117:      	movq	0x8(%rsp), %rdi
    211c:      	movl	$0x4, %esi
    2121:      	callq	*%rax
    2123:      	movq	(%rsp), %rax
    2127:      	leaq	0xa0(%rax), %rdi
    212e:      	leaq	0xcc(%rbp), %rdx
    2135:      	movl	$0x4, %ecx
    213a:      	movl	$0x4, %eax
    213f:      	movl	$0x4, %esi
    2144:      	callq	*%rax
    2146:      	movq	(%rsp), %rax
    214a:      	leaq	0xa4(%rax), %rdi
    2151:      	leaq	0xd0(%rbp), %rdx
    2158:      	movl	$0x4, %ecx
    215d:      	movl	$0x4, %eax
    2162:      	movl	$0x4, %esi
    2167:      	callq	*%rax
    2169:      	movq	(%rsp), %rdi
    216d:      	addq	$0xa8, %rdi
    2174:      	addq	$0x158, %rbp            # imm = 0x158
    217b:      	movl	$0x4, %ecx
    2180:      	movl	$0x4, %eax
    2185:      	movl	$0x4, %esi
    218a:      	movq	%rbp, %rdx
    218d:      	callq	*%rax
    218f:      	movq	(%rsp), %rcx
    2193:      	movl	$0x10, %r12d
    2199:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    219e:      	leaq	0x38(%rbp), %rdx
    21a2:      	movl	$0x4, %ecx
    21a7:      	movl	$0x4, %eax
    21ac:      	movq	0x8(%rsp), %rdi
    21b1:      	movl	$0x4, %esi
    21b6:      	callq	*%rax
    21b8:      	movq	(%rsp), %rax
    21bc:      	leaq	0xa0(%rax), %rdi
    21c3:      	leaq	0x3c(%rbp), %rdx
    21c7:      	movl	$0x4, %ecx
    21cc:      	movl	$0x4, %eax
    21d1:      	movl	$0x4, %esi
    21d6:      	callq	*%rax
    21d8:      	movq	(%rsp), %rax
    21dc:      	leaq	0xa4(%rax), %rdi
    21e3:      	leaq	0x40(%rbp), %rdx
    21e7:      	movl	$0x4, %ecx
    21ec:      	movl	$0x4, %eax
    21f1:      	movl	$0x4, %esi
    21f6:      	callq	*%rax
    21f8:      	movq	(%rsp), %rax
    21fc:      	leaq	0xa8(%rax), %rdi
    2203:      	leaq	0x44(%rbp), %rdx
    2207:      	movl	$0x4, %ecx
    220c:      	movl	$0x4, %eax
    2211:      	movl	$0x4, %esi
    2216:      	callq	*%rax
    2218:      	movq	(%rsp), %rdi
    221c:      	addq	$0xac, %rdi
    2223:      	subq	$-0x80, %rbp
    2227:      	movl	$0x10, %ecx
    222c:      	movl	$0x4, %eax
    2231:      	movl	$0x10, %esi
    2236:      	movq	%rbp, %rdx
    2239:      	callq	*%rax
    223b:      	movq	(%rsp), %rcx
    223f:      	movl	$0x20, %r12d
    2245:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    224a:      	movl	$0x4, %ecx
    224f:      	movl	$0x4, %eax
    2254:      	movq	0x8(%rsp), %rdi
    2259:      	movl	$0x4, %esi
    225e:      	movq	%rbp, %rdx
    2261:      	callq	*%rax
    2263:      	movq	(%rsp), %rax
    2267:      	leaq	0xa0(%rax), %rdi
    226e:      	leaq	0x4(%rbp), %rdx
    2272:      	movl	$0x4, %ecx
    2277:      	movl	$0x4, %eax
    227c:      	movl	$0x4, %esi
    2281:      	callq	*%rax
    2283:      	movq	(%rsp), %rdi
    2287:      	addq	$0xa4, %rdi
    228e:      	addq	$0x30, %rbp
    2292:      	movl	$0x10, %ecx
    2297:      	movl	$0x4, %eax
    229c:      	movl	$0x10, %esi
    22a1:      	movq	%rbp, %rdx
    22a4:      	jmp	0x2342 <generic_retkprobe_event+0x2342>
    22a9:      	leaq	0x4(%rbp), %rdx
    22ad:      	leaq	0x30(%rsp), %rdi
    22b2:      	movl	$0x4, %ecx
    22b7:      	movl	$0x4, %eax
    22bc:      	movl	$0x4, %esi
    22c1:      	callq	*%rax
    22c3:      	movl	0x30(%rsp), %eax
    22c7:      	movq	(%rsp), %rcx
    22cb:      	movl	%eax, 0x9c(%rcx)
    22d1:      	leaq	0xc(%rbp), %rdx
    22d5:      	leaq	0x30(%rsp), %rdi
    22da:      	movl	$0x4, %ecx
    22df:      	movl	$0x4, %eax
    22e4:      	movl	$0x4, %esi
    22e9:      	callq	*%rax
    22eb:      	movl	0x30(%rsp), %eax
    22ef:      	movq	(%rsp), %rcx
    22f3:      	movl	%eax, 0xa0(%rcx)
    22f9:      	addq	$0x50, %rbp
    22fd:      	leaq	0x30(%rsp), %rdi
    2302:      	movl	$0x8, %ecx
    2307:      	movl	$0x2d, %eax
    230c:      	movl	$0x8, %esi
    2311:      	movq	%rbp, %rdx
    2314:      	callq	*%rax
    2316:      	movq	(%rsp), %rdi
    231a:      	addq	$0xa4, %rdi
    2321:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2326:      	movq	0x30(%rsp), %rcx
    232b:      	addq	%rdx, %rcx
    232e:      	movl	$0x10, %esi
    2333:      	movl	$0x2d, %eax
    2338:      	addq	0x30(%rsp), %rdx
    233d:      	movl	$0x10, %esi
    2342:      	callq	*%rax
    2344:      	movq	(%rsp), %rcx
    2348:      	movl	$0x18, %r12d
    234e:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    2353:      	movq	0x8(%rsp), %rax
    2358:      	movq	$0x0, 0x48(%rax)
    2360:      	movq	$0x0, 0x40(%rax)
    2368:      	movq	$0x0, 0x38(%rax)
    2370:      	movq	$0x0, 0x30(%rax)
    2378:      	movq	$0x0, 0x28(%rax)
    2380:      	movq	$0x0, 0x20(%rax)
    2388:      	movq	$0x0, 0x18(%rax)
    2390:      	movq	$0x0, 0x10(%rax)
    2398:      	movq	$0x0, 0x8(%rax)
    23a0:      	movq	$0x0, (%rax)
    23a7:      	leaq	0x30(%rsp), %rdi
    23ac:      	movl	$0x8, %ecx
    23b1:      	movl	$0x4, %eax
    23b6:      	movl	$0x8, %esi
    23bb:      	movq	%rbp, %rdx
    23be:      	callq	*%rax
    23c0:      	testq	%rax, %rax
    23c3:      	je	0x2673 <generic_retkprobe_event+0x2673>
    23c9:      	xorl	%r12d, %r12d
    23cc:      	jmp	0x286a <generic_retkprobe_event+0x286a>
    23d1:      	movq	$-0x1, %r12
    23d8:      	movq	0x18(%rsp), %r13
    23dd:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    23e2:      	leaq	0x10(%r13), %rdx
    23e6:      	leaq	0x70(%rsp), %rdi
    23eb:      	movl	$0x8, %ecx
    23f0:      	movl	$0x4, %eax
    23f5:      	movl	$0x8, %esi
    23fa:      	callq	*%rax
    23fc:      	addq	$0x18, %r13
    2400:      	leaq	0x88(%rsp), %rdi
    2408:      	movl	$0x8, %ecx
    240d:      	movl	$0x4, %eax
    2412:      	movl	$0x8, %esi
    2417:      	movq	%r13, %rdx
    241a:      	callq	*%rax
    241c:      	movq	0x70(%rsp), %rdx
    2421:      	movq	0x88(%rsp), %r13
    2429:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    2430:      	movl	$0xfff, %r12d           # imm = 0xFFF
    2436:      	cmovbq	%r13, %r12
    243a:      	movq	%r14, %rdi
    243d:      	addq	$0xa4, %rdi
    2444:      	movl	$0x4, %eax
    2449:      	movl	%r12d, %esi
    244c:      	callq	*%rax
    244e:      	testl	%eax, %eax
    2450:      	js	0x2744 <generic_retkprobe_event+0x2744>
    2456:      	movl	%r13d, 0x9c(%r14)
    245d:      	movl	%r12d, 0xa0(%r14)
    2464:      	addq	$0x8, %r12
    2468:      	jmp	0x286a <generic_retkprobe_event+0x286a>
    246d:      	movq	%rbx, 0x8(%rsp)
    2472:      	movq	0x30(%rsp), %r14
    2477:      	movl	$0x0, 0x70(%rsp)
    247f:      	movzwl	0xa0(%rsp), %r13d
    2488:      	movq	(%rip), %rdi            # 0x248f <generic_retkprobe_event+0x248f>
    248f:      	leaq	0x70(%rsp), %rsi
    2494:      	movl	$0x1, %eax
    2499:      	leaq	(%r14,%r13), %rbx
    249d:      	callq	*%rax
    249f:      	testq	%rax, %rax
    24a2:      	je	0x2fe8 <generic_retkprobe_event+0x2fe8>
    24a8:      	movq	%rax, %r12
    24ab:      	movw	%r13w, (%rax)
    24af:      	movb	$-0x1, 0x5(%rax)
    24b3:      	movb	$0x0, 0x7(%rax)
    24b7:      	movq	%rax, %rdi
    24ba:      	addq	$0x6, %rdi
    24be:      	leaq	0x6(%rbx), %rdx
    24c2:      	movl	$0x1, %ecx
    24c7:      	movl	$0x4, %eax
    24cc:      	movq	%rdi, %r13
    24cf:      	movl	$0x1, %esi
    24d4:      	callq	*%rax
    24d6:      	testq	%rax, %rax
    24d9:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    24df:      	movzbl	0x5(%r12), %eax
    24e5:      	cmpl	$0x32, %eax
    24e8:      	jg	0x287d <generic_retkprobe_event+0x287d>
    24ee:      	testl	%eax, %eax
    24f0:      	je	0x28a7 <generic_retkprobe_event+0x28a7>
    24f6:      	cmpl	$0x2b, %eax
    24f9:      	je	0x28a7 <generic_retkprobe_event+0x28a7>
    24ff:      	cmpl	$0x2c, %eax
    2502:      	jne	0x2a63 <generic_retkprobe_event+0x2a63>
    2508:      	movw	$0x8, 0x2(%r12)
    2510:      	movw	$0x8, %ax
    2514:      	jmp	0x29aa <generic_retkprobe_event+0x29aa>
    2519:      	leaq	0x48(%r12), %rdx
    251e:      	movl	$0x10, %ecx
    2523:      	movl	$0x4, %eax
    2528:      	movq	%rbp, %rdi
    252b:      	movl	$0x10, %esi
    2530:      	callq	*%rax
    2532:      	leaq	0x38(%r12), %rdx
    2537:      	movl	$0x10, %ecx
    253c:      	movl	$0x4, %eax
    2541:      	movq	%r13, %rdi
    2544:      	movl	$0x10, %esi
    2549:      	callq	*%rax
    254b:      	movq	(%rsp), %r13
    254f:      	leaq	0xbc(%r13), %rdi
    2556:      	leaq	0xc(%r12), %r14
    255b:      	addq	$0xe, %r12
    255f:      	movl	$0x2, %ecx
    2564:      	movl	$0x4, %eax
    2569:      	movl	$0x2, %esi
    256e:      	movq	%r12, %rdx
    2571:      	callq	*%rax
    2573:      	movq	%r13, %rdi
    2576:      	addq	$0xbe, %rdi
    257d:      	movl	$0x2, %ecx
    2582:      	movl	$0x4, %eax
    2587:      	movl	$0x2, %esi
    258c:      	movq	%r14, %rdx
    258f:      	callq	*%rax
    2591:      	movzwl	0xbe(%r13), %eax
    2599:      	movbew	%ax, 0xbe(%r13)
    25a3:      	movq	0x10(%rsp), %rax
    25a8:      	movq	%rax, 0x30(%rsp)
    25ad:      	movq	(%rip), %rdi            # 0x25b4 <generic_retkprobe_event+0x25b4>
    25b4:      	leaq	0x30(%rsp), %rsi
    25b9:      	movl	$0x1, %eax
    25be:      	callq	*%rax
    25c0:      	testq	%rax, %rax
    25c3:      	je	0x25dd <generic_retkprobe_event+0x25dd>
    25c5:      	movl	(%rax), %ecx
    25c7:      	movq	0x8(%rsp), %rbp
    25cc:      	movl	%ecx, 0x10(%rbp)
    25cf:      	movq	0x8(%rax), %rcx
    25d3:      	movq	%rcx, 0x18(%rbp)
    25d7:      	movl	0x4(%rax), %eax
    25da:      	movl	%eax, 0x7c(%rbp)
    25dd:      	movl	$0x40, %r12d
    25e3:      	movq	0x18(%rsp), %r13
    25e8:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    25ed:      	movq	$0x0, 0x9c(%r14)
    25f8:      	movl	$0x8, %r12d
    25fe:      	movq	0x18(%rsp), %r13
    2603:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    2608:      	leaq	0xa4(%rcx), %rdi
    260f:      	leaq	0x8(%r12), %rdx
    2614:      	movq	%rcx, %r14
    2617:      	movl	$0x10, %ecx
    261c:      	movl	$0x4, %eax
    2621:      	movl	$0x10, %esi
    2626:      	callq	*%rax
    2628:      	movq	%r14, %rdi
    262b:      	addq	$0x9e, %rdi
    2632:      	addq	$0x2, %r12
    2636:      	movl	$0x2, %ecx
    263b:      	movl	$0x4, %eax
    2640:      	movl	$0x2, %esi
    2645:      	movq	%r12, %rdx
    2648:      	callq	*%rax
    264a:      	movq	(%rsp), %rcx
    264e:      	movzwl	0x9e(%rcx), %eax
    2655:      	movbew	%ax, 0x9e(%rcx)
    265e:      	movq	0x18(%rsp), %r13
    2663:      	movq	0x20(%rsp), %r15
    2668:      	movl	$0x18, %r12d
    266e:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    2673:      	movq	(%rsp), %rax
    2677:      	leaq	0xac(%rax), %rdi
    267e:      	movq	0x30(%rsp), %rcx
    2683:      	movl	$0x3f, %edx
    2688:      	movl	$0x2d, %eax
    268d:      	movq	0x30(%rsp), %rdx
    2692:      	movl	$0x3f, %esi
    2697:      	callq	*%rax
    2699:      	testq	%rax, %rax
    269c:      	js	0x23c9 <generic_retkprobe_event+0x23c9>
    26a2:      	leaq	0x8(%rbp), %rdx
    26a6:      	leaq	0x70(%rsp), %rdi
    26ab:      	movl	$0x8, %ecx
    26b0:      	movl	$0x4, %eax
    26b5:      	movl	$0x8, %esi
    26ba:      	callq	*%rax
    26bc:      	movq	(%rsp), %rdi
    26c0:      	addq	$0xa4, %rdi
    26c7:      	movl	$0x348, %edx            # imm = 0x348
    26cc:      	movq	0x70(%rsp), %rcx
    26d1:      	addq	%rdx, %rcx
    26d4:      	movl	$0x8, %esi
    26d9:      	movl	$0x4, %eax
    26de:      	addq	0x70(%rsp), %rdx
    26e3:      	movl	$0x8, %esi
    26e8:      	callq	*%rax
    26ea:      	addq	$0x58, %rbp
    26ee:      	leaq	0x70(%rsp), %rdi
    26f3:      	movl	$0x4, %ecx
    26f8:      	movl	$0x4, %eax
    26fd:      	movl	$0x4, %esi
    2702:      	movq	%rbp, %rdx
    2705:      	callq	*%rax
    2707:      	movl	$0x50, %r12d
    270d:      	testq	%rax, %rax
    2710:      	jne	0x286a <generic_retkprobe_event+0x286a>
    2716:      	xorl	%eax, %eax
    2718:      	cmpl	$0x0, 0x70(%rsp)
    271d:      	setne	%al
    2720:      	movq	0x8(%rsp), %rcx
    2725:      	movl	%eax, (%rcx)
    2727:      	jmp	0x286a <generic_retkprobe_event+0x286a>
    272c:      	xorl	%r12d, %r12d
    272f:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    2734:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    273f:      	jmp	0x286a <generic_retkprobe_event+0x286a>
    2744:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    274f:      	movl	$0x4, %r12d
    2755:      	jmp	0x286a <generic_retkprobe_event+0x286a>
    275a:      	addq	$0x3, %r12
    275e:      	movl	$0x6b, %ecx
    2763:      	movl	$0x71, %eax
    2768:      	movl	$0x6b, %esi
    276d:      	movq	%r12, %rdx
    2770:      	callq	*%rax
    2772:      	movq	%rax, %rcx
    2775:      	movb	$0x6b, %al
    2777:      	testl	%ecx, %ecx
    2779:      	js	0x2785 <generic_retkprobe_event+0x2785>
    277b:      	movq	(%rsp), %rcx
    277f:      	movb	%al, 0x9f(%rcx)
    2785:      	movl	$0x70, %r12d
    278b:      	movq	0x18(%rsp), %r13
    2790:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    2795:      	leaq	0x48(%r12), %rdx
    279a:      	movl	$0x10, %ecx
    279f:      	movl	$0x4, %eax
    27a4:      	movq	0x8(%rsp), %rdi
    27a9:      	movl	$0x10, %esi
    27ae:      	callq	*%rax
    27b0:      	leaq	0x38(%r12), %rdx
    27b5:      	movl	$0x10, %ecx
    27ba:      	movl	$0x4, %eax
    27bf:      	movq	%r13, %rdi
    27c2:      	movl	$0x10, %esi
    27c7:      	callq	*%rax
    27c9:      	movq	(%rsp), %r13
    27cd:      	leaq	0xbc(%r13), %rdi
    27d4:      	leaq	0xc(%r12), %r14
    27d9:      	addq	$0xe, %r12
    27dd:      	movl	$0x2, %ecx
    27e2:      	movl	$0x4, %eax
    27e7:      	movl	$0x2, %esi
    27ec:      	movq	%r12, %rdx
    27ef:      	callq	*%rax
    27f1:      	movq	%r13, %rdi
    27f4:      	addq	$0xbe, %rdi
    27fb:      	movl	$0x2, %ecx
    2800:      	movl	$0x4, %eax
    2805:      	movl	$0x2, %esi
    280a:      	movq	%r14, %rdx
    280d:      	callq	*%rax
    280f:      	movzwl	0xbe(%r13), %eax
    2817:      	movbew	%ax, 0xbe(%r13)
    2821:      	movq	(%rsp), %rax
    2825:      	movq	0xc4(%rax), %rax
    282c:      	movq	%rax, 0x30(%rsp)
    2831:      	movq	(%rip), %rdi            # 0x2838 <generic_retkprobe_event+0x2838>
    2838:      	leaq	0x30(%rsp), %rsi
    283d:      	movl	$0x1, %eax
    2842:      	callq	*%rax
    2844:      	testq	%rax, %rax
    2847:      	je	0x2864 <generic_retkprobe_event+0x2864>
    2849:      	movl	(%rax), %ecx
    284b:      	movq	0x80(%rsp), %rdx
    2853:      	movl	%ecx, 0x10(%rdx)
    2856:      	movq	0x8(%rax), %rcx
    285a:      	movq	%rcx, 0x18(%rdx)
    285e:      	movl	0x4(%rax), %eax
    2861:      	movl	%eax, 0x7c(%rdx)
    2864:      	movl	$0x40, %r12d
    286a:      	movq	0x18(%rsp), %r13
    286f:      	movq	(%rsp), %rcx
    2873:      	movq	0x20(%rsp), %r15
    2878:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    287d:      	cmpl	$0x33, %eax
    2880:      	je	0x2997 <generic_retkprobe_event+0x2997>
    2886:      	cmpl	$0x3c, %eax
    2889:      	je	0x28a7 <generic_retkprobe_event+0x28a7>
    288b:      	cmpl	$0xff, %eax
    2890:      	jne	0x2a63 <generic_retkprobe_event+0x2a63>
    2896:      	movw	$0x28, 0x2(%r12)
    289e:      	movw	$0x28, %ax
    28a2:      	jmp	0x29aa <generic_retkprobe_event+0x29aa>
    28a7:      	movzbl	0x7(%r12), %eax
    28ad:      	leal	0x8(,%rax,8), %eax
    28b4:      	jmp	0x29a4 <generic_retkprobe_event+0x29a4>
    28b9:      	xorl	%eax, %eax
    28bb:      	movq	%rax, (%rsp)
    28bf:      	cmpq	$0x3, 0xa8(%rsp)
    28c8:      	jne	0x28dc <generic_retkprobe_event+0x28dc>
    28ca:      	movq	%rbp, %r13
    28cd:      	movq	0x28(%rsp), %r14
    28d2:      	movq	0x20(%rsp), %r15
    28d7:      	jmp	0x41b <generic_retkprobe_event+0x41b>
    28dc:      	movq	0x98(%rsp), %rax
    28e4:      	leaq	0x30(%rax), %rdx
    28e8:      	leaq	0x30(%rsp), %rdi
    28ed:      	movl	$0x4, %r12d
    28f3:      	movl	$0x10, %ecx
    28f8:      	movl	$0x4, %eax
    28fd:      	movl	$0x10, %esi
    2902:      	callq	*%rax
    2904:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2909:      	testl	%eax, %eax
    290b:      	js	0x3356 <generic_retkprobe_event+0x3356>
    2911:      	movq	0x38(%rsp), %rdx
    2916:      	movq	(%rsp), %rax
    291a:      	cmpq	%rax, %rdx
    291d:      	movq	%rax, %r13
    2920:      	cmovbq	%rdx, %r13
    2924:      	testq	%rax, %rax
    2927:      	cmovneq	%r13, %rdx
    292b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2930:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2937:      	ja	0x3356 <generic_retkprobe_event+0x3356>
    293d:      	movq	%rdx, %r14
    2940:      	movq	%r15, %rdi
    2943:      	addq	0x80(%rsp), %rdi
    294b:      	movq	%rdi, %r15
    294e:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2954:      	addq	0x20(%rsp), %rdi
    2959:      	movq	0x30(%rsp), %rcx
    295e:      	movl	$0x4, %eax
    2963:      	movq	%rdx, %rsi
    2966:      	movq	0x30(%rsp), %rdx
    296b:      	callq	*%rax
    296d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2972:      	testl	%eax, %eax
    2974:      	js	0x3356 <generic_retkprobe_event+0x3356>
    297a:      	addq	%r14, %rbp
    297d:      	cmpq	$0x0, (%rsp)
    2982:      	je	0x2cff <generic_retkprobe_event+0x2cff>
    2988:      	subq	%r13, (%rsp)
    298c:      	jne	0x2d05 <generic_retkprobe_event+0x2d05>
    2992:      	jmp	0x28ca <generic_retkprobe_event+0x28ca>
    2997:      	movzbl	0x7(%r12), %eax
    299d:      	leal	0x8(,%rax,4), %eax
    29a4:      	movw	%ax, 0x2(%r12)
    29aa:      	addw	(%r12), %ax
    29af:      	movw	%ax, (%r12)
    29b4:      	movzbl	0x6(%r12), %ecx
    29ba:      	cmpq	$0x3c, %rcx
    29be:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    29c4:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    29ce:      	btq	%rcx, %rdx
    29d2:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    29d8:      	movb	%cl, 0x5(%r12)
    29dd:      	movzwl	%ax, %ecx
    29e0:      	addq	%r14, %rcx
    29e3:      	movl	$0x2, %edx
    29e8:      	movl	$0x4, %eax
    29ed:      	movq	%r13, %rdi
    29f0:      	movzwl	(%r12), %edx
    29f5:      	addq	%r14, %rdx
    29f8:      	movl	$0x2, %esi
    29fd:      	callq	*%rax
    29ff:      	testq	%rax, %rax
    2a02:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    2a08:      	movzbl	0x5(%r12), %eax
    2a0e:      	cmpl	$0x32, %eax
    2a11:      	jg	0x2a2f <generic_retkprobe_event+0x2a2f>
    2a13:      	testl	%eax, %eax
    2a15:      	je	0x2a4e <generic_retkprobe_event+0x2a4e>
    2a17:      	cmpl	$0x2b, %eax
    2a1a:      	je	0x2a4e <generic_retkprobe_event+0x2a4e>
    2a1c:      	cmpl	$0x2c, %eax
    2a1f:      	jne	0x2a83 <generic_retkprobe_event+0x2a83>
    2a21:      	movw	$0x8, 0x2(%r12)
    2a29:      	movw	$0x8, %ax
    2a2d:      	jmp	0x2a89 <generic_retkprobe_event+0x2a89>
    2a2f:      	cmpl	$0x33, %eax
    2a32:      	je	0x2a6e <generic_retkprobe_event+0x2a6e>
    2a34:      	cmpl	$0x3c, %eax
    2a37:      	je	0x2a4e <generic_retkprobe_event+0x2a4e>
    2a39:      	cmpl	$0xff, %eax
    2a3e:      	jne	0x2a83 <generic_retkprobe_event+0x2a83>
    2a40:      	movw	$0x28, 0x2(%r12)
    2a48:      	movw	$0x28, %ax
    2a4c:      	jmp	0x2a89 <generic_retkprobe_event+0x2a89>
    2a4e:      	movzbl	0x7(%r12), %eax
    2a54:      	leal	0x8(,%rax,8), %eax
    2a5b:      	movw	%ax, 0x2(%r12)
    2a61:      	jmp	0x2a89 <generic_retkprobe_event+0x2a89>
    2a63:      	movzwl	0x2(%r12), %eax
    2a69:      	jmp	0x29aa <generic_retkprobe_event+0x29aa>
    2a6e:      	movzbl	0x7(%r12), %eax
    2a74:      	leal	0x8(,%rax,4), %eax
    2a7b:      	movw	%ax, 0x2(%r12)
    2a81:      	jmp	0x2a89 <generic_retkprobe_event+0x2a89>
    2a83:      	movzwl	0x2(%r12), %eax
    2a89:      	addw	(%r12), %ax
    2a8e:      	movw	%ax, (%r12)
    2a93:      	movzbl	0x6(%r12), %ecx
    2a99:      	cmpq	$0x3c, %rcx
    2a9d:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    2aa3:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2aad:      	btq	%rcx, %rdx
    2ab1:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    2ab7:      	movb	%cl, 0x5(%r12)
    2abc:      	movzwl	%ax, %ecx
    2abf:      	addq	%r14, %rcx
    2ac2:      	movl	$0x2, %edx
    2ac7:      	movl	$0x4, %eax
    2acc:      	movq	%r13, %rdi
    2acf:      	movzwl	(%r12), %edx
    2ad4:      	addq	%r14, %rdx
    2ad7:      	movl	$0x2, %esi
    2adc:      	callq	*%rax
    2ade:      	testq	%rax, %rax
    2ae1:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    2ae7:      	movzbl	0x5(%r12), %eax
    2aed:      	cmpl	$0x32, %eax
    2af0:      	jg	0x2b0e <generic_retkprobe_event+0x2b0e>
    2af2:      	testl	%eax, %eax
    2af4:      	je	0x2b2d <generic_retkprobe_event+0x2b2d>
    2af6:      	cmpl	$0x2b, %eax
    2af9:      	je	0x2b2d <generic_retkprobe_event+0x2b2d>
    2afb:      	cmpl	$0x2c, %eax
    2afe:      	jne	0x2b57 <generic_retkprobe_event+0x2b57>
    2b00:      	movw	$0x8, 0x2(%r12)
    2b08:      	movw	$0x8, %ax
    2b0c:      	jmp	0x2b5d <generic_retkprobe_event+0x2b5d>
    2b0e:      	cmpl	$0x33, %eax
    2b11:      	je	0x2b42 <generic_retkprobe_event+0x2b42>
    2b13:      	cmpl	$0x3c, %eax
    2b16:      	je	0x2b2d <generic_retkprobe_event+0x2b2d>
    2b18:      	cmpl	$0xff, %eax
    2b1d:      	jne	0x2b57 <generic_retkprobe_event+0x2b57>
    2b1f:      	movw	$0x28, 0x2(%r12)
    2b27:      	movw	$0x28, %ax
    2b2b:      	jmp	0x2b5d <generic_retkprobe_event+0x2b5d>
    2b2d:      	movzbl	0x7(%r12), %eax
    2b33:      	leal	0x8(,%rax,8), %eax
    2b3a:      	movw	%ax, 0x2(%r12)
    2b40:      	jmp	0x2b5d <generic_retkprobe_event+0x2b5d>
    2b42:      	movzbl	0x7(%r12), %eax
    2b48:      	leal	0x8(,%rax,4), %eax
    2b4f:      	movw	%ax, 0x2(%r12)
    2b55:      	jmp	0x2b5d <generic_retkprobe_event+0x2b5d>
    2b57:      	movzwl	0x2(%r12), %eax
    2b5d:      	addw	(%r12), %ax
    2b62:      	movw	%ax, (%r12)
    2b67:      	movzbl	0x6(%r12), %ecx
    2b6d:      	cmpq	$0x3c, %rcx
    2b71:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    2b77:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b81:      	btq	%rcx, %rdx
    2b85:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    2b8b:      	movb	%cl, 0x5(%r12)
    2b90:      	movzwl	%ax, %ecx
    2b93:      	addq	%r14, %rcx
    2b96:      	movl	$0x2, %edx
    2b9b:      	movl	$0x4, %eax
    2ba0:      	movq	%r13, %rdi
    2ba3:      	movzwl	(%r12), %edx
    2ba8:      	addq	%r14, %rdx
    2bab:      	movl	$0x2, %esi
    2bb0:      	callq	*%rax
    2bb2:      	testq	%rax, %rax
    2bb5:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    2bbb:      	movzbl	0x5(%r12), %eax
    2bc1:      	cmpl	$0x32, %eax
    2bc4:      	jg	0x2be2 <generic_retkprobe_event+0x2be2>
    2bc6:      	testl	%eax, %eax
    2bc8:      	je	0x2c01 <generic_retkprobe_event+0x2c01>
    2bca:      	cmpl	$0x2b, %eax
    2bcd:      	je	0x2c01 <generic_retkprobe_event+0x2c01>
    2bcf:      	cmpl	$0x2c, %eax
    2bd2:      	jne	0x2c2b <generic_retkprobe_event+0x2c2b>
    2bd4:      	movw	$0x8, 0x2(%r12)
    2bdc:      	movw	$0x8, %ax
    2be0:      	jmp	0x2c31 <generic_retkprobe_event+0x2c31>
    2be2:      	cmpl	$0x33, %eax
    2be5:      	je	0x2c16 <generic_retkprobe_event+0x2c16>
    2be7:      	cmpl	$0x3c, %eax
    2bea:      	je	0x2c01 <generic_retkprobe_event+0x2c01>
    2bec:      	cmpl	$0xff, %eax
    2bf1:      	jne	0x2c2b <generic_retkprobe_event+0x2c2b>
    2bf3:      	movw	$0x28, 0x2(%r12)
    2bfb:      	movw	$0x28, %ax
    2bff:      	jmp	0x2c31 <generic_retkprobe_event+0x2c31>
    2c01:      	movzbl	0x7(%r12), %eax
    2c07:      	leal	0x8(,%rax,8), %eax
    2c0e:      	movw	%ax, 0x2(%r12)
    2c14:      	jmp	0x2c31 <generic_retkprobe_event+0x2c31>
    2c16:      	movzbl	0x7(%r12), %eax
    2c1c:      	leal	0x8(,%rax,4), %eax
    2c23:      	movw	%ax, 0x2(%r12)
    2c29:      	jmp	0x2c31 <generic_retkprobe_event+0x2c31>
    2c2b:      	movzwl	0x2(%r12), %eax
    2c31:      	addw	(%r12), %ax
    2c36:      	movw	%ax, (%r12)
    2c3b:      	movzbl	0x6(%r12), %ecx
    2c41:      	cmpq	$0x3c, %rcx
    2c45:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    2c4b:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2c55:      	btq	%rcx, %rdx
    2c59:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    2c5f:      	movb	%cl, 0x5(%r12)
    2c64:      	movzwl	%ax, %ecx
    2c67:      	addq	%r14, %rcx
    2c6a:      	movl	$0x2, %edx
    2c6f:      	movl	$0x4, %eax
    2c74:      	movq	%r13, %rdi
    2c77:      	movzwl	(%r12), %edx
    2c7c:      	addq	%r14, %rdx
    2c7f:      	movl	$0x2, %esi
    2c84:      	callq	*%rax
    2c86:      	testq	%rax, %rax
    2c89:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    2c8f:      	movzbl	0x5(%r12), %eax
    2c95:      	cmpl	$0x32, %eax
    2c98:      	jg	0x2cbd <generic_retkprobe_event+0x2cbd>
    2c9a:      	testl	%eax, %eax
    2c9c:      	je	0x2ce7 <generic_retkprobe_event+0x2ce7>
    2c9e:      	cmpl	$0x2b, %eax
    2ca1:      	je	0x2ce7 <generic_retkprobe_event+0x2ce7>
    2ca3:      	cmpl	$0x2c, %eax
    2ca6:      	jne	0x2de5 <generic_retkprobe_event+0x2de5>
    2cac:      	movw	$0x8, 0x2(%r12)
    2cb4:      	movw	$0x8, %ax
    2cb8:      	jmp	0x2deb <generic_retkprobe_event+0x2deb>
    2cbd:      	cmpl	$0x33, %eax
    2cc0:      	je	0x2dd0 <generic_retkprobe_event+0x2dd0>
    2cc6:      	cmpl	$0x3c, %eax
    2cc9:      	je	0x2ce7 <generic_retkprobe_event+0x2ce7>
    2ccb:      	cmpl	$0xff, %eax
    2cd0:      	jne	0x2de5 <generic_retkprobe_event+0x2de5>
    2cd6:      	movw	$0x28, 0x2(%r12)
    2cde:      	movw	$0x28, %ax
    2ce2:      	jmp	0x2deb <generic_retkprobe_event+0x2deb>
    2ce7:      	movzbl	0x7(%r12), %eax
    2ced:      	leal	0x8(,%rax,8), %eax
    2cf4:      	movw	%ax, 0x2(%r12)
    2cfa:      	jmp	0x2deb <generic_retkprobe_event+0x2deb>
    2cff:      	xorl	%eax, %eax
    2d01:      	movq	%rax, (%rsp)
    2d05:      	cmpq	$0x5, 0xa8(%rsp)
    2d0e:      	jb	0x28ca <generic_retkprobe_event+0x28ca>
    2d14:      	movq	0x98(%rsp), %rax
    2d1c:      	leaq	0x40(%rax), %rdx
    2d20:      	leaq	0x30(%rsp), %rdi
    2d25:      	movl	$0x4, %r12d
    2d2b:      	movl	$0x10, %ecx
    2d30:      	movl	$0x4, %eax
    2d35:      	movl	$0x10, %esi
    2d3a:      	callq	*%rax
    2d3c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d41:      	testl	%eax, %eax
    2d43:      	js	0x3356 <generic_retkprobe_event+0x3356>
    2d49:      	movq	0x38(%rsp), %rdx
    2d4e:      	movq	(%rsp), %rax
    2d52:      	cmpq	%rax, %rdx
    2d55:      	movq	%rax, %r13
    2d58:      	cmovbq	%rdx, %r13
    2d5c:      	testq	%rax, %rax
    2d5f:      	cmovneq	%r13, %rdx
    2d63:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d68:      	movq	%rdx, 0x8(%rsp)
    2d6d:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2d74:      	ja	0x3356 <generic_retkprobe_event+0x3356>
    2d7a:      	movq	%r14, %rdi
    2d7d:      	addq	%r15, %rdi
    2d80:      	movq	%rdi, %r14
    2d83:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d89:      	addq	0x20(%rsp), %rdi
    2d8e:      	movq	0x30(%rsp), %rcx
    2d93:      	movl	$0x4, %eax
    2d98:      	movq	0x8(%rsp), %rsi
    2d9d:      	movq	0x30(%rsp), %rdx
    2da2:      	callq	*%rax
    2da4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2da9:      	testl	%eax, %eax
    2dab:      	js	0x3356 <generic_retkprobe_event+0x3356>
    2db1:      	addq	0x8(%rsp), %rbp
    2db6:      	cmpq	$0x0, (%rsp)
    2dbb:      	je	0x31ef <generic_retkprobe_event+0x31ef>
    2dc1:      	subq	%r13, (%rsp)
    2dc5:      	jne	0x31f5 <generic_retkprobe_event+0x31f5>
    2dcb:      	jmp	0x28ca <generic_retkprobe_event+0x28ca>
    2dd0:      	movzbl	0x7(%r12), %eax
    2dd6:      	leal	0x8(,%rax,4), %eax
    2ddd:      	movw	%ax, 0x2(%r12)
    2de3:      	jmp	0x2deb <generic_retkprobe_event+0x2deb>
    2de5:      	movzwl	0x2(%r12), %eax
    2deb:      	addw	(%r12), %ax
    2df0:      	movw	%ax, (%r12)
    2df5:      	movzbl	0x6(%r12), %ecx
    2dfb:      	cmpq	$0x3c, %rcx
    2dff:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    2e05:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2e0f:      	btq	%rcx, %rdx
    2e13:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    2e19:      	movb	%cl, 0x5(%r12)
    2e1e:      	movzwl	%ax, %ecx
    2e21:      	addq	%r14, %rcx
    2e24:      	movl	$0x2, %edx
    2e29:      	movl	$0x4, %eax
    2e2e:      	movq	%r13, %rdi
    2e31:      	movzwl	(%r12), %edx
    2e36:      	addq	%r14, %rdx
    2e39:      	movl	$0x2, %esi
    2e3e:      	callq	*%rax
    2e40:      	testq	%rax, %rax
    2e43:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    2e49:      	movzbl	0x5(%r12), %eax
    2e4f:      	cmpl	$0x32, %eax
    2e52:      	jg	0x2e70 <generic_retkprobe_event+0x2e70>
    2e54:      	testl	%eax, %eax
    2e56:      	je	0x2e8f <generic_retkprobe_event+0x2e8f>
    2e58:      	cmpl	$0x2b, %eax
    2e5b:      	je	0x2e8f <generic_retkprobe_event+0x2e8f>
    2e5d:      	cmpl	$0x2c, %eax
    2e60:      	jne	0x2eb9 <generic_retkprobe_event+0x2eb9>
    2e62:      	movw	$0x8, 0x2(%r12)
    2e6a:      	movw	$0x8, %ax
    2e6e:      	jmp	0x2ebf <generic_retkprobe_event+0x2ebf>
    2e70:      	cmpl	$0x33, %eax
    2e73:      	je	0x2ea4 <generic_retkprobe_event+0x2ea4>
    2e75:      	cmpl	$0x3c, %eax
    2e78:      	je	0x2e8f <generic_retkprobe_event+0x2e8f>
    2e7a:      	cmpl	$0xff, %eax
    2e7f:      	jne	0x2eb9 <generic_retkprobe_event+0x2eb9>
    2e81:      	movw	$0x28, 0x2(%r12)
    2e89:      	movw	$0x28, %ax
    2e8d:      	jmp	0x2ebf <generic_retkprobe_event+0x2ebf>
    2e8f:      	movzbl	0x7(%r12), %eax
    2e95:      	leal	0x8(,%rax,8), %eax
    2e9c:      	movw	%ax, 0x2(%r12)
    2ea2:      	jmp	0x2ebf <generic_retkprobe_event+0x2ebf>
    2ea4:      	movzbl	0x7(%r12), %eax
    2eaa:      	leal	0x8(,%rax,4), %eax
    2eb1:      	movw	%ax, 0x2(%r12)
    2eb7:      	jmp	0x2ebf <generic_retkprobe_event+0x2ebf>
    2eb9:      	movzwl	0x2(%r12), %eax
    2ebf:      	addw	(%r12), %ax
    2ec4:      	movw	%ax, (%r12)
    2ec9:      	movzbl	0x6(%r12), %ecx
    2ecf:      	cmpq	$0x3c, %rcx
    2ed3:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    2ed9:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2ee3:      	btq	%rcx, %rdx
    2ee7:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    2eed:      	movb	%cl, 0x5(%r12)
    2ef2:      	movzwl	%ax, %ecx
    2ef5:      	addq	%r14, %rcx
    2ef8:      	movl	$0x2, %edx
    2efd:      	movl	$0x4, %eax
    2f02:      	movq	%r13, %rdi
    2f05:      	movzwl	(%r12), %edx
    2f0a:      	addq	%r14, %rdx
    2f0d:      	movl	$0x2, %esi
    2f12:      	callq	*%rax
    2f14:      	testq	%rax, %rax
    2f17:      	js	0x2fe8 <generic_retkprobe_event+0x2fe8>
    2f1d:      	movzbl	0x5(%r12), %eax
    2f23:      	cmpl	$0x32, %eax
    2f26:      	jg	0x2f44 <generic_retkprobe_event+0x2f44>
    2f28:      	testl	%eax, %eax
    2f2a:      	je	0x2f63 <generic_retkprobe_event+0x2f63>
    2f2c:      	cmpl	$0x2b, %eax
    2f2f:      	je	0x2f63 <generic_retkprobe_event+0x2f63>
    2f31:      	cmpl	$0x2c, %eax
    2f34:      	jne	0x2f8d <generic_retkprobe_event+0x2f8d>
    2f36:      	movw	$0x8, 0x2(%r12)
    2f3e:      	movw	$0x8, %ax
    2f42:      	jmp	0x2f93 <generic_retkprobe_event+0x2f93>
    2f44:      	cmpl	$0x33, %eax
    2f47:      	je	0x2f78 <generic_retkprobe_event+0x2f78>
    2f49:      	cmpl	$0x3c, %eax
    2f4c:      	je	0x2f63 <generic_retkprobe_event+0x2f63>
    2f4e:      	cmpl	$0xff, %eax
    2f53:      	jne	0x2f8d <generic_retkprobe_event+0x2f8d>
    2f55:      	movw	$0x28, 0x2(%r12)
    2f5d:      	movw	$0x28, %ax
    2f61:      	jmp	0x2f93 <generic_retkprobe_event+0x2f93>
    2f63:      	movzbl	0x7(%r12), %eax
    2f69:      	leal	0x8(,%rax,8), %eax
    2f70:      	movw	%ax, 0x2(%r12)
    2f76:      	jmp	0x2f93 <generic_retkprobe_event+0x2f93>
    2f78:      	movzbl	0x7(%r12), %eax
    2f7e:      	leal	0x8(,%rax,4), %eax
    2f85:      	movw	%ax, 0x2(%r12)
    2f8b:      	jmp	0x2f93 <generic_retkprobe_event+0x2f93>
    2f8d:      	movzwl	0x2(%r12), %eax
    2f93:      	addw	(%r12), %ax
    2f98:      	movw	%ax, (%r12)
    2f9d:      	movzbl	0x6(%r12), %ecx
    2fa3:      	cmpq	$0x3c, %rcx
    2fa7:      	ja	0x31e2 <generic_retkprobe_event+0x31e2>
    2fad:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2fb7:      	btq	%rcx, %rdx
    2fbb:      	jae	0x31e2 <generic_retkprobe_event+0x31e2>
    2fc1:      	movb	%cl, 0x5(%r12)
    2fc6:      	movzwl	%ax, %ecx
    2fc9:      	addq	%r14, %rcx
    2fcc:      	movl	$0x2, %edx
    2fd1:      	movl	$0x4, %eax
    2fd6:      	movzwl	(%r12), %edx
    2fdb:      	addq	%r14, %rdx
    2fde:      	movq	%r13, %rdi
    2fe1:      	movl	$0x2, %esi
    2fe6:      	callq	*%rax
    2fe8:      	xorl	%ecx, %ecx
    2fea:      	movb	%cl, 0xc8(%rsp)
    2ff1:      	movzbl	%cl, %eax
    2ff4:      	movq	(%rsp), %r14
    2ff8:      	movw	%ax, 0xc0(%r14)
    3000:      	movw	$0xa, 0xc2(%r14)
    300a:      	leaq	0x8(%rbx), %rdx
    300e:      	movl	$0x10, %ecx
    3013:      	movl	$0x4, %eax
    3018:      	movq	%rbp, %rdi
    301b:      	movl	$0x10, %esi
    3020:      	callq	*%rax
    3022:      	leaq	0xac(%r14), %rdi
    3029:      	addq	$0x18, %rbx
    302d:      	movl	$0x10, %ecx
    3032:      	movl	$0x4, %eax
    3037:      	movl	$0x10, %esi
    303c:      	movq	%rbx, %rdx
    303f:      	callq	*%rax
    3041:      	movzbl	0xc8(%rsp), %eax
    3049:      	cmpl	$0x11, %eax
    304c:      	je	0x30a0 <generic_retkprobe_event+0x30a0>
    304e:      	cmpl	$0x6, %eax
    3051:      	jne	0x30f0 <generic_retkprobe_event+0x30f0>
    3057:      	movq	0x30(%rsp), %r14
    305c:      	movzwl	0xd0(%rsp), %r12d
    3065:      	leaq	(%r14,%r12), %rdx
    3069:      	movq	(%rsp), %r13
    306d:      	leaq	0xbc(%r13), %rdi
    3074:      	movl	$0x2, %ecx
    3079:      	movl	$0x4, %eax
    307e:      	movl	$0x2, %esi
    3083:      	callq	*%rax
    3085:      	leaq	0xbe(%r13), %rdi
    308c:      	leaq	(%r14,%r12), %rdx
    3090:      	addq	$0x2, %rdx
    3094:      	movl	$0x2, %ecx
    3099:      	movl	$0x4, %eax
    309e:      	jmp	0x30e7 <generic_retkprobe_event+0x30e7>
    30a0:      	movq	0x30(%rsp), %r14
    30a5:      	movzwl	0xd0(%rsp), %r12d
    30ae:      	leaq	(%r14,%r12), %rdx
    30b2:      	movq	(%rsp), %r13
    30b6:      	leaq	0xbc(%r13), %rdi
    30bd:      	movl	$0x2, %ecx
    30c2:      	movl	$0x4, %eax
    30c7:      	movl	$0x2, %esi
    30cc:      	callq	*%rax
    30ce:      	leaq	0xbe(%r13), %rdi
    30d5:      	leaq	(%r14,%r12), %rdx
    30d9:      	addq	$0x2, %rdx
    30dd:      	movl	$0x2, %ecx
    30e2:      	movl	$0x4, %eax
    30e7:      	movl	$0x2, %esi
    30ec:      	callq	*%rax
    30ee:      	jmp	0x30ff <generic_retkprobe_event+0x30ff>
    30f0:      	movq	(%rsp), %r13
    30f4:      	movl	$0x0, 0xbc(%r13)
    30ff:      	movzwl	0xbc(%r13), %eax
    3107:      	movzwl	0xbe(%r13), %ecx
    310f:      	movbew	%ax, 0xbc(%r13)
    3119:      	movbew	%cx, 0xbe(%r13)
    3123:      	movq	0x80(%rsp), %rdx
    312b:      	addq	$0xe0, %rdx
    3132:      	leaq	0x70(%rsp), %rdi
    3137:      	movl	$0x8, %ecx
    313c:      	movl	$0x4, %eax
    3141:      	movl	$0x4, %r14d
    3147:      	movl	$0x8, %esi
    314c:      	callq	*%rax
    314e:      	movq	0x70(%rsp), %rcx
    3153:      	testq	%rcx, %rcx
    3156:      	je	0x31c8 <generic_retkprobe_event+0x31c8>
    3158:      	addq	$0x5, %rcx
    315c:      	leaq	0x88(%rsp), %rdi
    3164:      	movl	$0x8, %edx
    3169:      	movl	$0x4, %eax
    316e:      	movq	0x70(%rsp), %rdx
    3173:      	addq	$0x5, %rdx
    3177:      	movl	$0x8, %esi
    317c:      	callq	*%rax
    317e:      	movq	0x70(%rsp), %r12
    3183:      	movq	0x88(%rsp), %r13
    318b:      	movq	(%rsp), %rbp
    318f:      	leaq	0xd4(%rbp), %rdi
    3196:      	leaq	(%r12,%r13,8), %rdx
    319a:      	addq	$0x44, %rdx
    319e:      	movl	$0x4, %eax
    31a3:      	movl	$0x4, %esi
    31a8:      	callq	*%rax
    31aa:      	movq	%rbp, %rdi
    31ad:      	addq	$0xd8, %rdi
    31b4:      	leaq	(%r12,%r13,8), %rdx
    31b8:      	addq	$0x45, %rdx
    31bc:      	movl	$0x4, %eax
    31c1:      	movl	$0x4, %esi
    31c6:      	callq	*%rax
    31c8:      	movq	0x18(%rsp), %r13
    31cd:      	movq	0x8(%rsp), %rbx
    31d2:      	movq	0x20(%rsp), %r15
    31d7:      	movl	$0x40, %r12d
    31dd:      	jmp	0x1483 <generic_retkprobe_event+0x1483>
    31e2:      	movw	%ax, 0xd0(%rsp)
    31ea:      	jmp	0x2fea <generic_retkprobe_event+0x2fea>
    31ef:      	xorl	%eax, %eax
    31f1:      	movq	%rax, (%rsp)
    31f5:      	cmpq	$0x5, 0xa8(%rsp)
    31fe:      	je	0x28ca <generic_retkprobe_event+0x28ca>
    3204:      	movq	0x98(%rsp), %rax
    320c:      	leaq	0x50(%rax), %rdx
    3210:      	leaq	0x30(%rsp), %rdi
    3215:      	movl	$0x4, %r12d
    321b:      	movl	$0x10, %ecx
    3220:      	movl	$0x4, %eax
    3225:      	movl	$0x10, %esi
    322a:      	callq	*%rax
    322c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3231:      	testl	%eax, %eax
    3233:      	js	0x3356 <generic_retkprobe_event+0x3356>
    3239:      	movq	0x38(%rsp), %r15
    323e:      	movq	(%rsp), %rax
    3242:      	cmpq	%rax, %r15
    3245:      	movq	%rax, %r13
    3248:      	cmovbq	%r15, %r13
    324c:      	testq	%rax, %rax
    324f:      	cmovneq	%r13, %r15
    3253:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3258:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    325f:      	ja	0x3356 <generic_retkprobe_event+0x3356>
    3265:      	movq	0x8(%rsp), %rdi
    326a:      	addq	%r14, %rdi
    326d:      	movq	%rdi, %r14
    3270:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3276:      	addq	0x20(%rsp), %rdi
    327b:      	movq	0x30(%rsp), %rcx
    3280:      	movl	$0x4, %eax
    3285:      	movq	0x30(%rsp), %rdx
    328a:      	movl	%r15d, %esi
    328d:      	callq	*%rax
    328f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3294:      	testl	%eax, %eax
    3296:      	js	0x3356 <generic_retkprobe_event+0x3356>
    329c:      	addq	%r15, %rbp
    329f:      	cmpq	$0x0, (%rsp)
    32a4:      	je	0x32b1 <generic_retkprobe_event+0x32b1>
    32a6:      	subq	%r13, (%rsp)
    32aa:      	jne	0x32b7 <generic_retkprobe_event+0x32b7>
    32ac:      	jmp	0x28ca <generic_retkprobe_event+0x28ca>
    32b1:      	xorl	%eax, %eax
    32b3:      	movq	%rax, (%rsp)
    32b7:      	cmpq	$0x7, 0xa8(%rsp)
    32c0:      	jb	0x28ca <generic_retkprobe_event+0x28ca>
    32c6:      	movq	0x98(%rsp), %rdx
    32ce:      	addq	$0x60, %rdx
    32d2:      	leaq	0x30(%rsp), %rdi
    32d7:      	movl	$0x4, %r12d
    32dd:      	movl	$0x10, %ecx
    32e2:      	movl	$0x4, %eax
    32e7:      	movl	$0x10, %esi
    32ec:      	callq	*%rax
    32ee:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32f3:      	testl	%eax, %eax
    32f5:      	js	0x3356 <generic_retkprobe_event+0x3356>
    32f7:      	movq	0x38(%rsp), %rax
    32fc:      	movq	(%rsp), %rcx
    3300:      	cmpq	%rcx, %rax
    3303:      	movq	%rcx, %r13
    3306:      	cmovbq	%rax, %r13
    330a:      	testq	%rcx, %rcx
    330d:      	cmoveq	%rax, %r13
    3311:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3316:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    331d:      	ja	0x3356 <generic_retkprobe_event+0x3356>
    331f:      	addq	%r14, %r15
    3322:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    3329:      	addq	0x20(%rsp), %r15
    332e:      	movq	0x30(%rsp), %rcx
    3333:      	movl	$0x4, %eax
    3338:      	movq	0x30(%rsp), %rdx
    333d:      	movq	%r15, %rdi
    3340:      	movl	%r13d, %esi
    3343:      	callq	*%rax
    3345:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    334a:      	testl	%eax, %eax
    334c:      	js	0x3356 <generic_retkprobe_event+0x3356>
    334e:      	addq	%rbp, %r13
    3351:      	jmp	0x28cd <generic_retkprobe_event+0x28cd>
    3356:      	movq	0x28(%rsp), %r14
    335b:      	movq	0x20(%rsp), %rax
    3360:      	movl	%ecx, (%rax,%r14)
    3364:      	jmp	0x1b3e <generic_retkprobe_event+0x1b3e>
