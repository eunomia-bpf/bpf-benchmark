
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_xdp.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq
       a:      	nopw	(%rax,%rax)

0000000000000010 <__check_device_mtu>:
      10:      	movq	(%rip), %rax            # 0x17 <__check_device_mtu+0x7>
      17:      	movzwl	(%rax), %eax
      1a:      	retq

Disassembly of section xdp/tail:

0000000000000000 <tail_drop_notify>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x78, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x10(%rsp)
      19:      	movl	$0x1, %eax
      1e:      	movq	(%rip), %rdi            # 0x25 <tail_drop_notify+0x25>
      25:      	leaq	0x10(%rsp), %rsi
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x6b <tail_drop_notify+0x6b>
      31:      	movl	0x8(%rax), %eax
      34:      	movl	%eax, 0x8(%rsp)
      38:      	movq	(%rip), %rax            # 0x3f <tail_drop_notify+0x3f>
      3f:      	xorl	%ebp, %ebp
      41:      	cmpb	$0x0, (%rax)
      44:      	je	0x81 <tail_drop_notify+0x81>
      46:      	movl	$0x0, 0x10(%rsp)
      4e:      	movl	$0x1, %eax
      53:      	movq	(%rip), %rdi            # 0x5a <tail_drop_notify+0x5a>
      5a:      	leaq	0x10(%rsp), %rsi
      5f:      	callq	*%rax
      61:      	testq	%rax, %rax
      64:      	je	0x81 <tail_drop_notify+0x81>
      66:      	movq	(%rax), %r12
      69:      	jmp	0x84 <tail_drop_notify+0x84>
      6b:      	movl	$0x0, 0x8(%rsp)
      73:      	movq	(%rip), %rax            # 0x7a <tail_drop_notify+0x7a>
      7a:      	xorl	%ebp, %ebp
      7c:      	cmpb	$0x0, (%rax)
      7f:      	jne	0x46 <tail_drop_notify+0x46>
      81:      	xorl	%r12d, %r12d
      84:      	movq	0x8(%rbx), %rax
      88:      	subq	(%rbx), %rax
      8b:      	movq	%rax, 0x68(%rsp)
      90:      	movl	$0x0, 0x10(%rsp)
      98:      	movl	$0x1, %eax
      9d:      	movq	(%rip), %rdi            # 0xa4 <tail_drop_notify+0xa4>
      a4:      	leaq	0x10(%rsp), %rsi
      a9:      	callq	*%rax
      ab:      	testq	%rax, %rax
      ae:      	je	0xb3 <tail_drop_notify+0xb3>
      b0:      	movl	0x10(%rax), %ebp
      b3:      	movq	$0x2, 0x50(%rsp)
      bc:      	movq	(%rip), %rax            # 0xc3 <tail_drop_notify+0xc3>
      c3:      	cmpl	$0x0, (%rax)
      c6:      	je	0x1fd <tail_drop_notify+0x1fd>
      cc:      	movq	(%rip), %rcx            # 0xd3 <tail_drop_notify+0xd3>
      d3:      	movl	(%rcx), %ecx
      d5:      	movq	%rcx, 0x40(%rsp)
      da:      	movl	(%rax), %r13d
      dd:      	movl	$0x5, %ecx
      e2:      	xorl	%eax, %eax
      e4:      	callq	*%rcx
      e6:      	movq	%rax, %r15
      e9:      	movl	$0x2, 0xc(%rsp)
      f1:      	movl	$0x1, %eax
      f6:      	movq	(%rip), %rdi            # 0xfd <tail_drop_notify+0xfd>
      fd:      	leaq	0xc(%rsp), %rsi
     102:      	callq	*%rax
     104:      	movq	%rax, %r14
     107:      	testq	%rax, %rax
     10a:      	jne	0x13a <tail_drop_notify+0x13a>
     10c:      	movq	$0x0, 0x70(%rsp)
     115:      	movl	$0x2, %eax
     11a:      	movq	(%rip), %rdi            # 0x121 <tail_drop_notify+0x121>
     121:      	leaq	0xc(%rsp), %rsi
     126:      	leaq	0x70(%rsp), %r14
     12b:      	movq	%r14, %rdx
     12e:      	xorl	%ecx, %ecx
     130:      	callq	*%rax
     132:      	testl	%eax, %eax
     134:      	js	0x367 <tail_drop_notify+0x367>
     13a:      	movl	$0x1, %eax
     13f:      	movq	(%rip), %rdi            # 0x146 <tail_drop_notify+0x146>
     146:      	leaq	0x50(%rsp), %rsi
     14b:      	callq	*%rax
     14d:      	testq	%rax, %rax
     150:      	je	0x1b9 <tail_drop_notify+0x1b9>
     152:      	movq	(%rax), %rcx
     155:      	movq	%r15, %rsi
     158:      	subq	%rcx, %rsi
     15b:      	cmpq	$0x3b9aca00, %rsi       # imm = 0x3B9ACA00
     162:      	jbe	0x1e9 <tail_drop_notify+0x1e9>
     168:      	movl	$0x3b9aca00, %ecx       # imm = 0x3B9ACA00
     16d:      	movq	%rax, %rdi
     170:      	movq	%rsi, %rax
     173:      	xorl	%edx, %edx
     175:      	divq	%rcx
     178:      	movq	%rax, %rcx
     17b:      	movl	$0x3b9aca00, %r8d       # imm = 0x3B9ACA00
     181:      	movq	%rsi, %rax
     184:      	xorl	%edx, %edx
     186:      	divq	%r8
     189:      	movq	%rdi, %rax
     18c:      	imulq	%r13, %rcx
     190:      	addq	0x8(%rdi), %rcx
     194:      	movq	%rcx, 0x8(%rdi)
     198:      	subq	%rdx, %r15
     19b:      	movq	%r15, (%rdi)
     19e:      	movq	0x40(%rsp), %rdx
     1a3:      	cmpq	%rdx, %rcx
     1a6:      	jbe	0x1af <tail_drop_notify+0x1af>
     1a8:      	movq	%rdx, 0x8(%rax)
     1ac:      	movq	%rdx, %rcx
     1af:      	testq	%rcx, %rcx
     1b2:      	jne	0x1f6 <tail_drop_notify+0x1f6>
     1b4:      	jmp	0x37a <tail_drop_notify+0x37a>
     1b9:      	movq	%r15, 0x10(%rsp)
     1be:      	decq	%r13
     1c1:      	movq	%r13, 0x18(%rsp)
     1c6:      	movl	$0x2, %eax
     1cb:      	movq	(%rip), %rdi            # 0x1d2 <tail_drop_notify+0x1d2>
     1d2:      	leaq	0x50(%rsp), %rsi
     1d7:      	leaq	0x10(%rsp), %rdx
     1dc:      	xorl	%ecx, %ecx
     1de:      	callq	*%rax
     1e0:      	testl	%eax, %eax
     1e2:      	jns	0x1fd <tail_drop_notify+0x1fd>
     1e4:      	jmp	0x37a <tail_drop_notify+0x37a>
     1e9:      	movq	0x8(%rax), %rcx
     1ed:      	testq	%rcx, %rcx
     1f0:      	je	0x37a <tail_drop_notify+0x37a>
     1f6:      	decq	%rcx
     1f9:      	movq	%rcx, 0x8(%rax)
     1fd:      	movq	(%rbx), %rax
     200:      	movq	0x8(%rbx), %r14
     204:      	leaq	0xe(%rax), %rcx
     208:      	xorl	%r13d, %r13d
     20b:      	movl	$0x0, %edx
     210:      	cmpq	%r14, %rcx
     213:      	ja	0x222 <tail_drop_notify+0x222>
     215:      	movzwl	0xc(%rax), %ecx
     219:      	cmpl	$0xdd86, %ecx           # imm = 0xDD86
     21f:      	sete	%dl
     222:      	movl	%edx, 0x4c(%rsp)
     226:      	movq	%r12, 0x58(%rsp)
     22b:      	movq	%rbx, 0x40(%rsp)
     230:      	movq	(%rip), %rcx            # 0x237 <tail_drop_notify+0x237>
     237:      	movl	(%rcx), %ecx
     239:      	subq	%rax, %r14
     23c:      	cmpq	%rcx, %r14
     23f:      	cmovaeq	%rcx, %r14
     243:      	movl	$0x0, 0x10(%rsp)
     24b:      	movl	$0x1, %eax
     250:      	movq	(%rip), %rdi            # 0x257 <tail_drop_notify+0x257>
     257:      	leaq	0x10(%rsp), %rsi
     25c:      	callq	*%rax
     25e:      	testq	%rax, %rax
     261:      	je	0x266 <tail_drop_notify+0x266>
     263:      	movl	(%rax), %r13d
     266:      	movl	%ebp, %r12d
     269:      	shrl	$0x10, %r12d
     26d:      	movq	%rbp, 0x60(%rsp)
     272:      	shrl	$0x8, %ebp
     275:      	movl	$0x0, 0x10(%rsp)
     27d:      	movl	$0x1, %eax
     282:      	movq	(%rip), %rdi            # 0x289 <tail_drop_notify+0x289>
     289:      	leaq	0x10(%rsp), %rsi
     28e:      	callq	*%rax
     290:      	xorl	%r15d, %r15d
     293:      	movl	$0x0, %ebx
     298:      	testq	%rax, %rax
     29b:      	je	0x2a0 <tail_drop_notify+0x2a0>
     29d:      	movl	0x4(%rax), %ebx
     2a0:      	movl	$0x0, 0x10(%rsp)
     2a8:      	movl	$0x1, %eax
     2ad:      	movq	(%rip), %rdi            # 0x2b4 <tail_drop_notify+0x2b4>
     2b4:      	leaq	0x10(%rsp), %rsi
     2b9:      	callq	*%rax
     2bb:      	testq	%rax, %rax
     2be:      	je	0x2c4 <tail_drop_notify+0x2c4>
     2c0:      	movl	0xc(%rax), %r15d
     2c4:      	movq	0x40(%rsp), %rdi
     2c9:      	movl	0xc(%rdi), %eax
     2cc:      	movb	$0x0, 0x37(%rsp)
     2d1:      	movw	$0x0, 0x35(%rsp)
     2d8:      	movb	$0x1, 0x10(%rsp)
     2dd:      	movl	0x8(%rsp), %ecx
     2e1:      	movb	%cl, 0x11(%rsp)
     2e5:      	movw	$0x0, 0x12(%rsp)
     2ec:      	movl	$0x0, 0x14(%rsp)
     2f4:      	movq	0x68(%rsp), %rdx
     2f9:      	movl	%edx, 0x18(%rsp)
     2fd:      	movw	%r14w, 0x1c(%rsp)
     303:      	movw	$0x3, 0x1e(%rsp)
     30a:      	movl	%r13d, 0x20(%rsp)
     30f:      	movl	%ebx, 0x24(%rsp)
     313:      	movl	%r15d, 0x28(%rsp)
     318:      	movw	%r12w, 0x2c(%rsp)
     31e:      	movb	%bpl, 0x2e(%rsp)
     323:      	movb	%ch, 0x2f(%rsp)
     327:      	movl	%eax, 0x30(%rsp)
     32b:      	movl	0x4c(%rsp), %eax
     32f:      	movb	%al, 0x34(%rsp)
     333:      	movq	0x58(%rsp), %rax
     338:      	movq	%rax, 0x38(%rsp)
     33d:      	movl	$0x19, %eax
     342:      	shlq	$0x20, %r14
     346:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     34b:      	orq	%r14, %rdx
     34e:      	movq	(%rip), %rsi            # 0x355 <tail_drop_notify+0x355>
     355:      	leaq	0x10(%rsp), %rcx
     35a:      	movl	$0x30, %r8d
     360:      	callq	*%rax
     362:      	movq	0x60(%rsp), %rbp
     367:      	movzbl	%bpl, %eax
     36b:      	addq	$0x78, %rsp
     36f:      	popq	%rbx
     370:      	popq	%r12
     372:      	popq	%r13
     374:      	popq	%r14
     376:      	popq	%r15
     378:      	popq	%rbp
     379:      	retq
     37a:      	incq	(%r14)
     37d:      	jmp	0x367 <tail_drop_notify+0x367>

Disassembly of section xdp/entry:

0000000000000000 <cil_xdp_entry>:
       0:      	pushq	%rbp
       1:      	pushq	%r14
       3:      	pushq	%rbx
       4:      	subq	$0x10, %rsp
       8:      	movq	%rdi, %rbx
       b:      	movq	(%rip), %rax            # 0x12 <cil_xdp_entry+0x12>
      12:      	cmpb	$0x0, (%rax)
      15:      	je	0x55 <cil_xdp_entry+0x55>
      17:      	movzbl	(%rax), %edx
      1a:      	movq	(%rbx), %rcx
      1d:      	movq	0x8(%rbx), %rax
      21:      	leaq	0xe(%rcx), %rdi
      25:      	cmpq	%rax, %rdi
      28:      	jbe	0xe7 <cil_xdp_entry+0xe7>
      2e:      	movl	$0x0, 0xc(%rsp)
      36:      	movl	$0x1, %eax
      3b:      	movq	(%rip), %rdi            # 0x42 <cil_xdp_entry+0x42>
      42:      	leaq	0xc(%rsp), %rsi
      47:      	callq	*%rax
      49:      	testq	%rax, %rax
      4c:      	je	0x55 <cil_xdp_entry+0x55>
      4e:      	movq	$0x0, (%rax)
      55:      	movq	(%rbx), %rax
      58:      	leaq	0xe(%rax), %rcx
      5c:      	cmpq	0x8(%rbx), %rcx
      60:      	ja	0xd9 <cil_xdp_entry+0xd9>
      62:      	cmpw	$0x6, 0xc(%rax)
      67:      	jb	0xd9 <cil_xdp_entry+0xd9>
      69:      	movl	$0x0, 0xc(%rsp)
      71:      	movl	$0x1, %eax
      76:      	movq	(%rip), %rdi            # 0x7d <cil_xdp_entry+0x7d>
      7d:      	leaq	0xc(%rsp), %rsi
      82:      	callq	*%rax
      84:      	testq	%rax, %rax
      87:      	je	0x90 <cil_xdp_entry+0x90>
      89:      	movl	$0x0, 0x18(%rax)
      90:      	movl	$0x0, 0xc(%rsp)
      98:      	movl	$0x1, %eax
      9d:      	movq	(%rip), %rdi            # 0xa4 <cil_xdp_entry+0xa4>
      a4:      	leaq	0xc(%rsp), %rsi
      a9:      	callq	*%rax
      ab:      	testq	%rax, %rax
      ae:      	je	0xd9 <cil_xdp_entry+0xd9>
      b0:      	movl	0x18(%rax), %ebp
      b3:      	testl	%ebp, %ebp
      b5:      	je	0xd9 <cil_xdp_entry+0xd9>
      b7:      	movl	$0x36, %eax
      bc:      	movq	%rbx, %rdi
      bf:      	movl	$0xfffffffc, %esi       # imm = 0xFFFFFFFC
      c4:      	callq	*%rax
      c6:      	testl	%eax, %eax
      c8:      	jne	0xd9 <cil_xdp_entry+0xd9>
      ca:      	movq	0x10(%rbx), %rax
      ce:      	leaq	0x4(%rax), %rcx
      d2:      	cmpq	(%rbx), %rcx
      d5:      	ja	0xd9 <cil_xdp_entry+0xd9>
      d7:      	movl	%ebp, (%rax)
      d9:      	movl	$0x2, %eax
      de:      	addq	$0x10, %rsp
      e2:      	popq	%rbx
      e3:      	popq	%r14
      e5:      	popq	%rbp
      e6:      	retq
      e7:      	cmpw	$0x8, 0xc(%rcx)
      ec:      	jne	0x2e <cil_xdp_entry+0x2e>
      f2:      	leaq	0x22(%rcx), %rsi
      f6:      	cmpq	%rax, %rsi
      f9:      	ja	0x2e <cil_xdp_entry+0x2e>
      ff:      	movzbl	(%rdi), %edi
     102:      	andl	$0xf, %edi
     105:      	cmpb	$0x6, %dil
     109:      	jae	0x13a <cil_xdp_entry+0x13a>
     10b:      	xorl	%r14d, %r14d
     10e:      	movl	$0x0, 0xc(%rsp)
     116:      	movl	$0x1, %eax
     11b:      	movq	(%rip), %rdi            # 0x122 <cil_xdp_entry+0x122>
     122:      	leaq	0xc(%rsp), %rsi
     127:      	callq	*%rax
     129:      	testq	%rax, %rax
     12c:      	je	0x55 <cil_xdp_entry+0x55>
     132:      	movq	%r14, (%rax)
     135:      	jmp	0x55 <cil_xdp_entry+0x55>
     13a:      	leaq	0x23(%rcx), %r8
     13e:      	cmpq	%rax, %r8
     141:      	ja	0x2e <cil_xdp_entry+0x2e>
     147:      	movzbl	(%rsi), %r14d
     14b:      	testl	%r14d, %r14d
     14e:      	je	0x10e <cil_xdp_entry+0x10e>
     150:      	movl	$0x23, %esi
     155:      	cmpl	$0x1, %r14d
     159:      	jne	0x1e7 <cil_xdp_entry+0x1e7>
     15f:      	leal	0x22(,%rdi,4), %edi
     166:      	cmpl	%edi, %esi
     168:      	jae	0x10b <cil_xdp_entry+0x10b>
     16a:      	movl	%esi, %r8d
     16d:      	leaq	(%rcx,%r8), %r9
     171:      	incq	%r9
     174:      	cmpq	%rax, %r9
     177:      	ja	0x2e <cil_xdp_entry+0x2e>
     17d:      	leaq	(%rcx,%r8), %r9
     181:      	movzbl	(%r9), %r14d
     185:      	testl	%r14d, %r14d
     188:      	je	0x10e <cil_xdp_entry+0x10e>
     18a:      	cmpl	$0x1, %r14d
     18e:      	jne	0x27a <cil_xdp_entry+0x27a>
     194:      	addl	%r14d, %esi
     197:      	cmpl	%edi, %esi
     199:      	jae	0x10b <cil_xdp_entry+0x10b>
     19f:      	movl	%esi, %edi
     1a1:      	leaq	(%rcx,%rdi), %r8
     1a5:      	incq	%r8
     1a8:      	cmpq	%rax, %r8
     1ab:      	ja	0x2e <cil_xdp_entry+0x2e>
     1b1:      	leaq	(%rcx,%rdi), %r8
     1b5:      	movzbl	(%r8), %r8d
     1b9:      	cmpb	$0x2, %r8b
     1bd:      	jb	0x10b <cil_xdp_entry+0x10b>
     1c3:      	leaq	(%rcx,%rdi), %r9
     1c7:      	addq	$0x2, %r9
     1cb:      	cmpq	%rax, %r9
     1ce:      	ja	0x2e <cil_xdp_entry+0x2e>
     1d4:      	cmpb	%dl, %r8b
     1d7:      	jne	0x10b <cil_xdp_entry+0x10b>
     1dd:      	addq	%rcx, %rdi
     1e0:      	movzbl	0x1(%rdi), %r8d
     1e5:      	jmp	0x203 <cil_xdp_entry+0x203>
     1e7:      	leaq	0x24(%rcx), %rsi
     1eb:      	cmpq	%rax, %rsi
     1ee:      	ja	0x2e <cil_xdp_entry+0x2e>
     1f4:      	movzbl	0x23(%rcx), %r8d
     1f9:      	movl	$0x22, %esi
     1fe:      	cmpb	%dl, %r14b
     201:      	jne	0x25f <cil_xdp_entry+0x25f>
     203:      	cmpb	$0xa, %r8b
     207:      	je	0x2e6 <cil_xdp_entry+0x2e6>
     20d:      	movzbl	%r8b, %edx
     211:      	cmpl	$0x6, %edx
     214:      	je	0x2b0 <cil_xdp_entry+0x2b0>
     21a:      	cmpl	$0x4, %edx
     21d:      	jne	0x2e <cil_xdp_entry+0x2e>
     223:      	movl	%esi, %edx
     225:      	leaq	(%rcx,%rdx), %rsi
     229:      	addq	$0x4, %rsi
     22d:      	cmpq	%rax, %rsi
     230:      	ja	0x2e <cil_xdp_entry+0x2e>
     236:      	addq	%rdx, %rcx
     239:      	movl	$0x2, %esi
     23e:      	movl	$0x2, %eax
     243:      	xorl	%edx, %edx
     245:      	divq	%rsi
     248:      	cmpq	$0x1, %rdx
     24c:      	jne	0x31c <cil_xdp_entry+0x31c>
     252:      	movzbl	0x2(%rcx), %eax
     256:      	movzbl	0x3(%rcx), %ecx
     25a:      	jmp	0x325 <cil_xdp_entry+0x325>
     25f:      	movzbl	%r8b, %esi
     263:      	addl	$0x22, %esi
     266:      	leal	0x22(,%rdi,4), %edi
     26d:      	cmpl	%edi, %esi
     26f:      	jae	0x10b <cil_xdp_entry+0x10b>
     275:      	jmp	0x16a <cil_xdp_entry+0x16a>
     27a:      	leaq	(%rcx,%r8), %r9
     27e:      	addq	$0x2, %r9
     282:      	cmpq	%rax, %r9
     285:      	ja	0x2e <cil_xdp_entry+0x2e>
     28b:      	addq	%rcx, %r8
     28e:      	movzbl	0x1(%r8), %r8d
     293:      	cmpb	%dl, %r14b
     296:      	je	0x203 <cil_xdp_entry+0x203>
     29c:      	movzbl	%r8b, %r14d
     2a0:      	addl	%r14d, %esi
     2a3:      	cmpl	%edi, %esi
     2a5:      	jae	0x10b <cil_xdp_entry+0x10b>
     2ab:      	jmp	0x19f <cil_xdp_entry+0x19f>
     2b0:      	movl	%esi, %esi
     2b2:      	leaq	(%rcx,%rsi), %rdx
     2b6:      	addq	$0x6, %rdx
     2ba:      	cmpq	%rax, %rdx
     2bd:      	ja	0x2e <cil_xdp_entry+0x2e>
     2c3:      	movl	$0x2, %edi
     2c8:      	movl	$0x4, %eax
     2cd:      	xorl	%edx, %edx
     2cf:      	divq	%rdi
     2d2:      	cmpq	$0x1, %rdx
     2d6:      	je	0x33d <cil_xdp_entry+0x33d>
     2d8:      	addq	%rsi, %rcx
     2db:      	movbel	0x2(%rcx), %r14d
     2e1:      	jmp	0x10e <cil_xdp_entry+0x10e>
     2e6:      	movl	%esi, %esi
     2e8:      	leaq	(%rcx,%rsi), %rdx
     2ec:      	addq	$0xa, %rdx
     2f0:      	cmpq	%rax, %rdx
     2f3:      	ja	0x2e <cil_xdp_entry+0x2e>
     2f9:      	movl	$0x2, %edi
     2fe:      	movl	$0x8, %eax
     303:      	xorl	%edx, %edx
     305:      	divq	%rdi
     308:      	cmpq	$0x1, %rdx
     30c:      	je	0x33d <cil_xdp_entry+0x33d>
     30e:      	addq	%rsi, %rcx
     311:      	movbeq	0x2(%rcx), %r14
     317:      	jmp	0x10e <cil_xdp_entry+0x10e>
     31c:      	movzwl	0x2(%rcx), %eax
     320:      	movl	%eax, %ecx
     322:      	shrl	$0x8, %ecx
     325:      	movzbl	%cl, %ecx
     328:      	shll	$0x8, %ecx
     32b:      	movzbl	%al, %eax
     32e:      	orl	%ecx, %eax
     330:      	rolw	$0x8, %ax
     334:      	movzwl	%ax, %r14d
     338:      	jmp	0x10e <cil_xdp_entry+0x10e>
     33d:      	ud2
