
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/capable.native.o:	file format elf64-x86-64

Disassembly of section kprobe/cap_capable:

0000000000000000 <kprobe__cap_capable_entry>:
       0:      	pushq	%rbp
       1:      	pushq	%rbx
       2:      	subq	$0x18, %rsp
       6:      	movl	0x58(%rdi), %ebx
       9:      	movl	0x60(%rdi), %ebp
       c:      	movq	(%rip), %rax            # 0x13 <kprobe__cap_capable_entry+0x13>
      13:      	cmpb	$0x0, (%rax)
      16:      	je	0x2b <kprobe__cap_capable_entry+0x2b>
      18:      	movq	(%rip), %rdi            # 0x1f <kprobe__cap_capable_entry+0x1f>
      1f:      	xorl	%esi, %esi
      21:      	callq	0x26 <kprobe__cap_capable_entry+0x26>
      26:      	testq	%rax, %rax
      29:      	je	0x7a <kprobe__cap_capable_entry+0x7a>
      2b:      	callq	0x30 <kprobe__cap_capable_entry+0x30>
      30:      	movq	%rax, 0x10(%rsp)
      35:      	shrq	$0x20, %rax
      39:      	movq	(%rip), %rcx            # 0x40 <kprobe__cap_capable_entry+0x40>
      40:      	movl	(%rcx), %ecx
      42:      	cmpl	%eax, %ecx
      44:      	je	0x7a <kprobe__cap_capable_entry+0x7a>
      46:      	movq	(%rip), %rcx            # 0x4d <kprobe__cap_capable_entry+0x4d>
      4d:      	movl	(%rcx), %edx
      4f:      	cmpl	$-0x1, %edx
      52:      	je	0x5a <kprobe__cap_capable_entry+0x5a>
      54:      	movl	(%rcx), %ecx
      56:      	cmpl	%eax, %ecx
      58:      	jne	0x7a <kprobe__cap_capable_entry+0x7a>
      5a:      	movl	%ebp, 0x8(%rsp)
      5e:      	movl	%ebx, 0xc(%rsp)
      62:      	movq	(%rip), %rdi            # 0x69 <kprobe__cap_capable_entry+0x69>
      69:      	leaq	0x10(%rsp), %rsi
      6e:      	leaq	0x8(%rsp), %rdx
      73:      	xorl	%ecx, %ecx
      75:      	callq	0x7a <kprobe__cap_capable_entry+0x7a>
      7a:      	xorl	%eax, %eax
      7c:      	addq	$0x18, %rsp
      80:      	popq	%rbx
      81:      	popq	%rbp
      82:      	retq

Disassembly of section kretprobe/cap_capable:

0000000000000000 <kprobe__cap_capable_exit>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x58, %rsp
       7:      	movq	%rdi, %rbx
       a:      	callq	0xf <kprobe__cap_capable_exit+0xf>
       f:      	movq	%rax, 0x18(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <kprobe__cap_capable_exit+0x1b>
      1b:      	leaq	0x18(%rsp), %rsi
      20:      	callq	0x25 <kprobe__cap_capable_exit+0x25>
      25:      	testq	%rax, %rax
      28:      	je	0x1f9 <kprobe__cap_capable_exit+0x1f9>
      2e:      	movq	%rax, %r14
      31:      	movq	(%rip), %rdi            # 0x38 <kprobe__cap_capable_exit+0x38>
      38:      	leaq	0x18(%rsp), %rsi
      3d:      	callq	0x42 <kprobe__cap_capable_exit+0x42>
      42:      	movl	$0x0, 0x4c(%rsp)
      4a:      	movq	$0x0, 0x44(%rsp)
      53:      	movq	$0x0, 0x3c(%rsp)
      5c:      	movq	$0x0, 0x34(%rsp)
      65:      	movq	0x18(%rsp), %rax
      6a:      	movq	%rax, %rcx
      6d:      	shrq	$0x20, %rcx
      71:      	movl	%ecx, 0x24(%rsp)
      75:      	movl	%eax, 0x2c(%rsp)
      79:      	movl	(%r14), %eax
      7c:      	movl	%eax, 0x28(%rsp)
      80:      	callq	0x85 <kprobe__cap_capable_exit+0x85>
      85:      	movl	%eax, 0x30(%rsp)
      89:      	leaq	0x40(%rsp), %rdi
      8e:      	movl	$0x10, %esi
      93:      	callq	0x98 <kprobe__cap_capable_exit+0x98>
      98:      	movl	0x50(%rbx), %eax
      9b:      	movl	%eax, 0x3c(%rsp)
      9f:      	movq	(%rip), %rax            # 0xa6 <kprobe__cap_capable_exit+0xa6>
      a6:      	cmpl	$0x50100, (%rax)        # imm = 0x50100
      ac:      	movl	0x4(%r14), %eax
      b0:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
      b5:      	jl	0xc8 <kprobe__cap_capable_exit+0xc8>
      b7:      	xorl	%edx, %edx
      b9:      	testb	$0x2, %al
      bb:      	sete	%dl
      be:      	shrl	$0x2, %eax
      c1:      	movl	%eax, %ecx
      c3:      	andl	$0x1, %ecx
      c6:      	movl	%edx, %eax
      c8:      	movl	%eax, 0x34(%rsp)
      cc:      	movl	%ecx, 0x38(%rsp)
      d0:      	movq	(%rip), %rax            # 0xd7 <kprobe__cap_capable_exit+0xd7>
      d7:      	cmpl	$0x0, (%rax)
      da:      	je	0x14a <kprobe__cap_capable_exit+0x14a>
      dc:      	movl	(%r14), %ecx
      df:      	movl	%ecx, 0x8(%rsp)
      e3:      	movl	$0x0, 0xc(%rsp)
      eb:      	movq	$0x0, 0x10(%rsp)
      f4:      	movl	(%rax), %eax
      f6:      	cmpl	$0x2, %eax
      f9:      	jne	0x107 <kprobe__cap_capable_exit+0x107>
      fb:      	callq	0x100 <kprobe__cap_capable_exit+0x100>
     100:      	movq	%rax, 0x10(%rsp)
     105:      	jmp	0x10f <kprobe__cap_capable_exit+0x10f>
     107:      	movl	0x18(%rsp), %eax
     10b:      	movl	%eax, 0xc(%rsp)
     10f:      	movq	(%rip), %rdi            # 0x116 <kprobe__cap_capable_exit+0x116>
     116:      	leaq	0x8(%rsp), %rsi
     11b:      	callq	0x120 <kprobe__cap_capable_exit+0x120>
     120:      	testq	%rax, %rax
     123:      	jne	0x1f9 <kprobe__cap_capable_exit+0x1f9>
     129:      	movq	$0x0, 0x50(%rsp)
     132:      	movq	(%rip), %rdi            # 0x139 <kprobe__cap_capable_exit+0x139>
     139:      	leaq	0x8(%rsp), %rsi
     13e:      	leaq	0x50(%rsp), %rdx
     143:      	xorl	%ecx, %ecx
     145:      	callq	0x14a <kprobe__cap_capable_exit+0x14a>
     14a:      	movq	(%rip), %r14            # 0x151 <kprobe__cap_capable_exit+0x151>
     151:      	cmpb	$0x0, (%r14)
     155:      	jne	0x163 <kprobe__cap_capable_exit+0x163>
     157:      	movq	(%rip), %rax            # 0x15e <kprobe__cap_capable_exit+0x15e>
     15e:      	cmpb	$0x0, (%rax)
     161:      	je	0x1da <kprobe__cap_capable_exit+0x1da>
     163:      	movq	0x18(%rsp), %rax
     168:      	movq	%rax, %rcx
     16b:      	shrq	$0x20, %rcx
     16f:      	movl	%ecx, 0x8(%rsp)
     173:      	movl	%eax, 0xc(%rsp)
     177:      	movq	$-0x1, 0x10(%rsp)
     180:      	movq	(%rip), %rax            # 0x187 <kprobe__cap_capable_exit+0x187>
     187:      	cmpb	$0x0, (%rax)
     18a:      	je	0x1a4 <kprobe__cap_capable_exit+0x1a4>
     18c:      	movq	(%rip), %rsi            # 0x193 <kprobe__cap_capable_exit+0x193>
     193:      	movl	$0x100, %edx            # imm = 0x100
     198:      	movq	%rbx, %rdi
     19b:      	callq	0x1a0 <kprobe__cap_capable_exit+0x1a0>
     1a0:      	movl	%eax, 0x10(%rsp)
     1a4:      	cmpb	$0x0, (%r14)
     1a8:      	je	0x1bf <kprobe__cap_capable_exit+0x1bf>
     1aa:      	movq	(%rip), %rsi            # 0x1b1 <kprobe__cap_capable_exit+0x1b1>
     1b1:      	movq	%rbx, %rdi
     1b4:      	xorl	%edx, %edx
     1b6:      	callq	0x1bb <kprobe__cap_capable_exit+0x1bb>
     1bb:      	movl	%eax, 0x14(%rsp)
     1bf:      	movq	(%rip), %rdi            # 0x1c6 <kprobe__cap_capable_exit+0x1c6>
     1c6:      	leaq	0x8(%rsp), %rsi
     1cb:      	leaq	0x24(%rsp), %rdx
     1d0:      	movl	$0x1, %ecx
     1d5:      	callq	0x1da <kprobe__cap_capable_exit+0x1da>
     1da:      	movq	(%rip), %rsi            # 0x1e1 <kprobe__cap_capable_exit+0x1e1>
     1e1:      	leaq	0x24(%rsp), %rcx
     1e6:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     1eb:      	movl	$0x2c, %r8d
     1f1:      	movq	%rbx, %rdi
     1f4:      	callq	0x1f9 <kprobe__cap_capable_exit+0x1f9>
     1f9:      	xorl	%eax, %eax
     1fb:      	addq	$0x58, %rsp
     1ff:      	popq	%rbx
     200:      	popq	%r14
     202:      	retq
