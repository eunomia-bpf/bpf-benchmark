
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/runqlat.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <handle_switch>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%rbx
       6:      	subq	$0x18, %rsp
       a:      	movq	%rsi, %rbx
       d:      	movq	%rdi, %r14
      10:      	movq	(%rip), %rax            # 0x17 <handle_switch+0x17>
      17:      	cmpb	$0x0, (%rax)
      1a:      	je	0x33 <handle_switch+0x33>
      1c:      	movq	(%rip), %rdi            # 0x23 <handle_switch+0x23>
      23:      	xorl	%esi, %esi
      25:      	callq	0x2a <handle_switch+0x2a>
      2a:      	testq	%rax, %rax
      2d:      	je	0x2e3 <handle_switch+0x2e3>
      33:      	leaq	0x8(%rsp), %rdi
      38:      	movl	$0x4, %esi
      3d:      	movq	%r14, %rdx
      40:      	callq	0x45 <handle_switch+0x45>
      45:      	cmpl	$0x0, 0x8(%rsp)
      4a:      	jne	0xbf <handle_switch+0xbf>
      4c:      	leaq	0xaf4(%r14), %rdx
      53:      	leaq	0x8(%rsp), %rdi
      58:      	movl	$0x4, %esi
      5d:      	callq	0x62 <handle_switch+0x62>
      62:      	movl	0x8(%rsp), %ebp
      66:      	addq	$0xaf0, %r14            # imm = 0xAF0
      6d:      	leaq	0x8(%rsp), %rdi
      72:      	movl	$0x4, %esi
      77:      	movq	%r14, %rdx
      7a:      	callq	0x7f <handle_switch+0x7f>
      7f:      	movl	0x8(%rsp), %eax
      83:      	movl	%eax, 0x4(%rsp)
      87:      	testl	%eax, %eax
      89:      	je	0xbf <handle_switch+0xbf>
      8b:      	movq	(%rip), %rax            # 0x92 <handle_switch+0x92>
      92:      	cmpl	$0x0, (%rax)
      95:      	je	0x9d <handle_switch+0x9d>
      97:      	movl	(%rax), %eax
      99:      	cmpl	%ebp, %eax
      9b:      	jne	0xbf <handle_switch+0xbf>
      9d:      	callq	0xa2 <handle_switch+0xa2>
      a2:      	movq	%rax, 0x8(%rsp)
      a7:      	movq	(%rip), %rdi            # 0xae <handle_switch+0xae>
      ae:      	leaq	0x4(%rsp), %rsi
      b3:      	leaq	0x8(%rsp), %rdx
      b8:      	xorl	%ecx, %ecx
      ba:      	callq	0xbf <handle_switch+0xbf>
      bf:      	leaq	0xaf0(%rbx), %rdx
      c6:      	leaq	0x4(%rsp), %r14
      cb:      	movq	%r14, %rdi
      ce:      	movl	$0x4, %esi
      d3:      	callq	0xd8 <handle_switch+0xd8>
      d8:      	movq	(%rip), %rdi            # 0xdf <handle_switch+0xdf>
      df:      	movq	%r14, %rsi
      e2:      	callq	0xe7 <handle_switch+0xe7>
      e7:      	testq	%rax, %rax
      ea:      	je	0x2e3 <handle_switch+0x2e3>
      f0:      	movq	%rax, %r14
      f3:      	callq	0xf8 <handle_switch+0xf8>
      f8:      	movq	%rax, %r15
      fb:      	subq	(%r14), %r15
      fe:      	js	0x2d2 <handle_switch+0x2d2>
     104:      	movq	(%rip), %rax            # 0x10b <handle_switch+0x10b>
     10b:      	cmpb	$0x0, (%rax)
     10e:      	je	0x126 <handle_switch+0x126>
     110:      	leaq	0xaf4(%rbx), %rdx
     117:      	movq	%rsp, %rdi
     11a:      	movl	$0x4, %esi
     11f:      	callq	0x124 <handle_switch+0x124>
     124:      	jmp	0x13d <handle_switch+0x13d>
     126:      	movq	(%rip), %rax            # 0x12d <handle_switch+0x12d>
     12d:      	cmpb	$0x0, (%rax)
     130:      	je	0x2ee <handle_switch+0x2ee>
     136:      	movl	0x4(%rsp), %eax
     13a:      	movl	%eax, (%rsp)
     13d:      	movq	(%rip), %rdi            # 0x144 <handle_switch+0x144>
     144:      	movq	%rsp, %rsi
     147:      	callq	0x14c <handle_switch+0x14c>
     14c:      	movq	%rax, %r14
     14f:      	testq	%rax, %rax
     152:      	je	0x1e6 <handle_switch+0x1e6>
     158:      	cmpb	$0x0, 0x68(%r14)
     15d:      	je	0x230 <handle_switch+0x230>
     163:      	movq	(%rip), %rax            # 0x16a <handle_switch+0x16a>
     16a:      	cmpb	$0x0, (%rax)
     16d:      	je	0x258 <handle_switch+0x258>
     173:      	movl	$0xf4240, %ecx          # imm = 0xF4240
     178:      	movq	%r15, %rax
     17b:      	cqto
     17d:      	idivq	%rcx
     180:      	movq	%rax, %rdx
     183:      	xorl	%ecx, %ecx
     185:      	shrq	$0x20, %rdx
     189:      	je	0x274 <handle_switch+0x274>
     18f:      	cmpl	$0x10000, %edx          # imm = 0x10000
     195:      	setae	%cl
     198:      	shll	$0x4, %ecx
     19b:      	shrxl	%ecx, %edx, %edx
     1a0:      	xorl	%eax, %eax
     1a2:      	cmpl	$0x100, %edx            # imm = 0x100
     1a8:      	setae	%al
     1ab:      	shll	$0x3, %eax
     1ae:      	shrxl	%eax, %edx, %edx
     1b3:      	xorl	%esi, %esi
     1b5:      	cmpl	$0x10, %edx
     1b8:      	setae	%sil
     1bc:      	shll	$0x2, %esi
     1bf:      	shrxl	%esi, %edx, %edx
     1c4:      	xorl	%edi, %edi
     1c6:      	cmpl	$0x4, %edx
     1c9:      	setae	%dil
     1cd:      	addl	%edi, %edi
     1cf:      	shrxl	%edi, %edx, %edx
     1d4:      	shrl	%edx
     1d6:      	orl	%ecx, %eax
     1d8:      	orl	%esi, %eax
     1da:      	orl	%edi, %eax
     1dc:      	orl	%edx, %eax
     1de:      	addl	$0x20, %eax
     1e1:      	jmp	0x2c2 <handle_switch+0x2c2>
     1e6:      	movq	(%rip), %rdi            # 0x1ed <handle_switch+0x1ed>
     1ed:      	leaq	(%rip), %rdx            # 0x1f4 <handle_switch+0x1f4>
     1f4:      	movq	%rsp, %rsi
     1f7:      	movl	$0x1, %ecx
     1fc:      	callq	0x201 <handle_switch+0x201>
     201:      	testq	%rax, %rax
     204:      	je	0x210 <handle_switch+0x210>
     206:      	cmpq	$-0x11, %rax
     20a:      	jne	0x2d2 <handle_switch+0x2d2>
     210:      	movq	(%rip), %rdi            # 0x217 <handle_switch+0x217>
     217:      	movq	%rsp, %rsi
     21a:      	callq	0x21f <handle_switch+0x21f>
     21f:      	movq	%rax, %r14
     222:      	testq	%rax, %rax
     225:      	jne	0x158 <handle_switch+0x158>
     22b:      	jmp	0x2d2 <handle_switch+0x2d2>
     230:      	leaq	0x68(%r14), %rdi
     234:      	addq	$0xd10, %rbx            # imm = 0xD10
     23b:      	movl	$0x10, %esi
     240:      	movq	%rbx, %rdx
     243:      	callq	0x248 <handle_switch+0x248>
     248:      	movq	(%rip), %rax            # 0x24f <handle_switch+0x24f>
     24f:      	cmpb	$0x0, (%rax)
     252:      	jne	0x173 <handle_switch+0x173>
     258:      	movl	$0x3e8, %ecx            # imm = 0x3E8
     25d:      	movq	%r15, %rax
     260:      	cqto
     262:      	idivq	%rcx
     265:      	movq	%rax, %rdx
     268:      	xorl	%ecx, %ecx
     26a:      	shrq	$0x20, %rdx
     26e:      	jne	0x18f <handle_switch+0x18f>
     274:      	cmpl	$0x10000, %eax          # imm = 0x10000
     279:      	setae	%cl
     27c:      	shll	$0x4, %ecx
     27f:      	shrxl	%ecx, %eax, %edx
     284:      	xorl	%eax, %eax
     286:      	cmpl	$0x100, %edx            # imm = 0x100
     28c:      	setae	%al
     28f:      	shll	$0x3, %eax
     292:      	shrxl	%eax, %edx, %edx
     297:      	xorl	%esi, %esi
     299:      	cmpl	$0x10, %edx
     29c:      	setae	%sil
     2a0:      	shll	$0x2, %esi
     2a3:      	shrxl	%esi, %edx, %edx
     2a8:      	xorl	%edi, %edi
     2aa:      	cmpl	$0x4, %edx
     2ad:      	setae	%dil
     2b1:      	addl	%edi, %edi
     2b3:      	shrxl	%edi, %edx, %edx
     2b8:      	shrl	%edx
     2ba:      	orl	%ecx, %eax
     2bc:      	orl	%esi, %eax
     2be:      	orl	%edi, %eax
     2c0:      	orl	%edx, %eax
     2c2:      	cmpl	$0x19, %eax
     2c5:      	movl	$0x19, %ecx
     2ca:      	cmovbl	%eax, %ecx
     2cd:      	lock
     2ce:      	incl	(%r14,%rcx,4)
     2d2:      	movq	(%rip), %rdi            # 0x2d9 <handle_switch+0x2d9>
     2d9:      	leaq	0x4(%rsp), %rsi
     2de:      	callq	0x2e3 <handle_switch+0x2e3>
     2e3:      	addq	$0x18, %rsp
     2e7:      	popq	%rbx
     2e8:      	popq	%r14
     2ea:      	popq	%r15
     2ec:      	popq	%rbp
     2ed:      	retq
     2ee:      	movq	(%rip), %rax            # 0x2f5 <handle_switch+0x2f5>
     2f5:      	cmpb	$0x0, (%rax)
     2f8:      	je	0x359 <handle_switch+0x359>
     2fa:      	leaq	0xb58(%rbx), %rdx
     301:      	leaq	0x8(%rsp), %rdi
     306:      	movl	$0x8, %esi
     30b:      	callq	0x310 <handle_switch+0x310>
     310:      	movq	0x8(%rsp), %r14
     315:      	leaq	0x4(%r14), %rdx
     319:      	leaq	0x8(%rsp), %rdi
     31e:      	movl	$0x4, %esi
     323:      	callq	0x328 <handle_switch+0x328>
     328:      	movl	0x8(%rsp), %eax
     32c:      	shlq	$0x4, %rax
     330:      	leaq	(%r14,%rax), %rdx
     334:      	addq	$0x80, %rdx
     33b:      	leaq	0x8(%rsp), %rdi
     340:      	movl	$0x10, %esi
     345:      	callq	0x34a <handle_switch+0x34a>
     34a:      	movl	$0x158, %edx            # imm = 0x158
     34f:      	addq	0x10(%rsp), %rdx
     354:      	jmp	0x117 <handle_switch+0x117>
     359:      	movl	$0xffffffff, (%rsp)     # imm = 0xFFFFFFFF
     360:      	jmp	0x13d <handle_switch+0x13d>

Disassembly of section tp_btf/sched_wakeup:

0000000000000000 <sched_wakeup>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movq	(%rdi), %rbx
       8:      	movq	(%rip), %rax            # 0xf <sched_wakeup+0xf>
       f:      	cmpb	$0x0, (%rax)
      12:      	je	0x27 <sched_wakeup+0x27>
      14:      	movq	(%rip), %rdi            # 0x1b <sched_wakeup+0x1b>
      1b:      	xorl	%esi, %esi
      1d:      	callq	0x22 <sched_wakeup+0x22>
      22:      	testq	%rax, %rax
      25:      	je	0x6f <sched_wakeup+0x6f>
      27:      	movl	0xaf0(%rbx), %ecx
      2d:      	movl	0xaf4(%rbx), %eax
      33:      	movl	%ecx, 0x4(%rsp)
      37:      	testl	%ecx, %ecx
      39:      	je	0x6f <sched_wakeup+0x6f>
      3b:      	movq	(%rip), %rcx            # 0x42 <sched_wakeup+0x42>
      42:      	cmpl	$0x0, (%rcx)
      45:      	je	0x4d <sched_wakeup+0x4d>
      47:      	movl	(%rcx), %ecx
      49:      	cmpl	%eax, %ecx
      4b:      	jne	0x6f <sched_wakeup+0x6f>
      4d:      	callq	0x52 <sched_wakeup+0x52>
      52:      	movq	%rax, 0x8(%rsp)
      57:      	movq	(%rip), %rdi            # 0x5e <sched_wakeup+0x5e>
      5e:      	leaq	0x4(%rsp), %rsi
      63:      	leaq	0x8(%rsp), %rdx
      68:      	xorl	%ecx, %ecx
      6a:      	callq	0x6f <sched_wakeup+0x6f>
      6f:      	xorl	%eax, %eax
      71:      	addq	$0x10, %rsp
      75:      	popq	%rbx
      76:      	retq

Disassembly of section tp_btf/sched_wakeup_new:

0000000000000000 <sched_wakeup_new>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movq	(%rdi), %rbx
       8:      	movq	(%rip), %rax            # 0xf <sched_wakeup_new+0xf>
       f:      	cmpb	$0x0, (%rax)
      12:      	je	0x27 <sched_wakeup_new+0x27>
      14:      	movq	(%rip), %rdi            # 0x1b <sched_wakeup_new+0x1b>
      1b:      	xorl	%esi, %esi
      1d:      	callq	0x22 <sched_wakeup_new+0x22>
      22:      	testq	%rax, %rax
      25:      	je	0x6f <sched_wakeup_new+0x6f>
      27:      	movl	0xaf0(%rbx), %ecx
      2d:      	movl	0xaf4(%rbx), %eax
      33:      	movl	%ecx, 0x4(%rsp)
      37:      	testl	%ecx, %ecx
      39:      	je	0x6f <sched_wakeup_new+0x6f>
      3b:      	movq	(%rip), %rcx            # 0x42 <sched_wakeup_new+0x42>
      42:      	cmpl	$0x0, (%rcx)
      45:      	je	0x4d <sched_wakeup_new+0x4d>
      47:      	movl	(%rcx), %ecx
      49:      	cmpl	%eax, %ecx
      4b:      	jne	0x6f <sched_wakeup_new+0x6f>
      4d:      	callq	0x52 <sched_wakeup_new+0x52>
      52:      	movq	%rax, 0x8(%rsp)
      57:      	movq	(%rip), %rdi            # 0x5e <sched_wakeup_new+0x5e>
      5e:      	leaq	0x4(%rsp), %rsi
      63:      	leaq	0x8(%rsp), %rdx
      68:      	xorl	%ecx, %ecx
      6a:      	callq	0x6f <sched_wakeup_new+0x6f>
      6f:      	xorl	%eax, %eax
      71:      	addq	$0x10, %rsp
      75:      	popq	%rbx
      76:      	retq

Disassembly of section tp_btf/sched_switch:

0000000000000000 <sched_switch>:
       0:      	pushq	%rax
       1:      	movq	0x8(%rdi), %rax
       5:      	movq	0x10(%rdi), %rsi
       9:      	movq	%rax, %rdi
       c:      	callq	0x11 <sched_switch+0x11>
      11:      	xorl	%eax, %eax
      13:      	popq	%rcx
      14:      	retq

Disassembly of section raw_tp/sched_wakeup:

0000000000000000 <handle_sched_wakeup>:
       0:      	pushq	%rbp
       1:      	pushq	%rbx
       2:      	subq	$0x18, %rsp
       6:      	movq	(%rdi), %rbx
       9:      	movq	(%rip), %rax            # 0x10 <handle_sched_wakeup+0x10>
      10:      	cmpb	$0x0, (%rax)
      13:      	je	0x28 <handle_sched_wakeup+0x28>
      15:      	movq	(%rip), %rdi            # 0x1c <handle_sched_wakeup+0x1c>
      1c:      	xorl	%esi, %esi
      1e:      	callq	0x23 <handle_sched_wakeup+0x23>
      23:      	testq	%rax, %rax
      26:      	je	0x9b <handle_sched_wakeup+0x9b>
      28:      	leaq	0xaf4(%rbx), %rdx
      2f:      	leaq	0x8(%rsp), %rdi
      34:      	movl	$0x4, %esi
      39:      	callq	0x3e <handle_sched_wakeup+0x3e>
      3e:      	movl	0x8(%rsp), %ebp
      42:      	addq	$0xaf0, %rbx            # imm = 0xAF0
      49:      	leaq	0x8(%rsp), %rdi
      4e:      	movl	$0x4, %esi
      53:      	movq	%rbx, %rdx
      56:      	callq	0x5b <handle_sched_wakeup+0x5b>
      5b:      	movl	0x8(%rsp), %eax
      5f:      	movl	%eax, 0x14(%rsp)
      63:      	testl	%eax, %eax
      65:      	je	0x9b <handle_sched_wakeup+0x9b>
      67:      	movq	(%rip), %rax            # 0x6e <handle_sched_wakeup+0x6e>
      6e:      	cmpl	$0x0, (%rax)
      71:      	je	0x79 <handle_sched_wakeup+0x79>
      73:      	movl	(%rax), %eax
      75:      	cmpl	%ebp, %eax
      77:      	jne	0x9b <handle_sched_wakeup+0x9b>
      79:      	callq	0x7e <handle_sched_wakeup+0x7e>
      7e:      	movq	%rax, 0x8(%rsp)
      83:      	movq	(%rip), %rdi            # 0x8a <handle_sched_wakeup+0x8a>
      8a:      	leaq	0x14(%rsp), %rsi
      8f:      	leaq	0x8(%rsp), %rdx
      94:      	xorl	%ecx, %ecx
      96:      	callq	0x9b <handle_sched_wakeup+0x9b>
      9b:      	xorl	%eax, %eax
      9d:      	addq	$0x18, %rsp
      a1:      	popq	%rbx
      a2:      	popq	%rbp
      a3:      	retq

Disassembly of section raw_tp/sched_wakeup_new:

0000000000000000 <handle_sched_wakeup_new>:
       0:      	pushq	%rbp
       1:      	pushq	%rbx
       2:      	subq	$0x18, %rsp
       6:      	movq	(%rdi), %rbx
       9:      	movq	(%rip), %rax            # 0x10 <handle_sched_wakeup_new+0x10>
      10:      	cmpb	$0x0, (%rax)
      13:      	je	0x28 <handle_sched_wakeup_new+0x28>
      15:      	movq	(%rip), %rdi            # 0x1c <handle_sched_wakeup_new+0x1c>
      1c:      	xorl	%esi, %esi
      1e:      	callq	0x23 <handle_sched_wakeup_new+0x23>
      23:      	testq	%rax, %rax
      26:      	je	0x9b <handle_sched_wakeup_new+0x9b>
      28:      	leaq	0xaf4(%rbx), %rdx
      2f:      	leaq	0x8(%rsp), %rdi
      34:      	movl	$0x4, %esi
      39:      	callq	0x3e <handle_sched_wakeup_new+0x3e>
      3e:      	movl	0x8(%rsp), %ebp
      42:      	addq	$0xaf0, %rbx            # imm = 0xAF0
      49:      	leaq	0x8(%rsp), %rdi
      4e:      	movl	$0x4, %esi
      53:      	movq	%rbx, %rdx
      56:      	callq	0x5b <handle_sched_wakeup_new+0x5b>
      5b:      	movl	0x8(%rsp), %eax
      5f:      	movl	%eax, 0x14(%rsp)
      63:      	testl	%eax, %eax
      65:      	je	0x9b <handle_sched_wakeup_new+0x9b>
      67:      	movq	(%rip), %rax            # 0x6e <handle_sched_wakeup_new+0x6e>
      6e:      	cmpl	$0x0, (%rax)
      71:      	je	0x79 <handle_sched_wakeup_new+0x79>
      73:      	movl	(%rax), %eax
      75:      	cmpl	%ebp, %eax
      77:      	jne	0x9b <handle_sched_wakeup_new+0x9b>
      79:      	callq	0x7e <handle_sched_wakeup_new+0x7e>
      7e:      	movq	%rax, 0x8(%rsp)
      83:      	movq	(%rip), %rdi            # 0x8a <handle_sched_wakeup_new+0x8a>
      8a:      	leaq	0x14(%rsp), %rsi
      8f:      	leaq	0x8(%rsp), %rdx
      94:      	xorl	%ecx, %ecx
      96:      	callq	0x9b <handle_sched_wakeup_new+0x9b>
      9b:      	xorl	%eax, %eax
      9d:      	addq	$0x18, %rsp
      a1:      	popq	%rbx
      a2:      	popq	%rbp
      a3:      	retq

Disassembly of section raw_tp/sched_switch:

0000000000000000 <handle_sched_switch>:
       0:      	pushq	%rax
       1:      	movq	0x8(%rdi), %rax
       5:      	movq	0x10(%rdi), %rsi
       9:      	movq	%rax, %rdi
       c:      	callq	0x11 <handle_sched_switch+0x11>
      11:      	xorl	%eax, %eax
      13:      	popq	%rcx
      14:      	retq
