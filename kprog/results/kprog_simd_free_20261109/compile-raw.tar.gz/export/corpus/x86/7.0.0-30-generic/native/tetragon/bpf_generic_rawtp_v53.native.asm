
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_rawtp_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section raw_tp:

0000000000000000 <generic_rawtp_setup_event>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x18, %rsp
       7:      	movq	%rdi, %rbx
       a:      	movl	$0x0, 0x14(%rsp)
      12:      	movq	(%rip), %rdi            # 0x19 <generic_rawtp_setup_event+0x19>
      19:      	leaq	0x14(%rsp), %rsi
      1e:      	movl	$0x1, %eax
      23:      	callq	*%rax
      25:      	testq	%rax, %rax
      28:      	je	0x1be <generic_rawtp_setup_event+0x1be>
      2e:      	movq	%rax, %r14
      31:      	leaq	0x5ef8(%rax), %rsi
      38:      	movq	(%rip), %rdi            # 0x3f <generic_rawtp_setup_event+0x3f>
      3f:      	movl	$0x1, %eax
      44:      	callq	*%rax
      46:      	testq	%rax, %rax
      49:      	je	0x1be <generic_rawtp_setup_event+0x1be>
      4f:      	leaq	0x8(%rsp), %rdi
      54:      	movl	$0x8, %ecx
      59:      	movl	$0x4, %eax
      5e:      	movl	$0x8, %esi
      63:      	movq	%rbx, %rdx
      66:      	callq	*%rax
      68:      	movq	0x8(%rsp), %rax
      6d:      	movq	%rax, 0x5e50(%r14)
      74:      	leaq	0x8(%rbx), %rdx
      78:      	leaq	0x8(%rsp), %rdi
      7d:      	movl	$0x8, %ecx
      82:      	movl	$0x4, %eax
      87:      	movl	$0x8, %esi
      8c:      	callq	*%rax
      8e:      	movq	0x8(%rsp), %rax
      93:      	movq	%rax, 0x5e58(%r14)
      9a:      	leaq	0x10(%rbx), %rdx
      9e:      	leaq	0x8(%rsp), %rdi
      a3:      	movl	$0x8, %ecx
      a8:      	movl	$0x4, %eax
      ad:      	movl	$0x8, %esi
      b2:      	callq	*%rax
      b4:      	movq	0x8(%rsp), %rax
      b9:      	movq	%rax, 0x5e60(%r14)
      c0:      	leaq	0x18(%rbx), %rdx
      c4:      	leaq	0x8(%rsp), %rdi
      c9:      	movl	$0x8, %ecx
      ce:      	movl	$0x4, %eax
      d3:      	movl	$0x8, %esi
      d8:      	callq	*%rax
      da:      	movq	0x8(%rsp), %rax
      df:      	movq	%rax, 0x5e68(%r14)
      e6:      	leaq	0x20(%rbx), %rdx
      ea:      	leaq	0x8(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x4, %eax
      f9:      	movl	$0x8, %esi
      fe:      	callq	*%rax
     100:      	movq	0x8(%rsp), %rax
     105:      	movq	%rax, 0x5e70(%r14)
     10c:      	movb	$0xe, (%r14)
     110:      	movw	$0x0, 0x2(%r14)
     117:      	movl	$0x0, 0x4(%r14)
     11f:      	movl	$0x7d, %eax
     124:      	callq	*%rax
     126:      	movq	%rax, 0x8(%r14)
     12a:      	movq	$0x0, 0x70(%r14)
     132:      	movl	$0x0, 0x14(%r14)
     13a:      	movl	$0xe, %eax
     13f:      	callq	*%rax
     141:      	movl	%eax, 0x7c(%r14)
     145:      	movl	$0x0, 0x8(%rsp)
     14d:      	movq	(%rip), %rdi            # 0x154 <generic_rawtp_setup_event+0x154>
     154:      	leaq	0x8(%rsp), %rsi
     159:      	movl	$0x1, %eax
     15e:      	callq	*%rax
     160:      	testq	%rax, %rax
     163:      	je	0x188 <generic_rawtp_setup_event+0x188>
     165:      	movq	%rax, %rsi
     168:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     16f:      	movq	(%rip), %rdi            # 0x176 <generic_rawtp_setup_event+0x176>
     176:      	movl	$0x1, %eax
     17b:      	callq	*%rax
     17d:      	testq	%rax, %rax
     180:      	je	0x188 <generic_rawtp_setup_event+0x188>
     182:      	cmpl	$-0x1, 0x40(%rax)
     186:      	jne	0x1a3 <generic_rawtp_setup_event+0x1a3>
     188:      	movq	(%rip), %rsi            # 0x18f <generic_rawtp_setup_event+0x18f>
     18f:      	movl	$0x3, %ecx
     194:      	movl	$0xc, %eax
     199:      	movq	%rbx, %rdi
     19c:      	movl	$0x3, %edx
     1a1:      	callq	*%rax
     1a3:      	movq	(%rip), %rsi            # 0x1aa <generic_rawtp_setup_event+0x1aa>
     1aa:      	movl	$0x1, %ecx
     1af:      	movl	$0xc, %eax
     1b4:      	movq	%rbx, %rdi
     1b7:      	movl	$0x1, %edx
     1bc:      	callq	*%rax
     1be:      	xorl	%eax, %eax
     1c0:      	addq	$0x18, %rsp
     1c4:      	popq	%rbx
     1c5:      	popq	%r14
     1c7:      	retq
     1c8:      	nopl	(%rax,%rax)

00000000000001d0 <generic_rawtp_process_event>:
     1d0:      	pushq	%rbp
     1d1:      	pushq	%r15
     1d3:      	pushq	%r14
     1d5:      	pushq	%r13
     1d7:      	pushq	%r12
     1d9:      	pushq	%rbx
     1da:      	subq	$0x108, %rsp            # imm = 0x108
     1e1:      	movq	%rdi, %rbx
     1e4:      	movl	$0x0, 0xf4(%rsp)
     1ef:      	movq	(%rip), %rdi            # 0x1f6 <generic_rawtp_process_event+0x26>
     1f6:      	leaq	0xf4(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0xa0c <generic_rawtp_process_event+0x83c>
     20e:      	movq	%rax, %r14
     211:      	movl	0x5efc(%rax), %r12d
     218:      	movl	0x4(%rax), %r13d
     21c:      	cmpq	$0x2327, %r13           # imm = 0x2327
     223:      	ja	0x96d <generic_rawtp_process_event+0x79d>
     229:      	movl	$0x0, 0xf8(%rsp)
     234:      	movq	(%rip), %rdi            # 0x23b <generic_rawtp_process_event+0x6b>
     23b:      	leaq	0xf8(%rsp), %rsi
     243:      	movl	$0x1, %eax
     248:      	callq	*%rax
     24a:      	testq	%rax, %rax
     24d:      	je	0x96d <generic_rawtp_process_event+0x79d>
     253:      	movq	%rax, %r15
     256:      	leaq	0x5ef8(%rax), %rsi
     25d:      	movq	(%rip), %rdi            # 0x264 <generic_rawtp_process_event+0x94>
     264:      	movl	$0x1, %eax
     269:      	callq	*%rax
     26b:      	cmpl	$0x4, %r12d
     26f:      	jg	0x96d <generic_rawtp_process_event+0x79d>
     275:      	testq	%rax, %rax
     278:      	je	0x96d <generic_rawtp_process_event+0x79d>
     27e:      	movq	%r13, 0xb8(%rsp)
     286:      	movq	%r12, 0x100(%rsp)
     28e:      	movl	%r12d, %edx
     291:      	andl	$0x7, %edx
     294:      	movl	%edx, %ecx
     296:      	movl	0x4(%rax,%rcx,4), %r13d
     29b:      	movslq	0x18(%rax,%rcx,4), %r12
     2a0:      	movl	%r12d, %esi
     2a3:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     2af:      	testl	$0x100, %r12d           # imm = 0x100
     2b6:      	movq	%rdx, 0x20(%rsp)
     2bb:      	jne	0x2d9 <generic_rawtp_process_event+0x109>
     2bd:      	testb	%r12b, %r12b
     2c0:      	js	0x2e7 <generic_rawtp_process_event+0x117>
     2c2:      	testb	$0x40, %sil
     2c6:      	jne	0x2f4 <generic_rawtp_process_event+0x124>
     2c8:      	movl	0x40(%rax,%rdx,4), %ecx
     2cc:      	andl	$0x7, %ecx
     2cf:      	movq	0x5e50(%r15,%rcx,8), %rcx
     2d7:      	jmp	0x325 <generic_rawtp_process_event+0x155>
     2d9:      	movq	$0x0, 0x10(%rsp)
     2e2:      	jmp	0x6da <generic_rawtp_process_event+0x50a>
     2e7:      	movq	$0x0, 0x10(%rsp)
     2f0:      	xorl	%ecx, %ecx
     2f2:      	jmp	0x32a <generic_rawtp_process_event+0x15a>
     2f4:      	movq	%rax, 0x18(%rsp)
     2f9:      	movl	$0x23, %eax
     2fe:      	movq	%r14, %rbp
     301:      	movq	%r13, %r14
     304:      	movq	%r12, %r13
     307:      	movq	%rsi, %r12
     30a:      	callq	*%rax
     30c:      	movq	%r12, %rsi
     30f:      	movq	%r13, %r12
     312:      	movq	%r14, %r13
     315:      	movq	%rbp, %r14
     318:      	movq	0x20(%rsp), %rdx
     31d:      	movq	%rax, %rcx
     320:      	movq	0x18(%rsp), %rax
     325:      	movq	%rcx, 0x10(%rsp)
     32a:      	cmpl	$0x4, %edx
     32d:      	ja	0x6da <generic_rawtp_process_event+0x50a>
     333:      	leaq	(%rdx,%rdx,4), %rdx
     337:      	shll	$0x4, %edx
     33a:      	cmpw	$0x0, 0x76(%rax,%rdx)
     340:      	je	0x6da <generic_rawtp_process_event+0x50a>
     346:      	addq	%rax, %rdx
     349:      	addq	$0x70, %rdx
     34d:      	movl	(%rdx), %eax
     34f:      	addq	%rax, %rcx
     352:      	movq	%rcx, 0x10(%rsp)
     357:      	cmpw	$0x0, 0x4(%rdx)
     35c:      	movq	%r12, 0x30(%rsp)
     361:      	je	0x3a1 <generic_rawtp_process_event+0x1d1>
     363:      	leaq	0x10(%rsp), %rdi
     368:      	movq	%rdx, %r12
     36b:      	movl	$0x8, %edx
     370:      	movl	$0x4, %eax
     375:      	movq	0x10(%rsp), %rdx
     37a:      	movq	%rsi, %rbp
     37d:      	movl	$0x8, %esi
     382:      	callq	*%rax
     384:      	movq	%r12, %rdx
     387:      	movq	0x30(%rsp), %r12
     38c:      	movq	%rbp, %rsi
     38f:      	movq	0x20(%rsp), %rcx
     394:      	movl	$0x1, %ebp
     399:      	testl	%eax, %eax
     39b:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     3a1:      	cmpw	$0x0, 0xe(%rdx)
     3a6:      	je	0x6da <generic_rawtp_process_event+0x50a>
     3ac:      	movl	0x8(%rdx), %ecx
     3af:      	addq	0x10(%rsp), %rcx
     3b4:      	movq	%rcx, 0x10(%rsp)
     3b9:      	cmpw	$0x0, 0xc(%rdx)
     3be:      	je	0x3fe <generic_rawtp_process_event+0x22e>
     3c0:      	leaq	0x10(%rsp), %rdi
     3c5:      	movq	%rdx, %r12
     3c8:      	movl	$0x8, %edx
     3cd:      	movl	$0x4, %eax
     3d2:      	movq	0x10(%rsp), %rdx
     3d7:      	movq	%rsi, %rbp
     3da:      	movl	$0x8, %esi
     3df:      	callq	*%rax
     3e1:      	movq	%r12, %rdx
     3e4:      	movq	0x30(%rsp), %r12
     3e9:      	movq	%rbp, %rsi
     3ec:      	movq	0x20(%rsp), %rcx
     3f1:      	movl	$0x2, %ebp
     3f6:      	testl	%eax, %eax
     3f8:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     3fe:      	cmpw	$0x0, 0x16(%rdx)
     403:      	je	0x6da <generic_rawtp_process_event+0x50a>
     409:      	movl	0x10(%rdx), %ecx
     40c:      	addq	0x10(%rsp), %rcx
     411:      	movq	%rcx, 0x10(%rsp)
     416:      	cmpw	$0x0, 0x14(%rdx)
     41b:      	je	0x45b <generic_rawtp_process_event+0x28b>
     41d:      	leaq	0x10(%rsp), %rdi
     422:      	movq	%rdx, %r12
     425:      	movl	$0x8, %edx
     42a:      	movl	$0x4, %eax
     42f:      	movq	0x10(%rsp), %rdx
     434:      	movq	%rsi, %rbp
     437:      	movl	$0x8, %esi
     43c:      	callq	*%rax
     43e:      	movq	%r12, %rdx
     441:      	movq	0x30(%rsp), %r12
     446:      	movq	%rbp, %rsi
     449:      	movq	0x20(%rsp), %rcx
     44e:      	movl	$0x3, %ebp
     453:      	testl	%eax, %eax
     455:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     45b:      	cmpw	$0x0, 0x1e(%rdx)
     460:      	je	0x6da <generic_rawtp_process_event+0x50a>
     466:      	movl	0x18(%rdx), %ecx
     469:      	addq	0x10(%rsp), %rcx
     46e:      	movq	%rcx, 0x10(%rsp)
     473:      	cmpw	$0x0, 0x1c(%rdx)
     478:      	je	0x4b8 <generic_rawtp_process_event+0x2e8>
     47a:      	leaq	0x10(%rsp), %rdi
     47f:      	movq	%rdx, %r12
     482:      	movl	$0x8, %edx
     487:      	movl	$0x4, %eax
     48c:      	movq	0x10(%rsp), %rdx
     491:      	movq	%rsi, %rbp
     494:      	movl	$0x8, %esi
     499:      	callq	*%rax
     49b:      	movq	%r12, %rdx
     49e:      	movq	0x30(%rsp), %r12
     4a3:      	movq	%rbp, %rsi
     4a6:      	movq	0x20(%rsp), %rcx
     4ab:      	movl	$0x4, %ebp
     4b0:      	testl	%eax, %eax
     4b2:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     4b8:      	cmpw	$0x0, 0x26(%rdx)
     4bd:      	je	0x6da <generic_rawtp_process_event+0x50a>
     4c3:      	movl	0x20(%rdx), %ecx
     4c6:      	addq	0x10(%rsp), %rcx
     4cb:      	movq	%rcx, 0x10(%rsp)
     4d0:      	cmpw	$0x0, 0x24(%rdx)
     4d5:      	je	0x515 <generic_rawtp_process_event+0x345>
     4d7:      	leaq	0x10(%rsp), %rdi
     4dc:      	movq	%rdx, %r12
     4df:      	movl	$0x8, %edx
     4e4:      	movl	$0x4, %eax
     4e9:      	movq	0x10(%rsp), %rdx
     4ee:      	movq	%rsi, %rbp
     4f1:      	movl	$0x8, %esi
     4f6:      	callq	*%rax
     4f8:      	movq	%r12, %rdx
     4fb:      	movq	0x30(%rsp), %r12
     500:      	movq	%rbp, %rsi
     503:      	movq	0x20(%rsp), %rcx
     508:      	movl	$0x5, %ebp
     50d:      	testl	%eax, %eax
     50f:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     515:      	cmpw	$0x0, 0x2e(%rdx)
     51a:      	je	0x6da <generic_rawtp_process_event+0x50a>
     520:      	movl	0x28(%rdx), %ecx
     523:      	addq	0x10(%rsp), %rcx
     528:      	movq	%rcx, 0x10(%rsp)
     52d:      	cmpw	$0x0, 0x2c(%rdx)
     532:      	je	0x572 <generic_rawtp_process_event+0x3a2>
     534:      	leaq	0x10(%rsp), %rdi
     539:      	movq	%rdx, %r12
     53c:      	movl	$0x8, %edx
     541:      	movl	$0x4, %eax
     546:      	movq	0x10(%rsp), %rdx
     54b:      	movq	%rsi, %rbp
     54e:      	movl	$0x8, %esi
     553:      	callq	*%rax
     555:      	movq	%r12, %rdx
     558:      	movq	0x30(%rsp), %r12
     55d:      	movq	%rbp, %rsi
     560:      	movq	0x20(%rsp), %rcx
     565:      	movl	$0x6, %ebp
     56a:      	testl	%eax, %eax
     56c:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     572:      	cmpw	$0x0, 0x36(%rdx)
     577:      	je	0x6da <generic_rawtp_process_event+0x50a>
     57d:      	movl	0x30(%rdx), %ecx
     580:      	addq	0x10(%rsp), %rcx
     585:      	movq	%rcx, 0x10(%rsp)
     58a:      	cmpw	$0x0, 0x34(%rdx)
     58f:      	je	0x5cf <generic_rawtp_process_event+0x3ff>
     591:      	leaq	0x10(%rsp), %rdi
     596:      	movq	%rdx, %r12
     599:      	movl	$0x8, %edx
     59e:      	movl	$0x4, %eax
     5a3:      	movq	0x10(%rsp), %rdx
     5a8:      	movq	%rsi, %rbp
     5ab:      	movl	$0x8, %esi
     5b0:      	callq	*%rax
     5b2:      	movq	%r12, %rdx
     5b5:      	movq	0x30(%rsp), %r12
     5ba:      	movq	%rbp, %rsi
     5bd:      	movq	0x20(%rsp), %rcx
     5c2:      	movl	$0x7, %ebp
     5c7:      	testl	%eax, %eax
     5c9:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     5cf:      	cmpw	$0x0, 0x3e(%rdx)
     5d4:      	je	0x6da <generic_rawtp_process_event+0x50a>
     5da:      	movl	0x38(%rdx), %ecx
     5dd:      	addq	0x10(%rsp), %rcx
     5e2:      	movq	%rcx, 0x10(%rsp)
     5e7:      	cmpw	$0x0, 0x3c(%rdx)
     5ec:      	je	0x62f <generic_rawtp_process_event+0x45f>
     5ee:      	leaq	0x10(%rsp), %rdi
     5f3:      	movq	%rdx, 0x18(%rsp)
     5f8:      	movl	$0x8, %edx
     5fd:      	movl	$0x4, %eax
     602:      	movq	0x10(%rsp), %rdx
     607:      	movl	$0x8, %ebp
     60c:      	movq	%rsi, 0x58(%rsp)
     611:      	movl	$0x8, %esi
     616:      	callq	*%rax
     618:      	movq	0x18(%rsp), %rdx
     61d:      	movq	0x58(%rsp), %rsi
     622:      	movq	0x20(%rsp), %rcx
     627:      	testl	%eax, %eax
     629:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     62f:      	cmpw	$0x0, 0x46(%rdx)
     634:      	je	0x6da <generic_rawtp_process_event+0x50a>
     63a:      	movl	0x40(%rdx), %ecx
     63d:      	addq	0x10(%rsp), %rcx
     642:      	movq	%rcx, 0x10(%rsp)
     647:      	cmpw	$0x0, 0x44(%rdx)
     64c:      	je	0x688 <generic_rawtp_process_event+0x4b8>
     64e:      	leaq	0x10(%rsp), %rdi
     653:      	movq	%rdx, %r12
     656:      	movl	$0x8, %edx
     65b:      	movl	$0x4, %eax
     660:      	movq	0x10(%rsp), %rdx
     665:      	movq	%rsi, %rbp
     668:      	movl	$0x8, %esi
     66d:      	callq	*%rax
     66f:      	movq	%r12, %rdx
     672:      	movq	0x30(%rsp), %r12
     677:      	movq	%rbp, %rsi
     67a:      	movq	0x20(%rsp), %rcx
     67f:      	movl	$0x9, %ebp
     684:      	testl	%eax, %eax
     686:      	js	0x6d2 <generic_rawtp_process_event+0x502>
     688:      	cmpw	$0x0, 0x4e(%rdx)
     68d:      	je	0x6da <generic_rawtp_process_event+0x50a>
     68f:      	movl	0x48(%rdx), %ecx
     692:      	addq	0x10(%rsp), %rcx
     697:      	movq	%rcx, 0x10(%rsp)
     69c:      	cmpw	$0x0, 0x4c(%rdx)
     6a1:      	je	0x6da <generic_rawtp_process_event+0x50a>
     6a3:      	leaq	0x10(%rsp), %rdi
     6a8:      	movl	$0x8, %edx
     6ad:      	movl	$0x4, %eax
     6b2:      	movq	0x10(%rsp), %rdx
     6b7:      	movq	%rsi, %rbp
     6ba:      	movl	$0x8, %esi
     6bf:      	callq	*%rax
     6c1:      	movq	%rbp, %rsi
     6c4:      	movq	0x20(%rsp), %rcx
     6c9:      	movl	$0xa, %ebp
     6ce:      	testl	%eax, %eax
     6d0:      	jns	0x6da <generic_rawtp_process_event+0x50a>
     6d2:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     6da:      	movl	%r13d, %ebp
     6dd:      	cmpl	$0x2a, %r13d
     6e1:      	ja	0x8d7 <generic_rawtp_process_event+0x707>
     6e7:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     6f1:      	btq	%rbp, %rax
     6f5:      	jae	0x8d7 <generic_rawtp_process_event+0x707>
     6fb:      	movq	0x10(%rsp), %rbp
     700:      	movl	$0x0, 0x50(%rsp)
     708:      	movq	(%rip), %rdi            # 0x70f <generic_rawtp_process_event+0x53f>
     70f:      	leaq	0x50(%rsp), %rsi
     714:      	movl	$0x1, %eax
     719:      	callq	*%rax
     71b:      	testq	%rax, %rax
     71e:      	je	0x955 <generic_rawtp_process_event+0x785>
     724:      	movq	%rax, %r12
     727:      	cmpl	$0x0, 0x6420(%rax)
     72e:      	je	0x87f <generic_rawtp_process_event+0x6af>
     734:      	movl	$0x0, 0x6420(%r12)
     740:      	movq	(%rip), %rdi            # 0x747 <generic_rawtp_process_event+0x577>
     747:      	leaq	0x50(%rsp), %rsi
     74c:      	movl	$0x1, %eax
     751:      	callq	*%rax
     753:      	testq	%rax, %rax
     756:      	je	0x955 <generic_rawtp_process_event+0x785>
     75c:      	movq	%rax, %rdx
     75f:      	movq	0x20(%rsp), %rcx
     764:      	movl	0x5ea0(%r12,%rcx,4), %eax
     76c:      	movq	0xb8(%rsp), %r13
     774:      	movl	%eax, 0x90(%r12,%r13)
     77c:      	movq	%r13, %rbp
     77f:      	addq	$0x4, %rbp
     783:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     78b:      	movl	$0x4, %esi
     790:      	testl	%eax, %eax
     792:      	jne	0x95f <generic_rawtp_process_event+0x78f>
     798:      	movq	%r12, %r15
     79b:      	addq	$0x90, %r15
     7a2:      	movl	0x6424(%r12), %eax
     7aa:      	movq	%rbx, 0x8(%rsp)
     7af:      	movl	$0xfff, %ebx            # imm = 0xFFF
     7b4:      	subl	%eax, %ebx
     7b6:      	andl	$0xfff, %eax            # imm = 0xFFF
     7bb:      	addq	%rax, %rdx
     7be:      	movq	0x6440(%r12), %r13
     7c6:      	leaq	(%r15,%rbp), %rdi
     7ca:      	addq	$0x4, %rdi
     7ce:      	andl	$0xfff, %ebx            # imm = 0xFFF
     7d4:      	movl	$0x4, %eax
     7d9:      	addq	%rbp, %r15
     7dc:      	movl	%ebx, %esi
     7de:      	callq	*%rax
     7e0:      	movl	%ebx, 0x90(%r12,%rbp)
     7e8:      	addq	$0x8, %r13
     7ec:      	leaq	0x78(%rsp), %rdi
     7f1:      	movl	$0x8, %ecx
     7f6:      	movl	$0x4, %eax
     7fb:      	movl	$0x8, %esi
     800:      	movq	%r13, %rdx
     803:      	movq	0xb8(%rsp), %r13
     80b:      	callq	*%rax
     80d:      	movq	0x78(%rsp), %rcx
     812:      	addq	$0x30, %rcx
     816:      	leaq	0x68(%rsp), %rdi
     81b:      	movl	$0x8, %edx
     820:      	movl	$0x4, %eax
     825:      	movq	0x78(%rsp), %rdx
     82a:      	addq	$0x30, %rdx
     82e:      	movl	$0x8, %esi
     833:      	callq	*%rax
     835:      	movq	0x68(%rsp), %rcx
     83a:      	leaq	0xc0(%rsp), %rdi
     842:      	movl	$0x2, %edx
     847:      	movl	$0x4, %eax
     84c:      	movq	0x68(%rsp), %rdx
     851:      	movl	$0x2, %esi
     856:      	callq	*%rax
     858:      	movq	%rbx, %rsi
     85b:      	movq	0x8(%rsp), %rbx
     860:      	movl	$0x0, 0x4(%rsi,%r15)
     869:      	movzwl	0xc0(%rsp), %eax
     871:      	movw	%ax, 0x8(%rsi,%r15)
     877:      	addl	$0xe, %esi
     87a:      	jmp	0x95f <generic_rawtp_process_event+0x78f>
     87f:      	movq	%rbp, 0x78(%rsp)
     884:      	movq	$0x0, 0x68(%rsp)
     88d:      	cmpl	$0x17, %r13d
     891:      	jle	0x938 <generic_rawtp_process_event+0x768>
     897:      	cmpl	$0x18, %r13d
     89b:      	je	0xa9f <generic_rawtp_process_event+0x8cf>
     8a1:      	cmpl	$0x25, %r13d
     8a5:      	je	0xb01 <generic_rawtp_process_event+0x931>
     8ab:      	cmpl	$0x2a, %r13d
     8af:      	jne	0x955 <generic_rawtp_process_event+0x785>
     8b5:      	movq	%r12, %rax
     8b8:      	addq	$0x6430, %rax           # imm = 0x6430
     8be:      	movq	$0x0, 0x6430(%r12)
     8ca:      	movq	%rbp, 0x6438(%r12)
     8d2:      	jmp	0xb34 <generic_rawtp_process_event+0x964>
     8d7:      	movq	0x10(%rsp), %rax
     8dc:      	movq	%rax, 0x18(%rsp)
     8e1:      	cmpl	$0x15, %r13d
     8e5:      	jg	0xa20 <generic_rawtp_process_event+0x850>
     8eb:      	movl	$0x1fe, %r15d           # imm = 0x1FE
     8f1:      	cmpl	$0x9, %r13d
     8f5:      	jle	0xa6f <generic_rawtp_process_event+0x89f>
     8fb:      	cmpl	$0x10, %r13d
     8ff:      	jle	0xb99 <generic_rawtp_process_event+0x9c9>
     905:      	cmpl	$0x12, %r13d
     909:      	jle	0xc0a <generic_rawtp_process_event+0xa3a>
     90f:      	cmpl	$0x13, %r13d
     913:      	je	0xc27 <generic_rawtp_process_event+0xa57>
     919:      	cmpl	$0x14, %r13d
     91d:      	je	0xc4b <generic_rawtp_process_event+0xa7b>
     923:      	cmpl	$0x15, %r13d
     927:      	jne	0xc59 <generic_rawtp_process_event+0xa89>
     92d:      	movl	$0x20, %r15d
     933:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     938:      	cmpl	$0xf, %r13d
     93c:      	je	0xb3e <generic_rawtp_process_event+0x96e>
     942:      	cmpl	$0x10, %r13d
     946:      	jne	0x955 <generic_rawtp_process_event+0x785>
     948:      	leaq	0xc0(%rsp), %r15
     950:      	jmp	0xacd <generic_rawtp_process_event+0x8fd>
     955:      	xorl	%esi, %esi
     957:      	movq	0xb8(%rsp), %r13
     95f:      	addl	%r13d, %esi
     962:      	movl	%esi, %r13d
     965:      	movq	0x100(%rsp), %r12
     96d:      	movl	%r13d, 0x4(%r14)
     971:      	cmpl	$0x3, %r12d
     975:      	jg	0x9e6 <generic_rawtp_process_event+0x816>
     977:      	movl	$0x0, 0x78(%rsp)
     97f:      	movq	(%rip), %rdi            # 0x986 <generic_rawtp_process_event+0x7b6>
     986:      	leaq	0x78(%rsp), %rsi
     98b:      	movl	$0x1, %eax
     990:      	callq	*%rax
     992:      	testq	%rax, %rax
     995:      	je	0x9e6 <generic_rawtp_process_event+0x816>
     997:      	movq	%rax, %rsi
     99a:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     9a1:      	movq	(%rip), %rdi            # 0x9a8 <generic_rawtp_process_event+0x7d8>
     9a8:      	movl	$0x1, %eax
     9ad:      	callq	*%rax
     9af:      	testq	%rax, %rax
     9b2:      	je	0x9e6 <generic_rawtp_process_event+0x816>
     9b4:      	incl	%r12d
     9b7:      	movl	%r12d, %ecx
     9ba:      	andl	$0x7, %ecx
     9bd:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     9c2:      	je	0x9e6 <generic_rawtp_process_event+0x816>
     9c4:      	movl	%r12d, 0x5efc(%r14)
     9cb:      	movq	(%rip), %rsi            # 0x9d2 <generic_rawtp_process_event+0x802>
     9d2:      	movl	$0x1, %ecx
     9d7:      	movl	$0xc, %eax
     9dc:      	movq	%rbx, %rdi
     9df:      	movl	$0x1, %edx
     9e4:      	callq	*%rax
     9e6:      	movl	$0x0, 0x5efc(%r14)
     9f1:      	movq	(%rip), %rsi            # 0x9f8 <generic_rawtp_process_event+0x828>
     9f8:      	movl	$0x3, %ecx
     9fd:      	movl	$0xc, %eax
     a02:      	movq	%rbx, %rdi
     a05:      	movl	$0x3, %edx
     a0a:      	callq	*%rax
     a0c:      	xorl	%eax, %eax
     a0e:      	addq	$0x108, %rsp            # imm = 0x108
     a15:      	popq	%rbx
     a16:      	popq	%r12
     a18:      	popq	%r13
     a1a:      	popq	%r14
     a1c:      	popq	%r15
     a1e:      	popq	%rbp
     a1f:      	retq
     a20:      	cmpl	$0x20, %r13d
     a24:      	jg	0xa53 <generic_rawtp_process_event+0x883>
     a26:      	cmpl	$0x1a, %r13d
     a2a:      	jg	0xbbb <generic_rawtp_process_event+0x9eb>
     a30:      	cmpl	$0x16, %r13d
     a34:      	je	0xc02 <generic_rawtp_process_event+0xa32>
     a3a:      	cmpl	$0x17, %r13d
     a3e:      	je	0xbb0 <generic_rawtp_process_event+0x9e0>
     a44:      	cmpl	$0x1a, %r13d
     a48:      	je	0xc3b <generic_rawtp_process_event+0xa6b>
     a4e:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     a53:      	cmpl	$0x26, %r13d
     a57:      	jg	0xbd3 <generic_rawtp_process_event+0xa03>
     a5d:      	leal	-0x21(%r13), %eax
     a61:      	cmpl	$0x4, %eax
     a64:      	jb	0xbb0 <generic_rawtp_process_event+0x9e0>
     a6a:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     a6f:      	cmpl	$0x4, %r13d
     a73:      	jg	0xbe7 <generic_rawtp_process_event+0xa17>
     a79:      	leal	-0x2(%r13), %eax
     a7d:      	cmpl	$0x2, %eax
     a80:      	jb	0xbc8 <generic_rawtp_process_event+0x9f8>
     a86:      	cmpl	$0x1, %r13d
     a8a:      	je	0xbc8 <generic_rawtp_process_event+0x9f8>
     a90:      	cmpl	$0x4, %r13d
     a94:      	je	0xbb0 <generic_rawtp_process_event+0x9e0>
     a9a:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     a9f:      	leaq	0xc0(%rsp), %r15
     aa7:      	movl	$0x8, %ecx
     aac:      	movl	$0x4, %eax
     ab1:      	movq	0x78(%rsp), %rdx
     ab6:      	movq	%r15, %rdi
     ab9:      	movl	$0x8, %esi
     abe:      	callq	*%rax
     ac0:      	movq	0xc0(%rsp), %rax
     ac8:      	movq	%rax, 0x78(%rsp)
     acd:      	movq	0xb8(%rsp), %r13
     ad5:      	leaq	0x78(%rsp), %rdx
     ada:      	movl	$0x8, %ecx
     adf:      	movl	$0x4, %eax
     ae4:      	leaq	0xc0(%rsp), %rdi
     aec:      	movl	$0x8, %esi
     af1:      	callq	*%rax
     af3:      	movq	0xc0(%rsp), %rax
     afb:      	addq	$0x40, %rax
     aff:      	jmp	0xb6f <generic_rawtp_process_event+0x99f>
     b01:      	addq	$0x40, %rbp
     b05:      	movq	%rbp, 0x78(%rsp)
     b0a:      	leaq	0xc0(%rsp), %rdi
     b12:      	movl	$0x8, %ecx
     b17:      	movl	$0x4, %eax
     b1c:      	movq	0x78(%rsp), %rdx
     b21:      	movl	$0x8, %esi
     b26:      	callq	*%rax
     b28:      	movq	0xc0(%rsp), %rax
     b30:      	addq	$0x40, %rax
     b34:      	movq	0xb8(%rsp), %r13
     b3c:      	jmp	0xb6f <generic_rawtp_process_event+0x99f>
     b3e:      	leaq	0x68(%rsp), %rdi
     b43:      	leaq	0x78(%rsp), %rdx
     b48:      	movl	$0x8, %ecx
     b4d:      	movl	$0x4, %eax
     b52:      	movl	$0x8, %esi
     b57:      	callq	*%rax
     b59:      	movq	0x68(%rsp), %rax
     b5e:      	testq	%rax, %rax
     b61:      	movq	0xb8(%rsp), %r13
     b69:      	je	0xbfb <generic_rawtp_process_event+0xa2b>
     b6f:      	movq	%rax, 0x6440(%r12)
     b77:      	movq	(%rip), %rsi            # 0xb7e <generic_rawtp_process_event+0x9ae>
     b7e:      	movl	$0x6, %ecx
     b83:      	movl	$0xc, %eax
     b88:      	movq	%rbx, %rdi
     b8b:      	movl	$0x6, %edx
     b90:      	callq	*%rax
     b92:      	xorl	%esi, %esi
     b94:      	jmp	0x95f <generic_rawtp_process_event+0x78f>
     b99:      	leal	-0xa(%r13), %eax
     b9d:      	cmpl	$0x2, %eax
     ba0:      	jb	0xbb0 <generic_rawtp_process_event+0x9e0>
     ba2:      	leal	-0xc(%r13), %eax
     ba6:      	cmpl	$0x2, %eax
     ba9:      	jb	0xbc8 <generic_rawtp_process_event+0x9f8>
     bab:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     bb0:      	movl	$0x8, %r15d
     bb6:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     bbb:      	leal	-0x1d(%r13), %eax
     bbf:      	cmpl	$0x4, %eax
     bc2:      	jae	0xc53 <generic_rawtp_process_event+0xa83>
     bc8:      	movl	$0x4, %r15d
     bce:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     bd3:      	cmpl	$0x28, %r13d
     bd7:      	jg	0xc1b <generic_rawtp_process_event+0xa4b>
     bd9:      	cmpl	$0x27, %r13d
     bdd:      	je	0xc02 <generic_rawtp_process_event+0xa32>
     bdf:      	cmpl	$0x28, %r13d
     be3:      	je	0xc27 <generic_rawtp_process_event+0xa57>
     be5:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     be7:      	cmpl	$0x6, %r13d
     beb:      	jg	0xc2f <generic_rawtp_process_event+0xa5f>
     bed:      	cmpl	$0x5, %r13d
     bf1:      	je	0xc43 <generic_rawtp_process_event+0xa73>
     bf3:      	cmpl	$0x6, %r13d
     bf7:      	je	0xc5c <generic_rawtp_process_event+0xa8c>
     bf9:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     bfb:      	xorl	%esi, %esi
     bfd:      	jmp	0x95f <generic_rawtp_process_event+0x78f>
     c02:      	movl	$0x10, %r15d
     c08:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     c0a:      	cmpl	$0x11, %r13d
     c0e:      	je	0xc5c <generic_rawtp_process_event+0xa8c>
     c10:      	movq	%r12, %r15
     c13:      	cmpl	$0x12, %r13d
     c17:      	je	0xc5c <generic_rawtp_process_event+0xa8c>
     c19:      	jmp	0xc59 <generic_rawtp_process_event+0xa89>
     c1b:      	cmpl	$0x29, %r13d
     c1f:      	je	0xc43 <generic_rawtp_process_event+0xa73>
     c21:      	cmpl	$0x2b, %r13d
     c25:      	jne	0xc59 <generic_rawtp_process_event+0xa89>
     c27:      	movl	$0x18, %r15d
     c2d:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     c2f:      	cmpl	$0x7, %r13d
     c33:      	je	0xc43 <generic_rawtp_process_event+0xa73>
     c35:      	cmpl	$0x8, %r13d
     c39:      	jne	0xc59 <generic_rawtp_process_event+0xa89>
     c3b:      	movl	$0x50, %r15d
     c41:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     c43:      	movl	$0x40, %r15d
     c49:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     c4b:      	movl	$0x98, %r15d
     c51:      	jmp	0xc5c <generic_rawtp_process_event+0xa8c>
     c53:      	cmpl	$0x1b, %r13d
     c57:      	je	0xc3b <generic_rawtp_process_event+0xa6b>
     c59:      	xorl	%r15d, %r15d
     c5c:      	movq	%rsi, 0x58(%rsp)
     c61:      	movl	$0x0, 0xfc(%rsp)
     c6c:      	movq	(%rip), %rdi            # 0xc73 <generic_rawtp_process_event+0xaa3>
     c73:      	leaq	0xfc(%rsp), %rsi
     c7b:      	movl	$0x1, %eax
     c80:      	callq	*%rax
     c82:      	xorl	%esi, %esi
     c84:      	testq	%rax, %rax
     c87:      	je	0x957 <generic_rawtp_process_event+0x787>
     c8d:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     c92:      	subq	%r15, %rcx
     c95:      	cmpq	0xb8(%rsp), %rcx
     c9d:      	jbe	0x957 <generic_rawtp_process_event+0x787>
     ca3:      	movq	0x20(%rsp), %rsi
     ca8:      	movl	0x5ea0(%rax,%rsi,4), %ecx
     caf:      	movq	0xb8(%rsp), %rdx
     cb7:      	movl	%ecx, 0x90(%rax,%rdx)
     cbe:      	leaq	0x4(%rdx), %rdi
     cc2:      	movq	%rdi, 0x5e78(%rax,%rsi,8)
     cca:      	movl	$0x4, %esi
     ccf:      	testl	%ecx, %ecx
     cd1:      	jne	0x957 <generic_rawtp_process_event+0x787>
     cd7:      	movq	%rax, %r15
     cda:      	addq	$0x90, %r15
     ce1:      	addq	%rdi, %r15
     ce4:      	movq	0x18(%rsp), %rdx
     ce9:      	movq	%rdx, 0x78(%rsp)
     cee:      	movq	$0x0, 0x68(%rsp)
     cf7:      	cmpl	$0x17, %r13d
     cfb:      	movq	%rax, 0x40(%rsp)
     d00:      	jle	0xd3d <generic_rawtp_process_event+0xb6d>
     d02:      	cmpl	$0x18, %r13d
     d06:      	je	0xd58 <generic_rawtp_process_event+0xb88>
     d08:      	cmpl	$0x25, %r13d
     d0c:      	je	0xd96 <generic_rawtp_process_event+0xbc6>
     d12:      	cmpl	$0x2a, %r13d
     d16:      	jne	0x13ba <generic_rawtp_process_event+0x11ea>
     d1c:      	movq	$0x0, 0xc0(%rsp)
     d28:      	movq	%rdx, 0xc8(%rsp)
     d30:      	leaq	0xc0(%rsp), %rax
     d38:      	jmp	0xdc3 <generic_rawtp_process_event+0xbf3>
     d3d:      	cmpl	$0xf, %r13d
     d41:      	je	0x12ec <generic_rawtp_process_event+0x111c>
     d47:      	cmpl	$0x10, %r13d
     d4b:      	jne	0x13ba <generic_rawtp_process_event+0x11ea>
     d51:      	leaq	0x50(%rsp), %r12
     d56:      	jmp	0xd80 <generic_rawtp_process_event+0xbb0>
     d58:      	leaq	0x50(%rsp), %r12
     d5d:      	movl	$0x8, %ecx
     d62:      	movl	$0x4, %eax
     d67:      	movq	0x78(%rsp), %rdx
     d6c:      	movq	%r12, %rdi
     d6f:      	movl	$0x8, %esi
     d74:      	callq	*%rax
     d76:      	movq	0x50(%rsp), %rax
     d7b:      	movq	%rax, 0x78(%rsp)
     d80:      	leaq	0x78(%rsp), %rdx
     d85:      	movl	$0x8, %ecx
     d8a:      	movl	$0x4, %eax
     d8f:      	leaq	0x50(%rsp), %rdi
     d94:      	jmp	0xdb3 <generic_rawtp_process_event+0xbe3>
     d96:      	addq	$0x40, %rdx
     d9a:      	movq	%rdx, 0x78(%rsp)
     d9f:      	leaq	0x50(%rsp), %rdi
     da4:      	movl	$0x8, %ecx
     da9:      	movl	$0x4, %eax
     dae:      	movq	0x78(%rsp), %rdx
     db3:      	movl	$0x8, %esi
     db8:      	callq	*%rax
     dba:      	movq	0x50(%rsp), %rax
     dbf:      	addq	$0x40, %rax
     dc3:      	movq	%rax, 0x48(%rsp)
     dc8:      	movl	$0x0, 0xe4(%rsp)
     dd3:      	movq	(%rip), %rdi            # 0xdda <generic_rawtp_process_event+0xc0a>
     dda:      	leaq	0xe4(%rsp), %rsi
     de2:      	movl	$0x1, %eax
     de7:      	callq	*%rax
     de9:      	testq	%rax, %rax
     dec:      	je	0x1201 <generic_rawtp_process_event+0x1031>
     df2:      	movq	%rax, %r12
     df5:      	movq	%r15, 0x38(%rsp)
     dfa:      	addq	$0x1000, %rax           # imm = 0x1000
     e00:      	movq	%rax, 0x18(%rsp)
     e05:      	movl	$0x23, %eax
     e0a:      	callq	*%rax
     e0c:      	leaq	0xd50(%rax), %rdx
     e13:      	leaq	0xd8(%rsp), %rdi
     e1b:      	movl	$0x8, %ecx
     e20:      	movl	$0x4, %eax
     e25:      	movl	$0x8, %esi
     e2a:      	callq	*%rax
     e2c:      	movq	0xd8(%rsp), %rbp
     e34:      	movq	0x48(%rsp), %rax
     e39:      	leaq	0x8(%rax), %rdx
     e3d:      	leaq	0xe8(%rsp), %rdi
     e45:      	movl	$0x8, %ecx
     e4a:      	movl	$0x4, %eax
     e4f:      	leaq	0x18(%rbp), %rcx
     e53:      	movq	%rcx, 0x30(%rsp)
     e58:      	movl	$0x8, %esi
     e5d:      	movq	%rdx, 0x58(%rsp)
     e62:      	callq	*%rax
     e64:      	movq	0xe8(%rsp), %r13
     e6c:      	leaq	0x10(%r13), %rdx
     e70:      	leaq	0x78(%rsp), %rdi
     e75:      	movl	$0x8, %ecx
     e7a:      	movl	$0x4, %eax
     e7f:      	movl	$0x8, %esi
     e84:      	callq	*%rax
     e86:      	cmpq	$0x0, 0x78(%rsp)
     e8c:      	movl	$0x1000, %r15d          # imm = 0x1000
     e92:      	je	0xe9b <generic_rawtp_process_event+0xccb>
     e94:      	movq	0x18(%rsp), %rcx
     e99:      	jmp	0xeee <generic_rawtp_process_event+0xd1e>
     e9b:      	leaq	0x18(%r13), %rdx
     e9f:      	leaq	0x78(%rsp), %rdi
     ea4:      	movl	$0x8, %ecx
     ea9:      	movl	$0x4, %eax
     eae:      	movl	$0x8, %esi
     eb3:      	callq	*%rax
     eb5:      	cmpq	%r13, 0x78(%rsp)
     eba:      	movq	0x18(%rsp), %rcx
     ebf:      	je	0xeee <generic_rawtp_process_event+0xd1e>
     ec1:      	movq	%r12, %rcx
     ec4:      	addq	$0xff6, %rcx            # imm = 0xFF6
     ecb:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     ed5:      	movq	%rax, 0xff6(%r12)
     edd:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     ee8:      	movl	$0xff6, %r15d           # imm = 0xFF6
     eee:      	movq	$0x0, 0x80(%rsp)
     efa:      	movq	$0x0, 0x78(%rsp)
     f03:      	movq	%r12, 0x88(%rsp)
     f0b:      	movq	$0x0, 0x90(%rsp)
     f17:      	movq	$0x0, 0x98(%rsp)
     f23:      	movq	$0x0, 0xa0(%rsp)
     f2f:      	movq	%rcx, 0x18(%rsp)
     f34:      	movq	%rcx, 0xa8(%rsp)
     f3c:      	movl	%r15d, 0xb0(%rsp)
     f44:      	movb	$0x0, 0xb4(%rsp)
     f4c:      	addq	$0x20, %rbp
     f50:      	leaq	0x78(%rsp), %rdi
     f55:      	movl	$0x8, %ecx
     f5a:      	movl	$0x4, %eax
     f5f:      	leaq	0x80(%rsp), %r12
     f67:      	leaq	0x90(%rsp), %r15
     f6f:      	leaq	0x98(%rsp), %r13
     f77:      	movl	$0x8, %esi
     f7c:      	movq	%rbp, %rdx
     f7f:      	callq	*%rax
     f81:      	movl	$0x8, %ecx
     f86:      	movl	$0x4, %eax
     f8b:      	movq	0x30(%rsp), %rdx
     f90:      	movq	%r12, %rdi
     f93:      	movl	$0x8, %esi
     f98:      	callq	*%rax
     f9a:      	movl	$0x8, %ecx
     f9f:      	movl	$0x4, %eax
     fa4:      	movq	0x58(%rsp), %rdx
     fa9:      	movq	%r15, %rdi
     fac:      	movl	$0x8, %esi
     fb1:      	callq	*%rax
     fb3:      	movl	$0x8, %ecx
     fb8:      	movl	$0x4, %eax
     fbd:      	movq	0x48(%rsp), %rdx
     fc2:      	movq	%r13, %rdi
     fc5:      	movl	$0x8, %esi
     fca:      	callq	*%rax
     fcc:      	movq	0x98(%rsp), %rax
     fd4:      	addq	$-0x20, %rax
     fd8:      	movq	%rax, 0xa0(%rsp)
     fe0:      	movl	$0x80, %eax
     fe5:      	movl	$0x8, %r15d
     feb:      	movq	0x90(%rsp), %r13
     ff3:      	movq	0x98(%rsp), %rdx
     ffb:      	movq	0xa0(%rsp), %r12
    1003:      	cmpq	0x78(%rsp), %r13
    1008:      	jne	0x1018 <generic_rawtp_process_event+0xe48>
    100a:      	cmpq	0x80(%rsp), %rdx
    1012:      	je	0x11b0 <generic_rawtp_process_event+0xfe0>
    1018:      	movl	%eax, 0x30(%rsp)
    101c:      	movl	$0x4, %eax
    1021:      	leaq	0xd0(%rsp), %rdi
    1029:      	movl	$0x8, %esi
    102e:      	callq	*%rax
    1030:      	cmpq	0xd0(%rsp), %r13
    1038:      	je	0x1144 <generic_rawtp_process_event+0xf74>
    103e:      	leaq	0x18(%r13), %rbp
    1042:      	movl	$0x4, %eax
    1047:      	leaq	0x50(%rsp), %rdi
    104c:      	movl	$0x8, %esi
    1051:      	movq	%rbp, %rdx
    1054:      	callq	*%rax
    1056:      	cmpq	%r13, 0x50(%rsp)
    105b:      	je	0x1144 <generic_rawtp_process_event+0xf74>
    1061:      	movl	$0x4, %eax
    1066:      	leaq	0x60(%rsp), %rdi
    106b:      	movl	$0x8, %esi
    1070:      	movq	%rbp, %rdx
    1073:      	callq	*%rax
    1075:      	addq	$0x20, %r13
    1079:      	movl	$0x4, %eax
    107e:      	leaq	0x68(%rsp), %rdi
    1083:      	movl	$0x10, %ecx
    1088:      	movl	$0x10, %esi
    108d:      	movq	%r13, %rdx
    1090:      	callq	*%rax
    1092:      	movq	0x88(%rsp), %r12
    109a:      	movq	0xa8(%rsp), %rax
    10a2:      	movl	0x6c(%rsp), %ebp
    10a6:      	subq	%r12, %rax
    10a9:      	movl	0xb0(%rsp), %r13d
    10b1:      	movl	%ebp, %edx
    10b3:      	subl	%r13d, %edx
    10b6:      	movl	$0x0, %ecx
    10bb:      	cmovbl	%ecx, %edx
    10be:      	addq	0x70(%rsp), %rdx
    10c3:      	xorl	%esi, %esi
    10c5:      	cmpl	%ebp, %r13d
    10c8:      	seta	%sil
    10cc:      	movl	%ebp, %ecx
    10ce:      	cmovbl	%r13d, %ecx
    10d2:      	addl	%ecx, %esi
    10d4:      	movl	%r13d, %edi
    10d7:      	subl	%esi, %edi
    10d9:      	movl	%edi, 0xb0(%rsp)
    10e0:      	subq	%rsi, %rax
    10e3:      	jb	0x11b8 <generic_rawtp_process_event+0xfe8>
    10e9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    10ef:      	ja	0x11b8 <generic_rawtp_process_event+0xfe8>
    10f5:      	cmpl	%ebp, %r13d
    10f8:      	jbe	0x10ff <generic_rawtp_process_event+0xf2f>
    10fa:      	movb	$0x2f, (%r12,%rax)
    10ff:      	xorl	%edi, %edi
    1101:      	cmpl	%ebp, %r13d
    1104:      	seta	%dil
    1108:      	movzbl	%cl, %esi
    110b:      	addq	%rax, %r12
    110e:      	addq	%r12, %rdi
    1111:      	movl	$0x4, %eax
    1116:      	callq	*%rax
    1118:      	movq	%r12, 0xa8(%rsp)
    1120:      	cmpl	%ebp, %r13d
    1123:      	jbe	0x11b8 <generic_rawtp_process_event+0xfe8>
    1129:      	movq	0x60(%rsp), %rax
    112e:      	movq	%rax, 0x90(%rsp)
    1136:      	movl	0x30(%rsp), %eax
    113a:      	decl	%eax
    113c:      	jne	0xfeb <generic_rawtp_process_event+0xe1b>
    1142:      	jmp	0x11b8 <generic_rawtp_process_event+0xfe8>
    1144:      	leaq	0x10(%r12), %rdx
    1149:      	movl	$0x4, %eax
    114e:      	leaq	0x50(%rsp), %rdi
    1153:      	movl	$0x8, %esi
    1158:      	callq	*%rax
    115a:      	movq	0xa0(%rsp), %rax
    1162:      	cmpq	0x50(%rsp), %rax
    1167:      	movl	$0x8, %ecx
    116c:      	je	0x11b0 <generic_rawtp_process_event+0xfe0>
    116e:      	addq	$0x18, %r12
    1172:      	movl	$0x4, %eax
    1177:      	leaq	0x90(%rsp), %rdi
    117f:      	movl	$0x8, %esi
    1184:      	movq	%r12, %rdx
    1187:      	callq	*%rax
    1189:      	movq	0x50(%rsp), %rax
    118e:      	movq	%rax, 0xa0(%rsp)
    1196:      	addq	$0x20, %rax
    119a:      	movq	%rax, 0x98(%rsp)
    11a2:      	movl	0x30(%rsp), %eax
    11a6:      	decl	%eax
    11a8:      	jne	0xfeb <generic_rawtp_process_event+0xe1b>
    11ae:      	jmp	0x11b8 <generic_rawtp_process_event+0xfe8>
    11b0:      	movb	$0x1, 0xb4(%rsp)
    11b8:      	movq	0xa8(%rsp), %rax
    11c0:      	movq	0x18(%rsp), %rdx
    11c5:      	cmpq	%rdx, %rax
    11c8:      	je	0x1209 <generic_rawtp_process_event+0x1039>
    11ca:      	xorl	%ebp, %ebp
    11cc:      	cmpb	$0x0, 0xb4(%rsp)
    11d4:      	sete	%cl
    11d7:      	movl	0xb0(%rsp), %edx
    11de:      	movl	$0x1000, %r12d          # imm = 0x1000
    11e4:      	subl	%edx, %r12d
    11e7:      	testl	%edx, %edx
    11e9:      	cmovlel	%edx, %r12d
    11ed:      	testq	%rax, %rax
    11f0:      	movq	0x38(%rsp), %r15
    11f5:      	je	0x1201 <generic_rawtp_process_event+0x1031>
    11f7:      	movb	%cl, %bpl
    11fa:      	addl	%ebp, %ebp
    11fc:      	movq	%rax, %rdx
    11ff:      	jmp	0x1213 <generic_rawtp_process_event+0x1043>
    1201:      	xorl	%r12d, %r12d
    1204:      	jmp	0x12b6 <generic_rawtp_process_event+0x10e6>
    1209:      	xorl	%r12d, %r12d
    120c:      	xorl	%ebp, %ebp
    120e:      	movq	0x38(%rsp), %r15
    1213:      	leaq	0x4(%r15), %rdi
    1217:      	andl	$0xfff, %r12d           # imm = 0xFFF
    121e:      	movl	$0x4, %eax
    1223:      	movl	%r12d, %esi
    1226:      	callq	*%rax
    1228:      	movl	%r12d, (%r15)
    122b:      	leaq	0x78(%rsp), %rdi
    1230:      	movl	$0x8, %ecx
    1235:      	movl	$0x4, %eax
    123a:      	movq	0x58(%rsp), %rdx
    123f:      	movl	$0x8, %esi
    1244:      	callq	*%rax
    1246:      	movq	0x78(%rsp), %rcx
    124b:      	addq	$0x30, %rcx
    124f:      	leaq	0x68(%rsp), %rdi
    1254:      	movl	$0x8, %edx
    1259:      	movl	$0x4, %eax
    125e:      	movq	0x78(%rsp), %rdx
    1263:      	addq	$0x30, %rdx
    1267:      	movl	$0x8, %esi
    126c:      	callq	*%rax
    126e:      	movq	0x68(%rsp), %rcx
    1273:      	leaq	0x50(%rsp), %rdi
    1278:      	movl	$0x2, %edx
    127d:      	movl	$0x4, %eax
    1282:      	movq	0x68(%rsp), %rdx
    1287:      	movl	$0x2, %esi
    128c:      	callq	*%rax
    128e:      	movl	%ebp, 0x4(%r15,%r12)
    1293:      	movzwl	0x50(%rsp), %eax
    1298:      	movw	%ax, 0x8(%r15,%r12)
    129e:      	addl	$0xa, %r12d
    12a2:      	movq	0x40(%rsp), %rax
    12a7:      	movq	0x20(%rsp), %rcx
    12ac:      	movl	$0x4, %esi
    12b1:      	testl	%r12d, %r12d
    12b4:      	js	0x12c9 <generic_rawtp_process_event+0x10f9>
    12b6:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    12bd:      	addq	$0x4, %r12
    12c1:      	movq	%r12, %rsi
    12c4:      	jmp	0x957 <generic_rawtp_process_event+0x787>
    12c9:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    12d4:      	movq	0xb8(%rsp), %rcx
    12dc:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    12e7:      	jmp	0x957 <generic_rawtp_process_event+0x787>
    12ec:      	movq	%rdi, 0x38(%rsp)
    12f1:      	leaq	0x68(%rsp), %rdi
    12f6:      	leaq	0x78(%rsp), %rdx
    12fb:      	movl	$0x8, %ecx
    1300:      	movl	$0x4, %eax
    1305:      	movl	$0x8, %esi
    130a:      	callq	*%rax
    130c:      	movq	0x68(%rsp), %rax
    1311:      	movq	%rax, 0x48(%rsp)
    1316:      	testq	%rax, %rax
    1319:      	jne	0xdc8 <generic_rawtp_process_event+0xbf8>
    131f:      	movl	$0x0, 0xe8(%rsp)
    132a:      	movq	(%rip), %rdi            # 0x1331 <generic_rawtp_process_event+0x1161>
    1331:      	leaq	0xe8(%rsp), %rsi
    1339:      	movl	$0x1, %eax
    133e:      	callq	*%rax
    1340:      	xorl	%ebp, %ebp
    1342:      	testq	%rax, %rax
    1345:      	je	0x385a <generic_rawtp_process_event+0x368a>
    134b:      	cmpl	$0x19, %r13d
    134f:      	movq	%rbx, 0x8(%rsp)
    1354:      	movq	%r14, 0x28(%rsp)
    1359:      	movq	%rax, 0x48(%rsp)
    135e:      	jg	0x16d0 <generic_rawtp_process_event+0x1500>
    1364:      	movq	%r13, %rax
    1367:      	cmpl	$0x12, %r13d
    136b:      	jle	0x1711 <generic_rawtp_process_event+0x1541>
    1371:      	cmpl	$0x14, %r13d
    1375:      	jle	0x1ba0 <generic_rawtp_process_event+0x19d0>
    137b:      	cmpl	$0x15, %eax
    137e:      	je	0x240d <generic_rawtp_process_event+0x223d>
    1384:      	cmpl	$0x16, %eax
    1387:      	je	0x2386 <generic_rawtp_process_event+0x21b6>
    138d:      	cmpl	$0x17, %eax
    1390:      	movq	0x8(%rsp), %rbx
    1395:      	movq	0x28(%rsp), %r14
    139a:      	jne	0x385a <generic_rawtp_process_event+0x368a>
    13a0:      	movl	$0x0, 0x4(%r15)
    13a8:      	movq	0x18(%rsp), %rax
    13ad:      	movl	%eax, (%r15)
    13b0:      	movl	$0x8, %ebp
    13b5:      	jmp	0x385a <generic_rawtp_process_event+0x368a>
    13ba:      	movq	%rdi, 0x38(%rsp)
    13bf:      	cmpl	$0x28, %r13d
    13c3:      	ja	0x131f <generic_rawtp_process_event+0x114f>
    13c9:      	movabsq	$0x1c1f2027cf2, %rax    # imm = 0x1C1F2027CF2
    13d3:      	btq	%rbp, %rax
    13d7:      	jae	0x131f <generic_rawtp_process_event+0x114f>
    13dd:      	movq	%rdx, 0x60(%rsp)
    13e2:      	movl	$0x0, 0xe8(%rsp)
    13ed:      	movq	(%rip), %rdi            # 0x13f4 <generic_rawtp_process_event+0x1224>
    13f4:      	leaq	0xe8(%rsp), %rsi
    13fc:      	movl	$0x1, %eax
    1401:      	callq	*%rax
    1403:      	testq	%rax, %rax
    1406:      	je	0x1599 <generic_rawtp_process_event+0x13c9>
    140c:      	movq	%r15, %rbp
    140f:      	cmpl	$0x10, %r13d
    1413:      	jg	0x15a1 <generic_rawtp_process_event+0x13d1>
    1419:      	cmpl	$0x9, %r13d
    141d:      	jg	0x15d5 <generic_rawtp_process_event+0x1405>
    1423:      	movq	%r14, 0x28(%rsp)
    1428:      	movq	%rbx, 0x8(%rsp)
    142d:      	cmpl	$0x4, %r13d
    1431:      	jle	0x177f <generic_rawtp_process_event+0x15af>
    1437:      	cmpl	$0x5, %r13d
    143b:      	je	0x1e85 <generic_rawtp_process_event+0x1cb5>
    1441:      	movq	%rax, %r15
    1444:      	movq	%r13, %rax
    1447:      	cmpl	$0x6, %eax
    144a:      	je	0x1656 <generic_rawtp_process_event+0x1486>
    1450:      	cmpl	$0x7, %eax
    1453:      	movq	0x40(%rsp), %rax
    1458:      	movq	0x20(%rsp), %rcx
    145d:      	movl	$0x4, %esi
    1462:      	movq	0x8(%rsp), %rbx
    1467:      	movl	$0x0, %r12d
    146d:      	movq	0x28(%rsp), %r14
    1472:      	jne	0x12b1 <generic_rawtp_process_event+0x10e1>
    1478:      	movq	0x60(%rsp), %r12
    147d:      	movq	%rbp, %rbx
    1480:      	movq	%r12, 0x28(%rbp)
    1484:      	leaq	0x26(%rbp), %rdi
    1488:      	leaq	0x10(%r12), %rdx
    148d:      	movl	$0x2, %ecx
    1492:      	movl	$0x4, %eax
    1497:      	movl	$0x2, %esi
    149c:      	callq	*%rax
    149e:      	leaq	0x3a(%rbp), %rdi
    14a2:      	leaq	0x12(%r12), %rdx
    14a7:      	movl	$0x1, %ecx
    14ac:      	movl	$0x4, %eax
    14b1:      	movl	$0x1, %esi
    14b6:      	callq	*%rax
    14b8:      	leaq	0x38(%rbp), %rdi
    14bc:      	leaq	0x226(%r12), %rdx
    14c4:      	movl	$0x2, %ecx
    14c9:      	movl	$0x4, %eax
    14ce:      	movl	$0x2, %esi
    14d3:      	callq	*%rax
    14d5:      	leaq	0x24(%rbp), %rdi
    14d9:      	leaq	0x224(%r12), %rdx
    14e1:      	movl	$0x2, %ecx
    14e6:      	movl	$0x4, %eax
    14eb:      	movl	$0x2, %esi
    14f0:      	callq	*%rax
    14f2:      	leaq	0x30(%rbp), %rdi
    14f6:      	leaq	0x21c(%r12), %rdx
    14fe:      	movl	$0x4, %ecx
    1503:      	movl	$0x4, %eax
    1508:      	movl	$0x4, %esi
    150d:      	callq	*%rax
    150f:      	leaq	0x34(%rbp), %rdi
    1513:      	leaq	0x218(%r12), %rdx
    151b:      	movl	$0x4, %ecx
    1520:      	movl	$0x4, %eax
    1525:      	movl	$0x4, %esi
    152a:      	callq	*%rax
    152c:      	leaq	0x10(%rbp), %r13
    1530:      	movq	$0x0, (%rbp)
    1538:      	movq	$0x0, 0x8(%rbp)
    1540:      	movq	$0x0, 0x10(%rbp)
    1548:      	movq	$0x0, 0x18(%rbp)
    1550:      	movzwl	0x26(%rbp), %eax
    1554:      	cmpl	$0xa, %eax
    1557:      	je	0x26e4 <generic_rawtp_process_event+0x2514>
    155d:      	cmpl	$0x2, %eax
    1560:      	jne	0x2716 <generic_rawtp_process_event+0x2546>
    1566:      	leaq	0x4(%r12), %rdx
    156b:      	movl	$0x4, %ecx
    1570:      	movl	$0x4, %eax
    1575:      	movq	%rbp, %rdi
    1578:      	movl	$0x4, %esi
    157d:      	callq	*%rax
    157f:      	movl	$0x4, %ecx
    1584:      	movl	$0x4, %eax
    1589:      	movq	%r13, %rdi
    158c:      	movl	$0x4, %esi
    1591:      	movq	%r12, %rdx
    1594:      	jmp	0x2714 <generic_rawtp_process_event+0x2544>
    1599:      	xorl	%r12d, %r12d
    159c:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    15a1:      	cmpl	$0x1e, %r13d
    15a5:      	jg	0x168d <generic_rawtp_process_event+0x14bd>
    15ab:      	cmpl	$0x1c, %r13d
    15af:      	jg	0x1807 <generic_rawtp_process_event+0x1637>
    15b5:      	movq	%rax, %r15
    15b8:      	movq	%r13, %rax
    15bb:      	cmpl	$0x11, %eax
    15be:      	je	0x2037 <generic_rawtp_process_event+0x1e67>
    15c4:      	cmpl	$0x19, %eax
    15c7:      	je	0x1c75 <generic_rawtp_process_event+0x1aa5>
    15cd:      	cmpl	$0x1c, %eax
    15d0:      	jmp	0x1795 <generic_rawtp_process_event+0x15c5>
    15d5:      	leal	-0xa(%r13), %eax
    15d9:      	cmpl	$0x2, %eax
    15dc:      	jb	0x17b0 <generic_rawtp_process_event+0x15e0>
    15e2:      	leal	-0xc(%r13), %eax
    15e6:      	cmpl	$0x2, %eax
    15e9:      	jb	0x17e3 <generic_rawtp_process_event+0x1613>
    15ef:      	movq	%r13, %rcx
    15f2:      	cmpl	$0xe, %ecx
    15f5:      	movq	0x40(%rsp), %rax
    15fa:      	movq	0x20(%rsp), %rcx
    15ff:      	movl	$0x4, %esi
    1604:      	movl	$0x0, %r12d
    160a:      	jne	0x12b1 <generic_rawtp_process_event+0x10e1>
    1610:      	movq	%r14, 0x28(%rsp)
    1615:      	movq	%rbx, 0x8(%rsp)
    161a:      	leaq	0x78(%rsp), %rdi
    161f:      	leaq	0x60(%rsp), %r12
    1624:      	movl	$0x8, %ecx
    1629:      	movl	$0x4, %eax
    162e:      	movl	$0x8, %esi
    1633:      	movq	%r12, %rdx
    1636:      	callq	*%rax
    1638:      	movq	0x78(%rsp), %rcx
    163d:      	movl	$0x8, %edx
    1642:      	movl	$0x4, %eax
    1647:      	movq	0x78(%rsp), %rdx
    164c:      	movq	%r12, %rdi
    164f:      	movl	$0x8, %esi
    1654:      	callq	*%rax
    1656:      	movq	0x60(%rsp), %rdx
    165b:      	leaq	0x4(%rbp), %rdi
    165f:      	movl	$0x1ff, %ecx            # imm = 0x1FF
    1664:      	movl	$0x2d, %eax
    1669:      	movl	$0x1ff, %esi            # imm = 0x1FF
    166e:      	callq	*%rax
    1670:      	movq	%rax, %r12
    1673:      	testq	%rax, %rax
    1676:      	js	0x3bff <generic_rawtp_process_event+0x3a2f>
    167c:      	leal	-0x1(%r12), %eax
    1681:      	movl	%eax, (%rbp)
    1684:      	addq	$0x3, %r12
    1688:      	jmp	0x3bff <generic_rawtp_process_event+0x3a2f>
    168d:      	movq	%r14, %r15
    1690:      	movq	%rbx, 0x8(%rsp)
    1695:      	cmpl	$0x26, %r13d
    1699:      	jg	0x182b <generic_rawtp_process_event+0x165b>
    169f:      	leal	-0x1f(%r13), %eax
    16a3:      	cmpl	$0x2, %eax
    16a6:      	jae	0x1b16 <generic_rawtp_process_event+0x1946>
    16ac:      	leaq	0x60(%rsp), %rdx
    16b1:      	movl	$0x4, %r12d
    16b7:      	movl	$0x1, %ecx
    16bc:      	movl	$0x4, %eax
    16c1:      	movq	%rbp, %rdi
    16c4:      	movl	$0x1, %esi
    16c9:      	callq	*%rax
    16cb:      	jmp	0x28de <generic_rawtp_process_event+0x270e>
    16d0:      	movq	%r15, 0x38(%rsp)
    16d5:      	cmpl	$0x20, %r13d
    16d9:      	jle	0x1a52 <generic_rawtp_process_event+0x1882>
    16df:      	leal	-0x21(%r13), %eax
    16e3:      	cmpl	$0x4, %eax
    16e6:      	jae	0x18eb <generic_rawtp_process_event+0x171b>
    16ec:      	movl	$0x8, %ebp
    16f1:      	movl	$0x8, %ecx
    16f6:      	movl	$0x4, %eax
    16fb:      	movq	0x38(%rsp), %rdi
    1700:      	movq	0x18(%rsp), %rdx
    1705:      	movl	$0x8, %esi
    170a:      	callq	*%rax
    170c:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    1711:      	cmpl	$0x7, %r13d
    1715:      	jg	0x1b63 <generic_rawtp_process_event+0x1993>
    171b:      	cmpl	$0x2, %eax
    171e:      	je	0x2135 <generic_rawtp_process_event+0x1f65>
    1724:      	cmpl	$0x3, %eax
    1727:      	movq	0x8(%rsp), %rbx
    172c:      	movq	0x28(%rsp), %r14
    1731:      	jne	0x385a <generic_rawtp_process_event+0x368a>
    1737:      	movq	0x48(%rsp), %rax
    173c:      	leaq	0x90(%rax), %r13
    1743:      	andl	$0xf, %r12d
    1747:      	movq	%r12, %rax
    174a:      	cmpl	$0x2, %r12d
    174e:      	jle	0x2873 <generic_rawtp_process_event+0x26a3>
    1754:      	cmpl	$0x3, %eax
    1757:      	je	0x2b33 <generic_rawtp_process_event+0x2963>
    175d:      	cmpl	$0x4, %eax
    1760:      	je	0x2b40 <generic_rawtp_process_event+0x2970>
    1766:      	cmpl	$0x5, %eax
    1769:      	jne	0x2f33 <generic_rawtp_process_event+0x2d63>
    176f:      	movq	0x48(%rsp), %rax
    1774:      	addq	$0x5e70, %rax           # imm = 0x5E70
    177a:      	jmp	0x2b58 <generic_rawtp_process_event+0x2988>
    177f:      	cmpl	$0x1, %r13d
    1783:      	movq	0x8(%rsp), %rbx
    1788:      	movq	0x28(%rsp), %r14
    178d:      	je	0x17e3 <generic_rawtp_process_event+0x1613>
    178f:      	movq	%r13, %rax
    1792:      	cmpl	$0x4, %eax
    1795:      	movq	0x40(%rsp), %rax
    179a:      	movq	0x20(%rsp), %rcx
    179f:      	movl	$0x4, %esi
    17a4:      	movl	$0x0, %r12d
    17aa:      	jne	0x12b1 <generic_rawtp_process_event+0x10e1>
    17b0:      	movl	$0x8, %r12d
    17b6:      	leaq	0x60(%rsp), %rdx
    17bb:      	movl	$0x8, %ecx
    17c0:      	movl	$0x4, %eax
    17c5:      	movq	%rbp, %rdi
    17c8:      	movl	$0x8, %esi
    17cd:      	callq	*%rax
    17cf:      	movl	$0x4, %esi
    17d4:      	movq	0x20(%rsp), %rcx
    17d9:      	movq	0x40(%rsp), %rax
    17de:      	jmp	0x12b1 <generic_rawtp_process_event+0x10e1>
    17e3:      	leaq	0x60(%rsp), %rdx
    17e8:      	movl	$0x4, %r12d
    17ee:      	movl	$0x4, %ecx
    17f3:      	movl	$0x4, %eax
    17f8:      	movq	%rbp, %rdi
    17fb:      	movl	$0x4, %esi
    1800:      	callq	*%rax
    1802:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    1807:      	leaq	0x60(%rsp), %rdx
    180c:      	movl	$0x4, %r12d
    1812:      	movl	$0x2, %ecx
    1817:      	movl	$0x4, %eax
    181c:      	movq	%rbp, %rdi
    181f:      	movl	$0x2, %esi
    1824:      	callq	*%rax
    1826:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    182b:      	cmpl	$0x27, %r13d
    182f:      	je	0x20f9 <generic_rawtp_process_event+0x1f29>
    1835:      	movq	%r13, %rax
    1838:      	cmpl	$0x28, %eax
    183b:      	movq	0x40(%rsp), %rax
    1840:      	movq	0x20(%rsp), %rcx
    1845:      	movl	$0x4, %esi
    184a:      	movq	0x8(%rsp), %rbx
    184f:      	movl	$0x0, %r12d
    1855:      	movq	%r15, %r14
    1858:      	jne	0x12b1 <generic_rawtp_process_event+0x10e1>
    185e:      	movq	0x60(%rsp), %r12
    1863:      	movq	%rbp, %rdi
    1866:      	movq	$0x0, 0x10(%rbp)
    186e:      	movq	$0x0, 0x8(%rbp)
    1876:      	movq	$0x0, (%rbp)
    187e:      	movl	$0x2, %ecx
    1883:      	movl	$0x4, %eax
    1888:      	movl	$0x2, %esi
    188d:      	movq	%r12, %rdx
    1890:      	callq	*%rax
    1892:      	testq	%rax, %rax
    1895:      	js	0x28d8 <generic_rawtp_process_event+0x2708>
    189b:      	movzwl	(%rbp), %eax
    189f:      	cmpl	$0xa, %eax
    18a2:      	je	0x2895 <generic_rawtp_process_event+0x26c5>
    18a8:      	cmpl	$0x2, %eax
    18ab:      	jne	0x28ce <generic_rawtp_process_event+0x26fe>
    18b1:      	leaq	0x4(%r12), %rdx
    18b6:      	leaq	0x78(%rsp), %rdi
    18bb:      	movl	$0x4, %ecx
    18c0:      	movl	$0x4, %eax
    18c5:      	movl	$0x4, %esi
    18ca:      	callq	*%rax
    18cc:      	movl	0x78(%rsp), %eax
    18d0:      	movq	%rax, 0x8(%rbp)
    18d4:      	leaq	0x2(%rbp), %rdi
    18d8:      	addq	$0x2, %r12
    18dc:      	movl	$0x2, %ecx
    18e1:      	movl	$0x4, %eax
    18e6:      	jmp	0x28c4 <generic_rawtp_process_event+0x26f4>
    18eb:      	movq	%r13, %rcx
    18ee:      	cmpl	$0x2b, %ecx
    18f1:      	je	0x24fc <generic_rawtp_process_event+0x232c>
    18f7:      	cmpl	$0x29, %ecx
    18fa:      	movq	0x8(%rsp), %rbx
    18ff:      	movq	0x28(%rsp), %r14
    1904:      	jne	0x385a <generic_rawtp_process_event+0x368a>
    190a:      	movq	0x18(%rsp), %rdx
    190f:      	addq	$0x18, %rdx
    1913:      	leaq	0x78(%rsp), %rdi
    1918:      	movl	$0x4, %ebx
    191d:      	movl	$0x8, %ecx
    1922:      	movl	$0x4, %eax
    1927:      	movl	$0x8, %esi
    192c:      	callq	*%rax
    192e:      	movq	0x78(%rsp), %r12
    1933:      	testq	%r12, %r12
    1936:      	je	0x2aeb <generic_rawtp_process_event+0x291b>
    193c:      	movq	0x38(%rsp), %r15
    1941:      	movq	%r12, 0x28(%r15)
    1945:      	leaq	0x26(%r15), %rdi
    1949:      	leaq	0x10(%r12), %rdx
    194e:      	movl	$0x2, %ecx
    1953:      	movl	$0x4, %eax
    1958:      	movl	$0x2, %esi
    195d:      	callq	*%rax
    195f:      	leaq	0x3a(%r15), %rdi
    1963:      	leaq	0x12(%r12), %rdx
    1968:      	movl	$0x1, %ecx
    196d:      	movl	$0x4, %eax
    1972:      	movl	$0x1, %esi
    1977:      	callq	*%rax
    1979:      	leaq	0x38(%r15), %rdi
    197d:      	leaq	0x226(%r12), %rdx
    1985:      	movl	$0x2, %ecx
    198a:      	movl	$0x4, %eax
    198f:      	movl	$0x2, %esi
    1994:      	callq	*%rax
    1996:      	leaq	0x24(%r15), %rdi
    199a:      	leaq	0x224(%r12), %rdx
    19a2:      	movl	$0x2, %ecx
    19a7:      	movl	$0x4, %eax
    19ac:      	movl	$0x2, %esi
    19b1:      	callq	*%rax
    19b3:      	leaq	0x30(%r15), %rdi
    19b7:      	leaq	0x21c(%r12), %rdx
    19bf:      	movl	$0x4, %eax
    19c4:      	movl	$0x4, %esi
    19c9:      	callq	*%rax
    19cb:      	leaq	0x34(%r15), %rdi
    19cf:      	leaq	0x218(%r12), %rdx
    19d7:      	movl	$0x4, %eax
    19dc:      	movl	$0x4, %esi
    19e1:      	callq	*%rax
    19e3:      	leaq	0x10(%r15), %r13
    19e7:      	movq	$0x0, (%r15)
    19ee:      	movq	$0x0, 0x8(%r15)
    19f6:      	movq	$0x0, 0x10(%r15)
    19fe:      	movq	$0x0, 0x18(%r15)
    1a06:      	movzwl	0x26(%r15), %eax
    1a0b:      	cmpl	$0xa, %eax
    1a0e:      	je	0x2a6f <generic_rawtp_process_event+0x289f>
    1a14:      	cmpl	$0x2, %eax
    1a17:      	jne	0x2aa3 <generic_rawtp_process_event+0x28d3>
    1a1d:      	leaq	0x4(%r12), %rdx
    1a22:      	movl	$0x4, %ecx
    1a27:      	movl	$0x4, %eax
    1a2c:      	movq	0x38(%rsp), %rdi
    1a31:      	movl	$0x4, %esi
    1a36:      	callq	*%rax
    1a38:      	movl	$0x4, %ecx
    1a3d:      	movl	$0x4, %eax
    1a42:      	movq	%r13, %rdi
    1a45:      	movl	$0x4, %esi
    1a4a:      	movq	%r12, %rdx
    1a4d:      	jmp	0x2aa1 <generic_rawtp_process_event+0x28d1>
    1a52:      	cmpl	$0x1a, %r13d
    1a56:      	je	0x2598 <generic_rawtp_process_event+0x23c8>
    1a5c:      	movq	%r13, %rax
    1a5f:      	cmpl	$0x1b, %eax
    1a62:      	movq	0x8(%rsp), %rbx
    1a67:      	movq	0x28(%rsp), %r14
    1a6c:      	jne	0x385a <generic_rawtp_process_event+0x368a>
    1a72:      	movq	0x38(%rsp), %rax
    1a77:      	movq	$0x0, 0x48(%rax)
    1a7f:      	movq	$0x0, 0x40(%rax)
    1a87:      	movq	$0x0, 0x38(%rax)
    1a8f:      	movq	$0x0, 0x30(%rax)
    1a97:      	movq	$0x0, 0x28(%rax)
    1a9f:      	movq	$0x0, 0x20(%rax)
    1aa7:      	movq	$0x0, 0x18(%rax)
    1aaf:      	movq	$0x0, 0x10(%rax)
    1ab7:      	movq	$0x0, 0x8(%rax)
    1abf:      	movq	$0x0, (%rax)
    1ac6:      	leaq	0x10(%rax), %rdi
    1aca:      	movq	0x18(%rsp), %rax
    1acf:      	leaq	0x18(%rax), %rdx
    1ad3:      	movl	$0x3f, %ecx
    1ad8:      	movl	$0x2d, %eax
    1add:      	movl	$0x3f, %esi
    1ae2:      	callq	*%rax
    1ae4:      	testq	%rax, %rax
    1ae7:      	js	0x2610 <generic_rawtp_process_event+0x2440>
    1aed:      	movq	0x38(%rsp), %rdi
    1af2:      	addq	$0x8, %rdi
    1af6:      	movq	0x18(%rsp), %rdx
    1afb:      	addq	$0x348, %rdx            # imm = 0x348
    1b02:      	movl	$0x8, %ecx
    1b07:      	movl	$0x4, %eax
    1b0c:      	movl	$0x8, %esi
    1b11:      	jmp	0x237a <generic_rawtp_process_event+0x21aa>
    1b16:      	movq	%r13, %rcx
    1b19:      	cmpl	$0x26, %ecx
    1b1c:      	movq	0x40(%rsp), %rax
    1b21:      	movq	0x20(%rsp), %rcx
    1b26:      	movl	$0x4, %esi
    1b2b:      	movq	0x8(%rsp), %rbx
    1b30:      	movl	$0x0, %r12d
    1b36:      	movq	%r15, %r14
    1b39:      	jne	0x12b1 <generic_rawtp_process_event+0x10e1>
    1b3f:      	movq	0x60(%rsp), %rsi
    1b44:      	movzwl	%si, %edx
    1b47:      	addq	%rbx, %rdx
    1b4a:      	shrl	$0x10, %esi
    1b4d:      	andl	$0xfff, %esi            # imm = 0xFFF
    1b53:      	leaq	0x4(%rbp), %rdi
    1b57:      	incl	%esi
    1b59:      	movl	$0x2d, %eax
    1b5e:      	jmp	0x2116 <generic_rawtp_process_event+0x1f46>
    1b63:      	cmpl	$0x8, %eax
    1b66:      	je	0x21a1 <generic_rawtp_process_event+0x1fd1>
    1b6c:      	cmpl	$0x12, %eax
    1b6f:      	movq	0x8(%rsp), %rbx
    1b74:      	movq	0x28(%rsp), %r14
    1b79:      	jne	0x385a <generic_rawtp_process_event+0x368a>
    1b7f:      	movq	0x58(%rsp), %rbp
    1b84:      	andl	$0x3ff, %ebp            # imm = 0x3FF
    1b8a:      	movl	$0x4, %eax
    1b8f:      	movq	0x18(%rsp), %rdx
    1b94:      	movq	%r15, %rdi
    1b97:      	movl	%ebp, %esi
    1b99:      	callq	*%rax
    1b9b:      	jmp	0x385a <generic_rawtp_process_event+0x368a>
    1ba0:      	cmpl	$0x13, %eax
    1ba3:      	je	0x24a2 <generic_rawtp_process_event+0x22d2>
    1ba9:      	cmpl	$0x14, %eax
    1bac:      	movq	0x8(%rsp), %rbx
    1bb1:      	movq	0x28(%rsp), %r14
    1bb6:      	jne	0x385a <generic_rawtp_process_event+0x368a>
    1bbc:      	movq	$0x0, 0x78(%rsp)
    1bc5:      	movq	0x18(%rsp), %r13
    1bca:      	leaq	0x110(%r13), %rdx
    1bd1:      	leaq	0x78(%rsp), %rdi
    1bd6:      	movl	$0x8, %ecx
    1bdb:      	movl	$0x4, %eax
    1be0:      	leaq	0xd8(%r13), %r12
    1be7:      	movl	$0x8, %esi
    1bec:      	callq	*%rax
    1bee:      	movq	0x78(%rsp), %rcx
    1bf3:      	movl	$0x80, %edx
    1bf8:      	movl	$0x2d, %eax
    1bfd:      	movq	0x78(%rsp), %rdx
    1c02:      	movq	%r15, %rdi
    1c05:      	movl	$0x80, %esi
    1c0a:      	callq	*%rax
    1c0c:      	leaq	0x90(%r15), %rdi
    1c13:      	movl	$0x4, %ecx
    1c18:      	movl	$0x4, %eax
    1c1d:      	movl	$0x4, %esi
    1c22:      	movq	%r12, %rdx
    1c25:      	callq	*%rax
    1c27:      	leaq	0x80(%r15), %rdi
    1c2e:      	leaq	0xe0(%r13), %rdx
    1c35:      	movl	$0x8, %ecx
    1c3a:      	movl	$0x4, %eax
    1c3f:      	movl	$0x8, %esi
    1c44:      	callq	*%rax
    1c46:      	addq	$0x88, %r15
    1c4d:      	addq	$0x118, %r13            # imm = 0x118
    1c54:      	movl	$0x8, %ecx
    1c59:      	movl	$0x4, %eax
    1c5e:      	movq	%r15, %rdi
    1c61:      	movl	$0x8, %esi
    1c66:      	movq	%r13, %rdx
    1c69:      	callq	*%rax
    1c6b:      	movl	$0x98, %ebp
    1c70:      	jmp	0x385a <generic_rawtp_process_event+0x368a>
    1c75:      	movq	0x60(%rsp), %r13
    1c7a:      	leaq	0xd8(%rsp), %rdi
    1c82:      	movl	$0x1, %ecx
    1c87:      	movl	$0x4, %eax
    1c8c:      	movl	$0x1, %esi
    1c91:      	movq	%r13, %rdx
    1c94:      	callq	*%rax
    1c96:      	cmpb	$0x1, 0xd8(%rsp)
    1c9e:      	jne	0x2617 <generic_rawtp_process_event+0x2447>
    1ca4:      	addq	$0x10, %r13
    1ca8:      	leaq	0x68(%rsp), %rdi
    1cad:      	movl	$0x8, %ebp
    1cb2:      	movl	$0x8, %ecx
    1cb7:      	movl	$0x4, %eax
    1cbc:      	movl	$0x8, %esi
    1cc1:      	movq	%r13, %rdx
    1cc4:      	callq	*%rax
    1cc6:      	movq	0x68(%rsp), %rdx
    1ccb:      	leaq	0xc0(%rsp), %rdi
    1cd3:      	movl	$0x8, %ecx
    1cd8:      	movl	$0x4, %eax
    1cdd:      	movl	$0x8, %esi
    1ce2:      	callq	*%rax
    1ce4:      	movq	0x68(%rsp), %rdx
    1ce9:      	addq	$0x8, %rdx
    1ced:      	leaq	0x50(%rsp), %rdi
    1cf2:      	movl	$0x8, %ecx
    1cf7:      	movl	$0x4, %eax
    1cfc:      	movl	$0x8, %esi
    1d01:      	callq	*%rax
    1d03:      	movq	0xc0(%rsp), %rax
    1d0b:      	movq	%rax, 0x48(%rsp)
    1d10:      	movq	0x50(%rsp), %rax
    1d15:      	movq	%rax, 0x18(%rsp)
    1d1a:      	movq	0x38(%rsp), %rax
    1d1f:      	addq	%r15, %rax
    1d22:      	addq	$0x90, %rax
    1d28:      	movq	%rax, 0x58(%rsp)
    1d2d:      	testb	$0x20, %r12b
    1d31:      	je	0x29dc <generic_rawtp_process_event+0x280c>
    1d37:      	cmpq	$0x1000, 0x18(%rsp)     # imm = 0x1000
    1d40:      	jb	0x29b3 <generic_rawtp_process_event+0x27e3>
    1d46:      	movq	0x58(%rsp), %rax
    1d4b:      	movl	$0x1, (%rax)
    1d51:      	movl	$0x0, 0xd0(%rsp)
    1d5c:      	movq	(%rip), %rdi            # 0x1d63 <generic_rawtp_process_event+0x1b93>
    1d63:      	leaq	0xd0(%rsp), %rsi
    1d6b:      	movl	$0x1, %eax
    1d70:      	callq	*%rax
    1d72:      	movq	%rax, 0x30(%rsp)
    1d77:      	testq	%rax, %rax
    1d7a:      	je	0x30f0 <generic_rawtp_process_event+0x2f20>
    1d80:      	movq	0x30(%rsp), %r12
    1d85:      	movl	$0x18, (%r12)
    1d8d:      	movl	$0xe, %eax
    1d92:      	callq	*%rax
    1d94:      	leaq	0x10(%r12), %r15
    1d99:      	movq	%rax, 0x10(%r12)
    1d9e:      	cmpq	$-0x16, %rax
    1da2:      	jne	0x1dc6 <generic_rawtp_process_event+0x1bf6>
    1da4:      	leaq	0x20(%rbx), %rdx
    1da8:      	leaq	0x78(%rsp), %rdi
    1dad:      	movl	$0x8, %ecx
    1db2:      	movl	$0x4, %eax
    1db7:      	movl	$0x8, %esi
    1dbc:      	callq	*%rax
    1dbe:      	movq	0x78(%rsp), %rax
    1dc3:      	movq	%rax, (%r15)
    1dc6:      	movl	$0x7d, %eax
    1dcb:      	callq	*%rax
    1dcd:      	movq	0x30(%rsp), %rbp
    1dd2:      	movq	%rax, 0x18(%rbp)
    1dd6:      	movq	(%r15), %rax
    1dd9:      	movq	0x8(%r15), %rcx
    1ddd:      	movq	0x58(%rsp), %rdx
    1de2:      	movq	%rax, 0x14(%rdx)
    1de6:      	movq	%rcx, 0x1c(%rdx)
    1dea:      	addq	$0x20, %rbp
    1dee:      	movl	$0xa, %r15d
    1df4:      	xorl	%r12d, %r12d
    1df7:      	movq	0x18(%rsp), %r13
    1dfc:      	subq	%r12, %r13
    1dff:      	js	0x32ff <generic_rawtp_process_event+0x312f>
    1e05:      	movq	0x48(%rsp), %rax
    1e0a:      	leaq	(%r12,%rax), %rdx
    1e0e:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    1e15:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    1e1a:      	cmovaeq	%rax, %r13
    1e1e:      	movl	$0x4, %eax
    1e23:      	movq	%rbp, %rdi
    1e26:      	movl	%r13d, %esi
    1e29:      	callq	*%rax
    1e2b:      	testl	%eax, %eax
    1e2d:      	js	0x1e56 <generic_rawtp_process_event+0x1c86>
    1e2f:      	leal	0x20(%r13), %r8d
    1e33:      	movq	0x30(%rsp), %rcx
    1e38:      	movl	%r8d, 0x4(%rcx)
    1e3c:      	movl	$0x19, %eax
    1e41:      	movq	%rbx, %rdi
    1e44:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    1e49:      	movq	(%rip), %rsi            # 0x1e50 <generic_rawtp_process_event+0x1c80>
    1e50:      	callq	*%rax
    1e52:      	testl	%eax, %eax
    1e54:      	jns	0x1e59 <generic_rawtp_process_event+0x1c89>
    1e56:      	movslq	%eax, %r13
    1e59:      	testl	%r13d, %r13d
    1e5c:      	js	0x3308 <generic_rawtp_process_event+0x3138>
    1e62:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    1e69:      	addq	%r13, %r12
    1e6c:      	cmpq	0x18(%rsp), %r12
    1e71:      	je	0x3362 <generic_rawtp_process_event+0x3192>
    1e77:      	decl	%r15d
    1e7a:      	jne	0x1df7 <generic_rawtp_process_event+0x1c27>
    1e80:      	jmp	0x36c3 <generic_rawtp_process_event+0x34f3>
    1e85:      	movq	0x60(%rsp), %r13
    1e8a:      	movq	%rbp, %rbx
    1e8d:      	leaq	0x28(%rbp), %rdi
    1e91:      	leaq	0x98(%r13), %rdx
    1e98:      	movl	$0x4, %ecx
    1e9d:      	movl	$0x4, %eax
    1ea2:      	movl	$0x4, %esi
    1ea7:      	callq	*%rax
    1ea9:      	leaq	0x2c(%rbp), %rdi
    1ead:      	leaq	0x70(%r13), %rdx
    1eb1:      	movl	$0x4, %ecx
    1eb6:      	movl	$0x4, %eax
    1ebb:      	movl	$0x4, %esi
    1ec0:      	callq	*%rax
    1ec2:      	leaq	0x30(%rbp), %rdi
    1ec6:      	leaq	0x90(%r13), %rdx
    1ecd:      	movl	$0x4, %ecx
    1ed2:      	movl	$0x4, %eax
    1ed7:      	movl	$0x4, %esi
    1edc:      	callq	*%rax
    1ede:      	leaq	0x34(%rbp), %rdi
    1ee2:      	leaq	0xa8(%r13), %rdx
    1ee9:      	movl	$0x4, %ecx
    1eee:      	movl	$0x4, %eax
    1ef3:      	movl	$0x4, %esi
    1ef8:      	callq	*%rax
    1efa:      	movq	$0x0, 0x78(%rsp)
    1f03:      	leaq	0xc8(%r13), %rdx
    1f0a:      	leaq	0x78(%rsp), %rdi
    1f0f:      	movl	$0x8, %ecx
    1f14:      	movl	$0x4, %eax
    1f19:      	movl	$0x8, %esi
    1f1e:      	callq	*%rax
    1f20:      	leaq	0xb8(%r13), %rdx
    1f27:      	leaq	0x50(%rsp), %rdi
    1f2c:      	movl	$0x2, %ecx
    1f31:      	movl	$0x4, %eax
    1f36:      	movl	$0x2, %esi
    1f3b:      	callq	*%rax
    1f3d:      	movzwl	0x50(%rsp), %r12d
    1f43:      	addq	0x78(%rsp), %r12
    1f48:      	leaq	0xe4(%rsp), %rdi
    1f50:      	movl	$0x1, %ecx
    1f55:      	movl	$0x4, %eax
    1f5a:      	movl	$0x1, %esi
    1f5f:      	movq	%r12, %rdx
    1f62:      	callq	*%rax
    1f64:      	movzbl	0xe4(%rsp), %eax
    1f6c:      	shrl	$0x4, %eax
    1f6f:      	cmpl	$0x6, %eax
    1f72:      	je	0x263f <generic_rawtp_process_event+0x246f>
    1f78:      	cmpl	$0x4, %eax
    1f7b:      	jne	0x3bf9 <generic_rawtp_process_event+0x3a29>
    1f81:      	leaq	0x9(%r12), %rdx
    1f86:      	leaq	0xd8(%rsp), %rdi
    1f8e:      	movl	$0x1, %ecx
    1f93:      	movl	$0x4, %eax
    1f98:      	movl	$0x1, %esi
    1f9d:      	callq	*%rax
    1f9f:      	movzbl	0xd8(%rsp), %eax
    1fa7:      	movq	%rbp, %rdi
    1faa:      	movw	%ax, 0x24(%rbp)
    1fae:      	movw	$0x2, 0x26(%rbp)
    1fb4:      	leaq	0xc(%r12), %rdx
    1fb9:      	movq	$0x0, (%rbp)
    1fc1:      	movq	$0x0, 0x8(%rbp)
    1fc9:      	movq	$0x0, 0x10(%rbp)
    1fd1:      	movq	$0x0, 0x18(%rbp)
    1fd9:      	movl	$0x4, %ecx
    1fde:      	movl	$0x4, %eax
    1fe3:      	leaq	0x10(%rbp), %rbx
    1fe7:      	movl	$0x4, %esi
    1fec:      	callq	*%rax
    1fee:      	addq	$0x10, %r12
    1ff2:      	movl	$0x4, %ecx
    1ff7:      	movl	$0x4, %eax
    1ffc:      	movq	%rbx, %rdi
    1fff:      	movl	$0x4, %esi
    2004:      	movq	%r12, %rdx
    2007:      	callq	*%rax
    2009:      	leaq	0xb6(%r13), %rdx
    2010:      	leaq	0xd0(%rsp), %rdi
    2018:      	movl	$0x2, %ecx
    201d:      	movl	$0x4, %eax
    2022:      	movl	$0x2, %esi
    2027:      	callq	*%rax
    2029:      	movzbl	0xd8(%rsp), %r12d
    2032:      	jmp	0x3aaa <generic_rawtp_process_event+0x38da>
    2037:      	movq	$0x0, 0x80(%rsp)
    2043:      	movl	$0xe, %eax
    2048:      	callq	*%rax
    204a:      	shrq	$0x20, %rax
    204e:      	movq	%rax, 0x78(%rsp)
    2053:      	leaq	0x68(%rsp), %rdi
    2058:      	leaq	0x60(%rsp), %rdx
    205d:      	movl	$0x4, %ecx
    2062:      	movl	$0x4, %eax
    2067:      	movl	$0x4, %esi
    206c:      	callq	*%rax
    206e:      	movl	0x68(%rsp), %eax
    2072:      	movl	%eax, 0x80(%rsp)
    2079:      	movq	(%rip), %rdi            # 0x2080 <generic_rawtp_process_event+0x1eb0>
    2080:      	leaq	0x78(%rsp), %rsi
    2085:      	movl	$0x1, %eax
    208a:      	callq	*%rax
    208c:      	testq	%rax, %rax
    208f:      	je	0x2633 <generic_rawtp_process_event+0x2463>
    2095:      	movq	%rax, %r13
    2098:      	movl	(%rax), %r15d
    209b:      	leaq	0x68(%rsp), %rdx
    20a0:      	movl	$0x4, %eax
    20a5:      	movq	%rbp, %r12
    20a8:      	movl	$0x4, %ebp
    20ad:      	movq	%r12, %rdi
    20b0:      	movl	$0x4, %esi
    20b5:      	callq	*%rax
    20b7:      	andl	$0xfff, %r15d           # imm = 0xFFF
    20be:      	leaq	0x4(%r12), %rdi
    20c3:      	leaq	0x4(%r15), %rsi
    20c7:      	movl	$0x4, %eax
    20cc:      	movq	%r13, %rdx
    20cf:      	callq	*%rax
    20d1:      	leaq	(%r12,%r15), %rdi
    20d5:      	addq	$0x8, %rdi
    20d9:      	leaq	(%r15,%r13), %rdx
    20dd:      	addq	$0x4, %rdx
    20e1:      	movl	$0x4, %eax
    20e6:      	movl	$0x4, %esi
    20eb:      	callq	*%rax
    20ed:      	addq	$0xc, %r15
    20f1:      	movq	%r15, %r12
    20f4:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    20f9:      	movl	$0x120, %edx            # imm = 0x120
    20fe:      	addq	0x60(%rsp), %rdx
    2103:      	leaq	0x4(%rbp), %rdi
    2107:      	movl	$0x11, %ecx
    210c:      	movl	$0x2d, %eax
    2111:      	movl	$0x11, %esi
    2116:      	callq	*%rax
    2118:      	movq	%rax, %r12
    211b:      	testq	%rax, %rax
    211e:      	js	0x28de <generic_rawtp_process_event+0x270e>
    2124:      	leal	-0x1(%r12), %eax
    2129:      	movl	%eax, (%rbp)
    212c:      	addq	$0x3, %r12
    2130:      	jmp	0x28de <generic_rawtp_process_event+0x270e>
    2135:      	movq	0x38(%rsp), %rax
    213a:      	movq	0x48(%rsp), %rcx
    213f:      	leaq	(%rcx,%rax), %rbx
    2143:      	addq	$0x90, %rbx
    214a:      	movq	$0x0, 0x60(%rsp)
    2153:      	testb	$0x10, %r12b
    2157:      	jne	0x279c <generic_rawtp_process_event+0x25cc>
    215d:      	movl	%r12d, %r15d
    2160:      	movq	0x58(%rsp), %rdx
    2165:      	andl	$0xf, %edx
    2168:      	xorl	%eax, %eax
    216a:      	movq	%rdx, %rcx
    216d:      	cmpl	$0x2, %edx
    2170:      	jle	0x2a4d <generic_rawtp_process_event+0x287d>
    2176:      	cmpl	$0x3, %ecx
    2179:      	je	0x30fb <generic_rawtp_process_event+0x2f2b>
    217f:      	cmpl	$0x4, %ecx
    2182:      	je	0x3108 <generic_rawtp_process_event+0x2f38>
    2188:      	cmpl	$0x5, %ecx
    218b:      	jne	0x3123 <generic_rawtp_process_event+0x2f53>
    2191:      	movq	0x48(%rsp), %rax
    2196:      	addq	$0x5e70, %rax           # imm = 0x5E70
    219c:      	jmp	0x3120 <generic_rawtp_process_event+0x2f50>
    21a1:      	movq	%r15, %rbx
    21a4:      	leaq	0x28(%r15), %r13
    21a8:      	leaq	0x40(%r15), %r12
    21ac:      	movq	0x18(%rsp), %r15
    21b1:      	leaq	0x8(%r15), %rdx
    21b5:      	movl	$0x4, %ecx
    21ba:      	movl	$0x4, %eax
    21bf:      	movq	%rbx, %rdi
    21c2:      	movl	$0x4, %esi
    21c7:      	callq	*%rax
    21c9:      	leaq	0x4(%rbx), %rdi
    21cd:      	leaq	0xc(%r15), %rdx
    21d1:      	movl	$0x4, %ecx
    21d6:      	movl	$0x4, %eax
    21db:      	movl	$0x4, %esi
    21e0:      	callq	*%rax
    21e2:      	leaq	0x10(%rbx), %rdi
    21e6:      	leaq	0x18(%r15), %rdx
    21ea:      	movl	$0x4, %ecx
    21ef:      	movl	$0x4, %eax
    21f4:      	movl	$0x4, %esi
    21f9:      	callq	*%rax
    21fb:      	leaq	0x14(%rbx), %rdi
    21ff:      	leaq	0x1c(%r15), %rdx
    2203:      	movl	$0x4, %ecx
    2208:      	movl	$0x4, %eax
    220d:      	movl	$0x4, %esi
    2212:      	callq	*%rax
    2214:      	leaq	0x8(%rbx), %rdi
    2218:      	leaq	0x10(%r15), %rdx
    221c:      	movl	$0x4, %ecx
    2221:      	movl	$0x4, %eax
    2226:      	movl	$0x4, %esi
    222b:      	callq	*%rax
    222d:      	leaq	0xc(%rbx), %rdi
    2231:      	leaq	0x14(%r15), %rdx
    2235:      	movl	$0x4, %ecx
    223a:      	movl	$0x4, %eax
    223f:      	movl	$0x4, %esi
    2244:      	callq	*%rax
    2246:      	leaq	0x18(%rbx), %rdi
    224a:      	leaq	0x20(%r15), %rdx
    224e:      	movl	$0x4, %ecx
    2253:      	movl	$0x4, %eax
    2258:      	movl	$0x4, %esi
    225d:      	callq	*%rax
    225f:      	leaq	0x1c(%rbx), %rdi
    2263:      	leaq	0x24(%r15), %rdx
    2267:      	movl	$0x4, %ecx
    226c:      	movl	$0x4, %eax
    2271:      	movl	$0x4, %esi
    2276:      	callq	*%rax
    2278:      	movl	$0x0, 0x24(%rbx)
    227f:      	leaq	0x20(%rbx), %rdi
    2283:      	leaq	0x28(%r15), %rdx
    2287:      	movl	$0x4, %ecx
    228c:      	movl	$0x4, %eax
    2291:      	movl	$0x4, %esi
    2296:      	callq	*%rax
    2298:      	leaq	0x30(%rbx), %rdi
    229c:      	leaq	0x40(%r15), %rdx
    22a0:      	movl	$0x8, %ecx
    22a5:      	movl	$0x4, %eax
    22aa:      	movl	$0x8, %esi
    22af:      	callq	*%rax
    22b1:      	leaq	0x38(%rbx), %rdi
    22b5:      	leaq	0x30(%r15), %rdx
    22b9:      	movl	$0x8, %ecx
    22be:      	movl	$0x4, %eax
    22c3:      	movl	$0x8, %esi
    22c8:      	callq	*%rax
    22ca:      	leaq	0x38(%r15), %rdx
    22ce:      	movl	$0x8, %ecx
    22d3:      	movl	$0x4, %eax
    22d8:      	movq	%r13, %rdi
    22db:      	movl	$0x8, %esi
    22e0:      	callq	*%rax
    22e2:      	addq	$0x90, %r15
    22e9:      	leaq	0x78(%rsp), %rdi
    22ee:      	movl	$0x8, %ecx
    22f3:      	movl	$0x4, %eax
    22f8:      	movl	$0x8, %esi
    22fd:      	movq	%r15, %rdx
    2300:      	callq	*%rax
    2302:      	movq	0x78(%rsp), %r13
    2307:      	leaq	0xc8(%r13), %rdx
    230e:      	movl	$0x4, %ecx
    2313:      	movl	$0x4, %eax
    2318:      	movq	%r12, %rdi
    231b:      	movl	$0x4, %esi
    2320:      	callq	*%rax
    2322:      	leaq	0x44(%rbx), %rdi
    2326:      	leaq	0xcc(%r13), %rdx
    232d:      	movl	$0x4, %ecx
    2332:      	movl	$0x4, %eax
    2337:      	movl	$0x4, %esi
    233c:      	callq	*%rax
    233e:      	leaq	0x48(%rbx), %rdi
    2342:      	leaq	0xd0(%r13), %rdx
    2349:      	movl	$0x4, %ecx
    234e:      	movl	$0x4, %eax
    2353:      	movl	$0x4, %esi
    2358:      	callq	*%rax
    235a:      	addq	$0x4c, %rbx
    235e:      	addq	$0x158, %r13            # imm = 0x158
    2365:      	movl	$0x4, %ecx
    236a:      	movl	$0x4, %eax
    236f:      	movq	%rbx, %rdi
    2372:      	movl	$0x4, %esi
    2377:      	movq	%r13, %rdx
    237a:      	callq	*%rax
    237c:      	movl	$0x50, %ebp
    2381:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    2386:      	movq	0x18(%rsp), %r12
    238b:      	leaq	0xc8(%r12), %rdx
    2393:      	movl	$0x4, %ecx
    2398:      	movl	$0x4, %eax
    239d:      	movq	%r15, %rdi
    23a0:      	movl	$0x4, %esi
    23a5:      	callq	*%rax
    23a7:      	leaq	0x4(%r15), %rdi
    23ab:      	leaq	0xcc(%r12), %rdx
    23b3:      	movl	$0x4, %ecx
    23b8:      	movl	$0x4, %eax
    23bd:      	movl	$0x4, %esi
    23c2:      	callq	*%rax
    23c4:      	leaq	0x8(%r15), %rdi
    23c8:      	leaq	0xd0(%r12), %rdx
    23d0:      	movl	$0x4, %ecx
    23d5:      	movl	$0x4, %eax
    23da:      	movl	$0x4, %esi
    23df:      	callq	*%rax
    23e1:      	addq	$0xc, %r15
    23e5:      	addq	$0x158, %r12            # imm = 0x158
    23ec:      	movl	$0x4, %ecx
    23f1:      	movl	$0x4, %eax
    23f6:      	movq	%r15, %rdi
    23f9:      	movl	$0x4, %esi
    23fe:      	movq	%r12, %rdx
    2401:      	callq	*%rax
    2403:      	movl	$0x10, %ebp
    2408:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    240d:      	movq	0x18(%rsp), %r12
    2412:      	leaq	0x38(%r12), %rdx
    2417:      	movl	$0x4, %ecx
    241c:      	movl	$0x4, %eax
    2421:      	movq	%r15, %rdi
    2424:      	movl	$0x4, %esi
    2429:      	callq	*%rax
    242b:      	leaq	0x4(%r15), %rdi
    242f:      	leaq	0x3c(%r12), %rdx
    2434:      	movl	$0x4, %ecx
    2439:      	movl	$0x4, %eax
    243e:      	movl	$0x4, %esi
    2443:      	callq	*%rax
    2445:      	leaq	0x8(%r15), %rdi
    2449:      	leaq	0x40(%r12), %rdx
    244e:      	movl	$0x4, %ecx
    2453:      	movl	$0x4, %eax
    2458:      	movl	$0x4, %esi
    245d:      	callq	*%rax
    245f:      	leaq	0xc(%r15), %rdi
    2463:      	leaq	0x44(%r12), %rdx
    2468:      	movl	$0x4, %ecx
    246d:      	movl	$0x4, %eax
    2472:      	movl	$0x4, %esi
    2477:      	callq	*%rax
    2479:      	addq	$0x10, %r15
    247d:      	subq	$-0x80, %r12
    2481:      	movl	$0x10, %ecx
    2486:      	movl	$0x4, %eax
    248b:      	movq	%r15, %rdi
    248e:      	movl	$0x10, %esi
    2493:      	movq	%r12, %rdx
    2496:      	callq	*%rax
    2498:      	movl	$0x20, %ebp
    249d:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    24a2:      	movl	$0x4, %ecx
    24a7:      	movl	$0x4, %eax
    24ac:      	movq	%r15, %rbx
    24af:      	movq	0x18(%rsp), %r15
    24b4:      	movq	%rbx, %rdi
    24b7:      	movl	$0x4, %esi
    24bc:      	movq	%r15, %rdx
    24bf:      	callq	*%rax
    24c1:      	leaq	0x4(%rbx), %rdi
    24c5:      	leaq	0x4(%r15), %rdx
    24c9:      	movl	$0x4, %ecx
    24ce:      	movl	$0x4, %eax
    24d3:      	movl	$0x4, %esi
    24d8:      	callq	*%rax
    24da:      	addq	$0x8, %rbx
    24de:      	addq	$0x30, %r15
    24e2:      	movl	$0x10, %ecx
    24e7:      	movl	$0x4, %eax
    24ec:      	movq	%rbx, %rdi
    24ef:      	movl	$0x10, %esi
    24f4:      	movq	%r15, %rdx
    24f7:      	jmp	0x258c <generic_rawtp_process_event+0x23bc>
    24fc:      	movq	0x18(%rsp), %r15
    2501:      	leaq	0x4(%r15), %rdx
    2505:      	leaq	0x78(%rsp), %rdi
    250a:      	movl	$0x4, %ecx
    250f:      	movl	$0x4, %eax
    2514:      	movl	$0x4, %esi
    2519:      	callq	*%rax
    251b:      	movl	0x78(%rsp), %eax
    251f:      	movq	0x38(%rsp), %rbx
    2524:      	movl	%eax, (%rbx)
    2526:      	leaq	0xc(%r15), %rdx
    252a:      	leaq	0x78(%rsp), %rdi
    252f:      	movl	$0x4, %ecx
    2534:      	movl	$0x4, %eax
    2539:      	movl	$0x4, %esi
    253e:      	callq	*%rax
    2540:      	movl	0x78(%rsp), %eax
    2544:      	movl	%eax, 0x4(%rbx)
    2547:      	addq	$0x50, %r15
    254b:      	leaq	0x78(%rsp), %rdi
    2550:      	movl	$0x8, %ecx
    2555:      	movl	$0x2d, %eax
    255a:      	movl	$0x8, %esi
    255f:      	movq	%r15, %rdx
    2562:      	callq	*%rax
    2564:      	addq	$0x8, %rbx
    2568:      	movl	$0x3f8, %edx            # imm = 0x3F8
    256d:      	movq	0x78(%rsp), %rcx
    2572:      	addq	%rdx, %rcx
    2575:      	movl	$0x10, %esi
    257a:      	movl	$0x2d, %eax
    257f:      	addq	0x78(%rsp), %rdx
    2584:      	movq	%rbx, %rdi
    2587:      	movl	$0x10, %esi
    258c:      	callq	*%rax
    258e:      	movl	$0x18, %ebp
    2593:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    2598:      	movq	0x38(%rsp), %rax
    259d:      	movq	$0x0, 0x48(%rax)
    25a5:      	movq	$0x0, 0x40(%rax)
    25ad:      	movq	$0x0, 0x38(%rax)
    25b5:      	movq	$0x0, 0x30(%rax)
    25bd:      	movq	$0x0, 0x28(%rax)
    25c5:      	movq	$0x0, 0x20(%rax)
    25cd:      	movq	$0x0, 0x18(%rax)
    25d5:      	movq	$0x0, 0x10(%rax)
    25dd:      	movq	$0x0, 0x8(%rax)
    25e5:      	movq	$0x0, (%rax)
    25ec:      	leaq	0x78(%rsp), %rdi
    25f1:      	movl	$0x8, %ecx
    25f6:      	movl	$0x4, %eax
    25fb:      	movq	0x18(%rsp), %rdx
    2600:      	movl	$0x8, %esi
    2605:      	callq	*%rax
    2607:      	testq	%rax, %rax
    260a:      	je	0x28fa <generic_rawtp_process_event+0x272a>
    2610:      	xorl	%ebp, %ebp
    2612:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    2617:      	movq	0x38(%rsp), %rax
    261c:      	movq	$0x0, 0x90(%r15,%rax)
    2628:      	movl	$0x8, %r12d
    262e:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    2633:      	movq	$-0x1, %r12
    263a:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    263f:      	movq	0x78(%rsp), %rcx
    2644:      	movl	$0x0, 0x68(%rsp)
    264c:      	movzwl	0x50(%rsp), %r15d
    2652:      	movq	(%rip), %rdi            # 0x2659 <generic_rawtp_process_event+0x2489>
    2659:      	leaq	0x68(%rsp), %rsi
    265e:      	movl	$0x1, %eax
    2663:      	movq	%rcx, 0x30(%rsp)
    2668:      	leaq	(%rcx,%r15), %r14
    266c:      	callq	*%rax
    266e:      	testq	%rax, %rax
    2671:      	je	0x3a5a <generic_rawtp_process_event+0x388a>
    2677:      	movq	%rax, %rbx
    267a:      	movw	%r15w, (%rax)
    267e:      	movb	$-0x1, 0x5(%rax)
    2682:      	movb	$0x0, 0x7(%rax)
    2686:      	movq	%rax, %r15
    2689:      	addq	$0x6, %r15
    268d:      	leaq	0x6(%r14), %rdx
    2691:      	movl	$0x1, %ecx
    2696:      	movl	$0x4, %eax
    269b:      	movq	%r15, %rdi
    269e:      	movl	$0x1, %esi
    26a3:      	callq	*%rax
    26a5:      	testq	%rax, %rax
    26a8:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    26ae:      	movzbl	0x5(%rbx), %eax
    26b2:      	cmpl	$0x32, %eax
    26b5:      	jg	0x3038 <generic_rawtp_process_event+0x2e68>
    26bb:      	testl	%eax, %eax
    26bd:      	je	0x30e0 <generic_rawtp_process_event+0x2f10>
    26c3:      	cmpl	$0x2b, %eax
    26c6:      	je	0x30e0 <generic_rawtp_process_event+0x2f10>
    26cc:      	cmpl	$0x2c, %eax
    26cf:      	jne	0x343c <generic_rawtp_process_event+0x326c>
    26d5:      	movw	$0x8, 0x2(%rbx)
    26db:      	movw	$0x8, %ax
    26df:      	jmp	0x337b <generic_rawtp_process_event+0x31ab>
    26e4:      	leaq	0x48(%r12), %rdx
    26e9:      	movl	$0x10, %ecx
    26ee:      	movl	$0x4, %eax
    26f3:      	movq	%rbp, %rdi
    26f6:      	movl	$0x10, %esi
    26fb:      	callq	*%rax
    26fd:      	leaq	0x38(%r12), %rdx
    2702:      	movl	$0x10, %ecx
    2707:      	movl	$0x4, %eax
    270c:      	movq	%r13, %rdi
    270f:      	movl	$0x10, %esi
    2714:      	callq	*%rax
    2716:      	leaq	0x20(%rbp), %rdi
    271a:      	leaq	0xc(%r12), %r13
    271f:      	addq	$0xe, %r12
    2723:      	movl	$0x2, %ecx
    2728:      	movl	$0x4, %eax
    272d:      	movl	$0x2, %esi
    2732:      	movq	%r12, %rdx
    2735:      	callq	*%rax
    2737:      	leaq	0x22(%rbp), %rdi
    273b:      	movl	$0x2, %ecx
    2740:      	movl	$0x4, %eax
    2745:      	movl	$0x2, %esi
    274a:      	movq	%r13, %rdx
    274d:      	callq	*%rax
    274f:      	movzwl	0x22(%rbp), %eax
    2753:      	movbew	%ax, 0x22(%rbp)
    2759:      	movq	0x60(%rsp), %rax
    275e:      	movq	%rax, 0x78(%rsp)
    2763:      	movq	(%rip), %rdi            # 0x276a <generic_rawtp_process_event+0x259a>
    276a:      	leaq	0x78(%rsp), %rsi
    276f:      	movl	$0x1, %eax
    2774:      	callq	*%rax
    2776:      	testq	%rax, %rax
    2779:      	je	0x3bf9 <generic_rawtp_process_event+0x3a29>
    277f:      	movl	(%rax), %ecx
    2781:      	movq	%r15, %rbp
    2784:      	movl	%ecx, 0x10(%r15)
    2788:      	movq	0x8(%rax), %rcx
    278c:      	movq	%rcx, 0x18(%r15)
    2790:      	movl	0x4(%rax), %eax
    2793:      	movl	%eax, 0x7c(%r15)
    2797:      	jmp	0x3bf9 <generic_rawtp_process_event+0x3a29>
    279c:      	movl	$0xe, %eax
    27a1:      	callq	*%rax
    27a3:      	cmpq	$-0x16, %rax
    27a7:      	jne	0x27cd <generic_rawtp_process_event+0x25fd>
    27a9:      	movq	0x8(%rsp), %rax
    27ae:      	leaq	0x20(%rax), %rdx
    27b2:      	leaq	0x78(%rsp), %rdi
    27b7:      	movl	$0x8, %ecx
    27bc:      	movl	$0x4, %eax
    27c1:      	movl	$0x8, %esi
    27c6:      	callq	*%rax
    27c8:      	movq	0x78(%rsp), %rax
    27cd:      	movq	0x48(%rsp), %rdx
    27d2:      	movq	0x8(%rdx), %rcx
    27d6:      	movq	0x60(%rdx), %rdx
    27da:      	movq	%rcx, 0x78(%rsp)
    27df:      	movq	0x18(%rsp), %rcx
    27e4:      	movq	%rcx, 0x80(%rsp)
    27ec:      	movq	$0x0, 0x88(%rsp)
    27f8:      	movq	%rdx, 0x68(%rsp)
    27fd:      	movq	%rax, 0x70(%rsp)
    2802:      	movq	(%rip), %rdi            # 0x2809 <generic_rawtp_process_event+0x2639>
    2809:      	xorl	%ecx, %ecx
    280b:      	leaq	0x68(%rsp), %rsi
    2810:      	leaq	0x78(%rsp), %rdx
    2815:      	movl	$0x2, %eax
    281a:      	xorl	%ecx, %ecx
    281c:      	callq	*%rax
    281e:      	testq	%rax, %rax
    2821:      	je	0x3091 <generic_rawtp_process_event+0x2ec1>
    2827:      	negl	%eax
    2829:      	movw	%ax, 0xc0(%rsp)
    2831:      	movw	$0x5, 0xc2(%rsp)
    283b:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2845:      	movq	%rax, 0xc4(%rsp)
    284d:      	movq	(%rip), %rdi            # 0x2854 <generic_rawtp_process_event+0x2684>
    2854:      	leaq	0xc0(%rsp), %rsi
    285c:      	movl	$0x1, %eax
    2861:      	callq	*%rax
    2863:      	testq	%rax, %rax
    2866:      	je	0x3064 <generic_rawtp_process_event+0x2e94>
    286c:      	incl	(%rax)
    286e:      	jmp	0x3091 <generic_rawtp_process_event+0x2ec1>
    2873:      	cmpl	$0x1, %eax
    2876:      	je	0x2b4d <generic_rawtp_process_event+0x297d>
    287c:      	cmpl	$0x2, %eax
    287f:      	jne	0x2f33 <generic_rawtp_process_event+0x2d63>
    2885:      	movq	0x48(%rsp), %rax
    288a:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2890:      	jmp	0x2b58 <generic_rawtp_process_event+0x2988>
    2895:      	movq	%rbp, %rbx
    2898:      	leaq	0x8(%rbp), %rdi
    289c:      	leaq	0x8(%r12), %rdx
    28a1:      	movl	$0x10, %ecx
    28a6:      	movl	$0x4, %eax
    28ab:      	movl	$0x10, %esi
    28b0:      	callq	*%rax
    28b2:      	leaq	0x2(%rbp), %rdi
    28b6:      	addq	$0x2, %r12
    28ba:      	movl	$0x2, %ecx
    28bf:      	movl	$0x4, %eax
    28c4:      	movl	$0x2, %esi
    28c9:      	movq	%r12, %rdx
    28cc:      	callq	*%rax
    28ce:      	movzwl	0x2(%rbp), %eax
    28d2:      	movbew	%ax, 0x2(%rbp)
    28d8:      	movl	$0x18, %r12d
    28de:      	movq	0x40(%rsp), %rax
    28e3:      	movq	0x20(%rsp), %rcx
    28e8:      	movl	$0x4, %esi
    28ed:      	movq	0x8(%rsp), %rbx
    28f2:      	movq	%r15, %r14
    28f5:      	jmp	0x12b1 <generic_rawtp_process_event+0x10e1>
    28fa:      	movq	0x38(%rsp), %rax
    28ff:      	leaq	0x10(%rax), %rdi
    2903:      	movq	0x78(%rsp), %rcx
    2908:      	movl	$0x3f, %edx
    290d:      	movl	$0x2d, %eax
    2912:      	movq	0x78(%rsp), %rdx
    2917:      	movl	$0x3f, %esi
    291c:      	callq	*%rax
    291e:      	testq	%rax, %rax
    2921:      	js	0x2610 <generic_rawtp_process_event+0x2440>
    2927:      	movq	0x18(%rsp), %rbx
    292c:      	leaq	0x8(%rbx), %rdx
    2930:      	leaq	0x68(%rsp), %rdi
    2935:      	movl	$0x8, %ecx
    293a:      	movl	$0x4, %eax
    293f:      	movl	$0x8, %esi
    2944:      	callq	*%rax
    2946:      	movq	0x38(%rsp), %rax
    294b:      	leaq	0x8(%rax), %rdi
    294f:      	movl	$0x348, %edx            # imm = 0x348
    2954:      	movq	0x68(%rsp), %rcx
    2959:      	addq	%rdx, %rcx
    295c:      	movl	$0x8, %esi
    2961:      	movl	$0x4, %eax
    2966:      	addq	0x68(%rsp), %rdx
    296b:      	movl	$0x8, %esi
    2970:      	callq	*%rax
    2972:      	addq	$0x58, %rbx
    2976:      	leaq	0x68(%rsp), %rdi
    297b:      	movl	$0x4, %ecx
    2980:      	movl	$0x4, %eax
    2985:      	movl	$0x4, %esi
    298a:      	movq	%rbx, %rdx
    298d:      	callq	*%rax
    298f:      	movl	$0x50, %ebp
    2994:      	testq	%rax, %rax
    2997:      	jne	0x3850 <generic_rawtp_process_event+0x3680>
    299d:      	xorl	%eax, %eax
    299f:      	cmpl	$0x0, 0x68(%rsp)
    29a4:      	setne	%al
    29a7:      	movq	0x38(%rsp), %rcx
    29ac:      	movl	%eax, (%rcx)
    29ae:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    29b3:      	addq	$0x90, %r15
    29ba:      	movq	0xb8(%rsp), %rax
    29c2:      	movl	$0x0, 0x4(%r15,%rax)
    29cb:      	addq	%r15, %rax
    29ce:      	addq	$0x8, %rax
    29d2:      	movq	%rax, 0x58(%rsp)
    29d7:      	movl	$0xc, %ebp
    29dc:      	movq	0x18(%rsp), %rax
    29e1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    29e7:      	movl	$0xfff, %r13d           # imm = 0xFFF
    29ed:      	cmovbq	%rax, %r13
    29f1:      	movq	0x58(%rsp), %rax
    29f6:      	leaq	0x8(%rax), %rdi
    29fa:      	movl	$0x4, %eax
    29ff:      	movq	0x48(%rsp), %rdx
    2a04:      	movl	%r13d, %esi
    2a07:      	callq	*%rax
    2a09:      	testl	%eax, %eax
    2a0b:      	js	0x2a28 <generic_rawtp_process_event+0x2858>
    2a0d:      	movq	0x58(%rsp), %rax
    2a12:      	movq	0x18(%rsp), %rcx
    2a17:      	movl	%ecx, (%rax)
    2a19:      	movl	%r13d, 0x4(%rax)
    2a1d:      	addq	%r13, %rbp
    2a20:      	movq	%rbp, %r12
    2a23:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    2a28:      	movq	0x58(%rsp), %rax
    2a2d:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    2a33:      	movq	0x40(%rsp), %rax
    2a38:      	movq	0x20(%rsp), %rcx
    2a3d:      	movl	$0x4, %esi
    2a42:      	movl	$0x4, %r12d
    2a48:      	jmp	0x12b1 <generic_rawtp_process_event+0x10e1>
    2a4d:      	cmpl	$0x1, %ecx
    2a50:      	je	0x3115 <generic_rawtp_process_event+0x2f45>
    2a56:      	cmpl	$0x2, %ecx
    2a59:      	jne	0x3123 <generic_rawtp_process_event+0x2f53>
    2a5f:      	movq	0x48(%rsp), %rax
    2a64:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2a6a:      	jmp	0x3120 <generic_rawtp_process_event+0x2f50>
    2a6f:      	leaq	0x48(%r12), %rdx
    2a74:      	movl	$0x10, %ecx
    2a79:      	movl	$0x4, %eax
    2a7e:      	movq	0x38(%rsp), %rdi
    2a83:      	movl	$0x10, %esi
    2a88:      	callq	*%rax
    2a8a:      	leaq	0x38(%r12), %rdx
    2a8f:      	movl	$0x10, %ecx
    2a94:      	movl	$0x4, %eax
    2a99:      	movq	%r13, %rdi
    2a9c:      	movl	$0x10, %esi
    2aa1:      	callq	*%rax
    2aa3:      	movq	0x38(%rsp), %rbx
    2aa8:      	leaq	0x20(%rbx), %rdi
    2aac:      	leaq	0xc(%r12), %r13
    2ab1:      	addq	$0xe, %r12
    2ab5:      	movl	$0x2, %ecx
    2aba:      	movl	$0x4, %eax
    2abf:      	movl	$0x2, %esi
    2ac4:      	movq	%r12, %rdx
    2ac7:      	callq	*%rax
    2ac9:      	leaq	0x22(%rbx), %rdi
    2acd:      	movl	$0x2, %ecx
    2ad2:      	movl	$0x4, %eax
    2ad7:      	movl	$0x2, %esi
    2adc:      	movq	%r13, %rdx
    2adf:      	callq	*%rax
    2ae1:      	movzwl	0x22(%rbx), %eax
    2ae5:      	movbew	%ax, 0x22(%rbx)
    2aeb:      	movq	0x38(%rsp), %rax
    2af0:      	movq	0x28(%rax), %rax
    2af4:      	movq	%rax, 0x78(%rsp)
    2af9:      	movq	(%rip), %rdi            # 0x2b00 <generic_rawtp_process_event+0x2930>
    2b00:      	leaq	0x78(%rsp), %rsi
    2b05:      	movl	$0x1, %eax
    2b0a:      	callq	*%rax
    2b0c:      	testq	%rax, %rax
    2b0f:      	je	0x2b29 <generic_rawtp_process_event+0x2959>
    2b11:      	movl	(%rax), %ecx
    2b13:      	movq	0x48(%rsp), %rdx
    2b18:      	movl	%ecx, 0x10(%rdx)
    2b1b:      	movq	0x8(%rax), %rcx
    2b1f:      	movq	%rcx, 0x18(%rdx)
    2b23:      	movl	0x4(%rax), %eax
    2b26:      	movl	%eax, 0x7c(%rdx)
    2b29:      	movl	$0x40, %ebp
    2b2e:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    2b33:      	movq	0x48(%rsp), %rax
    2b38:      	addq	$0x5e60, %rax           # imm = 0x5E60
    2b3e:      	jmp	0x2b58 <generic_rawtp_process_event+0x2988>
    2b40:      	movq	0x48(%rsp), %rax
    2b45:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2b4b:      	jmp	0x2b58 <generic_rawtp_process_event+0x2988>
    2b4d:      	movq	0x48(%rsp), %rax
    2b52:      	addq	$0x5e50, %rax           # imm = 0x5E50
    2b58:      	movq	(%rax), %r12
    2b5b:      	testb	$0x10, 0x58(%rsp)
    2b60:      	jne	0x2f47 <generic_rawtp_process_event+0x2d77>
    2b66:      	testq	%r12, %r12
    2b69:      	je	0x301a <generic_rawtp_process_event+0x2e4a>
    2b6f:      	leaq	0x78(%rsp), %rdi
    2b74:      	movl	$0x4, %ebp
    2b79:      	movl	$0x10, %ecx
    2b7e:      	movl	$0x4, %eax
    2b83:      	movq	0x18(%rsp), %rdx
    2b88:      	movl	$0x10, %esi
    2b8d:      	callq	*%rax
    2b8f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b94:      	testl	%eax, %eax
    2b96:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2b9c:      	movq	0x80(%rsp), %r14
    2ba4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2ba9:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    2bb0:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2bb6:      	movq	0xb8(%rsp), %rax
    2bbe:      	leaq	0xc(%rax), %r15
    2bc2:      	leaq	(%r15,%r13), %rdi
    2bc6:      	movq	0x78(%rsp), %rcx
    2bcb:      	movl	$0x4, %eax
    2bd0:      	movq	0x78(%rsp), %rdx
    2bd5:      	movl	%r14d, %esi
    2bd8:      	callq	*%rax
    2bda:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bdf:      	testl	%eax, %eax
    2be1:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2be7:      	cmpq	$0x1, %r12
    2beb:      	je	0x301d <generic_rawtp_process_event+0x2e4d>
    2bf1:      	movq	0x18(%rsp), %rax
    2bf6:      	leaq	0x10(%rax), %rdx
    2bfa:      	leaq	0x78(%rsp), %rdi
    2bff:      	movl	$0x4, %ebp
    2c04:      	movl	$0x10, %ecx
    2c09:      	movl	$0x4, %eax
    2c0e:      	movl	$0x10, %esi
    2c13:      	callq	*%rax
    2c15:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c1a:      	testl	%eax, %eax
    2c1c:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2c22:      	movq	0x80(%rsp), %rbx
    2c2a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c2f:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    2c36:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2c3c:      	addq	%r14, %r15
    2c3f:      	leaq	(%r15,%r13), %rdi
    2c43:      	movq	0x78(%rsp), %rcx
    2c48:      	movl	$0x4, %eax
    2c4d:      	movq	0x78(%rsp), %rdx
    2c52:      	movl	%ebx, %esi
    2c54:      	callq	*%rax
    2c56:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c5b:      	testl	%eax, %eax
    2c5d:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2c63:      	addq	%rbx, %r14
    2c66:      	cmpq	$0x3, %r12
    2c6a:      	jb	0x301d <generic_rawtp_process_event+0x2e4d>
    2c70:      	movq	0x18(%rsp), %rax
    2c75:      	leaq	0x20(%rax), %rdx
    2c79:      	leaq	0x78(%rsp), %rdi
    2c7e:      	movl	$0x4, %ebp
    2c83:      	movl	$0x10, %ecx
    2c88:      	movl	$0x4, %eax
    2c8d:      	movl	$0x10, %esi
    2c92:      	callq	*%rax
    2c94:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c99:      	testl	%eax, %eax
    2c9b:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2ca1:      	movq	0x80(%rsp), %rax
    2ca9:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2cae:      	movq	%rax, 0x30(%rsp)
    2cb3:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2cb9:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2cbf:      	addq	%r15, %rbx
    2cc2:      	movl	%ebx, %edi
    2cc4:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cca:      	addq	%r13, %rdi
    2ccd:      	movq	0x78(%rsp), %rcx
    2cd2:      	movl	$0x4, %eax
    2cd7:      	movq	0x30(%rsp), %rsi
    2cdc:      	movq	0x78(%rsp), %rdx
    2ce1:      	callq	*%rax
    2ce3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ce8:      	testl	%eax, %eax
    2cea:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2cf0:      	addq	0x30(%rsp), %r14
    2cf5:      	cmpq	$0x3, %r12
    2cf9:      	je	0x301d <generic_rawtp_process_event+0x2e4d>
    2cff:      	movq	0x18(%rsp), %rax
    2d04:      	leaq	0x30(%rax), %rdx
    2d08:      	leaq	0x78(%rsp), %rdi
    2d0d:      	movl	$0x4, %ebp
    2d12:      	movl	$0x10, %ecx
    2d17:      	movl	$0x4, %eax
    2d1c:      	movl	$0x10, %esi
    2d21:      	callq	*%rax
    2d23:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d28:      	testl	%eax, %eax
    2d2a:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2d30:      	movq	0x80(%rsp), %rax
    2d38:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d3d:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2d43:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2d49:      	movq	%rax, %r15
    2d4c:      	movq	0x30(%rsp), %rdi
    2d51:      	addq	%rbx, %rdi
    2d54:      	movq	%rdi, %rbx
    2d57:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d5d:      	addq	%r13, %rdi
    2d60:      	movq	0x78(%rsp), %rcx
    2d65:      	movl	$0x4, %eax
    2d6a:      	movq	%r15, %rsi
    2d6d:      	movq	0x78(%rsp), %rdx
    2d72:      	callq	*%rax
    2d74:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d79:      	testl	%eax, %eax
    2d7b:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2d81:      	addq	%r15, %r14
    2d84:      	cmpq	$0x5, %r12
    2d88:      	jb	0x301d <generic_rawtp_process_event+0x2e4d>
    2d8e:      	movq	0x18(%rsp), %rax
    2d93:      	leaq	0x40(%rax), %rdx
    2d97:      	leaq	0x78(%rsp), %rdi
    2d9c:      	movl	$0x4, %ebp
    2da1:      	movl	$0x10, %ecx
    2da6:      	movl	$0x4, %eax
    2dab:      	movl	$0x10, %esi
    2db0:      	callq	*%rax
    2db2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2db7:      	testl	%eax, %eax
    2db9:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2dbf:      	movq	0x80(%rsp), %rax
    2dc7:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2dcc:      	movq	%rax, 0x30(%rsp)
    2dd1:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2dd7:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2ddd:      	movq	%r15, %rdi
    2de0:      	addq	%rbx, %rdi
    2de3:      	movq	%rdi, %r15
    2de6:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2dec:      	addq	%r13, %rdi
    2def:      	movq	0x78(%rsp), %rcx
    2df4:      	movl	$0x4, %eax
    2df9:      	movq	0x30(%rsp), %rsi
    2dfe:      	movq	0x78(%rsp), %rdx
    2e03:      	callq	*%rax
    2e05:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e0a:      	testl	%eax, %eax
    2e0c:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2e12:      	addq	0x30(%rsp), %r14
    2e17:      	cmpq	$0x5, %r12
    2e1b:      	je	0x301d <generic_rawtp_process_event+0x2e4d>
    2e21:      	movq	0x18(%rsp), %rax
    2e26:      	leaq	0x50(%rax), %rdx
    2e2a:      	leaq	0x78(%rsp), %rdi
    2e2f:      	movl	$0x4, %ebp
    2e34:      	movl	$0x10, %ecx
    2e39:      	movl	$0x4, %eax
    2e3e:      	movl	$0x10, %esi
    2e43:      	callq	*%rax
    2e45:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e4a:      	testl	%eax, %eax
    2e4c:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2e52:      	movq	0x80(%rsp), %rbx
    2e5a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2e5f:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    2e66:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2e6c:      	movq	0x30(%rsp), %rdi
    2e71:      	addq	%r15, %rdi
    2e74:      	movq	%rdi, %r15
    2e77:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2e7d:      	addq	%r13, %rdi
    2e80:      	movq	0x78(%rsp), %rcx
    2e85:      	movl	$0x4, %eax
    2e8a:      	movq	0x78(%rsp), %rdx
    2e8f:      	movl	%ebx, %esi
    2e91:      	callq	*%rax
    2e93:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e98:      	testl	%eax, %eax
    2e9a:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2ea0:      	addq	%rbx, %r14
    2ea3:      	cmpq	$0x7, %r12
    2ea7:      	jb	0x301d <generic_rawtp_process_event+0x2e4d>
    2ead:      	movq	0x18(%rsp), %rdx
    2eb2:      	addq	$0x60, %rdx
    2eb6:      	leaq	0x78(%rsp), %rdi
    2ebb:      	movl	$0x4, %ebp
    2ec0:      	movl	$0x10, %ecx
    2ec5:      	movl	$0x4, %eax
    2eca:      	movl	$0x10, %esi
    2ecf:      	callq	*%rax
    2ed1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ed6:      	testl	%eax, %eax
    2ed8:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2eda:      	movq	0x80(%rsp), %r12
    2ee2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2ee7:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2eee:      	ja	0x2f24 <generic_rawtp_process_event+0x2d54>
    2ef0:      	addq	%r15, %rbx
    2ef3:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
    2ef9:      	addq	%r13, %rbx
    2efc:      	movq	0x78(%rsp), %rcx
    2f01:      	movl	$0x4, %eax
    2f06:      	movq	0x78(%rsp), %rdx
    2f0b:      	movq	%rbx, %rdi
    2f0e:      	movl	%r12d, %esi
    2f11:      	callq	*%rax
    2f13:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f18:      	testl	%eax, %eax
    2f1a:      	js	0x2f24 <generic_rawtp_process_event+0x2d54>
    2f1c:      	addq	%r12, %r14
    2f1f:      	jmp	0x301d <generic_rawtp_process_event+0x2e4d>
    2f24:      	movq	0x38(%rsp), %rax
    2f29:      	movl	%ecx, (%r13,%rax)
    2f2e:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    2f33:      	xorl	%r12d, %r12d
    2f36:      	movl	$0x0, %r14d
    2f3c:      	testb	$0x10, 0x58(%rsp)
    2f41:      	je	0x301d <generic_rawtp_process_event+0x2e4d>
    2f47:      	movl	$0xe, %eax
    2f4c:      	callq	*%rax
    2f4e:      	cmpq	$-0x16, %rax
    2f52:      	jne	0x2f78 <generic_rawtp_process_event+0x2da8>
    2f54:      	movq	0x8(%rsp), %rax
    2f59:      	leaq	0x20(%rax), %rdx
    2f5d:      	leaq	0x78(%rsp), %rdi
    2f62:      	movl	$0x8, %ecx
    2f67:      	movl	$0x4, %eax
    2f6c:      	movl	$0x8, %esi
    2f71:      	callq	*%rax
    2f73:      	movq	0x78(%rsp), %rax
    2f78:      	movq	0x48(%rsp), %rdx
    2f7d:      	movq	0x8(%rdx), %rcx
    2f81:      	movq	0x60(%rdx), %rdx
    2f85:      	movq	%rcx, 0x78(%rsp)
    2f8a:      	movq	0x18(%rsp), %rcx
    2f8f:      	movq	%rcx, 0x80(%rsp)
    2f97:      	movq	%r12, 0x88(%rsp)
    2f9f:      	movq	%rdx, 0x68(%rsp)
    2fa4:      	movq	%rax, 0x70(%rsp)
    2fa9:      	movq	(%rip), %rdi            # 0x2fb0 <generic_rawtp_process_event+0x2de0>
    2fb0:      	xorl	%ecx, %ecx
    2fb2:      	leaq	0x68(%rsp), %rsi
    2fb7:      	leaq	0x78(%rsp), %rdx
    2fbc:      	movl	$0x2, %eax
    2fc1:      	xorl	%ecx, %ecx
    2fc3:      	callq	*%rax
    2fc5:      	testq	%rax, %rax
    2fc8:      	je	0x30c8 <generic_rawtp_process_event+0x2ef8>
    2fce:      	negl	%eax
    2fd0:      	movw	%ax, 0xc0(%rsp)
    2fd8:      	movw	$0x5, 0xc2(%rsp)
    2fe2:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    2fec:      	movq	%rax, 0xc4(%rsp)
    2ff4:      	movq	(%rip), %rdi            # 0x2ffb <generic_rawtp_process_event+0x2e2b>
    2ffb:      	leaq	0xc0(%rsp), %rsi
    3003:      	movl	$0x1, %eax
    3008:      	callq	*%rax
    300a:      	testq	%rax, %rax
    300d:      	je	0x30a1 <generic_rawtp_process_event+0x2ed1>
    3013:      	incl	(%rax)
    3015:      	jmp	0x30c8 <generic_rawtp_process_event+0x2ef8>
    301a:      	xorl	%r14d, %r14d
    301d:      	movq	0x38(%rsp), %rax
    3022:      	movl	%r14d, (%r13,%rax)
    3027:      	movl	%r14d, 0x4(%r13,%rax)
    302c:      	addq	$0x8, %r14
    3030:      	movq	%r14, %rbp
    3033:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    3038:      	cmpl	$0x33, %eax
    303b:      	je	0x336c <generic_rawtp_process_event+0x319c>
    3041:      	cmpl	$0x3c, %eax
    3044:      	je	0x30e0 <generic_rawtp_process_event+0x2f10>
    304a:      	cmpl	$0xff, %eax
    304f:      	jne	0x343c <generic_rawtp_process_event+0x326c>
    3055:      	movw	$0x28, 0x2(%rbx)
    305b:      	movw	$0x28, %ax
    305f:      	jmp	0x337b <generic_rawtp_process_event+0x31ab>
    3064:      	movl	$0x1, 0xd0(%rsp)
    306f:      	movq	(%rip), %rdi            # 0x3076 <generic_rawtp_process_event+0x2ea6>
    3076:      	xorl	%ecx, %ecx
    3078:      	leaq	0xc0(%rsp), %rsi
    3080:      	leaq	0xd0(%rsp), %rdx
    3088:      	movl	$0x2, %eax
    308d:      	xorl	%ecx, %ecx
    308f:      	callq	*%rax
    3091:      	movl	$0xfffffffc, (%rbx)     # imm = 0xFFFFFFFC
    3097:      	movl	$0x4, %ebp
    309c:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    30a1:      	movl	$0x1, 0x50(%rsp)
    30a9:      	movq	(%rip), %rdi            # 0x30b0 <generic_rawtp_process_event+0x2ee0>
    30b0:      	xorl	%ecx, %ecx
    30b2:      	leaq	0xc0(%rsp), %rsi
    30ba:      	leaq	0x50(%rsp), %rdx
    30bf:      	movl	$0x2, %eax
    30c4:      	xorl	%ecx, %ecx
    30c6:      	callq	*%rax
    30c8:      	movq	0x38(%rsp), %rax
    30cd:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    30d6:      	movl	$0x4, %ebp
    30db:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    30e0:      	movzbl	0x7(%rbx), %eax
    30e4:      	leal	0x8(,%rax,8), %eax
    30eb:      	jmp	0x3377 <generic_rawtp_process_event+0x31a7>
    30f0:      	movl	$0x4, %r12d
    30f6:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    30fb:      	movq	0x48(%rsp), %rax
    3100:      	addq	$0x5e60, %rax           # imm = 0x5E60
    3106:      	jmp	0x3120 <generic_rawtp_process_event+0x2f50>
    3108:      	movq	0x48(%rsp), %rax
    310d:      	addq	$0x5e68, %rax           # imm = 0x5E68
    3113:      	jmp	0x3120 <generic_rawtp_process_event+0x2f50>
    3115:      	movq	0x48(%rsp), %rax
    311a:      	addq	$0x5e50, %rax           # imm = 0x5E50
    3120:      	movq	(%rax), %rax
    3123:      	movq	%rax, 0x50(%rsp)
    3128:      	leaq	0x60(%rsp), %rdi
    312d:      	leaq	0x50(%rsp), %rdx
    3132:      	movl	$0x8, %ecx
    3137:      	movl	$0x4, %eax
    313c:      	movl	$0x8, %ebp
    3141:      	movl	$0x8, %esi
    3146:      	callq	*%rax
    3148:      	movq	0x60(%rsp), %r14
    314d:      	testb	$0x20, %r15b
    3151:      	je	0x32b8 <generic_rawtp_process_event+0x30e8>
    3157:      	cmpq	$0x1000, %r14           # imm = 0x1000
    315e:      	jb	0x328f <generic_rawtp_process_event+0x30bf>
    3164:      	movl	$0x1, (%rbx)
    316a:      	movl	$0x0, 0x68(%rsp)
    3172:      	movq	(%rip), %rdi            # 0x3179 <generic_rawtp_process_event+0x2fa9>
    3179:      	leaq	0x68(%rsp), %rsi
    317e:      	movl	$0x1, %eax
    3183:      	callq	*%rax
    3185:      	movq	%rax, 0x30(%rsp)
    318a:      	testq	%rax, %rax
    318d:      	je	0x32f5 <generic_rawtp_process_event+0x3125>
    3193:      	movq	0x30(%rsp), %r12
    3198:      	movl	$0x18, (%r12)
    31a0:      	movl	$0xe, %eax
    31a5:      	callq	*%rax
    31a7:      	leaq	0x10(%r12), %r15
    31ac:      	movq	%rax, 0x10(%r12)
    31b1:      	cmpq	$-0x16, %rax
    31b5:      	jne	0x31de <generic_rawtp_process_event+0x300e>
    31b7:      	movq	0x8(%rsp), %rax
    31bc:      	leaq	0x20(%rax), %rdx
    31c0:      	leaq	0x78(%rsp), %rdi
    31c5:      	movl	$0x8, %ecx
    31ca:      	movl	$0x4, %eax
    31cf:      	movl	$0x8, %esi
    31d4:      	callq	*%rax
    31d6:      	movq	0x78(%rsp), %rax
    31db:      	movq	%rax, (%r15)
    31de:      	movl	$0x7d, %eax
    31e3:      	callq	*%rax
    31e5:      	movq	0x30(%rsp), %r13
    31ea:      	movq	%rax, 0x18(%r13)
    31ee:      	movq	(%r15), %rax
    31f1:      	movq	0x8(%r15), %rcx
    31f5:      	movq	%rax, 0x14(%rbx)
    31f9:      	movq	%rcx, 0x1c(%rbx)
    31fd:      	addq	$0x20, %r13
    3201:      	movl	$0xa, %r15d
    3207:      	xorl	%r12d, %r12d
    320a:      	movq	%r14, %rbp
    320d:      	subq	%r12, %rbp
    3210:      	js	0x346e <generic_rawtp_process_event+0x329e>
    3216:      	movq	0x18(%rsp), %rax
    321b:      	leaq	(%r12,%rax), %rdx
    321f:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    3226:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    322b:      	cmovaeq	%rax, %rbp
    322f:      	movl	$0x4, %eax
    3234:      	movq	%r13, %rdi
    3237:      	movl	%ebp, %esi
    3239:      	callq	*%rax
    323b:      	testl	%eax, %eax
    323d:      	js	0x3268 <generic_rawtp_process_event+0x3098>
    323f:      	leal	0x20(%rbp), %r8d
    3243:      	movq	0x30(%rsp), %rcx
    3248:      	movl	%r8d, 0x4(%rcx)
    324c:      	movl	$0x19, %eax
    3251:      	movq	0x8(%rsp), %rdi
    3256:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    325b:      	movq	(%rip), %rsi            # 0x3262 <generic_rawtp_process_event+0x3092>
    3262:      	callq	*%rax
    3264:      	testl	%eax, %eax
    3266:      	jns	0x326b <generic_rawtp_process_event+0x309b>
    3268:      	movslq	%eax, %rbp
    326b:      	testl	%ebp, %ebp
    326d:      	js	0x3477 <generic_rawtp_process_event+0x32a7>
    3273:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    3279:      	addq	%rbp, %r12
    327c:      	cmpq	%r14, %r12
    327f:      	je	0x34d1 <generic_rawtp_process_event+0x3301>
    3285:      	decl	%r15d
    3288:      	jne	0x320a <generic_rawtp_process_event+0x303a>
    328a:      	jmp	0x3816 <generic_rawtp_process_event+0x3646>
    328f:      	movq	0x48(%rsp), %rcx
    3294:      	addq	$0x90, %rcx
    329b:      	movq	0xb8(%rsp), %rax
    32a3:      	movl	$0x0, 0x4(%rcx,%rax)
    32ab:      	leaq	(%rcx,%rax), %rbx
    32af:      	addq	$0x8, %rbx
    32b3:      	movl	$0xc, %ebp
    32b8:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    32bf:      	movl	$0xfff, %r13d           # imm = 0xFFF
    32c5:      	cmovbq	%r14, %r13
    32c9:      	leaq	0x8(%rbx), %rdi
    32cd:      	movl	$0x4, %eax
    32d2:      	movq	0x18(%rsp), %rdx
    32d7:      	movl	%r13d, %esi
    32da:      	callq	*%rax
    32dc:      	testl	%eax, %eax
    32de:      	js	0x32ef <generic_rawtp_process_event+0x311f>
    32e0:      	movl	%r14d, (%rbx)
    32e3:      	movl	%r13d, 0x4(%rbx)
    32e7:      	addq	%r13, %rbp
    32ea:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    32ef:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    32f5:      	movl	$0x4, %ebp
    32fa:      	jmp	0x3850 <generic_rawtp_process_event+0x3680>
    32ff:      	movq	$-0x1, %r12
    3306:      	jmp	0x330b <generic_rawtp_process_event+0x313b>
    3308:      	movq	%r13, %r12
    330b:      	movl	$0x0, 0x78(%rsp)
    3313:      	movq	(%rip), %rdi            # 0x331a <generic_rawtp_process_event+0x314a>
    331a:      	leaq	0x78(%rsp), %rsi
    331f:      	movl	$0x1, %eax
    3324:      	callq	*%rax
    3326:      	testq	%rax, %rax
    3329:      	je	0x36c3 <generic_rawtp_process_event+0x34f3>
    332f:      	cmpq	$-0xc, %r12
    3333:      	jg	0x3445 <generic_rawtp_process_event+0x3275>
    3339:      	cmpq	$-0x1c, %r12
    333d:      	je	0x3699 <generic_rawtp_process_event+0x34c9>
    3343:      	cmpq	$-0x16, %r12
    3347:      	je	0x36b1 <generic_rawtp_process_event+0x34e1>
    334d:      	cmpq	$-0x10, %r12
    3351:      	jne	0x36a9 <generic_rawtp_process_event+0x34d9>
    3357:      	addq	$0x558, %rax            # imm = 0x558
    335d:      	jmp	0x36bf <generic_rawtp_process_event+0x34ef>
    3362:      	movq	0x18(%rsp), %r12
    3367:      	jmp	0x36c3 <generic_rawtp_process_event+0x34f3>
    336c:      	movzbl	0x7(%rbx), %eax
    3370:      	leal	0x8(,%rax,4), %eax
    3377:      	movw	%ax, 0x2(%rbx)
    337b:      	addw	(%rbx), %ax
    337e:      	movw	%ax, (%rbx)
    3381:      	movzbl	0x6(%rbx), %r12d
    3386:      	cmpq	$0x3c, %r12
    338a:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3390:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    339a:      	btq	%r12, %rcx
    339e:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    33a4:      	movb	%r12b, 0x5(%rbx)
    33a8:      	movzwl	%ax, %ecx
    33ab:      	movq	0x30(%rsp), %rsi
    33b0:      	addq	%rsi, %rcx
    33b3:      	movl	$0x2, %edx
    33b8:      	movl	$0x4, %eax
    33bd:      	movzwl	(%rbx), %edx
    33c0:      	addq	%rsi, %rdx
    33c3:      	movq	%r15, %rdi
    33c6:      	movl	$0x2, %esi
    33cb:      	callq	*%rax
    33cd:      	testq	%rax, %rax
    33d0:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    33d6:      	movzbl	0x5(%rbx), %eax
    33da:      	cmpl	$0x32, %eax
    33dd:      	jg	0x3400 <generic_rawtp_process_event+0x3230>
    33df:      	testl	%eax, %eax
    33e1:      	je	0x3428 <generic_rawtp_process_event+0x3258>
    33e3:      	cmpl	$0x2b, %eax
    33e6:      	je	0x3428 <generic_rawtp_process_event+0x3258>
    33e8:      	cmpl	$0x2c, %eax
    33eb:      	jne	0x34ea <generic_rawtp_process_event+0x331a>
    33f1:      	movw	$0x8, 0x2(%rbx)
    33f7:      	movw	$0x8, %ax
    33fb:      	jmp	0x34ee <generic_rawtp_process_event+0x331e>
    3400:      	cmpl	$0x33, %eax
    3403:      	je	0x34d9 <generic_rawtp_process_event+0x3309>
    3409:      	cmpl	$0x3c, %eax
    340c:      	je	0x3428 <generic_rawtp_process_event+0x3258>
    340e:      	cmpl	$0xff, %eax
    3413:      	jne	0x34ea <generic_rawtp_process_event+0x331a>
    3419:      	movw	$0x28, 0x2(%rbx)
    341f:      	movw	$0x28, %ax
    3423:      	jmp	0x34ee <generic_rawtp_process_event+0x331e>
    3428:      	movzbl	0x7(%rbx), %eax
    342c:      	leal	0x8(,%rax,8), %eax
    3433:      	movw	%ax, 0x2(%rbx)
    3437:      	jmp	0x34ee <generic_rawtp_process_event+0x331e>
    343c:      	movzwl	0x2(%rbx), %eax
    3440:      	jmp	0x337b <generic_rawtp_process_event+0x31ab>
    3445:      	cmpq	$-0xb, %r12
    3449:      	je	0x36a1 <generic_rawtp_process_event+0x34d1>
    344f:      	cmpq	$-0x7, %r12
    3453:      	je	0x36b9 <generic_rawtp_process_event+0x34e9>
    3459:      	cmpq	$-0x2, %r12
    345d:      	jne	0x36a9 <generic_rawtp_process_event+0x34d9>
    3463:      	addq	$0x548, %rax            # imm = 0x548
    3469:      	jmp	0x36bf <generic_rawtp_process_event+0x34ef>
    346e:      	movq	$-0x1, %r12
    3475:      	jmp	0x347a <generic_rawtp_process_event+0x32aa>
    3477:      	movq	%rbp, %r12
    347a:      	movl	$0x0, 0x78(%rsp)
    3482:      	movq	(%rip), %rdi            # 0x3489 <generic_rawtp_process_event+0x32b9>
    3489:      	leaq	0x78(%rsp), %rsi
    348e:      	movl	$0x1, %eax
    3493:      	callq	*%rax
    3495:      	testq	%rax, %rax
    3498:      	je	0x3816 <generic_rawtp_process_event+0x3646>
    349e:      	cmpq	$-0xc, %r12
    34a2:      	jg	0x359a <generic_rawtp_process_event+0x33ca>
    34a8:      	cmpq	$-0x1c, %r12
    34ac:      	je	0x37ec <generic_rawtp_process_event+0x361c>
    34b2:      	cmpq	$-0x16, %r12
    34b6:      	je	0x37fc <generic_rawtp_process_event+0x362c>
    34bc:      	cmpq	$-0x10, %r12
    34c0:      	jne	0x380c <generic_rawtp_process_event+0x363c>
    34c6:      	addq	$0x558, %rax            # imm = 0x558
    34cc:      	jmp	0x3812 <generic_rawtp_process_event+0x3642>
    34d1:      	movq	%r14, %r12
    34d4:      	jmp	0x3816 <generic_rawtp_process_event+0x3646>
    34d9:      	movzbl	0x7(%rbx), %eax
    34dd:      	leal	0x8(,%rax,4), %eax
    34e4:      	movw	%ax, 0x2(%rbx)
    34e8:      	jmp	0x34ee <generic_rawtp_process_event+0x331e>
    34ea:      	movzwl	0x2(%rbx), %eax
    34ee:      	addw	(%rbx), %ax
    34f1:      	movw	%ax, (%rbx)
    34f4:      	movzbl	0x6(%rbx), %r12d
    34f9:      	cmpq	$0x3c, %r12
    34fd:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3503:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    350d:      	btq	%r12, %rcx
    3511:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3517:      	movb	%r12b, 0x5(%rbx)
    351b:      	movzwl	%ax, %ecx
    351e:      	movq	0x30(%rsp), %rsi
    3523:      	addq	%rsi, %rcx
    3526:      	movl	$0x2, %edx
    352b:      	movl	$0x4, %eax
    3530:      	movzwl	(%rbx), %edx
    3533:      	addq	%rsi, %rdx
    3536:      	movq	%r15, %rdi
    3539:      	movl	$0x2, %esi
    353e:      	callq	*%rax
    3540:      	testq	%rax, %rax
    3543:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    3549:      	movzbl	0x5(%rbx), %eax
    354d:      	cmpl	$0x32, %eax
    3550:      	jg	0x356c <generic_rawtp_process_event+0x339c>
    3552:      	testl	%eax, %eax
    3554:      	je	0x3589 <generic_rawtp_process_event+0x33b9>
    3556:      	cmpl	$0x2b, %eax
    3559:      	je	0x3589 <generic_rawtp_process_event+0x33b9>
    355b:      	cmpl	$0x2c, %eax
    355e:      	jne	0x35d4 <generic_rawtp_process_event+0x3404>
    3560:      	movw	$0x8, 0x2(%rbx)
    3566:      	movw	$0x8, %ax
    356a:      	jmp	0x35d8 <generic_rawtp_process_event+0x3408>
    356c:      	cmpl	$0x33, %eax
    356f:      	je	0x35c3 <generic_rawtp_process_event+0x33f3>
    3571:      	cmpl	$0x3c, %eax
    3574:      	je	0x3589 <generic_rawtp_process_event+0x33b9>
    3576:      	cmpl	$0xff, %eax
    357b:      	jne	0x35d4 <generic_rawtp_process_event+0x3404>
    357d:      	movw	$0x28, 0x2(%rbx)
    3583:      	movw	$0x28, %ax
    3587:      	jmp	0x35d8 <generic_rawtp_process_event+0x3408>
    3589:      	movzbl	0x7(%rbx), %eax
    358d:      	leal	0x8(,%rax,8), %eax
    3594:      	movw	%ax, 0x2(%rbx)
    3598:      	jmp	0x35d8 <generic_rawtp_process_event+0x3408>
    359a:      	cmpq	$-0xb, %r12
    359e:      	je	0x37f4 <generic_rawtp_process_event+0x3624>
    35a4:      	cmpq	$-0x7, %r12
    35a8:      	je	0x3804 <generic_rawtp_process_event+0x3634>
    35ae:      	cmpq	$-0x2, %r12
    35b2:      	jne	0x380c <generic_rawtp_process_event+0x363c>
    35b8:      	addq	$0x548, %rax            # imm = 0x548
    35be:      	jmp	0x3812 <generic_rawtp_process_event+0x3642>
    35c3:      	movzbl	0x7(%rbx), %eax
    35c7:      	leal	0x8(,%rax,4), %eax
    35ce:      	movw	%ax, 0x2(%rbx)
    35d2:      	jmp	0x35d8 <generic_rawtp_process_event+0x3408>
    35d4:      	movzwl	0x2(%rbx), %eax
    35d8:      	addw	(%rbx), %ax
    35db:      	movw	%ax, (%rbx)
    35de:      	movzbl	0x6(%rbx), %r12d
    35e3:      	cmpq	$0x3c, %r12
    35e7:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    35ed:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    35f7:      	btq	%r12, %rcx
    35fb:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3601:      	movb	%r12b, 0x5(%rbx)
    3605:      	movzwl	%ax, %ecx
    3608:      	movq	0x30(%rsp), %rsi
    360d:      	addq	%rsi, %rcx
    3610:      	movl	$0x2, %edx
    3615:      	movl	$0x4, %eax
    361a:      	movzwl	(%rbx), %edx
    361d:      	addq	%rsi, %rdx
    3620:      	movq	%r15, %rdi
    3623:      	movl	$0x2, %esi
    3628:      	callq	*%rax
    362a:      	testq	%rax, %rax
    362d:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    3633:      	movzbl	0x5(%rbx), %eax
    3637:      	cmpl	$0x32, %eax
    363a:      	jg	0x365d <generic_rawtp_process_event+0x348d>
    363c:      	testl	%eax, %eax
    363e:      	je	0x3685 <generic_rawtp_process_event+0x34b5>
    3640:      	cmpl	$0x2b, %eax
    3643:      	je	0x3685 <generic_rawtp_process_event+0x34b5>
    3645:      	cmpl	$0x2c, %eax
    3648:      	jne	0x3727 <generic_rawtp_process_event+0x3557>
    364e:      	movw	$0x8, 0x2(%rbx)
    3654:      	movw	$0x8, %ax
    3658:      	jmp	0x372b <generic_rawtp_process_event+0x355b>
    365d:      	cmpl	$0x33, %eax
    3660:      	je	0x3716 <generic_rawtp_process_event+0x3546>
    3666:      	cmpl	$0x3c, %eax
    3669:      	je	0x3685 <generic_rawtp_process_event+0x34b5>
    366b:      	cmpl	$0xff, %eax
    3670:      	jne	0x3727 <generic_rawtp_process_event+0x3557>
    3676:      	movw	$0x28, 0x2(%rbx)
    367c:      	movw	$0x28, %ax
    3680:      	jmp	0x372b <generic_rawtp_process_event+0x355b>
    3685:      	movzbl	0x7(%rbx), %eax
    3689:      	leal	0x8(,%rax,8), %eax
    3690:      	movw	%ax, 0x2(%rbx)
    3694:      	jmp	0x372b <generic_rawtp_process_event+0x355b>
    3699:      	addq	$0x568, %rax            # imm = 0x568
    369f:      	jmp	0x36bf <generic_rawtp_process_event+0x34ef>
    36a1:      	addq	$0x570, %rax            # imm = 0x570
    36a7:      	jmp	0x36bf <generic_rawtp_process_event+0x34ef>
    36a9:      	addq	$0x540, %rax            # imm = 0x540
    36af:      	jmp	0x36bf <generic_rawtp_process_event+0x34ef>
    36b1:      	addq	$0x560, %rax            # imm = 0x560
    36b7:      	jmp	0x36bf <generic_rawtp_process_event+0x34ef>
    36b9:      	addq	$0x550, %rax            # imm = 0x550
    36bf:      	lock
    36c0:      	incq	(%rax)
    36c3:      	testl	%r12d, %r12d
    36c6:      	js	0x36ea <generic_rawtp_process_event+0x351a>
    36c8:      	movq	0x58(%rsp), %rax
    36cd:      	movq	$0x0, 0x4(%rax)
    36d5:      	movq	0x18(%rsp), %rdx
    36da:      	movl	%edx, %ecx
    36dc:      	subl	%r12d, %ecx
    36df:      	xorl	%eax, %eax
    36e1:      	cmpq	$-0x1, %rdx
    36e5:      	cmovnel	%ecx, %eax
    36e8:      	jmp	0x36ff <generic_rawtp_process_event+0x352f>
    36ea:      	movq	0x58(%rsp), %rax
    36ef:      	movl	%r12d, 0x4(%rax)
    36f3:      	movl	$0x0, 0x8(%rax)
    36fa:      	xorl	%eax, %eax
    36fc:      	xorl	%r12d, %r12d
    36ff:      	movq	0x58(%rsp), %rcx
    3704:      	movl	%eax, 0xc(%rcx)
    3707:      	movl	%r12d, 0x10(%rcx)
    370b:      	movl	$0x24, %r12d
    3711:      	jmp	0x12a2 <generic_rawtp_process_event+0x10d2>
    3716:      	movzbl	0x7(%rbx), %eax
    371a:      	leal	0x8(,%rax,4), %eax
    3721:      	movw	%ax, 0x2(%rbx)
    3725:      	jmp	0x372b <generic_rawtp_process_event+0x355b>
    3727:      	movzwl	0x2(%rbx), %eax
    372b:      	addw	(%rbx), %ax
    372e:      	movw	%ax, (%rbx)
    3731:      	movzbl	0x6(%rbx), %r12d
    3736:      	cmpq	$0x3c, %r12
    373a:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3740:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    374a:      	btq	%r12, %rcx
    374e:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3754:      	movb	%r12b, 0x5(%rbx)
    3758:      	movzwl	%ax, %ecx
    375b:      	movq	0x30(%rsp), %rsi
    3760:      	addq	%rsi, %rcx
    3763:      	movl	$0x2, %edx
    3768:      	movl	$0x4, %eax
    376d:      	movzwl	(%rbx), %edx
    3770:      	addq	%rsi, %rdx
    3773:      	movq	%r15, %rdi
    3776:      	movl	$0x2, %esi
    377b:      	callq	*%rax
    377d:      	testq	%rax, %rax
    3780:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    3786:      	movzbl	0x5(%rbx), %eax
    378a:      	cmpl	$0x32, %eax
    378d:      	jg	0x37b0 <generic_rawtp_process_event+0x35e0>
    378f:      	testl	%eax, %eax
    3791:      	je	0x37d8 <generic_rawtp_process_event+0x3608>
    3793:      	cmpl	$0x2b, %eax
    3796:      	je	0x37d8 <generic_rawtp_process_event+0x3608>
    3798:      	cmpl	$0x2c, %eax
    379b:      	jne	0x3882 <generic_rawtp_process_event+0x36b2>
    37a1:      	movw	$0x8, 0x2(%rbx)
    37a7:      	movw	$0x8, %ax
    37ab:      	jmp	0x3886 <generic_rawtp_process_event+0x36b6>
    37b0:      	cmpl	$0x33, %eax
    37b3:      	je	0x3871 <generic_rawtp_process_event+0x36a1>
    37b9:      	cmpl	$0x3c, %eax
    37bc:      	je	0x37d8 <generic_rawtp_process_event+0x3608>
    37be:      	cmpl	$0xff, %eax
    37c3:      	jne	0x3882 <generic_rawtp_process_event+0x36b2>
    37c9:      	movw	$0x28, 0x2(%rbx)
    37cf:      	movw	$0x28, %ax
    37d3:      	jmp	0x3886 <generic_rawtp_process_event+0x36b6>
    37d8:      	movzbl	0x7(%rbx), %eax
    37dc:      	leal	0x8(,%rax,8), %eax
    37e3:      	movw	%ax, 0x2(%rbx)
    37e7:      	jmp	0x3886 <generic_rawtp_process_event+0x36b6>
    37ec:      	addq	$0x568, %rax            # imm = 0x568
    37f2:      	jmp	0x3812 <generic_rawtp_process_event+0x3642>
    37f4:      	addq	$0x570, %rax            # imm = 0x570
    37fa:      	jmp	0x3812 <generic_rawtp_process_event+0x3642>
    37fc:      	addq	$0x560, %rax            # imm = 0x560
    3802:      	jmp	0x3812 <generic_rawtp_process_event+0x3642>
    3804:      	addq	$0x550, %rax            # imm = 0x550
    380a:      	jmp	0x3812 <generic_rawtp_process_event+0x3642>
    380c:      	addq	$0x540, %rax            # imm = 0x540
    3812:      	lock
    3813:      	incq	(%rax)
    3816:      	testl	%r12d, %r12d
    3819:      	js	0x3834 <generic_rawtp_process_event+0x3664>
    381b:      	movq	$0x0, 0x4(%rbx)
    3823:      	movl	%r14d, %ecx
    3826:      	subl	%r12d, %ecx
    3829:      	xorl	%eax, %eax
    382b:      	cmpq	$-0x1, %r14
    382f:      	cmovnel	%ecx, %eax
    3832:      	jmp	0x3844 <generic_rawtp_process_event+0x3674>
    3834:      	movl	%r12d, 0x4(%rbx)
    3838:      	movl	$0x0, 0x8(%rbx)
    383f:      	xorl	%eax, %eax
    3841:      	xorl	%r12d, %r12d
    3844:      	movl	%eax, 0xc(%rbx)
    3847:      	movl	%r12d, 0x10(%rbx)
    384b:      	movl	$0x24, %ebp
    3850:      	movq	0x8(%rsp), %rbx
    3855:      	movq	0x28(%rsp), %r14
    385a:      	movq	0x40(%rsp), %rax
    385f:      	movq	0x20(%rsp), %rcx
    3864:      	movl	$0x4, %esi
    3869:      	movq	%rbp, %r12
    386c:      	jmp	0x12b1 <generic_rawtp_process_event+0x10e1>
    3871:      	movzbl	0x7(%rbx), %eax
    3875:      	leal	0x8(,%rax,4), %eax
    387c:      	movw	%ax, 0x2(%rbx)
    3880:      	jmp	0x3886 <generic_rawtp_process_event+0x36b6>
    3882:      	movzwl	0x2(%rbx), %eax
    3886:      	addw	(%rbx), %ax
    3889:      	movw	%ax, (%rbx)
    388c:      	movzbl	0x6(%rbx), %r12d
    3891:      	cmpq	$0x3c, %r12
    3895:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    389b:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    38a5:      	btq	%r12, %rcx
    38a9:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    38af:      	movb	%r12b, 0x5(%rbx)
    38b3:      	movzwl	%ax, %ecx
    38b6:      	movq	0x30(%rsp), %rsi
    38bb:      	addq	%rsi, %rcx
    38be:      	movl	$0x2, %edx
    38c3:      	movl	$0x4, %eax
    38c8:      	movzwl	(%rbx), %edx
    38cb:      	addq	%rsi, %rdx
    38ce:      	movq	%r15, %rdi
    38d1:      	movl	$0x2, %esi
    38d6:      	callq	*%rax
    38d8:      	testq	%rax, %rax
    38db:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    38e1:      	movzbl	0x5(%rbx), %eax
    38e5:      	cmpl	$0x32, %eax
    38e8:      	jg	0x3904 <generic_rawtp_process_event+0x3734>
    38ea:      	testl	%eax, %eax
    38ec:      	je	0x3921 <generic_rawtp_process_event+0x3751>
    38ee:      	cmpl	$0x2b, %eax
    38f1:      	je	0x3921 <generic_rawtp_process_event+0x3751>
    38f3:      	cmpl	$0x2c, %eax
    38f6:      	jne	0x3943 <generic_rawtp_process_event+0x3773>
    38f8:      	movw	$0x8, 0x2(%rbx)
    38fe:      	movw	$0x8, %ax
    3902:      	jmp	0x3947 <generic_rawtp_process_event+0x3777>
    3904:      	cmpl	$0x33, %eax
    3907:      	je	0x3932 <generic_rawtp_process_event+0x3762>
    3909:      	cmpl	$0x3c, %eax
    390c:      	je	0x3921 <generic_rawtp_process_event+0x3751>
    390e:      	cmpl	$0xff, %eax
    3913:      	jne	0x3943 <generic_rawtp_process_event+0x3773>
    3915:      	movw	$0x28, 0x2(%rbx)
    391b:      	movw	$0x28, %ax
    391f:      	jmp	0x3947 <generic_rawtp_process_event+0x3777>
    3921:      	movzbl	0x7(%rbx), %eax
    3925:      	leal	0x8(,%rax,8), %eax
    392c:      	movw	%ax, 0x2(%rbx)
    3930:      	jmp	0x3947 <generic_rawtp_process_event+0x3777>
    3932:      	movzbl	0x7(%rbx), %eax
    3936:      	leal	0x8(,%rax,4), %eax
    393d:      	movw	%ax, 0x2(%rbx)
    3941:      	jmp	0x3947 <generic_rawtp_process_event+0x3777>
    3943:      	movzwl	0x2(%rbx), %eax
    3947:      	addw	(%rbx), %ax
    394a:      	movw	%ax, (%rbx)
    394d:      	movzbl	0x6(%rbx), %r12d
    3952:      	cmpq	$0x3c, %r12
    3956:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    395c:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3966:      	btq	%r12, %rcx
    396a:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3970:      	movb	%r12b, 0x5(%rbx)
    3974:      	movzwl	%ax, %ecx
    3977:      	movq	0x30(%rsp), %rsi
    397c:      	addq	%rsi, %rcx
    397f:      	movl	$0x2, %edx
    3984:      	movl	$0x4, %eax
    3989:      	movzwl	(%rbx), %edx
    398c:      	addq	%rsi, %rdx
    398f:      	movq	%r15, %rdi
    3992:      	movl	$0x2, %esi
    3997:      	callq	*%rax
    3999:      	testq	%rax, %rax
    399c:      	js	0x3a5a <generic_rawtp_process_event+0x388a>
    39a2:      	movzbl	0x5(%rbx), %eax
    39a6:      	cmpl	$0x32, %eax
    39a9:      	jg	0x39c5 <generic_rawtp_process_event+0x37f5>
    39ab:      	testl	%eax, %eax
    39ad:      	je	0x39e2 <generic_rawtp_process_event+0x3812>
    39af:      	cmpl	$0x2b, %eax
    39b2:      	je	0x39e2 <generic_rawtp_process_event+0x3812>
    39b4:      	cmpl	$0x2c, %eax
    39b7:      	jne	0x3a04 <generic_rawtp_process_event+0x3834>
    39b9:      	movw	$0x8, 0x2(%rbx)
    39bf:      	movw	$0x8, %ax
    39c3:      	jmp	0x3a08 <generic_rawtp_process_event+0x3838>
    39c5:      	cmpl	$0x33, %eax
    39c8:      	je	0x39f3 <generic_rawtp_process_event+0x3823>
    39ca:      	cmpl	$0x3c, %eax
    39cd:      	je	0x39e2 <generic_rawtp_process_event+0x3812>
    39cf:      	cmpl	$0xff, %eax
    39d4:      	jne	0x3a04 <generic_rawtp_process_event+0x3834>
    39d6:      	movw	$0x28, 0x2(%rbx)
    39dc:      	movw	$0x28, %ax
    39e0:      	jmp	0x3a08 <generic_rawtp_process_event+0x3838>
    39e2:      	movzbl	0x7(%rbx), %eax
    39e6:      	leal	0x8(,%rax,8), %eax
    39ed:      	movw	%ax, 0x2(%rbx)
    39f1:      	jmp	0x3a08 <generic_rawtp_process_event+0x3838>
    39f3:      	movzbl	0x7(%rbx), %eax
    39f7:      	leal	0x8(,%rax,4), %eax
    39fe:      	movw	%ax, 0x2(%rbx)
    3a02:      	jmp	0x3a08 <generic_rawtp_process_event+0x3838>
    3a04:      	movzwl	0x2(%rbx), %eax
    3a08:      	addw	(%rbx), %ax
    3a0b:      	movw	%ax, (%rbx)
    3a0e:      	movzbl	0x6(%rbx), %r12d
    3a13:      	cmpq	$0x3c, %r12
    3a17:      	ja	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3a1d:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3a27:      	btq	%r12, %rcx
    3a2b:      	jae	0x3c1d <generic_rawtp_process_event+0x3a4d>
    3a31:      	movb	%r12b, 0x5(%rbx)
    3a35:      	movzwl	%ax, %ecx
    3a38:      	movq	0x30(%rsp), %rsi
    3a3d:      	addq	%rsi, %rcx
    3a40:      	movl	$0x2, %edx
    3a45:      	movl	$0x4, %eax
    3a4a:      	movzwl	(%rbx), %edx
    3a4d:      	addq	%rsi, %rdx
    3a50:      	movq	%r15, %rdi
    3a53:      	movl	$0x2, %esi
    3a58:      	callq	*%rax
    3a5a:      	xorl	%r12d, %r12d
    3a5d:      	movb	%r12b, 0xd8(%rsp)
    3a65:      	movzbl	%r12b, %eax
    3a69:      	movq	%rbp, %rbx
    3a6c:      	movw	%ax, 0x24(%rbp)
    3a70:      	movw	$0xa, 0x26(%rbp)
    3a76:      	leaq	0x8(%r14), %rdx
    3a7a:      	movl	$0x10, %ecx
    3a7f:      	movl	$0x4, %eax
    3a84:      	movq	%rbp, %rdi
    3a87:      	movl	$0x10, %esi
    3a8c:      	callq	*%rax
    3a8e:      	leaq	0x10(%rbp), %rdi
    3a92:      	addq	$0x18, %r14
    3a96:      	movl	$0x10, %ecx
    3a9b:      	movl	$0x4, %eax
    3aa0:      	movl	$0x10, %esi
    3aa5:      	movq	%r14, %rdx
    3aa8:      	callq	*%rax
    3aaa:      	cmpb	$0x11, %r12b
    3aae:      	je	0x3aff <generic_rawtp_process_event+0x392f>
    3ab0:      	movzbl	%r12b, %eax
    3ab4:      	cmpl	$0x6, %eax
    3ab7:      	jne	0x3b48 <generic_rawtp_process_event+0x3978>
    3abd:      	movq	0x78(%rsp), %r15
    3ac2:      	movzwl	0xd0(%rsp), %r12d
    3acb:      	leaq	(%r15,%r12), %rdx
    3acf:      	movq	%rbp, %rbx
    3ad2:      	leaq	0x20(%rbp), %rdi
    3ad6:      	movl	$0x2, %ecx
    3adb:      	movl	$0x4, %eax
    3ae0:      	movl	$0x2, %esi
    3ae5:      	callq	*%rax
    3ae7:      	leaq	0x22(%rbp), %rdi
    3aeb:      	leaq	(%r15,%r12), %rdx
    3aef:      	addq	$0x2, %rdx
    3af3:      	movl	$0x2, %ecx
    3af8:      	movl	$0x4, %eax
    3afd:      	jmp	0x3b3f <generic_rawtp_process_event+0x396f>
    3aff:      	movq	0x78(%rsp), %r15
    3b04:      	movzwl	0xd0(%rsp), %r12d
    3b0d:      	leaq	(%r15,%r12), %rdx
    3b11:      	movq	%rbp, %rbx
    3b14:      	leaq	0x20(%rbp), %rdi
    3b18:      	movl	$0x2, %ecx
    3b1d:      	movl	$0x4, %eax
    3b22:      	movl	$0x2, %esi
    3b27:      	callq	*%rax
    3b29:      	leaq	0x22(%rbp), %rdi
    3b2d:      	leaq	(%r15,%r12), %rdx
    3b31:      	addq	$0x2, %rdx
    3b35:      	movl	$0x2, %ecx
    3b3a:      	movl	$0x4, %eax
    3b3f:      	movl	$0x2, %esi
    3b44:      	callq	*%rax
    3b46:      	jmp	0x3b4f <generic_rawtp_process_event+0x397f>
    3b48:      	movl	$0x0, 0x20(%rbp)
    3b4f:      	movzwl	0x20(%rbp), %eax
    3b53:      	movzwl	0x22(%rbp), %ecx
    3b57:      	movbew	%ax, 0x20(%rbp)
    3b5d:      	movbew	%cx, 0x22(%rbp)
    3b63:      	addq	$0xe0, %r13
    3b6a:      	leaq	0x68(%rsp), %rdi
    3b6f:      	movl	$0x8, %ecx
    3b74:      	movl	$0x4, %eax
    3b79:      	movl	$0x4, %r15d
    3b7f:      	movl	$0x8, %esi
    3b84:      	movq	%r13, %rdx
    3b87:      	callq	*%rax
    3b89:      	movq	0x68(%rsp), %rcx
    3b8e:      	testq	%rcx, %rcx
    3b91:      	je	0x3bf9 <generic_rawtp_process_event+0x3a29>
    3b93:      	addq	$0x5, %rcx
    3b97:      	leaq	0xc0(%rsp), %rdi
    3b9f:      	movl	$0x8, %edx
    3ba4:      	movl	$0x4, %eax
    3ba9:      	movq	0x68(%rsp), %rdx
    3bae:      	addq	$0x5, %rdx
    3bb2:      	movl	$0x8, %esi
    3bb7:      	callq	*%rax
    3bb9:      	movq	0x68(%rsp), %r12
    3bbe:      	movq	0xc0(%rsp), %r13
    3bc6:      	leaq	0x38(%rbp), %rdi
    3bca:      	leaq	(%r12,%r13,8), %rdx
    3bce:      	addq	$0x44, %rdx
    3bd2:      	movl	$0x4, %eax
    3bd7:      	movl	$0x4, %esi
    3bdc:      	callq	*%rax
    3bde:      	addq	$0x3c, %rbp
    3be2:      	leaq	(%r12,%r13,8), %rdx
    3be6:      	addq	$0x45, %rdx
    3bea:      	movl	$0x4, %eax
    3bef:      	movq	%rbp, %rdi
    3bf2:      	movl	$0x4, %esi
    3bf7:      	callq	*%rax
    3bf9:      	movl	$0x40, %r12d
    3bff:      	movq	0x40(%rsp), %rax
    3c04:      	movq	0x20(%rsp), %rcx
    3c09:      	movl	$0x4, %esi
    3c0e:      	movq	0x8(%rsp), %rbx
    3c13:      	movq	0x28(%rsp), %r14
    3c18:      	jmp	0x12b1 <generic_rawtp_process_event+0x10e1>
    3c1d:      	movw	%ax, 0xd0(%rsp)
    3c25:      	jmp	0x3a5d <generic_rawtp_process_event+0x388d>
    3c2a:      	nopw	(%rax,%rax)

0000000000003c30 <generic_rawtp_process_filter>:
    3c30:      	pushq	%rbp
    3c31:      	pushq	%r15
    3c33:      	pushq	%r14
    3c35:      	pushq	%r13
    3c37:      	pushq	%r12
    3c39:      	pushq	%rbx
    3c3a:      	subq	$0xf8, %rsp
    3c41:      	movq	%rdi, %rbp
    3c44:      	movl	$0x0, 0xc8(%rsp)
    3c4f:      	movq	(%rip), %rdi            # 0x3c56 <generic_rawtp_process_filter+0x26>
    3c56:      	leaq	0xc8(%rsp), %rsi
    3c5e:      	movl	$0x1, %eax
    3c63:      	callq	*%rax
    3c65:      	testq	%rax, %rax
    3c68:      	je	0x5ee6 <generic_rawtp_process_filter+0x22b6>
    3c6e:      	movq	%rax, %r12
    3c71:      	movl	$0x23, %eax
    3c76:      	callq	*%rax
    3c78:      	movq	%rax, %rcx
    3c7b:      	movq	%rax, 0x50(%rsp)
    3c80:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3c87:      	leaq	0x48(%rsp), %rdi
    3c8c:      	movl	$0x4, %edx
    3c91:      	movl	$0x71, %eax
    3c96:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3c9b:      	addq	0x50(%rsp), %rdx
    3ca0:      	movl	$0x4, %esi
    3ca5:      	callq	*%rax
    3ca7:      	movl	0x48(%rsp), %eax
    3cab:      	movl	%eax, 0x38(%rsp)
    3caf:      	movq	(%rip), %rdi            # 0x3cb6 <generic_rawtp_process_filter+0x86>
    3cb6:      	leaq	0x38(%rsp), %rsi
    3cbb:      	movl	$0x1, %eax
    3cc0:      	callq	*%rax
    3cc2:      	testq	%rax, %rax
    3cc5:      	movq	%r12, 0x30(%rsp)
    3cca:      	je	0x3cda <generic_rawtp_process_filter+0xaa>
    3ccc:      	movq	%rax, %r14
    3ccf:      	cmpq	$0x0, 0x8(%rax)
    3cd4:      	jne	0x4af2 <generic_rawtp_process_filter+0xec2>
    3cda:      	movl	$0xb00, %edx            # imm = 0xB00
    3cdf:      	movq	0x50(%rsp), %rcx
    3ce4:      	addq	%rdx, %rcx
    3ce7:      	leaq	0x50(%rsp), %rdi
    3cec:      	movl	$0x8, %esi
    3cf1:      	movl	$0x71, %eax
    3cf6:      	addq	0x50(%rsp), %rdx
    3cfb:      	movl	$0x8, %esi
    3d00:      	callq	*%rax
    3d02:      	movq	0x50(%rsp), %rcx
    3d07:      	testq	%rcx, %rcx
    3d0a:      	je	0x3e9f <generic_rawtp_process_filter+0x26f>
    3d10:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3d17:      	leaq	0x48(%rsp), %rdi
    3d1c:      	movl	$0x4, %edx
    3d21:      	movl	$0x71, %eax
    3d26:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3d2b:      	addq	0x50(%rsp), %rdx
    3d30:      	movl	$0x4, %esi
    3d35:      	callq	*%rax
    3d37:      	movl	0x48(%rsp), %eax
    3d3b:      	movl	%eax, 0x38(%rsp)
    3d3f:      	movq	(%rip), %rdi            # 0x3d46 <generic_rawtp_process_filter+0x116>
    3d46:      	leaq	0x38(%rsp), %rsi
    3d4b:      	movl	$0x1, %eax
    3d50:      	callq	*%rax
    3d52:      	testq	%rax, %rax
    3d55:      	je	0x3d65 <generic_rawtp_process_filter+0x135>
    3d57:      	movq	%rax, %r14
    3d5a:      	cmpq	$0x0, 0x8(%rax)
    3d5f:      	jne	0x4af2 <generic_rawtp_process_filter+0xec2>
    3d65:      	movl	$0xb00, %edx            # imm = 0xB00
    3d6a:      	movq	0x50(%rsp), %rcx
    3d6f:      	addq	%rdx, %rcx
    3d72:      	leaq	0x50(%rsp), %rdi
    3d77:      	movl	$0x8, %esi
    3d7c:      	movl	$0x71, %eax
    3d81:      	addq	0x50(%rsp), %rdx
    3d86:      	movl	$0x8, %esi
    3d8b:      	callq	*%rax
    3d8d:      	movq	0x50(%rsp), %rcx
    3d92:      	testq	%rcx, %rcx
    3d95:      	je	0x3e9f <generic_rawtp_process_filter+0x26f>
    3d9b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3da2:      	leaq	0x48(%rsp), %rdi
    3da7:      	movl	$0x4, %edx
    3dac:      	movl	$0x71, %eax
    3db1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3db6:      	addq	0x50(%rsp), %rdx
    3dbb:      	movl	$0x4, %esi
    3dc0:      	callq	*%rax
    3dc2:      	movl	0x48(%rsp), %eax
    3dc6:      	movl	%eax, 0x38(%rsp)
    3dca:      	movq	(%rip), %rdi            # 0x3dd1 <generic_rawtp_process_filter+0x1a1>
    3dd1:      	leaq	0x38(%rsp), %rsi
    3dd6:      	movl	$0x1, %eax
    3ddb:      	callq	*%rax
    3ddd:      	testq	%rax, %rax
    3de0:      	je	0x3df0 <generic_rawtp_process_filter+0x1c0>
    3de2:      	movq	%rax, %r14
    3de5:      	cmpq	$0x0, 0x8(%rax)
    3dea:      	jne	0x4af2 <generic_rawtp_process_filter+0xec2>
    3df0:      	movl	$0xb00, %edx            # imm = 0xB00
    3df5:      	movq	0x50(%rsp), %rcx
    3dfa:      	addq	%rdx, %rcx
    3dfd:      	leaq	0x50(%rsp), %rdi
    3e02:      	movl	$0x8, %esi
    3e07:      	movl	$0x71, %eax
    3e0c:      	addq	0x50(%rsp), %rdx
    3e11:      	movl	$0x8, %esi
    3e16:      	callq	*%rax
    3e18:      	movq	0x50(%rsp), %rcx
    3e1d:      	testq	%rcx, %rcx
    3e20:      	je	0x3e9f <generic_rawtp_process_filter+0x26f>
    3e22:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3e29:      	leaq	0x48(%rsp), %rdi
    3e2e:      	movl	$0x4, %edx
    3e33:      	movl	$0x71, %eax
    3e38:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3e3d:      	addq	0x50(%rsp), %rdx
    3e42:      	movl	$0x4, %esi
    3e47:      	callq	*%rax
    3e49:      	movl	0x48(%rsp), %eax
    3e4d:      	movl	%eax, 0x38(%rsp)
    3e51:      	movq	(%rip), %rdi            # 0x3e58 <generic_rawtp_process_filter+0x228>
    3e58:      	leaq	0x38(%rsp), %rsi
    3e5d:      	movl	$0x1, %eax
    3e62:      	callq	*%rax
    3e64:      	testq	%rax, %rax
    3e67:      	je	0x3e77 <generic_rawtp_process_filter+0x247>
    3e69:      	movq	%rax, %r14
    3e6c:      	cmpq	$0x0, 0x8(%rax)
    3e71:      	jne	0x4af2 <generic_rawtp_process_filter+0xec2>
    3e77:      	movl	$0xb00, %edx            # imm = 0xB00
    3e7c:      	movq	0x50(%rsp), %rcx
    3e81:      	addq	%rdx, %rcx
    3e84:      	leaq	0x50(%rsp), %rdi
    3e89:      	movl	$0x8, %esi
    3e8e:      	movl	$0x71, %eax
    3e93:      	addq	0x50(%rsp), %rdx
    3e98:      	movl	$0x8, %esi
    3e9d:      	callq	*%rax
    3e9f:      	movl	$0x23, %eax
    3ea4:      	callq	*%rax
    3ea6:      	movq	%rax, %r13
    3ea9:      	leaq	0xaf4(%rax), %rdx
    3eb0:      	leaq	0x50(%rsp), %rdi
    3eb5:      	movl	$0x4, %ecx
    3eba:      	movl	$0x4, %eax
    3ebf:      	movl	$0x4, %r14d
    3ec5:      	movl	$0x4, %esi
    3eca:      	callq	*%rax
    3ecc:      	movl	0x50(%rsp), %eax
    3ed0:      	movl	%eax, 0x5f10(%r12)
    3ed8:      	movl	$0x7d, %eax
    3edd:      	callq	*%rax
    3edf:      	movq	%rax, 0x5f18(%r12)
    3ee7:      	movl	$0x0, 0x5f20(%r12)
    3ef3:      	movq	$0x0, 0x5f28(%r12)
    3eff:      	movl	$0x0, 0x5f30(%r12)
    3f0b:      	leaq	0x60(%r13), %rdx
    3f0f:      	leaq	0x38(%rsp), %rdi
    3f14:      	movl	$0x8, %ecx
    3f19:      	movl	$0x71, %eax
    3f1e:      	movl	$0x8, %esi
    3f23:      	callq	*%rax
    3f25:      	movq	0x38(%rsp), %rcx
    3f2a:      	xorl	%ebx, %ebx
    3f2c:      	testq	%rcx, %rcx
    3f2f:      	je	0x3f9e <generic_rawtp_process_filter+0x36e>
    3f31:      	addq	$0x4, %rcx
    3f35:      	leaq	0x48(%rsp), %rdi
    3f3a:      	movl	$0x4, %edx
    3f3f:      	movl	$0x71, %eax
    3f44:      	movq	0x38(%rsp), %rdx
    3f49:      	addq	$0x4, %rdx
    3f4d:      	movl	$0x4, %esi
    3f52:      	callq	*%rax
    3f54:      	movl	0x48(%rsp), %eax
    3f58:      	testl	%eax, %eax
    3f5a:      	je	0x3f9e <generic_rawtp_process_filter+0x36e>
    3f5c:      	movq	0x38(%rsp), %rcx
    3f61:      	shll	$0x4, %eax
    3f64:      	addq	%rax, %rcx
    3f67:      	addq	$0x80, %rcx
    3f6e:      	leaq	0x50(%rsp), %rdi
    3f73:      	movl	$0x10, %edx
    3f78:      	movl	$0x71, %eax
    3f7d:      	movq	0x38(%rsp), %rcx
    3f82:      	movl	0x48(%rsp), %edx
    3f86:      	shll	$0x4, %edx
    3f89:      	addq	%rcx, %rdx
    3f8c:      	addq	$0x80, %rdx
    3f93:      	movl	$0x10, %esi
    3f98:      	callq	*%rax
    3f9a:      	movl	0x50(%rsp), %ebx
    3f9e:      	movl	%ebx, 0x5f34(%r12)
    3fa6:      	leaq	0xd00(%r13), %r15
    3fad:      	leaq	0x50(%rsp), %rdi
    3fb2:      	movl	$0x8, %ecx
    3fb7:      	movl	$0x4, %eax
    3fbc:      	leaq	0x5f60(%r12), %rbx
    3fc4:      	movl	$0x8, %esi
    3fc9:      	movq	%r15, %rdx
    3fcc:      	callq	*%rax
    3fce:      	movq	0x50(%rsp), %r12
    3fd3:      	movq	0x30(%rsp), %rax
    3fd8:      	leaq	0x5f68(%rax), %rdi
    3fdf:      	leaq	0x40(%r12), %rdx
    3fe4:      	movl	$0x8, %ecx
    3fe9:      	movl	$0x4, %eax
    3fee:      	movl	$0x8, %esi
    3ff3:      	callq	*%rax
    3ff5:      	movq	0x30(%rsp), %rax
    3ffa:      	leaq	0x5f70(%rax), %rdi
    4001:      	leaq	0x30(%r12), %rdx
    4006:      	movl	$0x8, %ecx
    400b:      	movl	$0x4, %eax
    4010:      	movl	$0x8, %esi
    4015:      	callq	*%rax
    4017:      	addq	$0x38, %r12
    401b:      	movl	$0x8, %ecx
    4020:      	movl	$0x4, %eax
    4025:      	movq	%rbx, %rdi
    4028:      	movl	$0x8, %esi
    402d:      	movq	%r12, %rdx
    4030:      	movq	0x30(%rsp), %r12
    4035:      	callq	*%rax
    4037:      	leaq	0x5f38(%r12), %rbx
    403f:      	leaq	0xd70(%r13), %rdx
    4046:      	leaq	0x48(%rsp), %rdi
    404b:      	movl	$0x8, %ecx
    4050:      	movl	$0x4, %eax
    4055:      	movl	$0x8, %esi
    405a:      	callq	*%rax
    405c:      	movq	0x48(%rsp), %rcx
    4061:      	leaq	0x50(%rsp), %rdi
    4066:      	movl	$0x48, %edx
    406b:      	movl	$0x4, %eax
    4070:      	movq	0x48(%rsp), %rdx
    4075:      	movl	$0x48, %esi
    407a:      	callq	*%rax
    407c:      	movl	$0x218, %edx            # imm = 0x218
    4081:      	movq	0x58(%rsp), %rcx
    4086:      	addq	%rdx, %rcx
    4089:      	movl	$0x4, %eax
    408e:      	addq	0x58(%rsp), %rdx
    4093:      	movq	%rbx, %rdi
    4096:      	movl	$0x4, %esi
    409b:      	callq	*%rax
    409d:      	leaq	0x5f3c(%r12), %rdi
    40a5:      	movl	$0x4d8, %edx            # imm = 0x4D8
    40aa:      	movq	0x60(%rsp), %rcx
    40af:      	addq	%rdx, %rcx
    40b2:      	movl	$0x4, %eax
    40b7:      	addq	0x60(%rsp), %rdx
    40bc:      	movl	$0x4, %esi
    40c1:      	callq	*%rax
    40c3:      	leaq	0x5f40(%r12), %rdi
    40cb:      	movq	0x68(%rsp), %rcx
    40d0:      	addq	$0x58, %rcx
    40d4:      	movl	$0x4, %eax
    40d9:      	movq	0x68(%rsp), %rdx
    40de:      	addq	$0x58, %rdx
    40e2:      	movl	$0x4, %esi
    40e7:      	callq	*%rax
    40e9:      	movq	$0x0, 0xa0(%rsp)
    40f5:      	leaq	0xb58(%r13), %rdx
    40fc:      	leaq	0xa0(%rsp), %rdi
    4104:      	movl	$0x8, %ecx
    4109:      	movl	$0x4, %eax
    410e:      	movl	$0x8, %esi
    4113:      	callq	*%rax
    4115:      	movq	0xa0(%rsp), %rcx
    411d:      	testq	%rcx, %rcx
    4120:      	je	0x41d9 <generic_rawtp_process_filter+0x5a9>
    4126:      	movl	$0x0, 0xc0(%rsp)
    4131:      	addq	$0x4, %rcx
    4135:      	leaq	0xc0(%rsp), %rdi
    413d:      	movl	$0x4, %edx
    4142:      	movl	$0x4, %eax
    4147:      	movq	0xa0(%rsp), %rdx
    414f:      	addq	$0x4, %rdx
    4153:      	movl	$0x4, %esi
    4158:      	callq	*%rax
    415a:      	movq	0xa0(%rsp), %rax
    4162:      	movslq	0xc0(%rsp), %rcx
    416a:      	shlq	$0x4, %rcx
    416e:      	addq	%rax, %rcx
    4171:      	addq	$0x80, %rcx
    4178:      	leaq	0x38(%rsp), %rdi
    417d:      	movl	$0x10, %edx
    4182:      	movl	$0x4, %eax
    4187:      	movq	0xa0(%rsp), %rcx
    418f:      	movslq	0xc0(%rsp), %rdx
    4197:      	shlq	$0x4, %rdx
    419b:      	addq	%rcx, %rdx
    419e:      	addq	$0x80, %rdx
    41a5:      	movl	$0x10, %esi
    41aa:      	callq	*%rax
    41ac:      	leaq	0x5f44(%r12), %rdi
    41b4:      	movl	$0x158, %edx            # imm = 0x158
    41b9:      	movq	0x40(%rsp), %rcx
    41be:      	addq	%rdx, %rcx
    41c1:      	movl	$0x4, %esi
    41c6:      	movl	$0x4, %eax
    41cb:      	addq	0x40(%rsp), %rdx
    41d0:      	movl	$0x4, %esi
    41d5:      	callq	*%rax
    41d7:      	jmp	0x41e5 <generic_rawtp_process_filter+0x5b5>
    41d9:      	movl	$0x0, 0x5f44(%r12)
    41e5:      	movq	%rbp, 0xb0(%rsp)
    41ed:      	leaq	0x5f48(%r12), %rdi
    41f5:      	movl	$0x158, %ebx            # imm = 0x158
    41fa:      	movq	0x70(%rsp), %rcx
    41ff:      	addq	%rbx, %rcx
    4202:      	movl	$0x4, %edx
    4207:      	movl	$0x4, %eax
    420c:      	movq	0x70(%rsp), %rdx
    4211:      	addq	%rbx, %rdx
    4214:      	movl	$0x4, %esi
    4219:      	callq	*%rax
    421b:      	leaq	0x5f4c(%r12), %rdi
    4223:      	movl	$0x118, %edx            # imm = 0x118
    4228:      	movq	0x78(%rsp), %rcx
    422d:      	addq	%rdx, %rcx
    4230:      	movl	$0x4, %esi
    4235:      	movl	$0x4, %eax
    423a:      	addq	0x78(%rsp), %rdx
    423f:      	movl	$0x4, %esi
    4244:      	callq	*%rax
    4246:      	leaq	0x5f50(%r12), %rdi
    424e:      	movl	$0x98, %r12d
    4254:      	movq	0x80(%rsp), %rcx
    425c:      	addq	%r12, %rcx
    425f:      	movl	$0x4, %edx
    4264:      	movl	$0x4, %eax
    4269:      	movq	0x80(%rsp), %rdx
    4271:      	addq	%r12, %rdx
    4274:      	movl	$0x4, %esi
    4279:      	callq	*%rax
    427b:      	movq	0x30(%rsp), %rax
    4280:      	leaq	0x5f54(%rax), %rdi
    4287:      	movq	0x88(%rsp), %rcx
    428f:      	addq	%r12, %rcx
    4292:      	movl	$0x4, %edx
    4297:      	movl	$0x4, %eax
    429c:      	addq	0x88(%rsp), %r12
    42a4:      	movl	$0x4, %esi
    42a9:      	movq	%r12, %rdx
    42ac:      	movq	0x30(%rsp), %r12
    42b1:      	callq	*%rax
    42b3:      	leaq	0x5f58(%r12), %rdi
    42bb:      	movq	0x90(%rsp), %rcx
    42c3:      	addq	$0x58, %rcx
    42c7:      	movl	$0x4, %edx
    42cc:      	movl	$0x4, %eax
    42d1:      	movq	0x90(%rsp), %rdx
    42d9:      	addq	$0x58, %rdx
    42dd:      	movl	$0x4, %esi
    42e2:      	callq	*%rax
    42e4:      	movq	$0x0, 0x38(%rsp)
    42ed:      	movq	$0x0, 0xa0(%rsp)
    42f9:      	leaq	0x38(%rsp), %rdi
    42fe:      	movl	$0x8, %ecx
    4303:      	movl	$0x4, %eax
    4308:      	movl	$0x8, %esi
    430d:      	movq	%r15, %rdx
    4310:      	callq	*%rax
    4312:      	movl	$0x90, %edx
    4317:      	movq	0x38(%rsp), %rcx
    431c:      	addq	%rdx, %rcx
    431f:      	leaq	0xa0(%rsp), %rdi
    4327:      	movl	$0x8, %esi
    432c:      	movl	$0x4, %eax
    4331:      	addq	0x38(%rsp), %rdx
    4336:      	movl	$0x8, %esi
    433b:      	callq	*%rax
    433d:      	leaq	0x5f5c(%r12), %rdi
    4345:      	movq	0xa0(%rsp), %rcx
    434d:      	addq	%rbx, %rcx
    4350:      	movl	$0x4, %edx
    4355:      	movl	$0x4, %eax
    435a:      	addq	0xa0(%rsp), %rbx
    4362:      	movl	$0x4, %esi
    4367:      	movq	%rbx, %rdx
    436a:      	callq	*%rax
    436c:      	cmpl	$0x1, 0x5f34(%r12)
    4375:      	jne	0x4380 <generic_rawtp_process_filter+0x750>
    4377:      	orb	$0x2, 0x5f33(%r12)
    4380:      	leaq	0x5f78(%r12), %rdi
    4388:      	movl	$0x308, %edx            # imm = 0x308
    438d:      	movq	%rdi, 0xa8(%rsp)
    4395:      	xorl	%esi, %esi
    4397:      	callq	0x439c <generic_rawtp_process_filter+0x76c>
    439c:      	leaq	0x6290(%r12), %rax
    43a4:      	movq	%rax, 0x8(%rsp)
    43a9:      	addq	$0xa78, %r13            # imm = 0xA78
    43b0:      	leaq	0x38(%rsp), %rdi
    43b5:      	movl	$0x8, %ecx
    43ba:      	movl	$0x4, %eax
    43bf:      	movl	$0x8, %esi
    43c4:      	movq	%r13, %rdx
    43c7:      	callq	*%rax
    43c9:      	movl	$0x5f8, %edx            # imm = 0x5F8
    43ce:      	movq	0x38(%rsp), %rcx
    43d3:      	addq	%rdx, %rcx
    43d6:      	leaq	0x50(%rsp), %rdi
    43db:      	movl	$0x8, %esi
    43e0:      	movl	$0x4, %eax
    43e5:      	addq	0x38(%rsp), %rdx
    43ea:      	movl	$0x8, %esi
    43ef:      	callq	*%rax
    43f1:      	movq	0x50(%rsp), %rbx
    43f6:      	movl	$0x0, 0xcc(%rsp)
    4401:      	movq	(%rip), %rdi            # 0x4408 <generic_rawtp_process_filter+0x7d8>
    4408:      	leaq	0xcc(%rsp), %rsi
    4410:      	movl	$0x1, %eax
    4415:      	callq	*%rax
    4417:      	testq	%rax, %rax
    441a:      	je	0x475c <generic_rawtp_process_filter+0xb2c>
    4420:      	movq	%rax, %r15
    4423:      	movl	$0x1000, 0x6410(%r12)   # imm = 0x1000
    442f:      	leaq	0x1000(%rax), %r13
    4436:      	movl	$0x23, %eax
    443b:      	callq	*%rax
    443d:      	leaq	0xd50(%rax), %rdx
    4444:      	leaq	0xe8(%rsp), %rdi
    444c:      	movl	$0x8, %ecx
    4451:      	movl	$0x4, %eax
    4456:      	movl	$0x8, %esi
    445b:      	callq	*%rax
    445d:      	movq	0xe8(%rsp), %r12
    4465:      	leaq	0x48(%rbx), %rbp
    4469:      	leaq	0xf0(%rsp), %rdi
    4471:      	movl	$0x8, %ecx
    4476:      	movl	$0x4, %eax
    447b:      	movl	$0x8, %esi
    4480:      	movq	%rbp, %rdx
    4483:      	callq	*%rax
    4485:      	movq	0xf0(%rsp), %r14
    448d:      	leaq	0x10(%r14), %rdx
    4491:      	leaq	0x50(%rsp), %rdi
    4496:      	movl	$0x8, %ecx
    449b:      	movl	$0x4, %eax
    44a0:      	movl	$0x8, %esi
    44a5:      	callq	*%rax
    44a7:      	cmpq	$0x0, 0x50(%rsp)
    44ad:      	je	0x47e6 <generic_rawtp_process_filter+0xbb6>
    44b3:      	movq	%rbp, 0xb8(%rsp)
    44bb:      	movq	$0x0, 0x58(%rsp)
    44c4:      	movq	$0x0, 0x50(%rsp)
    44cd:      	movq	%r15, 0x60(%rsp)
    44d2:      	movq	$0x0, 0x68(%rsp)
    44db:      	movq	$0x0, 0x70(%rsp)
    44e4:      	movq	$0x0, 0x78(%rsp)
    44ed:      	movq	%r13, 0x28(%rsp)
    44f2:      	movq	%r13, 0x80(%rsp)
    44fa:      	movq	0x30(%rsp), %rax
    44ff:      	movl	0x6410(%rax), %eax
    4505:      	movl	%eax, 0x88(%rsp)
    450c:      	leaq	0x18(%r12), %r15
    4511:      	movb	$0x0, 0x8c(%rsp)
    4519:      	addq	$0x20, %r12
    451d:      	leaq	0x50(%rsp), %rdi
    4522:      	movl	$0x8, %r14d
    4528:      	movl	$0x4, %eax
    452d:      	addq	$0x40, %rbx
    4531:      	leaq	0x58(%rsp), %r13
    4536:      	leaq	0x68(%rsp), %rbp
    453b:      	movl	$0x8, %esi
    4540:      	movq	%r12, %rdx
    4543:      	callq	*%rax
    4545:      	movl	$0x8, %ecx
    454a:      	movl	$0x4, %eax
    454f:      	movq	%r13, %rdi
    4552:      	movl	$0x8, %esi
    4557:      	movq	%r15, %rdx
    455a:      	callq	*%rax
    455c:      	movl	$0x8, %ecx
    4561:      	movl	$0x4, %eax
    4566:      	movq	0xb8(%rsp), %rdx
    456e:      	movq	%rbp, %rdi
    4571:      	movl	$0x8, %esi
    4576:      	callq	*%rax
    4578:      	movl	$0x8, %ecx
    457d:      	movl	$0x4, %eax
    4582:      	leaq	0x70(%rsp), %rdi
    4587:      	movl	$0x8, %esi
    458c:      	movq	%rbx, %rdx
    458f:      	callq	*%rax
    4591:      	movq	0x70(%rsp), %rax
    4596:      	addq	$-0x20, %rax
    459a:      	movq	%rax, 0x78(%rsp)
    459f:      	movl	$0x80, %ebp
    45a4:      	leaq	0x48(%rsp), %rbx
    45a9:      	nopl	(%rax)
    45b0:      	movq	0x68(%rsp), %r15
    45b5:      	movq	0x70(%rsp), %rdx
    45ba:      	movq	0x78(%rsp), %r12
    45bf:      	cmpq	0x50(%rsp), %r15
    45c4:      	jne	0x45d1 <generic_rawtp_process_filter+0x9a1>
    45c6:      	cmpq	0x58(%rsp), %rdx
    45cb:      	je	0x4845 <generic_rawtp_process_filter+0xc15>
    45d1:      	movl	$0x4, %eax
    45d6:      	leaq	0xc0(%rsp), %rdi
    45de:      	movl	$0x8, %esi
    45e3:      	callq	*%rax
    45e5:      	cmpq	0xc0(%rsp), %r15
    45ed:      	je	0x4700 <generic_rawtp_process_filter+0xad0>
    45f3:      	leaq	0x18(%r15), %r13
    45f7:      	movl	$0x4, %eax
    45fc:      	movq	%rbx, %rdi
    45ff:      	movl	$0x8, %esi
    4604:      	movq	%r13, %rdx
    4607:      	callq	*%rax
    4609:      	cmpq	%r15, 0x48(%rsp)
    460e:      	je	0x4700 <generic_rawtp_process_filter+0xad0>
    4614:      	movl	$0x4, %eax
    4619:      	leaq	0xa0(%rsp), %rdi
    4621:      	movl	$0x8, %esi
    4626:      	movq	%r13, %rdx
    4629:      	callq	*%rax
    462b:      	addq	$0x20, %r15
    462f:      	movl	$0x4, %eax
    4634:      	leaq	0x38(%rsp), %rdi
    4639:      	movl	$0x10, %ecx
    463e:      	movl	$0x10, %esi
    4643:      	movq	%r15, %rdx
    4646:      	callq	*%rax
    4648:      	movq	0x60(%rsp), %r15
    464d:      	movq	0x80(%rsp), %rax
    4655:      	movl	0x3c(%rsp), %r12d
    465a:      	subq	%r15, %rax
    465d:      	movl	0x88(%rsp), %r13d
    4665:      	movl	%r12d, %edx
    4668:      	subl	%r13d, %edx
    466b:      	movl	$0x0, %ecx
    4670:      	cmovbl	%ecx, %edx
    4673:      	addq	0x40(%rsp), %rdx
    4678:      	xorl	%esi, %esi
    467a:      	cmpl	%r12d, %r13d
    467d:      	seta	%sil
    4681:      	movl	%r12d, %ecx
    4684:      	cmovbl	%r13d, %ecx
    4688:      	addl	%ecx, %esi
    468a:      	movl	%r13d, %edi
    468d:      	subl	%esi, %edi
    468f:      	movl	%edi, 0x88(%rsp)
    4696:      	subq	%rsi, %rax
    4699:      	jb	0x484d <generic_rawtp_process_filter+0xc1d>
    469f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    46a5:      	ja	0x484d <generic_rawtp_process_filter+0xc1d>
    46ab:      	cmpl	%r12d, %r13d
    46ae:      	jbe	0x46b5 <generic_rawtp_process_filter+0xa85>
    46b0:      	movb	$0x2f, (%r15,%rax)
    46b5:      	xorl	%edi, %edi
    46b7:      	cmpl	%r12d, %r13d
    46ba:      	seta	%dil
    46be:      	movzbl	%cl, %esi
    46c1:      	addq	%rax, %r15
    46c4:      	addq	%r15, %rdi
    46c7:      	movl	$0x4, %eax
    46cc:      	callq	*%rax
    46ce:      	movq	%r15, 0x80(%rsp)
    46d6:      	cmpl	%r12d, %r13d
    46d9:      	jbe	0x484d <generic_rawtp_process_filter+0xc1d>
    46df:      	movq	0xa0(%rsp), %rax
    46e7:      	movq	%rax, 0x68(%rsp)
    46ec:      	decl	%ebp
    46ee:      	jne	0x45b0 <generic_rawtp_process_filter+0x980>
    46f4:      	jmp	0x484d <generic_rawtp_process_filter+0xc1d>
    46f9:      	nopl	(%rax)
    4700:      	leaq	0x10(%r12), %rdx
    4705:      	movl	$0x4, %eax
    470a:      	movq	%rbx, %rdi
    470d:      	movl	$0x8, %esi
    4712:      	callq	*%rax
    4714:      	movq	0x78(%rsp), %rax
    4719:      	cmpq	0x48(%rsp), %rax
    471e:      	je	0x497c <generic_rawtp_process_filter+0xd4c>
    4724:      	addq	$0x18, %r12
    4728:      	movl	$0x4, %eax
    472d:      	leaq	0x68(%rsp), %rdi
    4732:      	movl	$0x8, %esi
    4737:      	movq	%r12, %rdx
    473a:      	callq	*%rax
    473c:      	movq	0x48(%rsp), %rax
    4741:      	movq	%rax, 0x78(%rsp)
    4746:      	addq	$0x20, %rax
    474a:      	movq	%rax, 0x70(%rsp)
    474f:      	decl	%ebp
    4751:      	jne	0x45b0 <generic_rawtp_process_filter+0x980>
    4757:      	jmp	0x484d <generic_rawtp_process_filter+0xc1d>
    475c:      	movq	0xb0(%rsp), %rbp
    4764:      	movl	0x6410(%r12), %eax
    476c:      	leal	-0x101(%rax), %ecx
    4772:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4778:      	jbe	0x4ad6 <generic_rawtp_process_filter+0xea6>
    477e:      	movzbl	%al, %ebx
    4781:      	leaq	0x5f80(%r12), %rdi
    4789:      	movl	$0x4, %eax
    478e:      	movq	0x8(%rsp), %rdx
    4793:      	movl	%ebx, %esi
    4795:      	callq	*%rax
    4797:      	movq	%rax, %r15
    479a:      	testq	%rax, %rax
    479d:      	je	0x48dd <generic_rawtp_process_filter+0xcad>
    47a3:      	movl	%r15d, %eax
    47a6:      	negl	%eax
    47a8:      	movw	%ax, 0x50(%rsp)
    47ad:      	movw	$0xf, 0x52(%rsp)
    47b4:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    47be:      	movq	%rax, 0x54(%rsp)
    47c3:      	movq	(%rip), %rdi            # 0x47ca <generic_rawtp_process_filter+0xb9a>
    47ca:      	leaq	0x50(%rsp), %rsi
    47cf:      	movl	$0x1, %eax
    47d4:      	callq	*%rax
    47d6:      	testq	%rax, %rax
    47d9:      	je	0x48b9 <generic_rawtp_process_filter+0xc89>
    47df:      	incl	(%rax)
    47e1:      	jmp	0x48dd <generic_rawtp_process_filter+0xcad>
    47e6:      	leaq	0x18(%r14), %rdx
    47ea:      	leaq	0x50(%rsp), %rdi
    47ef:      	movl	$0x8, %ecx
    47f4:      	movl	$0x4, %eax
    47f9:      	movl	$0x8, %esi
    47fe:      	callq	*%rax
    4800:      	cmpq	%r14, 0x50(%rsp)
    4805:      	je	0x44b3 <generic_rawtp_process_filter+0x883>
    480b:      	movq	0x30(%rsp), %rdx
    4810:      	movl	0x6410(%rdx), %ecx
    4816:      	leal	-0xa(%rcx), %eax
    4819:      	movl	%eax, 0x6410(%rdx)
    481f:      	cmpl	$0x9, %ecx
    4822:      	jg	0x5019 <generic_rawtp_process_filter+0x13e9>
    4828:      	movl	$0xffffffdc, 0x6414(%rdx) # imm = 0xFFFFFFDC
    4832:      	movq	%r13, %rbx
    4835:      	movq	0xb0(%rsp), %rbp
    483d:      	movq	%rdx, %r12
    4840:      	jmp	0x49c4 <generic_rawtp_process_filter+0xd94>
    4845:      	movb	$0x1, 0x8c(%rsp)
    484d:      	movq	0x80(%rsp), %rbx
    4855:      	movq	0x28(%rsp), %rcx
    485a:      	cmpq	%rcx, %rbx
    485d:      	je	0x499a <generic_rawtp_process_filter+0xd6a>
    4863:      	xorl	%ecx, %ecx
    4865:      	cmpb	$0x0, 0x8c(%rsp)
    486d:      	sete	%cl
    4870:      	addl	%ecx, %ecx
    4872:      	movl	0x88(%rsp), %eax
    4879:      	movq	0x30(%rsp), %r12
    487e:      	movl	%eax, 0x6410(%r12)
    4886:      	movl	%ecx, 0x6414(%r12)
    488e:      	testl	%eax, %eax
    4890:      	movq	0xb0(%rsp), %rbp
    4898:      	jle	0x48ab <generic_rawtp_process_filter+0xc7b>
    489a:      	movl	$0x1000, %ecx           # imm = 0x1000
    489f:      	subl	%eax, %ecx
    48a1:      	movl	%ecx, 0x6410(%r12)
    48a9:      	movl	%ecx, %eax
    48ab:      	testq	%rbx, %rbx
    48ae:      	jne	0x49c4 <generic_rawtp_process_filter+0xd94>
    48b4:      	jmp	0x4abc <generic_rawtp_process_filter+0xe8c>
    48b9:      	movl	$0x1, 0x38(%rsp)
    48c1:      	movq	(%rip), %rdi            # 0x48c8 <generic_rawtp_process_filter+0xc98>
    48c8:      	xorl	%ecx, %ecx
    48ca:      	leaq	0x50(%rsp), %rsi
    48cf:      	leaq	0x38(%rsp), %rdx
    48d4:      	movl	$0x2, %eax
    48d9:      	xorl	%ecx, %ecx
    48db:      	callq	*%rax
    48dd:      	testl	%r15d, %r15d
    48e0:      	cmovel	%ebx, %r15d
    48e4:      	movl	%r15d, 0x5f78(%r12)
    48ec:      	cmpl	$0x7f, %ebx
    48ef:      	movl	$0x7f, %esi
    48f4:      	cmovbl	%ebx, %esi
    48f7:      	leaq	0x6080(%r12), %rdi
    48ff:      	leaq	0x6390(%r12), %rdx
    4907:      	movl	$0x4, %eax
    490c:      	callq	*%rax
    490e:      	testq	%rax, %rax
    4911:      	je	0x4ae4 <generic_rawtp_process_filter+0xeb4>
    4917:      	negl	%eax
    4919:      	movw	%ax, 0x50(%rsp)
    491e:      	movw	$0xf, 0x52(%rsp)
    4925:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    492f:      	movq	%rax, 0x54(%rsp)
    4934:      	movq	(%rip), %rdi            # 0x493b <generic_rawtp_process_filter+0xd0b>
    493b:      	leaq	0x50(%rsp), %rsi
    4940:      	movl	$0x1, %eax
    4945:      	callq	*%rax
    4947:      	testq	%rax, %rax
    494a:      	je	0x4953 <generic_rawtp_process_filter+0xd23>
    494c:      	incl	(%rax)
    494e:      	jmp	0x4ae4 <generic_rawtp_process_filter+0xeb4>
    4953:      	movl	$0x1, 0x38(%rsp)
    495b:      	movq	(%rip), %rdi            # 0x4962 <generic_rawtp_process_filter+0xd32>
    4962:      	xorl	%ecx, %ecx
    4964:      	leaq	0x50(%rsp), %rsi
    4969:      	leaq	0x38(%rsp), %rdx
    496e:      	movl	$0x2, %eax
    4973:      	xorl	%ecx, %ecx
    4975:      	callq	*%rax
    4977:      	jmp	0x4ae4 <generic_rawtp_process_filter+0xeb4>
    497c:      	movb	$0x1, 0x8c(%rsp)
    4984:      	movq	0x80(%rsp), %rbx
    498c:      	movq	0x28(%rsp), %rcx
    4991:      	cmpq	%rcx, %rbx
    4994:      	jne	0x4863 <generic_rawtp_process_filter+0xc33>
    499a:      	movq	0x30(%rsp), %r12
    499f:      	movl	$0x0, 0x6410(%r12)
    49ab:      	movl	$0x0, 0x6414(%r12)
    49b7:      	xorl	%eax, %eax
    49b9:      	movq	%rcx, %rbx
    49bc:      	movq	0xb0(%rsp), %rbp
    49c4:      	xorl	%ecx, %ecx
    49c6:      	movl	%eax, %r14d
    49c9:      	subl	$0x7f, %r14d
    49cd:      	movl	$0x7f, %r15d
    49d3:      	cmovbl	%eax, %r15d
    49d7:      	cmovbl	%ecx, %r14d
    49db:      	cmpl	$0xff, %eax
    49e0:      	movl	$0xff, %ecx
    49e5:      	cmovbl	%eax, %ecx
    49e8:      	movzbl	%cl, %esi
    49eb:      	movl	%esi, 0x6410(%r12)
    49f3:      	movl	$0x4, %eax
    49f8:      	movq	0x8(%rsp), %rdi
    49fd:      	movq	%rbx, %rdx
    4a00:      	callq	*%rax
    4a02:      	testq	%rax, %rax
    4a05:      	je	0x4a64 <generic_rawtp_process_filter+0xe34>
    4a07:      	negl	%eax
    4a09:      	movw	%ax, 0x50(%rsp)
    4a0e:      	movw	$0x8, 0x52(%rsp)
    4a15:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4a1f:      	movq	%rax, 0x54(%rsp)
    4a24:      	movq	(%rip), %rdi            # 0x4a2b <generic_rawtp_process_filter+0xdfb>
    4a2b:      	leaq	0x50(%rsp), %rsi
    4a30:      	movl	$0x1, %eax
    4a35:      	callq	*%rax
    4a37:      	testq	%rax, %rax
    4a3a:      	je	0x4a40 <generic_rawtp_process_filter+0xe10>
    4a3c:      	incl	(%rax)
    4a3e:      	jmp	0x4a64 <generic_rawtp_process_filter+0xe34>
    4a40:      	movl	$0x1, 0x38(%rsp)
    4a48:      	movq	(%rip), %rdi            # 0x4a4f <generic_rawtp_process_filter+0xe1f>
    4a4f:      	xorl	%ecx, %ecx
    4a51:      	leaq	0x50(%rsp), %rsi
    4a56:      	leaq	0x38(%rsp), %rdx
    4a5b:      	movl	$0x2, %eax
    4a60:      	xorl	%ecx, %ecx
    4a62:      	callq	*%rax
    4a64:      	leaq	0x6390(%r12), %rdi
    4a6c:      	addq	%r14, %rbx
    4a6f:      	movl	$0x4, %eax
    4a74:      	movl	%r15d, %esi
    4a77:      	movq	%rbx, %rdx
    4a7a:      	callq	*%rax
    4a7c:      	testq	%rax, %rax
    4a7f:      	je	0x4abc <generic_rawtp_process_filter+0xe8c>
    4a81:      	negl	%eax
    4a83:      	movw	%ax, 0x50(%rsp)
    4a88:      	movw	$0x8, 0x52(%rsp)
    4a8f:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4a99:      	movq	%rax, 0x54(%rsp)
    4a9e:      	movq	(%rip), %rdi            # 0x4aa5 <generic_rawtp_process_filter+0xe75>
    4aa5:      	leaq	0x50(%rsp), %rsi
    4aaa:      	movl	$0x1, %eax
    4aaf:      	callq	*%rax
    4ab1:      	testq	%rax, %rax
    4ab4:      	je	0x4fd6 <generic_rawtp_process_filter+0x13a6>
    4aba:      	incl	(%rax)
    4abc:      	movl	0x6410(%r12), %eax
    4ac4:      	leal	-0x101(%rax), %ecx
    4aca:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4ad0:      	ja	0x477e <generic_rawtp_process_filter+0xb4e>
    4ad6:      	movq	0xa8(%rsp), %rax
    4ade:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4ae4:      	leaq	0x5f10(%r12), %r14
    4aec:      	orb	$0x10, 0x1(%r12)
    4af2:      	leaq	0x5ef8(%r12), %rsi
    4afa:      	movq	(%rip), %rdi            # 0x4b01 <generic_rawtp_process_filter+0xed1>
    4b01:      	movl	$0x1, %eax
    4b06:      	callq	*%rax
    4b08:      	testq	%rax, %rax
    4b0b:      	je	0x5ee6 <generic_rawtp_process_filter+0x22b6>
    4b11:      	movq	0x5eb8(%r12), %rbx
    4b19:      	cmpq	$0x6, %rbx
    4b1d:      	jae	0x4d5a <generic_rawtp_process_filter+0x112a>
    4b23:      	movslq	(%rax), %rcx
    4b26:      	testq	%rcx, %rcx
    4b29:      	je	0x4d7f <generic_rawtp_process_filter+0x114f>
    4b2f:      	cmpq	%rcx, %rbx
    4b32:      	jae	0x4d5a <generic_rawtp_process_filter+0x112a>
    4b38:      	movq	%rax, 0x8(%rsp)
    4b3d:      	movq	%rcx, 0xb8(%rsp)
    4b45:      	movq	%rbp, 0xb0(%rsp)
    4b4d:      	movl	%ebx, 0x50(%rsp)
    4b51:      	movl	$0x0, 0x38(%rsp)
    4b59:      	movq	(%rip), %rdi            # 0x4b60 <generic_rawtp_process_filter+0xf30>
    4b60:      	leaq	0x50(%rsp), %rsi
    4b65:      	movl	$0x1, %eax
    4b6a:      	callq	*%rax
    4b6c:      	testq	%rax, %rax
    4b6f:      	movq	%r14, 0x28(%rsp)
    4b74:      	je	0x4d9e <generic_rawtp_process_filter+0x116e>
    4b7a:      	movq	%rax, %r13
    4b7d:      	movl	(%rax), %eax
    4b7f:      	testl	%eax, %eax
    4b81:      	je	0x4d9e <generic_rawtp_process_filter+0x116e>
    4b87:      	cmpl	$0x0, 0x68(%r14)
    4b8c:      	js	0x5e8c <generic_rawtp_process_filter+0x225c>
    4b92:      	cmpl	$0x1b, %eax
    4b95:      	ja	0x5e8c <generic_rawtp_process_filter+0x225c>
    4b9b:      	movl	$0x60, %ecx
    4ba0:      	btl	%eax, %ecx
    4ba3:      	jb	0x51e8 <generic_rawtp_process_filter+0x15b8>
    4ba9:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4bae:      	btl	%eax, %ecx
    4bb1:      	jb	0x5158 <generic_rawtp_process_filter+0x1528>
    4bb7:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4bbc:      	btl	%eax, %ecx
    4bbf:      	jae	0x5e8c <generic_rawtp_process_filter+0x225c>
    4bc5:      	movq	%r13, %rsi
    4bc8:      	addq	$0x4, %rsi
    4bcc:      	movq	(%rip), %rdi            # 0x4bd3 <generic_rawtp_process_filter+0xfa3>
    4bd3:      	movl	$0x1, %eax
    4bd8:      	callq	*%rax
    4bda:      	testq	%rax, %rax
    4bdd:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    4be3:      	movq	%rax, %r15
    4be6:      	movq	0x28(%rsp), %rax
    4beb:      	movl	0x68(%rax), %eax
    4bee:      	cmpl	$0x7f, %eax
    4bf1:      	movl	$0x7f, %r14d
    4bf7:      	cmovll	%eax, %r14d
    4bfb:      	movq	(%rip), %rdi            # 0x4c02 <generic_rawtp_process_filter+0xfd2>
    4c02:      	leaq	0x38(%rsp), %rsi
    4c07:      	movl	$0x1, %eax
    4c0c:      	callq	*%rax
    4c0e:      	testq	%rax, %rax
    4c11:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    4c17:      	movq	%rax, %rbp
    4c1a:      	leal	(,%r14,8), %eax
    4c22:      	movl	%eax, (%rbp)
    4c25:      	movq	0x28(%rsp), %rax
    4c2a:      	cmpl	$0x0, 0x6c(%rax)
    4c2e:      	jne	0x4d21 <generic_rawtp_process_filter+0x10f1>
    4c34:      	movq	%r15, 0xa8(%rsp)
    4c3c:      	movq	0x28(%rsp), %r15
    4c41:      	movl	0x68(%r15), %ecx
    4c45:      	movl	%ecx, %eax
    4c47:      	subl	%r14d, %eax
    4c4a:      	movl	%r14d, %edx
    4c4d:      	andl	$0x7f, %edx
    4c50:      	addl	%edx, %eax
    4c52:      	addl	%ecx, %edx
    4c54:      	movl	%r14d, %ecx
    4c57:      	notl	%ecx
    4c59:      	addl	%edx, %ecx
    4c5b:      	subl	%r14d, %edx
    4c5e:      	leal	-0x4(%rdx), %esi
    4c61:      	leaq	0x1f3(%r15), %rdi
    4c68:      	leal	-0x3(%rdx), %r8d
    4c6c:      	addl	$-0x2, %edx
    4c6f:      	movq	$-0x3, %r9
    4c76:      	leal	(%rcx,%r9), %r10d
    4c7a:      	addl	$0x3, %r10d
    4c7e:      	andl	$0x7f, %r10d
    4c82:      	movzbl	0x170(%r15,%r10), %r10d
    4c8b:      	movb	%r10b, -0x3(%rdi)
    4c8f:      	leaq	(%rax,%r9), %r10
    4c93:      	cmpq	$-0x2, %r10
    4c97:      	je	0x4d11 <generic_rawtp_process_filter+0x10e1>
    4c99:      	leal	(%rdx,%r9), %r11d
    4c9d:      	addl	$0x3, %r11d
    4ca1:      	andl	$0x7f, %r11d
    4ca5:      	movzbl	0x170(%r15,%r11), %r11d
    4cae:      	movb	%r11b, -0x2(%rdi)
    4cb2:      	cmpq	$-0x1, %r10
    4cb6:      	je	0x4d11 <generic_rawtp_process_filter+0x10e1>
    4cb8:      	leal	(%r8,%r9), %r10d
    4cbc:      	addl	$0x3, %r10d
    4cc0:      	andl	$0x7f, %r10d
    4cc4:      	movzbl	0x170(%r15,%r10), %r10d
    4ccd:      	movb	%r10b, -0x1(%rdi)
    4cd1:      	movq	%rax, %r10
    4cd4:      	addq	%r9, %r10
    4cd7:      	je	0x4d11 <generic_rawtp_process_filter+0x10e1>
    4cd9:      	cmpq	$-0x7f, %r9
    4cdd:      	je	0x4d11 <generic_rawtp_process_filter+0x10e1>
    4cdf:      	leal	(%rsi,%r9), %r10d
    4ce3:      	addl	$0x3, %r10d
    4ce7:      	andl	$0x7f, %r10d
    4ceb:      	movzbl	0x170(%r15,%r10), %r10d
    4cf4:      	movb	%r10b, (%rdi)
    4cf7:      	addq	$0x4, %rdi
    4cfb:      	leaq	(%rax,%r9), %r10
    4cff:      	addq	$-0x4, %r10
    4d03:      	addq	$-0x4, %r9
    4d07:      	cmpq	$-0x3, %r10
    4d0b:      	jne	0x4c76 <generic_rawtp_process_filter+0x1046>
    4d11:      	movl	$0x1, 0x6c(%r15)
    4d19:      	movq	0xa8(%rsp), %r15
    4d21:      	cmpl	$0x7f, %r14d
    4d25:      	ja	0x4d4d <generic_rawtp_process_filter+0x111d>
    4d27:      	movslq	%r14d, %rsi
    4d2a:      	movq	%rbp, %rdi
    4d2d:      	addq	$0x4, %rdi
    4d31:      	movq	0x28(%rsp), %rax
    4d36:      	leaq	0x1f0(%rax), %rdx
    4d3d:      	movl	$0x4, %eax
    4d42:      	callq	*%rax
    4d44:      	testq	%rax, %rax
    4d47:      	js	0x5e8c <generic_rawtp_process_filter+0x225c>
    4d4d:      	movl	$0x1, %eax
    4d52:      	movq	%r15, %rdi
    4d55:      	jmp	0x51e3 <generic_rawtp_process_filter+0x15b3>
    4d5a:      	movl	(%r14), %eax
    4d5d:      	movl	%eax, 0x10(%r12)
    4d62:      	movq	0x8(%r14), %rax
    4d66:      	movq	%rax, 0x18(%r12)
    4d6b:      	cmpb	$0x0, 0x5ec0(%r12)
    4d74:      	jne	0x5ed1 <generic_rawtp_process_filter+0x22a1>
    4d7a:      	jmp	0x5ee6 <generic_rawtp_process_filter+0x22b6>
    4d7f:      	movb	$0x1, 0x5ec0(%r12)
    4d88:      	movl	(%r14), %eax
    4d8b:      	movl	%eax, 0x10(%r12)
    4d90:      	movq	0x8(%r14), %rax
    4d94:      	movq	%rax, 0x18(%r12)
    4d99:      	jmp	0x5ed1 <generic_rawtp_process_filter+0x22a1>
    4d9e:      	movq	0x8(%rsp), %r10
    4da3:      	movq	(%rip), %rax            # 0x4daa <generic_rawtp_process_filter+0x117a>
    4daa:      	cmpb	$0x0, (%rax)
    4dad:      	je	0x5050 <generic_rawtp_process_filter+0x1420>
    4db3:      	movq	(%rip), %rdi            # 0x4dba <generic_rawtp_process_filter+0x118a>
    4dba:      	movl	$0x1, %eax
    4dbf:      	movq	0x28(%rsp), %rsi
    4dc4:      	callq	*%rax
    4dc6:      	movq	0x8(%rsp), %r10
    4dcb:      	testq	%rax, %rax
    4dce:      	je	0x5050 <generic_rawtp_process_filter+0x1420>
    4dd4:      	movq	%rax, %rbp
    4dd7:      	leal	0x5(%rbx), %eax
    4dda:      	movl	%eax, 0x50(%rsp)
    4dde:      	movl	$0x0, 0x38(%rsp)
    4de6:      	movq	(%rip), %rdi            # 0x4ded <generic_rawtp_process_filter+0x11bd>
    4ded:      	leaq	0x50(%rsp), %rsi
    4df2:      	movl	$0x1, %eax
    4df7:      	callq	*%rax
    4df9:      	testq	%rax, %rax
    4dfc:      	je	0x504b <generic_rawtp_process_filter+0x141b>
    4e02:      	movq	%rax, %r13
    4e05:      	movl	(%rax), %eax
    4e07:      	testl	%eax, %eax
    4e09:      	je	0x504b <generic_rawtp_process_filter+0x141b>
    4e0f:      	cmpl	$0x0, (%rbp)
    4e13:      	js	0x5e8c <generic_rawtp_process_filter+0x225c>
    4e19:      	cmpl	$0x1b, %eax
    4e1c:      	ja	0x5e8c <generic_rawtp_process_filter+0x225c>
    4e22:      	movl	$0x60, %ecx
    4e27:      	btl	%eax, %ecx
    4e2a:      	jb	0x5306 <generic_rawtp_process_filter+0x16d6>
    4e30:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4e35:      	btl	%eax, %ecx
    4e38:      	jb	0x5278 <generic_rawtp_process_filter+0x1648>
    4e3e:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4e43:      	btl	%eax, %ecx
    4e46:      	jae	0x5e8c <generic_rawtp_process_filter+0x225c>
    4e4c:      	movq	%r13, %rsi
    4e4f:      	addq	$0x4, %rsi
    4e53:      	movq	(%rip), %rdi            # 0x4e5a <generic_rawtp_process_filter+0x122a>
    4e5a:      	movl	$0x1, %eax
    4e5f:      	callq	*%rax
    4e61:      	testq	%rax, %rax
    4e64:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    4e6a:      	movq	%rax, %r15
    4e6d:      	movl	(%rbp), %eax
    4e70:      	cmpl	$0x7f, %eax
    4e73:      	movl	$0x7f, %r14d
    4e79:      	cmovll	%eax, %r14d
    4e7d:      	movq	(%rip), %rdi            # 0x4e84 <generic_rawtp_process_filter+0x1254>
    4e84:      	leaq	0x38(%rsp), %rsi
    4e89:      	movl	$0x1, %eax
    4e8e:      	callq	*%rax
    4e90:      	testq	%rax, %rax
    4e93:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    4e99:      	movq	%rax, %rcx
    4e9c:      	leal	(,%r14,8), %eax
    4ea4:      	movl	%eax, (%rcx)
    4ea6:      	cmpl	$0x0, 0x4(%rbp)
    4eaa:      	jne	0x4f96 <generic_rawtp_process_filter+0x1366>
    4eb0:      	movq	%rcx, 0xa8(%rsp)
    4eb8:      	movl	(%rbp), %ecx
    4ebb:      	movl	%ecx, %eax
    4ebd:      	subl	%r14d, %eax
    4ec0:      	movl	%r14d, %edx
    4ec3:      	andl	$0x7f, %edx
    4ec6:      	addl	%edx, %eax
    4ec8:      	addl	%ecx, %edx
    4eca:      	movl	%r14d, %ecx
    4ecd:      	notl	%ecx
    4ecf:      	addl	%edx, %ecx
    4ed1:      	subl	%r14d, %edx
    4ed4:      	leal	-0x4(%rdx), %esi
    4ed7:      	leaq	0x18b(%rbp), %rdi
    4ede:      	leal	-0x3(%rdx), %r8d
    4ee2:      	addl	$-0x2, %edx
    4ee5:      	movq	$-0x3, %r9
    4eec:      	leal	(%rcx,%r9), %r10d
    4ef0:      	addl	$0x3, %r10d
    4ef4:      	andl	$0x7f, %r10d
    4ef8:      	movzbl	0x108(%rbp,%r10), %r10d
    4f01:      	movb	%r10b, -0x3(%rdi)
    4f05:      	leaq	(%rax,%r9), %r10
    4f09:      	cmpq	$-0x2, %r10
    4f0d:      	je	0x4f87 <generic_rawtp_process_filter+0x1357>
    4f0f:      	leal	(%rdx,%r9), %r11d
    4f13:      	addl	$0x3, %r11d
    4f17:      	andl	$0x7f, %r11d
    4f1b:      	movzbl	0x108(%rbp,%r11), %r11d
    4f24:      	movb	%r11b, -0x2(%rdi)
    4f28:      	cmpq	$-0x1, %r10
    4f2c:      	je	0x4f87 <generic_rawtp_process_filter+0x1357>
    4f2e:      	leal	(%r8,%r9), %r10d
    4f32:      	addl	$0x3, %r10d
    4f36:      	andl	$0x7f, %r10d
    4f3a:      	movzbl	0x108(%rbp,%r10), %r10d
    4f43:      	movb	%r10b, -0x1(%rdi)
    4f47:      	movq	%rax, %r10
    4f4a:      	addq	%r9, %r10
    4f4d:      	je	0x4f87 <generic_rawtp_process_filter+0x1357>
    4f4f:      	cmpq	$-0x7f, %r9
    4f53:      	je	0x4f87 <generic_rawtp_process_filter+0x1357>
    4f55:      	leal	(%rsi,%r9), %r10d
    4f59:      	addl	$0x3, %r10d
    4f5d:      	andl	$0x7f, %r10d
    4f61:      	movzbl	0x108(%rbp,%r10), %r10d
    4f6a:      	movb	%r10b, (%rdi)
    4f6d:      	addq	$0x4, %rdi
    4f71:      	leaq	(%rax,%r9), %r10
    4f75:      	addq	$-0x4, %r10
    4f79:      	addq	$-0x4, %r9
    4f7d:      	cmpq	$-0x3, %r10
    4f81:      	jne	0x4eec <generic_rawtp_process_filter+0x12bc>
    4f87:      	movl	$0x1, 0x4(%rbp)
    4f8e:      	movq	0xa8(%rsp), %rcx
    4f96:      	cmpl	$0x7f, %r14d
    4f9a:      	ja	0x4fc6 <generic_rawtp_process_filter+0x1396>
    4f9c:      	movslq	%r14d, %rsi
    4f9f:      	movq	%rcx, %rdi
    4fa2:      	addq	$0x4, %rdi
    4fa6:      	addq	$0x188, %rbp            # imm = 0x188
    4fad:      	movl	$0x4, %eax
    4fb2:      	movq	%rbp, %rdx
    4fb5:      	movq	%rcx, %r14
    4fb8:      	callq	*%rax
    4fba:      	movq	%r14, %rcx
    4fbd:      	testq	%rax, %rax
    4fc0:      	js	0x5e8c <generic_rawtp_process_filter+0x225c>
    4fc6:      	movl	$0x1, %eax
    4fcb:      	movq	%r15, %rdi
    4fce:      	movq	%rcx, %rsi
    4fd1:      	jmp	0x5366 <generic_rawtp_process_filter+0x1736>
    4fd6:      	movl	$0x1, 0x38(%rsp)
    4fde:      	movq	(%rip), %rdi            # 0x4fe5 <generic_rawtp_process_filter+0x13b5>
    4fe5:      	xorl	%ecx, %ecx
    4fe7:      	leaq	0x50(%rsp), %rsi
    4fec:      	leaq	0x38(%rsp), %rdx
    4ff1:      	movl	$0x2, %eax
    4ff6:      	xorl	%ecx, %ecx
    4ff8:      	callq	*%rax
    4ffa:      	movl	0x6410(%r12), %eax
    5002:      	leal	-0x101(%rax), %ecx
    5008:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    500e:      	jbe	0x4ad6 <generic_rawtp_process_filter+0xea6>
    5014:      	jmp	0x477e <generic_rawtp_process_filter+0xb4e>
    5019:      	movq	%rbp, 0xb8(%rsp)
    5021:      	movq	%r15, %r13
    5024:      	addq	$0xff6, %r13            # imm = 0xFF6
    502b:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5035:      	movq	%rax, 0xff6(%r15)
    503c:      	movw	$0x2964, 0xffe(%r15)    # imm = 0x2964
    5046:      	jmp	0x44bb <generic_rawtp_process_filter+0x88b>
    504b:      	movq	0x8(%rsp), %r10
    5050:      	movl	%ebx, %eax
    5052:      	leaq	0x4(,%rax,4), %rcx
    505a:      	movl	0x4(%r10,%rax,4), %eax
    505f:      	leal	(%rax,%rcx), %edx
    5062:      	andl	$0x3ff, %edx            # imm = 0x3FF
    5068:      	addl	%eax, %ecx
    506a:      	addl	$0x4, %ecx
    506d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5073:      	leaq	0x8(%rdx), %rbp
    5077:      	cmpl	$0x5, (%rcx,%r10)
    507c:      	jb	0x514e <generic_rawtp_process_filter+0x151e>
    5082:      	movq	%rdx, 0xd8(%rsp)
    508a:      	movl	(%rbp,%r10), %edi
    508f:      	movl	0x4(%rbp,%r10), %r8d
    5094:      	movl	0x8(%rbp,%r10), %edx
    5099:      	movq	$0x0, 0x58(%rsp)
    50a2:      	movq	$0x0, 0x50(%rsp)
    50ab:      	cmpl	$0x4, %edx
    50ae:      	movl	$0x4, %ecx
    50b3:      	cmovbl	%edx, %ecx
    50b6:      	cmpl	$0x6, %edi
    50b9:      	jne	0x50cf <generic_rawtp_process_filter+0x149f>
    50bb:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    50c5:      	movq	%rsi, 0x50(%rsp)
    50ca:      	movq	%rsi, 0x58(%rsp)
    50cf:      	testl	%edx, %edx
    50d1:      	movq	0x28(%rsp), %r14
    50d6:      	je	0x5852 <generic_rawtp_process_filter+0x1c22>
    50dc:      	leaq	0x24(%r14), %rdx
    50e0:      	testb	$0x1, %r8b
    50e4:      	movq	%rdx, 0xe0(%rsp)
    50ec:      	movq	%rdx, %r9
    50ef:      	cmoveq	%r14, %r9
    50f3:      	leaq	0x10(%r14), %rdx
    50f7:      	movq	%rdx, 0xd0(%rsp)
    50ff:      	leal	(%rax,%rbx,4), %r11d
    5103:      	addl	$0x4, %r11d
    5107:      	andl	$0x3ff, %r11d           # imm = 0x3FF
    510e:      	addq	$0x14, %r11
    5112:      	decq	%rcx
    5115:      	cmpq	$0x3, %rcx
    5119:      	movl	$0x3, %eax
    511e:      	cmovbq	%rcx, %rax
    5122:      	movl	%eax, %eax
    5124:      	leaq	0x4(,%rax,4), %rax
    512c:      	movq	%rax, 0xa8(%rsp)
    5134:      	xorl	%ebx, %ebx
    5136:      	movl	%edi, 0x4(%rsp)
    513a:      	movq	%r8, 0x20(%rsp)
    513f:      	movq	%r9, 0x18(%rsp)
    5144:      	movq	%r11, 0x10(%rsp)
    5149:      	jmp	0x53ec <generic_rawtp_process_filter+0x17bc>
    514e:      	movl	$0x1, %eax
    5153:      	jmp	0x5893 <generic_rawtp_process_filter+0x1c63>
    5158:      	movq	%r13, %rsi
    515b:      	addq	$0x4, %rsi
    515f:      	movq	(%rip), %rdi            # 0x5166 <generic_rawtp_process_filter+0x1536>
    5166:      	movl	$0x1, %eax
    516b:      	callq	*%rax
    516d:      	testq	%rax, %rax
    5170:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5176:      	movq	%rax, %r14
    5179:      	movq	(%rip), %rdi            # 0x5180 <generic_rawtp_process_filter+0x1550>
    5180:      	leaq	0x38(%rsp), %rsi
    5185:      	movl	$0x1, %eax
    518a:      	callq	*%rax
    518c:      	testq	%rax, %rax
    518f:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5195:      	movq	%rax, %rbp
    5198:      	movl	$0x104, %edx            # imm = 0x104
    519d:      	movq	%rax, %rdi
    51a0:      	xorl	%esi, %esi
    51a2:      	callq	0x51a7 <generic_rawtp_process_filter+0x1577>
    51a7:      	movq	0x28(%rsp), %rsi
    51ac:      	movl	0x68(%rsi), %eax
    51af:      	leal	(,%rax,8), %ecx
    51b6:      	movl	%ecx, (%rbp)
    51b9:      	movq	%rbp, %rdi
    51bc:      	addq	$0x4, %rdi
    51c0:      	movzbl	%al, %ecx
    51c3:      	leaq	0x70(%rsi), %rdx
    51c7:      	movl	$0x4, %eax
    51cc:      	movzbl	0x68(%rsi), %esi
    51d0:      	callq	*%rax
    51d2:      	testq	%rax, %rax
    51d5:      	js	0x5e8c <generic_rawtp_process_filter+0x225c>
    51db:      	movl	$0x1, %eax
    51e0:      	movq	%r14, %rdi
    51e3:      	movq	%rbp, %rsi
    51e6:      	jmp	0x5241 <generic_rawtp_process_filter+0x1611>
    51e8:      	movl	0x8(%r13), %eax
    51ec:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    51f1:      	cmpq	%rcx, %rax
    51f4:      	movq	0x28(%rsp), %rcx
    51f9:      	je	0x5214 <generic_rawtp_process_filter+0x15e4>
    51fb:      	movq	0x370(%rcx), %rcx
    5202:      	btq	%rax, %rcx
    5206:      	jae	0x5214 <generic_rawtp_process_filter+0x15e4>
    5208:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5212:      	jmp	0x5243 <generic_rawtp_process_filter+0x1613>
    5214:      	movq	(%rip), %rdi            # 0x521b <generic_rawtp_process_filter+0x15eb>
    521b:      	leaq	0x50(%rsp), %rsi
    5220:      	movl	$0x1, %eax
    5225:      	callq	*%rax
    5227:      	testq	%rax, %rax
    522a:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5230:      	movq	%rax, %rdi
    5233:      	movq	0x28(%rsp), %rax
    5238:      	leaq	0x70(%rax), %rsi
    523c:      	movl	$0x1, %eax
    5241:      	callq	*%rax
    5243:      	movl	(%r13), %ecx
    5247:      	cmpq	$0x25, %rcx
    524b:      	movq	0x8(%rsp), %r10
    5250:      	ja	0x532d <generic_rawtp_process_filter+0x16fd>
    5256:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5260:      	btq	%rcx, %rdx
    5264:      	jae	0x532d <generic_rawtp_process_filter+0x16fd>
    526a:      	testq	%rax, %rax
    526d:      	jne	0x5e8c <generic_rawtp_process_filter+0x225c>
    5273:      	jmp	0x4da3 <generic_rawtp_process_filter+0x1173>
    5278:      	movq	%r13, %rsi
    527b:      	addq	$0x4, %rsi
    527f:      	movq	(%rip), %rdi            # 0x5286 <generic_rawtp_process_filter+0x1656>
    5286:      	movl	$0x1, %eax
    528b:      	callq	*%rax
    528d:      	testq	%rax, %rax
    5290:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5296:      	movq	%rax, %r14
    5299:      	movq	(%rip), %rdi            # 0x52a0 <generic_rawtp_process_filter+0x1670>
    52a0:      	leaq	0x38(%rsp), %rsi
    52a5:      	movl	$0x1, %eax
    52aa:      	callq	*%rax
    52ac:      	testq	%rax, %rax
    52af:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    52b5:      	movq	%rax, %r15
    52b8:      	movl	$0x104, %edx            # imm = 0x104
    52bd:      	movq	%rax, %rdi
    52c0:      	xorl	%esi, %esi
    52c2:      	callq	0x52c7 <generic_rawtp_process_filter+0x1697>
    52c7:      	movl	(%rbp), %eax
    52ca:      	leal	(,%rax,8), %ecx
    52d1:      	movl	%ecx, (%r15)
    52d4:      	movq	%r15, %rdi
    52d7:      	addq	$0x4, %rdi
    52db:      	movzbl	%al, %ecx
    52de:      	movq	%rbp, %rdx
    52e1:      	addq	$0x8, %rdx
    52e5:      	movl	$0x4, %eax
    52ea:      	movzbl	(%rbp), %esi
    52ee:      	callq	*%rax
    52f0:      	testq	%rax, %rax
    52f3:      	js	0x5e8c <generic_rawtp_process_filter+0x225c>
    52f9:      	movl	$0x1, %eax
    52fe:      	movq	%r14, %rdi
    5301:      	movq	%r15, %rsi
    5304:      	jmp	0x5366 <generic_rawtp_process_filter+0x1736>
    5306:      	movl	0x8(%r13), %eax
    530a:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    530f:      	cmpq	%rcx, %rax
    5312:      	je	0x533b <generic_rawtp_process_filter+0x170b>
    5314:      	movq	0x308(%rbp), %rcx
    531b:      	btq	%rax, %rcx
    531f:      	jae	0x533b <generic_rawtp_process_filter+0x170b>
    5321:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    532b:      	jmp	0x5368 <generic_rawtp_process_filter+0x1738>
    532d:      	testq	%rax, %rax
    5330:      	jne	0x4da3 <generic_rawtp_process_filter+0x1173>
    5336:      	jmp	0x5e8c <generic_rawtp_process_filter+0x225c>
    533b:      	movq	(%rip), %rdi            # 0x5342 <generic_rawtp_process_filter+0x1712>
    5342:      	leaq	0x50(%rsp), %rsi
    5347:      	movl	$0x1, %eax
    534c:      	callq	*%rax
    534e:      	testq	%rax, %rax
    5351:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5357:      	movq	%rax, %rdi
    535a:      	addq	$0x8, %rbp
    535e:      	movl	$0x1, %eax
    5363:      	movq	%rbp, %rsi
    5366:      	callq	*%rax
    5368:      	movl	(%r13), %ecx
    536c:      	cmpq	$0x25, %rcx
    5370:      	movq	0x8(%rsp), %r10
    5375:      	ja	0x5395 <generic_rawtp_process_filter+0x1765>
    5377:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5381:      	btq	%rcx, %rdx
    5385:      	jae	0x5395 <generic_rawtp_process_filter+0x1765>
    5387:      	testq	%rax, %rax
    538a:      	jne	0x5e8c <generic_rawtp_process_filter+0x225c>
    5390:      	jmp	0x5050 <generic_rawtp_process_filter+0x1420>
    5395:      	testq	%rax, %rax
    5398:      	jne	0x5050 <generic_rawtp_process_filter+0x1420>
    539e:      	jmp	0x5e8c <generic_rawtp_process_filter+0x225c>
    53a3:      	movq	0x30(%rsp), %r12
    53a8:      	movq	0x28(%rsp), %r14
    53ad:      	movq	0x8(%rsp), %r10
    53b2:      	movl	0x4(%rsp), %edi
    53b6:      	movq	0x20(%rsp), %r8
    53bb:      	movq	0x18(%rsp), %r9
    53c0:      	movq	0x10(%rsp), %r11
    53c5:      	cmpl	$0x6, %edi
    53c8:      	setne	%al
    53cb:      	xorb	$0x1, %r13b
    53cf:      	orb	%al, %r13b
    53d2:      	movzbl	%r13b, %eax
    53d6:      	movl	%eax, 0x50(%rsp,%rbx)
    53da:      	addq	$0x4, %rbx
    53de:      	cmpq	%rbx, 0xa8(%rsp)
    53e6:      	je	0x5852 <generic_rawtp_process_filter+0x1c22>
    53ec:      	leaq	(%r11,%rbx), %rax
    53f0:      	movl	(%r9), %ecx
    53f3:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    53f9:      	jbe	0x5621 <generic_rawtp_process_filter+0x19f1>
    53ff:      	xorl	%r15d, %r15d
    5402:      	testb	$0x2, %r8b
    5406:      	je	0x563e <generic_rawtp_process_filter+0x1a0e>
    540c:      	testb	$0x1, %r8b
    5410:      	jne	0x565e <generic_rawtp_process_filter+0x1a2e>
    5416:      	movl	(%r14), %eax
    5419:      	movb	$0x1, %r13b
    541c:      	cmpq	%rax, %r15
    541f:      	je	0x53c5 <generic_rawtp_process_filter+0x1795>
    5421:      	movl	0x10(%r14), %eax
    5425:      	cmpq	%rax, %r15
    5428:      	je	0x53c5 <generic_rawtp_process_filter+0x1795>
    542a:      	movl	$0x1, %eax
    542f:      	movq	0xd0(%rsp), %rsi
    5437:      	movq	(%rip), %rdi            # 0x543e <generic_rawtp_process_filter+0x180e>
    543e:      	callq	*%rax
    5440:      	testq	%rax, %rax
    5443:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    5449:      	movq	%rax, %rsi
    544c:      	movl	(%rax), %eax
    544e:      	cmpq	%rax, %r15
    5451:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5457:      	movl	0x10(%rsi), %eax
    545a:      	cmpq	%rax, %r15
    545d:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5463:      	addq	$0x10, %rsi
    5467:      	movl	$0x1, %eax
    546c:      	movq	(%rip), %rdi            # 0x5473 <generic_rawtp_process_filter+0x1843>
    5473:      	callq	*%rax
    5475:      	testq	%rax, %rax
    5478:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    547e:      	movq	%rax, %rsi
    5481:      	movl	(%rax), %eax
    5483:      	cmpq	%rax, %r15
    5486:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    548c:      	movl	0x10(%rsi), %eax
    548f:      	cmpq	%rax, %r15
    5492:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5498:      	addq	$0x10, %rsi
    549c:      	movl	$0x1, %eax
    54a1:      	movq	(%rip), %rdi            # 0x54a8 <generic_rawtp_process_filter+0x1878>
    54a8:      	callq	*%rax
    54aa:      	testq	%rax, %rax
    54ad:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    54b3:      	movq	%rax, %rsi
    54b6:      	movl	(%rax), %eax
    54b8:      	cmpq	%rax, %r15
    54bb:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    54c1:      	movl	0x10(%rsi), %eax
    54c4:      	cmpq	%rax, %r15
    54c7:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    54cd:      	addq	$0x10, %rsi
    54d1:      	movl	$0x1, %eax
    54d6:      	movq	(%rip), %rdi            # 0x54dd <generic_rawtp_process_filter+0x18ad>
    54dd:      	callq	*%rax
    54df:      	testq	%rax, %rax
    54e2:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    54e8:      	movq	%rax, %rsi
    54eb:      	movl	(%rax), %eax
    54ed:      	cmpq	%rax, %r15
    54f0:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    54f6:      	movl	0x10(%rsi), %eax
    54f9:      	cmpq	%rax, %r15
    54fc:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5502:      	addq	$0x10, %rsi
    5506:      	movl	$0x1, %eax
    550b:      	movq	(%rip), %rdi            # 0x5512 <generic_rawtp_process_filter+0x18e2>
    5512:      	callq	*%rax
    5514:      	testq	%rax, %rax
    5517:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    551d:      	movq	%rax, %rsi
    5520:      	movl	(%rax), %eax
    5522:      	cmpq	%rax, %r15
    5525:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    552b:      	movl	0x10(%rsi), %eax
    552e:      	cmpq	%rax, %r15
    5531:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5537:      	addq	$0x10, %rsi
    553b:      	movl	$0x1, %eax
    5540:      	movq	(%rip), %rdi            # 0x5547 <generic_rawtp_process_filter+0x1917>
    5547:      	callq	*%rax
    5549:      	testq	%rax, %rax
    554c:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    5552:      	movq	%rax, %rsi
    5555:      	movl	(%rax), %eax
    5557:      	cmpq	%rax, %r15
    555a:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    5560:      	movl	0x10(%rsi), %eax
    5563:      	cmpq	%rax, %r15
    5566:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    556c:      	addq	$0x10, %rsi
    5570:      	movl	$0x1, %eax
    5575:      	movq	(%rip), %rdi            # 0x557c <generic_rawtp_process_filter+0x194c>
    557c:      	callq	*%rax
    557e:      	testq	%rax, %rax
    5581:      	movq	0x30(%rsp), %r12
    5586:      	movq	0x28(%rsp), %r14
    558b:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    5591:      	movq	%rax, %rsi
    5594:      	movl	(%rax), %eax
    5596:      	cmpq	%rax, %r15
    5599:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    559f:      	movl	0x10(%rsi), %eax
    55a2:      	cmpq	%rax, %r15
    55a5:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    55ab:      	addq	$0x10, %rsi
    55af:      	movl	$0x1, %eax
    55b4:      	movq	(%rip), %rdi            # 0x55bb <generic_rawtp_process_filter+0x198b>
    55bb:      	callq	*%rax
    55bd:      	testq	%rax, %rax
    55c0:      	movq	0x30(%rsp), %r12
    55c5:      	movq	0x28(%rsp), %r14
    55ca:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    55d0:      	movq	%rax, %rsi
    55d3:      	movl	(%rax), %eax
    55d5:      	cmpq	%rax, %r15
    55d8:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    55de:      	movl	0x10(%rsi), %eax
    55e1:      	cmpq	%rax, %r15
    55e4:      	movq	0x30(%rsp), %r12
    55e9:      	movq	0x28(%rsp), %r14
    55ee:      	movq	0x8(%rsp), %r10
    55f3:      	movl	0x4(%rsp), %edi
    55f7:      	movq	0x20(%rsp), %r8
    55fc:      	movq	0x18(%rsp), %r9
    5601:      	movq	0x10(%rsp), %r11
    5606:      	je	0x53c5 <generic_rawtp_process_filter+0x1795>
    560c:      	addq	$0x10, %rsi
    5610:      	movl	$0x1, %eax
    5615:      	movq	(%rip), %rcx            # 0x561c <generic_rawtp_process_filter+0x19ec>
    561c:      	jmp	0x580e <generic_rawtp_process_filter+0x1bde>
    5621:      	movl	$0x4, %esi
    5626:      	xorl	%edx, %edx
    5628:      	divq	%rsi
    562b:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5630:      	movl	(%r10,%rax,4), %r15d
    5634:      	testb	$0x2, %r8b
    5638:      	jne	0x540c <generic_rawtp_process_filter+0x17dc>
    563e:      	cmpl	$0x5, %edi
    5641:      	jne	0x564c <generic_rawtp_process_filter+0x1a1c>
    5643:      	cmpq	%rcx, %r15
    5646:      	jne	0x584a <generic_rawtp_process_filter+0x1c1a>
    564c:      	cmpq	%rcx, %r15
    564f:      	setne	%al
    5652:      	cmpl	$0x6, %edi
    5655:      	setne	%r13b
    5659:      	jmp	0x53cf <generic_rawtp_process_filter+0x179f>
    565e:      	movq	0xe0(%rsp), %rax
    5666:      	movl	(%rax), %eax
    5668:      	testq	%rax, %rax
    566b:      	je	0x584a <generic_rawtp_process_filter+0x1c1a>
    5671:      	movb	$0x1, %r13b
    5674:      	testq	%r15, %r15
    5677:      	je	0x53c5 <generic_rawtp_process_filter+0x1795>
    567d:      	cmpq	%rax, %r15
    5680:      	je	0x53c5 <generic_rawtp_process_filter+0x1795>
    5686:      	movl	$0x1, %eax
    568b:      	movq	0xd0(%rsp), %rsi
    5693:      	movq	(%rip), %rdi            # 0x569a <generic_rawtp_process_filter+0x1a6a>
    569a:      	callq	*%rax
    569c:      	testq	%rax, %rax
    569f:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    56a5:      	movq	%rax, %rsi
    56a8:      	movl	0x24(%rax), %eax
    56ab:      	cmpq	%rax, %r15
    56ae:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    56b4:      	addq	$0x10, %rsi
    56b8:      	movl	$0x1, %eax
    56bd:      	movq	(%rip), %rdi            # 0x56c4 <generic_rawtp_process_filter+0x1a94>
    56c4:      	callq	*%rax
    56c6:      	testq	%rax, %rax
    56c9:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    56cf:      	movq	%rax, %rsi
    56d2:      	movl	0x24(%rax), %eax
    56d5:      	cmpq	%rax, %r15
    56d8:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    56de:      	addq	$0x10, %rsi
    56e2:      	movl	$0x1, %eax
    56e7:      	movq	(%rip), %rdi            # 0x56ee <generic_rawtp_process_filter+0x1abe>
    56ee:      	callq	*%rax
    56f0:      	testq	%rax, %rax
    56f3:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    56f9:      	movq	%rax, %rsi
    56fc:      	movl	0x24(%rax), %eax
    56ff:      	cmpq	%rax, %r15
    5702:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5708:      	addq	$0x10, %rsi
    570c:      	movl	$0x1, %eax
    5711:      	movq	(%rip), %rdi            # 0x5718 <generic_rawtp_process_filter+0x1ae8>
    5718:      	callq	*%rax
    571a:      	testq	%rax, %rax
    571d:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    5723:      	movq	%rax, %rsi
    5726:      	movl	0x24(%rax), %eax
    5729:      	cmpq	%rax, %r15
    572c:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    5732:      	addq	$0x10, %rsi
    5736:      	movl	$0x1, %eax
    573b:      	movq	(%rip), %rdi            # 0x5742 <generic_rawtp_process_filter+0x1b12>
    5742:      	callq	*%rax
    5744:      	testq	%rax, %rax
    5747:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    574d:      	movq	%rax, %rsi
    5750:      	movl	0x24(%rax), %eax
    5753:      	cmpq	%rax, %r15
    5756:      	je	0x53ad <generic_rawtp_process_filter+0x177d>
    575c:      	addq	$0x10, %rsi
    5760:      	movl	$0x1, %eax
    5765:      	movq	(%rip), %rdi            # 0x576c <generic_rawtp_process_filter+0x1b3c>
    576c:      	callq	*%rax
    576e:      	testq	%rax, %rax
    5771:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    5777:      	movq	%rax, %rsi
    577a:      	movl	0x24(%rax), %eax
    577d:      	cmpq	%rax, %r15
    5780:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    5786:      	addq	$0x10, %rsi
    578a:      	movl	$0x1, %eax
    578f:      	movq	(%rip), %rdi            # 0x5796 <generic_rawtp_process_filter+0x1b66>
    5796:      	callq	*%rax
    5798:      	testq	%rax, %rax
    579b:      	movq	0x30(%rsp), %r12
    57a0:      	movq	0x28(%rsp), %r14
    57a5:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    57a7:      	movq	%rax, %rsi
    57aa:      	movl	0x24(%rax), %eax
    57ad:      	cmpq	%rax, %r15
    57b0:      	je	0x53a3 <generic_rawtp_process_filter+0x1773>
    57b6:      	addq	$0x10, %rsi
    57ba:      	movl	$0x1, %eax
    57bf:      	movq	(%rip), %rdi            # 0x57c6 <generic_rawtp_process_filter+0x1b96>
    57c6:      	callq	*%rax
    57c8:      	testq	%rax, %rax
    57cb:      	movq	0x30(%rsp), %r12
    57d0:      	movq	0x28(%rsp), %r14
    57d5:      	je	0x5821 <generic_rawtp_process_filter+0x1bf1>
    57d7:      	movq	%rax, %rsi
    57da:      	movl	0x24(%rax), %eax
    57dd:      	cmpq	%rax, %r15
    57e0:      	movq	0x8(%rsp), %r10
    57e5:      	movl	0x4(%rsp), %edi
    57e9:      	movq	0x20(%rsp), %r8
    57ee:      	movq	0x18(%rsp), %r9
    57f3:      	movq	0x10(%rsp), %r11
    57f8:      	je	0x53c5 <generic_rawtp_process_filter+0x1795>
    57fe:      	addq	$0x10, %rsi
    5802:      	movl	$0x1, %eax
    5807:      	movq	(%rip), %rcx            # 0x580e <generic_rawtp_process_filter+0x1bde>
    580e:      	movq	(%rip), %rdi            # 0x5815 <generic_rawtp_process_filter+0x1be5>
    5815:      	callq	*%rax
    5817:      	movq	0x30(%rsp), %r12
    581c:      	movq	0x28(%rsp), %r14
    5821:      	xorl	%r13d, %r13d
    5824:      	movl	0x4(%rsp), %edi
    5828:      	cmpl	$0x5, %edi
    582b:      	movq	0x8(%rsp), %r10
    5830:      	movq	0x20(%rsp), %r8
    5835:      	movq	0x18(%rsp), %r9
    583a:      	movq	0x10(%rsp), %r11
    583f:      	jne	0x53c5 <generic_rawtp_process_filter+0x1795>
    5845:      	jmp	0x53d2 <generic_rawtp_process_filter+0x17a2>
    584a:      	xorl	%r13d, %r13d
    584d:      	jmp	0x53d2 <generic_rawtp_process_filter+0x17a2>
    5852:      	movl	0x50(%rsp), %esi
    5856:      	movl	0x54(%rsp), %ecx
    585a:      	movl	0x58(%rsp), %eax
    585e:      	movl	0x5c(%rsp), %edx
    5862:      	cmpl	$0x6, %edi
    5865:      	jne	0x586f <generic_rawtp_process_filter+0x1c3f>
    5867:      	andl	%esi, %ecx
    5869:      	andl	%edx, %eax
    586b:      	andl	%ecx, %eax
    586d:      	jmp	0x5875 <generic_rawtp_process_filter+0x1c45>
    586f:      	orl	%esi, %ecx
    5871:      	orl	%edx, %eax
    5873:      	orl	%ecx, %eax
    5875:      	testl	%eax, %eax
    5877:      	movq	0xd8(%rsp), %rdx
    587f:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5885:      	addl	$0x14, %edx
    5888:      	movl	0x8(%r10,%rbp), %ecx
    588d:      	andl	$0x7, %ecx
    5890:      	leal	(%rdx,%rcx,4), %ebp
    5893:      	movl	%ebp, %ecx
    5895:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    589b:      	movl	(%rcx,%r10), %ecx
    589f:      	addl	$0x4, %ebp
    58a2:      	addl	$-0x4, %ecx
    58a5:      	xorl	%esi, %esi
    58a7:      	movl	$0x4, %r8d
    58ad:      	jmp	0x58bf <generic_rawtp_process_filter+0x1c8f>
    58af:      	nop
    58b0:      	xorl	%ecx, %ecx
    58b2:      	incq	%rsi
    58b5:      	cmpq	$0xa, %rsi
    58b9:      	je	0x5a48 <generic_rawtp_process_filter+0x1e18>
    58bf:      	testl	%ecx, %ecx
    58c1:      	je	0x58b0 <generic_rawtp_process_filter+0x1c80>
    58c3:      	movl	%ebp, %r9d
    58c6:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    58cd:      	movl	(%r9,%r10), %r11d
    58d1:      	movq	%r10, %rax
    58d4:      	movl	0x4(%r9,%r10), %r10d
    58d9:      	movl	0x8(%r9,%rax), %edx
    58de:      	movq	$0x0, 0x58(%rsp)
    58e7:      	movq	$0x0, 0x50(%rsp)
    58f0:      	cmpl	$0x4, %edx
    58f3:      	movl	$0x4, %eax
    58f8:      	cmovbl	%edx, %eax
    58fb:      	cmpl	$0x6, %r10d
    58ff:      	jne	0x5915 <generic_rawtp_process_filter+0x1ce5>
    5901:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    590b:      	movq	%rdi, 0x50(%rsp)
    5910:      	movq	%rdi, 0x58(%rsp)
    5915:      	addl	$0xc, %ebp
    5918:      	testl	%edx, %edx
    591a:      	je	0x59f0 <generic_rawtp_process_filter+0x1dc0>
    5920:      	andl	$0xf, %r11d
    5924:      	decq	%rax
    5927:      	cmpq	$0x3, %rax
    592b:      	movl	$0x3, %edx
    5930:      	cmovaeq	%rdx, %rax
    5934:      	leaq	0x4(,%rax,4), %rbx
    593c:      	movl	%ebp, %r14d
    593f:      	cmpl	$0x9, %r11d
    5943:      	jbe	0x597a <generic_rawtp_process_filter+0x1d4a>
    5945:      	xorl	%r11d, %r11d
    5948:      	jmp	0x5966 <generic_rawtp_process_filter+0x1d36>
    594a:      	nopw	(%rax,%rax)
    5950:      	movl	$0x0, 0x50(%rsp,%r11)
    5959:      	addq	$0x4, %r11
    595d:      	cmpq	%r11, %rbx
    5960:      	je	0x59f0 <generic_rawtp_process_filter+0x1dc0>
    5966:      	leaq	(%r14,%r11), %rax
    596a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    596f:      	ja	0x5950 <generic_rawtp_process_filter+0x1d20>
    5971:      	movl	%eax, %eax
    5973:      	xorl	%edx, %edx
    5975:      	divq	%r8
    5978:      	jmp	0x5950 <generic_rawtp_process_filter+0x1d20>
    597a:      	xorl	%r15d, %r15d
    597d:      	jmp	0x59c1 <generic_rawtp_process_filter+0x1d91>
    597f:      	nop
    5980:      	cmpl	$0x5, %r10d
    5984:      	setne	%dl
    5987:      	movl	%r10d, %r13d
    598a:      	xorl	$0x6, %r13d
    598e:      	movq	0x30(%rsp), %rax
    5993:      	movl	0x20(%rax,%r11,4), %edi
    5998:      	movl	%r12d, %eax
    599b:      	xorl	%edi, %eax
    599d:      	cmpl	%edi, %r12d
    59a0:      	sete	%dil
    59a4:      	orb	%dl, %dil
    59a7:      	orl	%r13d, %eax
    59aa:      	setne	%al
    59ad:      	andb	%dil, %al
    59b0:      	movzbl	%al, %eax
    59b3:      	movl	%eax, 0x50(%rsp,%r15)
    59b8:      	addq	$0x4, %r15
    59bc:      	cmpq	%r15, %rbx
    59bf:      	je	0x59f0 <generic_rawtp_process_filter+0x1dc0>
    59c1:      	leaq	(%r14,%r15), %rdx
    59c5:      	xorl	%r12d, %r12d
    59c8:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    59ce:      	ja	0x5980 <generic_rawtp_process_filter+0x1d50>
    59d0:      	movl	%edx, %eax
    59d2:      	xorl	%edx, %edx
    59d4:      	divq	%r8
    59d7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    59dc:      	movq	0x8(%rsp), %rdx
    59e1:      	movl	(%rdx,%rax,4), %r12d
    59e5:      	jmp	0x5980 <generic_rawtp_process_filter+0x1d50>
    59e7:      	nopw	(%rax,%rax)
    59f0:      	movl	0x50(%rsp), %ebx
    59f4:      	movl	0x54(%rsp), %edx
    59f8:      	movl	0x58(%rsp), %eax
    59fc:      	movl	0x5c(%rsp), %r11d
    5a01:      	cmpl	$0x6, %r10d
    5a05:      	jne	0x5a10 <generic_rawtp_process_filter+0x1de0>
    5a07:      	andl	%ebx, %edx
    5a09:      	andl	%r11d, %eax
    5a0c:      	andl	%edx, %eax
    5a0e:      	jmp	0x5a17 <generic_rawtp_process_filter+0x1de7>
    5a10:      	orl	%ebx, %edx
    5a12:      	orl	%r11d, %eax
    5a15:      	orl	%edx, %eax
    5a17:      	movq	0x30(%rsp), %r12
    5a1c:      	movq	0x8(%rsp), %r10
    5a21:      	testl	%eax, %eax
    5a23:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5a29:      	movl	0x8(%r10,%r9), %edx
    5a2e:      	shll	$0x2, %edx
    5a31:      	subl	%edx, %ecx
    5a33:      	andl	$0x1c, %edx
    5a36:      	addl	%edx, %ebp
    5a38:      	addl	$-0xc, %ecx
    5a3b:      	incq	%rsi
    5a3e:      	cmpq	$0xa, %rsi
    5a42:      	jne	0x58bf <generic_rawtp_process_filter+0x1c8f>
    5a48:      	movl	%ebp, %ecx
    5a4a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5a50:      	leal	0x4(%rbp), %ebx
    5a53:      	cmpl	$0x4, (%rcx,%r10)
    5a58:      	je	0x5ab3 <generic_rawtp_process_filter+0x1e83>
    5a5a:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5a60:      	movl	(%rbx,%r10), %ecx
    5a64:      	movl	0x4(%rbx,%r10), %edx
    5a69:      	movl	0x8(%rbx,%r10), %edi
    5a6e:      	movq	0xc(%rbx,%r10), %rax
    5a73:      	testl	%edi, %edi
    5a75:      	je	0x5a87 <generic_rawtp_process_filter+0x1e57>
    5a77:      	xorl	%esi, %esi
    5a79:      	cmpl	$0x2, %ecx
    5a7c:      	ja	0x5aaa <generic_rawtp_process_filter+0x1e7a>
    5a7e:      	cmpl	%edi, 0x44(%r12)
    5a83:      	jne	0x5a90 <generic_rawtp_process_filter+0x1e60>
    5a85:      	jmp	0x5aaa <generic_rawtp_process_filter+0x1e7a>
    5a87:      	cmpl	$0x2, %ecx
    5a8a:      	jbe	0x5a90 <generic_rawtp_process_filter+0x1e60>
    5a8c:      	xorl	%esi, %esi
    5a8e:      	jmp	0x5aaa <generic_rawtp_process_filter+0x1e7a>
    5a90:      	andq	0x48(%r12,%rcx,8), %rax
    5a95:      	cmpl	$0x5, %edx
    5a98:      	jne	0x5aa3 <generic_rawtp_process_filter+0x1e73>
    5a9a:      	testq	%rax, %rax
    5a9d:      	setne	%sil
    5aa1:      	jmp	0x5aaa <generic_rawtp_process_filter+0x1e7a>
    5aa3:      	testq	%rax, %rax
    5aa6:      	sete	%sil
    5aaa:      	addl	$0x18, %ebp
    5aad:      	movzbl	%sil, %eax
    5ab1:      	movl	%ebp, %ebx
    5ab3:      	testl	%eax, %eax
    5ab5:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5abb:      	movl	%ebx, %ecx
    5abd:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5ac3:      	leal	0x4(%rbx), %eax
    5ac6:      	cmpl	$0x4, (%rcx,%r10)
    5acb:      	je	0x5d9f <generic_rawtp_process_filter+0x216f>
    5ad1:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5ad6:      	movl	(%rax,%r10), %r14d
    5ada:      	movl	0x4(%rax,%r10), %ebp
    5adf:      	movl	$0xe, %eax
    5ae4:      	callq	*%rax
    5ae6:      	shrq	$0x20, %rax
    5aea:      	movl	%eax, 0x50(%rsp)
    5aee:      	movq	(%rip), %rdi            # 0x5af5 <generic_rawtp_process_filter+0x1ec5>
    5af5:      	leaq	0x50(%rsp), %rsi
    5afa:      	movl	$0x1, %eax
    5aff:      	callq	*%rax
    5b01:      	movq	0x8(%rsp), %r10
    5b06:      	testq	%rax, %rax
    5b09:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5b0f:      	cmpl	$0x5, %r14d
    5b13:      	je	0x5b42 <generic_rawtp_process_filter+0x1f12>
    5b15:      	cmpl	$0x6, %r14d
    5b19:      	jne	0x5e8c <generic_rawtp_process_filter+0x225c>
    5b1f:      	movq	%r12, %rcx
    5b22:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5b29:      	testb	$0x1, %bpl
    5b2d:      	jne	0x5b6c <generic_rawtp_process_filter+0x1f3c>
    5b2f:      	movl	0x28(%rax), %edx
    5b32:      	testl	%edx, %edx
    5b34:      	je	0x5b65 <generic_rawtp_process_filter+0x1f35>
    5b36:      	cmpl	0x20(%r12), %edx
    5b3b:      	je	0x5b6c <generic_rawtp_process_filter+0x1f3c>
    5b3d:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5b42:      	movq	%r12, %rcx
    5b45:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5b4c:      	testb	$0x1, %bpl
    5b50:      	je	0x5b8c <generic_rawtp_process_filter+0x1f5c>
    5b52:      	movl	0x28(%rax), %edx
    5b55:      	testl	%edx, %edx
    5b57:      	je	0x5b85 <generic_rawtp_process_filter+0x1f55>
    5b59:      	cmpl	0x20(%r12), %edx
    5b5e:      	je	0x5b8c <generic_rawtp_process_filter+0x1f5c>
    5b60:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5b65:      	movq	$0x1, (%rcx)
    5b6c:      	testb	$0x2, %bpl
    5b70:      	jne	0x5bac <generic_rawtp_process_filter+0x1f7c>
    5b72:      	movl	0x2c(%rax), %edx
    5b75:      	testl	%edx, %edx
    5b77:      	je	0x5ba5 <generic_rawtp_process_filter+0x1f75>
    5b79:      	cmpl	0x24(%r12), %edx
    5b7e:      	je	0x5bac <generic_rawtp_process_filter+0x1f7c>
    5b80:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5b85:      	movq	$0x1, (%rcx)
    5b8c:      	testb	$0x2, %bpl
    5b90:      	je	0x5bcc <generic_rawtp_process_filter+0x1f9c>
    5b92:      	movl	0x2c(%rax), %edx
    5b95:      	testl	%edx, %edx
    5b97:      	je	0x5bc5 <generic_rawtp_process_filter+0x1f95>
    5b99:      	cmpl	0x24(%r12), %edx
    5b9e:      	je	0x5bcc <generic_rawtp_process_filter+0x1f9c>
    5ba0:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5ba5:      	movq	$0x1, (%rcx)
    5bac:      	testb	$0x4, %bpl
    5bb0:      	jne	0x5bec <generic_rawtp_process_filter+0x1fbc>
    5bb2:      	movl	0x30(%rax), %edx
    5bb5:      	testl	%edx, %edx
    5bb7:      	je	0x5be5 <generic_rawtp_process_filter+0x1fb5>
    5bb9:      	cmpl	0x28(%r12), %edx
    5bbe:      	je	0x5bec <generic_rawtp_process_filter+0x1fbc>
    5bc0:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5bc5:      	movq	$0x1, (%rcx)
    5bcc:      	testb	$0x4, %bpl
    5bd0:      	je	0x5c0c <generic_rawtp_process_filter+0x1fdc>
    5bd2:      	movl	0x30(%rax), %edx
    5bd5:      	testl	%edx, %edx
    5bd7:      	je	0x5c05 <generic_rawtp_process_filter+0x1fd5>
    5bd9:      	cmpl	0x28(%r12), %edx
    5bde:      	je	0x5c0c <generic_rawtp_process_filter+0x1fdc>
    5be0:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5be5:      	movq	$0x1, (%rcx)
    5bec:      	testb	$0x8, %bpl
    5bf0:      	jne	0x5c2c <generic_rawtp_process_filter+0x1ffc>
    5bf2:      	movl	0x34(%rax), %edx
    5bf5:      	testl	%edx, %edx
    5bf7:      	je	0x5c25 <generic_rawtp_process_filter+0x1ff5>
    5bf9:      	cmpl	0x2c(%r12), %edx
    5bfe:      	je	0x5c2c <generic_rawtp_process_filter+0x1ffc>
    5c00:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5c05:      	movq	$0x1, (%rcx)
    5c0c:      	testb	$0x8, %bpl
    5c10:      	je	0x5c4c <generic_rawtp_process_filter+0x201c>
    5c12:      	movl	0x34(%rax), %edx
    5c15:      	testl	%edx, %edx
    5c17:      	je	0x5c45 <generic_rawtp_process_filter+0x2015>
    5c19:      	cmpl	0x2c(%r12), %edx
    5c1e:      	je	0x5c4c <generic_rawtp_process_filter+0x201c>
    5c20:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5c25:      	movq	$0x1, (%rcx)
    5c2c:      	testb	$0x10, %bpl
    5c30:      	jne	0x5c6c <generic_rawtp_process_filter+0x203c>
    5c32:      	movl	0x38(%rax), %edx
    5c35:      	testl	%edx, %edx
    5c37:      	je	0x5c65 <generic_rawtp_process_filter+0x2035>
    5c39:      	cmpl	0x30(%r12), %edx
    5c3e:      	je	0x5c6c <generic_rawtp_process_filter+0x203c>
    5c40:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5c45:      	movq	$0x1, (%rcx)
    5c4c:      	testb	$0x10, %bpl
    5c50:      	je	0x5c8c <generic_rawtp_process_filter+0x205c>
    5c52:      	movl	0x38(%rax), %edx
    5c55:      	testl	%edx, %edx
    5c57:      	je	0x5c85 <generic_rawtp_process_filter+0x2055>
    5c59:      	cmpl	0x30(%r12), %edx
    5c5e:      	je	0x5c8c <generic_rawtp_process_filter+0x205c>
    5c60:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5c65:      	movq	$0x1, (%rcx)
    5c6c:      	testb	$0x20, %bpl
    5c70:      	jne	0x5cac <generic_rawtp_process_filter+0x207c>
    5c72:      	movl	0x3c(%rax), %edx
    5c75:      	testl	%edx, %edx
    5c77:      	je	0x5ca5 <generic_rawtp_process_filter+0x2075>
    5c79:      	cmpl	0x34(%r12), %edx
    5c7e:      	je	0x5cac <generic_rawtp_process_filter+0x207c>
    5c80:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5c85:      	movq	$0x1, (%rcx)
    5c8c:      	testb	$0x20, %bpl
    5c90:      	je	0x5ccc <generic_rawtp_process_filter+0x209c>
    5c92:      	movl	0x3c(%rax), %edx
    5c95:      	testl	%edx, %edx
    5c97:      	je	0x5cc5 <generic_rawtp_process_filter+0x2095>
    5c99:      	cmpl	0x34(%r12), %edx
    5c9e:      	je	0x5ccc <generic_rawtp_process_filter+0x209c>
    5ca0:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5ca5:      	movq	$0x1, (%rcx)
    5cac:      	testb	$0x40, %bpl
    5cb0:      	jne	0x5cec <generic_rawtp_process_filter+0x20bc>
    5cb2:      	movl	0x40(%rax), %edx
    5cb5:      	testl	%edx, %edx
    5cb7:      	je	0x5ce5 <generic_rawtp_process_filter+0x20b5>
    5cb9:      	cmpl	0x38(%r12), %edx
    5cbe:      	je	0x5cec <generic_rawtp_process_filter+0x20bc>
    5cc0:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5cc5:      	movq	$0x1, (%rcx)
    5ccc:      	testb	$0x40, %bpl
    5cd0:      	je	0x5d0b <generic_rawtp_process_filter+0x20db>
    5cd2:      	movl	0x40(%rax), %edx
    5cd5:      	testl	%edx, %edx
    5cd7:      	je	0x5d04 <generic_rawtp_process_filter+0x20d4>
    5cd9:      	cmpl	0x38(%r12), %edx
    5cde:      	je	0x5d0b <generic_rawtp_process_filter+0x20db>
    5ce0:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5ce5:      	movq	$0x1, (%rcx)
    5cec:      	testb	%bpl, %bpl
    5cef:      	js	0x5d27 <generic_rawtp_process_filter+0x20f7>
    5cf1:      	movl	0x44(%rax), %edx
    5cf4:      	testl	%edx, %edx
    5cf6:      	je	0x5d20 <generic_rawtp_process_filter+0x20f0>
    5cf8:      	cmpl	0x3c(%r12), %edx
    5cfd:      	je	0x5d27 <generic_rawtp_process_filter+0x20f7>
    5cff:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5d04:      	movq	$0x1, (%rcx)
    5d0b:      	testb	%bpl, %bpl
    5d0e:      	jns	0x5d46 <generic_rawtp_process_filter+0x2116>
    5d10:      	movl	0x44(%rax), %edx
    5d13:      	testl	%edx, %edx
    5d15:      	je	0x5d3f <generic_rawtp_process_filter+0x210f>
    5d17:      	cmpl	0x3c(%r12), %edx
    5d1c:      	je	0x5d46 <generic_rawtp_process_filter+0x2116>
    5d1e:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5d20:      	movq	$0x1, (%rcx)
    5d27:      	testl	$0x100, %ebp            # imm = 0x100
    5d2d:      	jne	0x5d71 <generic_rawtp_process_filter+0x2141>
    5d2f:      	movl	0x48(%rax), %edx
    5d32:      	testl	%edx, %edx
    5d34:      	je	0x5d6a <generic_rawtp_process_filter+0x213a>
    5d36:      	cmpl	0x40(%r12), %edx
    5d3b:      	je	0x5d71 <generic_rawtp_process_filter+0x2141>
    5d3d:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5d3f:      	movq	$0x1, (%rcx)
    5d46:      	testl	$0x100, %ebp            # imm = 0x100
    5d4c:      	je	0x5e72 <generic_rawtp_process_filter+0x2242>
    5d52:      	movl	0x48(%rax), %edx
    5d55:      	testl	%edx, %edx
    5d57:      	je	0x5e6b <generic_rawtp_process_filter+0x223b>
    5d5d:      	cmpl	0x40(%r12), %edx
    5d62:      	je	0x5e72 <generic_rawtp_process_filter+0x2242>
    5d68:      	jmp	0x5d93 <generic_rawtp_process_filter+0x2163>
    5d6a:      	movq	$0x1, (%rcx)
    5d71:      	testl	$0x200, %ebp            # imm = 0x200
    5d77:      	jne	0x5e8c <generic_rawtp_process_filter+0x225c>
    5d7d:      	movl	0x4c(%rax), %eax
    5d80:      	testl	%eax, %eax
    5d82:      	je	0x5e85 <generic_rawtp_process_filter+0x2255>
    5d88:      	cmpl	0x44(%r12), %eax
    5d8d:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5d93:      	addl	$0xc, %ebx
    5d96:      	movq	$0x1, (%rcx)
    5d9d:      	movl	%ebx, %eax
    5d9f:      	movl	%eax, %ecx
    5da1:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5da7:      	cmpl	$0x4, (%rcx,%r10)
    5dac:      	jne	0x5dd9 <generic_rawtp_process_filter+0x21a9>
    5dae:      	movq	0x5eb8(%r12), %rax
    5db6:      	andl	$0x1f, %eax
    5db9:      	movb	$0x1, 0x5ec1(%r12,%rax)
    5dc2:      	movb	$0x1, 0x5ee0(%r12)
    5dcb:      	movb	$0x1, 0x5ec0(%r12)
    5dd4:      	jmp	0x5e8c <generic_rawtp_process_filter+0x225c>
    5dd9:      	addl	$0x4, %eax
    5ddc:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5de1:      	movl	(%rax,%r10), %r14d
    5de5:      	movl	0x4(%rax,%r10), %ebx
    5dea:      	movl	0x8(%rax,%r10), %ebp
    5def:      	movq	0xc(%rax,%r10), %r15
    5df4:      	movl	$0xe, %eax
    5df9:      	callq	*%rax
    5dfb:      	shrq	$0x20, %rax
    5dff:      	movl	%eax, 0x50(%rsp)
    5e03:      	movq	(%rip), %rdi            # 0x5e0a <generic_rawtp_process_filter+0x21da>
    5e0a:      	leaq	0x50(%rsp), %rsi
    5e0f:      	movl	$0x1, %eax
    5e14:      	callq	*%rax
    5e16:      	testq	%rax, %rax
    5e19:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e1b:      	testl	%ebp, %ebp
    5e1d:      	je	0x5e2e <generic_rawtp_process_filter+0x21fe>
    5e1f:      	cmpl	$0x2, %r14d
    5e23:      	ja	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e25:      	cmpl	%ebp, 0x44(%r12)
    5e2a:      	jne	0x5e34 <generic_rawtp_process_filter+0x2204>
    5e2c:      	jmp	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e2e:      	cmpl	$0x2, %r14d
    5e32:      	ja	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e34:      	movq	0x50(%rax,%r14,8), %rax
    5e39:      	movq	0x48(%r12,%r14,8), %rcx
    5e3e:      	movq	%rcx, %rdx
    5e41:      	xorq	%rax, %rdx
    5e44:      	testq	%r15, %rdx
    5e47:      	je	0x5e50 <generic_rawtp_process_filter+0x2220>
    5e49:      	cmpl	$0x5, %ebx
    5e4c:      	jne	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e4e:      	jmp	0x5e5a <generic_rawtp_process_filter+0x222a>
    5e50:      	cmpq	%rcx, %rax
    5e53:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e55:      	cmpl	$0x6, %ebx
    5e58:      	jne	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e5a:      	movq	$0x1, 0x5ef0(%r12)
    5e66:      	jmp	0x5dae <generic_rawtp_process_filter+0x217e>
    5e6b:      	movq	$0x1, (%rcx)
    5e72:      	testl	$0x200, %ebp            # imm = 0x200
    5e78:      	je	0x5e8c <generic_rawtp_process_filter+0x225c>
    5e7a:      	movl	0x4c(%rax), %eax
    5e7d:      	testl	%eax, %eax
    5e7f:      	jne	0x5d88 <generic_rawtp_process_filter+0x2158>
    5e85:      	movq	$0x1, (%rcx)
    5e8c:      	movq	0x5eb8(%r12), %rax
    5e94:      	incq	%rax
    5e97:      	movq	%rax, 0x5eb8(%r12)
    5e9f:      	cmpq	0xb8(%rsp), %rax
    5ea7:      	jbe	0x5efa <generic_rawtp_process_filter+0x22ca>
    5ea9:      	movq	0x28(%rsp), %rcx
    5eae:      	movl	(%rcx), %eax
    5eb0:      	movl	%eax, 0x10(%r12)
    5eb5:      	movq	0x8(%rcx), %rax
    5eb9:      	movq	%rax, 0x18(%r12)
    5ebe:      	cmpb	$0x0, 0x5ec0(%r12)
    5ec7:      	movq	0xb0(%rsp), %rbp
    5ecf:      	je	0x5ee6 <generic_rawtp_process_filter+0x22b6>
    5ed1:      	movq	(%rip), %rsi            # 0x5ed8 <generic_rawtp_process_filter+0x22a8>
    5ed8:      	xorl	%ecx, %ecx
    5eda:      	movl	$0xc, %eax
    5edf:      	movq	%rbp, %rdi
    5ee2:      	xorl	%edx, %edx
    5ee4:      	callq	*%rax
    5ee6:      	xorl	%eax, %eax
    5ee8:      	addq	$0xf8, %rsp
    5eef:      	popq	%rbx
    5ef0:      	popq	%r12
    5ef2:      	popq	%r13
    5ef4:      	popq	%r14
    5ef6:      	popq	%r15
    5ef8:      	popq	%rbp
    5ef9:      	retq
    5efa:      	movq	(%rip), %rsi            # 0x5f01 <generic_rawtp_process_filter+0x22d1>
    5f01:      	movl	$0x2, %ecx
    5f06:      	movl	$0xc, %eax
    5f0b:      	movq	0xb0(%rsp), %rdi
    5f13:      	movl	$0x2, %edx
    5f18:      	jmp	0x5ee4 <generic_rawtp_process_filter+0x22b4>
    5f1a:      	nopw	(%rax,%rax)

0000000000005f20 <generic_rawtp_filter_arg>:
    5f20:      	pushq	%rbp
    5f21:      	pushq	%r15
    5f23:      	pushq	%r14
    5f25:      	pushq	%r13
    5f27:      	pushq	%r12
    5f29:      	pushq	%rbx
    5f2a:      	subq	$0xc8, %rsp
    5f31:      	movq	%rdi, %r13
    5f34:      	movl	$0x0, 0xb4(%rsp)
    5f3f:      	movq	(%rip), %rdi            # 0x5f46 <generic_rawtp_filter_arg+0x26>
    5f46:      	leaq	0xb4(%rsp), %rsi
    5f4e:      	movl	$0x1, %eax
    5f53:      	callq	*%rax
    5f55:      	testq	%rax, %rax
    5f58:      	je	0x60f3 <generic_rawtp_filter_arg+0x1d3>
    5f5e:      	movq	%rax, %r14
    5f61:      	movl	0x5f00(%rax), %ebx
    5f67:      	leaq	0x5ef8(%rax), %rsi
    5f6e:      	movq	(%rip), %rdi            # 0x5f75 <generic_rawtp_filter_arg+0x55>
    5f75:      	movl	$0x1, %eax
    5f7a:      	callq	*%rax
    5f7c:      	testq	%rax, %rax
    5f7f:      	je	0x60d8 <generic_rawtp_filter_arg+0x1b8>
    5f85:      	cmpb	$0x0, 0x5ee0(%r14)
    5f8d:      	je	0x60d8 <generic_rawtp_filter_arg+0x1b8>
    5f93:      	movq	%rax, %r15
    5f96:      	movl	%ebx, %eax
    5f98:      	andl	$0x7, %eax
    5f9b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    5fa4:      	je	0x602d <generic_rawtp_filter_arg+0x10d>
    5faa:      	movl	%eax, %eax
    5fac:      	movl	0x4(%r15,%rax,4), %ecx
    5fb1:      	leaq	(%rcx,%rax,4), %rdx
    5fb5:      	addq	$0x4, %rdx
    5fb9:      	leaq	(%rcx,%rax,4), %rax
    5fbd:      	addq	$0x8, %rax
    5fc1:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5fc6:      	movl	(%rax,%r15), %eax
    5fca:      	addq	%rdx, %rax
    5fcd:      	addq	$0x4, %rax
    5fd1:      	movl	%eax, %ecx
    5fd3:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5fd9:      	movl	(%rcx,%r15), %ecx
    5fdd:      	addq	%rax, %rcx
    5fe0:      	movl	%ecx, %eax
    5fe2:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5fe7:      	movl	(%rax,%r15), %eax
    5feb:      	addq	%rcx, %rax
    5fee:      	movl	%eax, %ecx
    5ff0:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5ff6:      	movl	(%rcx,%r15), %ecx
    5ffa:      	addq	%rax, %rcx
    5ffd:      	movl	%ecx, %eax
    5fff:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6004:      	movl	(%rax,%r15), %r9d
    6008:      	addq	%rcx, %r9
    600b:      	movl	%r9d, %edi
    600e:      	andl	$0x3ff, %edi            # imm = 0x3FF
    6014:      	cmpl	$0x19, (%r15,%rdi)
    6019:      	jae	0x6079 <generic_rawtp_filter_arg+0x159>
    601b:      	cmpq	$0x1, %rdi
    601f:      	je	0x60d8 <generic_rawtp_filter_arg+0x1b8>
    6025:      	testl	%edi, %edi
    6027:      	jne	0x60b6 <generic_rawtp_filter_arg+0x196>
    602d:      	cmpl	$0x1, %ebx
    6030:      	jg	0x604e <generic_rawtp_filter_arg+0x12e>
    6032:      	cmpl	$-0x1, %ebx
    6035:      	je	0x6107 <generic_rawtp_filter_arg+0x1e7>
    603b:      	testl	%ebx, %ebx
    603d:      	je	0x6113 <generic_rawtp_filter_arg+0x1f3>
    6043:      	cmpl	$0x1, %ebx
    6046:      	je	0x6122 <generic_rawtp_filter_arg+0x202>
    604c:      	jmp	0x6069 <generic_rawtp_filter_arg+0x149>
    604e:      	cmpl	$0x2, %ebx
    6051:      	je	0x6131 <generic_rawtp_filter_arg+0x211>
    6057:      	cmpl	$0x3, %ebx
    605a:      	je	0x6140 <generic_rawtp_filter_arg+0x220>
    6060:      	cmpl	$0x4, %ebx
    6063:      	je	0x614f <generic_rawtp_filter_arg+0x22f>
    6069:      	cmpl	$0x4, %ebx
    606c:      	jg	0x6180 <generic_rawtp_filter_arg+0x260>
    6072:      	incl	%ebx
    6074:      	jmp	0x615e <generic_rawtp_filter_arg+0x23e>
    6079:      	leaq	(%r15,%rdi), %rax
    607d:      	movq	%rax, 0xc0(%rsp)
    6085:      	xorl	%r11d, %r11d
    6088:      	leaq	0x80(%rsp), %rax
    6090:      	movq	%rax, 0x38(%rsp)
    6095:      	movq	%rbx, 0xb8(%rsp)
    609d:      	movq	%rdi, 0x10(%rsp)
    60a2:      	movq	%r9, 0x18(%rsp)
    60a7:      	movq	%r15, 0x68(%rsp)
    60ac:      	movq	%r13, 0x78(%rsp)
    60b1:      	jmp	0x61f5 <generic_rawtp_filter_arg+0x2d5>
    60b6:      	movl	%edi, 0x5f04(%r14)
    60bd:      	movq	(%rip), %rsi            # 0x60c4 <generic_rawtp_filter_arg+0x1a4>
    60c4:      	movl	$0x4, %ecx
    60c9:      	movl	$0xc, %eax
    60ce:      	movq	%r13, %rdi
    60d1:      	movl	$0x4, %edx
    60d6:      	callq	*%rax
    60d8:      	movq	(%rip), %rsi            # 0x60df <generic_rawtp_filter_arg+0x1bf>
    60df:      	movl	$0x5, %ecx
    60e4:      	movl	$0xc, %eax
    60e9:      	movq	%r13, %rdi
    60ec:      	movl	$0x5, %edx
    60f1:      	callq	*%rax
    60f3:      	xorl	%eax, %eax
    60f5:      	addq	$0xc8, %rsp
    60fc:      	popq	%rbx
    60fd:      	popq	%r12
    60ff:      	popq	%r13
    6101:      	popq	%r14
    6103:      	popq	%r15
    6105:      	popq	%rbp
    6106:      	retq
    6107:      	xorl	%ebx, %ebx
    6109:      	cmpb	$0x0, 0x5ec1(%r14)
    6111:      	jne	0x615e <generic_rawtp_filter_arg+0x23e>
    6113:      	movl	$0x1, %ebx
    6118:      	cmpb	$0x0, 0x5ec2(%r14)
    6120:      	jne	0x615e <generic_rawtp_filter_arg+0x23e>
    6122:      	movl	$0x2, %ebx
    6127:      	cmpb	$0x0, 0x5ec3(%r14)
    612f:      	jne	0x615e <generic_rawtp_filter_arg+0x23e>
    6131:      	movl	$0x3, %ebx
    6136:      	cmpb	$0x0, 0x5ec4(%r14)
    613e:      	jne	0x615e <generic_rawtp_filter_arg+0x23e>
    6140:      	movl	$0x4, %ebx
    6145:      	cmpb	$0x0, 0x5ec5(%r14)
    614d:      	jne	0x615e <generic_rawtp_filter_arg+0x23e>
    614f:      	movl	$0x5, %ebx
    6154:      	cmpb	$0x0, 0x5ec6(%r14)
    615c:      	je	0x6180 <generic_rawtp_filter_arg+0x260>
    615e:      	movl	%ebx, 0x5f00(%r14)
    6165:      	movq	(%rip), %rsi            # 0x616c <generic_rawtp_filter_arg+0x24c>
    616c:      	movl	$0x3, %ecx
    6171:      	movl	$0xc, %eax
    6176:      	movq	%r13, %rdi
    6179:      	movl	$0x3, %edx
    617e:      	callq	*%rax
    6180:      	movq	0x60(%r14), %rbx
    6184:      	movl	$0xe, %eax
    6189:      	callq	*%rax
    618b:      	movq	%rbx, 0x40(%rsp)
    6190:      	movq	%rax, 0x48(%rsp)
    6195:      	movq	(%rip), %rdi            # 0x619c <generic_rawtp_filter_arg+0x27c>
    619c:      	leaq	0x40(%rsp), %rsi
    61a1:      	movl	$0x1, %eax
    61a6:      	callq	*%rax
    61a8:      	testq	%rax, %rax
    61ab:      	je	0x60f3 <generic_rawtp_filter_arg+0x1d3>
    61b1:      	movq	(%rip), %rdi            # 0x61b8 <generic_rawtp_filter_arg+0x298>
    61b8:      	leaq	0x40(%rsp), %rsi
    61bd:      	movl	$0x3, %eax
    61c2:      	callq	*%rax
    61c4:      	jmp	0x60f3 <generic_rawtp_filter_arg+0x1d3>
    61c9:      	testq	%rax, %rax
    61cc:      	setne	%cl
    61cf:      	movzbl	%cl, %ebx
    61d2:      	movq	0x78(%rsp), %r13
    61d7:      	testq	%rbx, %rbx
    61da:      	movq	0xb8(%rsp), %rbx
    61e2:      	je	0x602d <generic_rawtp_filter_arg+0x10d>
    61e8:      	incq	%r11
    61eb:      	cmpq	$0x5, %r11
    61ef:      	je	0x601b <generic_rawtp_filter_arg+0xfb>
    61f5:      	movq	0xc0(%rsp), %rax
    61fd:      	movl	0x4(%rax,%r11,4), %r12d
    6202:      	testl	$0x3ff, %r12d           # imm = 0x3FF
    6209:      	je	0x601b <generic_rawtp_filter_arg+0xfb>
    620f:      	addl	%r9d, %r12d
    6212:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    6219:      	movl	0x4(%r15,%r12), %eax
    621e:      	cmpl	$0x23, %eax
    6221:      	je	0x602d <generic_rawtp_filter_arg+0x10d>
    6227:      	addq	%r15, %r12
    622a:      	movl	(%r12), %ecx
    622e:      	cmpq	$0x4, %rcx
    6232:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    6238:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6241:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    6247:      	movq	0x5e78(%r14,%rcx,8), %rcx
    624f:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6255:      	leaq	(%r14,%rcx), %rsi
    6259:      	addq	$0x90, %rsi
    6260:      	movl	0xc(%r12), %ecx
    6265:      	cmpl	$0x10, %ecx
    6268:      	jle	0x62c4 <generic_rawtp_filter_arg+0x3a4>
    626a:      	leal	-0x1c(%rcx), %edx
    626d:      	cmpl	$0x9, %edx
    6270:      	jb	0x63ee <generic_rawtp_filter_arg+0x4ce>
    6276:      	movq	%rsi, %r8
    6279:      	cmpl	$0x2a, %ecx
    627c:      	ja	0x6713 <generic_rawtp_filter_arg+0x7f3>
    6282:      	movl	%ecx, %edx
    6284:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
    628e:      	btq	%rdx, %rsi
    6292:      	jb	0x62ec <generic_rawtp_filter_arg+0x3cc>
    6294:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
    629e:      	btq	%rdx, %rsi
    62a2:      	jb	0x634b <generic_rawtp_filter_arg+0x42b>
    62a8:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
    62b2:      	btq	%rdx, %rsi
    62b6:      	jae	0x6713 <generic_rawtp_filter_arg+0x7f3>
    62bc:      	movq	%r8, %rsi
    62bf:      	jmp	0x6723 <generic_rawtp_filter_arg+0x803>
    62c4:      	cmpl	$0x6, %ecx
    62c7:      	jg	0x6327 <generic_rawtp_filter_arg+0x407>
    62c9:      	cmpl	$0x3, %ecx
    62cc:      	jle	0x63a3 <generic_rawtp_filter_arg+0x483>
    62d2:      	cmpl	$0x4, %ecx
    62d5:      	je	0x63ee <generic_rawtp_filter_arg+0x4ce>
    62db:      	movq	%rsi, %r8
    62de:      	cmpl	$0x5, %ecx
    62e1:      	je	0x634b <generic_rawtp_filter_arg+0x42b>
    62e3:      	cmpl	$0x6, %ecx
    62e6:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    62ec:      	movq	%r8, %rsi
    62ef:      	movl	(%r8), %ebp
    62f2:      	addq	$0x4, %rsi
    62f6:      	cmpl	$0x19, %eax
    62f9:      	jg	0x65a7 <generic_rawtp_filter_arg+0x687>
    62ff:      	leal	-0x3(%rax), %ecx
    6302:      	cmpl	$0x2, %ecx
    6305:      	jb	0x6f00 <generic_rawtp_filter_arg+0xfe0>
    630b:      	cmpl	$0x8, %eax
    630e:      	je	0x6e57 <generic_rawtp_filter_arg+0xf37>
    6314:      	movl	$0x0, %ebx
    6319:      	cmpl	$0x9, %eax
    631c:      	je	0x65c7 <generic_rawtp_filter_arg+0x6a7>
    6322:      	jmp	0x8ee7 <generic_rawtp_filter_arg+0x2fc7>
    6327:      	leal	-0xa(%rcx), %edx
    632a:      	cmpl	$0x4, %edx
    632d:      	jb	0x63ee <generic_rawtp_filter_arg+0x4ce>
    6333:      	leal	-0xf(%rcx), %edx
    6336:      	cmpl	$0x2, %edx
    6339:      	jb	0x6723 <generic_rawtp_filter_arg+0x803>
    633f:      	movq	%rsi, %r8
    6342:      	cmpl	$0x7, %ecx
    6345:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    634b:      	movq	$0x0, 0x60(%rsp)
    6354:      	movq	$0x0, 0x58(%rsp)
    635d:      	movq	$0x0, 0x50(%rsp)
    6366:      	movq	$0x0, 0x48(%rsp)
    636f:      	movq	$0x0, 0x40(%rsp)
    6378:      	cmpl	$0x27, %ecx
    637b:      	jg	0x651c <generic_rawtp_filter_arg+0x5fc>
    6381:      	cmpl	$0x5, %ecx
    6384:      	movq	%r8, %rsi
    6387:      	je	0x6ca4 <generic_rawtp_filter_arg+0xd84>
    638d:      	movq	%rsi, %rdx
    6390:      	movl	$0x0, %ebx
    6395:      	cmpl	$0x7, %ecx
    6398:      	je	0x6ca6 <generic_rawtp_filter_arg+0xd86>
    639e:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    63a3:      	cmpl	$0x1, %ecx
    63a6:      	je	0x63ee <generic_rawtp_filter_arg+0x4ce>
    63a8:      	cmpl	$0x2, %ecx
    63ab:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    63b1:      	movl	0x4(%rsi), %ebp
    63b4:      	addq	$0x8, %rsi
    63b8:      	cmpl	$0x19, %eax
    63bb:      	jg	0x6f84 <generic_rawtp_filter_arg+0x1064>
    63c1:      	leal	-0x3(%rax), %ecx
    63c4:      	cmpl	$0x2, %ecx
    63c7:      	jb	0x780c <generic_rawtp_filter_arg+0x18ec>
    63cd:      	movq	%rsi, 0x8(%rsp)
    63d2:      	cmpl	$0x8, %eax
    63d5:      	je	0x776c <generic_rawtp_filter_arg+0x184c>
    63db:      	movl	$0x0, %ebx
    63e0:      	cmpl	$0x9, %eax
    63e3:      	je	0x6fa9 <generic_rawtp_filter_arg+0x1089>
    63e9:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    63ee:      	movq	%rsi, 0x8(%rsp)
    63f3:      	cmpl	$0xb, %ecx
    63f6:      	jle	0x6487 <generic_rawtp_filter_arg+0x567>
    63fc:      	cmpl	$0x24, %ecx
    63ff:      	ja	0x64ce <generic_rawtp_filter_arg+0x5ae>
    6405:      	movl	%ecx, %edx
    6407:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    6411:      	btq	%rdx, %rsi
    6415:      	jb	0x64a2 <generic_rawtp_filter_arg+0x582>
    641b:      	movl	$0x60000000, %esi       # imm = 0x60000000
    6420:      	btq	%rdx, %rsi
    6424:      	jb	0x6879 <generic_rawtp_filter_arg+0x959>
    642a:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6434:      	btq	%rdx, %rsi
    6438:      	jae	0x64ce <generic_rawtp_filter_arg+0x5ae>
    643e:      	cmpl	$0x20, %eax
    6441:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    6447:      	movl	%eax, %ecx
    6449:      	movl	$0x101e, %edx           # imm = 0x101E
    644e:      	btq	%rcx, %rdx
    6452:      	jae	0x70ff <generic_rawtp_filter_arg+0x11df>
    6458:      	movl	0x10(%r12), %ecx
    645d:      	cmpl	$0x2, %eax
    6460:      	jle	0x760c <generic_rawtp_filter_arg+0x16ec>
    6466:      	leal	-0x3(%rax), %edx
    6469:      	cmpl	$0x2, %edx
    646c:      	movq	0x8(%rsp), %rdx
    6471:      	jae	0x7c3f <generic_rawtp_filter_arg+0x1d1f>
    6477:      	movzbl	(%rdx), %edx
    647a:      	cmpl	%edx, %ecx
    647c:      	jne	0x7f5d <generic_rawtp_filter_arg+0x203d>
    6482:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    6487:      	leal	-0xa(%rcx), %edx
    648a:      	cmpl	$0x2, %edx
    648d:      	jb	0x6913 <generic_rawtp_filter_arg+0x9f3>
    6493:      	cmpl	$0x1, %ecx
    6496:      	je	0x64da <generic_rawtp_filter_arg+0x5ba>
    6498:      	cmpl	$0x4, %ecx
    649b:      	je	0x64da <generic_rawtp_filter_arg+0x5ba>
    649d:      	jmp	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    64a2:      	cmpl	$0x9, %eax
    64a5:      	jle	0x68c2 <generic_rawtp_filter_arg+0x9a2>
    64ab:      	cmpl	$0x1d, %eax
    64ae:      	jg	0x6d29 <generic_rawtp_filter_arg+0xe09>
    64b4:      	leal	-0xa(%rax), %edx
    64b7:      	cmpl	$0x2, %edx
    64ba:      	jb	0x69a9 <generic_rawtp_filter_arg+0xa89>
    64c0:      	cmpl	$0xc, %eax
    64c3:      	je	0x6929 <generic_rawtp_filter_arg+0xa09>
    64c9:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    64ce:      	leal	-0xc(%rcx), %edx
    64d1:      	cmpl	$0x2, %edx
    64d4:      	jae	0x690a <generic_rawtp_filter_arg+0x9ea>
    64da:      	cmpl	$0x20, %eax
    64dd:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    64e3:      	movl	%eax, %edx
    64e5:      	movl	$0x101e, %esi           # imm = 0x101E
    64ea:      	btq	%rdx, %rsi
    64ee:      	jae	0x653e <generic_rawtp_filter_arg+0x61e>
    64f0:      	movl	0x10(%r12), %edx
    64f5:      	cmpl	$0x2, %eax
    64f8:      	jle	0x68cf <generic_rawtp_filter_arg+0x9af>
    64fe:      	leal	-0x3(%rax), %esi
    6501:      	cmpl	$0x2, %esi
    6504:      	jae	0x70e4 <generic_rawtp_filter_arg+0x11c4>
    650a:      	movq	0x8(%rsp), %rsi
    650f:      	cmpl	%edx, (%rsi)
    6511:      	jne	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    6517:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    651c:      	cmpl	$0x28, %ecx
    651f:      	movq	%r8, %rsi
    6522:      	je	0x6c7c <generic_rawtp_filter_arg+0xd5c>
    6528:      	movq	%rsi, %rdx
    652b:      	movl	$0x0, %ebx
    6530:      	cmpl	$0x29, %ecx
    6533:      	je	0x6ca6 <generic_rawtp_filter_arg+0xd86>
    6539:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    653e:      	movl	$0xc00, %esi            # imm = 0xC00
    6543:      	btq	%rdx, %rsi
    6547:      	jb	0x6c16 <generic_rawtp_filter_arg+0xcf6>
    654d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6557:      	btq	%rdx, %rsi
    655b:      	jae	0x602d <generic_rawtp_filter_arg+0x10d>
    6561:      	cmpl	$0x1f, %eax
    6564:      	jne	0x7251 <generic_rawtp_filter_arg+0x1331>
    656a:      	movl	0x10(%r12), %esi
    656f:      	movl	0x14(%r12), %edx
    6574:      	cmpl	$0xc, %ecx
    6577:      	ja	0x8004 <generic_rawtp_filter_arg+0x20e4>
    657d:      	movl	$0x1402, %eax           # imm = 0x1402
    6582:      	btl	%ecx, %eax
    6585:      	jae	0x8004 <generic_rawtp_filter_arg+0x20e4>
    658b:      	movq	0x8(%rsp), %rax
    6590:      	movl	(%rax), %eax
    6592:      	cmpl	%eax, %esi
    6594:      	jg	0x8017 <generic_rawtp_filter_arg+0x20f7>
    659a:      	cmpl	%edx, %eax
    659c:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    65a2:      	jmp	0x8017 <generic_rawtp_filter_arg+0x20f7>
    65a7:      	cmpl	$0x20, %eax
    65aa:      	jg	0x6d75 <generic_rawtp_filter_arg+0xe55>
    65b0:      	cmpl	$0x1a, %eax
    65b3:      	je	0x6e57 <generic_rawtp_filter_arg+0xf37>
    65b9:      	movl	$0x0, %ebx
    65be:      	cmpl	$0x1b, %eax
    65c1:      	jne	0x8ee7 <generic_rawtp_filter_arg+0x2fc7>
    65c7:      	movq	%rsi, 0x8(%rsp)
    65cc:      	movq	%r11, 0x20(%rsp)
    65d1:      	movl	0x10(%r12), %eax
    65d6:      	movl	%eax, 0x40(%rsp)
    65da:      	movl	$0x0, 0x80(%rsp)
    65e5:      	movl	$0x1, %eax
    65ea:      	leaq	0x40(%rsp), %rsi
    65ef:      	movq	(%rip), %rdi            # 0x65f6 <generic_rawtp_filter_arg+0x6d6>
    65f6:      	callq	*%rax
    65f8:      	testl	%ebp, %ebp
    65fa:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    6600:      	movl	$0x0, %ebx
    6605:      	testq	%rax, %rax
    6608:      	je	0x8ed8 <generic_rawtp_filter_arg+0x2fb8>
    660e:      	movq	%rax, 0x28(%rsp)
    6613:      	movl	$0x1, %eax
    6618:      	movq	0x38(%rsp), %rsi
    661d:      	movq	(%rip), %rdi            # 0x6624 <generic_rawtp_filter_arg+0x704>
    6624:      	callq	*%rax
    6626:      	testq	%rax, %rax
    6629:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    662f:      	movq	%rax, %rdi
    6632:      	cmpl	$0x7f, %ebp
    6635:      	movl	$0x7f, %eax
    663a:      	cmovbl	%ebp, %eax
    663d:      	shll	$0x3, %eax
    6640:      	movl	%eax, (%rdi)
    6642:      	movq	%rbp, %rax
    6645:      	negq	%rax
    6648:      	movl	$0x3, %ecx
    664d:      	subq	%rbp, %rcx
    6650:      	leal	-0x4(%rbp), %edx
    6653:      	movq	%rdi, 0x70(%rsp)
    6658:      	addq	$0x7, %rdi
    665c:      	movl	$0x2, %r8d
    6662:      	subq	%rbp, %r8
    6665:      	leal	-0x3(%rbp), %r9d
    6669:      	movl	$0x1, %r10d
    666f:      	subq	%rbp, %r10
    6672:      	leal	-0x2(%rbp), %r11d
    6676:      	decl	%ebp
    6678:      	xorl	%ebx, %ebx
    667a:      	movq	0x8(%rsp), %rsi
    667f:      	leal	(%rbx,%rbp), %r13d
    6683:      	andl	$0xfff, %r13d           # imm = 0xFFF
    668a:      	movzbl	(%rsi,%r13), %r13d
    668f:      	movb	%r13b, -0x3(%rdi)
    6693:      	cmpq	%rbx, %r10
    6696:      	je	0x66f0 <generic_rawtp_filter_arg+0x7d0>
    6698:      	leal	(%r11,%rbx), %r13d
    669c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    66a3:      	movzbl	(%rsi,%r13), %r13d
    66a8:      	movb	%r13b, -0x2(%rdi)
    66ac:      	cmpq	%rbx, %r8
    66af:      	je	0x66f0 <generic_rawtp_filter_arg+0x7d0>
    66b1:      	leal	(%r9,%rbx), %r13d
    66b5:      	andl	$0xfff, %r13d           # imm = 0xFFF
    66bc:      	movzbl	(%rsi,%r13), %r13d
    66c1:      	movb	%r13b, -0x1(%rdi)
    66c5:      	cmpq	%rbx, %rcx
    66c8:      	je	0x66f0 <generic_rawtp_filter_arg+0x7d0>
    66ca:      	cmpq	$-0x7c, %rbx
    66ce:      	je	0x66f0 <generic_rawtp_filter_arg+0x7d0>
    66d0:      	leal	(%rdx,%rbx), %r13d
    66d4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    66db:      	movzbl	(%rsi,%r13), %r13d
    66e0:      	movb	%r13b, (%rdi)
    66e3:      	addq	$-0x4, %rbx
    66e7:      	addq	$0x4, %rdi
    66eb:      	cmpq	%rbx, %rax
    66ee:      	jne	0x667f <generic_rawtp_filter_arg+0x75f>
    66f0:      	movl	$0x1, %eax
    66f5:      	movq	0x28(%rsp), %rdi
    66fa:      	movq	0x70(%rsp), %rsi
    66ff:      	callq	*%rax
    6701:      	xorl	%ebx, %ebx
    6703:      	testq	%rax, %rax
    6706:      	setne	%bl
    6709:      	movq	0x78(%rsp), %r13
    670e:      	jmp	0x8ed8 <generic_rawtp_filter_arg+0x2fb8>
    6713:      	cmpl	$0x11, %ecx
    6716:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    671c:      	movq	%r8, %rsi
    671f:      	addq	$0x4, %rsi
    6723:      	movq	%rsi, 0x8(%rsp)
    6728:      	movl	(%rsi), %ebp
    672a:      	movl	%eax, %ecx
    672c:      	andl	$-0x2, %ecx
    672f:      	cmpl	$0x24, %ecx
    6732:      	je	0x673c <generic_rawtp_filter_arg+0x81c>
    6734:      	testl	%ebp, %ebp
    6736:      	je	0x602d <generic_rawtp_filter_arg+0x10d>
    673c:      	cmpl	$0x25, %eax
    673f:      	movq	0x8(%rsp), %rsi
    6744:      	ja	0x6844 <generic_rawtp_filter_arg+0x924>
    674a:      	movl	%eax, %ecx
    674c:      	movl	$0x4000100, %edx        # imm = 0x4000100
    6751:      	btq	%rcx, %rdx
    6755:      	jb	0x6b6e <generic_rawtp_filter_arg+0xc4e>
    675b:      	movl	$0x8000200, %edx        # imm = 0x8000200
    6760:      	btq	%rcx, %rdx
    6764:      	jb	0x6a23 <generic_rawtp_filter_arg+0xb03>
    676a:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    6774:      	btq	%rcx, %rdx
    6778:      	jae	0x6844 <generic_rawtp_filter_arg+0x924>
    677e:      	movw	$0x0, 0x40(%rsp)
    6785:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    678b:      	ja	0x6863 <generic_rawtp_filter_arg+0x943>
    6791:      	movq	%r11, 0x20(%rsp)
    6796:      	leaq	(%rsi,%rbp), %rcx
    679a:      	addq	$0x8, %rcx
    679e:      	movl	$0x4, %eax
    67a3:      	leaq	0x40(%rsp), %rdi
    67a8:      	movl	$0x2, %edx
    67ad:      	movl	(%rsi), %ecx
    67af:      	leaq	(%rsi,%rcx), %rdx
    67b3:      	addq	$0x8, %rdx
    67b7:      	movl	$0x2, %esi
    67bc:      	callq	*%rax
    67be:      	movl	0x10(%r12), %ecx
    67c3:      	testl	%ecx, %ecx
    67c5:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    67cb:      	movzwl	0x40(%rsp), %eax
    67d0:      	andl	$0xf000, %eax           # imm = 0xF000
    67d5:      	movl	$0x1, %ebx
    67da:      	cmpl	%eax, %ecx
    67dc:      	je	0x8cfb <generic_rawtp_filter_arg+0x2ddb>
    67e2:      	movl	0x8(%r12), %ecx
    67e7:      	cmpl	$0xd, %ecx
    67ea:      	movq	0x10(%rsp), %rdi
    67ef:      	movq	0x18(%rsp), %r9
    67f4:      	movq	0x20(%rsp), %r11
    67f9:      	jb	0x6863 <generic_rawtp_filter_arg+0x943>
    67fb:      	movl	0x14(%r12), %edx
    6800:      	testl	%edx, %edx
    6802:      	je	0x6863 <generic_rawtp_filter_arg+0x943>
    6804:      	cmpl	%eax, %edx
    6806:      	je	0x8d0a <generic_rawtp_filter_arg+0x2dea>
    680c:      	cmpl	$0x11, %ecx
    680f:      	jb	0x6863 <generic_rawtp_filter_arg+0x943>
    6811:      	movl	0x18(%r12), %edx
    6816:      	testl	%edx, %edx
    6818:      	je	0x6863 <generic_rawtp_filter_arg+0x943>
    681a:      	cmpl	%eax, %edx
    681c:      	je	0x8d0a <generic_rawtp_filter_arg+0x2dea>
    6822:      	cmpl	$0x15, %ecx
    6825:      	jb	0x9224 <generic_rawtp_filter_arg+0x3304>
    682b:      	movl	0x1c(%r12), %ecx
    6830:      	testl	%ecx, %ecx
    6832:      	je	0x9224 <generic_rawtp_filter_arg+0x3304>
    6838:      	xorl	%ebx, %ebx
    683a:      	cmpl	%eax, %ecx
    683c:      	sete	%bl
    683f:      	jmp	0x9226 <generic_rawtp_filter_arg+0x3306>
    6844:      	addl	$-0x3, %eax
    6847:      	cmpl	$0x2, %eax
    684a:      	jae	0x6863 <generic_rawtp_filter_arg+0x943>
    684c:      	movl	$0x0, 0x80(%rsp)
    6857:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    685d:      	jbe	0x71fb <generic_rawtp_filter_arg+0x12db>
    6863:      	xorl	%ebx, %ebx
    6865:      	movl	0x4(%r12), %eax
    686a:      	cmpq	$0x25, %rax
    686e:      	jbe	0x8d19 <generic_rawtp_filter_arg+0x2df9>
    6874:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    6879:      	cmpl	$0x20, %eax
    687c:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    6882:      	movl	%eax, %ecx
    6884:      	movl	$0x101e, %edx           # imm = 0x101E
    6889:      	btq	%rcx, %rdx
    688d:      	jae	0x7135 <generic_rawtp_filter_arg+0x1215>
    6893:      	movl	0x10(%r12), %ecx
    6898:      	cmpl	$0x2, %eax
    689b:      	jle	0x7633 <generic_rawtp_filter_arg+0x1713>
    68a1:      	leal	-0x3(%rax), %edx
    68a4:      	cmpl	$0x2, %edx
    68a7:      	movq	0x8(%rsp), %rdx
    68ac:      	jae	0x7c5d <generic_rawtp_filter_arg+0x1d3d>
    68b2:      	movzwl	(%rdx), %edx
    68b5:      	cmpl	%edx, %ecx
    68b7:      	jne	0x7faa <generic_rawtp_filter_arg+0x208a>
    68bd:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    68c2:      	leal	-0x1(%rax), %edx
    68c5:      	cmpl	$0x4, %edx
    68c8:      	jb	0x6929 <generic_rawtp_filter_arg+0xa09>
    68ca:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    68cf:      	cmpl	$0x1, %eax
    68d2:      	je	0x73bf <generic_rawtp_filter_arg+0x149f>
    68d8:      	cmpl	$0x2, %eax
    68db:      	jne	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    68e1:      	cmpl	$0xc, %ecx
    68e4:      	ja	0x81d4 <generic_rawtp_filter_arg+0x22b4>
    68ea:      	movl	$0x1402, %esi           # imm = 0x1402
    68ef:      	btl	%ecx, %esi
    68f2:      	jae	0x81d4 <generic_rawtp_filter_arg+0x22b4>
    68f8:      	movq	0x8(%rsp), %rsi
    68fd:      	cmpl	%edx, (%rsi)
    68ff:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    6905:      	jmp	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    690a:      	cmpl	$0x1c, %ecx
    690d:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    6913:      	cmpl	$0x20, %eax
    6916:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    691c:      	movl	%eax, %edx
    691e:      	movl	$0x101e, %esi           # imm = 0x101E
    6923:      	btq	%rdx, %rsi
    6927:      	jae	0x6952 <generic_rawtp_filter_arg+0xa32>
    6929:      	movq	0x10(%r12), %rdx
    692e:      	cmpl	$0x2, %eax
    6931:      	jle	0x6976 <generic_rawtp_filter_arg+0xa56>
    6933:      	leal	-0x3(%rax), %esi
    6936:      	cmpl	$0x2, %esi
    6939:      	jae	0x6c60 <generic_rawtp_filter_arg+0xd40>
    693f:      	movq	0x8(%rsp), %rsi
    6944:      	cmpq	%rdx, (%rsi)
    6947:      	jne	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    694d:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    6952:      	movl	$0xc00, %esi            # imm = 0xC00
    6957:      	btq	%rdx, %rsi
    695b:      	jb	0x69a9 <generic_rawtp_filter_arg+0xa89>
    695d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6967:      	btq	%rdx, %rsi
    696b:      	jb	0x6d35 <generic_rawtp_filter_arg+0xe15>
    6971:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    6976:      	cmpl	$0x1, %eax
    6979:      	je	0x71da <generic_rawtp_filter_arg+0x12ba>
    697f:      	cmpl	$0x2, %eax
    6982:      	jne	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    6988:      	cmpl	$0xc, %ecx
    698b:      	je	0x6996 <generic_rawtp_filter_arg+0xa76>
    698d:      	cmpl	$0xa, %ecx
    6990:      	jne	0x7ba5 <generic_rawtp_filter_arg+0x1c85>
    6996:      	movq	0x8(%rsp), %rsi
    699b:      	cmpq	%rdx, (%rsi)
    699e:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    69a4:      	jmp	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    69a9:      	movq	%r11, %rbp
    69ac:      	movzbl	0x10(%r12), %eax
    69b2:      	movl	%eax, 0x80(%rsp)
    69b9:      	movl	$0x1, %eax
    69be:      	movq	0x38(%rsp), %rsi
    69c3:      	movq	(%rip), %rdi            # 0x69ca <generic_rawtp_filter_arg+0xaaa>
    69ca:      	callq	*%rax
    69cc:      	testq	%rax, %rax
    69cf:      	je	0x771b <generic_rawtp_filter_arg+0x17fb>
    69d5:      	movq	%rax, %rdi
    69d8:      	movq	0x8(%rsp), %rax
    69dd:      	movq	(%rax), %rax
    69e0:      	movq	%rax, 0x40(%rsp)
    69e5:      	movl	$0x1, %eax
    69ea:      	leaq	0x40(%rsp), %rsi
    69ef:      	callq	*%rax
    69f1:      	movl	0x4(%r12), %ecx
    69f6:      	cmpl	$0xb, %ecx
    69f9:      	je	0x7747 <generic_rawtp_filter_arg+0x1827>
    69ff:      	cmpl	$0xa, %ecx
    6a02:      	movq	0x10(%rsp), %rdi
    6a07:      	movq	0x18(%rsp), %r9
    6a0c:      	movq	%rbp, %r11
    6a0f:      	jne	0x7762 <generic_rawtp_filter_arg+0x1842>
    6a15:      	testq	%rax, %rax
    6a18:      	setne	%al
    6a1b:      	movzbl	%al, %ebx
    6a1e:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    6a23:      	movq	%r11, 0x20(%rsp)
    6a28:      	movl	0x10(%r12), %eax
    6a2d:      	movl	%eax, 0x40(%rsp)
    6a31:      	movl	$0x0, 0x80(%rsp)
    6a3c:      	movl	$0x1, %eax
    6a41:      	leaq	0x40(%rsp), %rsi
    6a46:      	movq	(%rip), %rdi            # 0x6a4d <generic_rawtp_filter_arg+0xb2d>
    6a4d:      	callq	*%rax
    6a4f:      	testl	%ebp, %ebp
    6a51:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    6a57:      	movl	$0x0, %ebx
    6a5c:      	testq	%rax, %rax
    6a5f:      	je	0x8cfb <generic_rawtp_filter_arg+0x2ddb>
    6a65:      	movq	%rax, 0x28(%rsp)
    6a6a:      	movl	$0x1, %eax
    6a6f:      	movq	0x38(%rsp), %rsi
    6a74:      	movq	(%rip), %rdi            # 0x6a7b <generic_rawtp_filter_arg+0xb5b>
    6a7b:      	callq	*%rax
    6a7d:      	testq	%rax, %rax
    6a80:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    6a86:      	movq	%rax, %rdi
    6a89:      	cmpl	$0x7f, %ebp
    6a8c:      	movl	$0x7f, %eax
    6a91:      	cmovbl	%ebp, %eax
    6a94:      	shll	$0x3, %eax
    6a97:      	movl	%eax, (%rdi)
    6a99:      	movq	%rbp, %rax
    6a9c:      	negq	%rax
    6a9f:      	movl	$0x3, %ecx
    6aa4:      	subq	%rbp, %rcx
    6aa7:      	leal	-0x4(%rbp), %edx
    6aaa:      	movq	%rdi, 0x70(%rsp)
    6aaf:      	addq	$0x7, %rdi
    6ab3:      	movl	$0x2, %r8d
    6ab9:      	subq	%rbp, %r8
    6abc:      	leal	-0x3(%rbp), %r9d
    6ac0:      	movl	$0x1, %r10d
    6ac6:      	subq	%rbp, %r10
    6ac9:      	leal	-0x2(%rbp), %r11d
    6acd:      	decl	%ebp
    6acf:      	xorl	%ebx, %ebx
    6ad1:      	movq	0x8(%rsp), %rsi
    6ad6:      	leal	(%rbx,%rbp), %r13d
    6ada:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6ae1:      	movzbl	0x4(%rsi,%r13), %r13d
    6ae7:      	movb	%r13b, -0x3(%rdi)
    6aeb:      	cmpq	%rbx, %r10
    6aee:      	je	0x6b4b <generic_rawtp_filter_arg+0xc2b>
    6af0:      	leal	(%r11,%rbx), %r13d
    6af4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6afb:      	movzbl	0x4(%rsi,%r13), %r13d
    6b01:      	movb	%r13b, -0x2(%rdi)
    6b05:      	cmpq	%rbx, %r8
    6b08:      	je	0x6b4b <generic_rawtp_filter_arg+0xc2b>
    6b0a:      	leal	(%r9,%rbx), %r13d
    6b0e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6b15:      	movzbl	0x4(%rsi,%r13), %r13d
    6b1b:      	movb	%r13b, -0x1(%rdi)
    6b1f:      	cmpq	%rbx, %rcx
    6b22:      	je	0x6b4b <generic_rawtp_filter_arg+0xc2b>
    6b24:      	cmpq	$-0x7c, %rbx
    6b28:      	je	0x6b4b <generic_rawtp_filter_arg+0xc2b>
    6b2a:      	leal	(%rdx,%rbx), %r13d
    6b2e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6b35:      	movzbl	0x4(%rsi,%r13), %r13d
    6b3b:      	movb	%r13b, (%rdi)
    6b3e:      	addq	$-0x4, %rbx
    6b42:      	addq	$0x4, %rdi
    6b46:      	cmpq	%rbx, %rax
    6b49:      	jne	0x6ad6 <generic_rawtp_filter_arg+0xbb6>
    6b4b:      	movl	$0x1, %eax
    6b50:      	movq	0x28(%rsp), %rdi
    6b55:      	movq	0x70(%rsp), %rsi
    6b5a:      	callq	*%rax
    6b5c:      	xorl	%ebx, %ebx
    6b5e:      	testq	%rax, %rax
    6b61:      	setne	%bl
    6b64:      	movq	0x78(%rsp), %r13
    6b69:      	jmp	0x8cfb <generic_rawtp_filter_arg+0x2ddb>
    6b6e:      	movq	%r11, 0x20(%rsp)
    6b73:      	movl	0x10(%r12), %eax
    6b78:      	movl	%eax, 0x40(%rsp)
    6b7c:      	movl	$0x0, 0x80(%rsp)
    6b87:      	movl	$0x1, %eax
    6b8c:      	leaq	0x40(%rsp), %rsi
    6b91:      	movq	(%rip), %rdi            # 0x6b98 <generic_rawtp_filter_arg+0xc78>
    6b98:      	callq	*%rax
    6b9a:      	testl	%ebp, %ebp
    6b9c:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    6ba2:      	movl	$0x0, %ebx
    6ba7:      	testq	%rax, %rax
    6baa:      	je	0x8cfb <generic_rawtp_filter_arg+0x2ddb>
    6bb0:      	movq	%rax, 0x28(%rsp)
    6bb5:      	movl	$0x1, %eax
    6bba:      	movq	0x38(%rsp), %rsi
    6bbf:      	movq	(%rip), %rdi            # 0x6bc6 <generic_rawtp_filter_arg+0xca6>
    6bc6:      	callq	*%rax
    6bc8:      	testq	%rax, %rax
    6bcb:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    6bd1:      	movq	%rax, %rbx
    6bd4:      	movq	0x8(%rsp), %rdx
    6bd9:      	addq	$0x4, %rdx
    6bdd:      	cmpl	$0xff, %ebp
    6be3:      	movl	$0xff, %eax
    6be8:      	cmovael	%eax, %ebp
    6beb:      	leal	(,%rbp,8), %eax
    6bf2:      	movl	%eax, (%rbx)
    6bf4:      	movq	%rbx, %rdi
    6bf7:      	addq	$0x4, %rdi
    6bfb:      	movl	$0x4, %eax
    6c00:      	movl	%ebp, %esi
    6c02:      	callq	*%rax
    6c04:      	movl	$0x1, %eax
    6c09:      	movq	0x28(%rsp), %rdi
    6c0e:      	movq	%rbx, %rsi
    6c11:      	jmp	0x8ced <generic_rawtp_filter_arg+0x2dcd>
    6c16:      	movq	%r11, %rbp
    6c19:      	movzbl	0x10(%r12), %eax
    6c1f:      	movl	%eax, 0x80(%rsp)
    6c26:      	movl	$0x1, %eax
    6c2b:      	movq	0x38(%rsp), %rsi
    6c30:      	movq	(%rip), %rdi            # 0x6c37 <generic_rawtp_filter_arg+0xd17>
    6c37:      	callq	*%rax
    6c39:      	testq	%rax, %rax
    6c3c:      	je	0x771b <generic_rawtp_filter_arg+0x17fb>
    6c42:      	movq	%rax, %rdi
    6c45:      	movq	0x8(%rsp), %rax
    6c4a:      	movl	(%rax), %eax
    6c4c:      	movq	%rax, 0x40(%rsp)
    6c51:      	movl	$0x1, %eax
    6c56:      	leaq	0x40(%rsp), %rsi
    6c5b:      	jmp	0x76e4 <generic_rawtp_filter_arg+0x17c4>
    6c60:      	cmpl	$0xc, %eax
    6c63:      	jne	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    6c69:      	movq	0x8(%rsp), %rsi
    6c6e:      	testq	%rdx, (%rsi)
    6c71:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    6c77:      	jmp	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    6c7c:      	movzwl	(%rsi), %edx
    6c7f:      	movw	%dx, 0x66(%rsp)
    6c84:      	movzwl	0x2(%rsi), %edx
    6c88:      	movw	%dx, 0x60(%rsp)
    6c8d:      	movq	0x8(%rsi), %rdx
    6c91:      	movq	%rdx, 0x40(%rsp)
    6c96:      	movq	0x10(%rsi), %rdx
    6c9a:      	movq	%rdx, 0x48(%rsp)
    6c9f:      	leaq	0x40(%rsp), %rsi
    6ca4:      	xorl	%edx, %edx
    6ca6:      	cmpl	$0x13, %eax
    6ca9:      	jle	0x6cd2 <generic_rawtp_filter_arg+0xdb2>
    6cab:      	cmpl	$0x17, %eax
    6cae:      	jg	0x6d04 <generic_rawtp_filter_arg+0xde4>
    6cb0:      	leal	-0x14(%rax), %ecx
    6cb3:      	cmpl	$0x2, %ecx
    6cb6:      	jb	0x72a3 <generic_rawtp_filter_arg+0x1383>
    6cbc:      	leal	-0x16(%rax), %ecx
    6cbf:      	movl	$0x0, %ebx
    6cc4:      	cmpl	$0x2, %ecx
    6cc7:      	jb	0x729c <generic_rawtp_filter_arg+0x137c>
    6ccd:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    6cd2:      	cmpl	$0xf, %eax
    6cd5:      	jle	0x6f5f <generic_rawtp_filter_arg+0x103f>
    6cdb:      	cmpl	$0x11, %eax
    6cde:      	jg	0x7289 <generic_rawtp_filter_arg+0x1369>
    6ce4:      	cmpl	$0x10, %eax
    6ce7:      	je	0x729c <generic_rawtp_filter_arg+0x137c>
    6ced:      	movl	$0x0, %ebx
    6cf2:      	cmpl	$0x11, %eax
    6cf5:      	jne	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    6cfb:      	movzwl	0x24(%rsi), %ebx
    6cff:      	jmp	0x7b0e <generic_rawtp_filter_arg+0x1bee>
    6d04:      	cmpl	$0x1b, %eax
    6d07:      	jg	0x72dc <generic_rawtp_filter_arg+0x13bc>
    6d0d:      	cmpl	$0x18, %eax
    6d10:      	je	0x7316 <generic_rawtp_filter_arg+0x13f6>
    6d16:      	movl	$0x0, %ebx
    6d1b:      	cmpl	$0x19, %eax
    6d1e:      	je	0x730c <generic_rawtp_filter_arg+0x13ec>
    6d24:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    6d29:      	leal	-0x1f(%rax), %edx
    6d2c:      	cmpl	$0x2, %edx
    6d2f:      	jae	0x783e <generic_rawtp_filter_arg+0x191e>
    6d35:      	cmpl	$0x1f, %eax
    6d38:      	jne	0x6f2d <generic_rawtp_filter_arg+0x100d>
    6d3e:      	movq	0x10(%r12), %rsi
    6d43:      	movq	0x18(%r12), %rdx
    6d48:      	cmpl	$0xa, %ecx
    6d4b:      	je	0x6d56 <generic_rawtp_filter_arg+0xe36>
    6d4d:      	cmpl	$0xc, %ecx
    6d50:      	jne	0x7a61 <generic_rawtp_filter_arg+0x1b41>
    6d56:      	movq	0x8(%rsp), %rax
    6d5b:      	movq	(%rax), %rax
    6d5e:      	cmpq	%rax, %rsi
    6d61:      	jg	0x7a77 <generic_rawtp_filter_arg+0x1b57>
    6d67:      	cmpq	%rdx, %rax
    6d6a:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    6d70:      	jmp	0x7a77 <generic_rawtp_filter_arg+0x1b57>
    6d75:      	cmpl	$0x21, %eax
    6d78:      	je	0x73e8 <generic_rawtp_filter_arg+0x14c8>
    6d7e:      	movl	$0x0, %ebx
    6d83:      	cmpl	$0x22, %eax
    6d86:      	jne	0x8ee7 <generic_rawtp_filter_arg+0x2fc7>
    6d8c:      	movq	%rsi, 0x8(%rsp)
    6d91:      	xorl	%ebx, %ebx
    6d93:      	xorl	%r13d, %r13d
    6d96:      	movq	%r11, %r15
    6d99:      	movl	0x10(%r12,%rbx,4), %eax
    6d9e:      	movl	%eax, 0x40(%rsp)
    6da2:      	movl	$0x1, %eax
    6da7:      	leaq	0x40(%rsp), %rsi
    6dac:      	movq	(%rip), %rdi            # 0x6db3 <generic_rawtp_filter_arg+0xe93>
    6db3:      	callq	*%rax
    6db5:      	testq	%rax, %rax
    6db8:      	je	0x82b3 <generic_rawtp_filter_arg+0x2393>
    6dbe:      	testl	%ebp, %ebp
    6dc0:      	movq	%r15, %r11
    6dc3:      	movq	0x68(%rsp), %r15
    6dc8:      	je	0x6e34 <generic_rawtp_filter_arg+0xf14>
    6dca:      	movq	0x8(%rsp), %rdx
    6dcf:      	xorl	%ecx, %ecx
    6dd1:      	jmp	0x6dde <generic_rawtp_filter_arg+0xebe>
    6dd3:      	incq	%rcx
    6dd6:      	incq	%rdx
    6dd9:      	cmpq	%rbp, %rcx
    6ddc:      	je	0x6e34 <generic_rawtp_filter_arg+0xf14>
    6dde:      	xorl	%esi, %esi
    6de0:      	leaq	(%rcx,%rsi), %rdi
    6de4:      	cmpq	%rbp, %rdi
    6de7:      	jae	0x6dd3 <generic_rawtp_filter_arg+0xeb3>
    6de9:      	movsbl	(%rax,%rsi), %edi
    6ded:      	testl	%edi, %edi
    6def:      	je	0x6e2c <generic_rawtp_filter_arg+0xf0c>
    6df1:      	movsbl	(%rdx,%rsi), %r9d
    6df6:      	leal	-0x41(%r9), %r10d
    6dfa:      	movl	%r9d, %r8d
    6dfd:      	orl	$0x20, %r8d
    6e01:      	cmpl	$0x1a, %r10d
    6e05:      	cmovael	%r9d, %r8d
    6e09:      	leal	-0x41(%rdi), %r10d
    6e0d:      	movl	%edi, %r9d
    6e10:      	orl	$0x20, %r9d
    6e14:      	cmpl	$0x1a, %r10d
    6e18:      	cmovael	%edi, %r9d
    6e1c:      	cmpq	$0x62, %rsi
    6e20:      	ja	0x6dd3 <generic_rawtp_filter_arg+0xeb3>
    6e22:      	incq	%rsi
    6e25:      	cmpl	%r9d, %r8d
    6e28:      	je	0x6de0 <generic_rawtp_filter_arg+0xec0>
    6e2a:      	jmp	0x6dd3 <generic_rawtp_filter_arg+0xeb3>
    6e2c:      	testl	%ecx, %ecx
    6e2e:      	jns	0x85a8 <generic_rawtp_filter_arg+0x2688>
    6e34:      	leal	0xc(%r13), %eax
    6e38:      	cmpl	0x8(%r12), %eax
    6e3d:      	jae	0x6e50 <generic_rawtp_filter_arg+0xf30>
    6e3f:      	addl	$0x4, %r13d
    6e43:      	incq	%rbx
    6e46:      	cmpq	$0x64, %rbx
    6e4a:      	jne	0x6d96 <generic_rawtp_filter_arg+0xe76>
    6e50:      	xorl	%ebx, %ebx
    6e52:      	jmp	0x85ad <generic_rawtp_filter_arg+0x268d>
    6e57:      	movq	%rsi, 0x8(%rsp)
    6e5c:      	movq	%r11, 0x20(%rsp)
    6e61:      	movl	0x10(%r12), %eax
    6e66:      	movl	%eax, 0x40(%rsp)
    6e6a:      	movl	$0x0, 0x80(%rsp)
    6e75:      	movl	$0x1, %eax
    6e7a:      	leaq	0x40(%rsp), %rsi
    6e7f:      	movq	(%rip), %rdi            # 0x6e86 <generic_rawtp_filter_arg+0xf66>
    6e86:      	callq	*%rax
    6e88:      	testl	%ebp, %ebp
    6e8a:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    6e90:      	movl	$0x0, %ebx
    6e95:      	testq	%rax, %rax
    6e98:      	je	0x8ed8 <generic_rawtp_filter_arg+0x2fb8>
    6e9e:      	movq	%rax, 0x28(%rsp)
    6ea3:      	movl	$0x1, %eax
    6ea8:      	movq	0x38(%rsp), %rsi
    6ead:      	movq	(%rip), %rdi            # 0x6eb4 <generic_rawtp_filter_arg+0xf94>
    6eb4:      	callq	*%rax
    6eb6:      	testq	%rax, %rax
    6eb9:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    6ebf:      	cmpl	$0xff, %ebp
    6ec5:      	movl	$0xff, %ecx
    6eca:      	cmovael	%ecx, %ebp
    6ecd:      	leal	(,%rbp,8), %ecx
    6ed4:      	movl	%ecx, (%rax)
    6ed6:      	movq	%rax, %rdi
    6ed9:      	addq	$0x4, %rdi
    6edd:      	movq	%rax, %rbx
    6ee0:      	movl	$0x4, %eax
    6ee5:      	movq	0x8(%rsp), %rdx
    6eea:      	movl	%ebp, %esi
    6eec:      	callq	*%rax
    6eee:      	movl	$0x1, %eax
    6ef3:      	movq	0x28(%rsp), %rdi
    6ef8:      	movq	%rbx, %rsi
    6efb:      	jmp	0x8eca <generic_rawtp_filter_arg+0x2faa>
    6f00:      	movl	$0x0, 0x80(%rsp)
    6f0b:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6f11:      	jbe	0x74a2 <generic_rawtp_filter_arg+0x1582>
    6f17:      	xorl	%ebx, %ebx
    6f19:      	movl	0x4(%r12), %eax
    6f1e:      	cmpq	$0x25, %rax
    6f22:      	jbe	0x8ef6 <generic_rawtp_filter_arg+0x2fd6>
    6f28:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    6f2d:      	movq	0x10(%r12), %rsi
    6f32:      	movq	0x18(%r12), %rax
    6f37:      	cmpl	$0xc, %ecx
    6f3a:      	je	0x6f45 <generic_rawtp_filter_arg+0x1025>
    6f3c:      	cmpl	$0xa, %ecx
    6f3f:      	jne	0x7ab9 <generic_rawtp_filter_arg+0x1b99>
    6f45:      	movq	0x8(%rsp), %rdx
    6f4a:      	movq	(%rdx), %rdx
    6f4d:      	cmpq	%rdx, %rsi
    6f50:      	setle	%sil
    6f54:      	cmpq	%rax, %rdx
    6f57:      	setle	%al
    6f5a:      	jmp	0x7ace <generic_rawtp_filter_arg+0x1bae>
    6f5f:      	cmpl	$0xd, %eax
    6f62:      	je	0x7316 <generic_rawtp_filter_arg+0x13f6>
    6f68:      	cmpl	$0xe, %eax
    6f6b:      	je	0x730c <generic_rawtp_filter_arg+0x13ec>
    6f71:      	movl	$0x0, %ebx
    6f76:      	cmpl	$0xf, %eax
    6f79:      	je	0x72a3 <generic_rawtp_filter_arg+0x1383>
    6f7f:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    6f84:      	cmpl	$0x20, %eax
    6f87:      	movq	%rsi, 0x8(%rsp)
    6f8c:      	jg	0x7578 <generic_rawtp_filter_arg+0x1658>
    6f92:      	cmpl	$0x1a, %eax
    6f95:      	je	0x776c <generic_rawtp_filter_arg+0x184c>
    6f9b:      	movl	$0x0, %ebx
    6fa0:      	cmpl	$0x1b, %eax
    6fa3:      	jne	0x91b5 <generic_rawtp_filter_arg+0x3295>
    6fa9:      	movq	%r11, 0x20(%rsp)
    6fae:      	movl	0x10(%r12), %eax
    6fb3:      	movl	%eax, 0x40(%rsp)
    6fb7:      	movl	$0x0, 0x80(%rsp)
    6fc2:      	movl	$0x1, %eax
    6fc7:      	leaq	0x40(%rsp), %rsi
    6fcc:      	movq	(%rip), %rdi            # 0x6fd3 <generic_rawtp_filter_arg+0x10b3>
    6fd3:      	callq	*%rax
    6fd5:      	testl	%ebp, %ebp
    6fd7:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    6fdd:      	movq	%rax, %r13
    6fe0:      	movl	$0x0, %ebx
    6fe5:      	testq	%rax, %rax
    6fe8:      	je	0x91a6 <generic_rawtp_filter_arg+0x3286>
    6fee:      	movl	$0x1, %eax
    6ff3:      	movq	0x38(%rsp), %rsi
    6ff8:      	movq	(%rip), %rdi            # 0x6fff <generic_rawtp_filter_arg+0x10df>
    6fff:      	callq	*%rax
    7001:      	testq	%rax, %rax
    7004:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    700a:      	movq	%rax, %rdi
    700d:      	movq	%r13, 0x28(%rsp)
    7012:      	cmpl	$0x7f, %ebp
    7015:      	movl	$0x7f, %eax
    701a:      	cmovbl	%ebp, %eax
    701d:      	shll	$0x3, %eax
    7020:      	movl	%eax, (%rdi)
    7022:      	movq	%rbp, %rax
    7025:      	negq	%rax
    7028:      	movl	$0x3, %ecx
    702d:      	subq	%rbp, %rcx
    7030:      	leal	-0x4(%rbp), %edx
    7033:      	movq	%rdi, 0x70(%rsp)
    7038:      	addq	$0x7, %rdi
    703c:      	movl	$0x2, %r8d
    7042:      	subq	%rbp, %r8
    7045:      	leal	-0x3(%rbp), %r9d
    7049:      	movl	$0x1, %r10d
    704f:      	subq	%rbp, %r10
    7052:      	leal	-0x2(%rbp), %r11d
    7056:      	decl	%ebp
    7058:      	xorl	%ebx, %ebx
    705a:      	movq	0x8(%rsp), %rsi
    705f:      	leal	(%rbx,%rbp), %r13d
    7063:      	andl	$0xfff, %r13d           # imm = 0xFFF
    706a:      	movzbl	(%rsi,%r13), %r13d
    706f:      	movb	%r13b, -0x3(%rdi)
    7073:      	cmpq	%rbx, %r10
    7076:      	je	0x70d0 <generic_rawtp_filter_arg+0x11b0>
    7078:      	leal	(%r11,%rbx), %r13d
    707c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    7083:      	movzbl	(%rsi,%r13), %r13d
    7088:      	movb	%r13b, -0x2(%rdi)
    708c:      	cmpq	%rbx, %r8
    708f:      	je	0x70d0 <generic_rawtp_filter_arg+0x11b0>
    7091:      	leal	(%r9,%rbx), %r13d
    7095:      	andl	$0xfff, %r13d           # imm = 0xFFF
    709c:      	movzbl	(%rsi,%r13), %r13d
    70a1:      	movb	%r13b, -0x1(%rdi)
    70a5:      	cmpq	%rbx, %rcx
    70a8:      	je	0x70d0 <generic_rawtp_filter_arg+0x11b0>
    70aa:      	cmpq	$-0x7c, %rbx
    70ae:      	je	0x70d0 <generic_rawtp_filter_arg+0x11b0>
    70b0:      	leal	(%rdx,%rbx), %r13d
    70b4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    70bb:      	movzbl	(%rsi,%r13), %r13d
    70c0:      	movb	%r13b, (%rdi)
    70c3:      	addq	$-0x4, %rbx
    70c7:      	addq	$0x4, %rdi
    70cb:      	cmpq	%rbx, %rax
    70ce:      	jne	0x705f <generic_rawtp_filter_arg+0x113f>
    70d0:      	movl	$0x1, %eax
    70d5:      	movq	0x28(%rsp), %rdi
    70da:      	movq	0x70(%rsp), %rsi
    70df:      	jmp	0x9198 <generic_rawtp_filter_arg+0x3278>
    70e4:      	cmpl	$0xc, %eax
    70e7:      	jne	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    70ed:      	movq	0x8(%rsp), %rsi
    70f2:      	testl	%edx, (%rsi)
    70f4:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    70fa:      	jmp	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    70ff:      	movl	$0xc00, %edx            # imm = 0xC00
    7104:      	btq	%rcx, %rdx
    7108:      	jb	0x765a <generic_rawtp_filter_arg+0x173a>
    710e:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7118:      	btq	%rcx, %rdx
    711c:      	jae	0x602d <generic_rawtp_filter_arg+0x10d>
    7122:      	cmpl	$0x1f, %eax
    7125:      	jne	0x7db4 <generic_rawtp_filter_arg+0x1e94>
    712b:      	movq	0x8(%rsp), %rax
    7130:      	movzbl	(%rax), %eax
    7133:      	jmp	0x7169 <generic_rawtp_filter_arg+0x1249>
    7135:      	movl	$0xc00, %edx            # imm = 0xC00
    713a:      	btq	%rcx, %rdx
    713e:      	jb	0x76a2 <generic_rawtp_filter_arg+0x1782>
    7144:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    714e:      	btq	%rcx, %rdx
    7152:      	jae	0x602d <generic_rawtp_filter_arg+0x10d>
    7158:      	cmpl	$0x1f, %eax
    715b:      	jne	0x7dc3 <generic_rawtp_filter_arg+0x1ea3>
    7161:      	movq	0x8(%rsp), %rax
    7166:      	movzwl	(%rax), %eax
    7169:      	cmpl	%eax, 0x10(%r12)
    716e:      	ja	0x717b <generic_rawtp_filter_arg+0x125b>
    7170:      	cmpl	%eax, 0x14(%r12)
    7175:      	jae	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    717b:      	movl	0x8(%r12), %ecx
    7180:      	cmpl	$0x11, %ecx
    7183:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    7189:      	cmpl	%eax, 0x18(%r12)
    718e:      	ja	0x719b <generic_rawtp_filter_arg+0x127b>
    7190:      	cmpl	%eax, 0x1c(%r12)
    7195:      	jae	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    719b:      	cmpl	$0x19, %ecx
    719e:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    71a4:      	cmpl	%eax, 0x20(%r12)
    71a9:      	ja	0x71b6 <generic_rawtp_filter_arg+0x1296>
    71ab:      	cmpl	%eax, 0x24(%r12)
    71b0:      	jae	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    71b6:      	cmpl	$0x21, %ecx
    71b9:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    71bf:      	cmpl	%eax, 0x28(%r12)
    71c4:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    71ca:      	cmpl	%eax, 0x2c(%r12)
    71cf:      	jae	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    71d5:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    71da:      	cmpl	$0xc, %ecx
    71dd:      	je	0x71e8 <generic_rawtp_filter_arg+0x12c8>
    71df:      	cmpl	$0xa, %ecx
    71e2:      	jne	0x7b95 <generic_rawtp_filter_arg+0x1c75>
    71e8:      	movq	0x8(%rsp), %rsi
    71ed:      	cmpq	%rdx, (%rsi)
    71f0:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    71f6:      	jmp	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    71fb:      	movzwl	%bp, %eax
    71fe:      	cmpl	$0x90, %eax
    7203:      	movq	%r11, 0x20(%rsp)
    7208:      	ja	0x78af <generic_rawtp_filter_arg+0x198f>
    720e:      	testw	%bp, %bp
    7211:      	je	0x7223 <generic_rawtp_filter_arg+0x1303>
    7213:      	movl	%ebp, %eax
    7215:      	movl	$0x18, %ecx
    721a:      	cltd
    721b:      	idivl	%ecx
    721d:      	movl	%ebp, %esi
    721f:      	testl	%edx, %edx
    7221:      	je	0x7245 <generic_rawtp_filter_arg+0x1325>
    7223:      	movl	%ebp, %eax
    7225:      	movl	$0x18, %ecx
    722a:      	cltd
    722b:      	idivl	%ecx
    722d:      	shll	$0x3, %eax
    7230:      	leal	(%rax,%rax,2), %eax
    7233:      	addl	$0x18, %eax
    7236:      	movzwl	%ax, %esi
    7239:      	cmpl	$0x90, %esi
    723f:      	ja	0x78c3 <generic_rawtp_filter_arg+0x19a3>
    7245:      	movl	%esi, %eax
    7247:      	cltd
    7248:      	idivl	%ecx
    724a:      	decl	%eax
    724c:      	jmp	0x78d4 <generic_rawtp_filter_arg+0x19b4>
    7251:      	movl	0x10(%r12), %esi
    7256:      	movl	0x14(%r12), %eax
    725b:      	cmpl	$0xc, %ecx
    725e:      	ja	0x8062 <generic_rawtp_filter_arg+0x2142>
    7264:      	movl	$0x1402, %edx           # imm = 0x1402
    7269:      	btl	%ecx, %edx
    726c:      	jae	0x8062 <generic_rawtp_filter_arg+0x2142>
    7272:      	movq	0x8(%rsp), %rdx
    7277:      	movl	(%rdx), %edx
    7279:      	cmpl	%edx, %esi
    727b:      	setle	%sil
    727f:      	cmpl	%eax, %edx
    7281:      	setle	%al
    7284:      	jmp	0x8074 <generic_rawtp_filter_arg+0x2154>
    7289:      	cmpl	$0x12, %eax
    728c:      	je	0x72a3 <generic_rawtp_filter_arg+0x1383>
    728e:      	movl	$0x0, %ebx
    7293:      	cmpl	$0x13, %eax
    7296:      	jne	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    729c:      	movzwl	0x22(%rsi), %r13d
    72a1:      	jmp	0x72a8 <generic_rawtp_filter_arg+0x1388>
    72a3:      	movzwl	0x20(%rsi), %r13d
    72a8:      	xorl	%edx, %edx
    72aa:      	xorl	%ebp, %ebp
    72ac:      	xorl	%r8d, %r8d
    72af:      	xorl	%ebx, %ebx
    72b1:      	cmpl	$0x11, %eax
    72b4:      	jg	0x732e <generic_rawtp_filter_arg+0x140e>
    72b6:      	leal	-0xd(%rax), %ecx
    72b9:      	cmpl	$0x2, %ecx
    72bc:      	jb	0x7361 <generic_rawtp_filter_arg+0x1441>
    72c2:      	leal	-0xf(%rax), %ecx
    72c5:      	cmpl	$0x2, %ecx
    72c8:      	jb	0x7504 <generic_rawtp_filter_arg+0x15e4>
    72ce:      	cmpl	$0x11, %eax
    72d1:      	je	0x7b0e <generic_rawtp_filter_arg+0x1bee>
    72d7:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    72dc:      	cmpl	$0x1c, %eax
    72df:      	je	0x7b0a <generic_rawtp_filter_arg+0x1bea>
    72e5:      	movl	$0x0, %ebx
    72ea:      	cmpl	$0x1d, %eax
    72ed:      	jne	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    72f3:      	cmpl	$0x7, %ecx
    72f6:      	jne	0x8152 <generic_rawtp_filter_arg+0x2232>
    72fc:      	testq	%rdx, %rdx
    72ff:      	jne	0x815e <generic_rawtp_filter_arg+0x223e>
    7305:      	xorl	%ebx, %ebx
    7307:      	jmp	0x8170 <generic_rawtp_filter_arg+0x2250>
    730c:      	movq	0x10(%rsi), %rdx
    7310:      	movq	0x18(%rsi), %r8
    7314:      	jmp	0x731d <generic_rawtp_filter_arg+0x13fd>
    7316:      	movq	(%rsi), %rdx
    7319:      	movq	0x8(%rsi), %r8
    731d:      	movq	%rdx, %rbp
    7320:      	shrq	$0x20, %rbp
    7324:      	xorl	%r13d, %r13d
    7327:      	xorl	%ebx, %ebx
    7329:      	cmpl	$0x11, %eax
    732c:      	jle	0x72b6 <generic_rawtp_filter_arg+0x1396>
    732e:      	cmpl	$0x19, %eax
    7331:      	ja	0x74f8 <generic_rawtp_filter_arg+0x15d8>
    7337:      	movl	$0x500000, %ecx         # imm = 0x500000
    733c:      	btl	%eax, %ecx
    733f:      	jb	0x7889 <generic_rawtp_filter_arg+0x1969>
    7345:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    734a:      	btl	%eax, %ecx
    734d:      	jb	0x789c <generic_rawtp_filter_arg+0x197c>
    7353:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7358:      	btl	%eax, %ecx
    735b:      	jae	0x74f8 <generic_rawtp_filter_arg+0x15d8>
    7361:      	movzwl	0x26(%rsi), %eax
    7365:      	cmpl	$0xa, %eax
    7368:      	je	0x79b6 <generic_rawtp_filter_arg+0x1a96>
    736e:      	cmpl	$0x2, %eax
    7371:      	jne	0x7a57 <generic_rawtp_filter_arg+0x1b37>
    7377:      	movq	%rdx, %r13
    737a:      	movq	%r11, 0x20(%rsp)
    737f:      	movl	0x10(%r12), %eax
    7384:      	movl	%eax, 0x34(%rsp)
    7388:      	movl	$0x1, %eax
    738d:      	leaq	0x34(%rsp), %rsi
    7392:      	movq	(%rip), %rdi            # 0x7399 <generic_rawtp_filter_arg+0x1479>
    7399:      	callq	*%rax
    739b:      	testq	%rax, %rax
    739e:      	je	0x7c7b <generic_rawtp_filter_arg+0x1d5b>
    73a4:      	movq	%rax, %rdi
    73a7:      	movl	$0x20, 0x80(%rsp)
    73b2:      	movl	%r13d, 0x84(%rsp)
    73ba:      	jmp	0x7a15 <generic_rawtp_filter_arg+0x1af5>
    73bf:      	cmpl	$0xc, %ecx
    73c2:      	ja	0x81c5 <generic_rawtp_filter_arg+0x22a5>
    73c8:      	movl	$0x1402, %esi           # imm = 0x1402
    73cd:      	btl	%ecx, %esi
    73d0:      	jae	0x81c5 <generic_rawtp_filter_arg+0x22a5>
    73d6:      	movq	0x8(%rsp), %rsi
    73db:      	cmpl	%edx, (%rsi)
    73dd:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    73e3:      	jmp	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    73e8:      	movq	%rsi, 0x8(%rsp)
    73ed:      	xorl	%ebx, %ebx
    73ef:      	xorl	%r13d, %r13d
    73f2:      	movq	%r11, %r15
    73f5:      	movl	0x10(%r12,%rbx,4), %eax
    73fa:      	movl	%eax, 0x40(%rsp)
    73fe:      	movl	$0x1, %eax
    7403:      	leaq	0x40(%rsp), %rsi
    7408:      	movq	(%rip), %rdi            # 0x740f <generic_rawtp_filter_arg+0x14ef>
    740f:      	callq	*%rax
    7411:      	testq	%rax, %rax
    7414:      	je	0x829f <generic_rawtp_filter_arg+0x237f>
    741a:      	testl	%ebp, %ebp
    741c:      	movq	0x18(%rsp), %r9
    7421:      	movq	%r15, %r11
    7424:      	movq	0x68(%rsp), %r15
    7429:      	je	0x747f <generic_rawtp_filter_arg+0x155f>
    742b:      	movq	0x8(%rsp), %rdx
    7430:      	xorl	%ecx, %ecx
    7432:      	jmp	0x743f <generic_rawtp_filter_arg+0x151f>
    7434:      	incq	%rcx
    7437:      	incq	%rdx
    743a:      	cmpq	%rbp, %rcx
    743d:      	je	0x747f <generic_rawtp_filter_arg+0x155f>
    743f:      	xorl	%esi, %esi
    7441:      	nopw	%cs:(%rax,%rax)
    7450:      	leaq	(%rcx,%rsi), %rdi
    7454:      	cmpq	%rbp, %rdi
    7457:      	jae	0x7434 <generic_rawtp_filter_arg+0x1514>
    7459:      	movzbl	(%rax,%rsi), %edi
    745d:      	testb	%dil, %dil
    7460:      	je	0x7477 <generic_rawtp_filter_arg+0x1557>
    7462:      	cmpq	$0x62, %rsi
    7466:      	ja	0x7434 <generic_rawtp_filter_arg+0x1514>
    7468:      	leaq	0x1(%rsi), %r8
    746c:      	cmpb	%dil, (%rdx,%rsi)
    7470:      	movq	%r8, %rsi
    7473:      	je	0x7450 <generic_rawtp_filter_arg+0x1530>
    7475:      	jmp	0x7434 <generic_rawtp_filter_arg+0x1514>
    7477:      	testl	%ecx, %ecx
    7479:      	jns	0x8585 <generic_rawtp_filter_arg+0x2665>
    747f:      	leal	0xc(%r13), %eax
    7483:      	cmpl	0x8(%r12), %eax
    7488:      	jae	0x749b <generic_rawtp_filter_arg+0x157b>
    748a:      	addl	$0x4, %r13d
    748e:      	incq	%rbx
    7491:      	cmpq	$0x64, %rbx
    7495:      	jne	0x73f2 <generic_rawtp_filter_arg+0x14d2>
    749b:      	xorl	%ebx, %ebx
    749d:      	jmp	0x858a <generic_rawtp_filter_arg+0x266a>
    74a2:      	movzwl	%bp, %eax
    74a5:      	cmpl	$0x90, %eax
    74aa:      	movq	%r11, 0x20(%rsp)
    74af:      	ja	0x7c8b <generic_rawtp_filter_arg+0x1d6b>
    74b5:      	testw	%bp, %bp
    74b8:      	je	0x74ca <generic_rawtp_filter_arg+0x15aa>
    74ba:      	movl	%ebp, %eax
    74bc:      	movl	$0x18, %ecx
    74c1:      	cltd
    74c2:      	idivl	%ecx
    74c4:      	movl	%ebp, %edi
    74c6:      	testl	%edx, %edx
    74c8:      	je	0x74ec <generic_rawtp_filter_arg+0x15cc>
    74ca:      	movl	%ebp, %eax
    74cc:      	movl	$0x18, %ecx
    74d1:      	cltd
    74d2:      	idivl	%ecx
    74d4:      	shll	$0x3, %eax
    74d7:      	leal	(%rax,%rax,2), %eax
    74da:      	addl	$0x18, %eax
    74dd:      	movzwl	%ax, %edi
    74e0:      	cmpl	$0x90, %edi
    74e6:      	ja	0x7c9f <generic_rawtp_filter_arg+0x1d7f>
    74ec:      	movl	%edi, %eax
    74ee:      	cltd
    74ef:      	idivl	%ecx
    74f1:      	decl	%eax
    74f3:      	jmp	0x7cb0 <generic_rawtp_filter_arg+0x1d90>
    74f8:      	addl	$-0x12, %eax
    74fb:      	cmpl	$0x2, %eax
    74fe:      	jae	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    7504:      	movq	%r11, %rbp
    7507:      	movzbl	0x10(%r12), %eax
    750d:      	movl	%eax, 0x34(%rsp)
    7511:      	movl	$0x1, %eax
    7516:      	movq	(%rip), %rdi            # 0x751d <generic_rawtp_filter_arg+0x15fd>
    751d:      	leaq	0x34(%rsp), %rsi
    7522:      	callq	*%rax
    7524:      	testq	%rax, %rax
    7527:      	je	0x782a <generic_rawtp_filter_arg+0x190a>
    752d:      	movq	%rax, %rdi
    7530:      	movzwl	%r13w, %eax
    7534:      	movq	%rax, 0x80(%rsp)
    753c:      	movl	$0x1, %eax
    7541:      	movq	0x38(%rsp), %rsi
    7546:      	callq	*%rax
    7548:      	movl	0x4(%r12), %edx
    754d:      	xorl	%ecx, %ecx
    754f:      	cmpl	$0x1d, %edx
    7552:      	ja	0x8bc9 <generic_rawtp_filter_arg+0x2ca9>
    7558:      	movl	$0x30038400, %esi       # imm = 0x30038400
    755d:      	btl	%edx, %esi
    7560:      	movq	0x10(%rsp), %rdi
    7565:      	movq	0x18(%rsp), %r9
    756a:      	movq	%rbp, %r11
    756d:      	jb	0x61c9 <generic_rawtp_filter_arg+0x2a9>
    7573:      	jmp	0x7b7c <generic_rawtp_filter_arg+0x1c5c>
    7578:      	cmpl	$0x21, %eax
    757b:      	je	0x7e48 <generic_rawtp_filter_arg+0x1f28>
    7581:      	movl	$0x0, %ebx
    7586:      	cmpl	$0x22, %eax
    7589:      	jne	0x91b5 <generic_rawtp_filter_arg+0x3295>
    758f:      	movl	$0x10, %r13d
    7595:      	movq	%r11, %r15
    7598:      	movl	(%r12,%r13), %eax
    759c:      	movl	%eax, 0x40(%rsp)
    75a0:      	movl	$0x1, %eax
    75a5:      	leaq	0x40(%rsp), %rsi
    75aa:      	movq	(%rip), %rdi            # 0x75b1 <generic_rawtp_filter_arg+0x1691>
    75b1:      	callq	*%rax
    75b3:      	testq	%rax, %rax
    75b6:      	je	0x88b2 <generic_rawtp_filter_arg+0x2992>
    75bc:      	movq	0x8(%rsp), %rdi
    75c1:      	movq	%rax, %rsi
    75c4:      	movq	%rbp, %rdx
    75c7:      	callq	0x75cc <generic_rawtp_filter_arg+0x16ac>
    75cc:      	testl	%eax, %eax
    75ce:      	jns	0x88b6 <generic_rawtp_filter_arg+0x2996>
    75d4:      	addq	$0x4, %r13
    75d8:      	leal	-0x8(%r13), %eax
    75dc:      	cmpl	0x8(%r12), %eax
    75e1:      	movq	0x10(%rsp), %rdi
    75e6:      	movq	0x18(%rsp), %r9
    75eb:      	movq	%r15, %r11
    75ee:      	jae	0x8962 <generic_rawtp_filter_arg+0x2a42>
    75f4:      	movl	$0x0, %ebx
    75f9:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    7600:      	movq	0x68(%rsp), %r15
    7605:      	jne	0x7595 <generic_rawtp_filter_arg+0x1675>
    7607:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    760c:      	cmpl	$0x1, %eax
    760f:      	je	0x7f4d <generic_rawtp_filter_arg+0x202d>
    7615:      	cmpl	$0x2, %eax
    7618:      	jne	0x7f5d <generic_rawtp_filter_arg+0x203d>
    761e:      	movq	0x8(%rsp), %rdx
    7623:      	movzbl	(%rdx), %edx
    7626:      	cmpl	%edx, %ecx
    7628:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    762e:      	jmp	0x7f5d <generic_rawtp_filter_arg+0x203d>
    7633:      	cmpl	$0x1, %eax
    7636:      	je	0x7f9a <generic_rawtp_filter_arg+0x207a>
    763c:      	cmpl	$0x2, %eax
    763f:      	jne	0x7faa <generic_rawtp_filter_arg+0x208a>
    7645:      	movq	0x8(%rsp), %rdx
    764a:      	movzwl	(%rdx), %edx
    764d:      	cmpl	%edx, %ecx
    764f:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7655:      	jmp	0x7faa <generic_rawtp_filter_arg+0x208a>
    765a:      	movq	%r11, %rbp
    765d:      	movzbl	0x10(%r12), %eax
    7663:      	movl	%eax, 0x80(%rsp)
    766a:      	movl	$0x1, %eax
    766f:      	movq	0x38(%rsp), %rsi
    7674:      	movq	(%rip), %rdi            # 0x767b <generic_rawtp_filter_arg+0x175b>
    767b:      	callq	*%rax
    767d:      	testq	%rax, %rax
    7680:      	je	0x771b <generic_rawtp_filter_arg+0x17fb>
    7686:      	movq	%rax, %rdi
    7689:      	movq	0x8(%rsp), %rax
    768e:      	movzbl	(%rax), %eax
    7691:      	movq	%rax, 0x40(%rsp)
    7696:      	movl	$0x1, %eax
    769b:      	leaq	0x40(%rsp), %rsi
    76a0:      	jmp	0x76e4 <generic_rawtp_filter_arg+0x17c4>
    76a2:      	movq	%r11, %rbp
    76a5:      	movzbl	0x10(%r12), %eax
    76ab:      	movl	%eax, 0x80(%rsp)
    76b2:      	movl	$0x1, %eax
    76b7:      	movq	0x38(%rsp), %rsi
    76bc:      	movq	(%rip), %rdi            # 0x76c3 <generic_rawtp_filter_arg+0x17a3>
    76c3:      	callq	*%rax
    76c5:      	testq	%rax, %rax
    76c8:      	je	0x771b <generic_rawtp_filter_arg+0x17fb>
    76ca:      	movq	%rax, %rdi
    76cd:      	movq	0x8(%rsp), %rax
    76d2:      	movzwl	(%rax), %eax
    76d5:      	movq	%rax, 0x40(%rsp)
    76da:      	movl	$0x1, %eax
    76df:      	leaq	0x40(%rsp), %rsi
    76e4:      	callq	*%rax
    76e6:      	movl	0x4(%r12), %edx
    76eb:      	xorl	%ecx, %ecx
    76ed:      	cmpl	$0x1d, %edx
    76f0:      	ja	0x8813 <generic_rawtp_filter_arg+0x28f3>
    76f6:      	movl	$0x30038400, %esi       # imm = 0x30038400
    76fb:      	btl	%edx, %esi
    76fe:      	movq	0x10(%rsp), %rdi
    7703:      	movq	0x18(%rsp), %r9
    7708:      	movq	%rbp, %r11
    770b:      	jae	0x772f <generic_rawtp_filter_arg+0x180f>
    770d:      	testq	%rax, %rax
    7710:      	setne	%cl
    7713:      	movzbl	%cl, %ebx
    7716:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    771b:      	xorl	%ebx, %ebx
    771d:      	movq	0x10(%rsp), %rdi
    7722:      	movq	0x18(%rsp), %r9
    7727:      	movq	%rbp, %r11
    772a:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    772f:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7734:      	btl	%edx, %esi
    7737:      	jae	0x773f <generic_rawtp_filter_arg+0x181f>
    7739:      	testq	%rax, %rax
    773c:      	sete	%cl
    773f:      	movzbl	%cl, %ebx
    7742:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    7747:      	testq	%rax, %rax
    774a:      	sete	%al
    774d:      	movq	0x10(%rsp), %rdi
    7752:      	movq	0x18(%rsp), %r9
    7757:      	movq	%rbp, %r11
    775a:      	movzbl	%al, %ebx
    775d:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    7762:      	xorl	%eax, %eax
    7764:      	movzbl	%al, %ebx
    7767:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    776c:      	movq	%r11, 0x20(%rsp)
    7771:      	movl	0x10(%r12), %eax
    7776:      	movl	%eax, 0x40(%rsp)
    777a:      	movl	$0x0, 0x80(%rsp)
    7785:      	movl	$0x1, %eax
    778a:      	leaq	0x40(%rsp), %rsi
    778f:      	movq	(%rip), %rdi            # 0x7796 <generic_rawtp_filter_arg+0x1876>
    7796:      	callq	*%rax
    7798:      	testl	%ebp, %ebp
    779a:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    77a0:      	movq	%rax, %r13
    77a3:      	movl	$0x0, %ebx
    77a8:      	testq	%rax, %rax
    77ab:      	je	0x91a6 <generic_rawtp_filter_arg+0x3286>
    77b1:      	movl	$0x1, %eax
    77b6:      	movq	0x38(%rsp), %rsi
    77bb:      	movq	(%rip), %rdi            # 0x77c2 <generic_rawtp_filter_arg+0x18a2>
    77c2:      	callq	*%rax
    77c4:      	testq	%rax, %rax
    77c7:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    77cd:      	cmpl	$0xff, %ebp
    77d3:      	movl	$0xff, %ecx
    77d8:      	cmovael	%ecx, %ebp
    77db:      	leal	(,%rbp,8), %ecx
    77e2:      	movl	%ecx, (%rax)
    77e4:      	movq	%rax, %rdi
    77e7:      	addq	$0x4, %rdi
    77eb:      	movq	%rax, %rbx
    77ee:      	movl	$0x4, %eax
    77f3:      	movq	0x8(%rsp), %rdx
    77f8:      	movl	%ebp, %esi
    77fa:      	callq	*%rax
    77fc:      	movl	$0x1, %eax
    7801:      	movq	%r13, %rdi
    7804:      	movq	%rbx, %rsi
    7807:      	jmp	0x9198 <generic_rawtp_filter_arg+0x3278>
    780c:      	movl	$0x0, 0x80(%rsp)
    7817:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    781d:      	jbe	0x7ef7 <generic_rawtp_filter_arg+0x1fd7>
    7823:      	xorl	%ebx, %ebx
    7825:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    782a:      	xorl	%ebx, %ebx
    782c:      	movq	0x10(%rsp), %rdi
    7831:      	movq	0x18(%rsp), %r9
    7836:      	movq	%rbp, %r11
    7839:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    783e:      	cmpl	$0x1e, %eax
    7841:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    7847:      	movl	0x10(%r12), %eax
    784c:      	andl	$0x7, %eax
    784f:      	movl	%eax, %ecx
    7851:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    785a:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    7860:      	movq	0x8(%rsp), %rcx
    7865:      	movq	(%rcx), %rcx
    7868:      	movq	0x5e78(%r14,%rax,8), %rax
    7870:      	andl	$0x7ff, %eax            # imm = 0x7FF
    7875:      	xorl	%ebx, %ebx
    7877:      	andnq	0x90(%r14,%rax), %rcx, %rax
    7881:      	setne	%bl
    7884:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    7889:      	movzwl	%r13w, %eax
    788d:      	xorl	%ebx, %ebx
    788f:      	cmpl	$0x400, %eax            # imm = 0x400
    7894:      	setb	%bl
    7897:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    789c:      	movzwl	%r13w, %eax
    78a0:      	xorl	%ebx, %ebx
    78a2:      	cmpl	$0x400, %eax            # imm = 0x400
    78a7:      	setae	%bl
    78aa:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    78af:      	cmpl	$0x101, %eax            # imm = 0x101
    78b4:      	movl	$0x100, %esi            # imm = 0x100
    78b9:      	movl	$0x1fe, %eax            # imm = 0x1FE
    78be:      	cmovael	%eax, %esi
    78c1:      	movl	%esi, %eax
    78c3:      	movzwl	%ax, %ecx
    78c6:      	xorl	%eax, %eax
    78c8:      	cmpl	$0x100, %ecx            # imm = 0x100
    78ce:      	sete	%al
    78d1:      	xorl	$0x7, %eax
    78d4:      	movl	%eax, %ecx
    78d6:      	andl	$0xf, %ecx
    78d9:      	movl	0x10(%r12,%rcx,4), %ecx
    78de:      	cmpl	$-0x1, %ecx
    78e1:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    78e7:      	movl	%ecx, 0xa0(%rsp)
    78ee:      	movq	%rsi, 0x98(%rsp)
    78f6:      	movl	%eax, 0x70(%rsp)
    78fa:      	movl	$0x1, %eax
    78ff:      	movq	(%rip), %rdi            # 0x7906 <generic_rawtp_filter_arg+0x19e6>
    7906:      	movq	0x38(%rsp), %rbx
    790b:      	movq	%rbx, %rsi
    790e:      	callq	*%rax
    7910:      	movq	%rax, 0x28(%rsp)
    7915:      	movl	$0x1, %eax
    791a:      	movq	(%rip), %rdi            # 0x7921 <generic_rawtp_filter_arg+0x1a01>
    7921:      	movq	%rbx, %rsi
    7924:      	callq	*%rax
    7926:      	cmpq	$0x0, 0x28(%rsp)
    792c:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    7932:      	movl	$0x0, %ebx
    7937:      	testq	%rax, %rax
    793a:      	movq	0x10(%rsp), %rdi
    793f:      	movq	0x18(%rsp), %r9
    7944:      	movq	0x20(%rsp), %r11
    7949:      	je	0x8d0a <generic_rawtp_filter_arg+0x2dea>
    794f:      	movq	%rax, 0xa8(%rsp)
    7957:      	movq	0x8(%rsp), %rdx
    795c:      	addq	$0x4, %rdx
    7960:      	movl	0x70(%rsp), %ebx
    7964:      	cmpl	$0x5, %ebx
    7967:      	jg	0x8310 <generic_rawtp_filter_arg+0x23f0>
    796d:      	movq	0x28(%rsp), %rax
    7972:      	movb	%bpl, (%rax)
    7975:      	leaq	0x1(%rax), %rdi
    7979:      	movl	$0x4, %eax
    797e:      	movl	%ebp, %esi
    7980:      	callq	*%rax
    7982:      	movq	0x98(%rsp), %rsi
    798a:      	subl	%ebp, %esi
    798c:      	jbe	0x8353 <generic_rawtp_filter_arg+0x2433>
    7992:      	movq	0x28(%rsp), %rax
    7997:      	leaq	(%rax,%rbp), %rdi
    799b:      	incq	%rdi
    799e:      	andl	$0xfff, %esi            # imm = 0xFFF
    79a4:      	movl	$0x4, %eax
    79a9:      	movq	0xa8(%rsp), %rdx
    79b1:      	jmp	0x8351 <generic_rawtp_filter_arg+0x2431>
    79b6:      	movq	%r8, %rbx
    79b9:      	movq	%rdx, %r13
    79bc:      	movq	%r11, 0x20(%rsp)
    79c1:      	movl	0x14(%r12), %eax
    79c6:      	movl	%eax, 0x34(%rsp)
    79ca:      	movl	$0x1, %eax
    79cf:      	movq	(%rip), %rdi            # 0x79d6 <generic_rawtp_filter_arg+0x1ab6>
    79d6:      	leaq	0x34(%rsp), %rsi
    79db:      	callq	*%rax
    79dd:      	testq	%rax, %rax
    79e0:      	je	0x7c7b <generic_rawtp_filter_arg+0x1d5b>
    79e6:      	movq	%rax, %rdi
    79e9:      	movl	$0x80, 0x80(%rsp)
    79f4:      	movl	%r13d, 0x84(%rsp)
    79fc:      	movl	%ebp, 0x88(%rsp)
    7a03:      	movl	%ebx, 0x8c(%rsp)
    7a0a:      	shrq	$0x20, %rbx
    7a0e:      	movl	%ebx, 0x90(%rsp)
    7a15:      	movl	$0x1, %eax
    7a1a:      	movq	0x38(%rsp), %rsi
    7a1f:      	callq	*%rax
    7a21:      	movl	0x4(%r12), %ecx
    7a26:      	leal	-0x18(%rcx), %edx
    7a29:      	cmpl	$0x2, %edx
    7a2c:      	jb	0x7fe7 <generic_rawtp_filter_arg+0x20c7>
    7a32:      	addl	$-0xd, %ecx
    7a35:      	cmpl	$0x1, %ecx
    7a38:      	movq	0x10(%rsp), %rdi
    7a3d:      	movq	0x18(%rsp), %r9
    7a42:      	movq	0x20(%rsp), %r11
    7a47:      	ja	0x7a57 <generic_rawtp_filter_arg+0x1b37>
    7a49:      	testq	%rax, %rax
    7a4c:      	setne	%al
    7a4f:      	movzbl	%al, %ebx
    7a52:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    7a57:      	xorl	%eax, %eax
    7a59:      	movzbl	%al, %ebx
    7a5c:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    7a61:      	movq	0x8(%rsp), %rax
    7a66:      	movq	(%rax), %rax
    7a69:      	cmpq	%rax, %rsi
    7a6c:      	ja	0x7a77 <generic_rawtp_filter_arg+0x1b57>
    7a6e:      	cmpq	%rdx, %rax
    7a71:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7a77:      	movl	0x8(%r12), %edx
    7a7c:      	cmpl	$0x19, %edx
    7a7f:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    7a85:      	movq	0x20(%r12), %rdi
    7a8a:      	movq	0x28(%r12), %rsi
    7a8f:      	cmpl	$0xc, %ecx
    7a92:      	je	0x7a9d <generic_rawtp_filter_arg+0x1b7d>
    7a94:      	cmpl	$0xa, %ecx
    7a97:      	jne	0x8102 <generic_rawtp_filter_arg+0x21e2>
    7a9d:      	cmpq	%rax, %rdi
    7aa0:      	movq	0x10(%rsp), %rdi
    7aa5:      	jg	0x8115 <generic_rawtp_filter_arg+0x21f5>
    7aab:      	cmpq	%rsi, %rax
    7aae:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7ab4:      	jmp	0x8115 <generic_rawtp_filter_arg+0x21f5>
    7ab9:      	movq	0x8(%rsp), %rdx
    7abe:      	movq	(%rdx), %rdx
    7ac1:      	cmpq	%rdx, %rsi
    7ac4:      	setbe	%sil
    7ac8:      	cmpq	%rax, %rdx
    7acb:      	setbe	%al
    7ace:      	andb	%sil, %al
    7ad1:      	movl	0x8(%r12), %esi
    7ad6:      	cmpl	$0x19, %esi
    7ad9:      	jb	0x8d49 <generic_rawtp_filter_arg+0x2e29>
    7adf:      	movq	0x20(%r12), %r8
    7ae4:      	movq	0x28(%r12), %rdi
    7ae9:      	cmpl	$0xc, %ecx
    7aec:      	je	0x7af7 <generic_rawtp_filter_arg+0x1bd7>
    7aee:      	cmpl	$0xa, %ecx
    7af1:      	jne	0x80ba <generic_rawtp_filter_arg+0x219a>
    7af7:      	cmpq	%rdx, %r8
    7afa:      	setle	%r8b
    7afe:      	cmpq	%rdi, %rdx
    7b01:      	setle	%dil
    7b05:      	jmp	0x80c8 <generic_rawtp_filter_arg+0x21a8>
    7b0a:      	movzwl	0x26(%rsi), %ebx
    7b0e:      	movq	%r11, %r13
    7b11:      	movzbl	0x10(%r12), %eax
    7b17:      	movl	%eax, 0x34(%rsp)
    7b1b:      	movl	$0x1, %eax
    7b20:      	movq	(%rip), %rdi            # 0x7b27 <generic_rawtp_filter_arg+0x1c07>
    7b27:      	leaq	0x34(%rsp), %rsi
    7b2c:      	callq	*%rax
    7b2e:      	testq	%rax, %rax
    7b31:      	je	0x81b1 <generic_rawtp_filter_arg+0x2291>
    7b37:      	movq	%rax, %rdi
    7b3a:      	movzwl	%bx, %eax
    7b3d:      	movq	%rax, 0x80(%rsp)
    7b45:      	movl	$0x1, %eax
    7b4a:      	movq	0x38(%rsp), %rsi
    7b4f:      	callq	*%rax
    7b51:      	movl	0x4(%r12), %edx
    7b56:      	xorl	%ecx, %ecx
    7b58:      	cmpl	$0x1d, %edx
    7b5b:      	ja	0x8b5a <generic_rawtp_filter_arg+0x2c3a>
    7b61:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7b66:      	btl	%edx, %esi
    7b69:      	movq	0x10(%rsp), %rdi
    7b6e:      	movq	0x18(%rsp), %r9
    7b73:      	movq	%r13, %r11
    7b76:      	jb	0x61c9 <generic_rawtp_filter_arg+0x2a9>
    7b7c:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7b81:      	btl	%edx, %esi
    7b84:      	jae	0x61cf <generic_rawtp_filter_arg+0x2af>
    7b8a:      	testq	%rax, %rax
    7b8d:      	sete	%cl
    7b90:      	jmp	0x61cf <generic_rawtp_filter_arg+0x2af>
    7b95:      	movq	0x8(%rsp), %rsi
    7b9a:      	cmpq	%rdx, (%rsi)
    7b9d:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7ba3:      	jmp	0x7bb3 <generic_rawtp_filter_arg+0x1c93>
    7ba5:      	movq	0x8(%rsp), %rsi
    7baa:      	cmpq	%rdx, (%rsi)
    7bad:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7bb3:      	movl	0x8(%r12), %edx
    7bb8:      	cmpl	$0x11, %edx
    7bbb:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    7bc1:      	movq	0x18(%r12), %rsi
    7bc6:      	cmpl	$0x2, %eax
    7bc9:      	jle	0x7beb <generic_rawtp_filter_arg+0x1ccb>
    7bcb:      	leal	-0x3(%rax), %edi
    7bce:      	cmpl	$0x2, %edi
    7bd1:      	jae	0x7c1e <generic_rawtp_filter_arg+0x1cfe>
    7bd3:      	movq	0x8(%rsp), %rdi
    7bd8:      	cmpq	%rsi, (%rdi)
    7bdb:      	movq	0x10(%rsp), %rdi
    7be0:      	jne	0x8750 <generic_rawtp_filter_arg+0x2830>
    7be6:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    7beb:      	cmpl	$0x1, %eax
    7bee:      	je	0x7d93 <generic_rawtp_filter_arg+0x1e73>
    7bf4:      	cmpl	$0x2, %eax
    7bf7:      	jne	0x8750 <generic_rawtp_filter_arg+0x2830>
    7bfd:      	cmpl	$0xc, %ecx
    7c00:      	je	0x7c0b <generic_rawtp_filter_arg+0x1ceb>
    7c02:      	cmpl	$0xa, %ecx
    7c05:      	jne	0x8742 <generic_rawtp_filter_arg+0x2822>
    7c0b:      	movq	0x8(%rsp), %r8
    7c10:      	cmpq	%rsi, (%r8)
    7c13:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7c19:      	jmp	0x8750 <generic_rawtp_filter_arg+0x2830>
    7c1e:      	cmpl	$0xc, %eax
    7c21:      	movq	0x10(%rsp), %rdi
    7c26:      	jne	0x8750 <generic_rawtp_filter_arg+0x2830>
    7c2c:      	movq	0x8(%rsp), %r8
    7c31:      	testq	%rsi, (%r8)
    7c34:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7c3a:      	jmp	0x8750 <generic_rawtp_filter_arg+0x2830>
    7c3f:      	cmpl	$0xc, %eax
    7c42:      	jne	0x7f5d <generic_rawtp_filter_arg+0x203d>
    7c48:      	movq	0x8(%rsp), %rdx
    7c4d:      	movzbl	(%rdx), %edx
    7c50:      	testl	%edx, %ecx
    7c52:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7c58:      	jmp	0x7f5d <generic_rawtp_filter_arg+0x203d>
    7c5d:      	cmpl	$0xc, %eax
    7c60:      	jne	0x7faa <generic_rawtp_filter_arg+0x208a>
    7c66:      	movq	0x8(%rsp), %rdx
    7c6b:      	movzwl	(%rdx), %edx
    7c6e:      	testl	%edx, %ecx
    7c70:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7c76:      	jmp	0x7faa <generic_rawtp_filter_arg+0x208a>
    7c7b:      	movl	0x4(%r12), %eax
    7c80:      	andl	$-0x2, %eax
    7c83:      	cmpl	$0x18, %eax
    7c86:      	jmp	0x7fea <generic_rawtp_filter_arg+0x20ca>
    7c8b:      	cmpl	$0x101, %eax            # imm = 0x101
    7c90:      	movl	$0x100, %edi            # imm = 0x100
    7c95:      	movl	$0x1fe, %eax            # imm = 0x1FE
    7c9a:      	cmovael	%eax, %edi
    7c9d:      	movl	%edi, %eax
    7c9f:      	movzwl	%ax, %ecx
    7ca2:      	xorl	%eax, %eax
    7ca4:      	cmpl	$0x100, %ecx            # imm = 0x100
    7caa:      	sete	%al
    7cad:      	xorl	$0x7, %eax
    7cb0:      	movl	%eax, %ecx
    7cb2:      	andl	$0xf, %ecx
    7cb5:      	movl	0x10(%r12,%rcx,4), %ecx
    7cba:      	cmpl	$-0x1, %ecx
    7cbd:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    7cc3:      	movl	%ecx, 0xa0(%rsp)
    7cca:      	movq	%rdi, 0x98(%rsp)
    7cd2:      	movl	%eax, 0x70(%rsp)
    7cd6:      	movq	%rsi, 0x8(%rsp)
    7cdb:      	movl	$0x1, %eax
    7ce0:      	movq	(%rip), %rdi            # 0x7ce7 <generic_rawtp_filter_arg+0x1dc7>
    7ce7:      	movq	0x38(%rsp), %rbx
    7cec:      	movq	%rbx, %rsi
    7cef:      	callq	*%rax
    7cf1:      	movq	%rax, 0x28(%rsp)
    7cf6:      	movl	$0x1, %eax
    7cfb:      	movq	(%rip), %rdi            # 0x7d02 <generic_rawtp_filter_arg+0x1de2>
    7d02:      	movq	%rbx, %rsi
    7d05:      	callq	*%rax
    7d07:      	cmpq	$0x0, 0x28(%rsp)
    7d0d:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    7d13:      	movl	$0x0, %ebx
    7d18:      	testq	%rax, %rax
    7d1b:      	movq	0x10(%rsp), %rdi
    7d20:      	movq	0x18(%rsp), %r9
    7d25:      	movq	0x20(%rsp), %r11
    7d2a:      	je	0x8ee7 <generic_rawtp_filter_arg+0x2fc7>
    7d30:      	movq	%rax, 0xa8(%rsp)
    7d38:      	movl	0x70(%rsp), %ebx
    7d3c:      	cmpl	$0x5, %ebx
    7d3f:      	jg	0x861a <generic_rawtp_filter_arg+0x26fa>
    7d45:      	movq	0x28(%rsp), %rax
    7d4a:      	movb	%bpl, (%rax)
    7d4d:      	leaq	0x1(%rax), %rdi
    7d51:      	movl	$0x4, %eax
    7d56:      	movq	0x8(%rsp), %rdx
    7d5b:      	movl	%ebp, %esi
    7d5d:      	callq	*%rax
    7d5f:      	movq	0x98(%rsp), %rsi
    7d67:      	subl	%ebp, %esi
    7d69:      	jbe	0x8662 <generic_rawtp_filter_arg+0x2742>
    7d6f:      	movq	0x28(%rsp), %rax
    7d74:      	leaq	(%rax,%rbp), %rdi
    7d78:      	incq	%rdi
    7d7b:      	andl	$0xfff, %esi            # imm = 0xFFF
    7d81:      	movl	$0x4, %eax
    7d86:      	movq	0xa8(%rsp), %rdx
    7d8e:      	jmp	0x8660 <generic_rawtp_filter_arg+0x2740>
    7d93:      	cmpl	$0xc, %ecx
    7d96:      	je	0x7da1 <generic_rawtp_filter_arg+0x1e81>
    7d98:      	cmpl	$0xa, %ecx
    7d9b:      	jne	0x8732 <generic_rawtp_filter_arg+0x2812>
    7da1:      	movq	0x8(%rsp), %r8
    7da6:      	cmpq	%rsi, (%r8)
    7da9:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7daf:      	jmp	0x8750 <generic_rawtp_filter_arg+0x2830>
    7db4:      	movl	0x8(%r12), %edx
    7db9:      	movq	0x8(%rsp), %rax
    7dbe:      	movzbl	(%rax), %ecx
    7dc1:      	jmp	0x7dd0 <generic_rawtp_filter_arg+0x1eb0>
    7dc3:      	movl	0x8(%r12), %edx
    7dc8:      	movq	0x8(%rsp), %rax
    7dcd:      	movzwl	(%rax), %ecx
    7dd0:      	cmpl	%ecx, 0x10(%r12)
    7dd5:      	setbe	%sil
    7dd9:      	cmpl	%ecx, 0x14(%r12)
    7dde:      	setae	%al
    7de1:      	andb	%sil, %al
    7de4:      	cmpl	$0x11, %edx
    7de7:      	jb	0x8d49 <generic_rawtp_filter_arg+0x2e29>
    7ded:      	cmpl	%ecx, 0x18(%r12)
    7df2:      	setbe	%sil
    7df6:      	cmpl	%ecx, 0x1c(%r12)
    7dfb:      	setae	%dil
    7dff:      	andb	%sil, %dil
    7e02:      	orb	%dil, %al
    7e05:      	cmpl	$0x19, %edx
    7e08:      	jb	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    7e0e:      	cmpl	%ecx, 0x20(%r12)
    7e13:      	setbe	%sil
    7e17:      	cmpl	%ecx, 0x24(%r12)
    7e1c:      	setae	%dil
    7e20:      	andb	%sil, %dil
    7e23:      	orb	%dil, %al
    7e26:      	cmpl	$0x21, %edx
    7e29:      	jb	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    7e2f:      	cmpl	%ecx, 0x28(%r12)
    7e34:      	setbe	%dl
    7e37:      	cmpl	%ecx, 0x2c(%r12)
    7e3c:      	setae	%cl
    7e3f:      	andb	%dl, %cl
    7e41:      	orb	%cl, %al
    7e43:      	jmp	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    7e48:      	xorl	%ebx, %ebx
    7e4a:      	xorl	%r13d, %r13d
    7e4d:      	movq	%r11, %r15
    7e50:      	movl	0x10(%r12,%rbx,4), %eax
    7e55:      	movl	%eax, 0x40(%rsp)
    7e59:      	movl	$0x1, %eax
    7e5e:      	leaq	0x40(%rsp), %rsi
    7e63:      	movq	(%rip), %rdi            # 0x7e6a <generic_rawtp_filter_arg+0x1f4a>
    7e6a:      	callq	*%rax
    7e6c:      	testq	%rax, %rax
    7e6f:      	je	0x8849 <generic_rawtp_filter_arg+0x2929>
    7e75:      	testl	%ebp, %ebp
    7e77:      	movq	0x18(%rsp), %r9
    7e7c:      	movq	%r15, %r11
    7e7f:      	movq	0x68(%rsp), %r15
    7e84:      	je	0x7ecf <generic_rawtp_filter_arg+0x1faf>
    7e86:      	movq	0x8(%rsp), %rdx
    7e8b:      	xorl	%ecx, %ecx
    7e8d:      	jmp	0x7e9a <generic_rawtp_filter_arg+0x1f7a>
    7e8f:      	incq	%rcx
    7e92:      	incq	%rdx
    7e95:      	cmpq	%rbp, %rcx
    7e98:      	je	0x7ecf <generic_rawtp_filter_arg+0x1faf>
    7e9a:      	xorl	%esi, %esi
    7e9c:      	nopl	(%rax)
    7ea0:      	leaq	(%rcx,%rsi), %rdi
    7ea4:      	cmpq	%rbp, %rdi
    7ea7:      	jae	0x7e8f <generic_rawtp_filter_arg+0x1f6f>
    7ea9:      	movzbl	(%rax,%rsi), %edi
    7ead:      	testb	%dil, %dil
    7eb0:      	je	0x7ec7 <generic_rawtp_filter_arg+0x1fa7>
    7eb2:      	cmpq	$0x62, %rsi
    7eb6:      	ja	0x7e8f <generic_rawtp_filter_arg+0x1f6f>
    7eb8:      	leaq	0x1(%rsi), %r8
    7ebc:      	cmpb	%dil, (%rdx,%rsi)
    7ec0:      	movq	%r8, %rsi
    7ec3:      	je	0x7ea0 <generic_rawtp_filter_arg+0x1f80>
    7ec5:      	jmp	0x7e8f <generic_rawtp_filter_arg+0x1f6f>
    7ec7:      	testl	%ecx, %ecx
    7ec9:      	jns	0x8bba <generic_rawtp_filter_arg+0x2c9a>
    7ecf:      	leal	0xc(%r13), %eax
    7ed3:      	cmpl	0x8(%r12), %eax
    7ed8:      	jae	0x7eeb <generic_rawtp_filter_arg+0x1fcb>
    7eda:      	addl	$0x4, %r13d
    7ede:      	incq	%rbx
    7ee1:      	cmpq	$0x64, %rbx
    7ee5:      	jne	0x7e4d <generic_rawtp_filter_arg+0x1f2d>
    7eeb:      	xorl	%ebx, %ebx
    7eed:      	movq	0x10(%rsp), %rdi
    7ef2:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    7ef7:      	movzwl	%bp, %eax
    7efa:      	cmpl	$0x90, %eax
    7eff:      	movq	%r11, 0x20(%rsp)
    7f04:      	ja	0x83e2 <generic_rawtp_filter_arg+0x24c2>
    7f0a:      	testw	%bp, %bp
    7f0d:      	je	0x7f1f <generic_rawtp_filter_arg+0x1fff>
    7f0f:      	movl	%ebp, %eax
    7f11:      	movl	$0x18, %ecx
    7f16:      	cltd
    7f17:      	idivl	%ecx
    7f19:      	movl	%ebp, %edi
    7f1b:      	testl	%edx, %edx
    7f1d:      	je	0x7f41 <generic_rawtp_filter_arg+0x2021>
    7f1f:      	movl	%ebp, %eax
    7f21:      	movl	$0x18, %ecx
    7f26:      	cltd
    7f27:      	idivl	%ecx
    7f29:      	shll	$0x3, %eax
    7f2c:      	leal	(%rax,%rax,2), %eax
    7f2f:      	addl	$0x18, %eax
    7f32:      	movzwl	%ax, %edi
    7f35:      	cmpl	$0x90, %edi
    7f3b:      	ja	0x83f6 <generic_rawtp_filter_arg+0x24d6>
    7f41:      	movl	%edi, %eax
    7f43:      	cltd
    7f44:      	idivl	%ecx
    7f46:      	decl	%eax
    7f48:      	jmp	0x8407 <generic_rawtp_filter_arg+0x24e7>
    7f4d:      	movq	0x8(%rsp), %rdx
    7f52:      	movzbl	(%rdx), %edx
    7f55:      	cmpl	%edx, %ecx
    7f57:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7f5d:      	movl	0x8(%r12), %ecx
    7f62:      	cmpl	$0xd, %ecx
    7f65:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    7f6b:      	movl	0x14(%r12), %edx
    7f70:      	cmpl	$0x2, %eax
    7f73:      	jle	0x82c2 <generic_rawtp_filter_arg+0x23a2>
    7f79:      	leal	-0x3(%rax), %esi
    7f7c:      	cmpl	$0x2, %esi
    7f7f:      	jae	0x87d7 <generic_rawtp_filter_arg+0x28b7>
    7f85:      	movq	0x8(%rsp), %rsi
    7f8a:      	movzbl	(%rsi), %esi
    7f8d:      	cmpl	%esi, %edx
    7f8f:      	jne	0x88e2 <generic_rawtp_filter_arg+0x29c2>
    7f95:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    7f9a:      	movq	0x8(%rsp), %rdx
    7f9f:      	movzwl	(%rdx), %edx
    7fa2:      	cmpl	%edx, %ecx
    7fa4:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    7faa:      	movl	0x8(%r12), %ecx
    7faf:      	cmpl	$0xd, %ecx
    7fb2:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    7fb8:      	movl	0x14(%r12), %edx
    7fbd:      	cmpl	$0x2, %eax
    7fc0:      	jle	0x82e9 <generic_rawtp_filter_arg+0x23c9>
    7fc6:      	leal	-0x3(%rax), %esi
    7fc9:      	cmpl	$0x2, %esi
    7fcc:      	jae	0x87f5 <generic_rawtp_filter_arg+0x28d5>
    7fd2:      	movq	0x8(%rsp), %rsi
    7fd7:      	movzwl	(%rsi), %esi
    7fda:      	cmpl	%esi, %edx
    7fdc:      	jne	0x892a <generic_rawtp_filter_arg+0x2a0a>
    7fe2:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    7fe7:      	testq	%rax, %rax
    7fea:      	sete	%al
    7fed:      	movq	0x10(%rsp), %rdi
    7ff2:      	movq	0x18(%rsp), %r9
    7ff7:      	movq	0x20(%rsp), %r11
    7ffc:      	movzbl	%al, %ebx
    7fff:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    8004:      	movq	0x8(%rsp), %rax
    8009:      	movl	(%rax), %eax
    800b:      	cmpl	%eax, %esi
    800d:      	ja	0x8017 <generic_rawtp_filter_arg+0x20f7>
    800f:      	cmpl	%edx, %eax
    8011:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8017:      	movl	0x8(%r12), %edx
    801c:      	cmpl	$0x11, %edx
    801f:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    8025:      	movl	0x18(%r12), %edi
    802a:      	movl	0x1c(%r12), %esi
    802f:      	cmpl	$0xc, %ecx
    8032:      	ja	0x852e <generic_rawtp_filter_arg+0x260e>
    8038:      	movl	$0x1402, %r8d           # imm = 0x1402
    803e:      	btl	%ecx, %r8d
    8042:      	jae	0x852e <generic_rawtp_filter_arg+0x260e>
    8048:      	cmpl	%eax, %edi
    804a:      	movq	0x10(%rsp), %rdi
    804f:      	jg	0x853f <generic_rawtp_filter_arg+0x261f>
    8055:      	cmpl	%esi, %eax
    8057:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    805d:      	jmp	0x853f <generic_rawtp_filter_arg+0x261f>
    8062:      	movq	0x8(%rsp), %rdx
    8067:      	movl	(%rdx), %edx
    8069:      	cmpl	%edx, %esi
    806b:      	setbe	%sil
    806f:      	cmpl	%eax, %edx
    8071:      	setbe	%al
    8074:      	andb	%sil, %al
    8077:      	movl	0x8(%r12), %esi
    807c:      	cmpl	$0x11, %esi
    807f:      	jb	0x8d49 <generic_rawtp_filter_arg+0x2e29>
    8085:      	movl	0x18(%r12), %r8d
    808a:      	movl	0x1c(%r12), %edi
    808f:      	cmpl	$0xc, %ecx
    8092:      	ja	0x84dd <generic_rawtp_filter_arg+0x25bd>
    8098:      	movl	$0x1402, %r10d          # imm = 0x1402
    809e:      	btl	%ecx, %r10d
    80a2:      	jae	0x84dd <generic_rawtp_filter_arg+0x25bd>
    80a8:      	cmpl	%edx, %r8d
    80ab:      	setle	%r8b
    80af:      	cmpl	%edi, %edx
    80b1:      	setle	%dil
    80b5:      	jmp	0x84ea <generic_rawtp_filter_arg+0x25ca>
    80ba:      	cmpq	%rdx, %r8
    80bd:      	setbe	%r8b
    80c1:      	cmpq	%rdi, %rdx
    80c4:      	setbe	%dil
    80c8:      	andb	%r8b, %dil
    80cb:      	orb	%dil, %al
    80ce:      	cmpl	$0x29, %esi
    80d1:      	jb	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    80d7:      	movq	0x30(%r12), %r8
    80dc:      	movq	0x38(%r12), %rdi
    80e1:      	cmpl	$0xc, %ecx
    80e4:      	je	0x80ef <generic_rawtp_filter_arg+0x21cf>
    80e6:      	cmpl	$0xa, %ecx
    80e9:      	jne	0x85d0 <generic_rawtp_filter_arg+0x26b0>
    80ef:      	cmpq	%rdx, %r8
    80f2:      	setle	%r8b
    80f6:      	cmpq	%rdi, %rdx
    80f9:      	setle	%dil
    80fd:      	jmp	0x85de <generic_rawtp_filter_arg+0x26be>
    8102:      	cmpq	%rax, %rdi
    8105:      	movq	0x10(%rsp), %rdi
    810a:      	ja	0x8115 <generic_rawtp_filter_arg+0x21f5>
    810c:      	cmpq	%rsi, %rax
    810f:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8115:      	cmpl	$0x29, %edx
    8118:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    811e:      	movq	0x30(%r12), %rdi
    8123:      	movq	0x38(%r12), %rsi
    8128:      	cmpl	$0xc, %ecx
    812b:      	je	0x8136 <generic_rawtp_filter_arg+0x2216>
    812d:      	cmpl	$0xa, %ecx
    8130:      	jne	0x86e7 <generic_rawtp_filter_arg+0x27c7>
    8136:      	cmpq	%rax, %rdi
    8139:      	movq	0x10(%rsp), %rdi
    813e:      	jg	0x86fa <generic_rawtp_filter_arg+0x27da>
    8144:      	cmpq	%rsi, %rax
    8147:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    814d:      	jmp	0x86fa <generic_rawtp_filter_arg+0x27da>
    8152:      	xorl	%ebx, %ebx
    8154:      	cmpl	$0x29, %ecx
    8157:      	jne	0x8162 <generic_rawtp_filter_arg+0x2242>
    8159:      	testq	%rdx, %rdx
    815c:      	je	0x8162 <generic_rawtp_filter_arg+0x2242>
    815e:      	movzbl	0x3a(%rdx), %ebx
    8162:      	cmpl	$0x29, %ecx
    8165:      	je	0x8170 <generic_rawtp_filter_arg+0x2250>
    8167:      	cmpl	$0x7, %ecx
    816a:      	jne	0x8613 <generic_rawtp_filter_arg+0x26f3>
    8170:      	movq	%r11, %r13
    8173:      	movzbl	0x10(%r12), %eax
    8179:      	movl	%eax, 0x34(%rsp)
    817d:      	movl	$0x1, %eax
    8182:      	movq	(%rip), %rdi            # 0x8189 <generic_rawtp_filter_arg+0x2269>
    8189:      	leaq	0x34(%rsp), %rsi
    818e:      	callq	*%rax
    8190:      	testq	%rax, %rax
    8193:      	je	0x81b1 <generic_rawtp_filter_arg+0x2291>
    8195:      	movq	%rax, %rdi
    8198:      	movl	%ebx, %eax
    819a:      	movq	%rax, 0x80(%rsp)
    81a2:      	movl	$0x1, %eax
    81a7:      	movq	0x38(%rsp), %rsi
    81ac:      	jmp	0x7b4f <generic_rawtp_filter_arg+0x1c2f>
    81b1:      	xorl	%ebx, %ebx
    81b3:      	movq	0x10(%rsp), %rdi
    81b8:      	movq	0x18(%rsp), %r9
    81bd:      	movq	%r13, %r11
    81c0:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    81c5:      	movq	0x8(%rsp), %rsi
    81ca:      	cmpl	%edx, (%rsi)
    81cc:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    81d2:      	jmp	0x81e1 <generic_rawtp_filter_arg+0x22c1>
    81d4:      	movq	0x8(%rsp), %rsi
    81d9:      	cmpl	%edx, (%rsi)
    81db:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    81e1:      	movl	0x8(%r12), %edx
    81e6:      	cmpl	$0xd, %edx
    81e9:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    81ef:      	movl	0x14(%r12), %esi
    81f4:      	cmpl	$0x2, %eax
    81f7:      	jle	0x8218 <generic_rawtp_filter_arg+0x22f8>
    81f9:      	leal	-0x3(%rax), %edi
    81fc:      	cmpl	$0x2, %edi
    81ff:      	jae	0x8252 <generic_rawtp_filter_arg+0x2332>
    8201:      	movq	0x8(%rsp), %rdi
    8206:      	cmpl	%esi, (%rdi)
    8208:      	movq	0x10(%rsp), %rdi
    820d:      	jne	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    8213:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    8218:      	cmpl	$0x1, %eax
    821b:      	je	0x8273 <generic_rawtp_filter_arg+0x2353>
    821d:      	cmpl	$0x2, %eax
    8220:      	jne	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    8226:      	cmpl	$0xc, %ecx
    8229:      	ja	0x8a1e <generic_rawtp_filter_arg+0x2afe>
    822f:      	movl	$0x1402, %r8d           # imm = 0x1402
    8235:      	btl	%ecx, %r8d
    8239:      	jae	0x8a1e <generic_rawtp_filter_arg+0x2afe>
    823f:      	movq	0x8(%rsp), %r8
    8244:      	cmpl	%esi, (%r8)
    8247:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    824d:      	jmp	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    8252:      	cmpl	$0xc, %eax
    8255:      	movq	0x10(%rsp), %rdi
    825a:      	jne	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    8260:      	movq	0x8(%rsp), %r8
    8265:      	testl	%esi, (%r8)
    8268:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    826e:      	jmp	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    8273:      	cmpl	$0xc, %ecx
    8276:      	ja	0x8a0e <generic_rawtp_filter_arg+0x2aee>
    827c:      	movl	$0x1402, %r8d           # imm = 0x1402
    8282:      	btl	%ecx, %r8d
    8286:      	jae	0x8a0e <generic_rawtp_filter_arg+0x2aee>
    828c:      	movq	0x8(%rsp), %r8
    8291:      	cmpl	%esi, (%r8)
    8294:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    829a:      	jmp	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    829f:      	xorl	%ebx, %ebx
    82a1:      	movq	0x18(%rsp), %r9
    82a6:      	movq	%r15, %r11
    82a9:      	movq	0x68(%rsp), %r15
    82ae:      	jmp	0x858a <generic_rawtp_filter_arg+0x266a>
    82b3:      	xorl	%ebx, %ebx
    82b5:      	movq	%r15, %r11
    82b8:      	movq	0x68(%rsp), %r15
    82bd:      	jmp	0x85ad <generic_rawtp_filter_arg+0x268d>
    82c2:      	cmpl	$0x1, %eax
    82c5:      	je	0x88d2 <generic_rawtp_filter_arg+0x29b2>
    82cb:      	cmpl	$0x2, %eax
    82ce:      	jne	0x88e2 <generic_rawtp_filter_arg+0x29c2>
    82d4:      	movq	0x8(%rsp), %rsi
    82d9:      	movzbl	(%rsi), %esi
    82dc:      	cmpl	%esi, %edx
    82de:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    82e4:      	jmp	0x88e2 <generic_rawtp_filter_arg+0x29c2>
    82e9:      	cmpl	$0x1, %eax
    82ec:      	je	0x891a <generic_rawtp_filter_arg+0x29fa>
    82f2:      	cmpl	$0x2, %eax
    82f5:      	jne	0x892a <generic_rawtp_filter_arg+0x2a0a>
    82fb:      	movq	0x8(%rsp), %rsi
    8300:      	movzwl	(%rsi), %esi
    8303:      	cmpl	%esi, %edx
    8305:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    830b:      	jmp	0x892a <generic_rawtp_filter_arg+0x2a0a>
    8310:      	movq	0x28(%rsp), %rax
    8315:      	movw	%bp, (%rax)
    8318:      	leaq	0x2(%rax), %rdi
    831c:      	movl	$0x4, %eax
    8321:      	movl	%ebp, %esi
    8323:      	callq	*%rax
    8325:      	movq	0x98(%rsp), %rsi
    832d:      	subl	%ebp, %esi
    832f:      	jbe	0x8353 <generic_rawtp_filter_arg+0x2433>
    8331:      	movq	0x28(%rsp), %rax
    8336:      	leaq	(%rax,%rbp), %rdi
    833a:      	addq	$0x2, %rdi
    833e:      	andl	$0xfff, %esi            # imm = 0xFFF
    8344:      	movl	$0x4, %eax
    8349:      	movq	0xa8(%rsp), %rdx
    8351:      	callq	*%rax
    8353:      	movl	0xa0(%rsp), %eax
    835a:      	movl	%eax, 0x40(%rsp)
    835e:      	cmpl	$0x3, %ebx
    8361:      	jg	0x83a2 <generic_rawtp_filter_arg+0x2482>
    8363:      	cmpl	$0x1, %ebx
    8366:      	movq	0x10(%rsp), %rdi
    836b:      	movq	0x18(%rsp), %r9
    8370:      	movq	0x20(%rsp), %r11
    8375:      	jg	0x8862 <generic_rawtp_filter_arg+0x2942>
    837b:      	testl	%ebx, %ebx
    837d:      	je	0x8c8f <generic_rawtp_filter_arg+0x2d6f>
    8383:      	cmpl	$0x1, %ebx
    8386:      	jne	0x6863 <generic_rawtp_filter_arg+0x943>
    838c:      	movl	$0x1, %eax
    8391:      	leaq	0x40(%rsp), %rsi
    8396:      	movq	(%rip), %rdi            # 0x839d <generic_rawtp_filter_arg+0x247d>
    839d:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    83a2:      	cmpl	$0x5, %ebx
    83a5:      	movq	0x10(%rsp), %rdi
    83aa:      	movq	0x18(%rsp), %r9
    83af:      	movq	0x20(%rsp), %r11
    83b4:      	jg	0x888a <generic_rawtp_filter_arg+0x296a>
    83ba:      	cmpl	$0x4, %ebx
    83bd:      	je	0x8ca2 <generic_rawtp_filter_arg+0x2d82>
    83c3:      	cmpl	$0x5, %ebx
    83c6:      	jne	0x6863 <generic_rawtp_filter_arg+0x943>
    83cc:      	movl	$0x1, %eax
    83d1:      	leaq	0x40(%rsp), %rsi
    83d6:      	movq	(%rip), %rdi            # 0x83dd <generic_rawtp_filter_arg+0x24bd>
    83dd:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    83e2:      	cmpl	$0x101, %eax            # imm = 0x101
    83e7:      	movl	$0x100, %edi            # imm = 0x100
    83ec:      	movl	$0x1fe, %eax            # imm = 0x1FE
    83f1:      	cmovael	%eax, %edi
    83f4:      	movl	%edi, %eax
    83f6:      	movzwl	%ax, %ecx
    83f9:      	xorl	%eax, %eax
    83fb:      	cmpl	$0x100, %ecx            # imm = 0x100
    8401:      	sete	%al
    8404:      	xorl	$0x7, %eax
    8407:      	movl	%eax, %ecx
    8409:      	andl	$0xf, %ecx
    840c:      	movl	0x10(%r12,%rcx,4), %ecx
    8411:      	cmpl	$-0x1, %ecx
    8414:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    841a:      	movl	%ecx, 0x98(%rsp)
    8421:      	movq	%rdi, 0xa0(%rsp)
    8429:      	movl	%eax, 0x70(%rsp)
    842d:      	movq	%rsi, 0x8(%rsp)
    8432:      	movl	$0x1, %eax
    8437:      	movq	(%rip), %rdi            # 0x843e <generic_rawtp_filter_arg+0x251e>
    843e:      	movq	0x38(%rsp), %rbx
    8443:      	movq	%rbx, %rsi
    8446:      	callq	*%rax
    8448:      	movq	%rax, 0x28(%rsp)
    844d:      	movl	$0x1, %eax
    8452:      	movq	(%rip), %rdi            # 0x8459 <generic_rawtp_filter_arg+0x2539>
    8459:      	movq	%rbx, %rsi
    845c:      	callq	*%rax
    845e:      	cmpq	$0x0, 0x28(%rsp)
    8464:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    846a:      	movl	$0x0, %ebx
    846f:      	testq	%rax, %rax
    8472:      	movq	0x10(%rsp), %rdi
    8477:      	movq	0x18(%rsp), %r9
    847c:      	movq	0x20(%rsp), %r11
    8481:      	je	0x91b5 <generic_rawtp_filter_arg+0x3295>
    8487:      	movq	%rax, %r13
    848a:      	movl	0x70(%rsp), %ebx
    848e:      	cmpl	$0x5, %ebx
    8491:      	jg	0x8bdb <generic_rawtp_filter_arg+0x2cbb>
    8497:      	movq	0x28(%rsp), %rax
    849c:      	movb	%bpl, (%rax)
    849f:      	leaq	0x1(%rax), %rdi
    84a3:      	movl	$0x4, %eax
    84a8:      	movq	0x8(%rsp), %rdx
    84ad:      	movl	%ebp, %esi
    84af:      	callq	*%rax
    84b1:      	movq	0xa0(%rsp), %rsi
    84b9:      	subl	%ebp, %esi
    84bb:      	jbe	0x8c1e <generic_rawtp_filter_arg+0x2cfe>
    84c1:      	movq	0x28(%rsp), %rax
    84c6:      	leaq	(%rax,%rbp), %rdi
    84ca:      	incq	%rdi
    84cd:      	andl	$0xfff, %esi            # imm = 0xFFF
    84d3:      	movl	$0x4, %eax
    84d8:      	jmp	0x8c19 <generic_rawtp_filter_arg+0x2cf9>
    84dd:      	cmpl	%edx, %r8d
    84e0:      	setbe	%r8b
    84e4:      	cmpl	%edi, %edx
    84e6:      	setbe	%dil
    84ea:      	andb	%r8b, %dil
    84ed:      	orb	%dil, %al
    84f0:      	cmpl	$0x19, %esi
    84f3:      	jb	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    84f9:      	movl	0x20(%r12), %r8d
    84fe:      	movl	0x24(%r12), %edi
    8503:      	cmpl	$0xc, %ecx
    8506:      	ja	0x896e <generic_rawtp_filter_arg+0x2a4e>
    850c:      	movl	$0x1402, %r10d          # imm = 0x1402
    8512:      	btl	%ecx, %r10d
    8516:      	jae	0x896e <generic_rawtp_filter_arg+0x2a4e>
    851c:      	cmpl	%edx, %r8d
    851f:      	setle	%r8b
    8523:      	cmpl	%edi, %edx
    8525:      	setle	%dil
    8529:      	jmp	0x897b <generic_rawtp_filter_arg+0x2a5b>
    852e:      	cmpl	%eax, %edi
    8530:      	movq	0x10(%rsp), %rdi
    8535:      	ja	0x853f <generic_rawtp_filter_arg+0x261f>
    8537:      	cmpl	%esi, %eax
    8539:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    853f:      	cmpl	$0x19, %edx
    8542:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    8548:      	movl	0x20(%r12), %edi
    854d:      	movl	0x24(%r12), %esi
    8552:      	cmpl	$0xc, %ecx
    8555:      	ja	0x89bc <generic_rawtp_filter_arg+0x2a9c>
    855b:      	movl	$0x1402, %r8d           # imm = 0x1402
    8561:      	btl	%ecx, %r8d
    8565:      	jae	0x89bc <generic_rawtp_filter_arg+0x2a9c>
    856b:      	cmpl	%eax, %edi
    856d:      	movq	0x10(%rsp), %rdi
    8572:      	jg	0x89cd <generic_rawtp_filter_arg+0x2aad>
    8578:      	cmpl	%esi, %eax
    857a:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8580:      	jmp	0x89cd <generic_rawtp_filter_arg+0x2aad>
    8585:      	movl	$0x1, %ebx
    858a:      	movq	0x78(%rsp), %r13
    858f:      	movq	0x10(%rsp), %rdi
    8594:      	movl	0x4(%r12), %eax
    8599:      	cmpq	$0x25, %rax
    859d:      	jbe	0x8ef6 <generic_rawtp_filter_arg+0x2fd6>
    85a3:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    85a8:      	movl	$0x1, %ebx
    85ad:      	movq	0x78(%rsp), %r13
    85b2:      	movq	0x10(%rsp), %rdi
    85b7:      	movq	0x18(%rsp), %r9
    85bc:      	movl	0x4(%r12), %eax
    85c1:      	cmpq	$0x25, %rax
    85c5:      	jbe	0x8ef6 <generic_rawtp_filter_arg+0x2fd6>
    85cb:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    85d0:      	cmpq	%rdx, %r8
    85d3:      	setbe	%r8b
    85d7:      	cmpq	%rdi, %rdx
    85da:      	setbe	%dil
    85de:      	andb	%r8b, %dil
    85e1:      	orb	%dil, %al
    85e4:      	cmpl	$0x39, %esi
    85e7:      	jb	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    85ed:      	movq	0x40(%r12), %rdi
    85f2:      	movq	0x48(%r12), %rsi
    85f7:      	cmpl	$0xc, %ecx
    85fa:      	je	0x8605 <generic_rawtp_filter_arg+0x26e5>
    85fc:      	cmpl	$0xa, %ecx
    85ff:      	jne	0x8ae5 <generic_rawtp_filter_arg+0x2bc5>
    8605:      	cmpq	%rdx, %rdi
    8608:      	setle	%cl
    860b:      	cmpq	%rsi, %rdx
    860e:      	jmp	0x89b4 <generic_rawtp_filter_arg+0x2a94>
    8613:      	xorl	%ebx, %ebx
    8615:      	jmp	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    861a:      	movq	0x28(%rsp), %rax
    861f:      	movw	%bp, (%rax)
    8622:      	leaq	0x2(%rax), %rdi
    8626:      	movl	$0x4, %eax
    862b:      	movq	0x8(%rsp), %rdx
    8630:      	movl	%ebp, %esi
    8632:      	callq	*%rax
    8634:      	movq	0x98(%rsp), %rsi
    863c:      	subl	%ebp, %esi
    863e:      	jbe	0x8662 <generic_rawtp_filter_arg+0x2742>
    8640:      	movq	0x28(%rsp), %rax
    8645:      	leaq	(%rax,%rbp), %rdi
    8649:      	addq	$0x2, %rdi
    864d:      	andl	$0xfff, %esi            # imm = 0xFFF
    8653:      	movl	$0x4, %eax
    8658:      	movq	0xa8(%rsp), %rdx
    8660:      	callq	*%rax
    8662:      	movl	0xa0(%rsp), %eax
    8669:      	movl	%eax, 0x40(%rsp)
    866d:      	cmpl	$0x3, %ebx
    8670:      	jg	0x86ac <generic_rawtp_filter_arg+0x278c>
    8672:      	cmpl	$0x1, %ebx
    8675:      	movq	0x18(%rsp), %r9
    867a:      	movq	0x20(%rsp), %r11
    867f:      	jg	0x8af3 <generic_rawtp_filter_arg+0x2bd3>
    8685:      	testl	%ebx, %ebx
    8687:      	je	0x8e6c <generic_rawtp_filter_arg+0x2f4c>
    868d:      	cmpl	$0x1, %ebx
    8690:      	jne	0x8f0f <generic_rawtp_filter_arg+0x2fef>
    8696:      	movl	$0x1, %eax
    869b:      	leaq	0x40(%rsp), %rsi
    86a0:      	movq	(%rip), %rdi            # 0x86a7 <generic_rawtp_filter_arg+0x2787>
    86a7:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    86ac:      	cmpl	$0x5, %ebx
    86af:      	movq	0x18(%rsp), %r9
    86b4:      	movq	0x20(%rsp), %r11
    86b9:      	jg	0x8b1b <generic_rawtp_filter_arg+0x2bfb>
    86bf:      	cmpl	$0x4, %ebx
    86c2:      	je	0x8e7f <generic_rawtp_filter_arg+0x2f5f>
    86c8:      	cmpl	$0x5, %ebx
    86cb:      	jne	0x8f0f <generic_rawtp_filter_arg+0x2fef>
    86d1:      	movl	$0x1, %eax
    86d6:      	leaq	0x40(%rsp), %rsi
    86db:      	movq	(%rip), %rdi            # 0x86e2 <generic_rawtp_filter_arg+0x27c2>
    86e2:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    86e7:      	cmpq	%rax, %rdi
    86ea:      	movq	0x10(%rsp), %rdi
    86ef:      	ja	0x86fa <generic_rawtp_filter_arg+0x27da>
    86f1:      	cmpq	%rsi, %rax
    86f4:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    86fa:      	cmpl	$0x39, %edx
    86fd:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    8703:      	movq	0x40(%r12), %rsi
    8708:      	movq	0x48(%r12), %rdx
    870d:      	cmpl	$0xc, %ecx
    8710:      	je	0x871b <generic_rawtp_filter_arg+0x27fb>
    8712:      	cmpl	$0xa, %ecx
    8715:      	jne	0x8b43 <generic_rawtp_filter_arg+0x2c23>
    871b:      	cmpq	%rax, %rsi
    871e:      	jg	0x602d <generic_rawtp_filter_arg+0x10d>
    8724:      	cmpq	%rdx, %rax
    8727:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    872d:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    8732:      	movq	0x8(%rsp), %r8
    8737:      	cmpq	%rsi, (%r8)
    873a:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8740:      	jmp	0x8750 <generic_rawtp_filter_arg+0x2830>
    8742:      	movq	0x8(%rsp), %r8
    8747:      	cmpq	%rsi, (%r8)
    874a:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8750:      	cmpl	$0x19, %edx
    8753:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    8759:      	movq	0x20(%r12), %rsi
    875e:      	cmpl	$0x2, %eax
    8761:      	jle	0x8783 <generic_rawtp_filter_arg+0x2863>
    8763:      	leal	-0x3(%rax), %edi
    8766:      	cmpl	$0x2, %edi
    8769:      	jae	0x87b6 <generic_rawtp_filter_arg+0x2896>
    876b:      	movq	0x8(%rsp), %rdi
    8770:      	cmpq	%rsi, (%rdi)
    8773:      	movq	0x10(%rsp), %rdi
    8778:      	jne	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    877e:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    8783:      	cmpl	$0x1, %eax
    8786:      	je	0x8828 <generic_rawtp_filter_arg+0x2908>
    878c:      	cmpl	$0x2, %eax
    878f:      	jne	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    8795:      	cmpl	$0xc, %ecx
    8798:      	je	0x87a3 <generic_rawtp_filter_arg+0x2883>
    879a:      	cmpl	$0xa, %ecx
    879d:      	jne	0x8d66 <generic_rawtp_filter_arg+0x2e46>
    87a3:      	movq	0x8(%rsp), %r8
    87a8:      	cmpq	%rsi, (%r8)
    87ab:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    87b1:      	jmp	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    87b6:      	cmpl	$0xc, %eax
    87b9:      	movq	0x10(%rsp), %rdi
    87be:      	jne	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    87c4:      	movq	0x8(%rsp), %r8
    87c9:      	testq	%rsi, (%r8)
    87cc:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    87d2:      	jmp	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    87d7:      	cmpl	$0xc, %eax
    87da:      	jne	0x88e2 <generic_rawtp_filter_arg+0x29c2>
    87e0:      	movq	0x8(%rsp), %rsi
    87e5:      	movzbl	(%rsi), %esi
    87e8:      	testl	%esi, %edx
    87ea:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    87f0:      	jmp	0x88e2 <generic_rawtp_filter_arg+0x29c2>
    87f5:      	cmpl	$0xc, %eax
    87f8:      	jne	0x892a <generic_rawtp_filter_arg+0x2a0a>
    87fe:      	movq	0x8(%rsp), %rsi
    8803:      	movzwl	(%rsi), %esi
    8806:      	testl	%esi, %edx
    8808:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    880e:      	jmp	0x892a <generic_rawtp_filter_arg+0x2a0a>
    8813:      	movq	0x10(%rsp), %rdi
    8818:      	movq	0x18(%rsp), %r9
    881d:      	movq	%rbp, %r11
    8820:      	movzbl	%cl, %ebx
    8823:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8828:      	cmpl	$0xc, %ecx
    882b:      	je	0x8836 <generic_rawtp_filter_arg+0x2916>
    882d:      	cmpl	$0xa, %ecx
    8830:      	jne	0x8d56 <generic_rawtp_filter_arg+0x2e36>
    8836:      	movq	0x8(%rsp), %r8
    883b:      	cmpq	%rsi, (%r8)
    883e:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8844:      	jmp	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    8849:      	xorl	%ebx, %ebx
    884b:      	movq	0x18(%rsp), %r9
    8850:      	movq	%r15, %r11
    8853:      	movq	0x68(%rsp), %r15
    8858:      	movq	0x10(%rsp), %rdi
    885d:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    8862:      	cmpl	$0x2, %ebx
    8865:      	je	0x8cb5 <generic_rawtp_filter_arg+0x2d95>
    886b:      	cmpl	$0x3, %ebx
    886e:      	jne	0x6863 <generic_rawtp_filter_arg+0x943>
    8874:      	movl	$0x1, %eax
    8879:      	leaq	0x40(%rsp), %rsi
    887e:      	movq	(%rip), %rdi            # 0x8885 <generic_rawtp_filter_arg+0x2965>
    8885:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    888a:      	cmpl	$0x6, %ebx
    888d:      	je	0x8cc8 <generic_rawtp_filter_arg+0x2da8>
    8893:      	cmpl	$0x7, %ebx
    8896:      	jne	0x6863 <generic_rawtp_filter_arg+0x943>
    889c:      	movl	$0x1, %eax
    88a1:      	leaq	0x40(%rsp), %rsi
    88a6:      	movq	(%rip), %rdi            # 0x88ad <generic_rawtp_filter_arg+0x298d>
    88ad:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    88b2:      	xorl	%ebx, %ebx
    88b4:      	jmp	0x88bb <generic_rawtp_filter_arg+0x299b>
    88b6:      	movl	$0x1, %ebx
    88bb:      	movq	0x10(%rsp), %rdi
    88c0:      	movq	0x18(%rsp), %r9
    88c5:      	movq	%r15, %r11
    88c8:      	movq	0x68(%rsp), %r15
    88cd:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    88d2:      	movq	0x8(%rsp), %rsi
    88d7:      	movzbl	(%rsi), %esi
    88da:      	cmpl	%esi, %edx
    88dc:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    88e2:      	cmpl	$0x11, %ecx
    88e5:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    88eb:      	movl	0x18(%r12), %edx
    88f0:      	cmpl	$0x2, %eax
    88f3:      	jle	0x8b6c <generic_rawtp_filter_arg+0x2c4c>
    88f9:      	leal	-0x3(%rax), %esi
    88fc:      	cmpl	$0x2, %esi
    88ff:      	jae	0x8dfa <generic_rawtp_filter_arg+0x2eda>
    8905:      	movq	0x8(%rsp), %rsi
    890a:      	movzbl	(%rsi), %esi
    890d:      	cmpl	%esi, %edx
    890f:      	jne	0x8f7c <generic_rawtp_filter_arg+0x305c>
    8915:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    891a:      	movq	0x8(%rsp), %rsi
    891f:      	movzwl	(%rsi), %esi
    8922:      	cmpl	%esi, %edx
    8924:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    892a:      	cmpl	$0x11, %ecx
    892d:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    8933:      	movl	0x18(%r12), %edx
    8938:      	cmpl	$0x2, %eax
    893b:      	jle	0x8b93 <generic_rawtp_filter_arg+0x2c73>
    8941:      	leal	-0x3(%rax), %esi
    8944:      	cmpl	$0x2, %esi
    8947:      	jae	0x8e18 <generic_rawtp_filter_arg+0x2ef8>
    894d:      	movq	0x8(%rsp), %rsi
    8952:      	movzwl	(%rsi), %esi
    8955:      	cmpl	%esi, %edx
    8957:      	jne	0x8fcb <generic_rawtp_filter_arg+0x30ab>
    895d:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    8962:      	xorl	%ebx, %ebx
    8964:      	movq	0x68(%rsp), %r15
    8969:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    896e:      	cmpl	%edx, %r8d
    8971:      	setbe	%r8b
    8975:      	cmpl	%edi, %edx
    8977:      	setbe	%dil
    897b:      	andb	%r8b, %dil
    897e:      	orb	%dil, %al
    8981:      	cmpl	$0x21, %esi
    8984:      	jb	0x8d44 <generic_rawtp_filter_arg+0x2e24>
    898a:      	movl	0x28(%r12), %edi
    898f:      	movl	0x2c(%r12), %esi
    8994:      	cmpl	$0xc, %ecx
    8997:      	ja	0x8d36 <generic_rawtp_filter_arg+0x2e16>
    899d:      	movl	$0x1402, %r8d           # imm = 0x1402
    89a3:      	btl	%ecx, %r8d
    89a7:      	jae	0x8d36 <generic_rawtp_filter_arg+0x2e16>
    89ad:      	cmpl	%edx, %edi
    89af:      	setle	%cl
    89b2:      	cmpl	%esi, %edx
    89b4:      	setle	%dl
    89b7:      	jmp	0x8d40 <generic_rawtp_filter_arg+0x2e20>
    89bc:      	cmpl	%eax, %edi
    89be:      	movq	0x10(%rsp), %rdi
    89c3:      	ja	0x89cd <generic_rawtp_filter_arg+0x2aad>
    89c5:      	cmpl	%esi, %eax
    89c7:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    89cd:      	cmpl	$0x21, %edx
    89d0:      	jb	0x602d <generic_rawtp_filter_arg+0x10d>
    89d6:      	movl	0x28(%r12), %esi
    89db:      	movl	0x2c(%r12), %edx
    89e0:      	cmpl	$0xc, %ecx
    89e3:      	ja	0x8e36 <generic_rawtp_filter_arg+0x2f16>
    89e9:      	movl	$0x1402, %r8d           # imm = 0x1402
    89ef:      	btl	%ecx, %r8d
    89f3:      	jae	0x8e36 <generic_rawtp_filter_arg+0x2f16>
    89f9:      	cmpl	%eax, %esi
    89fb:      	jg	0x602d <generic_rawtp_filter_arg+0x10d>
    8a01:      	cmpl	%edx, %eax
    8a03:      	jle	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8a09:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    8a0e:      	movq	0x8(%rsp), %r8
    8a13:      	cmpl	%esi, (%r8)
    8a16:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8a1c:      	jmp	0x8a2c <generic_rawtp_filter_arg+0x2b0c>
    8a1e:      	movq	0x8(%rsp), %r8
    8a23:      	cmpl	%esi, (%r8)
    8a26:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8a2c:      	cmpl	$0x11, %edx
    8a2f:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    8a35:      	movl	0x18(%r12), %esi
    8a3a:      	cmpl	$0x2, %eax
    8a3d:      	jle	0x8a5e <generic_rawtp_filter_arg+0x2b3e>
    8a3f:      	leal	-0x3(%rax), %edi
    8a42:      	cmpl	$0x2, %edi
    8a45:      	jae	0x8a98 <generic_rawtp_filter_arg+0x2b78>
    8a47:      	movq	0x8(%rsp), %rdi
    8a4c:      	cmpl	%esi, (%rdi)
    8a4e:      	movq	0x10(%rsp), %rdi
    8a53:      	jne	0x9033 <generic_rawtp_filter_arg+0x3113>
    8a59:      	jmp	0x9141 <generic_rawtp_filter_arg+0x3221>
    8a5e:      	cmpl	$0x1, %eax
    8a61:      	je	0x8ab9 <generic_rawtp_filter_arg+0x2b99>
    8a63:      	cmpl	$0x2, %eax
    8a66:      	jne	0x9033 <generic_rawtp_filter_arg+0x3113>
    8a6c:      	cmpl	$0xc, %ecx
    8a6f:      	ja	0x9025 <generic_rawtp_filter_arg+0x3105>
    8a75:      	movl	$0x1402, %r8d           # imm = 0x1402
    8a7b:      	btl	%ecx, %r8d
    8a7f:      	jae	0x9025 <generic_rawtp_filter_arg+0x3105>
    8a85:      	movq	0x8(%rsp), %r8
    8a8a:      	cmpl	%esi, (%r8)
    8a8d:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8a93:      	jmp	0x9033 <generic_rawtp_filter_arg+0x3113>
    8a98:      	cmpl	$0xc, %eax
    8a9b:      	movq	0x10(%rsp), %rdi
    8aa0:      	jne	0x9033 <generic_rawtp_filter_arg+0x3113>
    8aa6:      	movq	0x8(%rsp), %r8
    8aab:      	testl	%esi, (%r8)
    8aae:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8ab4:      	jmp	0x9033 <generic_rawtp_filter_arg+0x3113>
    8ab9:      	cmpl	$0xc, %ecx
    8abc:      	ja	0x9015 <generic_rawtp_filter_arg+0x30f5>
    8ac2:      	movl	$0x1402, %r8d           # imm = 0x1402
    8ac8:      	btl	%ecx, %r8d
    8acc:      	jae	0x9015 <generic_rawtp_filter_arg+0x30f5>
    8ad2:      	movq	0x8(%rsp), %r8
    8ad7:      	cmpl	%esi, (%r8)
    8ada:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8ae0:      	jmp	0x9033 <generic_rawtp_filter_arg+0x3113>
    8ae5:      	cmpq	%rdx, %rdi
    8ae8:      	setbe	%cl
    8aeb:      	cmpq	%rsi, %rdx
    8aee:      	jmp	0x8d3d <generic_rawtp_filter_arg+0x2e1d>
    8af3:      	cmpl	$0x2, %ebx
    8af6:      	je	0x8e92 <generic_rawtp_filter_arg+0x2f72>
    8afc:      	cmpl	$0x3, %ebx
    8aff:      	jne	0x8f0f <generic_rawtp_filter_arg+0x2fef>
    8b05:      	movl	$0x1, %eax
    8b0a:      	leaq	0x40(%rsp), %rsi
    8b0f:      	movq	(%rip), %rdi            # 0x8b16 <generic_rawtp_filter_arg+0x2bf6>
    8b16:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    8b1b:      	cmpl	$0x6, %ebx
    8b1e:      	je	0x8ea5 <generic_rawtp_filter_arg+0x2f85>
    8b24:      	cmpl	$0x7, %ebx
    8b27:      	jne	0x8f0f <generic_rawtp_filter_arg+0x2fef>
    8b2d:      	movl	$0x1, %eax
    8b32:      	leaq	0x40(%rsp), %rsi
    8b37:      	movq	(%rip), %rdi            # 0x8b3e <generic_rawtp_filter_arg+0x2c1e>
    8b3e:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    8b43:      	cmpq	%rax, %rsi
    8b46:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    8b4c:      	cmpq	%rdx, %rax
    8b4f:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8b55:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    8b5a:      	movq	0x10(%rsp), %rdi
    8b5f:      	movq	0x18(%rsp), %r9
    8b64:      	movq	%r13, %r11
    8b67:      	jmp	0x61cf <generic_rawtp_filter_arg+0x2af>
    8b6c:      	cmpl	$0x1, %eax
    8b6f:      	je	0x8f6c <generic_rawtp_filter_arg+0x304c>
    8b75:      	cmpl	$0x2, %eax
    8b78:      	jne	0x8f7c <generic_rawtp_filter_arg+0x305c>
    8b7e:      	movq	0x8(%rsp), %rsi
    8b83:      	movzbl	(%rsi), %esi
    8b86:      	cmpl	%esi, %edx
    8b88:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8b8e:      	jmp	0x8f7c <generic_rawtp_filter_arg+0x305c>
    8b93:      	cmpl	$0x1, %eax
    8b96:      	je	0x8fbb <generic_rawtp_filter_arg+0x309b>
    8b9c:      	cmpl	$0x2, %eax
    8b9f:      	jne	0x8fcb <generic_rawtp_filter_arg+0x30ab>
    8ba5:      	movq	0x8(%rsp), %rsi
    8baa:      	movzwl	(%rsi), %esi
    8bad:      	cmpl	%esi, %edx
    8baf:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8bb5:      	jmp	0x8fcb <generic_rawtp_filter_arg+0x30ab>
    8bba:      	movl	$0x1, %ebx
    8bbf:      	movq	0x10(%rsp), %rdi
    8bc4:      	jmp	0x91b5 <generic_rawtp_filter_arg+0x3295>
    8bc9:      	movq	0x10(%rsp), %rdi
    8bce:      	movq	0x18(%rsp), %r9
    8bd3:      	movq	%rbp, %r11
    8bd6:      	jmp	0x61cf <generic_rawtp_filter_arg+0x2af>
    8bdb:      	movq	0x28(%rsp), %rax
    8be0:      	movw	%bp, (%rax)
    8be3:      	leaq	0x2(%rax), %rdi
    8be7:      	movl	$0x4, %eax
    8bec:      	movq	0x8(%rsp), %rdx
    8bf1:      	movl	%ebp, %esi
    8bf3:      	callq	*%rax
    8bf5:      	movq	0xa0(%rsp), %rsi
    8bfd:      	subl	%ebp, %esi
    8bff:      	jbe	0x8c1e <generic_rawtp_filter_arg+0x2cfe>
    8c01:      	movq	0x28(%rsp), %rax
    8c06:      	leaq	(%rax,%rbp), %rdi
    8c0a:      	addq	$0x2, %rdi
    8c0e:      	andl	$0xfff, %esi            # imm = 0xFFF
    8c14:      	movl	$0x4, %eax
    8c19:      	movq	%r13, %rdx
    8c1c:      	callq	*%rax
    8c1e:      	movl	0x98(%rsp), %eax
    8c25:      	movl	%eax, 0x40(%rsp)
    8c29:      	cmpl	$0x3, %ebx
    8c2c:      	jg	0x8c5e <generic_rawtp_filter_arg+0x2d3e>
    8c2e:      	cmpl	$0x1, %ebx
    8c31:      	leaq	0x40(%rsp), %rsi
    8c36:      	jg	0x8f26 <generic_rawtp_filter_arg+0x3006>
    8c3c:      	testl	%ebx, %ebx
    8c3e:      	je	0x914e <generic_rawtp_filter_arg+0x322e>
    8c44:      	cmpl	$0x1, %ebx
    8c47:      	jne	0x91a4 <generic_rawtp_filter_arg+0x3284>
    8c4d:      	movl	$0x1, %eax
    8c52:      	movq	(%rip), %rdi            # 0x8c59 <generic_rawtp_filter_arg+0x2d39>
    8c59:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    8c5e:      	cmpl	$0x5, %ebx
    8c61:      	leaq	0x40(%rsp), %rsi
    8c66:      	jg	0x8f49 <generic_rawtp_filter_arg+0x3029>
    8c6c:      	cmpl	$0x4, %ebx
    8c6f:      	je	0x915c <generic_rawtp_filter_arg+0x323c>
    8c75:      	cmpl	$0x5, %ebx
    8c78:      	jne	0x91a4 <generic_rawtp_filter_arg+0x3284>
    8c7e:      	movl	$0x1, %eax
    8c83:      	movq	(%rip), %rdi            # 0x8c8a <generic_rawtp_filter_arg+0x2d6a>
    8c8a:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    8c8f:      	movl	$0x1, %eax
    8c94:      	movq	(%rip), %rdi            # 0x8c9b <generic_rawtp_filter_arg+0x2d7b>
    8c9b:      	leaq	0x40(%rsp), %rsi
    8ca0:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    8ca2:      	movl	$0x1, %eax
    8ca7:      	leaq	0x40(%rsp), %rsi
    8cac:      	movq	(%rip), %rdi            # 0x8cb3 <generic_rawtp_filter_arg+0x2d93>
    8cb3:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    8cb5:      	movl	$0x1, %eax
    8cba:      	leaq	0x40(%rsp), %rsi
    8cbf:      	movq	(%rip), %rdi            # 0x8cc6 <generic_rawtp_filter_arg+0x2da6>
    8cc6:      	jmp	0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    8cc8:      	movl	$0x1, %eax
    8ccd:      	leaq	0x40(%rsp), %rsi
    8cd2:      	movq	(%rip), %rdi            # 0x8cd9 <generic_rawtp_filter_arg+0x2db9>
    8cd9:      	callq	*%rax
    8cdb:      	testq	%rax, %rax
    8cde:      	je	0x8cf9 <generic_rawtp_filter_arg+0x2dd9>
    8ce0:      	movq	%rax, %rdi
    8ce3:      	movl	$0x1, %eax
    8ce8:      	movq	0x28(%rsp), %rsi
    8ced:      	callq	*%rax
    8cef:      	xorl	%ebx, %ebx
    8cf1:      	testq	%rax, %rax
    8cf4:      	setne	%bl
    8cf7:      	jmp	0x8cfb <generic_rawtp_filter_arg+0x2ddb>
    8cf9:      	xorl	%ebx, %ebx
    8cfb:      	movq	0x10(%rsp), %rdi
    8d00:      	movq	0x18(%rsp), %r9
    8d05:      	movq	0x20(%rsp), %r11
    8d0a:      	movl	0x4(%r12), %eax
    8d0f:      	cmpq	$0x25, %rax
    8d13:      	ja	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8d19:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    8d23:      	btq	%rax, %rcx
    8d27:      	jae	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8d2d:      	xorq	$0x1, %rbx
    8d31:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8d36:      	cmpl	%edx, %edi
    8d38:      	setbe	%cl
    8d3b:      	cmpl	%esi, %edx
    8d3d:      	setbe	%dl
    8d40:      	andb	%cl, %dl
    8d42:      	orb	%dl, %al
    8d44:      	movq	0x10(%rsp), %rdi
    8d49:      	testb	%al, %al
    8d4b:      	je	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8d51:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    8d56:      	movq	0x8(%rsp), %r8
    8d5b:      	cmpq	%rsi, (%r8)
    8d5e:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8d64:      	jmp	0x8d74 <generic_rawtp_filter_arg+0x2e54>
    8d66:      	movq	0x8(%rsp), %r8
    8d6b:      	cmpq	%rsi, (%r8)
    8d6e:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8d74:      	cmpl	$0x21, %edx
    8d77:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    8d7d:      	movq	0x28(%r12), %rdx
    8d82:      	cmpl	$0x2, %eax
    8d85:      	jle	0x8db4 <generic_rawtp_filter_arg+0x2e94>
    8d87:      	leal	-0x3(%rax), %ecx
    8d8a:      	cmpl	$0x2, %ecx
    8d8d:      	jb	0x8de7 <generic_rawtp_filter_arg+0x2ec7>
    8d8f:      	cmpl	$0x6, %eax
    8d92:      	je	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8d98:      	cmpl	$0xc, %eax
    8d9b:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    8da1:      	movq	0x8(%rsp), %rcx
    8da6:      	testq	%rdx, (%rcx)
    8da9:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8daf:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    8db4:      	cmpl	$0x1, %eax
    8db7:      	je	0x8e4b <generic_rawtp_filter_arg+0x2f2b>
    8dbd:      	cmpl	$0x2, %eax
    8dc0:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    8dc6:      	cmpl	$0xc, %ecx
    8dc9:      	je	0x8dd4 <generic_rawtp_filter_arg+0x2eb4>
    8dcb:      	cmpl	$0xa, %ecx
    8dce:      	jne	0x91ed <generic_rawtp_filter_arg+0x32cd>
    8dd4:      	movq	0x8(%rsp), %rcx
    8dd9:      	cmpq	%rdx, (%rcx)
    8ddc:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8de2:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    8de7:      	movq	0x8(%rsp), %rcx
    8dec:      	cmpq	%rdx, (%rcx)
    8def:      	je	0x9141 <generic_rawtp_filter_arg+0x3221>
    8df5:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    8dfa:      	cmpl	$0xc, %eax
    8dfd:      	jne	0x8f7c <generic_rawtp_filter_arg+0x305c>
    8e03:      	movq	0x8(%rsp), %rsi
    8e08:      	movzbl	(%rsi), %esi
    8e0b:      	testl	%esi, %edx
    8e0d:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8e13:      	jmp	0x8f7c <generic_rawtp_filter_arg+0x305c>
    8e18:      	cmpl	$0xc, %eax
    8e1b:      	jne	0x8fcb <generic_rawtp_filter_arg+0x30ab>
    8e21:      	movq	0x8(%rsp), %rsi
    8e26:      	movzwl	(%rsi), %esi
    8e29:      	testl	%esi, %edx
    8e2b:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8e31:      	jmp	0x8fcb <generic_rawtp_filter_arg+0x30ab>
    8e36:      	cmpl	%eax, %esi
    8e38:      	ja	0x602d <generic_rawtp_filter_arg+0x10d>
    8e3e:      	cmpl	%edx, %eax
    8e40:      	jbe	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8e46:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    8e4b:      	cmpl	$0xc, %ecx
    8e4e:      	movq	0x8(%rsp), %rsi
    8e53:      	je	0x8e5e <generic_rawtp_filter_arg+0x2f3e>
    8e55:      	cmpl	$0xa, %ecx
    8e58:      	jne	0x91fd <generic_rawtp_filter_arg+0x32dd>
    8e5e:      	cmpq	%rdx, (%rsi)
    8e61:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8e67:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    8e6c:      	movl	$0x1, %eax
    8e71:      	movq	(%rip), %rdi            # 0x8e78 <generic_rawtp_filter_arg+0x2f58>
    8e78:      	leaq	0x40(%rsp), %rsi
    8e7d:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    8e7f:      	movl	$0x1, %eax
    8e84:      	leaq	0x40(%rsp), %rsi
    8e89:      	movq	(%rip), %rdi            # 0x8e90 <generic_rawtp_filter_arg+0x2f70>
    8e90:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    8e92:      	movl	$0x1, %eax
    8e97:      	leaq	0x40(%rsp), %rsi
    8e9c:      	movq	(%rip), %rdi            # 0x8ea3 <generic_rawtp_filter_arg+0x2f83>
    8ea3:      	jmp	0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    8ea5:      	movl	$0x1, %eax
    8eaa:      	leaq	0x40(%rsp), %rsi
    8eaf:      	movq	(%rip), %rdi            # 0x8eb6 <generic_rawtp_filter_arg+0x2f96>
    8eb6:      	callq	*%rax
    8eb8:      	testq	%rax, %rax
    8ebb:      	je	0x8ed6 <generic_rawtp_filter_arg+0x2fb6>
    8ebd:      	movq	%rax, %rdi
    8ec0:      	movl	$0x1, %eax
    8ec5:      	movq	0x28(%rsp), %rsi
    8eca:      	callq	*%rax
    8ecc:      	xorl	%ebx, %ebx
    8ece:      	testq	%rax, %rax
    8ed1:      	setne	%bl
    8ed4:      	jmp	0x8ed8 <generic_rawtp_filter_arg+0x2fb8>
    8ed6:      	xorl	%ebx, %ebx
    8ed8:      	movq	0x10(%rsp), %rdi
    8edd:      	movq	0x18(%rsp), %r9
    8ee2:      	movq	0x20(%rsp), %r11
    8ee7:      	movl	0x4(%r12), %eax
    8eec:      	cmpq	$0x25, %rax
    8ef0:      	ja	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8ef6:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    8f00:      	btq	%rax, %rcx
    8f04:      	jb	0x91dd <generic_rawtp_filter_arg+0x32bd>
    8f0a:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8f0f:      	xorl	%ebx, %ebx
    8f11:      	movq	0x10(%rsp), %rdi
    8f16:      	movl	0x4(%r12), %eax
    8f1b:      	cmpq	$0x25, %rax
    8f1f:      	jbe	0x8ef6 <generic_rawtp_filter_arg+0x2fd6>
    8f21:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    8f26:      	cmpl	$0x2, %ebx
    8f29:      	je	0x916a <generic_rawtp_filter_arg+0x324a>
    8f2f:      	cmpl	$0x3, %ebx
    8f32:      	jne	0x91a4 <generic_rawtp_filter_arg+0x3284>
    8f38:      	movl	$0x1, %eax
    8f3d:      	movq	(%rip), %rdi            # 0x8f44 <generic_rawtp_filter_arg+0x3024>
    8f44:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    8f49:      	cmpl	$0x6, %ebx
    8f4c:      	je	0x9178 <generic_rawtp_filter_arg+0x3258>
    8f52:      	cmpl	$0x7, %ebx
    8f55:      	jne	0x91a4 <generic_rawtp_filter_arg+0x3284>
    8f5b:      	movl	$0x1, %eax
    8f60:      	movq	(%rip), %rdi            # 0x8f67 <generic_rawtp_filter_arg+0x3047>
    8f67:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    8f6c:      	movq	0x8(%rsp), %rsi
    8f71:      	movzbl	(%rsi), %esi
    8f74:      	cmpl	%esi, %edx
    8f76:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8f7c:      	cmpl	$0x15, %ecx
    8f7f:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    8f85:      	movl	0x1c(%r12), %ecx
    8f8a:      	cmpl	$0x2, %eax
    8f8d:      	jle	0x90e4 <generic_rawtp_filter_arg+0x31c4>
    8f93:      	leal	-0x3(%rax), %edx
    8f96:      	cmpl	$0x2, %edx
    8f99:      	jb	0x9127 <generic_rawtp_filter_arg+0x3207>
    8f9f:      	cmpl	$0x6, %eax
    8fa2:      	je	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8fa8:      	cmpl	$0xc, %eax
    8fab:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    8fb1:      	movq	0x8(%rsp), %rdx
    8fb6:      	movzbl	(%rdx), %edx
    8fb9:      	jmp	0x9008 <generic_rawtp_filter_arg+0x30e8>
    8fbb:      	movq	0x8(%rsp), %rsi
    8fc0:      	movzwl	(%rsi), %esi
    8fc3:      	cmpl	%esi, %edx
    8fc5:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8fcb:      	cmpl	$0x15, %ecx
    8fce:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    8fd4:      	movl	0x1c(%r12), %ecx
    8fd9:      	cmpl	$0x2, %eax
    8fdc:      	jle	0x9100 <generic_rawtp_filter_arg+0x31e0>
    8fe2:      	leal	-0x3(%rax), %edx
    8fe5:      	cmpl	$0x2, %edx
    8fe8:      	jb	0x9131 <generic_rawtp_filter_arg+0x3211>
    8fee:      	cmpl	$0x6, %eax
    8ff1:      	je	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    8ff7:      	cmpl	$0xc, %eax
    8ffa:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    9000:      	movq	0x8(%rsp), %rdx
    9005:      	movzwl	(%rdx), %edx
    9008:      	testl	%edx, %ecx
    900a:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9010:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    9015:      	movq	0x8(%rsp), %r8
    901a:      	cmpl	%esi, (%r8)
    901d:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9023:      	jmp	0x9033 <generic_rawtp_filter_arg+0x3113>
    9025:      	movq	0x8(%rsp), %r8
    902a:      	cmpl	%esi, (%r8)
    902d:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9033:      	cmpl	$0x15, %edx
    9036:      	jb	0x926a <generic_rawtp_filter_arg+0x334a>
    903c:      	movl	0x1c(%r12), %edx
    9041:      	cmpl	$0x2, %eax
    9044:      	jle	0x9072 <generic_rawtp_filter_arg+0x3152>
    9046:      	leal	-0x3(%rax), %ecx
    9049:      	cmpl	$0x2, %ecx
    904c:      	jb	0x90a9 <generic_rawtp_filter_arg+0x3189>
    904e:      	cmpl	$0x6, %eax
    9051:      	je	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9057:      	cmpl	$0xc, %eax
    905a:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    9060:      	movq	0x8(%rsp), %rcx
    9065:      	testl	%edx, (%rcx)
    9067:      	jne	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    906d:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    9072:      	cmpl	$0x1, %eax
    9075:      	je	0x90bb <generic_rawtp_filter_arg+0x319b>
    9077:      	cmpl	$0x2, %eax
    907a:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    9080:      	cmpl	$0xc, %ecx
    9083:      	ja	0x924e <generic_rawtp_filter_arg+0x332e>
    9089:      	movl	$0x1402, %esi           # imm = 0x1402
    908e:      	btl	%ecx, %esi
    9091:      	jae	0x924e <generic_rawtp_filter_arg+0x332e>
    9097:      	movq	0x8(%rsp), %rcx
    909c:      	cmpl	%edx, (%rcx)
    909e:      	jl	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    90a4:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    90a9:      	movq	0x8(%rsp), %rcx
    90ae:      	cmpl	%edx, (%rcx)
    90b0:      	je	0x9141 <generic_rawtp_filter_arg+0x3221>
    90b6:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    90bb:      	cmpl	$0xc, %ecx
    90be:      	ja	0x925d <generic_rawtp_filter_arg+0x333d>
    90c4:      	movl	$0x1402, %esi           # imm = 0x1402
    90c9:      	btl	%ecx, %esi
    90cc:      	jae	0x925d <generic_rawtp_filter_arg+0x333d>
    90d2:      	movq	0x8(%rsp), %rcx
    90d7:      	cmpl	%edx, (%rcx)
    90d9:      	jg	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    90df:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    90e4:      	cmpl	$0x1, %eax
    90e7:      	je	0x9208 <generic_rawtp_filter_arg+0x32e8>
    90ed:      	cmpl	$0x2, %eax
    90f0:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    90f6:      	movq	0x8(%rsp), %rdx
    90fb:      	movzbl	(%rdx), %edx
    90fe:      	jmp	0x911a <generic_rawtp_filter_arg+0x31fa>
    9100:      	cmpl	$0x1, %eax
    9103:      	je	0x9212 <generic_rawtp_filter_arg+0x32f2>
    9109:      	cmpl	$0x2, %eax
    910c:      	jne	0x602d <generic_rawtp_filter_arg+0x10d>
    9112:      	movq	0x8(%rsp), %rdx
    9117:      	movzwl	(%rdx), %edx
    911a:      	cmpl	%edx, %ecx
    911c:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9122:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    9127:      	movq	0x8(%rsp), %rdx
    912c:      	movzbl	(%rdx), %edx
    912f:      	jmp	0x9139 <generic_rawtp_filter_arg+0x3219>
    9131:      	movq	0x8(%rsp), %rdx
    9136:      	movzwl	(%rdx), %edx
    9139:      	cmpl	%edx, %ecx
    913b:      	jne	0x926a <generic_rawtp_filter_arg+0x334a>
    9141:      	xorl	%ebx, %ebx
    9143:      	cmpl	$0x3, %eax
    9146:      	sete	%bl
    9149:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    914e:      	movl	$0x1, %eax
    9153:      	movq	(%rip), %rdi            # 0x915a <generic_rawtp_filter_arg+0x323a>
    915a:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    915c:      	movl	$0x1, %eax
    9161:      	movq	(%rip), %rdi            # 0x9168 <generic_rawtp_filter_arg+0x3248>
    9168:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    916a:      	movl	$0x1, %eax
    916f:      	movq	(%rip), %rdi            # 0x9176 <generic_rawtp_filter_arg+0x3256>
    9176:      	jmp	0x9184 <generic_rawtp_filter_arg+0x3264>
    9178:      	movl	$0x1, %eax
    917d:      	movq	(%rip), %rdi            # 0x9184 <generic_rawtp_filter_arg+0x3264>
    9184:      	callq	*%rax
    9186:      	testq	%rax, %rax
    9189:      	je	0x91a4 <generic_rawtp_filter_arg+0x3284>
    918b:      	movq	%rax, %rdi
    918e:      	movl	$0x1, %eax
    9193:      	movq	0x28(%rsp), %rsi
    9198:      	callq	*%rax
    919a:      	xorl	%ebx, %ebx
    919c:      	testq	%rax, %rax
    919f:      	setne	%bl
    91a2:      	jmp	0x91a6 <generic_rawtp_filter_arg+0x3286>
    91a4:      	xorl	%ebx, %ebx
    91a6:      	movq	0x10(%rsp), %rdi
    91ab:      	movq	0x18(%rsp), %r9
    91b0:      	movq	0x20(%rsp), %r11
    91b5:      	movl	0x4(%r12), %eax
    91ba:      	cmpq	$0x25, %rax
    91be:      	ja	0x61d2 <generic_rawtp_filter_arg+0x2b2>
    91c4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    91ce:      	btq	%rax, %rcx
    91d2:      	movq	0x78(%rsp), %r13
    91d7:      	jae	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    91dd:      	xorl	%eax, %eax
    91df:      	testq	%rbx, %rbx
    91e2:      	sete	%al
    91e5:      	movq	%rax, %rbx
    91e8:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    91ed:      	movq	0x8(%rsp), %rcx
    91f2:      	cmpq	%rdx, (%rcx)
    91f5:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    91fb:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    91fd:      	cmpq	%rdx, (%rsi)
    9200:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9206:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    9208:      	movq	0x8(%rsp), %rdx
    920d:      	movzbl	(%rdx), %edx
    9210:      	jmp	0x921a <generic_rawtp_filter_arg+0x32fa>
    9212:      	movq	0x8(%rsp), %rdx
    9217:      	movzwl	(%rdx), %edx
    921a:      	cmpl	%edx, %ecx
    921c:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9222:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    9224:      	xorl	%ebx, %ebx
    9226:      	movq	0x10(%rsp), %rdi
    922b:      	movq	0x18(%rsp), %r9
    9230:      	movq	0x20(%rsp), %r11
    9235:      	movq	0x68(%rsp), %r15
    923a:      	movl	0x4(%r12), %eax
    923f:      	cmpq	$0x25, %rax
    9243:      	jbe	0x8d19 <generic_rawtp_filter_arg+0x2df9>
    9249:      	jmp	0x61d7 <generic_rawtp_filter_arg+0x2b7>
    924e:      	movq	0x8(%rsp), %rcx
    9253:      	cmpl	%edx, (%rcx)
    9255:      	jb	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    925b:      	jmp	0x926a <generic_rawtp_filter_arg+0x334a>
    925d:      	movq	0x8(%rsp), %rcx
    9262:      	cmpl	%edx, (%rcx)
    9264:      	ja	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    926a:      	orl	$0x2, %eax
    926d:      	cmpl	$0x6, %eax
    9270:      	je	0x61e8 <generic_rawtp_filter_arg+0x2c8>
    9276:      	jmp	0x602d <generic_rawtp_filter_arg+0x10d>
    927b:      	nopl	(%rax,%rax)

0000000000009280 <generic_rawtp_actions>:
    9280:      	pushq	%rbp
    9281:      	pushq	%r15
    9283:      	pushq	%r14
    9285:      	pushq	%r13
    9287:      	pushq	%r12
    9289:      	pushq	%rbx
    928a:      	subq	$0xa8, %rsp
    9291:      	movq	%rdi, 0x80(%rsp)
    9299:      	movl	$0x0, 0x88(%rsp)
    92a4:      	movq	(%rip), %rdi            # 0x92ab <generic_rawtp_actions+0x2b>
    92ab:      	leaq	0x88(%rsp), %rsi
    92b3:      	movl	$0x1, %eax
    92b8:      	callq	*%rax
    92ba:      	testq	%rax, %rax
    92bd:      	je	0x9da8 <generic_rawtp_actions+0xb28>
    92c3:      	movq	%rax, %rsi
    92c6:      	movl	0x5f04(%rax), %ebx
    92cc:      	cmpl	$0x2, %ebx
    92cf:      	jl	0x9da8 <generic_rawtp_actions+0xb28>
    92d5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    92dc:      	movq	(%rip), %rdi            # 0x92e3 <generic_rawtp_actions+0x63>
    92e3:      	movl	$0x1, %eax
    92e8:      	callq	*%rax
    92ea:      	testq	%rax, %rax
    92ed:      	je	0x9da8 <generic_rawtp_actions+0xb28>
    92f3:      	movq	%rax, %r14
    92f6:      	movl	%ebx, %eax
    92f8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    92fd:      	addl	(%r14,%rax), %ebx
    9301:      	movl	$0x0, 0x8c(%rsp)
    930c:      	movq	(%rip), %rdi            # 0x9313 <generic_rawtp_actions+0x93>
    9313:      	leaq	0x8c(%rsp), %rsi
    931b:      	movl	$0x1, %eax
    9320:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    9326:      	callq	*%rax
    9328:      	testq	%rax, %rax
    932b:      	je	0x9352 <generic_rawtp_actions+0xd2>
    932d:      	cmpb	$0x0, (%rax)
    9330:      	sete	0x17(%rsp)
    9335:      	je	0x936d <generic_rawtp_actions+0xed>
    9337:      	movl	$0x5, %eax
    933c:      	movq	%rax, 0x78(%rsp)
    9341:      	movl	$0x9, %eax
    9346:      	movq	%rax, 0x70(%rsp)
    934b:      	movl	$0x7, %eax
    9350:      	jmp	0x9386 <generic_rawtp_actions+0x106>
    9352:      	movl	$0x4, %eax
    9357:      	movq	%rax, 0x78(%rsp)
    935c:      	movl	$0x8, %eax
    9361:      	movq	%rax, 0x70(%rsp)
    9366:      	movb	$0x1, 0x17(%rsp)
    936b:      	jmp	0x9381 <generic_rawtp_actions+0x101>
    936d:      	movl	$0x4, %eax
    9372:      	movq	%rax, 0x78(%rsp)
    9377:      	movl	$0x8, %eax
    937c:      	movq	%rax, 0x70(%rsp)
    9381:      	movl	$0x6, %eax
    9386:      	movq	%rax, 0x68(%rsp)
    938b:      	addq	%rbx, %r14
    938e:      	movb	$0x1, %al
    9390:      	movl	%eax, 0x44(%rsp)
    9394:      	movq	(%rip), %rbp            # 0x939b <generic_rawtp_actions+0x11b>
    939b:      	xorl	%r12d, %r12d
    939e:      	xorl	%r15d, %r15d
    93a1:      	jmp	0x93ca <generic_rawtp_actions+0x14a>
    93a3:      	incl	%r15d
    93a6:      	movl	0x4(%r14,%r15,4), %eax
    93ab:      	movl	%eax, 0x78(%rdx)
    93ae:      	nop
    93b0:      	movq	%r13, 0x70(%rdx)
    93b4:      	incl	%r15d
    93b7:      	movl	%r15d, %ebx
    93ba:      	incl	%r12d
    93bd:      	movl	%ebx, %r15d
    93c0:      	cmpl	$0x3, %r12d
    93c4:      	je	0x9d81 <generic_rawtp_actions+0xb01>
    93ca:      	leal	0x4(,%r15,4), %eax
    93d2:      	cmpl	(%r14), %eax
    93d5:      	jae	0x9d81 <generic_rawtp_actions+0xb01>
    93db:      	movl	%r15d, %eax
    93de:      	movslq	0x4(%r14,%rax,4), %r13
    93e3:      	movl	$0x0, 0x90(%rsp)
    93ee:      	movl	$0x1, %eax
    93f3:      	leaq	0x90(%rsp), %rsi
    93fb:      	movq	%rbp, %rdi
    93fe:      	callq	*%rax
    9400:      	xorl	%ebx, %ebx
    9402:      	testq	%rax, %rax
    9405:      	je	0x93ba <generic_rawtp_actions+0x13a>
    9407:      	movq	%rax, %rdx
    940a:      	cmpl	$0x7, %r13d
    940e:      	jg	0x9440 <generic_rawtp_actions+0x1c0>
    9410:      	cmpl	$0x3, %r13d
    9414:      	jg	0x9496 <generic_rawtp_actions+0x216>
    941a:      	cmpl	$0x1, %r13d
    941e:      	jg	0x95e7 <generic_rawtp_actions+0x367>
    9424:      	testl	%r13d, %r13d
    9427:      	je	0x97f7 <generic_rawtp_actions+0x577>
    942d:      	cmpl	$0x1, %r13d
    9431:      	je	0x9600 <generic_rawtp_actions+0x380>
    9437:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    943c:      	nopl	(%rax)
    9440:      	cmpl	$0xb, %r13d
    9444:      	jg	0x95b0 <generic_rawtp_actions+0x330>
    944a:      	leal	-0xa(%r13), %eax
    944e:      	cmpl	$0x2, %eax
    9451:      	jb	0x968f <generic_rawtp_actions+0x40f>
    9457:      	cmpl	$0x8, %r13d
    945b:      	je	0x9751 <generic_rawtp_actions+0x4d1>
    9461:      	cmpl	$0x9, %r13d
    9465:      	jne	0x93b0 <generic_rawtp_actions+0x130>
    946b:      	movq	%r13, 0x8(%rsp)
    9470:      	movq	%r14, %rax
    9473:      	movq	%rbp, %r13
    9476:      	incl	%r15d
    9479:      	movl	0x4(%r14,%r15,4), %eax
    947e:      	movq	%rdx, %rbp
    9481:      	movl	$0x3, %ebx
    9486:      	cmpb	$0x0, 0x17(%rsp)
    948b:      	jne	0x98d3 <generic_rawtp_actions+0x653>
    9491:      	jmp	0x98f8 <generic_rawtp_actions+0x678>
    9496:      	leal	-0x6(%r13), %eax
    949a:      	cmpl	$0x2, %eax
    949d:      	jb	0x93a3 <generic_rawtp_actions+0x123>
    94a3:      	cmpl	$0x4, %r13d
    94a7:      	je	0x975e <generic_rawtp_actions+0x4de>
    94ad:      	cmpl	$0x5, %r13d
    94b1:      	jne	0x93b0 <generic_rawtp_actions+0x130>
    94b7:      	leal	0x1(%r15), %eax
    94bb:      	movl	0x4(%r14,%rax,4), %eax
    94c0:      	addl	$0x2, %r15d
    94c4:      	movl	0x4(%r14,%r15,4), %ebx
    94c9:      	movq	$0x0, 0x20(%rsp)
    94d2:      	movq	$0x0, 0x18(%rsp)
    94db:      	andl	$0x7, %eax
    94de:      	cmpl	$0x4, %eax
    94e1:      	ja	0x93b0 <generic_rawtp_actions+0x130>
    94e7:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    94ef:      	jne	0x93b0 <generic_rawtp_actions+0x130>
    94f5:      	movq	0x5e78(%rdx,%rax,8), %rax
    94fd:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9502:      	movl	0x90(%rdx,%rax), %eax
    9509:      	movl	%eax, 0x20(%rsp)
    950d:      	movl	$0xe, %eax
    9512:      	movq	%rdx, 0x8(%rsp)
    9517:      	callq	*%rax
    9519:      	shrq	$0x20, %rax
    951d:      	movq	%rax, 0x18(%rsp)
    9522:      	movl	$0x1, %eax
    9527:      	leaq	0x18(%rsp), %rsi
    952c:      	movq	(%rip), %rdi            # 0x9533 <generic_rawtp_actions+0x2b3>
    9533:      	callq	*%rax
    9535:      	movq	0x8(%rsp), %rdx
    953a:      	testq	%rax, %rax
    953d:      	je	0x93b0 <generic_rawtp_actions+0x130>
    9543:      	andl	$0x7, %ebx
    9546:      	cmpl	$0x4, %ebx
    9549:      	ja	0x93b0 <generic_rawtp_actions+0x130>
    954f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    9557:      	jne	0x93b0 <generic_rawtp_actions+0x130>
    955d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    9565:      	movl	$0x0, 0x24(%rsp)
    956d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    9573:      	movl	0x90(%rdx,%rcx), %ecx
    957a:      	movl	%ecx, 0x20(%rsp)
    957e:      	movq	%rax, %rbx
    9581:      	movl	$0xe, %eax
    9586:      	callq	*%rax
    9588:      	shrq	$0x20, %rax
    958c:      	movq	%rax, 0x18(%rsp)
    9591:      	movl	$0x2, %eax
    9596:      	xorl	%ecx, %ecx
    9598:      	leaq	0x18(%rsp), %rsi
    959d:      	movq	(%rip), %rdi            # 0x95a4 <generic_rawtp_actions+0x324>
    95a4:      	movq	%rbx, %rdx
    95a7:      	xorl	%ecx, %ecx
    95a9:      	callq	*%rax
    95ab:      	jmp	0x97ed <generic_rawtp_actions+0x56d>
    95b0:      	cmpl	$0xc, %r13d
    95b4:      	je	0x98e4 <generic_rawtp_actions+0x664>
    95ba:      	cmpl	$0xd, %r13d
    95be:      	je	0x9776 <generic_rawtp_actions+0x4f6>
    95c4:      	cmpl	$0xe, %r13d
    95c8:      	jne	0x93b0 <generic_rawtp_actions+0x130>
    95ce:      	movq	%r13, 0x8(%rsp)
    95d3:      	movq	%rbp, %r13
    95d6:      	movq	%rdx, %rbp
    95d9:      	addl	$0x2, %r15d
    95dd:      	movq	0x70(%rsp), %rbx
    95e2:      	jmp	0x98f8 <generic_rawtp_actions+0x678>
    95e7:      	movl	$0x9, %eax
    95ec:      	cmpl	$0x2, %r13d
    95f0:      	je	0x98bc <generic_rawtp_actions+0x63c>
    95f6:      	cmpl	$0x3, %r13d
    95fa:      	jne	0x93b0 <generic_rawtp_actions+0x130>
    9600:      	movq	%rdx, 0x8(%rsp)
    9605:      	leal	0x1(%r15), %eax
    9609:      	movq	%r14, %rcx
    960c:      	movl	0x4(%r14,%rax,4), %r14d
    9611:      	addl	$0x2, %r15d
    9615:      	movq	%rcx, %rbp
    9618:      	movl	0x4(%rcx,%r15,4), %eax
    961d:      	movq	%rax, 0x38(%rsp)
    9622:      	movq	$0x0, 0x20(%rsp)
    962b:      	movq	$0x0, 0x18(%rsp)
    9634:      	movl	$0x0, 0x28(%rsp)
    963c:      	movl	$0x1, %eax
    9641:      	leaq	0x28(%rsp), %rsi
    9646:      	movq	(%rip), %rdi            # 0x964d <generic_rawtp_actions+0x3cd>
    964d:      	callq	*%rax
    964f:      	xorl	%ecx, %ecx
    9651:      	testq	%rax, %rax
    9654:      	je	0x9a88 <generic_rawtp_actions+0x808>
    965a:      	andl	$0x7, %r14d
    965e:      	cmpl	$0x4, %r14d
    9662:      	movq	0x8(%rsp), %rdx
    9667:      	ja	0x9678 <generic_rawtp_actions+0x3f8>
    9669:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    9672:      	je	0x992d <generic_rawtp_actions+0x6ad>
    9678:      	movq	%rbp, %r14
    967b:      	movq	(%rip), %rbp            # 0x9682 <generic_rawtp_actions+0x402>
    9682:      	testl	%ecx, %ecx
    9684:      	jne	0x93ba <generic_rawtp_actions+0x13a>
    968a:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    968f:      	incl	%r15d
    9692:      	movl	0x4(%r14,%r15,4), %eax
    9697:      	andl	$0x7, %eax
    969a:      	xorl	%ecx, %ecx
    969c:      	cmpl	$0x4, %eax
    969f:      	ja	0x9a97 <generic_rawtp_actions+0x817>
    96a5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    96ad:      	jne	0x9a97 <generic_rawtp_actions+0x817>
    96b3:      	movq	0x5e78(%rdx,%rax,8), %rax
    96bb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    96c0:      	movq	0xb8(%rdx,%rax), %rax
    96c8:      	movq	%rax, 0x28(%rsp)
    96cd:      	testq	%rax, %rax
    96d0:      	je	0x9a97 <generic_rawtp_actions+0x817>
    96d6:      	movq	%rdx, 0x8(%rsp)
    96db:      	cmpl	$0xa, %r13d
    96df:      	jne	0x9aa4 <generic_rawtp_actions+0x824>
    96e5:      	movl	$0xe, %eax
    96ea:      	callq	*%rax
    96ec:      	movq	%rax, 0x38(%rsp)
    96f1:      	shrq	$0x20, %rax
    96f5:      	movl	%eax, 0x18(%rsp)
    96f9:      	movl	$0x1, %eax
    96fe:      	leaq	0x18(%rsp), %rsi
    9703:      	movq	(%rip), %rdi            # 0x970a <generic_rawtp_actions+0x48a>
    970a:      	callq	*%rax
    970c:      	xorl	%ecx, %ecx
    970e:      	testq	%rax, %rax
    9711:      	movq	0x8(%rsp), %rdx
    9716:      	je	0x9a97 <generic_rawtp_actions+0x817>
    971c:      	movl	(%rax), %ecx
    971e:      	movl	%ecx, 0x18(%rsp)
    9722:      	movq	0x38(%rsp), %rcx
    9727:      	movl	%ecx, 0x1c(%rsp)
    972b:      	movq	0x8(%rax), %rax
    972f:      	movq	%rax, 0x20(%rsp)
    9734:      	xorl	%ecx, %ecx
    9736:      	movl	$0x2, %eax
    973b:      	leaq	0x28(%rsp), %rsi
    9740:      	leaq	0x18(%rsp), %rdx
    9745:      	movq	(%rip), %rdi            # 0x974c <generic_rawtp_actions+0x4cc>
    974c:      	jmp	0x99f0 <generic_rawtp_actions+0x770>
    9751:      	movl	$0x0, 0x44(%rsp)
    9759:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    975e:      	movq	%r13, 0x8(%rsp)
    9763:      	movq	%rbp, %r13
    9766:      	movq	%rdx, %rbp
    9769:      	incl	%r15d
    976c:      	movq	0x78(%rsp), %rbx
    9771:      	jmp	0x98f8 <generic_rawtp_actions+0x678>
    9776:      	movq	%rdx, 0x8(%rsp)
    977b:      	movl	$0xe, %eax
    9780:      	callq	*%rax
    9782:      	movq	%rax, 0x50(%rsp)
    9787:      	movl	$0x1, %eax
    978c:      	leaq	0x50(%rsp), %rsi
    9791:      	movq	(%rip), %rdi            # 0x9798 <generic_rawtp_actions+0x518>
    9798:      	callq	*%rax
    979a:      	testq	%rax, %rax
    979d:      	je	0x97ed <generic_rawtp_actions+0x56d>
    979f:      	movq	0x4(%rax), %rax
    97a3:      	movq	%rax, 0x28(%rsp)
    97a8:      	movl	$0x2, 0x30(%rsp)
    97b0:      	movl	$0x1, %eax
    97b5:      	leaq	0x28(%rsp), %rsi
    97ba:      	movq	(%rip), %rbx            # 0x97c1 <generic_rawtp_actions+0x541>
    97c1:      	movq	%rbx, %rdi
    97c4:      	callq	*%rax
    97c6:      	movl	$0x1, 0x5c(%rsp)
    97ce:      	testq	%rax, %rax
    97d1:      	je	0x9a08 <generic_rawtp_actions+0x788>
    97d7:      	lock
    97d8:      	incl	(%rax)
    97da:      	movl	$0x3, %eax
    97df:      	leaq	0x50(%rsp), %rsi
    97e4:      	movq	(%rip), %rdi            # 0x97eb <generic_rawtp_actions+0x56b>
    97eb:      	callq	*%rax
    97ed:      	movq	0x8(%rsp), %rdx
    97f2:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    97f7:      	movq	%rdx, 0x8(%rsp)
    97fc:      	leal	0x1(%r15), %eax
    9800:      	movl	0x4(%r14,%rax,4), %ebx
    9805:      	leal	0x2(%r15), %eax
    9809:      	movl	0x4(%r14,%rax,4), %eax
    980e:      	movl	%eax, 0x60(%rsp)
    9812:      	movl	$0x7d, %eax
    9817:      	callq	*%rax
    9819:      	movq	%rax, 0x18(%rsp)
    981e:      	movl	$0x0, 0x50(%rsp)
    9826:      	movq	%rbx, 0xa0(%rsp)
    982e:      	testq	%rbx, %rbx
    9831:      	je	0x9ca8 <generic_rawtp_actions+0xa28>
    9837:      	movl	$0x1, %eax
    983c:      	movq	(%rip), %rdi            # 0x9843 <generic_rawtp_actions+0x5c3>
    9843:      	leaq	0x50(%rsp), %rsi
    9848:      	callq	*%rax
    984a:      	testq	%rax, %rax
    984d:      	je	0x9ca8 <generic_rawtp_actions+0xa28>
    9853:      	movq	%rax, 0x48(%rsp)
    9858:      	movq	%rax, %rbx
    985b:      	movl	$0x1, %eax
    9860:      	leaq	0x50(%rsp), %rsi
    9865:      	movq	(%rip), %rdi            # 0x986c <generic_rawtp_actions+0x5ec>
    986c:      	callq	*%rax
    986e:      	movq	%rax, %rdx
    9871:      	movq	0x8(%rsp), %rcx
    9876:      	movq	0x60(%rcx), %rax
    987a:      	movq	%rax, (%rbx)
    987d:      	movq	0x70(%rcx), %rax
    9881:      	movq	%rax, 0x8(%rbx)
    9885:      	xorl	%eax, %eax
    9887:      	movq	%rax, 0x38(%rsp)
    988c:      	movl	$0x0, %eax
    9891:      	movl	0x60(%rsp), %esi
    9895:      	cmpl	$0x2, %esi
    9898:      	je	0x9acf <generic_rawtp_actions+0x84f>
    989e:      	cmpl	$0x1, %esi
    98a1:      	je	0x9acc <generic_rawtp_actions+0x84c>
    98a7:      	testl	%esi, %esi
    98a9:      	jne	0x9ca8 <generic_rawtp_actions+0xa28>
    98af:      	movq	0x8(%rsp), %rax
    98b4:      	movl	0x7c(%rax), %eax
    98b7:      	jmp	0x9acf <generic_rawtp_actions+0x84f>
    98bc:      	movq	%r13, 0x8(%rsp)
    98c1:      	movq	%rbp, %r13
    98c4:      	movq	%rdx, %rbp
    98c7:      	movl	$0x3, %ebx
    98cc:      	cmpb	$0x0, 0x17(%rsp)
    98d1:      	je	0x98f8 <generic_rawtp_actions+0x678>
    98d3:      	movslq	%eax, %rdi
    98d6:      	movl	$0x6d, %eax
    98db:      	callq	*%rax
    98dd:      	movl	$0x2, %ebx
    98e2:      	jmp	0x98f8 <generic_rawtp_actions+0x678>
    98e4:      	movq	%r13, 0x8(%rsp)
    98e9:      	movq	%rbp, %r13
    98ec:      	movq	%rdx, %rbp
    98ef:      	addl	$0x3, %r15d
    98f3:      	movq	0x68(%rsp), %rbx
    98f8:      	movl	$0x0, 0x18(%rsp)
    9900:      	movl	$0x1, %eax
    9905:      	leaq	0x18(%rsp), %rsi
    990a:      	movq	(%rip), %rdi            # 0x9911 <generic_rawtp_actions+0x691>
    9911:      	callq	*%rax
    9913:      	testq	%rax, %rax
    9916:      	je	0x991d <generic_rawtp_actions+0x69d>
    9918:      	lock
    9919:      	incq	(%rax,%rbx,8)
    991d:      	movq	%rbp, %rdx
    9920:      	movq	%r13, %rbp
    9923:      	movq	0x8(%rsp), %r13
    9928:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    992d:      	movq	%rax, 0x48(%rsp)
    9932:      	movq	0x5e78(%rdx,%r14,8), %rax
    993a:      	movl	$0x0, 0x24(%rsp)
    9942:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9947:      	movl	0x90(%rdx,%rax), %eax
    994e:      	movl	%eax, 0x20(%rsp)
    9952:      	movl	$0xe, %eax
    9957:      	callq	*%rax
    9959:      	shrq	$0x20, %rax
    995d:      	movq	%rax, 0x18(%rsp)
    9962:      	cmpl	$0x1, %r13d
    9966:      	jne	0x9a72 <generic_rawtp_actions+0x7f2>
    996c:      	movq	0x38(%rsp), %rax
    9971:      	andl	$0x7, %eax
    9974:      	cmpl	$0x4, %eax
    9977:      	movq	%rbp, %r14
    997a:      	movl	$0x0, %ecx
    997f:      	ja	0x9a8b <generic_rawtp_actions+0x80b>
    9985:      	movq	0x8(%rsp), %rdx
    998a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    9992:      	movq	(%rip), %rbp            # 0x9999 <generic_rawtp_actions+0x719>
    9999:      	jne	0x9a97 <generic_rawtp_actions+0x817>
    999f:      	movq	0x5e78(%rdx,%rax,8), %rax
    99a7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    99ac:      	addq	%rax, %rdx
    99af:      	addq	$0x90, %rdx
    99b6:      	movq	0x8(%rsp), %rcx
    99bb:      	movl	0x90(%rcx,%rax), %esi
    99c2:      	andl	$0xfff, %esi            # imm = 0xFFF
    99c8:      	addq	$0x8, %rsi
    99cc:      	movl	$0x4, %eax
    99d1:      	movq	0x48(%rsp), %rdi
    99d6:      	callq	*%rax
    99d8:      	xorl	%ecx, %ecx
    99da:      	movl	$0x2, %eax
    99df:      	leaq	0x18(%rsp), %rsi
    99e4:      	movq	(%rip), %rdi            # 0x99eb <generic_rawtp_actions+0x76b>
    99eb:      	movq	0x48(%rsp), %rdx
    99f0:      	xorl	%ecx, %ecx
    99f2:      	callq	*%rax
    99f4:      	xorl	%ecx, %ecx
    99f6:      	movq	0x8(%rsp), %rdx
    99fb:      	testl	%ecx, %ecx
    99fd:      	jne	0x93ba <generic_rawtp_actions+0x13a>
    9a03:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    9a08:      	movl	$0x2, %eax
    9a0d:      	movl	$0x1, %ecx
    9a12:      	leaq	0x5c(%rsp), %rdx
    9a17:      	leaq	0x28(%rsp), %rsi
    9a1c:      	movq	%rbx, %rdi
    9a1f:      	callq	*%rax
    9a21:      	testq	%rax, %rax
    9a24:      	je	0x97da <generic_rawtp_actions+0x55a>
    9a2a:      	movq	%rax, 0x38(%rsp)
    9a2f:      	negl	%eax
    9a31:      	movw	%ax, 0x18(%rsp)
    9a36:      	movw	$0x3, 0x1a(%rsp)
    9a3d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9a47:      	movq	%rax, 0x1c(%rsp)
    9a4c:      	movl	$0x1, %eax
    9a51:      	leaq	0x18(%rsp), %rsi
    9a56:      	movq	(%rip), %rbx            # 0x9a5d <generic_rawtp_actions+0x7dd>
    9a5d:      	movq	%rbx, %rdi
    9a60:      	callq	*%rax
    9a62:      	testq	%rax, %rax
    9a65:      	je	0x9d28 <generic_rawtp_actions+0xaa8>
    9a6b:      	incl	(%rax)
    9a6d:      	jmp	0x9d4e <generic_rawtp_actions+0xace>
    9a72:      	movl	$0x3, %eax
    9a77:      	leaq	0x18(%rsp), %rsi
    9a7c:      	movq	(%rip), %rdi            # 0x9a83 <generic_rawtp_actions+0x803>
    9a83:      	callq	*%rax
    9a85:      	movq	%rax, %rcx
    9a88:      	movq	%rbp, %r14
    9a8b:      	movq	(%rip), %rbp            # 0x9a92 <generic_rawtp_actions+0x812>
    9a92:      	movq	0x8(%rsp), %rdx
    9a97:      	testl	%ecx, %ecx
    9a99:      	jne	0x93ba <generic_rawtp_actions+0x13a>
    9a9f:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    9aa4:      	movl	$0x3, %eax
    9aa9:      	leaq	0x28(%rsp), %rsi
    9aae:      	movq	(%rip), %rdi            # 0x9ab5 <generic_rawtp_actions+0x835>
    9ab5:      	callq	*%rax
    9ab7:      	movq	%rax, %rcx
    9aba:      	movq	0x8(%rsp), %rdx
    9abf:      	testl	%ecx, %ecx
    9ac1:      	jne	0x93ba <generic_rawtp_actions+0x13a>
    9ac7:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    9acc:      	movl	0x10(%rcx), %eax
    9acf:      	movq	%r14, 0x60(%rsp)
    9ad4:      	movl	%eax, %eax
    9ad6:      	movq	%rbx, 0x98(%rsp)
    9ade:      	movq	%rax, 0x10(%rbx)
    9ae2:      	movq	0x48(%rsp), %rdi
    9ae7:      	addq	$0x18, %rdi
    9aeb:      	movl	$0x4, %eax
    9af0:      	movl	$0xc8, %ecx
    9af5:      	movq	%rdi, 0x48(%rsp)
    9afa:      	movl	$0xc8, %esi
    9aff:      	callq	*%rax
    9b01:      	xorl	%r14d, %r14d
    9b04:      	leaq	0x28(%rsp), %rbx
    9b09:      	jmp	0x9b23 <generic_rawtp_actions+0x8a3>
    9b0b:      	nopl	(%rax,%rax)
    9b10:      	leaq	0x28(%rsp), %rbx
    9b15:      	addq	$0x4, %r14
    9b19:      	cmpq	$0x14, %r14
    9b1d:      	je	0x9c4b <generic_rawtp_actions+0x9cb>
    9b23:      	movl	$0x0, 0x28(%rsp)
    9b2b:      	movl	$0x1, %eax
    9b30:      	movq	%rbp, %rdi
    9b33:      	movq	%rbx, %rsi
    9b36:      	callq	*%rax
    9b38:      	testq	%rax, %rax
    9b3b:      	je	0x9c4b <generic_rawtp_actions+0x9cb>
    9b41:      	movq	%rax, %rsi
    9b44:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9b4b:      	movl	$0x1, %eax
    9b50:      	movq	(%rip), %rdi            # 0x9b57 <generic_rawtp_actions+0x8d7>
    9b57:      	callq	*%rax
    9b59:      	testq	%rax, %rax
    9b5c:      	je	0x9c4b <generic_rawtp_actions+0x9cb>
    9b62:      	cmpl	$-0x1, 0x40(%rax,%r14)
    9b68:      	movq	0x8(%rsp), %rdx
    9b6d:      	je	0x9c4b <generic_rawtp_actions+0x9cb>
    9b73:      	movq	0x5e78(%rdx,%r14,2), %rax
    9b7b:      	movl	0x4(%rdx), %ecx
    9b7e:      	cmpq	%rcx, %rax
    9b81:      	jge	0x9c4b <generic_rawtp_actions+0x9cb>
    9b87:      	cmpq	$0x10, %r14
    9b8b:      	je	0x9bf2 <generic_rawtp_actions+0x972>
    9b8d:      	movl	$0x0, 0x28(%rsp)
    9b95:      	movl	$0x1, %eax
    9b9a:      	movq	%rbp, %rdi
    9b9d:      	movq	%rbx, %rsi
    9ba0:      	callq	*%rax
    9ba2:      	testq	%rax, %rax
    9ba5:      	je	0x9be5 <generic_rawtp_actions+0x965>
    9ba7:      	movq	%rax, %rsi
    9baa:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9bb1:      	movl	$0x1, %eax
    9bb6:      	movq	(%rip), %rdi            # 0x9bbd <generic_rawtp_actions+0x93d>
    9bbd:      	callq	*%rax
    9bbf:      	testq	%rax, %rax
    9bc2:      	je	0x9be5 <generic_rawtp_actions+0x965>
    9bc4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    9bca:      	movq	0x8(%rsp), %rdx
    9bcf:      	movq	0x5e78(%rdx,%r14,2), %rax
    9bd7:      	je	0x9bf2 <generic_rawtp_actions+0x972>
    9bd9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    9be1:      	subl	%eax, %ebx
    9be3:      	jmp	0x9bfa <generic_rawtp_actions+0x97a>
    9be5:      	movq	0x8(%rsp), %rdx
    9bea:      	movq	0x5e78(%rdx,%r14,2), %rax
    9bf2:      	movl	0x4(%rdx), %ebx
    9bf5:      	subl	%eax, %ebx
    9bf7:      	addl	$0x4, %ebx
    9bfa:      	testl	%ebx, %ebx
    9bfc:      	jle	0x9b10 <generic_rawtp_actions+0x890>
    9c02:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    9c07:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    9c0c:      	cmpl	$0x28, %ebx
    9c0f:      	movl	$0x28, %ecx
    9c14:      	cmovgel	%ecx, %ebx
    9c17:      	movzbl	0x38(%rsp), %ebp
    9c1c:      	movq	0x48(%rsp), %rcx
    9c21:      	leaq	(%rcx,%rbp), %rdi
    9c25:      	addq	%rax, %rdx
    9c28:      	addq	$0x90, %rdx
    9c2f:      	movl	$0x4, %eax
    9c34:      	movl	%ebx, %esi
    9c36:      	callq	*%rax
    9c38:      	addl	%ebp, %ebx
    9c3a:      	movq	(%rip), %rbp            # 0x9c41 <generic_rawtp_actions+0x9c1>
    9c41:      	movq	%rbx, 0x38(%rsp)
    9c46:      	jmp	0x9b10 <generic_rawtp_actions+0x890>
    9c4b:      	movl	$0x1, %eax
    9c50:      	movq	(%rip), %rdi            # 0x9c57 <generic_rawtp_actions+0x9d7>
    9c57:      	movq	0x98(%rsp), %rbx
    9c5f:      	movq	%rbx, %rsi
    9c62:      	callq	*%rax
    9c64:      	testq	%rax, %rax
    9c67:      	movq	0x60(%rsp), %r14
    9c6c:      	je	0x9c8e <generic_rawtp_actions+0xa0e>
    9c6e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    9c7a:      	addq	0x18(%rsp), %rcx
    9c7f:      	cmpq	%rcx, (%rax)
    9c82:      	jbe	0x9c8e <generic_rawtp_actions+0xa0e>
    9c84:      	movl	$0x0, 0x44(%rsp)
    9c8c:      	jmp	0x9ca8 <generic_rawtp_actions+0xa28>
    9c8e:      	movl	$0x2, %eax
    9c93:      	xorl	%ecx, %ecx
    9c95:      	movq	(%rip), %rdi            # 0x9c9c <generic_rawtp_actions+0xa1c>
    9c9c:      	leaq	0x18(%rsp), %rdx
    9ca1:      	movq	%rbx, %rsi
    9ca4:      	xorl	%ecx, %ecx
    9ca6:      	callq	*%rax
    9ca8:      	leal	0x3(%r15), %eax
    9cac:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    9cb2:      	movq	0x8(%rsp), %rdx
    9cb7:      	je	0x9ce3 <generic_rawtp_actions+0xa63>
    9cb9:      	orb	$0x2, 0x1(%rdx)
    9cbd:      	movl	$0x1b, %eax
    9cc2:      	movq	0x80(%rsp), %rdi
    9cca:      	xorl	%ecx, %ecx
    9ccc:      	movq	(%rip), %rsi            # 0x9cd3 <generic_rawtp_actions+0xa53>
    9cd3:      	xorl	%edx, %edx
    9cd5:      	callq	*%rax
    9cd7:      	movq	0x8(%rsp), %rdx
    9cdc:      	movq	%rax, 0x80(%rdx)
    9ce3:      	addl	$0x4, %r15d
    9ce7:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    9ced:      	je	0x93b0 <generic_rawtp_actions+0x130>
    9cf3:      	orb	$0x4, 0x1(%rdx)
    9cf7:      	movl	$0x1b, %eax
    9cfc:      	movq	0x80(%rsp), %rdi
    9d04:      	movq	(%rip), %rsi            # 0x9d0b <generic_rawtp_actions+0xa8b>
    9d0b:      	movl	$0x100, %ecx            # imm = 0x100
    9d10:      	movl	$0x100, %edx            # imm = 0x100
    9d15:      	callq	*%rax
    9d17:      	movq	0x8(%rsp), %rdx
    9d1c:      	movq	%rax, 0x88(%rdx)
    9d23:      	jmp	0x93b0 <generic_rawtp_actions+0x130>
    9d28:      	movl	$0x1, 0x94(%rsp)
    9d33:      	movl	$0x2, %eax
    9d38:      	xorl	%ecx, %ecx
    9d3a:      	leaq	0x94(%rsp), %rdx
    9d42:      	leaq	0x18(%rsp), %rsi
    9d47:      	movq	%rbx, %rdi
    9d4a:      	xorl	%ecx, %ecx
    9d4c:      	callq	*%rax
    9d4e:      	cmpl	$0x0, 0x38(%rsp)
    9d53:      	je	0x97da <generic_rawtp_actions+0x55a>
    9d59:      	movl	$0x1, %eax
    9d5e:      	leaq	0x28(%rsp), %rsi
    9d63:      	movq	(%rip), %rdi            # 0x9d6a <generic_rawtp_actions+0xaea>
    9d6a:      	callq	*%rax
    9d6c:      	testq	%rax, %rax
    9d6f:      	je	0x97da <generic_rawtp_actions+0x55a>
    9d75:      	movl	0x5c(%rsp), %ecx
    9d79:      	lock
    9d7a:      	addl	%ecx, (%rax)
    9d7c:      	jmp	0x97da <generic_rawtp_actions+0x55a>
    9d81:      	cmpb	$0x0, 0x44(%rsp)
    9d86:      	je	0x9da8 <generic_rawtp_actions+0xb28>
    9d88:      	movq	(%rip), %rsi            # 0x9d8f <generic_rawtp_actions+0xb0f>
    9d8f:      	movl	$0x5, %ecx
    9d94:      	movl	$0xc, %eax
    9d99:      	movq	0x80(%rsp), %rdi
    9da1:      	movl	$0x5, %edx
    9da6:      	callq	*%rax
    9da8:      	xorl	%eax, %eax
    9daa:      	addq	$0xa8, %rsp
    9db1:      	popq	%rbx
    9db2:      	popq	%r12
    9db4:      	popq	%r13
    9db6:      	popq	%r14
    9db8:      	popq	%r15
    9dba:      	popq	%rbp
    9dbb:      	retq
    9dbc:      	nopl	(%rax)

0000000000009dc0 <generic_rawtp_output>:
    9dc0:      	pushq	%rbp
    9dc1:      	pushq	%r15
    9dc3:      	pushq	%r14
    9dc5:      	pushq	%r13
    9dc7:      	pushq	%r12
    9dc9:      	pushq	%rbx
    9dca:      	subq	$0x78, %rsp
    9dce:      	movq	%rdi, %rbx
    9dd1:      	movl	$0x0, 0x14(%rsp)
    9dd9:      	movq	(%rip), %rdi            # 0x9de0 <generic_rawtp_output+0x20>
    9de0:      	leaq	0x14(%rsp), %rsi
    9de5:      	movl	$0x1, %eax
    9dea:      	callq	*%rax
    9dec:      	testq	%rax, %rax
    9def:      	je	0xa2ca <generic_rawtp_output+0x50a>
    9df5:      	movq	%rax, %r14
    9df8:      	cmpq	$0x0, 0x5ee8(%rax)
    9e00:      	je	0xa114 <generic_rawtp_output+0x354>
    9e06:      	movl	$0xe, %eax
    9e0b:      	callq	*%rax
    9e0d:      	movq	%rax, %r15
    9e10:      	shrq	$0x20, %r15
    9e14:      	movl	$0x23, %eax
    9e19:      	callq	*%rax
    9e1b:      	movq	%rax, %r12
    9e1e:      	movl	%r15d, 0x28(%rsp)
    9e23:      	movq	(%rip), %rdi            # 0x9e2a <generic_rawtp_output+0x6a>
    9e2a:      	leaq	0x28(%rsp), %rsi
    9e2f:      	movl	$0x1, %eax
    9e34:      	callq	*%rax
    9e36:      	testq	%rax, %rax
    9e39:      	je	0xa114 <generic_rawtp_output+0x354>
    9e3f:      	movq	%rax, %r15
    9e42:      	leaq	0xd70(%r12), %rdx
    9e4a:      	leaq	0x70(%rsp), %rdi
    9e4f:      	movl	$0x8, %ecx
    9e54:      	movl	$0x4, %eax
    9e59:      	leaq	0x28(%r15), %r13
    9e5d:      	movl	$0x4, %ebp
    9e62:      	movl	$0x8, %esi
    9e67:      	callq	*%rax
    9e69:      	movq	0x70(%rsp), %rcx
    9e6e:      	leaq	0x28(%rsp), %rdi
    9e73:      	movl	$0x48, %edx
    9e78:      	movl	$0x4, %eax
    9e7d:      	movq	0x70(%rsp), %rdx
    9e82:      	movl	$0x48, %esi
    9e87:      	callq	*%rax
    9e89:      	movl	$0x218, %edx            # imm = 0x218
    9e8e:      	movq	0x30(%rsp), %rcx
    9e93:      	addq	%rdx, %rcx
    9e96:      	movl	$0x4, %esi
    9e9b:      	movl	$0x4, %eax
    9ea0:      	addq	0x30(%rsp), %rdx
    9ea5:      	movq	%r13, %rdi
    9ea8:      	movl	$0x4, %esi
    9ead:      	callq	*%rax
    9eaf:      	leaq	0x2c(%r15), %rdi
    9eb3:      	movl	$0x4d8, %edx            # imm = 0x4D8
    9eb8:      	movq	0x38(%rsp), %rcx
    9ebd:      	addq	%rdx, %rcx
    9ec0:      	movl	$0x4, %esi
    9ec5:      	movl	$0x4, %eax
    9eca:      	addq	0x38(%rsp), %rdx
    9ecf:      	movl	$0x4, %esi
    9ed4:      	callq	*%rax
    9ed6:      	leaq	0x30(%r15), %rdi
    9eda:      	movq	0x40(%rsp), %rcx
    9edf:      	addq	$0x58, %rcx
    9ee3:      	movl	$0x4, %edx
    9ee8:      	movl	$0x4, %eax
    9eed:      	movq	0x40(%rsp), %rdx
    9ef2:      	addq	$0x58, %rdx
    9ef6:      	movl	$0x4, %esi
    9efb:      	callq	*%rax
    9efd:      	movq	$0x0, 0x8(%rsp)
    9f06:      	leaq	0xb58(%r12), %rdx
    9f0e:      	leaq	0x8(%rsp), %rdi
    9f13:      	movl	$0x8, %ecx
    9f18:      	movl	$0x4, %eax
    9f1d:      	movl	$0x8, %esi
    9f22:      	callq	*%rax
    9f24:      	movq	0x8(%rsp), %rcx
    9f29:      	testq	%rcx, %rcx
    9f2c:      	je	0x9fc2 <generic_rawtp_output+0x202>
    9f32:      	movl	$0x0, 0x10(%rsp)
    9f3a:      	addq	$0x4, %rcx
    9f3e:      	leaq	0x10(%rsp), %rdi
    9f43:      	movl	$0x4, %eax
    9f48:      	movq	0x8(%rsp), %rdx
    9f4d:      	addq	$0x4, %rdx
    9f51:      	movl	$0x4, %esi
    9f56:      	callq	*%rax
    9f58:      	movq	0x8(%rsp), %rax
    9f5d:      	movslq	0x10(%rsp), %rcx
    9f62:      	shlq	$0x4, %rcx
    9f66:      	addq	%rax, %rcx
    9f69:      	addq	$0x80, %rcx
    9f70:      	leaq	0x18(%rsp), %rdi
    9f75:      	movl	$0x10, %edx
    9f7a:      	movl	$0x4, %eax
    9f7f:      	movq	0x8(%rsp), %rcx
    9f84:      	movslq	0x10(%rsp), %rdx
    9f89:      	shlq	$0x4, %rdx
    9f8d:      	addq	%rcx, %rdx
    9f90:      	addq	$0x80, %rdx
    9f97:      	movl	$0x10, %esi
    9f9c:      	callq	*%rax
    9f9e:      	leaq	0x34(%r15), %rdi
    9fa2:      	movl	$0x158, %edx            # imm = 0x158
    9fa7:      	movq	0x20(%rsp), %rcx
    9fac:      	addq	%rdx, %rcx
    9faf:      	movl	$0x4, %eax
    9fb4:      	addq	0x20(%rsp), %rdx
    9fb9:      	movl	$0x4, %esi
    9fbe:      	callq	*%rax
    9fc0:      	jmp	0x9fca <generic_rawtp_output+0x20a>
    9fc2:      	movl	$0x0, 0x34(%r15)
    9fca:      	leaq	0x38(%r15), %rdi
    9fce:      	movl	$0x158, %r13d           # imm = 0x158
    9fd4:      	movq	0x48(%rsp), %rcx
    9fd9:      	addq	%r13, %rcx
    9fdc:      	movl	$0x4, %edx
    9fe1:      	movl	$0x4, %eax
    9fe6:      	movq	0x48(%rsp), %rdx
    9feb:      	addq	%r13, %rdx
    9fee:      	movl	$0x4, %esi
    9ff3:      	callq	*%rax
    9ff5:      	leaq	0x3c(%r15), %rdi
    9ff9:      	movl	$0x118, %edx            # imm = 0x118
    9ffe:      	movq	0x50(%rsp), %rcx
    a003:      	addq	%rdx, %rcx
    a006:      	movl	$0x4, %esi
    a00b:      	movl	$0x4, %eax
    a010:      	addq	0x50(%rsp), %rdx
    a015:      	movl	$0x4, %esi
    a01a:      	callq	*%rax
    a01c:      	leaq	0x40(%r15), %rdi
    a020:      	movl	$0x98, %ebp
    a025:      	movq	0x58(%rsp), %rcx
    a02a:      	addq	%rbp, %rcx
    a02d:      	movl	$0x4, %edx
    a032:      	movl	$0x4, %eax
    a037:      	movq	0x58(%rsp), %rdx
    a03c:      	addq	%rbp, %rdx
    a03f:      	movl	$0x4, %esi
    a044:      	callq	*%rax
    a046:      	leaq	0x44(%r15), %rdi
    a04a:      	movq	0x60(%rsp), %rcx
    a04f:      	addq	%rbp, %rcx
    a052:      	movl	$0x4, %edx
    a057:      	movl	$0x4, %eax
    a05c:      	addq	0x60(%rsp), %rbp
    a061:      	movl	$0x4, %esi
    a066:      	movq	%rbp, %rdx
    a069:      	callq	*%rax
    a06b:      	leaq	0x48(%r15), %rdi
    a06f:      	movq	0x68(%rsp), %rcx
    a074:      	addq	$0x58, %rcx
    a078:      	movl	$0x4, %edx
    a07d:      	movl	$0x4, %eax
    a082:      	movq	0x68(%rsp), %rdx
    a087:      	addq	$0x58, %rdx
    a08b:      	movl	$0x4, %esi
    a090:      	callq	*%rax
    a092:      	movq	$0x0, 0x18(%rsp)
    a09b:      	movq	$0x0, 0x8(%rsp)
    a0a4:      	addq	$0xd00, %r12            # imm = 0xD00
    a0ab:      	leaq	0x18(%rsp), %rdi
    a0b0:      	movl	$0x8, %ecx
    a0b5:      	movl	$0x4, %eax
    a0ba:      	movl	$0x8, %esi
    a0bf:      	movq	%r12, %rdx
    a0c2:      	callq	*%rax
    a0c4:      	movl	$0x90, %edx
    a0c9:      	movq	0x18(%rsp), %rcx
    a0ce:      	addq	%rdx, %rcx
    a0d1:      	leaq	0x8(%rsp), %rdi
    a0d6:      	movl	$0x8, %esi
    a0db:      	movl	$0x4, %eax
    a0e0:      	addq	0x18(%rsp), %rdx
    a0e5:      	movl	$0x8, %esi
    a0ea:      	callq	*%rax
    a0ec:      	addq	$0x4c, %r15
    a0f0:      	movq	0x8(%rsp), %rcx
    a0f5:      	addq	%r13, %rcx
    a0f8:      	movl	$0x4, %edx
    a0fd:      	movl	$0x4, %eax
    a102:      	addq	0x8(%rsp), %r13
    a107:      	movq	%r15, %rdi
    a10a:      	movl	$0x4, %esi
    a10f:      	movq	%r13, %rdx
    a112:      	callq	*%rax
    a114:      	cmpq	$0x0, 0x5ef0(%r14)
    a11c:      	je	0xa1d5 <generic_rawtp_output+0x415>
    a122:      	movl	$0xe, %eax
    a127:      	callq	*%rax
    a129:      	movq	%rax, %r15
    a12c:      	shrq	$0x20, %r15
    a130:      	movl	$0x23, %eax
    a135:      	callq	*%rax
    a137:      	movq	%rax, %r12
    a13a:      	movl	%r15d, 0x28(%rsp)
    a13f:      	movq	(%rip), %rdi            # 0xa146 <generic_rawtp_output+0x386>
    a146:      	leaq	0x28(%rsp), %rsi
    a14b:      	movl	$0x1, %eax
    a150:      	callq	*%rax
    a152:      	testq	%rax, %rax
    a155:      	je	0xa1d5 <generic_rawtp_output+0x415>
    a157:      	leaq	0x50(%rax), %r15
    a15b:      	addq	$0xd00, %r12            # imm = 0xD00
    a162:      	leaq	0x28(%rsp), %rdi
    a167:      	movl	$0x8, %ecx
    a16c:      	movq	%rax, %r13
    a16f:      	movl	$0x4, %eax
    a174:      	movl	$0x8, %esi
    a179:      	movq	%r12, %rdx
    a17c:      	callq	*%rax
    a17e:      	movq	0x28(%rsp), %r12
    a183:      	leaq	0x58(%r13), %rdi
    a187:      	leaq	0x40(%r12), %rdx
    a18c:      	movl	$0x8, %ecx
    a191:      	movl	$0x4, %eax
    a196:      	movl	$0x8, %esi
    a19b:      	callq	*%rax
    a19d:      	addq	$0x60, %r13
    a1a1:      	leaq	0x30(%r12), %rdx
    a1a6:      	movl	$0x8, %ecx
    a1ab:      	movl	$0x4, %eax
    a1b0:      	movq	%r13, %rdi
    a1b3:      	movl	$0x8, %esi
    a1b8:      	callq	*%rax
    a1ba:      	addq	$0x38, %r12
    a1be:      	movl	$0x8, %ecx
    a1c3:      	movl	$0x4, %eax
    a1c8:      	movq	%r15, %rdi
    a1cb:      	movl	$0x8, %esi
    a1d0:      	movq	%r12, %rdx
    a1d3:      	callq	*%rax
    a1d5:      	movl	$0x90, %eax
    a1da:      	addl	0x4(%r14), %eax
    a1de:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    a1e3:      	cmpl	$0x2328, %eax           # imm = 0x2328
    a1e8:      	movl	$0x2328, %r8d           # imm = 0x2328
    a1ee:      	cmovbl	%eax, %r8d
    a1f2:      	movq	(%rip), %rsi            # 0xa1f9 <generic_rawtp_output+0x439>
    a1f9:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    a1fe:      	movl	$0x19, %eax
    a203:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    a208:      	movq	%rbx, %rdi
    a20b:      	movq	%r14, %rcx
    a20e:      	callq	*%rax
    a210:      	testq	%rax, %rax
    a213:      	js	0xa243 <generic_rawtp_output+0x483>
    a215:      	movl	$0x0, 0x28(%rsp)
    a21d:      	movq	(%rip), %rdi            # 0xa224 <generic_rawtp_output+0x464>
    a224:      	leaq	0x28(%rsp), %rsi
    a229:      	movl	$0x1, %eax
    a22e:      	callq	*%rax
    a230:      	testq	%rax, %rax
    a233:      	je	0xa2ca <generic_rawtp_output+0x50a>
    a239:      	lock
    a23a:      	incq	0x8(%rax)
    a23e:      	jmp	0xa2ca <generic_rawtp_output+0x50a>
    a243:      	movq	%rax, %rbx
    a246:      	movl	$0x0, 0x28(%rsp)
    a24e:      	movq	(%rip), %rdi            # 0xa255 <generic_rawtp_output+0x495>
    a255:      	leaq	0x28(%rsp), %rsi
    a25a:      	movl	$0x1, %eax
    a25f:      	callq	*%rax
    a261:      	testq	%rax, %rax
    a264:      	je	0xa2ca <generic_rawtp_output+0x50a>
    a266:      	cmpq	$-0xc, %rbx
    a26a:      	jg	0xa286 <generic_rawtp_output+0x4c6>
    a26c:      	cmpq	$-0x1c, %rbx
    a270:      	je	0xa2a0 <generic_rawtp_output+0x4e0>
    a272:      	cmpq	$-0x16, %rbx
    a276:      	je	0xa2b8 <generic_rawtp_output+0x4f8>
    a278:      	cmpq	$-0x10, %rbx
    a27c:      	jne	0xa2b0 <generic_rawtp_output+0x4f0>
    a27e:      	addq	$0x328, %rax            # imm = 0x328
    a284:      	jmp	0xa2c6 <generic_rawtp_output+0x506>
    a286:      	cmpq	$-0xb, %rbx
    a28a:      	je	0xa2a8 <generic_rawtp_output+0x4e8>
    a28c:      	cmpq	$-0x7, %rbx
    a290:      	je	0xa2c0 <generic_rawtp_output+0x500>
    a292:      	cmpq	$-0x2, %rbx
    a296:      	jne	0xa2b0 <generic_rawtp_output+0x4f0>
    a298:      	addq	$0x318, %rax            # imm = 0x318
    a29e:      	jmp	0xa2c6 <generic_rawtp_output+0x506>
    a2a0:      	addq	$0x338, %rax            # imm = 0x338
    a2a6:      	jmp	0xa2c6 <generic_rawtp_output+0x506>
    a2a8:      	addq	$0x340, %rax            # imm = 0x340
    a2ae:      	jmp	0xa2c6 <generic_rawtp_output+0x506>
    a2b0:      	addq	$0x310, %rax            # imm = 0x310
    a2b6:      	jmp	0xa2c6 <generic_rawtp_output+0x506>
    a2b8:      	addq	$0x330, %rax            # imm = 0x330
    a2be:      	jmp	0xa2c6 <generic_rawtp_output+0x506>
    a2c0:      	addq	$0x320, %rax            # imm = 0x320
    a2c6:      	lock
    a2c7:      	incq	(%rax)
    a2ca:      	xorl	%eax, %eax
    a2cc:      	addq	$0x78, %rsp
    a2d0:      	popq	%rbx
    a2d1:      	popq	%r12
    a2d3:      	popq	%r13
    a2d5:      	popq	%r14
    a2d7:      	popq	%r15
    a2d9:      	popq	%rbp
    a2da:      	retq
    a2db:      	nopl	(%rax,%rax)

000000000000a2e0 <generic_rawtp_path>:
    a2e0:      	pushq	%rbp
    a2e1:      	pushq	%r15
    a2e3:      	pushq	%r14
    a2e5:      	pushq	%r13
    a2e7:      	pushq	%r12
    a2e9:      	pushq	%rbx
    a2ea:      	subq	$0x88, %rsp
    a2f1:      	movq	%rdi, %rbp
    a2f4:      	movl	$0x0, 0x70(%rsp)
    a2fc:      	movq	(%rip), %rdi            # 0xa303 <generic_rawtp_path+0x23>
    a303:      	leaq	0x70(%rsp), %rsi
    a308:      	movl	$0x1, %eax
    a30d:      	callq	*%rax
    a30f:      	testq	%rax, %rax
    a312:      	je	0x16159 <generic_rawtp_path+0xbe79>
    a318:      	movq	%rax, %r14
    a31b:      	movl	0x6420(%rax), %eax
    a321:      	cmpl	$0x1, %eax
    a324:      	je	0xa3c6 <generic_rawtp_path+0xe6>
    a32a:      	testl	%eax, %eax
    a32c:      	jne	0x16159 <generic_rawtp_path+0xbe79>
    a332:      	movq	0x6440(%r14), %r12
    a339:      	movl	$0x0, 0x10(%rsp)
    a341:      	movq	(%rip), %rdi            # 0xa348 <generic_rawtp_path+0x68>
    a348:      	leaq	0x10(%rsp), %rsi
    a34d:      	movl	$0x1, %eax
    a352:      	callq	*%rax
    a354:      	testq	%rax, %rax
    a357:      	je	0x16159 <generic_rawtp_path+0xbe79>
    a35d:      	movq	%rax, %r15
    a360:      	addq	$0x8, %r12
    a364:      	leaq	0x58(%rsp), %rdi
    a369:      	movl	$0x8, %ecx
    a36e:      	movl	$0x4, %eax
    a373:      	movl	$0x8, %esi
    a378:      	movq	%r12, %rdx
    a37b:      	callq	*%rax
    a37d:      	testq	%rax, %rax
    a380:      	je	0x15e09 <generic_rawtp_path+0xbb29>
    a386:      	negl	%eax
    a388:      	movw	%ax, 0x18(%rsp)
    a38d:      	movw	$0x6, 0x1a(%rsp)
    a394:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    a39e:      	movq	%rax, 0x1c(%rsp)
    a3a3:      	movq	(%rip), %rdi            # 0xa3aa <generic_rawtp_path+0xca>
    a3aa:      	leaq	0x18(%rsp), %rsi
    a3af:      	movl	$0x1, %eax
    a3b4:      	callq	*%rax
    a3b6:      	testq	%rax, %rax
    a3b9:      	je	0x15de8 <generic_rawtp_path+0xbb08>
    a3bf:      	incl	(%rax)
    a3c1:      	jmp	0x15e09 <generic_rawtp_path+0xbb29>
    a3c6:      	movq	0x6448(%r14), %rax
    a3cd:      	movq	%rax, 0x18(%rsp)
    a3d2:      	movq	0x6450(%r14), %rax
    a3d9:      	movq	%rax, 0x20(%rsp)
    a3de:      	movq	$0x0, 0x28(%rsp)
    a3e7:      	movq	0x6458(%r14), %rax
    a3ee:      	movq	%rax, 0x30(%rsp)
    a3f3:      	movq	0x6460(%r14), %rax
    a3fa:      	movq	%rax, 0x38(%rsp)
    a3ff:      	movq	0x6468(%r14), %rax
    a406:      	movq	%rax, 0x40(%rsp)
    a40b:      	movq	$0x0, 0x48(%rsp)
    a414:      	movl	$0x0, 0x50(%rsp)
    a41c:      	movb	$0x0, 0x54(%rsp)
    a421:      	movl	$0x0, 0x74(%rsp)
    a429:      	movq	(%rip), %rdi            # 0xa430 <generic_rawtp_path+0x150>
    a430:      	leaq	0x74(%rsp), %rsi
    a435:      	movl	$0x1, %eax
    a43a:      	callq	*%rax
    a43c:      	testq	%rax, %rax
    a43f:      	je	0x16159 <generic_rawtp_path+0xbe79>
    a445:      	movq	%rbp, 0x78(%rsp)
    a44a:      	movq	%rax, 0x28(%rsp)
    a44f:      	movl	0x6424(%r14), %edx
    a456:      	movl	%edx, %ecx
    a458:      	andl	$0xfff, %ecx            # imm = 0xFFF
    a45e:      	movq	%rax, %rsi
    a461:      	movq	%rax, 0x80(%rsp)
    a469:      	addq	%rax, %rcx
    a46c:      	movq	%rcx, 0x48(%rsp)
    a471:      	movl	%edx, 0x50(%rsp)
    a475:      	movl	$0x200, %eax            # imm = 0x200
    a47a:      	movl	$0x8, %r13d
    a480:      	movq	%rsp, %rbp
    a483:      	movl	%eax, 0x6c(%rsp)
    a487:      	movq	0x30(%rsp), %r12
    a48c:      	movq	0x38(%rsp), %rdx
    a491:      	movq	0x40(%rsp), %r15
    a496:      	cmpq	0x18(%rsp), %r12
    a49b:      	jne	0xa4a8 <generic_rawtp_path+0x1c8>
    a49d:      	cmpq	0x20(%rsp), %rdx
    a4a2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a4a8:      	movl	$0x4, %eax
    a4ad:      	leaq	0x10(%rsp), %rdi
    a4b2:      	movl	$0x8, %esi
    a4b7:      	callq	*%rax
    a4b9:      	cmpq	0x10(%rsp), %r12
    a4be:      	je	0xa5bd <generic_rawtp_path+0x2dd>
    a4c4:      	leaq	0x18(%r12), %rbx
    a4c9:      	movl	$0x4, %eax
    a4ce:      	movq	%rbp, %rdi
    a4d1:      	movl	$0x8, %esi
    a4d6:      	movq	%rbx, %rdx
    a4d9:      	callq	*%rax
    a4db:      	cmpq	%r12, (%rsp)
    a4df:      	je	0xa5bd <generic_rawtp_path+0x2dd>
    a4e5:      	movl	$0x4, %eax
    a4ea:      	leaq	0x8(%rsp), %rdi
    a4ef:      	movl	$0x8, %esi
    a4f4:      	movq	%rbx, %rdx
    a4f7:      	callq	*%rax
    a4f9:      	addq	$0x20, %r12
    a4fd:      	movl	$0x4, %eax
    a502:      	leaq	0x58(%rsp), %rdi
    a507:      	movl	$0x10, %ecx
    a50c:      	movl	$0x10, %esi
    a511:      	movq	%r12, %rdx
    a514:      	callq	*%rax
    a516:      	movq	0x28(%rsp), %rbx
    a51b:      	movq	0x48(%rsp), %rax
    a520:      	movl	0x5c(%rsp), %r15d
    a525:      	subq	%rbx, %rax
    a528:      	movl	0x50(%rsp), %r12d
    a52d:      	movl	%r15d, %edx
    a530:      	subl	%r12d, %edx
    a533:      	movl	$0x0, %ecx
    a538:      	cmovbl	%ecx, %edx
    a53b:      	addq	0x60(%rsp), %rdx
    a540:      	xorl	%esi, %esi
    a542:      	cmpl	%r15d, %r12d
    a545:      	seta	%sil
    a549:      	movl	%r15d, %ecx
    a54c:      	cmovbl	%r12d, %ecx
    a550:      	addl	%ecx, %esi
    a552:      	movl	%r12d, %edi
    a555:      	subl	%esi, %edi
    a557:      	movl	%edi, 0x50(%rsp)
    a55b:      	subq	%rsi, %rax
    a55e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    a564:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    a56a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    a570:      	cmpl	%r15d, %r12d
    a573:      	jbe	0xa579 <generic_rawtp_path+0x299>
    a575:      	movb	$0x2f, (%rbx,%rax)
    a579:      	xorl	%edi, %edi
    a57b:      	cmpl	%r15d, %r12d
    a57e:      	seta	%dil
    a582:      	movzbl	%cl, %esi
    a585:      	addq	%rax, %rbx
    a588:      	addq	%rbx, %rdi
    a58b:      	movl	$0x4, %eax
    a590:      	callq	*%rax
    a592:      	movq	%rbx, 0x48(%rsp)
    a597:      	cmpl	%r15d, %r12d
    a59a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    a5a0:      	movq	0x8(%rsp), %r12
    a5a5:      	movq	%r12, 0x30(%rsp)
    a5aa:      	movq	0x38(%rsp), %rdx
    a5af:      	movq	0x40(%rsp), %r15
    a5b4:      	cmpq	0x18(%rsp), %r12
    a5b9:      	je	0xa615 <generic_rawtp_path+0x335>
    a5bb:      	jmp	0xa620 <generic_rawtp_path+0x340>
    a5bd:      	leaq	0x10(%r15), %rdx
    a5c1:      	movl	$0x4, %eax
    a5c6:      	movq	%rbp, %rdi
    a5c9:      	movl	$0x8, %esi
    a5ce:      	callq	*%rax
    a5d0:      	movq	0x40(%rsp), %rax
    a5d5:      	cmpq	(%rsp), %rax
    a5d9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a5df:      	addq	$0x18, %r15
    a5e3:      	movl	$0x4, %eax
    a5e8:      	leaq	0x30(%rsp), %rdi
    a5ed:      	movl	$0x8, %esi
    a5f2:      	movq	%r15, %rdx
    a5f5:      	callq	*%rax
    a5f7:      	movq	(%rsp), %r15
    a5fb:      	movq	%r15, 0x40(%rsp)
    a600:      	leaq	0x20(%r15), %rdx
    a604:      	movq	%rdx, 0x38(%rsp)
    a609:      	movq	0x30(%rsp), %r12
    a60e:      	cmpq	0x18(%rsp), %r12
    a613:      	jne	0xa620 <generic_rawtp_path+0x340>
    a615:      	cmpq	0x20(%rsp), %rdx
    a61a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a620:      	movl	$0x4, %eax
    a625:      	leaq	0x10(%rsp), %rdi
    a62a:      	movl	$0x8, %esi
    a62f:      	callq	*%rax
    a631:      	cmpq	0x10(%rsp), %r12
    a636:      	je	0xa735 <generic_rawtp_path+0x455>
    a63c:      	leaq	0x18(%r12), %rbx
    a641:      	movl	$0x4, %eax
    a646:      	movq	%rbp, %rdi
    a649:      	movl	$0x8, %esi
    a64e:      	movq	%rbx, %rdx
    a651:      	callq	*%rax
    a653:      	cmpq	%r12, (%rsp)
    a657:      	je	0xa735 <generic_rawtp_path+0x455>
    a65d:      	movl	$0x4, %eax
    a662:      	leaq	0x8(%rsp), %rdi
    a667:      	movl	$0x8, %esi
    a66c:      	movq	%rbx, %rdx
    a66f:      	callq	*%rax
    a671:      	addq	$0x20, %r12
    a675:      	movl	$0x4, %eax
    a67a:      	leaq	0x58(%rsp), %rdi
    a67f:      	movl	$0x10, %ecx
    a684:      	movl	$0x10, %esi
    a689:      	movq	%r12, %rdx
    a68c:      	callq	*%rax
    a68e:      	movq	0x28(%rsp), %rbx
    a693:      	movq	0x48(%rsp), %rax
    a698:      	movl	0x5c(%rsp), %r15d
    a69d:      	subq	%rbx, %rax
    a6a0:      	movl	0x50(%rsp), %r12d
    a6a5:      	movl	%r15d, %edx
    a6a8:      	subl	%r12d, %edx
    a6ab:      	movl	$0x0, %ecx
    a6b0:      	cmovbl	%ecx, %edx
    a6b3:      	addq	0x60(%rsp), %rdx
    a6b8:      	xorl	%esi, %esi
    a6ba:      	cmpl	%r15d, %r12d
    a6bd:      	seta	%sil
    a6c1:      	movl	%r15d, %ecx
    a6c4:      	cmovbl	%r12d, %ecx
    a6c8:      	addl	%ecx, %esi
    a6ca:      	movl	%r12d, %edi
    a6cd:      	subl	%esi, %edi
    a6cf:      	movl	%edi, 0x50(%rsp)
    a6d3:      	subq	%rsi, %rax
    a6d6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    a6dc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    a6e2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    a6e8:      	cmpl	%r15d, %r12d
    a6eb:      	jbe	0xa6f1 <generic_rawtp_path+0x411>
    a6ed:      	movb	$0x2f, (%rbx,%rax)
    a6f1:      	xorl	%edi, %edi
    a6f3:      	cmpl	%r15d, %r12d
    a6f6:      	seta	%dil
    a6fa:      	movzbl	%cl, %esi
    a6fd:      	addq	%rax, %rbx
    a700:      	addq	%rbx, %rdi
    a703:      	movl	$0x4, %eax
    a708:      	callq	*%rax
    a70a:      	movq	%rbx, 0x48(%rsp)
    a70f:      	cmpl	%r15d, %r12d
    a712:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    a718:      	movq	0x8(%rsp), %r12
    a71d:      	movq	%r12, 0x30(%rsp)
    a722:      	movq	0x38(%rsp), %rdx
    a727:      	movq	0x40(%rsp), %r15
    a72c:      	cmpq	0x18(%rsp), %r12
    a731:      	je	0xa78d <generic_rawtp_path+0x4ad>
    a733:      	jmp	0xa798 <generic_rawtp_path+0x4b8>
    a735:      	leaq	0x10(%r15), %rdx
    a739:      	movl	$0x4, %eax
    a73e:      	movq	%rbp, %rdi
    a741:      	movl	$0x8, %esi
    a746:      	callq	*%rax
    a748:      	movq	0x40(%rsp), %rax
    a74d:      	cmpq	(%rsp), %rax
    a751:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a757:      	addq	$0x18, %r15
    a75b:      	movl	$0x4, %eax
    a760:      	leaq	0x30(%rsp), %rdi
    a765:      	movl	$0x8, %esi
    a76a:      	movq	%r15, %rdx
    a76d:      	callq	*%rax
    a76f:      	movq	(%rsp), %r15
    a773:      	movq	%r15, 0x40(%rsp)
    a778:      	leaq	0x20(%r15), %rdx
    a77c:      	movq	%rdx, 0x38(%rsp)
    a781:      	movq	0x30(%rsp), %r12
    a786:      	cmpq	0x18(%rsp), %r12
    a78b:      	jne	0xa798 <generic_rawtp_path+0x4b8>
    a78d:      	cmpq	0x20(%rsp), %rdx
    a792:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a798:      	movl	$0x4, %eax
    a79d:      	leaq	0x10(%rsp), %rdi
    a7a2:      	movl	$0x8, %esi
    a7a7:      	callq	*%rax
    a7a9:      	cmpq	0x10(%rsp), %r12
    a7ae:      	je	0xa8ad <generic_rawtp_path+0x5cd>
    a7b4:      	leaq	0x18(%r12), %rbx
    a7b9:      	movl	$0x4, %eax
    a7be:      	movq	%rbp, %rdi
    a7c1:      	movl	$0x8, %esi
    a7c6:      	movq	%rbx, %rdx
    a7c9:      	callq	*%rax
    a7cb:      	cmpq	%r12, (%rsp)
    a7cf:      	je	0xa8ad <generic_rawtp_path+0x5cd>
    a7d5:      	movl	$0x4, %eax
    a7da:      	leaq	0x8(%rsp), %rdi
    a7df:      	movl	$0x8, %esi
    a7e4:      	movq	%rbx, %rdx
    a7e7:      	callq	*%rax
    a7e9:      	addq	$0x20, %r12
    a7ed:      	movl	$0x4, %eax
    a7f2:      	leaq	0x58(%rsp), %rdi
    a7f7:      	movl	$0x10, %ecx
    a7fc:      	movl	$0x10, %esi
    a801:      	movq	%r12, %rdx
    a804:      	callq	*%rax
    a806:      	movq	0x28(%rsp), %rbx
    a80b:      	movq	0x48(%rsp), %rax
    a810:      	movl	0x5c(%rsp), %r15d
    a815:      	subq	%rbx, %rax
    a818:      	movl	0x50(%rsp), %r12d
    a81d:      	movl	%r15d, %edx
    a820:      	subl	%r12d, %edx
    a823:      	movl	$0x0, %ecx
    a828:      	cmovbl	%ecx, %edx
    a82b:      	addq	0x60(%rsp), %rdx
    a830:      	xorl	%esi, %esi
    a832:      	cmpl	%r15d, %r12d
    a835:      	seta	%sil
    a839:      	movl	%r15d, %ecx
    a83c:      	cmovbl	%r12d, %ecx
    a840:      	addl	%ecx, %esi
    a842:      	movl	%r12d, %edi
    a845:      	subl	%esi, %edi
    a847:      	movl	%edi, 0x50(%rsp)
    a84b:      	subq	%rsi, %rax
    a84e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    a854:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    a85a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    a860:      	cmpl	%r15d, %r12d
    a863:      	jbe	0xa869 <generic_rawtp_path+0x589>
    a865:      	movb	$0x2f, (%rbx,%rax)
    a869:      	xorl	%edi, %edi
    a86b:      	cmpl	%r15d, %r12d
    a86e:      	seta	%dil
    a872:      	movzbl	%cl, %esi
    a875:      	addq	%rax, %rbx
    a878:      	addq	%rbx, %rdi
    a87b:      	movl	$0x4, %eax
    a880:      	callq	*%rax
    a882:      	movq	%rbx, 0x48(%rsp)
    a887:      	cmpl	%r15d, %r12d
    a88a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    a890:      	movq	0x8(%rsp), %r12
    a895:      	movq	%r12, 0x30(%rsp)
    a89a:      	movq	0x38(%rsp), %rdx
    a89f:      	movq	0x40(%rsp), %r15
    a8a4:      	cmpq	0x18(%rsp), %r12
    a8a9:      	je	0xa905 <generic_rawtp_path+0x625>
    a8ab:      	jmp	0xa910 <generic_rawtp_path+0x630>
    a8ad:      	leaq	0x10(%r15), %rdx
    a8b1:      	movl	$0x4, %eax
    a8b6:      	movq	%rbp, %rdi
    a8b9:      	movl	$0x8, %esi
    a8be:      	callq	*%rax
    a8c0:      	movq	0x40(%rsp), %rax
    a8c5:      	cmpq	(%rsp), %rax
    a8c9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a8cf:      	addq	$0x18, %r15
    a8d3:      	movl	$0x4, %eax
    a8d8:      	leaq	0x30(%rsp), %rdi
    a8dd:      	movl	$0x8, %esi
    a8e2:      	movq	%r15, %rdx
    a8e5:      	callq	*%rax
    a8e7:      	movq	(%rsp), %r15
    a8eb:      	movq	%r15, 0x40(%rsp)
    a8f0:      	leaq	0x20(%r15), %rdx
    a8f4:      	movq	%rdx, 0x38(%rsp)
    a8f9:      	movq	0x30(%rsp), %r12
    a8fe:      	cmpq	0x18(%rsp), %r12
    a903:      	jne	0xa910 <generic_rawtp_path+0x630>
    a905:      	cmpq	0x20(%rsp), %rdx
    a90a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    a910:      	movl	$0x4, %eax
    a915:      	leaq	0x10(%rsp), %rdi
    a91a:      	movl	$0x8, %esi
    a91f:      	callq	*%rax
    a921:      	cmpq	0x10(%rsp), %r12
    a926:      	je	0xaa25 <generic_rawtp_path+0x745>
    a92c:      	leaq	0x18(%r12), %rbx
    a931:      	movl	$0x4, %eax
    a936:      	movq	%rbp, %rdi
    a939:      	movl	$0x8, %esi
    a93e:      	movq	%rbx, %rdx
    a941:      	callq	*%rax
    a943:      	cmpq	%r12, (%rsp)
    a947:      	je	0xaa25 <generic_rawtp_path+0x745>
    a94d:      	movl	$0x4, %eax
    a952:      	leaq	0x8(%rsp), %rdi
    a957:      	movl	$0x8, %esi
    a95c:      	movq	%rbx, %rdx
    a95f:      	callq	*%rax
    a961:      	addq	$0x20, %r12
    a965:      	movl	$0x4, %eax
    a96a:      	leaq	0x58(%rsp), %rdi
    a96f:      	movl	$0x10, %ecx
    a974:      	movl	$0x10, %esi
    a979:      	movq	%r12, %rdx
    a97c:      	callq	*%rax
    a97e:      	movq	0x28(%rsp), %rbx
    a983:      	movq	0x48(%rsp), %rax
    a988:      	movl	0x5c(%rsp), %r15d
    a98d:      	subq	%rbx, %rax
    a990:      	movl	0x50(%rsp), %r12d
    a995:      	movl	%r15d, %edx
    a998:      	subl	%r12d, %edx
    a99b:      	movl	$0x0, %ecx
    a9a0:      	cmovbl	%ecx, %edx
    a9a3:      	addq	0x60(%rsp), %rdx
    a9a8:      	xorl	%esi, %esi
    a9aa:      	cmpl	%r15d, %r12d
    a9ad:      	seta	%sil
    a9b1:      	movl	%r15d, %ecx
    a9b4:      	cmovbl	%r12d, %ecx
    a9b8:      	addl	%ecx, %esi
    a9ba:      	movl	%r12d, %edi
    a9bd:      	subl	%esi, %edi
    a9bf:      	movl	%edi, 0x50(%rsp)
    a9c3:      	subq	%rsi, %rax
    a9c6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    a9cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    a9d2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    a9d8:      	cmpl	%r15d, %r12d
    a9db:      	jbe	0xa9e1 <generic_rawtp_path+0x701>
    a9dd:      	movb	$0x2f, (%rbx,%rax)
    a9e1:      	xorl	%edi, %edi
    a9e3:      	cmpl	%r15d, %r12d
    a9e6:      	seta	%dil
    a9ea:      	movzbl	%cl, %esi
    a9ed:      	addq	%rax, %rbx
    a9f0:      	addq	%rbx, %rdi
    a9f3:      	movl	$0x4, %eax
    a9f8:      	callq	*%rax
    a9fa:      	movq	%rbx, 0x48(%rsp)
    a9ff:      	cmpl	%r15d, %r12d
    aa02:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    aa08:      	movq	0x8(%rsp), %r12
    aa0d:      	movq	%r12, 0x30(%rsp)
    aa12:      	movq	0x38(%rsp), %rdx
    aa17:      	movq	0x40(%rsp), %r15
    aa1c:      	cmpq	0x18(%rsp), %r12
    aa21:      	je	0xaa7d <generic_rawtp_path+0x79d>
    aa23:      	jmp	0xaa88 <generic_rawtp_path+0x7a8>
    aa25:      	leaq	0x10(%r15), %rdx
    aa29:      	movl	$0x4, %eax
    aa2e:      	movq	%rbp, %rdi
    aa31:      	movl	$0x8, %esi
    aa36:      	callq	*%rax
    aa38:      	movq	0x40(%rsp), %rax
    aa3d:      	cmpq	(%rsp), %rax
    aa41:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    aa47:      	addq	$0x18, %r15
    aa4b:      	movl	$0x4, %eax
    aa50:      	leaq	0x30(%rsp), %rdi
    aa55:      	movl	$0x8, %esi
    aa5a:      	movq	%r15, %rdx
    aa5d:      	callq	*%rax
    aa5f:      	movq	(%rsp), %r15
    aa63:      	movq	%r15, 0x40(%rsp)
    aa68:      	leaq	0x20(%r15), %rdx
    aa6c:      	movq	%rdx, 0x38(%rsp)
    aa71:      	movq	0x30(%rsp), %r12
    aa76:      	cmpq	0x18(%rsp), %r12
    aa7b:      	jne	0xaa88 <generic_rawtp_path+0x7a8>
    aa7d:      	cmpq	0x20(%rsp), %rdx
    aa82:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    aa88:      	movl	$0x4, %eax
    aa8d:      	leaq	0x10(%rsp), %rdi
    aa92:      	movl	$0x8, %esi
    aa97:      	callq	*%rax
    aa99:      	cmpq	0x10(%rsp), %r12
    aa9e:      	je	0xab9d <generic_rawtp_path+0x8bd>
    aaa4:      	leaq	0x18(%r12), %rbx
    aaa9:      	movl	$0x4, %eax
    aaae:      	movq	%rbp, %rdi
    aab1:      	movl	$0x8, %esi
    aab6:      	movq	%rbx, %rdx
    aab9:      	callq	*%rax
    aabb:      	cmpq	%r12, (%rsp)
    aabf:      	je	0xab9d <generic_rawtp_path+0x8bd>
    aac5:      	movl	$0x4, %eax
    aaca:      	leaq	0x8(%rsp), %rdi
    aacf:      	movl	$0x8, %esi
    aad4:      	movq	%rbx, %rdx
    aad7:      	callq	*%rax
    aad9:      	addq	$0x20, %r12
    aadd:      	movl	$0x4, %eax
    aae2:      	leaq	0x58(%rsp), %rdi
    aae7:      	movl	$0x10, %ecx
    aaec:      	movl	$0x10, %esi
    aaf1:      	movq	%r12, %rdx
    aaf4:      	callq	*%rax
    aaf6:      	movq	0x28(%rsp), %rbx
    aafb:      	movq	0x48(%rsp), %rax
    ab00:      	movl	0x5c(%rsp), %r15d
    ab05:      	subq	%rbx, %rax
    ab08:      	movl	0x50(%rsp), %r12d
    ab0d:      	movl	%r15d, %edx
    ab10:      	subl	%r12d, %edx
    ab13:      	movl	$0x0, %ecx
    ab18:      	cmovbl	%ecx, %edx
    ab1b:      	addq	0x60(%rsp), %rdx
    ab20:      	xorl	%esi, %esi
    ab22:      	cmpl	%r15d, %r12d
    ab25:      	seta	%sil
    ab29:      	movl	%r15d, %ecx
    ab2c:      	cmovbl	%r12d, %ecx
    ab30:      	addl	%ecx, %esi
    ab32:      	movl	%r12d, %edi
    ab35:      	subl	%esi, %edi
    ab37:      	movl	%edi, 0x50(%rsp)
    ab3b:      	subq	%rsi, %rax
    ab3e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ab44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ab4a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    ab50:      	cmpl	%r15d, %r12d
    ab53:      	jbe	0xab59 <generic_rawtp_path+0x879>
    ab55:      	movb	$0x2f, (%rbx,%rax)
    ab59:      	xorl	%edi, %edi
    ab5b:      	cmpl	%r15d, %r12d
    ab5e:      	seta	%dil
    ab62:      	movzbl	%cl, %esi
    ab65:      	addq	%rax, %rbx
    ab68:      	addq	%rbx, %rdi
    ab6b:      	movl	$0x4, %eax
    ab70:      	callq	*%rax
    ab72:      	movq	%rbx, 0x48(%rsp)
    ab77:      	cmpl	%r15d, %r12d
    ab7a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ab80:      	movq	0x8(%rsp), %r12
    ab85:      	movq	%r12, 0x30(%rsp)
    ab8a:      	movq	0x38(%rsp), %rdx
    ab8f:      	movq	0x40(%rsp), %r15
    ab94:      	cmpq	0x18(%rsp), %r12
    ab99:      	je	0xabf5 <generic_rawtp_path+0x915>
    ab9b:      	jmp	0xac00 <generic_rawtp_path+0x920>
    ab9d:      	leaq	0x10(%r15), %rdx
    aba1:      	movl	$0x4, %eax
    aba6:      	movq	%rbp, %rdi
    aba9:      	movl	$0x8, %esi
    abae:      	callq	*%rax
    abb0:      	movq	0x40(%rsp), %rax
    abb5:      	cmpq	(%rsp), %rax
    abb9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    abbf:      	addq	$0x18, %r15
    abc3:      	movl	$0x4, %eax
    abc8:      	leaq	0x30(%rsp), %rdi
    abcd:      	movl	$0x8, %esi
    abd2:      	movq	%r15, %rdx
    abd5:      	callq	*%rax
    abd7:      	movq	(%rsp), %r15
    abdb:      	movq	%r15, 0x40(%rsp)
    abe0:      	leaq	0x20(%r15), %rdx
    abe4:      	movq	%rdx, 0x38(%rsp)
    abe9:      	movq	0x30(%rsp), %r12
    abee:      	cmpq	0x18(%rsp), %r12
    abf3:      	jne	0xac00 <generic_rawtp_path+0x920>
    abf5:      	cmpq	0x20(%rsp), %rdx
    abfa:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ac00:      	movl	$0x4, %eax
    ac05:      	leaq	0x10(%rsp), %rdi
    ac0a:      	movl	$0x8, %esi
    ac0f:      	callq	*%rax
    ac11:      	cmpq	0x10(%rsp), %r12
    ac16:      	je	0xad15 <generic_rawtp_path+0xa35>
    ac1c:      	leaq	0x18(%r12), %rbx
    ac21:      	movl	$0x4, %eax
    ac26:      	movq	%rbp, %rdi
    ac29:      	movl	$0x8, %esi
    ac2e:      	movq	%rbx, %rdx
    ac31:      	callq	*%rax
    ac33:      	cmpq	%r12, (%rsp)
    ac37:      	je	0xad15 <generic_rawtp_path+0xa35>
    ac3d:      	movl	$0x4, %eax
    ac42:      	leaq	0x8(%rsp), %rdi
    ac47:      	movl	$0x8, %esi
    ac4c:      	movq	%rbx, %rdx
    ac4f:      	callq	*%rax
    ac51:      	addq	$0x20, %r12
    ac55:      	movl	$0x4, %eax
    ac5a:      	leaq	0x58(%rsp), %rdi
    ac5f:      	movl	$0x10, %ecx
    ac64:      	movl	$0x10, %esi
    ac69:      	movq	%r12, %rdx
    ac6c:      	callq	*%rax
    ac6e:      	movq	0x28(%rsp), %rbx
    ac73:      	movq	0x48(%rsp), %rax
    ac78:      	movl	0x5c(%rsp), %r15d
    ac7d:      	subq	%rbx, %rax
    ac80:      	movl	0x50(%rsp), %r12d
    ac85:      	movl	%r15d, %edx
    ac88:      	subl	%r12d, %edx
    ac8b:      	movl	$0x0, %ecx
    ac90:      	cmovbl	%ecx, %edx
    ac93:      	addq	0x60(%rsp), %rdx
    ac98:      	xorl	%esi, %esi
    ac9a:      	cmpl	%r15d, %r12d
    ac9d:      	seta	%sil
    aca1:      	movl	%r15d, %ecx
    aca4:      	cmovbl	%r12d, %ecx
    aca8:      	addl	%ecx, %esi
    acaa:      	movl	%r12d, %edi
    acad:      	subl	%esi, %edi
    acaf:      	movl	%edi, 0x50(%rsp)
    acb3:      	subq	%rsi, %rax
    acb6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    acbc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    acc2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    acc8:      	cmpl	%r15d, %r12d
    accb:      	jbe	0xacd1 <generic_rawtp_path+0x9f1>
    accd:      	movb	$0x2f, (%rbx,%rax)
    acd1:      	xorl	%edi, %edi
    acd3:      	cmpl	%r15d, %r12d
    acd6:      	seta	%dil
    acda:      	movzbl	%cl, %esi
    acdd:      	addq	%rax, %rbx
    ace0:      	addq	%rbx, %rdi
    ace3:      	movl	$0x4, %eax
    ace8:      	callq	*%rax
    acea:      	movq	%rbx, 0x48(%rsp)
    acef:      	cmpl	%r15d, %r12d
    acf2:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    acf8:      	movq	0x8(%rsp), %r12
    acfd:      	movq	%r12, 0x30(%rsp)
    ad02:      	movq	0x38(%rsp), %rdx
    ad07:      	movq	0x40(%rsp), %r15
    ad0c:      	cmpq	0x18(%rsp), %r12
    ad11:      	je	0xad6d <generic_rawtp_path+0xa8d>
    ad13:      	jmp	0xad78 <generic_rawtp_path+0xa98>
    ad15:      	leaq	0x10(%r15), %rdx
    ad19:      	movl	$0x4, %eax
    ad1e:      	movq	%rbp, %rdi
    ad21:      	movl	$0x8, %esi
    ad26:      	callq	*%rax
    ad28:      	movq	0x40(%rsp), %rax
    ad2d:      	cmpq	(%rsp), %rax
    ad31:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ad37:      	addq	$0x18, %r15
    ad3b:      	movl	$0x4, %eax
    ad40:      	leaq	0x30(%rsp), %rdi
    ad45:      	movl	$0x8, %esi
    ad4a:      	movq	%r15, %rdx
    ad4d:      	callq	*%rax
    ad4f:      	movq	(%rsp), %r15
    ad53:      	movq	%r15, 0x40(%rsp)
    ad58:      	leaq	0x20(%r15), %rdx
    ad5c:      	movq	%rdx, 0x38(%rsp)
    ad61:      	movq	0x30(%rsp), %r12
    ad66:      	cmpq	0x18(%rsp), %r12
    ad6b:      	jne	0xad78 <generic_rawtp_path+0xa98>
    ad6d:      	cmpq	0x20(%rsp), %rdx
    ad72:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ad78:      	movl	$0x4, %eax
    ad7d:      	leaq	0x10(%rsp), %rdi
    ad82:      	movl	$0x8, %esi
    ad87:      	callq	*%rax
    ad89:      	cmpq	0x10(%rsp), %r12
    ad8e:      	je	0xae8d <generic_rawtp_path+0xbad>
    ad94:      	leaq	0x18(%r12), %rbx
    ad99:      	movl	$0x4, %eax
    ad9e:      	movq	%rbp, %rdi
    ada1:      	movl	$0x8, %esi
    ada6:      	movq	%rbx, %rdx
    ada9:      	callq	*%rax
    adab:      	cmpq	%r12, (%rsp)
    adaf:      	je	0xae8d <generic_rawtp_path+0xbad>
    adb5:      	movl	$0x4, %eax
    adba:      	leaq	0x8(%rsp), %rdi
    adbf:      	movl	$0x8, %esi
    adc4:      	movq	%rbx, %rdx
    adc7:      	callq	*%rax
    adc9:      	addq	$0x20, %r12
    adcd:      	movl	$0x4, %eax
    add2:      	leaq	0x58(%rsp), %rdi
    add7:      	movl	$0x10, %ecx
    addc:      	movl	$0x10, %esi
    ade1:      	movq	%r12, %rdx
    ade4:      	callq	*%rax
    ade6:      	movq	0x28(%rsp), %rbx
    adeb:      	movq	0x48(%rsp), %rax
    adf0:      	movl	0x5c(%rsp), %r15d
    adf5:      	subq	%rbx, %rax
    adf8:      	movl	0x50(%rsp), %r12d
    adfd:      	movl	%r15d, %edx
    ae00:      	subl	%r12d, %edx
    ae03:      	movl	$0x0, %ecx
    ae08:      	cmovbl	%ecx, %edx
    ae0b:      	addq	0x60(%rsp), %rdx
    ae10:      	xorl	%esi, %esi
    ae12:      	cmpl	%r15d, %r12d
    ae15:      	seta	%sil
    ae19:      	movl	%r15d, %ecx
    ae1c:      	cmovbl	%r12d, %ecx
    ae20:      	addl	%ecx, %esi
    ae22:      	movl	%r12d, %edi
    ae25:      	subl	%esi, %edi
    ae27:      	movl	%edi, 0x50(%rsp)
    ae2b:      	subq	%rsi, %rax
    ae2e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ae34:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ae3a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    ae40:      	cmpl	%r15d, %r12d
    ae43:      	jbe	0xae49 <generic_rawtp_path+0xb69>
    ae45:      	movb	$0x2f, (%rbx,%rax)
    ae49:      	xorl	%edi, %edi
    ae4b:      	cmpl	%r15d, %r12d
    ae4e:      	seta	%dil
    ae52:      	movzbl	%cl, %esi
    ae55:      	addq	%rax, %rbx
    ae58:      	addq	%rbx, %rdi
    ae5b:      	movl	$0x4, %eax
    ae60:      	callq	*%rax
    ae62:      	movq	%rbx, 0x48(%rsp)
    ae67:      	cmpl	%r15d, %r12d
    ae6a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ae70:      	movq	0x8(%rsp), %r12
    ae75:      	movq	%r12, 0x30(%rsp)
    ae7a:      	movq	0x38(%rsp), %rdx
    ae7f:      	movq	0x40(%rsp), %r15
    ae84:      	cmpq	0x18(%rsp), %r12
    ae89:      	je	0xaee5 <generic_rawtp_path+0xc05>
    ae8b:      	jmp	0xaef0 <generic_rawtp_path+0xc10>
    ae8d:      	leaq	0x10(%r15), %rdx
    ae91:      	movl	$0x4, %eax
    ae96:      	movq	%rbp, %rdi
    ae99:      	movl	$0x8, %esi
    ae9e:      	callq	*%rax
    aea0:      	movq	0x40(%rsp), %rax
    aea5:      	cmpq	(%rsp), %rax
    aea9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    aeaf:      	addq	$0x18, %r15
    aeb3:      	movl	$0x4, %eax
    aeb8:      	leaq	0x30(%rsp), %rdi
    aebd:      	movl	$0x8, %esi
    aec2:      	movq	%r15, %rdx
    aec5:      	callq	*%rax
    aec7:      	movq	(%rsp), %r15
    aecb:      	movq	%r15, 0x40(%rsp)
    aed0:      	leaq	0x20(%r15), %rdx
    aed4:      	movq	%rdx, 0x38(%rsp)
    aed9:      	movq	0x30(%rsp), %r12
    aede:      	cmpq	0x18(%rsp), %r12
    aee3:      	jne	0xaef0 <generic_rawtp_path+0xc10>
    aee5:      	cmpq	0x20(%rsp), %rdx
    aeea:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    aef0:      	movl	$0x4, %eax
    aef5:      	leaq	0x10(%rsp), %rdi
    aefa:      	movl	$0x8, %esi
    aeff:      	callq	*%rax
    af01:      	cmpq	0x10(%rsp), %r12
    af06:      	je	0xb005 <generic_rawtp_path+0xd25>
    af0c:      	leaq	0x18(%r12), %rbx
    af11:      	movl	$0x4, %eax
    af16:      	movq	%rbp, %rdi
    af19:      	movl	$0x8, %esi
    af1e:      	movq	%rbx, %rdx
    af21:      	callq	*%rax
    af23:      	cmpq	%r12, (%rsp)
    af27:      	je	0xb005 <generic_rawtp_path+0xd25>
    af2d:      	movl	$0x4, %eax
    af32:      	leaq	0x8(%rsp), %rdi
    af37:      	movl	$0x8, %esi
    af3c:      	movq	%rbx, %rdx
    af3f:      	callq	*%rax
    af41:      	addq	$0x20, %r12
    af45:      	movl	$0x4, %eax
    af4a:      	leaq	0x58(%rsp), %rdi
    af4f:      	movl	$0x10, %ecx
    af54:      	movl	$0x10, %esi
    af59:      	movq	%r12, %rdx
    af5c:      	callq	*%rax
    af5e:      	movq	0x28(%rsp), %rbx
    af63:      	movq	0x48(%rsp), %rax
    af68:      	movl	0x5c(%rsp), %r15d
    af6d:      	subq	%rbx, %rax
    af70:      	movl	0x50(%rsp), %r12d
    af75:      	movl	%r15d, %edx
    af78:      	subl	%r12d, %edx
    af7b:      	movl	$0x0, %ecx
    af80:      	cmovbl	%ecx, %edx
    af83:      	addq	0x60(%rsp), %rdx
    af88:      	xorl	%esi, %esi
    af8a:      	cmpl	%r15d, %r12d
    af8d:      	seta	%sil
    af91:      	movl	%r15d, %ecx
    af94:      	cmovbl	%r12d, %ecx
    af98:      	addl	%ecx, %esi
    af9a:      	movl	%r12d, %edi
    af9d:      	subl	%esi, %edi
    af9f:      	movl	%edi, 0x50(%rsp)
    afa3:      	subq	%rsi, %rax
    afa6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    afac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    afb2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    afb8:      	cmpl	%r15d, %r12d
    afbb:      	jbe	0xafc1 <generic_rawtp_path+0xce1>
    afbd:      	movb	$0x2f, (%rbx,%rax)
    afc1:      	xorl	%edi, %edi
    afc3:      	cmpl	%r15d, %r12d
    afc6:      	seta	%dil
    afca:      	movzbl	%cl, %esi
    afcd:      	addq	%rax, %rbx
    afd0:      	addq	%rbx, %rdi
    afd3:      	movl	$0x4, %eax
    afd8:      	callq	*%rax
    afda:      	movq	%rbx, 0x48(%rsp)
    afdf:      	cmpl	%r15d, %r12d
    afe2:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    afe8:      	movq	0x8(%rsp), %r12
    afed:      	movq	%r12, 0x30(%rsp)
    aff2:      	movq	0x38(%rsp), %rdx
    aff7:      	movq	0x40(%rsp), %r15
    affc:      	cmpq	0x18(%rsp), %r12
    b001:      	je	0xb05d <generic_rawtp_path+0xd7d>
    b003:      	jmp	0xb068 <generic_rawtp_path+0xd88>
    b005:      	leaq	0x10(%r15), %rdx
    b009:      	movl	$0x4, %eax
    b00e:      	movq	%rbp, %rdi
    b011:      	movl	$0x8, %esi
    b016:      	callq	*%rax
    b018:      	movq	0x40(%rsp), %rax
    b01d:      	cmpq	(%rsp), %rax
    b021:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b027:      	addq	$0x18, %r15
    b02b:      	movl	$0x4, %eax
    b030:      	leaq	0x30(%rsp), %rdi
    b035:      	movl	$0x8, %esi
    b03a:      	movq	%r15, %rdx
    b03d:      	callq	*%rax
    b03f:      	movq	(%rsp), %r15
    b043:      	movq	%r15, 0x40(%rsp)
    b048:      	leaq	0x20(%r15), %rdx
    b04c:      	movq	%rdx, 0x38(%rsp)
    b051:      	movq	0x30(%rsp), %r12
    b056:      	cmpq	0x18(%rsp), %r12
    b05b:      	jne	0xb068 <generic_rawtp_path+0xd88>
    b05d:      	cmpq	0x20(%rsp), %rdx
    b062:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b068:      	movl	$0x4, %eax
    b06d:      	leaq	0x10(%rsp), %rdi
    b072:      	movl	$0x8, %esi
    b077:      	callq	*%rax
    b079:      	cmpq	0x10(%rsp), %r12
    b07e:      	je	0xb17d <generic_rawtp_path+0xe9d>
    b084:      	leaq	0x18(%r12), %rbx
    b089:      	movl	$0x4, %eax
    b08e:      	movq	%rbp, %rdi
    b091:      	movl	$0x8, %esi
    b096:      	movq	%rbx, %rdx
    b099:      	callq	*%rax
    b09b:      	cmpq	%r12, (%rsp)
    b09f:      	je	0xb17d <generic_rawtp_path+0xe9d>
    b0a5:      	movl	$0x4, %eax
    b0aa:      	leaq	0x8(%rsp), %rdi
    b0af:      	movl	$0x8, %esi
    b0b4:      	movq	%rbx, %rdx
    b0b7:      	callq	*%rax
    b0b9:      	addq	$0x20, %r12
    b0bd:      	movl	$0x4, %eax
    b0c2:      	leaq	0x58(%rsp), %rdi
    b0c7:      	movl	$0x10, %ecx
    b0cc:      	movl	$0x10, %esi
    b0d1:      	movq	%r12, %rdx
    b0d4:      	callq	*%rax
    b0d6:      	movq	0x28(%rsp), %rbx
    b0db:      	movq	0x48(%rsp), %rax
    b0e0:      	movl	0x5c(%rsp), %r15d
    b0e5:      	subq	%rbx, %rax
    b0e8:      	movl	0x50(%rsp), %r12d
    b0ed:      	movl	%r15d, %edx
    b0f0:      	subl	%r12d, %edx
    b0f3:      	movl	$0x0, %ecx
    b0f8:      	cmovbl	%ecx, %edx
    b0fb:      	addq	0x60(%rsp), %rdx
    b100:      	xorl	%esi, %esi
    b102:      	cmpl	%r15d, %r12d
    b105:      	seta	%sil
    b109:      	movl	%r15d, %ecx
    b10c:      	cmovbl	%r12d, %ecx
    b110:      	addl	%ecx, %esi
    b112:      	movl	%r12d, %edi
    b115:      	subl	%esi, %edi
    b117:      	movl	%edi, 0x50(%rsp)
    b11b:      	subq	%rsi, %rax
    b11e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b124:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b12a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b130:      	cmpl	%r15d, %r12d
    b133:      	jbe	0xb139 <generic_rawtp_path+0xe59>
    b135:      	movb	$0x2f, (%rbx,%rax)
    b139:      	xorl	%edi, %edi
    b13b:      	cmpl	%r15d, %r12d
    b13e:      	seta	%dil
    b142:      	movzbl	%cl, %esi
    b145:      	addq	%rax, %rbx
    b148:      	addq	%rbx, %rdi
    b14b:      	movl	$0x4, %eax
    b150:      	callq	*%rax
    b152:      	movq	%rbx, 0x48(%rsp)
    b157:      	cmpl	%r15d, %r12d
    b15a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    b160:      	movq	0x8(%rsp), %r12
    b165:      	movq	%r12, 0x30(%rsp)
    b16a:      	movq	0x38(%rsp), %rdx
    b16f:      	movq	0x40(%rsp), %r15
    b174:      	cmpq	0x18(%rsp), %r12
    b179:      	je	0xb1d5 <generic_rawtp_path+0xef5>
    b17b:      	jmp	0xb1e0 <generic_rawtp_path+0xf00>
    b17d:      	leaq	0x10(%r15), %rdx
    b181:      	movl	$0x4, %eax
    b186:      	movq	%rbp, %rdi
    b189:      	movl	$0x8, %esi
    b18e:      	callq	*%rax
    b190:      	movq	0x40(%rsp), %rax
    b195:      	cmpq	(%rsp), %rax
    b199:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b19f:      	addq	$0x18, %r15
    b1a3:      	movl	$0x4, %eax
    b1a8:      	leaq	0x30(%rsp), %rdi
    b1ad:      	movl	$0x8, %esi
    b1b2:      	movq	%r15, %rdx
    b1b5:      	callq	*%rax
    b1b7:      	movq	(%rsp), %r15
    b1bb:      	movq	%r15, 0x40(%rsp)
    b1c0:      	leaq	0x20(%r15), %rdx
    b1c4:      	movq	%rdx, 0x38(%rsp)
    b1c9:      	movq	0x30(%rsp), %r12
    b1ce:      	cmpq	0x18(%rsp), %r12
    b1d3:      	jne	0xb1e0 <generic_rawtp_path+0xf00>
    b1d5:      	cmpq	0x20(%rsp), %rdx
    b1da:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b1e0:      	movl	$0x4, %eax
    b1e5:      	leaq	0x10(%rsp), %rdi
    b1ea:      	movl	$0x8, %esi
    b1ef:      	callq	*%rax
    b1f1:      	cmpq	0x10(%rsp), %r12
    b1f6:      	je	0xb2ee <generic_rawtp_path+0x100e>
    b1fc:      	leaq	0x18(%r12), %rbx
    b201:      	movl	$0x4, %eax
    b206:      	movq	%rbp, %rdi
    b209:      	movl	$0x8, %esi
    b20e:      	movq	%rbx, %rdx
    b211:      	callq	*%rax
    b213:      	cmpq	%r12, (%rsp)
    b217:      	je	0xb2ee <generic_rawtp_path+0x100e>
    b21d:      	movl	$0x4, %eax
    b222:      	leaq	0x8(%rsp), %rdi
    b227:      	movl	$0x8, %esi
    b22c:      	movq	%rbx, %rdx
    b22f:      	callq	*%rax
    b231:      	addq	$0x20, %r12
    b235:      	movl	$0x4, %eax
    b23a:      	leaq	0x58(%rsp), %rdi
    b23f:      	movl	$0x10, %ecx
    b244:      	movl	$0x10, %esi
    b249:      	movq	%r12, %rdx
    b24c:      	callq	*%rax
    b24e:      	movq	0x28(%rsp), %rbx
    b253:      	movq	0x48(%rsp), %rax
    b258:      	movl	0x5c(%rsp), %r15d
    b25d:      	subq	%rbx, %rax
    b260:      	movl	0x50(%rsp), %r12d
    b265:      	movl	%r15d, %edx
    b268:      	subl	%r12d, %edx
    b26b:      	movl	$0x0, %ecx
    b270:      	cmovbl	%ecx, %edx
    b273:      	addq	0x60(%rsp), %rdx
    b278:      	xorl	%esi, %esi
    b27a:      	cmpl	%r15d, %r12d
    b27d:      	seta	%sil
    b281:      	movl	%r15d, %ecx
    b284:      	cmovbl	%r12d, %ecx
    b288:      	addl	%ecx, %esi
    b28a:      	movl	%r12d, %edi
    b28d:      	subl	%esi, %edi
    b28f:      	movl	%edi, 0x50(%rsp)
    b293:      	subq	%rsi, %rax
    b296:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b29c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b2a2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b2a8:      	cmpl	%r15d, %r12d
    b2ab:      	jbe	0xb2b1 <generic_rawtp_path+0xfd1>
    b2ad:      	movb	$0x2f, (%rbx,%rax)
    b2b1:      	xorl	%edi, %edi
    b2b3:      	cmpl	%r15d, %r12d
    b2b6:      	seta	%dil
    b2ba:      	movzbl	%cl, %esi
    b2bd:      	addq	%rax, %rbx
    b2c0:      	addq	%rbx, %rdi
    b2c3:      	movl	$0x4, %eax
    b2c8:      	callq	*%rax
    b2ca:      	movq	%rbx, 0x48(%rsp)
    b2cf:      	cmpl	%r15d, %r12d
    b2d2:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    b2d8:      	movq	0x8(%rsp), %r12
    b2dd:      	movq	%r12, 0x30(%rsp)
    b2e2:      	movq	0x38(%rsp), %rdx
    b2e7:      	movq	0x40(%rsp), %r15
    b2ec:      	jmp	0xb33f <generic_rawtp_path+0x105f>
    b2ee:      	leaq	0x10(%r15), %rdx
    b2f2:      	movl	$0x4, %eax
    b2f7:      	movq	%rbp, %rdi
    b2fa:      	movl	$0x8, %esi
    b2ff:      	callq	*%rax
    b301:      	movq	0x40(%rsp), %rax
    b306:      	cmpq	(%rsp), %rax
    b30a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b310:      	addq	$0x18, %r15
    b314:      	movl	$0x4, %eax
    b319:      	leaq	0x30(%rsp), %rdi
    b31e:      	movl	$0x8, %esi
    b323:      	movq	%r15, %rdx
    b326:      	callq	*%rax
    b328:      	movq	(%rsp), %r15
    b32c:      	movq	%r15, 0x40(%rsp)
    b331:      	leaq	0x20(%r15), %rdx
    b335:      	movq	%rdx, 0x38(%rsp)
    b33a:      	movq	0x30(%rsp), %r12
    b33f:      	cmpq	0x18(%rsp), %r12
    b344:      	jne	0xb351 <generic_rawtp_path+0x1071>
    b346:      	cmpq	0x20(%rsp), %rdx
    b34b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b351:      	movl	$0x4, %eax
    b356:      	leaq	0x10(%rsp), %rdi
    b35b:      	movl	$0x8, %esi
    b360:      	callq	*%rax
    b362:      	cmpq	0x10(%rsp), %r12
    b367:      	je	0xb45f <generic_rawtp_path+0x117f>
    b36d:      	leaq	0x18(%r12), %rbx
    b372:      	movl	$0x4, %eax
    b377:      	movq	%rbp, %rdi
    b37a:      	movl	$0x8, %esi
    b37f:      	movq	%rbx, %rdx
    b382:      	callq	*%rax
    b384:      	cmpq	%r12, (%rsp)
    b388:      	je	0xb45f <generic_rawtp_path+0x117f>
    b38e:      	movl	$0x4, %eax
    b393:      	leaq	0x8(%rsp), %rdi
    b398:      	movl	$0x8, %esi
    b39d:      	movq	%rbx, %rdx
    b3a0:      	callq	*%rax
    b3a2:      	addq	$0x20, %r12
    b3a6:      	movl	$0x4, %eax
    b3ab:      	leaq	0x58(%rsp), %rdi
    b3b0:      	movl	$0x10, %ecx
    b3b5:      	movl	$0x10, %esi
    b3ba:      	movq	%r12, %rdx
    b3bd:      	callq	*%rax
    b3bf:      	movq	0x28(%rsp), %rbx
    b3c4:      	movq	0x48(%rsp), %rax
    b3c9:      	movl	0x5c(%rsp), %r15d
    b3ce:      	subq	%rbx, %rax
    b3d1:      	movl	0x50(%rsp), %r12d
    b3d6:      	movl	%r15d, %edx
    b3d9:      	subl	%r12d, %edx
    b3dc:      	movl	$0x0, %ecx
    b3e1:      	cmovbl	%ecx, %edx
    b3e4:      	addq	0x60(%rsp), %rdx
    b3e9:      	xorl	%esi, %esi
    b3eb:      	cmpl	%r15d, %r12d
    b3ee:      	seta	%sil
    b3f2:      	movl	%r15d, %ecx
    b3f5:      	cmovbl	%r12d, %ecx
    b3f9:      	addl	%ecx, %esi
    b3fb:      	movl	%r12d, %edi
    b3fe:      	subl	%esi, %edi
    b400:      	movl	%edi, 0x50(%rsp)
    b404:      	subq	%rsi, %rax
    b407:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b40d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b413:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b419:      	cmpl	%r15d, %r12d
    b41c:      	jbe	0xb422 <generic_rawtp_path+0x1142>
    b41e:      	movb	$0x2f, (%rbx,%rax)
    b422:      	xorl	%edi, %edi
    b424:      	cmpl	%r15d, %r12d
    b427:      	seta	%dil
    b42b:      	movzbl	%cl, %esi
    b42e:      	addq	%rax, %rbx
    b431:      	addq	%rbx, %rdi
    b434:      	movl	$0x4, %eax
    b439:      	callq	*%rax
    b43b:      	movq	%rbx, 0x48(%rsp)
    b440:      	cmpl	%r15d, %r12d
    b443:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    b449:      	movq	0x8(%rsp), %r12
    b44e:      	movq	%r12, 0x30(%rsp)
    b453:      	movq	0x38(%rsp), %rdx
    b458:      	movq	0x40(%rsp), %r15
    b45d:      	jmp	0xb4b0 <generic_rawtp_path+0x11d0>
    b45f:      	leaq	0x10(%r15), %rdx
    b463:      	movl	$0x4, %eax
    b468:      	movq	%rbp, %rdi
    b46b:      	movl	$0x8, %esi
    b470:      	callq	*%rax
    b472:      	movq	0x40(%rsp), %rax
    b477:      	cmpq	(%rsp), %rax
    b47b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b481:      	addq	$0x18, %r15
    b485:      	movl	$0x4, %eax
    b48a:      	leaq	0x30(%rsp), %rdi
    b48f:      	movl	$0x8, %esi
    b494:      	movq	%r15, %rdx
    b497:      	callq	*%rax
    b499:      	movq	(%rsp), %r15
    b49d:      	movq	%r15, 0x40(%rsp)
    b4a2:      	leaq	0x20(%r15), %rdx
    b4a6:      	movq	%rdx, 0x38(%rsp)
    b4ab:      	movq	0x30(%rsp), %r12
    b4b0:      	cmpq	0x18(%rsp), %r12
    b4b5:      	jne	0xb4c2 <generic_rawtp_path+0x11e2>
    b4b7:      	cmpq	0x20(%rsp), %rdx
    b4bc:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b4c2:      	movl	$0x4, %eax
    b4c7:      	leaq	0x10(%rsp), %rdi
    b4cc:      	movl	$0x8, %esi
    b4d1:      	callq	*%rax
    b4d3:      	cmpq	0x10(%rsp), %r12
    b4d8:      	je	0xb5d0 <generic_rawtp_path+0x12f0>
    b4de:      	leaq	0x18(%r12), %rbx
    b4e3:      	movl	$0x4, %eax
    b4e8:      	movq	%rbp, %rdi
    b4eb:      	movl	$0x8, %esi
    b4f0:      	movq	%rbx, %rdx
    b4f3:      	callq	*%rax
    b4f5:      	cmpq	%r12, (%rsp)
    b4f9:      	je	0xb5d0 <generic_rawtp_path+0x12f0>
    b4ff:      	movl	$0x4, %eax
    b504:      	leaq	0x8(%rsp), %rdi
    b509:      	movl	$0x8, %esi
    b50e:      	movq	%rbx, %rdx
    b511:      	callq	*%rax
    b513:      	addq	$0x20, %r12
    b517:      	movl	$0x4, %eax
    b51c:      	leaq	0x58(%rsp), %rdi
    b521:      	movl	$0x10, %ecx
    b526:      	movl	$0x10, %esi
    b52b:      	movq	%r12, %rdx
    b52e:      	callq	*%rax
    b530:      	movq	0x28(%rsp), %rbx
    b535:      	movq	0x48(%rsp), %rax
    b53a:      	movl	0x5c(%rsp), %r15d
    b53f:      	subq	%rbx, %rax
    b542:      	movl	0x50(%rsp), %r12d
    b547:      	movl	%r15d, %edx
    b54a:      	subl	%r12d, %edx
    b54d:      	movl	$0x0, %ecx
    b552:      	cmovbl	%ecx, %edx
    b555:      	addq	0x60(%rsp), %rdx
    b55a:      	xorl	%esi, %esi
    b55c:      	cmpl	%r15d, %r12d
    b55f:      	seta	%sil
    b563:      	movl	%r15d, %ecx
    b566:      	cmovbl	%r12d, %ecx
    b56a:      	addl	%ecx, %esi
    b56c:      	movl	%r12d, %edi
    b56f:      	subl	%esi, %edi
    b571:      	movl	%edi, 0x50(%rsp)
    b575:      	subq	%rsi, %rax
    b578:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b57e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b584:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b58a:      	cmpl	%r15d, %r12d
    b58d:      	jbe	0xb593 <generic_rawtp_path+0x12b3>
    b58f:      	movb	$0x2f, (%rbx,%rax)
    b593:      	xorl	%edi, %edi
    b595:      	cmpl	%r15d, %r12d
    b598:      	seta	%dil
    b59c:      	movzbl	%cl, %esi
    b59f:      	addq	%rax, %rbx
    b5a2:      	addq	%rbx, %rdi
    b5a5:      	movl	$0x4, %eax
    b5aa:      	callq	*%rax
    b5ac:      	movq	%rbx, 0x48(%rsp)
    b5b1:      	cmpl	%r15d, %r12d
    b5b4:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    b5ba:      	movq	0x8(%rsp), %r12
    b5bf:      	movq	%r12, 0x30(%rsp)
    b5c4:      	movq	0x38(%rsp), %rdx
    b5c9:      	movq	0x40(%rsp), %r15
    b5ce:      	jmp	0xb621 <generic_rawtp_path+0x1341>
    b5d0:      	leaq	0x10(%r15), %rdx
    b5d4:      	movl	$0x4, %eax
    b5d9:      	movq	%rbp, %rdi
    b5dc:      	movl	$0x8, %esi
    b5e1:      	callq	*%rax
    b5e3:      	movq	0x40(%rsp), %rax
    b5e8:      	cmpq	(%rsp), %rax
    b5ec:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b5f2:      	addq	$0x18, %r15
    b5f6:      	movl	$0x4, %eax
    b5fb:      	leaq	0x30(%rsp), %rdi
    b600:      	movl	$0x8, %esi
    b605:      	movq	%r15, %rdx
    b608:      	callq	*%rax
    b60a:      	movq	(%rsp), %r15
    b60e:      	movq	%r15, 0x40(%rsp)
    b613:      	leaq	0x20(%r15), %rdx
    b617:      	movq	%rdx, 0x38(%rsp)
    b61c:      	movq	0x30(%rsp), %r12
    b621:      	cmpq	0x18(%rsp), %r12
    b626:      	jne	0xb633 <generic_rawtp_path+0x1353>
    b628:      	cmpq	0x20(%rsp), %rdx
    b62d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b633:      	movl	$0x4, %eax
    b638:      	leaq	0x10(%rsp), %rdi
    b63d:      	movl	$0x8, %esi
    b642:      	callq	*%rax
    b644:      	cmpq	0x10(%rsp), %r12
    b649:      	je	0xb741 <generic_rawtp_path+0x1461>
    b64f:      	leaq	0x18(%r12), %rbx
    b654:      	movl	$0x4, %eax
    b659:      	movq	%rbp, %rdi
    b65c:      	movl	$0x8, %esi
    b661:      	movq	%rbx, %rdx
    b664:      	callq	*%rax
    b666:      	cmpq	%r12, (%rsp)
    b66a:      	je	0xb741 <generic_rawtp_path+0x1461>
    b670:      	movl	$0x4, %eax
    b675:      	leaq	0x8(%rsp), %rdi
    b67a:      	movl	$0x8, %esi
    b67f:      	movq	%rbx, %rdx
    b682:      	callq	*%rax
    b684:      	addq	$0x20, %r12
    b688:      	movl	$0x4, %eax
    b68d:      	leaq	0x58(%rsp), %rdi
    b692:      	movl	$0x10, %ecx
    b697:      	movl	$0x10, %esi
    b69c:      	movq	%r12, %rdx
    b69f:      	callq	*%rax
    b6a1:      	movq	0x28(%rsp), %rbx
    b6a6:      	movq	0x48(%rsp), %rax
    b6ab:      	movl	0x5c(%rsp), %r15d
    b6b0:      	subq	%rbx, %rax
    b6b3:      	movl	0x50(%rsp), %r12d
    b6b8:      	movl	%r15d, %edx
    b6bb:      	subl	%r12d, %edx
    b6be:      	movl	$0x0, %ecx
    b6c3:      	cmovbl	%ecx, %edx
    b6c6:      	addq	0x60(%rsp), %rdx
    b6cb:      	xorl	%esi, %esi
    b6cd:      	cmpl	%r15d, %r12d
    b6d0:      	seta	%sil
    b6d4:      	movl	%r15d, %ecx
    b6d7:      	cmovbl	%r12d, %ecx
    b6db:      	addl	%ecx, %esi
    b6dd:      	movl	%r12d, %edi
    b6e0:      	subl	%esi, %edi
    b6e2:      	movl	%edi, 0x50(%rsp)
    b6e6:      	subq	%rsi, %rax
    b6e9:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b6ef:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b6f5:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b6fb:      	cmpl	%r15d, %r12d
    b6fe:      	jbe	0xb704 <generic_rawtp_path+0x1424>
    b700:      	movb	$0x2f, (%rbx,%rax)
    b704:      	xorl	%edi, %edi
    b706:      	cmpl	%r15d, %r12d
    b709:      	seta	%dil
    b70d:      	movzbl	%cl, %esi
    b710:      	addq	%rax, %rbx
    b713:      	addq	%rbx, %rdi
    b716:      	movl	$0x4, %eax
    b71b:      	callq	*%rax
    b71d:      	movq	%rbx, 0x48(%rsp)
    b722:      	cmpl	%r15d, %r12d
    b725:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    b72b:      	movq	0x8(%rsp), %r12
    b730:      	movq	%r12, 0x30(%rsp)
    b735:      	movq	0x38(%rsp), %rdx
    b73a:      	movq	0x40(%rsp), %r15
    b73f:      	jmp	0xb792 <generic_rawtp_path+0x14b2>
    b741:      	leaq	0x10(%r15), %rdx
    b745:      	movl	$0x4, %eax
    b74a:      	movq	%rbp, %rdi
    b74d:      	movl	$0x8, %esi
    b752:      	callq	*%rax
    b754:      	movq	0x40(%rsp), %rax
    b759:      	cmpq	(%rsp), %rax
    b75d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b763:      	addq	$0x18, %r15
    b767:      	movl	$0x4, %eax
    b76c:      	leaq	0x30(%rsp), %rdi
    b771:      	movl	$0x8, %esi
    b776:      	movq	%r15, %rdx
    b779:      	callq	*%rax
    b77b:      	movq	(%rsp), %r15
    b77f:      	movq	%r15, 0x40(%rsp)
    b784:      	leaq	0x20(%r15), %rdx
    b788:      	movq	%rdx, 0x38(%rsp)
    b78d:      	movq	0x30(%rsp), %r12
    b792:      	cmpq	0x18(%rsp), %r12
    b797:      	jne	0xb7a4 <generic_rawtp_path+0x14c4>
    b799:      	cmpq	0x20(%rsp), %rdx
    b79e:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b7a4:      	movl	$0x4, %eax
    b7a9:      	leaq	0x10(%rsp), %rdi
    b7ae:      	movl	$0x8, %esi
    b7b3:      	callq	*%rax
    b7b5:      	cmpq	0x10(%rsp), %r12
    b7ba:      	je	0xb8b2 <generic_rawtp_path+0x15d2>
    b7c0:      	leaq	0x18(%r12), %rbx
    b7c5:      	movl	$0x4, %eax
    b7ca:      	movq	%rbp, %rdi
    b7cd:      	movl	$0x8, %esi
    b7d2:      	movq	%rbx, %rdx
    b7d5:      	callq	*%rax
    b7d7:      	cmpq	%r12, (%rsp)
    b7db:      	je	0xb8b2 <generic_rawtp_path+0x15d2>
    b7e1:      	movl	$0x4, %eax
    b7e6:      	leaq	0x8(%rsp), %rdi
    b7eb:      	movl	$0x8, %esi
    b7f0:      	movq	%rbx, %rdx
    b7f3:      	callq	*%rax
    b7f5:      	addq	$0x20, %r12
    b7f9:      	movl	$0x4, %eax
    b7fe:      	leaq	0x58(%rsp), %rdi
    b803:      	movl	$0x10, %ecx
    b808:      	movl	$0x10, %esi
    b80d:      	movq	%r12, %rdx
    b810:      	callq	*%rax
    b812:      	movq	0x28(%rsp), %rbx
    b817:      	movq	0x48(%rsp), %rax
    b81c:      	movl	0x5c(%rsp), %r15d
    b821:      	subq	%rbx, %rax
    b824:      	movl	0x50(%rsp), %r12d
    b829:      	movl	%r15d, %edx
    b82c:      	subl	%r12d, %edx
    b82f:      	movl	$0x0, %ecx
    b834:      	cmovbl	%ecx, %edx
    b837:      	addq	0x60(%rsp), %rdx
    b83c:      	xorl	%esi, %esi
    b83e:      	cmpl	%r15d, %r12d
    b841:      	seta	%sil
    b845:      	movl	%r15d, %ecx
    b848:      	cmovbl	%r12d, %ecx
    b84c:      	addl	%ecx, %esi
    b84e:      	movl	%r12d, %edi
    b851:      	subl	%esi, %edi
    b853:      	movl	%edi, 0x50(%rsp)
    b857:      	subq	%rsi, %rax
    b85a:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b860:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b866:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b86c:      	cmpl	%r15d, %r12d
    b86f:      	jbe	0xb875 <generic_rawtp_path+0x1595>
    b871:      	movb	$0x2f, (%rbx,%rax)
    b875:      	xorl	%edi, %edi
    b877:      	cmpl	%r15d, %r12d
    b87a:      	seta	%dil
    b87e:      	movzbl	%cl, %esi
    b881:      	addq	%rax, %rbx
    b884:      	addq	%rbx, %rdi
    b887:      	movl	$0x4, %eax
    b88c:      	callq	*%rax
    b88e:      	movq	%rbx, 0x48(%rsp)
    b893:      	cmpl	%r15d, %r12d
    b896:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    b89c:      	movq	0x8(%rsp), %r12
    b8a1:      	movq	%r12, 0x30(%rsp)
    b8a6:      	movq	0x38(%rsp), %rdx
    b8ab:      	movq	0x40(%rsp), %r15
    b8b0:      	jmp	0xb903 <generic_rawtp_path+0x1623>
    b8b2:      	leaq	0x10(%r15), %rdx
    b8b6:      	movl	$0x4, %eax
    b8bb:      	movq	%rbp, %rdi
    b8be:      	movl	$0x8, %esi
    b8c3:      	callq	*%rax
    b8c5:      	movq	0x40(%rsp), %rax
    b8ca:      	cmpq	(%rsp), %rax
    b8ce:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b8d4:      	addq	$0x18, %r15
    b8d8:      	movl	$0x4, %eax
    b8dd:      	leaq	0x30(%rsp), %rdi
    b8e2:      	movl	$0x8, %esi
    b8e7:      	movq	%r15, %rdx
    b8ea:      	callq	*%rax
    b8ec:      	movq	(%rsp), %r15
    b8f0:      	movq	%r15, 0x40(%rsp)
    b8f5:      	leaq	0x20(%r15), %rdx
    b8f9:      	movq	%rdx, 0x38(%rsp)
    b8fe:      	movq	0x30(%rsp), %r12
    b903:      	cmpq	0x18(%rsp), %r12
    b908:      	jne	0xb915 <generic_rawtp_path+0x1635>
    b90a:      	cmpq	0x20(%rsp), %rdx
    b90f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    b915:      	movl	$0x4, %eax
    b91a:      	leaq	0x10(%rsp), %rdi
    b91f:      	movl	$0x8, %esi
    b924:      	callq	*%rax
    b926:      	cmpq	0x10(%rsp), %r12
    b92b:      	je	0xba23 <generic_rawtp_path+0x1743>
    b931:      	leaq	0x18(%r12), %rbx
    b936:      	movl	$0x4, %eax
    b93b:      	movq	%rbp, %rdi
    b93e:      	movl	$0x8, %esi
    b943:      	movq	%rbx, %rdx
    b946:      	callq	*%rax
    b948:      	cmpq	%r12, (%rsp)
    b94c:      	je	0xba23 <generic_rawtp_path+0x1743>
    b952:      	movl	$0x4, %eax
    b957:      	leaq	0x8(%rsp), %rdi
    b95c:      	movl	$0x8, %esi
    b961:      	movq	%rbx, %rdx
    b964:      	callq	*%rax
    b966:      	addq	$0x20, %r12
    b96a:      	movl	$0x4, %eax
    b96f:      	leaq	0x58(%rsp), %rdi
    b974:      	movl	$0x10, %ecx
    b979:      	movl	$0x10, %esi
    b97e:      	movq	%r12, %rdx
    b981:      	callq	*%rax
    b983:      	movq	0x28(%rsp), %rbx
    b988:      	movq	0x48(%rsp), %rax
    b98d:      	movl	0x5c(%rsp), %r15d
    b992:      	subq	%rbx, %rax
    b995:      	movl	0x50(%rsp), %r12d
    b99a:      	movl	%r15d, %edx
    b99d:      	subl	%r12d, %edx
    b9a0:      	movl	$0x0, %ecx
    b9a5:      	cmovbl	%ecx, %edx
    b9a8:      	addq	0x60(%rsp), %rdx
    b9ad:      	xorl	%esi, %esi
    b9af:      	cmpl	%r15d, %r12d
    b9b2:      	seta	%sil
    b9b6:      	movl	%r15d, %ecx
    b9b9:      	cmovbl	%r12d, %ecx
    b9bd:      	addl	%ecx, %esi
    b9bf:      	movl	%r12d, %edi
    b9c2:      	subl	%esi, %edi
    b9c4:      	movl	%edi, 0x50(%rsp)
    b9c8:      	subq	%rsi, %rax
    b9cb:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    b9d1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b9d7:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    b9dd:      	cmpl	%r15d, %r12d
    b9e0:      	jbe	0xb9e6 <generic_rawtp_path+0x1706>
    b9e2:      	movb	$0x2f, (%rbx,%rax)
    b9e6:      	xorl	%edi, %edi
    b9e8:      	cmpl	%r15d, %r12d
    b9eb:      	seta	%dil
    b9ef:      	movzbl	%cl, %esi
    b9f2:      	addq	%rax, %rbx
    b9f5:      	addq	%rbx, %rdi
    b9f8:      	movl	$0x4, %eax
    b9fd:      	callq	*%rax
    b9ff:      	movq	%rbx, 0x48(%rsp)
    ba04:      	cmpl	%r15d, %r12d
    ba07:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ba0d:      	movq	0x8(%rsp), %r12
    ba12:      	movq	%r12, 0x30(%rsp)
    ba17:      	movq	0x38(%rsp), %rdx
    ba1c:      	movq	0x40(%rsp), %r15
    ba21:      	jmp	0xba74 <generic_rawtp_path+0x1794>
    ba23:      	leaq	0x10(%r15), %rdx
    ba27:      	movl	$0x4, %eax
    ba2c:      	movq	%rbp, %rdi
    ba2f:      	movl	$0x8, %esi
    ba34:      	callq	*%rax
    ba36:      	movq	0x40(%rsp), %rax
    ba3b:      	cmpq	(%rsp), %rax
    ba3f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ba45:      	addq	$0x18, %r15
    ba49:      	movl	$0x4, %eax
    ba4e:      	leaq	0x30(%rsp), %rdi
    ba53:      	movl	$0x8, %esi
    ba58:      	movq	%r15, %rdx
    ba5b:      	callq	*%rax
    ba5d:      	movq	(%rsp), %r15
    ba61:      	movq	%r15, 0x40(%rsp)
    ba66:      	leaq	0x20(%r15), %rdx
    ba6a:      	movq	%rdx, 0x38(%rsp)
    ba6f:      	movq	0x30(%rsp), %r12
    ba74:      	cmpq	0x18(%rsp), %r12
    ba79:      	jne	0xba86 <generic_rawtp_path+0x17a6>
    ba7b:      	cmpq	0x20(%rsp), %rdx
    ba80:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ba86:      	movl	$0x4, %eax
    ba8b:      	leaq	0x10(%rsp), %rdi
    ba90:      	movl	$0x8, %esi
    ba95:      	callq	*%rax
    ba97:      	cmpq	0x10(%rsp), %r12
    ba9c:      	je	0xbb94 <generic_rawtp_path+0x18b4>
    baa2:      	leaq	0x18(%r12), %rbx
    baa7:      	movl	$0x4, %eax
    baac:      	movq	%rbp, %rdi
    baaf:      	movl	$0x8, %esi
    bab4:      	movq	%rbx, %rdx
    bab7:      	callq	*%rax
    bab9:      	cmpq	%r12, (%rsp)
    babd:      	je	0xbb94 <generic_rawtp_path+0x18b4>
    bac3:      	movl	$0x4, %eax
    bac8:      	leaq	0x8(%rsp), %rdi
    bacd:      	movl	$0x8, %esi
    bad2:      	movq	%rbx, %rdx
    bad5:      	callq	*%rax
    bad7:      	addq	$0x20, %r12
    badb:      	movl	$0x4, %eax
    bae0:      	leaq	0x58(%rsp), %rdi
    bae5:      	movl	$0x10, %ecx
    baea:      	movl	$0x10, %esi
    baef:      	movq	%r12, %rdx
    baf2:      	callq	*%rax
    baf4:      	movq	0x28(%rsp), %rbx
    baf9:      	movq	0x48(%rsp), %rax
    bafe:      	movl	0x5c(%rsp), %r15d
    bb03:      	subq	%rbx, %rax
    bb06:      	movl	0x50(%rsp), %r12d
    bb0b:      	movl	%r15d, %edx
    bb0e:      	subl	%r12d, %edx
    bb11:      	movl	$0x0, %ecx
    bb16:      	cmovbl	%ecx, %edx
    bb19:      	addq	0x60(%rsp), %rdx
    bb1e:      	xorl	%esi, %esi
    bb20:      	cmpl	%r15d, %r12d
    bb23:      	seta	%sil
    bb27:      	movl	%r15d, %ecx
    bb2a:      	cmovbl	%r12d, %ecx
    bb2e:      	addl	%ecx, %esi
    bb30:      	movl	%r12d, %edi
    bb33:      	subl	%esi, %edi
    bb35:      	movl	%edi, 0x50(%rsp)
    bb39:      	subq	%rsi, %rax
    bb3c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    bb42:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bb48:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    bb4e:      	cmpl	%r15d, %r12d
    bb51:      	jbe	0xbb57 <generic_rawtp_path+0x1877>
    bb53:      	movb	$0x2f, (%rbx,%rax)
    bb57:      	xorl	%edi, %edi
    bb59:      	cmpl	%r15d, %r12d
    bb5c:      	seta	%dil
    bb60:      	movzbl	%cl, %esi
    bb63:      	addq	%rax, %rbx
    bb66:      	addq	%rbx, %rdi
    bb69:      	movl	$0x4, %eax
    bb6e:      	callq	*%rax
    bb70:      	movq	%rbx, 0x48(%rsp)
    bb75:      	cmpl	%r15d, %r12d
    bb78:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    bb7e:      	movq	0x8(%rsp), %r12
    bb83:      	movq	%r12, 0x30(%rsp)
    bb88:      	movq	0x38(%rsp), %rdx
    bb8d:      	movq	0x40(%rsp), %r15
    bb92:      	jmp	0xbbe5 <generic_rawtp_path+0x1905>
    bb94:      	leaq	0x10(%r15), %rdx
    bb98:      	movl	$0x4, %eax
    bb9d:      	movq	%rbp, %rdi
    bba0:      	movl	$0x8, %esi
    bba5:      	callq	*%rax
    bba7:      	movq	0x40(%rsp), %rax
    bbac:      	cmpq	(%rsp), %rax
    bbb0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    bbb6:      	addq	$0x18, %r15
    bbba:      	movl	$0x4, %eax
    bbbf:      	leaq	0x30(%rsp), %rdi
    bbc4:      	movl	$0x8, %esi
    bbc9:      	movq	%r15, %rdx
    bbcc:      	callq	*%rax
    bbce:      	movq	(%rsp), %r15
    bbd2:      	movq	%r15, 0x40(%rsp)
    bbd7:      	leaq	0x20(%r15), %rdx
    bbdb:      	movq	%rdx, 0x38(%rsp)
    bbe0:      	movq	0x30(%rsp), %r12
    bbe5:      	cmpq	0x18(%rsp), %r12
    bbea:      	jne	0xbbf7 <generic_rawtp_path+0x1917>
    bbec:      	cmpq	0x20(%rsp), %rdx
    bbf1:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    bbf7:      	movl	$0x4, %eax
    bbfc:      	leaq	0x10(%rsp), %rdi
    bc01:      	movl	$0x8, %esi
    bc06:      	callq	*%rax
    bc08:      	cmpq	0x10(%rsp), %r12
    bc0d:      	je	0xbd05 <generic_rawtp_path+0x1a25>
    bc13:      	leaq	0x18(%r12), %rbx
    bc18:      	movl	$0x4, %eax
    bc1d:      	movq	%rbp, %rdi
    bc20:      	movl	$0x8, %esi
    bc25:      	movq	%rbx, %rdx
    bc28:      	callq	*%rax
    bc2a:      	cmpq	%r12, (%rsp)
    bc2e:      	je	0xbd05 <generic_rawtp_path+0x1a25>
    bc34:      	movl	$0x4, %eax
    bc39:      	leaq	0x8(%rsp), %rdi
    bc3e:      	movl	$0x8, %esi
    bc43:      	movq	%rbx, %rdx
    bc46:      	callq	*%rax
    bc48:      	addq	$0x20, %r12
    bc4c:      	movl	$0x4, %eax
    bc51:      	leaq	0x58(%rsp), %rdi
    bc56:      	movl	$0x10, %ecx
    bc5b:      	movl	$0x10, %esi
    bc60:      	movq	%r12, %rdx
    bc63:      	callq	*%rax
    bc65:      	movq	0x28(%rsp), %rbx
    bc6a:      	movq	0x48(%rsp), %rax
    bc6f:      	movl	0x5c(%rsp), %r15d
    bc74:      	subq	%rbx, %rax
    bc77:      	movl	0x50(%rsp), %r12d
    bc7c:      	movl	%r15d, %edx
    bc7f:      	subl	%r12d, %edx
    bc82:      	movl	$0x0, %ecx
    bc87:      	cmovbl	%ecx, %edx
    bc8a:      	addq	0x60(%rsp), %rdx
    bc8f:      	xorl	%esi, %esi
    bc91:      	cmpl	%r15d, %r12d
    bc94:      	seta	%sil
    bc98:      	movl	%r15d, %ecx
    bc9b:      	cmovbl	%r12d, %ecx
    bc9f:      	addl	%ecx, %esi
    bca1:      	movl	%r12d, %edi
    bca4:      	subl	%esi, %edi
    bca6:      	movl	%edi, 0x50(%rsp)
    bcaa:      	subq	%rsi, %rax
    bcad:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    bcb3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bcb9:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    bcbf:      	cmpl	%r15d, %r12d
    bcc2:      	jbe	0xbcc8 <generic_rawtp_path+0x19e8>
    bcc4:      	movb	$0x2f, (%rbx,%rax)
    bcc8:      	xorl	%edi, %edi
    bcca:      	cmpl	%r15d, %r12d
    bccd:      	seta	%dil
    bcd1:      	movzbl	%cl, %esi
    bcd4:      	addq	%rax, %rbx
    bcd7:      	addq	%rbx, %rdi
    bcda:      	movl	$0x4, %eax
    bcdf:      	callq	*%rax
    bce1:      	movq	%rbx, 0x48(%rsp)
    bce6:      	cmpl	%r15d, %r12d
    bce9:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    bcef:      	movq	0x8(%rsp), %r12
    bcf4:      	movq	%r12, 0x30(%rsp)
    bcf9:      	movq	0x38(%rsp), %rdx
    bcfe:      	movq	0x40(%rsp), %r15
    bd03:      	jmp	0xbd56 <generic_rawtp_path+0x1a76>
    bd05:      	leaq	0x10(%r15), %rdx
    bd09:      	movl	$0x4, %eax
    bd0e:      	movq	%rbp, %rdi
    bd11:      	movl	$0x8, %esi
    bd16:      	callq	*%rax
    bd18:      	movq	0x40(%rsp), %rax
    bd1d:      	cmpq	(%rsp), %rax
    bd21:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    bd27:      	addq	$0x18, %r15
    bd2b:      	movl	$0x4, %eax
    bd30:      	leaq	0x30(%rsp), %rdi
    bd35:      	movl	$0x8, %esi
    bd3a:      	movq	%r15, %rdx
    bd3d:      	callq	*%rax
    bd3f:      	movq	(%rsp), %r15
    bd43:      	movq	%r15, 0x40(%rsp)
    bd48:      	leaq	0x20(%r15), %rdx
    bd4c:      	movq	%rdx, 0x38(%rsp)
    bd51:      	movq	0x30(%rsp), %r12
    bd56:      	cmpq	0x18(%rsp), %r12
    bd5b:      	jne	0xbd68 <generic_rawtp_path+0x1a88>
    bd5d:      	cmpq	0x20(%rsp), %rdx
    bd62:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    bd68:      	movl	$0x4, %eax
    bd6d:      	leaq	0x10(%rsp), %rdi
    bd72:      	movl	$0x8, %esi
    bd77:      	callq	*%rax
    bd79:      	cmpq	0x10(%rsp), %r12
    bd7e:      	je	0xbe76 <generic_rawtp_path+0x1b96>
    bd84:      	leaq	0x18(%r12), %rbx
    bd89:      	movl	$0x4, %eax
    bd8e:      	movq	%rbp, %rdi
    bd91:      	movl	$0x8, %esi
    bd96:      	movq	%rbx, %rdx
    bd99:      	callq	*%rax
    bd9b:      	cmpq	%r12, (%rsp)
    bd9f:      	je	0xbe76 <generic_rawtp_path+0x1b96>
    bda5:      	movl	$0x4, %eax
    bdaa:      	leaq	0x8(%rsp), %rdi
    bdaf:      	movl	$0x8, %esi
    bdb4:      	movq	%rbx, %rdx
    bdb7:      	callq	*%rax
    bdb9:      	addq	$0x20, %r12
    bdbd:      	movl	$0x4, %eax
    bdc2:      	leaq	0x58(%rsp), %rdi
    bdc7:      	movl	$0x10, %ecx
    bdcc:      	movl	$0x10, %esi
    bdd1:      	movq	%r12, %rdx
    bdd4:      	callq	*%rax
    bdd6:      	movq	0x28(%rsp), %rbx
    bddb:      	movq	0x48(%rsp), %rax
    bde0:      	movl	0x5c(%rsp), %r15d
    bde5:      	subq	%rbx, %rax
    bde8:      	movl	0x50(%rsp), %r12d
    bded:      	movl	%r15d, %edx
    bdf0:      	subl	%r12d, %edx
    bdf3:      	movl	$0x0, %ecx
    bdf8:      	cmovbl	%ecx, %edx
    bdfb:      	addq	0x60(%rsp), %rdx
    be00:      	xorl	%esi, %esi
    be02:      	cmpl	%r15d, %r12d
    be05:      	seta	%sil
    be09:      	movl	%r15d, %ecx
    be0c:      	cmovbl	%r12d, %ecx
    be10:      	addl	%ecx, %esi
    be12:      	movl	%r12d, %edi
    be15:      	subl	%esi, %edi
    be17:      	movl	%edi, 0x50(%rsp)
    be1b:      	subq	%rsi, %rax
    be1e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    be24:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    be2a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    be30:      	cmpl	%r15d, %r12d
    be33:      	jbe	0xbe39 <generic_rawtp_path+0x1b59>
    be35:      	movb	$0x2f, (%rbx,%rax)
    be39:      	xorl	%edi, %edi
    be3b:      	cmpl	%r15d, %r12d
    be3e:      	seta	%dil
    be42:      	movzbl	%cl, %esi
    be45:      	addq	%rax, %rbx
    be48:      	addq	%rbx, %rdi
    be4b:      	movl	$0x4, %eax
    be50:      	callq	*%rax
    be52:      	movq	%rbx, 0x48(%rsp)
    be57:      	cmpl	%r15d, %r12d
    be5a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    be60:      	movq	0x8(%rsp), %r12
    be65:      	movq	%r12, 0x30(%rsp)
    be6a:      	movq	0x38(%rsp), %rdx
    be6f:      	movq	0x40(%rsp), %r15
    be74:      	jmp	0xbec7 <generic_rawtp_path+0x1be7>
    be76:      	leaq	0x10(%r15), %rdx
    be7a:      	movl	$0x4, %eax
    be7f:      	movq	%rbp, %rdi
    be82:      	movl	$0x8, %esi
    be87:      	callq	*%rax
    be89:      	movq	0x40(%rsp), %rax
    be8e:      	cmpq	(%rsp), %rax
    be92:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    be98:      	addq	$0x18, %r15
    be9c:      	movl	$0x4, %eax
    bea1:      	leaq	0x30(%rsp), %rdi
    bea6:      	movl	$0x8, %esi
    beab:      	movq	%r15, %rdx
    beae:      	callq	*%rax
    beb0:      	movq	(%rsp), %r15
    beb4:      	movq	%r15, 0x40(%rsp)
    beb9:      	leaq	0x20(%r15), %rdx
    bebd:      	movq	%rdx, 0x38(%rsp)
    bec2:      	movq	0x30(%rsp), %r12
    bec7:      	cmpq	0x18(%rsp), %r12
    becc:      	jne	0xbed9 <generic_rawtp_path+0x1bf9>
    bece:      	cmpq	0x20(%rsp), %rdx
    bed3:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    bed9:      	movl	$0x4, %eax
    bede:      	leaq	0x10(%rsp), %rdi
    bee3:      	movl	$0x8, %esi
    bee8:      	callq	*%rax
    beea:      	cmpq	0x10(%rsp), %r12
    beef:      	je	0xbfe7 <generic_rawtp_path+0x1d07>
    bef5:      	leaq	0x18(%r12), %rbx
    befa:      	movl	$0x4, %eax
    beff:      	movq	%rbp, %rdi
    bf02:      	movl	$0x8, %esi
    bf07:      	movq	%rbx, %rdx
    bf0a:      	callq	*%rax
    bf0c:      	cmpq	%r12, (%rsp)
    bf10:      	je	0xbfe7 <generic_rawtp_path+0x1d07>
    bf16:      	movl	$0x4, %eax
    bf1b:      	leaq	0x8(%rsp), %rdi
    bf20:      	movl	$0x8, %esi
    bf25:      	movq	%rbx, %rdx
    bf28:      	callq	*%rax
    bf2a:      	addq	$0x20, %r12
    bf2e:      	movl	$0x4, %eax
    bf33:      	leaq	0x58(%rsp), %rdi
    bf38:      	movl	$0x10, %ecx
    bf3d:      	movl	$0x10, %esi
    bf42:      	movq	%r12, %rdx
    bf45:      	callq	*%rax
    bf47:      	movq	0x28(%rsp), %rbx
    bf4c:      	movq	0x48(%rsp), %rax
    bf51:      	movl	0x5c(%rsp), %r15d
    bf56:      	subq	%rbx, %rax
    bf59:      	movl	0x50(%rsp), %r12d
    bf5e:      	movl	%r15d, %edx
    bf61:      	subl	%r12d, %edx
    bf64:      	movl	$0x0, %ecx
    bf69:      	cmovbl	%ecx, %edx
    bf6c:      	addq	0x60(%rsp), %rdx
    bf71:      	xorl	%esi, %esi
    bf73:      	cmpl	%r15d, %r12d
    bf76:      	seta	%sil
    bf7a:      	movl	%r15d, %ecx
    bf7d:      	cmovbl	%r12d, %ecx
    bf81:      	addl	%ecx, %esi
    bf83:      	movl	%r12d, %edi
    bf86:      	subl	%esi, %edi
    bf88:      	movl	%edi, 0x50(%rsp)
    bf8c:      	subq	%rsi, %rax
    bf8f:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    bf95:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bf9b:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    bfa1:      	cmpl	%r15d, %r12d
    bfa4:      	jbe	0xbfaa <generic_rawtp_path+0x1cca>
    bfa6:      	movb	$0x2f, (%rbx,%rax)
    bfaa:      	xorl	%edi, %edi
    bfac:      	cmpl	%r15d, %r12d
    bfaf:      	seta	%dil
    bfb3:      	movzbl	%cl, %esi
    bfb6:      	addq	%rax, %rbx
    bfb9:      	addq	%rbx, %rdi
    bfbc:      	movl	$0x4, %eax
    bfc1:      	callq	*%rax
    bfc3:      	movq	%rbx, 0x48(%rsp)
    bfc8:      	cmpl	%r15d, %r12d
    bfcb:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    bfd1:      	movq	0x8(%rsp), %r12
    bfd6:      	movq	%r12, 0x30(%rsp)
    bfdb:      	movq	0x38(%rsp), %rdx
    bfe0:      	movq	0x40(%rsp), %r15
    bfe5:      	jmp	0xc038 <generic_rawtp_path+0x1d58>
    bfe7:      	leaq	0x10(%r15), %rdx
    bfeb:      	movl	$0x4, %eax
    bff0:      	movq	%rbp, %rdi
    bff3:      	movl	$0x8, %esi
    bff8:      	callq	*%rax
    bffa:      	movq	0x40(%rsp), %rax
    bfff:      	cmpq	(%rsp), %rax
    c003:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c009:      	addq	$0x18, %r15
    c00d:      	movl	$0x4, %eax
    c012:      	leaq	0x30(%rsp), %rdi
    c017:      	movl	$0x8, %esi
    c01c:      	movq	%r15, %rdx
    c01f:      	callq	*%rax
    c021:      	movq	(%rsp), %r15
    c025:      	movq	%r15, 0x40(%rsp)
    c02a:      	leaq	0x20(%r15), %rdx
    c02e:      	movq	%rdx, 0x38(%rsp)
    c033:      	movq	0x30(%rsp), %r12
    c038:      	cmpq	0x18(%rsp), %r12
    c03d:      	jne	0xc04a <generic_rawtp_path+0x1d6a>
    c03f:      	cmpq	0x20(%rsp), %rdx
    c044:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c04a:      	movl	$0x4, %eax
    c04f:      	leaq	0x10(%rsp), %rdi
    c054:      	movl	$0x8, %esi
    c059:      	callq	*%rax
    c05b:      	cmpq	0x10(%rsp), %r12
    c060:      	je	0xc158 <generic_rawtp_path+0x1e78>
    c066:      	leaq	0x18(%r12), %rbx
    c06b:      	movl	$0x4, %eax
    c070:      	movq	%rbp, %rdi
    c073:      	movl	$0x8, %esi
    c078:      	movq	%rbx, %rdx
    c07b:      	callq	*%rax
    c07d:      	cmpq	%r12, (%rsp)
    c081:      	je	0xc158 <generic_rawtp_path+0x1e78>
    c087:      	movl	$0x4, %eax
    c08c:      	leaq	0x8(%rsp), %rdi
    c091:      	movl	$0x8, %esi
    c096:      	movq	%rbx, %rdx
    c099:      	callq	*%rax
    c09b:      	addq	$0x20, %r12
    c09f:      	movl	$0x4, %eax
    c0a4:      	leaq	0x58(%rsp), %rdi
    c0a9:      	movl	$0x10, %ecx
    c0ae:      	movl	$0x10, %esi
    c0b3:      	movq	%r12, %rdx
    c0b6:      	callq	*%rax
    c0b8:      	movq	0x28(%rsp), %rbx
    c0bd:      	movq	0x48(%rsp), %rax
    c0c2:      	movl	0x5c(%rsp), %r15d
    c0c7:      	subq	%rbx, %rax
    c0ca:      	movl	0x50(%rsp), %r12d
    c0cf:      	movl	%r15d, %edx
    c0d2:      	subl	%r12d, %edx
    c0d5:      	movl	$0x0, %ecx
    c0da:      	cmovbl	%ecx, %edx
    c0dd:      	addq	0x60(%rsp), %rdx
    c0e2:      	xorl	%esi, %esi
    c0e4:      	cmpl	%r15d, %r12d
    c0e7:      	seta	%sil
    c0eb:      	movl	%r15d, %ecx
    c0ee:      	cmovbl	%r12d, %ecx
    c0f2:      	addl	%ecx, %esi
    c0f4:      	movl	%r12d, %edi
    c0f7:      	subl	%esi, %edi
    c0f9:      	movl	%edi, 0x50(%rsp)
    c0fd:      	subq	%rsi, %rax
    c100:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c106:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c10c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c112:      	cmpl	%r15d, %r12d
    c115:      	jbe	0xc11b <generic_rawtp_path+0x1e3b>
    c117:      	movb	$0x2f, (%rbx,%rax)
    c11b:      	xorl	%edi, %edi
    c11d:      	cmpl	%r15d, %r12d
    c120:      	seta	%dil
    c124:      	movzbl	%cl, %esi
    c127:      	addq	%rax, %rbx
    c12a:      	addq	%rbx, %rdi
    c12d:      	movl	$0x4, %eax
    c132:      	callq	*%rax
    c134:      	movq	%rbx, 0x48(%rsp)
    c139:      	cmpl	%r15d, %r12d
    c13c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c142:      	movq	0x8(%rsp), %r12
    c147:      	movq	%r12, 0x30(%rsp)
    c14c:      	movq	0x38(%rsp), %rdx
    c151:      	movq	0x40(%rsp), %r15
    c156:      	jmp	0xc1a9 <generic_rawtp_path+0x1ec9>
    c158:      	leaq	0x10(%r15), %rdx
    c15c:      	movl	$0x4, %eax
    c161:      	movq	%rbp, %rdi
    c164:      	movl	$0x8, %esi
    c169:      	callq	*%rax
    c16b:      	movq	0x40(%rsp), %rax
    c170:      	cmpq	(%rsp), %rax
    c174:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c17a:      	addq	$0x18, %r15
    c17e:      	movl	$0x4, %eax
    c183:      	leaq	0x30(%rsp), %rdi
    c188:      	movl	$0x8, %esi
    c18d:      	movq	%r15, %rdx
    c190:      	callq	*%rax
    c192:      	movq	(%rsp), %r15
    c196:      	movq	%r15, 0x40(%rsp)
    c19b:      	leaq	0x20(%r15), %rdx
    c19f:      	movq	%rdx, 0x38(%rsp)
    c1a4:      	movq	0x30(%rsp), %r12
    c1a9:      	cmpq	0x18(%rsp), %r12
    c1ae:      	jne	0xc1bb <generic_rawtp_path+0x1edb>
    c1b0:      	cmpq	0x20(%rsp), %rdx
    c1b5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c1bb:      	movl	$0x4, %eax
    c1c0:      	leaq	0x10(%rsp), %rdi
    c1c5:      	movl	$0x8, %esi
    c1ca:      	callq	*%rax
    c1cc:      	cmpq	0x10(%rsp), %r12
    c1d1:      	je	0xc2c9 <generic_rawtp_path+0x1fe9>
    c1d7:      	leaq	0x18(%r12), %rbx
    c1dc:      	movl	$0x4, %eax
    c1e1:      	movq	%rbp, %rdi
    c1e4:      	movl	$0x8, %esi
    c1e9:      	movq	%rbx, %rdx
    c1ec:      	callq	*%rax
    c1ee:      	cmpq	%r12, (%rsp)
    c1f2:      	je	0xc2c9 <generic_rawtp_path+0x1fe9>
    c1f8:      	movl	$0x4, %eax
    c1fd:      	leaq	0x8(%rsp), %rdi
    c202:      	movl	$0x8, %esi
    c207:      	movq	%rbx, %rdx
    c20a:      	callq	*%rax
    c20c:      	addq	$0x20, %r12
    c210:      	movl	$0x4, %eax
    c215:      	leaq	0x58(%rsp), %rdi
    c21a:      	movl	$0x10, %ecx
    c21f:      	movl	$0x10, %esi
    c224:      	movq	%r12, %rdx
    c227:      	callq	*%rax
    c229:      	movq	0x28(%rsp), %rbx
    c22e:      	movq	0x48(%rsp), %rax
    c233:      	movl	0x5c(%rsp), %r15d
    c238:      	subq	%rbx, %rax
    c23b:      	movl	0x50(%rsp), %r12d
    c240:      	movl	%r15d, %edx
    c243:      	subl	%r12d, %edx
    c246:      	movl	$0x0, %ecx
    c24b:      	cmovbl	%ecx, %edx
    c24e:      	addq	0x60(%rsp), %rdx
    c253:      	xorl	%esi, %esi
    c255:      	cmpl	%r15d, %r12d
    c258:      	seta	%sil
    c25c:      	movl	%r15d, %ecx
    c25f:      	cmovbl	%r12d, %ecx
    c263:      	addl	%ecx, %esi
    c265:      	movl	%r12d, %edi
    c268:      	subl	%esi, %edi
    c26a:      	movl	%edi, 0x50(%rsp)
    c26e:      	subq	%rsi, %rax
    c271:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c277:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c27d:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c283:      	cmpl	%r15d, %r12d
    c286:      	jbe	0xc28c <generic_rawtp_path+0x1fac>
    c288:      	movb	$0x2f, (%rbx,%rax)
    c28c:      	xorl	%edi, %edi
    c28e:      	cmpl	%r15d, %r12d
    c291:      	seta	%dil
    c295:      	movzbl	%cl, %esi
    c298:      	addq	%rax, %rbx
    c29b:      	addq	%rbx, %rdi
    c29e:      	movl	$0x4, %eax
    c2a3:      	callq	*%rax
    c2a5:      	movq	%rbx, 0x48(%rsp)
    c2aa:      	cmpl	%r15d, %r12d
    c2ad:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c2b3:      	movq	0x8(%rsp), %r12
    c2b8:      	movq	%r12, 0x30(%rsp)
    c2bd:      	movq	0x38(%rsp), %rdx
    c2c2:      	movq	0x40(%rsp), %r15
    c2c7:      	jmp	0xc31a <generic_rawtp_path+0x203a>
    c2c9:      	leaq	0x10(%r15), %rdx
    c2cd:      	movl	$0x4, %eax
    c2d2:      	movq	%rbp, %rdi
    c2d5:      	movl	$0x8, %esi
    c2da:      	callq	*%rax
    c2dc:      	movq	0x40(%rsp), %rax
    c2e1:      	cmpq	(%rsp), %rax
    c2e5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c2eb:      	addq	$0x18, %r15
    c2ef:      	movl	$0x4, %eax
    c2f4:      	leaq	0x30(%rsp), %rdi
    c2f9:      	movl	$0x8, %esi
    c2fe:      	movq	%r15, %rdx
    c301:      	callq	*%rax
    c303:      	movq	(%rsp), %r15
    c307:      	movq	%r15, 0x40(%rsp)
    c30c:      	leaq	0x20(%r15), %rdx
    c310:      	movq	%rdx, 0x38(%rsp)
    c315:      	movq	0x30(%rsp), %r12
    c31a:      	cmpq	0x18(%rsp), %r12
    c31f:      	jne	0xc32c <generic_rawtp_path+0x204c>
    c321:      	cmpq	0x20(%rsp), %rdx
    c326:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c32c:      	movl	$0x4, %eax
    c331:      	leaq	0x10(%rsp), %rdi
    c336:      	movl	$0x8, %esi
    c33b:      	callq	*%rax
    c33d:      	cmpq	0x10(%rsp), %r12
    c342:      	je	0xc43a <generic_rawtp_path+0x215a>
    c348:      	leaq	0x18(%r12), %rbx
    c34d:      	movl	$0x4, %eax
    c352:      	movq	%rbp, %rdi
    c355:      	movl	$0x8, %esi
    c35a:      	movq	%rbx, %rdx
    c35d:      	callq	*%rax
    c35f:      	cmpq	%r12, (%rsp)
    c363:      	je	0xc43a <generic_rawtp_path+0x215a>
    c369:      	movl	$0x4, %eax
    c36e:      	leaq	0x8(%rsp), %rdi
    c373:      	movl	$0x8, %esi
    c378:      	movq	%rbx, %rdx
    c37b:      	callq	*%rax
    c37d:      	addq	$0x20, %r12
    c381:      	movl	$0x4, %eax
    c386:      	leaq	0x58(%rsp), %rdi
    c38b:      	movl	$0x10, %ecx
    c390:      	movl	$0x10, %esi
    c395:      	movq	%r12, %rdx
    c398:      	callq	*%rax
    c39a:      	movq	0x28(%rsp), %rbx
    c39f:      	movq	0x48(%rsp), %rax
    c3a4:      	movl	0x5c(%rsp), %r15d
    c3a9:      	subq	%rbx, %rax
    c3ac:      	movl	0x50(%rsp), %r12d
    c3b1:      	movl	%r15d, %edx
    c3b4:      	subl	%r12d, %edx
    c3b7:      	movl	$0x0, %ecx
    c3bc:      	cmovbl	%ecx, %edx
    c3bf:      	addq	0x60(%rsp), %rdx
    c3c4:      	xorl	%esi, %esi
    c3c6:      	cmpl	%r15d, %r12d
    c3c9:      	seta	%sil
    c3cd:      	movl	%r15d, %ecx
    c3d0:      	cmovbl	%r12d, %ecx
    c3d4:      	addl	%ecx, %esi
    c3d6:      	movl	%r12d, %edi
    c3d9:      	subl	%esi, %edi
    c3db:      	movl	%edi, 0x50(%rsp)
    c3df:      	subq	%rsi, %rax
    c3e2:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c3e8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c3ee:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c3f4:      	cmpl	%r15d, %r12d
    c3f7:      	jbe	0xc3fd <generic_rawtp_path+0x211d>
    c3f9:      	movb	$0x2f, (%rbx,%rax)
    c3fd:      	xorl	%edi, %edi
    c3ff:      	cmpl	%r15d, %r12d
    c402:      	seta	%dil
    c406:      	movzbl	%cl, %esi
    c409:      	addq	%rax, %rbx
    c40c:      	addq	%rbx, %rdi
    c40f:      	movl	$0x4, %eax
    c414:      	callq	*%rax
    c416:      	movq	%rbx, 0x48(%rsp)
    c41b:      	cmpl	%r15d, %r12d
    c41e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c424:      	movq	0x8(%rsp), %r12
    c429:      	movq	%r12, 0x30(%rsp)
    c42e:      	movq	0x38(%rsp), %rdx
    c433:      	movq	0x40(%rsp), %r15
    c438:      	jmp	0xc48b <generic_rawtp_path+0x21ab>
    c43a:      	leaq	0x10(%r15), %rdx
    c43e:      	movl	$0x4, %eax
    c443:      	movq	%rbp, %rdi
    c446:      	movl	$0x8, %esi
    c44b:      	callq	*%rax
    c44d:      	movq	0x40(%rsp), %rax
    c452:      	cmpq	(%rsp), %rax
    c456:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c45c:      	addq	$0x18, %r15
    c460:      	movl	$0x4, %eax
    c465:      	leaq	0x30(%rsp), %rdi
    c46a:      	movl	$0x8, %esi
    c46f:      	movq	%r15, %rdx
    c472:      	callq	*%rax
    c474:      	movq	(%rsp), %r15
    c478:      	movq	%r15, 0x40(%rsp)
    c47d:      	leaq	0x20(%r15), %rdx
    c481:      	movq	%rdx, 0x38(%rsp)
    c486:      	movq	0x30(%rsp), %r12
    c48b:      	cmpq	0x18(%rsp), %r12
    c490:      	jne	0xc49d <generic_rawtp_path+0x21bd>
    c492:      	cmpq	0x20(%rsp), %rdx
    c497:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c49d:      	movl	$0x4, %eax
    c4a2:      	leaq	0x10(%rsp), %rdi
    c4a7:      	movl	$0x8, %esi
    c4ac:      	callq	*%rax
    c4ae:      	cmpq	0x10(%rsp), %r12
    c4b3:      	je	0xc5ab <generic_rawtp_path+0x22cb>
    c4b9:      	leaq	0x18(%r12), %rbx
    c4be:      	movl	$0x4, %eax
    c4c3:      	movq	%rbp, %rdi
    c4c6:      	movl	$0x8, %esi
    c4cb:      	movq	%rbx, %rdx
    c4ce:      	callq	*%rax
    c4d0:      	cmpq	%r12, (%rsp)
    c4d4:      	je	0xc5ab <generic_rawtp_path+0x22cb>
    c4da:      	movl	$0x4, %eax
    c4df:      	leaq	0x8(%rsp), %rdi
    c4e4:      	movl	$0x8, %esi
    c4e9:      	movq	%rbx, %rdx
    c4ec:      	callq	*%rax
    c4ee:      	addq	$0x20, %r12
    c4f2:      	movl	$0x4, %eax
    c4f7:      	leaq	0x58(%rsp), %rdi
    c4fc:      	movl	$0x10, %ecx
    c501:      	movl	$0x10, %esi
    c506:      	movq	%r12, %rdx
    c509:      	callq	*%rax
    c50b:      	movq	0x28(%rsp), %rbx
    c510:      	movq	0x48(%rsp), %rax
    c515:      	movl	0x5c(%rsp), %r15d
    c51a:      	subq	%rbx, %rax
    c51d:      	movl	0x50(%rsp), %r12d
    c522:      	movl	%r15d, %edx
    c525:      	subl	%r12d, %edx
    c528:      	movl	$0x0, %ecx
    c52d:      	cmovbl	%ecx, %edx
    c530:      	addq	0x60(%rsp), %rdx
    c535:      	xorl	%esi, %esi
    c537:      	cmpl	%r15d, %r12d
    c53a:      	seta	%sil
    c53e:      	movl	%r15d, %ecx
    c541:      	cmovbl	%r12d, %ecx
    c545:      	addl	%ecx, %esi
    c547:      	movl	%r12d, %edi
    c54a:      	subl	%esi, %edi
    c54c:      	movl	%edi, 0x50(%rsp)
    c550:      	subq	%rsi, %rax
    c553:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c559:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c55f:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c565:      	cmpl	%r15d, %r12d
    c568:      	jbe	0xc56e <generic_rawtp_path+0x228e>
    c56a:      	movb	$0x2f, (%rbx,%rax)
    c56e:      	xorl	%edi, %edi
    c570:      	cmpl	%r15d, %r12d
    c573:      	seta	%dil
    c577:      	movzbl	%cl, %esi
    c57a:      	addq	%rax, %rbx
    c57d:      	addq	%rbx, %rdi
    c580:      	movl	$0x4, %eax
    c585:      	callq	*%rax
    c587:      	movq	%rbx, 0x48(%rsp)
    c58c:      	cmpl	%r15d, %r12d
    c58f:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c595:      	movq	0x8(%rsp), %r12
    c59a:      	movq	%r12, 0x30(%rsp)
    c59f:      	movq	0x38(%rsp), %rdx
    c5a4:      	movq	0x40(%rsp), %r15
    c5a9:      	jmp	0xc5fc <generic_rawtp_path+0x231c>
    c5ab:      	leaq	0x10(%r15), %rdx
    c5af:      	movl	$0x4, %eax
    c5b4:      	movq	%rbp, %rdi
    c5b7:      	movl	$0x8, %esi
    c5bc:      	callq	*%rax
    c5be:      	movq	0x40(%rsp), %rax
    c5c3:      	cmpq	(%rsp), %rax
    c5c7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c5cd:      	addq	$0x18, %r15
    c5d1:      	movl	$0x4, %eax
    c5d6:      	leaq	0x30(%rsp), %rdi
    c5db:      	movl	$0x8, %esi
    c5e0:      	movq	%r15, %rdx
    c5e3:      	callq	*%rax
    c5e5:      	movq	(%rsp), %r15
    c5e9:      	movq	%r15, 0x40(%rsp)
    c5ee:      	leaq	0x20(%r15), %rdx
    c5f2:      	movq	%rdx, 0x38(%rsp)
    c5f7:      	movq	0x30(%rsp), %r12
    c5fc:      	cmpq	0x18(%rsp), %r12
    c601:      	jne	0xc60e <generic_rawtp_path+0x232e>
    c603:      	cmpq	0x20(%rsp), %rdx
    c608:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c60e:      	movl	$0x4, %eax
    c613:      	leaq	0x10(%rsp), %rdi
    c618:      	movl	$0x8, %esi
    c61d:      	callq	*%rax
    c61f:      	cmpq	0x10(%rsp), %r12
    c624:      	je	0xc71c <generic_rawtp_path+0x243c>
    c62a:      	leaq	0x18(%r12), %rbx
    c62f:      	movl	$0x4, %eax
    c634:      	movq	%rbp, %rdi
    c637:      	movl	$0x8, %esi
    c63c:      	movq	%rbx, %rdx
    c63f:      	callq	*%rax
    c641:      	cmpq	%r12, (%rsp)
    c645:      	je	0xc71c <generic_rawtp_path+0x243c>
    c64b:      	movl	$0x4, %eax
    c650:      	leaq	0x8(%rsp), %rdi
    c655:      	movl	$0x8, %esi
    c65a:      	movq	%rbx, %rdx
    c65d:      	callq	*%rax
    c65f:      	addq	$0x20, %r12
    c663:      	movl	$0x4, %eax
    c668:      	leaq	0x58(%rsp), %rdi
    c66d:      	movl	$0x10, %ecx
    c672:      	movl	$0x10, %esi
    c677:      	movq	%r12, %rdx
    c67a:      	callq	*%rax
    c67c:      	movq	0x28(%rsp), %rbx
    c681:      	movq	0x48(%rsp), %rax
    c686:      	movl	0x5c(%rsp), %r15d
    c68b:      	subq	%rbx, %rax
    c68e:      	movl	0x50(%rsp), %r12d
    c693:      	movl	%r15d, %edx
    c696:      	subl	%r12d, %edx
    c699:      	movl	$0x0, %ecx
    c69e:      	cmovbl	%ecx, %edx
    c6a1:      	addq	0x60(%rsp), %rdx
    c6a6:      	xorl	%esi, %esi
    c6a8:      	cmpl	%r15d, %r12d
    c6ab:      	seta	%sil
    c6af:      	movl	%r15d, %ecx
    c6b2:      	cmovbl	%r12d, %ecx
    c6b6:      	addl	%ecx, %esi
    c6b8:      	movl	%r12d, %edi
    c6bb:      	subl	%esi, %edi
    c6bd:      	movl	%edi, 0x50(%rsp)
    c6c1:      	subq	%rsi, %rax
    c6c4:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c6ca:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c6d0:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c6d6:      	cmpl	%r15d, %r12d
    c6d9:      	jbe	0xc6df <generic_rawtp_path+0x23ff>
    c6db:      	movb	$0x2f, (%rbx,%rax)
    c6df:      	xorl	%edi, %edi
    c6e1:      	cmpl	%r15d, %r12d
    c6e4:      	seta	%dil
    c6e8:      	movzbl	%cl, %esi
    c6eb:      	addq	%rax, %rbx
    c6ee:      	addq	%rbx, %rdi
    c6f1:      	movl	$0x4, %eax
    c6f6:      	callq	*%rax
    c6f8:      	movq	%rbx, 0x48(%rsp)
    c6fd:      	cmpl	%r15d, %r12d
    c700:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c706:      	movq	0x8(%rsp), %r12
    c70b:      	movq	%r12, 0x30(%rsp)
    c710:      	movq	0x38(%rsp), %rdx
    c715:      	movq	0x40(%rsp), %r15
    c71a:      	jmp	0xc76d <generic_rawtp_path+0x248d>
    c71c:      	leaq	0x10(%r15), %rdx
    c720:      	movl	$0x4, %eax
    c725:      	movq	%rbp, %rdi
    c728:      	movl	$0x8, %esi
    c72d:      	callq	*%rax
    c72f:      	movq	0x40(%rsp), %rax
    c734:      	cmpq	(%rsp), %rax
    c738:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c73e:      	addq	$0x18, %r15
    c742:      	movl	$0x4, %eax
    c747:      	leaq	0x30(%rsp), %rdi
    c74c:      	movl	$0x8, %esi
    c751:      	movq	%r15, %rdx
    c754:      	callq	*%rax
    c756:      	movq	(%rsp), %r15
    c75a:      	movq	%r15, 0x40(%rsp)
    c75f:      	leaq	0x20(%r15), %rdx
    c763:      	movq	%rdx, 0x38(%rsp)
    c768:      	movq	0x30(%rsp), %r12
    c76d:      	cmpq	0x18(%rsp), %r12
    c772:      	jne	0xc77f <generic_rawtp_path+0x249f>
    c774:      	cmpq	0x20(%rsp), %rdx
    c779:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c77f:      	movl	$0x4, %eax
    c784:      	leaq	0x10(%rsp), %rdi
    c789:      	movl	$0x8, %esi
    c78e:      	callq	*%rax
    c790:      	cmpq	0x10(%rsp), %r12
    c795:      	je	0xc88d <generic_rawtp_path+0x25ad>
    c79b:      	leaq	0x18(%r12), %rbx
    c7a0:      	movl	$0x4, %eax
    c7a5:      	movq	%rbp, %rdi
    c7a8:      	movl	$0x8, %esi
    c7ad:      	movq	%rbx, %rdx
    c7b0:      	callq	*%rax
    c7b2:      	cmpq	%r12, (%rsp)
    c7b6:      	je	0xc88d <generic_rawtp_path+0x25ad>
    c7bc:      	movl	$0x4, %eax
    c7c1:      	leaq	0x8(%rsp), %rdi
    c7c6:      	movl	$0x8, %esi
    c7cb:      	movq	%rbx, %rdx
    c7ce:      	callq	*%rax
    c7d0:      	addq	$0x20, %r12
    c7d4:      	movl	$0x4, %eax
    c7d9:      	leaq	0x58(%rsp), %rdi
    c7de:      	movl	$0x10, %ecx
    c7e3:      	movl	$0x10, %esi
    c7e8:      	movq	%r12, %rdx
    c7eb:      	callq	*%rax
    c7ed:      	movq	0x28(%rsp), %rbx
    c7f2:      	movq	0x48(%rsp), %rax
    c7f7:      	movl	0x5c(%rsp), %r15d
    c7fc:      	subq	%rbx, %rax
    c7ff:      	movl	0x50(%rsp), %r12d
    c804:      	movl	%r15d, %edx
    c807:      	subl	%r12d, %edx
    c80a:      	movl	$0x0, %ecx
    c80f:      	cmovbl	%ecx, %edx
    c812:      	addq	0x60(%rsp), %rdx
    c817:      	xorl	%esi, %esi
    c819:      	cmpl	%r15d, %r12d
    c81c:      	seta	%sil
    c820:      	movl	%r15d, %ecx
    c823:      	cmovbl	%r12d, %ecx
    c827:      	addl	%ecx, %esi
    c829:      	movl	%r12d, %edi
    c82c:      	subl	%esi, %edi
    c82e:      	movl	%edi, 0x50(%rsp)
    c832:      	subq	%rsi, %rax
    c835:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c83b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c841:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c847:      	cmpl	%r15d, %r12d
    c84a:      	jbe	0xc850 <generic_rawtp_path+0x2570>
    c84c:      	movb	$0x2f, (%rbx,%rax)
    c850:      	xorl	%edi, %edi
    c852:      	cmpl	%r15d, %r12d
    c855:      	seta	%dil
    c859:      	movzbl	%cl, %esi
    c85c:      	addq	%rax, %rbx
    c85f:      	addq	%rbx, %rdi
    c862:      	movl	$0x4, %eax
    c867:      	callq	*%rax
    c869:      	movq	%rbx, 0x48(%rsp)
    c86e:      	cmpl	%r15d, %r12d
    c871:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c877:      	movq	0x8(%rsp), %r12
    c87c:      	movq	%r12, 0x30(%rsp)
    c881:      	movq	0x38(%rsp), %rdx
    c886:      	movq	0x40(%rsp), %r15
    c88b:      	jmp	0xc8de <generic_rawtp_path+0x25fe>
    c88d:      	leaq	0x10(%r15), %rdx
    c891:      	movl	$0x4, %eax
    c896:      	movq	%rbp, %rdi
    c899:      	movl	$0x8, %esi
    c89e:      	callq	*%rax
    c8a0:      	movq	0x40(%rsp), %rax
    c8a5:      	cmpq	(%rsp), %rax
    c8a9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c8af:      	addq	$0x18, %r15
    c8b3:      	movl	$0x4, %eax
    c8b8:      	leaq	0x30(%rsp), %rdi
    c8bd:      	movl	$0x8, %esi
    c8c2:      	movq	%r15, %rdx
    c8c5:      	callq	*%rax
    c8c7:      	movq	(%rsp), %r15
    c8cb:      	movq	%r15, 0x40(%rsp)
    c8d0:      	leaq	0x20(%r15), %rdx
    c8d4:      	movq	%rdx, 0x38(%rsp)
    c8d9:      	movq	0x30(%rsp), %r12
    c8de:      	cmpq	0x18(%rsp), %r12
    c8e3:      	jne	0xc8f0 <generic_rawtp_path+0x2610>
    c8e5:      	cmpq	0x20(%rsp), %rdx
    c8ea:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    c8f0:      	movl	$0x4, %eax
    c8f5:      	leaq	0x10(%rsp), %rdi
    c8fa:      	movl	$0x8, %esi
    c8ff:      	callq	*%rax
    c901:      	cmpq	0x10(%rsp), %r12
    c906:      	je	0xc9fe <generic_rawtp_path+0x271e>
    c90c:      	leaq	0x18(%r12), %rbx
    c911:      	movl	$0x4, %eax
    c916:      	movq	%rbp, %rdi
    c919:      	movl	$0x8, %esi
    c91e:      	movq	%rbx, %rdx
    c921:      	callq	*%rax
    c923:      	cmpq	%r12, (%rsp)
    c927:      	je	0xc9fe <generic_rawtp_path+0x271e>
    c92d:      	movl	$0x4, %eax
    c932:      	leaq	0x8(%rsp), %rdi
    c937:      	movl	$0x8, %esi
    c93c:      	movq	%rbx, %rdx
    c93f:      	callq	*%rax
    c941:      	addq	$0x20, %r12
    c945:      	movl	$0x4, %eax
    c94a:      	leaq	0x58(%rsp), %rdi
    c94f:      	movl	$0x10, %ecx
    c954:      	movl	$0x10, %esi
    c959:      	movq	%r12, %rdx
    c95c:      	callq	*%rax
    c95e:      	movq	0x28(%rsp), %rbx
    c963:      	movq	0x48(%rsp), %rax
    c968:      	movl	0x5c(%rsp), %r15d
    c96d:      	subq	%rbx, %rax
    c970:      	movl	0x50(%rsp), %r12d
    c975:      	movl	%r15d, %edx
    c978:      	subl	%r12d, %edx
    c97b:      	movl	$0x0, %ecx
    c980:      	cmovbl	%ecx, %edx
    c983:      	addq	0x60(%rsp), %rdx
    c988:      	xorl	%esi, %esi
    c98a:      	cmpl	%r15d, %r12d
    c98d:      	seta	%sil
    c991:      	movl	%r15d, %ecx
    c994:      	cmovbl	%r12d, %ecx
    c998:      	addl	%ecx, %esi
    c99a:      	movl	%r12d, %edi
    c99d:      	subl	%esi, %edi
    c99f:      	movl	%edi, 0x50(%rsp)
    c9a3:      	subq	%rsi, %rax
    c9a6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    c9ac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c9b2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    c9b8:      	cmpl	%r15d, %r12d
    c9bb:      	jbe	0xc9c1 <generic_rawtp_path+0x26e1>
    c9bd:      	movb	$0x2f, (%rbx,%rax)
    c9c1:      	xorl	%edi, %edi
    c9c3:      	cmpl	%r15d, %r12d
    c9c6:      	seta	%dil
    c9ca:      	movzbl	%cl, %esi
    c9cd:      	addq	%rax, %rbx
    c9d0:      	addq	%rbx, %rdi
    c9d3:      	movl	$0x4, %eax
    c9d8:      	callq	*%rax
    c9da:      	movq	%rbx, 0x48(%rsp)
    c9df:      	cmpl	%r15d, %r12d
    c9e2:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    c9e8:      	movq	0x8(%rsp), %r12
    c9ed:      	movq	%r12, 0x30(%rsp)
    c9f2:      	movq	0x38(%rsp), %rdx
    c9f7:      	movq	0x40(%rsp), %r15
    c9fc:      	jmp	0xca4f <generic_rawtp_path+0x276f>
    c9fe:      	leaq	0x10(%r15), %rdx
    ca02:      	movl	$0x4, %eax
    ca07:      	movq	%rbp, %rdi
    ca0a:      	movl	$0x8, %esi
    ca0f:      	callq	*%rax
    ca11:      	movq	0x40(%rsp), %rax
    ca16:      	cmpq	(%rsp), %rax
    ca1a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ca20:      	addq	$0x18, %r15
    ca24:      	movl	$0x4, %eax
    ca29:      	leaq	0x30(%rsp), %rdi
    ca2e:      	movl	$0x8, %esi
    ca33:      	movq	%r15, %rdx
    ca36:      	callq	*%rax
    ca38:      	movq	(%rsp), %r15
    ca3c:      	movq	%r15, 0x40(%rsp)
    ca41:      	leaq	0x20(%r15), %rdx
    ca45:      	movq	%rdx, 0x38(%rsp)
    ca4a:      	movq	0x30(%rsp), %r12
    ca4f:      	cmpq	0x18(%rsp), %r12
    ca54:      	jne	0xca61 <generic_rawtp_path+0x2781>
    ca56:      	cmpq	0x20(%rsp), %rdx
    ca5b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ca61:      	movl	$0x4, %eax
    ca66:      	leaq	0x10(%rsp), %rdi
    ca6b:      	movl	$0x8, %esi
    ca70:      	callq	*%rax
    ca72:      	cmpq	0x10(%rsp), %r12
    ca77:      	je	0xcb6f <generic_rawtp_path+0x288f>
    ca7d:      	leaq	0x18(%r12), %rbx
    ca82:      	movl	$0x4, %eax
    ca87:      	movq	%rbp, %rdi
    ca8a:      	movl	$0x8, %esi
    ca8f:      	movq	%rbx, %rdx
    ca92:      	callq	*%rax
    ca94:      	cmpq	%r12, (%rsp)
    ca98:      	je	0xcb6f <generic_rawtp_path+0x288f>
    ca9e:      	movl	$0x4, %eax
    caa3:      	leaq	0x8(%rsp), %rdi
    caa8:      	movl	$0x8, %esi
    caad:      	movq	%rbx, %rdx
    cab0:      	callq	*%rax
    cab2:      	addq	$0x20, %r12
    cab6:      	movl	$0x4, %eax
    cabb:      	leaq	0x58(%rsp), %rdi
    cac0:      	movl	$0x10, %ecx
    cac5:      	movl	$0x10, %esi
    caca:      	movq	%r12, %rdx
    cacd:      	callq	*%rax
    cacf:      	movq	0x28(%rsp), %rbx
    cad4:      	movq	0x48(%rsp), %rax
    cad9:      	movl	0x5c(%rsp), %r15d
    cade:      	subq	%rbx, %rax
    cae1:      	movl	0x50(%rsp), %r12d
    cae6:      	movl	%r15d, %edx
    cae9:      	subl	%r12d, %edx
    caec:      	movl	$0x0, %ecx
    caf1:      	cmovbl	%ecx, %edx
    caf4:      	addq	0x60(%rsp), %rdx
    caf9:      	xorl	%esi, %esi
    cafb:      	cmpl	%r15d, %r12d
    cafe:      	seta	%sil
    cb02:      	movl	%r15d, %ecx
    cb05:      	cmovbl	%r12d, %ecx
    cb09:      	addl	%ecx, %esi
    cb0b:      	movl	%r12d, %edi
    cb0e:      	subl	%esi, %edi
    cb10:      	movl	%edi, 0x50(%rsp)
    cb14:      	subq	%rsi, %rax
    cb17:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    cb1d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cb23:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    cb29:      	cmpl	%r15d, %r12d
    cb2c:      	jbe	0xcb32 <generic_rawtp_path+0x2852>
    cb2e:      	movb	$0x2f, (%rbx,%rax)
    cb32:      	xorl	%edi, %edi
    cb34:      	cmpl	%r15d, %r12d
    cb37:      	seta	%dil
    cb3b:      	movzbl	%cl, %esi
    cb3e:      	addq	%rax, %rbx
    cb41:      	addq	%rbx, %rdi
    cb44:      	movl	$0x4, %eax
    cb49:      	callq	*%rax
    cb4b:      	movq	%rbx, 0x48(%rsp)
    cb50:      	cmpl	%r15d, %r12d
    cb53:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    cb59:      	movq	0x8(%rsp), %r12
    cb5e:      	movq	%r12, 0x30(%rsp)
    cb63:      	movq	0x38(%rsp), %rdx
    cb68:      	movq	0x40(%rsp), %r15
    cb6d:      	jmp	0xcbc0 <generic_rawtp_path+0x28e0>
    cb6f:      	leaq	0x10(%r15), %rdx
    cb73:      	movl	$0x4, %eax
    cb78:      	movq	%rbp, %rdi
    cb7b:      	movl	$0x8, %esi
    cb80:      	callq	*%rax
    cb82:      	movq	0x40(%rsp), %rax
    cb87:      	cmpq	(%rsp), %rax
    cb8b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    cb91:      	addq	$0x18, %r15
    cb95:      	movl	$0x4, %eax
    cb9a:      	leaq	0x30(%rsp), %rdi
    cb9f:      	movl	$0x8, %esi
    cba4:      	movq	%r15, %rdx
    cba7:      	callq	*%rax
    cba9:      	movq	(%rsp), %r15
    cbad:      	movq	%r15, 0x40(%rsp)
    cbb2:      	leaq	0x20(%r15), %rdx
    cbb6:      	movq	%rdx, 0x38(%rsp)
    cbbb:      	movq	0x30(%rsp), %r12
    cbc0:      	cmpq	0x18(%rsp), %r12
    cbc5:      	jne	0xcbd2 <generic_rawtp_path+0x28f2>
    cbc7:      	cmpq	0x20(%rsp), %rdx
    cbcc:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    cbd2:      	movl	$0x4, %eax
    cbd7:      	leaq	0x10(%rsp), %rdi
    cbdc:      	movl	$0x8, %esi
    cbe1:      	callq	*%rax
    cbe3:      	cmpq	0x10(%rsp), %r12
    cbe8:      	je	0xcce0 <generic_rawtp_path+0x2a00>
    cbee:      	leaq	0x18(%r12), %rbx
    cbf3:      	movl	$0x4, %eax
    cbf8:      	movq	%rbp, %rdi
    cbfb:      	movl	$0x8, %esi
    cc00:      	movq	%rbx, %rdx
    cc03:      	callq	*%rax
    cc05:      	cmpq	%r12, (%rsp)
    cc09:      	je	0xcce0 <generic_rawtp_path+0x2a00>
    cc0f:      	movl	$0x4, %eax
    cc14:      	leaq	0x8(%rsp), %rdi
    cc19:      	movl	$0x8, %esi
    cc1e:      	movq	%rbx, %rdx
    cc21:      	callq	*%rax
    cc23:      	addq	$0x20, %r12
    cc27:      	movl	$0x4, %eax
    cc2c:      	leaq	0x58(%rsp), %rdi
    cc31:      	movl	$0x10, %ecx
    cc36:      	movl	$0x10, %esi
    cc3b:      	movq	%r12, %rdx
    cc3e:      	callq	*%rax
    cc40:      	movq	0x28(%rsp), %rbx
    cc45:      	movq	0x48(%rsp), %rax
    cc4a:      	movl	0x5c(%rsp), %r15d
    cc4f:      	subq	%rbx, %rax
    cc52:      	movl	0x50(%rsp), %r12d
    cc57:      	movl	%r15d, %edx
    cc5a:      	subl	%r12d, %edx
    cc5d:      	movl	$0x0, %ecx
    cc62:      	cmovbl	%ecx, %edx
    cc65:      	addq	0x60(%rsp), %rdx
    cc6a:      	xorl	%esi, %esi
    cc6c:      	cmpl	%r15d, %r12d
    cc6f:      	seta	%sil
    cc73:      	movl	%r15d, %ecx
    cc76:      	cmovbl	%r12d, %ecx
    cc7a:      	addl	%ecx, %esi
    cc7c:      	movl	%r12d, %edi
    cc7f:      	subl	%esi, %edi
    cc81:      	movl	%edi, 0x50(%rsp)
    cc85:      	subq	%rsi, %rax
    cc88:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    cc8e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cc94:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    cc9a:      	cmpl	%r15d, %r12d
    cc9d:      	jbe	0xcca3 <generic_rawtp_path+0x29c3>
    cc9f:      	movb	$0x2f, (%rbx,%rax)
    cca3:      	xorl	%edi, %edi
    cca5:      	cmpl	%r15d, %r12d
    cca8:      	seta	%dil
    ccac:      	movzbl	%cl, %esi
    ccaf:      	addq	%rax, %rbx
    ccb2:      	addq	%rbx, %rdi
    ccb5:      	movl	$0x4, %eax
    ccba:      	callq	*%rax
    ccbc:      	movq	%rbx, 0x48(%rsp)
    ccc1:      	cmpl	%r15d, %r12d
    ccc4:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ccca:      	movq	0x8(%rsp), %r12
    cccf:      	movq	%r12, 0x30(%rsp)
    ccd4:      	movq	0x38(%rsp), %rdx
    ccd9:      	movq	0x40(%rsp), %r15
    ccde:      	jmp	0xcd31 <generic_rawtp_path+0x2a51>
    cce0:      	leaq	0x10(%r15), %rdx
    cce4:      	movl	$0x4, %eax
    cce9:      	movq	%rbp, %rdi
    ccec:      	movl	$0x8, %esi
    ccf1:      	callq	*%rax
    ccf3:      	movq	0x40(%rsp), %rax
    ccf8:      	cmpq	(%rsp), %rax
    ccfc:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    cd02:      	addq	$0x18, %r15
    cd06:      	movl	$0x4, %eax
    cd0b:      	leaq	0x30(%rsp), %rdi
    cd10:      	movl	$0x8, %esi
    cd15:      	movq	%r15, %rdx
    cd18:      	callq	*%rax
    cd1a:      	movq	(%rsp), %r15
    cd1e:      	movq	%r15, 0x40(%rsp)
    cd23:      	leaq	0x20(%r15), %rdx
    cd27:      	movq	%rdx, 0x38(%rsp)
    cd2c:      	movq	0x30(%rsp), %r12
    cd31:      	cmpq	0x18(%rsp), %r12
    cd36:      	jne	0xcd43 <generic_rawtp_path+0x2a63>
    cd38:      	cmpq	0x20(%rsp), %rdx
    cd3d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    cd43:      	movl	$0x4, %eax
    cd48:      	leaq	0x10(%rsp), %rdi
    cd4d:      	movl	$0x8, %esi
    cd52:      	callq	*%rax
    cd54:      	cmpq	0x10(%rsp), %r12
    cd59:      	je	0xce51 <generic_rawtp_path+0x2b71>
    cd5f:      	leaq	0x18(%r12), %rbx
    cd64:      	movl	$0x4, %eax
    cd69:      	movq	%rbp, %rdi
    cd6c:      	movl	$0x8, %esi
    cd71:      	movq	%rbx, %rdx
    cd74:      	callq	*%rax
    cd76:      	cmpq	%r12, (%rsp)
    cd7a:      	je	0xce51 <generic_rawtp_path+0x2b71>
    cd80:      	movl	$0x4, %eax
    cd85:      	leaq	0x8(%rsp), %rdi
    cd8a:      	movl	$0x8, %esi
    cd8f:      	movq	%rbx, %rdx
    cd92:      	callq	*%rax
    cd94:      	addq	$0x20, %r12
    cd98:      	movl	$0x4, %eax
    cd9d:      	leaq	0x58(%rsp), %rdi
    cda2:      	movl	$0x10, %ecx
    cda7:      	movl	$0x10, %esi
    cdac:      	movq	%r12, %rdx
    cdaf:      	callq	*%rax
    cdb1:      	movq	0x28(%rsp), %rbx
    cdb6:      	movq	0x48(%rsp), %rax
    cdbb:      	movl	0x5c(%rsp), %r15d
    cdc0:      	subq	%rbx, %rax
    cdc3:      	movl	0x50(%rsp), %r12d
    cdc8:      	movl	%r15d, %edx
    cdcb:      	subl	%r12d, %edx
    cdce:      	movl	$0x0, %ecx
    cdd3:      	cmovbl	%ecx, %edx
    cdd6:      	addq	0x60(%rsp), %rdx
    cddb:      	xorl	%esi, %esi
    cddd:      	cmpl	%r15d, %r12d
    cde0:      	seta	%sil
    cde4:      	movl	%r15d, %ecx
    cde7:      	cmovbl	%r12d, %ecx
    cdeb:      	addl	%ecx, %esi
    cded:      	movl	%r12d, %edi
    cdf0:      	subl	%esi, %edi
    cdf2:      	movl	%edi, 0x50(%rsp)
    cdf6:      	subq	%rsi, %rax
    cdf9:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    cdff:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ce05:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    ce0b:      	cmpl	%r15d, %r12d
    ce0e:      	jbe	0xce14 <generic_rawtp_path+0x2b34>
    ce10:      	movb	$0x2f, (%rbx,%rax)
    ce14:      	xorl	%edi, %edi
    ce16:      	cmpl	%r15d, %r12d
    ce19:      	seta	%dil
    ce1d:      	movzbl	%cl, %esi
    ce20:      	addq	%rax, %rbx
    ce23:      	addq	%rbx, %rdi
    ce26:      	movl	$0x4, %eax
    ce2b:      	callq	*%rax
    ce2d:      	movq	%rbx, 0x48(%rsp)
    ce32:      	cmpl	%r15d, %r12d
    ce35:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ce3b:      	movq	0x8(%rsp), %r12
    ce40:      	movq	%r12, 0x30(%rsp)
    ce45:      	movq	0x38(%rsp), %rdx
    ce4a:      	movq	0x40(%rsp), %r15
    ce4f:      	jmp	0xcea2 <generic_rawtp_path+0x2bc2>
    ce51:      	leaq	0x10(%r15), %rdx
    ce55:      	movl	$0x4, %eax
    ce5a:      	movq	%rbp, %rdi
    ce5d:      	movl	$0x8, %esi
    ce62:      	callq	*%rax
    ce64:      	movq	0x40(%rsp), %rax
    ce69:      	cmpq	(%rsp), %rax
    ce6d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ce73:      	addq	$0x18, %r15
    ce77:      	movl	$0x4, %eax
    ce7c:      	leaq	0x30(%rsp), %rdi
    ce81:      	movl	$0x8, %esi
    ce86:      	movq	%r15, %rdx
    ce89:      	callq	*%rax
    ce8b:      	movq	(%rsp), %r15
    ce8f:      	movq	%r15, 0x40(%rsp)
    ce94:      	leaq	0x20(%r15), %rdx
    ce98:      	movq	%rdx, 0x38(%rsp)
    ce9d:      	movq	0x30(%rsp), %r12
    cea2:      	cmpq	0x18(%rsp), %r12
    cea7:      	jne	0xceb4 <generic_rawtp_path+0x2bd4>
    cea9:      	cmpq	0x20(%rsp), %rdx
    ceae:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ceb4:      	movl	$0x4, %eax
    ceb9:      	leaq	0x10(%rsp), %rdi
    cebe:      	movl	$0x8, %esi
    cec3:      	callq	*%rax
    cec5:      	cmpq	0x10(%rsp), %r12
    ceca:      	je	0xcfc2 <generic_rawtp_path+0x2ce2>
    ced0:      	leaq	0x18(%r12), %rbx
    ced5:      	movl	$0x4, %eax
    ceda:      	movq	%rbp, %rdi
    cedd:      	movl	$0x8, %esi
    cee2:      	movq	%rbx, %rdx
    cee5:      	callq	*%rax
    cee7:      	cmpq	%r12, (%rsp)
    ceeb:      	je	0xcfc2 <generic_rawtp_path+0x2ce2>
    cef1:      	movl	$0x4, %eax
    cef6:      	leaq	0x8(%rsp), %rdi
    cefb:      	movl	$0x8, %esi
    cf00:      	movq	%rbx, %rdx
    cf03:      	callq	*%rax
    cf05:      	addq	$0x20, %r12
    cf09:      	movl	$0x4, %eax
    cf0e:      	leaq	0x58(%rsp), %rdi
    cf13:      	movl	$0x10, %ecx
    cf18:      	movl	$0x10, %esi
    cf1d:      	movq	%r12, %rdx
    cf20:      	callq	*%rax
    cf22:      	movq	0x28(%rsp), %rbx
    cf27:      	movq	0x48(%rsp), %rax
    cf2c:      	movl	0x5c(%rsp), %r15d
    cf31:      	subq	%rbx, %rax
    cf34:      	movl	0x50(%rsp), %r12d
    cf39:      	movl	%r15d, %edx
    cf3c:      	subl	%r12d, %edx
    cf3f:      	movl	$0x0, %ecx
    cf44:      	cmovbl	%ecx, %edx
    cf47:      	addq	0x60(%rsp), %rdx
    cf4c:      	xorl	%esi, %esi
    cf4e:      	cmpl	%r15d, %r12d
    cf51:      	seta	%sil
    cf55:      	movl	%r15d, %ecx
    cf58:      	cmovbl	%r12d, %ecx
    cf5c:      	addl	%ecx, %esi
    cf5e:      	movl	%r12d, %edi
    cf61:      	subl	%esi, %edi
    cf63:      	movl	%edi, 0x50(%rsp)
    cf67:      	subq	%rsi, %rax
    cf6a:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    cf70:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cf76:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    cf7c:      	cmpl	%r15d, %r12d
    cf7f:      	jbe	0xcf85 <generic_rawtp_path+0x2ca5>
    cf81:      	movb	$0x2f, (%rbx,%rax)
    cf85:      	xorl	%edi, %edi
    cf87:      	cmpl	%r15d, %r12d
    cf8a:      	seta	%dil
    cf8e:      	movzbl	%cl, %esi
    cf91:      	addq	%rax, %rbx
    cf94:      	addq	%rbx, %rdi
    cf97:      	movl	$0x4, %eax
    cf9c:      	callq	*%rax
    cf9e:      	movq	%rbx, 0x48(%rsp)
    cfa3:      	cmpl	%r15d, %r12d
    cfa6:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    cfac:      	movq	0x8(%rsp), %r12
    cfb1:      	movq	%r12, 0x30(%rsp)
    cfb6:      	movq	0x38(%rsp), %rdx
    cfbb:      	movq	0x40(%rsp), %r15
    cfc0:      	jmp	0xd013 <generic_rawtp_path+0x2d33>
    cfc2:      	leaq	0x10(%r15), %rdx
    cfc6:      	movl	$0x4, %eax
    cfcb:      	movq	%rbp, %rdi
    cfce:      	movl	$0x8, %esi
    cfd3:      	callq	*%rax
    cfd5:      	movq	0x40(%rsp), %rax
    cfda:      	cmpq	(%rsp), %rax
    cfde:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    cfe4:      	addq	$0x18, %r15
    cfe8:      	movl	$0x4, %eax
    cfed:      	leaq	0x30(%rsp), %rdi
    cff2:      	movl	$0x8, %esi
    cff7:      	movq	%r15, %rdx
    cffa:      	callq	*%rax
    cffc:      	movq	(%rsp), %r15
    d000:      	movq	%r15, 0x40(%rsp)
    d005:      	leaq	0x20(%r15), %rdx
    d009:      	movq	%rdx, 0x38(%rsp)
    d00e:      	movq	0x30(%rsp), %r12
    d013:      	cmpq	0x18(%rsp), %r12
    d018:      	jne	0xd025 <generic_rawtp_path+0x2d45>
    d01a:      	cmpq	0x20(%rsp), %rdx
    d01f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d025:      	movl	$0x4, %eax
    d02a:      	leaq	0x10(%rsp), %rdi
    d02f:      	movl	$0x8, %esi
    d034:      	callq	*%rax
    d036:      	cmpq	0x10(%rsp), %r12
    d03b:      	je	0xd133 <generic_rawtp_path+0x2e53>
    d041:      	leaq	0x18(%r12), %rbx
    d046:      	movl	$0x4, %eax
    d04b:      	movq	%rbp, %rdi
    d04e:      	movl	$0x8, %esi
    d053:      	movq	%rbx, %rdx
    d056:      	callq	*%rax
    d058:      	cmpq	%r12, (%rsp)
    d05c:      	je	0xd133 <generic_rawtp_path+0x2e53>
    d062:      	movl	$0x4, %eax
    d067:      	leaq	0x8(%rsp), %rdi
    d06c:      	movl	$0x8, %esi
    d071:      	movq	%rbx, %rdx
    d074:      	callq	*%rax
    d076:      	addq	$0x20, %r12
    d07a:      	movl	$0x4, %eax
    d07f:      	leaq	0x58(%rsp), %rdi
    d084:      	movl	$0x10, %ecx
    d089:      	movl	$0x10, %esi
    d08e:      	movq	%r12, %rdx
    d091:      	callq	*%rax
    d093:      	movq	0x28(%rsp), %rbx
    d098:      	movq	0x48(%rsp), %rax
    d09d:      	movl	0x5c(%rsp), %r15d
    d0a2:      	subq	%rbx, %rax
    d0a5:      	movl	0x50(%rsp), %r12d
    d0aa:      	movl	%r15d, %edx
    d0ad:      	subl	%r12d, %edx
    d0b0:      	movl	$0x0, %ecx
    d0b5:      	cmovbl	%ecx, %edx
    d0b8:      	addq	0x60(%rsp), %rdx
    d0bd:      	xorl	%esi, %esi
    d0bf:      	cmpl	%r15d, %r12d
    d0c2:      	seta	%sil
    d0c6:      	movl	%r15d, %ecx
    d0c9:      	cmovbl	%r12d, %ecx
    d0cd:      	addl	%ecx, %esi
    d0cf:      	movl	%r12d, %edi
    d0d2:      	subl	%esi, %edi
    d0d4:      	movl	%edi, 0x50(%rsp)
    d0d8:      	subq	%rsi, %rax
    d0db:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d0e1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d0e7:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d0ed:      	cmpl	%r15d, %r12d
    d0f0:      	jbe	0xd0f6 <generic_rawtp_path+0x2e16>
    d0f2:      	movb	$0x2f, (%rbx,%rax)
    d0f6:      	xorl	%edi, %edi
    d0f8:      	cmpl	%r15d, %r12d
    d0fb:      	seta	%dil
    d0ff:      	movzbl	%cl, %esi
    d102:      	addq	%rax, %rbx
    d105:      	addq	%rbx, %rdi
    d108:      	movl	$0x4, %eax
    d10d:      	callq	*%rax
    d10f:      	movq	%rbx, 0x48(%rsp)
    d114:      	cmpl	%r15d, %r12d
    d117:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d11d:      	movq	0x8(%rsp), %r12
    d122:      	movq	%r12, 0x30(%rsp)
    d127:      	movq	0x38(%rsp), %rdx
    d12c:      	movq	0x40(%rsp), %r15
    d131:      	jmp	0xd184 <generic_rawtp_path+0x2ea4>
    d133:      	leaq	0x10(%r15), %rdx
    d137:      	movl	$0x4, %eax
    d13c:      	movq	%rbp, %rdi
    d13f:      	movl	$0x8, %esi
    d144:      	callq	*%rax
    d146:      	movq	0x40(%rsp), %rax
    d14b:      	cmpq	(%rsp), %rax
    d14f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d155:      	addq	$0x18, %r15
    d159:      	movl	$0x4, %eax
    d15e:      	leaq	0x30(%rsp), %rdi
    d163:      	movl	$0x8, %esi
    d168:      	movq	%r15, %rdx
    d16b:      	callq	*%rax
    d16d:      	movq	(%rsp), %r15
    d171:      	movq	%r15, 0x40(%rsp)
    d176:      	leaq	0x20(%r15), %rdx
    d17a:      	movq	%rdx, 0x38(%rsp)
    d17f:      	movq	0x30(%rsp), %r12
    d184:      	cmpq	0x18(%rsp), %r12
    d189:      	jne	0xd196 <generic_rawtp_path+0x2eb6>
    d18b:      	cmpq	0x20(%rsp), %rdx
    d190:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d196:      	movl	$0x4, %eax
    d19b:      	leaq	0x10(%rsp), %rdi
    d1a0:      	movl	$0x8, %esi
    d1a5:      	callq	*%rax
    d1a7:      	cmpq	0x10(%rsp), %r12
    d1ac:      	je	0xd2a4 <generic_rawtp_path+0x2fc4>
    d1b2:      	leaq	0x18(%r12), %rbx
    d1b7:      	movl	$0x4, %eax
    d1bc:      	movq	%rbp, %rdi
    d1bf:      	movl	$0x8, %esi
    d1c4:      	movq	%rbx, %rdx
    d1c7:      	callq	*%rax
    d1c9:      	cmpq	%r12, (%rsp)
    d1cd:      	je	0xd2a4 <generic_rawtp_path+0x2fc4>
    d1d3:      	movl	$0x4, %eax
    d1d8:      	leaq	0x8(%rsp), %rdi
    d1dd:      	movl	$0x8, %esi
    d1e2:      	movq	%rbx, %rdx
    d1e5:      	callq	*%rax
    d1e7:      	addq	$0x20, %r12
    d1eb:      	movl	$0x4, %eax
    d1f0:      	leaq	0x58(%rsp), %rdi
    d1f5:      	movl	$0x10, %ecx
    d1fa:      	movl	$0x10, %esi
    d1ff:      	movq	%r12, %rdx
    d202:      	callq	*%rax
    d204:      	movq	0x28(%rsp), %rbx
    d209:      	movq	0x48(%rsp), %rax
    d20e:      	movl	0x5c(%rsp), %r15d
    d213:      	subq	%rbx, %rax
    d216:      	movl	0x50(%rsp), %r12d
    d21b:      	movl	%r15d, %edx
    d21e:      	subl	%r12d, %edx
    d221:      	movl	$0x0, %ecx
    d226:      	cmovbl	%ecx, %edx
    d229:      	addq	0x60(%rsp), %rdx
    d22e:      	xorl	%esi, %esi
    d230:      	cmpl	%r15d, %r12d
    d233:      	seta	%sil
    d237:      	movl	%r15d, %ecx
    d23a:      	cmovbl	%r12d, %ecx
    d23e:      	addl	%ecx, %esi
    d240:      	movl	%r12d, %edi
    d243:      	subl	%esi, %edi
    d245:      	movl	%edi, 0x50(%rsp)
    d249:      	subq	%rsi, %rax
    d24c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d252:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d258:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d25e:      	cmpl	%r15d, %r12d
    d261:      	jbe	0xd267 <generic_rawtp_path+0x2f87>
    d263:      	movb	$0x2f, (%rbx,%rax)
    d267:      	xorl	%edi, %edi
    d269:      	cmpl	%r15d, %r12d
    d26c:      	seta	%dil
    d270:      	movzbl	%cl, %esi
    d273:      	addq	%rax, %rbx
    d276:      	addq	%rbx, %rdi
    d279:      	movl	$0x4, %eax
    d27e:      	callq	*%rax
    d280:      	movq	%rbx, 0x48(%rsp)
    d285:      	cmpl	%r15d, %r12d
    d288:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d28e:      	movq	0x8(%rsp), %r12
    d293:      	movq	%r12, 0x30(%rsp)
    d298:      	movq	0x38(%rsp), %rdx
    d29d:      	movq	0x40(%rsp), %r15
    d2a2:      	jmp	0xd2f5 <generic_rawtp_path+0x3015>
    d2a4:      	leaq	0x10(%r15), %rdx
    d2a8:      	movl	$0x4, %eax
    d2ad:      	movq	%rbp, %rdi
    d2b0:      	movl	$0x8, %esi
    d2b5:      	callq	*%rax
    d2b7:      	movq	0x40(%rsp), %rax
    d2bc:      	cmpq	(%rsp), %rax
    d2c0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d2c6:      	addq	$0x18, %r15
    d2ca:      	movl	$0x4, %eax
    d2cf:      	leaq	0x30(%rsp), %rdi
    d2d4:      	movl	$0x8, %esi
    d2d9:      	movq	%r15, %rdx
    d2dc:      	callq	*%rax
    d2de:      	movq	(%rsp), %r15
    d2e2:      	movq	%r15, 0x40(%rsp)
    d2e7:      	leaq	0x20(%r15), %rdx
    d2eb:      	movq	%rdx, 0x38(%rsp)
    d2f0:      	movq	0x30(%rsp), %r12
    d2f5:      	cmpq	0x18(%rsp), %r12
    d2fa:      	jne	0xd307 <generic_rawtp_path+0x3027>
    d2fc:      	cmpq	0x20(%rsp), %rdx
    d301:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d307:      	movl	$0x4, %eax
    d30c:      	leaq	0x10(%rsp), %rdi
    d311:      	movl	$0x8, %esi
    d316:      	callq	*%rax
    d318:      	cmpq	0x10(%rsp), %r12
    d31d:      	je	0xd415 <generic_rawtp_path+0x3135>
    d323:      	leaq	0x18(%r12), %rbx
    d328:      	movl	$0x4, %eax
    d32d:      	movq	%rbp, %rdi
    d330:      	movl	$0x8, %esi
    d335:      	movq	%rbx, %rdx
    d338:      	callq	*%rax
    d33a:      	cmpq	%r12, (%rsp)
    d33e:      	je	0xd415 <generic_rawtp_path+0x3135>
    d344:      	movl	$0x4, %eax
    d349:      	leaq	0x8(%rsp), %rdi
    d34e:      	movl	$0x8, %esi
    d353:      	movq	%rbx, %rdx
    d356:      	callq	*%rax
    d358:      	addq	$0x20, %r12
    d35c:      	movl	$0x4, %eax
    d361:      	leaq	0x58(%rsp), %rdi
    d366:      	movl	$0x10, %ecx
    d36b:      	movl	$0x10, %esi
    d370:      	movq	%r12, %rdx
    d373:      	callq	*%rax
    d375:      	movq	0x28(%rsp), %rbx
    d37a:      	movq	0x48(%rsp), %rax
    d37f:      	movl	0x5c(%rsp), %r15d
    d384:      	subq	%rbx, %rax
    d387:      	movl	0x50(%rsp), %r12d
    d38c:      	movl	%r15d, %edx
    d38f:      	subl	%r12d, %edx
    d392:      	movl	$0x0, %ecx
    d397:      	cmovbl	%ecx, %edx
    d39a:      	addq	0x60(%rsp), %rdx
    d39f:      	xorl	%esi, %esi
    d3a1:      	cmpl	%r15d, %r12d
    d3a4:      	seta	%sil
    d3a8:      	movl	%r15d, %ecx
    d3ab:      	cmovbl	%r12d, %ecx
    d3af:      	addl	%ecx, %esi
    d3b1:      	movl	%r12d, %edi
    d3b4:      	subl	%esi, %edi
    d3b6:      	movl	%edi, 0x50(%rsp)
    d3ba:      	subq	%rsi, %rax
    d3bd:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d3c3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d3c9:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d3cf:      	cmpl	%r15d, %r12d
    d3d2:      	jbe	0xd3d8 <generic_rawtp_path+0x30f8>
    d3d4:      	movb	$0x2f, (%rbx,%rax)
    d3d8:      	xorl	%edi, %edi
    d3da:      	cmpl	%r15d, %r12d
    d3dd:      	seta	%dil
    d3e1:      	movzbl	%cl, %esi
    d3e4:      	addq	%rax, %rbx
    d3e7:      	addq	%rbx, %rdi
    d3ea:      	movl	$0x4, %eax
    d3ef:      	callq	*%rax
    d3f1:      	movq	%rbx, 0x48(%rsp)
    d3f6:      	cmpl	%r15d, %r12d
    d3f9:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d3ff:      	movq	0x8(%rsp), %r12
    d404:      	movq	%r12, 0x30(%rsp)
    d409:      	movq	0x38(%rsp), %rdx
    d40e:      	movq	0x40(%rsp), %r15
    d413:      	jmp	0xd466 <generic_rawtp_path+0x3186>
    d415:      	leaq	0x10(%r15), %rdx
    d419:      	movl	$0x4, %eax
    d41e:      	movq	%rbp, %rdi
    d421:      	movl	$0x8, %esi
    d426:      	callq	*%rax
    d428:      	movq	0x40(%rsp), %rax
    d42d:      	cmpq	(%rsp), %rax
    d431:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d437:      	addq	$0x18, %r15
    d43b:      	movl	$0x4, %eax
    d440:      	leaq	0x30(%rsp), %rdi
    d445:      	movl	$0x8, %esi
    d44a:      	movq	%r15, %rdx
    d44d:      	callq	*%rax
    d44f:      	movq	(%rsp), %r15
    d453:      	movq	%r15, 0x40(%rsp)
    d458:      	leaq	0x20(%r15), %rdx
    d45c:      	movq	%rdx, 0x38(%rsp)
    d461:      	movq	0x30(%rsp), %r12
    d466:      	cmpq	0x18(%rsp), %r12
    d46b:      	jne	0xd478 <generic_rawtp_path+0x3198>
    d46d:      	cmpq	0x20(%rsp), %rdx
    d472:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d478:      	movl	$0x4, %eax
    d47d:      	leaq	0x10(%rsp), %rdi
    d482:      	movl	$0x8, %esi
    d487:      	callq	*%rax
    d489:      	cmpq	0x10(%rsp), %r12
    d48e:      	je	0xd586 <generic_rawtp_path+0x32a6>
    d494:      	leaq	0x18(%r12), %rbx
    d499:      	movl	$0x4, %eax
    d49e:      	movq	%rbp, %rdi
    d4a1:      	movl	$0x8, %esi
    d4a6:      	movq	%rbx, %rdx
    d4a9:      	callq	*%rax
    d4ab:      	cmpq	%r12, (%rsp)
    d4af:      	je	0xd586 <generic_rawtp_path+0x32a6>
    d4b5:      	movl	$0x4, %eax
    d4ba:      	leaq	0x8(%rsp), %rdi
    d4bf:      	movl	$0x8, %esi
    d4c4:      	movq	%rbx, %rdx
    d4c7:      	callq	*%rax
    d4c9:      	addq	$0x20, %r12
    d4cd:      	movl	$0x4, %eax
    d4d2:      	leaq	0x58(%rsp), %rdi
    d4d7:      	movl	$0x10, %ecx
    d4dc:      	movl	$0x10, %esi
    d4e1:      	movq	%r12, %rdx
    d4e4:      	callq	*%rax
    d4e6:      	movq	0x28(%rsp), %rbx
    d4eb:      	movq	0x48(%rsp), %rax
    d4f0:      	movl	0x5c(%rsp), %r15d
    d4f5:      	subq	%rbx, %rax
    d4f8:      	movl	0x50(%rsp), %r12d
    d4fd:      	movl	%r15d, %edx
    d500:      	subl	%r12d, %edx
    d503:      	movl	$0x0, %ecx
    d508:      	cmovbl	%ecx, %edx
    d50b:      	addq	0x60(%rsp), %rdx
    d510:      	xorl	%esi, %esi
    d512:      	cmpl	%r15d, %r12d
    d515:      	seta	%sil
    d519:      	movl	%r15d, %ecx
    d51c:      	cmovbl	%r12d, %ecx
    d520:      	addl	%ecx, %esi
    d522:      	movl	%r12d, %edi
    d525:      	subl	%esi, %edi
    d527:      	movl	%edi, 0x50(%rsp)
    d52b:      	subq	%rsi, %rax
    d52e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d534:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d53a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d540:      	cmpl	%r15d, %r12d
    d543:      	jbe	0xd549 <generic_rawtp_path+0x3269>
    d545:      	movb	$0x2f, (%rbx,%rax)
    d549:      	xorl	%edi, %edi
    d54b:      	cmpl	%r15d, %r12d
    d54e:      	seta	%dil
    d552:      	movzbl	%cl, %esi
    d555:      	addq	%rax, %rbx
    d558:      	addq	%rbx, %rdi
    d55b:      	movl	$0x4, %eax
    d560:      	callq	*%rax
    d562:      	movq	%rbx, 0x48(%rsp)
    d567:      	cmpl	%r15d, %r12d
    d56a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d570:      	movq	0x8(%rsp), %r12
    d575:      	movq	%r12, 0x30(%rsp)
    d57a:      	movq	0x38(%rsp), %rdx
    d57f:      	movq	0x40(%rsp), %r15
    d584:      	jmp	0xd5d7 <generic_rawtp_path+0x32f7>
    d586:      	leaq	0x10(%r15), %rdx
    d58a:      	movl	$0x4, %eax
    d58f:      	movq	%rbp, %rdi
    d592:      	movl	$0x8, %esi
    d597:      	callq	*%rax
    d599:      	movq	0x40(%rsp), %rax
    d59e:      	cmpq	(%rsp), %rax
    d5a2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d5a8:      	addq	$0x18, %r15
    d5ac:      	movl	$0x4, %eax
    d5b1:      	leaq	0x30(%rsp), %rdi
    d5b6:      	movl	$0x8, %esi
    d5bb:      	movq	%r15, %rdx
    d5be:      	callq	*%rax
    d5c0:      	movq	(%rsp), %r15
    d5c4:      	movq	%r15, 0x40(%rsp)
    d5c9:      	leaq	0x20(%r15), %rdx
    d5cd:      	movq	%rdx, 0x38(%rsp)
    d5d2:      	movq	0x30(%rsp), %r12
    d5d7:      	cmpq	0x18(%rsp), %r12
    d5dc:      	jne	0xd5e9 <generic_rawtp_path+0x3309>
    d5de:      	cmpq	0x20(%rsp), %rdx
    d5e3:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d5e9:      	movl	$0x4, %eax
    d5ee:      	leaq	0x10(%rsp), %rdi
    d5f3:      	movl	$0x8, %esi
    d5f8:      	callq	*%rax
    d5fa:      	cmpq	0x10(%rsp), %r12
    d5ff:      	je	0xd6f7 <generic_rawtp_path+0x3417>
    d605:      	leaq	0x18(%r12), %rbx
    d60a:      	movl	$0x4, %eax
    d60f:      	movq	%rbp, %rdi
    d612:      	movl	$0x8, %esi
    d617:      	movq	%rbx, %rdx
    d61a:      	callq	*%rax
    d61c:      	cmpq	%r12, (%rsp)
    d620:      	je	0xd6f7 <generic_rawtp_path+0x3417>
    d626:      	movl	$0x4, %eax
    d62b:      	leaq	0x8(%rsp), %rdi
    d630:      	movl	$0x8, %esi
    d635:      	movq	%rbx, %rdx
    d638:      	callq	*%rax
    d63a:      	addq	$0x20, %r12
    d63e:      	movl	$0x4, %eax
    d643:      	leaq	0x58(%rsp), %rdi
    d648:      	movl	$0x10, %ecx
    d64d:      	movl	$0x10, %esi
    d652:      	movq	%r12, %rdx
    d655:      	callq	*%rax
    d657:      	movq	0x28(%rsp), %rbx
    d65c:      	movq	0x48(%rsp), %rax
    d661:      	movl	0x5c(%rsp), %r15d
    d666:      	subq	%rbx, %rax
    d669:      	movl	0x50(%rsp), %r12d
    d66e:      	movl	%r15d, %edx
    d671:      	subl	%r12d, %edx
    d674:      	movl	$0x0, %ecx
    d679:      	cmovbl	%ecx, %edx
    d67c:      	addq	0x60(%rsp), %rdx
    d681:      	xorl	%esi, %esi
    d683:      	cmpl	%r15d, %r12d
    d686:      	seta	%sil
    d68a:      	movl	%r15d, %ecx
    d68d:      	cmovbl	%r12d, %ecx
    d691:      	addl	%ecx, %esi
    d693:      	movl	%r12d, %edi
    d696:      	subl	%esi, %edi
    d698:      	movl	%edi, 0x50(%rsp)
    d69c:      	subq	%rsi, %rax
    d69f:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d6a5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d6ab:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d6b1:      	cmpl	%r15d, %r12d
    d6b4:      	jbe	0xd6ba <generic_rawtp_path+0x33da>
    d6b6:      	movb	$0x2f, (%rbx,%rax)
    d6ba:      	xorl	%edi, %edi
    d6bc:      	cmpl	%r15d, %r12d
    d6bf:      	seta	%dil
    d6c3:      	movzbl	%cl, %esi
    d6c6:      	addq	%rax, %rbx
    d6c9:      	addq	%rbx, %rdi
    d6cc:      	movl	$0x4, %eax
    d6d1:      	callq	*%rax
    d6d3:      	movq	%rbx, 0x48(%rsp)
    d6d8:      	cmpl	%r15d, %r12d
    d6db:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d6e1:      	movq	0x8(%rsp), %r12
    d6e6:      	movq	%r12, 0x30(%rsp)
    d6eb:      	movq	0x38(%rsp), %rdx
    d6f0:      	movq	0x40(%rsp), %r15
    d6f5:      	jmp	0xd748 <generic_rawtp_path+0x3468>
    d6f7:      	leaq	0x10(%r15), %rdx
    d6fb:      	movl	$0x4, %eax
    d700:      	movq	%rbp, %rdi
    d703:      	movl	$0x8, %esi
    d708:      	callq	*%rax
    d70a:      	movq	0x40(%rsp), %rax
    d70f:      	cmpq	(%rsp), %rax
    d713:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d719:      	addq	$0x18, %r15
    d71d:      	movl	$0x4, %eax
    d722:      	leaq	0x30(%rsp), %rdi
    d727:      	movl	$0x8, %esi
    d72c:      	movq	%r15, %rdx
    d72f:      	callq	*%rax
    d731:      	movq	(%rsp), %r15
    d735:      	movq	%r15, 0x40(%rsp)
    d73a:      	leaq	0x20(%r15), %rdx
    d73e:      	movq	%rdx, 0x38(%rsp)
    d743:      	movq	0x30(%rsp), %r12
    d748:      	cmpq	0x18(%rsp), %r12
    d74d:      	jne	0xd75a <generic_rawtp_path+0x347a>
    d74f:      	cmpq	0x20(%rsp), %rdx
    d754:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d75a:      	movl	$0x4, %eax
    d75f:      	leaq	0x10(%rsp), %rdi
    d764:      	movl	$0x8, %esi
    d769:      	callq	*%rax
    d76b:      	cmpq	0x10(%rsp), %r12
    d770:      	je	0xd868 <generic_rawtp_path+0x3588>
    d776:      	leaq	0x18(%r12), %rbx
    d77b:      	movl	$0x4, %eax
    d780:      	movq	%rbp, %rdi
    d783:      	movl	$0x8, %esi
    d788:      	movq	%rbx, %rdx
    d78b:      	callq	*%rax
    d78d:      	cmpq	%r12, (%rsp)
    d791:      	je	0xd868 <generic_rawtp_path+0x3588>
    d797:      	movl	$0x4, %eax
    d79c:      	leaq	0x8(%rsp), %rdi
    d7a1:      	movl	$0x8, %esi
    d7a6:      	movq	%rbx, %rdx
    d7a9:      	callq	*%rax
    d7ab:      	addq	$0x20, %r12
    d7af:      	movl	$0x4, %eax
    d7b4:      	leaq	0x58(%rsp), %rdi
    d7b9:      	movl	$0x10, %ecx
    d7be:      	movl	$0x10, %esi
    d7c3:      	movq	%r12, %rdx
    d7c6:      	callq	*%rax
    d7c8:      	movq	0x28(%rsp), %rbx
    d7cd:      	movq	0x48(%rsp), %rax
    d7d2:      	movl	0x5c(%rsp), %r15d
    d7d7:      	subq	%rbx, %rax
    d7da:      	movl	0x50(%rsp), %r12d
    d7df:      	movl	%r15d, %edx
    d7e2:      	subl	%r12d, %edx
    d7e5:      	movl	$0x0, %ecx
    d7ea:      	cmovbl	%ecx, %edx
    d7ed:      	addq	0x60(%rsp), %rdx
    d7f2:      	xorl	%esi, %esi
    d7f4:      	cmpl	%r15d, %r12d
    d7f7:      	seta	%sil
    d7fb:      	movl	%r15d, %ecx
    d7fe:      	cmovbl	%r12d, %ecx
    d802:      	addl	%ecx, %esi
    d804:      	movl	%r12d, %edi
    d807:      	subl	%esi, %edi
    d809:      	movl	%edi, 0x50(%rsp)
    d80d:      	subq	%rsi, %rax
    d810:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d816:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d81c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d822:      	cmpl	%r15d, %r12d
    d825:      	jbe	0xd82b <generic_rawtp_path+0x354b>
    d827:      	movb	$0x2f, (%rbx,%rax)
    d82b:      	xorl	%edi, %edi
    d82d:      	cmpl	%r15d, %r12d
    d830:      	seta	%dil
    d834:      	movzbl	%cl, %esi
    d837:      	addq	%rax, %rbx
    d83a:      	addq	%rbx, %rdi
    d83d:      	movl	$0x4, %eax
    d842:      	callq	*%rax
    d844:      	movq	%rbx, 0x48(%rsp)
    d849:      	cmpl	%r15d, %r12d
    d84c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d852:      	movq	0x8(%rsp), %r12
    d857:      	movq	%r12, 0x30(%rsp)
    d85c:      	movq	0x38(%rsp), %rdx
    d861:      	movq	0x40(%rsp), %r15
    d866:      	jmp	0xd8b9 <generic_rawtp_path+0x35d9>
    d868:      	leaq	0x10(%r15), %rdx
    d86c:      	movl	$0x4, %eax
    d871:      	movq	%rbp, %rdi
    d874:      	movl	$0x8, %esi
    d879:      	callq	*%rax
    d87b:      	movq	0x40(%rsp), %rax
    d880:      	cmpq	(%rsp), %rax
    d884:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d88a:      	addq	$0x18, %r15
    d88e:      	movl	$0x4, %eax
    d893:      	leaq	0x30(%rsp), %rdi
    d898:      	movl	$0x8, %esi
    d89d:      	movq	%r15, %rdx
    d8a0:      	callq	*%rax
    d8a2:      	movq	(%rsp), %r15
    d8a6:      	movq	%r15, 0x40(%rsp)
    d8ab:      	leaq	0x20(%r15), %rdx
    d8af:      	movq	%rdx, 0x38(%rsp)
    d8b4:      	movq	0x30(%rsp), %r12
    d8b9:      	cmpq	0x18(%rsp), %r12
    d8be:      	jne	0xd8cb <generic_rawtp_path+0x35eb>
    d8c0:      	cmpq	0x20(%rsp), %rdx
    d8c5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d8cb:      	movl	$0x4, %eax
    d8d0:      	leaq	0x10(%rsp), %rdi
    d8d5:      	movl	$0x8, %esi
    d8da:      	callq	*%rax
    d8dc:      	cmpq	0x10(%rsp), %r12
    d8e1:      	je	0xd9d9 <generic_rawtp_path+0x36f9>
    d8e7:      	leaq	0x18(%r12), %rbx
    d8ec:      	movl	$0x4, %eax
    d8f1:      	movq	%rbp, %rdi
    d8f4:      	movl	$0x8, %esi
    d8f9:      	movq	%rbx, %rdx
    d8fc:      	callq	*%rax
    d8fe:      	cmpq	%r12, (%rsp)
    d902:      	je	0xd9d9 <generic_rawtp_path+0x36f9>
    d908:      	movl	$0x4, %eax
    d90d:      	leaq	0x8(%rsp), %rdi
    d912:      	movl	$0x8, %esi
    d917:      	movq	%rbx, %rdx
    d91a:      	callq	*%rax
    d91c:      	addq	$0x20, %r12
    d920:      	movl	$0x4, %eax
    d925:      	leaq	0x58(%rsp), %rdi
    d92a:      	movl	$0x10, %ecx
    d92f:      	movl	$0x10, %esi
    d934:      	movq	%r12, %rdx
    d937:      	callq	*%rax
    d939:      	movq	0x28(%rsp), %rbx
    d93e:      	movq	0x48(%rsp), %rax
    d943:      	movl	0x5c(%rsp), %r15d
    d948:      	subq	%rbx, %rax
    d94b:      	movl	0x50(%rsp), %r12d
    d950:      	movl	%r15d, %edx
    d953:      	subl	%r12d, %edx
    d956:      	movl	$0x0, %ecx
    d95b:      	cmovbl	%ecx, %edx
    d95e:      	addq	0x60(%rsp), %rdx
    d963:      	xorl	%esi, %esi
    d965:      	cmpl	%r15d, %r12d
    d968:      	seta	%sil
    d96c:      	movl	%r15d, %ecx
    d96f:      	cmovbl	%r12d, %ecx
    d973:      	addl	%ecx, %esi
    d975:      	movl	%r12d, %edi
    d978:      	subl	%esi, %edi
    d97a:      	movl	%edi, 0x50(%rsp)
    d97e:      	subq	%rsi, %rax
    d981:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    d987:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d98d:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    d993:      	cmpl	%r15d, %r12d
    d996:      	jbe	0xd99c <generic_rawtp_path+0x36bc>
    d998:      	movb	$0x2f, (%rbx,%rax)
    d99c:      	xorl	%edi, %edi
    d99e:      	cmpl	%r15d, %r12d
    d9a1:      	seta	%dil
    d9a5:      	movzbl	%cl, %esi
    d9a8:      	addq	%rax, %rbx
    d9ab:      	addq	%rbx, %rdi
    d9ae:      	movl	$0x4, %eax
    d9b3:      	callq	*%rax
    d9b5:      	movq	%rbx, 0x48(%rsp)
    d9ba:      	cmpl	%r15d, %r12d
    d9bd:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    d9c3:      	movq	0x8(%rsp), %r12
    d9c8:      	movq	%r12, 0x30(%rsp)
    d9cd:      	movq	0x38(%rsp), %rdx
    d9d2:      	movq	0x40(%rsp), %r15
    d9d7:      	jmp	0xda2a <generic_rawtp_path+0x374a>
    d9d9:      	leaq	0x10(%r15), %rdx
    d9dd:      	movl	$0x4, %eax
    d9e2:      	movq	%rbp, %rdi
    d9e5:      	movl	$0x8, %esi
    d9ea:      	callq	*%rax
    d9ec:      	movq	0x40(%rsp), %rax
    d9f1:      	cmpq	(%rsp), %rax
    d9f5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    d9fb:      	addq	$0x18, %r15
    d9ff:      	movl	$0x4, %eax
    da04:      	leaq	0x30(%rsp), %rdi
    da09:      	movl	$0x8, %esi
    da0e:      	movq	%r15, %rdx
    da11:      	callq	*%rax
    da13:      	movq	(%rsp), %r15
    da17:      	movq	%r15, 0x40(%rsp)
    da1c:      	leaq	0x20(%r15), %rdx
    da20:      	movq	%rdx, 0x38(%rsp)
    da25:      	movq	0x30(%rsp), %r12
    da2a:      	cmpq	0x18(%rsp), %r12
    da2f:      	jne	0xda3c <generic_rawtp_path+0x375c>
    da31:      	cmpq	0x20(%rsp), %rdx
    da36:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    da3c:      	movl	$0x4, %eax
    da41:      	leaq	0x10(%rsp), %rdi
    da46:      	movl	$0x8, %esi
    da4b:      	callq	*%rax
    da4d:      	cmpq	0x10(%rsp), %r12
    da52:      	je	0xdb4a <generic_rawtp_path+0x386a>
    da58:      	leaq	0x18(%r12), %rbx
    da5d:      	movl	$0x4, %eax
    da62:      	movq	%rbp, %rdi
    da65:      	movl	$0x8, %esi
    da6a:      	movq	%rbx, %rdx
    da6d:      	callq	*%rax
    da6f:      	cmpq	%r12, (%rsp)
    da73:      	je	0xdb4a <generic_rawtp_path+0x386a>
    da79:      	movl	$0x4, %eax
    da7e:      	leaq	0x8(%rsp), %rdi
    da83:      	movl	$0x8, %esi
    da88:      	movq	%rbx, %rdx
    da8b:      	callq	*%rax
    da8d:      	addq	$0x20, %r12
    da91:      	movl	$0x4, %eax
    da96:      	leaq	0x58(%rsp), %rdi
    da9b:      	movl	$0x10, %ecx
    daa0:      	movl	$0x10, %esi
    daa5:      	movq	%r12, %rdx
    daa8:      	callq	*%rax
    daaa:      	movq	0x28(%rsp), %rbx
    daaf:      	movq	0x48(%rsp), %rax
    dab4:      	movl	0x5c(%rsp), %r15d
    dab9:      	subq	%rbx, %rax
    dabc:      	movl	0x50(%rsp), %r12d
    dac1:      	movl	%r15d, %edx
    dac4:      	subl	%r12d, %edx
    dac7:      	movl	$0x0, %ecx
    dacc:      	cmovbl	%ecx, %edx
    dacf:      	addq	0x60(%rsp), %rdx
    dad4:      	xorl	%esi, %esi
    dad6:      	cmpl	%r15d, %r12d
    dad9:      	seta	%sil
    dadd:      	movl	%r15d, %ecx
    dae0:      	cmovbl	%r12d, %ecx
    dae4:      	addl	%ecx, %esi
    dae6:      	movl	%r12d, %edi
    dae9:      	subl	%esi, %edi
    daeb:      	movl	%edi, 0x50(%rsp)
    daef:      	subq	%rsi, %rax
    daf2:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    daf8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dafe:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    db04:      	cmpl	%r15d, %r12d
    db07:      	jbe	0xdb0d <generic_rawtp_path+0x382d>
    db09:      	movb	$0x2f, (%rbx,%rax)
    db0d:      	xorl	%edi, %edi
    db0f:      	cmpl	%r15d, %r12d
    db12:      	seta	%dil
    db16:      	movzbl	%cl, %esi
    db19:      	addq	%rax, %rbx
    db1c:      	addq	%rbx, %rdi
    db1f:      	movl	$0x4, %eax
    db24:      	callq	*%rax
    db26:      	movq	%rbx, 0x48(%rsp)
    db2b:      	cmpl	%r15d, %r12d
    db2e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    db34:      	movq	0x8(%rsp), %r12
    db39:      	movq	%r12, 0x30(%rsp)
    db3e:      	movq	0x38(%rsp), %rdx
    db43:      	movq	0x40(%rsp), %r15
    db48:      	jmp	0xdb9b <generic_rawtp_path+0x38bb>
    db4a:      	leaq	0x10(%r15), %rdx
    db4e:      	movl	$0x4, %eax
    db53:      	movq	%rbp, %rdi
    db56:      	movl	$0x8, %esi
    db5b:      	callq	*%rax
    db5d:      	movq	0x40(%rsp), %rax
    db62:      	cmpq	(%rsp), %rax
    db66:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    db6c:      	addq	$0x18, %r15
    db70:      	movl	$0x4, %eax
    db75:      	leaq	0x30(%rsp), %rdi
    db7a:      	movl	$0x8, %esi
    db7f:      	movq	%r15, %rdx
    db82:      	callq	*%rax
    db84:      	movq	(%rsp), %r15
    db88:      	movq	%r15, 0x40(%rsp)
    db8d:      	leaq	0x20(%r15), %rdx
    db91:      	movq	%rdx, 0x38(%rsp)
    db96:      	movq	0x30(%rsp), %r12
    db9b:      	cmpq	0x18(%rsp), %r12
    dba0:      	jne	0xdbad <generic_rawtp_path+0x38cd>
    dba2:      	cmpq	0x20(%rsp), %rdx
    dba7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    dbad:      	movl	$0x4, %eax
    dbb2:      	leaq	0x10(%rsp), %rdi
    dbb7:      	movl	$0x8, %esi
    dbbc:      	callq	*%rax
    dbbe:      	cmpq	0x10(%rsp), %r12
    dbc3:      	je	0xdcbb <generic_rawtp_path+0x39db>
    dbc9:      	leaq	0x18(%r12), %rbx
    dbce:      	movl	$0x4, %eax
    dbd3:      	movq	%rbp, %rdi
    dbd6:      	movl	$0x8, %esi
    dbdb:      	movq	%rbx, %rdx
    dbde:      	callq	*%rax
    dbe0:      	cmpq	%r12, (%rsp)
    dbe4:      	je	0xdcbb <generic_rawtp_path+0x39db>
    dbea:      	movl	$0x4, %eax
    dbef:      	leaq	0x8(%rsp), %rdi
    dbf4:      	movl	$0x8, %esi
    dbf9:      	movq	%rbx, %rdx
    dbfc:      	callq	*%rax
    dbfe:      	addq	$0x20, %r12
    dc02:      	movl	$0x4, %eax
    dc07:      	leaq	0x58(%rsp), %rdi
    dc0c:      	movl	$0x10, %ecx
    dc11:      	movl	$0x10, %esi
    dc16:      	movq	%r12, %rdx
    dc19:      	callq	*%rax
    dc1b:      	movq	0x28(%rsp), %rbx
    dc20:      	movq	0x48(%rsp), %rax
    dc25:      	movl	0x5c(%rsp), %r15d
    dc2a:      	subq	%rbx, %rax
    dc2d:      	movl	0x50(%rsp), %r12d
    dc32:      	movl	%r15d, %edx
    dc35:      	subl	%r12d, %edx
    dc38:      	movl	$0x0, %ecx
    dc3d:      	cmovbl	%ecx, %edx
    dc40:      	addq	0x60(%rsp), %rdx
    dc45:      	xorl	%esi, %esi
    dc47:      	cmpl	%r15d, %r12d
    dc4a:      	seta	%sil
    dc4e:      	movl	%r15d, %ecx
    dc51:      	cmovbl	%r12d, %ecx
    dc55:      	addl	%ecx, %esi
    dc57:      	movl	%r12d, %edi
    dc5a:      	subl	%esi, %edi
    dc5c:      	movl	%edi, 0x50(%rsp)
    dc60:      	subq	%rsi, %rax
    dc63:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    dc69:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dc6f:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    dc75:      	cmpl	%r15d, %r12d
    dc78:      	jbe	0xdc7e <generic_rawtp_path+0x399e>
    dc7a:      	movb	$0x2f, (%rbx,%rax)
    dc7e:      	xorl	%edi, %edi
    dc80:      	cmpl	%r15d, %r12d
    dc83:      	seta	%dil
    dc87:      	movzbl	%cl, %esi
    dc8a:      	addq	%rax, %rbx
    dc8d:      	addq	%rbx, %rdi
    dc90:      	movl	$0x4, %eax
    dc95:      	callq	*%rax
    dc97:      	movq	%rbx, 0x48(%rsp)
    dc9c:      	cmpl	%r15d, %r12d
    dc9f:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    dca5:      	movq	0x8(%rsp), %r12
    dcaa:      	movq	%r12, 0x30(%rsp)
    dcaf:      	movq	0x38(%rsp), %rdx
    dcb4:      	movq	0x40(%rsp), %r15
    dcb9:      	jmp	0xdd0c <generic_rawtp_path+0x3a2c>
    dcbb:      	leaq	0x10(%r15), %rdx
    dcbf:      	movl	$0x4, %eax
    dcc4:      	movq	%rbp, %rdi
    dcc7:      	movl	$0x8, %esi
    dccc:      	callq	*%rax
    dcce:      	movq	0x40(%rsp), %rax
    dcd3:      	cmpq	(%rsp), %rax
    dcd7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    dcdd:      	addq	$0x18, %r15
    dce1:      	movl	$0x4, %eax
    dce6:      	leaq	0x30(%rsp), %rdi
    dceb:      	movl	$0x8, %esi
    dcf0:      	movq	%r15, %rdx
    dcf3:      	callq	*%rax
    dcf5:      	movq	(%rsp), %r15
    dcf9:      	movq	%r15, 0x40(%rsp)
    dcfe:      	leaq	0x20(%r15), %rdx
    dd02:      	movq	%rdx, 0x38(%rsp)
    dd07:      	movq	0x30(%rsp), %r12
    dd0c:      	cmpq	0x18(%rsp), %r12
    dd11:      	jne	0xdd1e <generic_rawtp_path+0x3a3e>
    dd13:      	cmpq	0x20(%rsp), %rdx
    dd18:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    dd1e:      	movl	$0x4, %eax
    dd23:      	leaq	0x10(%rsp), %rdi
    dd28:      	movl	$0x8, %esi
    dd2d:      	callq	*%rax
    dd2f:      	cmpq	0x10(%rsp), %r12
    dd34:      	je	0xde2c <generic_rawtp_path+0x3b4c>
    dd3a:      	leaq	0x18(%r12), %rbx
    dd3f:      	movl	$0x4, %eax
    dd44:      	movq	%rbp, %rdi
    dd47:      	movl	$0x8, %esi
    dd4c:      	movq	%rbx, %rdx
    dd4f:      	callq	*%rax
    dd51:      	cmpq	%r12, (%rsp)
    dd55:      	je	0xde2c <generic_rawtp_path+0x3b4c>
    dd5b:      	movl	$0x4, %eax
    dd60:      	leaq	0x8(%rsp), %rdi
    dd65:      	movl	$0x8, %esi
    dd6a:      	movq	%rbx, %rdx
    dd6d:      	callq	*%rax
    dd6f:      	addq	$0x20, %r12
    dd73:      	movl	$0x4, %eax
    dd78:      	leaq	0x58(%rsp), %rdi
    dd7d:      	movl	$0x10, %ecx
    dd82:      	movl	$0x10, %esi
    dd87:      	movq	%r12, %rdx
    dd8a:      	callq	*%rax
    dd8c:      	movq	0x28(%rsp), %rbx
    dd91:      	movq	0x48(%rsp), %rax
    dd96:      	movl	0x5c(%rsp), %r15d
    dd9b:      	subq	%rbx, %rax
    dd9e:      	movl	0x50(%rsp), %r12d
    dda3:      	movl	%r15d, %edx
    dda6:      	subl	%r12d, %edx
    dda9:      	movl	$0x0, %ecx
    ddae:      	cmovbl	%ecx, %edx
    ddb1:      	addq	0x60(%rsp), %rdx
    ddb6:      	xorl	%esi, %esi
    ddb8:      	cmpl	%r15d, %r12d
    ddbb:      	seta	%sil
    ddbf:      	movl	%r15d, %ecx
    ddc2:      	cmovbl	%r12d, %ecx
    ddc6:      	addl	%ecx, %esi
    ddc8:      	movl	%r12d, %edi
    ddcb:      	subl	%esi, %edi
    ddcd:      	movl	%edi, 0x50(%rsp)
    ddd1:      	subq	%rsi, %rax
    ddd4:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ddda:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dde0:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    dde6:      	cmpl	%r15d, %r12d
    dde9:      	jbe	0xddef <generic_rawtp_path+0x3b0f>
    ddeb:      	movb	$0x2f, (%rbx,%rax)
    ddef:      	xorl	%edi, %edi
    ddf1:      	cmpl	%r15d, %r12d
    ddf4:      	seta	%dil
    ddf8:      	movzbl	%cl, %esi
    ddfb:      	addq	%rax, %rbx
    ddfe:      	addq	%rbx, %rdi
    de01:      	movl	$0x4, %eax
    de06:      	callq	*%rax
    de08:      	movq	%rbx, 0x48(%rsp)
    de0d:      	cmpl	%r15d, %r12d
    de10:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    de16:      	movq	0x8(%rsp), %r12
    de1b:      	movq	%r12, 0x30(%rsp)
    de20:      	movq	0x38(%rsp), %rdx
    de25:      	movq	0x40(%rsp), %r15
    de2a:      	jmp	0xde7d <generic_rawtp_path+0x3b9d>
    de2c:      	leaq	0x10(%r15), %rdx
    de30:      	movl	$0x4, %eax
    de35:      	movq	%rbp, %rdi
    de38:      	movl	$0x8, %esi
    de3d:      	callq	*%rax
    de3f:      	movq	0x40(%rsp), %rax
    de44:      	cmpq	(%rsp), %rax
    de48:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    de4e:      	addq	$0x18, %r15
    de52:      	movl	$0x4, %eax
    de57:      	leaq	0x30(%rsp), %rdi
    de5c:      	movl	$0x8, %esi
    de61:      	movq	%r15, %rdx
    de64:      	callq	*%rax
    de66:      	movq	(%rsp), %r15
    de6a:      	movq	%r15, 0x40(%rsp)
    de6f:      	leaq	0x20(%r15), %rdx
    de73:      	movq	%rdx, 0x38(%rsp)
    de78:      	movq	0x30(%rsp), %r12
    de7d:      	cmpq	0x18(%rsp), %r12
    de82:      	jne	0xde8f <generic_rawtp_path+0x3baf>
    de84:      	cmpq	0x20(%rsp), %rdx
    de89:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    de8f:      	movl	$0x4, %eax
    de94:      	leaq	0x10(%rsp), %rdi
    de99:      	movl	$0x8, %esi
    de9e:      	callq	*%rax
    dea0:      	cmpq	0x10(%rsp), %r12
    dea5:      	je	0xdf9d <generic_rawtp_path+0x3cbd>
    deab:      	leaq	0x18(%r12), %rbx
    deb0:      	movl	$0x4, %eax
    deb5:      	movq	%rbp, %rdi
    deb8:      	movl	$0x8, %esi
    debd:      	movq	%rbx, %rdx
    dec0:      	callq	*%rax
    dec2:      	cmpq	%r12, (%rsp)
    dec6:      	je	0xdf9d <generic_rawtp_path+0x3cbd>
    decc:      	movl	$0x4, %eax
    ded1:      	leaq	0x8(%rsp), %rdi
    ded6:      	movl	$0x8, %esi
    dedb:      	movq	%rbx, %rdx
    dede:      	callq	*%rax
    dee0:      	addq	$0x20, %r12
    dee4:      	movl	$0x4, %eax
    dee9:      	leaq	0x58(%rsp), %rdi
    deee:      	movl	$0x10, %ecx
    def3:      	movl	$0x10, %esi
    def8:      	movq	%r12, %rdx
    defb:      	callq	*%rax
    defd:      	movq	0x28(%rsp), %rbx
    df02:      	movq	0x48(%rsp), %rax
    df07:      	movl	0x5c(%rsp), %r15d
    df0c:      	subq	%rbx, %rax
    df0f:      	movl	0x50(%rsp), %r12d
    df14:      	movl	%r15d, %edx
    df17:      	subl	%r12d, %edx
    df1a:      	movl	$0x0, %ecx
    df1f:      	cmovbl	%ecx, %edx
    df22:      	addq	0x60(%rsp), %rdx
    df27:      	xorl	%esi, %esi
    df29:      	cmpl	%r15d, %r12d
    df2c:      	seta	%sil
    df30:      	movl	%r15d, %ecx
    df33:      	cmovbl	%r12d, %ecx
    df37:      	addl	%ecx, %esi
    df39:      	movl	%r12d, %edi
    df3c:      	subl	%esi, %edi
    df3e:      	movl	%edi, 0x50(%rsp)
    df42:      	subq	%rsi, %rax
    df45:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    df4b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    df51:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    df57:      	cmpl	%r15d, %r12d
    df5a:      	jbe	0xdf60 <generic_rawtp_path+0x3c80>
    df5c:      	movb	$0x2f, (%rbx,%rax)
    df60:      	xorl	%edi, %edi
    df62:      	cmpl	%r15d, %r12d
    df65:      	seta	%dil
    df69:      	movzbl	%cl, %esi
    df6c:      	addq	%rax, %rbx
    df6f:      	addq	%rbx, %rdi
    df72:      	movl	$0x4, %eax
    df77:      	callq	*%rax
    df79:      	movq	%rbx, 0x48(%rsp)
    df7e:      	cmpl	%r15d, %r12d
    df81:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    df87:      	movq	0x8(%rsp), %r12
    df8c:      	movq	%r12, 0x30(%rsp)
    df91:      	movq	0x38(%rsp), %rdx
    df96:      	movq	0x40(%rsp), %r15
    df9b:      	jmp	0xdfee <generic_rawtp_path+0x3d0e>
    df9d:      	leaq	0x10(%r15), %rdx
    dfa1:      	movl	$0x4, %eax
    dfa6:      	movq	%rbp, %rdi
    dfa9:      	movl	$0x8, %esi
    dfae:      	callq	*%rax
    dfb0:      	movq	0x40(%rsp), %rax
    dfb5:      	cmpq	(%rsp), %rax
    dfb9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    dfbf:      	addq	$0x18, %r15
    dfc3:      	movl	$0x4, %eax
    dfc8:      	leaq	0x30(%rsp), %rdi
    dfcd:      	movl	$0x8, %esi
    dfd2:      	movq	%r15, %rdx
    dfd5:      	callq	*%rax
    dfd7:      	movq	(%rsp), %r15
    dfdb:      	movq	%r15, 0x40(%rsp)
    dfe0:      	leaq	0x20(%r15), %rdx
    dfe4:      	movq	%rdx, 0x38(%rsp)
    dfe9:      	movq	0x30(%rsp), %r12
    dfee:      	cmpq	0x18(%rsp), %r12
    dff3:      	jne	0xe000 <generic_rawtp_path+0x3d20>
    dff5:      	cmpq	0x20(%rsp), %rdx
    dffa:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e000:      	movl	$0x4, %eax
    e005:      	leaq	0x10(%rsp), %rdi
    e00a:      	movl	$0x8, %esi
    e00f:      	callq	*%rax
    e011:      	cmpq	0x10(%rsp), %r12
    e016:      	je	0xe10e <generic_rawtp_path+0x3e2e>
    e01c:      	leaq	0x18(%r12), %rbx
    e021:      	movl	$0x4, %eax
    e026:      	movq	%rbp, %rdi
    e029:      	movl	$0x8, %esi
    e02e:      	movq	%rbx, %rdx
    e031:      	callq	*%rax
    e033:      	cmpq	%r12, (%rsp)
    e037:      	je	0xe10e <generic_rawtp_path+0x3e2e>
    e03d:      	movl	$0x4, %eax
    e042:      	leaq	0x8(%rsp), %rdi
    e047:      	movl	$0x8, %esi
    e04c:      	movq	%rbx, %rdx
    e04f:      	callq	*%rax
    e051:      	addq	$0x20, %r12
    e055:      	movl	$0x4, %eax
    e05a:      	leaq	0x58(%rsp), %rdi
    e05f:      	movl	$0x10, %ecx
    e064:      	movl	$0x10, %esi
    e069:      	movq	%r12, %rdx
    e06c:      	callq	*%rax
    e06e:      	movq	0x28(%rsp), %rbx
    e073:      	movq	0x48(%rsp), %rax
    e078:      	movl	0x5c(%rsp), %r15d
    e07d:      	subq	%rbx, %rax
    e080:      	movl	0x50(%rsp), %r12d
    e085:      	movl	%r15d, %edx
    e088:      	subl	%r12d, %edx
    e08b:      	movl	$0x0, %ecx
    e090:      	cmovbl	%ecx, %edx
    e093:      	addq	0x60(%rsp), %rdx
    e098:      	xorl	%esi, %esi
    e09a:      	cmpl	%r15d, %r12d
    e09d:      	seta	%sil
    e0a1:      	movl	%r15d, %ecx
    e0a4:      	cmovbl	%r12d, %ecx
    e0a8:      	addl	%ecx, %esi
    e0aa:      	movl	%r12d, %edi
    e0ad:      	subl	%esi, %edi
    e0af:      	movl	%edi, 0x50(%rsp)
    e0b3:      	subq	%rsi, %rax
    e0b6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e0bc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e0c2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e0c8:      	cmpl	%r15d, %r12d
    e0cb:      	jbe	0xe0d1 <generic_rawtp_path+0x3df1>
    e0cd:      	movb	$0x2f, (%rbx,%rax)
    e0d1:      	xorl	%edi, %edi
    e0d3:      	cmpl	%r15d, %r12d
    e0d6:      	seta	%dil
    e0da:      	movzbl	%cl, %esi
    e0dd:      	addq	%rax, %rbx
    e0e0:      	addq	%rbx, %rdi
    e0e3:      	movl	$0x4, %eax
    e0e8:      	callq	*%rax
    e0ea:      	movq	%rbx, 0x48(%rsp)
    e0ef:      	cmpl	%r15d, %r12d
    e0f2:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e0f8:      	movq	0x8(%rsp), %r12
    e0fd:      	movq	%r12, 0x30(%rsp)
    e102:      	movq	0x38(%rsp), %rdx
    e107:      	movq	0x40(%rsp), %r15
    e10c:      	jmp	0xe15f <generic_rawtp_path+0x3e7f>
    e10e:      	leaq	0x10(%r15), %rdx
    e112:      	movl	$0x4, %eax
    e117:      	movq	%rbp, %rdi
    e11a:      	movl	$0x8, %esi
    e11f:      	callq	*%rax
    e121:      	movq	0x40(%rsp), %rax
    e126:      	cmpq	(%rsp), %rax
    e12a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e130:      	addq	$0x18, %r15
    e134:      	movl	$0x4, %eax
    e139:      	leaq	0x30(%rsp), %rdi
    e13e:      	movl	$0x8, %esi
    e143:      	movq	%r15, %rdx
    e146:      	callq	*%rax
    e148:      	movq	(%rsp), %r15
    e14c:      	movq	%r15, 0x40(%rsp)
    e151:      	leaq	0x20(%r15), %rdx
    e155:      	movq	%rdx, 0x38(%rsp)
    e15a:      	movq	0x30(%rsp), %r12
    e15f:      	cmpq	0x18(%rsp), %r12
    e164:      	jne	0xe171 <generic_rawtp_path+0x3e91>
    e166:      	cmpq	0x20(%rsp), %rdx
    e16b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e171:      	movl	$0x4, %eax
    e176:      	leaq	0x10(%rsp), %rdi
    e17b:      	movl	$0x8, %esi
    e180:      	callq	*%rax
    e182:      	cmpq	0x10(%rsp), %r12
    e187:      	je	0xe27f <generic_rawtp_path+0x3f9f>
    e18d:      	leaq	0x18(%r12), %rbx
    e192:      	movl	$0x4, %eax
    e197:      	movq	%rbp, %rdi
    e19a:      	movl	$0x8, %esi
    e19f:      	movq	%rbx, %rdx
    e1a2:      	callq	*%rax
    e1a4:      	cmpq	%r12, (%rsp)
    e1a8:      	je	0xe27f <generic_rawtp_path+0x3f9f>
    e1ae:      	movl	$0x4, %eax
    e1b3:      	leaq	0x8(%rsp), %rdi
    e1b8:      	movl	$0x8, %esi
    e1bd:      	movq	%rbx, %rdx
    e1c0:      	callq	*%rax
    e1c2:      	addq	$0x20, %r12
    e1c6:      	movl	$0x4, %eax
    e1cb:      	leaq	0x58(%rsp), %rdi
    e1d0:      	movl	$0x10, %ecx
    e1d5:      	movl	$0x10, %esi
    e1da:      	movq	%r12, %rdx
    e1dd:      	callq	*%rax
    e1df:      	movq	0x28(%rsp), %rbx
    e1e4:      	movq	0x48(%rsp), %rax
    e1e9:      	movl	0x5c(%rsp), %r15d
    e1ee:      	subq	%rbx, %rax
    e1f1:      	movl	0x50(%rsp), %r12d
    e1f6:      	movl	%r15d, %edx
    e1f9:      	subl	%r12d, %edx
    e1fc:      	movl	$0x0, %ecx
    e201:      	cmovbl	%ecx, %edx
    e204:      	addq	0x60(%rsp), %rdx
    e209:      	xorl	%esi, %esi
    e20b:      	cmpl	%r15d, %r12d
    e20e:      	seta	%sil
    e212:      	movl	%r15d, %ecx
    e215:      	cmovbl	%r12d, %ecx
    e219:      	addl	%ecx, %esi
    e21b:      	movl	%r12d, %edi
    e21e:      	subl	%esi, %edi
    e220:      	movl	%edi, 0x50(%rsp)
    e224:      	subq	%rsi, %rax
    e227:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e22d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e233:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e239:      	cmpl	%r15d, %r12d
    e23c:      	jbe	0xe242 <generic_rawtp_path+0x3f62>
    e23e:      	movb	$0x2f, (%rbx,%rax)
    e242:      	xorl	%edi, %edi
    e244:      	cmpl	%r15d, %r12d
    e247:      	seta	%dil
    e24b:      	movzbl	%cl, %esi
    e24e:      	addq	%rax, %rbx
    e251:      	addq	%rbx, %rdi
    e254:      	movl	$0x4, %eax
    e259:      	callq	*%rax
    e25b:      	movq	%rbx, 0x48(%rsp)
    e260:      	cmpl	%r15d, %r12d
    e263:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e269:      	movq	0x8(%rsp), %r12
    e26e:      	movq	%r12, 0x30(%rsp)
    e273:      	movq	0x38(%rsp), %rdx
    e278:      	movq	0x40(%rsp), %r15
    e27d:      	jmp	0xe2d0 <generic_rawtp_path+0x3ff0>
    e27f:      	leaq	0x10(%r15), %rdx
    e283:      	movl	$0x4, %eax
    e288:      	movq	%rbp, %rdi
    e28b:      	movl	$0x8, %esi
    e290:      	callq	*%rax
    e292:      	movq	0x40(%rsp), %rax
    e297:      	cmpq	(%rsp), %rax
    e29b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e2a1:      	addq	$0x18, %r15
    e2a5:      	movl	$0x4, %eax
    e2aa:      	leaq	0x30(%rsp), %rdi
    e2af:      	movl	$0x8, %esi
    e2b4:      	movq	%r15, %rdx
    e2b7:      	callq	*%rax
    e2b9:      	movq	(%rsp), %r15
    e2bd:      	movq	%r15, 0x40(%rsp)
    e2c2:      	leaq	0x20(%r15), %rdx
    e2c6:      	movq	%rdx, 0x38(%rsp)
    e2cb:      	movq	0x30(%rsp), %r12
    e2d0:      	cmpq	0x18(%rsp), %r12
    e2d5:      	jne	0xe2e2 <generic_rawtp_path+0x4002>
    e2d7:      	cmpq	0x20(%rsp), %rdx
    e2dc:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e2e2:      	movl	$0x4, %eax
    e2e7:      	leaq	0x10(%rsp), %rdi
    e2ec:      	movl	$0x8, %esi
    e2f1:      	callq	*%rax
    e2f3:      	cmpq	0x10(%rsp), %r12
    e2f8:      	je	0xe3f0 <generic_rawtp_path+0x4110>
    e2fe:      	leaq	0x18(%r12), %rbx
    e303:      	movl	$0x4, %eax
    e308:      	movq	%rbp, %rdi
    e30b:      	movl	$0x8, %esi
    e310:      	movq	%rbx, %rdx
    e313:      	callq	*%rax
    e315:      	cmpq	%r12, (%rsp)
    e319:      	je	0xe3f0 <generic_rawtp_path+0x4110>
    e31f:      	movl	$0x4, %eax
    e324:      	leaq	0x8(%rsp), %rdi
    e329:      	movl	$0x8, %esi
    e32e:      	movq	%rbx, %rdx
    e331:      	callq	*%rax
    e333:      	addq	$0x20, %r12
    e337:      	movl	$0x4, %eax
    e33c:      	leaq	0x58(%rsp), %rdi
    e341:      	movl	$0x10, %ecx
    e346:      	movl	$0x10, %esi
    e34b:      	movq	%r12, %rdx
    e34e:      	callq	*%rax
    e350:      	movq	0x28(%rsp), %rbx
    e355:      	movq	0x48(%rsp), %rax
    e35a:      	movl	0x5c(%rsp), %r15d
    e35f:      	subq	%rbx, %rax
    e362:      	movl	0x50(%rsp), %r12d
    e367:      	movl	%r15d, %edx
    e36a:      	subl	%r12d, %edx
    e36d:      	movl	$0x0, %ecx
    e372:      	cmovbl	%ecx, %edx
    e375:      	addq	0x60(%rsp), %rdx
    e37a:      	xorl	%esi, %esi
    e37c:      	cmpl	%r15d, %r12d
    e37f:      	seta	%sil
    e383:      	movl	%r15d, %ecx
    e386:      	cmovbl	%r12d, %ecx
    e38a:      	addl	%ecx, %esi
    e38c:      	movl	%r12d, %edi
    e38f:      	subl	%esi, %edi
    e391:      	movl	%edi, 0x50(%rsp)
    e395:      	subq	%rsi, %rax
    e398:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e39e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e3a4:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e3aa:      	cmpl	%r15d, %r12d
    e3ad:      	jbe	0xe3b3 <generic_rawtp_path+0x40d3>
    e3af:      	movb	$0x2f, (%rbx,%rax)
    e3b3:      	xorl	%edi, %edi
    e3b5:      	cmpl	%r15d, %r12d
    e3b8:      	seta	%dil
    e3bc:      	movzbl	%cl, %esi
    e3bf:      	addq	%rax, %rbx
    e3c2:      	addq	%rbx, %rdi
    e3c5:      	movl	$0x4, %eax
    e3ca:      	callq	*%rax
    e3cc:      	movq	%rbx, 0x48(%rsp)
    e3d1:      	cmpl	%r15d, %r12d
    e3d4:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e3da:      	movq	0x8(%rsp), %r12
    e3df:      	movq	%r12, 0x30(%rsp)
    e3e4:      	movq	0x38(%rsp), %rdx
    e3e9:      	movq	0x40(%rsp), %r15
    e3ee:      	jmp	0xe441 <generic_rawtp_path+0x4161>
    e3f0:      	leaq	0x10(%r15), %rdx
    e3f4:      	movl	$0x4, %eax
    e3f9:      	movq	%rbp, %rdi
    e3fc:      	movl	$0x8, %esi
    e401:      	callq	*%rax
    e403:      	movq	0x40(%rsp), %rax
    e408:      	cmpq	(%rsp), %rax
    e40c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e412:      	addq	$0x18, %r15
    e416:      	movl	$0x4, %eax
    e41b:      	leaq	0x30(%rsp), %rdi
    e420:      	movl	$0x8, %esi
    e425:      	movq	%r15, %rdx
    e428:      	callq	*%rax
    e42a:      	movq	(%rsp), %r15
    e42e:      	movq	%r15, 0x40(%rsp)
    e433:      	leaq	0x20(%r15), %rdx
    e437:      	movq	%rdx, 0x38(%rsp)
    e43c:      	movq	0x30(%rsp), %r12
    e441:      	cmpq	0x18(%rsp), %r12
    e446:      	jne	0xe453 <generic_rawtp_path+0x4173>
    e448:      	cmpq	0x20(%rsp), %rdx
    e44d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e453:      	movl	$0x4, %eax
    e458:      	leaq	0x10(%rsp), %rdi
    e45d:      	movl	$0x8, %esi
    e462:      	callq	*%rax
    e464:      	cmpq	0x10(%rsp), %r12
    e469:      	je	0xe561 <generic_rawtp_path+0x4281>
    e46f:      	leaq	0x18(%r12), %rbx
    e474:      	movl	$0x4, %eax
    e479:      	movq	%rbp, %rdi
    e47c:      	movl	$0x8, %esi
    e481:      	movq	%rbx, %rdx
    e484:      	callq	*%rax
    e486:      	cmpq	%r12, (%rsp)
    e48a:      	je	0xe561 <generic_rawtp_path+0x4281>
    e490:      	movl	$0x4, %eax
    e495:      	leaq	0x8(%rsp), %rdi
    e49a:      	movl	$0x8, %esi
    e49f:      	movq	%rbx, %rdx
    e4a2:      	callq	*%rax
    e4a4:      	addq	$0x20, %r12
    e4a8:      	movl	$0x4, %eax
    e4ad:      	leaq	0x58(%rsp), %rdi
    e4b2:      	movl	$0x10, %ecx
    e4b7:      	movl	$0x10, %esi
    e4bc:      	movq	%r12, %rdx
    e4bf:      	callq	*%rax
    e4c1:      	movq	0x28(%rsp), %rbx
    e4c6:      	movq	0x48(%rsp), %rax
    e4cb:      	movl	0x5c(%rsp), %r15d
    e4d0:      	subq	%rbx, %rax
    e4d3:      	movl	0x50(%rsp), %r12d
    e4d8:      	movl	%r15d, %edx
    e4db:      	subl	%r12d, %edx
    e4de:      	movl	$0x0, %ecx
    e4e3:      	cmovbl	%ecx, %edx
    e4e6:      	addq	0x60(%rsp), %rdx
    e4eb:      	xorl	%esi, %esi
    e4ed:      	cmpl	%r15d, %r12d
    e4f0:      	seta	%sil
    e4f4:      	movl	%r15d, %ecx
    e4f7:      	cmovbl	%r12d, %ecx
    e4fb:      	addl	%ecx, %esi
    e4fd:      	movl	%r12d, %edi
    e500:      	subl	%esi, %edi
    e502:      	movl	%edi, 0x50(%rsp)
    e506:      	subq	%rsi, %rax
    e509:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e50f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e515:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e51b:      	cmpl	%r15d, %r12d
    e51e:      	jbe	0xe524 <generic_rawtp_path+0x4244>
    e520:      	movb	$0x2f, (%rbx,%rax)
    e524:      	xorl	%edi, %edi
    e526:      	cmpl	%r15d, %r12d
    e529:      	seta	%dil
    e52d:      	movzbl	%cl, %esi
    e530:      	addq	%rax, %rbx
    e533:      	addq	%rbx, %rdi
    e536:      	movl	$0x4, %eax
    e53b:      	callq	*%rax
    e53d:      	movq	%rbx, 0x48(%rsp)
    e542:      	cmpl	%r15d, %r12d
    e545:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e54b:      	movq	0x8(%rsp), %r12
    e550:      	movq	%r12, 0x30(%rsp)
    e555:      	movq	0x38(%rsp), %rdx
    e55a:      	movq	0x40(%rsp), %r15
    e55f:      	jmp	0xe5b2 <generic_rawtp_path+0x42d2>
    e561:      	leaq	0x10(%r15), %rdx
    e565:      	movl	$0x4, %eax
    e56a:      	movq	%rbp, %rdi
    e56d:      	movl	$0x8, %esi
    e572:      	callq	*%rax
    e574:      	movq	0x40(%rsp), %rax
    e579:      	cmpq	(%rsp), %rax
    e57d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e583:      	addq	$0x18, %r15
    e587:      	movl	$0x4, %eax
    e58c:      	leaq	0x30(%rsp), %rdi
    e591:      	movl	$0x8, %esi
    e596:      	movq	%r15, %rdx
    e599:      	callq	*%rax
    e59b:      	movq	(%rsp), %r15
    e59f:      	movq	%r15, 0x40(%rsp)
    e5a4:      	leaq	0x20(%r15), %rdx
    e5a8:      	movq	%rdx, 0x38(%rsp)
    e5ad:      	movq	0x30(%rsp), %r12
    e5b2:      	cmpq	0x18(%rsp), %r12
    e5b7:      	jne	0xe5c4 <generic_rawtp_path+0x42e4>
    e5b9:      	cmpq	0x20(%rsp), %rdx
    e5be:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e5c4:      	movl	$0x4, %eax
    e5c9:      	leaq	0x10(%rsp), %rdi
    e5ce:      	movl	$0x8, %esi
    e5d3:      	callq	*%rax
    e5d5:      	cmpq	0x10(%rsp), %r12
    e5da:      	je	0xe6d2 <generic_rawtp_path+0x43f2>
    e5e0:      	leaq	0x18(%r12), %rbx
    e5e5:      	movl	$0x4, %eax
    e5ea:      	movq	%rbp, %rdi
    e5ed:      	movl	$0x8, %esi
    e5f2:      	movq	%rbx, %rdx
    e5f5:      	callq	*%rax
    e5f7:      	cmpq	%r12, (%rsp)
    e5fb:      	je	0xe6d2 <generic_rawtp_path+0x43f2>
    e601:      	movl	$0x4, %eax
    e606:      	leaq	0x8(%rsp), %rdi
    e60b:      	movl	$0x8, %esi
    e610:      	movq	%rbx, %rdx
    e613:      	callq	*%rax
    e615:      	addq	$0x20, %r12
    e619:      	movl	$0x4, %eax
    e61e:      	leaq	0x58(%rsp), %rdi
    e623:      	movl	$0x10, %ecx
    e628:      	movl	$0x10, %esi
    e62d:      	movq	%r12, %rdx
    e630:      	callq	*%rax
    e632:      	movq	0x28(%rsp), %rbx
    e637:      	movq	0x48(%rsp), %rax
    e63c:      	movl	0x5c(%rsp), %r15d
    e641:      	subq	%rbx, %rax
    e644:      	movl	0x50(%rsp), %r12d
    e649:      	movl	%r15d, %edx
    e64c:      	subl	%r12d, %edx
    e64f:      	movl	$0x0, %ecx
    e654:      	cmovbl	%ecx, %edx
    e657:      	addq	0x60(%rsp), %rdx
    e65c:      	xorl	%esi, %esi
    e65e:      	cmpl	%r15d, %r12d
    e661:      	seta	%sil
    e665:      	movl	%r15d, %ecx
    e668:      	cmovbl	%r12d, %ecx
    e66c:      	addl	%ecx, %esi
    e66e:      	movl	%r12d, %edi
    e671:      	subl	%esi, %edi
    e673:      	movl	%edi, 0x50(%rsp)
    e677:      	subq	%rsi, %rax
    e67a:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e680:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e686:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e68c:      	cmpl	%r15d, %r12d
    e68f:      	jbe	0xe695 <generic_rawtp_path+0x43b5>
    e691:      	movb	$0x2f, (%rbx,%rax)
    e695:      	xorl	%edi, %edi
    e697:      	cmpl	%r15d, %r12d
    e69a:      	seta	%dil
    e69e:      	movzbl	%cl, %esi
    e6a1:      	addq	%rax, %rbx
    e6a4:      	addq	%rbx, %rdi
    e6a7:      	movl	$0x4, %eax
    e6ac:      	callq	*%rax
    e6ae:      	movq	%rbx, 0x48(%rsp)
    e6b3:      	cmpl	%r15d, %r12d
    e6b6:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e6bc:      	movq	0x8(%rsp), %r12
    e6c1:      	movq	%r12, 0x30(%rsp)
    e6c6:      	movq	0x38(%rsp), %rdx
    e6cb:      	movq	0x40(%rsp), %r15
    e6d0:      	jmp	0xe723 <generic_rawtp_path+0x4443>
    e6d2:      	leaq	0x10(%r15), %rdx
    e6d6:      	movl	$0x4, %eax
    e6db:      	movq	%rbp, %rdi
    e6de:      	movl	$0x8, %esi
    e6e3:      	callq	*%rax
    e6e5:      	movq	0x40(%rsp), %rax
    e6ea:      	cmpq	(%rsp), %rax
    e6ee:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e6f4:      	addq	$0x18, %r15
    e6f8:      	movl	$0x4, %eax
    e6fd:      	leaq	0x30(%rsp), %rdi
    e702:      	movl	$0x8, %esi
    e707:      	movq	%r15, %rdx
    e70a:      	callq	*%rax
    e70c:      	movq	(%rsp), %r15
    e710:      	movq	%r15, 0x40(%rsp)
    e715:      	leaq	0x20(%r15), %rdx
    e719:      	movq	%rdx, 0x38(%rsp)
    e71e:      	movq	0x30(%rsp), %r12
    e723:      	cmpq	0x18(%rsp), %r12
    e728:      	jne	0xe735 <generic_rawtp_path+0x4455>
    e72a:      	cmpq	0x20(%rsp), %rdx
    e72f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e735:      	movl	$0x4, %eax
    e73a:      	leaq	0x10(%rsp), %rdi
    e73f:      	movl	$0x8, %esi
    e744:      	callq	*%rax
    e746:      	cmpq	0x10(%rsp), %r12
    e74b:      	je	0xe843 <generic_rawtp_path+0x4563>
    e751:      	leaq	0x18(%r12), %rbx
    e756:      	movl	$0x4, %eax
    e75b:      	movq	%rbp, %rdi
    e75e:      	movl	$0x8, %esi
    e763:      	movq	%rbx, %rdx
    e766:      	callq	*%rax
    e768:      	cmpq	%r12, (%rsp)
    e76c:      	je	0xe843 <generic_rawtp_path+0x4563>
    e772:      	movl	$0x4, %eax
    e777:      	leaq	0x8(%rsp), %rdi
    e77c:      	movl	$0x8, %esi
    e781:      	movq	%rbx, %rdx
    e784:      	callq	*%rax
    e786:      	addq	$0x20, %r12
    e78a:      	movl	$0x4, %eax
    e78f:      	leaq	0x58(%rsp), %rdi
    e794:      	movl	$0x10, %ecx
    e799:      	movl	$0x10, %esi
    e79e:      	movq	%r12, %rdx
    e7a1:      	callq	*%rax
    e7a3:      	movq	0x28(%rsp), %rbx
    e7a8:      	movq	0x48(%rsp), %rax
    e7ad:      	movl	0x5c(%rsp), %r15d
    e7b2:      	subq	%rbx, %rax
    e7b5:      	movl	0x50(%rsp), %r12d
    e7ba:      	movl	%r15d, %edx
    e7bd:      	subl	%r12d, %edx
    e7c0:      	movl	$0x0, %ecx
    e7c5:      	cmovbl	%ecx, %edx
    e7c8:      	addq	0x60(%rsp), %rdx
    e7cd:      	xorl	%esi, %esi
    e7cf:      	cmpl	%r15d, %r12d
    e7d2:      	seta	%sil
    e7d6:      	movl	%r15d, %ecx
    e7d9:      	cmovbl	%r12d, %ecx
    e7dd:      	addl	%ecx, %esi
    e7df:      	movl	%r12d, %edi
    e7e2:      	subl	%esi, %edi
    e7e4:      	movl	%edi, 0x50(%rsp)
    e7e8:      	subq	%rsi, %rax
    e7eb:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e7f1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e7f7:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e7fd:      	cmpl	%r15d, %r12d
    e800:      	jbe	0xe806 <generic_rawtp_path+0x4526>
    e802:      	movb	$0x2f, (%rbx,%rax)
    e806:      	xorl	%edi, %edi
    e808:      	cmpl	%r15d, %r12d
    e80b:      	seta	%dil
    e80f:      	movzbl	%cl, %esi
    e812:      	addq	%rax, %rbx
    e815:      	addq	%rbx, %rdi
    e818:      	movl	$0x4, %eax
    e81d:      	callq	*%rax
    e81f:      	movq	%rbx, 0x48(%rsp)
    e824:      	cmpl	%r15d, %r12d
    e827:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e82d:      	movq	0x8(%rsp), %r12
    e832:      	movq	%r12, 0x30(%rsp)
    e837:      	movq	0x38(%rsp), %rdx
    e83c:      	movq	0x40(%rsp), %r15
    e841:      	jmp	0xe894 <generic_rawtp_path+0x45b4>
    e843:      	leaq	0x10(%r15), %rdx
    e847:      	movl	$0x4, %eax
    e84c:      	movq	%rbp, %rdi
    e84f:      	movl	$0x8, %esi
    e854:      	callq	*%rax
    e856:      	movq	0x40(%rsp), %rax
    e85b:      	cmpq	(%rsp), %rax
    e85f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e865:      	addq	$0x18, %r15
    e869:      	movl	$0x4, %eax
    e86e:      	leaq	0x30(%rsp), %rdi
    e873:      	movl	$0x8, %esi
    e878:      	movq	%r15, %rdx
    e87b:      	callq	*%rax
    e87d:      	movq	(%rsp), %r15
    e881:      	movq	%r15, 0x40(%rsp)
    e886:      	leaq	0x20(%r15), %rdx
    e88a:      	movq	%rdx, 0x38(%rsp)
    e88f:      	movq	0x30(%rsp), %r12
    e894:      	cmpq	0x18(%rsp), %r12
    e899:      	jne	0xe8a6 <generic_rawtp_path+0x45c6>
    e89b:      	cmpq	0x20(%rsp), %rdx
    e8a0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e8a6:      	movl	$0x4, %eax
    e8ab:      	leaq	0x10(%rsp), %rdi
    e8b0:      	movl	$0x8, %esi
    e8b5:      	callq	*%rax
    e8b7:      	cmpq	0x10(%rsp), %r12
    e8bc:      	je	0xe9b4 <generic_rawtp_path+0x46d4>
    e8c2:      	leaq	0x18(%r12), %rbx
    e8c7:      	movl	$0x4, %eax
    e8cc:      	movq	%rbp, %rdi
    e8cf:      	movl	$0x8, %esi
    e8d4:      	movq	%rbx, %rdx
    e8d7:      	callq	*%rax
    e8d9:      	cmpq	%r12, (%rsp)
    e8dd:      	je	0xe9b4 <generic_rawtp_path+0x46d4>
    e8e3:      	movl	$0x4, %eax
    e8e8:      	leaq	0x8(%rsp), %rdi
    e8ed:      	movl	$0x8, %esi
    e8f2:      	movq	%rbx, %rdx
    e8f5:      	callq	*%rax
    e8f7:      	addq	$0x20, %r12
    e8fb:      	movl	$0x4, %eax
    e900:      	leaq	0x58(%rsp), %rdi
    e905:      	movl	$0x10, %ecx
    e90a:      	movl	$0x10, %esi
    e90f:      	movq	%r12, %rdx
    e912:      	callq	*%rax
    e914:      	movq	0x28(%rsp), %rbx
    e919:      	movq	0x48(%rsp), %rax
    e91e:      	movl	0x5c(%rsp), %r15d
    e923:      	subq	%rbx, %rax
    e926:      	movl	0x50(%rsp), %r12d
    e92b:      	movl	%r15d, %edx
    e92e:      	subl	%r12d, %edx
    e931:      	movl	$0x0, %ecx
    e936:      	cmovbl	%ecx, %edx
    e939:      	addq	0x60(%rsp), %rdx
    e93e:      	xorl	%esi, %esi
    e940:      	cmpl	%r15d, %r12d
    e943:      	seta	%sil
    e947:      	movl	%r15d, %ecx
    e94a:      	cmovbl	%r12d, %ecx
    e94e:      	addl	%ecx, %esi
    e950:      	movl	%r12d, %edi
    e953:      	subl	%esi, %edi
    e955:      	movl	%edi, 0x50(%rsp)
    e959:      	subq	%rsi, %rax
    e95c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    e962:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e968:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    e96e:      	cmpl	%r15d, %r12d
    e971:      	jbe	0xe977 <generic_rawtp_path+0x4697>
    e973:      	movb	$0x2f, (%rbx,%rax)
    e977:      	xorl	%edi, %edi
    e979:      	cmpl	%r15d, %r12d
    e97c:      	seta	%dil
    e980:      	movzbl	%cl, %esi
    e983:      	addq	%rax, %rbx
    e986:      	addq	%rbx, %rdi
    e989:      	movl	$0x4, %eax
    e98e:      	callq	*%rax
    e990:      	movq	%rbx, 0x48(%rsp)
    e995:      	cmpl	%r15d, %r12d
    e998:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    e99e:      	movq	0x8(%rsp), %r12
    e9a3:      	movq	%r12, 0x30(%rsp)
    e9a8:      	movq	0x38(%rsp), %rdx
    e9ad:      	movq	0x40(%rsp), %r15
    e9b2:      	jmp	0xea05 <generic_rawtp_path+0x4725>
    e9b4:      	leaq	0x10(%r15), %rdx
    e9b8:      	movl	$0x4, %eax
    e9bd:      	movq	%rbp, %rdi
    e9c0:      	movl	$0x8, %esi
    e9c5:      	callq	*%rax
    e9c7:      	movq	0x40(%rsp), %rax
    e9cc:      	cmpq	(%rsp), %rax
    e9d0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    e9d6:      	addq	$0x18, %r15
    e9da:      	movl	$0x4, %eax
    e9df:      	leaq	0x30(%rsp), %rdi
    e9e4:      	movl	$0x8, %esi
    e9e9:      	movq	%r15, %rdx
    e9ec:      	callq	*%rax
    e9ee:      	movq	(%rsp), %r15
    e9f2:      	movq	%r15, 0x40(%rsp)
    e9f7:      	leaq	0x20(%r15), %rdx
    e9fb:      	movq	%rdx, 0x38(%rsp)
    ea00:      	movq	0x30(%rsp), %r12
    ea05:      	cmpq	0x18(%rsp), %r12
    ea0a:      	jne	0xea17 <generic_rawtp_path+0x4737>
    ea0c:      	cmpq	0x20(%rsp), %rdx
    ea11:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ea17:      	movl	$0x4, %eax
    ea1c:      	leaq	0x10(%rsp), %rdi
    ea21:      	movl	$0x8, %esi
    ea26:      	callq	*%rax
    ea28:      	cmpq	0x10(%rsp), %r12
    ea2d:      	je	0xeb25 <generic_rawtp_path+0x4845>
    ea33:      	leaq	0x18(%r12), %rbx
    ea38:      	movl	$0x4, %eax
    ea3d:      	movq	%rbp, %rdi
    ea40:      	movl	$0x8, %esi
    ea45:      	movq	%rbx, %rdx
    ea48:      	callq	*%rax
    ea4a:      	cmpq	%r12, (%rsp)
    ea4e:      	je	0xeb25 <generic_rawtp_path+0x4845>
    ea54:      	movl	$0x4, %eax
    ea59:      	leaq	0x8(%rsp), %rdi
    ea5e:      	movl	$0x8, %esi
    ea63:      	movq	%rbx, %rdx
    ea66:      	callq	*%rax
    ea68:      	addq	$0x20, %r12
    ea6c:      	movl	$0x4, %eax
    ea71:      	leaq	0x58(%rsp), %rdi
    ea76:      	movl	$0x10, %ecx
    ea7b:      	movl	$0x10, %esi
    ea80:      	movq	%r12, %rdx
    ea83:      	callq	*%rax
    ea85:      	movq	0x28(%rsp), %rbx
    ea8a:      	movq	0x48(%rsp), %rax
    ea8f:      	movl	0x5c(%rsp), %r15d
    ea94:      	subq	%rbx, %rax
    ea97:      	movl	0x50(%rsp), %r12d
    ea9c:      	movl	%r15d, %edx
    ea9f:      	subl	%r12d, %edx
    eaa2:      	movl	$0x0, %ecx
    eaa7:      	cmovbl	%ecx, %edx
    eaaa:      	addq	0x60(%rsp), %rdx
    eaaf:      	xorl	%esi, %esi
    eab1:      	cmpl	%r15d, %r12d
    eab4:      	seta	%sil
    eab8:      	movl	%r15d, %ecx
    eabb:      	cmovbl	%r12d, %ecx
    eabf:      	addl	%ecx, %esi
    eac1:      	movl	%r12d, %edi
    eac4:      	subl	%esi, %edi
    eac6:      	movl	%edi, 0x50(%rsp)
    eaca:      	subq	%rsi, %rax
    eacd:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ead3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ead9:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    eadf:      	cmpl	%r15d, %r12d
    eae2:      	jbe	0xeae8 <generic_rawtp_path+0x4808>
    eae4:      	movb	$0x2f, (%rbx,%rax)
    eae8:      	xorl	%edi, %edi
    eaea:      	cmpl	%r15d, %r12d
    eaed:      	seta	%dil
    eaf1:      	movzbl	%cl, %esi
    eaf4:      	addq	%rax, %rbx
    eaf7:      	addq	%rbx, %rdi
    eafa:      	movl	$0x4, %eax
    eaff:      	callq	*%rax
    eb01:      	movq	%rbx, 0x48(%rsp)
    eb06:      	cmpl	%r15d, %r12d
    eb09:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    eb0f:      	movq	0x8(%rsp), %r12
    eb14:      	movq	%r12, 0x30(%rsp)
    eb19:      	movq	0x38(%rsp), %rdx
    eb1e:      	movq	0x40(%rsp), %r15
    eb23:      	jmp	0xeb76 <generic_rawtp_path+0x4896>
    eb25:      	leaq	0x10(%r15), %rdx
    eb29:      	movl	$0x4, %eax
    eb2e:      	movq	%rbp, %rdi
    eb31:      	movl	$0x8, %esi
    eb36:      	callq	*%rax
    eb38:      	movq	0x40(%rsp), %rax
    eb3d:      	cmpq	(%rsp), %rax
    eb41:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    eb47:      	addq	$0x18, %r15
    eb4b:      	movl	$0x4, %eax
    eb50:      	leaq	0x30(%rsp), %rdi
    eb55:      	movl	$0x8, %esi
    eb5a:      	movq	%r15, %rdx
    eb5d:      	callq	*%rax
    eb5f:      	movq	(%rsp), %r15
    eb63:      	movq	%r15, 0x40(%rsp)
    eb68:      	leaq	0x20(%r15), %rdx
    eb6c:      	movq	%rdx, 0x38(%rsp)
    eb71:      	movq	0x30(%rsp), %r12
    eb76:      	cmpq	0x18(%rsp), %r12
    eb7b:      	jne	0xeb88 <generic_rawtp_path+0x48a8>
    eb7d:      	cmpq	0x20(%rsp), %rdx
    eb82:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    eb88:      	movl	$0x4, %eax
    eb8d:      	leaq	0x10(%rsp), %rdi
    eb92:      	movl	$0x8, %esi
    eb97:      	callq	*%rax
    eb99:      	cmpq	0x10(%rsp), %r12
    eb9e:      	je	0xec96 <generic_rawtp_path+0x49b6>
    eba4:      	leaq	0x18(%r12), %rbx
    eba9:      	movl	$0x4, %eax
    ebae:      	movq	%rbp, %rdi
    ebb1:      	movl	$0x8, %esi
    ebb6:      	movq	%rbx, %rdx
    ebb9:      	callq	*%rax
    ebbb:      	cmpq	%r12, (%rsp)
    ebbf:      	je	0xec96 <generic_rawtp_path+0x49b6>
    ebc5:      	movl	$0x4, %eax
    ebca:      	leaq	0x8(%rsp), %rdi
    ebcf:      	movl	$0x8, %esi
    ebd4:      	movq	%rbx, %rdx
    ebd7:      	callq	*%rax
    ebd9:      	addq	$0x20, %r12
    ebdd:      	movl	$0x4, %eax
    ebe2:      	leaq	0x58(%rsp), %rdi
    ebe7:      	movl	$0x10, %ecx
    ebec:      	movl	$0x10, %esi
    ebf1:      	movq	%r12, %rdx
    ebf4:      	callq	*%rax
    ebf6:      	movq	0x28(%rsp), %rbx
    ebfb:      	movq	0x48(%rsp), %rax
    ec00:      	movl	0x5c(%rsp), %r15d
    ec05:      	subq	%rbx, %rax
    ec08:      	movl	0x50(%rsp), %r12d
    ec0d:      	movl	%r15d, %edx
    ec10:      	subl	%r12d, %edx
    ec13:      	movl	$0x0, %ecx
    ec18:      	cmovbl	%ecx, %edx
    ec1b:      	addq	0x60(%rsp), %rdx
    ec20:      	xorl	%esi, %esi
    ec22:      	cmpl	%r15d, %r12d
    ec25:      	seta	%sil
    ec29:      	movl	%r15d, %ecx
    ec2c:      	cmovbl	%r12d, %ecx
    ec30:      	addl	%ecx, %esi
    ec32:      	movl	%r12d, %edi
    ec35:      	subl	%esi, %edi
    ec37:      	movl	%edi, 0x50(%rsp)
    ec3b:      	subq	%rsi, %rax
    ec3e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ec44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ec4a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    ec50:      	cmpl	%r15d, %r12d
    ec53:      	jbe	0xec59 <generic_rawtp_path+0x4979>
    ec55:      	movb	$0x2f, (%rbx,%rax)
    ec59:      	xorl	%edi, %edi
    ec5b:      	cmpl	%r15d, %r12d
    ec5e:      	seta	%dil
    ec62:      	movzbl	%cl, %esi
    ec65:      	addq	%rax, %rbx
    ec68:      	addq	%rbx, %rdi
    ec6b:      	movl	$0x4, %eax
    ec70:      	callq	*%rax
    ec72:      	movq	%rbx, 0x48(%rsp)
    ec77:      	cmpl	%r15d, %r12d
    ec7a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ec80:      	movq	0x8(%rsp), %r12
    ec85:      	movq	%r12, 0x30(%rsp)
    ec8a:      	movq	0x38(%rsp), %rdx
    ec8f:      	movq	0x40(%rsp), %r15
    ec94:      	jmp	0xece7 <generic_rawtp_path+0x4a07>
    ec96:      	leaq	0x10(%r15), %rdx
    ec9a:      	movl	$0x4, %eax
    ec9f:      	movq	%rbp, %rdi
    eca2:      	movl	$0x8, %esi
    eca7:      	callq	*%rax
    eca9:      	movq	0x40(%rsp), %rax
    ecae:      	cmpq	(%rsp), %rax
    ecb2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ecb8:      	addq	$0x18, %r15
    ecbc:      	movl	$0x4, %eax
    ecc1:      	leaq	0x30(%rsp), %rdi
    ecc6:      	movl	$0x8, %esi
    eccb:      	movq	%r15, %rdx
    ecce:      	callq	*%rax
    ecd0:      	movq	(%rsp), %r15
    ecd4:      	movq	%r15, 0x40(%rsp)
    ecd9:      	leaq	0x20(%r15), %rdx
    ecdd:      	movq	%rdx, 0x38(%rsp)
    ece2:      	movq	0x30(%rsp), %r12
    ece7:      	cmpq	0x18(%rsp), %r12
    ecec:      	jne	0xecf9 <generic_rawtp_path+0x4a19>
    ecee:      	cmpq	0x20(%rsp), %rdx
    ecf3:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ecf9:      	movl	$0x4, %eax
    ecfe:      	leaq	0x10(%rsp), %rdi
    ed03:      	movl	$0x8, %esi
    ed08:      	callq	*%rax
    ed0a:      	cmpq	0x10(%rsp), %r12
    ed0f:      	je	0xee07 <generic_rawtp_path+0x4b27>
    ed15:      	leaq	0x18(%r12), %rbx
    ed1a:      	movl	$0x4, %eax
    ed1f:      	movq	%rbp, %rdi
    ed22:      	movl	$0x8, %esi
    ed27:      	movq	%rbx, %rdx
    ed2a:      	callq	*%rax
    ed2c:      	cmpq	%r12, (%rsp)
    ed30:      	je	0xee07 <generic_rawtp_path+0x4b27>
    ed36:      	movl	$0x4, %eax
    ed3b:      	leaq	0x8(%rsp), %rdi
    ed40:      	movl	$0x8, %esi
    ed45:      	movq	%rbx, %rdx
    ed48:      	callq	*%rax
    ed4a:      	addq	$0x20, %r12
    ed4e:      	movl	$0x4, %eax
    ed53:      	leaq	0x58(%rsp), %rdi
    ed58:      	movl	$0x10, %ecx
    ed5d:      	movl	$0x10, %esi
    ed62:      	movq	%r12, %rdx
    ed65:      	callq	*%rax
    ed67:      	movq	0x28(%rsp), %rbx
    ed6c:      	movq	0x48(%rsp), %rax
    ed71:      	movl	0x5c(%rsp), %r15d
    ed76:      	subq	%rbx, %rax
    ed79:      	movl	0x50(%rsp), %r12d
    ed7e:      	movl	%r15d, %edx
    ed81:      	subl	%r12d, %edx
    ed84:      	movl	$0x0, %ecx
    ed89:      	cmovbl	%ecx, %edx
    ed8c:      	addq	0x60(%rsp), %rdx
    ed91:      	xorl	%esi, %esi
    ed93:      	cmpl	%r15d, %r12d
    ed96:      	seta	%sil
    ed9a:      	movl	%r15d, %ecx
    ed9d:      	cmovbl	%r12d, %ecx
    eda1:      	addl	%ecx, %esi
    eda3:      	movl	%r12d, %edi
    eda6:      	subl	%esi, %edi
    eda8:      	movl	%edi, 0x50(%rsp)
    edac:      	subq	%rsi, %rax
    edaf:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    edb5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    edbb:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    edc1:      	cmpl	%r15d, %r12d
    edc4:      	jbe	0xedca <generic_rawtp_path+0x4aea>
    edc6:      	movb	$0x2f, (%rbx,%rax)
    edca:      	xorl	%edi, %edi
    edcc:      	cmpl	%r15d, %r12d
    edcf:      	seta	%dil
    edd3:      	movzbl	%cl, %esi
    edd6:      	addq	%rax, %rbx
    edd9:      	addq	%rbx, %rdi
    eddc:      	movl	$0x4, %eax
    ede1:      	callq	*%rax
    ede3:      	movq	%rbx, 0x48(%rsp)
    ede8:      	cmpl	%r15d, %r12d
    edeb:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    edf1:      	movq	0x8(%rsp), %r12
    edf6:      	movq	%r12, 0x30(%rsp)
    edfb:      	movq	0x38(%rsp), %rdx
    ee00:      	movq	0x40(%rsp), %r15
    ee05:      	jmp	0xee58 <generic_rawtp_path+0x4b78>
    ee07:      	leaq	0x10(%r15), %rdx
    ee0b:      	movl	$0x4, %eax
    ee10:      	movq	%rbp, %rdi
    ee13:      	movl	$0x8, %esi
    ee18:      	callq	*%rax
    ee1a:      	movq	0x40(%rsp), %rax
    ee1f:      	cmpq	(%rsp), %rax
    ee23:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ee29:      	addq	$0x18, %r15
    ee2d:      	movl	$0x4, %eax
    ee32:      	leaq	0x30(%rsp), %rdi
    ee37:      	movl	$0x8, %esi
    ee3c:      	movq	%r15, %rdx
    ee3f:      	callq	*%rax
    ee41:      	movq	(%rsp), %r15
    ee45:      	movq	%r15, 0x40(%rsp)
    ee4a:      	leaq	0x20(%r15), %rdx
    ee4e:      	movq	%rdx, 0x38(%rsp)
    ee53:      	movq	0x30(%rsp), %r12
    ee58:      	cmpq	0x18(%rsp), %r12
    ee5d:      	jne	0xee6a <generic_rawtp_path+0x4b8a>
    ee5f:      	cmpq	0x20(%rsp), %rdx
    ee64:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ee6a:      	movl	$0x4, %eax
    ee6f:      	leaq	0x10(%rsp), %rdi
    ee74:      	movl	$0x8, %esi
    ee79:      	callq	*%rax
    ee7b:      	cmpq	0x10(%rsp), %r12
    ee80:      	je	0xef78 <generic_rawtp_path+0x4c98>
    ee86:      	leaq	0x18(%r12), %rbx
    ee8b:      	movl	$0x4, %eax
    ee90:      	movq	%rbp, %rdi
    ee93:      	movl	$0x8, %esi
    ee98:      	movq	%rbx, %rdx
    ee9b:      	callq	*%rax
    ee9d:      	cmpq	%r12, (%rsp)
    eea1:      	je	0xef78 <generic_rawtp_path+0x4c98>
    eea7:      	movl	$0x4, %eax
    eeac:      	leaq	0x8(%rsp), %rdi
    eeb1:      	movl	$0x8, %esi
    eeb6:      	movq	%rbx, %rdx
    eeb9:      	callq	*%rax
    eebb:      	addq	$0x20, %r12
    eebf:      	movl	$0x4, %eax
    eec4:      	leaq	0x58(%rsp), %rdi
    eec9:      	movl	$0x10, %ecx
    eece:      	movl	$0x10, %esi
    eed3:      	movq	%r12, %rdx
    eed6:      	callq	*%rax
    eed8:      	movq	0x28(%rsp), %rbx
    eedd:      	movq	0x48(%rsp), %rax
    eee2:      	movl	0x5c(%rsp), %r15d
    eee7:      	subq	%rbx, %rax
    eeea:      	movl	0x50(%rsp), %r12d
    eeef:      	movl	%r15d, %edx
    eef2:      	subl	%r12d, %edx
    eef5:      	movl	$0x0, %ecx
    eefa:      	cmovbl	%ecx, %edx
    eefd:      	addq	0x60(%rsp), %rdx
    ef02:      	xorl	%esi, %esi
    ef04:      	cmpl	%r15d, %r12d
    ef07:      	seta	%sil
    ef0b:      	movl	%r15d, %ecx
    ef0e:      	cmovbl	%r12d, %ecx
    ef12:      	addl	%ecx, %esi
    ef14:      	movl	%r12d, %edi
    ef17:      	subl	%esi, %edi
    ef19:      	movl	%edi, 0x50(%rsp)
    ef1d:      	subq	%rsi, %rax
    ef20:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ef26:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ef2c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    ef32:      	cmpl	%r15d, %r12d
    ef35:      	jbe	0xef3b <generic_rawtp_path+0x4c5b>
    ef37:      	movb	$0x2f, (%rbx,%rax)
    ef3b:      	xorl	%edi, %edi
    ef3d:      	cmpl	%r15d, %r12d
    ef40:      	seta	%dil
    ef44:      	movzbl	%cl, %esi
    ef47:      	addq	%rax, %rbx
    ef4a:      	addq	%rbx, %rdi
    ef4d:      	movl	$0x4, %eax
    ef52:      	callq	*%rax
    ef54:      	movq	%rbx, 0x48(%rsp)
    ef59:      	cmpl	%r15d, %r12d
    ef5c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ef62:      	movq	0x8(%rsp), %r12
    ef67:      	movq	%r12, 0x30(%rsp)
    ef6c:      	movq	0x38(%rsp), %rdx
    ef71:      	movq	0x40(%rsp), %r15
    ef76:      	jmp	0xefc9 <generic_rawtp_path+0x4ce9>
    ef78:      	leaq	0x10(%r15), %rdx
    ef7c:      	movl	$0x4, %eax
    ef81:      	movq	%rbp, %rdi
    ef84:      	movl	$0x8, %esi
    ef89:      	callq	*%rax
    ef8b:      	movq	0x40(%rsp), %rax
    ef90:      	cmpq	(%rsp), %rax
    ef94:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ef9a:      	addq	$0x18, %r15
    ef9e:      	movl	$0x4, %eax
    efa3:      	leaq	0x30(%rsp), %rdi
    efa8:      	movl	$0x8, %esi
    efad:      	movq	%r15, %rdx
    efb0:      	callq	*%rax
    efb2:      	movq	(%rsp), %r15
    efb6:      	movq	%r15, 0x40(%rsp)
    efbb:      	leaq	0x20(%r15), %rdx
    efbf:      	movq	%rdx, 0x38(%rsp)
    efc4:      	movq	0x30(%rsp), %r12
    efc9:      	cmpq	0x18(%rsp), %r12
    efce:      	jne	0xefdb <generic_rawtp_path+0x4cfb>
    efd0:      	cmpq	0x20(%rsp), %rdx
    efd5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    efdb:      	movl	$0x4, %eax
    efe0:      	leaq	0x10(%rsp), %rdi
    efe5:      	movl	$0x8, %esi
    efea:      	callq	*%rax
    efec:      	cmpq	0x10(%rsp), %r12
    eff1:      	je	0xf0e9 <generic_rawtp_path+0x4e09>
    eff7:      	leaq	0x18(%r12), %rbx
    effc:      	movl	$0x4, %eax
    f001:      	movq	%rbp, %rdi
    f004:      	movl	$0x8, %esi
    f009:      	movq	%rbx, %rdx
    f00c:      	callq	*%rax
    f00e:      	cmpq	%r12, (%rsp)
    f012:      	je	0xf0e9 <generic_rawtp_path+0x4e09>
    f018:      	movl	$0x4, %eax
    f01d:      	leaq	0x8(%rsp), %rdi
    f022:      	movl	$0x8, %esi
    f027:      	movq	%rbx, %rdx
    f02a:      	callq	*%rax
    f02c:      	addq	$0x20, %r12
    f030:      	movl	$0x4, %eax
    f035:      	leaq	0x58(%rsp), %rdi
    f03a:      	movl	$0x10, %ecx
    f03f:      	movl	$0x10, %esi
    f044:      	movq	%r12, %rdx
    f047:      	callq	*%rax
    f049:      	movq	0x28(%rsp), %rbx
    f04e:      	movq	0x48(%rsp), %rax
    f053:      	movl	0x5c(%rsp), %r15d
    f058:      	subq	%rbx, %rax
    f05b:      	movl	0x50(%rsp), %r12d
    f060:      	movl	%r15d, %edx
    f063:      	subl	%r12d, %edx
    f066:      	movl	$0x0, %ecx
    f06b:      	cmovbl	%ecx, %edx
    f06e:      	addq	0x60(%rsp), %rdx
    f073:      	xorl	%esi, %esi
    f075:      	cmpl	%r15d, %r12d
    f078:      	seta	%sil
    f07c:      	movl	%r15d, %ecx
    f07f:      	cmovbl	%r12d, %ecx
    f083:      	addl	%ecx, %esi
    f085:      	movl	%r12d, %edi
    f088:      	subl	%esi, %edi
    f08a:      	movl	%edi, 0x50(%rsp)
    f08e:      	subq	%rsi, %rax
    f091:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f097:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f09d:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f0a3:      	cmpl	%r15d, %r12d
    f0a6:      	jbe	0xf0ac <generic_rawtp_path+0x4dcc>
    f0a8:      	movb	$0x2f, (%rbx,%rax)
    f0ac:      	xorl	%edi, %edi
    f0ae:      	cmpl	%r15d, %r12d
    f0b1:      	seta	%dil
    f0b5:      	movzbl	%cl, %esi
    f0b8:      	addq	%rax, %rbx
    f0bb:      	addq	%rbx, %rdi
    f0be:      	movl	$0x4, %eax
    f0c3:      	callq	*%rax
    f0c5:      	movq	%rbx, 0x48(%rsp)
    f0ca:      	cmpl	%r15d, %r12d
    f0cd:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f0d3:      	movq	0x8(%rsp), %r12
    f0d8:      	movq	%r12, 0x30(%rsp)
    f0dd:      	movq	0x38(%rsp), %rdx
    f0e2:      	movq	0x40(%rsp), %r15
    f0e7:      	jmp	0xf13a <generic_rawtp_path+0x4e5a>
    f0e9:      	leaq	0x10(%r15), %rdx
    f0ed:      	movl	$0x4, %eax
    f0f2:      	movq	%rbp, %rdi
    f0f5:      	movl	$0x8, %esi
    f0fa:      	callq	*%rax
    f0fc:      	movq	0x40(%rsp), %rax
    f101:      	cmpq	(%rsp), %rax
    f105:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f10b:      	addq	$0x18, %r15
    f10f:      	movl	$0x4, %eax
    f114:      	leaq	0x30(%rsp), %rdi
    f119:      	movl	$0x8, %esi
    f11e:      	movq	%r15, %rdx
    f121:      	callq	*%rax
    f123:      	movq	(%rsp), %r15
    f127:      	movq	%r15, 0x40(%rsp)
    f12c:      	leaq	0x20(%r15), %rdx
    f130:      	movq	%rdx, 0x38(%rsp)
    f135:      	movq	0x30(%rsp), %r12
    f13a:      	cmpq	0x18(%rsp), %r12
    f13f:      	jne	0xf14c <generic_rawtp_path+0x4e6c>
    f141:      	cmpq	0x20(%rsp), %rdx
    f146:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f14c:      	movl	$0x4, %eax
    f151:      	leaq	0x10(%rsp), %rdi
    f156:      	movl	$0x8, %esi
    f15b:      	callq	*%rax
    f15d:      	cmpq	0x10(%rsp), %r12
    f162:      	je	0xf25a <generic_rawtp_path+0x4f7a>
    f168:      	leaq	0x18(%r12), %rbx
    f16d:      	movl	$0x4, %eax
    f172:      	movq	%rbp, %rdi
    f175:      	movl	$0x8, %esi
    f17a:      	movq	%rbx, %rdx
    f17d:      	callq	*%rax
    f17f:      	cmpq	%r12, (%rsp)
    f183:      	je	0xf25a <generic_rawtp_path+0x4f7a>
    f189:      	movl	$0x4, %eax
    f18e:      	leaq	0x8(%rsp), %rdi
    f193:      	movl	$0x8, %esi
    f198:      	movq	%rbx, %rdx
    f19b:      	callq	*%rax
    f19d:      	addq	$0x20, %r12
    f1a1:      	movl	$0x4, %eax
    f1a6:      	leaq	0x58(%rsp), %rdi
    f1ab:      	movl	$0x10, %ecx
    f1b0:      	movl	$0x10, %esi
    f1b5:      	movq	%r12, %rdx
    f1b8:      	callq	*%rax
    f1ba:      	movq	0x28(%rsp), %rbx
    f1bf:      	movq	0x48(%rsp), %rax
    f1c4:      	movl	0x5c(%rsp), %r15d
    f1c9:      	subq	%rbx, %rax
    f1cc:      	movl	0x50(%rsp), %r12d
    f1d1:      	movl	%r15d, %edx
    f1d4:      	subl	%r12d, %edx
    f1d7:      	movl	$0x0, %ecx
    f1dc:      	cmovbl	%ecx, %edx
    f1df:      	addq	0x60(%rsp), %rdx
    f1e4:      	xorl	%esi, %esi
    f1e6:      	cmpl	%r15d, %r12d
    f1e9:      	seta	%sil
    f1ed:      	movl	%r15d, %ecx
    f1f0:      	cmovbl	%r12d, %ecx
    f1f4:      	addl	%ecx, %esi
    f1f6:      	movl	%r12d, %edi
    f1f9:      	subl	%esi, %edi
    f1fb:      	movl	%edi, 0x50(%rsp)
    f1ff:      	subq	%rsi, %rax
    f202:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f208:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f20e:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f214:      	cmpl	%r15d, %r12d
    f217:      	jbe	0xf21d <generic_rawtp_path+0x4f3d>
    f219:      	movb	$0x2f, (%rbx,%rax)
    f21d:      	xorl	%edi, %edi
    f21f:      	cmpl	%r15d, %r12d
    f222:      	seta	%dil
    f226:      	movzbl	%cl, %esi
    f229:      	addq	%rax, %rbx
    f22c:      	addq	%rbx, %rdi
    f22f:      	movl	$0x4, %eax
    f234:      	callq	*%rax
    f236:      	movq	%rbx, 0x48(%rsp)
    f23b:      	cmpl	%r15d, %r12d
    f23e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f244:      	movq	0x8(%rsp), %r12
    f249:      	movq	%r12, 0x30(%rsp)
    f24e:      	movq	0x38(%rsp), %rdx
    f253:      	movq	0x40(%rsp), %r15
    f258:      	jmp	0xf2ab <generic_rawtp_path+0x4fcb>
    f25a:      	leaq	0x10(%r15), %rdx
    f25e:      	movl	$0x4, %eax
    f263:      	movq	%rbp, %rdi
    f266:      	movl	$0x8, %esi
    f26b:      	callq	*%rax
    f26d:      	movq	0x40(%rsp), %rax
    f272:      	cmpq	(%rsp), %rax
    f276:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f27c:      	addq	$0x18, %r15
    f280:      	movl	$0x4, %eax
    f285:      	leaq	0x30(%rsp), %rdi
    f28a:      	movl	$0x8, %esi
    f28f:      	movq	%r15, %rdx
    f292:      	callq	*%rax
    f294:      	movq	(%rsp), %r15
    f298:      	movq	%r15, 0x40(%rsp)
    f29d:      	leaq	0x20(%r15), %rdx
    f2a1:      	movq	%rdx, 0x38(%rsp)
    f2a6:      	movq	0x30(%rsp), %r12
    f2ab:      	cmpq	0x18(%rsp), %r12
    f2b0:      	jne	0xf2bd <generic_rawtp_path+0x4fdd>
    f2b2:      	cmpq	0x20(%rsp), %rdx
    f2b7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f2bd:      	movl	$0x4, %eax
    f2c2:      	leaq	0x10(%rsp), %rdi
    f2c7:      	movl	$0x8, %esi
    f2cc:      	callq	*%rax
    f2ce:      	cmpq	0x10(%rsp), %r12
    f2d3:      	je	0xf3cb <generic_rawtp_path+0x50eb>
    f2d9:      	leaq	0x18(%r12), %rbx
    f2de:      	movl	$0x4, %eax
    f2e3:      	movq	%rbp, %rdi
    f2e6:      	movl	$0x8, %esi
    f2eb:      	movq	%rbx, %rdx
    f2ee:      	callq	*%rax
    f2f0:      	cmpq	%r12, (%rsp)
    f2f4:      	je	0xf3cb <generic_rawtp_path+0x50eb>
    f2fa:      	movl	$0x4, %eax
    f2ff:      	leaq	0x8(%rsp), %rdi
    f304:      	movl	$0x8, %esi
    f309:      	movq	%rbx, %rdx
    f30c:      	callq	*%rax
    f30e:      	addq	$0x20, %r12
    f312:      	movl	$0x4, %eax
    f317:      	leaq	0x58(%rsp), %rdi
    f31c:      	movl	$0x10, %ecx
    f321:      	movl	$0x10, %esi
    f326:      	movq	%r12, %rdx
    f329:      	callq	*%rax
    f32b:      	movq	0x28(%rsp), %rbx
    f330:      	movq	0x48(%rsp), %rax
    f335:      	movl	0x5c(%rsp), %r15d
    f33a:      	subq	%rbx, %rax
    f33d:      	movl	0x50(%rsp), %r12d
    f342:      	movl	%r15d, %edx
    f345:      	subl	%r12d, %edx
    f348:      	movl	$0x0, %ecx
    f34d:      	cmovbl	%ecx, %edx
    f350:      	addq	0x60(%rsp), %rdx
    f355:      	xorl	%esi, %esi
    f357:      	cmpl	%r15d, %r12d
    f35a:      	seta	%sil
    f35e:      	movl	%r15d, %ecx
    f361:      	cmovbl	%r12d, %ecx
    f365:      	addl	%ecx, %esi
    f367:      	movl	%r12d, %edi
    f36a:      	subl	%esi, %edi
    f36c:      	movl	%edi, 0x50(%rsp)
    f370:      	subq	%rsi, %rax
    f373:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f379:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f37f:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f385:      	cmpl	%r15d, %r12d
    f388:      	jbe	0xf38e <generic_rawtp_path+0x50ae>
    f38a:      	movb	$0x2f, (%rbx,%rax)
    f38e:      	xorl	%edi, %edi
    f390:      	cmpl	%r15d, %r12d
    f393:      	seta	%dil
    f397:      	movzbl	%cl, %esi
    f39a:      	addq	%rax, %rbx
    f39d:      	addq	%rbx, %rdi
    f3a0:      	movl	$0x4, %eax
    f3a5:      	callq	*%rax
    f3a7:      	movq	%rbx, 0x48(%rsp)
    f3ac:      	cmpl	%r15d, %r12d
    f3af:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f3b5:      	movq	0x8(%rsp), %r12
    f3ba:      	movq	%r12, 0x30(%rsp)
    f3bf:      	movq	0x38(%rsp), %rdx
    f3c4:      	movq	0x40(%rsp), %r15
    f3c9:      	jmp	0xf41c <generic_rawtp_path+0x513c>
    f3cb:      	leaq	0x10(%r15), %rdx
    f3cf:      	movl	$0x4, %eax
    f3d4:      	movq	%rbp, %rdi
    f3d7:      	movl	$0x8, %esi
    f3dc:      	callq	*%rax
    f3de:      	movq	0x40(%rsp), %rax
    f3e3:      	cmpq	(%rsp), %rax
    f3e7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f3ed:      	addq	$0x18, %r15
    f3f1:      	movl	$0x4, %eax
    f3f6:      	leaq	0x30(%rsp), %rdi
    f3fb:      	movl	$0x8, %esi
    f400:      	movq	%r15, %rdx
    f403:      	callq	*%rax
    f405:      	movq	(%rsp), %r15
    f409:      	movq	%r15, 0x40(%rsp)
    f40e:      	leaq	0x20(%r15), %rdx
    f412:      	movq	%rdx, 0x38(%rsp)
    f417:      	movq	0x30(%rsp), %r12
    f41c:      	cmpq	0x18(%rsp), %r12
    f421:      	jne	0xf42e <generic_rawtp_path+0x514e>
    f423:      	cmpq	0x20(%rsp), %rdx
    f428:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f42e:      	movl	$0x4, %eax
    f433:      	leaq	0x10(%rsp), %rdi
    f438:      	movl	$0x8, %esi
    f43d:      	callq	*%rax
    f43f:      	cmpq	0x10(%rsp), %r12
    f444:      	je	0xf53c <generic_rawtp_path+0x525c>
    f44a:      	leaq	0x18(%r12), %rbx
    f44f:      	movl	$0x4, %eax
    f454:      	movq	%rbp, %rdi
    f457:      	movl	$0x8, %esi
    f45c:      	movq	%rbx, %rdx
    f45f:      	callq	*%rax
    f461:      	cmpq	%r12, (%rsp)
    f465:      	je	0xf53c <generic_rawtp_path+0x525c>
    f46b:      	movl	$0x4, %eax
    f470:      	leaq	0x8(%rsp), %rdi
    f475:      	movl	$0x8, %esi
    f47a:      	movq	%rbx, %rdx
    f47d:      	callq	*%rax
    f47f:      	addq	$0x20, %r12
    f483:      	movl	$0x4, %eax
    f488:      	leaq	0x58(%rsp), %rdi
    f48d:      	movl	$0x10, %ecx
    f492:      	movl	$0x10, %esi
    f497:      	movq	%r12, %rdx
    f49a:      	callq	*%rax
    f49c:      	movq	0x28(%rsp), %rbx
    f4a1:      	movq	0x48(%rsp), %rax
    f4a6:      	movl	0x5c(%rsp), %r15d
    f4ab:      	subq	%rbx, %rax
    f4ae:      	movl	0x50(%rsp), %r12d
    f4b3:      	movl	%r15d, %edx
    f4b6:      	subl	%r12d, %edx
    f4b9:      	movl	$0x0, %ecx
    f4be:      	cmovbl	%ecx, %edx
    f4c1:      	addq	0x60(%rsp), %rdx
    f4c6:      	xorl	%esi, %esi
    f4c8:      	cmpl	%r15d, %r12d
    f4cb:      	seta	%sil
    f4cf:      	movl	%r15d, %ecx
    f4d2:      	cmovbl	%r12d, %ecx
    f4d6:      	addl	%ecx, %esi
    f4d8:      	movl	%r12d, %edi
    f4db:      	subl	%esi, %edi
    f4dd:      	movl	%edi, 0x50(%rsp)
    f4e1:      	subq	%rsi, %rax
    f4e4:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f4ea:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f4f0:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f4f6:      	cmpl	%r15d, %r12d
    f4f9:      	jbe	0xf4ff <generic_rawtp_path+0x521f>
    f4fb:      	movb	$0x2f, (%rbx,%rax)
    f4ff:      	xorl	%edi, %edi
    f501:      	cmpl	%r15d, %r12d
    f504:      	seta	%dil
    f508:      	movzbl	%cl, %esi
    f50b:      	addq	%rax, %rbx
    f50e:      	addq	%rbx, %rdi
    f511:      	movl	$0x4, %eax
    f516:      	callq	*%rax
    f518:      	movq	%rbx, 0x48(%rsp)
    f51d:      	cmpl	%r15d, %r12d
    f520:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f526:      	movq	0x8(%rsp), %r12
    f52b:      	movq	%r12, 0x30(%rsp)
    f530:      	movq	0x38(%rsp), %rdx
    f535:      	movq	0x40(%rsp), %r15
    f53a:      	jmp	0xf58d <generic_rawtp_path+0x52ad>
    f53c:      	leaq	0x10(%r15), %rdx
    f540:      	movl	$0x4, %eax
    f545:      	movq	%rbp, %rdi
    f548:      	movl	$0x8, %esi
    f54d:      	callq	*%rax
    f54f:      	movq	0x40(%rsp), %rax
    f554:      	cmpq	(%rsp), %rax
    f558:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f55e:      	addq	$0x18, %r15
    f562:      	movl	$0x4, %eax
    f567:      	leaq	0x30(%rsp), %rdi
    f56c:      	movl	$0x8, %esi
    f571:      	movq	%r15, %rdx
    f574:      	callq	*%rax
    f576:      	movq	(%rsp), %r15
    f57a:      	movq	%r15, 0x40(%rsp)
    f57f:      	leaq	0x20(%r15), %rdx
    f583:      	movq	%rdx, 0x38(%rsp)
    f588:      	movq	0x30(%rsp), %r12
    f58d:      	cmpq	0x18(%rsp), %r12
    f592:      	jne	0xf59f <generic_rawtp_path+0x52bf>
    f594:      	cmpq	0x20(%rsp), %rdx
    f599:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f59f:      	movl	$0x4, %eax
    f5a4:      	leaq	0x10(%rsp), %rdi
    f5a9:      	movl	$0x8, %esi
    f5ae:      	callq	*%rax
    f5b0:      	cmpq	0x10(%rsp), %r12
    f5b5:      	je	0xf6ad <generic_rawtp_path+0x53cd>
    f5bb:      	leaq	0x18(%r12), %rbx
    f5c0:      	movl	$0x4, %eax
    f5c5:      	movq	%rbp, %rdi
    f5c8:      	movl	$0x8, %esi
    f5cd:      	movq	%rbx, %rdx
    f5d0:      	callq	*%rax
    f5d2:      	cmpq	%r12, (%rsp)
    f5d6:      	je	0xf6ad <generic_rawtp_path+0x53cd>
    f5dc:      	movl	$0x4, %eax
    f5e1:      	leaq	0x8(%rsp), %rdi
    f5e6:      	movl	$0x8, %esi
    f5eb:      	movq	%rbx, %rdx
    f5ee:      	callq	*%rax
    f5f0:      	addq	$0x20, %r12
    f5f4:      	movl	$0x4, %eax
    f5f9:      	leaq	0x58(%rsp), %rdi
    f5fe:      	movl	$0x10, %ecx
    f603:      	movl	$0x10, %esi
    f608:      	movq	%r12, %rdx
    f60b:      	callq	*%rax
    f60d:      	movq	0x28(%rsp), %rbx
    f612:      	movq	0x48(%rsp), %rax
    f617:      	movl	0x5c(%rsp), %r15d
    f61c:      	subq	%rbx, %rax
    f61f:      	movl	0x50(%rsp), %r12d
    f624:      	movl	%r15d, %edx
    f627:      	subl	%r12d, %edx
    f62a:      	movl	$0x0, %ecx
    f62f:      	cmovbl	%ecx, %edx
    f632:      	addq	0x60(%rsp), %rdx
    f637:      	xorl	%esi, %esi
    f639:      	cmpl	%r15d, %r12d
    f63c:      	seta	%sil
    f640:      	movl	%r15d, %ecx
    f643:      	cmovbl	%r12d, %ecx
    f647:      	addl	%ecx, %esi
    f649:      	movl	%r12d, %edi
    f64c:      	subl	%esi, %edi
    f64e:      	movl	%edi, 0x50(%rsp)
    f652:      	subq	%rsi, %rax
    f655:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f65b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f661:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f667:      	cmpl	%r15d, %r12d
    f66a:      	jbe	0xf670 <generic_rawtp_path+0x5390>
    f66c:      	movb	$0x2f, (%rbx,%rax)
    f670:      	xorl	%edi, %edi
    f672:      	cmpl	%r15d, %r12d
    f675:      	seta	%dil
    f679:      	movzbl	%cl, %esi
    f67c:      	addq	%rax, %rbx
    f67f:      	addq	%rbx, %rdi
    f682:      	movl	$0x4, %eax
    f687:      	callq	*%rax
    f689:      	movq	%rbx, 0x48(%rsp)
    f68e:      	cmpl	%r15d, %r12d
    f691:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f697:      	movq	0x8(%rsp), %r12
    f69c:      	movq	%r12, 0x30(%rsp)
    f6a1:      	movq	0x38(%rsp), %rdx
    f6a6:      	movq	0x40(%rsp), %r15
    f6ab:      	jmp	0xf6fe <generic_rawtp_path+0x541e>
    f6ad:      	leaq	0x10(%r15), %rdx
    f6b1:      	movl	$0x4, %eax
    f6b6:      	movq	%rbp, %rdi
    f6b9:      	movl	$0x8, %esi
    f6be:      	callq	*%rax
    f6c0:      	movq	0x40(%rsp), %rax
    f6c5:      	cmpq	(%rsp), %rax
    f6c9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f6cf:      	addq	$0x18, %r15
    f6d3:      	movl	$0x4, %eax
    f6d8:      	leaq	0x30(%rsp), %rdi
    f6dd:      	movl	$0x8, %esi
    f6e2:      	movq	%r15, %rdx
    f6e5:      	callq	*%rax
    f6e7:      	movq	(%rsp), %r15
    f6eb:      	movq	%r15, 0x40(%rsp)
    f6f0:      	leaq	0x20(%r15), %rdx
    f6f4:      	movq	%rdx, 0x38(%rsp)
    f6f9:      	movq	0x30(%rsp), %r12
    f6fe:      	cmpq	0x18(%rsp), %r12
    f703:      	jne	0xf710 <generic_rawtp_path+0x5430>
    f705:      	cmpq	0x20(%rsp), %rdx
    f70a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f710:      	movl	$0x4, %eax
    f715:      	leaq	0x10(%rsp), %rdi
    f71a:      	movl	$0x8, %esi
    f71f:      	callq	*%rax
    f721:      	cmpq	0x10(%rsp), %r12
    f726:      	je	0xf81e <generic_rawtp_path+0x553e>
    f72c:      	leaq	0x18(%r12), %rbx
    f731:      	movl	$0x4, %eax
    f736:      	movq	%rbp, %rdi
    f739:      	movl	$0x8, %esi
    f73e:      	movq	%rbx, %rdx
    f741:      	callq	*%rax
    f743:      	cmpq	%r12, (%rsp)
    f747:      	je	0xf81e <generic_rawtp_path+0x553e>
    f74d:      	movl	$0x4, %eax
    f752:      	leaq	0x8(%rsp), %rdi
    f757:      	movl	$0x8, %esi
    f75c:      	movq	%rbx, %rdx
    f75f:      	callq	*%rax
    f761:      	addq	$0x20, %r12
    f765:      	movl	$0x4, %eax
    f76a:      	leaq	0x58(%rsp), %rdi
    f76f:      	movl	$0x10, %ecx
    f774:      	movl	$0x10, %esi
    f779:      	movq	%r12, %rdx
    f77c:      	callq	*%rax
    f77e:      	movq	0x28(%rsp), %rbx
    f783:      	movq	0x48(%rsp), %rax
    f788:      	movl	0x5c(%rsp), %r15d
    f78d:      	subq	%rbx, %rax
    f790:      	movl	0x50(%rsp), %r12d
    f795:      	movl	%r15d, %edx
    f798:      	subl	%r12d, %edx
    f79b:      	movl	$0x0, %ecx
    f7a0:      	cmovbl	%ecx, %edx
    f7a3:      	addq	0x60(%rsp), %rdx
    f7a8:      	xorl	%esi, %esi
    f7aa:      	cmpl	%r15d, %r12d
    f7ad:      	seta	%sil
    f7b1:      	movl	%r15d, %ecx
    f7b4:      	cmovbl	%r12d, %ecx
    f7b8:      	addl	%ecx, %esi
    f7ba:      	movl	%r12d, %edi
    f7bd:      	subl	%esi, %edi
    f7bf:      	movl	%edi, 0x50(%rsp)
    f7c3:      	subq	%rsi, %rax
    f7c6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f7cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f7d2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f7d8:      	cmpl	%r15d, %r12d
    f7db:      	jbe	0xf7e1 <generic_rawtp_path+0x5501>
    f7dd:      	movb	$0x2f, (%rbx,%rax)
    f7e1:      	xorl	%edi, %edi
    f7e3:      	cmpl	%r15d, %r12d
    f7e6:      	seta	%dil
    f7ea:      	movzbl	%cl, %esi
    f7ed:      	addq	%rax, %rbx
    f7f0:      	addq	%rbx, %rdi
    f7f3:      	movl	$0x4, %eax
    f7f8:      	callq	*%rax
    f7fa:      	movq	%rbx, 0x48(%rsp)
    f7ff:      	cmpl	%r15d, %r12d
    f802:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f808:      	movq	0x8(%rsp), %r12
    f80d:      	movq	%r12, 0x30(%rsp)
    f812:      	movq	0x38(%rsp), %rdx
    f817:      	movq	0x40(%rsp), %r15
    f81c:      	jmp	0xf86f <generic_rawtp_path+0x558f>
    f81e:      	leaq	0x10(%r15), %rdx
    f822:      	movl	$0x4, %eax
    f827:      	movq	%rbp, %rdi
    f82a:      	movl	$0x8, %esi
    f82f:      	callq	*%rax
    f831:      	movq	0x40(%rsp), %rax
    f836:      	cmpq	(%rsp), %rax
    f83a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f840:      	addq	$0x18, %r15
    f844:      	movl	$0x4, %eax
    f849:      	leaq	0x30(%rsp), %rdi
    f84e:      	movl	$0x8, %esi
    f853:      	movq	%r15, %rdx
    f856:      	callq	*%rax
    f858:      	movq	(%rsp), %r15
    f85c:      	movq	%r15, 0x40(%rsp)
    f861:      	leaq	0x20(%r15), %rdx
    f865:      	movq	%rdx, 0x38(%rsp)
    f86a:      	movq	0x30(%rsp), %r12
    f86f:      	cmpq	0x18(%rsp), %r12
    f874:      	jne	0xf881 <generic_rawtp_path+0x55a1>
    f876:      	cmpq	0x20(%rsp), %rdx
    f87b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f881:      	movl	$0x4, %eax
    f886:      	leaq	0x10(%rsp), %rdi
    f88b:      	movl	$0x8, %esi
    f890:      	callq	*%rax
    f892:      	cmpq	0x10(%rsp), %r12
    f897:      	je	0xf98f <generic_rawtp_path+0x56af>
    f89d:      	leaq	0x18(%r12), %rbx
    f8a2:      	movl	$0x4, %eax
    f8a7:      	movq	%rbp, %rdi
    f8aa:      	movl	$0x8, %esi
    f8af:      	movq	%rbx, %rdx
    f8b2:      	callq	*%rax
    f8b4:      	cmpq	%r12, (%rsp)
    f8b8:      	je	0xf98f <generic_rawtp_path+0x56af>
    f8be:      	movl	$0x4, %eax
    f8c3:      	leaq	0x8(%rsp), %rdi
    f8c8:      	movl	$0x8, %esi
    f8cd:      	movq	%rbx, %rdx
    f8d0:      	callq	*%rax
    f8d2:      	addq	$0x20, %r12
    f8d6:      	movl	$0x4, %eax
    f8db:      	leaq	0x58(%rsp), %rdi
    f8e0:      	movl	$0x10, %ecx
    f8e5:      	movl	$0x10, %esi
    f8ea:      	movq	%r12, %rdx
    f8ed:      	callq	*%rax
    f8ef:      	movq	0x28(%rsp), %rbx
    f8f4:      	movq	0x48(%rsp), %rax
    f8f9:      	movl	0x5c(%rsp), %r15d
    f8fe:      	subq	%rbx, %rax
    f901:      	movl	0x50(%rsp), %r12d
    f906:      	movl	%r15d, %edx
    f909:      	subl	%r12d, %edx
    f90c:      	movl	$0x0, %ecx
    f911:      	cmovbl	%ecx, %edx
    f914:      	addq	0x60(%rsp), %rdx
    f919:      	xorl	%esi, %esi
    f91b:      	cmpl	%r15d, %r12d
    f91e:      	seta	%sil
    f922:      	movl	%r15d, %ecx
    f925:      	cmovbl	%r12d, %ecx
    f929:      	addl	%ecx, %esi
    f92b:      	movl	%r12d, %edi
    f92e:      	subl	%esi, %edi
    f930:      	movl	%edi, 0x50(%rsp)
    f934:      	subq	%rsi, %rax
    f937:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    f93d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f943:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    f949:      	cmpl	%r15d, %r12d
    f94c:      	jbe	0xf952 <generic_rawtp_path+0x5672>
    f94e:      	movb	$0x2f, (%rbx,%rax)
    f952:      	xorl	%edi, %edi
    f954:      	cmpl	%r15d, %r12d
    f957:      	seta	%dil
    f95b:      	movzbl	%cl, %esi
    f95e:      	addq	%rax, %rbx
    f961:      	addq	%rbx, %rdi
    f964:      	movl	$0x4, %eax
    f969:      	callq	*%rax
    f96b:      	movq	%rbx, 0x48(%rsp)
    f970:      	cmpl	%r15d, %r12d
    f973:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    f979:      	movq	0x8(%rsp), %r12
    f97e:      	movq	%r12, 0x30(%rsp)
    f983:      	movq	0x38(%rsp), %rdx
    f988:      	movq	0x40(%rsp), %r15
    f98d:      	jmp	0xf9e0 <generic_rawtp_path+0x5700>
    f98f:      	leaq	0x10(%r15), %rdx
    f993:      	movl	$0x4, %eax
    f998:      	movq	%rbp, %rdi
    f99b:      	movl	$0x8, %esi
    f9a0:      	callq	*%rax
    f9a2:      	movq	0x40(%rsp), %rax
    f9a7:      	cmpq	(%rsp), %rax
    f9ab:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f9b1:      	addq	$0x18, %r15
    f9b5:      	movl	$0x4, %eax
    f9ba:      	leaq	0x30(%rsp), %rdi
    f9bf:      	movl	$0x8, %esi
    f9c4:      	movq	%r15, %rdx
    f9c7:      	callq	*%rax
    f9c9:      	movq	(%rsp), %r15
    f9cd:      	movq	%r15, 0x40(%rsp)
    f9d2:      	leaq	0x20(%r15), %rdx
    f9d6:      	movq	%rdx, 0x38(%rsp)
    f9db:      	movq	0x30(%rsp), %r12
    f9e0:      	cmpq	0x18(%rsp), %r12
    f9e5:      	jne	0xf9f2 <generic_rawtp_path+0x5712>
    f9e7:      	cmpq	0x20(%rsp), %rdx
    f9ec:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    f9f2:      	movl	$0x4, %eax
    f9f7:      	leaq	0x10(%rsp), %rdi
    f9fc:      	movl	$0x8, %esi
    fa01:      	callq	*%rax
    fa03:      	cmpq	0x10(%rsp), %r12
    fa08:      	je	0xfb00 <generic_rawtp_path+0x5820>
    fa0e:      	leaq	0x18(%r12), %rbx
    fa13:      	movl	$0x4, %eax
    fa18:      	movq	%rbp, %rdi
    fa1b:      	movl	$0x8, %esi
    fa20:      	movq	%rbx, %rdx
    fa23:      	callq	*%rax
    fa25:      	cmpq	%r12, (%rsp)
    fa29:      	je	0xfb00 <generic_rawtp_path+0x5820>
    fa2f:      	movl	$0x4, %eax
    fa34:      	leaq	0x8(%rsp), %rdi
    fa39:      	movl	$0x8, %esi
    fa3e:      	movq	%rbx, %rdx
    fa41:      	callq	*%rax
    fa43:      	addq	$0x20, %r12
    fa47:      	movl	$0x4, %eax
    fa4c:      	leaq	0x58(%rsp), %rdi
    fa51:      	movl	$0x10, %ecx
    fa56:      	movl	$0x10, %esi
    fa5b:      	movq	%r12, %rdx
    fa5e:      	callq	*%rax
    fa60:      	movq	0x28(%rsp), %rbx
    fa65:      	movq	0x48(%rsp), %rax
    fa6a:      	movl	0x5c(%rsp), %r15d
    fa6f:      	subq	%rbx, %rax
    fa72:      	movl	0x50(%rsp), %r12d
    fa77:      	movl	%r15d, %edx
    fa7a:      	subl	%r12d, %edx
    fa7d:      	movl	$0x0, %ecx
    fa82:      	cmovbl	%ecx, %edx
    fa85:      	addq	0x60(%rsp), %rdx
    fa8a:      	xorl	%esi, %esi
    fa8c:      	cmpl	%r15d, %r12d
    fa8f:      	seta	%sil
    fa93:      	movl	%r15d, %ecx
    fa96:      	cmovbl	%r12d, %ecx
    fa9a:      	addl	%ecx, %esi
    fa9c:      	movl	%r12d, %edi
    fa9f:      	subl	%esi, %edi
    faa1:      	movl	%edi, 0x50(%rsp)
    faa5:      	subq	%rsi, %rax
    faa8:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    faae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fab4:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    faba:      	cmpl	%r15d, %r12d
    fabd:      	jbe	0xfac3 <generic_rawtp_path+0x57e3>
    fabf:      	movb	$0x2f, (%rbx,%rax)
    fac3:      	xorl	%edi, %edi
    fac5:      	cmpl	%r15d, %r12d
    fac8:      	seta	%dil
    facc:      	movzbl	%cl, %esi
    facf:      	addq	%rax, %rbx
    fad2:      	addq	%rbx, %rdi
    fad5:      	movl	$0x4, %eax
    fada:      	callq	*%rax
    fadc:      	movq	%rbx, 0x48(%rsp)
    fae1:      	cmpl	%r15d, %r12d
    fae4:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    faea:      	movq	0x8(%rsp), %r12
    faef:      	movq	%r12, 0x30(%rsp)
    faf4:      	movq	0x38(%rsp), %rdx
    faf9:      	movq	0x40(%rsp), %r15
    fafe:      	jmp	0xfb51 <generic_rawtp_path+0x5871>
    fb00:      	leaq	0x10(%r15), %rdx
    fb04:      	movl	$0x4, %eax
    fb09:      	movq	%rbp, %rdi
    fb0c:      	movl	$0x8, %esi
    fb11:      	callq	*%rax
    fb13:      	movq	0x40(%rsp), %rax
    fb18:      	cmpq	(%rsp), %rax
    fb1c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    fb22:      	addq	$0x18, %r15
    fb26:      	movl	$0x4, %eax
    fb2b:      	leaq	0x30(%rsp), %rdi
    fb30:      	movl	$0x8, %esi
    fb35:      	movq	%r15, %rdx
    fb38:      	callq	*%rax
    fb3a:      	movq	(%rsp), %r15
    fb3e:      	movq	%r15, 0x40(%rsp)
    fb43:      	leaq	0x20(%r15), %rdx
    fb47:      	movq	%rdx, 0x38(%rsp)
    fb4c:      	movq	0x30(%rsp), %r12
    fb51:      	cmpq	0x18(%rsp), %r12
    fb56:      	jne	0xfb63 <generic_rawtp_path+0x5883>
    fb58:      	cmpq	0x20(%rsp), %rdx
    fb5d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    fb63:      	movl	$0x4, %eax
    fb68:      	leaq	0x10(%rsp), %rdi
    fb6d:      	movl	$0x8, %esi
    fb72:      	callq	*%rax
    fb74:      	cmpq	0x10(%rsp), %r12
    fb79:      	je	0xfc71 <generic_rawtp_path+0x5991>
    fb7f:      	leaq	0x18(%r12), %rbx
    fb84:      	movl	$0x4, %eax
    fb89:      	movq	%rbp, %rdi
    fb8c:      	movl	$0x8, %esi
    fb91:      	movq	%rbx, %rdx
    fb94:      	callq	*%rax
    fb96:      	cmpq	%r12, (%rsp)
    fb9a:      	je	0xfc71 <generic_rawtp_path+0x5991>
    fba0:      	movl	$0x4, %eax
    fba5:      	leaq	0x8(%rsp), %rdi
    fbaa:      	movl	$0x8, %esi
    fbaf:      	movq	%rbx, %rdx
    fbb2:      	callq	*%rax
    fbb4:      	addq	$0x20, %r12
    fbb8:      	movl	$0x4, %eax
    fbbd:      	leaq	0x58(%rsp), %rdi
    fbc2:      	movl	$0x10, %ecx
    fbc7:      	movl	$0x10, %esi
    fbcc:      	movq	%r12, %rdx
    fbcf:      	callq	*%rax
    fbd1:      	movq	0x28(%rsp), %rbx
    fbd6:      	movq	0x48(%rsp), %rax
    fbdb:      	movl	0x5c(%rsp), %r15d
    fbe0:      	subq	%rbx, %rax
    fbe3:      	movl	0x50(%rsp), %r12d
    fbe8:      	movl	%r15d, %edx
    fbeb:      	subl	%r12d, %edx
    fbee:      	movl	$0x0, %ecx
    fbf3:      	cmovbl	%ecx, %edx
    fbf6:      	addq	0x60(%rsp), %rdx
    fbfb:      	xorl	%esi, %esi
    fbfd:      	cmpl	%r15d, %r12d
    fc00:      	seta	%sil
    fc04:      	movl	%r15d, %ecx
    fc07:      	cmovbl	%r12d, %ecx
    fc0b:      	addl	%ecx, %esi
    fc0d:      	movl	%r12d, %edi
    fc10:      	subl	%esi, %edi
    fc12:      	movl	%edi, 0x50(%rsp)
    fc16:      	subq	%rsi, %rax
    fc19:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    fc1f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fc25:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    fc2b:      	cmpl	%r15d, %r12d
    fc2e:      	jbe	0xfc34 <generic_rawtp_path+0x5954>
    fc30:      	movb	$0x2f, (%rbx,%rax)
    fc34:      	xorl	%edi, %edi
    fc36:      	cmpl	%r15d, %r12d
    fc39:      	seta	%dil
    fc3d:      	movzbl	%cl, %esi
    fc40:      	addq	%rax, %rbx
    fc43:      	addq	%rbx, %rdi
    fc46:      	movl	$0x4, %eax
    fc4b:      	callq	*%rax
    fc4d:      	movq	%rbx, 0x48(%rsp)
    fc52:      	cmpl	%r15d, %r12d
    fc55:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    fc5b:      	movq	0x8(%rsp), %r12
    fc60:      	movq	%r12, 0x30(%rsp)
    fc65:      	movq	0x38(%rsp), %rdx
    fc6a:      	movq	0x40(%rsp), %r15
    fc6f:      	jmp	0xfcc2 <generic_rawtp_path+0x59e2>
    fc71:      	leaq	0x10(%r15), %rdx
    fc75:      	movl	$0x4, %eax
    fc7a:      	movq	%rbp, %rdi
    fc7d:      	movl	$0x8, %esi
    fc82:      	callq	*%rax
    fc84:      	movq	0x40(%rsp), %rax
    fc89:      	cmpq	(%rsp), %rax
    fc8d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    fc93:      	addq	$0x18, %r15
    fc97:      	movl	$0x4, %eax
    fc9c:      	leaq	0x30(%rsp), %rdi
    fca1:      	movl	$0x8, %esi
    fca6:      	movq	%r15, %rdx
    fca9:      	callq	*%rax
    fcab:      	movq	(%rsp), %r15
    fcaf:      	movq	%r15, 0x40(%rsp)
    fcb4:      	leaq	0x20(%r15), %rdx
    fcb8:      	movq	%rdx, 0x38(%rsp)
    fcbd:      	movq	0x30(%rsp), %r12
    fcc2:      	cmpq	0x18(%rsp), %r12
    fcc7:      	jne	0xfcd4 <generic_rawtp_path+0x59f4>
    fcc9:      	cmpq	0x20(%rsp), %rdx
    fcce:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    fcd4:      	movl	$0x4, %eax
    fcd9:      	leaq	0x10(%rsp), %rdi
    fcde:      	movl	$0x8, %esi
    fce3:      	callq	*%rax
    fce5:      	cmpq	0x10(%rsp), %r12
    fcea:      	je	0xfde2 <generic_rawtp_path+0x5b02>
    fcf0:      	leaq	0x18(%r12), %rbx
    fcf5:      	movl	$0x4, %eax
    fcfa:      	movq	%rbp, %rdi
    fcfd:      	movl	$0x8, %esi
    fd02:      	movq	%rbx, %rdx
    fd05:      	callq	*%rax
    fd07:      	cmpq	%r12, (%rsp)
    fd0b:      	je	0xfde2 <generic_rawtp_path+0x5b02>
    fd11:      	movl	$0x4, %eax
    fd16:      	leaq	0x8(%rsp), %rdi
    fd1b:      	movl	$0x8, %esi
    fd20:      	movq	%rbx, %rdx
    fd23:      	callq	*%rax
    fd25:      	addq	$0x20, %r12
    fd29:      	movl	$0x4, %eax
    fd2e:      	leaq	0x58(%rsp), %rdi
    fd33:      	movl	$0x10, %ecx
    fd38:      	movl	$0x10, %esi
    fd3d:      	movq	%r12, %rdx
    fd40:      	callq	*%rax
    fd42:      	movq	0x28(%rsp), %rbx
    fd47:      	movq	0x48(%rsp), %rax
    fd4c:      	movl	0x5c(%rsp), %r15d
    fd51:      	subq	%rbx, %rax
    fd54:      	movl	0x50(%rsp), %r12d
    fd59:      	movl	%r15d, %edx
    fd5c:      	subl	%r12d, %edx
    fd5f:      	movl	$0x0, %ecx
    fd64:      	cmovbl	%ecx, %edx
    fd67:      	addq	0x60(%rsp), %rdx
    fd6c:      	xorl	%esi, %esi
    fd6e:      	cmpl	%r15d, %r12d
    fd71:      	seta	%sil
    fd75:      	movl	%r15d, %ecx
    fd78:      	cmovbl	%r12d, %ecx
    fd7c:      	addl	%ecx, %esi
    fd7e:      	movl	%r12d, %edi
    fd81:      	subl	%esi, %edi
    fd83:      	movl	%edi, 0x50(%rsp)
    fd87:      	subq	%rsi, %rax
    fd8a:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    fd90:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fd96:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    fd9c:      	cmpl	%r15d, %r12d
    fd9f:      	jbe	0xfda5 <generic_rawtp_path+0x5ac5>
    fda1:      	movb	$0x2f, (%rbx,%rax)
    fda5:      	xorl	%edi, %edi
    fda7:      	cmpl	%r15d, %r12d
    fdaa:      	seta	%dil
    fdae:      	movzbl	%cl, %esi
    fdb1:      	addq	%rax, %rbx
    fdb4:      	addq	%rbx, %rdi
    fdb7:      	movl	$0x4, %eax
    fdbc:      	callq	*%rax
    fdbe:      	movq	%rbx, 0x48(%rsp)
    fdc3:      	cmpl	%r15d, %r12d
    fdc6:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    fdcc:      	movq	0x8(%rsp), %r12
    fdd1:      	movq	%r12, 0x30(%rsp)
    fdd6:      	movq	0x38(%rsp), %rdx
    fddb:      	movq	0x40(%rsp), %r15
    fde0:      	jmp	0xfe33 <generic_rawtp_path+0x5b53>
    fde2:      	leaq	0x10(%r15), %rdx
    fde6:      	movl	$0x4, %eax
    fdeb:      	movq	%rbp, %rdi
    fdee:      	movl	$0x8, %esi
    fdf3:      	callq	*%rax
    fdf5:      	movq	0x40(%rsp), %rax
    fdfa:      	cmpq	(%rsp), %rax
    fdfe:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    fe04:      	addq	$0x18, %r15
    fe08:      	movl	$0x4, %eax
    fe0d:      	leaq	0x30(%rsp), %rdi
    fe12:      	movl	$0x8, %esi
    fe17:      	movq	%r15, %rdx
    fe1a:      	callq	*%rax
    fe1c:      	movq	(%rsp), %r15
    fe20:      	movq	%r15, 0x40(%rsp)
    fe25:      	leaq	0x20(%r15), %rdx
    fe29:      	movq	%rdx, 0x38(%rsp)
    fe2e:      	movq	0x30(%rsp), %r12
    fe33:      	cmpq	0x18(%rsp), %r12
    fe38:      	jne	0xfe45 <generic_rawtp_path+0x5b65>
    fe3a:      	cmpq	0x20(%rsp), %rdx
    fe3f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    fe45:      	movl	$0x4, %eax
    fe4a:      	leaq	0x10(%rsp), %rdi
    fe4f:      	movl	$0x8, %esi
    fe54:      	callq	*%rax
    fe56:      	cmpq	0x10(%rsp), %r12
    fe5b:      	je	0xff53 <generic_rawtp_path+0x5c73>
    fe61:      	leaq	0x18(%r12), %rbx
    fe66:      	movl	$0x4, %eax
    fe6b:      	movq	%rbp, %rdi
    fe6e:      	movl	$0x8, %esi
    fe73:      	movq	%rbx, %rdx
    fe76:      	callq	*%rax
    fe78:      	cmpq	%r12, (%rsp)
    fe7c:      	je	0xff53 <generic_rawtp_path+0x5c73>
    fe82:      	movl	$0x4, %eax
    fe87:      	leaq	0x8(%rsp), %rdi
    fe8c:      	movl	$0x8, %esi
    fe91:      	movq	%rbx, %rdx
    fe94:      	callq	*%rax
    fe96:      	addq	$0x20, %r12
    fe9a:      	movl	$0x4, %eax
    fe9f:      	leaq	0x58(%rsp), %rdi
    fea4:      	movl	$0x10, %ecx
    fea9:      	movl	$0x10, %esi
    feae:      	movq	%r12, %rdx
    feb1:      	callq	*%rax
    feb3:      	movq	0x28(%rsp), %rbx
    feb8:      	movq	0x48(%rsp), %rax
    febd:      	movl	0x5c(%rsp), %r15d
    fec2:      	subq	%rbx, %rax
    fec5:      	movl	0x50(%rsp), %r12d
    feca:      	movl	%r15d, %edx
    fecd:      	subl	%r12d, %edx
    fed0:      	movl	$0x0, %ecx
    fed5:      	cmovbl	%ecx, %edx
    fed8:      	addq	0x60(%rsp), %rdx
    fedd:      	xorl	%esi, %esi
    fedf:      	cmpl	%r15d, %r12d
    fee2:      	seta	%sil
    fee6:      	movl	%r15d, %ecx
    fee9:      	cmovbl	%r12d, %ecx
    feed:      	addl	%ecx, %esi
    feef:      	movl	%r12d, %edi
    fef2:      	subl	%esi, %edi
    fef4:      	movl	%edi, 0x50(%rsp)
    fef8:      	subq	%rsi, %rax
    fefb:      	jb	0x15d52 <generic_rawtp_path+0xba72>
    ff01:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ff07:      	ja	0x15d52 <generic_rawtp_path+0xba72>
    ff0d:      	cmpl	%r15d, %r12d
    ff10:      	jbe	0xff16 <generic_rawtp_path+0x5c36>
    ff12:      	movb	$0x2f, (%rbx,%rax)
    ff16:      	xorl	%edi, %edi
    ff18:      	cmpl	%r15d, %r12d
    ff1b:      	seta	%dil
    ff1f:      	movzbl	%cl, %esi
    ff22:      	addq	%rax, %rbx
    ff25:      	addq	%rbx, %rdi
    ff28:      	movl	$0x4, %eax
    ff2d:      	callq	*%rax
    ff2f:      	movq	%rbx, 0x48(%rsp)
    ff34:      	cmpl	%r15d, %r12d
    ff37:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
    ff3d:      	movq	0x8(%rsp), %r12
    ff42:      	movq	%r12, 0x30(%rsp)
    ff47:      	movq	0x38(%rsp), %rdx
    ff4c:      	movq	0x40(%rsp), %r15
    ff51:      	jmp	0xffa4 <generic_rawtp_path+0x5cc4>
    ff53:      	leaq	0x10(%r15), %rdx
    ff57:      	movl	$0x4, %eax
    ff5c:      	movq	%rbp, %rdi
    ff5f:      	movl	$0x8, %esi
    ff64:      	callq	*%rax
    ff66:      	movq	0x40(%rsp), %rax
    ff6b:      	cmpq	(%rsp), %rax
    ff6f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ff75:      	addq	$0x18, %r15
    ff79:      	movl	$0x4, %eax
    ff7e:      	leaq	0x30(%rsp), %rdi
    ff83:      	movl	$0x8, %esi
    ff88:      	movq	%r15, %rdx
    ff8b:      	callq	*%rax
    ff8d:      	movq	(%rsp), %r15
    ff91:      	movq	%r15, 0x40(%rsp)
    ff96:      	leaq	0x20(%r15), %rdx
    ff9a:      	movq	%rdx, 0x38(%rsp)
    ff9f:      	movq	0x30(%rsp), %r12
    ffa4:      	cmpq	0x18(%rsp), %r12
    ffa9:      	jne	0xffb6 <generic_rawtp_path+0x5cd6>
    ffab:      	cmpq	0x20(%rsp), %rdx
    ffb0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
    ffb6:      	movl	$0x4, %eax
    ffbb:      	leaq	0x10(%rsp), %rdi
    ffc0:      	movl	$0x8, %esi
    ffc5:      	callq	*%rax
    ffc7:      	cmpq	0x10(%rsp), %r12
    ffcc:      	je	0x100c4 <generic_rawtp_path+0x5de4>
    ffd2:      	leaq	0x18(%r12), %rbx
    ffd7:      	movl	$0x4, %eax
    ffdc:      	movq	%rbp, %rdi
    ffdf:      	movl	$0x8, %esi
    ffe4:      	movq	%rbx, %rdx
    ffe7:      	callq	*%rax
    ffe9:      	cmpq	%r12, (%rsp)
    ffed:      	je	0x100c4 <generic_rawtp_path+0x5de4>
    fff3:      	movl	$0x4, %eax
    fff8:      	leaq	0x8(%rsp), %rdi
    fffd:      	movl	$0x8, %esi
   10002:      	movq	%rbx, %rdx
   10005:      	callq	*%rax
   10007:      	addq	$0x20, %r12
   1000b:      	movl	$0x4, %eax
   10010:      	leaq	0x58(%rsp), %rdi
   10015:      	movl	$0x10, %ecx
   1001a:      	movl	$0x10, %esi
   1001f:      	movq	%r12, %rdx
   10022:      	callq	*%rax
   10024:      	movq	0x28(%rsp), %rbx
   10029:      	movq	0x48(%rsp), %rax
   1002e:      	movl	0x5c(%rsp), %r15d
   10033:      	subq	%rbx, %rax
   10036:      	movl	0x50(%rsp), %r12d
   1003b:      	movl	%r15d, %edx
   1003e:      	subl	%r12d, %edx
   10041:      	movl	$0x0, %ecx
   10046:      	cmovbl	%ecx, %edx
   10049:      	addq	0x60(%rsp), %rdx
   1004e:      	xorl	%esi, %esi
   10050:      	cmpl	%r15d, %r12d
   10053:      	seta	%sil
   10057:      	movl	%r15d, %ecx
   1005a:      	cmovbl	%r12d, %ecx
   1005e:      	addl	%ecx, %esi
   10060:      	movl	%r12d, %edi
   10063:      	subl	%esi, %edi
   10065:      	movl	%edi, 0x50(%rsp)
   10069:      	subq	%rsi, %rax
   1006c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10072:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10078:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1007e:      	cmpl	%r15d, %r12d
   10081:      	jbe	0x10087 <generic_rawtp_path+0x5da7>
   10083:      	movb	$0x2f, (%rbx,%rax)
   10087:      	xorl	%edi, %edi
   10089:      	cmpl	%r15d, %r12d
   1008c:      	seta	%dil
   10090:      	movzbl	%cl, %esi
   10093:      	addq	%rax, %rbx
   10096:      	addq	%rbx, %rdi
   10099:      	movl	$0x4, %eax
   1009e:      	callq	*%rax
   100a0:      	movq	%rbx, 0x48(%rsp)
   100a5:      	cmpl	%r15d, %r12d
   100a8:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   100ae:      	movq	0x8(%rsp), %r12
   100b3:      	movq	%r12, 0x30(%rsp)
   100b8:      	movq	0x38(%rsp), %rdx
   100bd:      	movq	0x40(%rsp), %r15
   100c2:      	jmp	0x10115 <generic_rawtp_path+0x5e35>
   100c4:      	leaq	0x10(%r15), %rdx
   100c8:      	movl	$0x4, %eax
   100cd:      	movq	%rbp, %rdi
   100d0:      	movl	$0x8, %esi
   100d5:      	callq	*%rax
   100d7:      	movq	0x40(%rsp), %rax
   100dc:      	cmpq	(%rsp), %rax
   100e0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   100e6:      	addq	$0x18, %r15
   100ea:      	movl	$0x4, %eax
   100ef:      	leaq	0x30(%rsp), %rdi
   100f4:      	movl	$0x8, %esi
   100f9:      	movq	%r15, %rdx
   100fc:      	callq	*%rax
   100fe:      	movq	(%rsp), %r15
   10102:      	movq	%r15, 0x40(%rsp)
   10107:      	leaq	0x20(%r15), %rdx
   1010b:      	movq	%rdx, 0x38(%rsp)
   10110:      	movq	0x30(%rsp), %r12
   10115:      	cmpq	0x18(%rsp), %r12
   1011a:      	jne	0x10127 <generic_rawtp_path+0x5e47>
   1011c:      	cmpq	0x20(%rsp), %rdx
   10121:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10127:      	movl	$0x4, %eax
   1012c:      	leaq	0x10(%rsp), %rdi
   10131:      	movl	$0x8, %esi
   10136:      	callq	*%rax
   10138:      	cmpq	0x10(%rsp), %r12
   1013d:      	je	0x10235 <generic_rawtp_path+0x5f55>
   10143:      	leaq	0x18(%r12), %rbx
   10148:      	movl	$0x4, %eax
   1014d:      	movq	%rbp, %rdi
   10150:      	movl	$0x8, %esi
   10155:      	movq	%rbx, %rdx
   10158:      	callq	*%rax
   1015a:      	cmpq	%r12, (%rsp)
   1015e:      	je	0x10235 <generic_rawtp_path+0x5f55>
   10164:      	movl	$0x4, %eax
   10169:      	leaq	0x8(%rsp), %rdi
   1016e:      	movl	$0x8, %esi
   10173:      	movq	%rbx, %rdx
   10176:      	callq	*%rax
   10178:      	addq	$0x20, %r12
   1017c:      	movl	$0x4, %eax
   10181:      	leaq	0x58(%rsp), %rdi
   10186:      	movl	$0x10, %ecx
   1018b:      	movl	$0x10, %esi
   10190:      	movq	%r12, %rdx
   10193:      	callq	*%rax
   10195:      	movq	0x28(%rsp), %rbx
   1019a:      	movq	0x48(%rsp), %rax
   1019f:      	movl	0x5c(%rsp), %r15d
   101a4:      	subq	%rbx, %rax
   101a7:      	movl	0x50(%rsp), %r12d
   101ac:      	movl	%r15d, %edx
   101af:      	subl	%r12d, %edx
   101b2:      	movl	$0x0, %ecx
   101b7:      	cmovbl	%ecx, %edx
   101ba:      	addq	0x60(%rsp), %rdx
   101bf:      	xorl	%esi, %esi
   101c1:      	cmpl	%r15d, %r12d
   101c4:      	seta	%sil
   101c8:      	movl	%r15d, %ecx
   101cb:      	cmovbl	%r12d, %ecx
   101cf:      	addl	%ecx, %esi
   101d1:      	movl	%r12d, %edi
   101d4:      	subl	%esi, %edi
   101d6:      	movl	%edi, 0x50(%rsp)
   101da:      	subq	%rsi, %rax
   101dd:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   101e3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   101e9:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   101ef:      	cmpl	%r15d, %r12d
   101f2:      	jbe	0x101f8 <generic_rawtp_path+0x5f18>
   101f4:      	movb	$0x2f, (%rbx,%rax)
   101f8:      	xorl	%edi, %edi
   101fa:      	cmpl	%r15d, %r12d
   101fd:      	seta	%dil
   10201:      	movzbl	%cl, %esi
   10204:      	addq	%rax, %rbx
   10207:      	addq	%rbx, %rdi
   1020a:      	movl	$0x4, %eax
   1020f:      	callq	*%rax
   10211:      	movq	%rbx, 0x48(%rsp)
   10216:      	cmpl	%r15d, %r12d
   10219:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1021f:      	movq	0x8(%rsp), %r12
   10224:      	movq	%r12, 0x30(%rsp)
   10229:      	movq	0x38(%rsp), %rdx
   1022e:      	movq	0x40(%rsp), %r15
   10233:      	jmp	0x10286 <generic_rawtp_path+0x5fa6>
   10235:      	leaq	0x10(%r15), %rdx
   10239:      	movl	$0x4, %eax
   1023e:      	movq	%rbp, %rdi
   10241:      	movl	$0x8, %esi
   10246:      	callq	*%rax
   10248:      	movq	0x40(%rsp), %rax
   1024d:      	cmpq	(%rsp), %rax
   10251:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10257:      	addq	$0x18, %r15
   1025b:      	movl	$0x4, %eax
   10260:      	leaq	0x30(%rsp), %rdi
   10265:      	movl	$0x8, %esi
   1026a:      	movq	%r15, %rdx
   1026d:      	callq	*%rax
   1026f:      	movq	(%rsp), %r15
   10273:      	movq	%r15, 0x40(%rsp)
   10278:      	leaq	0x20(%r15), %rdx
   1027c:      	movq	%rdx, 0x38(%rsp)
   10281:      	movq	0x30(%rsp), %r12
   10286:      	cmpq	0x18(%rsp), %r12
   1028b:      	jne	0x10298 <generic_rawtp_path+0x5fb8>
   1028d:      	cmpq	0x20(%rsp), %rdx
   10292:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10298:      	movl	$0x4, %eax
   1029d:      	leaq	0x10(%rsp), %rdi
   102a2:      	movl	$0x8, %esi
   102a7:      	callq	*%rax
   102a9:      	cmpq	0x10(%rsp), %r12
   102ae:      	je	0x103a6 <generic_rawtp_path+0x60c6>
   102b4:      	leaq	0x18(%r12), %rbx
   102b9:      	movl	$0x4, %eax
   102be:      	movq	%rbp, %rdi
   102c1:      	movl	$0x8, %esi
   102c6:      	movq	%rbx, %rdx
   102c9:      	callq	*%rax
   102cb:      	cmpq	%r12, (%rsp)
   102cf:      	je	0x103a6 <generic_rawtp_path+0x60c6>
   102d5:      	movl	$0x4, %eax
   102da:      	leaq	0x8(%rsp), %rdi
   102df:      	movl	$0x8, %esi
   102e4:      	movq	%rbx, %rdx
   102e7:      	callq	*%rax
   102e9:      	addq	$0x20, %r12
   102ed:      	movl	$0x4, %eax
   102f2:      	leaq	0x58(%rsp), %rdi
   102f7:      	movl	$0x10, %ecx
   102fc:      	movl	$0x10, %esi
   10301:      	movq	%r12, %rdx
   10304:      	callq	*%rax
   10306:      	movq	0x28(%rsp), %rbx
   1030b:      	movq	0x48(%rsp), %rax
   10310:      	movl	0x5c(%rsp), %r15d
   10315:      	subq	%rbx, %rax
   10318:      	movl	0x50(%rsp), %r12d
   1031d:      	movl	%r15d, %edx
   10320:      	subl	%r12d, %edx
   10323:      	movl	$0x0, %ecx
   10328:      	cmovbl	%ecx, %edx
   1032b:      	addq	0x60(%rsp), %rdx
   10330:      	xorl	%esi, %esi
   10332:      	cmpl	%r15d, %r12d
   10335:      	seta	%sil
   10339:      	movl	%r15d, %ecx
   1033c:      	cmovbl	%r12d, %ecx
   10340:      	addl	%ecx, %esi
   10342:      	movl	%r12d, %edi
   10345:      	subl	%esi, %edi
   10347:      	movl	%edi, 0x50(%rsp)
   1034b:      	subq	%rsi, %rax
   1034e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10354:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1035a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10360:      	cmpl	%r15d, %r12d
   10363:      	jbe	0x10369 <generic_rawtp_path+0x6089>
   10365:      	movb	$0x2f, (%rbx,%rax)
   10369:      	xorl	%edi, %edi
   1036b:      	cmpl	%r15d, %r12d
   1036e:      	seta	%dil
   10372:      	movzbl	%cl, %esi
   10375:      	addq	%rax, %rbx
   10378:      	addq	%rbx, %rdi
   1037b:      	movl	$0x4, %eax
   10380:      	callq	*%rax
   10382:      	movq	%rbx, 0x48(%rsp)
   10387:      	cmpl	%r15d, %r12d
   1038a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10390:      	movq	0x8(%rsp), %r12
   10395:      	movq	%r12, 0x30(%rsp)
   1039a:      	movq	0x38(%rsp), %rdx
   1039f:      	movq	0x40(%rsp), %r15
   103a4:      	jmp	0x103f7 <generic_rawtp_path+0x6117>
   103a6:      	leaq	0x10(%r15), %rdx
   103aa:      	movl	$0x4, %eax
   103af:      	movq	%rbp, %rdi
   103b2:      	movl	$0x8, %esi
   103b7:      	callq	*%rax
   103b9:      	movq	0x40(%rsp), %rax
   103be:      	cmpq	(%rsp), %rax
   103c2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   103c8:      	addq	$0x18, %r15
   103cc:      	movl	$0x4, %eax
   103d1:      	leaq	0x30(%rsp), %rdi
   103d6:      	movl	$0x8, %esi
   103db:      	movq	%r15, %rdx
   103de:      	callq	*%rax
   103e0:      	movq	(%rsp), %r15
   103e4:      	movq	%r15, 0x40(%rsp)
   103e9:      	leaq	0x20(%r15), %rdx
   103ed:      	movq	%rdx, 0x38(%rsp)
   103f2:      	movq	0x30(%rsp), %r12
   103f7:      	cmpq	0x18(%rsp), %r12
   103fc:      	jne	0x10409 <generic_rawtp_path+0x6129>
   103fe:      	cmpq	0x20(%rsp), %rdx
   10403:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10409:      	movl	$0x4, %eax
   1040e:      	leaq	0x10(%rsp), %rdi
   10413:      	movl	$0x8, %esi
   10418:      	callq	*%rax
   1041a:      	cmpq	0x10(%rsp), %r12
   1041f:      	je	0x10517 <generic_rawtp_path+0x6237>
   10425:      	leaq	0x18(%r12), %rbx
   1042a:      	movl	$0x4, %eax
   1042f:      	movq	%rbp, %rdi
   10432:      	movl	$0x8, %esi
   10437:      	movq	%rbx, %rdx
   1043a:      	callq	*%rax
   1043c:      	cmpq	%r12, (%rsp)
   10440:      	je	0x10517 <generic_rawtp_path+0x6237>
   10446:      	movl	$0x4, %eax
   1044b:      	leaq	0x8(%rsp), %rdi
   10450:      	movl	$0x8, %esi
   10455:      	movq	%rbx, %rdx
   10458:      	callq	*%rax
   1045a:      	addq	$0x20, %r12
   1045e:      	movl	$0x4, %eax
   10463:      	leaq	0x58(%rsp), %rdi
   10468:      	movl	$0x10, %ecx
   1046d:      	movl	$0x10, %esi
   10472:      	movq	%r12, %rdx
   10475:      	callq	*%rax
   10477:      	movq	0x28(%rsp), %rbx
   1047c:      	movq	0x48(%rsp), %rax
   10481:      	movl	0x5c(%rsp), %r15d
   10486:      	subq	%rbx, %rax
   10489:      	movl	0x50(%rsp), %r12d
   1048e:      	movl	%r15d, %edx
   10491:      	subl	%r12d, %edx
   10494:      	movl	$0x0, %ecx
   10499:      	cmovbl	%ecx, %edx
   1049c:      	addq	0x60(%rsp), %rdx
   104a1:      	xorl	%esi, %esi
   104a3:      	cmpl	%r15d, %r12d
   104a6:      	seta	%sil
   104aa:      	movl	%r15d, %ecx
   104ad:      	cmovbl	%r12d, %ecx
   104b1:      	addl	%ecx, %esi
   104b3:      	movl	%r12d, %edi
   104b6:      	subl	%esi, %edi
   104b8:      	movl	%edi, 0x50(%rsp)
   104bc:      	subq	%rsi, %rax
   104bf:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   104c5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   104cb:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   104d1:      	cmpl	%r15d, %r12d
   104d4:      	jbe	0x104da <generic_rawtp_path+0x61fa>
   104d6:      	movb	$0x2f, (%rbx,%rax)
   104da:      	xorl	%edi, %edi
   104dc:      	cmpl	%r15d, %r12d
   104df:      	seta	%dil
   104e3:      	movzbl	%cl, %esi
   104e6:      	addq	%rax, %rbx
   104e9:      	addq	%rbx, %rdi
   104ec:      	movl	$0x4, %eax
   104f1:      	callq	*%rax
   104f3:      	movq	%rbx, 0x48(%rsp)
   104f8:      	cmpl	%r15d, %r12d
   104fb:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10501:      	movq	0x8(%rsp), %r12
   10506:      	movq	%r12, 0x30(%rsp)
   1050b:      	movq	0x38(%rsp), %rdx
   10510:      	movq	0x40(%rsp), %r15
   10515:      	jmp	0x10568 <generic_rawtp_path+0x6288>
   10517:      	leaq	0x10(%r15), %rdx
   1051b:      	movl	$0x4, %eax
   10520:      	movq	%rbp, %rdi
   10523:      	movl	$0x8, %esi
   10528:      	callq	*%rax
   1052a:      	movq	0x40(%rsp), %rax
   1052f:      	cmpq	(%rsp), %rax
   10533:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10539:      	addq	$0x18, %r15
   1053d:      	movl	$0x4, %eax
   10542:      	leaq	0x30(%rsp), %rdi
   10547:      	movl	$0x8, %esi
   1054c:      	movq	%r15, %rdx
   1054f:      	callq	*%rax
   10551:      	movq	(%rsp), %r15
   10555:      	movq	%r15, 0x40(%rsp)
   1055a:      	leaq	0x20(%r15), %rdx
   1055e:      	movq	%rdx, 0x38(%rsp)
   10563:      	movq	0x30(%rsp), %r12
   10568:      	cmpq	0x18(%rsp), %r12
   1056d:      	jne	0x1057a <generic_rawtp_path+0x629a>
   1056f:      	cmpq	0x20(%rsp), %rdx
   10574:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1057a:      	movl	$0x4, %eax
   1057f:      	leaq	0x10(%rsp), %rdi
   10584:      	movl	$0x8, %esi
   10589:      	callq	*%rax
   1058b:      	cmpq	0x10(%rsp), %r12
   10590:      	je	0x10688 <generic_rawtp_path+0x63a8>
   10596:      	leaq	0x18(%r12), %rbx
   1059b:      	movl	$0x4, %eax
   105a0:      	movq	%rbp, %rdi
   105a3:      	movl	$0x8, %esi
   105a8:      	movq	%rbx, %rdx
   105ab:      	callq	*%rax
   105ad:      	cmpq	%r12, (%rsp)
   105b1:      	je	0x10688 <generic_rawtp_path+0x63a8>
   105b7:      	movl	$0x4, %eax
   105bc:      	leaq	0x8(%rsp), %rdi
   105c1:      	movl	$0x8, %esi
   105c6:      	movq	%rbx, %rdx
   105c9:      	callq	*%rax
   105cb:      	addq	$0x20, %r12
   105cf:      	movl	$0x4, %eax
   105d4:      	leaq	0x58(%rsp), %rdi
   105d9:      	movl	$0x10, %ecx
   105de:      	movl	$0x10, %esi
   105e3:      	movq	%r12, %rdx
   105e6:      	callq	*%rax
   105e8:      	movq	0x28(%rsp), %rbx
   105ed:      	movq	0x48(%rsp), %rax
   105f2:      	movl	0x5c(%rsp), %r15d
   105f7:      	subq	%rbx, %rax
   105fa:      	movl	0x50(%rsp), %r12d
   105ff:      	movl	%r15d, %edx
   10602:      	subl	%r12d, %edx
   10605:      	movl	$0x0, %ecx
   1060a:      	cmovbl	%ecx, %edx
   1060d:      	addq	0x60(%rsp), %rdx
   10612:      	xorl	%esi, %esi
   10614:      	cmpl	%r15d, %r12d
   10617:      	seta	%sil
   1061b:      	movl	%r15d, %ecx
   1061e:      	cmovbl	%r12d, %ecx
   10622:      	addl	%ecx, %esi
   10624:      	movl	%r12d, %edi
   10627:      	subl	%esi, %edi
   10629:      	movl	%edi, 0x50(%rsp)
   1062d:      	subq	%rsi, %rax
   10630:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10636:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1063c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10642:      	cmpl	%r15d, %r12d
   10645:      	jbe	0x1064b <generic_rawtp_path+0x636b>
   10647:      	movb	$0x2f, (%rbx,%rax)
   1064b:      	xorl	%edi, %edi
   1064d:      	cmpl	%r15d, %r12d
   10650:      	seta	%dil
   10654:      	movzbl	%cl, %esi
   10657:      	addq	%rax, %rbx
   1065a:      	addq	%rbx, %rdi
   1065d:      	movl	$0x4, %eax
   10662:      	callq	*%rax
   10664:      	movq	%rbx, 0x48(%rsp)
   10669:      	cmpl	%r15d, %r12d
   1066c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10672:      	movq	0x8(%rsp), %r12
   10677:      	movq	%r12, 0x30(%rsp)
   1067c:      	movq	0x38(%rsp), %rdx
   10681:      	movq	0x40(%rsp), %r15
   10686:      	jmp	0x106d9 <generic_rawtp_path+0x63f9>
   10688:      	leaq	0x10(%r15), %rdx
   1068c:      	movl	$0x4, %eax
   10691:      	movq	%rbp, %rdi
   10694:      	movl	$0x8, %esi
   10699:      	callq	*%rax
   1069b:      	movq	0x40(%rsp), %rax
   106a0:      	cmpq	(%rsp), %rax
   106a4:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   106aa:      	addq	$0x18, %r15
   106ae:      	movl	$0x4, %eax
   106b3:      	leaq	0x30(%rsp), %rdi
   106b8:      	movl	$0x8, %esi
   106bd:      	movq	%r15, %rdx
   106c0:      	callq	*%rax
   106c2:      	movq	(%rsp), %r15
   106c6:      	movq	%r15, 0x40(%rsp)
   106cb:      	leaq	0x20(%r15), %rdx
   106cf:      	movq	%rdx, 0x38(%rsp)
   106d4:      	movq	0x30(%rsp), %r12
   106d9:      	cmpq	0x18(%rsp), %r12
   106de:      	jne	0x106eb <generic_rawtp_path+0x640b>
   106e0:      	cmpq	0x20(%rsp), %rdx
   106e5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   106eb:      	movl	$0x4, %eax
   106f0:      	leaq	0x10(%rsp), %rdi
   106f5:      	movl	$0x8, %esi
   106fa:      	callq	*%rax
   106fc:      	cmpq	0x10(%rsp), %r12
   10701:      	je	0x107f9 <generic_rawtp_path+0x6519>
   10707:      	leaq	0x18(%r12), %rbx
   1070c:      	movl	$0x4, %eax
   10711:      	movq	%rbp, %rdi
   10714:      	movl	$0x8, %esi
   10719:      	movq	%rbx, %rdx
   1071c:      	callq	*%rax
   1071e:      	cmpq	%r12, (%rsp)
   10722:      	je	0x107f9 <generic_rawtp_path+0x6519>
   10728:      	movl	$0x4, %eax
   1072d:      	leaq	0x8(%rsp), %rdi
   10732:      	movl	$0x8, %esi
   10737:      	movq	%rbx, %rdx
   1073a:      	callq	*%rax
   1073c:      	addq	$0x20, %r12
   10740:      	movl	$0x4, %eax
   10745:      	leaq	0x58(%rsp), %rdi
   1074a:      	movl	$0x10, %ecx
   1074f:      	movl	$0x10, %esi
   10754:      	movq	%r12, %rdx
   10757:      	callq	*%rax
   10759:      	movq	0x28(%rsp), %rbx
   1075e:      	movq	0x48(%rsp), %rax
   10763:      	movl	0x5c(%rsp), %r15d
   10768:      	subq	%rbx, %rax
   1076b:      	movl	0x50(%rsp), %r12d
   10770:      	movl	%r15d, %edx
   10773:      	subl	%r12d, %edx
   10776:      	movl	$0x0, %ecx
   1077b:      	cmovbl	%ecx, %edx
   1077e:      	addq	0x60(%rsp), %rdx
   10783:      	xorl	%esi, %esi
   10785:      	cmpl	%r15d, %r12d
   10788:      	seta	%sil
   1078c:      	movl	%r15d, %ecx
   1078f:      	cmovbl	%r12d, %ecx
   10793:      	addl	%ecx, %esi
   10795:      	movl	%r12d, %edi
   10798:      	subl	%esi, %edi
   1079a:      	movl	%edi, 0x50(%rsp)
   1079e:      	subq	%rsi, %rax
   107a1:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   107a7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   107ad:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   107b3:      	cmpl	%r15d, %r12d
   107b6:      	jbe	0x107bc <generic_rawtp_path+0x64dc>
   107b8:      	movb	$0x2f, (%rbx,%rax)
   107bc:      	xorl	%edi, %edi
   107be:      	cmpl	%r15d, %r12d
   107c1:      	seta	%dil
   107c5:      	movzbl	%cl, %esi
   107c8:      	addq	%rax, %rbx
   107cb:      	addq	%rbx, %rdi
   107ce:      	movl	$0x4, %eax
   107d3:      	callq	*%rax
   107d5:      	movq	%rbx, 0x48(%rsp)
   107da:      	cmpl	%r15d, %r12d
   107dd:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   107e3:      	movq	0x8(%rsp), %r12
   107e8:      	movq	%r12, 0x30(%rsp)
   107ed:      	movq	0x38(%rsp), %rdx
   107f2:      	movq	0x40(%rsp), %r15
   107f7:      	jmp	0x1084a <generic_rawtp_path+0x656a>
   107f9:      	leaq	0x10(%r15), %rdx
   107fd:      	movl	$0x4, %eax
   10802:      	movq	%rbp, %rdi
   10805:      	movl	$0x8, %esi
   1080a:      	callq	*%rax
   1080c:      	movq	0x40(%rsp), %rax
   10811:      	cmpq	(%rsp), %rax
   10815:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1081b:      	addq	$0x18, %r15
   1081f:      	movl	$0x4, %eax
   10824:      	leaq	0x30(%rsp), %rdi
   10829:      	movl	$0x8, %esi
   1082e:      	movq	%r15, %rdx
   10831:      	callq	*%rax
   10833:      	movq	(%rsp), %r15
   10837:      	movq	%r15, 0x40(%rsp)
   1083c:      	leaq	0x20(%r15), %rdx
   10840:      	movq	%rdx, 0x38(%rsp)
   10845:      	movq	0x30(%rsp), %r12
   1084a:      	cmpq	0x18(%rsp), %r12
   1084f:      	jne	0x1085c <generic_rawtp_path+0x657c>
   10851:      	cmpq	0x20(%rsp), %rdx
   10856:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1085c:      	movl	$0x4, %eax
   10861:      	leaq	0x10(%rsp), %rdi
   10866:      	movl	$0x8, %esi
   1086b:      	callq	*%rax
   1086d:      	cmpq	0x10(%rsp), %r12
   10872:      	je	0x1096a <generic_rawtp_path+0x668a>
   10878:      	leaq	0x18(%r12), %rbx
   1087d:      	movl	$0x4, %eax
   10882:      	movq	%rbp, %rdi
   10885:      	movl	$0x8, %esi
   1088a:      	movq	%rbx, %rdx
   1088d:      	callq	*%rax
   1088f:      	cmpq	%r12, (%rsp)
   10893:      	je	0x1096a <generic_rawtp_path+0x668a>
   10899:      	movl	$0x4, %eax
   1089e:      	leaq	0x8(%rsp), %rdi
   108a3:      	movl	$0x8, %esi
   108a8:      	movq	%rbx, %rdx
   108ab:      	callq	*%rax
   108ad:      	addq	$0x20, %r12
   108b1:      	movl	$0x4, %eax
   108b6:      	leaq	0x58(%rsp), %rdi
   108bb:      	movl	$0x10, %ecx
   108c0:      	movl	$0x10, %esi
   108c5:      	movq	%r12, %rdx
   108c8:      	callq	*%rax
   108ca:      	movq	0x28(%rsp), %rbx
   108cf:      	movq	0x48(%rsp), %rax
   108d4:      	movl	0x5c(%rsp), %r15d
   108d9:      	subq	%rbx, %rax
   108dc:      	movl	0x50(%rsp), %r12d
   108e1:      	movl	%r15d, %edx
   108e4:      	subl	%r12d, %edx
   108e7:      	movl	$0x0, %ecx
   108ec:      	cmovbl	%ecx, %edx
   108ef:      	addq	0x60(%rsp), %rdx
   108f4:      	xorl	%esi, %esi
   108f6:      	cmpl	%r15d, %r12d
   108f9:      	seta	%sil
   108fd:      	movl	%r15d, %ecx
   10900:      	cmovbl	%r12d, %ecx
   10904:      	addl	%ecx, %esi
   10906:      	movl	%r12d, %edi
   10909:      	subl	%esi, %edi
   1090b:      	movl	%edi, 0x50(%rsp)
   1090f:      	subq	%rsi, %rax
   10912:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10918:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1091e:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10924:      	cmpl	%r15d, %r12d
   10927:      	jbe	0x1092d <generic_rawtp_path+0x664d>
   10929:      	movb	$0x2f, (%rbx,%rax)
   1092d:      	xorl	%edi, %edi
   1092f:      	cmpl	%r15d, %r12d
   10932:      	seta	%dil
   10936:      	movzbl	%cl, %esi
   10939:      	addq	%rax, %rbx
   1093c:      	addq	%rbx, %rdi
   1093f:      	movl	$0x4, %eax
   10944:      	callq	*%rax
   10946:      	movq	%rbx, 0x48(%rsp)
   1094b:      	cmpl	%r15d, %r12d
   1094e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10954:      	movq	0x8(%rsp), %r12
   10959:      	movq	%r12, 0x30(%rsp)
   1095e:      	movq	0x38(%rsp), %rdx
   10963:      	movq	0x40(%rsp), %r15
   10968:      	jmp	0x109bb <generic_rawtp_path+0x66db>
   1096a:      	leaq	0x10(%r15), %rdx
   1096e:      	movl	$0x4, %eax
   10973:      	movq	%rbp, %rdi
   10976:      	movl	$0x8, %esi
   1097b:      	callq	*%rax
   1097d:      	movq	0x40(%rsp), %rax
   10982:      	cmpq	(%rsp), %rax
   10986:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1098c:      	addq	$0x18, %r15
   10990:      	movl	$0x4, %eax
   10995:      	leaq	0x30(%rsp), %rdi
   1099a:      	movl	$0x8, %esi
   1099f:      	movq	%r15, %rdx
   109a2:      	callq	*%rax
   109a4:      	movq	(%rsp), %r15
   109a8:      	movq	%r15, 0x40(%rsp)
   109ad:      	leaq	0x20(%r15), %rdx
   109b1:      	movq	%rdx, 0x38(%rsp)
   109b6:      	movq	0x30(%rsp), %r12
   109bb:      	cmpq	0x18(%rsp), %r12
   109c0:      	jne	0x109cd <generic_rawtp_path+0x66ed>
   109c2:      	cmpq	0x20(%rsp), %rdx
   109c7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   109cd:      	movl	$0x4, %eax
   109d2:      	leaq	0x10(%rsp), %rdi
   109d7:      	movl	$0x8, %esi
   109dc:      	callq	*%rax
   109de:      	cmpq	0x10(%rsp), %r12
   109e3:      	je	0x10adb <generic_rawtp_path+0x67fb>
   109e9:      	leaq	0x18(%r12), %rbx
   109ee:      	movl	$0x4, %eax
   109f3:      	movq	%rbp, %rdi
   109f6:      	movl	$0x8, %esi
   109fb:      	movq	%rbx, %rdx
   109fe:      	callq	*%rax
   10a00:      	cmpq	%r12, (%rsp)
   10a04:      	je	0x10adb <generic_rawtp_path+0x67fb>
   10a0a:      	movl	$0x4, %eax
   10a0f:      	leaq	0x8(%rsp), %rdi
   10a14:      	movl	$0x8, %esi
   10a19:      	movq	%rbx, %rdx
   10a1c:      	callq	*%rax
   10a1e:      	addq	$0x20, %r12
   10a22:      	movl	$0x4, %eax
   10a27:      	leaq	0x58(%rsp), %rdi
   10a2c:      	movl	$0x10, %ecx
   10a31:      	movl	$0x10, %esi
   10a36:      	movq	%r12, %rdx
   10a39:      	callq	*%rax
   10a3b:      	movq	0x28(%rsp), %rbx
   10a40:      	movq	0x48(%rsp), %rax
   10a45:      	movl	0x5c(%rsp), %r15d
   10a4a:      	subq	%rbx, %rax
   10a4d:      	movl	0x50(%rsp), %r12d
   10a52:      	movl	%r15d, %edx
   10a55:      	subl	%r12d, %edx
   10a58:      	movl	$0x0, %ecx
   10a5d:      	cmovbl	%ecx, %edx
   10a60:      	addq	0x60(%rsp), %rdx
   10a65:      	xorl	%esi, %esi
   10a67:      	cmpl	%r15d, %r12d
   10a6a:      	seta	%sil
   10a6e:      	movl	%r15d, %ecx
   10a71:      	cmovbl	%r12d, %ecx
   10a75:      	addl	%ecx, %esi
   10a77:      	movl	%r12d, %edi
   10a7a:      	subl	%esi, %edi
   10a7c:      	movl	%edi, 0x50(%rsp)
   10a80:      	subq	%rsi, %rax
   10a83:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10a89:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10a8f:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10a95:      	cmpl	%r15d, %r12d
   10a98:      	jbe	0x10a9e <generic_rawtp_path+0x67be>
   10a9a:      	movb	$0x2f, (%rbx,%rax)
   10a9e:      	xorl	%edi, %edi
   10aa0:      	cmpl	%r15d, %r12d
   10aa3:      	seta	%dil
   10aa7:      	movzbl	%cl, %esi
   10aaa:      	addq	%rax, %rbx
   10aad:      	addq	%rbx, %rdi
   10ab0:      	movl	$0x4, %eax
   10ab5:      	callq	*%rax
   10ab7:      	movq	%rbx, 0x48(%rsp)
   10abc:      	cmpl	%r15d, %r12d
   10abf:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10ac5:      	movq	0x8(%rsp), %r12
   10aca:      	movq	%r12, 0x30(%rsp)
   10acf:      	movq	0x38(%rsp), %rdx
   10ad4:      	movq	0x40(%rsp), %r15
   10ad9:      	jmp	0x10b2c <generic_rawtp_path+0x684c>
   10adb:      	leaq	0x10(%r15), %rdx
   10adf:      	movl	$0x4, %eax
   10ae4:      	movq	%rbp, %rdi
   10ae7:      	movl	$0x8, %esi
   10aec:      	callq	*%rax
   10aee:      	movq	0x40(%rsp), %rax
   10af3:      	cmpq	(%rsp), %rax
   10af7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10afd:      	addq	$0x18, %r15
   10b01:      	movl	$0x4, %eax
   10b06:      	leaq	0x30(%rsp), %rdi
   10b0b:      	movl	$0x8, %esi
   10b10:      	movq	%r15, %rdx
   10b13:      	callq	*%rax
   10b15:      	movq	(%rsp), %r15
   10b19:      	movq	%r15, 0x40(%rsp)
   10b1e:      	leaq	0x20(%r15), %rdx
   10b22:      	movq	%rdx, 0x38(%rsp)
   10b27:      	movq	0x30(%rsp), %r12
   10b2c:      	cmpq	0x18(%rsp), %r12
   10b31:      	jne	0x10b3e <generic_rawtp_path+0x685e>
   10b33:      	cmpq	0x20(%rsp), %rdx
   10b38:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10b3e:      	movl	$0x4, %eax
   10b43:      	leaq	0x10(%rsp), %rdi
   10b48:      	movl	$0x8, %esi
   10b4d:      	callq	*%rax
   10b4f:      	cmpq	0x10(%rsp), %r12
   10b54:      	je	0x10c4c <generic_rawtp_path+0x696c>
   10b5a:      	leaq	0x18(%r12), %rbx
   10b5f:      	movl	$0x4, %eax
   10b64:      	movq	%rbp, %rdi
   10b67:      	movl	$0x8, %esi
   10b6c:      	movq	%rbx, %rdx
   10b6f:      	callq	*%rax
   10b71:      	cmpq	%r12, (%rsp)
   10b75:      	je	0x10c4c <generic_rawtp_path+0x696c>
   10b7b:      	movl	$0x4, %eax
   10b80:      	leaq	0x8(%rsp), %rdi
   10b85:      	movl	$0x8, %esi
   10b8a:      	movq	%rbx, %rdx
   10b8d:      	callq	*%rax
   10b8f:      	addq	$0x20, %r12
   10b93:      	movl	$0x4, %eax
   10b98:      	leaq	0x58(%rsp), %rdi
   10b9d:      	movl	$0x10, %ecx
   10ba2:      	movl	$0x10, %esi
   10ba7:      	movq	%r12, %rdx
   10baa:      	callq	*%rax
   10bac:      	movq	0x28(%rsp), %rbx
   10bb1:      	movq	0x48(%rsp), %rax
   10bb6:      	movl	0x5c(%rsp), %r15d
   10bbb:      	subq	%rbx, %rax
   10bbe:      	movl	0x50(%rsp), %r12d
   10bc3:      	movl	%r15d, %edx
   10bc6:      	subl	%r12d, %edx
   10bc9:      	movl	$0x0, %ecx
   10bce:      	cmovbl	%ecx, %edx
   10bd1:      	addq	0x60(%rsp), %rdx
   10bd6:      	xorl	%esi, %esi
   10bd8:      	cmpl	%r15d, %r12d
   10bdb:      	seta	%sil
   10bdf:      	movl	%r15d, %ecx
   10be2:      	cmovbl	%r12d, %ecx
   10be6:      	addl	%ecx, %esi
   10be8:      	movl	%r12d, %edi
   10beb:      	subl	%esi, %edi
   10bed:      	movl	%edi, 0x50(%rsp)
   10bf1:      	subq	%rsi, %rax
   10bf4:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10bfa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10c00:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10c06:      	cmpl	%r15d, %r12d
   10c09:      	jbe	0x10c0f <generic_rawtp_path+0x692f>
   10c0b:      	movb	$0x2f, (%rbx,%rax)
   10c0f:      	xorl	%edi, %edi
   10c11:      	cmpl	%r15d, %r12d
   10c14:      	seta	%dil
   10c18:      	movzbl	%cl, %esi
   10c1b:      	addq	%rax, %rbx
   10c1e:      	addq	%rbx, %rdi
   10c21:      	movl	$0x4, %eax
   10c26:      	callq	*%rax
   10c28:      	movq	%rbx, 0x48(%rsp)
   10c2d:      	cmpl	%r15d, %r12d
   10c30:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10c36:      	movq	0x8(%rsp), %r12
   10c3b:      	movq	%r12, 0x30(%rsp)
   10c40:      	movq	0x38(%rsp), %rdx
   10c45:      	movq	0x40(%rsp), %r15
   10c4a:      	jmp	0x10c9d <generic_rawtp_path+0x69bd>
   10c4c:      	leaq	0x10(%r15), %rdx
   10c50:      	movl	$0x4, %eax
   10c55:      	movq	%rbp, %rdi
   10c58:      	movl	$0x8, %esi
   10c5d:      	callq	*%rax
   10c5f:      	movq	0x40(%rsp), %rax
   10c64:      	cmpq	(%rsp), %rax
   10c68:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10c6e:      	addq	$0x18, %r15
   10c72:      	movl	$0x4, %eax
   10c77:      	leaq	0x30(%rsp), %rdi
   10c7c:      	movl	$0x8, %esi
   10c81:      	movq	%r15, %rdx
   10c84:      	callq	*%rax
   10c86:      	movq	(%rsp), %r15
   10c8a:      	movq	%r15, 0x40(%rsp)
   10c8f:      	leaq	0x20(%r15), %rdx
   10c93:      	movq	%rdx, 0x38(%rsp)
   10c98:      	movq	0x30(%rsp), %r12
   10c9d:      	cmpq	0x18(%rsp), %r12
   10ca2:      	jne	0x10caf <generic_rawtp_path+0x69cf>
   10ca4:      	cmpq	0x20(%rsp), %rdx
   10ca9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10caf:      	movl	$0x4, %eax
   10cb4:      	leaq	0x10(%rsp), %rdi
   10cb9:      	movl	$0x8, %esi
   10cbe:      	callq	*%rax
   10cc0:      	cmpq	0x10(%rsp), %r12
   10cc5:      	je	0x10dbd <generic_rawtp_path+0x6add>
   10ccb:      	leaq	0x18(%r12), %rbx
   10cd0:      	movl	$0x4, %eax
   10cd5:      	movq	%rbp, %rdi
   10cd8:      	movl	$0x8, %esi
   10cdd:      	movq	%rbx, %rdx
   10ce0:      	callq	*%rax
   10ce2:      	cmpq	%r12, (%rsp)
   10ce6:      	je	0x10dbd <generic_rawtp_path+0x6add>
   10cec:      	movl	$0x4, %eax
   10cf1:      	leaq	0x8(%rsp), %rdi
   10cf6:      	movl	$0x8, %esi
   10cfb:      	movq	%rbx, %rdx
   10cfe:      	callq	*%rax
   10d00:      	addq	$0x20, %r12
   10d04:      	movl	$0x4, %eax
   10d09:      	leaq	0x58(%rsp), %rdi
   10d0e:      	movl	$0x10, %ecx
   10d13:      	movl	$0x10, %esi
   10d18:      	movq	%r12, %rdx
   10d1b:      	callq	*%rax
   10d1d:      	movq	0x28(%rsp), %rbx
   10d22:      	movq	0x48(%rsp), %rax
   10d27:      	movl	0x5c(%rsp), %r15d
   10d2c:      	subq	%rbx, %rax
   10d2f:      	movl	0x50(%rsp), %r12d
   10d34:      	movl	%r15d, %edx
   10d37:      	subl	%r12d, %edx
   10d3a:      	movl	$0x0, %ecx
   10d3f:      	cmovbl	%ecx, %edx
   10d42:      	addq	0x60(%rsp), %rdx
   10d47:      	xorl	%esi, %esi
   10d49:      	cmpl	%r15d, %r12d
   10d4c:      	seta	%sil
   10d50:      	movl	%r15d, %ecx
   10d53:      	cmovbl	%r12d, %ecx
   10d57:      	addl	%ecx, %esi
   10d59:      	movl	%r12d, %edi
   10d5c:      	subl	%esi, %edi
   10d5e:      	movl	%edi, 0x50(%rsp)
   10d62:      	subq	%rsi, %rax
   10d65:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10d6b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10d71:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10d77:      	cmpl	%r15d, %r12d
   10d7a:      	jbe	0x10d80 <generic_rawtp_path+0x6aa0>
   10d7c:      	movb	$0x2f, (%rbx,%rax)
   10d80:      	xorl	%edi, %edi
   10d82:      	cmpl	%r15d, %r12d
   10d85:      	seta	%dil
   10d89:      	movzbl	%cl, %esi
   10d8c:      	addq	%rax, %rbx
   10d8f:      	addq	%rbx, %rdi
   10d92:      	movl	$0x4, %eax
   10d97:      	callq	*%rax
   10d99:      	movq	%rbx, 0x48(%rsp)
   10d9e:      	cmpl	%r15d, %r12d
   10da1:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10da7:      	movq	0x8(%rsp), %r12
   10dac:      	movq	%r12, 0x30(%rsp)
   10db1:      	movq	0x38(%rsp), %rdx
   10db6:      	movq	0x40(%rsp), %r15
   10dbb:      	jmp	0x10e0e <generic_rawtp_path+0x6b2e>
   10dbd:      	leaq	0x10(%r15), %rdx
   10dc1:      	movl	$0x4, %eax
   10dc6:      	movq	%rbp, %rdi
   10dc9:      	movl	$0x8, %esi
   10dce:      	callq	*%rax
   10dd0:      	movq	0x40(%rsp), %rax
   10dd5:      	cmpq	(%rsp), %rax
   10dd9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10ddf:      	addq	$0x18, %r15
   10de3:      	movl	$0x4, %eax
   10de8:      	leaq	0x30(%rsp), %rdi
   10ded:      	movl	$0x8, %esi
   10df2:      	movq	%r15, %rdx
   10df5:      	callq	*%rax
   10df7:      	movq	(%rsp), %r15
   10dfb:      	movq	%r15, 0x40(%rsp)
   10e00:      	leaq	0x20(%r15), %rdx
   10e04:      	movq	%rdx, 0x38(%rsp)
   10e09:      	movq	0x30(%rsp), %r12
   10e0e:      	cmpq	0x18(%rsp), %r12
   10e13:      	jne	0x10e20 <generic_rawtp_path+0x6b40>
   10e15:      	cmpq	0x20(%rsp), %rdx
   10e1a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10e20:      	movl	$0x4, %eax
   10e25:      	leaq	0x10(%rsp), %rdi
   10e2a:      	movl	$0x8, %esi
   10e2f:      	callq	*%rax
   10e31:      	cmpq	0x10(%rsp), %r12
   10e36:      	je	0x10f2e <generic_rawtp_path+0x6c4e>
   10e3c:      	leaq	0x18(%r12), %rbx
   10e41:      	movl	$0x4, %eax
   10e46:      	movq	%rbp, %rdi
   10e49:      	movl	$0x8, %esi
   10e4e:      	movq	%rbx, %rdx
   10e51:      	callq	*%rax
   10e53:      	cmpq	%r12, (%rsp)
   10e57:      	je	0x10f2e <generic_rawtp_path+0x6c4e>
   10e5d:      	movl	$0x4, %eax
   10e62:      	leaq	0x8(%rsp), %rdi
   10e67:      	movl	$0x8, %esi
   10e6c:      	movq	%rbx, %rdx
   10e6f:      	callq	*%rax
   10e71:      	addq	$0x20, %r12
   10e75:      	movl	$0x4, %eax
   10e7a:      	leaq	0x58(%rsp), %rdi
   10e7f:      	movl	$0x10, %ecx
   10e84:      	movl	$0x10, %esi
   10e89:      	movq	%r12, %rdx
   10e8c:      	callq	*%rax
   10e8e:      	movq	0x28(%rsp), %rbx
   10e93:      	movq	0x48(%rsp), %rax
   10e98:      	movl	0x5c(%rsp), %r15d
   10e9d:      	subq	%rbx, %rax
   10ea0:      	movl	0x50(%rsp), %r12d
   10ea5:      	movl	%r15d, %edx
   10ea8:      	subl	%r12d, %edx
   10eab:      	movl	$0x0, %ecx
   10eb0:      	cmovbl	%ecx, %edx
   10eb3:      	addq	0x60(%rsp), %rdx
   10eb8:      	xorl	%esi, %esi
   10eba:      	cmpl	%r15d, %r12d
   10ebd:      	seta	%sil
   10ec1:      	movl	%r15d, %ecx
   10ec4:      	cmovbl	%r12d, %ecx
   10ec8:      	addl	%ecx, %esi
   10eca:      	movl	%r12d, %edi
   10ecd:      	subl	%esi, %edi
   10ecf:      	movl	%edi, 0x50(%rsp)
   10ed3:      	subq	%rsi, %rax
   10ed6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   10edc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10ee2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   10ee8:      	cmpl	%r15d, %r12d
   10eeb:      	jbe	0x10ef1 <generic_rawtp_path+0x6c11>
   10eed:      	movb	$0x2f, (%rbx,%rax)
   10ef1:      	xorl	%edi, %edi
   10ef3:      	cmpl	%r15d, %r12d
   10ef6:      	seta	%dil
   10efa:      	movzbl	%cl, %esi
   10efd:      	addq	%rax, %rbx
   10f00:      	addq	%rbx, %rdi
   10f03:      	movl	$0x4, %eax
   10f08:      	callq	*%rax
   10f0a:      	movq	%rbx, 0x48(%rsp)
   10f0f:      	cmpl	%r15d, %r12d
   10f12:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   10f18:      	movq	0x8(%rsp), %r12
   10f1d:      	movq	%r12, 0x30(%rsp)
   10f22:      	movq	0x38(%rsp), %rdx
   10f27:      	movq	0x40(%rsp), %r15
   10f2c:      	jmp	0x10f7f <generic_rawtp_path+0x6c9f>
   10f2e:      	leaq	0x10(%r15), %rdx
   10f32:      	movl	$0x4, %eax
   10f37:      	movq	%rbp, %rdi
   10f3a:      	movl	$0x8, %esi
   10f3f:      	callq	*%rax
   10f41:      	movq	0x40(%rsp), %rax
   10f46:      	cmpq	(%rsp), %rax
   10f4a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10f50:      	addq	$0x18, %r15
   10f54:      	movl	$0x4, %eax
   10f59:      	leaq	0x30(%rsp), %rdi
   10f5e:      	movl	$0x8, %esi
   10f63:      	movq	%r15, %rdx
   10f66:      	callq	*%rax
   10f68:      	movq	(%rsp), %r15
   10f6c:      	movq	%r15, 0x40(%rsp)
   10f71:      	leaq	0x20(%r15), %rdx
   10f75:      	movq	%rdx, 0x38(%rsp)
   10f7a:      	movq	0x30(%rsp), %r12
   10f7f:      	cmpq	0x18(%rsp), %r12
   10f84:      	jne	0x10f91 <generic_rawtp_path+0x6cb1>
   10f86:      	cmpq	0x20(%rsp), %rdx
   10f8b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   10f91:      	movl	$0x4, %eax
   10f96:      	leaq	0x10(%rsp), %rdi
   10f9b:      	movl	$0x8, %esi
   10fa0:      	callq	*%rax
   10fa2:      	cmpq	0x10(%rsp), %r12
   10fa7:      	je	0x1109f <generic_rawtp_path+0x6dbf>
   10fad:      	leaq	0x18(%r12), %rbx
   10fb2:      	movl	$0x4, %eax
   10fb7:      	movq	%rbp, %rdi
   10fba:      	movl	$0x8, %esi
   10fbf:      	movq	%rbx, %rdx
   10fc2:      	callq	*%rax
   10fc4:      	cmpq	%r12, (%rsp)
   10fc8:      	je	0x1109f <generic_rawtp_path+0x6dbf>
   10fce:      	movl	$0x4, %eax
   10fd3:      	leaq	0x8(%rsp), %rdi
   10fd8:      	movl	$0x8, %esi
   10fdd:      	movq	%rbx, %rdx
   10fe0:      	callq	*%rax
   10fe2:      	addq	$0x20, %r12
   10fe6:      	movl	$0x4, %eax
   10feb:      	leaq	0x58(%rsp), %rdi
   10ff0:      	movl	$0x10, %ecx
   10ff5:      	movl	$0x10, %esi
   10ffa:      	movq	%r12, %rdx
   10ffd:      	callq	*%rax
   10fff:      	movq	0x28(%rsp), %rbx
   11004:      	movq	0x48(%rsp), %rax
   11009:      	movl	0x5c(%rsp), %r15d
   1100e:      	subq	%rbx, %rax
   11011:      	movl	0x50(%rsp), %r12d
   11016:      	movl	%r15d, %edx
   11019:      	subl	%r12d, %edx
   1101c:      	movl	$0x0, %ecx
   11021:      	cmovbl	%ecx, %edx
   11024:      	addq	0x60(%rsp), %rdx
   11029:      	xorl	%esi, %esi
   1102b:      	cmpl	%r15d, %r12d
   1102e:      	seta	%sil
   11032:      	movl	%r15d, %ecx
   11035:      	cmovbl	%r12d, %ecx
   11039:      	addl	%ecx, %esi
   1103b:      	movl	%r12d, %edi
   1103e:      	subl	%esi, %edi
   11040:      	movl	%edi, 0x50(%rsp)
   11044:      	subq	%rsi, %rax
   11047:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1104d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11053:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   11059:      	cmpl	%r15d, %r12d
   1105c:      	jbe	0x11062 <generic_rawtp_path+0x6d82>
   1105e:      	movb	$0x2f, (%rbx,%rax)
   11062:      	xorl	%edi, %edi
   11064:      	cmpl	%r15d, %r12d
   11067:      	seta	%dil
   1106b:      	movzbl	%cl, %esi
   1106e:      	addq	%rax, %rbx
   11071:      	addq	%rbx, %rdi
   11074:      	movl	$0x4, %eax
   11079:      	callq	*%rax
   1107b:      	movq	%rbx, 0x48(%rsp)
   11080:      	cmpl	%r15d, %r12d
   11083:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   11089:      	movq	0x8(%rsp), %r12
   1108e:      	movq	%r12, 0x30(%rsp)
   11093:      	movq	0x38(%rsp), %rdx
   11098:      	movq	0x40(%rsp), %r15
   1109d:      	jmp	0x110f0 <generic_rawtp_path+0x6e10>
   1109f:      	leaq	0x10(%r15), %rdx
   110a3:      	movl	$0x4, %eax
   110a8:      	movq	%rbp, %rdi
   110ab:      	movl	$0x8, %esi
   110b0:      	callq	*%rax
   110b2:      	movq	0x40(%rsp), %rax
   110b7:      	cmpq	(%rsp), %rax
   110bb:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   110c1:      	addq	$0x18, %r15
   110c5:      	movl	$0x4, %eax
   110ca:      	leaq	0x30(%rsp), %rdi
   110cf:      	movl	$0x8, %esi
   110d4:      	movq	%r15, %rdx
   110d7:      	callq	*%rax
   110d9:      	movq	(%rsp), %r15
   110dd:      	movq	%r15, 0x40(%rsp)
   110e2:      	leaq	0x20(%r15), %rdx
   110e6:      	movq	%rdx, 0x38(%rsp)
   110eb:      	movq	0x30(%rsp), %r12
   110f0:      	cmpq	0x18(%rsp), %r12
   110f5:      	jne	0x11102 <generic_rawtp_path+0x6e22>
   110f7:      	cmpq	0x20(%rsp), %rdx
   110fc:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11102:      	movl	$0x4, %eax
   11107:      	leaq	0x10(%rsp), %rdi
   1110c:      	movl	$0x8, %esi
   11111:      	callq	*%rax
   11113:      	cmpq	0x10(%rsp), %r12
   11118:      	je	0x11210 <generic_rawtp_path+0x6f30>
   1111e:      	leaq	0x18(%r12), %rbx
   11123:      	movl	$0x4, %eax
   11128:      	movq	%rbp, %rdi
   1112b:      	movl	$0x8, %esi
   11130:      	movq	%rbx, %rdx
   11133:      	callq	*%rax
   11135:      	cmpq	%r12, (%rsp)
   11139:      	je	0x11210 <generic_rawtp_path+0x6f30>
   1113f:      	movl	$0x4, %eax
   11144:      	leaq	0x8(%rsp), %rdi
   11149:      	movl	$0x8, %esi
   1114e:      	movq	%rbx, %rdx
   11151:      	callq	*%rax
   11153:      	addq	$0x20, %r12
   11157:      	movl	$0x4, %eax
   1115c:      	leaq	0x58(%rsp), %rdi
   11161:      	movl	$0x10, %ecx
   11166:      	movl	$0x10, %esi
   1116b:      	movq	%r12, %rdx
   1116e:      	callq	*%rax
   11170:      	movq	0x28(%rsp), %rbx
   11175:      	movq	0x48(%rsp), %rax
   1117a:      	movl	0x5c(%rsp), %r15d
   1117f:      	subq	%rbx, %rax
   11182:      	movl	0x50(%rsp), %r12d
   11187:      	movl	%r15d, %edx
   1118a:      	subl	%r12d, %edx
   1118d:      	movl	$0x0, %ecx
   11192:      	cmovbl	%ecx, %edx
   11195:      	addq	0x60(%rsp), %rdx
   1119a:      	xorl	%esi, %esi
   1119c:      	cmpl	%r15d, %r12d
   1119f:      	seta	%sil
   111a3:      	movl	%r15d, %ecx
   111a6:      	cmovbl	%r12d, %ecx
   111aa:      	addl	%ecx, %esi
   111ac:      	movl	%r12d, %edi
   111af:      	subl	%esi, %edi
   111b1:      	movl	%edi, 0x50(%rsp)
   111b5:      	subq	%rsi, %rax
   111b8:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   111be:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   111c4:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   111ca:      	cmpl	%r15d, %r12d
   111cd:      	jbe	0x111d3 <generic_rawtp_path+0x6ef3>
   111cf:      	movb	$0x2f, (%rbx,%rax)
   111d3:      	xorl	%edi, %edi
   111d5:      	cmpl	%r15d, %r12d
   111d8:      	seta	%dil
   111dc:      	movzbl	%cl, %esi
   111df:      	addq	%rax, %rbx
   111e2:      	addq	%rbx, %rdi
   111e5:      	movl	$0x4, %eax
   111ea:      	callq	*%rax
   111ec:      	movq	%rbx, 0x48(%rsp)
   111f1:      	cmpl	%r15d, %r12d
   111f4:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   111fa:      	movq	0x8(%rsp), %r12
   111ff:      	movq	%r12, 0x30(%rsp)
   11204:      	movq	0x38(%rsp), %rdx
   11209:      	movq	0x40(%rsp), %r15
   1120e:      	jmp	0x11261 <generic_rawtp_path+0x6f81>
   11210:      	leaq	0x10(%r15), %rdx
   11214:      	movl	$0x4, %eax
   11219:      	movq	%rbp, %rdi
   1121c:      	movl	$0x8, %esi
   11221:      	callq	*%rax
   11223:      	movq	0x40(%rsp), %rax
   11228:      	cmpq	(%rsp), %rax
   1122c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11232:      	addq	$0x18, %r15
   11236:      	movl	$0x4, %eax
   1123b:      	leaq	0x30(%rsp), %rdi
   11240:      	movl	$0x8, %esi
   11245:      	movq	%r15, %rdx
   11248:      	callq	*%rax
   1124a:      	movq	(%rsp), %r15
   1124e:      	movq	%r15, 0x40(%rsp)
   11253:      	leaq	0x20(%r15), %rdx
   11257:      	movq	%rdx, 0x38(%rsp)
   1125c:      	movq	0x30(%rsp), %r12
   11261:      	cmpq	0x18(%rsp), %r12
   11266:      	jne	0x11273 <generic_rawtp_path+0x6f93>
   11268:      	cmpq	0x20(%rsp), %rdx
   1126d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11273:      	movl	$0x4, %eax
   11278:      	leaq	0x10(%rsp), %rdi
   1127d:      	movl	$0x8, %esi
   11282:      	callq	*%rax
   11284:      	cmpq	0x10(%rsp), %r12
   11289:      	je	0x11381 <generic_rawtp_path+0x70a1>
   1128f:      	leaq	0x18(%r12), %rbx
   11294:      	movl	$0x4, %eax
   11299:      	movq	%rbp, %rdi
   1129c:      	movl	$0x8, %esi
   112a1:      	movq	%rbx, %rdx
   112a4:      	callq	*%rax
   112a6:      	cmpq	%r12, (%rsp)
   112aa:      	je	0x11381 <generic_rawtp_path+0x70a1>
   112b0:      	movl	$0x4, %eax
   112b5:      	leaq	0x8(%rsp), %rdi
   112ba:      	movl	$0x8, %esi
   112bf:      	movq	%rbx, %rdx
   112c2:      	callq	*%rax
   112c4:      	addq	$0x20, %r12
   112c8:      	movl	$0x4, %eax
   112cd:      	leaq	0x58(%rsp), %rdi
   112d2:      	movl	$0x10, %ecx
   112d7:      	movl	$0x10, %esi
   112dc:      	movq	%r12, %rdx
   112df:      	callq	*%rax
   112e1:      	movq	0x28(%rsp), %rbx
   112e6:      	movq	0x48(%rsp), %rax
   112eb:      	movl	0x5c(%rsp), %r15d
   112f0:      	subq	%rbx, %rax
   112f3:      	movl	0x50(%rsp), %r12d
   112f8:      	movl	%r15d, %edx
   112fb:      	subl	%r12d, %edx
   112fe:      	movl	$0x0, %ecx
   11303:      	cmovbl	%ecx, %edx
   11306:      	addq	0x60(%rsp), %rdx
   1130b:      	xorl	%esi, %esi
   1130d:      	cmpl	%r15d, %r12d
   11310:      	seta	%sil
   11314:      	movl	%r15d, %ecx
   11317:      	cmovbl	%r12d, %ecx
   1131b:      	addl	%ecx, %esi
   1131d:      	movl	%r12d, %edi
   11320:      	subl	%esi, %edi
   11322:      	movl	%edi, 0x50(%rsp)
   11326:      	subq	%rsi, %rax
   11329:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1132f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11335:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1133b:      	cmpl	%r15d, %r12d
   1133e:      	jbe	0x11344 <generic_rawtp_path+0x7064>
   11340:      	movb	$0x2f, (%rbx,%rax)
   11344:      	xorl	%edi, %edi
   11346:      	cmpl	%r15d, %r12d
   11349:      	seta	%dil
   1134d:      	movzbl	%cl, %esi
   11350:      	addq	%rax, %rbx
   11353:      	addq	%rbx, %rdi
   11356:      	movl	$0x4, %eax
   1135b:      	callq	*%rax
   1135d:      	movq	%rbx, 0x48(%rsp)
   11362:      	cmpl	%r15d, %r12d
   11365:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1136b:      	movq	0x8(%rsp), %r12
   11370:      	movq	%r12, 0x30(%rsp)
   11375:      	movq	0x38(%rsp), %rdx
   1137a:      	movq	0x40(%rsp), %r15
   1137f:      	jmp	0x113d2 <generic_rawtp_path+0x70f2>
   11381:      	leaq	0x10(%r15), %rdx
   11385:      	movl	$0x4, %eax
   1138a:      	movq	%rbp, %rdi
   1138d:      	movl	$0x8, %esi
   11392:      	callq	*%rax
   11394:      	movq	0x40(%rsp), %rax
   11399:      	cmpq	(%rsp), %rax
   1139d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   113a3:      	addq	$0x18, %r15
   113a7:      	movl	$0x4, %eax
   113ac:      	leaq	0x30(%rsp), %rdi
   113b1:      	movl	$0x8, %esi
   113b6:      	movq	%r15, %rdx
   113b9:      	callq	*%rax
   113bb:      	movq	(%rsp), %r15
   113bf:      	movq	%r15, 0x40(%rsp)
   113c4:      	leaq	0x20(%r15), %rdx
   113c8:      	movq	%rdx, 0x38(%rsp)
   113cd:      	movq	0x30(%rsp), %r12
   113d2:      	cmpq	0x18(%rsp), %r12
   113d7:      	jne	0x113e4 <generic_rawtp_path+0x7104>
   113d9:      	cmpq	0x20(%rsp), %rdx
   113de:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   113e4:      	movl	$0x4, %eax
   113e9:      	leaq	0x10(%rsp), %rdi
   113ee:      	movl	$0x8, %esi
   113f3:      	callq	*%rax
   113f5:      	cmpq	0x10(%rsp), %r12
   113fa:      	je	0x114f2 <generic_rawtp_path+0x7212>
   11400:      	leaq	0x18(%r12), %rbx
   11405:      	movl	$0x4, %eax
   1140a:      	movq	%rbp, %rdi
   1140d:      	movl	$0x8, %esi
   11412:      	movq	%rbx, %rdx
   11415:      	callq	*%rax
   11417:      	cmpq	%r12, (%rsp)
   1141b:      	je	0x114f2 <generic_rawtp_path+0x7212>
   11421:      	movl	$0x4, %eax
   11426:      	leaq	0x8(%rsp), %rdi
   1142b:      	movl	$0x8, %esi
   11430:      	movq	%rbx, %rdx
   11433:      	callq	*%rax
   11435:      	addq	$0x20, %r12
   11439:      	movl	$0x4, %eax
   1143e:      	leaq	0x58(%rsp), %rdi
   11443:      	movl	$0x10, %ecx
   11448:      	movl	$0x10, %esi
   1144d:      	movq	%r12, %rdx
   11450:      	callq	*%rax
   11452:      	movq	0x28(%rsp), %rbx
   11457:      	movq	0x48(%rsp), %rax
   1145c:      	movl	0x5c(%rsp), %r15d
   11461:      	subq	%rbx, %rax
   11464:      	movl	0x50(%rsp), %r12d
   11469:      	movl	%r15d, %edx
   1146c:      	subl	%r12d, %edx
   1146f:      	movl	$0x0, %ecx
   11474:      	cmovbl	%ecx, %edx
   11477:      	addq	0x60(%rsp), %rdx
   1147c:      	xorl	%esi, %esi
   1147e:      	cmpl	%r15d, %r12d
   11481:      	seta	%sil
   11485:      	movl	%r15d, %ecx
   11488:      	cmovbl	%r12d, %ecx
   1148c:      	addl	%ecx, %esi
   1148e:      	movl	%r12d, %edi
   11491:      	subl	%esi, %edi
   11493:      	movl	%edi, 0x50(%rsp)
   11497:      	subq	%rsi, %rax
   1149a:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   114a0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   114a6:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   114ac:      	cmpl	%r15d, %r12d
   114af:      	jbe	0x114b5 <generic_rawtp_path+0x71d5>
   114b1:      	movb	$0x2f, (%rbx,%rax)
   114b5:      	xorl	%edi, %edi
   114b7:      	cmpl	%r15d, %r12d
   114ba:      	seta	%dil
   114be:      	movzbl	%cl, %esi
   114c1:      	addq	%rax, %rbx
   114c4:      	addq	%rbx, %rdi
   114c7:      	movl	$0x4, %eax
   114cc:      	callq	*%rax
   114ce:      	movq	%rbx, 0x48(%rsp)
   114d3:      	cmpl	%r15d, %r12d
   114d6:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   114dc:      	movq	0x8(%rsp), %r12
   114e1:      	movq	%r12, 0x30(%rsp)
   114e6:      	movq	0x38(%rsp), %rdx
   114eb:      	movq	0x40(%rsp), %r15
   114f0:      	jmp	0x11543 <generic_rawtp_path+0x7263>
   114f2:      	leaq	0x10(%r15), %rdx
   114f6:      	movl	$0x4, %eax
   114fb:      	movq	%rbp, %rdi
   114fe:      	movl	$0x8, %esi
   11503:      	callq	*%rax
   11505:      	movq	0x40(%rsp), %rax
   1150a:      	cmpq	(%rsp), %rax
   1150e:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11514:      	addq	$0x18, %r15
   11518:      	movl	$0x4, %eax
   1151d:      	leaq	0x30(%rsp), %rdi
   11522:      	movl	$0x8, %esi
   11527:      	movq	%r15, %rdx
   1152a:      	callq	*%rax
   1152c:      	movq	(%rsp), %r15
   11530:      	movq	%r15, 0x40(%rsp)
   11535:      	leaq	0x20(%r15), %rdx
   11539:      	movq	%rdx, 0x38(%rsp)
   1153e:      	movq	0x30(%rsp), %r12
   11543:      	cmpq	0x18(%rsp), %r12
   11548:      	jne	0x11555 <generic_rawtp_path+0x7275>
   1154a:      	cmpq	0x20(%rsp), %rdx
   1154f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11555:      	movl	$0x4, %eax
   1155a:      	leaq	0x10(%rsp), %rdi
   1155f:      	movl	$0x8, %esi
   11564:      	callq	*%rax
   11566:      	cmpq	0x10(%rsp), %r12
   1156b:      	je	0x11663 <generic_rawtp_path+0x7383>
   11571:      	leaq	0x18(%r12), %rbx
   11576:      	movl	$0x4, %eax
   1157b:      	movq	%rbp, %rdi
   1157e:      	movl	$0x8, %esi
   11583:      	movq	%rbx, %rdx
   11586:      	callq	*%rax
   11588:      	cmpq	%r12, (%rsp)
   1158c:      	je	0x11663 <generic_rawtp_path+0x7383>
   11592:      	movl	$0x4, %eax
   11597:      	leaq	0x8(%rsp), %rdi
   1159c:      	movl	$0x8, %esi
   115a1:      	movq	%rbx, %rdx
   115a4:      	callq	*%rax
   115a6:      	addq	$0x20, %r12
   115aa:      	movl	$0x4, %eax
   115af:      	leaq	0x58(%rsp), %rdi
   115b4:      	movl	$0x10, %ecx
   115b9:      	movl	$0x10, %esi
   115be:      	movq	%r12, %rdx
   115c1:      	callq	*%rax
   115c3:      	movq	0x28(%rsp), %rbx
   115c8:      	movq	0x48(%rsp), %rax
   115cd:      	movl	0x5c(%rsp), %r15d
   115d2:      	subq	%rbx, %rax
   115d5:      	movl	0x50(%rsp), %r12d
   115da:      	movl	%r15d, %edx
   115dd:      	subl	%r12d, %edx
   115e0:      	movl	$0x0, %ecx
   115e5:      	cmovbl	%ecx, %edx
   115e8:      	addq	0x60(%rsp), %rdx
   115ed:      	xorl	%esi, %esi
   115ef:      	cmpl	%r15d, %r12d
   115f2:      	seta	%sil
   115f6:      	movl	%r15d, %ecx
   115f9:      	cmovbl	%r12d, %ecx
   115fd:      	addl	%ecx, %esi
   115ff:      	movl	%r12d, %edi
   11602:      	subl	%esi, %edi
   11604:      	movl	%edi, 0x50(%rsp)
   11608:      	subq	%rsi, %rax
   1160b:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   11611:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11617:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1161d:      	cmpl	%r15d, %r12d
   11620:      	jbe	0x11626 <generic_rawtp_path+0x7346>
   11622:      	movb	$0x2f, (%rbx,%rax)
   11626:      	xorl	%edi, %edi
   11628:      	cmpl	%r15d, %r12d
   1162b:      	seta	%dil
   1162f:      	movzbl	%cl, %esi
   11632:      	addq	%rax, %rbx
   11635:      	addq	%rbx, %rdi
   11638:      	movl	$0x4, %eax
   1163d:      	callq	*%rax
   1163f:      	movq	%rbx, 0x48(%rsp)
   11644:      	cmpl	%r15d, %r12d
   11647:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1164d:      	movq	0x8(%rsp), %r12
   11652:      	movq	%r12, 0x30(%rsp)
   11657:      	movq	0x38(%rsp), %rdx
   1165c:      	movq	0x40(%rsp), %r15
   11661:      	jmp	0x116b4 <generic_rawtp_path+0x73d4>
   11663:      	leaq	0x10(%r15), %rdx
   11667:      	movl	$0x4, %eax
   1166c:      	movq	%rbp, %rdi
   1166f:      	movl	$0x8, %esi
   11674:      	callq	*%rax
   11676:      	movq	0x40(%rsp), %rax
   1167b:      	cmpq	(%rsp), %rax
   1167f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11685:      	addq	$0x18, %r15
   11689:      	movl	$0x4, %eax
   1168e:      	leaq	0x30(%rsp), %rdi
   11693:      	movl	$0x8, %esi
   11698:      	movq	%r15, %rdx
   1169b:      	callq	*%rax
   1169d:      	movq	(%rsp), %r15
   116a1:      	movq	%r15, 0x40(%rsp)
   116a6:      	leaq	0x20(%r15), %rdx
   116aa:      	movq	%rdx, 0x38(%rsp)
   116af:      	movq	0x30(%rsp), %r12
   116b4:      	cmpq	0x18(%rsp), %r12
   116b9:      	jne	0x116c6 <generic_rawtp_path+0x73e6>
   116bb:      	cmpq	0x20(%rsp), %rdx
   116c0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   116c6:      	movl	$0x4, %eax
   116cb:      	leaq	0x10(%rsp), %rdi
   116d0:      	movl	$0x8, %esi
   116d5:      	callq	*%rax
   116d7:      	cmpq	0x10(%rsp), %r12
   116dc:      	je	0x117d4 <generic_rawtp_path+0x74f4>
   116e2:      	leaq	0x18(%r12), %rbx
   116e7:      	movl	$0x4, %eax
   116ec:      	movq	%rbp, %rdi
   116ef:      	movl	$0x8, %esi
   116f4:      	movq	%rbx, %rdx
   116f7:      	callq	*%rax
   116f9:      	cmpq	%r12, (%rsp)
   116fd:      	je	0x117d4 <generic_rawtp_path+0x74f4>
   11703:      	movl	$0x4, %eax
   11708:      	leaq	0x8(%rsp), %rdi
   1170d:      	movl	$0x8, %esi
   11712:      	movq	%rbx, %rdx
   11715:      	callq	*%rax
   11717:      	addq	$0x20, %r12
   1171b:      	movl	$0x4, %eax
   11720:      	leaq	0x58(%rsp), %rdi
   11725:      	movl	$0x10, %ecx
   1172a:      	movl	$0x10, %esi
   1172f:      	movq	%r12, %rdx
   11732:      	callq	*%rax
   11734:      	movq	0x28(%rsp), %rbx
   11739:      	movq	0x48(%rsp), %rax
   1173e:      	movl	0x5c(%rsp), %r15d
   11743:      	subq	%rbx, %rax
   11746:      	movl	0x50(%rsp), %r12d
   1174b:      	movl	%r15d, %edx
   1174e:      	subl	%r12d, %edx
   11751:      	movl	$0x0, %ecx
   11756:      	cmovbl	%ecx, %edx
   11759:      	addq	0x60(%rsp), %rdx
   1175e:      	xorl	%esi, %esi
   11760:      	cmpl	%r15d, %r12d
   11763:      	seta	%sil
   11767:      	movl	%r15d, %ecx
   1176a:      	cmovbl	%r12d, %ecx
   1176e:      	addl	%ecx, %esi
   11770:      	movl	%r12d, %edi
   11773:      	subl	%esi, %edi
   11775:      	movl	%edi, 0x50(%rsp)
   11779:      	subq	%rsi, %rax
   1177c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   11782:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11788:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1178e:      	cmpl	%r15d, %r12d
   11791:      	jbe	0x11797 <generic_rawtp_path+0x74b7>
   11793:      	movb	$0x2f, (%rbx,%rax)
   11797:      	xorl	%edi, %edi
   11799:      	cmpl	%r15d, %r12d
   1179c:      	seta	%dil
   117a0:      	movzbl	%cl, %esi
   117a3:      	addq	%rax, %rbx
   117a6:      	addq	%rbx, %rdi
   117a9:      	movl	$0x4, %eax
   117ae:      	callq	*%rax
   117b0:      	movq	%rbx, 0x48(%rsp)
   117b5:      	cmpl	%r15d, %r12d
   117b8:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   117be:      	movq	0x8(%rsp), %r12
   117c3:      	movq	%r12, 0x30(%rsp)
   117c8:      	movq	0x38(%rsp), %rdx
   117cd:      	movq	0x40(%rsp), %r15
   117d2:      	jmp	0x11825 <generic_rawtp_path+0x7545>
   117d4:      	leaq	0x10(%r15), %rdx
   117d8:      	movl	$0x4, %eax
   117dd:      	movq	%rbp, %rdi
   117e0:      	movl	$0x8, %esi
   117e5:      	callq	*%rax
   117e7:      	movq	0x40(%rsp), %rax
   117ec:      	cmpq	(%rsp), %rax
   117f0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   117f6:      	addq	$0x18, %r15
   117fa:      	movl	$0x4, %eax
   117ff:      	leaq	0x30(%rsp), %rdi
   11804:      	movl	$0x8, %esi
   11809:      	movq	%r15, %rdx
   1180c:      	callq	*%rax
   1180e:      	movq	(%rsp), %r15
   11812:      	movq	%r15, 0x40(%rsp)
   11817:      	leaq	0x20(%r15), %rdx
   1181b:      	movq	%rdx, 0x38(%rsp)
   11820:      	movq	0x30(%rsp), %r12
   11825:      	cmpq	0x18(%rsp), %r12
   1182a:      	jne	0x11837 <generic_rawtp_path+0x7557>
   1182c:      	cmpq	0x20(%rsp), %rdx
   11831:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11837:      	movl	$0x4, %eax
   1183c:      	leaq	0x10(%rsp), %rdi
   11841:      	movl	$0x8, %esi
   11846:      	callq	*%rax
   11848:      	cmpq	0x10(%rsp), %r12
   1184d:      	je	0x11945 <generic_rawtp_path+0x7665>
   11853:      	leaq	0x18(%r12), %rbx
   11858:      	movl	$0x4, %eax
   1185d:      	movq	%rbp, %rdi
   11860:      	movl	$0x8, %esi
   11865:      	movq	%rbx, %rdx
   11868:      	callq	*%rax
   1186a:      	cmpq	%r12, (%rsp)
   1186e:      	je	0x11945 <generic_rawtp_path+0x7665>
   11874:      	movl	$0x4, %eax
   11879:      	leaq	0x8(%rsp), %rdi
   1187e:      	movl	$0x8, %esi
   11883:      	movq	%rbx, %rdx
   11886:      	callq	*%rax
   11888:      	addq	$0x20, %r12
   1188c:      	movl	$0x4, %eax
   11891:      	leaq	0x58(%rsp), %rdi
   11896:      	movl	$0x10, %ecx
   1189b:      	movl	$0x10, %esi
   118a0:      	movq	%r12, %rdx
   118a3:      	callq	*%rax
   118a5:      	movq	0x28(%rsp), %rbx
   118aa:      	movq	0x48(%rsp), %rax
   118af:      	movl	0x5c(%rsp), %r15d
   118b4:      	subq	%rbx, %rax
   118b7:      	movl	0x50(%rsp), %r12d
   118bc:      	movl	%r15d, %edx
   118bf:      	subl	%r12d, %edx
   118c2:      	movl	$0x0, %ecx
   118c7:      	cmovbl	%ecx, %edx
   118ca:      	addq	0x60(%rsp), %rdx
   118cf:      	xorl	%esi, %esi
   118d1:      	cmpl	%r15d, %r12d
   118d4:      	seta	%sil
   118d8:      	movl	%r15d, %ecx
   118db:      	cmovbl	%r12d, %ecx
   118df:      	addl	%ecx, %esi
   118e1:      	movl	%r12d, %edi
   118e4:      	subl	%esi, %edi
   118e6:      	movl	%edi, 0x50(%rsp)
   118ea:      	subq	%rsi, %rax
   118ed:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   118f3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   118f9:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   118ff:      	cmpl	%r15d, %r12d
   11902:      	jbe	0x11908 <generic_rawtp_path+0x7628>
   11904:      	movb	$0x2f, (%rbx,%rax)
   11908:      	xorl	%edi, %edi
   1190a:      	cmpl	%r15d, %r12d
   1190d:      	seta	%dil
   11911:      	movzbl	%cl, %esi
   11914:      	addq	%rax, %rbx
   11917:      	addq	%rbx, %rdi
   1191a:      	movl	$0x4, %eax
   1191f:      	callq	*%rax
   11921:      	movq	%rbx, 0x48(%rsp)
   11926:      	cmpl	%r15d, %r12d
   11929:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1192f:      	movq	0x8(%rsp), %r12
   11934:      	movq	%r12, 0x30(%rsp)
   11939:      	movq	0x38(%rsp), %rdx
   1193e:      	movq	0x40(%rsp), %r15
   11943:      	jmp	0x11996 <generic_rawtp_path+0x76b6>
   11945:      	leaq	0x10(%r15), %rdx
   11949:      	movl	$0x4, %eax
   1194e:      	movq	%rbp, %rdi
   11951:      	movl	$0x8, %esi
   11956:      	callq	*%rax
   11958:      	movq	0x40(%rsp), %rax
   1195d:      	cmpq	(%rsp), %rax
   11961:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11967:      	addq	$0x18, %r15
   1196b:      	movl	$0x4, %eax
   11970:      	leaq	0x30(%rsp), %rdi
   11975:      	movl	$0x8, %esi
   1197a:      	movq	%r15, %rdx
   1197d:      	callq	*%rax
   1197f:      	movq	(%rsp), %r15
   11983:      	movq	%r15, 0x40(%rsp)
   11988:      	leaq	0x20(%r15), %rdx
   1198c:      	movq	%rdx, 0x38(%rsp)
   11991:      	movq	0x30(%rsp), %r12
   11996:      	cmpq	0x18(%rsp), %r12
   1199b:      	jne	0x119a8 <generic_rawtp_path+0x76c8>
   1199d:      	cmpq	0x20(%rsp), %rdx
   119a2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   119a8:      	movl	$0x4, %eax
   119ad:      	leaq	0x10(%rsp), %rdi
   119b2:      	movl	$0x8, %esi
   119b7:      	callq	*%rax
   119b9:      	cmpq	0x10(%rsp), %r12
   119be:      	je	0x11ab6 <generic_rawtp_path+0x77d6>
   119c4:      	leaq	0x18(%r12), %rbx
   119c9:      	movl	$0x4, %eax
   119ce:      	movq	%rbp, %rdi
   119d1:      	movl	$0x8, %esi
   119d6:      	movq	%rbx, %rdx
   119d9:      	callq	*%rax
   119db:      	cmpq	%r12, (%rsp)
   119df:      	je	0x11ab6 <generic_rawtp_path+0x77d6>
   119e5:      	movl	$0x4, %eax
   119ea:      	leaq	0x8(%rsp), %rdi
   119ef:      	movl	$0x8, %esi
   119f4:      	movq	%rbx, %rdx
   119f7:      	callq	*%rax
   119f9:      	addq	$0x20, %r12
   119fd:      	movl	$0x4, %eax
   11a02:      	leaq	0x58(%rsp), %rdi
   11a07:      	movl	$0x10, %ecx
   11a0c:      	movl	$0x10, %esi
   11a11:      	movq	%r12, %rdx
   11a14:      	callq	*%rax
   11a16:      	movq	0x28(%rsp), %rbx
   11a1b:      	movq	0x48(%rsp), %rax
   11a20:      	movl	0x5c(%rsp), %r15d
   11a25:      	subq	%rbx, %rax
   11a28:      	movl	0x50(%rsp), %r12d
   11a2d:      	movl	%r15d, %edx
   11a30:      	subl	%r12d, %edx
   11a33:      	movl	$0x0, %ecx
   11a38:      	cmovbl	%ecx, %edx
   11a3b:      	addq	0x60(%rsp), %rdx
   11a40:      	xorl	%esi, %esi
   11a42:      	cmpl	%r15d, %r12d
   11a45:      	seta	%sil
   11a49:      	movl	%r15d, %ecx
   11a4c:      	cmovbl	%r12d, %ecx
   11a50:      	addl	%ecx, %esi
   11a52:      	movl	%r12d, %edi
   11a55:      	subl	%esi, %edi
   11a57:      	movl	%edi, 0x50(%rsp)
   11a5b:      	subq	%rsi, %rax
   11a5e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   11a64:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11a6a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   11a70:      	cmpl	%r15d, %r12d
   11a73:      	jbe	0x11a79 <generic_rawtp_path+0x7799>
   11a75:      	movb	$0x2f, (%rbx,%rax)
   11a79:      	xorl	%edi, %edi
   11a7b:      	cmpl	%r15d, %r12d
   11a7e:      	seta	%dil
   11a82:      	movzbl	%cl, %esi
   11a85:      	addq	%rax, %rbx
   11a88:      	addq	%rbx, %rdi
   11a8b:      	movl	$0x4, %eax
   11a90:      	callq	*%rax
   11a92:      	movq	%rbx, 0x48(%rsp)
   11a97:      	cmpl	%r15d, %r12d
   11a9a:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   11aa0:      	movq	0x8(%rsp), %r12
   11aa5:      	movq	%r12, 0x30(%rsp)
   11aaa:      	movq	0x38(%rsp), %rdx
   11aaf:      	movq	0x40(%rsp), %r15
   11ab4:      	jmp	0x11b07 <generic_rawtp_path+0x7827>
   11ab6:      	leaq	0x10(%r15), %rdx
   11aba:      	movl	$0x4, %eax
   11abf:      	movq	%rbp, %rdi
   11ac2:      	movl	$0x8, %esi
   11ac7:      	callq	*%rax
   11ac9:      	movq	0x40(%rsp), %rax
   11ace:      	cmpq	(%rsp), %rax
   11ad2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11ad8:      	addq	$0x18, %r15
   11adc:      	movl	$0x4, %eax
   11ae1:      	leaq	0x30(%rsp), %rdi
   11ae6:      	movl	$0x8, %esi
   11aeb:      	movq	%r15, %rdx
   11aee:      	callq	*%rax
   11af0:      	movq	(%rsp), %r15
   11af4:      	movq	%r15, 0x40(%rsp)
   11af9:      	leaq	0x20(%r15), %rdx
   11afd:      	movq	%rdx, 0x38(%rsp)
   11b02:      	movq	0x30(%rsp), %r12
   11b07:      	cmpq	0x18(%rsp), %r12
   11b0c:      	jne	0x11b19 <generic_rawtp_path+0x7839>
   11b0e:      	cmpq	0x20(%rsp), %rdx
   11b13:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11b19:      	movl	$0x4, %eax
   11b1e:      	leaq	0x10(%rsp), %rdi
   11b23:      	movl	$0x8, %esi
   11b28:      	callq	*%rax
   11b2a:      	cmpq	0x10(%rsp), %r12
   11b2f:      	je	0x11c27 <generic_rawtp_path+0x7947>
   11b35:      	leaq	0x18(%r12), %rbx
   11b3a:      	movl	$0x4, %eax
   11b3f:      	movq	%rbp, %rdi
   11b42:      	movl	$0x8, %esi
   11b47:      	movq	%rbx, %rdx
   11b4a:      	callq	*%rax
   11b4c:      	cmpq	%r12, (%rsp)
   11b50:      	je	0x11c27 <generic_rawtp_path+0x7947>
   11b56:      	movl	$0x4, %eax
   11b5b:      	leaq	0x8(%rsp), %rdi
   11b60:      	movl	$0x8, %esi
   11b65:      	movq	%rbx, %rdx
   11b68:      	callq	*%rax
   11b6a:      	addq	$0x20, %r12
   11b6e:      	movl	$0x4, %eax
   11b73:      	leaq	0x58(%rsp), %rdi
   11b78:      	movl	$0x10, %ecx
   11b7d:      	movl	$0x10, %esi
   11b82:      	movq	%r12, %rdx
   11b85:      	callq	*%rax
   11b87:      	movq	0x28(%rsp), %rbx
   11b8c:      	movq	0x48(%rsp), %rax
   11b91:      	movl	0x5c(%rsp), %r15d
   11b96:      	subq	%rbx, %rax
   11b99:      	movl	0x50(%rsp), %r12d
   11b9e:      	movl	%r15d, %edx
   11ba1:      	subl	%r12d, %edx
   11ba4:      	movl	$0x0, %ecx
   11ba9:      	cmovbl	%ecx, %edx
   11bac:      	addq	0x60(%rsp), %rdx
   11bb1:      	xorl	%esi, %esi
   11bb3:      	cmpl	%r15d, %r12d
   11bb6:      	seta	%sil
   11bba:      	movl	%r15d, %ecx
   11bbd:      	cmovbl	%r12d, %ecx
   11bc1:      	addl	%ecx, %esi
   11bc3:      	movl	%r12d, %edi
   11bc6:      	subl	%esi, %edi
   11bc8:      	movl	%edi, 0x50(%rsp)
   11bcc:      	subq	%rsi, %rax
   11bcf:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   11bd5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11bdb:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   11be1:      	cmpl	%r15d, %r12d
   11be4:      	jbe	0x11bea <generic_rawtp_path+0x790a>
   11be6:      	movb	$0x2f, (%rbx,%rax)
   11bea:      	xorl	%edi, %edi
   11bec:      	cmpl	%r15d, %r12d
   11bef:      	seta	%dil
   11bf3:      	movzbl	%cl, %esi
   11bf6:      	addq	%rax, %rbx
   11bf9:      	addq	%rbx, %rdi
   11bfc:      	movl	$0x4, %eax
   11c01:      	callq	*%rax
   11c03:      	movq	%rbx, 0x48(%rsp)
   11c08:      	cmpl	%r15d, %r12d
   11c0b:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   11c11:      	movq	0x8(%rsp), %r12
   11c16:      	movq	%r12, 0x30(%rsp)
   11c1b:      	movq	0x38(%rsp), %rdx
   11c20:      	movq	0x40(%rsp), %r15
   11c25:      	jmp	0x11c78 <generic_rawtp_path+0x7998>
   11c27:      	leaq	0x10(%r15), %rdx
   11c2b:      	movl	$0x4, %eax
   11c30:      	movq	%rbp, %rdi
   11c33:      	movl	$0x8, %esi
   11c38:      	callq	*%rax
   11c3a:      	movq	0x40(%rsp), %rax
   11c3f:      	cmpq	(%rsp), %rax
   11c43:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11c49:      	addq	$0x18, %r15
   11c4d:      	movl	$0x4, %eax
   11c52:      	leaq	0x30(%rsp), %rdi
   11c57:      	movl	$0x8, %esi
   11c5c:      	movq	%r15, %rdx
   11c5f:      	callq	*%rax
   11c61:      	movq	(%rsp), %r15
   11c65:      	movq	%r15, 0x40(%rsp)
   11c6a:      	leaq	0x20(%r15), %rdx
   11c6e:      	movq	%rdx, 0x38(%rsp)
   11c73:      	movq	0x30(%rsp), %r12
   11c78:      	cmpq	0x18(%rsp), %r12
   11c7d:      	jne	0x11c8a <generic_rawtp_path+0x79aa>
   11c7f:      	cmpq	0x20(%rsp), %rdx
   11c84:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11c8a:      	movl	$0x4, %eax
   11c8f:      	leaq	0x10(%rsp), %rdi
   11c94:      	movl	$0x8, %esi
   11c99:      	callq	*%rax
   11c9b:      	cmpq	0x10(%rsp), %r12
   11ca0:      	je	0x11d98 <generic_rawtp_path+0x7ab8>
   11ca6:      	leaq	0x18(%r12), %rbx
   11cab:      	movl	$0x4, %eax
   11cb0:      	movq	%rbp, %rdi
   11cb3:      	movl	$0x8, %esi
   11cb8:      	movq	%rbx, %rdx
   11cbb:      	callq	*%rax
   11cbd:      	cmpq	%r12, (%rsp)
   11cc1:      	je	0x11d98 <generic_rawtp_path+0x7ab8>
   11cc7:      	movl	$0x4, %eax
   11ccc:      	leaq	0x8(%rsp), %rdi
   11cd1:      	movl	$0x8, %esi
   11cd6:      	movq	%rbx, %rdx
   11cd9:      	callq	*%rax
   11cdb:      	addq	$0x20, %r12
   11cdf:      	movl	$0x4, %eax
   11ce4:      	leaq	0x58(%rsp), %rdi
   11ce9:      	movl	$0x10, %ecx
   11cee:      	movl	$0x10, %esi
   11cf3:      	movq	%r12, %rdx
   11cf6:      	callq	*%rax
   11cf8:      	movq	0x28(%rsp), %rbx
   11cfd:      	movq	0x48(%rsp), %rax
   11d02:      	movl	0x5c(%rsp), %r15d
   11d07:      	subq	%rbx, %rax
   11d0a:      	movl	0x50(%rsp), %r12d
   11d0f:      	movl	%r15d, %edx
   11d12:      	subl	%r12d, %edx
   11d15:      	movl	$0x0, %ecx
   11d1a:      	cmovbl	%ecx, %edx
   11d1d:      	addq	0x60(%rsp), %rdx
   11d22:      	xorl	%esi, %esi
   11d24:      	cmpl	%r15d, %r12d
   11d27:      	seta	%sil
   11d2b:      	movl	%r15d, %ecx
   11d2e:      	cmovbl	%r12d, %ecx
   11d32:      	addl	%ecx, %esi
   11d34:      	movl	%r12d, %edi
   11d37:      	subl	%esi, %edi
   11d39:      	movl	%edi, 0x50(%rsp)
   11d3d:      	subq	%rsi, %rax
   11d40:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   11d46:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11d4c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   11d52:      	cmpl	%r15d, %r12d
   11d55:      	jbe	0x11d5b <generic_rawtp_path+0x7a7b>
   11d57:      	movb	$0x2f, (%rbx,%rax)
   11d5b:      	xorl	%edi, %edi
   11d5d:      	cmpl	%r15d, %r12d
   11d60:      	seta	%dil
   11d64:      	movzbl	%cl, %esi
   11d67:      	addq	%rax, %rbx
   11d6a:      	addq	%rbx, %rdi
   11d6d:      	movl	$0x4, %eax
   11d72:      	callq	*%rax
   11d74:      	movq	%rbx, 0x48(%rsp)
   11d79:      	cmpl	%r15d, %r12d
   11d7c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   11d82:      	movq	0x8(%rsp), %r12
   11d87:      	movq	%r12, 0x30(%rsp)
   11d8c:      	movq	0x38(%rsp), %rdx
   11d91:      	movq	0x40(%rsp), %r15
   11d96:      	jmp	0x11de9 <generic_rawtp_path+0x7b09>
   11d98:      	leaq	0x10(%r15), %rdx
   11d9c:      	movl	$0x4, %eax
   11da1:      	movq	%rbp, %rdi
   11da4:      	movl	$0x8, %esi
   11da9:      	callq	*%rax
   11dab:      	movq	0x40(%rsp), %rax
   11db0:      	cmpq	(%rsp), %rax
   11db4:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11dba:      	addq	$0x18, %r15
   11dbe:      	movl	$0x4, %eax
   11dc3:      	leaq	0x30(%rsp), %rdi
   11dc8:      	movl	$0x8, %esi
   11dcd:      	movq	%r15, %rdx
   11dd0:      	callq	*%rax
   11dd2:      	movq	(%rsp), %r15
   11dd6:      	movq	%r15, 0x40(%rsp)
   11ddb:      	leaq	0x20(%r15), %rdx
   11ddf:      	movq	%rdx, 0x38(%rsp)
   11de4:      	movq	0x30(%rsp), %r12
   11de9:      	cmpq	0x18(%rsp), %r12
   11dee:      	jne	0x11dfb <generic_rawtp_path+0x7b1b>
   11df0:      	cmpq	0x20(%rsp), %rdx
   11df5:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11dfb:      	movl	$0x4, %eax
   11e00:      	leaq	0x10(%rsp), %rdi
   11e05:      	movl	$0x8, %esi
   11e0a:      	callq	*%rax
   11e0c:      	cmpq	0x10(%rsp), %r12
   11e11:      	je	0x11f09 <generic_rawtp_path+0x7c29>
   11e17:      	leaq	0x18(%r12), %rbx
   11e1c:      	movl	$0x4, %eax
   11e21:      	movq	%rbp, %rdi
   11e24:      	movl	$0x8, %esi
   11e29:      	movq	%rbx, %rdx
   11e2c:      	callq	*%rax
   11e2e:      	cmpq	%r12, (%rsp)
   11e32:      	je	0x11f09 <generic_rawtp_path+0x7c29>
   11e38:      	movl	$0x4, %eax
   11e3d:      	leaq	0x8(%rsp), %rdi
   11e42:      	movl	$0x8, %esi
   11e47:      	movq	%rbx, %rdx
   11e4a:      	callq	*%rax
   11e4c:      	addq	$0x20, %r12
   11e50:      	movl	$0x4, %eax
   11e55:      	leaq	0x58(%rsp), %rdi
   11e5a:      	movl	$0x10, %ecx
   11e5f:      	movl	$0x10, %esi
   11e64:      	movq	%r12, %rdx
   11e67:      	callq	*%rax
   11e69:      	movq	0x28(%rsp), %rbx
   11e6e:      	movq	0x48(%rsp), %rax
   11e73:      	movl	0x5c(%rsp), %r15d
   11e78:      	subq	%rbx, %rax
   11e7b:      	movl	0x50(%rsp), %r12d
   11e80:      	movl	%r15d, %edx
   11e83:      	subl	%r12d, %edx
   11e86:      	movl	$0x0, %ecx
   11e8b:      	cmovbl	%ecx, %edx
   11e8e:      	addq	0x60(%rsp), %rdx
   11e93:      	xorl	%esi, %esi
   11e95:      	cmpl	%r15d, %r12d
   11e98:      	seta	%sil
   11e9c:      	movl	%r15d, %ecx
   11e9f:      	cmovbl	%r12d, %ecx
   11ea3:      	addl	%ecx, %esi
   11ea5:      	movl	%r12d, %edi
   11ea8:      	subl	%esi, %edi
   11eaa:      	movl	%edi, 0x50(%rsp)
   11eae:      	subq	%rsi, %rax
   11eb1:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   11eb7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11ebd:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   11ec3:      	cmpl	%r15d, %r12d
   11ec6:      	jbe	0x11ecc <generic_rawtp_path+0x7bec>
   11ec8:      	movb	$0x2f, (%rbx,%rax)
   11ecc:      	xorl	%edi, %edi
   11ece:      	cmpl	%r15d, %r12d
   11ed1:      	seta	%dil
   11ed5:      	movzbl	%cl, %esi
   11ed8:      	addq	%rax, %rbx
   11edb:      	addq	%rbx, %rdi
   11ede:      	movl	$0x4, %eax
   11ee3:      	callq	*%rax
   11ee5:      	movq	%rbx, 0x48(%rsp)
   11eea:      	cmpl	%r15d, %r12d
   11eed:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   11ef3:      	movq	0x8(%rsp), %r12
   11ef8:      	movq	%r12, 0x30(%rsp)
   11efd:      	movq	0x38(%rsp), %rdx
   11f02:      	movq	0x40(%rsp), %r15
   11f07:      	jmp	0x11f5a <generic_rawtp_path+0x7c7a>
   11f09:      	leaq	0x10(%r15), %rdx
   11f0d:      	movl	$0x4, %eax
   11f12:      	movq	%rbp, %rdi
   11f15:      	movl	$0x8, %esi
   11f1a:      	callq	*%rax
   11f1c:      	movq	0x40(%rsp), %rax
   11f21:      	cmpq	(%rsp), %rax
   11f25:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11f2b:      	addq	$0x18, %r15
   11f2f:      	movl	$0x4, %eax
   11f34:      	leaq	0x30(%rsp), %rdi
   11f39:      	movl	$0x8, %esi
   11f3e:      	movq	%r15, %rdx
   11f41:      	callq	*%rax
   11f43:      	movq	(%rsp), %r15
   11f47:      	movq	%r15, 0x40(%rsp)
   11f4c:      	leaq	0x20(%r15), %rdx
   11f50:      	movq	%rdx, 0x38(%rsp)
   11f55:      	movq	0x30(%rsp), %r12
   11f5a:      	cmpq	0x18(%rsp), %r12
   11f5f:      	jne	0x11f6c <generic_rawtp_path+0x7c8c>
   11f61:      	cmpq	0x20(%rsp), %rdx
   11f66:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   11f6c:      	movl	$0x4, %eax
   11f71:      	leaq	0x10(%rsp), %rdi
   11f76:      	movl	$0x8, %esi
   11f7b:      	callq	*%rax
   11f7d:      	cmpq	0x10(%rsp), %r12
   11f82:      	je	0x1207a <generic_rawtp_path+0x7d9a>
   11f88:      	leaq	0x18(%r12), %rbx
   11f8d:      	movl	$0x4, %eax
   11f92:      	movq	%rbp, %rdi
   11f95:      	movl	$0x8, %esi
   11f9a:      	movq	%rbx, %rdx
   11f9d:      	callq	*%rax
   11f9f:      	cmpq	%r12, (%rsp)
   11fa3:      	je	0x1207a <generic_rawtp_path+0x7d9a>
   11fa9:      	movl	$0x4, %eax
   11fae:      	leaq	0x8(%rsp), %rdi
   11fb3:      	movl	$0x8, %esi
   11fb8:      	movq	%rbx, %rdx
   11fbb:      	callq	*%rax
   11fbd:      	addq	$0x20, %r12
   11fc1:      	movl	$0x4, %eax
   11fc6:      	leaq	0x58(%rsp), %rdi
   11fcb:      	movl	$0x10, %ecx
   11fd0:      	movl	$0x10, %esi
   11fd5:      	movq	%r12, %rdx
   11fd8:      	callq	*%rax
   11fda:      	movq	0x28(%rsp), %rbx
   11fdf:      	movq	0x48(%rsp), %rax
   11fe4:      	movl	0x5c(%rsp), %r15d
   11fe9:      	subq	%rbx, %rax
   11fec:      	movl	0x50(%rsp), %r12d
   11ff1:      	movl	%r15d, %edx
   11ff4:      	subl	%r12d, %edx
   11ff7:      	movl	$0x0, %ecx
   11ffc:      	cmovbl	%ecx, %edx
   11fff:      	addq	0x60(%rsp), %rdx
   12004:      	xorl	%esi, %esi
   12006:      	cmpl	%r15d, %r12d
   12009:      	seta	%sil
   1200d:      	movl	%r15d, %ecx
   12010:      	cmovbl	%r12d, %ecx
   12014:      	addl	%ecx, %esi
   12016:      	movl	%r12d, %edi
   12019:      	subl	%esi, %edi
   1201b:      	movl	%edi, 0x50(%rsp)
   1201f:      	subq	%rsi, %rax
   12022:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   12028:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1202e:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12034:      	cmpl	%r15d, %r12d
   12037:      	jbe	0x1203d <generic_rawtp_path+0x7d5d>
   12039:      	movb	$0x2f, (%rbx,%rax)
   1203d:      	xorl	%edi, %edi
   1203f:      	cmpl	%r15d, %r12d
   12042:      	seta	%dil
   12046:      	movzbl	%cl, %esi
   12049:      	addq	%rax, %rbx
   1204c:      	addq	%rbx, %rdi
   1204f:      	movl	$0x4, %eax
   12054:      	callq	*%rax
   12056:      	movq	%rbx, 0x48(%rsp)
   1205b:      	cmpl	%r15d, %r12d
   1205e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12064:      	movq	0x8(%rsp), %r12
   12069:      	movq	%r12, 0x30(%rsp)
   1206e:      	movq	0x38(%rsp), %rdx
   12073:      	movq	0x40(%rsp), %r15
   12078:      	jmp	0x120cb <generic_rawtp_path+0x7deb>
   1207a:      	leaq	0x10(%r15), %rdx
   1207e:      	movl	$0x4, %eax
   12083:      	movq	%rbp, %rdi
   12086:      	movl	$0x8, %esi
   1208b:      	callq	*%rax
   1208d:      	movq	0x40(%rsp), %rax
   12092:      	cmpq	(%rsp), %rax
   12096:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1209c:      	addq	$0x18, %r15
   120a0:      	movl	$0x4, %eax
   120a5:      	leaq	0x30(%rsp), %rdi
   120aa:      	movl	$0x8, %esi
   120af:      	movq	%r15, %rdx
   120b2:      	callq	*%rax
   120b4:      	movq	(%rsp), %r15
   120b8:      	movq	%r15, 0x40(%rsp)
   120bd:      	leaq	0x20(%r15), %rdx
   120c1:      	movq	%rdx, 0x38(%rsp)
   120c6:      	movq	0x30(%rsp), %r12
   120cb:      	cmpq	0x18(%rsp), %r12
   120d0:      	jne	0x120dd <generic_rawtp_path+0x7dfd>
   120d2:      	cmpq	0x20(%rsp), %rdx
   120d7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   120dd:      	movl	$0x4, %eax
   120e2:      	leaq	0x10(%rsp), %rdi
   120e7:      	movl	$0x8, %esi
   120ec:      	callq	*%rax
   120ee:      	cmpq	0x10(%rsp), %r12
   120f3:      	je	0x121eb <generic_rawtp_path+0x7f0b>
   120f9:      	leaq	0x18(%r12), %rbx
   120fe:      	movl	$0x4, %eax
   12103:      	movq	%rbp, %rdi
   12106:      	movl	$0x8, %esi
   1210b:      	movq	%rbx, %rdx
   1210e:      	callq	*%rax
   12110:      	cmpq	%r12, (%rsp)
   12114:      	je	0x121eb <generic_rawtp_path+0x7f0b>
   1211a:      	movl	$0x4, %eax
   1211f:      	leaq	0x8(%rsp), %rdi
   12124:      	movl	$0x8, %esi
   12129:      	movq	%rbx, %rdx
   1212c:      	callq	*%rax
   1212e:      	addq	$0x20, %r12
   12132:      	movl	$0x4, %eax
   12137:      	leaq	0x58(%rsp), %rdi
   1213c:      	movl	$0x10, %ecx
   12141:      	movl	$0x10, %esi
   12146:      	movq	%r12, %rdx
   12149:      	callq	*%rax
   1214b:      	movq	0x28(%rsp), %rbx
   12150:      	movq	0x48(%rsp), %rax
   12155:      	movl	0x5c(%rsp), %r15d
   1215a:      	subq	%rbx, %rax
   1215d:      	movl	0x50(%rsp), %r12d
   12162:      	movl	%r15d, %edx
   12165:      	subl	%r12d, %edx
   12168:      	movl	$0x0, %ecx
   1216d:      	cmovbl	%ecx, %edx
   12170:      	addq	0x60(%rsp), %rdx
   12175:      	xorl	%esi, %esi
   12177:      	cmpl	%r15d, %r12d
   1217a:      	seta	%sil
   1217e:      	movl	%r15d, %ecx
   12181:      	cmovbl	%r12d, %ecx
   12185:      	addl	%ecx, %esi
   12187:      	movl	%r12d, %edi
   1218a:      	subl	%esi, %edi
   1218c:      	movl	%edi, 0x50(%rsp)
   12190:      	subq	%rsi, %rax
   12193:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   12199:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1219f:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   121a5:      	cmpl	%r15d, %r12d
   121a8:      	jbe	0x121ae <generic_rawtp_path+0x7ece>
   121aa:      	movb	$0x2f, (%rbx,%rax)
   121ae:      	xorl	%edi, %edi
   121b0:      	cmpl	%r15d, %r12d
   121b3:      	seta	%dil
   121b7:      	movzbl	%cl, %esi
   121ba:      	addq	%rax, %rbx
   121bd:      	addq	%rbx, %rdi
   121c0:      	movl	$0x4, %eax
   121c5:      	callq	*%rax
   121c7:      	movq	%rbx, 0x48(%rsp)
   121cc:      	cmpl	%r15d, %r12d
   121cf:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   121d5:      	movq	0x8(%rsp), %r12
   121da:      	movq	%r12, 0x30(%rsp)
   121df:      	movq	0x38(%rsp), %rdx
   121e4:      	movq	0x40(%rsp), %r15
   121e9:      	jmp	0x1223c <generic_rawtp_path+0x7f5c>
   121eb:      	leaq	0x10(%r15), %rdx
   121ef:      	movl	$0x4, %eax
   121f4:      	movq	%rbp, %rdi
   121f7:      	movl	$0x8, %esi
   121fc:      	callq	*%rax
   121fe:      	movq	0x40(%rsp), %rax
   12203:      	cmpq	(%rsp), %rax
   12207:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1220d:      	addq	$0x18, %r15
   12211:      	movl	$0x4, %eax
   12216:      	leaq	0x30(%rsp), %rdi
   1221b:      	movl	$0x8, %esi
   12220:      	movq	%r15, %rdx
   12223:      	callq	*%rax
   12225:      	movq	(%rsp), %r15
   12229:      	movq	%r15, 0x40(%rsp)
   1222e:      	leaq	0x20(%r15), %rdx
   12232:      	movq	%rdx, 0x38(%rsp)
   12237:      	movq	0x30(%rsp), %r12
   1223c:      	cmpq	0x18(%rsp), %r12
   12241:      	jne	0x1224e <generic_rawtp_path+0x7f6e>
   12243:      	cmpq	0x20(%rsp), %rdx
   12248:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1224e:      	movl	$0x4, %eax
   12253:      	leaq	0x10(%rsp), %rdi
   12258:      	movl	$0x8, %esi
   1225d:      	callq	*%rax
   1225f:      	cmpq	0x10(%rsp), %r12
   12264:      	je	0x1235c <generic_rawtp_path+0x807c>
   1226a:      	leaq	0x18(%r12), %rbx
   1226f:      	movl	$0x4, %eax
   12274:      	movq	%rbp, %rdi
   12277:      	movl	$0x8, %esi
   1227c:      	movq	%rbx, %rdx
   1227f:      	callq	*%rax
   12281:      	cmpq	%r12, (%rsp)
   12285:      	je	0x1235c <generic_rawtp_path+0x807c>
   1228b:      	movl	$0x4, %eax
   12290:      	leaq	0x8(%rsp), %rdi
   12295:      	movl	$0x8, %esi
   1229a:      	movq	%rbx, %rdx
   1229d:      	callq	*%rax
   1229f:      	addq	$0x20, %r12
   122a3:      	movl	$0x4, %eax
   122a8:      	leaq	0x58(%rsp), %rdi
   122ad:      	movl	$0x10, %ecx
   122b2:      	movl	$0x10, %esi
   122b7:      	movq	%r12, %rdx
   122ba:      	callq	*%rax
   122bc:      	movq	0x28(%rsp), %rbx
   122c1:      	movq	0x48(%rsp), %rax
   122c6:      	movl	0x5c(%rsp), %r15d
   122cb:      	subq	%rbx, %rax
   122ce:      	movl	0x50(%rsp), %r12d
   122d3:      	movl	%r15d, %edx
   122d6:      	subl	%r12d, %edx
   122d9:      	movl	$0x0, %ecx
   122de:      	cmovbl	%ecx, %edx
   122e1:      	addq	0x60(%rsp), %rdx
   122e6:      	xorl	%esi, %esi
   122e8:      	cmpl	%r15d, %r12d
   122eb:      	seta	%sil
   122ef:      	movl	%r15d, %ecx
   122f2:      	cmovbl	%r12d, %ecx
   122f6:      	addl	%ecx, %esi
   122f8:      	movl	%r12d, %edi
   122fb:      	subl	%esi, %edi
   122fd:      	movl	%edi, 0x50(%rsp)
   12301:      	subq	%rsi, %rax
   12304:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1230a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12310:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12316:      	cmpl	%r15d, %r12d
   12319:      	jbe	0x1231f <generic_rawtp_path+0x803f>
   1231b:      	movb	$0x2f, (%rbx,%rax)
   1231f:      	xorl	%edi, %edi
   12321:      	cmpl	%r15d, %r12d
   12324:      	seta	%dil
   12328:      	movzbl	%cl, %esi
   1232b:      	addq	%rax, %rbx
   1232e:      	addq	%rbx, %rdi
   12331:      	movl	$0x4, %eax
   12336:      	callq	*%rax
   12338:      	movq	%rbx, 0x48(%rsp)
   1233d:      	cmpl	%r15d, %r12d
   12340:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12346:      	movq	0x8(%rsp), %r12
   1234b:      	movq	%r12, 0x30(%rsp)
   12350:      	movq	0x38(%rsp), %rdx
   12355:      	movq	0x40(%rsp), %r15
   1235a:      	jmp	0x123ad <generic_rawtp_path+0x80cd>
   1235c:      	leaq	0x10(%r15), %rdx
   12360:      	movl	$0x4, %eax
   12365:      	movq	%rbp, %rdi
   12368:      	movl	$0x8, %esi
   1236d:      	callq	*%rax
   1236f:      	movq	0x40(%rsp), %rax
   12374:      	cmpq	(%rsp), %rax
   12378:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1237e:      	addq	$0x18, %r15
   12382:      	movl	$0x4, %eax
   12387:      	leaq	0x30(%rsp), %rdi
   1238c:      	movl	$0x8, %esi
   12391:      	movq	%r15, %rdx
   12394:      	callq	*%rax
   12396:      	movq	(%rsp), %r15
   1239a:      	movq	%r15, 0x40(%rsp)
   1239f:      	leaq	0x20(%r15), %rdx
   123a3:      	movq	%rdx, 0x38(%rsp)
   123a8:      	movq	0x30(%rsp), %r12
   123ad:      	cmpq	0x18(%rsp), %r12
   123b2:      	jne	0x123bf <generic_rawtp_path+0x80df>
   123b4:      	cmpq	0x20(%rsp), %rdx
   123b9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   123bf:      	movl	$0x4, %eax
   123c4:      	leaq	0x10(%rsp), %rdi
   123c9:      	movl	$0x8, %esi
   123ce:      	callq	*%rax
   123d0:      	cmpq	0x10(%rsp), %r12
   123d5:      	je	0x124cd <generic_rawtp_path+0x81ed>
   123db:      	leaq	0x18(%r12), %rbx
   123e0:      	movl	$0x4, %eax
   123e5:      	movq	%rbp, %rdi
   123e8:      	movl	$0x8, %esi
   123ed:      	movq	%rbx, %rdx
   123f0:      	callq	*%rax
   123f2:      	cmpq	%r12, (%rsp)
   123f6:      	je	0x124cd <generic_rawtp_path+0x81ed>
   123fc:      	movl	$0x4, %eax
   12401:      	leaq	0x8(%rsp), %rdi
   12406:      	movl	$0x8, %esi
   1240b:      	movq	%rbx, %rdx
   1240e:      	callq	*%rax
   12410:      	addq	$0x20, %r12
   12414:      	movl	$0x4, %eax
   12419:      	leaq	0x58(%rsp), %rdi
   1241e:      	movl	$0x10, %ecx
   12423:      	movl	$0x10, %esi
   12428:      	movq	%r12, %rdx
   1242b:      	callq	*%rax
   1242d:      	movq	0x28(%rsp), %rbx
   12432:      	movq	0x48(%rsp), %rax
   12437:      	movl	0x5c(%rsp), %r15d
   1243c:      	subq	%rbx, %rax
   1243f:      	movl	0x50(%rsp), %r12d
   12444:      	movl	%r15d, %edx
   12447:      	subl	%r12d, %edx
   1244a:      	movl	$0x0, %ecx
   1244f:      	cmovbl	%ecx, %edx
   12452:      	addq	0x60(%rsp), %rdx
   12457:      	xorl	%esi, %esi
   12459:      	cmpl	%r15d, %r12d
   1245c:      	seta	%sil
   12460:      	movl	%r15d, %ecx
   12463:      	cmovbl	%r12d, %ecx
   12467:      	addl	%ecx, %esi
   12469:      	movl	%r12d, %edi
   1246c:      	subl	%esi, %edi
   1246e:      	movl	%edi, 0x50(%rsp)
   12472:      	subq	%rsi, %rax
   12475:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1247b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12481:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12487:      	cmpl	%r15d, %r12d
   1248a:      	jbe	0x12490 <generic_rawtp_path+0x81b0>
   1248c:      	movb	$0x2f, (%rbx,%rax)
   12490:      	xorl	%edi, %edi
   12492:      	cmpl	%r15d, %r12d
   12495:      	seta	%dil
   12499:      	movzbl	%cl, %esi
   1249c:      	addq	%rax, %rbx
   1249f:      	addq	%rbx, %rdi
   124a2:      	movl	$0x4, %eax
   124a7:      	callq	*%rax
   124a9:      	movq	%rbx, 0x48(%rsp)
   124ae:      	cmpl	%r15d, %r12d
   124b1:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   124b7:      	movq	0x8(%rsp), %r12
   124bc:      	movq	%r12, 0x30(%rsp)
   124c1:      	movq	0x38(%rsp), %rdx
   124c6:      	movq	0x40(%rsp), %r15
   124cb:      	jmp	0x1251e <generic_rawtp_path+0x823e>
   124cd:      	leaq	0x10(%r15), %rdx
   124d1:      	movl	$0x4, %eax
   124d6:      	movq	%rbp, %rdi
   124d9:      	movl	$0x8, %esi
   124de:      	callq	*%rax
   124e0:      	movq	0x40(%rsp), %rax
   124e5:      	cmpq	(%rsp), %rax
   124e9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   124ef:      	addq	$0x18, %r15
   124f3:      	movl	$0x4, %eax
   124f8:      	leaq	0x30(%rsp), %rdi
   124fd:      	movl	$0x8, %esi
   12502:      	movq	%r15, %rdx
   12505:      	callq	*%rax
   12507:      	movq	(%rsp), %r15
   1250b:      	movq	%r15, 0x40(%rsp)
   12510:      	leaq	0x20(%r15), %rdx
   12514:      	movq	%rdx, 0x38(%rsp)
   12519:      	movq	0x30(%rsp), %r12
   1251e:      	cmpq	0x18(%rsp), %r12
   12523:      	jne	0x12530 <generic_rawtp_path+0x8250>
   12525:      	cmpq	0x20(%rsp), %rdx
   1252a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12530:      	movl	$0x4, %eax
   12535:      	leaq	0x10(%rsp), %rdi
   1253a:      	movl	$0x8, %esi
   1253f:      	callq	*%rax
   12541:      	cmpq	0x10(%rsp), %r12
   12546:      	je	0x1263e <generic_rawtp_path+0x835e>
   1254c:      	leaq	0x18(%r12), %rbx
   12551:      	movl	$0x4, %eax
   12556:      	movq	%rbp, %rdi
   12559:      	movl	$0x8, %esi
   1255e:      	movq	%rbx, %rdx
   12561:      	callq	*%rax
   12563:      	cmpq	%r12, (%rsp)
   12567:      	je	0x1263e <generic_rawtp_path+0x835e>
   1256d:      	movl	$0x4, %eax
   12572:      	leaq	0x8(%rsp), %rdi
   12577:      	movl	$0x8, %esi
   1257c:      	movq	%rbx, %rdx
   1257f:      	callq	*%rax
   12581:      	addq	$0x20, %r12
   12585:      	movl	$0x4, %eax
   1258a:      	leaq	0x58(%rsp), %rdi
   1258f:      	movl	$0x10, %ecx
   12594:      	movl	$0x10, %esi
   12599:      	movq	%r12, %rdx
   1259c:      	callq	*%rax
   1259e:      	movq	0x28(%rsp), %rbx
   125a3:      	movq	0x48(%rsp), %rax
   125a8:      	movl	0x5c(%rsp), %r15d
   125ad:      	subq	%rbx, %rax
   125b0:      	movl	0x50(%rsp), %r12d
   125b5:      	movl	%r15d, %edx
   125b8:      	subl	%r12d, %edx
   125bb:      	movl	$0x0, %ecx
   125c0:      	cmovbl	%ecx, %edx
   125c3:      	addq	0x60(%rsp), %rdx
   125c8:      	xorl	%esi, %esi
   125ca:      	cmpl	%r15d, %r12d
   125cd:      	seta	%sil
   125d1:      	movl	%r15d, %ecx
   125d4:      	cmovbl	%r12d, %ecx
   125d8:      	addl	%ecx, %esi
   125da:      	movl	%r12d, %edi
   125dd:      	subl	%esi, %edi
   125df:      	movl	%edi, 0x50(%rsp)
   125e3:      	subq	%rsi, %rax
   125e6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   125ec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   125f2:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   125f8:      	cmpl	%r15d, %r12d
   125fb:      	jbe	0x12601 <generic_rawtp_path+0x8321>
   125fd:      	movb	$0x2f, (%rbx,%rax)
   12601:      	xorl	%edi, %edi
   12603:      	cmpl	%r15d, %r12d
   12606:      	seta	%dil
   1260a:      	movzbl	%cl, %esi
   1260d:      	addq	%rax, %rbx
   12610:      	addq	%rbx, %rdi
   12613:      	movl	$0x4, %eax
   12618:      	callq	*%rax
   1261a:      	movq	%rbx, 0x48(%rsp)
   1261f:      	cmpl	%r15d, %r12d
   12622:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12628:      	movq	0x8(%rsp), %r12
   1262d:      	movq	%r12, 0x30(%rsp)
   12632:      	movq	0x38(%rsp), %rdx
   12637:      	movq	0x40(%rsp), %r15
   1263c:      	jmp	0x1268f <generic_rawtp_path+0x83af>
   1263e:      	leaq	0x10(%r15), %rdx
   12642:      	movl	$0x4, %eax
   12647:      	movq	%rbp, %rdi
   1264a:      	movl	$0x8, %esi
   1264f:      	callq	*%rax
   12651:      	movq	0x40(%rsp), %rax
   12656:      	cmpq	(%rsp), %rax
   1265a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12660:      	addq	$0x18, %r15
   12664:      	movl	$0x4, %eax
   12669:      	leaq	0x30(%rsp), %rdi
   1266e:      	movl	$0x8, %esi
   12673:      	movq	%r15, %rdx
   12676:      	callq	*%rax
   12678:      	movq	(%rsp), %r15
   1267c:      	movq	%r15, 0x40(%rsp)
   12681:      	leaq	0x20(%r15), %rdx
   12685:      	movq	%rdx, 0x38(%rsp)
   1268a:      	movq	0x30(%rsp), %r12
   1268f:      	cmpq	0x18(%rsp), %r12
   12694:      	jne	0x126a1 <generic_rawtp_path+0x83c1>
   12696:      	cmpq	0x20(%rsp), %rdx
   1269b:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   126a1:      	movl	$0x4, %eax
   126a6:      	leaq	0x10(%rsp), %rdi
   126ab:      	movl	$0x8, %esi
   126b0:      	callq	*%rax
   126b2:      	cmpq	0x10(%rsp), %r12
   126b7:      	je	0x127af <generic_rawtp_path+0x84cf>
   126bd:      	leaq	0x18(%r12), %rbx
   126c2:      	movl	$0x4, %eax
   126c7:      	movq	%rbp, %rdi
   126ca:      	movl	$0x8, %esi
   126cf:      	movq	%rbx, %rdx
   126d2:      	callq	*%rax
   126d4:      	cmpq	%r12, (%rsp)
   126d8:      	je	0x127af <generic_rawtp_path+0x84cf>
   126de:      	movl	$0x4, %eax
   126e3:      	leaq	0x8(%rsp), %rdi
   126e8:      	movl	$0x8, %esi
   126ed:      	movq	%rbx, %rdx
   126f0:      	callq	*%rax
   126f2:      	addq	$0x20, %r12
   126f6:      	movl	$0x4, %eax
   126fb:      	leaq	0x58(%rsp), %rdi
   12700:      	movl	$0x10, %ecx
   12705:      	movl	$0x10, %esi
   1270a:      	movq	%r12, %rdx
   1270d:      	callq	*%rax
   1270f:      	movq	0x28(%rsp), %rbx
   12714:      	movq	0x48(%rsp), %rax
   12719:      	movl	0x5c(%rsp), %r15d
   1271e:      	subq	%rbx, %rax
   12721:      	movl	0x50(%rsp), %r12d
   12726:      	movl	%r15d, %edx
   12729:      	subl	%r12d, %edx
   1272c:      	movl	$0x0, %ecx
   12731:      	cmovbl	%ecx, %edx
   12734:      	addq	0x60(%rsp), %rdx
   12739:      	xorl	%esi, %esi
   1273b:      	cmpl	%r15d, %r12d
   1273e:      	seta	%sil
   12742:      	movl	%r15d, %ecx
   12745:      	cmovbl	%r12d, %ecx
   12749:      	addl	%ecx, %esi
   1274b:      	movl	%r12d, %edi
   1274e:      	subl	%esi, %edi
   12750:      	movl	%edi, 0x50(%rsp)
   12754:      	subq	%rsi, %rax
   12757:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1275d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12763:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12769:      	cmpl	%r15d, %r12d
   1276c:      	jbe	0x12772 <generic_rawtp_path+0x8492>
   1276e:      	movb	$0x2f, (%rbx,%rax)
   12772:      	xorl	%edi, %edi
   12774:      	cmpl	%r15d, %r12d
   12777:      	seta	%dil
   1277b:      	movzbl	%cl, %esi
   1277e:      	addq	%rax, %rbx
   12781:      	addq	%rbx, %rdi
   12784:      	movl	$0x4, %eax
   12789:      	callq	*%rax
   1278b:      	movq	%rbx, 0x48(%rsp)
   12790:      	cmpl	%r15d, %r12d
   12793:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12799:      	movq	0x8(%rsp), %r12
   1279e:      	movq	%r12, 0x30(%rsp)
   127a3:      	movq	0x38(%rsp), %rdx
   127a8:      	movq	0x40(%rsp), %r15
   127ad:      	jmp	0x12800 <generic_rawtp_path+0x8520>
   127af:      	leaq	0x10(%r15), %rdx
   127b3:      	movl	$0x4, %eax
   127b8:      	movq	%rbp, %rdi
   127bb:      	movl	$0x8, %esi
   127c0:      	callq	*%rax
   127c2:      	movq	0x40(%rsp), %rax
   127c7:      	cmpq	(%rsp), %rax
   127cb:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   127d1:      	addq	$0x18, %r15
   127d5:      	movl	$0x4, %eax
   127da:      	leaq	0x30(%rsp), %rdi
   127df:      	movl	$0x8, %esi
   127e4:      	movq	%r15, %rdx
   127e7:      	callq	*%rax
   127e9:      	movq	(%rsp), %r15
   127ed:      	movq	%r15, 0x40(%rsp)
   127f2:      	leaq	0x20(%r15), %rdx
   127f6:      	movq	%rdx, 0x38(%rsp)
   127fb:      	movq	0x30(%rsp), %r12
   12800:      	cmpq	0x18(%rsp), %r12
   12805:      	jne	0x12812 <generic_rawtp_path+0x8532>
   12807:      	cmpq	0x20(%rsp), %rdx
   1280c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12812:      	movl	$0x4, %eax
   12817:      	leaq	0x10(%rsp), %rdi
   1281c:      	movl	$0x8, %esi
   12821:      	callq	*%rax
   12823:      	cmpq	0x10(%rsp), %r12
   12828:      	je	0x12920 <generic_rawtp_path+0x8640>
   1282e:      	leaq	0x18(%r12), %rbx
   12833:      	movl	$0x4, %eax
   12838:      	movq	%rbp, %rdi
   1283b:      	movl	$0x8, %esi
   12840:      	movq	%rbx, %rdx
   12843:      	callq	*%rax
   12845:      	cmpq	%r12, (%rsp)
   12849:      	je	0x12920 <generic_rawtp_path+0x8640>
   1284f:      	movl	$0x4, %eax
   12854:      	leaq	0x8(%rsp), %rdi
   12859:      	movl	$0x8, %esi
   1285e:      	movq	%rbx, %rdx
   12861:      	callq	*%rax
   12863:      	addq	$0x20, %r12
   12867:      	movl	$0x4, %eax
   1286c:      	leaq	0x58(%rsp), %rdi
   12871:      	movl	$0x10, %ecx
   12876:      	movl	$0x10, %esi
   1287b:      	movq	%r12, %rdx
   1287e:      	callq	*%rax
   12880:      	movq	0x28(%rsp), %rbx
   12885:      	movq	0x48(%rsp), %rax
   1288a:      	movl	0x5c(%rsp), %r15d
   1288f:      	subq	%rbx, %rax
   12892:      	movl	0x50(%rsp), %r12d
   12897:      	movl	%r15d, %edx
   1289a:      	subl	%r12d, %edx
   1289d:      	movl	$0x0, %ecx
   128a2:      	cmovbl	%ecx, %edx
   128a5:      	addq	0x60(%rsp), %rdx
   128aa:      	xorl	%esi, %esi
   128ac:      	cmpl	%r15d, %r12d
   128af:      	seta	%sil
   128b3:      	movl	%r15d, %ecx
   128b6:      	cmovbl	%r12d, %ecx
   128ba:      	addl	%ecx, %esi
   128bc:      	movl	%r12d, %edi
   128bf:      	subl	%esi, %edi
   128c1:      	movl	%edi, 0x50(%rsp)
   128c5:      	subq	%rsi, %rax
   128c8:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   128ce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   128d4:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   128da:      	cmpl	%r15d, %r12d
   128dd:      	jbe	0x128e3 <generic_rawtp_path+0x8603>
   128df:      	movb	$0x2f, (%rbx,%rax)
   128e3:      	xorl	%edi, %edi
   128e5:      	cmpl	%r15d, %r12d
   128e8:      	seta	%dil
   128ec:      	movzbl	%cl, %esi
   128ef:      	addq	%rax, %rbx
   128f2:      	addq	%rbx, %rdi
   128f5:      	movl	$0x4, %eax
   128fa:      	callq	*%rax
   128fc:      	movq	%rbx, 0x48(%rsp)
   12901:      	cmpl	%r15d, %r12d
   12904:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1290a:      	movq	0x8(%rsp), %r12
   1290f:      	movq	%r12, 0x30(%rsp)
   12914:      	movq	0x38(%rsp), %rdx
   12919:      	movq	0x40(%rsp), %r15
   1291e:      	jmp	0x12971 <generic_rawtp_path+0x8691>
   12920:      	leaq	0x10(%r15), %rdx
   12924:      	movl	$0x4, %eax
   12929:      	movq	%rbp, %rdi
   1292c:      	movl	$0x8, %esi
   12931:      	callq	*%rax
   12933:      	movq	0x40(%rsp), %rax
   12938:      	cmpq	(%rsp), %rax
   1293c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12942:      	addq	$0x18, %r15
   12946:      	movl	$0x4, %eax
   1294b:      	leaq	0x30(%rsp), %rdi
   12950:      	movl	$0x8, %esi
   12955:      	movq	%r15, %rdx
   12958:      	callq	*%rax
   1295a:      	movq	(%rsp), %r15
   1295e:      	movq	%r15, 0x40(%rsp)
   12963:      	leaq	0x20(%r15), %rdx
   12967:      	movq	%rdx, 0x38(%rsp)
   1296c:      	movq	0x30(%rsp), %r12
   12971:      	cmpq	0x18(%rsp), %r12
   12976:      	jne	0x12983 <generic_rawtp_path+0x86a3>
   12978:      	cmpq	0x20(%rsp), %rdx
   1297d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12983:      	movl	$0x4, %eax
   12988:      	leaq	0x10(%rsp), %rdi
   1298d:      	movl	$0x8, %esi
   12992:      	callq	*%rax
   12994:      	cmpq	0x10(%rsp), %r12
   12999:      	je	0x12a91 <generic_rawtp_path+0x87b1>
   1299f:      	leaq	0x18(%r12), %rbx
   129a4:      	movl	$0x4, %eax
   129a9:      	movq	%rbp, %rdi
   129ac:      	movl	$0x8, %esi
   129b1:      	movq	%rbx, %rdx
   129b4:      	callq	*%rax
   129b6:      	cmpq	%r12, (%rsp)
   129ba:      	je	0x12a91 <generic_rawtp_path+0x87b1>
   129c0:      	movl	$0x4, %eax
   129c5:      	leaq	0x8(%rsp), %rdi
   129ca:      	movl	$0x8, %esi
   129cf:      	movq	%rbx, %rdx
   129d2:      	callq	*%rax
   129d4:      	addq	$0x20, %r12
   129d8:      	movl	$0x4, %eax
   129dd:      	leaq	0x58(%rsp), %rdi
   129e2:      	movl	$0x10, %ecx
   129e7:      	movl	$0x10, %esi
   129ec:      	movq	%r12, %rdx
   129ef:      	callq	*%rax
   129f1:      	movq	0x28(%rsp), %rbx
   129f6:      	movq	0x48(%rsp), %rax
   129fb:      	movl	0x5c(%rsp), %r15d
   12a00:      	subq	%rbx, %rax
   12a03:      	movl	0x50(%rsp), %r12d
   12a08:      	movl	%r15d, %edx
   12a0b:      	subl	%r12d, %edx
   12a0e:      	movl	$0x0, %ecx
   12a13:      	cmovbl	%ecx, %edx
   12a16:      	addq	0x60(%rsp), %rdx
   12a1b:      	xorl	%esi, %esi
   12a1d:      	cmpl	%r15d, %r12d
   12a20:      	seta	%sil
   12a24:      	movl	%r15d, %ecx
   12a27:      	cmovbl	%r12d, %ecx
   12a2b:      	addl	%ecx, %esi
   12a2d:      	movl	%r12d, %edi
   12a30:      	subl	%esi, %edi
   12a32:      	movl	%edi, 0x50(%rsp)
   12a36:      	subq	%rsi, %rax
   12a39:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   12a3f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12a45:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12a4b:      	cmpl	%r15d, %r12d
   12a4e:      	jbe	0x12a54 <generic_rawtp_path+0x8774>
   12a50:      	movb	$0x2f, (%rbx,%rax)
   12a54:      	xorl	%edi, %edi
   12a56:      	cmpl	%r15d, %r12d
   12a59:      	seta	%dil
   12a5d:      	movzbl	%cl, %esi
   12a60:      	addq	%rax, %rbx
   12a63:      	addq	%rbx, %rdi
   12a66:      	movl	$0x4, %eax
   12a6b:      	callq	*%rax
   12a6d:      	movq	%rbx, 0x48(%rsp)
   12a72:      	cmpl	%r15d, %r12d
   12a75:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12a7b:      	movq	0x8(%rsp), %r12
   12a80:      	movq	%r12, 0x30(%rsp)
   12a85:      	movq	0x38(%rsp), %rdx
   12a8a:      	movq	0x40(%rsp), %r15
   12a8f:      	jmp	0x12ae2 <generic_rawtp_path+0x8802>
   12a91:      	leaq	0x10(%r15), %rdx
   12a95:      	movl	$0x4, %eax
   12a9a:      	movq	%rbp, %rdi
   12a9d:      	movl	$0x8, %esi
   12aa2:      	callq	*%rax
   12aa4:      	movq	0x40(%rsp), %rax
   12aa9:      	cmpq	(%rsp), %rax
   12aad:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12ab3:      	addq	$0x18, %r15
   12ab7:      	movl	$0x4, %eax
   12abc:      	leaq	0x30(%rsp), %rdi
   12ac1:      	movl	$0x8, %esi
   12ac6:      	movq	%r15, %rdx
   12ac9:      	callq	*%rax
   12acb:      	movq	(%rsp), %r15
   12acf:      	movq	%r15, 0x40(%rsp)
   12ad4:      	leaq	0x20(%r15), %rdx
   12ad8:      	movq	%rdx, 0x38(%rsp)
   12add:      	movq	0x30(%rsp), %r12
   12ae2:      	cmpq	0x18(%rsp), %r12
   12ae7:      	jne	0x12af4 <generic_rawtp_path+0x8814>
   12ae9:      	cmpq	0x20(%rsp), %rdx
   12aee:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12af4:      	movl	$0x4, %eax
   12af9:      	leaq	0x10(%rsp), %rdi
   12afe:      	movl	$0x8, %esi
   12b03:      	callq	*%rax
   12b05:      	cmpq	0x10(%rsp), %r12
   12b0a:      	je	0x12c02 <generic_rawtp_path+0x8922>
   12b10:      	leaq	0x18(%r12), %rbx
   12b15:      	movl	$0x4, %eax
   12b1a:      	movq	%rbp, %rdi
   12b1d:      	movl	$0x8, %esi
   12b22:      	movq	%rbx, %rdx
   12b25:      	callq	*%rax
   12b27:      	cmpq	%r12, (%rsp)
   12b2b:      	je	0x12c02 <generic_rawtp_path+0x8922>
   12b31:      	movl	$0x4, %eax
   12b36:      	leaq	0x8(%rsp), %rdi
   12b3b:      	movl	$0x8, %esi
   12b40:      	movq	%rbx, %rdx
   12b43:      	callq	*%rax
   12b45:      	addq	$0x20, %r12
   12b49:      	movl	$0x4, %eax
   12b4e:      	leaq	0x58(%rsp), %rdi
   12b53:      	movl	$0x10, %ecx
   12b58:      	movl	$0x10, %esi
   12b5d:      	movq	%r12, %rdx
   12b60:      	callq	*%rax
   12b62:      	movq	0x28(%rsp), %rbx
   12b67:      	movq	0x48(%rsp), %rax
   12b6c:      	movl	0x5c(%rsp), %r15d
   12b71:      	subq	%rbx, %rax
   12b74:      	movl	0x50(%rsp), %r12d
   12b79:      	movl	%r15d, %edx
   12b7c:      	subl	%r12d, %edx
   12b7f:      	movl	$0x0, %ecx
   12b84:      	cmovbl	%ecx, %edx
   12b87:      	addq	0x60(%rsp), %rdx
   12b8c:      	xorl	%esi, %esi
   12b8e:      	cmpl	%r15d, %r12d
   12b91:      	seta	%sil
   12b95:      	movl	%r15d, %ecx
   12b98:      	cmovbl	%r12d, %ecx
   12b9c:      	addl	%ecx, %esi
   12b9e:      	movl	%r12d, %edi
   12ba1:      	subl	%esi, %edi
   12ba3:      	movl	%edi, 0x50(%rsp)
   12ba7:      	subq	%rsi, %rax
   12baa:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   12bb0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12bb6:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12bbc:      	cmpl	%r15d, %r12d
   12bbf:      	jbe	0x12bc5 <generic_rawtp_path+0x88e5>
   12bc1:      	movb	$0x2f, (%rbx,%rax)
   12bc5:      	xorl	%edi, %edi
   12bc7:      	cmpl	%r15d, %r12d
   12bca:      	seta	%dil
   12bce:      	movzbl	%cl, %esi
   12bd1:      	addq	%rax, %rbx
   12bd4:      	addq	%rbx, %rdi
   12bd7:      	movl	$0x4, %eax
   12bdc:      	callq	*%rax
   12bde:      	movq	%rbx, 0x48(%rsp)
   12be3:      	cmpl	%r15d, %r12d
   12be6:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12bec:      	movq	0x8(%rsp), %r12
   12bf1:      	movq	%r12, 0x30(%rsp)
   12bf6:      	movq	0x38(%rsp), %rdx
   12bfb:      	movq	0x40(%rsp), %r15
   12c00:      	jmp	0x12c53 <generic_rawtp_path+0x8973>
   12c02:      	leaq	0x10(%r15), %rdx
   12c06:      	movl	$0x4, %eax
   12c0b:      	movq	%rbp, %rdi
   12c0e:      	movl	$0x8, %esi
   12c13:      	callq	*%rax
   12c15:      	movq	0x40(%rsp), %rax
   12c1a:      	cmpq	(%rsp), %rax
   12c1e:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12c24:      	addq	$0x18, %r15
   12c28:      	movl	$0x4, %eax
   12c2d:      	leaq	0x30(%rsp), %rdi
   12c32:      	movl	$0x8, %esi
   12c37:      	movq	%r15, %rdx
   12c3a:      	callq	*%rax
   12c3c:      	movq	(%rsp), %r15
   12c40:      	movq	%r15, 0x40(%rsp)
   12c45:      	leaq	0x20(%r15), %rdx
   12c49:      	movq	%rdx, 0x38(%rsp)
   12c4e:      	movq	0x30(%rsp), %r12
   12c53:      	cmpq	0x18(%rsp), %r12
   12c58:      	jne	0x12c65 <generic_rawtp_path+0x8985>
   12c5a:      	cmpq	0x20(%rsp), %rdx
   12c5f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12c65:      	movl	$0x4, %eax
   12c6a:      	leaq	0x10(%rsp), %rdi
   12c6f:      	movl	$0x8, %esi
   12c74:      	callq	*%rax
   12c76:      	cmpq	0x10(%rsp), %r12
   12c7b:      	je	0x12d73 <generic_rawtp_path+0x8a93>
   12c81:      	leaq	0x18(%r12), %rbx
   12c86:      	movl	$0x4, %eax
   12c8b:      	movq	%rbp, %rdi
   12c8e:      	movl	$0x8, %esi
   12c93:      	movq	%rbx, %rdx
   12c96:      	callq	*%rax
   12c98:      	cmpq	%r12, (%rsp)
   12c9c:      	je	0x12d73 <generic_rawtp_path+0x8a93>
   12ca2:      	movl	$0x4, %eax
   12ca7:      	leaq	0x8(%rsp), %rdi
   12cac:      	movl	$0x8, %esi
   12cb1:      	movq	%rbx, %rdx
   12cb4:      	callq	*%rax
   12cb6:      	addq	$0x20, %r12
   12cba:      	movl	$0x4, %eax
   12cbf:      	leaq	0x58(%rsp), %rdi
   12cc4:      	movl	$0x10, %ecx
   12cc9:      	movl	$0x10, %esi
   12cce:      	movq	%r12, %rdx
   12cd1:      	callq	*%rax
   12cd3:      	movq	0x28(%rsp), %rbx
   12cd8:      	movq	0x48(%rsp), %rax
   12cdd:      	movl	0x5c(%rsp), %r15d
   12ce2:      	subq	%rbx, %rax
   12ce5:      	movl	0x50(%rsp), %r12d
   12cea:      	movl	%r15d, %edx
   12ced:      	subl	%r12d, %edx
   12cf0:      	movl	$0x0, %ecx
   12cf5:      	cmovbl	%ecx, %edx
   12cf8:      	addq	0x60(%rsp), %rdx
   12cfd:      	xorl	%esi, %esi
   12cff:      	cmpl	%r15d, %r12d
   12d02:      	seta	%sil
   12d06:      	movl	%r15d, %ecx
   12d09:      	cmovbl	%r12d, %ecx
   12d0d:      	addl	%ecx, %esi
   12d0f:      	movl	%r12d, %edi
   12d12:      	subl	%esi, %edi
   12d14:      	movl	%edi, 0x50(%rsp)
   12d18:      	subq	%rsi, %rax
   12d1b:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   12d21:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12d27:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12d2d:      	cmpl	%r15d, %r12d
   12d30:      	jbe	0x12d36 <generic_rawtp_path+0x8a56>
   12d32:      	movb	$0x2f, (%rbx,%rax)
   12d36:      	xorl	%edi, %edi
   12d38:      	cmpl	%r15d, %r12d
   12d3b:      	seta	%dil
   12d3f:      	movzbl	%cl, %esi
   12d42:      	addq	%rax, %rbx
   12d45:      	addq	%rbx, %rdi
   12d48:      	movl	$0x4, %eax
   12d4d:      	callq	*%rax
   12d4f:      	movq	%rbx, 0x48(%rsp)
   12d54:      	cmpl	%r15d, %r12d
   12d57:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12d5d:      	movq	0x8(%rsp), %r12
   12d62:      	movq	%r12, 0x30(%rsp)
   12d67:      	movq	0x38(%rsp), %rdx
   12d6c:      	movq	0x40(%rsp), %r15
   12d71:      	jmp	0x12dc4 <generic_rawtp_path+0x8ae4>
   12d73:      	leaq	0x10(%r15), %rdx
   12d77:      	movl	$0x4, %eax
   12d7c:      	movq	%rbp, %rdi
   12d7f:      	movl	$0x8, %esi
   12d84:      	callq	*%rax
   12d86:      	movq	0x40(%rsp), %rax
   12d8b:      	cmpq	(%rsp), %rax
   12d8f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12d95:      	addq	$0x18, %r15
   12d99:      	movl	$0x4, %eax
   12d9e:      	leaq	0x30(%rsp), %rdi
   12da3:      	movl	$0x8, %esi
   12da8:      	movq	%r15, %rdx
   12dab:      	callq	*%rax
   12dad:      	movq	(%rsp), %r15
   12db1:      	movq	%r15, 0x40(%rsp)
   12db6:      	leaq	0x20(%r15), %rdx
   12dba:      	movq	%rdx, 0x38(%rsp)
   12dbf:      	movq	0x30(%rsp), %r12
   12dc4:      	cmpq	0x18(%rsp), %r12
   12dc9:      	jne	0x12dd6 <generic_rawtp_path+0x8af6>
   12dcb:      	cmpq	0x20(%rsp), %rdx
   12dd0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12dd6:      	movl	$0x4, %eax
   12ddb:      	leaq	0x10(%rsp), %rdi
   12de0:      	movl	$0x8, %esi
   12de5:      	callq	*%rax
   12de7:      	cmpq	0x10(%rsp), %r12
   12dec:      	je	0x12ee4 <generic_rawtp_path+0x8c04>
   12df2:      	leaq	0x18(%r12), %rbx
   12df7:      	movl	$0x4, %eax
   12dfc:      	movq	%rbp, %rdi
   12dff:      	movl	$0x8, %esi
   12e04:      	movq	%rbx, %rdx
   12e07:      	callq	*%rax
   12e09:      	cmpq	%r12, (%rsp)
   12e0d:      	je	0x12ee4 <generic_rawtp_path+0x8c04>
   12e13:      	movl	$0x4, %eax
   12e18:      	leaq	0x8(%rsp), %rdi
   12e1d:      	movl	$0x8, %esi
   12e22:      	movq	%rbx, %rdx
   12e25:      	callq	*%rax
   12e27:      	addq	$0x20, %r12
   12e2b:      	movl	$0x4, %eax
   12e30:      	leaq	0x58(%rsp), %rdi
   12e35:      	movl	$0x10, %ecx
   12e3a:      	movl	$0x10, %esi
   12e3f:      	movq	%r12, %rdx
   12e42:      	callq	*%rax
   12e44:      	movq	0x28(%rsp), %rbx
   12e49:      	movq	0x48(%rsp), %rax
   12e4e:      	movl	0x5c(%rsp), %r15d
   12e53:      	subq	%rbx, %rax
   12e56:      	movl	0x50(%rsp), %r12d
   12e5b:      	movl	%r15d, %edx
   12e5e:      	subl	%r12d, %edx
   12e61:      	movl	$0x0, %ecx
   12e66:      	cmovbl	%ecx, %edx
   12e69:      	addq	0x60(%rsp), %rdx
   12e6e:      	xorl	%esi, %esi
   12e70:      	cmpl	%r15d, %r12d
   12e73:      	seta	%sil
   12e77:      	movl	%r15d, %ecx
   12e7a:      	cmovbl	%r12d, %ecx
   12e7e:      	addl	%ecx, %esi
   12e80:      	movl	%r12d, %edi
   12e83:      	subl	%esi, %edi
   12e85:      	movl	%edi, 0x50(%rsp)
   12e89:      	subq	%rsi, %rax
   12e8c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   12e92:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12e98:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   12e9e:      	cmpl	%r15d, %r12d
   12ea1:      	jbe	0x12ea7 <generic_rawtp_path+0x8bc7>
   12ea3:      	movb	$0x2f, (%rbx,%rax)
   12ea7:      	xorl	%edi, %edi
   12ea9:      	cmpl	%r15d, %r12d
   12eac:      	seta	%dil
   12eb0:      	movzbl	%cl, %esi
   12eb3:      	addq	%rax, %rbx
   12eb6:      	addq	%rbx, %rdi
   12eb9:      	movl	$0x4, %eax
   12ebe:      	callq	*%rax
   12ec0:      	movq	%rbx, 0x48(%rsp)
   12ec5:      	cmpl	%r15d, %r12d
   12ec8:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   12ece:      	movq	0x8(%rsp), %r12
   12ed3:      	movq	%r12, 0x30(%rsp)
   12ed8:      	movq	0x38(%rsp), %rdx
   12edd:      	movq	0x40(%rsp), %r15
   12ee2:      	jmp	0x12f35 <generic_rawtp_path+0x8c55>
   12ee4:      	leaq	0x10(%r15), %rdx
   12ee8:      	movl	$0x4, %eax
   12eed:      	movq	%rbp, %rdi
   12ef0:      	movl	$0x8, %esi
   12ef5:      	callq	*%rax
   12ef7:      	movq	0x40(%rsp), %rax
   12efc:      	cmpq	(%rsp), %rax
   12f00:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12f06:      	addq	$0x18, %r15
   12f0a:      	movl	$0x4, %eax
   12f0f:      	leaq	0x30(%rsp), %rdi
   12f14:      	movl	$0x8, %esi
   12f19:      	movq	%r15, %rdx
   12f1c:      	callq	*%rax
   12f1e:      	movq	(%rsp), %r15
   12f22:      	movq	%r15, 0x40(%rsp)
   12f27:      	leaq	0x20(%r15), %rdx
   12f2b:      	movq	%rdx, 0x38(%rsp)
   12f30:      	movq	0x30(%rsp), %r12
   12f35:      	cmpq	0x18(%rsp), %r12
   12f3a:      	jne	0x12f47 <generic_rawtp_path+0x8c67>
   12f3c:      	cmpq	0x20(%rsp), %rdx
   12f41:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   12f47:      	movl	$0x4, %eax
   12f4c:      	leaq	0x10(%rsp), %rdi
   12f51:      	movl	$0x8, %esi
   12f56:      	callq	*%rax
   12f58:      	cmpq	0x10(%rsp), %r12
   12f5d:      	je	0x13055 <generic_rawtp_path+0x8d75>
   12f63:      	leaq	0x18(%r12), %rbx
   12f68:      	movl	$0x4, %eax
   12f6d:      	movq	%rbp, %rdi
   12f70:      	movl	$0x8, %esi
   12f75:      	movq	%rbx, %rdx
   12f78:      	callq	*%rax
   12f7a:      	cmpq	%r12, (%rsp)
   12f7e:      	je	0x13055 <generic_rawtp_path+0x8d75>
   12f84:      	movl	$0x4, %eax
   12f89:      	leaq	0x8(%rsp), %rdi
   12f8e:      	movl	$0x8, %esi
   12f93:      	movq	%rbx, %rdx
   12f96:      	callq	*%rax
   12f98:      	addq	$0x20, %r12
   12f9c:      	movl	$0x4, %eax
   12fa1:      	leaq	0x58(%rsp), %rdi
   12fa6:      	movl	$0x10, %ecx
   12fab:      	movl	$0x10, %esi
   12fb0:      	movq	%r12, %rdx
   12fb3:      	callq	*%rax
   12fb5:      	movq	0x28(%rsp), %rbx
   12fba:      	movq	0x48(%rsp), %rax
   12fbf:      	movl	0x5c(%rsp), %r15d
   12fc4:      	subq	%rbx, %rax
   12fc7:      	movl	0x50(%rsp), %r12d
   12fcc:      	movl	%r15d, %edx
   12fcf:      	subl	%r12d, %edx
   12fd2:      	movl	$0x0, %ecx
   12fd7:      	cmovbl	%ecx, %edx
   12fda:      	addq	0x60(%rsp), %rdx
   12fdf:      	xorl	%esi, %esi
   12fe1:      	cmpl	%r15d, %r12d
   12fe4:      	seta	%sil
   12fe8:      	movl	%r15d, %ecx
   12feb:      	cmovbl	%r12d, %ecx
   12fef:      	addl	%ecx, %esi
   12ff1:      	movl	%r12d, %edi
   12ff4:      	subl	%esi, %edi
   12ff6:      	movl	%edi, 0x50(%rsp)
   12ffa:      	subq	%rsi, %rax
   12ffd:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13003:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13009:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1300f:      	cmpl	%r15d, %r12d
   13012:      	jbe	0x13018 <generic_rawtp_path+0x8d38>
   13014:      	movb	$0x2f, (%rbx,%rax)
   13018:      	xorl	%edi, %edi
   1301a:      	cmpl	%r15d, %r12d
   1301d:      	seta	%dil
   13021:      	movzbl	%cl, %esi
   13024:      	addq	%rax, %rbx
   13027:      	addq	%rbx, %rdi
   1302a:      	movl	$0x4, %eax
   1302f:      	callq	*%rax
   13031:      	movq	%rbx, 0x48(%rsp)
   13036:      	cmpl	%r15d, %r12d
   13039:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1303f:      	movq	0x8(%rsp), %r12
   13044:      	movq	%r12, 0x30(%rsp)
   13049:      	movq	0x38(%rsp), %rdx
   1304e:      	movq	0x40(%rsp), %r15
   13053:      	jmp	0x130a6 <generic_rawtp_path+0x8dc6>
   13055:      	leaq	0x10(%r15), %rdx
   13059:      	movl	$0x4, %eax
   1305e:      	movq	%rbp, %rdi
   13061:      	movl	$0x8, %esi
   13066:      	callq	*%rax
   13068:      	movq	0x40(%rsp), %rax
   1306d:      	cmpq	(%rsp), %rax
   13071:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13077:      	addq	$0x18, %r15
   1307b:      	movl	$0x4, %eax
   13080:      	leaq	0x30(%rsp), %rdi
   13085:      	movl	$0x8, %esi
   1308a:      	movq	%r15, %rdx
   1308d:      	callq	*%rax
   1308f:      	movq	(%rsp), %r15
   13093:      	movq	%r15, 0x40(%rsp)
   13098:      	leaq	0x20(%r15), %rdx
   1309c:      	movq	%rdx, 0x38(%rsp)
   130a1:      	movq	0x30(%rsp), %r12
   130a6:      	cmpq	0x18(%rsp), %r12
   130ab:      	jne	0x130b8 <generic_rawtp_path+0x8dd8>
   130ad:      	cmpq	0x20(%rsp), %rdx
   130b2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   130b8:      	movl	$0x4, %eax
   130bd:      	leaq	0x10(%rsp), %rdi
   130c2:      	movl	$0x8, %esi
   130c7:      	callq	*%rax
   130c9:      	cmpq	0x10(%rsp), %r12
   130ce:      	je	0x131c6 <generic_rawtp_path+0x8ee6>
   130d4:      	leaq	0x18(%r12), %rbx
   130d9:      	movl	$0x4, %eax
   130de:      	movq	%rbp, %rdi
   130e1:      	movl	$0x8, %esi
   130e6:      	movq	%rbx, %rdx
   130e9:      	callq	*%rax
   130eb:      	cmpq	%r12, (%rsp)
   130ef:      	je	0x131c6 <generic_rawtp_path+0x8ee6>
   130f5:      	movl	$0x4, %eax
   130fa:      	leaq	0x8(%rsp), %rdi
   130ff:      	movl	$0x8, %esi
   13104:      	movq	%rbx, %rdx
   13107:      	callq	*%rax
   13109:      	addq	$0x20, %r12
   1310d:      	movl	$0x4, %eax
   13112:      	leaq	0x58(%rsp), %rdi
   13117:      	movl	$0x10, %ecx
   1311c:      	movl	$0x10, %esi
   13121:      	movq	%r12, %rdx
   13124:      	callq	*%rax
   13126:      	movq	0x28(%rsp), %rbx
   1312b:      	movq	0x48(%rsp), %rax
   13130:      	movl	0x5c(%rsp), %r15d
   13135:      	subq	%rbx, %rax
   13138:      	movl	0x50(%rsp), %r12d
   1313d:      	movl	%r15d, %edx
   13140:      	subl	%r12d, %edx
   13143:      	movl	$0x0, %ecx
   13148:      	cmovbl	%ecx, %edx
   1314b:      	addq	0x60(%rsp), %rdx
   13150:      	xorl	%esi, %esi
   13152:      	cmpl	%r15d, %r12d
   13155:      	seta	%sil
   13159:      	movl	%r15d, %ecx
   1315c:      	cmovbl	%r12d, %ecx
   13160:      	addl	%ecx, %esi
   13162:      	movl	%r12d, %edi
   13165:      	subl	%esi, %edi
   13167:      	movl	%edi, 0x50(%rsp)
   1316b:      	subq	%rsi, %rax
   1316e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13174:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1317a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13180:      	cmpl	%r15d, %r12d
   13183:      	jbe	0x13189 <generic_rawtp_path+0x8ea9>
   13185:      	movb	$0x2f, (%rbx,%rax)
   13189:      	xorl	%edi, %edi
   1318b:      	cmpl	%r15d, %r12d
   1318e:      	seta	%dil
   13192:      	movzbl	%cl, %esi
   13195:      	addq	%rax, %rbx
   13198:      	addq	%rbx, %rdi
   1319b:      	movl	$0x4, %eax
   131a0:      	callq	*%rax
   131a2:      	movq	%rbx, 0x48(%rsp)
   131a7:      	cmpl	%r15d, %r12d
   131aa:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   131b0:      	movq	0x8(%rsp), %r12
   131b5:      	movq	%r12, 0x30(%rsp)
   131ba:      	movq	0x38(%rsp), %rdx
   131bf:      	movq	0x40(%rsp), %r15
   131c4:      	jmp	0x13217 <generic_rawtp_path+0x8f37>
   131c6:      	leaq	0x10(%r15), %rdx
   131ca:      	movl	$0x4, %eax
   131cf:      	movq	%rbp, %rdi
   131d2:      	movl	$0x8, %esi
   131d7:      	callq	*%rax
   131d9:      	movq	0x40(%rsp), %rax
   131de:      	cmpq	(%rsp), %rax
   131e2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   131e8:      	addq	$0x18, %r15
   131ec:      	movl	$0x4, %eax
   131f1:      	leaq	0x30(%rsp), %rdi
   131f6:      	movl	$0x8, %esi
   131fb:      	movq	%r15, %rdx
   131fe:      	callq	*%rax
   13200:      	movq	(%rsp), %r15
   13204:      	movq	%r15, 0x40(%rsp)
   13209:      	leaq	0x20(%r15), %rdx
   1320d:      	movq	%rdx, 0x38(%rsp)
   13212:      	movq	0x30(%rsp), %r12
   13217:      	cmpq	0x18(%rsp), %r12
   1321c:      	jne	0x13229 <generic_rawtp_path+0x8f49>
   1321e:      	cmpq	0x20(%rsp), %rdx
   13223:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13229:      	movl	$0x4, %eax
   1322e:      	leaq	0x10(%rsp), %rdi
   13233:      	movl	$0x8, %esi
   13238:      	callq	*%rax
   1323a:      	cmpq	0x10(%rsp), %r12
   1323f:      	je	0x13337 <generic_rawtp_path+0x9057>
   13245:      	leaq	0x18(%r12), %rbx
   1324a:      	movl	$0x4, %eax
   1324f:      	movq	%rbp, %rdi
   13252:      	movl	$0x8, %esi
   13257:      	movq	%rbx, %rdx
   1325a:      	callq	*%rax
   1325c:      	cmpq	%r12, (%rsp)
   13260:      	je	0x13337 <generic_rawtp_path+0x9057>
   13266:      	movl	$0x4, %eax
   1326b:      	leaq	0x8(%rsp), %rdi
   13270:      	movl	$0x8, %esi
   13275:      	movq	%rbx, %rdx
   13278:      	callq	*%rax
   1327a:      	addq	$0x20, %r12
   1327e:      	movl	$0x4, %eax
   13283:      	leaq	0x58(%rsp), %rdi
   13288:      	movl	$0x10, %ecx
   1328d:      	movl	$0x10, %esi
   13292:      	movq	%r12, %rdx
   13295:      	callq	*%rax
   13297:      	movq	0x28(%rsp), %rbx
   1329c:      	movq	0x48(%rsp), %rax
   132a1:      	movl	0x5c(%rsp), %r15d
   132a6:      	subq	%rbx, %rax
   132a9:      	movl	0x50(%rsp), %r12d
   132ae:      	movl	%r15d, %edx
   132b1:      	subl	%r12d, %edx
   132b4:      	movl	$0x0, %ecx
   132b9:      	cmovbl	%ecx, %edx
   132bc:      	addq	0x60(%rsp), %rdx
   132c1:      	xorl	%esi, %esi
   132c3:      	cmpl	%r15d, %r12d
   132c6:      	seta	%sil
   132ca:      	movl	%r15d, %ecx
   132cd:      	cmovbl	%r12d, %ecx
   132d1:      	addl	%ecx, %esi
   132d3:      	movl	%r12d, %edi
   132d6:      	subl	%esi, %edi
   132d8:      	movl	%edi, 0x50(%rsp)
   132dc:      	subq	%rsi, %rax
   132df:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   132e5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   132eb:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   132f1:      	cmpl	%r15d, %r12d
   132f4:      	jbe	0x132fa <generic_rawtp_path+0x901a>
   132f6:      	movb	$0x2f, (%rbx,%rax)
   132fa:      	xorl	%edi, %edi
   132fc:      	cmpl	%r15d, %r12d
   132ff:      	seta	%dil
   13303:      	movzbl	%cl, %esi
   13306:      	addq	%rax, %rbx
   13309:      	addq	%rbx, %rdi
   1330c:      	movl	$0x4, %eax
   13311:      	callq	*%rax
   13313:      	movq	%rbx, 0x48(%rsp)
   13318:      	cmpl	%r15d, %r12d
   1331b:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13321:      	movq	0x8(%rsp), %r12
   13326:      	movq	%r12, 0x30(%rsp)
   1332b:      	movq	0x38(%rsp), %rdx
   13330:      	movq	0x40(%rsp), %r15
   13335:      	jmp	0x13388 <generic_rawtp_path+0x90a8>
   13337:      	leaq	0x10(%r15), %rdx
   1333b:      	movl	$0x4, %eax
   13340:      	movq	%rbp, %rdi
   13343:      	movl	$0x8, %esi
   13348:      	callq	*%rax
   1334a:      	movq	0x40(%rsp), %rax
   1334f:      	cmpq	(%rsp), %rax
   13353:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13359:      	addq	$0x18, %r15
   1335d:      	movl	$0x4, %eax
   13362:      	leaq	0x30(%rsp), %rdi
   13367:      	movl	$0x8, %esi
   1336c:      	movq	%r15, %rdx
   1336f:      	callq	*%rax
   13371:      	movq	(%rsp), %r15
   13375:      	movq	%r15, 0x40(%rsp)
   1337a:      	leaq	0x20(%r15), %rdx
   1337e:      	movq	%rdx, 0x38(%rsp)
   13383:      	movq	0x30(%rsp), %r12
   13388:      	cmpq	0x18(%rsp), %r12
   1338d:      	jne	0x1339a <generic_rawtp_path+0x90ba>
   1338f:      	cmpq	0x20(%rsp), %rdx
   13394:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1339a:      	movl	$0x4, %eax
   1339f:      	leaq	0x10(%rsp), %rdi
   133a4:      	movl	$0x8, %esi
   133a9:      	callq	*%rax
   133ab:      	cmpq	0x10(%rsp), %r12
   133b0:      	je	0x134a8 <generic_rawtp_path+0x91c8>
   133b6:      	leaq	0x18(%r12), %rbx
   133bb:      	movl	$0x4, %eax
   133c0:      	movq	%rbp, %rdi
   133c3:      	movl	$0x8, %esi
   133c8:      	movq	%rbx, %rdx
   133cb:      	callq	*%rax
   133cd:      	cmpq	%r12, (%rsp)
   133d1:      	je	0x134a8 <generic_rawtp_path+0x91c8>
   133d7:      	movl	$0x4, %eax
   133dc:      	leaq	0x8(%rsp), %rdi
   133e1:      	movl	$0x8, %esi
   133e6:      	movq	%rbx, %rdx
   133e9:      	callq	*%rax
   133eb:      	addq	$0x20, %r12
   133ef:      	movl	$0x4, %eax
   133f4:      	leaq	0x58(%rsp), %rdi
   133f9:      	movl	$0x10, %ecx
   133fe:      	movl	$0x10, %esi
   13403:      	movq	%r12, %rdx
   13406:      	callq	*%rax
   13408:      	movq	0x28(%rsp), %rbx
   1340d:      	movq	0x48(%rsp), %rax
   13412:      	movl	0x5c(%rsp), %r15d
   13417:      	subq	%rbx, %rax
   1341a:      	movl	0x50(%rsp), %r12d
   1341f:      	movl	%r15d, %edx
   13422:      	subl	%r12d, %edx
   13425:      	movl	$0x0, %ecx
   1342a:      	cmovbl	%ecx, %edx
   1342d:      	addq	0x60(%rsp), %rdx
   13432:      	xorl	%esi, %esi
   13434:      	cmpl	%r15d, %r12d
   13437:      	seta	%sil
   1343b:      	movl	%r15d, %ecx
   1343e:      	cmovbl	%r12d, %ecx
   13442:      	addl	%ecx, %esi
   13444:      	movl	%r12d, %edi
   13447:      	subl	%esi, %edi
   13449:      	movl	%edi, 0x50(%rsp)
   1344d:      	subq	%rsi, %rax
   13450:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13456:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1345c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13462:      	cmpl	%r15d, %r12d
   13465:      	jbe	0x1346b <generic_rawtp_path+0x918b>
   13467:      	movb	$0x2f, (%rbx,%rax)
   1346b:      	xorl	%edi, %edi
   1346d:      	cmpl	%r15d, %r12d
   13470:      	seta	%dil
   13474:      	movzbl	%cl, %esi
   13477:      	addq	%rax, %rbx
   1347a:      	addq	%rbx, %rdi
   1347d:      	movl	$0x4, %eax
   13482:      	callq	*%rax
   13484:      	movq	%rbx, 0x48(%rsp)
   13489:      	cmpl	%r15d, %r12d
   1348c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13492:      	movq	0x8(%rsp), %r12
   13497:      	movq	%r12, 0x30(%rsp)
   1349c:      	movq	0x38(%rsp), %rdx
   134a1:      	movq	0x40(%rsp), %r15
   134a6:      	jmp	0x134f9 <generic_rawtp_path+0x9219>
   134a8:      	leaq	0x10(%r15), %rdx
   134ac:      	movl	$0x4, %eax
   134b1:      	movq	%rbp, %rdi
   134b4:      	movl	$0x8, %esi
   134b9:      	callq	*%rax
   134bb:      	movq	0x40(%rsp), %rax
   134c0:      	cmpq	(%rsp), %rax
   134c4:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   134ca:      	addq	$0x18, %r15
   134ce:      	movl	$0x4, %eax
   134d3:      	leaq	0x30(%rsp), %rdi
   134d8:      	movl	$0x8, %esi
   134dd:      	movq	%r15, %rdx
   134e0:      	callq	*%rax
   134e2:      	movq	(%rsp), %r15
   134e6:      	movq	%r15, 0x40(%rsp)
   134eb:      	leaq	0x20(%r15), %rdx
   134ef:      	movq	%rdx, 0x38(%rsp)
   134f4:      	movq	0x30(%rsp), %r12
   134f9:      	cmpq	0x18(%rsp), %r12
   134fe:      	jne	0x1350b <generic_rawtp_path+0x922b>
   13500:      	cmpq	0x20(%rsp), %rdx
   13505:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1350b:      	movl	$0x4, %eax
   13510:      	leaq	0x10(%rsp), %rdi
   13515:      	movl	$0x8, %esi
   1351a:      	callq	*%rax
   1351c:      	cmpq	0x10(%rsp), %r12
   13521:      	je	0x13619 <generic_rawtp_path+0x9339>
   13527:      	leaq	0x18(%r12), %rbx
   1352c:      	movl	$0x4, %eax
   13531:      	movq	%rbp, %rdi
   13534:      	movl	$0x8, %esi
   13539:      	movq	%rbx, %rdx
   1353c:      	callq	*%rax
   1353e:      	cmpq	%r12, (%rsp)
   13542:      	je	0x13619 <generic_rawtp_path+0x9339>
   13548:      	movl	$0x4, %eax
   1354d:      	leaq	0x8(%rsp), %rdi
   13552:      	movl	$0x8, %esi
   13557:      	movq	%rbx, %rdx
   1355a:      	callq	*%rax
   1355c:      	addq	$0x20, %r12
   13560:      	movl	$0x4, %eax
   13565:      	leaq	0x58(%rsp), %rdi
   1356a:      	movl	$0x10, %ecx
   1356f:      	movl	$0x10, %esi
   13574:      	movq	%r12, %rdx
   13577:      	callq	*%rax
   13579:      	movq	0x28(%rsp), %rbx
   1357e:      	movq	0x48(%rsp), %rax
   13583:      	movl	0x5c(%rsp), %r15d
   13588:      	subq	%rbx, %rax
   1358b:      	movl	0x50(%rsp), %r12d
   13590:      	movl	%r15d, %edx
   13593:      	subl	%r12d, %edx
   13596:      	movl	$0x0, %ecx
   1359b:      	cmovbl	%ecx, %edx
   1359e:      	addq	0x60(%rsp), %rdx
   135a3:      	xorl	%esi, %esi
   135a5:      	cmpl	%r15d, %r12d
   135a8:      	seta	%sil
   135ac:      	movl	%r15d, %ecx
   135af:      	cmovbl	%r12d, %ecx
   135b3:      	addl	%ecx, %esi
   135b5:      	movl	%r12d, %edi
   135b8:      	subl	%esi, %edi
   135ba:      	movl	%edi, 0x50(%rsp)
   135be:      	subq	%rsi, %rax
   135c1:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   135c7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   135cd:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   135d3:      	cmpl	%r15d, %r12d
   135d6:      	jbe	0x135dc <generic_rawtp_path+0x92fc>
   135d8:      	movb	$0x2f, (%rbx,%rax)
   135dc:      	xorl	%edi, %edi
   135de:      	cmpl	%r15d, %r12d
   135e1:      	seta	%dil
   135e5:      	movzbl	%cl, %esi
   135e8:      	addq	%rax, %rbx
   135eb:      	addq	%rbx, %rdi
   135ee:      	movl	$0x4, %eax
   135f3:      	callq	*%rax
   135f5:      	movq	%rbx, 0x48(%rsp)
   135fa:      	cmpl	%r15d, %r12d
   135fd:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13603:      	movq	0x8(%rsp), %r12
   13608:      	movq	%r12, 0x30(%rsp)
   1360d:      	movq	0x38(%rsp), %rdx
   13612:      	movq	0x40(%rsp), %r15
   13617:      	jmp	0x1366a <generic_rawtp_path+0x938a>
   13619:      	leaq	0x10(%r15), %rdx
   1361d:      	movl	$0x4, %eax
   13622:      	movq	%rbp, %rdi
   13625:      	movl	$0x8, %esi
   1362a:      	callq	*%rax
   1362c:      	movq	0x40(%rsp), %rax
   13631:      	cmpq	(%rsp), %rax
   13635:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1363b:      	addq	$0x18, %r15
   1363f:      	movl	$0x4, %eax
   13644:      	leaq	0x30(%rsp), %rdi
   13649:      	movl	$0x8, %esi
   1364e:      	movq	%r15, %rdx
   13651:      	callq	*%rax
   13653:      	movq	(%rsp), %r15
   13657:      	movq	%r15, 0x40(%rsp)
   1365c:      	leaq	0x20(%r15), %rdx
   13660:      	movq	%rdx, 0x38(%rsp)
   13665:      	movq	0x30(%rsp), %r12
   1366a:      	cmpq	0x18(%rsp), %r12
   1366f:      	jne	0x1367c <generic_rawtp_path+0x939c>
   13671:      	cmpq	0x20(%rsp), %rdx
   13676:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1367c:      	movl	$0x4, %eax
   13681:      	leaq	0x10(%rsp), %rdi
   13686:      	movl	$0x8, %esi
   1368b:      	callq	*%rax
   1368d:      	cmpq	0x10(%rsp), %r12
   13692:      	je	0x1378a <generic_rawtp_path+0x94aa>
   13698:      	leaq	0x18(%r12), %rbx
   1369d:      	movl	$0x4, %eax
   136a2:      	movq	%rbp, %rdi
   136a5:      	movl	$0x8, %esi
   136aa:      	movq	%rbx, %rdx
   136ad:      	callq	*%rax
   136af:      	cmpq	%r12, (%rsp)
   136b3:      	je	0x1378a <generic_rawtp_path+0x94aa>
   136b9:      	movl	$0x4, %eax
   136be:      	leaq	0x8(%rsp), %rdi
   136c3:      	movl	$0x8, %esi
   136c8:      	movq	%rbx, %rdx
   136cb:      	callq	*%rax
   136cd:      	addq	$0x20, %r12
   136d1:      	movl	$0x4, %eax
   136d6:      	leaq	0x58(%rsp), %rdi
   136db:      	movl	$0x10, %ecx
   136e0:      	movl	$0x10, %esi
   136e5:      	movq	%r12, %rdx
   136e8:      	callq	*%rax
   136ea:      	movq	0x28(%rsp), %rbx
   136ef:      	movq	0x48(%rsp), %rax
   136f4:      	movl	0x5c(%rsp), %r15d
   136f9:      	subq	%rbx, %rax
   136fc:      	movl	0x50(%rsp), %r12d
   13701:      	movl	%r15d, %edx
   13704:      	subl	%r12d, %edx
   13707:      	movl	$0x0, %ecx
   1370c:      	cmovbl	%ecx, %edx
   1370f:      	addq	0x60(%rsp), %rdx
   13714:      	xorl	%esi, %esi
   13716:      	cmpl	%r15d, %r12d
   13719:      	seta	%sil
   1371d:      	movl	%r15d, %ecx
   13720:      	cmovbl	%r12d, %ecx
   13724:      	addl	%ecx, %esi
   13726:      	movl	%r12d, %edi
   13729:      	subl	%esi, %edi
   1372b:      	movl	%edi, 0x50(%rsp)
   1372f:      	subq	%rsi, %rax
   13732:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13738:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1373e:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13744:      	cmpl	%r15d, %r12d
   13747:      	jbe	0x1374d <generic_rawtp_path+0x946d>
   13749:      	movb	$0x2f, (%rbx,%rax)
   1374d:      	xorl	%edi, %edi
   1374f:      	cmpl	%r15d, %r12d
   13752:      	seta	%dil
   13756:      	movzbl	%cl, %esi
   13759:      	addq	%rax, %rbx
   1375c:      	addq	%rbx, %rdi
   1375f:      	movl	$0x4, %eax
   13764:      	callq	*%rax
   13766:      	movq	%rbx, 0x48(%rsp)
   1376b:      	cmpl	%r15d, %r12d
   1376e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13774:      	movq	0x8(%rsp), %r12
   13779:      	movq	%r12, 0x30(%rsp)
   1377e:      	movq	0x38(%rsp), %rdx
   13783:      	movq	0x40(%rsp), %r15
   13788:      	jmp	0x137db <generic_rawtp_path+0x94fb>
   1378a:      	leaq	0x10(%r15), %rdx
   1378e:      	movl	$0x4, %eax
   13793:      	movq	%rbp, %rdi
   13796:      	movl	$0x8, %esi
   1379b:      	callq	*%rax
   1379d:      	movq	0x40(%rsp), %rax
   137a2:      	cmpq	(%rsp), %rax
   137a6:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   137ac:      	addq	$0x18, %r15
   137b0:      	movl	$0x4, %eax
   137b5:      	leaq	0x30(%rsp), %rdi
   137ba:      	movl	$0x8, %esi
   137bf:      	movq	%r15, %rdx
   137c2:      	callq	*%rax
   137c4:      	movq	(%rsp), %r15
   137c8:      	movq	%r15, 0x40(%rsp)
   137cd:      	leaq	0x20(%r15), %rdx
   137d1:      	movq	%rdx, 0x38(%rsp)
   137d6:      	movq	0x30(%rsp), %r12
   137db:      	cmpq	0x18(%rsp), %r12
   137e0:      	jne	0x137ed <generic_rawtp_path+0x950d>
   137e2:      	cmpq	0x20(%rsp), %rdx
   137e7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   137ed:      	movl	$0x4, %eax
   137f2:      	leaq	0x10(%rsp), %rdi
   137f7:      	movl	$0x8, %esi
   137fc:      	callq	*%rax
   137fe:      	cmpq	0x10(%rsp), %r12
   13803:      	je	0x138fb <generic_rawtp_path+0x961b>
   13809:      	leaq	0x18(%r12), %rbx
   1380e:      	movl	$0x4, %eax
   13813:      	movq	%rbp, %rdi
   13816:      	movl	$0x8, %esi
   1381b:      	movq	%rbx, %rdx
   1381e:      	callq	*%rax
   13820:      	cmpq	%r12, (%rsp)
   13824:      	je	0x138fb <generic_rawtp_path+0x961b>
   1382a:      	movl	$0x4, %eax
   1382f:      	leaq	0x8(%rsp), %rdi
   13834:      	movl	$0x8, %esi
   13839:      	movq	%rbx, %rdx
   1383c:      	callq	*%rax
   1383e:      	addq	$0x20, %r12
   13842:      	movl	$0x4, %eax
   13847:      	leaq	0x58(%rsp), %rdi
   1384c:      	movl	$0x10, %ecx
   13851:      	movl	$0x10, %esi
   13856:      	movq	%r12, %rdx
   13859:      	callq	*%rax
   1385b:      	movq	0x28(%rsp), %rbx
   13860:      	movq	0x48(%rsp), %rax
   13865:      	movl	0x5c(%rsp), %r15d
   1386a:      	subq	%rbx, %rax
   1386d:      	movl	0x50(%rsp), %r12d
   13872:      	movl	%r15d, %edx
   13875:      	subl	%r12d, %edx
   13878:      	movl	$0x0, %ecx
   1387d:      	cmovbl	%ecx, %edx
   13880:      	addq	0x60(%rsp), %rdx
   13885:      	xorl	%esi, %esi
   13887:      	cmpl	%r15d, %r12d
   1388a:      	seta	%sil
   1388e:      	movl	%r15d, %ecx
   13891:      	cmovbl	%r12d, %ecx
   13895:      	addl	%ecx, %esi
   13897:      	movl	%r12d, %edi
   1389a:      	subl	%esi, %edi
   1389c:      	movl	%edi, 0x50(%rsp)
   138a0:      	subq	%rsi, %rax
   138a3:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   138a9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   138af:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   138b5:      	cmpl	%r15d, %r12d
   138b8:      	jbe	0x138be <generic_rawtp_path+0x95de>
   138ba:      	movb	$0x2f, (%rbx,%rax)
   138be:      	xorl	%edi, %edi
   138c0:      	cmpl	%r15d, %r12d
   138c3:      	seta	%dil
   138c7:      	movzbl	%cl, %esi
   138ca:      	addq	%rax, %rbx
   138cd:      	addq	%rbx, %rdi
   138d0:      	movl	$0x4, %eax
   138d5:      	callq	*%rax
   138d7:      	movq	%rbx, 0x48(%rsp)
   138dc:      	cmpl	%r15d, %r12d
   138df:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   138e5:      	movq	0x8(%rsp), %r12
   138ea:      	movq	%r12, 0x30(%rsp)
   138ef:      	movq	0x38(%rsp), %rdx
   138f4:      	movq	0x40(%rsp), %r15
   138f9:      	jmp	0x1394c <generic_rawtp_path+0x966c>
   138fb:      	leaq	0x10(%r15), %rdx
   138ff:      	movl	$0x4, %eax
   13904:      	movq	%rbp, %rdi
   13907:      	movl	$0x8, %esi
   1390c:      	callq	*%rax
   1390e:      	movq	0x40(%rsp), %rax
   13913:      	cmpq	(%rsp), %rax
   13917:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1391d:      	addq	$0x18, %r15
   13921:      	movl	$0x4, %eax
   13926:      	leaq	0x30(%rsp), %rdi
   1392b:      	movl	$0x8, %esi
   13930:      	movq	%r15, %rdx
   13933:      	callq	*%rax
   13935:      	movq	(%rsp), %r15
   13939:      	movq	%r15, 0x40(%rsp)
   1393e:      	leaq	0x20(%r15), %rdx
   13942:      	movq	%rdx, 0x38(%rsp)
   13947:      	movq	0x30(%rsp), %r12
   1394c:      	cmpq	0x18(%rsp), %r12
   13951:      	jne	0x1395e <generic_rawtp_path+0x967e>
   13953:      	cmpq	0x20(%rsp), %rdx
   13958:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1395e:      	movl	$0x4, %eax
   13963:      	leaq	0x10(%rsp), %rdi
   13968:      	movl	$0x8, %esi
   1396d:      	callq	*%rax
   1396f:      	cmpq	0x10(%rsp), %r12
   13974:      	je	0x13a6c <generic_rawtp_path+0x978c>
   1397a:      	leaq	0x18(%r12), %rbx
   1397f:      	movl	$0x4, %eax
   13984:      	movq	%rbp, %rdi
   13987:      	movl	$0x8, %esi
   1398c:      	movq	%rbx, %rdx
   1398f:      	callq	*%rax
   13991:      	cmpq	%r12, (%rsp)
   13995:      	je	0x13a6c <generic_rawtp_path+0x978c>
   1399b:      	movl	$0x4, %eax
   139a0:      	leaq	0x8(%rsp), %rdi
   139a5:      	movl	$0x8, %esi
   139aa:      	movq	%rbx, %rdx
   139ad:      	callq	*%rax
   139af:      	addq	$0x20, %r12
   139b3:      	movl	$0x4, %eax
   139b8:      	leaq	0x58(%rsp), %rdi
   139bd:      	movl	$0x10, %ecx
   139c2:      	movl	$0x10, %esi
   139c7:      	movq	%r12, %rdx
   139ca:      	callq	*%rax
   139cc:      	movq	0x28(%rsp), %rbx
   139d1:      	movq	0x48(%rsp), %rax
   139d6:      	movl	0x5c(%rsp), %r15d
   139db:      	subq	%rbx, %rax
   139de:      	movl	0x50(%rsp), %r12d
   139e3:      	movl	%r15d, %edx
   139e6:      	subl	%r12d, %edx
   139e9:      	movl	$0x0, %ecx
   139ee:      	cmovbl	%ecx, %edx
   139f1:      	addq	0x60(%rsp), %rdx
   139f6:      	xorl	%esi, %esi
   139f8:      	cmpl	%r15d, %r12d
   139fb:      	seta	%sil
   139ff:      	movl	%r15d, %ecx
   13a02:      	cmovbl	%r12d, %ecx
   13a06:      	addl	%ecx, %esi
   13a08:      	movl	%r12d, %edi
   13a0b:      	subl	%esi, %edi
   13a0d:      	movl	%edi, 0x50(%rsp)
   13a11:      	subq	%rsi, %rax
   13a14:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13a1a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13a20:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13a26:      	cmpl	%r15d, %r12d
   13a29:      	jbe	0x13a2f <generic_rawtp_path+0x974f>
   13a2b:      	movb	$0x2f, (%rbx,%rax)
   13a2f:      	xorl	%edi, %edi
   13a31:      	cmpl	%r15d, %r12d
   13a34:      	seta	%dil
   13a38:      	movzbl	%cl, %esi
   13a3b:      	addq	%rax, %rbx
   13a3e:      	addq	%rbx, %rdi
   13a41:      	movl	$0x4, %eax
   13a46:      	callq	*%rax
   13a48:      	movq	%rbx, 0x48(%rsp)
   13a4d:      	cmpl	%r15d, %r12d
   13a50:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13a56:      	movq	0x8(%rsp), %r12
   13a5b:      	movq	%r12, 0x30(%rsp)
   13a60:      	movq	0x38(%rsp), %rdx
   13a65:      	movq	0x40(%rsp), %r15
   13a6a:      	jmp	0x13abd <generic_rawtp_path+0x97dd>
   13a6c:      	leaq	0x10(%r15), %rdx
   13a70:      	movl	$0x4, %eax
   13a75:      	movq	%rbp, %rdi
   13a78:      	movl	$0x8, %esi
   13a7d:      	callq	*%rax
   13a7f:      	movq	0x40(%rsp), %rax
   13a84:      	cmpq	(%rsp), %rax
   13a88:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13a8e:      	addq	$0x18, %r15
   13a92:      	movl	$0x4, %eax
   13a97:      	leaq	0x30(%rsp), %rdi
   13a9c:      	movl	$0x8, %esi
   13aa1:      	movq	%r15, %rdx
   13aa4:      	callq	*%rax
   13aa6:      	movq	(%rsp), %r15
   13aaa:      	movq	%r15, 0x40(%rsp)
   13aaf:      	leaq	0x20(%r15), %rdx
   13ab3:      	movq	%rdx, 0x38(%rsp)
   13ab8:      	movq	0x30(%rsp), %r12
   13abd:      	cmpq	0x18(%rsp), %r12
   13ac2:      	jne	0x13acf <generic_rawtp_path+0x97ef>
   13ac4:      	cmpq	0x20(%rsp), %rdx
   13ac9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13acf:      	movl	$0x4, %eax
   13ad4:      	leaq	0x10(%rsp), %rdi
   13ad9:      	movl	$0x8, %esi
   13ade:      	callq	*%rax
   13ae0:      	cmpq	0x10(%rsp), %r12
   13ae5:      	je	0x13bdd <generic_rawtp_path+0x98fd>
   13aeb:      	leaq	0x18(%r12), %rbx
   13af0:      	movl	$0x4, %eax
   13af5:      	movq	%rbp, %rdi
   13af8:      	movl	$0x8, %esi
   13afd:      	movq	%rbx, %rdx
   13b00:      	callq	*%rax
   13b02:      	cmpq	%r12, (%rsp)
   13b06:      	je	0x13bdd <generic_rawtp_path+0x98fd>
   13b0c:      	movl	$0x4, %eax
   13b11:      	leaq	0x8(%rsp), %rdi
   13b16:      	movl	$0x8, %esi
   13b1b:      	movq	%rbx, %rdx
   13b1e:      	callq	*%rax
   13b20:      	addq	$0x20, %r12
   13b24:      	movl	$0x4, %eax
   13b29:      	leaq	0x58(%rsp), %rdi
   13b2e:      	movl	$0x10, %ecx
   13b33:      	movl	$0x10, %esi
   13b38:      	movq	%r12, %rdx
   13b3b:      	callq	*%rax
   13b3d:      	movq	0x28(%rsp), %rbx
   13b42:      	movq	0x48(%rsp), %rax
   13b47:      	movl	0x5c(%rsp), %r15d
   13b4c:      	subq	%rbx, %rax
   13b4f:      	movl	0x50(%rsp), %r12d
   13b54:      	movl	%r15d, %edx
   13b57:      	subl	%r12d, %edx
   13b5a:      	movl	$0x0, %ecx
   13b5f:      	cmovbl	%ecx, %edx
   13b62:      	addq	0x60(%rsp), %rdx
   13b67:      	xorl	%esi, %esi
   13b69:      	cmpl	%r15d, %r12d
   13b6c:      	seta	%sil
   13b70:      	movl	%r15d, %ecx
   13b73:      	cmovbl	%r12d, %ecx
   13b77:      	addl	%ecx, %esi
   13b79:      	movl	%r12d, %edi
   13b7c:      	subl	%esi, %edi
   13b7e:      	movl	%edi, 0x50(%rsp)
   13b82:      	subq	%rsi, %rax
   13b85:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13b8b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13b91:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13b97:      	cmpl	%r15d, %r12d
   13b9a:      	jbe	0x13ba0 <generic_rawtp_path+0x98c0>
   13b9c:      	movb	$0x2f, (%rbx,%rax)
   13ba0:      	xorl	%edi, %edi
   13ba2:      	cmpl	%r15d, %r12d
   13ba5:      	seta	%dil
   13ba9:      	movzbl	%cl, %esi
   13bac:      	addq	%rax, %rbx
   13baf:      	addq	%rbx, %rdi
   13bb2:      	movl	$0x4, %eax
   13bb7:      	callq	*%rax
   13bb9:      	movq	%rbx, 0x48(%rsp)
   13bbe:      	cmpl	%r15d, %r12d
   13bc1:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13bc7:      	movq	0x8(%rsp), %r12
   13bcc:      	movq	%r12, 0x30(%rsp)
   13bd1:      	movq	0x38(%rsp), %rdx
   13bd6:      	movq	0x40(%rsp), %r15
   13bdb:      	jmp	0x13c2e <generic_rawtp_path+0x994e>
   13bdd:      	leaq	0x10(%r15), %rdx
   13be1:      	movl	$0x4, %eax
   13be6:      	movq	%rbp, %rdi
   13be9:      	movl	$0x8, %esi
   13bee:      	callq	*%rax
   13bf0:      	movq	0x40(%rsp), %rax
   13bf5:      	cmpq	(%rsp), %rax
   13bf9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13bff:      	addq	$0x18, %r15
   13c03:      	movl	$0x4, %eax
   13c08:      	leaq	0x30(%rsp), %rdi
   13c0d:      	movl	$0x8, %esi
   13c12:      	movq	%r15, %rdx
   13c15:      	callq	*%rax
   13c17:      	movq	(%rsp), %r15
   13c1b:      	movq	%r15, 0x40(%rsp)
   13c20:      	leaq	0x20(%r15), %rdx
   13c24:      	movq	%rdx, 0x38(%rsp)
   13c29:      	movq	0x30(%rsp), %r12
   13c2e:      	cmpq	0x18(%rsp), %r12
   13c33:      	jne	0x13c40 <generic_rawtp_path+0x9960>
   13c35:      	cmpq	0x20(%rsp), %rdx
   13c3a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13c40:      	movl	$0x4, %eax
   13c45:      	leaq	0x10(%rsp), %rdi
   13c4a:      	movl	$0x8, %esi
   13c4f:      	callq	*%rax
   13c51:      	cmpq	0x10(%rsp), %r12
   13c56:      	je	0x13d4e <generic_rawtp_path+0x9a6e>
   13c5c:      	leaq	0x18(%r12), %rbx
   13c61:      	movl	$0x4, %eax
   13c66:      	movq	%rbp, %rdi
   13c69:      	movl	$0x8, %esi
   13c6e:      	movq	%rbx, %rdx
   13c71:      	callq	*%rax
   13c73:      	cmpq	%r12, (%rsp)
   13c77:      	je	0x13d4e <generic_rawtp_path+0x9a6e>
   13c7d:      	movl	$0x4, %eax
   13c82:      	leaq	0x8(%rsp), %rdi
   13c87:      	movl	$0x8, %esi
   13c8c:      	movq	%rbx, %rdx
   13c8f:      	callq	*%rax
   13c91:      	addq	$0x20, %r12
   13c95:      	movl	$0x4, %eax
   13c9a:      	leaq	0x58(%rsp), %rdi
   13c9f:      	movl	$0x10, %ecx
   13ca4:      	movl	$0x10, %esi
   13ca9:      	movq	%r12, %rdx
   13cac:      	callq	*%rax
   13cae:      	movq	0x28(%rsp), %rbx
   13cb3:      	movq	0x48(%rsp), %rax
   13cb8:      	movl	0x5c(%rsp), %r15d
   13cbd:      	subq	%rbx, %rax
   13cc0:      	movl	0x50(%rsp), %r12d
   13cc5:      	movl	%r15d, %edx
   13cc8:      	subl	%r12d, %edx
   13ccb:      	movl	$0x0, %ecx
   13cd0:      	cmovbl	%ecx, %edx
   13cd3:      	addq	0x60(%rsp), %rdx
   13cd8:      	xorl	%esi, %esi
   13cda:      	cmpl	%r15d, %r12d
   13cdd:      	seta	%sil
   13ce1:      	movl	%r15d, %ecx
   13ce4:      	cmovbl	%r12d, %ecx
   13ce8:      	addl	%ecx, %esi
   13cea:      	movl	%r12d, %edi
   13ced:      	subl	%esi, %edi
   13cef:      	movl	%edi, 0x50(%rsp)
   13cf3:      	subq	%rsi, %rax
   13cf6:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13cfc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13d02:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13d08:      	cmpl	%r15d, %r12d
   13d0b:      	jbe	0x13d11 <generic_rawtp_path+0x9a31>
   13d0d:      	movb	$0x2f, (%rbx,%rax)
   13d11:      	xorl	%edi, %edi
   13d13:      	cmpl	%r15d, %r12d
   13d16:      	seta	%dil
   13d1a:      	movzbl	%cl, %esi
   13d1d:      	addq	%rax, %rbx
   13d20:      	addq	%rbx, %rdi
   13d23:      	movl	$0x4, %eax
   13d28:      	callq	*%rax
   13d2a:      	movq	%rbx, 0x48(%rsp)
   13d2f:      	cmpl	%r15d, %r12d
   13d32:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13d38:      	movq	0x8(%rsp), %r12
   13d3d:      	movq	%r12, 0x30(%rsp)
   13d42:      	movq	0x38(%rsp), %rdx
   13d47:      	movq	0x40(%rsp), %r15
   13d4c:      	jmp	0x13d9f <generic_rawtp_path+0x9abf>
   13d4e:      	leaq	0x10(%r15), %rdx
   13d52:      	movl	$0x4, %eax
   13d57:      	movq	%rbp, %rdi
   13d5a:      	movl	$0x8, %esi
   13d5f:      	callq	*%rax
   13d61:      	movq	0x40(%rsp), %rax
   13d66:      	cmpq	(%rsp), %rax
   13d6a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13d70:      	addq	$0x18, %r15
   13d74:      	movl	$0x4, %eax
   13d79:      	leaq	0x30(%rsp), %rdi
   13d7e:      	movl	$0x8, %esi
   13d83:      	movq	%r15, %rdx
   13d86:      	callq	*%rax
   13d88:      	movq	(%rsp), %r15
   13d8c:      	movq	%r15, 0x40(%rsp)
   13d91:      	leaq	0x20(%r15), %rdx
   13d95:      	movq	%rdx, 0x38(%rsp)
   13d9a:      	movq	0x30(%rsp), %r12
   13d9f:      	cmpq	0x18(%rsp), %r12
   13da4:      	jne	0x13db1 <generic_rawtp_path+0x9ad1>
   13da6:      	cmpq	0x20(%rsp), %rdx
   13dab:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13db1:      	movl	$0x4, %eax
   13db6:      	leaq	0x10(%rsp), %rdi
   13dbb:      	movl	$0x8, %esi
   13dc0:      	callq	*%rax
   13dc2:      	cmpq	0x10(%rsp), %r12
   13dc7:      	je	0x13ebf <generic_rawtp_path+0x9bdf>
   13dcd:      	leaq	0x18(%r12), %rbx
   13dd2:      	movl	$0x4, %eax
   13dd7:      	movq	%rbp, %rdi
   13dda:      	movl	$0x8, %esi
   13ddf:      	movq	%rbx, %rdx
   13de2:      	callq	*%rax
   13de4:      	cmpq	%r12, (%rsp)
   13de8:      	je	0x13ebf <generic_rawtp_path+0x9bdf>
   13dee:      	movl	$0x4, %eax
   13df3:      	leaq	0x8(%rsp), %rdi
   13df8:      	movl	$0x8, %esi
   13dfd:      	movq	%rbx, %rdx
   13e00:      	callq	*%rax
   13e02:      	addq	$0x20, %r12
   13e06:      	movl	$0x4, %eax
   13e0b:      	leaq	0x58(%rsp), %rdi
   13e10:      	movl	$0x10, %ecx
   13e15:      	movl	$0x10, %esi
   13e1a:      	movq	%r12, %rdx
   13e1d:      	callq	*%rax
   13e1f:      	movq	0x28(%rsp), %rbx
   13e24:      	movq	0x48(%rsp), %rax
   13e29:      	movl	0x5c(%rsp), %r15d
   13e2e:      	subq	%rbx, %rax
   13e31:      	movl	0x50(%rsp), %r12d
   13e36:      	movl	%r15d, %edx
   13e39:      	subl	%r12d, %edx
   13e3c:      	movl	$0x0, %ecx
   13e41:      	cmovbl	%ecx, %edx
   13e44:      	addq	0x60(%rsp), %rdx
   13e49:      	xorl	%esi, %esi
   13e4b:      	cmpl	%r15d, %r12d
   13e4e:      	seta	%sil
   13e52:      	movl	%r15d, %ecx
   13e55:      	cmovbl	%r12d, %ecx
   13e59:      	addl	%ecx, %esi
   13e5b:      	movl	%r12d, %edi
   13e5e:      	subl	%esi, %edi
   13e60:      	movl	%edi, 0x50(%rsp)
   13e64:      	subq	%rsi, %rax
   13e67:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13e6d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13e73:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13e79:      	cmpl	%r15d, %r12d
   13e7c:      	jbe	0x13e82 <generic_rawtp_path+0x9ba2>
   13e7e:      	movb	$0x2f, (%rbx,%rax)
   13e82:      	xorl	%edi, %edi
   13e84:      	cmpl	%r15d, %r12d
   13e87:      	seta	%dil
   13e8b:      	movzbl	%cl, %esi
   13e8e:      	addq	%rax, %rbx
   13e91:      	addq	%rbx, %rdi
   13e94:      	movl	$0x4, %eax
   13e99:      	callq	*%rax
   13e9b:      	movq	%rbx, 0x48(%rsp)
   13ea0:      	cmpl	%r15d, %r12d
   13ea3:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   13ea9:      	movq	0x8(%rsp), %r12
   13eae:      	movq	%r12, 0x30(%rsp)
   13eb3:      	movq	0x38(%rsp), %rdx
   13eb8:      	movq	0x40(%rsp), %r15
   13ebd:      	jmp	0x13f10 <generic_rawtp_path+0x9c30>
   13ebf:      	leaq	0x10(%r15), %rdx
   13ec3:      	movl	$0x4, %eax
   13ec8:      	movq	%rbp, %rdi
   13ecb:      	movl	$0x8, %esi
   13ed0:      	callq	*%rax
   13ed2:      	movq	0x40(%rsp), %rax
   13ed7:      	cmpq	(%rsp), %rax
   13edb:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13ee1:      	addq	$0x18, %r15
   13ee5:      	movl	$0x4, %eax
   13eea:      	leaq	0x30(%rsp), %rdi
   13eef:      	movl	$0x8, %esi
   13ef4:      	movq	%r15, %rdx
   13ef7:      	callq	*%rax
   13ef9:      	movq	(%rsp), %r15
   13efd:      	movq	%r15, 0x40(%rsp)
   13f02:      	leaq	0x20(%r15), %rdx
   13f06:      	movq	%rdx, 0x38(%rsp)
   13f0b:      	movq	0x30(%rsp), %r12
   13f10:      	cmpq	0x18(%rsp), %r12
   13f15:      	jne	0x13f22 <generic_rawtp_path+0x9c42>
   13f17:      	cmpq	0x20(%rsp), %rdx
   13f1c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   13f22:      	movl	$0x4, %eax
   13f27:      	leaq	0x10(%rsp), %rdi
   13f2c:      	movl	$0x8, %esi
   13f31:      	callq	*%rax
   13f33:      	cmpq	0x10(%rsp), %r12
   13f38:      	je	0x14030 <generic_rawtp_path+0x9d50>
   13f3e:      	leaq	0x18(%r12), %rbx
   13f43:      	movl	$0x4, %eax
   13f48:      	movq	%rbp, %rdi
   13f4b:      	movl	$0x8, %esi
   13f50:      	movq	%rbx, %rdx
   13f53:      	callq	*%rax
   13f55:      	cmpq	%r12, (%rsp)
   13f59:      	je	0x14030 <generic_rawtp_path+0x9d50>
   13f5f:      	movl	$0x4, %eax
   13f64:      	leaq	0x8(%rsp), %rdi
   13f69:      	movl	$0x8, %esi
   13f6e:      	movq	%rbx, %rdx
   13f71:      	callq	*%rax
   13f73:      	addq	$0x20, %r12
   13f77:      	movl	$0x4, %eax
   13f7c:      	leaq	0x58(%rsp), %rdi
   13f81:      	movl	$0x10, %ecx
   13f86:      	movl	$0x10, %esi
   13f8b:      	movq	%r12, %rdx
   13f8e:      	callq	*%rax
   13f90:      	movq	0x28(%rsp), %rbx
   13f95:      	movq	0x48(%rsp), %rax
   13f9a:      	movl	0x5c(%rsp), %r15d
   13f9f:      	subq	%rbx, %rax
   13fa2:      	movl	0x50(%rsp), %r12d
   13fa7:      	movl	%r15d, %edx
   13faa:      	subl	%r12d, %edx
   13fad:      	movl	$0x0, %ecx
   13fb2:      	cmovbl	%ecx, %edx
   13fb5:      	addq	0x60(%rsp), %rdx
   13fba:      	xorl	%esi, %esi
   13fbc:      	cmpl	%r15d, %r12d
   13fbf:      	seta	%sil
   13fc3:      	movl	%r15d, %ecx
   13fc6:      	cmovbl	%r12d, %ecx
   13fca:      	addl	%ecx, %esi
   13fcc:      	movl	%r12d, %edi
   13fcf:      	subl	%esi, %edi
   13fd1:      	movl	%edi, 0x50(%rsp)
   13fd5:      	subq	%rsi, %rax
   13fd8:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   13fde:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13fe4:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   13fea:      	cmpl	%r15d, %r12d
   13fed:      	jbe	0x13ff3 <generic_rawtp_path+0x9d13>
   13fef:      	movb	$0x2f, (%rbx,%rax)
   13ff3:      	xorl	%edi, %edi
   13ff5:      	cmpl	%r15d, %r12d
   13ff8:      	seta	%dil
   13ffc:      	movzbl	%cl, %esi
   13fff:      	addq	%rax, %rbx
   14002:      	addq	%rbx, %rdi
   14005:      	movl	$0x4, %eax
   1400a:      	callq	*%rax
   1400c:      	movq	%rbx, 0x48(%rsp)
   14011:      	cmpl	%r15d, %r12d
   14014:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1401a:      	movq	0x8(%rsp), %r12
   1401f:      	movq	%r12, 0x30(%rsp)
   14024:      	movq	0x38(%rsp), %rdx
   14029:      	movq	0x40(%rsp), %r15
   1402e:      	jmp	0x14081 <generic_rawtp_path+0x9da1>
   14030:      	leaq	0x10(%r15), %rdx
   14034:      	movl	$0x4, %eax
   14039:      	movq	%rbp, %rdi
   1403c:      	movl	$0x8, %esi
   14041:      	callq	*%rax
   14043:      	movq	0x40(%rsp), %rax
   14048:      	cmpq	(%rsp), %rax
   1404c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14052:      	addq	$0x18, %r15
   14056:      	movl	$0x4, %eax
   1405b:      	leaq	0x30(%rsp), %rdi
   14060:      	movl	$0x8, %esi
   14065:      	movq	%r15, %rdx
   14068:      	callq	*%rax
   1406a:      	movq	(%rsp), %r15
   1406e:      	movq	%r15, 0x40(%rsp)
   14073:      	leaq	0x20(%r15), %rdx
   14077:      	movq	%rdx, 0x38(%rsp)
   1407c:      	movq	0x30(%rsp), %r12
   14081:      	cmpq	0x18(%rsp), %r12
   14086:      	jne	0x14093 <generic_rawtp_path+0x9db3>
   14088:      	cmpq	0x20(%rsp), %rdx
   1408d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14093:      	movl	$0x4, %eax
   14098:      	leaq	0x10(%rsp), %rdi
   1409d:      	movl	$0x8, %esi
   140a2:      	callq	*%rax
   140a4:      	cmpq	0x10(%rsp), %r12
   140a9:      	je	0x141a1 <generic_rawtp_path+0x9ec1>
   140af:      	leaq	0x18(%r12), %rbx
   140b4:      	movl	$0x4, %eax
   140b9:      	movq	%rbp, %rdi
   140bc:      	movl	$0x8, %esi
   140c1:      	movq	%rbx, %rdx
   140c4:      	callq	*%rax
   140c6:      	cmpq	%r12, (%rsp)
   140ca:      	je	0x141a1 <generic_rawtp_path+0x9ec1>
   140d0:      	movl	$0x4, %eax
   140d5:      	leaq	0x8(%rsp), %rdi
   140da:      	movl	$0x8, %esi
   140df:      	movq	%rbx, %rdx
   140e2:      	callq	*%rax
   140e4:      	addq	$0x20, %r12
   140e8:      	movl	$0x4, %eax
   140ed:      	leaq	0x58(%rsp), %rdi
   140f2:      	movl	$0x10, %ecx
   140f7:      	movl	$0x10, %esi
   140fc:      	movq	%r12, %rdx
   140ff:      	callq	*%rax
   14101:      	movq	0x28(%rsp), %rbx
   14106:      	movq	0x48(%rsp), %rax
   1410b:      	movl	0x5c(%rsp), %r15d
   14110:      	subq	%rbx, %rax
   14113:      	movl	0x50(%rsp), %r12d
   14118:      	movl	%r15d, %edx
   1411b:      	subl	%r12d, %edx
   1411e:      	movl	$0x0, %ecx
   14123:      	cmovbl	%ecx, %edx
   14126:      	addq	0x60(%rsp), %rdx
   1412b:      	xorl	%esi, %esi
   1412d:      	cmpl	%r15d, %r12d
   14130:      	seta	%sil
   14134:      	movl	%r15d, %ecx
   14137:      	cmovbl	%r12d, %ecx
   1413b:      	addl	%ecx, %esi
   1413d:      	movl	%r12d, %edi
   14140:      	subl	%esi, %edi
   14142:      	movl	%edi, 0x50(%rsp)
   14146:      	subq	%rsi, %rax
   14149:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1414f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14155:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1415b:      	cmpl	%r15d, %r12d
   1415e:      	jbe	0x14164 <generic_rawtp_path+0x9e84>
   14160:      	movb	$0x2f, (%rbx,%rax)
   14164:      	xorl	%edi, %edi
   14166:      	cmpl	%r15d, %r12d
   14169:      	seta	%dil
   1416d:      	movzbl	%cl, %esi
   14170:      	addq	%rax, %rbx
   14173:      	addq	%rbx, %rdi
   14176:      	movl	$0x4, %eax
   1417b:      	callq	*%rax
   1417d:      	movq	%rbx, 0x48(%rsp)
   14182:      	cmpl	%r15d, %r12d
   14185:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1418b:      	movq	0x8(%rsp), %r12
   14190:      	movq	%r12, 0x30(%rsp)
   14195:      	movq	0x38(%rsp), %rdx
   1419a:      	movq	0x40(%rsp), %r15
   1419f:      	jmp	0x141f2 <generic_rawtp_path+0x9f12>
   141a1:      	leaq	0x10(%r15), %rdx
   141a5:      	movl	$0x4, %eax
   141aa:      	movq	%rbp, %rdi
   141ad:      	movl	$0x8, %esi
   141b2:      	callq	*%rax
   141b4:      	movq	0x40(%rsp), %rax
   141b9:      	cmpq	(%rsp), %rax
   141bd:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   141c3:      	addq	$0x18, %r15
   141c7:      	movl	$0x4, %eax
   141cc:      	leaq	0x30(%rsp), %rdi
   141d1:      	movl	$0x8, %esi
   141d6:      	movq	%r15, %rdx
   141d9:      	callq	*%rax
   141db:      	movq	(%rsp), %r15
   141df:      	movq	%r15, 0x40(%rsp)
   141e4:      	leaq	0x20(%r15), %rdx
   141e8:      	movq	%rdx, 0x38(%rsp)
   141ed:      	movq	0x30(%rsp), %r12
   141f2:      	cmpq	0x18(%rsp), %r12
   141f7:      	jne	0x14204 <generic_rawtp_path+0x9f24>
   141f9:      	cmpq	0x20(%rsp), %rdx
   141fe:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14204:      	movl	$0x4, %eax
   14209:      	leaq	0x10(%rsp), %rdi
   1420e:      	movl	$0x8, %esi
   14213:      	callq	*%rax
   14215:      	cmpq	0x10(%rsp), %r12
   1421a:      	je	0x14312 <generic_rawtp_path+0xa032>
   14220:      	leaq	0x18(%r12), %rbx
   14225:      	movl	$0x4, %eax
   1422a:      	movq	%rbp, %rdi
   1422d:      	movl	$0x8, %esi
   14232:      	movq	%rbx, %rdx
   14235:      	callq	*%rax
   14237:      	cmpq	%r12, (%rsp)
   1423b:      	je	0x14312 <generic_rawtp_path+0xa032>
   14241:      	movl	$0x4, %eax
   14246:      	leaq	0x8(%rsp), %rdi
   1424b:      	movl	$0x8, %esi
   14250:      	movq	%rbx, %rdx
   14253:      	callq	*%rax
   14255:      	addq	$0x20, %r12
   14259:      	movl	$0x4, %eax
   1425e:      	leaq	0x58(%rsp), %rdi
   14263:      	movl	$0x10, %ecx
   14268:      	movl	$0x10, %esi
   1426d:      	movq	%r12, %rdx
   14270:      	callq	*%rax
   14272:      	movq	0x28(%rsp), %rbx
   14277:      	movq	0x48(%rsp), %rax
   1427c:      	movl	0x5c(%rsp), %r15d
   14281:      	subq	%rbx, %rax
   14284:      	movl	0x50(%rsp), %r12d
   14289:      	movl	%r15d, %edx
   1428c:      	subl	%r12d, %edx
   1428f:      	movl	$0x0, %ecx
   14294:      	cmovbl	%ecx, %edx
   14297:      	addq	0x60(%rsp), %rdx
   1429c:      	xorl	%esi, %esi
   1429e:      	cmpl	%r15d, %r12d
   142a1:      	seta	%sil
   142a5:      	movl	%r15d, %ecx
   142a8:      	cmovbl	%r12d, %ecx
   142ac:      	addl	%ecx, %esi
   142ae:      	movl	%r12d, %edi
   142b1:      	subl	%esi, %edi
   142b3:      	movl	%edi, 0x50(%rsp)
   142b7:      	subq	%rsi, %rax
   142ba:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   142c0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   142c6:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   142cc:      	cmpl	%r15d, %r12d
   142cf:      	jbe	0x142d5 <generic_rawtp_path+0x9ff5>
   142d1:      	movb	$0x2f, (%rbx,%rax)
   142d5:      	xorl	%edi, %edi
   142d7:      	cmpl	%r15d, %r12d
   142da:      	seta	%dil
   142de:      	movzbl	%cl, %esi
   142e1:      	addq	%rax, %rbx
   142e4:      	addq	%rbx, %rdi
   142e7:      	movl	$0x4, %eax
   142ec:      	callq	*%rax
   142ee:      	movq	%rbx, 0x48(%rsp)
   142f3:      	cmpl	%r15d, %r12d
   142f6:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   142fc:      	movq	0x8(%rsp), %r12
   14301:      	movq	%r12, 0x30(%rsp)
   14306:      	movq	0x38(%rsp), %rdx
   1430b:      	movq	0x40(%rsp), %r15
   14310:      	jmp	0x14363 <generic_rawtp_path+0xa083>
   14312:      	leaq	0x10(%r15), %rdx
   14316:      	movl	$0x4, %eax
   1431b:      	movq	%rbp, %rdi
   1431e:      	movl	$0x8, %esi
   14323:      	callq	*%rax
   14325:      	movq	0x40(%rsp), %rax
   1432a:      	cmpq	(%rsp), %rax
   1432e:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14334:      	addq	$0x18, %r15
   14338:      	movl	$0x4, %eax
   1433d:      	leaq	0x30(%rsp), %rdi
   14342:      	movl	$0x8, %esi
   14347:      	movq	%r15, %rdx
   1434a:      	callq	*%rax
   1434c:      	movq	(%rsp), %r15
   14350:      	movq	%r15, 0x40(%rsp)
   14355:      	leaq	0x20(%r15), %rdx
   14359:      	movq	%rdx, 0x38(%rsp)
   1435e:      	movq	0x30(%rsp), %r12
   14363:      	cmpq	0x18(%rsp), %r12
   14368:      	jne	0x14375 <generic_rawtp_path+0xa095>
   1436a:      	cmpq	0x20(%rsp), %rdx
   1436f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14375:      	movl	$0x4, %eax
   1437a:      	leaq	0x10(%rsp), %rdi
   1437f:      	movl	$0x8, %esi
   14384:      	callq	*%rax
   14386:      	cmpq	0x10(%rsp), %r12
   1438b:      	je	0x14483 <generic_rawtp_path+0xa1a3>
   14391:      	leaq	0x18(%r12), %rbx
   14396:      	movl	$0x4, %eax
   1439b:      	movq	%rbp, %rdi
   1439e:      	movl	$0x8, %esi
   143a3:      	movq	%rbx, %rdx
   143a6:      	callq	*%rax
   143a8:      	cmpq	%r12, (%rsp)
   143ac:      	je	0x14483 <generic_rawtp_path+0xa1a3>
   143b2:      	movl	$0x4, %eax
   143b7:      	leaq	0x8(%rsp), %rdi
   143bc:      	movl	$0x8, %esi
   143c1:      	movq	%rbx, %rdx
   143c4:      	callq	*%rax
   143c6:      	addq	$0x20, %r12
   143ca:      	movl	$0x4, %eax
   143cf:      	leaq	0x58(%rsp), %rdi
   143d4:      	movl	$0x10, %ecx
   143d9:      	movl	$0x10, %esi
   143de:      	movq	%r12, %rdx
   143e1:      	callq	*%rax
   143e3:      	movq	0x28(%rsp), %rbx
   143e8:      	movq	0x48(%rsp), %rax
   143ed:      	movl	0x5c(%rsp), %r15d
   143f2:      	subq	%rbx, %rax
   143f5:      	movl	0x50(%rsp), %r12d
   143fa:      	movl	%r15d, %edx
   143fd:      	subl	%r12d, %edx
   14400:      	movl	$0x0, %ecx
   14405:      	cmovbl	%ecx, %edx
   14408:      	addq	0x60(%rsp), %rdx
   1440d:      	xorl	%esi, %esi
   1440f:      	cmpl	%r15d, %r12d
   14412:      	seta	%sil
   14416:      	movl	%r15d, %ecx
   14419:      	cmovbl	%r12d, %ecx
   1441d:      	addl	%ecx, %esi
   1441f:      	movl	%r12d, %edi
   14422:      	subl	%esi, %edi
   14424:      	movl	%edi, 0x50(%rsp)
   14428:      	subq	%rsi, %rax
   1442b:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14431:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14437:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1443d:      	cmpl	%r15d, %r12d
   14440:      	jbe	0x14446 <generic_rawtp_path+0xa166>
   14442:      	movb	$0x2f, (%rbx,%rax)
   14446:      	xorl	%edi, %edi
   14448:      	cmpl	%r15d, %r12d
   1444b:      	seta	%dil
   1444f:      	movzbl	%cl, %esi
   14452:      	addq	%rax, %rbx
   14455:      	addq	%rbx, %rdi
   14458:      	movl	$0x4, %eax
   1445d:      	callq	*%rax
   1445f:      	movq	%rbx, 0x48(%rsp)
   14464:      	cmpl	%r15d, %r12d
   14467:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1446d:      	movq	0x8(%rsp), %r12
   14472:      	movq	%r12, 0x30(%rsp)
   14477:      	movq	0x38(%rsp), %rdx
   1447c:      	movq	0x40(%rsp), %r15
   14481:      	jmp	0x144d4 <generic_rawtp_path+0xa1f4>
   14483:      	leaq	0x10(%r15), %rdx
   14487:      	movl	$0x4, %eax
   1448c:      	movq	%rbp, %rdi
   1448f:      	movl	$0x8, %esi
   14494:      	callq	*%rax
   14496:      	movq	0x40(%rsp), %rax
   1449b:      	cmpq	(%rsp), %rax
   1449f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   144a5:      	addq	$0x18, %r15
   144a9:      	movl	$0x4, %eax
   144ae:      	leaq	0x30(%rsp), %rdi
   144b3:      	movl	$0x8, %esi
   144b8:      	movq	%r15, %rdx
   144bb:      	callq	*%rax
   144bd:      	movq	(%rsp), %r15
   144c1:      	movq	%r15, 0x40(%rsp)
   144c6:      	leaq	0x20(%r15), %rdx
   144ca:      	movq	%rdx, 0x38(%rsp)
   144cf:      	movq	0x30(%rsp), %r12
   144d4:      	cmpq	0x18(%rsp), %r12
   144d9:      	jne	0x144e6 <generic_rawtp_path+0xa206>
   144db:      	cmpq	0x20(%rsp), %rdx
   144e0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   144e6:      	movl	$0x4, %eax
   144eb:      	leaq	0x10(%rsp), %rdi
   144f0:      	movl	$0x8, %esi
   144f5:      	callq	*%rax
   144f7:      	cmpq	0x10(%rsp), %r12
   144fc:      	je	0x145f4 <generic_rawtp_path+0xa314>
   14502:      	leaq	0x18(%r12), %rbx
   14507:      	movl	$0x4, %eax
   1450c:      	movq	%rbp, %rdi
   1450f:      	movl	$0x8, %esi
   14514:      	movq	%rbx, %rdx
   14517:      	callq	*%rax
   14519:      	cmpq	%r12, (%rsp)
   1451d:      	je	0x145f4 <generic_rawtp_path+0xa314>
   14523:      	movl	$0x4, %eax
   14528:      	leaq	0x8(%rsp), %rdi
   1452d:      	movl	$0x8, %esi
   14532:      	movq	%rbx, %rdx
   14535:      	callq	*%rax
   14537:      	addq	$0x20, %r12
   1453b:      	movl	$0x4, %eax
   14540:      	leaq	0x58(%rsp), %rdi
   14545:      	movl	$0x10, %ecx
   1454a:      	movl	$0x10, %esi
   1454f:      	movq	%r12, %rdx
   14552:      	callq	*%rax
   14554:      	movq	0x28(%rsp), %rbx
   14559:      	movq	0x48(%rsp), %rax
   1455e:      	movl	0x5c(%rsp), %r15d
   14563:      	subq	%rbx, %rax
   14566:      	movl	0x50(%rsp), %r12d
   1456b:      	movl	%r15d, %edx
   1456e:      	subl	%r12d, %edx
   14571:      	movl	$0x0, %ecx
   14576:      	cmovbl	%ecx, %edx
   14579:      	addq	0x60(%rsp), %rdx
   1457e:      	xorl	%esi, %esi
   14580:      	cmpl	%r15d, %r12d
   14583:      	seta	%sil
   14587:      	movl	%r15d, %ecx
   1458a:      	cmovbl	%r12d, %ecx
   1458e:      	addl	%ecx, %esi
   14590:      	movl	%r12d, %edi
   14593:      	subl	%esi, %edi
   14595:      	movl	%edi, 0x50(%rsp)
   14599:      	subq	%rsi, %rax
   1459c:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   145a2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   145a8:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   145ae:      	cmpl	%r15d, %r12d
   145b1:      	jbe	0x145b7 <generic_rawtp_path+0xa2d7>
   145b3:      	movb	$0x2f, (%rbx,%rax)
   145b7:      	xorl	%edi, %edi
   145b9:      	cmpl	%r15d, %r12d
   145bc:      	seta	%dil
   145c0:      	movzbl	%cl, %esi
   145c3:      	addq	%rax, %rbx
   145c6:      	addq	%rbx, %rdi
   145c9:      	movl	$0x4, %eax
   145ce:      	callq	*%rax
   145d0:      	movq	%rbx, 0x48(%rsp)
   145d5:      	cmpl	%r15d, %r12d
   145d8:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   145de:      	movq	0x8(%rsp), %r12
   145e3:      	movq	%r12, 0x30(%rsp)
   145e8:      	movq	0x38(%rsp), %rdx
   145ed:      	movq	0x40(%rsp), %r15
   145f2:      	jmp	0x14645 <generic_rawtp_path+0xa365>
   145f4:      	leaq	0x10(%r15), %rdx
   145f8:      	movl	$0x4, %eax
   145fd:      	movq	%rbp, %rdi
   14600:      	movl	$0x8, %esi
   14605:      	callq	*%rax
   14607:      	movq	0x40(%rsp), %rax
   1460c:      	cmpq	(%rsp), %rax
   14610:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14616:      	addq	$0x18, %r15
   1461a:      	movl	$0x4, %eax
   1461f:      	leaq	0x30(%rsp), %rdi
   14624:      	movl	$0x8, %esi
   14629:      	movq	%r15, %rdx
   1462c:      	callq	*%rax
   1462e:      	movq	(%rsp), %r15
   14632:      	movq	%r15, 0x40(%rsp)
   14637:      	leaq	0x20(%r15), %rdx
   1463b:      	movq	%rdx, 0x38(%rsp)
   14640:      	movq	0x30(%rsp), %r12
   14645:      	cmpq	0x18(%rsp), %r12
   1464a:      	jne	0x14657 <generic_rawtp_path+0xa377>
   1464c:      	cmpq	0x20(%rsp), %rdx
   14651:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14657:      	movl	$0x4, %eax
   1465c:      	leaq	0x10(%rsp), %rdi
   14661:      	movl	$0x8, %esi
   14666:      	callq	*%rax
   14668:      	cmpq	0x10(%rsp), %r12
   1466d:      	je	0x14765 <generic_rawtp_path+0xa485>
   14673:      	leaq	0x18(%r12), %rbx
   14678:      	movl	$0x4, %eax
   1467d:      	movq	%rbp, %rdi
   14680:      	movl	$0x8, %esi
   14685:      	movq	%rbx, %rdx
   14688:      	callq	*%rax
   1468a:      	cmpq	%r12, (%rsp)
   1468e:      	je	0x14765 <generic_rawtp_path+0xa485>
   14694:      	movl	$0x4, %eax
   14699:      	leaq	0x8(%rsp), %rdi
   1469e:      	movl	$0x8, %esi
   146a3:      	movq	%rbx, %rdx
   146a6:      	callq	*%rax
   146a8:      	addq	$0x20, %r12
   146ac:      	movl	$0x4, %eax
   146b1:      	leaq	0x58(%rsp), %rdi
   146b6:      	movl	$0x10, %ecx
   146bb:      	movl	$0x10, %esi
   146c0:      	movq	%r12, %rdx
   146c3:      	callq	*%rax
   146c5:      	movq	0x28(%rsp), %rbx
   146ca:      	movq	0x48(%rsp), %rax
   146cf:      	movl	0x5c(%rsp), %r15d
   146d4:      	subq	%rbx, %rax
   146d7:      	movl	0x50(%rsp), %r12d
   146dc:      	movl	%r15d, %edx
   146df:      	subl	%r12d, %edx
   146e2:      	movl	$0x0, %ecx
   146e7:      	cmovbl	%ecx, %edx
   146ea:      	addq	0x60(%rsp), %rdx
   146ef:      	xorl	%esi, %esi
   146f1:      	cmpl	%r15d, %r12d
   146f4:      	seta	%sil
   146f8:      	movl	%r15d, %ecx
   146fb:      	cmovbl	%r12d, %ecx
   146ff:      	addl	%ecx, %esi
   14701:      	movl	%r12d, %edi
   14704:      	subl	%esi, %edi
   14706:      	movl	%edi, 0x50(%rsp)
   1470a:      	subq	%rsi, %rax
   1470d:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14713:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14719:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1471f:      	cmpl	%r15d, %r12d
   14722:      	jbe	0x14728 <generic_rawtp_path+0xa448>
   14724:      	movb	$0x2f, (%rbx,%rax)
   14728:      	xorl	%edi, %edi
   1472a:      	cmpl	%r15d, %r12d
   1472d:      	seta	%dil
   14731:      	movzbl	%cl, %esi
   14734:      	addq	%rax, %rbx
   14737:      	addq	%rbx, %rdi
   1473a:      	movl	$0x4, %eax
   1473f:      	callq	*%rax
   14741:      	movq	%rbx, 0x48(%rsp)
   14746:      	cmpl	%r15d, %r12d
   14749:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1474f:      	movq	0x8(%rsp), %r12
   14754:      	movq	%r12, 0x30(%rsp)
   14759:      	movq	0x38(%rsp), %rdx
   1475e:      	movq	0x40(%rsp), %r15
   14763:      	jmp	0x147b6 <generic_rawtp_path+0xa4d6>
   14765:      	leaq	0x10(%r15), %rdx
   14769:      	movl	$0x4, %eax
   1476e:      	movq	%rbp, %rdi
   14771:      	movl	$0x8, %esi
   14776:      	callq	*%rax
   14778:      	movq	0x40(%rsp), %rax
   1477d:      	cmpq	(%rsp), %rax
   14781:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14787:      	addq	$0x18, %r15
   1478b:      	movl	$0x4, %eax
   14790:      	leaq	0x30(%rsp), %rdi
   14795:      	movl	$0x8, %esi
   1479a:      	movq	%r15, %rdx
   1479d:      	callq	*%rax
   1479f:      	movq	(%rsp), %r15
   147a3:      	movq	%r15, 0x40(%rsp)
   147a8:      	leaq	0x20(%r15), %rdx
   147ac:      	movq	%rdx, 0x38(%rsp)
   147b1:      	movq	0x30(%rsp), %r12
   147b6:      	cmpq	0x18(%rsp), %r12
   147bb:      	jne	0x147c8 <generic_rawtp_path+0xa4e8>
   147bd:      	cmpq	0x20(%rsp), %rdx
   147c2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   147c8:      	movl	$0x4, %eax
   147cd:      	leaq	0x10(%rsp), %rdi
   147d2:      	movl	$0x8, %esi
   147d7:      	callq	*%rax
   147d9:      	cmpq	0x10(%rsp), %r12
   147de:      	je	0x148d6 <generic_rawtp_path+0xa5f6>
   147e4:      	leaq	0x18(%r12), %rbx
   147e9:      	movl	$0x4, %eax
   147ee:      	movq	%rbp, %rdi
   147f1:      	movl	$0x8, %esi
   147f6:      	movq	%rbx, %rdx
   147f9:      	callq	*%rax
   147fb:      	cmpq	%r12, (%rsp)
   147ff:      	je	0x148d6 <generic_rawtp_path+0xa5f6>
   14805:      	movl	$0x4, %eax
   1480a:      	leaq	0x8(%rsp), %rdi
   1480f:      	movl	$0x8, %esi
   14814:      	movq	%rbx, %rdx
   14817:      	callq	*%rax
   14819:      	addq	$0x20, %r12
   1481d:      	movl	$0x4, %eax
   14822:      	leaq	0x58(%rsp), %rdi
   14827:      	movl	$0x10, %ecx
   1482c:      	movl	$0x10, %esi
   14831:      	movq	%r12, %rdx
   14834:      	callq	*%rax
   14836:      	movq	0x28(%rsp), %rbx
   1483b:      	movq	0x48(%rsp), %rax
   14840:      	movl	0x5c(%rsp), %r15d
   14845:      	subq	%rbx, %rax
   14848:      	movl	0x50(%rsp), %r12d
   1484d:      	movl	%r15d, %edx
   14850:      	subl	%r12d, %edx
   14853:      	movl	$0x0, %ecx
   14858:      	cmovbl	%ecx, %edx
   1485b:      	addq	0x60(%rsp), %rdx
   14860:      	xorl	%esi, %esi
   14862:      	cmpl	%r15d, %r12d
   14865:      	seta	%sil
   14869:      	movl	%r15d, %ecx
   1486c:      	cmovbl	%r12d, %ecx
   14870:      	addl	%ecx, %esi
   14872:      	movl	%r12d, %edi
   14875:      	subl	%esi, %edi
   14877:      	movl	%edi, 0x50(%rsp)
   1487b:      	subq	%rsi, %rax
   1487e:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14884:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1488a:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   14890:      	cmpl	%r15d, %r12d
   14893:      	jbe	0x14899 <generic_rawtp_path+0xa5b9>
   14895:      	movb	$0x2f, (%rbx,%rax)
   14899:      	xorl	%edi, %edi
   1489b:      	cmpl	%r15d, %r12d
   1489e:      	seta	%dil
   148a2:      	movzbl	%cl, %esi
   148a5:      	addq	%rax, %rbx
   148a8:      	addq	%rbx, %rdi
   148ab:      	movl	$0x4, %eax
   148b0:      	callq	*%rax
   148b2:      	movq	%rbx, 0x48(%rsp)
   148b7:      	cmpl	%r15d, %r12d
   148ba:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   148c0:      	movq	0x8(%rsp), %r12
   148c5:      	movq	%r12, 0x30(%rsp)
   148ca:      	movq	0x38(%rsp), %rdx
   148cf:      	movq	0x40(%rsp), %r15
   148d4:      	jmp	0x14927 <generic_rawtp_path+0xa647>
   148d6:      	leaq	0x10(%r15), %rdx
   148da:      	movl	$0x4, %eax
   148df:      	movq	%rbp, %rdi
   148e2:      	movl	$0x8, %esi
   148e7:      	callq	*%rax
   148e9:      	movq	0x40(%rsp), %rax
   148ee:      	cmpq	(%rsp), %rax
   148f2:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   148f8:      	addq	$0x18, %r15
   148fc:      	movl	$0x4, %eax
   14901:      	leaq	0x30(%rsp), %rdi
   14906:      	movl	$0x8, %esi
   1490b:      	movq	%r15, %rdx
   1490e:      	callq	*%rax
   14910:      	movq	(%rsp), %r15
   14914:      	movq	%r15, 0x40(%rsp)
   14919:      	leaq	0x20(%r15), %rdx
   1491d:      	movq	%rdx, 0x38(%rsp)
   14922:      	movq	0x30(%rsp), %r12
   14927:      	cmpq	0x18(%rsp), %r12
   1492c:      	jne	0x14939 <generic_rawtp_path+0xa659>
   1492e:      	cmpq	0x20(%rsp), %rdx
   14933:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14939:      	movl	$0x4, %eax
   1493e:      	leaq	0x10(%rsp), %rdi
   14943:      	movl	$0x8, %esi
   14948:      	callq	*%rax
   1494a:      	cmpq	0x10(%rsp), %r12
   1494f:      	je	0x14a47 <generic_rawtp_path+0xa767>
   14955:      	leaq	0x18(%r12), %rbx
   1495a:      	movl	$0x4, %eax
   1495f:      	movq	%rbp, %rdi
   14962:      	movl	$0x8, %esi
   14967:      	movq	%rbx, %rdx
   1496a:      	callq	*%rax
   1496c:      	cmpq	%r12, (%rsp)
   14970:      	je	0x14a47 <generic_rawtp_path+0xa767>
   14976:      	movl	$0x4, %eax
   1497b:      	leaq	0x8(%rsp), %rdi
   14980:      	movl	$0x8, %esi
   14985:      	movq	%rbx, %rdx
   14988:      	callq	*%rax
   1498a:      	addq	$0x20, %r12
   1498e:      	movl	$0x4, %eax
   14993:      	leaq	0x58(%rsp), %rdi
   14998:      	movl	$0x10, %ecx
   1499d:      	movl	$0x10, %esi
   149a2:      	movq	%r12, %rdx
   149a5:      	callq	*%rax
   149a7:      	movq	0x28(%rsp), %rbx
   149ac:      	movq	0x48(%rsp), %rax
   149b1:      	movl	0x5c(%rsp), %r15d
   149b6:      	subq	%rbx, %rax
   149b9:      	movl	0x50(%rsp), %r12d
   149be:      	movl	%r15d, %edx
   149c1:      	subl	%r12d, %edx
   149c4:      	movl	$0x0, %ecx
   149c9:      	cmovbl	%ecx, %edx
   149cc:      	addq	0x60(%rsp), %rdx
   149d1:      	xorl	%esi, %esi
   149d3:      	cmpl	%r15d, %r12d
   149d6:      	seta	%sil
   149da:      	movl	%r15d, %ecx
   149dd:      	cmovbl	%r12d, %ecx
   149e1:      	addl	%ecx, %esi
   149e3:      	movl	%r12d, %edi
   149e6:      	subl	%esi, %edi
   149e8:      	movl	%edi, 0x50(%rsp)
   149ec:      	subq	%rsi, %rax
   149ef:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   149f5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   149fb:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   14a01:      	cmpl	%r15d, %r12d
   14a04:      	jbe	0x14a0a <generic_rawtp_path+0xa72a>
   14a06:      	movb	$0x2f, (%rbx,%rax)
   14a0a:      	xorl	%edi, %edi
   14a0c:      	cmpl	%r15d, %r12d
   14a0f:      	seta	%dil
   14a13:      	movzbl	%cl, %esi
   14a16:      	addq	%rax, %rbx
   14a19:      	addq	%rbx, %rdi
   14a1c:      	movl	$0x4, %eax
   14a21:      	callq	*%rax
   14a23:      	movq	%rbx, 0x48(%rsp)
   14a28:      	cmpl	%r15d, %r12d
   14a2b:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   14a31:      	movq	0x8(%rsp), %r12
   14a36:      	movq	%r12, 0x30(%rsp)
   14a3b:      	movq	0x38(%rsp), %rdx
   14a40:      	movq	0x40(%rsp), %r15
   14a45:      	jmp	0x14a98 <generic_rawtp_path+0xa7b8>
   14a47:      	leaq	0x10(%r15), %rdx
   14a4b:      	movl	$0x4, %eax
   14a50:      	movq	%rbp, %rdi
   14a53:      	movl	$0x8, %esi
   14a58:      	callq	*%rax
   14a5a:      	movq	0x40(%rsp), %rax
   14a5f:      	cmpq	(%rsp), %rax
   14a63:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14a69:      	addq	$0x18, %r15
   14a6d:      	movl	$0x4, %eax
   14a72:      	leaq	0x30(%rsp), %rdi
   14a77:      	movl	$0x8, %esi
   14a7c:      	movq	%r15, %rdx
   14a7f:      	callq	*%rax
   14a81:      	movq	(%rsp), %r15
   14a85:      	movq	%r15, 0x40(%rsp)
   14a8a:      	leaq	0x20(%r15), %rdx
   14a8e:      	movq	%rdx, 0x38(%rsp)
   14a93:      	movq	0x30(%rsp), %r12
   14a98:      	cmpq	0x18(%rsp), %r12
   14a9d:      	jne	0x14aaa <generic_rawtp_path+0xa7ca>
   14a9f:      	cmpq	0x20(%rsp), %rdx
   14aa4:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14aaa:      	movl	$0x4, %eax
   14aaf:      	leaq	0x10(%rsp), %rdi
   14ab4:      	movl	$0x8, %esi
   14ab9:      	callq	*%rax
   14abb:      	cmpq	0x10(%rsp), %r12
   14ac0:      	je	0x14bb8 <generic_rawtp_path+0xa8d8>
   14ac6:      	leaq	0x18(%r12), %rbx
   14acb:      	movl	$0x4, %eax
   14ad0:      	movq	%rbp, %rdi
   14ad3:      	movl	$0x8, %esi
   14ad8:      	movq	%rbx, %rdx
   14adb:      	callq	*%rax
   14add:      	cmpq	%r12, (%rsp)
   14ae1:      	je	0x14bb8 <generic_rawtp_path+0xa8d8>
   14ae7:      	movl	$0x4, %eax
   14aec:      	leaq	0x8(%rsp), %rdi
   14af1:      	movl	$0x8, %esi
   14af6:      	movq	%rbx, %rdx
   14af9:      	callq	*%rax
   14afb:      	addq	$0x20, %r12
   14aff:      	movl	$0x4, %eax
   14b04:      	leaq	0x58(%rsp), %rdi
   14b09:      	movl	$0x10, %ecx
   14b0e:      	movl	$0x10, %esi
   14b13:      	movq	%r12, %rdx
   14b16:      	callq	*%rax
   14b18:      	movq	0x28(%rsp), %rbx
   14b1d:      	movq	0x48(%rsp), %rax
   14b22:      	movl	0x5c(%rsp), %r15d
   14b27:      	subq	%rbx, %rax
   14b2a:      	movl	0x50(%rsp), %r12d
   14b2f:      	movl	%r15d, %edx
   14b32:      	subl	%r12d, %edx
   14b35:      	movl	$0x0, %ecx
   14b3a:      	cmovbl	%ecx, %edx
   14b3d:      	addq	0x60(%rsp), %rdx
   14b42:      	xorl	%esi, %esi
   14b44:      	cmpl	%r15d, %r12d
   14b47:      	seta	%sil
   14b4b:      	movl	%r15d, %ecx
   14b4e:      	cmovbl	%r12d, %ecx
   14b52:      	addl	%ecx, %esi
   14b54:      	movl	%r12d, %edi
   14b57:      	subl	%esi, %edi
   14b59:      	movl	%edi, 0x50(%rsp)
   14b5d:      	subq	%rsi, %rax
   14b60:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14b66:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14b6c:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   14b72:      	cmpl	%r15d, %r12d
   14b75:      	jbe	0x14b7b <generic_rawtp_path+0xa89b>
   14b77:      	movb	$0x2f, (%rbx,%rax)
   14b7b:      	xorl	%edi, %edi
   14b7d:      	cmpl	%r15d, %r12d
   14b80:      	seta	%dil
   14b84:      	movzbl	%cl, %esi
   14b87:      	addq	%rax, %rbx
   14b8a:      	addq	%rbx, %rdi
   14b8d:      	movl	$0x4, %eax
   14b92:      	callq	*%rax
   14b94:      	movq	%rbx, 0x48(%rsp)
   14b99:      	cmpl	%r15d, %r12d
   14b9c:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   14ba2:      	movq	0x8(%rsp), %r12
   14ba7:      	movq	%r12, 0x30(%rsp)
   14bac:      	movq	0x38(%rsp), %rdx
   14bb1:      	movq	0x40(%rsp), %r15
   14bb6:      	jmp	0x14c09 <generic_rawtp_path+0xa929>
   14bb8:      	leaq	0x10(%r15), %rdx
   14bbc:      	movl	$0x4, %eax
   14bc1:      	movq	%rbp, %rdi
   14bc4:      	movl	$0x8, %esi
   14bc9:      	callq	*%rax
   14bcb:      	movq	0x40(%rsp), %rax
   14bd0:      	cmpq	(%rsp), %rax
   14bd4:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14bda:      	addq	$0x18, %r15
   14bde:      	movl	$0x4, %eax
   14be3:      	leaq	0x30(%rsp), %rdi
   14be8:      	movl	$0x8, %esi
   14bed:      	movq	%r15, %rdx
   14bf0:      	callq	*%rax
   14bf2:      	movq	(%rsp), %r15
   14bf6:      	movq	%r15, 0x40(%rsp)
   14bfb:      	leaq	0x20(%r15), %rdx
   14bff:      	movq	%rdx, 0x38(%rsp)
   14c04:      	movq	0x30(%rsp), %r12
   14c09:      	cmpq	0x18(%rsp), %r12
   14c0e:      	jne	0x14c1b <generic_rawtp_path+0xa93b>
   14c10:      	cmpq	0x20(%rsp), %rdx
   14c15:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14c1b:      	movl	$0x4, %eax
   14c20:      	leaq	0x10(%rsp), %rdi
   14c25:      	movl	$0x8, %esi
   14c2a:      	callq	*%rax
   14c2c:      	cmpq	0x10(%rsp), %r12
   14c31:      	je	0x14d29 <generic_rawtp_path+0xaa49>
   14c37:      	leaq	0x18(%r12), %rbx
   14c3c:      	movl	$0x4, %eax
   14c41:      	movq	%rbp, %rdi
   14c44:      	movl	$0x8, %esi
   14c49:      	movq	%rbx, %rdx
   14c4c:      	callq	*%rax
   14c4e:      	cmpq	%r12, (%rsp)
   14c52:      	je	0x14d29 <generic_rawtp_path+0xaa49>
   14c58:      	movl	$0x4, %eax
   14c5d:      	leaq	0x8(%rsp), %rdi
   14c62:      	movl	$0x8, %esi
   14c67:      	movq	%rbx, %rdx
   14c6a:      	callq	*%rax
   14c6c:      	addq	$0x20, %r12
   14c70:      	movl	$0x4, %eax
   14c75:      	leaq	0x58(%rsp), %rdi
   14c7a:      	movl	$0x10, %ecx
   14c7f:      	movl	$0x10, %esi
   14c84:      	movq	%r12, %rdx
   14c87:      	callq	*%rax
   14c89:      	movq	0x28(%rsp), %rbx
   14c8e:      	movq	0x48(%rsp), %rax
   14c93:      	movl	0x5c(%rsp), %r15d
   14c98:      	subq	%rbx, %rax
   14c9b:      	movl	0x50(%rsp), %r12d
   14ca0:      	movl	%r15d, %edx
   14ca3:      	subl	%r12d, %edx
   14ca6:      	movl	$0x0, %ecx
   14cab:      	cmovbl	%ecx, %edx
   14cae:      	addq	0x60(%rsp), %rdx
   14cb3:      	xorl	%esi, %esi
   14cb5:      	cmpl	%r15d, %r12d
   14cb8:      	seta	%sil
   14cbc:      	movl	%r15d, %ecx
   14cbf:      	cmovbl	%r12d, %ecx
   14cc3:      	addl	%ecx, %esi
   14cc5:      	movl	%r12d, %edi
   14cc8:      	subl	%esi, %edi
   14cca:      	movl	%edi, 0x50(%rsp)
   14cce:      	subq	%rsi, %rax
   14cd1:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14cd7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14cdd:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   14ce3:      	cmpl	%r15d, %r12d
   14ce6:      	jbe	0x14cec <generic_rawtp_path+0xaa0c>
   14ce8:      	movb	$0x2f, (%rbx,%rax)
   14cec:      	xorl	%edi, %edi
   14cee:      	cmpl	%r15d, %r12d
   14cf1:      	seta	%dil
   14cf5:      	movzbl	%cl, %esi
   14cf8:      	addq	%rax, %rbx
   14cfb:      	addq	%rbx, %rdi
   14cfe:      	movl	$0x4, %eax
   14d03:      	callq	*%rax
   14d05:      	movq	%rbx, 0x48(%rsp)
   14d0a:      	cmpl	%r15d, %r12d
   14d0d:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   14d13:      	movq	0x8(%rsp), %r12
   14d18:      	movq	%r12, 0x30(%rsp)
   14d1d:      	movq	0x38(%rsp), %rdx
   14d22:      	movq	0x40(%rsp), %r15
   14d27:      	jmp	0x14d7a <generic_rawtp_path+0xaa9a>
   14d29:      	leaq	0x10(%r15), %rdx
   14d2d:      	movl	$0x4, %eax
   14d32:      	movq	%rbp, %rdi
   14d35:      	movl	$0x8, %esi
   14d3a:      	callq	*%rax
   14d3c:      	movq	0x40(%rsp), %rax
   14d41:      	cmpq	(%rsp), %rax
   14d45:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14d4b:      	addq	$0x18, %r15
   14d4f:      	movl	$0x4, %eax
   14d54:      	leaq	0x30(%rsp), %rdi
   14d59:      	movl	$0x8, %esi
   14d5e:      	movq	%r15, %rdx
   14d61:      	callq	*%rax
   14d63:      	movq	(%rsp), %r15
   14d67:      	movq	%r15, 0x40(%rsp)
   14d6c:      	leaq	0x20(%r15), %rdx
   14d70:      	movq	%rdx, 0x38(%rsp)
   14d75:      	movq	0x30(%rsp), %r12
   14d7a:      	cmpq	0x18(%rsp), %r12
   14d7f:      	jne	0x14d8c <generic_rawtp_path+0xaaac>
   14d81:      	cmpq	0x20(%rsp), %rdx
   14d86:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14d8c:      	movl	$0x4, %eax
   14d91:      	leaq	0x10(%rsp), %rdi
   14d96:      	movl	$0x8, %esi
   14d9b:      	callq	*%rax
   14d9d:      	cmpq	0x10(%rsp), %r12
   14da2:      	je	0x14e9a <generic_rawtp_path+0xabba>
   14da8:      	leaq	0x18(%r12), %rbx
   14dad:      	movl	$0x4, %eax
   14db2:      	movq	%rbp, %rdi
   14db5:      	movl	$0x8, %esi
   14dba:      	movq	%rbx, %rdx
   14dbd:      	callq	*%rax
   14dbf:      	cmpq	%r12, (%rsp)
   14dc3:      	je	0x14e9a <generic_rawtp_path+0xabba>
   14dc9:      	movl	$0x4, %eax
   14dce:      	leaq	0x8(%rsp), %rdi
   14dd3:      	movl	$0x8, %esi
   14dd8:      	movq	%rbx, %rdx
   14ddb:      	callq	*%rax
   14ddd:      	addq	$0x20, %r12
   14de1:      	movl	$0x4, %eax
   14de6:      	leaq	0x58(%rsp), %rdi
   14deb:      	movl	$0x10, %ecx
   14df0:      	movl	$0x10, %esi
   14df5:      	movq	%r12, %rdx
   14df8:      	callq	*%rax
   14dfa:      	movq	0x28(%rsp), %rbx
   14dff:      	movq	0x48(%rsp), %rax
   14e04:      	movl	0x5c(%rsp), %r15d
   14e09:      	subq	%rbx, %rax
   14e0c:      	movl	0x50(%rsp), %r12d
   14e11:      	movl	%r15d, %edx
   14e14:      	subl	%r12d, %edx
   14e17:      	movl	$0x0, %ecx
   14e1c:      	cmovbl	%ecx, %edx
   14e1f:      	addq	0x60(%rsp), %rdx
   14e24:      	xorl	%esi, %esi
   14e26:      	cmpl	%r15d, %r12d
   14e29:      	seta	%sil
   14e2d:      	movl	%r15d, %ecx
   14e30:      	cmovbl	%r12d, %ecx
   14e34:      	addl	%ecx, %esi
   14e36:      	movl	%r12d, %edi
   14e39:      	subl	%esi, %edi
   14e3b:      	movl	%edi, 0x50(%rsp)
   14e3f:      	subq	%rsi, %rax
   14e42:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14e48:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14e4e:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   14e54:      	cmpl	%r15d, %r12d
   14e57:      	jbe	0x14e5d <generic_rawtp_path+0xab7d>
   14e59:      	movb	$0x2f, (%rbx,%rax)
   14e5d:      	xorl	%edi, %edi
   14e5f:      	cmpl	%r15d, %r12d
   14e62:      	seta	%dil
   14e66:      	movzbl	%cl, %esi
   14e69:      	addq	%rax, %rbx
   14e6c:      	addq	%rbx, %rdi
   14e6f:      	movl	$0x4, %eax
   14e74:      	callq	*%rax
   14e76:      	movq	%rbx, 0x48(%rsp)
   14e7b:      	cmpl	%r15d, %r12d
   14e7e:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   14e84:      	movq	0x8(%rsp), %r12
   14e89:      	movq	%r12, 0x30(%rsp)
   14e8e:      	movq	0x38(%rsp), %rdx
   14e93:      	movq	0x40(%rsp), %r15
   14e98:      	jmp	0x14eeb <generic_rawtp_path+0xac0b>
   14e9a:      	leaq	0x10(%r15), %rdx
   14e9e:      	movl	$0x4, %eax
   14ea3:      	movq	%rbp, %rdi
   14ea6:      	movl	$0x8, %esi
   14eab:      	callq	*%rax
   14ead:      	movq	0x40(%rsp), %rax
   14eb2:      	cmpq	(%rsp), %rax
   14eb6:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14ebc:      	addq	$0x18, %r15
   14ec0:      	movl	$0x4, %eax
   14ec5:      	leaq	0x30(%rsp), %rdi
   14eca:      	movl	$0x8, %esi
   14ecf:      	movq	%r15, %rdx
   14ed2:      	callq	*%rax
   14ed4:      	movq	(%rsp), %r15
   14ed8:      	movq	%r15, 0x40(%rsp)
   14edd:      	leaq	0x20(%r15), %rdx
   14ee1:      	movq	%rdx, 0x38(%rsp)
   14ee6:      	movq	0x30(%rsp), %r12
   14eeb:      	cmpq	0x18(%rsp), %r12
   14ef0:      	jne	0x14efd <generic_rawtp_path+0xac1d>
   14ef2:      	cmpq	0x20(%rsp), %rdx
   14ef7:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   14efd:      	movl	$0x4, %eax
   14f02:      	leaq	0x10(%rsp), %rdi
   14f07:      	movl	$0x8, %esi
   14f0c:      	callq	*%rax
   14f0e:      	cmpq	0x10(%rsp), %r12
   14f13:      	je	0x1500b <generic_rawtp_path+0xad2b>
   14f19:      	leaq	0x18(%r12), %rbx
   14f1e:      	movl	$0x4, %eax
   14f23:      	movq	%rbp, %rdi
   14f26:      	movl	$0x8, %esi
   14f2b:      	movq	%rbx, %rdx
   14f2e:      	callq	*%rax
   14f30:      	cmpq	%r12, (%rsp)
   14f34:      	je	0x1500b <generic_rawtp_path+0xad2b>
   14f3a:      	movl	$0x4, %eax
   14f3f:      	leaq	0x8(%rsp), %rdi
   14f44:      	movl	$0x8, %esi
   14f49:      	movq	%rbx, %rdx
   14f4c:      	callq	*%rax
   14f4e:      	addq	$0x20, %r12
   14f52:      	movl	$0x4, %eax
   14f57:      	leaq	0x58(%rsp), %rdi
   14f5c:      	movl	$0x10, %ecx
   14f61:      	movl	$0x10, %esi
   14f66:      	movq	%r12, %rdx
   14f69:      	callq	*%rax
   14f6b:      	movq	0x28(%rsp), %rbx
   14f70:      	movq	0x48(%rsp), %rax
   14f75:      	movl	0x5c(%rsp), %r15d
   14f7a:      	subq	%rbx, %rax
   14f7d:      	movl	0x50(%rsp), %r12d
   14f82:      	movl	%r15d, %edx
   14f85:      	subl	%r12d, %edx
   14f88:      	movl	$0x0, %ecx
   14f8d:      	cmovbl	%ecx, %edx
   14f90:      	addq	0x60(%rsp), %rdx
   14f95:      	xorl	%esi, %esi
   14f97:      	cmpl	%r15d, %r12d
   14f9a:      	seta	%sil
   14f9e:      	movl	%r15d, %ecx
   14fa1:      	cmovbl	%r12d, %ecx
   14fa5:      	addl	%ecx, %esi
   14fa7:      	movl	%r12d, %edi
   14faa:      	subl	%esi, %edi
   14fac:      	movl	%edi, 0x50(%rsp)
   14fb0:      	subq	%rsi, %rax
   14fb3:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   14fb9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14fbf:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   14fc5:      	cmpl	%r15d, %r12d
   14fc8:      	jbe	0x14fce <generic_rawtp_path+0xacee>
   14fca:      	movb	$0x2f, (%rbx,%rax)
   14fce:      	xorl	%edi, %edi
   14fd0:      	cmpl	%r15d, %r12d
   14fd3:      	seta	%dil
   14fd7:      	movzbl	%cl, %esi
   14fda:      	addq	%rax, %rbx
   14fdd:      	addq	%rbx, %rdi
   14fe0:      	movl	$0x4, %eax
   14fe5:      	callq	*%rax
   14fe7:      	movq	%rbx, 0x48(%rsp)
   14fec:      	cmpl	%r15d, %r12d
   14fef:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   14ff5:      	movq	0x8(%rsp), %r12
   14ffa:      	movq	%r12, 0x30(%rsp)
   14fff:      	movq	0x38(%rsp), %rdx
   15004:      	movq	0x40(%rsp), %r15
   15009:      	jmp	0x1505c <generic_rawtp_path+0xad7c>
   1500b:      	leaq	0x10(%r15), %rdx
   1500f:      	movl	$0x4, %eax
   15014:      	movq	%rbp, %rdi
   15017:      	movl	$0x8, %esi
   1501c:      	callq	*%rax
   1501e:      	movq	0x40(%rsp), %rax
   15023:      	cmpq	(%rsp), %rax
   15027:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1502d:      	addq	$0x18, %r15
   15031:      	movl	$0x4, %eax
   15036:      	leaq	0x30(%rsp), %rdi
   1503b:      	movl	$0x8, %esi
   15040:      	movq	%r15, %rdx
   15043:      	callq	*%rax
   15045:      	movq	(%rsp), %r15
   15049:      	movq	%r15, 0x40(%rsp)
   1504e:      	leaq	0x20(%r15), %rdx
   15052:      	movq	%rdx, 0x38(%rsp)
   15057:      	movq	0x30(%rsp), %r12
   1505c:      	cmpq	0x18(%rsp), %r12
   15061:      	jne	0x1506e <generic_rawtp_path+0xad8e>
   15063:      	cmpq	0x20(%rsp), %rdx
   15068:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1506e:      	movl	$0x4, %eax
   15073:      	leaq	0x10(%rsp), %rdi
   15078:      	movl	$0x8, %esi
   1507d:      	callq	*%rax
   1507f:      	cmpq	0x10(%rsp), %r12
   15084:      	je	0x1517c <generic_rawtp_path+0xae9c>
   1508a:      	leaq	0x18(%r12), %rbx
   1508f:      	movl	$0x4, %eax
   15094:      	movq	%rbp, %rdi
   15097:      	movl	$0x8, %esi
   1509c:      	movq	%rbx, %rdx
   1509f:      	callq	*%rax
   150a1:      	cmpq	%r12, (%rsp)
   150a5:      	je	0x1517c <generic_rawtp_path+0xae9c>
   150ab:      	movl	$0x4, %eax
   150b0:      	leaq	0x8(%rsp), %rdi
   150b5:      	movl	$0x8, %esi
   150ba:      	movq	%rbx, %rdx
   150bd:      	callq	*%rax
   150bf:      	addq	$0x20, %r12
   150c3:      	movl	$0x4, %eax
   150c8:      	leaq	0x58(%rsp), %rdi
   150cd:      	movl	$0x10, %ecx
   150d2:      	movl	$0x10, %esi
   150d7:      	movq	%r12, %rdx
   150da:      	callq	*%rax
   150dc:      	movq	0x28(%rsp), %rbx
   150e1:      	movq	0x48(%rsp), %rax
   150e6:      	movl	0x5c(%rsp), %r15d
   150eb:      	subq	%rbx, %rax
   150ee:      	movl	0x50(%rsp), %r12d
   150f3:      	movl	%r15d, %edx
   150f6:      	subl	%r12d, %edx
   150f9:      	movl	$0x0, %ecx
   150fe:      	cmovbl	%ecx, %edx
   15101:      	addq	0x60(%rsp), %rdx
   15106:      	xorl	%esi, %esi
   15108:      	cmpl	%r15d, %r12d
   1510b:      	seta	%sil
   1510f:      	movl	%r15d, %ecx
   15112:      	cmovbl	%r12d, %ecx
   15116:      	addl	%ecx, %esi
   15118:      	movl	%r12d, %edi
   1511b:      	subl	%esi, %edi
   1511d:      	movl	%edi, 0x50(%rsp)
   15121:      	subq	%rsi, %rax
   15124:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1512a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15130:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   15136:      	cmpl	%r15d, %r12d
   15139:      	jbe	0x1513f <generic_rawtp_path+0xae5f>
   1513b:      	movb	$0x2f, (%rbx,%rax)
   1513f:      	xorl	%edi, %edi
   15141:      	cmpl	%r15d, %r12d
   15144:      	seta	%dil
   15148:      	movzbl	%cl, %esi
   1514b:      	addq	%rax, %rbx
   1514e:      	addq	%rbx, %rdi
   15151:      	movl	$0x4, %eax
   15156:      	callq	*%rax
   15158:      	movq	%rbx, 0x48(%rsp)
   1515d:      	cmpl	%r15d, %r12d
   15160:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   15166:      	movq	0x8(%rsp), %r12
   1516b:      	movq	%r12, 0x30(%rsp)
   15170:      	movq	0x38(%rsp), %rdx
   15175:      	movq	0x40(%rsp), %r15
   1517a:      	jmp	0x151cd <generic_rawtp_path+0xaeed>
   1517c:      	leaq	0x10(%r15), %rdx
   15180:      	movl	$0x4, %eax
   15185:      	movq	%rbp, %rdi
   15188:      	movl	$0x8, %esi
   1518d:      	callq	*%rax
   1518f:      	movq	0x40(%rsp), %rax
   15194:      	cmpq	(%rsp), %rax
   15198:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1519e:      	addq	$0x18, %r15
   151a2:      	movl	$0x4, %eax
   151a7:      	leaq	0x30(%rsp), %rdi
   151ac:      	movl	$0x8, %esi
   151b1:      	movq	%r15, %rdx
   151b4:      	callq	*%rax
   151b6:      	movq	(%rsp), %r15
   151ba:      	movq	%r15, 0x40(%rsp)
   151bf:      	leaq	0x20(%r15), %rdx
   151c3:      	movq	%rdx, 0x38(%rsp)
   151c8:      	movq	0x30(%rsp), %r12
   151cd:      	cmpq	0x18(%rsp), %r12
   151d2:      	jne	0x151df <generic_rawtp_path+0xaeff>
   151d4:      	cmpq	0x20(%rsp), %rdx
   151d9:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   151df:      	movl	$0x4, %eax
   151e4:      	leaq	0x10(%rsp), %rdi
   151e9:      	movl	$0x8, %esi
   151ee:      	callq	*%rax
   151f0:      	cmpq	0x10(%rsp), %r12
   151f5:      	je	0x152ed <generic_rawtp_path+0xb00d>
   151fb:      	leaq	0x18(%r12), %rbx
   15200:      	movl	$0x4, %eax
   15205:      	movq	%rbp, %rdi
   15208:      	movl	$0x8, %esi
   1520d:      	movq	%rbx, %rdx
   15210:      	callq	*%rax
   15212:      	cmpq	%r12, (%rsp)
   15216:      	je	0x152ed <generic_rawtp_path+0xb00d>
   1521c:      	movl	$0x4, %eax
   15221:      	leaq	0x8(%rsp), %rdi
   15226:      	movl	$0x8, %esi
   1522b:      	movq	%rbx, %rdx
   1522e:      	callq	*%rax
   15230:      	addq	$0x20, %r12
   15234:      	movl	$0x4, %eax
   15239:      	leaq	0x58(%rsp), %rdi
   1523e:      	movl	$0x10, %ecx
   15243:      	movl	$0x10, %esi
   15248:      	movq	%r12, %rdx
   1524b:      	callq	*%rax
   1524d:      	movq	0x28(%rsp), %rbx
   15252:      	movq	0x48(%rsp), %rax
   15257:      	movl	0x5c(%rsp), %r15d
   1525c:      	subq	%rbx, %rax
   1525f:      	movl	0x50(%rsp), %r12d
   15264:      	movl	%r15d, %edx
   15267:      	subl	%r12d, %edx
   1526a:      	movl	$0x0, %ecx
   1526f:      	cmovbl	%ecx, %edx
   15272:      	addq	0x60(%rsp), %rdx
   15277:      	xorl	%esi, %esi
   15279:      	cmpl	%r15d, %r12d
   1527c:      	seta	%sil
   15280:      	movl	%r15d, %ecx
   15283:      	cmovbl	%r12d, %ecx
   15287:      	addl	%ecx, %esi
   15289:      	movl	%r12d, %edi
   1528c:      	subl	%esi, %edi
   1528e:      	movl	%edi, 0x50(%rsp)
   15292:      	subq	%rsi, %rax
   15295:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1529b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   152a1:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   152a7:      	cmpl	%r15d, %r12d
   152aa:      	jbe	0x152b0 <generic_rawtp_path+0xafd0>
   152ac:      	movb	$0x2f, (%rbx,%rax)
   152b0:      	xorl	%edi, %edi
   152b2:      	cmpl	%r15d, %r12d
   152b5:      	seta	%dil
   152b9:      	movzbl	%cl, %esi
   152bc:      	addq	%rax, %rbx
   152bf:      	addq	%rbx, %rdi
   152c2:      	movl	$0x4, %eax
   152c7:      	callq	*%rax
   152c9:      	movq	%rbx, 0x48(%rsp)
   152ce:      	cmpl	%r15d, %r12d
   152d1:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   152d7:      	movq	0x8(%rsp), %r12
   152dc:      	movq	%r12, 0x30(%rsp)
   152e1:      	movq	0x38(%rsp), %rdx
   152e6:      	movq	0x40(%rsp), %r15
   152eb:      	jmp	0x1533e <generic_rawtp_path+0xb05e>
   152ed:      	leaq	0x10(%r15), %rdx
   152f1:      	movl	$0x4, %eax
   152f6:      	movq	%rbp, %rdi
   152f9:      	movl	$0x8, %esi
   152fe:      	callq	*%rax
   15300:      	movq	0x40(%rsp), %rax
   15305:      	cmpq	(%rsp), %rax
   15309:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   1530f:      	addq	$0x18, %r15
   15313:      	movl	$0x4, %eax
   15318:      	leaq	0x30(%rsp), %rdi
   1531d:      	movl	$0x8, %esi
   15322:      	movq	%r15, %rdx
   15325:      	callq	*%rax
   15327:      	movq	(%rsp), %r15
   1532b:      	movq	%r15, 0x40(%rsp)
   15330:      	leaq	0x20(%r15), %rdx
   15334:      	movq	%rdx, 0x38(%rsp)
   15339:      	movq	0x30(%rsp), %r12
   1533e:      	cmpq	0x18(%rsp), %r12
   15343:      	jne	0x15350 <generic_rawtp_path+0xb070>
   15345:      	cmpq	0x20(%rsp), %rdx
   1534a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15350:      	movl	$0x4, %eax
   15355:      	leaq	0x10(%rsp), %rdi
   1535a:      	movl	$0x8, %esi
   1535f:      	callq	*%rax
   15361:      	cmpq	0x10(%rsp), %r12
   15366:      	je	0x1545e <generic_rawtp_path+0xb17e>
   1536c:      	leaq	0x18(%r12), %rbx
   15371:      	movl	$0x4, %eax
   15376:      	movq	%rbp, %rdi
   15379:      	movl	$0x8, %esi
   1537e:      	movq	%rbx, %rdx
   15381:      	callq	*%rax
   15383:      	cmpq	%r12, (%rsp)
   15387:      	je	0x1545e <generic_rawtp_path+0xb17e>
   1538d:      	movl	$0x4, %eax
   15392:      	leaq	0x8(%rsp), %rdi
   15397:      	movl	$0x8, %esi
   1539c:      	movq	%rbx, %rdx
   1539f:      	callq	*%rax
   153a1:      	addq	$0x20, %r12
   153a5:      	movl	$0x4, %eax
   153aa:      	leaq	0x58(%rsp), %rdi
   153af:      	movl	$0x10, %ecx
   153b4:      	movl	$0x10, %esi
   153b9:      	movq	%r12, %rdx
   153bc:      	callq	*%rax
   153be:      	movq	0x28(%rsp), %rbx
   153c3:      	movq	0x48(%rsp), %rax
   153c8:      	movl	0x5c(%rsp), %r15d
   153cd:      	subq	%rbx, %rax
   153d0:      	movl	0x50(%rsp), %r12d
   153d5:      	movl	%r15d, %edx
   153d8:      	subl	%r12d, %edx
   153db:      	movl	$0x0, %ecx
   153e0:      	cmovbl	%ecx, %edx
   153e3:      	addq	0x60(%rsp), %rdx
   153e8:      	xorl	%esi, %esi
   153ea:      	cmpl	%r15d, %r12d
   153ed:      	seta	%sil
   153f1:      	movl	%r15d, %ecx
   153f4:      	cmovbl	%r12d, %ecx
   153f8:      	addl	%ecx, %esi
   153fa:      	movl	%r12d, %edi
   153fd:      	subl	%esi, %edi
   153ff:      	movl	%edi, 0x50(%rsp)
   15403:      	subq	%rsi, %rax
   15406:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1540c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15412:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   15418:      	cmpl	%r15d, %r12d
   1541b:      	jbe	0x15421 <generic_rawtp_path+0xb141>
   1541d:      	movb	$0x2f, (%rbx,%rax)
   15421:      	xorl	%edi, %edi
   15423:      	cmpl	%r15d, %r12d
   15426:      	seta	%dil
   1542a:      	movzbl	%cl, %esi
   1542d:      	addq	%rax, %rbx
   15430:      	addq	%rbx, %rdi
   15433:      	movl	$0x4, %eax
   15438:      	callq	*%rax
   1543a:      	movq	%rbx, 0x48(%rsp)
   1543f:      	cmpl	%r15d, %r12d
   15442:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   15448:      	movq	0x8(%rsp), %r12
   1544d:      	movq	%r12, 0x30(%rsp)
   15452:      	movq	0x38(%rsp), %rdx
   15457:      	movq	0x40(%rsp), %r15
   1545c:      	jmp	0x154af <generic_rawtp_path+0xb1cf>
   1545e:      	leaq	0x10(%r15), %rdx
   15462:      	movl	$0x4, %eax
   15467:      	movq	%rbp, %rdi
   1546a:      	movl	$0x8, %esi
   1546f:      	callq	*%rax
   15471:      	movq	0x40(%rsp), %rax
   15476:      	cmpq	(%rsp), %rax
   1547a:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15480:      	addq	$0x18, %r15
   15484:      	movl	$0x4, %eax
   15489:      	leaq	0x30(%rsp), %rdi
   1548e:      	movl	$0x8, %esi
   15493:      	movq	%r15, %rdx
   15496:      	callq	*%rax
   15498:      	movq	(%rsp), %r15
   1549c:      	movq	%r15, 0x40(%rsp)
   154a1:      	leaq	0x20(%r15), %rdx
   154a5:      	movq	%rdx, 0x38(%rsp)
   154aa:      	movq	0x30(%rsp), %r12
   154af:      	cmpq	0x18(%rsp), %r12
   154b4:      	jne	0x154c1 <generic_rawtp_path+0xb1e1>
   154b6:      	cmpq	0x20(%rsp), %rdx
   154bb:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   154c1:      	movl	$0x4, %eax
   154c6:      	leaq	0x10(%rsp), %rdi
   154cb:      	movl	$0x8, %esi
   154d0:      	callq	*%rax
   154d2:      	cmpq	0x10(%rsp), %r12
   154d7:      	je	0x155cf <generic_rawtp_path+0xb2ef>
   154dd:      	leaq	0x18(%r12), %rbx
   154e2:      	movl	$0x4, %eax
   154e7:      	movq	%rbp, %rdi
   154ea:      	movl	$0x8, %esi
   154ef:      	movq	%rbx, %rdx
   154f2:      	callq	*%rax
   154f4:      	cmpq	%r12, (%rsp)
   154f8:      	je	0x155cf <generic_rawtp_path+0xb2ef>
   154fe:      	movl	$0x4, %eax
   15503:      	leaq	0x8(%rsp), %rdi
   15508:      	movl	$0x8, %esi
   1550d:      	movq	%rbx, %rdx
   15510:      	callq	*%rax
   15512:      	addq	$0x20, %r12
   15516:      	movl	$0x4, %eax
   1551b:      	leaq	0x58(%rsp), %rdi
   15520:      	movl	$0x10, %ecx
   15525:      	movl	$0x10, %esi
   1552a:      	movq	%r12, %rdx
   1552d:      	callq	*%rax
   1552f:      	movq	0x28(%rsp), %rbx
   15534:      	movq	0x48(%rsp), %rax
   15539:      	movl	0x5c(%rsp), %r15d
   1553e:      	subq	%rbx, %rax
   15541:      	movl	0x50(%rsp), %r12d
   15546:      	movl	%r15d, %edx
   15549:      	subl	%r12d, %edx
   1554c:      	movl	$0x0, %ecx
   15551:      	cmovbl	%ecx, %edx
   15554:      	addq	0x60(%rsp), %rdx
   15559:      	xorl	%esi, %esi
   1555b:      	cmpl	%r15d, %r12d
   1555e:      	seta	%sil
   15562:      	movl	%r15d, %ecx
   15565:      	cmovbl	%r12d, %ecx
   15569:      	addl	%ecx, %esi
   1556b:      	movl	%r12d, %edi
   1556e:      	subl	%esi, %edi
   15570:      	movl	%edi, 0x50(%rsp)
   15574:      	subq	%rsi, %rax
   15577:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1557d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15583:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   15589:      	cmpl	%r15d, %r12d
   1558c:      	jbe	0x15592 <generic_rawtp_path+0xb2b2>
   1558e:      	movb	$0x2f, (%rbx,%rax)
   15592:      	xorl	%edi, %edi
   15594:      	cmpl	%r15d, %r12d
   15597:      	seta	%dil
   1559b:      	movzbl	%cl, %esi
   1559e:      	addq	%rax, %rbx
   155a1:      	addq	%rbx, %rdi
   155a4:      	movl	$0x4, %eax
   155a9:      	callq	*%rax
   155ab:      	movq	%rbx, 0x48(%rsp)
   155b0:      	cmpl	%r15d, %r12d
   155b3:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   155b9:      	movq	0x8(%rsp), %r12
   155be:      	movq	%r12, 0x30(%rsp)
   155c3:      	movq	0x38(%rsp), %rdx
   155c8:      	movq	0x40(%rsp), %r15
   155cd:      	jmp	0x15620 <generic_rawtp_path+0xb340>
   155cf:      	leaq	0x10(%r15), %rdx
   155d3:      	movl	$0x4, %eax
   155d8:      	movq	%rbp, %rdi
   155db:      	movl	$0x8, %esi
   155e0:      	callq	*%rax
   155e2:      	movq	0x40(%rsp), %rax
   155e7:      	cmpq	(%rsp), %rax
   155eb:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   155f1:      	addq	$0x18, %r15
   155f5:      	movl	$0x4, %eax
   155fa:      	leaq	0x30(%rsp), %rdi
   155ff:      	movl	$0x8, %esi
   15604:      	movq	%r15, %rdx
   15607:      	callq	*%rax
   15609:      	movq	(%rsp), %r15
   1560d:      	movq	%r15, 0x40(%rsp)
   15612:      	leaq	0x20(%r15), %rdx
   15616:      	movq	%rdx, 0x38(%rsp)
   1561b:      	movq	0x30(%rsp), %r12
   15620:      	cmpq	0x18(%rsp), %r12
   15625:      	jne	0x15632 <generic_rawtp_path+0xb352>
   15627:      	cmpq	0x20(%rsp), %rdx
   1562c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15632:      	movl	$0x4, %eax
   15637:      	leaq	0x10(%rsp), %rdi
   1563c:      	movl	$0x8, %esi
   15641:      	callq	*%rax
   15643:      	cmpq	0x10(%rsp), %r12
   15648:      	je	0x15740 <generic_rawtp_path+0xb460>
   1564e:      	leaq	0x18(%r12), %rbx
   15653:      	movl	$0x4, %eax
   15658:      	movq	%rbp, %rdi
   1565b:      	movl	$0x8, %esi
   15660:      	movq	%rbx, %rdx
   15663:      	callq	*%rax
   15665:      	cmpq	%r12, (%rsp)
   15669:      	je	0x15740 <generic_rawtp_path+0xb460>
   1566f:      	movl	$0x4, %eax
   15674:      	leaq	0x8(%rsp), %rdi
   15679:      	movl	$0x8, %esi
   1567e:      	movq	%rbx, %rdx
   15681:      	callq	*%rax
   15683:      	addq	$0x20, %r12
   15687:      	movl	$0x4, %eax
   1568c:      	leaq	0x58(%rsp), %rdi
   15691:      	movl	$0x10, %ecx
   15696:      	movl	$0x10, %esi
   1569b:      	movq	%r12, %rdx
   1569e:      	callq	*%rax
   156a0:      	movq	0x28(%rsp), %rbx
   156a5:      	movq	0x48(%rsp), %rax
   156aa:      	movl	0x5c(%rsp), %r15d
   156af:      	subq	%rbx, %rax
   156b2:      	movl	0x50(%rsp), %r12d
   156b7:      	movl	%r15d, %edx
   156ba:      	subl	%r12d, %edx
   156bd:      	movl	$0x0, %ecx
   156c2:      	cmovbl	%ecx, %edx
   156c5:      	addq	0x60(%rsp), %rdx
   156ca:      	xorl	%esi, %esi
   156cc:      	cmpl	%r15d, %r12d
   156cf:      	seta	%sil
   156d3:      	movl	%r15d, %ecx
   156d6:      	cmovbl	%r12d, %ecx
   156da:      	addl	%ecx, %esi
   156dc:      	movl	%r12d, %edi
   156df:      	subl	%esi, %edi
   156e1:      	movl	%edi, 0x50(%rsp)
   156e5:      	subq	%rsi, %rax
   156e8:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   156ee:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   156f4:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   156fa:      	cmpl	%r15d, %r12d
   156fd:      	jbe	0x15703 <generic_rawtp_path+0xb423>
   156ff:      	movb	$0x2f, (%rbx,%rax)
   15703:      	xorl	%edi, %edi
   15705:      	cmpl	%r15d, %r12d
   15708:      	seta	%dil
   1570c:      	movzbl	%cl, %esi
   1570f:      	addq	%rax, %rbx
   15712:      	addq	%rbx, %rdi
   15715:      	movl	$0x4, %eax
   1571a:      	callq	*%rax
   1571c:      	movq	%rbx, 0x48(%rsp)
   15721:      	cmpl	%r15d, %r12d
   15724:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1572a:      	movq	0x8(%rsp), %r12
   1572f:      	movq	%r12, 0x30(%rsp)
   15734:      	movq	0x38(%rsp), %rdx
   15739:      	movq	0x40(%rsp), %r15
   1573e:      	jmp	0x15791 <generic_rawtp_path+0xb4b1>
   15740:      	leaq	0x10(%r15), %rdx
   15744:      	movl	$0x4, %eax
   15749:      	movq	%rbp, %rdi
   1574c:      	movl	$0x8, %esi
   15751:      	callq	*%rax
   15753:      	movq	0x40(%rsp), %rax
   15758:      	cmpq	(%rsp), %rax
   1575c:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15762:      	addq	$0x18, %r15
   15766:      	movl	$0x4, %eax
   1576b:      	leaq	0x30(%rsp), %rdi
   15770:      	movl	$0x8, %esi
   15775:      	movq	%r15, %rdx
   15778:      	callq	*%rax
   1577a:      	movq	(%rsp), %r15
   1577e:      	movq	%r15, 0x40(%rsp)
   15783:      	leaq	0x20(%r15), %rdx
   15787:      	movq	%rdx, 0x38(%rsp)
   1578c:      	movq	0x30(%rsp), %r12
   15791:      	cmpq	0x18(%rsp), %r12
   15796:      	jne	0x157a3 <generic_rawtp_path+0xb4c3>
   15798:      	cmpq	0x20(%rsp), %rdx
   1579d:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   157a3:      	movl	$0x4, %eax
   157a8:      	leaq	0x10(%rsp), %rdi
   157ad:      	movl	$0x8, %esi
   157b2:      	callq	*%rax
   157b4:      	cmpq	0x10(%rsp), %r12
   157b9:      	je	0x158b1 <generic_rawtp_path+0xb5d1>
   157bf:      	leaq	0x18(%r12), %rbx
   157c4:      	movl	$0x4, %eax
   157c9:      	movq	%rbp, %rdi
   157cc:      	movl	$0x8, %esi
   157d1:      	movq	%rbx, %rdx
   157d4:      	callq	*%rax
   157d6:      	cmpq	%r12, (%rsp)
   157da:      	je	0x158b1 <generic_rawtp_path+0xb5d1>
   157e0:      	movl	$0x4, %eax
   157e5:      	leaq	0x8(%rsp), %rdi
   157ea:      	movl	$0x8, %esi
   157ef:      	movq	%rbx, %rdx
   157f2:      	callq	*%rax
   157f4:      	addq	$0x20, %r12
   157f8:      	movl	$0x4, %eax
   157fd:      	leaq	0x58(%rsp), %rdi
   15802:      	movl	$0x10, %ecx
   15807:      	movl	$0x10, %esi
   1580c:      	movq	%r12, %rdx
   1580f:      	callq	*%rax
   15811:      	movq	0x28(%rsp), %rbx
   15816:      	movq	0x48(%rsp), %rax
   1581b:      	movl	0x5c(%rsp), %r15d
   15820:      	subq	%rbx, %rax
   15823:      	movl	0x50(%rsp), %r12d
   15828:      	movl	%r15d, %edx
   1582b:      	subl	%r12d, %edx
   1582e:      	movl	$0x0, %ecx
   15833:      	cmovbl	%ecx, %edx
   15836:      	addq	0x60(%rsp), %rdx
   1583b:      	xorl	%esi, %esi
   1583d:      	cmpl	%r15d, %r12d
   15840:      	seta	%sil
   15844:      	movl	%r15d, %ecx
   15847:      	cmovbl	%r12d, %ecx
   1584b:      	addl	%ecx, %esi
   1584d:      	movl	%r12d, %edi
   15850:      	subl	%esi, %edi
   15852:      	movl	%edi, 0x50(%rsp)
   15856:      	subq	%rsi, %rax
   15859:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   1585f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15865:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   1586b:      	cmpl	%r15d, %r12d
   1586e:      	jbe	0x15874 <generic_rawtp_path+0xb594>
   15870:      	movb	$0x2f, (%rbx,%rax)
   15874:      	xorl	%edi, %edi
   15876:      	cmpl	%r15d, %r12d
   15879:      	seta	%dil
   1587d:      	movzbl	%cl, %esi
   15880:      	addq	%rax, %rbx
   15883:      	addq	%rbx, %rdi
   15886:      	movl	$0x4, %eax
   1588b:      	callq	*%rax
   1588d:      	movq	%rbx, 0x48(%rsp)
   15892:      	cmpl	%r15d, %r12d
   15895:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   1589b:      	movq	0x8(%rsp), %r12
   158a0:      	movq	%r12, 0x30(%rsp)
   158a5:      	movq	0x38(%rsp), %rdx
   158aa:      	movq	0x40(%rsp), %r15
   158af:      	jmp	0x15902 <generic_rawtp_path+0xb622>
   158b1:      	leaq	0x10(%r15), %rdx
   158b5:      	movl	$0x4, %eax
   158ba:      	movq	%rbp, %rdi
   158bd:      	movl	$0x8, %esi
   158c2:      	callq	*%rax
   158c4:      	movq	0x40(%rsp), %rax
   158c9:      	cmpq	(%rsp), %rax
   158cd:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   158d3:      	addq	$0x18, %r15
   158d7:      	movl	$0x4, %eax
   158dc:      	leaq	0x30(%rsp), %rdi
   158e1:      	movl	$0x8, %esi
   158e6:      	movq	%r15, %rdx
   158e9:      	callq	*%rax
   158eb:      	movq	(%rsp), %r15
   158ef:      	movq	%r15, 0x40(%rsp)
   158f4:      	leaq	0x20(%r15), %rdx
   158f8:      	movq	%rdx, 0x38(%rsp)
   158fd:      	movq	0x30(%rsp), %r12
   15902:      	cmpq	0x18(%rsp), %r12
   15907:      	jne	0x15914 <generic_rawtp_path+0xb634>
   15909:      	cmpq	0x20(%rsp), %rdx
   1590e:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15914:      	movl	$0x4, %eax
   15919:      	leaq	0x10(%rsp), %rdi
   1591e:      	movl	$0x8, %esi
   15923:      	callq	*%rax
   15925:      	cmpq	0x10(%rsp), %r12
   1592a:      	je	0x15a22 <generic_rawtp_path+0xb742>
   15930:      	leaq	0x18(%r12), %rbx
   15935:      	movl	$0x4, %eax
   1593a:      	movq	%rbp, %rdi
   1593d:      	movl	$0x8, %esi
   15942:      	movq	%rbx, %rdx
   15945:      	callq	*%rax
   15947:      	cmpq	%r12, (%rsp)
   1594b:      	je	0x15a22 <generic_rawtp_path+0xb742>
   15951:      	movl	$0x4, %eax
   15956:      	leaq	0x8(%rsp), %rdi
   1595b:      	movl	$0x8, %esi
   15960:      	movq	%rbx, %rdx
   15963:      	callq	*%rax
   15965:      	addq	$0x20, %r12
   15969:      	movl	$0x4, %eax
   1596e:      	leaq	0x58(%rsp), %rdi
   15973:      	movl	$0x10, %ecx
   15978:      	movl	$0x10, %esi
   1597d:      	movq	%r12, %rdx
   15980:      	callq	*%rax
   15982:      	movq	0x28(%rsp), %rbx
   15987:      	movq	0x48(%rsp), %rax
   1598c:      	movl	0x5c(%rsp), %r15d
   15991:      	subq	%rbx, %rax
   15994:      	movl	0x50(%rsp), %r12d
   15999:      	movl	%r15d, %edx
   1599c:      	subl	%r12d, %edx
   1599f:      	movl	$0x0, %ecx
   159a4:      	cmovbl	%ecx, %edx
   159a7:      	addq	0x60(%rsp), %rdx
   159ac:      	xorl	%esi, %esi
   159ae:      	cmpl	%r15d, %r12d
   159b1:      	seta	%sil
   159b5:      	movl	%r15d, %ecx
   159b8:      	cmovbl	%r12d, %ecx
   159bc:      	addl	%ecx, %esi
   159be:      	movl	%r12d, %edi
   159c1:      	subl	%esi, %edi
   159c3:      	movl	%edi, 0x50(%rsp)
   159c7:      	subq	%rsi, %rax
   159ca:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   159d0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   159d6:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   159dc:      	cmpl	%r15d, %r12d
   159df:      	jbe	0x159e5 <generic_rawtp_path+0xb705>
   159e1:      	movb	$0x2f, (%rbx,%rax)
   159e5:      	xorl	%edi, %edi
   159e7:      	cmpl	%r15d, %r12d
   159ea:      	seta	%dil
   159ee:      	movzbl	%cl, %esi
   159f1:      	addq	%rax, %rbx
   159f4:      	addq	%rbx, %rdi
   159f7:      	movl	$0x4, %eax
   159fc:      	callq	*%rax
   159fe:      	movq	%rbx, 0x48(%rsp)
   15a03:      	cmpl	%r15d, %r12d
   15a06:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   15a0c:      	movq	0x8(%rsp), %r12
   15a11:      	movq	%r12, 0x30(%rsp)
   15a16:      	movq	0x38(%rsp), %rdx
   15a1b:      	movq	0x40(%rsp), %r15
   15a20:      	jmp	0x15a73 <generic_rawtp_path+0xb793>
   15a22:      	leaq	0x10(%r15), %rdx
   15a26:      	movl	$0x4, %eax
   15a2b:      	movq	%rbp, %rdi
   15a2e:      	movl	$0x8, %esi
   15a33:      	callq	*%rax
   15a35:      	movq	0x40(%rsp), %rax
   15a3a:      	cmpq	(%rsp), %rax
   15a3e:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15a44:      	addq	$0x18, %r15
   15a48:      	movl	$0x4, %eax
   15a4d:      	leaq	0x30(%rsp), %rdi
   15a52:      	movl	$0x8, %esi
   15a57:      	movq	%r15, %rdx
   15a5a:      	callq	*%rax
   15a5c:      	movq	(%rsp), %r15
   15a60:      	movq	%r15, 0x40(%rsp)
   15a65:      	leaq	0x20(%r15), %rdx
   15a69:      	movq	%rdx, 0x38(%rsp)
   15a6e:      	movq	0x30(%rsp), %r12
   15a73:      	cmpq	0x18(%rsp), %r12
   15a78:      	jne	0x15a85 <generic_rawtp_path+0xb7a5>
   15a7a:      	cmpq	0x20(%rsp), %rdx
   15a7f:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15a85:      	movl	$0x4, %eax
   15a8a:      	leaq	0x10(%rsp), %rdi
   15a8f:      	movl	$0x8, %esi
   15a94:      	callq	*%rax
   15a96:      	cmpq	0x10(%rsp), %r12
   15a9b:      	je	0x15b93 <generic_rawtp_path+0xb8b3>
   15aa1:      	leaq	0x18(%r12), %rbx
   15aa6:      	movl	$0x4, %eax
   15aab:      	movq	%rbp, %rdi
   15aae:      	movl	$0x8, %esi
   15ab3:      	movq	%rbx, %rdx
   15ab6:      	callq	*%rax
   15ab8:      	cmpq	%r12, (%rsp)
   15abc:      	je	0x15b93 <generic_rawtp_path+0xb8b3>
   15ac2:      	movl	$0x4, %eax
   15ac7:      	leaq	0x8(%rsp), %rdi
   15acc:      	movl	$0x8, %esi
   15ad1:      	movq	%rbx, %rdx
   15ad4:      	callq	*%rax
   15ad6:      	addq	$0x20, %r12
   15ada:      	movl	$0x4, %eax
   15adf:      	leaq	0x58(%rsp), %rdi
   15ae4:      	movl	$0x10, %ecx
   15ae9:      	movl	$0x10, %esi
   15aee:      	movq	%r12, %rdx
   15af1:      	callq	*%rax
   15af3:      	movq	0x28(%rsp), %rbx
   15af8:      	movq	0x48(%rsp), %rax
   15afd:      	movl	0x5c(%rsp), %r15d
   15b02:      	subq	%rbx, %rax
   15b05:      	movl	0x50(%rsp), %r12d
   15b0a:      	movl	%r15d, %edx
   15b0d:      	subl	%r12d, %edx
   15b10:      	movl	$0x0, %ecx
   15b15:      	cmovbl	%ecx, %edx
   15b18:      	addq	0x60(%rsp), %rdx
   15b1d:      	xorl	%esi, %esi
   15b1f:      	cmpl	%r15d, %r12d
   15b22:      	seta	%sil
   15b26:      	movl	%r15d, %ecx
   15b29:      	cmovbl	%r12d, %ecx
   15b2d:      	addl	%ecx, %esi
   15b2f:      	movl	%r12d, %edi
   15b32:      	subl	%esi, %edi
   15b34:      	movl	%edi, 0x50(%rsp)
   15b38:      	subq	%rsi, %rax
   15b3b:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   15b41:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15b47:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   15b4d:      	cmpl	%r15d, %r12d
   15b50:      	jbe	0x15b56 <generic_rawtp_path+0xb876>
   15b52:      	movb	$0x2f, (%rbx,%rax)
   15b56:      	xorl	%edi, %edi
   15b58:      	cmpl	%r15d, %r12d
   15b5b:      	seta	%dil
   15b5f:      	movzbl	%cl, %esi
   15b62:      	addq	%rax, %rbx
   15b65:      	addq	%rbx, %rdi
   15b68:      	movl	$0x4, %eax
   15b6d:      	callq	*%rax
   15b6f:      	movq	%rbx, 0x48(%rsp)
   15b74:      	cmpl	%r15d, %r12d
   15b77:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   15b7d:      	movq	0x8(%rsp), %r12
   15b82:      	movq	%r12, 0x30(%rsp)
   15b87:      	movq	0x38(%rsp), %rdx
   15b8c:      	movq	0x40(%rsp), %r15
   15b91:      	jmp	0x15be4 <generic_rawtp_path+0xb904>
   15b93:      	leaq	0x10(%r15), %rdx
   15b97:      	movl	$0x4, %eax
   15b9c:      	movq	%rbp, %rdi
   15b9f:      	movl	$0x8, %esi
   15ba4:      	callq	*%rax
   15ba6:      	movq	0x40(%rsp), %rax
   15bab:      	cmpq	(%rsp), %rax
   15baf:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15bb5:      	addq	$0x18, %r15
   15bb9:      	movl	$0x4, %eax
   15bbe:      	leaq	0x30(%rsp), %rdi
   15bc3:      	movl	$0x8, %esi
   15bc8:      	movq	%r15, %rdx
   15bcb:      	callq	*%rax
   15bcd:      	movq	(%rsp), %r15
   15bd1:      	movq	%r15, 0x40(%rsp)
   15bd6:      	leaq	0x20(%r15), %rdx
   15bda:      	movq	%rdx, 0x38(%rsp)
   15bdf:      	movq	0x30(%rsp), %r12
   15be4:      	cmpq	0x18(%rsp), %r12
   15be9:      	jne	0x15bf6 <generic_rawtp_path+0xb916>
   15beb:      	cmpq	0x20(%rsp), %rdx
   15bf0:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15bf6:      	movl	$0x4, %eax
   15bfb:      	leaq	0x10(%rsp), %rdi
   15c00:      	movl	$0x8, %esi
   15c05:      	callq	*%rax
   15c07:      	cmpq	0x10(%rsp), %r12
   15c0c:      	je	0x15cf6 <generic_rawtp_path+0xba16>
   15c12:      	leaq	0x18(%r12), %rbx
   15c17:      	movl	$0x4, %eax
   15c1c:      	movq	%rbp, %rdi
   15c1f:      	movl	$0x8, %esi
   15c24:      	movq	%rbx, %rdx
   15c27:      	callq	*%rax
   15c29:      	cmpq	%r12, (%rsp)
   15c2d:      	je	0x15cf6 <generic_rawtp_path+0xba16>
   15c33:      	movl	$0x4, %eax
   15c38:      	leaq	0x8(%rsp), %rdi
   15c3d:      	movl	$0x8, %esi
   15c42:      	movq	%rbx, %rdx
   15c45:      	callq	*%rax
   15c47:      	addq	$0x20, %r12
   15c4b:      	movl	$0x4, %eax
   15c50:      	leaq	0x58(%rsp), %rdi
   15c55:      	movl	$0x10, %ecx
   15c5a:      	movl	$0x10, %esi
   15c5f:      	movq	%r12, %rdx
   15c62:      	callq	*%rax
   15c64:      	movq	0x28(%rsp), %rbx
   15c69:      	movq	0x48(%rsp), %rax
   15c6e:      	movl	0x5c(%rsp), %r15d
   15c73:      	subq	%rbx, %rax
   15c76:      	movl	0x50(%rsp), %r12d
   15c7b:      	movl	%r15d, %edx
   15c7e:      	subl	%r12d, %edx
   15c81:      	movl	$0x0, %ecx
   15c86:      	cmovbl	%ecx, %edx
   15c89:      	addq	0x60(%rsp), %rdx
   15c8e:      	xorl	%esi, %esi
   15c90:      	cmpl	%r15d, %r12d
   15c93:      	seta	%sil
   15c97:      	movl	%r15d, %ecx
   15c9a:      	cmovbl	%r12d, %ecx
   15c9e:      	addl	%ecx, %esi
   15ca0:      	movl	%r12d, %edi
   15ca3:      	subl	%esi, %edi
   15ca5:      	movl	%edi, 0x50(%rsp)
   15ca9:      	subq	%rsi, %rax
   15cac:      	jb	0x15d52 <generic_rawtp_path+0xba72>
   15cb2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15cb8:      	ja	0x15d52 <generic_rawtp_path+0xba72>
   15cbe:      	cmpl	%r15d, %r12d
   15cc1:      	jbe	0x15cc7 <generic_rawtp_path+0xb9e7>
   15cc3:      	movb	$0x2f, (%rbx,%rax)
   15cc7:      	xorl	%edi, %edi
   15cc9:      	cmpl	%r15d, %r12d
   15ccc:      	seta	%dil
   15cd0:      	movzbl	%cl, %esi
   15cd3:      	addq	%rax, %rbx
   15cd6:      	addq	%rbx, %rdi
   15cd9:      	movl	$0x4, %eax
   15cde:      	callq	*%rax
   15ce0:      	movq	%rbx, 0x48(%rsp)
   15ce5:      	cmpl	%r15d, %r12d
   15ce8:      	jbe	0x15d52 <generic_rawtp_path+0xba72>
   15cea:      	movq	0x8(%rsp), %rax
   15cef:      	movq	%rax, 0x30(%rsp)
   15cf4:      	jmp	0x15d3e <generic_rawtp_path+0xba5e>
   15cf6:      	leaq	0x10(%r15), %rdx
   15cfa:      	movl	$0x4, %eax
   15cff:      	movq	%rbp, %rdi
   15d02:      	movl	$0x8, %esi
   15d07:      	callq	*%rax
   15d09:      	movq	0x40(%rsp), %rax
   15d0e:      	cmpq	(%rsp), %rax
   15d12:      	je	0x15d4d <generic_rawtp_path+0xba6d>
   15d14:      	addq	$0x18, %r15
   15d18:      	movl	$0x4, %eax
   15d1d:      	leaq	0x30(%rsp), %rdi
   15d22:      	movl	$0x8, %esi
   15d27:      	movq	%r15, %rdx
   15d2a:      	callq	*%rax
   15d2c:      	movq	(%rsp), %rax
   15d30:      	movq	%rax, 0x40(%rsp)
   15d35:      	addq	$0x20, %rax
   15d39:      	movq	%rax, 0x38(%rsp)
   15d3e:      	movl	0x6c(%rsp), %eax
   15d42:      	addl	$-0x80, %eax
   15d45:      	jne	0xa483 <generic_rawtp_path+0x1a3>
   15d4b:      	jmp	0x15d52 <generic_rawtp_path+0xba72>
   15d4d:      	movb	$0x1, 0x54(%rsp)
   15d52:      	movl	0x6428(%r14), %eax
   15d59:      	incl	%eax
   15d5b:      	movl	%eax, 0x6428(%r14)
   15d62:      	movl	0x48(%rsp), %ecx
   15d66:      	subl	0x80(%rsp), %ecx
   15d6d:      	movl	%ecx, 0x6424(%r14)
   15d74:      	cmpb	$0x0, 0x54(%rsp)
   15d79:      	jne	0x15dc1 <generic_rawtp_path+0xbae1>
   15d7b:      	cmpl	$0x8, %eax
   15d7e:      	je	0x15dc1 <generic_rawtp_path+0xbae1>
   15d80:      	movq	0x30(%rsp), %rax
   15d85:      	movq	%rax, 0x6458(%r14)
   15d8c:      	movq	0x38(%rsp), %rax
   15d91:      	movq	%rax, 0x6460(%r14)
   15d98:      	movq	0x40(%rsp), %rax
   15d9d:      	movq	%rax, 0x6468(%r14)
   15da4:      	movq	(%rip), %rcx            # 0x15dab <generic_rawtp_path+0xbacb>
   15dab:      	movl	$0x6, %edx
   15db0:      	movl	$0xc, %eax
   15db5:      	movq	0x78(%rsp), %rdi
   15dba:      	movl	$0x6, %edx
   15dbf:      	jmp	0x15ddc <generic_rawtp_path+0xbafc>
   15dc1:      	movq	(%rip), %rcx            # 0x15dc8 <generic_rawtp_path+0xbae8>
   15dc8:      	movl	$0x1, %edx
   15dcd:      	movl	$0xc, %eax
   15dd2:      	movq	0x78(%rsp), %rdi
   15dd7:      	movl	$0x1, %edx
   15ddc:      	movq	(%rip), %rsi            # 0x15de3 <generic_rawtp_path+0xbb03>
   15de3:      	jmp	0x16157 <generic_rawtp_path+0xbe77>
   15de8:      	movl	$0x1, (%rsp)
   15def:      	movq	(%rip), %rdi            # 0x15df6 <generic_rawtp_path+0xbb16>
   15df6:      	xorl	%ecx, %ecx
   15df8:      	leaq	0x18(%rsp), %rsi
   15dfd:      	movq	%rsp, %rdx
   15e00:      	movl	$0x2, %eax
   15e05:      	xorl	%ecx, %ecx
   15e07:      	callq	*%rax
   15e09:      	movq	0x58(%rsp), %r12
   15e0e:      	leaq	0x10(%r12), %rdx
   15e13:      	leaq	0x18(%rsp), %rdi
   15e18:      	movl	$0x8, %ecx
   15e1d:      	movl	$0x4, %eax
   15e22:      	leaq	0xfff(%r15), %rbx
   15e29:      	movl	$0x8, %esi
   15e2e:      	callq	*%rax
   15e30:      	cmpq	$0x0, 0x18(%rsp)
   15e36:      	jne	0x15e7f <generic_rawtp_path+0xbb9f>
   15e38:      	leaq	0x18(%r12), %rdx
   15e3d:      	leaq	0x18(%rsp), %rdi
   15e42:      	movl	$0x8, %ecx
   15e47:      	movl	$0x4, %eax
   15e4c:      	movl	$0x8, %esi
   15e51:      	callq	*%rax
   15e53:      	cmpq	%r12, 0x18(%rsp)
   15e58:      	je	0x15e7f <generic_rawtp_path+0xbb9f>
   15e5a:      	movq	%r15, %rbx
   15e5d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   15e64:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   15e6e:      	movq	%rax, 0xff5(%r15)
   15e75:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   15e7f:      	movl	$0x23, %eax
   15e84:      	callq	*%rax
   15e86:      	leaq	0xd50(%rax), %rdx
   15e8d:      	movq	%rsp, %rdi
   15e90:      	movl	$0x8, %ecx
   15e95:      	movl	$0x4, %eax
   15e9a:      	movl	$0x8, %esi
   15e9f:      	callq	*%rax
   15ea1:      	testq	%rax, %rax
   15ea4:      	je	0x15f03 <generic_rawtp_path+0xbc23>
   15ea6:      	negl	%eax
   15ea8:      	movw	%ax, 0x18(%rsp)
   15ead:      	movw	$0x6, 0x1a(%rsp)
   15eb4:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   15ebe:      	movq	%rax, 0x1c(%rsp)
   15ec3:      	movq	(%rip), %rdi            # 0x15eca <generic_rawtp_path+0xbbea>
   15eca:      	leaq	0x18(%rsp), %rsi
   15ecf:      	movl	$0x1, %eax
   15ed4:      	callq	*%rax
   15ed6:      	testq	%rax, %rax
   15ed9:      	je	0x15edf <generic_rawtp_path+0xbbff>
   15edb:      	incl	(%rax)
   15edd:      	jmp	0x15f03 <generic_rawtp_path+0xbc23>
   15edf:      	movl	$0x1, 0x8(%rsp)
   15ee7:      	movq	(%rip), %rdi            # 0x15eee <generic_rawtp_path+0xbc0e>
   15eee:      	xorl	%ecx, %ecx
   15ef0:      	leaq	0x18(%rsp), %rsi
   15ef5:      	leaq	0x8(%rsp), %rdx
   15efa:      	movl	$0x2, %eax
   15eff:      	xorl	%ecx, %ecx
   15f01:      	callq	*%rax
   15f03:      	movq	(%rsp), %rdx
   15f07:      	leaq	0x18(%rdx), %r13
   15f0b:      	movq	0x6440(%r14), %r12
   15f12:      	leaq	0x6448(%r14), %rdi
   15f19:      	addq	$0x20, %rdx
   15f1d:      	movl	$0x8, %ecx
   15f22:      	movl	$0x4, %eax
   15f27:      	movl	$0x8, %esi
   15f2c:      	callq	*%rax
   15f2e:      	testq	%rax, %rax
   15f31:      	je	0x15f90 <generic_rawtp_path+0xbcb0>
   15f33:      	negl	%eax
   15f35:      	movw	%ax, 0x18(%rsp)
   15f3a:      	movw	$0x6, 0x1a(%rsp)
   15f41:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   15f4b:      	movq	%rax, 0x1c(%rsp)
   15f50:      	movq	(%rip), %rdi            # 0x15f57 <generic_rawtp_path+0xbc77>
   15f57:      	leaq	0x18(%rsp), %rsi
   15f5c:      	movl	$0x1, %eax
   15f61:      	callq	*%rax
   15f63:      	testq	%rax, %rax
   15f66:      	je	0x15f6c <generic_rawtp_path+0xbc8c>
   15f68:      	incl	(%rax)
   15f6a:      	jmp	0x15f90 <generic_rawtp_path+0xbcb0>
   15f6c:      	movl	$0x1, 0x8(%rsp)
   15f74:      	movq	(%rip), %rdi            # 0x15f7b <generic_rawtp_path+0xbc9b>
   15f7b:      	xorl	%ecx, %ecx
   15f7d:      	leaq	0x18(%rsp), %rsi
   15f82:      	leaq	0x8(%rsp), %rdx
   15f87:      	movl	$0x2, %eax
   15f8c:      	xorl	%ecx, %ecx
   15f8e:      	callq	*%rax
   15f90:      	leaq	0x6450(%r14), %rdi
   15f97:      	movl	$0x8, %ecx
   15f9c:      	movl	$0x4, %eax
   15fa1:      	movl	$0x8, %esi
   15fa6:      	movq	%r13, %rdx
   15fa9:      	callq	*%rax
   15fab:      	testq	%rax, %rax
   15fae:      	je	0x1600d <generic_rawtp_path+0xbd2d>
   15fb0:      	negl	%eax
   15fb2:      	movw	%ax, 0x18(%rsp)
   15fb7:      	movw	$0x6, 0x1a(%rsp)
   15fbe:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   15fc8:      	movq	%rax, 0x1c(%rsp)
   15fcd:      	movq	(%rip), %rdi            # 0x15fd4 <generic_rawtp_path+0xbcf4>
   15fd4:      	leaq	0x18(%rsp), %rsi
   15fd9:      	movl	$0x1, %eax
   15fde:      	callq	*%rax
   15fe0:      	testq	%rax, %rax
   15fe3:      	je	0x15fe9 <generic_rawtp_path+0xbd09>
   15fe5:      	incl	(%rax)
   15fe7:      	jmp	0x1600d <generic_rawtp_path+0xbd2d>
   15fe9:      	movl	$0x1, 0x8(%rsp)
   15ff1:      	movq	(%rip), %rdi            # 0x15ff8 <generic_rawtp_path+0xbd18>
   15ff8:      	xorl	%ecx, %ecx
   15ffa:      	leaq	0x18(%rsp), %rsi
   15fff:      	leaq	0x8(%rsp), %rdx
   16004:      	movl	$0x2, %eax
   16009:      	xorl	%ecx, %ecx
   1600b:      	callq	*%rax
   1600d:      	leaq	0x6458(%r14), %rdi
   16014:      	leaq	0x8(%r12), %rdx
   16019:      	movl	$0x8, %ecx
   1601e:      	movl	$0x4, %eax
   16023:      	movl	$0x8, %esi
   16028:      	callq	*%rax
   1602a:      	testq	%rax, %rax
   1602d:      	je	0x1608c <generic_rawtp_path+0xbdac>
   1602f:      	negl	%eax
   16031:      	movw	%ax, 0x18(%rsp)
   16036:      	movw	$0x6, 0x1a(%rsp)
   1603d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   16047:      	movq	%rax, 0x1c(%rsp)
   1604c:      	movq	(%rip), %rdi            # 0x16053 <generic_rawtp_path+0xbd73>
   16053:      	leaq	0x18(%rsp), %rsi
   16058:      	movl	$0x1, %eax
   1605d:      	callq	*%rax
   1605f:      	testq	%rax, %rax
   16062:      	je	0x16068 <generic_rawtp_path+0xbd88>
   16064:      	incl	(%rax)
   16066:      	jmp	0x1608c <generic_rawtp_path+0xbdac>
   16068:      	movl	$0x1, 0x8(%rsp)
   16070:      	movq	(%rip), %rdi            # 0x16077 <generic_rawtp_path+0xbd97>
   16077:      	xorl	%ecx, %ecx
   16079:      	leaq	0x18(%rsp), %rsi
   1607e:      	leaq	0x8(%rsp), %rdx
   16083:      	movl	$0x2, %eax
   16088:      	xorl	%ecx, %ecx
   1608a:      	callq	*%rax
   1608c:      	movq	%r14, %rdi
   1608f:      	addq	$0x6460, %rdi           # imm = 0x6460
   16096:      	movl	$0x8, %ecx
   1609b:      	movl	$0x4, %eax
   160a0:      	movl	$0x8, %esi
   160a5:      	movq	%r12, %rdx
   160a8:      	callq	*%rax
   160aa:      	testq	%rax, %rax
   160ad:      	je	0x1610c <generic_rawtp_path+0xbe2c>
   160af:      	negl	%eax
   160b1:      	movw	%ax, 0x18(%rsp)
   160b6:      	movw	$0x6, 0x1a(%rsp)
   160bd:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   160c7:      	movq	%rax, 0x1c(%rsp)
   160cc:      	movq	(%rip), %rdi            # 0x160d3 <generic_rawtp_path+0xbdf3>
   160d3:      	leaq	0x18(%rsp), %rsi
   160d8:      	movl	$0x1, %eax
   160dd:      	callq	*%rax
   160df:      	testq	%rax, %rax
   160e2:      	je	0x160e8 <generic_rawtp_path+0xbe08>
   160e4:      	incl	(%rax)
   160e6:      	jmp	0x1610c <generic_rawtp_path+0xbe2c>
   160e8:      	movl	$0x1, 0x8(%rsp)
   160f0:      	movq	(%rip), %rdi            # 0x160f7 <generic_rawtp_path+0xbe17>
   160f7:      	xorl	%ecx, %ecx
   160f9:      	leaq	0x18(%rsp), %rsi
   160fe:      	leaq	0x8(%rsp), %rdx
   16103:      	movl	$0x2, %eax
   16108:      	xorl	%ecx, %ecx
   1610a:      	callq	*%rax
   1610c:      	movq	0x6460(%r14), %rax
   16113:      	addq	$-0x20, %rax
   16117:      	movq	%rax, 0x6468(%r14)
   1611e:      	movl	$0x0, 0x6428(%r14)
   16129:      	subl	%r15d, %ebx
   1612c:      	movl	%ebx, 0x6424(%r14)
   16133:      	movl	$0x1, 0x6420(%r14)
   1613e:      	movq	(%rip), %rsi            # 0x16145 <generic_rawtp_path+0xbe65>
   16145:      	movl	$0x6, %ecx
   1614a:      	movl	$0xc, %eax
   1614f:      	movq	%rbp, %rdi
   16152:      	movl	$0x6, %edx
   16157:      	callq	*%rax
   16159:      	xorl	%eax, %eax
   1615b:      	addq	$0x88, %rsp
   16162:      	popq	%rbx
   16163:      	popq	%r12
   16165:      	popq	%r13
   16167:      	popq	%r14
   16169:      	popq	%r15
   1616b:      	popq	%rbp
   1616c:      	retq

Disassembly of section raw_tp/generic_tracepoint:

0000000000000000 <generic_rawtp_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_rawtp_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_rawtp_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_rawtp_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_rawtp_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_rawtp_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_rawtp_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_rawtp_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_rawtp_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_rawtp_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_rawtp_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_rawtp_event+0x1f6>
      d3:      	jmp	0x62d <generic_rawtp_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_rawtp_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_rawtp_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_rawtp_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_rawtp_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_rawtp_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_rawtp_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_rawtp_event+0x1f6>
     1e1:      	jmp	0x62d <generic_rawtp_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_rawtp_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_rawtp_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_rawtp_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_rawtp_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_rawtp_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_rawtp_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_rawtp_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_rawtp_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_rawtp_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_rawtp_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_rawtp_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_rawtp_event+0x62d>
     695:      	jmp	0x23b <generic_rawtp_event+0x23b>
