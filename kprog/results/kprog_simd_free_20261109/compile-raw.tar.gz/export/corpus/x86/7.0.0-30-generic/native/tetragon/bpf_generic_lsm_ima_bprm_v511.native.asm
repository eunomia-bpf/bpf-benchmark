
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_ima_bprm_v511.native.o:	file format elf64-x86-64

Disassembly of section lsm.s/generic_lsm_ima_bprm:

0000000000000000 <ima_bprm>:
       0:      	pushq	%rbx
       1:      	subq	$0x50, %rsp
       5:      	movq	(%rdi), %rbx
       8:      	movl	$0xe, %eax
       d:      	callq	*%rax
       f:      	movq	%rax, (%rsp)
      13:      	movq	(%rip), %rdi            # 0x1a <ima_bprm+0x1a>
      1a:      	movq	%rsp, %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	je	0x6f <ima_bprm+0x6f>
      29:      	cmpb	$0x1, (%rax)
      2c:      	jne	0x6f <ima_bprm+0x6f>
      2e:      	movq	0x40(%rbx), %rcx
      32:      	leaq	0x10(%rsp), %rsi
      37:      	movl	$0x40, %edx
      3c:      	movl	$0xc1, %eax
      41:      	movq	0x40(%rbx), %rdi
      45:      	movl	$0x40, %edx
      4a:      	callq	*%rax
      4c:      	movb	%al, 0xf(%rsp)
      50:      	movb	$0x2, 0xe(%rsp)
      55:      	movq	(%rip), %rdi            # 0x5c <ima_bprm+0x5c>
      5c:      	xorl	%ecx, %ecx
      5e:      	movq	%rsp, %rsi
      61:      	leaq	0xe(%rsp), %rdx
      66:      	movl	$0x2, %eax
      6b:      	xorl	%ecx, %ecx
      6d:      	callq	*%rax
      6f:      	xorl	%eax, %eax
      71:      	addq	$0x50, %rsp
      75:      	popq	%rbx
      76:      	retq
