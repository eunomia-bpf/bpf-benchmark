
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_exit_v511.native.o:	file format elf64-x86-64

Disassembly of section kprobe/acct_process:

0000000000000000 <event_exit_acct_process>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movq	%rdi, %r15
      10:      	movl	$0xe, %eax
      15:      	callq	*%rax
      17:      	movq	%rax, %r14
      1a:      	shrq	$0x20, %r14
      1e:      	movl	%r14d, 0x4(%rsp)
      23:      	movq	(%rip), %rdi            # 0x2a <event_exit_acct_process+0x2a>
      2a:      	leaq	0x4(%rsp), %rsi
      2f:      	movl	$0x1, %eax
      34:      	callq	*%rax
      36:      	testq	%rax, %rax
      39:      	je	0x2a7 <event_exit_acct_process+0x2a7>
      3f:      	movq	%rax, %rbx
      42:      	cmpq	$0x0, 0x8(%rax)
      47:      	je	0x232 <event_exit_acct_process+0x232>
      4d:      	movl	$0x23, %eax
      52:      	callq	*%rax
      54:      	movq	%rax, %r13
      57:      	movl	$0x0, 0xc(%rsp)
      5f:      	movq	(%rip), %rdi            # 0x66 <event_exit_acct_process+0x66>
      66:      	leaq	0xc(%rsp), %rsi
      6b:      	movl	$0x1, %eax
      70:      	callq	*%rax
      72:      	testq	%rax, %rax
      75:      	je	0x2a7 <event_exit_acct_process+0x2a7>
      7b:      	movq	%rax, %r12
      7e:      	movabsq	$0x2800000007, %rax     # imm = 0x2800000007
      88:      	movq	%rax, (%r12)
      8c:      	movl	$0x7d, %eax
      91:      	callq	*%rax
      93:      	movq	%rax, 0x8(%r12)
      98:      	movl	%r14d, 0x10(%r12)
      9d:      	movl	$0x0, 0x14(%r12)
      a6:      	movq	0x8(%rbx), %rax
      aa:      	movq	%rax, 0x18(%r12)
      af:      	movq	%r12, %rdi
      b2:      	addq	$0x20, %rdi
      b6:      	movl	%r14d, 0x24(%r12)
      bb:      	addq	$0xa8c, %r13            # imm = 0xA8C
      c2:      	movl	$0x4, %ecx
      c7:      	movl	$0x4, %eax
      cc:      	movl	$0x4, %esi
      d1:      	movq	%r13, %rdx
      d4:      	callq	*%rax
      d6:      	movl	$0x0, 0x8(%rsp)
      de:      	movq	(%rip), %rdi            # 0xe5 <event_exit_acct_process+0xe5>
      e5:      	leaq	0x8(%rsp), %rsi
      ea:      	movl	$0x1, %eax
      ef:      	callq	*%rax
      f1:      	testq	%rax, %rax
      f4:      	je	0x17e <event_exit_acct_process+0x17e>
      fa:      	cmpb	$0x0, 0x28(%rax)
      fe:      	je	0x17e <event_exit_acct_process+0x17e>
     100:      	movq	(%rip), %rsi            # 0x107 <event_exit_acct_process+0x107>
     107:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     10c:      	movl	$0x28, %edx
     111:      	movl	$0x19, %eax
     116:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     11b:      	movl	$0x28, %r8d
     121:      	movq	%r15, %rdi
     124:      	movq	%r12, %rcx
     127:      	callq	*%rax
     129:      	testq	%rax, %rax
     12c:      	jns	0x232 <event_exit_acct_process+0x232>
     132:      	movq	%rax, %r15
     135:      	movl	$0x0, 0x4(%rsp)
     13d:      	movq	(%rip), %rdi            # 0x144 <event_exit_acct_process+0x144>
     144:      	leaq	0x4(%rsp), %rsi
     149:      	movl	$0x1, %eax
     14e:      	callq	*%rax
     150:      	testq	%rax, %rax
     153:      	je	0x232 <event_exit_acct_process+0x232>
     159:      	cmpq	$-0xc, %r15
     15d:      	jg	0x1fe <event_exit_acct_process+0x1fe>
     163:      	cmpq	$-0x1c, %r15
     167:      	je	0x218 <event_exit_acct_process+0x218>
     16d:      	cmpq	$-0x16, %r15
     171:      	jne	0x1d6 <event_exit_acct_process+0x1d6>
     173:      	addq	$0x1a8, %rax            # imm = 0x1A8
     179:      	jmp	0x22e <event_exit_acct_process+0x22e>
     17e:      	movq	(%rip), %rdi            # 0x185 <event_exit_acct_process+0x185>
     185:      	xorl	%ecx, %ecx
     187:      	movl	$0x28, %edx
     18c:      	movl	$0x82, %eax
     191:      	movq	%r12, %rsi
     194:      	xorl	%ecx, %ecx
     196:      	callq	*%rax
     198:      	testq	%rax, %rax
     19b:      	jns	0x232 <event_exit_acct_process+0x232>
     1a1:      	movq	%rax, %r15
     1a4:      	movl	$0x0, 0x4(%rsp)
     1ac:      	movq	(%rip), %rdi            # 0x1b3 <event_exit_acct_process+0x1b3>
     1b3:      	leaq	0x4(%rsp), %rsi
     1b8:      	movl	$0x1, %eax
     1bd:      	callq	*%rax
     1bf:      	testq	%rax, %rax
     1c2:      	je	0x232 <event_exit_acct_process+0x232>
     1c4:      	cmpq	$-0xc, %r15
     1c8:      	jg	0x1e4 <event_exit_acct_process+0x1e4>
     1ca:      	cmpq	$-0x1c, %r15
     1ce:      	je	0x218 <event_exit_acct_process+0x218>
     1d0:      	cmpq	$-0x16, %r15
     1d4:      	je	0x173 <event_exit_acct_process+0x173>
     1d6:      	cmpq	$-0x10, %r15
     1da:      	jne	0x210 <event_exit_acct_process+0x210>
     1dc:      	addq	$0x1a0, %rax            # imm = 0x1A0
     1e2:      	jmp	0x22e <event_exit_acct_process+0x22e>
     1e4:      	cmpq	$-0xb, %r15
     1e8:      	je	0x220 <event_exit_acct_process+0x220>
     1ea:      	cmpq	$-0x7, %r15
     1ee:      	je	0x228 <event_exit_acct_process+0x228>
     1f0:      	cmpq	$-0x2, %r15
     1f4:      	jne	0x210 <event_exit_acct_process+0x210>
     1f6:      	addq	$0x190, %rax            # imm = 0x190
     1fc:      	jmp	0x22e <event_exit_acct_process+0x22e>
     1fe:      	cmpq	$-0xb, %r15
     202:      	je	0x220 <event_exit_acct_process+0x220>
     204:      	cmpq	$-0x7, %r15
     208:      	je	0x228 <event_exit_acct_process+0x228>
     20a:      	cmpq	$-0x2, %r15
     20e:      	je	0x1f6 <event_exit_acct_process+0x1f6>
     210:      	addq	$0x188, %rax            # imm = 0x188
     216:      	jmp	0x22e <event_exit_acct_process+0x22e>
     218:      	addq	$0x1b0, %rax            # imm = 0x1B0
     21e:      	jmp	0x22e <event_exit_acct_process+0x22e>
     220:      	addq	$0x1b8, %rax            # imm = 0x1B8
     226:      	jmp	0x22e <event_exit_acct_process+0x22e>
     228:      	addq	$0x198, %rax            # imm = 0x198
     22e:      	lock
     22f:      	incq	(%rax)
     232:      	movl	%r14d, 0x8(%rsp)
     237:      	movq	(%rip), %rdi            # 0x23e <event_exit_acct_process+0x23e>
     23e:      	leaq	0x8(%rsp), %rsi
     243:      	movl	$0x3, %eax
     248:      	callq	*%rax
     24a:      	testl	%eax, %eax
     24c:      	je	0x273 <event_exit_acct_process+0x273>
     24e:      	movl	$0x2, 0x4(%rsp)
     256:      	movq	(%rip), %rdi            # 0x25d <event_exit_acct_process+0x25d>
     25d:      	leaq	0x4(%rsp), %rsi
     262:      	movl	$0x1, %eax
     267:      	callq	*%rax
     269:      	testq	%rax, %rax
     26c:      	je	0x296 <event_exit_acct_process+0x296>
     26e:      	incq	(%rax)
     271:      	jmp	0x296 <event_exit_acct_process+0x296>
     273:      	movl	$0x0, 0x4(%rsp)
     27b:      	movq	(%rip), %rdi            # 0x282 <event_exit_acct_process+0x282>
     282:      	leaq	0x4(%rsp), %rsi
     287:      	movl	$0x1, %eax
     28c:      	callq	*%rax
     28e:      	testq	%rax, %rax
     291:      	je	0x296 <event_exit_acct_process+0x296>
     293:      	decq	(%rax)
     296:      	movq	(%rip), %rdi            # 0x29d <event_exit_acct_process+0x29d>
     29d:      	movl	$0x3, %eax
     2a2:      	movq	%rbx, %rsi
     2a5:      	callq	*%rax
     2a7:      	xorl	%eax, %eax
     2a9:      	addq	$0x10, %rsp
     2ad:      	popq	%rbx
     2ae:      	popq	%r12
     2b0:      	popq	%r13
     2b2:      	popq	%r14
     2b4:      	popq	%r15
     2b6:      	retq

Disassembly of section kprobe/disassociate_ctty:

0000000000000000 <event_exit_disassociate_ctty>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movq	%rdi, %r15
      10:      	leaq	0x70(%rdi), %rdx
      14:      	movq	%rsp, %rdi
      17:      	movl	$0x8, %ecx
      1c:      	movl	$0x4, %eax
      21:      	movl	$0x8, %esi
      26:      	callq	*%rax
      28:      	cmpl	$0x0, (%rsp)
      2c:      	je	0x2ba <event_exit_disassociate_ctty+0x2ba>
      32:      	movl	$0xe, %eax
      37:      	callq	*%rax
      39:      	movq	%rax, %r14
      3c:      	shrq	$0x20, %r14
      40:      	movl	%r14d, (%rsp)
      44:      	movq	(%rip), %rdi            # 0x4b <event_exit_disassociate_ctty+0x4b>
      4b:      	movq	%rsp, %rsi
      4e:      	movl	$0x1, %eax
      53:      	callq	*%rax
      55:      	testq	%rax, %rax
      58:      	je	0x2ba <event_exit_disassociate_ctty+0x2ba>
      5e:      	movq	%rax, %rbx
      61:      	cmpq	$0x0, 0x8(%rax)
      66:      	je	0x24b <event_exit_disassociate_ctty+0x24b>
      6c:      	movl	$0x23, %eax
      71:      	callq	*%rax
      73:      	movq	%rax, %r13
      76:      	movl	$0x0, 0xc(%rsp)
      7e:      	movq	(%rip), %rdi            # 0x85 <event_exit_disassociate_ctty+0x85>
      85:      	leaq	0xc(%rsp), %rsi
      8a:      	movl	$0x1, %eax
      8f:      	callq	*%rax
      91:      	testq	%rax, %rax
      94:      	je	0x2ba <event_exit_disassociate_ctty+0x2ba>
      9a:      	movq	%rax, %r12
      9d:      	movabsq	$0x2800000007, %rax     # imm = 0x2800000007
      a7:      	movq	%rax, (%r12)
      ab:      	movl	$0x7d, %eax
      b0:      	callq	*%rax
      b2:      	movq	%rax, 0x8(%r12)
      b7:      	movl	%r14d, 0x10(%r12)
      bc:      	movl	$0x0, 0x14(%r12)
      c5:      	movq	0x8(%rbx), %rax
      c9:      	movq	%rax, 0x18(%r12)
      ce:      	movq	%r12, %rdi
      d1:      	addq	$0x20, %rdi
      d5:      	movl	%r14d, 0x24(%r12)
      da:      	addq	$0xa8c, %r13            # imm = 0xA8C
      e1:      	movl	$0x4, %ecx
      e6:      	movl	$0x4, %eax
      eb:      	movl	$0x4, %esi
      f0:      	movq	%r13, %rdx
      f3:      	callq	*%rax
      f5:      	movl	$0x0, 0x8(%rsp)
      fd:      	movq	(%rip), %rdi            # 0x104 <event_exit_disassociate_ctty+0x104>
     104:      	leaq	0x8(%rsp), %rsi
     109:      	movl	$0x1, %eax
     10e:      	callq	*%rax
     110:      	testq	%rax, %rax
     113:      	je	0x19a <event_exit_disassociate_ctty+0x19a>
     119:      	cmpb	$0x0, 0x28(%rax)
     11d:      	je	0x19a <event_exit_disassociate_ctty+0x19a>
     11f:      	movq	(%rip), %rsi            # 0x126 <event_exit_disassociate_ctty+0x126>
     126:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     12b:      	movl	$0x28, %edx
     130:      	movl	$0x19, %eax
     135:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     13a:      	movl	$0x28, %r8d
     140:      	movq	%r15, %rdi
     143:      	movq	%r12, %rcx
     146:      	callq	*%rax
     148:      	testq	%rax, %rax
     14b:      	jns	0x24b <event_exit_disassociate_ctty+0x24b>
     151:      	movq	%rax, %r15
     154:      	movl	$0x0, (%rsp)
     15b:      	movq	(%rip), %rdi            # 0x162 <event_exit_disassociate_ctty+0x162>
     162:      	movq	%rsp, %rsi
     165:      	movl	$0x1, %eax
     16a:      	callq	*%rax
     16c:      	testq	%rax, %rax
     16f:      	je	0x24b <event_exit_disassociate_ctty+0x24b>
     175:      	cmpq	$-0xc, %r15
     179:      	jg	0x217 <event_exit_disassociate_ctty+0x217>
     17f:      	cmpq	$-0x1c, %r15
     183:      	je	0x231 <event_exit_disassociate_ctty+0x231>
     189:      	cmpq	$-0x16, %r15
     18d:      	jne	0x1ef <event_exit_disassociate_ctty+0x1ef>
     18f:      	addq	$0x1a8, %rax            # imm = 0x1A8
     195:      	jmp	0x247 <event_exit_disassociate_ctty+0x247>
     19a:      	movq	(%rip), %rdi            # 0x1a1 <event_exit_disassociate_ctty+0x1a1>
     1a1:      	xorl	%ecx, %ecx
     1a3:      	movl	$0x28, %edx
     1a8:      	movl	$0x82, %eax
     1ad:      	movq	%r12, %rsi
     1b0:      	xorl	%ecx, %ecx
     1b2:      	callq	*%rax
     1b4:      	testq	%rax, %rax
     1b7:      	jns	0x24b <event_exit_disassociate_ctty+0x24b>
     1bd:      	movq	%rax, %r15
     1c0:      	movl	$0x0, (%rsp)
     1c7:      	movq	(%rip), %rdi            # 0x1ce <event_exit_disassociate_ctty+0x1ce>
     1ce:      	movq	%rsp, %rsi
     1d1:      	movl	$0x1, %eax
     1d6:      	callq	*%rax
     1d8:      	testq	%rax, %rax
     1db:      	je	0x24b <event_exit_disassociate_ctty+0x24b>
     1dd:      	cmpq	$-0xc, %r15
     1e1:      	jg	0x1fd <event_exit_disassociate_ctty+0x1fd>
     1e3:      	cmpq	$-0x1c, %r15
     1e7:      	je	0x231 <event_exit_disassociate_ctty+0x231>
     1e9:      	cmpq	$-0x16, %r15
     1ed:      	je	0x18f <event_exit_disassociate_ctty+0x18f>
     1ef:      	cmpq	$-0x10, %r15
     1f3:      	jne	0x229 <event_exit_disassociate_ctty+0x229>
     1f5:      	addq	$0x1a0, %rax            # imm = 0x1A0
     1fb:      	jmp	0x247 <event_exit_disassociate_ctty+0x247>
     1fd:      	cmpq	$-0xb, %r15
     201:      	je	0x239 <event_exit_disassociate_ctty+0x239>
     203:      	cmpq	$-0x7, %r15
     207:      	je	0x241 <event_exit_disassociate_ctty+0x241>
     209:      	cmpq	$-0x2, %r15
     20d:      	jne	0x229 <event_exit_disassociate_ctty+0x229>
     20f:      	addq	$0x190, %rax            # imm = 0x190
     215:      	jmp	0x247 <event_exit_disassociate_ctty+0x247>
     217:      	cmpq	$-0xb, %r15
     21b:      	je	0x239 <event_exit_disassociate_ctty+0x239>
     21d:      	cmpq	$-0x7, %r15
     221:      	je	0x241 <event_exit_disassociate_ctty+0x241>
     223:      	cmpq	$-0x2, %r15
     227:      	je	0x20f <event_exit_disassociate_ctty+0x20f>
     229:      	addq	$0x188, %rax            # imm = 0x188
     22f:      	jmp	0x247 <event_exit_disassociate_ctty+0x247>
     231:      	addq	$0x1b0, %rax            # imm = 0x1B0
     237:      	jmp	0x247 <event_exit_disassociate_ctty+0x247>
     239:      	addq	$0x1b8, %rax            # imm = 0x1B8
     23f:      	jmp	0x247 <event_exit_disassociate_ctty+0x247>
     241:      	addq	$0x198, %rax            # imm = 0x198
     247:      	lock
     248:      	incq	(%rax)
     24b:      	movl	%r14d, 0x8(%rsp)
     250:      	movq	(%rip), %rdi            # 0x257 <event_exit_disassociate_ctty+0x257>
     257:      	leaq	0x8(%rsp), %rsi
     25c:      	movl	$0x3, %eax
     261:      	callq	*%rax
     263:      	testl	%eax, %eax
     265:      	je	0x289 <event_exit_disassociate_ctty+0x289>
     267:      	movl	$0x2, (%rsp)
     26e:      	movq	(%rip), %rdi            # 0x275 <event_exit_disassociate_ctty+0x275>
     275:      	movq	%rsp, %rsi
     278:      	movl	$0x1, %eax
     27d:      	callq	*%rax
     27f:      	testq	%rax, %rax
     282:      	je	0x2a9 <event_exit_disassociate_ctty+0x2a9>
     284:      	incq	(%rax)
     287:      	jmp	0x2a9 <event_exit_disassociate_ctty+0x2a9>
     289:      	movl	$0x0, (%rsp)
     290:      	movq	(%rip), %rdi            # 0x297 <event_exit_disassociate_ctty+0x297>
     297:      	movq	%rsp, %rsi
     29a:      	movl	$0x1, %eax
     29f:      	callq	*%rax
     2a1:      	testq	%rax, %rax
     2a4:      	je	0x2a9 <event_exit_disassociate_ctty+0x2a9>
     2a6:      	decq	(%rax)
     2a9:      	movq	(%rip), %rdi            # 0x2b0 <event_exit_disassociate_ctty+0x2b0>
     2b0:      	movl	$0x3, %eax
     2b5:      	movq	%rbx, %rsi
     2b8:      	callq	*%rax
     2ba:      	xorl	%eax, %eax
     2bc:      	addq	$0x10, %rsp
     2c0:      	popq	%rbx
     2c1:      	popq	%r12
     2c3:      	popq	%r13
     2c5:      	popq	%r14
     2c7:      	popq	%r15
     2c9:      	retq
