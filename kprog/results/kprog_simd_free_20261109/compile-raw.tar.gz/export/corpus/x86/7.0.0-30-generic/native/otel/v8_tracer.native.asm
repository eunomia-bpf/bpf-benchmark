
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/v8_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_v8:

0000000000000000 <perf_unwind_v8>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, (%rsp)
      1b:      	movq	(%rip), %rdi            # 0x22 <perf_unwind_v8+0x22>
      22:      	movq	%rsp, %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x212f <perf_unwind_v8+0x212f>
      35:      	movq	%rax, %r14
      38:      	movl	(%rax), %eax
      3a:      	movl	%eax, 0xc4(%rsp)
      41:      	movq	(%rip), %rbp            # 0x48 <perf_unwind_v8+0x48>
      48:      	cmpl	$0x0, (%rbp)
      4c:      	jne	0x6c6 <perf_unwind_v8+0x6c6>
      52:      	movq	(%rip), %rdi            # 0x59 <perf_unwind_v8+0x59>
      59:      	leaq	0xc4(%rsp), %rsi
      61:      	movl	$0x1, %eax
      66:      	callq	*%rax
      68:      	testq	%rax, %rax
      6b:      	je	0x97 <perf_unwind_v8+0x97>
      6d:      	movq	%rax, 0x48(%rsp)
      72:      	movl	$0x37, 0x70(%rsp)
      7a:      	movq	(%rip), %rdi            # 0x81 <perf_unwind_v8+0x81>
      81:      	leaq	0x70(%rsp), %rsi
      86:      	movl	$0x1, %eax
      8b:      	callq	*%rax
      8d:      	testq	%rax, %rax
      90:      	je	0xcd <perf_unwind_v8+0xcd>
      92:      	incq	(%rax)
      95:      	jmp	0xd7 <perf_unwind_v8+0xd7>
      97:      	cmpl	$0x0, (%rbp)
      9b:      	jne	0xa42 <perf_unwind_v8+0xa42>
      a1:      	movl	$0x54, 0x70(%rsp)
      a9:      	movq	(%rip), %rdi            # 0xb0 <perf_unwind_v8+0xb0>
      b0:      	leaq	0x70(%rsp), %rsi
      b5:      	movl	$0x1, %eax
      ba:      	callq	*%rax
      bc:      	testq	%rax, %rax
      bf:      	je	0x1db <perf_unwind_v8+0x1db>
      c5:      	incq	(%rax)
      c8:      	jmp	0x1e5 <perf_unwind_v8+0x1e5>
      cd:      	cmpl	$0x0, (%rbp)
      d1:      	jne	0xa98 <perf_unwind_v8+0xa98>
      d7:      	movq	0xed0(%r14), %r13
      de:      	movq	0xed8(%r14), %r12
      e5:      	movq	0xee0(%r14), %rdx
      ec:      	cmpl	$0x0, (%rbp)
      f0:      	jne	0x8bb <perf_unwind_v8+0x8bb>
      f6:      	cmpq	%r12, %rdx
      f9:      	jb	0x202f <perf_unwind_v8+0x202f>
      ff:      	leaq	0x2000(%r12), %rax
     107:      	cmpq	%rax, %rdx
     10a:      	jae	0x202f <perf_unwind_v8+0x202f>
     110:      	leaq	0xf80(%r14), %r15
     117:      	addq	$-0x40, %rdx
     11b:      	movl	$0x40, %eax
     120:      	movl	$0x70, %ecx
     125:      	movq	%r15, %rdi
     128:      	movl	$0x40, %esi
     12d:      	callq	*%rcx
     12f:      	testq	%rax, %rax
     132:      	je	0x1f0 <perf_unwind_v8+0x1f0>
     138:      	cmpl	$0x0, (%rbp)
     13c:      	jne	0xb10 <perf_unwind_v8+0xb10>
     142:      	movl	$0x39, 0x70(%rsp)
     14a:      	movq	(%rip), %rdi            # 0x151 <perf_unwind_v8+0x151>
     151:      	leaq	0x70(%rsp), %rsi
     156:      	movl	$0x1, %eax
     15b:      	callq	*%rax
     15d:      	testq	%rax, %rax
     160:      	jne	0x2059 <perf_unwind_v8+0x2059>
     166:      	cmpl	$0x0, (%rbp)
     16a:      	je	0x2068 <perf_unwind_v8+0x2068>
     170:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     17a:      	movq	%rax, 0x26(%rsp)
     17f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     189:      	movq	%rax, 0x20(%rsp)
     18e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     198:      	movq	%rax, 0x18(%rsp)
     19d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     1a7:      	movq	%rax, 0x10(%rsp)
     1ac:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     1b6:      	movq	%rax, 0x8(%rsp)
     1bb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     1c5:      	movq	%rax, (%rsp)
     1c9:      	movq	%rsp, %rdi
     1cc:      	movl	$0x2e, %eax
     1d1:      	movl	$0x6, %ecx
     1d6:      	jmp	0x2299 <perf_unwind_v8+0x2299>
     1db:      	cmpl	$0x0, (%rbp)
     1df:      	jne	0xca2 <perf_unwind_v8+0xca2>
     1e5:      	movl	$0x138a, %r12d          # imm = 0x138A
     1eb:      	jmp	0x206e <perf_unwind_v8+0x206e>
     1f0:      	movq	%r15, 0x98(%rsp)
     1f8:      	movq	0x48(%rsp), %r8
     1fd:      	movzbl	0x14(%r8), %eax
     202:      	xorl	%ebp, %ebp
     204:      	cmpq	$0x38, %rax
     208:      	ja	0x220 <perf_unwind_v8+0x220>
     20a:      	movzbl	0x15(%r8), %ecx
     20f:      	cmpq	$0x38, %rcx
     213:      	ja	0x220 <perf_unwind_v8+0x220>
     215:      	movzbl	0x16(%r8), %edi
     21a:      	cmpq	$0x38, %rdi
     21e:      	jbe	0x22b <perf_unwind_v8+0x22b>
     220:      	movl	$0x1, %r12d
     226:      	jmp	0x2070 <perf_unwind_v8+0x2070>
     22b:      	movq	%r14, %rsi
     22e:      	addq	$0xfc0, %rsi            # imm = 0xFC0
     235:      	movq	%rsi, 0xb0(%rsp)
     23d:      	movq	0x98(%rsp), %rsi
     245:      	movq	(%rsi,%rax), %rdx
     249:      	testb	$0x1, %dl
     24c:      	jne	0x2ba <perf_unwind_v8+0x2ba>
     24e:      	shrq	%rdx
     251:      	movq	(%rip), %rax            # 0x258 <perf_unwind_v8+0x258>
     258:      	cmpl	$0x0, (%rax)
     25b:      	jne	0xe74 <perf_unwind_v8+0xe74>
     261:      	xorl	%r15d, %r15d
     264:      	movzbl	0xf30(%r14), %ebp
     26c:      	movl	0x2c0(%r14), %eax
     273:      	cmpq	$0x7f, %rax
     277:      	jb	0x35f <perf_unwind_v8+0x35f>
     27d:      	movq	(%rip), %r15            # 0x284 <perf_unwind_v8+0x284>
     284:      	cmpl	$0x0, (%r15)
     288:      	jne	0xf4e <perf_unwind_v8+0xf4e>
     28e:      	movl	$0x2, 0x70(%rsp)
     296:      	movq	(%rip), %rdi            # 0x29d <perf_unwind_v8+0x29d>
     29d:      	leaq	0x70(%rsp), %rsi
     2a2:      	movl	$0x1, %eax
     2a7:      	callq	*%rax
     2a9:      	testq	%rax, %rax
     2ac:      	je	0x5f2 <perf_unwind_v8+0x5f2>
     2b2:      	incq	(%rax)
     2b5:      	jmp	0x5fc <perf_unwind_v8+0x5fc>
     2ba:      	movq	%rsi, %rax
     2bd:      	movq	(%rsi,%rdi), %r15
     2c1:      	movq	(%rsi,%rcx), %rsi
     2c5:      	movl	%esi, %ecx
     2c7:      	andl	$0x3, %ecx
     2ca:      	andq	$-0x4, %rsi
     2ce:      	xorl	%eax, %eax
     2d0:      	cmpl	$0x1, %ecx
     2d3:      	cmovneq	%rax, %rsi
     2d7:      	testq	%rsi, %rsi
     2da:      	je	0x486 <perf_unwind_v8+0x486>
     2e0:      	movzbl	0xc(%r8), %edx
     2e5:      	movq	%rsi, %rbp
     2e8:      	addq	%rsi, %rdx
     2eb:      	movq	%rsp, %rdi
     2ee:      	movl	$0x8, %eax
     2f3:      	movl	$0x70, %ecx
     2f8:      	movl	$0x8, %esi
     2fd:      	callq	*%rcx
     2ff:      	testq	%rax, %rax
     302:      	jne	0x47c <perf_unwind_v8+0x47c>
     308:      	movq	(%rsp), %rax
     30c:      	movl	%eax, %ecx
     30e:      	andl	$0x3, %ecx
     311:      	cmpl	$0x1, %ecx
     314:      	jne	0x47c <perf_unwind_v8+0x47c>
     31a:      	andq	$-0x4, %rax
     31e:      	je	0x47c <perf_unwind_v8+0x47c>
     324:      	movq	0x48(%rsp), %rsi
     329:      	movzbl	0xd(%rsi), %ecx
     32d:      	addq	%rax, %rcx
     330:      	movq	%rsp, %rdi
     333:      	movl	$0x2, %edx
     338:      	movl	$0x70, %r8d
     33e:      	movzbl	0xd(%rsi), %edx
     342:      	addq	%rax, %rdx
     345:      	movl	$0x2, %esi
     34a:      	callq	*%r8
     34d:      	testq	%rax, %rax
     350:      	jne	0x932 <perf_unwind_v8+0x932>
     356:      	movzwl	(%rsp), %eax
     35a:      	jmp	0x934 <perf_unwind_v8+0x934>
     35f:      	leal	0x1(%rax), %ecx
     362:      	movl	%ecx, 0x2c0(%r14)
     369:      	leaq	(%rax,%rax,2), %rax
     36d:      	movq	%r15, 0x2d0(%r14,%rax,8)
     375:      	movq	%rdx, 0x2d8(%r14,%rax,8)
     37d:      	movb	$0x8, 0x2e0(%r14,%rax,8)
     386:      	movb	%bpl, 0x2e1(%r14,%rax,8)
     38e:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     39a:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     3a5:      	movq	0xee0(%r14), %rax
     3ac:      	movq	%rsp, %rdi
     3af:      	movl	$0x10, %ecx
     3b4:      	movl	$0x70, %r8d
     3ba:      	movq	0xee0(%r14), %rdx
     3c1:      	movl	$0x10, %esi
     3c6:      	callq	*%r8
     3c9:      	testq	%rax, %rax
     3cc:      	je	0x607 <perf_unwind_v8+0x607>
     3d2:      	movq	(%rip), %r15            # 0x3d9 <perf_unwind_v8+0x3d9>
     3d9:      	cmpl	$0x0, (%r15)
     3dd:      	jne	0x1081 <perf_unwind_v8+0x1081>
     3e3:      	movl	$0x39, 0x70(%rsp)
     3eb:      	movq	(%rip), %rdi            # 0x3f2 <perf_unwind_v8+0x3f2>
     3f2:      	leaq	0x70(%rsp), %rsi
     3f7:      	movl	$0x1, %eax
     3fc:      	callq	*%rax
     3fe:      	testq	%rax, %rax
     401:      	jne	0x2059 <perf_unwind_v8+0x2059>
     407:      	cmpl	$0x0, (%r15)
     40b:      	je	0x2068 <perf_unwind_v8+0x2068>
     411:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     41b:      	movq	%rax, 0x26(%rsp)
     420:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     42a:      	movq	%rax, 0x20(%rsp)
     42f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     439:      	movq	%rax, 0x18(%rsp)
     43e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     448:      	movq	%rax, 0x10(%rsp)
     44d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     457:      	movq	%rax, 0x8(%rsp)
     45c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     466:      	movq	%rax, (%rsp)
     46a:      	movq	%rsp, %rdi
     46d:      	movl	$0x2e, %eax
     472:      	movl	$0x6, %ecx
     477:      	jmp	0x2299 <perf_unwind_v8+0x2299>
     47c:      	xorl	%eax, %eax
     47e:      	movq	0x48(%rsp), %r8
     483:      	movq	%rbp, %rsi
     486:      	cmpw	0x4(%r8), %ax
     48b:      	jb	0x494 <perf_unwind_v8+0x494>
     48d:      	cmpw	0x6(%r8), %ax
     492:      	jbe	0x4e1 <perf_unwind_v8+0x4e1>
     494:      	movq	(%rip), %r12            # 0x49b <perf_unwind_v8+0x49b>
     49b:      	cmpl	$0x0, (%r12)
     4a0:      	jne	0xed3 <perf_unwind_v8+0xed3>
     4a6:      	movl	$0x3a, 0x70(%rsp)
     4ae:      	movq	(%rip), %rdi            # 0x4b5 <perf_unwind_v8+0x4b5>
     4b5:      	leaq	0x70(%rsp), %rsi
     4ba:      	movl	$0x1, %eax
     4bf:      	callq	*%rax
     4c1:      	testq	%rax, %rax
     4c4:      	je	0x4cb <perf_unwind_v8+0x4cb>
     4c6:      	incq	(%rax)
     4c9:      	jmp	0x4d6 <perf_unwind_v8+0x4d6>
     4cb:      	cmpl	$0x0, (%r12)
     4d0:      	jne	0x10d0 <perf_unwind_v8+0x10d0>
     4d6:      	movl	$0x1389, %r12d          # imm = 0x1389
     4dc:      	jmp	0x206e <perf_unwind_v8+0x206e>
     4e1:      	movzbl	0xf(%r8), %edx
     4e6:      	movq	%rsi, 0x50(%rsp)
     4eb:      	addq	%rsi, %rdx
     4ee:      	movq	%rsp, %rdi
     4f1:      	movl	$0x8, %eax
     4f6:      	movl	$0x70, %ecx
     4fb:      	movl	$0x8, %esi
     500:      	callq	*%rcx
     502:      	testq	%rax, %rax
     505:      	jne	0x5a7 <perf_unwind_v8+0x5a7>
     50b:      	movq	(%rsp), %rbp
     50f:      	movl	%ebp, %eax
     511:      	andl	$0x3, %eax
     514:      	cmpl	$0x1, %eax
     517:      	jne	0x5a7 <perf_unwind_v8+0x5a7>
     51d:      	andq	$-0x4, %rbp
     521:      	je	0x5a7 <perf_unwind_v8+0x5a7>
     527:      	movq	0x48(%rsp), %rax
     52c:      	movzbl	0xc(%rax), %edx
     530:      	addq	%rbp, %rdx
     533:      	movq	%rsp, %rdi
     536:      	movl	$0x8, %eax
     53b:      	movl	$0x70, %ecx
     540:      	movl	$0x8, %esi
     545:      	callq	*%rcx
     547:      	testq	%rax, %rax
     54a:      	jne	0x982 <perf_unwind_v8+0x982>
     550:      	movq	(%rsp), %rax
     554:      	movl	%eax, %ecx
     556:      	andl	$0x3, %ecx
     559:      	cmpl	$0x1, %ecx
     55c:      	jne	0x982 <perf_unwind_v8+0x982>
     562:      	andq	$-0x4, %rax
     566:      	je	0x982 <perf_unwind_v8+0x982>
     56c:      	movq	0x48(%rsp), %rsi
     571:      	movzbl	0xd(%rsi), %ecx
     575:      	addq	%rax, %rcx
     578:      	movq	%rsp, %rdi
     57b:      	movl	$0x2, %edx
     580:      	movl	$0x70, %r8d
     586:      	movzbl	0xd(%rsi), %edx
     58a:      	addq	%rax, %rdx
     58d:      	movl	$0x2, %esi
     592:      	callq	*%r8
     595:      	testq	%rax, %rax
     598:      	jne	0x982 <perf_unwind_v8+0x982>
     59e:      	movzwl	(%rsp), %eax
     5a2:      	jmp	0x984 <perf_unwind_v8+0x984>
     5a7:      	xorl	%ebp, %ebp
     5a9:      	xorl	%eax, %eax
     5ab:      	movq	0x48(%rsp), %rcx
     5b0:      	movq	0x50(%rsp), %rsi
     5b5:      	cmpw	0xa(%rcx), %ax
     5b9:      	jne	0x998 <perf_unwind_v8+0x998>
     5bf:      	movq	%r15, %rdx
     5c2:      	shrq	$0x20, %rdx
     5c6:      	je	0x714 <perf_unwind_v8+0x714>
     5cc:      	andl	$0x1, %r15d
     5d0:      	jne	0x714 <perf_unwind_v8+0x714>
     5d6:      	movq	(%rip), %rax            # 0x5dd <perf_unwind_v8+0x5dd>
     5dd:      	cmpl	$0x0, (%rax)
     5e0:      	jne	0x152f <perf_unwind_v8+0x152f>
     5e6:      	orq	$0x1, %rbp
     5ea:      	movq	%rbp, %r15
     5ed:      	jmp	0xbf4 <perf_unwind_v8+0xbf4>
     5f2:      	cmpl	$0x0, (%r15)
     5f6:      	jne	0x1163 <perf_unwind_v8+0x1163>
     5fc:      	movl	$0x2, %r12d
     602:      	jmp	0x206e <perf_unwind_v8+0x206e>
     607:      	movq	0xee0(%r14), %rax
     60e:      	addq	$0x10, %rax
     612:      	movq	%rax, 0xed8(%r14)
     619:      	movq	(%rsp), %rax
     61d:      	movq	%rax, 0xee0(%r14)
     624:      	movq	0x8(%rsp), %rax
     629:      	movq	%rax, 0xed0(%r14)
     630:      	movb	$0x1, 0xf30(%r14)
     638:      	movq	(%rip), %r13            # 0x63f <perf_unwind_v8+0x63f>
     63f:      	cmpl	$0x0, (%r13)
     644:      	jne	0x11db <perf_unwind_v8+0x11db>
     64a:      	movl	$0x38, 0x70(%rsp)
     652:      	movq	(%rip), %rdi            # 0x659 <perf_unwind_v8+0x659>
     659:      	leaq	0x70(%rsp), %rsi
     65e:      	movl	$0x1, %eax
     663:      	callq	*%rax
     665:      	testq	%rax, %rax
     668:      	je	0x673 <perf_unwind_v8+0x673>
     66a:      	incq	(%rax)
     66d:      	movl	(%r13), %eax
     671:      	jmp	0x680 <perf_unwind_v8+0x680>
     673:      	xorl	%eax, %eax
     675:      	cmpl	$0x0, (%r13)
     67a:      	jne	0x14b7 <perf_unwind_v8+0x14b7>
     680:      	movq	0xed0(%r14), %r12
     687:      	testq	%r12, %r12
     68a:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
     690:      	testl	%eax, %eax
     692:      	jne	0x1248 <perf_unwind_v8+0x1248>
     698:      	movq	%r12, %rax
     69b:      	shrq	$0x38, %rax
     69f:      	je	0x12d7 <perf_unwind_v8+0x12d7>
     6a5:      	cmpl	$0x0, (%r13)
     6aa:      	jne	0x1dc5 <perf_unwind_v8+0x1dc5>
     6b0:      	movl	$0xb, 0xf28(%r14)
     6bb:      	movl	$0xfab, %r12d           # imm = 0xFAB
     6c1:      	jmp	0x206e <perf_unwind_v8+0x206e>
     6c6:      	movabsq	$0xa3d3d3d3d2064, %rax  # imm = 0xA3D3D3D3D2064
     6d0:      	movq	%rax, 0x10(%rsp)
     6d5:      	movabsq	$0x252038765f646e69, %rax # imm = 0x252038765F646E69
     6df:      	movq	%rax, 0x8(%rsp)
     6e4:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     6ee:      	movq	%rax, (%rsp)
     6f2:      	movq	%rsp, %rdi
     6f5:      	movl	$0x18, %eax
     6fa:      	movl	$0x6, %ecx
     6ff:      	movl	0x2c0(%r14), %edx
     706:      	movl	$0x18, %esi
     70b:      	xorl	%eax, %eax
     70d:      	callq	*%rcx
     70f:      	jmp	0x52 <perf_unwind_v8+0x52>
     714:      	movzbl	0xe(%rcx), %edx
     718:      	addq	%rsi, %rdx
     71b:      	movq	%rsp, %rdi
     71e:      	movl	$0x8, %eax
     723:      	movl	$0x70, %ecx
     728:      	movl	$0x8, %esi
     72d:      	callq	*%rcx
     72f:      	testq	%rax, %rax
     732:      	jne	0x7d5 <perf_unwind_v8+0x7d5>
     738:      	movq	(%rsp), %r15
     73c:      	movl	%r15d, %eax
     73f:      	andl	$0x3, %eax
     742:      	cmpl	$0x1, %eax
     745:      	jne	0x7d5 <perf_unwind_v8+0x7d5>
     74b:      	andq	$-0x4, %r15
     74f:      	je	0x7d5 <perf_unwind_v8+0x7d5>
     755:      	movq	0x48(%rsp), %rax
     75a:      	movzbl	0xc(%rax), %edx
     75e:      	addq	%r15, %rdx
     761:      	movq	%rsp, %rdi
     764:      	movl	$0x8, %eax
     769:      	movl	$0x70, %ecx
     76e:      	movl	$0x8, %esi
     773:      	callq	*%rcx
     775:      	testq	%rax, %rax
     778:      	jne	0xd1a <perf_unwind_v8+0xd1a>
     77e:      	movq	(%rsp), %rax
     782:      	movl	%eax, %ecx
     784:      	andl	$0x3, %ecx
     787:      	cmpl	$0x1, %ecx
     78a:      	jne	0xd1a <perf_unwind_v8+0xd1a>
     790:      	andq	$-0x4, %rax
     794:      	je	0xd1a <perf_unwind_v8+0xd1a>
     79a:      	movq	0x48(%rsp), %rsi
     79f:      	movzbl	0xd(%rsi), %ecx
     7a3:      	addq	%rax, %rcx
     7a6:      	movq	%rsp, %rdi
     7a9:      	movl	$0x2, %edx
     7ae:      	movl	$0x70, %r8d
     7b4:      	movzbl	0xd(%rsi), %edx
     7b8:      	addq	%rax, %rdx
     7bb:      	movl	$0x2, %esi
     7c0:      	callq	*%r8
     7c3:      	testq	%rax, %rax
     7c6:      	jne	0xd1a <perf_unwind_v8+0xd1a>
     7cc:      	movzwl	(%rsp), %eax
     7d0:      	jmp	0xd1c <perf_unwind_v8+0xd1c>
     7d5:      	xorl	%edx, %edx
     7d7:      	xorl	%eax, %eax
     7d9:      	movq	%rbp, 0x58(%rsp)
     7de:      	movq	%rbp, %r15
     7e1:      	orq	$0x2, %r15
     7e5:      	movq	0x48(%rsp), %rcx
     7ea:      	cmpw	0x8(%rcx), %ax
     7ee:      	movq	(%rip), %rbp            # 0x7f5 <perf_unwind_v8+0x7f5>
     7f5:      	jne	0x94c <perf_unwind_v8+0x94c>
     7fb:      	movl	$0x60, %eax
     800:      	movl	$0x70, %ecx
     805:      	movq	0xb0(%rsp), %rdi
     80d:      	movl	$0x60, %esi
     812:      	movq	%rdx, 0x68(%rsp)
     817:      	callq	*%rcx
     819:      	testq	%rax, %rax
     81c:      	je	0xb84 <perf_unwind_v8+0xb84>
     822:      	movl	$0x3b, 0x70(%rsp)
     82a:      	movq	(%rip), %rdi            # 0x831 <perf_unwind_v8+0x831>
     831:      	leaq	0x70(%rsp), %rsi
     836:      	movl	$0x1, %eax
     83b:      	callq	*%rax
     83d:      	testq	%rax, %rax
     840:      	jne	0x97a <perf_unwind_v8+0x97a>
     846:      	cmpl	$0x0, (%rbp)
     84a:      	je	0xbf2 <perf_unwind_v8+0xbf2>
     850:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     85a:      	movq	%rax, 0x26(%rsp)
     85f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     869:      	movq	%rax, 0x20(%rsp)
     86e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     878:      	movq	%rax, 0x18(%rsp)
     87d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     887:      	movq	%rax, 0x10(%rsp)
     88c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     896:      	movq	%rax, 0x8(%rsp)
     89b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     8a5:      	movq	%rax, (%rsp)
     8a9:      	movq	%rsp, %rdi
     8ac:      	movl	$0x2e, %eax
     8b1:      	movl	$0x6, %ecx
     8b6:      	jmp	0x181b <perf_unwind_v8+0x181b>
     8bb:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
     8c5:      	movq	%rax, 0x17(%rsp)
     8ca:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
     8d4:      	movq	%rax, 0x10(%rsp)
     8d9:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
     8e3:      	movq	%rax, 0x8(%rsp)
     8e8:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
     8f2:      	movq	%rax, (%rsp)
     8f6:      	movq	%rsp, %rdi
     8f9:      	movl	$0x1f, %eax
     8fe:      	movl	$0x6, %r9d
     904:      	movl	$0x1f, %esi
     909:      	movq	%rdx, %rbp
     90c:      	movq	%r13, %rdx
     90f:      	movq	%r12, %rcx
     912:      	movq	%rbp, %r8
     915:      	xorl	%eax, %eax
     917:      	callq	*%r9
     91a:      	movq	%rbp, %rdx
     91d:      	movq	(%rip), %rbp            # 0x924 <perf_unwind_v8+0x924>
     924:      	cmpq	%r12, %rdx
     927:      	jae	0xff <perf_unwind_v8+0xff>
     92d:      	jmp	0x202f <perf_unwind_v8+0x202f>
     932:      	xorl	%eax, %eax
     934:      	movq	%rbp, %rsi
     937:      	movq	0x48(%rsp), %r8
     93c:      	cmpw	0x4(%r8), %ax
     941:      	jae	0x48d <perf_unwind_v8+0x48d>
     947:      	jmp	0x494 <perf_unwind_v8+0x494>
     94c:      	cmpl	$0x0, (%rbp)
     950:      	jne	0x1624 <perf_unwind_v8+0x1624>
     956:      	movl	$0x3b, 0x70(%rsp)
     95e:      	movq	(%rip), %rdi            # 0x965 <perf_unwind_v8+0x965>
     965:      	leaq	0x70(%rsp), %rsi
     96a:      	movl	$0x1, %eax
     96f:      	callq	*%rax
     971:      	testq	%rax, %rax
     974:      	je	0xbe8 <perf_unwind_v8+0xbe8>
     97a:      	incq	(%rax)
     97d:      	jmp	0xbf2 <perf_unwind_v8+0xbf2>
     982:      	xorl	%eax, %eax
     984:      	movq	0x50(%rsp), %rsi
     989:      	movq	0x48(%rsp), %rcx
     98e:      	cmpw	0xa(%rcx), %ax
     992:      	je	0x5bf <perf_unwind_v8+0x5bf>
     998:      	movq	(%rip), %r15            # 0x99f <perf_unwind_v8+0x99f>
     99f:      	cmpl	$0x0, (%r15)
     9a3:      	jne	0x1461 <perf_unwind_v8+0x1461>
     9a9:      	movl	$0x3a, 0x70(%rsp)
     9b1:      	movq	(%rip), %rdi            # 0x9b8 <perf_unwind_v8+0x9b8>
     9b8:      	leaq	0x70(%rsp), %rsi
     9bd:      	movl	$0x1, %eax
     9c2:      	callq	*%rax
     9c4:      	testq	%rax, %rax
     9c7:      	jne	0x4c6 <perf_unwind_v8+0x4c6>
     9cd:      	cmpl	$0x0, (%r15)
     9d1:      	je	0x4d6 <perf_unwind_v8+0x4d6>
     9d7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     9e1:      	movq	%rax, 0x26(%rsp)
     9e6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     9f0:      	movq	%rax, 0x20(%rsp)
     9f5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     9ff:      	movq	%rax, 0x18(%rsp)
     a04:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     a0e:      	movq	%rax, 0x10(%rsp)
     a13:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     a1d:      	movq	%rax, 0x8(%rsp)
     a22:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     a2c:      	movq	%rax, (%rsp)
     a30:      	movq	%rsp, %rdi
     a33:      	movl	$0x2e, %eax
     a38:      	movl	$0x6, %ecx
     a3d:      	jmp	0x1136 <perf_unwind_v8+0x1136>
     a42:      	movabsq	$0xa646970207369, %rax  # imm = 0xA646970207369
     a4c:      	movq	%rax, 0x18(%rsp)
     a51:      	movabsq	$0x687420726f66206f, %rax # imm = 0x687420726F66206F
     a5b:      	movq	%rax, 0x10(%rsp)
     a60:      	movabsq	$0x666e49636f725038, %rax # imm = 0x666E49636F725038
     a6a:      	movq	%rax, 0x8(%rsp)
     a6f:      	movabsq	$0x56206f6e203a3876, %rax # imm = 0x56206F6E203A3876
     a79:      	movq	%rax, (%rsp)
     a7d:      	movq	%rsp, %rdi
     a80:      	movl	$0x20, %eax
     a85:      	movl	$0x6, %ecx
     a8a:      	movl	$0x20, %esi
     a8f:      	xorl	%eax, %eax
     a91:      	callq	*%rcx
     a93:      	jmp	0xa1 <perf_unwind_v8+0xa1>
     a98:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     aa2:      	movq	%rax, 0x26(%rsp)
     aa7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ab1:      	movq	%rax, 0x20(%rsp)
     ab6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ac0:      	movq	%rax, 0x18(%rsp)
     ac5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     acf:      	movq	%rax, 0x10(%rsp)
     ad4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     ade:      	movq	%rax, 0x8(%rsp)
     ae3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     aed:      	movq	%rax, (%rsp)
     af1:      	movq	%rsp, %rdi
     af4:      	movl	$0x2e, %eax
     af9:      	movl	$0x6, %ecx
     afe:      	movl	0x70(%rsp), %edx
     b02:      	movl	$0x2e, %esi
     b07:      	xorl	%eax, %eax
     b09:      	callq	*%rcx
     b0b:      	jmp	0xd7 <perf_unwind_v8+0xd7>
     b10:      	movabsq	$0xa747865746e6f, %rax  # imm = 0xA747865746E6F
     b1a:      	movq	%rax, 0x26(%rsp)
     b1f:      	movabsq	$0x6e6f63207265746e, %rax # imm = 0x6E6F63207265746E
     b29:      	movq	%rax, 0x20(%rsp)
     b2e:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
     b38:      	movq	%rax, 0x18(%rsp)
     b3d:      	movabsq	$0x662064616572206f, %rax # imm = 0x662064616572206F
     b47:      	movq	%rax, 0x10(%rsp)
     b4c:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     b56:      	movq	%rax, 0x8(%rsp)
     b5b:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
     b65:      	movq	%rax, (%rsp)
     b69:      	movq	%rsp, %rdi
     b6c:      	movl	$0x2e, %eax
     b71:      	movl	$0x6, %ecx
     b76:      	movl	$0x2e, %esi
     b7b:      	xorl	%eax, %eax
     b7d:      	callq	*%rcx
     b7f:      	jmp	0x142 <perf_unwind_v8+0x142>
     b84:      	movq	0x48(%rsp), %rax
     b89:      	movzbl	0x12(%rax), %ecx
     b8d:      	xorl	%ebp, %ebp
     b8f:      	cmpq	$0x5c, %rcx
     b93:      	ja	0x220 <perf_unwind_v8+0x220>
     b99:      	movq	0x48(%rsp), %rax
     b9e:      	movzbl	0x13(%rax), %eax
     ba2:      	cmpq	$0x5c, %rax
     ba6:      	ja	0x220 <perf_unwind_v8+0x220>
     bac:      	movq	0x48(%rsp), %rdx
     bb1:      	cmpb	$0x0, 0x10(%rdx)
     bb5:      	movzbl	0x11(%rdx), %edx
     bb9:      	movq	%rdx, 0x90(%rsp)
     bc1:      	je	0xd24 <perf_unwind_v8+0xd24>
     bc7:      	movq	0xb0(%rsp), %rdx
     bcf:      	movq	0x90(%rsp), %rsi
     bd7:      	movq	(%rdx,%rsi), %rsi
     bdb:      	movq	%rsi, 0x90(%rsp)
     be3:      	jmp	0xd39 <perf_unwind_v8+0xd39>
     be8:      	cmpl	$0x0, (%rbp)
     bec:      	jne	0x17b5 <perf_unwind_v8+0x17b5>
     bf2:      	xorl	%edx, %edx
     bf4:      	movzbl	0xf30(%r14), %ebp
     bfc:      	movq	(%rip), %rax            # 0xc03 <perf_unwind_v8+0xc03>
     c03:      	cmpl	$0x0, (%rax)
     c06:      	je	0x26c <perf_unwind_v8+0x26c>
     c0c:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
     c16:      	movq	%rax, 0x30(%rsp)
     c1b:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
     c25:      	movq	%rax, 0x28(%rsp)
     c2a:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
     c34:      	movq	%rax, 0x20(%rsp)
     c39:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
     c43:      	movq	%rax, 0x18(%rsp)
     c48:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
     c52:      	movq	%rax, 0x10(%rsp)
     c57:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
     c61:      	movq	%rax, 0x8(%rsp)
     c66:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
     c70:      	movq	%rax, (%rsp)
     c74:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
     c7c:      	movq	%rsp, %rdi
     c7f:      	movl	$0x3c, %eax
     c84:      	movl	$0x6, %r8d
     c8a:      	movl	$0x3c, %esi
     c8f:      	movq	%r15, %rcx
     c92:      	xorl	%eax, %eax
     c94:      	movq	%rdx, %r12
     c97:      	callq	*%r8
     c9a:      	movq	%r12, %rdx
     c9d:      	jmp	0x26c <perf_unwind_v8+0x26c>
     ca2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     cac:      	movq	%rax, 0x26(%rsp)
     cb1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     cbb:      	movq	%rax, 0x20(%rsp)
     cc0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     cca:      	movq	%rax, 0x18(%rsp)
     ccf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     cd9:      	movq	%rax, 0x10(%rsp)
     cde:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     ce8:      	movq	%rax, 0x8(%rsp)
     ced:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     cf7:      	movq	%rax, (%rsp)
     cfb:      	movq	%rsp, %rdi
     cfe:      	movl	$0x2e, %eax
     d03:      	movl	$0x6, %ecx
     d08:      	movl	0x70(%rsp), %edx
     d0c:      	movl	$0x2e, %esi
     d11:      	xorl	%eax, %eax
     d13:      	callq	*%rcx
     d15:      	jmp	0x1e5 <perf_unwind_v8+0x1e5>
     d1a:      	xorl	%eax, %eax
     d1c:      	movq	%r15, %rdx
     d1f:      	jmp	0x7d9 <perf_unwind_v8+0x7d9>
     d24:      	movq	0x90(%rsp), %rdx
     d2c:      	addq	0x68(%rsp), %rdx
     d31:      	movq	%rdx, 0x90(%rsp)
     d39:      	movq	0xb0(%rsp), %rdx
     d41:      	movl	(%rdx,%rcx), %esi
     d44:      	movq	0x48(%rsp), %rcx
     d49:      	movzbl	0x17(%rcx), %edi
     d4d:      	movl	%edi, 0xac(%rsp)
     d54:      	movzbl	0x18(%rcx), %ecx
     d58:      	movq	%rsi, 0xb8(%rsp)
     d60:      	addq	0x90(%rsp), %rsi
     d68:      	movq	%rsi, 0xa0(%rsp)
     d70:      	andl	(%rdx,%rax), %ecx
     d73:      	movl	%ecx, 0xc0(%rsp)
     d7a:      	movq	(%rip), %rax            # 0xd81 <perf_unwind_v8+0xd81>
     d81:      	cmpl	$0x0, (%rax)
     d84:      	jne	0x182d <perf_unwind_v8+0x182d>
     d8a:      	cmpq	0x90(%rsp), %r13
     d92:      	jb	0xdf1 <perf_unwind_v8+0xdf1>
     d94:      	cmpq	0xa0(%rsp), %r13
     d9c:      	jae	0xdf1 <perf_unwind_v8+0xdf1>
     d9e:      	movl	0xac(%rsp), %eax
     da5:      	shrxl	%eax, 0xc0(%rsp), %eax
     daf:      	movq	0x48(%rsp), %rcx
     db4:      	movzbl	0x19(%rcx), %ecx
     db8:      	movq	0x50(%rsp), %rdx
     dbd:      	orq	$0x4, %rdx
     dc1:      	movq	0x68(%rsp), %r15
     dc6:      	orq	$0x3, %r15
     dca:      	cmpl	%ecx, %eax
     dcc:      	cmoveq	%rdx, %r15
     dd0:      	movq	0xb8(%rsp), %rdx
     dd8:      	shll	$0x4, %edx
     ddb:      	orl	%eax, %edx
     ddd:      	subq	0x90(%rsp), %r13
     de5:      	shlq	$0x20, %rdx
     de9:      	orq	%r13, %rdx
     dec:      	jmp	0xbf4 <perf_unwind_v8+0xbf4>
     df1:      	cmpl	$0x0, 0x2c0(%r14)
     df9:      	je	0xe12 <perf_unwind_v8+0xe12>
     dfb:      	movq	(%rip), %rax            # 0xe02 <perf_unwind_v8+0xe02>
     e02:      	cmpl	$0x0, (%rax)
     e05:      	jne	0x2470 <perf_unwind_v8+0x2470>
     e0b:      	xorl	%edx, %edx
     e0d:      	jmp	0x264 <perf_unwind_v8+0x264>
     e12:      	addq	$-0x18, %r12
     e16:      	leaq	0x70(%rsp), %rdi
     e1b:      	movl	$0x18, %eax
     e20:      	movl	$0x70, %ecx
     e25:      	movl	$0x18, %esi
     e2a:      	movq	%r12, %rdx
     e2d:      	callq	*%rcx
     e2f:      	testq	%rax, %rax
     e32:      	je	0xfb3 <perf_unwind_v8+0xfb3>
     e38:      	movq	(%rip), %rax            # 0xe3f <perf_unwind_v8+0xe3f>
     e3f:      	cmpl	$0x0, (%rax)
     e42:      	jne	0x255c <perf_unwind_v8+0x255c>
     e48:      	movl	$0x39, 0x64(%rsp)
     e50:      	movq	(%rip), %rdi            # 0xe57 <perf_unwind_v8+0xe57>
     e57:      	leaq	0x64(%rsp), %rsi
     e5c:      	movl	$0x1, %eax
     e61:      	callq	*%rax
     e63:      	testq	%rax, %rax
     e66:      	je	0x1148 <perf_unwind_v8+0x1148>
     e6c:      	incq	(%rax)
     e6f:      	jmp	0x1158 <perf_unwind_v8+0x1158>
     e74:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
     e7e:      	movq	%rax, 0x15(%rsp)
     e83:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
     e8d:      	movq	%rax, 0x10(%rsp)
     e92:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
     e9c:      	movq	%rax, 0x8(%rsp)
     ea1:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
     eab:      	movq	%rax, (%rsp)
     eaf:      	movq	%rsp, %rdi
     eb2:      	movl	$0x1d, %eax
     eb7:      	movl	$0x6, %ecx
     ebc:      	xorl	%r15d, %r15d
     ebf:      	movl	$0x1d, %esi
     ec4:      	xorl	%eax, %eax
     ec6:      	movq	%rdx, %r12
     ec9:      	callq	*%rcx
     ecb:      	movq	%r12, %rdx
     ece:      	jmp	0xbf4 <perf_unwind_v8+0xbf4>
     ed3:      	movabsq	$0x7825203d3c207825, %rcx # imm = 0x7825203D3C207825
     edd:      	movq	%rcx, 0x20(%rsp)
     ee2:      	movabsq	$0x203d3c207825203a, %rcx # imm = 0x203D3C207825203A
     eec:      	movq	%rcx, 0x18(%rsp)
     ef1:      	movabsq	$0x6e6f6974636e7546, %rcx # imm = 0x6E6F6974636E7546
     efb:      	movq	%rcx, 0x10(%rsp)
     f00:      	movabsq	$0x534a206120746f6e, %rcx # imm = 0x534A206120746F6E
     f0a:      	movq	%rcx, 0x8(%rsp)
     f0f:      	movzwl	%ax, %ecx
     f12:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
     f1c:      	movq	%rax, (%rsp)
     f20:      	movw	$0xa, 0x28(%rsp)
     f27:      	movq	%rsp, %rdi
     f2a:      	movl	$0x2a, %eax
     f2f:      	movl	$0x6, %r9d
     f35:      	movzwl	0x4(%r8), %edx
     f3a:      	movzwl	0x6(%r8), %r8d
     f3f:      	movl	$0x2a, %esi
     f44:      	xorl	%eax, %eax
     f46:      	callq	*%r9
     f49:      	jmp	0x4a6 <perf_unwind_v8+0x4a6>
     f4e:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
     f58:      	movq	%rax, 0x1d(%rsp)
     f5d:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
     f67:      	movq	%rax, 0x18(%rsp)
     f6c:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
     f76:      	movq	%rax, 0x10(%rsp)
     f7b:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
     f85:      	movq	%rax, 0x8(%rsp)
     f8a:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
     f94:      	movq	%rax, (%rsp)
     f98:      	movq	%rsp, %rdi
     f9b:      	movl	$0x25, %eax
     fa0:      	movl	$0x6, %ecx
     fa5:      	movl	$0x25, %esi
     faa:      	xorl	%eax, %eax
     fac:      	callq	*%rcx
     fae:      	jmp	0x28e <perf_unwind_v8+0x28e>
     fb3:      	movq	0x80(%rsp), %r13
     fbb:      	cmpq	0x90(%rsp), %r13
     fc3:      	jb	0xfcf <perf_unwind_v8+0xfcf>
     fc5:      	cmpq	0xa0(%rsp), %r13
     fcd:      	jb	0x1009 <perf_unwind_v8+0x1009>
     fcf:      	movq	0x78(%rsp), %r13
     fd4:      	cmpq	0x90(%rsp), %r13
     fdc:      	jb	0xfe8 <perf_unwind_v8+0xfe8>
     fde:      	cmpq	0xa0(%rsp), %r13
     fe6:      	jb	0x1009 <perf_unwind_v8+0x1009>
     fe8:      	movq	0x70(%rsp), %r13
     fed:      	cmpq	0x90(%rsp), %r13
     ff5:      	jb	0x1584 <perf_unwind_v8+0x1584>
     ffb:      	cmpq	0xa0(%rsp), %r13
    1003:      	jae	0x1584 <perf_unwind_v8+0x1584>
    1009:      	movq	(%rip), %rax            # 0x1010 <perf_unwind_v8+0x1010>
    1010:      	cmpl	$0x0, (%rax)
    1013:      	je	0xd9e <perf_unwind_v8+0xd9e>
    1019:      	movabsq	$0xa786c25203a6b, %rax  # imm = 0xA786C25203A6B
    1023:      	movq	%rax, 0x1f(%rsp)
    1028:      	movabsq	$0x6b63617473206d6f, %rax # imm = 0x6B63617473206D6F
    1032:      	movq	%rax, 0x18(%rsp)
    1037:      	movabsq	$0x7266206465726576, %rax # imm = 0x7266206465726576
    1041:      	movq	%rax, 0x10(%rsp)
    1046:      	movabsq	$0x6f63657220637020, %rax # imm = 0x6F63657220637020
    1050:      	movq	%rax, 0x8(%rsp)
    1055:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    105f:      	movq	%rax, (%rsp)
    1063:      	movq	%rsp, %rdi
    1066:      	movl	$0x27, %eax
    106b:      	movl	$0x6, %ecx
    1070:      	movl	$0x27, %esi
    1075:      	movq	%r13, %rdx
    1078:      	xorl	%eax, %eax
    107a:      	callq	*%rcx
    107c:      	jmp	0xd9e <perf_unwind_v8+0xd9e>
    1081:      	movabsq	$0x746e696f7020656d, %rax # imm = 0x746E696F7020656D
    108b:      	movq	%rax, 0x10(%rsp)
    1090:      	movabsq	$0x6172662064616220, %rax # imm = 0x6172662064616220
    109a:      	movq	%rax, 0x8(%rsp)
    109f:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    10a9:      	movq	%rax, (%rsp)
    10ad:      	movl	$0xa7265, 0x18(%rsp)    # imm = 0xA7265
    10b5:      	movq	%rsp, %rdi
    10b8:      	movl	$0x1c, %eax
    10bd:      	movl	$0x6, %ecx
    10c2:      	movl	$0x1c, %esi
    10c7:      	xorl	%eax, %eax
    10c9:      	callq	*%rcx
    10cb:      	jmp	0x3e3 <perf_unwind_v8+0x3e3>
    10d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10da:      	movq	%rax, 0x26(%rsp)
    10df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10e9:      	movq	%rax, 0x20(%rsp)
    10ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10f8:      	movq	%rax, 0x18(%rsp)
    10fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1107:      	movq	%rax, 0x10(%rsp)
    110c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1116:      	movq	%rax, 0x8(%rsp)
    111b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1125:      	movq	%rax, (%rsp)
    1129:      	movq	%rsp, %rdi
    112c:      	movl	$0x2e, %eax
    1131:      	movl	$0x6, %ecx
    1136:      	movl	0x70(%rsp), %edx
    113a:      	movl	$0x2e, %esi
    113f:      	xorl	%eax, %eax
    1141:      	callq	*%rcx
    1143:      	jmp	0x4d6 <perf_unwind_v8+0x4d6>
    1148:      	movq	(%rip), %rax            # 0x114f <perf_unwind_v8+0x114f>
    114f:      	cmpl	$0x0, (%rax)
    1152:      	jne	0x2679 <perf_unwind_v8+0x2679>
    1158:      	movl	$0x1388, %r12d          # imm = 0x1388
    115e:      	jmp	0x2070 <perf_unwind_v8+0x2070>
    1163:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    116d:      	movq	%rax, 0x26(%rsp)
    1172:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    117c:      	movq	%rax, 0x20(%rsp)
    1181:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    118b:      	movq	%rax, 0x18(%rsp)
    1190:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    119a:      	movq	%rax, 0x10(%rsp)
    119f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    11a9:      	movq	%rax, 0x8(%rsp)
    11ae:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11b8:      	movq	%rax, (%rsp)
    11bc:      	movq	%rsp, %rdi
    11bf:      	movl	$0x2e, %eax
    11c4:      	movl	$0x6, %ecx
    11c9:      	movl	0x70(%rsp), %edx
    11cd:      	movl	$0x2e, %esi
    11d2:      	xorl	%eax, %eax
    11d4:      	callq	*%rcx
    11d6:      	jmp	0x5fc <perf_unwind_v8+0x5fc>
    11db:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    11e5:      	movq	%rax, 0x17(%rsp)
    11ea:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    11f4:      	movq	%rax, 0x10(%rsp)
    11f9:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    1203:      	movq	%rax, 0x8(%rsp)
    1208:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    1212:      	movq	%rax, (%rsp)
    1216:      	movq	%rsp, %rdi
    1219:      	movl	$0x1f, %eax
    121e:      	movl	$0x6, %r9d
    1224:      	movq	0xed0(%r14), %rdx
    122b:      	movq	0xed8(%r14), %rcx
    1232:      	movq	0xee0(%r14), %r8
    1239:      	movl	$0x1f, %esi
    123e:      	xorl	%eax, %eax
    1240:      	callq	*%r9
    1243:      	jmp	0x64a <perf_unwind_v8+0x64a>
    1248:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    1252:      	movq	%rax, 0x28(%rsp)
    1257:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    1261:      	movq	%rax, 0x20(%rsp)
    1266:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    1270:      	movq	%rax, 0x18(%rsp)
    1275:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    127f:      	movq	%rax, 0x10(%rsp)
    1284:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    128e:      	movq	%rax, 0x8(%rsp)
    1293:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    129d:      	movq	%rax, (%rsp)
    12a1:      	movb	$0x0, 0x30(%rsp)
    12a6:      	movq	%rsp, %rdi
    12a9:      	movl	$0x31, %eax
    12ae:      	movl	$0x6, %ecx
    12b3:      	movl	0x2c0(%r14), %edx
    12ba:      	movl	$0x31, %esi
    12bf:      	xorl	%eax, %eax
    12c1:      	callq	*%rcx
    12c3:      	movq	0xed0(%r14), %r12
    12ca:      	movq	%r12, %rax
    12cd:      	shrq	$0x38, %rax
    12d1:      	jne	0x6a5 <perf_unwind_v8+0x6a5>
    12d7:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    12de:      	ja	0x1301 <perf_unwind_v8+0x1301>
    12e0:      	cmpl	$0x0, (%r13)
    12e5:      	jne	0x2870 <perf_unwind_v8+0x2870>
    12eb:      	movl	$0x31, 0xf28(%r14)
    12f6:      	movl	$0xfae, %r12d           # imm = 0xFAE
    12fc:      	jmp	0x206e <perf_unwind_v8+0x206e>
    1301:      	movl	(%r14), %eax
    1304:      	movl	$0x60, 0x70(%rsp)
    130c:      	movbel	%eax, 0x74(%rsp)
    1312:      	movbeq	%r12, 0x78(%rsp)
    1319:      	movq	(%rip), %rdi            # 0x1320 <perf_unwind_v8+0x1320>
    1320:      	leaq	0x70(%rsp), %rsi
    1325:      	movl	$0x1, %eax
    132a:      	callq	*%rax
    132c:      	testq	%rax, %rax
    132f:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    1335:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    133f:      	movq	0x8(%rax), %rbp
    1343:      	movq	%rbp, %rcx
    1346:      	andq	%rdx, %rcx
    1349:      	movq	%rcx, 0xf20(%r14)
    1350:      	movq	(%rax), %rax
    1353:      	movq	%rax, 0xf10(%r14)
    135a:      	shrq	$0x38, %rbp
    135e:      	movq	%r12, %rax
    1361:      	subq	%rcx, %rax
    1364:      	movq	%rax, 0xf18(%r14)
    136b:      	movq	(%rip), %rax            # 0x1372 <perf_unwind_v8+0x1372>
    1372:      	cmpl	$0x0, (%rax)
    1375:      	jne	0x16a6 <perf_unwind_v8+0x16a6>
    137b:      	cmpl	$0x1, %ebp
    137e:      	jne	0x19d9 <perf_unwind_v8+0x19d9>
    1384:      	movq	0xf10(%r14), %rax
    138b:      	movq	%rax, 0x70(%rsp)
    1390:      	movq	0xf18(%r14), %r13
    1397:      	movq	(%rip), %rdi            # 0x139e <perf_unwind_v8+0x139e>
    139e:      	leaq	0x70(%rsp), %rsi
    13a3:      	movl	$0x1, %eax
    13a8:      	callq	*%rax
    13aa:      	movl	$0x1, %ebp
    13af:      	testq	%rax, %rax
    13b2:      	je	0x19d9 <perf_unwind_v8+0x19d9>
    13b8:      	movq	%rax, %r12
    13bb:      	cmpq	%r13, (%rax)
    13be:      	ja	0x13c7 <perf_unwind_v8+0x13c7>
    13c0:      	cmpq	%r13, 0x8(%r12)
    13c5:      	jae	0x13dd <perf_unwind_v8+0x13dd>
    13c7:      	cmpq	%r13, 0x10(%r12)
    13cc:      	ja	0x19d9 <perf_unwind_v8+0x19d9>
    13d2:      	cmpq	%r13, 0x18(%r12)
    13d7:      	jb	0x19d9 <perf_unwind_v8+0x19d9>
    13dd:      	movq	(%rip), %rax            # 0x13e4 <perf_unwind_v8+0x13e4>
    13e4:      	cmpl	$0x0, (%rax)
    13e7:      	jne	0x1932 <perf_unwind_v8+0x1932>
    13ed:      	movl	0x1380(%r14), %eax
    13f4:      	movl	0x20(%r12), %ecx
    13f9:      	btl	%ecx, %eax
    13fc:      	jae	0x199e <perf_unwind_v8+0x199e>
    1402:      	movq	(%rip), %rax            # 0x1409 <perf_unwind_v8+0x1409>
    1409:      	cmpl	$0x0, (%rax)
    140c:      	je	0x19d9 <perf_unwind_v8+0x19d9>
    1412:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    141c:      	movq	%rax, 0x10(%rsp)
    1421:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    142b:      	movq	%rax, 0x8(%rsp)
    1430:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    143a:      	movq	%rax, (%rsp)
    143e:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    1446:      	movq	%rsp, %rdi
    1449:      	movl	$0x1b, %eax
    144e:      	movl	$0x6, %ecx
    1453:      	movl	$0x1b, %esi
    1458:      	xorl	%eax, %eax
    145a:      	callq	*%rcx
    145c:      	jmp	0x19d9 <perf_unwind_v8+0x19d9>
    1461:      	movabsq	$0xa6f666e496e6f, %rax  # imm = 0xA6F666E496E6F
    146b:      	movq	%rax, 0x17(%rsp)
    1470:      	movabsq	$0x6f6974636e754664, %rax # imm = 0x6F6974636E754664
    147a:      	movq	%rax, 0x10(%rsp)
    147f:      	movabsq	$0x6572616853206f6e, %rax # imm = 0x6572616853206F6E
    1489:      	movq	%rax, 0x8(%rsp)
    148e:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    1498:      	movq	%rax, (%rsp)
    149c:      	movq	%rsp, %rdi
    149f:      	movl	$0x1f, %eax
    14a4:      	movl	$0x6, %ecx
    14a9:      	movl	$0x1f, %esi
    14ae:      	xorl	%eax, %eax
    14b0:      	callq	*%rcx
    14b2:      	jmp	0x9a9 <perf_unwind_v8+0x9a9>
    14b7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    14c1:      	movq	%rax, 0x26(%rsp)
    14c6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    14d0:      	movq	%rax, 0x20(%rsp)
    14d5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    14df:      	movq	%rax, 0x18(%rsp)
    14e4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    14ee:      	movq	%rax, 0x10(%rsp)
    14f3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    14fd:      	movq	%rax, 0x8(%rsp)
    1502:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    150c:      	movq	%rax, (%rsp)
    1510:      	movq	%rsp, %rdi
    1513:      	movl	$0x2e, %eax
    1518:      	movl	$0x6, %ecx
    151d:      	movl	0x70(%rsp), %edx
    1521:      	movl	$0x2e, %esi
    1526:      	xorl	%eax, %eax
    1528:      	callq	*%rcx
    152a:      	jmp	0x66d <perf_unwind_v8+0x66d>
    152f:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    1539:      	movq	%rax, 0x10(%rsp)
    153e:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    1548:      	movq	%rax, 0x8(%rsp)
    154d:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    1557:      	movq	%rax, (%rsp)
    155b:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    1563:      	movq	%rsp, %rdi
    1566:      	movl	$0x1c, %eax
    156b:      	movl	$0x6, %ecx
    1570:      	movl	$0x1c, %esi
    1575:      	xorl	%eax, %eax
    1577:      	movq	%rdx, %r15
    157a:      	callq	*%rcx
    157c:      	movq	%r15, %rdx
    157f:      	jmp	0x5e6 <perf_unwind_v8+0x5e6>
    1584:      	movq	(%rip), %rax            # 0x158b <perf_unwind_v8+0x158b>
    158b:      	cmpl	$0x0, (%rax)
    158e:      	je	0xbf2 <perf_unwind_v8+0xbf2>
    1594:      	movabsq	$0x6c2520786c252078, %rax # imm = 0x6C2520786C252078
    159e:      	movq	%rax, 0x28(%rsp)
    15a3:      	movabsq	$0x6c2520706f74206b, %rax # imm = 0x6C2520706F74206B
    15ad:      	movq	%rax, 0x20(%rsp)
    15b2:      	movabsq	$0x63617473203a626f, %rax # imm = 0x63617473203A626F
    15bc:      	movq	%rax, 0x18(%rsp)
    15c1:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    15cb:      	movq	%rax, 0x10(%rsp)
    15d0:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    15da:      	movq	%rax, 0x8(%rsp)
    15df:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    15e9:      	movq	%rax, (%rsp)
    15ed:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    15f5:      	movq	%rsp, %rdi
    15f8:      	movl	$0x33, %eax
    15fd:      	movl	$0x6, %r9d
    1603:      	movq	0x80(%rsp), %rdx
    160b:      	movq	0x70(%rsp), %r8
    1610:      	movq	0x78(%rsp), %rcx
    1615:      	movl	$0x33, %esi
    161a:      	xorl	%eax, %eax
    161c:      	callq	*%r9
    161f:      	jmp	0xbf2 <perf_unwind_v8+0xbf2>
    1624:      	movzwl	%ax, %r8d
    1628:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    1632:      	movq	%rax, 0x26(%rsp)
    1637:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    1641:      	movq	%rax, 0x20(%rsp)
    1646:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    1650:      	movq	%rax, 0x18(%rsp)
    1655:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    165f:      	movq	%rax, 0x10(%rsp)
    1664:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    166e:      	movq	%rax, 0x8(%rsp)
    1673:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    167d:      	movq	%rax, (%rsp)
    1681:      	movq	%rsp, %rdi
    1684:      	movl	$0x2e, %eax
    1689:      	movl	$0x6, %r9d
    168f:      	movl	$0x2e, %esi
    1694:      	movq	%rdx, %rcx
    1697:      	movq	0x50(%rsp), %rdx
    169c:      	xorl	%eax, %eax
    169e:      	callq	*%r9
    16a1:      	jmp	0x956 <perf_unwind_v8+0x956>
    16a6:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    16b0:      	movq	%rax, 0x28(%rsp)
    16b5:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    16bf:      	movq	%rax, 0x20(%rsp)
    16c4:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    16ce:      	movq	%rax, 0x18(%rsp)
    16d3:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    16dd:      	movq	%rax, 0x10(%rsp)
    16e2:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    16ec:      	movq	%rax, 0x8(%rsp)
    16f1:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    16fb:      	movq	%r13, (%rsp)
    16ff:      	movw	$0xa, 0x30(%rsp)
    1706:      	movq	%rsp, %rdi
    1709:      	movl	$0x32, %eax
    170e:      	movl	$0x6, %r9d
    1714:      	movq	0xf10(%r14), %rcx
    171b:      	movl	$0x32, %esi
    1720:      	movq	%r12, %rdx
    1723:      	movl	%ebp, %r8d
    1726:      	xorl	%eax, %eax
    1728:      	callq	*%r9
    172b:      	movq	(%rip), %rax            # 0x1732 <perf_unwind_v8+0x1732>
    1732:      	cmpl	$0x0, (%rax)
    1735:      	je	0x137b <perf_unwind_v8+0x137b>
    173b:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    1745:      	movq	%rax, 0x27(%rsp)
    174a:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    1754:      	movq	%rax, 0x20(%rsp)
    1759:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1763:      	movq	%rax, 0x18(%rsp)
    1768:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1772:      	movq	%rax, 0x10(%rsp)
    1777:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1781:      	movq	%rax, 0x8(%rsp)
    1786:      	movq	%r13, (%rsp)
    178a:      	movq	%rsp, %rdi
    178d:      	movl	$0x2f, %eax
    1792:      	movl	$0x6, %r8d
    1798:      	movq	0xf18(%r14), %rcx
    179f:      	movq	0xf20(%r14), %rdx
    17a6:      	movl	$0x2f, %esi
    17ab:      	xorl	%eax, %eax
    17ad:      	callq	*%r8
    17b0:      	jmp	0x137b <perf_unwind_v8+0x137b>
    17b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17bf:      	movq	%rax, 0x26(%rsp)
    17c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    17ce:      	movq	%rax, 0x20(%rsp)
    17d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17dd:      	movq	%rax, 0x18(%rsp)
    17e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17ec:      	movq	%rax, 0x10(%rsp)
    17f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17fb:      	movq	%rax, 0x8(%rsp)
    1800:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    180a:      	movq	%rax, (%rsp)
    180e:      	movq	%rsp, %rdi
    1811:      	movl	$0x2e, %eax
    1816:      	movl	$0x6, %ecx
    181b:      	movl	0x70(%rsp), %edx
    181f:      	movl	$0x2e, %esi
    1824:      	xorl	%eax, %eax
    1826:      	callq	*%rcx
    1828:      	jmp	0xbf2 <perf_unwind_v8+0xbf2>
    182d:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    1837:      	movq	%rax, 0x20(%rsp)
    183c:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    1846:      	movq	%rax, 0x18(%rsp)
    184b:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    1855:      	movq	%rax, 0x10(%rsp)
    185a:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    1864:      	movq	%rax, 0x8(%rsp)
    1869:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    1873:      	movq	%rax, (%rsp)
    1877:      	movb	$0x0, 0x28(%rsp)
    187c:      	movq	%rsp, %rdi
    187f:      	movl	$0x29, %eax
    1884:      	movl	$0x6, %r9d
    188a:      	movl	$0x29, %esi
    188f:      	movq	0x50(%rsp), %rdx
    1894:      	movq	0x58(%rsp), %rcx
    1899:      	movq	0x68(%rsp), %r8
    189e:      	xorl	%eax, %eax
    18a0:      	callq	*%r9
    18a3:      	movq	(%rip), %rax            # 0x18aa <perf_unwind_v8+0x18aa>
    18aa:      	cmpl	$0x0, (%rax)
    18ad:      	je	0xd8a <perf_unwind_v8+0xd8a>
    18b3:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    18bd:      	movq	%rax, 0x1d(%rsp)
    18c2:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    18cc:      	movq	%rax, 0x18(%rsp)
    18d1:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    18db:      	movq	%rax, 0x10(%rsp)
    18e0:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    18ea:      	movq	%rax, 0x8(%rsp)
    18ef:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    18f9:      	movq	%rax, (%rsp)
    18fd:      	movq	%rsp, %rdi
    1900:      	movl	$0x25, %eax
    1905:      	movl	$0x6, %r9d
    190b:      	movl	$0x25, %esi
    1910:      	movq	0x90(%rsp), %rdx
    1918:      	movq	0xa0(%rsp), %rcx
    1920:      	movq	0xb8(%rsp), %r8
    1928:      	xorl	%eax, %eax
    192a:      	callq	*%r9
    192d:      	jmp	0xd8a <perf_unwind_v8+0xd8a>
    1932:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    193c:      	movq	%rax, 0x16(%rsp)
    1941:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    194b:      	movq	%rax, 0x10(%rsp)
    1950:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    195a:      	movq	%rax, 0x8(%rsp)
    195f:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    1969:      	movq	%rax, (%rsp)
    196d:      	movq	%rsp, %rdi
    1970:      	movl	$0x1e, %eax
    1975:      	movl	$0x6, %ecx
    197a:      	movzwl	0x20(%r12), %edx
    1980:      	movl	$0x1e, %esi
    1985:      	xorl	%eax, %eax
    1987:      	callq	*%rcx
    1989:      	movl	0x1380(%r14), %eax
    1990:      	movl	0x20(%r12), %ecx
    1995:      	btl	%ecx, %eax
    1998:      	jb	0x1402 <perf_unwind_v8+0x1402>
    199e:      	movl	$0x0, 0x64(%rsp)
    19a6:      	movq	(%rip), %rdi            # 0x19ad <perf_unwind_v8+0x19ad>
    19ad:      	leaq	0x64(%rsp), %rsi
    19b2:      	movl	$0x1, %eax
    19b7:      	callq	*%rax
    19b9:      	testq	%rax, %rax
    19bc:      	je	0x19c3 <perf_unwind_v8+0x19c3>
    19be:      	incq	(%rax)
    19c1:      	jmp	0x19d3 <perf_unwind_v8+0x19d3>
    19c3:      	movq	(%rip), %rax            # 0x19ca <perf_unwind_v8+0x19ca>
    19ca:      	cmpl	$0x0, (%rax)
    19cd:      	jne	0x24e4 <perf_unwind_v8+0x24e4>
    19d3:      	movzwl	0x20(%r12), %ebp
    19d9:      	xorl	%r12d, %r12d
    19dc:      	cmpl	$0x7, %ebp
    19df:      	jne	0x2070 <perf_unwind_v8+0x2070>
    19e5:      	movq	0xed0(%r14), %r13
    19ec:      	movq	0xed8(%r14), %r12
    19f3:      	movq	0xee0(%r14), %rbp
    19fa:      	movq	(%rip), %rax            # 0x1a01 <perf_unwind_v8+0x1a01>
    1a01:      	cmpl	$0x0, (%rax)
    1a04:      	jne	0x1fc0 <perf_unwind_v8+0x1fc0>
    1a0a:      	cmpq	%r12, %rbp
    1a0d:      	jb	0x2025 <perf_unwind_v8+0x2025>
    1a13:      	leaq	0x2000(%r12), %rax
    1a1b:      	cmpq	%rax, %rbp
    1a1e:      	jae	0x2025 <perf_unwind_v8+0x2025>
    1a24:      	addq	$-0x40, %rbp
    1a28:      	movl	$0x40, %eax
    1a2d:      	movl	$0x70, %ecx
    1a32:      	movq	0x98(%rsp), %rdi
    1a3a:      	movl	$0x40, %esi
    1a3f:      	movq	%rbp, %rdx
    1a42:      	callq	*%rcx
    1a44:      	testq	%rax, %rax
    1a47:      	movq	(%rip), %rbp            # 0x1a4e <perf_unwind_v8+0x1a4e>
    1a4e:      	jne	0x138 <perf_unwind_v8+0x138>
    1a54:      	movq	0x48(%rsp), %rax
    1a59:      	movzbl	0x14(%rax), %ecx
    1a5d:      	xorl	%ebp, %ebp
    1a5f:      	cmpq	$0x38, %rcx
    1a63:      	ja	0x220 <perf_unwind_v8+0x220>
    1a69:      	movq	0x48(%rsp), %rax
    1a6e:      	movzbl	0x15(%rax), %eax
    1a72:      	cmpq	$0x38, %rax
    1a76:      	ja	0x220 <perf_unwind_v8+0x220>
    1a7c:      	movq	0x48(%rsp), %rdx
    1a81:      	movzbl	0x16(%rdx), %edx
    1a85:      	cmpq	$0x38, %rdx
    1a89:      	ja	0x220 <perf_unwind_v8+0x220>
    1a8f:      	movq	0x98(%rsp), %rsi
    1a97:      	movq	(%rsi,%rcx), %rbp
    1a9b:      	testb	$0x1, %bpl
    1a9f:      	jne	0x1bbd <perf_unwind_v8+0x1bbd>
    1aa5:      	shrq	%rbp
    1aa8:      	movq	(%rip), %rax            # 0x1aaf <perf_unwind_v8+0x1aaf>
    1aaf:      	cmpl	$0x0, (%rax)
    1ab2:      	jne	0x26f7 <perf_unwind_v8+0x26f7>
    1ab8:      	xorl	%r15d, %r15d
    1abb:      	movzbl	0xf30(%r14), %r12d
    1ac3:      	movl	0x2c0(%r14), %eax
    1aca:      	cmpq	$0x7e, %rax
    1ace:      	ja	0x27d <perf_unwind_v8+0x27d>
    1ad4:      	leal	0x1(%rax), %ecx
    1ad7:      	movl	%ecx, 0x2c0(%r14)
    1ade:      	leaq	(%rax,%rax,2), %rax
    1ae2:      	movq	%r15, 0x2d0(%r14,%rax,8)
    1aea:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    1af2:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    1afb:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    1b03:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    1b0f:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    1b1a:      	movq	0xee0(%r14), %rax
    1b21:      	movq	%rsp, %rdi
    1b24:      	movl	$0x10, %ecx
    1b29:      	movl	$0x70, %r8d
    1b2f:      	movq	0xee0(%r14), %rdx
    1b36:      	movl	$0x10, %esi
    1b3b:      	callq	*%r8
    1b3e:      	testq	%rax, %rax
    1b41:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    1b47:      	movq	0xee0(%r14), %rax
    1b4e:      	addq	$0x10, %rax
    1b52:      	movq	%rax, 0xed8(%r14)
    1b59:      	movq	(%rsp), %rax
    1b5d:      	movq	%rax, 0xee0(%r14)
    1b64:      	movq	0x8(%rsp), %rax
    1b69:      	movq	%rax, 0xed0(%r14)
    1b70:      	movb	$0x1, 0xf30(%r14)
    1b78:      	movq	(%rip), %rax            # 0x1b7f <perf_unwind_v8+0x1b7f>
    1b7f:      	cmpl	$0x0, (%rax)
    1b82:      	jne	0x2753 <perf_unwind_v8+0x2753>
    1b88:      	movl	$0x38, 0x70(%rsp)
    1b90:      	movq	(%rip), %rdi            # 0x1b97 <perf_unwind_v8+0x1b97>
    1b97:      	leaq	0x70(%rsp), %rsi
    1b9c:      	movl	$0x1, %eax
    1ba1:      	callq	*%rax
    1ba3:      	testq	%rax, %rax
    1ba6:      	je	0x1d76 <perf_unwind_v8+0x1d76>
    1bac:      	incq	(%rax)
    1baf:      	movq	(%rip), %rax            # 0x1bb6 <perf_unwind_v8+0x1bb6>
    1bb6:      	movl	(%rax), %eax
    1bb8:      	jmp	0x1d88 <perf_unwind_v8+0x1d88>
    1bbd:      	movq	0x98(%rsp), %rcx
    1bc5:      	movq	(%rcx,%rdx), %r15
    1bc9:      	movq	(%rcx,%rax), %r12
    1bcd:      	movl	%r12d, %ecx
    1bd0:      	andl	$0x3, %ecx
    1bd3:      	andq	$-0x4, %r12
    1bd7:      	xorl	%eax, %eax
    1bd9:      	cmpl	$0x1, %ecx
    1bdc:      	cmovneq	%rax, %r12
    1be0:      	testq	%r12, %r12
    1be3:      	je	0x1c54 <perf_unwind_v8+0x1c54>
    1be5:      	movq	0x48(%rsp), %rax
    1bea:      	movzbl	0xc(%rax), %edx
    1bee:      	addq	%r12, %rdx
    1bf1:      	movq	%rsp, %rdi
    1bf4:      	movl	$0x8, %eax
    1bf9:      	movl	$0x70, %ecx
    1bfe:      	movl	$0x8, %esi
    1c03:      	callq	*%rcx
    1c05:      	testq	%rax, %rax
    1c08:      	jne	0x1c52 <perf_unwind_v8+0x1c52>
    1c0a:      	movq	(%rsp), %rax
    1c0e:      	movl	%eax, %ecx
    1c10:      	andl	$0x3, %ecx
    1c13:      	cmpl	$0x1, %ecx
    1c16:      	jne	0x1c52 <perf_unwind_v8+0x1c52>
    1c18:      	andq	$-0x4, %rax
    1c1c:      	je	0x1c52 <perf_unwind_v8+0x1c52>
    1c1e:      	movq	0x48(%rsp), %rsi
    1c23:      	movzbl	0xd(%rsi), %ecx
    1c27:      	addq	%rax, %rcx
    1c2a:      	movq	%rsp, %rdi
    1c2d:      	movl	$0x2, %edx
    1c32:      	movl	$0x70, %r8d
    1c38:      	movzbl	0xd(%rsi), %edx
    1c3c:      	addq	%rax, %rdx
    1c3f:      	movl	$0x2, %esi
    1c44:      	callq	*%r8
    1c47:      	testq	%rax, %rax
    1c4a:      	jne	0x1c52 <perf_unwind_v8+0x1c52>
    1c4c:      	movzwl	(%rsp), %eax
    1c50:      	jmp	0x1c54 <perf_unwind_v8+0x1c54>
    1c52:      	xorl	%eax, %eax
    1c54:      	movq	0x48(%rsp), %rcx
    1c59:      	cmpw	0x4(%rcx), %ax
    1c5d:      	jae	0x1c69 <perf_unwind_v8+0x1c69>
    1c5f:      	movq	0x48(%rsp), %r8
    1c64:      	jmp	0x494 <perf_unwind_v8+0x494>
    1c69:      	movq	0x48(%rsp), %r8
    1c6e:      	cmpw	0x6(%r8), %ax
    1c73:      	ja	0x494 <perf_unwind_v8+0x494>
    1c79:      	movzbl	0xf(%r8), %edx
    1c7e:      	addq	%r12, %rdx
    1c81:      	movq	%rsp, %rdi
    1c84:      	movl	$0x8, %eax
    1c89:      	movl	$0x70, %ecx
    1c8e:      	movl	$0x8, %esi
    1c93:      	callq	*%rcx
    1c95:      	testq	%rax, %rax
    1c98:      	jne	0x1d29 <perf_unwind_v8+0x1d29>
    1c9e:      	movq	(%rsp), %rcx
    1ca2:      	movq	%rcx, %rax
    1ca5:      	movq	%rcx, 0x50(%rsp)
    1caa:      	andl	$0x3, %eax
    1cad:      	cmpl	$0x1, %eax
    1cb0:      	jne	0x1d29 <perf_unwind_v8+0x1d29>
    1cb2:      	andq	$-0x4, 0x50(%rsp)
    1cb8:      	je	0x1d29 <perf_unwind_v8+0x1d29>
    1cba:      	movq	0x48(%rsp), %rax
    1cbf:      	movzbl	0xc(%rax), %edx
    1cc3:      	addq	0x50(%rsp), %rdx
    1cc8:      	movq	%rsp, %rdi
    1ccb:      	movl	$0x8, %eax
    1cd0:      	movl	$0x70, %ecx
    1cd5:      	movl	$0x8, %esi
    1cda:      	callq	*%rcx
    1cdc:      	testq	%rax, %rax
    1cdf:      	jne	0x1d30 <perf_unwind_v8+0x1d30>
    1ce1:      	movq	(%rsp), %rax
    1ce5:      	movl	%eax, %ecx
    1ce7:      	andl	$0x3, %ecx
    1cea:      	cmpl	$0x1, %ecx
    1ced:      	jne	0x1d30 <perf_unwind_v8+0x1d30>
    1cef:      	andq	$-0x4, %rax
    1cf3:      	je	0x1d30 <perf_unwind_v8+0x1d30>
    1cf5:      	movq	0x48(%rsp), %rsi
    1cfa:      	movzbl	0xd(%rsi), %ecx
    1cfe:      	addq	%rax, %rcx
    1d01:      	movq	%rsp, %rdi
    1d04:      	movl	$0x2, %edx
    1d09:      	movl	$0x70, %r8d
    1d0f:      	movzbl	0xd(%rsi), %edx
    1d13:      	addq	%rax, %rdx
    1d16:      	movl	$0x2, %esi
    1d1b:      	callq	*%r8
    1d1e:      	testq	%rax, %rax
    1d21:      	jne	0x1d30 <perf_unwind_v8+0x1d30>
    1d23:      	movzwl	(%rsp), %eax
    1d27:      	jmp	0x1d32 <perf_unwind_v8+0x1d32>
    1d29:      	xorl	%eax, %eax
    1d2b:      	movq	%rax, 0x50(%rsp)
    1d30:      	xorl	%eax, %eax
    1d32:      	movq	0x48(%rsp), %rcx
    1d37:      	cmpw	0xa(%rcx), %ax
    1d3b:      	jne	0x998 <perf_unwind_v8+0x998>
    1d41:      	movq	%r15, %rbp
    1d44:      	shrq	$0x20, %rbp
    1d48:      	je	0x1e25 <perf_unwind_v8+0x1e25>
    1d4e:      	andl	$0x1, %r15d
    1d52:      	jne	0x1e25 <perf_unwind_v8+0x1e25>
    1d58:      	movq	(%rip), %rax            # 0x1d5f <perf_unwind_v8+0x1d5f>
    1d5f:      	cmpl	$0x0, (%rax)
    1d62:      	jne	0x2aa1 <perf_unwind_v8+0x2aa1>
    1d68:      	movq	0x50(%rsp), %r15
    1d6d:      	orq	$0x1, %r15
    1d71:      	jmp	0x23c5 <perf_unwind_v8+0x23c5>
    1d76:      	xorl	%eax, %eax
    1d78:      	movq	(%rip), %rcx            # 0x1d7f <perf_unwind_v8+0x1d7f>
    1d7f:      	cmpl	$0x0, (%rcx)
    1d82:      	jne	0x2a29 <perf_unwind_v8+0x2a29>
    1d88:      	movq	0xed0(%r14), %r12
    1d8f:      	testq	%r12, %r12
    1d92:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    1d98:      	testl	%eax, %eax
    1d9a:      	jne	0x27c0 <perf_unwind_v8+0x27c0>
    1da0:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1daa:      	cmpq	%rax, %r12
    1dad:      	jbe	0x2855 <perf_unwind_v8+0x2855>
    1db3:      	movq	(%rip), %r13            # 0x1dba <perf_unwind_v8+0x1dba>
    1dba:      	cmpl	$0x0, (%r13)
    1dbf:      	je	0x6b0 <perf_unwind_v8+0x6b0>
    1dc5:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    1dcf:      	movq	%rax, 0x18(%rsp)
    1dd4:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    1dde:      	movq	%rax, 0x10(%rsp)
    1de3:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    1ded:      	movq	%rax, 0x8(%rsp)
    1df2:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    1dfc:      	movq	%rax, (%rsp)
    1e00:      	movw	$0xa, 0x20(%rsp)
    1e07:      	movq	%rsp, %rdi
    1e0a:      	movl	$0x22, %eax
    1e0f:      	movl	$0x6, %ecx
    1e14:      	movl	$0x22, %esi
    1e19:      	movq	%r12, %rdx
    1e1c:      	xorl	%eax, %eax
    1e1e:      	callq	*%rcx
    1e20:      	jmp	0x6b0 <perf_unwind_v8+0x6b0>
    1e25:      	movq	0x48(%rsp), %rax
    1e2a:      	movzbl	0xe(%rax), %edx
    1e2e:      	addq	%r12, %rdx
    1e31:      	movq	%rsp, %rdi
    1e34:      	movl	$0x8, %eax
    1e39:      	movl	$0x70, %ecx
    1e3e:      	movl	$0x8, %esi
    1e43:      	callq	*%rcx
    1e45:      	testq	%rax, %rax
    1e48:      	jne	0x1ed9 <perf_unwind_v8+0x1ed9>
    1e4e:      	movq	(%rsp), %rcx
    1e52:      	movq	%rcx, %rax
    1e55:      	movq	%rcx, 0x58(%rsp)
    1e5a:      	andl	$0x3, %eax
    1e5d:      	cmpl	$0x1, %eax
    1e60:      	jne	0x1ed9 <perf_unwind_v8+0x1ed9>
    1e62:      	andq	$-0x4, 0x58(%rsp)
    1e68:      	je	0x1ed9 <perf_unwind_v8+0x1ed9>
    1e6a:      	movq	0x48(%rsp), %rax
    1e6f:      	movzbl	0xc(%rax), %edx
    1e73:      	addq	0x58(%rsp), %rdx
    1e78:      	movq	%rsp, %rdi
    1e7b:      	movl	$0x8, %eax
    1e80:      	movl	$0x70, %ecx
    1e85:      	movl	$0x8, %esi
    1e8a:      	callq	*%rcx
    1e8c:      	testq	%rax, %rax
    1e8f:      	jne	0x1ee0 <perf_unwind_v8+0x1ee0>
    1e91:      	movq	(%rsp), %rax
    1e95:      	movl	%eax, %ecx
    1e97:      	andl	$0x3, %ecx
    1e9a:      	cmpl	$0x1, %ecx
    1e9d:      	jne	0x1ee0 <perf_unwind_v8+0x1ee0>
    1e9f:      	andq	$-0x4, %rax
    1ea3:      	je	0x1ee0 <perf_unwind_v8+0x1ee0>
    1ea5:      	movq	0x48(%rsp), %rsi
    1eaa:      	movzbl	0xd(%rsi), %ecx
    1eae:      	addq	%rax, %rcx
    1eb1:      	movq	%rsp, %rdi
    1eb4:      	movl	$0x2, %edx
    1eb9:      	movl	$0x70, %r8d
    1ebf:      	movzbl	0xd(%rsi), %edx
    1ec3:      	addq	%rax, %rdx
    1ec6:      	movl	$0x2, %esi
    1ecb:      	callq	*%r8
    1ece:      	testq	%rax, %rax
    1ed1:      	jne	0x1ee0 <perf_unwind_v8+0x1ee0>
    1ed3:      	movzwl	(%rsp), %eax
    1ed7:      	jmp	0x1ee2 <perf_unwind_v8+0x1ee2>
    1ed9:      	xorl	%eax, %eax
    1edb:      	movq	%rax, 0x58(%rsp)
    1ee0:      	xorl	%eax, %eax
    1ee2:      	movq	0x50(%rsp), %r15
    1ee7:      	orq	$0x2, %r15
    1eeb:      	movq	0x48(%rsp), %rcx
    1ef0:      	cmpw	0x8(%rcx), %ax
    1ef4:      	jne	0x2323 <perf_unwind_v8+0x2323>
    1efa:      	movl	$0x60, %eax
    1eff:      	movl	$0x70, %ecx
    1f04:      	movq	0xb0(%rsp), %rdi
    1f0c:      	movq	0x58(%rsp), %rdx
    1f11:      	movl	$0x60, %esi
    1f16:      	callq	*%rcx
    1f18:      	testq	%rax, %rax
    1f1b:      	je	0x2358 <perf_unwind_v8+0x2358>
    1f21:      	movl	$0x3b, 0x70(%rsp)
    1f29:      	movq	(%rip), %rdi            # 0x1f30 <perf_unwind_v8+0x1f30>
    1f30:      	leaq	0x70(%rsp), %rsi
    1f35:      	movl	$0x1, %eax
    1f3a:      	callq	*%rax
    1f3c:      	testq	%rax, %rax
    1f3f:      	jne	0x2353 <perf_unwind_v8+0x2353>
    1f45:      	movq	(%rip), %rax            # 0x1f4c <perf_unwind_v8+0x1f4c>
    1f4c:      	cmpl	$0x0, (%rax)
    1f4f:      	je	0x23c3 <perf_unwind_v8+0x23c3>
    1f55:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f5f:      	movq	%rax, 0x26(%rsp)
    1f64:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f6e:      	movq	%rax, 0x20(%rsp)
    1f73:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f7d:      	movq	%rax, 0x18(%rsp)
    1f82:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f8c:      	movq	%rax, 0x10(%rsp)
    1f91:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f9b:      	movq	%rax, 0x8(%rsp)
    1fa0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1faa:      	movq	%rax, (%rsp)
    1fae:      	movq	%rsp, %rdi
    1fb1:      	movl	$0x2e, %eax
    1fb6:      	movl	$0x6, %ecx
    1fbb:      	jmp	0x2cea <perf_unwind_v8+0x2cea>
    1fc0:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    1fca:      	movq	%rax, 0x17(%rsp)
    1fcf:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    1fd9:      	movq	%rax, 0x10(%rsp)
    1fde:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    1fe8:      	movq	%rax, 0x8(%rsp)
    1fed:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    1ff7:      	movq	%rax, (%rsp)
    1ffb:      	movq	%rsp, %rdi
    1ffe:      	movl	$0x1f, %eax
    2003:      	movl	$0x6, %r9d
    2009:      	movl	$0x1f, %esi
    200e:      	movq	%r13, %rdx
    2011:      	movq	%r12, %rcx
    2014:      	movq	%rbp, %r8
    2017:      	xorl	%eax, %eax
    2019:      	callq	*%r9
    201c:      	cmpq	%r12, %rbp
    201f:      	jae	0x1a13 <perf_unwind_v8+0x1a13>
    2025:      	movq	%rbp, %rdx
    2028:      	movq	(%rip), %rbp            # 0x202f <perf_unwind_v8+0x202f>
    202f:      	cmpl	$0x0, (%rbp)
    2033:      	jne	0x21c4 <perf_unwind_v8+0x21c4>
    2039:      	movl	$0x39, 0x70(%rsp)
    2041:      	movq	(%rip), %rdi            # 0x2048 <perf_unwind_v8+0x2048>
    2048:      	leaq	0x70(%rsp), %rsi
    204d:      	movl	$0x1, %eax
    2052:      	callq	*%rax
    2054:      	testq	%rax, %rax
    2057:      	je	0x205e <perf_unwind_v8+0x205e>
    2059:      	incq	(%rax)
    205c:      	jmp	0x2068 <perf_unwind_v8+0x2068>
    205e:      	cmpl	$0x0, (%rbp)
    2062:      	jne	0x2233 <perf_unwind_v8+0x2233>
    2068:      	movl	$0x1388, %r12d          # imm = 0x1388
    206e:      	xorl	%ebp, %ebp
    2070:      	movl	%r12d, 0xf2c(%r14)
    2077:      	movl	$0x0, (%rsp)
    207e:      	movq	(%rip), %rdi            # 0x2085 <perf_unwind_v8+0x2085>
    2085:      	movq	%rsp, %rsi
    2088:      	movl	$0x1, %eax
    208d:      	callq	*%rax
    208f:      	testq	%rax, %rax
    2092:      	je	0x20d4 <perf_unwind_v8+0x20d4>
    2094:      	movzbl	0x1384(%rax), %ecx
    209b:      	movl	%ebp, %edx
    209d:      	cmpb	$0x1d, %cl
    20a0:      	jb	0x2101 <perf_unwind_v8+0x2101>
    20a2:      	movq	%rax, %r14
    20a5:      	movl	$0x5, 0xf2c(%rax)
    20af:      	movl	$0x44, 0x70(%rsp)
    20b7:      	movq	(%rip), %rdi            # 0x20be <perf_unwind_v8+0x20be>
    20be:      	leaq	0x70(%rsp), %rsi
    20c3:      	movl	$0x1, %eax
    20c8:      	callq	*%rax
    20ca:      	testq	%rax, %rax
    20cd:      	je	0x20e4 <perf_unwind_v8+0x20e4>
    20cf:      	incq	(%rax)
    20d2:      	jmp	0x20f4 <perf_unwind_v8+0x20f4>
    20d4:      	movq	(%rip), %rcx            # 0x20db <perf_unwind_v8+0x20db>
    20db:      	xorl	%edx, %edx
    20dd:      	movl	$0xc, %eax
    20e2:      	jmp	0x2117 <perf_unwind_v8+0x2117>
    20e4:      	movq	(%rip), %rax            # 0x20eb <perf_unwind_v8+0x20eb>
    20eb:      	cmpl	$0x0, (%rax)
    20ee:      	jne	0x22ab <perf_unwind_v8+0x22ab>
    20f4:      	movq	%r14, %rax
    20f7:      	movzbl	0x1384(%r14), %ecx
    20ff:      	xorl	%edx, %edx
    2101:      	incb	%cl
    2103:      	movb	%cl, 0x1384(%rax)
    2109:      	movl	%edx, %ecx
    210b:      	movq	(%rip), %rsi            # 0x2112 <perf_unwind_v8+0x2112>
    2112:      	movl	$0xc, %eax
    2117:      	movq	(%rip), %rsi            # 0x211e <perf_unwind_v8+0x211e>
    211e:      	movq	%rbx, %rdi
    2121:      	callq	*%rax
    2123:      	movq	(%rip), %rax            # 0x212a <perf_unwind_v8+0x212a>
    212a:      	cmpl	$0x0, (%rax)
    212d:      	jne	0x2146 <perf_unwind_v8+0x2146>
    212f:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    2134:      	addq	$0xc8, %rsp
    213b:      	popq	%rbx
    213c:      	popq	%r12
    213e:      	popq	%r13
    2140:      	popq	%r14
    2142:      	popq	%r15
    2144:      	popq	%rbp
    2145:      	retq
    2146:      	movabsq	$0x656c696166202964, %rax # imm = 0x656C696166202964
    2150:      	movq	%rax, 0x28(%rsp)
    2155:      	movabsq	$0x2528207265646e69, %rax # imm = 0x2528207265646E69
    215f:      	movq	%rax, 0x20(%rsp)
    2164:      	movabsq	$0x776e7520656d6172, %rax # imm = 0x776E7520656D6172
    216e:      	movq	%rax, 0x18(%rsp)
    2173:      	movabsq	$0x66207478656e2072, %rax # imm = 0x66207478656E2072
    217d:      	movq	%rax, 0x10(%rsp)
    2182:      	movabsq	$0x6f66206c6c616320, %rax # imm = 0x6F66206C6C616320
    218c:      	movq	%rax, 0x8(%rsp)
    2191:      	movabsq	$0x6c696174203a3876, %rax # imm = 0x6C696174203A3876
    219b:      	movq	%rax, (%rsp)
    219f:      	movl	$0xa6465, 0x2f(%rsp)    # imm = 0xA6465
    21a7:      	movq	%rsp, %rdi
    21aa:      	movl	$0x33, %eax
    21af:      	movl	$0x6, %ecx
    21b4:      	movl	$0x33, %esi
    21b9:      	movl	%ebp, %edx
    21bb:      	xorl	%eax, %eax
    21bd:      	callq	*%rcx
    21bf:      	jmp	0x212f <perf_unwind_v8+0x212f>
    21c4:      	movabsq	$0xa786c25202f2078, %rax # imm = 0xA786C25202F2078
    21ce:      	movq	%rax, 0x20(%rsp)
    21d3:      	movabsq	$0x6c252066666f2072, %rax # imm = 0x6C252066666F2072
    21dd:      	movq	%rax, 0x18(%rsp)
    21e2:      	movabsq	$0x6166206f6f742072, %rax # imm = 0x6166206F6F742072
    21ec:      	movq	%rax, 0x10(%rsp)
    21f1:      	movabsq	$0x65746e696f702065, %rax # imm = 0x65746E696F702065
    21fb:      	movq	%rax, 0x8(%rsp)
    2200:      	movabsq	$0x6d617266203a3876, %rax # imm = 0x6D617266203A3876
    220a:      	movq	%rax, (%rsp)
    220e:      	movb	$0x0, 0x28(%rsp)
    2213:      	movq	%rsp, %rdi
    2216:      	movl	$0x29, %eax
    221b:      	movl	$0x6, %r8d
    2221:      	movl	$0x29, %esi
    2226:      	movq	%r12, %rcx
    2229:      	xorl	%eax, %eax
    222b:      	callq	*%r8
    222e:      	jmp	0x2039 <perf_unwind_v8+0x2039>
    2233:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    223d:      	movq	%rax, 0x26(%rsp)
    2242:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    224c:      	movq	%rax, 0x20(%rsp)
    2251:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    225b:      	movq	%rax, 0x18(%rsp)
    2260:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    226a:      	movq	%rax, 0x10(%rsp)
    226f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2279:      	movq	%rax, 0x8(%rsp)
    227e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2288:      	movq	%rax, (%rsp)
    228c:      	movq	%rsp, %rdi
    228f:      	movl	$0x2e, %eax
    2294:      	movl	$0x6, %ecx
    2299:      	movl	0x70(%rsp), %edx
    229d:      	movl	$0x2e, %esi
    22a2:      	xorl	%eax, %eax
    22a4:      	callq	*%rcx
    22a6:      	jmp	0x2068 <perf_unwind_v8+0x2068>
    22ab:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    22b5:      	movq	%rax, 0x26(%rsp)
    22ba:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    22c4:      	movq	%rax, 0x20(%rsp)
    22c9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    22d3:      	movq	%rax, 0x18(%rsp)
    22d8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    22e2:      	movq	%rax, 0x10(%rsp)
    22e7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22f1:      	movq	%rax, 0x8(%rsp)
    22f6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2300:      	movq	%rax, (%rsp)
    2304:      	movq	%rsp, %rdi
    2307:      	movl	$0x2e, %eax
    230c:      	movl	$0x6, %ecx
    2311:      	movl	0x70(%rsp), %edx
    2315:      	movl	$0x2e, %esi
    231a:      	xorl	%eax, %eax
    231c:      	callq	*%rcx
    231e:      	jmp	0x20f4 <perf_unwind_v8+0x20f4>
    2323:      	movq	(%rip), %rcx            # 0x232a <perf_unwind_v8+0x232a>
    232a:      	cmpl	$0x0, (%rcx)
    232d:      	jne	0x2af3 <perf_unwind_v8+0x2af3>
    2333:      	movl	$0x3b, 0x70(%rsp)
    233b:      	movq	(%rip), %rdi            # 0x2342 <perf_unwind_v8+0x2342>
    2342:      	leaq	0x70(%rsp), %rsi
    2347:      	movl	$0x1, %eax
    234c:      	callq	*%rax
    234e:      	testq	%rax, %rax
    2351:      	je	0x23b3 <perf_unwind_v8+0x23b3>
    2353:      	incq	(%rax)
    2356:      	jmp	0x23c3 <perf_unwind_v8+0x23c3>
    2358:      	movq	0x48(%rsp), %rax
    235d:      	movzbl	0x12(%rax), %ecx
    2361:      	xorl	%ebp, %ebp
    2363:      	cmpq	$0x5c, %rcx
    2367:      	ja	0x220 <perf_unwind_v8+0x220>
    236d:      	movq	0x48(%rsp), %rax
    2372:      	movzbl	0x13(%rax), %eax
    2376:      	cmpq	$0x5c, %rax
    237a:      	ja	0x220 <perf_unwind_v8+0x220>
    2380:      	movq	0x48(%rsp), %rdx
    2385:      	cmpb	$0x0, 0x10(%rdx)
    2389:      	movzbl	0x11(%rdx), %edx
    238d:      	movq	%rdx, 0x68(%rsp)
    2392:      	je	0x25ab <perf_unwind_v8+0x25ab>
    2398:      	movq	0xb0(%rsp), %rdx
    23a0:      	movq	0x68(%rsp), %rsi
    23a5:      	movq	(%rdx,%rsi), %rsi
    23a9:      	movq	%rsi, 0x68(%rsp)
    23ae:      	jmp	0x25ba <perf_unwind_v8+0x25ba>
    23b3:      	movq	(%rip), %rax            # 0x23ba <perf_unwind_v8+0x23ba>
    23ba:      	cmpl	$0x0, (%rax)
    23bd:      	jne	0x2c84 <perf_unwind_v8+0x2c84>
    23c3:      	xorl	%ebp, %ebp
    23c5:      	movzbl	0xf30(%r14), %r12d
    23cd:      	movq	(%rip), %rax            # 0x23d4 <perf_unwind_v8+0x23d4>
    23d4:      	cmpl	$0x0, (%rax)
    23d7:      	je	0x1ac3 <perf_unwind_v8+0x1ac3>
    23dd:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    23e7:      	movq	%rax, 0x30(%rsp)
    23ec:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    23f6:      	movq	%rax, 0x28(%rsp)
    23fb:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    2405:      	movq	%rax, 0x20(%rsp)
    240a:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    2414:      	movq	%rax, 0x18(%rsp)
    2419:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    2423:      	movq	%rax, 0x10(%rsp)
    2428:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    2432:      	movq	%rax, 0x8(%rsp)
    2437:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2441:      	movq	%rax, (%rsp)
    2445:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    244d:      	movq	%rsp, %rdi
    2450:      	movl	$0x3c, %eax
    2455:      	movl	$0x6, %r8d
    245b:      	movl	$0x3c, %esi
    2460:      	movq	%rbp, %rdx
    2463:      	movq	%r15, %rcx
    2466:      	xorl	%eax, %eax
    2468:      	callq	*%r8
    246b:      	jmp	0x1ac3 <perf_unwind_v8+0x1ac3>
    2470:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    247a:      	movq	%rax, 0x28(%rsp)
    247f:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    2489:      	movq	%rax, 0x20(%rsp)
    248e:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    2498:      	movq	%rax, 0x18(%rsp)
    249d:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    24a7:      	movq	%rax, 0x10(%rsp)
    24ac:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    24b6:      	movq	%rax, 0x8(%rsp)
    24bb:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    24c5:      	movq	%rax, (%rsp)
    24c9:      	movq	%rsp, %rdi
    24cc:      	movl	$0x30, %eax
    24d1:      	movl	$0x6, %ecx
    24d6:      	movl	$0x30, %esi
    24db:      	xorl	%eax, %eax
    24dd:      	callq	*%rcx
    24df:      	jmp	0xbf2 <perf_unwind_v8+0xbf2>
    24e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    24ee:      	movq	%rax, 0x26(%rsp)
    24f3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    24fd:      	movq	%rax, 0x20(%rsp)
    2502:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    250c:      	movq	%rax, 0x18(%rsp)
    2511:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    251b:      	movq	%rax, 0x10(%rsp)
    2520:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    252a:      	movq	%rax, 0x8(%rsp)
    252f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2539:      	movq	%rax, (%rsp)
    253d:      	movq	%rsp, %rdi
    2540:      	movl	$0x2e, %eax
    2545:      	movl	$0x6, %ecx
    254a:      	movl	0x64(%rsp), %edx
    254e:      	movl	$0x2e, %esi
    2553:      	xorl	%eax, %eax
    2555:      	callq	*%rcx
    2557:      	jmp	0x19d3 <perf_unwind_v8+0x19d3>
    255c:      	movabsq	$0x746e696f70206b63, %rax # imm = 0x746E696F70206B63
    2566:      	movq	%rax, 0x10(%rsp)
    256b:      	movabsq	$0x6174732064616220, %rax # imm = 0x6174732064616220
    2575:      	movq	%rax, 0x8(%rsp)
    257a:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    2584:      	movq	%rax, (%rsp)
    2588:      	movl	$0xa7265, 0x18(%rsp)    # imm = 0xA7265
    2590:      	movq	%rsp, %rdi
    2593:      	movl	$0x1c, %eax
    2598:      	movl	$0x6, %ecx
    259d:      	movl	$0x1c, %esi
    25a2:      	xorl	%eax, %eax
    25a4:      	callq	*%rcx
    25a6:      	jmp	0xe48 <perf_unwind_v8+0xe48>
    25ab:      	movq	0x68(%rsp), %rdx
    25b0:      	addq	0x58(%rsp), %rdx
    25b5:      	movq	%rdx, 0x68(%rsp)
    25ba:      	movq	0xb0(%rsp), %rdx
    25c2:      	movl	(%rdx,%rcx), %esi
    25c5:      	movq	0x48(%rsp), %rcx
    25ca:      	movzbl	0x17(%rcx), %edi
    25ce:      	movl	%edi, 0xb8(%rsp)
    25d5:      	movzbl	0x18(%rcx), %ecx
    25d9:      	movq	%rsi, 0xa0(%rsp)
    25e1:      	addq	0x68(%rsp), %rsi
    25e6:      	movq	%rsi, 0x90(%rsp)
    25ee:      	andl	(%rdx,%rax), %ecx
    25f1:      	movl	%ecx, 0xac(%rsp)
    25f8:      	movq	(%rip), %rax            # 0x25ff <perf_unwind_v8+0x25ff>
    25ff:      	cmpl	$0x0, (%rax)
    2602:      	jne	0x2cfc <perf_unwind_v8+0x2cfc>
    2608:      	movq	%r13, %rbp
    260b:      	subq	0x68(%rsp), %rbp
    2610:      	jb	0x2662 <perf_unwind_v8+0x2662>
    2612:      	cmpq	0x90(%rsp), %r13
    261a:      	jae	0x2662 <perf_unwind_v8+0x2662>
    261c:      	movl	0xb8(%rsp), %eax
    2623:      	shrxl	%eax, 0xac(%rsp), %eax
    262d:      	movq	0x48(%rsp), %rcx
    2632:      	movzbl	0x19(%rcx), %ecx
    2636:      	orq	$0x4, %r12
    263a:      	movq	0x58(%rsp), %r15
    263f:      	orq	$0x3, %r15
    2643:      	cmpl	%ecx, %eax
    2645:      	cmoveq	%r12, %r15
    2649:      	movq	0xa0(%rsp), %rcx
    2651:      	shll	$0x4, %ecx
    2654:      	orl	%eax, %ecx
    2656:      	shlq	$0x20, %rcx
    265a:      	orq	%rcx, %rbp
    265d:      	jmp	0x23c5 <perf_unwind_v8+0x23c5>
    2662:      	movq	(%rip), %rax            # 0x2669 <perf_unwind_v8+0x2669>
    2669:      	cmpl	$0x0, (%rax)
    266c:      	jne	0x3736 <perf_unwind_v8+0x3736>
    2672:      	xorl	%ebp, %ebp
    2674:      	jmp	0x1abb <perf_unwind_v8+0x1abb>
    2679:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2683:      	movq	%rax, 0x26(%rsp)
    2688:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2692:      	movq	%rax, 0x20(%rsp)
    2697:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    26a1:      	movq	%rax, 0x18(%rsp)
    26a6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    26b0:      	movq	%rax, 0x10(%rsp)
    26b5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    26bf:      	movq	%rax, 0x8(%rsp)
    26c4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    26ce:      	movq	%rax, (%rsp)
    26d2:      	movq	%rsp, %rdi
    26d5:      	movl	$0x2e, %eax
    26da:      	movl	$0x6, %ecx
    26df:      	movl	0x64(%rsp), %edx
    26e3:      	movl	$0x2e, %esi
    26e8:      	xorl	%eax, %eax
    26ea:      	callq	*%rcx
    26ec:      	movl	$0x1388, %r12d          # imm = 0x1388
    26f2:      	jmp	0x2070 <perf_unwind_v8+0x2070>
    26f7:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    2701:      	movq	%rax, 0x15(%rsp)
    2706:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    2710:      	movq	%rax, 0x10(%rsp)
    2715:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    271f:      	movq	%rax, 0x8(%rsp)
    2724:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    272e:      	movq	%rax, (%rsp)
    2732:      	movq	%rsp, %rdi
    2735:      	movl	$0x1d, %eax
    273a:      	movl	$0x6, %ecx
    273f:      	xorl	%r15d, %r15d
    2742:      	movl	$0x1d, %esi
    2747:      	movq	%rbp, %rdx
    274a:      	xorl	%eax, %eax
    274c:      	callq	*%rcx
    274e:      	jmp	0x23c5 <perf_unwind_v8+0x23c5>
    2753:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    275d:      	movq	%rax, 0x17(%rsp)
    2762:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    276c:      	movq	%rax, 0x10(%rsp)
    2771:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    277b:      	movq	%rax, 0x8(%rsp)
    2780:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    278a:      	movq	%rax, (%rsp)
    278e:      	movq	%rsp, %rdi
    2791:      	movl	$0x1f, %eax
    2796:      	movl	$0x6, %r9d
    279c:      	movq	0xed0(%r14), %rdx
    27a3:      	movq	0xed8(%r14), %rcx
    27aa:      	movq	0xee0(%r14), %r8
    27b1:      	movl	$0x1f, %esi
    27b6:      	xorl	%eax, %eax
    27b8:      	callq	*%r9
    27bb:      	jmp	0x1b88 <perf_unwind_v8+0x1b88>
    27c0:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    27ca:      	movq	%rax, 0x28(%rsp)
    27cf:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    27d9:      	movq	%rax, 0x20(%rsp)
    27de:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    27e8:      	movq	%rax, 0x18(%rsp)
    27ed:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    27f7:      	movq	%rax, 0x10(%rsp)
    27fc:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    2806:      	movq	%rax, 0x8(%rsp)
    280b:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    2815:      	movq	%rax, (%rsp)
    2819:      	movb	$0x0, 0x30(%rsp)
    281e:      	movq	%rsp, %rdi
    2821:      	movl	$0x31, %eax
    2826:      	movl	$0x6, %ecx
    282b:      	movl	0x2c0(%r14), %edx
    2832:      	movl	$0x31, %esi
    2837:      	xorl	%eax, %eax
    2839:      	callq	*%rcx
    283b:      	movq	0xed0(%r14), %r12
    2842:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    284c:      	cmpq	%rax, %r12
    284f:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    2855:      	cmpq	$0x1000, %r12           # imm = 0x1000
    285c:      	jae	0x28c9 <perf_unwind_v8+0x28c9>
    285e:      	movq	(%rip), %r13            # 0x2865 <perf_unwind_v8+0x2865>
    2865:      	cmpl	$0x0, (%r13)
    286a:      	je	0x12eb <perf_unwind_v8+0x12eb>
    2870:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    287a:      	movq	%rax, 0x16(%rsp)
    287f:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    2889:      	movq	%rax, 0x10(%rsp)
    288e:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    2898:      	movq	%rax, 0x8(%rsp)
    289d:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    28a7:      	movq	%rax, (%rsp)
    28ab:      	movq	%rsp, %rdi
    28ae:      	movl	$0x1e, %eax
    28b3:      	movl	$0x6, %ecx
    28b8:      	movl	$0x1e, %esi
    28bd:      	movq	%r12, %rdx
    28c0:      	xorl	%eax, %eax
    28c2:      	callq	*%rcx
    28c4:      	jmp	0x12eb <perf_unwind_v8+0x12eb>
    28c9:      	movl	(%r14), %eax
    28cc:      	movl	$0x60, 0x70(%rsp)
    28d4:      	movbel	%eax, 0x74(%rsp)
    28da:      	movbeq	%r12, 0x78(%rsp)
    28e1:      	movq	(%rip), %rdi            # 0x28e8 <perf_unwind_v8+0x28e8>
    28e8:      	leaq	0x70(%rsp), %rsi
    28ed:      	movl	$0x1, %eax
    28f2:      	callq	*%rax
    28f4:      	testq	%rax, %rax
    28f7:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    28fd:      	movq	0x8(%rax), %rbp
    2901:      	movq	%rbp, %rcx
    2904:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    290e:      	andq	%rdx, %rcx
    2911:      	movq	%rcx, 0xf20(%r14)
    2918:      	movq	(%rax), %rax
    291b:      	movq	%rax, 0xf10(%r14)
    2922:      	shrq	$0x38, %rbp
    2926:      	movq	%r12, %rax
    2929:      	subq	%rcx, %rax
    292c:      	movq	%rax, 0xf18(%r14)
    2933:      	movq	(%rip), %rax            # 0x293a <perf_unwind_v8+0x293a>
    293a:      	cmpl	$0x0, (%rax)
    293d:      	jne	0x2b75 <perf_unwind_v8+0x2b75>
    2943:      	cmpl	$0x1, %ebp
    2946:      	jne	0x2ea3 <perf_unwind_v8+0x2ea3>
    294c:      	movq	0xf10(%r14), %rax
    2953:      	movq	%rax, 0x70(%rsp)
    2958:      	movq	0xf18(%r14), %r13
    295f:      	movq	(%rip), %rdi            # 0x2966 <perf_unwind_v8+0x2966>
    2966:      	leaq	0x70(%rsp), %rsi
    296b:      	movl	$0x1, %eax
    2970:      	callq	*%rax
    2972:      	movl	$0x1, %ebp
    2977:      	testq	%rax, %rax
    297a:      	je	0x2ea3 <perf_unwind_v8+0x2ea3>
    2980:      	movq	%rax, %r12
    2983:      	cmpq	%r13, (%rax)
    2986:      	ja	0x298f <perf_unwind_v8+0x298f>
    2988:      	cmpq	%r13, 0x8(%r12)
    298d:      	jae	0x29a5 <perf_unwind_v8+0x29a5>
    298f:      	cmpq	%r13, 0x10(%r12)
    2994:      	ja	0x2ea3 <perf_unwind_v8+0x2ea3>
    299a:      	cmpq	%r13, 0x18(%r12)
    299f:      	jb	0x2ea3 <perf_unwind_v8+0x2ea3>
    29a5:      	movq	(%rip), %rax            # 0x29ac <perf_unwind_v8+0x29ac>
    29ac:      	cmpl	$0x0, (%rax)
    29af:      	jne	0x2dfc <perf_unwind_v8+0x2dfc>
    29b5:      	movl	0x1380(%r14), %eax
    29bc:      	movl	0x20(%r12), %ecx
    29c1:      	btl	%ecx, %eax
    29c4:      	jae	0x2e68 <perf_unwind_v8+0x2e68>
    29ca:      	movq	(%rip), %rax            # 0x29d1 <perf_unwind_v8+0x29d1>
    29d1:      	cmpl	$0x0, (%rax)
    29d4:      	je	0x2ea3 <perf_unwind_v8+0x2ea3>
    29da:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    29e4:      	movq	%rax, 0x10(%rsp)
    29e9:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    29f3:      	movq	%rax, 0x8(%rsp)
    29f8:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2a02:      	movq	%rax, (%rsp)
    2a06:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    2a0e:      	movq	%rsp, %rdi
    2a11:      	movl	$0x1b, %eax
    2a16:      	movl	$0x6, %ecx
    2a1b:      	movl	$0x1b, %esi
    2a20:      	xorl	%eax, %eax
    2a22:      	callq	*%rcx
    2a24:      	jmp	0x2ea3 <perf_unwind_v8+0x2ea3>
    2a29:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2a33:      	movq	%rax, 0x26(%rsp)
    2a38:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2a42:      	movq	%rax, 0x20(%rsp)
    2a47:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2a51:      	movq	%rax, 0x18(%rsp)
    2a56:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2a60:      	movq	%rax, 0x10(%rsp)
    2a65:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2a6f:      	movq	%rax, 0x8(%rsp)
    2a74:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a7e:      	movq	%rax, (%rsp)
    2a82:      	movq	%rsp, %rdi
    2a85:      	movl	$0x2e, %eax
    2a8a:      	movl	$0x6, %ecx
    2a8f:      	movl	0x70(%rsp), %edx
    2a93:      	movl	$0x2e, %esi
    2a98:      	xorl	%eax, %eax
    2a9a:      	callq	*%rcx
    2a9c:      	jmp	0x1baf <perf_unwind_v8+0x1baf>
    2aa1:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    2aab:      	movq	%rax, 0x10(%rsp)
    2ab0:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    2aba:      	movq	%rax, 0x8(%rsp)
    2abf:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    2ac9:      	movq	%rax, (%rsp)
    2acd:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    2ad5:      	movq	%rsp, %rdi
    2ad8:      	movl	$0x1c, %eax
    2add:      	movl	$0x6, %ecx
    2ae2:      	movl	$0x1c, %esi
    2ae7:      	movq	%rbp, %rdx
    2aea:      	xorl	%eax, %eax
    2aec:      	callq	*%rcx
    2aee:      	jmp	0x1d68 <perf_unwind_v8+0x1d68>
    2af3:      	movzwl	%ax, %r8d
    2af7:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    2b01:      	movq	%rax, 0x26(%rsp)
    2b06:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    2b10:      	movq	%rax, 0x20(%rsp)
    2b15:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    2b1f:      	movq	%rax, 0x18(%rsp)
    2b24:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    2b2e:      	movq	%rax, 0x10(%rsp)
    2b33:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    2b3d:      	movq	%rax, 0x8(%rsp)
    2b42:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    2b4c:      	movq	%rax, (%rsp)
    2b50:      	movq	%rsp, %rdi
    2b53:      	movl	$0x2e, %eax
    2b58:      	movl	$0x6, %r9d
    2b5e:      	movl	$0x2e, %esi
    2b63:      	movq	%r12, %rdx
    2b66:      	movq	0x58(%rsp), %rcx
    2b6b:      	xorl	%eax, %eax
    2b6d:      	callq	*%r9
    2b70:      	jmp	0x2333 <perf_unwind_v8+0x2333>
    2b75:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    2b7f:      	movq	%rax, 0x28(%rsp)
    2b84:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    2b8e:      	movq	%rax, 0x20(%rsp)
    2b93:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    2b9d:      	movq	%rax, 0x18(%rsp)
    2ba2:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    2bac:      	movq	%rax, 0x10(%rsp)
    2bb1:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    2bbb:      	movq	%rax, 0x8(%rsp)
    2bc0:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    2bca:      	movq	%r13, (%rsp)
    2bce:      	movw	$0xa, 0x30(%rsp)
    2bd5:      	movq	%rsp, %rdi
    2bd8:      	movl	$0x32, %eax
    2bdd:      	movl	$0x6, %r9d
    2be3:      	movq	0xf10(%r14), %rcx
    2bea:      	movl	$0x32, %esi
    2bef:      	movq	%r12, %rdx
    2bf2:      	movl	%ebp, %r8d
    2bf5:      	xorl	%eax, %eax
    2bf7:      	callq	*%r9
    2bfa:      	movq	(%rip), %rax            # 0x2c01 <perf_unwind_v8+0x2c01>
    2c01:      	cmpl	$0x0, (%rax)
    2c04:      	je	0x2943 <perf_unwind_v8+0x2943>
    2c0a:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    2c14:      	movq	%rax, 0x27(%rsp)
    2c19:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    2c23:      	movq	%rax, 0x20(%rsp)
    2c28:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    2c32:      	movq	%rax, 0x18(%rsp)
    2c37:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    2c41:      	movq	%rax, 0x10(%rsp)
    2c46:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    2c50:      	movq	%rax, 0x8(%rsp)
    2c55:      	movq	%r13, (%rsp)
    2c59:      	movq	%rsp, %rdi
    2c5c:      	movl	$0x2f, %eax
    2c61:      	movl	$0x6, %r8d
    2c67:      	movq	0xf18(%r14), %rcx
    2c6e:      	movq	0xf20(%r14), %rdx
    2c75:      	movl	$0x2f, %esi
    2c7a:      	xorl	%eax, %eax
    2c7c:      	callq	*%r8
    2c7f:      	jmp	0x2943 <perf_unwind_v8+0x2943>
    2c84:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2c8e:      	movq	%rax, 0x26(%rsp)
    2c93:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2c9d:      	movq	%rax, 0x20(%rsp)
    2ca2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2cac:      	movq	%rax, 0x18(%rsp)
    2cb1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2cbb:      	movq	%rax, 0x10(%rsp)
    2cc0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2cca:      	movq	%rax, 0x8(%rsp)
    2ccf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2cd9:      	movq	%rax, (%rsp)
    2cdd:      	movq	%rsp, %rdi
    2ce0:      	movl	$0x2e, %eax
    2ce5:      	movl	$0x6, %ecx
    2cea:      	movl	0x70(%rsp), %edx
    2cee:      	movl	$0x2e, %esi
    2cf3:      	xorl	%eax, %eax
    2cf5:      	callq	*%rcx
    2cf7:      	jmp	0x23c3 <perf_unwind_v8+0x23c3>
    2cfc:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    2d06:      	movq	%rax, 0x20(%rsp)
    2d0b:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    2d15:      	movq	%rax, 0x18(%rsp)
    2d1a:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    2d24:      	movq	%rax, 0x10(%rsp)
    2d29:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    2d33:      	movq	%rax, 0x8(%rsp)
    2d38:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    2d42:      	movq	%rax, (%rsp)
    2d46:      	movb	$0x0, 0x28(%rsp)
    2d4b:      	movq	%rsp, %rdi
    2d4e:      	movl	$0x29, %eax
    2d53:      	movl	$0x6, %r9d
    2d59:      	movl	$0x29, %esi
    2d5e:      	movq	%r12, %rdx
    2d61:      	movq	0x50(%rsp), %rcx
    2d66:      	movq	0x58(%rsp), %r8
    2d6b:      	xorl	%eax, %eax
    2d6d:      	callq	*%r9
    2d70:      	movq	(%rip), %rax            # 0x2d77 <perf_unwind_v8+0x2d77>
    2d77:      	cmpl	$0x0, (%rax)
    2d7a:      	je	0x2608 <perf_unwind_v8+0x2608>
    2d80:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    2d8a:      	movq	%rax, 0x1d(%rsp)
    2d8f:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    2d99:      	movq	%rax, 0x18(%rsp)
    2d9e:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    2da8:      	movq	%rax, 0x10(%rsp)
    2dad:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    2db7:      	movq	%rax, 0x8(%rsp)
    2dbc:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    2dc6:      	movq	%rax, (%rsp)
    2dca:      	movq	%rsp, %rdi
    2dcd:      	movl	$0x25, %eax
    2dd2:      	movl	$0x6, %r9d
    2dd8:      	movl	$0x25, %esi
    2ddd:      	movq	0x68(%rsp), %rdx
    2de2:      	movq	0x90(%rsp), %rcx
    2dea:      	movq	0xa0(%rsp), %r8
    2df2:      	xorl	%eax, %eax
    2df4:      	callq	*%r9
    2df7:      	jmp	0x2608 <perf_unwind_v8+0x2608>
    2dfc:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    2e06:      	movq	%rax, 0x16(%rsp)
    2e0b:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    2e15:      	movq	%rax, 0x10(%rsp)
    2e1a:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    2e24:      	movq	%rax, 0x8(%rsp)
    2e29:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2e33:      	movq	%rax, (%rsp)
    2e37:      	movq	%rsp, %rdi
    2e3a:      	movl	$0x1e, %eax
    2e3f:      	movl	$0x6, %ecx
    2e44:      	movzwl	0x20(%r12), %edx
    2e4a:      	movl	$0x1e, %esi
    2e4f:      	xorl	%eax, %eax
    2e51:      	callq	*%rcx
    2e53:      	movl	0x1380(%r14), %eax
    2e5a:      	movl	0x20(%r12), %ecx
    2e5f:      	btl	%ecx, %eax
    2e62:      	jb	0x29ca <perf_unwind_v8+0x29ca>
    2e68:      	movl	$0x0, 0x64(%rsp)
    2e70:      	movq	(%rip), %rdi            # 0x2e77 <perf_unwind_v8+0x2e77>
    2e77:      	leaq	0x64(%rsp), %rsi
    2e7c:      	movl	$0x1, %eax
    2e81:      	callq	*%rax
    2e83:      	testq	%rax, %rax
    2e86:      	je	0x2e8d <perf_unwind_v8+0x2e8d>
    2e88:      	incq	(%rax)
    2e8b:      	jmp	0x2e9d <perf_unwind_v8+0x2e9d>
    2e8d:      	movq	(%rip), %rax            # 0x2e94 <perf_unwind_v8+0x2e94>
    2e94:      	cmpl	$0x0, (%rax)
    2e97:      	jne	0x37ac <perf_unwind_v8+0x37ac>
    2e9d:      	movzwl	0x20(%r12), %ebp
    2ea3:      	xorl	%r12d, %r12d
    2ea6:      	cmpl	$0x7, %ebp
    2ea9:      	jne	0x2070 <perf_unwind_v8+0x2070>
    2eaf:      	movq	0xed0(%r14), %r13
    2eb6:      	movq	0xed8(%r14), %r12
    2ebd:      	movq	0xee0(%r14), %rbp
    2ec4:      	movq	(%rip), %rax            # 0x2ecb <perf_unwind_v8+0x2ecb>
    2ecb:      	cmpl	$0x0, (%rax)
    2ece:      	jne	0x357f <perf_unwind_v8+0x357f>
    2ed4:      	cmpq	%r12, %rbp
    2ed7:      	jb	0x2025 <perf_unwind_v8+0x2025>
    2edd:      	leaq	0x2000(%r12), %rax
    2ee5:      	cmpq	%rax, %rbp
    2ee8:      	jae	0x2025 <perf_unwind_v8+0x2025>
    2eee:      	addq	$-0x40, %rbp
    2ef2:      	movl	$0x40, %eax
    2ef7:      	movl	$0x70, %ecx
    2efc:      	movq	0x98(%rsp), %rdi
    2f04:      	movl	$0x40, %esi
    2f09:      	movq	%rbp, %rdx
    2f0c:      	callq	*%rcx
    2f0e:      	testq	%rax, %rax
    2f11:      	movq	(%rip), %rbp            # 0x2f18 <perf_unwind_v8+0x2f18>
    2f18:      	jne	0x138 <perf_unwind_v8+0x138>
    2f1e:      	movq	0x48(%rsp), %rax
    2f23:      	movzbl	0x14(%rax), %ecx
    2f27:      	xorl	%ebp, %ebp
    2f29:      	cmpq	$0x38, %rcx
    2f2d:      	ja	0x220 <perf_unwind_v8+0x220>
    2f33:      	movq	0x48(%rsp), %rax
    2f38:      	movzbl	0x15(%rax), %eax
    2f3c:      	cmpq	$0x38, %rax
    2f40:      	ja	0x220 <perf_unwind_v8+0x220>
    2f46:      	movq	0x48(%rsp), %rdx
    2f4b:      	movzbl	0x16(%rdx), %edx
    2f4f:      	cmpq	$0x38, %rdx
    2f53:      	ja	0x220 <perf_unwind_v8+0x220>
    2f59:      	movq	0x98(%rsp), %rsi
    2f61:      	movq	(%rsi,%rcx), %rbp
    2f65:      	testb	$0x1, %bpl
    2f69:      	jne	0x3087 <perf_unwind_v8+0x3087>
    2f6f:      	shrq	%rbp
    2f72:      	movq	(%rip), %rax            # 0x2f79 <perf_unwind_v8+0x2f79>
    2f79:      	cmpl	$0x0, (%rax)
    2f7c:      	jne	0x38f2 <perf_unwind_v8+0x38f2>
    2f82:      	xorl	%r15d, %r15d
    2f85:      	movzbl	0xf30(%r14), %r12d
    2f8d:      	movl	0x2c0(%r14), %eax
    2f94:      	cmpq	$0x7e, %rax
    2f98:      	ja	0x27d <perf_unwind_v8+0x27d>
    2f9e:      	leal	0x1(%rax), %ecx
    2fa1:      	movl	%ecx, 0x2c0(%r14)
    2fa8:      	leaq	(%rax,%rax,2), %rax
    2fac:      	movq	%r15, 0x2d0(%r14,%rax,8)
    2fb4:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    2fbc:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    2fc5:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    2fcd:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    2fd9:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    2fe4:      	movq	0xee0(%r14), %rax
    2feb:      	movq	%rsp, %rdi
    2fee:      	movl	$0x10, %ecx
    2ff3:      	movl	$0x70, %r8d
    2ff9:      	movq	0xee0(%r14), %rdx
    3000:      	movl	$0x10, %esi
    3005:      	callq	*%r8
    3008:      	testq	%rax, %rax
    300b:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    3011:      	movq	0xee0(%r14), %rax
    3018:      	addq	$0x10, %rax
    301c:      	movq	%rax, 0xed8(%r14)
    3023:      	movq	(%rsp), %rax
    3027:      	movq	%rax, 0xee0(%r14)
    302e:      	movq	0x8(%rsp), %rax
    3033:      	movq	%rax, 0xed0(%r14)
    303a:      	movb	$0x1, 0xf30(%r14)
    3042:      	movq	(%rip), %rax            # 0x3049 <perf_unwind_v8+0x3049>
    3049:      	cmpl	$0x0, (%rax)
    304c:      	jne	0x394e <perf_unwind_v8+0x394e>
    3052:      	movl	$0x38, 0x70(%rsp)
    305a:      	movq	(%rip), %rdi            # 0x3061 <perf_unwind_v8+0x3061>
    3061:      	leaq	0x70(%rsp), %rsi
    3066:      	movl	$0x1, %eax
    306b:      	callq	*%rax
    306d:      	testq	%rax, %rax
    3070:      	je	0x323a <perf_unwind_v8+0x323a>
    3076:      	incq	(%rax)
    3079:      	movq	(%rip), %rax            # 0x3080 <perf_unwind_v8+0x3080>
    3080:      	movl	(%rax), %eax
    3082:      	jmp	0x324c <perf_unwind_v8+0x324c>
    3087:      	movq	0x98(%rsp), %rcx
    308f:      	movq	(%rcx,%rdx), %r15
    3093:      	movq	(%rcx,%rax), %r12
    3097:      	movl	%r12d, %ecx
    309a:      	andl	$0x3, %ecx
    309d:      	andq	$-0x4, %r12
    30a1:      	xorl	%eax, %eax
    30a3:      	cmpl	$0x1, %ecx
    30a6:      	cmovneq	%rax, %r12
    30aa:      	testq	%r12, %r12
    30ad:      	je	0x311e <perf_unwind_v8+0x311e>
    30af:      	movq	0x48(%rsp), %rax
    30b4:      	movzbl	0xc(%rax), %edx
    30b8:      	addq	%r12, %rdx
    30bb:      	movq	%rsp, %rdi
    30be:      	movl	$0x8, %eax
    30c3:      	movl	$0x70, %ecx
    30c8:      	movl	$0x8, %esi
    30cd:      	callq	*%rcx
    30cf:      	testq	%rax, %rax
    30d2:      	jne	0x311c <perf_unwind_v8+0x311c>
    30d4:      	movq	(%rsp), %rax
    30d8:      	movl	%eax, %ecx
    30da:      	andl	$0x3, %ecx
    30dd:      	cmpl	$0x1, %ecx
    30e0:      	jne	0x311c <perf_unwind_v8+0x311c>
    30e2:      	andq	$-0x4, %rax
    30e6:      	je	0x311c <perf_unwind_v8+0x311c>
    30e8:      	movq	0x48(%rsp), %rsi
    30ed:      	movzbl	0xd(%rsi), %ecx
    30f1:      	addq	%rax, %rcx
    30f4:      	movq	%rsp, %rdi
    30f7:      	movl	$0x2, %edx
    30fc:      	movl	$0x70, %r8d
    3102:      	movzbl	0xd(%rsi), %edx
    3106:      	addq	%rax, %rdx
    3109:      	movl	$0x2, %esi
    310e:      	callq	*%r8
    3111:      	testq	%rax, %rax
    3114:      	jne	0x311c <perf_unwind_v8+0x311c>
    3116:      	movzwl	(%rsp), %eax
    311a:      	jmp	0x311e <perf_unwind_v8+0x311e>
    311c:      	xorl	%eax, %eax
    311e:      	movq	0x48(%rsp), %rcx
    3123:      	cmpw	0x4(%rcx), %ax
    3127:      	jb	0x1c5f <perf_unwind_v8+0x1c5f>
    312d:      	movq	0x48(%rsp), %r8
    3132:      	cmpw	0x6(%r8), %ax
    3137:      	ja	0x494 <perf_unwind_v8+0x494>
    313d:      	movzbl	0xf(%r8), %edx
    3142:      	addq	%r12, %rdx
    3145:      	movq	%rsp, %rdi
    3148:      	movl	$0x8, %eax
    314d:      	movl	$0x70, %ecx
    3152:      	movl	$0x8, %esi
    3157:      	callq	*%rcx
    3159:      	testq	%rax, %rax
    315c:      	jne	0x31ed <perf_unwind_v8+0x31ed>
    3162:      	movq	(%rsp), %rcx
    3166:      	movq	%rcx, %rax
    3169:      	movq	%rcx, 0x50(%rsp)
    316e:      	andl	$0x3, %eax
    3171:      	cmpl	$0x1, %eax
    3174:      	jne	0x31ed <perf_unwind_v8+0x31ed>
    3176:      	andq	$-0x4, 0x50(%rsp)
    317c:      	je	0x31ed <perf_unwind_v8+0x31ed>
    317e:      	movq	0x48(%rsp), %rax
    3183:      	movzbl	0xc(%rax), %edx
    3187:      	addq	0x50(%rsp), %rdx
    318c:      	movq	%rsp, %rdi
    318f:      	movl	$0x8, %eax
    3194:      	movl	$0x70, %ecx
    3199:      	movl	$0x8, %esi
    319e:      	callq	*%rcx
    31a0:      	testq	%rax, %rax
    31a3:      	jne	0x31f4 <perf_unwind_v8+0x31f4>
    31a5:      	movq	(%rsp), %rax
    31a9:      	movl	%eax, %ecx
    31ab:      	andl	$0x3, %ecx
    31ae:      	cmpl	$0x1, %ecx
    31b1:      	jne	0x31f4 <perf_unwind_v8+0x31f4>
    31b3:      	andq	$-0x4, %rax
    31b7:      	je	0x31f4 <perf_unwind_v8+0x31f4>
    31b9:      	movq	0x48(%rsp), %rsi
    31be:      	movzbl	0xd(%rsi), %ecx
    31c2:      	addq	%rax, %rcx
    31c5:      	movq	%rsp, %rdi
    31c8:      	movl	$0x2, %edx
    31cd:      	movl	$0x70, %r8d
    31d3:      	movzbl	0xd(%rsi), %edx
    31d7:      	addq	%rax, %rdx
    31da:      	movl	$0x2, %esi
    31df:      	callq	*%r8
    31e2:      	testq	%rax, %rax
    31e5:      	jne	0x31f4 <perf_unwind_v8+0x31f4>
    31e7:      	movzwl	(%rsp), %eax
    31eb:      	jmp	0x31f6 <perf_unwind_v8+0x31f6>
    31ed:      	xorl	%eax, %eax
    31ef:      	movq	%rax, 0x50(%rsp)
    31f4:      	xorl	%eax, %eax
    31f6:      	movq	0x48(%rsp), %rcx
    31fb:      	cmpw	0xa(%rcx), %ax
    31ff:      	jne	0x998 <perf_unwind_v8+0x998>
    3205:      	movq	%r15, %rbp
    3208:      	shrq	$0x20, %rbp
    320c:      	je	0x33e4 <perf_unwind_v8+0x33e4>
    3212:      	andl	$0x1, %r15d
    3216:      	jne	0x33e4 <perf_unwind_v8+0x33e4>
    321c:      	movq	(%rip), %rax            # 0x3223 <perf_unwind_v8+0x3223>
    3223:      	cmpl	$0x0, (%rax)
    3226:      	jne	0x3acd <perf_unwind_v8+0x3acd>
    322c:      	movq	0x50(%rsp), %r15
    3231:      	orq	$0x1, %r15
    3235:      	jmp	0x368b <perf_unwind_v8+0x368b>
    323a:      	xorl	%eax, %eax
    323c:      	movq	(%rip), %rcx            # 0x3243 <perf_unwind_v8+0x3243>
    3243:      	cmpl	$0x0, (%rcx)
    3246:      	jne	0x3a55 <perf_unwind_v8+0x3a55>
    324c:      	movq	0xed0(%r14), %r12
    3253:      	testq	%r12, %r12
    3256:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    325c:      	testl	%eax, %eax
    325e:      	jne	0x39bb <perf_unwind_v8+0x39bb>
    3264:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    326e:      	cmpq	%rax, %r12
    3271:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    3277:      	cmpq	$0x1000, %r12           # imm = 0x1000
    327e:      	jb	0x285e <perf_unwind_v8+0x285e>
    3284:      	movl	(%r14), %eax
    3287:      	movl	$0x60, 0x70(%rsp)
    328f:      	movbel	%eax, 0x74(%rsp)
    3295:      	movbeq	%r12, 0x78(%rsp)
    329c:      	movq	(%rip), %rdi            # 0x32a3 <perf_unwind_v8+0x32a3>
    32a3:      	leaq	0x70(%rsp), %rsi
    32a8:      	movl	$0x1, %eax
    32ad:      	callq	*%rax
    32af:      	testq	%rax, %rax
    32b2:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    32b8:      	movq	0x8(%rax), %rbp
    32bc:      	movq	%rbp, %rcx
    32bf:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    32c9:      	andq	%rdx, %rcx
    32cc:      	movq	%rcx, 0xf20(%r14)
    32d3:      	movq	(%rax), %rax
    32d6:      	movq	%rax, 0xf10(%r14)
    32dd:      	shrq	$0x38, %rbp
    32e1:      	movq	%r12, %rax
    32e4:      	subq	%rcx, %rax
    32e7:      	movq	%rax, 0xf18(%r14)
    32ee:      	movq	(%rip), %rax            # 0x32f5 <perf_unwind_v8+0x32f5>
    32f5:      	cmpl	$0x0, (%rax)
    32f8:      	jne	0x3ba1 <perf_unwind_v8+0x3ba1>
    32fe:      	cmpl	$0x1, %ebp
    3301:      	jne	0x3dcf <perf_unwind_v8+0x3dcf>
    3307:      	movq	0xf10(%r14), %rax
    330e:      	movq	%rax, 0x70(%rsp)
    3313:      	movq	0xf18(%r14), %r13
    331a:      	movq	(%rip), %rdi            # 0x3321 <perf_unwind_v8+0x3321>
    3321:      	leaq	0x70(%rsp), %rsi
    3326:      	movl	$0x1, %eax
    332b:      	callq	*%rax
    332d:      	movl	$0x1, %ebp
    3332:      	testq	%rax, %rax
    3335:      	je	0x3dcf <perf_unwind_v8+0x3dcf>
    333b:      	movq	%rax, %r12
    333e:      	cmpq	%r13, (%rax)
    3341:      	ja	0x334a <perf_unwind_v8+0x334a>
    3343:      	cmpq	%r13, 0x8(%r12)
    3348:      	jae	0x3360 <perf_unwind_v8+0x3360>
    334a:      	cmpq	%r13, 0x10(%r12)
    334f:      	ja	0x3dcf <perf_unwind_v8+0x3dcf>
    3355:      	cmpq	%r13, 0x18(%r12)
    335a:      	jb	0x3dcf <perf_unwind_v8+0x3dcf>
    3360:      	movq	(%rip), %rax            # 0x3367 <perf_unwind_v8+0x3367>
    3367:      	cmpl	$0x0, (%rax)
    336a:      	jne	0x3d28 <perf_unwind_v8+0x3d28>
    3370:      	movl	0x1380(%r14), %eax
    3377:      	movl	0x20(%r12), %ecx
    337c:      	btl	%ecx, %eax
    337f:      	jae	0x3d94 <perf_unwind_v8+0x3d94>
    3385:      	movq	(%rip), %rax            # 0x338c <perf_unwind_v8+0x338c>
    338c:      	cmpl	$0x0, (%rax)
    338f:      	je	0x3dcf <perf_unwind_v8+0x3dcf>
    3395:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    339f:      	movq	%rax, 0x10(%rsp)
    33a4:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    33ae:      	movq	%rax, 0x8(%rsp)
    33b3:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    33bd:      	movq	%rax, (%rsp)
    33c1:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    33c9:      	movq	%rsp, %rdi
    33cc:      	movl	$0x1b, %eax
    33d1:      	movl	$0x6, %ecx
    33d6:      	movl	$0x1b, %esi
    33db:      	xorl	%eax, %eax
    33dd:      	callq	*%rcx
    33df:      	jmp	0x3dcf <perf_unwind_v8+0x3dcf>
    33e4:      	movq	0x48(%rsp), %rax
    33e9:      	movzbl	0xe(%rax), %edx
    33ed:      	addq	%r12, %rdx
    33f0:      	movq	%rsp, %rdi
    33f3:      	movl	$0x8, %eax
    33f8:      	movl	$0x70, %ecx
    33fd:      	movl	$0x8, %esi
    3402:      	callq	*%rcx
    3404:      	testq	%rax, %rax
    3407:      	jne	0x3498 <perf_unwind_v8+0x3498>
    340d:      	movq	(%rsp), %rcx
    3411:      	movq	%rcx, %rax
    3414:      	movq	%rcx, 0x58(%rsp)
    3419:      	andl	$0x3, %eax
    341c:      	cmpl	$0x1, %eax
    341f:      	jne	0x3498 <perf_unwind_v8+0x3498>
    3421:      	andq	$-0x4, 0x58(%rsp)
    3427:      	je	0x3498 <perf_unwind_v8+0x3498>
    3429:      	movq	0x48(%rsp), %rax
    342e:      	movzbl	0xc(%rax), %edx
    3432:      	addq	0x58(%rsp), %rdx
    3437:      	movq	%rsp, %rdi
    343a:      	movl	$0x8, %eax
    343f:      	movl	$0x70, %ecx
    3444:      	movl	$0x8, %esi
    3449:      	callq	*%rcx
    344b:      	testq	%rax, %rax
    344e:      	jne	0x349f <perf_unwind_v8+0x349f>
    3450:      	movq	(%rsp), %rax
    3454:      	movl	%eax, %ecx
    3456:      	andl	$0x3, %ecx
    3459:      	cmpl	$0x1, %ecx
    345c:      	jne	0x349f <perf_unwind_v8+0x349f>
    345e:      	andq	$-0x4, %rax
    3462:      	je	0x349f <perf_unwind_v8+0x349f>
    3464:      	movq	0x48(%rsp), %rsi
    3469:      	movzbl	0xd(%rsi), %ecx
    346d:      	addq	%rax, %rcx
    3470:      	movq	%rsp, %rdi
    3473:      	movl	$0x2, %edx
    3478:      	movl	$0x70, %r8d
    347e:      	movzbl	0xd(%rsi), %edx
    3482:      	addq	%rax, %rdx
    3485:      	movl	$0x2, %esi
    348a:      	callq	*%r8
    348d:      	testq	%rax, %rax
    3490:      	jne	0x349f <perf_unwind_v8+0x349f>
    3492:      	movzwl	(%rsp), %eax
    3496:      	jmp	0x34a1 <perf_unwind_v8+0x34a1>
    3498:      	xorl	%eax, %eax
    349a:      	movq	%rax, 0x58(%rsp)
    349f:      	xorl	%eax, %eax
    34a1:      	movq	0x50(%rsp), %r15
    34a6:      	orq	$0x2, %r15
    34aa:      	movq	0x48(%rsp), %rcx
    34af:      	cmpw	0x8(%rcx), %ax
    34b3:      	jne	0x35e9 <perf_unwind_v8+0x35e9>
    34b9:      	movl	$0x60, %eax
    34be:      	movl	$0x70, %ecx
    34c3:      	movq	0xb0(%rsp), %rdi
    34cb:      	movq	0x58(%rsp), %rdx
    34d0:      	movl	$0x60, %esi
    34d5:      	callq	*%rcx
    34d7:      	testq	%rax, %rax
    34da:      	je	0x361e <perf_unwind_v8+0x361e>
    34e0:      	movl	$0x3b, 0x70(%rsp)
    34e8:      	movq	(%rip), %rdi            # 0x34ef <perf_unwind_v8+0x34ef>
    34ef:      	leaq	0x70(%rsp), %rsi
    34f4:      	movl	$0x1, %eax
    34f9:      	callq	*%rax
    34fb:      	testq	%rax, %rax
    34fe:      	jne	0x3619 <perf_unwind_v8+0x3619>
    3504:      	movq	(%rip), %rax            # 0x350b <perf_unwind_v8+0x350b>
    350b:      	cmpl	$0x0, (%rax)
    350e:      	je	0x3689 <perf_unwind_v8+0x3689>
    3514:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    351e:      	movq	%rax, 0x26(%rsp)
    3523:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    352d:      	movq	%rax, 0x20(%rsp)
    3532:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    353c:      	movq	%rax, 0x18(%rsp)
    3541:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    354b:      	movq	%rax, 0x10(%rsp)
    3550:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    355a:      	movq	%rax, 0x8(%rsp)
    355f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3569:      	movq	%rax, (%rsp)
    356d:      	movq	%rsp, %rdi
    3570:      	movl	$0x2e, %eax
    3575:      	movl	$0x6, %ecx
    357a:      	jmp	0x3d16 <perf_unwind_v8+0x3d16>
    357f:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    3589:      	movq	%rax, 0x17(%rsp)
    358e:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    3598:      	movq	%rax, 0x10(%rsp)
    359d:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    35a7:      	movq	%rax, 0x8(%rsp)
    35ac:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    35b6:      	movq	%rax, (%rsp)
    35ba:      	movq	%rsp, %rdi
    35bd:      	movl	$0x1f, %eax
    35c2:      	movl	$0x6, %r9d
    35c8:      	movl	$0x1f, %esi
    35cd:      	movq	%r13, %rdx
    35d0:      	movq	%r12, %rcx
    35d3:      	movq	%rbp, %r8
    35d6:      	xorl	%eax, %eax
    35d8:      	callq	*%r9
    35db:      	cmpq	%r12, %rbp
    35de:      	jae	0x2edd <perf_unwind_v8+0x2edd>
    35e4:      	jmp	0x2025 <perf_unwind_v8+0x2025>
    35e9:      	movq	(%rip), %rcx            # 0x35f0 <perf_unwind_v8+0x35f0>
    35f0:      	cmpl	$0x0, (%rcx)
    35f3:      	jne	0x3b1f <perf_unwind_v8+0x3b1f>
    35f9:      	movl	$0x3b, 0x70(%rsp)
    3601:      	movq	(%rip), %rdi            # 0x3608 <perf_unwind_v8+0x3608>
    3608:      	leaq	0x70(%rsp), %rsi
    360d:      	movl	$0x1, %eax
    3612:      	callq	*%rax
    3614:      	testq	%rax, %rax
    3617:      	je	0x3679 <perf_unwind_v8+0x3679>
    3619:      	incq	(%rax)
    361c:      	jmp	0x3689 <perf_unwind_v8+0x3689>
    361e:      	movq	0x48(%rsp), %rax
    3623:      	movzbl	0x12(%rax), %ecx
    3627:      	xorl	%ebp, %ebp
    3629:      	cmpq	$0x5c, %rcx
    362d:      	ja	0x220 <perf_unwind_v8+0x220>
    3633:      	movq	0x48(%rsp), %rax
    3638:      	movzbl	0x13(%rax), %eax
    363c:      	cmpq	$0x5c, %rax
    3640:      	ja	0x220 <perf_unwind_v8+0x220>
    3646:      	movq	0x48(%rsp), %rdx
    364b:      	cmpb	$0x0, 0x10(%rdx)
    364f:      	movzbl	0x11(%rdx), %edx
    3653:      	movq	%rdx, 0x68(%rsp)
    3658:      	je	0x3824 <perf_unwind_v8+0x3824>
    365e:      	movq	0xb0(%rsp), %rdx
    3666:      	movq	0x68(%rsp), %rsi
    366b:      	movq	(%rdx,%rsi), %rsi
    366f:      	movq	%rsi, 0x68(%rsp)
    3674:      	jmp	0x3833 <perf_unwind_v8+0x3833>
    3679:      	movq	(%rip), %rax            # 0x3680 <perf_unwind_v8+0x3680>
    3680:      	cmpl	$0x0, (%rax)
    3683:      	jne	0x3cb0 <perf_unwind_v8+0x3cb0>
    3689:      	xorl	%ebp, %ebp
    368b:      	movzbl	0xf30(%r14), %r12d
    3693:      	movq	(%rip), %rax            # 0x369a <perf_unwind_v8+0x369a>
    369a:      	cmpl	$0x0, (%rax)
    369d:      	je	0x2f8d <perf_unwind_v8+0x2f8d>
    36a3:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    36ad:      	movq	%rax, 0x30(%rsp)
    36b2:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    36bc:      	movq	%rax, 0x28(%rsp)
    36c1:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    36cb:      	movq	%rax, 0x20(%rsp)
    36d0:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    36da:      	movq	%rax, 0x18(%rsp)
    36df:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    36e9:      	movq	%rax, 0x10(%rsp)
    36ee:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    36f8:      	movq	%rax, 0x8(%rsp)
    36fd:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3707:      	movq	%rax, (%rsp)
    370b:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    3713:      	movq	%rsp, %rdi
    3716:      	movl	$0x3c, %eax
    371b:      	movl	$0x6, %r8d
    3721:      	movl	$0x3c, %esi
    3726:      	movq	%rbp, %rdx
    3729:      	movq	%r15, %rcx
    372c:      	xorl	%eax, %eax
    372e:      	callq	*%r8
    3731:      	jmp	0x2f8d <perf_unwind_v8+0x2f8d>
    3736:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    3740:      	movq	%rax, 0x28(%rsp)
    3745:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    374f:      	movq	%rax, 0x20(%rsp)
    3754:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    375e:      	movq	%rax, 0x18(%rsp)
    3763:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    376d:      	movq	%rax, 0x10(%rsp)
    3772:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    377c:      	movq	%rax, 0x8(%rsp)
    3781:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    378b:      	movq	%rax, (%rsp)
    378f:      	movq	%rsp, %rdi
    3792:      	movl	$0x30, %eax
    3797:      	movl	$0x6, %ecx
    379c:      	xorl	%ebp, %ebp
    379e:      	movl	$0x30, %esi
    37a3:      	xorl	%eax, %eax
    37a5:      	callq	*%rcx
    37a7:      	jmp	0x23c5 <perf_unwind_v8+0x23c5>
    37ac:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    37b6:      	movq	%rax, 0x26(%rsp)
    37bb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    37c5:      	movq	%rax, 0x20(%rsp)
    37ca:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    37d4:      	movq	%rax, 0x18(%rsp)
    37d9:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    37e3:      	movq	%rax, 0x10(%rsp)
    37e8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    37f2:      	movq	%rax, 0x8(%rsp)
    37f7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3801:      	movq	%rax, (%rsp)
    3805:      	movq	%rsp, %rdi
    3808:      	movl	$0x2e, %eax
    380d:      	movl	$0x6, %ecx
    3812:      	movl	0x64(%rsp), %edx
    3816:      	movl	$0x2e, %esi
    381b:      	xorl	%eax, %eax
    381d:      	callq	*%rcx
    381f:      	jmp	0x2e9d <perf_unwind_v8+0x2e9d>
    3824:      	movq	0x68(%rsp), %rdx
    3829:      	addq	0x58(%rsp), %rdx
    382e:      	movq	%rdx, 0x68(%rsp)
    3833:      	movq	0xb0(%rsp), %rdx
    383b:      	movl	(%rdx,%rcx), %esi
    383e:      	movq	0x48(%rsp), %rcx
    3843:      	movzbl	0x17(%rcx), %edi
    3847:      	movl	%edi, 0xb8(%rsp)
    384e:      	movzbl	0x18(%rcx), %ecx
    3852:      	movq	%rsi, 0xa0(%rsp)
    385a:      	addq	0x68(%rsp), %rsi
    385f:      	movq	%rsi, 0x90(%rsp)
    3867:      	andl	(%rdx,%rax), %ecx
    386a:      	movl	%ecx, 0xac(%rsp)
    3871:      	movq	(%rip), %rax            # 0x3878 <perf_unwind_v8+0x3878>
    3878:      	cmpl	$0x0, (%rax)
    387b:      	jne	0x4740 <perf_unwind_v8+0x4740>
    3881:      	movq	%r13, %rbp
    3884:      	subq	0x68(%rsp), %rbp
    3889:      	jb	0x38db <perf_unwind_v8+0x38db>
    388b:      	cmpq	0x90(%rsp), %r13
    3893:      	jae	0x38db <perf_unwind_v8+0x38db>
    3895:      	movl	0xb8(%rsp), %eax
    389c:      	shrxl	%eax, 0xac(%rsp), %eax
    38a6:      	movq	0x48(%rsp), %rcx
    38ab:      	movzbl	0x19(%rcx), %ecx
    38af:      	orq	$0x4, %r12
    38b3:      	movq	0x58(%rsp), %r15
    38b8:      	orq	$0x3, %r15
    38bc:      	cmpl	%ecx, %eax
    38be:      	cmoveq	%r12, %r15
    38c2:      	movq	0xa0(%rsp), %rcx
    38ca:      	shll	$0x4, %ecx
    38cd:      	orl	%eax, %ecx
    38cf:      	shlq	$0x20, %rcx
    38d3:      	orq	%rcx, %rbp
    38d6:      	jmp	0x368b <perf_unwind_v8+0x368b>
    38db:      	movq	(%rip), %rax            # 0x38e2 <perf_unwind_v8+0x38e2>
    38e2:      	cmpl	$0x0, (%rax)
    38e5:      	jne	0x4840 <perf_unwind_v8+0x4840>
    38eb:      	xorl	%ebp, %ebp
    38ed:      	jmp	0x2f85 <perf_unwind_v8+0x2f85>
    38f2:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    38fc:      	movq	%rax, 0x15(%rsp)
    3901:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    390b:      	movq	%rax, 0x10(%rsp)
    3910:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    391a:      	movq	%rax, 0x8(%rsp)
    391f:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    3929:      	movq	%rax, (%rsp)
    392d:      	movq	%rsp, %rdi
    3930:      	movl	$0x1d, %eax
    3935:      	movl	$0x6, %ecx
    393a:      	xorl	%r15d, %r15d
    393d:      	movl	$0x1d, %esi
    3942:      	movq	%rbp, %rdx
    3945:      	xorl	%eax, %eax
    3947:      	callq	*%rcx
    3949:      	jmp	0x368b <perf_unwind_v8+0x368b>
    394e:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    3958:      	movq	%rax, 0x17(%rsp)
    395d:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    3967:      	movq	%rax, 0x10(%rsp)
    396c:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    3976:      	movq	%rax, 0x8(%rsp)
    397b:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    3985:      	movq	%rax, (%rsp)
    3989:      	movq	%rsp, %rdi
    398c:      	movl	$0x1f, %eax
    3991:      	movl	$0x6, %r9d
    3997:      	movq	0xed0(%r14), %rdx
    399e:      	movq	0xed8(%r14), %rcx
    39a5:      	movq	0xee0(%r14), %r8
    39ac:      	movl	$0x1f, %esi
    39b1:      	xorl	%eax, %eax
    39b3:      	callq	*%r9
    39b6:      	jmp	0x3052 <perf_unwind_v8+0x3052>
    39bb:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    39c5:      	movq	%rax, 0x28(%rsp)
    39ca:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    39d4:      	movq	%rax, 0x20(%rsp)
    39d9:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    39e3:      	movq	%rax, 0x18(%rsp)
    39e8:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    39f2:      	movq	%rax, 0x10(%rsp)
    39f7:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    3a01:      	movq	%rax, 0x8(%rsp)
    3a06:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    3a10:      	movq	%rax, (%rsp)
    3a14:      	movb	$0x0, 0x30(%rsp)
    3a19:      	movq	%rsp, %rdi
    3a1c:      	movl	$0x31, %eax
    3a21:      	movl	$0x6, %ecx
    3a26:      	movl	0x2c0(%r14), %edx
    3a2d:      	movl	$0x31, %esi
    3a32:      	xorl	%eax, %eax
    3a34:      	callq	*%rcx
    3a36:      	movq	0xed0(%r14), %r12
    3a3d:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3a47:      	cmpq	%rax, %r12
    3a4a:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    3a50:      	jmp	0x3277 <perf_unwind_v8+0x3277>
    3a55:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3a5f:      	movq	%rax, 0x26(%rsp)
    3a64:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3a6e:      	movq	%rax, 0x20(%rsp)
    3a73:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3a7d:      	movq	%rax, 0x18(%rsp)
    3a82:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3a8c:      	movq	%rax, 0x10(%rsp)
    3a91:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3a9b:      	movq	%rax, 0x8(%rsp)
    3aa0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3aaa:      	movq	%rax, (%rsp)
    3aae:      	movq	%rsp, %rdi
    3ab1:      	movl	$0x2e, %eax
    3ab6:      	movl	$0x6, %ecx
    3abb:      	movl	0x70(%rsp), %edx
    3abf:      	movl	$0x2e, %esi
    3ac4:      	xorl	%eax, %eax
    3ac6:      	callq	*%rcx
    3ac8:      	jmp	0x3079 <perf_unwind_v8+0x3079>
    3acd:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    3ad7:      	movq	%rax, 0x10(%rsp)
    3adc:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    3ae6:      	movq	%rax, 0x8(%rsp)
    3aeb:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    3af5:      	movq	%rax, (%rsp)
    3af9:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    3b01:      	movq	%rsp, %rdi
    3b04:      	movl	$0x1c, %eax
    3b09:      	movl	$0x6, %ecx
    3b0e:      	movl	$0x1c, %esi
    3b13:      	movq	%rbp, %rdx
    3b16:      	xorl	%eax, %eax
    3b18:      	callq	*%rcx
    3b1a:      	jmp	0x322c <perf_unwind_v8+0x322c>
    3b1f:      	movzwl	%ax, %r8d
    3b23:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    3b2d:      	movq	%rax, 0x26(%rsp)
    3b32:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    3b3c:      	movq	%rax, 0x20(%rsp)
    3b41:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    3b4b:      	movq	%rax, 0x18(%rsp)
    3b50:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    3b5a:      	movq	%rax, 0x10(%rsp)
    3b5f:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    3b69:      	movq	%rax, 0x8(%rsp)
    3b6e:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    3b78:      	movq	%rax, (%rsp)
    3b7c:      	movq	%rsp, %rdi
    3b7f:      	movl	$0x2e, %eax
    3b84:      	movl	$0x6, %r9d
    3b8a:      	movl	$0x2e, %esi
    3b8f:      	movq	%r12, %rdx
    3b92:      	movq	0x58(%rsp), %rcx
    3b97:      	xorl	%eax, %eax
    3b99:      	callq	*%r9
    3b9c:      	jmp	0x35f9 <perf_unwind_v8+0x35f9>
    3ba1:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    3bab:      	movq	%rax, 0x28(%rsp)
    3bb0:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    3bba:      	movq	%rax, 0x20(%rsp)
    3bbf:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    3bc9:      	movq	%rax, 0x18(%rsp)
    3bce:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    3bd8:      	movq	%rax, 0x10(%rsp)
    3bdd:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    3be7:      	movq	%rax, 0x8(%rsp)
    3bec:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    3bf6:      	movq	%r13, (%rsp)
    3bfa:      	movw	$0xa, 0x30(%rsp)
    3c01:      	movq	%rsp, %rdi
    3c04:      	movl	$0x32, %eax
    3c09:      	movl	$0x6, %r9d
    3c0f:      	movq	0xf10(%r14), %rcx
    3c16:      	movl	$0x32, %esi
    3c1b:      	movq	%r12, %rdx
    3c1e:      	movl	%ebp, %r8d
    3c21:      	xorl	%eax, %eax
    3c23:      	callq	*%r9
    3c26:      	movq	(%rip), %rax            # 0x3c2d <perf_unwind_v8+0x3c2d>
    3c2d:      	cmpl	$0x0, (%rax)
    3c30:      	je	0x32fe <perf_unwind_v8+0x32fe>
    3c36:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    3c40:      	movq	%rax, 0x27(%rsp)
    3c45:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    3c4f:      	movq	%rax, 0x20(%rsp)
    3c54:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    3c5e:      	movq	%rax, 0x18(%rsp)
    3c63:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    3c6d:      	movq	%rax, 0x10(%rsp)
    3c72:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    3c7c:      	movq	%rax, 0x8(%rsp)
    3c81:      	movq	%r13, (%rsp)
    3c85:      	movq	%rsp, %rdi
    3c88:      	movl	$0x2f, %eax
    3c8d:      	movl	$0x6, %r8d
    3c93:      	movq	0xf18(%r14), %rcx
    3c9a:      	movq	0xf20(%r14), %rdx
    3ca1:      	movl	$0x2f, %esi
    3ca6:      	xorl	%eax, %eax
    3ca8:      	callq	*%r8
    3cab:      	jmp	0x32fe <perf_unwind_v8+0x32fe>
    3cb0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3cba:      	movq	%rax, 0x26(%rsp)
    3cbf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3cc9:      	movq	%rax, 0x20(%rsp)
    3cce:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3cd8:      	movq	%rax, 0x18(%rsp)
    3cdd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3ce7:      	movq	%rax, 0x10(%rsp)
    3cec:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3cf6:      	movq	%rax, 0x8(%rsp)
    3cfb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3d05:      	movq	%rax, (%rsp)
    3d09:      	movq	%rsp, %rdi
    3d0c:      	movl	$0x2e, %eax
    3d11:      	movl	$0x6, %ecx
    3d16:      	movl	0x70(%rsp), %edx
    3d1a:      	movl	$0x2e, %esi
    3d1f:      	xorl	%eax, %eax
    3d21:      	callq	*%rcx
    3d23:      	jmp	0x3689 <perf_unwind_v8+0x3689>
    3d28:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    3d32:      	movq	%rax, 0x16(%rsp)
    3d37:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    3d41:      	movq	%rax, 0x10(%rsp)
    3d46:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    3d50:      	movq	%rax, 0x8(%rsp)
    3d55:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3d5f:      	movq	%rax, (%rsp)
    3d63:      	movq	%rsp, %rdi
    3d66:      	movl	$0x1e, %eax
    3d6b:      	movl	$0x6, %ecx
    3d70:      	movzwl	0x20(%r12), %edx
    3d76:      	movl	$0x1e, %esi
    3d7b:      	xorl	%eax, %eax
    3d7d:      	callq	*%rcx
    3d7f:      	movl	0x1380(%r14), %eax
    3d86:      	movl	0x20(%r12), %ecx
    3d8b:      	btl	%ecx, %eax
    3d8e:      	jb	0x3385 <perf_unwind_v8+0x3385>
    3d94:      	movl	$0x0, 0x64(%rsp)
    3d9c:      	movq	(%rip), %rdi            # 0x3da3 <perf_unwind_v8+0x3da3>
    3da3:      	leaq	0x64(%rsp), %rsi
    3da8:      	movl	$0x1, %eax
    3dad:      	callq	*%rax
    3daf:      	testq	%rax, %rax
    3db2:      	je	0x3db9 <perf_unwind_v8+0x3db9>
    3db4:      	incq	(%rax)
    3db7:      	jmp	0x3dc9 <perf_unwind_v8+0x3dc9>
    3db9:      	movq	(%rip), %rax            # 0x3dc0 <perf_unwind_v8+0x3dc0>
    3dc0:      	cmpl	$0x0, (%rax)
    3dc3:      	jne	0x48b6 <perf_unwind_v8+0x48b6>
    3dc9:      	movzwl	0x20(%r12), %ebp
    3dcf:      	xorl	%r12d, %r12d
    3dd2:      	cmpl	$0x7, %ebp
    3dd5:      	jne	0x2070 <perf_unwind_v8+0x2070>
    3ddb:      	movq	0xed0(%r14), %r13
    3de2:      	movq	0xed8(%r14), %r12
    3de9:      	movq	0xee0(%r14), %rbp
    3df0:      	movq	(%rip), %rax            # 0x3df7 <perf_unwind_v8+0x3df7>
    3df7:      	cmpl	$0x0, (%rax)
    3dfa:      	jne	0x4579 <perf_unwind_v8+0x4579>
    3e00:      	cmpq	%r12, %rbp
    3e03:      	jb	0x2025 <perf_unwind_v8+0x2025>
    3e09:      	leaq	0x2000(%r12), %rax
    3e11:      	cmpq	%rax, %rbp
    3e14:      	jae	0x2025 <perf_unwind_v8+0x2025>
    3e1a:      	addq	$-0x40, %rbp
    3e1e:      	movl	$0x40, %eax
    3e23:      	movl	$0x70, %ecx
    3e28:      	movq	0x98(%rsp), %rdi
    3e30:      	movl	$0x40, %esi
    3e35:      	movq	%rbp, %rdx
    3e38:      	callq	*%rcx
    3e3a:      	testq	%rax, %rax
    3e3d:      	movq	(%rip), %rbp            # 0x3e44 <perf_unwind_v8+0x3e44>
    3e44:      	jne	0x138 <perf_unwind_v8+0x138>
    3e4a:      	movq	0x48(%rsp), %rax
    3e4f:      	movzbl	0x14(%rax), %ecx
    3e53:      	xorl	%ebp, %ebp
    3e55:      	cmpq	$0x38, %rcx
    3e59:      	ja	0x220 <perf_unwind_v8+0x220>
    3e5f:      	movq	0x48(%rsp), %rax
    3e64:      	movzbl	0x15(%rax), %eax
    3e68:      	cmpq	$0x38, %rax
    3e6c:      	ja	0x220 <perf_unwind_v8+0x220>
    3e72:      	movq	0x48(%rsp), %rdx
    3e77:      	movzbl	0x16(%rdx), %edx
    3e7b:      	cmpq	$0x38, %rdx
    3e7f:      	ja	0x220 <perf_unwind_v8+0x220>
    3e85:      	movq	0x98(%rsp), %rsi
    3e8d:      	movq	(%rsi,%rcx), %rbp
    3e91:      	testb	$0x1, %bpl
    3e95:      	jne	0x3fb3 <perf_unwind_v8+0x3fb3>
    3e9b:      	shrq	%rbp
    3e9e:      	movq	(%rip), %rax            # 0x3ea5 <perf_unwind_v8+0x3ea5>
    3ea5:      	cmpl	$0x0, (%rax)
    3ea8:      	jne	0x492e <perf_unwind_v8+0x492e>
    3eae:      	xorl	%r15d, %r15d
    3eb1:      	movzbl	0xf30(%r14), %r12d
    3eb9:      	movl	0x2c0(%r14), %eax
    3ec0:      	cmpq	$0x7e, %rax
    3ec4:      	ja	0x27d <perf_unwind_v8+0x27d>
    3eca:      	leal	0x1(%rax), %ecx
    3ecd:      	movl	%ecx, 0x2c0(%r14)
    3ed4:      	leaq	(%rax,%rax,2), %rax
    3ed8:      	movq	%r15, 0x2d0(%r14,%rax,8)
    3ee0:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    3ee8:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    3ef1:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    3ef9:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    3f05:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    3f10:      	movq	0xee0(%r14), %rax
    3f17:      	movq	%rsp, %rdi
    3f1a:      	movl	$0x10, %ecx
    3f1f:      	movl	$0x70, %r8d
    3f25:      	movq	0xee0(%r14), %rdx
    3f2c:      	movl	$0x10, %esi
    3f31:      	callq	*%r8
    3f34:      	testq	%rax, %rax
    3f37:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    3f3d:      	movq	0xee0(%r14), %rax
    3f44:      	addq	$0x10, %rax
    3f48:      	movq	%rax, 0xed8(%r14)
    3f4f:      	movq	(%rsp), %rax
    3f53:      	movq	%rax, 0xee0(%r14)
    3f5a:      	movq	0x8(%rsp), %rax
    3f5f:      	movq	%rax, 0xed0(%r14)
    3f66:      	movb	$0x1, 0xf30(%r14)
    3f6e:      	movq	(%rip), %rax            # 0x3f75 <perf_unwind_v8+0x3f75>
    3f75:      	cmpl	$0x0, (%rax)
    3f78:      	jne	0x498a <perf_unwind_v8+0x498a>
    3f7e:      	movl	$0x38, 0x70(%rsp)
    3f86:      	movq	(%rip), %rdi            # 0x3f8d <perf_unwind_v8+0x3f8d>
    3f8d:      	leaq	0x70(%rsp), %rsi
    3f92:      	movl	$0x1, %eax
    3f97:      	callq	*%rax
    3f99:      	testq	%rax, %rax
    3f9c:      	je	0x4166 <perf_unwind_v8+0x4166>
    3fa2:      	incq	(%rax)
    3fa5:      	movq	(%rip), %rax            # 0x3fac <perf_unwind_v8+0x3fac>
    3fac:      	movl	(%rax), %eax
    3fae:      	jmp	0x4178 <perf_unwind_v8+0x4178>
    3fb3:      	movq	0x98(%rsp), %rcx
    3fbb:      	movq	(%rcx,%rdx), %r15
    3fbf:      	movq	(%rcx,%rax), %r12
    3fc3:      	movl	%r12d, %ecx
    3fc6:      	andl	$0x3, %ecx
    3fc9:      	andq	$-0x4, %r12
    3fcd:      	xorl	%eax, %eax
    3fcf:      	cmpl	$0x1, %ecx
    3fd2:      	cmovneq	%rax, %r12
    3fd6:      	testq	%r12, %r12
    3fd9:      	je	0x404a <perf_unwind_v8+0x404a>
    3fdb:      	movq	0x48(%rsp), %rax
    3fe0:      	movzbl	0xc(%rax), %edx
    3fe4:      	addq	%r12, %rdx
    3fe7:      	movq	%rsp, %rdi
    3fea:      	movl	$0x8, %eax
    3fef:      	movl	$0x70, %ecx
    3ff4:      	movl	$0x8, %esi
    3ff9:      	callq	*%rcx
    3ffb:      	testq	%rax, %rax
    3ffe:      	jne	0x4048 <perf_unwind_v8+0x4048>
    4000:      	movq	(%rsp), %rax
    4004:      	movl	%eax, %ecx
    4006:      	andl	$0x3, %ecx
    4009:      	cmpl	$0x1, %ecx
    400c:      	jne	0x4048 <perf_unwind_v8+0x4048>
    400e:      	andq	$-0x4, %rax
    4012:      	je	0x4048 <perf_unwind_v8+0x4048>
    4014:      	movq	0x48(%rsp), %rsi
    4019:      	movzbl	0xd(%rsi), %ecx
    401d:      	addq	%rax, %rcx
    4020:      	movq	%rsp, %rdi
    4023:      	movl	$0x2, %edx
    4028:      	movl	$0x70, %r8d
    402e:      	movzbl	0xd(%rsi), %edx
    4032:      	addq	%rax, %rdx
    4035:      	movl	$0x2, %esi
    403a:      	callq	*%r8
    403d:      	testq	%rax, %rax
    4040:      	jne	0x4048 <perf_unwind_v8+0x4048>
    4042:      	movzwl	(%rsp), %eax
    4046:      	jmp	0x404a <perf_unwind_v8+0x404a>
    4048:      	xorl	%eax, %eax
    404a:      	movq	0x48(%rsp), %rcx
    404f:      	cmpw	0x4(%rcx), %ax
    4053:      	jb	0x1c5f <perf_unwind_v8+0x1c5f>
    4059:      	movq	0x48(%rsp), %r8
    405e:      	cmpw	0x6(%r8), %ax
    4063:      	ja	0x494 <perf_unwind_v8+0x494>
    4069:      	movzbl	0xf(%r8), %edx
    406e:      	addq	%r12, %rdx
    4071:      	movq	%rsp, %rdi
    4074:      	movl	$0x8, %eax
    4079:      	movl	$0x70, %ecx
    407e:      	movl	$0x8, %esi
    4083:      	callq	*%rcx
    4085:      	testq	%rax, %rax
    4088:      	jne	0x4119 <perf_unwind_v8+0x4119>
    408e:      	movq	(%rsp), %rcx
    4092:      	movq	%rcx, %rax
    4095:      	movq	%rcx, 0x50(%rsp)
    409a:      	andl	$0x3, %eax
    409d:      	cmpl	$0x1, %eax
    40a0:      	jne	0x4119 <perf_unwind_v8+0x4119>
    40a2:      	andq	$-0x4, 0x50(%rsp)
    40a8:      	je	0x4119 <perf_unwind_v8+0x4119>
    40aa:      	movq	0x48(%rsp), %rax
    40af:      	movzbl	0xc(%rax), %edx
    40b3:      	addq	0x50(%rsp), %rdx
    40b8:      	movq	%rsp, %rdi
    40bb:      	movl	$0x8, %eax
    40c0:      	movl	$0x70, %ecx
    40c5:      	movl	$0x8, %esi
    40ca:      	callq	*%rcx
    40cc:      	testq	%rax, %rax
    40cf:      	jne	0x4120 <perf_unwind_v8+0x4120>
    40d1:      	movq	(%rsp), %rax
    40d5:      	movl	%eax, %ecx
    40d7:      	andl	$0x3, %ecx
    40da:      	cmpl	$0x1, %ecx
    40dd:      	jne	0x4120 <perf_unwind_v8+0x4120>
    40df:      	andq	$-0x4, %rax
    40e3:      	je	0x4120 <perf_unwind_v8+0x4120>
    40e5:      	movq	0x48(%rsp), %rsi
    40ea:      	movzbl	0xd(%rsi), %ecx
    40ee:      	addq	%rax, %rcx
    40f1:      	movq	%rsp, %rdi
    40f4:      	movl	$0x2, %edx
    40f9:      	movl	$0x70, %r8d
    40ff:      	movzbl	0xd(%rsi), %edx
    4103:      	addq	%rax, %rdx
    4106:      	movl	$0x2, %esi
    410b:      	callq	*%r8
    410e:      	testq	%rax, %rax
    4111:      	jne	0x4120 <perf_unwind_v8+0x4120>
    4113:      	movzwl	(%rsp), %eax
    4117:      	jmp	0x4122 <perf_unwind_v8+0x4122>
    4119:      	xorl	%eax, %eax
    411b:      	movq	%rax, 0x50(%rsp)
    4120:      	xorl	%eax, %eax
    4122:      	movq	0x48(%rsp), %rcx
    4127:      	cmpw	0xa(%rcx), %ax
    412b:      	jne	0x998 <perf_unwind_v8+0x998>
    4131:      	movq	%r15, %rbp
    4134:      	shrq	$0x20, %rbp
    4138:      	je	0x4469 <perf_unwind_v8+0x4469>
    413e:      	andl	$0x1, %r15d
    4142:      	jne	0x4469 <perf_unwind_v8+0x4469>
    4148:      	movq	(%rip), %rax            # 0x414f <perf_unwind_v8+0x414f>
    414f:      	cmpl	$0x0, (%rax)
    4152:      	jne	0x49f7 <perf_unwind_v8+0x49f7>
    4158:      	movq	0x50(%rsp), %r15
    415d:      	orq	$0x1, %r15
    4161:      	jmp	0x5310 <perf_unwind_v8+0x5310>
    4166:      	xorl	%eax, %eax
    4168:      	movq	(%rip), %rcx            # 0x416f <perf_unwind_v8+0x416f>
    416f:      	cmpl	$0x0, (%rcx)
    4172:      	jne	0x4a49 <perf_unwind_v8+0x4a49>
    4178:      	movq	0xed0(%r14), %r12
    417f:      	testq	%r12, %r12
    4182:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    4188:      	testl	%eax, %eax
    418a:      	jne	0x4ac1 <perf_unwind_v8+0x4ac1>
    4190:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    419a:      	cmpq	%rax, %r12
    419d:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    41a3:      	cmpq	$0x1000, %r12           # imm = 0x1000
    41aa:      	jb	0x285e <perf_unwind_v8+0x285e>
    41b0:      	movl	(%r14), %eax
    41b3:      	movl	$0x60, 0x70(%rsp)
    41bb:      	movbel	%eax, 0x74(%rsp)
    41c1:      	movbeq	%r12, 0x78(%rsp)
    41c8:      	movq	(%rip), %rdi            # 0x41cf <perf_unwind_v8+0x41cf>
    41cf:      	leaq	0x70(%rsp), %rsi
    41d4:      	movl	$0x1, %eax
    41d9:      	callq	*%rax
    41db:      	testq	%rax, %rax
    41de:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    41e4:      	movq	0x8(%rax), %rbp
    41e8:      	movq	%rbp, %rcx
    41eb:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    41f5:      	andq	%rdx, %rcx
    41f8:      	movq	%rcx, 0xf20(%r14)
    41ff:      	movq	(%rax), %rax
    4202:      	movq	%rax, 0xf10(%r14)
    4209:      	shrq	$0x38, %rbp
    420d:      	movq	%r12, %rax
    4210:      	subq	%rcx, %rax
    4213:      	movq	%rax, 0xf18(%r14)
    421a:      	movq	(%rip), %rax            # 0x4221 <perf_unwind_v8+0x4221>
    4221:      	cmpl	$0x0, (%rax)
    4224:      	je	0x4330 <perf_unwind_v8+0x4330>
    422a:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    4234:      	movq	%rax, 0x28(%rsp)
    4239:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    4243:      	movq	%rax, 0x20(%rsp)
    4248:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    4252:      	movq	%rax, 0x18(%rsp)
    4257:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    4261:      	movq	%rax, 0x10(%rsp)
    4266:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    4270:      	movq	%rax, 0x8(%rsp)
    4275:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    427f:      	movq	%r13, (%rsp)
    4283:      	movw	$0xa, 0x30(%rsp)
    428a:      	movq	%rsp, %rdi
    428d:      	movl	$0x32, %eax
    4292:      	movl	$0x6, %r9d
    4298:      	movq	0xf10(%r14), %rcx
    429f:      	movl	$0x32, %esi
    42a4:      	movq	%r12, %rdx
    42a7:      	movl	%ebp, %r8d
    42aa:      	xorl	%eax, %eax
    42ac:      	callq	*%r9
    42af:      	movq	(%rip), %rax            # 0x42b6 <perf_unwind_v8+0x42b6>
    42b6:      	cmpl	$0x0, (%rax)
    42b9:      	je	0x4330 <perf_unwind_v8+0x4330>
    42bb:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    42c5:      	movq	%rax, 0x27(%rsp)
    42ca:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    42d4:      	movq	%rax, 0x20(%rsp)
    42d9:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    42e3:      	movq	%rax, 0x18(%rsp)
    42e8:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    42f2:      	movq	%rax, 0x10(%rsp)
    42f7:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    4301:      	movq	%rax, 0x8(%rsp)
    4306:      	movq	%r13, (%rsp)
    430a:      	movq	%rsp, %rdi
    430d:      	movl	$0x2f, %eax
    4312:      	movl	$0x6, %r8d
    4318:      	movq	0xf18(%r14), %rcx
    431f:      	movq	0xf20(%r14), %rdx
    4326:      	movl	$0x2f, %esi
    432b:      	xorl	%eax, %eax
    432d:      	callq	*%r8
    4330:      	cmpl	$0x1, %ebp
    4333:      	jne	0x4ced <perf_unwind_v8+0x4ced>
    4339:      	movq	0xf10(%r14), %rax
    4340:      	movq	%rax, 0x70(%rsp)
    4345:      	movq	0xf18(%r14), %r13
    434c:      	movq	(%rip), %rdi            # 0x4353 <perf_unwind_v8+0x4353>
    4353:      	leaq	0x70(%rsp), %rsi
    4358:      	movl	$0x1, %eax
    435d:      	callq	*%rax
    435f:      	movl	$0x1, %ebp
    4364:      	testq	%rax, %rax
    4367:      	je	0x4ced <perf_unwind_v8+0x4ced>
    436d:      	movq	%rax, %r12
    4370:      	cmpq	%r13, (%rax)
    4373:      	ja	0x437c <perf_unwind_v8+0x437c>
    4375:      	cmpq	%r13, 0x8(%r12)
    437a:      	jae	0x4392 <perf_unwind_v8+0x4392>
    437c:      	cmpq	%r13, 0x10(%r12)
    4381:      	ja	0x4ced <perf_unwind_v8+0x4ced>
    4387:      	cmpq	%r13, 0x18(%r12)
    438c:      	jb	0x4ced <perf_unwind_v8+0x4ced>
    4392:      	movq	(%rip), %rax            # 0x4399 <perf_unwind_v8+0x4399>
    4399:      	cmpl	$0x0, (%rax)
    439c:      	je	0x43f5 <perf_unwind_v8+0x43f5>
    439e:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    43a8:      	movq	%rax, 0x16(%rsp)
    43ad:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    43b7:      	movq	%rax, 0x10(%rsp)
    43bc:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    43c6:      	movq	%rax, 0x8(%rsp)
    43cb:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    43d5:      	movq	%rax, (%rsp)
    43d9:      	movq	%rsp, %rdi
    43dc:      	movl	$0x1e, %eax
    43e1:      	movl	$0x6, %ecx
    43e6:      	movzwl	0x20(%r12), %edx
    43ec:      	movl	$0x1e, %esi
    43f1:      	xorl	%eax, %eax
    43f3:      	callq	*%rcx
    43f5:      	movl	0x1380(%r14), %eax
    43fc:      	movl	0x20(%r12), %ecx
    4401:      	btl	%ecx, %eax
    4404:      	jae	0x4b5b <perf_unwind_v8+0x4b5b>
    440a:      	movq	(%rip), %rax            # 0x4411 <perf_unwind_v8+0x4411>
    4411:      	cmpl	$0x0, (%rax)
    4414:      	je	0x4ced <perf_unwind_v8+0x4ced>
    441a:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    4424:      	movq	%rax, 0x10(%rsp)
    4429:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    4433:      	movq	%rax, 0x8(%rsp)
    4438:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    4442:      	movq	%rax, (%rsp)
    4446:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    444e:      	movq	%rsp, %rdi
    4451:      	movl	$0x1b, %eax
    4456:      	movl	$0x6, %ecx
    445b:      	movl	$0x1b, %esi
    4460:      	xorl	%eax, %eax
    4462:      	callq	*%rcx
    4464:      	jmp	0x4ced <perf_unwind_v8+0x4ced>
    4469:      	movq	0x48(%rsp), %rax
    446e:      	movzbl	0xe(%rax), %edx
    4472:      	addq	%r12, %rdx
    4475:      	movq	%rsp, %rdi
    4478:      	movl	$0x8, %eax
    447d:      	movl	$0x70, %ecx
    4482:      	movl	$0x8, %esi
    4487:      	callq	*%rcx
    4489:      	testq	%rax, %rax
    448c:      	je	0x469a <perf_unwind_v8+0x469a>
    4492:      	xorl	%eax, %eax
    4494:      	movq	%rax, 0x58(%rsp)
    4499:      	xorl	%eax, %eax
    449b:      	movq	0x50(%rsp), %r15
    44a0:      	orq	$0x2, %r15
    44a4:      	movq	0x48(%rsp), %rcx
    44a9:      	cmpw	0x8(%rcx), %ax
    44ad:      	jne	0x45e3 <perf_unwind_v8+0x45e3>
    44b3:      	movl	$0x60, %eax
    44b8:      	movl	$0x70, %ecx
    44bd:      	movq	0xb0(%rsp), %rdi
    44c5:      	movq	0x58(%rsp), %rdx
    44ca:      	movl	$0x60, %esi
    44cf:      	callq	*%rcx
    44d1:      	testq	%rax, %rax
    44d4:      	je	0x4b87 <perf_unwind_v8+0x4b87>
    44da:      	movl	$0x3b, 0x70(%rsp)
    44e2:      	movq	(%rip), %rdi            # 0x44e9 <perf_unwind_v8+0x44e9>
    44e9:      	leaq	0x70(%rsp), %rsi
    44ee:      	movl	$0x1, %eax
    44f3:      	callq	*%rax
    44f5:      	testq	%rax, %rax
    44f8:      	jne	0x4690 <perf_unwind_v8+0x4690>
    44fe:      	movq	(%rip), %rax            # 0x4505 <perf_unwind_v8+0x4505>
    4505:      	cmpl	$0x0, (%rax)
    4508:      	je	0x4c61 <perf_unwind_v8+0x4c61>
    450e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4518:      	movq	%rax, 0x26(%rsp)
    451d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4527:      	movq	%rax, 0x20(%rsp)
    452c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4536:      	movq	%rax, 0x18(%rsp)
    453b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4545:      	movq	%rax, 0x10(%rsp)
    454a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4554:      	movq	%rax, 0x8(%rsp)
    4559:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4563:      	movq	%rax, (%rsp)
    4567:      	movq	%rsp, %rdi
    456a:      	movl	$0x2e, %eax
    456f:      	movl	$0x6, %ecx
    4574:      	jmp	0x4c54 <perf_unwind_v8+0x4c54>
    4579:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    4583:      	movq	%rax, 0x17(%rsp)
    4588:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    4592:      	movq	%rax, 0x10(%rsp)
    4597:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    45a1:      	movq	%rax, 0x8(%rsp)
    45a6:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    45b0:      	movq	%rax, (%rsp)
    45b4:      	movq	%rsp, %rdi
    45b7:      	movl	$0x1f, %eax
    45bc:      	movl	$0x6, %r9d
    45c2:      	movl	$0x1f, %esi
    45c7:      	movq	%r13, %rdx
    45ca:      	movq	%r12, %rcx
    45cd:      	movq	%rbp, %r8
    45d0:      	xorl	%eax, %eax
    45d2:      	callq	*%r9
    45d5:      	cmpq	%r12, %rbp
    45d8:      	jae	0x3e09 <perf_unwind_v8+0x3e09>
    45de:      	jmp	0x2025 <perf_unwind_v8+0x2025>
    45e3:      	movq	(%rip), %rcx            # 0x45ea <perf_unwind_v8+0x45ea>
    45ea:      	cmpl	$0x0, (%rcx)
    45ed:      	je	0x466c <perf_unwind_v8+0x466c>
    45ef:      	movzwl	%ax, %r8d
    45f3:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    45fd:      	movq	%rax, 0x26(%rsp)
    4602:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    460c:      	movq	%rax, 0x20(%rsp)
    4611:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    461b:      	movq	%rax, 0x18(%rsp)
    4620:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    462a:      	movq	%rax, 0x10(%rsp)
    462f:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    4639:      	movq	%rax, 0x8(%rsp)
    463e:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    4648:      	movq	%rax, (%rsp)
    464c:      	movq	%rsp, %rdi
    464f:      	movl	$0x2e, %eax
    4654:      	movl	$0x6, %r9d
    465a:      	movl	$0x2e, %esi
    465f:      	movq	%r12, %rdx
    4662:      	movq	0x58(%rsp), %rcx
    4667:      	xorl	%eax, %eax
    4669:      	callq	*%r9
    466c:      	movl	$0x3b, 0x70(%rsp)
    4674:      	movq	(%rip), %rdi            # 0x467b <perf_unwind_v8+0x467b>
    467b:      	leaq	0x70(%rsp), %rsi
    4680:      	movl	$0x1, %eax
    4685:      	callq	*%rax
    4687:      	testq	%rax, %rax
    468a:      	je	0x4be2 <perf_unwind_v8+0x4be2>
    4690:      	incq	(%rax)
    4693:      	xorl	%ebp, %ebp
    4695:      	jmp	0x5310 <perf_unwind_v8+0x5310>
    469a:      	movq	(%rsp), %rcx
    469e:      	movq	%rcx, %rax
    46a1:      	movq	%rcx, 0x58(%rsp)
    46a6:      	andl	$0x3, %eax
    46a9:      	cmpl	$0x1, %eax
    46ac:      	jne	0x4492 <perf_unwind_v8+0x4492>
    46b2:      	andq	$-0x4, 0x58(%rsp)
    46b8:      	je	0x4492 <perf_unwind_v8+0x4492>
    46be:      	movq	0x48(%rsp), %rax
    46c3:      	movzbl	0xc(%rax), %edx
    46c7:      	addq	0x58(%rsp), %rdx
    46cc:      	movq	%rsp, %rdi
    46cf:      	movl	$0x8, %eax
    46d4:      	movl	$0x70, %ecx
    46d9:      	movl	$0x8, %esi
    46de:      	callq	*%rcx
    46e0:      	testq	%rax, %rax
    46e3:      	jne	0x4499 <perf_unwind_v8+0x4499>
    46e9:      	movq	(%rsp), %rax
    46ed:      	movl	%eax, %ecx
    46ef:      	andl	$0x3, %ecx
    46f2:      	cmpl	$0x1, %ecx
    46f5:      	jne	0x4499 <perf_unwind_v8+0x4499>
    46fb:      	andq	$-0x4, %rax
    46ff:      	je	0x4499 <perf_unwind_v8+0x4499>
    4705:      	movq	0x48(%rsp), %rsi
    470a:      	movzbl	0xd(%rsi), %ecx
    470e:      	addq	%rax, %rcx
    4711:      	movq	%rsp, %rdi
    4714:      	movl	$0x2, %edx
    4719:      	movl	$0x70, %r8d
    471f:      	movzbl	0xd(%rsi), %edx
    4723:      	addq	%rax, %rdx
    4726:      	movl	$0x2, %esi
    472b:      	callq	*%r8
    472e:      	testq	%rax, %rax
    4731:      	jne	0x4499 <perf_unwind_v8+0x4499>
    4737:      	movzwl	(%rsp), %eax
    473b:      	jmp	0x449b <perf_unwind_v8+0x449b>
    4740:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    474a:      	movq	%rax, 0x20(%rsp)
    474f:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    4759:      	movq	%rax, 0x18(%rsp)
    475e:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    4768:      	movq	%rax, 0x10(%rsp)
    476d:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    4777:      	movq	%rax, 0x8(%rsp)
    477c:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    4786:      	movq	%rax, (%rsp)
    478a:      	movb	$0x0, 0x28(%rsp)
    478f:      	movq	%rsp, %rdi
    4792:      	movl	$0x29, %eax
    4797:      	movl	$0x6, %r9d
    479d:      	movl	$0x29, %esi
    47a2:      	movq	%r12, %rdx
    47a5:      	movq	0x50(%rsp), %rcx
    47aa:      	movq	0x58(%rsp), %r8
    47af:      	xorl	%eax, %eax
    47b1:      	callq	*%r9
    47b4:      	movq	(%rip), %rax            # 0x47bb <perf_unwind_v8+0x47bb>
    47bb:      	cmpl	$0x0, (%rax)
    47be:      	je	0x3881 <perf_unwind_v8+0x3881>
    47c4:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    47ce:      	movq	%rax, 0x1d(%rsp)
    47d3:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    47dd:      	movq	%rax, 0x18(%rsp)
    47e2:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    47ec:      	movq	%rax, 0x10(%rsp)
    47f1:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    47fb:      	movq	%rax, 0x8(%rsp)
    4800:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    480a:      	movq	%rax, (%rsp)
    480e:      	movq	%rsp, %rdi
    4811:      	movl	$0x25, %eax
    4816:      	movl	$0x6, %r9d
    481c:      	movl	$0x25, %esi
    4821:      	movq	0x68(%rsp), %rdx
    4826:      	movq	0x90(%rsp), %rcx
    482e:      	movq	0xa0(%rsp), %r8
    4836:      	xorl	%eax, %eax
    4838:      	callq	*%r9
    483b:      	jmp	0x3881 <perf_unwind_v8+0x3881>
    4840:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    484a:      	movq	%rax, 0x28(%rsp)
    484f:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    4859:      	movq	%rax, 0x20(%rsp)
    485e:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    4868:      	movq	%rax, 0x18(%rsp)
    486d:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    4877:      	movq	%rax, 0x10(%rsp)
    487c:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    4886:      	movq	%rax, 0x8(%rsp)
    488b:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    4895:      	movq	%rax, (%rsp)
    4899:      	movq	%rsp, %rdi
    489c:      	movl	$0x30, %eax
    48a1:      	movl	$0x6, %ecx
    48a6:      	xorl	%ebp, %ebp
    48a8:      	movl	$0x30, %esi
    48ad:      	xorl	%eax, %eax
    48af:      	callq	*%rcx
    48b1:      	jmp	0x368b <perf_unwind_v8+0x368b>
    48b6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    48c0:      	movq	%rax, 0x26(%rsp)
    48c5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    48cf:      	movq	%rax, 0x20(%rsp)
    48d4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    48de:      	movq	%rax, 0x18(%rsp)
    48e3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    48ed:      	movq	%rax, 0x10(%rsp)
    48f2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    48fc:      	movq	%rax, 0x8(%rsp)
    4901:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    490b:      	movq	%rax, (%rsp)
    490f:      	movq	%rsp, %rdi
    4912:      	movl	$0x2e, %eax
    4917:      	movl	$0x6, %ecx
    491c:      	movl	0x64(%rsp), %edx
    4920:      	movl	$0x2e, %esi
    4925:      	xorl	%eax, %eax
    4927:      	callq	*%rcx
    4929:      	jmp	0x3dc9 <perf_unwind_v8+0x3dc9>
    492e:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    4938:      	movq	%rax, 0x15(%rsp)
    493d:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    4947:      	movq	%rax, 0x10(%rsp)
    494c:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    4956:      	movq	%rax, 0x8(%rsp)
    495b:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    4965:      	movq	%rax, (%rsp)
    4969:      	movq	%rsp, %rdi
    496c:      	movl	$0x1d, %eax
    4971:      	movl	$0x6, %ecx
    4976:      	xorl	%r15d, %r15d
    4979:      	movl	$0x1d, %esi
    497e:      	movq	%rbp, %rdx
    4981:      	xorl	%eax, %eax
    4983:      	callq	*%rcx
    4985:      	jmp	0x5310 <perf_unwind_v8+0x5310>
    498a:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    4994:      	movq	%rax, 0x17(%rsp)
    4999:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    49a3:      	movq	%rax, 0x10(%rsp)
    49a8:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    49b2:      	movq	%rax, 0x8(%rsp)
    49b7:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    49c1:      	movq	%rax, (%rsp)
    49c5:      	movq	%rsp, %rdi
    49c8:      	movl	$0x1f, %eax
    49cd:      	movl	$0x6, %r9d
    49d3:      	movq	0xed0(%r14), %rdx
    49da:      	movq	0xed8(%r14), %rcx
    49e1:      	movq	0xee0(%r14), %r8
    49e8:      	movl	$0x1f, %esi
    49ed:      	xorl	%eax, %eax
    49ef:      	callq	*%r9
    49f2:      	jmp	0x3f7e <perf_unwind_v8+0x3f7e>
    49f7:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    4a01:      	movq	%rax, 0x10(%rsp)
    4a06:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    4a10:      	movq	%rax, 0x8(%rsp)
    4a15:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    4a1f:      	movq	%rax, (%rsp)
    4a23:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    4a2b:      	movq	%rsp, %rdi
    4a2e:      	movl	$0x1c, %eax
    4a33:      	movl	$0x6, %ecx
    4a38:      	movl	$0x1c, %esi
    4a3d:      	movq	%rbp, %rdx
    4a40:      	xorl	%eax, %eax
    4a42:      	callq	*%rcx
    4a44:      	jmp	0x4158 <perf_unwind_v8+0x4158>
    4a49:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4a53:      	movq	%rax, 0x26(%rsp)
    4a58:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4a62:      	movq	%rax, 0x20(%rsp)
    4a67:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4a71:      	movq	%rax, 0x18(%rsp)
    4a76:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4a80:      	movq	%rax, 0x10(%rsp)
    4a85:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4a8f:      	movq	%rax, 0x8(%rsp)
    4a94:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a9e:      	movq	%rax, (%rsp)
    4aa2:      	movq	%rsp, %rdi
    4aa5:      	movl	$0x2e, %eax
    4aaa:      	movl	$0x6, %ecx
    4aaf:      	movl	0x70(%rsp), %edx
    4ab3:      	movl	$0x2e, %esi
    4ab8:      	xorl	%eax, %eax
    4aba:      	callq	*%rcx
    4abc:      	jmp	0x3fa5 <perf_unwind_v8+0x3fa5>
    4ac1:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    4acb:      	movq	%rax, 0x28(%rsp)
    4ad0:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    4ada:      	movq	%rax, 0x20(%rsp)
    4adf:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    4ae9:      	movq	%rax, 0x18(%rsp)
    4aee:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    4af8:      	movq	%rax, 0x10(%rsp)
    4afd:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    4b07:      	movq	%rax, 0x8(%rsp)
    4b0c:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    4b16:      	movq	%rax, (%rsp)
    4b1a:      	movb	$0x0, 0x30(%rsp)
    4b1f:      	movq	%rsp, %rdi
    4b22:      	movl	$0x31, %eax
    4b27:      	movl	$0x6, %ecx
    4b2c:      	movl	0x2c0(%r14), %edx
    4b33:      	movl	$0x31, %esi
    4b38:      	xorl	%eax, %eax
    4b3a:      	callq	*%rcx
    4b3c:      	movq	0xed0(%r14), %r12
    4b43:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    4b4d:      	cmpq	%rax, %r12
    4b50:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    4b56:      	jmp	0x41a3 <perf_unwind_v8+0x41a3>
    4b5b:      	movl	$0x0, 0x64(%rsp)
    4b63:      	movq	(%rip), %rdi            # 0x4b6a <perf_unwind_v8+0x4b6a>
    4b6a:      	leaq	0x64(%rsp), %rsi
    4b6f:      	movl	$0x1, %eax
    4b74:      	callq	*%rax
    4b76:      	testq	%rax, %rax
    4b79:      	je	0x4c68 <perf_unwind_v8+0x4c68>
    4b7f:      	incq	(%rax)
    4b82:      	jmp	0x4ce7 <perf_unwind_v8+0x4ce7>
    4b87:      	movq	0x48(%rsp), %rax
    4b8c:      	movzbl	0x12(%rax), %ecx
    4b90:      	xorl	%ebp, %ebp
    4b92:      	cmpq	$0x5c, %rcx
    4b96:      	ja	0x220 <perf_unwind_v8+0x220>
    4b9c:      	movq	0x48(%rsp), %rax
    4ba1:      	movzbl	0x13(%rax), %eax
    4ba5:      	cmpq	$0x5c, %rax
    4ba9:      	ja	0x220 <perf_unwind_v8+0x220>
    4baf:      	movq	0x48(%rsp), %rdx
    4bb4:      	cmpb	$0x0, 0x10(%rdx)
    4bb8:      	movzbl	0x11(%rdx), %edx
    4bbc:      	movq	%rdx, 0x68(%rsp)
    4bc1:      	je	0x4e48 <perf_unwind_v8+0x4e48>
    4bc7:      	movq	0xb0(%rsp), %rdx
    4bcf:      	movq	0x68(%rsp), %rsi
    4bd4:      	movq	(%rdx,%rsi), %rsi
    4bd8:      	movq	%rsi, 0x68(%rsp)
    4bdd:      	jmp	0x4e57 <perf_unwind_v8+0x4e57>
    4be2:      	movq	(%rip), %rax            # 0x4be9 <perf_unwind_v8+0x4be9>
    4be9:      	cmpl	$0x0, (%rax)
    4bec:      	je	0x4c61 <perf_unwind_v8+0x4c61>
    4bee:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4bf8:      	movq	%rax, 0x26(%rsp)
    4bfd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4c07:      	movq	%rax, 0x20(%rsp)
    4c0c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4c16:      	movq	%rax, 0x18(%rsp)
    4c1b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4c25:      	movq	%rax, 0x10(%rsp)
    4c2a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4c34:      	movq	%rax, 0x8(%rsp)
    4c39:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4c43:      	movq	%rax, (%rsp)
    4c47:      	movq	%rsp, %rdi
    4c4a:      	movl	$0x2e, %eax
    4c4f:      	movl	$0x6, %ecx
    4c54:      	movl	0x70(%rsp), %edx
    4c58:      	movl	$0x2e, %esi
    4c5d:      	xorl	%eax, %eax
    4c5f:      	callq	*%rcx
    4c61:      	xorl	%ebp, %ebp
    4c63:      	jmp	0x5310 <perf_unwind_v8+0x5310>
    4c68:      	movq	(%rip), %rax            # 0x4c6f <perf_unwind_v8+0x4c6f>
    4c6f:      	cmpl	$0x0, (%rax)
    4c72:      	je	0x4ce7 <perf_unwind_v8+0x4ce7>
    4c74:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4c7e:      	movq	%rax, 0x26(%rsp)
    4c83:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4c8d:      	movq	%rax, 0x20(%rsp)
    4c92:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4c9c:      	movq	%rax, 0x18(%rsp)
    4ca1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4cab:      	movq	%rax, 0x10(%rsp)
    4cb0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4cba:      	movq	%rax, 0x8(%rsp)
    4cbf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4cc9:      	movq	%rax, (%rsp)
    4ccd:      	movq	%rsp, %rdi
    4cd0:      	movl	$0x2e, %eax
    4cd5:      	movl	$0x6, %ecx
    4cda:      	movl	0x64(%rsp), %edx
    4cde:      	movl	$0x2e, %esi
    4ce3:      	xorl	%eax, %eax
    4ce5:      	callq	*%rcx
    4ce7:      	movzwl	0x20(%r12), %ebp
    4ced:      	xorl	%r12d, %r12d
    4cf0:      	cmpl	$0x7, %ebp
    4cf3:      	jne	0x2070 <perf_unwind_v8+0x2070>
    4cf9:      	movq	0xed0(%r14), %rax
    4d00:      	movq	%rax, 0xa0(%rsp)
    4d08:      	movq	0xed8(%r14), %r12
    4d0f:      	movq	0xee0(%r14), %r13
    4d16:      	movq	(%rip), %rax            # 0x4d1d <perf_unwind_v8+0x4d1d>
    4d1d:      	cmpl	$0x0, (%rax)
    4d20:      	je	0x4d83 <perf_unwind_v8+0x4d83>
    4d22:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    4d2c:      	movq	%rax, 0x17(%rsp)
    4d31:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    4d3b:      	movq	%rax, 0x10(%rsp)
    4d40:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    4d4a:      	movq	%rax, 0x8(%rsp)
    4d4f:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    4d59:      	movq	%rax, (%rsp)
    4d5d:      	movq	%rsp, %rdi
    4d60:      	movl	$0x1f, %eax
    4d65:      	movl	$0x6, %r9d
    4d6b:      	movl	$0x1f, %esi
    4d70:      	movq	0xa0(%rsp), %rdx
    4d78:      	movq	%r12, %rcx
    4d7b:      	movq	%r13, %r8
    4d7e:      	xorl	%eax, %eax
    4d80:      	callq	*%r9
    4d83:      	cmpq	%r12, %r13
    4d86:      	jb	0x80b0 <perf_unwind_v8+0x80b0>
    4d8c:      	leaq	0x2000(%r12), %rax
    4d94:      	cmpq	%rax, %r13
    4d97:      	jae	0x80b0 <perf_unwind_v8+0x80b0>
    4d9d:      	addq	$-0x40, %r13
    4da1:      	movl	$0x40, %eax
    4da6:      	movl	$0x70, %ecx
    4dab:      	movq	0x98(%rsp), %rdi
    4db3:      	movl	$0x40, %esi
    4db8:      	movq	%r13, %rdx
    4dbb:      	callq	*%rcx
    4dbd:      	testq	%rax, %rax
    4dc0:      	movq	(%rip), %rbp            # 0x4dc7 <perf_unwind_v8+0x4dc7>
    4dc7:      	jne	0x138 <perf_unwind_v8+0x138>
    4dcd:      	movq	0x48(%rsp), %rax
    4dd2:      	movzbl	0x14(%rax), %ecx
    4dd6:      	xorl	%ebp, %ebp
    4dd8:      	cmpq	$0x38, %rcx
    4ddc:      	ja	0x220 <perf_unwind_v8+0x220>
    4de2:      	movq	0x48(%rsp), %rax
    4de7:      	movzbl	0x15(%rax), %eax
    4deb:      	cmpq	$0x38, %rax
    4def:      	ja	0x220 <perf_unwind_v8+0x220>
    4df5:      	movq	0x48(%rsp), %rdx
    4dfa:      	movzbl	0x16(%rdx), %edx
    4dfe:      	cmpq	$0x38, %rdx
    4e02:      	ja	0x220 <perf_unwind_v8+0x220>
    4e08:      	movq	0x98(%rsp), %rsi
    4e10:      	movq	(%rsi,%rcx), %rbp
    4e14:      	testb	$0x1, %bpl
    4e18:      	jne	0x4ffe <perf_unwind_v8+0x4ffe>
    4e1e:      	shrq	%rbp
    4e21:      	movq	(%rip), %rax            # 0x4e28 <perf_unwind_v8+0x4e28>
    4e28:      	cmpl	$0x0, (%rax)
    4e2b:      	jne	0x5187 <perf_unwind_v8+0x5187>
    4e31:      	xorl	%eax, %eax
    4e33:      	movq	%rax, 0x90(%rsp)
    4e3b:      	movzbl	0xf30(%r14), %r12d
    4e43:      	jmp	0x59c0 <perf_unwind_v8+0x59c0>
    4e48:      	movq	0x68(%rsp), %rdx
    4e4d:      	addq	0x58(%rsp), %rdx
    4e52:      	movq	%rdx, 0x68(%rsp)
    4e57:      	movq	0xb0(%rsp), %rdx
    4e5f:      	movl	(%rdx,%rcx), %esi
    4e62:      	movq	0x48(%rsp), %rcx
    4e67:      	movzbl	0x17(%rcx), %edi
    4e6b:      	movl	%edi, 0xb8(%rsp)
    4e72:      	movzbl	0x18(%rcx), %ecx
    4e76:      	movq	%rsi, 0x90(%rsp)
    4e7e:      	addq	0x68(%rsp), %rsi
    4e83:      	movq	%rsi, 0xa0(%rsp)
    4e8b:      	andl	(%rdx,%rax), %ecx
    4e8e:      	movl	%ecx, 0xac(%rsp)
    4e95:      	movq	(%rip), %rax            # 0x4e9c <perf_unwind_v8+0x4e9c>
    4e9c:      	cmpl	$0x0, (%rax)
    4e9f:      	je	0x4f9c <perf_unwind_v8+0x4f9c>
    4ea5:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    4eaf:      	movq	%rax, 0x20(%rsp)
    4eb4:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    4ebe:      	movq	%rax, 0x18(%rsp)
    4ec3:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    4ecd:      	movq	%rax, 0x10(%rsp)
    4ed2:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    4edc:      	movq	%rax, 0x8(%rsp)
    4ee1:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    4eeb:      	movq	%rax, (%rsp)
    4eef:      	movb	$0x0, 0x28(%rsp)
    4ef4:      	movq	%rsp, %rdi
    4ef7:      	movl	$0x29, %eax
    4efc:      	movl	$0x6, %r9d
    4f02:      	movl	$0x29, %esi
    4f07:      	movq	%r12, %rdx
    4f0a:      	movq	0x50(%rsp), %rcx
    4f0f:      	movq	0x58(%rsp), %r8
    4f14:      	xorl	%eax, %eax
    4f16:      	callq	*%r9
    4f19:      	movq	(%rip), %rax            # 0x4f20 <perf_unwind_v8+0x4f20>
    4f20:      	cmpl	$0x0, (%rax)
    4f23:      	je	0x4f9c <perf_unwind_v8+0x4f9c>
    4f25:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    4f2f:      	movq	%rax, 0x1d(%rsp)
    4f34:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    4f3e:      	movq	%rax, 0x18(%rsp)
    4f43:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    4f4d:      	movq	%rax, 0x10(%rsp)
    4f52:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    4f5c:      	movq	%rax, 0x8(%rsp)
    4f61:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    4f6b:      	movq	%rax, (%rsp)
    4f6f:      	movq	%rsp, %rdi
    4f72:      	movl	$0x25, %eax
    4f77:      	movl	$0x6, %r9d
    4f7d:      	movl	$0x25, %esi
    4f82:      	movq	0x68(%rsp), %rdx
    4f87:      	movq	0xa0(%rsp), %rcx
    4f8f:      	movq	0x90(%rsp), %r8
    4f97:      	xorl	%eax, %eax
    4f99:      	callq	*%r9
    4f9c:      	movq	%r13, %rbp
    4f9f:      	subq	0x68(%rsp), %rbp
    4fa4:      	jb	0x51ea <perf_unwind_v8+0x51ea>
    4faa:      	cmpq	0xa0(%rsp), %r13
    4fb2:      	jae	0x51ea <perf_unwind_v8+0x51ea>
    4fb8:      	movl	0xb8(%rsp), %eax
    4fbf:      	shrxl	%eax, 0xac(%rsp), %eax
    4fc9:      	movq	0x48(%rsp), %rcx
    4fce:      	movzbl	0x19(%rcx), %ecx
    4fd2:      	orq	$0x4, %r12
    4fd6:      	movq	0x58(%rsp), %r15
    4fdb:      	orq	$0x3, %r15
    4fdf:      	cmpl	%ecx, %eax
    4fe1:      	cmoveq	%r12, %r15
    4fe5:      	movq	0x90(%rsp), %rcx
    4fed:      	shll	$0x4, %ecx
    4ff0:      	orl	%eax, %ecx
    4ff2:      	shlq	$0x20, %rcx
    4ff6:      	orq	%rcx, %rbp
    4ff9:      	jmp	0x5310 <perf_unwind_v8+0x5310>
    4ffe:      	movq	0x98(%rsp), %rcx
    5006:      	movq	(%rcx,%rdx), %r12
    500a:      	movq	(%rcx,%rax), %rdx
    500e:      	movl	%edx, %ecx
    5010:      	andl	$0x3, %ecx
    5013:      	andq	$-0x4, %rdx
    5017:      	xorl	%eax, %eax
    5019:      	cmpl	$0x1, %ecx
    501c:      	cmovneq	%rax, %rdx
    5020:      	movq	%rdx, 0x68(%rsp)
    5025:      	testq	%rdx, %rdx
    5028:      	je	0x509b <perf_unwind_v8+0x509b>
    502a:      	movq	0x48(%rsp), %rax
    502f:      	movzbl	0xc(%rax), %edx
    5033:      	addq	0x68(%rsp), %rdx
    5038:      	movq	%rsp, %rdi
    503b:      	movl	$0x8, %eax
    5040:      	movl	$0x70, %ecx
    5045:      	movl	$0x8, %esi
    504a:      	callq	*%rcx
    504c:      	testq	%rax, %rax
    504f:      	jne	0x5099 <perf_unwind_v8+0x5099>
    5051:      	movq	(%rsp), %rax
    5055:      	movl	%eax, %ecx
    5057:      	andl	$0x3, %ecx
    505a:      	cmpl	$0x1, %ecx
    505d:      	jne	0x5099 <perf_unwind_v8+0x5099>
    505f:      	andq	$-0x4, %rax
    5063:      	je	0x5099 <perf_unwind_v8+0x5099>
    5065:      	movq	0x48(%rsp), %rsi
    506a:      	movzbl	0xd(%rsi), %ecx
    506e:      	addq	%rax, %rcx
    5071:      	movq	%rsp, %rdi
    5074:      	movl	$0x2, %edx
    5079:      	movl	$0x70, %r8d
    507f:      	movzbl	0xd(%rsi), %edx
    5083:      	addq	%rax, %rdx
    5086:      	movl	$0x2, %esi
    508b:      	callq	*%r8
    508e:      	testq	%rax, %rax
    5091:      	jne	0x5099 <perf_unwind_v8+0x5099>
    5093:      	movzwl	(%rsp), %eax
    5097:      	jmp	0x509b <perf_unwind_v8+0x509b>
    5099:      	xorl	%eax, %eax
    509b:      	movq	0x48(%rsp), %rcx
    50a0:      	cmpw	0x4(%rcx), %ax
    50a4:      	jb	0x1c5f <perf_unwind_v8+0x1c5f>
    50aa:      	movq	0x48(%rsp), %r8
    50af:      	cmpw	0x6(%r8), %ax
    50b4:      	ja	0x494 <perf_unwind_v8+0x494>
    50ba:      	movzbl	0xf(%r8), %edx
    50bf:      	addq	0x68(%rsp), %rdx
    50c4:      	movq	%rsp, %rdi
    50c7:      	movl	$0x8, %eax
    50cc:      	movl	$0x70, %ecx
    50d1:      	movl	$0x8, %esi
    50d6:      	callq	*%rcx
    50d8:      	testq	%rax, %rax
    50db:      	jne	0x5201 <perf_unwind_v8+0x5201>
    50e1:      	movq	(%rsp), %rcx
    50e5:      	movq	%rcx, %rax
    50e8:      	movq	%rcx, 0x58(%rsp)
    50ed:      	andl	$0x3, %eax
    50f0:      	cmpl	$0x1, %eax
    50f3:      	jne	0x5201 <perf_unwind_v8+0x5201>
    50f9:      	andq	$-0x4, 0x58(%rsp)
    50ff:      	je	0x5201 <perf_unwind_v8+0x5201>
    5105:      	movq	0x48(%rsp), %rax
    510a:      	movzbl	0xc(%rax), %edx
    510e:      	addq	0x58(%rsp), %rdx
    5113:      	movq	%rsp, %rdi
    5116:      	movl	$0x8, %eax
    511b:      	movl	$0x70, %ecx
    5120:      	movl	$0x8, %esi
    5125:      	callq	*%rcx
    5127:      	testq	%rax, %rax
    512a:      	jne	0x5208 <perf_unwind_v8+0x5208>
    5130:      	movq	(%rsp), %rax
    5134:      	movl	%eax, %ecx
    5136:      	andl	$0x3, %ecx
    5139:      	cmpl	$0x1, %ecx
    513c:      	jne	0x5208 <perf_unwind_v8+0x5208>
    5142:      	andq	$-0x4, %rax
    5146:      	je	0x5208 <perf_unwind_v8+0x5208>
    514c:      	movq	0x48(%rsp), %rsi
    5151:      	movzbl	0xd(%rsi), %ecx
    5155:      	addq	%rax, %rcx
    5158:      	movq	%rsp, %rdi
    515b:      	movl	$0x2, %edx
    5160:      	movl	$0x70, %r8d
    5166:      	movzbl	0xd(%rsi), %edx
    516a:      	addq	%rax, %rdx
    516d:      	movl	$0x2, %esi
    5172:      	callq	*%r8
    5175:      	testq	%rax, %rax
    5178:      	jne	0x5208 <perf_unwind_v8+0x5208>
    517e:      	movzwl	(%rsp), %eax
    5182:      	jmp	0x520a <perf_unwind_v8+0x520a>
    5187:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    5191:      	movq	%rax, 0x15(%rsp)
    5196:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    51a0:      	movq	%rax, 0x10(%rsp)
    51a5:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    51af:      	movq	%rax, 0x8(%rsp)
    51b4:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    51be:      	movq	%rax, (%rsp)
    51c2:      	movq	%rsp, %rdi
    51c5:      	movl	$0x1d, %eax
    51ca:      	movl	$0x6, %ecx
    51cf:      	xorl	%eax, %eax
    51d1:      	movq	%rax, 0x90(%rsp)
    51d9:      	movl	$0x1d, %esi
    51de:      	movq	%rbp, %rdx
    51e1:      	xorl	%eax, %eax
    51e3:      	callq	*%rcx
    51e5:      	jmp	0x5915 <perf_unwind_v8+0x5915>
    51ea:      	movq	(%rip), %rax            # 0x51f1 <perf_unwind_v8+0x51f1>
    51f1:      	cmpl	$0x0, (%rax)
    51f4:      	jne	0x529f <perf_unwind_v8+0x529f>
    51fa:      	xorl	%ebp, %ebp
    51fc:      	jmp	0x3eb1 <perf_unwind_v8+0x3eb1>
    5201:      	xorl	%eax, %eax
    5203:      	movq	%rax, 0x58(%rsp)
    5208:      	xorl	%eax, %eax
    520a:      	movq	0x48(%rsp), %rcx
    520f:      	cmpw	0xa(%rcx), %ax
    5213:      	jne	0x998 <perf_unwind_v8+0x998>
    5219:      	movq	%r12, %rbp
    521c:      	shrq	$0x20, %rbp
    5220:      	je	0x53bb <perf_unwind_v8+0x53bb>
    5226:      	andl	$0x1, %r12d
    522a:      	jne	0x53bb <perf_unwind_v8+0x53bb>
    5230:      	movq	(%rip), %rax            # 0x5237 <perf_unwind_v8+0x5237>
    5237:      	cmpl	$0x0, (%rax)
    523a:      	je	0x5289 <perf_unwind_v8+0x5289>
    523c:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    5246:      	movq	%rax, 0x10(%rsp)
    524b:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    5255:      	movq	%rax, 0x8(%rsp)
    525a:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    5264:      	movq	%rax, (%rsp)
    5268:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    5270:      	movq	%rsp, %rdi
    5273:      	movl	$0x1c, %eax
    5278:      	movl	$0x6, %ecx
    527d:      	movl	$0x1c, %esi
    5282:      	movq	%rbp, %rdx
    5285:      	xorl	%eax, %eax
    5287:      	callq	*%rcx
    5289:      	movq	0x58(%rsp), %r15
    528e:      	orq	$0x1, %r15
    5292:      	movq	%r15, 0x90(%rsp)
    529a:      	jmp	0x5915 <perf_unwind_v8+0x5915>
    529f:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    52a9:      	movq	%rax, 0x28(%rsp)
    52ae:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    52b8:      	movq	%rax, 0x20(%rsp)
    52bd:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    52c7:      	movq	%rax, 0x18(%rsp)
    52cc:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    52d6:      	movq	%rax, 0x10(%rsp)
    52db:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    52e5:      	movq	%rax, 0x8(%rsp)
    52ea:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    52f4:      	movq	%rax, (%rsp)
    52f8:      	movq	%rsp, %rdi
    52fb:      	movl	$0x30, %eax
    5300:      	movl	$0x6, %ecx
    5305:      	xorl	%ebp, %ebp
    5307:      	movl	$0x30, %esi
    530c:      	xorl	%eax, %eax
    530e:      	callq	*%rcx
    5310:      	movzbl	0xf30(%r14), %r12d
    5318:      	movq	(%rip), %rax            # 0x531f <perf_unwind_v8+0x531f>
    531f:      	cmpl	$0x0, (%rax)
    5322:      	je	0x3eb9 <perf_unwind_v8+0x3eb9>
    5328:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    5332:      	movq	%rax, 0x30(%rsp)
    5337:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    5341:      	movq	%rax, 0x28(%rsp)
    5346:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    5350:      	movq	%rax, 0x20(%rsp)
    5355:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    535f:      	movq	%rax, 0x18(%rsp)
    5364:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    536e:      	movq	%rax, 0x10(%rsp)
    5373:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    537d:      	movq	%rax, 0x8(%rsp)
    5382:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    538c:      	movq	%rax, (%rsp)
    5390:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    5398:      	movq	%rsp, %rdi
    539b:      	movl	$0x3c, %eax
    53a0:      	movl	$0x6, %r8d
    53a6:      	movl	$0x3c, %esi
    53ab:      	movq	%rbp, %rdx
    53ae:      	movq	%r15, %rcx
    53b1:      	xorl	%eax, %eax
    53b3:      	callq	*%r8
    53b6:      	jmp	0x3eb9 <perf_unwind_v8+0x3eb9>
    53bb:      	movq	0x48(%rsp), %rax
    53c0:      	movzbl	0xe(%rax), %edx
    53c4:      	addq	0x68(%rsp), %rdx
    53c9:      	movq	%rsp, %rdi
    53cc:      	movl	$0x8, %eax
    53d1:      	movl	$0x70, %ecx
    53d6:      	movl	$0x8, %esi
    53db:      	callq	*%rcx
    53dd:      	testq	%rax, %rax
    53e0:      	jne	0x5471 <perf_unwind_v8+0x5471>
    53e6:      	movq	(%rsp), %rcx
    53ea:      	movq	%rcx, %rax
    53ed:      	movq	%rcx, 0x50(%rsp)
    53f2:      	andl	$0x3, %eax
    53f5:      	cmpl	$0x1, %eax
    53f8:      	jne	0x5471 <perf_unwind_v8+0x5471>
    53fa:      	andq	$-0x4, 0x50(%rsp)
    5400:      	je	0x5471 <perf_unwind_v8+0x5471>
    5402:      	movq	0x48(%rsp), %rax
    5407:      	movzbl	0xc(%rax), %edx
    540b:      	addq	0x50(%rsp), %rdx
    5410:      	movq	%rsp, %rdi
    5413:      	movl	$0x8, %eax
    5418:      	movl	$0x70, %ecx
    541d:      	movl	$0x8, %esi
    5422:      	callq	*%rcx
    5424:      	testq	%rax, %rax
    5427:      	jne	0x5478 <perf_unwind_v8+0x5478>
    5429:      	movq	(%rsp), %rax
    542d:      	movl	%eax, %ecx
    542f:      	andl	$0x3, %ecx
    5432:      	cmpl	$0x1, %ecx
    5435:      	jne	0x5478 <perf_unwind_v8+0x5478>
    5437:      	andq	$-0x4, %rax
    543b:      	je	0x5478 <perf_unwind_v8+0x5478>
    543d:      	movq	0x48(%rsp), %rsi
    5442:      	movzbl	0xd(%rsi), %ecx
    5446:      	addq	%rax, %rcx
    5449:      	movq	%rsp, %rdi
    544c:      	movl	$0x2, %edx
    5451:      	movl	$0x70, %r8d
    5457:      	movzbl	0xd(%rsi), %edx
    545b:      	addq	%rax, %rdx
    545e:      	movl	$0x2, %esi
    5463:      	callq	*%r8
    5466:      	testq	%rax, %rax
    5469:      	jne	0x5478 <perf_unwind_v8+0x5478>
    546b:      	movzwl	(%rsp), %eax
    546f:      	jmp	0x547a <perf_unwind_v8+0x547a>
    5471:      	xorl	%eax, %eax
    5473:      	movq	%rax, 0x50(%rsp)
    5478:      	xorl	%eax, %eax
    547a:      	movq	0x58(%rsp), %rcx
    547f:      	orq	$0x2, %rcx
    5483:      	movq	%rcx, 0x90(%rsp)
    548b:      	movq	0x48(%rsp), %rcx
    5490:      	cmpw	0x8(%rcx), %ax
    5494:      	jne	0x5560 <perf_unwind_v8+0x5560>
    549a:      	movl	$0x60, %eax
    549f:      	movl	$0x70, %ecx
    54a4:      	movq	0xb0(%rsp), %rdi
    54ac:      	movq	0x50(%rsp), %rdx
    54b1:      	movl	$0x60, %esi
    54b6:      	callq	*%rcx
    54b8:      	testq	%rax, %rax
    54bb:      	je	0x5615 <perf_unwind_v8+0x5615>
    54c1:      	movl	$0x3b, 0x70(%rsp)
    54c9:      	movq	(%rip), %rdi            # 0x54d0 <perf_unwind_v8+0x54d0>
    54d0:      	leaq	0x70(%rsp), %rsi
    54d5:      	movl	$0x1, %eax
    54da:      	callq	*%rax
    54dc:      	testq	%rax, %rax
    54df:      	jne	0x560b <perf_unwind_v8+0x560b>
    54e5:      	movq	(%rip), %rax            # 0x54ec <perf_unwind_v8+0x54ec>
    54ec:      	cmpl	$0x0, (%rax)
    54ef:      	je	0x56e1 <perf_unwind_v8+0x56e1>
    54f5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    54ff:      	movq	%rax, 0x26(%rsp)
    5504:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    550e:      	movq	%rax, 0x20(%rsp)
    5513:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    551d:      	movq	%rax, 0x18(%rsp)
    5522:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    552c:      	movq	%rax, 0x10(%rsp)
    5531:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    553b:      	movq	%rax, 0x8(%rsp)
    5540:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    554a:      	movq	%rax, (%rsp)
    554e:      	movq	%rsp, %rdi
    5551:      	movl	$0x2e, %eax
    5556:      	movl	$0x6, %ecx
    555b:      	jmp	0x56d4 <perf_unwind_v8+0x56d4>
    5560:      	movq	(%rip), %rcx            # 0x5567 <perf_unwind_v8+0x5567>
    5567:      	cmpl	$0x0, (%rcx)
    556a:      	je	0x55eb <perf_unwind_v8+0x55eb>
    556c:      	movzwl	%ax, %r8d
    5570:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    557a:      	movq	%rax, 0x26(%rsp)
    557f:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    5589:      	movq	%rax, 0x20(%rsp)
    558e:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    5598:      	movq	%rax, 0x18(%rsp)
    559d:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    55a7:      	movq	%rax, 0x10(%rsp)
    55ac:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    55b6:      	movq	%rax, 0x8(%rsp)
    55bb:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    55c5:      	movq	%rax, (%rsp)
    55c9:      	movq	%rsp, %rdi
    55cc:      	movl	$0x2e, %eax
    55d1:      	movl	$0x6, %r9d
    55d7:      	movl	$0x2e, %esi
    55dc:      	movq	0x68(%rsp), %rdx
    55e1:      	movq	0x50(%rsp), %rcx
    55e6:      	xorl	%eax, %eax
    55e8:      	callq	*%r9
    55eb:      	movl	$0x3b, 0x70(%rsp)
    55f3:      	movq	(%rip), %rdi            # 0x55fa <perf_unwind_v8+0x55fa>
    55fa:      	leaq	0x70(%rsp), %rsi
    55ff:      	movl	$0x1, %eax
    5604:      	callq	*%rax
    5606:      	testq	%rax, %rax
    5609:      	je	0x5662 <perf_unwind_v8+0x5662>
    560b:      	incq	(%rax)
    560e:      	xorl	%ebp, %ebp
    5610:      	jmp	0x5915 <perf_unwind_v8+0x5915>
    5615:      	movq	0x48(%rsp), %rax
    561a:      	movzbl	0x12(%rax), %ecx
    561e:      	xorl	%ebp, %ebp
    5620:      	cmpq	$0x5c, %rcx
    5624:      	ja	0x220 <perf_unwind_v8+0x220>
    562a:      	movq	0x48(%rsp), %rax
    562f:      	movzbl	0x13(%rax), %eax
    5633:      	cmpq	$0x5c, %rax
    5637:      	ja	0x220 <perf_unwind_v8+0x220>
    563d:      	movq	0x48(%rsp), %rdx
    5642:      	cmpb	$0x0, 0x10(%rdx)
    5646:      	movzbl	0x11(%rdx), %r12d
    564b:      	je	0x56e8 <perf_unwind_v8+0x56e8>
    5651:      	movq	0xb0(%rsp), %rdx
    5659:      	movq	(%rdx,%r12), %r12
    565d:      	jmp	0x56ed <perf_unwind_v8+0x56ed>
    5662:      	movq	(%rip), %rax            # 0x5669 <perf_unwind_v8+0x5669>
    5669:      	cmpl	$0x0, (%rax)
    566c:      	je	0x56e1 <perf_unwind_v8+0x56e1>
    566e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5678:      	movq	%rax, 0x26(%rsp)
    567d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5687:      	movq	%rax, 0x20(%rsp)
    568c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5696:      	movq	%rax, 0x18(%rsp)
    569b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    56a5:      	movq	%rax, 0x10(%rsp)
    56aa:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    56b4:      	movq	%rax, 0x8(%rsp)
    56b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    56c3:      	movq	%rax, (%rsp)
    56c7:      	movq	%rsp, %rdi
    56ca:      	movl	$0x2e, %eax
    56cf:      	movl	$0x6, %ecx
    56d4:      	movl	0x70(%rsp), %edx
    56d8:      	movl	$0x2e, %esi
    56dd:      	xorl	%eax, %eax
    56df:      	callq	*%rcx
    56e1:      	xorl	%ebp, %ebp
    56e3:      	jmp	0x5915 <perf_unwind_v8+0x5915>
    56e8:      	addq	0x50(%rsp), %r12
    56ed:      	movq	0xb0(%rsp), %rdx
    56f5:      	movl	(%rdx,%rcx), %r13d
    56f9:      	movq	0x48(%rsp), %rcx
    56fe:      	movzbl	0x17(%rcx), %esi
    5702:      	movl	%esi, 0xac(%rsp)
    5709:      	movzbl	0x18(%rcx), %r15d
    570e:      	movq	%r13, %rcx
    5711:      	addq	%r12, %rcx
    5714:      	movq	%rcx, 0xb8(%rsp)
    571c:      	andl	(%rdx,%rax), %r15d
    5720:      	movq	(%rip), %rax            # 0x5727 <perf_unwind_v8+0x5727>
    5727:      	cmpl	$0x0, (%rax)
    572a:      	je	0x5822 <perf_unwind_v8+0x5822>
    5730:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    573a:      	movq	%rax, 0x20(%rsp)
    573f:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    5749:      	movq	%rax, 0x18(%rsp)
    574e:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    5758:      	movq	%rax, 0x10(%rsp)
    575d:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    5767:      	movq	%rax, 0x8(%rsp)
    576c:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    5776:      	movq	%rax, (%rsp)
    577a:      	movb	$0x0, 0x28(%rsp)
    577f:      	movq	%rsp, %rdi
    5782:      	movl	$0x29, %eax
    5787:      	movl	$0x6, %r9d
    578d:      	movl	$0x29, %esi
    5792:      	movq	0x68(%rsp), %rdx
    5797:      	movq	0x58(%rsp), %rcx
    579c:      	movq	0x50(%rsp), %r8
    57a1:      	xorl	%eax, %eax
    57a3:      	callq	*%r9
    57a6:      	movq	(%rip), %rax            # 0x57ad <perf_unwind_v8+0x57ad>
    57ad:      	cmpl	$0x0, (%rax)
    57b0:      	je	0x5822 <perf_unwind_v8+0x5822>
    57b2:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    57bc:      	movq	%rax, 0x1d(%rsp)
    57c1:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    57cb:      	movq	%rax, 0x18(%rsp)
    57d0:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    57da:      	movq	%rax, 0x10(%rsp)
    57df:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    57e9:      	movq	%rax, 0x8(%rsp)
    57ee:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    57f8:      	movq	%rax, (%rsp)
    57fc:      	movq	%rsp, %rdi
    57ff:      	movl	$0x25, %eax
    5804:      	movl	$0x6, %r9d
    580a:      	movl	$0x25, %esi
    580f:      	movq	%r12, %rdx
    5812:      	movq	0xb8(%rsp), %rcx
    581a:      	movl	%r13d, %r8d
    581d:      	xorl	%eax, %eax
    581f:      	callq	*%r9
    5822:      	movq	0xa0(%rsp), %rbp
    582a:      	subq	%r12, %rbp
    582d:      	jb	0x5889 <perf_unwind_v8+0x5889>
    582f:      	movq	0xb8(%rsp), %rax
    5837:      	cmpq	%rax, 0xa0(%rsp)
    583f:      	jae	0x5889 <perf_unwind_v8+0x5889>
    5841:      	movl	0xac(%rsp), %eax
    5848:      	shrxl	%eax, %r15d, %eax
    584d:      	movq	0x48(%rsp), %rcx
    5852:      	movzbl	0x19(%rcx), %ecx
    5856:      	movq	0x68(%rsp), %r15
    585b:      	orq	$0x4, %r15
    585f:      	movq	0x50(%rsp), %rdx
    5864:      	orq	$0x3, %rdx
    5868:      	cmpl	%ecx, %eax
    586a:      	cmoveq	%r15, %rdx
    586e:      	shll	$0x4, %r13d
    5872:      	orl	%eax, %r13d
    5875:      	shlq	$0x20, %r13
    5879:      	orq	%r13, %rbp
    587c:      	movq	%rdx, 0x90(%rsp)
    5884:      	jmp	0x5915 <perf_unwind_v8+0x5915>
    5889:      	movq	(%rip), %rax            # 0x5890 <perf_unwind_v8+0x5890>
    5890:      	cmpl	$0x0, (%rax)
    5893:      	jne	0x58a4 <perf_unwind_v8+0x58a4>
    5895:      	xorl	%ebp, %ebp
    5897:      	movzbl	0xf30(%r14), %r12d
    589f:      	jmp	0x59c0 <perf_unwind_v8+0x59c0>
    58a4:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    58ae:      	movq	%rax, 0x28(%rsp)
    58b3:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    58bd:      	movq	%rax, 0x20(%rsp)
    58c2:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    58cc:      	movq	%rax, 0x18(%rsp)
    58d1:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    58db:      	movq	%rax, 0x10(%rsp)
    58e0:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    58ea:      	movq	%rax, 0x8(%rsp)
    58ef:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    58f9:      	movq	%rax, (%rsp)
    58fd:      	movq	%rsp, %rdi
    5900:      	movl	$0x30, %eax
    5905:      	movl	$0x6, %ecx
    590a:      	xorl	%ebp, %ebp
    590c:      	movl	$0x30, %esi
    5911:      	xorl	%eax, %eax
    5913:      	callq	*%rcx
    5915:      	movzbl	0xf30(%r14), %r12d
    591d:      	movq	(%rip), %rax            # 0x5924 <perf_unwind_v8+0x5924>
    5924:      	cmpl	$0x0, (%rax)
    5927:      	je	0x59c0 <perf_unwind_v8+0x59c0>
    592d:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    5937:      	movq	%rax, 0x30(%rsp)
    593c:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    5946:      	movq	%rax, 0x28(%rsp)
    594b:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    5955:      	movq	%rax, 0x20(%rsp)
    595a:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    5964:      	movq	%rax, 0x18(%rsp)
    5969:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    5973:      	movq	%rax, 0x10(%rsp)
    5978:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    5982:      	movq	%rax, 0x8(%rsp)
    5987:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5991:      	movq	%rax, (%rsp)
    5995:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    599d:      	movq	%rsp, %rdi
    59a0:      	movl	$0x3c, %eax
    59a5:      	movl	$0x6, %r8d
    59ab:      	movl	$0x3c, %esi
    59b0:      	movq	%rbp, %rdx
    59b3:      	movq	0x90(%rsp), %rcx
    59bb:      	xorl	%eax, %eax
    59bd:      	callq	*%r8
    59c0:      	movl	0x2c0(%r14), %eax
    59c7:      	cmpq	$0x7e, %rax
    59cb:      	ja	0x27d <perf_unwind_v8+0x27d>
    59d1:      	leal	0x1(%rax), %ecx
    59d4:      	movl	%ecx, 0x2c0(%r14)
    59db:      	leaq	(%rax,%rax,2), %rax
    59df:      	movq	0x90(%rsp), %rcx
    59e7:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    59ef:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    59f7:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    5a00:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    5a08:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    5a14:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    5a1f:      	movq	0xee0(%r14), %rax
    5a26:      	movq	%rsp, %rdi
    5a29:      	movl	$0x10, %ecx
    5a2e:      	movl	$0x70, %r8d
    5a34:      	movq	0xee0(%r14), %rdx
    5a3b:      	movl	$0x10, %esi
    5a40:      	callq	*%r8
    5a43:      	testq	%rax, %rax
    5a46:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    5a4c:      	movq	0xee0(%r14), %rax
    5a53:      	addq	$0x10, %rax
    5a57:      	movq	%rax, 0xed8(%r14)
    5a5e:      	movq	(%rsp), %rax
    5a62:      	movq	%rax, 0xee0(%r14)
    5a69:      	movq	0x8(%rsp), %rax
    5a6e:      	movq	%rax, 0xed0(%r14)
    5a75:      	movb	$0x1, 0xf30(%r14)
    5a7d:      	movq	(%rip), %rax            # 0x5a84 <perf_unwind_v8+0x5a84>
    5a84:      	cmpl	$0x0, (%rax)
    5a87:      	je	0x5af1 <perf_unwind_v8+0x5af1>
    5a89:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    5a93:      	movq	%rax, 0x17(%rsp)
    5a98:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    5aa2:      	movq	%rax, 0x10(%rsp)
    5aa7:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    5ab1:      	movq	%rax, 0x8(%rsp)
    5ab6:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    5ac0:      	movq	%rax, (%rsp)
    5ac4:      	movq	%rsp, %rdi
    5ac7:      	movl	$0x1f, %eax
    5acc:      	movl	$0x6, %r9d
    5ad2:      	movq	0xed0(%r14), %rdx
    5ad9:      	movq	0xed8(%r14), %rcx
    5ae0:      	movq	0xee0(%r14), %r8
    5ae7:      	movl	$0x1f, %esi
    5aec:      	xorl	%eax, %eax
    5aee:      	callq	*%r9
    5af1:      	movl	$0x38, 0x70(%rsp)
    5af9:      	movq	(%rip), %rdi            # 0x5b00 <perf_unwind_v8+0x5b00>
    5b00:      	leaq	0x70(%rsp), %rsi
    5b05:      	movl	$0x1, %eax
    5b0a:      	callq	*%rax
    5b0c:      	testq	%rax, %rax
    5b0f:      	je	0x5b19 <perf_unwind_v8+0x5b19>
    5b11:      	incq	(%rax)
    5b14:      	jmp	0x5b9a <perf_unwind_v8+0x5b9a>
    5b19:      	xorl	%eax, %eax
    5b1b:      	movq	(%rip), %rcx            # 0x5b22 <perf_unwind_v8+0x5b22>
    5b22:      	cmpl	$0x0, (%rcx)
    5b25:      	je	0x5ba3 <perf_unwind_v8+0x5ba3>
    5b27:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5b31:      	movq	%rax, 0x26(%rsp)
    5b36:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5b40:      	movq	%rax, 0x20(%rsp)
    5b45:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5b4f:      	movq	%rax, 0x18(%rsp)
    5b54:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5b5e:      	movq	%rax, 0x10(%rsp)
    5b63:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5b6d:      	movq	%rax, 0x8(%rsp)
    5b72:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5b7c:      	movq	%rax, (%rsp)
    5b80:      	movq	%rsp, %rdi
    5b83:      	movl	$0x2e, %eax
    5b88:      	movl	$0x6, %ecx
    5b8d:      	movl	0x70(%rsp), %edx
    5b91:      	movl	$0x2e, %esi
    5b96:      	xorl	%eax, %eax
    5b98:      	callq	*%rcx
    5b9a:      	movq	(%rip), %rax            # 0x5ba1 <perf_unwind_v8+0x5ba1>
    5ba1:      	movl	(%rax), %eax
    5ba3:      	movq	0xed0(%r14), %r12
    5baa:      	testq	%r12, %r12
    5bad:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    5bb3:      	testl	%eax, %eax
    5bb5:      	je	0x5c3d <perf_unwind_v8+0x5c3d>
    5bbb:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    5bc5:      	movq	%rax, 0x28(%rsp)
    5bca:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    5bd4:      	movq	%rax, 0x20(%rsp)
    5bd9:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    5be3:      	movq	%rax, 0x18(%rsp)
    5be8:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    5bf2:      	movq	%rax, 0x10(%rsp)
    5bf7:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    5c01:      	movq	%rax, 0x8(%rsp)
    5c06:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    5c10:      	movq	%rax, (%rsp)
    5c14:      	movb	$0x0, 0x30(%rsp)
    5c19:      	movq	%rsp, %rdi
    5c1c:      	movl	$0x31, %eax
    5c21:      	movl	$0x6, %ecx
    5c26:      	movl	0x2c0(%r14), %edx
    5c2d:      	movl	$0x31, %esi
    5c32:      	xorl	%eax, %eax
    5c34:      	callq	*%rcx
    5c36:      	movq	0xed0(%r14), %r12
    5c3d:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    5c47:      	cmpq	%rax, %r12
    5c4a:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    5c50:      	cmpq	$0x1000, %r12           # imm = 0x1000
    5c57:      	jb	0x285e <perf_unwind_v8+0x285e>
    5c5d:      	movl	(%r14), %eax
    5c60:      	movl	$0x60, 0x70(%rsp)
    5c68:      	movbel	%eax, 0x74(%rsp)
    5c6e:      	movbeq	%r12, 0x78(%rsp)
    5c75:      	movq	(%rip), %rdi            # 0x5c7c <perf_unwind_v8+0x5c7c>
    5c7c:      	leaq	0x70(%rsp), %rsi
    5c81:      	movl	$0x1, %eax
    5c86:      	callq	*%rax
    5c88:      	testq	%rax, %rax
    5c8b:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    5c91:      	movq	0x8(%rax), %rbp
    5c95:      	movq	%rbp, %rcx
    5c98:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    5ca2:      	andq	%rdx, %rcx
    5ca5:      	movq	%rcx, 0xf20(%r14)
    5cac:      	movq	(%rax), %rax
    5caf:      	movq	%rax, 0xf10(%r14)
    5cb6:      	shrq	$0x38, %rbp
    5cba:      	movq	%r12, %rax
    5cbd:      	subq	%rcx, %rax
    5cc0:      	movq	%rax, 0xf18(%r14)
    5cc7:      	movq	(%rip), %rax            # 0x5cce <perf_unwind_v8+0x5cce>
    5cce:      	cmpl	$0x0, (%rax)
    5cd1:      	je	0x5ddd <perf_unwind_v8+0x5ddd>
    5cd7:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    5ce1:      	movq	%rax, 0x28(%rsp)
    5ce6:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    5cf0:      	movq	%rax, 0x20(%rsp)
    5cf5:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    5cff:      	movq	%rax, 0x18(%rsp)
    5d04:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    5d0e:      	movq	%rax, 0x10(%rsp)
    5d13:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    5d1d:      	movq	%rax, 0x8(%rsp)
    5d22:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    5d2c:      	movq	%r13, (%rsp)
    5d30:      	movw	$0xa, 0x30(%rsp)
    5d37:      	movq	%rsp, %rdi
    5d3a:      	movl	$0x32, %eax
    5d3f:      	movl	$0x6, %r9d
    5d45:      	movq	0xf10(%r14), %rcx
    5d4c:      	movl	$0x32, %esi
    5d51:      	movq	%r12, %rdx
    5d54:      	movl	%ebp, %r8d
    5d57:      	xorl	%eax, %eax
    5d59:      	callq	*%r9
    5d5c:      	movq	(%rip), %rax            # 0x5d63 <perf_unwind_v8+0x5d63>
    5d63:      	cmpl	$0x0, (%rax)
    5d66:      	je	0x5ddd <perf_unwind_v8+0x5ddd>
    5d68:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    5d72:      	movq	%rax, 0x27(%rsp)
    5d77:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    5d81:      	movq	%rax, 0x20(%rsp)
    5d86:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    5d90:      	movq	%rax, 0x18(%rsp)
    5d95:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    5d9f:      	movq	%rax, 0x10(%rsp)
    5da4:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    5dae:      	movq	%rax, 0x8(%rsp)
    5db3:      	movq	%r13, (%rsp)
    5db7:      	movq	%rsp, %rdi
    5dba:      	movl	$0x2f, %eax
    5dbf:      	movl	$0x6, %r8d
    5dc5:      	movq	0xf18(%r14), %rcx
    5dcc:      	movq	0xf20(%r14), %rdx
    5dd3:      	movl	$0x2f, %esi
    5dd8:      	xorl	%eax, %eax
    5dda:      	callq	*%r8
    5ddd:      	cmpl	$0x1, %ebp
    5de0:      	jne	0x5fbc <perf_unwind_v8+0x5fbc>
    5de6:      	movq	0xf10(%r14), %rax
    5ded:      	movq	%rax, 0x70(%rsp)
    5df2:      	movq	0xf18(%r14), %r13
    5df9:      	movq	(%rip), %rdi            # 0x5e00 <perf_unwind_v8+0x5e00>
    5e00:      	leaq	0x70(%rsp), %rsi
    5e05:      	movl	$0x1, %eax
    5e0a:      	callq	*%rax
    5e0c:      	movl	$0x1, %ebp
    5e11:      	testq	%rax, %rax
    5e14:      	je	0x5fbc <perf_unwind_v8+0x5fbc>
    5e1a:      	movq	%rax, %r12
    5e1d:      	cmpq	%r13, (%rax)
    5e20:      	ja	0x5e29 <perf_unwind_v8+0x5e29>
    5e22:      	cmpq	%r13, 0x8(%r12)
    5e27:      	jae	0x5e3f <perf_unwind_v8+0x5e3f>
    5e29:      	cmpq	%r13, 0x10(%r12)
    5e2e:      	ja	0x5fbc <perf_unwind_v8+0x5fbc>
    5e34:      	cmpq	%r13, 0x18(%r12)
    5e39:      	jb	0x5fbc <perf_unwind_v8+0x5fbc>
    5e3f:      	movq	(%rip), %rax            # 0x5e46 <perf_unwind_v8+0x5e46>
    5e46:      	cmpl	$0x0, (%rax)
    5e49:      	je	0x5ea2 <perf_unwind_v8+0x5ea2>
    5e4b:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    5e55:      	movq	%rax, 0x16(%rsp)
    5e5a:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    5e64:      	movq	%rax, 0x10(%rsp)
    5e69:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    5e73:      	movq	%rax, 0x8(%rsp)
    5e78:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5e82:      	movq	%rax, (%rsp)
    5e86:      	movq	%rsp, %rdi
    5e89:      	movl	$0x1e, %eax
    5e8e:      	movl	$0x6, %ecx
    5e93:      	movzwl	0x20(%r12), %edx
    5e99:      	movl	$0x1e, %esi
    5e9e:      	xorl	%eax, %eax
    5ea0:      	callq	*%rcx
    5ea2:      	movl	0x1380(%r14), %eax
    5ea9:      	movl	0x20(%r12), %ecx
    5eae:      	btl	%ecx, %eax
    5eb1:      	jae	0x5f12 <perf_unwind_v8+0x5f12>
    5eb3:      	movq	(%rip), %rax            # 0x5eba <perf_unwind_v8+0x5eba>
    5eba:      	cmpl	$0x0, (%rax)
    5ebd:      	je	0x5fbc <perf_unwind_v8+0x5fbc>
    5ec3:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    5ecd:      	movq	%rax, 0x10(%rsp)
    5ed2:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    5edc:      	movq	%rax, 0x8(%rsp)
    5ee1:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5eeb:      	movq	%rax, (%rsp)
    5eef:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    5ef7:      	movq	%rsp, %rdi
    5efa:      	movl	$0x1b, %eax
    5eff:      	movl	$0x6, %ecx
    5f04:      	movl	$0x1b, %esi
    5f09:      	xorl	%eax, %eax
    5f0b:      	callq	*%rcx
    5f0d:      	jmp	0x5fbc <perf_unwind_v8+0x5fbc>
    5f12:      	movl	$0x0, 0x64(%rsp)
    5f1a:      	movq	(%rip), %rdi            # 0x5f21 <perf_unwind_v8+0x5f21>
    5f21:      	leaq	0x64(%rsp), %rsi
    5f26:      	movl	$0x1, %eax
    5f2b:      	callq	*%rax
    5f2d:      	testq	%rax, %rax
    5f30:      	je	0x5f37 <perf_unwind_v8+0x5f37>
    5f32:      	incq	(%rax)
    5f35:      	jmp	0x5fb6 <perf_unwind_v8+0x5fb6>
    5f37:      	movq	(%rip), %rax            # 0x5f3e <perf_unwind_v8+0x5f3e>
    5f3e:      	cmpl	$0x0, (%rax)
    5f41:      	je	0x5fb6 <perf_unwind_v8+0x5fb6>
    5f43:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5f4d:      	movq	%rax, 0x26(%rsp)
    5f52:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5f5c:      	movq	%rax, 0x20(%rsp)
    5f61:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5f6b:      	movq	%rax, 0x18(%rsp)
    5f70:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5f7a:      	movq	%rax, 0x10(%rsp)
    5f7f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5f89:      	movq	%rax, 0x8(%rsp)
    5f8e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5f98:      	movq	%rax, (%rsp)
    5f9c:      	movq	%rsp, %rdi
    5f9f:      	movl	$0x2e, %eax
    5fa4:      	movl	$0x6, %ecx
    5fa9:      	movl	0x64(%rsp), %edx
    5fad:      	movl	$0x2e, %esi
    5fb2:      	xorl	%eax, %eax
    5fb4:      	callq	*%rcx
    5fb6:      	movzwl	0x20(%r12), %ebp
    5fbc:      	xorl	%r12d, %r12d
    5fbf:      	cmpl	$0x7, %ebp
    5fc2:      	jne	0x2070 <perf_unwind_v8+0x2070>
    5fc8:      	movq	0xed0(%r14), %rax
    5fcf:      	movq	%rax, 0xa0(%rsp)
    5fd7:      	movq	0xed8(%r14), %r12
    5fde:      	movq	0xee0(%r14), %r13
    5fe5:      	movq	(%rip), %rax            # 0x5fec <perf_unwind_v8+0x5fec>
    5fec:      	cmpl	$0x0, (%rax)
    5fef:      	je	0x6052 <perf_unwind_v8+0x6052>
    5ff1:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    5ffb:      	movq	%rax, 0x17(%rsp)
    6000:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    600a:      	movq	%rax, 0x10(%rsp)
    600f:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    6019:      	movq	%rax, 0x8(%rsp)
    601e:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    6028:      	movq	%rax, (%rsp)
    602c:      	movq	%rsp, %rdi
    602f:      	movl	$0x1f, %eax
    6034:      	movl	$0x6, %r9d
    603a:      	movl	$0x1f, %esi
    603f:      	movq	0xa0(%rsp), %rdx
    6047:      	movq	%r12, %rcx
    604a:      	movq	%r13, %r8
    604d:      	xorl	%eax, %eax
    604f:      	callq	*%r9
    6052:      	cmpq	%r12, %r13
    6055:      	jb	0x80b0 <perf_unwind_v8+0x80b0>
    605b:      	leaq	0x2000(%r12), %rax
    6063:      	cmpq	%rax, %r13
    6066:      	jae	0x80b0 <perf_unwind_v8+0x80b0>
    606c:      	addq	$-0x40, %r13
    6070:      	movl	$0x40, %eax
    6075:      	movl	$0x70, %ecx
    607a:      	movq	0x98(%rsp), %rdi
    6082:      	movl	$0x40, %esi
    6087:      	movq	%r13, %rdx
    608a:      	callq	*%rcx
    608c:      	testq	%rax, %rax
    608f:      	movq	(%rip), %rbp            # 0x6096 <perf_unwind_v8+0x6096>
    6096:      	jne	0x138 <perf_unwind_v8+0x138>
    609c:      	movq	0x48(%rsp), %rax
    60a1:      	movzbl	0x14(%rax), %ecx
    60a5:      	xorl	%ebp, %ebp
    60a7:      	cmpq	$0x38, %rcx
    60ab:      	ja	0x220 <perf_unwind_v8+0x220>
    60b1:      	movq	0x48(%rsp), %rax
    60b6:      	movzbl	0x15(%rax), %eax
    60ba:      	cmpq	$0x38, %rax
    60be:      	ja	0x220 <perf_unwind_v8+0x220>
    60c4:      	movq	0x48(%rsp), %rdx
    60c9:      	movzbl	0x16(%rdx), %edx
    60cd:      	cmpq	$0x38, %rdx
    60d1:      	ja	0x220 <perf_unwind_v8+0x220>
    60d7:      	movq	0x98(%rsp), %rsi
    60df:      	movq	(%rsi,%rcx), %rbp
    60e3:      	testb	$0x1, %bpl
    60e7:      	jne	0x6113 <perf_unwind_v8+0x6113>
    60e9:      	shrq	%rbp
    60ec:      	movq	(%rip), %rax            # 0x60f3 <perf_unwind_v8+0x60f3>
    60f3:      	cmpl	$0x0, (%rax)
    60f6:      	jne	0x6295 <perf_unwind_v8+0x6295>
    60fc:      	xorl	%eax, %eax
    60fe:      	movq	%rax, 0x90(%rsp)
    6106:      	movzbl	0xf30(%r14), %r12d
    610e:      	jmp	0x6993 <perf_unwind_v8+0x6993>
    6113:      	movq	0x98(%rsp), %rcx
    611b:      	movq	(%rcx,%rdx), %r12
    611f:      	movq	(%rcx,%rax), %rdx
    6123:      	movl	%edx, %ecx
    6125:      	andl	$0x3, %ecx
    6128:      	andq	$-0x4, %rdx
    612c:      	xorl	%eax, %eax
    612e:      	cmpl	$0x1, %ecx
    6131:      	cmovneq	%rax, %rdx
    6135:      	movq	%rdx, 0x68(%rsp)
    613a:      	testq	%rdx, %rdx
    613d:      	je	0x61b0 <perf_unwind_v8+0x61b0>
    613f:      	movq	0x48(%rsp), %rax
    6144:      	movzbl	0xc(%rax), %edx
    6148:      	addq	0x68(%rsp), %rdx
    614d:      	movq	%rsp, %rdi
    6150:      	movl	$0x8, %eax
    6155:      	movl	$0x70, %ecx
    615a:      	movl	$0x8, %esi
    615f:      	callq	*%rcx
    6161:      	testq	%rax, %rax
    6164:      	jne	0x61ae <perf_unwind_v8+0x61ae>
    6166:      	movq	(%rsp), %rax
    616a:      	movl	%eax, %ecx
    616c:      	andl	$0x3, %ecx
    616f:      	cmpl	$0x1, %ecx
    6172:      	jne	0x61ae <perf_unwind_v8+0x61ae>
    6174:      	andq	$-0x4, %rax
    6178:      	je	0x61ae <perf_unwind_v8+0x61ae>
    617a:      	movq	0x48(%rsp), %rsi
    617f:      	movzbl	0xd(%rsi), %ecx
    6183:      	addq	%rax, %rcx
    6186:      	movq	%rsp, %rdi
    6189:      	movl	$0x2, %edx
    618e:      	movl	$0x70, %r8d
    6194:      	movzbl	0xd(%rsi), %edx
    6198:      	addq	%rax, %rdx
    619b:      	movl	$0x2, %esi
    61a0:      	callq	*%r8
    61a3:      	testq	%rax, %rax
    61a6:      	jne	0x61ae <perf_unwind_v8+0x61ae>
    61a8:      	movzwl	(%rsp), %eax
    61ac:      	jmp	0x61b0 <perf_unwind_v8+0x61b0>
    61ae:      	xorl	%eax, %eax
    61b0:      	movq	0x48(%rsp), %rcx
    61b5:      	cmpw	0x4(%rcx), %ax
    61b9:      	jb	0x1c5f <perf_unwind_v8+0x1c5f>
    61bf:      	movq	0x48(%rsp), %r8
    61c4:      	cmpw	0x6(%r8), %ax
    61c9:      	ja	0x494 <perf_unwind_v8+0x494>
    61cf:      	movzbl	0xf(%r8), %edx
    61d4:      	addq	0x68(%rsp), %rdx
    61d9:      	movq	%rsp, %rdi
    61dc:      	movl	$0x8, %eax
    61e1:      	movl	$0x70, %ecx
    61e6:      	movl	$0x8, %esi
    61eb:      	callq	*%rcx
    61ed:      	testq	%rax, %rax
    61f0:      	jne	0x62f8 <perf_unwind_v8+0x62f8>
    61f6:      	movq	(%rsp), %rcx
    61fa:      	movq	%rcx, %rax
    61fd:      	movq	%rcx, 0x58(%rsp)
    6202:      	andl	$0x3, %eax
    6205:      	cmpl	$0x1, %eax
    6208:      	jne	0x62f8 <perf_unwind_v8+0x62f8>
    620e:      	andq	$-0x4, 0x58(%rsp)
    6214:      	je	0x62f8 <perf_unwind_v8+0x62f8>
    621a:      	movq	0x48(%rsp), %rax
    621f:      	movzbl	0xc(%rax), %edx
    6223:      	addq	0x58(%rsp), %rdx
    6228:      	movq	%rsp, %rdi
    622b:      	movl	$0x8, %eax
    6230:      	movl	$0x70, %ecx
    6235:      	movl	$0x8, %esi
    623a:      	callq	*%rcx
    623c:      	testq	%rax, %rax
    623f:      	jne	0x62ff <perf_unwind_v8+0x62ff>
    6245:      	movq	(%rsp), %rax
    6249:      	movl	%eax, %ecx
    624b:      	andl	$0x3, %ecx
    624e:      	cmpl	$0x1, %ecx
    6251:      	jne	0x62ff <perf_unwind_v8+0x62ff>
    6257:      	andq	$-0x4, %rax
    625b:      	je	0x62ff <perf_unwind_v8+0x62ff>
    6261:      	movq	0x48(%rsp), %rsi
    6266:      	movzbl	0xd(%rsi), %ecx
    626a:      	addq	%rax, %rcx
    626d:      	movq	%rsp, %rdi
    6270:      	movl	$0x2, %edx
    6275:      	movl	$0x70, %r8d
    627b:      	movzbl	0xd(%rsi), %edx
    627f:      	addq	%rax, %rdx
    6282:      	movl	$0x2, %esi
    6287:      	callq	*%r8
    628a:      	testq	%rax, %rax
    628d:      	jne	0x62ff <perf_unwind_v8+0x62ff>
    628f:      	movzwl	(%rsp), %eax
    6293:      	jmp	0x6301 <perf_unwind_v8+0x6301>
    6295:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    629f:      	movq	%rax, 0x15(%rsp)
    62a4:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    62ae:      	movq	%rax, 0x10(%rsp)
    62b3:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    62bd:      	movq	%rax, 0x8(%rsp)
    62c2:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    62cc:      	movq	%rax, (%rsp)
    62d0:      	movq	%rsp, %rdi
    62d3:      	movl	$0x1d, %eax
    62d8:      	movl	$0x6, %ecx
    62dd:      	xorl	%eax, %eax
    62df:      	movq	%rax, 0x90(%rsp)
    62e7:      	movl	$0x1d, %esi
    62ec:      	movq	%rbp, %rdx
    62ef:      	xorl	%eax, %eax
    62f1:      	callq	*%rcx
    62f3:      	jmp	0x68e8 <perf_unwind_v8+0x68e8>
    62f8:      	xorl	%eax, %eax
    62fa:      	movq	%rax, 0x58(%rsp)
    62ff:      	xorl	%eax, %eax
    6301:      	movq	0x48(%rsp), %rcx
    6306:      	cmpw	0xa(%rcx), %ax
    630a:      	jne	0x998 <perf_unwind_v8+0x998>
    6310:      	movq	%r12, %rbp
    6313:      	shrq	$0x20, %rbp
    6317:      	je	0x638e <perf_unwind_v8+0x638e>
    6319:      	andl	$0x1, %r12d
    631d:      	jne	0x638e <perf_unwind_v8+0x638e>
    631f:      	movq	(%rip), %rax            # 0x6326 <perf_unwind_v8+0x6326>
    6326:      	cmpl	$0x0, (%rax)
    6329:      	je	0x6378 <perf_unwind_v8+0x6378>
    632b:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    6335:      	movq	%rax, 0x10(%rsp)
    633a:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    6344:      	movq	%rax, 0x8(%rsp)
    6349:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    6353:      	movq	%rax, (%rsp)
    6357:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    635f:      	movq	%rsp, %rdi
    6362:      	movl	$0x1c, %eax
    6367:      	movl	$0x6, %ecx
    636c:      	movl	$0x1c, %esi
    6371:      	movq	%rbp, %rdx
    6374:      	xorl	%eax, %eax
    6376:      	callq	*%rcx
    6378:      	movq	0x58(%rsp), %r15
    637d:      	orq	$0x1, %r15
    6381:      	movq	%r15, 0x90(%rsp)
    6389:      	jmp	0x68e8 <perf_unwind_v8+0x68e8>
    638e:      	movq	0x48(%rsp), %rax
    6393:      	movzbl	0xe(%rax), %edx
    6397:      	addq	0x68(%rsp), %rdx
    639c:      	movq	%rsp, %rdi
    639f:      	movl	$0x8, %eax
    63a4:      	movl	$0x70, %ecx
    63a9:      	movl	$0x8, %esi
    63ae:      	callq	*%rcx
    63b0:      	testq	%rax, %rax
    63b3:      	jne	0x6444 <perf_unwind_v8+0x6444>
    63b9:      	movq	(%rsp), %rcx
    63bd:      	movq	%rcx, %rax
    63c0:      	movq	%rcx, 0x50(%rsp)
    63c5:      	andl	$0x3, %eax
    63c8:      	cmpl	$0x1, %eax
    63cb:      	jne	0x6444 <perf_unwind_v8+0x6444>
    63cd:      	andq	$-0x4, 0x50(%rsp)
    63d3:      	je	0x6444 <perf_unwind_v8+0x6444>
    63d5:      	movq	0x48(%rsp), %rax
    63da:      	movzbl	0xc(%rax), %edx
    63de:      	addq	0x50(%rsp), %rdx
    63e3:      	movq	%rsp, %rdi
    63e6:      	movl	$0x8, %eax
    63eb:      	movl	$0x70, %ecx
    63f0:      	movl	$0x8, %esi
    63f5:      	callq	*%rcx
    63f7:      	testq	%rax, %rax
    63fa:      	jne	0x644b <perf_unwind_v8+0x644b>
    63fc:      	movq	(%rsp), %rax
    6400:      	movl	%eax, %ecx
    6402:      	andl	$0x3, %ecx
    6405:      	cmpl	$0x1, %ecx
    6408:      	jne	0x644b <perf_unwind_v8+0x644b>
    640a:      	andq	$-0x4, %rax
    640e:      	je	0x644b <perf_unwind_v8+0x644b>
    6410:      	movq	0x48(%rsp), %rsi
    6415:      	movzbl	0xd(%rsi), %ecx
    6419:      	addq	%rax, %rcx
    641c:      	movq	%rsp, %rdi
    641f:      	movl	$0x2, %edx
    6424:      	movl	$0x70, %r8d
    642a:      	movzbl	0xd(%rsi), %edx
    642e:      	addq	%rax, %rdx
    6431:      	movl	$0x2, %esi
    6436:      	callq	*%r8
    6439:      	testq	%rax, %rax
    643c:      	jne	0x644b <perf_unwind_v8+0x644b>
    643e:      	movzwl	(%rsp), %eax
    6442:      	jmp	0x644d <perf_unwind_v8+0x644d>
    6444:      	xorl	%eax, %eax
    6446:      	movq	%rax, 0x50(%rsp)
    644b:      	xorl	%eax, %eax
    644d:      	movq	0x58(%rsp), %rcx
    6452:      	orq	$0x2, %rcx
    6456:      	movq	%rcx, 0x90(%rsp)
    645e:      	movq	0x48(%rsp), %rcx
    6463:      	cmpw	0x8(%rcx), %ax
    6467:      	jne	0x6533 <perf_unwind_v8+0x6533>
    646d:      	movl	$0x60, %eax
    6472:      	movl	$0x70, %ecx
    6477:      	movq	0xb0(%rsp), %rdi
    647f:      	movq	0x50(%rsp), %rdx
    6484:      	movl	$0x60, %esi
    6489:      	callq	*%rcx
    648b:      	testq	%rax, %rax
    648e:      	je	0x65e8 <perf_unwind_v8+0x65e8>
    6494:      	movl	$0x3b, 0x70(%rsp)
    649c:      	movq	(%rip), %rdi            # 0x64a3 <perf_unwind_v8+0x64a3>
    64a3:      	leaq	0x70(%rsp), %rsi
    64a8:      	movl	$0x1, %eax
    64ad:      	callq	*%rax
    64af:      	testq	%rax, %rax
    64b2:      	jne	0x65de <perf_unwind_v8+0x65de>
    64b8:      	movq	(%rip), %rax            # 0x64bf <perf_unwind_v8+0x64bf>
    64bf:      	cmpl	$0x0, (%rax)
    64c2:      	je	0x66b4 <perf_unwind_v8+0x66b4>
    64c8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    64d2:      	movq	%rax, 0x26(%rsp)
    64d7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    64e1:      	movq	%rax, 0x20(%rsp)
    64e6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    64f0:      	movq	%rax, 0x18(%rsp)
    64f5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    64ff:      	movq	%rax, 0x10(%rsp)
    6504:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    650e:      	movq	%rax, 0x8(%rsp)
    6513:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    651d:      	movq	%rax, (%rsp)
    6521:      	movq	%rsp, %rdi
    6524:      	movl	$0x2e, %eax
    6529:      	movl	$0x6, %ecx
    652e:      	jmp	0x66a7 <perf_unwind_v8+0x66a7>
    6533:      	movq	(%rip), %rcx            # 0x653a <perf_unwind_v8+0x653a>
    653a:      	cmpl	$0x0, (%rcx)
    653d:      	je	0x65be <perf_unwind_v8+0x65be>
    653f:      	movzwl	%ax, %r8d
    6543:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    654d:      	movq	%rax, 0x26(%rsp)
    6552:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    655c:      	movq	%rax, 0x20(%rsp)
    6561:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    656b:      	movq	%rax, 0x18(%rsp)
    6570:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    657a:      	movq	%rax, 0x10(%rsp)
    657f:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    6589:      	movq	%rax, 0x8(%rsp)
    658e:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    6598:      	movq	%rax, (%rsp)
    659c:      	movq	%rsp, %rdi
    659f:      	movl	$0x2e, %eax
    65a4:      	movl	$0x6, %r9d
    65aa:      	movl	$0x2e, %esi
    65af:      	movq	0x68(%rsp), %rdx
    65b4:      	movq	0x50(%rsp), %rcx
    65b9:      	xorl	%eax, %eax
    65bb:      	callq	*%r9
    65be:      	movl	$0x3b, 0x70(%rsp)
    65c6:      	movq	(%rip), %rdi            # 0x65cd <perf_unwind_v8+0x65cd>
    65cd:      	leaq	0x70(%rsp), %rsi
    65d2:      	movl	$0x1, %eax
    65d7:      	callq	*%rax
    65d9:      	testq	%rax, %rax
    65dc:      	je	0x6635 <perf_unwind_v8+0x6635>
    65de:      	incq	(%rax)
    65e1:      	xorl	%ebp, %ebp
    65e3:      	jmp	0x68e8 <perf_unwind_v8+0x68e8>
    65e8:      	movq	0x48(%rsp), %rax
    65ed:      	movzbl	0x12(%rax), %ecx
    65f1:      	xorl	%ebp, %ebp
    65f3:      	cmpq	$0x5c, %rcx
    65f7:      	ja	0x220 <perf_unwind_v8+0x220>
    65fd:      	movq	0x48(%rsp), %rax
    6602:      	movzbl	0x13(%rax), %eax
    6606:      	cmpq	$0x5c, %rax
    660a:      	ja	0x220 <perf_unwind_v8+0x220>
    6610:      	movq	0x48(%rsp), %rdx
    6615:      	cmpb	$0x0, 0x10(%rdx)
    6619:      	movzbl	0x11(%rdx), %r12d
    661e:      	je	0x66bb <perf_unwind_v8+0x66bb>
    6624:      	movq	0xb0(%rsp), %rdx
    662c:      	movq	(%rdx,%r12), %r12
    6630:      	jmp	0x66c0 <perf_unwind_v8+0x66c0>
    6635:      	movq	(%rip), %rax            # 0x663c <perf_unwind_v8+0x663c>
    663c:      	cmpl	$0x0, (%rax)
    663f:      	je	0x66b4 <perf_unwind_v8+0x66b4>
    6641:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    664b:      	movq	%rax, 0x26(%rsp)
    6650:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    665a:      	movq	%rax, 0x20(%rsp)
    665f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6669:      	movq	%rax, 0x18(%rsp)
    666e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6678:      	movq	%rax, 0x10(%rsp)
    667d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6687:      	movq	%rax, 0x8(%rsp)
    668c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6696:      	movq	%rax, (%rsp)
    669a:      	movq	%rsp, %rdi
    669d:      	movl	$0x2e, %eax
    66a2:      	movl	$0x6, %ecx
    66a7:      	movl	0x70(%rsp), %edx
    66ab:      	movl	$0x2e, %esi
    66b0:      	xorl	%eax, %eax
    66b2:      	callq	*%rcx
    66b4:      	xorl	%ebp, %ebp
    66b6:      	jmp	0x68e8 <perf_unwind_v8+0x68e8>
    66bb:      	addq	0x50(%rsp), %r12
    66c0:      	movq	0xb0(%rsp), %rdx
    66c8:      	movl	(%rdx,%rcx), %r13d
    66cc:      	movq	0x48(%rsp), %rcx
    66d1:      	movzbl	0x17(%rcx), %esi
    66d5:      	movl	%esi, 0xac(%rsp)
    66dc:      	movzbl	0x18(%rcx), %r15d
    66e1:      	movq	%r13, %rcx
    66e4:      	addq	%r12, %rcx
    66e7:      	movq	%rcx, 0xb8(%rsp)
    66ef:      	andl	(%rdx,%rax), %r15d
    66f3:      	movq	(%rip), %rax            # 0x66fa <perf_unwind_v8+0x66fa>
    66fa:      	cmpl	$0x0, (%rax)
    66fd:      	je	0x67f5 <perf_unwind_v8+0x67f5>
    6703:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    670d:      	movq	%rax, 0x20(%rsp)
    6712:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    671c:      	movq	%rax, 0x18(%rsp)
    6721:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    672b:      	movq	%rax, 0x10(%rsp)
    6730:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    673a:      	movq	%rax, 0x8(%rsp)
    673f:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    6749:      	movq	%rax, (%rsp)
    674d:      	movb	$0x0, 0x28(%rsp)
    6752:      	movq	%rsp, %rdi
    6755:      	movl	$0x29, %eax
    675a:      	movl	$0x6, %r9d
    6760:      	movl	$0x29, %esi
    6765:      	movq	0x68(%rsp), %rdx
    676a:      	movq	0x58(%rsp), %rcx
    676f:      	movq	0x50(%rsp), %r8
    6774:      	xorl	%eax, %eax
    6776:      	callq	*%r9
    6779:      	movq	(%rip), %rax            # 0x6780 <perf_unwind_v8+0x6780>
    6780:      	cmpl	$0x0, (%rax)
    6783:      	je	0x67f5 <perf_unwind_v8+0x67f5>
    6785:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    678f:      	movq	%rax, 0x1d(%rsp)
    6794:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    679e:      	movq	%rax, 0x18(%rsp)
    67a3:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    67ad:      	movq	%rax, 0x10(%rsp)
    67b2:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    67bc:      	movq	%rax, 0x8(%rsp)
    67c1:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    67cb:      	movq	%rax, (%rsp)
    67cf:      	movq	%rsp, %rdi
    67d2:      	movl	$0x25, %eax
    67d7:      	movl	$0x6, %r9d
    67dd:      	movl	$0x25, %esi
    67e2:      	movq	%r12, %rdx
    67e5:      	movq	0xb8(%rsp), %rcx
    67ed:      	movl	%r13d, %r8d
    67f0:      	xorl	%eax, %eax
    67f2:      	callq	*%r9
    67f5:      	movq	0xa0(%rsp), %rbp
    67fd:      	subq	%r12, %rbp
    6800:      	jb	0x685c <perf_unwind_v8+0x685c>
    6802:      	movq	0xb8(%rsp), %rax
    680a:      	cmpq	%rax, 0xa0(%rsp)
    6812:      	jae	0x685c <perf_unwind_v8+0x685c>
    6814:      	movl	0xac(%rsp), %eax
    681b:      	shrxl	%eax, %r15d, %eax
    6820:      	movq	0x48(%rsp), %rcx
    6825:      	movzbl	0x19(%rcx), %ecx
    6829:      	movq	0x68(%rsp), %r15
    682e:      	orq	$0x4, %r15
    6832:      	movq	0x50(%rsp), %rdx
    6837:      	orq	$0x3, %rdx
    683b:      	cmpl	%ecx, %eax
    683d:      	cmoveq	%r15, %rdx
    6841:      	shll	$0x4, %r13d
    6845:      	orl	%eax, %r13d
    6848:      	shlq	$0x20, %r13
    684c:      	orq	%r13, %rbp
    684f:      	movq	%rdx, 0x90(%rsp)
    6857:      	jmp	0x68e8 <perf_unwind_v8+0x68e8>
    685c:      	movq	(%rip), %rax            # 0x6863 <perf_unwind_v8+0x6863>
    6863:      	cmpl	$0x0, (%rax)
    6866:      	jne	0x6877 <perf_unwind_v8+0x6877>
    6868:      	xorl	%ebp, %ebp
    686a:      	movzbl	0xf30(%r14), %r12d
    6872:      	jmp	0x6993 <perf_unwind_v8+0x6993>
    6877:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    6881:      	movq	%rax, 0x28(%rsp)
    6886:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    6890:      	movq	%rax, 0x20(%rsp)
    6895:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    689f:      	movq	%rax, 0x18(%rsp)
    68a4:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    68ae:      	movq	%rax, 0x10(%rsp)
    68b3:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    68bd:      	movq	%rax, 0x8(%rsp)
    68c2:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    68cc:      	movq	%rax, (%rsp)
    68d0:      	movq	%rsp, %rdi
    68d3:      	movl	$0x30, %eax
    68d8:      	movl	$0x6, %ecx
    68dd:      	xorl	%ebp, %ebp
    68df:      	movl	$0x30, %esi
    68e4:      	xorl	%eax, %eax
    68e6:      	callq	*%rcx
    68e8:      	movzbl	0xf30(%r14), %r12d
    68f0:      	movq	(%rip), %rax            # 0x68f7 <perf_unwind_v8+0x68f7>
    68f7:      	cmpl	$0x0, (%rax)
    68fa:      	je	0x6993 <perf_unwind_v8+0x6993>
    6900:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    690a:      	movq	%rax, 0x30(%rsp)
    690f:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    6919:      	movq	%rax, 0x28(%rsp)
    691e:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    6928:      	movq	%rax, 0x20(%rsp)
    692d:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    6937:      	movq	%rax, 0x18(%rsp)
    693c:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    6946:      	movq	%rax, 0x10(%rsp)
    694b:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    6955:      	movq	%rax, 0x8(%rsp)
    695a:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    6964:      	movq	%rax, (%rsp)
    6968:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    6970:      	movq	%rsp, %rdi
    6973:      	movl	$0x3c, %eax
    6978:      	movl	$0x6, %r8d
    697e:      	movl	$0x3c, %esi
    6983:      	movq	%rbp, %rdx
    6986:      	movq	0x90(%rsp), %rcx
    698e:      	xorl	%eax, %eax
    6990:      	callq	*%r8
    6993:      	movl	0x2c0(%r14), %eax
    699a:      	cmpq	$0x7e, %rax
    699e:      	ja	0x27d <perf_unwind_v8+0x27d>
    69a4:      	leal	0x1(%rax), %ecx
    69a7:      	movl	%ecx, 0x2c0(%r14)
    69ae:      	leaq	(%rax,%rax,2), %rax
    69b2:      	movq	0x90(%rsp), %rcx
    69ba:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    69c2:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    69ca:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    69d3:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    69db:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    69e7:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    69f2:      	movq	0xee0(%r14), %rax
    69f9:      	movq	%rsp, %rdi
    69fc:      	movl	$0x10, %ecx
    6a01:      	movl	$0x70, %r8d
    6a07:      	movq	0xee0(%r14), %rdx
    6a0e:      	movl	$0x10, %esi
    6a13:      	callq	*%r8
    6a16:      	testq	%rax, %rax
    6a19:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    6a1f:      	movq	0xee0(%r14), %rax
    6a26:      	addq	$0x10, %rax
    6a2a:      	movq	%rax, 0xed8(%r14)
    6a31:      	movq	(%rsp), %rax
    6a35:      	movq	%rax, 0xee0(%r14)
    6a3c:      	movq	0x8(%rsp), %rax
    6a41:      	movq	%rax, 0xed0(%r14)
    6a48:      	movb	$0x1, 0xf30(%r14)
    6a50:      	movq	(%rip), %rax            # 0x6a57 <perf_unwind_v8+0x6a57>
    6a57:      	cmpl	$0x0, (%rax)
    6a5a:      	je	0x6ac4 <perf_unwind_v8+0x6ac4>
    6a5c:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    6a66:      	movq	%rax, 0x17(%rsp)
    6a6b:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    6a75:      	movq	%rax, 0x10(%rsp)
    6a7a:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    6a84:      	movq	%rax, 0x8(%rsp)
    6a89:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    6a93:      	movq	%rax, (%rsp)
    6a97:      	movq	%rsp, %rdi
    6a9a:      	movl	$0x1f, %eax
    6a9f:      	movl	$0x6, %r9d
    6aa5:      	movq	0xed0(%r14), %rdx
    6aac:      	movq	0xed8(%r14), %rcx
    6ab3:      	movq	0xee0(%r14), %r8
    6aba:      	movl	$0x1f, %esi
    6abf:      	xorl	%eax, %eax
    6ac1:      	callq	*%r9
    6ac4:      	movl	$0x38, 0x70(%rsp)
    6acc:      	movq	(%rip), %rdi            # 0x6ad3 <perf_unwind_v8+0x6ad3>
    6ad3:      	leaq	0x70(%rsp), %rsi
    6ad8:      	movl	$0x1, %eax
    6add:      	callq	*%rax
    6adf:      	testq	%rax, %rax
    6ae2:      	je	0x6aec <perf_unwind_v8+0x6aec>
    6ae4:      	incq	(%rax)
    6ae7:      	jmp	0x6b6d <perf_unwind_v8+0x6b6d>
    6aec:      	xorl	%eax, %eax
    6aee:      	movq	(%rip), %rcx            # 0x6af5 <perf_unwind_v8+0x6af5>
    6af5:      	cmpl	$0x0, (%rcx)
    6af8:      	je	0x6b76 <perf_unwind_v8+0x6b76>
    6afa:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6b04:      	movq	%rax, 0x26(%rsp)
    6b09:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6b13:      	movq	%rax, 0x20(%rsp)
    6b18:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6b22:      	movq	%rax, 0x18(%rsp)
    6b27:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6b31:      	movq	%rax, 0x10(%rsp)
    6b36:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6b40:      	movq	%rax, 0x8(%rsp)
    6b45:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6b4f:      	movq	%rax, (%rsp)
    6b53:      	movq	%rsp, %rdi
    6b56:      	movl	$0x2e, %eax
    6b5b:      	movl	$0x6, %ecx
    6b60:      	movl	0x70(%rsp), %edx
    6b64:      	movl	$0x2e, %esi
    6b69:      	xorl	%eax, %eax
    6b6b:      	callq	*%rcx
    6b6d:      	movq	(%rip), %rax            # 0x6b74 <perf_unwind_v8+0x6b74>
    6b74:      	movl	(%rax), %eax
    6b76:      	movq	0xed0(%r14), %r12
    6b7d:      	testq	%r12, %r12
    6b80:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    6b86:      	testl	%eax, %eax
    6b88:      	je	0x6c10 <perf_unwind_v8+0x6c10>
    6b8e:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    6b98:      	movq	%rax, 0x28(%rsp)
    6b9d:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    6ba7:      	movq	%rax, 0x20(%rsp)
    6bac:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    6bb6:      	movq	%rax, 0x18(%rsp)
    6bbb:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    6bc5:      	movq	%rax, 0x10(%rsp)
    6bca:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    6bd4:      	movq	%rax, 0x8(%rsp)
    6bd9:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    6be3:      	movq	%rax, (%rsp)
    6be7:      	movb	$0x0, 0x30(%rsp)
    6bec:      	movq	%rsp, %rdi
    6bef:      	movl	$0x31, %eax
    6bf4:      	movl	$0x6, %ecx
    6bf9:      	movl	0x2c0(%r14), %edx
    6c00:      	movl	$0x31, %esi
    6c05:      	xorl	%eax, %eax
    6c07:      	callq	*%rcx
    6c09:      	movq	0xed0(%r14), %r12
    6c10:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    6c1a:      	cmpq	%rax, %r12
    6c1d:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    6c23:      	cmpq	$0x1000, %r12           # imm = 0x1000
    6c2a:      	jb	0x285e <perf_unwind_v8+0x285e>
    6c30:      	movl	(%r14), %eax
    6c33:      	movl	$0x60, 0x70(%rsp)
    6c3b:      	movbel	%eax, 0x74(%rsp)
    6c41:      	movbeq	%r12, 0x78(%rsp)
    6c48:      	movq	(%rip), %rdi            # 0x6c4f <perf_unwind_v8+0x6c4f>
    6c4f:      	leaq	0x70(%rsp), %rsi
    6c54:      	movl	$0x1, %eax
    6c59:      	callq	*%rax
    6c5b:      	testq	%rax, %rax
    6c5e:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    6c64:      	movq	0x8(%rax), %rbp
    6c68:      	movq	%rbp, %rcx
    6c6b:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    6c75:      	andq	%rdx, %rcx
    6c78:      	movq	%rcx, 0xf20(%r14)
    6c7f:      	movq	(%rax), %rax
    6c82:      	movq	%rax, 0xf10(%r14)
    6c89:      	shrq	$0x38, %rbp
    6c8d:      	movq	%r12, %rax
    6c90:      	subq	%rcx, %rax
    6c93:      	movq	%rax, 0xf18(%r14)
    6c9a:      	movq	(%rip), %rax            # 0x6ca1 <perf_unwind_v8+0x6ca1>
    6ca1:      	cmpl	$0x0, (%rax)
    6ca4:      	je	0x6db0 <perf_unwind_v8+0x6db0>
    6caa:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    6cb4:      	movq	%rax, 0x28(%rsp)
    6cb9:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    6cc3:      	movq	%rax, 0x20(%rsp)
    6cc8:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    6cd2:      	movq	%rax, 0x18(%rsp)
    6cd7:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    6ce1:      	movq	%rax, 0x10(%rsp)
    6ce6:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    6cf0:      	movq	%rax, 0x8(%rsp)
    6cf5:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    6cff:      	movq	%r13, (%rsp)
    6d03:      	movw	$0xa, 0x30(%rsp)
    6d0a:      	movq	%rsp, %rdi
    6d0d:      	movl	$0x32, %eax
    6d12:      	movl	$0x6, %r9d
    6d18:      	movq	0xf10(%r14), %rcx
    6d1f:      	movl	$0x32, %esi
    6d24:      	movq	%r12, %rdx
    6d27:      	movl	%ebp, %r8d
    6d2a:      	xorl	%eax, %eax
    6d2c:      	callq	*%r9
    6d2f:      	movq	(%rip), %rax            # 0x6d36 <perf_unwind_v8+0x6d36>
    6d36:      	cmpl	$0x0, (%rax)
    6d39:      	je	0x6db0 <perf_unwind_v8+0x6db0>
    6d3b:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    6d45:      	movq	%rax, 0x27(%rsp)
    6d4a:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    6d54:      	movq	%rax, 0x20(%rsp)
    6d59:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    6d63:      	movq	%rax, 0x18(%rsp)
    6d68:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    6d72:      	movq	%rax, 0x10(%rsp)
    6d77:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    6d81:      	movq	%rax, 0x8(%rsp)
    6d86:      	movq	%r13, (%rsp)
    6d8a:      	movq	%rsp, %rdi
    6d8d:      	movl	$0x2f, %eax
    6d92:      	movl	$0x6, %r8d
    6d98:      	movq	0xf18(%r14), %rcx
    6d9f:      	movq	0xf20(%r14), %rdx
    6da6:      	movl	$0x2f, %esi
    6dab:      	xorl	%eax, %eax
    6dad:      	callq	*%r8
    6db0:      	cmpl	$0x1, %ebp
    6db3:      	jne	0x6f8f <perf_unwind_v8+0x6f8f>
    6db9:      	movq	0xf10(%r14), %rax
    6dc0:      	movq	%rax, 0x70(%rsp)
    6dc5:      	movq	0xf18(%r14), %r13
    6dcc:      	movq	(%rip), %rdi            # 0x6dd3 <perf_unwind_v8+0x6dd3>
    6dd3:      	leaq	0x70(%rsp), %rsi
    6dd8:      	movl	$0x1, %eax
    6ddd:      	callq	*%rax
    6ddf:      	movl	$0x1, %ebp
    6de4:      	testq	%rax, %rax
    6de7:      	je	0x6f8f <perf_unwind_v8+0x6f8f>
    6ded:      	movq	%rax, %r12
    6df0:      	cmpq	%r13, (%rax)
    6df3:      	ja	0x6dfc <perf_unwind_v8+0x6dfc>
    6df5:      	cmpq	%r13, 0x8(%r12)
    6dfa:      	jae	0x6e12 <perf_unwind_v8+0x6e12>
    6dfc:      	cmpq	%r13, 0x10(%r12)
    6e01:      	ja	0x6f8f <perf_unwind_v8+0x6f8f>
    6e07:      	cmpq	%r13, 0x18(%r12)
    6e0c:      	jb	0x6f8f <perf_unwind_v8+0x6f8f>
    6e12:      	movq	(%rip), %rax            # 0x6e19 <perf_unwind_v8+0x6e19>
    6e19:      	cmpl	$0x0, (%rax)
    6e1c:      	je	0x6e75 <perf_unwind_v8+0x6e75>
    6e1e:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    6e28:      	movq	%rax, 0x16(%rsp)
    6e2d:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    6e37:      	movq	%rax, 0x10(%rsp)
    6e3c:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    6e46:      	movq	%rax, 0x8(%rsp)
    6e4b:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    6e55:      	movq	%rax, (%rsp)
    6e59:      	movq	%rsp, %rdi
    6e5c:      	movl	$0x1e, %eax
    6e61:      	movl	$0x6, %ecx
    6e66:      	movzwl	0x20(%r12), %edx
    6e6c:      	movl	$0x1e, %esi
    6e71:      	xorl	%eax, %eax
    6e73:      	callq	*%rcx
    6e75:      	movl	0x1380(%r14), %eax
    6e7c:      	movl	0x20(%r12), %ecx
    6e81:      	btl	%ecx, %eax
    6e84:      	jae	0x6ee5 <perf_unwind_v8+0x6ee5>
    6e86:      	movq	(%rip), %rax            # 0x6e8d <perf_unwind_v8+0x6e8d>
    6e8d:      	cmpl	$0x0, (%rax)
    6e90:      	je	0x6f8f <perf_unwind_v8+0x6f8f>
    6e96:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    6ea0:      	movq	%rax, 0x10(%rsp)
    6ea5:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    6eaf:      	movq	%rax, 0x8(%rsp)
    6eb4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    6ebe:      	movq	%rax, (%rsp)
    6ec2:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    6eca:      	movq	%rsp, %rdi
    6ecd:      	movl	$0x1b, %eax
    6ed2:      	movl	$0x6, %ecx
    6ed7:      	movl	$0x1b, %esi
    6edc:      	xorl	%eax, %eax
    6ede:      	callq	*%rcx
    6ee0:      	jmp	0x6f8f <perf_unwind_v8+0x6f8f>
    6ee5:      	movl	$0x0, 0x64(%rsp)
    6eed:      	movq	(%rip), %rdi            # 0x6ef4 <perf_unwind_v8+0x6ef4>
    6ef4:      	leaq	0x64(%rsp), %rsi
    6ef9:      	movl	$0x1, %eax
    6efe:      	callq	*%rax
    6f00:      	testq	%rax, %rax
    6f03:      	je	0x6f0a <perf_unwind_v8+0x6f0a>
    6f05:      	incq	(%rax)
    6f08:      	jmp	0x6f89 <perf_unwind_v8+0x6f89>
    6f0a:      	movq	(%rip), %rax            # 0x6f11 <perf_unwind_v8+0x6f11>
    6f11:      	cmpl	$0x0, (%rax)
    6f14:      	je	0x6f89 <perf_unwind_v8+0x6f89>
    6f16:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6f20:      	movq	%rax, 0x26(%rsp)
    6f25:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6f2f:      	movq	%rax, 0x20(%rsp)
    6f34:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6f3e:      	movq	%rax, 0x18(%rsp)
    6f43:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6f4d:      	movq	%rax, 0x10(%rsp)
    6f52:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6f5c:      	movq	%rax, 0x8(%rsp)
    6f61:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6f6b:      	movq	%rax, (%rsp)
    6f6f:      	movq	%rsp, %rdi
    6f72:      	movl	$0x2e, %eax
    6f77:      	movl	$0x6, %ecx
    6f7c:      	movl	0x64(%rsp), %edx
    6f80:      	movl	$0x2e, %esi
    6f85:      	xorl	%eax, %eax
    6f87:      	callq	*%rcx
    6f89:      	movzwl	0x20(%r12), %ebp
    6f8f:      	xorl	%r12d, %r12d
    6f92:      	cmpl	$0x7, %ebp
    6f95:      	jne	0x2070 <perf_unwind_v8+0x2070>
    6f9b:      	movq	0xed0(%r14), %rax
    6fa2:      	movq	%rax, 0xa0(%rsp)
    6faa:      	movq	0xed8(%r14), %r12
    6fb1:      	movq	0xee0(%r14), %r13
    6fb8:      	movq	(%rip), %rax            # 0x6fbf <perf_unwind_v8+0x6fbf>
    6fbf:      	cmpl	$0x0, (%rax)
    6fc2:      	je	0x7025 <perf_unwind_v8+0x7025>
    6fc4:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    6fce:      	movq	%rax, 0x17(%rsp)
    6fd3:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    6fdd:      	movq	%rax, 0x10(%rsp)
    6fe2:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    6fec:      	movq	%rax, 0x8(%rsp)
    6ff1:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    6ffb:      	movq	%rax, (%rsp)
    6fff:      	movq	%rsp, %rdi
    7002:      	movl	$0x1f, %eax
    7007:      	movl	$0x6, %r9d
    700d:      	movl	$0x1f, %esi
    7012:      	movq	0xa0(%rsp), %rdx
    701a:      	movq	%r12, %rcx
    701d:      	movq	%r13, %r8
    7020:      	xorl	%eax, %eax
    7022:      	callq	*%r9
    7025:      	cmpq	%r12, %r13
    7028:      	jb	0x80b0 <perf_unwind_v8+0x80b0>
    702e:      	leaq	0x2000(%r12), %rax
    7036:      	cmpq	%rax, %r13
    7039:      	jae	0x80b0 <perf_unwind_v8+0x80b0>
    703f:      	addq	$-0x40, %r13
    7043:      	movl	$0x40, %eax
    7048:      	movl	$0x70, %ecx
    704d:      	movq	0x98(%rsp), %rdi
    7055:      	movl	$0x40, %esi
    705a:      	movq	%r13, %rdx
    705d:      	callq	*%rcx
    705f:      	testq	%rax, %rax
    7062:      	movq	(%rip), %rbp            # 0x7069 <perf_unwind_v8+0x7069>
    7069:      	jne	0x138 <perf_unwind_v8+0x138>
    706f:      	movq	0x48(%rsp), %rax
    7074:      	movzbl	0x14(%rax), %ecx
    7078:      	xorl	%ebp, %ebp
    707a:      	cmpq	$0x38, %rcx
    707e:      	ja	0x220 <perf_unwind_v8+0x220>
    7084:      	movq	0x48(%rsp), %rax
    7089:      	movzbl	0x15(%rax), %eax
    708d:      	cmpq	$0x38, %rax
    7091:      	ja	0x220 <perf_unwind_v8+0x220>
    7097:      	movq	0x48(%rsp), %rdx
    709c:      	movzbl	0x16(%rdx), %edx
    70a0:      	cmpq	$0x38, %rdx
    70a4:      	ja	0x220 <perf_unwind_v8+0x220>
    70aa:      	movq	0x98(%rsp), %rsi
    70b2:      	movq	(%rsi,%rcx), %rbp
    70b6:      	testb	$0x1, %bpl
    70ba:      	jne	0x70e6 <perf_unwind_v8+0x70e6>
    70bc:      	shrq	%rbp
    70bf:      	movq	(%rip), %rax            # 0x70c6 <perf_unwind_v8+0x70c6>
    70c6:      	cmpl	$0x0, (%rax)
    70c9:      	jne	0x7268 <perf_unwind_v8+0x7268>
    70cf:      	xorl	%eax, %eax
    70d1:      	movq	%rax, 0x90(%rsp)
    70d9:      	movzbl	0xf30(%r14), %r12d
    70e1:      	jmp	0x7966 <perf_unwind_v8+0x7966>
    70e6:      	movq	0x98(%rsp), %rcx
    70ee:      	movq	(%rcx,%rdx), %r12
    70f2:      	movq	(%rcx,%rax), %rdx
    70f6:      	movl	%edx, %ecx
    70f8:      	andl	$0x3, %ecx
    70fb:      	andq	$-0x4, %rdx
    70ff:      	xorl	%eax, %eax
    7101:      	cmpl	$0x1, %ecx
    7104:      	cmovneq	%rax, %rdx
    7108:      	movq	%rdx, 0x68(%rsp)
    710d:      	testq	%rdx, %rdx
    7110:      	je	0x7183 <perf_unwind_v8+0x7183>
    7112:      	movq	0x48(%rsp), %rax
    7117:      	movzbl	0xc(%rax), %edx
    711b:      	addq	0x68(%rsp), %rdx
    7120:      	movq	%rsp, %rdi
    7123:      	movl	$0x8, %eax
    7128:      	movl	$0x70, %ecx
    712d:      	movl	$0x8, %esi
    7132:      	callq	*%rcx
    7134:      	testq	%rax, %rax
    7137:      	jne	0x7181 <perf_unwind_v8+0x7181>
    7139:      	movq	(%rsp), %rax
    713d:      	movl	%eax, %ecx
    713f:      	andl	$0x3, %ecx
    7142:      	cmpl	$0x1, %ecx
    7145:      	jne	0x7181 <perf_unwind_v8+0x7181>
    7147:      	andq	$-0x4, %rax
    714b:      	je	0x7181 <perf_unwind_v8+0x7181>
    714d:      	movq	0x48(%rsp), %rsi
    7152:      	movzbl	0xd(%rsi), %ecx
    7156:      	addq	%rax, %rcx
    7159:      	movq	%rsp, %rdi
    715c:      	movl	$0x2, %edx
    7161:      	movl	$0x70, %r8d
    7167:      	movzbl	0xd(%rsi), %edx
    716b:      	addq	%rax, %rdx
    716e:      	movl	$0x2, %esi
    7173:      	callq	*%r8
    7176:      	testq	%rax, %rax
    7179:      	jne	0x7181 <perf_unwind_v8+0x7181>
    717b:      	movzwl	(%rsp), %eax
    717f:      	jmp	0x7183 <perf_unwind_v8+0x7183>
    7181:      	xorl	%eax, %eax
    7183:      	movq	0x48(%rsp), %rcx
    7188:      	cmpw	0x4(%rcx), %ax
    718c:      	jb	0x1c5f <perf_unwind_v8+0x1c5f>
    7192:      	movq	0x48(%rsp), %r8
    7197:      	cmpw	0x6(%r8), %ax
    719c:      	ja	0x494 <perf_unwind_v8+0x494>
    71a2:      	movzbl	0xf(%r8), %edx
    71a7:      	addq	0x68(%rsp), %rdx
    71ac:      	movq	%rsp, %rdi
    71af:      	movl	$0x8, %eax
    71b4:      	movl	$0x70, %ecx
    71b9:      	movl	$0x8, %esi
    71be:      	callq	*%rcx
    71c0:      	testq	%rax, %rax
    71c3:      	jne	0x72cb <perf_unwind_v8+0x72cb>
    71c9:      	movq	(%rsp), %rcx
    71cd:      	movq	%rcx, %rax
    71d0:      	movq	%rcx, 0x58(%rsp)
    71d5:      	andl	$0x3, %eax
    71d8:      	cmpl	$0x1, %eax
    71db:      	jne	0x72cb <perf_unwind_v8+0x72cb>
    71e1:      	andq	$-0x4, 0x58(%rsp)
    71e7:      	je	0x72cb <perf_unwind_v8+0x72cb>
    71ed:      	movq	0x48(%rsp), %rax
    71f2:      	movzbl	0xc(%rax), %edx
    71f6:      	addq	0x58(%rsp), %rdx
    71fb:      	movq	%rsp, %rdi
    71fe:      	movl	$0x8, %eax
    7203:      	movl	$0x70, %ecx
    7208:      	movl	$0x8, %esi
    720d:      	callq	*%rcx
    720f:      	testq	%rax, %rax
    7212:      	jne	0x72d2 <perf_unwind_v8+0x72d2>
    7218:      	movq	(%rsp), %rax
    721c:      	movl	%eax, %ecx
    721e:      	andl	$0x3, %ecx
    7221:      	cmpl	$0x1, %ecx
    7224:      	jne	0x72d2 <perf_unwind_v8+0x72d2>
    722a:      	andq	$-0x4, %rax
    722e:      	je	0x72d2 <perf_unwind_v8+0x72d2>
    7234:      	movq	0x48(%rsp), %rsi
    7239:      	movzbl	0xd(%rsi), %ecx
    723d:      	addq	%rax, %rcx
    7240:      	movq	%rsp, %rdi
    7243:      	movl	$0x2, %edx
    7248:      	movl	$0x70, %r8d
    724e:      	movzbl	0xd(%rsi), %edx
    7252:      	addq	%rax, %rdx
    7255:      	movl	$0x2, %esi
    725a:      	callq	*%r8
    725d:      	testq	%rax, %rax
    7260:      	jne	0x72d2 <perf_unwind_v8+0x72d2>
    7262:      	movzwl	(%rsp), %eax
    7266:      	jmp	0x72d4 <perf_unwind_v8+0x72d4>
    7268:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    7272:      	movq	%rax, 0x15(%rsp)
    7277:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    7281:      	movq	%rax, 0x10(%rsp)
    7286:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    7290:      	movq	%rax, 0x8(%rsp)
    7295:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    729f:      	movq	%rax, (%rsp)
    72a3:      	movq	%rsp, %rdi
    72a6:      	movl	$0x1d, %eax
    72ab:      	movl	$0x6, %ecx
    72b0:      	xorl	%eax, %eax
    72b2:      	movq	%rax, 0x90(%rsp)
    72ba:      	movl	$0x1d, %esi
    72bf:      	movq	%rbp, %rdx
    72c2:      	xorl	%eax, %eax
    72c4:      	callq	*%rcx
    72c6:      	jmp	0x78bb <perf_unwind_v8+0x78bb>
    72cb:      	xorl	%eax, %eax
    72cd:      	movq	%rax, 0x58(%rsp)
    72d2:      	xorl	%eax, %eax
    72d4:      	movq	0x48(%rsp), %rcx
    72d9:      	cmpw	0xa(%rcx), %ax
    72dd:      	jne	0x998 <perf_unwind_v8+0x998>
    72e3:      	movq	%r12, %rbp
    72e6:      	shrq	$0x20, %rbp
    72ea:      	je	0x7361 <perf_unwind_v8+0x7361>
    72ec:      	andl	$0x1, %r12d
    72f0:      	jne	0x7361 <perf_unwind_v8+0x7361>
    72f2:      	movq	(%rip), %rax            # 0x72f9 <perf_unwind_v8+0x72f9>
    72f9:      	cmpl	$0x0, (%rax)
    72fc:      	je	0x734b <perf_unwind_v8+0x734b>
    72fe:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    7308:      	movq	%rax, 0x10(%rsp)
    730d:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    7317:      	movq	%rax, 0x8(%rsp)
    731c:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    7326:      	movq	%rax, (%rsp)
    732a:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    7332:      	movq	%rsp, %rdi
    7335:      	movl	$0x1c, %eax
    733a:      	movl	$0x6, %ecx
    733f:      	movl	$0x1c, %esi
    7344:      	movq	%rbp, %rdx
    7347:      	xorl	%eax, %eax
    7349:      	callq	*%rcx
    734b:      	movq	0x58(%rsp), %r15
    7350:      	orq	$0x1, %r15
    7354:      	movq	%r15, 0x90(%rsp)
    735c:      	jmp	0x78bb <perf_unwind_v8+0x78bb>
    7361:      	movq	0x48(%rsp), %rax
    7366:      	movzbl	0xe(%rax), %edx
    736a:      	addq	0x68(%rsp), %rdx
    736f:      	movq	%rsp, %rdi
    7372:      	movl	$0x8, %eax
    7377:      	movl	$0x70, %ecx
    737c:      	movl	$0x8, %esi
    7381:      	callq	*%rcx
    7383:      	testq	%rax, %rax
    7386:      	jne	0x7417 <perf_unwind_v8+0x7417>
    738c:      	movq	(%rsp), %rcx
    7390:      	movq	%rcx, %rax
    7393:      	movq	%rcx, 0x50(%rsp)
    7398:      	andl	$0x3, %eax
    739b:      	cmpl	$0x1, %eax
    739e:      	jne	0x7417 <perf_unwind_v8+0x7417>
    73a0:      	andq	$-0x4, 0x50(%rsp)
    73a6:      	je	0x7417 <perf_unwind_v8+0x7417>
    73a8:      	movq	0x48(%rsp), %rax
    73ad:      	movzbl	0xc(%rax), %edx
    73b1:      	addq	0x50(%rsp), %rdx
    73b6:      	movq	%rsp, %rdi
    73b9:      	movl	$0x8, %eax
    73be:      	movl	$0x70, %ecx
    73c3:      	movl	$0x8, %esi
    73c8:      	callq	*%rcx
    73ca:      	testq	%rax, %rax
    73cd:      	jne	0x741e <perf_unwind_v8+0x741e>
    73cf:      	movq	(%rsp), %rax
    73d3:      	movl	%eax, %ecx
    73d5:      	andl	$0x3, %ecx
    73d8:      	cmpl	$0x1, %ecx
    73db:      	jne	0x741e <perf_unwind_v8+0x741e>
    73dd:      	andq	$-0x4, %rax
    73e1:      	je	0x741e <perf_unwind_v8+0x741e>
    73e3:      	movq	0x48(%rsp), %rsi
    73e8:      	movzbl	0xd(%rsi), %ecx
    73ec:      	addq	%rax, %rcx
    73ef:      	movq	%rsp, %rdi
    73f2:      	movl	$0x2, %edx
    73f7:      	movl	$0x70, %r8d
    73fd:      	movzbl	0xd(%rsi), %edx
    7401:      	addq	%rax, %rdx
    7404:      	movl	$0x2, %esi
    7409:      	callq	*%r8
    740c:      	testq	%rax, %rax
    740f:      	jne	0x741e <perf_unwind_v8+0x741e>
    7411:      	movzwl	(%rsp), %eax
    7415:      	jmp	0x7420 <perf_unwind_v8+0x7420>
    7417:      	xorl	%eax, %eax
    7419:      	movq	%rax, 0x50(%rsp)
    741e:      	xorl	%eax, %eax
    7420:      	movq	0x58(%rsp), %rcx
    7425:      	orq	$0x2, %rcx
    7429:      	movq	%rcx, 0x90(%rsp)
    7431:      	movq	0x48(%rsp), %rcx
    7436:      	cmpw	0x8(%rcx), %ax
    743a:      	jne	0x7506 <perf_unwind_v8+0x7506>
    7440:      	movl	$0x60, %eax
    7445:      	movl	$0x70, %ecx
    744a:      	movq	0xb0(%rsp), %rdi
    7452:      	movq	0x50(%rsp), %rdx
    7457:      	movl	$0x60, %esi
    745c:      	callq	*%rcx
    745e:      	testq	%rax, %rax
    7461:      	je	0x75bb <perf_unwind_v8+0x75bb>
    7467:      	movl	$0x3b, 0x70(%rsp)
    746f:      	movq	(%rip), %rdi            # 0x7476 <perf_unwind_v8+0x7476>
    7476:      	leaq	0x70(%rsp), %rsi
    747b:      	movl	$0x1, %eax
    7480:      	callq	*%rax
    7482:      	testq	%rax, %rax
    7485:      	jne	0x75b1 <perf_unwind_v8+0x75b1>
    748b:      	movq	(%rip), %rax            # 0x7492 <perf_unwind_v8+0x7492>
    7492:      	cmpl	$0x0, (%rax)
    7495:      	je	0x7687 <perf_unwind_v8+0x7687>
    749b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    74a5:      	movq	%rax, 0x26(%rsp)
    74aa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    74b4:      	movq	%rax, 0x20(%rsp)
    74b9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    74c3:      	movq	%rax, 0x18(%rsp)
    74c8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    74d2:      	movq	%rax, 0x10(%rsp)
    74d7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    74e1:      	movq	%rax, 0x8(%rsp)
    74e6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    74f0:      	movq	%rax, (%rsp)
    74f4:      	movq	%rsp, %rdi
    74f7:      	movl	$0x2e, %eax
    74fc:      	movl	$0x6, %ecx
    7501:      	jmp	0x767a <perf_unwind_v8+0x767a>
    7506:      	movq	(%rip), %rcx            # 0x750d <perf_unwind_v8+0x750d>
    750d:      	cmpl	$0x0, (%rcx)
    7510:      	je	0x7591 <perf_unwind_v8+0x7591>
    7512:      	movzwl	%ax, %r8d
    7516:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    7520:      	movq	%rax, 0x26(%rsp)
    7525:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    752f:      	movq	%rax, 0x20(%rsp)
    7534:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    753e:      	movq	%rax, 0x18(%rsp)
    7543:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    754d:      	movq	%rax, 0x10(%rsp)
    7552:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    755c:      	movq	%rax, 0x8(%rsp)
    7561:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    756b:      	movq	%rax, (%rsp)
    756f:      	movq	%rsp, %rdi
    7572:      	movl	$0x2e, %eax
    7577:      	movl	$0x6, %r9d
    757d:      	movl	$0x2e, %esi
    7582:      	movq	0x68(%rsp), %rdx
    7587:      	movq	0x50(%rsp), %rcx
    758c:      	xorl	%eax, %eax
    758e:      	callq	*%r9
    7591:      	movl	$0x3b, 0x70(%rsp)
    7599:      	movq	(%rip), %rdi            # 0x75a0 <perf_unwind_v8+0x75a0>
    75a0:      	leaq	0x70(%rsp), %rsi
    75a5:      	movl	$0x1, %eax
    75aa:      	callq	*%rax
    75ac:      	testq	%rax, %rax
    75af:      	je	0x7608 <perf_unwind_v8+0x7608>
    75b1:      	incq	(%rax)
    75b4:      	xorl	%ebp, %ebp
    75b6:      	jmp	0x78bb <perf_unwind_v8+0x78bb>
    75bb:      	movq	0x48(%rsp), %rax
    75c0:      	movzbl	0x12(%rax), %ecx
    75c4:      	xorl	%ebp, %ebp
    75c6:      	cmpq	$0x5c, %rcx
    75ca:      	ja	0x220 <perf_unwind_v8+0x220>
    75d0:      	movq	0x48(%rsp), %rax
    75d5:      	movzbl	0x13(%rax), %eax
    75d9:      	cmpq	$0x5c, %rax
    75dd:      	ja	0x220 <perf_unwind_v8+0x220>
    75e3:      	movq	0x48(%rsp), %rdx
    75e8:      	cmpb	$0x0, 0x10(%rdx)
    75ec:      	movzbl	0x11(%rdx), %r12d
    75f1:      	je	0x768e <perf_unwind_v8+0x768e>
    75f7:      	movq	0xb0(%rsp), %rdx
    75ff:      	movq	(%rdx,%r12), %r12
    7603:      	jmp	0x7693 <perf_unwind_v8+0x7693>
    7608:      	movq	(%rip), %rax            # 0x760f <perf_unwind_v8+0x760f>
    760f:      	cmpl	$0x0, (%rax)
    7612:      	je	0x7687 <perf_unwind_v8+0x7687>
    7614:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    761e:      	movq	%rax, 0x26(%rsp)
    7623:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    762d:      	movq	%rax, 0x20(%rsp)
    7632:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    763c:      	movq	%rax, 0x18(%rsp)
    7641:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    764b:      	movq	%rax, 0x10(%rsp)
    7650:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    765a:      	movq	%rax, 0x8(%rsp)
    765f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7669:      	movq	%rax, (%rsp)
    766d:      	movq	%rsp, %rdi
    7670:      	movl	$0x2e, %eax
    7675:      	movl	$0x6, %ecx
    767a:      	movl	0x70(%rsp), %edx
    767e:      	movl	$0x2e, %esi
    7683:      	xorl	%eax, %eax
    7685:      	callq	*%rcx
    7687:      	xorl	%ebp, %ebp
    7689:      	jmp	0x78bb <perf_unwind_v8+0x78bb>
    768e:      	addq	0x50(%rsp), %r12
    7693:      	movq	0xb0(%rsp), %rdx
    769b:      	movl	(%rdx,%rcx), %r13d
    769f:      	movq	0x48(%rsp), %rcx
    76a4:      	movzbl	0x17(%rcx), %esi
    76a8:      	movl	%esi, 0xac(%rsp)
    76af:      	movzbl	0x18(%rcx), %r15d
    76b4:      	movq	%r13, %rcx
    76b7:      	addq	%r12, %rcx
    76ba:      	movq	%rcx, 0xb8(%rsp)
    76c2:      	andl	(%rdx,%rax), %r15d
    76c6:      	movq	(%rip), %rax            # 0x76cd <perf_unwind_v8+0x76cd>
    76cd:      	cmpl	$0x0, (%rax)
    76d0:      	je	0x77c8 <perf_unwind_v8+0x77c8>
    76d6:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    76e0:      	movq	%rax, 0x20(%rsp)
    76e5:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    76ef:      	movq	%rax, 0x18(%rsp)
    76f4:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    76fe:      	movq	%rax, 0x10(%rsp)
    7703:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    770d:      	movq	%rax, 0x8(%rsp)
    7712:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    771c:      	movq	%rax, (%rsp)
    7720:      	movb	$0x0, 0x28(%rsp)
    7725:      	movq	%rsp, %rdi
    7728:      	movl	$0x29, %eax
    772d:      	movl	$0x6, %r9d
    7733:      	movl	$0x29, %esi
    7738:      	movq	0x68(%rsp), %rdx
    773d:      	movq	0x58(%rsp), %rcx
    7742:      	movq	0x50(%rsp), %r8
    7747:      	xorl	%eax, %eax
    7749:      	callq	*%r9
    774c:      	movq	(%rip), %rax            # 0x7753 <perf_unwind_v8+0x7753>
    7753:      	cmpl	$0x0, (%rax)
    7756:      	je	0x77c8 <perf_unwind_v8+0x77c8>
    7758:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    7762:      	movq	%rax, 0x1d(%rsp)
    7767:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    7771:      	movq	%rax, 0x18(%rsp)
    7776:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    7780:      	movq	%rax, 0x10(%rsp)
    7785:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    778f:      	movq	%rax, 0x8(%rsp)
    7794:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    779e:      	movq	%rax, (%rsp)
    77a2:      	movq	%rsp, %rdi
    77a5:      	movl	$0x25, %eax
    77aa:      	movl	$0x6, %r9d
    77b0:      	movl	$0x25, %esi
    77b5:      	movq	%r12, %rdx
    77b8:      	movq	0xb8(%rsp), %rcx
    77c0:      	movl	%r13d, %r8d
    77c3:      	xorl	%eax, %eax
    77c5:      	callq	*%r9
    77c8:      	movq	0xa0(%rsp), %rbp
    77d0:      	subq	%r12, %rbp
    77d3:      	jb	0x782f <perf_unwind_v8+0x782f>
    77d5:      	movq	0xb8(%rsp), %rax
    77dd:      	cmpq	%rax, 0xa0(%rsp)
    77e5:      	jae	0x782f <perf_unwind_v8+0x782f>
    77e7:      	movl	0xac(%rsp), %eax
    77ee:      	shrxl	%eax, %r15d, %eax
    77f3:      	movq	0x48(%rsp), %rcx
    77f8:      	movzbl	0x19(%rcx), %ecx
    77fc:      	movq	0x68(%rsp), %r15
    7801:      	orq	$0x4, %r15
    7805:      	movq	0x50(%rsp), %rdx
    780a:      	orq	$0x3, %rdx
    780e:      	cmpl	%ecx, %eax
    7810:      	cmoveq	%r15, %rdx
    7814:      	shll	$0x4, %r13d
    7818:      	orl	%eax, %r13d
    781b:      	shlq	$0x20, %r13
    781f:      	orq	%r13, %rbp
    7822:      	movq	%rdx, 0x90(%rsp)
    782a:      	jmp	0x78bb <perf_unwind_v8+0x78bb>
    782f:      	movq	(%rip), %rax            # 0x7836 <perf_unwind_v8+0x7836>
    7836:      	cmpl	$0x0, (%rax)
    7839:      	jne	0x784a <perf_unwind_v8+0x784a>
    783b:      	xorl	%ebp, %ebp
    783d:      	movzbl	0xf30(%r14), %r12d
    7845:      	jmp	0x7966 <perf_unwind_v8+0x7966>
    784a:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    7854:      	movq	%rax, 0x28(%rsp)
    7859:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    7863:      	movq	%rax, 0x20(%rsp)
    7868:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    7872:      	movq	%rax, 0x18(%rsp)
    7877:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    7881:      	movq	%rax, 0x10(%rsp)
    7886:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    7890:      	movq	%rax, 0x8(%rsp)
    7895:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    789f:      	movq	%rax, (%rsp)
    78a3:      	movq	%rsp, %rdi
    78a6:      	movl	$0x30, %eax
    78ab:      	movl	$0x6, %ecx
    78b0:      	xorl	%ebp, %ebp
    78b2:      	movl	$0x30, %esi
    78b7:      	xorl	%eax, %eax
    78b9:      	callq	*%rcx
    78bb:      	movzbl	0xf30(%r14), %r12d
    78c3:      	movq	(%rip), %rax            # 0x78ca <perf_unwind_v8+0x78ca>
    78ca:      	cmpl	$0x0, (%rax)
    78cd:      	je	0x7966 <perf_unwind_v8+0x7966>
    78d3:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    78dd:      	movq	%rax, 0x30(%rsp)
    78e2:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    78ec:      	movq	%rax, 0x28(%rsp)
    78f1:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    78fb:      	movq	%rax, 0x20(%rsp)
    7900:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    790a:      	movq	%rax, 0x18(%rsp)
    790f:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    7919:      	movq	%rax, 0x10(%rsp)
    791e:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    7928:      	movq	%rax, 0x8(%rsp)
    792d:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    7937:      	movq	%rax, (%rsp)
    793b:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    7943:      	movq	%rsp, %rdi
    7946:      	movl	$0x3c, %eax
    794b:      	movl	$0x6, %r8d
    7951:      	movl	$0x3c, %esi
    7956:      	movq	%rbp, %rdx
    7959:      	movq	0x90(%rsp), %rcx
    7961:      	xorl	%eax, %eax
    7963:      	callq	*%r8
    7966:      	movl	0x2c0(%r14), %eax
    796d:      	cmpq	$0x7e, %rax
    7971:      	ja	0x27d <perf_unwind_v8+0x27d>
    7977:      	leal	0x1(%rax), %ecx
    797a:      	movl	%ecx, 0x2c0(%r14)
    7981:      	leaq	(%rax,%rax,2), %rax
    7985:      	movq	0x90(%rsp), %rcx
    798d:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    7995:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    799d:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    79a6:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    79ae:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    79ba:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    79c5:      	movq	0xee0(%r14), %rax
    79cc:      	movq	%rsp, %rdi
    79cf:      	movl	$0x10, %ecx
    79d4:      	movl	$0x70, %r8d
    79da:      	movq	0xee0(%r14), %rdx
    79e1:      	movl	$0x10, %esi
    79e6:      	callq	*%r8
    79e9:      	testq	%rax, %rax
    79ec:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    79f2:      	movq	0xee0(%r14), %rax
    79f9:      	addq	$0x10, %rax
    79fd:      	movq	%rax, 0xed8(%r14)
    7a04:      	movq	(%rsp), %rax
    7a08:      	movq	%rax, 0xee0(%r14)
    7a0f:      	movq	0x8(%rsp), %rax
    7a14:      	movq	%rax, 0xed0(%r14)
    7a1b:      	movb	$0x1, 0xf30(%r14)
    7a23:      	movq	(%rip), %rax            # 0x7a2a <perf_unwind_v8+0x7a2a>
    7a2a:      	cmpl	$0x0, (%rax)
    7a2d:      	je	0x7a97 <perf_unwind_v8+0x7a97>
    7a2f:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    7a39:      	movq	%rax, 0x17(%rsp)
    7a3e:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    7a48:      	movq	%rax, 0x10(%rsp)
    7a4d:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    7a57:      	movq	%rax, 0x8(%rsp)
    7a5c:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    7a66:      	movq	%rax, (%rsp)
    7a6a:      	movq	%rsp, %rdi
    7a6d:      	movl	$0x1f, %eax
    7a72:      	movl	$0x6, %r9d
    7a78:      	movq	0xed0(%r14), %rdx
    7a7f:      	movq	0xed8(%r14), %rcx
    7a86:      	movq	0xee0(%r14), %r8
    7a8d:      	movl	$0x1f, %esi
    7a92:      	xorl	%eax, %eax
    7a94:      	callq	*%r9
    7a97:      	movl	$0x38, 0x70(%rsp)
    7a9f:      	movq	(%rip), %rdi            # 0x7aa6 <perf_unwind_v8+0x7aa6>
    7aa6:      	leaq	0x70(%rsp), %rsi
    7aab:      	movl	$0x1, %eax
    7ab0:      	callq	*%rax
    7ab2:      	testq	%rax, %rax
    7ab5:      	je	0x7abf <perf_unwind_v8+0x7abf>
    7ab7:      	incq	(%rax)
    7aba:      	jmp	0x7b40 <perf_unwind_v8+0x7b40>
    7abf:      	xorl	%eax, %eax
    7ac1:      	movq	(%rip), %rcx            # 0x7ac8 <perf_unwind_v8+0x7ac8>
    7ac8:      	cmpl	$0x0, (%rcx)
    7acb:      	je	0x7b49 <perf_unwind_v8+0x7b49>
    7acd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7ad7:      	movq	%rax, 0x26(%rsp)
    7adc:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7ae6:      	movq	%rax, 0x20(%rsp)
    7aeb:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7af5:      	movq	%rax, 0x18(%rsp)
    7afa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7b04:      	movq	%rax, 0x10(%rsp)
    7b09:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7b13:      	movq	%rax, 0x8(%rsp)
    7b18:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7b22:      	movq	%rax, (%rsp)
    7b26:      	movq	%rsp, %rdi
    7b29:      	movl	$0x2e, %eax
    7b2e:      	movl	$0x6, %ecx
    7b33:      	movl	0x70(%rsp), %edx
    7b37:      	movl	$0x2e, %esi
    7b3c:      	xorl	%eax, %eax
    7b3e:      	callq	*%rcx
    7b40:      	movq	(%rip), %rax            # 0x7b47 <perf_unwind_v8+0x7b47>
    7b47:      	movl	(%rax), %eax
    7b49:      	movq	0xed0(%r14), %r12
    7b50:      	testq	%r12, %r12
    7b53:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    7b59:      	testl	%eax, %eax
    7b5b:      	je	0x7be3 <perf_unwind_v8+0x7be3>
    7b61:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    7b6b:      	movq	%rax, 0x28(%rsp)
    7b70:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    7b7a:      	movq	%rax, 0x20(%rsp)
    7b7f:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    7b89:      	movq	%rax, 0x18(%rsp)
    7b8e:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    7b98:      	movq	%rax, 0x10(%rsp)
    7b9d:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    7ba7:      	movq	%rax, 0x8(%rsp)
    7bac:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    7bb6:      	movq	%rax, (%rsp)
    7bba:      	movb	$0x0, 0x30(%rsp)
    7bbf:      	movq	%rsp, %rdi
    7bc2:      	movl	$0x31, %eax
    7bc7:      	movl	$0x6, %ecx
    7bcc:      	movl	0x2c0(%r14), %edx
    7bd3:      	movl	$0x31, %esi
    7bd8:      	xorl	%eax, %eax
    7bda:      	callq	*%rcx
    7bdc:      	movq	0xed0(%r14), %r12
    7be3:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    7bed:      	cmpq	%rax, %r12
    7bf0:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    7bf6:      	cmpq	$0x1000, %r12           # imm = 0x1000
    7bfd:      	jb	0x285e <perf_unwind_v8+0x285e>
    7c03:      	movl	(%r14), %eax
    7c06:      	movl	$0x60, 0x70(%rsp)
    7c0e:      	movbel	%eax, 0x74(%rsp)
    7c14:      	movbeq	%r12, 0x78(%rsp)
    7c1b:      	movq	(%rip), %rdi            # 0x7c22 <perf_unwind_v8+0x7c22>
    7c22:      	leaq	0x70(%rsp), %rsi
    7c27:      	movl	$0x1, %eax
    7c2c:      	callq	*%rax
    7c2e:      	testq	%rax, %rax
    7c31:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    7c37:      	movq	0x8(%rax), %rbp
    7c3b:      	movq	%rbp, %rcx
    7c3e:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    7c48:      	andq	%rdx, %rcx
    7c4b:      	movq	%rcx, 0xf20(%r14)
    7c52:      	movq	(%rax), %rax
    7c55:      	movq	%rax, 0xf10(%r14)
    7c5c:      	shrq	$0x38, %rbp
    7c60:      	movq	%r12, %rax
    7c63:      	subq	%rcx, %rax
    7c66:      	movq	%rax, 0xf18(%r14)
    7c6d:      	movq	(%rip), %rax            # 0x7c74 <perf_unwind_v8+0x7c74>
    7c74:      	cmpl	$0x0, (%rax)
    7c77:      	je	0x7d83 <perf_unwind_v8+0x7d83>
    7c7d:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    7c87:      	movq	%rax, 0x28(%rsp)
    7c8c:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    7c96:      	movq	%rax, 0x20(%rsp)
    7c9b:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    7ca5:      	movq	%rax, 0x18(%rsp)
    7caa:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    7cb4:      	movq	%rax, 0x10(%rsp)
    7cb9:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    7cc3:      	movq	%rax, 0x8(%rsp)
    7cc8:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    7cd2:      	movq	%r13, (%rsp)
    7cd6:      	movw	$0xa, 0x30(%rsp)
    7cdd:      	movq	%rsp, %rdi
    7ce0:      	movl	$0x32, %eax
    7ce5:      	movl	$0x6, %r9d
    7ceb:      	movq	0xf10(%r14), %rcx
    7cf2:      	movl	$0x32, %esi
    7cf7:      	movq	%r12, %rdx
    7cfa:      	movl	%ebp, %r8d
    7cfd:      	xorl	%eax, %eax
    7cff:      	callq	*%r9
    7d02:      	movq	(%rip), %rax            # 0x7d09 <perf_unwind_v8+0x7d09>
    7d09:      	cmpl	$0x0, (%rax)
    7d0c:      	je	0x7d83 <perf_unwind_v8+0x7d83>
    7d0e:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    7d18:      	movq	%rax, 0x27(%rsp)
    7d1d:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    7d27:      	movq	%rax, 0x20(%rsp)
    7d2c:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    7d36:      	movq	%rax, 0x18(%rsp)
    7d3b:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    7d45:      	movq	%rax, 0x10(%rsp)
    7d4a:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    7d54:      	movq	%rax, 0x8(%rsp)
    7d59:      	movq	%r13, (%rsp)
    7d5d:      	movq	%rsp, %rdi
    7d60:      	movl	$0x2f, %eax
    7d65:      	movl	$0x6, %r8d
    7d6b:      	movq	0xf18(%r14), %rcx
    7d72:      	movq	0xf20(%r14), %rdx
    7d79:      	movl	$0x2f, %esi
    7d7e:      	xorl	%eax, %eax
    7d80:      	callq	*%r8
    7d83:      	cmpl	$0x1, %ebp
    7d86:      	jne	0x7f62 <perf_unwind_v8+0x7f62>
    7d8c:      	movq	0xf10(%r14), %rax
    7d93:      	movq	%rax, 0x70(%rsp)
    7d98:      	movq	0xf18(%r14), %r13
    7d9f:      	movq	(%rip), %rdi            # 0x7da6 <perf_unwind_v8+0x7da6>
    7da6:      	leaq	0x70(%rsp), %rsi
    7dab:      	movl	$0x1, %eax
    7db0:      	callq	*%rax
    7db2:      	movl	$0x1, %ebp
    7db7:      	testq	%rax, %rax
    7dba:      	je	0x7f62 <perf_unwind_v8+0x7f62>
    7dc0:      	movq	%rax, %r12
    7dc3:      	cmpq	%r13, (%rax)
    7dc6:      	ja	0x7dcf <perf_unwind_v8+0x7dcf>
    7dc8:      	cmpq	%r13, 0x8(%r12)
    7dcd:      	jae	0x7de5 <perf_unwind_v8+0x7de5>
    7dcf:      	cmpq	%r13, 0x10(%r12)
    7dd4:      	ja	0x7f62 <perf_unwind_v8+0x7f62>
    7dda:      	cmpq	%r13, 0x18(%r12)
    7ddf:      	jb	0x7f62 <perf_unwind_v8+0x7f62>
    7de5:      	movq	(%rip), %rax            # 0x7dec <perf_unwind_v8+0x7dec>
    7dec:      	cmpl	$0x0, (%rax)
    7def:      	je	0x7e48 <perf_unwind_v8+0x7e48>
    7df1:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    7dfb:      	movq	%rax, 0x16(%rsp)
    7e00:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    7e0a:      	movq	%rax, 0x10(%rsp)
    7e0f:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    7e19:      	movq	%rax, 0x8(%rsp)
    7e1e:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    7e28:      	movq	%rax, (%rsp)
    7e2c:      	movq	%rsp, %rdi
    7e2f:      	movl	$0x1e, %eax
    7e34:      	movl	$0x6, %ecx
    7e39:      	movzwl	0x20(%r12), %edx
    7e3f:      	movl	$0x1e, %esi
    7e44:      	xorl	%eax, %eax
    7e46:      	callq	*%rcx
    7e48:      	movl	0x1380(%r14), %eax
    7e4f:      	movl	0x20(%r12), %ecx
    7e54:      	btl	%ecx, %eax
    7e57:      	jae	0x7eb8 <perf_unwind_v8+0x7eb8>
    7e59:      	movq	(%rip), %rax            # 0x7e60 <perf_unwind_v8+0x7e60>
    7e60:      	cmpl	$0x0, (%rax)
    7e63:      	je	0x7f62 <perf_unwind_v8+0x7f62>
    7e69:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    7e73:      	movq	%rax, 0x10(%rsp)
    7e78:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    7e82:      	movq	%rax, 0x8(%rsp)
    7e87:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    7e91:      	movq	%rax, (%rsp)
    7e95:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    7e9d:      	movq	%rsp, %rdi
    7ea0:      	movl	$0x1b, %eax
    7ea5:      	movl	$0x6, %ecx
    7eaa:      	movl	$0x1b, %esi
    7eaf:      	xorl	%eax, %eax
    7eb1:      	callq	*%rcx
    7eb3:      	jmp	0x7f62 <perf_unwind_v8+0x7f62>
    7eb8:      	movl	$0x0, 0x64(%rsp)
    7ec0:      	movq	(%rip), %rdi            # 0x7ec7 <perf_unwind_v8+0x7ec7>
    7ec7:      	leaq	0x64(%rsp), %rsi
    7ecc:      	movl	$0x1, %eax
    7ed1:      	callq	*%rax
    7ed3:      	testq	%rax, %rax
    7ed6:      	je	0x7edd <perf_unwind_v8+0x7edd>
    7ed8:      	incq	(%rax)
    7edb:      	jmp	0x7f5c <perf_unwind_v8+0x7f5c>
    7edd:      	movq	(%rip), %rax            # 0x7ee4 <perf_unwind_v8+0x7ee4>
    7ee4:      	cmpl	$0x0, (%rax)
    7ee7:      	je	0x7f5c <perf_unwind_v8+0x7f5c>
    7ee9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7ef3:      	movq	%rax, 0x26(%rsp)
    7ef8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7f02:      	movq	%rax, 0x20(%rsp)
    7f07:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7f11:      	movq	%rax, 0x18(%rsp)
    7f16:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7f20:      	movq	%rax, 0x10(%rsp)
    7f25:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7f2f:      	movq	%rax, 0x8(%rsp)
    7f34:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7f3e:      	movq	%rax, (%rsp)
    7f42:      	movq	%rsp, %rdi
    7f45:      	movl	$0x2e, %eax
    7f4a:      	movl	$0x6, %ecx
    7f4f:      	movl	0x64(%rsp), %edx
    7f53:      	movl	$0x2e, %esi
    7f58:      	xorl	%eax, %eax
    7f5a:      	callq	*%rcx
    7f5c:      	movzwl	0x20(%r12), %ebp
    7f62:      	xorl	%r12d, %r12d
    7f65:      	cmpl	$0x7, %ebp
    7f68:      	jne	0x2070 <perf_unwind_v8+0x2070>
    7f6e:      	movq	0xed0(%r14), %rax
    7f75:      	movq	%rax, 0x68(%rsp)
    7f7a:      	movq	0xed8(%r14), %r12
    7f81:      	movq	0xee0(%r14), %r13
    7f88:      	movq	(%rip), %rax            # 0x7f8f <perf_unwind_v8+0x7f8f>
    7f8f:      	cmpl	$0x0, (%rax)
    7f92:      	je	0x7ff2 <perf_unwind_v8+0x7ff2>
    7f94:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    7f9e:      	movq	%rax, 0x17(%rsp)
    7fa3:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    7fad:      	movq	%rax, 0x10(%rsp)
    7fb2:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    7fbc:      	movq	%rax, 0x8(%rsp)
    7fc1:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    7fcb:      	movq	%rax, (%rsp)
    7fcf:      	movq	%rsp, %rdi
    7fd2:      	movl	$0x1f, %eax
    7fd7:      	movl	$0x6, %r9d
    7fdd:      	movl	$0x1f, %esi
    7fe2:      	movq	0x68(%rsp), %rdx
    7fe7:      	movq	%r12, %rcx
    7fea:      	movq	%r13, %r8
    7fed:      	xorl	%eax, %eax
    7fef:      	callq	*%r9
    7ff2:      	cmpq	%r12, %r13
    7ff5:      	jb	0x80b0 <perf_unwind_v8+0x80b0>
    7ffb:      	leaq	0x2000(%r12), %rax
    8003:      	cmpq	%rax, %r13
    8006:      	jae	0x80b0 <perf_unwind_v8+0x80b0>
    800c:      	addq	$-0x40, %r13
    8010:      	movl	$0x40, %eax
    8015:      	movl	$0x70, %ecx
    801a:      	movq	0x98(%rsp), %rdi
    8022:      	movl	$0x40, %esi
    8027:      	movq	%r13, %rdx
    802a:      	callq	*%rcx
    802c:      	testq	%rax, %rax
    802f:      	movq	(%rip), %rbp            # 0x8036 <perf_unwind_v8+0x8036>
    8036:      	jne	0x138 <perf_unwind_v8+0x138>
    803c:      	movq	0x48(%rsp), %rax
    8041:      	movzbl	0x14(%rax), %ecx
    8045:      	xorl	%ebp, %ebp
    8047:      	cmpq	$0x38, %rcx
    804b:      	ja	0x220 <perf_unwind_v8+0x220>
    8051:      	movq	0x48(%rsp), %rax
    8056:      	movzbl	0x15(%rax), %eax
    805a:      	cmpq	$0x38, %rax
    805e:      	ja	0x220 <perf_unwind_v8+0x220>
    8064:      	movq	0x48(%rsp), %rdx
    8069:      	movzbl	0x16(%rdx), %edx
    806d:      	cmpq	$0x38, %rdx
    8071:      	ja	0x220 <perf_unwind_v8+0x220>
    8077:      	movq	0x98(%rsp), %rsi
    807f:      	movq	(%rsi,%rcx), %rbp
    8083:      	testb	$0x1, %bpl
    8087:      	jne	0x80b8 <perf_unwind_v8+0x80b8>
    8089:      	shrq	%rbp
    808c:      	movq	(%rip), %rax            # 0x8093 <perf_unwind_v8+0x8093>
    8093:      	cmpl	$0x0, (%rax)
    8096:      	jne	0x8243 <perf_unwind_v8+0x8243>
    809c:      	xorl	%eax, %eax
    809e:      	movq	%rax, 0x50(%rsp)
    80a3:      	movzbl	0xf30(%r14), %r15d
    80ab:      	jmp	0x892e <perf_unwind_v8+0x892e>
    80b0:      	movq	%r13, %rdx
    80b3:      	jmp	0x2028 <perf_unwind_v8+0x2028>
    80b8:      	movq	0x98(%rsp), %r15
    80c0:      	movq	(%r15,%rdx), %r12
    80c4:      	movq	(%r15,%rax), %rdx
    80c8:      	movl	%edx, %ecx
    80ca:      	andl	$0x3, %ecx
    80cd:      	andq	$-0x4, %rdx
    80d1:      	xorl	%eax, %eax
    80d3:      	cmpl	$0x1, %ecx
    80d6:      	cmovneq	%rax, %rdx
    80da:      	movq	%rdx, 0x58(%rsp)
    80df:      	testq	%rdx, %rdx
    80e2:      	je	0x8155 <perf_unwind_v8+0x8155>
    80e4:      	movq	0x48(%rsp), %rax
    80e9:      	movzbl	0xc(%rax), %edx
    80ed:      	addq	0x58(%rsp), %rdx
    80f2:      	movq	%rsp, %rdi
    80f5:      	movl	$0x8, %eax
    80fa:      	movl	$0x70, %ecx
    80ff:      	movl	$0x8, %esi
    8104:      	callq	*%rcx
    8106:      	testq	%rax, %rax
    8109:      	jne	0x8153 <perf_unwind_v8+0x8153>
    810b:      	movq	(%rsp), %rax
    810f:      	movl	%eax, %ecx
    8111:      	andl	$0x3, %ecx
    8114:      	cmpl	$0x1, %ecx
    8117:      	jne	0x8153 <perf_unwind_v8+0x8153>
    8119:      	andq	$-0x4, %rax
    811d:      	je	0x8153 <perf_unwind_v8+0x8153>
    811f:      	movq	0x48(%rsp), %rsi
    8124:      	movzbl	0xd(%rsi), %ecx
    8128:      	addq	%rax, %rcx
    812b:      	movq	%rsp, %rdi
    812e:      	movl	$0x2, %edx
    8133:      	movl	$0x70, %r8d
    8139:      	movzbl	0xd(%rsi), %edx
    813d:      	addq	%rax, %rdx
    8140:      	movl	$0x2, %esi
    8145:      	callq	*%r8
    8148:      	testq	%rax, %rax
    814b:      	jne	0x8153 <perf_unwind_v8+0x8153>
    814d:      	movzwl	(%rsp), %eax
    8151:      	jmp	0x8155 <perf_unwind_v8+0x8155>
    8153:      	xorl	%eax, %eax
    8155:      	movq	0x48(%rsp), %rcx
    815a:      	cmpw	0x4(%rcx), %ax
    815e:      	jb	0x1c5f <perf_unwind_v8+0x1c5f>
    8164:      	movq	0x48(%rsp), %r8
    8169:      	cmpw	0x6(%r8), %ax
    816e:      	ja	0x494 <perf_unwind_v8+0x494>
    8174:      	movzbl	0xf(%r8), %edx
    8179:      	addq	0x58(%rsp), %rdx
    817e:      	movq	%rsp, %rdi
    8181:      	movl	$0x8, %eax
    8186:      	movl	$0x70, %ecx
    818b:      	movl	$0x8, %esi
    8190:      	callq	*%rcx
    8192:      	testq	%rax, %rax
    8195:      	jne	0x82a3 <perf_unwind_v8+0x82a3>
    819b:      	movq	(%rsp), %rcx
    819f:      	movq	%rcx, %rax
    81a2:      	movq	%rcx, 0x98(%rsp)
    81aa:      	andl	$0x3, %eax
    81ad:      	cmpl	$0x1, %eax
    81b0:      	jne	0x82a3 <perf_unwind_v8+0x82a3>
    81b6:      	andq	$-0x4, 0x98(%rsp)
    81bf:      	je	0x82a3 <perf_unwind_v8+0x82a3>
    81c5:      	movq	0x48(%rsp), %rax
    81ca:      	movzbl	0xc(%rax), %edx
    81ce:      	addq	0x98(%rsp), %rdx
    81d6:      	movq	%rsp, %rdi
    81d9:      	movl	$0x8, %eax
    81de:      	movl	$0x70, %ecx
    81e3:      	movl	$0x8, %esi
    81e8:      	callq	*%rcx
    81ea:      	testq	%rax, %rax
    81ed:      	jne	0x82ad <perf_unwind_v8+0x82ad>
    81f3:      	movq	(%rsp), %rax
    81f7:      	movl	%eax, %ecx
    81f9:      	andl	$0x3, %ecx
    81fc:      	cmpl	$0x1, %ecx
    81ff:      	jne	0x82ad <perf_unwind_v8+0x82ad>
    8205:      	andq	$-0x4, %rax
    8209:      	je	0x82ad <perf_unwind_v8+0x82ad>
    820f:      	movq	0x48(%rsp), %rsi
    8214:      	movzbl	0xd(%rsi), %ecx
    8218:      	addq	%rax, %rcx
    821b:      	movq	%rsp, %rdi
    821e:      	movl	$0x2, %edx
    8223:      	movl	$0x70, %r8d
    8229:      	movzbl	0xd(%rsi), %edx
    822d:      	addq	%rax, %rdx
    8230:      	movl	$0x2, %esi
    8235:      	callq	*%r8
    8238:      	testq	%rax, %rax
    823b:      	jne	0x82ad <perf_unwind_v8+0x82ad>
    823d:      	movzwl	(%rsp), %eax
    8241:      	jmp	0x82af <perf_unwind_v8+0x82af>
    8243:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    824d:      	movq	%rax, 0x15(%rsp)
    8252:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    825c:      	movq	%rax, 0x10(%rsp)
    8261:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    826b:      	movq	%rax, 0x8(%rsp)
    8270:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    827a:      	movq	%rax, (%rsp)
    827e:      	movq	%rsp, %rdi
    8281:      	movl	$0x1d, %eax
    8286:      	movl	$0x6, %ecx
    828b:      	xorl	%eax, %eax
    828d:      	movq	%rax, 0x50(%rsp)
    8292:      	movl	$0x1d, %esi
    8297:      	movq	%rbp, %rdx
    829a:      	xorl	%eax, %eax
    829c:      	callq	*%rcx
    829e:      	jmp	0x8886 <perf_unwind_v8+0x8886>
    82a3:      	xorl	%eax, %eax
    82a5:      	movq	%rax, 0x98(%rsp)
    82ad:      	xorl	%eax, %eax
    82af:      	movq	0x48(%rsp), %rcx
    82b4:      	cmpw	0xa(%rcx), %ax
    82b8:      	jne	0x998 <perf_unwind_v8+0x998>
    82be:      	movq	%r12, %rbp
    82c1:      	shrq	$0x20, %rbp
    82c5:      	je	0x833c <perf_unwind_v8+0x833c>
    82c7:      	andl	$0x1, %r12d
    82cb:      	jne	0x833c <perf_unwind_v8+0x833c>
    82cd:      	movq	(%rip), %rax            # 0x82d4 <perf_unwind_v8+0x82d4>
    82d4:      	cmpl	$0x0, (%rax)
    82d7:      	je	0x8326 <perf_unwind_v8+0x8326>
    82d9:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    82e3:      	movq	%rax, 0x10(%rsp)
    82e8:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    82f2:      	movq	%rax, 0x8(%rsp)
    82f7:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    8301:      	movq	%rax, (%rsp)
    8305:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    830d:      	movq	%rsp, %rdi
    8310:      	movl	$0x1c, %eax
    8315:      	movl	$0x6, %ecx
    831a:      	movl	$0x1c, %esi
    831f:      	movq	%rbp, %rdx
    8322:      	xorl	%eax, %eax
    8324:      	callq	*%rcx
    8326:      	movq	0x98(%rsp), %rax
    832e:      	orq	$0x1, %rax
    8332:      	movq	%rax, 0x50(%rsp)
    8337:      	jmp	0x8886 <perf_unwind_v8+0x8886>
    833c:      	movq	0x48(%rsp), %rax
    8341:      	movzbl	0xe(%rax), %edx
    8345:      	addq	0x58(%rsp), %rdx
    834a:      	movq	%rsp, %rdi
    834d:      	movl	$0x8, %eax
    8352:      	movl	$0x70, %ecx
    8357:      	movl	$0x8, %esi
    835c:      	callq	*%rcx
    835e:      	testq	%rax, %rax
    8361:      	jne	0x83e9 <perf_unwind_v8+0x83e9>
    8367:      	movq	(%rsp), %rax
    836b:      	movq	%rax, %r15
    836e:      	andl	$0x3, %eax
    8371:      	cmpl	$0x1, %eax
    8374:      	jne	0x83e9 <perf_unwind_v8+0x83e9>
    8376:      	andq	$-0x4, %r15
    837a:      	je	0x83e9 <perf_unwind_v8+0x83e9>
    837c:      	movq	0x48(%rsp), %rax
    8381:      	movzbl	0xc(%rax), %edx
    8385:      	addq	%r15, %rdx
    8388:      	movq	%rsp, %rdi
    838b:      	movl	$0x8, %eax
    8390:      	movl	$0x70, %ecx
    8395:      	movl	$0x8, %esi
    839a:      	callq	*%rcx
    839c:      	testq	%rax, %rax
    839f:      	jne	0x83ec <perf_unwind_v8+0x83ec>
    83a1:      	movq	(%rsp), %rax
    83a5:      	movl	%eax, %ecx
    83a7:      	andl	$0x3, %ecx
    83aa:      	cmpl	$0x1, %ecx
    83ad:      	jne	0x83ec <perf_unwind_v8+0x83ec>
    83af:      	andq	$-0x4, %rax
    83b3:      	je	0x83ec <perf_unwind_v8+0x83ec>
    83b5:      	movq	0x48(%rsp), %rsi
    83ba:      	movzbl	0xd(%rsi), %ecx
    83be:      	addq	%rax, %rcx
    83c1:      	movq	%rsp, %rdi
    83c4:      	movl	$0x2, %edx
    83c9:      	movl	$0x70, %r8d
    83cf:      	movzbl	0xd(%rsi), %edx
    83d3:      	addq	%rax, %rdx
    83d6:      	movl	$0x2, %esi
    83db:      	callq	*%r8
    83de:      	testq	%rax, %rax
    83e1:      	jne	0x83ec <perf_unwind_v8+0x83ec>
    83e3:      	movzwl	(%rsp), %eax
    83e7:      	jmp	0x83ee <perf_unwind_v8+0x83ee>
    83e9:      	xorl	%r15d, %r15d
    83ec:      	xorl	%eax, %eax
    83ee:      	movq	0x98(%rsp), %rcx
    83f6:      	orq	$0x2, %rcx
    83fa:      	movq	%rcx, 0x50(%rsp)
    83ff:      	movq	0x48(%rsp), %rcx
    8404:      	cmpw	0x8(%rcx), %ax
    8408:      	jne	0x84d2 <perf_unwind_v8+0x84d2>
    840e:      	movl	$0x60, %eax
    8413:      	movl	$0x70, %ecx
    8418:      	movq	0xb0(%rsp), %rdi
    8420:      	movq	%r15, %rdx
    8423:      	movl	$0x60, %esi
    8428:      	callq	*%rcx
    842a:      	testq	%rax, %rax
    842d:      	je	0x8585 <perf_unwind_v8+0x8585>
    8433:      	movl	$0x3b, 0x70(%rsp)
    843b:      	movq	(%rip), %rdi            # 0x8442 <perf_unwind_v8+0x8442>
    8442:      	leaq	0x70(%rsp), %rsi
    8447:      	movl	$0x1, %eax
    844c:      	callq	*%rax
    844e:      	testq	%rax, %rax
    8451:      	jne	0x857b <perf_unwind_v8+0x857b>
    8457:      	movq	(%rip), %rax            # 0x845e <perf_unwind_v8+0x845e>
    845e:      	cmpl	$0x0, (%rax)
    8461:      	je	0x8657 <perf_unwind_v8+0x8657>
    8467:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8471:      	movq	%rax, 0x26(%rsp)
    8476:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8480:      	movq	%rax, 0x20(%rsp)
    8485:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    848f:      	movq	%rax, 0x18(%rsp)
    8494:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    849e:      	movq	%rax, 0x10(%rsp)
    84a3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    84ad:      	movq	%rax, 0x8(%rsp)
    84b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    84bc:      	movq	%rax, (%rsp)
    84c0:      	movq	%rsp, %rdi
    84c3:      	movl	$0x2e, %eax
    84c8:      	movl	$0x6, %ecx
    84cd:      	jmp	0x864a <perf_unwind_v8+0x864a>
    84d2:      	movq	(%rip), %rcx            # 0x84d9 <perf_unwind_v8+0x84d9>
    84d9:      	cmpl	$0x0, (%rcx)
    84dc:      	je	0x855b <perf_unwind_v8+0x855b>
    84de:      	movzwl	%ax, %r8d
    84e2:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    84ec:      	movq	%rax, 0x26(%rsp)
    84f1:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    84fb:      	movq	%rax, 0x20(%rsp)
    8500:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    850a:      	movq	%rax, 0x18(%rsp)
    850f:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    8519:      	movq	%rax, 0x10(%rsp)
    851e:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    8528:      	movq	%rax, 0x8(%rsp)
    852d:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    8537:      	movq	%rax, (%rsp)
    853b:      	movq	%rsp, %rdi
    853e:      	movl	$0x2e, %eax
    8543:      	movl	$0x6, %r9d
    8549:      	movl	$0x2e, %esi
    854e:      	movq	0x58(%rsp), %rdx
    8553:      	movq	%r15, %rcx
    8556:      	xorl	%eax, %eax
    8558:      	callq	*%r9
    855b:      	movl	$0x3b, 0x70(%rsp)
    8563:      	movq	(%rip), %rdi            # 0x856a <perf_unwind_v8+0x856a>
    856a:      	leaq	0x70(%rsp), %rsi
    856f:      	movl	$0x1, %eax
    8574:      	callq	*%rax
    8576:      	testq	%rax, %rax
    8579:      	je	0x85d8 <perf_unwind_v8+0x85d8>
    857b:      	incq	(%rax)
    857e:      	xorl	%ebp, %ebp
    8580:      	jmp	0x8886 <perf_unwind_v8+0x8886>
    8585:      	movq	0x48(%rsp), %rax
    858a:      	movzbl	0x12(%rax), %ecx
    858e:      	xorl	%ebp, %ebp
    8590:      	cmpq	$0x5c, %rcx
    8594:      	ja	0x220 <perf_unwind_v8+0x220>
    859a:      	movq	0x48(%rsp), %rax
    859f:      	movzbl	0x13(%rax), %eax
    85a3:      	movl	$0x1, %r12d
    85a9:      	cmpq	$0x5c, %rax
    85ad:      	ja	0x2070 <perf_unwind_v8+0x2070>
    85b3:      	movq	0x48(%rsp), %rdx
    85b8:      	cmpb	$0x0, 0x10(%rdx)
    85bc:      	movzbl	0x11(%rdx), %r12d
    85c1:      	je	0x865e <perf_unwind_v8+0x865e>
    85c7:      	movq	0xb0(%rsp), %rdx
    85cf:      	movq	(%rdx,%r12), %r12
    85d3:      	jmp	0x8661 <perf_unwind_v8+0x8661>
    85d8:      	movq	(%rip), %rax            # 0x85df <perf_unwind_v8+0x85df>
    85df:      	cmpl	$0x0, (%rax)
    85e2:      	je	0x8657 <perf_unwind_v8+0x8657>
    85e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    85ee:      	movq	%rax, 0x26(%rsp)
    85f3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    85fd:      	movq	%rax, 0x20(%rsp)
    8602:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    860c:      	movq	%rax, 0x18(%rsp)
    8611:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    861b:      	movq	%rax, 0x10(%rsp)
    8620:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    862a:      	movq	%rax, 0x8(%rsp)
    862f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8639:      	movq	%rax, (%rsp)
    863d:      	movq	%rsp, %rdi
    8640:      	movl	$0x2e, %eax
    8645:      	movl	$0x6, %ecx
    864a:      	movl	0x70(%rsp), %edx
    864e:      	movl	$0x2e, %esi
    8653:      	xorl	%eax, %eax
    8655:      	callq	*%rcx
    8657:      	xorl	%ebp, %ebp
    8659:      	jmp	0x8886 <perf_unwind_v8+0x8886>
    865e:      	addq	%r15, %r12
    8661:      	movq	0xb0(%rsp), %rdx
    8669:      	movl	(%rdx,%rcx), %r13d
    866d:      	movq	0x48(%rsp), %rcx
    8672:      	movzbl	0x17(%rcx), %esi
    8676:      	movl	%esi, 0xa0(%rsp)
    867d:      	movzbl	0x18(%rcx), %ecx
    8681:      	movq	%r13, %rsi
    8684:      	addq	%r12, %rsi
    8687:      	movq	%rsi, 0x90(%rsp)
    868f:      	andl	(%rdx,%rax), %ecx
    8692:      	movl	%ecx, 0xb0(%rsp)
    8699:      	movq	(%rip), %rax            # 0x86a0 <perf_unwind_v8+0x86a0>
    86a0:      	cmpl	$0x0, (%rax)
    86a3:      	je	0x879c <perf_unwind_v8+0x879c>
    86a9:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    86b3:      	movq	%rax, 0x20(%rsp)
    86b8:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    86c2:      	movq	%rax, 0x18(%rsp)
    86c7:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    86d1:      	movq	%rax, 0x10(%rsp)
    86d6:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    86e0:      	movq	%rax, 0x8(%rsp)
    86e5:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    86ef:      	movq	%rax, (%rsp)
    86f3:      	movb	$0x0, 0x28(%rsp)
    86f8:      	movq	%rsp, %rdi
    86fb:      	movl	$0x29, %eax
    8700:      	movl	$0x6, %r9d
    8706:      	movl	$0x29, %esi
    870b:      	movq	0x58(%rsp), %rdx
    8710:      	movq	0x98(%rsp), %rcx
    8718:      	movq	%r15, %r8
    871b:      	xorl	%eax, %eax
    871d:      	callq	*%r9
    8720:      	movq	(%rip), %rax            # 0x8727 <perf_unwind_v8+0x8727>
    8727:      	cmpl	$0x0, (%rax)
    872a:      	je	0x879c <perf_unwind_v8+0x879c>
    872c:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    8736:      	movq	%rax, 0x1d(%rsp)
    873b:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    8745:      	movq	%rax, 0x18(%rsp)
    874a:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    8754:      	movq	%rax, 0x10(%rsp)
    8759:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    8763:      	movq	%rax, 0x8(%rsp)
    8768:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    8772:      	movq	%rax, (%rsp)
    8776:      	movq	%rsp, %rdi
    8779:      	movl	$0x25, %eax
    877e:      	movl	$0x6, %r9d
    8784:      	movl	$0x25, %esi
    8789:      	movq	%r12, %rdx
    878c:      	movq	0x90(%rsp), %rcx
    8794:      	movl	%r13d, %r8d
    8797:      	xorl	%eax, %eax
    8799:      	callq	*%r9
    879c:      	movq	0x68(%rsp), %rbp
    87a1:      	subq	%r12, %rbp
    87a4:      	jb	0x87fa <perf_unwind_v8+0x87fa>
    87a6:      	movq	0x90(%rsp), %rax
    87ae:      	cmpq	%rax, 0x68(%rsp)
    87b3:      	jae	0x87fa <perf_unwind_v8+0x87fa>
    87b5:      	movl	0xa0(%rsp), %eax
    87bc:      	shrxl	%eax, 0xb0(%rsp), %eax
    87c6:      	movq	0x48(%rsp), %rcx
    87cb:      	movzbl	0x19(%rcx), %ecx
    87cf:      	movq	0x58(%rsp), %rdx
    87d4:      	orq	$0x4, %rdx
    87d8:      	orq	$0x3, %r15
    87dc:      	cmpl	%ecx, %eax
    87de:      	cmoveq	%rdx, %r15
    87e2:      	shll	$0x4, %r13d
    87e6:      	orl	%eax, %r13d
    87e9:      	shlq	$0x20, %r13
    87ed:      	orq	%r13, %rbp
    87f0:      	movq	%r15, 0x50(%rsp)
    87f5:      	jmp	0x8886 <perf_unwind_v8+0x8886>
    87fa:      	movq	(%rip), %rax            # 0x8801 <perf_unwind_v8+0x8801>
    8801:      	cmpl	$0x0, (%rax)
    8804:      	jne	0x8815 <perf_unwind_v8+0x8815>
    8806:      	xorl	%ebp, %ebp
    8808:      	movzbl	0xf30(%r14), %r15d
    8810:      	jmp	0x892e <perf_unwind_v8+0x892e>
    8815:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    881f:      	movq	%rax, 0x28(%rsp)
    8824:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    882e:      	movq	%rax, 0x20(%rsp)
    8833:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    883d:      	movq	%rax, 0x18(%rsp)
    8842:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    884c:      	movq	%rax, 0x10(%rsp)
    8851:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    885b:      	movq	%rax, 0x8(%rsp)
    8860:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    886a:      	movq	%rax, (%rsp)
    886e:      	movq	%rsp, %rdi
    8871:      	movl	$0x30, %eax
    8876:      	movl	$0x6, %ecx
    887b:      	xorl	%ebp, %ebp
    887d:      	movl	$0x30, %esi
    8882:      	xorl	%eax, %eax
    8884:      	callq	*%rcx
    8886:      	movzbl	0xf30(%r14), %r15d
    888e:      	movq	(%rip), %rax            # 0x8895 <perf_unwind_v8+0x8895>
    8895:      	cmpl	$0x0, (%rax)
    8898:      	je	0x892e <perf_unwind_v8+0x892e>
    889e:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    88a8:      	movq	%rax, 0x30(%rsp)
    88ad:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    88b7:      	movq	%rax, 0x28(%rsp)
    88bc:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    88c6:      	movq	%rax, 0x20(%rsp)
    88cb:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    88d5:      	movq	%rax, 0x18(%rsp)
    88da:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    88e4:      	movq	%rax, 0x10(%rsp)
    88e9:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    88f3:      	movq	%rax, 0x8(%rsp)
    88f8:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8902:      	movq	%rax, (%rsp)
    8906:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    890e:      	movq	%rsp, %rdi
    8911:      	movl	$0x3c, %eax
    8916:      	movl	$0x6, %r8d
    891c:      	movl	$0x3c, %esi
    8921:      	movq	%rbp, %rdx
    8924:      	movq	0x50(%rsp), %rcx
    8929:      	xorl	%eax, %eax
    892b:      	callq	*%r8
    892e:      	movl	0x2c0(%r14), %eax
    8935:      	cmpq	$0x7e, %rax
    8939:      	ja	0x27d <perf_unwind_v8+0x27d>
    893f:      	leal	0x1(%rax), %ecx
    8942:      	movl	%ecx, 0x2c0(%r14)
    8949:      	leaq	(%rax,%rax,2), %rax
    894d:      	movq	0x50(%rsp), %rcx
    8952:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    895a:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    8962:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    896b:      	movb	%r15b, 0x2e1(%r14,%rax,8)
    8973:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    897f:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    898a:      	movq	0xee0(%r14), %rax
    8991:      	movq	%rsp, %rdi
    8994:      	movl	$0x10, %ecx
    8999:      	movl	$0x70, %r8d
    899f:      	movq	0xee0(%r14), %rdx
    89a6:      	movl	$0x10, %esi
    89ab:      	callq	*%r8
    89ae:      	testq	%rax, %rax
    89b1:      	jne	0x3d2 <perf_unwind_v8+0x3d2>
    89b7:      	movq	0xee0(%r14), %rax
    89be:      	addq	$0x10, %rax
    89c2:      	movq	%rax, 0xed8(%r14)
    89c9:      	movq	(%rsp), %rax
    89cd:      	movq	%rax, 0xee0(%r14)
    89d4:      	movq	0x8(%rsp), %rax
    89d9:      	movq	%rax, 0xed0(%r14)
    89e0:      	movb	$0x1, 0xf30(%r14)
    89e8:      	movq	(%rip), %rax            # 0x89ef <perf_unwind_v8+0x89ef>
    89ef:      	cmpl	$0x0, (%rax)
    89f2:      	je	0x8a5c <perf_unwind_v8+0x8a5c>
    89f4:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    89fe:      	movq	%rax, 0x17(%rsp)
    8a03:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    8a0d:      	movq	%rax, 0x10(%rsp)
    8a12:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    8a1c:      	movq	%rax, 0x8(%rsp)
    8a21:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    8a2b:      	movq	%rax, (%rsp)
    8a2f:      	movq	%rsp, %rdi
    8a32:      	movl	$0x1f, %eax
    8a37:      	movl	$0x6, %r9d
    8a3d:      	movq	0xed0(%r14), %rdx
    8a44:      	movq	0xed8(%r14), %rcx
    8a4b:      	movq	0xee0(%r14), %r8
    8a52:      	movl	$0x1f, %esi
    8a57:      	xorl	%eax, %eax
    8a59:      	callq	*%r9
    8a5c:      	movl	$0x38, 0x70(%rsp)
    8a64:      	movq	(%rip), %rdi            # 0x8a6b <perf_unwind_v8+0x8a6b>
    8a6b:      	leaq	0x70(%rsp), %rsi
    8a70:      	movl	$0x1, %eax
    8a75:      	callq	*%rax
    8a77:      	testq	%rax, %rax
    8a7a:      	je	0x8a84 <perf_unwind_v8+0x8a84>
    8a7c:      	incq	(%rax)
    8a7f:      	jmp	0x8b05 <perf_unwind_v8+0x8b05>
    8a84:      	xorl	%eax, %eax
    8a86:      	movq	(%rip), %rcx            # 0x8a8d <perf_unwind_v8+0x8a8d>
    8a8d:      	cmpl	$0x0, (%rcx)
    8a90:      	je	0x8b0e <perf_unwind_v8+0x8b0e>
    8a92:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8a9c:      	movq	%rax, 0x26(%rsp)
    8aa1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8aab:      	movq	%rax, 0x20(%rsp)
    8ab0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8aba:      	movq	%rax, 0x18(%rsp)
    8abf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8ac9:      	movq	%rax, 0x10(%rsp)
    8ace:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8ad8:      	movq	%rax, 0x8(%rsp)
    8add:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8ae7:      	movq	%rax, (%rsp)
    8aeb:      	movq	%rsp, %rdi
    8aee:      	movl	$0x2e, %eax
    8af3:      	movl	$0x6, %ecx
    8af8:      	movl	0x70(%rsp), %edx
    8afc:      	movl	$0x2e, %esi
    8b01:      	xorl	%eax, %eax
    8b03:      	callq	*%rcx
    8b05:      	movq	(%rip), %rax            # 0x8b0c <perf_unwind_v8+0x8b0c>
    8b0c:      	movl	(%rax), %eax
    8b0e:      	movq	0xed0(%r14), %r12
    8b15:      	testq	%r12, %r12
    8b18:      	je	0x8e7c <perf_unwind_v8+0x8e7c>
    8b1e:      	testl	%eax, %eax
    8b20:      	je	0x8ba8 <perf_unwind_v8+0x8ba8>
    8b26:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    8b30:      	movq	%rax, 0x28(%rsp)
    8b35:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    8b3f:      	movq	%rax, 0x20(%rsp)
    8b44:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    8b4e:      	movq	%rax, 0x18(%rsp)
    8b53:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    8b5d:      	movq	%rax, 0x10(%rsp)
    8b62:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    8b6c:      	movq	%rax, 0x8(%rsp)
    8b71:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    8b7b:      	movq	%rax, (%rsp)
    8b7f:      	movb	$0x0, 0x30(%rsp)
    8b84:      	movq	%rsp, %rdi
    8b87:      	movl	$0x31, %eax
    8b8c:      	movl	$0x6, %ecx
    8b91:      	movl	0x2c0(%r14), %edx
    8b98:      	movl	$0x31, %esi
    8b9d:      	xorl	%eax, %eax
    8b9f:      	callq	*%rcx
    8ba1:      	movq	0xed0(%r14), %r12
    8ba8:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    8bb2:      	cmpq	%rax, %r12
    8bb5:      	ja	0x1db3 <perf_unwind_v8+0x1db3>
    8bbb:      	cmpq	$0x1000, %r12           # imm = 0x1000
    8bc2:      	jb	0x285e <perf_unwind_v8+0x285e>
    8bc8:      	movl	(%r14), %eax
    8bcb:      	movl	$0x60, 0x70(%rsp)
    8bd3:      	movbel	%eax, 0x74(%rsp)
    8bd9:      	movbeq	%r12, 0x78(%rsp)
    8be0:      	movq	(%rip), %rdi            # 0x8be7 <perf_unwind_v8+0x8be7>
    8be7:      	leaq	0x70(%rsp), %rsi
    8bec:      	movl	$0x1, %eax
    8bf1:      	callq	*%rax
    8bf3:      	testq	%rax, %rax
    8bf6:      	je	0x8e96 <perf_unwind_v8+0x8e96>
    8bfc:      	movq	0x8(%rax), %rbp
    8c00:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    8c0a:      	andq	%rbp, %rcx
    8c0d:      	movq	%rcx, 0xf20(%r14)
    8c14:      	movq	(%rax), %rax
    8c17:      	movq	%rax, 0xf10(%r14)
    8c1e:      	shrq	$0x38, %rbp
    8c22:      	movq	%r12, %rax
    8c25:      	subq	%rcx, %rax
    8c28:      	movq	%rax, 0xf18(%r14)
    8c2f:      	movq	(%rip), %rax            # 0x8c36 <perf_unwind_v8+0x8c36>
    8c36:      	cmpl	$0x0, (%rax)
    8c39:      	je	0x8d45 <perf_unwind_v8+0x8d45>
    8c3f:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    8c49:      	movq	%rax, 0x28(%rsp)
    8c4e:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    8c58:      	movq	%rax, 0x20(%rsp)
    8c5d:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    8c67:      	movq	%rax, 0x18(%rsp)
    8c6c:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    8c76:      	movq	%rax, 0x10(%rsp)
    8c7b:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    8c85:      	movq	%rax, 0x8(%rsp)
    8c8a:      	movabsq	$0x6365732074786554, %r15 # imm = 0x6365732074786554
    8c94:      	movq	%r15, (%rsp)
    8c98:      	movw	$0xa, 0x30(%rsp)
    8c9f:      	movq	%rsp, %rdi
    8ca2:      	movl	$0x32, %eax
    8ca7:      	movl	$0x6, %r9d
    8cad:      	movq	0xf10(%r14), %rcx
    8cb4:      	movl	$0x32, %esi
    8cb9:      	movq	%r12, %rdx
    8cbc:      	movl	%ebp, %r8d
    8cbf:      	xorl	%eax, %eax
    8cc1:      	callq	*%r9
    8cc4:      	movq	(%rip), %rax            # 0x8ccb <perf_unwind_v8+0x8ccb>
    8ccb:      	cmpl	$0x0, (%rax)
    8cce:      	je	0x8d45 <perf_unwind_v8+0x8d45>
    8cd0:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    8cda:      	movq	%rax, 0x27(%rsp)
    8cdf:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    8ce9:      	movq	%rax, 0x20(%rsp)
    8cee:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    8cf8:      	movq	%rax, 0x18(%rsp)
    8cfd:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    8d07:      	movq	%rax, 0x10(%rsp)
    8d0c:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    8d16:      	movq	%rax, 0x8(%rsp)
    8d1b:      	movq	%r15, (%rsp)
    8d1f:      	movq	%rsp, %rdi
    8d22:      	movl	$0x2f, %eax
    8d27:      	movl	$0x6, %r8d
    8d2d:      	movq	0xf18(%r14), %rcx
    8d34:      	movq	0xf20(%r14), %rdx
    8d3b:      	movl	$0x2f, %esi
    8d40:      	xorl	%eax, %eax
    8d42:      	callq	*%r8
    8d45:      	xorl	%r12d, %r12d
    8d48:      	cmpl	$0x1, %ebp
    8d4b:      	jne	0x2070 <perf_unwind_v8+0x2070>
    8d51:      	movq	0xf10(%r14), %rax
    8d58:      	movq	%rax, 0x70(%rsp)
    8d5d:      	movq	0xf18(%r14), %r13
    8d64:      	movq	(%rip), %rdi            # 0x8d6b <perf_unwind_v8+0x8d6b>
    8d6b:      	leaq	0x70(%rsp), %rsi
    8d70:      	movl	$0x1, %eax
    8d75:      	callq	*%rax
    8d77:      	movl	$0x1, %ebp
    8d7c:      	testq	%rax, %rax
    8d7f:      	je	0x2070 <perf_unwind_v8+0x2070>
    8d85:      	movq	%rax, %r15
    8d88:      	cmpq	%r13, (%rax)
    8d8b:      	ja	0x8d93 <perf_unwind_v8+0x8d93>
    8d8d:      	cmpq	%r13, 0x8(%r15)
    8d91:      	jae	0x8da7 <perf_unwind_v8+0x8da7>
    8d93:      	cmpq	%r13, 0x10(%r15)
    8d97:      	ja	0x2070 <perf_unwind_v8+0x2070>
    8d9d:      	cmpq	%r13, 0x18(%r15)
    8da1:      	jb	0x2070 <perf_unwind_v8+0x2070>
    8da7:      	movq	(%rip), %rax            # 0x8dae <perf_unwind_v8+0x8dae>
    8dae:      	cmpl	$0x0, (%rax)
    8db1:      	je	0x8e09 <perf_unwind_v8+0x8e09>
    8db3:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    8dbd:      	movq	%rax, 0x16(%rsp)
    8dc2:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    8dcc:      	movq	%rax, 0x10(%rsp)
    8dd1:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    8ddb:      	movq	%rax, 0x8(%rsp)
    8de0:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    8dea:      	movq	%rax, (%rsp)
    8dee:      	movq	%rsp, %rdi
    8df1:      	movl	$0x1e, %eax
    8df6:      	movl	$0x6, %ecx
    8dfb:      	movzwl	0x20(%r15), %edx
    8e00:      	movl	$0x1e, %esi
    8e05:      	xorl	%eax, %eax
    8e07:      	callq	*%rcx
    8e09:      	movl	0x1380(%r14), %eax
    8e10:      	movl	0x20(%r15), %ecx
    8e14:      	btl	%ecx, %eax
    8e17:      	jae	0x8fc0 <perf_unwind_v8+0x8fc0>
    8e1d:      	movq	(%rip), %rax            # 0x8e24 <perf_unwind_v8+0x8e24>
    8e24:      	cmpl	$0x0, (%rax)
    8e27:      	je	0x2070 <perf_unwind_v8+0x2070>
    8e2d:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    8e37:      	movq	%rax, 0x10(%rsp)
    8e3c:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    8e46:      	movq	%rax, 0x8(%rsp)
    8e4b:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    8e55:      	movq	%rax, (%rsp)
    8e59:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    8e61:      	movq	%rsp, %rdi
    8e64:      	movl	$0x1b, %eax
    8e69:      	movl	$0x6, %ecx
    8e6e:      	movl	$0x1b, %esi
    8e73:      	xorl	%eax, %eax
    8e75:      	callq	*%rcx
    8e77:      	jmp	0x2070 <perf_unwind_v8+0x2070>
    8e7c:      	testl	%eax, %eax
    8e7e:      	jne	0x8ebc <perf_unwind_v8+0x8ebc>
    8e80:      	movl	$0x1, 0xf28(%r14)
    8e8b:      	movl	$0xfad, %r12d           # imm = 0xFAD
    8e91:      	jmp	0x206e <perf_unwind_v8+0x206e>
    8e96:      	movq	(%rip), %rax            # 0x8e9d <perf_unwind_v8+0x8e9d>
    8e9d:      	cmpl	$0x0, (%rax)
    8ea0:      	jne	0x8f35 <perf_unwind_v8+0x8f35>
    8ea6:      	movl	$0xc, 0xf28(%r14)
    8eb1:      	movl	$0xfac, %r12d           # imm = 0xFAC
    8eb7:      	jmp	0x206e <perf_unwind_v8+0x206e>
    8ebc:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    8ec6:      	movq	%rax, 0x28(%rsp)
    8ecb:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    8ed5:      	movq	%rax, 0x20(%rsp)
    8eda:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    8ee4:      	movq	%rax, 0x18(%rsp)
    8ee9:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    8ef3:      	movq	%rax, 0x10(%rsp)
    8ef8:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    8f02:      	movq	%rax, 0x8(%rsp)
    8f07:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    8f11:      	movq	%rax, (%rsp)
    8f15:      	movb	$0x0, 0x30(%rsp)
    8f1a:      	movq	%rsp, %rdi
    8f1d:      	movl	$0x31, %eax
    8f22:      	movl	$0x6, %ecx
    8f27:      	movl	$0x31, %esi
    8f2c:      	xorl	%eax, %eax
    8f2e:      	callq	*%rcx
    8f30:      	jmp	0x8e80 <perf_unwind_v8+0x8e80>
    8f35:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    8f3f:      	movq	%rax, 0x30(%rsp)
    8f44:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    8f4e:      	movq	%rax, 0x28(%rsp)
    8f53:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    8f5d:      	movq	%rax, 0x20(%rsp)
    8f62:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    8f6c:      	movq	%rax, 0x18(%rsp)
    8f71:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    8f7b:      	movq	%rax, 0x10(%rsp)
    8f80:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    8f8a:      	movq	%rax, 0x8(%rsp)
    8f8f:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    8f99:      	movq	%rax, (%rsp)
    8f9d:      	movb	$0x0, 0x38(%rsp)
    8fa2:      	movq	%rsp, %rdi
    8fa5:      	movl	$0x39, %eax
    8faa:      	movl	$0x6, %ecx
    8faf:      	movl	$0x39, %esi
    8fb4:      	movq	%r12, %rdx
    8fb7:      	xorl	%eax, %eax
    8fb9:      	callq	*%rcx
    8fbb:      	jmp	0x8ea6 <perf_unwind_v8+0x8ea6>
    8fc0:      	movl	$0x0, 0x64(%rsp)
    8fc8:      	movq	(%rip), %rdi            # 0x8fcf <perf_unwind_v8+0x8fcf>
    8fcf:      	leaq	0x64(%rsp), %rsi
    8fd4:      	movl	$0x1, %eax
    8fd9:      	callq	*%rax
    8fdb:      	testq	%rax, %rax
    8fde:      	je	0x8fed <perf_unwind_v8+0x8fed>
    8fe0:      	incq	(%rax)
    8fe3:      	movzwl	0x20(%r15), %ebp
    8fe8:      	jmp	0x2070 <perf_unwind_v8+0x2070>
    8fed:      	movq	(%rip), %rax            # 0x8ff4 <perf_unwind_v8+0x8ff4>
    8ff4:      	cmpl	$0x0, (%rax)
    8ff7:      	je	0x906c <perf_unwind_v8+0x906c>
    8ff9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    9003:      	movq	%rax, 0x26(%rsp)
    9008:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    9012:      	movq	%rax, 0x20(%rsp)
    9017:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9021:      	movq	%rax, 0x18(%rsp)
    9026:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9030:      	movq	%rax, 0x10(%rsp)
    9035:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    903f:      	movq	%rax, 0x8(%rsp)
    9044:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    904e:      	movq	%rax, (%rsp)
    9052:      	movq	%rsp, %rdi
    9055:      	movl	$0x2e, %eax
    905a:      	movl	$0x6, %ecx
    905f:      	movl	0x64(%rsp), %edx
    9063:      	movl	$0x2e, %esi
    9068:      	xorl	%eax, %eax
    906a:      	callq	*%rcx
    906c:      	movzwl	0x20(%r15), %ebp
    9071:      	jmp	0x2070 <perf_unwind_v8+0x2070>

Disassembly of section kprobe/unwind_v8:

0000000000000000 <kprobe_unwind_v8>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, (%rsp)
      1b:      	movq	(%rip), %rdi            # 0x22 <kprobe_unwind_v8+0x22>
      22:      	movq	%rsp, %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x212f <kprobe_unwind_v8+0x212f>
      35:      	movq	%rax, %r14
      38:      	movl	(%rax), %eax
      3a:      	movl	%eax, 0xc4(%rsp)
      41:      	movq	(%rip), %rbp            # 0x48 <kprobe_unwind_v8+0x48>
      48:      	cmpl	$0x0, (%rbp)
      4c:      	jne	0x6c6 <kprobe_unwind_v8+0x6c6>
      52:      	movq	(%rip), %rdi            # 0x59 <kprobe_unwind_v8+0x59>
      59:      	leaq	0xc4(%rsp), %rsi
      61:      	movl	$0x1, %eax
      66:      	callq	*%rax
      68:      	testq	%rax, %rax
      6b:      	je	0x97 <kprobe_unwind_v8+0x97>
      6d:      	movq	%rax, 0x48(%rsp)
      72:      	movl	$0x37, 0x70(%rsp)
      7a:      	movq	(%rip), %rdi            # 0x81 <kprobe_unwind_v8+0x81>
      81:      	leaq	0x70(%rsp), %rsi
      86:      	movl	$0x1, %eax
      8b:      	callq	*%rax
      8d:      	testq	%rax, %rax
      90:      	je	0xcd <kprobe_unwind_v8+0xcd>
      92:      	incq	(%rax)
      95:      	jmp	0xd7 <kprobe_unwind_v8+0xd7>
      97:      	cmpl	$0x0, (%rbp)
      9b:      	jne	0xa42 <kprobe_unwind_v8+0xa42>
      a1:      	movl	$0x54, 0x70(%rsp)
      a9:      	movq	(%rip), %rdi            # 0xb0 <kprobe_unwind_v8+0xb0>
      b0:      	leaq	0x70(%rsp), %rsi
      b5:      	movl	$0x1, %eax
      ba:      	callq	*%rax
      bc:      	testq	%rax, %rax
      bf:      	je	0x1db <kprobe_unwind_v8+0x1db>
      c5:      	incq	(%rax)
      c8:      	jmp	0x1e5 <kprobe_unwind_v8+0x1e5>
      cd:      	cmpl	$0x0, (%rbp)
      d1:      	jne	0xa98 <kprobe_unwind_v8+0xa98>
      d7:      	movq	0xed0(%r14), %r13
      de:      	movq	0xed8(%r14), %r12
      e5:      	movq	0xee0(%r14), %rdx
      ec:      	cmpl	$0x0, (%rbp)
      f0:      	jne	0x8bb <kprobe_unwind_v8+0x8bb>
      f6:      	cmpq	%r12, %rdx
      f9:      	jb	0x202f <kprobe_unwind_v8+0x202f>
      ff:      	leaq	0x2000(%r12), %rax
     107:      	cmpq	%rax, %rdx
     10a:      	jae	0x202f <kprobe_unwind_v8+0x202f>
     110:      	leaq	0xf80(%r14), %r15
     117:      	addq	$-0x40, %rdx
     11b:      	movl	$0x40, %eax
     120:      	movl	$0x70, %ecx
     125:      	movq	%r15, %rdi
     128:      	movl	$0x40, %esi
     12d:      	callq	*%rcx
     12f:      	testq	%rax, %rax
     132:      	je	0x1f0 <kprobe_unwind_v8+0x1f0>
     138:      	cmpl	$0x0, (%rbp)
     13c:      	jne	0xb10 <kprobe_unwind_v8+0xb10>
     142:      	movl	$0x39, 0x70(%rsp)
     14a:      	movq	(%rip), %rdi            # 0x151 <kprobe_unwind_v8+0x151>
     151:      	leaq	0x70(%rsp), %rsi
     156:      	movl	$0x1, %eax
     15b:      	callq	*%rax
     15d:      	testq	%rax, %rax
     160:      	jne	0x2059 <kprobe_unwind_v8+0x2059>
     166:      	cmpl	$0x0, (%rbp)
     16a:      	je	0x2068 <kprobe_unwind_v8+0x2068>
     170:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     17a:      	movq	%rax, 0x26(%rsp)
     17f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     189:      	movq	%rax, 0x20(%rsp)
     18e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     198:      	movq	%rax, 0x18(%rsp)
     19d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     1a7:      	movq	%rax, 0x10(%rsp)
     1ac:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     1b6:      	movq	%rax, 0x8(%rsp)
     1bb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     1c5:      	movq	%rax, (%rsp)
     1c9:      	movq	%rsp, %rdi
     1cc:      	movl	$0x2e, %eax
     1d1:      	movl	$0x6, %ecx
     1d6:      	jmp	0x2299 <kprobe_unwind_v8+0x2299>
     1db:      	cmpl	$0x0, (%rbp)
     1df:      	jne	0xca2 <kprobe_unwind_v8+0xca2>
     1e5:      	movl	$0x138a, %r12d          # imm = 0x138A
     1eb:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
     1f0:      	movq	%r15, 0x98(%rsp)
     1f8:      	movq	0x48(%rsp), %r8
     1fd:      	movzbl	0x14(%r8), %eax
     202:      	xorl	%ebp, %ebp
     204:      	cmpq	$0x38, %rax
     208:      	ja	0x220 <kprobe_unwind_v8+0x220>
     20a:      	movzbl	0x15(%r8), %ecx
     20f:      	cmpq	$0x38, %rcx
     213:      	ja	0x220 <kprobe_unwind_v8+0x220>
     215:      	movzbl	0x16(%r8), %edi
     21a:      	cmpq	$0x38, %rdi
     21e:      	jbe	0x22b <kprobe_unwind_v8+0x22b>
     220:      	movl	$0x1, %r12d
     226:      	jmp	0x2070 <kprobe_unwind_v8+0x2070>
     22b:      	movq	%r14, %rsi
     22e:      	addq	$0xfc0, %rsi            # imm = 0xFC0
     235:      	movq	%rsi, 0xb0(%rsp)
     23d:      	movq	0x98(%rsp), %rsi
     245:      	movq	(%rsi,%rax), %rdx
     249:      	testb	$0x1, %dl
     24c:      	jne	0x2ba <kprobe_unwind_v8+0x2ba>
     24e:      	shrq	%rdx
     251:      	movq	(%rip), %rax            # 0x258 <kprobe_unwind_v8+0x258>
     258:      	cmpl	$0x0, (%rax)
     25b:      	jne	0xe74 <kprobe_unwind_v8+0xe74>
     261:      	xorl	%r15d, %r15d
     264:      	movzbl	0xf30(%r14), %ebp
     26c:      	movl	0x2c0(%r14), %eax
     273:      	cmpq	$0x7f, %rax
     277:      	jb	0x35f <kprobe_unwind_v8+0x35f>
     27d:      	movq	(%rip), %r15            # 0x284 <kprobe_unwind_v8+0x284>
     284:      	cmpl	$0x0, (%r15)
     288:      	jne	0xf4e <kprobe_unwind_v8+0xf4e>
     28e:      	movl	$0x2, 0x70(%rsp)
     296:      	movq	(%rip), %rdi            # 0x29d <kprobe_unwind_v8+0x29d>
     29d:      	leaq	0x70(%rsp), %rsi
     2a2:      	movl	$0x1, %eax
     2a7:      	callq	*%rax
     2a9:      	testq	%rax, %rax
     2ac:      	je	0x5f2 <kprobe_unwind_v8+0x5f2>
     2b2:      	incq	(%rax)
     2b5:      	jmp	0x5fc <kprobe_unwind_v8+0x5fc>
     2ba:      	movq	%rsi, %rax
     2bd:      	movq	(%rsi,%rdi), %r15
     2c1:      	movq	(%rsi,%rcx), %rsi
     2c5:      	movl	%esi, %ecx
     2c7:      	andl	$0x3, %ecx
     2ca:      	andq	$-0x4, %rsi
     2ce:      	xorl	%eax, %eax
     2d0:      	cmpl	$0x1, %ecx
     2d3:      	cmovneq	%rax, %rsi
     2d7:      	testq	%rsi, %rsi
     2da:      	je	0x486 <kprobe_unwind_v8+0x486>
     2e0:      	movzbl	0xc(%r8), %edx
     2e5:      	movq	%rsi, %rbp
     2e8:      	addq	%rsi, %rdx
     2eb:      	movq	%rsp, %rdi
     2ee:      	movl	$0x8, %eax
     2f3:      	movl	$0x70, %ecx
     2f8:      	movl	$0x8, %esi
     2fd:      	callq	*%rcx
     2ff:      	testq	%rax, %rax
     302:      	jne	0x47c <kprobe_unwind_v8+0x47c>
     308:      	movq	(%rsp), %rax
     30c:      	movl	%eax, %ecx
     30e:      	andl	$0x3, %ecx
     311:      	cmpl	$0x1, %ecx
     314:      	jne	0x47c <kprobe_unwind_v8+0x47c>
     31a:      	andq	$-0x4, %rax
     31e:      	je	0x47c <kprobe_unwind_v8+0x47c>
     324:      	movq	0x48(%rsp), %rsi
     329:      	movzbl	0xd(%rsi), %ecx
     32d:      	addq	%rax, %rcx
     330:      	movq	%rsp, %rdi
     333:      	movl	$0x2, %edx
     338:      	movl	$0x70, %r8d
     33e:      	movzbl	0xd(%rsi), %edx
     342:      	addq	%rax, %rdx
     345:      	movl	$0x2, %esi
     34a:      	callq	*%r8
     34d:      	testq	%rax, %rax
     350:      	jne	0x932 <kprobe_unwind_v8+0x932>
     356:      	movzwl	(%rsp), %eax
     35a:      	jmp	0x934 <kprobe_unwind_v8+0x934>
     35f:      	leal	0x1(%rax), %ecx
     362:      	movl	%ecx, 0x2c0(%r14)
     369:      	leaq	(%rax,%rax,2), %rax
     36d:      	movq	%r15, 0x2d0(%r14,%rax,8)
     375:      	movq	%rdx, 0x2d8(%r14,%rax,8)
     37d:      	movb	$0x8, 0x2e0(%r14,%rax,8)
     386:      	movb	%bpl, 0x2e1(%r14,%rax,8)
     38e:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     39a:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     3a5:      	movq	0xee0(%r14), %rax
     3ac:      	movq	%rsp, %rdi
     3af:      	movl	$0x10, %ecx
     3b4:      	movl	$0x70, %r8d
     3ba:      	movq	0xee0(%r14), %rdx
     3c1:      	movl	$0x10, %esi
     3c6:      	callq	*%r8
     3c9:      	testq	%rax, %rax
     3cc:      	je	0x607 <kprobe_unwind_v8+0x607>
     3d2:      	movq	(%rip), %r15            # 0x3d9 <kprobe_unwind_v8+0x3d9>
     3d9:      	cmpl	$0x0, (%r15)
     3dd:      	jne	0x1081 <kprobe_unwind_v8+0x1081>
     3e3:      	movl	$0x39, 0x70(%rsp)
     3eb:      	movq	(%rip), %rdi            # 0x3f2 <kprobe_unwind_v8+0x3f2>
     3f2:      	leaq	0x70(%rsp), %rsi
     3f7:      	movl	$0x1, %eax
     3fc:      	callq	*%rax
     3fe:      	testq	%rax, %rax
     401:      	jne	0x2059 <kprobe_unwind_v8+0x2059>
     407:      	cmpl	$0x0, (%r15)
     40b:      	je	0x2068 <kprobe_unwind_v8+0x2068>
     411:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     41b:      	movq	%rax, 0x26(%rsp)
     420:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     42a:      	movq	%rax, 0x20(%rsp)
     42f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     439:      	movq	%rax, 0x18(%rsp)
     43e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     448:      	movq	%rax, 0x10(%rsp)
     44d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     457:      	movq	%rax, 0x8(%rsp)
     45c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     466:      	movq	%rax, (%rsp)
     46a:      	movq	%rsp, %rdi
     46d:      	movl	$0x2e, %eax
     472:      	movl	$0x6, %ecx
     477:      	jmp	0x2299 <kprobe_unwind_v8+0x2299>
     47c:      	xorl	%eax, %eax
     47e:      	movq	0x48(%rsp), %r8
     483:      	movq	%rbp, %rsi
     486:      	cmpw	0x4(%r8), %ax
     48b:      	jb	0x494 <kprobe_unwind_v8+0x494>
     48d:      	cmpw	0x6(%r8), %ax
     492:      	jbe	0x4e1 <kprobe_unwind_v8+0x4e1>
     494:      	movq	(%rip), %r12            # 0x49b <kprobe_unwind_v8+0x49b>
     49b:      	cmpl	$0x0, (%r12)
     4a0:      	jne	0xed3 <kprobe_unwind_v8+0xed3>
     4a6:      	movl	$0x3a, 0x70(%rsp)
     4ae:      	movq	(%rip), %rdi            # 0x4b5 <kprobe_unwind_v8+0x4b5>
     4b5:      	leaq	0x70(%rsp), %rsi
     4ba:      	movl	$0x1, %eax
     4bf:      	callq	*%rax
     4c1:      	testq	%rax, %rax
     4c4:      	je	0x4cb <kprobe_unwind_v8+0x4cb>
     4c6:      	incq	(%rax)
     4c9:      	jmp	0x4d6 <kprobe_unwind_v8+0x4d6>
     4cb:      	cmpl	$0x0, (%r12)
     4d0:      	jne	0x10d0 <kprobe_unwind_v8+0x10d0>
     4d6:      	movl	$0x1389, %r12d          # imm = 0x1389
     4dc:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
     4e1:      	movzbl	0xf(%r8), %edx
     4e6:      	movq	%rsi, 0x50(%rsp)
     4eb:      	addq	%rsi, %rdx
     4ee:      	movq	%rsp, %rdi
     4f1:      	movl	$0x8, %eax
     4f6:      	movl	$0x70, %ecx
     4fb:      	movl	$0x8, %esi
     500:      	callq	*%rcx
     502:      	testq	%rax, %rax
     505:      	jne	0x5a7 <kprobe_unwind_v8+0x5a7>
     50b:      	movq	(%rsp), %rbp
     50f:      	movl	%ebp, %eax
     511:      	andl	$0x3, %eax
     514:      	cmpl	$0x1, %eax
     517:      	jne	0x5a7 <kprobe_unwind_v8+0x5a7>
     51d:      	andq	$-0x4, %rbp
     521:      	je	0x5a7 <kprobe_unwind_v8+0x5a7>
     527:      	movq	0x48(%rsp), %rax
     52c:      	movzbl	0xc(%rax), %edx
     530:      	addq	%rbp, %rdx
     533:      	movq	%rsp, %rdi
     536:      	movl	$0x8, %eax
     53b:      	movl	$0x70, %ecx
     540:      	movl	$0x8, %esi
     545:      	callq	*%rcx
     547:      	testq	%rax, %rax
     54a:      	jne	0x982 <kprobe_unwind_v8+0x982>
     550:      	movq	(%rsp), %rax
     554:      	movl	%eax, %ecx
     556:      	andl	$0x3, %ecx
     559:      	cmpl	$0x1, %ecx
     55c:      	jne	0x982 <kprobe_unwind_v8+0x982>
     562:      	andq	$-0x4, %rax
     566:      	je	0x982 <kprobe_unwind_v8+0x982>
     56c:      	movq	0x48(%rsp), %rsi
     571:      	movzbl	0xd(%rsi), %ecx
     575:      	addq	%rax, %rcx
     578:      	movq	%rsp, %rdi
     57b:      	movl	$0x2, %edx
     580:      	movl	$0x70, %r8d
     586:      	movzbl	0xd(%rsi), %edx
     58a:      	addq	%rax, %rdx
     58d:      	movl	$0x2, %esi
     592:      	callq	*%r8
     595:      	testq	%rax, %rax
     598:      	jne	0x982 <kprobe_unwind_v8+0x982>
     59e:      	movzwl	(%rsp), %eax
     5a2:      	jmp	0x984 <kprobe_unwind_v8+0x984>
     5a7:      	xorl	%ebp, %ebp
     5a9:      	xorl	%eax, %eax
     5ab:      	movq	0x48(%rsp), %rcx
     5b0:      	movq	0x50(%rsp), %rsi
     5b5:      	cmpw	0xa(%rcx), %ax
     5b9:      	jne	0x998 <kprobe_unwind_v8+0x998>
     5bf:      	movq	%r15, %rdx
     5c2:      	shrq	$0x20, %rdx
     5c6:      	je	0x714 <kprobe_unwind_v8+0x714>
     5cc:      	andl	$0x1, %r15d
     5d0:      	jne	0x714 <kprobe_unwind_v8+0x714>
     5d6:      	movq	(%rip), %rax            # 0x5dd <kprobe_unwind_v8+0x5dd>
     5dd:      	cmpl	$0x0, (%rax)
     5e0:      	jne	0x152f <kprobe_unwind_v8+0x152f>
     5e6:      	orq	$0x1, %rbp
     5ea:      	movq	%rbp, %r15
     5ed:      	jmp	0xbf4 <kprobe_unwind_v8+0xbf4>
     5f2:      	cmpl	$0x0, (%r15)
     5f6:      	jne	0x1163 <kprobe_unwind_v8+0x1163>
     5fc:      	movl	$0x2, %r12d
     602:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
     607:      	movq	0xee0(%r14), %rax
     60e:      	addq	$0x10, %rax
     612:      	movq	%rax, 0xed8(%r14)
     619:      	movq	(%rsp), %rax
     61d:      	movq	%rax, 0xee0(%r14)
     624:      	movq	0x8(%rsp), %rax
     629:      	movq	%rax, 0xed0(%r14)
     630:      	movb	$0x1, 0xf30(%r14)
     638:      	movq	(%rip), %r13            # 0x63f <kprobe_unwind_v8+0x63f>
     63f:      	cmpl	$0x0, (%r13)
     644:      	jne	0x11db <kprobe_unwind_v8+0x11db>
     64a:      	movl	$0x38, 0x70(%rsp)
     652:      	movq	(%rip), %rdi            # 0x659 <kprobe_unwind_v8+0x659>
     659:      	leaq	0x70(%rsp), %rsi
     65e:      	movl	$0x1, %eax
     663:      	callq	*%rax
     665:      	testq	%rax, %rax
     668:      	je	0x673 <kprobe_unwind_v8+0x673>
     66a:      	incq	(%rax)
     66d:      	movl	(%r13), %eax
     671:      	jmp	0x680 <kprobe_unwind_v8+0x680>
     673:      	xorl	%eax, %eax
     675:      	cmpl	$0x0, (%r13)
     67a:      	jne	0x14b7 <kprobe_unwind_v8+0x14b7>
     680:      	movq	0xed0(%r14), %r12
     687:      	testq	%r12, %r12
     68a:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
     690:      	testl	%eax, %eax
     692:      	jne	0x1248 <kprobe_unwind_v8+0x1248>
     698:      	movq	%r12, %rax
     69b:      	shrq	$0x38, %rax
     69f:      	je	0x12d7 <kprobe_unwind_v8+0x12d7>
     6a5:      	cmpl	$0x0, (%r13)
     6aa:      	jne	0x1dc5 <kprobe_unwind_v8+0x1dc5>
     6b0:      	movl	$0xb, 0xf28(%r14)
     6bb:      	movl	$0xfab, %r12d           # imm = 0xFAB
     6c1:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
     6c6:      	movabsq	$0xa3d3d3d3d2064, %rax  # imm = 0xA3D3D3D3D2064
     6d0:      	movq	%rax, 0x10(%rsp)
     6d5:      	movabsq	$0x252038765f646e69, %rax # imm = 0x252038765F646E69
     6df:      	movq	%rax, 0x8(%rsp)
     6e4:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     6ee:      	movq	%rax, (%rsp)
     6f2:      	movq	%rsp, %rdi
     6f5:      	movl	$0x18, %eax
     6fa:      	movl	$0x6, %ecx
     6ff:      	movl	0x2c0(%r14), %edx
     706:      	movl	$0x18, %esi
     70b:      	xorl	%eax, %eax
     70d:      	callq	*%rcx
     70f:      	jmp	0x52 <kprobe_unwind_v8+0x52>
     714:      	movzbl	0xe(%rcx), %edx
     718:      	addq	%rsi, %rdx
     71b:      	movq	%rsp, %rdi
     71e:      	movl	$0x8, %eax
     723:      	movl	$0x70, %ecx
     728:      	movl	$0x8, %esi
     72d:      	callq	*%rcx
     72f:      	testq	%rax, %rax
     732:      	jne	0x7d5 <kprobe_unwind_v8+0x7d5>
     738:      	movq	(%rsp), %r15
     73c:      	movl	%r15d, %eax
     73f:      	andl	$0x3, %eax
     742:      	cmpl	$0x1, %eax
     745:      	jne	0x7d5 <kprobe_unwind_v8+0x7d5>
     74b:      	andq	$-0x4, %r15
     74f:      	je	0x7d5 <kprobe_unwind_v8+0x7d5>
     755:      	movq	0x48(%rsp), %rax
     75a:      	movzbl	0xc(%rax), %edx
     75e:      	addq	%r15, %rdx
     761:      	movq	%rsp, %rdi
     764:      	movl	$0x8, %eax
     769:      	movl	$0x70, %ecx
     76e:      	movl	$0x8, %esi
     773:      	callq	*%rcx
     775:      	testq	%rax, %rax
     778:      	jne	0xd1a <kprobe_unwind_v8+0xd1a>
     77e:      	movq	(%rsp), %rax
     782:      	movl	%eax, %ecx
     784:      	andl	$0x3, %ecx
     787:      	cmpl	$0x1, %ecx
     78a:      	jne	0xd1a <kprobe_unwind_v8+0xd1a>
     790:      	andq	$-0x4, %rax
     794:      	je	0xd1a <kprobe_unwind_v8+0xd1a>
     79a:      	movq	0x48(%rsp), %rsi
     79f:      	movzbl	0xd(%rsi), %ecx
     7a3:      	addq	%rax, %rcx
     7a6:      	movq	%rsp, %rdi
     7a9:      	movl	$0x2, %edx
     7ae:      	movl	$0x70, %r8d
     7b4:      	movzbl	0xd(%rsi), %edx
     7b8:      	addq	%rax, %rdx
     7bb:      	movl	$0x2, %esi
     7c0:      	callq	*%r8
     7c3:      	testq	%rax, %rax
     7c6:      	jne	0xd1a <kprobe_unwind_v8+0xd1a>
     7cc:      	movzwl	(%rsp), %eax
     7d0:      	jmp	0xd1c <kprobe_unwind_v8+0xd1c>
     7d5:      	xorl	%edx, %edx
     7d7:      	xorl	%eax, %eax
     7d9:      	movq	%rbp, 0x58(%rsp)
     7de:      	movq	%rbp, %r15
     7e1:      	orq	$0x2, %r15
     7e5:      	movq	0x48(%rsp), %rcx
     7ea:      	cmpw	0x8(%rcx), %ax
     7ee:      	movq	(%rip), %rbp            # 0x7f5 <kprobe_unwind_v8+0x7f5>
     7f5:      	jne	0x94c <kprobe_unwind_v8+0x94c>
     7fb:      	movl	$0x60, %eax
     800:      	movl	$0x70, %ecx
     805:      	movq	0xb0(%rsp), %rdi
     80d:      	movl	$0x60, %esi
     812:      	movq	%rdx, 0x68(%rsp)
     817:      	callq	*%rcx
     819:      	testq	%rax, %rax
     81c:      	je	0xb84 <kprobe_unwind_v8+0xb84>
     822:      	movl	$0x3b, 0x70(%rsp)
     82a:      	movq	(%rip), %rdi            # 0x831 <kprobe_unwind_v8+0x831>
     831:      	leaq	0x70(%rsp), %rsi
     836:      	movl	$0x1, %eax
     83b:      	callq	*%rax
     83d:      	testq	%rax, %rax
     840:      	jne	0x97a <kprobe_unwind_v8+0x97a>
     846:      	cmpl	$0x0, (%rbp)
     84a:      	je	0xbf2 <kprobe_unwind_v8+0xbf2>
     850:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     85a:      	movq	%rax, 0x26(%rsp)
     85f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     869:      	movq	%rax, 0x20(%rsp)
     86e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     878:      	movq	%rax, 0x18(%rsp)
     87d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     887:      	movq	%rax, 0x10(%rsp)
     88c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     896:      	movq	%rax, 0x8(%rsp)
     89b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     8a5:      	movq	%rax, (%rsp)
     8a9:      	movq	%rsp, %rdi
     8ac:      	movl	$0x2e, %eax
     8b1:      	movl	$0x6, %ecx
     8b6:      	jmp	0x181b <kprobe_unwind_v8+0x181b>
     8bb:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
     8c5:      	movq	%rax, 0x17(%rsp)
     8ca:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
     8d4:      	movq	%rax, 0x10(%rsp)
     8d9:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
     8e3:      	movq	%rax, 0x8(%rsp)
     8e8:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
     8f2:      	movq	%rax, (%rsp)
     8f6:      	movq	%rsp, %rdi
     8f9:      	movl	$0x1f, %eax
     8fe:      	movl	$0x6, %r9d
     904:      	movl	$0x1f, %esi
     909:      	movq	%rdx, %rbp
     90c:      	movq	%r13, %rdx
     90f:      	movq	%r12, %rcx
     912:      	movq	%rbp, %r8
     915:      	xorl	%eax, %eax
     917:      	callq	*%r9
     91a:      	movq	%rbp, %rdx
     91d:      	movq	(%rip), %rbp            # 0x924 <kprobe_unwind_v8+0x924>
     924:      	cmpq	%r12, %rdx
     927:      	jae	0xff <kprobe_unwind_v8+0xff>
     92d:      	jmp	0x202f <kprobe_unwind_v8+0x202f>
     932:      	xorl	%eax, %eax
     934:      	movq	%rbp, %rsi
     937:      	movq	0x48(%rsp), %r8
     93c:      	cmpw	0x4(%r8), %ax
     941:      	jae	0x48d <kprobe_unwind_v8+0x48d>
     947:      	jmp	0x494 <kprobe_unwind_v8+0x494>
     94c:      	cmpl	$0x0, (%rbp)
     950:      	jne	0x1624 <kprobe_unwind_v8+0x1624>
     956:      	movl	$0x3b, 0x70(%rsp)
     95e:      	movq	(%rip), %rdi            # 0x965 <kprobe_unwind_v8+0x965>
     965:      	leaq	0x70(%rsp), %rsi
     96a:      	movl	$0x1, %eax
     96f:      	callq	*%rax
     971:      	testq	%rax, %rax
     974:      	je	0xbe8 <kprobe_unwind_v8+0xbe8>
     97a:      	incq	(%rax)
     97d:      	jmp	0xbf2 <kprobe_unwind_v8+0xbf2>
     982:      	xorl	%eax, %eax
     984:      	movq	0x50(%rsp), %rsi
     989:      	movq	0x48(%rsp), %rcx
     98e:      	cmpw	0xa(%rcx), %ax
     992:      	je	0x5bf <kprobe_unwind_v8+0x5bf>
     998:      	movq	(%rip), %r15            # 0x99f <kprobe_unwind_v8+0x99f>
     99f:      	cmpl	$0x0, (%r15)
     9a3:      	jne	0x1461 <kprobe_unwind_v8+0x1461>
     9a9:      	movl	$0x3a, 0x70(%rsp)
     9b1:      	movq	(%rip), %rdi            # 0x9b8 <kprobe_unwind_v8+0x9b8>
     9b8:      	leaq	0x70(%rsp), %rsi
     9bd:      	movl	$0x1, %eax
     9c2:      	callq	*%rax
     9c4:      	testq	%rax, %rax
     9c7:      	jne	0x4c6 <kprobe_unwind_v8+0x4c6>
     9cd:      	cmpl	$0x0, (%r15)
     9d1:      	je	0x4d6 <kprobe_unwind_v8+0x4d6>
     9d7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     9e1:      	movq	%rax, 0x26(%rsp)
     9e6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     9f0:      	movq	%rax, 0x20(%rsp)
     9f5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     9ff:      	movq	%rax, 0x18(%rsp)
     a04:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     a0e:      	movq	%rax, 0x10(%rsp)
     a13:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     a1d:      	movq	%rax, 0x8(%rsp)
     a22:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     a2c:      	movq	%rax, (%rsp)
     a30:      	movq	%rsp, %rdi
     a33:      	movl	$0x2e, %eax
     a38:      	movl	$0x6, %ecx
     a3d:      	jmp	0x1136 <kprobe_unwind_v8+0x1136>
     a42:      	movabsq	$0xa646970207369, %rax  # imm = 0xA646970207369
     a4c:      	movq	%rax, 0x18(%rsp)
     a51:      	movabsq	$0x687420726f66206f, %rax # imm = 0x687420726F66206F
     a5b:      	movq	%rax, 0x10(%rsp)
     a60:      	movabsq	$0x666e49636f725038, %rax # imm = 0x666E49636F725038
     a6a:      	movq	%rax, 0x8(%rsp)
     a6f:      	movabsq	$0x56206f6e203a3876, %rax # imm = 0x56206F6E203A3876
     a79:      	movq	%rax, (%rsp)
     a7d:      	movq	%rsp, %rdi
     a80:      	movl	$0x20, %eax
     a85:      	movl	$0x6, %ecx
     a8a:      	movl	$0x20, %esi
     a8f:      	xorl	%eax, %eax
     a91:      	callq	*%rcx
     a93:      	jmp	0xa1 <kprobe_unwind_v8+0xa1>
     a98:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     aa2:      	movq	%rax, 0x26(%rsp)
     aa7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ab1:      	movq	%rax, 0x20(%rsp)
     ab6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ac0:      	movq	%rax, 0x18(%rsp)
     ac5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     acf:      	movq	%rax, 0x10(%rsp)
     ad4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     ade:      	movq	%rax, 0x8(%rsp)
     ae3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     aed:      	movq	%rax, (%rsp)
     af1:      	movq	%rsp, %rdi
     af4:      	movl	$0x2e, %eax
     af9:      	movl	$0x6, %ecx
     afe:      	movl	0x70(%rsp), %edx
     b02:      	movl	$0x2e, %esi
     b07:      	xorl	%eax, %eax
     b09:      	callq	*%rcx
     b0b:      	jmp	0xd7 <kprobe_unwind_v8+0xd7>
     b10:      	movabsq	$0xa747865746e6f, %rax  # imm = 0xA747865746E6F
     b1a:      	movq	%rax, 0x26(%rsp)
     b1f:      	movabsq	$0x6e6f63207265746e, %rax # imm = 0x6E6F63207265746E
     b29:      	movq	%rax, 0x20(%rsp)
     b2e:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
     b38:      	movq	%rax, 0x18(%rsp)
     b3d:      	movabsq	$0x662064616572206f, %rax # imm = 0x662064616572206F
     b47:      	movq	%rax, 0x10(%rsp)
     b4c:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     b56:      	movq	%rax, 0x8(%rsp)
     b5b:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
     b65:      	movq	%rax, (%rsp)
     b69:      	movq	%rsp, %rdi
     b6c:      	movl	$0x2e, %eax
     b71:      	movl	$0x6, %ecx
     b76:      	movl	$0x2e, %esi
     b7b:      	xorl	%eax, %eax
     b7d:      	callq	*%rcx
     b7f:      	jmp	0x142 <kprobe_unwind_v8+0x142>
     b84:      	movq	0x48(%rsp), %rax
     b89:      	movzbl	0x12(%rax), %ecx
     b8d:      	xorl	%ebp, %ebp
     b8f:      	cmpq	$0x5c, %rcx
     b93:      	ja	0x220 <kprobe_unwind_v8+0x220>
     b99:      	movq	0x48(%rsp), %rax
     b9e:      	movzbl	0x13(%rax), %eax
     ba2:      	cmpq	$0x5c, %rax
     ba6:      	ja	0x220 <kprobe_unwind_v8+0x220>
     bac:      	movq	0x48(%rsp), %rdx
     bb1:      	cmpb	$0x0, 0x10(%rdx)
     bb5:      	movzbl	0x11(%rdx), %edx
     bb9:      	movq	%rdx, 0x90(%rsp)
     bc1:      	je	0xd24 <kprobe_unwind_v8+0xd24>
     bc7:      	movq	0xb0(%rsp), %rdx
     bcf:      	movq	0x90(%rsp), %rsi
     bd7:      	movq	(%rdx,%rsi), %rsi
     bdb:      	movq	%rsi, 0x90(%rsp)
     be3:      	jmp	0xd39 <kprobe_unwind_v8+0xd39>
     be8:      	cmpl	$0x0, (%rbp)
     bec:      	jne	0x17b5 <kprobe_unwind_v8+0x17b5>
     bf2:      	xorl	%edx, %edx
     bf4:      	movzbl	0xf30(%r14), %ebp
     bfc:      	movq	(%rip), %rax            # 0xc03 <kprobe_unwind_v8+0xc03>
     c03:      	cmpl	$0x0, (%rax)
     c06:      	je	0x26c <kprobe_unwind_v8+0x26c>
     c0c:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
     c16:      	movq	%rax, 0x30(%rsp)
     c1b:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
     c25:      	movq	%rax, 0x28(%rsp)
     c2a:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
     c34:      	movq	%rax, 0x20(%rsp)
     c39:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
     c43:      	movq	%rax, 0x18(%rsp)
     c48:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
     c52:      	movq	%rax, 0x10(%rsp)
     c57:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
     c61:      	movq	%rax, 0x8(%rsp)
     c66:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
     c70:      	movq	%rax, (%rsp)
     c74:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
     c7c:      	movq	%rsp, %rdi
     c7f:      	movl	$0x3c, %eax
     c84:      	movl	$0x6, %r8d
     c8a:      	movl	$0x3c, %esi
     c8f:      	movq	%r15, %rcx
     c92:      	xorl	%eax, %eax
     c94:      	movq	%rdx, %r12
     c97:      	callq	*%r8
     c9a:      	movq	%r12, %rdx
     c9d:      	jmp	0x26c <kprobe_unwind_v8+0x26c>
     ca2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     cac:      	movq	%rax, 0x26(%rsp)
     cb1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     cbb:      	movq	%rax, 0x20(%rsp)
     cc0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     cca:      	movq	%rax, 0x18(%rsp)
     ccf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     cd9:      	movq	%rax, 0x10(%rsp)
     cde:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     ce8:      	movq	%rax, 0x8(%rsp)
     ced:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     cf7:      	movq	%rax, (%rsp)
     cfb:      	movq	%rsp, %rdi
     cfe:      	movl	$0x2e, %eax
     d03:      	movl	$0x6, %ecx
     d08:      	movl	0x70(%rsp), %edx
     d0c:      	movl	$0x2e, %esi
     d11:      	xorl	%eax, %eax
     d13:      	callq	*%rcx
     d15:      	jmp	0x1e5 <kprobe_unwind_v8+0x1e5>
     d1a:      	xorl	%eax, %eax
     d1c:      	movq	%r15, %rdx
     d1f:      	jmp	0x7d9 <kprobe_unwind_v8+0x7d9>
     d24:      	movq	0x90(%rsp), %rdx
     d2c:      	addq	0x68(%rsp), %rdx
     d31:      	movq	%rdx, 0x90(%rsp)
     d39:      	movq	0xb0(%rsp), %rdx
     d41:      	movl	(%rdx,%rcx), %esi
     d44:      	movq	0x48(%rsp), %rcx
     d49:      	movzbl	0x17(%rcx), %edi
     d4d:      	movl	%edi, 0xac(%rsp)
     d54:      	movzbl	0x18(%rcx), %ecx
     d58:      	movq	%rsi, 0xb8(%rsp)
     d60:      	addq	0x90(%rsp), %rsi
     d68:      	movq	%rsi, 0xa0(%rsp)
     d70:      	andl	(%rdx,%rax), %ecx
     d73:      	movl	%ecx, 0xc0(%rsp)
     d7a:      	movq	(%rip), %rax            # 0xd81 <kprobe_unwind_v8+0xd81>
     d81:      	cmpl	$0x0, (%rax)
     d84:      	jne	0x182d <kprobe_unwind_v8+0x182d>
     d8a:      	cmpq	0x90(%rsp), %r13
     d92:      	jb	0xdf1 <kprobe_unwind_v8+0xdf1>
     d94:      	cmpq	0xa0(%rsp), %r13
     d9c:      	jae	0xdf1 <kprobe_unwind_v8+0xdf1>
     d9e:      	movl	0xac(%rsp), %eax
     da5:      	shrxl	%eax, 0xc0(%rsp), %eax
     daf:      	movq	0x48(%rsp), %rcx
     db4:      	movzbl	0x19(%rcx), %ecx
     db8:      	movq	0x50(%rsp), %rdx
     dbd:      	orq	$0x4, %rdx
     dc1:      	movq	0x68(%rsp), %r15
     dc6:      	orq	$0x3, %r15
     dca:      	cmpl	%ecx, %eax
     dcc:      	cmoveq	%rdx, %r15
     dd0:      	movq	0xb8(%rsp), %rdx
     dd8:      	shll	$0x4, %edx
     ddb:      	orl	%eax, %edx
     ddd:      	subq	0x90(%rsp), %r13
     de5:      	shlq	$0x20, %rdx
     de9:      	orq	%r13, %rdx
     dec:      	jmp	0xbf4 <kprobe_unwind_v8+0xbf4>
     df1:      	cmpl	$0x0, 0x2c0(%r14)
     df9:      	je	0xe12 <kprobe_unwind_v8+0xe12>
     dfb:      	movq	(%rip), %rax            # 0xe02 <kprobe_unwind_v8+0xe02>
     e02:      	cmpl	$0x0, (%rax)
     e05:      	jne	0x2470 <kprobe_unwind_v8+0x2470>
     e0b:      	xorl	%edx, %edx
     e0d:      	jmp	0x264 <kprobe_unwind_v8+0x264>
     e12:      	addq	$-0x18, %r12
     e16:      	leaq	0x70(%rsp), %rdi
     e1b:      	movl	$0x18, %eax
     e20:      	movl	$0x70, %ecx
     e25:      	movl	$0x18, %esi
     e2a:      	movq	%r12, %rdx
     e2d:      	callq	*%rcx
     e2f:      	testq	%rax, %rax
     e32:      	je	0xfb3 <kprobe_unwind_v8+0xfb3>
     e38:      	movq	(%rip), %rax            # 0xe3f <kprobe_unwind_v8+0xe3f>
     e3f:      	cmpl	$0x0, (%rax)
     e42:      	jne	0x255c <kprobe_unwind_v8+0x255c>
     e48:      	movl	$0x39, 0x64(%rsp)
     e50:      	movq	(%rip), %rdi            # 0xe57 <kprobe_unwind_v8+0xe57>
     e57:      	leaq	0x64(%rsp), %rsi
     e5c:      	movl	$0x1, %eax
     e61:      	callq	*%rax
     e63:      	testq	%rax, %rax
     e66:      	je	0x1148 <kprobe_unwind_v8+0x1148>
     e6c:      	incq	(%rax)
     e6f:      	jmp	0x1158 <kprobe_unwind_v8+0x1158>
     e74:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
     e7e:      	movq	%rax, 0x15(%rsp)
     e83:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
     e8d:      	movq	%rax, 0x10(%rsp)
     e92:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
     e9c:      	movq	%rax, 0x8(%rsp)
     ea1:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
     eab:      	movq	%rax, (%rsp)
     eaf:      	movq	%rsp, %rdi
     eb2:      	movl	$0x1d, %eax
     eb7:      	movl	$0x6, %ecx
     ebc:      	xorl	%r15d, %r15d
     ebf:      	movl	$0x1d, %esi
     ec4:      	xorl	%eax, %eax
     ec6:      	movq	%rdx, %r12
     ec9:      	callq	*%rcx
     ecb:      	movq	%r12, %rdx
     ece:      	jmp	0xbf4 <kprobe_unwind_v8+0xbf4>
     ed3:      	movabsq	$0x7825203d3c207825, %rcx # imm = 0x7825203D3C207825
     edd:      	movq	%rcx, 0x20(%rsp)
     ee2:      	movabsq	$0x203d3c207825203a, %rcx # imm = 0x203D3C207825203A
     eec:      	movq	%rcx, 0x18(%rsp)
     ef1:      	movabsq	$0x6e6f6974636e7546, %rcx # imm = 0x6E6F6974636E7546
     efb:      	movq	%rcx, 0x10(%rsp)
     f00:      	movabsq	$0x534a206120746f6e, %rcx # imm = 0x534A206120746F6E
     f0a:      	movq	%rcx, 0x8(%rsp)
     f0f:      	movzwl	%ax, %ecx
     f12:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
     f1c:      	movq	%rax, (%rsp)
     f20:      	movw	$0xa, 0x28(%rsp)
     f27:      	movq	%rsp, %rdi
     f2a:      	movl	$0x2a, %eax
     f2f:      	movl	$0x6, %r9d
     f35:      	movzwl	0x4(%r8), %edx
     f3a:      	movzwl	0x6(%r8), %r8d
     f3f:      	movl	$0x2a, %esi
     f44:      	xorl	%eax, %eax
     f46:      	callq	*%r9
     f49:      	jmp	0x4a6 <kprobe_unwind_v8+0x4a6>
     f4e:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
     f58:      	movq	%rax, 0x1d(%rsp)
     f5d:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
     f67:      	movq	%rax, 0x18(%rsp)
     f6c:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
     f76:      	movq	%rax, 0x10(%rsp)
     f7b:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
     f85:      	movq	%rax, 0x8(%rsp)
     f8a:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
     f94:      	movq	%rax, (%rsp)
     f98:      	movq	%rsp, %rdi
     f9b:      	movl	$0x25, %eax
     fa0:      	movl	$0x6, %ecx
     fa5:      	movl	$0x25, %esi
     faa:      	xorl	%eax, %eax
     fac:      	callq	*%rcx
     fae:      	jmp	0x28e <kprobe_unwind_v8+0x28e>
     fb3:      	movq	0x80(%rsp), %r13
     fbb:      	cmpq	0x90(%rsp), %r13
     fc3:      	jb	0xfcf <kprobe_unwind_v8+0xfcf>
     fc5:      	cmpq	0xa0(%rsp), %r13
     fcd:      	jb	0x1009 <kprobe_unwind_v8+0x1009>
     fcf:      	movq	0x78(%rsp), %r13
     fd4:      	cmpq	0x90(%rsp), %r13
     fdc:      	jb	0xfe8 <kprobe_unwind_v8+0xfe8>
     fde:      	cmpq	0xa0(%rsp), %r13
     fe6:      	jb	0x1009 <kprobe_unwind_v8+0x1009>
     fe8:      	movq	0x70(%rsp), %r13
     fed:      	cmpq	0x90(%rsp), %r13
     ff5:      	jb	0x1584 <kprobe_unwind_v8+0x1584>
     ffb:      	cmpq	0xa0(%rsp), %r13
    1003:      	jae	0x1584 <kprobe_unwind_v8+0x1584>
    1009:      	movq	(%rip), %rax            # 0x1010 <kprobe_unwind_v8+0x1010>
    1010:      	cmpl	$0x0, (%rax)
    1013:      	je	0xd9e <kprobe_unwind_v8+0xd9e>
    1019:      	movabsq	$0xa786c25203a6b, %rax  # imm = 0xA786C25203A6B
    1023:      	movq	%rax, 0x1f(%rsp)
    1028:      	movabsq	$0x6b63617473206d6f, %rax # imm = 0x6B63617473206D6F
    1032:      	movq	%rax, 0x18(%rsp)
    1037:      	movabsq	$0x7266206465726576, %rax # imm = 0x7266206465726576
    1041:      	movq	%rax, 0x10(%rsp)
    1046:      	movabsq	$0x6f63657220637020, %rax # imm = 0x6F63657220637020
    1050:      	movq	%rax, 0x8(%rsp)
    1055:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    105f:      	movq	%rax, (%rsp)
    1063:      	movq	%rsp, %rdi
    1066:      	movl	$0x27, %eax
    106b:      	movl	$0x6, %ecx
    1070:      	movl	$0x27, %esi
    1075:      	movq	%r13, %rdx
    1078:      	xorl	%eax, %eax
    107a:      	callq	*%rcx
    107c:      	jmp	0xd9e <kprobe_unwind_v8+0xd9e>
    1081:      	movabsq	$0x746e696f7020656d, %rax # imm = 0x746E696F7020656D
    108b:      	movq	%rax, 0x10(%rsp)
    1090:      	movabsq	$0x6172662064616220, %rax # imm = 0x6172662064616220
    109a:      	movq	%rax, 0x8(%rsp)
    109f:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    10a9:      	movq	%rax, (%rsp)
    10ad:      	movl	$0xa7265, 0x18(%rsp)    # imm = 0xA7265
    10b5:      	movq	%rsp, %rdi
    10b8:      	movl	$0x1c, %eax
    10bd:      	movl	$0x6, %ecx
    10c2:      	movl	$0x1c, %esi
    10c7:      	xorl	%eax, %eax
    10c9:      	callq	*%rcx
    10cb:      	jmp	0x3e3 <kprobe_unwind_v8+0x3e3>
    10d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10da:      	movq	%rax, 0x26(%rsp)
    10df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10e9:      	movq	%rax, 0x20(%rsp)
    10ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10f8:      	movq	%rax, 0x18(%rsp)
    10fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1107:      	movq	%rax, 0x10(%rsp)
    110c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1116:      	movq	%rax, 0x8(%rsp)
    111b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1125:      	movq	%rax, (%rsp)
    1129:      	movq	%rsp, %rdi
    112c:      	movl	$0x2e, %eax
    1131:      	movl	$0x6, %ecx
    1136:      	movl	0x70(%rsp), %edx
    113a:      	movl	$0x2e, %esi
    113f:      	xorl	%eax, %eax
    1141:      	callq	*%rcx
    1143:      	jmp	0x4d6 <kprobe_unwind_v8+0x4d6>
    1148:      	movq	(%rip), %rax            # 0x114f <kprobe_unwind_v8+0x114f>
    114f:      	cmpl	$0x0, (%rax)
    1152:      	jne	0x2679 <kprobe_unwind_v8+0x2679>
    1158:      	movl	$0x1388, %r12d          # imm = 0x1388
    115e:      	jmp	0x2070 <kprobe_unwind_v8+0x2070>
    1163:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    116d:      	movq	%rax, 0x26(%rsp)
    1172:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    117c:      	movq	%rax, 0x20(%rsp)
    1181:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    118b:      	movq	%rax, 0x18(%rsp)
    1190:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    119a:      	movq	%rax, 0x10(%rsp)
    119f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    11a9:      	movq	%rax, 0x8(%rsp)
    11ae:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11b8:      	movq	%rax, (%rsp)
    11bc:      	movq	%rsp, %rdi
    11bf:      	movl	$0x2e, %eax
    11c4:      	movl	$0x6, %ecx
    11c9:      	movl	0x70(%rsp), %edx
    11cd:      	movl	$0x2e, %esi
    11d2:      	xorl	%eax, %eax
    11d4:      	callq	*%rcx
    11d6:      	jmp	0x5fc <kprobe_unwind_v8+0x5fc>
    11db:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    11e5:      	movq	%rax, 0x17(%rsp)
    11ea:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    11f4:      	movq	%rax, 0x10(%rsp)
    11f9:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    1203:      	movq	%rax, 0x8(%rsp)
    1208:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    1212:      	movq	%rax, (%rsp)
    1216:      	movq	%rsp, %rdi
    1219:      	movl	$0x1f, %eax
    121e:      	movl	$0x6, %r9d
    1224:      	movq	0xed0(%r14), %rdx
    122b:      	movq	0xed8(%r14), %rcx
    1232:      	movq	0xee0(%r14), %r8
    1239:      	movl	$0x1f, %esi
    123e:      	xorl	%eax, %eax
    1240:      	callq	*%r9
    1243:      	jmp	0x64a <kprobe_unwind_v8+0x64a>
    1248:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    1252:      	movq	%rax, 0x28(%rsp)
    1257:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    1261:      	movq	%rax, 0x20(%rsp)
    1266:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    1270:      	movq	%rax, 0x18(%rsp)
    1275:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    127f:      	movq	%rax, 0x10(%rsp)
    1284:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    128e:      	movq	%rax, 0x8(%rsp)
    1293:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    129d:      	movq	%rax, (%rsp)
    12a1:      	movb	$0x0, 0x30(%rsp)
    12a6:      	movq	%rsp, %rdi
    12a9:      	movl	$0x31, %eax
    12ae:      	movl	$0x6, %ecx
    12b3:      	movl	0x2c0(%r14), %edx
    12ba:      	movl	$0x31, %esi
    12bf:      	xorl	%eax, %eax
    12c1:      	callq	*%rcx
    12c3:      	movq	0xed0(%r14), %r12
    12ca:      	movq	%r12, %rax
    12cd:      	shrq	$0x38, %rax
    12d1:      	jne	0x6a5 <kprobe_unwind_v8+0x6a5>
    12d7:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    12de:      	ja	0x1301 <kprobe_unwind_v8+0x1301>
    12e0:      	cmpl	$0x0, (%r13)
    12e5:      	jne	0x2870 <kprobe_unwind_v8+0x2870>
    12eb:      	movl	$0x31, 0xf28(%r14)
    12f6:      	movl	$0xfae, %r12d           # imm = 0xFAE
    12fc:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
    1301:      	movl	(%r14), %eax
    1304:      	movl	$0x60, 0x70(%rsp)
    130c:      	movbel	%eax, 0x74(%rsp)
    1312:      	movbeq	%r12, 0x78(%rsp)
    1319:      	movq	(%rip), %rdi            # 0x1320 <kprobe_unwind_v8+0x1320>
    1320:      	leaq	0x70(%rsp), %rsi
    1325:      	movl	$0x1, %eax
    132a:      	callq	*%rax
    132c:      	testq	%rax, %rax
    132f:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    1335:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    133f:      	movq	0x8(%rax), %rbp
    1343:      	movq	%rbp, %rcx
    1346:      	andq	%rdx, %rcx
    1349:      	movq	%rcx, 0xf20(%r14)
    1350:      	movq	(%rax), %rax
    1353:      	movq	%rax, 0xf10(%r14)
    135a:      	shrq	$0x38, %rbp
    135e:      	movq	%r12, %rax
    1361:      	subq	%rcx, %rax
    1364:      	movq	%rax, 0xf18(%r14)
    136b:      	movq	(%rip), %rax            # 0x1372 <kprobe_unwind_v8+0x1372>
    1372:      	cmpl	$0x0, (%rax)
    1375:      	jne	0x16a6 <kprobe_unwind_v8+0x16a6>
    137b:      	cmpl	$0x1, %ebp
    137e:      	jne	0x19d9 <kprobe_unwind_v8+0x19d9>
    1384:      	movq	0xf10(%r14), %rax
    138b:      	movq	%rax, 0x70(%rsp)
    1390:      	movq	0xf18(%r14), %r13
    1397:      	movq	(%rip), %rdi            # 0x139e <kprobe_unwind_v8+0x139e>
    139e:      	leaq	0x70(%rsp), %rsi
    13a3:      	movl	$0x1, %eax
    13a8:      	callq	*%rax
    13aa:      	movl	$0x1, %ebp
    13af:      	testq	%rax, %rax
    13b2:      	je	0x19d9 <kprobe_unwind_v8+0x19d9>
    13b8:      	movq	%rax, %r12
    13bb:      	cmpq	%r13, (%rax)
    13be:      	ja	0x13c7 <kprobe_unwind_v8+0x13c7>
    13c0:      	cmpq	%r13, 0x8(%r12)
    13c5:      	jae	0x13dd <kprobe_unwind_v8+0x13dd>
    13c7:      	cmpq	%r13, 0x10(%r12)
    13cc:      	ja	0x19d9 <kprobe_unwind_v8+0x19d9>
    13d2:      	cmpq	%r13, 0x18(%r12)
    13d7:      	jb	0x19d9 <kprobe_unwind_v8+0x19d9>
    13dd:      	movq	(%rip), %rax            # 0x13e4 <kprobe_unwind_v8+0x13e4>
    13e4:      	cmpl	$0x0, (%rax)
    13e7:      	jne	0x1932 <kprobe_unwind_v8+0x1932>
    13ed:      	movl	0x1380(%r14), %eax
    13f4:      	movl	0x20(%r12), %ecx
    13f9:      	btl	%ecx, %eax
    13fc:      	jae	0x199e <kprobe_unwind_v8+0x199e>
    1402:      	movq	(%rip), %rax            # 0x1409 <kprobe_unwind_v8+0x1409>
    1409:      	cmpl	$0x0, (%rax)
    140c:      	je	0x19d9 <kprobe_unwind_v8+0x19d9>
    1412:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    141c:      	movq	%rax, 0x10(%rsp)
    1421:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    142b:      	movq	%rax, 0x8(%rsp)
    1430:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    143a:      	movq	%rax, (%rsp)
    143e:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    1446:      	movq	%rsp, %rdi
    1449:      	movl	$0x1b, %eax
    144e:      	movl	$0x6, %ecx
    1453:      	movl	$0x1b, %esi
    1458:      	xorl	%eax, %eax
    145a:      	callq	*%rcx
    145c:      	jmp	0x19d9 <kprobe_unwind_v8+0x19d9>
    1461:      	movabsq	$0xa6f666e496e6f, %rax  # imm = 0xA6F666E496E6F
    146b:      	movq	%rax, 0x17(%rsp)
    1470:      	movabsq	$0x6f6974636e754664, %rax # imm = 0x6F6974636E754664
    147a:      	movq	%rax, 0x10(%rsp)
    147f:      	movabsq	$0x6572616853206f6e, %rax # imm = 0x6572616853206F6E
    1489:      	movq	%rax, 0x8(%rsp)
    148e:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    1498:      	movq	%rax, (%rsp)
    149c:      	movq	%rsp, %rdi
    149f:      	movl	$0x1f, %eax
    14a4:      	movl	$0x6, %ecx
    14a9:      	movl	$0x1f, %esi
    14ae:      	xorl	%eax, %eax
    14b0:      	callq	*%rcx
    14b2:      	jmp	0x9a9 <kprobe_unwind_v8+0x9a9>
    14b7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    14c1:      	movq	%rax, 0x26(%rsp)
    14c6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    14d0:      	movq	%rax, 0x20(%rsp)
    14d5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    14df:      	movq	%rax, 0x18(%rsp)
    14e4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    14ee:      	movq	%rax, 0x10(%rsp)
    14f3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    14fd:      	movq	%rax, 0x8(%rsp)
    1502:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    150c:      	movq	%rax, (%rsp)
    1510:      	movq	%rsp, %rdi
    1513:      	movl	$0x2e, %eax
    1518:      	movl	$0x6, %ecx
    151d:      	movl	0x70(%rsp), %edx
    1521:      	movl	$0x2e, %esi
    1526:      	xorl	%eax, %eax
    1528:      	callq	*%rcx
    152a:      	jmp	0x66d <kprobe_unwind_v8+0x66d>
    152f:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    1539:      	movq	%rax, 0x10(%rsp)
    153e:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    1548:      	movq	%rax, 0x8(%rsp)
    154d:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    1557:      	movq	%rax, (%rsp)
    155b:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    1563:      	movq	%rsp, %rdi
    1566:      	movl	$0x1c, %eax
    156b:      	movl	$0x6, %ecx
    1570:      	movl	$0x1c, %esi
    1575:      	xorl	%eax, %eax
    1577:      	movq	%rdx, %r15
    157a:      	callq	*%rcx
    157c:      	movq	%r15, %rdx
    157f:      	jmp	0x5e6 <kprobe_unwind_v8+0x5e6>
    1584:      	movq	(%rip), %rax            # 0x158b <kprobe_unwind_v8+0x158b>
    158b:      	cmpl	$0x0, (%rax)
    158e:      	je	0xbf2 <kprobe_unwind_v8+0xbf2>
    1594:      	movabsq	$0x6c2520786c252078, %rax # imm = 0x6C2520786C252078
    159e:      	movq	%rax, 0x28(%rsp)
    15a3:      	movabsq	$0x6c2520706f74206b, %rax # imm = 0x6C2520706F74206B
    15ad:      	movq	%rax, 0x20(%rsp)
    15b2:      	movabsq	$0x63617473203a626f, %rax # imm = 0x63617473203A626F
    15bc:      	movq	%rax, 0x18(%rsp)
    15c1:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    15cb:      	movq	%rax, 0x10(%rsp)
    15d0:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    15da:      	movq	%rax, 0x8(%rsp)
    15df:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    15e9:      	movq	%rax, (%rsp)
    15ed:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    15f5:      	movq	%rsp, %rdi
    15f8:      	movl	$0x33, %eax
    15fd:      	movl	$0x6, %r9d
    1603:      	movq	0x80(%rsp), %rdx
    160b:      	movq	0x70(%rsp), %r8
    1610:      	movq	0x78(%rsp), %rcx
    1615:      	movl	$0x33, %esi
    161a:      	xorl	%eax, %eax
    161c:      	callq	*%r9
    161f:      	jmp	0xbf2 <kprobe_unwind_v8+0xbf2>
    1624:      	movzwl	%ax, %r8d
    1628:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    1632:      	movq	%rax, 0x26(%rsp)
    1637:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    1641:      	movq	%rax, 0x20(%rsp)
    1646:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    1650:      	movq	%rax, 0x18(%rsp)
    1655:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    165f:      	movq	%rax, 0x10(%rsp)
    1664:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    166e:      	movq	%rax, 0x8(%rsp)
    1673:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    167d:      	movq	%rax, (%rsp)
    1681:      	movq	%rsp, %rdi
    1684:      	movl	$0x2e, %eax
    1689:      	movl	$0x6, %r9d
    168f:      	movl	$0x2e, %esi
    1694:      	movq	%rdx, %rcx
    1697:      	movq	0x50(%rsp), %rdx
    169c:      	xorl	%eax, %eax
    169e:      	callq	*%r9
    16a1:      	jmp	0x956 <kprobe_unwind_v8+0x956>
    16a6:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    16b0:      	movq	%rax, 0x28(%rsp)
    16b5:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    16bf:      	movq	%rax, 0x20(%rsp)
    16c4:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    16ce:      	movq	%rax, 0x18(%rsp)
    16d3:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    16dd:      	movq	%rax, 0x10(%rsp)
    16e2:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    16ec:      	movq	%rax, 0x8(%rsp)
    16f1:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    16fb:      	movq	%r13, (%rsp)
    16ff:      	movw	$0xa, 0x30(%rsp)
    1706:      	movq	%rsp, %rdi
    1709:      	movl	$0x32, %eax
    170e:      	movl	$0x6, %r9d
    1714:      	movq	0xf10(%r14), %rcx
    171b:      	movl	$0x32, %esi
    1720:      	movq	%r12, %rdx
    1723:      	movl	%ebp, %r8d
    1726:      	xorl	%eax, %eax
    1728:      	callq	*%r9
    172b:      	movq	(%rip), %rax            # 0x1732 <kprobe_unwind_v8+0x1732>
    1732:      	cmpl	$0x0, (%rax)
    1735:      	je	0x137b <kprobe_unwind_v8+0x137b>
    173b:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    1745:      	movq	%rax, 0x27(%rsp)
    174a:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    1754:      	movq	%rax, 0x20(%rsp)
    1759:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1763:      	movq	%rax, 0x18(%rsp)
    1768:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1772:      	movq	%rax, 0x10(%rsp)
    1777:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1781:      	movq	%rax, 0x8(%rsp)
    1786:      	movq	%r13, (%rsp)
    178a:      	movq	%rsp, %rdi
    178d:      	movl	$0x2f, %eax
    1792:      	movl	$0x6, %r8d
    1798:      	movq	0xf18(%r14), %rcx
    179f:      	movq	0xf20(%r14), %rdx
    17a6:      	movl	$0x2f, %esi
    17ab:      	xorl	%eax, %eax
    17ad:      	callq	*%r8
    17b0:      	jmp	0x137b <kprobe_unwind_v8+0x137b>
    17b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17bf:      	movq	%rax, 0x26(%rsp)
    17c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    17ce:      	movq	%rax, 0x20(%rsp)
    17d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17dd:      	movq	%rax, 0x18(%rsp)
    17e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17ec:      	movq	%rax, 0x10(%rsp)
    17f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17fb:      	movq	%rax, 0x8(%rsp)
    1800:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    180a:      	movq	%rax, (%rsp)
    180e:      	movq	%rsp, %rdi
    1811:      	movl	$0x2e, %eax
    1816:      	movl	$0x6, %ecx
    181b:      	movl	0x70(%rsp), %edx
    181f:      	movl	$0x2e, %esi
    1824:      	xorl	%eax, %eax
    1826:      	callq	*%rcx
    1828:      	jmp	0xbf2 <kprobe_unwind_v8+0xbf2>
    182d:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    1837:      	movq	%rax, 0x20(%rsp)
    183c:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    1846:      	movq	%rax, 0x18(%rsp)
    184b:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    1855:      	movq	%rax, 0x10(%rsp)
    185a:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    1864:      	movq	%rax, 0x8(%rsp)
    1869:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    1873:      	movq	%rax, (%rsp)
    1877:      	movb	$0x0, 0x28(%rsp)
    187c:      	movq	%rsp, %rdi
    187f:      	movl	$0x29, %eax
    1884:      	movl	$0x6, %r9d
    188a:      	movl	$0x29, %esi
    188f:      	movq	0x50(%rsp), %rdx
    1894:      	movq	0x58(%rsp), %rcx
    1899:      	movq	0x68(%rsp), %r8
    189e:      	xorl	%eax, %eax
    18a0:      	callq	*%r9
    18a3:      	movq	(%rip), %rax            # 0x18aa <kprobe_unwind_v8+0x18aa>
    18aa:      	cmpl	$0x0, (%rax)
    18ad:      	je	0xd8a <kprobe_unwind_v8+0xd8a>
    18b3:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    18bd:      	movq	%rax, 0x1d(%rsp)
    18c2:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    18cc:      	movq	%rax, 0x18(%rsp)
    18d1:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    18db:      	movq	%rax, 0x10(%rsp)
    18e0:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    18ea:      	movq	%rax, 0x8(%rsp)
    18ef:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    18f9:      	movq	%rax, (%rsp)
    18fd:      	movq	%rsp, %rdi
    1900:      	movl	$0x25, %eax
    1905:      	movl	$0x6, %r9d
    190b:      	movl	$0x25, %esi
    1910:      	movq	0x90(%rsp), %rdx
    1918:      	movq	0xa0(%rsp), %rcx
    1920:      	movq	0xb8(%rsp), %r8
    1928:      	xorl	%eax, %eax
    192a:      	callq	*%r9
    192d:      	jmp	0xd8a <kprobe_unwind_v8+0xd8a>
    1932:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    193c:      	movq	%rax, 0x16(%rsp)
    1941:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    194b:      	movq	%rax, 0x10(%rsp)
    1950:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    195a:      	movq	%rax, 0x8(%rsp)
    195f:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    1969:      	movq	%rax, (%rsp)
    196d:      	movq	%rsp, %rdi
    1970:      	movl	$0x1e, %eax
    1975:      	movl	$0x6, %ecx
    197a:      	movzwl	0x20(%r12), %edx
    1980:      	movl	$0x1e, %esi
    1985:      	xorl	%eax, %eax
    1987:      	callq	*%rcx
    1989:      	movl	0x1380(%r14), %eax
    1990:      	movl	0x20(%r12), %ecx
    1995:      	btl	%ecx, %eax
    1998:      	jb	0x1402 <kprobe_unwind_v8+0x1402>
    199e:      	movl	$0x0, 0x64(%rsp)
    19a6:      	movq	(%rip), %rdi            # 0x19ad <kprobe_unwind_v8+0x19ad>
    19ad:      	leaq	0x64(%rsp), %rsi
    19b2:      	movl	$0x1, %eax
    19b7:      	callq	*%rax
    19b9:      	testq	%rax, %rax
    19bc:      	je	0x19c3 <kprobe_unwind_v8+0x19c3>
    19be:      	incq	(%rax)
    19c1:      	jmp	0x19d3 <kprobe_unwind_v8+0x19d3>
    19c3:      	movq	(%rip), %rax            # 0x19ca <kprobe_unwind_v8+0x19ca>
    19ca:      	cmpl	$0x0, (%rax)
    19cd:      	jne	0x24e4 <kprobe_unwind_v8+0x24e4>
    19d3:      	movzwl	0x20(%r12), %ebp
    19d9:      	xorl	%r12d, %r12d
    19dc:      	cmpl	$0x7, %ebp
    19df:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    19e5:      	movq	0xed0(%r14), %r13
    19ec:      	movq	0xed8(%r14), %r12
    19f3:      	movq	0xee0(%r14), %rbp
    19fa:      	movq	(%rip), %rax            # 0x1a01 <kprobe_unwind_v8+0x1a01>
    1a01:      	cmpl	$0x0, (%rax)
    1a04:      	jne	0x1fc0 <kprobe_unwind_v8+0x1fc0>
    1a0a:      	cmpq	%r12, %rbp
    1a0d:      	jb	0x2025 <kprobe_unwind_v8+0x2025>
    1a13:      	leaq	0x2000(%r12), %rax
    1a1b:      	cmpq	%rax, %rbp
    1a1e:      	jae	0x2025 <kprobe_unwind_v8+0x2025>
    1a24:      	addq	$-0x40, %rbp
    1a28:      	movl	$0x40, %eax
    1a2d:      	movl	$0x70, %ecx
    1a32:      	movq	0x98(%rsp), %rdi
    1a3a:      	movl	$0x40, %esi
    1a3f:      	movq	%rbp, %rdx
    1a42:      	callq	*%rcx
    1a44:      	testq	%rax, %rax
    1a47:      	movq	(%rip), %rbp            # 0x1a4e <kprobe_unwind_v8+0x1a4e>
    1a4e:      	jne	0x138 <kprobe_unwind_v8+0x138>
    1a54:      	movq	0x48(%rsp), %rax
    1a59:      	movzbl	0x14(%rax), %ecx
    1a5d:      	xorl	%ebp, %ebp
    1a5f:      	cmpq	$0x38, %rcx
    1a63:      	ja	0x220 <kprobe_unwind_v8+0x220>
    1a69:      	movq	0x48(%rsp), %rax
    1a6e:      	movzbl	0x15(%rax), %eax
    1a72:      	cmpq	$0x38, %rax
    1a76:      	ja	0x220 <kprobe_unwind_v8+0x220>
    1a7c:      	movq	0x48(%rsp), %rdx
    1a81:      	movzbl	0x16(%rdx), %edx
    1a85:      	cmpq	$0x38, %rdx
    1a89:      	ja	0x220 <kprobe_unwind_v8+0x220>
    1a8f:      	movq	0x98(%rsp), %rsi
    1a97:      	movq	(%rsi,%rcx), %rbp
    1a9b:      	testb	$0x1, %bpl
    1a9f:      	jne	0x1bbd <kprobe_unwind_v8+0x1bbd>
    1aa5:      	shrq	%rbp
    1aa8:      	movq	(%rip), %rax            # 0x1aaf <kprobe_unwind_v8+0x1aaf>
    1aaf:      	cmpl	$0x0, (%rax)
    1ab2:      	jne	0x26f7 <kprobe_unwind_v8+0x26f7>
    1ab8:      	xorl	%r15d, %r15d
    1abb:      	movzbl	0xf30(%r14), %r12d
    1ac3:      	movl	0x2c0(%r14), %eax
    1aca:      	cmpq	$0x7e, %rax
    1ace:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    1ad4:      	leal	0x1(%rax), %ecx
    1ad7:      	movl	%ecx, 0x2c0(%r14)
    1ade:      	leaq	(%rax,%rax,2), %rax
    1ae2:      	movq	%r15, 0x2d0(%r14,%rax,8)
    1aea:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    1af2:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    1afb:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    1b03:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    1b0f:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    1b1a:      	movq	0xee0(%r14), %rax
    1b21:      	movq	%rsp, %rdi
    1b24:      	movl	$0x10, %ecx
    1b29:      	movl	$0x70, %r8d
    1b2f:      	movq	0xee0(%r14), %rdx
    1b36:      	movl	$0x10, %esi
    1b3b:      	callq	*%r8
    1b3e:      	testq	%rax, %rax
    1b41:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    1b47:      	movq	0xee0(%r14), %rax
    1b4e:      	addq	$0x10, %rax
    1b52:      	movq	%rax, 0xed8(%r14)
    1b59:      	movq	(%rsp), %rax
    1b5d:      	movq	%rax, 0xee0(%r14)
    1b64:      	movq	0x8(%rsp), %rax
    1b69:      	movq	%rax, 0xed0(%r14)
    1b70:      	movb	$0x1, 0xf30(%r14)
    1b78:      	movq	(%rip), %rax            # 0x1b7f <kprobe_unwind_v8+0x1b7f>
    1b7f:      	cmpl	$0x0, (%rax)
    1b82:      	jne	0x2753 <kprobe_unwind_v8+0x2753>
    1b88:      	movl	$0x38, 0x70(%rsp)
    1b90:      	movq	(%rip), %rdi            # 0x1b97 <kprobe_unwind_v8+0x1b97>
    1b97:      	leaq	0x70(%rsp), %rsi
    1b9c:      	movl	$0x1, %eax
    1ba1:      	callq	*%rax
    1ba3:      	testq	%rax, %rax
    1ba6:      	je	0x1d76 <kprobe_unwind_v8+0x1d76>
    1bac:      	incq	(%rax)
    1baf:      	movq	(%rip), %rax            # 0x1bb6 <kprobe_unwind_v8+0x1bb6>
    1bb6:      	movl	(%rax), %eax
    1bb8:      	jmp	0x1d88 <kprobe_unwind_v8+0x1d88>
    1bbd:      	movq	0x98(%rsp), %rcx
    1bc5:      	movq	(%rcx,%rdx), %r15
    1bc9:      	movq	(%rcx,%rax), %r12
    1bcd:      	movl	%r12d, %ecx
    1bd0:      	andl	$0x3, %ecx
    1bd3:      	andq	$-0x4, %r12
    1bd7:      	xorl	%eax, %eax
    1bd9:      	cmpl	$0x1, %ecx
    1bdc:      	cmovneq	%rax, %r12
    1be0:      	testq	%r12, %r12
    1be3:      	je	0x1c54 <kprobe_unwind_v8+0x1c54>
    1be5:      	movq	0x48(%rsp), %rax
    1bea:      	movzbl	0xc(%rax), %edx
    1bee:      	addq	%r12, %rdx
    1bf1:      	movq	%rsp, %rdi
    1bf4:      	movl	$0x8, %eax
    1bf9:      	movl	$0x70, %ecx
    1bfe:      	movl	$0x8, %esi
    1c03:      	callq	*%rcx
    1c05:      	testq	%rax, %rax
    1c08:      	jne	0x1c52 <kprobe_unwind_v8+0x1c52>
    1c0a:      	movq	(%rsp), %rax
    1c0e:      	movl	%eax, %ecx
    1c10:      	andl	$0x3, %ecx
    1c13:      	cmpl	$0x1, %ecx
    1c16:      	jne	0x1c52 <kprobe_unwind_v8+0x1c52>
    1c18:      	andq	$-0x4, %rax
    1c1c:      	je	0x1c52 <kprobe_unwind_v8+0x1c52>
    1c1e:      	movq	0x48(%rsp), %rsi
    1c23:      	movzbl	0xd(%rsi), %ecx
    1c27:      	addq	%rax, %rcx
    1c2a:      	movq	%rsp, %rdi
    1c2d:      	movl	$0x2, %edx
    1c32:      	movl	$0x70, %r8d
    1c38:      	movzbl	0xd(%rsi), %edx
    1c3c:      	addq	%rax, %rdx
    1c3f:      	movl	$0x2, %esi
    1c44:      	callq	*%r8
    1c47:      	testq	%rax, %rax
    1c4a:      	jne	0x1c52 <kprobe_unwind_v8+0x1c52>
    1c4c:      	movzwl	(%rsp), %eax
    1c50:      	jmp	0x1c54 <kprobe_unwind_v8+0x1c54>
    1c52:      	xorl	%eax, %eax
    1c54:      	movq	0x48(%rsp), %rcx
    1c59:      	cmpw	0x4(%rcx), %ax
    1c5d:      	jae	0x1c69 <kprobe_unwind_v8+0x1c69>
    1c5f:      	movq	0x48(%rsp), %r8
    1c64:      	jmp	0x494 <kprobe_unwind_v8+0x494>
    1c69:      	movq	0x48(%rsp), %r8
    1c6e:      	cmpw	0x6(%r8), %ax
    1c73:      	ja	0x494 <kprobe_unwind_v8+0x494>
    1c79:      	movzbl	0xf(%r8), %edx
    1c7e:      	addq	%r12, %rdx
    1c81:      	movq	%rsp, %rdi
    1c84:      	movl	$0x8, %eax
    1c89:      	movl	$0x70, %ecx
    1c8e:      	movl	$0x8, %esi
    1c93:      	callq	*%rcx
    1c95:      	testq	%rax, %rax
    1c98:      	jne	0x1d29 <kprobe_unwind_v8+0x1d29>
    1c9e:      	movq	(%rsp), %rcx
    1ca2:      	movq	%rcx, %rax
    1ca5:      	movq	%rcx, 0x50(%rsp)
    1caa:      	andl	$0x3, %eax
    1cad:      	cmpl	$0x1, %eax
    1cb0:      	jne	0x1d29 <kprobe_unwind_v8+0x1d29>
    1cb2:      	andq	$-0x4, 0x50(%rsp)
    1cb8:      	je	0x1d29 <kprobe_unwind_v8+0x1d29>
    1cba:      	movq	0x48(%rsp), %rax
    1cbf:      	movzbl	0xc(%rax), %edx
    1cc3:      	addq	0x50(%rsp), %rdx
    1cc8:      	movq	%rsp, %rdi
    1ccb:      	movl	$0x8, %eax
    1cd0:      	movl	$0x70, %ecx
    1cd5:      	movl	$0x8, %esi
    1cda:      	callq	*%rcx
    1cdc:      	testq	%rax, %rax
    1cdf:      	jne	0x1d30 <kprobe_unwind_v8+0x1d30>
    1ce1:      	movq	(%rsp), %rax
    1ce5:      	movl	%eax, %ecx
    1ce7:      	andl	$0x3, %ecx
    1cea:      	cmpl	$0x1, %ecx
    1ced:      	jne	0x1d30 <kprobe_unwind_v8+0x1d30>
    1cef:      	andq	$-0x4, %rax
    1cf3:      	je	0x1d30 <kprobe_unwind_v8+0x1d30>
    1cf5:      	movq	0x48(%rsp), %rsi
    1cfa:      	movzbl	0xd(%rsi), %ecx
    1cfe:      	addq	%rax, %rcx
    1d01:      	movq	%rsp, %rdi
    1d04:      	movl	$0x2, %edx
    1d09:      	movl	$0x70, %r8d
    1d0f:      	movzbl	0xd(%rsi), %edx
    1d13:      	addq	%rax, %rdx
    1d16:      	movl	$0x2, %esi
    1d1b:      	callq	*%r8
    1d1e:      	testq	%rax, %rax
    1d21:      	jne	0x1d30 <kprobe_unwind_v8+0x1d30>
    1d23:      	movzwl	(%rsp), %eax
    1d27:      	jmp	0x1d32 <kprobe_unwind_v8+0x1d32>
    1d29:      	xorl	%eax, %eax
    1d2b:      	movq	%rax, 0x50(%rsp)
    1d30:      	xorl	%eax, %eax
    1d32:      	movq	0x48(%rsp), %rcx
    1d37:      	cmpw	0xa(%rcx), %ax
    1d3b:      	jne	0x998 <kprobe_unwind_v8+0x998>
    1d41:      	movq	%r15, %rbp
    1d44:      	shrq	$0x20, %rbp
    1d48:      	je	0x1e25 <kprobe_unwind_v8+0x1e25>
    1d4e:      	andl	$0x1, %r15d
    1d52:      	jne	0x1e25 <kprobe_unwind_v8+0x1e25>
    1d58:      	movq	(%rip), %rax            # 0x1d5f <kprobe_unwind_v8+0x1d5f>
    1d5f:      	cmpl	$0x0, (%rax)
    1d62:      	jne	0x2aa1 <kprobe_unwind_v8+0x2aa1>
    1d68:      	movq	0x50(%rsp), %r15
    1d6d:      	orq	$0x1, %r15
    1d71:      	jmp	0x23c5 <kprobe_unwind_v8+0x23c5>
    1d76:      	xorl	%eax, %eax
    1d78:      	movq	(%rip), %rcx            # 0x1d7f <kprobe_unwind_v8+0x1d7f>
    1d7f:      	cmpl	$0x0, (%rcx)
    1d82:      	jne	0x2a29 <kprobe_unwind_v8+0x2a29>
    1d88:      	movq	0xed0(%r14), %r12
    1d8f:      	testq	%r12, %r12
    1d92:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    1d98:      	testl	%eax, %eax
    1d9a:      	jne	0x27c0 <kprobe_unwind_v8+0x27c0>
    1da0:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1daa:      	cmpq	%rax, %r12
    1dad:      	jbe	0x2855 <kprobe_unwind_v8+0x2855>
    1db3:      	movq	(%rip), %r13            # 0x1dba <kprobe_unwind_v8+0x1dba>
    1dba:      	cmpl	$0x0, (%r13)
    1dbf:      	je	0x6b0 <kprobe_unwind_v8+0x6b0>
    1dc5:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    1dcf:      	movq	%rax, 0x18(%rsp)
    1dd4:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    1dde:      	movq	%rax, 0x10(%rsp)
    1de3:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    1ded:      	movq	%rax, 0x8(%rsp)
    1df2:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    1dfc:      	movq	%rax, (%rsp)
    1e00:      	movw	$0xa, 0x20(%rsp)
    1e07:      	movq	%rsp, %rdi
    1e0a:      	movl	$0x22, %eax
    1e0f:      	movl	$0x6, %ecx
    1e14:      	movl	$0x22, %esi
    1e19:      	movq	%r12, %rdx
    1e1c:      	xorl	%eax, %eax
    1e1e:      	callq	*%rcx
    1e20:      	jmp	0x6b0 <kprobe_unwind_v8+0x6b0>
    1e25:      	movq	0x48(%rsp), %rax
    1e2a:      	movzbl	0xe(%rax), %edx
    1e2e:      	addq	%r12, %rdx
    1e31:      	movq	%rsp, %rdi
    1e34:      	movl	$0x8, %eax
    1e39:      	movl	$0x70, %ecx
    1e3e:      	movl	$0x8, %esi
    1e43:      	callq	*%rcx
    1e45:      	testq	%rax, %rax
    1e48:      	jne	0x1ed9 <kprobe_unwind_v8+0x1ed9>
    1e4e:      	movq	(%rsp), %rcx
    1e52:      	movq	%rcx, %rax
    1e55:      	movq	%rcx, 0x58(%rsp)
    1e5a:      	andl	$0x3, %eax
    1e5d:      	cmpl	$0x1, %eax
    1e60:      	jne	0x1ed9 <kprobe_unwind_v8+0x1ed9>
    1e62:      	andq	$-0x4, 0x58(%rsp)
    1e68:      	je	0x1ed9 <kprobe_unwind_v8+0x1ed9>
    1e6a:      	movq	0x48(%rsp), %rax
    1e6f:      	movzbl	0xc(%rax), %edx
    1e73:      	addq	0x58(%rsp), %rdx
    1e78:      	movq	%rsp, %rdi
    1e7b:      	movl	$0x8, %eax
    1e80:      	movl	$0x70, %ecx
    1e85:      	movl	$0x8, %esi
    1e8a:      	callq	*%rcx
    1e8c:      	testq	%rax, %rax
    1e8f:      	jne	0x1ee0 <kprobe_unwind_v8+0x1ee0>
    1e91:      	movq	(%rsp), %rax
    1e95:      	movl	%eax, %ecx
    1e97:      	andl	$0x3, %ecx
    1e9a:      	cmpl	$0x1, %ecx
    1e9d:      	jne	0x1ee0 <kprobe_unwind_v8+0x1ee0>
    1e9f:      	andq	$-0x4, %rax
    1ea3:      	je	0x1ee0 <kprobe_unwind_v8+0x1ee0>
    1ea5:      	movq	0x48(%rsp), %rsi
    1eaa:      	movzbl	0xd(%rsi), %ecx
    1eae:      	addq	%rax, %rcx
    1eb1:      	movq	%rsp, %rdi
    1eb4:      	movl	$0x2, %edx
    1eb9:      	movl	$0x70, %r8d
    1ebf:      	movzbl	0xd(%rsi), %edx
    1ec3:      	addq	%rax, %rdx
    1ec6:      	movl	$0x2, %esi
    1ecb:      	callq	*%r8
    1ece:      	testq	%rax, %rax
    1ed1:      	jne	0x1ee0 <kprobe_unwind_v8+0x1ee0>
    1ed3:      	movzwl	(%rsp), %eax
    1ed7:      	jmp	0x1ee2 <kprobe_unwind_v8+0x1ee2>
    1ed9:      	xorl	%eax, %eax
    1edb:      	movq	%rax, 0x58(%rsp)
    1ee0:      	xorl	%eax, %eax
    1ee2:      	movq	0x50(%rsp), %r15
    1ee7:      	orq	$0x2, %r15
    1eeb:      	movq	0x48(%rsp), %rcx
    1ef0:      	cmpw	0x8(%rcx), %ax
    1ef4:      	jne	0x2323 <kprobe_unwind_v8+0x2323>
    1efa:      	movl	$0x60, %eax
    1eff:      	movl	$0x70, %ecx
    1f04:      	movq	0xb0(%rsp), %rdi
    1f0c:      	movq	0x58(%rsp), %rdx
    1f11:      	movl	$0x60, %esi
    1f16:      	callq	*%rcx
    1f18:      	testq	%rax, %rax
    1f1b:      	je	0x2358 <kprobe_unwind_v8+0x2358>
    1f21:      	movl	$0x3b, 0x70(%rsp)
    1f29:      	movq	(%rip), %rdi            # 0x1f30 <kprobe_unwind_v8+0x1f30>
    1f30:      	leaq	0x70(%rsp), %rsi
    1f35:      	movl	$0x1, %eax
    1f3a:      	callq	*%rax
    1f3c:      	testq	%rax, %rax
    1f3f:      	jne	0x2353 <kprobe_unwind_v8+0x2353>
    1f45:      	movq	(%rip), %rax            # 0x1f4c <kprobe_unwind_v8+0x1f4c>
    1f4c:      	cmpl	$0x0, (%rax)
    1f4f:      	je	0x23c3 <kprobe_unwind_v8+0x23c3>
    1f55:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f5f:      	movq	%rax, 0x26(%rsp)
    1f64:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f6e:      	movq	%rax, 0x20(%rsp)
    1f73:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f7d:      	movq	%rax, 0x18(%rsp)
    1f82:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f8c:      	movq	%rax, 0x10(%rsp)
    1f91:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f9b:      	movq	%rax, 0x8(%rsp)
    1fa0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1faa:      	movq	%rax, (%rsp)
    1fae:      	movq	%rsp, %rdi
    1fb1:      	movl	$0x2e, %eax
    1fb6:      	movl	$0x6, %ecx
    1fbb:      	jmp	0x2cea <kprobe_unwind_v8+0x2cea>
    1fc0:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    1fca:      	movq	%rax, 0x17(%rsp)
    1fcf:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    1fd9:      	movq	%rax, 0x10(%rsp)
    1fde:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    1fe8:      	movq	%rax, 0x8(%rsp)
    1fed:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    1ff7:      	movq	%rax, (%rsp)
    1ffb:      	movq	%rsp, %rdi
    1ffe:      	movl	$0x1f, %eax
    2003:      	movl	$0x6, %r9d
    2009:      	movl	$0x1f, %esi
    200e:      	movq	%r13, %rdx
    2011:      	movq	%r12, %rcx
    2014:      	movq	%rbp, %r8
    2017:      	xorl	%eax, %eax
    2019:      	callq	*%r9
    201c:      	cmpq	%r12, %rbp
    201f:      	jae	0x1a13 <kprobe_unwind_v8+0x1a13>
    2025:      	movq	%rbp, %rdx
    2028:      	movq	(%rip), %rbp            # 0x202f <kprobe_unwind_v8+0x202f>
    202f:      	cmpl	$0x0, (%rbp)
    2033:      	jne	0x21c4 <kprobe_unwind_v8+0x21c4>
    2039:      	movl	$0x39, 0x70(%rsp)
    2041:      	movq	(%rip), %rdi            # 0x2048 <kprobe_unwind_v8+0x2048>
    2048:      	leaq	0x70(%rsp), %rsi
    204d:      	movl	$0x1, %eax
    2052:      	callq	*%rax
    2054:      	testq	%rax, %rax
    2057:      	je	0x205e <kprobe_unwind_v8+0x205e>
    2059:      	incq	(%rax)
    205c:      	jmp	0x2068 <kprobe_unwind_v8+0x2068>
    205e:      	cmpl	$0x0, (%rbp)
    2062:      	jne	0x2233 <kprobe_unwind_v8+0x2233>
    2068:      	movl	$0x1388, %r12d          # imm = 0x1388
    206e:      	xorl	%ebp, %ebp
    2070:      	movl	%r12d, 0xf2c(%r14)
    2077:      	movl	$0x0, (%rsp)
    207e:      	movq	(%rip), %rdi            # 0x2085 <kprobe_unwind_v8+0x2085>
    2085:      	movq	%rsp, %rsi
    2088:      	movl	$0x1, %eax
    208d:      	callq	*%rax
    208f:      	testq	%rax, %rax
    2092:      	je	0x20d4 <kprobe_unwind_v8+0x20d4>
    2094:      	movzbl	0x1384(%rax), %ecx
    209b:      	movl	%ebp, %edx
    209d:      	cmpb	$0x1d, %cl
    20a0:      	jb	0x2101 <kprobe_unwind_v8+0x2101>
    20a2:      	movq	%rax, %r14
    20a5:      	movl	$0x5, 0xf2c(%rax)
    20af:      	movl	$0x44, 0x70(%rsp)
    20b7:      	movq	(%rip), %rdi            # 0x20be <kprobe_unwind_v8+0x20be>
    20be:      	leaq	0x70(%rsp), %rsi
    20c3:      	movl	$0x1, %eax
    20c8:      	callq	*%rax
    20ca:      	testq	%rax, %rax
    20cd:      	je	0x20e4 <kprobe_unwind_v8+0x20e4>
    20cf:      	incq	(%rax)
    20d2:      	jmp	0x20f4 <kprobe_unwind_v8+0x20f4>
    20d4:      	movq	(%rip), %rcx            # 0x20db <kprobe_unwind_v8+0x20db>
    20db:      	xorl	%edx, %edx
    20dd:      	movl	$0xc, %eax
    20e2:      	jmp	0x2117 <kprobe_unwind_v8+0x2117>
    20e4:      	movq	(%rip), %rax            # 0x20eb <kprobe_unwind_v8+0x20eb>
    20eb:      	cmpl	$0x0, (%rax)
    20ee:      	jne	0x22ab <kprobe_unwind_v8+0x22ab>
    20f4:      	movq	%r14, %rax
    20f7:      	movzbl	0x1384(%r14), %ecx
    20ff:      	xorl	%edx, %edx
    2101:      	incb	%cl
    2103:      	movb	%cl, 0x1384(%rax)
    2109:      	movl	%edx, %ecx
    210b:      	movq	(%rip), %rsi            # 0x2112 <kprobe_unwind_v8+0x2112>
    2112:      	movl	$0xc, %eax
    2117:      	movq	(%rip), %rsi            # 0x211e <kprobe_unwind_v8+0x211e>
    211e:      	movq	%rbx, %rdi
    2121:      	callq	*%rax
    2123:      	movq	(%rip), %rax            # 0x212a <kprobe_unwind_v8+0x212a>
    212a:      	cmpl	$0x0, (%rax)
    212d:      	jne	0x2146 <kprobe_unwind_v8+0x2146>
    212f:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    2134:      	addq	$0xc8, %rsp
    213b:      	popq	%rbx
    213c:      	popq	%r12
    213e:      	popq	%r13
    2140:      	popq	%r14
    2142:      	popq	%r15
    2144:      	popq	%rbp
    2145:      	retq
    2146:      	movabsq	$0x656c696166202964, %rax # imm = 0x656C696166202964
    2150:      	movq	%rax, 0x28(%rsp)
    2155:      	movabsq	$0x2528207265646e69, %rax # imm = 0x2528207265646E69
    215f:      	movq	%rax, 0x20(%rsp)
    2164:      	movabsq	$0x776e7520656d6172, %rax # imm = 0x776E7520656D6172
    216e:      	movq	%rax, 0x18(%rsp)
    2173:      	movabsq	$0x66207478656e2072, %rax # imm = 0x66207478656E2072
    217d:      	movq	%rax, 0x10(%rsp)
    2182:      	movabsq	$0x6f66206c6c616320, %rax # imm = 0x6F66206C6C616320
    218c:      	movq	%rax, 0x8(%rsp)
    2191:      	movabsq	$0x6c696174203a3876, %rax # imm = 0x6C696174203A3876
    219b:      	movq	%rax, (%rsp)
    219f:      	movl	$0xa6465, 0x2f(%rsp)    # imm = 0xA6465
    21a7:      	movq	%rsp, %rdi
    21aa:      	movl	$0x33, %eax
    21af:      	movl	$0x6, %ecx
    21b4:      	movl	$0x33, %esi
    21b9:      	movl	%ebp, %edx
    21bb:      	xorl	%eax, %eax
    21bd:      	callq	*%rcx
    21bf:      	jmp	0x212f <kprobe_unwind_v8+0x212f>
    21c4:      	movabsq	$0xa786c25202f2078, %rax # imm = 0xA786C25202F2078
    21ce:      	movq	%rax, 0x20(%rsp)
    21d3:      	movabsq	$0x6c252066666f2072, %rax # imm = 0x6C252066666F2072
    21dd:      	movq	%rax, 0x18(%rsp)
    21e2:      	movabsq	$0x6166206f6f742072, %rax # imm = 0x6166206F6F742072
    21ec:      	movq	%rax, 0x10(%rsp)
    21f1:      	movabsq	$0x65746e696f702065, %rax # imm = 0x65746E696F702065
    21fb:      	movq	%rax, 0x8(%rsp)
    2200:      	movabsq	$0x6d617266203a3876, %rax # imm = 0x6D617266203A3876
    220a:      	movq	%rax, (%rsp)
    220e:      	movb	$0x0, 0x28(%rsp)
    2213:      	movq	%rsp, %rdi
    2216:      	movl	$0x29, %eax
    221b:      	movl	$0x6, %r8d
    2221:      	movl	$0x29, %esi
    2226:      	movq	%r12, %rcx
    2229:      	xorl	%eax, %eax
    222b:      	callq	*%r8
    222e:      	jmp	0x2039 <kprobe_unwind_v8+0x2039>
    2233:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    223d:      	movq	%rax, 0x26(%rsp)
    2242:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    224c:      	movq	%rax, 0x20(%rsp)
    2251:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    225b:      	movq	%rax, 0x18(%rsp)
    2260:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    226a:      	movq	%rax, 0x10(%rsp)
    226f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2279:      	movq	%rax, 0x8(%rsp)
    227e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2288:      	movq	%rax, (%rsp)
    228c:      	movq	%rsp, %rdi
    228f:      	movl	$0x2e, %eax
    2294:      	movl	$0x6, %ecx
    2299:      	movl	0x70(%rsp), %edx
    229d:      	movl	$0x2e, %esi
    22a2:      	xorl	%eax, %eax
    22a4:      	callq	*%rcx
    22a6:      	jmp	0x2068 <kprobe_unwind_v8+0x2068>
    22ab:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    22b5:      	movq	%rax, 0x26(%rsp)
    22ba:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    22c4:      	movq	%rax, 0x20(%rsp)
    22c9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    22d3:      	movq	%rax, 0x18(%rsp)
    22d8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    22e2:      	movq	%rax, 0x10(%rsp)
    22e7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22f1:      	movq	%rax, 0x8(%rsp)
    22f6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2300:      	movq	%rax, (%rsp)
    2304:      	movq	%rsp, %rdi
    2307:      	movl	$0x2e, %eax
    230c:      	movl	$0x6, %ecx
    2311:      	movl	0x70(%rsp), %edx
    2315:      	movl	$0x2e, %esi
    231a:      	xorl	%eax, %eax
    231c:      	callq	*%rcx
    231e:      	jmp	0x20f4 <kprobe_unwind_v8+0x20f4>
    2323:      	movq	(%rip), %rcx            # 0x232a <kprobe_unwind_v8+0x232a>
    232a:      	cmpl	$0x0, (%rcx)
    232d:      	jne	0x2af3 <kprobe_unwind_v8+0x2af3>
    2333:      	movl	$0x3b, 0x70(%rsp)
    233b:      	movq	(%rip), %rdi            # 0x2342 <kprobe_unwind_v8+0x2342>
    2342:      	leaq	0x70(%rsp), %rsi
    2347:      	movl	$0x1, %eax
    234c:      	callq	*%rax
    234e:      	testq	%rax, %rax
    2351:      	je	0x23b3 <kprobe_unwind_v8+0x23b3>
    2353:      	incq	(%rax)
    2356:      	jmp	0x23c3 <kprobe_unwind_v8+0x23c3>
    2358:      	movq	0x48(%rsp), %rax
    235d:      	movzbl	0x12(%rax), %ecx
    2361:      	xorl	%ebp, %ebp
    2363:      	cmpq	$0x5c, %rcx
    2367:      	ja	0x220 <kprobe_unwind_v8+0x220>
    236d:      	movq	0x48(%rsp), %rax
    2372:      	movzbl	0x13(%rax), %eax
    2376:      	cmpq	$0x5c, %rax
    237a:      	ja	0x220 <kprobe_unwind_v8+0x220>
    2380:      	movq	0x48(%rsp), %rdx
    2385:      	cmpb	$0x0, 0x10(%rdx)
    2389:      	movzbl	0x11(%rdx), %edx
    238d:      	movq	%rdx, 0x68(%rsp)
    2392:      	je	0x25ab <kprobe_unwind_v8+0x25ab>
    2398:      	movq	0xb0(%rsp), %rdx
    23a0:      	movq	0x68(%rsp), %rsi
    23a5:      	movq	(%rdx,%rsi), %rsi
    23a9:      	movq	%rsi, 0x68(%rsp)
    23ae:      	jmp	0x25ba <kprobe_unwind_v8+0x25ba>
    23b3:      	movq	(%rip), %rax            # 0x23ba <kprobe_unwind_v8+0x23ba>
    23ba:      	cmpl	$0x0, (%rax)
    23bd:      	jne	0x2c84 <kprobe_unwind_v8+0x2c84>
    23c3:      	xorl	%ebp, %ebp
    23c5:      	movzbl	0xf30(%r14), %r12d
    23cd:      	movq	(%rip), %rax            # 0x23d4 <kprobe_unwind_v8+0x23d4>
    23d4:      	cmpl	$0x0, (%rax)
    23d7:      	je	0x1ac3 <kprobe_unwind_v8+0x1ac3>
    23dd:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    23e7:      	movq	%rax, 0x30(%rsp)
    23ec:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    23f6:      	movq	%rax, 0x28(%rsp)
    23fb:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    2405:      	movq	%rax, 0x20(%rsp)
    240a:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    2414:      	movq	%rax, 0x18(%rsp)
    2419:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    2423:      	movq	%rax, 0x10(%rsp)
    2428:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    2432:      	movq	%rax, 0x8(%rsp)
    2437:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2441:      	movq	%rax, (%rsp)
    2445:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    244d:      	movq	%rsp, %rdi
    2450:      	movl	$0x3c, %eax
    2455:      	movl	$0x6, %r8d
    245b:      	movl	$0x3c, %esi
    2460:      	movq	%rbp, %rdx
    2463:      	movq	%r15, %rcx
    2466:      	xorl	%eax, %eax
    2468:      	callq	*%r8
    246b:      	jmp	0x1ac3 <kprobe_unwind_v8+0x1ac3>
    2470:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    247a:      	movq	%rax, 0x28(%rsp)
    247f:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    2489:      	movq	%rax, 0x20(%rsp)
    248e:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    2498:      	movq	%rax, 0x18(%rsp)
    249d:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    24a7:      	movq	%rax, 0x10(%rsp)
    24ac:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    24b6:      	movq	%rax, 0x8(%rsp)
    24bb:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    24c5:      	movq	%rax, (%rsp)
    24c9:      	movq	%rsp, %rdi
    24cc:      	movl	$0x30, %eax
    24d1:      	movl	$0x6, %ecx
    24d6:      	movl	$0x30, %esi
    24db:      	xorl	%eax, %eax
    24dd:      	callq	*%rcx
    24df:      	jmp	0xbf2 <kprobe_unwind_v8+0xbf2>
    24e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    24ee:      	movq	%rax, 0x26(%rsp)
    24f3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    24fd:      	movq	%rax, 0x20(%rsp)
    2502:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    250c:      	movq	%rax, 0x18(%rsp)
    2511:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    251b:      	movq	%rax, 0x10(%rsp)
    2520:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    252a:      	movq	%rax, 0x8(%rsp)
    252f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2539:      	movq	%rax, (%rsp)
    253d:      	movq	%rsp, %rdi
    2540:      	movl	$0x2e, %eax
    2545:      	movl	$0x6, %ecx
    254a:      	movl	0x64(%rsp), %edx
    254e:      	movl	$0x2e, %esi
    2553:      	xorl	%eax, %eax
    2555:      	callq	*%rcx
    2557:      	jmp	0x19d3 <kprobe_unwind_v8+0x19d3>
    255c:      	movabsq	$0x746e696f70206b63, %rax # imm = 0x746E696F70206B63
    2566:      	movq	%rax, 0x10(%rsp)
    256b:      	movabsq	$0x6174732064616220, %rax # imm = 0x6174732064616220
    2575:      	movq	%rax, 0x8(%rsp)
    257a:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    2584:      	movq	%rax, (%rsp)
    2588:      	movl	$0xa7265, 0x18(%rsp)    # imm = 0xA7265
    2590:      	movq	%rsp, %rdi
    2593:      	movl	$0x1c, %eax
    2598:      	movl	$0x6, %ecx
    259d:      	movl	$0x1c, %esi
    25a2:      	xorl	%eax, %eax
    25a4:      	callq	*%rcx
    25a6:      	jmp	0xe48 <kprobe_unwind_v8+0xe48>
    25ab:      	movq	0x68(%rsp), %rdx
    25b0:      	addq	0x58(%rsp), %rdx
    25b5:      	movq	%rdx, 0x68(%rsp)
    25ba:      	movq	0xb0(%rsp), %rdx
    25c2:      	movl	(%rdx,%rcx), %esi
    25c5:      	movq	0x48(%rsp), %rcx
    25ca:      	movzbl	0x17(%rcx), %edi
    25ce:      	movl	%edi, 0xb8(%rsp)
    25d5:      	movzbl	0x18(%rcx), %ecx
    25d9:      	movq	%rsi, 0xa0(%rsp)
    25e1:      	addq	0x68(%rsp), %rsi
    25e6:      	movq	%rsi, 0x90(%rsp)
    25ee:      	andl	(%rdx,%rax), %ecx
    25f1:      	movl	%ecx, 0xac(%rsp)
    25f8:      	movq	(%rip), %rax            # 0x25ff <kprobe_unwind_v8+0x25ff>
    25ff:      	cmpl	$0x0, (%rax)
    2602:      	jne	0x2cfc <kprobe_unwind_v8+0x2cfc>
    2608:      	movq	%r13, %rbp
    260b:      	subq	0x68(%rsp), %rbp
    2610:      	jb	0x2662 <kprobe_unwind_v8+0x2662>
    2612:      	cmpq	0x90(%rsp), %r13
    261a:      	jae	0x2662 <kprobe_unwind_v8+0x2662>
    261c:      	movl	0xb8(%rsp), %eax
    2623:      	shrxl	%eax, 0xac(%rsp), %eax
    262d:      	movq	0x48(%rsp), %rcx
    2632:      	movzbl	0x19(%rcx), %ecx
    2636:      	orq	$0x4, %r12
    263a:      	movq	0x58(%rsp), %r15
    263f:      	orq	$0x3, %r15
    2643:      	cmpl	%ecx, %eax
    2645:      	cmoveq	%r12, %r15
    2649:      	movq	0xa0(%rsp), %rcx
    2651:      	shll	$0x4, %ecx
    2654:      	orl	%eax, %ecx
    2656:      	shlq	$0x20, %rcx
    265a:      	orq	%rcx, %rbp
    265d:      	jmp	0x23c5 <kprobe_unwind_v8+0x23c5>
    2662:      	movq	(%rip), %rax            # 0x2669 <kprobe_unwind_v8+0x2669>
    2669:      	cmpl	$0x0, (%rax)
    266c:      	jne	0x3736 <kprobe_unwind_v8+0x3736>
    2672:      	xorl	%ebp, %ebp
    2674:      	jmp	0x1abb <kprobe_unwind_v8+0x1abb>
    2679:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2683:      	movq	%rax, 0x26(%rsp)
    2688:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2692:      	movq	%rax, 0x20(%rsp)
    2697:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    26a1:      	movq	%rax, 0x18(%rsp)
    26a6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    26b0:      	movq	%rax, 0x10(%rsp)
    26b5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    26bf:      	movq	%rax, 0x8(%rsp)
    26c4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    26ce:      	movq	%rax, (%rsp)
    26d2:      	movq	%rsp, %rdi
    26d5:      	movl	$0x2e, %eax
    26da:      	movl	$0x6, %ecx
    26df:      	movl	0x64(%rsp), %edx
    26e3:      	movl	$0x2e, %esi
    26e8:      	xorl	%eax, %eax
    26ea:      	callq	*%rcx
    26ec:      	movl	$0x1388, %r12d          # imm = 0x1388
    26f2:      	jmp	0x2070 <kprobe_unwind_v8+0x2070>
    26f7:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    2701:      	movq	%rax, 0x15(%rsp)
    2706:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    2710:      	movq	%rax, 0x10(%rsp)
    2715:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    271f:      	movq	%rax, 0x8(%rsp)
    2724:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    272e:      	movq	%rax, (%rsp)
    2732:      	movq	%rsp, %rdi
    2735:      	movl	$0x1d, %eax
    273a:      	movl	$0x6, %ecx
    273f:      	xorl	%r15d, %r15d
    2742:      	movl	$0x1d, %esi
    2747:      	movq	%rbp, %rdx
    274a:      	xorl	%eax, %eax
    274c:      	callq	*%rcx
    274e:      	jmp	0x23c5 <kprobe_unwind_v8+0x23c5>
    2753:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    275d:      	movq	%rax, 0x17(%rsp)
    2762:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    276c:      	movq	%rax, 0x10(%rsp)
    2771:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    277b:      	movq	%rax, 0x8(%rsp)
    2780:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    278a:      	movq	%rax, (%rsp)
    278e:      	movq	%rsp, %rdi
    2791:      	movl	$0x1f, %eax
    2796:      	movl	$0x6, %r9d
    279c:      	movq	0xed0(%r14), %rdx
    27a3:      	movq	0xed8(%r14), %rcx
    27aa:      	movq	0xee0(%r14), %r8
    27b1:      	movl	$0x1f, %esi
    27b6:      	xorl	%eax, %eax
    27b8:      	callq	*%r9
    27bb:      	jmp	0x1b88 <kprobe_unwind_v8+0x1b88>
    27c0:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    27ca:      	movq	%rax, 0x28(%rsp)
    27cf:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    27d9:      	movq	%rax, 0x20(%rsp)
    27de:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    27e8:      	movq	%rax, 0x18(%rsp)
    27ed:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    27f7:      	movq	%rax, 0x10(%rsp)
    27fc:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    2806:      	movq	%rax, 0x8(%rsp)
    280b:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    2815:      	movq	%rax, (%rsp)
    2819:      	movb	$0x0, 0x30(%rsp)
    281e:      	movq	%rsp, %rdi
    2821:      	movl	$0x31, %eax
    2826:      	movl	$0x6, %ecx
    282b:      	movl	0x2c0(%r14), %edx
    2832:      	movl	$0x31, %esi
    2837:      	xorl	%eax, %eax
    2839:      	callq	*%rcx
    283b:      	movq	0xed0(%r14), %r12
    2842:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    284c:      	cmpq	%rax, %r12
    284f:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    2855:      	cmpq	$0x1000, %r12           # imm = 0x1000
    285c:      	jae	0x28c9 <kprobe_unwind_v8+0x28c9>
    285e:      	movq	(%rip), %r13            # 0x2865 <kprobe_unwind_v8+0x2865>
    2865:      	cmpl	$0x0, (%r13)
    286a:      	je	0x12eb <kprobe_unwind_v8+0x12eb>
    2870:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    287a:      	movq	%rax, 0x16(%rsp)
    287f:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    2889:      	movq	%rax, 0x10(%rsp)
    288e:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    2898:      	movq	%rax, 0x8(%rsp)
    289d:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    28a7:      	movq	%rax, (%rsp)
    28ab:      	movq	%rsp, %rdi
    28ae:      	movl	$0x1e, %eax
    28b3:      	movl	$0x6, %ecx
    28b8:      	movl	$0x1e, %esi
    28bd:      	movq	%r12, %rdx
    28c0:      	xorl	%eax, %eax
    28c2:      	callq	*%rcx
    28c4:      	jmp	0x12eb <kprobe_unwind_v8+0x12eb>
    28c9:      	movl	(%r14), %eax
    28cc:      	movl	$0x60, 0x70(%rsp)
    28d4:      	movbel	%eax, 0x74(%rsp)
    28da:      	movbeq	%r12, 0x78(%rsp)
    28e1:      	movq	(%rip), %rdi            # 0x28e8 <kprobe_unwind_v8+0x28e8>
    28e8:      	leaq	0x70(%rsp), %rsi
    28ed:      	movl	$0x1, %eax
    28f2:      	callq	*%rax
    28f4:      	testq	%rax, %rax
    28f7:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    28fd:      	movq	0x8(%rax), %rbp
    2901:      	movq	%rbp, %rcx
    2904:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    290e:      	andq	%rdx, %rcx
    2911:      	movq	%rcx, 0xf20(%r14)
    2918:      	movq	(%rax), %rax
    291b:      	movq	%rax, 0xf10(%r14)
    2922:      	shrq	$0x38, %rbp
    2926:      	movq	%r12, %rax
    2929:      	subq	%rcx, %rax
    292c:      	movq	%rax, 0xf18(%r14)
    2933:      	movq	(%rip), %rax            # 0x293a <kprobe_unwind_v8+0x293a>
    293a:      	cmpl	$0x0, (%rax)
    293d:      	jne	0x2b75 <kprobe_unwind_v8+0x2b75>
    2943:      	cmpl	$0x1, %ebp
    2946:      	jne	0x2ea3 <kprobe_unwind_v8+0x2ea3>
    294c:      	movq	0xf10(%r14), %rax
    2953:      	movq	%rax, 0x70(%rsp)
    2958:      	movq	0xf18(%r14), %r13
    295f:      	movq	(%rip), %rdi            # 0x2966 <kprobe_unwind_v8+0x2966>
    2966:      	leaq	0x70(%rsp), %rsi
    296b:      	movl	$0x1, %eax
    2970:      	callq	*%rax
    2972:      	movl	$0x1, %ebp
    2977:      	testq	%rax, %rax
    297a:      	je	0x2ea3 <kprobe_unwind_v8+0x2ea3>
    2980:      	movq	%rax, %r12
    2983:      	cmpq	%r13, (%rax)
    2986:      	ja	0x298f <kprobe_unwind_v8+0x298f>
    2988:      	cmpq	%r13, 0x8(%r12)
    298d:      	jae	0x29a5 <kprobe_unwind_v8+0x29a5>
    298f:      	cmpq	%r13, 0x10(%r12)
    2994:      	ja	0x2ea3 <kprobe_unwind_v8+0x2ea3>
    299a:      	cmpq	%r13, 0x18(%r12)
    299f:      	jb	0x2ea3 <kprobe_unwind_v8+0x2ea3>
    29a5:      	movq	(%rip), %rax            # 0x29ac <kprobe_unwind_v8+0x29ac>
    29ac:      	cmpl	$0x0, (%rax)
    29af:      	jne	0x2dfc <kprobe_unwind_v8+0x2dfc>
    29b5:      	movl	0x1380(%r14), %eax
    29bc:      	movl	0x20(%r12), %ecx
    29c1:      	btl	%ecx, %eax
    29c4:      	jae	0x2e68 <kprobe_unwind_v8+0x2e68>
    29ca:      	movq	(%rip), %rax            # 0x29d1 <kprobe_unwind_v8+0x29d1>
    29d1:      	cmpl	$0x0, (%rax)
    29d4:      	je	0x2ea3 <kprobe_unwind_v8+0x2ea3>
    29da:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    29e4:      	movq	%rax, 0x10(%rsp)
    29e9:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    29f3:      	movq	%rax, 0x8(%rsp)
    29f8:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2a02:      	movq	%rax, (%rsp)
    2a06:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    2a0e:      	movq	%rsp, %rdi
    2a11:      	movl	$0x1b, %eax
    2a16:      	movl	$0x6, %ecx
    2a1b:      	movl	$0x1b, %esi
    2a20:      	xorl	%eax, %eax
    2a22:      	callq	*%rcx
    2a24:      	jmp	0x2ea3 <kprobe_unwind_v8+0x2ea3>
    2a29:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2a33:      	movq	%rax, 0x26(%rsp)
    2a38:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2a42:      	movq	%rax, 0x20(%rsp)
    2a47:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2a51:      	movq	%rax, 0x18(%rsp)
    2a56:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2a60:      	movq	%rax, 0x10(%rsp)
    2a65:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2a6f:      	movq	%rax, 0x8(%rsp)
    2a74:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a7e:      	movq	%rax, (%rsp)
    2a82:      	movq	%rsp, %rdi
    2a85:      	movl	$0x2e, %eax
    2a8a:      	movl	$0x6, %ecx
    2a8f:      	movl	0x70(%rsp), %edx
    2a93:      	movl	$0x2e, %esi
    2a98:      	xorl	%eax, %eax
    2a9a:      	callq	*%rcx
    2a9c:      	jmp	0x1baf <kprobe_unwind_v8+0x1baf>
    2aa1:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    2aab:      	movq	%rax, 0x10(%rsp)
    2ab0:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    2aba:      	movq	%rax, 0x8(%rsp)
    2abf:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    2ac9:      	movq	%rax, (%rsp)
    2acd:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    2ad5:      	movq	%rsp, %rdi
    2ad8:      	movl	$0x1c, %eax
    2add:      	movl	$0x6, %ecx
    2ae2:      	movl	$0x1c, %esi
    2ae7:      	movq	%rbp, %rdx
    2aea:      	xorl	%eax, %eax
    2aec:      	callq	*%rcx
    2aee:      	jmp	0x1d68 <kprobe_unwind_v8+0x1d68>
    2af3:      	movzwl	%ax, %r8d
    2af7:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    2b01:      	movq	%rax, 0x26(%rsp)
    2b06:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    2b10:      	movq	%rax, 0x20(%rsp)
    2b15:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    2b1f:      	movq	%rax, 0x18(%rsp)
    2b24:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    2b2e:      	movq	%rax, 0x10(%rsp)
    2b33:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    2b3d:      	movq	%rax, 0x8(%rsp)
    2b42:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    2b4c:      	movq	%rax, (%rsp)
    2b50:      	movq	%rsp, %rdi
    2b53:      	movl	$0x2e, %eax
    2b58:      	movl	$0x6, %r9d
    2b5e:      	movl	$0x2e, %esi
    2b63:      	movq	%r12, %rdx
    2b66:      	movq	0x58(%rsp), %rcx
    2b6b:      	xorl	%eax, %eax
    2b6d:      	callq	*%r9
    2b70:      	jmp	0x2333 <kprobe_unwind_v8+0x2333>
    2b75:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    2b7f:      	movq	%rax, 0x28(%rsp)
    2b84:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    2b8e:      	movq	%rax, 0x20(%rsp)
    2b93:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    2b9d:      	movq	%rax, 0x18(%rsp)
    2ba2:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    2bac:      	movq	%rax, 0x10(%rsp)
    2bb1:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    2bbb:      	movq	%rax, 0x8(%rsp)
    2bc0:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    2bca:      	movq	%r13, (%rsp)
    2bce:      	movw	$0xa, 0x30(%rsp)
    2bd5:      	movq	%rsp, %rdi
    2bd8:      	movl	$0x32, %eax
    2bdd:      	movl	$0x6, %r9d
    2be3:      	movq	0xf10(%r14), %rcx
    2bea:      	movl	$0x32, %esi
    2bef:      	movq	%r12, %rdx
    2bf2:      	movl	%ebp, %r8d
    2bf5:      	xorl	%eax, %eax
    2bf7:      	callq	*%r9
    2bfa:      	movq	(%rip), %rax            # 0x2c01 <kprobe_unwind_v8+0x2c01>
    2c01:      	cmpl	$0x0, (%rax)
    2c04:      	je	0x2943 <kprobe_unwind_v8+0x2943>
    2c0a:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    2c14:      	movq	%rax, 0x27(%rsp)
    2c19:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    2c23:      	movq	%rax, 0x20(%rsp)
    2c28:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    2c32:      	movq	%rax, 0x18(%rsp)
    2c37:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    2c41:      	movq	%rax, 0x10(%rsp)
    2c46:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    2c50:      	movq	%rax, 0x8(%rsp)
    2c55:      	movq	%r13, (%rsp)
    2c59:      	movq	%rsp, %rdi
    2c5c:      	movl	$0x2f, %eax
    2c61:      	movl	$0x6, %r8d
    2c67:      	movq	0xf18(%r14), %rcx
    2c6e:      	movq	0xf20(%r14), %rdx
    2c75:      	movl	$0x2f, %esi
    2c7a:      	xorl	%eax, %eax
    2c7c:      	callq	*%r8
    2c7f:      	jmp	0x2943 <kprobe_unwind_v8+0x2943>
    2c84:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2c8e:      	movq	%rax, 0x26(%rsp)
    2c93:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2c9d:      	movq	%rax, 0x20(%rsp)
    2ca2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2cac:      	movq	%rax, 0x18(%rsp)
    2cb1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2cbb:      	movq	%rax, 0x10(%rsp)
    2cc0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2cca:      	movq	%rax, 0x8(%rsp)
    2ccf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2cd9:      	movq	%rax, (%rsp)
    2cdd:      	movq	%rsp, %rdi
    2ce0:      	movl	$0x2e, %eax
    2ce5:      	movl	$0x6, %ecx
    2cea:      	movl	0x70(%rsp), %edx
    2cee:      	movl	$0x2e, %esi
    2cf3:      	xorl	%eax, %eax
    2cf5:      	callq	*%rcx
    2cf7:      	jmp	0x23c3 <kprobe_unwind_v8+0x23c3>
    2cfc:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    2d06:      	movq	%rax, 0x20(%rsp)
    2d0b:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    2d15:      	movq	%rax, 0x18(%rsp)
    2d1a:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    2d24:      	movq	%rax, 0x10(%rsp)
    2d29:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    2d33:      	movq	%rax, 0x8(%rsp)
    2d38:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    2d42:      	movq	%rax, (%rsp)
    2d46:      	movb	$0x0, 0x28(%rsp)
    2d4b:      	movq	%rsp, %rdi
    2d4e:      	movl	$0x29, %eax
    2d53:      	movl	$0x6, %r9d
    2d59:      	movl	$0x29, %esi
    2d5e:      	movq	%r12, %rdx
    2d61:      	movq	0x50(%rsp), %rcx
    2d66:      	movq	0x58(%rsp), %r8
    2d6b:      	xorl	%eax, %eax
    2d6d:      	callq	*%r9
    2d70:      	movq	(%rip), %rax            # 0x2d77 <kprobe_unwind_v8+0x2d77>
    2d77:      	cmpl	$0x0, (%rax)
    2d7a:      	je	0x2608 <kprobe_unwind_v8+0x2608>
    2d80:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    2d8a:      	movq	%rax, 0x1d(%rsp)
    2d8f:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    2d99:      	movq	%rax, 0x18(%rsp)
    2d9e:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    2da8:      	movq	%rax, 0x10(%rsp)
    2dad:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    2db7:      	movq	%rax, 0x8(%rsp)
    2dbc:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    2dc6:      	movq	%rax, (%rsp)
    2dca:      	movq	%rsp, %rdi
    2dcd:      	movl	$0x25, %eax
    2dd2:      	movl	$0x6, %r9d
    2dd8:      	movl	$0x25, %esi
    2ddd:      	movq	0x68(%rsp), %rdx
    2de2:      	movq	0x90(%rsp), %rcx
    2dea:      	movq	0xa0(%rsp), %r8
    2df2:      	xorl	%eax, %eax
    2df4:      	callq	*%r9
    2df7:      	jmp	0x2608 <kprobe_unwind_v8+0x2608>
    2dfc:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    2e06:      	movq	%rax, 0x16(%rsp)
    2e0b:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    2e15:      	movq	%rax, 0x10(%rsp)
    2e1a:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    2e24:      	movq	%rax, 0x8(%rsp)
    2e29:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2e33:      	movq	%rax, (%rsp)
    2e37:      	movq	%rsp, %rdi
    2e3a:      	movl	$0x1e, %eax
    2e3f:      	movl	$0x6, %ecx
    2e44:      	movzwl	0x20(%r12), %edx
    2e4a:      	movl	$0x1e, %esi
    2e4f:      	xorl	%eax, %eax
    2e51:      	callq	*%rcx
    2e53:      	movl	0x1380(%r14), %eax
    2e5a:      	movl	0x20(%r12), %ecx
    2e5f:      	btl	%ecx, %eax
    2e62:      	jb	0x29ca <kprobe_unwind_v8+0x29ca>
    2e68:      	movl	$0x0, 0x64(%rsp)
    2e70:      	movq	(%rip), %rdi            # 0x2e77 <kprobe_unwind_v8+0x2e77>
    2e77:      	leaq	0x64(%rsp), %rsi
    2e7c:      	movl	$0x1, %eax
    2e81:      	callq	*%rax
    2e83:      	testq	%rax, %rax
    2e86:      	je	0x2e8d <kprobe_unwind_v8+0x2e8d>
    2e88:      	incq	(%rax)
    2e8b:      	jmp	0x2e9d <kprobe_unwind_v8+0x2e9d>
    2e8d:      	movq	(%rip), %rax            # 0x2e94 <kprobe_unwind_v8+0x2e94>
    2e94:      	cmpl	$0x0, (%rax)
    2e97:      	jne	0x37ac <kprobe_unwind_v8+0x37ac>
    2e9d:      	movzwl	0x20(%r12), %ebp
    2ea3:      	xorl	%r12d, %r12d
    2ea6:      	cmpl	$0x7, %ebp
    2ea9:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    2eaf:      	movq	0xed0(%r14), %r13
    2eb6:      	movq	0xed8(%r14), %r12
    2ebd:      	movq	0xee0(%r14), %rbp
    2ec4:      	movq	(%rip), %rax            # 0x2ecb <kprobe_unwind_v8+0x2ecb>
    2ecb:      	cmpl	$0x0, (%rax)
    2ece:      	jne	0x357f <kprobe_unwind_v8+0x357f>
    2ed4:      	cmpq	%r12, %rbp
    2ed7:      	jb	0x2025 <kprobe_unwind_v8+0x2025>
    2edd:      	leaq	0x2000(%r12), %rax
    2ee5:      	cmpq	%rax, %rbp
    2ee8:      	jae	0x2025 <kprobe_unwind_v8+0x2025>
    2eee:      	addq	$-0x40, %rbp
    2ef2:      	movl	$0x40, %eax
    2ef7:      	movl	$0x70, %ecx
    2efc:      	movq	0x98(%rsp), %rdi
    2f04:      	movl	$0x40, %esi
    2f09:      	movq	%rbp, %rdx
    2f0c:      	callq	*%rcx
    2f0e:      	testq	%rax, %rax
    2f11:      	movq	(%rip), %rbp            # 0x2f18 <kprobe_unwind_v8+0x2f18>
    2f18:      	jne	0x138 <kprobe_unwind_v8+0x138>
    2f1e:      	movq	0x48(%rsp), %rax
    2f23:      	movzbl	0x14(%rax), %ecx
    2f27:      	xorl	%ebp, %ebp
    2f29:      	cmpq	$0x38, %rcx
    2f2d:      	ja	0x220 <kprobe_unwind_v8+0x220>
    2f33:      	movq	0x48(%rsp), %rax
    2f38:      	movzbl	0x15(%rax), %eax
    2f3c:      	cmpq	$0x38, %rax
    2f40:      	ja	0x220 <kprobe_unwind_v8+0x220>
    2f46:      	movq	0x48(%rsp), %rdx
    2f4b:      	movzbl	0x16(%rdx), %edx
    2f4f:      	cmpq	$0x38, %rdx
    2f53:      	ja	0x220 <kprobe_unwind_v8+0x220>
    2f59:      	movq	0x98(%rsp), %rsi
    2f61:      	movq	(%rsi,%rcx), %rbp
    2f65:      	testb	$0x1, %bpl
    2f69:      	jne	0x3087 <kprobe_unwind_v8+0x3087>
    2f6f:      	shrq	%rbp
    2f72:      	movq	(%rip), %rax            # 0x2f79 <kprobe_unwind_v8+0x2f79>
    2f79:      	cmpl	$0x0, (%rax)
    2f7c:      	jne	0x38f2 <kprobe_unwind_v8+0x38f2>
    2f82:      	xorl	%r15d, %r15d
    2f85:      	movzbl	0xf30(%r14), %r12d
    2f8d:      	movl	0x2c0(%r14), %eax
    2f94:      	cmpq	$0x7e, %rax
    2f98:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    2f9e:      	leal	0x1(%rax), %ecx
    2fa1:      	movl	%ecx, 0x2c0(%r14)
    2fa8:      	leaq	(%rax,%rax,2), %rax
    2fac:      	movq	%r15, 0x2d0(%r14,%rax,8)
    2fb4:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    2fbc:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    2fc5:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    2fcd:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    2fd9:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    2fe4:      	movq	0xee0(%r14), %rax
    2feb:      	movq	%rsp, %rdi
    2fee:      	movl	$0x10, %ecx
    2ff3:      	movl	$0x70, %r8d
    2ff9:      	movq	0xee0(%r14), %rdx
    3000:      	movl	$0x10, %esi
    3005:      	callq	*%r8
    3008:      	testq	%rax, %rax
    300b:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    3011:      	movq	0xee0(%r14), %rax
    3018:      	addq	$0x10, %rax
    301c:      	movq	%rax, 0xed8(%r14)
    3023:      	movq	(%rsp), %rax
    3027:      	movq	%rax, 0xee0(%r14)
    302e:      	movq	0x8(%rsp), %rax
    3033:      	movq	%rax, 0xed0(%r14)
    303a:      	movb	$0x1, 0xf30(%r14)
    3042:      	movq	(%rip), %rax            # 0x3049 <kprobe_unwind_v8+0x3049>
    3049:      	cmpl	$0x0, (%rax)
    304c:      	jne	0x394e <kprobe_unwind_v8+0x394e>
    3052:      	movl	$0x38, 0x70(%rsp)
    305a:      	movq	(%rip), %rdi            # 0x3061 <kprobe_unwind_v8+0x3061>
    3061:      	leaq	0x70(%rsp), %rsi
    3066:      	movl	$0x1, %eax
    306b:      	callq	*%rax
    306d:      	testq	%rax, %rax
    3070:      	je	0x323a <kprobe_unwind_v8+0x323a>
    3076:      	incq	(%rax)
    3079:      	movq	(%rip), %rax            # 0x3080 <kprobe_unwind_v8+0x3080>
    3080:      	movl	(%rax), %eax
    3082:      	jmp	0x324c <kprobe_unwind_v8+0x324c>
    3087:      	movq	0x98(%rsp), %rcx
    308f:      	movq	(%rcx,%rdx), %r15
    3093:      	movq	(%rcx,%rax), %r12
    3097:      	movl	%r12d, %ecx
    309a:      	andl	$0x3, %ecx
    309d:      	andq	$-0x4, %r12
    30a1:      	xorl	%eax, %eax
    30a3:      	cmpl	$0x1, %ecx
    30a6:      	cmovneq	%rax, %r12
    30aa:      	testq	%r12, %r12
    30ad:      	je	0x311e <kprobe_unwind_v8+0x311e>
    30af:      	movq	0x48(%rsp), %rax
    30b4:      	movzbl	0xc(%rax), %edx
    30b8:      	addq	%r12, %rdx
    30bb:      	movq	%rsp, %rdi
    30be:      	movl	$0x8, %eax
    30c3:      	movl	$0x70, %ecx
    30c8:      	movl	$0x8, %esi
    30cd:      	callq	*%rcx
    30cf:      	testq	%rax, %rax
    30d2:      	jne	0x311c <kprobe_unwind_v8+0x311c>
    30d4:      	movq	(%rsp), %rax
    30d8:      	movl	%eax, %ecx
    30da:      	andl	$0x3, %ecx
    30dd:      	cmpl	$0x1, %ecx
    30e0:      	jne	0x311c <kprobe_unwind_v8+0x311c>
    30e2:      	andq	$-0x4, %rax
    30e6:      	je	0x311c <kprobe_unwind_v8+0x311c>
    30e8:      	movq	0x48(%rsp), %rsi
    30ed:      	movzbl	0xd(%rsi), %ecx
    30f1:      	addq	%rax, %rcx
    30f4:      	movq	%rsp, %rdi
    30f7:      	movl	$0x2, %edx
    30fc:      	movl	$0x70, %r8d
    3102:      	movzbl	0xd(%rsi), %edx
    3106:      	addq	%rax, %rdx
    3109:      	movl	$0x2, %esi
    310e:      	callq	*%r8
    3111:      	testq	%rax, %rax
    3114:      	jne	0x311c <kprobe_unwind_v8+0x311c>
    3116:      	movzwl	(%rsp), %eax
    311a:      	jmp	0x311e <kprobe_unwind_v8+0x311e>
    311c:      	xorl	%eax, %eax
    311e:      	movq	0x48(%rsp), %rcx
    3123:      	cmpw	0x4(%rcx), %ax
    3127:      	jb	0x1c5f <kprobe_unwind_v8+0x1c5f>
    312d:      	movq	0x48(%rsp), %r8
    3132:      	cmpw	0x6(%r8), %ax
    3137:      	ja	0x494 <kprobe_unwind_v8+0x494>
    313d:      	movzbl	0xf(%r8), %edx
    3142:      	addq	%r12, %rdx
    3145:      	movq	%rsp, %rdi
    3148:      	movl	$0x8, %eax
    314d:      	movl	$0x70, %ecx
    3152:      	movl	$0x8, %esi
    3157:      	callq	*%rcx
    3159:      	testq	%rax, %rax
    315c:      	jne	0x31ed <kprobe_unwind_v8+0x31ed>
    3162:      	movq	(%rsp), %rcx
    3166:      	movq	%rcx, %rax
    3169:      	movq	%rcx, 0x50(%rsp)
    316e:      	andl	$0x3, %eax
    3171:      	cmpl	$0x1, %eax
    3174:      	jne	0x31ed <kprobe_unwind_v8+0x31ed>
    3176:      	andq	$-0x4, 0x50(%rsp)
    317c:      	je	0x31ed <kprobe_unwind_v8+0x31ed>
    317e:      	movq	0x48(%rsp), %rax
    3183:      	movzbl	0xc(%rax), %edx
    3187:      	addq	0x50(%rsp), %rdx
    318c:      	movq	%rsp, %rdi
    318f:      	movl	$0x8, %eax
    3194:      	movl	$0x70, %ecx
    3199:      	movl	$0x8, %esi
    319e:      	callq	*%rcx
    31a0:      	testq	%rax, %rax
    31a3:      	jne	0x31f4 <kprobe_unwind_v8+0x31f4>
    31a5:      	movq	(%rsp), %rax
    31a9:      	movl	%eax, %ecx
    31ab:      	andl	$0x3, %ecx
    31ae:      	cmpl	$0x1, %ecx
    31b1:      	jne	0x31f4 <kprobe_unwind_v8+0x31f4>
    31b3:      	andq	$-0x4, %rax
    31b7:      	je	0x31f4 <kprobe_unwind_v8+0x31f4>
    31b9:      	movq	0x48(%rsp), %rsi
    31be:      	movzbl	0xd(%rsi), %ecx
    31c2:      	addq	%rax, %rcx
    31c5:      	movq	%rsp, %rdi
    31c8:      	movl	$0x2, %edx
    31cd:      	movl	$0x70, %r8d
    31d3:      	movzbl	0xd(%rsi), %edx
    31d7:      	addq	%rax, %rdx
    31da:      	movl	$0x2, %esi
    31df:      	callq	*%r8
    31e2:      	testq	%rax, %rax
    31e5:      	jne	0x31f4 <kprobe_unwind_v8+0x31f4>
    31e7:      	movzwl	(%rsp), %eax
    31eb:      	jmp	0x31f6 <kprobe_unwind_v8+0x31f6>
    31ed:      	xorl	%eax, %eax
    31ef:      	movq	%rax, 0x50(%rsp)
    31f4:      	xorl	%eax, %eax
    31f6:      	movq	0x48(%rsp), %rcx
    31fb:      	cmpw	0xa(%rcx), %ax
    31ff:      	jne	0x998 <kprobe_unwind_v8+0x998>
    3205:      	movq	%r15, %rbp
    3208:      	shrq	$0x20, %rbp
    320c:      	je	0x33e4 <kprobe_unwind_v8+0x33e4>
    3212:      	andl	$0x1, %r15d
    3216:      	jne	0x33e4 <kprobe_unwind_v8+0x33e4>
    321c:      	movq	(%rip), %rax            # 0x3223 <kprobe_unwind_v8+0x3223>
    3223:      	cmpl	$0x0, (%rax)
    3226:      	jne	0x3acd <kprobe_unwind_v8+0x3acd>
    322c:      	movq	0x50(%rsp), %r15
    3231:      	orq	$0x1, %r15
    3235:      	jmp	0x368b <kprobe_unwind_v8+0x368b>
    323a:      	xorl	%eax, %eax
    323c:      	movq	(%rip), %rcx            # 0x3243 <kprobe_unwind_v8+0x3243>
    3243:      	cmpl	$0x0, (%rcx)
    3246:      	jne	0x3a55 <kprobe_unwind_v8+0x3a55>
    324c:      	movq	0xed0(%r14), %r12
    3253:      	testq	%r12, %r12
    3256:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    325c:      	testl	%eax, %eax
    325e:      	jne	0x39bb <kprobe_unwind_v8+0x39bb>
    3264:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    326e:      	cmpq	%rax, %r12
    3271:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    3277:      	cmpq	$0x1000, %r12           # imm = 0x1000
    327e:      	jb	0x285e <kprobe_unwind_v8+0x285e>
    3284:      	movl	(%r14), %eax
    3287:      	movl	$0x60, 0x70(%rsp)
    328f:      	movbel	%eax, 0x74(%rsp)
    3295:      	movbeq	%r12, 0x78(%rsp)
    329c:      	movq	(%rip), %rdi            # 0x32a3 <kprobe_unwind_v8+0x32a3>
    32a3:      	leaq	0x70(%rsp), %rsi
    32a8:      	movl	$0x1, %eax
    32ad:      	callq	*%rax
    32af:      	testq	%rax, %rax
    32b2:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    32b8:      	movq	0x8(%rax), %rbp
    32bc:      	movq	%rbp, %rcx
    32bf:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    32c9:      	andq	%rdx, %rcx
    32cc:      	movq	%rcx, 0xf20(%r14)
    32d3:      	movq	(%rax), %rax
    32d6:      	movq	%rax, 0xf10(%r14)
    32dd:      	shrq	$0x38, %rbp
    32e1:      	movq	%r12, %rax
    32e4:      	subq	%rcx, %rax
    32e7:      	movq	%rax, 0xf18(%r14)
    32ee:      	movq	(%rip), %rax            # 0x32f5 <kprobe_unwind_v8+0x32f5>
    32f5:      	cmpl	$0x0, (%rax)
    32f8:      	jne	0x3ba1 <kprobe_unwind_v8+0x3ba1>
    32fe:      	cmpl	$0x1, %ebp
    3301:      	jne	0x3dcf <kprobe_unwind_v8+0x3dcf>
    3307:      	movq	0xf10(%r14), %rax
    330e:      	movq	%rax, 0x70(%rsp)
    3313:      	movq	0xf18(%r14), %r13
    331a:      	movq	(%rip), %rdi            # 0x3321 <kprobe_unwind_v8+0x3321>
    3321:      	leaq	0x70(%rsp), %rsi
    3326:      	movl	$0x1, %eax
    332b:      	callq	*%rax
    332d:      	movl	$0x1, %ebp
    3332:      	testq	%rax, %rax
    3335:      	je	0x3dcf <kprobe_unwind_v8+0x3dcf>
    333b:      	movq	%rax, %r12
    333e:      	cmpq	%r13, (%rax)
    3341:      	ja	0x334a <kprobe_unwind_v8+0x334a>
    3343:      	cmpq	%r13, 0x8(%r12)
    3348:      	jae	0x3360 <kprobe_unwind_v8+0x3360>
    334a:      	cmpq	%r13, 0x10(%r12)
    334f:      	ja	0x3dcf <kprobe_unwind_v8+0x3dcf>
    3355:      	cmpq	%r13, 0x18(%r12)
    335a:      	jb	0x3dcf <kprobe_unwind_v8+0x3dcf>
    3360:      	movq	(%rip), %rax            # 0x3367 <kprobe_unwind_v8+0x3367>
    3367:      	cmpl	$0x0, (%rax)
    336a:      	jne	0x3d28 <kprobe_unwind_v8+0x3d28>
    3370:      	movl	0x1380(%r14), %eax
    3377:      	movl	0x20(%r12), %ecx
    337c:      	btl	%ecx, %eax
    337f:      	jae	0x3d94 <kprobe_unwind_v8+0x3d94>
    3385:      	movq	(%rip), %rax            # 0x338c <kprobe_unwind_v8+0x338c>
    338c:      	cmpl	$0x0, (%rax)
    338f:      	je	0x3dcf <kprobe_unwind_v8+0x3dcf>
    3395:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    339f:      	movq	%rax, 0x10(%rsp)
    33a4:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    33ae:      	movq	%rax, 0x8(%rsp)
    33b3:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    33bd:      	movq	%rax, (%rsp)
    33c1:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    33c9:      	movq	%rsp, %rdi
    33cc:      	movl	$0x1b, %eax
    33d1:      	movl	$0x6, %ecx
    33d6:      	movl	$0x1b, %esi
    33db:      	xorl	%eax, %eax
    33dd:      	callq	*%rcx
    33df:      	jmp	0x3dcf <kprobe_unwind_v8+0x3dcf>
    33e4:      	movq	0x48(%rsp), %rax
    33e9:      	movzbl	0xe(%rax), %edx
    33ed:      	addq	%r12, %rdx
    33f0:      	movq	%rsp, %rdi
    33f3:      	movl	$0x8, %eax
    33f8:      	movl	$0x70, %ecx
    33fd:      	movl	$0x8, %esi
    3402:      	callq	*%rcx
    3404:      	testq	%rax, %rax
    3407:      	jne	0x3498 <kprobe_unwind_v8+0x3498>
    340d:      	movq	(%rsp), %rcx
    3411:      	movq	%rcx, %rax
    3414:      	movq	%rcx, 0x58(%rsp)
    3419:      	andl	$0x3, %eax
    341c:      	cmpl	$0x1, %eax
    341f:      	jne	0x3498 <kprobe_unwind_v8+0x3498>
    3421:      	andq	$-0x4, 0x58(%rsp)
    3427:      	je	0x3498 <kprobe_unwind_v8+0x3498>
    3429:      	movq	0x48(%rsp), %rax
    342e:      	movzbl	0xc(%rax), %edx
    3432:      	addq	0x58(%rsp), %rdx
    3437:      	movq	%rsp, %rdi
    343a:      	movl	$0x8, %eax
    343f:      	movl	$0x70, %ecx
    3444:      	movl	$0x8, %esi
    3449:      	callq	*%rcx
    344b:      	testq	%rax, %rax
    344e:      	jne	0x349f <kprobe_unwind_v8+0x349f>
    3450:      	movq	(%rsp), %rax
    3454:      	movl	%eax, %ecx
    3456:      	andl	$0x3, %ecx
    3459:      	cmpl	$0x1, %ecx
    345c:      	jne	0x349f <kprobe_unwind_v8+0x349f>
    345e:      	andq	$-0x4, %rax
    3462:      	je	0x349f <kprobe_unwind_v8+0x349f>
    3464:      	movq	0x48(%rsp), %rsi
    3469:      	movzbl	0xd(%rsi), %ecx
    346d:      	addq	%rax, %rcx
    3470:      	movq	%rsp, %rdi
    3473:      	movl	$0x2, %edx
    3478:      	movl	$0x70, %r8d
    347e:      	movzbl	0xd(%rsi), %edx
    3482:      	addq	%rax, %rdx
    3485:      	movl	$0x2, %esi
    348a:      	callq	*%r8
    348d:      	testq	%rax, %rax
    3490:      	jne	0x349f <kprobe_unwind_v8+0x349f>
    3492:      	movzwl	(%rsp), %eax
    3496:      	jmp	0x34a1 <kprobe_unwind_v8+0x34a1>
    3498:      	xorl	%eax, %eax
    349a:      	movq	%rax, 0x58(%rsp)
    349f:      	xorl	%eax, %eax
    34a1:      	movq	0x50(%rsp), %r15
    34a6:      	orq	$0x2, %r15
    34aa:      	movq	0x48(%rsp), %rcx
    34af:      	cmpw	0x8(%rcx), %ax
    34b3:      	jne	0x35e9 <kprobe_unwind_v8+0x35e9>
    34b9:      	movl	$0x60, %eax
    34be:      	movl	$0x70, %ecx
    34c3:      	movq	0xb0(%rsp), %rdi
    34cb:      	movq	0x58(%rsp), %rdx
    34d0:      	movl	$0x60, %esi
    34d5:      	callq	*%rcx
    34d7:      	testq	%rax, %rax
    34da:      	je	0x361e <kprobe_unwind_v8+0x361e>
    34e0:      	movl	$0x3b, 0x70(%rsp)
    34e8:      	movq	(%rip), %rdi            # 0x34ef <kprobe_unwind_v8+0x34ef>
    34ef:      	leaq	0x70(%rsp), %rsi
    34f4:      	movl	$0x1, %eax
    34f9:      	callq	*%rax
    34fb:      	testq	%rax, %rax
    34fe:      	jne	0x3619 <kprobe_unwind_v8+0x3619>
    3504:      	movq	(%rip), %rax            # 0x350b <kprobe_unwind_v8+0x350b>
    350b:      	cmpl	$0x0, (%rax)
    350e:      	je	0x3689 <kprobe_unwind_v8+0x3689>
    3514:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    351e:      	movq	%rax, 0x26(%rsp)
    3523:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    352d:      	movq	%rax, 0x20(%rsp)
    3532:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    353c:      	movq	%rax, 0x18(%rsp)
    3541:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    354b:      	movq	%rax, 0x10(%rsp)
    3550:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    355a:      	movq	%rax, 0x8(%rsp)
    355f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3569:      	movq	%rax, (%rsp)
    356d:      	movq	%rsp, %rdi
    3570:      	movl	$0x2e, %eax
    3575:      	movl	$0x6, %ecx
    357a:      	jmp	0x3d16 <kprobe_unwind_v8+0x3d16>
    357f:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    3589:      	movq	%rax, 0x17(%rsp)
    358e:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    3598:      	movq	%rax, 0x10(%rsp)
    359d:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    35a7:      	movq	%rax, 0x8(%rsp)
    35ac:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    35b6:      	movq	%rax, (%rsp)
    35ba:      	movq	%rsp, %rdi
    35bd:      	movl	$0x1f, %eax
    35c2:      	movl	$0x6, %r9d
    35c8:      	movl	$0x1f, %esi
    35cd:      	movq	%r13, %rdx
    35d0:      	movq	%r12, %rcx
    35d3:      	movq	%rbp, %r8
    35d6:      	xorl	%eax, %eax
    35d8:      	callq	*%r9
    35db:      	cmpq	%r12, %rbp
    35de:      	jae	0x2edd <kprobe_unwind_v8+0x2edd>
    35e4:      	jmp	0x2025 <kprobe_unwind_v8+0x2025>
    35e9:      	movq	(%rip), %rcx            # 0x35f0 <kprobe_unwind_v8+0x35f0>
    35f0:      	cmpl	$0x0, (%rcx)
    35f3:      	jne	0x3b1f <kprobe_unwind_v8+0x3b1f>
    35f9:      	movl	$0x3b, 0x70(%rsp)
    3601:      	movq	(%rip), %rdi            # 0x3608 <kprobe_unwind_v8+0x3608>
    3608:      	leaq	0x70(%rsp), %rsi
    360d:      	movl	$0x1, %eax
    3612:      	callq	*%rax
    3614:      	testq	%rax, %rax
    3617:      	je	0x3679 <kprobe_unwind_v8+0x3679>
    3619:      	incq	(%rax)
    361c:      	jmp	0x3689 <kprobe_unwind_v8+0x3689>
    361e:      	movq	0x48(%rsp), %rax
    3623:      	movzbl	0x12(%rax), %ecx
    3627:      	xorl	%ebp, %ebp
    3629:      	cmpq	$0x5c, %rcx
    362d:      	ja	0x220 <kprobe_unwind_v8+0x220>
    3633:      	movq	0x48(%rsp), %rax
    3638:      	movzbl	0x13(%rax), %eax
    363c:      	cmpq	$0x5c, %rax
    3640:      	ja	0x220 <kprobe_unwind_v8+0x220>
    3646:      	movq	0x48(%rsp), %rdx
    364b:      	cmpb	$0x0, 0x10(%rdx)
    364f:      	movzbl	0x11(%rdx), %edx
    3653:      	movq	%rdx, 0x68(%rsp)
    3658:      	je	0x3824 <kprobe_unwind_v8+0x3824>
    365e:      	movq	0xb0(%rsp), %rdx
    3666:      	movq	0x68(%rsp), %rsi
    366b:      	movq	(%rdx,%rsi), %rsi
    366f:      	movq	%rsi, 0x68(%rsp)
    3674:      	jmp	0x3833 <kprobe_unwind_v8+0x3833>
    3679:      	movq	(%rip), %rax            # 0x3680 <kprobe_unwind_v8+0x3680>
    3680:      	cmpl	$0x0, (%rax)
    3683:      	jne	0x3cb0 <kprobe_unwind_v8+0x3cb0>
    3689:      	xorl	%ebp, %ebp
    368b:      	movzbl	0xf30(%r14), %r12d
    3693:      	movq	(%rip), %rax            # 0x369a <kprobe_unwind_v8+0x369a>
    369a:      	cmpl	$0x0, (%rax)
    369d:      	je	0x2f8d <kprobe_unwind_v8+0x2f8d>
    36a3:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    36ad:      	movq	%rax, 0x30(%rsp)
    36b2:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    36bc:      	movq	%rax, 0x28(%rsp)
    36c1:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    36cb:      	movq	%rax, 0x20(%rsp)
    36d0:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    36da:      	movq	%rax, 0x18(%rsp)
    36df:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    36e9:      	movq	%rax, 0x10(%rsp)
    36ee:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    36f8:      	movq	%rax, 0x8(%rsp)
    36fd:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3707:      	movq	%rax, (%rsp)
    370b:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    3713:      	movq	%rsp, %rdi
    3716:      	movl	$0x3c, %eax
    371b:      	movl	$0x6, %r8d
    3721:      	movl	$0x3c, %esi
    3726:      	movq	%rbp, %rdx
    3729:      	movq	%r15, %rcx
    372c:      	xorl	%eax, %eax
    372e:      	callq	*%r8
    3731:      	jmp	0x2f8d <kprobe_unwind_v8+0x2f8d>
    3736:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    3740:      	movq	%rax, 0x28(%rsp)
    3745:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    374f:      	movq	%rax, 0x20(%rsp)
    3754:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    375e:      	movq	%rax, 0x18(%rsp)
    3763:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    376d:      	movq	%rax, 0x10(%rsp)
    3772:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    377c:      	movq	%rax, 0x8(%rsp)
    3781:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    378b:      	movq	%rax, (%rsp)
    378f:      	movq	%rsp, %rdi
    3792:      	movl	$0x30, %eax
    3797:      	movl	$0x6, %ecx
    379c:      	xorl	%ebp, %ebp
    379e:      	movl	$0x30, %esi
    37a3:      	xorl	%eax, %eax
    37a5:      	callq	*%rcx
    37a7:      	jmp	0x23c5 <kprobe_unwind_v8+0x23c5>
    37ac:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    37b6:      	movq	%rax, 0x26(%rsp)
    37bb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    37c5:      	movq	%rax, 0x20(%rsp)
    37ca:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    37d4:      	movq	%rax, 0x18(%rsp)
    37d9:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    37e3:      	movq	%rax, 0x10(%rsp)
    37e8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    37f2:      	movq	%rax, 0x8(%rsp)
    37f7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3801:      	movq	%rax, (%rsp)
    3805:      	movq	%rsp, %rdi
    3808:      	movl	$0x2e, %eax
    380d:      	movl	$0x6, %ecx
    3812:      	movl	0x64(%rsp), %edx
    3816:      	movl	$0x2e, %esi
    381b:      	xorl	%eax, %eax
    381d:      	callq	*%rcx
    381f:      	jmp	0x2e9d <kprobe_unwind_v8+0x2e9d>
    3824:      	movq	0x68(%rsp), %rdx
    3829:      	addq	0x58(%rsp), %rdx
    382e:      	movq	%rdx, 0x68(%rsp)
    3833:      	movq	0xb0(%rsp), %rdx
    383b:      	movl	(%rdx,%rcx), %esi
    383e:      	movq	0x48(%rsp), %rcx
    3843:      	movzbl	0x17(%rcx), %edi
    3847:      	movl	%edi, 0xb8(%rsp)
    384e:      	movzbl	0x18(%rcx), %ecx
    3852:      	movq	%rsi, 0xa0(%rsp)
    385a:      	addq	0x68(%rsp), %rsi
    385f:      	movq	%rsi, 0x90(%rsp)
    3867:      	andl	(%rdx,%rax), %ecx
    386a:      	movl	%ecx, 0xac(%rsp)
    3871:      	movq	(%rip), %rax            # 0x3878 <kprobe_unwind_v8+0x3878>
    3878:      	cmpl	$0x0, (%rax)
    387b:      	jne	0x4740 <kprobe_unwind_v8+0x4740>
    3881:      	movq	%r13, %rbp
    3884:      	subq	0x68(%rsp), %rbp
    3889:      	jb	0x38db <kprobe_unwind_v8+0x38db>
    388b:      	cmpq	0x90(%rsp), %r13
    3893:      	jae	0x38db <kprobe_unwind_v8+0x38db>
    3895:      	movl	0xb8(%rsp), %eax
    389c:      	shrxl	%eax, 0xac(%rsp), %eax
    38a6:      	movq	0x48(%rsp), %rcx
    38ab:      	movzbl	0x19(%rcx), %ecx
    38af:      	orq	$0x4, %r12
    38b3:      	movq	0x58(%rsp), %r15
    38b8:      	orq	$0x3, %r15
    38bc:      	cmpl	%ecx, %eax
    38be:      	cmoveq	%r12, %r15
    38c2:      	movq	0xa0(%rsp), %rcx
    38ca:      	shll	$0x4, %ecx
    38cd:      	orl	%eax, %ecx
    38cf:      	shlq	$0x20, %rcx
    38d3:      	orq	%rcx, %rbp
    38d6:      	jmp	0x368b <kprobe_unwind_v8+0x368b>
    38db:      	movq	(%rip), %rax            # 0x38e2 <kprobe_unwind_v8+0x38e2>
    38e2:      	cmpl	$0x0, (%rax)
    38e5:      	jne	0x4840 <kprobe_unwind_v8+0x4840>
    38eb:      	xorl	%ebp, %ebp
    38ed:      	jmp	0x2f85 <kprobe_unwind_v8+0x2f85>
    38f2:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    38fc:      	movq	%rax, 0x15(%rsp)
    3901:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    390b:      	movq	%rax, 0x10(%rsp)
    3910:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    391a:      	movq	%rax, 0x8(%rsp)
    391f:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    3929:      	movq	%rax, (%rsp)
    392d:      	movq	%rsp, %rdi
    3930:      	movl	$0x1d, %eax
    3935:      	movl	$0x6, %ecx
    393a:      	xorl	%r15d, %r15d
    393d:      	movl	$0x1d, %esi
    3942:      	movq	%rbp, %rdx
    3945:      	xorl	%eax, %eax
    3947:      	callq	*%rcx
    3949:      	jmp	0x368b <kprobe_unwind_v8+0x368b>
    394e:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    3958:      	movq	%rax, 0x17(%rsp)
    395d:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    3967:      	movq	%rax, 0x10(%rsp)
    396c:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    3976:      	movq	%rax, 0x8(%rsp)
    397b:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    3985:      	movq	%rax, (%rsp)
    3989:      	movq	%rsp, %rdi
    398c:      	movl	$0x1f, %eax
    3991:      	movl	$0x6, %r9d
    3997:      	movq	0xed0(%r14), %rdx
    399e:      	movq	0xed8(%r14), %rcx
    39a5:      	movq	0xee0(%r14), %r8
    39ac:      	movl	$0x1f, %esi
    39b1:      	xorl	%eax, %eax
    39b3:      	callq	*%r9
    39b6:      	jmp	0x3052 <kprobe_unwind_v8+0x3052>
    39bb:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    39c5:      	movq	%rax, 0x28(%rsp)
    39ca:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    39d4:      	movq	%rax, 0x20(%rsp)
    39d9:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    39e3:      	movq	%rax, 0x18(%rsp)
    39e8:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    39f2:      	movq	%rax, 0x10(%rsp)
    39f7:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    3a01:      	movq	%rax, 0x8(%rsp)
    3a06:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    3a10:      	movq	%rax, (%rsp)
    3a14:      	movb	$0x0, 0x30(%rsp)
    3a19:      	movq	%rsp, %rdi
    3a1c:      	movl	$0x31, %eax
    3a21:      	movl	$0x6, %ecx
    3a26:      	movl	0x2c0(%r14), %edx
    3a2d:      	movl	$0x31, %esi
    3a32:      	xorl	%eax, %eax
    3a34:      	callq	*%rcx
    3a36:      	movq	0xed0(%r14), %r12
    3a3d:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3a47:      	cmpq	%rax, %r12
    3a4a:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    3a50:      	jmp	0x3277 <kprobe_unwind_v8+0x3277>
    3a55:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3a5f:      	movq	%rax, 0x26(%rsp)
    3a64:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3a6e:      	movq	%rax, 0x20(%rsp)
    3a73:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3a7d:      	movq	%rax, 0x18(%rsp)
    3a82:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3a8c:      	movq	%rax, 0x10(%rsp)
    3a91:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3a9b:      	movq	%rax, 0x8(%rsp)
    3aa0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3aaa:      	movq	%rax, (%rsp)
    3aae:      	movq	%rsp, %rdi
    3ab1:      	movl	$0x2e, %eax
    3ab6:      	movl	$0x6, %ecx
    3abb:      	movl	0x70(%rsp), %edx
    3abf:      	movl	$0x2e, %esi
    3ac4:      	xorl	%eax, %eax
    3ac6:      	callq	*%rcx
    3ac8:      	jmp	0x3079 <kprobe_unwind_v8+0x3079>
    3acd:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    3ad7:      	movq	%rax, 0x10(%rsp)
    3adc:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    3ae6:      	movq	%rax, 0x8(%rsp)
    3aeb:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    3af5:      	movq	%rax, (%rsp)
    3af9:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    3b01:      	movq	%rsp, %rdi
    3b04:      	movl	$0x1c, %eax
    3b09:      	movl	$0x6, %ecx
    3b0e:      	movl	$0x1c, %esi
    3b13:      	movq	%rbp, %rdx
    3b16:      	xorl	%eax, %eax
    3b18:      	callq	*%rcx
    3b1a:      	jmp	0x322c <kprobe_unwind_v8+0x322c>
    3b1f:      	movzwl	%ax, %r8d
    3b23:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    3b2d:      	movq	%rax, 0x26(%rsp)
    3b32:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    3b3c:      	movq	%rax, 0x20(%rsp)
    3b41:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    3b4b:      	movq	%rax, 0x18(%rsp)
    3b50:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    3b5a:      	movq	%rax, 0x10(%rsp)
    3b5f:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    3b69:      	movq	%rax, 0x8(%rsp)
    3b6e:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    3b78:      	movq	%rax, (%rsp)
    3b7c:      	movq	%rsp, %rdi
    3b7f:      	movl	$0x2e, %eax
    3b84:      	movl	$0x6, %r9d
    3b8a:      	movl	$0x2e, %esi
    3b8f:      	movq	%r12, %rdx
    3b92:      	movq	0x58(%rsp), %rcx
    3b97:      	xorl	%eax, %eax
    3b99:      	callq	*%r9
    3b9c:      	jmp	0x35f9 <kprobe_unwind_v8+0x35f9>
    3ba1:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    3bab:      	movq	%rax, 0x28(%rsp)
    3bb0:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    3bba:      	movq	%rax, 0x20(%rsp)
    3bbf:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    3bc9:      	movq	%rax, 0x18(%rsp)
    3bce:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    3bd8:      	movq	%rax, 0x10(%rsp)
    3bdd:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    3be7:      	movq	%rax, 0x8(%rsp)
    3bec:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    3bf6:      	movq	%r13, (%rsp)
    3bfa:      	movw	$0xa, 0x30(%rsp)
    3c01:      	movq	%rsp, %rdi
    3c04:      	movl	$0x32, %eax
    3c09:      	movl	$0x6, %r9d
    3c0f:      	movq	0xf10(%r14), %rcx
    3c16:      	movl	$0x32, %esi
    3c1b:      	movq	%r12, %rdx
    3c1e:      	movl	%ebp, %r8d
    3c21:      	xorl	%eax, %eax
    3c23:      	callq	*%r9
    3c26:      	movq	(%rip), %rax            # 0x3c2d <kprobe_unwind_v8+0x3c2d>
    3c2d:      	cmpl	$0x0, (%rax)
    3c30:      	je	0x32fe <kprobe_unwind_v8+0x32fe>
    3c36:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    3c40:      	movq	%rax, 0x27(%rsp)
    3c45:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    3c4f:      	movq	%rax, 0x20(%rsp)
    3c54:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    3c5e:      	movq	%rax, 0x18(%rsp)
    3c63:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    3c6d:      	movq	%rax, 0x10(%rsp)
    3c72:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    3c7c:      	movq	%rax, 0x8(%rsp)
    3c81:      	movq	%r13, (%rsp)
    3c85:      	movq	%rsp, %rdi
    3c88:      	movl	$0x2f, %eax
    3c8d:      	movl	$0x6, %r8d
    3c93:      	movq	0xf18(%r14), %rcx
    3c9a:      	movq	0xf20(%r14), %rdx
    3ca1:      	movl	$0x2f, %esi
    3ca6:      	xorl	%eax, %eax
    3ca8:      	callq	*%r8
    3cab:      	jmp	0x32fe <kprobe_unwind_v8+0x32fe>
    3cb0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3cba:      	movq	%rax, 0x26(%rsp)
    3cbf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3cc9:      	movq	%rax, 0x20(%rsp)
    3cce:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3cd8:      	movq	%rax, 0x18(%rsp)
    3cdd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3ce7:      	movq	%rax, 0x10(%rsp)
    3cec:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3cf6:      	movq	%rax, 0x8(%rsp)
    3cfb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3d05:      	movq	%rax, (%rsp)
    3d09:      	movq	%rsp, %rdi
    3d0c:      	movl	$0x2e, %eax
    3d11:      	movl	$0x6, %ecx
    3d16:      	movl	0x70(%rsp), %edx
    3d1a:      	movl	$0x2e, %esi
    3d1f:      	xorl	%eax, %eax
    3d21:      	callq	*%rcx
    3d23:      	jmp	0x3689 <kprobe_unwind_v8+0x3689>
    3d28:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    3d32:      	movq	%rax, 0x16(%rsp)
    3d37:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    3d41:      	movq	%rax, 0x10(%rsp)
    3d46:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    3d50:      	movq	%rax, 0x8(%rsp)
    3d55:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3d5f:      	movq	%rax, (%rsp)
    3d63:      	movq	%rsp, %rdi
    3d66:      	movl	$0x1e, %eax
    3d6b:      	movl	$0x6, %ecx
    3d70:      	movzwl	0x20(%r12), %edx
    3d76:      	movl	$0x1e, %esi
    3d7b:      	xorl	%eax, %eax
    3d7d:      	callq	*%rcx
    3d7f:      	movl	0x1380(%r14), %eax
    3d86:      	movl	0x20(%r12), %ecx
    3d8b:      	btl	%ecx, %eax
    3d8e:      	jb	0x3385 <kprobe_unwind_v8+0x3385>
    3d94:      	movl	$0x0, 0x64(%rsp)
    3d9c:      	movq	(%rip), %rdi            # 0x3da3 <kprobe_unwind_v8+0x3da3>
    3da3:      	leaq	0x64(%rsp), %rsi
    3da8:      	movl	$0x1, %eax
    3dad:      	callq	*%rax
    3daf:      	testq	%rax, %rax
    3db2:      	je	0x3db9 <kprobe_unwind_v8+0x3db9>
    3db4:      	incq	(%rax)
    3db7:      	jmp	0x3dc9 <kprobe_unwind_v8+0x3dc9>
    3db9:      	movq	(%rip), %rax            # 0x3dc0 <kprobe_unwind_v8+0x3dc0>
    3dc0:      	cmpl	$0x0, (%rax)
    3dc3:      	jne	0x48b6 <kprobe_unwind_v8+0x48b6>
    3dc9:      	movzwl	0x20(%r12), %ebp
    3dcf:      	xorl	%r12d, %r12d
    3dd2:      	cmpl	$0x7, %ebp
    3dd5:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    3ddb:      	movq	0xed0(%r14), %r13
    3de2:      	movq	0xed8(%r14), %r12
    3de9:      	movq	0xee0(%r14), %rbp
    3df0:      	movq	(%rip), %rax            # 0x3df7 <kprobe_unwind_v8+0x3df7>
    3df7:      	cmpl	$0x0, (%rax)
    3dfa:      	jne	0x4579 <kprobe_unwind_v8+0x4579>
    3e00:      	cmpq	%r12, %rbp
    3e03:      	jb	0x2025 <kprobe_unwind_v8+0x2025>
    3e09:      	leaq	0x2000(%r12), %rax
    3e11:      	cmpq	%rax, %rbp
    3e14:      	jae	0x2025 <kprobe_unwind_v8+0x2025>
    3e1a:      	addq	$-0x40, %rbp
    3e1e:      	movl	$0x40, %eax
    3e23:      	movl	$0x70, %ecx
    3e28:      	movq	0x98(%rsp), %rdi
    3e30:      	movl	$0x40, %esi
    3e35:      	movq	%rbp, %rdx
    3e38:      	callq	*%rcx
    3e3a:      	testq	%rax, %rax
    3e3d:      	movq	(%rip), %rbp            # 0x3e44 <kprobe_unwind_v8+0x3e44>
    3e44:      	jne	0x138 <kprobe_unwind_v8+0x138>
    3e4a:      	movq	0x48(%rsp), %rax
    3e4f:      	movzbl	0x14(%rax), %ecx
    3e53:      	xorl	%ebp, %ebp
    3e55:      	cmpq	$0x38, %rcx
    3e59:      	ja	0x220 <kprobe_unwind_v8+0x220>
    3e5f:      	movq	0x48(%rsp), %rax
    3e64:      	movzbl	0x15(%rax), %eax
    3e68:      	cmpq	$0x38, %rax
    3e6c:      	ja	0x220 <kprobe_unwind_v8+0x220>
    3e72:      	movq	0x48(%rsp), %rdx
    3e77:      	movzbl	0x16(%rdx), %edx
    3e7b:      	cmpq	$0x38, %rdx
    3e7f:      	ja	0x220 <kprobe_unwind_v8+0x220>
    3e85:      	movq	0x98(%rsp), %rsi
    3e8d:      	movq	(%rsi,%rcx), %rbp
    3e91:      	testb	$0x1, %bpl
    3e95:      	jne	0x3fb3 <kprobe_unwind_v8+0x3fb3>
    3e9b:      	shrq	%rbp
    3e9e:      	movq	(%rip), %rax            # 0x3ea5 <kprobe_unwind_v8+0x3ea5>
    3ea5:      	cmpl	$0x0, (%rax)
    3ea8:      	jne	0x492e <kprobe_unwind_v8+0x492e>
    3eae:      	xorl	%r15d, %r15d
    3eb1:      	movzbl	0xf30(%r14), %r12d
    3eb9:      	movl	0x2c0(%r14), %eax
    3ec0:      	cmpq	$0x7e, %rax
    3ec4:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    3eca:      	leal	0x1(%rax), %ecx
    3ecd:      	movl	%ecx, 0x2c0(%r14)
    3ed4:      	leaq	(%rax,%rax,2), %rax
    3ed8:      	movq	%r15, 0x2d0(%r14,%rax,8)
    3ee0:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    3ee8:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    3ef1:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    3ef9:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    3f05:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    3f10:      	movq	0xee0(%r14), %rax
    3f17:      	movq	%rsp, %rdi
    3f1a:      	movl	$0x10, %ecx
    3f1f:      	movl	$0x70, %r8d
    3f25:      	movq	0xee0(%r14), %rdx
    3f2c:      	movl	$0x10, %esi
    3f31:      	callq	*%r8
    3f34:      	testq	%rax, %rax
    3f37:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    3f3d:      	movq	0xee0(%r14), %rax
    3f44:      	addq	$0x10, %rax
    3f48:      	movq	%rax, 0xed8(%r14)
    3f4f:      	movq	(%rsp), %rax
    3f53:      	movq	%rax, 0xee0(%r14)
    3f5a:      	movq	0x8(%rsp), %rax
    3f5f:      	movq	%rax, 0xed0(%r14)
    3f66:      	movb	$0x1, 0xf30(%r14)
    3f6e:      	movq	(%rip), %rax            # 0x3f75 <kprobe_unwind_v8+0x3f75>
    3f75:      	cmpl	$0x0, (%rax)
    3f78:      	jne	0x498a <kprobe_unwind_v8+0x498a>
    3f7e:      	movl	$0x38, 0x70(%rsp)
    3f86:      	movq	(%rip), %rdi            # 0x3f8d <kprobe_unwind_v8+0x3f8d>
    3f8d:      	leaq	0x70(%rsp), %rsi
    3f92:      	movl	$0x1, %eax
    3f97:      	callq	*%rax
    3f99:      	testq	%rax, %rax
    3f9c:      	je	0x4166 <kprobe_unwind_v8+0x4166>
    3fa2:      	incq	(%rax)
    3fa5:      	movq	(%rip), %rax            # 0x3fac <kprobe_unwind_v8+0x3fac>
    3fac:      	movl	(%rax), %eax
    3fae:      	jmp	0x4178 <kprobe_unwind_v8+0x4178>
    3fb3:      	movq	0x98(%rsp), %rcx
    3fbb:      	movq	(%rcx,%rdx), %r15
    3fbf:      	movq	(%rcx,%rax), %r12
    3fc3:      	movl	%r12d, %ecx
    3fc6:      	andl	$0x3, %ecx
    3fc9:      	andq	$-0x4, %r12
    3fcd:      	xorl	%eax, %eax
    3fcf:      	cmpl	$0x1, %ecx
    3fd2:      	cmovneq	%rax, %r12
    3fd6:      	testq	%r12, %r12
    3fd9:      	je	0x404a <kprobe_unwind_v8+0x404a>
    3fdb:      	movq	0x48(%rsp), %rax
    3fe0:      	movzbl	0xc(%rax), %edx
    3fe4:      	addq	%r12, %rdx
    3fe7:      	movq	%rsp, %rdi
    3fea:      	movl	$0x8, %eax
    3fef:      	movl	$0x70, %ecx
    3ff4:      	movl	$0x8, %esi
    3ff9:      	callq	*%rcx
    3ffb:      	testq	%rax, %rax
    3ffe:      	jne	0x4048 <kprobe_unwind_v8+0x4048>
    4000:      	movq	(%rsp), %rax
    4004:      	movl	%eax, %ecx
    4006:      	andl	$0x3, %ecx
    4009:      	cmpl	$0x1, %ecx
    400c:      	jne	0x4048 <kprobe_unwind_v8+0x4048>
    400e:      	andq	$-0x4, %rax
    4012:      	je	0x4048 <kprobe_unwind_v8+0x4048>
    4014:      	movq	0x48(%rsp), %rsi
    4019:      	movzbl	0xd(%rsi), %ecx
    401d:      	addq	%rax, %rcx
    4020:      	movq	%rsp, %rdi
    4023:      	movl	$0x2, %edx
    4028:      	movl	$0x70, %r8d
    402e:      	movzbl	0xd(%rsi), %edx
    4032:      	addq	%rax, %rdx
    4035:      	movl	$0x2, %esi
    403a:      	callq	*%r8
    403d:      	testq	%rax, %rax
    4040:      	jne	0x4048 <kprobe_unwind_v8+0x4048>
    4042:      	movzwl	(%rsp), %eax
    4046:      	jmp	0x404a <kprobe_unwind_v8+0x404a>
    4048:      	xorl	%eax, %eax
    404a:      	movq	0x48(%rsp), %rcx
    404f:      	cmpw	0x4(%rcx), %ax
    4053:      	jb	0x1c5f <kprobe_unwind_v8+0x1c5f>
    4059:      	movq	0x48(%rsp), %r8
    405e:      	cmpw	0x6(%r8), %ax
    4063:      	ja	0x494 <kprobe_unwind_v8+0x494>
    4069:      	movzbl	0xf(%r8), %edx
    406e:      	addq	%r12, %rdx
    4071:      	movq	%rsp, %rdi
    4074:      	movl	$0x8, %eax
    4079:      	movl	$0x70, %ecx
    407e:      	movl	$0x8, %esi
    4083:      	callq	*%rcx
    4085:      	testq	%rax, %rax
    4088:      	jne	0x4119 <kprobe_unwind_v8+0x4119>
    408e:      	movq	(%rsp), %rcx
    4092:      	movq	%rcx, %rax
    4095:      	movq	%rcx, 0x50(%rsp)
    409a:      	andl	$0x3, %eax
    409d:      	cmpl	$0x1, %eax
    40a0:      	jne	0x4119 <kprobe_unwind_v8+0x4119>
    40a2:      	andq	$-0x4, 0x50(%rsp)
    40a8:      	je	0x4119 <kprobe_unwind_v8+0x4119>
    40aa:      	movq	0x48(%rsp), %rax
    40af:      	movzbl	0xc(%rax), %edx
    40b3:      	addq	0x50(%rsp), %rdx
    40b8:      	movq	%rsp, %rdi
    40bb:      	movl	$0x8, %eax
    40c0:      	movl	$0x70, %ecx
    40c5:      	movl	$0x8, %esi
    40ca:      	callq	*%rcx
    40cc:      	testq	%rax, %rax
    40cf:      	jne	0x4120 <kprobe_unwind_v8+0x4120>
    40d1:      	movq	(%rsp), %rax
    40d5:      	movl	%eax, %ecx
    40d7:      	andl	$0x3, %ecx
    40da:      	cmpl	$0x1, %ecx
    40dd:      	jne	0x4120 <kprobe_unwind_v8+0x4120>
    40df:      	andq	$-0x4, %rax
    40e3:      	je	0x4120 <kprobe_unwind_v8+0x4120>
    40e5:      	movq	0x48(%rsp), %rsi
    40ea:      	movzbl	0xd(%rsi), %ecx
    40ee:      	addq	%rax, %rcx
    40f1:      	movq	%rsp, %rdi
    40f4:      	movl	$0x2, %edx
    40f9:      	movl	$0x70, %r8d
    40ff:      	movzbl	0xd(%rsi), %edx
    4103:      	addq	%rax, %rdx
    4106:      	movl	$0x2, %esi
    410b:      	callq	*%r8
    410e:      	testq	%rax, %rax
    4111:      	jne	0x4120 <kprobe_unwind_v8+0x4120>
    4113:      	movzwl	(%rsp), %eax
    4117:      	jmp	0x4122 <kprobe_unwind_v8+0x4122>
    4119:      	xorl	%eax, %eax
    411b:      	movq	%rax, 0x50(%rsp)
    4120:      	xorl	%eax, %eax
    4122:      	movq	0x48(%rsp), %rcx
    4127:      	cmpw	0xa(%rcx), %ax
    412b:      	jne	0x998 <kprobe_unwind_v8+0x998>
    4131:      	movq	%r15, %rbp
    4134:      	shrq	$0x20, %rbp
    4138:      	je	0x4469 <kprobe_unwind_v8+0x4469>
    413e:      	andl	$0x1, %r15d
    4142:      	jne	0x4469 <kprobe_unwind_v8+0x4469>
    4148:      	movq	(%rip), %rax            # 0x414f <kprobe_unwind_v8+0x414f>
    414f:      	cmpl	$0x0, (%rax)
    4152:      	jne	0x49f7 <kprobe_unwind_v8+0x49f7>
    4158:      	movq	0x50(%rsp), %r15
    415d:      	orq	$0x1, %r15
    4161:      	jmp	0x5310 <kprobe_unwind_v8+0x5310>
    4166:      	xorl	%eax, %eax
    4168:      	movq	(%rip), %rcx            # 0x416f <kprobe_unwind_v8+0x416f>
    416f:      	cmpl	$0x0, (%rcx)
    4172:      	jne	0x4a49 <kprobe_unwind_v8+0x4a49>
    4178:      	movq	0xed0(%r14), %r12
    417f:      	testq	%r12, %r12
    4182:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    4188:      	testl	%eax, %eax
    418a:      	jne	0x4ac1 <kprobe_unwind_v8+0x4ac1>
    4190:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    419a:      	cmpq	%rax, %r12
    419d:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    41a3:      	cmpq	$0x1000, %r12           # imm = 0x1000
    41aa:      	jb	0x285e <kprobe_unwind_v8+0x285e>
    41b0:      	movl	(%r14), %eax
    41b3:      	movl	$0x60, 0x70(%rsp)
    41bb:      	movbel	%eax, 0x74(%rsp)
    41c1:      	movbeq	%r12, 0x78(%rsp)
    41c8:      	movq	(%rip), %rdi            # 0x41cf <kprobe_unwind_v8+0x41cf>
    41cf:      	leaq	0x70(%rsp), %rsi
    41d4:      	movl	$0x1, %eax
    41d9:      	callq	*%rax
    41db:      	testq	%rax, %rax
    41de:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    41e4:      	movq	0x8(%rax), %rbp
    41e8:      	movq	%rbp, %rcx
    41eb:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    41f5:      	andq	%rdx, %rcx
    41f8:      	movq	%rcx, 0xf20(%r14)
    41ff:      	movq	(%rax), %rax
    4202:      	movq	%rax, 0xf10(%r14)
    4209:      	shrq	$0x38, %rbp
    420d:      	movq	%r12, %rax
    4210:      	subq	%rcx, %rax
    4213:      	movq	%rax, 0xf18(%r14)
    421a:      	movq	(%rip), %rax            # 0x4221 <kprobe_unwind_v8+0x4221>
    4221:      	cmpl	$0x0, (%rax)
    4224:      	je	0x4330 <kprobe_unwind_v8+0x4330>
    422a:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    4234:      	movq	%rax, 0x28(%rsp)
    4239:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    4243:      	movq	%rax, 0x20(%rsp)
    4248:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    4252:      	movq	%rax, 0x18(%rsp)
    4257:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    4261:      	movq	%rax, 0x10(%rsp)
    4266:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    4270:      	movq	%rax, 0x8(%rsp)
    4275:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    427f:      	movq	%r13, (%rsp)
    4283:      	movw	$0xa, 0x30(%rsp)
    428a:      	movq	%rsp, %rdi
    428d:      	movl	$0x32, %eax
    4292:      	movl	$0x6, %r9d
    4298:      	movq	0xf10(%r14), %rcx
    429f:      	movl	$0x32, %esi
    42a4:      	movq	%r12, %rdx
    42a7:      	movl	%ebp, %r8d
    42aa:      	xorl	%eax, %eax
    42ac:      	callq	*%r9
    42af:      	movq	(%rip), %rax            # 0x42b6 <kprobe_unwind_v8+0x42b6>
    42b6:      	cmpl	$0x0, (%rax)
    42b9:      	je	0x4330 <kprobe_unwind_v8+0x4330>
    42bb:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    42c5:      	movq	%rax, 0x27(%rsp)
    42ca:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    42d4:      	movq	%rax, 0x20(%rsp)
    42d9:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    42e3:      	movq	%rax, 0x18(%rsp)
    42e8:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    42f2:      	movq	%rax, 0x10(%rsp)
    42f7:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    4301:      	movq	%rax, 0x8(%rsp)
    4306:      	movq	%r13, (%rsp)
    430a:      	movq	%rsp, %rdi
    430d:      	movl	$0x2f, %eax
    4312:      	movl	$0x6, %r8d
    4318:      	movq	0xf18(%r14), %rcx
    431f:      	movq	0xf20(%r14), %rdx
    4326:      	movl	$0x2f, %esi
    432b:      	xorl	%eax, %eax
    432d:      	callq	*%r8
    4330:      	cmpl	$0x1, %ebp
    4333:      	jne	0x4ced <kprobe_unwind_v8+0x4ced>
    4339:      	movq	0xf10(%r14), %rax
    4340:      	movq	%rax, 0x70(%rsp)
    4345:      	movq	0xf18(%r14), %r13
    434c:      	movq	(%rip), %rdi            # 0x4353 <kprobe_unwind_v8+0x4353>
    4353:      	leaq	0x70(%rsp), %rsi
    4358:      	movl	$0x1, %eax
    435d:      	callq	*%rax
    435f:      	movl	$0x1, %ebp
    4364:      	testq	%rax, %rax
    4367:      	je	0x4ced <kprobe_unwind_v8+0x4ced>
    436d:      	movq	%rax, %r12
    4370:      	cmpq	%r13, (%rax)
    4373:      	ja	0x437c <kprobe_unwind_v8+0x437c>
    4375:      	cmpq	%r13, 0x8(%r12)
    437a:      	jae	0x4392 <kprobe_unwind_v8+0x4392>
    437c:      	cmpq	%r13, 0x10(%r12)
    4381:      	ja	0x4ced <kprobe_unwind_v8+0x4ced>
    4387:      	cmpq	%r13, 0x18(%r12)
    438c:      	jb	0x4ced <kprobe_unwind_v8+0x4ced>
    4392:      	movq	(%rip), %rax            # 0x4399 <kprobe_unwind_v8+0x4399>
    4399:      	cmpl	$0x0, (%rax)
    439c:      	je	0x43f5 <kprobe_unwind_v8+0x43f5>
    439e:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    43a8:      	movq	%rax, 0x16(%rsp)
    43ad:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    43b7:      	movq	%rax, 0x10(%rsp)
    43bc:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    43c6:      	movq	%rax, 0x8(%rsp)
    43cb:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    43d5:      	movq	%rax, (%rsp)
    43d9:      	movq	%rsp, %rdi
    43dc:      	movl	$0x1e, %eax
    43e1:      	movl	$0x6, %ecx
    43e6:      	movzwl	0x20(%r12), %edx
    43ec:      	movl	$0x1e, %esi
    43f1:      	xorl	%eax, %eax
    43f3:      	callq	*%rcx
    43f5:      	movl	0x1380(%r14), %eax
    43fc:      	movl	0x20(%r12), %ecx
    4401:      	btl	%ecx, %eax
    4404:      	jae	0x4b5b <kprobe_unwind_v8+0x4b5b>
    440a:      	movq	(%rip), %rax            # 0x4411 <kprobe_unwind_v8+0x4411>
    4411:      	cmpl	$0x0, (%rax)
    4414:      	je	0x4ced <kprobe_unwind_v8+0x4ced>
    441a:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    4424:      	movq	%rax, 0x10(%rsp)
    4429:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    4433:      	movq	%rax, 0x8(%rsp)
    4438:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    4442:      	movq	%rax, (%rsp)
    4446:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    444e:      	movq	%rsp, %rdi
    4451:      	movl	$0x1b, %eax
    4456:      	movl	$0x6, %ecx
    445b:      	movl	$0x1b, %esi
    4460:      	xorl	%eax, %eax
    4462:      	callq	*%rcx
    4464:      	jmp	0x4ced <kprobe_unwind_v8+0x4ced>
    4469:      	movq	0x48(%rsp), %rax
    446e:      	movzbl	0xe(%rax), %edx
    4472:      	addq	%r12, %rdx
    4475:      	movq	%rsp, %rdi
    4478:      	movl	$0x8, %eax
    447d:      	movl	$0x70, %ecx
    4482:      	movl	$0x8, %esi
    4487:      	callq	*%rcx
    4489:      	testq	%rax, %rax
    448c:      	je	0x469a <kprobe_unwind_v8+0x469a>
    4492:      	xorl	%eax, %eax
    4494:      	movq	%rax, 0x58(%rsp)
    4499:      	xorl	%eax, %eax
    449b:      	movq	0x50(%rsp), %r15
    44a0:      	orq	$0x2, %r15
    44a4:      	movq	0x48(%rsp), %rcx
    44a9:      	cmpw	0x8(%rcx), %ax
    44ad:      	jne	0x45e3 <kprobe_unwind_v8+0x45e3>
    44b3:      	movl	$0x60, %eax
    44b8:      	movl	$0x70, %ecx
    44bd:      	movq	0xb0(%rsp), %rdi
    44c5:      	movq	0x58(%rsp), %rdx
    44ca:      	movl	$0x60, %esi
    44cf:      	callq	*%rcx
    44d1:      	testq	%rax, %rax
    44d4:      	je	0x4b87 <kprobe_unwind_v8+0x4b87>
    44da:      	movl	$0x3b, 0x70(%rsp)
    44e2:      	movq	(%rip), %rdi            # 0x44e9 <kprobe_unwind_v8+0x44e9>
    44e9:      	leaq	0x70(%rsp), %rsi
    44ee:      	movl	$0x1, %eax
    44f3:      	callq	*%rax
    44f5:      	testq	%rax, %rax
    44f8:      	jne	0x4690 <kprobe_unwind_v8+0x4690>
    44fe:      	movq	(%rip), %rax            # 0x4505 <kprobe_unwind_v8+0x4505>
    4505:      	cmpl	$0x0, (%rax)
    4508:      	je	0x4c61 <kprobe_unwind_v8+0x4c61>
    450e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4518:      	movq	%rax, 0x26(%rsp)
    451d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4527:      	movq	%rax, 0x20(%rsp)
    452c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4536:      	movq	%rax, 0x18(%rsp)
    453b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4545:      	movq	%rax, 0x10(%rsp)
    454a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4554:      	movq	%rax, 0x8(%rsp)
    4559:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4563:      	movq	%rax, (%rsp)
    4567:      	movq	%rsp, %rdi
    456a:      	movl	$0x2e, %eax
    456f:      	movl	$0x6, %ecx
    4574:      	jmp	0x4c54 <kprobe_unwind_v8+0x4c54>
    4579:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    4583:      	movq	%rax, 0x17(%rsp)
    4588:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    4592:      	movq	%rax, 0x10(%rsp)
    4597:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    45a1:      	movq	%rax, 0x8(%rsp)
    45a6:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    45b0:      	movq	%rax, (%rsp)
    45b4:      	movq	%rsp, %rdi
    45b7:      	movl	$0x1f, %eax
    45bc:      	movl	$0x6, %r9d
    45c2:      	movl	$0x1f, %esi
    45c7:      	movq	%r13, %rdx
    45ca:      	movq	%r12, %rcx
    45cd:      	movq	%rbp, %r8
    45d0:      	xorl	%eax, %eax
    45d2:      	callq	*%r9
    45d5:      	cmpq	%r12, %rbp
    45d8:      	jae	0x3e09 <kprobe_unwind_v8+0x3e09>
    45de:      	jmp	0x2025 <kprobe_unwind_v8+0x2025>
    45e3:      	movq	(%rip), %rcx            # 0x45ea <kprobe_unwind_v8+0x45ea>
    45ea:      	cmpl	$0x0, (%rcx)
    45ed:      	je	0x466c <kprobe_unwind_v8+0x466c>
    45ef:      	movzwl	%ax, %r8d
    45f3:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    45fd:      	movq	%rax, 0x26(%rsp)
    4602:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    460c:      	movq	%rax, 0x20(%rsp)
    4611:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    461b:      	movq	%rax, 0x18(%rsp)
    4620:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    462a:      	movq	%rax, 0x10(%rsp)
    462f:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    4639:      	movq	%rax, 0x8(%rsp)
    463e:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    4648:      	movq	%rax, (%rsp)
    464c:      	movq	%rsp, %rdi
    464f:      	movl	$0x2e, %eax
    4654:      	movl	$0x6, %r9d
    465a:      	movl	$0x2e, %esi
    465f:      	movq	%r12, %rdx
    4662:      	movq	0x58(%rsp), %rcx
    4667:      	xorl	%eax, %eax
    4669:      	callq	*%r9
    466c:      	movl	$0x3b, 0x70(%rsp)
    4674:      	movq	(%rip), %rdi            # 0x467b <kprobe_unwind_v8+0x467b>
    467b:      	leaq	0x70(%rsp), %rsi
    4680:      	movl	$0x1, %eax
    4685:      	callq	*%rax
    4687:      	testq	%rax, %rax
    468a:      	je	0x4be2 <kprobe_unwind_v8+0x4be2>
    4690:      	incq	(%rax)
    4693:      	xorl	%ebp, %ebp
    4695:      	jmp	0x5310 <kprobe_unwind_v8+0x5310>
    469a:      	movq	(%rsp), %rcx
    469e:      	movq	%rcx, %rax
    46a1:      	movq	%rcx, 0x58(%rsp)
    46a6:      	andl	$0x3, %eax
    46a9:      	cmpl	$0x1, %eax
    46ac:      	jne	0x4492 <kprobe_unwind_v8+0x4492>
    46b2:      	andq	$-0x4, 0x58(%rsp)
    46b8:      	je	0x4492 <kprobe_unwind_v8+0x4492>
    46be:      	movq	0x48(%rsp), %rax
    46c3:      	movzbl	0xc(%rax), %edx
    46c7:      	addq	0x58(%rsp), %rdx
    46cc:      	movq	%rsp, %rdi
    46cf:      	movl	$0x8, %eax
    46d4:      	movl	$0x70, %ecx
    46d9:      	movl	$0x8, %esi
    46de:      	callq	*%rcx
    46e0:      	testq	%rax, %rax
    46e3:      	jne	0x4499 <kprobe_unwind_v8+0x4499>
    46e9:      	movq	(%rsp), %rax
    46ed:      	movl	%eax, %ecx
    46ef:      	andl	$0x3, %ecx
    46f2:      	cmpl	$0x1, %ecx
    46f5:      	jne	0x4499 <kprobe_unwind_v8+0x4499>
    46fb:      	andq	$-0x4, %rax
    46ff:      	je	0x4499 <kprobe_unwind_v8+0x4499>
    4705:      	movq	0x48(%rsp), %rsi
    470a:      	movzbl	0xd(%rsi), %ecx
    470e:      	addq	%rax, %rcx
    4711:      	movq	%rsp, %rdi
    4714:      	movl	$0x2, %edx
    4719:      	movl	$0x70, %r8d
    471f:      	movzbl	0xd(%rsi), %edx
    4723:      	addq	%rax, %rdx
    4726:      	movl	$0x2, %esi
    472b:      	callq	*%r8
    472e:      	testq	%rax, %rax
    4731:      	jne	0x4499 <kprobe_unwind_v8+0x4499>
    4737:      	movzwl	(%rsp), %eax
    473b:      	jmp	0x449b <kprobe_unwind_v8+0x449b>
    4740:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    474a:      	movq	%rax, 0x20(%rsp)
    474f:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    4759:      	movq	%rax, 0x18(%rsp)
    475e:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    4768:      	movq	%rax, 0x10(%rsp)
    476d:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    4777:      	movq	%rax, 0x8(%rsp)
    477c:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    4786:      	movq	%rax, (%rsp)
    478a:      	movb	$0x0, 0x28(%rsp)
    478f:      	movq	%rsp, %rdi
    4792:      	movl	$0x29, %eax
    4797:      	movl	$0x6, %r9d
    479d:      	movl	$0x29, %esi
    47a2:      	movq	%r12, %rdx
    47a5:      	movq	0x50(%rsp), %rcx
    47aa:      	movq	0x58(%rsp), %r8
    47af:      	xorl	%eax, %eax
    47b1:      	callq	*%r9
    47b4:      	movq	(%rip), %rax            # 0x47bb <kprobe_unwind_v8+0x47bb>
    47bb:      	cmpl	$0x0, (%rax)
    47be:      	je	0x3881 <kprobe_unwind_v8+0x3881>
    47c4:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    47ce:      	movq	%rax, 0x1d(%rsp)
    47d3:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    47dd:      	movq	%rax, 0x18(%rsp)
    47e2:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    47ec:      	movq	%rax, 0x10(%rsp)
    47f1:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    47fb:      	movq	%rax, 0x8(%rsp)
    4800:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    480a:      	movq	%rax, (%rsp)
    480e:      	movq	%rsp, %rdi
    4811:      	movl	$0x25, %eax
    4816:      	movl	$0x6, %r9d
    481c:      	movl	$0x25, %esi
    4821:      	movq	0x68(%rsp), %rdx
    4826:      	movq	0x90(%rsp), %rcx
    482e:      	movq	0xa0(%rsp), %r8
    4836:      	xorl	%eax, %eax
    4838:      	callq	*%r9
    483b:      	jmp	0x3881 <kprobe_unwind_v8+0x3881>
    4840:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    484a:      	movq	%rax, 0x28(%rsp)
    484f:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    4859:      	movq	%rax, 0x20(%rsp)
    485e:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    4868:      	movq	%rax, 0x18(%rsp)
    486d:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    4877:      	movq	%rax, 0x10(%rsp)
    487c:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    4886:      	movq	%rax, 0x8(%rsp)
    488b:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    4895:      	movq	%rax, (%rsp)
    4899:      	movq	%rsp, %rdi
    489c:      	movl	$0x30, %eax
    48a1:      	movl	$0x6, %ecx
    48a6:      	xorl	%ebp, %ebp
    48a8:      	movl	$0x30, %esi
    48ad:      	xorl	%eax, %eax
    48af:      	callq	*%rcx
    48b1:      	jmp	0x368b <kprobe_unwind_v8+0x368b>
    48b6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    48c0:      	movq	%rax, 0x26(%rsp)
    48c5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    48cf:      	movq	%rax, 0x20(%rsp)
    48d4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    48de:      	movq	%rax, 0x18(%rsp)
    48e3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    48ed:      	movq	%rax, 0x10(%rsp)
    48f2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    48fc:      	movq	%rax, 0x8(%rsp)
    4901:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    490b:      	movq	%rax, (%rsp)
    490f:      	movq	%rsp, %rdi
    4912:      	movl	$0x2e, %eax
    4917:      	movl	$0x6, %ecx
    491c:      	movl	0x64(%rsp), %edx
    4920:      	movl	$0x2e, %esi
    4925:      	xorl	%eax, %eax
    4927:      	callq	*%rcx
    4929:      	jmp	0x3dc9 <kprobe_unwind_v8+0x3dc9>
    492e:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    4938:      	movq	%rax, 0x15(%rsp)
    493d:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    4947:      	movq	%rax, 0x10(%rsp)
    494c:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    4956:      	movq	%rax, 0x8(%rsp)
    495b:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    4965:      	movq	%rax, (%rsp)
    4969:      	movq	%rsp, %rdi
    496c:      	movl	$0x1d, %eax
    4971:      	movl	$0x6, %ecx
    4976:      	xorl	%r15d, %r15d
    4979:      	movl	$0x1d, %esi
    497e:      	movq	%rbp, %rdx
    4981:      	xorl	%eax, %eax
    4983:      	callq	*%rcx
    4985:      	jmp	0x5310 <kprobe_unwind_v8+0x5310>
    498a:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    4994:      	movq	%rax, 0x17(%rsp)
    4999:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    49a3:      	movq	%rax, 0x10(%rsp)
    49a8:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    49b2:      	movq	%rax, 0x8(%rsp)
    49b7:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    49c1:      	movq	%rax, (%rsp)
    49c5:      	movq	%rsp, %rdi
    49c8:      	movl	$0x1f, %eax
    49cd:      	movl	$0x6, %r9d
    49d3:      	movq	0xed0(%r14), %rdx
    49da:      	movq	0xed8(%r14), %rcx
    49e1:      	movq	0xee0(%r14), %r8
    49e8:      	movl	$0x1f, %esi
    49ed:      	xorl	%eax, %eax
    49ef:      	callq	*%r9
    49f2:      	jmp	0x3f7e <kprobe_unwind_v8+0x3f7e>
    49f7:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    4a01:      	movq	%rax, 0x10(%rsp)
    4a06:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    4a10:      	movq	%rax, 0x8(%rsp)
    4a15:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    4a1f:      	movq	%rax, (%rsp)
    4a23:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    4a2b:      	movq	%rsp, %rdi
    4a2e:      	movl	$0x1c, %eax
    4a33:      	movl	$0x6, %ecx
    4a38:      	movl	$0x1c, %esi
    4a3d:      	movq	%rbp, %rdx
    4a40:      	xorl	%eax, %eax
    4a42:      	callq	*%rcx
    4a44:      	jmp	0x4158 <kprobe_unwind_v8+0x4158>
    4a49:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4a53:      	movq	%rax, 0x26(%rsp)
    4a58:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4a62:      	movq	%rax, 0x20(%rsp)
    4a67:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4a71:      	movq	%rax, 0x18(%rsp)
    4a76:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4a80:      	movq	%rax, 0x10(%rsp)
    4a85:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4a8f:      	movq	%rax, 0x8(%rsp)
    4a94:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a9e:      	movq	%rax, (%rsp)
    4aa2:      	movq	%rsp, %rdi
    4aa5:      	movl	$0x2e, %eax
    4aaa:      	movl	$0x6, %ecx
    4aaf:      	movl	0x70(%rsp), %edx
    4ab3:      	movl	$0x2e, %esi
    4ab8:      	xorl	%eax, %eax
    4aba:      	callq	*%rcx
    4abc:      	jmp	0x3fa5 <kprobe_unwind_v8+0x3fa5>
    4ac1:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    4acb:      	movq	%rax, 0x28(%rsp)
    4ad0:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    4ada:      	movq	%rax, 0x20(%rsp)
    4adf:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    4ae9:      	movq	%rax, 0x18(%rsp)
    4aee:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    4af8:      	movq	%rax, 0x10(%rsp)
    4afd:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    4b07:      	movq	%rax, 0x8(%rsp)
    4b0c:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    4b16:      	movq	%rax, (%rsp)
    4b1a:      	movb	$0x0, 0x30(%rsp)
    4b1f:      	movq	%rsp, %rdi
    4b22:      	movl	$0x31, %eax
    4b27:      	movl	$0x6, %ecx
    4b2c:      	movl	0x2c0(%r14), %edx
    4b33:      	movl	$0x31, %esi
    4b38:      	xorl	%eax, %eax
    4b3a:      	callq	*%rcx
    4b3c:      	movq	0xed0(%r14), %r12
    4b43:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    4b4d:      	cmpq	%rax, %r12
    4b50:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    4b56:      	jmp	0x41a3 <kprobe_unwind_v8+0x41a3>
    4b5b:      	movl	$0x0, 0x64(%rsp)
    4b63:      	movq	(%rip), %rdi            # 0x4b6a <kprobe_unwind_v8+0x4b6a>
    4b6a:      	leaq	0x64(%rsp), %rsi
    4b6f:      	movl	$0x1, %eax
    4b74:      	callq	*%rax
    4b76:      	testq	%rax, %rax
    4b79:      	je	0x4c68 <kprobe_unwind_v8+0x4c68>
    4b7f:      	incq	(%rax)
    4b82:      	jmp	0x4ce7 <kprobe_unwind_v8+0x4ce7>
    4b87:      	movq	0x48(%rsp), %rax
    4b8c:      	movzbl	0x12(%rax), %ecx
    4b90:      	xorl	%ebp, %ebp
    4b92:      	cmpq	$0x5c, %rcx
    4b96:      	ja	0x220 <kprobe_unwind_v8+0x220>
    4b9c:      	movq	0x48(%rsp), %rax
    4ba1:      	movzbl	0x13(%rax), %eax
    4ba5:      	cmpq	$0x5c, %rax
    4ba9:      	ja	0x220 <kprobe_unwind_v8+0x220>
    4baf:      	movq	0x48(%rsp), %rdx
    4bb4:      	cmpb	$0x0, 0x10(%rdx)
    4bb8:      	movzbl	0x11(%rdx), %edx
    4bbc:      	movq	%rdx, 0x68(%rsp)
    4bc1:      	je	0x4e48 <kprobe_unwind_v8+0x4e48>
    4bc7:      	movq	0xb0(%rsp), %rdx
    4bcf:      	movq	0x68(%rsp), %rsi
    4bd4:      	movq	(%rdx,%rsi), %rsi
    4bd8:      	movq	%rsi, 0x68(%rsp)
    4bdd:      	jmp	0x4e57 <kprobe_unwind_v8+0x4e57>
    4be2:      	movq	(%rip), %rax            # 0x4be9 <kprobe_unwind_v8+0x4be9>
    4be9:      	cmpl	$0x0, (%rax)
    4bec:      	je	0x4c61 <kprobe_unwind_v8+0x4c61>
    4bee:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4bf8:      	movq	%rax, 0x26(%rsp)
    4bfd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4c07:      	movq	%rax, 0x20(%rsp)
    4c0c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4c16:      	movq	%rax, 0x18(%rsp)
    4c1b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4c25:      	movq	%rax, 0x10(%rsp)
    4c2a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4c34:      	movq	%rax, 0x8(%rsp)
    4c39:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4c43:      	movq	%rax, (%rsp)
    4c47:      	movq	%rsp, %rdi
    4c4a:      	movl	$0x2e, %eax
    4c4f:      	movl	$0x6, %ecx
    4c54:      	movl	0x70(%rsp), %edx
    4c58:      	movl	$0x2e, %esi
    4c5d:      	xorl	%eax, %eax
    4c5f:      	callq	*%rcx
    4c61:      	xorl	%ebp, %ebp
    4c63:      	jmp	0x5310 <kprobe_unwind_v8+0x5310>
    4c68:      	movq	(%rip), %rax            # 0x4c6f <kprobe_unwind_v8+0x4c6f>
    4c6f:      	cmpl	$0x0, (%rax)
    4c72:      	je	0x4ce7 <kprobe_unwind_v8+0x4ce7>
    4c74:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4c7e:      	movq	%rax, 0x26(%rsp)
    4c83:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4c8d:      	movq	%rax, 0x20(%rsp)
    4c92:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4c9c:      	movq	%rax, 0x18(%rsp)
    4ca1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4cab:      	movq	%rax, 0x10(%rsp)
    4cb0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4cba:      	movq	%rax, 0x8(%rsp)
    4cbf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4cc9:      	movq	%rax, (%rsp)
    4ccd:      	movq	%rsp, %rdi
    4cd0:      	movl	$0x2e, %eax
    4cd5:      	movl	$0x6, %ecx
    4cda:      	movl	0x64(%rsp), %edx
    4cde:      	movl	$0x2e, %esi
    4ce3:      	xorl	%eax, %eax
    4ce5:      	callq	*%rcx
    4ce7:      	movzwl	0x20(%r12), %ebp
    4ced:      	xorl	%r12d, %r12d
    4cf0:      	cmpl	$0x7, %ebp
    4cf3:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    4cf9:      	movq	0xed0(%r14), %rax
    4d00:      	movq	%rax, 0xa0(%rsp)
    4d08:      	movq	0xed8(%r14), %r12
    4d0f:      	movq	0xee0(%r14), %r13
    4d16:      	movq	(%rip), %rax            # 0x4d1d <kprobe_unwind_v8+0x4d1d>
    4d1d:      	cmpl	$0x0, (%rax)
    4d20:      	je	0x4d83 <kprobe_unwind_v8+0x4d83>
    4d22:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    4d2c:      	movq	%rax, 0x17(%rsp)
    4d31:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    4d3b:      	movq	%rax, 0x10(%rsp)
    4d40:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    4d4a:      	movq	%rax, 0x8(%rsp)
    4d4f:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    4d59:      	movq	%rax, (%rsp)
    4d5d:      	movq	%rsp, %rdi
    4d60:      	movl	$0x1f, %eax
    4d65:      	movl	$0x6, %r9d
    4d6b:      	movl	$0x1f, %esi
    4d70:      	movq	0xa0(%rsp), %rdx
    4d78:      	movq	%r12, %rcx
    4d7b:      	movq	%r13, %r8
    4d7e:      	xorl	%eax, %eax
    4d80:      	callq	*%r9
    4d83:      	cmpq	%r12, %r13
    4d86:      	jb	0x80b0 <kprobe_unwind_v8+0x80b0>
    4d8c:      	leaq	0x2000(%r12), %rax
    4d94:      	cmpq	%rax, %r13
    4d97:      	jae	0x80b0 <kprobe_unwind_v8+0x80b0>
    4d9d:      	addq	$-0x40, %r13
    4da1:      	movl	$0x40, %eax
    4da6:      	movl	$0x70, %ecx
    4dab:      	movq	0x98(%rsp), %rdi
    4db3:      	movl	$0x40, %esi
    4db8:      	movq	%r13, %rdx
    4dbb:      	callq	*%rcx
    4dbd:      	testq	%rax, %rax
    4dc0:      	movq	(%rip), %rbp            # 0x4dc7 <kprobe_unwind_v8+0x4dc7>
    4dc7:      	jne	0x138 <kprobe_unwind_v8+0x138>
    4dcd:      	movq	0x48(%rsp), %rax
    4dd2:      	movzbl	0x14(%rax), %ecx
    4dd6:      	xorl	%ebp, %ebp
    4dd8:      	cmpq	$0x38, %rcx
    4ddc:      	ja	0x220 <kprobe_unwind_v8+0x220>
    4de2:      	movq	0x48(%rsp), %rax
    4de7:      	movzbl	0x15(%rax), %eax
    4deb:      	cmpq	$0x38, %rax
    4def:      	ja	0x220 <kprobe_unwind_v8+0x220>
    4df5:      	movq	0x48(%rsp), %rdx
    4dfa:      	movzbl	0x16(%rdx), %edx
    4dfe:      	cmpq	$0x38, %rdx
    4e02:      	ja	0x220 <kprobe_unwind_v8+0x220>
    4e08:      	movq	0x98(%rsp), %rsi
    4e10:      	movq	(%rsi,%rcx), %rbp
    4e14:      	testb	$0x1, %bpl
    4e18:      	jne	0x4ffe <kprobe_unwind_v8+0x4ffe>
    4e1e:      	shrq	%rbp
    4e21:      	movq	(%rip), %rax            # 0x4e28 <kprobe_unwind_v8+0x4e28>
    4e28:      	cmpl	$0x0, (%rax)
    4e2b:      	jne	0x5187 <kprobe_unwind_v8+0x5187>
    4e31:      	xorl	%eax, %eax
    4e33:      	movq	%rax, 0x90(%rsp)
    4e3b:      	movzbl	0xf30(%r14), %r12d
    4e43:      	jmp	0x59c0 <kprobe_unwind_v8+0x59c0>
    4e48:      	movq	0x68(%rsp), %rdx
    4e4d:      	addq	0x58(%rsp), %rdx
    4e52:      	movq	%rdx, 0x68(%rsp)
    4e57:      	movq	0xb0(%rsp), %rdx
    4e5f:      	movl	(%rdx,%rcx), %esi
    4e62:      	movq	0x48(%rsp), %rcx
    4e67:      	movzbl	0x17(%rcx), %edi
    4e6b:      	movl	%edi, 0xb8(%rsp)
    4e72:      	movzbl	0x18(%rcx), %ecx
    4e76:      	movq	%rsi, 0x90(%rsp)
    4e7e:      	addq	0x68(%rsp), %rsi
    4e83:      	movq	%rsi, 0xa0(%rsp)
    4e8b:      	andl	(%rdx,%rax), %ecx
    4e8e:      	movl	%ecx, 0xac(%rsp)
    4e95:      	movq	(%rip), %rax            # 0x4e9c <kprobe_unwind_v8+0x4e9c>
    4e9c:      	cmpl	$0x0, (%rax)
    4e9f:      	je	0x4f9c <kprobe_unwind_v8+0x4f9c>
    4ea5:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    4eaf:      	movq	%rax, 0x20(%rsp)
    4eb4:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    4ebe:      	movq	%rax, 0x18(%rsp)
    4ec3:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    4ecd:      	movq	%rax, 0x10(%rsp)
    4ed2:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    4edc:      	movq	%rax, 0x8(%rsp)
    4ee1:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    4eeb:      	movq	%rax, (%rsp)
    4eef:      	movb	$0x0, 0x28(%rsp)
    4ef4:      	movq	%rsp, %rdi
    4ef7:      	movl	$0x29, %eax
    4efc:      	movl	$0x6, %r9d
    4f02:      	movl	$0x29, %esi
    4f07:      	movq	%r12, %rdx
    4f0a:      	movq	0x50(%rsp), %rcx
    4f0f:      	movq	0x58(%rsp), %r8
    4f14:      	xorl	%eax, %eax
    4f16:      	callq	*%r9
    4f19:      	movq	(%rip), %rax            # 0x4f20 <kprobe_unwind_v8+0x4f20>
    4f20:      	cmpl	$0x0, (%rax)
    4f23:      	je	0x4f9c <kprobe_unwind_v8+0x4f9c>
    4f25:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    4f2f:      	movq	%rax, 0x1d(%rsp)
    4f34:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    4f3e:      	movq	%rax, 0x18(%rsp)
    4f43:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    4f4d:      	movq	%rax, 0x10(%rsp)
    4f52:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    4f5c:      	movq	%rax, 0x8(%rsp)
    4f61:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    4f6b:      	movq	%rax, (%rsp)
    4f6f:      	movq	%rsp, %rdi
    4f72:      	movl	$0x25, %eax
    4f77:      	movl	$0x6, %r9d
    4f7d:      	movl	$0x25, %esi
    4f82:      	movq	0x68(%rsp), %rdx
    4f87:      	movq	0xa0(%rsp), %rcx
    4f8f:      	movq	0x90(%rsp), %r8
    4f97:      	xorl	%eax, %eax
    4f99:      	callq	*%r9
    4f9c:      	movq	%r13, %rbp
    4f9f:      	subq	0x68(%rsp), %rbp
    4fa4:      	jb	0x51ea <kprobe_unwind_v8+0x51ea>
    4faa:      	cmpq	0xa0(%rsp), %r13
    4fb2:      	jae	0x51ea <kprobe_unwind_v8+0x51ea>
    4fb8:      	movl	0xb8(%rsp), %eax
    4fbf:      	shrxl	%eax, 0xac(%rsp), %eax
    4fc9:      	movq	0x48(%rsp), %rcx
    4fce:      	movzbl	0x19(%rcx), %ecx
    4fd2:      	orq	$0x4, %r12
    4fd6:      	movq	0x58(%rsp), %r15
    4fdb:      	orq	$0x3, %r15
    4fdf:      	cmpl	%ecx, %eax
    4fe1:      	cmoveq	%r12, %r15
    4fe5:      	movq	0x90(%rsp), %rcx
    4fed:      	shll	$0x4, %ecx
    4ff0:      	orl	%eax, %ecx
    4ff2:      	shlq	$0x20, %rcx
    4ff6:      	orq	%rcx, %rbp
    4ff9:      	jmp	0x5310 <kprobe_unwind_v8+0x5310>
    4ffe:      	movq	0x98(%rsp), %rcx
    5006:      	movq	(%rcx,%rdx), %r12
    500a:      	movq	(%rcx,%rax), %rdx
    500e:      	movl	%edx, %ecx
    5010:      	andl	$0x3, %ecx
    5013:      	andq	$-0x4, %rdx
    5017:      	xorl	%eax, %eax
    5019:      	cmpl	$0x1, %ecx
    501c:      	cmovneq	%rax, %rdx
    5020:      	movq	%rdx, 0x68(%rsp)
    5025:      	testq	%rdx, %rdx
    5028:      	je	0x509b <kprobe_unwind_v8+0x509b>
    502a:      	movq	0x48(%rsp), %rax
    502f:      	movzbl	0xc(%rax), %edx
    5033:      	addq	0x68(%rsp), %rdx
    5038:      	movq	%rsp, %rdi
    503b:      	movl	$0x8, %eax
    5040:      	movl	$0x70, %ecx
    5045:      	movl	$0x8, %esi
    504a:      	callq	*%rcx
    504c:      	testq	%rax, %rax
    504f:      	jne	0x5099 <kprobe_unwind_v8+0x5099>
    5051:      	movq	(%rsp), %rax
    5055:      	movl	%eax, %ecx
    5057:      	andl	$0x3, %ecx
    505a:      	cmpl	$0x1, %ecx
    505d:      	jne	0x5099 <kprobe_unwind_v8+0x5099>
    505f:      	andq	$-0x4, %rax
    5063:      	je	0x5099 <kprobe_unwind_v8+0x5099>
    5065:      	movq	0x48(%rsp), %rsi
    506a:      	movzbl	0xd(%rsi), %ecx
    506e:      	addq	%rax, %rcx
    5071:      	movq	%rsp, %rdi
    5074:      	movl	$0x2, %edx
    5079:      	movl	$0x70, %r8d
    507f:      	movzbl	0xd(%rsi), %edx
    5083:      	addq	%rax, %rdx
    5086:      	movl	$0x2, %esi
    508b:      	callq	*%r8
    508e:      	testq	%rax, %rax
    5091:      	jne	0x5099 <kprobe_unwind_v8+0x5099>
    5093:      	movzwl	(%rsp), %eax
    5097:      	jmp	0x509b <kprobe_unwind_v8+0x509b>
    5099:      	xorl	%eax, %eax
    509b:      	movq	0x48(%rsp), %rcx
    50a0:      	cmpw	0x4(%rcx), %ax
    50a4:      	jb	0x1c5f <kprobe_unwind_v8+0x1c5f>
    50aa:      	movq	0x48(%rsp), %r8
    50af:      	cmpw	0x6(%r8), %ax
    50b4:      	ja	0x494 <kprobe_unwind_v8+0x494>
    50ba:      	movzbl	0xf(%r8), %edx
    50bf:      	addq	0x68(%rsp), %rdx
    50c4:      	movq	%rsp, %rdi
    50c7:      	movl	$0x8, %eax
    50cc:      	movl	$0x70, %ecx
    50d1:      	movl	$0x8, %esi
    50d6:      	callq	*%rcx
    50d8:      	testq	%rax, %rax
    50db:      	jne	0x5201 <kprobe_unwind_v8+0x5201>
    50e1:      	movq	(%rsp), %rcx
    50e5:      	movq	%rcx, %rax
    50e8:      	movq	%rcx, 0x58(%rsp)
    50ed:      	andl	$0x3, %eax
    50f0:      	cmpl	$0x1, %eax
    50f3:      	jne	0x5201 <kprobe_unwind_v8+0x5201>
    50f9:      	andq	$-0x4, 0x58(%rsp)
    50ff:      	je	0x5201 <kprobe_unwind_v8+0x5201>
    5105:      	movq	0x48(%rsp), %rax
    510a:      	movzbl	0xc(%rax), %edx
    510e:      	addq	0x58(%rsp), %rdx
    5113:      	movq	%rsp, %rdi
    5116:      	movl	$0x8, %eax
    511b:      	movl	$0x70, %ecx
    5120:      	movl	$0x8, %esi
    5125:      	callq	*%rcx
    5127:      	testq	%rax, %rax
    512a:      	jne	0x5208 <kprobe_unwind_v8+0x5208>
    5130:      	movq	(%rsp), %rax
    5134:      	movl	%eax, %ecx
    5136:      	andl	$0x3, %ecx
    5139:      	cmpl	$0x1, %ecx
    513c:      	jne	0x5208 <kprobe_unwind_v8+0x5208>
    5142:      	andq	$-0x4, %rax
    5146:      	je	0x5208 <kprobe_unwind_v8+0x5208>
    514c:      	movq	0x48(%rsp), %rsi
    5151:      	movzbl	0xd(%rsi), %ecx
    5155:      	addq	%rax, %rcx
    5158:      	movq	%rsp, %rdi
    515b:      	movl	$0x2, %edx
    5160:      	movl	$0x70, %r8d
    5166:      	movzbl	0xd(%rsi), %edx
    516a:      	addq	%rax, %rdx
    516d:      	movl	$0x2, %esi
    5172:      	callq	*%r8
    5175:      	testq	%rax, %rax
    5178:      	jne	0x5208 <kprobe_unwind_v8+0x5208>
    517e:      	movzwl	(%rsp), %eax
    5182:      	jmp	0x520a <kprobe_unwind_v8+0x520a>
    5187:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    5191:      	movq	%rax, 0x15(%rsp)
    5196:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    51a0:      	movq	%rax, 0x10(%rsp)
    51a5:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    51af:      	movq	%rax, 0x8(%rsp)
    51b4:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    51be:      	movq	%rax, (%rsp)
    51c2:      	movq	%rsp, %rdi
    51c5:      	movl	$0x1d, %eax
    51ca:      	movl	$0x6, %ecx
    51cf:      	xorl	%eax, %eax
    51d1:      	movq	%rax, 0x90(%rsp)
    51d9:      	movl	$0x1d, %esi
    51de:      	movq	%rbp, %rdx
    51e1:      	xorl	%eax, %eax
    51e3:      	callq	*%rcx
    51e5:      	jmp	0x5915 <kprobe_unwind_v8+0x5915>
    51ea:      	movq	(%rip), %rax            # 0x51f1 <kprobe_unwind_v8+0x51f1>
    51f1:      	cmpl	$0x0, (%rax)
    51f4:      	jne	0x529f <kprobe_unwind_v8+0x529f>
    51fa:      	xorl	%ebp, %ebp
    51fc:      	jmp	0x3eb1 <kprobe_unwind_v8+0x3eb1>
    5201:      	xorl	%eax, %eax
    5203:      	movq	%rax, 0x58(%rsp)
    5208:      	xorl	%eax, %eax
    520a:      	movq	0x48(%rsp), %rcx
    520f:      	cmpw	0xa(%rcx), %ax
    5213:      	jne	0x998 <kprobe_unwind_v8+0x998>
    5219:      	movq	%r12, %rbp
    521c:      	shrq	$0x20, %rbp
    5220:      	je	0x53bb <kprobe_unwind_v8+0x53bb>
    5226:      	andl	$0x1, %r12d
    522a:      	jne	0x53bb <kprobe_unwind_v8+0x53bb>
    5230:      	movq	(%rip), %rax            # 0x5237 <kprobe_unwind_v8+0x5237>
    5237:      	cmpl	$0x0, (%rax)
    523a:      	je	0x5289 <kprobe_unwind_v8+0x5289>
    523c:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    5246:      	movq	%rax, 0x10(%rsp)
    524b:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    5255:      	movq	%rax, 0x8(%rsp)
    525a:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    5264:      	movq	%rax, (%rsp)
    5268:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    5270:      	movq	%rsp, %rdi
    5273:      	movl	$0x1c, %eax
    5278:      	movl	$0x6, %ecx
    527d:      	movl	$0x1c, %esi
    5282:      	movq	%rbp, %rdx
    5285:      	xorl	%eax, %eax
    5287:      	callq	*%rcx
    5289:      	movq	0x58(%rsp), %r15
    528e:      	orq	$0x1, %r15
    5292:      	movq	%r15, 0x90(%rsp)
    529a:      	jmp	0x5915 <kprobe_unwind_v8+0x5915>
    529f:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    52a9:      	movq	%rax, 0x28(%rsp)
    52ae:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    52b8:      	movq	%rax, 0x20(%rsp)
    52bd:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    52c7:      	movq	%rax, 0x18(%rsp)
    52cc:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    52d6:      	movq	%rax, 0x10(%rsp)
    52db:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    52e5:      	movq	%rax, 0x8(%rsp)
    52ea:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    52f4:      	movq	%rax, (%rsp)
    52f8:      	movq	%rsp, %rdi
    52fb:      	movl	$0x30, %eax
    5300:      	movl	$0x6, %ecx
    5305:      	xorl	%ebp, %ebp
    5307:      	movl	$0x30, %esi
    530c:      	xorl	%eax, %eax
    530e:      	callq	*%rcx
    5310:      	movzbl	0xf30(%r14), %r12d
    5318:      	movq	(%rip), %rax            # 0x531f <kprobe_unwind_v8+0x531f>
    531f:      	cmpl	$0x0, (%rax)
    5322:      	je	0x3eb9 <kprobe_unwind_v8+0x3eb9>
    5328:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    5332:      	movq	%rax, 0x30(%rsp)
    5337:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    5341:      	movq	%rax, 0x28(%rsp)
    5346:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    5350:      	movq	%rax, 0x20(%rsp)
    5355:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    535f:      	movq	%rax, 0x18(%rsp)
    5364:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    536e:      	movq	%rax, 0x10(%rsp)
    5373:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    537d:      	movq	%rax, 0x8(%rsp)
    5382:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    538c:      	movq	%rax, (%rsp)
    5390:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    5398:      	movq	%rsp, %rdi
    539b:      	movl	$0x3c, %eax
    53a0:      	movl	$0x6, %r8d
    53a6:      	movl	$0x3c, %esi
    53ab:      	movq	%rbp, %rdx
    53ae:      	movq	%r15, %rcx
    53b1:      	xorl	%eax, %eax
    53b3:      	callq	*%r8
    53b6:      	jmp	0x3eb9 <kprobe_unwind_v8+0x3eb9>
    53bb:      	movq	0x48(%rsp), %rax
    53c0:      	movzbl	0xe(%rax), %edx
    53c4:      	addq	0x68(%rsp), %rdx
    53c9:      	movq	%rsp, %rdi
    53cc:      	movl	$0x8, %eax
    53d1:      	movl	$0x70, %ecx
    53d6:      	movl	$0x8, %esi
    53db:      	callq	*%rcx
    53dd:      	testq	%rax, %rax
    53e0:      	jne	0x5471 <kprobe_unwind_v8+0x5471>
    53e6:      	movq	(%rsp), %rcx
    53ea:      	movq	%rcx, %rax
    53ed:      	movq	%rcx, 0x50(%rsp)
    53f2:      	andl	$0x3, %eax
    53f5:      	cmpl	$0x1, %eax
    53f8:      	jne	0x5471 <kprobe_unwind_v8+0x5471>
    53fa:      	andq	$-0x4, 0x50(%rsp)
    5400:      	je	0x5471 <kprobe_unwind_v8+0x5471>
    5402:      	movq	0x48(%rsp), %rax
    5407:      	movzbl	0xc(%rax), %edx
    540b:      	addq	0x50(%rsp), %rdx
    5410:      	movq	%rsp, %rdi
    5413:      	movl	$0x8, %eax
    5418:      	movl	$0x70, %ecx
    541d:      	movl	$0x8, %esi
    5422:      	callq	*%rcx
    5424:      	testq	%rax, %rax
    5427:      	jne	0x5478 <kprobe_unwind_v8+0x5478>
    5429:      	movq	(%rsp), %rax
    542d:      	movl	%eax, %ecx
    542f:      	andl	$0x3, %ecx
    5432:      	cmpl	$0x1, %ecx
    5435:      	jne	0x5478 <kprobe_unwind_v8+0x5478>
    5437:      	andq	$-0x4, %rax
    543b:      	je	0x5478 <kprobe_unwind_v8+0x5478>
    543d:      	movq	0x48(%rsp), %rsi
    5442:      	movzbl	0xd(%rsi), %ecx
    5446:      	addq	%rax, %rcx
    5449:      	movq	%rsp, %rdi
    544c:      	movl	$0x2, %edx
    5451:      	movl	$0x70, %r8d
    5457:      	movzbl	0xd(%rsi), %edx
    545b:      	addq	%rax, %rdx
    545e:      	movl	$0x2, %esi
    5463:      	callq	*%r8
    5466:      	testq	%rax, %rax
    5469:      	jne	0x5478 <kprobe_unwind_v8+0x5478>
    546b:      	movzwl	(%rsp), %eax
    546f:      	jmp	0x547a <kprobe_unwind_v8+0x547a>
    5471:      	xorl	%eax, %eax
    5473:      	movq	%rax, 0x50(%rsp)
    5478:      	xorl	%eax, %eax
    547a:      	movq	0x58(%rsp), %rcx
    547f:      	orq	$0x2, %rcx
    5483:      	movq	%rcx, 0x90(%rsp)
    548b:      	movq	0x48(%rsp), %rcx
    5490:      	cmpw	0x8(%rcx), %ax
    5494:      	jne	0x5560 <kprobe_unwind_v8+0x5560>
    549a:      	movl	$0x60, %eax
    549f:      	movl	$0x70, %ecx
    54a4:      	movq	0xb0(%rsp), %rdi
    54ac:      	movq	0x50(%rsp), %rdx
    54b1:      	movl	$0x60, %esi
    54b6:      	callq	*%rcx
    54b8:      	testq	%rax, %rax
    54bb:      	je	0x5615 <kprobe_unwind_v8+0x5615>
    54c1:      	movl	$0x3b, 0x70(%rsp)
    54c9:      	movq	(%rip), %rdi            # 0x54d0 <kprobe_unwind_v8+0x54d0>
    54d0:      	leaq	0x70(%rsp), %rsi
    54d5:      	movl	$0x1, %eax
    54da:      	callq	*%rax
    54dc:      	testq	%rax, %rax
    54df:      	jne	0x560b <kprobe_unwind_v8+0x560b>
    54e5:      	movq	(%rip), %rax            # 0x54ec <kprobe_unwind_v8+0x54ec>
    54ec:      	cmpl	$0x0, (%rax)
    54ef:      	je	0x56e1 <kprobe_unwind_v8+0x56e1>
    54f5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    54ff:      	movq	%rax, 0x26(%rsp)
    5504:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    550e:      	movq	%rax, 0x20(%rsp)
    5513:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    551d:      	movq	%rax, 0x18(%rsp)
    5522:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    552c:      	movq	%rax, 0x10(%rsp)
    5531:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    553b:      	movq	%rax, 0x8(%rsp)
    5540:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    554a:      	movq	%rax, (%rsp)
    554e:      	movq	%rsp, %rdi
    5551:      	movl	$0x2e, %eax
    5556:      	movl	$0x6, %ecx
    555b:      	jmp	0x56d4 <kprobe_unwind_v8+0x56d4>
    5560:      	movq	(%rip), %rcx            # 0x5567 <kprobe_unwind_v8+0x5567>
    5567:      	cmpl	$0x0, (%rcx)
    556a:      	je	0x55eb <kprobe_unwind_v8+0x55eb>
    556c:      	movzwl	%ax, %r8d
    5570:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    557a:      	movq	%rax, 0x26(%rsp)
    557f:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    5589:      	movq	%rax, 0x20(%rsp)
    558e:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    5598:      	movq	%rax, 0x18(%rsp)
    559d:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    55a7:      	movq	%rax, 0x10(%rsp)
    55ac:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    55b6:      	movq	%rax, 0x8(%rsp)
    55bb:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    55c5:      	movq	%rax, (%rsp)
    55c9:      	movq	%rsp, %rdi
    55cc:      	movl	$0x2e, %eax
    55d1:      	movl	$0x6, %r9d
    55d7:      	movl	$0x2e, %esi
    55dc:      	movq	0x68(%rsp), %rdx
    55e1:      	movq	0x50(%rsp), %rcx
    55e6:      	xorl	%eax, %eax
    55e8:      	callq	*%r9
    55eb:      	movl	$0x3b, 0x70(%rsp)
    55f3:      	movq	(%rip), %rdi            # 0x55fa <kprobe_unwind_v8+0x55fa>
    55fa:      	leaq	0x70(%rsp), %rsi
    55ff:      	movl	$0x1, %eax
    5604:      	callq	*%rax
    5606:      	testq	%rax, %rax
    5609:      	je	0x5662 <kprobe_unwind_v8+0x5662>
    560b:      	incq	(%rax)
    560e:      	xorl	%ebp, %ebp
    5610:      	jmp	0x5915 <kprobe_unwind_v8+0x5915>
    5615:      	movq	0x48(%rsp), %rax
    561a:      	movzbl	0x12(%rax), %ecx
    561e:      	xorl	%ebp, %ebp
    5620:      	cmpq	$0x5c, %rcx
    5624:      	ja	0x220 <kprobe_unwind_v8+0x220>
    562a:      	movq	0x48(%rsp), %rax
    562f:      	movzbl	0x13(%rax), %eax
    5633:      	cmpq	$0x5c, %rax
    5637:      	ja	0x220 <kprobe_unwind_v8+0x220>
    563d:      	movq	0x48(%rsp), %rdx
    5642:      	cmpb	$0x0, 0x10(%rdx)
    5646:      	movzbl	0x11(%rdx), %r12d
    564b:      	je	0x56e8 <kprobe_unwind_v8+0x56e8>
    5651:      	movq	0xb0(%rsp), %rdx
    5659:      	movq	(%rdx,%r12), %r12
    565d:      	jmp	0x56ed <kprobe_unwind_v8+0x56ed>
    5662:      	movq	(%rip), %rax            # 0x5669 <kprobe_unwind_v8+0x5669>
    5669:      	cmpl	$0x0, (%rax)
    566c:      	je	0x56e1 <kprobe_unwind_v8+0x56e1>
    566e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5678:      	movq	%rax, 0x26(%rsp)
    567d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5687:      	movq	%rax, 0x20(%rsp)
    568c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5696:      	movq	%rax, 0x18(%rsp)
    569b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    56a5:      	movq	%rax, 0x10(%rsp)
    56aa:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    56b4:      	movq	%rax, 0x8(%rsp)
    56b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    56c3:      	movq	%rax, (%rsp)
    56c7:      	movq	%rsp, %rdi
    56ca:      	movl	$0x2e, %eax
    56cf:      	movl	$0x6, %ecx
    56d4:      	movl	0x70(%rsp), %edx
    56d8:      	movl	$0x2e, %esi
    56dd:      	xorl	%eax, %eax
    56df:      	callq	*%rcx
    56e1:      	xorl	%ebp, %ebp
    56e3:      	jmp	0x5915 <kprobe_unwind_v8+0x5915>
    56e8:      	addq	0x50(%rsp), %r12
    56ed:      	movq	0xb0(%rsp), %rdx
    56f5:      	movl	(%rdx,%rcx), %r13d
    56f9:      	movq	0x48(%rsp), %rcx
    56fe:      	movzbl	0x17(%rcx), %esi
    5702:      	movl	%esi, 0xac(%rsp)
    5709:      	movzbl	0x18(%rcx), %r15d
    570e:      	movq	%r13, %rcx
    5711:      	addq	%r12, %rcx
    5714:      	movq	%rcx, 0xb8(%rsp)
    571c:      	andl	(%rdx,%rax), %r15d
    5720:      	movq	(%rip), %rax            # 0x5727 <kprobe_unwind_v8+0x5727>
    5727:      	cmpl	$0x0, (%rax)
    572a:      	je	0x5822 <kprobe_unwind_v8+0x5822>
    5730:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    573a:      	movq	%rax, 0x20(%rsp)
    573f:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    5749:      	movq	%rax, 0x18(%rsp)
    574e:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    5758:      	movq	%rax, 0x10(%rsp)
    575d:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    5767:      	movq	%rax, 0x8(%rsp)
    576c:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    5776:      	movq	%rax, (%rsp)
    577a:      	movb	$0x0, 0x28(%rsp)
    577f:      	movq	%rsp, %rdi
    5782:      	movl	$0x29, %eax
    5787:      	movl	$0x6, %r9d
    578d:      	movl	$0x29, %esi
    5792:      	movq	0x68(%rsp), %rdx
    5797:      	movq	0x58(%rsp), %rcx
    579c:      	movq	0x50(%rsp), %r8
    57a1:      	xorl	%eax, %eax
    57a3:      	callq	*%r9
    57a6:      	movq	(%rip), %rax            # 0x57ad <kprobe_unwind_v8+0x57ad>
    57ad:      	cmpl	$0x0, (%rax)
    57b0:      	je	0x5822 <kprobe_unwind_v8+0x5822>
    57b2:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    57bc:      	movq	%rax, 0x1d(%rsp)
    57c1:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    57cb:      	movq	%rax, 0x18(%rsp)
    57d0:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    57da:      	movq	%rax, 0x10(%rsp)
    57df:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    57e9:      	movq	%rax, 0x8(%rsp)
    57ee:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    57f8:      	movq	%rax, (%rsp)
    57fc:      	movq	%rsp, %rdi
    57ff:      	movl	$0x25, %eax
    5804:      	movl	$0x6, %r9d
    580a:      	movl	$0x25, %esi
    580f:      	movq	%r12, %rdx
    5812:      	movq	0xb8(%rsp), %rcx
    581a:      	movl	%r13d, %r8d
    581d:      	xorl	%eax, %eax
    581f:      	callq	*%r9
    5822:      	movq	0xa0(%rsp), %rbp
    582a:      	subq	%r12, %rbp
    582d:      	jb	0x5889 <kprobe_unwind_v8+0x5889>
    582f:      	movq	0xb8(%rsp), %rax
    5837:      	cmpq	%rax, 0xa0(%rsp)
    583f:      	jae	0x5889 <kprobe_unwind_v8+0x5889>
    5841:      	movl	0xac(%rsp), %eax
    5848:      	shrxl	%eax, %r15d, %eax
    584d:      	movq	0x48(%rsp), %rcx
    5852:      	movzbl	0x19(%rcx), %ecx
    5856:      	movq	0x68(%rsp), %r15
    585b:      	orq	$0x4, %r15
    585f:      	movq	0x50(%rsp), %rdx
    5864:      	orq	$0x3, %rdx
    5868:      	cmpl	%ecx, %eax
    586a:      	cmoveq	%r15, %rdx
    586e:      	shll	$0x4, %r13d
    5872:      	orl	%eax, %r13d
    5875:      	shlq	$0x20, %r13
    5879:      	orq	%r13, %rbp
    587c:      	movq	%rdx, 0x90(%rsp)
    5884:      	jmp	0x5915 <kprobe_unwind_v8+0x5915>
    5889:      	movq	(%rip), %rax            # 0x5890 <kprobe_unwind_v8+0x5890>
    5890:      	cmpl	$0x0, (%rax)
    5893:      	jne	0x58a4 <kprobe_unwind_v8+0x58a4>
    5895:      	xorl	%ebp, %ebp
    5897:      	movzbl	0xf30(%r14), %r12d
    589f:      	jmp	0x59c0 <kprobe_unwind_v8+0x59c0>
    58a4:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    58ae:      	movq	%rax, 0x28(%rsp)
    58b3:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    58bd:      	movq	%rax, 0x20(%rsp)
    58c2:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    58cc:      	movq	%rax, 0x18(%rsp)
    58d1:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    58db:      	movq	%rax, 0x10(%rsp)
    58e0:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    58ea:      	movq	%rax, 0x8(%rsp)
    58ef:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    58f9:      	movq	%rax, (%rsp)
    58fd:      	movq	%rsp, %rdi
    5900:      	movl	$0x30, %eax
    5905:      	movl	$0x6, %ecx
    590a:      	xorl	%ebp, %ebp
    590c:      	movl	$0x30, %esi
    5911:      	xorl	%eax, %eax
    5913:      	callq	*%rcx
    5915:      	movzbl	0xf30(%r14), %r12d
    591d:      	movq	(%rip), %rax            # 0x5924 <kprobe_unwind_v8+0x5924>
    5924:      	cmpl	$0x0, (%rax)
    5927:      	je	0x59c0 <kprobe_unwind_v8+0x59c0>
    592d:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    5937:      	movq	%rax, 0x30(%rsp)
    593c:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    5946:      	movq	%rax, 0x28(%rsp)
    594b:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    5955:      	movq	%rax, 0x20(%rsp)
    595a:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    5964:      	movq	%rax, 0x18(%rsp)
    5969:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    5973:      	movq	%rax, 0x10(%rsp)
    5978:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    5982:      	movq	%rax, 0x8(%rsp)
    5987:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5991:      	movq	%rax, (%rsp)
    5995:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    599d:      	movq	%rsp, %rdi
    59a0:      	movl	$0x3c, %eax
    59a5:      	movl	$0x6, %r8d
    59ab:      	movl	$0x3c, %esi
    59b0:      	movq	%rbp, %rdx
    59b3:      	movq	0x90(%rsp), %rcx
    59bb:      	xorl	%eax, %eax
    59bd:      	callq	*%r8
    59c0:      	movl	0x2c0(%r14), %eax
    59c7:      	cmpq	$0x7e, %rax
    59cb:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    59d1:      	leal	0x1(%rax), %ecx
    59d4:      	movl	%ecx, 0x2c0(%r14)
    59db:      	leaq	(%rax,%rax,2), %rax
    59df:      	movq	0x90(%rsp), %rcx
    59e7:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    59ef:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    59f7:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    5a00:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    5a08:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    5a14:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    5a1f:      	movq	0xee0(%r14), %rax
    5a26:      	movq	%rsp, %rdi
    5a29:      	movl	$0x10, %ecx
    5a2e:      	movl	$0x70, %r8d
    5a34:      	movq	0xee0(%r14), %rdx
    5a3b:      	movl	$0x10, %esi
    5a40:      	callq	*%r8
    5a43:      	testq	%rax, %rax
    5a46:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    5a4c:      	movq	0xee0(%r14), %rax
    5a53:      	addq	$0x10, %rax
    5a57:      	movq	%rax, 0xed8(%r14)
    5a5e:      	movq	(%rsp), %rax
    5a62:      	movq	%rax, 0xee0(%r14)
    5a69:      	movq	0x8(%rsp), %rax
    5a6e:      	movq	%rax, 0xed0(%r14)
    5a75:      	movb	$0x1, 0xf30(%r14)
    5a7d:      	movq	(%rip), %rax            # 0x5a84 <kprobe_unwind_v8+0x5a84>
    5a84:      	cmpl	$0x0, (%rax)
    5a87:      	je	0x5af1 <kprobe_unwind_v8+0x5af1>
    5a89:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    5a93:      	movq	%rax, 0x17(%rsp)
    5a98:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    5aa2:      	movq	%rax, 0x10(%rsp)
    5aa7:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    5ab1:      	movq	%rax, 0x8(%rsp)
    5ab6:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    5ac0:      	movq	%rax, (%rsp)
    5ac4:      	movq	%rsp, %rdi
    5ac7:      	movl	$0x1f, %eax
    5acc:      	movl	$0x6, %r9d
    5ad2:      	movq	0xed0(%r14), %rdx
    5ad9:      	movq	0xed8(%r14), %rcx
    5ae0:      	movq	0xee0(%r14), %r8
    5ae7:      	movl	$0x1f, %esi
    5aec:      	xorl	%eax, %eax
    5aee:      	callq	*%r9
    5af1:      	movl	$0x38, 0x70(%rsp)
    5af9:      	movq	(%rip), %rdi            # 0x5b00 <kprobe_unwind_v8+0x5b00>
    5b00:      	leaq	0x70(%rsp), %rsi
    5b05:      	movl	$0x1, %eax
    5b0a:      	callq	*%rax
    5b0c:      	testq	%rax, %rax
    5b0f:      	je	0x5b19 <kprobe_unwind_v8+0x5b19>
    5b11:      	incq	(%rax)
    5b14:      	jmp	0x5b9a <kprobe_unwind_v8+0x5b9a>
    5b19:      	xorl	%eax, %eax
    5b1b:      	movq	(%rip), %rcx            # 0x5b22 <kprobe_unwind_v8+0x5b22>
    5b22:      	cmpl	$0x0, (%rcx)
    5b25:      	je	0x5ba3 <kprobe_unwind_v8+0x5ba3>
    5b27:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5b31:      	movq	%rax, 0x26(%rsp)
    5b36:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5b40:      	movq	%rax, 0x20(%rsp)
    5b45:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5b4f:      	movq	%rax, 0x18(%rsp)
    5b54:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5b5e:      	movq	%rax, 0x10(%rsp)
    5b63:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5b6d:      	movq	%rax, 0x8(%rsp)
    5b72:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5b7c:      	movq	%rax, (%rsp)
    5b80:      	movq	%rsp, %rdi
    5b83:      	movl	$0x2e, %eax
    5b88:      	movl	$0x6, %ecx
    5b8d:      	movl	0x70(%rsp), %edx
    5b91:      	movl	$0x2e, %esi
    5b96:      	xorl	%eax, %eax
    5b98:      	callq	*%rcx
    5b9a:      	movq	(%rip), %rax            # 0x5ba1 <kprobe_unwind_v8+0x5ba1>
    5ba1:      	movl	(%rax), %eax
    5ba3:      	movq	0xed0(%r14), %r12
    5baa:      	testq	%r12, %r12
    5bad:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    5bb3:      	testl	%eax, %eax
    5bb5:      	je	0x5c3d <kprobe_unwind_v8+0x5c3d>
    5bbb:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    5bc5:      	movq	%rax, 0x28(%rsp)
    5bca:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    5bd4:      	movq	%rax, 0x20(%rsp)
    5bd9:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    5be3:      	movq	%rax, 0x18(%rsp)
    5be8:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    5bf2:      	movq	%rax, 0x10(%rsp)
    5bf7:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    5c01:      	movq	%rax, 0x8(%rsp)
    5c06:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    5c10:      	movq	%rax, (%rsp)
    5c14:      	movb	$0x0, 0x30(%rsp)
    5c19:      	movq	%rsp, %rdi
    5c1c:      	movl	$0x31, %eax
    5c21:      	movl	$0x6, %ecx
    5c26:      	movl	0x2c0(%r14), %edx
    5c2d:      	movl	$0x31, %esi
    5c32:      	xorl	%eax, %eax
    5c34:      	callq	*%rcx
    5c36:      	movq	0xed0(%r14), %r12
    5c3d:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    5c47:      	cmpq	%rax, %r12
    5c4a:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    5c50:      	cmpq	$0x1000, %r12           # imm = 0x1000
    5c57:      	jb	0x285e <kprobe_unwind_v8+0x285e>
    5c5d:      	movl	(%r14), %eax
    5c60:      	movl	$0x60, 0x70(%rsp)
    5c68:      	movbel	%eax, 0x74(%rsp)
    5c6e:      	movbeq	%r12, 0x78(%rsp)
    5c75:      	movq	(%rip), %rdi            # 0x5c7c <kprobe_unwind_v8+0x5c7c>
    5c7c:      	leaq	0x70(%rsp), %rsi
    5c81:      	movl	$0x1, %eax
    5c86:      	callq	*%rax
    5c88:      	testq	%rax, %rax
    5c8b:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    5c91:      	movq	0x8(%rax), %rbp
    5c95:      	movq	%rbp, %rcx
    5c98:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    5ca2:      	andq	%rdx, %rcx
    5ca5:      	movq	%rcx, 0xf20(%r14)
    5cac:      	movq	(%rax), %rax
    5caf:      	movq	%rax, 0xf10(%r14)
    5cb6:      	shrq	$0x38, %rbp
    5cba:      	movq	%r12, %rax
    5cbd:      	subq	%rcx, %rax
    5cc0:      	movq	%rax, 0xf18(%r14)
    5cc7:      	movq	(%rip), %rax            # 0x5cce <kprobe_unwind_v8+0x5cce>
    5cce:      	cmpl	$0x0, (%rax)
    5cd1:      	je	0x5ddd <kprobe_unwind_v8+0x5ddd>
    5cd7:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    5ce1:      	movq	%rax, 0x28(%rsp)
    5ce6:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    5cf0:      	movq	%rax, 0x20(%rsp)
    5cf5:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    5cff:      	movq	%rax, 0x18(%rsp)
    5d04:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    5d0e:      	movq	%rax, 0x10(%rsp)
    5d13:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    5d1d:      	movq	%rax, 0x8(%rsp)
    5d22:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    5d2c:      	movq	%r13, (%rsp)
    5d30:      	movw	$0xa, 0x30(%rsp)
    5d37:      	movq	%rsp, %rdi
    5d3a:      	movl	$0x32, %eax
    5d3f:      	movl	$0x6, %r9d
    5d45:      	movq	0xf10(%r14), %rcx
    5d4c:      	movl	$0x32, %esi
    5d51:      	movq	%r12, %rdx
    5d54:      	movl	%ebp, %r8d
    5d57:      	xorl	%eax, %eax
    5d59:      	callq	*%r9
    5d5c:      	movq	(%rip), %rax            # 0x5d63 <kprobe_unwind_v8+0x5d63>
    5d63:      	cmpl	$0x0, (%rax)
    5d66:      	je	0x5ddd <kprobe_unwind_v8+0x5ddd>
    5d68:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    5d72:      	movq	%rax, 0x27(%rsp)
    5d77:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    5d81:      	movq	%rax, 0x20(%rsp)
    5d86:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    5d90:      	movq	%rax, 0x18(%rsp)
    5d95:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    5d9f:      	movq	%rax, 0x10(%rsp)
    5da4:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    5dae:      	movq	%rax, 0x8(%rsp)
    5db3:      	movq	%r13, (%rsp)
    5db7:      	movq	%rsp, %rdi
    5dba:      	movl	$0x2f, %eax
    5dbf:      	movl	$0x6, %r8d
    5dc5:      	movq	0xf18(%r14), %rcx
    5dcc:      	movq	0xf20(%r14), %rdx
    5dd3:      	movl	$0x2f, %esi
    5dd8:      	xorl	%eax, %eax
    5dda:      	callq	*%r8
    5ddd:      	cmpl	$0x1, %ebp
    5de0:      	jne	0x5fbc <kprobe_unwind_v8+0x5fbc>
    5de6:      	movq	0xf10(%r14), %rax
    5ded:      	movq	%rax, 0x70(%rsp)
    5df2:      	movq	0xf18(%r14), %r13
    5df9:      	movq	(%rip), %rdi            # 0x5e00 <kprobe_unwind_v8+0x5e00>
    5e00:      	leaq	0x70(%rsp), %rsi
    5e05:      	movl	$0x1, %eax
    5e0a:      	callq	*%rax
    5e0c:      	movl	$0x1, %ebp
    5e11:      	testq	%rax, %rax
    5e14:      	je	0x5fbc <kprobe_unwind_v8+0x5fbc>
    5e1a:      	movq	%rax, %r12
    5e1d:      	cmpq	%r13, (%rax)
    5e20:      	ja	0x5e29 <kprobe_unwind_v8+0x5e29>
    5e22:      	cmpq	%r13, 0x8(%r12)
    5e27:      	jae	0x5e3f <kprobe_unwind_v8+0x5e3f>
    5e29:      	cmpq	%r13, 0x10(%r12)
    5e2e:      	ja	0x5fbc <kprobe_unwind_v8+0x5fbc>
    5e34:      	cmpq	%r13, 0x18(%r12)
    5e39:      	jb	0x5fbc <kprobe_unwind_v8+0x5fbc>
    5e3f:      	movq	(%rip), %rax            # 0x5e46 <kprobe_unwind_v8+0x5e46>
    5e46:      	cmpl	$0x0, (%rax)
    5e49:      	je	0x5ea2 <kprobe_unwind_v8+0x5ea2>
    5e4b:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    5e55:      	movq	%rax, 0x16(%rsp)
    5e5a:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    5e64:      	movq	%rax, 0x10(%rsp)
    5e69:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    5e73:      	movq	%rax, 0x8(%rsp)
    5e78:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5e82:      	movq	%rax, (%rsp)
    5e86:      	movq	%rsp, %rdi
    5e89:      	movl	$0x1e, %eax
    5e8e:      	movl	$0x6, %ecx
    5e93:      	movzwl	0x20(%r12), %edx
    5e99:      	movl	$0x1e, %esi
    5e9e:      	xorl	%eax, %eax
    5ea0:      	callq	*%rcx
    5ea2:      	movl	0x1380(%r14), %eax
    5ea9:      	movl	0x20(%r12), %ecx
    5eae:      	btl	%ecx, %eax
    5eb1:      	jae	0x5f12 <kprobe_unwind_v8+0x5f12>
    5eb3:      	movq	(%rip), %rax            # 0x5eba <kprobe_unwind_v8+0x5eba>
    5eba:      	cmpl	$0x0, (%rax)
    5ebd:      	je	0x5fbc <kprobe_unwind_v8+0x5fbc>
    5ec3:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    5ecd:      	movq	%rax, 0x10(%rsp)
    5ed2:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    5edc:      	movq	%rax, 0x8(%rsp)
    5ee1:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5eeb:      	movq	%rax, (%rsp)
    5eef:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    5ef7:      	movq	%rsp, %rdi
    5efa:      	movl	$0x1b, %eax
    5eff:      	movl	$0x6, %ecx
    5f04:      	movl	$0x1b, %esi
    5f09:      	xorl	%eax, %eax
    5f0b:      	callq	*%rcx
    5f0d:      	jmp	0x5fbc <kprobe_unwind_v8+0x5fbc>
    5f12:      	movl	$0x0, 0x64(%rsp)
    5f1a:      	movq	(%rip), %rdi            # 0x5f21 <kprobe_unwind_v8+0x5f21>
    5f21:      	leaq	0x64(%rsp), %rsi
    5f26:      	movl	$0x1, %eax
    5f2b:      	callq	*%rax
    5f2d:      	testq	%rax, %rax
    5f30:      	je	0x5f37 <kprobe_unwind_v8+0x5f37>
    5f32:      	incq	(%rax)
    5f35:      	jmp	0x5fb6 <kprobe_unwind_v8+0x5fb6>
    5f37:      	movq	(%rip), %rax            # 0x5f3e <kprobe_unwind_v8+0x5f3e>
    5f3e:      	cmpl	$0x0, (%rax)
    5f41:      	je	0x5fb6 <kprobe_unwind_v8+0x5fb6>
    5f43:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5f4d:      	movq	%rax, 0x26(%rsp)
    5f52:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5f5c:      	movq	%rax, 0x20(%rsp)
    5f61:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5f6b:      	movq	%rax, 0x18(%rsp)
    5f70:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5f7a:      	movq	%rax, 0x10(%rsp)
    5f7f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5f89:      	movq	%rax, 0x8(%rsp)
    5f8e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5f98:      	movq	%rax, (%rsp)
    5f9c:      	movq	%rsp, %rdi
    5f9f:      	movl	$0x2e, %eax
    5fa4:      	movl	$0x6, %ecx
    5fa9:      	movl	0x64(%rsp), %edx
    5fad:      	movl	$0x2e, %esi
    5fb2:      	xorl	%eax, %eax
    5fb4:      	callq	*%rcx
    5fb6:      	movzwl	0x20(%r12), %ebp
    5fbc:      	xorl	%r12d, %r12d
    5fbf:      	cmpl	$0x7, %ebp
    5fc2:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    5fc8:      	movq	0xed0(%r14), %rax
    5fcf:      	movq	%rax, 0xa0(%rsp)
    5fd7:      	movq	0xed8(%r14), %r12
    5fde:      	movq	0xee0(%r14), %r13
    5fe5:      	movq	(%rip), %rax            # 0x5fec <kprobe_unwind_v8+0x5fec>
    5fec:      	cmpl	$0x0, (%rax)
    5fef:      	je	0x6052 <kprobe_unwind_v8+0x6052>
    5ff1:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    5ffb:      	movq	%rax, 0x17(%rsp)
    6000:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    600a:      	movq	%rax, 0x10(%rsp)
    600f:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    6019:      	movq	%rax, 0x8(%rsp)
    601e:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    6028:      	movq	%rax, (%rsp)
    602c:      	movq	%rsp, %rdi
    602f:      	movl	$0x1f, %eax
    6034:      	movl	$0x6, %r9d
    603a:      	movl	$0x1f, %esi
    603f:      	movq	0xa0(%rsp), %rdx
    6047:      	movq	%r12, %rcx
    604a:      	movq	%r13, %r8
    604d:      	xorl	%eax, %eax
    604f:      	callq	*%r9
    6052:      	cmpq	%r12, %r13
    6055:      	jb	0x80b0 <kprobe_unwind_v8+0x80b0>
    605b:      	leaq	0x2000(%r12), %rax
    6063:      	cmpq	%rax, %r13
    6066:      	jae	0x80b0 <kprobe_unwind_v8+0x80b0>
    606c:      	addq	$-0x40, %r13
    6070:      	movl	$0x40, %eax
    6075:      	movl	$0x70, %ecx
    607a:      	movq	0x98(%rsp), %rdi
    6082:      	movl	$0x40, %esi
    6087:      	movq	%r13, %rdx
    608a:      	callq	*%rcx
    608c:      	testq	%rax, %rax
    608f:      	movq	(%rip), %rbp            # 0x6096 <kprobe_unwind_v8+0x6096>
    6096:      	jne	0x138 <kprobe_unwind_v8+0x138>
    609c:      	movq	0x48(%rsp), %rax
    60a1:      	movzbl	0x14(%rax), %ecx
    60a5:      	xorl	%ebp, %ebp
    60a7:      	cmpq	$0x38, %rcx
    60ab:      	ja	0x220 <kprobe_unwind_v8+0x220>
    60b1:      	movq	0x48(%rsp), %rax
    60b6:      	movzbl	0x15(%rax), %eax
    60ba:      	cmpq	$0x38, %rax
    60be:      	ja	0x220 <kprobe_unwind_v8+0x220>
    60c4:      	movq	0x48(%rsp), %rdx
    60c9:      	movzbl	0x16(%rdx), %edx
    60cd:      	cmpq	$0x38, %rdx
    60d1:      	ja	0x220 <kprobe_unwind_v8+0x220>
    60d7:      	movq	0x98(%rsp), %rsi
    60df:      	movq	(%rsi,%rcx), %rbp
    60e3:      	testb	$0x1, %bpl
    60e7:      	jne	0x6113 <kprobe_unwind_v8+0x6113>
    60e9:      	shrq	%rbp
    60ec:      	movq	(%rip), %rax            # 0x60f3 <kprobe_unwind_v8+0x60f3>
    60f3:      	cmpl	$0x0, (%rax)
    60f6:      	jne	0x6295 <kprobe_unwind_v8+0x6295>
    60fc:      	xorl	%eax, %eax
    60fe:      	movq	%rax, 0x90(%rsp)
    6106:      	movzbl	0xf30(%r14), %r12d
    610e:      	jmp	0x6993 <kprobe_unwind_v8+0x6993>
    6113:      	movq	0x98(%rsp), %rcx
    611b:      	movq	(%rcx,%rdx), %r12
    611f:      	movq	(%rcx,%rax), %rdx
    6123:      	movl	%edx, %ecx
    6125:      	andl	$0x3, %ecx
    6128:      	andq	$-0x4, %rdx
    612c:      	xorl	%eax, %eax
    612e:      	cmpl	$0x1, %ecx
    6131:      	cmovneq	%rax, %rdx
    6135:      	movq	%rdx, 0x68(%rsp)
    613a:      	testq	%rdx, %rdx
    613d:      	je	0x61b0 <kprobe_unwind_v8+0x61b0>
    613f:      	movq	0x48(%rsp), %rax
    6144:      	movzbl	0xc(%rax), %edx
    6148:      	addq	0x68(%rsp), %rdx
    614d:      	movq	%rsp, %rdi
    6150:      	movl	$0x8, %eax
    6155:      	movl	$0x70, %ecx
    615a:      	movl	$0x8, %esi
    615f:      	callq	*%rcx
    6161:      	testq	%rax, %rax
    6164:      	jne	0x61ae <kprobe_unwind_v8+0x61ae>
    6166:      	movq	(%rsp), %rax
    616a:      	movl	%eax, %ecx
    616c:      	andl	$0x3, %ecx
    616f:      	cmpl	$0x1, %ecx
    6172:      	jne	0x61ae <kprobe_unwind_v8+0x61ae>
    6174:      	andq	$-0x4, %rax
    6178:      	je	0x61ae <kprobe_unwind_v8+0x61ae>
    617a:      	movq	0x48(%rsp), %rsi
    617f:      	movzbl	0xd(%rsi), %ecx
    6183:      	addq	%rax, %rcx
    6186:      	movq	%rsp, %rdi
    6189:      	movl	$0x2, %edx
    618e:      	movl	$0x70, %r8d
    6194:      	movzbl	0xd(%rsi), %edx
    6198:      	addq	%rax, %rdx
    619b:      	movl	$0x2, %esi
    61a0:      	callq	*%r8
    61a3:      	testq	%rax, %rax
    61a6:      	jne	0x61ae <kprobe_unwind_v8+0x61ae>
    61a8:      	movzwl	(%rsp), %eax
    61ac:      	jmp	0x61b0 <kprobe_unwind_v8+0x61b0>
    61ae:      	xorl	%eax, %eax
    61b0:      	movq	0x48(%rsp), %rcx
    61b5:      	cmpw	0x4(%rcx), %ax
    61b9:      	jb	0x1c5f <kprobe_unwind_v8+0x1c5f>
    61bf:      	movq	0x48(%rsp), %r8
    61c4:      	cmpw	0x6(%r8), %ax
    61c9:      	ja	0x494 <kprobe_unwind_v8+0x494>
    61cf:      	movzbl	0xf(%r8), %edx
    61d4:      	addq	0x68(%rsp), %rdx
    61d9:      	movq	%rsp, %rdi
    61dc:      	movl	$0x8, %eax
    61e1:      	movl	$0x70, %ecx
    61e6:      	movl	$0x8, %esi
    61eb:      	callq	*%rcx
    61ed:      	testq	%rax, %rax
    61f0:      	jne	0x62f8 <kprobe_unwind_v8+0x62f8>
    61f6:      	movq	(%rsp), %rcx
    61fa:      	movq	%rcx, %rax
    61fd:      	movq	%rcx, 0x58(%rsp)
    6202:      	andl	$0x3, %eax
    6205:      	cmpl	$0x1, %eax
    6208:      	jne	0x62f8 <kprobe_unwind_v8+0x62f8>
    620e:      	andq	$-0x4, 0x58(%rsp)
    6214:      	je	0x62f8 <kprobe_unwind_v8+0x62f8>
    621a:      	movq	0x48(%rsp), %rax
    621f:      	movzbl	0xc(%rax), %edx
    6223:      	addq	0x58(%rsp), %rdx
    6228:      	movq	%rsp, %rdi
    622b:      	movl	$0x8, %eax
    6230:      	movl	$0x70, %ecx
    6235:      	movl	$0x8, %esi
    623a:      	callq	*%rcx
    623c:      	testq	%rax, %rax
    623f:      	jne	0x62ff <kprobe_unwind_v8+0x62ff>
    6245:      	movq	(%rsp), %rax
    6249:      	movl	%eax, %ecx
    624b:      	andl	$0x3, %ecx
    624e:      	cmpl	$0x1, %ecx
    6251:      	jne	0x62ff <kprobe_unwind_v8+0x62ff>
    6257:      	andq	$-0x4, %rax
    625b:      	je	0x62ff <kprobe_unwind_v8+0x62ff>
    6261:      	movq	0x48(%rsp), %rsi
    6266:      	movzbl	0xd(%rsi), %ecx
    626a:      	addq	%rax, %rcx
    626d:      	movq	%rsp, %rdi
    6270:      	movl	$0x2, %edx
    6275:      	movl	$0x70, %r8d
    627b:      	movzbl	0xd(%rsi), %edx
    627f:      	addq	%rax, %rdx
    6282:      	movl	$0x2, %esi
    6287:      	callq	*%r8
    628a:      	testq	%rax, %rax
    628d:      	jne	0x62ff <kprobe_unwind_v8+0x62ff>
    628f:      	movzwl	(%rsp), %eax
    6293:      	jmp	0x6301 <kprobe_unwind_v8+0x6301>
    6295:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    629f:      	movq	%rax, 0x15(%rsp)
    62a4:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    62ae:      	movq	%rax, 0x10(%rsp)
    62b3:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    62bd:      	movq	%rax, 0x8(%rsp)
    62c2:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    62cc:      	movq	%rax, (%rsp)
    62d0:      	movq	%rsp, %rdi
    62d3:      	movl	$0x1d, %eax
    62d8:      	movl	$0x6, %ecx
    62dd:      	xorl	%eax, %eax
    62df:      	movq	%rax, 0x90(%rsp)
    62e7:      	movl	$0x1d, %esi
    62ec:      	movq	%rbp, %rdx
    62ef:      	xorl	%eax, %eax
    62f1:      	callq	*%rcx
    62f3:      	jmp	0x68e8 <kprobe_unwind_v8+0x68e8>
    62f8:      	xorl	%eax, %eax
    62fa:      	movq	%rax, 0x58(%rsp)
    62ff:      	xorl	%eax, %eax
    6301:      	movq	0x48(%rsp), %rcx
    6306:      	cmpw	0xa(%rcx), %ax
    630a:      	jne	0x998 <kprobe_unwind_v8+0x998>
    6310:      	movq	%r12, %rbp
    6313:      	shrq	$0x20, %rbp
    6317:      	je	0x638e <kprobe_unwind_v8+0x638e>
    6319:      	andl	$0x1, %r12d
    631d:      	jne	0x638e <kprobe_unwind_v8+0x638e>
    631f:      	movq	(%rip), %rax            # 0x6326 <kprobe_unwind_v8+0x6326>
    6326:      	cmpl	$0x0, (%rax)
    6329:      	je	0x6378 <kprobe_unwind_v8+0x6378>
    632b:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    6335:      	movq	%rax, 0x10(%rsp)
    633a:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    6344:      	movq	%rax, 0x8(%rsp)
    6349:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    6353:      	movq	%rax, (%rsp)
    6357:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    635f:      	movq	%rsp, %rdi
    6362:      	movl	$0x1c, %eax
    6367:      	movl	$0x6, %ecx
    636c:      	movl	$0x1c, %esi
    6371:      	movq	%rbp, %rdx
    6374:      	xorl	%eax, %eax
    6376:      	callq	*%rcx
    6378:      	movq	0x58(%rsp), %r15
    637d:      	orq	$0x1, %r15
    6381:      	movq	%r15, 0x90(%rsp)
    6389:      	jmp	0x68e8 <kprobe_unwind_v8+0x68e8>
    638e:      	movq	0x48(%rsp), %rax
    6393:      	movzbl	0xe(%rax), %edx
    6397:      	addq	0x68(%rsp), %rdx
    639c:      	movq	%rsp, %rdi
    639f:      	movl	$0x8, %eax
    63a4:      	movl	$0x70, %ecx
    63a9:      	movl	$0x8, %esi
    63ae:      	callq	*%rcx
    63b0:      	testq	%rax, %rax
    63b3:      	jne	0x6444 <kprobe_unwind_v8+0x6444>
    63b9:      	movq	(%rsp), %rcx
    63bd:      	movq	%rcx, %rax
    63c0:      	movq	%rcx, 0x50(%rsp)
    63c5:      	andl	$0x3, %eax
    63c8:      	cmpl	$0x1, %eax
    63cb:      	jne	0x6444 <kprobe_unwind_v8+0x6444>
    63cd:      	andq	$-0x4, 0x50(%rsp)
    63d3:      	je	0x6444 <kprobe_unwind_v8+0x6444>
    63d5:      	movq	0x48(%rsp), %rax
    63da:      	movzbl	0xc(%rax), %edx
    63de:      	addq	0x50(%rsp), %rdx
    63e3:      	movq	%rsp, %rdi
    63e6:      	movl	$0x8, %eax
    63eb:      	movl	$0x70, %ecx
    63f0:      	movl	$0x8, %esi
    63f5:      	callq	*%rcx
    63f7:      	testq	%rax, %rax
    63fa:      	jne	0x644b <kprobe_unwind_v8+0x644b>
    63fc:      	movq	(%rsp), %rax
    6400:      	movl	%eax, %ecx
    6402:      	andl	$0x3, %ecx
    6405:      	cmpl	$0x1, %ecx
    6408:      	jne	0x644b <kprobe_unwind_v8+0x644b>
    640a:      	andq	$-0x4, %rax
    640e:      	je	0x644b <kprobe_unwind_v8+0x644b>
    6410:      	movq	0x48(%rsp), %rsi
    6415:      	movzbl	0xd(%rsi), %ecx
    6419:      	addq	%rax, %rcx
    641c:      	movq	%rsp, %rdi
    641f:      	movl	$0x2, %edx
    6424:      	movl	$0x70, %r8d
    642a:      	movzbl	0xd(%rsi), %edx
    642e:      	addq	%rax, %rdx
    6431:      	movl	$0x2, %esi
    6436:      	callq	*%r8
    6439:      	testq	%rax, %rax
    643c:      	jne	0x644b <kprobe_unwind_v8+0x644b>
    643e:      	movzwl	(%rsp), %eax
    6442:      	jmp	0x644d <kprobe_unwind_v8+0x644d>
    6444:      	xorl	%eax, %eax
    6446:      	movq	%rax, 0x50(%rsp)
    644b:      	xorl	%eax, %eax
    644d:      	movq	0x58(%rsp), %rcx
    6452:      	orq	$0x2, %rcx
    6456:      	movq	%rcx, 0x90(%rsp)
    645e:      	movq	0x48(%rsp), %rcx
    6463:      	cmpw	0x8(%rcx), %ax
    6467:      	jne	0x6533 <kprobe_unwind_v8+0x6533>
    646d:      	movl	$0x60, %eax
    6472:      	movl	$0x70, %ecx
    6477:      	movq	0xb0(%rsp), %rdi
    647f:      	movq	0x50(%rsp), %rdx
    6484:      	movl	$0x60, %esi
    6489:      	callq	*%rcx
    648b:      	testq	%rax, %rax
    648e:      	je	0x65e8 <kprobe_unwind_v8+0x65e8>
    6494:      	movl	$0x3b, 0x70(%rsp)
    649c:      	movq	(%rip), %rdi            # 0x64a3 <kprobe_unwind_v8+0x64a3>
    64a3:      	leaq	0x70(%rsp), %rsi
    64a8:      	movl	$0x1, %eax
    64ad:      	callq	*%rax
    64af:      	testq	%rax, %rax
    64b2:      	jne	0x65de <kprobe_unwind_v8+0x65de>
    64b8:      	movq	(%rip), %rax            # 0x64bf <kprobe_unwind_v8+0x64bf>
    64bf:      	cmpl	$0x0, (%rax)
    64c2:      	je	0x66b4 <kprobe_unwind_v8+0x66b4>
    64c8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    64d2:      	movq	%rax, 0x26(%rsp)
    64d7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    64e1:      	movq	%rax, 0x20(%rsp)
    64e6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    64f0:      	movq	%rax, 0x18(%rsp)
    64f5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    64ff:      	movq	%rax, 0x10(%rsp)
    6504:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    650e:      	movq	%rax, 0x8(%rsp)
    6513:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    651d:      	movq	%rax, (%rsp)
    6521:      	movq	%rsp, %rdi
    6524:      	movl	$0x2e, %eax
    6529:      	movl	$0x6, %ecx
    652e:      	jmp	0x66a7 <kprobe_unwind_v8+0x66a7>
    6533:      	movq	(%rip), %rcx            # 0x653a <kprobe_unwind_v8+0x653a>
    653a:      	cmpl	$0x0, (%rcx)
    653d:      	je	0x65be <kprobe_unwind_v8+0x65be>
    653f:      	movzwl	%ax, %r8d
    6543:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    654d:      	movq	%rax, 0x26(%rsp)
    6552:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    655c:      	movq	%rax, 0x20(%rsp)
    6561:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    656b:      	movq	%rax, 0x18(%rsp)
    6570:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    657a:      	movq	%rax, 0x10(%rsp)
    657f:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    6589:      	movq	%rax, 0x8(%rsp)
    658e:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    6598:      	movq	%rax, (%rsp)
    659c:      	movq	%rsp, %rdi
    659f:      	movl	$0x2e, %eax
    65a4:      	movl	$0x6, %r9d
    65aa:      	movl	$0x2e, %esi
    65af:      	movq	0x68(%rsp), %rdx
    65b4:      	movq	0x50(%rsp), %rcx
    65b9:      	xorl	%eax, %eax
    65bb:      	callq	*%r9
    65be:      	movl	$0x3b, 0x70(%rsp)
    65c6:      	movq	(%rip), %rdi            # 0x65cd <kprobe_unwind_v8+0x65cd>
    65cd:      	leaq	0x70(%rsp), %rsi
    65d2:      	movl	$0x1, %eax
    65d7:      	callq	*%rax
    65d9:      	testq	%rax, %rax
    65dc:      	je	0x6635 <kprobe_unwind_v8+0x6635>
    65de:      	incq	(%rax)
    65e1:      	xorl	%ebp, %ebp
    65e3:      	jmp	0x68e8 <kprobe_unwind_v8+0x68e8>
    65e8:      	movq	0x48(%rsp), %rax
    65ed:      	movzbl	0x12(%rax), %ecx
    65f1:      	xorl	%ebp, %ebp
    65f3:      	cmpq	$0x5c, %rcx
    65f7:      	ja	0x220 <kprobe_unwind_v8+0x220>
    65fd:      	movq	0x48(%rsp), %rax
    6602:      	movzbl	0x13(%rax), %eax
    6606:      	cmpq	$0x5c, %rax
    660a:      	ja	0x220 <kprobe_unwind_v8+0x220>
    6610:      	movq	0x48(%rsp), %rdx
    6615:      	cmpb	$0x0, 0x10(%rdx)
    6619:      	movzbl	0x11(%rdx), %r12d
    661e:      	je	0x66bb <kprobe_unwind_v8+0x66bb>
    6624:      	movq	0xb0(%rsp), %rdx
    662c:      	movq	(%rdx,%r12), %r12
    6630:      	jmp	0x66c0 <kprobe_unwind_v8+0x66c0>
    6635:      	movq	(%rip), %rax            # 0x663c <kprobe_unwind_v8+0x663c>
    663c:      	cmpl	$0x0, (%rax)
    663f:      	je	0x66b4 <kprobe_unwind_v8+0x66b4>
    6641:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    664b:      	movq	%rax, 0x26(%rsp)
    6650:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    665a:      	movq	%rax, 0x20(%rsp)
    665f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6669:      	movq	%rax, 0x18(%rsp)
    666e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6678:      	movq	%rax, 0x10(%rsp)
    667d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6687:      	movq	%rax, 0x8(%rsp)
    668c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6696:      	movq	%rax, (%rsp)
    669a:      	movq	%rsp, %rdi
    669d:      	movl	$0x2e, %eax
    66a2:      	movl	$0x6, %ecx
    66a7:      	movl	0x70(%rsp), %edx
    66ab:      	movl	$0x2e, %esi
    66b0:      	xorl	%eax, %eax
    66b2:      	callq	*%rcx
    66b4:      	xorl	%ebp, %ebp
    66b6:      	jmp	0x68e8 <kprobe_unwind_v8+0x68e8>
    66bb:      	addq	0x50(%rsp), %r12
    66c0:      	movq	0xb0(%rsp), %rdx
    66c8:      	movl	(%rdx,%rcx), %r13d
    66cc:      	movq	0x48(%rsp), %rcx
    66d1:      	movzbl	0x17(%rcx), %esi
    66d5:      	movl	%esi, 0xac(%rsp)
    66dc:      	movzbl	0x18(%rcx), %r15d
    66e1:      	movq	%r13, %rcx
    66e4:      	addq	%r12, %rcx
    66e7:      	movq	%rcx, 0xb8(%rsp)
    66ef:      	andl	(%rdx,%rax), %r15d
    66f3:      	movq	(%rip), %rax            # 0x66fa <kprobe_unwind_v8+0x66fa>
    66fa:      	cmpl	$0x0, (%rax)
    66fd:      	je	0x67f5 <kprobe_unwind_v8+0x67f5>
    6703:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    670d:      	movq	%rax, 0x20(%rsp)
    6712:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    671c:      	movq	%rax, 0x18(%rsp)
    6721:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    672b:      	movq	%rax, 0x10(%rsp)
    6730:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    673a:      	movq	%rax, 0x8(%rsp)
    673f:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    6749:      	movq	%rax, (%rsp)
    674d:      	movb	$0x0, 0x28(%rsp)
    6752:      	movq	%rsp, %rdi
    6755:      	movl	$0x29, %eax
    675a:      	movl	$0x6, %r9d
    6760:      	movl	$0x29, %esi
    6765:      	movq	0x68(%rsp), %rdx
    676a:      	movq	0x58(%rsp), %rcx
    676f:      	movq	0x50(%rsp), %r8
    6774:      	xorl	%eax, %eax
    6776:      	callq	*%r9
    6779:      	movq	(%rip), %rax            # 0x6780 <kprobe_unwind_v8+0x6780>
    6780:      	cmpl	$0x0, (%rax)
    6783:      	je	0x67f5 <kprobe_unwind_v8+0x67f5>
    6785:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    678f:      	movq	%rax, 0x1d(%rsp)
    6794:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    679e:      	movq	%rax, 0x18(%rsp)
    67a3:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    67ad:      	movq	%rax, 0x10(%rsp)
    67b2:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    67bc:      	movq	%rax, 0x8(%rsp)
    67c1:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    67cb:      	movq	%rax, (%rsp)
    67cf:      	movq	%rsp, %rdi
    67d2:      	movl	$0x25, %eax
    67d7:      	movl	$0x6, %r9d
    67dd:      	movl	$0x25, %esi
    67e2:      	movq	%r12, %rdx
    67e5:      	movq	0xb8(%rsp), %rcx
    67ed:      	movl	%r13d, %r8d
    67f0:      	xorl	%eax, %eax
    67f2:      	callq	*%r9
    67f5:      	movq	0xa0(%rsp), %rbp
    67fd:      	subq	%r12, %rbp
    6800:      	jb	0x685c <kprobe_unwind_v8+0x685c>
    6802:      	movq	0xb8(%rsp), %rax
    680a:      	cmpq	%rax, 0xa0(%rsp)
    6812:      	jae	0x685c <kprobe_unwind_v8+0x685c>
    6814:      	movl	0xac(%rsp), %eax
    681b:      	shrxl	%eax, %r15d, %eax
    6820:      	movq	0x48(%rsp), %rcx
    6825:      	movzbl	0x19(%rcx), %ecx
    6829:      	movq	0x68(%rsp), %r15
    682e:      	orq	$0x4, %r15
    6832:      	movq	0x50(%rsp), %rdx
    6837:      	orq	$0x3, %rdx
    683b:      	cmpl	%ecx, %eax
    683d:      	cmoveq	%r15, %rdx
    6841:      	shll	$0x4, %r13d
    6845:      	orl	%eax, %r13d
    6848:      	shlq	$0x20, %r13
    684c:      	orq	%r13, %rbp
    684f:      	movq	%rdx, 0x90(%rsp)
    6857:      	jmp	0x68e8 <kprobe_unwind_v8+0x68e8>
    685c:      	movq	(%rip), %rax            # 0x6863 <kprobe_unwind_v8+0x6863>
    6863:      	cmpl	$0x0, (%rax)
    6866:      	jne	0x6877 <kprobe_unwind_v8+0x6877>
    6868:      	xorl	%ebp, %ebp
    686a:      	movzbl	0xf30(%r14), %r12d
    6872:      	jmp	0x6993 <kprobe_unwind_v8+0x6993>
    6877:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    6881:      	movq	%rax, 0x28(%rsp)
    6886:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    6890:      	movq	%rax, 0x20(%rsp)
    6895:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    689f:      	movq	%rax, 0x18(%rsp)
    68a4:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    68ae:      	movq	%rax, 0x10(%rsp)
    68b3:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    68bd:      	movq	%rax, 0x8(%rsp)
    68c2:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    68cc:      	movq	%rax, (%rsp)
    68d0:      	movq	%rsp, %rdi
    68d3:      	movl	$0x30, %eax
    68d8:      	movl	$0x6, %ecx
    68dd:      	xorl	%ebp, %ebp
    68df:      	movl	$0x30, %esi
    68e4:      	xorl	%eax, %eax
    68e6:      	callq	*%rcx
    68e8:      	movzbl	0xf30(%r14), %r12d
    68f0:      	movq	(%rip), %rax            # 0x68f7 <kprobe_unwind_v8+0x68f7>
    68f7:      	cmpl	$0x0, (%rax)
    68fa:      	je	0x6993 <kprobe_unwind_v8+0x6993>
    6900:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    690a:      	movq	%rax, 0x30(%rsp)
    690f:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    6919:      	movq	%rax, 0x28(%rsp)
    691e:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    6928:      	movq	%rax, 0x20(%rsp)
    692d:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    6937:      	movq	%rax, 0x18(%rsp)
    693c:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    6946:      	movq	%rax, 0x10(%rsp)
    694b:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    6955:      	movq	%rax, 0x8(%rsp)
    695a:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    6964:      	movq	%rax, (%rsp)
    6968:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    6970:      	movq	%rsp, %rdi
    6973:      	movl	$0x3c, %eax
    6978:      	movl	$0x6, %r8d
    697e:      	movl	$0x3c, %esi
    6983:      	movq	%rbp, %rdx
    6986:      	movq	0x90(%rsp), %rcx
    698e:      	xorl	%eax, %eax
    6990:      	callq	*%r8
    6993:      	movl	0x2c0(%r14), %eax
    699a:      	cmpq	$0x7e, %rax
    699e:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    69a4:      	leal	0x1(%rax), %ecx
    69a7:      	movl	%ecx, 0x2c0(%r14)
    69ae:      	leaq	(%rax,%rax,2), %rax
    69b2:      	movq	0x90(%rsp), %rcx
    69ba:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    69c2:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    69ca:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    69d3:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    69db:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    69e7:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    69f2:      	movq	0xee0(%r14), %rax
    69f9:      	movq	%rsp, %rdi
    69fc:      	movl	$0x10, %ecx
    6a01:      	movl	$0x70, %r8d
    6a07:      	movq	0xee0(%r14), %rdx
    6a0e:      	movl	$0x10, %esi
    6a13:      	callq	*%r8
    6a16:      	testq	%rax, %rax
    6a19:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    6a1f:      	movq	0xee0(%r14), %rax
    6a26:      	addq	$0x10, %rax
    6a2a:      	movq	%rax, 0xed8(%r14)
    6a31:      	movq	(%rsp), %rax
    6a35:      	movq	%rax, 0xee0(%r14)
    6a3c:      	movq	0x8(%rsp), %rax
    6a41:      	movq	%rax, 0xed0(%r14)
    6a48:      	movb	$0x1, 0xf30(%r14)
    6a50:      	movq	(%rip), %rax            # 0x6a57 <kprobe_unwind_v8+0x6a57>
    6a57:      	cmpl	$0x0, (%rax)
    6a5a:      	je	0x6ac4 <kprobe_unwind_v8+0x6ac4>
    6a5c:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    6a66:      	movq	%rax, 0x17(%rsp)
    6a6b:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    6a75:      	movq	%rax, 0x10(%rsp)
    6a7a:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    6a84:      	movq	%rax, 0x8(%rsp)
    6a89:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    6a93:      	movq	%rax, (%rsp)
    6a97:      	movq	%rsp, %rdi
    6a9a:      	movl	$0x1f, %eax
    6a9f:      	movl	$0x6, %r9d
    6aa5:      	movq	0xed0(%r14), %rdx
    6aac:      	movq	0xed8(%r14), %rcx
    6ab3:      	movq	0xee0(%r14), %r8
    6aba:      	movl	$0x1f, %esi
    6abf:      	xorl	%eax, %eax
    6ac1:      	callq	*%r9
    6ac4:      	movl	$0x38, 0x70(%rsp)
    6acc:      	movq	(%rip), %rdi            # 0x6ad3 <kprobe_unwind_v8+0x6ad3>
    6ad3:      	leaq	0x70(%rsp), %rsi
    6ad8:      	movl	$0x1, %eax
    6add:      	callq	*%rax
    6adf:      	testq	%rax, %rax
    6ae2:      	je	0x6aec <kprobe_unwind_v8+0x6aec>
    6ae4:      	incq	(%rax)
    6ae7:      	jmp	0x6b6d <kprobe_unwind_v8+0x6b6d>
    6aec:      	xorl	%eax, %eax
    6aee:      	movq	(%rip), %rcx            # 0x6af5 <kprobe_unwind_v8+0x6af5>
    6af5:      	cmpl	$0x0, (%rcx)
    6af8:      	je	0x6b76 <kprobe_unwind_v8+0x6b76>
    6afa:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6b04:      	movq	%rax, 0x26(%rsp)
    6b09:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6b13:      	movq	%rax, 0x20(%rsp)
    6b18:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6b22:      	movq	%rax, 0x18(%rsp)
    6b27:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6b31:      	movq	%rax, 0x10(%rsp)
    6b36:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6b40:      	movq	%rax, 0x8(%rsp)
    6b45:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6b4f:      	movq	%rax, (%rsp)
    6b53:      	movq	%rsp, %rdi
    6b56:      	movl	$0x2e, %eax
    6b5b:      	movl	$0x6, %ecx
    6b60:      	movl	0x70(%rsp), %edx
    6b64:      	movl	$0x2e, %esi
    6b69:      	xorl	%eax, %eax
    6b6b:      	callq	*%rcx
    6b6d:      	movq	(%rip), %rax            # 0x6b74 <kprobe_unwind_v8+0x6b74>
    6b74:      	movl	(%rax), %eax
    6b76:      	movq	0xed0(%r14), %r12
    6b7d:      	testq	%r12, %r12
    6b80:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    6b86:      	testl	%eax, %eax
    6b88:      	je	0x6c10 <kprobe_unwind_v8+0x6c10>
    6b8e:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    6b98:      	movq	%rax, 0x28(%rsp)
    6b9d:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    6ba7:      	movq	%rax, 0x20(%rsp)
    6bac:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    6bb6:      	movq	%rax, 0x18(%rsp)
    6bbb:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    6bc5:      	movq	%rax, 0x10(%rsp)
    6bca:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    6bd4:      	movq	%rax, 0x8(%rsp)
    6bd9:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    6be3:      	movq	%rax, (%rsp)
    6be7:      	movb	$0x0, 0x30(%rsp)
    6bec:      	movq	%rsp, %rdi
    6bef:      	movl	$0x31, %eax
    6bf4:      	movl	$0x6, %ecx
    6bf9:      	movl	0x2c0(%r14), %edx
    6c00:      	movl	$0x31, %esi
    6c05:      	xorl	%eax, %eax
    6c07:      	callq	*%rcx
    6c09:      	movq	0xed0(%r14), %r12
    6c10:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    6c1a:      	cmpq	%rax, %r12
    6c1d:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    6c23:      	cmpq	$0x1000, %r12           # imm = 0x1000
    6c2a:      	jb	0x285e <kprobe_unwind_v8+0x285e>
    6c30:      	movl	(%r14), %eax
    6c33:      	movl	$0x60, 0x70(%rsp)
    6c3b:      	movbel	%eax, 0x74(%rsp)
    6c41:      	movbeq	%r12, 0x78(%rsp)
    6c48:      	movq	(%rip), %rdi            # 0x6c4f <kprobe_unwind_v8+0x6c4f>
    6c4f:      	leaq	0x70(%rsp), %rsi
    6c54:      	movl	$0x1, %eax
    6c59:      	callq	*%rax
    6c5b:      	testq	%rax, %rax
    6c5e:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    6c64:      	movq	0x8(%rax), %rbp
    6c68:      	movq	%rbp, %rcx
    6c6b:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    6c75:      	andq	%rdx, %rcx
    6c78:      	movq	%rcx, 0xf20(%r14)
    6c7f:      	movq	(%rax), %rax
    6c82:      	movq	%rax, 0xf10(%r14)
    6c89:      	shrq	$0x38, %rbp
    6c8d:      	movq	%r12, %rax
    6c90:      	subq	%rcx, %rax
    6c93:      	movq	%rax, 0xf18(%r14)
    6c9a:      	movq	(%rip), %rax            # 0x6ca1 <kprobe_unwind_v8+0x6ca1>
    6ca1:      	cmpl	$0x0, (%rax)
    6ca4:      	je	0x6db0 <kprobe_unwind_v8+0x6db0>
    6caa:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    6cb4:      	movq	%rax, 0x28(%rsp)
    6cb9:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    6cc3:      	movq	%rax, 0x20(%rsp)
    6cc8:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    6cd2:      	movq	%rax, 0x18(%rsp)
    6cd7:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    6ce1:      	movq	%rax, 0x10(%rsp)
    6ce6:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    6cf0:      	movq	%rax, 0x8(%rsp)
    6cf5:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    6cff:      	movq	%r13, (%rsp)
    6d03:      	movw	$0xa, 0x30(%rsp)
    6d0a:      	movq	%rsp, %rdi
    6d0d:      	movl	$0x32, %eax
    6d12:      	movl	$0x6, %r9d
    6d18:      	movq	0xf10(%r14), %rcx
    6d1f:      	movl	$0x32, %esi
    6d24:      	movq	%r12, %rdx
    6d27:      	movl	%ebp, %r8d
    6d2a:      	xorl	%eax, %eax
    6d2c:      	callq	*%r9
    6d2f:      	movq	(%rip), %rax            # 0x6d36 <kprobe_unwind_v8+0x6d36>
    6d36:      	cmpl	$0x0, (%rax)
    6d39:      	je	0x6db0 <kprobe_unwind_v8+0x6db0>
    6d3b:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    6d45:      	movq	%rax, 0x27(%rsp)
    6d4a:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    6d54:      	movq	%rax, 0x20(%rsp)
    6d59:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    6d63:      	movq	%rax, 0x18(%rsp)
    6d68:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    6d72:      	movq	%rax, 0x10(%rsp)
    6d77:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    6d81:      	movq	%rax, 0x8(%rsp)
    6d86:      	movq	%r13, (%rsp)
    6d8a:      	movq	%rsp, %rdi
    6d8d:      	movl	$0x2f, %eax
    6d92:      	movl	$0x6, %r8d
    6d98:      	movq	0xf18(%r14), %rcx
    6d9f:      	movq	0xf20(%r14), %rdx
    6da6:      	movl	$0x2f, %esi
    6dab:      	xorl	%eax, %eax
    6dad:      	callq	*%r8
    6db0:      	cmpl	$0x1, %ebp
    6db3:      	jne	0x6f8f <kprobe_unwind_v8+0x6f8f>
    6db9:      	movq	0xf10(%r14), %rax
    6dc0:      	movq	%rax, 0x70(%rsp)
    6dc5:      	movq	0xf18(%r14), %r13
    6dcc:      	movq	(%rip), %rdi            # 0x6dd3 <kprobe_unwind_v8+0x6dd3>
    6dd3:      	leaq	0x70(%rsp), %rsi
    6dd8:      	movl	$0x1, %eax
    6ddd:      	callq	*%rax
    6ddf:      	movl	$0x1, %ebp
    6de4:      	testq	%rax, %rax
    6de7:      	je	0x6f8f <kprobe_unwind_v8+0x6f8f>
    6ded:      	movq	%rax, %r12
    6df0:      	cmpq	%r13, (%rax)
    6df3:      	ja	0x6dfc <kprobe_unwind_v8+0x6dfc>
    6df5:      	cmpq	%r13, 0x8(%r12)
    6dfa:      	jae	0x6e12 <kprobe_unwind_v8+0x6e12>
    6dfc:      	cmpq	%r13, 0x10(%r12)
    6e01:      	ja	0x6f8f <kprobe_unwind_v8+0x6f8f>
    6e07:      	cmpq	%r13, 0x18(%r12)
    6e0c:      	jb	0x6f8f <kprobe_unwind_v8+0x6f8f>
    6e12:      	movq	(%rip), %rax            # 0x6e19 <kprobe_unwind_v8+0x6e19>
    6e19:      	cmpl	$0x0, (%rax)
    6e1c:      	je	0x6e75 <kprobe_unwind_v8+0x6e75>
    6e1e:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    6e28:      	movq	%rax, 0x16(%rsp)
    6e2d:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    6e37:      	movq	%rax, 0x10(%rsp)
    6e3c:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    6e46:      	movq	%rax, 0x8(%rsp)
    6e4b:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    6e55:      	movq	%rax, (%rsp)
    6e59:      	movq	%rsp, %rdi
    6e5c:      	movl	$0x1e, %eax
    6e61:      	movl	$0x6, %ecx
    6e66:      	movzwl	0x20(%r12), %edx
    6e6c:      	movl	$0x1e, %esi
    6e71:      	xorl	%eax, %eax
    6e73:      	callq	*%rcx
    6e75:      	movl	0x1380(%r14), %eax
    6e7c:      	movl	0x20(%r12), %ecx
    6e81:      	btl	%ecx, %eax
    6e84:      	jae	0x6ee5 <kprobe_unwind_v8+0x6ee5>
    6e86:      	movq	(%rip), %rax            # 0x6e8d <kprobe_unwind_v8+0x6e8d>
    6e8d:      	cmpl	$0x0, (%rax)
    6e90:      	je	0x6f8f <kprobe_unwind_v8+0x6f8f>
    6e96:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    6ea0:      	movq	%rax, 0x10(%rsp)
    6ea5:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    6eaf:      	movq	%rax, 0x8(%rsp)
    6eb4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    6ebe:      	movq	%rax, (%rsp)
    6ec2:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    6eca:      	movq	%rsp, %rdi
    6ecd:      	movl	$0x1b, %eax
    6ed2:      	movl	$0x6, %ecx
    6ed7:      	movl	$0x1b, %esi
    6edc:      	xorl	%eax, %eax
    6ede:      	callq	*%rcx
    6ee0:      	jmp	0x6f8f <kprobe_unwind_v8+0x6f8f>
    6ee5:      	movl	$0x0, 0x64(%rsp)
    6eed:      	movq	(%rip), %rdi            # 0x6ef4 <kprobe_unwind_v8+0x6ef4>
    6ef4:      	leaq	0x64(%rsp), %rsi
    6ef9:      	movl	$0x1, %eax
    6efe:      	callq	*%rax
    6f00:      	testq	%rax, %rax
    6f03:      	je	0x6f0a <kprobe_unwind_v8+0x6f0a>
    6f05:      	incq	(%rax)
    6f08:      	jmp	0x6f89 <kprobe_unwind_v8+0x6f89>
    6f0a:      	movq	(%rip), %rax            # 0x6f11 <kprobe_unwind_v8+0x6f11>
    6f11:      	cmpl	$0x0, (%rax)
    6f14:      	je	0x6f89 <kprobe_unwind_v8+0x6f89>
    6f16:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6f20:      	movq	%rax, 0x26(%rsp)
    6f25:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6f2f:      	movq	%rax, 0x20(%rsp)
    6f34:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6f3e:      	movq	%rax, 0x18(%rsp)
    6f43:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6f4d:      	movq	%rax, 0x10(%rsp)
    6f52:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6f5c:      	movq	%rax, 0x8(%rsp)
    6f61:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6f6b:      	movq	%rax, (%rsp)
    6f6f:      	movq	%rsp, %rdi
    6f72:      	movl	$0x2e, %eax
    6f77:      	movl	$0x6, %ecx
    6f7c:      	movl	0x64(%rsp), %edx
    6f80:      	movl	$0x2e, %esi
    6f85:      	xorl	%eax, %eax
    6f87:      	callq	*%rcx
    6f89:      	movzwl	0x20(%r12), %ebp
    6f8f:      	xorl	%r12d, %r12d
    6f92:      	cmpl	$0x7, %ebp
    6f95:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    6f9b:      	movq	0xed0(%r14), %rax
    6fa2:      	movq	%rax, 0xa0(%rsp)
    6faa:      	movq	0xed8(%r14), %r12
    6fb1:      	movq	0xee0(%r14), %r13
    6fb8:      	movq	(%rip), %rax            # 0x6fbf <kprobe_unwind_v8+0x6fbf>
    6fbf:      	cmpl	$0x0, (%rax)
    6fc2:      	je	0x7025 <kprobe_unwind_v8+0x7025>
    6fc4:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    6fce:      	movq	%rax, 0x17(%rsp)
    6fd3:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    6fdd:      	movq	%rax, 0x10(%rsp)
    6fe2:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    6fec:      	movq	%rax, 0x8(%rsp)
    6ff1:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    6ffb:      	movq	%rax, (%rsp)
    6fff:      	movq	%rsp, %rdi
    7002:      	movl	$0x1f, %eax
    7007:      	movl	$0x6, %r9d
    700d:      	movl	$0x1f, %esi
    7012:      	movq	0xa0(%rsp), %rdx
    701a:      	movq	%r12, %rcx
    701d:      	movq	%r13, %r8
    7020:      	xorl	%eax, %eax
    7022:      	callq	*%r9
    7025:      	cmpq	%r12, %r13
    7028:      	jb	0x80b0 <kprobe_unwind_v8+0x80b0>
    702e:      	leaq	0x2000(%r12), %rax
    7036:      	cmpq	%rax, %r13
    7039:      	jae	0x80b0 <kprobe_unwind_v8+0x80b0>
    703f:      	addq	$-0x40, %r13
    7043:      	movl	$0x40, %eax
    7048:      	movl	$0x70, %ecx
    704d:      	movq	0x98(%rsp), %rdi
    7055:      	movl	$0x40, %esi
    705a:      	movq	%r13, %rdx
    705d:      	callq	*%rcx
    705f:      	testq	%rax, %rax
    7062:      	movq	(%rip), %rbp            # 0x7069 <kprobe_unwind_v8+0x7069>
    7069:      	jne	0x138 <kprobe_unwind_v8+0x138>
    706f:      	movq	0x48(%rsp), %rax
    7074:      	movzbl	0x14(%rax), %ecx
    7078:      	xorl	%ebp, %ebp
    707a:      	cmpq	$0x38, %rcx
    707e:      	ja	0x220 <kprobe_unwind_v8+0x220>
    7084:      	movq	0x48(%rsp), %rax
    7089:      	movzbl	0x15(%rax), %eax
    708d:      	cmpq	$0x38, %rax
    7091:      	ja	0x220 <kprobe_unwind_v8+0x220>
    7097:      	movq	0x48(%rsp), %rdx
    709c:      	movzbl	0x16(%rdx), %edx
    70a0:      	cmpq	$0x38, %rdx
    70a4:      	ja	0x220 <kprobe_unwind_v8+0x220>
    70aa:      	movq	0x98(%rsp), %rsi
    70b2:      	movq	(%rsi,%rcx), %rbp
    70b6:      	testb	$0x1, %bpl
    70ba:      	jne	0x70e6 <kprobe_unwind_v8+0x70e6>
    70bc:      	shrq	%rbp
    70bf:      	movq	(%rip), %rax            # 0x70c6 <kprobe_unwind_v8+0x70c6>
    70c6:      	cmpl	$0x0, (%rax)
    70c9:      	jne	0x7268 <kprobe_unwind_v8+0x7268>
    70cf:      	xorl	%eax, %eax
    70d1:      	movq	%rax, 0x90(%rsp)
    70d9:      	movzbl	0xf30(%r14), %r12d
    70e1:      	jmp	0x7966 <kprobe_unwind_v8+0x7966>
    70e6:      	movq	0x98(%rsp), %rcx
    70ee:      	movq	(%rcx,%rdx), %r12
    70f2:      	movq	(%rcx,%rax), %rdx
    70f6:      	movl	%edx, %ecx
    70f8:      	andl	$0x3, %ecx
    70fb:      	andq	$-0x4, %rdx
    70ff:      	xorl	%eax, %eax
    7101:      	cmpl	$0x1, %ecx
    7104:      	cmovneq	%rax, %rdx
    7108:      	movq	%rdx, 0x68(%rsp)
    710d:      	testq	%rdx, %rdx
    7110:      	je	0x7183 <kprobe_unwind_v8+0x7183>
    7112:      	movq	0x48(%rsp), %rax
    7117:      	movzbl	0xc(%rax), %edx
    711b:      	addq	0x68(%rsp), %rdx
    7120:      	movq	%rsp, %rdi
    7123:      	movl	$0x8, %eax
    7128:      	movl	$0x70, %ecx
    712d:      	movl	$0x8, %esi
    7132:      	callq	*%rcx
    7134:      	testq	%rax, %rax
    7137:      	jne	0x7181 <kprobe_unwind_v8+0x7181>
    7139:      	movq	(%rsp), %rax
    713d:      	movl	%eax, %ecx
    713f:      	andl	$0x3, %ecx
    7142:      	cmpl	$0x1, %ecx
    7145:      	jne	0x7181 <kprobe_unwind_v8+0x7181>
    7147:      	andq	$-0x4, %rax
    714b:      	je	0x7181 <kprobe_unwind_v8+0x7181>
    714d:      	movq	0x48(%rsp), %rsi
    7152:      	movzbl	0xd(%rsi), %ecx
    7156:      	addq	%rax, %rcx
    7159:      	movq	%rsp, %rdi
    715c:      	movl	$0x2, %edx
    7161:      	movl	$0x70, %r8d
    7167:      	movzbl	0xd(%rsi), %edx
    716b:      	addq	%rax, %rdx
    716e:      	movl	$0x2, %esi
    7173:      	callq	*%r8
    7176:      	testq	%rax, %rax
    7179:      	jne	0x7181 <kprobe_unwind_v8+0x7181>
    717b:      	movzwl	(%rsp), %eax
    717f:      	jmp	0x7183 <kprobe_unwind_v8+0x7183>
    7181:      	xorl	%eax, %eax
    7183:      	movq	0x48(%rsp), %rcx
    7188:      	cmpw	0x4(%rcx), %ax
    718c:      	jb	0x1c5f <kprobe_unwind_v8+0x1c5f>
    7192:      	movq	0x48(%rsp), %r8
    7197:      	cmpw	0x6(%r8), %ax
    719c:      	ja	0x494 <kprobe_unwind_v8+0x494>
    71a2:      	movzbl	0xf(%r8), %edx
    71a7:      	addq	0x68(%rsp), %rdx
    71ac:      	movq	%rsp, %rdi
    71af:      	movl	$0x8, %eax
    71b4:      	movl	$0x70, %ecx
    71b9:      	movl	$0x8, %esi
    71be:      	callq	*%rcx
    71c0:      	testq	%rax, %rax
    71c3:      	jne	0x72cb <kprobe_unwind_v8+0x72cb>
    71c9:      	movq	(%rsp), %rcx
    71cd:      	movq	%rcx, %rax
    71d0:      	movq	%rcx, 0x58(%rsp)
    71d5:      	andl	$0x3, %eax
    71d8:      	cmpl	$0x1, %eax
    71db:      	jne	0x72cb <kprobe_unwind_v8+0x72cb>
    71e1:      	andq	$-0x4, 0x58(%rsp)
    71e7:      	je	0x72cb <kprobe_unwind_v8+0x72cb>
    71ed:      	movq	0x48(%rsp), %rax
    71f2:      	movzbl	0xc(%rax), %edx
    71f6:      	addq	0x58(%rsp), %rdx
    71fb:      	movq	%rsp, %rdi
    71fe:      	movl	$0x8, %eax
    7203:      	movl	$0x70, %ecx
    7208:      	movl	$0x8, %esi
    720d:      	callq	*%rcx
    720f:      	testq	%rax, %rax
    7212:      	jne	0x72d2 <kprobe_unwind_v8+0x72d2>
    7218:      	movq	(%rsp), %rax
    721c:      	movl	%eax, %ecx
    721e:      	andl	$0x3, %ecx
    7221:      	cmpl	$0x1, %ecx
    7224:      	jne	0x72d2 <kprobe_unwind_v8+0x72d2>
    722a:      	andq	$-0x4, %rax
    722e:      	je	0x72d2 <kprobe_unwind_v8+0x72d2>
    7234:      	movq	0x48(%rsp), %rsi
    7239:      	movzbl	0xd(%rsi), %ecx
    723d:      	addq	%rax, %rcx
    7240:      	movq	%rsp, %rdi
    7243:      	movl	$0x2, %edx
    7248:      	movl	$0x70, %r8d
    724e:      	movzbl	0xd(%rsi), %edx
    7252:      	addq	%rax, %rdx
    7255:      	movl	$0x2, %esi
    725a:      	callq	*%r8
    725d:      	testq	%rax, %rax
    7260:      	jne	0x72d2 <kprobe_unwind_v8+0x72d2>
    7262:      	movzwl	(%rsp), %eax
    7266:      	jmp	0x72d4 <kprobe_unwind_v8+0x72d4>
    7268:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    7272:      	movq	%rax, 0x15(%rsp)
    7277:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    7281:      	movq	%rax, 0x10(%rsp)
    7286:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    7290:      	movq	%rax, 0x8(%rsp)
    7295:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    729f:      	movq	%rax, (%rsp)
    72a3:      	movq	%rsp, %rdi
    72a6:      	movl	$0x1d, %eax
    72ab:      	movl	$0x6, %ecx
    72b0:      	xorl	%eax, %eax
    72b2:      	movq	%rax, 0x90(%rsp)
    72ba:      	movl	$0x1d, %esi
    72bf:      	movq	%rbp, %rdx
    72c2:      	xorl	%eax, %eax
    72c4:      	callq	*%rcx
    72c6:      	jmp	0x78bb <kprobe_unwind_v8+0x78bb>
    72cb:      	xorl	%eax, %eax
    72cd:      	movq	%rax, 0x58(%rsp)
    72d2:      	xorl	%eax, %eax
    72d4:      	movq	0x48(%rsp), %rcx
    72d9:      	cmpw	0xa(%rcx), %ax
    72dd:      	jne	0x998 <kprobe_unwind_v8+0x998>
    72e3:      	movq	%r12, %rbp
    72e6:      	shrq	$0x20, %rbp
    72ea:      	je	0x7361 <kprobe_unwind_v8+0x7361>
    72ec:      	andl	$0x1, %r12d
    72f0:      	jne	0x7361 <kprobe_unwind_v8+0x7361>
    72f2:      	movq	(%rip), %rax            # 0x72f9 <kprobe_unwind_v8+0x72f9>
    72f9:      	cmpl	$0x0, (%rax)
    72fc:      	je	0x734b <kprobe_unwind_v8+0x734b>
    72fe:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    7308:      	movq	%rax, 0x10(%rsp)
    730d:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    7317:      	movq	%rax, 0x8(%rsp)
    731c:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    7326:      	movq	%rax, (%rsp)
    732a:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    7332:      	movq	%rsp, %rdi
    7335:      	movl	$0x1c, %eax
    733a:      	movl	$0x6, %ecx
    733f:      	movl	$0x1c, %esi
    7344:      	movq	%rbp, %rdx
    7347:      	xorl	%eax, %eax
    7349:      	callq	*%rcx
    734b:      	movq	0x58(%rsp), %r15
    7350:      	orq	$0x1, %r15
    7354:      	movq	%r15, 0x90(%rsp)
    735c:      	jmp	0x78bb <kprobe_unwind_v8+0x78bb>
    7361:      	movq	0x48(%rsp), %rax
    7366:      	movzbl	0xe(%rax), %edx
    736a:      	addq	0x68(%rsp), %rdx
    736f:      	movq	%rsp, %rdi
    7372:      	movl	$0x8, %eax
    7377:      	movl	$0x70, %ecx
    737c:      	movl	$0x8, %esi
    7381:      	callq	*%rcx
    7383:      	testq	%rax, %rax
    7386:      	jne	0x7417 <kprobe_unwind_v8+0x7417>
    738c:      	movq	(%rsp), %rcx
    7390:      	movq	%rcx, %rax
    7393:      	movq	%rcx, 0x50(%rsp)
    7398:      	andl	$0x3, %eax
    739b:      	cmpl	$0x1, %eax
    739e:      	jne	0x7417 <kprobe_unwind_v8+0x7417>
    73a0:      	andq	$-0x4, 0x50(%rsp)
    73a6:      	je	0x7417 <kprobe_unwind_v8+0x7417>
    73a8:      	movq	0x48(%rsp), %rax
    73ad:      	movzbl	0xc(%rax), %edx
    73b1:      	addq	0x50(%rsp), %rdx
    73b6:      	movq	%rsp, %rdi
    73b9:      	movl	$0x8, %eax
    73be:      	movl	$0x70, %ecx
    73c3:      	movl	$0x8, %esi
    73c8:      	callq	*%rcx
    73ca:      	testq	%rax, %rax
    73cd:      	jne	0x741e <kprobe_unwind_v8+0x741e>
    73cf:      	movq	(%rsp), %rax
    73d3:      	movl	%eax, %ecx
    73d5:      	andl	$0x3, %ecx
    73d8:      	cmpl	$0x1, %ecx
    73db:      	jne	0x741e <kprobe_unwind_v8+0x741e>
    73dd:      	andq	$-0x4, %rax
    73e1:      	je	0x741e <kprobe_unwind_v8+0x741e>
    73e3:      	movq	0x48(%rsp), %rsi
    73e8:      	movzbl	0xd(%rsi), %ecx
    73ec:      	addq	%rax, %rcx
    73ef:      	movq	%rsp, %rdi
    73f2:      	movl	$0x2, %edx
    73f7:      	movl	$0x70, %r8d
    73fd:      	movzbl	0xd(%rsi), %edx
    7401:      	addq	%rax, %rdx
    7404:      	movl	$0x2, %esi
    7409:      	callq	*%r8
    740c:      	testq	%rax, %rax
    740f:      	jne	0x741e <kprobe_unwind_v8+0x741e>
    7411:      	movzwl	(%rsp), %eax
    7415:      	jmp	0x7420 <kprobe_unwind_v8+0x7420>
    7417:      	xorl	%eax, %eax
    7419:      	movq	%rax, 0x50(%rsp)
    741e:      	xorl	%eax, %eax
    7420:      	movq	0x58(%rsp), %rcx
    7425:      	orq	$0x2, %rcx
    7429:      	movq	%rcx, 0x90(%rsp)
    7431:      	movq	0x48(%rsp), %rcx
    7436:      	cmpw	0x8(%rcx), %ax
    743a:      	jne	0x7506 <kprobe_unwind_v8+0x7506>
    7440:      	movl	$0x60, %eax
    7445:      	movl	$0x70, %ecx
    744a:      	movq	0xb0(%rsp), %rdi
    7452:      	movq	0x50(%rsp), %rdx
    7457:      	movl	$0x60, %esi
    745c:      	callq	*%rcx
    745e:      	testq	%rax, %rax
    7461:      	je	0x75bb <kprobe_unwind_v8+0x75bb>
    7467:      	movl	$0x3b, 0x70(%rsp)
    746f:      	movq	(%rip), %rdi            # 0x7476 <kprobe_unwind_v8+0x7476>
    7476:      	leaq	0x70(%rsp), %rsi
    747b:      	movl	$0x1, %eax
    7480:      	callq	*%rax
    7482:      	testq	%rax, %rax
    7485:      	jne	0x75b1 <kprobe_unwind_v8+0x75b1>
    748b:      	movq	(%rip), %rax            # 0x7492 <kprobe_unwind_v8+0x7492>
    7492:      	cmpl	$0x0, (%rax)
    7495:      	je	0x7687 <kprobe_unwind_v8+0x7687>
    749b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    74a5:      	movq	%rax, 0x26(%rsp)
    74aa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    74b4:      	movq	%rax, 0x20(%rsp)
    74b9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    74c3:      	movq	%rax, 0x18(%rsp)
    74c8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    74d2:      	movq	%rax, 0x10(%rsp)
    74d7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    74e1:      	movq	%rax, 0x8(%rsp)
    74e6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    74f0:      	movq	%rax, (%rsp)
    74f4:      	movq	%rsp, %rdi
    74f7:      	movl	$0x2e, %eax
    74fc:      	movl	$0x6, %ecx
    7501:      	jmp	0x767a <kprobe_unwind_v8+0x767a>
    7506:      	movq	(%rip), %rcx            # 0x750d <kprobe_unwind_v8+0x750d>
    750d:      	cmpl	$0x0, (%rcx)
    7510:      	je	0x7591 <kprobe_unwind_v8+0x7591>
    7512:      	movzwl	%ax, %r8d
    7516:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    7520:      	movq	%rax, 0x26(%rsp)
    7525:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    752f:      	movq	%rax, 0x20(%rsp)
    7534:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    753e:      	movq	%rax, 0x18(%rsp)
    7543:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    754d:      	movq	%rax, 0x10(%rsp)
    7552:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    755c:      	movq	%rax, 0x8(%rsp)
    7561:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    756b:      	movq	%rax, (%rsp)
    756f:      	movq	%rsp, %rdi
    7572:      	movl	$0x2e, %eax
    7577:      	movl	$0x6, %r9d
    757d:      	movl	$0x2e, %esi
    7582:      	movq	0x68(%rsp), %rdx
    7587:      	movq	0x50(%rsp), %rcx
    758c:      	xorl	%eax, %eax
    758e:      	callq	*%r9
    7591:      	movl	$0x3b, 0x70(%rsp)
    7599:      	movq	(%rip), %rdi            # 0x75a0 <kprobe_unwind_v8+0x75a0>
    75a0:      	leaq	0x70(%rsp), %rsi
    75a5:      	movl	$0x1, %eax
    75aa:      	callq	*%rax
    75ac:      	testq	%rax, %rax
    75af:      	je	0x7608 <kprobe_unwind_v8+0x7608>
    75b1:      	incq	(%rax)
    75b4:      	xorl	%ebp, %ebp
    75b6:      	jmp	0x78bb <kprobe_unwind_v8+0x78bb>
    75bb:      	movq	0x48(%rsp), %rax
    75c0:      	movzbl	0x12(%rax), %ecx
    75c4:      	xorl	%ebp, %ebp
    75c6:      	cmpq	$0x5c, %rcx
    75ca:      	ja	0x220 <kprobe_unwind_v8+0x220>
    75d0:      	movq	0x48(%rsp), %rax
    75d5:      	movzbl	0x13(%rax), %eax
    75d9:      	cmpq	$0x5c, %rax
    75dd:      	ja	0x220 <kprobe_unwind_v8+0x220>
    75e3:      	movq	0x48(%rsp), %rdx
    75e8:      	cmpb	$0x0, 0x10(%rdx)
    75ec:      	movzbl	0x11(%rdx), %r12d
    75f1:      	je	0x768e <kprobe_unwind_v8+0x768e>
    75f7:      	movq	0xb0(%rsp), %rdx
    75ff:      	movq	(%rdx,%r12), %r12
    7603:      	jmp	0x7693 <kprobe_unwind_v8+0x7693>
    7608:      	movq	(%rip), %rax            # 0x760f <kprobe_unwind_v8+0x760f>
    760f:      	cmpl	$0x0, (%rax)
    7612:      	je	0x7687 <kprobe_unwind_v8+0x7687>
    7614:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    761e:      	movq	%rax, 0x26(%rsp)
    7623:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    762d:      	movq	%rax, 0x20(%rsp)
    7632:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    763c:      	movq	%rax, 0x18(%rsp)
    7641:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    764b:      	movq	%rax, 0x10(%rsp)
    7650:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    765a:      	movq	%rax, 0x8(%rsp)
    765f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7669:      	movq	%rax, (%rsp)
    766d:      	movq	%rsp, %rdi
    7670:      	movl	$0x2e, %eax
    7675:      	movl	$0x6, %ecx
    767a:      	movl	0x70(%rsp), %edx
    767e:      	movl	$0x2e, %esi
    7683:      	xorl	%eax, %eax
    7685:      	callq	*%rcx
    7687:      	xorl	%ebp, %ebp
    7689:      	jmp	0x78bb <kprobe_unwind_v8+0x78bb>
    768e:      	addq	0x50(%rsp), %r12
    7693:      	movq	0xb0(%rsp), %rdx
    769b:      	movl	(%rdx,%rcx), %r13d
    769f:      	movq	0x48(%rsp), %rcx
    76a4:      	movzbl	0x17(%rcx), %esi
    76a8:      	movl	%esi, 0xac(%rsp)
    76af:      	movzbl	0x18(%rcx), %r15d
    76b4:      	movq	%r13, %rcx
    76b7:      	addq	%r12, %rcx
    76ba:      	movq	%rcx, 0xb8(%rsp)
    76c2:      	andl	(%rdx,%rax), %r15d
    76c6:      	movq	(%rip), %rax            # 0x76cd <kprobe_unwind_v8+0x76cd>
    76cd:      	cmpl	$0x0, (%rax)
    76d0:      	je	0x77c8 <kprobe_unwind_v8+0x77c8>
    76d6:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    76e0:      	movq	%rax, 0x20(%rsp)
    76e5:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    76ef:      	movq	%rax, 0x18(%rsp)
    76f4:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    76fe:      	movq	%rax, 0x10(%rsp)
    7703:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    770d:      	movq	%rax, 0x8(%rsp)
    7712:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    771c:      	movq	%rax, (%rsp)
    7720:      	movb	$0x0, 0x28(%rsp)
    7725:      	movq	%rsp, %rdi
    7728:      	movl	$0x29, %eax
    772d:      	movl	$0x6, %r9d
    7733:      	movl	$0x29, %esi
    7738:      	movq	0x68(%rsp), %rdx
    773d:      	movq	0x58(%rsp), %rcx
    7742:      	movq	0x50(%rsp), %r8
    7747:      	xorl	%eax, %eax
    7749:      	callq	*%r9
    774c:      	movq	(%rip), %rax            # 0x7753 <kprobe_unwind_v8+0x7753>
    7753:      	cmpl	$0x0, (%rax)
    7756:      	je	0x77c8 <kprobe_unwind_v8+0x77c8>
    7758:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    7762:      	movq	%rax, 0x1d(%rsp)
    7767:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    7771:      	movq	%rax, 0x18(%rsp)
    7776:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    7780:      	movq	%rax, 0x10(%rsp)
    7785:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    778f:      	movq	%rax, 0x8(%rsp)
    7794:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    779e:      	movq	%rax, (%rsp)
    77a2:      	movq	%rsp, %rdi
    77a5:      	movl	$0x25, %eax
    77aa:      	movl	$0x6, %r9d
    77b0:      	movl	$0x25, %esi
    77b5:      	movq	%r12, %rdx
    77b8:      	movq	0xb8(%rsp), %rcx
    77c0:      	movl	%r13d, %r8d
    77c3:      	xorl	%eax, %eax
    77c5:      	callq	*%r9
    77c8:      	movq	0xa0(%rsp), %rbp
    77d0:      	subq	%r12, %rbp
    77d3:      	jb	0x782f <kprobe_unwind_v8+0x782f>
    77d5:      	movq	0xb8(%rsp), %rax
    77dd:      	cmpq	%rax, 0xa0(%rsp)
    77e5:      	jae	0x782f <kprobe_unwind_v8+0x782f>
    77e7:      	movl	0xac(%rsp), %eax
    77ee:      	shrxl	%eax, %r15d, %eax
    77f3:      	movq	0x48(%rsp), %rcx
    77f8:      	movzbl	0x19(%rcx), %ecx
    77fc:      	movq	0x68(%rsp), %r15
    7801:      	orq	$0x4, %r15
    7805:      	movq	0x50(%rsp), %rdx
    780a:      	orq	$0x3, %rdx
    780e:      	cmpl	%ecx, %eax
    7810:      	cmoveq	%r15, %rdx
    7814:      	shll	$0x4, %r13d
    7818:      	orl	%eax, %r13d
    781b:      	shlq	$0x20, %r13
    781f:      	orq	%r13, %rbp
    7822:      	movq	%rdx, 0x90(%rsp)
    782a:      	jmp	0x78bb <kprobe_unwind_v8+0x78bb>
    782f:      	movq	(%rip), %rax            # 0x7836 <kprobe_unwind_v8+0x7836>
    7836:      	cmpl	$0x0, (%rax)
    7839:      	jne	0x784a <kprobe_unwind_v8+0x784a>
    783b:      	xorl	%ebp, %ebp
    783d:      	movzbl	0xf30(%r14), %r12d
    7845:      	jmp	0x7966 <kprobe_unwind_v8+0x7966>
    784a:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    7854:      	movq	%rax, 0x28(%rsp)
    7859:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    7863:      	movq	%rax, 0x20(%rsp)
    7868:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    7872:      	movq	%rax, 0x18(%rsp)
    7877:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    7881:      	movq	%rax, 0x10(%rsp)
    7886:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    7890:      	movq	%rax, 0x8(%rsp)
    7895:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    789f:      	movq	%rax, (%rsp)
    78a3:      	movq	%rsp, %rdi
    78a6:      	movl	$0x30, %eax
    78ab:      	movl	$0x6, %ecx
    78b0:      	xorl	%ebp, %ebp
    78b2:      	movl	$0x30, %esi
    78b7:      	xorl	%eax, %eax
    78b9:      	callq	*%rcx
    78bb:      	movzbl	0xf30(%r14), %r12d
    78c3:      	movq	(%rip), %rax            # 0x78ca <kprobe_unwind_v8+0x78ca>
    78ca:      	cmpl	$0x0, (%rax)
    78cd:      	je	0x7966 <kprobe_unwind_v8+0x7966>
    78d3:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    78dd:      	movq	%rax, 0x30(%rsp)
    78e2:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    78ec:      	movq	%rax, 0x28(%rsp)
    78f1:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    78fb:      	movq	%rax, 0x20(%rsp)
    7900:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    790a:      	movq	%rax, 0x18(%rsp)
    790f:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    7919:      	movq	%rax, 0x10(%rsp)
    791e:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    7928:      	movq	%rax, 0x8(%rsp)
    792d:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    7937:      	movq	%rax, (%rsp)
    793b:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    7943:      	movq	%rsp, %rdi
    7946:      	movl	$0x3c, %eax
    794b:      	movl	$0x6, %r8d
    7951:      	movl	$0x3c, %esi
    7956:      	movq	%rbp, %rdx
    7959:      	movq	0x90(%rsp), %rcx
    7961:      	xorl	%eax, %eax
    7963:      	callq	*%r8
    7966:      	movl	0x2c0(%r14), %eax
    796d:      	cmpq	$0x7e, %rax
    7971:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    7977:      	leal	0x1(%rax), %ecx
    797a:      	movl	%ecx, 0x2c0(%r14)
    7981:      	leaq	(%rax,%rax,2), %rax
    7985:      	movq	0x90(%rsp), %rcx
    798d:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    7995:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    799d:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    79a6:      	movb	%r12b, 0x2e1(%r14,%rax,8)
    79ae:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    79ba:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    79c5:      	movq	0xee0(%r14), %rax
    79cc:      	movq	%rsp, %rdi
    79cf:      	movl	$0x10, %ecx
    79d4:      	movl	$0x70, %r8d
    79da:      	movq	0xee0(%r14), %rdx
    79e1:      	movl	$0x10, %esi
    79e6:      	callq	*%r8
    79e9:      	testq	%rax, %rax
    79ec:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    79f2:      	movq	0xee0(%r14), %rax
    79f9:      	addq	$0x10, %rax
    79fd:      	movq	%rax, 0xed8(%r14)
    7a04:      	movq	(%rsp), %rax
    7a08:      	movq	%rax, 0xee0(%r14)
    7a0f:      	movq	0x8(%rsp), %rax
    7a14:      	movq	%rax, 0xed0(%r14)
    7a1b:      	movb	$0x1, 0xf30(%r14)
    7a23:      	movq	(%rip), %rax            # 0x7a2a <kprobe_unwind_v8+0x7a2a>
    7a2a:      	cmpl	$0x0, (%rax)
    7a2d:      	je	0x7a97 <kprobe_unwind_v8+0x7a97>
    7a2f:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    7a39:      	movq	%rax, 0x17(%rsp)
    7a3e:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    7a48:      	movq	%rax, 0x10(%rsp)
    7a4d:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    7a57:      	movq	%rax, 0x8(%rsp)
    7a5c:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    7a66:      	movq	%rax, (%rsp)
    7a6a:      	movq	%rsp, %rdi
    7a6d:      	movl	$0x1f, %eax
    7a72:      	movl	$0x6, %r9d
    7a78:      	movq	0xed0(%r14), %rdx
    7a7f:      	movq	0xed8(%r14), %rcx
    7a86:      	movq	0xee0(%r14), %r8
    7a8d:      	movl	$0x1f, %esi
    7a92:      	xorl	%eax, %eax
    7a94:      	callq	*%r9
    7a97:      	movl	$0x38, 0x70(%rsp)
    7a9f:      	movq	(%rip), %rdi            # 0x7aa6 <kprobe_unwind_v8+0x7aa6>
    7aa6:      	leaq	0x70(%rsp), %rsi
    7aab:      	movl	$0x1, %eax
    7ab0:      	callq	*%rax
    7ab2:      	testq	%rax, %rax
    7ab5:      	je	0x7abf <kprobe_unwind_v8+0x7abf>
    7ab7:      	incq	(%rax)
    7aba:      	jmp	0x7b40 <kprobe_unwind_v8+0x7b40>
    7abf:      	xorl	%eax, %eax
    7ac1:      	movq	(%rip), %rcx            # 0x7ac8 <kprobe_unwind_v8+0x7ac8>
    7ac8:      	cmpl	$0x0, (%rcx)
    7acb:      	je	0x7b49 <kprobe_unwind_v8+0x7b49>
    7acd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7ad7:      	movq	%rax, 0x26(%rsp)
    7adc:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7ae6:      	movq	%rax, 0x20(%rsp)
    7aeb:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7af5:      	movq	%rax, 0x18(%rsp)
    7afa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7b04:      	movq	%rax, 0x10(%rsp)
    7b09:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7b13:      	movq	%rax, 0x8(%rsp)
    7b18:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7b22:      	movq	%rax, (%rsp)
    7b26:      	movq	%rsp, %rdi
    7b29:      	movl	$0x2e, %eax
    7b2e:      	movl	$0x6, %ecx
    7b33:      	movl	0x70(%rsp), %edx
    7b37:      	movl	$0x2e, %esi
    7b3c:      	xorl	%eax, %eax
    7b3e:      	callq	*%rcx
    7b40:      	movq	(%rip), %rax            # 0x7b47 <kprobe_unwind_v8+0x7b47>
    7b47:      	movl	(%rax), %eax
    7b49:      	movq	0xed0(%r14), %r12
    7b50:      	testq	%r12, %r12
    7b53:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    7b59:      	testl	%eax, %eax
    7b5b:      	je	0x7be3 <kprobe_unwind_v8+0x7be3>
    7b61:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    7b6b:      	movq	%rax, 0x28(%rsp)
    7b70:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    7b7a:      	movq	%rax, 0x20(%rsp)
    7b7f:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    7b89:      	movq	%rax, 0x18(%rsp)
    7b8e:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    7b98:      	movq	%rax, 0x10(%rsp)
    7b9d:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    7ba7:      	movq	%rax, 0x8(%rsp)
    7bac:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    7bb6:      	movq	%rax, (%rsp)
    7bba:      	movb	$0x0, 0x30(%rsp)
    7bbf:      	movq	%rsp, %rdi
    7bc2:      	movl	$0x31, %eax
    7bc7:      	movl	$0x6, %ecx
    7bcc:      	movl	0x2c0(%r14), %edx
    7bd3:      	movl	$0x31, %esi
    7bd8:      	xorl	%eax, %eax
    7bda:      	callq	*%rcx
    7bdc:      	movq	0xed0(%r14), %r12
    7be3:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    7bed:      	cmpq	%rax, %r12
    7bf0:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    7bf6:      	cmpq	$0x1000, %r12           # imm = 0x1000
    7bfd:      	jb	0x285e <kprobe_unwind_v8+0x285e>
    7c03:      	movl	(%r14), %eax
    7c06:      	movl	$0x60, 0x70(%rsp)
    7c0e:      	movbel	%eax, 0x74(%rsp)
    7c14:      	movbeq	%r12, 0x78(%rsp)
    7c1b:      	movq	(%rip), %rdi            # 0x7c22 <kprobe_unwind_v8+0x7c22>
    7c22:      	leaq	0x70(%rsp), %rsi
    7c27:      	movl	$0x1, %eax
    7c2c:      	callq	*%rax
    7c2e:      	testq	%rax, %rax
    7c31:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    7c37:      	movq	0x8(%rax), %rbp
    7c3b:      	movq	%rbp, %rcx
    7c3e:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    7c48:      	andq	%rdx, %rcx
    7c4b:      	movq	%rcx, 0xf20(%r14)
    7c52:      	movq	(%rax), %rax
    7c55:      	movq	%rax, 0xf10(%r14)
    7c5c:      	shrq	$0x38, %rbp
    7c60:      	movq	%r12, %rax
    7c63:      	subq	%rcx, %rax
    7c66:      	movq	%rax, 0xf18(%r14)
    7c6d:      	movq	(%rip), %rax            # 0x7c74 <kprobe_unwind_v8+0x7c74>
    7c74:      	cmpl	$0x0, (%rax)
    7c77:      	je	0x7d83 <kprobe_unwind_v8+0x7d83>
    7c7d:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    7c87:      	movq	%rax, 0x28(%rsp)
    7c8c:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    7c96:      	movq	%rax, 0x20(%rsp)
    7c9b:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    7ca5:      	movq	%rax, 0x18(%rsp)
    7caa:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    7cb4:      	movq	%rax, 0x10(%rsp)
    7cb9:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    7cc3:      	movq	%rax, 0x8(%rsp)
    7cc8:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    7cd2:      	movq	%r13, (%rsp)
    7cd6:      	movw	$0xa, 0x30(%rsp)
    7cdd:      	movq	%rsp, %rdi
    7ce0:      	movl	$0x32, %eax
    7ce5:      	movl	$0x6, %r9d
    7ceb:      	movq	0xf10(%r14), %rcx
    7cf2:      	movl	$0x32, %esi
    7cf7:      	movq	%r12, %rdx
    7cfa:      	movl	%ebp, %r8d
    7cfd:      	xorl	%eax, %eax
    7cff:      	callq	*%r9
    7d02:      	movq	(%rip), %rax            # 0x7d09 <kprobe_unwind_v8+0x7d09>
    7d09:      	cmpl	$0x0, (%rax)
    7d0c:      	je	0x7d83 <kprobe_unwind_v8+0x7d83>
    7d0e:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    7d18:      	movq	%rax, 0x27(%rsp)
    7d1d:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    7d27:      	movq	%rax, 0x20(%rsp)
    7d2c:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    7d36:      	movq	%rax, 0x18(%rsp)
    7d3b:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    7d45:      	movq	%rax, 0x10(%rsp)
    7d4a:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    7d54:      	movq	%rax, 0x8(%rsp)
    7d59:      	movq	%r13, (%rsp)
    7d5d:      	movq	%rsp, %rdi
    7d60:      	movl	$0x2f, %eax
    7d65:      	movl	$0x6, %r8d
    7d6b:      	movq	0xf18(%r14), %rcx
    7d72:      	movq	0xf20(%r14), %rdx
    7d79:      	movl	$0x2f, %esi
    7d7e:      	xorl	%eax, %eax
    7d80:      	callq	*%r8
    7d83:      	cmpl	$0x1, %ebp
    7d86:      	jne	0x7f62 <kprobe_unwind_v8+0x7f62>
    7d8c:      	movq	0xf10(%r14), %rax
    7d93:      	movq	%rax, 0x70(%rsp)
    7d98:      	movq	0xf18(%r14), %r13
    7d9f:      	movq	(%rip), %rdi            # 0x7da6 <kprobe_unwind_v8+0x7da6>
    7da6:      	leaq	0x70(%rsp), %rsi
    7dab:      	movl	$0x1, %eax
    7db0:      	callq	*%rax
    7db2:      	movl	$0x1, %ebp
    7db7:      	testq	%rax, %rax
    7dba:      	je	0x7f62 <kprobe_unwind_v8+0x7f62>
    7dc0:      	movq	%rax, %r12
    7dc3:      	cmpq	%r13, (%rax)
    7dc6:      	ja	0x7dcf <kprobe_unwind_v8+0x7dcf>
    7dc8:      	cmpq	%r13, 0x8(%r12)
    7dcd:      	jae	0x7de5 <kprobe_unwind_v8+0x7de5>
    7dcf:      	cmpq	%r13, 0x10(%r12)
    7dd4:      	ja	0x7f62 <kprobe_unwind_v8+0x7f62>
    7dda:      	cmpq	%r13, 0x18(%r12)
    7ddf:      	jb	0x7f62 <kprobe_unwind_v8+0x7f62>
    7de5:      	movq	(%rip), %rax            # 0x7dec <kprobe_unwind_v8+0x7dec>
    7dec:      	cmpl	$0x0, (%rax)
    7def:      	je	0x7e48 <kprobe_unwind_v8+0x7e48>
    7df1:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    7dfb:      	movq	%rax, 0x16(%rsp)
    7e00:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    7e0a:      	movq	%rax, 0x10(%rsp)
    7e0f:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    7e19:      	movq	%rax, 0x8(%rsp)
    7e1e:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    7e28:      	movq	%rax, (%rsp)
    7e2c:      	movq	%rsp, %rdi
    7e2f:      	movl	$0x1e, %eax
    7e34:      	movl	$0x6, %ecx
    7e39:      	movzwl	0x20(%r12), %edx
    7e3f:      	movl	$0x1e, %esi
    7e44:      	xorl	%eax, %eax
    7e46:      	callq	*%rcx
    7e48:      	movl	0x1380(%r14), %eax
    7e4f:      	movl	0x20(%r12), %ecx
    7e54:      	btl	%ecx, %eax
    7e57:      	jae	0x7eb8 <kprobe_unwind_v8+0x7eb8>
    7e59:      	movq	(%rip), %rax            # 0x7e60 <kprobe_unwind_v8+0x7e60>
    7e60:      	cmpl	$0x0, (%rax)
    7e63:      	je	0x7f62 <kprobe_unwind_v8+0x7f62>
    7e69:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    7e73:      	movq	%rax, 0x10(%rsp)
    7e78:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    7e82:      	movq	%rax, 0x8(%rsp)
    7e87:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    7e91:      	movq	%rax, (%rsp)
    7e95:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    7e9d:      	movq	%rsp, %rdi
    7ea0:      	movl	$0x1b, %eax
    7ea5:      	movl	$0x6, %ecx
    7eaa:      	movl	$0x1b, %esi
    7eaf:      	xorl	%eax, %eax
    7eb1:      	callq	*%rcx
    7eb3:      	jmp	0x7f62 <kprobe_unwind_v8+0x7f62>
    7eb8:      	movl	$0x0, 0x64(%rsp)
    7ec0:      	movq	(%rip), %rdi            # 0x7ec7 <kprobe_unwind_v8+0x7ec7>
    7ec7:      	leaq	0x64(%rsp), %rsi
    7ecc:      	movl	$0x1, %eax
    7ed1:      	callq	*%rax
    7ed3:      	testq	%rax, %rax
    7ed6:      	je	0x7edd <kprobe_unwind_v8+0x7edd>
    7ed8:      	incq	(%rax)
    7edb:      	jmp	0x7f5c <kprobe_unwind_v8+0x7f5c>
    7edd:      	movq	(%rip), %rax            # 0x7ee4 <kprobe_unwind_v8+0x7ee4>
    7ee4:      	cmpl	$0x0, (%rax)
    7ee7:      	je	0x7f5c <kprobe_unwind_v8+0x7f5c>
    7ee9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7ef3:      	movq	%rax, 0x26(%rsp)
    7ef8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7f02:      	movq	%rax, 0x20(%rsp)
    7f07:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7f11:      	movq	%rax, 0x18(%rsp)
    7f16:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7f20:      	movq	%rax, 0x10(%rsp)
    7f25:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7f2f:      	movq	%rax, 0x8(%rsp)
    7f34:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7f3e:      	movq	%rax, (%rsp)
    7f42:      	movq	%rsp, %rdi
    7f45:      	movl	$0x2e, %eax
    7f4a:      	movl	$0x6, %ecx
    7f4f:      	movl	0x64(%rsp), %edx
    7f53:      	movl	$0x2e, %esi
    7f58:      	xorl	%eax, %eax
    7f5a:      	callq	*%rcx
    7f5c:      	movzwl	0x20(%r12), %ebp
    7f62:      	xorl	%r12d, %r12d
    7f65:      	cmpl	$0x7, %ebp
    7f68:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    7f6e:      	movq	0xed0(%r14), %rax
    7f75:      	movq	%rax, 0x68(%rsp)
    7f7a:      	movq	0xed8(%r14), %r12
    7f81:      	movq	0xee0(%r14), %r13
    7f88:      	movq	(%rip), %rax            # 0x7f8f <kprobe_unwind_v8+0x7f8f>
    7f8f:      	cmpl	$0x0, (%rax)
    7f92:      	je	0x7ff2 <kprobe_unwind_v8+0x7ff2>
    7f94:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    7f9e:      	movq	%rax, 0x17(%rsp)
    7fa3:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    7fad:      	movq	%rax, 0x10(%rsp)
    7fb2:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    7fbc:      	movq	%rax, 0x8(%rsp)
    7fc1:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    7fcb:      	movq	%rax, (%rsp)
    7fcf:      	movq	%rsp, %rdi
    7fd2:      	movl	$0x1f, %eax
    7fd7:      	movl	$0x6, %r9d
    7fdd:      	movl	$0x1f, %esi
    7fe2:      	movq	0x68(%rsp), %rdx
    7fe7:      	movq	%r12, %rcx
    7fea:      	movq	%r13, %r8
    7fed:      	xorl	%eax, %eax
    7fef:      	callq	*%r9
    7ff2:      	cmpq	%r12, %r13
    7ff5:      	jb	0x80b0 <kprobe_unwind_v8+0x80b0>
    7ffb:      	leaq	0x2000(%r12), %rax
    8003:      	cmpq	%rax, %r13
    8006:      	jae	0x80b0 <kprobe_unwind_v8+0x80b0>
    800c:      	addq	$-0x40, %r13
    8010:      	movl	$0x40, %eax
    8015:      	movl	$0x70, %ecx
    801a:      	movq	0x98(%rsp), %rdi
    8022:      	movl	$0x40, %esi
    8027:      	movq	%r13, %rdx
    802a:      	callq	*%rcx
    802c:      	testq	%rax, %rax
    802f:      	movq	(%rip), %rbp            # 0x8036 <kprobe_unwind_v8+0x8036>
    8036:      	jne	0x138 <kprobe_unwind_v8+0x138>
    803c:      	movq	0x48(%rsp), %rax
    8041:      	movzbl	0x14(%rax), %ecx
    8045:      	xorl	%ebp, %ebp
    8047:      	cmpq	$0x38, %rcx
    804b:      	ja	0x220 <kprobe_unwind_v8+0x220>
    8051:      	movq	0x48(%rsp), %rax
    8056:      	movzbl	0x15(%rax), %eax
    805a:      	cmpq	$0x38, %rax
    805e:      	ja	0x220 <kprobe_unwind_v8+0x220>
    8064:      	movq	0x48(%rsp), %rdx
    8069:      	movzbl	0x16(%rdx), %edx
    806d:      	cmpq	$0x38, %rdx
    8071:      	ja	0x220 <kprobe_unwind_v8+0x220>
    8077:      	movq	0x98(%rsp), %rsi
    807f:      	movq	(%rsi,%rcx), %rbp
    8083:      	testb	$0x1, %bpl
    8087:      	jne	0x80b8 <kprobe_unwind_v8+0x80b8>
    8089:      	shrq	%rbp
    808c:      	movq	(%rip), %rax            # 0x8093 <kprobe_unwind_v8+0x8093>
    8093:      	cmpl	$0x0, (%rax)
    8096:      	jne	0x8243 <kprobe_unwind_v8+0x8243>
    809c:      	xorl	%eax, %eax
    809e:      	movq	%rax, 0x50(%rsp)
    80a3:      	movzbl	0xf30(%r14), %r15d
    80ab:      	jmp	0x892e <kprobe_unwind_v8+0x892e>
    80b0:      	movq	%r13, %rdx
    80b3:      	jmp	0x2028 <kprobe_unwind_v8+0x2028>
    80b8:      	movq	0x98(%rsp), %r15
    80c0:      	movq	(%r15,%rdx), %r12
    80c4:      	movq	(%r15,%rax), %rdx
    80c8:      	movl	%edx, %ecx
    80ca:      	andl	$0x3, %ecx
    80cd:      	andq	$-0x4, %rdx
    80d1:      	xorl	%eax, %eax
    80d3:      	cmpl	$0x1, %ecx
    80d6:      	cmovneq	%rax, %rdx
    80da:      	movq	%rdx, 0x58(%rsp)
    80df:      	testq	%rdx, %rdx
    80e2:      	je	0x8155 <kprobe_unwind_v8+0x8155>
    80e4:      	movq	0x48(%rsp), %rax
    80e9:      	movzbl	0xc(%rax), %edx
    80ed:      	addq	0x58(%rsp), %rdx
    80f2:      	movq	%rsp, %rdi
    80f5:      	movl	$0x8, %eax
    80fa:      	movl	$0x70, %ecx
    80ff:      	movl	$0x8, %esi
    8104:      	callq	*%rcx
    8106:      	testq	%rax, %rax
    8109:      	jne	0x8153 <kprobe_unwind_v8+0x8153>
    810b:      	movq	(%rsp), %rax
    810f:      	movl	%eax, %ecx
    8111:      	andl	$0x3, %ecx
    8114:      	cmpl	$0x1, %ecx
    8117:      	jne	0x8153 <kprobe_unwind_v8+0x8153>
    8119:      	andq	$-0x4, %rax
    811d:      	je	0x8153 <kprobe_unwind_v8+0x8153>
    811f:      	movq	0x48(%rsp), %rsi
    8124:      	movzbl	0xd(%rsi), %ecx
    8128:      	addq	%rax, %rcx
    812b:      	movq	%rsp, %rdi
    812e:      	movl	$0x2, %edx
    8133:      	movl	$0x70, %r8d
    8139:      	movzbl	0xd(%rsi), %edx
    813d:      	addq	%rax, %rdx
    8140:      	movl	$0x2, %esi
    8145:      	callq	*%r8
    8148:      	testq	%rax, %rax
    814b:      	jne	0x8153 <kprobe_unwind_v8+0x8153>
    814d:      	movzwl	(%rsp), %eax
    8151:      	jmp	0x8155 <kprobe_unwind_v8+0x8155>
    8153:      	xorl	%eax, %eax
    8155:      	movq	0x48(%rsp), %rcx
    815a:      	cmpw	0x4(%rcx), %ax
    815e:      	jb	0x1c5f <kprobe_unwind_v8+0x1c5f>
    8164:      	movq	0x48(%rsp), %r8
    8169:      	cmpw	0x6(%r8), %ax
    816e:      	ja	0x494 <kprobe_unwind_v8+0x494>
    8174:      	movzbl	0xf(%r8), %edx
    8179:      	addq	0x58(%rsp), %rdx
    817e:      	movq	%rsp, %rdi
    8181:      	movl	$0x8, %eax
    8186:      	movl	$0x70, %ecx
    818b:      	movl	$0x8, %esi
    8190:      	callq	*%rcx
    8192:      	testq	%rax, %rax
    8195:      	jne	0x82a3 <kprobe_unwind_v8+0x82a3>
    819b:      	movq	(%rsp), %rcx
    819f:      	movq	%rcx, %rax
    81a2:      	movq	%rcx, 0x98(%rsp)
    81aa:      	andl	$0x3, %eax
    81ad:      	cmpl	$0x1, %eax
    81b0:      	jne	0x82a3 <kprobe_unwind_v8+0x82a3>
    81b6:      	andq	$-0x4, 0x98(%rsp)
    81bf:      	je	0x82a3 <kprobe_unwind_v8+0x82a3>
    81c5:      	movq	0x48(%rsp), %rax
    81ca:      	movzbl	0xc(%rax), %edx
    81ce:      	addq	0x98(%rsp), %rdx
    81d6:      	movq	%rsp, %rdi
    81d9:      	movl	$0x8, %eax
    81de:      	movl	$0x70, %ecx
    81e3:      	movl	$0x8, %esi
    81e8:      	callq	*%rcx
    81ea:      	testq	%rax, %rax
    81ed:      	jne	0x82ad <kprobe_unwind_v8+0x82ad>
    81f3:      	movq	(%rsp), %rax
    81f7:      	movl	%eax, %ecx
    81f9:      	andl	$0x3, %ecx
    81fc:      	cmpl	$0x1, %ecx
    81ff:      	jne	0x82ad <kprobe_unwind_v8+0x82ad>
    8205:      	andq	$-0x4, %rax
    8209:      	je	0x82ad <kprobe_unwind_v8+0x82ad>
    820f:      	movq	0x48(%rsp), %rsi
    8214:      	movzbl	0xd(%rsi), %ecx
    8218:      	addq	%rax, %rcx
    821b:      	movq	%rsp, %rdi
    821e:      	movl	$0x2, %edx
    8223:      	movl	$0x70, %r8d
    8229:      	movzbl	0xd(%rsi), %edx
    822d:      	addq	%rax, %rdx
    8230:      	movl	$0x2, %esi
    8235:      	callq	*%r8
    8238:      	testq	%rax, %rax
    823b:      	jne	0x82ad <kprobe_unwind_v8+0x82ad>
    823d:      	movzwl	(%rsp), %eax
    8241:      	jmp	0x82af <kprobe_unwind_v8+0x82af>
    8243:      	movabsq	$0xa646c25206761, %rax  # imm = 0xA646C25206761
    824d:      	movq	%rax, 0x15(%rsp)
    8252:      	movabsq	$0x20676174202c656d, %rax # imm = 0x20676174202C656D
    825c:      	movq	%rax, 0x10(%rsp)
    8261:      	movabsq	$0x6172662062757473, %rax # imm = 0x6172662062757473
    826b:      	movq	%rax, 0x8(%rsp)
    8270:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    827a:      	movq	%rax, (%rsp)
    827e:      	movq	%rsp, %rdi
    8281:      	movl	$0x1d, %eax
    8286:      	movl	$0x6, %ecx
    828b:      	xorl	%eax, %eax
    828d:      	movq	%rax, 0x50(%rsp)
    8292:      	movl	$0x1d, %esi
    8297:      	movq	%rbp, %rdx
    829a:      	xorl	%eax, %eax
    829c:      	callq	*%rcx
    829e:      	jmp	0x8886 <kprobe_unwind_v8+0x8886>
    82a3:      	xorl	%eax, %eax
    82a5:      	movq	%rax, 0x98(%rsp)
    82ad:      	xorl	%eax, %eax
    82af:      	movq	0x48(%rsp), %rcx
    82b4:      	cmpw	0xa(%rcx), %ax
    82b8:      	jne	0x998 <kprobe_unwind_v8+0x998>
    82be:      	movq	%r12, %rbp
    82c1:      	shrq	$0x20, %rbp
    82c5:      	je	0x833c <kprobe_unwind_v8+0x833c>
    82c7:      	andl	$0x1, %r12d
    82cb:      	jne	0x833c <kprobe_unwind_v8+0x833c>
    82cd:      	movq	(%rip), %rax            # 0x82d4 <kprobe_unwind_v8+0x82d4>
    82d4:      	cmpl	$0x0, (%rax)
    82d7:      	je	0x8326 <kprobe_unwind_v8+0x8326>
    82d9:      	movabsq	$0x252061746c65645f, %rax # imm = 0x252061746C65645F
    82e3:      	movq	%rax, 0x10(%rsp)
    82e8:      	movabsq	$0x65646f6365747962, %rax # imm = 0x65646F6365747962
    82f2:      	movq	%rax, 0x8(%rsp)
    82f7:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    8301:      	movq	%rax, (%rsp)
    8305:      	movl	$0xa786c, 0x18(%rsp)    # imm = 0xA786C
    830d:      	movq	%rsp, %rdi
    8310:      	movl	$0x1c, %eax
    8315:      	movl	$0x6, %ecx
    831a:      	movl	$0x1c, %esi
    831f:      	movq	%rbp, %rdx
    8322:      	xorl	%eax, %eax
    8324:      	callq	*%rcx
    8326:      	movq	0x98(%rsp), %rax
    832e:      	orq	$0x1, %rax
    8332:      	movq	%rax, 0x50(%rsp)
    8337:      	jmp	0x8886 <kprobe_unwind_v8+0x8886>
    833c:      	movq	0x48(%rsp), %rax
    8341:      	movzbl	0xe(%rax), %edx
    8345:      	addq	0x58(%rsp), %rdx
    834a:      	movq	%rsp, %rdi
    834d:      	movl	$0x8, %eax
    8352:      	movl	$0x70, %ecx
    8357:      	movl	$0x8, %esi
    835c:      	callq	*%rcx
    835e:      	testq	%rax, %rax
    8361:      	jne	0x83e9 <kprobe_unwind_v8+0x83e9>
    8367:      	movq	(%rsp), %rax
    836b:      	movq	%rax, %r15
    836e:      	andl	$0x3, %eax
    8371:      	cmpl	$0x1, %eax
    8374:      	jne	0x83e9 <kprobe_unwind_v8+0x83e9>
    8376:      	andq	$-0x4, %r15
    837a:      	je	0x83e9 <kprobe_unwind_v8+0x83e9>
    837c:      	movq	0x48(%rsp), %rax
    8381:      	movzbl	0xc(%rax), %edx
    8385:      	addq	%r15, %rdx
    8388:      	movq	%rsp, %rdi
    838b:      	movl	$0x8, %eax
    8390:      	movl	$0x70, %ecx
    8395:      	movl	$0x8, %esi
    839a:      	callq	*%rcx
    839c:      	testq	%rax, %rax
    839f:      	jne	0x83ec <kprobe_unwind_v8+0x83ec>
    83a1:      	movq	(%rsp), %rax
    83a5:      	movl	%eax, %ecx
    83a7:      	andl	$0x3, %ecx
    83aa:      	cmpl	$0x1, %ecx
    83ad:      	jne	0x83ec <kprobe_unwind_v8+0x83ec>
    83af:      	andq	$-0x4, %rax
    83b3:      	je	0x83ec <kprobe_unwind_v8+0x83ec>
    83b5:      	movq	0x48(%rsp), %rsi
    83ba:      	movzbl	0xd(%rsi), %ecx
    83be:      	addq	%rax, %rcx
    83c1:      	movq	%rsp, %rdi
    83c4:      	movl	$0x2, %edx
    83c9:      	movl	$0x70, %r8d
    83cf:      	movzbl	0xd(%rsi), %edx
    83d3:      	addq	%rax, %rdx
    83d6:      	movl	$0x2, %esi
    83db:      	callq	*%r8
    83de:      	testq	%rax, %rax
    83e1:      	jne	0x83ec <kprobe_unwind_v8+0x83ec>
    83e3:      	movzwl	(%rsp), %eax
    83e7:      	jmp	0x83ee <kprobe_unwind_v8+0x83ee>
    83e9:      	xorl	%r15d, %r15d
    83ec:      	xorl	%eax, %eax
    83ee:      	movq	0x98(%rsp), %rcx
    83f6:      	orq	$0x2, %rcx
    83fa:      	movq	%rcx, 0x50(%rsp)
    83ff:      	movq	0x48(%rsp), %rcx
    8404:      	cmpw	0x8(%rcx), %ax
    8408:      	jne	0x84d2 <kprobe_unwind_v8+0x84d2>
    840e:      	movl	$0x60, %eax
    8413:      	movl	$0x70, %ecx
    8418:      	movq	0xb0(%rsp), %rdi
    8420:      	movq	%r15, %rdx
    8423:      	movl	$0x60, %esi
    8428:      	callq	*%rcx
    842a:      	testq	%rax, %rax
    842d:      	je	0x8585 <kprobe_unwind_v8+0x8585>
    8433:      	movl	$0x3b, 0x70(%rsp)
    843b:      	movq	(%rip), %rdi            # 0x8442 <kprobe_unwind_v8+0x8442>
    8442:      	leaq	0x70(%rsp), %rsi
    8447:      	movl	$0x1, %eax
    844c:      	callq	*%rax
    844e:      	testq	%rax, %rax
    8451:      	jne	0x857b <kprobe_unwind_v8+0x857b>
    8457:      	movq	(%rip), %rax            # 0x845e <kprobe_unwind_v8+0x845e>
    845e:      	cmpl	$0x0, (%rax)
    8461:      	je	0x8657 <kprobe_unwind_v8+0x8657>
    8467:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8471:      	movq	%rax, 0x26(%rsp)
    8476:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8480:      	movq	%rax, 0x20(%rsp)
    8485:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    848f:      	movq	%rax, 0x18(%rsp)
    8494:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    849e:      	movq	%rax, 0x10(%rsp)
    84a3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    84ad:      	movq	%rax, 0x8(%rsp)
    84b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    84bc:      	movq	%rax, (%rsp)
    84c0:      	movq	%rsp, %rdi
    84c3:      	movl	$0x2e, %eax
    84c8:      	movl	$0x6, %ecx
    84cd:      	jmp	0x864a <kprobe_unwind_v8+0x864a>
    84d2:      	movq	(%rip), %rcx            # 0x84d9 <kprobe_unwind_v8+0x84d9>
    84d9:      	cmpl	$0x0, (%rcx)
    84dc:      	je	0x855b <kprobe_unwind_v8+0x855b>
    84de:      	movzwl	%ax, %r8d
    84e2:      	movabsq	$0xa7825203d2065, %rax  # imm = 0xA7825203D2065
    84ec:      	movq	%rax, 0x26(%rsp)
    84f1:      	movabsq	$0x20657079745f6564, %rax # imm = 0x20657079745F6564
    84fb:      	movq	%rax, 0x20(%rsp)
    8500:      	movabsq	$0x6f63202c786c2520, %rax # imm = 0x6F63202C786C2520
    850a:      	movq	%rax, 0x18(%rsp)
    850f:      	movabsq	$0x3d2065646f63202c, %rax # imm = 0x3D2065646F63202C
    8519:      	movq	%rax, 0x10(%rsp)
    851e:      	movabsq	$0x786c25203d20636e, %rax # imm = 0x786C25203D20636E
    8528:      	movq	%rax, 0x8(%rsp)
    852d:      	movabsq	$0x7566736a203a3876, %rax # imm = 0x7566736A203A3876
    8537:      	movq	%rax, (%rsp)
    853b:      	movq	%rsp, %rdi
    853e:      	movl	$0x2e, %eax
    8543:      	movl	$0x6, %r9d
    8549:      	movl	$0x2e, %esi
    854e:      	movq	0x58(%rsp), %rdx
    8553:      	movq	%r15, %rcx
    8556:      	xorl	%eax, %eax
    8558:      	callq	*%r9
    855b:      	movl	$0x3b, 0x70(%rsp)
    8563:      	movq	(%rip), %rdi            # 0x856a <kprobe_unwind_v8+0x856a>
    856a:      	leaq	0x70(%rsp), %rsi
    856f:      	movl	$0x1, %eax
    8574:      	callq	*%rax
    8576:      	testq	%rax, %rax
    8579:      	je	0x85d8 <kprobe_unwind_v8+0x85d8>
    857b:      	incq	(%rax)
    857e:      	xorl	%ebp, %ebp
    8580:      	jmp	0x8886 <kprobe_unwind_v8+0x8886>
    8585:      	movq	0x48(%rsp), %rax
    858a:      	movzbl	0x12(%rax), %ecx
    858e:      	xorl	%ebp, %ebp
    8590:      	cmpq	$0x5c, %rcx
    8594:      	ja	0x220 <kprobe_unwind_v8+0x220>
    859a:      	movq	0x48(%rsp), %rax
    859f:      	movzbl	0x13(%rax), %eax
    85a3:      	movl	$0x1, %r12d
    85a9:      	cmpq	$0x5c, %rax
    85ad:      	ja	0x2070 <kprobe_unwind_v8+0x2070>
    85b3:      	movq	0x48(%rsp), %rdx
    85b8:      	cmpb	$0x0, 0x10(%rdx)
    85bc:      	movzbl	0x11(%rdx), %r12d
    85c1:      	je	0x865e <kprobe_unwind_v8+0x865e>
    85c7:      	movq	0xb0(%rsp), %rdx
    85cf:      	movq	(%rdx,%r12), %r12
    85d3:      	jmp	0x8661 <kprobe_unwind_v8+0x8661>
    85d8:      	movq	(%rip), %rax            # 0x85df <kprobe_unwind_v8+0x85df>
    85df:      	cmpl	$0x0, (%rax)
    85e2:      	je	0x8657 <kprobe_unwind_v8+0x8657>
    85e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    85ee:      	movq	%rax, 0x26(%rsp)
    85f3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    85fd:      	movq	%rax, 0x20(%rsp)
    8602:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    860c:      	movq	%rax, 0x18(%rsp)
    8611:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    861b:      	movq	%rax, 0x10(%rsp)
    8620:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    862a:      	movq	%rax, 0x8(%rsp)
    862f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8639:      	movq	%rax, (%rsp)
    863d:      	movq	%rsp, %rdi
    8640:      	movl	$0x2e, %eax
    8645:      	movl	$0x6, %ecx
    864a:      	movl	0x70(%rsp), %edx
    864e:      	movl	$0x2e, %esi
    8653:      	xorl	%eax, %eax
    8655:      	callq	*%rcx
    8657:      	xorl	%ebp, %ebp
    8659:      	jmp	0x8886 <kprobe_unwind_v8+0x8886>
    865e:      	addq	%r15, %r12
    8661:      	movq	0xb0(%rsp), %rdx
    8669:      	movl	(%rdx,%rcx), %r13d
    866d:      	movq	0x48(%rsp), %rcx
    8672:      	movzbl	0x17(%rcx), %esi
    8676:      	movl	%esi, 0xa0(%rsp)
    867d:      	movzbl	0x18(%rcx), %ecx
    8681:      	movq	%r13, %rsi
    8684:      	addq	%r12, %rsi
    8687:      	movq	%rsi, 0x90(%rsp)
    868f:      	andl	(%rdx,%rax), %ecx
    8692:      	movl	%ecx, 0xb0(%rsp)
    8699:      	movq	(%rip), %rax            # 0x86a0 <kprobe_unwind_v8+0x86a0>
    86a0:      	cmpl	$0x0, (%rax)
    86a3:      	je	0x879c <kprobe_unwind_v8+0x879c>
    86a9:      	movabsq	$0xa786c25203d2065, %rax # imm = 0xA786C25203D2065
    86b3:      	movq	%rax, 0x20(%rsp)
    86b8:      	movabsq	$0x646f63202f20786c, %rax # imm = 0x646F63202F20786C
    86c2:      	movq	%rax, 0x18(%rsp)
    86c7:      	movabsq	$0x25203d2069667320, %rax # imm = 0x25203D2069667320
    86d1:      	movq	%rax, 0x10(%rsp)
    86d6:      	movabsq	$0x2f20786c25203d20, %rax # imm = 0x2F20786C25203D20
    86e0:      	movq	%rax, 0x8(%rsp)
    86e5:      	movabsq	$0x636e7566203a3876, %rax # imm = 0x636E7566203A3876
    86ef:      	movq	%rax, (%rsp)
    86f3:      	movb	$0x0, 0x28(%rsp)
    86f8:      	movq	%rsp, %rdi
    86fb:      	movl	$0x29, %eax
    8700:      	movl	$0x6, %r9d
    8706:      	movl	$0x29, %esi
    870b:      	movq	0x58(%rsp), %rdx
    8710:      	movq	0x98(%rsp), %rcx
    8718:      	movq	%r15, %r8
    871b:      	xorl	%eax, %eax
    871d:      	callq	*%r9
    8720:      	movq	(%rip), %rax            # 0x8727 <kprobe_unwind_v8+0x8727>
    8727:      	cmpl	$0x0, (%rax)
    872a:      	je	0x879c <kprobe_unwind_v8+0x879c>
    872c:      	movabsq	$0xa296425282078, %rax  # imm = 0xA296425282078
    8736:      	movq	%rax, 0x1d(%rsp)
    873b:      	movabsq	$0x2820786c252e2e78, %rax # imm = 0x2820786C252E2E78
    8745:      	movq	%rax, 0x18(%rsp)
    874a:      	movabsq	$0x6c25203a736e6f69, %rax # imm = 0x6C25203A736E6F69
    8754:      	movq	%rax, 0x10(%rsp)
    8759:      	movabsq	$0x7463757274736e69, %rax # imm = 0x7463757274736E69
    8763:      	movq	%rax, 0x8(%rsp)
    8768:      	movabsq	$0x203e2d20203a3876, %rax # imm = 0x203E2D20203A3876
    8772:      	movq	%rax, (%rsp)
    8776:      	movq	%rsp, %rdi
    8779:      	movl	$0x25, %eax
    877e:      	movl	$0x6, %r9d
    8784:      	movl	$0x25, %esi
    8789:      	movq	%r12, %rdx
    878c:      	movq	0x90(%rsp), %rcx
    8794:      	movl	%r13d, %r8d
    8797:      	xorl	%eax, %eax
    8799:      	callq	*%r9
    879c:      	movq	0x68(%rsp), %rbp
    87a1:      	subq	%r12, %rbp
    87a4:      	jb	0x87fa <kprobe_unwind_v8+0x87fa>
    87a6:      	movq	0x90(%rsp), %rax
    87ae:      	cmpq	%rax, 0x68(%rsp)
    87b3:      	jae	0x87fa <kprobe_unwind_v8+0x87fa>
    87b5:      	movl	0xa0(%rsp), %eax
    87bc:      	shrxl	%eax, 0xb0(%rsp), %eax
    87c6:      	movq	0x48(%rsp), %rcx
    87cb:      	movzbl	0x19(%rcx), %ecx
    87cf:      	movq	0x58(%rsp), %rdx
    87d4:      	orq	$0x4, %rdx
    87d8:      	orq	$0x3, %r15
    87dc:      	cmpl	%ecx, %eax
    87de:      	cmoveq	%rdx, %r15
    87e2:      	shll	$0x4, %r13d
    87e6:      	orl	%eax, %r13d
    87e9:      	shlq	$0x20, %r13
    87ed:      	orq	%r13, %rbp
    87f0:      	movq	%r15, 0x50(%rsp)
    87f5:      	jmp	0x8886 <kprobe_unwind_v8+0x8886>
    87fa:      	movq	(%rip), %rax            # 0x8801 <kprobe_unwind_v8+0x8801>
    8801:      	cmpl	$0x0, (%rax)
    8804:      	jne	0x8815 <kprobe_unwind_v8+0x8815>
    8806:      	xorl	%ebp, %ebp
    8808:      	movzbl	0xf30(%r14), %r15d
    8810:      	jmp	0x892e <kprobe_unwind_v8+0x892e>
    8815:      	movabsq	$0xa29656d617266, %rax  # imm = 0xA29656D617266
    881f:      	movq	%rax, 0x28(%rsp)
    8824:      	movabsq	$0x2074736f6d706f74, %rax # imm = 0x2074736F6D706F74
    882e:      	movq	%rax, 0x20(%rsp)
    8833:      	movabsq	$0x20746f6e2820626f, %rax # imm = 0x20746F6E2820626F
    883d:      	movq	%rax, 0x18(%rsp)
    8842:      	movabsq	$0x6c622065646f6320, %rax # imm = 0x6C622065646F6320
    884c:      	movq	%rax, 0x10(%rsp)
    8851:      	movabsq	$0x6564697374756f20, %rax # imm = 0x6564697374756F20
    885b:      	movq	%rax, 0x8(%rsp)
    8860:      	movabsq	$0x3e2d2d20203a3876, %rax # imm = 0x3E2D2D20203A3876
    886a:      	movq	%rax, (%rsp)
    886e:      	movq	%rsp, %rdi
    8871:      	movl	$0x30, %eax
    8876:      	movl	$0x6, %ecx
    887b:      	xorl	%ebp, %ebp
    887d:      	movl	$0x30, %esi
    8882:      	xorl	%eax, %eax
    8884:      	callq	*%rcx
    8886:      	movzbl	0xf30(%r14), %r15d
    888e:      	movq	(%rip), %rax            # 0x8895 <kprobe_unwind_v8+0x8895>
    8895:      	cmpl	$0x0, (%rax)
    8898:      	je	0x892e <kprobe_unwind_v8+0x892e>
    889e:      	movabsq	$0x253d657079745f64, %rax # imm = 0x253D657079745F64
    88a8:      	movq	%rax, 0x30(%rsp)
    88ad:      	movabsq	$0x6e615f7265746e69, %rax # imm = 0x6E615F7265746E69
    88b7:      	movq	%rax, 0x28(%rsp)
    88bc:      	movabsq	$0x6f70202c786c253d, %rax # imm = 0x6F70202C786C253D
    88c6:      	movq	%rax, 0x20(%rsp)
    88cb:      	movabsq	$0x72656b72616d5f72, %rax # imm = 0x72656B72616D5F72
    88d5:      	movq	%rax, 0x18(%rsp)
    88da:      	movabsq	$0x6f5f61746c656420, %rax # imm = 0x6F5F61746C656420
    88e4:      	movq	%rax, 0x10(%rsp)
    88e9:      	movabsq	$0x656d617266203876, %rax # imm = 0x656D617266203876
    88f3:      	movq	%rax, 0x8(%rsp)
    88f8:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8902:      	movq	%rax, (%rsp)
    8906:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    890e:      	movq	%rsp, %rdi
    8911:      	movl	$0x3c, %eax
    8916:      	movl	$0x6, %r8d
    891c:      	movl	$0x3c, %esi
    8921:      	movq	%rbp, %rdx
    8924:      	movq	0x50(%rsp), %rcx
    8929:      	xorl	%eax, %eax
    892b:      	callq	*%r8
    892e:      	movl	0x2c0(%r14), %eax
    8935:      	cmpq	$0x7e, %rax
    8939:      	ja	0x27d <kprobe_unwind_v8+0x27d>
    893f:      	leal	0x1(%rax), %ecx
    8942:      	movl	%ecx, 0x2c0(%r14)
    8949:      	leaq	(%rax,%rax,2), %rax
    894d:      	movq	0x50(%rsp), %rcx
    8952:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    895a:      	movq	%rbp, 0x2d8(%r14,%rax,8)
    8962:      	movb	$0x8, 0x2e0(%r14,%rax,8)
    896b:      	movb	%r15b, 0x2e1(%r14,%rax,8)
    8973:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    897f:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    898a:      	movq	0xee0(%r14), %rax
    8991:      	movq	%rsp, %rdi
    8994:      	movl	$0x10, %ecx
    8999:      	movl	$0x70, %r8d
    899f:      	movq	0xee0(%r14), %rdx
    89a6:      	movl	$0x10, %esi
    89ab:      	callq	*%r8
    89ae:      	testq	%rax, %rax
    89b1:      	jne	0x3d2 <kprobe_unwind_v8+0x3d2>
    89b7:      	movq	0xee0(%r14), %rax
    89be:      	addq	$0x10, %rax
    89c2:      	movq	%rax, 0xed8(%r14)
    89c9:      	movq	(%rsp), %rax
    89cd:      	movq	%rax, 0xee0(%r14)
    89d4:      	movq	0x8(%rsp), %rax
    89d9:      	movq	%rax, 0xed0(%r14)
    89e0:      	movb	$0x1, 0xf30(%r14)
    89e8:      	movq	(%rip), %rax            # 0x89ef <kprobe_unwind_v8+0x89ef>
    89ef:      	cmpl	$0x0, (%rax)
    89f2:      	je	0x8a5c <kprobe_unwind_v8+0x8a5c>
    89f4:      	movabsq	$0xa786c25203a70, %rax  # imm = 0xA786C25203A70
    89fe:      	movq	%rax, 0x17(%rsp)
    8a03:      	movabsq	$0x7066202c786c2520, %rax # imm = 0x7066202C786C2520
    8a0d:      	movq	%rax, 0x10(%rsp)
    8a12:      	movabsq	$0x3a7073202c786c25, %rax # imm = 0x3A7073202C786C25
    8a1c:      	movq	%rax, 0x8(%rsp)
    8a21:      	movabsq	$0x203a6370203a3876, %rax # imm = 0x203A6370203A3876
    8a2b:      	movq	%rax, (%rsp)
    8a2f:      	movq	%rsp, %rdi
    8a32:      	movl	$0x1f, %eax
    8a37:      	movl	$0x6, %r9d
    8a3d:      	movq	0xed0(%r14), %rdx
    8a44:      	movq	0xed8(%r14), %rcx
    8a4b:      	movq	0xee0(%r14), %r8
    8a52:      	movl	$0x1f, %esi
    8a57:      	xorl	%eax, %eax
    8a59:      	callq	*%r9
    8a5c:      	movl	$0x38, 0x70(%rsp)
    8a64:      	movq	(%rip), %rdi            # 0x8a6b <kprobe_unwind_v8+0x8a6b>
    8a6b:      	leaq	0x70(%rsp), %rsi
    8a70:      	movl	$0x1, %eax
    8a75:      	callq	*%rax
    8a77:      	testq	%rax, %rax
    8a7a:      	je	0x8a84 <kprobe_unwind_v8+0x8a84>
    8a7c:      	incq	(%rax)
    8a7f:      	jmp	0x8b05 <kprobe_unwind_v8+0x8b05>
    8a84:      	xorl	%eax, %eax
    8a86:      	movq	(%rip), %rcx            # 0x8a8d <kprobe_unwind_v8+0x8a8d>
    8a8d:      	cmpl	$0x0, (%rcx)
    8a90:      	je	0x8b0e <kprobe_unwind_v8+0x8b0e>
    8a92:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8a9c:      	movq	%rax, 0x26(%rsp)
    8aa1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8aab:      	movq	%rax, 0x20(%rsp)
    8ab0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8aba:      	movq	%rax, 0x18(%rsp)
    8abf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8ac9:      	movq	%rax, 0x10(%rsp)
    8ace:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8ad8:      	movq	%rax, 0x8(%rsp)
    8add:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8ae7:      	movq	%rax, (%rsp)
    8aeb:      	movq	%rsp, %rdi
    8aee:      	movl	$0x2e, %eax
    8af3:      	movl	$0x6, %ecx
    8af8:      	movl	0x70(%rsp), %edx
    8afc:      	movl	$0x2e, %esi
    8b01:      	xorl	%eax, %eax
    8b03:      	callq	*%rcx
    8b05:      	movq	(%rip), %rax            # 0x8b0c <kprobe_unwind_v8+0x8b0c>
    8b0c:      	movl	(%rax), %eax
    8b0e:      	movq	0xed0(%r14), %r12
    8b15:      	testq	%r12, %r12
    8b18:      	je	0x8e7c <kprobe_unwind_v8+0x8e7c>
    8b1e:      	testl	%eax, %eax
    8b20:      	je	0x8ba8 <kprobe_unwind_v8+0x8ba8>
    8b26:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    8b30:      	movq	%rax, 0x28(%rsp)
    8b35:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    8b3f:      	movq	%rax, 0x20(%rsp)
    8b44:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    8b4e:      	movq	%rax, 0x18(%rsp)
    8b53:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    8b5d:      	movq	%rax, 0x10(%rsp)
    8b62:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    8b6c:      	movq	%rax, 0x8(%rsp)
    8b71:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    8b7b:      	movq	%rax, (%rsp)
    8b7f:      	movb	$0x0, 0x30(%rsp)
    8b84:      	movq	%rsp, %rdi
    8b87:      	movl	$0x31, %eax
    8b8c:      	movl	$0x6, %ecx
    8b91:      	movl	0x2c0(%r14), %edx
    8b98:      	movl	$0x31, %esi
    8b9d:      	xorl	%eax, %eax
    8b9f:      	callq	*%rcx
    8ba1:      	movq	0xed0(%r14), %r12
    8ba8:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    8bb2:      	cmpq	%rax, %r12
    8bb5:      	ja	0x1db3 <kprobe_unwind_v8+0x1db3>
    8bbb:      	cmpq	$0x1000, %r12           # imm = 0x1000
    8bc2:      	jb	0x285e <kprobe_unwind_v8+0x285e>
    8bc8:      	movl	(%r14), %eax
    8bcb:      	movl	$0x60, 0x70(%rsp)
    8bd3:      	movbel	%eax, 0x74(%rsp)
    8bd9:      	movbeq	%r12, 0x78(%rsp)
    8be0:      	movq	(%rip), %rdi            # 0x8be7 <kprobe_unwind_v8+0x8be7>
    8be7:      	leaq	0x70(%rsp), %rsi
    8bec:      	movl	$0x1, %eax
    8bf1:      	callq	*%rax
    8bf3:      	testq	%rax, %rax
    8bf6:      	je	0x8e96 <kprobe_unwind_v8+0x8e96>
    8bfc:      	movq	0x8(%rax), %rbp
    8c00:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    8c0a:      	andq	%rbp, %rcx
    8c0d:      	movq	%rcx, 0xf20(%r14)
    8c14:      	movq	(%rax), %rax
    8c17:      	movq	%rax, 0xf10(%r14)
    8c1e:      	shrq	$0x38, %rbp
    8c22:      	movq	%r12, %rax
    8c25:      	subq	%rcx, %rax
    8c28:      	movq	%rax, 0xf18(%r14)
    8c2f:      	movq	(%rip), %rax            # 0x8c36 <kprobe_unwind_v8+0x8c36>
    8c36:      	cmpl	$0x0, (%rax)
    8c39:      	je	0x8d45 <kprobe_unwind_v8+0x8d45>
    8c3f:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    8c49:      	movq	%rax, 0x28(%rsp)
    8c4e:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    8c58:      	movq	%rax, 0x20(%rsp)
    8c5d:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    8c67:      	movq	%rax, 0x18(%rsp)
    8c6c:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    8c76:      	movq	%rax, 0x10(%rsp)
    8c7b:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    8c85:      	movq	%rax, 0x8(%rsp)
    8c8a:      	movabsq	$0x6365732074786554, %r15 # imm = 0x6365732074786554
    8c94:      	movq	%r15, (%rsp)
    8c98:      	movw	$0xa, 0x30(%rsp)
    8c9f:      	movq	%rsp, %rdi
    8ca2:      	movl	$0x32, %eax
    8ca7:      	movl	$0x6, %r9d
    8cad:      	movq	0xf10(%r14), %rcx
    8cb4:      	movl	$0x32, %esi
    8cb9:      	movq	%r12, %rdx
    8cbc:      	movl	%ebp, %r8d
    8cbf:      	xorl	%eax, %eax
    8cc1:      	callq	*%r9
    8cc4:      	movq	(%rip), %rax            # 0x8ccb <kprobe_unwind_v8+0x8ccb>
    8ccb:      	cmpl	$0x0, (%rax)
    8cce:      	je	0x8d45 <kprobe_unwind_v8+0x8d45>
    8cd0:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    8cda:      	movq	%rax, 0x27(%rsp)
    8cdf:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    8ce9:      	movq	%rax, 0x20(%rsp)
    8cee:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    8cf8:      	movq	%rax, 0x18(%rsp)
    8cfd:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    8d07:      	movq	%rax, 0x10(%rsp)
    8d0c:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    8d16:      	movq	%rax, 0x8(%rsp)
    8d1b:      	movq	%r15, (%rsp)
    8d1f:      	movq	%rsp, %rdi
    8d22:      	movl	$0x2f, %eax
    8d27:      	movl	$0x6, %r8d
    8d2d:      	movq	0xf18(%r14), %rcx
    8d34:      	movq	0xf20(%r14), %rdx
    8d3b:      	movl	$0x2f, %esi
    8d40:      	xorl	%eax, %eax
    8d42:      	callq	*%r8
    8d45:      	xorl	%r12d, %r12d
    8d48:      	cmpl	$0x1, %ebp
    8d4b:      	jne	0x2070 <kprobe_unwind_v8+0x2070>
    8d51:      	movq	0xf10(%r14), %rax
    8d58:      	movq	%rax, 0x70(%rsp)
    8d5d:      	movq	0xf18(%r14), %r13
    8d64:      	movq	(%rip), %rdi            # 0x8d6b <kprobe_unwind_v8+0x8d6b>
    8d6b:      	leaq	0x70(%rsp), %rsi
    8d70:      	movl	$0x1, %eax
    8d75:      	callq	*%rax
    8d77:      	movl	$0x1, %ebp
    8d7c:      	testq	%rax, %rax
    8d7f:      	je	0x2070 <kprobe_unwind_v8+0x2070>
    8d85:      	movq	%rax, %r15
    8d88:      	cmpq	%r13, (%rax)
    8d8b:      	ja	0x8d93 <kprobe_unwind_v8+0x8d93>
    8d8d:      	cmpq	%r13, 0x8(%r15)
    8d91:      	jae	0x8da7 <kprobe_unwind_v8+0x8da7>
    8d93:      	cmpq	%r13, 0x10(%r15)
    8d97:      	ja	0x2070 <kprobe_unwind_v8+0x2070>
    8d9d:      	cmpq	%r13, 0x18(%r15)
    8da1:      	jb	0x2070 <kprobe_unwind_v8+0x2070>
    8da7:      	movq	(%rip), %rax            # 0x8dae <kprobe_unwind_v8+0x8dae>
    8dae:      	cmpl	$0x0, (%rax)
    8db1:      	je	0x8e09 <kprobe_unwind_v8+0x8e09>
    8db3:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    8dbd:      	movq	%rax, 0x16(%rsp)
    8dc2:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    8dcc:      	movq	%rax, 0x10(%rsp)
    8dd1:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    8ddb:      	movq	%rax, 0x8(%rsp)
    8de0:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    8dea:      	movq	%rax, (%rsp)
    8dee:      	movq	%rsp, %rdi
    8df1:      	movl	$0x1e, %eax
    8df6:      	movl	$0x6, %ecx
    8dfb:      	movzwl	0x20(%r15), %edx
    8e00:      	movl	$0x1e, %esi
    8e05:      	xorl	%eax, %eax
    8e07:      	callq	*%rcx
    8e09:      	movl	0x1380(%r14), %eax
    8e10:      	movl	0x20(%r15), %ecx
    8e14:      	btl	%ecx, %eax
    8e17:      	jae	0x8fc0 <kprobe_unwind_v8+0x8fc0>
    8e1d:      	movq	(%rip), %rax            # 0x8e24 <kprobe_unwind_v8+0x8e24>
    8e24:      	cmpl	$0x0, (%rax)
    8e27:      	je	0x2070 <kprobe_unwind_v8+0x2070>
    8e2d:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    8e37:      	movq	%rax, 0x10(%rsp)
    8e3c:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    8e46:      	movq	%rax, 0x8(%rsp)
    8e4b:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    8e55:      	movq	%rax, (%rsp)
    8e59:      	movl	$0xa656e, 0x17(%rsp)    # imm = 0xA656E
    8e61:      	movq	%rsp, %rdi
    8e64:      	movl	$0x1b, %eax
    8e69:      	movl	$0x6, %ecx
    8e6e:      	movl	$0x1b, %esi
    8e73:      	xorl	%eax, %eax
    8e75:      	callq	*%rcx
    8e77:      	jmp	0x2070 <kprobe_unwind_v8+0x2070>
    8e7c:      	testl	%eax, %eax
    8e7e:      	jne	0x8ebc <kprobe_unwind_v8+0x8ebc>
    8e80:      	movl	$0x1, 0xf28(%r14)
    8e8b:      	movl	$0xfad, %r12d           # imm = 0xFAD
    8e91:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
    8e96:      	movq	(%rip), %rax            # 0x8e9d <kprobe_unwind_v8+0x8e9d>
    8e9d:      	cmpl	$0x0, (%rax)
    8ea0:      	jne	0x8f35 <kprobe_unwind_v8+0x8f35>
    8ea6:      	movl	$0xc, 0xf28(%r14)
    8eb1:      	movl	$0xfac, %r12d           # imm = 0xFAC
    8eb7:      	jmp	0x206e <kprobe_unwind_v8+0x206e>
    8ebc:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    8ec6:      	movq	%rax, 0x28(%rsp)
    8ecb:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    8ed5:      	movq	%rax, 0x20(%rsp)
    8eda:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    8ee4:      	movq	%rax, 0x18(%rsp)
    8ee9:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    8ef3:      	movq	%rax, 0x10(%rsp)
    8ef8:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    8f02:      	movq	%rax, 0x8(%rsp)
    8f07:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    8f11:      	movq	%rax, (%rsp)
    8f15:      	movb	$0x0, 0x30(%rsp)
    8f1a:      	movq	%rsp, %rdi
    8f1d:      	movl	$0x31, %eax
    8f22:      	movl	$0x6, %ecx
    8f27:      	movl	$0x31, %esi
    8f2c:      	xorl	%eax, %eax
    8f2e:      	callq	*%rcx
    8f30:      	jmp	0x8e80 <kprobe_unwind_v8+0x8e80>
    8f35:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    8f3f:      	movq	%rax, 0x30(%rsp)
    8f44:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    8f4e:      	movq	%rax, 0x28(%rsp)
    8f53:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    8f5d:      	movq	%rax, 0x20(%rsp)
    8f62:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    8f6c:      	movq	%rax, 0x18(%rsp)
    8f71:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    8f7b:      	movq	%rax, 0x10(%rsp)
    8f80:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    8f8a:      	movq	%rax, 0x8(%rsp)
    8f8f:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    8f99:      	movq	%rax, (%rsp)
    8f9d:      	movb	$0x0, 0x38(%rsp)
    8fa2:      	movq	%rsp, %rdi
    8fa5:      	movl	$0x39, %eax
    8faa:      	movl	$0x6, %ecx
    8faf:      	movl	$0x39, %esi
    8fb4:      	movq	%r12, %rdx
    8fb7:      	xorl	%eax, %eax
    8fb9:      	callq	*%rcx
    8fbb:      	jmp	0x8ea6 <kprobe_unwind_v8+0x8ea6>
    8fc0:      	movl	$0x0, 0x64(%rsp)
    8fc8:      	movq	(%rip), %rdi            # 0x8fcf <kprobe_unwind_v8+0x8fcf>
    8fcf:      	leaq	0x64(%rsp), %rsi
    8fd4:      	movl	$0x1, %eax
    8fd9:      	callq	*%rax
    8fdb:      	testq	%rax, %rax
    8fde:      	je	0x8fed <kprobe_unwind_v8+0x8fed>
    8fe0:      	incq	(%rax)
    8fe3:      	movzwl	0x20(%r15), %ebp
    8fe8:      	jmp	0x2070 <kprobe_unwind_v8+0x2070>
    8fed:      	movq	(%rip), %rax            # 0x8ff4 <kprobe_unwind_v8+0x8ff4>
    8ff4:      	cmpl	$0x0, (%rax)
    8ff7:      	je	0x906c <kprobe_unwind_v8+0x906c>
    8ff9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    9003:      	movq	%rax, 0x26(%rsp)
    9008:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    9012:      	movq	%rax, 0x20(%rsp)
    9017:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9021:      	movq	%rax, 0x18(%rsp)
    9026:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9030:      	movq	%rax, 0x10(%rsp)
    9035:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    903f:      	movq	%rax, 0x8(%rsp)
    9044:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    904e:      	movq	%rax, (%rsp)
    9052:      	movq	%rsp, %rdi
    9055:      	movl	$0x2e, %eax
    905a:      	movl	$0x6, %ecx
    905f:      	movl	0x64(%rsp), %edx
    9063:      	movl	$0x2e, %esi
    9068:      	xorl	%eax, %eax
    906a:      	callq	*%rcx
    906c:      	movzwl	0x20(%r15), %ebp
    9071:      	jmp	0x2070 <kprobe_unwind_v8+0x2070>
