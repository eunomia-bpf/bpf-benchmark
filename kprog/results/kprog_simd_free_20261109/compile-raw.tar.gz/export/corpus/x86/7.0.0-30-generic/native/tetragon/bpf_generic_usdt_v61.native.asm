
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_usdt_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	movl	$0x1, %eax
       5:      	cmpl	$0x9, %edi
       8:      	ja	0x82 <extract_arg_depth+0x82>
       a:      	pushq	%r14
       c:      	pushq	%rbx
       d:      	pushq	%rax
       e:      	movq	(%rsi), %r8
      11:      	movl	%edi, %r9d
      14:      	cmpw	$0x0, 0x6(%r8,%r9,8)
      1b:      	je	0x7b <extract_arg_depth+0x7b>
      1d:      	movq	0x8(%rsi), %rcx
      21:      	movl	(%r8,%r9,8), %edx
      25:      	addq	(%rcx), %rdx
      28:      	movq	%rdx, (%rcx)
      2b:      	xorl	%eax, %eax
      2d:      	cmpw	$0x0, 0x4(%r8,%r9,8)
      34:      	je	0x7b <extract_arg_depth+0x7b>
      36:      	movl	%edi, %ebx
      38:      	cmpb	$0x0, 0x10(%rsi)
      3c:      	je	0x4a <extract_arg_depth+0x4a>
      3e:      	movl	$0x8, %edi
      43:      	movl	$0x94, %eax
      48:      	jmp	0x54 <extract_arg_depth+0x54>
      4a:      	movl	$0x8, %edi
      4f:      	movl	$0x4, %eax
      54:      	movq	%rsi, %r14
      57:      	movq	0x8(%rsi), %rdi
      5b:      	movq	(%rdi), %rdx
      5e:      	movl	$0x8, %esi
      63:      	callq	*%rax
      65:      	testl	%eax, %eax
      67:      	movl	$0x0, %eax
      6c:      	jns	0x7b <extract_arg_depth+0x7b>
      6e:      	incl	%ebx
      70:      	movq	0x18(%r14), %rax
      74:      	movl	%ebx, (%rax)
      76:      	movl	$0x1, %eax
      7b:      	addq	$0x8, %rsp
      7f:      	popq	%rbx
      80:      	popq	%r14
      82:      	retq
      83:      	nopw	%cs:(%rax,%rax)

0000000000000090 <do_bytes>:
      90:      	pushq	%rbp
      91:      	pushq	%r15
      93:      	pushq	%r14
      95:      	pushq	%r13
      97:      	pushq	%r12
      99:      	pushq	%rbx
      9a:      	pushq	%rax
      9b:      	movq	%rcx, %rbx
      9e:      	movq	%rdx, %r14
      a1:      	movq	%rsi, %r15
      a4:      	movq	%rdi, %r12
      a7:      	callq	0x2f0 <__do_bytes>
      ac:      	testl	%eax, %eax
      ae:      	js	0x257 <do_bytes+0x1c7>
      b4:      	movl	%eax, %r13d
      b7:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
      be:      	movq	%rbx, %rcx
      c1:      	subq	%r13, %rcx
      c4:      	je	0x2de <do_bytes+0x24e>
      ca:      	leaq	(%r14,%r13), %rdx
      ce:      	movq	%r12, %rdi
      d1:      	movq	%r15, %rsi
      d4:      	callq	0x2f0 <__do_bytes>
      d9:      	testl	%eax, %eax
      db:      	js	0x257 <do_bytes+0x1c7>
      e1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
      e6:      	movq	%rax, %rbp
      e9:      	addq	%r13, %rbp
      ec:      	movq	%rbx, %rcx
      ef:      	subq	%rbp, %rcx
      f2:      	je	0x2de <do_bytes+0x24e>
      f8:      	leaq	(%r14,%rbp), %rdx
      fc:      	movq	%r12, %rdi
      ff:      	movq	%r15, %rsi
     102:      	callq	0x2f0 <__do_bytes>
     107:      	testl	%eax, %eax
     109:      	js	0x257 <do_bytes+0x1c7>
     10f:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     114:      	movq	%rax, %r13
     117:      	addq	%rbp, %r13
     11a:      	movq	%rbx, %rcx
     11d:      	subq	%r13, %rcx
     120:      	je	0x2de <do_bytes+0x24e>
     126:      	leaq	(%r14,%r13), %rdx
     12a:      	movq	%r12, %rdi
     12d:      	movq	%r15, %rsi
     130:      	callq	0x2f0 <__do_bytes>
     135:      	testl	%eax, %eax
     137:      	js	0x257 <do_bytes+0x1c7>
     13d:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     142:      	movq	%rax, %rbp
     145:      	addq	%r13, %rbp
     148:      	movq	%rbx, %rcx
     14b:      	subq	%rbp, %rcx
     14e:      	je	0x2de <do_bytes+0x24e>
     154:      	leaq	(%r14,%rbp), %rdx
     158:      	movq	%r12, %rdi
     15b:      	movq	%r15, %rsi
     15e:      	callq	0x2f0 <__do_bytes>
     163:      	testl	%eax, %eax
     165:      	js	0x257 <do_bytes+0x1c7>
     16b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     170:      	movq	%rax, %r13
     173:      	addq	%rbp, %r13
     176:      	movq	%rbx, %rcx
     179:      	subq	%r13, %rcx
     17c:      	je	0x2de <do_bytes+0x24e>
     182:      	leaq	(%r14,%r13), %rdx
     186:      	movq	%r12, %rdi
     189:      	movq	%r15, %rsi
     18c:      	callq	0x2f0 <__do_bytes>
     191:      	testl	%eax, %eax
     193:      	js	0x257 <do_bytes+0x1c7>
     199:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     19e:      	movq	%rax, %rbp
     1a1:      	addq	%r13, %rbp
     1a4:      	movq	%rbx, %rcx
     1a7:      	subq	%rbp, %rcx
     1aa:      	je	0x2de <do_bytes+0x24e>
     1b0:      	leaq	(%r14,%rbp), %rdx
     1b4:      	movq	%r12, %rdi
     1b7:      	movq	%r15, %rsi
     1ba:      	callq	0x2f0 <__do_bytes>
     1bf:      	testl	%eax, %eax
     1c1:      	js	0x257 <do_bytes+0x1c7>
     1c7:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     1cc:      	movq	%rax, %r13
     1cf:      	addq	%rbp, %r13
     1d2:      	movq	%rbx, %rcx
     1d5:      	subq	%r13, %rcx
     1d8:      	je	0x2de <do_bytes+0x24e>
     1de:      	leaq	(%r14,%r13), %rdx
     1e2:      	movq	%r12, %rdi
     1e5:      	movq	%r15, %rsi
     1e8:      	callq	0x2f0 <__do_bytes>
     1ed:      	testl	%eax, %eax
     1ef:      	js	0x257 <do_bytes+0x1c7>
     1f1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     1f6:      	movq	%rax, %rbp
     1f9:      	addq	%r13, %rbp
     1fc:      	movq	%rbx, %rcx
     1ff:      	subq	%rbp, %rcx
     202:      	je	0x2de <do_bytes+0x24e>
     208:      	leaq	(%r14,%rbp), %rdx
     20c:      	movq	%r12, %rdi
     20f:      	movq	%r15, %rsi
     212:      	callq	0x2f0 <__do_bytes>
     217:      	testl	%eax, %eax
     219:      	js	0x257 <do_bytes+0x1c7>
     21b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     220:      	movq	%rax, %r13
     223:      	addq	%rbp, %r13
     226:      	movq	%rbx, %rcx
     229:      	subq	%r13, %rcx
     22c:      	je	0x2de <do_bytes+0x24e>
     232:      	addq	%r13, %r14
     235:      	movq	%r12, %rdi
     238:      	movq	%r15, %rsi
     23b:      	movq	%r14, %rdx
     23e:      	callq	0x2f0 <__do_bytes>
     243:      	testl	%eax, %eax
     245:      	js	0x257 <do_bytes+0x1c7>
     247:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     24c:      	addq	%r13, %rax
     24f:      	movq	%rax, %rbx
     252:      	jmp	0x2de <do_bytes+0x24e>
     257:      	movslq	%eax, %rbx
     25a:      	movl	$0x0, 0x4(%rsp)
     262:      	movq	(%rip), %rdi            # 0x269 <do_bytes+0x1d9>
     269:      	leaq	0x4(%rsp), %rsi
     26e:      	movl	$0x1, %eax
     273:      	callq	*%rax
     275:      	testq	%rax, %rax
     278:      	je	0x2de <do_bytes+0x24e>
     27a:      	cmpq	$-0xc, %rbx
     27e:      	jg	0x29a <do_bytes+0x20a>
     280:      	cmpq	$-0x1c, %rbx
     284:      	je	0x2b4 <do_bytes+0x224>
     286:      	cmpq	$-0x16, %rbx
     28a:      	je	0x2cc <do_bytes+0x23c>
     28c:      	cmpq	$-0x10, %rbx
     290:      	jne	0x2c4 <do_bytes+0x234>
     292:      	addq	$0x558, %rax            # imm = 0x558
     298:      	jmp	0x2da <do_bytes+0x24a>
     29a:      	cmpq	$-0xb, %rbx
     29e:      	je	0x2bc <do_bytes+0x22c>
     2a0:      	cmpq	$-0x7, %rbx
     2a4:      	je	0x2d4 <do_bytes+0x244>
     2a6:      	cmpq	$-0x2, %rbx
     2aa:      	jne	0x2c4 <do_bytes+0x234>
     2ac:      	addq	$0x548, %rax            # imm = 0x548
     2b2:      	jmp	0x2da <do_bytes+0x24a>
     2b4:      	addq	$0x568, %rax            # imm = 0x568
     2ba:      	jmp	0x2da <do_bytes+0x24a>
     2bc:      	addq	$0x570, %rax            # imm = 0x570
     2c2:      	jmp	0x2da <do_bytes+0x24a>
     2c4:      	addq	$0x540, %rax            # imm = 0x540
     2ca:      	jmp	0x2da <do_bytes+0x24a>
     2cc:      	addq	$0x560, %rax            # imm = 0x560
     2d2:      	jmp	0x2da <do_bytes+0x24a>
     2d4:      	addq	$0x550, %rax            # imm = 0x550
     2da:      	lock
     2db:      	incq	(%rax)
     2de:      	movq	%rbx, %rax
     2e1:      	addq	$0x8, %rsp
     2e5:      	popq	%rbx
     2e6:      	popq	%r12
     2e8:      	popq	%r13
     2ea:      	popq	%r14
     2ec:      	popq	%r15
     2ee:      	popq	%rbp
     2ef:      	retq

00000000000002f0 <__do_bytes>:
     2f0:      	pushq	%r15
     2f2:      	pushq	%r14
     2f4:      	pushq	%r12
     2f6:      	pushq	%rbx
     2f7:      	pushq	%rax
     2f8:      	testq	%rcx, %rcx
     2fb:      	js	0x379 <__do_bytes+0x89>
     2fd:      	movq	%rsi, %r14
     300:      	movq	%rdi, %r12
     303:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     30a:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     30f:      	cmovbq	%rcx, %rbx
     313:      	leaq	0x20(%rsi), %rdi
     317:      	movl	$0x4, %eax
     31c:      	movl	%ebx, %esi
     31e:      	callq	*%rax
     320:      	testl	%eax, %eax
     322:      	js	0x39e <__do_bytes+0xae>
     324:      	leal	0x20(%rbx), %r15d
     328:      	movl	%r15d, 0x4(%r14)
     32c:      	movl	$0x0, 0x4(%rsp)
     334:      	movq	(%rip), %rdi            # 0x33b <__do_bytes+0x4b>
     33b:      	leaq	0x4(%rsp), %rsi
     340:      	movl	$0x1, %eax
     345:      	callq	*%rax
     347:      	testq	%rax, %rax
     34a:      	je	0x382 <__do_bytes+0x92>
     34c:      	cmpb	$0x0, 0x28(%rax)
     350:      	je	0x382 <__do_bytes+0x92>
     352:      	movq	(%rip), %rsi            # 0x359 <__do_bytes+0x69>
     359:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     35e:      	movl	$0x19, %eax
     363:      	movq	%r12, %rdi
     366:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     36b:      	movq	%r14, %rcx
     36e:      	movq	%r15, %r8
     371:      	callq	*%rax
     373:      	testl	%eax, %eax
     375:      	js	0x39e <__do_bytes+0xae>
     377:      	jmp	0x3a1 <__do_bytes+0xb1>
     379:      	movq	$-0x1, %rbx
     380:      	jmp	0x3a1 <__do_bytes+0xb1>
     382:      	movq	(%rip), %rdi            # 0x389 <__do_bytes+0x99>
     389:      	xorl	%ecx, %ecx
     38b:      	movl	$0x82, %eax
     390:      	movq	%r14, %rsi
     393:      	movq	%r15, %rdx
     396:      	xorl	%ecx, %ecx
     398:      	callq	*%rax
     39a:      	testl	%eax, %eax
     39c:      	jns	0x3a1 <__do_bytes+0xb1>
     39e:      	movslq	%eax, %rbx
     3a1:      	movq	%rbx, %rax
     3a4:      	addq	$0x8, %rsp
     3a8:      	popq	%rbx
     3a9:      	popq	%r12
     3ab:      	popq	%r14
     3ad:      	popq	%r15
     3af:      	retq

00000000000003b0 <filter_64ty>:
     3b0:      	pushq	%rax
     3b1:      	movl	0x4(%rdi), %ecx
     3b4:      	xorl	%eax, %eax
     3b6:      	cmpq	$0x20, %rcx
     3ba:      	ja	0x3f5 <filter_64ty+0x45>
     3bc:      	movl	$0x101e, %edx           # imm = 0x101E
     3c1:      	btq	%rcx, %rdx
     3c5:      	jae	0x3ce <filter_64ty+0x1e>
     3c7:      	callq	0x4f0 <filter_64ty_selector_val>
     3cc:      	popq	%rcx
     3cd:      	retq
     3ce:      	movl	$0xc00, %edx            # imm = 0xC00
     3d3:      	btq	%rcx, %rdx
     3d7:      	jb	0x3f0 <filter_64ty+0x40>
     3d9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     3e3:      	btq	%rcx, %rdx
     3e7:      	jae	0x3f5 <filter_64ty+0x45>
     3e9:      	callq	0x7b0 <filter_64ty_range>
     3ee:      	popq	%rcx
     3ef:      	retq
     3f0:      	callq	0x730 <filter_64ty_map>
     3f5:      	popq	%rcx
     3f6:      	retq
     3f7:      	nopw	(%rax,%rax)

0000000000000400 <filter_32ty>:
     400:      	pushq	%rax
     401:      	movl	0x4(%rdi), %ecx
     404:      	xorl	%eax, %eax
     406:      	cmpq	$0x20, %rcx
     40a:      	ja	0x445 <filter_32ty+0x45>
     40c:      	movl	$0x101e, %edx           # imm = 0x101E
     411:      	btq	%rcx, %rdx
     415:      	jae	0x41e <filter_32ty+0x1e>
     417:      	callq	0x990 <filter_32ty_selector_val>
     41c:      	popq	%rcx
     41d:      	retq
     41e:      	movl	$0xc00, %edx            # imm = 0xC00
     423:      	btq	%rcx, %rdx
     427:      	jb	0x440 <filter_32ty+0x40>
     429:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     433:      	btq	%rcx, %rdx
     437:      	jae	0x445 <filter_32ty+0x45>
     439:      	callq	0xc40 <filter_32ty_range>
     43e:      	popq	%rcx
     43f:      	retq
     440:      	callq	0xbb0 <filter_32ty_map>
     445:      	popq	%rcx
     446:      	retq
     447:      	nopw	(%rax,%rax)

0000000000000450 <filter_16ty>:
     450:      	pushq	%rax
     451:      	movl	0x4(%rdi), %ecx
     454:      	xorl	%eax, %eax
     456:      	cmpq	$0x20, %rcx
     45a:      	ja	0x495 <filter_16ty+0x45>
     45c:      	movl	$0x101e, %edx           # imm = 0x101E
     461:      	btq	%rcx, %rdx
     465:      	jae	0x46e <filter_16ty+0x1e>
     467:      	callq	0xe00 <filter_16ty_selector_val>
     46c:      	popq	%rcx
     46d:      	retq
     46e:      	movl	$0xc00, %edx            # imm = 0xC00
     473:      	btq	%rcx, %rdx
     477:      	jb	0x490 <filter_16ty+0x40>
     479:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     483:      	btq	%rcx, %rdx
     487:      	jae	0x495 <filter_16ty+0x45>
     489:      	callq	0x10b0 <filter_16ty_range>
     48e:      	popq	%rcx
     48f:      	retq
     490:      	callq	0x1020 <filter_16ty_map>
     495:      	popq	%rcx
     496:      	retq
     497:      	nopw	(%rax,%rax)

00000000000004a0 <filter_8ty>:
     4a0:      	pushq	%rax
     4a1:      	movl	0x4(%rdi), %ecx
     4a4:      	xorl	%eax, %eax
     4a6:      	cmpq	$0x20, %rcx
     4aa:      	ja	0x4e5 <filter_8ty+0x45>
     4ac:      	movl	$0x101e, %edx           # imm = 0x101E
     4b1:      	btq	%rcx, %rdx
     4b5:      	jae	0x4be <filter_8ty+0x1e>
     4b7:      	callq	0x1270 <filter_8ty_selector_val>
     4bc:      	popq	%rcx
     4bd:      	retq
     4be:      	movl	$0xc00, %edx            # imm = 0xC00
     4c3:      	btq	%rcx, %rdx
     4c7:      	jb	0x4e0 <filter_8ty+0x40>
     4c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     4d3:      	btq	%rcx, %rdx
     4d7:      	jae	0x4e5 <filter_8ty+0x45>
     4d9:      	callq	0x1520 <filter_8ty_range>
     4de:      	popq	%rcx
     4df:      	retq
     4e0:      	callq	0x1490 <filter_8ty_map>
     4e5:      	popq	%rcx
     4e6:      	retq
     4e7:      	nopw	(%rax,%rax)

00000000000004f0 <filter_64ty_selector_val>:
     4f0:      	movl	0x4(%rdi), %ecx
     4f3:      	movl	$0x1, %eax
     4f8:      	cmpq	$0x25, %rcx
     4fc:      	ja	0x574 <filter_64ty_selector_val+0x84>
     4fe:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     508:      	btq	%rcx, %rdx
     50c:      	jae	0x50f <filter_64ty_selector_val+0x1f>
     50e:      	retq
     50f:      	movl	$0x18, %edx
     514:      	btq	%rcx, %rdx
     518:      	jae	0x530 <filter_64ty_selector_val+0x40>
     51a:      	movq	(%rsi), %rdx
     51d:      	cmpq	0x10(%rdi), %rdx
     521:      	jne	0x652 <filter_64ty_selector_val+0x162>
     527:      	xorl	%eax, %eax
     529:      	cmpl	$0x3, %ecx
     52c:      	sete	%al
     52f:      	retq
     530:      	cmpq	$0xc, %rcx
     534:      	jne	0x574 <filter_64ty_selector_val+0x84>
     536:      	movq	(%rsi), %rcx
     539:      	testq	%rcx, 0x10(%rdi)
     53d:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     53f:      	movl	0x8(%rdi), %edx
     542:      	cmpl	$0x11, %edx
     545:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     54b:      	testq	%rcx, 0x18(%rdi)
     54f:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     551:      	cmpl	$0x19, %edx
     554:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     55a:      	testq	%rcx, 0x20(%rdi)
     55e:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     560:      	cmpl	$0x21, %edx
     563:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     569:      	testq	%rcx, 0x28(%rdi)
     56d:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     56f:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     574:      	cmpl	$0x1, %ecx
     577:      	je	0x5ea <filter_64ty_selector_val+0xfa>
     579:      	cmpl	$0x2, %ecx
     57c:      	jne	0x71f <filter_64ty_selector_val+0x22f>
     582:      	movl	0xc(%rdi), %ecx
     585:      	cmpl	$0xc, %ecx
     588:      	ja	0x6e2 <filter_64ty_selector_val+0x1f2>
     58e:      	movl	$0x1402, %edx           # imm = 0x1402
     593:      	btl	%ecx, %edx
     596:      	jae	0x6e2 <filter_64ty_selector_val+0x1f2>
     59c:      	movq	(%rsi), %rcx
     59f:      	cmpq	0x10(%rdi), %rcx
     5a3:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5a9:      	movl	0x8(%rdi), %edx
     5ac:      	cmpl	$0x11, %edx
     5af:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5b5:      	cmpq	0x18(%rdi), %rcx
     5b9:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5bf:      	cmpl	$0x19, %edx
     5c2:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5c8:      	cmpq	0x20(%rdi), %rcx
     5cc:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5d2:      	cmpl	$0x21, %edx
     5d5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5db:      	cmpq	0x28(%rdi), %rcx
     5df:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5e5:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     5ea:      	movl	0xc(%rdi), %ecx
     5ed:      	cmpl	$0xc, %ecx
     5f0:      	ja	0x6a3 <filter_64ty_selector_val+0x1b3>
     5f6:      	movl	$0x1402, %edx           # imm = 0x1402
     5fb:      	btl	%ecx, %edx
     5fe:      	jae	0x6a3 <filter_64ty_selector_val+0x1b3>
     604:      	movq	(%rsi), %rcx
     607:      	cmpq	0x10(%rdi), %rcx
     60b:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     611:      	movl	0x8(%rdi), %edx
     614:      	cmpl	$0x11, %edx
     617:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     61d:      	cmpq	0x18(%rdi), %rcx
     621:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     627:      	cmpl	$0x19, %edx
     62a:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     630:      	cmpq	0x20(%rdi), %rcx
     634:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     63a:      	cmpl	$0x21, %edx
     63d:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     643:      	cmpq	0x28(%rdi), %rcx
     647:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     64d:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     652:      	movl	0x8(%rdi), %esi
     655:      	cmpl	$0x11, %esi
     658:      	jb	0x682 <filter_64ty_selector_val+0x192>
     65a:      	cmpq	0x18(%rdi), %rdx
     65e:      	je	0x527 <filter_64ty_selector_val+0x37>
     664:      	cmpl	$0x19, %esi
     667:      	jb	0x682 <filter_64ty_selector_val+0x192>
     669:      	cmpq	0x20(%rdi), %rdx
     66d:      	je	0x527 <filter_64ty_selector_val+0x37>
     673:      	cmpl	$0x21, %esi
     676:      	jb	0x682 <filter_64ty_selector_val+0x192>
     678:      	cmpq	0x28(%rdi), %rdx
     67c:      	je	0x527 <filter_64ty_selector_val+0x37>
     682:      	cmpl	$0x25, %ecx
     685:      	ja	0x71f <filter_64ty_selector_val+0x22f>
     68b:      	movl	%ecx, %ecx
     68d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     697:      	btq	%rcx, %rdx
     69b:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     6a1:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     6a3:      	movq	(%rsi), %rcx
     6a6:      	cmpq	0x10(%rdi), %rcx
     6aa:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6b0:      	movl	0x8(%rdi), %edx
     6b3:      	cmpl	$0x11, %edx
     6b6:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6b8:      	cmpq	0x18(%rdi), %rcx
     6bc:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6c2:      	cmpl	$0x19, %edx
     6c5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6c7:      	cmpq	0x20(%rdi), %rcx
     6cb:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6d1:      	cmpl	$0x21, %edx
     6d4:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6d6:      	cmpq	0x28(%rdi), %rcx
     6da:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6e0:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     6e2:      	movq	(%rsi), %rcx
     6e5:      	cmpq	0x10(%rdi), %rcx
     6e9:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     6ef:      	movl	0x8(%rdi), %edx
     6f2:      	cmpl	$0x11, %edx
     6f5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6f7:      	cmpq	0x18(%rdi), %rcx
     6fb:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     701:      	cmpl	$0x19, %edx
     704:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     706:      	cmpq	0x20(%rdi), %rcx
     70a:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     710:      	cmpl	$0x21, %edx
     713:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     715:      	cmpq	0x28(%rdi), %rcx
     719:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     71f:      	xorl	%eax, %eax
     721:      	retq
     722:      	nopw	%cs:(%rax,%rax)

0000000000000730 <filter_64ty_map>:
     730:      	pushq	%r14
     732:      	pushq	%rbx
     733:      	subq	$0x18, %rsp
     737:      	movq	%rsi, %r14
     73a:      	movq	%rdi, %rbx
     73d:      	movzbl	0x10(%rdi), %eax
     741:      	movl	%eax, 0xc(%rsp)
     745:      	movq	(%rip), %rdi            # 0x74c <filter_64ty_map+0x1c>
     74c:      	leaq	0xc(%rsp), %rsi
     751:      	movl	$0x1, %eax
     756:      	callq	*%rax
     758:      	testq	%rax, %rax
     75b:      	je	0x789 <filter_64ty_map+0x59>
     75d:      	movq	%rax, %rdi
     760:      	movq	(%r14), %rax
     763:      	movq	%rax, 0x10(%rsp)
     768:      	leaq	0x10(%rsp), %rsi
     76d:      	movl	$0x1, %eax
     772:      	callq	*%rax
     774:      	movl	0x4(%rbx), %ecx
     777:      	cmpl	$0xb, %ecx
     77a:      	je	0x793 <filter_64ty_map+0x63>
     77c:      	cmpl	$0xa, %ecx
     77f:      	jne	0x79b <filter_64ty_map+0x6b>
     781:      	testq	%rax, %rax
     784:      	setne	%al
     787:      	jmp	0x79d <filter_64ty_map+0x6d>
     789:      	xorl	%eax, %eax
     78b:      	addq	$0x18, %rsp
     78f:      	popq	%rbx
     790:      	popq	%r14
     792:      	retq
     793:      	testq	%rax, %rax
     796:      	sete	%al
     799:      	jmp	0x79d <filter_64ty_map+0x6d>
     79b:      	xorl	%eax, %eax
     79d:      	movzbl	%al, %eax
     7a0:      	addq	$0x18, %rsp
     7a4:      	popq	%rbx
     7a5:      	popq	%r14
     7a7:      	retq
     7a8:      	nopl	(%rax,%rax)

00000000000007b0 <filter_64ty_range>:
     7b0:      	movl	0x4(%rdi), %ecx
     7b3:      	movl	0xc(%rdi), %eax
     7b6:      	cmpl	$0xc, %eax
     7b9:      	ja	0x8b0 <filter_64ty_range+0x100>
     7bf:      	movl	$0x1402, %edx           # imm = 0x1402
     7c4:      	btl	%eax, %edx
     7c7:      	jae	0x8b0 <filter_64ty_range+0x100>
     7cd:      	movq	(%rsi), %rsi
     7d0:      	cmpl	$0x1f, %ecx
     7d3:      	jne	0x843 <filter_64ty_range+0x93>
     7d5:      	movl	$0x1, %eax
     7da:      	cmpq	%rsi, 0x10(%rdi)
     7de:      	jg	0x7ea <filter_64ty_range+0x3a>
     7e0:      	cmpq	0x18(%rdi), %rsi
     7e4:      	jle	0x8c9 <filter_64ty_range+0x119>
     7ea:      	movl	0x8(%rdi), %edx
     7ed:      	cmpl	$0x19, %edx
     7f0:      	jb	0x977 <filter_64ty_range+0x1c7>
     7f6:      	cmpq	%rsi, 0x20(%rdi)
     7fa:      	jg	0x806 <filter_64ty_range+0x56>
     7fc:      	cmpq	0x28(%rdi), %rsi
     800:      	jle	0x8c9 <filter_64ty_range+0x119>
     806:      	cmpl	$0x29, %edx
     809:      	jb	0x977 <filter_64ty_range+0x1c7>
     80f:      	cmpq	%rsi, 0x30(%rdi)
     813:      	jg	0x81f <filter_64ty_range+0x6f>
     815:      	cmpq	0x38(%rdi), %rsi
     819:      	jle	0x8c9 <filter_64ty_range+0x119>
     81f:      	cmpl	$0x39, %edx
     822:      	jb	0x977 <filter_64ty_range+0x1c7>
     828:      	xorl	%edx, %edx
     82a:      	cmpq	%rsi, 0x40(%rdi)
     82e:      	jg	0x979 <filter_64ty_range+0x1c9>
     834:      	cmpq	0x48(%rdi), %rsi
     838:      	jle	0x8c9 <filter_64ty_range+0x119>
     83e:      	jmp	0x979 <filter_64ty_range+0x1c9>
     843:      	movl	0x8(%rdi), %eax
     846:      	cmpq	%rsi, 0x10(%rdi)
     84a:      	setle	%r8b
     84e:      	cmpq	0x18(%rdi), %rsi
     852:      	setle	%dl
     855:      	andb	%r8b, %dl
     858:      	cmpl	$0x19, %eax
     85b:      	jb	0x979 <filter_64ty_range+0x1c9>
     861:      	cmpq	%rsi, 0x20(%rdi)
     865:      	setle	%r8b
     869:      	cmpq	0x28(%rdi), %rsi
     86d:      	setle	%r9b
     871:      	andb	%r8b, %r9b
     874:      	orb	%r9b, %dl
     877:      	cmpl	$0x29, %eax
     87a:      	jb	0x979 <filter_64ty_range+0x1c9>
     880:      	cmpq	%rsi, 0x30(%rdi)
     884:      	setle	%r8b
     888:      	cmpq	0x38(%rdi), %rsi
     88c:      	setle	%r9b
     890:      	andb	%r8b, %r9b
     893:      	orb	%r9b, %dl
     896:      	cmpl	$0x39, %eax
     899:      	jb	0x979 <filter_64ty_range+0x1c9>
     89f:      	cmpq	%rsi, 0x40(%rdi)
     8a3:      	setle	%al
     8a6:      	cmpq	0x48(%rdi), %rsi
     8aa:      	setle	%sil
     8ae:      	jmp	0x92d <filter_64ty_range+0x17d>
     8b0:      	movq	(%rsi), %rsi
     8b3:      	cmpl	$0x1f, %ecx
     8b6:      	jne	0x8ca <filter_64ty_range+0x11a>
     8b8:      	movl	$0x1, %eax
     8bd:      	cmpq	%rsi, 0x10(%rdi)
     8c1:      	ja	0x935 <filter_64ty_range+0x185>
     8c3:      	cmpq	0x18(%rdi), %rsi
     8c7:      	ja	0x935 <filter_64ty_range+0x185>
     8c9:      	retq
     8ca:      	movl	0x8(%rdi), %eax
     8cd:      	cmpq	%rsi, 0x10(%rdi)
     8d1:      	setbe	%r8b
     8d5:      	cmpq	0x18(%rdi), %rsi
     8d9:      	setbe	%dl
     8dc:      	andb	%r8b, %dl
     8df:      	cmpl	$0x19, %eax
     8e2:      	jb	0x979 <filter_64ty_range+0x1c9>
     8e8:      	cmpq	%rsi, 0x20(%rdi)
     8ec:      	setbe	%r8b
     8f0:      	cmpq	0x28(%rdi), %rsi
     8f4:      	setbe	%r9b
     8f8:      	andb	%r8b, %r9b
     8fb:      	orb	%r9b, %dl
     8fe:      	cmpl	$0x29, %eax
     901:      	jb	0x979 <filter_64ty_range+0x1c9>
     903:      	cmpq	%rsi, 0x30(%rdi)
     907:      	setbe	%r8b
     90b:      	cmpq	0x38(%rdi), %rsi
     90f:      	setbe	%r9b
     913:      	andb	%r8b, %r9b
     916:      	orb	%r9b, %dl
     919:      	cmpl	$0x39, %eax
     91c:      	jb	0x979 <filter_64ty_range+0x1c9>
     91e:      	cmpq	%rsi, 0x40(%rdi)
     922:      	setbe	%al
     925:      	cmpq	0x48(%rdi), %rsi
     929:      	setbe	%sil
     92d:      	andb	%al, %sil
     930:      	orb	%sil, %dl
     933:      	jmp	0x979 <filter_64ty_range+0x1c9>
     935:      	movl	0x8(%rdi), %edx
     938:      	cmpl	$0x19, %edx
     93b:      	jb	0x977 <filter_64ty_range+0x1c7>
     93d:      	cmpq	%rsi, 0x20(%rdi)
     941:      	ja	0x949 <filter_64ty_range+0x199>
     943:      	cmpq	0x28(%rdi), %rsi
     947:      	jbe	0x8c9 <filter_64ty_range+0x119>
     949:      	cmpl	$0x29, %edx
     94c:      	jb	0x977 <filter_64ty_range+0x1c7>
     94e:      	cmpq	%rsi, 0x30(%rdi)
     952:      	ja	0x95e <filter_64ty_range+0x1ae>
     954:      	cmpq	0x38(%rdi), %rsi
     958:      	jbe	0x8c9 <filter_64ty_range+0x119>
     95e:      	cmpl	$0x39, %edx
     961:      	jb	0x977 <filter_64ty_range+0x1c7>
     963:      	xorl	%edx, %edx
     965:      	cmpq	%rsi, 0x40(%rdi)
     969:      	ja	0x979 <filter_64ty_range+0x1c9>
     96b:      	cmpq	0x48(%rdi), %rsi
     96f:      	jbe	0x8c9 <filter_64ty_range+0x119>
     975:      	jmp	0x979 <filter_64ty_range+0x1c9>
     977:      	xorl	%edx, %edx
     979:      	cmpl	$0x20, %ecx
     97c:      	sete	%al
     97f:      	xorb	$0x1, %dl
     982:      	andb	%al, %dl
     984:      	movzbl	%dl, %eax
     987:      	retq
     988:      	nopl	(%rax,%rax)

0000000000000990 <filter_32ty_selector_val>:
     990:      	movl	0x4(%rdi), %ecx
     993:      	movl	$0x1, %eax
     998:      	cmpq	$0x25, %rcx
     99c:      	ja	0xa0d <filter_32ty_selector_val+0x7d>
     99e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     9a8:      	btq	%rcx, %rdx
     9ac:      	jae	0x9af <filter_32ty_selector_val+0x1f>
     9ae:      	retq
     9af:      	movl	$0x18, %edx
     9b4:      	btq	%rcx, %rdx
     9b8:      	jae	0x9ce <filter_32ty_selector_val+0x3e>
     9ba:      	movl	(%rsi), %edx
     9bc:      	cmpl	0x10(%rdi), %edx
     9bf:      	jne	0xae1 <filter_32ty_selector_val+0x151>
     9c5:      	xorl	%eax, %eax
     9c7:      	cmpl	$0x3, %ecx
     9ca:      	sete	%al
     9cd:      	retq
     9ce:      	cmpq	$0xc, %rcx
     9d2:      	jne	0xa0d <filter_32ty_selector_val+0x7d>
     9d4:      	movl	(%rsi), %ecx
     9d6:      	testl	%ecx, 0x10(%rdi)
     9d9:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9db:      	movl	0x8(%rdi), %edx
     9de:      	cmpl	$0xd, %edx
     9e1:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     9e7:      	testl	%ecx, 0x14(%rdi)
     9ea:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9ec:      	cmpl	$0x11, %edx
     9ef:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     9f5:      	testl	%ecx, 0x18(%rdi)
     9f8:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9fa:      	cmpl	$0x15, %edx
     9fd:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a03:      	testl	%ecx, 0x1c(%rdi)
     a06:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     a08:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     a0d:      	cmpl	$0x1, %ecx
     a10:      	je	0xa7e <filter_32ty_selector_val+0xee>
     a12:      	cmpl	$0x2, %ecx
     a15:      	jne	0xba1 <filter_32ty_selector_val+0x211>
     a1b:      	movl	0xc(%rdi), %ecx
     a1e:      	cmpl	$0xc, %ecx
     a21:      	ja	0xb69 <filter_32ty_selector_val+0x1d9>
     a27:      	movl	$0x1402, %edx           # imm = 0x1402
     a2c:      	btl	%ecx, %edx
     a2f:      	jae	0xb69 <filter_32ty_selector_val+0x1d9>
     a35:      	movl	(%rsi), %ecx
     a37:      	cmpl	0x10(%rdi), %ecx
     a3a:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a40:      	movl	0x8(%rdi), %edx
     a43:      	cmpl	$0xd, %edx
     a46:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a4c:      	cmpl	0x14(%rdi), %ecx
     a4f:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a55:      	cmpl	$0x11, %edx
     a58:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a5e:      	cmpl	0x18(%rdi), %ecx
     a61:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a67:      	cmpl	$0x15, %edx
     a6a:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a70:      	cmpl	0x1c(%rdi), %ecx
     a73:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a79:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     a7e:      	movl	0xc(%rdi), %ecx
     a81:      	cmpl	$0xc, %ecx
     a84:      	ja	0xb2f <filter_32ty_selector_val+0x19f>
     a8a:      	movl	$0x1402, %edx           # imm = 0x1402
     a8f:      	btl	%ecx, %edx
     a92:      	jae	0xb2f <filter_32ty_selector_val+0x19f>
     a98:      	movl	(%rsi), %ecx
     a9a:      	cmpl	0x10(%rdi), %ecx
     a9d:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     aa3:      	movl	0x8(%rdi), %edx
     aa6:      	cmpl	$0xd, %edx
     aa9:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     aaf:      	cmpl	0x14(%rdi), %ecx
     ab2:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     ab8:      	cmpl	$0x11, %edx
     abb:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     ac1:      	cmpl	0x18(%rdi), %ecx
     ac4:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     aca:      	cmpl	$0x15, %edx
     acd:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     ad3:      	cmpl	0x1c(%rdi), %ecx
     ad6:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     adc:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     ae1:      	movl	0x8(%rdi), %esi
     ae4:      	cmpl	$0xd, %esi
     ae7:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     ae9:      	cmpl	0x14(%rdi), %edx
     aec:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     af2:      	cmpl	$0x11, %esi
     af5:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     af7:      	cmpl	0x18(%rdi), %edx
     afa:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     b00:      	cmpl	$0x15, %esi
     b03:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     b05:      	cmpl	0x1c(%rdi), %edx
     b08:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     b0e:      	cmpl	$0x25, %ecx
     b11:      	ja	0xba1 <filter_32ty_selector_val+0x211>
     b17:      	movl	%ecx, %ecx
     b19:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     b23:      	btq	%rcx, %rdx
     b27:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b2d:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     b2f:      	movl	(%rsi), %ecx
     b31:      	cmpl	0x10(%rdi), %ecx
     b34:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b3a:      	movl	0x8(%rdi), %edx
     b3d:      	cmpl	$0xd, %edx
     b40:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b42:      	cmpl	0x14(%rdi), %ecx
     b45:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b4b:      	cmpl	$0x11, %edx
     b4e:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b50:      	cmpl	0x18(%rdi), %ecx
     b53:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b59:      	cmpl	$0x15, %edx
     b5c:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b5e:      	cmpl	0x1c(%rdi), %ecx
     b61:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b67:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     b69:      	movl	(%rsi), %ecx
     b6b:      	cmpl	0x10(%rdi), %ecx
     b6e:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b74:      	movl	0x8(%rdi), %edx
     b77:      	cmpl	$0xd, %edx
     b7a:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b7c:      	cmpl	0x14(%rdi), %ecx
     b7f:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b85:      	cmpl	$0x11, %edx
     b88:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b8a:      	cmpl	0x18(%rdi), %ecx
     b8d:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b93:      	cmpl	$0x15, %edx
     b96:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b98:      	cmpl	0x1c(%rdi), %ecx
     b9b:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     ba1:      	xorl	%eax, %eax
     ba3:      	retq
     ba4:      	nopw	%cs:(%rax,%rax)

0000000000000bb0 <filter_32ty_map>:
     bb0:      	pushq	%r14
     bb2:      	pushq	%rbx
     bb3:      	subq	$0x18, %rsp
     bb7:      	movq	%rsi, %r14
     bba:      	movq	%rdi, %rbx
     bbd:      	movzbl	0x10(%rdi), %eax
     bc1:      	movl	%eax, 0xc(%rsp)
     bc5:      	movq	(%rip), %rdi            # 0xbcc <filter_32ty_map+0x1c>
     bcc:      	leaq	0xc(%rsp), %rsi
     bd1:      	movl	$0x1, %eax
     bd6:      	callq	*%rax
     bd8:      	testq	%rax, %rax
     bdb:      	je	0xc10 <filter_32ty_map+0x60>
     bdd:      	movq	%rax, %rdi
     be0:      	movl	(%r14), %eax
     be3:      	movq	%rax, 0x10(%rsp)
     be8:      	leaq	0x10(%rsp), %rsi
     bed:      	movl	$0x1, %eax
     bf2:      	callq	*%rax
     bf4:      	movl	0x4(%rbx), %edx
     bf7:      	xorl	%ecx, %ecx
     bf9:      	cmpl	$0x1d, %edx
     bfc:      	ja	0xc2a <filter_32ty_map+0x7a>
     bfe:      	movl	$0x30038400, %esi       # imm = 0x30038400
     c03:      	btl	%edx, %esi
     c06:      	jae	0xc1a <filter_32ty_map+0x6a>
     c08:      	testq	%rax, %rax
     c0b:      	setne	%cl
     c0e:      	jmp	0xc2a <filter_32ty_map+0x7a>
     c10:      	xorl	%eax, %eax
     c12:      	addq	$0x18, %rsp
     c16:      	popq	%rbx
     c17:      	popq	%r14
     c19:      	retq
     c1a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     c1f:      	btl	%edx, %esi
     c22:      	jae	0xc2a <filter_32ty_map+0x7a>
     c24:      	testq	%rax, %rax
     c27:      	sete	%cl
     c2a:      	movzbl	%cl, %eax
     c2d:      	addq	$0x18, %rsp
     c31:      	popq	%rbx
     c32:      	popq	%r14
     c34:      	retq
     c35:      	nopw	%cs:(%rax,%rax)

0000000000000c40 <filter_32ty_range>:
     c40:      	movl	0x4(%rdi), %ecx
     c43:      	movl	0xc(%rdi), %eax
     c46:      	cmpl	$0xc, %eax
     c49:      	ja	0xd2f <filter_32ty_range+0xef>
     c4f:      	movl	$0x1402, %edx           # imm = 0x1402
     c54:      	btl	%eax, %edx
     c57:      	jae	0xd2f <filter_32ty_range+0xef>
     c5d:      	movl	(%rsi), %esi
     c5f:      	cmpl	$0x1f, %ecx
     c62:      	jne	0xcca <filter_32ty_range+0x8a>
     c64:      	movl	$0x1, %eax
     c69:      	cmpl	%esi, 0x10(%rdi)
     c6c:      	jg	0xc77 <filter_32ty_range+0x37>
     c6e:      	cmpl	0x14(%rdi), %esi
     c71:      	jle	0xd45 <filter_32ty_range+0x105>
     c77:      	movl	0x8(%rdi), %edx
     c7a:      	cmpl	$0x11, %edx
     c7d:      	jb	0xde5 <filter_32ty_range+0x1a5>
     c83:      	cmpl	%esi, 0x18(%rdi)
     c86:      	jg	0xc91 <filter_32ty_range+0x51>
     c88:      	cmpl	0x1c(%rdi), %esi
     c8b:      	jle	0xd45 <filter_32ty_range+0x105>
     c91:      	cmpl	$0x19, %edx
     c94:      	jb	0xde5 <filter_32ty_range+0x1a5>
     c9a:      	cmpl	%esi, 0x20(%rdi)
     c9d:      	jg	0xca8 <filter_32ty_range+0x68>
     c9f:      	cmpl	0x24(%rdi), %esi
     ca2:      	jle	0xd45 <filter_32ty_range+0x105>
     ca8:      	cmpl	$0x21, %edx
     cab:      	jb	0xde5 <filter_32ty_range+0x1a5>
     cb1:      	xorl	%edx, %edx
     cb3:      	cmpl	%esi, 0x28(%rdi)
     cb6:      	jg	0xde7 <filter_32ty_range+0x1a7>
     cbc:      	cmpl	0x2c(%rdi), %esi
     cbf:      	jle	0xd45 <filter_32ty_range+0x105>
     cc5:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     cca:      	movl	0x8(%rdi), %eax
     ccd:      	cmpl	%esi, 0x10(%rdi)
     cd0:      	setle	%r8b
     cd4:      	cmpl	0x14(%rdi), %esi
     cd7:      	setle	%dl
     cda:      	andb	%r8b, %dl
     cdd:      	cmpl	$0x11, %eax
     ce0:      	jb	0xde7 <filter_32ty_range+0x1a7>
     ce6:      	cmpl	%esi, 0x18(%rdi)
     ce9:      	setle	%r8b
     ced:      	cmpl	0x1c(%rdi), %esi
     cf0:      	setle	%r9b
     cf4:      	andb	%r8b, %r9b
     cf7:      	orb	%r9b, %dl
     cfa:      	cmpl	$0x19, %eax
     cfd:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d03:      	cmpl	%esi, 0x20(%rdi)
     d06:      	setle	%r8b
     d0a:      	cmpl	0x24(%rdi), %esi
     d0d:      	setle	%r9b
     d11:      	andb	%r8b, %r9b
     d14:      	orb	%r9b, %dl
     d17:      	cmpl	$0x21, %eax
     d1a:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d20:      	cmpl	%esi, 0x28(%rdi)
     d23:      	setle	%al
     d26:      	cmpl	0x2c(%rdi), %esi
     d29:      	setle	%sil
     d2d:      	jmp	0xda1 <filter_32ty_range+0x161>
     d2f:      	movl	(%rsi), %esi
     d31:      	cmpl	$0x1f, %ecx
     d34:      	jne	0xd46 <filter_32ty_range+0x106>
     d36:      	movl	$0x1, %eax
     d3b:      	cmpl	%esi, 0x10(%rdi)
     d3e:      	ja	0xda9 <filter_32ty_range+0x169>
     d40:      	cmpl	0x14(%rdi), %esi
     d43:      	ja	0xda9 <filter_32ty_range+0x169>
     d45:      	retq
     d46:      	movl	0x8(%rdi), %eax
     d49:      	cmpl	%esi, 0x10(%rdi)
     d4c:      	setbe	%r8b
     d50:      	cmpl	0x14(%rdi), %esi
     d53:      	setbe	%dl
     d56:      	andb	%r8b, %dl
     d59:      	cmpl	$0x11, %eax
     d5c:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d62:      	cmpl	%esi, 0x18(%rdi)
     d65:      	setbe	%r8b
     d69:      	cmpl	0x1c(%rdi), %esi
     d6c:      	setbe	%r9b
     d70:      	andb	%r8b, %r9b
     d73:      	orb	%r9b, %dl
     d76:      	cmpl	$0x19, %eax
     d79:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d7b:      	cmpl	%esi, 0x20(%rdi)
     d7e:      	setbe	%r8b
     d82:      	cmpl	0x24(%rdi), %esi
     d85:      	setbe	%r9b
     d89:      	andb	%r8b, %r9b
     d8c:      	orb	%r9b, %dl
     d8f:      	cmpl	$0x21, %eax
     d92:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d94:      	cmpl	%esi, 0x28(%rdi)
     d97:      	setbe	%al
     d9a:      	cmpl	0x2c(%rdi), %esi
     d9d:      	setbe	%sil
     da1:      	andb	%al, %sil
     da4:      	orb	%sil, %dl
     da7:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     da9:      	movl	0x8(%rdi), %edx
     dac:      	cmpl	$0x11, %edx
     daf:      	jb	0xde5 <filter_32ty_range+0x1a5>
     db1:      	cmpl	%esi, 0x18(%rdi)
     db4:      	ja	0xdbb <filter_32ty_range+0x17b>
     db6:      	cmpl	0x1c(%rdi), %esi
     db9:      	jbe	0xd45 <filter_32ty_range+0x105>
     dbb:      	cmpl	$0x19, %edx
     dbe:      	jb	0xde5 <filter_32ty_range+0x1a5>
     dc0:      	cmpl	%esi, 0x20(%rdi)
     dc3:      	ja	0xdce <filter_32ty_range+0x18e>
     dc5:      	cmpl	0x24(%rdi), %esi
     dc8:      	jbe	0xd45 <filter_32ty_range+0x105>
     dce:      	cmpl	$0x21, %edx
     dd1:      	jb	0xde5 <filter_32ty_range+0x1a5>
     dd3:      	xorl	%edx, %edx
     dd5:      	cmpl	%esi, 0x28(%rdi)
     dd8:      	ja	0xde7 <filter_32ty_range+0x1a7>
     dda:      	cmpl	0x2c(%rdi), %esi
     ddd:      	jbe	0xd45 <filter_32ty_range+0x105>
     de3:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     de5:      	xorl	%edx, %edx
     de7:      	cmpl	$0x20, %ecx
     dea:      	sete	%al
     ded:      	xorb	$0x1, %dl
     df0:      	andb	%al, %dl
     df2:      	movzbl	%dl, %eax
     df5:      	retq
     df6:      	nopw	%cs:(%rax,%rax)

0000000000000e00 <filter_16ty_selector_val>:
     e00:      	movl	0x4(%rdi), %ecx
     e03:      	movl	$0x1, %eax
     e08:      	cmpq	$0x25, %rcx
     e0c:      	ja	0xe7f <filter_16ty_selector_val+0x7f>
     e0e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     e18:      	btq	%rcx, %rdx
     e1c:      	jae	0xe1f <filter_16ty_selector_val+0x1f>
     e1e:      	retq
     e1f:      	movl	$0x18, %edx
     e24:      	btq	%rcx, %rdx
     e28:      	jae	0xe3f <filter_16ty_selector_val+0x3f>
     e2a:      	movzwl	(%rsi), %edx
     e2d:      	cmpl	%edx, 0x10(%rdi)
     e30:      	jne	0xf55 <filter_16ty_selector_val+0x155>
     e36:      	xorl	%eax, %eax
     e38:      	cmpl	$0x3, %ecx
     e3b:      	sete	%al
     e3e:      	retq
     e3f:      	cmpq	$0xc, %rcx
     e43:      	jne	0xe7f <filter_16ty_selector_val+0x7f>
     e45:      	movzwl	(%rsi), %ecx
     e48:      	testl	%ecx, 0x10(%rdi)
     e4b:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e4d:      	movl	0x8(%rdi), %edx
     e50:      	cmpl	$0xd, %edx
     e53:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e59:      	testl	%ecx, 0x14(%rdi)
     e5c:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e5e:      	cmpl	$0x11, %edx
     e61:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e67:      	testl	%ecx, 0x18(%rdi)
     e6a:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e6c:      	cmpl	$0x15, %edx
     e6f:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e75:      	testl	%ecx, 0x1c(%rdi)
     e78:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e7a:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     e7f:      	cmpl	$0x1, %ecx
     e82:      	je	0xef1 <filter_16ty_selector_val+0xf1>
     e84:      	cmpl	$0x2, %ecx
     e87:      	jne	0x1017 <filter_16ty_selector_val+0x217>
     e8d:      	movl	0xc(%rdi), %ecx
     e90:      	cmpl	$0xc, %ecx
     e93:      	ja	0xfde <filter_16ty_selector_val+0x1de>
     e99:      	movl	$0x1402, %edx           # imm = 0x1402
     e9e:      	btl	%ecx, %edx
     ea1:      	jae	0xfde <filter_16ty_selector_val+0x1de>
     ea7:      	movswl	(%rsi), %ecx
     eaa:      	cmpl	%ecx, 0x10(%rdi)
     ead:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eb3:      	movl	0x8(%rdi), %edx
     eb6:      	cmpl	$0xd, %edx
     eb9:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ebf:      	cmpl	%ecx, 0x14(%rdi)
     ec2:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     ec8:      	cmpl	$0x11, %edx
     ecb:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ed1:      	cmpl	%ecx, 0x18(%rdi)
     ed4:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eda:      	cmpl	$0x15, %edx
     edd:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ee3:      	cmpl	%ecx, 0x1c(%rdi)
     ee6:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eec:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     ef1:      	movl	0xc(%rdi), %ecx
     ef4:      	cmpl	$0xc, %ecx
     ef7:      	ja	0xfa3 <filter_16ty_selector_val+0x1a3>
     efd:      	movl	$0x1402, %edx           # imm = 0x1402
     f02:      	btl	%ecx, %edx
     f05:      	jae	0xfa3 <filter_16ty_selector_val+0x1a3>
     f0b:      	movswl	(%rsi), %ecx
     f0e:      	cmpl	%ecx, 0x10(%rdi)
     f11:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f17:      	movl	0x8(%rdi), %edx
     f1a:      	cmpl	$0xd, %edx
     f1d:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f23:      	cmpl	%ecx, 0x14(%rdi)
     f26:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f2c:      	cmpl	$0x11, %edx
     f2f:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f35:      	cmpl	%ecx, 0x18(%rdi)
     f38:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f3e:      	cmpl	$0x15, %edx
     f41:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f47:      	cmpl	%ecx, 0x1c(%rdi)
     f4a:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f50:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     f55:      	movl	0x8(%rdi), %esi
     f58:      	cmpl	$0xd, %esi
     f5b:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f5d:      	cmpl	%edx, 0x14(%rdi)
     f60:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f66:      	cmpl	$0x11, %esi
     f69:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f6b:      	cmpl	%edx, 0x18(%rdi)
     f6e:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f74:      	cmpl	$0x15, %esi
     f77:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f79:      	cmpl	%edx, 0x1c(%rdi)
     f7c:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f82:      	cmpl	$0x25, %ecx
     f85:      	ja	0x1017 <filter_16ty_selector_val+0x217>
     f8b:      	movl	%ecx, %ecx
     f8d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     f97:      	btq	%rcx, %rdx
     f9b:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fa1:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     fa3:      	movzwl	(%rsi), %ecx
     fa6:      	cmpl	%ecx, 0x10(%rdi)
     fa9:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     faf:      	movl	0x8(%rdi), %edx
     fb2:      	cmpl	$0xd, %edx
     fb5:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fb7:      	cmpl	%ecx, 0x14(%rdi)
     fba:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fc0:      	cmpl	$0x11, %edx
     fc3:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fc5:      	cmpl	%ecx, 0x18(%rdi)
     fc8:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fce:      	cmpl	$0x15, %edx
     fd1:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fd3:      	cmpl	%ecx, 0x1c(%rdi)
     fd6:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fdc:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     fde:      	movzwl	(%rsi), %ecx
     fe1:      	cmpl	%ecx, 0x10(%rdi)
     fe4:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
     fea:      	movl	0x8(%rdi), %edx
     fed:      	cmpl	$0xd, %edx
     ff0:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ff2:      	cmpl	%ecx, 0x14(%rdi)
     ff5:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
     ffb:      	cmpl	$0x11, %edx
     ffe:      	jb	0x1017 <filter_16ty_selector_val+0x217>
    1000:      	cmpl	%ecx, 0x18(%rdi)
    1003:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
    1009:      	cmpl	$0x15, %edx
    100c:      	jb	0x1017 <filter_16ty_selector_val+0x217>
    100e:      	cmpl	%ecx, 0x1c(%rdi)
    1011:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
    1017:      	xorl	%eax, %eax
    1019:      	retq
    101a:      	nopw	(%rax,%rax)

0000000000001020 <filter_16ty_map>:
    1020:      	pushq	%r14
    1022:      	pushq	%rbx
    1023:      	subq	$0x18, %rsp
    1027:      	movq	%rsi, %r14
    102a:      	movq	%rdi, %rbx
    102d:      	movzbl	0x10(%rdi), %eax
    1031:      	movl	%eax, 0xc(%rsp)
    1035:      	movq	(%rip), %rdi            # 0x103c <filter_16ty_map+0x1c>
    103c:      	leaq	0xc(%rsp), %rsi
    1041:      	movl	$0x1, %eax
    1046:      	callq	*%rax
    1048:      	testq	%rax, %rax
    104b:      	je	0x1081 <filter_16ty_map+0x61>
    104d:      	movq	%rax, %rdi
    1050:      	movzwl	(%r14), %eax
    1054:      	movq	%rax, 0x10(%rsp)
    1059:      	leaq	0x10(%rsp), %rsi
    105e:      	movl	$0x1, %eax
    1063:      	callq	*%rax
    1065:      	movl	0x4(%rbx), %edx
    1068:      	xorl	%ecx, %ecx
    106a:      	cmpl	$0x1d, %edx
    106d:      	ja	0x109b <filter_16ty_map+0x7b>
    106f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1074:      	btl	%edx, %esi
    1077:      	jae	0x108b <filter_16ty_map+0x6b>
    1079:      	testq	%rax, %rax
    107c:      	setne	%cl
    107f:      	jmp	0x109b <filter_16ty_map+0x7b>
    1081:      	xorl	%eax, %eax
    1083:      	addq	$0x18, %rsp
    1087:      	popq	%rbx
    1088:      	popq	%r14
    108a:      	retq
    108b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1090:      	btl	%edx, %esi
    1093:      	jae	0x109b <filter_16ty_map+0x7b>
    1095:      	testq	%rax, %rax
    1098:      	sete	%cl
    109b:      	movzbl	%cl, %eax
    109e:      	addq	$0x18, %rsp
    10a2:      	popq	%rbx
    10a3:      	popq	%r14
    10a5:      	retq
    10a6:      	nopw	%cs:(%rax,%rax)

00000000000010b0 <filter_16ty_range>:
    10b0:      	movl	0x4(%rdi), %ecx
    10b3:      	movl	0xc(%rdi), %eax
    10b6:      	cmpl	$0xc, %eax
    10b9:      	ja	0x11a0 <filter_16ty_range+0xf0>
    10bf:      	movl	$0x1402, %edx           # imm = 0x1402
    10c4:      	btl	%eax, %edx
    10c7:      	jae	0x11a0 <filter_16ty_range+0xf0>
    10cd:      	movswl	(%rsi), %esi
    10d0:      	cmpl	$0x1f, %ecx
    10d3:      	jne	0x113b <filter_16ty_range+0x8b>
    10d5:      	movl	$0x1, %eax
    10da:      	cmpl	%esi, 0x10(%rdi)
    10dd:      	jg	0x10e8 <filter_16ty_range+0x38>
    10df:      	cmpl	%esi, 0x14(%rdi)
    10e2:      	jge	0x11b7 <filter_16ty_range+0x107>
    10e8:      	movl	0x8(%rdi), %edx
    10eb:      	cmpl	$0x11, %edx
    10ee:      	jb	0x1257 <filter_16ty_range+0x1a7>
    10f4:      	cmpl	%esi, 0x18(%rdi)
    10f7:      	jg	0x1102 <filter_16ty_range+0x52>
    10f9:      	cmpl	%esi, 0x1c(%rdi)
    10fc:      	jge	0x11b7 <filter_16ty_range+0x107>
    1102:      	cmpl	$0x19, %edx
    1105:      	jb	0x1257 <filter_16ty_range+0x1a7>
    110b:      	cmpl	%esi, 0x20(%rdi)
    110e:      	jg	0x1119 <filter_16ty_range+0x69>
    1110:      	cmpl	%esi, 0x24(%rdi)
    1113:      	jge	0x11b7 <filter_16ty_range+0x107>
    1119:      	cmpl	$0x21, %edx
    111c:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1122:      	xorl	%edx, %edx
    1124:      	cmpl	%esi, 0x28(%rdi)
    1127:      	jg	0x1259 <filter_16ty_range+0x1a9>
    112d:      	cmpl	%esi, 0x2c(%rdi)
    1130:      	jge	0x11b7 <filter_16ty_range+0x107>
    1136:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    113b:      	movl	0x8(%rdi), %eax
    113e:      	cmpl	%esi, 0x10(%rdi)
    1141:      	setle	%r8b
    1145:      	cmpl	%esi, 0x14(%rdi)
    1148:      	setge	%dl
    114b:      	andb	%r8b, %dl
    114e:      	cmpl	$0x11, %eax
    1151:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1157:      	cmpl	%esi, 0x18(%rdi)
    115a:      	setle	%r8b
    115e:      	cmpl	%esi, 0x1c(%rdi)
    1161:      	setge	%r9b
    1165:      	andb	%r8b, %r9b
    1168:      	orb	%r9b, %dl
    116b:      	cmpl	$0x19, %eax
    116e:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1174:      	cmpl	%esi, 0x20(%rdi)
    1177:      	setle	%r8b
    117b:      	cmpl	%esi, 0x24(%rdi)
    117e:      	setge	%r9b
    1182:      	andb	%r8b, %r9b
    1185:      	orb	%r9b, %dl
    1188:      	cmpl	$0x21, %eax
    118b:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1191:      	cmpl	%esi, 0x28(%rdi)
    1194:      	setle	%al
    1197:      	cmpl	%esi, 0x2c(%rdi)
    119a:      	setge	%sil
    119e:      	jmp	0x1213 <filter_16ty_range+0x163>
    11a0:      	movzwl	(%rsi), %esi
    11a3:      	cmpl	$0x1f, %ecx
    11a6:      	jne	0x11b8 <filter_16ty_range+0x108>
    11a8:      	movl	$0x1, %eax
    11ad:      	cmpl	%esi, 0x10(%rdi)
    11b0:      	ja	0x121b <filter_16ty_range+0x16b>
    11b2:      	cmpl	%esi, 0x14(%rdi)
    11b5:      	jb	0x121b <filter_16ty_range+0x16b>
    11b7:      	retq
    11b8:      	movl	0x8(%rdi), %eax
    11bb:      	cmpl	%esi, 0x10(%rdi)
    11be:      	setbe	%r8b
    11c2:      	cmpl	%esi, 0x14(%rdi)
    11c5:      	setae	%dl
    11c8:      	andb	%r8b, %dl
    11cb:      	cmpl	$0x11, %eax
    11ce:      	jb	0x1259 <filter_16ty_range+0x1a9>
    11d4:      	cmpl	%esi, 0x18(%rdi)
    11d7:      	setbe	%r8b
    11db:      	cmpl	%esi, 0x1c(%rdi)
    11de:      	setae	%r9b
    11e2:      	andb	%r8b, %r9b
    11e5:      	orb	%r9b, %dl
    11e8:      	cmpl	$0x19, %eax
    11eb:      	jb	0x1259 <filter_16ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x20(%rdi)
    11f0:      	setbe	%r8b
    11f4:      	cmpl	%esi, 0x24(%rdi)
    11f7:      	setae	%r9b
    11fb:      	andb	%r8b, %r9b
    11fe:      	orb	%r9b, %dl
    1201:      	cmpl	$0x21, %eax
    1204:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1206:      	cmpl	%esi, 0x28(%rdi)
    1209:      	setbe	%al
    120c:      	cmpl	%esi, 0x2c(%rdi)
    120f:      	setae	%sil
    1213:      	andb	%al, %sil
    1216:      	orb	%sil, %dl
    1219:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    121b:      	movl	0x8(%rdi), %edx
    121e:      	cmpl	$0x11, %edx
    1221:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1223:      	cmpl	%esi, 0x18(%rdi)
    1226:      	ja	0x122d <filter_16ty_range+0x17d>
    1228:      	cmpl	%esi, 0x1c(%rdi)
    122b:      	jae	0x11b7 <filter_16ty_range+0x107>
    122d:      	cmpl	$0x19, %edx
    1230:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1232:      	cmpl	%esi, 0x20(%rdi)
    1235:      	ja	0x1240 <filter_16ty_range+0x190>
    1237:      	cmpl	%esi, 0x24(%rdi)
    123a:      	jae	0x11b7 <filter_16ty_range+0x107>
    1240:      	cmpl	$0x21, %edx
    1243:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1245:      	xorl	%edx, %edx
    1247:      	cmpl	%esi, 0x28(%rdi)
    124a:      	ja	0x1259 <filter_16ty_range+0x1a9>
    124c:      	cmpl	%esi, 0x2c(%rdi)
    124f:      	jae	0x11b7 <filter_16ty_range+0x107>
    1255:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    1257:      	xorl	%edx, %edx
    1259:      	cmpl	$0x20, %ecx
    125c:      	sete	%al
    125f:      	xorb	$0x1, %dl
    1262:      	andb	%al, %dl
    1264:      	movzbl	%dl, %eax
    1267:      	retq
    1268:      	nopl	(%rax,%rax)

0000000000001270 <filter_8ty_selector_val>:
    1270:      	movl	0x4(%rdi), %ecx
    1273:      	movl	$0x1, %eax
    1278:      	cmpq	$0x25, %rcx
    127c:      	ja	0x12ef <filter_8ty_selector_val+0x7f>
    127e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
    1288:      	btq	%rcx, %rdx
    128c:      	jae	0x128f <filter_8ty_selector_val+0x1f>
    128e:      	retq
    128f:      	movl	$0x18, %edx
    1294:      	btq	%rcx, %rdx
    1298:      	jae	0x12af <filter_8ty_selector_val+0x3f>
    129a:      	movzbl	(%rsi), %edx
    129d:      	cmpl	%edx, 0x10(%rdi)
    12a0:      	jne	0x13c5 <filter_8ty_selector_val+0x155>
    12a6:      	xorl	%eax, %eax
    12a8:      	cmpl	$0x3, %ecx
    12ab:      	sete	%al
    12ae:      	retq
    12af:      	cmpq	$0xc, %rcx
    12b3:      	jne	0x12ef <filter_8ty_selector_val+0x7f>
    12b5:      	movzbl	(%rsi), %ecx
    12b8:      	testl	%ecx, 0x10(%rdi)
    12bb:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12bd:      	movl	0x8(%rdi), %edx
    12c0:      	cmpl	$0xd, %edx
    12c3:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12c9:      	testl	%ecx, 0x14(%rdi)
    12cc:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12ce:      	cmpl	$0x11, %edx
    12d1:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12d7:      	testl	%ecx, 0x18(%rdi)
    12da:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12dc:      	cmpl	$0x15, %edx
    12df:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12e5:      	testl	%ecx, 0x1c(%rdi)
    12e8:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12ea:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    12ef:      	cmpl	$0x1, %ecx
    12f2:      	je	0x1361 <filter_8ty_selector_val+0xf1>
    12f4:      	cmpl	$0x2, %ecx
    12f7:      	jne	0x1487 <filter_8ty_selector_val+0x217>
    12fd:      	movl	0xc(%rdi), %ecx
    1300:      	cmpl	$0xc, %ecx
    1303:      	ja	0x144e <filter_8ty_selector_val+0x1de>
    1309:      	movl	$0x1402, %edx           # imm = 0x1402
    130e:      	btl	%ecx, %edx
    1311:      	jae	0x144e <filter_8ty_selector_val+0x1de>
    1317:      	movsbl	(%rsi), %ecx
    131a:      	cmpl	%ecx, 0x10(%rdi)
    131d:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    1323:      	movl	0x8(%rdi), %edx
    1326:      	cmpl	$0xd, %edx
    1329:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    132f:      	cmpl	%ecx, 0x14(%rdi)
    1332:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    1338:      	cmpl	$0x11, %edx
    133b:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1341:      	cmpl	%ecx, 0x18(%rdi)
    1344:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    134a:      	cmpl	$0x15, %edx
    134d:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1353:      	cmpl	%ecx, 0x1c(%rdi)
    1356:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    135c:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    1361:      	movl	0xc(%rdi), %ecx
    1364:      	cmpl	$0xc, %ecx
    1367:      	ja	0x1413 <filter_8ty_selector_val+0x1a3>
    136d:      	movl	$0x1402, %edx           # imm = 0x1402
    1372:      	btl	%ecx, %edx
    1375:      	jae	0x1413 <filter_8ty_selector_val+0x1a3>
    137b:      	movsbl	(%rsi), %ecx
    137e:      	cmpl	%ecx, 0x10(%rdi)
    1381:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    1387:      	movl	0x8(%rdi), %edx
    138a:      	cmpl	$0xd, %edx
    138d:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1393:      	cmpl	%ecx, 0x14(%rdi)
    1396:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    139c:      	cmpl	$0x11, %edx
    139f:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    13a5:      	cmpl	%ecx, 0x18(%rdi)
    13a8:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    13ae:      	cmpl	$0x15, %edx
    13b1:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    13b7:      	cmpl	%ecx, 0x1c(%rdi)
    13ba:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    13c0:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    13c5:      	movl	0x8(%rdi), %esi
    13c8:      	cmpl	$0xd, %esi
    13cb:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13cd:      	cmpl	%edx, 0x14(%rdi)
    13d0:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13d6:      	cmpl	$0x11, %esi
    13d9:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13db:      	cmpl	%edx, 0x18(%rdi)
    13de:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13e4:      	cmpl	$0x15, %esi
    13e7:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13e9:      	cmpl	%edx, 0x1c(%rdi)
    13ec:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13f2:      	cmpl	$0x25, %ecx
    13f5:      	ja	0x1487 <filter_8ty_selector_val+0x217>
    13fb:      	movl	%ecx, %ecx
    13fd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1407:      	btq	%rcx, %rdx
    140b:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    1411:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    1413:      	movzbl	(%rsi), %ecx
    1416:      	cmpl	%ecx, 0x10(%rdi)
    1419:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    141f:      	movl	0x8(%rdi), %edx
    1422:      	cmpl	$0xd, %edx
    1425:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1427:      	cmpl	%ecx, 0x14(%rdi)
    142a:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    1430:      	cmpl	$0x11, %edx
    1433:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1435:      	cmpl	%ecx, 0x18(%rdi)
    1438:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    143e:      	cmpl	$0x15, %edx
    1441:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1443:      	cmpl	%ecx, 0x1c(%rdi)
    1446:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    144c:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    144e:      	movzbl	(%rsi), %ecx
    1451:      	cmpl	%ecx, 0x10(%rdi)
    1454:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    145a:      	movl	0x8(%rdi), %edx
    145d:      	cmpl	$0xd, %edx
    1460:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1462:      	cmpl	%ecx, 0x14(%rdi)
    1465:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    146b:      	cmpl	$0x11, %edx
    146e:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1470:      	cmpl	%ecx, 0x18(%rdi)
    1473:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    1479:      	cmpl	$0x15, %edx
    147c:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    147e:      	cmpl	%ecx, 0x1c(%rdi)
    1481:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    1487:      	xorl	%eax, %eax
    1489:      	retq
    148a:      	nopw	(%rax,%rax)

0000000000001490 <filter_8ty_map>:
    1490:      	pushq	%r14
    1492:      	pushq	%rbx
    1493:      	subq	$0x18, %rsp
    1497:      	movq	%rsi, %r14
    149a:      	movq	%rdi, %rbx
    149d:      	movzbl	0x10(%rdi), %eax
    14a1:      	movl	%eax, 0xc(%rsp)
    14a5:      	movq	(%rip), %rdi            # 0x14ac <filter_8ty_map+0x1c>
    14ac:      	leaq	0xc(%rsp), %rsi
    14b1:      	movl	$0x1, %eax
    14b6:      	callq	*%rax
    14b8:      	testq	%rax, %rax
    14bb:      	je	0x14f1 <filter_8ty_map+0x61>
    14bd:      	movq	%rax, %rdi
    14c0:      	movzbl	(%r14), %eax
    14c4:      	movq	%rax, 0x10(%rsp)
    14c9:      	leaq	0x10(%rsp), %rsi
    14ce:      	movl	$0x1, %eax
    14d3:      	callq	*%rax
    14d5:      	movl	0x4(%rbx), %edx
    14d8:      	xorl	%ecx, %ecx
    14da:      	cmpl	$0x1d, %edx
    14dd:      	ja	0x150b <filter_8ty_map+0x7b>
    14df:      	movl	$0x30038400, %esi       # imm = 0x30038400
    14e4:      	btl	%edx, %esi
    14e7:      	jae	0x14fb <filter_8ty_map+0x6b>
    14e9:      	testq	%rax, %rax
    14ec:      	setne	%cl
    14ef:      	jmp	0x150b <filter_8ty_map+0x7b>
    14f1:      	xorl	%eax, %eax
    14f3:      	addq	$0x18, %rsp
    14f7:      	popq	%rbx
    14f8:      	popq	%r14
    14fa:      	retq
    14fb:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1500:      	btl	%edx, %esi
    1503:      	jae	0x150b <filter_8ty_map+0x7b>
    1505:      	testq	%rax, %rax
    1508:      	sete	%cl
    150b:      	movzbl	%cl, %eax
    150e:      	addq	$0x18, %rsp
    1512:      	popq	%rbx
    1513:      	popq	%r14
    1515:      	retq
    1516:      	nopw	%cs:(%rax,%rax)

0000000000001520 <filter_8ty_range>:
    1520:      	movl	0x4(%rdi), %ecx
    1523:      	movl	0xc(%rdi), %eax
    1526:      	cmpl	$0xc, %eax
    1529:      	ja	0x1610 <filter_8ty_range+0xf0>
    152f:      	movl	$0x1402, %edx           # imm = 0x1402
    1534:      	btl	%eax, %edx
    1537:      	jae	0x1610 <filter_8ty_range+0xf0>
    153d:      	movsbl	(%rsi), %esi
    1540:      	cmpl	$0x1f, %ecx
    1543:      	jne	0x15ab <filter_8ty_range+0x8b>
    1545:      	movl	$0x1, %eax
    154a:      	cmpl	%esi, 0x10(%rdi)
    154d:      	jg	0x1558 <filter_8ty_range+0x38>
    154f:      	cmpl	%esi, 0x14(%rdi)
    1552:      	jge	0x1627 <filter_8ty_range+0x107>
    1558:      	movl	0x8(%rdi), %edx
    155b:      	cmpl	$0x11, %edx
    155e:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1564:      	cmpl	%esi, 0x18(%rdi)
    1567:      	jg	0x1572 <filter_8ty_range+0x52>
    1569:      	cmpl	%esi, 0x1c(%rdi)
    156c:      	jge	0x1627 <filter_8ty_range+0x107>
    1572:      	cmpl	$0x19, %edx
    1575:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    157b:      	cmpl	%esi, 0x20(%rdi)
    157e:      	jg	0x1589 <filter_8ty_range+0x69>
    1580:      	cmpl	%esi, 0x24(%rdi)
    1583:      	jge	0x1627 <filter_8ty_range+0x107>
    1589:      	cmpl	$0x21, %edx
    158c:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1592:      	xorl	%edx, %edx
    1594:      	cmpl	%esi, 0x28(%rdi)
    1597:      	jg	0x16c9 <filter_8ty_range+0x1a9>
    159d:      	cmpl	%esi, 0x2c(%rdi)
    15a0:      	jge	0x1627 <filter_8ty_range+0x107>
    15a6:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    15ab:      	movl	0x8(%rdi), %eax
    15ae:      	cmpl	%esi, 0x10(%rdi)
    15b1:      	setle	%r8b
    15b5:      	cmpl	%esi, 0x14(%rdi)
    15b8:      	setge	%dl
    15bb:      	andb	%r8b, %dl
    15be:      	cmpl	$0x11, %eax
    15c1:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    15c7:      	cmpl	%esi, 0x18(%rdi)
    15ca:      	setle	%r8b
    15ce:      	cmpl	%esi, 0x1c(%rdi)
    15d1:      	setge	%r9b
    15d5:      	andb	%r8b, %r9b
    15d8:      	orb	%r9b, %dl
    15db:      	cmpl	$0x19, %eax
    15de:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    15e4:      	cmpl	%esi, 0x20(%rdi)
    15e7:      	setle	%r8b
    15eb:      	cmpl	%esi, 0x24(%rdi)
    15ee:      	setge	%r9b
    15f2:      	andb	%r8b, %r9b
    15f5:      	orb	%r9b, %dl
    15f8:      	cmpl	$0x21, %eax
    15fb:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1601:      	cmpl	%esi, 0x28(%rdi)
    1604:      	setle	%al
    1607:      	cmpl	%esi, 0x2c(%rdi)
    160a:      	setge	%sil
    160e:      	jmp	0x1683 <filter_8ty_range+0x163>
    1610:      	movzbl	(%rsi), %esi
    1613:      	cmpl	$0x1f, %ecx
    1616:      	jne	0x1628 <filter_8ty_range+0x108>
    1618:      	movl	$0x1, %eax
    161d:      	cmpl	%esi, 0x10(%rdi)
    1620:      	ja	0x168b <filter_8ty_range+0x16b>
    1622:      	cmpl	%esi, 0x14(%rdi)
    1625:      	jb	0x168b <filter_8ty_range+0x16b>
    1627:      	retq
    1628:      	movl	0x8(%rdi), %eax
    162b:      	cmpl	%esi, 0x10(%rdi)
    162e:      	setbe	%r8b
    1632:      	cmpl	%esi, 0x14(%rdi)
    1635:      	setae	%dl
    1638:      	andb	%r8b, %dl
    163b:      	cmpl	$0x11, %eax
    163e:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1644:      	cmpl	%esi, 0x18(%rdi)
    1647:      	setbe	%r8b
    164b:      	cmpl	%esi, 0x1c(%rdi)
    164e:      	setae	%r9b
    1652:      	andb	%r8b, %r9b
    1655:      	orb	%r9b, %dl
    1658:      	cmpl	$0x19, %eax
    165b:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    165d:      	cmpl	%esi, 0x20(%rdi)
    1660:      	setbe	%r8b
    1664:      	cmpl	%esi, 0x24(%rdi)
    1667:      	setae	%r9b
    166b:      	andb	%r8b, %r9b
    166e:      	orb	%r9b, %dl
    1671:      	cmpl	$0x21, %eax
    1674:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1676:      	cmpl	%esi, 0x28(%rdi)
    1679:      	setbe	%al
    167c:      	cmpl	%esi, 0x2c(%rdi)
    167f:      	setae	%sil
    1683:      	andb	%al, %sil
    1686:      	orb	%sil, %dl
    1689:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    168b:      	movl	0x8(%rdi), %edx
    168e:      	cmpl	$0x11, %edx
    1691:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1693:      	cmpl	%esi, 0x18(%rdi)
    1696:      	ja	0x169d <filter_8ty_range+0x17d>
    1698:      	cmpl	%esi, 0x1c(%rdi)
    169b:      	jae	0x1627 <filter_8ty_range+0x107>
    169d:      	cmpl	$0x19, %edx
    16a0:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    16a2:      	cmpl	%esi, 0x20(%rdi)
    16a5:      	ja	0x16b0 <filter_8ty_range+0x190>
    16a7:      	cmpl	%esi, 0x24(%rdi)
    16aa:      	jae	0x1627 <filter_8ty_range+0x107>
    16b0:      	cmpl	$0x21, %edx
    16b3:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    16b5:      	xorl	%edx, %edx
    16b7:      	cmpl	%esi, 0x28(%rdi)
    16ba:      	ja	0x16c9 <filter_8ty_range+0x1a9>
    16bc:      	cmpl	%esi, 0x2c(%rdi)
    16bf:      	jae	0x1627 <filter_8ty_range+0x107>
    16c5:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    16c7:      	xorl	%edx, %edx
    16c9:      	cmpl	$0x20, %ecx
    16cc:      	sete	%al
    16cf:      	xorb	$0x1, %dl
    16d2:      	andb	%al, %dl
    16d4:      	movzbl	%dl, %eax
    16d7:      	retq
    16d8:      	nopl	(%rax,%rax)

00000000000016e0 <filter_file_buf>:
    16e0:      	pushq	%rbx
    16e1:      	movq	%rdi, %rbx
    16e4:      	movl	(%rsi), %edx
    16e6:      	movl	0x4(%rdi), %ecx
    16e9:      	testl	%edx, %edx
    16eb:      	jne	0x16fb <filter_file_buf+0x1b>
    16ed:      	movl	%ecx, %eax
    16ef:      	andl	$-0x2, %eax
    16f2:      	cmpl	$0x24, %eax
    16f5:      	je	0x16fb <filter_file_buf+0x1b>
    16f7:      	xorl	%eax, %eax
    16f9:      	popq	%rbx
    16fa:      	retq
    16fb:      	cmpl	$0x25, %ecx
    16fe:      	ja	0x173a <filter_file_buf+0x5a>
    1700:      	movl	%ecx, %eax
    1702:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1707:      	btq	%rax, %rdi
    170b:      	jb	0x176e <filter_file_buf+0x8e>
    170d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1712:      	btq	%rax, %rdi
    1716:      	jb	0x1758 <filter_file_buf+0x78>
    1718:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1722:      	btq	%rax, %rdi
    1726:      	jae	0x173a <filter_file_buf+0x5a>
    1728:      	movq	%rbx, %rdi
    172b:      	callq	0x21d0 <filter_file_type>
    1730:      	movl	0x4(%rbx), %ecx
    1733:      	cmpl	$0x25, %ecx
    1736:      	jbe	0x178b <filter_file_buf+0xab>
    1738:      	jmp	0x17a1 <filter_file_buf+0xc1>
    173a:      	leal	-0x3(%rcx), %eax
    173d:      	cmpl	$0x2, %eax
    1740:      	jae	0x1784 <filter_file_buf+0xa4>
    1742:      	addq	$0x4, %rsi
    1746:      	movq	%rbx, %rdi
    1749:      	callq	0x1c60 <filter_char_buf_equal>
    174e:      	movl	0x4(%rbx), %ecx
    1751:      	cmpl	$0x25, %ecx
    1754:      	jbe	0x178b <filter_file_buf+0xab>
    1756:      	jmp	0x17a1 <filter_file_buf+0xc1>
    1758:      	addq	$0x4, %rsi
    175c:      	movl	0x10(%rbx), %edi
    175f:      	callq	0x2080 <filter_char_buf_postfix>
    1764:      	movl	0x4(%rbx), %ecx
    1767:      	cmpl	$0x25, %ecx
    176a:      	jbe	0x178b <filter_file_buf+0xab>
    176c:      	jmp	0x17a1 <filter_file_buf+0xc1>
    176e:      	addq	$0x4, %rsi
    1772:      	movl	0x10(%rbx), %edi
    1775:      	callq	0x1fe0 <filter_char_buf_prefix>
    177a:      	movl	0x4(%rbx), %ecx
    177d:      	cmpl	$0x25, %ecx
    1780:      	jbe	0x178b <filter_file_buf+0xab>
    1782:      	jmp	0x17a1 <filter_file_buf+0xc1>
    1784:      	xorl	%eax, %eax
    1786:      	cmpl	$0x25, %ecx
    1789:      	ja	0x17a1 <filter_file_buf+0xc1>
    178b:      	movl	%ecx, %ecx
    178d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1797:      	btq	%rcx, %rdx
    179b:      	jae	0x17a1 <filter_file_buf+0xc1>
    179d:      	xorq	$0x1, %rax
    17a1:      	popq	%rbx
    17a2:      	retq
    17a3:      	nopw	%cs:(%rax,%rax)

00000000000017b0 <filter_char_buf>:
    17b0:      	pushq	%rbx
    17b1:      	movq	%rsi, %rax
    17b4:      	movq	%rdi, %rbx
    17b7:      	movslq	%edx, %rcx
    17ba:      	movl	-0x4(%rsi,%rcx), %edx
    17be:      	movl	%ecx, %esi
    17c0:      	addq	%rax, %rsi
    17c3:      	movl	0x4(%rdi), %ecx
    17c6:      	xorl	%eax, %eax
    17c8:      	cmpl	$0x19, %ecx
    17cb:      	jg	0x17e1 <filter_char_buf+0x31>
    17cd:      	leal	-0x3(%rcx), %edi
    17d0:      	cmpl	$0x2, %edi
    17d3:      	jb	0x1818 <filter_char_buf+0x68>
    17d5:      	cmpl	$0x8, %ecx
    17d8:      	je	0x180e <filter_char_buf+0x5e>
    17da:      	cmpl	$0x9, %ecx
    17dd:      	je	0x17f0 <filter_char_buf+0x40>
    17df:      	jmp	0x182f <filter_char_buf+0x7f>
    17e1:      	cmpl	$0x20, %ecx
    17e4:      	jg	0x17fa <filter_char_buf+0x4a>
    17e6:      	cmpl	$0x1a, %ecx
    17e9:      	je	0x180e <filter_char_buf+0x5e>
    17eb:      	cmpl	$0x1b, %ecx
    17ee:      	jne	0x182f <filter_char_buf+0x7f>
    17f0:      	movl	0x10(%rbx), %edi
    17f3:      	callq	0x2080 <filter_char_buf_postfix>
    17f8:      	jmp	0x182c <filter_char_buf+0x7c>
    17fa:      	cmpl	$0x21, %ecx
    17fd:      	je	0x1822 <filter_char_buf+0x72>
    17ff:      	cmpl	$0x22, %ecx
    1802:      	jne	0x182f <filter_char_buf+0x7f>
    1804:      	movq	%rbx, %rdi
    1807:      	movl	$0x1, %ecx
    180c:      	jmp	0x1827 <filter_char_buf+0x77>
    180e:      	movl	0x10(%rbx), %edi
    1811:      	callq	0x1fe0 <filter_char_buf_prefix>
    1816:      	jmp	0x182c <filter_char_buf+0x7c>
    1818:      	movq	%rbx, %rdi
    181b:      	callq	0x1c60 <filter_char_buf_equal>
    1820:      	jmp	0x182c <filter_char_buf+0x7c>
    1822:      	movq	%rbx, %rdi
    1825:      	xorl	%ecx, %ecx
    1827:      	callq	0x2280 <filter_char_substring>
    182c:      	movl	0x4(%rbx), %ecx
    182f:      	cmpl	$0x25, %ecx
    1832:      	ja	0x1851 <filter_char_buf+0xa1>
    1834:      	movl	%ecx, %ecx
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x1851 <filter_char_buf+0xa1>
    1846:      	xorl	%ecx, %ecx
    1848:      	testq	%rax, %rax
    184b:      	sete	%cl
    184e:      	movq	%rcx, %rax
    1851:      	popq	%rbx
    1852:      	retq
    1853:      	nopw	%cs:(%rax,%rax)

0000000000001860 <filter_inet>:
    1860:      	pushq	%r15
    1862:      	pushq	%r14
    1864:      	pushq	%r12
    1866:      	pushq	%rbx
    1867:      	subq	$0x48, %rsp
    186b:      	movq	$0x0, 0x40(%rsp)
    1874:      	movq	$0x0, 0x38(%rsp)
    187d:      	movq	$0x0, 0x30(%rsp)
    1886:      	movq	$0x0, 0x28(%rsp)
    188f:      	movq	$0x0, 0x20(%rsp)
    1898:      	movl	$0x0, (%rsp)
    189f:      	movl	$0x0, 0x4(%rsp)
    18a7:      	movl	0xc(%rdi), %edx
    18aa:      	xorl	%eax, %eax
    18ac:      	cmpl	$0x27, %edx
    18af:      	jg	0x18c7 <filter_inet+0x67>
    18b1:      	cmpl	$0x5, %edx
    18b4:      	je	0x194c <filter_inet+0xec>
    18ba:      	movq	%rsi, %r8
    18bd:      	cmpl	$0x7, %edx
    18c0:      	je	0x18d8 <filter_inet+0x78>
    18c2:      	jmp	0x1b5d <filter_inet+0x2fd>
    18c7:      	cmpl	$0x28, %edx
    18ca:      	je	0x1924 <filter_inet+0xc4>
    18cc:      	movq	%rsi, %r8
    18cf:      	cmpl	$0x29, %edx
    18d2:      	jne	0x1b5d <filter_inet+0x2fd>
    18d8:      	movl	0x4(%rdi), %ecx
    18db:      	xorl	%eax, %eax
    18dd:      	cmpl	$0x13, %ecx
    18e0:      	jle	0x1959 <filter_inet+0xf9>
    18e2:      	cmpl	$0x17, %ecx
    18e5:      	jg	0x1904 <filter_inet+0xa4>
    18e7:      	leal	-0x14(%rcx), %edx
    18ea:      	cmpl	$0x2, %edx
    18ed:      	jb	0x19aa <filter_inet+0x14a>
    18f3:      	leal	-0x16(%rcx), %edx
    18f6:      	cmpl	$0x2, %edx
    18f9:      	jb	0x19a4 <filter_inet+0x144>
    18ff:      	jmp	0x1b5d <filter_inet+0x2fd>
    1904:      	cmpl	$0x1b, %ecx
    1907:      	jg	0x19e7 <filter_inet+0x187>
    190d:      	cmpl	$0x18, %ecx
    1910:      	je	0x1a1a <filter_inet+0x1ba>
    1916:      	cmpl	$0x19, %ecx
    1919:      	je	0x1a10 <filter_inet+0x1b0>
    191f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1924:      	movzwl	(%rsi), %eax
    1927:      	movw	%ax, 0x46(%rsp)
    192c:      	movzwl	0x2(%rsi), %eax
    1930:      	movw	%ax, 0x40(%rsp)
    1935:      	movq	0x8(%rsi), %rax
    1939:      	movq	%rax, 0x20(%rsp)
    193e:      	movq	0x10(%rsi), %rax
    1942:      	movq	%rax, 0x28(%rsp)
    1947:      	leaq	0x20(%rsp), %rsi
    194c:      	xorl	%r8d, %r8d
    194f:      	movl	0x4(%rdi), %ecx
    1952:      	xorl	%eax, %eax
    1954:      	cmpl	$0x13, %ecx
    1957:      	jg	0x18e2 <filter_inet+0x82>
    1959:      	cmpl	$0xf, %ecx
    195c:      	jle	0x197a <filter_inet+0x11a>
    195e:      	cmpl	$0x11, %ecx
    1961:      	jg	0x1996 <filter_inet+0x136>
    1963:      	cmpl	$0x10, %ecx
    1966:      	je	0x19a4 <filter_inet+0x144>
    1968:      	cmpl	$0x11, %ecx
    196b:      	jne	0x1b5d <filter_inet+0x2fd>
    1971:      	movzwl	0x24(%rsi), %eax
    1975:      	jmp	0x1b52 <filter_inet+0x2f2>
    197a:      	cmpl	$0xd, %ecx
    197d:      	je	0x1a1a <filter_inet+0x1ba>
    1983:      	cmpl	$0xe, %ecx
    1986:      	je	0x1a10 <filter_inet+0x1b0>
    198c:      	cmpl	$0xf, %ecx
    198f:      	je	0x19aa <filter_inet+0x14a>
    1991:      	jmp	0x1b5d <filter_inet+0x2fd>
    1996:      	cmpl	$0x12, %ecx
    1999:      	je	0x19aa <filter_inet+0x14a>
    199b:      	cmpl	$0x13, %ecx
    199e:      	jne	0x1b5d <filter_inet+0x2fd>
    19a4:      	movzwl	0x22(%rsi), %edx
    19a8:      	jmp	0x19ae <filter_inet+0x14e>
    19aa:      	movzwl	0x20(%rsi), %edx
    19ae:      	movl	%edx, 0x4(%rsp)
    19b2:      	xorl	%ebx, %ebx
    19b4:      	xorl	%r15d, %r15d
    19b7:      	xorl	%r14d, %r14d
    19ba:      	xorl	%eax, %eax
    19bc:      	cmpl	$0x11, %ecx
    19bf:      	jg	0x1a31 <filter_inet+0x1d1>
    19c1:      	leal	-0xd(%rcx), %edx
    19c4:      	cmpl	$0x2, %edx
    19c7:      	jb	0x1a58 <filter_inet+0x1f8>
    19cd:      	leal	-0xf(%rcx), %edx
    19d0:      	cmpl	$0x2, %edx
    19d3:      	jb	0x1aad <filter_inet+0x24d>
    19d9:      	cmpl	$0x11, %ecx
    19dc:      	je	0x1b55 <filter_inet+0x2f5>
    19e2:      	jmp	0x1b5d <filter_inet+0x2fd>
    19e7:      	cmpl	$0x1c, %ecx
    19ea:      	je	0x1b4e <filter_inet+0x2ee>
    19f0:      	cmpl	$0x1d, %ecx
    19f3:      	jne	0x1b5d <filter_inet+0x2fd>
    19f9:      	cmpl	$0x7, %edx
    19fc:      	jne	0x1b81 <filter_inet+0x321>
    1a02:      	testq	%r8, %r8
    1a05:      	jne	0x1b8b <filter_inet+0x32b>
    1a0b:      	jmp	0x1b55 <filter_inet+0x2f5>
    1a10:      	movq	0x10(%rsi), %rbx
    1a14:      	movq	0x18(%rsi), %r14
    1a18:      	jmp	0x1a21 <filter_inet+0x1c1>
    1a1a:      	movq	(%rsi), %rbx
    1a1d:      	movq	0x8(%rsi), %r14
    1a21:      	movq	%rbx, %r15
    1a24:      	shrq	$0x20, %r15
    1a28:      	xorl	%edx, %edx
    1a2a:      	xorl	%eax, %eax
    1a2c:      	cmpl	$0x11, %ecx
    1a2f:      	jle	0x19c1 <filter_inet+0x161>
    1a31:      	cmpl	$0x19, %ecx
    1a34:      	ja	0x1aa1 <filter_inet+0x241>
    1a36:      	movl	$0x500000, %r8d         # imm = 0x500000
    1a3c:      	btl	%ecx, %r8d
    1a40:      	jb	0x1ab7 <filter_inet+0x257>
    1a42:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1a48:      	btl	%ecx, %r8d
    1a4c:      	jb	0x1ac7 <filter_inet+0x267>
    1a4e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    1a53:      	btl	%ecx, %edx
    1a56:      	jae	0x1aa1 <filter_inet+0x241>
    1a58:      	movzwl	0x26(%rsi), %eax
    1a5c:      	cmpl	$0xa, %eax
    1a5f:      	je	0x1ad7 <filter_inet+0x277>
    1a61:      	cmpl	$0x2, %eax
    1a64:      	jne	0x1b47 <filter_inet+0x2e7>
    1a6a:      	movq	%rdi, %r12
    1a6d:      	movl	0x10(%rdi), %eax
    1a70:      	movl	%eax, 0x8(%rsp)
    1a74:      	movq	(%rip), %rdi            # 0x1a7b <filter_inet+0x21b>
    1a7b:      	leaq	0x8(%rsp), %rsi
    1a80:      	movl	$0x1, %eax
    1a85:      	callq	*%rax
    1a87:      	testq	%rax, %rax
    1a8a:      	je	0x1b69 <filter_inet+0x309>
    1a90:      	movq	%rax, %rdi
    1a93:      	movl	$0x20, 0xc(%rsp)
    1a9b:      	movl	%ebx, 0x10(%rsp)
    1a9f:      	jmp	0x1b1b <filter_inet+0x2bb>
    1aa1:      	addl	$-0x12, %ecx
    1aa4:      	cmpl	$0x2, %ecx
    1aa7:      	jae	0x1b5d <filter_inet+0x2fd>
    1aad:      	leaq	0x4(%rsp), %rsi
    1ab2:      	jmp	0x1b58 <filter_inet+0x2f8>
    1ab7:      	xorl	%eax, %eax
    1ab9:      	cmpl	$0x400, %edx            # imm = 0x400
    1abf:      	setb	%al
    1ac2:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ac7:      	xorl	%eax, %eax
    1ac9:      	cmpl	$0x400, %edx            # imm = 0x400
    1acf:      	setae	%al
    1ad2:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ad7:      	movq	%rdi, %r12
    1ada:      	movl	0x14(%rdi), %eax
    1add:      	movl	%eax, 0x8(%rsp)
    1ae1:      	movq	(%rip), %rdi            # 0x1ae8 <filter_inet+0x288>
    1ae8:      	leaq	0x8(%rsp), %rsi
    1aed:      	movl	$0x1, %eax
    1af2:      	callq	*%rax
    1af4:      	testq	%rax, %rax
    1af7:      	je	0x1b69 <filter_inet+0x309>
    1af9:      	movq	%rax, %rdi
    1afc:      	movl	$0x80, 0xc(%rsp)
    1b04:      	movl	%ebx, 0x10(%rsp)
    1b08:      	movl	%r15d, 0x14(%rsp)
    1b0d:      	movl	%r14d, 0x18(%rsp)
    1b12:      	shrq	$0x20, %r14
    1b16:      	movl	%r14d, 0x1c(%rsp)
    1b1b:      	leaq	0xc(%rsp), %rsi
    1b20:      	movl	$0x1, %eax
    1b25:      	callq	*%rax
    1b27:      	movl	0x4(%r12), %ecx
    1b2c:      	leal	-0x18(%rcx), %edx
    1b2f:      	cmpl	$0x2, %edx
    1b32:      	jb	0x1b76 <filter_inet+0x316>
    1b34:      	addl	$-0xd, %ecx
    1b37:      	cmpl	$0x1, %ecx
    1b3a:      	ja	0x1b47 <filter_inet+0x2e7>
    1b3c:      	testq	%rax, %rax
    1b3f:      	setne	%al
    1b42:      	movzbl	%al, %eax
    1b45:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b47:      	xorl	%eax, %eax
    1b49:      	movzbl	%al, %eax
    1b4c:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b4e:      	movzwl	0x26(%rsi), %eax
    1b52:      	movl	%eax, (%rsp)
    1b55:      	movq	%rsp, %rsi
    1b58:      	callq	0xbb0 <filter_32ty_map>
    1b5d:      	addq	$0x48, %rsp
    1b61:      	popq	%rbx
    1b62:      	popq	%r12
    1b64:      	popq	%r14
    1b66:      	popq	%r15
    1b68:      	retq
    1b69:      	movl	0x4(%r12), %eax
    1b6e:      	andl	$-0x2, %eax
    1b71:      	cmpl	$0x18, %eax
    1b74:      	jmp	0x1b79 <filter_inet+0x319>
    1b76:      	testq	%rax, %rax
    1b79:      	sete	%al
    1b7c:      	movzbl	%al, %eax
    1b7f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b81:      	cmpl	$0x29, %edx
    1b84:      	jne	0x1b93 <filter_inet+0x333>
    1b86:      	testq	%r8, %r8
    1b89:      	je	0x1b93 <filter_inet+0x333>
    1b8b:      	movzbl	0x3a(%r8), %eax
    1b90:      	movl	%eax, (%rsp)
    1b93:      	cmpl	$0x29, %edx
    1b96:      	je	0x1b55 <filter_inet+0x2f5>
    1b98:      	cmpl	$0x7, %edx
    1b9b:      	je	0x1b55 <filter_inet+0x2f5>
    1b9d:      	xorl	%eax, %eax
    1b9f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ba1:      	nopw	%cs:(%rax,%rax)

0000000000001bb0 <filter_sockaddr_un>:
    1bb0:      	pushq	%rbx
    1bb1:      	subq	$0x10, %rsp
    1bb5:      	movq	%rsi, %rcx
    1bb8:      	addq	$0x4, %rsi
    1bbc:      	movzbl	0x3(%rcx), %edx
    1bc0:      	movl	0x4(%rdi), %r8d
    1bc4:      	xorl	%eax, %eax
    1bc6:      	cmpl	$0x19, %r8d
    1bca:      	jg	0x1c00 <filter_sockaddr_un+0x50>
    1bcc:      	leal	-0x3(%r8), %ecx
    1bd0:      	cmpl	$0x2, %ecx
    1bd3:      	jae	0x1c0e <filter_sockaddr_un+0x5e>
    1bd5:      	movq	%rdi, %rbx
    1bd8:      	callq	0x1c60 <filter_char_buf_equal>
    1bdd:      	movl	0x4(%rbx), %ecx
    1be0:      	cmpq	$0x25, %rcx
    1be4:      	ja	0x1bfa <filter_sockaddr_un+0x4a>
    1be6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1bf0:      	btq	%rcx, %rdx
    1bf4:      	jae	0x1bfa <filter_sockaddr_un+0x4a>
    1bf6:      	xorq	$0x1, %rax
    1bfa:      	addq	$0x10, %rsp
    1bfe:      	popq	%rbx
    1bff:      	retq
    1c00:      	cmpl	$0x1c, %r8d
    1c04:      	je	0x1c44 <filter_sockaddr_un+0x94>
    1c06:      	cmpl	$0x1a, %r8d
    1c0a:      	je	0x1c14 <filter_sockaddr_un+0x64>
    1c0c:      	jmp	0x1bfa <filter_sockaddr_un+0x4a>
    1c0e:      	cmpl	$0x8, %r8d
    1c12:      	jne	0x1bfa <filter_sockaddr_un+0x4a>
    1c14:      	movl	0x10(%rdi), %eax
    1c17:      	movq	%rdi, %rbx
    1c1a:      	movl	%eax, %edi
    1c1c:      	callq	0x1fe0 <filter_char_buf_prefix>
    1c21:      	movl	0x4(%rbx), %ecx
    1c24:      	cmpq	$0x25, %rcx
    1c28:      	ja	0x1bfa <filter_sockaddr_un+0x4a>
    1c2a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1c34:      	btq	%rcx, %rdx
    1c38:      	jae	0x1bfa <filter_sockaddr_un+0x4a>
    1c3a:      	xorq	$0x1, %rax
    1c3e:      	addq	$0x10, %rsp
    1c42:      	popq	%rbx
    1c43:      	retq
    1c44:      	movzwl	(%rcx), %eax
    1c47:      	movl	%eax, 0xc(%rsp)
    1c4b:      	leaq	0xc(%rsp), %rsi
    1c50:      	callq	0xbb0 <filter_32ty_map>
    1c55:      	addq	$0x10, %rsp
    1c59:      	popq	%rbx
    1c5a:      	retq
    1c5b:      	nopl	(%rax,%rax)

0000000000001c60 <filter_char_buf_equal>:
    1c60:      	pushq	%rbp
    1c61:      	pushq	%r15
    1c63:      	pushq	%r14
    1c65:      	pushq	%r13
    1c67:      	pushq	%r12
    1c69:      	pushq	%rbx
    1c6a:      	subq	$0x28, %rsp
    1c6e:      	movl	$0x0, 0x14(%rsp)
    1c76:      	cmpl	$0x1000, %edx           # imm = 0x1000
    1c7c:      	ja	0x1fce <filter_char_buf_equal+0x36e>
    1c82:      	movl	%edx, %ebp
    1c84:      	movzwl	%bp, %eax
    1c87:      	cmpl	$0x90, %eax
    1c8c:      	ja	0x1cd5 <filter_char_buf_equal+0x75>
    1c8e:      	testw	%bp, %bp
    1c91:      	je	0x1ca4 <filter_char_buf_equal+0x44>
    1c93:      	movl	$0x18, %ecx
    1c98:      	movl	%ebp, %eax
    1c9a:      	cltd
    1c9b:      	idivl	%ecx
    1c9d:      	movl	%ebp, %r14d
    1ca0:      	testl	%edx, %edx
    1ca2:      	je	0x1cc4 <filter_char_buf_equal+0x64>
    1ca4:      	movl	$0x18, %ecx
    1ca9:      	movl	%ebp, %eax
    1cab:      	cltd
    1cac:      	idivl	%ecx
    1cae:      	shll	$0x3, %eax
    1cb1:      	leal	(%rax,%rax,2), %eax
    1cb4:      	addl	$0x18, %eax
    1cb7:      	movzwl	%ax, %r14d
    1cbb:      	cmpl	$0x90, %r14d
    1cc2:      	ja	0x1d13 <filter_char_buf_equal+0xb3>
    1cc4:      	movl	%r14d, %eax
    1cc7:      	cltd
    1cc8:      	idivl	%ecx
    1cca:      	movl	%eax, %r15d
    1ccd:      	decl	%r15d
    1cd0:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1cd5:      	movl	$0x100, %r14d           # imm = 0x100
    1cdb:      	cmpl	$0x101, %eax            # imm = 0x101
    1ce0:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1ce2:      	movl	$0x200, %r14d           # imm = 0x200
    1ce8:      	cmpl	$0x201, %eax            # imm = 0x201
    1ced:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1cef:      	movl	$0x400, %r14d           # imm = 0x400
    1cf5:      	cmpl	$0x401, %eax            # imm = 0x401
    1cfa:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1cfc:      	xorl	%r14d, %r14d
    1cff:      	cmpl	$0x801, %eax            # imm = 0x801
    1d04:      	setae	%r14b
    1d08:      	shll	$0xb, %r14d
    1d0c:      	addl	$0x800, %r14d           # imm = 0x800
    1d13:      	leal	-0x100(%r14), %eax
    1d1a:      	rorxl	$0x8, %eax, %eax
    1d20:      	cmpl	$0x2, %eax
    1d23:      	jg	0x1d36 <filter_char_buf_equal+0xd6>
    1d25:      	testl	%eax, %eax
    1d27:      	je	0x1d50 <filter_char_buf_equal+0xf0>
    1d29:      	cmpl	$0x1, %eax
    1d2c:      	jne	0x1d48 <filter_char_buf_equal+0xe8>
    1d2e:      	movl	$0x7, %r15d
    1d34:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d36:      	cmpl	$0x3, %eax
    1d39:      	je	0x1d58 <filter_char_buf_equal+0xf8>
    1d3b:      	cmpl	$0x7, %eax
    1d3e:      	jne	0x1d48 <filter_char_buf_equal+0xe8>
    1d40:      	movl	$0x9, %r15d
    1d46:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d48:      	movl	$0xa, %r15d
    1d4e:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d50:      	movl	$0x6, %r15d
    1d56:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d58:      	movl	$0x8, %r15d
    1d5e:      	movl	%r15d, %eax
    1d61:      	andl	$0xf, %eax
    1d64:      	movl	0x10(%rdi,%rax,4), %r13d
    1d69:      	cmpl	$-0x1, %r13d
    1d6d:      	je	0x1fce <filter_char_buf_equal+0x36e>
    1d73:      	movq	%rsi, 0x20(%rsp)
    1d78:      	movq	(%rip), %rdi            # 0x1d7f <filter_char_buf_equal+0x11f>
    1d7f:      	leaq	0x14(%rsp), %r12
    1d84:      	movl	$0x1, %eax
    1d89:      	movq	%r12, %rsi
    1d8c:      	callq	*%rax
    1d8e:      	movq	%rax, %rbx
    1d91:      	movq	(%rip), %rdi            # 0x1d98 <filter_char_buf_equal+0x138>
    1d98:      	movl	$0x1, %eax
    1d9d:      	movq	%r12, %rsi
    1da0:      	callq	*%rax
    1da2:      	movq	%rax, %rcx
    1da5:      	xorl	%eax, %eax
    1da7:      	movq	%rbx, 0x8(%rsp)
    1dac:      	testq	%rbx, %rbx
    1daf:      	je	0x1fd0 <filter_char_buf_equal+0x370>
    1db5:      	testq	%rcx, %rcx
    1db8:      	je	0x1fd0 <filter_char_buf_equal+0x370>
    1dbe:      	movq	%rcx, 0x18(%rsp)
    1dc3:      	cmpl	$0x5, %r15d
    1dc7:      	jg	0x1e0a <filter_char_buf_equal+0x1aa>
    1dc9:      	movq	0x8(%rsp), %rax
    1dce:      	movb	%bpl, (%rax)
    1dd1:      	leaq	0x1(%rax), %rdi
    1dd5:      	movl	%ebp, %r12d
    1dd8:      	movl	$0x4, %eax
    1ddd:      	movq	0x20(%rsp), %rdx
    1de2:      	movl	%ebp, %esi
    1de4:      	callq	*%rax
    1de6:      	subl	%ebp, %r14d
    1de9:      	jbe	0x1e4f <filter_char_buf_equal+0x1ef>
    1deb:      	movq	0x8(%rsp), %rax
    1df0:      	leaq	(%rax,%r12), %rdi
    1df4:      	incq	%rdi
    1df7:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1dfe:      	movl	$0x4, %eax
    1e03:      	movq	0x18(%rsp), %rdx
    1e08:      	jmp	0x1e4a <filter_char_buf_equal+0x1ea>
    1e0a:      	movq	0x8(%rsp), %rax
    1e0f:      	movw	%bp, (%rax)
    1e12:      	leaq	0x2(%rax), %rdi
    1e16:      	movl	%ebp, %r12d
    1e19:      	movl	$0x4, %eax
    1e1e:      	movq	0x20(%rsp), %rdx
    1e23:      	movl	%ebp, %esi
    1e25:      	callq	*%rax
    1e27:      	subl	%ebp, %r14d
    1e2a:      	jbe	0x1e4f <filter_char_buf_equal+0x1ef>
    1e2c:      	movq	0x8(%rsp), %rax
    1e31:      	leaq	(%rax,%r12), %rdi
    1e35:      	addq	$0x2, %rdi
    1e39:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1e40:      	movl	$0x4, %eax
    1e45:      	movq	0x18(%rsp), %rdx
    1e4a:      	movl	%r14d, %esi
    1e4d:      	callq	*%rax
    1e4f:      	movl	%r13d, 0x4(%rsp)
    1e54:      	cmpl	$0x4, %r15d
    1e58:      	jle	0x1e94 <filter_char_buf_equal+0x234>
    1e5a:      	cmpl	$0x7, %r15d
    1e5e:      	jg	0x1ece <filter_char_buf_equal+0x26e>
    1e60:      	cmpl	$0x5, %r15d
    1e64:      	je	0x1f82 <filter_char_buf_equal+0x322>
    1e6a:      	cmpl	$0x6, %r15d
    1e6e:      	je	0x1f49 <filter_char_buf_equal+0x2e9>
    1e74:      	cmpl	$0x7, %r15d
    1e78:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1e7e:      	movq	(%rip), %rdi            # 0x1e85 <filter_char_buf_equal+0x225>
    1e85:      	leaq	0x4(%rsp), %rcx
    1e8a:      	movl	$0x1, %eax
    1e8f:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1e94:      	cmpl	$0x1, %r15d
    1e98:      	jle	0x1efe <filter_char_buf_equal+0x29e>
    1e9a:      	cmpl	$0x2, %r15d
    1e9e:      	je	0x1f6f <filter_char_buf_equal+0x30f>
    1ea4:      	cmpl	$0x3, %r15d
    1ea8:      	je	0x1f36 <filter_char_buf_equal+0x2d6>
    1eae:      	cmpl	$0x4, %r15d
    1eb2:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1eb8:      	movq	(%rip), %rdi            # 0x1ebf <filter_char_buf_equal+0x25f>
    1ebf:      	leaq	0x4(%rsp), %rcx
    1ec4:      	movl	$0x1, %eax
    1ec9:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1ece:      	cmpl	$0x8, %r15d
    1ed2:      	je	0x1f95 <filter_char_buf_equal+0x335>
    1ed8:      	cmpl	$0x9, %r15d
    1edc:      	je	0x1f5c <filter_char_buf_equal+0x2fc>
    1ede:      	cmpl	$0xa, %r15d
    1ee2:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1ee8:      	movq	(%rip), %rdi            # 0x1eef <filter_char_buf_equal+0x28f>
    1eef:      	leaq	0x4(%rsp), %rcx
    1ef4:      	movl	$0x1, %eax
    1ef9:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1efe:      	testl	%r15d, %r15d
    1f01:      	je	0x1f23 <filter_char_buf_equal+0x2c3>
    1f03:      	cmpl	$0x1, %r15d
    1f07:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1f0d:      	movq	(%rip), %rdi            # 0x1f14 <filter_char_buf_equal+0x2b4>
    1f14:      	leaq	0x4(%rsp), %rcx
    1f19:      	movl	$0x1, %eax
    1f1e:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f23:      	movq	(%rip), %rdi            # 0x1f2a <filter_char_buf_equal+0x2ca>
    1f2a:      	leaq	0x4(%rsp), %rcx
    1f2f:      	movl	$0x1, %eax
    1f34:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f36:      	movq	(%rip), %rdi            # 0x1f3d <filter_char_buf_equal+0x2dd>
    1f3d:      	leaq	0x4(%rsp), %rcx
    1f42:      	movl	$0x1, %eax
    1f47:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f49:      	movq	(%rip), %rdi            # 0x1f50 <filter_char_buf_equal+0x2f0>
    1f50:      	leaq	0x4(%rsp), %rcx
    1f55:      	movl	$0x1, %eax
    1f5a:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f5c:      	movq	(%rip), %rdi            # 0x1f63 <filter_char_buf_equal+0x303>
    1f63:      	leaq	0x4(%rsp), %rcx
    1f68:      	movl	$0x1, %eax
    1f6d:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f6f:      	movq	(%rip), %rdi            # 0x1f76 <filter_char_buf_equal+0x316>
    1f76:      	leaq	0x4(%rsp), %rcx
    1f7b:      	movl	$0x1, %eax
    1f80:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f82:      	movq	(%rip), %rdi            # 0x1f89 <filter_char_buf_equal+0x329>
    1f89:      	leaq	0x4(%rsp), %rcx
    1f8e:      	movl	$0x1, %eax
    1f93:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f95:      	movq	(%rip), %rdi            # 0x1f9c <filter_char_buf_equal+0x33c>
    1f9c:      	leaq	0x4(%rsp), %rcx
    1fa1:      	movl	$0x1, %eax
    1fa6:      	leaq	0x4(%rsp), %rsi
    1fab:      	callq	*%rax
    1fad:      	testq	%rax, %rax
    1fb0:      	je	0x1fce <filter_char_buf_equal+0x36e>
    1fb2:      	movq	%rax, %rdi
    1fb5:      	movl	$0x1, %eax
    1fba:      	movq	0x8(%rsp), %rsi
    1fbf:      	callq	*%rax
    1fc1:      	movq	%rax, %rcx
    1fc4:      	xorl	%eax, %eax
    1fc6:      	testq	%rcx, %rcx
    1fc9:      	setne	%al
    1fcc:      	jmp	0x1fd0 <filter_char_buf_equal+0x370>
    1fce:      	xorl	%eax, %eax
    1fd0:      	addq	$0x28, %rsp
    1fd4:      	popq	%rbx
    1fd5:      	popq	%r12
    1fd7:      	popq	%r13
    1fd9:      	popq	%r14
    1fdb:      	popq	%r15
    1fdd:      	popq	%rbp
    1fde:      	retq
    1fdf:      	nop

0000000000001fe0 <filter_char_buf_prefix>:
    1fe0:      	pushq	%rbp
    1fe1:      	pushq	%r15
    1fe3:      	pushq	%r14
    1fe5:      	pushq	%rbx
    1fe6:      	pushq	%rax
    1fe7:      	movl	%edx, %ebp
    1fe9:      	movq	%rsi, %rbx
    1fec:      	movl	%edi, 0x4(%rsp)
    1ff0:      	movl	$0x0, (%rsp)
    1ff7:      	movq	(%rip), %rdi            # 0x1ffe <filter_char_buf_prefix+0x1e>
    1ffe:      	leaq	0x4(%rsp), %rsi
    2003:      	movl	$0x1, %eax
    2008:      	callq	*%rax
    200a:      	movq	%rax, %r14
    200d:      	xorl	%eax, %eax
    200f:      	testl	%ebp, %ebp
    2011:      	je	0x2075 <filter_char_buf_prefix+0x95>
    2013:      	testq	%r14, %r14
    2016:      	je	0x2075 <filter_char_buf_prefix+0x95>
    2018:      	movq	(%rip), %rdi            # 0x201f <filter_char_buf_prefix+0x3f>
    201f:      	movq	%rsp, %rsi
    2022:      	movl	$0x1, %eax
    2027:      	callq	*%rax
    2029:      	testq	%rax, %rax
    202c:      	je	0x2073 <filter_char_buf_prefix+0x93>
    202e:      	cmpl	$0xff, %ebp
    2034:      	movl	$0xff, %esi
    2039:      	cmovbl	%ebp, %esi
    203c:      	leal	(,%rsi,8), %ecx
    2043:      	movl	%ecx, (%rax)
    2045:      	movq	%rax, %rdi
    2048:      	addq	$0x4, %rdi
    204c:      	movq	%rax, %r15
    204f:      	movl	$0x4, %eax
    2054:      	movq	%rbx, %rdx
    2057:      	callq	*%rax
    2059:      	movl	$0x1, %eax
    205e:      	movq	%r14, %rdi
    2061:      	movq	%r15, %rsi
    2064:      	callq	*%rax
    2066:      	movq	%rax, %rcx
    2069:      	xorl	%eax, %eax
    206b:      	testq	%rcx, %rcx
    206e:      	setne	%al
    2071:      	jmp	0x2075 <filter_char_buf_prefix+0x95>
    2073:      	xorl	%eax, %eax
    2075:      	addq	$0x8, %rsp
    2079:      	popq	%rbx
    207a:      	popq	%r14
    207c:      	popq	%r15
    207e:      	popq	%rbp
    207f:      	retq

0000000000002080 <filter_char_buf_postfix>:
    2080:      	pushq	%r15
    2082:      	pushq	%r14
    2084:      	pushq	%rbx
    2085:      	subq	$0x10, %rsp
    2089:      	movl	%edx, %ebx
    208b:      	movq	%rsi, %r14
    208e:      	movl	%edi, 0xc(%rsp)
    2092:      	movl	$0x0, 0x8(%rsp)
    209a:      	movq	(%rip), %rdi            # 0x20a1 <filter_char_buf_postfix+0x21>
    20a1:      	leaq	0xc(%rsp), %rsi
    20a6:      	movl	$0x1, %eax
    20ab:      	callq	*%rax
    20ad:      	movq	%rax, %r15
    20b0:      	xorl	%eax, %eax
    20b2:      	testl	%ebx, %ebx
    20b4:      	je	0x21c0 <filter_char_buf_postfix+0x140>
    20ba:      	testq	%r15, %r15
    20bd:      	je	0x21c0 <filter_char_buf_postfix+0x140>
    20c3:      	movq	(%rip), %rdi            # 0x20ca <filter_char_buf_postfix+0x4a>
    20ca:      	leaq	0x8(%rsp), %rsi
    20cf:      	movl	$0x1, %eax
    20d4:      	callq	*%rax
    20d6:      	testq	%rax, %rax
    20d9:      	je	0x21be <filter_char_buf_postfix+0x13e>
    20df:      	movq	%rax, %rsi
    20e2:      	cmpl	$0x7f, %ebx
    20e5:      	movl	$0x7f, %eax
    20ea:      	cmovbl	%ebx, %eax
    20ed:      	shll	$0x3, %eax
    20f0:      	movl	%eax, (%rsi)
    20f2:      	movl	%ebx, %eax
    20f4:      	leal	-0x4(%rbx), %ecx
    20f7:      	movq	%rsi, %rdx
    20fa:      	addq	$0x7, %rdx
    20fe:      	leal	-0x3(%rbx), %edi
    2101:      	leal	-0x2(%rbx), %r8d
    2105:      	decl	%ebx
    2107:      	movq	$-0x3, %r9
    210e:      	nop
    2110:      	leal	(%rbx,%r9), %r10d
    2114:      	addl	$0x3, %r10d
    2118:      	andl	$0xfff, %r10d           # imm = 0xFFF
    211f:      	movzbl	(%r14,%r10), %r10d
    2124:      	movb	%r10b, -0x3(%rdx)
    2128:      	leaq	(%rax,%r9), %r10
    212c:      	cmpq	$-0x2, %r10
    2130:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2132:      	leal	(%r8,%r9), %r11d
    2136:      	addl	$0x3, %r11d
    213a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    2141:      	movzbl	(%r14,%r11), %r11d
    2146:      	movb	%r11b, -0x2(%rdx)
    214a:      	cmpq	$-0x1, %r10
    214e:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2150:      	leal	(%rdi,%r9), %r10d
    2154:      	addl	$0x3, %r10d
    2158:      	andl	$0xfff, %r10d           # imm = 0xFFF
    215f:      	movzbl	(%r14,%r10), %r10d
    2164:      	movb	%r10b, -0x1(%rdx)
    2168:      	movq	%rax, %r10
    216b:      	addq	%r9, %r10
    216e:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2170:      	cmpq	$-0x7f, %r9
    2174:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2176:      	leal	(%rcx,%r9), %r10d
    217a:      	addl	$0x3, %r10d
    217e:      	andl	$0xfff, %r10d           # imm = 0xFFF
    2185:      	movzbl	(%r14,%r10), %r10d
    218a:      	movb	%r10b, (%rdx)
    218d:      	addq	$0x4, %rdx
    2191:      	leaq	(%rax,%r9), %r10
    2195:      	addq	$-0x4, %r10
    2199:      	addq	$-0x4, %r9
    219d:      	cmpq	$-0x3, %r10
    21a1:      	jne	0x2110 <filter_char_buf_postfix+0x90>
    21a7:      	movl	$0x1, %eax
    21ac:      	movq	%r15, %rdi
    21af:      	callq	*%rax
    21b1:      	movq	%rax, %rcx
    21b4:      	xorl	%eax, %eax
    21b6:      	testq	%rcx, %rcx
    21b9:      	setne	%al
    21bc:      	jmp	0x21c0 <filter_char_buf_postfix+0x140>
    21be:      	xorl	%eax, %eax
    21c0:      	addq	$0x10, %rsp
    21c4:      	popq	%rbx
    21c5:      	popq	%r14
    21c7:      	popq	%r15
    21c9:      	retq
    21ca:      	nopw	(%rax,%rax)

00000000000021d0 <filter_file_type>:
    21d0:      	pushq	%rbx
    21d1:      	subq	$0x10, %rsp
    21d5:      	movw	$0x0, 0xe(%rsp)
    21dc:      	movl	(%rsi), %eax
    21de:      	cmpq	$0x1000, %rax           # imm = 0x1000
    21e4:      	ja	0x226c <filter_file_type+0x9c>
    21ea:      	movq	%rdi, %rbx
    21ed:      	leaq	(%rsi,%rax), %rcx
    21f1:      	addq	$0x8, %rcx
    21f5:      	leaq	0xe(%rsp), %rdi
    21fa:      	movl	$0x2, %edx
    21ff:      	movl	$0x4, %eax
    2204:      	movl	(%rsi), %ecx
    2206:      	leaq	(%rsi,%rcx), %rdx
    220a:      	addq	$0x8, %rdx
    220e:      	movl	$0x2, %esi
    2213:      	callq	*%rax
    2215:      	movl	0x10(%rbx), %edx
    2218:      	testl	%edx, %edx
    221a:      	je	0x226c <filter_file_type+0x9c>
    221c:      	movzwl	0xe(%rsp), %ecx
    2221:      	andl	$0xf000, %ecx           # imm = 0xF000
    2227:      	movl	$0x1, %eax
    222c:      	cmpl	%ecx, %edx
    222e:      	je	0x226e <filter_file_type+0x9e>
    2230:      	movl	0x8(%rbx), %edx
    2233:      	cmpl	$0xc, %edx
    2236:      	jbe	0x226c <filter_file_type+0x9c>
    2238:      	movl	0x14(%rbx), %esi
    223b:      	testl	%esi, %esi
    223d:      	je	0x226c <filter_file_type+0x9c>
    223f:      	cmpl	%ecx, %esi
    2241:      	je	0x226e <filter_file_type+0x9e>
    2243:      	cmpl	$0x11, %edx
    2246:      	jb	0x226c <filter_file_type+0x9c>
    2248:      	movl	0x18(%rbx), %esi
    224b:      	testl	%esi, %esi
    224d:      	je	0x226c <filter_file_type+0x9c>
    224f:      	cmpl	%ecx, %esi
    2251:      	je	0x226e <filter_file_type+0x9e>
    2253:      	cmpl	$0x15, %edx
    2256:      	jb	0x226c <filter_file_type+0x9c>
    2258:      	movl	0x1c(%rbx), %edx
    225b:      	testl	%edx, %edx
    225d:      	je	0x226c <filter_file_type+0x9c>
    225f:      	xorl	%eax, %eax
    2261:      	cmpl	%ecx, %edx
    2263:      	sete	%al
    2266:      	addq	$0x10, %rsp
    226a:      	popq	%rbx
    226b:      	retq
    226c:      	xorl	%eax, %eax
    226e:      	addq	$0x10, %rsp
    2272:      	popq	%rbx
    2273:      	retq
    2274:      	nopw	%cs:(%rax,%rax)

0000000000002280 <filter_char_substring>:
    2280:      	pushq	%rbp
    2281:      	pushq	%r15
    2283:      	pushq	%r14
    2285:      	pushq	%r13
    2287:      	pushq	%r12
    2289:      	pushq	%rbx
    228a:      	pushq	%rax
    228b:      	movq	%rsi, %r15
    228e:      	movq	%rdi, %r14
    2291:      	movl	%edx, %ebp
    2293:      	testl	%ecx, %ecx
    2295:      	je	0x236d <filter_char_substring+0xed>
    229b:      	testl	%edx, %edx
    229d:      	je	0x241d <filter_char_substring+0x19d>
    22a3:      	leaq	0x4(%rsp), %r13
    22a8:      	xorl	%ebx, %ebx
    22aa:      	xorl	%r12d, %r12d
    22ad:      	nopl	(%rax)
    22b0:      	movl	0x10(%r14,%rbx,4), %eax
    22b5:      	movl	%eax, 0x4(%rsp)
    22b9:      	movl	$0x1, %eax
    22be:      	movq	(%rip), %rdi            # 0x22c5 <filter_char_substring+0x45>
    22c5:      	movq	%r13, %rsi
    22c8:      	callq	*%rax
    22ca:      	testq	%rax, %rax
    22cd:      	je	0x24b0 <filter_char_substring+0x230>
    22d3:      	movq	%r15, %rdx
    22d6:      	xorl	%ecx, %ecx
    22d8:      	jmp	0x22eb <filter_char_substring+0x6b>
    22da:      	nopw	(%rax,%rax)
    22e0:      	incq	%rcx
    22e3:      	incq	%rdx
    22e6:      	cmpq	%rbp, %rcx
    22e9:      	je	0x2348 <filter_char_substring+0xc8>
    22eb:      	xorl	%esi, %esi
    22ed:      	nopl	(%rax)
    22f0:      	leaq	(%rcx,%rsi), %rdi
    22f4:      	cmpq	%rbp, %rdi
    22f7:      	jae	0x22e0 <filter_char_substring+0x60>
    22f9:      	movsbl	(%rax,%rsi), %edi
    22fd:      	testl	%edi, %edi
    22ff:      	je	0x2340 <filter_char_substring+0xc0>
    2301:      	movsbl	(%rdx,%rsi), %r9d
    2306:      	leal	-0x41(%r9), %r10d
    230a:      	movl	%r9d, %r8d
    230d:      	orl	$0x20, %r8d
    2311:      	cmpl	$0x1a, %r10d
    2315:      	cmovael	%r9d, %r8d
    2319:      	leal	-0x41(%rdi), %r10d
    231d:      	movl	%edi, %r9d
    2320:      	orl	$0x20, %r9d
    2324:      	cmpl	$0x1a, %r10d
    2328:      	cmovael	%edi, %r9d
    232c:      	cmpq	$0x62, %rsi
    2330:      	ja	0x22e0 <filter_char_substring+0x60>
    2332:      	incq	%rsi
    2335:      	cmpl	%r9d, %r8d
    2338:      	je	0x22f0 <filter_char_substring+0x70>
    233a:      	jmp	0x22e0 <filter_char_substring+0x60>
    233c:      	nopl	(%rax)
    2340:      	testl	%ecx, %ecx
    2342:      	jns	0x24c1 <filter_char_substring+0x241>
    2348:      	leal	0xc(%r12), %eax
    234d:      	cmpl	0x8(%r14), %eax
    2351:      	jae	0x24b0 <filter_char_substring+0x230>
    2357:      	addl	$0x4, %r12d
    235b:      	incq	%rbx
    235e:      	cmpq	$0x64, %rbx
    2362:      	jne	0x22b0 <filter_char_substring+0x30>
    2368:      	jmp	0x24b0 <filter_char_substring+0x230>
    236d:      	testl	%edx, %edx
    236f:      	je	0x2462 <filter_char_substring+0x1e2>
    2375:      	leaq	0x4(%rsp), %r13
    237a:      	xorl	%ebx, %ebx
    237c:      	xorl	%r12d, %r12d
    237f:      	nop
    2380:      	movl	0x10(%r14,%rbx,4), %eax
    2385:      	movl	%eax, 0x4(%rsp)
    2389:      	movl	$0x1, %eax
    238e:      	movq	(%rip), %rdi            # 0x2395 <filter_char_substring+0x115>
    2395:      	movq	%r13, %rsi
    2398:      	callq	*%rax
    239a:      	testq	%rax, %rax
    239d:      	je	0x24b0 <filter_char_substring+0x230>
    23a3:      	movq	%r15, %rdx
    23a6:      	xorl	%ecx, %ecx
    23a8:      	jmp	0x23bb <filter_char_substring+0x13b>
    23aa:      	nopw	(%rax,%rax)
    23b0:      	incq	%rcx
    23b3:      	incq	%rdx
    23b6:      	cmpq	%rbp, %rcx
    23b9:      	je	0x23f8 <filter_char_substring+0x178>
    23bb:      	xorl	%esi, %esi
    23bd:      	nopl	(%rax)
    23c0:      	leaq	(%rcx,%rsi), %rdi
    23c4:      	cmpq	%rbp, %rdi
    23c7:      	jae	0x23b0 <filter_char_substring+0x130>
    23c9:      	movzbl	(%rax,%rsi), %edi
    23cd:      	testb	%dil, %dil
    23d0:      	je	0x23f0 <filter_char_substring+0x170>
    23d2:      	cmpq	$0x62, %rsi
    23d6:      	ja	0x23b0 <filter_char_substring+0x130>
    23d8:      	leaq	0x1(%rsi), %r8
    23dc:      	cmpb	%dil, (%rdx,%rsi)
    23e0:      	movq	%r8, %rsi
    23e3:      	je	0x23c0 <filter_char_substring+0x140>
    23e5:      	jmp	0x23b0 <filter_char_substring+0x130>
    23e7:      	nopw	(%rax,%rax)
    23f0:      	testl	%ecx, %ecx
    23f2:      	jns	0x24c1 <filter_char_substring+0x241>
    23f8:      	leal	0xc(%r12), %eax
    23fd:      	cmpl	0x8(%r14), %eax
    2401:      	jae	0x24b0 <filter_char_substring+0x230>
    2407:      	addl	$0x4, %r12d
    240b:      	incq	%rbx
    240e:      	cmpq	$0x64, %rbx
    2412:      	jne	0x2380 <filter_char_substring+0x100>
    2418:      	jmp	0x24b0 <filter_char_substring+0x230>
    241d:      	movl	$0x10, %ebx
    2422:      	movq	(%rip), %r15            # 0x2429 <filter_char_substring+0x1a9>
    2429:      	leaq	0x4(%rsp), %r12
    242e:      	nop
    2430:      	movl	(%r14,%rbx), %eax
    2434:      	movl	%eax, 0x4(%rsp)
    2438:      	movl	$0x1, %eax
    243d:      	movq	%r15, %rdi
    2440:      	movq	%r12, %rsi
    2443:      	callq	*%rax
    2445:      	testq	%rax, %rax
    2448:      	je	0x24b0 <filter_char_substring+0x230>
    244a:      	addq	$0x4, %rbx
    244e:      	leal	-0x8(%rbx), %eax
    2451:      	cmpl	0x8(%r14), %eax
    2455:      	jae	0x24b0 <filter_char_substring+0x230>
    2457:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    245e:      	jne	0x2430 <filter_char_substring+0x1b0>
    2460:      	jmp	0x24b0 <filter_char_substring+0x230>
    2462:      	movl	$0x10, %ebx
    2467:      	movq	(%rip), %r15            # 0x246e <filter_char_substring+0x1ee>
    246e:      	leaq	0x4(%rsp), %r12
    2473:      	nopw	%cs:(%rax,%rax)
    2480:      	movl	(%r14,%rbx), %eax
    2484:      	movl	%eax, 0x4(%rsp)
    2488:      	movl	$0x1, %eax
    248d:      	movq	%r15, %rdi
    2490:      	movq	%r12, %rsi
    2493:      	callq	*%rax
    2495:      	testq	%rax, %rax
    2498:      	je	0x24b0 <filter_char_substring+0x230>
    249a:      	addq	$0x4, %rbx
    249e:      	leal	-0x8(%rbx), %eax
    24a1:      	cmpl	0x8(%r14), %eax
    24a5:      	jae	0x24b0 <filter_char_substring+0x230>
    24a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    24ae:      	jne	0x2480 <filter_char_substring+0x200>
    24b0:      	xorl	%eax, %eax
    24b2:      	addq	$0x8, %rsp
    24b6:      	popq	%rbx
    24b7:      	popq	%r12
    24b9:      	popq	%r13
    24bb:      	popq	%r14
    24bd:      	popq	%r15
    24bf:      	popq	%rbp
    24c0:      	retq
    24c1:      	movl	$0x1, %eax
    24c6:      	jmp	0x24b2 <filter_char_substring+0x232>
    24c8:      	nopl	(%rax,%rax)

00000000000024d0 <do_action>:
    24d0:      	pushq	%rbp
    24d1:      	pushq	%r15
    24d3:      	pushq	%r14
    24d5:      	pushq	%r13
    24d7:      	pushq	%r12
    24d9:      	pushq	%rbx
    24da:      	subq	$0x78, %rsp
    24de:      	movl	%r8d, %ebp
    24e1:      	movq	%rcx, 0x20(%rsp)
    24e6:      	movq	%rdx, %r15
    24e9:      	movl	%esi, %r14d
    24ec:      	movq	%rdi, %rbx
    24ef:      	movl	%esi, %eax
    24f1:      	movslq	0x4(%rdx,%rax,4), %r12
    24f6:      	movl	$0x0, 0x54(%rsp)
    24fe:      	movq	(%rip), %rdi            # 0x2505 <do_action+0x35>
    2505:      	leaq	0x54(%rsp), %rsi
    250a:      	movl	$0x1, %eax
    250f:      	callq	*%rax
    2511:      	movq	%rax, %r13
    2514:      	xorl	%eax, %eax
    2516:      	testq	%r13, %r13
    2519:      	je	0x2ee3 <do_action+0xa13>
    251f:      	cmpl	$0x7, %r12d
    2523:      	jg	0x254d <do_action+0x7d>
    2525:      	cmpl	$0x3, %r12d
    2529:      	jg	0x2589 <do_action+0xb9>
    252b:      	cmpl	$0x1, %r12d
    252f:      	jg	0x279e <do_action+0x2ce>
    2535:      	testl	%r12d, %r12d
    2538:      	je	0x2a24 <do_action+0x554>
    253e:      	cmpl	$0x1, %r12d
    2542:      	je	0x27b7 <do_action+0x2e7>
    2548:      	jmp	0x2ed9 <do_action+0xa09>
    254d:      	cmpl	$0xb, %r12d
    2551:      	jg	0x268e <do_action+0x1be>
    2557:      	leal	-0xa(%r12), %ecx
    255c:      	cmpl	$0x2, %ecx
    255f:      	jb	0x28c2 <do_action+0x3f2>
    2565:      	cmpl	$0x8, %r12d
    2569:      	je	0x298c <do_action+0x4bc>
    256f:      	cmpl	$0x9, %r12d
    2573:      	jne	0x2ed9 <do_action+0xa09>
    2579:      	movq	%r13, %rbx
    257c:      	incl	%r14d
    257f:      	movl	0x4(%r15,%r14,4), %eax
    2584:      	jmp	0x2ae2 <do_action+0x612>
    2589:      	leal	-0x6(%r12), %eax
    258e:      	cmpl	$0x2, %eax
    2591:      	jb	0x297b <do_action+0x4ab>
    2597:      	cmpl	$0x4, %r12d
    259b:      	je	0x2999 <do_action+0x4c9>
    25a1:      	cmpl	$0x5, %r12d
    25a5:      	jne	0x2ed9 <do_action+0xa09>
    25ab:      	leal	0x1(%r14), %eax
    25af:      	movl	0x4(%r15,%rax,4), %eax
    25b4:      	addl	$0x2, %r14d
    25b8:      	andl	$0x7, %eax
    25bb:      	cmpl	$0x4, %eax
    25be:      	ja	0x2ed9 <do_action+0xa09>
    25c4:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    25cd:      	jne	0x2ed9 <do_action+0xa09>
    25d3:      	movl	0x4(%r15,%r14,4), %ebx
    25d8:      	movq	0x5e78(%r13,%rax,8), %rax
    25e0:      	movl	$0x0, 0xc(%rsp)
    25e8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    25ed:      	movl	0x90(%r13,%rax), %eax
    25f5:      	movl	%eax, 0x8(%rsp)
    25f9:      	movl	$0xe, %eax
    25fe:      	callq	*%rax
    2600:      	shrq	$0x20, %rax
    2604:      	movq	%rax, (%rsp)
    2608:      	movq	(%rip), %rdi            # 0x260f <do_action+0x13f>
    260f:      	movq	%rsp, %rsi
    2612:      	movl	$0x1, %eax
    2617:      	callq	*%rax
    2619:      	testq	%rax, %rax
    261c:      	je	0x2ed9 <do_action+0xa09>
    2622:      	andl	$0x7, %ebx
    2625:      	cmpl	$0x4, %ebx
    2628:      	ja	0x2ed9 <do_action+0xa09>
    262e:      	cmpl	$0x0, 0x5ea0(%r13,%rbx,4)
    2637:      	jne	0x2ed9 <do_action+0xa09>
    263d:      	movq	0x5e78(%r13,%rbx,8), %rcx
    2645:      	movl	$0x0, 0xc(%rsp)
    264d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    2653:      	movl	0x90(%r13,%rcx), %ecx
    265b:      	movl	%ecx, 0x8(%rsp)
    265f:      	movq	%rax, %r15
    2662:      	movl	$0xe, %eax
    2667:      	callq	*%rax
    2669:      	shrq	$0x20, %rax
    266d:      	movq	%rax, (%rsp)
    2671:      	movq	(%rip), %rdi            # 0x2678 <do_action+0x1a8>
    2678:      	xorl	%ecx, %ecx
    267a:      	movq	%rsp, %rsi
    267d:      	movl	$0x2, %eax
    2682:      	movq	%r15, %rdx
    2685:      	xorl	%ecx, %ecx
    2687:      	callq	*%rax
    2689:      	jmp	0x2ed9 <do_action+0xa09>
    268e:      	cmpl	$0xc, %r12d
    2692:      	je	0x2b06 <do_action+0x636>
    2698:      	cmpl	$0xd, %r12d
    269c:      	je	0x29ac <do_action+0x4dc>
    26a2:      	cmpl	$0xe, %r12d
    26a6:      	jne	0x2ed9 <do_action+0xa09>
    26ac:      	movq	%rbx, 0x48(%rsp)
    26b1:      	movq	%r13, %rbx
    26b4:      	leal	0x2(%r14), %eax
    26b8:      	movl	$0x9, %r13d
    26be:      	testb	%bpl, %bpl
    26c1:      	je	0x2b1a <do_action+0x64a>
    26c7:      	movl	%eax, 0x20(%rsp)
    26cb:      	movl	%eax, %eax
    26cd:      	movl	0x4(%r15,%rax,4), %ebp
    26d2:      	incl	%r14d
    26d5:      	movl	0x4(%r15,%r14,4), %r14d
    26da:      	movq	%rbx, %rsi
    26dd:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    26e4:      	movq	(%rip), %rdi            # 0x26eb <do_action+0x21b>
    26eb:      	movl	$0x1, %eax
    26f0:      	callq	*%rax
    26f2:      	movl	$0x8, %r13d
    26f8:      	testq	%rax, %rax
    26fb:      	je	0x2eaf <do_action+0x9df>
    2701:      	andl	$0x7, %r14d
    2705:      	leaq	(%r14,%r14,2), %r14
    2709:      	cmpb	$0x3, 0x211(%rax,%r14,8)
    2712:      	jne	0x2b88 <do_action+0x6b8>
    2718:      	movl	0x208(%rax,%r14,8), %esi
    2720:      	movq	0x48(%rsp), %rdi
    2725:      	xorl	%edx, %edx
    2727:      	movq	%rax, %r15
    272a:      	callq	0x2f00 <read_reg>
    272f:      	addq	0x200(%r15,%r14,8), %rax
    2737:      	movq	%rax, (%rsp)
    273b:      	movl	%ebp, 0x8(%rsp)
    273f:      	movl	$0xe, %eax
    2744:      	callq	*%rax
    2746:      	movq	%rax, 0x28(%rsp)
    274b:      	movq	(%rip), %rdi            # 0x2752 <do_action+0x282>
    2752:      	leaq	0x28(%rsp), %rsi
    2757:      	movl	$0x1, %eax
    275c:      	callq	*%rax
    275e:      	testq	%rax, %rax
    2761:      	je	0x2e09 <do_action+0x939>
    2767:      	movq	%rax, %r14
    276a:      	movl	$0xe0011, 0x10(%rsp)    # imm = 0xE0011
    2772:      	movq	$0x377, 0x14(%rsp)      # imm = 0x377
    277b:      	movq	(%rip), %rdi            # 0x2782 <do_action+0x2b2>
    2782:      	leaq	0x10(%rsp), %rsi
    2787:      	movl	$0x1, %eax
    278c:      	callq	*%rax
    278e:      	testq	%rax, %rax
    2791:      	je	0x2e7b <do_action+0x9ab>
    2797:      	incl	(%rax)
    2799:      	jmp	0x2e9f <do_action+0x9cf>
    279e:      	movl	$0x9, %eax
    27a3:      	cmpl	$0x2, %r12d
    27a7:      	je	0x2adf <do_action+0x60f>
    27ad:      	cmpl	$0x3, %r12d
    27b1:      	jne	0x2ed9 <do_action+0xa09>
    27b7:      	leal	0x1(%r14), %eax
    27bb:      	movl	0x4(%r15,%rax,4), %ebp
    27c0:      	addl	$0x2, %r14d
    27c4:      	movl	0x4(%r15,%r14,4), %ebx
    27c9:      	movl	$0x0, 0x10(%rsp)
    27d1:      	movq	(%rip), %rdi            # 0x27d8 <do_action+0x308>
    27d8:      	leaq	0x10(%rsp), %rsi
    27dd:      	movl	$0x1, %eax
    27e2:      	callq	*%rax
    27e4:      	xorl	%r15d, %r15d
    27e7:      	testq	%rax, %rax
    27ea:      	je	0x2bb8 <do_action+0x6e8>
    27f0:      	movq	%rax, 0x20(%rsp)
    27f5:      	andl	$0x7, %ebp
    27f8:      	cmpl	$0x4, %ebp
    27fb:      	movl	$0x0, %eax
    2800:      	ja	0x2bba <do_action+0x6ea>
    2806:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    280f:      	jne	0x2bba <do_action+0x6ea>
    2815:      	movq	0x5e78(%r13,%rbp,8), %rax
    281d:      	movl	$0x0, 0xc(%rsp)
    2825:      	andl	$0x7ff, %eax            # imm = 0x7FF
    282a:      	movl	0x90(%r13,%rax), %eax
    2832:      	movl	%eax, 0x8(%rsp)
    2836:      	movl	$0xe, %eax
    283b:      	callq	*%rax
    283d:      	shrq	$0x20, %rax
    2841:      	movq	%rax, (%rsp)
    2845:      	cmpl	$0x1, %r12d
    2849:      	jne	0x2b91 <do_action+0x6c1>
    284f:      	andl	$0x7, %ebx
    2852:      	cmpl	$0x4, %ebx
    2855:      	ja	0x2bb8 <do_action+0x6e8>
    285b:      	cmpl	$0x0, 0x5ea0(%r13,%rbx,4)
    2864:      	movl	$0x0, %eax
    2869:      	jne	0x2bba <do_action+0x6ea>
    286f:      	movq	0x5e78(%r13,%rbx,8), %rax
    2877:      	andl	$0x7ff, %eax            # imm = 0x7FF
    287c:      	leaq	(%rax,%r13), %rdx
    2880:      	addq	$0x90, %rdx
    2887:      	movl	0x90(%r13,%rax), %esi
    288f:      	andl	$0xfff, %esi            # imm = 0xFFF
    2895:      	addq	$0x8, %rsi
    2899:      	movl	$0x4, %eax
    289e:      	movq	0x20(%rsp), %rbx
    28a3:      	movq	%rbx, %rdi
    28a6:      	callq	*%rax
    28a8:      	movq	(%rip), %rdi            # 0x28af <do_action+0x3df>
    28af:      	xorl	%r15d, %r15d
    28b2:      	movq	%rsp, %rsi
    28b5:      	movl	$0x2, %eax
    28ba:      	movq	%rbx, %rdx
    28bd:      	jmp	0x2972 <do_action+0x4a2>
    28c2:      	incl	%r14d
    28c5:      	movl	0x4(%r15,%r14,4), %ecx
    28ca:      	andl	$0x7, %ecx
    28cd:      	xorl	%r15d, %r15d
    28d0:      	cmpl	$0x4, %ecx
    28d3:      	ja	0x2bba <do_action+0x6ea>
    28d9:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    28e2:      	jne	0x2bba <do_action+0x6ea>
    28e8:      	movq	0x5e78(%r13,%rcx,8), %rcx
    28f0:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    28f6:      	movq	0xb8(%r13,%rcx), %rcx
    28fe:      	movq	%rcx, 0x10(%rsp)
    2903:      	testq	%rcx, %rcx
    2906:      	je	0x2bba <do_action+0x6ea>
    290c:      	cmpl	$0xa, %r12d
    2910:      	jne	0x2ba2 <do_action+0x6d2>
    2916:      	movl	$0xe, %eax
    291b:      	callq	*%rax
    291d:      	movq	%rax, %rbx
    2920:      	shrq	$0x20, %rax
    2924:      	movl	%eax, (%rsp)
    2927:      	movq	(%rip), %rdi            # 0x292e <do_action+0x45e>
    292e:      	movq	%rsp, %rsi
    2931:      	movl	$0x1, %eax
    2936:      	callq	*%rax
    2938:      	movq	%rax, %rcx
    293b:      	testq	%rax, %rax
    293e:      	movl	$0x0, %eax
    2943:      	je	0x2bba <do_action+0x6ea>
    2949:      	movl	(%rcx), %eax
    294b:      	movl	%eax, (%rsp)
    294e:      	movl	%ebx, 0x4(%rsp)
    2952:      	movq	0x8(%rcx), %rax
    2956:      	movq	%rax, 0x8(%rsp)
    295b:      	movq	(%rip), %rdi            # 0x2962 <do_action+0x492>
    2962:      	xorl	%r15d, %r15d
    2965:      	leaq	0x10(%rsp), %rsi
    296a:      	movq	%rsp, %rdx
    296d:      	movl	$0x2, %eax
    2972:      	xorl	%ecx, %ecx
    2974:      	callq	*%rax
    2976:      	jmp	0x2bb8 <do_action+0x6e8>
    297b:      	incl	%r14d
    297e:      	movl	0x4(%r15,%r14,4), %eax
    2983:      	movl	%eax, 0x78(%r13)
    2987:      	jmp	0x2ed9 <do_action+0xa09>
    298c:      	movq	0x20(%rsp), %rax
    2991:      	movb	$0x0, (%rax)
    2994:      	jmp	0x2ed9 <do_action+0xa09>
    2999:      	movq	%r13, %rbx
    299c:      	incl	%r14d
    299f:      	movzbl	%bpl, %r13d
    29a3:      	xorq	$0x5, %r13
    29a7:      	jmp	0x2eb4 <do_action+0x9e4>
    29ac:      	movl	$0xe, %eax
    29b1:      	callq	*%rax
    29b3:      	movq	%rax, 0x28(%rsp)
    29b8:      	movq	(%rip), %rdi            # 0x29bf <do_action+0x4ef>
    29bf:      	leaq	0x28(%rsp), %rsi
    29c4:      	movl	$0x1, %eax
    29c9:      	callq	*%rax
    29cb:      	testq	%rax, %rax
    29ce:      	je	0x2ed9 <do_action+0xa09>
    29d4:      	movq	0x4(%rax), %rax
    29d8:      	movq	%rax, 0x10(%rsp)
    29dd:      	movl	$0x2, 0x18(%rsp)
    29e5:      	movq	(%rip), %rdi            # 0x29ec <do_action+0x51c>
    29ec:      	leaq	0x10(%rsp), %rsi
    29f1:      	movl	$0x1, %eax
    29f6:      	callq	*%rax
    29f8:      	movl	$0x1, 0x34(%rsp)
    2a00:      	testq	%rax, %rax
    2a03:      	je	0x2b22 <do_action+0x652>
    2a09:      	lock
    2a0a:      	incl	(%rax)
    2a0c:      	movq	(%rip), %rdi            # 0x2a13 <do_action+0x543>
    2a13:      	leaq	0x28(%rsp), %rsi
    2a18:      	movl	$0x3, %eax
    2a1d:      	callq	*%rax
    2a1f:      	jmp	0x2ed9 <do_action+0xa09>
    2a24:      	movq	%rbx, 0x48(%rsp)
    2a29:      	leal	0x1(%r14), %eax
    2a2d:      	movl	0x4(%r15,%rax,4), %ebp
    2a32:      	leal	0x2(%r14), %eax
    2a36:      	movl	0x4(%r15,%rax,4), %ebx
    2a3b:      	movl	$0x7d, %eax
    2a40:      	callq	*%rax
    2a42:      	movq	%rax, 0x68(%rsp)
    2a47:      	movq	%rax, (%rsp)
    2a4b:      	movl	$0x0, 0x28(%rsp)
    2a53:      	movq	%rbp, 0x70(%rsp)
    2a58:      	testq	%rbp, %rbp
    2a5b:      	je	0x2d8a <do_action+0x8ba>
    2a61:      	movq	(%rip), %rdi            # 0x2a68 <do_action+0x598>
    2a68:      	leaq	0x28(%rsp), %rsi
    2a6d:      	movl	$0x1, %eax
    2a72:      	callq	*%rax
    2a74:      	testq	%rax, %rax
    2a77:      	je	0x2d8a <do_action+0x8ba>
    2a7d:      	movq	%rax, 0x40(%rsp)
    2a82:      	movq	%rax, %rbp
    2a85:      	movq	(%rip), %rdi            # 0x2a8c <do_action+0x5bc>
    2a8c:      	leaq	0x28(%rsp), %rsi
    2a91:      	movl	$0x1, %eax
    2a96:      	callq	*%rax
    2a98:      	movq	%rax, %rdx
    2a9b:      	movq	0x60(%r13), %rax
    2a9f:      	movq	%rax, (%rbp)
    2aa3:      	movq	0x70(%r13), %rax
    2aa7:      	movq	%rbp, 0x38(%rsp)
    2aac:      	movq	%rax, 0x8(%rbp)
    2ab0:      	xorl	%eax, %eax
    2ab2:      	movq	%rax, 0x60(%rsp)
    2ab7:      	movl	$0x0, %eax
    2abc:      	cmpl	$0x2, %ebx
    2abf:      	je	0x2bcc <do_action+0x6fc>
    2ac5:      	cmpl	$0x1, %ebx
    2ac8:      	je	0x2bc8 <do_action+0x6f8>
    2ace:      	testl	%ebx, %ebx
    2ad0:      	jne	0x2d8a <do_action+0x8ba>
    2ad6:      	movl	0x7c(%r13), %eax
    2ada:      	jmp	0x2bcc <do_action+0x6fc>
    2adf:      	movq	%r13, %rbx
    2ae2:      	movl	$0x3, %r13d
    2ae8:      	testb	%bpl, %bpl
    2aeb:      	je	0x2eb4 <do_action+0x9e4>
    2af1:      	movslq	%eax, %rdi
    2af4:      	movl	$0x6d, %eax
    2af9:      	callq	*%rax
    2afb:      	movl	$0x2, %r13d
    2b01:      	jmp	0x2eb4 <do_action+0x9e4>
    2b06:      	movq	%r13, %rbx
    2b09:      	addl	$0x3, %r14d
    2b0d:      	movzbl	%bpl, %r13d
    2b11:      	xorq	$0x7, %r13
    2b15:      	jmp	0x2eb4 <do_action+0x9e4>
    2b1a:      	movl	%eax, %r14d
    2b1d:      	jmp	0x2eb4 <do_action+0x9e4>
    2b22:      	movq	(%rip), %rdi            # 0x2b29 <do_action+0x659>
    2b29:      	leaq	0x10(%rsp), %rsi
    2b2e:      	leaq	0x34(%rsp), %rdx
    2b33:      	movl	$0x1, %ecx
    2b38:      	movl	$0x2, %eax
    2b3d:      	callq	*%rax
    2b3f:      	testq	%rax, %rax
    2b42:      	je	0x2a0c <do_action+0x53c>
    2b48:      	movq	%rax, %r15
    2b4b:      	negl	%eax
    2b4d:      	movw	%ax, (%rsp)
    2b51:      	movw	$0x3, 0x2(%rsp)
    2b58:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    2b62:      	movq	%rax, 0x4(%rsp)
    2b67:      	movq	(%rip), %rdi            # 0x2b6e <do_action+0x69e>
    2b6e:      	movq	%rsp, %rsi
    2b71:      	movl	$0x1, %eax
    2b76:      	callq	*%rax
    2b78:      	testq	%rax, %rax
    2b7b:      	je	0x2e28 <do_action+0x958>
    2b81:      	incl	(%rax)
    2b83:      	jmp	0x2e4a <do_action+0x97a>
    2b88:      	orb	$0x20, 0x1(%rbx)
    2b8c:      	jmp	0x2eaf <do_action+0x9df>
    2b91:      	movq	(%rip), %rdi            # 0x2b98 <do_action+0x6c8>
    2b98:      	movq	%rsp, %rsi
    2b9b:      	movl	$0x3, %eax
    2ba0:      	jmp	0x2bb3 <do_action+0x6e3>
    2ba2:      	movq	(%rip), %rdi            # 0x2ba9 <do_action+0x6d9>
    2ba9:      	leaq	0x10(%rsp), %rsi
    2bae:      	movl	$0x3, %eax
    2bb3:      	callq	*%rax
    2bb5:      	movq	%rax, %r15
    2bb8:      	xorl	%eax, %eax
    2bba:      	testl	%r15d, %r15d
    2bbd:      	jne	0x2ee3 <do_action+0xa13>
    2bc3:      	jmp	0x2ed9 <do_action+0xa09>
    2bc8:      	movl	0x10(%r13), %eax
    2bcc:      	movl	%eax, %eax
    2bce:      	movq	0x38(%rsp), %rcx
    2bd3:      	movq	%rax, 0x10(%rcx)
    2bd7:      	movq	0x40(%rsp), %rdi
    2bdc:      	addq	$0x18, %rdi
    2be0:      	movl	$0xc8, %ecx
    2be5:      	movl	$0x4, %eax
    2bea:      	movq	%rdi, 0x40(%rsp)
    2bef:      	movl	$0xc8, %esi
    2bf4:      	callq	*%rax
    2bf6:      	xorl	%ebx, %ebx
    2bf8:      	movq	%r13, 0x58(%rsp)
    2bfd:      	jmp	0x2c0d <do_action+0x73d>
    2bff:      	addq	$0x4, %rbx
    2c03:      	cmpq	$0x14, %rbx
    2c07:      	je	0x2d38 <do_action+0x868>
    2c0d:      	movl	$0x0, 0x10(%rsp)
    2c15:      	movl	$0x1, %eax
    2c1a:      	movq	(%rip), %rdi            # 0x2c21 <do_action+0x751>
    2c21:      	leaq	0x10(%rsp), %rsi
    2c26:      	callq	*%rax
    2c28:      	testq	%rax, %rax
    2c2b:      	je	0x2d38 <do_action+0x868>
    2c31:      	movq	%rax, %rsi
    2c34:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2c3b:      	movl	$0x1, %eax
    2c40:      	movq	(%rip), %rdi            # 0x2c47 <do_action+0x777>
    2c47:      	callq	*%rax
    2c49:      	testq	%rax, %rax
    2c4c:      	je	0x2d38 <do_action+0x868>
    2c52:      	cmpl	$-0x1, 0x40(%rax,%rbx)
    2c57:      	je	0x2d38 <do_action+0x868>
    2c5d:      	movq	0x5e78(%r13,%rbx,2), %rax
    2c65:      	movl	0x4(%r13), %ecx
    2c69:      	cmpq	%rcx, %rax
    2c6c:      	jge	0x2d38 <do_action+0x868>
    2c72:      	cmpq	$0x10, %rbx
    2c76:      	je	0x2cd8 <do_action+0x808>
    2c78:      	movl	$0x0, 0x10(%rsp)
    2c80:      	movl	$0x1, %eax
    2c85:      	movq	(%rip), %rdi            # 0x2c8c <do_action+0x7bc>
    2c8c:      	leaq	0x10(%rsp), %rsi
    2c91:      	callq	*%rax
    2c93:      	testq	%rax, %rax
    2c96:      	je	0x2cd0 <do_action+0x800>
    2c98:      	movq	%rax, %rsi
    2c9b:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2ca2:      	movl	$0x1, %eax
    2ca7:      	movq	(%rip), %rdi            # 0x2cae <do_action+0x7de>
    2cae:      	callq	*%rax
    2cb0:      	testq	%rax, %rax
    2cb3:      	je	0x2cd0 <do_action+0x800>
    2cb5:      	cmpl	$-0x1, 0x44(%rax,%rbx)
    2cba:      	movq	0x5e78(%r13,%rbx,2), %rax
    2cc2:      	je	0x2cd8 <do_action+0x808>
    2cc4:      	movl	0x5e80(%r13,%rbx,2), %ebp
    2ccc:      	subl	%eax, %ebp
    2cce:      	jmp	0x2ce1 <do_action+0x811>
    2cd0:      	movq	0x5e78(%r13,%rbx,2), %rax
    2cd8:      	movl	0x4(%r13), %ebp
    2cdc:      	subl	%eax, %ebp
    2cde:      	addl	$0x4, %ebp
    2ce1:      	testl	%ebp, %ebp
    2ce3:      	jle	0x2bff <do_action+0x72f>
    2ce9:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2cee:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    2cf3:      	cmpl	$0x28, %ebp
    2cf6:      	movl	$0x28, %ecx
    2cfb:      	cmovgel	%ecx, %ebp
    2cfe:      	movzbl	0x60(%rsp), %r13d
    2d04:      	movq	0x40(%rsp), %rcx
    2d09:      	leaq	(%rcx,%r13), %rdi
    2d0d:      	movq	0x58(%rsp), %rcx
    2d12:      	leaq	(%rcx,%rax), %rdx
    2d16:      	addq	$0x90, %rdx
    2d1d:      	movl	$0x4, %eax
    2d22:      	movl	%ebp, %esi
    2d24:      	callq	*%rax
    2d26:      	addl	%r13d, %ebp
    2d29:      	movq	0x58(%rsp), %r13
    2d2e:      	movq	%rbp, 0x60(%rsp)
    2d33:      	jmp	0x2bff <do_action+0x72f>
    2d38:      	movq	(%rip), %rdi            # 0x2d3f <do_action+0x86f>
    2d3f:      	movl	$0x1, %eax
    2d44:      	movq	0x38(%rsp), %rsi
    2d49:      	callq	*%rax
    2d4b:      	testq	%rax, %rax
    2d4e:      	je	0x2d70 <do_action+0x8a0>
    2d50:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    2d59:      	movq	0x68(%rsp), %rdx
    2d5e:      	addq	%rcx, %rdx
    2d61:      	cmpq	%rdx, (%rax)
    2d64:      	jbe	0x2d70 <do_action+0x8a0>
    2d66:      	movq	0x20(%rsp), %rax
    2d6b:      	movb	$0x0, (%rax)
    2d6e:      	jmp	0x2d8a <do_action+0x8ba>
    2d70:      	movq	(%rip), %rdi            # 0x2d77 <do_action+0x8a7>
    2d77:      	xorl	%ecx, %ecx
    2d79:      	movq	%rsp, %rdx
    2d7c:      	movl	$0x2, %eax
    2d81:      	movq	0x38(%rsp), %rsi
    2d86:      	xorl	%ecx, %ecx
    2d88:      	callq	*%rax
    2d8a:      	leal	0x3(%r14), %eax
    2d8e:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2d94:      	movq	0x48(%rsp), %rbx
    2d99:      	je	0x2dbc <do_action+0x8ec>
    2d9b:      	orb	$0x2, 0x1(%r13)
    2da0:      	movq	(%rip), %rsi            # 0x2da7 <do_action+0x8d7>
    2da7:      	xorl	%ecx, %ecx
    2da9:      	movl	$0x1b, %eax
    2dae:      	movq	%rbx, %rdi
    2db1:      	xorl	%edx, %edx
    2db3:      	callq	*%rax
    2db5:      	movq	%rax, 0x80(%r13)
    2dbc:      	leal	0x4(%r14), %eax
    2dc0:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2dc6:      	je	0x2def <do_action+0x91f>
    2dc8:      	orb	$0x4, 0x1(%r13)
    2dcd:      	movq	(%rip), %rsi            # 0x2dd4 <do_action+0x904>
    2dd4:      	movl	$0x100, %ecx            # imm = 0x100
    2dd9:      	movl	$0x1b, %eax
    2dde:      	movl	$0x100, %edx            # imm = 0x100
    2de3:      	movq	%rbx, %rdi
    2de6:      	callq	*%rax
    2de8:      	movq	%rax, 0x88(%r13)
    2def:      	addl	$0x5, %r14d
    2df3:      	cmpl	$0x0, 0x4(%r15,%r14,4)
    2df9:      	je	0x2ed9 <do_action+0xa09>
    2dff:      	orb	$0x8, 0x1(%r13)
    2e04:      	jmp	0x2ed9 <do_action+0xa09>
    2e09:      	movq	(%rip), %rdi            # 0x2e10 <do_action+0x940>
    2e10:      	xorl	%ecx, %ecx
    2e12:      	leaq	0x28(%rsp), %rsi
    2e17:      	movq	%rsp, %rdx
    2e1a:      	movl	$0x2, %eax
    2e1f:      	xorl	%ecx, %ecx
    2e21:      	callq	*%rax
    2e23:      	jmp	0x2eaf <do_action+0x9df>
    2e28:      	movl	$0x1, 0x30(%rsp)
    2e30:      	movq	(%rip), %rdi            # 0x2e37 <do_action+0x967>
    2e37:      	xorl	%ecx, %ecx
    2e39:      	movq	%rsp, %rsi
    2e3c:      	leaq	0x30(%rsp), %rdx
    2e41:      	movl	$0x2, %eax
    2e46:      	xorl	%ecx, %ecx
    2e48:      	callq	*%rax
    2e4a:      	testl	%r15d, %r15d
    2e4d:      	je	0x2a0c <do_action+0x53c>
    2e53:      	movq	(%rip), %rdi            # 0x2e5a <do_action+0x98a>
    2e5a:      	leaq	0x10(%rsp), %rsi
    2e5f:      	movl	$0x1, %eax
    2e64:      	callq	*%rax
    2e66:      	testq	%rax, %rax
    2e69:      	je	0x2a0c <do_action+0x53c>
    2e6f:      	movl	0x34(%rsp), %ecx
    2e73:      	lock
    2e74:      	addl	%ecx, (%rax)
    2e76:      	jmp	0x2a0c <do_action+0x53c>
    2e7b:      	movl	$0x1, 0x30(%rsp)
    2e83:      	movq	(%rip), %rdi            # 0x2e8a <do_action+0x9ba>
    2e8a:      	xorl	%ecx, %ecx
    2e8c:      	leaq	0x10(%rsp), %rsi
    2e91:      	leaq	0x30(%rsp), %rdx
    2e96:      	movl	$0x2, %eax
    2e9b:      	xorl	%ecx, %ecx
    2e9d:      	callq	*%rax
    2e9f:      	movq	(%rsp), %rax
    2ea3:      	movq	0x8(%rsp), %rcx
    2ea8:      	movq	%rcx, 0x8(%r14)
    2eac:      	movq	%rax, (%r14)
    2eaf:      	movl	0x20(%rsp), %r14d
    2eb4:      	movl	$0x0, (%rsp)
    2ebb:      	movq	(%rip), %rdi            # 0x2ec2 <do_action+0x9f2>
    2ec2:      	movq	%rsp, %rsi
    2ec5:      	movl	$0x1, %eax
    2eca:      	callq	*%rax
    2ecc:      	testq	%rax, %rax
    2ecf:      	je	0x2ed6 <do_action+0xa06>
    2ed1:      	lock
    2ed2:      	incq	(%rax,%r13,8)
    2ed6:      	movq	%rbx, %r13
    2ed9:      	movq	%r12, 0x70(%r13)
    2edd:      	incl	%r14d
    2ee0:      	movl	%r14d, %eax
    2ee3:      	addq	$0x78, %rsp
    2ee7:      	popq	%rbx
    2ee8:      	popq	%r12
    2eea:      	popq	%r13
    2eec:      	popq	%r14
    2eee:      	popq	%r15
    2ef0:      	popq	%rbp
    2ef1:      	retq
    2ef2:      	nopw	%cs:(%rax,%rax)

0000000000002f00 <read_reg>:
    2f00:      	rorxl	$0x3, %esi, %ecx
    2f06:      	xorl	%eax, %eax
    2f08:      	cmpl	$0x7, %ecx
    2f0b:      	jle	0x2f42 <read_reg+0x42>
    2f0d:      	cmpl	$0xb, %ecx
    2f10:      	jle	0x2f66 <read_reg+0x66>
    2f12:      	cmpl	$0xd, %ecx
    2f15:      	jle	0x2fcb <read_reg+0xcb>
    2f1b:      	cmpl	$0xe, %ecx
    2f1e:      	je	0x2fff <read_reg+0xff>
    2f24:      	cmpl	$0x10, %ecx
    2f27:      	je	0x2fe7 <read_reg+0xe7>
    2f2d:      	cmpl	$0x13, %ecx
    2f30:      	jne	0x3015 <read_reg+0x115>
    2f36:      	addq	$0x98, %rdi
    2f3d:      	jmp	0x3009 <read_reg+0x109>
    2f42:      	cmpl	$0x3, %ecx
    2f45:      	jg	0x2f82 <read_reg+0x82>
    2f47:      	cmpl	$0x1, %ecx
    2f4a:      	jg	0x2fab <read_reg+0xab>
    2f4c:      	testl	%ecx, %ecx
    2f4e:      	je	0x3009 <read_reg+0x109>
    2f54:      	cmpl	$0x1, %ecx
    2f57:      	jne	0x3015 <read_reg+0x115>
    2f5d:      	addq	$0x8, %rdi
    2f61:      	jmp	0x3009 <read_reg+0x109>
    2f66:      	cmpl	$0x9, %ecx
    2f69:      	jg	0x2f9b <read_reg+0x9b>
    2f6b:      	cmpl	$0x8, %ecx
    2f6e:      	je	0x2fdb <read_reg+0xdb>
    2f70:      	cmpl	$0x9, %ecx
    2f73:      	jne	0x3015 <read_reg+0x115>
    2f79:      	addq	$0x48, %rdi
    2f7d:      	jmp	0x3009 <read_reg+0x109>
    2f82:      	cmpl	$0x5, %ecx
    2f85:      	jg	0x2fbb <read_reg+0xbb>
    2f87:      	cmpl	$0x4, %ecx
    2f8a:      	je	0x2fed <read_reg+0xed>
    2f8c:      	cmpl	$0x5, %ecx
    2f8f:      	jne	0x3015 <read_reg+0x115>
    2f95:      	addq	$0x28, %rdi
    2f99:      	jmp	0x3009 <read_reg+0x109>
    2f9b:      	cmpl	$0xa, %ecx
    2f9e:      	je	0x2fe1 <read_reg+0xe1>
    2fa0:      	cmpl	$0xb, %ecx
    2fa3:      	jne	0x3015 <read_reg+0x115>
    2fa5:      	addq	$0x58, %rdi
    2fa9:      	jmp	0x3009 <read_reg+0x109>
    2fab:      	cmpl	$0x2, %ecx
    2fae:      	je	0x2ff3 <read_reg+0xf3>
    2fb0:      	cmpl	$0x3, %ecx
    2fb3:      	jne	0x3015 <read_reg+0x115>
    2fb5:      	addq	$0x18, %rdi
    2fb9:      	jmp	0x3009 <read_reg+0x109>
    2fbb:      	cmpl	$0x6, %ecx
    2fbe:      	je	0x2ff9 <read_reg+0xf9>
    2fc0:      	cmpl	$0x7, %ecx
    2fc3:      	jne	0x3015 <read_reg+0x115>
    2fc5:      	addq	$0x38, %rdi
    2fc9:      	jmp	0x3009 <read_reg+0x109>
    2fcb:      	cmpl	$0xc, %ecx
    2fce:      	je	0x3005 <read_reg+0x105>
    2fd0:      	cmpl	$0xd, %ecx
    2fd3:      	jne	0x3015 <read_reg+0x115>
    2fd5:      	addq	$0x68, %rdi
    2fd9:      	jmp	0x3009 <read_reg+0x109>
    2fdb:      	addq	$0x40, %rdi
    2fdf:      	jmp	0x3009 <read_reg+0x109>
    2fe1:      	addq	$0x50, %rdi
    2fe5:      	jmp	0x3009 <read_reg+0x109>
    2fe7:      	subq	$-0x80, %rdi
    2feb:      	jmp	0x3009 <read_reg+0x109>
    2fed:      	addq	$0x20, %rdi
    2ff1:      	jmp	0x3009 <read_reg+0x109>
    2ff3:      	addq	$0x10, %rdi
    2ff7:      	jmp	0x3009 <read_reg+0x109>
    2ff9:      	addq	$0x30, %rdi
    2ffd:      	jmp	0x3009 <read_reg+0x109>
    2fff:      	addq	$0x70, %rdi
    3003:      	jmp	0x3009 <read_reg+0x109>
    3005:      	addq	$0x60, %rdi
    3009:      	movl	$0x40, %eax
    300e:      	subl	%edx, %eax
    3010:      	bzhiq	%rax, (%rdi), %rax
    3015:      	retq
    3016:      	nopw	%cs:(%rax,%rax)

0000000000003020 <try_preload_arg>:
    3020:      	pushq	%rbp
    3021:      	pushq	%r15
    3023:      	pushq	%r14
    3025:      	pushq	%r13
    3027:      	pushq	%r12
    3029:      	pushq	%rbx
    302a:      	subq	$0x38, %rsp
    302e:      	movl	%edi, %ebx
    3030:      	andl	$0x7, %ebx
    3033:      	movq	(%rsi), %r14
    3036:      	movl	0x18(%r14,%rbx,4), %eax
    303b:      	testl	$0x100, %eax            # imm = 0x100
    3040:      	jne	0x3053 <try_preload_arg+0x33>
    3042:      	xorl	%eax, %eax
    3044:      	addq	$0x38, %rsp
    3048:      	popq	%rbx
    3049:      	popq	%r12
    304b:      	popq	%r13
    304d:      	popq	%r14
    304f:      	popq	%r15
    3051:      	popq	%rbp
    3052:      	retq
    3053:      	movq	0x8(%rsi), %rdi
    3057:      	testb	%al, %al
    3059:      	js	0x30e5 <try_preload_arg+0xc5>
    305f:      	movl	$0x0, 0x10(%rsp)
    3067:      	leaq	(%rbx,%rbx,2), %r15
    306b:      	leaq	(%r14,%r15,8), %r12
    306f:      	addq	$0x200, %r12            # imm = 0x200
    3076:      	movzbl	0x211(%r14,%r15,8), %ecx
    307f:      	xorl	%eax, %eax
    3081:      	cmpl	$0x2, %ecx
    3084:      	jg	0x3444 <try_preload_arg+0x424>
    308a:      	cmpl	$0x1, %ecx
    308d:      	je	0x3511 <try_preload_arg+0x4f1>
    3093:      	cmpl	$0x2, %ecx
    3096:      	jne	0x3541 <try_preload_arg+0x521>
    309c:      	movl	0x208(%r14,%r15,8), %eax
    30a4:      	andl	$0xfff, %eax            # imm = 0xFFF
    30a9:      	addq	%rax, %rdi
    30ac:      	leaq	0x18(%rsp), %rcx
    30b1:      	movl	$0x8, %edx
    30b6:      	movl	$0x71, %eax
    30bb:      	movq	%rdi, %rdx
    30be:      	movq	%rcx, %rdi
    30c1:      	movl	$0x8, %esi
    30c6:      	callq	*%rax
    30c8:      	testl	%eax, %eax
    30ca:      	je	0x351a <try_preload_arg+0x4fa>
    30d0:      	xorl	%eax, %eax
    30d2:      	movq	%rax, 0x8(%rsp)
    30d7:      	cmpl	$0x4, %ebx
    30da:      	ja	0x39d2 <try_preload_arg+0x9b2>
    30e0:      	jmp	0x35c1 <try_preload_arg+0x5a1>
    30e5:      	movl	$0x0, 0x10(%rsp)
    30ed:      	movzbl	0x2c2(%r14,%rbx,4), %eax
    30f6:      	shlb	$0x3, %al
    30f9:      	movb	$0x40, %cl
    30fb:      	subb	%al, %cl
    30fd:      	movzwl	0x2c0(%r14,%rbx,4), %esi
    3106:      	movzbl	%cl, %edx
    3109:      	callq	0x2f00 <read_reg>
    310e:      	movq	%rax, 0x8(%rsp)
    3113:      	movl	0x4(%r14,%rbx,4), %ebp
    3118:      	cmpl	$0x4, %ebx
    311b:      	ja	0x3918 <try_preload_arg+0x8f8>
    3121:      	leaq	(%rbx,%rbx,4), %rax
    3125:      	shll	$0x4, %eax
    3128:      	cmpw	$0x0, 0x76(%r14,%rax)
    312f:      	je	0x3918 <try_preload_arg+0x8f8>
    3135:      	leaq	(%r14,%rax), %rbx
    3139:      	addq	$0x70, %rbx
    313d:      	movq	%rbx, 0x18(%rsp)
    3142:      	leaq	0x8(%rsp), %rax
    3147:      	movq	%rax, 0x20(%rsp)
    314c:      	movb	$0x1, 0x28(%rsp)
    3151:      	leaq	0x10(%rsp), %rax
    3156:      	movq	%rax, 0x30(%rsp)
    315b:      	movq	(%rip), %rax            # 0x3162 <try_preload_arg+0x142>
    3162:      	cmpb	$0x0, (%rax)
    3165:      	je	0x38f7 <try_preload_arg+0x8d7>
    316b:      	cmpw	$0x0, 0x6(%rbx)
    3170:      	je	0x3918 <try_preload_arg+0x8f8>
    3176:      	movl	(%rbx), %ecx
    3178:      	addq	0x8(%rsp), %rcx
    317d:      	movq	%rcx, 0x8(%rsp)
    3182:      	cmpw	$0x0, 0x4(%rbx)
    3187:      	je	0x31b2 <try_preload_arg+0x192>
    3189:      	leaq	0x8(%rsp), %rdi
    318e:      	movl	$0x8, %edx
    3193:      	movl	$0x94, %eax
    3198:      	movq	0x8(%rsp), %rdx
    319d:      	movl	$0x8, %esi
    31a2:      	callq	*%rax
    31a4:      	movl	$0x1, %r14d
    31aa:      	testl	%eax, %eax
    31ac:      	js	0x343a <try_preload_arg+0x41a>
    31b2:      	cmpw	$0x0, 0xe(%rbx)
    31b7:      	je	0x3918 <try_preload_arg+0x8f8>
    31bd:      	movl	0x8(%rbx), %ecx
    31c0:      	addq	0x8(%rsp), %rcx
    31c5:      	movq	%rcx, 0x8(%rsp)
    31ca:      	cmpw	$0x0, 0xc(%rbx)
    31cf:      	je	0x31fa <try_preload_arg+0x1da>
    31d1:      	leaq	0x8(%rsp), %rdi
    31d6:      	movl	$0x8, %edx
    31db:      	movl	$0x94, %eax
    31e0:      	movq	0x8(%rsp), %rdx
    31e5:      	movl	$0x8, %esi
    31ea:      	callq	*%rax
    31ec:      	movl	$0x2, %r14d
    31f2:      	testl	%eax, %eax
    31f4:      	js	0x343a <try_preload_arg+0x41a>
    31fa:      	cmpw	$0x0, 0x16(%rbx)
    31ff:      	je	0x3918 <try_preload_arg+0x8f8>
    3205:      	movl	0x10(%rbx), %ecx
    3208:      	addq	0x8(%rsp), %rcx
    320d:      	movq	%rcx, 0x8(%rsp)
    3212:      	cmpw	$0x0, 0x14(%rbx)
    3217:      	je	0x3242 <try_preload_arg+0x222>
    3219:      	leaq	0x8(%rsp), %rdi
    321e:      	movl	$0x8, %edx
    3223:      	movl	$0x94, %eax
    3228:      	movq	0x8(%rsp), %rdx
    322d:      	movl	$0x8, %esi
    3232:      	callq	*%rax
    3234:      	movl	$0x3, %r14d
    323a:      	testl	%eax, %eax
    323c:      	js	0x343a <try_preload_arg+0x41a>
    3242:      	cmpw	$0x0, 0x1e(%rbx)
    3247:      	je	0x3918 <try_preload_arg+0x8f8>
    324d:      	movl	0x18(%rbx), %ecx
    3250:      	addq	0x8(%rsp), %rcx
    3255:      	movq	%rcx, 0x8(%rsp)
    325a:      	cmpw	$0x0, 0x1c(%rbx)
    325f:      	je	0x328a <try_preload_arg+0x26a>
    3261:      	leaq	0x8(%rsp), %rdi
    3266:      	movl	$0x8, %edx
    326b:      	movl	$0x94, %eax
    3270:      	movq	0x8(%rsp), %rdx
    3275:      	movl	$0x8, %esi
    327a:      	callq	*%rax
    327c:      	movl	$0x4, %r14d
    3282:      	testl	%eax, %eax
    3284:      	js	0x343a <try_preload_arg+0x41a>
    328a:      	cmpw	$0x0, 0x26(%rbx)
    328f:      	je	0x3918 <try_preload_arg+0x8f8>
    3295:      	movl	0x20(%rbx), %ecx
    3298:      	addq	0x8(%rsp), %rcx
    329d:      	movq	%rcx, 0x8(%rsp)
    32a2:      	cmpw	$0x0, 0x24(%rbx)
    32a7:      	je	0x32d2 <try_preload_arg+0x2b2>
    32a9:      	leaq	0x8(%rsp), %rdi
    32ae:      	movl	$0x8, %edx
    32b3:      	movl	$0x94, %eax
    32b8:      	movq	0x8(%rsp), %rdx
    32bd:      	movl	$0x8, %esi
    32c2:      	callq	*%rax
    32c4:      	movl	$0x5, %r14d
    32ca:      	testl	%eax, %eax
    32cc:      	js	0x343a <try_preload_arg+0x41a>
    32d2:      	cmpw	$0x0, 0x2e(%rbx)
    32d7:      	je	0x3918 <try_preload_arg+0x8f8>
    32dd:      	movl	0x28(%rbx), %ecx
    32e0:      	addq	0x8(%rsp), %rcx
    32e5:      	movq	%rcx, 0x8(%rsp)
    32ea:      	cmpw	$0x0, 0x2c(%rbx)
    32ef:      	je	0x331a <try_preload_arg+0x2fa>
    32f1:      	leaq	0x8(%rsp), %rdi
    32f6:      	movl	$0x8, %edx
    32fb:      	movl	$0x94, %eax
    3300:      	movq	0x8(%rsp), %rdx
    3305:      	movl	$0x8, %esi
    330a:      	callq	*%rax
    330c:      	movl	$0x6, %r14d
    3312:      	testl	%eax, %eax
    3314:      	js	0x343a <try_preload_arg+0x41a>
    331a:      	cmpw	$0x0, 0x36(%rbx)
    331f:      	je	0x3918 <try_preload_arg+0x8f8>
    3325:      	movl	0x30(%rbx), %ecx
    3328:      	addq	0x8(%rsp), %rcx
    332d:      	movq	%rcx, 0x8(%rsp)
    3332:      	cmpw	$0x0, 0x34(%rbx)
    3337:      	je	0x3362 <try_preload_arg+0x342>
    3339:      	leaq	0x8(%rsp), %rdi
    333e:      	movl	$0x8, %edx
    3343:      	movl	$0x94, %eax
    3348:      	movq	0x8(%rsp), %rdx
    334d:      	movl	$0x8, %esi
    3352:      	callq	*%rax
    3354:      	movl	$0x7, %r14d
    335a:      	testl	%eax, %eax
    335c:      	js	0x343a <try_preload_arg+0x41a>
    3362:      	cmpw	$0x0, 0x3e(%rbx)
    3367:      	je	0x3918 <try_preload_arg+0x8f8>
    336d:      	movl	0x38(%rbx), %ecx
    3370:      	addq	0x8(%rsp), %rcx
    3375:      	movq	%rcx, 0x8(%rsp)
    337a:      	cmpw	$0x0, 0x3c(%rbx)
    337f:      	je	0x33aa <try_preload_arg+0x38a>
    3381:      	leaq	0x8(%rsp), %rdi
    3386:      	movl	$0x8, %edx
    338b:      	movl	$0x94, %eax
    3390:      	movq	0x8(%rsp), %rdx
    3395:      	movl	$0x8, %r14d
    339b:      	movl	$0x8, %esi
    33a0:      	callq	*%rax
    33a2:      	testl	%eax, %eax
    33a4:      	js	0x343a <try_preload_arg+0x41a>
    33aa:      	cmpw	$0x0, 0x46(%rbx)
    33af:      	je	0x3918 <try_preload_arg+0x8f8>
    33b5:      	movl	0x40(%rbx), %ecx
    33b8:      	addq	0x8(%rsp), %rcx
    33bd:      	movq	%rcx, 0x8(%rsp)
    33c2:      	cmpw	$0x0, 0x44(%rbx)
    33c7:      	je	0x33ee <try_preload_arg+0x3ce>
    33c9:      	leaq	0x8(%rsp), %rdi
    33ce:      	movl	$0x8, %edx
    33d3:      	movl	$0x94, %eax
    33d8:      	movq	0x8(%rsp), %rdx
    33dd:      	movl	$0x8, %esi
    33e2:      	callq	*%rax
    33e4:      	movl	$0x9, %r14d
    33ea:      	testl	%eax, %eax
    33ec:      	js	0x343a <try_preload_arg+0x41a>
    33ee:      	cmpw	$0x0, 0x4e(%rbx)
    33f3:      	je	0x3918 <try_preload_arg+0x8f8>
    33f9:      	movl	0x48(%rbx), %ecx
    33fc:      	addq	0x8(%rsp), %rcx
    3401:      	movq	%rcx, 0x8(%rsp)
    3406:      	cmpw	$0x0, 0x4c(%rbx)
    340b:      	je	0x3918 <try_preload_arg+0x8f8>
    3411:      	leaq	0x8(%rsp), %rdi
    3416:      	movl	$0x8, %edx
    341b:      	movl	$0x94, %eax
    3420:      	movq	0x8(%rsp), %rdx
    3425:      	movl	$0x8, %esi
    342a:      	callq	*%rax
    342c:      	movl	$0xa, %r14d
    3432:      	testl	%eax, %eax
    3434:      	jns	0x3918 <try_preload_arg+0x8f8>
    343a:      	movl	%r14d, 0x10(%rsp)
    343f:      	jmp	0x3918 <try_preload_arg+0x8f8>
    3444:      	cmpl	$0x3, %ecx
    3447:      	je	0x3551 <try_preload_arg+0x531>
    344d:      	cmpl	$0x4, %ecx
    3450:      	jne	0x3541 <try_preload_arg+0x521>
    3456:      	movl	0x208(%r14,%r15,8), %edx
    345e:      	andl	$0xfff, %edx            # imm = 0xFFF
    3464:      	movq	%rdi, %r13
    3467:      	addq	%rdi, %rdx
    346a:      	leaq	0x18(%rsp), %rdi
    346f:      	movl	$0x8, %ecx
    3474:      	movl	$0x71, %eax
    3479:      	movl	$0x8, %esi
    347e:      	callq	*%rax
    3480:      	testl	%eax, %eax
    3482:      	jne	0x35b1 <try_preload_arg+0x591>
    3488:      	movl	0x20c(%r14,%r15,8), %eax
    3490:      	andl	$0xfff, %eax            # imm = 0xFFF
    3495:      	movq	%r13, %rdx
    3498:      	addq	%rax, %rdx
    349b:      	leaq	0x8(%rsp), %rdi
    34a0:      	movl	$0x8, %ecx
    34a5:      	movl	$0x71, %eax
    34aa:      	movl	$0x8, %esi
    34af:      	callq	*%rax
    34b1:      	testl	%eax, %eax
    34b3:      	jne	0x35b1 <try_preload_arg+0x591>
    34b9:      	movzbl	0x213(%r14,%r15,8), %eax
    34c2:      	shlxq	%rax, 0x8(%rsp), %rax
    34c9:      	movq	(%r12), %rcx
    34cd:      	addq	0x18(%rsp), %rcx
    34d2:      	addq	%rax, %rcx
    34d5:      	leaq	0x18(%rsp), %rdi
    34da:      	movl	$0x8, %edx
    34df:      	movl	$0x94, %eax
    34e4:      	movzbl	0x213(%r14,%r15,8), %ecx
    34ed:      	shlxq	%rcx, 0x8(%rsp), %rcx
    34f4:      	movq	(%r12), %rdx
    34f8:      	addq	0x18(%rsp), %rdx
    34fd:      	addq	%rcx, %rdx
    3500:      	movl	$0x8, %esi
    3505:      	callq	*%rax
    3507:      	testl	%eax, %eax
    3509:      	jne	0x35b1 <try_preload_arg+0x591>
    350f:      	jmp	0x351a <try_preload_arg+0x4fa>
    3511:      	movq	(%r12), %rax
    3515:      	movq	%rax, 0x18(%rsp)
    351a:      	movzbl	0x210(%r14,%r15,8), %eax
    3523:      	shlxq	%rax, 0x18(%rsp), %rcx
    352a:      	cmpb	$0x0, 0x212(%r14,%r15,8)
    3533:      	shrxq	%rax, %rcx, %rdx
    3538:      	sarxq	%rax, %rcx, %rax
    353d:      	cmoveq	%rdx, %rax
    3541:      	movq	%rax, 0x8(%rsp)
    3546:      	cmpl	$0x4, %ebx
    3549:      	ja	0x39d2 <try_preload_arg+0x9b2>
    354f:      	jmp	0x35c1 <try_preload_arg+0x5a1>
    3551:      	movl	0x208(%r14,%r15,8), %eax
    3559:      	andl	$0xfff, %eax            # imm = 0xFFF
    355e:      	addq	%rax, %rdi
    3561:      	leaq	0x18(%rsp), %rcx
    3566:      	movl	$0x8, %edx
    356b:      	movl	$0x71, %eax
    3570:      	movq	%rdi, %rdx
    3573:      	movq	%rcx, %rdi
    3576:      	movl	$0x8, %esi
    357b:      	callq	*%rax
    357d:      	testl	%eax, %eax
    357f:      	jne	0x35b1 <try_preload_arg+0x591>
    3581:      	movq	0x18(%rsp), %rcx
    3586:      	addq	(%r12), %rcx
    358a:      	leaq	0x18(%rsp), %rdi
    358f:      	movl	$0x8, %edx
    3594:      	movl	$0x94, %eax
    3599:      	movq	0x18(%rsp), %rdx
    359e:      	addq	(%r12), %rdx
    35a2:      	movl	$0x8, %esi
    35a7:      	callq	*%rax
    35a9:      	testl	%eax, %eax
    35ab:      	je	0x351a <try_preload_arg+0x4fa>
    35b1:      	cltq
    35b3:      	movq	%rax, 0x8(%rsp)
    35b8:      	cmpl	$0x4, %ebx
    35bb:      	ja	0x39d2 <try_preload_arg+0x9b2>
    35c1:      	leaq	(%rbx,%rbx,4), %rax
    35c5:      	shll	$0x4, %eax
    35c8:      	cmpw	$0x0, 0x76(%r14,%rax)
    35cf:      	je	0x39d2 <try_preload_arg+0x9b2>
    35d5:      	leaq	(%r14,%rax), %r15
    35d9:      	addq	$0x70, %r15
    35dd:      	movq	%r15, 0x18(%rsp)
    35e2:      	leaq	0x8(%rsp), %rax
    35e7:      	movq	%rax, 0x20(%rsp)
    35ec:      	movb	$0x1, 0x28(%rsp)
    35f1:      	leaq	0x10(%rsp), %rax
    35f6:      	movq	%rax, 0x30(%rsp)
    35fb:      	movq	(%rip), %rax            # 0x3602 <try_preload_arg+0x5e2>
    3602:      	cmpb	$0x0, (%rax)
    3605:      	je	0x39b1 <try_preload_arg+0x991>
    360b:      	cmpw	$0x0, 0x6(%r15)
    3611:      	je	0x39d2 <try_preload_arg+0x9b2>
    3617:      	movl	(%r15), %ecx
    361a:      	addq	0x8(%rsp), %rcx
    361f:      	movq	%rcx, 0x8(%rsp)
    3624:      	cmpw	$0x0, 0x4(%r15)
    362a:      	je	0x3654 <try_preload_arg+0x634>
    362c:      	leaq	0x8(%rsp), %rdi
    3631:      	movl	$0x8, %edx
    3636:      	movl	$0x94, %eax
    363b:      	movq	0x8(%rsp), %rdx
    3640:      	movl	$0x8, %esi
    3645:      	callq	*%rax
    3647:      	movl	$0x1, %ebp
    364c:      	testl	%eax, %eax
    364e:      	js	0x38ee <try_preload_arg+0x8ce>
    3654:      	cmpw	$0x0, 0xe(%r15)
    365a:      	je	0x39d2 <try_preload_arg+0x9b2>
    3660:      	movl	0x8(%r15), %ecx
    3664:      	addq	0x8(%rsp), %rcx
    3669:      	movq	%rcx, 0x8(%rsp)
    366e:      	cmpw	$0x0, 0xc(%r15)
    3674:      	je	0x369e <try_preload_arg+0x67e>
    3676:      	leaq	0x8(%rsp), %rdi
    367b:      	movl	$0x8, %edx
    3680:      	movl	$0x94, %eax
    3685:      	movq	0x8(%rsp), %rdx
    368a:      	movl	$0x8, %esi
    368f:      	callq	*%rax
    3691:      	movl	$0x2, %ebp
    3696:      	testl	%eax, %eax
    3698:      	js	0x38ee <try_preload_arg+0x8ce>
    369e:      	cmpw	$0x0, 0x16(%r15)
    36a4:      	je	0x39d2 <try_preload_arg+0x9b2>
    36aa:      	movl	0x10(%r15), %ecx
    36ae:      	addq	0x8(%rsp), %rcx
    36b3:      	movq	%rcx, 0x8(%rsp)
    36b8:      	cmpw	$0x0, 0x14(%r15)
    36be:      	je	0x36e8 <try_preload_arg+0x6c8>
    36c0:      	leaq	0x8(%rsp), %rdi
    36c5:      	movl	$0x8, %edx
    36ca:      	movl	$0x94, %eax
    36cf:      	movq	0x8(%rsp), %rdx
    36d4:      	movl	$0x8, %esi
    36d9:      	callq	*%rax
    36db:      	movl	$0x3, %ebp
    36e0:      	testl	%eax, %eax
    36e2:      	js	0x38ee <try_preload_arg+0x8ce>
    36e8:      	cmpw	$0x0, 0x1e(%r15)
    36ee:      	je	0x39d2 <try_preload_arg+0x9b2>
    36f4:      	movl	0x18(%r15), %ecx
    36f8:      	addq	0x8(%rsp), %rcx
    36fd:      	movq	%rcx, 0x8(%rsp)
    3702:      	cmpw	$0x0, 0x1c(%r15)
    3708:      	je	0x3732 <try_preload_arg+0x712>
    370a:      	leaq	0x8(%rsp), %rdi
    370f:      	movl	$0x8, %edx
    3714:      	movl	$0x94, %eax
    3719:      	movq	0x8(%rsp), %rdx
    371e:      	movl	$0x8, %esi
    3723:      	callq	*%rax
    3725:      	movl	$0x4, %ebp
    372a:      	testl	%eax, %eax
    372c:      	js	0x38ee <try_preload_arg+0x8ce>
    3732:      	cmpw	$0x0, 0x26(%r15)
    3738:      	je	0x39d2 <try_preload_arg+0x9b2>
    373e:      	movl	0x20(%r15), %ecx
    3742:      	addq	0x8(%rsp), %rcx
    3747:      	movq	%rcx, 0x8(%rsp)
    374c:      	cmpw	$0x0, 0x24(%r15)
    3752:      	je	0x377c <try_preload_arg+0x75c>
    3754:      	leaq	0x8(%rsp), %rdi
    3759:      	movl	$0x8, %edx
    375e:      	movl	$0x94, %eax
    3763:      	movq	0x8(%rsp), %rdx
    3768:      	movl	$0x8, %esi
    376d:      	callq	*%rax
    376f:      	movl	$0x5, %ebp
    3774:      	testl	%eax, %eax
    3776:      	js	0x38ee <try_preload_arg+0x8ce>
    377c:      	cmpw	$0x0, 0x2e(%r15)
    3782:      	je	0x39d2 <try_preload_arg+0x9b2>
    3788:      	movl	0x28(%r15), %ecx
    378c:      	addq	0x8(%rsp), %rcx
    3791:      	movq	%rcx, 0x8(%rsp)
    3796:      	cmpw	$0x0, 0x2c(%r15)
    379c:      	je	0x37c6 <try_preload_arg+0x7a6>
    379e:      	leaq	0x8(%rsp), %rdi
    37a3:      	movl	$0x8, %edx
    37a8:      	movl	$0x94, %eax
    37ad:      	movq	0x8(%rsp), %rdx
    37b2:      	movl	$0x8, %esi
    37b7:      	callq	*%rax
    37b9:      	movl	$0x6, %ebp
    37be:      	testl	%eax, %eax
    37c0:      	js	0x38ee <try_preload_arg+0x8ce>
    37c6:      	cmpw	$0x0, 0x36(%r15)
    37cc:      	je	0x39d2 <try_preload_arg+0x9b2>
    37d2:      	movl	0x30(%r15), %ecx
    37d6:      	addq	0x8(%rsp), %rcx
    37db:      	movq	%rcx, 0x8(%rsp)
    37e0:      	cmpw	$0x0, 0x34(%r15)
    37e6:      	je	0x3810 <try_preload_arg+0x7f0>
    37e8:      	leaq	0x8(%rsp), %rdi
    37ed:      	movl	$0x8, %edx
    37f2:      	movl	$0x94, %eax
    37f7:      	movq	0x8(%rsp), %rdx
    37fc:      	movl	$0x8, %esi
    3801:      	callq	*%rax
    3803:      	movl	$0x7, %ebp
    3808:      	testl	%eax, %eax
    380a:      	js	0x38ee <try_preload_arg+0x8ce>
    3810:      	cmpw	$0x0, 0x3e(%r15)
    3816:      	je	0x39d2 <try_preload_arg+0x9b2>
    381c:      	movl	0x38(%r15), %ecx
    3820:      	addq	0x8(%rsp), %rcx
    3825:      	movq	%rcx, 0x8(%rsp)
    382a:      	cmpw	$0x0, 0x3c(%r15)
    3830:      	je	0x385a <try_preload_arg+0x83a>
    3832:      	leaq	0x8(%rsp), %rdi
    3837:      	movl	$0x8, %edx
    383c:      	movl	$0x94, %eax
    3841:      	movq	0x8(%rsp), %rdx
    3846:      	movl	$0x8, %ebp
    384b:      	movl	$0x8, %esi
    3850:      	callq	*%rax
    3852:      	testl	%eax, %eax
    3854:      	js	0x38ee <try_preload_arg+0x8ce>
    385a:      	cmpw	$0x0, 0x46(%r15)
    3860:      	je	0x39d2 <try_preload_arg+0x9b2>
    3866:      	movl	0x40(%r15), %ecx
    386a:      	addq	0x8(%rsp), %rcx
    386f:      	movq	%rcx, 0x8(%rsp)
    3874:      	cmpw	$0x0, 0x44(%r15)
    387a:      	je	0x38a0 <try_preload_arg+0x880>
    387c:      	leaq	0x8(%rsp), %rdi
    3881:      	movl	$0x8, %edx
    3886:      	movl	$0x94, %eax
    388b:      	movq	0x8(%rsp), %rdx
    3890:      	movl	$0x8, %esi
    3895:      	callq	*%rax
    3897:      	movl	$0x9, %ebp
    389c:      	testl	%eax, %eax
    389e:      	js	0x38ee <try_preload_arg+0x8ce>
    38a0:      	cmpw	$0x0, 0x4e(%r15)
    38a6:      	je	0x39d2 <try_preload_arg+0x9b2>
    38ac:      	movl	0x48(%r15), %ecx
    38b0:      	addq	0x8(%rsp), %rcx
    38b5:      	movq	%rcx, 0x8(%rsp)
    38ba:      	cmpw	$0x0, 0x4c(%r15)
    38c0:      	je	0x39d2 <try_preload_arg+0x9b2>
    38c6:      	leaq	0x8(%rsp), %rdi
    38cb:      	movl	$0x8, %edx
    38d0:      	movl	$0x94, %eax
    38d5:      	movq	0x8(%rsp), %rdx
    38da:      	movl	$0x8, %esi
    38df:      	callq	*%rax
    38e1:      	movl	$0xa, %ebp
    38e6:      	testl	%eax, %eax
    38e8:      	jns	0x39d2 <try_preload_arg+0x9b2>
    38ee:      	movl	%ebp, 0x10(%rsp)
    38f2:      	jmp	0x39d2 <try_preload_arg+0x9b2>
    38f7:      	leaq	-0x38fe(%rip), %rsi     # 0x0 <extract_arg_depth>
    38fe:      	xorl	%ecx, %ecx
    3900:      	leaq	0x18(%rsp), %rdx
    3905:      	movl	$0xa, %edi
    390a:      	movl	$0xb5, %eax
    390f:      	movl	$0xa, %edi
    3914:      	xorl	%ecx, %ecx
    3916:      	callq	*%rax
    3918:      	cmpl	$0x6, %ebp
    391b:      	jne	0x3042 <try_preload_arg+0x22>
    3921:      	movq	0x8(%rsp), %rbx
    3926:      	movl	0x10(%rsp), %ebp
    392a:      	movl	$0xe, %eax
    392f:      	callq	*%rax
    3931:      	movq	%rax, 0x18(%rsp)
    3936:      	movl	$0x0, 0x14(%rsp)
    393e:      	movq	(%rip), %rdi            # 0x3945 <try_preload_arg+0x925>
    3945:      	leaq	0x14(%rsp), %rsi
    394a:      	movl	$0x1, %eax
    394f:      	callq	*%rax
    3951:      	testq	%rax, %rax
    3954:      	je	0x3042 <try_preload_arg+0x22>
    395a:      	movq	%rax, %rdx
    395d:      	movq	(%rip), %r14            # 0x3964 <try_preload_arg+0x944>
    3964:      	xorl	%ecx, %ecx
    3966:      	leaq	0x18(%rsp), %r15
    396b:      	movl	$0x2, %eax
    3970:      	movq	%r14, %rdi
    3973:      	movq	%r15, %rsi
    3976:      	xorl	%ecx, %ecx
    3978:      	callq	*%rax
    397a:      	movl	$0x1, %eax
    397f:      	movq	%r14, %rdi
    3982:      	movq	%r15, %rsi
    3985:      	callq	*%rax
    3987:      	testq	%rax, %rax
    398a:      	je	0x3042 <try_preload_arg+0x22>
    3990:      	testl	%ebp, %ebp
    3992:      	jne	0x3a9a <try_preload_arg+0xa7a>
    3998:      	movq	%rax, %rdi
    399b:      	addq	$0x4, %rdi
    399f:      	movl	$0x1000, %ecx           # imm = 0x1000
    39a4:      	movq	%rax, %r14
    39a7:      	movl	$0x72, %eax
    39ac:      	jmp	0x3a80 <try_preload_arg+0xa60>
    39b1:      	leaq	-0x39b8(%rip), %rsi     # 0x0 <extract_arg_depth>
    39b8:      	xorl	%ecx, %ecx
    39ba:      	leaq	0x18(%rsp), %rdx
    39bf:      	movl	$0xa, %edi
    39c4:      	movl	$0xb5, %eax
    39c9:      	movl	$0xa, %edi
    39ce:      	xorl	%ecx, %ecx
    39d0:      	callq	*%rax
    39d2:      	movl	0x4(%r14,%rbx,4), %ebx
    39d7:      	leaq	0x8(%rsp), %rdi
    39dc:      	movl	$0x8, %ecx
    39e1:      	movl	$0x4, %eax
    39e6:      	movl	$0x8, %esi
    39eb:      	movq	%rdi, %rdx
    39ee:      	callq	*%rax
    39f0:      	cmpl	$0x6, %ebx
    39f3:      	jne	0x3042 <try_preload_arg+0x22>
    39f9:      	movq	0x8(%rsp), %rbx
    39fe:      	movl	0x10(%rsp), %ebp
    3a02:      	movl	$0xe, %eax
    3a07:      	callq	*%rax
    3a09:      	movq	%rax, 0x18(%rsp)
    3a0e:      	movl	$0x0, 0x14(%rsp)
    3a16:      	movq	(%rip), %rdi            # 0x3a1d <try_preload_arg+0x9fd>
    3a1d:      	leaq	0x14(%rsp), %rsi
    3a22:      	movl	$0x1, %eax
    3a27:      	callq	*%rax
    3a29:      	testq	%rax, %rax
    3a2c:      	je	0x3042 <try_preload_arg+0x22>
    3a32:      	movq	%rax, %rdx
    3a35:      	movq	(%rip), %r14            # 0x3a3c <try_preload_arg+0xa1c>
    3a3c:      	xorl	%ecx, %ecx
    3a3e:      	leaq	0x18(%rsp), %r15
    3a43:      	movl	$0x2, %eax
    3a48:      	movq	%r14, %rdi
    3a4b:      	movq	%r15, %rsi
    3a4e:      	xorl	%ecx, %ecx
    3a50:      	callq	*%rax
    3a52:      	movl	$0x1, %eax
    3a57:      	movq	%r14, %rdi
    3a5a:      	movq	%r15, %rsi
    3a5d:      	callq	*%rax
    3a5f:      	testq	%rax, %rax
    3a62:      	je	0x3042 <try_preload_arg+0x22>
    3a68:      	testl	%ebp, %ebp
    3a6a:      	jne	0x3a9a <try_preload_arg+0xa7a>
    3a6c:      	movq	%rax, %rdi
    3a6f:      	addq	$0x4, %rdi
    3a73:      	movl	$0x1000, %ecx           # imm = 0x1000
    3a78:      	movq	%rax, %r14
    3a7b:      	movl	$0x72, %eax
    3a80:      	movl	$0x1000, %esi           # imm = 0x1000
    3a85:      	movq	%rbx, %rdx
    3a88:      	callq	*%rax
    3a8a:      	movq	%rax, %rcx
    3a8d:      	movq	%r14, %rax
    3a90:      	testq	%rcx, %rcx
    3a93:      	jns	0x3a9a <try_preload_arg+0xa7a>
    3a95:      	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
    3a9a:      	movl	%ebp, (%rax)
    3a9c:      	jmp	0x3042 <try_preload_arg+0x22>

Disassembly of section uprobe:

0000000000000000 <generic_usdt_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x20, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movl	$0x0, 0x1c(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_usdt_setup_event+0x1b>
      1b:      	leaq	0x1c(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x9c6 <generic_usdt_setup_event+0x9c6>
      30:      	movq	%rax, %r14
      33:      	leaq	0x5ef8(%rax), %rsi
      3a:      	movq	(%rip), %rdi            # 0x41 <generic_usdt_setup_event+0x41>
      41:      	movl	$0x1, %eax
      46:      	callq	*%rax
      48:      	testq	%rax, %rax
      4b:      	je	0x9c6 <generic_usdt_setup_event+0x9c6>
      51:      	movq	%rax, %r15
      54:      	movb	$0x1c, (%r14)
      58:      	movw	$0x0, 0x2(%r14)
      5f:      	movl	$0x0, 0x4(%r14)
      67:      	movl	$0x7d, %eax
      6c:      	callq	*%rax
      6e:      	movq	%rax, 0x8(%r14)
      72:      	movq	$0x0, 0x70(%r14)
      7a:      	movl	$0x0, 0x14(%r14)
      82:      	movl	$0xe, %eax
      87:      	callq	*%rax
      89:      	movl	%eax, 0x7c(%r14)
      8d:      	movzbl	0x211(%r15), %ecx
      95:      	xorl	%eax, %eax
      97:      	cmpl	$0x2, %ecx
      9a:      	jg	0xe3 <generic_usdt_setup_event+0xe3>
      9c:      	cmpl	$0x1, %ecx
      9f:      	je	0x1ad <generic_usdt_setup_event+0x1ad>
      a5:      	cmpl	$0x2, %ecx
      a8:      	jne	0x242 <generic_usdt_setup_event+0x242>
      ae:      	movl	0x208(%r15), %edx
      b5:      	andl	$0xfff, %edx            # imm = 0xFFF
      bb:      	addq	%rbx, %rdx
      be:      	leaq	0x8(%rsp), %rdi
      c3:      	movl	$0x8, %ecx
      c8:      	movl	$0x71, %eax
      cd:      	movl	$0x8, %esi
      d2:      	callq	*%rax
      d4:      	testl	%eax, %eax
      d6:      	je	0x1b9 <generic_usdt_setup_event+0x1b9>
      dc:      	xorl	%eax, %eax
      de:      	jmp	0x242 <generic_usdt_setup_event+0x242>
      e3:      	cmpl	$0x3, %ecx
      e6:      	je	0x1e0 <generic_usdt_setup_event+0x1e0>
      ec:      	cmpl	$0x4, %ecx
      ef:      	jne	0x242 <generic_usdt_setup_event+0x242>
      f5:      	movl	0x208(%r15), %edx
      fc:      	andl	$0xfff, %edx            # imm = 0xFFF
     102:      	addq	%rbx, %rdx
     105:      	leaq	0x8(%rsp), %rdi
     10a:      	movl	$0x8, %ecx
     10f:      	movl	$0x71, %eax
     114:      	movl	$0x8, %esi
     119:      	callq	*%rax
     11b:      	testl	%eax, %eax
     11d:      	jne	0x240 <generic_usdt_setup_event+0x240>
     123:      	movl	0x20c(%r15), %edx
     12a:      	andl	$0xfff, %edx            # imm = 0xFFF
     130:      	addq	%rbx, %rdx
     133:      	leaq	0x10(%rsp), %rdi
     138:      	movl	$0x8, %ecx
     13d:      	movl	$0x71, %eax
     142:      	movl	$0x8, %esi
     147:      	callq	*%rax
     149:      	testl	%eax, %eax
     14b:      	jne	0x240 <generic_usdt_setup_event+0x240>
     151:      	movzbl	0x213(%r15), %eax
     159:      	shlxq	%rax, 0x10(%rsp), %rax
     160:      	movq	0x200(%r15), %rcx
     167:      	addq	0x8(%rsp), %rcx
     16c:      	addq	%rax, %rcx
     16f:      	leaq	0x8(%rsp), %rdi
     174:      	movl	$0x8, %edx
     179:      	movl	$0x70, %eax
     17e:      	movzbl	0x213(%r15), %ecx
     186:      	shlxq	%rcx, 0x10(%rsp), %rcx
     18d:      	movq	0x200(%r15), %rdx
     194:      	addq	0x8(%rsp), %rdx
     199:      	addq	%rcx, %rdx
     19c:      	movl	$0x8, %esi
     1a1:      	callq	*%rax
     1a3:      	testl	%eax, %eax
     1a5:      	jne	0x240 <generic_usdt_setup_event+0x240>
     1ab:      	jmp	0x1b9 <generic_usdt_setup_event+0x1b9>
     1ad:      	movq	0x200(%r15), %rax
     1b4:      	movq	%rax, 0x8(%rsp)
     1b9:      	movzbl	0x210(%r15), %eax
     1c1:      	shlxq	%rax, 0x8(%rsp), %rcx
     1c8:      	cmpb	$0x0, 0x212(%r15)
     1d0:      	shrxq	%rax, %rcx, %rdx
     1d5:      	sarxq	%rax, %rcx, %rax
     1da:      	cmoveq	%rdx, %rax
     1de:      	jmp	0x242 <generic_usdt_setup_event+0x242>
     1e0:      	movl	0x208(%r15), %edx
     1e7:      	andl	$0xfff, %edx            # imm = 0xFFF
     1ed:      	addq	%rbx, %rdx
     1f0:      	leaq	0x8(%rsp), %rdi
     1f5:      	movl	$0x8, %ecx
     1fa:      	movl	$0x71, %eax
     1ff:      	movl	$0x8, %esi
     204:      	callq	*%rax
     206:      	testl	%eax, %eax
     208:      	jne	0x240 <generic_usdt_setup_event+0x240>
     20a:      	movq	0x8(%rsp), %rcx
     20f:      	addq	0x200(%r15), %rcx
     216:      	leaq	0x8(%rsp), %rdi
     21b:      	movl	$0x8, %edx
     220:      	movl	$0x70, %eax
     225:      	movq	0x8(%rsp), %rdx
     22a:      	addq	0x200(%r15), %rdx
     231:      	movl	$0x8, %esi
     236:      	callq	*%rax
     238:      	testl	%eax, %eax
     23a:      	je	0x1b9 <generic_usdt_setup_event+0x1b9>
     240:      	cltq
     242:      	movq	%rax, 0x5e50(%r14)
     249:      	movzbl	0x229(%r15), %ecx
     251:      	xorl	%eax, %eax
     253:      	cmpl	$0x2, %ecx
     256:      	jg	0x29f <generic_usdt_setup_event+0x29f>
     258:      	cmpl	$0x1, %ecx
     25b:      	je	0x369 <generic_usdt_setup_event+0x369>
     261:      	cmpl	$0x2, %ecx
     264:      	jne	0x403 <generic_usdt_setup_event+0x403>
     26a:      	movl	0x220(%r15), %edx
     271:      	andl	$0xfff, %edx            # imm = 0xFFF
     277:      	addq	%rbx, %rdx
     27a:      	leaq	0x8(%rsp), %rdi
     27f:      	movl	$0x8, %ecx
     284:      	movl	$0x71, %eax
     289:      	movl	$0x8, %esi
     28e:      	callq	*%rax
     290:      	testl	%eax, %eax
     292:      	je	0x375 <generic_usdt_setup_event+0x375>
     298:      	xorl	%eax, %eax
     29a:      	jmp	0x403 <generic_usdt_setup_event+0x403>
     29f:      	cmpl	$0x3, %ecx
     2a2:      	je	0x3a1 <generic_usdt_setup_event+0x3a1>
     2a8:      	cmpl	$0x4, %ecx
     2ab:      	jne	0x403 <generic_usdt_setup_event+0x403>
     2b1:      	movl	0x220(%r15), %edx
     2b8:      	andl	$0xfff, %edx            # imm = 0xFFF
     2be:      	addq	%rbx, %rdx
     2c1:      	leaq	0x8(%rsp), %rdi
     2c6:      	movl	$0x8, %ecx
     2cb:      	movl	$0x71, %eax
     2d0:      	movl	$0x8, %esi
     2d5:      	callq	*%rax
     2d7:      	testl	%eax, %eax
     2d9:      	jne	0x401 <generic_usdt_setup_event+0x401>
     2df:      	movl	0x224(%r15), %edx
     2e6:      	andl	$0xfff, %edx            # imm = 0xFFF
     2ec:      	addq	%rbx, %rdx
     2ef:      	leaq	0x10(%rsp), %rdi
     2f4:      	movl	$0x8, %ecx
     2f9:      	movl	$0x71, %eax
     2fe:      	movl	$0x8, %esi
     303:      	callq	*%rax
     305:      	testl	%eax, %eax
     307:      	jne	0x401 <generic_usdt_setup_event+0x401>
     30d:      	movzbl	0x22b(%r15), %eax
     315:      	shlxq	%rax, 0x10(%rsp), %rax
     31c:      	movq	0x218(%r15), %rcx
     323:      	addq	0x8(%rsp), %rcx
     328:      	addq	%rax, %rcx
     32b:      	leaq	0x8(%rsp), %rdi
     330:      	movl	$0x8, %edx
     335:      	movl	$0x70, %eax
     33a:      	movzbl	0x22b(%r15), %ecx
     342:      	shlxq	%rcx, 0x10(%rsp), %rcx
     349:      	movq	0x218(%r15), %rdx
     350:      	addq	0x8(%rsp), %rdx
     355:      	addq	%rcx, %rdx
     358:      	movl	$0x8, %esi
     35d:      	callq	*%rax
     35f:      	testl	%eax, %eax
     361:      	jne	0x401 <generic_usdt_setup_event+0x401>
     367:      	jmp	0x375 <generic_usdt_setup_event+0x375>
     369:      	movq	0x218(%r15), %rax
     370:      	movq	%rax, 0x8(%rsp)
     375:      	movzbl	0x228(%r15), %eax
     37d:      	shlxq	%rax, 0x8(%rsp), %rcx
     384:      	movq	%rcx, 0x8(%rsp)
     389:      	cmpb	$0x0, 0x22a(%r15)
     391:      	shrxq	%rax, %rcx, %rdx
     396:      	sarxq	%rax, %rcx, %rax
     39b:      	cmoveq	%rdx, %rax
     39f:      	jmp	0x403 <generic_usdt_setup_event+0x403>
     3a1:      	movl	0x220(%r15), %edx
     3a8:      	andl	$0xfff, %edx            # imm = 0xFFF
     3ae:      	addq	%rbx, %rdx
     3b1:      	leaq	0x8(%rsp), %rdi
     3b6:      	movl	$0x8, %ecx
     3bb:      	movl	$0x71, %eax
     3c0:      	movl	$0x8, %esi
     3c5:      	callq	*%rax
     3c7:      	testl	%eax, %eax
     3c9:      	jne	0x401 <generic_usdt_setup_event+0x401>
     3cb:      	movq	0x8(%rsp), %rcx
     3d0:      	addq	0x218(%r15), %rcx
     3d7:      	leaq	0x8(%rsp), %rdi
     3dc:      	movl	$0x8, %edx
     3e1:      	movl	$0x70, %eax
     3e6:      	movq	0x8(%rsp), %rdx
     3eb:      	addq	0x218(%r15), %rdx
     3f2:      	movl	$0x8, %esi
     3f7:      	callq	*%rax
     3f9:      	testl	%eax, %eax
     3fb:      	je	0x375 <generic_usdt_setup_event+0x375>
     401:      	cltq
     403:      	movq	%rax, 0x5e58(%r14)
     40a:      	movzbl	0x241(%r15), %ecx
     412:      	xorl	%eax, %eax
     414:      	cmpl	$0x2, %ecx
     417:      	jg	0x460 <generic_usdt_setup_event+0x460>
     419:      	cmpl	$0x1, %ecx
     41c:      	je	0x52a <generic_usdt_setup_event+0x52a>
     422:      	cmpl	$0x2, %ecx
     425:      	jne	0x5c4 <generic_usdt_setup_event+0x5c4>
     42b:      	movl	0x238(%r15), %edx
     432:      	andl	$0xfff, %edx            # imm = 0xFFF
     438:      	addq	%rbx, %rdx
     43b:      	leaq	0x8(%rsp), %rdi
     440:      	movl	$0x8, %ecx
     445:      	movl	$0x71, %eax
     44a:      	movl	$0x8, %esi
     44f:      	callq	*%rax
     451:      	testl	%eax, %eax
     453:      	je	0x536 <generic_usdt_setup_event+0x536>
     459:      	xorl	%eax, %eax
     45b:      	jmp	0x5c4 <generic_usdt_setup_event+0x5c4>
     460:      	cmpl	$0x3, %ecx
     463:      	je	0x562 <generic_usdt_setup_event+0x562>
     469:      	cmpl	$0x4, %ecx
     46c:      	jne	0x5c4 <generic_usdt_setup_event+0x5c4>
     472:      	movl	0x238(%r15), %edx
     479:      	andl	$0xfff, %edx            # imm = 0xFFF
     47f:      	addq	%rbx, %rdx
     482:      	leaq	0x8(%rsp), %rdi
     487:      	movl	$0x8, %ecx
     48c:      	movl	$0x71, %eax
     491:      	movl	$0x8, %esi
     496:      	callq	*%rax
     498:      	testl	%eax, %eax
     49a:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     4a0:      	movl	0x23c(%r15), %edx
     4a7:      	andl	$0xfff, %edx            # imm = 0xFFF
     4ad:      	addq	%rbx, %rdx
     4b0:      	leaq	0x10(%rsp), %rdi
     4b5:      	movl	$0x8, %ecx
     4ba:      	movl	$0x71, %eax
     4bf:      	movl	$0x8, %esi
     4c4:      	callq	*%rax
     4c6:      	testl	%eax, %eax
     4c8:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     4ce:      	movzbl	0x243(%r15), %eax
     4d6:      	shlxq	%rax, 0x10(%rsp), %rax
     4dd:      	movq	0x230(%r15), %rcx
     4e4:      	addq	0x8(%rsp), %rcx
     4e9:      	addq	%rax, %rcx
     4ec:      	leaq	0x8(%rsp), %rdi
     4f1:      	movl	$0x8, %edx
     4f6:      	movl	$0x70, %eax
     4fb:      	movzbl	0x243(%r15), %ecx
     503:      	shlxq	%rcx, 0x10(%rsp), %rcx
     50a:      	movq	0x230(%r15), %rdx
     511:      	addq	0x8(%rsp), %rdx
     516:      	addq	%rcx, %rdx
     519:      	movl	$0x8, %esi
     51e:      	callq	*%rax
     520:      	testl	%eax, %eax
     522:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     528:      	jmp	0x536 <generic_usdt_setup_event+0x536>
     52a:      	movq	0x230(%r15), %rax
     531:      	movq	%rax, 0x8(%rsp)
     536:      	movzbl	0x240(%r15), %eax
     53e:      	shlxq	%rax, 0x8(%rsp), %rcx
     545:      	movq	%rcx, 0x8(%rsp)
     54a:      	cmpb	$0x0, 0x242(%r15)
     552:      	shrxq	%rax, %rcx, %rdx
     557:      	sarxq	%rax, %rcx, %rax
     55c:      	cmoveq	%rdx, %rax
     560:      	jmp	0x5c4 <generic_usdt_setup_event+0x5c4>
     562:      	movl	0x238(%r15), %edx
     569:      	andl	$0xfff, %edx            # imm = 0xFFF
     56f:      	addq	%rbx, %rdx
     572:      	leaq	0x8(%rsp), %rdi
     577:      	movl	$0x8, %ecx
     57c:      	movl	$0x71, %eax
     581:      	movl	$0x8, %esi
     586:      	callq	*%rax
     588:      	testl	%eax, %eax
     58a:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     58c:      	movq	0x8(%rsp), %rcx
     591:      	addq	0x230(%r15), %rcx
     598:      	leaq	0x8(%rsp), %rdi
     59d:      	movl	$0x8, %edx
     5a2:      	movl	$0x70, %eax
     5a7:      	movq	0x8(%rsp), %rdx
     5ac:      	addq	0x230(%r15), %rdx
     5b3:      	movl	$0x8, %esi
     5b8:      	callq	*%rax
     5ba:      	testl	%eax, %eax
     5bc:      	je	0x536 <generic_usdt_setup_event+0x536>
     5c2:      	cltq
     5c4:      	movq	%rax, 0x5e60(%r14)
     5cb:      	movzbl	0x259(%r15), %ecx
     5d3:      	xorl	%eax, %eax
     5d5:      	cmpl	$0x2, %ecx
     5d8:      	jg	0x621 <generic_usdt_setup_event+0x621>
     5da:      	cmpl	$0x1, %ecx
     5dd:      	je	0x6eb <generic_usdt_setup_event+0x6eb>
     5e3:      	cmpl	$0x2, %ecx
     5e6:      	jne	0x785 <generic_usdt_setup_event+0x785>
     5ec:      	movl	0x250(%r15), %edx
     5f3:      	andl	$0xfff, %edx            # imm = 0xFFF
     5f9:      	addq	%rbx, %rdx
     5fc:      	leaq	0x8(%rsp), %rdi
     601:      	movl	$0x8, %ecx
     606:      	movl	$0x71, %eax
     60b:      	movl	$0x8, %esi
     610:      	callq	*%rax
     612:      	testl	%eax, %eax
     614:      	je	0x6f7 <generic_usdt_setup_event+0x6f7>
     61a:      	xorl	%eax, %eax
     61c:      	jmp	0x785 <generic_usdt_setup_event+0x785>
     621:      	cmpl	$0x3, %ecx
     624:      	je	0x723 <generic_usdt_setup_event+0x723>
     62a:      	cmpl	$0x4, %ecx
     62d:      	jne	0x785 <generic_usdt_setup_event+0x785>
     633:      	movl	0x250(%r15), %edx
     63a:      	andl	$0xfff, %edx            # imm = 0xFFF
     640:      	addq	%rbx, %rdx
     643:      	leaq	0x8(%rsp), %rdi
     648:      	movl	$0x8, %ecx
     64d:      	movl	$0x71, %eax
     652:      	movl	$0x8, %esi
     657:      	callq	*%rax
     659:      	testl	%eax, %eax
     65b:      	jne	0x783 <generic_usdt_setup_event+0x783>
     661:      	movl	0x254(%r15), %edx
     668:      	andl	$0xfff, %edx            # imm = 0xFFF
     66e:      	addq	%rbx, %rdx
     671:      	leaq	0x10(%rsp), %rdi
     676:      	movl	$0x8, %ecx
     67b:      	movl	$0x71, %eax
     680:      	movl	$0x8, %esi
     685:      	callq	*%rax
     687:      	testl	%eax, %eax
     689:      	jne	0x783 <generic_usdt_setup_event+0x783>
     68f:      	movzbl	0x25b(%r15), %eax
     697:      	shlxq	%rax, 0x10(%rsp), %rax
     69e:      	movq	0x248(%r15), %rcx
     6a5:      	addq	0x8(%rsp), %rcx
     6aa:      	addq	%rax, %rcx
     6ad:      	leaq	0x8(%rsp), %rdi
     6b2:      	movl	$0x8, %edx
     6b7:      	movl	$0x70, %eax
     6bc:      	movzbl	0x25b(%r15), %ecx
     6c4:      	shlxq	%rcx, 0x10(%rsp), %rcx
     6cb:      	movq	0x248(%r15), %rdx
     6d2:      	addq	0x8(%rsp), %rdx
     6d7:      	addq	%rcx, %rdx
     6da:      	movl	$0x8, %esi
     6df:      	callq	*%rax
     6e1:      	testl	%eax, %eax
     6e3:      	jne	0x783 <generic_usdt_setup_event+0x783>
     6e9:      	jmp	0x6f7 <generic_usdt_setup_event+0x6f7>
     6eb:      	movq	0x248(%r15), %rax
     6f2:      	movq	%rax, 0x8(%rsp)
     6f7:      	movzbl	0x258(%r15), %eax
     6ff:      	shlxq	%rax, 0x8(%rsp), %rcx
     706:      	movq	%rcx, 0x8(%rsp)
     70b:      	cmpb	$0x0, 0x25a(%r15)
     713:      	shrxq	%rax, %rcx, %rdx
     718:      	sarxq	%rax, %rcx, %rax
     71d:      	cmoveq	%rdx, %rax
     721:      	jmp	0x785 <generic_usdt_setup_event+0x785>
     723:      	movl	0x250(%r15), %edx
     72a:      	andl	$0xfff, %edx            # imm = 0xFFF
     730:      	addq	%rbx, %rdx
     733:      	leaq	0x8(%rsp), %rdi
     738:      	movl	$0x8, %ecx
     73d:      	movl	$0x71, %eax
     742:      	movl	$0x8, %esi
     747:      	callq	*%rax
     749:      	testl	%eax, %eax
     74b:      	jne	0x783 <generic_usdt_setup_event+0x783>
     74d:      	movq	0x8(%rsp), %rcx
     752:      	addq	0x248(%r15), %rcx
     759:      	leaq	0x8(%rsp), %rdi
     75e:      	movl	$0x8, %edx
     763:      	movl	$0x70, %eax
     768:      	movq	0x8(%rsp), %rdx
     76d:      	addq	0x248(%r15), %rdx
     774:      	movl	$0x8, %esi
     779:      	callq	*%rax
     77b:      	testl	%eax, %eax
     77d:      	je	0x6f7 <generic_usdt_setup_event+0x6f7>
     783:      	cltq
     785:      	movq	%rax, 0x5e68(%r14)
     78c:      	movzbl	0x271(%r15), %ecx
     794:      	xorl	%eax, %eax
     796:      	cmpl	$0x2, %ecx
     799:      	jg	0x7e2 <generic_usdt_setup_event+0x7e2>
     79b:      	cmpl	$0x1, %ecx
     79e:      	je	0x8ac <generic_usdt_setup_event+0x8ac>
     7a4:      	cmpl	$0x2, %ecx
     7a7:      	jne	0x946 <generic_usdt_setup_event+0x946>
     7ad:      	movl	0x268(%r15), %edx
     7b4:      	andl	$0xfff, %edx            # imm = 0xFFF
     7ba:      	addq	%rbx, %rdx
     7bd:      	leaq	0x8(%rsp), %rdi
     7c2:      	movl	$0x8, %ecx
     7c7:      	movl	$0x71, %eax
     7cc:      	movl	$0x8, %esi
     7d1:      	callq	*%rax
     7d3:      	testl	%eax, %eax
     7d5:      	je	0x8b8 <generic_usdt_setup_event+0x8b8>
     7db:      	xorl	%eax, %eax
     7dd:      	jmp	0x946 <generic_usdt_setup_event+0x946>
     7e2:      	cmpl	$0x3, %ecx
     7e5:      	je	0x8e4 <generic_usdt_setup_event+0x8e4>
     7eb:      	cmpl	$0x4, %ecx
     7ee:      	jne	0x946 <generic_usdt_setup_event+0x946>
     7f4:      	movl	0x268(%r15), %edx
     7fb:      	andl	$0xfff, %edx            # imm = 0xFFF
     801:      	addq	%rbx, %rdx
     804:      	leaq	0x8(%rsp), %rdi
     809:      	movl	$0x8, %ecx
     80e:      	movl	$0x71, %eax
     813:      	movl	$0x8, %esi
     818:      	callq	*%rax
     81a:      	testl	%eax, %eax
     81c:      	jne	0x944 <generic_usdt_setup_event+0x944>
     822:      	movl	0x26c(%r15), %edx
     829:      	andl	$0xfff, %edx            # imm = 0xFFF
     82f:      	addq	%rbx, %rdx
     832:      	leaq	0x10(%rsp), %rdi
     837:      	movl	$0x8, %ecx
     83c:      	movl	$0x71, %eax
     841:      	movl	$0x8, %esi
     846:      	callq	*%rax
     848:      	testl	%eax, %eax
     84a:      	jne	0x944 <generic_usdt_setup_event+0x944>
     850:      	movzbl	0x273(%r15), %eax
     858:      	shlxq	%rax, 0x10(%rsp), %rax
     85f:      	movq	0x260(%r15), %rcx
     866:      	addq	0x8(%rsp), %rcx
     86b:      	addq	%rax, %rcx
     86e:      	leaq	0x8(%rsp), %rdi
     873:      	movl	$0x8, %edx
     878:      	movl	$0x70, %eax
     87d:      	movzbl	0x273(%r15), %ecx
     885:      	shlxq	%rcx, 0x10(%rsp), %rcx
     88c:      	movq	0x260(%r15), %rdx
     893:      	addq	0x8(%rsp), %rdx
     898:      	addq	%rcx, %rdx
     89b:      	movl	$0x8, %esi
     8a0:      	callq	*%rax
     8a2:      	testl	%eax, %eax
     8a4:      	jne	0x944 <generic_usdt_setup_event+0x944>
     8aa:      	jmp	0x8b8 <generic_usdt_setup_event+0x8b8>
     8ac:      	movq	0x260(%r15), %rax
     8b3:      	movq	%rax, 0x8(%rsp)
     8b8:      	movzbl	0x270(%r15), %eax
     8c0:      	shlxq	%rax, 0x8(%rsp), %rcx
     8c7:      	movq	%rcx, 0x8(%rsp)
     8cc:      	cmpb	$0x0, 0x272(%r15)
     8d4:      	shrxq	%rax, %rcx, %rdx
     8d9:      	sarxq	%rax, %rcx, %rax
     8de:      	cmoveq	%rdx, %rax
     8e2:      	jmp	0x946 <generic_usdt_setup_event+0x946>
     8e4:      	movl	0x268(%r15), %edx
     8eb:      	andl	$0xfff, %edx            # imm = 0xFFF
     8f1:      	addq	%rbx, %rdx
     8f4:      	leaq	0x8(%rsp), %rdi
     8f9:      	movl	$0x8, %ecx
     8fe:      	movl	$0x71, %eax
     903:      	movl	$0x8, %esi
     908:      	callq	*%rax
     90a:      	testl	%eax, %eax
     90c:      	jne	0x944 <generic_usdt_setup_event+0x944>
     90e:      	movq	0x8(%rsp), %rcx
     913:      	addq	0x260(%r15), %rcx
     91a:      	leaq	0x8(%rsp), %rdi
     91f:      	movl	$0x8, %edx
     924:      	movl	$0x70, %eax
     929:      	movq	0x8(%rsp), %rdx
     92e:      	addq	0x260(%r15), %rdx
     935:      	movl	$0x8, %esi
     93a:      	callq	*%rax
     93c:      	testl	%eax, %eax
     93e:      	je	0x8b8 <generic_usdt_setup_event+0x8b8>
     944:      	cltq
     946:      	movq	%rax, 0x5e70(%r14)
     94d:      	movl	$0x0, 0x8(%rsp)
     955:      	movq	(%rip), %rdi            # 0x95c <generic_usdt_setup_event+0x95c>
     95c:      	leaq	0x8(%rsp), %rsi
     961:      	movl	$0x1, %eax
     966:      	callq	*%rax
     968:      	testq	%rax, %rax
     96b:      	je	0x990 <generic_usdt_setup_event+0x990>
     96d:      	movq	%rax, %rsi
     970:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     977:      	movq	(%rip), %rdi            # 0x97e <generic_usdt_setup_event+0x97e>
     97e:      	movl	$0x1, %eax
     983:      	callq	*%rax
     985:      	testq	%rax, %rax
     988:      	je	0x990 <generic_usdt_setup_event+0x990>
     98a:      	cmpl	$-0x1, 0x40(%rax)
     98e:      	jne	0x9ab <generic_usdt_setup_event+0x9ab>
     990:      	movq	(%rip), %rsi            # 0x997 <generic_usdt_setup_event+0x997>
     997:      	movl	$0x3, %ecx
     99c:      	movl	$0xc, %eax
     9a1:      	movq	%rbx, %rdi
     9a4:      	movl	$0x3, %edx
     9a9:      	callq	*%rax
     9ab:      	movq	(%rip), %rsi            # 0x9b2 <generic_usdt_setup_event+0x9b2>
     9b2:      	movl	$0x1, %ecx
     9b7:      	movl	$0xc, %eax
     9bc:      	movq	%rbx, %rdi
     9bf:      	movl	$0x1, %edx
     9c4:      	callq	*%rax
     9c6:      	xorl	%eax, %eax
     9c8:      	addq	$0x20, %rsp
     9cc:      	popq	%rbx
     9cd:      	popq	%r14
     9cf:      	popq	%r15
     9d1:      	retq
     9d2:      	nopw	%cs:(%rax,%rax)

00000000000009e0 <generic_usdt_process_event>:
     9e0:      	pushq	%rbp
     9e1:      	pushq	%r15
     9e3:      	pushq	%r14
     9e5:      	pushq	%r13
     9e7:      	pushq	%r12
     9e9:      	pushq	%rbx
     9ea:      	subq	$0x108, %rsp            # imm = 0x108
     9f1:      	movq	%rdi, %rbx
     9f4:      	movl	$0x0, 0xec(%rsp)
     9ff:      	movq	(%rip), %rdi            # 0xa06 <generic_usdt_process_event+0x26>
     a06:      	leaq	0xec(%rsp), %rsi
     a0e:      	movl	$0x1, %eax
     a13:      	callq	*%rax
     a15:      	testq	%rax, %rax
     a18:      	je	0x2f4c <generic_usdt_process_event+0x256c>
     a1e:      	movq	%rax, %r14
     a21:      	movl	0x5efc(%rax), %r12d
     a28:      	movl	0x4(%rax), %r13d
     a2c:      	cmpq	$0x2327, %r13           # imm = 0x2327
     a33:      	ja	0xe67 <generic_usdt_process_event+0x487>
     a39:      	movl	$0x0, 0xf0(%rsp)
     a44:      	movq	(%rip), %rdi            # 0xa4b <generic_usdt_process_event+0x6b>
     a4b:      	leaq	0xf0(%rsp), %rsi
     a53:      	movl	$0x1, %eax
     a58:      	callq	*%rax
     a5a:      	testq	%rax, %rax
     a5d:      	je	0xe67 <generic_usdt_process_event+0x487>
     a63:      	movq	%rax, %r15
     a66:      	leaq	0x5ef8(%rax), %rsi
     a6d:      	movq	(%rip), %rdi            # 0xa74 <generic_usdt_process_event+0x94>
     a74:      	movl	$0x1, %eax
     a79:      	callq	*%rax
     a7b:      	cmpl	$0x4, %r12d
     a7f:      	jg	0xe67 <generic_usdt_process_event+0x487>
     a85:      	testq	%rax, %rax
     a88:      	je	0xe67 <generic_usdt_process_event+0x487>
     a8e:      	movq	%r13, 0xa8(%rsp)
     a96:      	movq	%r12, 0xc0(%rsp)
     a9e:      	movl	%r12d, %r13d
     aa1:      	andl	$0x7, %r13d
     aa5:      	movl	%r13d, %ecx
     aa8:      	movl	0x4(%rax,%rcx,4), %ebp
     aac:      	movslq	0x18(%rax,%rcx,4), %rdi
     ab1:      	leaq	(%r15,%rcx,4), %r12
     ab5:      	addq	$0x5ea0, %r12           # imm = 0x5EA0
     abc:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     ac8:      	movq	0x5e50(%r15,%rcx,8), %rsi
     ad0:      	movq	%rsi, 0xe0(%rsp)
     ad8:      	movq	%rdi, 0x18(%rsp)
     add:      	testl	$0x100, %edi            # imm = 0x100
     ae3:      	jne	0xaf6 <generic_usdt_process_event+0x116>
     ae5:      	cmpl	$0x4, %r13d
     ae9:      	movq	%r13, %rdx
     aec:      	jbe	0xb68 <generic_usdt_process_event+0x188>
     aee:      	movq	%rdx, %r13
     af1:      	jmp	0xc43 <generic_usdt_process_event+0x263>
     af6:      	movq	$0x0, 0x40(%rsp)
     aff:      	movl	$0xe, %eax
     b04:      	callq	*%rax
     b06:      	movq	%rax, 0x80(%rsp)
     b0e:      	movq	(%rip), %rdi            # 0xb15 <generic_usdt_process_event+0x135>
     b15:      	leaq	0x80(%rsp), %rsi
     b1d:      	movl	$0x1, %eax
     b22:      	callq	*%rax
     b24:      	testq	%rax, %rax
     b27:      	je	0xb56 <generic_usdt_process_event+0x176>
     b29:      	movl	(%rax), %ecx
     b2b:      	movl	%ecx, (%r12)
     b2f:      	cmpl	$0x6, %ebp
     b32:      	jne	0xb56 <generic_usdt_process_event+0x176>
     b34:      	addq	$0x4, %rax
     b38:      	movq	%rax, 0x40(%rsp)
     b3d:      	leaq	0x40(%rsp), %rdi
     b42:      	movl	$0x8, %ecx
     b47:      	movl	$0x4, %eax
     b4c:      	movl	$0x8, %esi
     b51:      	movq	%rdi, %rdx
     b54:      	callq	*%rax
     b56:      	movq	0x40(%rsp), %rsi
     b5b:      	movq	%rsi, 0xe0(%rsp)
     b63:      	jmp	0xc43 <generic_usdt_process_event+0x263>
     b68:      	movq	%rdx, %r13
     b6b:      	leaq	(%rdx,%rdx,4), %rcx
     b6f:      	shll	$0x4, %ecx
     b72:      	cmpw	$0x0, 0x76(%rax,%rcx)
     b78:      	je	0xc43 <generic_usdt_process_event+0x263>
     b7e:      	addq	%rcx, %rax
     b81:      	addq	$0x70, %rax
     b85:      	movq	%rax, 0x40(%rsp)
     b8a:      	leaq	0xe0(%rsp), %rax
     b92:      	movq	%rax, 0x48(%rsp)
     b97:      	movb	$0x0, 0x50(%rsp)
     b9c:      	movq	%r12, 0x58(%rsp)
     ba1:      	movq	(%rip), %rax            # 0xba8 <generic_usdt_process_event+0x1c8>
     ba8:      	cmpb	$0x0, (%rax)
     bab:      	je	0xc0d <generic_usdt_process_event+0x22d>
     bad:      	xorl	%r15d, %r15d
     bb0:      	movl	$0x8, %r12d
     bb6:      	jmp	0xbd9 <generic_usdt_process_event+0x1f9>
     bb8:      	movl	$0x4, %eax
     bbd:      	movq	0x48(%rsp), %rdi
     bc2:      	movq	(%rdi), %rdx
     bc5:      	movl	$0x8, %esi
     bca:      	callq	*%rax
     bcc:      	testl	%eax, %eax
     bce:      	js	0xc30 <generic_usdt_process_event+0x250>
     bd0:      	incq	%r15
     bd3:      	cmpq	$0xa, %r15
     bd7:      	je	0xc3b <generic_usdt_process_event+0x25b>
     bd9:      	movq	0x40(%rsp), %rax
     bde:      	cmpw	$0x0, 0x6(%rax,%r15,8)
     be5:      	je	0xc3b <generic_usdt_process_event+0x25b>
     be7:      	movq	0x48(%rsp), %rcx
     bec:      	movl	(%rax,%r15,8), %edx
     bf0:      	addq	(%rcx), %rdx
     bf3:      	movq	%rdx, (%rcx)
     bf6:      	cmpw	$0x0, 0x4(%rax,%r15,8)
     bfd:      	je	0xbd0 <generic_usdt_process_event+0x1f0>
     bff:      	cmpb	$0x0, 0x50(%rsp)
     c04:      	je	0xbb8 <generic_usdt_process_event+0x1d8>
     c06:      	movl	$0x94, %eax
     c0b:      	jmp	0xbbd <generic_usdt_process_event+0x1dd>
     c0d:      	leaq	(%rip), %rsi            # 0xc14 <generic_usdt_process_event+0x234>
     c14:      	xorl	%ecx, %ecx
     c16:      	leaq	0x40(%rsp), %rdx
     c1b:      	movl	$0xa, %edi
     c20:      	movl	$0xb5, %eax
     c25:      	movl	$0xa, %edi
     c2a:      	xorl	%ecx, %ecx
     c2c:      	callq	*%rax
     c2e:      	jmp	0xc3b <generic_usdt_process_event+0x25b>
     c30:      	incl	%r15d
     c33:      	movq	0x58(%rsp), %rax
     c38:      	movl	%r15d, (%rax)
     c3b:      	movq	0xe0(%rsp), %rsi
     c43:      	movq	%rsi, 0x10(%rsp)
     c48:      	movl	$0x1000, %r15d          # imm = 0x1000
     c4e:      	cmpl	$0x15, %ebp
     c51:      	jg	0xc84 <generic_usdt_process_event+0x2a4>
     c53:      	cmpl	$0xb, %ebp
     c56:      	jg	0xcb1 <generic_usdt_process_event+0x2d1>
     c58:      	cmpl	$0x5, %ebp
     c5b:      	jg	0xd2f <generic_usdt_process_event+0x34f>
     c61:      	cmpl	$0x3, %ebp
     c64:      	jg	0xda8 <generic_usdt_process_event+0x3c8>
     c6a:      	leal	-0x2(%rbp), %eax
     c6d:      	cmpl	$0x2, %eax
     c70:      	jb	0xd72 <generic_usdt_process_event+0x392>
     c76:      	cmpl	$0x1, %ebp
     c79:      	je	0xd72 <generic_usdt_process_event+0x392>
     c7f:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     c84:      	cmpl	$0x20, %ebp
     c87:      	jle	0xcd7 <generic_usdt_process_event+0x2f7>
     c89:      	cmpl	$0x27, %ebp
     c8c:      	jg	0xd00 <generic_usdt_process_event+0x320>
     c8e:      	leal	-0x21(%rbp), %eax
     c91:      	cmpl	$0x4, %eax
     c94:      	jb	0xdba <generic_usdt_process_event+0x3da>
     c9a:      	cmpl	$0x25, %ebp
     c9d:      	je	0xdda <generic_usdt_process_event+0x3fa>
     ca3:      	cmpl	$0x27, %ebp
     ca6:      	je	0xd7a <generic_usdt_process_event+0x39a>
     cac:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     cb1:      	cmpl	$0x11, %ebp
     cb4:      	jg	0xd54 <generic_usdt_process_event+0x374>
     cba:      	leal	-0xf(%rbp), %eax
     cbd:      	cmpl	$0x3, %eax
     cc0:      	jb	0xdda <generic_usdt_process_event+0x3fa>
     cc6:      	leal	-0xc(%rbp), %eax
     cc9:      	cmpl	$0x2, %eax
     ccc:      	jb	0xd72 <generic_usdt_process_event+0x392>
     cd2:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     cd7:      	cmpl	$0x1a, %ebp
     cda:      	jg	0xd6a <generic_usdt_process_event+0x38a>
     ce0:      	cmpl	$0x16, %ebp
     ce3:      	je	0xd7a <generic_usdt_process_event+0x39a>
     ce9:      	cmpl	$0x17, %ebp
     cec:      	je	0xdba <generic_usdt_process_event+0x3da>
     cf2:      	cmpl	$0x1a, %ebp
     cf5:      	je	0xdcf <generic_usdt_process_event+0x3ef>
     cfb:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     d00:      	cmpl	$0x29, %ebp
     d03:      	jle	0xd94 <generic_usdt_process_event+0x3b4>
     d09:      	cmpl	$0x2a, %ebp
     d0c:      	je	0xdda <generic_usdt_process_event+0x3fa>
     d12:      	cmpl	$0x2b, %ebp
     d15:      	je	0xda0 <generic_usdt_process_event+0x3c0>
     d1b:      	cmpl	$0x2c, %ebp
     d1e:      	jne	0xdd7 <generic_usdt_process_event+0x3f7>
     d24:      	movl	$0x70, %r15d
     d2a:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     d2f:      	cmpl	$0x9, %ebp
     d32:      	jg	0xdba <generic_usdt_process_event+0x3da>
     d38:      	cmpl	$0x6, %ebp
     d3b:      	je	0xdda <generic_usdt_process_event+0x3fa>
     d41:      	cmpl	$0x7, %ebp
     d44:      	je	0xdb2 <generic_usdt_process_event+0x3d2>
     d46:      	cmpl	$0x8, %ebp
     d49:      	je	0xdcf <generic_usdt_process_event+0x3ef>
     d4f:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     d54:      	cmpl	$0x13, %ebp
     d57:      	jg	0xd82 <generic_usdt_process_event+0x3a2>
     d59:      	movq	0x18(%rsp), %r15
     d5e:      	cmpl	$0x12, %ebp
     d61:      	je	0xdda <generic_usdt_process_event+0x3fa>
     d63:      	cmpl	$0x13, %ebp
     d66:      	je	0xda0 <generic_usdt_process_event+0x3c0>
     d68:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     d6a:      	leal	-0x1d(%rbp), %eax
     d6d:      	cmpl	$0x4, %eax
     d70:      	jae	0xdca <generic_usdt_process_event+0x3ea>
     d72:      	movl	$0x4, %r15d
     d78:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     d7a:      	movl	$0x10, %r15d
     d80:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     d82:      	cmpl	$0x14, %ebp
     d85:      	je	0xdc2 <generic_usdt_process_event+0x3e2>
     d87:      	cmpl	$0x15, %ebp
     d8a:      	jne	0xdd7 <generic_usdt_process_event+0x3f7>
     d8c:      	movl	$0x20, %r15d
     d92:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     d94:      	cmpl	$0x28, %ebp
     d97:      	je	0xda0 <generic_usdt_process_event+0x3c0>
     d99:      	cmpl	$0x29, %ebp
     d9c:      	je	0xdb2 <generic_usdt_process_event+0x3d2>
     d9e:      	jmp	0xdd7 <generic_usdt_process_event+0x3f7>
     da0:      	movl	$0x18, %r15d
     da6:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     da8:      	cmpl	$0x4, %ebp
     dab:      	je	0xdba <generic_usdt_process_event+0x3da>
     dad:      	cmpl	$0x5, %ebp
     db0:      	jne	0xdd7 <generic_usdt_process_event+0x3f7>
     db2:      	movl	$0x40, %r15d
     db8:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     dba:      	movl	$0x8, %r15d
     dc0:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     dc2:      	movl	$0x98, %r15d
     dc8:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     dca:      	cmpl	$0x1b, %ebp
     dcd:      	jne	0xdd7 <generic_usdt_process_event+0x3f7>
     dcf:      	movl	$0x50, %r15d
     dd5:      	jmp	0xdda <generic_usdt_process_event+0x3fa>
     dd7:      	xorl	%r15d, %r15d
     dda:      	movl	$0x0, 0xf4(%rsp)
     de5:      	movq	(%rip), %rdi            # 0xdec <generic_usdt_process_event+0x40c>
     dec:      	leaq	0xf4(%rsp), %rsi
     df4:      	movl	$0x1, %eax
     df9:      	callq	*%rax
     dfb:      	testq	%rax, %rax
     dfe:      	je	0xe57 <generic_usdt_process_event+0x477>
     e00:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     e05:      	subq	%r15, %rcx
     e08:      	cmpq	0xa8(%rsp), %rcx
     e10:      	jbe	0xe57 <generic_usdt_process_event+0x477>
     e12:      	movl	0x5ea0(%rax,%r13,4), %ecx
     e1a:      	movq	0xa8(%rsp), %rdx
     e22:      	movl	%ecx, 0x90(%rax,%rdx)
     e29:      	leaq	0x4(%rdx), %rsi
     e2d:      	movq	%rsi, 0x5e78(%rax,%r13,8)
     e35:      	movl	$0x4, %edx
     e3a:      	testl	%ecx, %ecx
     e3c:      	je	0xef5 <generic_usdt_process_event+0x515>
     e42:      	movq	0xc0(%rsp), %r12
     e4a:      	movq	0xa8(%rsp), %r13
     e52:      	jmp	0x2f12 <generic_usdt_process_event+0x2532>
     e57:      	movq	0xc0(%rsp), %r12
     e5f:      	movq	0xa8(%rsp), %r13
     e67:      	movl	%r13d, 0x4(%r14)
     e6b:      	cmpl	$0x3, %r12d
     e6f:      	jg	0x2f26 <generic_usdt_process_event+0x2546>
     e75:      	movl	$0x0, 0x40(%rsp)
     e7d:      	movq	(%rip), %rdi            # 0xe84 <generic_usdt_process_event+0x4a4>
     e84:      	leaq	0x40(%rsp), %rsi
     e89:      	movl	$0x1, %eax
     e8e:      	callq	*%rax
     e90:      	testq	%rax, %rax
     e93:      	je	0x2f26 <generic_usdt_process_event+0x2546>
     e99:      	movq	%rax, %rsi
     e9c:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     ea3:      	movq	(%rip), %rdi            # 0xeaa <generic_usdt_process_event+0x4ca>
     eaa:      	movl	$0x1, %eax
     eaf:      	callq	*%rax
     eb1:      	testq	%rax, %rax
     eb4:      	je	0x2f26 <generic_usdt_process_event+0x2546>
     eba:      	incl	%r12d
     ebd:      	movl	%r12d, %ecx
     ec0:      	andl	$0x7, %ecx
     ec3:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     ec8:      	je	0x2f26 <generic_usdt_process_event+0x2546>
     ece:      	movl	%r12d, 0x5efc(%r14)
     ed5:      	movq	(%rip), %rsi            # 0xedc <generic_usdt_process_event+0x4fc>
     edc:      	movl	$0x1, %ecx
     ee1:      	movl	$0xc, %eax
     ee6:      	movq	%rbx, %rdi
     ee9:      	movl	$0x1, %edx
     eee:      	callq	*%rax
     ef0:      	jmp	0x2f26 <generic_usdt_process_event+0x2546>
     ef5:      	movl	0x18(%rsp), %ecx
     ef9:      	movq	%rax, %r12
     efc:      	addq	$0x90, %r12
     f03:      	andl	$0x3fff, %esi           # imm = 0x3FFF
     f09:      	addq	%rsi, %r12
     f0c:      	movq	0x10(%rsp), %r15
     f11:      	movq	%r15, 0x40(%rsp)
     f16:      	movq	$0x0, 0x80(%rsp)
     f22:      	cmpl	$0x17, %ebp
     f25:      	movq	%rbx, 0x8(%rsp)
     f2a:      	movq	%rax, (%rsp)
     f2e:      	jle	0xf68 <generic_usdt_process_event+0x588>
     f30:      	cmpl	$0x18, %ebp
     f33:      	je	0xf81 <generic_usdt_process_event+0x5a1>
     f35:      	cmpl	$0x25, %ebp
     f38:      	je	0xfc2 <generic_usdt_process_event+0x5e2>
     f3e:      	cmpl	$0x2a, %ebp
     f41:      	jne	0x167a <generic_usdt_process_event+0xc9a>
     f47:      	movq	$0x0, 0xf8(%rsp)
     f53:      	movq	%r15, 0x100(%rsp)
     f5b:      	leaq	0xf8(%rsp), %rax
     f63:      	jmp	0xfef <generic_usdt_process_event+0x60f>
     f68:      	cmpl	$0xf, %ebp
     f6b:      	je	0x15a7 <generic_usdt_process_event+0xbc7>
     f71:      	cmpl	$0x10, %ebp
     f74:      	jne	0x167a <generic_usdt_process_event+0xc9a>
     f7a:      	leaq	0x20(%rsp), %r15
     f7f:      	jmp	0xfac <generic_usdt_process_event+0x5cc>
     f81:      	movq	%r15, %rdx
     f84:      	leaq	0x20(%rsp), %r15
     f89:      	movl	$0x8, %ecx
     f8e:      	movl	$0x4, %eax
     f93:      	movq	0x40(%rsp), %rdx
     f98:      	movq	%r15, %rdi
     f9b:      	movl	$0x8, %esi
     fa0:      	callq	*%rax
     fa2:      	movq	0x20(%rsp), %rax
     fa7:      	movq	%rax, 0x40(%rsp)
     fac:      	leaq	0x40(%rsp), %rdx
     fb1:      	movl	$0x8, %ecx
     fb6:      	movl	$0x4, %eax
     fbb:      	leaq	0x20(%rsp), %rdi
     fc0:      	jmp	0xfdf <generic_usdt_process_event+0x5ff>
     fc2:      	addq	$0x40, %r15
     fc6:      	movq	%r15, 0x40(%rsp)
     fcb:      	leaq	0x20(%rsp), %rdi
     fd0:      	movl	$0x8, %ecx
     fd5:      	movl	$0x4, %eax
     fda:      	movq	0x40(%rsp), %rdx
     fdf:      	movl	$0x8, %esi
     fe4:      	callq	*%rax
     fe6:      	movq	0x20(%rsp), %rax
     feb:      	addq	$0x40, %rax
     fef:      	movq	%rax, 0xb0(%rsp)
     ff7:      	movq	%r12, 0x30(%rsp)
     ffc:      	movl	$0x0, 0x98(%rsp)
    1007:      	movq	(%rip), %rdi            # 0x100e <generic_usdt_process_event+0x62e>
    100e:      	leaq	0x98(%rsp), %rsi
    1016:      	movl	$0x1, %eax
    101b:      	callq	*%rax
    101d:      	testq	%rax, %rax
    1020:      	je	0x10d7 <generic_usdt_process_event+0x6f7>
    1026:      	movq	%rax, %r12
    1029:      	movq	%r13, 0xd8(%rsp)
    1031:      	addq	$0x1000, %rax           # imm = 0x1000
    1037:      	movq	%rax, 0x18(%rsp)
    103c:      	movl	$0x23, %eax
    1041:      	callq	*%rax
    1043:      	leaq	0xd50(%rax), %rdx
    104a:      	leaq	0xd0(%rsp), %rdi
    1052:      	movl	$0x8, %ecx
    1057:      	movl	$0x4, %eax
    105c:      	movl	$0x8, %esi
    1061:      	callq	*%rax
    1063:      	movq	0xd0(%rsp), %r13
    106b:      	movq	0xb0(%rsp), %rax
    1073:      	leaq	0x8(%rax), %rdx
    1077:      	leaq	0xb8(%rsp), %rdi
    107f:      	movl	$0x8, %ecx
    1084:      	movl	$0x4, %eax
    1089:      	leaq	0x18(%r13), %rcx
    108d:      	movq	%rcx, 0x90(%rsp)
    1095:      	movl	$0x8, %esi
    109a:      	movq	%rdx, 0x10(%rsp)
    109f:      	callq	*%rax
    10a1:      	movq	0xb8(%rsp), %r15
    10a9:      	leaq	0x10(%r15), %rdx
    10ad:      	leaq	0x40(%rsp), %rdi
    10b2:      	movl	$0x8, %ecx
    10b7:      	movl	$0x4, %eax
    10bc:      	movl	$0x8, %esi
    10c1:      	callq	*%rax
    10c3:      	cmpq	$0x0, 0x40(%rsp)
    10c9:      	movl	$0x1000, %ebp           # imm = 0x1000
    10ce:      	je	0x10ee <generic_usdt_process_event+0x70e>
    10d0:      	movq	0x18(%rsp), %rcx
    10d5:      	jmp	0x1140 <generic_usdt_process_event+0x760>
    10d7:      	xorl	%edx, %edx
    10d9:      	movq	0xc0(%rsp), %r12
    10e1:      	movq	0xa8(%rsp), %r13
    10e9:      	jmp	0x2ee3 <generic_usdt_process_event+0x2503>
    10ee:      	leaq	0x18(%r15), %rdx
    10f2:      	leaq	0x40(%rsp), %rdi
    10f7:      	movl	$0x8, %ecx
    10fc:      	movl	$0x4, %eax
    1101:      	movl	$0x8, %esi
    1106:      	callq	*%rax
    1108:      	cmpq	%r15, 0x40(%rsp)
    110d:      	movq	0x18(%rsp), %rcx
    1112:      	je	0x1140 <generic_usdt_process_event+0x760>
    1114:      	movq	%r12, %rcx
    1117:      	addq	$0xff6, %rcx            # imm = 0xFF6
    111e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    1128:      	movq	%rax, 0xff6(%r12)
    1130:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    113b:      	movl	$0xff6, %ebp            # imm = 0xFF6
    1140:      	movq	$0x0, 0x48(%rsp)
    1149:      	movq	$0x0, 0x40(%rsp)
    1152:      	movq	%r12, 0x50(%rsp)
    1157:      	movq	$0x0, 0x58(%rsp)
    1160:      	movq	$0x0, 0x60(%rsp)
    1169:      	movq	$0x0, 0x68(%rsp)
    1172:      	movq	%rcx, 0x18(%rsp)
    1177:      	movq	%rcx, 0x70(%rsp)
    117c:      	movl	%ebp, 0x78(%rsp)
    1180:      	movb	$0x0, 0x7c(%rsp)
    1185:      	addq	$0x20, %r13
    1189:      	leaq	0x40(%rsp), %rdi
    118e:      	movl	$0x8, %ecx
    1193:      	movl	$0x4, %eax
    1198:      	leaq	0x48(%rsp), %r12
    119d:      	leaq	0x58(%rsp), %r15
    11a2:      	leaq	0x60(%rsp), %rbp
    11a7:      	movl	$0x8, %esi
    11ac:      	movq	%r13, %rdx
    11af:      	callq	*%rax
    11b1:      	movl	$0x8, %ecx
    11b6:      	movl	$0x4, %eax
    11bb:      	movq	0x90(%rsp), %rdx
    11c3:      	movq	%r12, %rdi
    11c6:      	movl	$0x8, %esi
    11cb:      	callq	*%rax
    11cd:      	movl	$0x8, %ecx
    11d2:      	movl	$0x4, %eax
    11d7:      	movq	0x10(%rsp), %rdx
    11dc:      	movq	%r15, %rdi
    11df:      	movl	$0x8, %esi
    11e4:      	callq	*%rax
    11e6:      	movl	$0x8, %ecx
    11eb:      	movl	$0x4, %eax
    11f0:      	movq	0xb0(%rsp), %rdx
    11f8:      	movq	%rbp, %rdi
    11fb:      	movl	$0x8, %esi
    1200:      	callq	*%rax
    1202:      	movq	0x60(%rsp), %rax
    1207:      	addq	$-0x20, %rax
    120b:      	movq	%rax, 0x68(%rsp)
    1210:      	movq	(%rip), %rax            # 0x1217 <generic_usdt_process_event+0x837>
    1217:      	cmpb	$0x0, (%rax)
    121a:      	je	0x13e6 <generic_usdt_process_event+0xa06>
    1220:      	movl	$0x800, %ebp            # imm = 0x800
    1225:      	movl	$0x8, %r15d
    122b:      	movq	0x58(%rsp), %r12
    1230:      	movq	0x60(%rsp), %rdx
    1235:      	movq	0x68(%rsp), %r13
    123a:      	cmpq	0x40(%rsp), %r12
    123f:      	jne	0x124c <generic_usdt_process_event+0x86c>
    1241:      	cmpq	0x48(%rsp), %rdx
    1246:      	je	0x1729 <generic_usdt_process_event+0xd49>
    124c:      	movl	$0x4, %eax
    1251:      	leaq	0x38(%rsp), %rdi
    1256:      	movl	$0x8, %esi
    125b:      	callq	*%rax
    125d:      	cmpq	0x38(%rsp), %r12
    1262:      	movl	$0x8, %ebx
    1267:      	je	0x137e <generic_usdt_process_event+0x99e>
    126d:      	leaq	0x18(%r12), %r15
    1272:      	movl	$0x4, %eax
    1277:      	leaq	0x20(%rsp), %rdi
    127c:      	movl	$0x8, %esi
    1281:      	movq	%r15, %rdx
    1284:      	callq	*%rax
    1286:      	cmpq	%r12, 0x20(%rsp)
    128b:      	je	0x137e <generic_usdt_process_event+0x99e>
    1291:      	movl	$0x4, %eax
    1296:      	leaq	0xa0(%rsp), %rdi
    129e:      	movl	$0x8, %esi
    12a3:      	movq	%r15, %rdx
    12a6:      	callq	*%rax
    12a8:      	addq	$0x20, %r12
    12ac:      	movl	$0x4, %eax
    12b1:      	leaq	0x80(%rsp), %rdi
    12b9:      	movl	$0x10, %ecx
    12be:      	movl	$0x10, %esi
    12c3:      	movq	%r12, %rdx
    12c6:      	callq	*%rax
    12c8:      	movq	0x50(%rsp), %r15
    12cd:      	movq	0x70(%rsp), %rax
    12d2:      	movl	0x84(%rsp), %r12d
    12da:      	subq	%r15, %rax
    12dd:      	movl	0x78(%rsp), %r13d
    12e2:      	movl	%r12d, %edx
    12e5:      	subl	%r13d, %edx
    12e8:      	movl	$0x0, %ecx
    12ed:      	cmovbl	%ecx, %edx
    12f0:      	addq	0x88(%rsp), %rdx
    12f8:      	xorl	%esi, %esi
    12fa:      	cmpl	%r12d, %r13d
    12fd:      	seta	%sil
    1301:      	movl	%r12d, %ecx
    1304:      	cmovbl	%r13d, %ecx
    1308:      	addl	%ecx, %esi
    130a:      	movl	%r13d, %edi
    130d:      	subl	%esi, %edi
    130f:      	movl	%edi, 0x78(%rsp)
    1313:      	subq	%rsi, %rax
    1316:      	movq	0x8(%rsp), %rbx
    131b:      	jb	0x173a <generic_usdt_process_event+0xd5a>
    1321:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1327:      	ja	0x173a <generic_usdt_process_event+0xd5a>
    132d:      	cmpl	%r12d, %r13d
    1330:      	jbe	0x1337 <generic_usdt_process_event+0x957>
    1332:      	movb	$0x2f, (%r15,%rax)
    1337:      	xorl	%edi, %edi
    1339:      	cmpl	%r12d, %r13d
    133c:      	seta	%dil
    1340:      	movzbl	%cl, %esi
    1343:      	addq	%rax, %r15
    1346:      	addq	%r15, %rdi
    1349:      	movl	$0x4, %eax
    134e:      	callq	*%rax
    1350:      	movq	%r15, 0x70(%rsp)
    1355:      	cmpl	%r12d, %r13d
    1358:      	jbe	0x173a <generic_usdt_process_event+0xd5a>
    135e:      	movq	0xa0(%rsp), %rax
    1366:      	movq	%rax, 0x58(%rsp)
    136b:      	movl	$0x8, %r15d
    1371:      	decl	%ebp
    1373:      	jne	0x122b <generic_usdt_process_event+0x84b>
    1379:      	jmp	0x173a <generic_usdt_process_event+0xd5a>
    137e:      	leaq	0x10(%r13), %rdx
    1382:      	movl	$0x4, %eax
    1387:      	leaq	0x20(%rsp), %rdi
    138c:      	movl	$0x8, %esi
    1391:      	callq	*%rax
    1393:      	movq	0x68(%rsp), %rax
    1398:      	cmpq	0x20(%rsp), %rax
    139d:      	movl	$0x8, %r15d
    13a3:      	je	0x1730 <generic_usdt_process_event+0xd50>
    13a9:      	addq	$0x18, %r13
    13ad:      	movl	$0x4, %eax
    13b2:      	leaq	0x58(%rsp), %rdi
    13b7:      	movl	$0x8, %esi
    13bc:      	movq	%r13, %rdx
    13bf:      	callq	*%rax
    13c1:      	movq	0x20(%rsp), %rax
    13c6:      	movq	%rax, 0x68(%rsp)
    13cb:      	addq	$0x20, %rax
    13cf:      	movq	%rax, 0x60(%rsp)
    13d4:      	movq	0x8(%rsp), %rbx
    13d9:      	decl	%ebp
    13db:      	jne	0x122b <generic_usdt_process_event+0x84b>
    13e1:      	jmp	0x173a <generic_usdt_process_event+0xd5a>
    13e6:      	movl	$0x800, %ebp            # imm = 0x800
    13eb:      	movl	$0x8, %r15d
    13f1:      	movq	0x58(%rsp), %r12
    13f6:      	movq	0x60(%rsp), %rdx
    13fb:      	movq	0x68(%rsp), %r13
    1400:      	cmpq	0x40(%rsp), %r12
    1405:      	jne	0x1412 <generic_usdt_process_event+0xa32>
    1407:      	cmpq	0x48(%rsp), %rdx
    140c:      	je	0x1729 <generic_usdt_process_event+0xd49>
    1412:      	movl	$0x4, %eax
    1417:      	leaq	0x38(%rsp), %rdi
    141c:      	movl	$0x8, %esi
    1421:      	callq	*%rax
    1423:      	cmpq	0x38(%rsp), %r12
    1428:      	movl	$0x8, %ecx
    142d:      	je	0x1544 <generic_usdt_process_event+0xb64>
    1433:      	leaq	0x18(%r12), %r15
    1438:      	movl	$0x4, %eax
    143d:      	leaq	0x20(%rsp), %rdi
    1442:      	movl	$0x8, %esi
    1447:      	movq	%r15, %rdx
    144a:      	callq	*%rax
    144c:      	movl	$0x8, %ecx
    1451:      	cmpq	%r12, 0x20(%rsp)
    1456:      	je	0x1544 <generic_usdt_process_event+0xb64>
    145c:      	movl	$0x4, %eax
    1461:      	leaq	0xa0(%rsp), %rdi
    1469:      	movl	$0x8, %esi
    146e:      	movq	%r15, %rdx
    1471:      	callq	*%rax
    1473:      	addq	$0x20, %r12
    1477:      	movl	$0x4, %eax
    147c:      	leaq	0x80(%rsp), %rdi
    1484:      	movl	$0x10, %ecx
    1489:      	movl	$0x10, %esi
    148e:      	movq	%r12, %rdx
    1491:      	callq	*%rax
    1493:      	movq	0x50(%rsp), %r15
    1498:      	movq	0x70(%rsp), %rax
    149d:      	movl	0x84(%rsp), %r12d
    14a5:      	subq	%r15, %rax
    14a8:      	movl	0x78(%rsp), %r13d
    14ad:      	movl	%r12d, %edx
    14b0:      	subl	%r13d, %edx
    14b3:      	movl	$0x0, %ecx
    14b8:      	cmovbl	%ecx, %edx
    14bb:      	addq	0x88(%rsp), %rdx
    14c3:      	xorl	%esi, %esi
    14c5:      	cmpl	%r12d, %r13d
    14c8:      	seta	%sil
    14cc:      	movl	%r12d, %ecx
    14cf:      	cmovbl	%r13d, %ecx
    14d3:      	addl	%ecx, %esi
    14d5:      	movl	%r13d, %edi
    14d8:      	subl	%esi, %edi
    14da:      	movl	%edi, 0x78(%rsp)
    14de:      	subq	%rsi, %rax
    14e1:      	jb	0x173a <generic_usdt_process_event+0xd5a>
    14e7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    14ed:      	ja	0x173a <generic_usdt_process_event+0xd5a>
    14f3:      	cmpl	%r12d, %r13d
    14f6:      	jbe	0x14fd <generic_usdt_process_event+0xb1d>
    14f8:      	movb	$0x2f, (%r15,%rax)
    14fd:      	xorl	%edi, %edi
    14ff:      	cmpl	%r12d, %r13d
    1502:      	seta	%dil
    1506:      	movzbl	%cl, %esi
    1509:      	addq	%rax, %r15
    150c:      	addq	%r15, %rdi
    150f:      	movl	$0x4, %eax
    1514:      	callq	*%rax
    1516:      	movq	%r15, 0x70(%rsp)
    151b:      	cmpl	%r12d, %r13d
    151e:      	jbe	0x173a <generic_usdt_process_event+0xd5a>
    1524:      	movq	0xa0(%rsp), %rax
    152c:      	movq	%rax, 0x58(%rsp)
    1531:      	movl	$0x8, %r15d
    1537:      	decl	%ebp
    1539:      	jne	0x13f1 <generic_usdt_process_event+0xa11>
    153f:      	jmp	0x173a <generic_usdt_process_event+0xd5a>
    1544:      	leaq	0x10(%r13), %rdx
    1548:      	movl	$0x4, %eax
    154d:      	leaq	0x20(%rsp), %rdi
    1552:      	movl	$0x8, %esi
    1557:      	callq	*%rax
    1559:      	movq	0x68(%rsp), %rax
    155e:      	cmpq	0x20(%rsp), %rax
    1563:      	movl	$0x8, %r15d
    1569:      	je	0x1729 <generic_usdt_process_event+0xd49>
    156f:      	addq	$0x18, %r13
    1573:      	movl	$0x4, %eax
    1578:      	leaq	0x58(%rsp), %rdi
    157d:      	movl	$0x8, %esi
    1582:      	movq	%r13, %rdx
    1585:      	callq	*%rax
    1587:      	movq	0x20(%rsp), %rax
    158c:      	movq	%rax, 0x68(%rsp)
    1591:      	addq	$0x20, %rax
    1595:      	movq	%rax, 0x60(%rsp)
    159a:      	decl	%ebp
    159c:      	jne	0x13f1 <generic_usdt_process_event+0xa11>
    15a2:      	jmp	0x173a <generic_usdt_process_event+0xd5a>
    15a7:      	movq	%rcx, 0xc8(%rsp)
    15af:      	movq	%rsi, 0x90(%rsp)
    15b7:      	leaq	0x80(%rsp), %rdi
    15bf:      	leaq	0x40(%rsp), %rdx
    15c4:      	movl	$0x8, %ecx
    15c9:      	movl	$0x4, %eax
    15ce:      	movl	$0x8, %esi
    15d3:      	callq	*%rax
    15d5:      	movq	0x80(%rsp), %rax
    15dd:      	movq	%rax, 0xb0(%rsp)
    15e5:      	testq	%rax, %rax
    15e8:      	jne	0xff7 <generic_usdt_process_event+0x617>
    15ee:      	movq	%r12, 0x30(%rsp)
    15f3:      	movq	%r13, 0xd8(%rsp)
    15fb:      	movl	$0x0, 0xd0(%rsp)
    1606:      	movq	(%rip), %rdi            # 0x160d <generic_usdt_process_event+0xc2d>
    160d:      	leaq	0xd0(%rsp), %rsi
    1615:      	movl	$0x1, %eax
    161a:      	callq	*%rax
    161c:      	xorl	%edx, %edx
    161e:      	testq	%rax, %rax
    1621:      	je	0x2ecb <generic_usdt_process_event+0x24eb>
    1627:      	cmpl	$0x19, %ebp
    162a:      	jg	0x1a55 <generic_usdt_process_event+0x1075>
    1630:      	cmpl	$0x12, %ebp
    1633:      	jle	0x1bb0 <generic_usdt_process_event+0x11d0>
    1639:      	cmpl	$0x14, %ebp
    163c:      	jle	0x1ef2 <generic_usdt_process_event+0x1512>
    1642:      	cmpl	$0x15, %ebp
    1645:      	je	0x27c7 <generic_usdt_process_event+0x1de7>
    164b:      	cmpl	$0x16, %ebp
    164e:      	je	0x2741 <generic_usdt_process_event+0x1d61>
    1654:      	cmpl	$0x17, %ebp
    1657:      	movq	(%rsp), %rcx
    165b:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1661:      	movq	0x30(%rsp), %rax
    1666:      	movl	$0x0, 0x4(%rax)
    166d:      	movl	%r15d, (%rax)
    1670:      	movl	$0x8, %edx
    1675:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    167a:      	movq	%rcx, 0xc8(%rsp)
    1682:      	movq	%rsi, 0x90(%rsp)
    168a:      	cmpl	$0x2c, %ebp
    168d:      	ja	0x15ee <generic_usdt_process_event+0xc0e>
    1693:      	movl	%ebp, %eax
    1695:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
    169f:      	btq	%rax, %rcx
    16a3:      	jae	0x15ee <generic_usdt_process_event+0xc0e>
    16a9:      	movq	%r13, 0xd8(%rsp)
    16b1:      	movq	%r15, 0x38(%rsp)
    16b6:      	movl	$0x0, 0xd0(%rsp)
    16c1:      	movq	(%rip), %rdi            # 0x16c8 <generic_usdt_process_event+0xce8>
    16c8:      	leaq	0xd0(%rsp), %rsi
    16d0:      	movl	$0x1, %eax
    16d5:      	callq	*%rax
    16d7:      	xorl	%edx, %edx
    16d9:      	testq	%rax, %rax
    16dc:      	je	0x2ecb <generic_usdt_process_event+0x24eb>
    16e2:      	cmpl	$0x10, %ebp
    16e5:      	movq	(%rsp), %rcx
    16e9:      	jle	0x1855 <generic_usdt_process_event+0xe75>
    16ef:      	cmpl	$0x1e, %ebp
    16f2:      	jle	0x19ac <generic_usdt_process_event+0xfcc>
    16f8:      	cmpl	$0x26, %ebp
    16fb:      	jg	0x1a86 <generic_usdt_process_event+0x10a6>
    1701:      	leal	-0x1f(%rbp), %eax
    1704:      	cmpl	$0x2, %eax
    1707:      	jae	0x1fcb <generic_usdt_process_event+0x15eb>
    170d:      	leaq	0x38(%rsp), %rdx
    1712:      	movl	$0x1, %ecx
    1717:      	movl	$0x4, %eax
    171c:      	movq	%r12, %rdi
    171f:      	movl	$0x1, %esi
    1724:      	jmp	0x1c77 <generic_usdt_process_event+0x1297>
    1729:      	movb	$0x1, 0x7c(%rsp)
    172e:      	jmp	0x173a <generic_usdt_process_event+0xd5a>
    1730:      	movb	$0x1, 0x7c(%rsp)
    1735:      	movq	0x8(%rsp), %rbx
    173a:      	movq	0x70(%rsp), %rax
    173f:      	movq	0x18(%rsp), %rdx
    1744:      	cmpq	%rdx, %rax
    1747:      	je	0x178a <generic_usdt_process_event+0xdaa>
    1749:      	xorl	%esi, %esi
    174b:      	cmpb	$0x0, 0x7c(%rsp)
    1750:      	sete	%cl
    1753:      	movl	0x78(%rsp), %edx
    1757:      	movl	$0x1000, %ebp           # imm = 0x1000
    175c:      	subl	%edx, %ebp
    175e:      	testl	%edx, %edx
    1760:      	cmovlel	%edx, %ebp
    1763:      	testq	%rax, %rax
    1766:      	movq	0xc0(%rsp), %r12
    176e:      	movq	0xa8(%rsp), %r13
    1776:      	je	0x184e <generic_usdt_process_event+0xe6e>
    177c:      	movb	%cl, %sil
    177f:      	addl	%esi, %esi
    1781:      	movl	%esi, 0x8(%rsp)
    1785:      	movq	%rax, %rdx
    1788:      	jmp	0x17a4 <generic_usdt_process_event+0xdc4>
    178a:      	movl	$0x0, 0x8(%rsp)
    1792:      	xorl	%ebp, %ebp
    1794:      	movq	0xc0(%rsp), %r12
    179c:      	movq	0xa8(%rsp), %r13
    17a4:      	movq	0x30(%rsp), %r15
    17a9:      	leaq	0x4(%r15), %rdi
    17ad:      	andl	$0xfff, %ebp            # imm = 0xFFF
    17b3:      	movl	$0x4, %eax
    17b8:      	movl	%ebp, %esi
    17ba:      	callq	*%rax
    17bc:      	movl	%ebp, (%r15)
    17bf:      	leaq	0x40(%rsp), %rdi
    17c4:      	movl	$0x8, %ecx
    17c9:      	movl	$0x4, %eax
    17ce:      	movq	0x10(%rsp), %rdx
    17d3:      	movl	$0x8, %esi
    17d8:      	callq	*%rax
    17da:      	movq	0x40(%rsp), %rcx
    17df:      	addq	$0x30, %rcx
    17e3:      	leaq	0x80(%rsp), %rdi
    17eb:      	movl	$0x8, %edx
    17f0:      	movl	$0x4, %eax
    17f5:      	movq	0x40(%rsp), %rdx
    17fa:      	addq	$0x30, %rdx
    17fe:      	movl	$0x8, %esi
    1803:      	callq	*%rax
    1805:      	movq	0x80(%rsp), %rcx
    180d:      	leaq	0x20(%rsp), %rdi
    1812:      	movl	$0x2, %edx
    1817:      	movl	$0x4, %eax
    181c:      	movq	0x80(%rsp), %rdx
    1824:      	movl	$0x2, %esi
    1829:      	callq	*%rax
    182b:      	movq	%rbp, %rdx
    182e:      	movl	0x8(%rsp), %eax
    1832:      	movl	%eax, 0x4(%r15,%rbp)
    1837:      	movzwl	0x20(%rsp), %eax
    183c:      	movw	%ax, 0x8(%r15,%rbp)
    1842:      	addl	$0xa, %edx
    1845:      	movq	(%rsp), %rcx
    1849:      	jmp	0x2edf <generic_usdt_process_event+0x24ff>
    184e:      	xorl	%edx, %edx
    1850:      	jmp	0x2ee3 <generic_usdt_process_event+0x2503>
    1855:      	cmpl	$0x9, %ebp
    1858:      	jg	0x19da <generic_usdt_process_event+0xffa>
    185e:      	cmpl	$0x4, %ebp
    1861:      	jle	0x1c2f <generic_usdt_process_event+0x124f>
    1867:      	cmpl	$0x5, %ebp
    186a:      	je	0x2251 <generic_usdt_process_event+0x1871>
    1870:      	cmpl	$0x6, %ebp
    1873:      	je	0x1a37 <generic_usdt_process_event+0x1057>
    1879:      	cmpl	$0x7, %ebp
    187c:      	movq	(%rsp), %rcx
    1880:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1886:      	movq	%rax, %r13
    1889:      	movq	0x38(%rsp), %r15
    188e:      	movq	%r15, 0x28(%r12)
    1893:      	leaq	0x26(%r12), %rdi
    1898:      	leaq	0x10(%r15), %rdx
    189c:      	movl	$0x2, %ecx
    18a1:      	movl	$0x4, %eax
    18a6:      	movl	$0x2, %esi
    18ab:      	callq	*%rax
    18ad:      	leaq	0x3a(%r12), %rdi
    18b2:      	leaq	0x12(%r15), %rdx
    18b6:      	movl	$0x1, %ecx
    18bb:      	movl	$0x4, %eax
    18c0:      	movl	$0x1, %esi
    18c5:      	callq	*%rax
    18c7:      	leaq	0x38(%r12), %rdi
    18cc:      	leaq	0x226(%r15), %rdx
    18d3:      	movl	$0x2, %ecx
    18d8:      	movl	$0x4, %eax
    18dd:      	movl	$0x2, %esi
    18e2:      	callq	*%rax
    18e4:      	leaq	0x24(%r12), %rdi
    18e9:      	leaq	0x224(%r15), %rdx
    18f0:      	movl	$0x2, %ecx
    18f5:      	movl	$0x4, %eax
    18fa:      	movl	$0x2, %esi
    18ff:      	callq	*%rax
    1901:      	leaq	0x30(%r12), %rdi
    1906:      	leaq	0x21c(%r15), %rdx
    190d:      	movl	$0x4, %ecx
    1912:      	movl	$0x4, %eax
    1917:      	movl	$0x4, %esi
    191c:      	callq	*%rax
    191e:      	leaq	0x34(%r12), %rdi
    1923:      	leaq	0x218(%r15), %rdx
    192a:      	movl	$0x4, %ecx
    192f:      	movl	$0x4, %eax
    1934:      	movl	$0x4, %esi
    1939:      	callq	*%rax
    193b:      	movq	%r12, %rax
    193e:      	addq	$0x10, %r12
    1942:      	movq	$0x0, (%rax)
    1949:      	movq	$0x0, 0x8(%rax)
    1951:      	movq	$0x0, 0x10(%rax)
    1959:      	movq	$0x0, 0x18(%rax)
    1961:      	movq	%rax, %rbp
    1964:      	movzwl	0x26(%rax), %eax
    1968:      	cmpl	$0xa, %eax
    196b:      	je	0x2bd8 <generic_usdt_process_event+0x21f8>
    1971:      	cmpl	$0x2, %eax
    1974:      	jne	0x2c08 <generic_usdt_process_event+0x2228>
    197a:      	leaq	0x4(%r15), %rdx
    197e:      	movl	$0x4, %ecx
    1983:      	movl	$0x4, %eax
    1988:      	movq	%rbp, %rdi
    198b:      	movl	$0x4, %esi
    1990:      	callq	*%rax
    1992:      	movl	$0x4, %ecx
    1997:      	movl	$0x4, %eax
    199c:      	movq	%r12, %rdi
    199f:      	movl	$0x4, %esi
    19a4:      	movq	%r15, %rdx
    19a7:      	jmp	0x2c06 <generic_usdt_process_event+0x2226>
    19ac:      	cmpl	$0x1c, %ebp
    19af:      	jg	0x1c16 <generic_usdt_process_event+0x1236>
    19b5:      	cmpl	$0x11, %ebp
    19b8:      	je	0x1ff9 <generic_usdt_process_event+0x1619>
    19be:      	movq	%rax, 0x10(%rsp)
    19c3:      	cmpl	$0x19, %ebp
    19c6:      	je	0x20be <generic_usdt_process_event+0x16de>
    19cc:      	cmpl	$0x1c, %ebp
    19cf:      	je	0x1c3d <generic_usdt_process_event+0x125d>
    19d5:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    19da:      	leal	-0xa(%rbp), %eax
    19dd:      	cmpl	$0x2, %eax
    19e0:      	jb	0x1c3d <generic_usdt_process_event+0x125d>
    19e6:      	leal	-0xc(%rbp), %eax
    19e9:      	cmpl	$0x2, %eax
    19ec:      	jb	0x1c60 <generic_usdt_process_event+0x1280>
    19f2:      	cmpl	$0xe, %ebp
    19f5:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    19fb:      	leaq	0x40(%rsp), %rdi
    1a00:      	leaq	0x38(%rsp), %r15
    1a05:      	movl	$0x8, %ecx
    1a0a:      	movl	$0x4, %eax
    1a0f:      	movl	$0x8, %esi
    1a14:      	movq	%r15, %rdx
    1a17:      	callq	*%rax
    1a19:      	movq	0x40(%rsp), %rcx
    1a1e:      	movl	$0x8, %edx
    1a23:      	movl	$0x4, %eax
    1a28:      	movq	0x40(%rsp), %rdx
    1a2d:      	movq	%r15, %rdi
    1a30:      	movl	$0x8, %esi
    1a35:      	callq	*%rax
    1a37:      	movq	0x38(%rsp), %rdx
    1a3c:      	leaq	0x4(%r12), %rdi
    1a41:      	movl	$0x1001, %ecx           # imm = 0x1001
    1a46:      	movl	$0x2d, %eax
    1a4b:      	movl	$0x1001, %esi           # imm = 0x1001
    1a50:      	jmp	0x2432 <generic_usdt_process_event+0x1a52>
    1a55:      	cmpl	$0x20, %ebp
    1a58:      	movq	0x30(%rsp), %rdi
    1a5d:      	jle	0x1de5 <generic_usdt_process_event+0x1405>
    1a63:      	leal	-0x21(%rbp), %ecx
    1a66:      	cmpl	$0x4, %ecx
    1a69:      	jae	0x1c83 <generic_usdt_process_event+0x12a3>
    1a6f:      	movl	$0x8, %ecx
    1a74:      	movl	$0x4, %eax
    1a79:      	movl	$0x8, %esi
    1a7e:      	movq	%r15, %rdx
    1a81:      	jmp	0x1c54 <generic_usdt_process_event+0x1274>
    1a86:      	cmpl	$0x27, %ebp
    1a89:      	je	0x2414 <generic_usdt_process_event+0x1a34>
    1a8f:      	cmpl	$0x28, %ebp
    1a92:      	je	0x2450 <generic_usdt_process_event+0x1a70>
    1a98:      	cmpl	$0x2c, %ebp
    1a9b:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1aa1:      	movq	0x38(%rsp), %r15
    1aa6:      	movb	$0x0, 0x40(%rsp)
    1aab:      	movq	$0x0, 0x68(%r12)
    1ab4:      	movq	$0x0, 0x60(%r12)
    1abd:      	movq	$0x0, 0x58(%r12)
    1ac6:      	movq	$0x0, 0x50(%r12)
    1acf:      	movq	$0x0, 0x48(%r12)
    1ad8:      	movq	$0x0, 0x40(%r12)
    1ae1:      	movq	$0x0, 0x38(%r12)
    1aea:      	movq	$0x0, 0x30(%r12)
    1af3:      	movq	$0x0, 0x28(%r12)
    1afc:      	movq	$0x0, 0x20(%r12)
    1b05:      	movq	$0x0, 0x18(%r12)
    1b0e:      	movq	$0x0, 0x10(%r12)
    1b17:      	movq	$0x0, 0x8(%r12)
    1b20:      	movq	$0x0, (%r12)
    1b28:      	movl	$0x2, %ecx
    1b2d:      	movl	$0x4, %eax
    1b32:      	movq	%r12, %r13
    1b35:      	movq	%r12, %rdi
    1b38:      	movl	$0x2, %esi
    1b3d:      	movq	%r15, %rdx
    1b40:      	callq	*%rax
    1b42:      	testq	%rax, %rax
    1b45:      	js	0x2ec6 <generic_usdt_process_event+0x24e6>
    1b4b:      	leaq	0x2(%r15), %r12
    1b4f:      	leaq	0x40(%rsp), %rdi
    1b54:      	movl	$0x1, %ecx
    1b59:      	movl	$0x4, %eax
    1b5e:      	movl	$0x1, %esi
    1b63:      	movq	%r12, %rdx
    1b66:      	callq	*%rax
    1b68:      	testq	%rax, %rax
    1b6b:      	js	0x2ec6 <generic_usdt_process_event+0x24e6>
    1b71:      	movq	%r13, %rax
    1b74:      	leaq	0x4(%r13), %rdi
    1b78:      	cmpb	$0x0, 0x40(%rsp)
    1b7d:      	sete	0x2(%r13)
    1b82:      	je	0x2e9c <generic_usdt_process_event+0x24bc>
    1b88:      	movl	$0x6c, %ecx
    1b8d:      	movl	$0x2d, %eax
    1b92:      	movl	$0x6c, %esi
    1b97:      	movq	%r12, %rdx
    1b9a:      	callq	*%rax
    1b9c:      	testl	%eax, %eax
    1b9e:      	movq	0x8(%rsp), %rbx
    1ba3:      	js	0x2ec6 <generic_usdt_process_event+0x24e6>
    1ba9:      	decb	%al
    1bab:      	jmp	0x2ec2 <generic_usdt_process_event+0x24e2>
    1bb0:      	cmpl	$0x7, %ebp
    1bb3:      	jg	0x1ea8 <generic_usdt_process_event+0x14c8>
    1bb9:      	cmpl	$0x2, %ebp
    1bbc:      	je	0x24e2 <generic_usdt_process_event+0x1b02>
    1bc2:      	cmpl	$0x3, %ebp
    1bc5:      	movq	(%rsp), %rcx
    1bc9:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1bcf:      	movq	%rax, %r13
    1bd2:      	leaq	0x90(%rax), %r15
    1bd9:      	movq	0xc8(%rsp), %rax
    1be1:      	andl	$0xf, %eax
    1be4:      	cmpl	$0x2, %eax
    1be7:      	jle	0x2d61 <generic_usdt_process_event+0x2381>
    1bed:      	cmpl	$0x3, %eax
    1bf0:      	je	0x3034 <generic_usdt_process_event+0x2654>
    1bf6:      	cmpl	$0x4, %eax
    1bf9:      	je	0x303f <generic_usdt_process_event+0x265f>
    1bff:      	cmpl	$0x5, %eax
    1c02:      	jne	0x3420 <generic_usdt_process_event+0x2a40>
    1c08:      	movq	%r13, %rax
    1c0b:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1c11:      	jmp	0x3053 <generic_usdt_process_event+0x2673>
    1c16:      	leaq	0x38(%rsp), %rdx
    1c1b:      	movl	$0x2, %ecx
    1c20:      	movl	$0x4, %eax
    1c25:      	movq	%r12, %rdi
    1c28:      	movl	$0x2, %esi
    1c2d:      	jmp	0x1c77 <generic_usdt_process_event+0x1297>
    1c2f:      	cmpl	$0x1, %ebp
    1c32:      	je	0x1c60 <generic_usdt_process_event+0x1280>
    1c34:      	cmpl	$0x4, %ebp
    1c37:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1c3d:      	leaq	0x38(%rsp), %rdx
    1c42:      	movl	$0x8, %ecx
    1c47:      	movl	$0x4, %eax
    1c4c:      	movq	%r12, %rdi
    1c4f:      	movl	$0x8, %esi
    1c54:      	callq	*%rax
    1c56:      	movl	$0x8, %edx
    1c5b:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    1c60:      	leaq	0x38(%rsp), %rdx
    1c65:      	movl	$0x4, %ecx
    1c6a:      	movl	$0x4, %eax
    1c6f:      	movq	%r12, %rdi
    1c72:      	movl	$0x4, %esi
    1c77:      	callq	*%rax
    1c79:      	movl	$0x4, %edx
    1c7e:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    1c83:      	cmpl	$0x2b, %ebp
    1c86:      	je	0x28b3 <generic_usdt_process_event+0x1ed3>
    1c8c:      	cmpl	$0x29, %ebp
    1c8f:      	movq	(%rsp), %rcx
    1c93:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1c99:      	movq	%rax, %r13
    1c9c:      	addq	$0x18, %r15
    1ca0:      	leaq	0x40(%rsp), %rdi
    1ca5:      	movl	$0x4, %ebp
    1caa:      	movl	$0x8, %ecx
    1caf:      	movl	$0x4, %eax
    1cb4:      	movl	$0x8, %esi
    1cb9:      	movq	%r15, %rdx
    1cbc:      	callq	*%rax
    1cbe:      	movq	0x40(%rsp), %r15
    1cc3:      	testq	%r15, %r15
    1cc6:      	je	0x2ff0 <generic_usdt_process_event+0x2610>
    1ccc:      	movq	0x30(%rsp), %r12
    1cd1:      	movq	%r15, 0x28(%r12)
    1cd6:      	leaq	0x26(%r12), %rdi
    1cdb:      	leaq	0x10(%r15), %rdx
    1cdf:      	movl	$0x2, %ecx
    1ce4:      	movl	$0x4, %eax
    1ce9:      	movl	$0x2, %esi
    1cee:      	callq	*%rax
    1cf0:      	leaq	0x3a(%r12), %rdi
    1cf5:      	leaq	0x12(%r15), %rdx
    1cf9:      	movl	$0x1, %ecx
    1cfe:      	movl	$0x4, %eax
    1d03:      	movl	$0x1, %esi
    1d08:      	callq	*%rax
    1d0a:      	leaq	0x38(%r12), %rdi
    1d0f:      	leaq	0x226(%r15), %rdx
    1d16:      	movl	$0x2, %ecx
    1d1b:      	movl	$0x4, %eax
    1d20:      	movl	$0x2, %esi
    1d25:      	callq	*%rax
    1d27:      	leaq	0x24(%r12), %rdi
    1d2c:      	leaq	0x224(%r15), %rdx
    1d33:      	movl	$0x2, %ecx
    1d38:      	movl	$0x4, %eax
    1d3d:      	movl	$0x2, %esi
    1d42:      	callq	*%rax
    1d44:      	leaq	0x30(%r12), %rdi
    1d49:      	leaq	0x21c(%r15), %rdx
    1d50:      	movl	$0x4, %eax
    1d55:      	movl	$0x4, %esi
    1d5a:      	callq	*%rax
    1d5c:      	leaq	0x34(%r12), %rdi
    1d61:      	leaq	0x218(%r15), %rdx
    1d68:      	movl	$0x4, %eax
    1d6d:      	movl	$0x4, %esi
    1d72:      	callq	*%rax
    1d74:      	movq	%r12, %rax
    1d77:      	addq	$0x10, %r12
    1d7b:      	movq	$0x0, (%rax)
    1d82:      	movq	$0x0, 0x8(%rax)
    1d8a:      	movq	$0x0, 0x10(%rax)
    1d92:      	movq	$0x0, 0x18(%rax)
    1d9a:      	movq	%rax, %rbp
    1d9d:      	movzwl	0x26(%rax), %eax
    1da1:      	cmpl	$0xa, %eax
    1da4:      	je	0x2f7e <generic_usdt_process_event+0x259e>
    1daa:      	cmpl	$0x2, %eax
    1dad:      	jne	0x2fae <generic_usdt_process_event+0x25ce>
    1db3:      	leaq	0x4(%r15), %rdx
    1db7:      	movl	$0x4, %ecx
    1dbc:      	movl	$0x4, %eax
    1dc1:      	movq	%rbp, %rdi
    1dc4:      	movl	$0x4, %esi
    1dc9:      	callq	*%rax
    1dcb:      	movl	$0x4, %ecx
    1dd0:      	movl	$0x4, %eax
    1dd5:      	movq	%r12, %rdi
    1dd8:      	movl	$0x4, %esi
    1ddd:      	movq	%r15, %rdx
    1de0:      	jmp	0x2fac <generic_usdt_process_event+0x25cc>
    1de5:      	cmpl	$0x1a, %ebp
    1de8:      	je	0x294e <generic_usdt_process_event+0x1f6e>
    1dee:      	cmpl	$0x1b, %ebp
    1df1:      	movq	(%rsp), %rcx
    1df5:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1dfb:      	movq	0x30(%rsp), %rax
    1e00:      	movq	%rcx, %r13
    1e03:      	movq	$0x0, 0x48(%rax)
    1e0b:      	movq	$0x0, 0x40(%rax)
    1e13:      	movq	$0x0, 0x38(%rax)
    1e1b:      	movq	$0x0, 0x30(%rax)
    1e23:      	movq	$0x0, 0x28(%rax)
    1e2b:      	movq	$0x0, 0x20(%rax)
    1e33:      	movq	$0x0, 0x18(%rax)
    1e3b:      	movq	$0x0, 0x10(%rax)
    1e43:      	movq	$0x0, 0x8(%rax)
    1e4b:      	movq	$0x0, (%rax)
    1e52:      	movq	%r15, %rcx
    1e55:      	movq	%rax, %r15
    1e58:      	leaq	0x10(%rax), %rdi
    1e5c:      	leaq	0x18(%rcx), %rdx
    1e60:      	movl	$0x3f, %ecx
    1e65:      	movl	$0x2d, %eax
    1e6a:      	movl	$0x3f, %esi
    1e6f:      	callq	*%rax
    1e71:      	testq	%rax, %rax
    1e74:      	js	0x2e90 <generic_usdt_process_event+0x24b0>
    1e7a:      	movq	%r15, %rdi
    1e7d:      	addq	$0x8, %rdi
    1e81:      	movq	0x10(%rsp), %rdx
    1e86:      	addq	$0x348, %rdx            # imm = 0x348
    1e8d:      	movl	$0x8, %ecx
    1e92:      	movl	$0x4, %eax
    1e97:      	movl	$0x8, %esi
    1e9c:      	callq	*%rax
    1e9e:      	movl	$0x50, %edx
    1ea3:      	jmp	0x2e92 <generic_usdt_process_event+0x24b2>
    1ea8:      	cmpl	$0x8, %ebp
    1eab:      	je	0x254b <generic_usdt_process_event+0x1b6b>
    1eb1:      	cmpl	$0x12, %ebp
    1eb4:      	movq	(%rsp), %rcx
    1eb8:      	movq	0x10(%rsp), %r12
    1ebd:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1ec3:      	movq	0xc8(%rsp), %r13
    1ecb:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    1ed2:      	movq	%r12, %rdx
    1ed5:      	movq	%rcx, %r15
    1ed8:      	movl	$0x4, %eax
    1edd:      	movq	0x30(%rsp), %rdi
    1ee2:      	movl	%r13d, %esi
    1ee5:      	callq	*%rax
    1ee7:      	movq	%r15, %rcx
    1eea:      	movq	%r13, %rdx
    1eed:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    1ef2:      	cmpl	$0x13, %ebp
    1ef5:      	je	0x285b <generic_usdt_process_event+0x1e7b>
    1efb:      	cmpl	$0x14, %ebp
    1efe:      	movq	(%rsp), %rcx
    1f02:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1f08:      	movq	$0x0, 0x40(%rsp)
    1f11:      	leaq	0x110(%r15), %rdx
    1f18:      	leaq	0x40(%rsp), %rdi
    1f1d:      	movl	$0x8, %esi
    1f22:      	movq	%rcx, %r13
    1f25:      	movl	$0x4, %eax
    1f2a:      	movq	%r15, %r12
    1f2d:      	addq	$0xd8, %r15
    1f34:      	movl	$0x8, %esi
    1f39:      	callq	*%rax
    1f3b:      	movq	0x40(%rsp), %rcx
    1f40:      	movl	$0x80, %edx
    1f45:      	movl	$0x2d, %eax
    1f4a:      	movq	0x30(%rsp), %rbp
    1f4f:      	movq	0x40(%rsp), %rdx
    1f54:      	movq	%rbp, %rdi
    1f57:      	movl	$0x80, %esi
    1f5c:      	callq	*%rax
    1f5e:      	leaq	0x90(%rbp), %rdi
    1f65:      	movl	$0x4, %ecx
    1f6a:      	movl	$0x4, %eax
    1f6f:      	movl	$0x4, %esi
    1f74:      	movq	%r15, %rdx
    1f77:      	callq	*%rax
    1f79:      	leaq	0x80(%rbp), %rdi
    1f80:      	leaq	0xe0(%r12), %rdx
    1f88:      	movl	$0x8, %ecx
    1f8d:      	movl	$0x4, %eax
    1f92:      	movl	$0x8, %esi
    1f97:      	callq	*%rax
    1f99:      	addq	$0x88, %rbp
    1fa0:      	addq	$0x118, %r12            # imm = 0x118
    1fa7:      	movl	$0x8, %ecx
    1fac:      	movl	$0x4, %eax
    1fb1:      	movq	%rbp, %rdi
    1fb4:      	movl	$0x8, %esi
    1fb9:      	movq	%r12, %rdx
    1fbc:      	callq	*%rax
    1fbe:      	movq	%r13, %rcx
    1fc1:      	movl	$0x98, %edx
    1fc6:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    1fcb:      	cmpl	$0x26, %ebp
    1fce:      	jne	0x2ecf <generic_usdt_process_event+0x24ef>
    1fd4:      	movq	0x38(%rsp), %rsi
    1fd9:      	movzwl	%si, %edx
    1fdc:      	addq	%rbx, %rdx
    1fdf:      	shrl	$0x10, %esi
    1fe2:      	andl	$0xfff, %esi            # imm = 0xFFF
    1fe8:      	leaq	0x4(%r12), %rdi
    1fed:      	incl	%esi
    1fef:      	movl	$0x2d, %eax
    1ff4:      	jmp	0x2432 <generic_usdt_process_event+0x1a52>
    1ff9:      	movq	%r12, %rbp
    1ffc:      	movq	$0x0, 0x48(%rsp)
    2005:      	movl	$0xe, %eax
    200a:      	callq	*%rax
    200c:      	shrq	$0x20, %rax
    2010:      	movq	%rax, 0x40(%rsp)
    2015:      	leaq	0x80(%rsp), %rdi
    201d:      	leaq	0x38(%rsp), %rdx
    2022:      	movl	$0x4, %ecx
    2027:      	movl	$0x4, %eax
    202c:      	movl	$0x4, %r13d
    2032:      	movl	$0x4, %esi
    2037:      	callq	*%rax
    2039:      	movl	0x80(%rsp), %eax
    2040:      	movl	%eax, 0x48(%rsp)
    2044:      	movq	(%rip), %rdi            # 0x204b <generic_usdt_process_event+0x166b>
    204b:      	leaq	0x40(%rsp), %rsi
    2050:      	movl	$0x1, %eax
    2055:      	callq	*%rax
    2057:      	testq	%rax, %rax
    205a:      	je	0x29c9 <generic_usdt_process_event+0x1fe9>
    2060:      	movl	(%rax), %r15d
    2063:      	leaq	0x80(%rsp), %rdx
    206b:      	movq	%rax, %r12
    206e:      	movl	$0x4, %eax
    2073:      	movq	%rbp, %rdi
    2076:      	movl	$0x4, %esi
    207b:      	callq	*%rax
    207d:      	andl	$0xfff, %r15d           # imm = 0xFFF
    2084:      	leaq	0x4(%rbp), %rdi
    2088:      	leaq	0x4(%r15), %rsi
    208c:      	movl	$0x4, %eax
    2091:      	movq	%r12, %rdx
    2094:      	callq	*%rax
    2096:      	leaq	(%r15,%rbp), %rdi
    209a:      	addq	$0x8, %rdi
    209e:      	leaq	(%r15,%r12), %rdx
    20a2:      	addq	$0x4, %rdx
    20a6:      	movl	$0x4, %eax
    20ab:      	movl	$0x4, %esi
    20b0:      	callq	*%rax
    20b2:      	movq	%r15, %rdx
    20b5:      	addq	$0xc, %rdx
    20b9:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    20be:      	movq	0x38(%rsp), %r12
    20c3:      	leaq	0x98(%rsp), %rdi
    20cb:      	movl	$0x1, %ecx
    20d0:      	movl	$0x4, %eax
    20d5:      	movl	$0x1, %esi
    20da:      	movq	%r12, %rdx
    20dd:      	callq	*%rax
    20df:      	movzbl	0x98(%rsp), %eax
    20e7:      	testl	%eax, %eax
    20e9:      	je	0x29d5 <generic_usdt_process_event+0x1ff5>
    20ef:      	cmpl	$0x1, %eax
    20f2:      	jne	0x2c75 <generic_usdt_process_event+0x2295>
    20f8:      	addq	$0x10, %r12
    20fc:      	leaq	0x80(%rsp), %rdi
    2104:      	movl	$0x8, %r15d
    210a:      	movl	$0x8, %ecx
    210f:      	movl	$0x4, %eax
    2114:      	movl	$0x8, %esi
    2119:      	movq	%r12, %rdx
    211c:      	callq	*%rax
    211e:      	movq	0x80(%rsp), %rdx
    2126:      	leaq	0x20(%rsp), %rdi
    212b:      	movl	$0x8, %ecx
    2130:      	movl	$0x4, %eax
    2135:      	movl	$0x8, %esi
    213a:      	callq	*%rax
    213c:      	movq	0x80(%rsp), %rdx
    2144:      	addq	$0x8, %rdx
    2148:      	leaq	0xa0(%rsp), %rdi
    2150:      	movl	$0x8, %ecx
    2155:      	movl	$0x4, %eax
    215a:      	movl	$0x8, %esi
    215f:      	callq	*%rax
    2161:      	movq	0x20(%rsp), %rax
    2166:      	movq	%rax, 0xb0(%rsp)
    216e:      	movq	0xa0(%rsp), %rbx
    2176:      	movq	0x10(%rsp), %rax
    217b:      	movq	0x90(%rsp), %rcx
    2183:      	leaq	(%rax,%rcx), %r12
    2187:      	addq	$0x90, %r12
    218e:      	testb	$0x20, 0x18(%rsp)
    2193:      	je	0x354a <generic_usdt_process_event+0x2b6a>
    2199:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    21a0:      	jb	0x351b <generic_usdt_process_event+0x2b3b>
    21a6:      	movl	$0x1, (%r12)
    21ae:      	movl	$0x0, 0xb8(%rsp)
    21b9:      	movq	(%rip), %rdi            # 0x21c0 <generic_usdt_process_event+0x17e0>
    21c0:      	leaq	0xb8(%rsp), %rsi
    21c8:      	movl	$0x1, %eax
    21cd:      	callq	*%rax
    21cf:      	testq	%rax, %rax
    21d2:      	je	0x37f6 <generic_usdt_process_event+0x2e16>
    21d8:      	movq	%rax, %r13
    21db:      	movl	$0x18, (%rax)
    21e1:      	movl	$0xe, %eax
    21e6:      	callq	*%rax
    21e8:      	movq	%r13, %r15
    21eb:      	addq	$0x10, %r15
    21ef:      	movq	%rax, 0x10(%r13)
    21f3:      	cmpq	$-0x16, %rax
    21f7:      	jne	0x2220 <generic_usdt_process_event+0x1840>
    21f9:      	movq	0x8(%rsp), %rax
    21fe:      	leaq	0x20(%rax), %rdx
    2202:      	leaq	0x40(%rsp), %rdi
    2207:      	movl	$0x8, %ecx
    220c:      	movl	$0x4, %eax
    2211:      	movl	$0x8, %esi
    2216:      	callq	*%rax
    2218:      	movq	0x40(%rsp), %rax
    221d:      	movq	%rax, (%r15)
    2220:      	movl	$0x7d, %eax
    2225:      	callq	*%rax
    2227:      	movq	%rax, 0x18(%r13)
    222b:      	movq	(%r15), %rax
    222e:      	movq	0x8(%r15), %rcx
    2232:      	movq	%rax, 0x14(%r12)
    2237:      	movq	%rcx, 0x1c(%r12)
    223c:      	movq	0x8(%rsp), %rdi
    2241:      	movq	%r13, %rsi
    2244:      	movq	0xb0(%rsp), %rdx
    224c:      	jmp	0x2b00 <generic_usdt_process_event+0x2120>
    2251:      	movq	%r12, %r15
    2254:      	movq	0x38(%rsp), %r12
    2259:      	leaq	0x28(%r15), %rdi
    225d:      	leaq	0x98(%r12), %rdx
    2265:      	movl	$0x4, %ecx
    226a:      	movl	$0x4, %eax
    226f:      	movl	$0x4, %esi
    2274:      	callq	*%rax
    2276:      	leaq	0x2c(%r15), %rdi
    227a:      	leaq	0x70(%r12), %rdx
    227f:      	movl	$0x4, %ecx
    2284:      	movl	$0x4, %eax
    2289:      	movl	$0x4, %esi
    228e:      	callq	*%rax
    2290:      	leaq	0x30(%r15), %rdi
    2294:      	leaq	0x90(%r12), %rdx
    229c:      	movl	$0x4, %ecx
    22a1:      	movl	$0x4, %eax
    22a6:      	movl	$0x4, %esi
    22ab:      	callq	*%rax
    22ad:      	movq	%r15, 0x30(%rsp)
    22b2:      	leaq	0x34(%r15), %rdi
    22b6:      	leaq	0xa8(%r12), %rdx
    22be:      	movl	$0x4, %ecx
    22c3:      	movl	$0x4, %eax
    22c8:      	movl	$0x4, %esi
    22cd:      	callq	*%rax
    22cf:      	movq	$0x0, 0x40(%rsp)
    22d8:      	leaq	0xc8(%r12), %rdx
    22e0:      	leaq	0x40(%rsp), %rdi
    22e5:      	movl	$0x8, %ecx
    22ea:      	movl	$0x4, %eax
    22ef:      	movl	$0x8, %esi
    22f4:      	callq	*%rax
    22f6:      	leaq	0xb8(%r12), %rdx
    22fe:      	leaq	0xa0(%rsp), %rdi
    2306:      	movl	$0x2, %ecx
    230b:      	movl	$0x4, %eax
    2310:      	movl	$0x2, %esi
    2315:      	callq	*%rax
    2317:      	movzwl	0xa0(%rsp), %r15d
    2320:      	addq	0x40(%rsp), %r15
    2325:      	leaq	0x9f(%rsp), %rdi
    232d:      	movl	$0x1, %ecx
    2332:      	movl	$0x4, %eax
    2337:      	movl	$0x1, %esi
    233c:      	movq	%r15, %rdx
    233f:      	callq	*%rax
    2341:      	movzbl	0x9f(%rsp), %eax
    2349:      	shrl	$0x4, %eax
    234c:      	cmpl	$0x6, %eax
    234f:      	je	0x2b28 <generic_usdt_process_event+0x2148>
    2355:      	cmpl	$0x4, %eax
    2358:      	jne	0x3f6b <generic_usdt_process_event+0x358b>
    235e:      	leaq	0x9(%r15), %rdx
    2362:      	leaq	0x98(%rsp), %rdi
    236a:      	movl	$0x1, %ecx
    236f:      	movl	$0x4, %eax
    2374:      	movl	$0x1, %esi
    2379:      	callq	*%rax
    237b:      	movzbl	0x98(%rsp), %eax
    2383:      	movq	0x30(%rsp), %rdi
    2388:      	movw	%ax, 0x24(%rdi)
    238c:      	movw	$0x2, 0x26(%rdi)
    2392:      	leaq	0xc(%r15), %rdx
    2396:      	movq	$0x0, (%rdi)
    239d:      	movq	$0x0, 0x8(%rdi)
    23a5:      	movq	$0x0, 0x10(%rdi)
    23ad:      	movq	$0x0, 0x18(%rdi)
    23b5:      	movl	$0x4, %ecx
    23ba:      	movl	$0x4, %eax
    23bf:      	leaq	0x10(%rdi), %r13
    23c3:      	movl	$0x4, %esi
    23c8:      	callq	*%rax
    23ca:      	addq	$0x10, %r15
    23ce:      	movl	$0x4, %ecx
    23d3:      	movl	$0x4, %eax
    23d8:      	movq	%r13, %rdi
    23db:      	movl	$0x4, %esi
    23e0:      	movq	%r15, %rdx
    23e3:      	callq	*%rax
    23e5:      	leaq	0xb6(%r12), %rdx
    23ed:      	leaq	0xb8(%rsp), %rdi
    23f5:      	movl	$0x2, %ecx
    23fa:      	movl	$0x4, %eax
    23ff:      	movl	$0x2, %esi
    2404:      	callq	*%rax
    2406:      	movzbl	0x98(%rsp), %r15d
    240f:      	jmp	0x3e03 <generic_usdt_process_event+0x3423>
    2414:      	movl	$0x120, %edx            # imm = 0x120
    2419:      	addq	0x38(%rsp), %rdx
    241e:      	leaq	0x4(%r12), %rdi
    2423:      	movl	$0x11, %ecx
    2428:      	movl	$0x2d, %eax
    242d:      	movl	$0x11, %esi
    2432:      	callq	*%rax
    2434:      	movq	%rax, %rdx
    2437:      	testq	%rax, %rax
    243a:      	js	0x2ecb <generic_usdt_process_event+0x24eb>
    2440:      	leal	-0x1(%rdx), %eax
    2443:      	movl	%eax, (%r12)
    2447:      	addq	$0x3, %rdx
    244b:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    2450:      	movq	0x38(%rsp), %r15
    2455:      	movq	$0x0, 0x10(%r12)
    245e:      	movq	$0x0, 0x8(%r12)
    2467:      	movq	$0x0, (%r12)
    246f:      	movl	$0x2, %ecx
    2474:      	movl	$0x4, %eax
    2479:      	movq	%r12, %rdi
    247c:      	movl	$0x2, %esi
    2481:      	movq	%r15, %rdx
    2484:      	callq	*%rax
    2486:      	testq	%rax, %rax
    2489:      	js	0x2dca <generic_usdt_process_event+0x23ea>
    248f:      	movq	%r12, %r13
    2492:      	movzwl	(%r12), %eax
    2497:      	cmpl	$0xa, %eax
    249a:      	je	0x2d81 <generic_usdt_process_event+0x23a1>
    24a0:      	cmpl	$0x2, %eax
    24a3:      	jne	0x2db9 <generic_usdt_process_event+0x23d9>
    24a9:      	leaq	0x4(%r15), %rdx
    24ad:      	leaq	0x40(%rsp), %rdi
    24b2:      	movl	$0x4, %ecx
    24b7:      	movl	$0x4, %eax
    24bc:      	movl	$0x4, %esi
    24c1:      	callq	*%rax
    24c3:      	movl	0x40(%rsp), %eax
    24c7:      	movq	%rax, 0x8(%r13)
    24cb:      	leaq	0x2(%r13), %rdi
    24cf:      	addq	$0x2, %r15
    24d3:      	movl	$0x2, %ecx
    24d8:      	movl	$0x4, %eax
    24dd:      	jmp	0x2daf <generic_usdt_process_event+0x23cf>
    24e2:      	movq	%rax, %rbp
    24e5:      	movq	0x90(%rsp), %rcx
    24ed:      	leaq	(%rax,%rcx), %r12
    24f1:      	addq	$0x90, %r12
    24f8:      	movq	$0x0, 0x38(%rsp)
    2501:      	testb	$0x10, 0x18(%rsp)
    2506:      	jne	0x2c98 <generic_usdt_process_event+0x22b8>
    250c:      	movq	0x18(%rsp), %rdx
    2511:      	movl	%edx, %ebx
    2513:      	andl	$0xf, %edx
    2516:      	xorl	%eax, %eax
    2518:      	movq	%rdx, %rcx
    251b:      	cmpl	$0x2, %edx
    251e:      	jle	0x2f60 <generic_usdt_process_event+0x2580>
    2524:      	cmpl	$0x3, %ecx
    2527:      	je	0x36c2 <generic_usdt_process_event+0x2ce2>
    252d:      	cmpl	$0x4, %ecx
    2530:      	je	0x36cb <generic_usdt_process_event+0x2ceb>
    2536:      	cmpl	$0x5, %ecx
    2539:      	jne	0x36de <generic_usdt_process_event+0x2cfe>
    253f:      	leaq	0x5e70(%rbp), %rax
    2546:      	jmp	0x36db <generic_usdt_process_event+0x2cfb>
    254b:      	movq	0x30(%rsp), %rbp
    2550:      	leaq	0x28(%rbp), %r13
    2554:      	leaq	0x40(%rbp), %r15
    2558:      	movq	0x10(%rsp), %r12
    255d:      	leaq	0x8(%r12), %rdx
    2562:      	movl	$0x4, %ecx
    2567:      	movl	$0x4, %eax
    256c:      	movq	%rbp, %rdi
    256f:      	movl	$0x4, %esi
    2574:      	callq	*%rax
    2576:      	leaq	0x4(%rbp), %rdi
    257a:      	leaq	0xc(%r12), %rdx
    257f:      	movl	$0x4, %ecx
    2584:      	movl	$0x4, %eax
    2589:      	movl	$0x4, %esi
    258e:      	callq	*%rax
    2590:      	leaq	0x10(%rbp), %rdi
    2594:      	leaq	0x18(%r12), %rdx
    2599:      	movl	$0x4, %ecx
    259e:      	movl	$0x4, %eax
    25a3:      	movl	$0x4, %esi
    25a8:      	callq	*%rax
    25aa:      	leaq	0x14(%rbp), %rdi
    25ae:      	leaq	0x1c(%r12), %rdx
    25b3:      	movl	$0x4, %ecx
    25b8:      	movl	$0x4, %eax
    25bd:      	movl	$0x4, %esi
    25c2:      	callq	*%rax
    25c4:      	leaq	0x8(%rbp), %rdi
    25c8:      	leaq	0x10(%r12), %rdx
    25cd:      	movl	$0x4, %ecx
    25d2:      	movl	$0x4, %eax
    25d7:      	movl	$0x4, %esi
    25dc:      	callq	*%rax
    25de:      	leaq	0xc(%rbp), %rdi
    25e2:      	leaq	0x14(%r12), %rdx
    25e7:      	movl	$0x4, %ecx
    25ec:      	movl	$0x4, %eax
    25f1:      	movl	$0x4, %esi
    25f6:      	callq	*%rax
    25f8:      	leaq	0x18(%rbp), %rdi
    25fc:      	leaq	0x20(%r12), %rdx
    2601:      	movl	$0x4, %ecx
    2606:      	movl	$0x4, %eax
    260b:      	movl	$0x4, %esi
    2610:      	callq	*%rax
    2612:      	leaq	0x1c(%rbp), %rdi
    2616:      	leaq	0x24(%r12), %rdx
    261b:      	movl	$0x4, %ecx
    2620:      	movl	$0x4, %eax
    2625:      	movl	$0x4, %esi
    262a:      	callq	*%rax
    262c:      	movl	$0x0, 0x24(%rbp)
    2633:      	leaq	0x20(%rbp), %rdi
    2637:      	leaq	0x28(%r12), %rdx
    263c:      	movl	$0x4, %ecx
    2641:      	movl	$0x4, %eax
    2646:      	movl	$0x4, %esi
    264b:      	callq	*%rax
    264d:      	leaq	0x30(%rbp), %rdi
    2651:      	leaq	0x40(%r12), %rdx
    2656:      	movl	$0x8, %ecx
    265b:      	movl	$0x4, %eax
    2660:      	movl	$0x8, %esi
    2665:      	callq	*%rax
    2667:      	leaq	0x38(%rbp), %rdi
    266b:      	leaq	0x30(%r12), %rdx
    2670:      	movl	$0x8, %ecx
    2675:      	movl	$0x4, %eax
    267a:      	movl	$0x8, %esi
    267f:      	callq	*%rax
    2681:      	leaq	0x38(%r12), %rdx
    2686:      	movl	$0x8, %ecx
    268b:      	movl	$0x4, %eax
    2690:      	movq	%r13, %rdi
    2693:      	movl	$0x8, %esi
    2698:      	callq	*%rax
    269a:      	addq	$0x90, %r12
    26a1:      	leaq	0x40(%rsp), %rdi
    26a6:      	movl	$0x8, %ecx
    26ab:      	movl	$0x4, %eax
    26b0:      	movl	$0x8, %esi
    26b5:      	movq	%r12, %rdx
    26b8:      	callq	*%rax
    26ba:      	movq	0x40(%rsp), %r12
    26bf:      	leaq	0xc8(%r12), %rdx
    26c7:      	movl	$0x4, %ecx
    26cc:      	movl	$0x4, %eax
    26d1:      	movq	%r15, %rdi
    26d4:      	movl	$0x4, %esi
    26d9:      	callq	*%rax
    26db:      	leaq	0x44(%rbp), %rdi
    26df:      	leaq	0xcc(%r12), %rdx
    26e7:      	movl	$0x4, %ecx
    26ec:      	movl	$0x4, %eax
    26f1:      	movl	$0x4, %esi
    26f6:      	callq	*%rax
    26f8:      	leaq	0x48(%rbp), %rdi
    26fc:      	leaq	0xd0(%r12), %rdx
    2704:      	movl	$0x4, %ecx
    2709:      	movl	$0x4, %eax
    270e:      	movl	$0x4, %esi
    2713:      	callq	*%rax
    2715:      	addq	$0x4c, %rbp
    2719:      	addq	$0x158, %r12            # imm = 0x158
    2720:      	movl	$0x4, %ecx
    2725:      	movl	$0x4, %eax
    272a:      	movq	%rbp, %rdi
    272d:      	movl	$0x4, %esi
    2732:      	movq	%r12, %rdx
    2735:      	callq	*%rax
    2737:      	movl	$0x50, %edx
    273c:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    2741:      	leaq	0xc8(%r15), %rdx
    2748:      	movl	$0x4, %ecx
    274d:      	movl	$0x4, %eax
    2752:      	movq	0x30(%rsp), %r12
    2757:      	movq	%r12, %rdi
    275a:      	movl	$0x4, %esi
    275f:      	callq	*%rax
    2761:      	leaq	0x4(%r12), %rdi
    2766:      	leaq	0xcc(%r15), %rdx
    276d:      	movl	$0x4, %ecx
    2772:      	movl	$0x4, %eax
    2777:      	movl	$0x4, %esi
    277c:      	callq	*%rax
    277e:      	leaq	0x8(%r12), %rdi
    2783:      	leaq	0xd0(%r15), %rdx
    278a:      	movl	$0x4, %ecx
    278f:      	movl	$0x4, %eax
    2794:      	movl	$0x4, %esi
    2799:      	callq	*%rax
    279b:      	addq	$0xc, %r12
    279f:      	addq	$0x158, %r15            # imm = 0x158
    27a6:      	movl	$0x4, %ecx
    27ab:      	movl	$0x4, %eax
    27b0:      	movq	%r12, %rdi
    27b3:      	movl	$0x4, %esi
    27b8:      	movq	%r15, %rdx
    27bb:      	callq	*%rax
    27bd:      	movl	$0x10, %edx
    27c2:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    27c7:      	leaq	0x38(%r15), %rdx
    27cb:      	movl	$0x4, %ecx
    27d0:      	movl	$0x4, %eax
    27d5:      	movq	0x30(%rsp), %r12
    27da:      	movq	%r12, %rdi
    27dd:      	movl	$0x4, %esi
    27e2:      	callq	*%rax
    27e4:      	leaq	0x4(%r12), %rdi
    27e9:      	leaq	0x3c(%r15), %rdx
    27ed:      	movl	$0x4, %ecx
    27f2:      	movl	$0x4, %eax
    27f7:      	movl	$0x4, %esi
    27fc:      	callq	*%rax
    27fe:      	leaq	0x8(%r12), %rdi
    2803:      	leaq	0x40(%r15), %rdx
    2807:      	movl	$0x4, %ecx
    280c:      	movl	$0x4, %eax
    2811:      	movl	$0x4, %esi
    2816:      	callq	*%rax
    2818:      	leaq	0xc(%r12), %rdi
    281d:      	leaq	0x44(%r15), %rdx
    2821:      	movl	$0x4, %ecx
    2826:      	movl	$0x4, %eax
    282b:      	movl	$0x4, %esi
    2830:      	callq	*%rax
    2832:      	addq	$0x10, %r12
    2836:      	subq	$-0x80, %r15
    283a:      	movl	$0x10, %ecx
    283f:      	movl	$0x4, %eax
    2844:      	movq	%r12, %rdi
    2847:      	movl	$0x10, %esi
    284c:      	movq	%r15, %rdx
    284f:      	callq	*%rax
    2851:      	movl	$0x20, %edx
    2856:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    285b:      	movl	$0x4, %ecx
    2860:      	movl	$0x4, %eax
    2865:      	movq	0x30(%rsp), %r12
    286a:      	movq	%r12, %rdi
    286d:      	movl	$0x4, %esi
    2872:      	movq	%r15, %rdx
    2875:      	callq	*%rax
    2877:      	leaq	0x4(%r12), %rdi
    287c:      	leaq	0x4(%r15), %rdx
    2880:      	movl	$0x4, %ecx
    2885:      	movl	$0x4, %eax
    288a:      	movl	$0x4, %esi
    288f:      	callq	*%rax
    2891:      	addq	$0x8, %r12
    2895:      	addq	$0x30, %r15
    2899:      	movl	$0x10, %ecx
    289e:      	movl	$0x4, %eax
    28a3:      	movq	%r12, %rdi
    28a6:      	movl	$0x10, %esi
    28ab:      	movq	%r15, %rdx
    28ae:      	jmp	0x2942 <generic_usdt_process_event+0x1f62>
    28b3:      	leaq	0x4(%r15), %rdx
    28b7:      	leaq	0x40(%rsp), %rdi
    28bc:      	movl	$0x4, %ecx
    28c1:      	movl	$0x4, %eax
    28c6:      	movl	$0x4, %esi
    28cb:      	callq	*%rax
    28cd:      	movl	0x40(%rsp), %eax
    28d1:      	movq	0x30(%rsp), %r12
    28d6:      	movl	%eax, (%r12)
    28da:      	leaq	0xc(%r15), %rdx
    28de:      	leaq	0x40(%rsp), %rdi
    28e3:      	movl	$0x4, %ecx
    28e8:      	movl	$0x4, %eax
    28ed:      	movl	$0x4, %esi
    28f2:      	callq	*%rax
    28f4:      	movl	0x40(%rsp), %eax
    28f8:      	movl	%eax, 0x4(%r12)
    28fd:      	addq	$0x50, %r15
    2901:      	leaq	0x40(%rsp), %rdi
    2906:      	movl	$0x8, %ecx
    290b:      	movl	$0x2d, %eax
    2910:      	movl	$0x8, %esi
    2915:      	movq	%r15, %rdx
    2918:      	callq	*%rax
    291a:      	addq	$0x8, %r12
    291e:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2923:      	movq	0x40(%rsp), %rcx
    2928:      	addq	%rdx, %rcx
    292b:      	movl	$0x10, %esi
    2930:      	movl	$0x2d, %eax
    2935:      	addq	0x40(%rsp), %rdx
    293a:      	movq	%r12, %rdi
    293d:      	movl	$0x10, %esi
    2942:      	callq	*%rax
    2944:      	movl	$0x18, %edx
    2949:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    294e:      	movq	$0x0, 0x48(%rdi)
    2956:      	movq	$0x0, 0x40(%rdi)
    295e:      	movq	$0x0, 0x38(%rdi)
    2966:      	movq	$0x0, 0x30(%rdi)
    296e:      	movq	$0x0, 0x28(%rdi)
    2976:      	movq	$0x0, 0x20(%rdi)
    297e:      	movq	$0x0, 0x18(%rdi)
    2986:      	movq	$0x0, 0x10(%rdi)
    298e:      	movq	$0x0, 0x8(%rdi)
    2996:      	movq	%rdi, %r13
    2999:      	movq	$0x0, (%rdi)
    29a0:      	leaq	0x40(%rsp), %rdi
    29a5:      	movl	$0x8, %ecx
    29aa:      	movl	$0x4, %eax
    29af:      	movl	$0x8, %esi
    29b4:      	movq	%r15, %rdx
    29b7:      	callq	*%rax
    29b9:      	testq	%rax, %rax
    29bc:      	je	0x2dd4 <generic_usdt_process_event+0x23f4>
    29c2:      	xorl	%edx, %edx
    29c4:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    29c9:      	movq	$-0x1, %rdx
    29d0:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    29d5:      	leaq	0x10(%r12), %rdx
    29da:      	leaq	0x20(%rsp), %rdi
    29df:      	movl	$0x8, %r13d
    29e5:      	movl	$0x8, %ecx
    29ea:      	movl	$0x4, %eax
    29ef:      	movl	$0x8, %esi
    29f4:      	callq	*%rax
    29f6:      	addq	$0x18, %r12
    29fa:      	leaq	0xa0(%rsp), %rdi
    2a02:      	movl	$0x8, %ecx
    2a07:      	movl	$0x4, %eax
    2a0c:      	movl	$0x8, %esi
    2a11:      	movq	%r12, %rdx
    2a14:      	callq	*%rax
    2a16:      	movq	0x20(%rsp), %rax
    2a1b:      	movq	%rax, 0x18(%rsp)
    2a20:      	movq	0xa0(%rsp), %rbx
    2a28:      	movq	0x10(%rsp), %rax
    2a2d:      	movq	0x90(%rsp), %rcx
    2a35:      	leaq	(%rax,%rcx), %r12
    2a39:      	addq	$0x90, %r12
    2a40:      	testb	$0x20, 0xc8(%rsp)
    2a48:      	je	0x35b0 <generic_usdt_process_event+0x2bd0>
    2a4e:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    2a55:      	jb	0x3581 <generic_usdt_process_event+0x2ba1>
    2a5b:      	movl	$0x1, (%r12)
    2a63:      	movl	$0x0, 0xb8(%rsp)
    2a6e:      	movq	(%rip), %rdi            # 0x2a75 <generic_usdt_process_event+0x2095>
    2a75:      	leaq	0xb8(%rsp), %rsi
    2a7d:      	movl	$0x1, %eax
    2a82:      	callq	*%rax
    2a84:      	testq	%rax, %rax
    2a87:      	je	0x37f6 <generic_usdt_process_event+0x2e16>
    2a8d:      	movq	%rax, %r15
    2a90:      	movl	$0x18, (%rax)
    2a96:      	movl	$0xe, %eax
    2a9b:      	callq	*%rax
    2a9d:      	movq	%r15, %r13
    2aa0:      	addq	$0x10, %r13
    2aa4:      	movq	%rax, 0x10(%r15)
    2aa8:      	cmpq	$-0x16, %rax
    2aac:      	jne	0x2ad6 <generic_usdt_process_event+0x20f6>
    2aae:      	movq	0x8(%rsp), %rax
    2ab3:      	leaq	0x20(%rax), %rdx
    2ab7:      	leaq	0x40(%rsp), %rdi
    2abc:      	movl	$0x8, %ecx
    2ac1:      	movl	$0x4, %eax
    2ac6:      	movl	$0x8, %esi
    2acb:      	callq	*%rax
    2acd:      	movq	0x40(%rsp), %rax
    2ad2:      	movq	%rax, (%r13)
    2ad6:      	movl	$0x7d, %eax
    2adb:      	callq	*%rax
    2add:      	movq	%rax, 0x18(%r15)
    2ae1:      	movq	(%r13), %rax
    2ae5:      	movq	0x8(%r13), %rcx
    2ae9:      	movq	%rax, 0x14(%r12)
    2aee:      	movq	%rcx, 0x1c(%r12)
    2af3:      	movq	0x8(%rsp), %rdi
    2af8:      	movq	%r15, %rsi
    2afb:      	movq	0x18(%rsp), %rdx
    2b00:      	movq	%rbx, %rcx
    2b03:      	callq	0x2b08 <generic_usdt_process_event+0x2128>
    2b08:      	testl	%eax, %eax
    2b0a:      	js	0x3878 <generic_usdt_process_event+0x2e98>
    2b10:      	movq	$0x0, 0x4(%r12)
    2b19:      	movl	%ebx, %edx
    2b1b:      	subl	%eax, %edx
    2b1d:      	xorl	%ecx, %ecx
    2b1f:      	cmpq	$-0x1, %rbx
    2b23:      	jmp	0x37ee <generic_usdt_process_event+0x2e0e>
    2b28:      	movq	0x40(%rsp), %rcx
    2b2d:      	movl	$0x0, 0x80(%rsp)
    2b38:      	movzwl	0xa0(%rsp), %r15d
    2b41:      	movq	(%rip), %rdi            # 0x2b48 <generic_usdt_process_event+0x2168>
    2b48:      	leaq	0x80(%rsp), %rsi
    2b50:      	movl	$0x1, %eax
    2b55:      	movq	%rcx, 0x18(%rsp)
    2b5a:      	leaq	(%rcx,%r15), %r13
    2b5e:      	callq	*%rax
    2b60:      	testq	%rax, %rax
    2b63:      	je	0x3db1 <generic_usdt_process_event+0x33d1>
    2b69:      	movq	%rax, %rbp
    2b6c:      	movw	%r15w, (%rax)
    2b70:      	movb	$-0x1, 0x5(%rax)
    2b74:      	movb	$0x0, 0x7(%rax)
    2b78:      	movq	%rax, %rdi
    2b7b:      	addq	$0x6, %rdi
    2b7f:      	leaq	0x6(%r13), %rdx
    2b83:      	movl	$0x1, %ecx
    2b88:      	movl	$0x4, %eax
    2b8d:      	movq	%rdi, 0x10(%rsp)
    2b92:      	movl	$0x1, %esi
    2b97:      	callq	*%rax
    2b99:      	testq	%rax, %rax
    2b9c:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    2ba2:      	movzbl	0x5(%rbp), %eax
    2ba6:      	cmpl	$0x32, %eax
    2ba9:      	jg	0x3606 <generic_usdt_process_event+0x2c26>
    2baf:      	testl	%eax, %eax
    2bb1:      	je	0x36b2 <generic_usdt_process_event+0x2cd2>
    2bb7:      	cmpl	$0x2b, %eax
    2bba:      	je	0x36b2 <generic_usdt_process_event+0x2cd2>
    2bc0:      	cmpl	$0x2c, %eax
    2bc3:      	jne	0x395e <generic_usdt_process_event+0x2f7e>
    2bc9:      	movw	$0x8, 0x2(%rbp)
    2bcf:      	movw	$0x8, %ax
    2bd3:      	jmp	0x38ad <generic_usdt_process_event+0x2ecd>
    2bd8:      	leaq	0x48(%r15), %rdx
    2bdc:      	movl	$0x10, %ecx
    2be1:      	movl	$0x4, %eax
    2be6:      	movq	%rbp, %rdi
    2be9:      	movl	$0x10, %esi
    2bee:      	callq	*%rax
    2bf0:      	leaq	0x38(%r15), %rdx
    2bf4:      	movl	$0x10, %ecx
    2bf9:      	movl	$0x4, %eax
    2bfe:      	movq	%r12, %rdi
    2c01:      	movl	$0x10, %esi
    2c06:      	callq	*%rax
    2c08:      	leaq	0x20(%rbp), %rdi
    2c0c:      	leaq	0xc(%r15), %r12
    2c10:      	addq	$0xe, %r15
    2c14:      	movl	$0x2, %ecx
    2c19:      	movl	$0x4, %eax
    2c1e:      	movl	$0x2, %esi
    2c23:      	movq	%r15, %rdx
    2c26:      	callq	*%rax
    2c28:      	leaq	0x22(%rbp), %rdi
    2c2c:      	movl	$0x2, %ecx
    2c31:      	movl	$0x4, %eax
    2c36:      	movl	$0x2, %esi
    2c3b:      	movq	%r12, %rdx
    2c3e:      	callq	*%rax
    2c40:      	movzwl	0x22(%rbp), %eax
    2c44:      	movbew	%ax, 0x22(%rbp)
    2c4a:      	movq	0x38(%rsp), %rax
    2c4f:      	movq	%rax, 0x40(%rsp)
    2c54:      	movq	(%rip), %rdi            # 0x2c5b <generic_usdt_process_event+0x227b>
    2c5b:      	leaq	0x40(%rsp), %rsi
    2c60:      	movl	$0x1, %eax
    2c65:      	callq	*%rax
    2c67:      	testq	%rax, %rax
    2c6a:      	jne	0x301a <generic_usdt_process_event+0x263a>
    2c70:      	jmp	0x3f6b <generic_usdt_process_event+0x358b>
    2c75:      	movq	0x10(%rsp), %rax
    2c7a:      	movq	0x90(%rsp), %rcx
    2c82:      	movq	$0x0, 0x90(%rax,%rcx)
    2c8e:      	movl	$0x8, %edx
    2c93:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    2c98:      	movl	$0xe, %eax
    2c9d:      	callq	*%rax
    2c9f:      	cmpq	$-0x16, %rax
    2ca3:      	jne	0x2cc9 <generic_usdt_process_event+0x22e9>
    2ca5:      	movq	0x8(%rsp), %rax
    2caa:      	leaq	0x20(%rax), %rdx
    2cae:      	leaq	0x40(%rsp), %rdi
    2cb3:      	movl	$0x8, %ecx
    2cb8:      	movl	$0x4, %eax
    2cbd:      	movl	$0x8, %esi
    2cc2:      	callq	*%rax
    2cc4:      	movq	0x40(%rsp), %rax
    2cc9:      	movq	0x8(%rbp), %rcx
    2ccd:      	movq	0x60(%rbp), %rdx
    2cd1:      	movq	%rcx, 0x40(%rsp)
    2cd6:      	movq	0x10(%rsp), %rcx
    2cdb:      	movq	%rcx, 0x48(%rsp)
    2ce0:      	movq	$0x0, 0x50(%rsp)
    2ce9:      	movq	%rdx, 0x80(%rsp)
    2cf1:      	movq	%rax, 0x88(%rsp)
    2cf9:      	movq	(%rip), %rdi            # 0x2d00 <generic_usdt_process_event+0x2320>
    2d00:      	xorl	%ecx, %ecx
    2d02:      	leaq	0x80(%rsp), %rsi
    2d0a:      	leaq	0x40(%rsp), %rdx
    2d0f:      	movl	$0x2, %eax
    2d14:      	xorl	%ecx, %ecx
    2d16:      	callq	*%rax
    2d18:      	testq	%rax, %rax
    2d1b:      	je	0x365c <generic_usdt_process_event+0x2c7c>
    2d21:      	negl	%eax
    2d23:      	movw	%ax, 0x20(%rsp)
    2d28:      	movw	$0x5, 0x22(%rsp)
    2d2f:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2d39:      	movq	%rax, 0x24(%rsp)
    2d3e:      	movq	(%rip), %rdi            # 0x2d45 <generic_usdt_process_event+0x2365>
    2d45:      	leaq	0x20(%rsp), %rsi
    2d4a:      	movl	$0x1, %eax
    2d4f:      	callq	*%rax
    2d51:      	testq	%rax, %rax
    2d54:      	je	0x3632 <generic_usdt_process_event+0x2c52>
    2d5a:      	incl	(%rax)
    2d5c:      	jmp	0x365c <generic_usdt_process_event+0x2c7c>
    2d61:      	cmpl	$0x1, %eax
    2d64:      	je	0x304a <generic_usdt_process_event+0x266a>
    2d6a:      	cmpl	$0x2, %eax
    2d6d:      	jne	0x3420 <generic_usdt_process_event+0x2a40>
    2d73:      	movq	%r13, %rax
    2d76:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2d7c:      	jmp	0x3053 <generic_usdt_process_event+0x2673>
    2d81:      	movq	%r13, %r12
    2d84:      	leaq	0x8(%r13), %rdi
    2d88:      	leaq	0x8(%r15), %rdx
    2d8c:      	movl	$0x10, %ecx
    2d91:      	movl	$0x4, %eax
    2d96:      	movl	$0x10, %esi
    2d9b:      	callq	*%rax
    2d9d:      	leaq	0x2(%r13), %rdi
    2da1:      	addq	$0x2, %r15
    2da5:      	movl	$0x2, %ecx
    2daa:      	movl	$0x4, %eax
    2daf:      	movl	$0x2, %esi
    2db4:      	movq	%r15, %rdx
    2db7:      	callq	*%rax
    2db9:      	movzwl	0x2(%r13), %eax
    2dbe:      	movbew	%ax, 0x2(%r13)
    2dc5:      	movq	0x8(%rsp), %rbx
    2dca:      	movl	$0x18, %edx
    2dcf:      	jmp	0x2ecb <generic_usdt_process_event+0x24eb>
    2dd4:      	leaq	0x10(%r13), %rdi
    2dd8:      	movq	0x40(%rsp), %rcx
    2ddd:      	movl	$0x3f, %edx
    2de2:      	movl	$0x2d, %eax
    2de7:      	movq	0x40(%rsp), %rdx
    2dec:      	movl	$0x3f, %esi
    2df1:      	callq	*%rax
    2df3:      	testq	%rax, %rax
    2df6:      	js	0x29c2 <generic_usdt_process_event+0x1fe2>
    2dfc:      	movq	0x10(%rsp), %r12
    2e01:      	leaq	0x8(%r12), %rdx
    2e06:      	leaq	0x80(%rsp), %rdi
    2e0e:      	movl	$0x8, %ecx
    2e13:      	movl	$0x4, %eax
    2e18:      	movl	$0x8, %esi
    2e1d:      	callq	*%rax
    2e1f:      	leaq	0x8(%r13), %rdi
    2e23:      	movl	$0x348, %edx            # imm = 0x348
    2e28:      	movq	0x80(%rsp), %rcx
    2e30:      	addq	%rdx, %rcx
    2e33:      	movl	$0x8, %esi
    2e38:      	movl	$0x4, %eax
    2e3d:      	addq	0x80(%rsp), %rdx
    2e45:      	movl	$0x8, %esi
    2e4a:      	callq	*%rax
    2e4c:      	addq	$0x58, %r12
    2e50:      	leaq	0x80(%rsp), %rdi
    2e58:      	movl	$0x4, %ecx
    2e5d:      	movl	$0x4, %eax
    2e62:      	movl	$0x4, %esi
    2e67:      	movq	%r12, %rdx
    2e6a:      	callq	*%rax
    2e6c:      	movl	$0x50, %edx
    2e71:      	testq	%rax, %rax
    2e74:      	jne	0x3f70 <generic_usdt_process_event+0x3590>
    2e7a:      	xorl	%eax, %eax
    2e7c:      	cmpl	$0x0, 0x80(%rsp)
    2e84:      	setne	%al
    2e87:      	movl	%eax, (%r13)
    2e8b:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    2e90:      	xorl	%edx, %edx
    2e92:      	movq	%r13, %rcx
    2e95:      	movq	0x8(%rsp), %rbx
    2e9a:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    2e9c:      	addq	$0x3, %r15
    2ea0:      	movl	$0x6b, %ecx
    2ea5:      	movl	$0x71, %eax
    2eaa:      	movl	$0x6b, %esi
    2eaf:      	movq	%r15, %rdx
    2eb2:      	callq	*%rax
    2eb4:      	movq	%rax, %rcx
    2eb7:      	movb	$0x6b, %al
    2eb9:      	testl	%ecx, %ecx
    2ebb:      	movq	0x8(%rsp), %rbx
    2ec0:      	js	0x2ec6 <generic_usdt_process_event+0x24e6>
    2ec2:      	movb	%al, 0x3(%r13)
    2ec6:      	movl	$0x70, %edx
    2ecb:      	movq	(%rsp), %rcx
    2ecf:      	movq	0xc0(%rsp), %r12
    2ed7:      	movq	0xa8(%rsp), %r13
    2edf:      	testl	%edx, %edx
    2ee1:      	js	0x2eee <generic_usdt_process_event+0x250e>
    2ee3:      	andl	$0x7fffffff, %edx       # imm = 0x7FFFFFFF
    2ee9:      	addl	$0x4, %edx
    2eec:      	jmp	0x2f12 <generic_usdt_process_event+0x2532>
    2eee:      	movq	0xd8(%rsp), %rax
    2ef6:      	movl	$0xffffffff, 0x5ea0(%rcx,%rax,4) # imm = 0xFFFFFFFF
    2f01:      	movl	$0xffffffff, 0x90(%rcx,%r13) # imm = 0xFFFFFFFF
    2f0d:      	movl	$0x4, %edx
    2f12:      	addl	%r13d, %edx
    2f15:      	movl	%edx, %r13d
    2f18:      	movl	%r13d, 0x4(%r14)
    2f1c:      	cmpl	$0x3, %r12d
    2f20:      	jle	0xe75 <generic_usdt_process_event+0x495>
    2f26:      	movl	$0x0, 0x5efc(%r14)
    2f31:      	movq	(%rip), %rsi            # 0x2f38 <generic_usdt_process_event+0x2558>
    2f38:      	movl	$0x3, %ecx
    2f3d:      	movl	$0xc, %eax
    2f42:      	movq	%rbx, %rdi
    2f45:      	movl	$0x3, %edx
    2f4a:      	callq	*%rax
    2f4c:      	xorl	%eax, %eax
    2f4e:      	addq	$0x108, %rsp            # imm = 0x108
    2f55:      	popq	%rbx
    2f56:      	popq	%r12
    2f58:      	popq	%r13
    2f5a:      	popq	%r14
    2f5c:      	popq	%r15
    2f5e:      	popq	%rbp
    2f5f:      	retq
    2f60:      	cmpl	$0x1, %ecx
    2f63:      	je	0x36d4 <generic_usdt_process_event+0x2cf4>
    2f69:      	cmpl	$0x2, %ecx
    2f6c:      	jne	0x36de <generic_usdt_process_event+0x2cfe>
    2f72:      	leaq	0x5e58(%rbp), %rax
    2f79:      	jmp	0x36db <generic_usdt_process_event+0x2cfb>
    2f7e:      	leaq	0x48(%r15), %rdx
    2f82:      	movl	$0x10, %ecx
    2f87:      	movl	$0x4, %eax
    2f8c:      	movq	%rbp, %rdi
    2f8f:      	movl	$0x10, %esi
    2f94:      	callq	*%rax
    2f96:      	leaq	0x38(%r15), %rdx
    2f9a:      	movl	$0x10, %ecx
    2f9f:      	movl	$0x4, %eax
    2fa4:      	movq	%r12, %rdi
    2fa7:      	movl	$0x10, %esi
    2fac:      	callq	*%rax
    2fae:      	leaq	0x20(%rbp), %rdi
    2fb2:      	leaq	0xc(%r15), %r12
    2fb6:      	addq	$0xe, %r15
    2fba:      	movl	$0x2, %ecx
    2fbf:      	movl	$0x4, %eax
    2fc4:      	movl	$0x2, %esi
    2fc9:      	movq	%r15, %rdx
    2fcc:      	callq	*%rax
    2fce:      	leaq	0x22(%rbp), %rdi
    2fd2:      	movl	$0x2, %ecx
    2fd7:      	movl	$0x4, %eax
    2fdc:      	movl	$0x2, %esi
    2fe1:      	movq	%r12, %rdx
    2fe4:      	callq	*%rax
    2fe6:      	movzwl	0x22(%rbp), %eax
    2fea:      	movbew	%ax, 0x22(%rbp)
    2ff0:      	movq	0x30(%rsp), %rax
    2ff5:      	movq	0x28(%rax), %rax
    2ff9:      	movq	%rax, 0x40(%rsp)
    2ffe:      	movq	(%rip), %rdi            # 0x3005 <generic_usdt_process_event+0x2625>
    3005:      	leaq	0x40(%rsp), %rsi
    300a:      	movl	$0x1, %eax
    300f:      	callq	*%rax
    3011:      	testq	%rax, %rax
    3014:      	je	0x3f6b <generic_usdt_process_event+0x358b>
    301a:      	movl	(%rax), %ecx
    301c:      	movl	%ecx, 0x10(%r13)
    3020:      	movq	0x8(%rax), %rcx
    3024:      	movq	%rcx, 0x18(%r13)
    3028:      	movl	0x4(%rax), %eax
    302b:      	movl	%eax, 0x7c(%r13)
    302f:      	jmp	0x3f6b <generic_usdt_process_event+0x358b>
    3034:      	movq	%r13, %rax
    3037:      	addq	$0x5e60, %rax           # imm = 0x5E60
    303d:      	jmp	0x3053 <generic_usdt_process_event+0x2673>
    303f:      	movq	%r13, %rax
    3042:      	addq	$0x5e68, %rax           # imm = 0x5E68
    3048:      	jmp	0x3053 <generic_usdt_process_event+0x2673>
    304a:      	movq	%r13, %rax
    304d:      	addq	$0x5e50, %rax           # imm = 0x5E50
    3053:      	movq	(%rax), %rbp
    3056:      	testb	$0x10, 0xc8(%rsp)
    305e:      	jne	0x3436 <generic_usdt_process_event+0x2a56>
    3064:      	testq	%rbp, %rbp
    3067:      	je	0x34fb <generic_usdt_process_event+0x2b1b>
    306d:      	leaq	0x40(%rsp), %rdi
    3072:      	movl	$0x10, %ecx
    3077:      	movl	$0x4, %eax
    307c:      	movq	0x10(%rsp), %rdx
    3081:      	movl	$0x10, %esi
    3086:      	callq	*%rax
    3088:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    308d:      	testl	%eax, %eax
    308f:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    3095:      	movq	0x48(%rsp), %rax
    309a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    309f:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    30a5:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    30ab:      	movq	%rax, %r12
    30ae:      	movq	0xa8(%rsp), %rax
    30b6:      	leaq	0xc(%rax), %rdi
    30ba:      	movq	%rdi, %r13
    30bd:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    30c3:      	addq	%r15, %rdi
    30c6:      	movq	0x40(%rsp), %rcx
    30cb:      	movl	$0x4, %eax
    30d0:      	movq	%r12, %rsi
    30d3:      	movq	0x40(%rsp), %rdx
    30d8:      	callq	*%rax
    30da:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30df:      	testl	%eax, %eax
    30e1:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    30e7:      	cmpq	$0x1, %rbp
    30eb:      	je	0x34fe <generic_usdt_process_event+0x2b1e>
    30f1:      	movq	0x10(%rsp), %rax
    30f6:      	leaq	0x10(%rax), %rdx
    30fa:      	leaq	0x40(%rsp), %rdi
    30ff:      	movl	$0x10, %ecx
    3104:      	movl	$0x4, %eax
    3109:      	movl	$0x10, %esi
    310e:      	callq	*%rax
    3110:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3115:      	testl	%eax, %eax
    3117:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    311d:      	movq	0x48(%rsp), %rbx
    3122:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3127:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    312e:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    3134:      	movq	%r13, %rdi
    3137:      	addq	%r12, %rdi
    313a:      	movq	%rdi, %r13
    313d:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3143:      	addq	%r15, %rdi
    3146:      	movq	0x40(%rsp), %rcx
    314b:      	movl	$0x4, %eax
    3150:      	movq	0x40(%rsp), %rdx
    3155:      	movl	%ebx, %esi
    3157:      	callq	*%rax
    3159:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    315e:      	testl	%eax, %eax
    3160:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    3166:      	addq	%rbx, %r12
    3169:      	cmpq	$0x3, %rbp
    316d:      	jb	0x34fe <generic_usdt_process_event+0x2b1e>
    3173:      	movq	0x10(%rsp), %rax
    3178:      	leaq	0x20(%rax), %rdx
    317c:      	leaq	0x40(%rsp), %rdi
    3181:      	movl	$0x10, %ecx
    3186:      	movl	$0x4, %eax
    318b:      	movl	$0x10, %esi
    3190:      	callq	*%rax
    3192:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3197:      	testl	%eax, %eax
    3199:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    319f:      	movq	0x48(%rsp), %rax
    31a4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    31a9:      	movq	%rax, 0x18(%rsp)
    31ae:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    31b4:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    31ba:      	addq	%r13, %rbx
    31bd:      	movl	%ebx, %edi
    31bf:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    31c5:      	addq	%r15, %rdi
    31c8:      	movq	0x40(%rsp), %rcx
    31cd:      	movl	$0x4, %eax
    31d2:      	movq	0x18(%rsp), %rsi
    31d7:      	movq	0x40(%rsp), %rdx
    31dc:      	callq	*%rax
    31de:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31e3:      	testl	%eax, %eax
    31e5:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    31eb:      	addq	0x18(%rsp), %r12
    31f0:      	cmpq	$0x3, %rbp
    31f4:      	je	0x34fe <generic_usdt_process_event+0x2b1e>
    31fa:      	movq	0x10(%rsp), %rax
    31ff:      	leaq	0x30(%rax), %rdx
    3203:      	leaq	0x40(%rsp), %rdi
    3208:      	movl	$0x10, %ecx
    320d:      	movl	$0x4, %eax
    3212:      	movl	$0x10, %esi
    3217:      	callq	*%rax
    3219:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    321e:      	testl	%eax, %eax
    3220:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    3226:      	movq	0x48(%rsp), %rax
    322b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3230:      	movq	%rax, 0xb0(%rsp)
    3238:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    323e:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    3244:      	movq	0x18(%rsp), %rdi
    3249:      	addq	%rbx, %rdi
    324c:      	movq	%rdi, %r13
    324f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3255:      	addq	%r15, %rdi
    3258:      	movq	0x40(%rsp), %rcx
    325d:      	movl	$0x4, %eax
    3262:      	movq	0xb0(%rsp), %rsi
    326a:      	movq	0x40(%rsp), %rdx
    326f:      	callq	*%rax
    3271:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3276:      	testl	%eax, %eax
    3278:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    327e:      	addq	0xb0(%rsp), %r12
    3286:      	cmpq	$0x5, %rbp
    328a:      	jb	0x34fe <generic_usdt_process_event+0x2b1e>
    3290:      	movq	0x10(%rsp), %rax
    3295:      	leaq	0x40(%rax), %rdx
    3299:      	leaq	0x40(%rsp), %rdi
    329e:      	movl	$0x10, %ecx
    32a3:      	movl	$0x4, %eax
    32a8:      	movl	$0x10, %esi
    32ad:      	callq	*%rax
    32af:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32b4:      	testl	%eax, %eax
    32b6:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    32bc:      	movq	0x48(%rsp), %rbx
    32c1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    32c6:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    32cd:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    32d3:      	movq	0xb0(%rsp), %rdi
    32db:      	addq	%r13, %rdi
    32de:      	movq	%rdi, %r13
    32e1:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    32e7:      	addq	%r15, %rdi
    32ea:      	movq	0x40(%rsp), %rcx
    32ef:      	movl	$0x4, %eax
    32f4:      	movq	0x40(%rsp), %rdx
    32f9:      	movl	%ebx, %esi
    32fb:      	callq	*%rax
    32fd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3302:      	testl	%eax, %eax
    3304:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    330a:      	addq	%rbx, %r12
    330d:      	cmpq	$0x5, %rbp
    3311:      	je	0x34fe <generic_usdt_process_event+0x2b1e>
    3317:      	movq	0x10(%rsp), %rax
    331c:      	leaq	0x50(%rax), %rdx
    3320:      	leaq	0x40(%rsp), %rdi
    3325:      	movl	$0x10, %ecx
    332a:      	movl	$0x4, %eax
    332f:      	movl	$0x10, %esi
    3334:      	callq	*%rax
    3336:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    333b:      	testl	%eax, %eax
    333d:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    3343:      	movq	0x48(%rsp), %rax
    3348:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    334d:      	movq	%rax, 0x18(%rsp)
    3352:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3358:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    335e:      	addq	%r13, %rbx
    3361:      	movl	%ebx, %edi
    3363:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3369:      	addq	%r15, %rdi
    336c:      	movq	0x40(%rsp), %rcx
    3371:      	movl	$0x4, %eax
    3376:      	movq	0x18(%rsp), %rsi
    337b:      	movq	0x40(%rsp), %rdx
    3380:      	callq	*%rax
    3382:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3387:      	testl	%eax, %eax
    3389:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    338f:      	addq	0x18(%rsp), %r12
    3394:      	cmpq	$0x7, %rbp
    3398:      	jb	0x34fe <generic_usdt_process_event+0x2b1e>
    339e:      	movq	0x10(%rsp), %rdx
    33a3:      	addq	$0x60, %rdx
    33a7:      	leaq	0x40(%rsp), %rdi
    33ac:      	movl	$0x10, %ecx
    33b1:      	movl	$0x4, %eax
    33b6:      	movl	$0x10, %esi
    33bb:      	callq	*%rax
    33bd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    33c2:      	testl	%eax, %eax
    33c4:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    33c6:      	movq	0x48(%rsp), %r13
    33cb:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    33d0:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    33d7:      	ja	0x340f <generic_usdt_process_event+0x2a2f>
    33d9:      	movq	0x18(%rsp), %rdi
    33de:      	addq	%rbx, %rdi
    33e1:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    33e7:      	addq	%r15, %rdi
    33ea:      	movq	0x40(%rsp), %rcx
    33ef:      	movl	$0x4, %eax
    33f4:      	movq	0x40(%rsp), %rdx
    33f9:      	movl	%r13d, %esi
    33fc:      	callq	*%rax
    33fe:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3403:      	testl	%eax, %eax
    3405:      	js	0x340f <generic_usdt_process_event+0x2a2f>
    3407:      	addq	%r13, %r12
    340a:      	jmp	0x34fe <generic_usdt_process_event+0x2b1e>
    340f:      	movq	0x90(%rsp), %rax
    3417:      	movl	%ecx, (%r15,%rax)
    341b:      	jmp	0x35f3 <generic_usdt_process_event+0x2c13>
    3420:      	xorl	%ebp, %ebp
    3422:      	movl	$0x0, %r12d
    3428:      	testb	$0x10, 0xc8(%rsp)
    3430:      	je	0x34fe <generic_usdt_process_event+0x2b1e>
    3436:      	movl	$0xe, %eax
    343b:      	callq	*%rax
    343d:      	cmpq	$-0x16, %rax
    3441:      	jne	0x3467 <generic_usdt_process_event+0x2a87>
    3443:      	movq	0x8(%rsp), %rax
    3448:      	leaq	0x20(%rax), %rdx
    344c:      	leaq	0x40(%rsp), %rdi
    3451:      	movl	$0x8, %ecx
    3456:      	movl	$0x4, %eax
    345b:      	movl	$0x8, %esi
    3460:      	callq	*%rax
    3462:      	movq	0x40(%rsp), %rax
    3467:      	movq	0x8(%r13), %rcx
    346b:      	movq	0x60(%r13), %rdx
    346f:      	movq	%rcx, 0x40(%rsp)
    3474:      	movq	0x10(%rsp), %rcx
    3479:      	movq	%rcx, 0x48(%rsp)
    347e:      	movq	%rbp, 0x50(%rsp)
    3483:      	movq	%rdx, 0x80(%rsp)
    348b:      	movq	%rax, 0x88(%rsp)
    3493:      	movq	(%rip), %rdi            # 0x349a <generic_usdt_process_event+0x2aba>
    349a:      	xorl	%ecx, %ecx
    349c:      	leaq	0x80(%rsp), %rsi
    34a4:      	leaq	0x40(%rsp), %rdx
    34a9:      	movl	$0x2, %eax
    34ae:      	xorl	%ecx, %ecx
    34b0:      	callq	*%rax
    34b2:      	testq	%rax, %rax
    34b5:      	je	0x3698 <generic_usdt_process_event+0x2cb8>
    34bb:      	negl	%eax
    34bd:      	movw	%ax, 0x20(%rsp)
    34c2:      	movw	$0x5, 0x22(%rsp)
    34c9:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    34d3:      	movq	%rax, 0x24(%rsp)
    34d8:      	movq	(%rip), %rdi            # 0x34df <generic_usdt_process_event+0x2aff>
    34df:      	leaq	0x20(%rsp), %rsi
    34e4:      	movl	$0x1, %eax
    34e9:      	callq	*%rax
    34eb:      	testq	%rax, %rax
    34ee:      	je	0x366e <generic_usdt_process_event+0x2c8e>
    34f4:      	incl	(%rax)
    34f6:      	jmp	0x3698 <generic_usdt_process_event+0x2cb8>
    34fb:      	xorl	%r12d, %r12d
    34fe:      	movq	0x90(%rsp), %rax
    3506:      	movl	%r12d, (%r15,%rax)
    350a:      	movl	%r12d, 0x4(%r15,%rax)
    350f:      	addq	$0x8, %r12
    3513:      	movq	%r12, %rdx
    3516:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    351b:      	movq	0x10(%rsp), %rax
    3520:      	addq	$0x90, %rax
    3526:      	movl	$0x0, (%r12)
    352e:      	movq	0xa8(%rsp), %rcx
    3536:      	leal	0x8(%rcx), %r12d
    353a:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    3541:      	addq	%rax, %r12
    3544:      	movl	$0xc, %r15d
    354a:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    3551:      	movl	$0xfff, %ebp            # imm = 0xFFF
    3556:      	cmovbq	%rbx, %rbp
    355a:      	leaq	0x8(%r12), %rdi
    355f:      	movl	$0x4, %eax
    3564:      	movq	0xb0(%rsp), %rdx
    356c:      	movl	%ebp, %esi
    356e:      	callq	*%rax
    3570:      	testl	%eax, %eax
    3572:      	js	0x3866 <generic_usdt_process_event+0x2e86>
    3578:      	movl	%ebx, (%r12)
    357c:      	jmp	0x3856 <generic_usdt_process_event+0x2e76>
    3581:      	movq	0x10(%rsp), %rax
    3586:      	addq	$0x90, %rax
    358c:      	movl	$0x0, (%r12)
    3594:      	movq	0xa8(%rsp), %rcx
    359c:      	leal	0x8(%rcx), %r12d
    35a0:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    35a7:      	addq	%rax, %r12
    35aa:      	movl	$0xc, %r13d
    35b0:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    35b7:      	movl	$0xfff, %ebp            # imm = 0xFFF
    35bc:      	cmovbq	%rbx, %rbp
    35c0:      	leaq	0x8(%r12), %rdi
    35c5:      	movl	$0x4, %eax
    35ca:      	movq	0x18(%rsp), %rdx
    35cf:      	movl	%ebp, %esi
    35d1:      	callq	*%rax
    35d3:      	testl	%eax, %eax
    35d5:      	js	0x35eb <generic_usdt_process_event+0x2c0b>
    35d7:      	movl	%ebx, (%r12)
    35db:      	movl	%ebp, 0x4(%r12)
    35e0:      	addq	%rbp, %r13
    35e3:      	movq	%r13, %rdx
    35e6:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    35eb:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    35f3:      	movq	(%rsp), %rcx
    35f7:      	movl	$0x4, %edx
    35fc:      	movq	0x8(%rsp), %rbx
    3601:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    3606:      	cmpl	$0x33, %eax
    3609:      	je	0x389e <generic_usdt_process_event+0x2ebe>
    360f:      	cmpl	$0x3c, %eax
    3612:      	je	0x36b2 <generic_usdt_process_event+0x2cd2>
    3618:      	cmpl	$0xff, %eax
    361d:      	jne	0x395e <generic_usdt_process_event+0x2f7e>
    3623:      	movw	$0x28, 0x2(%rbp)
    3629:      	movw	$0x28, %ax
    362d:      	jmp	0x38ad <generic_usdt_process_event+0x2ecd>
    3632:      	movl	$0x1, 0xb8(%rsp)
    363d:      	movq	(%rip), %rdi            # 0x3644 <generic_usdt_process_event+0x2c64>
    3644:      	xorl	%ecx, %ecx
    3646:      	leaq	0x20(%rsp), %rsi
    364b:      	leaq	0xb8(%rsp), %rdx
    3653:      	movl	$0x2, %eax
    3658:      	xorl	%ecx, %ecx
    365a:      	callq	*%rax
    365c:      	movl	$0xfffffffc, (%r12)     # imm = 0xFFFFFFFC
    3664:      	movl	$0x4, %edx
    3669:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    366e:      	movl	$0x1, 0xa0(%rsp)
    3679:      	movq	(%rip), %rdi            # 0x3680 <generic_usdt_process_event+0x2ca0>
    3680:      	xorl	%ecx, %ecx
    3682:      	leaq	0x20(%rsp), %rsi
    3687:      	leaq	0xa0(%rsp), %rdx
    368f:      	movl	$0x2, %eax
    3694:      	xorl	%ecx, %ecx
    3696:      	callq	*%rax
    3698:      	movq	0x90(%rsp), %rax
    36a0:      	movl	$0xfffffffc, (%r15,%rax) # imm = 0xFFFFFFFC
    36a8:      	movl	$0x4, %edx
    36ad:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    36b2:      	movzbl	0x7(%rbp), %eax
    36b6:      	leal	0x8(,%rax,8), %eax
    36bd:      	jmp	0x38a9 <generic_usdt_process_event+0x2ec9>
    36c2:      	leaq	0x5e60(%rbp), %rax
    36c9:      	jmp	0x36db <generic_usdt_process_event+0x2cfb>
    36cb:      	leaq	0x5e68(%rbp), %rax
    36d2:      	jmp	0x36db <generic_usdt_process_event+0x2cfb>
    36d4:      	leaq	0x5e50(%rbp), %rax
    36db:      	movq	(%rax), %rax
    36de:      	movq	%rax, 0xa0(%rsp)
    36e6:      	leaq	0x38(%rsp), %rdi
    36eb:      	leaq	0xa0(%rsp), %rdx
    36f3:      	movl	$0x8, %ecx
    36f8:      	movl	$0x4, %eax
    36fd:      	movl	$0x8, %r15d
    3703:      	movl	$0x8, %esi
    3708:      	callq	*%rax
    370a:      	movq	0x38(%rsp), %r13
    370f:      	testb	$0x20, %bl
    3712:      	je	0x382b <generic_usdt_process_event+0x2e4b>
    3718:      	cmpq	$0x1000, %r13           # imm = 0x1000
    371f:      	jb	0x3800 <generic_usdt_process_event+0x2e20>
    3725:      	movl	$0x1, (%r12)
    372d:      	movl	$0x0, 0x80(%rsp)
    3738:      	movq	(%rip), %rdi            # 0x373f <generic_usdt_process_event+0x2d5f>
    373f:      	leaq	0x80(%rsp), %rsi
    3747:      	movl	$0x1, %eax
    374c:      	callq	*%rax
    374e:      	testq	%rax, %rax
    3751:      	je	0x37f6 <generic_usdt_process_event+0x2e16>
    3757:      	movq	%rax, %r15
    375a:      	movl	$0x18, (%rax)
    3760:      	movl	$0xe, %eax
    3765:      	callq	*%rax
    3767:      	movq	%r15, %rbp
    376a:      	addq	$0x10, %rbp
    376e:      	movq	%rax, 0x10(%r15)
    3772:      	cmpq	$-0x16, %rax
    3776:      	jne	0x37a0 <generic_usdt_process_event+0x2dc0>
    3778:      	movq	0x8(%rsp), %rax
    377d:      	leaq	0x20(%rax), %rdx
    3781:      	leaq	0x40(%rsp), %rdi
    3786:      	movl	$0x8, %ecx
    378b:      	movl	$0x4, %eax
    3790:      	movl	$0x8, %esi
    3795:      	callq	*%rax
    3797:      	movq	0x40(%rsp), %rax
    379c:      	movq	%rax, (%rbp)
    37a0:      	movl	$0x7d, %eax
    37a5:      	callq	*%rax
    37a7:      	movq	%rax, 0x18(%r15)
    37ab:      	movq	(%rbp), %rax
    37af:      	movq	0x8(%rbp), %rcx
    37b3:      	movq	%rax, 0x14(%r12)
    37b8:      	movq	%rcx, 0x1c(%r12)
    37bd:      	movq	0x8(%rsp), %rdi
    37c2:      	movq	%r15, %rsi
    37c5:      	movq	0x10(%rsp), %rdx
    37ca:      	movq	%r13, %rcx
    37cd:      	callq	0x37d2 <generic_usdt_process_event+0x2df2>
    37d2:      	testl	%eax, %eax
    37d4:      	js	0x3878 <generic_usdt_process_event+0x2e98>
    37da:      	movq	$0x0, 0x4(%r12)
    37e3:      	movl	%r13d, %edx
    37e6:      	subl	%eax, %edx
    37e8:      	xorl	%ecx, %ecx
    37ea:      	cmpq	$-0x1, %r13
    37ee:      	cmovnel	%edx, %ecx
    37f1:      	jmp	0x388a <generic_usdt_process_event+0x2eaa>
    37f6:      	movl	$0x4, %edx
    37fb:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    3800:      	addq	$0x90, %rbp
    3807:      	movl	$0x0, (%r12)
    380f:      	movq	0xa8(%rsp), %rax
    3817:      	leal	0x8(%rax), %r12d
    381b:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    3822:      	addq	%rbp, %r12
    3825:      	movl	$0xc, %r15d
    382b:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    3832:      	movl	$0xfff, %ebp            # imm = 0xFFF
    3837:      	cmovbq	%r13, %rbp
    383b:      	leaq	0x8(%r12), %rdi
    3840:      	movl	$0x4, %eax
    3845:      	movq	0x10(%rsp), %rdx
    384a:      	movl	%ebp, %esi
    384c:      	callq	*%rax
    384e:      	testl	%eax, %eax
    3850:      	js	0x3866 <generic_usdt_process_event+0x2e86>
    3852:      	movl	%r13d, (%r12)
    3856:      	movl	%ebp, 0x4(%r12)
    385b:      	movq	%r15, %rdx
    385e:      	addq	%rbp, %rdx
    3861:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    3866:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    386e:      	movl	$0x4, %edx
    3873:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    3878:      	movl	%eax, 0x4(%r12)
    387d:      	movl	$0x0, 0x8(%r12)
    3886:      	xorl	%ecx, %ecx
    3888:      	xorl	%eax, %eax
    388a:      	movl	%ecx, 0xc(%r12)
    388f:      	movl	%eax, 0x10(%r12)
    3894:      	movl	$0x24, %edx
    3899:      	jmp	0x3f70 <generic_usdt_process_event+0x3590>
    389e:      	movzbl	0x7(%rbp), %eax
    38a2:      	leal	0x8(,%rax,4), %eax
    38a9:      	movw	%ax, 0x2(%rbp)
    38ad:      	addw	(%rbp), %ax
    38b1:      	movw	%ax, (%rbp)
    38b5:      	movzbl	0x6(%rbp), %r15d
    38ba:      	cmpq	$0x3c, %r15
    38be:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    38c4:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    38ce:      	btq	%r15, %rcx
    38d2:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    38d8:      	movb	%r15b, 0x5(%rbp)
    38dc:      	movzwl	%ax, %ecx
    38df:      	movq	0x18(%rsp), %rsi
    38e4:      	addq	%rsi, %rcx
    38e7:      	movl	$0x2, %edx
    38ec:      	movl	$0x4, %eax
    38f1:      	movq	0x10(%rsp), %rdi
    38f6:      	movzwl	(%rbp), %edx
    38fa:      	addq	%rsi, %rdx
    38fd:      	movl	$0x2, %esi
    3902:      	callq	*%rax
    3904:      	testq	%rax, %rax
    3907:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    390d:      	movzbl	0x5(%rbp), %eax
    3911:      	cmpl	$0x32, %eax
    3914:      	jg	0x3930 <generic_usdt_process_event+0x2f50>
    3916:      	testl	%eax, %eax
    3918:      	je	0x394d <generic_usdt_process_event+0x2f6d>
    391a:      	cmpl	$0x2b, %eax
    391d:      	je	0x394d <generic_usdt_process_event+0x2f6d>
    391f:      	cmpl	$0x2c, %eax
    3922:      	jne	0x3978 <generic_usdt_process_event+0x2f98>
    3924:      	movw	$0x8, 0x2(%rbp)
    392a:      	movw	$0x8, %ax
    392e:      	jmp	0x397c <generic_usdt_process_event+0x2f9c>
    3930:      	cmpl	$0x33, %eax
    3933:      	je	0x3967 <generic_usdt_process_event+0x2f87>
    3935:      	cmpl	$0x3c, %eax
    3938:      	je	0x394d <generic_usdt_process_event+0x2f6d>
    393a:      	cmpl	$0xff, %eax
    393f:      	jne	0x3978 <generic_usdt_process_event+0x2f98>
    3941:      	movw	$0x28, 0x2(%rbp)
    3947:      	movw	$0x28, %ax
    394b:      	jmp	0x397c <generic_usdt_process_event+0x2f9c>
    394d:      	movzbl	0x7(%rbp), %eax
    3951:      	leal	0x8(,%rax,8), %eax
    3958:      	movw	%ax, 0x2(%rbp)
    395c:      	jmp	0x397c <generic_usdt_process_event+0x2f9c>
    395e:      	movzwl	0x2(%rbp), %eax
    3962:      	jmp	0x38ad <generic_usdt_process_event+0x2ecd>
    3967:      	movzbl	0x7(%rbp), %eax
    396b:      	leal	0x8(,%rax,4), %eax
    3972:      	movw	%ax, 0x2(%rbp)
    3976:      	jmp	0x397c <generic_usdt_process_event+0x2f9c>
    3978:      	movzwl	0x2(%rbp), %eax
    397c:      	addw	(%rbp), %ax
    3980:      	movw	%ax, (%rbp)
    3984:      	movzbl	0x6(%rbp), %r15d
    3989:      	cmpq	$0x3c, %r15
    398d:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    3993:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    399d:      	btq	%r15, %rcx
    39a1:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    39a7:      	movb	%r15b, 0x5(%rbp)
    39ab:      	movzwl	%ax, %ecx
    39ae:      	movq	0x18(%rsp), %rsi
    39b3:      	addq	%rsi, %rcx
    39b6:      	movl	$0x2, %edx
    39bb:      	movl	$0x4, %eax
    39c0:      	movq	0x10(%rsp), %rdi
    39c5:      	movzwl	(%rbp), %edx
    39c9:      	addq	%rsi, %rdx
    39cc:      	movl	$0x2, %esi
    39d1:      	callq	*%rax
    39d3:      	testq	%rax, %rax
    39d6:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    39dc:      	movzbl	0x5(%rbp), %eax
    39e0:      	cmpl	$0x32, %eax
    39e3:      	jg	0x39ff <generic_usdt_process_event+0x301f>
    39e5:      	testl	%eax, %eax
    39e7:      	je	0x3a1c <generic_usdt_process_event+0x303c>
    39e9:      	cmpl	$0x2b, %eax
    39ec:      	je	0x3a1c <generic_usdt_process_event+0x303c>
    39ee:      	cmpl	$0x2c, %eax
    39f1:      	jne	0x3a3e <generic_usdt_process_event+0x305e>
    39f3:      	movw	$0x8, 0x2(%rbp)
    39f9:      	movw	$0x8, %ax
    39fd:      	jmp	0x3a42 <generic_usdt_process_event+0x3062>
    39ff:      	cmpl	$0x33, %eax
    3a02:      	je	0x3a2d <generic_usdt_process_event+0x304d>
    3a04:      	cmpl	$0x3c, %eax
    3a07:      	je	0x3a1c <generic_usdt_process_event+0x303c>
    3a09:      	cmpl	$0xff, %eax
    3a0e:      	jne	0x3a3e <generic_usdt_process_event+0x305e>
    3a10:      	movw	$0x28, 0x2(%rbp)
    3a16:      	movw	$0x28, %ax
    3a1a:      	jmp	0x3a42 <generic_usdt_process_event+0x3062>
    3a1c:      	movzbl	0x7(%rbp), %eax
    3a20:      	leal	0x8(,%rax,8), %eax
    3a27:      	movw	%ax, 0x2(%rbp)
    3a2b:      	jmp	0x3a42 <generic_usdt_process_event+0x3062>
    3a2d:      	movzbl	0x7(%rbp), %eax
    3a31:      	leal	0x8(,%rax,4), %eax
    3a38:      	movw	%ax, 0x2(%rbp)
    3a3c:      	jmp	0x3a42 <generic_usdt_process_event+0x3062>
    3a3e:      	movzwl	0x2(%rbp), %eax
    3a42:      	addw	(%rbp), %ax
    3a46:      	movw	%ax, (%rbp)
    3a4a:      	movzbl	0x6(%rbp), %r15d
    3a4f:      	cmpq	$0x3c, %r15
    3a53:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    3a59:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3a63:      	btq	%r15, %rcx
    3a67:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    3a6d:      	movb	%r15b, 0x5(%rbp)
    3a71:      	movzwl	%ax, %ecx
    3a74:      	movq	0x18(%rsp), %rsi
    3a79:      	addq	%rsi, %rcx
    3a7c:      	movl	$0x2, %edx
    3a81:      	movl	$0x4, %eax
    3a86:      	movq	0x10(%rsp), %rdi
    3a8b:      	movzwl	(%rbp), %edx
    3a8f:      	addq	%rsi, %rdx
    3a92:      	movl	$0x2, %esi
    3a97:      	callq	*%rax
    3a99:      	testq	%rax, %rax
    3a9c:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    3aa2:      	movzbl	0x5(%rbp), %eax
    3aa6:      	cmpl	$0x32, %eax
    3aa9:      	jg	0x3ac5 <generic_usdt_process_event+0x30e5>
    3aab:      	testl	%eax, %eax
    3aad:      	je	0x3ae2 <generic_usdt_process_event+0x3102>
    3aaf:      	cmpl	$0x2b, %eax
    3ab2:      	je	0x3ae2 <generic_usdt_process_event+0x3102>
    3ab4:      	cmpl	$0x2c, %eax
    3ab7:      	jne	0x3b04 <generic_usdt_process_event+0x3124>
    3ab9:      	movw	$0x8, 0x2(%rbp)
    3abf:      	movw	$0x8, %ax
    3ac3:      	jmp	0x3b08 <generic_usdt_process_event+0x3128>
    3ac5:      	cmpl	$0x33, %eax
    3ac8:      	je	0x3af3 <generic_usdt_process_event+0x3113>
    3aca:      	cmpl	$0x3c, %eax
    3acd:      	je	0x3ae2 <generic_usdt_process_event+0x3102>
    3acf:      	cmpl	$0xff, %eax
    3ad4:      	jne	0x3b04 <generic_usdt_process_event+0x3124>
    3ad6:      	movw	$0x28, 0x2(%rbp)
    3adc:      	movw	$0x28, %ax
    3ae0:      	jmp	0x3b08 <generic_usdt_process_event+0x3128>
    3ae2:      	movzbl	0x7(%rbp), %eax
    3ae6:      	leal	0x8(,%rax,8), %eax
    3aed:      	movw	%ax, 0x2(%rbp)
    3af1:      	jmp	0x3b08 <generic_usdt_process_event+0x3128>
    3af3:      	movzbl	0x7(%rbp), %eax
    3af7:      	leal	0x8(,%rax,4), %eax
    3afe:      	movw	%ax, 0x2(%rbp)
    3b02:      	jmp	0x3b08 <generic_usdt_process_event+0x3128>
    3b04:      	movzwl	0x2(%rbp), %eax
    3b08:      	addw	(%rbp), %ax
    3b0c:      	movw	%ax, (%rbp)
    3b10:      	movzbl	0x6(%rbp), %r15d
    3b15:      	cmpq	$0x3c, %r15
    3b19:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    3b1f:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3b29:      	btq	%r15, %rcx
    3b2d:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    3b33:      	movb	%r15b, 0x5(%rbp)
    3b37:      	movzwl	%ax, %ecx
    3b3a:      	movq	0x18(%rsp), %rsi
    3b3f:      	addq	%rsi, %rcx
    3b42:      	movl	$0x2, %edx
    3b47:      	movl	$0x4, %eax
    3b4c:      	movq	0x10(%rsp), %rdi
    3b51:      	movzwl	(%rbp), %edx
    3b55:      	addq	%rsi, %rdx
    3b58:      	movl	$0x2, %esi
    3b5d:      	callq	*%rax
    3b5f:      	testq	%rax, %rax
    3b62:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    3b68:      	movzbl	0x5(%rbp), %eax
    3b6c:      	cmpl	$0x32, %eax
    3b6f:      	jg	0x3b8b <generic_usdt_process_event+0x31ab>
    3b71:      	testl	%eax, %eax
    3b73:      	je	0x3ba8 <generic_usdt_process_event+0x31c8>
    3b75:      	cmpl	$0x2b, %eax
    3b78:      	je	0x3ba8 <generic_usdt_process_event+0x31c8>
    3b7a:      	cmpl	$0x2c, %eax
    3b7d:      	jne	0x3bca <generic_usdt_process_event+0x31ea>
    3b7f:      	movw	$0x8, 0x2(%rbp)
    3b85:      	movw	$0x8, %ax
    3b89:      	jmp	0x3bce <generic_usdt_process_event+0x31ee>
    3b8b:      	cmpl	$0x33, %eax
    3b8e:      	je	0x3bb9 <generic_usdt_process_event+0x31d9>
    3b90:      	cmpl	$0x3c, %eax
    3b93:      	je	0x3ba8 <generic_usdt_process_event+0x31c8>
    3b95:      	cmpl	$0xff, %eax
    3b9a:      	jne	0x3bca <generic_usdt_process_event+0x31ea>
    3b9c:      	movw	$0x28, 0x2(%rbp)
    3ba2:      	movw	$0x28, %ax
    3ba6:      	jmp	0x3bce <generic_usdt_process_event+0x31ee>
    3ba8:      	movzbl	0x7(%rbp), %eax
    3bac:      	leal	0x8(,%rax,8), %eax
    3bb3:      	movw	%ax, 0x2(%rbp)
    3bb7:      	jmp	0x3bce <generic_usdt_process_event+0x31ee>
    3bb9:      	movzbl	0x7(%rbp), %eax
    3bbd:      	leal	0x8(,%rax,4), %eax
    3bc4:      	movw	%ax, 0x2(%rbp)
    3bc8:      	jmp	0x3bce <generic_usdt_process_event+0x31ee>
    3bca:      	movzwl	0x2(%rbp), %eax
    3bce:      	addw	(%rbp), %ax
    3bd2:      	movw	%ax, (%rbp)
    3bd6:      	movzbl	0x6(%rbp), %r15d
    3bdb:      	cmpq	$0x3c, %r15
    3bdf:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    3be5:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3bef:      	btq	%r15, %rcx
    3bf3:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    3bf9:      	movb	%r15b, 0x5(%rbp)
    3bfd:      	movzwl	%ax, %ecx
    3c00:      	movq	0x18(%rsp), %rsi
    3c05:      	addq	%rsi, %rcx
    3c08:      	movl	$0x2, %edx
    3c0d:      	movl	$0x4, %eax
    3c12:      	movq	0x10(%rsp), %rdi
    3c17:      	movzwl	(%rbp), %edx
    3c1b:      	addq	%rsi, %rdx
    3c1e:      	movl	$0x2, %esi
    3c23:      	callq	*%rax
    3c25:      	testq	%rax, %rax
    3c28:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    3c2e:      	movzbl	0x5(%rbp), %eax
    3c32:      	cmpl	$0x32, %eax
    3c35:      	jg	0x3c51 <generic_usdt_process_event+0x3271>
    3c37:      	testl	%eax, %eax
    3c39:      	je	0x3c6e <generic_usdt_process_event+0x328e>
    3c3b:      	cmpl	$0x2b, %eax
    3c3e:      	je	0x3c6e <generic_usdt_process_event+0x328e>
    3c40:      	cmpl	$0x2c, %eax
    3c43:      	jne	0x3c90 <generic_usdt_process_event+0x32b0>
    3c45:      	movw	$0x8, 0x2(%rbp)
    3c4b:      	movw	$0x8, %ax
    3c4f:      	jmp	0x3c94 <generic_usdt_process_event+0x32b4>
    3c51:      	cmpl	$0x33, %eax
    3c54:      	je	0x3c7f <generic_usdt_process_event+0x329f>
    3c56:      	cmpl	$0x3c, %eax
    3c59:      	je	0x3c6e <generic_usdt_process_event+0x328e>
    3c5b:      	cmpl	$0xff, %eax
    3c60:      	jne	0x3c90 <generic_usdt_process_event+0x32b0>
    3c62:      	movw	$0x28, 0x2(%rbp)
    3c68:      	movw	$0x28, %ax
    3c6c:      	jmp	0x3c94 <generic_usdt_process_event+0x32b4>
    3c6e:      	movzbl	0x7(%rbp), %eax
    3c72:      	leal	0x8(,%rax,8), %eax
    3c79:      	movw	%ax, 0x2(%rbp)
    3c7d:      	jmp	0x3c94 <generic_usdt_process_event+0x32b4>
    3c7f:      	movzbl	0x7(%rbp), %eax
    3c83:      	leal	0x8(,%rax,4), %eax
    3c8a:      	movw	%ax, 0x2(%rbp)
    3c8e:      	jmp	0x3c94 <generic_usdt_process_event+0x32b4>
    3c90:      	movzwl	0x2(%rbp), %eax
    3c94:      	addw	(%rbp), %ax
    3c98:      	movw	%ax, (%rbp)
    3c9c:      	movzbl	0x6(%rbp), %r15d
    3ca1:      	cmpq	$0x3c, %r15
    3ca5:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    3cab:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3cb5:      	btq	%r15, %rcx
    3cb9:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    3cbf:      	movb	%r15b, 0x5(%rbp)
    3cc3:      	movzwl	%ax, %ecx
    3cc6:      	movq	0x18(%rsp), %rsi
    3ccb:      	addq	%rsi, %rcx
    3cce:      	movl	$0x2, %edx
    3cd3:      	movl	$0x4, %eax
    3cd8:      	movq	0x10(%rsp), %rdi
    3cdd:      	movzwl	(%rbp), %edx
    3ce1:      	addq	%rsi, %rdx
    3ce4:      	movl	$0x2, %esi
    3ce9:      	callq	*%rax
    3ceb:      	testq	%rax, %rax
    3cee:      	js	0x3db1 <generic_usdt_process_event+0x33d1>
    3cf4:      	movzbl	0x5(%rbp), %eax
    3cf8:      	cmpl	$0x32, %eax
    3cfb:      	jg	0x3d17 <generic_usdt_process_event+0x3337>
    3cfd:      	testl	%eax, %eax
    3cff:      	je	0x3d34 <generic_usdt_process_event+0x3354>
    3d01:      	cmpl	$0x2b, %eax
    3d04:      	je	0x3d34 <generic_usdt_process_event+0x3354>
    3d06:      	cmpl	$0x2c, %eax
    3d09:      	jne	0x3d56 <generic_usdt_process_event+0x3376>
    3d0b:      	movw	$0x8, 0x2(%rbp)
    3d11:      	movw	$0x8, %ax
    3d15:      	jmp	0x3d5a <generic_usdt_process_event+0x337a>
    3d17:      	cmpl	$0x33, %eax
    3d1a:      	je	0x3d45 <generic_usdt_process_event+0x3365>
    3d1c:      	cmpl	$0x3c, %eax
    3d1f:      	je	0x3d34 <generic_usdt_process_event+0x3354>
    3d21:      	cmpl	$0xff, %eax
    3d26:      	jne	0x3d56 <generic_usdt_process_event+0x3376>
    3d28:      	movw	$0x28, 0x2(%rbp)
    3d2e:      	movw	$0x28, %ax
    3d32:      	jmp	0x3d5a <generic_usdt_process_event+0x337a>
    3d34:      	movzbl	0x7(%rbp), %eax
    3d38:      	leal	0x8(,%rax,8), %eax
    3d3f:      	movw	%ax, 0x2(%rbp)
    3d43:      	jmp	0x3d5a <generic_usdt_process_event+0x337a>
    3d45:      	movzbl	0x7(%rbp), %eax
    3d49:      	leal	0x8(,%rax,4), %eax
    3d50:      	movw	%ax, 0x2(%rbp)
    3d54:      	jmp	0x3d5a <generic_usdt_process_event+0x337a>
    3d56:      	movzwl	0x2(%rbp), %eax
    3d5a:      	addw	(%rbp), %ax
    3d5e:      	movw	%ax, (%rbp)
    3d62:      	movzbl	0x6(%rbp), %r15d
    3d67:      	cmpq	$0x3c, %r15
    3d6b:      	ja	0x3f7e <generic_usdt_process_event+0x359e>
    3d71:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3d7b:      	btq	%r15, %rcx
    3d7f:      	jae	0x3f7e <generic_usdt_process_event+0x359e>
    3d85:      	movb	%r15b, 0x5(%rbp)
    3d89:      	movzwl	%ax, %ecx
    3d8c:      	movq	0x18(%rsp), %rsi
    3d91:      	addq	%rsi, %rcx
    3d94:      	movl	$0x2, %edx
    3d99:      	movl	$0x4, %eax
    3d9e:      	movq	0x10(%rsp), %rdi
    3da3:      	movzwl	(%rbp), %edx
    3da7:      	addq	%rsi, %rdx
    3daa:      	movl	$0x2, %esi
    3daf:      	callq	*%rax
    3db1:      	xorl	%r15d, %r15d
    3db4:      	movb	%r15b, 0x98(%rsp)
    3dbc:      	movzbl	%r15b, %eax
    3dc0:      	movq	0x30(%rsp), %rbp
    3dc5:      	movw	%ax, 0x24(%rbp)
    3dc9:      	movw	$0xa, 0x26(%rbp)
    3dcf:      	leaq	0x8(%r13), %rdx
    3dd3:      	movl	$0x10, %ecx
    3dd8:      	movl	$0x4, %eax
    3ddd:      	movq	%rbp, %rdi
    3de0:      	movl	$0x10, %esi
    3de5:      	callq	*%rax
    3de7:      	leaq	0x10(%rbp), %rdi
    3deb:      	addq	$0x18, %r13
    3def:      	movl	$0x10, %ecx
    3df4:      	movl	$0x4, %eax
    3df9:      	movl	$0x10, %esi
    3dfe:      	movq	%r13, %rdx
    3e01:      	callq	*%rax
    3e03:      	cmpb	$0x11, %r15b
    3e07:      	je	0x3e5a <generic_usdt_process_event+0x347a>
    3e09:      	movzbl	%r15b, %eax
    3e0d:      	cmpl	$0x6, %eax
    3e10:      	jne	0x3ea5 <generic_usdt_process_event+0x34c5>
    3e16:      	movq	0x40(%rsp), %r15
    3e1b:      	movzwl	0xb8(%rsp), %r13d
    3e24:      	leaq	(%r15,%r13), %rdx
    3e28:      	movq	0x30(%rsp), %rbp
    3e2d:      	leaq	0x20(%rbp), %rdi
    3e31:      	movl	$0x2, %ecx
    3e36:      	movl	$0x4, %eax
    3e3b:      	movl	$0x2, %esi
    3e40:      	callq	*%rax
    3e42:      	leaq	0x22(%rbp), %rdi
    3e46:      	leaq	(%r15,%r13), %rdx
    3e4a:      	addq	$0x2, %rdx
    3e4e:      	movl	$0x2, %ecx
    3e53:      	movl	$0x4, %eax
    3e58:      	jmp	0x3e9c <generic_usdt_process_event+0x34bc>
    3e5a:      	movq	0x40(%rsp), %r15
    3e5f:      	movzwl	0xb8(%rsp), %r13d
    3e68:      	leaq	(%r15,%r13), %rdx
    3e6c:      	movq	0x30(%rsp), %rbp
    3e71:      	leaq	0x20(%rbp), %rdi
    3e75:      	movl	$0x2, %ecx
    3e7a:      	movl	$0x4, %eax
    3e7f:      	movl	$0x2, %esi
    3e84:      	callq	*%rax
    3e86:      	leaq	0x22(%rbp), %rdi
    3e8a:      	leaq	(%r15,%r13), %rdx
    3e8e:      	addq	$0x2, %rdx
    3e92:      	movl	$0x2, %ecx
    3e97:      	movl	$0x4, %eax
    3e9c:      	movl	$0x2, %esi
    3ea1:      	callq	*%rax
    3ea3:      	jmp	0x3eb1 <generic_usdt_process_event+0x34d1>
    3ea5:      	movq	0x30(%rsp), %rax
    3eaa:      	movl	$0x0, 0x20(%rax)
    3eb1:      	movq	0x30(%rsp), %rdx
    3eb6:      	movzwl	0x20(%rdx), %eax
    3eba:      	movzwl	0x22(%rdx), %ecx
    3ebe:      	movbew	%ax, 0x20(%rdx)
    3ec4:      	movbew	%cx, 0x22(%rdx)
    3eca:      	addq	$0xe0, %r12
    3ed1:      	leaq	0x80(%rsp), %rdi
    3ed9:      	movl	$0x8, %ecx
    3ede:      	movl	$0x4, %eax
    3ee3:      	movl	$0x4, %r15d
    3ee9:      	movl	$0x8, %esi
    3eee:      	movq	%r12, %rdx
    3ef1:      	callq	*%rax
    3ef3:      	movq	0x80(%rsp), %rcx
    3efb:      	testq	%rcx, %rcx
    3efe:      	je	0x3f6b <generic_usdt_process_event+0x358b>
    3f00:      	addq	$0x5, %rcx
    3f04:      	leaq	0x20(%rsp), %rdi
    3f09:      	movl	$0x8, %edx
    3f0e:      	movl	$0x4, %eax
    3f13:      	movq	0x80(%rsp), %rdx
    3f1b:      	addq	$0x5, %rdx
    3f1f:      	movl	$0x8, %esi
    3f24:      	callq	*%rax
    3f26:      	movq	0x80(%rsp), %r12
    3f2e:      	movq	0x20(%rsp), %r13
    3f33:      	movq	0x30(%rsp), %rbp
    3f38:      	leaq	0x38(%rbp), %rdi
    3f3c:      	leaq	(%r12,%r13,8), %rdx
    3f40:      	addq	$0x44, %rdx
    3f44:      	movl	$0x4, %eax
    3f49:      	movl	$0x4, %esi
    3f4e:      	callq	*%rax
    3f50:      	addq	$0x3c, %rbp
    3f54:      	leaq	(%r12,%r13,8), %rdx
    3f58:      	addq	$0x45, %rdx
    3f5c:      	movl	$0x4, %eax
    3f61:      	movq	%rbp, %rdi
    3f64:      	movl	$0x4, %esi
    3f69:      	callq	*%rax
    3f6b:      	movl	$0x40, %edx
    3f70:      	movq	(%rsp), %rcx
    3f74:      	movq	0x8(%rsp), %rbx
    3f79:      	jmp	0x2ecf <generic_usdt_process_event+0x24ef>
    3f7e:      	movw	%ax, 0xb8(%rsp)
    3f86:      	jmp	0x3db4 <generic_usdt_process_event+0x33d4>
    3f8b:      	nopl	(%rax,%rax)

0000000000003f90 <generic_usdt_process_filter>:
    3f90:      	pushq	%rbp
    3f91:      	pushq	%r15
    3f93:      	pushq	%r14
    3f95:      	pushq	%r13
    3f97:      	pushq	%r12
    3f99:      	pushq	%rbx
    3f9a:      	subq	$0xe8, %rsp
    3fa1:      	movq	%rdi, %rbx
    3fa4:      	movl	$0x0, 0xc8(%rsp)
    3faf:      	movq	(%rip), %rdi            # 0x3fb6 <generic_usdt_process_filter+0x26>
    3fb6:      	leaq	0xc8(%rsp), %rsi
    3fbe:      	movl	$0x1, %eax
    3fc3:      	callq	*%rax
    3fc5:      	testq	%rax, %rax
    3fc8:      	je	0x65b3 <generic_usdt_process_filter+0x2623>
    3fce:      	movq	%rax, %r14
    3fd1:      	movl	$0x23, %eax
    3fd6:      	callq	*%rax
    3fd8:      	movq	%rax, %rcx
    3fdb:      	movq	%rax, 0x60(%rsp)
    3fe0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3fe7:      	leaq	0x10(%rsp), %rdi
    3fec:      	movl	$0x4, %edx
    3ff1:      	movl	$0x71, %eax
    3ff6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3ffb:      	addq	0x60(%rsp), %rdx
    4000:      	movl	$0x4, %esi
    4005:      	callq	*%rax
    4007:      	movl	0x10(%rsp), %eax
    400b:      	movl	%eax, 0x40(%rsp)
    400f:      	movq	(%rip), %rdi            # 0x4016 <generic_usdt_process_filter+0x86>
    4016:      	leaq	0x40(%rsp), %rsi
    401b:      	movl	$0x1, %eax
    4020:      	callq	*%rax
    4022:      	testq	%rax, %rax
    4025:      	movq	%r14, 0x50(%rsp)
    402a:      	je	0x403a <generic_usdt_process_filter+0xaa>
    402c:      	movq	%rax, %r15
    402f:      	cmpq	$0x0, 0x8(%rax)
    4034:      	jne	0x4fbf <generic_usdt_process_filter+0x102f>
    403a:      	movl	$0xb00, %edx            # imm = 0xB00
    403f:      	movq	0x60(%rsp), %rcx
    4044:      	addq	%rdx, %rcx
    4047:      	leaq	0x60(%rsp), %rdi
    404c:      	movl	$0x8, %esi
    4051:      	movl	$0x71, %eax
    4056:      	addq	0x60(%rsp), %rdx
    405b:      	movl	$0x8, %esi
    4060:      	callq	*%rax
    4062:      	movq	0x60(%rsp), %rcx
    4067:      	testq	%rcx, %rcx
    406a:      	je	0x41ff <generic_usdt_process_filter+0x26f>
    4070:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4077:      	leaq	0x10(%rsp), %rdi
    407c:      	movl	$0x4, %edx
    4081:      	movl	$0x71, %eax
    4086:      	movl	$0xaf4, %edx            # imm = 0xAF4
    408b:      	addq	0x60(%rsp), %rdx
    4090:      	movl	$0x4, %esi
    4095:      	callq	*%rax
    4097:      	movl	0x10(%rsp), %eax
    409b:      	movl	%eax, 0x40(%rsp)
    409f:      	movq	(%rip), %rdi            # 0x40a6 <generic_usdt_process_filter+0x116>
    40a6:      	leaq	0x40(%rsp), %rsi
    40ab:      	movl	$0x1, %eax
    40b0:      	callq	*%rax
    40b2:      	testq	%rax, %rax
    40b5:      	je	0x40c5 <generic_usdt_process_filter+0x135>
    40b7:      	movq	%rax, %r15
    40ba:      	cmpq	$0x0, 0x8(%rax)
    40bf:      	jne	0x4fbf <generic_usdt_process_filter+0x102f>
    40c5:      	movl	$0xb00, %edx            # imm = 0xB00
    40ca:      	movq	0x60(%rsp), %rcx
    40cf:      	addq	%rdx, %rcx
    40d2:      	leaq	0x60(%rsp), %rdi
    40d7:      	movl	$0x8, %esi
    40dc:      	movl	$0x71, %eax
    40e1:      	addq	0x60(%rsp), %rdx
    40e6:      	movl	$0x8, %esi
    40eb:      	callq	*%rax
    40ed:      	movq	0x60(%rsp), %rcx
    40f2:      	testq	%rcx, %rcx
    40f5:      	je	0x41ff <generic_usdt_process_filter+0x26f>
    40fb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4102:      	leaq	0x10(%rsp), %rdi
    4107:      	movl	$0x4, %edx
    410c:      	movl	$0x71, %eax
    4111:      	movl	$0xaf4, %edx            # imm = 0xAF4
    4116:      	addq	0x60(%rsp), %rdx
    411b:      	movl	$0x4, %esi
    4120:      	callq	*%rax
    4122:      	movl	0x10(%rsp), %eax
    4126:      	movl	%eax, 0x40(%rsp)
    412a:      	movq	(%rip), %rdi            # 0x4131 <generic_usdt_process_filter+0x1a1>
    4131:      	leaq	0x40(%rsp), %rsi
    4136:      	movl	$0x1, %eax
    413b:      	callq	*%rax
    413d:      	testq	%rax, %rax
    4140:      	je	0x4150 <generic_usdt_process_filter+0x1c0>
    4142:      	movq	%rax, %r15
    4145:      	cmpq	$0x0, 0x8(%rax)
    414a:      	jne	0x4fbf <generic_usdt_process_filter+0x102f>
    4150:      	movl	$0xb00, %edx            # imm = 0xB00
    4155:      	movq	0x60(%rsp), %rcx
    415a:      	addq	%rdx, %rcx
    415d:      	leaq	0x60(%rsp), %rdi
    4162:      	movl	$0x8, %esi
    4167:      	movl	$0x71, %eax
    416c:      	addq	0x60(%rsp), %rdx
    4171:      	movl	$0x8, %esi
    4176:      	callq	*%rax
    4178:      	movq	0x60(%rsp), %rcx
    417d:      	testq	%rcx, %rcx
    4180:      	je	0x41ff <generic_usdt_process_filter+0x26f>
    4182:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4189:      	leaq	0x10(%rsp), %rdi
    418e:      	movl	$0x4, %edx
    4193:      	movl	$0x71, %eax
    4198:      	movl	$0xaf4, %edx            # imm = 0xAF4
    419d:      	addq	0x60(%rsp), %rdx
    41a2:      	movl	$0x4, %esi
    41a7:      	callq	*%rax
    41a9:      	movl	0x10(%rsp), %eax
    41ad:      	movl	%eax, 0x40(%rsp)
    41b1:      	movq	(%rip), %rdi            # 0x41b8 <generic_usdt_process_filter+0x228>
    41b8:      	leaq	0x40(%rsp), %rsi
    41bd:      	movl	$0x1, %eax
    41c2:      	callq	*%rax
    41c4:      	testq	%rax, %rax
    41c7:      	je	0x41d7 <generic_usdt_process_filter+0x247>
    41c9:      	movq	%rax, %r15
    41cc:      	cmpq	$0x0, 0x8(%rax)
    41d1:      	jne	0x4fbf <generic_usdt_process_filter+0x102f>
    41d7:      	movl	$0xb00, %edx            # imm = 0xB00
    41dc:      	movq	0x60(%rsp), %rcx
    41e1:      	addq	%rdx, %rcx
    41e4:      	leaq	0x60(%rsp), %rdi
    41e9:      	movl	$0x8, %esi
    41ee:      	movl	$0x71, %eax
    41f3:      	addq	0x60(%rsp), %rdx
    41f8:      	movl	$0x8, %esi
    41fd:      	callq	*%rax
    41ff:      	movq	%rbx, 0xb8(%rsp)
    4207:      	movl	$0x23, %eax
    420c:      	callq	*%rax
    420e:      	movq	%rax, %r13
    4211:      	leaq	0xaf4(%rax), %rdx
    4218:      	leaq	0x60(%rsp), %rdi
    421d:      	movl	$0x4, %ecx
    4222:      	movl	$0x4, %eax
    4227:      	movl	$0x4, %ebp
    422c:      	movl	$0x4, %esi
    4231:      	callq	*%rax
    4233:      	movl	0x60(%rsp), %eax
    4237:      	movl	%eax, 0x5f10(%r14)
    423e:      	movl	$0x7d, %eax
    4243:      	callq	*%rax
    4245:      	movq	%rax, 0x5f18(%r14)
    424c:      	movl	$0x0, 0x5f20(%r14)
    4257:      	movq	$0x0, 0x5f28(%r14)
    4262:      	movl	$0x0, 0x5f30(%r14)
    426d:      	leaq	0x60(%r13), %rdx
    4271:      	leaq	0x40(%rsp), %rdi
    4276:      	movl	$0x8, %ecx
    427b:      	movl	$0x71, %eax
    4280:      	movl	$0x8, %esi
    4285:      	callq	*%rax
    4287:      	movq	0x40(%rsp), %rcx
    428c:      	xorl	%ebx, %ebx
    428e:      	testq	%rcx, %rcx
    4291:      	je	0x4300 <generic_usdt_process_filter+0x370>
    4293:      	addq	$0x4, %rcx
    4297:      	leaq	0x10(%rsp), %rdi
    429c:      	movl	$0x4, %edx
    42a1:      	movl	$0x71, %eax
    42a6:      	movq	0x40(%rsp), %rdx
    42ab:      	addq	$0x4, %rdx
    42af:      	movl	$0x4, %esi
    42b4:      	callq	*%rax
    42b6:      	movl	0x10(%rsp), %eax
    42ba:      	testl	%eax, %eax
    42bc:      	je	0x4300 <generic_usdt_process_filter+0x370>
    42be:      	movq	0x40(%rsp), %rcx
    42c3:      	shll	$0x4, %eax
    42c6:      	addq	%rax, %rcx
    42c9:      	addq	$0x80, %rcx
    42d0:      	leaq	0x60(%rsp), %rdi
    42d5:      	movl	$0x10, %edx
    42da:      	movl	$0x71, %eax
    42df:      	movq	0x40(%rsp), %rcx
    42e4:      	movl	0x10(%rsp), %edx
    42e8:      	shll	$0x4, %edx
    42eb:      	addq	%rcx, %rdx
    42ee:      	addq	$0x80, %rdx
    42f5:      	movl	$0x10, %esi
    42fa:      	callq	*%rax
    42fc:      	movl	0x60(%rsp), %ebx
    4300:      	movl	%ebx, 0x5f34(%r14)
    4307:      	leaq	0xd00(%r13), %r15
    430e:      	leaq	0x60(%rsp), %rdi
    4313:      	movl	$0x8, %ecx
    4318:      	movl	$0x4, %eax
    431d:      	leaq	0x5f60(%r14), %rbx
    4324:      	movl	$0x8, %esi
    4329:      	movq	%r15, %rdx
    432c:      	callq	*%rax
    432e:      	movq	0x60(%rsp), %r12
    4333:      	leaq	0x5f68(%r14), %rdi
    433a:      	leaq	0x40(%r12), %rdx
    433f:      	movl	$0x8, %ecx
    4344:      	movl	$0x4, %eax
    4349:      	movl	$0x8, %esi
    434e:      	callq	*%rax
    4350:      	leaq	0x5f70(%r14), %rdi
    4357:      	leaq	0x30(%r12), %rdx
    435c:      	movl	$0x8, %ecx
    4361:      	movl	$0x4, %eax
    4366:      	movl	$0x8, %esi
    436b:      	callq	*%rax
    436d:      	addq	$0x38, %r12
    4371:      	movl	$0x8, %ecx
    4376:      	movl	$0x4, %eax
    437b:      	movq	%rbx, %rdi
    437e:      	movl	$0x8, %esi
    4383:      	movq	%r12, %rdx
    4386:      	callq	*%rax
    4388:      	leaq	0x5f38(%r14), %rbx
    438f:      	leaq	0xd70(%r13), %rdx
    4396:      	leaq	0x10(%rsp), %rdi
    439b:      	movl	$0x8, %ecx
    43a0:      	movl	$0x4, %eax
    43a5:      	movl	$0x8, %esi
    43aa:      	callq	*%rax
    43ac:      	movq	0x10(%rsp), %rcx
    43b1:      	leaq	0x60(%rsp), %rdi
    43b6:      	movl	$0x48, %edx
    43bb:      	movl	$0x4, %eax
    43c0:      	movq	0x10(%rsp), %rdx
    43c5:      	movl	$0x48, %esi
    43ca:      	callq	*%rax
    43cc:      	movl	$0x218, %edx            # imm = 0x218
    43d1:      	movq	0x68(%rsp), %rcx
    43d6:      	addq	%rdx, %rcx
    43d9:      	movl	$0x4, %eax
    43de:      	addq	0x68(%rsp), %rdx
    43e3:      	movq	%rbx, %rdi
    43e6:      	movl	$0x4, %esi
    43eb:      	callq	*%rax
    43ed:      	leaq	0x5f3c(%r14), %rdi
    43f4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    43f9:      	movq	0x70(%rsp), %rcx
    43fe:      	addq	%rdx, %rcx
    4401:      	movl	$0x4, %eax
    4406:      	addq	0x70(%rsp), %rdx
    440b:      	movl	$0x4, %esi
    4410:      	callq	*%rax
    4412:      	leaq	0x5f40(%r14), %rdi
    4419:      	movq	0x78(%rsp), %rcx
    441e:      	addq	$0x58, %rcx
    4422:      	movl	$0x4, %eax
    4427:      	movq	0x78(%rsp), %rdx
    442c:      	addq	$0x58, %rdx
    4430:      	movl	$0x4, %esi
    4435:      	callq	*%rax
    4437:      	movq	$0x0, 0x58(%rsp)
    4440:      	leaq	0xb58(%r13), %rdx
    4447:      	leaq	0x58(%rsp), %rdi
    444c:      	movl	$0x8, %ecx
    4451:      	movl	$0x4, %eax
    4456:      	movl	$0x8, %esi
    445b:      	callq	*%rax
    445d:      	movq	0x58(%rsp), %rcx
    4462:      	testq	%rcx, %rcx
    4465:      	je	0x4514 <generic_usdt_process_filter+0x584>
    446b:      	movl	$0x0, 0xa8(%rsp)
    4476:      	addq	$0x4, %rcx
    447a:      	leaq	0xa8(%rsp), %rdi
    4482:      	movl	$0x4, %edx
    4487:      	movl	$0x4, %eax
    448c:      	movq	0x58(%rsp), %rdx
    4491:      	addq	$0x4, %rdx
    4495:      	movl	$0x4, %esi
    449a:      	callq	*%rax
    449c:      	movq	0x58(%rsp), %rax
    44a1:      	movslq	0xa8(%rsp), %rcx
    44a9:      	shlq	$0x4, %rcx
    44ad:      	addq	%rax, %rcx
    44b0:      	addq	$0x80, %rcx
    44b7:      	leaq	0x40(%rsp), %rdi
    44bc:      	movl	$0x10, %edx
    44c1:      	movl	$0x4, %eax
    44c6:      	movq	0x58(%rsp), %rcx
    44cb:      	movslq	0xa8(%rsp), %rdx
    44d3:      	shlq	$0x4, %rdx
    44d7:      	addq	%rcx, %rdx
    44da:      	addq	$0x80, %rdx
    44e1:      	movl	$0x10, %esi
    44e6:      	callq	*%rax
    44e8:      	leaq	0x5f44(%r14), %rdi
    44ef:      	movl	$0x158, %edx            # imm = 0x158
    44f4:      	movq	0x48(%rsp), %rcx
    44f9:      	addq	%rdx, %rcx
    44fc:      	movl	$0x4, %esi
    4501:      	movl	$0x4, %eax
    4506:      	addq	0x48(%rsp), %rdx
    450b:      	movl	$0x4, %esi
    4510:      	callq	*%rax
    4512:      	jmp	0x451f <generic_usdt_process_filter+0x58f>
    4514:      	movl	$0x0, 0x5f44(%r14)
    451f:      	leaq	0x5f48(%r14), %rdi
    4526:      	movl	$0x158, %ebx            # imm = 0x158
    452b:      	movq	0x80(%rsp), %rcx
    4533:      	addq	%rbx, %rcx
    4536:      	movl	$0x4, %edx
    453b:      	movl	$0x4, %eax
    4540:      	movq	0x80(%rsp), %rdx
    4548:      	addq	%rbx, %rdx
    454b:      	movl	$0x4, %esi
    4550:      	callq	*%rax
    4552:      	leaq	0x5f4c(%r14), %rdi
    4559:      	movl	$0x118, %edx            # imm = 0x118
    455e:      	movq	0x88(%rsp), %rcx
    4566:      	addq	%rdx, %rcx
    4569:      	movl	$0x4, %esi
    456e:      	movl	$0x4, %eax
    4573:      	addq	0x88(%rsp), %rdx
    457b:      	movl	$0x4, %esi
    4580:      	callq	*%rax
    4582:      	leaq	0x5f50(%r14), %rdi
    4589:      	movl	$0x98, %r12d
    458f:      	movq	0x90(%rsp), %rcx
    4597:      	addq	%r12, %rcx
    459a:      	movl	$0x4, %edx
    459f:      	movl	$0x4, %eax
    45a4:      	movq	0x90(%rsp), %rdx
    45ac:      	addq	%r12, %rdx
    45af:      	movl	$0x4, %esi
    45b4:      	callq	*%rax
    45b6:      	leaq	0x5f54(%r14), %rdi
    45bd:      	movq	0x98(%rsp), %rcx
    45c5:      	addq	%r12, %rcx
    45c8:      	movl	$0x4, %edx
    45cd:      	movl	$0x4, %eax
    45d2:      	addq	0x98(%rsp), %r12
    45da:      	movl	$0x4, %esi
    45df:      	movq	%r12, %rdx
    45e2:      	callq	*%rax
    45e4:      	leaq	0x5f58(%r14), %rdi
    45eb:      	movq	0xa0(%rsp), %rcx
    45f3:      	addq	$0x58, %rcx
    45f7:      	movl	$0x4, %edx
    45fc:      	movl	$0x4, %eax
    4601:      	movq	0xa0(%rsp), %rdx
    4609:      	addq	$0x58, %rdx
    460d:      	movl	$0x4, %esi
    4612:      	callq	*%rax
    4614:      	movq	$0x0, 0x40(%rsp)
    461d:      	movq	$0x0, 0x58(%rsp)
    4626:      	leaq	0x40(%rsp), %rdi
    462b:      	movl	$0x8, %ecx
    4630:      	movl	$0x4, %eax
    4635:      	movl	$0x8, %esi
    463a:      	movq	%r15, %rdx
    463d:      	callq	*%rax
    463f:      	movl	$0x90, %edx
    4644:      	movq	0x40(%rsp), %rcx
    4649:      	addq	%rdx, %rcx
    464c:      	leaq	0x58(%rsp), %rdi
    4651:      	movl	$0x8, %esi
    4656:      	movl	$0x4, %eax
    465b:      	addq	0x40(%rsp), %rdx
    4660:      	movl	$0x8, %esi
    4665:      	callq	*%rax
    4667:      	leaq	0x5f5c(%r14), %rdi
    466e:      	movq	0x58(%rsp), %rcx
    4673:      	addq	%rbx, %rcx
    4676:      	movl	$0x4, %edx
    467b:      	movl	$0x4, %eax
    4680:      	addq	0x58(%rsp), %rbx
    4685:      	movl	$0x4, %esi
    468a:      	movq	%rbx, %rdx
    468d:      	callq	*%rax
    468f:      	cmpl	$0x1, 0x5f34(%r14)
    4697:      	jne	0x46a1 <generic_usdt_process_filter+0x711>
    4699:      	orb	$0x2, 0x5f33(%r14)
    46a1:      	leaq	0x5f78(%r14), %rdi
    46a8:      	movl	$0x308, %edx            # imm = 0x308
    46ad:      	movq	%rdi, 0x8(%rsp)
    46b2:      	xorl	%esi, %esi
    46b4:      	callq	0x46b9 <generic_usdt_process_filter+0x729>
    46b9:      	leaq	0x6290(%r14), %rbp
    46c0:      	addq	$0xa78, %r13            # imm = 0xA78
    46c7:      	leaq	0x40(%rsp), %rdi
    46cc:      	movl	$0x8, %ecx
    46d1:      	movl	$0x4, %eax
    46d6:      	movl	$0x8, %esi
    46db:      	movq	%r13, %rdx
    46de:      	callq	*%rax
    46e0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    46e5:      	movq	0x40(%rsp), %rcx
    46ea:      	addq	%rdx, %rcx
    46ed:      	leaq	0x60(%rsp), %rdi
    46f2:      	movl	$0x8, %esi
    46f7:      	movl	$0x4, %eax
    46fc:      	addq	0x40(%rsp), %rdx
    4701:      	movl	$0x8, %esi
    4706:      	callq	*%rax
    4708:      	movq	0x60(%rsp), %rbx
    470d:      	movl	$0x0, 0xcc(%rsp)
    4718:      	movq	(%rip), %rdi            # 0x471f <generic_usdt_process_filter+0x78f>
    471f:      	leaq	0xcc(%rsp), %rsi
    4727:      	movl	$0x1, %eax
    472c:      	callq	*%rax
    472e:      	testq	%rax, %rax
    4731:      	je	0x4e37 <generic_usdt_process_filter+0xea7>
    4737:      	movq	%rax, %r12
    473a:      	movq	%rbp, 0x38(%rsp)
    473f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    474a:      	leaq	0x1000(%rax), %r13
    4751:      	movl	$0x23, %eax
    4756:      	callq	*%rax
    4758:      	leaq	0xd50(%rax), %rdx
    475f:      	leaq	0xd8(%rsp), %rdi
    4767:      	movl	$0x8, %ecx
    476c:      	movl	$0x4, %eax
    4771:      	movl	$0x8, %esi
    4776:      	callq	*%rax
    4778:      	movq	0xd8(%rsp), %rbp
    4780:      	leaq	0x48(%rbx), %r15
    4784:      	leaq	0xe0(%rsp), %rdi
    478c:      	movl	$0x8, %ecx
    4791:      	movl	$0x4, %eax
    4796:      	movl	$0x8, %esi
    479b:      	movq	%r15, %rdx
    479e:      	callq	*%rax
    47a0:      	movq	0xe0(%rsp), %r14
    47a8:      	leaq	0x10(%r14), %rdx
    47ac:      	leaq	0x60(%rsp), %rdi
    47b1:      	movl	$0x8, %ecx
    47b6:      	movl	$0x4, %eax
    47bb:      	movl	$0x8, %esi
    47c0:      	callq	*%rax
    47c2:      	cmpq	$0x0, 0x60(%rsp)
    47c8:      	je	0x4a96 <generic_usdt_process_filter+0xb06>
    47ce:      	movq	0x50(%rsp), %r14
    47d3:      	movq	$0x0, 0x68(%rsp)
    47dc:      	movq	$0x0, 0x60(%rsp)
    47e5:      	movq	%r12, 0x70(%rsp)
    47ea:      	movq	$0x0, 0x78(%rsp)
    47f3:      	movq	$0x0, 0x80(%rsp)
    47ff:      	movq	$0x0, 0x88(%rsp)
    480b:      	movq	%r13, 0xc0(%rsp)
    4813:      	movq	%r13, 0x90(%rsp)
    481b:      	movl	0x6410(%r14), %eax
    4822:      	movl	%eax, 0x98(%rsp)
    4829:      	leaq	0x18(%rbp), %r13
    482d:      	movb	$0x0, 0x9c(%rsp)
    4835:      	addq	$0x20, %rbp
    4839:      	leaq	0x60(%rsp), %rdi
    483e:      	movl	$0x8, %ecx
    4843:      	movl	$0x4, %eax
    4848:      	addq	$0x40, %rbx
    484c:      	leaq	0x68(%rsp), %r12
    4851:      	leaq	0x78(%rsp), %r14
    4856:      	movl	$0x8, %esi
    485b:      	movq	%rbp, %rdx
    485e:      	callq	*%rax
    4860:      	movl	$0x8, %ecx
    4865:      	movl	$0x4, %eax
    486a:      	movq	%r12, %rdi
    486d:      	movl	$0x8, %esi
    4872:      	movq	%r13, %rdx
    4875:      	callq	*%rax
    4877:      	movl	$0x8, %ecx
    487c:      	movl	$0x4, %eax
    4881:      	movq	%r14, %rdi
    4884:      	movl	$0x8, %esi
    4889:      	movq	%r15, %rdx
    488c:      	callq	*%rax
    488e:      	movl	$0x8, %ecx
    4893:      	movl	$0x4, %eax
    4898:      	leaq	0x80(%rsp), %rdi
    48a0:      	movl	$0x8, %esi
    48a5:      	movq	%rbx, %rdx
    48a8:      	callq	*%rax
    48aa:      	movq	0x80(%rsp), %rax
    48b2:      	addq	$-0x20, %rax
    48b6:      	movq	%rax, 0x88(%rsp)
    48be:      	movq	(%rip), %rax            # 0x48c5 <generic_usdt_process_filter+0x935>
    48c5:      	cmpb	$0x0, (%rax)
    48c8:      	je	0x4aed <generic_usdt_process_filter+0xb5d>
    48ce:      	movl	$0x800, %r14d           # imm = 0x800
    48d4:      	movl	$0x8, %ebp
    48d9:      	leaq	0x10(%rsp), %rbx
    48de:      	nop
    48e0:      	movq	0x78(%rsp), %r15
    48e5:      	movq	0x80(%rsp), %rdx
    48ed:      	movq	0x88(%rsp), %r12
    48f5:      	cmpq	0x60(%rsp), %r15
    48fa:      	jne	0x4907 <generic_usdt_process_filter+0x977>
    48fc:      	cmpq	0x68(%rsp), %rdx
    4901:      	je	0x4caf <generic_usdt_process_filter+0xd1f>
    4907:      	movl	$0x4, %eax
    490c:      	leaq	0xa8(%rsp), %rdi
    4914:      	movl	$0x8, %esi
    4919:      	callq	*%rax
    491b:      	cmpq	0xa8(%rsp), %r15
    4923:      	je	0x4a30 <generic_usdt_process_filter+0xaa0>
    4929:      	leaq	0x18(%r15), %r13
    492d:      	movl	$0x4, %eax
    4932:      	movq	%rbx, %rdi
    4935:      	movl	$0x8, %esi
    493a:      	movq	%r13, %rdx
    493d:      	callq	*%rax
    493f:      	cmpq	%r15, 0x10(%rsp)
    4944:      	je	0x4a30 <generic_usdt_process_filter+0xaa0>
    494a:      	movl	$0x4, %eax
    494f:      	leaq	0x58(%rsp), %rdi
    4954:      	movl	$0x8, %esi
    4959:      	movq	%r13, %rdx
    495c:      	callq	*%rax
    495e:      	addq	$0x20, %r15
    4962:      	movl	$0x4, %eax
    4967:      	leaq	0x40(%rsp), %rdi
    496c:      	movl	$0x10, %ecx
    4971:      	movl	$0x10, %esi
    4976:      	movq	%r15, %rdx
    4979:      	callq	*%rax
    497b:      	movq	0x70(%rsp), %r15
    4980:      	movq	0x90(%rsp), %rax
    4988:      	movl	0x44(%rsp), %r12d
    498d:      	subq	%r15, %rax
    4990:      	movl	0x98(%rsp), %r13d
    4998:      	movl	%r12d, %edx
    499b:      	subl	%r13d, %edx
    499e:      	movl	$0x0, %ecx
    49a3:      	cmovbl	%ecx, %edx
    49a6:      	addq	0x48(%rsp), %rdx
    49ab:      	xorl	%esi, %esi
    49ad:      	cmpl	%r12d, %r13d
    49b0:      	seta	%sil
    49b4:      	movl	%r12d, %ecx
    49b7:      	cmovbl	%r13d, %ecx
    49bb:      	addl	%ecx, %esi
    49bd:      	movl	%r13d, %edi
    49c0:      	subl	%esi, %edi
    49c2:      	movl	%edi, 0x98(%rsp)
    49c9:      	subq	%rsi, %rax
    49cc:      	jb	0x4cb7 <generic_usdt_process_filter+0xd27>
    49d2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    49d8:      	ja	0x4cb7 <generic_usdt_process_filter+0xd27>
    49de:      	cmpl	%r12d, %r13d
    49e1:      	jbe	0x49e8 <generic_usdt_process_filter+0xa58>
    49e3:      	movb	$0x2f, (%r15,%rax)
    49e8:      	xorl	%edi, %edi
    49ea:      	cmpl	%r12d, %r13d
    49ed:      	seta	%dil
    49f1:      	movzbl	%cl, %esi
    49f4:      	addq	%rax, %r15
    49f7:      	addq	%r15, %rdi
    49fa:      	movl	$0x4, %eax
    49ff:      	callq	*%rax
    4a01:      	movq	%r15, 0x90(%rsp)
    4a09:      	cmpl	%r12d, %r13d
    4a0c:      	jbe	0x4cb7 <generic_usdt_process_filter+0xd27>
    4a12:      	movq	0x58(%rsp), %rax
    4a17:      	movq	%rax, 0x78(%rsp)
    4a1c:      	decl	%r14d
    4a1f:      	jne	0x48e0 <generic_usdt_process_filter+0x950>
    4a25:      	jmp	0x4cb7 <generic_usdt_process_filter+0xd27>
    4a2a:      	nopw	(%rax,%rax)
    4a30:      	leaq	0x10(%r12), %rdx
    4a35:      	movl	$0x4, %eax
    4a3a:      	movq	%rbx, %rdi
    4a3d:      	movl	$0x8, %esi
    4a42:      	callq	*%rax
    4a44:      	movq	0x88(%rsp), %rax
    4a4c:      	cmpq	0x10(%rsp), %rax
    4a51:      	je	0x4caf <generic_usdt_process_filter+0xd1f>
    4a57:      	addq	$0x18, %r12
    4a5b:      	movl	$0x4, %eax
    4a60:      	leaq	0x78(%rsp), %rdi
    4a65:      	movl	$0x8, %esi
    4a6a:      	movq	%r12, %rdx
    4a6d:      	callq	*%rax
    4a6f:      	movq	0x10(%rsp), %rax
    4a74:      	movq	%rax, 0x88(%rsp)
    4a7c:      	addq	$0x20, %rax
    4a80:      	movq	%rax, 0x80(%rsp)
    4a88:      	decl	%r14d
    4a8b:      	jne	0x48e0 <generic_usdt_process_filter+0x950>
    4a91:      	jmp	0x4cb7 <generic_usdt_process_filter+0xd27>
    4a96:      	leaq	0x18(%r14), %rdx
    4a9a:      	leaq	0x60(%rsp), %rdi
    4a9f:      	movl	$0x8, %ecx
    4aa4:      	movl	$0x4, %eax
    4aa9:      	movl	$0x8, %esi
    4aae:      	callq	*%rax
    4ab0:      	cmpq	%r14, 0x60(%rsp)
    4ab5:      	je	0x47ce <generic_usdt_process_filter+0x83e>
    4abb:      	movq	0x50(%rsp), %r14
    4ac0:      	movl	0x6410(%r14), %ecx
    4ac7:      	leal	-0xa(%rcx), %eax
    4aca:      	movl	%eax, 0x6410(%r14)
    4ad1:      	cmpl	$0x9, %ecx
    4ad4:      	jg	0x5474 <generic_usdt_process_filter+0x14e4>
    4ada:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    4ae5:      	movq	%r13, %rbx
    4ae8:      	jmp	0x4d38 <generic_usdt_process_filter+0xda8>
    4aed:      	movl	$0x800, %r14d           # imm = 0x800
    4af3:      	movl	$0x8, %ebp
    4af8:      	leaq	0x10(%rsp), %rbx
    4afd:      	nopl	(%rax)
    4b00:      	movq	0x78(%rsp), %r15
    4b05:      	movq	0x80(%rsp), %rdx
    4b0d:      	movq	0x88(%rsp), %r12
    4b15:      	cmpq	0x60(%rsp), %r15
    4b1a:      	jne	0x4b27 <generic_usdt_process_filter+0xb97>
    4b1c:      	cmpq	0x68(%rsp), %rdx
    4b21:      	je	0x4caf <generic_usdt_process_filter+0xd1f>
    4b27:      	movl	$0x4, %eax
    4b2c:      	leaq	0xa8(%rsp), %rdi
    4b34:      	movl	$0x8, %esi
    4b39:      	callq	*%rax
    4b3b:      	cmpq	0xa8(%rsp), %r15
    4b43:      	je	0x4c50 <generic_usdt_process_filter+0xcc0>
    4b49:      	leaq	0x18(%r15), %r13
    4b4d:      	movl	$0x4, %eax
    4b52:      	movq	%rbx, %rdi
    4b55:      	movl	$0x8, %esi
    4b5a:      	movq	%r13, %rdx
    4b5d:      	callq	*%rax
    4b5f:      	cmpq	%r15, 0x10(%rsp)
    4b64:      	je	0x4c50 <generic_usdt_process_filter+0xcc0>
    4b6a:      	movl	$0x4, %eax
    4b6f:      	leaq	0x58(%rsp), %rdi
    4b74:      	movl	$0x8, %esi
    4b79:      	movq	%r13, %rdx
    4b7c:      	callq	*%rax
    4b7e:      	addq	$0x20, %r15
    4b82:      	movl	$0x4, %eax
    4b87:      	leaq	0x40(%rsp), %rdi
    4b8c:      	movl	$0x10, %ecx
    4b91:      	movl	$0x10, %esi
    4b96:      	movq	%r15, %rdx
    4b99:      	callq	*%rax
    4b9b:      	movq	0x70(%rsp), %r15
    4ba0:      	movq	0x90(%rsp), %rax
    4ba8:      	movl	0x44(%rsp), %r12d
    4bad:      	subq	%r15, %rax
    4bb0:      	movl	0x98(%rsp), %r13d
    4bb8:      	movl	%r12d, %edx
    4bbb:      	subl	%r13d, %edx
    4bbe:      	movl	$0x0, %ecx
    4bc3:      	cmovbl	%ecx, %edx
    4bc6:      	addq	0x48(%rsp), %rdx
    4bcb:      	xorl	%esi, %esi
    4bcd:      	cmpl	%r12d, %r13d
    4bd0:      	seta	%sil
    4bd4:      	movl	%r12d, %ecx
    4bd7:      	cmovbl	%r13d, %ecx
    4bdb:      	addl	%ecx, %esi
    4bdd:      	movl	%r13d, %edi
    4be0:      	subl	%esi, %edi
    4be2:      	movl	%edi, 0x98(%rsp)
    4be9:      	subq	%rsi, %rax
    4bec:      	jb	0x4cb7 <generic_usdt_process_filter+0xd27>
    4bf2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4bf8:      	ja	0x4cb7 <generic_usdt_process_filter+0xd27>
    4bfe:      	cmpl	%r12d, %r13d
    4c01:      	jbe	0x4c08 <generic_usdt_process_filter+0xc78>
    4c03:      	movb	$0x2f, (%r15,%rax)
    4c08:      	xorl	%edi, %edi
    4c0a:      	cmpl	%r12d, %r13d
    4c0d:      	seta	%dil
    4c11:      	movzbl	%cl, %esi
    4c14:      	addq	%rax, %r15
    4c17:      	addq	%r15, %rdi
    4c1a:      	movl	$0x4, %eax
    4c1f:      	callq	*%rax
    4c21:      	movq	%r15, 0x90(%rsp)
    4c29:      	cmpl	%r12d, %r13d
    4c2c:      	jbe	0x4cb7 <generic_usdt_process_filter+0xd27>
    4c32:      	movq	0x58(%rsp), %rax
    4c37:      	movq	%rax, 0x78(%rsp)
    4c3c:      	decl	%r14d
    4c3f:      	jne	0x4b00 <generic_usdt_process_filter+0xb70>
    4c45:      	jmp	0x4cb7 <generic_usdt_process_filter+0xd27>
    4c47:      	nopw	(%rax,%rax)
    4c50:      	leaq	0x10(%r12), %rdx
    4c55:      	movl	$0x4, %eax
    4c5a:      	movq	%rbx, %rdi
    4c5d:      	movl	$0x8, %esi
    4c62:      	callq	*%rax
    4c64:      	movq	0x88(%rsp), %rax
    4c6c:      	cmpq	0x10(%rsp), %rax
    4c71:      	je	0x4caf <generic_usdt_process_filter+0xd1f>
    4c73:      	addq	$0x18, %r12
    4c77:      	movl	$0x4, %eax
    4c7c:      	leaq	0x78(%rsp), %rdi
    4c81:      	movl	$0x8, %esi
    4c86:      	movq	%r12, %rdx
    4c89:      	callq	*%rax
    4c8b:      	movq	0x10(%rsp), %rax
    4c90:      	movq	%rax, 0x88(%rsp)
    4c98:      	addq	$0x20, %rax
    4c9c:      	movq	%rax, 0x80(%rsp)
    4ca4:      	decl	%r14d
    4ca7:      	jne	0x4b00 <generic_usdt_process_filter+0xb70>
    4cad:      	jmp	0x4cb7 <generic_usdt_process_filter+0xd27>
    4caf:      	movb	$0x1, 0x9c(%rsp)
    4cb7:      	movq	0x90(%rsp), %rbx
    4cbf:      	movq	0xc0(%rsp), %rcx
    4cc7:      	cmpq	%rcx, %rbx
    4cca:      	je	0x4d18 <generic_usdt_process_filter+0xd88>
    4ccc:      	xorl	%ecx, %ecx
    4cce:      	cmpb	$0x0, 0x9c(%rsp)
    4cd6:      	sete	%cl
    4cd9:      	addl	%ecx, %ecx
    4cdb:      	movl	0x98(%rsp), %eax
    4ce2:      	movq	0x50(%rsp), %r14
    4ce7:      	movl	%eax, 0x6410(%r14)
    4cee:      	movl	%ecx, 0x6414(%r14)
    4cf5:      	testl	%eax, %eax
    4cf7:      	movq	0x38(%rsp), %rbp
    4cfc:      	jle	0x4d0e <generic_usdt_process_filter+0xd7e>
    4cfe:      	movl	$0x1000, %ecx           # imm = 0x1000
    4d03:      	subl	%eax, %ecx
    4d05:      	movl	%ecx, 0x6410(%r14)
    4d0c:      	movl	%ecx, %eax
    4d0e:      	testq	%rbx, %rbx
    4d11:      	jne	0x4d3d <generic_usdt_process_filter+0xdad>
    4d13:      	jmp	0x4e37 <generic_usdt_process_filter+0xea7>
    4d18:      	movq	0x50(%rsp), %r14
    4d1d:      	movl	$0x0, 0x6410(%r14)
    4d28:      	movl	$0x0, 0x6414(%r14)
    4d33:      	xorl	%eax, %eax
    4d35:      	movq	%rcx, %rbx
    4d38:      	movq	0x38(%rsp), %rbp
    4d3d:      	xorl	%ecx, %ecx
    4d3f:      	movq	%r14, %rdx
    4d42:      	movl	%eax, %r14d
    4d45:      	subl	$0x7f, %r14d
    4d49:      	movl	$0x7f, %r15d
    4d4f:      	cmovbl	%eax, %r15d
    4d53:      	cmovbl	%ecx, %r14d
    4d57:      	cmpl	$0xff, %eax
    4d5c:      	movl	$0xff, %ecx
    4d61:      	cmovbl	%eax, %ecx
    4d64:      	movzbl	%cl, %esi
    4d67:      	movl	%esi, 0x6410(%rdx)
    4d6d:      	movl	$0x4, %eax
    4d72:      	movq	%rbp, %rdi
    4d75:      	movq	%rbx, %rdx
    4d78:      	callq	*%rax
    4d7a:      	testq	%rax, %rax
    4d7d:      	je	0x4ddc <generic_usdt_process_filter+0xe4c>
    4d7f:      	negl	%eax
    4d81:      	movw	%ax, 0x60(%rsp)
    4d86:      	movw	$0x8, 0x62(%rsp)
    4d8d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4d97:      	movq	%rax, 0x64(%rsp)
    4d9c:      	movq	(%rip), %rdi            # 0x4da3 <generic_usdt_process_filter+0xe13>
    4da3:      	leaq	0x60(%rsp), %rsi
    4da8:      	movl	$0x1, %eax
    4dad:      	callq	*%rax
    4daf:      	testq	%rax, %rax
    4db2:      	je	0x4db8 <generic_usdt_process_filter+0xe28>
    4db4:      	incl	(%rax)
    4db6:      	jmp	0x4ddc <generic_usdt_process_filter+0xe4c>
    4db8:      	movl	$0x1, 0x40(%rsp)
    4dc0:      	movq	(%rip), %rdi            # 0x4dc7 <generic_usdt_process_filter+0xe37>
    4dc7:      	xorl	%ecx, %ecx
    4dc9:      	leaq	0x60(%rsp), %rsi
    4dce:      	leaq	0x40(%rsp), %rdx
    4dd3:      	movl	$0x2, %eax
    4dd8:      	xorl	%ecx, %ecx
    4dda:      	callq	*%rax
    4ddc:      	movq	0x50(%rsp), %rax
    4de1:      	leaq	0x6390(%rax), %rdi
    4de8:      	addq	%r14, %rbx
    4deb:      	movq	%rax, %r14
    4dee:      	movl	$0x4, %eax
    4df3:      	movl	%r15d, %esi
    4df6:      	movq	%rbx, %rdx
    4df9:      	callq	*%rax
    4dfb:      	testq	%rax, %rax
    4dfe:      	je	0x4e37 <generic_usdt_process_filter+0xea7>
    4e00:      	negl	%eax
    4e02:      	movw	%ax, 0x60(%rsp)
    4e07:      	movw	$0x8, 0x62(%rsp)
    4e0e:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4e18:      	movq	%rax, 0x64(%rsp)
    4e1d:      	movq	(%rip), %rdi            # 0x4e24 <generic_usdt_process_filter+0xe94>
    4e24:      	leaq	0x60(%rsp), %rsi
    4e29:      	movl	$0x1, %eax
    4e2e:      	callq	*%rax
    4e30:      	testq	%rax, %rax
    4e33:      	je	0x4e64 <generic_usdt_process_filter+0xed4>
    4e35:      	incl	(%rax)
    4e37:      	movl	0x6410(%r14), %eax
    4e3e:      	leal	-0x101(%rax), %ecx
    4e44:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4e4a:      	ja	0x4e9d <generic_usdt_process_filter+0xf0d>
    4e4c:      	movq	0x8(%rsp), %rax
    4e51:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4e57:      	movq	0xb8(%rsp), %rbx
    4e5f:      	jmp	0x4fb3 <generic_usdt_process_filter+0x1023>
    4e64:      	movl	$0x1, 0x40(%rsp)
    4e6c:      	movq	(%rip), %rdi            # 0x4e73 <generic_usdt_process_filter+0xee3>
    4e73:      	xorl	%ecx, %ecx
    4e75:      	leaq	0x60(%rsp), %rsi
    4e7a:      	leaq	0x40(%rsp), %rdx
    4e7f:      	movl	$0x2, %eax
    4e84:      	xorl	%ecx, %ecx
    4e86:      	callq	*%rax
    4e88:      	movl	0x6410(%r14), %eax
    4e8f:      	leal	-0x101(%rax), %ecx
    4e95:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4e9b:      	jbe	0x4e4c <generic_usdt_process_filter+0xebc>
    4e9d:      	movzbl	%al, %ebx
    4ea0:      	leaq	0x5f80(%r14), %rdi
    4ea7:      	movl	$0x4, %eax
    4eac:      	movl	%ebx, %esi
    4eae:      	movq	%rbp, %rdx
    4eb1:      	callq	*%rax
    4eb3:      	movq	%rax, %r15
    4eb6:      	testq	%rax, %rax
    4eb9:      	je	0x4f1b <generic_usdt_process_filter+0xf8b>
    4ebb:      	movl	%r15d, %eax
    4ebe:      	negl	%eax
    4ec0:      	movw	%ax, 0x60(%rsp)
    4ec5:      	movw	$0xf, 0x62(%rsp)
    4ecc:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4ed6:      	movq	%rax, 0x64(%rsp)
    4edb:      	movq	(%rip), %rdi            # 0x4ee2 <generic_usdt_process_filter+0xf52>
    4ee2:      	leaq	0x60(%rsp), %rsi
    4ee7:      	movl	$0x1, %eax
    4eec:      	callq	*%rax
    4eee:      	testq	%rax, %rax
    4ef1:      	je	0x4ef7 <generic_usdt_process_filter+0xf67>
    4ef3:      	incl	(%rax)
    4ef5:      	jmp	0x4f1b <generic_usdt_process_filter+0xf8b>
    4ef7:      	movl	$0x1, 0x40(%rsp)
    4eff:      	movq	(%rip), %rdi            # 0x4f06 <generic_usdt_process_filter+0xf76>
    4f06:      	xorl	%ecx, %ecx
    4f08:      	leaq	0x60(%rsp), %rsi
    4f0d:      	leaq	0x40(%rsp), %rdx
    4f12:      	movl	$0x2, %eax
    4f17:      	xorl	%ecx, %ecx
    4f19:      	callq	*%rax
    4f1b:      	testl	%r15d, %r15d
    4f1e:      	cmovel	%ebx, %r15d
    4f22:      	movl	%r15d, 0x5f78(%r14)
    4f29:      	cmpl	$0x7f, %ebx
    4f2c:      	movl	$0x7f, %esi
    4f31:      	cmovbl	%ebx, %esi
    4f34:      	leaq	0x6080(%r14), %rdi
    4f3b:      	leaq	0x6390(%r14), %rdx
    4f42:      	movl	$0x4, %eax
    4f47:      	callq	*%rax
    4f49:      	testq	%rax, %rax
    4f4c:      	movq	0xb8(%rsp), %rbx
    4f54:      	je	0x4fb3 <generic_usdt_process_filter+0x1023>
    4f56:      	negl	%eax
    4f58:      	movw	%ax, 0x60(%rsp)
    4f5d:      	movw	$0xf, 0x62(%rsp)
    4f64:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    4f6e:      	movq	%rax, 0x64(%rsp)
    4f73:      	movq	(%rip), %rdi            # 0x4f7a <generic_usdt_process_filter+0xfea>
    4f7a:      	leaq	0x60(%rsp), %rsi
    4f7f:      	movl	$0x1, %eax
    4f84:      	callq	*%rax
    4f86:      	testq	%rax, %rax
    4f89:      	je	0x4f8f <generic_usdt_process_filter+0xfff>
    4f8b:      	incl	(%rax)
    4f8d:      	jmp	0x4fb3 <generic_usdt_process_filter+0x1023>
    4f8f:      	movl	$0x1, 0x40(%rsp)
    4f97:      	movq	(%rip), %rdi            # 0x4f9e <generic_usdt_process_filter+0x100e>
    4f9e:      	xorl	%ecx, %ecx
    4fa0:      	leaq	0x60(%rsp), %rsi
    4fa5:      	leaq	0x40(%rsp), %rdx
    4faa:      	movl	$0x2, %eax
    4faf:      	xorl	%ecx, %ecx
    4fb1:      	callq	*%rax
    4fb3:      	leaq	0x5f10(%r14), %r15
    4fba:      	orb	$0x10, 0x1(%r14)
    4fbf:      	leaq	0x5ef8(%r14), %rsi
    4fc6:      	movq	(%rip), %rdi            # 0x4fcd <generic_usdt_process_filter+0x103d>
    4fcd:      	movl	$0x1, %eax
    4fd2:      	callq	*%rax
    4fd4:      	testq	%rax, %rax
    4fd7:      	je	0x65b3 <generic_usdt_process_filter+0x2623>
    4fdd:      	movq	0x5eb8(%r14), %r13
    4fe4:      	cmpq	$0x6, %r13
    4fe8:      	jae	0x5216 <generic_usdt_process_filter+0x1286>
    4fee:      	movslq	(%rax), %rcx
    4ff1:      	testq	%rcx, %rcx
    4ff4:      	je	0x5238 <generic_usdt_process_filter+0x12a8>
    4ffa:      	cmpq	%rcx, %r13
    4ffd:      	jae	0x5216 <generic_usdt_process_filter+0x1286>
    5003:      	movq	%rax, 0x8(%rsp)
    5008:      	movq	%rcx, 0xc0(%rsp)
    5010:      	movq	%rbx, 0xb8(%rsp)
    5018:      	movl	%r13d, 0x10(%rsp)
    501d:      	movl	$0x0, 0x58(%rsp)
    5025:      	movq	(%rip), %rdi            # 0x502c <generic_usdt_process_filter+0x109c>
    502c:      	leaq	0x10(%rsp), %rsi
    5031:      	movl	$0x1, %eax
    5036:      	callq	*%rax
    5038:      	testq	%rax, %rax
    503b:      	movq	%r15, 0x38(%rsp)
    5040:      	je	0x5254 <generic_usdt_process_filter+0x12c4>
    5046:      	movq	%rax, %rbx
    5049:      	movl	(%rax), %eax
    504b:      	testl	%eax, %eax
    504d:      	je	0x5254 <generic_usdt_process_filter+0x12c4>
    5053:      	cmpl	$0x0, 0x68(%r15)
    5058:      	js	0x655b <generic_usdt_process_filter+0x25cb>
    505e:      	cmpl	$0x1b, %eax
    5061:      	ja	0x655b <generic_usdt_process_filter+0x25cb>
    5067:      	movl	$0x60, %ecx
    506c:      	btl	%eax, %ecx
    506f:      	jb	0x5cec <generic_usdt_process_filter+0x1d5c>
    5075:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    507a:      	btl	%eax, %ecx
    507d:      	jb	0x5c59 <generic_usdt_process_filter+0x1cc9>
    5083:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5088:      	btl	%eax, %ecx
    508b:      	jae	0x655b <generic_usdt_process_filter+0x25cb>
    5091:      	movq	%rbx, %rsi
    5094:      	addq	$0x4, %rsi
    5098:      	movq	(%rip), %rdi            # 0x509f <generic_usdt_process_filter+0x110f>
    509f:      	movl	$0x1, %eax
    50a4:      	callq	*%rax
    50a6:      	testq	%rax, %rax
    50a9:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    50af:      	movq	%rax, %r12
    50b2:      	movq	0x38(%rsp), %rax
    50b7:      	movl	0x68(%rax), %eax
    50ba:      	cmpl	$0x7f, %eax
    50bd:      	movl	$0x7f, %r14d
    50c3:      	cmovll	%eax, %r14d
    50c7:      	movq	(%rip), %rdi            # 0x50ce <generic_usdt_process_filter+0x113e>
    50ce:      	leaq	0x58(%rsp), %rsi
    50d3:      	movl	$0x1, %eax
    50d8:      	callq	*%rax
    50da:      	testq	%rax, %rax
    50dd:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    50e3:      	movq	%rax, %rbp
    50e6:      	leal	(,%r14,8), %eax
    50ee:      	movl	%eax, (%rbp)
    50f1:      	movq	0x38(%rsp), %rax
    50f6:      	cmpl	$0x0, 0x6c(%rax)
    50fa:      	jne	0x51dd <generic_usdt_process_filter+0x124d>
    5100:      	movq	0x38(%rsp), %r15
    5105:      	movl	0x68(%r15), %ecx
    5109:      	movl	%ecx, %eax
    510b:      	subl	%r14d, %eax
    510e:      	movl	%r14d, %edx
    5111:      	andl	$0x7f, %edx
    5114:      	addl	%edx, %eax
    5116:      	addl	%ecx, %edx
    5118:      	movl	%r14d, %ecx
    511b:      	notl	%ecx
    511d:      	addl	%edx, %ecx
    511f:      	subl	%r14d, %edx
    5122:      	leal	-0x4(%rdx), %esi
    5125:      	leaq	0x1f3(%r15), %rdi
    512c:      	leal	-0x3(%rdx), %r8d
    5130:      	addl	$-0x2, %edx
    5133:      	movq	$-0x3, %r9
    513a:      	leal	(%rcx,%r9), %r10d
    513e:      	addl	$0x3, %r10d
    5142:      	andl	$0x7f, %r10d
    5146:      	movzbl	0x170(%r15,%r10), %r10d
    514f:      	movb	%r10b, -0x3(%rdi)
    5153:      	leaq	(%rax,%r9), %r10
    5157:      	cmpq	$-0x2, %r10
    515b:      	je	0x51d5 <generic_usdt_process_filter+0x1245>
    515d:      	leal	(%rdx,%r9), %r11d
    5161:      	addl	$0x3, %r11d
    5165:      	andl	$0x7f, %r11d
    5169:      	movzbl	0x170(%r15,%r11), %r11d
    5172:      	movb	%r11b, -0x2(%rdi)
    5176:      	cmpq	$-0x1, %r10
    517a:      	je	0x51d5 <generic_usdt_process_filter+0x1245>
    517c:      	leal	(%r8,%r9), %r10d
    5180:      	addl	$0x3, %r10d
    5184:      	andl	$0x7f, %r10d
    5188:      	movzbl	0x170(%r15,%r10), %r10d
    5191:      	movb	%r10b, -0x1(%rdi)
    5195:      	movq	%rax, %r10
    5198:      	addq	%r9, %r10
    519b:      	je	0x51d5 <generic_usdt_process_filter+0x1245>
    519d:      	cmpq	$-0x7f, %r9
    51a1:      	je	0x51d5 <generic_usdt_process_filter+0x1245>
    51a3:      	leal	(%rsi,%r9), %r10d
    51a7:      	addl	$0x3, %r10d
    51ab:      	andl	$0x7f, %r10d
    51af:      	movzbl	0x170(%r15,%r10), %r10d
    51b8:      	movb	%r10b, (%rdi)
    51bb:      	addq	$0x4, %rdi
    51bf:      	leaq	(%rax,%r9), %r10
    51c3:      	addq	$-0x4, %r10
    51c7:      	addq	$-0x4, %r9
    51cb:      	cmpq	$-0x3, %r10
    51cf:      	jne	0x513a <generic_usdt_process_filter+0x11aa>
    51d5:      	movl	$0x1, 0x6c(%r15)
    51dd:      	cmpl	$0x7f, %r14d
    51e1:      	ja	0x5209 <generic_usdt_process_filter+0x1279>
    51e3:      	movslq	%r14d, %rsi
    51e6:      	movq	%rbp, %rdi
    51e9:      	addq	$0x4, %rdi
    51ed:      	movq	0x38(%rsp), %rax
    51f2:      	leaq	0x1f0(%rax), %rdx
    51f9:      	movl	$0x4, %eax
    51fe:      	callq	*%rax
    5200:      	testq	%rax, %rax
    5203:      	js	0x655b <generic_usdt_process_filter+0x25cb>
    5209:      	movl	$0x1, %eax
    520e:      	movq	%r12, %rdi
    5211:      	jmp	0x5ce4 <generic_usdt_process_filter+0x1d54>
    5216:      	movl	(%r15), %eax
    5219:      	movl	%eax, 0x10(%r14)
    521d:      	movq	0x8(%r15), %rax
    5221:      	movq	%rax, 0x18(%r14)
    5225:      	cmpb	$0x0, 0x5ec0(%r14)
    522d:      	jne	0x659e <generic_usdt_process_filter+0x260e>
    5233:      	jmp	0x65b3 <generic_usdt_process_filter+0x2623>
    5238:      	movb	$0x1, 0x5ec0(%r14)
    5240:      	movl	(%r15), %eax
    5243:      	movl	%eax, 0x10(%r14)
    5247:      	movq	0x8(%r15), %rax
    524b:      	movq	%rax, 0x18(%r14)
    524f:      	jmp	0x659e <generic_usdt_process_filter+0x260e>
    5254:      	movq	0x8(%rsp), %r10
    5259:      	movq	(%rip), %rax            # 0x5260 <generic_usdt_process_filter+0x12d0>
    5260:      	cmpb	$0x0, (%rax)
    5263:      	je	0x54a5 <generic_usdt_process_filter+0x1515>
    5269:      	movq	(%rip), %rdi            # 0x5270 <generic_usdt_process_filter+0x12e0>
    5270:      	movl	$0x1, %eax
    5275:      	movq	0x38(%rsp), %rsi
    527a:      	callq	*%rax
    527c:      	movq	0x8(%rsp), %r10
    5281:      	testq	%rax, %rax
    5284:      	je	0x54a5 <generic_usdt_process_filter+0x1515>
    528a:      	movq	%rax, %rbp
    528d:      	leal	0x5(%r13), %eax
    5291:      	movl	%eax, 0x10(%rsp)
    5295:      	movl	$0x0, 0x58(%rsp)
    529d:      	movq	(%rip), %rdi            # 0x52a4 <generic_usdt_process_filter+0x1314>
    52a4:      	leaq	0x10(%rsp), %rsi
    52a9:      	movl	$0x1, %eax
    52ae:      	callq	*%rax
    52b0:      	testq	%rax, %rax
    52b3:      	je	0x54a0 <generic_usdt_process_filter+0x1510>
    52b9:      	movq	%rax, %r12
    52bc:      	movl	(%rax), %eax
    52be:      	testl	%eax, %eax
    52c0:      	je	0x54a0 <generic_usdt_process_filter+0x1510>
    52c6:      	cmpl	$0x0, (%rbp)
    52ca:      	js	0x655b <generic_usdt_process_filter+0x25cb>
    52d0:      	cmpl	$0x1b, %eax
    52d3:      	ja	0x655b <generic_usdt_process_filter+0x25cb>
    52d9:      	movl	$0x60, %ecx
    52de:      	btl	%eax, %ecx
    52e1:      	jb	0x5f48 <generic_usdt_process_filter+0x1fb8>
    52e7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    52ec:      	btl	%eax, %ecx
    52ef:      	jb	0x5eb8 <generic_usdt_process_filter+0x1f28>
    52f5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    52fa:      	btl	%eax, %ecx
    52fd:      	jae	0x655b <generic_usdt_process_filter+0x25cb>
    5303:      	movq	%r12, %rsi
    5306:      	addq	$0x4, %rsi
    530a:      	movq	(%rip), %rdi            # 0x5311 <generic_usdt_process_filter+0x1381>
    5311:      	movl	$0x1, %eax
    5316:      	callq	*%rax
    5318:      	testq	%rax, %rax
    531b:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5321:      	movq	%rax, %r15
    5324:      	movl	(%rbp), %eax
    5327:      	cmpl	$0x7f, %eax
    532a:      	movl	$0x7f, %r14d
    5330:      	cmovll	%eax, %r14d
    5334:      	movq	(%rip), %rdi            # 0x533b <generic_usdt_process_filter+0x13ab>
    533b:      	leaq	0x58(%rsp), %rsi
    5340:      	movl	$0x1, %eax
    5345:      	callq	*%rax
    5347:      	testq	%rax, %rax
    534a:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5350:      	movq	%rax, %rbx
    5353:      	leal	(,%r14,8), %eax
    535b:      	movl	%eax, (%rbx)
    535d:      	cmpl	$0x0, 0x4(%rbp)
    5361:      	jne	0x543d <generic_usdt_process_filter+0x14ad>
    5367:      	movl	(%rbp), %ecx
    536a:      	movl	%ecx, %eax
    536c:      	subl	%r14d, %eax
    536f:      	movl	%r14d, %edx
    5372:      	andl	$0x7f, %edx
    5375:      	addl	%edx, %eax
    5377:      	addl	%ecx, %edx
    5379:      	movl	%r14d, %ecx
    537c:      	notl	%ecx
    537e:      	addl	%edx, %ecx
    5380:      	subl	%r14d, %edx
    5383:      	leal	-0x4(%rdx), %esi
    5386:      	leaq	0x18b(%rbp), %rdi
    538d:      	leal	-0x3(%rdx), %r8d
    5391:      	addl	$-0x2, %edx
    5394:      	movq	$-0x3, %r9
    539b:      	leal	(%rcx,%r9), %r10d
    539f:      	addl	$0x3, %r10d
    53a3:      	andl	$0x7f, %r10d
    53a7:      	movzbl	0x108(%rbp,%r10), %r10d
    53b0:      	movb	%r10b, -0x3(%rdi)
    53b4:      	leaq	(%rax,%r9), %r10
    53b8:      	cmpq	$-0x2, %r10
    53bc:      	je	0x5436 <generic_usdt_process_filter+0x14a6>
    53be:      	leal	(%rdx,%r9), %r11d
    53c2:      	addl	$0x3, %r11d
    53c6:      	andl	$0x7f, %r11d
    53ca:      	movzbl	0x108(%rbp,%r11), %r11d
    53d3:      	movb	%r11b, -0x2(%rdi)
    53d7:      	cmpq	$-0x1, %r10
    53db:      	je	0x5436 <generic_usdt_process_filter+0x14a6>
    53dd:      	leal	(%r8,%r9), %r10d
    53e1:      	addl	$0x3, %r10d
    53e5:      	andl	$0x7f, %r10d
    53e9:      	movzbl	0x108(%rbp,%r10), %r10d
    53f2:      	movb	%r10b, -0x1(%rdi)
    53f6:      	movq	%rax, %r10
    53f9:      	addq	%r9, %r10
    53fc:      	je	0x5436 <generic_usdt_process_filter+0x14a6>
    53fe:      	cmpq	$-0x7f, %r9
    5402:      	je	0x5436 <generic_usdt_process_filter+0x14a6>
    5404:      	leal	(%rsi,%r9), %r10d
    5408:      	addl	$0x3, %r10d
    540c:      	andl	$0x7f, %r10d
    5410:      	movzbl	0x108(%rbp,%r10), %r10d
    5419:      	movb	%r10b, (%rdi)
    541c:      	addq	$0x4, %rdi
    5420:      	leaq	(%rax,%r9), %r10
    5424:      	addq	$-0x4, %r10
    5428:      	addq	$-0x4, %r9
    542c:      	cmpq	$-0x3, %r10
    5430:      	jne	0x539b <generic_usdt_process_filter+0x140b>
    5436:      	movl	$0x1, 0x4(%rbp)
    543d:      	cmpl	$0x7f, %r14d
    5441:      	ja	0x5467 <generic_usdt_process_filter+0x14d7>
    5443:      	movslq	%r14d, %rsi
    5446:      	movq	%rbx, %rdi
    5449:      	addq	$0x4, %rdi
    544d:      	addq	$0x188, %rbp            # imm = 0x188
    5454:      	movl	$0x4, %eax
    5459:      	movq	%rbp, %rdx
    545c:      	callq	*%rax
    545e:      	testq	%rax, %rax
    5461:      	js	0x655b <generic_usdt_process_filter+0x25cb>
    5467:      	movl	$0x1, %eax
    546c:      	movq	%r15, %rdi
    546f:      	jmp	0x5f40 <generic_usdt_process_filter+0x1fb0>
    5474:      	movq	%r12, %r13
    5477:      	addq	$0xff6, %r13            # imm = 0xFF6
    547e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5488:      	movq	%rax, 0xff6(%r12)
    5490:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    549b:      	jmp	0x47d3 <generic_usdt_process_filter+0x843>
    54a0:      	movq	0x8(%rsp), %r10
    54a5:      	movl	%r13d, %eax
    54a8:      	leaq	0x4(,%rax,4), %rcx
    54b0:      	movl	0x4(%r10,%rax,4), %eax
    54b5:      	leal	(%rax,%rcx), %r14d
    54b9:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    54c0:      	addl	%eax, %ecx
    54c2:      	addl	$0x4, %ecx
    54c5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    54cb:      	leaq	0x8(%r14), %rbp
    54cf:      	cmpl	$0x5, (%rcx,%r10)
    54d4:      	jb	0x59fe <generic_usdt_process_filter+0x1a6e>
    54da:      	movl	(%rbp,%r10), %r12d
    54df:      	movl	0x4(%rbp,%r10), %edi
    54e4:      	movl	0x8(%rbp,%r10), %edx
    54e9:      	movq	$0x0, 0x68(%rsp)
    54f2:      	movq	$0x0, 0x60(%rsp)
    54fb:      	cmpl	$0x4, %edx
    54fe:      	movl	$0x4, %ecx
    5503:      	cmovbl	%edx, %ecx
    5506:      	cmpl	$0x6, %r12d
    550a:      	jne	0x5520 <generic_usdt_process_filter+0x1590>
    550c:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    5516:      	movq	%rsi, 0x60(%rsp)
    551b:      	movq	%rsi, 0x68(%rsp)
    5520:      	testl	%edx, %edx
    5522:      	je	0x5a05 <generic_usdt_process_filter+0x1a75>
    5528:      	movq	0x38(%rsp), %rdx
    552d:      	leaq	0x24(%rdx), %rsi
    5531:      	testb	$0x1, %dil
    5535:      	movq	%rsi, 0xb0(%rsp)
    553d:      	movq	%rsi, %r8
    5540:      	cmoveq	%rdx, %r8
    5544:      	addq	$0x10, %rdx
    5548:      	movq	%rdx, 0xd0(%rsp)
    5550:      	leal	(%rax,%r13,4), %r9d
    5554:      	addl	$0x4, %r9d
    5558:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    555f:      	addq	$0x14, %r9
    5563:      	decq	%rcx
    5566:      	cmpq	$0x3, %rcx
    556a:      	movl	$0x3, %eax
    556f:      	cmovbq	%rcx, %rax
    5573:      	movl	%eax, %eax
    5575:      	leaq	0x4(,%rax,4), %r11
    557d:      	xorl	%r13d, %r13d
    5580:      	movq	%rdi, 0x30(%rsp)
    5585:      	movq	%r8, 0x28(%rsp)
    558a:      	movq	%r9, 0x20(%rsp)
    558f:      	movq	%r11, 0x18(%rsp)
    5594:      	jmp	0x55d0 <generic_usdt_process_filter+0x1640>
    5596:      	movq	0x8(%rsp), %r10
    559b:      	movq	0x30(%rsp), %rdi
    55a0:      	movq	0x28(%rsp), %r8
    55a5:      	movq	0x20(%rsp), %r9
    55aa:      	movq	0x18(%rsp), %r11
    55af:      	cmpl	$0x6, %r12d
    55b3:      	setne	%al
    55b6:      	xorb	$0x1, %bl
    55b9:      	orb	%al, %bl
    55bb:      	movzbl	%bl, %eax
    55be:      	movl	%eax, 0x60(%rsp,%r13)
    55c3:      	addq	$0x4, %r13
    55c7:      	cmpq	%r13, %r11
    55ca:      	je	0x5a05 <generic_usdt_process_filter+0x1a75>
    55d0:      	leaq	(%r9,%r13), %rax
    55d4:      	movl	(%r8), %ecx
    55d7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    55dd:      	jbe	0x57ea <generic_usdt_process_filter+0x185a>
    55e3:      	xorl	%r15d, %r15d
    55e6:      	testb	$0x2, %dil
    55ea:      	je	0x5807 <generic_usdt_process_filter+0x1877>
    55f0:      	testb	$0x1, %dil
    55f4:      	jne	0x5828 <generic_usdt_process_filter+0x1898>
    55fa:      	movq	0x38(%rsp), %rcx
    55ff:      	movl	(%rcx), %eax
    5601:      	movb	$0x1, %bl
    5603:      	cmpq	%rax, %r15
    5606:      	je	0x55af <generic_usdt_process_filter+0x161f>
    5608:      	movl	0x10(%rcx), %eax
    560b:      	cmpq	%rax, %r15
    560e:      	je	0x55af <generic_usdt_process_filter+0x161f>
    5610:      	movl	$0x1, %eax
    5615:      	movq	0xd0(%rsp), %rsi
    561d:      	movq	(%rip), %rdi            # 0x5624 <generic_usdt_process_filter+0x1694>
    5624:      	callq	*%rax
    5626:      	testq	%rax, %rax
    5629:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    562f:      	movq	%rax, %rsi
    5632:      	movl	(%rax), %eax
    5634:      	cmpq	%rax, %r15
    5637:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    563d:      	movl	0x10(%rsi), %eax
    5640:      	cmpq	%rax, %r15
    5643:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5649:      	addq	$0x10, %rsi
    564d:      	movl	$0x1, %eax
    5652:      	movq	(%rip), %rdi            # 0x5659 <generic_usdt_process_filter+0x16c9>
    5659:      	callq	*%rax
    565b:      	testq	%rax, %rax
    565e:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5664:      	movq	%rax, %rsi
    5667:      	movl	(%rax), %eax
    5669:      	cmpq	%rax, %r15
    566c:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5672:      	movl	0x10(%rsi), %eax
    5675:      	cmpq	%rax, %r15
    5678:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    567e:      	addq	$0x10, %rsi
    5682:      	movl	$0x1, %eax
    5687:      	movq	(%rip), %rdi            # 0x568e <generic_usdt_process_filter+0x16fe>
    568e:      	callq	*%rax
    5690:      	testq	%rax, %rax
    5693:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5699:      	movq	%rax, %rsi
    569c:      	movl	(%rax), %eax
    569e:      	cmpq	%rax, %r15
    56a1:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    56a7:      	movl	0x10(%rsi), %eax
    56aa:      	cmpq	%rax, %r15
    56ad:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    56b3:      	addq	$0x10, %rsi
    56b7:      	movl	$0x1, %eax
    56bc:      	movq	(%rip), %rdi            # 0x56c3 <generic_usdt_process_filter+0x1733>
    56c3:      	callq	*%rax
    56c5:      	testq	%rax, %rax
    56c8:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    56ce:      	movq	%rax, %rsi
    56d1:      	movl	(%rax), %eax
    56d3:      	cmpq	%rax, %r15
    56d6:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    56dc:      	movl	0x10(%rsi), %eax
    56df:      	cmpq	%rax, %r15
    56e2:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    56e8:      	addq	$0x10, %rsi
    56ec:      	movl	$0x1, %eax
    56f1:      	movq	(%rip), %rdi            # 0x56f8 <generic_usdt_process_filter+0x1768>
    56f8:      	callq	*%rax
    56fa:      	testq	%rax, %rax
    56fd:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5703:      	movq	%rax, %rsi
    5706:      	movl	(%rax), %eax
    5708:      	cmpq	%rax, %r15
    570b:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5711:      	movl	0x10(%rsi), %eax
    5714:      	cmpq	%rax, %r15
    5717:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    571d:      	addq	$0x10, %rsi
    5721:      	movl	$0x1, %eax
    5726:      	movq	(%rip), %rdi            # 0x572d <generic_usdt_process_filter+0x179d>
    572d:      	callq	*%rax
    572f:      	testq	%rax, %rax
    5732:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5738:      	movq	%rax, %rsi
    573b:      	movl	(%rax), %eax
    573d:      	cmpq	%rax, %r15
    5740:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5746:      	movl	0x10(%rsi), %eax
    5749:      	cmpq	%rax, %r15
    574c:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5752:      	addq	$0x10, %rsi
    5756:      	movl	$0x1, %eax
    575b:      	movq	(%rip), %rdi            # 0x5762 <generic_usdt_process_filter+0x17d2>
    5762:      	callq	*%rax
    5764:      	testq	%rax, %rax
    5767:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    576d:      	movq	%rax, %rsi
    5770:      	movl	(%rax), %eax
    5772:      	cmpq	%rax, %r15
    5775:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    577b:      	movl	0x10(%rsi), %eax
    577e:      	cmpq	%rax, %r15
    5781:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5787:      	addq	$0x10, %rsi
    578b:      	movl	$0x1, %eax
    5790:      	movq	(%rip), %rdi            # 0x5797 <generic_usdt_process_filter+0x1807>
    5797:      	callq	*%rax
    5799:      	testq	%rax, %rax
    579c:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    57a2:      	movq	%rax, %rsi
    57a5:      	movl	(%rax), %eax
    57a7:      	cmpq	%rax, %r15
    57aa:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    57b0:      	movl	0x10(%rsi), %eax
    57b3:      	cmpq	%rax, %r15
    57b6:      	movq	0x8(%rsp), %r10
    57bb:      	movq	0x30(%rsp), %rdi
    57c0:      	movq	0x28(%rsp), %r8
    57c5:      	movq	0x20(%rsp), %r9
    57ca:      	movq	0x18(%rsp), %r11
    57cf:      	je	0x55af <generic_usdt_process_filter+0x161f>
    57d5:      	addq	$0x10, %rsi
    57d9:      	movl	$0x1, %eax
    57de:      	movq	(%rip), %rcx            # 0x57e5 <generic_usdt_process_filter+0x1855>
    57e5:      	jmp	0x59c4 <generic_usdt_process_filter+0x1a34>
    57ea:      	movl	$0x4, %esi
    57ef:      	xorl	%edx, %edx
    57f1:      	divq	%rsi
    57f4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    57f9:      	movl	(%r10,%rax,4), %r15d
    57fd:      	testb	$0x2, %dil
    5801:      	jne	0x55f0 <generic_usdt_process_filter+0x1660>
    5807:      	cmpl	$0x5, %r12d
    580b:      	jne	0x5816 <generic_usdt_process_filter+0x1886>
    580d:      	cmpq	%rcx, %r15
    5810:      	jne	0x59f7 <generic_usdt_process_filter+0x1a67>
    5816:      	cmpq	%rcx, %r15
    5819:      	setne	%al
    581c:      	cmpl	$0x6, %r12d
    5820:      	setne	%bl
    5823:      	jmp	0x55b9 <generic_usdt_process_filter+0x1629>
    5828:      	movq	0xb0(%rsp), %rax
    5830:      	movl	(%rax), %eax
    5832:      	testq	%rax, %rax
    5835:      	je	0x59f7 <generic_usdt_process_filter+0x1a67>
    583b:      	movb	$0x1, %bl
    583d:      	testq	%r15, %r15
    5840:      	je	0x55af <generic_usdt_process_filter+0x161f>
    5846:      	cmpq	%rax, %r15
    5849:      	je	0x55af <generic_usdt_process_filter+0x161f>
    584f:      	movl	$0x1, %eax
    5854:      	movq	0xd0(%rsp), %rsi
    585c:      	movq	(%rip), %rdi            # 0x5863 <generic_usdt_process_filter+0x18d3>
    5863:      	callq	*%rax
    5865:      	testq	%rax, %rax
    5868:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    586e:      	movq	%rax, %rsi
    5871:      	movl	0x24(%rax), %eax
    5874:      	cmpq	%rax, %r15
    5877:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    587d:      	addq	$0x10, %rsi
    5881:      	movl	$0x1, %eax
    5886:      	movq	(%rip), %rdi            # 0x588d <generic_usdt_process_filter+0x18fd>
    588d:      	callq	*%rax
    588f:      	testq	%rax, %rax
    5892:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5898:      	movq	%rax, %rsi
    589b:      	movl	0x24(%rax), %eax
    589e:      	cmpq	%rax, %r15
    58a1:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    58a7:      	addq	$0x10, %rsi
    58ab:      	movl	$0x1, %eax
    58b0:      	movq	(%rip), %rdi            # 0x58b7 <generic_usdt_process_filter+0x1927>
    58b7:      	callq	*%rax
    58b9:      	testq	%rax, %rax
    58bc:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    58c2:      	movq	%rax, %rsi
    58c5:      	movl	0x24(%rax), %eax
    58c8:      	cmpq	%rax, %r15
    58cb:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    58d1:      	addq	$0x10, %rsi
    58d5:      	movl	$0x1, %eax
    58da:      	movq	(%rip), %rdi            # 0x58e1 <generic_usdt_process_filter+0x1951>
    58e1:      	callq	*%rax
    58e3:      	testq	%rax, %rax
    58e6:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    58ec:      	movq	%rax, %rsi
    58ef:      	movl	0x24(%rax), %eax
    58f2:      	cmpq	%rax, %r15
    58f5:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    58fb:      	addq	$0x10, %rsi
    58ff:      	movl	$0x1, %eax
    5904:      	movq	(%rip), %rdi            # 0x590b <generic_usdt_process_filter+0x197b>
    590b:      	callq	*%rax
    590d:      	testq	%rax, %rax
    5910:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5916:      	movq	%rax, %rsi
    5919:      	movl	0x24(%rax), %eax
    591c:      	cmpq	%rax, %r15
    591f:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5925:      	addq	$0x10, %rsi
    5929:      	movl	$0x1, %eax
    592e:      	movq	(%rip), %rdi            # 0x5935 <generic_usdt_process_filter+0x19a5>
    5935:      	callq	*%rax
    5937:      	testq	%rax, %rax
    593a:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5940:      	movq	%rax, %rsi
    5943:      	movl	0x24(%rax), %eax
    5946:      	cmpq	%rax, %r15
    5949:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    594f:      	addq	$0x10, %rsi
    5953:      	movl	$0x1, %eax
    5958:      	movq	(%rip), %rdi            # 0x595f <generic_usdt_process_filter+0x19cf>
    595f:      	callq	*%rax
    5961:      	testq	%rax, %rax
    5964:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    5966:      	movq	%rax, %rsi
    5969:      	movl	0x24(%rax), %eax
    596c:      	cmpq	%rax, %r15
    596f:      	je	0x5596 <generic_usdt_process_filter+0x1606>
    5975:      	addq	$0x10, %rsi
    5979:      	movl	$0x1, %eax
    597e:      	movq	(%rip), %rdi            # 0x5985 <generic_usdt_process_filter+0x19f5>
    5985:      	callq	*%rax
    5987:      	testq	%rax, %rax
    598a:      	je	0x59cd <generic_usdt_process_filter+0x1a3d>
    598c:      	movq	%rax, %rsi
    598f:      	movl	0x24(%rax), %eax
    5992:      	cmpq	%rax, %r15
    5995:      	movq	0x8(%rsp), %r10
    599a:      	movq	0x30(%rsp), %rdi
    599f:      	movq	0x28(%rsp), %r8
    59a4:      	movq	0x20(%rsp), %r9
    59a9:      	movq	0x18(%rsp), %r11
    59ae:      	je	0x55af <generic_usdt_process_filter+0x161f>
    59b4:      	addq	$0x10, %rsi
    59b8:      	movl	$0x1, %eax
    59bd:      	movq	(%rip), %rcx            # 0x59c4 <generic_usdt_process_filter+0x1a34>
    59c4:      	movq	(%rip), %rdi            # 0x59cb <generic_usdt_process_filter+0x1a3b>
    59cb:      	callq	*%rax
    59cd:      	xorl	%ebx, %ebx
    59cf:      	cmpl	$0x5, %r12d
    59d3:      	movq	0x8(%rsp), %r10
    59d8:      	movq	0x30(%rsp), %rdi
    59dd:      	movq	0x28(%rsp), %r8
    59e2:      	movq	0x20(%rsp), %r9
    59e7:      	movq	0x18(%rsp), %r11
    59ec:      	jne	0x55af <generic_usdt_process_filter+0x161f>
    59f2:      	jmp	0x55bb <generic_usdt_process_filter+0x162b>
    59f7:      	xorl	%ebx, %ebx
    59f9:      	jmp	0x55bb <generic_usdt_process_filter+0x162b>
    59fe:      	movl	$0x1, %eax
    5a03:      	jmp	0x5a41 <generic_usdt_process_filter+0x1ab1>
    5a05:      	movl	0x60(%rsp), %esi
    5a09:      	movl	0x64(%rsp), %ecx
    5a0d:      	movl	0x68(%rsp), %eax
    5a11:      	movl	0x6c(%rsp), %edx
    5a15:      	cmpl	$0x6, %r12d
    5a19:      	jne	0x5a23 <generic_usdt_process_filter+0x1a93>
    5a1b:      	andl	%esi, %ecx
    5a1d:      	andl	%edx, %eax
    5a1f:      	andl	%ecx, %eax
    5a21:      	jmp	0x5a29 <generic_usdt_process_filter+0x1a99>
    5a23:      	orl	%esi, %ecx
    5a25:      	orl	%edx, %eax
    5a27:      	orl	%ecx, %eax
    5a29:      	testl	%eax, %eax
    5a2b:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5a31:      	addl	$0x14, %r14d
    5a35:      	movl	0x8(%r10,%rbp), %ecx
    5a3a:      	andl	$0x7, %ecx
    5a3d:      	leal	(%r14,%rcx,4), %ebp
    5a41:      	movq	0x50(%rsp), %r9
    5a46:      	movl	%ebp, %ecx
    5a48:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5a4e:      	movl	(%rcx,%r10), %ecx
    5a52:      	addl	$0x4, %ebp
    5a55:      	addl	$-0x4, %ecx
    5a58:      	xorl	%esi, %esi
    5a5a:      	movl	$0x4, %r8d
    5a60:      	jmp	0x5a7f <generic_usdt_process_filter+0x1aef>
    5a62:      	nopw	%cs:(%rax,%rax)
    5a70:      	xorl	%ecx, %ecx
    5a72:      	incq	%rsi
    5a75:      	cmpq	$0xa, %rsi
    5a79:      	je	0x5c08 <generic_usdt_process_filter+0x1c78>
    5a7f:      	testl	%ecx, %ecx
    5a81:      	je	0x5a70 <generic_usdt_process_filter+0x1ae0>
    5a83:      	movl	%ebp, %r9d
    5a86:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5a8d:      	movl	(%r9,%r10), %r11d
    5a91:      	movq	%r10, %rax
    5a94:      	movl	0x4(%r9,%r10), %r10d
    5a99:      	movl	0x8(%r9,%rax), %edx
    5a9e:      	movq	$0x0, 0x68(%rsp)
    5aa7:      	movq	$0x0, 0x60(%rsp)
    5ab0:      	cmpl	$0x4, %edx
    5ab3:      	movl	$0x4, %eax
    5ab8:      	cmovbl	%edx, %eax
    5abb:      	cmpl	$0x6, %r10d
    5abf:      	jne	0x5ad5 <generic_usdt_process_filter+0x1b45>
    5ac1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5acb:      	movq	%rdi, 0x60(%rsp)
    5ad0:      	movq	%rdi, 0x68(%rsp)
    5ad5:      	addl	$0xc, %ebp
    5ad8:      	testl	%edx, %edx
    5ada:      	je	0x5bb0 <generic_usdt_process_filter+0x1c20>
    5ae0:      	andl	$0xf, %r11d
    5ae4:      	decq	%rax
    5ae7:      	cmpq	$0x3, %rax
    5aeb:      	movl	$0x3, %edx
    5af0:      	cmovaeq	%rdx, %rax
    5af4:      	leaq	0x4(,%rax,4), %rbx
    5afc:      	movl	%ebp, %r14d
    5aff:      	cmpl	$0x9, %r11d
    5b03:      	jbe	0x5b3a <generic_usdt_process_filter+0x1baa>
    5b05:      	xorl	%r11d, %r11d
    5b08:      	jmp	0x5b26 <generic_usdt_process_filter+0x1b96>
    5b0a:      	nopw	(%rax,%rax)
    5b10:      	movl	$0x0, 0x60(%rsp,%r11)
    5b19:      	addq	$0x4, %r11
    5b1d:      	cmpq	%r11, %rbx
    5b20:      	je	0x5bb0 <generic_usdt_process_filter+0x1c20>
    5b26:      	leaq	(%r14,%r11), %rax
    5b2a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5b2f:      	ja	0x5b10 <generic_usdt_process_filter+0x1b80>
    5b31:      	movl	%eax, %eax
    5b33:      	xorl	%edx, %edx
    5b35:      	divq	%r8
    5b38:      	jmp	0x5b10 <generic_usdt_process_filter+0x1b80>
    5b3a:      	xorl	%r15d, %r15d
    5b3d:      	jmp	0x5b81 <generic_usdt_process_filter+0x1bf1>
    5b3f:      	nop
    5b40:      	cmpl	$0x5, %r10d
    5b44:      	setne	%dl
    5b47:      	movl	%r10d, %r13d
    5b4a:      	xorl	$0x6, %r13d
    5b4e:      	movq	0x50(%rsp), %rax
    5b53:      	movl	0x20(%rax,%r11,4), %edi
    5b58:      	movl	%r12d, %eax
    5b5b:      	xorl	%edi, %eax
    5b5d:      	cmpl	%edi, %r12d
    5b60:      	sete	%dil
    5b64:      	orb	%dl, %dil
    5b67:      	orl	%r13d, %eax
    5b6a:      	setne	%al
    5b6d:      	andb	%dil, %al
    5b70:      	movzbl	%al, %eax
    5b73:      	movl	%eax, 0x60(%rsp,%r15)
    5b78:      	addq	$0x4, %r15
    5b7c:      	cmpq	%r15, %rbx
    5b7f:      	je	0x5bb0 <generic_usdt_process_filter+0x1c20>
    5b81:      	leaq	(%r14,%r15), %rdx
    5b85:      	xorl	%r12d, %r12d
    5b88:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    5b8e:      	ja	0x5b40 <generic_usdt_process_filter+0x1bb0>
    5b90:      	movl	%edx, %eax
    5b92:      	xorl	%edx, %edx
    5b94:      	divq	%r8
    5b97:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5b9c:      	movq	0x8(%rsp), %rdx
    5ba1:      	movl	(%rdx,%rax,4), %r12d
    5ba5:      	jmp	0x5b40 <generic_usdt_process_filter+0x1bb0>
    5ba7:      	nopw	(%rax,%rax)
    5bb0:      	movl	0x60(%rsp), %ebx
    5bb4:      	movl	0x64(%rsp), %edx
    5bb8:      	movl	0x68(%rsp), %eax
    5bbc:      	movl	0x6c(%rsp), %r11d
    5bc1:      	cmpl	$0x6, %r10d
    5bc5:      	jne	0x5bd0 <generic_usdt_process_filter+0x1c40>
    5bc7:      	andl	%ebx, %edx
    5bc9:      	andl	%r11d, %eax
    5bcc:      	andl	%edx, %eax
    5bce:      	jmp	0x5bd7 <generic_usdt_process_filter+0x1c47>
    5bd0:      	orl	%ebx, %edx
    5bd2:      	orl	%r11d, %eax
    5bd5:      	orl	%edx, %eax
    5bd7:      	movq	0x8(%rsp), %r10
    5bdc:      	testl	%eax, %eax
    5bde:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5be4:      	movl	0x8(%r10,%r9), %edx
    5be9:      	shll	$0x2, %edx
    5bec:      	subl	%edx, %ecx
    5bee:      	andl	$0x1c, %edx
    5bf1:      	addl	%edx, %ebp
    5bf3:      	addl	$-0xc, %ecx
    5bf6:      	movq	0x50(%rsp), %r9
    5bfb:      	incq	%rsi
    5bfe:      	cmpq	$0xa, %rsi
    5c02:      	jne	0x5a7f <generic_usdt_process_filter+0x1aef>
    5c08:      	movl	%ebp, %ecx
    5c0a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5c10:      	leal	0x4(%rbp), %ebx
    5c13:      	cmpl	$0x4, (%rcx,%r10)
    5c18:      	je	0x5de8 <generic_usdt_process_filter+0x1e58>
    5c1e:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5c24:      	movl	(%rbx,%r10), %ecx
    5c28:      	movl	0x4(%rbx,%r10), %edx
    5c2d:      	movl	0x8(%rbx,%r10), %edi
    5c32:      	movq	0xc(%rbx,%r10), %rax
    5c37:      	testl	%edi, %edi
    5c39:      	je	0x5dbc <generic_usdt_process_filter+0x1e2c>
    5c3f:      	xorl	%esi, %esi
    5c41:      	cmpl	$0x2, %ecx
    5c44:      	ja	0x5ddf <generic_usdt_process_filter+0x1e4f>
    5c4a:      	cmpl	%edi, 0x44(%r9)
    5c4e:      	jne	0x5dc5 <generic_usdt_process_filter+0x1e35>
    5c54:      	jmp	0x5ddf <generic_usdt_process_filter+0x1e4f>
    5c59:      	movq	%rbx, %rsi
    5c5c:      	addq	$0x4, %rsi
    5c60:      	movq	(%rip), %rdi            # 0x5c67 <generic_usdt_process_filter+0x1cd7>
    5c67:      	movl	$0x1, %eax
    5c6c:      	callq	*%rax
    5c6e:      	testq	%rax, %rax
    5c71:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5c77:      	movq	%rax, %r14
    5c7a:      	movq	(%rip), %rdi            # 0x5c81 <generic_usdt_process_filter+0x1cf1>
    5c81:      	leaq	0x58(%rsp), %rsi
    5c86:      	movl	$0x1, %eax
    5c8b:      	callq	*%rax
    5c8d:      	testq	%rax, %rax
    5c90:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5c96:      	movq	%rax, %rbp
    5c99:      	movl	$0x104, %edx            # imm = 0x104
    5c9e:      	movq	%rax, %rdi
    5ca1:      	xorl	%esi, %esi
    5ca3:      	callq	0x5ca8 <generic_usdt_process_filter+0x1d18>
    5ca8:      	movq	0x38(%rsp), %rsi
    5cad:      	movl	0x68(%rsi), %eax
    5cb0:      	leal	(,%rax,8), %ecx
    5cb7:      	movl	%ecx, (%rbp)
    5cba:      	movq	%rbp, %rdi
    5cbd:      	addq	$0x4, %rdi
    5cc1:      	movzbl	%al, %ecx
    5cc4:      	leaq	0x70(%rsi), %rdx
    5cc8:      	movl	$0x4, %eax
    5ccd:      	movzbl	0x68(%rsi), %esi
    5cd1:      	callq	*%rax
    5cd3:      	testq	%rax, %rax
    5cd6:      	js	0x655b <generic_usdt_process_filter+0x25cb>
    5cdc:      	movl	$0x1, %eax
    5ce1:      	movq	%r14, %rdi
    5ce4:      	movq	%rbp, %rsi
    5ce7:      	jmp	0x60e7 <generic_usdt_process_filter+0x2157>
    5cec:      	movl	$0x0, 0x40(%rsp)
    5cf4:      	movq	(%rip), %rdi            # 0x5cfb <generic_usdt_process_filter+0x1d6b>
    5cfb:      	leaq	0x40(%rsp), %rsi
    5d00:      	movl	$0x1, %eax
    5d05:      	callq	*%rax
    5d07:      	testq	%rax, %rax
    5d0a:      	movq	0x38(%rsp), %rdx
    5d0f:      	je	0x6094 <generic_usdt_process_filter+0x2104>
    5d15:      	movq	(%rax), %rcx
    5d18:      	cmpq	0x378(%rdx), %rcx
    5d1f:      	je	0x6094 <generic_usdt_process_filter+0x2104>
    5d25:      	movq	%rax, 0xb0(%rsp)
    5d2d:      	movq	(%rip), %rax            # 0x5d34 <generic_usdt_process_filter+0x1da4>
    5d34:      	cmpb	$0x0, (%rax)
    5d37:      	je	0x600b <generic_usdt_process_filter+0x207b>
    5d3d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5d43:      	xorl	%r14d, %r14d
    5d46:      	movq	(%rip), %r12            # 0x5d4d <generic_usdt_process_filter+0x1dbd>
    5d4d:      	movq	0x38(%rsp), %rax
    5d52:      	movl	0x10(%rax), %eax
    5d55:      	movl	%eax, 0x60(%rsp)
    5d59:      	movl	$0x1, %eax
    5d5e:      	leaq	0x60(%rsp), %rsi
    5d63:      	movq	%r12, %rdi
    5d66:      	callq	*%rax
    5d68:      	testq	%rax, %rax
    5d6b:      	je	0x607d <generic_usdt_process_filter+0x20ed>
    5d71:      	movq	%rax, %rbp
    5d74:      	leaq	0x70(%rax), %rsi
    5d78:      	movl	$0x1, %eax
    5d7d:      	movq	(%rip), %rdi            # 0x5d84 <generic_usdt_process_filter+0x1df4>
    5d84:      	callq	*%rax
    5d86:      	testq	%rax, %rax
    5d89:      	je	0x5da0 <generic_usdt_process_filter+0x1e10>
    5d8b:      	movq	(%rax), %rax
    5d8e:      	testq	%rax, %rax
    5d91:      	je	0x5da0 <generic_usdt_process_filter+0x1e10>
    5d93:      	movq	0x38(%rsp), %rcx
    5d98:      	lock
    5d99:      	orq	%rax, 0x370(%rcx)
    5da0:      	subl	$0x1, %r15d
    5da4:      	setb	%al
    5da7:      	cmpq	%r14, %rbp
    5daa:      	je	0x607d <generic_usdt_process_filter+0x20ed>
    5db0:      	movq	%rbp, %r14
    5db3:      	testb	%al, %al
    5db5:      	je	0x5d4d <generic_usdt_process_filter+0x1dbd>
    5db7:      	jmp	0x607d <generic_usdt_process_filter+0x20ed>
    5dbc:      	cmpl	$0x2, %ecx
    5dbf:      	jbe	0x5dc5 <generic_usdt_process_filter+0x1e35>
    5dc1:      	xorl	%esi, %esi
    5dc3:      	jmp	0x5ddf <generic_usdt_process_filter+0x1e4f>
    5dc5:      	andq	0x48(%r9,%rcx,8), %rax
    5dca:      	cmpl	$0x5, %edx
    5dcd:      	jne	0x5dd8 <generic_usdt_process_filter+0x1e48>
    5dcf:      	testq	%rax, %rax
    5dd2:      	setne	%sil
    5dd6:      	jmp	0x5ddf <generic_usdt_process_filter+0x1e4f>
    5dd8:      	testq	%rax, %rax
    5ddb:      	sete	%sil
    5ddf:      	addl	$0x18, %ebp
    5de2:      	movzbl	%sil, %eax
    5de6:      	movl	%ebp, %ebx
    5de8:      	testl	%eax, %eax
    5dea:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5df0:      	movl	%ebx, %ecx
    5df2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5df8:      	leal	0x4(%rbx), %eax
    5dfb:      	cmpl	$0x4, (%rcx,%r10)
    5e00:      	je	0x6463 <generic_usdt_process_filter+0x24d3>
    5e06:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e0b:      	movl	(%rax,%r10), %r14d
    5e0f:      	movl	0x4(%rax,%r10), %ebp
    5e14:      	movl	$0xe, %eax
    5e19:      	callq	*%rax
    5e1b:      	shrq	$0x20, %rax
    5e1f:      	movl	%eax, 0x60(%rsp)
    5e23:      	movq	(%rip), %rdi            # 0x5e2a <generic_usdt_process_filter+0x1e9a>
    5e2a:      	leaq	0x60(%rsp), %rsi
    5e2f:      	movl	$0x1, %eax
    5e34:      	callq	*%rax
    5e36:      	movq	0x8(%rsp), %r10
    5e3b:      	testq	%rax, %rax
    5e3e:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5e44:      	cmpl	$0x5, %r14d
    5e48:      	je	0x5e86 <generic_usdt_process_filter+0x1ef6>
    5e4a:      	cmpl	$0x6, %r14d
    5e4e:      	jne	0x655b <generic_usdt_process_filter+0x25cb>
    5e54:      	movq	0x50(%rsp), %rsi
    5e59:      	movq	%rsi, %rcx
    5e5c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5e63:      	testb	$0x1, %bpl
    5e67:      	jne	0x6129 <generic_usdt_process_filter+0x2199>
    5e6d:      	movl	0x28(%rax), %edx
    5e70:      	testl	%edx, %edx
    5e72:      	je	0x6122 <generic_usdt_process_filter+0x2192>
    5e78:      	cmpl	0x20(%rsi), %edx
    5e7b:      	je	0x6129 <generic_usdt_process_filter+0x2199>
    5e81:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    5e86:      	movq	0x50(%rsp), %rsi
    5e8b:      	movq	%rsi, %rcx
    5e8e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5e95:      	testb	$0x1, %bpl
    5e99:      	je	0x6147 <generic_usdt_process_filter+0x21b7>
    5e9f:      	movl	0x28(%rax), %edx
    5ea2:      	testl	%edx, %edx
    5ea4:      	je	0x6140 <generic_usdt_process_filter+0x21b0>
    5eaa:      	cmpl	0x20(%rsi), %edx
    5ead:      	je	0x6147 <generic_usdt_process_filter+0x21b7>
    5eb3:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    5eb8:      	movq	%r12, %rsi
    5ebb:      	addq	$0x4, %rsi
    5ebf:      	movq	(%rip), %rdi            # 0x5ec6 <generic_usdt_process_filter+0x1f36>
    5ec6:      	movl	$0x1, %eax
    5ecb:      	callq	*%rax
    5ecd:      	testq	%rax, %rax
    5ed0:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5ed6:      	movq	%rax, %r14
    5ed9:      	movq	(%rip), %rdi            # 0x5ee0 <generic_usdt_process_filter+0x1f50>
    5ee0:      	leaq	0x58(%rsp), %rsi
    5ee5:      	movl	$0x1, %eax
    5eea:      	callq	*%rax
    5eec:      	testq	%rax, %rax
    5eef:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    5ef5:      	movq	%rax, %rbx
    5ef8:      	movl	$0x104, %edx            # imm = 0x104
    5efd:      	movq	%rax, %rdi
    5f00:      	xorl	%esi, %esi
    5f02:      	callq	0x5f07 <generic_usdt_process_filter+0x1f77>
    5f07:      	movl	(%rbp), %eax
    5f0a:      	leal	(,%rax,8), %ecx
    5f11:      	movl	%ecx, (%rbx)
    5f13:      	movq	%rbx, %rdi
    5f16:      	addq	$0x4, %rdi
    5f1a:      	movzbl	%al, %ecx
    5f1d:      	movq	%rbp, %rdx
    5f20:      	addq	$0x8, %rdx
    5f24:      	movl	$0x4, %eax
    5f29:      	movzbl	(%rbp), %esi
    5f2d:      	callq	*%rax
    5f2f:      	testq	%rax, %rax
    5f32:      	js	0x655b <generic_usdt_process_filter+0x25cb>
    5f38:      	movl	$0x1, %eax
    5f3d:      	movq	%r14, %rdi
    5f40:      	movq	%rbx, %rsi
    5f43:      	jmp	0x62bd <generic_usdt_process_filter+0x232d>
    5f48:      	movl	$0x0, 0x40(%rsp)
    5f50:      	movq	(%rip), %rdi            # 0x5f57 <generic_usdt_process_filter+0x1fc7>
    5f57:      	leaq	0x40(%rsp), %rsi
    5f5c:      	movl	$0x1, %eax
    5f61:      	callq	*%rax
    5f63:      	testq	%rax, %rax
    5f66:      	je	0x626a <generic_usdt_process_filter+0x22da>
    5f6c:      	movq	(%rax), %rcx
    5f6f:      	cmpq	0x310(%rbp), %rcx
    5f76:      	je	0x626a <generic_usdt_process_filter+0x22da>
    5f7c:      	movq	%rax, 0xb0(%rsp)
    5f84:      	movq	(%rip), %rax            # 0x5f8b <generic_usdt_process_filter+0x1ffb>
    5f8b:      	cmpb	$0x0, (%rax)
    5f8e:      	je	0x61ee <generic_usdt_process_filter+0x225e>
    5f94:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5f9a:      	xorl	%r14d, %r14d
    5f9d:      	movq	0x38(%rsp), %rax
    5fa2:      	movl	0x10(%rax), %eax
    5fa5:      	movl	%eax, 0x60(%rsp)
    5fa9:      	movl	$0x1, %eax
    5fae:      	movq	(%rip), %rdi            # 0x5fb5 <generic_usdt_process_filter+0x2025>
    5fb5:      	leaq	0x60(%rsp), %rsi
    5fba:      	callq	*%rax
    5fbc:      	testq	%rax, %rax
    5fbf:      	je	0x6258 <generic_usdt_process_filter+0x22c8>
    5fc5:      	movq	%rax, %rbx
    5fc8:      	leaq	0x70(%rax), %rsi
    5fcc:      	movl	$0x1, %eax
    5fd1:      	movq	(%rip), %rdi            # 0x5fd8 <generic_usdt_process_filter+0x2048>
    5fd8:      	callq	*%rax
    5fda:      	testq	%rax, %rax
    5fdd:      	je	0x5fef <generic_usdt_process_filter+0x205f>
    5fdf:      	movq	(%rax), %rax
    5fe2:      	testq	%rax, %rax
    5fe5:      	je	0x5fef <generic_usdt_process_filter+0x205f>
    5fe7:      	lock
    5fe8:      	orq	%rax, 0x308(%rbp)
    5fef:      	subl	$0x1, %r15d
    5ff3:      	setb	%al
    5ff6:      	cmpq	%r14, %rbx
    5ff9:      	je	0x6258 <generic_usdt_process_filter+0x22c8>
    5fff:      	movq	%rbx, %r14
    6002:      	testb	%al, %al
    6004:      	je	0x5f9d <generic_usdt_process_filter+0x200d>
    6006:      	jmp	0x6258 <generic_usdt_process_filter+0x22c8>
    600b:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    6011:      	xorl	%r14d, %r14d
    6014:      	movq	(%rip), %r12            # 0x601b <generic_usdt_process_filter+0x208b>
    601b:      	movq	0x38(%rsp), %rax
    6020:      	movl	0x10(%rax), %eax
    6023:      	movl	%eax, 0x60(%rsp)
    6027:      	movl	$0x1, %eax
    602c:      	leaq	0x60(%rsp), %rsi
    6031:      	movq	%r12, %rdi
    6034:      	callq	*%rax
    6036:      	testq	%rax, %rax
    6039:      	je	0x607d <generic_usdt_process_filter+0x20ed>
    603b:      	movq	%rax, %rbp
    603e:      	leaq	0x70(%rax), %rsi
    6042:      	movl	$0x1, %eax
    6047:      	movq	(%rip), %rdi            # 0x604e <generic_usdt_process_filter+0x20be>
    604e:      	callq	*%rax
    6050:      	testq	%rax, %rax
    6053:      	je	0x606a <generic_usdt_process_filter+0x20da>
    6055:      	movq	(%rax), %rax
    6058:      	testq	%rax, %rax
    605b:      	je	0x606a <generic_usdt_process_filter+0x20da>
    605d:      	movq	0x38(%rsp), %rcx
    6062:      	lock
    6063:      	orq	%rax, 0x370(%rcx)
    606a:      	subl	$0x1, %r15d
    606e:      	setb	%al
    6071:      	cmpq	%r14, %rbp
    6074:      	je	0x607d <generic_usdt_process_filter+0x20ed>
    6076:      	movq	%rbp, %r14
    6079:      	testb	%al, %al
    607b:      	je	0x601b <generic_usdt_process_filter+0x208b>
    607d:      	movq	0xb0(%rsp), %rax
    6085:      	movq	(%rax), %rax
    6088:      	movq	0x38(%rsp), %rdx
    608d:      	movq	%rax, 0x378(%rdx)
    6094:      	movl	0x8(%rbx), %eax
    6097:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    609c:      	cmpq	%rcx, %rax
    609f:      	je	0x60ba <generic_usdt_process_filter+0x212a>
    60a1:      	movq	0x370(%rdx), %rcx
    60a8:      	btq	%rax, %rcx
    60ac:      	jae	0x60ba <generic_usdt_process_filter+0x212a>
    60ae:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    60b8:      	jmp	0x60e9 <generic_usdt_process_filter+0x2159>
    60ba:      	movq	(%rip), %rdi            # 0x60c1 <generic_usdt_process_filter+0x2131>
    60c1:      	leaq	0x10(%rsp), %rsi
    60c6:      	movl	$0x1, %eax
    60cb:      	callq	*%rax
    60cd:      	testq	%rax, %rax
    60d0:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    60d6:      	movq	%rax, %rdi
    60d9:      	movq	0x38(%rsp), %rax
    60de:      	leaq	0x70(%rax), %rsi
    60e2:      	movl	$0x1, %eax
    60e7:      	callq	*%rax
    60e9:      	movl	(%rbx), %ecx
    60eb:      	cmpq	$0x25, %rcx
    60ef:      	movq	0x8(%rsp), %r10
    60f4:      	ja	0x6114 <generic_usdt_process_filter+0x2184>
    60f6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    6100:      	btq	%rcx, %rdx
    6104:      	jae	0x6114 <generic_usdt_process_filter+0x2184>
    6106:      	testq	%rax, %rax
    6109:      	jne	0x655b <generic_usdt_process_filter+0x25cb>
    610f:      	jmp	0x5259 <generic_usdt_process_filter+0x12c9>
    6114:      	testq	%rax, %rax
    6117:      	jne	0x5259 <generic_usdt_process_filter+0x12c9>
    611d:      	jmp	0x655b <generic_usdt_process_filter+0x25cb>
    6122:      	movq	$0x1, (%rcx)
    6129:      	testb	$0x2, %bpl
    612d:      	jne	0x6165 <generic_usdt_process_filter+0x21d5>
    612f:      	movl	0x2c(%rax), %edx
    6132:      	testl	%edx, %edx
    6134:      	je	0x615e <generic_usdt_process_filter+0x21ce>
    6136:      	cmpl	0x24(%rsi), %edx
    6139:      	je	0x6165 <generic_usdt_process_filter+0x21d5>
    613b:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6140:      	movq	$0x1, (%rcx)
    6147:      	testb	$0x2, %bpl
    614b:      	je	0x6183 <generic_usdt_process_filter+0x21f3>
    614d:      	movl	0x2c(%rax), %edx
    6150:      	testl	%edx, %edx
    6152:      	je	0x617c <generic_usdt_process_filter+0x21ec>
    6154:      	cmpl	0x24(%rsi), %edx
    6157:      	je	0x6183 <generic_usdt_process_filter+0x21f3>
    6159:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    615e:      	movq	$0x1, (%rcx)
    6165:      	testb	$0x4, %bpl
    6169:      	jne	0x61a1 <generic_usdt_process_filter+0x2211>
    616b:      	movl	0x30(%rax), %edx
    616e:      	testl	%edx, %edx
    6170:      	je	0x619a <generic_usdt_process_filter+0x220a>
    6172:      	cmpl	0x28(%rsi), %edx
    6175:      	je	0x61a1 <generic_usdt_process_filter+0x2211>
    6177:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    617c:      	movq	$0x1, (%rcx)
    6183:      	testb	$0x4, %bpl
    6187:      	je	0x61cb <generic_usdt_process_filter+0x223b>
    6189:      	movl	0x30(%rax), %edx
    618c:      	testl	%edx, %edx
    618e:      	je	0x61c4 <generic_usdt_process_filter+0x2234>
    6190:      	cmpl	0x28(%rsi), %edx
    6193:      	je	0x61cb <generic_usdt_process_filter+0x223b>
    6195:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    619a:      	movq	$0x1, (%rcx)
    61a1:      	testb	$0x8, %bpl
    61a5:      	jne	0x6301 <generic_usdt_process_filter+0x2371>
    61ab:      	movl	0x34(%rax), %edx
    61ae:      	testl	%edx, %edx
    61b0:      	je	0x62fa <generic_usdt_process_filter+0x236a>
    61b6:      	cmpl	0x2c(%rsi), %edx
    61b9:      	je	0x6301 <generic_usdt_process_filter+0x2371>
    61bf:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    61c4:      	movq	$0x1, (%rcx)
    61cb:      	testb	$0x8, %bpl
    61cf:      	je	0x631f <generic_usdt_process_filter+0x238f>
    61d5:      	movl	0x34(%rax), %edx
    61d8:      	testl	%edx, %edx
    61da:      	je	0x6318 <generic_usdt_process_filter+0x2388>
    61e0:      	cmpl	0x2c(%rsi), %edx
    61e3:      	je	0x631f <generic_usdt_process_filter+0x238f>
    61e9:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    61ee:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    61f4:      	xorl	%r14d, %r14d
    61f7:      	movq	0x38(%rsp), %rax
    61fc:      	movl	0x10(%rax), %eax
    61ff:      	movl	%eax, 0x60(%rsp)
    6203:      	movl	$0x1, %eax
    6208:      	movq	(%rip), %rdi            # 0x620f <generic_usdt_process_filter+0x227f>
    620f:      	leaq	0x60(%rsp), %rsi
    6214:      	callq	*%rax
    6216:      	testq	%rax, %rax
    6219:      	je	0x6258 <generic_usdt_process_filter+0x22c8>
    621b:      	movq	%rax, %rbx
    621e:      	leaq	0x70(%rax), %rsi
    6222:      	movl	$0x1, %eax
    6227:      	movq	(%rip), %rdi            # 0x622e <generic_usdt_process_filter+0x229e>
    622e:      	callq	*%rax
    6230:      	testq	%rax, %rax
    6233:      	je	0x6245 <generic_usdt_process_filter+0x22b5>
    6235:      	movq	(%rax), %rax
    6238:      	testq	%rax, %rax
    623b:      	je	0x6245 <generic_usdt_process_filter+0x22b5>
    623d:      	lock
    623e:      	orq	%rax, 0x308(%rbp)
    6245:      	subl	$0x1, %r15d
    6249:      	setb	%al
    624c:      	cmpq	%r14, %rbx
    624f:      	je	0x6258 <generic_usdt_process_filter+0x22c8>
    6251:      	movq	%rbx, %r14
    6254:      	testb	%al, %al
    6256:      	je	0x61f7 <generic_usdt_process_filter+0x2267>
    6258:      	movq	0xb0(%rsp), %rax
    6260:      	movq	(%rax), %rax
    6263:      	movq	%rax, 0x310(%rbp)
    626a:      	movl	0x8(%r12), %eax
    626f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6274:      	cmpq	%rcx, %rax
    6277:      	je	0x6292 <generic_usdt_process_filter+0x2302>
    6279:      	movq	0x308(%rbp), %rcx
    6280:      	btq	%rax, %rcx
    6284:      	jae	0x6292 <generic_usdt_process_filter+0x2302>
    6286:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6290:      	jmp	0x62bf <generic_usdt_process_filter+0x232f>
    6292:      	movq	(%rip), %rdi            # 0x6299 <generic_usdt_process_filter+0x2309>
    6299:      	leaq	0x10(%rsp), %rsi
    629e:      	movl	$0x1, %eax
    62a3:      	callq	*%rax
    62a5:      	testq	%rax, %rax
    62a8:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    62ae:      	movq	%rax, %rdi
    62b1:      	addq	$0x8, %rbp
    62b5:      	movl	$0x1, %eax
    62ba:      	movq	%rbp, %rsi
    62bd:      	callq	*%rax
    62bf:      	movl	(%r12), %ecx
    62c3:      	cmpq	$0x25, %rcx
    62c7:      	movq	0x8(%rsp), %r10
    62cc:      	ja	0x62ec <generic_usdt_process_filter+0x235c>
    62ce:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    62d8:      	btq	%rcx, %rdx
    62dc:      	jae	0x62ec <generic_usdt_process_filter+0x235c>
    62de:      	testq	%rax, %rax
    62e1:      	jne	0x655b <generic_usdt_process_filter+0x25cb>
    62e7:      	jmp	0x54a5 <generic_usdt_process_filter+0x1515>
    62ec:      	testq	%rax, %rax
    62ef:      	jne	0x54a5 <generic_usdt_process_filter+0x1515>
    62f5:      	jmp	0x655b <generic_usdt_process_filter+0x25cb>
    62fa:      	movq	$0x1, (%rcx)
    6301:      	testb	$0x10, %bpl
    6305:      	jne	0x633d <generic_usdt_process_filter+0x23ad>
    6307:      	movl	0x38(%rax), %edx
    630a:      	testl	%edx, %edx
    630c:      	je	0x6336 <generic_usdt_process_filter+0x23a6>
    630e:      	cmpl	0x30(%rsi), %edx
    6311:      	je	0x633d <generic_usdt_process_filter+0x23ad>
    6313:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6318:      	movq	$0x1, (%rcx)
    631f:      	testb	$0x10, %bpl
    6323:      	je	0x635b <generic_usdt_process_filter+0x23cb>
    6325:      	movl	0x38(%rax), %edx
    6328:      	testl	%edx, %edx
    632a:      	je	0x6354 <generic_usdt_process_filter+0x23c4>
    632c:      	cmpl	0x30(%rsi), %edx
    632f:      	je	0x635b <generic_usdt_process_filter+0x23cb>
    6331:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6336:      	movq	$0x1, (%rcx)
    633d:      	testb	$0x20, %bpl
    6341:      	jne	0x6379 <generic_usdt_process_filter+0x23e9>
    6343:      	movl	0x3c(%rax), %edx
    6346:      	testl	%edx, %edx
    6348:      	je	0x6372 <generic_usdt_process_filter+0x23e2>
    634a:      	cmpl	0x34(%rsi), %edx
    634d:      	je	0x6379 <generic_usdt_process_filter+0x23e9>
    634f:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6354:      	movq	$0x1, (%rcx)
    635b:      	testb	$0x20, %bpl
    635f:      	je	0x6397 <generic_usdt_process_filter+0x2407>
    6361:      	movl	0x3c(%rax), %edx
    6364:      	testl	%edx, %edx
    6366:      	je	0x6390 <generic_usdt_process_filter+0x2400>
    6368:      	cmpl	0x34(%rsi), %edx
    636b:      	je	0x6397 <generic_usdt_process_filter+0x2407>
    636d:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6372:      	movq	$0x1, (%rcx)
    6379:      	testb	$0x40, %bpl
    637d:      	jne	0x63b5 <generic_usdt_process_filter+0x2425>
    637f:      	movl	0x40(%rax), %edx
    6382:      	testl	%edx, %edx
    6384:      	je	0x63ae <generic_usdt_process_filter+0x241e>
    6386:      	cmpl	0x38(%rsi), %edx
    6389:      	je	0x63b5 <generic_usdt_process_filter+0x2425>
    638b:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6390:      	movq	$0x1, (%rcx)
    6397:      	testb	$0x40, %bpl
    639b:      	je	0x63d2 <generic_usdt_process_filter+0x2442>
    639d:      	movl	0x40(%rax), %edx
    63a0:      	testl	%edx, %edx
    63a2:      	je	0x63cb <generic_usdt_process_filter+0x243b>
    63a4:      	cmpl	0x38(%rsi), %edx
    63a7:      	je	0x63d2 <generic_usdt_process_filter+0x2442>
    63a9:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    63ae:      	movq	$0x1, (%rcx)
    63b5:      	testb	%bpl, %bpl
    63b8:      	js	0x63ec <generic_usdt_process_filter+0x245c>
    63ba:      	movl	0x44(%rax), %edx
    63bd:      	testl	%edx, %edx
    63bf:      	je	0x63e5 <generic_usdt_process_filter+0x2455>
    63c1:      	cmpl	0x3c(%rsi), %edx
    63c4:      	je	0x63ec <generic_usdt_process_filter+0x245c>
    63c6:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    63cb:      	movq	$0x1, (%rcx)
    63d2:      	testb	%bpl, %bpl
    63d5:      	jns	0x6409 <generic_usdt_process_filter+0x2479>
    63d7:      	movl	0x44(%rax), %edx
    63da:      	testl	%edx, %edx
    63dc:      	je	0x6402 <generic_usdt_process_filter+0x2472>
    63de:      	cmpl	0x3c(%rsi), %edx
    63e1:      	je	0x6409 <generic_usdt_process_filter+0x2479>
    63e3:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    63e5:      	movq	$0x1, (%rcx)
    63ec:      	testl	$0x100, %ebp            # imm = 0x100
    63f2:      	jne	0x6432 <generic_usdt_process_filter+0x24a2>
    63f4:      	movl	0x48(%rax), %edx
    63f7:      	testl	%edx, %edx
    63f9:      	je	0x642b <generic_usdt_process_filter+0x249b>
    63fb:      	cmpl	0x40(%rsi), %edx
    63fe:      	je	0x6432 <generic_usdt_process_filter+0x24a2>
    6400:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    6402:      	movq	$0x1, (%rcx)
    6409:      	testl	$0x100, %ebp            # imm = 0x100
    640f:      	je	0x6541 <generic_usdt_process_filter+0x25b1>
    6415:      	movl	0x48(%rax), %edx
    6418:      	testl	%edx, %edx
    641a:      	je	0x653a <generic_usdt_process_filter+0x25aa>
    6420:      	cmpl	0x40(%rsi), %edx
    6423:      	je	0x6541 <generic_usdt_process_filter+0x25b1>
    6429:      	jmp	0x6457 <generic_usdt_process_filter+0x24c7>
    642b:      	movq	$0x1, (%rcx)
    6432:      	testl	$0x200, %ebp            # imm = 0x200
    6438:      	jne	0x655b <generic_usdt_process_filter+0x25cb>
    643e:      	movl	0x4c(%rax), %eax
    6441:      	testl	%eax, %eax
    6443:      	je	0x6554 <generic_usdt_process_filter+0x25c4>
    6449:      	movq	0x50(%rsp), %rdx
    644e:      	cmpl	0x44(%rdx), %eax
    6451:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    6457:      	addl	$0xc, %ebx
    645a:      	movq	$0x1, (%rcx)
    6461:      	movl	%ebx, %eax
    6463:      	movl	%eax, %ecx
    6465:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    646b:      	cmpl	$0x4, (%rcx,%r10)
    6470:      	movq	0x50(%rsp), %rcx
    6475:      	jne	0x649c <generic_usdt_process_filter+0x250c>
    6477:      	movq	0x5eb8(%rcx), %rax
    647e:      	andl	$0x1f, %eax
    6481:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6489:      	movb	$0x1, 0x5ee0(%rcx)
    6490:      	movb	$0x1, 0x5ec0(%rcx)
    6497:      	jmp	0x655b <generic_usdt_process_filter+0x25cb>
    649c:      	addl	$0x4, %eax
    649f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    64a4:      	movl	(%rax,%r10), %r14d
    64a8:      	movl	0x4(%rax,%r10), %ebx
    64ad:      	movl	0x8(%rax,%r10), %ebp
    64b2:      	movq	0xc(%rax,%r10), %r15
    64b7:      	movl	$0xe, %eax
    64bc:      	callq	*%rax
    64be:      	shrq	$0x20, %rax
    64c2:      	movl	%eax, 0x60(%rsp)
    64c6:      	movq	(%rip), %rdi            # 0x64cd <generic_usdt_process_filter+0x253d>
    64cd:      	leaq	0x60(%rsp), %rsi
    64d2:      	movl	$0x1, %eax
    64d7:      	callq	*%rax
    64d9:      	testq	%rax, %rax
    64dc:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    64de:      	testl	%ebp, %ebp
    64e0:      	je	0x64f4 <generic_usdt_process_filter+0x2564>
    64e2:      	cmpl	$0x2, %r14d
    64e6:      	ja	0x655b <generic_usdt_process_filter+0x25cb>
    64e8:      	movq	0x50(%rsp), %rcx
    64ed:      	cmpl	%ebp, 0x44(%rcx)
    64f0:      	jne	0x64fa <generic_usdt_process_filter+0x256a>
    64f2:      	jmp	0x655b <generic_usdt_process_filter+0x25cb>
    64f4:      	cmpl	$0x2, %r14d
    64f8:      	ja	0x655b <generic_usdt_process_filter+0x25cb>
    64fa:      	movq	0x50(%rax,%r14,8), %rax
    64ff:      	movq	0x50(%rsp), %rcx
    6504:      	movq	0x48(%rcx,%r14,8), %rcx
    6509:      	movq	%rcx, %rdx
    650c:      	xorq	%rax, %rdx
    650f:      	testq	%r15, %rdx
    6512:      	je	0x651b <generic_usdt_process_filter+0x258b>
    6514:      	cmpl	$0x5, %ebx
    6517:      	jne	0x655b <generic_usdt_process_filter+0x25cb>
    6519:      	jmp	0x6525 <generic_usdt_process_filter+0x2595>
    651b:      	cmpq	%rcx, %rax
    651e:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    6520:      	cmpl	$0x6, %ebx
    6523:      	jne	0x655b <generic_usdt_process_filter+0x25cb>
    6525:      	movq	0x50(%rsp), %rcx
    652a:      	movq	$0x1, 0x5ef0(%rcx)
    6535:      	jmp	0x6477 <generic_usdt_process_filter+0x24e7>
    653a:      	movq	$0x1, (%rcx)
    6541:      	testl	$0x200, %ebp            # imm = 0x200
    6547:      	je	0x655b <generic_usdt_process_filter+0x25cb>
    6549:      	movl	0x4c(%rax), %eax
    654c:      	testl	%eax, %eax
    654e:      	jne	0x6449 <generic_usdt_process_filter+0x24b9>
    6554:      	movq	$0x1, (%rcx)
    655b:      	movq	0x50(%rsp), %rcx
    6560:      	movq	0x5eb8(%rcx), %rax
    6567:      	incq	%rax
    656a:      	movq	%rax, 0x5eb8(%rcx)
    6571:      	cmpq	0xc0(%rsp), %rax
    6579:      	jbe	0x65c7 <generic_usdt_process_filter+0x2637>
    657b:      	movq	0x38(%rsp), %rdx
    6580:      	movl	(%rdx), %eax
    6582:      	movl	%eax, 0x10(%rcx)
    6585:      	movq	0x8(%rdx), %rax
    6589:      	movq	%rax, 0x18(%rcx)
    658d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6594:      	movq	0xb8(%rsp), %rbx
    659c:      	je	0x65b3 <generic_usdt_process_filter+0x2623>
    659e:      	movq	(%rip), %rsi            # 0x65a5 <generic_usdt_process_filter+0x2615>
    65a5:      	xorl	%ecx, %ecx
    65a7:      	movl	$0xc, %eax
    65ac:      	movq	%rbx, %rdi
    65af:      	xorl	%edx, %edx
    65b1:      	callq	*%rax
    65b3:      	xorl	%eax, %eax
    65b5:      	addq	$0xe8, %rsp
    65bc:      	popq	%rbx
    65bd:      	popq	%r12
    65bf:      	popq	%r13
    65c1:      	popq	%r14
    65c3:      	popq	%r15
    65c5:      	popq	%rbp
    65c6:      	retq
    65c7:      	movq	(%rip), %rsi            # 0x65ce <generic_usdt_process_filter+0x263e>
    65ce:      	movl	$0x2, %ecx
    65d3:      	movl	$0xc, %eax
    65d8:      	movq	0xb8(%rsp), %rdi
    65e0:      	movl	$0x2, %edx
    65e5:      	jmp	0x65b1 <generic_usdt_process_filter+0x2621>
    65e7:      	nopw	(%rax,%rax)

00000000000065f0 <generic_usdt_filter_arg>:
    65f0:      	pushq	%rbp
    65f1:      	pushq	%r15
    65f3:      	pushq	%r14
    65f5:      	pushq	%r13
    65f7:      	pushq	%r12
    65f9:      	pushq	%rbx
    65fa:      	subq	$0x28, %rsp
    65fe:      	movq	%rdi, %rbx
    6601:      	movl	$0x0, 0xc(%rsp)
    6609:      	movq	(%rip), %rdi            # 0x6610 <generic_usdt_filter_arg+0x20>
    6610:      	leaq	0xc(%rsp), %rsi
    6615:      	movl	$0x1, %eax
    661a:      	callq	*%rax
    661c:      	testq	%rax, %rax
    661f:      	je	0x69ec <generic_usdt_filter_arg+0x3fc>
    6625:      	movq	%rax, %r14
    6628:      	movl	0x5f00(%rax), %r12d
    662f:      	leaq	0x5ef8(%rax), %rsi
    6636:      	movq	(%rip), %rdi            # 0x663d <generic_usdt_filter_arg+0x4d>
    663d:      	movl	$0x1, %eax
    6642:      	callq	*%rax
    6644:      	testq	%rax, %rax
    6647:      	je	0x69d1 <generic_usdt_filter_arg+0x3e1>
    664d:      	cmpb	$0x0, 0x5ee0(%r14)
    6655:      	je	0x69d1 <generic_usdt_filter_arg+0x3e1>
    665b:      	movq	%rax, %r15
    665e:      	movl	%r12d, %eax
    6661:      	andl	$0x7, %eax
    6664:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    666d:      	je	0x66fc <generic_usdt_filter_arg+0x10c>
    6673:      	movl	%eax, %eax
    6675:      	movl	0x4(%r15,%rax,4), %ecx
    667a:      	leaq	(%rcx,%rax,4), %rdx
    667e:      	addq	$0x4, %rdx
    6682:      	leaq	(%rcx,%rax,4), %rax
    6686:      	addq	$0x8, %rax
    668a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    668f:      	movl	(%rax,%r15), %eax
    6693:      	addq	%rdx, %rax
    6696:      	addq	$0x4, %rax
    669a:      	movl	%eax, %ecx
    669c:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    66a2:      	movl	(%rcx,%r15), %ecx
    66a6:      	addq	%rax, %rcx
    66a9:      	movl	%ecx, %eax
    66ab:      	andl	$0x3ff, %eax            # imm = 0x3FF
    66b0:      	movl	(%rax,%r15), %eax
    66b4:      	addq	%rcx, %rax
    66b7:      	movl	%eax, %ecx
    66b9:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    66bf:      	movl	(%rcx,%r15), %ecx
    66c3:      	addq	%rax, %rcx
    66c6:      	movl	%ecx, %eax
    66c8:      	andl	$0x3ff, %eax            # imm = 0x3FF
    66cd:      	movl	(%rax,%r15), %ebp
    66d1:      	addq	%rcx, %rbp
    66d4:      	movl	%ebp, %eax
    66d6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    66db:      	movq	%rax, (%rsp)
    66df:      	cmpl	$0x19, (%r15,%rax)
    66e4:      	jae	0x6751 <generic_usdt_filter_arg+0x161>
    66e6:      	movq	(%rsp), %rax
    66ea:      	cmpq	$0x1, %rax
    66ee:      	je	0x69d1 <generic_usdt_filter_arg+0x3e1>
    66f4:      	testl	%eax, %eax
    66f6:      	jne	0x69ab <generic_usdt_filter_arg+0x3bb>
    66fc:      	cmpl	$0x1, %r12d
    6700:      	jg	0x6721 <generic_usdt_filter_arg+0x131>
    6702:      	cmpl	$-0x1, %r12d
    6706:      	je	0x69fd <generic_usdt_filter_arg+0x40d>
    670c:      	testl	%r12d, %r12d
    670f:      	je	0x6a0a <generic_usdt_filter_arg+0x41a>
    6715:      	cmpl	$0x1, %r12d
    6719:      	je	0x6a1a <generic_usdt_filter_arg+0x42a>
    671f:      	jmp	0x673f <generic_usdt_filter_arg+0x14f>
    6721:      	cmpl	$0x2, %r12d
    6725:      	je	0x6a2a <generic_usdt_filter_arg+0x43a>
    672b:      	cmpl	$0x3, %r12d
    672f:      	je	0x6a3a <generic_usdt_filter_arg+0x44a>
    6735:      	cmpl	$0x4, %r12d
    6739:      	je	0x6a4a <generic_usdt_filter_arg+0x45a>
    673f:      	cmpl	$0x4, %r12d
    6743:      	jg	0x6a7c <generic_usdt_filter_arg+0x48c>
    6749:      	incl	%r12d
    674c:      	jmp	0x6a5a <generic_usdt_filter_arg+0x46a>
    6751:      	movq	(%rsp), %rax
    6755:      	addq	%r15, %rax
    6758:      	movq	%rax, 0x10(%rsp)
    675d:      	movl	$0x1, %r13d
    6763:      	nopw	%cs:(%rax,%rax)
    6770:      	movq	0x10(%rsp), %rax
    6775:      	movl	(%rax,%r13,4), %edi
    6779:      	testl	$0x3ff, %edi            # imm = 0x3FF
    677f:      	je	0x66e6 <generic_usdt_filter_arg+0xf6>
    6785:      	addl	%ebp, %edi
    6787:      	andl	$0x3ff, %edi            # imm = 0x3FF
    678d:      	movl	0x4(%r15,%rdi), %ecx
    6792:      	cmpl	$0x23, %ecx
    6795:      	je	0x66fc <generic_usdt_filter_arg+0x10c>
    679b:      	addq	%r15, %rdi
    679e:      	movl	(%rdi), %eax
    67a0:      	cmpq	$0x4, %rax
    67a4:      	ja	0x66fc <generic_usdt_filter_arg+0x10c>
    67aa:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
    67b3:      	jne	0x66fc <generic_usdt_filter_arg+0x10c>
    67b9:      	movq	0x5e78(%r14,%rax,8), %rax
    67c1:      	andl	$0x7ff, %eax            # imm = 0x7FF
    67c6:      	leaq	(%r14,%rax), %rsi
    67ca:      	addq	$0x90, %rsi
    67d1:      	movl	0xc(%rdi), %eax
    67d4:      	cmpl	$0x1b, %eax
    67d7:      	jle	0x67f8 <generic_usdt_filter_arg+0x208>
    67d9:      	cmpl	$0x25, %eax
    67dc:      	jg	0x6828 <generic_usdt_filter_arg+0x238>
    67de:      	leal	-0x1c(%rax), %edx
    67e1:      	cmpl	$0x9, %edx
    67e4:      	jb	0x686e <generic_usdt_filter_arg+0x27e>
    67ea:      	cmpl	$0x25, %eax
    67ed:      	je	0x6951 <generic_usdt_filter_arg+0x361>
    67f3:      	jmp	0x6999 <generic_usdt_filter_arg+0x3a9>
    67f8:      	cmpl	$0x9, %eax
    67fb:      	jle	0x684e <generic_usdt_filter_arg+0x25e>
    67fd:      	leal	-0xa(%rax), %edx
    6800:      	cmpl	$0x4, %edx
    6803:      	jb	0x686e <generic_usdt_filter_arg+0x27e>
    6805:      	leal	-0xf(%rax), %ecx
    6808:      	cmpl	$0x2, %ecx
    680b:      	jb	0x6951 <generic_usdt_filter_arg+0x361>
    6811:      	cmpl	$0x11, %eax
    6814:      	jne	0x6999 <generic_usdt_filter_arg+0x3a9>
    681a:      	addq	$0x4, %rsi
    681e:      	callq	0x6823 <generic_usdt_filter_arg+0x233>
    6823:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    6828:      	cmpl	$0x29, %eax
    682b:      	jg	0x6940 <generic_usdt_filter_arg+0x350>
    6831:      	leal	-0x26(%rax), %ecx
    6834:      	cmpl	$0x2, %ecx
    6837:      	jb	0x68fb <generic_usdt_filter_arg+0x30b>
    683d:      	addl	$-0x28, %eax
    6840:      	cmpl	$0x2, %eax
    6843:      	jb	0x68f1 <generic_usdt_filter_arg+0x301>
    6849:      	jmp	0x6999 <generic_usdt_filter_arg+0x3a9>
    684e:      	cmpl	$0x4, %eax
    6851:      	jg	0x68de <generic_usdt_filter_arg+0x2ee>
    6857:      	cmpl	$0x1, %eax
    685a:      	je	0x686e <generic_usdt_filter_arg+0x27e>
    685c:      	cmpl	$0x2, %eax
    685f:      	je	0x696e <generic_usdt_filter_arg+0x37e>
    6865:      	cmpl	$0x4, %eax
    6868:      	jne	0x6999 <generic_usdt_filter_arg+0x3a9>
    686e:      	cmpl	$0xb, %eax
    6871:      	jle	0x68bb <generic_usdt_filter_arg+0x2cb>
    6873:      	cmpl	$0x24, %eax
    6876:      	ja	0x6958 <generic_usdt_filter_arg+0x368>
    687c:      	movl	%eax, %edx
    687e:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
    6888:      	btq	%rdx, %r8
    688c:      	jb	0x6902 <generic_usdt_filter_arg+0x312>
    688e:      	movl	$0x60000000, %ecx       # imm = 0x60000000
    6893:      	btq	%rdx, %rcx
    6897:      	jb	0x6967 <generic_usdt_filter_arg+0x377>
    689d:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
    68a7:      	btq	%rdx, %rcx
    68ab:      	jae	0x6958 <generic_usdt_filter_arg+0x368>
    68b1:      	callq	0x68b6 <generic_usdt_filter_arg+0x2c6>
    68b6:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    68bb:      	leal	-0xa(%rax), %ecx
    68be:      	cmpl	$0x2, %ecx
    68c1:      	jb	0x697f <generic_usdt_filter_arg+0x38f>
    68c7:      	cmpl	$0x1, %eax
    68ca:      	je	0x6960 <generic_usdt_filter_arg+0x370>
    68d0:      	cmpl	$0x4, %eax
    68d3:      	je	0x6960 <generic_usdt_filter_arg+0x370>
    68d9:      	jmp	0x6999 <generic_usdt_filter_arg+0x3a9>
    68de:      	cmpl	$0x5, %eax
    68e1:      	je	0x68f1 <generic_usdt_filter_arg+0x301>
    68e3:      	cmpl	$0x6, %eax
    68e6:      	je	0x68fb <generic_usdt_filter_arg+0x30b>
    68e8:      	cmpl	$0x7, %eax
    68eb:      	jne	0x6999 <generic_usdt_filter_arg+0x3a9>
    68f1:      	callq	0x68f6 <generic_usdt_filter_arg+0x306>
    68f6:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    68fb:      	movl	$0x4, %edx
    6900:      	jmp	0x6973 <generic_usdt_filter_arg+0x383>
    6902:      	cmpl	$0x1e, %ecx
    6905:      	jne	0x697f <generic_usdt_filter_arg+0x38f>
    6907:      	movl	0x10(%rdi), %eax
    690a:      	andl	$0x7, %eax
    690d:      	movl	%eax, %ecx
    690f:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6918:      	jne	0x66fc <generic_usdt_filter_arg+0x10c>
    691e:      	movq	(%rsi), %rcx
    6921:      	movq	0x5e78(%r14,%rax,8), %rdx
    6929:      	andl	$0x7ff, %edx            # imm = 0x7FF
    692f:      	xorl	%eax, %eax
    6931:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
    693b:      	setne	%al
    693e:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    6940:      	cmpl	$0x2a, %eax
    6943:      	je	0x6951 <generic_usdt_filter_arg+0x361>
    6945:      	cmpl	$0x2c, %eax
    6948:      	jne	0x6999 <generic_usdt_filter_arg+0x3a9>
    694a:      	callq	0x694f <generic_usdt_filter_arg+0x35f>
    694f:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    6951:      	callq	0x6956 <generic_usdt_filter_arg+0x366>
    6956:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    6958:      	leal	-0xc(%rax), %ecx
    695b:      	cmpl	$0x2, %ecx
    695e:      	jae	0x697a <generic_usdt_filter_arg+0x38a>
    6960:      	callq	0x6965 <generic_usdt_filter_arg+0x375>
    6965:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    6967:      	callq	0x696c <generic_usdt_filter_arg+0x37c>
    696c:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    696e:      	movl	$0x8, %edx
    6973:      	callq	0x6978 <generic_usdt_filter_arg+0x388>
    6978:      	jmp	0x6990 <generic_usdt_filter_arg+0x3a0>
    697a:      	cmpl	$0x1c, %eax
    697d:      	jne	0x6999 <generic_usdt_filter_arg+0x3a9>
    697f:      	callq	0x6984 <generic_usdt_filter_arg+0x394>
    6984:      	nopw	%cs:(%rax,%rax)
    6990:      	testq	%rax, %rax
    6993:      	je	0x66fc <generic_usdt_filter_arg+0x10c>
    6999:      	incq	%r13
    699c:      	cmpq	$0x6, %r13
    69a0:      	jne	0x6770 <generic_usdt_filter_arg+0x180>
    69a6:      	jmp	0x66e6 <generic_usdt_filter_arg+0xf6>
    69ab:      	movq	(%rsp), %rax
    69af:      	movl	%eax, 0x5f04(%r14)
    69b6:      	movq	(%rip), %rsi            # 0x69bd <generic_usdt_filter_arg+0x3cd>
    69bd:      	movl	$0x4, %ecx
    69c2:      	movl	$0xc, %eax
    69c7:      	movq	%rbx, %rdi
    69ca:      	movl	$0x4, %edx
    69cf:      	callq	*%rax
    69d1:      	movq	(%rip), %rsi            # 0x69d8 <generic_usdt_filter_arg+0x3e8>
    69d8:      	movl	$0x5, %ecx
    69dd:      	movl	$0xc, %eax
    69e2:      	movq	%rbx, %rdi
    69e5:      	movl	$0x5, %edx
    69ea:      	callq	*%rax
    69ec:      	xorl	%eax, %eax
    69ee:      	addq	$0x28, %rsp
    69f2:      	popq	%rbx
    69f3:      	popq	%r12
    69f5:      	popq	%r13
    69f7:      	popq	%r14
    69f9:      	popq	%r15
    69fb:      	popq	%rbp
    69fc:      	retq
    69fd:      	xorl	%r12d, %r12d
    6a00:      	cmpb	$0x0, 0x5ec1(%r14)
    6a08:      	jne	0x6a5a <generic_usdt_filter_arg+0x46a>
    6a0a:      	movl	$0x1, %r12d
    6a10:      	cmpb	$0x0, 0x5ec2(%r14)
    6a18:      	jne	0x6a5a <generic_usdt_filter_arg+0x46a>
    6a1a:      	movl	$0x2, %r12d
    6a20:      	cmpb	$0x0, 0x5ec3(%r14)
    6a28:      	jne	0x6a5a <generic_usdt_filter_arg+0x46a>
    6a2a:      	movl	$0x3, %r12d
    6a30:      	cmpb	$0x0, 0x5ec4(%r14)
    6a38:      	jne	0x6a5a <generic_usdt_filter_arg+0x46a>
    6a3a:      	movl	$0x4, %r12d
    6a40:      	cmpb	$0x0, 0x5ec5(%r14)
    6a48:      	jne	0x6a5a <generic_usdt_filter_arg+0x46a>
    6a4a:      	movl	$0x5, %r12d
    6a50:      	cmpb	$0x0, 0x5ec6(%r14)
    6a58:      	je	0x6a7c <generic_usdt_filter_arg+0x48c>
    6a5a:      	movl	%r12d, 0x5f00(%r14)
    6a61:      	movq	(%rip), %rsi            # 0x6a68 <generic_usdt_filter_arg+0x478>
    6a68:      	movl	$0x3, %ecx
    6a6d:      	movl	$0xc, %eax
    6a72:      	movq	%rbx, %rdi
    6a75:      	movl	$0x3, %edx
    6a7a:      	callq	*%rax
    6a7c:      	movq	0x60(%r14), %rbx
    6a80:      	movl	$0xe, %eax
    6a85:      	callq	*%rax
    6a87:      	movq	%rbx, 0x18(%rsp)
    6a8c:      	movq	%rax, 0x20(%rsp)
    6a91:      	movq	(%rip), %rdi            # 0x6a98 <generic_usdt_filter_arg+0x4a8>
    6a98:      	leaq	0x18(%rsp), %rsi
    6a9d:      	movl	$0x1, %eax
    6aa2:      	callq	*%rax
    6aa4:      	testq	%rax, %rax
    6aa7:      	je	0x69ec <generic_usdt_filter_arg+0x3fc>
    6aad:      	movq	(%rip), %rdi            # 0x6ab4 <generic_usdt_filter_arg+0x4c4>
    6ab4:      	leaq	0x18(%rsp), %rsi
    6ab9:      	movl	$0x3, %eax
    6abe:      	callq	*%rax
    6ac0:      	jmp	0x69ec <generic_usdt_filter_arg+0x3fc>
    6ac5:      	nopw	%cs:(%rax,%rax)

0000000000006ad0 <generic_usdt_actions>:
    6ad0:      	pushq	%rbp
    6ad1:      	pushq	%r14
    6ad3:      	pushq	%rbx
    6ad4:      	subq	$0x10, %rsp
    6ad8:      	movq	%rdi, %rbx
    6adb:      	movl	$0x0, 0x8(%rsp)
    6ae3:      	movq	(%rip), %rdi            # 0x6aea <generic_usdt_actions+0x1a>
    6aea:      	leaq	0x8(%rsp), %rsi
    6aef:      	movl	$0x1, %eax
    6af4:      	callq	*%rax
    6af6:      	testq	%rax, %rax
    6af9:      	je	0x6c02 <generic_usdt_actions+0x132>
    6aff:      	movq	%rax, %rsi
    6b02:      	movl	0x5f04(%rax), %r14d
    6b09:      	cmpl	$0x2, %r14d
    6b0d:      	jl	0x6c02 <generic_usdt_actions+0x132>
    6b13:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    6b1a:      	movq	(%rip), %rdi            # 0x6b21 <generic_usdt_actions+0x51>
    6b21:      	movl	$0x1, %eax
    6b26:      	callq	*%rax
    6b28:      	testq	%rax, %rax
    6b2b:      	je	0x6c02 <generic_usdt_actions+0x132>
    6b31:      	movl	%r14d, %ecx
    6b34:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6b3a:      	addl	(%rax,%rcx), %r14d
    6b3e:      	movb	$0x1, 0x7(%rsp)
    6b43:      	movl	$0x0, 0xc(%rsp)
    6b4b:      	movq	(%rip), %rdi            # 0x6b52 <generic_usdt_actions+0x82>
    6b52:      	leaq	0xc(%rsp), %rsi
    6b57:      	movq	%rax, %rcx
    6b5a:      	movl	$0x1, %eax
    6b5f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
    6b66:      	addq	%rcx, %r14
    6b69:      	callq	*%rax
    6b6b:      	testq	%rax, %rax
    6b6e:      	je	0x6b7e <generic_usdt_actions+0xae>
    6b70:      	cmpb	$0x0, (%rax)
    6b73:      	sete	%al
    6b76:      	cmpl	$0x5, (%r14)
    6b7a:      	jae	0x6b86 <generic_usdt_actions+0xb6>
    6b7c:      	jmp	0x6be0 <generic_usdt_actions+0x110>
    6b7e:      	movb	$0x1, %al
    6b80:      	cmpl	$0x5, (%r14)
    6b84:      	jb	0x6be0 <generic_usdt_actions+0x110>
    6b86:      	movzbl	%al, %ebp
    6b89:      	leaq	0x7(%rsp), %rcx
    6b8e:      	movq	%rbx, %rdi
    6b91:      	xorl	%esi, %esi
    6b93:      	movq	%r14, %rdx
    6b96:      	movl	%ebp, %r8d
    6b99:      	callq	0x6b9e <generic_usdt_actions+0xce>
    6b9e:      	leal	0x4(,%rax,4), %ecx
    6ba5:      	cmpl	(%r14), %ecx
    6ba8:      	jae	0x6be0 <generic_usdt_actions+0x110>
    6baa:      	leaq	0x7(%rsp), %rcx
    6baf:      	movq	%rbx, %rdi
    6bb2:      	movl	%eax, %esi
    6bb4:      	movq	%r14, %rdx
    6bb7:      	movl	%ebp, %r8d
    6bba:      	callq	0x6bbf <generic_usdt_actions+0xef>
    6bbf:      	leal	0x4(,%rax,4), %ecx
    6bc6:      	cmpl	(%r14), %ecx
    6bc9:      	jae	0x6be0 <generic_usdt_actions+0x110>
    6bcb:      	leaq	0x7(%rsp), %rcx
    6bd0:      	movq	%rbx, %rdi
    6bd3:      	movl	%eax, %esi
    6bd5:      	movq	%r14, %rdx
    6bd8:      	movl	%ebp, %r8d
    6bdb:      	callq	0x6be0 <generic_usdt_actions+0x110>
    6be0:      	cmpb	$0x0, 0x7(%rsp)
    6be5:      	je	0x6c02 <generic_usdt_actions+0x132>
    6be7:      	movq	(%rip), %rsi            # 0x6bee <generic_usdt_actions+0x11e>
    6bee:      	movl	$0x5, %ecx
    6bf3:      	movl	$0xc, %eax
    6bf8:      	movq	%rbx, %rdi
    6bfb:      	movl	$0x5, %edx
    6c00:      	callq	*%rax
    6c02:      	xorl	%eax, %eax
    6c04:      	addq	$0x10, %rsp
    6c08:      	popq	%rbx
    6c09:      	popq	%r14
    6c0b:      	popq	%rbp
    6c0c:      	retq
    6c0d:      	nopl	(%rax)

0000000000006c10 <generic_usdt_output>:
    6c10:      	pushq	%rbp
    6c11:      	pushq	%r15
    6c13:      	pushq	%r14
    6c15:      	pushq	%r13
    6c17:      	pushq	%r12
    6c19:      	pushq	%rbx
    6c1a:      	subq	$0x78, %rsp
    6c1e:      	movq	%rdi, %r14
    6c21:      	movl	$0x0, 0x24(%rsp)
    6c29:      	movq	(%rip), %rdi            # 0x6c30 <generic_usdt_output+0x20>
    6c30:      	leaq	0x24(%rsp), %rsi
    6c35:      	movl	$0x1, %eax
    6c3a:      	callq	*%rax
    6c3c:      	testq	%rax, %rax
    6c3f:      	je	0x70e9 <generic_usdt_output+0x4d9>
    6c45:      	movq	%rax, %rbx
    6c48:      	cmpq	$0x0, 0x5ee8(%rax)
    6c50:      	je	0x6f58 <generic_usdt_output+0x348>
    6c56:      	movl	$0xe, %eax
    6c5b:      	callq	*%rax
    6c5d:      	movq	%rax, %r15
    6c60:      	shrq	$0x20, %r15
    6c64:      	movl	$0x23, %eax
    6c69:      	callq	*%rax
    6c6b:      	movq	%rax, %r12
    6c6e:      	movl	%r15d, 0x28(%rsp)
    6c73:      	movq	(%rip), %rdi            # 0x6c7a <generic_usdt_output+0x6a>
    6c7a:      	leaq	0x28(%rsp), %rsi
    6c7f:      	movl	$0x1, %eax
    6c84:      	callq	*%rax
    6c86:      	testq	%rax, %rax
    6c89:      	je	0x6f58 <generic_usdt_output+0x348>
    6c8f:      	movq	%rax, %r15
    6c92:      	leaq	0xd70(%r12), %rdx
    6c9a:      	leaq	0x70(%rsp), %rdi
    6c9f:      	movl	$0x8, %ecx
    6ca4:      	movl	$0x4, %eax
    6ca9:      	leaq	0x28(%r15), %r13
    6cad:      	movl	$0x4, %ebp
    6cb2:      	movl	$0x8, %esi
    6cb7:      	callq	*%rax
    6cb9:      	movq	0x70(%rsp), %rcx
    6cbe:      	leaq	0x28(%rsp), %rdi
    6cc3:      	movl	$0x48, %edx
    6cc8:      	movl	$0x4, %eax
    6ccd:      	movq	0x70(%rsp), %rdx
    6cd2:      	movl	$0x48, %esi
    6cd7:      	callq	*%rax
    6cd9:      	movl	$0x218, %edx            # imm = 0x218
    6cde:      	movq	0x30(%rsp), %rcx
    6ce3:      	addq	%rdx, %rcx
    6ce6:      	movl	$0x4, %esi
    6ceb:      	movl	$0x4, %eax
    6cf0:      	addq	0x30(%rsp), %rdx
    6cf5:      	movq	%r13, %rdi
    6cf8:      	movl	$0x4, %esi
    6cfd:      	callq	*%rax
    6cff:      	leaq	0x2c(%r15), %rdi
    6d03:      	movl	$0x4d8, %edx            # imm = 0x4D8
    6d08:      	movq	0x38(%rsp), %rcx
    6d0d:      	addq	%rdx, %rcx
    6d10:      	movl	$0x4, %esi
    6d15:      	movl	$0x4, %eax
    6d1a:      	addq	0x38(%rsp), %rdx
    6d1f:      	movl	$0x4, %esi
    6d24:      	callq	*%rax
    6d26:      	leaq	0x30(%r15), %rdi
    6d2a:      	movq	0x40(%rsp), %rcx
    6d2f:      	addq	$0x58, %rcx
    6d33:      	movl	$0x4, %edx
    6d38:      	movl	$0x4, %eax
    6d3d:      	movq	0x40(%rsp), %rdx
    6d42:      	addq	$0x58, %rdx
    6d46:      	movl	$0x4, %esi
    6d4b:      	callq	*%rax
    6d4d:      	movq	$0x0, (%rsp)
    6d55:      	leaq	0xb58(%r12), %rdx
    6d5d:      	movq	%rsp, %rdi
    6d60:      	movl	$0x8, %ecx
    6d65:      	movl	$0x4, %eax
    6d6a:      	movl	$0x8, %esi
    6d6f:      	callq	*%rax
    6d71:      	movq	(%rsp), %rcx
    6d75:      	testq	%rcx, %rcx
    6d78:      	je	0x6e0b <generic_usdt_output+0x1fb>
    6d7e:      	movl	$0x0, 0xc(%rsp)
    6d86:      	addq	$0x4, %rcx
    6d8a:      	leaq	0xc(%rsp), %rdi
    6d8f:      	movl	$0x4, %eax
    6d94:      	movq	(%rsp), %rdx
    6d98:      	addq	$0x4, %rdx
    6d9c:      	movl	$0x4, %esi
    6da1:      	callq	*%rax
    6da3:      	movq	(%rsp), %rax
    6da7:      	movslq	0xc(%rsp), %rcx
    6dac:      	shlq	$0x4, %rcx
    6db0:      	addq	%rax, %rcx
    6db3:      	addq	$0x80, %rcx
    6dba:      	leaq	0x10(%rsp), %rdi
    6dbf:      	movl	$0x10, %edx
    6dc4:      	movl	$0x4, %eax
    6dc9:      	movq	(%rsp), %rcx
    6dcd:      	movslq	0xc(%rsp), %rdx
    6dd2:      	shlq	$0x4, %rdx
    6dd6:      	addq	%rcx, %rdx
    6dd9:      	addq	$0x80, %rdx
    6de0:      	movl	$0x10, %esi
    6de5:      	callq	*%rax
    6de7:      	leaq	0x34(%r15), %rdi
    6deb:      	movl	$0x158, %edx            # imm = 0x158
    6df0:      	movq	0x18(%rsp), %rcx
    6df5:      	addq	%rdx, %rcx
    6df8:      	movl	$0x4, %eax
    6dfd:      	addq	0x18(%rsp), %rdx
    6e02:      	movl	$0x4, %esi
    6e07:      	callq	*%rax
    6e09:      	jmp	0x6e13 <generic_usdt_output+0x203>
    6e0b:      	movl	$0x0, 0x34(%r15)
    6e13:      	leaq	0x38(%r15), %rdi
    6e17:      	movl	$0x158, %r13d           # imm = 0x158
    6e1d:      	movq	0x48(%rsp), %rcx
    6e22:      	addq	%r13, %rcx
    6e25:      	movl	$0x4, %edx
    6e2a:      	movl	$0x4, %eax
    6e2f:      	movq	0x48(%rsp), %rdx
    6e34:      	addq	%r13, %rdx
    6e37:      	movl	$0x4, %esi
    6e3c:      	callq	*%rax
    6e3e:      	leaq	0x3c(%r15), %rdi
    6e42:      	movl	$0x118, %edx            # imm = 0x118
    6e47:      	movq	0x50(%rsp), %rcx
    6e4c:      	addq	%rdx, %rcx
    6e4f:      	movl	$0x4, %esi
    6e54:      	movl	$0x4, %eax
    6e59:      	addq	0x50(%rsp), %rdx
    6e5e:      	movl	$0x4, %esi
    6e63:      	callq	*%rax
    6e65:      	leaq	0x40(%r15), %rdi
    6e69:      	movl	$0x98, %ebp
    6e6e:      	movq	0x58(%rsp), %rcx
    6e73:      	addq	%rbp, %rcx
    6e76:      	movl	$0x4, %edx
    6e7b:      	movl	$0x4, %eax
    6e80:      	movq	0x58(%rsp), %rdx
    6e85:      	addq	%rbp, %rdx
    6e88:      	movl	$0x4, %esi
    6e8d:      	callq	*%rax
    6e8f:      	leaq	0x44(%r15), %rdi
    6e93:      	movq	0x60(%rsp), %rcx
    6e98:      	addq	%rbp, %rcx
    6e9b:      	movl	$0x4, %edx
    6ea0:      	movl	$0x4, %eax
    6ea5:      	addq	0x60(%rsp), %rbp
    6eaa:      	movl	$0x4, %esi
    6eaf:      	movq	%rbp, %rdx
    6eb2:      	callq	*%rax
    6eb4:      	leaq	0x48(%r15), %rdi
    6eb8:      	movq	0x68(%rsp), %rcx
    6ebd:      	addq	$0x58, %rcx
    6ec1:      	movl	$0x4, %edx
    6ec6:      	movl	$0x4, %eax
    6ecb:      	movq	0x68(%rsp), %rdx
    6ed0:      	addq	$0x58, %rdx
    6ed4:      	movl	$0x4, %esi
    6ed9:      	callq	*%rax
    6edb:      	movq	$0x0, 0x10(%rsp)
    6ee4:      	movq	$0x0, (%rsp)
    6eec:      	addq	$0xd00, %r12            # imm = 0xD00
    6ef3:      	leaq	0x10(%rsp), %rdi
    6ef8:      	movl	$0x8, %ecx
    6efd:      	movl	$0x4, %eax
    6f02:      	movl	$0x8, %esi
    6f07:      	movq	%r12, %rdx
    6f0a:      	callq	*%rax
    6f0c:      	movl	$0x90, %edx
    6f11:      	movq	0x10(%rsp), %rcx
    6f16:      	addq	%rdx, %rcx
    6f19:      	movq	%rsp, %rdi
    6f1c:      	movl	$0x8, %esi
    6f21:      	movl	$0x4, %eax
    6f26:      	addq	0x10(%rsp), %rdx
    6f2b:      	movl	$0x8, %esi
    6f30:      	callq	*%rax
    6f32:      	addq	$0x4c, %r15
    6f36:      	movq	(%rsp), %rcx
    6f3a:      	addq	%r13, %rcx
    6f3d:      	movl	$0x4, %edx
    6f42:      	movl	$0x4, %eax
    6f47:      	addq	(%rsp), %r13
    6f4b:      	movq	%r15, %rdi
    6f4e:      	movl	$0x4, %esi
    6f53:      	movq	%r13, %rdx
    6f56:      	callq	*%rax
    6f58:      	cmpq	$0x0, 0x5ef0(%rbx)
    6f60:      	je	0x7019 <generic_usdt_output+0x409>
    6f66:      	movl	$0xe, %eax
    6f6b:      	callq	*%rax
    6f6d:      	movq	%rax, %r15
    6f70:      	shrq	$0x20, %r15
    6f74:      	movl	$0x23, %eax
    6f79:      	callq	*%rax
    6f7b:      	movq	%rax, %r12
    6f7e:      	movl	%r15d, 0x28(%rsp)
    6f83:      	movq	(%rip), %rdi            # 0x6f8a <generic_usdt_output+0x37a>
    6f8a:      	leaq	0x28(%rsp), %rsi
    6f8f:      	movl	$0x1, %eax
    6f94:      	callq	*%rax
    6f96:      	testq	%rax, %rax
    6f99:      	je	0x7019 <generic_usdt_output+0x409>
    6f9b:      	leaq	0x50(%rax), %r15
    6f9f:      	addq	$0xd00, %r12            # imm = 0xD00
    6fa6:      	leaq	0x28(%rsp), %rdi
    6fab:      	movl	$0x8, %ecx
    6fb0:      	movq	%rax, %r13
    6fb3:      	movl	$0x4, %eax
    6fb8:      	movl	$0x8, %esi
    6fbd:      	movq	%r12, %rdx
    6fc0:      	callq	*%rax
    6fc2:      	movq	0x28(%rsp), %r12
    6fc7:      	leaq	0x58(%r13), %rdi
    6fcb:      	leaq	0x40(%r12), %rdx
    6fd0:      	movl	$0x8, %ecx
    6fd5:      	movl	$0x4, %eax
    6fda:      	movl	$0x8, %esi
    6fdf:      	callq	*%rax
    6fe1:      	addq	$0x60, %r13
    6fe5:      	leaq	0x30(%r12), %rdx
    6fea:      	movl	$0x8, %ecx
    6fef:      	movl	$0x4, %eax
    6ff4:      	movq	%r13, %rdi
    6ff7:      	movl	$0x8, %esi
    6ffc:      	callq	*%rax
    6ffe:      	addq	$0x38, %r12
    7002:      	movl	$0x8, %ecx
    7007:      	movl	$0x4, %eax
    700c:      	movq	%r15, %rdi
    700f:      	movl	$0x8, %esi
    7014:      	movq	%r12, %rdx
    7017:      	callq	*%rax
    7019:      	movl	$0x90, %eax
    701e:      	addl	0x4(%rbx), %eax
    7021:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    7026:      	cmpl	$0x2328, %eax           # imm = 0x2328
    702b:      	movl	$0x2328, %r15d          # imm = 0x2328
    7031:      	cmovbl	%eax, %r15d
    7035:      	movl	$0x0, 0x10(%rsp)
    703d:      	movq	(%rip), %rdi            # 0x7044 <generic_usdt_output+0x434>
    7044:      	leaq	0x10(%rsp), %rsi
    7049:      	movl	$0x1, %eax
    704e:      	callq	*%rax
    7050:      	testq	%rax, %rax
    7053:      	je	0x70a7 <generic_usdt_output+0x497>
    7055:      	cmpb	$0x0, 0x28(%rax)
    7059:      	je	0x70a7 <generic_usdt_output+0x497>
    705b:      	movq	(%rip), %rsi            # 0x7062 <generic_usdt_output+0x452>
    7062:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    7067:      	movl	$0x19, %eax
    706c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    7071:      	movq	%r14, %rdi
    7074:      	movq	%rbx, %rcx
    7077:      	movq	%r15, %r8
    707a:      	callq	*%rax
    707c:      	testq	%rax, %rax
    707f:      	js	0x7149 <generic_usdt_output+0x539>
    7085:      	movl	$0x0, 0x28(%rsp)
    708d:      	movq	(%rip), %rdi            # 0x7094 <generic_usdt_output+0x484>
    7094:      	leaq	0x28(%rsp), %rsi
    7099:      	movl	$0x1, %eax
    709e:      	callq	*%rax
    70a0:      	testq	%rax, %rax
    70a3:      	jne	0x70e4 <generic_usdt_output+0x4d4>
    70a5:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    70a7:      	movq	(%rip), %rdi            # 0x70ae <generic_usdt_output+0x49e>
    70ae:      	xorl	%ecx, %ecx
    70b0:      	movl	$0x82, %eax
    70b5:      	movq	%rbx, %rsi
    70b8:      	movq	%r15, %rdx
    70bb:      	xorl	%ecx, %ecx
    70bd:      	callq	*%rax
    70bf:      	testq	%rax, %rax
    70c2:      	js	0x70fa <generic_usdt_output+0x4ea>
    70c4:      	movl	$0x0, 0x28(%rsp)
    70cc:      	movq	(%rip), %rdi            # 0x70d3 <generic_usdt_output+0x4c3>
    70d3:      	leaq	0x28(%rsp), %rsi
    70d8:      	movl	$0x1, %eax
    70dd:      	callq	*%rax
    70df:      	testq	%rax, %rax
    70e2:      	je	0x70e9 <generic_usdt_output+0x4d9>
    70e4:      	lock
    70e5:      	incq	0x8(%rax)
    70e9:      	xorl	%eax, %eax
    70eb:      	addq	$0x78, %rsp
    70ef:      	popq	%rbx
    70f0:      	popq	%r12
    70f2:      	popq	%r13
    70f4:      	popq	%r14
    70f6:      	popq	%r15
    70f8:      	popq	%rbp
    70f9:      	retq
    70fa:      	movq	%rax, %rbx
    70fd:      	movl	$0x0, 0x28(%rsp)
    7105:      	movq	(%rip), %rdi            # 0x710c <generic_usdt_output+0x4fc>
    710c:      	leaq	0x28(%rsp), %rsi
    7111:      	movl	$0x1, %eax
    7116:      	callq	*%rax
    7118:      	testq	%rax, %rax
    711b:      	je	0x70e9 <generic_usdt_output+0x4d9>
    711d:      	cmpq	$-0xc, %rbx
    7121:      	jg	0x7191 <generic_usdt_output+0x581>
    7123:      	cmpq	$-0x1c, %rbx
    7127:      	je	0x71d3 <generic_usdt_output+0x5c3>
    712d:      	cmpq	$-0x16, %rbx
    7131:      	je	0x7182 <generic_usdt_output+0x572>
    7133:      	cmpq	$-0x10, %rbx
    7137:      	jne	0x71c4 <generic_usdt_output+0x5b4>
    713d:      	addq	$0x638, %rax            # imm = 0x638
    7143:      	lock
    7144:      	incq	(%rax)
    7147:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    7149:      	movq	%rax, %rbx
    714c:      	movl	$0x0, 0x28(%rsp)
    7154:      	movq	(%rip), %rdi            # 0x715b <generic_usdt_output+0x54b>
    715b:      	leaq	0x28(%rsp), %rsi
    7160:      	movl	$0x1, %eax
    7165:      	callq	*%rax
    7167:      	testq	%rax, %rax
    716a:      	je	0x70e9 <generic_usdt_output+0x4d9>
    7170:      	cmpq	$-0xc, %rbx
    7174:      	jg	0x71b2 <generic_usdt_output+0x5a2>
    7176:      	cmpq	$-0x1c, %rbx
    717a:      	je	0x71d3 <generic_usdt_output+0x5c3>
    717c:      	cmpq	$-0x16, %rbx
    7180:      	jne	0x7133 <generic_usdt_output+0x523>
    7182:      	addq	$0x640, %rax            # imm = 0x640
    7188:      	lock
    7189:      	incq	(%rax)
    718c:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    7191:      	cmpq	$-0xb, %rbx
    7195:      	je	0x71e2 <generic_usdt_output+0x5d2>
    7197:      	cmpq	$-0x7, %rbx
    719b:      	je	0x71f1 <generic_usdt_output+0x5e1>
    719d:      	cmpq	$-0x2, %rbx
    71a1:      	jne	0x71c4 <generic_usdt_output+0x5b4>
    71a3:      	addq	$0x628, %rax            # imm = 0x628
    71a9:      	lock
    71aa:      	incq	(%rax)
    71ad:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    71b2:      	cmpq	$-0xb, %rbx
    71b6:      	je	0x71e2 <generic_usdt_output+0x5d2>
    71b8:      	cmpq	$-0x7, %rbx
    71bc:      	je	0x71f1 <generic_usdt_output+0x5e1>
    71be:      	cmpq	$-0x2, %rbx
    71c2:      	je	0x71a3 <generic_usdt_output+0x593>
    71c4:      	addq	$0x620, %rax            # imm = 0x620
    71ca:      	lock
    71cb:      	incq	(%rax)
    71ce:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    71d3:      	addq	$0x648, %rax            # imm = 0x648
    71d9:      	lock
    71da:      	incq	(%rax)
    71dd:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    71e2:      	addq	$0x650, %rax            # imm = 0x650
    71e8:      	lock
    71e9:      	incq	(%rax)
    71ec:      	jmp	0x70e9 <generic_usdt_output+0x4d9>
    71f1:      	addq	$0x630, %rax            # imm = 0x630
    71f7:      	lock
    71f8:      	incq	(%rax)
    71fb:      	jmp	0x70e9 <generic_usdt_output+0x4d9>

Disassembly of section uprobe/generic_usdt:

0000000000000000 <generic_usdt_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_usdt_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x622 <generic_usdt_event+0x622>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_usdt_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x622 <generic_usdt_event+0x622>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_usdt_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_usdt_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x622 <generic_usdt_event+0x622>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_usdt_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_usdt_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_usdt_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_usdt_event+0x1f6>
      d3:      	jmp	0x622 <generic_usdt_event+0x622>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_usdt_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x622 <generic_usdt_event+0x622>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x622 <generic_usdt_event+0x622>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x622 <generic_usdt_event+0x622>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x622 <generic_usdt_event+0x622>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_usdt_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_usdt_event+0x1f6>
     1e1:      	jmp	0x622 <generic_usdt_event+0x622>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x622 <generic_usdt_event+0x622>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_usdt_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_usdt_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_usdt_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x636 <generic_usdt_event+0x636>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movq	$0x0, 0x5eb8(%r14)
     25f:      	movq	$0x0, 0x5ec0(%r14)
     26a:      	movq	$0x0, 0x5ec8(%r14)
     275:      	movq	$0x0, 0x5ed0(%r14)
     280:      	movq	$0x0, 0x5ed8(%r14)
     28b:      	movb	$0x0, 0x5ee0(%r14)
     293:      	movl	$0x23, %eax
     298:      	callq	*%rax
     29a:      	movq	%rax, %r15
     29d:      	leaq	0xd70(%rax), %rdx
     2a4:      	leaq	0x20(%rsp), %rdi
     2a9:      	movl	$0x8, %ecx
     2ae:      	movl	$0x4, %eax
     2b3:      	leaq	0x20(%r14), %r12
     2b7:      	movl	$0x4, %r13d
     2bd:      	movl	$0x8, %esi
     2c2:      	callq	*%rax
     2c4:      	movq	0x20(%rsp), %rcx
     2c9:      	leaq	0x40(%rsp), %rdi
     2ce:      	movl	$0x48, %edx
     2d3:      	movl	$0x4, %eax
     2d8:      	movq	0x20(%rsp), %rdx
     2dd:      	movl	$0x48, %esi
     2e2:      	callq	*%rax
     2e4:      	movl	$0x218, %edx            # imm = 0x218
     2e9:      	movq	0x48(%rsp), %rcx
     2ee:      	addq	%rdx, %rcx
     2f1:      	movl	$0x4, %esi
     2f6:      	movl	$0x4, %eax
     2fb:      	addq	0x48(%rsp), %rdx
     300:      	movq	%r12, %rdi
     303:      	movl	$0x4, %esi
     308:      	callq	*%rax
     30a:      	leaq	0x24(%r14), %rdi
     30e:      	movl	$0x4d8, %edx            # imm = 0x4D8
     313:      	movq	0x50(%rsp), %rcx
     318:      	addq	%rdx, %rcx
     31b:      	movl	$0x4, %esi
     320:      	movl	$0x4, %eax
     325:      	addq	0x50(%rsp), %rdx
     32a:      	movl	$0x4, %esi
     32f:      	callq	*%rax
     331:      	leaq	0x28(%r14), %rdi
     335:      	movq	0x58(%rsp), %rcx
     33a:      	addq	$0x58, %rcx
     33e:      	movl	$0x4, %edx
     343:      	movl	$0x4, %eax
     348:      	movq	0x58(%rsp), %rdx
     34d:      	addq	$0x58, %rdx
     351:      	movl	$0x4, %esi
     356:      	callq	*%rax
     358:      	movq	$0x0, 0x8(%rsp)
     361:      	leaq	0xb58(%r15), %rdx
     368:      	leaq	0x8(%rsp), %rdi
     36d:      	movl	$0x8, %ecx
     372:      	movl	$0x4, %eax
     377:      	movl	$0x8, %esi
     37c:      	callq	*%rax
     37e:      	movq	0x8(%rsp), %rcx
     383:      	testq	%rcx, %rcx
     386:      	je	0x41c <generic_usdt_event+0x41c>
     38c:      	movl	$0x0, 0x18(%rsp)
     394:      	addq	$0x4, %rcx
     398:      	leaq	0x18(%rsp), %rdi
     39d:      	movl	$0x4, %eax
     3a2:      	movq	0x8(%rsp), %rdx
     3a7:      	addq	$0x4, %rdx
     3ab:      	movl	$0x4, %esi
     3b0:      	callq	*%rax
     3b2:      	movq	0x8(%rsp), %rax
     3b7:      	movslq	0x18(%rsp), %rcx
     3bc:      	shlq	$0x4, %rcx
     3c0:      	addq	%rax, %rcx
     3c3:      	addq	$0x80, %rcx
     3ca:      	leaq	0x28(%rsp), %rdi
     3cf:      	movl	$0x10, %edx
     3d4:      	movl	$0x4, %eax
     3d9:      	movq	0x8(%rsp), %rcx
     3de:      	movslq	0x18(%rsp), %rdx
     3e3:      	shlq	$0x4, %rdx
     3e7:      	addq	%rcx, %rdx
     3ea:      	addq	$0x80, %rdx
     3f1:      	movl	$0x10, %esi
     3f6:      	callq	*%rax
     3f8:      	leaq	0x2c(%r14), %rdi
     3fc:      	movl	$0x158, %edx            # imm = 0x158
     401:      	movq	0x30(%rsp), %rcx
     406:      	addq	%rdx, %rcx
     409:      	movl	$0x4, %eax
     40e:      	addq	0x30(%rsp), %rdx
     413:      	movl	$0x4, %esi
     418:      	callq	*%rax
     41a:      	jmp	0x424 <generic_usdt_event+0x424>
     41c:      	movl	$0x0, 0x2c(%r14)
     424:      	leaq	0x30(%r14), %rdi
     428:      	movl	$0x158, %r12d           # imm = 0x158
     42e:      	movq	0x60(%rsp), %rcx
     433:      	addq	%r12, %rcx
     436:      	movl	$0x4, %edx
     43b:      	movl	$0x4, %eax
     440:      	movq	0x60(%rsp), %rdx
     445:      	addq	%r12, %rdx
     448:      	movl	$0x4, %esi
     44d:      	callq	*%rax
     44f:      	leaq	0x34(%r14), %rdi
     453:      	movl	$0x118, %edx            # imm = 0x118
     458:      	movq	0x68(%rsp), %rcx
     45d:      	addq	%rdx, %rcx
     460:      	movl	$0x4, %esi
     465:      	movl	$0x4, %eax
     46a:      	addq	0x68(%rsp), %rdx
     46f:      	movl	$0x4, %esi
     474:      	callq	*%rax
     476:      	leaq	0x38(%r14), %rdi
     47a:      	movl	$0x98, %r13d
     480:      	movq	0x70(%rsp), %rcx
     485:      	addq	%r13, %rcx
     488:      	movl	$0x4, %edx
     48d:      	movl	$0x4, %eax
     492:      	movq	0x70(%rsp), %rdx
     497:      	addq	%r13, %rdx
     49a:      	movl	$0x4, %esi
     49f:      	callq	*%rax
     4a1:      	leaq	0x3c(%r14), %rdi
     4a5:      	movq	0x78(%rsp), %rcx
     4aa:      	addq	%r13, %rcx
     4ad:      	movl	$0x4, %edx
     4b2:      	movl	$0x4, %eax
     4b7:      	addq	0x78(%rsp), %r13
     4bc:      	movl	$0x4, %esi
     4c1:      	movq	%r13, %rdx
     4c4:      	callq	*%rax
     4c6:      	leaq	0x40(%r14), %rdi
     4ca:      	movq	0x80(%rsp), %rcx
     4d2:      	addq	$0x58, %rcx
     4d6:      	movl	$0x4, %edx
     4db:      	movl	$0x4, %eax
     4e0:      	movq	0x80(%rsp), %rdx
     4e8:      	addq	$0x58, %rdx
     4ec:      	movl	$0x4, %esi
     4f1:      	callq	*%rax
     4f3:      	movq	$0x0, 0x28(%rsp)
     4fc:      	movq	$0x0, 0x8(%rsp)
     505:      	addq	$0xd00, %r15            # imm = 0xD00
     50c:      	leaq	0x28(%rsp), %rdi
     511:      	movl	$0x8, %ecx
     516:      	movl	$0x4, %eax
     51b:      	movl	$0x8, %esi
     520:      	movq	%r15, %rdx
     523:      	callq	*%rax
     525:      	movl	$0x90, %edx
     52a:      	movq	0x28(%rsp), %rcx
     52f:      	addq	%rdx, %rcx
     532:      	leaq	0x8(%rsp), %rdi
     537:      	movl	$0x8, %esi
     53c:      	movl	$0x4, %eax
     541:      	addq	0x28(%rsp), %rdx
     546:      	movl	$0x8, %esi
     54b:      	callq	*%rax
     54d:      	leaq	0x44(%r14), %rdi
     551:      	movq	0x8(%rsp), %rcx
     556:      	addq	%r12, %rcx
     559:      	movl	$0x4, %edx
     55e:      	movl	$0x4, %eax
     563:      	addq	0x8(%rsp), %r12
     568:      	movl	$0x4, %esi
     56d:      	movq	%r12, %rdx
     570:      	callq	*%rax
     572:      	leaq	0x48(%r14), %r12
     576:      	leaq	0x40(%rsp), %rdi
     57b:      	movl	$0x8, %ecx
     580:      	movl	$0x4, %eax
     585:      	movl	$0x8, %esi
     58a:      	movq	%r15, %rdx
     58d:      	callq	*%rax
     58f:      	movq	0x40(%rsp), %r15
     594:      	leaq	0x50(%r14), %rdi
     598:      	leaq	0x40(%r15), %rdx
     59c:      	movl	$0x8, %ecx
     5a1:      	movl	$0x4, %eax
     5a6:      	movl	$0x8, %esi
     5ab:      	callq	*%rax
     5ad:      	movq	%r14, %rdi
     5b0:      	addq	$0x58, %rdi
     5b4:      	leaq	0x30(%r15), %rdx
     5b8:      	movl	$0x8, %ecx
     5bd:      	movl	$0x4, %eax
     5c2:      	movl	$0x8, %esi
     5c7:      	callq	*%rax
     5c9:      	addq	$0x38, %r15
     5cd:      	movl	$0x8, %ecx
     5d2:      	movl	$0x4, %eax
     5d7:      	movq	%r12, %rdi
     5da:      	movl	$0x8, %esi
     5df:      	movq	%r15, %rdx
     5e2:      	callq	*%rax
     5e4:      	movb	$0x0, 0x5f08(%r14)
     5ec:      	movb	$0x0, 0x1(%r14)
     5f1:      	movq	$0x0, 0x5ee8(%r14)
     5fc:      	movq	$0x0, 0x5ef0(%r14)
     607:      	movq	(%rip), %rsi            # 0x60e <generic_usdt_event+0x60e>
     60e:      	movl	$0x2, %ecx
     613:      	movl	$0xc, %eax
     618:      	movq	%rbx, %rdi
     61b:      	movl	$0x2, %edx
     620:      	callq	*%rax
     622:      	xorl	%eax, %eax
     624:      	addq	$0x88, %rsp
     62b:      	popq	%rbx
     62c:      	popq	%r12
     62e:      	popq	%r13
     630:      	popq	%r14
     632:      	popq	%r15
     634:      	popq	%rbp
     635:      	retq
     636:      	movq	$-0x1, 0x18(%rsp)
     63f:      	leaq	0x18(%rsp), %rsi
     644:      	movl	$0x1, %eax
     649:      	movq	%r15, %rdi
     64c:      	callq	*%rax
     64e:      	testq	%rax, %rax
     651:      	je	0x622 <generic_usdt_event+0x622>
     653:      	movl	$0x1, 0x14(%rsp)
     65b:      	movq	(%rip), %rdi            # 0x662 <generic_usdt_event+0x662>
     662:      	leaq	0x14(%rsp), %rsi
     667:      	movl	$0x1, %eax
     66c:      	callq	*%rax
     66e:      	testq	%rax, %rax
     671:      	je	0x622 <generic_usdt_event+0x622>
     673:      	movq	%rax, %rdi
     676:      	leaq	0x8(%rsp), %rsi
     67b:      	movl	$0x1, %eax
     680:      	callq	*%rax
     682:      	testq	%rax, %rax
     685:      	movq	%r12, %rax
     688:      	jne	0x622 <generic_usdt_event+0x622>
     68a:      	jmp	0x23b <generic_usdt_event+0x23b>

Disassembly of section uprobe.s/generic_usdt:

0000000000000000 <generic_sleepable_preload>:
       0:      	pushq	%rbx
       1:      	subq	$0x20, %rsp
       5:      	movq	%rdi, %rbx
       8:      	movl	$0x0, 0xc(%rsp)
      10:      	movq	(%rip), %rdi            # 0x17 <generic_sleepable_preload+0x17>
      17:      	leaq	0xc(%rsp), %rsi
      1c:      	movl	$0x1, %eax
      21:      	callq	*%rax
      23:      	testq	%rax, %rax
      26:      	je	0x81 <generic_sleepable_preload+0x81>
      28:      	movq	%rax, 0x10(%rsp)
      2d:      	movq	%rbx, 0x18(%rsp)
      32:      	movq	(%rip), %rax            # 0x39 <generic_sleepable_preload+0x39>
      39:      	cmpb	$0x0, (%rax)
      3c:      	je	0x89 <generic_sleepable_preload+0x89>
      3e:      	leaq	0x10(%rsp), %rbx
      43:      	xorl	%edi, %edi
      45:      	movq	%rbx, %rsi
      48:      	callq	0x4d <generic_sleepable_preload+0x4d>
      4d:      	movl	$0x1, %edi
      52:      	movq	%rbx, %rsi
      55:      	callq	0x5a <generic_sleepable_preload+0x5a>
      5a:      	movl	$0x2, %edi
      5f:      	movq	%rbx, %rsi
      62:      	callq	0x67 <generic_sleepable_preload+0x67>
      67:      	movl	$0x3, %edi
      6c:      	movq	%rbx, %rsi
      6f:      	callq	0x74 <generic_sleepable_preload+0x74>
      74:      	movl	$0x4, %edi
      79:      	movq	%rbx, %rsi
      7c:      	callq	0x81 <generic_sleepable_preload+0x81>
      81:      	xorl	%eax, %eax
      83:      	addq	$0x20, %rsp
      87:      	popq	%rbx
      88:      	retq
      89:      	leaq	(%rip), %rsi            # 0x90 <generic_sleepable_preload+0x90>
      90:      	xorl	%ecx, %ecx
      92:      	leaq	0x10(%rsp), %rdx
      97:      	movl	$0x5, %edi
      9c:      	movl	$0xb5, %eax
      a1:      	movl	$0x5, %edi
      a6:      	xorl	%ecx, %ecx
      a8:      	callq	*%rax
      aa:      	xorl	%eax, %eax
      ac:      	addq	$0x20, %rsp
      b0:      	popq	%rbx
      b1:      	retq
      b2:      	nopw	%cs:(%rax,%rax)

00000000000000c0 <generic_sleepable_preload_cleanup>:
      c0:      	pushq	%rax
      c1:      	movl	$0xe, %eax
      c6:      	callq	*%rax
      c8:      	movq	%rax, (%rsp)
      cc:      	movq	(%rip), %rdi            # 0xd3 <generic_sleepable_preload_cleanup+0x13>
      d3:      	movq	%rsp, %rsi
      d6:      	movl	$0x3, %eax
      db:      	callq	*%rax
      dd:      	xorl	%eax, %eax
      df:      	popq	%rcx
      e0:      	retq
      e1:      	nopw	%cs:(%rax,%rax)

00000000000000f0 <generic_sleepable_offload>:
      f0:      	pushq	%rax
      f1:      	movl	$0xe, %eax
      f6:      	callq	*%rax
      f8:      	movq	%rax, (%rsp)
      fc:      	movq	(%rip), %rdi            # 0x103 <generic_sleepable_offload+0x13>
     103:      	movq	%rsp, %rsi
     106:      	movl	$0x1, %eax
     10b:      	callq	*%rax
     10d:      	testq	%rax, %rax
     110:      	je	0x144 <generic_sleepable_offload+0x54>
     112:      	movq	(%rax), %rcx
     115:      	movq	%rax, %rsi
     118:      	addq	$0x8, %rsi
     11c:      	movl	$0x4, %edx
     121:      	movq	%rax, %rdi
     124:      	movl	$0x24, %eax
     129:      	movq	(%rdi), %rdi
     12c:      	movl	$0x4, %edx
     131:      	callq	*%rax
     133:      	movq	(%rip), %rdi            # 0x13a <generic_sleepable_offload+0x4a>
     13a:      	movq	%rsp, %rsi
     13d:      	movl	$0x3, %eax
     142:      	callq	*%rax
     144:      	xorl	%eax, %eax
     146:      	popq	%rcx
     147:      	retq
