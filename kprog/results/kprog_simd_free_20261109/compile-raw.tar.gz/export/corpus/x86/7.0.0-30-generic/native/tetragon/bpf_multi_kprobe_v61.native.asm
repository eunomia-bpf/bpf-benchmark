
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_kprobe_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <read_reg>:
       0:      	rorxl	$0x3, %esi, %ecx
       6:      	xorl	%eax, %eax
       8:      	cmpl	$0x7, %ecx
       b:      	jle	0x42 <read_reg+0x42>
       d:      	cmpl	$0xb, %ecx
      10:      	jle	0x66 <read_reg+0x66>
      12:      	cmpl	$0xd, %ecx
      15:      	jle	0xcb <read_reg+0xcb>
      1b:      	cmpl	$0xe, %ecx
      1e:      	je	0xff <read_reg+0xff>
      24:      	cmpl	$0x10, %ecx
      27:      	je	0xe7 <read_reg+0xe7>
      2d:      	cmpl	$0x13, %ecx
      30:      	jne	0x115 <read_reg+0x115>
      36:      	addq	$0x98, %rdi
      3d:      	jmp	0x109 <read_reg+0x109>
      42:      	cmpl	$0x3, %ecx
      45:      	jg	0x82 <read_reg+0x82>
      47:      	cmpl	$0x1, %ecx
      4a:      	jg	0xab <read_reg+0xab>
      4c:      	testl	%ecx, %ecx
      4e:      	je	0x109 <read_reg+0x109>
      54:      	cmpl	$0x1, %ecx
      57:      	jne	0x115 <read_reg+0x115>
      5d:      	addq	$0x8, %rdi
      61:      	jmp	0x109 <read_reg+0x109>
      66:      	cmpl	$0x9, %ecx
      69:      	jg	0x9b <read_reg+0x9b>
      6b:      	cmpl	$0x8, %ecx
      6e:      	je	0xdb <read_reg+0xdb>
      70:      	cmpl	$0x9, %ecx
      73:      	jne	0x115 <read_reg+0x115>
      79:      	addq	$0x48, %rdi
      7d:      	jmp	0x109 <read_reg+0x109>
      82:      	cmpl	$0x5, %ecx
      85:      	jg	0xbb <read_reg+0xbb>
      87:      	cmpl	$0x4, %ecx
      8a:      	je	0xed <read_reg+0xed>
      8c:      	cmpl	$0x5, %ecx
      8f:      	jne	0x115 <read_reg+0x115>
      95:      	addq	$0x28, %rdi
      99:      	jmp	0x109 <read_reg+0x109>
      9b:      	cmpl	$0xa, %ecx
      9e:      	je	0xe1 <read_reg+0xe1>
      a0:      	cmpl	$0xb, %ecx
      a3:      	jne	0x115 <read_reg+0x115>
      a5:      	addq	$0x58, %rdi
      a9:      	jmp	0x109 <read_reg+0x109>
      ab:      	cmpl	$0x2, %ecx
      ae:      	je	0xf3 <read_reg+0xf3>
      b0:      	cmpl	$0x3, %ecx
      b3:      	jne	0x115 <read_reg+0x115>
      b5:      	addq	$0x18, %rdi
      b9:      	jmp	0x109 <read_reg+0x109>
      bb:      	cmpl	$0x6, %ecx
      be:      	je	0xf9 <read_reg+0xf9>
      c0:      	cmpl	$0x7, %ecx
      c3:      	jne	0x115 <read_reg+0x115>
      c5:      	addq	$0x38, %rdi
      c9:      	jmp	0x109 <read_reg+0x109>
      cb:      	cmpl	$0xc, %ecx
      ce:      	je	0x105 <read_reg+0x105>
      d0:      	cmpl	$0xd, %ecx
      d3:      	jne	0x115 <read_reg+0x115>
      d5:      	addq	$0x68, %rdi
      d9:      	jmp	0x109 <read_reg+0x109>
      db:      	addq	$0x40, %rdi
      df:      	jmp	0x109 <read_reg+0x109>
      e1:      	addq	$0x50, %rdi
      e5:      	jmp	0x109 <read_reg+0x109>
      e7:      	subq	$-0x80, %rdi
      eb:      	jmp	0x109 <read_reg+0x109>
      ed:      	addq	$0x20, %rdi
      f1:      	jmp	0x109 <read_reg+0x109>
      f3:      	addq	$0x10, %rdi
      f7:      	jmp	0x109 <read_reg+0x109>
      f9:      	addq	$0x30, %rdi
      fd:      	jmp	0x109 <read_reg+0x109>
      ff:      	addq	$0x70, %rdi
     103:      	jmp	0x109 <read_reg+0x109>
     105:      	addq	$0x60, %rdi
     109:      	movl	$0x40, %eax
     10e:      	subl	%edx, %eax
     110:      	bzhiq	%rax, (%rdi), %rax
     115:      	retq
     116:      	nopw	%cs:(%rax,%rax)

0000000000000120 <extract_arg_depth>:
     120:      	movl	$0x1, %eax
     125:      	cmpl	$0x9, %edi
     128:      	ja	0x1a2 <extract_arg_depth+0x82>
     12a:      	pushq	%r14
     12c:      	pushq	%rbx
     12d:      	pushq	%rax
     12e:      	movq	(%rsi), %r8
     131:      	movl	%edi, %r9d
     134:      	cmpw	$0x0, 0x6(%r8,%r9,8)
     13b:      	je	0x19b <extract_arg_depth+0x7b>
     13d:      	movq	0x8(%rsi), %rcx
     141:      	movl	(%r8,%r9,8), %edx
     145:      	addq	(%rcx), %rdx
     148:      	movq	%rdx, (%rcx)
     14b:      	xorl	%eax, %eax
     14d:      	cmpw	$0x0, 0x4(%r8,%r9,8)
     154:      	je	0x19b <extract_arg_depth+0x7b>
     156:      	movl	%edi, %ebx
     158:      	cmpb	$0x0, 0x10(%rsi)
     15c:      	je	0x16a <extract_arg_depth+0x4a>
     15e:      	movl	$0x8, %edi
     163:      	movl	$0x94, %eax
     168:      	jmp	0x174 <extract_arg_depth+0x54>
     16a:      	movl	$0x8, %edi
     16f:      	movl	$0x4, %eax
     174:      	movq	%rsi, %r14
     177:      	movq	0x8(%rsi), %rdi
     17b:      	movq	(%rdi), %rdx
     17e:      	movl	$0x8, %esi
     183:      	callq	*%rax
     185:      	testl	%eax, %eax
     187:      	movl	$0x0, %eax
     18c:      	jns	0x19b <extract_arg_depth+0x7b>
     18e:      	incl	%ebx
     190:      	movq	0x18(%r14), %rax
     194:      	movl	%ebx, (%rax)
     196:      	movl	$0x1, %eax
     19b:      	addq	$0x8, %rsp
     19f:      	popq	%rbx
     1a0:      	popq	%r14
     1a2:      	retq
     1a3:      	nopw	%cs:(%rax,%rax)

00000000000001b0 <do_bytes>:
     1b0:      	pushq	%rbp
     1b1:      	pushq	%r15
     1b3:      	pushq	%r14
     1b5:      	pushq	%r13
     1b7:      	pushq	%r12
     1b9:      	pushq	%rbx
     1ba:      	pushq	%rax
     1bb:      	movq	%rcx, %rbx
     1be:      	movq	%rdx, %r14
     1c1:      	movq	%rsi, %r15
     1c4:      	movq	%rdi, %r12
     1c7:      	callq	0x410 <__do_bytes>
     1cc:      	testl	%eax, %eax
     1ce:      	js	0x377 <do_bytes+0x1c7>
     1d4:      	movl	%eax, %r13d
     1d7:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
     1de:      	movq	%rbx, %rcx
     1e1:      	subq	%r13, %rcx
     1e4:      	je	0x3fe <do_bytes+0x24e>
     1ea:      	leaq	(%r14,%r13), %rdx
     1ee:      	movq	%r12, %rdi
     1f1:      	movq	%r15, %rsi
     1f4:      	callq	0x410 <__do_bytes>
     1f9:      	testl	%eax, %eax
     1fb:      	js	0x377 <do_bytes+0x1c7>
     201:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     206:      	movq	%rax, %rbp
     209:      	addq	%r13, %rbp
     20c:      	movq	%rbx, %rcx
     20f:      	subq	%rbp, %rcx
     212:      	je	0x3fe <do_bytes+0x24e>
     218:      	leaq	(%r14,%rbp), %rdx
     21c:      	movq	%r12, %rdi
     21f:      	movq	%r15, %rsi
     222:      	callq	0x410 <__do_bytes>
     227:      	testl	%eax, %eax
     229:      	js	0x377 <do_bytes+0x1c7>
     22f:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     234:      	movq	%rax, %r13
     237:      	addq	%rbp, %r13
     23a:      	movq	%rbx, %rcx
     23d:      	subq	%r13, %rcx
     240:      	je	0x3fe <do_bytes+0x24e>
     246:      	leaq	(%r14,%r13), %rdx
     24a:      	movq	%r12, %rdi
     24d:      	movq	%r15, %rsi
     250:      	callq	0x410 <__do_bytes>
     255:      	testl	%eax, %eax
     257:      	js	0x377 <do_bytes+0x1c7>
     25d:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     262:      	movq	%rax, %rbp
     265:      	addq	%r13, %rbp
     268:      	movq	%rbx, %rcx
     26b:      	subq	%rbp, %rcx
     26e:      	je	0x3fe <do_bytes+0x24e>
     274:      	leaq	(%r14,%rbp), %rdx
     278:      	movq	%r12, %rdi
     27b:      	movq	%r15, %rsi
     27e:      	callq	0x410 <__do_bytes>
     283:      	testl	%eax, %eax
     285:      	js	0x377 <do_bytes+0x1c7>
     28b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     290:      	movq	%rax, %r13
     293:      	addq	%rbp, %r13
     296:      	movq	%rbx, %rcx
     299:      	subq	%r13, %rcx
     29c:      	je	0x3fe <do_bytes+0x24e>
     2a2:      	leaq	(%r14,%r13), %rdx
     2a6:      	movq	%r12, %rdi
     2a9:      	movq	%r15, %rsi
     2ac:      	callq	0x410 <__do_bytes>
     2b1:      	testl	%eax, %eax
     2b3:      	js	0x377 <do_bytes+0x1c7>
     2b9:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     2be:      	movq	%rax, %rbp
     2c1:      	addq	%r13, %rbp
     2c4:      	movq	%rbx, %rcx
     2c7:      	subq	%rbp, %rcx
     2ca:      	je	0x3fe <do_bytes+0x24e>
     2d0:      	leaq	(%r14,%rbp), %rdx
     2d4:      	movq	%r12, %rdi
     2d7:      	movq	%r15, %rsi
     2da:      	callq	0x410 <__do_bytes>
     2df:      	testl	%eax, %eax
     2e1:      	js	0x377 <do_bytes+0x1c7>
     2e7:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     2ec:      	movq	%rax, %r13
     2ef:      	addq	%rbp, %r13
     2f2:      	movq	%rbx, %rcx
     2f5:      	subq	%r13, %rcx
     2f8:      	je	0x3fe <do_bytes+0x24e>
     2fe:      	leaq	(%r14,%r13), %rdx
     302:      	movq	%r12, %rdi
     305:      	movq	%r15, %rsi
     308:      	callq	0x410 <__do_bytes>
     30d:      	testl	%eax, %eax
     30f:      	js	0x377 <do_bytes+0x1c7>
     311:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     316:      	movq	%rax, %rbp
     319:      	addq	%r13, %rbp
     31c:      	movq	%rbx, %rcx
     31f:      	subq	%rbp, %rcx
     322:      	je	0x3fe <do_bytes+0x24e>
     328:      	leaq	(%r14,%rbp), %rdx
     32c:      	movq	%r12, %rdi
     32f:      	movq	%r15, %rsi
     332:      	callq	0x410 <__do_bytes>
     337:      	testl	%eax, %eax
     339:      	js	0x377 <do_bytes+0x1c7>
     33b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     340:      	movq	%rax, %r13
     343:      	addq	%rbp, %r13
     346:      	movq	%rbx, %rcx
     349:      	subq	%r13, %rcx
     34c:      	je	0x3fe <do_bytes+0x24e>
     352:      	addq	%r13, %r14
     355:      	movq	%r12, %rdi
     358:      	movq	%r15, %rsi
     35b:      	movq	%r14, %rdx
     35e:      	callq	0x410 <__do_bytes>
     363:      	testl	%eax, %eax
     365:      	js	0x377 <do_bytes+0x1c7>
     367:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     36c:      	addq	%r13, %rax
     36f:      	movq	%rax, %rbx
     372:      	jmp	0x3fe <do_bytes+0x24e>
     377:      	movslq	%eax, %rbx
     37a:      	movl	$0x0, 0x4(%rsp)
     382:      	movq	(%rip), %rdi            # 0x389 <do_bytes+0x1d9>
     389:      	leaq	0x4(%rsp), %rsi
     38e:      	movl	$0x1, %eax
     393:      	callq	*%rax
     395:      	testq	%rax, %rax
     398:      	je	0x3fe <do_bytes+0x24e>
     39a:      	cmpq	$-0xc, %rbx
     39e:      	jg	0x3ba <do_bytes+0x20a>
     3a0:      	cmpq	$-0x1c, %rbx
     3a4:      	je	0x3d4 <do_bytes+0x224>
     3a6:      	cmpq	$-0x16, %rbx
     3aa:      	je	0x3ec <do_bytes+0x23c>
     3ac:      	cmpq	$-0x10, %rbx
     3b0:      	jne	0x3e4 <do_bytes+0x234>
     3b2:      	addq	$0x558, %rax            # imm = 0x558
     3b8:      	jmp	0x3fa <do_bytes+0x24a>
     3ba:      	cmpq	$-0xb, %rbx
     3be:      	je	0x3dc <do_bytes+0x22c>
     3c0:      	cmpq	$-0x7, %rbx
     3c4:      	je	0x3f4 <do_bytes+0x244>
     3c6:      	cmpq	$-0x2, %rbx
     3ca:      	jne	0x3e4 <do_bytes+0x234>
     3cc:      	addq	$0x548, %rax            # imm = 0x548
     3d2:      	jmp	0x3fa <do_bytes+0x24a>
     3d4:      	addq	$0x568, %rax            # imm = 0x568
     3da:      	jmp	0x3fa <do_bytes+0x24a>
     3dc:      	addq	$0x570, %rax            # imm = 0x570
     3e2:      	jmp	0x3fa <do_bytes+0x24a>
     3e4:      	addq	$0x540, %rax            # imm = 0x540
     3ea:      	jmp	0x3fa <do_bytes+0x24a>
     3ec:      	addq	$0x560, %rax            # imm = 0x560
     3f2:      	jmp	0x3fa <do_bytes+0x24a>
     3f4:      	addq	$0x550, %rax            # imm = 0x550
     3fa:      	lock
     3fb:      	incq	(%rax)
     3fe:      	movq	%rbx, %rax
     401:      	addq	$0x8, %rsp
     405:      	popq	%rbx
     406:      	popq	%r12
     408:      	popq	%r13
     40a:      	popq	%r14
     40c:      	popq	%r15
     40e:      	popq	%rbp
     40f:      	retq

0000000000000410 <__do_bytes>:
     410:      	pushq	%r15
     412:      	pushq	%r14
     414:      	pushq	%r12
     416:      	pushq	%rbx
     417:      	pushq	%rax
     418:      	testq	%rcx, %rcx
     41b:      	js	0x499 <__do_bytes+0x89>
     41d:      	movq	%rsi, %r14
     420:      	movq	%rdi, %r12
     423:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     42a:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     42f:      	cmovbq	%rcx, %rbx
     433:      	leaq	0x20(%rsi), %rdi
     437:      	movl	$0x4, %eax
     43c:      	movl	%ebx, %esi
     43e:      	callq	*%rax
     440:      	testl	%eax, %eax
     442:      	js	0x4be <__do_bytes+0xae>
     444:      	leal	0x20(%rbx), %r15d
     448:      	movl	%r15d, 0x4(%r14)
     44c:      	movl	$0x0, 0x4(%rsp)
     454:      	movq	(%rip), %rdi            # 0x45b <__do_bytes+0x4b>
     45b:      	leaq	0x4(%rsp), %rsi
     460:      	movl	$0x1, %eax
     465:      	callq	*%rax
     467:      	testq	%rax, %rax
     46a:      	je	0x4a2 <__do_bytes+0x92>
     46c:      	cmpb	$0x0, 0x28(%rax)
     470:      	je	0x4a2 <__do_bytes+0x92>
     472:      	movq	(%rip), %rsi            # 0x479 <__do_bytes+0x69>
     479:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     47e:      	movl	$0x19, %eax
     483:      	movq	%r12, %rdi
     486:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     48b:      	movq	%r14, %rcx
     48e:      	movq	%r15, %r8
     491:      	callq	*%rax
     493:      	testl	%eax, %eax
     495:      	js	0x4be <__do_bytes+0xae>
     497:      	jmp	0x4c1 <__do_bytes+0xb1>
     499:      	movq	$-0x1, %rbx
     4a0:      	jmp	0x4c1 <__do_bytes+0xb1>
     4a2:      	movq	(%rip), %rdi            # 0x4a9 <__do_bytes+0x99>
     4a9:      	xorl	%ecx, %ecx
     4ab:      	movl	$0x82, %eax
     4b0:      	movq	%r14, %rsi
     4b3:      	movq	%r15, %rdx
     4b6:      	xorl	%ecx, %ecx
     4b8:      	callq	*%rax
     4ba:      	testl	%eax, %eax
     4bc:      	jns	0x4c1 <__do_bytes+0xb1>
     4be:      	movslq	%eax, %rbx
     4c1:      	movq	%rbx, %rax
     4c4:      	addq	$0x8, %rsp
     4c8:      	popq	%rbx
     4c9:      	popq	%r12
     4cb:      	popq	%r14
     4cd:      	popq	%r15
     4cf:      	retq

00000000000004d0 <filter_64ty>:
     4d0:      	pushq	%rax
     4d1:      	movl	0x4(%rdi), %ecx
     4d4:      	xorl	%eax, %eax
     4d6:      	cmpq	$0x20, %rcx
     4da:      	ja	0x515 <filter_64ty+0x45>
     4dc:      	movl	$0x101e, %edx           # imm = 0x101E
     4e1:      	btq	%rcx, %rdx
     4e5:      	jae	0x4ee <filter_64ty+0x1e>
     4e7:      	callq	0x610 <filter_64ty_selector_val>
     4ec:      	popq	%rcx
     4ed:      	retq
     4ee:      	movl	$0xc00, %edx            # imm = 0xC00
     4f3:      	btq	%rcx, %rdx
     4f7:      	jb	0x510 <filter_64ty+0x40>
     4f9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     503:      	btq	%rcx, %rdx
     507:      	jae	0x515 <filter_64ty+0x45>
     509:      	callq	0x8d0 <filter_64ty_range>
     50e:      	popq	%rcx
     50f:      	retq
     510:      	callq	0x850 <filter_64ty_map>
     515:      	popq	%rcx
     516:      	retq
     517:      	nopw	(%rax,%rax)

0000000000000520 <filter_32ty>:
     520:      	pushq	%rax
     521:      	movl	0x4(%rdi), %ecx
     524:      	xorl	%eax, %eax
     526:      	cmpq	$0x20, %rcx
     52a:      	ja	0x565 <filter_32ty+0x45>
     52c:      	movl	$0x101e, %edx           # imm = 0x101E
     531:      	btq	%rcx, %rdx
     535:      	jae	0x53e <filter_32ty+0x1e>
     537:      	callq	0xab0 <filter_32ty_selector_val>
     53c:      	popq	%rcx
     53d:      	retq
     53e:      	movl	$0xc00, %edx            # imm = 0xC00
     543:      	btq	%rcx, %rdx
     547:      	jb	0x560 <filter_32ty+0x40>
     549:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     553:      	btq	%rcx, %rdx
     557:      	jae	0x565 <filter_32ty+0x45>
     559:      	callq	0xd60 <filter_32ty_range>
     55e:      	popq	%rcx
     55f:      	retq
     560:      	callq	0xcd0 <filter_32ty_map>
     565:      	popq	%rcx
     566:      	retq
     567:      	nopw	(%rax,%rax)

0000000000000570 <filter_16ty>:
     570:      	pushq	%rax
     571:      	movl	0x4(%rdi), %ecx
     574:      	xorl	%eax, %eax
     576:      	cmpq	$0x20, %rcx
     57a:      	ja	0x5b5 <filter_16ty+0x45>
     57c:      	movl	$0x101e, %edx           # imm = 0x101E
     581:      	btq	%rcx, %rdx
     585:      	jae	0x58e <filter_16ty+0x1e>
     587:      	callq	0xf20 <filter_16ty_selector_val>
     58c:      	popq	%rcx
     58d:      	retq
     58e:      	movl	$0xc00, %edx            # imm = 0xC00
     593:      	btq	%rcx, %rdx
     597:      	jb	0x5b0 <filter_16ty+0x40>
     599:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     5a3:      	btq	%rcx, %rdx
     5a7:      	jae	0x5b5 <filter_16ty+0x45>
     5a9:      	callq	0x11d0 <filter_16ty_range>
     5ae:      	popq	%rcx
     5af:      	retq
     5b0:      	callq	0x1140 <filter_16ty_map>
     5b5:      	popq	%rcx
     5b6:      	retq
     5b7:      	nopw	(%rax,%rax)

00000000000005c0 <filter_8ty>:
     5c0:      	pushq	%rax
     5c1:      	movl	0x4(%rdi), %ecx
     5c4:      	xorl	%eax, %eax
     5c6:      	cmpq	$0x20, %rcx
     5ca:      	ja	0x605 <filter_8ty+0x45>
     5cc:      	movl	$0x101e, %edx           # imm = 0x101E
     5d1:      	btq	%rcx, %rdx
     5d5:      	jae	0x5de <filter_8ty+0x1e>
     5d7:      	callq	0x1390 <filter_8ty_selector_val>
     5dc:      	popq	%rcx
     5dd:      	retq
     5de:      	movl	$0xc00, %edx            # imm = 0xC00
     5e3:      	btq	%rcx, %rdx
     5e7:      	jb	0x600 <filter_8ty+0x40>
     5e9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     5f3:      	btq	%rcx, %rdx
     5f7:      	jae	0x605 <filter_8ty+0x45>
     5f9:      	callq	0x1640 <filter_8ty_range>
     5fe:      	popq	%rcx
     5ff:      	retq
     600:      	callq	0x15b0 <filter_8ty_map>
     605:      	popq	%rcx
     606:      	retq
     607:      	nopw	(%rax,%rax)

0000000000000610 <filter_64ty_selector_val>:
     610:      	movl	0x4(%rdi), %ecx
     613:      	movl	$0x1, %eax
     618:      	cmpq	$0x25, %rcx
     61c:      	ja	0x694 <filter_64ty_selector_val+0x84>
     61e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     628:      	btq	%rcx, %rdx
     62c:      	jae	0x62f <filter_64ty_selector_val+0x1f>
     62e:      	retq
     62f:      	movl	$0x18, %edx
     634:      	btq	%rcx, %rdx
     638:      	jae	0x650 <filter_64ty_selector_val+0x40>
     63a:      	movq	(%rsi), %rdx
     63d:      	cmpq	0x10(%rdi), %rdx
     641:      	jne	0x772 <filter_64ty_selector_val+0x162>
     647:      	xorl	%eax, %eax
     649:      	cmpl	$0x3, %ecx
     64c:      	sete	%al
     64f:      	retq
     650:      	cmpq	$0xc, %rcx
     654:      	jne	0x694 <filter_64ty_selector_val+0x84>
     656:      	movq	(%rsi), %rcx
     659:      	testq	%rcx, 0x10(%rdi)
     65d:      	jne	0x62e <filter_64ty_selector_val+0x1e>
     65f:      	movl	0x8(%rdi), %edx
     662:      	cmpl	$0x11, %edx
     665:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     66b:      	testq	%rcx, 0x18(%rdi)
     66f:      	jne	0x62e <filter_64ty_selector_val+0x1e>
     671:      	cmpl	$0x19, %edx
     674:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     67a:      	testq	%rcx, 0x20(%rdi)
     67e:      	jne	0x62e <filter_64ty_selector_val+0x1e>
     680:      	cmpl	$0x21, %edx
     683:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     689:      	testq	%rcx, 0x28(%rdi)
     68d:      	jne	0x62e <filter_64ty_selector_val+0x1e>
     68f:      	jmp	0x83f <filter_64ty_selector_val+0x22f>
     694:      	cmpl	$0x1, %ecx
     697:      	je	0x70a <filter_64ty_selector_val+0xfa>
     699:      	cmpl	$0x2, %ecx
     69c:      	jne	0x83f <filter_64ty_selector_val+0x22f>
     6a2:      	movl	0xc(%rdi), %ecx
     6a5:      	cmpl	$0xc, %ecx
     6a8:      	ja	0x802 <filter_64ty_selector_val+0x1f2>
     6ae:      	movl	$0x1402, %edx           # imm = 0x1402
     6b3:      	btl	%ecx, %edx
     6b6:      	jae	0x802 <filter_64ty_selector_val+0x1f2>
     6bc:      	movq	(%rsi), %rcx
     6bf:      	cmpq	0x10(%rdi), %rcx
     6c3:      	jl	0x62e <filter_64ty_selector_val+0x1e>
     6c9:      	movl	0x8(%rdi), %edx
     6cc:      	cmpl	$0x11, %edx
     6cf:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     6d5:      	cmpq	0x18(%rdi), %rcx
     6d9:      	jl	0x62e <filter_64ty_selector_val+0x1e>
     6df:      	cmpl	$0x19, %edx
     6e2:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     6e8:      	cmpq	0x20(%rdi), %rcx
     6ec:      	jl	0x62e <filter_64ty_selector_val+0x1e>
     6f2:      	cmpl	$0x21, %edx
     6f5:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     6fb:      	cmpq	0x28(%rdi), %rcx
     6ff:      	jl	0x62e <filter_64ty_selector_val+0x1e>
     705:      	jmp	0x83f <filter_64ty_selector_val+0x22f>
     70a:      	movl	0xc(%rdi), %ecx
     70d:      	cmpl	$0xc, %ecx
     710:      	ja	0x7c3 <filter_64ty_selector_val+0x1b3>
     716:      	movl	$0x1402, %edx           # imm = 0x1402
     71b:      	btl	%ecx, %edx
     71e:      	jae	0x7c3 <filter_64ty_selector_val+0x1b3>
     724:      	movq	(%rsi), %rcx
     727:      	cmpq	0x10(%rdi), %rcx
     72b:      	jg	0x62e <filter_64ty_selector_val+0x1e>
     731:      	movl	0x8(%rdi), %edx
     734:      	cmpl	$0x11, %edx
     737:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     73d:      	cmpq	0x18(%rdi), %rcx
     741:      	jg	0x62e <filter_64ty_selector_val+0x1e>
     747:      	cmpl	$0x19, %edx
     74a:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     750:      	cmpq	0x20(%rdi), %rcx
     754:      	jg	0x62e <filter_64ty_selector_val+0x1e>
     75a:      	cmpl	$0x21, %edx
     75d:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     763:      	cmpq	0x28(%rdi), %rcx
     767:      	jg	0x62e <filter_64ty_selector_val+0x1e>
     76d:      	jmp	0x83f <filter_64ty_selector_val+0x22f>
     772:      	movl	0x8(%rdi), %esi
     775:      	cmpl	$0x11, %esi
     778:      	jb	0x7a2 <filter_64ty_selector_val+0x192>
     77a:      	cmpq	0x18(%rdi), %rdx
     77e:      	je	0x647 <filter_64ty_selector_val+0x37>
     784:      	cmpl	$0x19, %esi
     787:      	jb	0x7a2 <filter_64ty_selector_val+0x192>
     789:      	cmpq	0x20(%rdi), %rdx
     78d:      	je	0x647 <filter_64ty_selector_val+0x37>
     793:      	cmpl	$0x21, %esi
     796:      	jb	0x7a2 <filter_64ty_selector_val+0x192>
     798:      	cmpq	0x28(%rdi), %rdx
     79c:      	je	0x647 <filter_64ty_selector_val+0x37>
     7a2:      	cmpl	$0x25, %ecx
     7a5:      	ja	0x83f <filter_64ty_selector_val+0x22f>
     7ab:      	movl	%ecx, %ecx
     7ad:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     7b7:      	btq	%rcx, %rdx
     7bb:      	jb	0x62e <filter_64ty_selector_val+0x1e>
     7c1:      	jmp	0x83f <filter_64ty_selector_val+0x22f>
     7c3:      	movq	(%rsi), %rcx
     7c6:      	cmpq	0x10(%rdi), %rcx
     7ca:      	ja	0x62e <filter_64ty_selector_val+0x1e>
     7d0:      	movl	0x8(%rdi), %edx
     7d3:      	cmpl	$0x11, %edx
     7d6:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     7d8:      	cmpq	0x18(%rdi), %rcx
     7dc:      	ja	0x62e <filter_64ty_selector_val+0x1e>
     7e2:      	cmpl	$0x19, %edx
     7e5:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     7e7:      	cmpq	0x20(%rdi), %rcx
     7eb:      	ja	0x62e <filter_64ty_selector_val+0x1e>
     7f1:      	cmpl	$0x21, %edx
     7f4:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     7f6:      	cmpq	0x28(%rdi), %rcx
     7fa:      	ja	0x62e <filter_64ty_selector_val+0x1e>
     800:      	jmp	0x83f <filter_64ty_selector_val+0x22f>
     802:      	movq	(%rsi), %rcx
     805:      	cmpq	0x10(%rdi), %rcx
     809:      	jb	0x62e <filter_64ty_selector_val+0x1e>
     80f:      	movl	0x8(%rdi), %edx
     812:      	cmpl	$0x11, %edx
     815:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     817:      	cmpq	0x18(%rdi), %rcx
     81b:      	jb	0x62e <filter_64ty_selector_val+0x1e>
     821:      	cmpl	$0x19, %edx
     824:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     826:      	cmpq	0x20(%rdi), %rcx
     82a:      	jb	0x62e <filter_64ty_selector_val+0x1e>
     830:      	cmpl	$0x21, %edx
     833:      	jb	0x83f <filter_64ty_selector_val+0x22f>
     835:      	cmpq	0x28(%rdi), %rcx
     839:      	jb	0x62e <filter_64ty_selector_val+0x1e>
     83f:      	xorl	%eax, %eax
     841:      	retq
     842:      	nopw	%cs:(%rax,%rax)

0000000000000850 <filter_64ty_map>:
     850:      	pushq	%r14
     852:      	pushq	%rbx
     853:      	subq	$0x18, %rsp
     857:      	movq	%rsi, %r14
     85a:      	movq	%rdi, %rbx
     85d:      	movzbl	0x10(%rdi), %eax
     861:      	movl	%eax, 0xc(%rsp)
     865:      	movq	(%rip), %rdi            # 0x86c <filter_64ty_map+0x1c>
     86c:      	leaq	0xc(%rsp), %rsi
     871:      	movl	$0x1, %eax
     876:      	callq	*%rax
     878:      	testq	%rax, %rax
     87b:      	je	0x8a9 <filter_64ty_map+0x59>
     87d:      	movq	%rax, %rdi
     880:      	movq	(%r14), %rax
     883:      	movq	%rax, 0x10(%rsp)
     888:      	leaq	0x10(%rsp), %rsi
     88d:      	movl	$0x1, %eax
     892:      	callq	*%rax
     894:      	movl	0x4(%rbx), %ecx
     897:      	cmpl	$0xb, %ecx
     89a:      	je	0x8b3 <filter_64ty_map+0x63>
     89c:      	cmpl	$0xa, %ecx
     89f:      	jne	0x8bb <filter_64ty_map+0x6b>
     8a1:      	testq	%rax, %rax
     8a4:      	setne	%al
     8a7:      	jmp	0x8bd <filter_64ty_map+0x6d>
     8a9:      	xorl	%eax, %eax
     8ab:      	addq	$0x18, %rsp
     8af:      	popq	%rbx
     8b0:      	popq	%r14
     8b2:      	retq
     8b3:      	testq	%rax, %rax
     8b6:      	sete	%al
     8b9:      	jmp	0x8bd <filter_64ty_map+0x6d>
     8bb:      	xorl	%eax, %eax
     8bd:      	movzbl	%al, %eax
     8c0:      	addq	$0x18, %rsp
     8c4:      	popq	%rbx
     8c5:      	popq	%r14
     8c7:      	retq
     8c8:      	nopl	(%rax,%rax)

00000000000008d0 <filter_64ty_range>:
     8d0:      	movl	0x4(%rdi), %ecx
     8d3:      	movl	0xc(%rdi), %eax
     8d6:      	cmpl	$0xc, %eax
     8d9:      	ja	0x9d0 <filter_64ty_range+0x100>
     8df:      	movl	$0x1402, %edx           # imm = 0x1402
     8e4:      	btl	%eax, %edx
     8e7:      	jae	0x9d0 <filter_64ty_range+0x100>
     8ed:      	movq	(%rsi), %rsi
     8f0:      	cmpl	$0x1f, %ecx
     8f3:      	jne	0x963 <filter_64ty_range+0x93>
     8f5:      	movl	$0x1, %eax
     8fa:      	cmpq	%rsi, 0x10(%rdi)
     8fe:      	jg	0x90a <filter_64ty_range+0x3a>
     900:      	cmpq	0x18(%rdi), %rsi
     904:      	jle	0x9e9 <filter_64ty_range+0x119>
     90a:      	movl	0x8(%rdi), %edx
     90d:      	cmpl	$0x19, %edx
     910:      	jb	0xa97 <filter_64ty_range+0x1c7>
     916:      	cmpq	%rsi, 0x20(%rdi)
     91a:      	jg	0x926 <filter_64ty_range+0x56>
     91c:      	cmpq	0x28(%rdi), %rsi
     920:      	jle	0x9e9 <filter_64ty_range+0x119>
     926:      	cmpl	$0x29, %edx
     929:      	jb	0xa97 <filter_64ty_range+0x1c7>
     92f:      	cmpq	%rsi, 0x30(%rdi)
     933:      	jg	0x93f <filter_64ty_range+0x6f>
     935:      	cmpq	0x38(%rdi), %rsi
     939:      	jle	0x9e9 <filter_64ty_range+0x119>
     93f:      	cmpl	$0x39, %edx
     942:      	jb	0xa97 <filter_64ty_range+0x1c7>
     948:      	xorl	%edx, %edx
     94a:      	cmpq	%rsi, 0x40(%rdi)
     94e:      	jg	0xa99 <filter_64ty_range+0x1c9>
     954:      	cmpq	0x48(%rdi), %rsi
     958:      	jle	0x9e9 <filter_64ty_range+0x119>
     95e:      	jmp	0xa99 <filter_64ty_range+0x1c9>
     963:      	movl	0x8(%rdi), %eax
     966:      	cmpq	%rsi, 0x10(%rdi)
     96a:      	setle	%r8b
     96e:      	cmpq	0x18(%rdi), %rsi
     972:      	setle	%dl
     975:      	andb	%r8b, %dl
     978:      	cmpl	$0x19, %eax
     97b:      	jb	0xa99 <filter_64ty_range+0x1c9>
     981:      	cmpq	%rsi, 0x20(%rdi)
     985:      	setle	%r8b
     989:      	cmpq	0x28(%rdi), %rsi
     98d:      	setle	%r9b
     991:      	andb	%r8b, %r9b
     994:      	orb	%r9b, %dl
     997:      	cmpl	$0x29, %eax
     99a:      	jb	0xa99 <filter_64ty_range+0x1c9>
     9a0:      	cmpq	%rsi, 0x30(%rdi)
     9a4:      	setle	%r8b
     9a8:      	cmpq	0x38(%rdi), %rsi
     9ac:      	setle	%r9b
     9b0:      	andb	%r8b, %r9b
     9b3:      	orb	%r9b, %dl
     9b6:      	cmpl	$0x39, %eax
     9b9:      	jb	0xa99 <filter_64ty_range+0x1c9>
     9bf:      	cmpq	%rsi, 0x40(%rdi)
     9c3:      	setle	%al
     9c6:      	cmpq	0x48(%rdi), %rsi
     9ca:      	setle	%sil
     9ce:      	jmp	0xa4d <filter_64ty_range+0x17d>
     9d0:      	movq	(%rsi), %rsi
     9d3:      	cmpl	$0x1f, %ecx
     9d6:      	jne	0x9ea <filter_64ty_range+0x11a>
     9d8:      	movl	$0x1, %eax
     9dd:      	cmpq	%rsi, 0x10(%rdi)
     9e1:      	ja	0xa55 <filter_64ty_range+0x185>
     9e3:      	cmpq	0x18(%rdi), %rsi
     9e7:      	ja	0xa55 <filter_64ty_range+0x185>
     9e9:      	retq
     9ea:      	movl	0x8(%rdi), %eax
     9ed:      	cmpq	%rsi, 0x10(%rdi)
     9f1:      	setbe	%r8b
     9f5:      	cmpq	0x18(%rdi), %rsi
     9f9:      	setbe	%dl
     9fc:      	andb	%r8b, %dl
     9ff:      	cmpl	$0x19, %eax
     a02:      	jb	0xa99 <filter_64ty_range+0x1c9>
     a08:      	cmpq	%rsi, 0x20(%rdi)
     a0c:      	setbe	%r8b
     a10:      	cmpq	0x28(%rdi), %rsi
     a14:      	setbe	%r9b
     a18:      	andb	%r8b, %r9b
     a1b:      	orb	%r9b, %dl
     a1e:      	cmpl	$0x29, %eax
     a21:      	jb	0xa99 <filter_64ty_range+0x1c9>
     a23:      	cmpq	%rsi, 0x30(%rdi)
     a27:      	setbe	%r8b
     a2b:      	cmpq	0x38(%rdi), %rsi
     a2f:      	setbe	%r9b
     a33:      	andb	%r8b, %r9b
     a36:      	orb	%r9b, %dl
     a39:      	cmpl	$0x39, %eax
     a3c:      	jb	0xa99 <filter_64ty_range+0x1c9>
     a3e:      	cmpq	%rsi, 0x40(%rdi)
     a42:      	setbe	%al
     a45:      	cmpq	0x48(%rdi), %rsi
     a49:      	setbe	%sil
     a4d:      	andb	%al, %sil
     a50:      	orb	%sil, %dl
     a53:      	jmp	0xa99 <filter_64ty_range+0x1c9>
     a55:      	movl	0x8(%rdi), %edx
     a58:      	cmpl	$0x19, %edx
     a5b:      	jb	0xa97 <filter_64ty_range+0x1c7>
     a5d:      	cmpq	%rsi, 0x20(%rdi)
     a61:      	ja	0xa69 <filter_64ty_range+0x199>
     a63:      	cmpq	0x28(%rdi), %rsi
     a67:      	jbe	0x9e9 <filter_64ty_range+0x119>
     a69:      	cmpl	$0x29, %edx
     a6c:      	jb	0xa97 <filter_64ty_range+0x1c7>
     a6e:      	cmpq	%rsi, 0x30(%rdi)
     a72:      	ja	0xa7e <filter_64ty_range+0x1ae>
     a74:      	cmpq	0x38(%rdi), %rsi
     a78:      	jbe	0x9e9 <filter_64ty_range+0x119>
     a7e:      	cmpl	$0x39, %edx
     a81:      	jb	0xa97 <filter_64ty_range+0x1c7>
     a83:      	xorl	%edx, %edx
     a85:      	cmpq	%rsi, 0x40(%rdi)
     a89:      	ja	0xa99 <filter_64ty_range+0x1c9>
     a8b:      	cmpq	0x48(%rdi), %rsi
     a8f:      	jbe	0x9e9 <filter_64ty_range+0x119>
     a95:      	jmp	0xa99 <filter_64ty_range+0x1c9>
     a97:      	xorl	%edx, %edx
     a99:      	cmpl	$0x20, %ecx
     a9c:      	sete	%al
     a9f:      	xorb	$0x1, %dl
     aa2:      	andb	%al, %dl
     aa4:      	movzbl	%dl, %eax
     aa7:      	retq
     aa8:      	nopl	(%rax,%rax)

0000000000000ab0 <filter_32ty_selector_val>:
     ab0:      	movl	0x4(%rdi), %ecx
     ab3:      	movl	$0x1, %eax
     ab8:      	cmpq	$0x25, %rcx
     abc:      	ja	0xb2d <filter_32ty_selector_val+0x7d>
     abe:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     ac8:      	btq	%rcx, %rdx
     acc:      	jae	0xacf <filter_32ty_selector_val+0x1f>
     ace:      	retq
     acf:      	movl	$0x18, %edx
     ad4:      	btq	%rcx, %rdx
     ad8:      	jae	0xaee <filter_32ty_selector_val+0x3e>
     ada:      	movl	(%rsi), %edx
     adc:      	cmpl	0x10(%rdi), %edx
     adf:      	jne	0xc01 <filter_32ty_selector_val+0x151>
     ae5:      	xorl	%eax, %eax
     ae7:      	cmpl	$0x3, %ecx
     aea:      	sete	%al
     aed:      	retq
     aee:      	cmpq	$0xc, %rcx
     af2:      	jne	0xb2d <filter_32ty_selector_val+0x7d>
     af4:      	movl	(%rsi), %ecx
     af6:      	testl	%ecx, 0x10(%rdi)
     af9:      	jne	0xace <filter_32ty_selector_val+0x1e>
     afb:      	movl	0x8(%rdi), %edx
     afe:      	cmpl	$0xd, %edx
     b01:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     b07:      	testl	%ecx, 0x14(%rdi)
     b0a:      	jne	0xace <filter_32ty_selector_val+0x1e>
     b0c:      	cmpl	$0x11, %edx
     b0f:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     b15:      	testl	%ecx, 0x18(%rdi)
     b18:      	jne	0xace <filter_32ty_selector_val+0x1e>
     b1a:      	cmpl	$0x15, %edx
     b1d:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     b23:      	testl	%ecx, 0x1c(%rdi)
     b26:      	jne	0xace <filter_32ty_selector_val+0x1e>
     b28:      	jmp	0xcc1 <filter_32ty_selector_val+0x211>
     b2d:      	cmpl	$0x1, %ecx
     b30:      	je	0xb9e <filter_32ty_selector_val+0xee>
     b32:      	cmpl	$0x2, %ecx
     b35:      	jne	0xcc1 <filter_32ty_selector_val+0x211>
     b3b:      	movl	0xc(%rdi), %ecx
     b3e:      	cmpl	$0xc, %ecx
     b41:      	ja	0xc89 <filter_32ty_selector_val+0x1d9>
     b47:      	movl	$0x1402, %edx           # imm = 0x1402
     b4c:      	btl	%ecx, %edx
     b4f:      	jae	0xc89 <filter_32ty_selector_val+0x1d9>
     b55:      	movl	(%rsi), %ecx
     b57:      	cmpl	0x10(%rdi), %ecx
     b5a:      	jl	0xace <filter_32ty_selector_val+0x1e>
     b60:      	movl	0x8(%rdi), %edx
     b63:      	cmpl	$0xd, %edx
     b66:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     b6c:      	cmpl	0x14(%rdi), %ecx
     b6f:      	jl	0xace <filter_32ty_selector_val+0x1e>
     b75:      	cmpl	$0x11, %edx
     b78:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     b7e:      	cmpl	0x18(%rdi), %ecx
     b81:      	jl	0xace <filter_32ty_selector_val+0x1e>
     b87:      	cmpl	$0x15, %edx
     b8a:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     b90:      	cmpl	0x1c(%rdi), %ecx
     b93:      	jl	0xace <filter_32ty_selector_val+0x1e>
     b99:      	jmp	0xcc1 <filter_32ty_selector_val+0x211>
     b9e:      	movl	0xc(%rdi), %ecx
     ba1:      	cmpl	$0xc, %ecx
     ba4:      	ja	0xc4f <filter_32ty_selector_val+0x19f>
     baa:      	movl	$0x1402, %edx           # imm = 0x1402
     baf:      	btl	%ecx, %edx
     bb2:      	jae	0xc4f <filter_32ty_selector_val+0x19f>
     bb8:      	movl	(%rsi), %ecx
     bba:      	cmpl	0x10(%rdi), %ecx
     bbd:      	jg	0xace <filter_32ty_selector_val+0x1e>
     bc3:      	movl	0x8(%rdi), %edx
     bc6:      	cmpl	$0xd, %edx
     bc9:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     bcf:      	cmpl	0x14(%rdi), %ecx
     bd2:      	jg	0xace <filter_32ty_selector_val+0x1e>
     bd8:      	cmpl	$0x11, %edx
     bdb:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     be1:      	cmpl	0x18(%rdi), %ecx
     be4:      	jg	0xace <filter_32ty_selector_val+0x1e>
     bea:      	cmpl	$0x15, %edx
     bed:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     bf3:      	cmpl	0x1c(%rdi), %ecx
     bf6:      	jg	0xace <filter_32ty_selector_val+0x1e>
     bfc:      	jmp	0xcc1 <filter_32ty_selector_val+0x211>
     c01:      	movl	0x8(%rdi), %esi
     c04:      	cmpl	$0xd, %esi
     c07:      	jb	0xc2e <filter_32ty_selector_val+0x17e>
     c09:      	cmpl	0x14(%rdi), %edx
     c0c:      	je	0xae5 <filter_32ty_selector_val+0x35>
     c12:      	cmpl	$0x11, %esi
     c15:      	jb	0xc2e <filter_32ty_selector_val+0x17e>
     c17:      	cmpl	0x18(%rdi), %edx
     c1a:      	je	0xae5 <filter_32ty_selector_val+0x35>
     c20:      	cmpl	$0x15, %esi
     c23:      	jb	0xc2e <filter_32ty_selector_val+0x17e>
     c25:      	cmpl	0x1c(%rdi), %edx
     c28:      	je	0xae5 <filter_32ty_selector_val+0x35>
     c2e:      	cmpl	$0x25, %ecx
     c31:      	ja	0xcc1 <filter_32ty_selector_val+0x211>
     c37:      	movl	%ecx, %ecx
     c39:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     c43:      	btq	%rcx, %rdx
     c47:      	jb	0xace <filter_32ty_selector_val+0x1e>
     c4d:      	jmp	0xcc1 <filter_32ty_selector_val+0x211>
     c4f:      	movl	(%rsi), %ecx
     c51:      	cmpl	0x10(%rdi), %ecx
     c54:      	ja	0xace <filter_32ty_selector_val+0x1e>
     c5a:      	movl	0x8(%rdi), %edx
     c5d:      	cmpl	$0xd, %edx
     c60:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     c62:      	cmpl	0x14(%rdi), %ecx
     c65:      	ja	0xace <filter_32ty_selector_val+0x1e>
     c6b:      	cmpl	$0x11, %edx
     c6e:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     c70:      	cmpl	0x18(%rdi), %ecx
     c73:      	ja	0xace <filter_32ty_selector_val+0x1e>
     c79:      	cmpl	$0x15, %edx
     c7c:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     c7e:      	cmpl	0x1c(%rdi), %ecx
     c81:      	ja	0xace <filter_32ty_selector_val+0x1e>
     c87:      	jmp	0xcc1 <filter_32ty_selector_val+0x211>
     c89:      	movl	(%rsi), %ecx
     c8b:      	cmpl	0x10(%rdi), %ecx
     c8e:      	jb	0xace <filter_32ty_selector_val+0x1e>
     c94:      	movl	0x8(%rdi), %edx
     c97:      	cmpl	$0xd, %edx
     c9a:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     c9c:      	cmpl	0x14(%rdi), %ecx
     c9f:      	jb	0xace <filter_32ty_selector_val+0x1e>
     ca5:      	cmpl	$0x11, %edx
     ca8:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     caa:      	cmpl	0x18(%rdi), %ecx
     cad:      	jb	0xace <filter_32ty_selector_val+0x1e>
     cb3:      	cmpl	$0x15, %edx
     cb6:      	jb	0xcc1 <filter_32ty_selector_val+0x211>
     cb8:      	cmpl	0x1c(%rdi), %ecx
     cbb:      	jb	0xace <filter_32ty_selector_val+0x1e>
     cc1:      	xorl	%eax, %eax
     cc3:      	retq
     cc4:      	nopw	%cs:(%rax,%rax)

0000000000000cd0 <filter_32ty_map>:
     cd0:      	pushq	%r14
     cd2:      	pushq	%rbx
     cd3:      	subq	$0x18, %rsp
     cd7:      	movq	%rsi, %r14
     cda:      	movq	%rdi, %rbx
     cdd:      	movzbl	0x10(%rdi), %eax
     ce1:      	movl	%eax, 0xc(%rsp)
     ce5:      	movq	(%rip), %rdi            # 0xcec <filter_32ty_map+0x1c>
     cec:      	leaq	0xc(%rsp), %rsi
     cf1:      	movl	$0x1, %eax
     cf6:      	callq	*%rax
     cf8:      	testq	%rax, %rax
     cfb:      	je	0xd30 <filter_32ty_map+0x60>
     cfd:      	movq	%rax, %rdi
     d00:      	movl	(%r14), %eax
     d03:      	movq	%rax, 0x10(%rsp)
     d08:      	leaq	0x10(%rsp), %rsi
     d0d:      	movl	$0x1, %eax
     d12:      	callq	*%rax
     d14:      	movl	0x4(%rbx), %edx
     d17:      	xorl	%ecx, %ecx
     d19:      	cmpl	$0x1d, %edx
     d1c:      	ja	0xd4a <filter_32ty_map+0x7a>
     d1e:      	movl	$0x30038400, %esi       # imm = 0x30038400
     d23:      	btl	%edx, %esi
     d26:      	jae	0xd3a <filter_32ty_map+0x6a>
     d28:      	testq	%rax, %rax
     d2b:      	setne	%cl
     d2e:      	jmp	0xd4a <filter_32ty_map+0x7a>
     d30:      	xorl	%eax, %eax
     d32:      	addq	$0x18, %rsp
     d36:      	popq	%rbx
     d37:      	popq	%r14
     d39:      	retq
     d3a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     d3f:      	btl	%edx, %esi
     d42:      	jae	0xd4a <filter_32ty_map+0x7a>
     d44:      	testq	%rax, %rax
     d47:      	sete	%cl
     d4a:      	movzbl	%cl, %eax
     d4d:      	addq	$0x18, %rsp
     d51:      	popq	%rbx
     d52:      	popq	%r14
     d54:      	retq
     d55:      	nopw	%cs:(%rax,%rax)

0000000000000d60 <filter_32ty_range>:
     d60:      	movl	0x4(%rdi), %ecx
     d63:      	movl	0xc(%rdi), %eax
     d66:      	cmpl	$0xc, %eax
     d69:      	ja	0xe4f <filter_32ty_range+0xef>
     d6f:      	movl	$0x1402, %edx           # imm = 0x1402
     d74:      	btl	%eax, %edx
     d77:      	jae	0xe4f <filter_32ty_range+0xef>
     d7d:      	movl	(%rsi), %esi
     d7f:      	cmpl	$0x1f, %ecx
     d82:      	jne	0xdea <filter_32ty_range+0x8a>
     d84:      	movl	$0x1, %eax
     d89:      	cmpl	%esi, 0x10(%rdi)
     d8c:      	jg	0xd97 <filter_32ty_range+0x37>
     d8e:      	cmpl	0x14(%rdi), %esi
     d91:      	jle	0xe65 <filter_32ty_range+0x105>
     d97:      	movl	0x8(%rdi), %edx
     d9a:      	cmpl	$0x11, %edx
     d9d:      	jb	0xf05 <filter_32ty_range+0x1a5>
     da3:      	cmpl	%esi, 0x18(%rdi)
     da6:      	jg	0xdb1 <filter_32ty_range+0x51>
     da8:      	cmpl	0x1c(%rdi), %esi
     dab:      	jle	0xe65 <filter_32ty_range+0x105>
     db1:      	cmpl	$0x19, %edx
     db4:      	jb	0xf05 <filter_32ty_range+0x1a5>
     dba:      	cmpl	%esi, 0x20(%rdi)
     dbd:      	jg	0xdc8 <filter_32ty_range+0x68>
     dbf:      	cmpl	0x24(%rdi), %esi
     dc2:      	jle	0xe65 <filter_32ty_range+0x105>
     dc8:      	cmpl	$0x21, %edx
     dcb:      	jb	0xf05 <filter_32ty_range+0x1a5>
     dd1:      	xorl	%edx, %edx
     dd3:      	cmpl	%esi, 0x28(%rdi)
     dd6:      	jg	0xf07 <filter_32ty_range+0x1a7>
     ddc:      	cmpl	0x2c(%rdi), %esi
     ddf:      	jle	0xe65 <filter_32ty_range+0x105>
     de5:      	jmp	0xf07 <filter_32ty_range+0x1a7>
     dea:      	movl	0x8(%rdi), %eax
     ded:      	cmpl	%esi, 0x10(%rdi)
     df0:      	setle	%r8b
     df4:      	cmpl	0x14(%rdi), %esi
     df7:      	setle	%dl
     dfa:      	andb	%r8b, %dl
     dfd:      	cmpl	$0x11, %eax
     e00:      	jb	0xf07 <filter_32ty_range+0x1a7>
     e06:      	cmpl	%esi, 0x18(%rdi)
     e09:      	setle	%r8b
     e0d:      	cmpl	0x1c(%rdi), %esi
     e10:      	setle	%r9b
     e14:      	andb	%r8b, %r9b
     e17:      	orb	%r9b, %dl
     e1a:      	cmpl	$0x19, %eax
     e1d:      	jb	0xf07 <filter_32ty_range+0x1a7>
     e23:      	cmpl	%esi, 0x20(%rdi)
     e26:      	setle	%r8b
     e2a:      	cmpl	0x24(%rdi), %esi
     e2d:      	setle	%r9b
     e31:      	andb	%r8b, %r9b
     e34:      	orb	%r9b, %dl
     e37:      	cmpl	$0x21, %eax
     e3a:      	jb	0xf07 <filter_32ty_range+0x1a7>
     e40:      	cmpl	%esi, 0x28(%rdi)
     e43:      	setle	%al
     e46:      	cmpl	0x2c(%rdi), %esi
     e49:      	setle	%sil
     e4d:      	jmp	0xec1 <filter_32ty_range+0x161>
     e4f:      	movl	(%rsi), %esi
     e51:      	cmpl	$0x1f, %ecx
     e54:      	jne	0xe66 <filter_32ty_range+0x106>
     e56:      	movl	$0x1, %eax
     e5b:      	cmpl	%esi, 0x10(%rdi)
     e5e:      	ja	0xec9 <filter_32ty_range+0x169>
     e60:      	cmpl	0x14(%rdi), %esi
     e63:      	ja	0xec9 <filter_32ty_range+0x169>
     e65:      	retq
     e66:      	movl	0x8(%rdi), %eax
     e69:      	cmpl	%esi, 0x10(%rdi)
     e6c:      	setbe	%r8b
     e70:      	cmpl	0x14(%rdi), %esi
     e73:      	setbe	%dl
     e76:      	andb	%r8b, %dl
     e79:      	cmpl	$0x11, %eax
     e7c:      	jb	0xf07 <filter_32ty_range+0x1a7>
     e82:      	cmpl	%esi, 0x18(%rdi)
     e85:      	setbe	%r8b
     e89:      	cmpl	0x1c(%rdi), %esi
     e8c:      	setbe	%r9b
     e90:      	andb	%r8b, %r9b
     e93:      	orb	%r9b, %dl
     e96:      	cmpl	$0x19, %eax
     e99:      	jb	0xf07 <filter_32ty_range+0x1a7>
     e9b:      	cmpl	%esi, 0x20(%rdi)
     e9e:      	setbe	%r8b
     ea2:      	cmpl	0x24(%rdi), %esi
     ea5:      	setbe	%r9b
     ea9:      	andb	%r8b, %r9b
     eac:      	orb	%r9b, %dl
     eaf:      	cmpl	$0x21, %eax
     eb2:      	jb	0xf07 <filter_32ty_range+0x1a7>
     eb4:      	cmpl	%esi, 0x28(%rdi)
     eb7:      	setbe	%al
     eba:      	cmpl	0x2c(%rdi), %esi
     ebd:      	setbe	%sil
     ec1:      	andb	%al, %sil
     ec4:      	orb	%sil, %dl
     ec7:      	jmp	0xf07 <filter_32ty_range+0x1a7>
     ec9:      	movl	0x8(%rdi), %edx
     ecc:      	cmpl	$0x11, %edx
     ecf:      	jb	0xf05 <filter_32ty_range+0x1a5>
     ed1:      	cmpl	%esi, 0x18(%rdi)
     ed4:      	ja	0xedb <filter_32ty_range+0x17b>
     ed6:      	cmpl	0x1c(%rdi), %esi
     ed9:      	jbe	0xe65 <filter_32ty_range+0x105>
     edb:      	cmpl	$0x19, %edx
     ede:      	jb	0xf05 <filter_32ty_range+0x1a5>
     ee0:      	cmpl	%esi, 0x20(%rdi)
     ee3:      	ja	0xeee <filter_32ty_range+0x18e>
     ee5:      	cmpl	0x24(%rdi), %esi
     ee8:      	jbe	0xe65 <filter_32ty_range+0x105>
     eee:      	cmpl	$0x21, %edx
     ef1:      	jb	0xf05 <filter_32ty_range+0x1a5>
     ef3:      	xorl	%edx, %edx
     ef5:      	cmpl	%esi, 0x28(%rdi)
     ef8:      	ja	0xf07 <filter_32ty_range+0x1a7>
     efa:      	cmpl	0x2c(%rdi), %esi
     efd:      	jbe	0xe65 <filter_32ty_range+0x105>
     f03:      	jmp	0xf07 <filter_32ty_range+0x1a7>
     f05:      	xorl	%edx, %edx
     f07:      	cmpl	$0x20, %ecx
     f0a:      	sete	%al
     f0d:      	xorb	$0x1, %dl
     f10:      	andb	%al, %dl
     f12:      	movzbl	%dl, %eax
     f15:      	retq
     f16:      	nopw	%cs:(%rax,%rax)

0000000000000f20 <filter_16ty_selector_val>:
     f20:      	movl	0x4(%rdi), %ecx
     f23:      	movl	$0x1, %eax
     f28:      	cmpq	$0x25, %rcx
     f2c:      	ja	0xf9f <filter_16ty_selector_val+0x7f>
     f2e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     f38:      	btq	%rcx, %rdx
     f3c:      	jae	0xf3f <filter_16ty_selector_val+0x1f>
     f3e:      	retq
     f3f:      	movl	$0x18, %edx
     f44:      	btq	%rcx, %rdx
     f48:      	jae	0xf5f <filter_16ty_selector_val+0x3f>
     f4a:      	movzwl	(%rsi), %edx
     f4d:      	cmpl	%edx, 0x10(%rdi)
     f50:      	jne	0x1075 <filter_16ty_selector_val+0x155>
     f56:      	xorl	%eax, %eax
     f58:      	cmpl	$0x3, %ecx
     f5b:      	sete	%al
     f5e:      	retq
     f5f:      	cmpq	$0xc, %rcx
     f63:      	jne	0xf9f <filter_16ty_selector_val+0x7f>
     f65:      	movzwl	(%rsi), %ecx
     f68:      	testl	%ecx, 0x10(%rdi)
     f6b:      	jne	0xf3e <filter_16ty_selector_val+0x1e>
     f6d:      	movl	0x8(%rdi), %edx
     f70:      	cmpl	$0xd, %edx
     f73:      	jb	0x1137 <filter_16ty_selector_val+0x217>
     f79:      	testl	%ecx, 0x14(%rdi)
     f7c:      	jne	0xf3e <filter_16ty_selector_val+0x1e>
     f7e:      	cmpl	$0x11, %edx
     f81:      	jb	0x1137 <filter_16ty_selector_val+0x217>
     f87:      	testl	%ecx, 0x18(%rdi)
     f8a:      	jne	0xf3e <filter_16ty_selector_val+0x1e>
     f8c:      	cmpl	$0x15, %edx
     f8f:      	jb	0x1137 <filter_16ty_selector_val+0x217>
     f95:      	testl	%ecx, 0x1c(%rdi)
     f98:      	jne	0xf3e <filter_16ty_selector_val+0x1e>
     f9a:      	jmp	0x1137 <filter_16ty_selector_val+0x217>
     f9f:      	cmpl	$0x1, %ecx
     fa2:      	je	0x1011 <filter_16ty_selector_val+0xf1>
     fa4:      	cmpl	$0x2, %ecx
     fa7:      	jne	0x1137 <filter_16ty_selector_val+0x217>
     fad:      	movl	0xc(%rdi), %ecx
     fb0:      	cmpl	$0xc, %ecx
     fb3:      	ja	0x10fe <filter_16ty_selector_val+0x1de>
     fb9:      	movl	$0x1402, %edx           # imm = 0x1402
     fbe:      	btl	%ecx, %edx
     fc1:      	jae	0x10fe <filter_16ty_selector_val+0x1de>
     fc7:      	movswl	(%rsi), %ecx
     fca:      	cmpl	%ecx, 0x10(%rdi)
     fcd:      	jg	0xf3e <filter_16ty_selector_val+0x1e>
     fd3:      	movl	0x8(%rdi), %edx
     fd6:      	cmpl	$0xd, %edx
     fd9:      	jb	0x1137 <filter_16ty_selector_val+0x217>
     fdf:      	cmpl	%ecx, 0x14(%rdi)
     fe2:      	jg	0xf3e <filter_16ty_selector_val+0x1e>
     fe8:      	cmpl	$0x11, %edx
     feb:      	jb	0x1137 <filter_16ty_selector_val+0x217>
     ff1:      	cmpl	%ecx, 0x18(%rdi)
     ff4:      	jg	0xf3e <filter_16ty_selector_val+0x1e>
     ffa:      	cmpl	$0x15, %edx
     ffd:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    1003:      	cmpl	%ecx, 0x1c(%rdi)
    1006:      	jg	0xf3e <filter_16ty_selector_val+0x1e>
    100c:      	jmp	0x1137 <filter_16ty_selector_val+0x217>
    1011:      	movl	0xc(%rdi), %ecx
    1014:      	cmpl	$0xc, %ecx
    1017:      	ja	0x10c3 <filter_16ty_selector_val+0x1a3>
    101d:      	movl	$0x1402, %edx           # imm = 0x1402
    1022:      	btl	%ecx, %edx
    1025:      	jae	0x10c3 <filter_16ty_selector_val+0x1a3>
    102b:      	movswl	(%rsi), %ecx
    102e:      	cmpl	%ecx, 0x10(%rdi)
    1031:      	jl	0xf3e <filter_16ty_selector_val+0x1e>
    1037:      	movl	0x8(%rdi), %edx
    103a:      	cmpl	$0xd, %edx
    103d:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    1043:      	cmpl	%ecx, 0x14(%rdi)
    1046:      	jl	0xf3e <filter_16ty_selector_val+0x1e>
    104c:      	cmpl	$0x11, %edx
    104f:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    1055:      	cmpl	%ecx, 0x18(%rdi)
    1058:      	jl	0xf3e <filter_16ty_selector_val+0x1e>
    105e:      	cmpl	$0x15, %edx
    1061:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    1067:      	cmpl	%ecx, 0x1c(%rdi)
    106a:      	jl	0xf3e <filter_16ty_selector_val+0x1e>
    1070:      	jmp	0x1137 <filter_16ty_selector_val+0x217>
    1075:      	movl	0x8(%rdi), %esi
    1078:      	cmpl	$0xd, %esi
    107b:      	jb	0x10a2 <filter_16ty_selector_val+0x182>
    107d:      	cmpl	%edx, 0x14(%rdi)
    1080:      	je	0xf56 <filter_16ty_selector_val+0x36>
    1086:      	cmpl	$0x11, %esi
    1089:      	jb	0x10a2 <filter_16ty_selector_val+0x182>
    108b:      	cmpl	%edx, 0x18(%rdi)
    108e:      	je	0xf56 <filter_16ty_selector_val+0x36>
    1094:      	cmpl	$0x15, %esi
    1097:      	jb	0x10a2 <filter_16ty_selector_val+0x182>
    1099:      	cmpl	%edx, 0x1c(%rdi)
    109c:      	je	0xf56 <filter_16ty_selector_val+0x36>
    10a2:      	cmpl	$0x25, %ecx
    10a5:      	ja	0x1137 <filter_16ty_selector_val+0x217>
    10ab:      	movl	%ecx, %ecx
    10ad:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    10b7:      	btq	%rcx, %rdx
    10bb:      	jb	0xf3e <filter_16ty_selector_val+0x1e>
    10c1:      	jmp	0x1137 <filter_16ty_selector_val+0x217>
    10c3:      	movzwl	(%rsi), %ecx
    10c6:      	cmpl	%ecx, 0x10(%rdi)
    10c9:      	jb	0xf3e <filter_16ty_selector_val+0x1e>
    10cf:      	movl	0x8(%rdi), %edx
    10d2:      	cmpl	$0xd, %edx
    10d5:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    10d7:      	cmpl	%ecx, 0x14(%rdi)
    10da:      	jb	0xf3e <filter_16ty_selector_val+0x1e>
    10e0:      	cmpl	$0x11, %edx
    10e3:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    10e5:      	cmpl	%ecx, 0x18(%rdi)
    10e8:      	jb	0xf3e <filter_16ty_selector_val+0x1e>
    10ee:      	cmpl	$0x15, %edx
    10f1:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    10f3:      	cmpl	%ecx, 0x1c(%rdi)
    10f6:      	jb	0xf3e <filter_16ty_selector_val+0x1e>
    10fc:      	jmp	0x1137 <filter_16ty_selector_val+0x217>
    10fe:      	movzwl	(%rsi), %ecx
    1101:      	cmpl	%ecx, 0x10(%rdi)
    1104:      	ja	0xf3e <filter_16ty_selector_val+0x1e>
    110a:      	movl	0x8(%rdi), %edx
    110d:      	cmpl	$0xd, %edx
    1110:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    1112:      	cmpl	%ecx, 0x14(%rdi)
    1115:      	ja	0xf3e <filter_16ty_selector_val+0x1e>
    111b:      	cmpl	$0x11, %edx
    111e:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    1120:      	cmpl	%ecx, 0x18(%rdi)
    1123:      	ja	0xf3e <filter_16ty_selector_val+0x1e>
    1129:      	cmpl	$0x15, %edx
    112c:      	jb	0x1137 <filter_16ty_selector_val+0x217>
    112e:      	cmpl	%ecx, 0x1c(%rdi)
    1131:      	ja	0xf3e <filter_16ty_selector_val+0x1e>
    1137:      	xorl	%eax, %eax
    1139:      	retq
    113a:      	nopw	(%rax,%rax)

0000000000001140 <filter_16ty_map>:
    1140:      	pushq	%r14
    1142:      	pushq	%rbx
    1143:      	subq	$0x18, %rsp
    1147:      	movq	%rsi, %r14
    114a:      	movq	%rdi, %rbx
    114d:      	movzbl	0x10(%rdi), %eax
    1151:      	movl	%eax, 0xc(%rsp)
    1155:      	movq	(%rip), %rdi            # 0x115c <filter_16ty_map+0x1c>
    115c:      	leaq	0xc(%rsp), %rsi
    1161:      	movl	$0x1, %eax
    1166:      	callq	*%rax
    1168:      	testq	%rax, %rax
    116b:      	je	0x11a1 <filter_16ty_map+0x61>
    116d:      	movq	%rax, %rdi
    1170:      	movzwl	(%r14), %eax
    1174:      	movq	%rax, 0x10(%rsp)
    1179:      	leaq	0x10(%rsp), %rsi
    117e:      	movl	$0x1, %eax
    1183:      	callq	*%rax
    1185:      	movl	0x4(%rbx), %edx
    1188:      	xorl	%ecx, %ecx
    118a:      	cmpl	$0x1d, %edx
    118d:      	ja	0x11bb <filter_16ty_map+0x7b>
    118f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1194:      	btl	%edx, %esi
    1197:      	jae	0x11ab <filter_16ty_map+0x6b>
    1199:      	testq	%rax, %rax
    119c:      	setne	%cl
    119f:      	jmp	0x11bb <filter_16ty_map+0x7b>
    11a1:      	xorl	%eax, %eax
    11a3:      	addq	$0x18, %rsp
    11a7:      	popq	%rbx
    11a8:      	popq	%r14
    11aa:      	retq
    11ab:      	movl	$0xc0800, %esi          # imm = 0xC0800
    11b0:      	btl	%edx, %esi
    11b3:      	jae	0x11bb <filter_16ty_map+0x7b>
    11b5:      	testq	%rax, %rax
    11b8:      	sete	%cl
    11bb:      	movzbl	%cl, %eax
    11be:      	addq	$0x18, %rsp
    11c2:      	popq	%rbx
    11c3:      	popq	%r14
    11c5:      	retq
    11c6:      	nopw	%cs:(%rax,%rax)

00000000000011d0 <filter_16ty_range>:
    11d0:      	movl	0x4(%rdi), %ecx
    11d3:      	movl	0xc(%rdi), %eax
    11d6:      	cmpl	$0xc, %eax
    11d9:      	ja	0x12c0 <filter_16ty_range+0xf0>
    11df:      	movl	$0x1402, %edx           # imm = 0x1402
    11e4:      	btl	%eax, %edx
    11e7:      	jae	0x12c0 <filter_16ty_range+0xf0>
    11ed:      	movswl	(%rsi), %esi
    11f0:      	cmpl	$0x1f, %ecx
    11f3:      	jne	0x125b <filter_16ty_range+0x8b>
    11f5:      	movl	$0x1, %eax
    11fa:      	cmpl	%esi, 0x10(%rdi)
    11fd:      	jg	0x1208 <filter_16ty_range+0x38>
    11ff:      	cmpl	%esi, 0x14(%rdi)
    1202:      	jge	0x12d7 <filter_16ty_range+0x107>
    1208:      	movl	0x8(%rdi), %edx
    120b:      	cmpl	$0x11, %edx
    120e:      	jb	0x1377 <filter_16ty_range+0x1a7>
    1214:      	cmpl	%esi, 0x18(%rdi)
    1217:      	jg	0x1222 <filter_16ty_range+0x52>
    1219:      	cmpl	%esi, 0x1c(%rdi)
    121c:      	jge	0x12d7 <filter_16ty_range+0x107>
    1222:      	cmpl	$0x19, %edx
    1225:      	jb	0x1377 <filter_16ty_range+0x1a7>
    122b:      	cmpl	%esi, 0x20(%rdi)
    122e:      	jg	0x1239 <filter_16ty_range+0x69>
    1230:      	cmpl	%esi, 0x24(%rdi)
    1233:      	jge	0x12d7 <filter_16ty_range+0x107>
    1239:      	cmpl	$0x21, %edx
    123c:      	jb	0x1377 <filter_16ty_range+0x1a7>
    1242:      	xorl	%edx, %edx
    1244:      	cmpl	%esi, 0x28(%rdi)
    1247:      	jg	0x1379 <filter_16ty_range+0x1a9>
    124d:      	cmpl	%esi, 0x2c(%rdi)
    1250:      	jge	0x12d7 <filter_16ty_range+0x107>
    1256:      	jmp	0x1379 <filter_16ty_range+0x1a9>
    125b:      	movl	0x8(%rdi), %eax
    125e:      	cmpl	%esi, 0x10(%rdi)
    1261:      	setle	%r8b
    1265:      	cmpl	%esi, 0x14(%rdi)
    1268:      	setge	%dl
    126b:      	andb	%r8b, %dl
    126e:      	cmpl	$0x11, %eax
    1271:      	jb	0x1379 <filter_16ty_range+0x1a9>
    1277:      	cmpl	%esi, 0x18(%rdi)
    127a:      	setle	%r8b
    127e:      	cmpl	%esi, 0x1c(%rdi)
    1281:      	setge	%r9b
    1285:      	andb	%r8b, %r9b
    1288:      	orb	%r9b, %dl
    128b:      	cmpl	$0x19, %eax
    128e:      	jb	0x1379 <filter_16ty_range+0x1a9>
    1294:      	cmpl	%esi, 0x20(%rdi)
    1297:      	setle	%r8b
    129b:      	cmpl	%esi, 0x24(%rdi)
    129e:      	setge	%r9b
    12a2:      	andb	%r8b, %r9b
    12a5:      	orb	%r9b, %dl
    12a8:      	cmpl	$0x21, %eax
    12ab:      	jb	0x1379 <filter_16ty_range+0x1a9>
    12b1:      	cmpl	%esi, 0x28(%rdi)
    12b4:      	setle	%al
    12b7:      	cmpl	%esi, 0x2c(%rdi)
    12ba:      	setge	%sil
    12be:      	jmp	0x1333 <filter_16ty_range+0x163>
    12c0:      	movzwl	(%rsi), %esi
    12c3:      	cmpl	$0x1f, %ecx
    12c6:      	jne	0x12d8 <filter_16ty_range+0x108>
    12c8:      	movl	$0x1, %eax
    12cd:      	cmpl	%esi, 0x10(%rdi)
    12d0:      	ja	0x133b <filter_16ty_range+0x16b>
    12d2:      	cmpl	%esi, 0x14(%rdi)
    12d5:      	jb	0x133b <filter_16ty_range+0x16b>
    12d7:      	retq
    12d8:      	movl	0x8(%rdi), %eax
    12db:      	cmpl	%esi, 0x10(%rdi)
    12de:      	setbe	%r8b
    12e2:      	cmpl	%esi, 0x14(%rdi)
    12e5:      	setae	%dl
    12e8:      	andb	%r8b, %dl
    12eb:      	cmpl	$0x11, %eax
    12ee:      	jb	0x1379 <filter_16ty_range+0x1a9>
    12f4:      	cmpl	%esi, 0x18(%rdi)
    12f7:      	setbe	%r8b
    12fb:      	cmpl	%esi, 0x1c(%rdi)
    12fe:      	setae	%r9b
    1302:      	andb	%r8b, %r9b
    1305:      	orb	%r9b, %dl
    1308:      	cmpl	$0x19, %eax
    130b:      	jb	0x1379 <filter_16ty_range+0x1a9>
    130d:      	cmpl	%esi, 0x20(%rdi)
    1310:      	setbe	%r8b
    1314:      	cmpl	%esi, 0x24(%rdi)
    1317:      	setae	%r9b
    131b:      	andb	%r8b, %r9b
    131e:      	orb	%r9b, %dl
    1321:      	cmpl	$0x21, %eax
    1324:      	jb	0x1379 <filter_16ty_range+0x1a9>
    1326:      	cmpl	%esi, 0x28(%rdi)
    1329:      	setbe	%al
    132c:      	cmpl	%esi, 0x2c(%rdi)
    132f:      	setae	%sil
    1333:      	andb	%al, %sil
    1336:      	orb	%sil, %dl
    1339:      	jmp	0x1379 <filter_16ty_range+0x1a9>
    133b:      	movl	0x8(%rdi), %edx
    133e:      	cmpl	$0x11, %edx
    1341:      	jb	0x1377 <filter_16ty_range+0x1a7>
    1343:      	cmpl	%esi, 0x18(%rdi)
    1346:      	ja	0x134d <filter_16ty_range+0x17d>
    1348:      	cmpl	%esi, 0x1c(%rdi)
    134b:      	jae	0x12d7 <filter_16ty_range+0x107>
    134d:      	cmpl	$0x19, %edx
    1350:      	jb	0x1377 <filter_16ty_range+0x1a7>
    1352:      	cmpl	%esi, 0x20(%rdi)
    1355:      	ja	0x1360 <filter_16ty_range+0x190>
    1357:      	cmpl	%esi, 0x24(%rdi)
    135a:      	jae	0x12d7 <filter_16ty_range+0x107>
    1360:      	cmpl	$0x21, %edx
    1363:      	jb	0x1377 <filter_16ty_range+0x1a7>
    1365:      	xorl	%edx, %edx
    1367:      	cmpl	%esi, 0x28(%rdi)
    136a:      	ja	0x1379 <filter_16ty_range+0x1a9>
    136c:      	cmpl	%esi, 0x2c(%rdi)
    136f:      	jae	0x12d7 <filter_16ty_range+0x107>
    1375:      	jmp	0x1379 <filter_16ty_range+0x1a9>
    1377:      	xorl	%edx, %edx
    1379:      	cmpl	$0x20, %ecx
    137c:      	sete	%al
    137f:      	xorb	$0x1, %dl
    1382:      	andb	%al, %dl
    1384:      	movzbl	%dl, %eax
    1387:      	retq
    1388:      	nopl	(%rax,%rax)

0000000000001390 <filter_8ty_selector_val>:
    1390:      	movl	0x4(%rdi), %ecx
    1393:      	movl	$0x1, %eax
    1398:      	cmpq	$0x25, %rcx
    139c:      	ja	0x140f <filter_8ty_selector_val+0x7f>
    139e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
    13a8:      	btq	%rcx, %rdx
    13ac:      	jae	0x13af <filter_8ty_selector_val+0x1f>
    13ae:      	retq
    13af:      	movl	$0x18, %edx
    13b4:      	btq	%rcx, %rdx
    13b8:      	jae	0x13cf <filter_8ty_selector_val+0x3f>
    13ba:      	movzbl	(%rsi), %edx
    13bd:      	cmpl	%edx, 0x10(%rdi)
    13c0:      	jne	0x14e5 <filter_8ty_selector_val+0x155>
    13c6:      	xorl	%eax, %eax
    13c8:      	cmpl	$0x3, %ecx
    13cb:      	sete	%al
    13ce:      	retq
    13cf:      	cmpq	$0xc, %rcx
    13d3:      	jne	0x140f <filter_8ty_selector_val+0x7f>
    13d5:      	movzbl	(%rsi), %ecx
    13d8:      	testl	%ecx, 0x10(%rdi)
    13db:      	jne	0x13ae <filter_8ty_selector_val+0x1e>
    13dd:      	movl	0x8(%rdi), %edx
    13e0:      	cmpl	$0xd, %edx
    13e3:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    13e9:      	testl	%ecx, 0x14(%rdi)
    13ec:      	jne	0x13ae <filter_8ty_selector_val+0x1e>
    13ee:      	cmpl	$0x11, %edx
    13f1:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    13f7:      	testl	%ecx, 0x18(%rdi)
    13fa:      	jne	0x13ae <filter_8ty_selector_val+0x1e>
    13fc:      	cmpl	$0x15, %edx
    13ff:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1405:      	testl	%ecx, 0x1c(%rdi)
    1408:      	jne	0x13ae <filter_8ty_selector_val+0x1e>
    140a:      	jmp	0x15a7 <filter_8ty_selector_val+0x217>
    140f:      	cmpl	$0x1, %ecx
    1412:      	je	0x1481 <filter_8ty_selector_val+0xf1>
    1414:      	cmpl	$0x2, %ecx
    1417:      	jne	0x15a7 <filter_8ty_selector_val+0x217>
    141d:      	movl	0xc(%rdi), %ecx
    1420:      	cmpl	$0xc, %ecx
    1423:      	ja	0x156e <filter_8ty_selector_val+0x1de>
    1429:      	movl	$0x1402, %edx           # imm = 0x1402
    142e:      	btl	%ecx, %edx
    1431:      	jae	0x156e <filter_8ty_selector_val+0x1de>
    1437:      	movsbl	(%rsi), %ecx
    143a:      	cmpl	%ecx, 0x10(%rdi)
    143d:      	jg	0x13ae <filter_8ty_selector_val+0x1e>
    1443:      	movl	0x8(%rdi), %edx
    1446:      	cmpl	$0xd, %edx
    1449:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    144f:      	cmpl	%ecx, 0x14(%rdi)
    1452:      	jg	0x13ae <filter_8ty_selector_val+0x1e>
    1458:      	cmpl	$0x11, %edx
    145b:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1461:      	cmpl	%ecx, 0x18(%rdi)
    1464:      	jg	0x13ae <filter_8ty_selector_val+0x1e>
    146a:      	cmpl	$0x15, %edx
    146d:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1473:      	cmpl	%ecx, 0x1c(%rdi)
    1476:      	jg	0x13ae <filter_8ty_selector_val+0x1e>
    147c:      	jmp	0x15a7 <filter_8ty_selector_val+0x217>
    1481:      	movl	0xc(%rdi), %ecx
    1484:      	cmpl	$0xc, %ecx
    1487:      	ja	0x1533 <filter_8ty_selector_val+0x1a3>
    148d:      	movl	$0x1402, %edx           # imm = 0x1402
    1492:      	btl	%ecx, %edx
    1495:      	jae	0x1533 <filter_8ty_selector_val+0x1a3>
    149b:      	movsbl	(%rsi), %ecx
    149e:      	cmpl	%ecx, 0x10(%rdi)
    14a1:      	jl	0x13ae <filter_8ty_selector_val+0x1e>
    14a7:      	movl	0x8(%rdi), %edx
    14aa:      	cmpl	$0xd, %edx
    14ad:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    14b3:      	cmpl	%ecx, 0x14(%rdi)
    14b6:      	jl	0x13ae <filter_8ty_selector_val+0x1e>
    14bc:      	cmpl	$0x11, %edx
    14bf:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    14c5:      	cmpl	%ecx, 0x18(%rdi)
    14c8:      	jl	0x13ae <filter_8ty_selector_val+0x1e>
    14ce:      	cmpl	$0x15, %edx
    14d1:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    14d7:      	cmpl	%ecx, 0x1c(%rdi)
    14da:      	jl	0x13ae <filter_8ty_selector_val+0x1e>
    14e0:      	jmp	0x15a7 <filter_8ty_selector_val+0x217>
    14e5:      	movl	0x8(%rdi), %esi
    14e8:      	cmpl	$0xd, %esi
    14eb:      	jb	0x1512 <filter_8ty_selector_val+0x182>
    14ed:      	cmpl	%edx, 0x14(%rdi)
    14f0:      	je	0x13c6 <filter_8ty_selector_val+0x36>
    14f6:      	cmpl	$0x11, %esi
    14f9:      	jb	0x1512 <filter_8ty_selector_val+0x182>
    14fb:      	cmpl	%edx, 0x18(%rdi)
    14fe:      	je	0x13c6 <filter_8ty_selector_val+0x36>
    1504:      	cmpl	$0x15, %esi
    1507:      	jb	0x1512 <filter_8ty_selector_val+0x182>
    1509:      	cmpl	%edx, 0x1c(%rdi)
    150c:      	je	0x13c6 <filter_8ty_selector_val+0x36>
    1512:      	cmpl	$0x25, %ecx
    1515:      	ja	0x15a7 <filter_8ty_selector_val+0x217>
    151b:      	movl	%ecx, %ecx
    151d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1527:      	btq	%rcx, %rdx
    152b:      	jb	0x13ae <filter_8ty_selector_val+0x1e>
    1531:      	jmp	0x15a7 <filter_8ty_selector_val+0x217>
    1533:      	movzbl	(%rsi), %ecx
    1536:      	cmpl	%ecx, 0x10(%rdi)
    1539:      	jb	0x13ae <filter_8ty_selector_val+0x1e>
    153f:      	movl	0x8(%rdi), %edx
    1542:      	cmpl	$0xd, %edx
    1545:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1547:      	cmpl	%ecx, 0x14(%rdi)
    154a:      	jb	0x13ae <filter_8ty_selector_val+0x1e>
    1550:      	cmpl	$0x11, %edx
    1553:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1555:      	cmpl	%ecx, 0x18(%rdi)
    1558:      	jb	0x13ae <filter_8ty_selector_val+0x1e>
    155e:      	cmpl	$0x15, %edx
    1561:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1563:      	cmpl	%ecx, 0x1c(%rdi)
    1566:      	jb	0x13ae <filter_8ty_selector_val+0x1e>
    156c:      	jmp	0x15a7 <filter_8ty_selector_val+0x217>
    156e:      	movzbl	(%rsi), %ecx
    1571:      	cmpl	%ecx, 0x10(%rdi)
    1574:      	ja	0x13ae <filter_8ty_selector_val+0x1e>
    157a:      	movl	0x8(%rdi), %edx
    157d:      	cmpl	$0xd, %edx
    1580:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1582:      	cmpl	%ecx, 0x14(%rdi)
    1585:      	ja	0x13ae <filter_8ty_selector_val+0x1e>
    158b:      	cmpl	$0x11, %edx
    158e:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    1590:      	cmpl	%ecx, 0x18(%rdi)
    1593:      	ja	0x13ae <filter_8ty_selector_val+0x1e>
    1599:      	cmpl	$0x15, %edx
    159c:      	jb	0x15a7 <filter_8ty_selector_val+0x217>
    159e:      	cmpl	%ecx, 0x1c(%rdi)
    15a1:      	ja	0x13ae <filter_8ty_selector_val+0x1e>
    15a7:      	xorl	%eax, %eax
    15a9:      	retq
    15aa:      	nopw	(%rax,%rax)

00000000000015b0 <filter_8ty_map>:
    15b0:      	pushq	%r14
    15b2:      	pushq	%rbx
    15b3:      	subq	$0x18, %rsp
    15b7:      	movq	%rsi, %r14
    15ba:      	movq	%rdi, %rbx
    15bd:      	movzbl	0x10(%rdi), %eax
    15c1:      	movl	%eax, 0xc(%rsp)
    15c5:      	movq	(%rip), %rdi            # 0x15cc <filter_8ty_map+0x1c>
    15cc:      	leaq	0xc(%rsp), %rsi
    15d1:      	movl	$0x1, %eax
    15d6:      	callq	*%rax
    15d8:      	testq	%rax, %rax
    15db:      	je	0x1611 <filter_8ty_map+0x61>
    15dd:      	movq	%rax, %rdi
    15e0:      	movzbl	(%r14), %eax
    15e4:      	movq	%rax, 0x10(%rsp)
    15e9:      	leaq	0x10(%rsp), %rsi
    15ee:      	movl	$0x1, %eax
    15f3:      	callq	*%rax
    15f5:      	movl	0x4(%rbx), %edx
    15f8:      	xorl	%ecx, %ecx
    15fa:      	cmpl	$0x1d, %edx
    15fd:      	ja	0x162b <filter_8ty_map+0x7b>
    15ff:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1604:      	btl	%edx, %esi
    1607:      	jae	0x161b <filter_8ty_map+0x6b>
    1609:      	testq	%rax, %rax
    160c:      	setne	%cl
    160f:      	jmp	0x162b <filter_8ty_map+0x7b>
    1611:      	xorl	%eax, %eax
    1613:      	addq	$0x18, %rsp
    1617:      	popq	%rbx
    1618:      	popq	%r14
    161a:      	retq
    161b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1620:      	btl	%edx, %esi
    1623:      	jae	0x162b <filter_8ty_map+0x7b>
    1625:      	testq	%rax, %rax
    1628:      	sete	%cl
    162b:      	movzbl	%cl, %eax
    162e:      	addq	$0x18, %rsp
    1632:      	popq	%rbx
    1633:      	popq	%r14
    1635:      	retq
    1636:      	nopw	%cs:(%rax,%rax)

0000000000001640 <filter_8ty_range>:
    1640:      	movl	0x4(%rdi), %ecx
    1643:      	movl	0xc(%rdi), %eax
    1646:      	cmpl	$0xc, %eax
    1649:      	ja	0x1730 <filter_8ty_range+0xf0>
    164f:      	movl	$0x1402, %edx           # imm = 0x1402
    1654:      	btl	%eax, %edx
    1657:      	jae	0x1730 <filter_8ty_range+0xf0>
    165d:      	movsbl	(%rsi), %esi
    1660:      	cmpl	$0x1f, %ecx
    1663:      	jne	0x16cb <filter_8ty_range+0x8b>
    1665:      	movl	$0x1, %eax
    166a:      	cmpl	%esi, 0x10(%rdi)
    166d:      	jg	0x1678 <filter_8ty_range+0x38>
    166f:      	cmpl	%esi, 0x14(%rdi)
    1672:      	jge	0x1747 <filter_8ty_range+0x107>
    1678:      	movl	0x8(%rdi), %edx
    167b:      	cmpl	$0x11, %edx
    167e:      	jb	0x17e7 <filter_8ty_range+0x1a7>
    1684:      	cmpl	%esi, 0x18(%rdi)
    1687:      	jg	0x1692 <filter_8ty_range+0x52>
    1689:      	cmpl	%esi, 0x1c(%rdi)
    168c:      	jge	0x1747 <filter_8ty_range+0x107>
    1692:      	cmpl	$0x19, %edx
    1695:      	jb	0x17e7 <filter_8ty_range+0x1a7>
    169b:      	cmpl	%esi, 0x20(%rdi)
    169e:      	jg	0x16a9 <filter_8ty_range+0x69>
    16a0:      	cmpl	%esi, 0x24(%rdi)
    16a3:      	jge	0x1747 <filter_8ty_range+0x107>
    16a9:      	cmpl	$0x21, %edx
    16ac:      	jb	0x17e7 <filter_8ty_range+0x1a7>
    16b2:      	xorl	%edx, %edx
    16b4:      	cmpl	%esi, 0x28(%rdi)
    16b7:      	jg	0x17e9 <filter_8ty_range+0x1a9>
    16bd:      	cmpl	%esi, 0x2c(%rdi)
    16c0:      	jge	0x1747 <filter_8ty_range+0x107>
    16c6:      	jmp	0x17e9 <filter_8ty_range+0x1a9>
    16cb:      	movl	0x8(%rdi), %eax
    16ce:      	cmpl	%esi, 0x10(%rdi)
    16d1:      	setle	%r8b
    16d5:      	cmpl	%esi, 0x14(%rdi)
    16d8:      	setge	%dl
    16db:      	andb	%r8b, %dl
    16de:      	cmpl	$0x11, %eax
    16e1:      	jb	0x17e9 <filter_8ty_range+0x1a9>
    16e7:      	cmpl	%esi, 0x18(%rdi)
    16ea:      	setle	%r8b
    16ee:      	cmpl	%esi, 0x1c(%rdi)
    16f1:      	setge	%r9b
    16f5:      	andb	%r8b, %r9b
    16f8:      	orb	%r9b, %dl
    16fb:      	cmpl	$0x19, %eax
    16fe:      	jb	0x17e9 <filter_8ty_range+0x1a9>
    1704:      	cmpl	%esi, 0x20(%rdi)
    1707:      	setle	%r8b
    170b:      	cmpl	%esi, 0x24(%rdi)
    170e:      	setge	%r9b
    1712:      	andb	%r8b, %r9b
    1715:      	orb	%r9b, %dl
    1718:      	cmpl	$0x21, %eax
    171b:      	jb	0x17e9 <filter_8ty_range+0x1a9>
    1721:      	cmpl	%esi, 0x28(%rdi)
    1724:      	setle	%al
    1727:      	cmpl	%esi, 0x2c(%rdi)
    172a:      	setge	%sil
    172e:      	jmp	0x17a3 <filter_8ty_range+0x163>
    1730:      	movzbl	(%rsi), %esi
    1733:      	cmpl	$0x1f, %ecx
    1736:      	jne	0x1748 <filter_8ty_range+0x108>
    1738:      	movl	$0x1, %eax
    173d:      	cmpl	%esi, 0x10(%rdi)
    1740:      	ja	0x17ab <filter_8ty_range+0x16b>
    1742:      	cmpl	%esi, 0x14(%rdi)
    1745:      	jb	0x17ab <filter_8ty_range+0x16b>
    1747:      	retq
    1748:      	movl	0x8(%rdi), %eax
    174b:      	cmpl	%esi, 0x10(%rdi)
    174e:      	setbe	%r8b
    1752:      	cmpl	%esi, 0x14(%rdi)
    1755:      	setae	%dl
    1758:      	andb	%r8b, %dl
    175b:      	cmpl	$0x11, %eax
    175e:      	jb	0x17e9 <filter_8ty_range+0x1a9>
    1764:      	cmpl	%esi, 0x18(%rdi)
    1767:      	setbe	%r8b
    176b:      	cmpl	%esi, 0x1c(%rdi)
    176e:      	setae	%r9b
    1772:      	andb	%r8b, %r9b
    1775:      	orb	%r9b, %dl
    1778:      	cmpl	$0x19, %eax
    177b:      	jb	0x17e9 <filter_8ty_range+0x1a9>
    177d:      	cmpl	%esi, 0x20(%rdi)
    1780:      	setbe	%r8b
    1784:      	cmpl	%esi, 0x24(%rdi)
    1787:      	setae	%r9b
    178b:      	andb	%r8b, %r9b
    178e:      	orb	%r9b, %dl
    1791:      	cmpl	$0x21, %eax
    1794:      	jb	0x17e9 <filter_8ty_range+0x1a9>
    1796:      	cmpl	%esi, 0x28(%rdi)
    1799:      	setbe	%al
    179c:      	cmpl	%esi, 0x2c(%rdi)
    179f:      	setae	%sil
    17a3:      	andb	%al, %sil
    17a6:      	orb	%sil, %dl
    17a9:      	jmp	0x17e9 <filter_8ty_range+0x1a9>
    17ab:      	movl	0x8(%rdi), %edx
    17ae:      	cmpl	$0x11, %edx
    17b1:      	jb	0x17e7 <filter_8ty_range+0x1a7>
    17b3:      	cmpl	%esi, 0x18(%rdi)
    17b6:      	ja	0x17bd <filter_8ty_range+0x17d>
    17b8:      	cmpl	%esi, 0x1c(%rdi)
    17bb:      	jae	0x1747 <filter_8ty_range+0x107>
    17bd:      	cmpl	$0x19, %edx
    17c0:      	jb	0x17e7 <filter_8ty_range+0x1a7>
    17c2:      	cmpl	%esi, 0x20(%rdi)
    17c5:      	ja	0x17d0 <filter_8ty_range+0x190>
    17c7:      	cmpl	%esi, 0x24(%rdi)
    17ca:      	jae	0x1747 <filter_8ty_range+0x107>
    17d0:      	cmpl	$0x21, %edx
    17d3:      	jb	0x17e7 <filter_8ty_range+0x1a7>
    17d5:      	xorl	%edx, %edx
    17d7:      	cmpl	%esi, 0x28(%rdi)
    17da:      	ja	0x17e9 <filter_8ty_range+0x1a9>
    17dc:      	cmpl	%esi, 0x2c(%rdi)
    17df:      	jae	0x1747 <filter_8ty_range+0x107>
    17e5:      	jmp	0x17e9 <filter_8ty_range+0x1a9>
    17e7:      	xorl	%edx, %edx
    17e9:      	cmpl	$0x20, %ecx
    17ec:      	sete	%al
    17ef:      	xorb	$0x1, %dl
    17f2:      	andb	%al, %dl
    17f4:      	movzbl	%dl, %eax
    17f7:      	retq
    17f8:      	nopl	(%rax,%rax)

0000000000001800 <filter_file_buf>:
    1800:      	pushq	%rbx
    1801:      	movq	%rdi, %rbx
    1804:      	movl	(%rsi), %edx
    1806:      	movl	0x4(%rdi), %ecx
    1809:      	testl	%edx, %edx
    180b:      	jne	0x181b <filter_file_buf+0x1b>
    180d:      	movl	%ecx, %eax
    180f:      	andl	$-0x2, %eax
    1812:      	cmpl	$0x24, %eax
    1815:      	je	0x181b <filter_file_buf+0x1b>
    1817:      	xorl	%eax, %eax
    1819:      	popq	%rbx
    181a:      	retq
    181b:      	cmpl	$0x25, %ecx
    181e:      	ja	0x185a <filter_file_buf+0x5a>
    1820:      	movl	%ecx, %eax
    1822:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1827:      	btq	%rax, %rdi
    182b:      	jb	0x188e <filter_file_buf+0x8e>
    182d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1832:      	btq	%rax, %rdi
    1836:      	jb	0x1878 <filter_file_buf+0x78>
    1838:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1842:      	btq	%rax, %rdi
    1846:      	jae	0x185a <filter_file_buf+0x5a>
    1848:      	movq	%rbx, %rdi
    184b:      	callq	0x22f0 <filter_file_type>
    1850:      	movl	0x4(%rbx), %ecx
    1853:      	cmpl	$0x25, %ecx
    1856:      	jbe	0x18ab <filter_file_buf+0xab>
    1858:      	jmp	0x18c1 <filter_file_buf+0xc1>
    185a:      	leal	-0x3(%rcx), %eax
    185d:      	cmpl	$0x2, %eax
    1860:      	jae	0x18a4 <filter_file_buf+0xa4>
    1862:      	addq	$0x4, %rsi
    1866:      	movq	%rbx, %rdi
    1869:      	callq	0x1d80 <filter_char_buf_equal>
    186e:      	movl	0x4(%rbx), %ecx
    1871:      	cmpl	$0x25, %ecx
    1874:      	jbe	0x18ab <filter_file_buf+0xab>
    1876:      	jmp	0x18c1 <filter_file_buf+0xc1>
    1878:      	addq	$0x4, %rsi
    187c:      	movl	0x10(%rbx), %edi
    187f:      	callq	0x21a0 <filter_char_buf_postfix>
    1884:      	movl	0x4(%rbx), %ecx
    1887:      	cmpl	$0x25, %ecx
    188a:      	jbe	0x18ab <filter_file_buf+0xab>
    188c:      	jmp	0x18c1 <filter_file_buf+0xc1>
    188e:      	addq	$0x4, %rsi
    1892:      	movl	0x10(%rbx), %edi
    1895:      	callq	0x2100 <filter_char_buf_prefix>
    189a:      	movl	0x4(%rbx), %ecx
    189d:      	cmpl	$0x25, %ecx
    18a0:      	jbe	0x18ab <filter_file_buf+0xab>
    18a2:      	jmp	0x18c1 <filter_file_buf+0xc1>
    18a4:      	xorl	%eax, %eax
    18a6:      	cmpl	$0x25, %ecx
    18a9:      	ja	0x18c1 <filter_file_buf+0xc1>
    18ab:      	movl	%ecx, %ecx
    18ad:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    18b7:      	btq	%rcx, %rdx
    18bb:      	jae	0x18c1 <filter_file_buf+0xc1>
    18bd:      	xorq	$0x1, %rax
    18c1:      	popq	%rbx
    18c2:      	retq
    18c3:      	nopw	%cs:(%rax,%rax)

00000000000018d0 <filter_char_buf>:
    18d0:      	pushq	%rbx
    18d1:      	movq	%rsi, %rax
    18d4:      	movq	%rdi, %rbx
    18d7:      	movslq	%edx, %rcx
    18da:      	movl	-0x4(%rsi,%rcx), %edx
    18de:      	movl	%ecx, %esi
    18e0:      	addq	%rax, %rsi
    18e3:      	movl	0x4(%rdi), %ecx
    18e6:      	xorl	%eax, %eax
    18e8:      	cmpl	$0x19, %ecx
    18eb:      	jg	0x1901 <filter_char_buf+0x31>
    18ed:      	leal	-0x3(%rcx), %edi
    18f0:      	cmpl	$0x2, %edi
    18f3:      	jb	0x1938 <filter_char_buf+0x68>
    18f5:      	cmpl	$0x8, %ecx
    18f8:      	je	0x192e <filter_char_buf+0x5e>
    18fa:      	cmpl	$0x9, %ecx
    18fd:      	je	0x1910 <filter_char_buf+0x40>
    18ff:      	jmp	0x194f <filter_char_buf+0x7f>
    1901:      	cmpl	$0x20, %ecx
    1904:      	jg	0x191a <filter_char_buf+0x4a>
    1906:      	cmpl	$0x1a, %ecx
    1909:      	je	0x192e <filter_char_buf+0x5e>
    190b:      	cmpl	$0x1b, %ecx
    190e:      	jne	0x194f <filter_char_buf+0x7f>
    1910:      	movl	0x10(%rbx), %edi
    1913:      	callq	0x21a0 <filter_char_buf_postfix>
    1918:      	jmp	0x194c <filter_char_buf+0x7c>
    191a:      	cmpl	$0x21, %ecx
    191d:      	je	0x1942 <filter_char_buf+0x72>
    191f:      	cmpl	$0x22, %ecx
    1922:      	jne	0x194f <filter_char_buf+0x7f>
    1924:      	movq	%rbx, %rdi
    1927:      	movl	$0x1, %ecx
    192c:      	jmp	0x1947 <filter_char_buf+0x77>
    192e:      	movl	0x10(%rbx), %edi
    1931:      	callq	0x2100 <filter_char_buf_prefix>
    1936:      	jmp	0x194c <filter_char_buf+0x7c>
    1938:      	movq	%rbx, %rdi
    193b:      	callq	0x1d80 <filter_char_buf_equal>
    1940:      	jmp	0x194c <filter_char_buf+0x7c>
    1942:      	movq	%rbx, %rdi
    1945:      	xorl	%ecx, %ecx
    1947:      	callq	0x23a0 <filter_char_substring>
    194c:      	movl	0x4(%rbx), %ecx
    194f:      	cmpl	$0x25, %ecx
    1952:      	ja	0x1971 <filter_char_buf+0xa1>
    1954:      	movl	%ecx, %ecx
    1956:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1960:      	btq	%rcx, %rdx
    1964:      	jae	0x1971 <filter_char_buf+0xa1>
    1966:      	xorl	%ecx, %ecx
    1968:      	testq	%rax, %rax
    196b:      	sete	%cl
    196e:      	movq	%rcx, %rax
    1971:      	popq	%rbx
    1972:      	retq
    1973:      	nopw	%cs:(%rax,%rax)

0000000000001980 <filter_inet>:
    1980:      	pushq	%r15
    1982:      	pushq	%r14
    1984:      	pushq	%r12
    1986:      	pushq	%rbx
    1987:      	subq	$0x48, %rsp
    198b:      	movq	$0x0, 0x40(%rsp)
    1994:      	movq	$0x0, 0x38(%rsp)
    199d:      	movq	$0x0, 0x30(%rsp)
    19a6:      	movq	$0x0, 0x28(%rsp)
    19af:      	movq	$0x0, 0x20(%rsp)
    19b8:      	movl	$0x0, (%rsp)
    19bf:      	movl	$0x0, 0x4(%rsp)
    19c7:      	movl	0xc(%rdi), %edx
    19ca:      	xorl	%eax, %eax
    19cc:      	cmpl	$0x27, %edx
    19cf:      	jg	0x19e7 <filter_inet+0x67>
    19d1:      	cmpl	$0x5, %edx
    19d4:      	je	0x1a6c <filter_inet+0xec>
    19da:      	movq	%rsi, %r8
    19dd:      	cmpl	$0x7, %edx
    19e0:      	je	0x19f8 <filter_inet+0x78>
    19e2:      	jmp	0x1c7d <filter_inet+0x2fd>
    19e7:      	cmpl	$0x28, %edx
    19ea:      	je	0x1a44 <filter_inet+0xc4>
    19ec:      	movq	%rsi, %r8
    19ef:      	cmpl	$0x29, %edx
    19f2:      	jne	0x1c7d <filter_inet+0x2fd>
    19f8:      	movl	0x4(%rdi), %ecx
    19fb:      	xorl	%eax, %eax
    19fd:      	cmpl	$0x13, %ecx
    1a00:      	jle	0x1a79 <filter_inet+0xf9>
    1a02:      	cmpl	$0x17, %ecx
    1a05:      	jg	0x1a24 <filter_inet+0xa4>
    1a07:      	leal	-0x14(%rcx), %edx
    1a0a:      	cmpl	$0x2, %edx
    1a0d:      	jb	0x1aca <filter_inet+0x14a>
    1a13:      	leal	-0x16(%rcx), %edx
    1a16:      	cmpl	$0x2, %edx
    1a19:      	jb	0x1ac4 <filter_inet+0x144>
    1a1f:      	jmp	0x1c7d <filter_inet+0x2fd>
    1a24:      	cmpl	$0x1b, %ecx
    1a27:      	jg	0x1b07 <filter_inet+0x187>
    1a2d:      	cmpl	$0x18, %ecx
    1a30:      	je	0x1b3a <filter_inet+0x1ba>
    1a36:      	cmpl	$0x19, %ecx
    1a39:      	je	0x1b30 <filter_inet+0x1b0>
    1a3f:      	jmp	0x1c7d <filter_inet+0x2fd>
    1a44:      	movzwl	(%rsi), %eax
    1a47:      	movw	%ax, 0x46(%rsp)
    1a4c:      	movzwl	0x2(%rsi), %eax
    1a50:      	movw	%ax, 0x40(%rsp)
    1a55:      	movq	0x8(%rsi), %rax
    1a59:      	movq	%rax, 0x20(%rsp)
    1a5e:      	movq	0x10(%rsi), %rax
    1a62:      	movq	%rax, 0x28(%rsp)
    1a67:      	leaq	0x20(%rsp), %rsi
    1a6c:      	xorl	%r8d, %r8d
    1a6f:      	movl	0x4(%rdi), %ecx
    1a72:      	xorl	%eax, %eax
    1a74:      	cmpl	$0x13, %ecx
    1a77:      	jg	0x1a02 <filter_inet+0x82>
    1a79:      	cmpl	$0xf, %ecx
    1a7c:      	jle	0x1a9a <filter_inet+0x11a>
    1a7e:      	cmpl	$0x11, %ecx
    1a81:      	jg	0x1ab6 <filter_inet+0x136>
    1a83:      	cmpl	$0x10, %ecx
    1a86:      	je	0x1ac4 <filter_inet+0x144>
    1a88:      	cmpl	$0x11, %ecx
    1a8b:      	jne	0x1c7d <filter_inet+0x2fd>
    1a91:      	movzwl	0x24(%rsi), %eax
    1a95:      	jmp	0x1c72 <filter_inet+0x2f2>
    1a9a:      	cmpl	$0xd, %ecx
    1a9d:      	je	0x1b3a <filter_inet+0x1ba>
    1aa3:      	cmpl	$0xe, %ecx
    1aa6:      	je	0x1b30 <filter_inet+0x1b0>
    1aac:      	cmpl	$0xf, %ecx
    1aaf:      	je	0x1aca <filter_inet+0x14a>
    1ab1:      	jmp	0x1c7d <filter_inet+0x2fd>
    1ab6:      	cmpl	$0x12, %ecx
    1ab9:      	je	0x1aca <filter_inet+0x14a>
    1abb:      	cmpl	$0x13, %ecx
    1abe:      	jne	0x1c7d <filter_inet+0x2fd>
    1ac4:      	movzwl	0x22(%rsi), %edx
    1ac8:      	jmp	0x1ace <filter_inet+0x14e>
    1aca:      	movzwl	0x20(%rsi), %edx
    1ace:      	movl	%edx, 0x4(%rsp)
    1ad2:      	xorl	%ebx, %ebx
    1ad4:      	xorl	%r15d, %r15d
    1ad7:      	xorl	%r14d, %r14d
    1ada:      	xorl	%eax, %eax
    1adc:      	cmpl	$0x11, %ecx
    1adf:      	jg	0x1b51 <filter_inet+0x1d1>
    1ae1:      	leal	-0xd(%rcx), %edx
    1ae4:      	cmpl	$0x2, %edx
    1ae7:      	jb	0x1b78 <filter_inet+0x1f8>
    1aed:      	leal	-0xf(%rcx), %edx
    1af0:      	cmpl	$0x2, %edx
    1af3:      	jb	0x1bcd <filter_inet+0x24d>
    1af9:      	cmpl	$0x11, %ecx
    1afc:      	je	0x1c75 <filter_inet+0x2f5>
    1b02:      	jmp	0x1c7d <filter_inet+0x2fd>
    1b07:      	cmpl	$0x1c, %ecx
    1b0a:      	je	0x1c6e <filter_inet+0x2ee>
    1b10:      	cmpl	$0x1d, %ecx
    1b13:      	jne	0x1c7d <filter_inet+0x2fd>
    1b19:      	cmpl	$0x7, %edx
    1b1c:      	jne	0x1ca1 <filter_inet+0x321>
    1b22:      	testq	%r8, %r8
    1b25:      	jne	0x1cab <filter_inet+0x32b>
    1b2b:      	jmp	0x1c75 <filter_inet+0x2f5>
    1b30:      	movq	0x10(%rsi), %rbx
    1b34:      	movq	0x18(%rsi), %r14
    1b38:      	jmp	0x1b41 <filter_inet+0x1c1>
    1b3a:      	movq	(%rsi), %rbx
    1b3d:      	movq	0x8(%rsi), %r14
    1b41:      	movq	%rbx, %r15
    1b44:      	shrq	$0x20, %r15
    1b48:      	xorl	%edx, %edx
    1b4a:      	xorl	%eax, %eax
    1b4c:      	cmpl	$0x11, %ecx
    1b4f:      	jle	0x1ae1 <filter_inet+0x161>
    1b51:      	cmpl	$0x19, %ecx
    1b54:      	ja	0x1bc1 <filter_inet+0x241>
    1b56:      	movl	$0x500000, %r8d         # imm = 0x500000
    1b5c:      	btl	%ecx, %r8d
    1b60:      	jb	0x1bd7 <filter_inet+0x257>
    1b62:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1b68:      	btl	%ecx, %r8d
    1b6c:      	jb	0x1be7 <filter_inet+0x267>
    1b6e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    1b73:      	btl	%ecx, %edx
    1b76:      	jae	0x1bc1 <filter_inet+0x241>
    1b78:      	movzwl	0x26(%rsi), %eax
    1b7c:      	cmpl	$0xa, %eax
    1b7f:      	je	0x1bf7 <filter_inet+0x277>
    1b81:      	cmpl	$0x2, %eax
    1b84:      	jne	0x1c67 <filter_inet+0x2e7>
    1b8a:      	movq	%rdi, %r12
    1b8d:      	movl	0x10(%rdi), %eax
    1b90:      	movl	%eax, 0x8(%rsp)
    1b94:      	movq	(%rip), %rdi            # 0x1b9b <filter_inet+0x21b>
    1b9b:      	leaq	0x8(%rsp), %rsi
    1ba0:      	movl	$0x1, %eax
    1ba5:      	callq	*%rax
    1ba7:      	testq	%rax, %rax
    1baa:      	je	0x1c89 <filter_inet+0x309>
    1bb0:      	movq	%rax, %rdi
    1bb3:      	movl	$0x20, 0xc(%rsp)
    1bbb:      	movl	%ebx, 0x10(%rsp)
    1bbf:      	jmp	0x1c3b <filter_inet+0x2bb>
    1bc1:      	addl	$-0x12, %ecx
    1bc4:      	cmpl	$0x2, %ecx
    1bc7:      	jae	0x1c7d <filter_inet+0x2fd>
    1bcd:      	leaq	0x4(%rsp), %rsi
    1bd2:      	jmp	0x1c78 <filter_inet+0x2f8>
    1bd7:      	xorl	%eax, %eax
    1bd9:      	cmpl	$0x400, %edx            # imm = 0x400
    1bdf:      	setb	%al
    1be2:      	jmp	0x1c7d <filter_inet+0x2fd>
    1be7:      	xorl	%eax, %eax
    1be9:      	cmpl	$0x400, %edx            # imm = 0x400
    1bef:      	setae	%al
    1bf2:      	jmp	0x1c7d <filter_inet+0x2fd>
    1bf7:      	movq	%rdi, %r12
    1bfa:      	movl	0x14(%rdi), %eax
    1bfd:      	movl	%eax, 0x8(%rsp)
    1c01:      	movq	(%rip), %rdi            # 0x1c08 <filter_inet+0x288>
    1c08:      	leaq	0x8(%rsp), %rsi
    1c0d:      	movl	$0x1, %eax
    1c12:      	callq	*%rax
    1c14:      	testq	%rax, %rax
    1c17:      	je	0x1c89 <filter_inet+0x309>
    1c19:      	movq	%rax, %rdi
    1c1c:      	movl	$0x80, 0xc(%rsp)
    1c24:      	movl	%ebx, 0x10(%rsp)
    1c28:      	movl	%r15d, 0x14(%rsp)
    1c2d:      	movl	%r14d, 0x18(%rsp)
    1c32:      	shrq	$0x20, %r14
    1c36:      	movl	%r14d, 0x1c(%rsp)
    1c3b:      	leaq	0xc(%rsp), %rsi
    1c40:      	movl	$0x1, %eax
    1c45:      	callq	*%rax
    1c47:      	movl	0x4(%r12), %ecx
    1c4c:      	leal	-0x18(%rcx), %edx
    1c4f:      	cmpl	$0x2, %edx
    1c52:      	jb	0x1c96 <filter_inet+0x316>
    1c54:      	addl	$-0xd, %ecx
    1c57:      	cmpl	$0x1, %ecx
    1c5a:      	ja	0x1c67 <filter_inet+0x2e7>
    1c5c:      	testq	%rax, %rax
    1c5f:      	setne	%al
    1c62:      	movzbl	%al, %eax
    1c65:      	jmp	0x1c7d <filter_inet+0x2fd>
    1c67:      	xorl	%eax, %eax
    1c69:      	movzbl	%al, %eax
    1c6c:      	jmp	0x1c7d <filter_inet+0x2fd>
    1c6e:      	movzwl	0x26(%rsi), %eax
    1c72:      	movl	%eax, (%rsp)
    1c75:      	movq	%rsp, %rsi
    1c78:      	callq	0xcd0 <filter_32ty_map>
    1c7d:      	addq	$0x48, %rsp
    1c81:      	popq	%rbx
    1c82:      	popq	%r12
    1c84:      	popq	%r14
    1c86:      	popq	%r15
    1c88:      	retq
    1c89:      	movl	0x4(%r12), %eax
    1c8e:      	andl	$-0x2, %eax
    1c91:      	cmpl	$0x18, %eax
    1c94:      	jmp	0x1c99 <filter_inet+0x319>
    1c96:      	testq	%rax, %rax
    1c99:      	sete	%al
    1c9c:      	movzbl	%al, %eax
    1c9f:      	jmp	0x1c7d <filter_inet+0x2fd>
    1ca1:      	cmpl	$0x29, %edx
    1ca4:      	jne	0x1cb3 <filter_inet+0x333>
    1ca6:      	testq	%r8, %r8
    1ca9:      	je	0x1cb3 <filter_inet+0x333>
    1cab:      	movzbl	0x3a(%r8), %eax
    1cb0:      	movl	%eax, (%rsp)
    1cb3:      	cmpl	$0x29, %edx
    1cb6:      	je	0x1c75 <filter_inet+0x2f5>
    1cb8:      	cmpl	$0x7, %edx
    1cbb:      	je	0x1c75 <filter_inet+0x2f5>
    1cbd:      	xorl	%eax, %eax
    1cbf:      	jmp	0x1c7d <filter_inet+0x2fd>
    1cc1:      	nopw	%cs:(%rax,%rax)

0000000000001cd0 <filter_sockaddr_un>:
    1cd0:      	pushq	%rbx
    1cd1:      	subq	$0x10, %rsp
    1cd5:      	movq	%rsi, %rcx
    1cd8:      	addq	$0x4, %rsi
    1cdc:      	movzbl	0x3(%rcx), %edx
    1ce0:      	movl	0x4(%rdi), %r8d
    1ce4:      	xorl	%eax, %eax
    1ce6:      	cmpl	$0x19, %r8d
    1cea:      	jg	0x1d20 <filter_sockaddr_un+0x50>
    1cec:      	leal	-0x3(%r8), %ecx
    1cf0:      	cmpl	$0x2, %ecx
    1cf3:      	jae	0x1d2e <filter_sockaddr_un+0x5e>
    1cf5:      	movq	%rdi, %rbx
    1cf8:      	callq	0x1d80 <filter_char_buf_equal>
    1cfd:      	movl	0x4(%rbx), %ecx
    1d00:      	cmpq	$0x25, %rcx
    1d04:      	ja	0x1d1a <filter_sockaddr_un+0x4a>
    1d06:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1d10:      	btq	%rcx, %rdx
    1d14:      	jae	0x1d1a <filter_sockaddr_un+0x4a>
    1d16:      	xorq	$0x1, %rax
    1d1a:      	addq	$0x10, %rsp
    1d1e:      	popq	%rbx
    1d1f:      	retq
    1d20:      	cmpl	$0x1c, %r8d
    1d24:      	je	0x1d64 <filter_sockaddr_un+0x94>
    1d26:      	cmpl	$0x1a, %r8d
    1d2a:      	je	0x1d34 <filter_sockaddr_un+0x64>
    1d2c:      	jmp	0x1d1a <filter_sockaddr_un+0x4a>
    1d2e:      	cmpl	$0x8, %r8d
    1d32:      	jne	0x1d1a <filter_sockaddr_un+0x4a>
    1d34:      	movl	0x10(%rdi), %eax
    1d37:      	movq	%rdi, %rbx
    1d3a:      	movl	%eax, %edi
    1d3c:      	callq	0x2100 <filter_char_buf_prefix>
    1d41:      	movl	0x4(%rbx), %ecx
    1d44:      	cmpq	$0x25, %rcx
    1d48:      	ja	0x1d1a <filter_sockaddr_un+0x4a>
    1d4a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1d54:      	btq	%rcx, %rdx
    1d58:      	jae	0x1d1a <filter_sockaddr_un+0x4a>
    1d5a:      	xorq	$0x1, %rax
    1d5e:      	addq	$0x10, %rsp
    1d62:      	popq	%rbx
    1d63:      	retq
    1d64:      	movzwl	(%rcx), %eax
    1d67:      	movl	%eax, 0xc(%rsp)
    1d6b:      	leaq	0xc(%rsp), %rsi
    1d70:      	callq	0xcd0 <filter_32ty_map>
    1d75:      	addq	$0x10, %rsp
    1d79:      	popq	%rbx
    1d7a:      	retq
    1d7b:      	nopl	(%rax,%rax)

0000000000001d80 <filter_char_buf_equal>:
    1d80:      	pushq	%rbp
    1d81:      	pushq	%r15
    1d83:      	pushq	%r14
    1d85:      	pushq	%r13
    1d87:      	pushq	%r12
    1d89:      	pushq	%rbx
    1d8a:      	subq	$0x28, %rsp
    1d8e:      	movl	$0x0, 0x14(%rsp)
    1d96:      	cmpl	$0x1000, %edx           # imm = 0x1000
    1d9c:      	ja	0x20ee <filter_char_buf_equal+0x36e>
    1da2:      	movl	%edx, %ebp
    1da4:      	movzwl	%bp, %eax
    1da7:      	cmpl	$0x90, %eax
    1dac:      	ja	0x1df5 <filter_char_buf_equal+0x75>
    1dae:      	testw	%bp, %bp
    1db1:      	je	0x1dc4 <filter_char_buf_equal+0x44>
    1db3:      	movl	$0x18, %ecx
    1db8:      	movl	%ebp, %eax
    1dba:      	cltd
    1dbb:      	idivl	%ecx
    1dbd:      	movl	%ebp, %r14d
    1dc0:      	testl	%edx, %edx
    1dc2:      	je	0x1de4 <filter_char_buf_equal+0x64>
    1dc4:      	movl	$0x18, %ecx
    1dc9:      	movl	%ebp, %eax
    1dcb:      	cltd
    1dcc:      	idivl	%ecx
    1dce:      	shll	$0x3, %eax
    1dd1:      	leal	(%rax,%rax,2), %eax
    1dd4:      	addl	$0x18, %eax
    1dd7:      	movzwl	%ax, %r14d
    1ddb:      	cmpl	$0x90, %r14d
    1de2:      	ja	0x1e33 <filter_char_buf_equal+0xb3>
    1de4:      	movl	%r14d, %eax
    1de7:      	cltd
    1de8:      	idivl	%ecx
    1dea:      	movl	%eax, %r15d
    1ded:      	decl	%r15d
    1df0:      	jmp	0x1e7e <filter_char_buf_equal+0xfe>
    1df5:      	movl	$0x100, %r14d           # imm = 0x100
    1dfb:      	cmpl	$0x101, %eax            # imm = 0x101
    1e00:      	jb	0x1e33 <filter_char_buf_equal+0xb3>
    1e02:      	movl	$0x200, %r14d           # imm = 0x200
    1e08:      	cmpl	$0x201, %eax            # imm = 0x201
    1e0d:      	jb	0x1e33 <filter_char_buf_equal+0xb3>
    1e0f:      	movl	$0x400, %r14d           # imm = 0x400
    1e15:      	cmpl	$0x401, %eax            # imm = 0x401
    1e1a:      	jb	0x1e33 <filter_char_buf_equal+0xb3>
    1e1c:      	xorl	%r14d, %r14d
    1e1f:      	cmpl	$0x801, %eax            # imm = 0x801
    1e24:      	setae	%r14b
    1e28:      	shll	$0xb, %r14d
    1e2c:      	addl	$0x800, %r14d           # imm = 0x800
    1e33:      	leal	-0x100(%r14), %eax
    1e3a:      	rorxl	$0x8, %eax, %eax
    1e40:      	cmpl	$0x2, %eax
    1e43:      	jg	0x1e56 <filter_char_buf_equal+0xd6>
    1e45:      	testl	%eax, %eax
    1e47:      	je	0x1e70 <filter_char_buf_equal+0xf0>
    1e49:      	cmpl	$0x1, %eax
    1e4c:      	jne	0x1e68 <filter_char_buf_equal+0xe8>
    1e4e:      	movl	$0x7, %r15d
    1e54:      	jmp	0x1e7e <filter_char_buf_equal+0xfe>
    1e56:      	cmpl	$0x3, %eax
    1e59:      	je	0x1e78 <filter_char_buf_equal+0xf8>
    1e5b:      	cmpl	$0x7, %eax
    1e5e:      	jne	0x1e68 <filter_char_buf_equal+0xe8>
    1e60:      	movl	$0x9, %r15d
    1e66:      	jmp	0x1e7e <filter_char_buf_equal+0xfe>
    1e68:      	movl	$0xa, %r15d
    1e6e:      	jmp	0x1e7e <filter_char_buf_equal+0xfe>
    1e70:      	movl	$0x6, %r15d
    1e76:      	jmp	0x1e7e <filter_char_buf_equal+0xfe>
    1e78:      	movl	$0x8, %r15d
    1e7e:      	movl	%r15d, %eax
    1e81:      	andl	$0xf, %eax
    1e84:      	movl	0x10(%rdi,%rax,4), %r13d
    1e89:      	cmpl	$-0x1, %r13d
    1e8d:      	je	0x20ee <filter_char_buf_equal+0x36e>
    1e93:      	movq	%rsi, 0x20(%rsp)
    1e98:      	movq	(%rip), %rdi            # 0x1e9f <filter_char_buf_equal+0x11f>
    1e9f:      	leaq	0x14(%rsp), %r12
    1ea4:      	movl	$0x1, %eax
    1ea9:      	movq	%r12, %rsi
    1eac:      	callq	*%rax
    1eae:      	movq	%rax, %rbx
    1eb1:      	movq	(%rip), %rdi            # 0x1eb8 <filter_char_buf_equal+0x138>
    1eb8:      	movl	$0x1, %eax
    1ebd:      	movq	%r12, %rsi
    1ec0:      	callq	*%rax
    1ec2:      	movq	%rax, %rcx
    1ec5:      	xorl	%eax, %eax
    1ec7:      	movq	%rbx, 0x8(%rsp)
    1ecc:      	testq	%rbx, %rbx
    1ecf:      	je	0x20f0 <filter_char_buf_equal+0x370>
    1ed5:      	testq	%rcx, %rcx
    1ed8:      	je	0x20f0 <filter_char_buf_equal+0x370>
    1ede:      	movq	%rcx, 0x18(%rsp)
    1ee3:      	cmpl	$0x5, %r15d
    1ee7:      	jg	0x1f2a <filter_char_buf_equal+0x1aa>
    1ee9:      	movq	0x8(%rsp), %rax
    1eee:      	movb	%bpl, (%rax)
    1ef1:      	leaq	0x1(%rax), %rdi
    1ef5:      	movl	%ebp, %r12d
    1ef8:      	movl	$0x4, %eax
    1efd:      	movq	0x20(%rsp), %rdx
    1f02:      	movl	%ebp, %esi
    1f04:      	callq	*%rax
    1f06:      	subl	%ebp, %r14d
    1f09:      	jbe	0x1f6f <filter_char_buf_equal+0x1ef>
    1f0b:      	movq	0x8(%rsp), %rax
    1f10:      	leaq	(%rax,%r12), %rdi
    1f14:      	incq	%rdi
    1f17:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1f1e:      	movl	$0x4, %eax
    1f23:      	movq	0x18(%rsp), %rdx
    1f28:      	jmp	0x1f6a <filter_char_buf_equal+0x1ea>
    1f2a:      	movq	0x8(%rsp), %rax
    1f2f:      	movw	%bp, (%rax)
    1f32:      	leaq	0x2(%rax), %rdi
    1f36:      	movl	%ebp, %r12d
    1f39:      	movl	$0x4, %eax
    1f3e:      	movq	0x20(%rsp), %rdx
    1f43:      	movl	%ebp, %esi
    1f45:      	callq	*%rax
    1f47:      	subl	%ebp, %r14d
    1f4a:      	jbe	0x1f6f <filter_char_buf_equal+0x1ef>
    1f4c:      	movq	0x8(%rsp), %rax
    1f51:      	leaq	(%rax,%r12), %rdi
    1f55:      	addq	$0x2, %rdi
    1f59:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1f60:      	movl	$0x4, %eax
    1f65:      	movq	0x18(%rsp), %rdx
    1f6a:      	movl	%r14d, %esi
    1f6d:      	callq	*%rax
    1f6f:      	movl	%r13d, 0x4(%rsp)
    1f74:      	cmpl	$0x4, %r15d
    1f78:      	jle	0x1fb4 <filter_char_buf_equal+0x234>
    1f7a:      	cmpl	$0x7, %r15d
    1f7e:      	jg	0x1fee <filter_char_buf_equal+0x26e>
    1f80:      	cmpl	$0x5, %r15d
    1f84:      	je	0x20a2 <filter_char_buf_equal+0x322>
    1f8a:      	cmpl	$0x6, %r15d
    1f8e:      	je	0x2069 <filter_char_buf_equal+0x2e9>
    1f94:      	cmpl	$0x7, %r15d
    1f98:      	jne	0x20ee <filter_char_buf_equal+0x36e>
    1f9e:      	movq	(%rip), %rdi            # 0x1fa5 <filter_char_buf_equal+0x225>
    1fa5:      	leaq	0x4(%rsp), %rcx
    1faa:      	movl	$0x1, %eax
    1faf:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    1fb4:      	cmpl	$0x1, %r15d
    1fb8:      	jle	0x201e <filter_char_buf_equal+0x29e>
    1fba:      	cmpl	$0x2, %r15d
    1fbe:      	je	0x208f <filter_char_buf_equal+0x30f>
    1fc4:      	cmpl	$0x3, %r15d
    1fc8:      	je	0x2056 <filter_char_buf_equal+0x2d6>
    1fce:      	cmpl	$0x4, %r15d
    1fd2:      	jne	0x20ee <filter_char_buf_equal+0x36e>
    1fd8:      	movq	(%rip), %rdi            # 0x1fdf <filter_char_buf_equal+0x25f>
    1fdf:      	leaq	0x4(%rsp), %rcx
    1fe4:      	movl	$0x1, %eax
    1fe9:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    1fee:      	cmpl	$0x8, %r15d
    1ff2:      	je	0x20b5 <filter_char_buf_equal+0x335>
    1ff8:      	cmpl	$0x9, %r15d
    1ffc:      	je	0x207c <filter_char_buf_equal+0x2fc>
    1ffe:      	cmpl	$0xa, %r15d
    2002:      	jne	0x20ee <filter_char_buf_equal+0x36e>
    2008:      	movq	(%rip), %rdi            # 0x200f <filter_char_buf_equal+0x28f>
    200f:      	leaq	0x4(%rsp), %rcx
    2014:      	movl	$0x1, %eax
    2019:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    201e:      	testl	%r15d, %r15d
    2021:      	je	0x2043 <filter_char_buf_equal+0x2c3>
    2023:      	cmpl	$0x1, %r15d
    2027:      	jne	0x20ee <filter_char_buf_equal+0x36e>
    202d:      	movq	(%rip), %rdi            # 0x2034 <filter_char_buf_equal+0x2b4>
    2034:      	leaq	0x4(%rsp), %rcx
    2039:      	movl	$0x1, %eax
    203e:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    2043:      	movq	(%rip), %rdi            # 0x204a <filter_char_buf_equal+0x2ca>
    204a:      	leaq	0x4(%rsp), %rcx
    204f:      	movl	$0x1, %eax
    2054:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    2056:      	movq	(%rip), %rdi            # 0x205d <filter_char_buf_equal+0x2dd>
    205d:      	leaq	0x4(%rsp), %rcx
    2062:      	movl	$0x1, %eax
    2067:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    2069:      	movq	(%rip), %rdi            # 0x2070 <filter_char_buf_equal+0x2f0>
    2070:      	leaq	0x4(%rsp), %rcx
    2075:      	movl	$0x1, %eax
    207a:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    207c:      	movq	(%rip), %rdi            # 0x2083 <filter_char_buf_equal+0x303>
    2083:      	leaq	0x4(%rsp), %rcx
    2088:      	movl	$0x1, %eax
    208d:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    208f:      	movq	(%rip), %rdi            # 0x2096 <filter_char_buf_equal+0x316>
    2096:      	leaq	0x4(%rsp), %rcx
    209b:      	movl	$0x1, %eax
    20a0:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    20a2:      	movq	(%rip), %rdi            # 0x20a9 <filter_char_buf_equal+0x329>
    20a9:      	leaq	0x4(%rsp), %rcx
    20ae:      	movl	$0x1, %eax
    20b3:      	jmp	0x20c6 <filter_char_buf_equal+0x346>
    20b5:      	movq	(%rip), %rdi            # 0x20bc <filter_char_buf_equal+0x33c>
    20bc:      	leaq	0x4(%rsp), %rcx
    20c1:      	movl	$0x1, %eax
    20c6:      	leaq	0x4(%rsp), %rsi
    20cb:      	callq	*%rax
    20cd:      	testq	%rax, %rax
    20d0:      	je	0x20ee <filter_char_buf_equal+0x36e>
    20d2:      	movq	%rax, %rdi
    20d5:      	movl	$0x1, %eax
    20da:      	movq	0x8(%rsp), %rsi
    20df:      	callq	*%rax
    20e1:      	movq	%rax, %rcx
    20e4:      	xorl	%eax, %eax
    20e6:      	testq	%rcx, %rcx
    20e9:      	setne	%al
    20ec:      	jmp	0x20f0 <filter_char_buf_equal+0x370>
    20ee:      	xorl	%eax, %eax
    20f0:      	addq	$0x28, %rsp
    20f4:      	popq	%rbx
    20f5:      	popq	%r12
    20f7:      	popq	%r13
    20f9:      	popq	%r14
    20fb:      	popq	%r15
    20fd:      	popq	%rbp
    20fe:      	retq
    20ff:      	nop

0000000000002100 <filter_char_buf_prefix>:
    2100:      	pushq	%rbp
    2101:      	pushq	%r15
    2103:      	pushq	%r14
    2105:      	pushq	%rbx
    2106:      	pushq	%rax
    2107:      	movl	%edx, %ebp
    2109:      	movq	%rsi, %rbx
    210c:      	movl	%edi, 0x4(%rsp)
    2110:      	movl	$0x0, (%rsp)
    2117:      	movq	(%rip), %rdi            # 0x211e <filter_char_buf_prefix+0x1e>
    211e:      	leaq	0x4(%rsp), %rsi
    2123:      	movl	$0x1, %eax
    2128:      	callq	*%rax
    212a:      	movq	%rax, %r14
    212d:      	xorl	%eax, %eax
    212f:      	testl	%ebp, %ebp
    2131:      	je	0x2195 <filter_char_buf_prefix+0x95>
    2133:      	testq	%r14, %r14
    2136:      	je	0x2195 <filter_char_buf_prefix+0x95>
    2138:      	movq	(%rip), %rdi            # 0x213f <filter_char_buf_prefix+0x3f>
    213f:      	movq	%rsp, %rsi
    2142:      	movl	$0x1, %eax
    2147:      	callq	*%rax
    2149:      	testq	%rax, %rax
    214c:      	je	0x2193 <filter_char_buf_prefix+0x93>
    214e:      	cmpl	$0xff, %ebp
    2154:      	movl	$0xff, %esi
    2159:      	cmovbl	%ebp, %esi
    215c:      	leal	(,%rsi,8), %ecx
    2163:      	movl	%ecx, (%rax)
    2165:      	movq	%rax, %rdi
    2168:      	addq	$0x4, %rdi
    216c:      	movq	%rax, %r15
    216f:      	movl	$0x4, %eax
    2174:      	movq	%rbx, %rdx
    2177:      	callq	*%rax
    2179:      	movl	$0x1, %eax
    217e:      	movq	%r14, %rdi
    2181:      	movq	%r15, %rsi
    2184:      	callq	*%rax
    2186:      	movq	%rax, %rcx
    2189:      	xorl	%eax, %eax
    218b:      	testq	%rcx, %rcx
    218e:      	setne	%al
    2191:      	jmp	0x2195 <filter_char_buf_prefix+0x95>
    2193:      	xorl	%eax, %eax
    2195:      	addq	$0x8, %rsp
    2199:      	popq	%rbx
    219a:      	popq	%r14
    219c:      	popq	%r15
    219e:      	popq	%rbp
    219f:      	retq

00000000000021a0 <filter_char_buf_postfix>:
    21a0:      	pushq	%r15
    21a2:      	pushq	%r14
    21a4:      	pushq	%rbx
    21a5:      	subq	$0x10, %rsp
    21a9:      	movl	%edx, %ebx
    21ab:      	movq	%rsi, %r14
    21ae:      	movl	%edi, 0xc(%rsp)
    21b2:      	movl	$0x0, 0x8(%rsp)
    21ba:      	movq	(%rip), %rdi            # 0x21c1 <filter_char_buf_postfix+0x21>
    21c1:      	leaq	0xc(%rsp), %rsi
    21c6:      	movl	$0x1, %eax
    21cb:      	callq	*%rax
    21cd:      	movq	%rax, %r15
    21d0:      	xorl	%eax, %eax
    21d2:      	testl	%ebx, %ebx
    21d4:      	je	0x22e0 <filter_char_buf_postfix+0x140>
    21da:      	testq	%r15, %r15
    21dd:      	je	0x22e0 <filter_char_buf_postfix+0x140>
    21e3:      	movq	(%rip), %rdi            # 0x21ea <filter_char_buf_postfix+0x4a>
    21ea:      	leaq	0x8(%rsp), %rsi
    21ef:      	movl	$0x1, %eax
    21f4:      	callq	*%rax
    21f6:      	testq	%rax, %rax
    21f9:      	je	0x22de <filter_char_buf_postfix+0x13e>
    21ff:      	movq	%rax, %rsi
    2202:      	cmpl	$0x7f, %ebx
    2205:      	movl	$0x7f, %eax
    220a:      	cmovbl	%ebx, %eax
    220d:      	shll	$0x3, %eax
    2210:      	movl	%eax, (%rsi)
    2212:      	movl	%ebx, %eax
    2214:      	leal	-0x4(%rbx), %ecx
    2217:      	movq	%rsi, %rdx
    221a:      	addq	$0x7, %rdx
    221e:      	leal	-0x3(%rbx), %edi
    2221:      	leal	-0x2(%rbx), %r8d
    2225:      	decl	%ebx
    2227:      	movq	$-0x3, %r9
    222e:      	nop
    2230:      	leal	(%rbx,%r9), %r10d
    2234:      	addl	$0x3, %r10d
    2238:      	andl	$0xfff, %r10d           # imm = 0xFFF
    223f:      	movzbl	(%r14,%r10), %r10d
    2244:      	movb	%r10b, -0x3(%rdx)
    2248:      	leaq	(%rax,%r9), %r10
    224c:      	cmpq	$-0x2, %r10
    2250:      	je	0x22c7 <filter_char_buf_postfix+0x127>
    2252:      	leal	(%r8,%r9), %r11d
    2256:      	addl	$0x3, %r11d
    225a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    2261:      	movzbl	(%r14,%r11), %r11d
    2266:      	movb	%r11b, -0x2(%rdx)
    226a:      	cmpq	$-0x1, %r10
    226e:      	je	0x22c7 <filter_char_buf_postfix+0x127>
    2270:      	leal	(%rdi,%r9), %r10d
    2274:      	addl	$0x3, %r10d
    2278:      	andl	$0xfff, %r10d           # imm = 0xFFF
    227f:      	movzbl	(%r14,%r10), %r10d
    2284:      	movb	%r10b, -0x1(%rdx)
    2288:      	movq	%rax, %r10
    228b:      	addq	%r9, %r10
    228e:      	je	0x22c7 <filter_char_buf_postfix+0x127>
    2290:      	cmpq	$-0x7f, %r9
    2294:      	je	0x22c7 <filter_char_buf_postfix+0x127>
    2296:      	leal	(%rcx,%r9), %r10d
    229a:      	addl	$0x3, %r10d
    229e:      	andl	$0xfff, %r10d           # imm = 0xFFF
    22a5:      	movzbl	(%r14,%r10), %r10d
    22aa:      	movb	%r10b, (%rdx)
    22ad:      	addq	$0x4, %rdx
    22b1:      	leaq	(%rax,%r9), %r10
    22b5:      	addq	$-0x4, %r10
    22b9:      	addq	$-0x4, %r9
    22bd:      	cmpq	$-0x3, %r10
    22c1:      	jne	0x2230 <filter_char_buf_postfix+0x90>
    22c7:      	movl	$0x1, %eax
    22cc:      	movq	%r15, %rdi
    22cf:      	callq	*%rax
    22d1:      	movq	%rax, %rcx
    22d4:      	xorl	%eax, %eax
    22d6:      	testq	%rcx, %rcx
    22d9:      	setne	%al
    22dc:      	jmp	0x22e0 <filter_char_buf_postfix+0x140>
    22de:      	xorl	%eax, %eax
    22e0:      	addq	$0x10, %rsp
    22e4:      	popq	%rbx
    22e5:      	popq	%r14
    22e7:      	popq	%r15
    22e9:      	retq
    22ea:      	nopw	(%rax,%rax)

00000000000022f0 <filter_file_type>:
    22f0:      	pushq	%rbx
    22f1:      	subq	$0x10, %rsp
    22f5:      	movw	$0x0, 0xe(%rsp)
    22fc:      	movl	(%rsi), %eax
    22fe:      	cmpq	$0x1000, %rax           # imm = 0x1000
    2304:      	ja	0x238c <filter_file_type+0x9c>
    230a:      	movq	%rdi, %rbx
    230d:      	leaq	(%rsi,%rax), %rcx
    2311:      	addq	$0x8, %rcx
    2315:      	leaq	0xe(%rsp), %rdi
    231a:      	movl	$0x2, %edx
    231f:      	movl	$0x4, %eax
    2324:      	movl	(%rsi), %ecx
    2326:      	leaq	(%rsi,%rcx), %rdx
    232a:      	addq	$0x8, %rdx
    232e:      	movl	$0x2, %esi
    2333:      	callq	*%rax
    2335:      	movl	0x10(%rbx), %edx
    2338:      	testl	%edx, %edx
    233a:      	je	0x238c <filter_file_type+0x9c>
    233c:      	movzwl	0xe(%rsp), %ecx
    2341:      	andl	$0xf000, %ecx           # imm = 0xF000
    2347:      	movl	$0x1, %eax
    234c:      	cmpl	%ecx, %edx
    234e:      	je	0x238e <filter_file_type+0x9e>
    2350:      	movl	0x8(%rbx), %edx
    2353:      	cmpl	$0xc, %edx
    2356:      	jbe	0x238c <filter_file_type+0x9c>
    2358:      	movl	0x14(%rbx), %esi
    235b:      	testl	%esi, %esi
    235d:      	je	0x238c <filter_file_type+0x9c>
    235f:      	cmpl	%ecx, %esi
    2361:      	je	0x238e <filter_file_type+0x9e>
    2363:      	cmpl	$0x11, %edx
    2366:      	jb	0x238c <filter_file_type+0x9c>
    2368:      	movl	0x18(%rbx), %esi
    236b:      	testl	%esi, %esi
    236d:      	je	0x238c <filter_file_type+0x9c>
    236f:      	cmpl	%ecx, %esi
    2371:      	je	0x238e <filter_file_type+0x9e>
    2373:      	cmpl	$0x15, %edx
    2376:      	jb	0x238c <filter_file_type+0x9c>
    2378:      	movl	0x1c(%rbx), %edx
    237b:      	testl	%edx, %edx
    237d:      	je	0x238c <filter_file_type+0x9c>
    237f:      	xorl	%eax, %eax
    2381:      	cmpl	%ecx, %edx
    2383:      	sete	%al
    2386:      	addq	$0x10, %rsp
    238a:      	popq	%rbx
    238b:      	retq
    238c:      	xorl	%eax, %eax
    238e:      	addq	$0x10, %rsp
    2392:      	popq	%rbx
    2393:      	retq
    2394:      	nopw	%cs:(%rax,%rax)

00000000000023a0 <filter_char_substring>:
    23a0:      	pushq	%rbp
    23a1:      	pushq	%r15
    23a3:      	pushq	%r14
    23a5:      	pushq	%r13
    23a7:      	pushq	%r12
    23a9:      	pushq	%rbx
    23aa:      	pushq	%rax
    23ab:      	movq	%rsi, %r15
    23ae:      	movq	%rdi, %r14
    23b1:      	movl	%edx, %ebp
    23b3:      	testl	%ecx, %ecx
    23b5:      	je	0x248d <filter_char_substring+0xed>
    23bb:      	testl	%edx, %edx
    23bd:      	je	0x253d <filter_char_substring+0x19d>
    23c3:      	leaq	0x4(%rsp), %r13
    23c8:      	xorl	%ebx, %ebx
    23ca:      	xorl	%r12d, %r12d
    23cd:      	nopl	(%rax)
    23d0:      	movl	0x10(%r14,%rbx,4), %eax
    23d5:      	movl	%eax, 0x4(%rsp)
    23d9:      	movl	$0x1, %eax
    23de:      	movq	(%rip), %rdi            # 0x23e5 <filter_char_substring+0x45>
    23e5:      	movq	%r13, %rsi
    23e8:      	callq	*%rax
    23ea:      	testq	%rax, %rax
    23ed:      	je	0x25d0 <filter_char_substring+0x230>
    23f3:      	movq	%r15, %rdx
    23f6:      	xorl	%ecx, %ecx
    23f8:      	jmp	0x240b <filter_char_substring+0x6b>
    23fa:      	nopw	(%rax,%rax)
    2400:      	incq	%rcx
    2403:      	incq	%rdx
    2406:      	cmpq	%rbp, %rcx
    2409:      	je	0x2468 <filter_char_substring+0xc8>
    240b:      	xorl	%esi, %esi
    240d:      	nopl	(%rax)
    2410:      	leaq	(%rcx,%rsi), %rdi
    2414:      	cmpq	%rbp, %rdi
    2417:      	jae	0x2400 <filter_char_substring+0x60>
    2419:      	movsbl	(%rax,%rsi), %edi
    241d:      	testl	%edi, %edi
    241f:      	je	0x2460 <filter_char_substring+0xc0>
    2421:      	movsbl	(%rdx,%rsi), %r9d
    2426:      	leal	-0x41(%r9), %r10d
    242a:      	movl	%r9d, %r8d
    242d:      	orl	$0x20, %r8d
    2431:      	cmpl	$0x1a, %r10d
    2435:      	cmovael	%r9d, %r8d
    2439:      	leal	-0x41(%rdi), %r10d
    243d:      	movl	%edi, %r9d
    2440:      	orl	$0x20, %r9d
    2444:      	cmpl	$0x1a, %r10d
    2448:      	cmovael	%edi, %r9d
    244c:      	cmpq	$0x62, %rsi
    2450:      	ja	0x2400 <filter_char_substring+0x60>
    2452:      	incq	%rsi
    2455:      	cmpl	%r9d, %r8d
    2458:      	je	0x2410 <filter_char_substring+0x70>
    245a:      	jmp	0x2400 <filter_char_substring+0x60>
    245c:      	nopl	(%rax)
    2460:      	testl	%ecx, %ecx
    2462:      	jns	0x25e1 <filter_char_substring+0x241>
    2468:      	leal	0xc(%r12), %eax
    246d:      	cmpl	0x8(%r14), %eax
    2471:      	jae	0x25d0 <filter_char_substring+0x230>
    2477:      	addl	$0x4, %r12d
    247b:      	incq	%rbx
    247e:      	cmpq	$0x64, %rbx
    2482:      	jne	0x23d0 <filter_char_substring+0x30>
    2488:      	jmp	0x25d0 <filter_char_substring+0x230>
    248d:      	testl	%edx, %edx
    248f:      	je	0x2582 <filter_char_substring+0x1e2>
    2495:      	leaq	0x4(%rsp), %r13
    249a:      	xorl	%ebx, %ebx
    249c:      	xorl	%r12d, %r12d
    249f:      	nop
    24a0:      	movl	0x10(%r14,%rbx,4), %eax
    24a5:      	movl	%eax, 0x4(%rsp)
    24a9:      	movl	$0x1, %eax
    24ae:      	movq	(%rip), %rdi            # 0x24b5 <filter_char_substring+0x115>
    24b5:      	movq	%r13, %rsi
    24b8:      	callq	*%rax
    24ba:      	testq	%rax, %rax
    24bd:      	je	0x25d0 <filter_char_substring+0x230>
    24c3:      	movq	%r15, %rdx
    24c6:      	xorl	%ecx, %ecx
    24c8:      	jmp	0x24db <filter_char_substring+0x13b>
    24ca:      	nopw	(%rax,%rax)
    24d0:      	incq	%rcx
    24d3:      	incq	%rdx
    24d6:      	cmpq	%rbp, %rcx
    24d9:      	je	0x2518 <filter_char_substring+0x178>
    24db:      	xorl	%esi, %esi
    24dd:      	nopl	(%rax)
    24e0:      	leaq	(%rcx,%rsi), %rdi
    24e4:      	cmpq	%rbp, %rdi
    24e7:      	jae	0x24d0 <filter_char_substring+0x130>
    24e9:      	movzbl	(%rax,%rsi), %edi
    24ed:      	testb	%dil, %dil
    24f0:      	je	0x2510 <filter_char_substring+0x170>
    24f2:      	cmpq	$0x62, %rsi
    24f6:      	ja	0x24d0 <filter_char_substring+0x130>
    24f8:      	leaq	0x1(%rsi), %r8
    24fc:      	cmpb	%dil, (%rdx,%rsi)
    2500:      	movq	%r8, %rsi
    2503:      	je	0x24e0 <filter_char_substring+0x140>
    2505:      	jmp	0x24d0 <filter_char_substring+0x130>
    2507:      	nopw	(%rax,%rax)
    2510:      	testl	%ecx, %ecx
    2512:      	jns	0x25e1 <filter_char_substring+0x241>
    2518:      	leal	0xc(%r12), %eax
    251d:      	cmpl	0x8(%r14), %eax
    2521:      	jae	0x25d0 <filter_char_substring+0x230>
    2527:      	addl	$0x4, %r12d
    252b:      	incq	%rbx
    252e:      	cmpq	$0x64, %rbx
    2532:      	jne	0x24a0 <filter_char_substring+0x100>
    2538:      	jmp	0x25d0 <filter_char_substring+0x230>
    253d:      	movl	$0x10, %ebx
    2542:      	movq	(%rip), %r15            # 0x2549 <filter_char_substring+0x1a9>
    2549:      	leaq	0x4(%rsp), %r12
    254e:      	nop
    2550:      	movl	(%r14,%rbx), %eax
    2554:      	movl	%eax, 0x4(%rsp)
    2558:      	movl	$0x1, %eax
    255d:      	movq	%r15, %rdi
    2560:      	movq	%r12, %rsi
    2563:      	callq	*%rax
    2565:      	testq	%rax, %rax
    2568:      	je	0x25d0 <filter_char_substring+0x230>
    256a:      	addq	$0x4, %rbx
    256e:      	leal	-0x8(%rbx), %eax
    2571:      	cmpl	0x8(%r14), %eax
    2575:      	jae	0x25d0 <filter_char_substring+0x230>
    2577:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    257e:      	jne	0x2550 <filter_char_substring+0x1b0>
    2580:      	jmp	0x25d0 <filter_char_substring+0x230>
    2582:      	movl	$0x10, %ebx
    2587:      	movq	(%rip), %r15            # 0x258e <filter_char_substring+0x1ee>
    258e:      	leaq	0x4(%rsp), %r12
    2593:      	nopw	%cs:(%rax,%rax)
    25a0:      	movl	(%r14,%rbx), %eax
    25a4:      	movl	%eax, 0x4(%rsp)
    25a8:      	movl	$0x1, %eax
    25ad:      	movq	%r15, %rdi
    25b0:      	movq	%r12, %rsi
    25b3:      	callq	*%rax
    25b5:      	testq	%rax, %rax
    25b8:      	je	0x25d0 <filter_char_substring+0x230>
    25ba:      	addq	$0x4, %rbx
    25be:      	leal	-0x8(%rbx), %eax
    25c1:      	cmpl	0x8(%r14), %eax
    25c5:      	jae	0x25d0 <filter_char_substring+0x230>
    25c7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    25ce:      	jne	0x25a0 <filter_char_substring+0x200>
    25d0:      	xorl	%eax, %eax
    25d2:      	addq	$0x8, %rsp
    25d6:      	popq	%rbx
    25d7:      	popq	%r12
    25d9:      	popq	%r13
    25db:      	popq	%r14
    25dd:      	popq	%r15
    25df:      	popq	%rbp
    25e0:      	retq
    25e1:      	movl	$0x1, %eax
    25e6:      	jmp	0x25d2 <filter_char_substring+0x232>
    25e8:      	nopl	(%rax,%rax)

00000000000025f0 <do_action>:
    25f0:      	pushq	%rbp
    25f1:      	pushq	%r15
    25f3:      	pushq	%r14
    25f5:      	pushq	%r13
    25f7:      	pushq	%r12
    25f9:      	pushq	%rbx
    25fa:      	subq	$0x88, %rsp
    2601:      	movl	%r8d, %ebp
    2604:      	movq	%rcx, 0x48(%rsp)
    2609:      	movq	%rdx, %r15
    260c:      	movl	%esi, %r14d
    260f:      	movq	%rdi, %r13
    2612:      	movl	%esi, %eax
    2614:      	movslq	0x4(%rdx,%rax,4), %rbx
    2619:      	movl	$0x0, 0x64(%rsp)
    2621:      	movq	(%rip), %rdi            # 0x2628 <do_action+0x38>
    2628:      	leaq	0x64(%rsp), %rsi
    262d:      	movl	$0x1, %eax
    2632:      	callq	*%rax
    2634:      	movq	%rax, %r12
    2637:      	xorl	%eax, %eax
    2639:      	testq	%r12, %r12
    263c:      	je	0x2e33 <do_action+0x843>
    2642:      	cmpl	$0x7, %ebx
    2645:      	jg	0x266b <do_action+0x7b>
    2647:      	cmpl	$0x3, %ebx
    264a:      	jg	0x26a7 <do_action+0xb7>
    264c:      	cmpl	$0x1, %ebx
    264f:      	jg	0x272e <do_action+0x13e>
    2655:      	testl	%ebx, %ebx
    2657:      	je	0x2a34 <do_action+0x444>
    265d:      	cmpl	$0x1, %ebx
    2660:      	je	0x2745 <do_action+0x155>
    2666:      	jmp	0x2e28 <do_action+0x838>
    266b:      	cmpl	$0xb, %ebx
    266e:      	jg	0x26f7 <do_action+0x107>
    2674:      	leal	-0xa(%rbx), %ecx
    2677:      	cmpl	$0x2, %ecx
    267a:      	jb	0x2858 <do_action+0x268>
    2680:      	cmpl	$0x8, %ebx
    2683:      	je	0x292e <do_action+0x33e>
    2689:      	cmpl	$0x9, %ebx
    268c:      	jne	0x2e28 <do_action+0x838>
    2692:      	movq	%r12, %r13
    2695:      	movq	%rbx, 0x30(%rsp)
    269a:      	incl	%r14d
    269d:      	movl	0x4(%r15,%r14,4), %eax
    26a2:      	jmp	0x2afa <do_action+0x50a>
    26a7:      	leal	-0x6(%rbx), %eax
    26aa:      	cmpl	$0x2, %eax
    26ad:      	jb	0x291c <do_action+0x32c>
    26b3:      	cmpl	$0x4, %ebx
    26b6:      	je	0x293b <do_action+0x34b>
    26bc:      	cmpl	$0x5, %ebx
    26bf:      	jne	0x2e28 <do_action+0x838>
    26c5:      	movq	%r12, %r13
    26c8:      	movq	%rbx, %r12
    26cb:      	leal	0x1(%r14), %eax
    26cf:      	movl	0x4(%r15,%rax,4), %eax
    26d4:      	addl	$0x2, %r14d
    26d8:      	andl	$0x7, %eax
    26db:      	cmpl	$0x4, %eax
    26de:      	ja	0x26ef <do_action+0xff>
    26e0:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    26e9:      	je	0x2c91 <do_action+0x6a1>
    26ef:      	movq	%r12, %rbx
    26f2:      	jmp	0x2e25 <do_action+0x835>
    26f7:      	cmpl	$0xc, %ebx
    26fa:      	je	0x2b1f <do_action+0x52f>
    2700:      	cmpl	$0xd, %ebx
    2703:      	je	0x29bc <do_action+0x3cc>
    2709:      	cmpl	$0xe, %ebx
    270c:      	jne	0x2e28 <do_action+0x838>
    2712:      	movq	%r12, %r13
    2715:      	movq	%rbx, 0x30(%rsp)
    271a:      	addl	$0x2, %r14d
    271e:      	movzbl	%bpl, %ebx
    2722:      	xorq	$0x9, %rbx
    2726:      	movl	%r14d, %r12d
    2729:      	jmp	0x2dfb <do_action+0x80b>
    272e:      	movl	$0x9, %eax
    2733:      	cmpl	$0x2, %ebx
    2736:      	je	0x2af2 <do_action+0x502>
    273c:      	cmpl	$0x3, %ebx
    273f:      	jne	0x2e28 <do_action+0x838>
    2745:      	movq	%rbx, %rbp
    2748:      	leal	0x1(%r14), %eax
    274c:      	movl	0x4(%r15,%rax,4), %r13d
    2751:      	addl	$0x2, %r14d
    2755:      	movl	0x4(%r15,%r14,4), %ebx
    275a:      	movl	$0x0, 0x10(%rsp)
    2762:      	movq	(%rip), %rdi            # 0x2769 <do_action+0x179>
    2769:      	leaq	0x10(%rsp), %rsi
    276e:      	movl	$0x1, %eax
    2773:      	callq	*%rax
    2775:      	xorl	%r15d, %r15d
    2778:      	testq	%rax, %rax
    277b:      	je	0x2dc2 <do_action+0x7d2>
    2781:      	movq	%rax, 0x48(%rsp)
    2786:      	andl	$0x7, %r13d
    278a:      	cmpl	$0x4, %r13d
    278e:      	movl	$0x0, %eax
    2793:      	ja	0x2dc4 <do_action+0x7d4>
    2799:      	cmpl	$0x0, 0x5ea0(%r12,%r13,4)
    27a2:      	jne	0x2dc4 <do_action+0x7d4>
    27a8:      	movq	0x5e78(%r12,%r13,8), %rax
    27b0:      	movl	$0x0, 0xc(%rsp)
    27b8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    27bd:      	movl	0x90(%r12,%rax), %eax
    27c5:      	movl	%eax, 0x8(%rsp)
    27c9:      	movl	$0xe, %eax
    27ce:      	callq	*%rax
    27d0:      	shrq	$0x20, %rax
    27d4:      	movq	%rax, (%rsp)
    27d8:      	cmpl	$0x1, %ebp
    27db:      	jne	0x2dae <do_action+0x7be>
    27e1:      	andl	$0x7, %ebx
    27e4:      	cmpl	$0x4, %ebx
    27e7:      	ja	0x2dc2 <do_action+0x7d2>
    27ed:      	cmpl	$0x0, 0x5ea0(%r12,%rbx,4)
    27f6:      	movl	$0x0, %eax
    27fb:      	jne	0x2dc4 <do_action+0x7d4>
    2801:      	movq	0x5e78(%r12,%rbx,8), %rax
    2809:      	andl	$0x7ff, %eax            # imm = 0x7FF
    280e:      	leaq	(%r12,%rax), %rdx
    2812:      	addq	$0x90, %rdx
    2819:      	movl	0x90(%r12,%rax), %esi
    2821:      	andl	$0xfff, %esi            # imm = 0xFFF
    2827:      	addq	$0x8, %rsi
    282b:      	movl	$0x4, %eax
    2830:      	movq	0x48(%rsp), %rbx
    2835:      	movq	%rbx, %rdi
    2838:      	callq	*%rax
    283a:      	movq	(%rip), %rdi            # 0x2841 <do_action+0x251>
    2841:      	xorl	%r15d, %r15d
    2844:      	movq	%rsp, %rsi
    2847:      	movl	$0x2, %eax
    284c:      	movq	%rbx, %rdx
    284f:      	xorl	%ecx, %ecx
    2851:      	callq	*%rax
    2853:      	jmp	0x2dc2 <do_action+0x7d2>
    2858:      	incl	%r14d
    285b:      	movl	0x4(%r15,%r14,4), %ecx
    2860:      	andl	$0x7, %ecx
    2863:      	xorl	%r15d, %r15d
    2866:      	cmpl	$0x4, %ecx
    2869:      	ja	0x2dc7 <do_action+0x7d7>
    286f:      	cmpl	$0x0, 0x5ea0(%r12,%rcx,4)
    2878:      	jne	0x2dc7 <do_action+0x7d7>
    287e:      	movq	0x5e78(%r12,%rcx,8), %rcx
    2886:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    288c:      	movq	0xb8(%r12,%rcx), %rcx
    2894:      	movq	%rcx, 0x10(%rsp)
    2899:      	testq	%rcx, %rcx
    289c:      	je	0x2dc7 <do_action+0x7d7>
    28a2:      	cmpl	$0xa, %ebx
    28a5:      	jne	0x2e45 <do_action+0x855>
    28ab:      	movl	$0xe, %eax
    28b0:      	callq	*%rax
    28b2:      	movq	%rax, %r13
    28b5:      	shrq	$0x20, %rax
    28b9:      	movl	%eax, (%rsp)
    28bc:      	movq	(%rip), %rdi            # 0x28c3 <do_action+0x2d3>
    28c3:      	movq	%rsp, %rsi
    28c6:      	movl	$0x1, %eax
    28cb:      	callq	*%rax
    28cd:      	movq	%rax, %rcx
    28d0:      	testq	%rax, %rax
    28d3:      	movl	$0x0, %eax
    28d8:      	je	0x2dc7 <do_action+0x7d7>
    28de:      	movl	(%rcx), %eax
    28e0:      	movl	%eax, (%rsp)
    28e3:      	movl	%r13d, 0x4(%rsp)
    28e8:      	movq	0x8(%rcx), %rax
    28ec:      	movq	%rax, 0x8(%rsp)
    28f1:      	movq	(%rip), %rdi            # 0x28f8 <do_action+0x308>
    28f8:      	xorl	%r15d, %r15d
    28fb:      	leaq	0x10(%rsp), %rsi
    2900:      	movq	%rsp, %rdx
    2903:      	movl	$0x2, %eax
    2908:      	xorl	%ecx, %ecx
    290a:      	callq	*%rax
    290c:      	xorl	%eax, %eax
    290e:      	testl	%r15d, %r15d
    2911:      	jne	0x2e33 <do_action+0x843>
    2917:      	jmp	0x2e28 <do_action+0x838>
    291c:      	incl	%r14d
    291f:      	movl	0x4(%r15,%r14,4), %eax
    2924:      	movl	%eax, 0x78(%r12)
    2929:      	jmp	0x2e28 <do_action+0x838>
    292e:      	movq	0x48(%rsp), %rax
    2933:      	movb	$0x0, (%rax)
    2936:      	jmp	0x2e28 <do_action+0x838>
    293b:      	movq	%rbx, 0x30(%rsp)
    2940:      	incl	%r14d
    2943:      	movl	$0x5, %ebx
    2948:      	testb	%bpl, %bpl
    294b:      	je	0x2bfc <do_action+0x60c>
    2951:      	movl	%r14d, %eax
    2954:      	movl	0x4(%r15,%rax,4), %ebx
    2959:      	movl	%ebx, 0x38(%rsp)
    295d:      	movl	$0xe, %eax
    2962:      	callq	*%rax
    2964:      	movq	%rax, 0x10(%rsp)
    2969:      	movq	(%rip), %rdi            # 0x2970 <do_action+0x380>
    2970:      	leaq	0x10(%rsp), %rsi
    2975:      	movl	$0x1, %eax
    297a:      	callq	*%rax
    297c:      	testq	%rax, %rax
    297f:      	je	0x2c6d <do_action+0x67d>
    2985:      	movq	%rax, %r15
    2988:      	movq	%r12, %r13
    298b:      	movl	$0xe0011, (%rsp)        # imm = 0xE0011
    2992:      	movq	$0x35c, 0x4(%rsp)       # imm = 0x35C
    299b:      	movq	(%rip), %rdi            # 0x29a2 <do_action+0x3b2>
    29a2:      	movq	%rsp, %rsi
    29a5:      	movl	$0x1, %eax
    29aa:      	callq	*%rax
    29ac:      	testq	%rax, %rax
    29af:      	je	0x2dce <do_action+0x7de>
    29b5:      	incl	(%rax)
    29b7:      	jmp	0x2df0 <do_action+0x800>
    29bc:      	movl	$0xe, %eax
    29c1:      	callq	*%rax
    29c3:      	movq	%rax, 0x20(%rsp)
    29c8:      	movq	(%rip), %rdi            # 0x29cf <do_action+0x3df>
    29cf:      	leaq	0x20(%rsp), %rsi
    29d4:      	movl	$0x1, %eax
    29d9:      	callq	*%rax
    29db:      	testq	%rax, %rax
    29de:      	je	0x2e28 <do_action+0x838>
    29e4:      	movq	0x4(%rax), %rax
    29e8:      	movq	%rax, 0x10(%rsp)
    29ed:      	movl	$0x2, 0x18(%rsp)
    29f5:      	movq	(%rip), %rdi            # 0x29fc <do_action+0x40c>
    29fc:      	leaq	0x10(%rsp), %rsi
    2a01:      	movl	$0x1, %eax
    2a06:      	callq	*%rax
    2a08:      	movl	$0x1, 0x2c(%rsp)
    2a10:      	testq	%rax, %rax
    2a13:      	je	0x2c07 <do_action+0x617>
    2a19:      	lock
    2a1a:      	incl	(%rax)
    2a1c:      	movq	(%rip), %rdi            # 0x2a23 <do_action+0x433>
    2a23:      	leaq	0x20(%rsp), %rsi
    2a28:      	movl	$0x3, %eax
    2a2d:      	callq	*%rax
    2a2f:      	jmp	0x2e28 <do_action+0x838>
    2a34:      	movq	%rbx, 0x30(%rsp)
    2a39:      	leal	0x1(%r14), %eax
    2a3d:      	movl	0x4(%r15,%rax,4), %ebp
    2a42:      	leal	0x2(%r14), %eax
    2a46:      	movl	0x4(%r15,%rax,4), %ebx
    2a4b:      	movl	$0x7d, %eax
    2a50:      	callq	*%rax
    2a52:      	movq	%rax, 0x70(%rsp)
    2a57:      	movq	%rax, (%rsp)
    2a5b:      	movl	$0x0, 0x20(%rsp)
    2a63:      	movq	%rbp, 0x78(%rsp)
    2a68:      	testq	%rbp, %rbp
    2a6b:      	je	0x3096 <do_action+0xaa6>
    2a71:      	movq	(%rip), %rdi            # 0x2a78 <do_action+0x488>
    2a78:      	leaq	0x20(%rsp), %rsi
    2a7d:      	movl	$0x1, %eax
    2a82:      	callq	*%rax
    2a84:      	testq	%rax, %rax
    2a87:      	je	0x3096 <do_action+0xaa6>
    2a8d:      	movq	%rax, 0x58(%rsp)
    2a92:      	movq	%rax, %rbp
    2a95:      	movq	(%rip), %rdi            # 0x2a9c <do_action+0x4ac>
    2a9c:      	leaq	0x20(%rsp), %rsi
    2aa1:      	movl	$0x1, %eax
    2aa6:      	callq	*%rax
    2aa8:      	movq	%rax, %rdx
    2aab:      	movq	0x60(%r12), %rax
    2ab0:      	movq	%rax, (%rbp)
    2ab4:      	movq	0x70(%r12), %rax
    2ab9:      	movq	%rbp, 0x50(%rsp)
    2abe:      	movq	%rax, 0x8(%rbp)
    2ac2:      	xorl	%eax, %eax
    2ac4:      	movq	%rax, 0x68(%rsp)
    2ac9:      	movl	$0x0, %eax
    2ace:      	cmpl	$0x2, %ebx
    2ad1:      	je	0x2ecf <do_action+0x8df>
    2ad7:      	cmpl	$0x1, %ebx
    2ada:      	je	0x2eca <do_action+0x8da>
    2ae0:      	testl	%ebx, %ebx
    2ae2:      	jne	0x3096 <do_action+0xaa6>
    2ae8:      	movl	0x7c(%r12), %eax
    2aed:      	jmp	0x2ecf <do_action+0x8df>
    2af2:      	movq	%r12, %r13
    2af5:      	movq	%rbx, 0x30(%rsp)
    2afa:      	movl	%r14d, %r12d
    2afd:      	movl	$0x3, %ebx
    2b02:      	testb	%bpl, %bpl
    2b05:      	je	0x2dfb <do_action+0x80b>
    2b0b:      	movslq	%eax, %rdi
    2b0e:      	movl	$0x6d, %eax
    2b13:      	callq	*%rax
    2b15:      	movl	$0x2, %ebx
    2b1a:      	jmp	0x2dfb <do_action+0x80b>
    2b1f:      	movq	%r12, %r13
    2b22:      	movq	%rbx, 0x30(%rsp)
    2b27:      	leal	0x3(%r14), %r12d
    2b2b:      	movl	$0x7, %ebx
    2b30:      	testb	%bpl, %bpl
    2b33:      	je	0x2dfb <do_action+0x80b>
    2b39:      	movl	%r12d, %eax
    2b3c:      	movl	0x4(%r15,%rax,4), %eax
    2b41:      	leal	0x2(%r14), %ecx
    2b45:      	incl	%r14d
    2b48:      	movl	0x4(%r15,%rcx,4), %ebx
    2b4d:      	movl	0x4(%r15,%r14,4), %ebp
    2b52:      	cmpq	$0x4, %rax
    2b56:      	ja	0x2b67 <do_action+0x577>
    2b58:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    2b61:      	je	0x311a <do_action+0xb2a>
    2b67:      	xorl	%eax, %eax
    2b69:      	movl	0x60(%r13), %r14d
    2b6d:      	orq	%rax, %r14
    2b70:      	movl	$0xe, %eax
    2b75:      	callq	*%rax
    2b77:      	movq	%rax, 0x38(%rsp)
    2b7c:      	movw	%bp, 0x10(%rsp)
    2b81:      	movw	%bx, 0x12(%rsp)
    2b86:      	movq	%r14, 0x14(%rsp)
    2b8b:      	movq	(%rip), %rdi            # 0x2b92 <do_action+0x5a2>
    2b92:      	leaq	0x38(%rsp), %rsi
    2b97:      	movl	$0x1, %eax
    2b9c:      	callq	*%rax
    2b9e:      	testq	%rax, %rax
    2ba1:      	je	0x2d4c <do_action+0x75c>
    2ba7:      	movq	%rax, %r14
    2baa:      	movq	0x4(%rax), %rax
    2bae:      	movq	%rax, 0x20(%rsp)
    2bb3:      	movl	$0x1, 0x28(%rsp)
    2bbb:      	movq	(%rip), %rdi            # 0x2bc2 <do_action+0x5d2>
    2bc2:      	leaq	0x20(%rsp), %rsi
    2bc7:      	movl	$0x1, %eax
    2bcc:      	callq	*%rax
    2bce:      	movl	$0x1, 0x44(%rsp)
    2bd6:      	testq	%rax, %rax
    2bd9:      	je	0x2e64 <do_action+0x874>
    2bdf:      	lock
    2be0:      	incl	(%rax)
    2be2:      	movl	0x18(%rsp), %eax
    2be6:      	movl	%eax, 0x8(%r14)
    2bea:      	movq	0x10(%rsp), %rax
    2bef:      	movq	%rax, (%r14)
    2bf2:      	movl	$0x6, %ebx
    2bf7:      	jmp	0x2dfb <do_action+0x80b>
    2bfc:      	movq	%r12, %r13
    2bff:      	movl	%r14d, %r12d
    2c02:      	jmp	0x2dfb <do_action+0x80b>
    2c07:      	movq	(%rip), %rdi            # 0x2c0e <do_action+0x61e>
    2c0e:      	leaq	0x10(%rsp), %rsi
    2c13:      	leaq	0x2c(%rsp), %rdx
    2c18:      	movl	$0x1, %ecx
    2c1d:      	movl	$0x2, %eax
    2c22:      	callq	*%rax
    2c24:      	testq	%rax, %rax
    2c27:      	je	0x2a1c <do_action+0x42c>
    2c2d:      	movq	%rax, %r15
    2c30:      	negl	%eax
    2c32:      	movw	%ax, (%rsp)
    2c36:      	movw	$0x3, 0x2(%rsp)
    2c3d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    2c47:      	movq	%rax, 0x4(%rsp)
    2c4c:      	movq	(%rip), %rdi            # 0x2c53 <do_action+0x663>
    2c53:      	movq	%rsp, %rsi
    2c56:      	movl	$0x1, %eax
    2c5b:      	callq	*%rax
    2c5d:      	testq	%rax, %rax
    2c60:      	je	0x313b <do_action+0xb4b>
    2c66:      	incl	(%rax)
    2c68:      	jmp	0x315d <do_action+0xb6d>
    2c6d:      	movq	%r12, %r13
    2c70:      	movq	(%rip), %rdi            # 0x2c77 <do_action+0x687>
    2c77:      	xorl	%ecx, %ecx
    2c79:      	leaq	0x10(%rsp), %rsi
    2c7e:      	leaq	0x38(%rsp), %rdx
    2c83:      	movl	$0x2, %eax
    2c88:      	xorl	%ecx, %ecx
    2c8a:      	callq	*%rax
    2c8c:      	jmp	0x2df3 <do_action+0x803>
    2c91:      	movl	0x4(%r15,%r14,4), %ebx
    2c96:      	movq	0x5e78(%r13,%rax,8), %rax
    2c9e:      	movl	$0x0, 0xc(%rsp)
    2ca6:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2cab:      	movl	0x90(%r13,%rax), %eax
    2cb3:      	movl	%eax, 0x8(%rsp)
    2cb7:      	movl	$0xe, %eax
    2cbc:      	callq	*%rax
    2cbe:      	shrq	$0x20, %rax
    2cc2:      	movq	%rax, (%rsp)
    2cc6:      	movq	(%rip), %rdi            # 0x2ccd <do_action+0x6dd>
    2ccd:      	movq	%rsp, %rsi
    2cd0:      	movl	$0x1, %eax
    2cd5:      	callq	*%rax
    2cd7:      	testq	%rax, %rax
    2cda:      	je	0x26ef <do_action+0xff>
    2ce0:      	andl	$0x7, %ebx
    2ce3:      	cmpl	$0x4, %ebx
    2ce6:      	ja	0x26ef <do_action+0xff>
    2cec:      	cmpl	$0x0, 0x5ea0(%r13,%rbx,4)
    2cf5:      	jne	0x26ef <do_action+0xff>
    2cfb:      	movq	0x5e78(%r13,%rbx,8), %rcx
    2d03:      	movl	$0x0, 0xc(%rsp)
    2d0b:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    2d11:      	movl	0x90(%r13,%rcx), %ecx
    2d19:      	movl	%ecx, 0x8(%rsp)
    2d1d:      	movq	%rax, %r15
    2d20:      	movl	$0xe, %eax
    2d25:      	callq	*%rax
    2d27:      	shrq	$0x20, %rax
    2d2b:      	movq	%rax, (%rsp)
    2d2f:      	movq	(%rip), %rdi            # 0x2d36 <do_action+0x746>
    2d36:      	xorl	%ecx, %ecx
    2d38:      	movq	%rsp, %rsi
    2d3b:      	movl	$0x2, %eax
    2d40:      	movq	%r15, %rdx
    2d43:      	xorl	%ecx, %ecx
    2d45:      	callq	*%rax
    2d47:      	jmp	0x26ef <do_action+0xff>
    2d4c:      	movq	(%rip), %rdi            # 0x2d53 <do_action+0x763>
    2d53:      	xorl	%ecx, %ecx
    2d55:      	leaq	0x38(%rsp), %rsi
    2d5a:      	leaq	0x10(%rsp), %rdx
    2d5f:      	movl	$0x2, %eax
    2d64:      	xorl	%ecx, %ecx
    2d66:      	callq	*%rax
    2d68:      	testq	%rax, %rax
    2d6b:      	je	0x2bf2 <do_action+0x602>
    2d71:      	negl	%eax
    2d73:      	movw	%ax, (%rsp)
    2d77:      	movw	$0x3, 0x2(%rsp)
    2d7e:      	movabsq	$0x20000006b, %rax      # imm = 0x20000006B
    2d88:      	movq	%rax, 0x4(%rsp)
    2d8d:      	movq	(%rip), %rdi            # 0x2d94 <do_action+0x7a4>
    2d94:      	movq	%rsp, %rsi
    2d97:      	movl	$0x1, %eax
    2d9c:      	callq	*%rax
    2d9e:      	testq	%rax, %rax
    2da1:      	je	0x318e <do_action+0xb9e>
    2da7:      	incl	(%rax)
    2da9:      	jmp	0x2bf2 <do_action+0x602>
    2dae:      	movq	(%rip), %rdi            # 0x2db5 <do_action+0x7c5>
    2db5:      	movq	%rsp, %rsi
    2db8:      	movl	$0x3, %eax
    2dbd:      	callq	*%rax
    2dbf:      	movq	%rax, %r15
    2dc2:      	xorl	%eax, %eax
    2dc4:      	movq	%rbp, %rbx
    2dc7:      	testl	%r15d, %r15d
    2dca:      	jne	0x2e33 <do_action+0x843>
    2dcc:      	jmp	0x2e28 <do_action+0x838>
    2dce:      	movl	$0x1, 0x20(%rsp)
    2dd6:      	movq	(%rip), %rdi            # 0x2ddd <do_action+0x7ed>
    2ddd:      	xorl	%ecx, %ecx
    2ddf:      	movq	%rsp, %rsi
    2de2:      	leaq	0x20(%rsp), %rdx
    2de7:      	movl	$0x2, %eax
    2dec:      	xorl	%ecx, %ecx
    2dee:      	callq	*%rax
    2df0:      	movl	%ebx, (%r15)
    2df3:      	movl	$0x4, %ebx
    2df8:      	movl	%r14d, %r12d
    2dfb:      	movl	$0x0, (%rsp)
    2e02:      	movq	(%rip), %rdi            # 0x2e09 <do_action+0x819>
    2e09:      	movq	%rsp, %rsi
    2e0c:      	movl	$0x1, %eax
    2e11:      	callq	*%rax
    2e13:      	testq	%rax, %rax
    2e16:      	je	0x2e1d <do_action+0x82d>
    2e18:      	lock
    2e19:      	incq	(%rax,%rbx,8)
    2e1d:      	movl	%r12d, %r14d
    2e20:      	movq	0x30(%rsp), %rbx
    2e25:      	movq	%r13, %r12
    2e28:      	movq	%rbx, 0x70(%r12)
    2e2d:      	incl	%r14d
    2e30:      	movl	%r14d, %eax
    2e33:      	addq	$0x88, %rsp
    2e3a:      	popq	%rbx
    2e3b:      	popq	%r12
    2e3d:      	popq	%r13
    2e3f:      	popq	%r14
    2e41:      	popq	%r15
    2e43:      	popq	%rbp
    2e44:      	retq
    2e45:      	movq	(%rip), %rdi            # 0x2e4c <do_action+0x85c>
    2e4c:      	leaq	0x10(%rsp), %rsi
    2e51:      	movl	$0x3, %eax
    2e56:      	callq	*%rax
    2e58:      	movq	%rax, %r15
    2e5b:      	xorl	%eax, %eax
    2e5d:      	testl	%r15d, %r15d
    2e60:      	jne	0x2e33 <do_action+0x843>
    2e62:      	jmp	0x2e28 <do_action+0x838>
    2e64:      	movq	(%rip), %rdi            # 0x2e6b <do_action+0x87b>
    2e6b:      	leaq	0x20(%rsp), %rsi
    2e70:      	leaq	0x44(%rsp), %rdx
    2e75:      	movl	$0x1, %ecx
    2e7a:      	movl	$0x2, %eax
    2e7f:      	callq	*%rax
    2e81:      	testq	%rax, %rax
    2e84:      	je	0x2be2 <do_action+0x5f2>
    2e8a:      	movq	%rax, %r15
    2e8d:      	negl	%eax
    2e8f:      	movw	%ax, (%rsp)
    2e93:      	movw	$0x3, 0x2(%rsp)
    2e9a:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    2ea4:      	movq	%rax, 0x4(%rsp)
    2ea9:      	movq	(%rip), %rdi            # 0x2eb0 <do_action+0x8c0>
    2eb0:      	movq	%rsp, %rsi
    2eb3:      	movl	$0x1, %eax
    2eb8:      	callq	*%rax
    2eba:      	testq	%rax, %rax
    2ebd:      	je	0x31b5 <do_action+0xbc5>
    2ec3:      	incl	(%rax)
    2ec5:      	jmp	0x31d7 <do_action+0xbe7>
    2eca:      	movl	0x10(%r12), %eax
    2ecf:      	movl	%eax, %eax
    2ed1:      	movq	0x50(%rsp), %rcx
    2ed6:      	movq	%rax, 0x10(%rcx)
    2eda:      	movq	0x58(%rsp), %rdi
    2edf:      	addq	$0x18, %rdi
    2ee3:      	movl	$0xc8, %ecx
    2ee8:      	movl	$0x4, %eax
    2eed:      	movq	%rdi, 0x58(%rsp)
    2ef2:      	movl	$0xc8, %esi
    2ef7:      	callq	*%rax
    2ef9:      	xorl	%ebx, %ebx
    2efb:      	movq	%r13, 0x80(%rsp)
    2f03:      	jmp	0x2f13 <do_action+0x923>
    2f05:      	addq	$0x4, %rbx
    2f09:      	cmpq	$0x14, %rbx
    2f0d:      	je	0x3044 <do_action+0xa54>
    2f13:      	movl	$0x0, 0x10(%rsp)
    2f1b:      	movl	$0x1, %eax
    2f20:      	movq	(%rip), %rdi            # 0x2f27 <do_action+0x937>
    2f27:      	leaq	0x10(%rsp), %rsi
    2f2c:      	callq	*%rax
    2f2e:      	testq	%rax, %rax
    2f31:      	je	0x3044 <do_action+0xa54>
    2f37:      	movq	%rax, %rsi
    2f3a:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2f41:      	movl	$0x1, %eax
    2f46:      	movq	(%rip), %rdi            # 0x2f4d <do_action+0x95d>
    2f4d:      	callq	*%rax
    2f4f:      	testq	%rax, %rax
    2f52:      	je	0x3044 <do_action+0xa54>
    2f58:      	cmpl	$-0x1, 0x40(%rax,%rbx)
    2f5d:      	je	0x3044 <do_action+0xa54>
    2f63:      	movq	0x5e78(%r12,%rbx,2), %rax
    2f6b:      	movl	0x4(%r12), %ecx
    2f70:      	cmpq	%rcx, %rax
    2f73:      	jge	0x3044 <do_action+0xa54>
    2f79:      	cmpq	$0x10, %rbx
    2f7d:      	je	0x2fdf <do_action+0x9ef>
    2f7f:      	movl	$0x0, 0x10(%rsp)
    2f87:      	movl	$0x1, %eax
    2f8c:      	movq	(%rip), %rdi            # 0x2f93 <do_action+0x9a3>
    2f93:      	leaq	0x10(%rsp), %rsi
    2f98:      	callq	*%rax
    2f9a:      	testq	%rax, %rax
    2f9d:      	je	0x2fd7 <do_action+0x9e7>
    2f9f:      	movq	%rax, %rsi
    2fa2:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2fa9:      	movl	$0x1, %eax
    2fae:      	movq	(%rip), %rdi            # 0x2fb5 <do_action+0x9c5>
    2fb5:      	callq	*%rax
    2fb7:      	testq	%rax, %rax
    2fba:      	je	0x2fd7 <do_action+0x9e7>
    2fbc:      	cmpl	$-0x1, 0x44(%rax,%rbx)
    2fc1:      	movq	0x5e78(%r12,%rbx,2), %rax
    2fc9:      	je	0x2fdf <do_action+0x9ef>
    2fcb:      	movl	0x5e80(%r12,%rbx,2), %ebp
    2fd3:      	subl	%eax, %ebp
    2fd5:      	jmp	0x2fe9 <do_action+0x9f9>
    2fd7:      	movq	0x5e78(%r12,%rbx,2), %rax
    2fdf:      	movl	0x4(%r12), %ebp
    2fe4:      	subl	%eax, %ebp
    2fe6:      	addl	$0x4, %ebp
    2fe9:      	testl	%ebp, %ebp
    2feb:      	jle	0x2f05 <do_action+0x915>
    2ff1:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2ff6:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    2ffb:      	cmpl	$0x28, %ebp
    2ffe:      	movl	$0x28, %ecx
    3003:      	cmovgel	%ecx, %ebp
    3006:      	movq	%r12, %r13
    3009:      	movzbl	0x68(%rsp), %r12d
    300f:      	movq	0x58(%rsp), %rcx
    3014:      	leaq	(%rcx,%r12), %rdi
    3018:      	leaq	(%rax,%r13), %rdx
    301c:      	addq	$0x90, %rdx
    3023:      	movl	$0x4, %eax
    3028:      	movl	%ebp, %esi
    302a:      	callq	*%rax
    302c:      	addl	%r12d, %ebp
    302f:      	movq	%r13, %r12
    3032:      	movq	0x80(%rsp), %r13
    303a:      	movq	%rbp, 0x68(%rsp)
    303f:      	jmp	0x2f05 <do_action+0x915>
    3044:      	movq	(%rip), %rdi            # 0x304b <do_action+0xa5b>
    304b:      	movl	$0x1, %eax
    3050:      	movq	0x50(%rsp), %rsi
    3055:      	callq	*%rax
    3057:      	testq	%rax, %rax
    305a:      	je	0x307c <do_action+0xa8c>
    305c:      	imulq	$-0xf4240, 0x78(%rsp), %rcx # imm = 0xFFF0BDC0
    3065:      	movq	0x70(%rsp), %rdx
    306a:      	addq	%rcx, %rdx
    306d:      	cmpq	%rdx, (%rax)
    3070:      	jbe	0x307c <do_action+0xa8c>
    3072:      	movq	0x48(%rsp), %rax
    3077:      	movb	$0x0, (%rax)
    307a:      	jmp	0x3096 <do_action+0xaa6>
    307c:      	movq	(%rip), %rdi            # 0x3083 <do_action+0xa93>
    3083:      	xorl	%ecx, %ecx
    3085:      	movq	%rsp, %rdx
    3088:      	movl	$0x2, %eax
    308d:      	movq	0x50(%rsp), %rsi
    3092:      	xorl	%ecx, %ecx
    3094:      	callq	*%rax
    3096:      	leal	0x3(%r14), %eax
    309a:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    30a0:      	movq	0x30(%rsp), %rbx
    30a5:      	je	0x30ca <do_action+0xada>
    30a7:      	orb	$0x2, 0x1(%r12)
    30ad:      	movq	(%rip), %rsi            # 0x30b4 <do_action+0xac4>
    30b4:      	xorl	%ecx, %ecx
    30b6:      	movl	$0x1b, %eax
    30bb:      	movq	%r13, %rdi
    30be:      	xorl	%edx, %edx
    30c0:      	callq	*%rax
    30c2:      	movq	%rax, 0x80(%r12)
    30ca:      	leal	0x4(%r14), %eax
    30ce:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    30d4:      	je	0x30ff <do_action+0xb0f>
    30d6:      	orb	$0x4, 0x1(%r12)
    30dc:      	movq	(%rip), %rsi            # 0x30e3 <do_action+0xaf3>
    30e3:      	movl	$0x100, %ecx            # imm = 0x100
    30e8:      	movl	$0x1b, %eax
    30ed:      	movl	$0x100, %edx            # imm = 0x100
    30f2:      	movq	%r13, %rdi
    30f5:      	callq	*%rax
    30f7:      	movq	%rax, 0x88(%r12)
    30ff:      	addl	$0x5, %r14d
    3103:      	cmpl	$0x0, 0x4(%r15,%r14,4)
    3109:      	je	0x2e28 <do_action+0x838>
    310f:      	orb	$0x8, 0x1(%r12)
    3115:      	jmp	0x2e28 <do_action+0x838>
    311a:      	movq	%r13, %rcx
    311d:      	movq	0x5e78(%r13,%rax,8), %rax
    3125:      	andl	$0x7ff, %eax            # imm = 0x7FF
    312a:      	movq	0x90(%r13,%rax), %rax
    3132:      	shlq	$0x20, %rax
    3136:      	jmp	0x2b69 <do_action+0x579>
    313b:      	movl	$0x1, 0x38(%rsp)
    3143:      	movq	(%rip), %rdi            # 0x314a <do_action+0xb5a>
    314a:      	xorl	%ecx, %ecx
    314c:      	movq	%rsp, %rsi
    314f:      	leaq	0x38(%rsp), %rdx
    3154:      	movl	$0x2, %eax
    3159:      	xorl	%ecx, %ecx
    315b:      	callq	*%rax
    315d:      	testl	%r15d, %r15d
    3160:      	je	0x2a1c <do_action+0x42c>
    3166:      	movq	(%rip), %rdi            # 0x316d <do_action+0xb7d>
    316d:      	leaq	0x10(%rsp), %rsi
    3172:      	movl	$0x1, %eax
    3177:      	callq	*%rax
    3179:      	testq	%rax, %rax
    317c:      	je	0x2a1c <do_action+0x42c>
    3182:      	movl	0x2c(%rsp), %ecx
    3186:      	lock
    3187:      	addl	%ecx, (%rax)
    3189:      	jmp	0x2a1c <do_action+0x42c>
    318e:      	movl	$0x1, 0x20(%rsp)
    3196:      	movq	(%rip), %rdi            # 0x319d <do_action+0xbad>
    319d:      	xorl	%ecx, %ecx
    319f:      	movq	%rsp, %rsi
    31a2:      	leaq	0x20(%rsp), %rdx
    31a7:      	movl	$0x2, %eax
    31ac:      	xorl	%ecx, %ecx
    31ae:      	callq	*%rax
    31b0:      	jmp	0x2bf2 <do_action+0x602>
    31b5:      	movl	$0x1, 0x2c(%rsp)
    31bd:      	movq	(%rip), %rdi            # 0x31c4 <do_action+0xbd4>
    31c4:      	xorl	%ecx, %ecx
    31c6:      	movq	%rsp, %rsi
    31c9:      	leaq	0x2c(%rsp), %rdx
    31ce:      	movl	$0x2, %eax
    31d3:      	xorl	%ecx, %ecx
    31d5:      	callq	*%rax
    31d7:      	testl	%r15d, %r15d
    31da:      	je	0x2be2 <do_action+0x5f2>
    31e0:      	movq	(%rip), %rdi            # 0x31e7 <do_action+0xbf7>
    31e7:      	leaq	0x20(%rsp), %rsi
    31ec:      	movl	$0x1, %eax
    31f1:      	callq	*%rax
    31f3:      	testq	%rax, %rax
    31f6:      	je	0x2be2 <do_action+0x5f2>
    31fc:      	movl	0x44(%rsp), %ecx
    3200:      	lock
    3201:      	addl	%ecx, (%rax)
    3203:      	jmp	0x2be2 <do_action+0x5f2>

Disassembly of section kprobe.multi:

0000000000000000 <generic_kprobe_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x40, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movl	$0x0, 0x1c(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_kprobe_setup_event+0x1b>
      1b:      	leaq	0x1c(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x343 <generic_kprobe_setup_event+0x343>
      30:      	movq	%rax, %r14
      33:      	leaq	0x5ef8(%rax), %rsi
      3a:      	movq	(%rip), %rdi            # 0x41 <generic_kprobe_setup_event+0x41>
      41:      	movl	$0x1, %eax
      46:      	callq	*%rax
      48:      	testq	%rax, %rax
      4b:      	je	0x343 <generic_kprobe_setup_event+0x343>
      51:      	movq	%rax, %r15
      54:      	cmpl	$0x0, 0x54(%rax)
      58:      	je	0x109 <generic_kprobe_setup_event+0x109>
      5e:      	testq	%rbx, %rbx
      61:      	je	0x343 <generic_kprobe_setup_event+0x343>
      67:      	leaq	0x70(%rbx), %rdx
      6b:      	movq	%rsp, %rdi
      6e:      	movl	$0x8, %ecx
      73:      	movl	$0x4, %eax
      78:      	movl	$0x8, %esi
      7d:      	callq	*%rax
      7f:      	movq	(%rsp), %rax
      83:      	movq	%rax, 0x5e50(%r14)
      8a:      	leaq	0x68(%rbx), %rdx
      8e:      	movq	%rsp, %rdi
      91:      	movl	$0x8, %ecx
      96:      	movl	$0x4, %eax
      9b:      	movl	$0x8, %esi
      a0:      	callq	*%rax
      a2:      	movq	(%rsp), %rax
      a6:      	movq	%rax, 0x5e58(%r14)
      ad:      	leaq	0x60(%rbx), %rdx
      b1:      	movq	%rsp, %rdi
      b4:      	movl	$0x8, %ecx
      b9:      	movl	$0x4, %eax
      be:      	movl	$0x8, %esi
      c3:      	callq	*%rax
      c5:      	movq	(%rsp), %rax
      c9:      	movq	%rax, 0x5e60(%r14)
      d0:      	leaq	0x38(%rbx), %rdx
      d4:      	movq	%rsp, %rdi
      d7:      	movl	$0x8, %ecx
      dc:      	movl	$0x4, %eax
      e1:      	movl	$0x8, %esi
      e6:      	callq	*%rax
      e8:      	movq	(%rsp), %rax
      ec:      	movq	%rax, 0x5e68(%r14)
      f3:      	leaq	0x48(%rbx), %rdx
      f7:      	movq	%rsp, %rdi
      fa:      	movl	$0x8, %ecx
      ff:      	movl	$0x4, %eax
     104:      	jmp	0x1a6 <generic_kprobe_setup_event+0x1a6>
     109:      	leaq	0x70(%rbx), %rdx
     10d:      	movq	%rsp, %rdi
     110:      	movl	$0x8, %ecx
     115:      	movl	$0x4, %eax
     11a:      	movl	$0x8, %esi
     11f:      	callq	*%rax
     121:      	movq	(%rsp), %rax
     125:      	movq	%rax, 0x5e50(%r14)
     12c:      	leaq	0x68(%rbx), %rdx
     130:      	movq	%rsp, %rdi
     133:      	movl	$0x8, %ecx
     138:      	movl	$0x4, %eax
     13d:      	movl	$0x8, %esi
     142:      	callq	*%rax
     144:      	movq	(%rsp), %rax
     148:      	movq	%rax, 0x5e58(%r14)
     14f:      	leaq	0x60(%rbx), %rdx
     153:      	movq	%rsp, %rdi
     156:      	movl	$0x8, %ecx
     15b:      	movl	$0x4, %eax
     160:      	movl	$0x8, %esi
     165:      	callq	*%rax
     167:      	movq	(%rsp), %rax
     16b:      	movq	%rax, 0x5e60(%r14)
     172:      	leaq	0x58(%rbx), %rdx
     176:      	movq	%rsp, %rdi
     179:      	movl	$0x8, %ecx
     17e:      	movl	$0x4, %eax
     183:      	movl	$0x8, %esi
     188:      	callq	*%rax
     18a:      	movq	(%rsp), %rax
     18e:      	movq	%rax, 0x5e68(%r14)
     195:      	leaq	0x48(%rbx), %rdx
     199:      	movq	%rsp, %rdi
     19c:      	movl	$0x8, %ecx
     1a1:      	movl	$0x4, %eax
     1a6:      	movl	$0x8, %esi
     1ab:      	callq	*%rax
     1ad:      	movq	(%rsp), %rax
     1b1:      	movq	%rax, 0x5e70(%r14)
     1b8:      	movb	$0xd, (%r14)
     1bc:      	movw	$0x0, 0x2(%r14)
     1c3:      	movl	$0x0, 0x4(%r14)
     1cb:      	movl	$0x7d, %eax
     1d0:      	callq	*%rax
     1d2:      	movq	%rax, 0x8(%r14)
     1d6:      	movq	$0x0, 0x70(%r14)
     1de:      	movl	$0x0, 0x14(%r14)
     1e6:      	movl	$0xe, %eax
     1eb:      	callq	*%rax
     1ed:      	movl	%eax, 0x7c(%r14)
     1f1:      	movl	$0xe, %eax
     1f6:      	callq	*%rax
     1f8:      	cmpq	$-0x16, %rax
     1fc:      	jne	0x21a <generic_kprobe_setup_event+0x21a>
     1fe:      	leaq	0x20(%rbx), %rdx
     202:      	movq	%rsp, %rdi
     205:      	movl	$0x8, %ecx
     20a:      	movl	$0x4, %eax
     20f:      	movl	$0x8, %esi
     214:      	callq	*%rax
     216:      	movq	(%rsp), %rax
     21a:      	movq	%rax, 0x68(%r14)
     21e:      	cmpl	$0x0, 0x5c(%r15)
     223:      	jle	0x2cd <generic_kprobe_setup_event+0x2cd>
     229:      	movq	0x8(%r14), %rcx
     22d:      	movq	0x60(%r14), %rdx
     231:      	movq	%rcx, (%rsp)
     235:      	movq	$0x1, 0x8(%rsp)
     23e:      	movq	$0x0, 0x10(%rsp)
     247:      	movq	%rdx, 0x30(%rsp)
     24c:      	movq	%rax, 0x38(%rsp)
     251:      	movq	(%rip), %rdi            # 0x258 <generic_kprobe_setup_event+0x258>
     258:      	xorl	%ecx, %ecx
     25a:      	leaq	0x30(%rsp), %rsi
     25f:      	movq	%rsp, %rdx
     262:      	movl	$0x2, %eax
     267:      	xorl	%ecx, %ecx
     269:      	callq	*%rax
     26b:      	testq	%rax, %rax
     26e:      	je	0x2cd <generic_kprobe_setup_event+0x2cd>
     270:      	negl	%eax
     272:      	movw	%ax, 0x24(%rsp)
     277:      	movw	$0x5, 0x26(%rsp)
     27e:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     288:      	movq	%rax, 0x28(%rsp)
     28d:      	movq	(%rip), %rdi            # 0x294 <generic_kprobe_setup_event+0x294>
     294:      	leaq	0x24(%rsp), %rsi
     299:      	movl	$0x1, %eax
     29e:      	callq	*%rax
     2a0:      	testq	%rax, %rax
     2a3:      	je	0x2a9 <generic_kprobe_setup_event+0x2a9>
     2a5:      	incl	(%rax)
     2a7:      	jmp	0x2cd <generic_kprobe_setup_event+0x2cd>
     2a9:      	movl	$0x1, 0x20(%rsp)
     2b1:      	movq	(%rip), %rdi            # 0x2b8 <generic_kprobe_setup_event+0x2b8>
     2b8:      	xorl	%ecx, %ecx
     2ba:      	leaq	0x24(%rsp), %rsi
     2bf:      	leaq	0x20(%rsp), %rdx
     2c4:      	movl	$0x2, %eax
     2c9:      	xorl	%ecx, %ecx
     2cb:      	callq	*%rax
     2cd:      	movl	$0x0, (%rsp)
     2d4:      	movq	(%rip), %rdi            # 0x2db <generic_kprobe_setup_event+0x2db>
     2db:      	movq	%rsp, %rsi
     2de:      	movl	$0x1, %eax
     2e3:      	callq	*%rax
     2e5:      	testq	%rax, %rax
     2e8:      	je	0x30d <generic_kprobe_setup_event+0x30d>
     2ea:      	movq	%rax, %rsi
     2ed:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     2f4:      	movq	(%rip), %rdi            # 0x2fb <generic_kprobe_setup_event+0x2fb>
     2fb:      	movl	$0x1, %eax
     300:      	callq	*%rax
     302:      	testq	%rax, %rax
     305:      	je	0x30d <generic_kprobe_setup_event+0x30d>
     307:      	cmpl	$-0x1, 0x40(%rax)
     30b:      	jne	0x328 <generic_kprobe_setup_event+0x328>
     30d:      	movq	(%rip), %rsi            # 0x314 <generic_kprobe_setup_event+0x314>
     314:      	movl	$0x3, %ecx
     319:      	movl	$0xc, %eax
     31e:      	movq	%rbx, %rdi
     321:      	movl	$0x3, %edx
     326:      	callq	*%rax
     328:      	movq	(%rip), %rsi            # 0x32f <generic_kprobe_setup_event+0x32f>
     32f:      	movl	$0x1, %ecx
     334:      	movl	$0xc, %eax
     339:      	movq	%rbx, %rdi
     33c:      	movl	$0x1, %edx
     341:      	callq	*%rax
     343:      	xorl	%eax, %eax
     345:      	addq	$0x40, %rsp
     349:      	popq	%rbx
     34a:      	popq	%r14
     34c:      	popq	%r15
     34e:      	retq
     34f:      	nop

0000000000000350 <generic_kprobe_process_event>:
     350:      	pushq	%rbp
     351:      	pushq	%r15
     353:      	pushq	%r14
     355:      	pushq	%r13
     357:      	pushq	%r12
     359:      	pushq	%rbx
     35a:      	subq	$0x108, %rsp            # imm = 0x108
     361:      	movq	%rdi, %r13
     364:      	movl	$0x0, 0xec(%rsp)
     36f:      	movq	(%rip), %rdi            # 0x376 <generic_kprobe_process_event+0x26>
     376:      	leaq	0xec(%rsp), %rsi
     37e:      	movl	$0x1, %eax
     383:      	callq	*%rax
     385:      	testq	%rax, %rax
     388:      	je	0x2a92 <generic_kprobe_process_event+0x2742>
     38e:      	movq	%rax, %r14
     391:      	movl	0x5efc(%rax), %ebx
     397:      	movl	0x4(%rax), %ebp
     39a:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     3a1:      	ja	0x29f6 <generic_kprobe_process_event+0x26a6>
     3a7:      	movl	$0x0, 0xf0(%rsp)
     3b2:      	movq	(%rip), %rdi            # 0x3b9 <generic_kprobe_process_event+0x69>
     3b9:      	leaq	0xf0(%rsp), %rsi
     3c1:      	movl	$0x1, %eax
     3c6:      	callq	*%rax
     3c8:      	testq	%rax, %rax
     3cb:      	je	0x29f6 <generic_kprobe_process_event+0x26a6>
     3d1:      	movq	%rax, %r15
     3d4:      	leaq	0x5ef8(%rax), %rsi
     3db:      	movq	(%rip), %rdi            # 0x3e2 <generic_kprobe_process_event+0x92>
     3e2:      	movl	$0x1, %eax
     3e7:      	callq	*%rax
     3e9:      	cmpl	$0x4, %ebx
     3ec:      	jg	0x29f6 <generic_kprobe_process_event+0x26a6>
     3f2:      	testq	%rax, %rax
     3f5:      	je	0x29f6 <generic_kprobe_process_event+0x26a6>
     3fb:      	movq	%rbp, 0x18(%rsp)
     400:      	movl	%ebx, %edx
     402:      	andl	$0x7, %edx
     405:      	movl	%edx, %ebp
     407:      	movl	0x4(%rax,%rbp,4), %r12d
     40c:      	movslq	0x18(%rax,%rbp,4), %rsi
     411:      	movl	%esi, %ecx
     413:      	movl	$0x0, 0x5ea0(%r15,%rbp,4)
     41f:      	testl	$0x100, %esi            # imm = 0x100
     425:      	movq	%rdx, (%rsp)
     429:      	movq	%rcx, 0x98(%rsp)
     431:      	movq	%rsi, 0x20(%rsp)
     436:      	jne	0x45a <generic_kprobe_process_event+0x10a>
     438:      	testb	%cl, %cl
     43a:      	js	0x46d <generic_kprobe_process_event+0x11d>
     43c:      	testb	$0x40, %sil
     440:      	jne	0x4d5 <generic_kprobe_process_event+0x185>
     446:      	movl	0x40(%rax,%rdx,4), %ecx
     44a:      	andl	$0x7, %ecx
     44d:      	movq	0x5e50(%r15,%rcx,8), %rsi
     455:      	jmp	0x531 <generic_kprobe_process_event+0x1e1>
     45a:      	movq	$0x0, 0xd8(%rsp)
     466:      	xorl	%esi, %esi
     468:      	jmp	0x623 <generic_kprobe_process_event+0x2d3>
     46d:      	movq	%rbx, 0x38(%rsp)
     472:      	movzbl	0x2c2(%rax,%rdx,4), %ecx
     47a:      	shlb	$0x3, %cl
     47d:      	movb	$0x40, %bl
     47f:      	subb	%cl, %bl
     481:      	cmpl	$0x0, 0x54(%rax)
     485:      	movzwl	0x2c0(%rax,%rdx,4), %edx
     48d:      	je	0x4fb <generic_kprobe_process_event+0x1ab>
     48f:      	testq	%r13, %r13
     492:      	je	0x526 <generic_kprobe_process_event+0x1d6>
     498:      	addq	%r13, %rdx
     49b:      	leaq	0x58(%rsp), %rdi
     4a0:      	movl	$0x8, %ecx
     4a5:      	movq	%r13, 0xc8(%rsp)
     4ad:      	movq	%rax, %r13
     4b0:      	movl	$0x4, %eax
     4b5:      	movl	$0x8, %esi
     4ba:      	callq	*%rax
     4bc:      	movq	%r13, %rax
     4bf:      	movq	0xc8(%rsp), %r13
     4c7:      	shlxq	%rbx, 0x58(%rsp), %rcx
     4ce:      	sarxq	%rbx, %rcx, %rsi
     4d3:      	jmp	0x528 <generic_kprobe_process_event+0x1d8>
     4d5:      	movq	%r14, 0x30(%rsp)
     4da:      	movq	%rbx, %r14
     4dd:      	movq	%rax, %rbx
     4e0:      	movl	$0x23, %eax
     4e5:      	callq	*%rax
     4e7:      	movq	(%rsp), %rdx
     4eb:      	movq	%rax, %rsi
     4ee:      	movq	%rbx, %rax
     4f1:      	movq	%r14, %rbx
     4f4:      	movq	0x30(%rsp), %r14
     4f9:      	jmp	0x531 <generic_kprobe_process_event+0x1e1>
     4fb:      	movzbl	%bl, %ecx
     4fe:      	movq	%r13, %rdi
     501:      	movl	%edx, %esi
     503:      	movl	%ecx, %edx
     505:      	movq	%rax, %rbx
     508:      	callq	0x50d <generic_kprobe_process_event+0x1bd>
     50d:      	movq	%rax, %rsi
     510:      	movq	%rbx, %rax
     513:      	movq	%rsi, 0xd8(%rsp)
     51b:      	movq	0x38(%rsp), %rbx
     520:      	movq	(%rsp), %rdx
     524:      	jmp	0x539 <generic_kprobe_process_event+0x1e9>
     526:      	xorl	%esi, %esi
     528:      	movq	0x38(%rsp), %rbx
     52d:      	movq	(%rsp), %rdx
     531:      	movq	%rsi, 0xd8(%rsp)
     539:      	cmpl	$0x4, %edx
     53c:      	ja	0x623 <generic_kprobe_process_event+0x2d3>
     542:      	leaq	(%rdx,%rdx,4), %rcx
     546:      	shll	$0x4, %ecx
     549:      	cmpw	$0x0, 0x76(%rax,%rcx)
     54f:      	je	0x623 <generic_kprobe_process_event+0x2d3>
     555:      	addq	%rcx, %rax
     558:      	addq	$0x70, %rax
     55c:      	movq	%rax, 0x58(%rsp)
     561:      	leaq	0xd8(%rsp), %rax
     569:      	movq	%rax, 0x60(%rsp)
     56e:      	movb	$0x0, 0x68(%rsp)
     573:      	leaq	(%r15,%rbp,4), %rax
     577:      	addq	$0x5ea0, %rax           # imm = 0x5EA0
     57d:      	movq	%rax, 0x70(%rsp)
     582:      	movq	(%rip), %rax            # 0x589 <generic_kprobe_process_event+0x239>
     589:      	cmpb	$0x0, (%rax)
     58c:      	je	0x5ed <generic_kprobe_process_event+0x29d>
     58e:      	xorl	%r15d, %r15d
     591:      	movl	$0x8, %ebp
     596:      	jmp	0x5b9 <generic_kprobe_process_event+0x269>
     598:      	movl	$0x4, %eax
     59d:      	movq	0x60(%rsp), %rdi
     5a2:      	movq	(%rdi), %rdx
     5a5:      	movl	$0x8, %esi
     5aa:      	callq	*%rax
     5ac:      	testl	%eax, %eax
     5ae:      	js	0x610 <generic_kprobe_process_event+0x2c0>
     5b0:      	incq	%r15
     5b3:      	cmpq	$0xa, %r15
     5b7:      	je	0x61b <generic_kprobe_process_event+0x2cb>
     5b9:      	movq	0x58(%rsp), %rax
     5be:      	cmpw	$0x0, 0x6(%rax,%r15,8)
     5c5:      	je	0x61b <generic_kprobe_process_event+0x2cb>
     5c7:      	movq	0x60(%rsp), %rcx
     5cc:      	movl	(%rax,%r15,8), %edx
     5d0:      	addq	(%rcx), %rdx
     5d3:      	movq	%rdx, (%rcx)
     5d6:      	cmpw	$0x0, 0x4(%rax,%r15,8)
     5dd:      	je	0x5b0 <generic_kprobe_process_event+0x260>
     5df:      	cmpb	$0x0, 0x68(%rsp)
     5e4:      	je	0x598 <generic_kprobe_process_event+0x248>
     5e6:      	movl	$0x94, %eax
     5eb:      	jmp	0x59d <generic_kprobe_process_event+0x24d>
     5ed:      	leaq	(%rip), %rsi            # 0x5f4 <generic_kprobe_process_event+0x2a4>
     5f4:      	xorl	%ecx, %ecx
     5f6:      	leaq	0x58(%rsp), %rdx
     5fb:      	movl	$0xa, %edi
     600:      	movl	$0xb5, %eax
     605:      	movl	$0xa, %edi
     60a:      	xorl	%ecx, %ecx
     60c:      	callq	*%rax
     60e:      	jmp	0x61b <generic_kprobe_process_event+0x2cb>
     610:      	incl	%r15d
     613:      	movq	0x70(%rsp), %rax
     618:      	movl	%r15d, (%rax)
     61b:      	movq	0xd8(%rsp), %rsi
     623:      	movl	$0x1000, %r15d          # imm = 0x1000
     629:      	cmpl	$0x15, %r12d
     62d:      	jg	0x66b <generic_kprobe_process_event+0x31b>
     62f:      	cmpl	$0xb, %r12d
     633:      	movq	0x18(%rsp), %rbp
     638:      	jg	0x6a3 <generic_kprobe_process_event+0x353>
     63a:      	cmpl	$0x5, %r12d
     63e:      	jg	0x72e <generic_kprobe_process_event+0x3de>
     644:      	cmpl	$0x3, %r12d
     648:      	jg	0x7b8 <generic_kprobe_process_event+0x468>
     64e:      	leal	-0x2(%r12), %eax
     653:      	cmpl	$0x2, %eax
     656:      	jb	0x77e <generic_kprobe_process_event+0x42e>
     65c:      	cmpl	$0x1, %r12d
     660:      	je	0x77e <generic_kprobe_process_event+0x42e>
     666:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     66b:      	cmpl	$0x20, %r12d
     66f:      	movq	0x18(%rsp), %rbp
     674:      	jle	0x6ce <generic_kprobe_process_event+0x37e>
     676:      	cmpl	$0x27, %r12d
     67a:      	jg	0x6fb <generic_kprobe_process_event+0x3ab>
     67c:      	leal	-0x21(%r12), %eax
     681:      	cmpl	$0x4, %eax
     684:      	jb	0x7cc <generic_kprobe_process_event+0x47c>
     68a:      	cmpl	$0x25, %r12d
     68e:      	je	0x7ed <generic_kprobe_process_event+0x49d>
     694:      	cmpl	$0x27, %r12d
     698:      	je	0x786 <generic_kprobe_process_event+0x436>
     69e:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     6a3:      	cmpl	$0x11, %r12d
     6a7:      	jg	0x757 <generic_kprobe_process_event+0x407>
     6ad:      	leal	-0xf(%r12), %eax
     6b2:      	cmpl	$0x3, %eax
     6b5:      	jb	0x7ed <generic_kprobe_process_event+0x49d>
     6bb:      	leal	-0xc(%r12), %eax
     6c0:      	cmpl	$0x2, %eax
     6c3:      	jb	0x77e <generic_kprobe_process_event+0x42e>
     6c9:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     6ce:      	cmpl	$0x1a, %r12d
     6d2:      	jg	0x774 <generic_kprobe_process_event+0x424>
     6d8:      	cmpl	$0x16, %r12d
     6dc:      	je	0x786 <generic_kprobe_process_event+0x436>
     6e2:      	cmpl	$0x17, %r12d
     6e6:      	je	0x7cc <generic_kprobe_process_event+0x47c>
     6ec:      	cmpl	$0x1a, %r12d
     6f0:      	je	0x7e2 <generic_kprobe_process_event+0x492>
     6f6:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     6fb:      	cmpl	$0x29, %r12d
     6ff:      	jle	0x7a2 <generic_kprobe_process_event+0x452>
     705:      	cmpl	$0x2a, %r12d
     709:      	je	0x7ed <generic_kprobe_process_event+0x49d>
     70f:      	cmpl	$0x2b, %r12d
     713:      	je	0x7b0 <generic_kprobe_process_event+0x460>
     719:      	cmpl	$0x2c, %r12d
     71d:      	jne	0x7ea <generic_kprobe_process_event+0x49a>
     723:      	movl	$0x70, %r15d
     729:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     72e:      	cmpl	$0x9, %r12d
     732:      	jg	0x7cc <generic_kprobe_process_event+0x47c>
     738:      	cmpl	$0x6, %r12d
     73c:      	je	0x7ed <generic_kprobe_process_event+0x49d>
     742:      	cmpl	$0x7, %r12d
     746:      	je	0x7c4 <generic_kprobe_process_event+0x474>
     748:      	cmpl	$0x8, %r12d
     74c:      	je	0x7e2 <generic_kprobe_process_event+0x492>
     752:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     757:      	cmpl	$0x13, %r12d
     75b:      	jg	0x78e <generic_kprobe_process_event+0x43e>
     75d:      	movq	0x20(%rsp), %r15
     762:      	cmpl	$0x12, %r12d
     766:      	je	0x7ed <generic_kprobe_process_event+0x49d>
     76c:      	cmpl	$0x13, %r12d
     770:      	je	0x7b0 <generic_kprobe_process_event+0x460>
     772:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     774:      	leal	-0x1d(%r12), %eax
     779:      	cmpl	$0x4, %eax
     77c:      	jae	0x7dc <generic_kprobe_process_event+0x48c>
     77e:      	movl	$0x4, %r15d
     784:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     786:      	movl	$0x10, %r15d
     78c:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     78e:      	cmpl	$0x14, %r12d
     792:      	je	0x7d4 <generic_kprobe_process_event+0x484>
     794:      	cmpl	$0x15, %r12d
     798:      	jne	0x7ea <generic_kprobe_process_event+0x49a>
     79a:      	movl	$0x20, %r15d
     7a0:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     7a2:      	cmpl	$0x28, %r12d
     7a6:      	je	0x7b0 <generic_kprobe_process_event+0x460>
     7a8:      	cmpl	$0x29, %r12d
     7ac:      	je	0x7c4 <generic_kprobe_process_event+0x474>
     7ae:      	jmp	0x7ea <generic_kprobe_process_event+0x49a>
     7b0:      	movl	$0x18, %r15d
     7b6:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     7b8:      	cmpl	$0x4, %r12d
     7bc:      	je	0x7cc <generic_kprobe_process_event+0x47c>
     7be:      	cmpl	$0x5, %r12d
     7c2:      	jne	0x7ea <generic_kprobe_process_event+0x49a>
     7c4:      	movl	$0x40, %r15d
     7ca:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     7cc:      	movl	$0x8, %r15d
     7d2:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     7d4:      	movl	$0x98, %r15d
     7da:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     7dc:      	cmpl	$0x1b, %r12d
     7e0:      	jne	0x7ea <generic_kprobe_process_event+0x49a>
     7e2:      	movl	$0x50, %r15d
     7e8:      	jmp	0x7ed <generic_kprobe_process_event+0x49d>
     7ea:      	xorl	%r15d, %r15d
     7ed:      	movq	%rsi, 0x28(%rsp)
     7f2:      	movl	$0x0, 0xf4(%rsp)
     7fd:      	movq	(%rip), %rdi            # 0x804 <generic_kprobe_process_event+0x4b4>
     804:      	leaq	0xf4(%rsp), %rsi
     80c:      	movl	$0x1, %eax
     811:      	callq	*%rax
     813:      	testq	%rax, %rax
     816:      	je	0x29f6 <generic_kprobe_process_event+0x26a6>
     81c:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     821:      	subq	%r15, %rcx
     824:      	cmpq	%rbp, %rcx
     827:      	jbe	0x29f6 <generic_kprobe_process_event+0x26a6>
     82d:      	movq	(%rsp), %rdx
     831:      	movl	0x5ea0(%rax,%rdx,4), %ecx
     838:      	movl	%ecx, 0x90(%rax,%rbp)
     83f:      	leaq	0x4(%rbp), %r15
     843:      	movq	%r15, 0x5e78(%rax,%rdx,8)
     84b:      	movl	$0x4, %edx
     850:      	testl	%ecx, %ecx
     852:      	jne	0x29f2 <generic_kprobe_process_event+0x26a2>
     858:      	movq	%rax, %rbp
     85b:      	addq	$0x90, %rbp
     862:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     869:      	addq	%r15, %rbp
     86c:      	movq	0x28(%rsp), %rdx
     871:      	movq	%rdx, 0x58(%rsp)
     876:      	movq	$0x0, 0xa0(%rsp)
     882:      	cmpl	$0x17, %r12d
     886:      	movq	%rax, 0x10(%rsp)
     88b:      	movq	%r13, 0xc8(%rsp)
     893:      	movq	%rbx, 0x38(%rsp)
     898:      	jle	0x8d5 <generic_kprobe_process_event+0x585>
     89a:      	cmpl	$0x18, %r12d
     89e:      	je	0x8f0 <generic_kprobe_process_event+0x5a0>
     8a0:      	cmpl	$0x25, %r12d
     8a4:      	je	0x92e <generic_kprobe_process_event+0x5de>
     8aa:      	cmpl	$0x2a, %r12d
     8ae:      	jne	0x111c <generic_kprobe_process_event+0xdcc>
     8b4:      	movq	$0x0, 0xf8(%rsp)
     8c0:      	movq	%rdx, 0x100(%rsp)
     8c8:      	leaq	0xf8(%rsp), %rax
     8d0:      	jmp	0x95b <generic_kprobe_process_event+0x60b>
     8d5:      	cmpl	$0xf, %r12d
     8d9:      	je	0x1036 <generic_kprobe_process_event+0xce6>
     8df:      	cmpl	$0x10, %r12d
     8e3:      	jne	0x111c <generic_kprobe_process_event+0xdcc>
     8e9:      	leaq	0x40(%rsp), %r15
     8ee:      	jmp	0x918 <generic_kprobe_process_event+0x5c8>
     8f0:      	leaq	0x40(%rsp), %r15
     8f5:      	movl	$0x8, %ecx
     8fa:      	movl	$0x4, %eax
     8ff:      	movq	0x58(%rsp), %rdx
     904:      	movq	%r15, %rdi
     907:      	movl	$0x8, %esi
     90c:      	callq	*%rax
     90e:      	movq	0x40(%rsp), %rax
     913:      	movq	%rax, 0x58(%rsp)
     918:      	leaq	0x58(%rsp), %rdx
     91d:      	movl	$0x8, %ecx
     922:      	movl	$0x4, %eax
     927:      	leaq	0x40(%rsp), %rdi
     92c:      	jmp	0x94b <generic_kprobe_process_event+0x5fb>
     92e:      	addq	$0x40, %rdx
     932:      	movq	%rdx, 0x58(%rsp)
     937:      	leaq	0x40(%rsp), %rdi
     93c:      	movl	$0x8, %ecx
     941:      	movl	$0x4, %eax
     946:      	movq	0x58(%rsp), %rdx
     94b:      	movl	$0x8, %esi
     950:      	callq	*%rax
     952:      	movq	0x40(%rsp), %rax
     957:      	addq	$0x40, %rax
     95b:      	movq	%rax, 0xb0(%rsp)
     963:      	movl	$0x0, 0xb8(%rsp)
     96e:      	movq	(%rip), %rdi            # 0x975 <generic_kprobe_process_event+0x625>
     975:      	leaq	0xb8(%rsp), %rsi
     97d:      	movl	$0x1, %eax
     982:      	callq	*%rax
     984:      	testq	%rax, %rax
     987:      	je	0xa35 <generic_kprobe_process_event+0x6e5>
     98d:      	movq	%rax, %r12
     990:      	movq	%rbp, 0x8(%rsp)
     995:      	leaq	0x1000(%rax), %rbx
     99c:      	movl	$0x23, %eax
     9a1:      	callq	*%rax
     9a3:      	leaq	0xd50(%rax), %rdx
     9aa:      	leaq	0xe0(%rsp), %rdi
     9b2:      	movl	$0x8, %ecx
     9b7:      	movl	$0x4, %eax
     9bc:      	movl	$0x8, %esi
     9c1:      	callq	*%rax
     9c3:      	movq	0xe0(%rsp), %r13
     9cb:      	movq	0xb0(%rsp), %rax
     9d3:      	leaq	0x8(%rax), %rdx
     9d7:      	leaq	0xd0(%rsp), %rdi
     9df:      	movl	$0x8, %ecx
     9e4:      	movl	$0x4, %eax
     9e9:      	leaq	0x18(%r13), %rcx
     9ed:      	movq	%rcx, 0x98(%rsp)
     9f5:      	movl	$0x8, %esi
     9fa:      	movq	%rdx, 0x28(%rsp)
     9ff:      	callq	*%rax
     a01:      	movq	0xd0(%rsp), %r15
     a09:      	leaq	0x10(%r15), %rdx
     a0d:      	leaq	0x58(%rsp), %rdi
     a12:      	movl	$0x8, %ecx
     a17:      	movl	$0x4, %eax
     a1c:      	movl	$0x8, %esi
     a21:      	callq	*%rax
     a23:      	cmpq	$0x0, 0x58(%rsp)
     a29:      	movl	$0x1000, %ebp           # imm = 0x1000
     a2e:      	je	0xa45 <generic_kprobe_process_event+0x6f5>
     a30:      	movq	%rbx, %rcx
     a33:      	jmp	0xa95 <generic_kprobe_process_event+0x745>
     a35:      	xorl	%r15d, %r15d
     a38:      	movq	0xc8(%rsp), %r13
     a40:      	jmp	0x11ce <generic_kprobe_process_event+0xe7e>
     a45:      	leaq	0x18(%r15), %rdx
     a49:      	leaq	0x58(%rsp), %rdi
     a4e:      	movl	$0x8, %ecx
     a53:      	movl	$0x4, %eax
     a58:      	movl	$0x8, %esi
     a5d:      	callq	*%rax
     a5f:      	cmpq	%r15, 0x58(%rsp)
     a64:      	movq	%rbx, %rcx
     a67:      	je	0xa95 <generic_kprobe_process_event+0x745>
     a69:      	movq	%r12, %rcx
     a6c:      	addq	$0xff6, %rcx            # imm = 0xFF6
     a73:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     a7d:      	movq	%rax, 0xff6(%r12)
     a85:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     a90:      	movl	$0xff6, %ebp            # imm = 0xFF6
     a95:      	movq	$0x0, 0x60(%rsp)
     a9e:      	movq	$0x0, 0x58(%rsp)
     aa7:      	movq	%r12, 0x68(%rsp)
     aac:      	movq	$0x0, 0x70(%rsp)
     ab5:      	movq	$0x0, 0x78(%rsp)
     abe:      	movq	$0x0, 0x80(%rsp)
     aca:      	movq	%rcx, 0x20(%rsp)
     acf:      	movq	%rcx, 0x88(%rsp)
     ad7:      	movl	%ebp, 0x90(%rsp)
     ade:      	movb	$0x0, 0x94(%rsp)
     ae6:      	addq	$0x20, %r13
     aea:      	leaq	0x58(%rsp), %rdi
     aef:      	movl	$0x8, %ecx
     af4:      	movl	$0x4, %eax
     af9:      	leaq	0x60(%rsp), %r12
     afe:      	leaq	0x70(%rsp), %rbx
     b03:      	leaq	0x78(%rsp), %r15
     b08:      	movl	$0x8, %esi
     b0d:      	movq	%r13, %rdx
     b10:      	callq	*%rax
     b12:      	movl	$0x8, %ecx
     b17:      	movl	$0x4, %eax
     b1c:      	movq	0x98(%rsp), %rdx
     b24:      	movq	%r12, %rdi
     b27:      	movl	$0x8, %esi
     b2c:      	callq	*%rax
     b2e:      	movl	$0x8, %ecx
     b33:      	movl	$0x4, %eax
     b38:      	movq	0x28(%rsp), %rdx
     b3d:      	movq	%rbx, %rdi
     b40:      	movl	$0x8, %esi
     b45:      	callq	*%rax
     b47:      	movl	$0x8, %ecx
     b4c:      	movl	$0x4, %eax
     b51:      	movq	0xb0(%rsp), %rdx
     b59:      	movq	%r15, %rdi
     b5c:      	movl	$0x8, %esi
     b61:      	callq	*%rax
     b63:      	movq	0x78(%rsp), %rax
     b68:      	addq	$-0x20, %rax
     b6c:      	movq	%rax, 0x80(%rsp)
     b74:      	movq	(%rip), %rax            # 0xb7b <generic_kprobe_process_event+0x82b>
     b7b:      	cmpb	$0x0, (%rax)
     b7e:      	je	0xd55 <generic_kprobe_process_event+0xa05>
     b84:      	movl	$0x800, %ebp            # imm = 0x800
     b89:      	movl	$0x8, %r15d
     b8f:      	movl	$0x8, %ebx
     b94:      	movq	0x70(%rsp), %r12
     b99:      	movq	0x78(%rsp), %rdx
     b9e:      	movq	0x80(%rsp), %r13
     ba6:      	cmpq	0x58(%rsp), %r12
     bab:      	jne	0xbb8 <generic_kprobe_process_event+0x868>
     bad:      	cmpq	0x60(%rsp), %rdx
     bb2:      	je	0xf1c <generic_kprobe_process_event+0xbcc>
     bb8:      	movl	$0x4, %eax
     bbd:      	leaq	0x50(%rsp), %rdi
     bc2:      	movl	$0x8, %esi
     bc7:      	callq	*%rax
     bc9:      	cmpq	0x50(%rsp), %r12
     bce:      	je	0xcec <generic_kprobe_process_event+0x99c>
     bd4:      	leaq	0x18(%r12), %r15
     bd9:      	movl	$0x4, %eax
     bde:      	leaq	0x40(%rsp), %rdi
     be3:      	movl	$0x8, %esi
     be8:      	movq	%r15, %rdx
     beb:      	callq	*%rax
     bed:      	cmpq	%r12, 0x40(%rsp)
     bf2:      	je	0xcec <generic_kprobe_process_event+0x99c>
     bf8:      	movl	$0x4, %eax
     bfd:      	leaq	0xc0(%rsp), %rdi
     c05:      	movl	$0x8, %esi
     c0a:      	movq	%r15, %rdx
     c0d:      	callq	*%rax
     c0f:      	addq	$0x20, %r12
     c13:      	movl	$0x4, %eax
     c18:      	leaq	0xa0(%rsp), %rdi
     c20:      	movl	$0x10, %ecx
     c25:      	movl	$0x10, %esi
     c2a:      	movq	%r12, %rdx
     c2d:      	callq	*%rax
     c2f:      	movq	0x68(%rsp), %r15
     c34:      	movq	0x88(%rsp), %rax
     c3c:      	movl	0xa4(%rsp), %r12d
     c44:      	subq	%r15, %rax
     c47:      	movl	0x90(%rsp), %r13d
     c4f:      	movl	%r12d, %edx
     c52:      	subl	%r13d, %edx
     c55:      	movl	$0x0, %ecx
     c5a:      	cmovbl	%ecx, %edx
     c5d:      	addq	0xa8(%rsp), %rdx
     c65:      	xorl	%esi, %esi
     c67:      	cmpl	%r12d, %r13d
     c6a:      	seta	%sil
     c6e:      	movl	%r12d, %ecx
     c71:      	cmovbl	%r13d, %ecx
     c75:      	addl	%ecx, %esi
     c77:      	movl	%r13d, %edi
     c7a:      	subl	%esi, %edi
     c7c:      	movl	%edi, 0x90(%rsp)
     c83:      	subq	%rsi, %rax
     c86:      	jb	0xf24 <generic_kprobe_process_event+0xbd4>
     c8c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     c92:      	ja	0xf24 <generic_kprobe_process_event+0xbd4>
     c98:      	cmpl	%r12d, %r13d
     c9b:      	jbe	0xca2 <generic_kprobe_process_event+0x952>
     c9d:      	movb	$0x2f, (%r15,%rax)
     ca2:      	xorl	%edi, %edi
     ca4:      	cmpl	%r12d, %r13d
     ca7:      	seta	%dil
     cab:      	movzbl	%cl, %esi
     cae:      	addq	%rax, %r15
     cb1:      	addq	%r15, %rdi
     cb4:      	movl	$0x4, %eax
     cb9:      	callq	*%rax
     cbb:      	movq	%r15, 0x88(%rsp)
     cc3:      	cmpl	%r12d, %r13d
     cc6:      	jbe	0xf24 <generic_kprobe_process_event+0xbd4>
     ccc:      	movq	0xc0(%rsp), %rax
     cd4:      	movq	%rax, 0x70(%rsp)
     cd9:      	movl	$0x8, %r15d
     cdf:      	decl	%ebp
     ce1:      	jne	0xb94 <generic_kprobe_process_event+0x844>
     ce7:      	jmp	0xf24 <generic_kprobe_process_event+0xbd4>
     cec:      	leaq	0x10(%r13), %rdx
     cf0:      	movl	$0x4, %eax
     cf5:      	leaq	0x40(%rsp), %rdi
     cfa:      	movl	$0x8, %esi
     cff:      	callq	*%rax
     d01:      	movq	0x80(%rsp), %rax
     d09:      	cmpq	0x40(%rsp), %rax
     d0e:      	movl	$0x8, %r15d
     d14:      	je	0xf1c <generic_kprobe_process_event+0xbcc>
     d1a:      	addq	$0x18, %r13
     d1e:      	movl	$0x4, %eax
     d23:      	leaq	0x70(%rsp), %rdi
     d28:      	movl	$0x8, %esi
     d2d:      	movq	%r13, %rdx
     d30:      	callq	*%rax
     d32:      	movq	0x40(%rsp), %rax
     d37:      	movq	%rax, 0x80(%rsp)
     d3f:      	addq	$0x20, %rax
     d43:      	movq	%rax, 0x78(%rsp)
     d48:      	decl	%ebp
     d4a:      	jne	0xb94 <generic_kprobe_process_event+0x844>
     d50:      	jmp	0xf24 <generic_kprobe_process_event+0xbd4>
     d55:      	movl	$0x800, %ebp            # imm = 0x800
     d5a:      	movl	$0x8, %r15d
     d60:      	movl	$0x8, %ebx
     d65:      	movq	0x70(%rsp), %r12
     d6a:      	movq	0x78(%rsp), %rdx
     d6f:      	movq	0x80(%rsp), %r13
     d77:      	cmpq	0x58(%rsp), %r12
     d7c:      	jne	0xd89 <generic_kprobe_process_event+0xa39>
     d7e:      	cmpq	0x60(%rsp), %rdx
     d83:      	je	0xf1c <generic_kprobe_process_event+0xbcc>
     d89:      	movl	$0x4, %eax
     d8e:      	leaq	0x50(%rsp), %rdi
     d93:      	movl	$0x8, %esi
     d98:      	callq	*%rax
     d9a:      	cmpq	0x50(%rsp), %r12
     d9f:      	je	0xeba <generic_kprobe_process_event+0xb6a>
     da5:      	leaq	0x18(%r12), %r15
     daa:      	movl	$0x4, %eax
     daf:      	leaq	0x40(%rsp), %rdi
     db4:      	movl	$0x8, %esi
     db9:      	movq	%r15, %rdx
     dbc:      	callq	*%rax
     dbe:      	cmpq	%r12, 0x40(%rsp)
     dc3:      	je	0xeba <generic_kprobe_process_event+0xb6a>
     dc9:      	movl	$0x4, %eax
     dce:      	leaq	0xc0(%rsp), %rdi
     dd6:      	movl	$0x8, %esi
     ddb:      	movq	%r15, %rdx
     dde:      	callq	*%rax
     de0:      	addq	$0x20, %r12
     de4:      	movl	$0x4, %eax
     de9:      	leaq	0xa0(%rsp), %rdi
     df1:      	movl	$0x10, %ecx
     df6:      	movl	$0x10, %esi
     dfb:      	movq	%r12, %rdx
     dfe:      	callq	*%rax
     e00:      	movq	0x68(%rsp), %r15
     e05:      	movq	0x88(%rsp), %rax
     e0d:      	movl	0xa4(%rsp), %r12d
     e15:      	subq	%r15, %rax
     e18:      	movl	0x90(%rsp), %r13d
     e20:      	movl	%r12d, %edx
     e23:      	subl	%r13d, %edx
     e26:      	movl	$0x0, %ecx
     e2b:      	cmovbl	%ecx, %edx
     e2e:      	addq	0xa8(%rsp), %rdx
     e36:      	xorl	%esi, %esi
     e38:      	cmpl	%r12d, %r13d
     e3b:      	seta	%sil
     e3f:      	movl	%r12d, %ecx
     e42:      	cmovbl	%r13d, %ecx
     e46:      	addl	%ecx, %esi
     e48:      	movl	%r13d, %edi
     e4b:      	subl	%esi, %edi
     e4d:      	movl	%edi, 0x90(%rsp)
     e54:      	subq	%rsi, %rax
     e57:      	jb	0xf24 <generic_kprobe_process_event+0xbd4>
     e5d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     e63:      	ja	0xf24 <generic_kprobe_process_event+0xbd4>
     e69:      	cmpl	%r12d, %r13d
     e6c:      	jbe	0xe73 <generic_kprobe_process_event+0xb23>
     e6e:      	movb	$0x2f, (%r15,%rax)
     e73:      	xorl	%edi, %edi
     e75:      	cmpl	%r12d, %r13d
     e78:      	seta	%dil
     e7c:      	movzbl	%cl, %esi
     e7f:      	addq	%rax, %r15
     e82:      	addq	%r15, %rdi
     e85:      	movl	$0x4, %eax
     e8a:      	callq	*%rax
     e8c:      	movq	%r15, 0x88(%rsp)
     e94:      	cmpl	%r12d, %r13d
     e97:      	jbe	0xf24 <generic_kprobe_process_event+0xbd4>
     e9d:      	movq	0xc0(%rsp), %rax
     ea5:      	movq	%rax, 0x70(%rsp)
     eaa:      	movl	$0x8, %r15d
     eb0:      	decl	%ebp
     eb2:      	jne	0xd65 <generic_kprobe_process_event+0xa15>
     eb8:      	jmp	0xf24 <generic_kprobe_process_event+0xbd4>
     eba:      	leaq	0x10(%r13), %rdx
     ebe:      	movl	$0x4, %eax
     ec3:      	leaq	0x40(%rsp), %rdi
     ec8:      	movl	$0x8, %esi
     ecd:      	callq	*%rax
     ecf:      	movq	0x80(%rsp), %rax
     ed7:      	cmpq	0x40(%rsp), %rax
     edc:      	movl	$0x8, %r15d
     ee2:      	je	0xf1c <generic_kprobe_process_event+0xbcc>
     ee4:      	addq	$0x18, %r13
     ee8:      	movl	$0x4, %eax
     eed:      	leaq	0x70(%rsp), %rdi
     ef2:      	movl	$0x8, %esi
     ef7:      	movq	%r13, %rdx
     efa:      	callq	*%rax
     efc:      	movq	0x40(%rsp), %rax
     f01:      	movq	%rax, 0x80(%rsp)
     f09:      	addq	$0x20, %rax
     f0d:      	movq	%rax, 0x78(%rsp)
     f12:      	decl	%ebp
     f14:      	jne	0xd65 <generic_kprobe_process_event+0xa15>
     f1a:      	jmp	0xf24 <generic_kprobe_process_event+0xbd4>
     f1c:      	movb	$0x1, 0x94(%rsp)
     f24:      	movq	0x88(%rsp), %rax
     f2c:      	movq	0x20(%rsp), %rdx
     f31:      	xorl	%ebp, %ebp
     f33:      	cmpq	%rdx, %rax
     f36:      	je	0xf74 <generic_kprobe_process_event+0xc24>
     f38:      	cmpb	$0x0, 0x94(%rsp)
     f40:      	sete	%cl
     f43:      	movl	0x90(%rsp), %edx
     f4a:      	movl	$0x1000, %r15d          # imm = 0x1000
     f50:      	subl	%edx, %r15d
     f53:      	testl	%edx, %edx
     f55:      	cmovlel	%edx, %r15d
     f59:      	testq	%rax, %rax
     f5c:      	movq	0xc8(%rsp), %r13
     f64:      	je	0x11cb <generic_kprobe_process_event+0xe7b>
     f6a:      	movb	%cl, %bpl
     f6d:      	addl	%ebp, %ebp
     f6f:      	movq	%rax, %rdx
     f72:      	jmp	0xf7f <generic_kprobe_process_event+0xc2f>
     f74:      	xorl	%r15d, %r15d
     f77:      	movq	0xc8(%rsp), %r13
     f7f:      	movq	0x38(%rsp), %rbx
     f84:      	movq	0x8(%rsp), %r12
     f89:      	leaq	0x4(%r12), %rdi
     f8e:      	andl	$0xfff, %r15d           # imm = 0xFFF
     f95:      	movl	$0x4, %eax
     f9a:      	movl	%r15d, %esi
     f9d:      	callq	*%rax
     f9f:      	movl	%r15d, (%r12)
     fa3:      	leaq	0x58(%rsp), %rdi
     fa8:      	movl	$0x8, %ecx
     fad:      	movl	$0x4, %eax
     fb2:      	movq	0x28(%rsp), %rdx
     fb7:      	movl	$0x8, %esi
     fbc:      	callq	*%rax
     fbe:      	movq	0x58(%rsp), %rcx
     fc3:      	addq	$0x30, %rcx
     fc7:      	leaq	0xa0(%rsp), %rdi
     fcf:      	movl	$0x8, %edx
     fd4:      	movl	$0x4, %eax
     fd9:      	movq	0x58(%rsp), %rdx
     fde:      	addq	$0x30, %rdx
     fe2:      	movl	$0x8, %esi
     fe7:      	callq	*%rax
     fe9:      	movq	0xa0(%rsp), %rcx
     ff1:      	leaq	0x40(%rsp), %rdi
     ff6:      	movl	$0x2, %edx
     ffb:      	movl	$0x4, %eax
    1000:      	movq	0xa0(%rsp), %rdx
    1008:      	movl	$0x2, %esi
    100d:      	callq	*%rax
    100f:      	movl	%ebp, 0x4(%r12,%r15)
    1014:      	movzwl	0x40(%rsp), %eax
    1019:      	movw	%ax, 0x8(%r12,%r15)
    101f:      	addl	$0xa, %r15d
    1023:      	movq	0x10(%rsp), %rcx
    1028:      	movq	0x18(%rsp), %rbp
    102d:      	movq	(%rsp), %rsi
    1031:      	jmp	0x29c2 <generic_kprobe_process_event+0x2672>
    1036:      	leaq	0xa0(%rsp), %rdi
    103e:      	leaq	0x58(%rsp), %rdx
    1043:      	movl	$0x8, %ecx
    1048:      	movl	$0x4, %eax
    104d:      	movl	$0x8, %esi
    1052:      	callq	*%rax
    1054:      	movq	0xa0(%rsp), %rax
    105c:      	movq	%rax, 0xb0(%rsp)
    1064:      	testq	%rax, %rax
    1067:      	jne	0x963 <generic_kprobe_process_event+0x613>
    106d:      	movl	$0x0, 0xe0(%rsp)
    1078:      	movq	(%rip), %rdi            # 0x107f <generic_kprobe_process_event+0xd2f>
    107f:      	leaq	0xe0(%rsp), %rsi
    1087:      	movl	$0x1, %eax
    108c:      	callq	*%rax
    108e:      	testq	%rax, %rax
    1091:      	je	0x1352 <generic_kprobe_process_event+0x1002>
    1097:      	movq	%r15, 0xb0(%rsp)
    109f:      	movq	%rbp, 0x8(%rsp)
    10a4:      	xorl	%r15d, %r15d
    10a7:      	cmpl	$0x19, %r12d
    10ab:      	movq	0xc8(%rsp), %r13
    10b3:      	movq	0x18(%rsp), %rbp
    10b8:      	jg	0x1427 <generic_kprobe_process_event+0x10d7>
    10be:      	cmpl	$0x12, %r12d
    10c2:      	jle	0x1598 <generic_kprobe_process_event+0x1248>
    10c8:      	cmpl	$0x14, %r12d
    10cc:      	jle	0x1945 <generic_kprobe_process_event+0x15f5>
    10d2:      	cmpl	$0x15, %r12d
    10d6:      	je	0x2262 <generic_kprobe_process_event+0x1f12>
    10dc:      	cmpl	$0x16, %r12d
    10e0:      	je	0x21d8 <generic_kprobe_process_event+0x1e88>
    10e6:      	cmpl	$0x17, %r12d
    10ea:      	movq	0x10(%rsp), %rcx
    10ef:      	movq	0x38(%rsp), %rbx
    10f4:      	movq	(%rsp), %rsi
    10f8:      	movq	0x28(%rsp), %rdx
    10fd:      	jne	0x29c2 <generic_kprobe_process_event+0x2672>
    1103:      	movq	0x8(%rsp), %rax
    1108:      	movl	$0x0, 0x4(%rax)
    110f:      	movl	%edx, (%rax)
    1111:      	movl	$0x8, %r15d
    1117:      	jmp	0x29c2 <generic_kprobe_process_event+0x2672>
    111c:      	cmpl	$0x2c, %r12d
    1120:      	ja	0x106d <generic_kprobe_process_event+0xd1d>
    1126:      	movl	%r12d, %eax
    1129:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
    1133:      	btq	%rax, %rcx
    1137:      	jae	0x106d <generic_kprobe_process_event+0xd1d>
    113d:      	movq	%rdx, 0x50(%rsp)
    1142:      	movl	$0x0, 0xe0(%rsp)
    114d:      	movq	(%rip), %rdi            # 0x1154 <generic_kprobe_process_event+0xe04>
    1154:      	leaq	0xe0(%rsp), %rsi
    115c:      	movl	$0x1, %eax
    1161:      	callq	*%rax
    1163:      	testq	%rax, %rax
    1166:      	je	0x11dd <generic_kprobe_process_event+0xe8d>
    1168:      	movq	%r15, %r13
    116b:      	movq	%rbp, 0x8(%rsp)
    1170:      	xorl	%r15d, %r15d
    1173:      	cmpl	$0x10, %r12d
    1177:      	movq	0x10(%rsp), %rcx
    117c:      	jle	0x11ef <generic_kprobe_process_event+0xe9f>
    117e:      	cmpl	$0x1e, %r12d
    1182:      	movq	0x18(%rsp), %rbp
    1187:      	jle	0x136c <generic_kprobe_process_event+0x101c>
    118d:      	cmpl	$0x26, %r12d
    1191:      	jg	0x1475 <generic_kprobe_process_event+0x1125>
    1197:      	leal	-0x1f(%r12), %eax
    119c:      	cmpl	$0x2, %eax
    119f:      	jae	0x1a3b <generic_kprobe_process_event+0x16eb>
    11a5:      	leaq	0x50(%rsp), %rdx
    11aa:      	movl	$0x4, %r15d
    11b0:      	movl	$0x1, %ecx
    11b5:      	movl	$0x4, %eax
    11ba:      	movq	0x8(%rsp), %rdi
    11bf:      	movl	$0x1, %esi
    11c4:      	callq	*%rax
    11c6:      	jmp	0x29ac <generic_kprobe_process_event+0x265c>
    11cb:      	xorl	%r15d, %r15d
    11ce:      	movq	0x38(%rsp), %rbx
    11d3:      	movq	0x18(%rsp), %rbp
    11d8:      	jmp	0x29c7 <generic_kprobe_process_event+0x2677>
    11dd:      	xorl	%r15d, %r15d
    11e0:      	movq	0x10(%rsp), %rcx
    11e5:      	movq	0x18(%rsp), %rbp
    11ea:      	jmp	0x29b1 <generic_kprobe_process_event+0x2661>
    11ef:      	cmpl	$0x9, %r12d
    11f3:      	movq	0x18(%rsp), %rbp
    11f8:      	movq	(%rsp), %rsi
    11fc:      	jg	0x13a2 <generic_kprobe_process_event+0x1052>
    1202:      	cmpl	$0x4, %r12d
    1206:      	jle	0x1648 <generic_kprobe_process_event+0x12f8>
    120c:      	cmpl	$0x5, %r12d
    1210:      	je	0x1cc5 <generic_kprobe_process_event+0x1975>
    1216:      	cmpl	$0x6, %r12d
    121a:      	je	0x1404 <generic_kprobe_process_event+0x10b4>
    1220:      	cmpl	$0x7, %r12d
    1224:      	movq	0x10(%rsp), %rcx
    1229:      	movq	(%rsp), %rsi
    122d:      	jne	0x29b5 <generic_kprobe_process_event+0x2665>
    1233:      	movq	%rax, %r13
    1236:      	movq	0x50(%rsp), %r15
    123b:      	movq	0x8(%rsp), %rbp
    1240:      	movq	%r15, 0x28(%rbp)
    1244:      	leaq	0x26(%rbp), %rdi
    1248:      	leaq	0x10(%r15), %rdx
    124c:      	movl	$0x2, %ecx
    1251:      	movl	$0x4, %eax
    1256:      	movl	$0x2, %esi
    125b:      	callq	*%rax
    125d:      	leaq	0x3a(%rbp), %rdi
    1261:      	leaq	0x12(%r15), %rdx
    1265:      	movl	$0x1, %ecx
    126a:      	movl	$0x4, %eax
    126f:      	movl	$0x1, %esi
    1274:      	callq	*%rax
    1276:      	leaq	0x38(%rbp), %rdi
    127a:      	leaq	0x226(%r15), %rdx
    1281:      	movl	$0x2, %ecx
    1286:      	movl	$0x4, %eax
    128b:      	movl	$0x2, %esi
    1290:      	callq	*%rax
    1292:      	leaq	0x24(%rbp), %rdi
    1296:      	leaq	0x224(%r15), %rdx
    129d:      	movl	$0x2, %ecx
    12a2:      	movl	$0x4, %eax
    12a7:      	movl	$0x2, %esi
    12ac:      	callq	*%rax
    12ae:      	leaq	0x30(%rbp), %rdi
    12b2:      	leaq	0x21c(%r15), %rdx
    12b9:      	movl	$0x4, %ecx
    12be:      	movl	$0x4, %eax
    12c3:      	movl	$0x4, %esi
    12c8:      	callq	*%rax
    12ca:      	leaq	0x34(%rbp), %rdi
    12ce:      	leaq	0x218(%r15), %rdx
    12d5:      	movl	$0x4, %ecx
    12da:      	movl	$0x4, %eax
    12df:      	movl	$0x4, %esi
    12e4:      	callq	*%rax
    12e6:      	leaq	0x10(%rbp), %r12
    12ea:      	movq	$0x0, (%rbp)
    12f2:      	movq	$0x0, 0x8(%rbp)
    12fa:      	movq	$0x0, 0x10(%rbp)
    1302:      	movq	$0x0, 0x18(%rbp)
    130a:      	movzwl	0x26(%rbp), %eax
    130e:      	cmpl	$0xa, %eax
    1311:      	je	0x268f <generic_kprobe_process_event+0x233f>
    1317:      	cmpl	$0x2, %eax
    131a:      	jne	0x26bf <generic_kprobe_process_event+0x236f>
    1320:      	leaq	0x4(%r15), %rdx
    1324:      	movl	$0x4, %ecx
    1329:      	movl	$0x4, %eax
    132e:      	movq	%rbp, %rdi
    1331:      	movl	$0x4, %esi
    1336:      	callq	*%rax
    1338:      	movl	$0x4, %ecx
    133d:      	movl	$0x4, %eax
    1342:      	movq	%r12, %rdi
    1345:      	movl	$0x4, %esi
    134a:      	movq	%r15, %rdx
    134d:      	jmp	0x26bd <generic_kprobe_process_event+0x236d>
    1352:      	xorl	%r15d, %r15d
    1355:      	movq	0x10(%rsp), %rcx
    135a:      	movq	0xc8(%rsp), %r13
    1362:      	movq	0x38(%rsp), %rbx
    1367:      	jmp	0x1028 <generic_kprobe_process_event+0xcd8>
    136c:      	cmpl	$0x1c, %r12d
    1370:      	jg	0x1622 <generic_kprobe_process_event+0x12d2>
    1376:      	cmpl	$0x11, %r12d
    137a:      	je	0x1a78 <generic_kprobe_process_event+0x1728>
    1380:      	movq	%rax, 0x28(%rsp)
    1385:      	cmpl	$0x19, %r12d
    1389:      	je	0x1b3c <generic_kprobe_process_event+0x17ec>
    138f:      	cmpl	$0x1c, %r12d
    1393:      	movq	(%rsp), %rsi
    1397:      	je	0x1658 <generic_kprobe_process_event+0x1308>
    139d:      	jmp	0x29b5 <generic_kprobe_process_event+0x2665>
    13a2:      	leal	-0xa(%r12), %eax
    13a7:      	cmpl	$0x2, %eax
    13aa:      	jb	0x1658 <generic_kprobe_process_event+0x1308>
    13b0:      	leal	-0xc(%r12), %eax
    13b5:      	cmpl	$0x2, %eax
    13b8:      	jb	0x1679 <generic_kprobe_process_event+0x1329>
    13be:      	cmpl	$0xe, %r12d
    13c2:      	jne	0x29b5 <generic_kprobe_process_event+0x2665>
    13c8:      	leaq	0x58(%rsp), %rdi
    13cd:      	leaq	0x50(%rsp), %r15
    13d2:      	movl	$0x8, %ecx
    13d7:      	movl	$0x4, %eax
    13dc:      	movl	$0x8, %esi
    13e1:      	movq	%r15, %rdx
    13e4:      	callq	*%rax
    13e6:      	movq	0x58(%rsp), %rcx
    13eb:      	movl	$0x8, %edx
    13f0:      	movl	$0x4, %eax
    13f5:      	movq	0x58(%rsp), %rdx
    13fa:      	movq	%r15, %rdi
    13fd:      	movl	$0x8, %esi
    1402:      	callq	*%rax
    1404:      	movq	0x50(%rsp), %rdx
    1409:      	movq	0x8(%rsp), %r12
    140e:      	leaq	0x4(%r12), %rdi
    1413:      	movl	$0x1001, %ecx           # imm = 0x1001
    1418:      	movl	$0x2d, %eax
    141d:      	movl	$0x1001, %esi           # imm = 0x1001
    1422:      	jmp	0x1ea8 <generic_kprobe_process_event+0x1b58>
    1427:      	cmpl	$0x20, %r12d
    142b:      	movq	0x38(%rsp), %rbx
    1430:      	movq	0x28(%rsp), %r8
    1435:      	jle	0x1818 <generic_kprobe_process_event+0x14c8>
    143b:      	movq	%rax, %rcx
    143e:      	leal	-0x21(%r12), %eax
    1443:      	cmpl	$0x4, %eax
    1446:      	jae	0x16a8 <generic_kprobe_process_event+0x1358>
    144c:      	movl	$0x8, %r15d
    1452:      	movl	$0x8, %ecx
    1457:      	movl	$0x4, %eax
    145c:      	movq	0x8(%rsp), %rdi
    1461:      	movl	$0x8, %esi
    1466:      	movq	%r8, %rdx
    1469:      	callq	*%rax
    146b:      	movq	0x10(%rsp), %rcx
    1470:      	jmp	0x102d <generic_kprobe_process_event+0xcdd>
    1475:      	cmpl	$0x27, %r12d
    1479:      	je	0x1e85 <generic_kprobe_process_event+0x1b35>
    147f:      	cmpl	$0x28, %r12d
    1483:      	je	0x1ec7 <generic_kprobe_process_event+0x1b77>
    1489:      	cmpl	$0x2c, %r12d
    148d:      	movq	(%rsp), %rsi
    1491:      	jne	0x29b5 <generic_kprobe_process_event+0x2665>
    1497:      	movq	0x50(%rsp), %r15
    149c:      	movb	$0x0, 0x58(%rsp)
    14a1:      	movq	0x8(%rsp), %rdi
    14a6:      	movq	$0x0, 0x68(%rdi)
    14ae:      	movq	$0x0, 0x60(%rdi)
    14b6:      	movq	$0x0, 0x58(%rdi)
    14be:      	movq	$0x0, 0x50(%rdi)
    14c6:      	movq	$0x0, 0x48(%rdi)
    14ce:      	movq	$0x0, 0x40(%rdi)
    14d6:      	movq	$0x0, 0x38(%rdi)
    14de:      	movq	$0x0, 0x30(%rdi)
    14e6:      	movq	$0x0, 0x28(%rdi)
    14ee:      	movq	$0x0, 0x20(%rdi)
    14f6:      	movq	$0x0, 0x18(%rdi)
    14fe:      	movq	$0x0, 0x10(%rdi)
    1506:      	movq	$0x0, 0x8(%rdi)
    150e:      	movq	$0x0, (%rdi)
    1515:      	movl	$0x2, %ecx
    151a:      	movl	$0x4, %eax
    151f:      	movl	$0x2, %esi
    1524:      	movq	%r15, %rdx
    1527:      	callq	*%rax
    1529:      	testq	%rax, %rax
    152c:      	js	0x29a6 <generic_kprobe_process_event+0x2656>
    1532:      	leaq	0x2(%r15), %r12
    1536:      	leaq	0x58(%rsp), %rdi
    153b:      	movl	$0x1, %ecx
    1540:      	movl	$0x4, %eax
    1545:      	movl	$0x1, %esi
    154a:      	movq	%r12, %rdx
    154d:      	callq	*%rax
    154f:      	testq	%rax, %rax
    1552:      	js	0x29a6 <generic_kprobe_process_event+0x2656>
    1558:      	movq	0x8(%rsp), %rax
    155d:      	leaq	0x4(%rax), %rdi
    1561:      	cmpb	$0x0, 0x58(%rsp)
    1566:      	sete	0x2(%rax)
    156a:      	je	0x2978 <generic_kprobe_process_event+0x2628>
    1570:      	movl	$0x6c, %ecx
    1575:      	movl	$0x2d, %eax
    157a:      	movl	$0x6c, %esi
    157f:      	movq	%r12, %rdx
    1582:      	callq	*%rax
    1584:      	testl	%eax, %eax
    1586:      	movq	0x18(%rsp), %rbp
    158b:      	js	0x29a6 <generic_kprobe_process_event+0x2656>
    1591:      	decb	%al
    1593:      	jmp	0x299e <generic_kprobe_process_event+0x264e>
    1598:      	cmpl	$0x7, %r12d
    159c:      	jg	0x18e2 <generic_kprobe_process_event+0x1592>
    15a2:      	movq	%rax, %rcx
    15a5:      	cmpl	$0x2, %r12d
    15a9:      	movq	%r14, 0x30(%rsp)
    15ae:      	je	0x1f60 <generic_kprobe_process_event+0x1c10>
    15b4:      	movq	%rcx, 0x20(%rsp)
    15b9:      	cmpl	$0x3, %r12d
    15bd:      	movq	0x10(%rsp), %rcx
    15c2:      	movq	0x38(%rsp), %rbx
    15c7:      	movq	(%rsp), %rsi
    15cb:      	jne	0x29c2 <generic_kprobe_process_event+0x2672>
    15d1:      	movq	%rbx, %r14
    15d4:      	movq	%r13, %rbx
    15d7:      	movq	0x20(%rsp), %rax
    15dc:      	leaq	0x90(%rax), %rbp
    15e3:      	movq	0x98(%rsp), %rax
    15eb:      	andl	$0xf, %eax
    15ee:      	cmpl	$0x2, %eax
    15f1:      	jle	0x2827 <generic_kprobe_process_event+0x24d7>
    15f7:      	cmpl	$0x3, %eax
    15fa:      	je	0x2b89 <generic_kprobe_process_event+0x2839>
    1600:      	cmpl	$0x4, %eax
    1603:      	je	0x2b96 <generic_kprobe_process_event+0x2846>
    1609:      	cmpl	$0x5, %eax
    160c:      	jne	0x2fee <generic_kprobe_process_event+0x2c9e>
    1612:      	movq	0x20(%rsp), %rax
    1617:      	addq	$0x5e70, %rax           # imm = 0x5E70
    161d:      	jmp	0x2bae <generic_kprobe_process_event+0x285e>
    1622:      	leaq	0x50(%rsp), %rdx
    1627:      	movl	$0x4, %r15d
    162d:      	movl	$0x2, %ecx
    1632:      	movl	$0x4, %eax
    1637:      	movq	0x8(%rsp), %rdi
    163c:      	movl	$0x2, %esi
    1641:      	callq	*%rax
    1643:      	jmp	0x29ac <generic_kprobe_process_event+0x265c>
    1648:      	cmpl	$0x1, %r12d
    164c:      	je	0x1679 <generic_kprobe_process_event+0x1329>
    164e:      	cmpl	$0x4, %r12d
    1652:      	jne	0x29b5 <generic_kprobe_process_event+0x2665>
    1658:      	movl	$0x8, %r15d
    165e:      	leaq	0x50(%rsp), %rdx
    1663:      	movl	$0x8, %ecx
    1668:      	movl	$0x4, %eax
    166d:      	movq	0x8(%rsp), %rdi
    1672:      	movl	$0x8, %esi
    1677:      	jmp	0x1698 <generic_kprobe_process_event+0x1348>
    1679:      	leaq	0x50(%rsp), %rdx
    167e:      	movl	$0x4, %r15d
    1684:      	movl	$0x4, %ecx
    1689:      	movl	$0x4, %eax
    168e:      	movq	0x8(%rsp), %rdi
    1693:      	movl	$0x4, %esi
    1698:      	callq	*%rax
    169a:      	movq	(%rsp), %rsi
    169e:      	movq	0x10(%rsp), %rcx
    16a3:      	jmp	0x29b5 <generic_kprobe_process_event+0x2665>
    16a8:      	movq	%rcx, 0x20(%rsp)
    16ad:      	cmpl	$0x2b, %r12d
    16b1:      	je	0x2364 <generic_kprobe_process_event+0x2014>
    16b7:      	cmpl	$0x29, %r12d
    16bb:      	movq	0x10(%rsp), %rcx
    16c0:      	movq	(%rsp), %rsi
    16c4:      	jne	0x29c2 <generic_kprobe_process_event+0x2672>
    16ca:      	movq	%r14, 0x30(%rsp)
    16cf:      	movq	%rbx, %r14
    16d2:      	movq	%r13, %rbx
    16d5:      	movq	%rcx, %r13
    16d8:      	addq	$0x18, %r8
    16dc:      	leaq	0x58(%rsp), %rdi
    16e1:      	movl	$0x4, %r12d
    16e7:      	movl	$0x8, %ecx
    16ec:      	movl	$0x4, %eax
    16f1:      	movl	$0x8, %esi
    16f6:      	movq	%r8, %rdx
    16f9:      	callq	*%rax
    16fb:      	movq	0x58(%rsp), %r15
    1700:      	testq	%r15, %r15
    1703:      	je	0x2b3d <generic_kprobe_process_event+0x27ed>
    1709:      	movq	0x8(%rsp), %rbp
    170e:      	movq	%r15, 0x28(%rbp)
    1712:      	leaq	0x26(%rbp), %rdi
    1716:      	leaq	0x10(%r15), %rdx
    171a:      	movl	$0x2, %ecx
    171f:      	movl	$0x4, %eax
    1724:      	movl	$0x2, %esi
    1729:      	callq	*%rax
    172b:      	leaq	0x3a(%rbp), %rdi
    172f:      	leaq	0x12(%r15), %rdx
    1733:      	movl	$0x1, %ecx
    1738:      	movl	$0x4, %eax
    173d:      	movl	$0x1, %esi
    1742:      	callq	*%rax
    1744:      	leaq	0x38(%rbp), %rdi
    1748:      	leaq	0x226(%r15), %rdx
    174f:      	movl	$0x2, %ecx
    1754:      	movl	$0x4, %eax
    1759:      	movl	$0x2, %esi
    175e:      	callq	*%rax
    1760:      	leaq	0x24(%rbp), %rdi
    1764:      	leaq	0x224(%r15), %rdx
    176b:      	movl	$0x2, %ecx
    1770:      	movl	$0x4, %eax
    1775:      	movl	$0x2, %esi
    177a:      	callq	*%rax
    177c:      	leaq	0x30(%rbp), %rdi
    1780:      	leaq	0x21c(%r15), %rdx
    1787:      	movl	$0x4, %eax
    178c:      	movl	$0x4, %esi
    1791:      	callq	*%rax
    1793:      	leaq	0x34(%rbp), %rdi
    1797:      	leaq	0x218(%r15), %rdx
    179e:      	movl	$0x4, %eax
    17a3:      	movl	$0x4, %esi
    17a8:      	callq	*%rax
    17aa:      	leaq	0x10(%rbp), %r12
    17ae:      	movq	$0x0, (%rbp)
    17b6:      	movq	$0x0, 0x8(%rbp)
    17be:      	movq	$0x0, 0x10(%rbp)
    17c6:      	movq	$0x0, 0x18(%rbp)
    17ce:      	movzwl	0x26(%rbp), %eax
    17d2:      	cmpl	$0xa, %eax
    17d5:      	je	0x2ac4 <generic_kprobe_process_event+0x2774>
    17db:      	cmpl	$0x2, %eax
    17de:      	jne	0x2af6 <generic_kprobe_process_event+0x27a6>
    17e4:      	leaq	0x4(%r15), %rdx
    17e8:      	movl	$0x4, %ecx
    17ed:      	movl	$0x4, %eax
    17f2:      	movq	0x8(%rsp), %rdi
    17f7:      	movl	$0x4, %esi
    17fc:      	callq	*%rax
    17fe:      	movl	$0x4, %ecx
    1803:      	movl	$0x4, %eax
    1808:      	movq	%r12, %rdi
    180b:      	movl	$0x4, %esi
    1810:      	movq	%r15, %rdx
    1813:      	jmp	0x2af4 <generic_kprobe_process_event+0x27a4>
    1818:      	cmpl	$0x1a, %r12d
    181c:      	je	0x2402 <generic_kprobe_process_event+0x20b2>
    1822:      	cmpl	$0x1b, %r12d
    1826:      	movq	0x10(%rsp), %rcx
    182b:      	movq	(%rsp), %rsi
    182f:      	jne	0x29c2 <generic_kprobe_process_event+0x2672>
    1835:      	movq	%rcx, %r12
    1838:      	movq	0x8(%rsp), %rax
    183d:      	movq	$0x0, 0x48(%rax)
    1845:      	movq	$0x0, 0x40(%rax)
    184d:      	movq	$0x0, 0x38(%rax)
    1855:      	movq	$0x0, 0x30(%rax)
    185d:      	movq	$0x0, 0x28(%rax)
    1865:      	movq	$0x0, 0x20(%rax)
    186d:      	movq	$0x0, 0x18(%rax)
    1875:      	movq	$0x0, 0x10(%rax)
    187d:      	movq	$0x0, 0x8(%rax)
    1885:      	movq	$0x0, (%rax)
    188c:      	leaq	0x10(%rax), %rdi
    1890:      	leaq	0x18(%r8), %rdx
    1894:      	movl	$0x3f, %ecx
    1899:      	movl	$0x2d, %eax
    189e:      	movl	$0x3f, %esi
    18a3:      	callq	*%rax
    18a5:      	testq	%rax, %rax
    18a8:      	js	0x296d <generic_kprobe_process_event+0x261d>
    18ae:      	movq	0x8(%rsp), %rdi
    18b3:      	addq	$0x8, %rdi
    18b7:      	movq	0x28(%rsp), %rdx
    18bc:      	addq	$0x348, %rdx            # imm = 0x348
    18c3:      	movl	$0x8, %ecx
    18c8:      	movl	$0x4, %eax
    18cd:      	movl	$0x8, %esi
    18d2:      	callq	*%rax
    18d4:      	movl	$0x50, %r15d
    18da:      	movq	%r12, %rcx
    18dd:      	jmp	0x1028 <generic_kprobe_process_event+0xcd8>
    18e2:      	movq	%r13, %rbx
    18e5:      	cmpl	$0x8, %r12d
    18e9:      	je	0x1fcc <generic_kprobe_process_event+0x1c7c>
    18ef:      	cmpl	$0x12, %r12d
    18f3:      	movq	0x10(%rsp), %rcx
    18f8:      	movq	%rbx, %r13
    18fb:      	movq	0x38(%rsp), %rbx
    1900:      	movq	(%rsp), %rsi
    1904:      	movq	0x28(%rsp), %rdx
    1909:      	jne	0x29c2 <generic_kprobe_process_event+0x2672>
    190f:      	movq	0x98(%rsp), %r12
    1917:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    191e:      	movq	%rbx, %r15
    1921:      	movq	%rcx, %rbx
    1924:      	movl	$0x4, %eax
    1929:      	movq	0x8(%rsp), %rdi
    192e:      	movl	%r12d, %esi
    1931:      	callq	*%rax
    1933:      	movq	(%rsp), %rsi
    1937:      	movq	%rbx, %rcx
    193a:      	movq	%r15, %rbx
    193d:      	movq	%r12, %r15
    1940:      	jmp	0x29c2 <generic_kprobe_process_event+0x2672>
    1945:      	cmpl	$0x13, %r12d
    1949:      	je	0x22f6 <generic_kprobe_process_event+0x1fa6>
    194f:      	cmpl	$0x14, %r12d
    1953:      	movq	0x10(%rsp), %rcx
    1958:      	movq	0x38(%rsp), %rbx
    195d:      	movq	(%rsp), %rsi
    1961:      	movq	0x28(%rsp), %r8
    1966:      	jne	0x29c2 <generic_kprobe_process_event+0x2672>
    196c:      	movq	$0x0, 0x58(%rsp)
    1975:      	leaq	0x110(%r8), %rdx
    197c:      	leaq	0x58(%rsp), %rdi
    1981:      	movl	$0x8, %esi
    1986:      	movl	$0x4, %eax
    198b:      	leaq	0xd8(%r8), %rcx
    1992:      	movq	%rcx, 0x20(%rsp)
    1997:      	movl	$0x8, %esi
    199c:      	movq	%r8, %r15
    199f:      	callq	*%rax
    19a1:      	movq	0x58(%rsp), %rcx
    19a6:      	movl	$0x80, %edx
    19ab:      	movl	$0x2d, %eax
    19b0:      	movq	0x8(%rsp), %r12
    19b5:      	movq	0x58(%rsp), %rdx
    19ba:      	movq	%r12, %rdi
    19bd:      	movl	$0x80, %esi
    19c2:      	callq	*%rax
    19c4:      	leaq	0x90(%r12), %rdi
    19cc:      	movl	$0x4, %ecx
    19d1:      	movl	$0x4, %eax
    19d6:      	movq	0x20(%rsp), %rdx
    19db:      	movl	$0x4, %esi
    19e0:      	callq	*%rax
    19e2:      	leaq	0x80(%r12), %rdi
    19ea:      	leaq	0xe0(%r15), %rdx
    19f1:      	movl	$0x8, %ecx
    19f6:      	movl	$0x4, %eax
    19fb:      	movl	$0x8, %esi
    1a00:      	callq	*%rax
    1a02:      	addq	$0x88, %r12
    1a09:      	addq	$0x118, %r15            # imm = 0x118
    1a10:      	movl	$0x8, %ecx
    1a15:      	movl	$0x4, %eax
    1a1a:      	movq	%r12, %rdi
    1a1d:      	movl	$0x8, %esi
    1a22:      	movq	%r15, %rdx
    1a25:      	callq	*%rax
    1a27:      	movq	(%rsp), %rsi
    1a2b:      	movq	0x10(%rsp), %rcx
    1a30:      	movl	$0x98, %r15d
    1a36:      	jmp	0x29c2 <generic_kprobe_process_event+0x2672>
    1a3b:      	cmpl	$0x26, %r12d
    1a3f:      	movq	(%rsp), %rsi
    1a43:      	jne	0x29b5 <generic_kprobe_process_event+0x2665>
    1a49:      	movq	0x50(%rsp), %rsi
    1a4e:      	movzwl	%si, %edx
    1a51:      	addq	0xc8(%rsp), %rdx
    1a59:      	shrl	$0x10, %esi
    1a5c:      	andl	$0xfff, %esi            # imm = 0xFFF
    1a62:      	movq	0x8(%rsp), %r12
    1a67:      	leaq	0x4(%r12), %rdi
    1a6c:      	incl	%esi
    1a6e:      	movl	$0x2d, %eax
    1a73:      	jmp	0x1ea8 <generic_kprobe_process_event+0x1b58>
    1a78:      	movq	$0x0, 0x60(%rsp)
    1a81:      	movl	$0xe, %eax
    1a86:      	callq	*%rax
    1a88:      	shrq	$0x20, %rax
    1a8c:      	movq	%rax, 0x58(%rsp)
    1a91:      	leaq	0xa0(%rsp), %rdi
    1a99:      	leaq	0x50(%rsp), %rdx
    1a9e:      	movl	$0x4, %ecx
    1aa3:      	movl	$0x4, %eax
    1aa8:      	movl	$0x4, %r13d
    1aae:      	movl	$0x4, %esi
    1ab3:      	callq	*%rax
    1ab5:      	movl	0xa0(%rsp), %eax
    1abc:      	movl	%eax, 0x60(%rsp)
    1ac0:      	movq	(%rip), %rdi            # 0x1ac7 <generic_kprobe_process_event+0x1777>
    1ac7:      	leaq	0x58(%rsp), %rsi
    1acc:      	movl	$0x1, %eax
    1ad1:      	callq	*%rax
    1ad3:      	testq	%rax, %rax
    1ad6:      	je	0x2480 <generic_kprobe_process_event+0x2130>
    1adc:      	movl	(%rax), %r15d
    1adf:      	leaq	0xa0(%rsp), %rdx
    1ae7:      	movq	%rax, %r12
    1aea:      	movl	$0x4, %eax
    1aef:      	movq	0x8(%rsp), %rbp
    1af4:      	movq	%rbp, %rdi
    1af7:      	movl	$0x4, %esi
    1afc:      	callq	*%rax
    1afe:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1b05:      	leaq	0x4(%rbp), %rdi
    1b09:      	leaq	0x4(%r15), %rsi
    1b0d:      	movl	$0x4, %eax
    1b12:      	movq	%r12, %rdx
    1b15:      	callq	*%rax
    1b17:      	leaq	(%r15,%rbp), %rdi
    1b1b:      	addq	$0x8, %rdi
    1b1f:      	leaq	(%r15,%r12), %rdx
    1b23:      	addq	$0x4, %rdx
    1b27:      	movl	$0x4, %eax
    1b2c:      	movl	$0x4, %esi
    1b31:      	callq	*%rax
    1b33:      	addq	$0xc, %r15
    1b37:      	jmp	0x11e0 <generic_kprobe_process_event+0xe90>
    1b3c:      	movq	%r14, 0x30(%rsp)
    1b41:      	movq	0x50(%rsp), %rbx
    1b46:      	leaq	0xb8(%rsp), %rdi
    1b4e:      	movl	$0x1, %ecx
    1b53:      	movl	$0x4, %eax
    1b58:      	movl	$0x1, %esi
    1b5d:      	movq	%rbx, %rdx
    1b60:      	callq	*%rax
    1b62:      	movzbl	0xb8(%rsp), %eax
    1b6a:      	testl	%eax, %eax
    1b6c:      	je	0x248c <generic_kprobe_process_event+0x213c>
    1b72:      	cmpl	$0x1, %eax
    1b75:      	jne	0x2747 <generic_kprobe_process_event+0x23f7>
    1b7b:      	addq	$0x10, %rbx
    1b7f:      	leaq	0xa0(%rsp), %rdi
    1b87:      	movl	$0x8, %r15d
    1b8d:      	movl	$0x8, %ecx
    1b92:      	movl	$0x4, %eax
    1b97:      	movl	$0x8, %esi
    1b9c:      	movq	%rbx, %rdx
    1b9f:      	callq	*%rax
    1ba1:      	movq	0xa0(%rsp), %rdx
    1ba9:      	leaq	0x40(%rsp), %rdi
    1bae:      	movl	$0x8, %ecx
    1bb3:      	movl	$0x4, %eax
    1bb8:      	movl	$0x8, %esi
    1bbd:      	callq	*%rax
    1bbf:      	movq	0xa0(%rsp), %rdx
    1bc7:      	addq	$0x8, %rdx
    1bcb:      	leaq	0xc0(%rsp), %rdi
    1bd3:      	movl	$0x8, %ecx
    1bd8:      	movl	$0x4, %eax
    1bdd:      	movl	$0x8, %esi
    1be2:      	callq	*%rax
    1be4:      	movq	0x40(%rsp), %r14
    1be9:      	movq	0xc0(%rsp), %rbx
    1bf1:      	movq	0x28(%rsp), %rax
    1bf6:      	leaq	(%rax,%r13), %r12
    1bfa:      	addq	$0x90, %r12
    1c01:      	testb	$0x20, 0x20(%rsp)
    1c06:      	je	0x3117 <generic_kprobe_process_event+0x2dc7>
    1c0c:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    1c13:      	jb	0x30eb <generic_kprobe_process_event+0x2d9b>
    1c19:      	movl	$0x1, (%r12)
    1c21:      	movl	$0x0, 0xd0(%rsp)
    1c2c:      	movq	(%rip), %rdi            # 0x1c33 <generic_kprobe_process_event+0x18e3>
    1c33:      	leaq	0xd0(%rsp), %rsi
    1c3b:      	movl	$0x1, %eax
    1c40:      	callq	*%rax
    1c42:      	testq	%rax, %rax
    1c45:      	je	0x3155 <generic_kprobe_process_event+0x2e05>
    1c4b:      	movq	%rax, %r13
    1c4e:      	movl	$0x18, (%rax)
    1c54:      	movl	$0xe, %eax
    1c59:      	callq	*%rax
    1c5b:      	movq	%r13, %r15
    1c5e:      	addq	$0x10, %r15
    1c62:      	movq	%rax, 0x10(%r13)
    1c66:      	cmpq	$-0x16, %rax
    1c6a:      	jne	0x1c96 <generic_kprobe_process_event+0x1946>
    1c6c:      	movq	0xc8(%rsp), %rax
    1c74:      	leaq	0x20(%rax), %rdx
    1c78:      	leaq	0x58(%rsp), %rdi
    1c7d:      	movl	$0x8, %ecx
    1c82:      	movl	$0x4, %eax
    1c87:      	movl	$0x8, %esi
    1c8c:      	callq	*%rax
    1c8e:      	movq	0x58(%rsp), %rax
    1c93:      	movq	%rax, (%r15)
    1c96:      	movl	$0x7d, %eax
    1c9b:      	callq	*%rax
    1c9d:      	movq	%rax, 0x18(%r13)
    1ca1:      	movq	(%r15), %rax
    1ca4:      	movq	0x8(%r15), %rcx
    1ca8:      	movq	%rax, 0x14(%r12)
    1cad:      	movq	%rcx, 0x1c(%r12)
    1cb2:      	movq	0xc8(%rsp), %rdi
    1cba:      	movq	%r13, %rsi
    1cbd:      	movq	%r14, %rdx
    1cc0:      	jmp	0x25b4 <generic_kprobe_process_event+0x2264>
    1cc5:      	movq	0x50(%rsp), %r12
    1cca:      	movq	0x8(%rsp), %r15
    1ccf:      	leaq	0x28(%r15), %rdi
    1cd3:      	leaq	0x98(%r12), %rdx
    1cdb:      	movl	$0x4, %ecx
    1ce0:      	movl	$0x4, %eax
    1ce5:      	movl	$0x4, %esi
    1cea:      	callq	*%rax
    1cec:      	leaq	0x2c(%r15), %rdi
    1cf0:      	leaq	0x70(%r12), %rdx
    1cf5:      	movl	$0x4, %ecx
    1cfa:      	movl	$0x4, %eax
    1cff:      	movl	$0x4, %esi
    1d04:      	callq	*%rax
    1d06:      	leaq	0x30(%r15), %rdi
    1d0a:      	leaq	0x90(%r12), %rdx
    1d12:      	movl	$0x4, %ecx
    1d17:      	movl	$0x4, %eax
    1d1c:      	movl	$0x4, %esi
    1d21:      	callq	*%rax
    1d23:      	leaq	0x34(%r15), %rdi
    1d27:      	leaq	0xa8(%r12), %rdx
    1d2f:      	movl	$0x4, %ecx
    1d34:      	movl	$0x4, %eax
    1d39:      	movl	$0x4, %esi
    1d3e:      	callq	*%rax
    1d40:      	movq	$0x0, 0x58(%rsp)
    1d49:      	leaq	0xc8(%r12), %rdx
    1d51:      	leaq	0x58(%rsp), %rdi
    1d56:      	movl	$0x8, %ecx
    1d5b:      	movl	$0x4, %eax
    1d60:      	movl	$0x8, %esi
    1d65:      	callq	*%rax
    1d67:      	leaq	0xb8(%r12), %rdx
    1d6f:      	leaq	0xc0(%rsp), %rdi
    1d77:      	movl	$0x2, %ecx
    1d7c:      	movl	$0x4, %eax
    1d81:      	movl	$0x2, %esi
    1d86:      	callq	*%rax
    1d88:      	movzwl	0xc0(%rsp), %r15d
    1d91:      	addq	0x58(%rsp), %r15
    1d96:      	leaq	0xbf(%rsp), %rdi
    1d9e:      	movl	$0x1, %ecx
    1da3:      	movl	$0x4, %eax
    1da8:      	movl	$0x1, %esi
    1dad:      	movq	%r15, %rdx
    1db0:      	callq	*%rax
    1db2:      	movzbl	0xbf(%rsp), %eax
    1dba:      	shrl	$0x4, %eax
    1dbd:      	cmpl	$0x6, %eax
    1dc0:      	je	0x25df <generic_kprobe_process_event+0x228f>
    1dc6:      	cmpl	$0x4, %eax
    1dc9:      	jne	0x3b49 <generic_kprobe_process_event+0x37f9>
    1dcf:      	leaq	0x9(%r15), %rdx
    1dd3:      	leaq	0xb8(%rsp), %rdi
    1ddb:      	movl	$0x1, %ecx
    1de0:      	movl	$0x4, %eax
    1de5:      	movl	$0x1, %esi
    1dea:      	callq	*%rax
    1dec:      	movzbl	0xb8(%rsp), %eax
    1df4:      	movq	0x8(%rsp), %rdi
    1df9:      	movw	%ax, 0x24(%rdi)
    1dfd:      	movw	$0x2, 0x26(%rdi)
    1e03:      	leaq	0xc(%r15), %rdx
    1e07:      	movq	$0x0, (%rdi)
    1e0e:      	movq	$0x0, 0x8(%rdi)
    1e16:      	movq	$0x0, 0x10(%rdi)
    1e1e:      	movq	$0x0, 0x18(%rdi)
    1e26:      	movl	$0x4, %ecx
    1e2b:      	movl	$0x4, %eax
    1e30:      	leaq	0x10(%rdi), %r13
    1e34:      	movl	$0x4, %esi
    1e39:      	callq	*%rax
    1e3b:      	addq	$0x10, %r15
    1e3f:      	movl	$0x4, %ecx
    1e44:      	movl	$0x4, %eax
    1e49:      	movq	%r13, %rdi
    1e4c:      	movl	$0x4, %esi
    1e51:      	movq	%r15, %rdx
    1e54:      	callq	*%rax
    1e56:      	leaq	0xb6(%r12), %rdx
    1e5e:      	leaq	0xd0(%rsp), %rdi
    1e66:      	movl	$0x2, %ecx
    1e6b:      	movl	$0x4, %eax
    1e70:      	movl	$0x2, %esi
    1e75:      	callq	*%rax
    1e77:      	movzbl	0xb8(%rsp), %r15d
    1e80:      	jmp	0x39db <generic_kprobe_process_event+0x368b>
    1e85:      	movl	$0x120, %edx            # imm = 0x120
    1e8a:      	addq	0x50(%rsp), %rdx
    1e8f:      	movq	0x8(%rsp), %r12
    1e94:      	leaq	0x4(%r12), %rdi
    1e99:      	movl	$0x11, %ecx
    1e9e:      	movl	$0x2d, %eax
    1ea3:      	movl	$0x11, %esi
    1ea8:      	callq	*%rax
    1eaa:      	movq	%rax, %r15
    1ead:      	testq	%rax, %rax
    1eb0:      	js	0x29ac <generic_kprobe_process_event+0x265c>
    1eb6:      	leal	-0x1(%r15), %eax
    1eba:      	movl	%eax, (%r12)
    1ebe:      	addq	$0x3, %r15
    1ec2:      	jmp	0x29ac <generic_kprobe_process_event+0x265c>
    1ec7:      	movq	0x50(%rsp), %r15
    1ecc:      	movq	0x8(%rsp), %r12
    1ed1:      	movq	$0x0, 0x10(%r12)
    1eda:      	movq	$0x0, 0x8(%r12)
    1ee3:      	movq	$0x0, (%r12)
    1eeb:      	movl	$0x2, %ecx
    1ef0:      	movl	$0x4, %eax
    1ef5:      	movq	%r12, %rdi
    1ef8:      	movl	$0x2, %esi
    1efd:      	movq	%r15, %rdx
    1f00:      	callq	*%rax
    1f02:      	testq	%rax, %rax
    1f05:      	js	0x2899 <generic_kprobe_process_event+0x2549>
    1f0b:      	movzwl	(%r12), %eax
    1f10:      	cmpl	$0xa, %eax
    1f13:      	je	0x2849 <generic_kprobe_process_event+0x24f9>
    1f19:      	cmpl	$0x2, %eax
    1f1c:      	jne	0x2885 <generic_kprobe_process_event+0x2535>
    1f22:      	leaq	0x4(%r15), %rdx
    1f26:      	leaq	0x58(%rsp), %rdi
    1f2b:      	movl	$0x4, %ecx
    1f30:      	movl	$0x4, %eax
    1f35:      	movl	$0x4, %esi
    1f3a:      	callq	*%rax
    1f3c:      	movl	0x58(%rsp), %eax
    1f40:      	movq	0x8(%rsp), %rcx
    1f45:      	movq	%rax, 0x8(%rcx)
    1f49:      	leaq	0x2(%rcx), %rdi
    1f4d:      	addq	$0x2, %r15
    1f51:      	movl	$0x2, %ecx
    1f56:      	movl	$0x4, %eax
    1f5b:      	jmp	0x287b <generic_kprobe_process_event+0x252b>
    1f60:      	movq	%r13, %r14
    1f63:      	movq	0xb0(%rsp), %rax
    1f6b:      	movq	%rcx, %r13
    1f6e:      	leaq	(%rcx,%rax), %rbx
    1f72:      	addq	$0x90, %rbx
    1f79:      	movq	$0x0, 0x50(%rsp)
    1f82:      	testb	$0x10, 0x20(%rsp)
    1f87:      	jne	0x2763 <generic_kprobe_process_event+0x2413>
    1f8d:      	movq	0x20(%rsp), %rdx
    1f92:      	movl	%edx, %ebp
    1f94:      	andl	$0xf, %edx
    1f97:      	xorl	%eax, %eax
    1f99:      	movq	%rdx, %rcx
    1f9c:      	cmpl	$0x2, %edx
    1f9f:      	jle	0x2aa6 <generic_kprobe_process_event+0x2756>
    1fa5:      	cmpl	$0x3, %ecx
    1fa8:      	je	0x32a6 <generic_kprobe_process_event+0x2f56>
    1fae:      	cmpl	$0x4, %ecx
    1fb1:      	je	0x32af <generic_kprobe_process_event+0x2f5f>
    1fb7:      	cmpl	$0x5, %ecx
    1fba:      	jne	0x32c2 <generic_kprobe_process_event+0x2f72>
    1fc0:      	leaq	0x5e70(%r13), %rax
    1fc7:      	jmp	0x32bf <generic_kprobe_process_event+0x2f6f>
    1fcc:      	movq	0x8(%rsp), %r15
    1fd1:      	leaq	0x28(%r15), %r13
    1fd5:      	leaq	0x40(%r15), %rax
    1fd9:      	movq	%rax, 0x20(%rsp)
    1fde:      	movq	0x28(%rsp), %r12
    1fe3:      	leaq	0x8(%r12), %rdx
    1fe8:      	movl	$0x4, %ecx
    1fed:      	movl	$0x4, %eax
    1ff2:      	movq	%r15, %rdi
    1ff5:      	movl	$0x4, %esi
    1ffa:      	callq	*%rax
    1ffc:      	leaq	0x4(%r15), %rdi
    2000:      	leaq	0xc(%r12), %rdx
    2005:      	movl	$0x4, %ecx
    200a:      	movl	$0x4, %eax
    200f:      	movl	$0x4, %esi
    2014:      	callq	*%rax
    2016:      	leaq	0x10(%r15), %rdi
    201a:      	leaq	0x18(%r12), %rdx
    201f:      	movl	$0x4, %ecx
    2024:      	movl	$0x4, %eax
    2029:      	movl	$0x4, %esi
    202e:      	callq	*%rax
    2030:      	leaq	0x14(%r15), %rdi
    2034:      	leaq	0x1c(%r12), %rdx
    2039:      	movl	$0x4, %ecx
    203e:      	movl	$0x4, %eax
    2043:      	movl	$0x4, %esi
    2048:      	callq	*%rax
    204a:      	leaq	0x8(%r15), %rdi
    204e:      	leaq	0x10(%r12), %rdx
    2053:      	movl	$0x4, %ecx
    2058:      	movl	$0x4, %eax
    205d:      	movl	$0x4, %esi
    2062:      	callq	*%rax
    2064:      	leaq	0xc(%r15), %rdi
    2068:      	leaq	0x14(%r12), %rdx
    206d:      	movl	$0x4, %ecx
    2072:      	movl	$0x4, %eax
    2077:      	movl	$0x4, %esi
    207c:      	callq	*%rax
    207e:      	leaq	0x18(%r15), %rdi
    2082:      	leaq	0x20(%r12), %rdx
    2087:      	movl	$0x4, %ecx
    208c:      	movl	$0x4, %eax
    2091:      	movl	$0x4, %esi
    2096:      	callq	*%rax
    2098:      	leaq	0x1c(%r15), %rdi
    209c:      	leaq	0x24(%r12), %rdx
    20a1:      	movl	$0x4, %ecx
    20a6:      	movl	$0x4, %eax
    20ab:      	movl	$0x4, %esi
    20b0:      	callq	*%rax
    20b2:      	movl	$0x0, 0x24(%r15)
    20ba:      	leaq	0x20(%r15), %rdi
    20be:      	leaq	0x28(%r12), %rdx
    20c3:      	movl	$0x4, %ecx
    20c8:      	movl	$0x4, %eax
    20cd:      	movl	$0x4, %esi
    20d2:      	callq	*%rax
    20d4:      	leaq	0x30(%r15), %rdi
    20d8:      	leaq	0x40(%r12), %rdx
    20dd:      	movl	$0x8, %ecx
    20e2:      	movl	$0x4, %eax
    20e7:      	movl	$0x8, %esi
    20ec:      	callq	*%rax
    20ee:      	leaq	0x38(%r15), %rdi
    20f2:      	leaq	0x30(%r12), %rdx
    20f7:      	movl	$0x8, %ecx
    20fc:      	movl	$0x4, %eax
    2101:      	movl	$0x8, %esi
    2106:      	callq	*%rax
    2108:      	leaq	0x38(%r12), %rdx
    210d:      	movl	$0x8, %ecx
    2112:      	movl	$0x4, %eax
    2117:      	movq	%r13, %rdi
    211a:      	movl	$0x8, %esi
    211f:      	callq	*%rax
    2121:      	addq	$0x90, %r12
    2128:      	leaq	0x58(%rsp), %rdi
    212d:      	movl	$0x8, %ecx
    2132:      	movl	$0x4, %eax
    2137:      	movl	$0x8, %esi
    213c:      	movq	%r12, %rdx
    213f:      	callq	*%rax
    2141:      	movq	0x58(%rsp), %r12
    2146:      	leaq	0xc8(%r12), %rdx
    214e:      	movl	$0x4, %ecx
    2153:      	movl	$0x4, %eax
    2158:      	movq	0x20(%rsp), %rdi
    215d:      	movl	$0x4, %esi
    2162:      	callq	*%rax
    2164:      	leaq	0x44(%r15), %rdi
    2168:      	leaq	0xcc(%r12), %rdx
    2170:      	movl	$0x4, %ecx
    2175:      	movl	$0x4, %eax
    217a:      	movl	$0x4, %esi
    217f:      	callq	*%rax
    2181:      	leaq	0x48(%r15), %rdi
    2185:      	leaq	0xd0(%r12), %rdx
    218d:      	movl	$0x4, %ecx
    2192:      	movl	$0x4, %eax
    2197:      	movl	$0x4, %esi
    219c:      	callq	*%rax
    219e:      	addq	$0x4c, %r15
    21a2:      	addq	$0x158, %r12            # imm = 0x158
    21a9:      	movl	$0x4, %ecx
    21ae:      	movl	$0x4, %eax
    21b3:      	movq	%r15, %rdi
    21b6:      	movl	$0x4, %esi
    21bb:      	movq	%r12, %rdx
    21be:      	callq	*%rax
    21c0:      	movl	$0x50, %r15d
    21c6:      	movq	0x10(%rsp), %rcx
    21cb:      	movq	%rbx, %r13
    21ce:      	movq	0x38(%rsp), %rbx
    21d3:      	jmp	0x102d <generic_kprobe_process_event+0xcdd>
    21d8:      	movq	0x28(%rsp), %r15
    21dd:      	leaq	0xc8(%r15), %rdx
    21e4:      	movl	$0x4, %ecx
    21e9:      	movl	$0x4, %eax
    21ee:      	movq	0x8(%rsp), %rbx
    21f3:      	movq	%rbx, %rdi
    21f6:      	movl	$0x4, %esi
    21fb:      	callq	*%rax
    21fd:      	leaq	0x4(%rbx), %rdi
    2201:      	leaq	0xcc(%r15), %rdx
    2208:      	movl	$0x4, %ecx
    220d:      	movl	$0x4, %eax
    2212:      	movl	$0x4, %esi
    2217:      	callq	*%rax
    2219:      	leaq	0x8(%rbx), %rdi
    221d:      	leaq	0xd0(%r15), %rdx
    2224:      	movl	$0x4, %ecx
    2229:      	movl	$0x4, %eax
    222e:      	movl	$0x4, %esi
    2233:      	callq	*%rax
    2235:      	addq	$0xc, %rbx
    2239:      	addq	$0x158, %r15            # imm = 0x158
    2240:      	movl	$0x4, %ecx
    2245:      	movl	$0x4, %eax
    224a:      	movq	%rbx, %rdi
    224d:      	movl	$0x4, %esi
    2252:      	movq	%r15, %rdx
    2255:      	callq	*%rax
    2257:      	movl	$0x10, %r15d
    225d:      	jmp	0x2355 <generic_kprobe_process_event+0x2005>
    2262:      	movq	0x28(%rsp), %r15
    2267:      	leaq	0x38(%r15), %rdx
    226b:      	movl	$0x4, %ecx
    2270:      	movl	$0x4, %eax
    2275:      	movq	0x8(%rsp), %rbx
    227a:      	movq	%rbx, %rdi
    227d:      	movl	$0x4, %esi
    2282:      	callq	*%rax
    2284:      	leaq	0x4(%rbx), %rdi
    2288:      	leaq	0x3c(%r15), %rdx
    228c:      	movl	$0x4, %ecx
    2291:      	movl	$0x4, %eax
    2296:      	movl	$0x4, %esi
    229b:      	callq	*%rax
    229d:      	leaq	0x8(%rbx), %rdi
    22a1:      	leaq	0x40(%r15), %rdx
    22a5:      	movl	$0x4, %ecx
    22aa:      	movl	$0x4, %eax
    22af:      	movl	$0x4, %esi
    22b4:      	callq	*%rax
    22b6:      	leaq	0xc(%rbx), %rdi
    22ba:      	leaq	0x44(%r15), %rdx
    22be:      	movl	$0x4, %ecx
    22c3:      	movl	$0x4, %eax
    22c8:      	movl	$0x4, %esi
    22cd:      	callq	*%rax
    22cf:      	addq	$0x10, %rbx
    22d3:      	subq	$-0x80, %r15
    22d7:      	movl	$0x10, %ecx
    22dc:      	movl	$0x4, %eax
    22e1:      	movq	%rbx, %rdi
    22e4:      	movl	$0x10, %esi
    22e9:      	movq	%r15, %rdx
    22ec:      	callq	*%rax
    22ee:      	movl	$0x20, %r15d
    22f4:      	jmp	0x2355 <generic_kprobe_process_event+0x2005>
    22f6:      	movl	$0x4, %ecx
    22fb:      	movl	$0x4, %eax
    2300:      	movq	0x8(%rsp), %rbx
    2305:      	movq	0x28(%rsp), %r15
    230a:      	movq	%rbx, %rdi
    230d:      	movl	$0x4, %esi
    2312:      	movq	%r15, %rdx
    2315:      	callq	*%rax
    2317:      	leaq	0x4(%rbx), %rdi
    231b:      	leaq	0x4(%r15), %rdx
    231f:      	movl	$0x4, %ecx
    2324:      	movl	$0x4, %eax
    2329:      	movl	$0x4, %esi
    232e:      	callq	*%rax
    2330:      	addq	$0x8, %rbx
    2334:      	addq	$0x30, %r15
    2338:      	movl	$0x10, %ecx
    233d:      	movl	$0x4, %eax
    2342:      	movq	%rbx, %rdi
    2345:      	movl	$0x10, %esi
    234a:      	movq	%r15, %rdx
    234d:      	callq	*%rax
    234f:      	movl	$0x18, %r15d
    2355:      	movq	0x10(%rsp), %rcx
    235a:      	movq	0x38(%rsp), %rbx
    235f:      	jmp	0x102d <generic_kprobe_process_event+0xcdd>
    2364:      	leaq	0x4(%r8), %rdx
    2368:      	leaq	0x58(%rsp), %rdi
    236d:      	movl	$0x4, %ecx
    2372:      	movl	$0x4, %eax
    2377:      	movl	$0x4, %esi
    237c:      	movq	%r8, %r12
    237f:      	callq	*%rax
    2381:      	movl	0x58(%rsp), %eax
    2385:      	movq	0x8(%rsp), %r15
    238a:      	movl	%eax, (%r15)
    238d:      	leaq	0xc(%r12), %rdx
    2392:      	leaq	0x58(%rsp), %rdi
    2397:      	movl	$0x4, %ecx
    239c:      	movl	$0x4, %eax
    23a1:      	movl	$0x4, %esi
    23a6:      	callq	*%rax
    23a8:      	movl	0x58(%rsp), %eax
    23ac:      	movl	%eax, 0x4(%r15)
    23b0:      	addq	$0x50, %r12
    23b4:      	leaq	0x58(%rsp), %rdi
    23b9:      	movl	$0x8, %ecx
    23be:      	movl	$0x2d, %eax
    23c3:      	movl	$0x8, %esi
    23c8:      	movq	%r12, %rdx
    23cb:      	callq	*%rax
    23cd:      	addq	$0x8, %r15
    23d1:      	movl	$0x3f8, %edx            # imm = 0x3F8
    23d6:      	movq	0x58(%rsp), %rcx
    23db:      	addq	%rdx, %rcx
    23de:      	movl	$0x10, %esi
    23e3:      	movl	$0x2d, %eax
    23e8:      	addq	0x58(%rsp), %rdx
    23ed:      	movq	%r15, %rdi
    23f0:      	movl	$0x10, %esi
    23f5:      	callq	*%rax
    23f7:      	movl	$0x18, %r15d
    23fd:      	jmp	0x146b <generic_kprobe_process_event+0x111b>
    2402:      	movq	0x8(%rsp), %rax
    2407:      	movq	$0x0, 0x48(%rax)
    240f:      	movq	$0x0, 0x40(%rax)
    2417:      	movq	$0x0, 0x38(%rax)
    241f:      	movq	$0x0, 0x30(%rax)
    2427:      	movq	$0x0, 0x28(%rax)
    242f:      	movq	$0x0, 0x20(%rax)
    2437:      	movq	$0x0, 0x18(%rax)
    243f:      	movq	$0x0, 0x10(%rax)
    2447:      	movq	$0x0, 0x8(%rax)
    244f:      	movq	$0x0, (%rax)
    2456:      	leaq	0x58(%rsp), %rdi
    245b:      	movl	$0x8, %ecx
    2460:      	movl	$0x4, %eax
    2465:      	movl	$0x8, %esi
    246a:      	movq	%r8, %rdx
    246d:      	callq	*%rax
    246f:      	testq	%rax, %rax
    2472:      	je	0x28a4 <generic_kprobe_process_event+0x2554>
    2478:      	xorl	%r15d, %r15d
    247b:      	jmp	0x1023 <generic_kprobe_process_event+0xcd3>
    2480:      	movq	$-0x1, %r15
    2487:      	jmp	0x11e0 <generic_kprobe_process_event+0xe90>
    248c:      	leaq	0x10(%rbx), %rdx
    2490:      	leaq	0x40(%rsp), %rdi
    2495:      	movl	$0x8, %r14d
    249b:      	movl	$0x8, %ecx
    24a0:      	movl	$0x4, %eax
    24a5:      	movl	$0x8, %esi
    24aa:      	callq	*%rax
    24ac:      	addq	$0x18, %rbx
    24b0:      	leaq	0xc0(%rsp), %rdi
    24b8:      	movl	$0x8, %ecx
    24bd:      	movl	$0x4, %eax
    24c2:      	movl	$0x8, %esi
    24c7:      	movq	%rbx, %rdx
    24ca:      	callq	*%rax
    24cc:      	movq	0x40(%rsp), %rax
    24d1:      	movq	%rax, 0x20(%rsp)
    24d6:      	movq	0xc0(%rsp), %rbx
    24de:      	movq	0x28(%rsp), %rax
    24e3:      	leaq	(%rax,%r13), %r12
    24e7:      	addq	$0x90, %r12
    24ee:      	testb	$0x20, 0x98(%rsp)
    24f6:      	je	0x318c <generic_kprobe_process_event+0x2e3c>
    24fc:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    2503:      	jb	0x3160 <generic_kprobe_process_event+0x2e10>
    2509:      	movl	$0x1, (%r12)
    2511:      	movl	$0x0, 0xd0(%rsp)
    251c:      	movq	(%rip), %rdi            # 0x2523 <generic_kprobe_process_event+0x21d3>
    2523:      	leaq	0xd0(%rsp), %rsi
    252b:      	movl	$0x1, %eax
    2530:      	callq	*%rax
    2532:      	testq	%rax, %rax
    2535:      	je	0x3155 <generic_kprobe_process_event+0x2e05>
    253b:      	movq	%rax, %r15
    253e:      	movl	$0x18, (%rax)
    2544:      	movl	$0xe, %eax
    2549:      	callq	*%rax
    254b:      	movq	%r15, %r13
    254e:      	addq	$0x10, %r13
    2552:      	movq	%rax, 0x10(%r15)
    2556:      	cmpq	$-0x16, %rax
    255a:      	jne	0x2587 <generic_kprobe_process_event+0x2237>
    255c:      	movq	0xc8(%rsp), %rax
    2564:      	leaq	0x20(%rax), %rdx
    2568:      	leaq	0x58(%rsp), %rdi
    256d:      	movl	$0x8, %ecx
    2572:      	movl	$0x4, %eax
    2577:      	movl	$0x8, %esi
    257c:      	callq	*%rax
    257e:      	movq	0x58(%rsp), %rax
    2583:      	movq	%rax, (%r13)
    2587:      	movl	$0x7d, %eax
    258c:      	callq	*%rax
    258e:      	movq	%rax, 0x18(%r15)
    2592:      	movq	(%r13), %rax
    2596:      	movq	0x8(%r13), %rcx
    259a:      	movq	%rax, 0x14(%r12)
    259f:      	movq	%rcx, 0x1c(%r12)
    25a4:      	movq	0xc8(%rsp), %rdi
    25ac:      	movq	%r15, %rsi
    25af:      	movq	0x20(%rsp), %rdx
    25b4:      	movq	%rbx, %rcx
    25b7:      	callq	0x25bc <generic_kprobe_process_event+0x226c>
    25bc:      	testl	%eax, %eax
    25be:      	js	0x3436 <generic_kprobe_process_event+0x30e6>
    25c4:      	movq	$0x0, 0x4(%r12)
    25cd:      	movl	%ebx, %edx
    25cf:      	subl	%eax, %edx
    25d1:      	xorl	%ecx, %ecx
    25d3:      	cmpq	$-0x1, %rbx
    25d7:      	cmovnel	%edx, %ecx
    25da:      	jmp	0x3448 <generic_kprobe_process_event+0x30f8>
    25df:      	movq	0x58(%rsp), %rcx
    25e4:      	movl	$0x0, 0xa0(%rsp)
    25ef:      	movzwl	0xc0(%rsp), %r15d
    25f8:      	movq	(%rip), %rdi            # 0x25ff <generic_kprobe_process_event+0x22af>
    25ff:      	leaq	0xa0(%rsp), %rsi
    2607:      	movl	$0x1, %eax
    260c:      	movq	%rcx, 0x28(%rsp)
    2611:      	leaq	(%rcx,%r15), %r13
    2615:      	callq	*%rax
    2617:      	testq	%rax, %rax
    261a:      	je	0x3989 <generic_kprobe_process_event+0x3639>
    2620:      	movq	%rax, %rbp
    2623:      	movw	%r15w, (%rax)
    2627:      	movb	$-0x1, 0x5(%rax)
    262b:      	movb	$0x0, 0x7(%rax)
    262f:      	movq	%rax, %rdi
    2632:      	addq	$0x6, %rdi
    2636:      	leaq	0x6(%r13), %rdx
    263a:      	movl	$0x1, %ecx
    263f:      	movl	$0x4, %eax
    2644:      	movq	%rdi, 0x20(%rsp)
    2649:      	movl	$0x1, %esi
    264e:      	callq	*%rax
    2650:      	testq	%rax, %rax
    2653:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    2659:      	movzbl	0x5(%rbp), %eax
    265d:      	cmpl	$0x32, %eax
    2660:      	jg	0x31da <generic_kprobe_process_event+0x2e8a>
    2666:      	testl	%eax, %eax
    2668:      	je	0x3296 <generic_kprobe_process_event+0x2f46>
    266e:      	cmpl	$0x2b, %eax
    2671:      	je	0x3296 <generic_kprobe_process_event+0x2f46>
    2677:      	cmpl	$0x2c, %eax
    267a:      	jne	0x353e <generic_kprobe_process_event+0x31ee>
    2680:      	movw	$0x8, 0x2(%rbp)
    2686:      	movw	$0x8, %ax
    268a:      	jmp	0x3486 <generic_kprobe_process_event+0x3136>
    268f:      	leaq	0x48(%r15), %rdx
    2693:      	movl	$0x10, %ecx
    2698:      	movl	$0x4, %eax
    269d:      	movq	%rbp, %rdi
    26a0:      	movl	$0x10, %esi
    26a5:      	callq	*%rax
    26a7:      	leaq	0x38(%r15), %rdx
    26ab:      	movl	$0x10, %ecx
    26b0:      	movl	$0x4, %eax
    26b5:      	movq	%r12, %rdi
    26b8:      	movl	$0x10, %esi
    26bd:      	callq	*%rax
    26bf:      	leaq	0x20(%rbp), %rdi
    26c3:      	leaq	0xc(%r15), %r12
    26c7:      	addq	$0xe, %r15
    26cb:      	movl	$0x2, %ecx
    26d0:      	movl	$0x4, %eax
    26d5:      	movl	$0x2, %esi
    26da:      	movq	%r15, %rdx
    26dd:      	callq	*%rax
    26df:      	leaq	0x22(%rbp), %rdi
    26e3:      	movl	$0x2, %ecx
    26e8:      	movl	$0x4, %eax
    26ed:      	movl	$0x2, %esi
    26f2:      	movq	%r12, %rdx
    26f5:      	callq	*%rax
    26f7:      	movzwl	0x22(%rbp), %eax
    26fb:      	movbew	%ax, 0x22(%rbp)
    2701:      	movq	0x50(%rsp), %rax
    2706:      	movq	%rax, 0x58(%rsp)
    270b:      	movq	(%rip), %rdi            # 0x2712 <generic_kprobe_process_event+0x23c2>
    2712:      	leaq	0x58(%rsp), %rsi
    2717:      	movl	$0x1, %eax
    271c:      	callq	*%rax
    271e:      	testq	%rax, %rax
    2721:      	je	0x3b49 <generic_kprobe_process_event+0x37f9>
    2727:      	movl	(%rax), %ecx
    2729:      	movl	%ecx, 0x10(%r13)
    272d:      	movq	0x8(%rax), %rcx
    2731:      	movq	%rcx, 0x18(%r13)
    2735:      	movl	0x4(%rax), %eax
    2738:      	movl	%eax, 0x7c(%r13)
    273c:      	movl	$0x40, %r15d
    2742:      	jmp	0x11e0 <generic_kprobe_process_event+0xe90>
    2747:      	movq	0x28(%rsp), %rax
    274c:      	movq	$0x0, 0x90(%rax,%r13)
    2758:      	movl	$0x8, %r15d
    275e:      	jmp	0x3458 <generic_kprobe_process_event+0x3108>
    2763:      	movl	$0xe, %eax
    2768:      	callq	*%rax
    276a:      	cmpq	$-0x16, %rax
    276e:      	jne	0x278f <generic_kprobe_process_event+0x243f>
    2770:      	leaq	0x20(%r14), %rdx
    2774:      	leaq	0x58(%rsp), %rdi
    2779:      	movl	$0x8, %ecx
    277e:      	movl	$0x4, %eax
    2783:      	movl	$0x8, %esi
    2788:      	callq	*%rax
    278a:      	movq	0x58(%rsp), %rax
    278f:      	movq	0x8(%r13), %rcx
    2793:      	movq	0x60(%r13), %rdx
    2797:      	movq	%rcx, 0x58(%rsp)
    279c:      	movq	0x28(%rsp), %rcx
    27a1:      	movq	%rcx, 0x60(%rsp)
    27a6:      	movq	$0x0, 0x68(%rsp)
    27af:      	movq	%rdx, 0xa0(%rsp)
    27b7:      	movq	%rax, 0xa8(%rsp)
    27bf:      	movq	(%rip), %rdi            # 0x27c6 <generic_kprobe_process_event+0x2476>
    27c6:      	xorl	%ecx, %ecx
    27c8:      	leaq	0xa0(%rsp), %rsi
    27d0:      	leaq	0x58(%rsp), %rdx
    27d5:      	movl	$0x2, %eax
    27da:      	xorl	%ecx, %ecx
    27dc:      	callq	*%rax
    27de:      	testq	%rax, %rax
    27e1:      	je	0x3230 <generic_kprobe_process_event+0x2ee0>
    27e7:      	negl	%eax
    27e9:      	movw	%ax, 0x40(%rsp)
    27ee:      	movw	$0x5, 0x42(%rsp)
    27f5:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    27ff:      	movq	%rax, 0x44(%rsp)
    2804:      	movq	(%rip), %rdi            # 0x280b <generic_kprobe_process_event+0x24bb>
    280b:      	leaq	0x40(%rsp), %rsi
    2810:      	movl	$0x1, %eax
    2815:      	callq	*%rax
    2817:      	testq	%rax, %rax
    281a:      	je	0x3206 <generic_kprobe_process_event+0x2eb6>
    2820:      	incl	(%rax)
    2822:      	jmp	0x3230 <generic_kprobe_process_event+0x2ee0>
    2827:      	cmpl	$0x1, %eax
    282a:      	je	0x2ba3 <generic_kprobe_process_event+0x2853>
    2830:      	cmpl	$0x2, %eax
    2833:      	jne	0x2fee <generic_kprobe_process_event+0x2c9e>
    2839:      	movq	0x20(%rsp), %rax
    283e:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2844:      	jmp	0x2bae <generic_kprobe_process_event+0x285e>
    2849:      	movq	0x8(%rsp), %r12
    284e:      	leaq	0x8(%r12), %rdi
    2853:      	leaq	0x8(%r15), %rdx
    2857:      	movl	$0x10, %ecx
    285c:      	movl	$0x4, %eax
    2861:      	movl	$0x10, %esi
    2866:      	callq	*%rax
    2868:      	leaq	0x2(%r12), %rdi
    286d:      	addq	$0x2, %r15
    2871:      	movl	$0x2, %ecx
    2876:      	movl	$0x4, %eax
    287b:      	movl	$0x2, %esi
    2880:      	movq	%r15, %rdx
    2883:      	callq	*%rax
    2885:      	movq	0x8(%rsp), %rcx
    288a:      	movzwl	0x2(%rcx), %eax
    288e:      	movbew	%ax, 0x2(%rcx)
    2894:      	movq	0x18(%rsp), %rbp
    2899:      	movl	$0x18, %r15d
    289f:      	jmp	0x29ac <generic_kprobe_process_event+0x265c>
    28a4:      	movq	0x8(%rsp), %rax
    28a9:      	leaq	0x10(%rax), %rdi
    28ad:      	movq	0x58(%rsp), %rcx
    28b2:      	movl	$0x3f, %edx
    28b7:      	movl	$0x2d, %eax
    28bc:      	movq	0x58(%rsp), %rdx
    28c1:      	movl	$0x3f, %esi
    28c6:      	callq	*%rax
    28c8:      	testq	%rax, %rax
    28cb:      	js	0x2478 <generic_kprobe_process_event+0x2128>
    28d1:      	movq	0x28(%rsp), %r15
    28d6:      	leaq	0x8(%r15), %rdx
    28da:      	leaq	0xa0(%rsp), %rdi
    28e2:      	movl	$0x8, %ecx
    28e7:      	movl	$0x4, %eax
    28ec:      	movl	$0x8, %esi
    28f1:      	callq	*%rax
    28f3:      	movq	0x8(%rsp), %rax
    28f8:      	leaq	0x8(%rax), %rdi
    28fc:      	movl	$0x348, %edx            # imm = 0x348
    2901:      	movq	0xa0(%rsp), %rcx
    2909:      	addq	%rdx, %rcx
    290c:      	movl	$0x8, %esi
    2911:      	movl	$0x4, %eax
    2916:      	addq	0xa0(%rsp), %rdx
    291e:      	movl	$0x8, %esi
    2923:      	callq	*%rax
    2925:      	addq	$0x58, %r15
    2929:      	leaq	0xa0(%rsp), %rdi
    2931:      	movl	$0x4, %ecx
    2936:      	movl	$0x4, %eax
    293b:      	movl	$0x4, %esi
    2940:      	movq	%r15, %rdx
    2943:      	callq	*%rax
    2945:      	movl	$0x50, %r15d
    294b:      	testq	%rax, %rax
    294e:      	jne	0x1023 <generic_kprobe_process_event+0xcd3>
    2954:      	xorl	%eax, %eax
    2956:      	cmpl	$0x0, 0xa0(%rsp)
    295e:      	setne	%al
    2961:      	movq	0x8(%rsp), %rcx
    2966:      	movl	%eax, (%rcx)
    2968:      	jmp	0x1023 <generic_kprobe_process_event+0xcd3>
    296d:      	xorl	%r15d, %r15d
    2970:      	movq	%r12, %rcx
    2973:      	jmp	0x1028 <generic_kprobe_process_event+0xcd8>
    2978:      	addq	$0x3, %r15
    297c:      	movl	$0x6b, %ecx
    2981:      	movl	$0x71, %eax
    2986:      	movl	$0x6b, %esi
    298b:      	movq	%r15, %rdx
    298e:      	callq	*%rax
    2990:      	movq	%rax, %rcx
    2993:      	movb	$0x6b, %al
    2995:      	testl	%ecx, %ecx
    2997:      	movq	0x18(%rsp), %rbp
    299c:      	js	0x29a6 <generic_kprobe_process_event+0x2656>
    299e:      	movq	0x8(%rsp), %rcx
    29a3:      	movb	%al, 0x3(%rcx)
    29a6:      	movl	$0x70, %r15d
    29ac:      	movq	0x10(%rsp), %rcx
    29b1:      	movq	(%rsp), %rsi
    29b5:      	movq	0xc8(%rsp), %r13
    29bd:      	movq	0x38(%rsp), %rbx
    29c2:      	testl	%r15d, %r15d
    29c5:      	js	0x29d7 <generic_kprobe_process_event+0x2687>
    29c7:      	andl	$0x7fffffff, %r15d      # imm = 0x7FFFFFFF
    29ce:      	addl	$0x4, %r15d
    29d2:      	movl	%r15d, %edx
    29d5:      	jmp	0x29f2 <generic_kprobe_process_event+0x26a2>
    29d7:      	movl	$0xffffffff, 0x5ea0(%rcx,%rsi,4) # imm = 0xFFFFFFFF
    29e2:      	movl	$0xffffffff, 0x90(%rcx,%rbp) # imm = 0xFFFFFFFF
    29ed:      	movl	$0x4, %edx
    29f2:      	addl	%ebp, %edx
    29f4:      	movl	%edx, %ebp
    29f6:      	movl	%ebp, 0x4(%r14)
    29fa:      	cmpl	$0x3, %ebx
    29fd:      	jg	0x2a6c <generic_kprobe_process_event+0x271c>
    29ff:      	movl	$0x0, 0x58(%rsp)
    2a07:      	movq	(%rip), %rdi            # 0x2a0e <generic_kprobe_process_event+0x26be>
    2a0e:      	leaq	0x58(%rsp), %rsi
    2a13:      	movl	$0x1, %eax
    2a18:      	callq	*%rax
    2a1a:      	testq	%rax, %rax
    2a1d:      	je	0x2a6c <generic_kprobe_process_event+0x271c>
    2a1f:      	movq	%rax, %rsi
    2a22:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2a29:      	movq	(%rip), %rdi            # 0x2a30 <generic_kprobe_process_event+0x26e0>
    2a30:      	movl	$0x1, %eax
    2a35:      	callq	*%rax
    2a37:      	testq	%rax, %rax
    2a3a:      	je	0x2a6c <generic_kprobe_process_event+0x271c>
    2a3c:      	incl	%ebx
    2a3e:      	movl	%ebx, %ecx
    2a40:      	andl	$0x7, %ecx
    2a43:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
    2a48:      	je	0x2a6c <generic_kprobe_process_event+0x271c>
    2a4a:      	movl	%ebx, 0x5efc(%r14)
    2a51:      	movq	(%rip), %rsi            # 0x2a58 <generic_kprobe_process_event+0x2708>
    2a58:      	movl	$0x1, %ecx
    2a5d:      	movl	$0xc, %eax
    2a62:      	movq	%r13, %rdi
    2a65:      	movl	$0x1, %edx
    2a6a:      	callq	*%rax
    2a6c:      	movl	$0x0, 0x5efc(%r14)
    2a77:      	movq	(%rip), %rsi            # 0x2a7e <generic_kprobe_process_event+0x272e>
    2a7e:      	movl	$0x3, %ecx
    2a83:      	movl	$0xc, %eax
    2a88:      	movq	%r13, %rdi
    2a8b:      	movl	$0x3, %edx
    2a90:      	callq	*%rax
    2a92:      	xorl	%eax, %eax
    2a94:      	addq	$0x108, %rsp            # imm = 0x108
    2a9b:      	popq	%rbx
    2a9c:      	popq	%r12
    2a9e:      	popq	%r13
    2aa0:      	popq	%r14
    2aa2:      	popq	%r15
    2aa4:      	popq	%rbp
    2aa5:      	retq
    2aa6:      	cmpl	$0x1, %ecx
    2aa9:      	je	0x32b8 <generic_kprobe_process_event+0x2f68>
    2aaf:      	cmpl	$0x2, %ecx
    2ab2:      	jne	0x32c2 <generic_kprobe_process_event+0x2f72>
    2ab8:      	leaq	0x5e58(%r13), %rax
    2abf:      	jmp	0x32bf <generic_kprobe_process_event+0x2f6f>
    2ac4:      	leaq	0x48(%r15), %rdx
    2ac8:      	movl	$0x10, %ecx
    2acd:      	movl	$0x4, %eax
    2ad2:      	movq	0x8(%rsp), %rdi
    2ad7:      	movl	$0x10, %esi
    2adc:      	callq	*%rax
    2ade:      	leaq	0x38(%r15), %rdx
    2ae2:      	movl	$0x10, %ecx
    2ae7:      	movl	$0x4, %eax
    2aec:      	movq	%r12, %rdi
    2aef:      	movl	$0x10, %esi
    2af4:      	callq	*%rax
    2af6:      	movq	0x8(%rsp), %rbp
    2afb:      	leaq	0x20(%rbp), %rdi
    2aff:      	leaq	0xc(%r15), %r12
    2b03:      	addq	$0xe, %r15
    2b07:      	movl	$0x2, %ecx
    2b0c:      	movl	$0x4, %eax
    2b11:      	movl	$0x2, %esi
    2b16:      	movq	%r15, %rdx
    2b19:      	callq	*%rax
    2b1b:      	leaq	0x22(%rbp), %rdi
    2b1f:      	movl	$0x2, %ecx
    2b24:      	movl	$0x4, %eax
    2b29:      	movl	$0x2, %esi
    2b2e:      	movq	%r12, %rdx
    2b31:      	callq	*%rax
    2b33:      	movzwl	0x22(%rbp), %eax
    2b37:      	movbew	%ax, 0x22(%rbp)
    2b3d:      	movq	0x8(%rsp), %rax
    2b42:      	movq	0x28(%rax), %rax
    2b46:      	movq	%rax, 0x58(%rsp)
    2b4b:      	movq	(%rip), %rdi            # 0x2b52 <generic_kprobe_process_event+0x2802>
    2b52:      	leaq	0x58(%rsp), %rsi
    2b57:      	movl	$0x1, %eax
    2b5c:      	callq	*%rax
    2b5e:      	testq	%rax, %rax
    2b61:      	je	0x2b7b <generic_kprobe_process_event+0x282b>
    2b63:      	movl	(%rax), %ecx
    2b65:      	movq	0x20(%rsp), %rdx
    2b6a:      	movl	%ecx, 0x10(%rdx)
    2b6d:      	movq	0x8(%rax), %rcx
    2b71:      	movq	%rcx, 0x18(%rdx)
    2b75:      	movl	0x4(%rax), %eax
    2b78:      	movl	%eax, 0x7c(%rdx)
    2b7b:      	movl	$0x40, %r15d
    2b81:      	movq	%r13, %rcx
    2b84:      	jmp	0x3286 <generic_kprobe_process_event+0x2f36>
    2b89:      	movq	0x20(%rsp), %rax
    2b8e:      	addq	$0x5e60, %rax           # imm = 0x5E60
    2b94:      	jmp	0x2bae <generic_kprobe_process_event+0x285e>
    2b96:      	movq	0x20(%rsp), %rax
    2b9b:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2ba1:      	jmp	0x2bae <generic_kprobe_process_event+0x285e>
    2ba3:      	movq	0x20(%rsp), %rax
    2ba8:      	addq	$0x5e50, %rax           # imm = 0x5E50
    2bae:      	movq	(%rax), %r12
    2bb1:      	testb	$0x10, 0x98(%rsp)
    2bb9:      	jne	0x3005 <generic_kprobe_process_event+0x2cb5>
    2bbf:      	testq	%r12, %r12
    2bc2:      	je	0x30ca <generic_kprobe_process_event+0x2d7a>
    2bc8:      	leaq	0x58(%rsp), %rdi
    2bcd:      	movl	$0x4, %r15d
    2bd3:      	movl	$0x10, %ecx
    2bd8:      	movl	$0x4, %eax
    2bdd:      	movq	0x28(%rsp), %rdx
    2be2:      	movl	$0x10, %esi
    2be7:      	callq	*%rax
    2be9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bee:      	testl	%eax, %eax
    2bf0:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2bf6:      	movq	0x60(%rsp), %r13
    2bfb:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c00:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    2c07:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2c0d:      	movq	0x18(%rsp), %rax
    2c12:      	leaq	0xc(%rax), %rdi
    2c16:      	movq	%rdi, 0x20(%rsp)
    2c1b:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c21:      	addq	%rbp, %rdi
    2c24:      	movq	0x58(%rsp), %rcx
    2c29:      	movl	$0x4, %eax
    2c2e:      	movq	0x58(%rsp), %rdx
    2c33:      	movl	%r13d, %esi
    2c36:      	callq	*%rax
    2c38:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c3d:      	testl	%eax, %eax
    2c3f:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2c45:      	cmpq	$0x1, %r12
    2c49:      	je	0x30cd <generic_kprobe_process_event+0x2d7d>
    2c4f:      	movq	0x28(%rsp), %rax
    2c54:      	leaq	0x10(%rax), %rdx
    2c58:      	leaq	0x58(%rsp), %rdi
    2c5d:      	movl	$0x4, %r15d
    2c63:      	movl	$0x10, %ecx
    2c68:      	movl	$0x4, %eax
    2c6d:      	movl	$0x10, %esi
    2c72:      	callq	*%rax
    2c74:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c79:      	testl	%eax, %eax
    2c7b:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2c81:      	movq	0x60(%rsp), %rax
    2c86:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c8b:      	movq	%rax, 0x98(%rsp)
    2c93:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2c99:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2c9f:      	movq	0x20(%rsp), %rdi
    2ca4:      	addq	%r13, %rdi
    2ca7:      	movq	%rdi, 0x20(%rsp)
    2cac:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cb2:      	addq	%rbp, %rdi
    2cb5:      	movq	0x58(%rsp), %rcx
    2cba:      	movl	$0x4, %eax
    2cbf:      	movq	0x98(%rsp), %rsi
    2cc7:      	movq	0x58(%rsp), %rdx
    2ccc:      	callq	*%rax
    2cce:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2cd3:      	testl	%eax, %eax
    2cd5:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2cdb:      	addq	0x98(%rsp), %r13
    2ce3:      	cmpq	$0x3, %r12
    2ce7:      	jb	0x30cd <generic_kprobe_process_event+0x2d7d>
    2ced:      	movq	0x28(%rsp), %rax
    2cf2:      	leaq	0x20(%rax), %rdx
    2cf6:      	leaq	0x58(%rsp), %rdi
    2cfb:      	movl	$0x4, %r15d
    2d01:      	movl	$0x10, %ecx
    2d06:      	movl	$0x4, %eax
    2d0b:      	movl	$0x10, %esi
    2d10:      	callq	*%rax
    2d12:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d17:      	testl	%eax, %eax
    2d19:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2d1f:      	movq	0x60(%rsp), %rax
    2d24:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d29:      	movq	%rax, 0x8(%rsp)
    2d2e:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2d34:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2d3a:      	movq	0x98(%rsp), %rdi
    2d42:      	addq	0x20(%rsp), %rdi
    2d47:      	movq	%rdi, 0x98(%rsp)
    2d4f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d55:      	addq	%rbp, %rdi
    2d58:      	movq	0x58(%rsp), %rcx
    2d5d:      	movl	$0x4, %eax
    2d62:      	movq	0x8(%rsp), %rsi
    2d67:      	movq	0x58(%rsp), %rdx
    2d6c:      	callq	*%rax
    2d6e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d73:      	testl	%eax, %eax
    2d75:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2d7b:      	addq	0x8(%rsp), %r13
    2d80:      	cmpq	$0x3, %r12
    2d84:      	je	0x30cd <generic_kprobe_process_event+0x2d7d>
    2d8a:      	movq	0x28(%rsp), %rax
    2d8f:      	leaq	0x30(%rax), %rdx
    2d93:      	leaq	0x58(%rsp), %rdi
    2d98:      	movl	$0x4, %r15d
    2d9e:      	movl	$0x10, %ecx
    2da3:      	movl	$0x4, %eax
    2da8:      	movl	$0x10, %esi
    2dad:      	callq	*%rax
    2daf:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2db4:      	testl	%eax, %eax
    2db6:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2dbc:      	movq	0x60(%rsp), %rax
    2dc1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2dc6:      	movq	%rax, 0x20(%rsp)
    2dcb:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2dd1:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2dd7:      	movq	0x8(%rsp), %rdi
    2ddc:      	addq	0x98(%rsp), %rdi
    2de4:      	movq	%rdi, 0x8(%rsp)
    2de9:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2def:      	addq	%rbp, %rdi
    2df2:      	movq	0x58(%rsp), %rcx
    2df7:      	movl	$0x4, %eax
    2dfc:      	movq	0x20(%rsp), %rsi
    2e01:      	movq	0x58(%rsp), %rdx
    2e06:      	callq	*%rax
    2e08:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e0d:      	testl	%eax, %eax
    2e0f:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2e15:      	addq	0x20(%rsp), %r13
    2e1a:      	cmpq	$0x5, %r12
    2e1e:      	jb	0x30cd <generic_kprobe_process_event+0x2d7d>
    2e24:      	movq	0x28(%rsp), %rax
    2e29:      	leaq	0x40(%rax), %rdx
    2e2d:      	leaq	0x58(%rsp), %rdi
    2e32:      	movl	$0x4, %r15d
    2e38:      	movl	$0x10, %ecx
    2e3d:      	movl	$0x4, %eax
    2e42:      	movl	$0x10, %esi
    2e47:      	callq	*%rax
    2e49:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e4e:      	testl	%eax, %eax
    2e50:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2e56:      	movq	0x60(%rsp), %rax
    2e5b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2e60:      	movq	%rax, 0x98(%rsp)
    2e68:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2e6e:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2e74:      	movq	0x20(%rsp), %rdi
    2e79:      	addq	0x8(%rsp), %rdi
    2e7e:      	movq	%rdi, 0x20(%rsp)
    2e83:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2e89:      	addq	%rbp, %rdi
    2e8c:      	movq	0x58(%rsp), %rcx
    2e91:      	movl	$0x4, %eax
    2e96:      	movq	0x98(%rsp), %rsi
    2e9e:      	movq	0x58(%rsp), %rdx
    2ea3:      	callq	*%rax
    2ea5:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2eaa:      	testl	%eax, %eax
    2eac:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2eb2:      	addq	0x98(%rsp), %r13
    2eba:      	cmpq	$0x5, %r12
    2ebe:      	je	0x30cd <generic_kprobe_process_event+0x2d7d>
    2ec4:      	movq	0x28(%rsp), %rax
    2ec9:      	leaq	0x50(%rax), %rdx
    2ecd:      	leaq	0x58(%rsp), %rdi
    2ed2:      	movl	$0x4, %r15d
    2ed8:      	movl	$0x10, %ecx
    2edd:      	movl	$0x4, %eax
    2ee2:      	movl	$0x10, %esi
    2ee7:      	callq	*%rax
    2ee9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2eee:      	testl	%eax, %eax
    2ef0:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2ef6:      	movq	0x60(%rsp), %rax
    2efb:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2f00:      	movq	%rax, 0x8(%rsp)
    2f05:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2f0b:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2f11:      	movq	0x98(%rsp), %rdi
    2f19:      	addq	0x20(%rsp), %rdi
    2f1e:      	movq	%rdi, 0x98(%rsp)
    2f26:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2f2c:      	addq	%rbp, %rdi
    2f2f:      	movq	0x58(%rsp), %rcx
    2f34:      	movl	$0x4, %eax
    2f39:      	movq	0x8(%rsp), %rsi
    2f3e:      	movq	0x58(%rsp), %rdx
    2f43:      	callq	*%rax
    2f45:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f4a:      	testl	%eax, %eax
    2f4c:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2f52:      	addq	0x8(%rsp), %r13
    2f57:      	cmpq	$0x7, %r12
    2f5b:      	jb	0x30cd <generic_kprobe_process_event+0x2d7d>
    2f61:      	movq	0x28(%rsp), %rdx
    2f66:      	addq	$0x60, %rdx
    2f6a:      	leaq	0x58(%rsp), %rdi
    2f6f:      	movl	$0x4, %r15d
    2f75:      	movl	$0x10, %ecx
    2f7a:      	movl	$0x4, %eax
    2f7f:      	movl	$0x10, %esi
    2f84:      	callq	*%rax
    2f86:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f8b:      	testl	%eax, %eax
    2f8d:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2f8f:      	movq	0x60(%rsp), %r12
    2f94:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2f99:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2fa0:      	ja	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2fa2:      	movq	0x8(%rsp), %rdi
    2fa7:      	addq	0x98(%rsp), %rdi
    2faf:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2fb5:      	addq	%rbp, %rdi
    2fb8:      	movq	0x58(%rsp), %rcx
    2fbd:      	movl	$0x4, %eax
    2fc2:      	movq	0x58(%rsp), %rdx
    2fc7:      	movl	%r12d, %esi
    2fca:      	callq	*%rax
    2fcc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2fd1:      	testl	%eax, %eax
    2fd3:      	js	0x2fdd <generic_kprobe_process_event+0x2c8d>
    2fd5:      	addq	%r12, %r13
    2fd8:      	jmp	0x30cd <generic_kprobe_process_event+0x2d7d>
    2fdd:      	movq	0xb0(%rsp), %rax
    2fe5:      	movl	%ecx, (%rbp,%rax)
    2fe9:      	jmp	0x3281 <generic_kprobe_process_event+0x2f31>
    2fee:      	xorl	%r12d, %r12d
    2ff1:      	movl	$0x0, %r13d
    2ff7:      	testb	$0x10, 0x98(%rsp)
    2fff:      	je	0x30cd <generic_kprobe_process_event+0x2d7d>
    3005:      	movl	$0xe, %eax
    300a:      	callq	*%rax
    300c:      	cmpq	$-0x16, %rax
    3010:      	jne	0x3031 <generic_kprobe_process_event+0x2ce1>
    3012:      	leaq	0x20(%rbx), %rdx
    3016:      	leaq	0x58(%rsp), %rdi
    301b:      	movl	$0x8, %ecx
    3020:      	movl	$0x4, %eax
    3025:      	movl	$0x8, %esi
    302a:      	callq	*%rax
    302c:      	movq	0x58(%rsp), %rax
    3031:      	movq	0x20(%rsp), %rdx
    3036:      	movq	0x8(%rdx), %rcx
    303a:      	movq	0x60(%rdx), %rdx
    303e:      	movq	%rcx, 0x58(%rsp)
    3043:      	movq	0x28(%rsp), %rcx
    3048:      	movq	%rcx, 0x60(%rsp)
    304d:      	movq	%r12, 0x68(%rsp)
    3052:      	movq	%rdx, 0xa0(%rsp)
    305a:      	movq	%rax, 0xa8(%rsp)
    3062:      	movq	(%rip), %rdi            # 0x3069 <generic_kprobe_process_event+0x2d19>
    3069:      	xorl	%ecx, %ecx
    306b:      	leaq	0xa0(%rsp), %rsi
    3073:      	leaq	0x58(%rsp), %rdx
    3078:      	movl	$0x2, %eax
    307d:      	xorl	%ecx, %ecx
    307f:      	callq	*%rax
    3081:      	testq	%rax, %rax
    3084:      	je	0x326b <generic_kprobe_process_event+0x2f1b>
    308a:      	negl	%eax
    308c:      	movw	%ax, 0x40(%rsp)
    3091:      	movw	$0x5, 0x42(%rsp)
    3098:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    30a2:      	movq	%rax, 0x44(%rsp)
    30a7:      	movq	(%rip), %rdi            # 0x30ae <generic_kprobe_process_event+0x2d5e>
    30ae:      	leaq	0x40(%rsp), %rsi
    30b3:      	movl	$0x1, %eax
    30b8:      	callq	*%rax
    30ba:      	testq	%rax, %rax
    30bd:      	je	0x3241 <generic_kprobe_process_event+0x2ef1>
    30c3:      	incl	(%rax)
    30c5:      	jmp	0x326b <generic_kprobe_process_event+0x2f1b>
    30ca:      	xorl	%r13d, %r13d
    30cd:      	movq	0xb0(%rsp), %rax
    30d5:      	movl	%r13d, (%rbp,%rax)
    30da:      	movl	%r13d, 0x4(%rbp,%rax)
    30df:      	addq	$0x8, %r13
    30e3:      	movq	%r13, %r15
    30e6:      	jmp	0x3281 <generic_kprobe_process_event+0x2f31>
    30eb:      	movq	0x28(%rsp), %rax
    30f0:      	addq	$0x90, %rax
    30f6:      	movl	$0x0, (%r12)
    30fe:      	movq	0x18(%rsp), %rcx
    3103:      	leal	0x8(%rcx), %r12d
    3107:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    310e:      	addq	%rax, %r12
    3111:      	movl	$0xc, %r15d
    3117:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    311e:      	movl	$0xfff, %ebp            # imm = 0xFFF
    3123:      	cmovbq	%rbx, %rbp
    3127:      	leaq	0x8(%r12), %rdi
    312c:      	movl	$0x4, %eax
    3131:      	movl	%ebp, %esi
    3133:      	movq	%r14, %rdx
    3136:      	callq	*%rax
    3138:      	testl	%eax, %eax
    313a:      	js	0x314d <generic_kprobe_process_event+0x2dfd>
    313c:      	movl	%ebx, (%r12)
    3140:      	movl	%ebp, 0x4(%r12)
    3145:      	addq	%rbp, %r15
    3148:      	jmp	0x3458 <generic_kprobe_process_event+0x3108>
    314d:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    3155:      	movl	$0x4, %r15d
    315b:      	jmp	0x3458 <generic_kprobe_process_event+0x3108>
    3160:      	movq	0x28(%rsp), %rax
    3165:      	addq	$0x90, %rax
    316b:      	movl	$0x0, (%r12)
    3173:      	movq	0x18(%rsp), %rcx
    3178:      	leal	0x8(%rcx), %r12d
    317c:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    3183:      	addq	%rax, %r12
    3186:      	movl	$0xc, %r14d
    318c:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    3193:      	movl	$0xfff, %ebp            # imm = 0xFFF
    3198:      	cmovbq	%rbx, %rbp
    319c:      	leaq	0x8(%r12), %rdi
    31a1:      	movl	$0x4, %eax
    31a6:      	movq	0x20(%rsp), %rdx
    31ab:      	movl	$0x4, %r15d
    31b1:      	movl	%ebp, %esi
    31b3:      	callq	*%rax
    31b5:      	testl	%eax, %eax
    31b7:      	js	0x31cd <generic_kprobe_process_event+0x2e7d>
    31b9:      	movl	%ebx, (%r12)
    31bd:      	movl	%ebp, 0x4(%r12)
    31c2:      	addq	%rbp, %r14
    31c5:      	movq	%r14, %r15
    31c8:      	jmp	0x3458 <generic_kprobe_process_event+0x3108>
    31cd:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    31d5:      	jmp	0x3458 <generic_kprobe_process_event+0x3108>
    31da:      	cmpl	$0x33, %eax
    31dd:      	je	0x3477 <generic_kprobe_process_event+0x3127>
    31e3:      	cmpl	$0x3c, %eax
    31e6:      	je	0x3296 <generic_kprobe_process_event+0x2f46>
    31ec:      	cmpl	$0xff, %eax
    31f1:      	jne	0x353e <generic_kprobe_process_event+0x31ee>
    31f7:      	movw	$0x28, 0x2(%rbp)
    31fd:      	movw	$0x28, %ax
    3201:      	jmp	0x3486 <generic_kprobe_process_event+0x3136>
    3206:      	movl	$0x1, 0xd0(%rsp)
    3211:      	movq	(%rip), %rdi            # 0x3218 <generic_kprobe_process_event+0x2ec8>
    3218:      	xorl	%ecx, %ecx
    321a:      	leaq	0x40(%rsp), %rsi
    321f:      	leaq	0xd0(%rsp), %rdx
    3227:      	movl	$0x2, %eax
    322c:      	xorl	%ecx, %ecx
    322e:      	callq	*%rax
    3230:      	movl	$0xfffffffc, (%rbx)     # imm = 0xFFFFFFFC
    3236:      	movl	$0x4, %r15d
    323c:      	jmp	0x3564 <generic_kprobe_process_event+0x3214>
    3241:      	movl	$0x1, 0xc0(%rsp)
    324c:      	movq	(%rip), %rdi            # 0x3253 <generic_kprobe_process_event+0x2f03>
    3253:      	xorl	%ecx, %ecx
    3255:      	leaq	0x40(%rsp), %rsi
    325a:      	leaq	0xc0(%rsp), %rdx
    3262:      	movl	$0x2, %eax
    3267:      	xorl	%ecx, %ecx
    3269:      	callq	*%rax
    326b:      	movq	0xb0(%rsp), %rax
    3273:      	movl	$0xfffffffc, (%rbp,%rax) # imm = 0xFFFFFFFC
    327b:      	movl	$0x4, %r15d
    3281:      	movq	0x10(%rsp), %rcx
    3286:      	movq	%rbx, %r13
    3289:      	movq	%r14, %rbx
    328c:      	movq	0x30(%rsp), %r14
    3291:      	jmp	0x1028 <generic_kprobe_process_event+0xcd8>
    3296:      	movzbl	0x7(%rbp), %eax
    329a:      	leal	0x8(,%rax,8), %eax
    32a1:      	jmp	0x3482 <generic_kprobe_process_event+0x3132>
    32a6:      	leaq	0x5e60(%r13), %rax
    32ad:      	jmp	0x32bf <generic_kprobe_process_event+0x2f6f>
    32af:      	leaq	0x5e68(%r13), %rax
    32b6:      	jmp	0x32bf <generic_kprobe_process_event+0x2f6f>
    32b8:      	leaq	0x5e50(%r13), %rax
    32bf:      	movq	(%rax), %rax
    32c2:      	movq	%rax, 0xc0(%rsp)
    32ca:      	leaq	0x50(%rsp), %rdi
    32cf:      	leaq	0xc0(%rsp), %rdx
    32d7:      	movl	$0x8, %ecx
    32dc:      	movl	$0x4, %eax
    32e1:      	movl	$0x8, %r15d
    32e7:      	movl	$0x8, %esi
    32ec:      	callq	*%rax
    32ee:      	movq	0x50(%rsp), %r12
    32f3:      	testb	$0x20, %bpl
    32f7:      	je	0x33f1 <generic_kprobe_process_event+0x30a1>
    32fd:      	cmpq	$0x1000, %r12           # imm = 0x1000
    3304:      	jb	0x33cd <generic_kprobe_process_event+0x307d>
    330a:      	movl	$0x1, (%rbx)
    3310:      	movl	$0x0, 0xa0(%rsp)
    331b:      	movq	(%rip), %rdi            # 0x3322 <generic_kprobe_process_event+0x2fd2>
    3322:      	leaq	0xa0(%rsp), %rsi
    332a:      	movl	$0x1, %eax
    332f:      	callq	*%rax
    3331:      	testq	%rax, %rax
    3334:      	je	0x346c <generic_kprobe_process_event+0x311c>
    333a:      	movq	%rax, %r13
    333d:      	movl	$0x18, (%rax)
    3343:      	movl	$0xe, %eax
    3348:      	callq	*%rax
    334a:      	movq	%r13, %r15
    334d:      	addq	$0x10, %r15
    3351:      	movq	%rax, 0x10(%r13)
    3355:      	cmpq	$-0x16, %rax
    3359:      	jne	0x337d <generic_kprobe_process_event+0x302d>
    335b:      	leaq	0x20(%r14), %rdx
    335f:      	leaq	0x58(%rsp), %rdi
    3364:      	movl	$0x8, %ecx
    3369:      	movl	$0x4, %eax
    336e:      	movl	$0x8, %esi
    3373:      	callq	*%rax
    3375:      	movq	0x58(%rsp), %rax
    337a:      	movq	%rax, (%r15)
    337d:      	movl	$0x7d, %eax
    3382:      	callq	*%rax
    3384:      	movq	%rax, 0x18(%r13)
    3388:      	movq	(%r15), %rax
    338b:      	movq	0x8(%r15), %rcx
    338f:      	movq	%rax, 0x14(%rbx)
    3393:      	movq	%rcx, 0x1c(%rbx)
    3397:      	movq	%r14, %rdi
    339a:      	movq	%r13, %rsi
    339d:      	movq	0x28(%rsp), %rdx
    33a2:      	movq	%r12, %rcx
    33a5:      	callq	0x33aa <generic_kprobe_process_event+0x305a>
    33aa:      	testl	%eax, %eax
    33ac:      	js	0x3547 <generic_kprobe_process_event+0x31f7>
    33b2:      	movq	$0x0, 0x4(%rbx)
    33ba:      	movl	%r12d, %edx
    33bd:      	subl	%eax, %edx
    33bf:      	xorl	%ecx, %ecx
    33c1:      	cmpq	$-0x1, %r12
    33c5:      	cmovnel	%edx, %ecx
    33c8:      	jmp	0x3558 <generic_kprobe_process_event+0x3208>
    33cd:      	addq	$0x90, %r13
    33d4:      	movl	$0x0, (%rbx)
    33da:      	movq	0x18(%rsp), %rax
    33df:      	leal	0x8(%rax), %ebx
    33e2:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
    33e8:      	addq	%r13, %rbx
    33eb:      	movl	$0xc, %r15d
    33f1:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    33f8:      	movl	$0xfff, %ebp            # imm = 0xFFF
    33fd:      	cmovbq	%r12, %rbp
    3401:      	leaq	0x8(%rbx), %rdi
    3405:      	movl	$0x4, %eax
    340a:      	movq	0x28(%rsp), %rdx
    340f:      	movl	%ebp, %esi
    3411:      	callq	*%rax
    3413:      	testl	%eax, %eax
    3415:      	js	0x3425 <generic_kprobe_process_event+0x30d5>
    3417:      	movl	%r12d, (%rbx)
    341a:      	movl	%ebp, 0x4(%rbx)
    341d:      	addq	%rbp, %r15
    3420:      	jmp	0x3564 <generic_kprobe_process_event+0x3214>
    3425:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    342b:      	movl	$0x4, %r15d
    3431:      	jmp	0x3564 <generic_kprobe_process_event+0x3214>
    3436:      	movl	%eax, 0x4(%r12)
    343b:      	movl	$0x0, 0x8(%r12)
    3444:      	xorl	%ecx, %ecx
    3446:      	xorl	%eax, %eax
    3448:      	movl	%ecx, 0xc(%r12)
    344d:      	movl	%eax, 0x10(%r12)
    3452:      	movl	$0x24, %r15d
    3458:      	movq	0x10(%rsp), %rcx
    345d:      	movq	0x30(%rsp), %r14
    3462:      	movq	0x18(%rsp), %rbp
    3467:      	jmp	0x29b1 <generic_kprobe_process_event+0x2661>
    346c:      	movl	$0x4, %r15d
    3472:      	jmp	0x3564 <generic_kprobe_process_event+0x3214>
    3477:      	movzbl	0x7(%rbp), %eax
    347b:      	leal	0x8(,%rax,4), %eax
    3482:      	movw	%ax, 0x2(%rbp)
    3486:      	addw	(%rbp), %ax
    348a:      	movw	%ax, (%rbp)
    348e:      	movzbl	0x6(%rbp), %r15d
    3493:      	cmpq	$0x3c, %r15
    3497:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    349d:      	movabsq	$0x1008180000000001, %rbx # imm = 0x1008180000000001
    34a7:      	btq	%r15, %rbx
    34ab:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    34b1:      	movb	%r15b, 0x5(%rbp)
    34b5:      	movzwl	%ax, %ecx
    34b8:      	movq	0x28(%rsp), %rsi
    34bd:      	addq	%rsi, %rcx
    34c0:      	movl	$0x2, %edx
    34c5:      	movl	$0x4, %eax
    34ca:      	movq	0x20(%rsp), %rdi
    34cf:      	movzwl	(%rbp), %edx
    34d3:      	addq	%rsi, %rdx
    34d6:      	movl	$0x2, %esi
    34db:      	callq	*%rax
    34dd:      	testq	%rax, %rax
    34e0:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    34e6:      	movzbl	0x5(%rbp), %eax
    34ea:      	cmpl	$0x32, %eax
    34ed:      	jg	0x3510 <generic_kprobe_process_event+0x31c0>
    34ef:      	testl	%eax, %eax
    34f1:      	je	0x352d <generic_kprobe_process_event+0x31dd>
    34f3:      	cmpl	$0x2b, %eax
    34f6:      	je	0x352d <generic_kprobe_process_event+0x31dd>
    34f8:      	cmpl	$0x2c, %eax
    34fb:      	jne	0x358c <generic_kprobe_process_event+0x323c>
    3501:      	movw	$0x8, 0x2(%rbp)
    3507:      	movw	$0x8, %ax
    350b:      	jmp	0x3590 <generic_kprobe_process_event+0x3240>
    3510:      	cmpl	$0x33, %eax
    3513:      	je	0x357b <generic_kprobe_process_event+0x322b>
    3515:      	cmpl	$0x3c, %eax
    3518:      	je	0x352d <generic_kprobe_process_event+0x31dd>
    351a:      	cmpl	$0xff, %eax
    351f:      	jne	0x358c <generic_kprobe_process_event+0x323c>
    3521:      	movw	$0x28, 0x2(%rbp)
    3527:      	movw	$0x28, %ax
    352b:      	jmp	0x3590 <generic_kprobe_process_event+0x3240>
    352d:      	movzbl	0x7(%rbp), %eax
    3531:      	leal	0x8(,%rax,8), %eax
    3538:      	movw	%ax, 0x2(%rbp)
    353c:      	jmp	0x3590 <generic_kprobe_process_event+0x3240>
    353e:      	movzwl	0x2(%rbp), %eax
    3542:      	jmp	0x3486 <generic_kprobe_process_event+0x3136>
    3547:      	movq	%rbx, %rcx
    354a:      	movl	%eax, 0x4(%rbx)
    354d:      	movl	$0x0, 0x8(%rbx)
    3554:      	xorl	%ecx, %ecx
    3556:      	xorl	%eax, %eax
    3558:      	movl	%ecx, 0xc(%rbx)
    355b:      	movl	%eax, 0x10(%rbx)
    355e:      	movl	$0x24, %r15d
    3564:      	movq	0x10(%rsp), %rcx
    3569:      	movq	%r14, %r13
    356c:      	movq	0x38(%rsp), %rbx
    3571:      	movq	0x30(%rsp), %r14
    3576:      	jmp	0x1028 <generic_kprobe_process_event+0xcd8>
    357b:      	movzbl	0x7(%rbp), %eax
    357f:      	leal	0x8(,%rax,4), %eax
    3586:      	movw	%ax, 0x2(%rbp)
    358a:      	jmp	0x3590 <generic_kprobe_process_event+0x3240>
    358c:      	movzwl	0x2(%rbp), %eax
    3590:      	addw	(%rbp), %ax
    3594:      	movw	%ax, (%rbp)
    3598:      	movzbl	0x6(%rbp), %r15d
    359d:      	cmpq	$0x3c, %r15
    35a1:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    35a7:      	btq	%r15, %rbx
    35ab:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    35b1:      	movb	%r15b, 0x5(%rbp)
    35b5:      	movzwl	%ax, %ecx
    35b8:      	movq	0x28(%rsp), %rsi
    35bd:      	addq	%rsi, %rcx
    35c0:      	movl	$0x2, %edx
    35c5:      	movl	$0x4, %eax
    35ca:      	movq	0x20(%rsp), %rdi
    35cf:      	movzwl	(%rbp), %edx
    35d3:      	addq	%rsi, %rdx
    35d6:      	movl	$0x2, %esi
    35db:      	callq	*%rax
    35dd:      	testq	%rax, %rax
    35e0:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    35e6:      	movzbl	0x5(%rbp), %eax
    35ea:      	cmpl	$0x32, %eax
    35ed:      	jg	0x3609 <generic_kprobe_process_event+0x32b9>
    35ef:      	testl	%eax, %eax
    35f1:      	je	0x3626 <generic_kprobe_process_event+0x32d6>
    35f3:      	cmpl	$0x2b, %eax
    35f6:      	je	0x3626 <generic_kprobe_process_event+0x32d6>
    35f8:      	cmpl	$0x2c, %eax
    35fb:      	jne	0x3648 <generic_kprobe_process_event+0x32f8>
    35fd:      	movw	$0x8, 0x2(%rbp)
    3603:      	movw	$0x8, %ax
    3607:      	jmp	0x364c <generic_kprobe_process_event+0x32fc>
    3609:      	cmpl	$0x33, %eax
    360c:      	je	0x3637 <generic_kprobe_process_event+0x32e7>
    360e:      	cmpl	$0x3c, %eax
    3611:      	je	0x3626 <generic_kprobe_process_event+0x32d6>
    3613:      	cmpl	$0xff, %eax
    3618:      	jne	0x3648 <generic_kprobe_process_event+0x32f8>
    361a:      	movw	$0x28, 0x2(%rbp)
    3620:      	movw	$0x28, %ax
    3624:      	jmp	0x364c <generic_kprobe_process_event+0x32fc>
    3626:      	movzbl	0x7(%rbp), %eax
    362a:      	leal	0x8(,%rax,8), %eax
    3631:      	movw	%ax, 0x2(%rbp)
    3635:      	jmp	0x364c <generic_kprobe_process_event+0x32fc>
    3637:      	movzbl	0x7(%rbp), %eax
    363b:      	leal	0x8(,%rax,4), %eax
    3642:      	movw	%ax, 0x2(%rbp)
    3646:      	jmp	0x364c <generic_kprobe_process_event+0x32fc>
    3648:      	movzwl	0x2(%rbp), %eax
    364c:      	addw	(%rbp), %ax
    3650:      	movw	%ax, (%rbp)
    3654:      	movzbl	0x6(%rbp), %r15d
    3659:      	cmpq	$0x3c, %r15
    365d:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    3663:      	btq	%r15, %rbx
    3667:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    366d:      	movb	%r15b, 0x5(%rbp)
    3671:      	movzwl	%ax, %ecx
    3674:      	movq	0x28(%rsp), %rsi
    3679:      	addq	%rsi, %rcx
    367c:      	movl	$0x2, %edx
    3681:      	movl	$0x4, %eax
    3686:      	movq	0x20(%rsp), %rdi
    368b:      	movzwl	(%rbp), %edx
    368f:      	addq	%rsi, %rdx
    3692:      	movl	$0x2, %esi
    3697:      	callq	*%rax
    3699:      	testq	%rax, %rax
    369c:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    36a2:      	movzbl	0x5(%rbp), %eax
    36a6:      	cmpl	$0x32, %eax
    36a9:      	jg	0x36c5 <generic_kprobe_process_event+0x3375>
    36ab:      	testl	%eax, %eax
    36ad:      	je	0x36e2 <generic_kprobe_process_event+0x3392>
    36af:      	cmpl	$0x2b, %eax
    36b2:      	je	0x36e2 <generic_kprobe_process_event+0x3392>
    36b4:      	cmpl	$0x2c, %eax
    36b7:      	jne	0x3704 <generic_kprobe_process_event+0x33b4>
    36b9:      	movw	$0x8, 0x2(%rbp)
    36bf:      	movw	$0x8, %ax
    36c3:      	jmp	0x3708 <generic_kprobe_process_event+0x33b8>
    36c5:      	cmpl	$0x33, %eax
    36c8:      	je	0x36f3 <generic_kprobe_process_event+0x33a3>
    36ca:      	cmpl	$0x3c, %eax
    36cd:      	je	0x36e2 <generic_kprobe_process_event+0x3392>
    36cf:      	cmpl	$0xff, %eax
    36d4:      	jne	0x3704 <generic_kprobe_process_event+0x33b4>
    36d6:      	movw	$0x28, 0x2(%rbp)
    36dc:      	movw	$0x28, %ax
    36e0:      	jmp	0x3708 <generic_kprobe_process_event+0x33b8>
    36e2:      	movzbl	0x7(%rbp), %eax
    36e6:      	leal	0x8(,%rax,8), %eax
    36ed:      	movw	%ax, 0x2(%rbp)
    36f1:      	jmp	0x3708 <generic_kprobe_process_event+0x33b8>
    36f3:      	movzbl	0x7(%rbp), %eax
    36f7:      	leal	0x8(,%rax,4), %eax
    36fe:      	movw	%ax, 0x2(%rbp)
    3702:      	jmp	0x3708 <generic_kprobe_process_event+0x33b8>
    3704:      	movzwl	0x2(%rbp), %eax
    3708:      	addw	(%rbp), %ax
    370c:      	movw	%ax, (%rbp)
    3710:      	movzbl	0x6(%rbp), %r15d
    3715:      	cmpq	$0x3c, %r15
    3719:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    371f:      	btq	%r15, %rbx
    3723:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    3729:      	movb	%r15b, 0x5(%rbp)
    372d:      	movzwl	%ax, %ecx
    3730:      	movq	0x28(%rsp), %rsi
    3735:      	addq	%rsi, %rcx
    3738:      	movl	$0x2, %edx
    373d:      	movl	$0x4, %eax
    3742:      	movq	0x20(%rsp), %rdi
    3747:      	movzwl	(%rbp), %edx
    374b:      	addq	%rsi, %rdx
    374e:      	movl	$0x2, %esi
    3753:      	callq	*%rax
    3755:      	testq	%rax, %rax
    3758:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    375e:      	movzbl	0x5(%rbp), %eax
    3762:      	cmpl	$0x32, %eax
    3765:      	jg	0x3781 <generic_kprobe_process_event+0x3431>
    3767:      	testl	%eax, %eax
    3769:      	je	0x379e <generic_kprobe_process_event+0x344e>
    376b:      	cmpl	$0x2b, %eax
    376e:      	je	0x379e <generic_kprobe_process_event+0x344e>
    3770:      	cmpl	$0x2c, %eax
    3773:      	jne	0x37c0 <generic_kprobe_process_event+0x3470>
    3775:      	movw	$0x8, 0x2(%rbp)
    377b:      	movw	$0x8, %ax
    377f:      	jmp	0x37c4 <generic_kprobe_process_event+0x3474>
    3781:      	cmpl	$0x33, %eax
    3784:      	je	0x37af <generic_kprobe_process_event+0x345f>
    3786:      	cmpl	$0x3c, %eax
    3789:      	je	0x379e <generic_kprobe_process_event+0x344e>
    378b:      	cmpl	$0xff, %eax
    3790:      	jne	0x37c0 <generic_kprobe_process_event+0x3470>
    3792:      	movw	$0x28, 0x2(%rbp)
    3798:      	movw	$0x28, %ax
    379c:      	jmp	0x37c4 <generic_kprobe_process_event+0x3474>
    379e:      	movzbl	0x7(%rbp), %eax
    37a2:      	leal	0x8(,%rax,8), %eax
    37a9:      	movw	%ax, 0x2(%rbp)
    37ad:      	jmp	0x37c4 <generic_kprobe_process_event+0x3474>
    37af:      	movzbl	0x7(%rbp), %eax
    37b3:      	leal	0x8(,%rax,4), %eax
    37ba:      	movw	%ax, 0x2(%rbp)
    37be:      	jmp	0x37c4 <generic_kprobe_process_event+0x3474>
    37c0:      	movzwl	0x2(%rbp), %eax
    37c4:      	addw	(%rbp), %ax
    37c8:      	movw	%ax, (%rbp)
    37cc:      	movzbl	0x6(%rbp), %r15d
    37d1:      	cmpq	$0x3c, %r15
    37d5:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    37db:      	btq	%r15, %rbx
    37df:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    37e5:      	movb	%r15b, 0x5(%rbp)
    37e9:      	movzwl	%ax, %ecx
    37ec:      	movq	0x28(%rsp), %rsi
    37f1:      	addq	%rsi, %rcx
    37f4:      	movl	$0x2, %edx
    37f9:      	movl	$0x4, %eax
    37fe:      	movq	0x20(%rsp), %rdi
    3803:      	movzwl	(%rbp), %edx
    3807:      	addq	%rsi, %rdx
    380a:      	movl	$0x2, %esi
    380f:      	callq	*%rax
    3811:      	testq	%rax, %rax
    3814:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    381a:      	movzbl	0x5(%rbp), %eax
    381e:      	cmpl	$0x32, %eax
    3821:      	jg	0x383d <generic_kprobe_process_event+0x34ed>
    3823:      	testl	%eax, %eax
    3825:      	je	0x385a <generic_kprobe_process_event+0x350a>
    3827:      	cmpl	$0x2b, %eax
    382a:      	je	0x385a <generic_kprobe_process_event+0x350a>
    382c:      	cmpl	$0x2c, %eax
    382f:      	jne	0x387c <generic_kprobe_process_event+0x352c>
    3831:      	movw	$0x8, 0x2(%rbp)
    3837:      	movw	$0x8, %ax
    383b:      	jmp	0x3880 <generic_kprobe_process_event+0x3530>
    383d:      	cmpl	$0x33, %eax
    3840:      	je	0x386b <generic_kprobe_process_event+0x351b>
    3842:      	cmpl	$0x3c, %eax
    3845:      	je	0x385a <generic_kprobe_process_event+0x350a>
    3847:      	cmpl	$0xff, %eax
    384c:      	jne	0x387c <generic_kprobe_process_event+0x352c>
    384e:      	movw	$0x28, 0x2(%rbp)
    3854:      	movw	$0x28, %ax
    3858:      	jmp	0x3880 <generic_kprobe_process_event+0x3530>
    385a:      	movzbl	0x7(%rbp), %eax
    385e:      	leal	0x8(,%rax,8), %eax
    3865:      	movw	%ax, 0x2(%rbp)
    3869:      	jmp	0x3880 <generic_kprobe_process_event+0x3530>
    386b:      	movzbl	0x7(%rbp), %eax
    386f:      	leal	0x8(,%rax,4), %eax
    3876:      	movw	%ax, 0x2(%rbp)
    387a:      	jmp	0x3880 <generic_kprobe_process_event+0x3530>
    387c:      	movzwl	0x2(%rbp), %eax
    3880:      	addw	(%rbp), %ax
    3884:      	movw	%ax, (%rbp)
    3888:      	movzbl	0x6(%rbp), %r15d
    388d:      	cmpq	$0x3c, %r15
    3891:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    3897:      	btq	%r15, %rbx
    389b:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    38a1:      	movb	%r15b, 0x5(%rbp)
    38a5:      	movzwl	%ax, %ecx
    38a8:      	movq	0x28(%rsp), %rsi
    38ad:      	addq	%rsi, %rcx
    38b0:      	movl	$0x2, %edx
    38b5:      	movl	$0x4, %eax
    38ba:      	movq	0x20(%rsp), %rdi
    38bf:      	movzwl	(%rbp), %edx
    38c3:      	addq	%rsi, %rdx
    38c6:      	movl	$0x2, %esi
    38cb:      	callq	*%rax
    38cd:      	testq	%rax, %rax
    38d0:      	js	0x3989 <generic_kprobe_process_event+0x3639>
    38d6:      	movzbl	0x5(%rbp), %eax
    38da:      	cmpl	$0x32, %eax
    38dd:      	jg	0x38f9 <generic_kprobe_process_event+0x35a9>
    38df:      	testl	%eax, %eax
    38e1:      	je	0x3916 <generic_kprobe_process_event+0x35c6>
    38e3:      	cmpl	$0x2b, %eax
    38e6:      	je	0x3916 <generic_kprobe_process_event+0x35c6>
    38e8:      	cmpl	$0x2c, %eax
    38eb:      	jne	0x3938 <generic_kprobe_process_event+0x35e8>
    38ed:      	movw	$0x8, 0x2(%rbp)
    38f3:      	movw	$0x8, %ax
    38f7:      	jmp	0x393c <generic_kprobe_process_event+0x35ec>
    38f9:      	cmpl	$0x33, %eax
    38fc:      	je	0x3927 <generic_kprobe_process_event+0x35d7>
    38fe:      	cmpl	$0x3c, %eax
    3901:      	je	0x3916 <generic_kprobe_process_event+0x35c6>
    3903:      	cmpl	$0xff, %eax
    3908:      	jne	0x3938 <generic_kprobe_process_event+0x35e8>
    390a:      	movw	$0x28, 0x2(%rbp)
    3910:      	movw	$0x28, %ax
    3914:      	jmp	0x393c <generic_kprobe_process_event+0x35ec>
    3916:      	movzbl	0x7(%rbp), %eax
    391a:      	leal	0x8(,%rax,8), %eax
    3921:      	movw	%ax, 0x2(%rbp)
    3925:      	jmp	0x393c <generic_kprobe_process_event+0x35ec>
    3927:      	movzbl	0x7(%rbp), %eax
    392b:      	leal	0x8(,%rax,4), %eax
    3932:      	movw	%ax, 0x2(%rbp)
    3936:      	jmp	0x393c <generic_kprobe_process_event+0x35ec>
    3938:      	movzwl	0x2(%rbp), %eax
    393c:      	addw	(%rbp), %ax
    3940:      	movw	%ax, (%rbp)
    3944:      	movzbl	0x6(%rbp), %r15d
    3949:      	cmpq	$0x3c, %r15
    394d:      	ja	0x3b54 <generic_kprobe_process_event+0x3804>
    3953:      	btq	%r15, %rbx
    3957:      	jae	0x3b54 <generic_kprobe_process_event+0x3804>
    395d:      	movb	%r15b, 0x5(%rbp)
    3961:      	movzwl	%ax, %ecx
    3964:      	movq	0x28(%rsp), %rsi
    3969:      	addq	%rsi, %rcx
    396c:      	movl	$0x2, %edx
    3971:      	movl	$0x4, %eax
    3976:      	movq	0x20(%rsp), %rdi
    397b:      	movzwl	(%rbp), %edx
    397f:      	addq	%rsi, %rdx
    3982:      	movl	$0x2, %esi
    3987:      	callq	*%rax
    3989:      	xorl	%r15d, %r15d
    398c:      	movb	%r15b, 0xb8(%rsp)
    3994:      	movzbl	%r15b, %eax
    3998:      	movq	0x8(%rsp), %rbp
    399d:      	movw	%ax, 0x24(%rbp)
    39a1:      	movw	$0xa, 0x26(%rbp)
    39a7:      	leaq	0x8(%r13), %rdx
    39ab:      	movl	$0x10, %ecx
    39b0:      	movl	$0x4, %eax
    39b5:      	movq	%rbp, %rdi
    39b8:      	movl	$0x10, %esi
    39bd:      	callq	*%rax
    39bf:      	leaq	0x10(%rbp), %rdi
    39c3:      	addq	$0x18, %r13
    39c7:      	movl	$0x10, %ecx
    39cc:      	movl	$0x4, %eax
    39d1:      	movl	$0x10, %esi
    39d6:      	movq	%r13, %rdx
    39d9:      	callq	*%rax
    39db:      	cmpb	$0x11, %r15b
    39df:      	je	0x3a32 <generic_kprobe_process_event+0x36e2>
    39e1:      	movzbl	%r15b, %eax
    39e5:      	cmpl	$0x6, %eax
    39e8:      	jne	0x3a7d <generic_kprobe_process_event+0x372d>
    39ee:      	movq	0x58(%rsp), %r13
    39f3:      	movzwl	0xd0(%rsp), %r15d
    39fc:      	leaq	(%r15,%r13), %rdx
    3a00:      	movq	0x8(%rsp), %rbp
    3a05:      	leaq	0x20(%rbp), %rdi
    3a09:      	movl	$0x2, %ecx
    3a0e:      	movl	$0x4, %eax
    3a13:      	movl	$0x2, %esi
    3a18:      	callq	*%rax
    3a1a:      	leaq	0x22(%rbp), %rdi
    3a1e:      	leaq	(%r15,%r13), %rdx
    3a22:      	addq	$0x2, %rdx
    3a26:      	movl	$0x2, %ecx
    3a2b:      	movl	$0x4, %eax
    3a30:      	jmp	0x3a74 <generic_kprobe_process_event+0x3724>
    3a32:      	movq	0x58(%rsp), %r13
    3a37:      	movzwl	0xd0(%rsp), %r15d
    3a40:      	leaq	(%r15,%r13), %rdx
    3a44:      	movq	0x8(%rsp), %rbp
    3a49:      	leaq	0x20(%rbp), %rdi
    3a4d:      	movl	$0x2, %ecx
    3a52:      	movl	$0x4, %eax
    3a57:      	movl	$0x2, %esi
    3a5c:      	callq	*%rax
    3a5e:      	leaq	0x22(%rbp), %rdi
    3a62:      	leaq	(%r15,%r13), %rdx
    3a66:      	addq	$0x2, %rdx
    3a6a:      	movl	$0x2, %ecx
    3a6f:      	movl	$0x4, %eax
    3a74:      	movl	$0x2, %esi
    3a79:      	callq	*%rax
    3a7b:      	jmp	0x3a89 <generic_kprobe_process_event+0x3739>
    3a7d:      	movq	0x8(%rsp), %rax
    3a82:      	movl	$0x0, 0x20(%rax)
    3a89:      	movq	0x8(%rsp), %rdx
    3a8e:      	movzwl	0x20(%rdx), %eax
    3a92:      	movzwl	0x22(%rdx), %ecx
    3a96:      	movbew	%ax, 0x20(%rdx)
    3a9c:      	movbew	%cx, 0x22(%rdx)
    3aa2:      	addq	$0xe0, %r12
    3aa9:      	leaq	0xa0(%rsp), %rdi
    3ab1:      	movl	$0x8, %ecx
    3ab6:      	movl	$0x4, %eax
    3abb:      	movl	$0x4, %r15d
    3ac1:      	movl	$0x8, %esi
    3ac6:      	movq	%r12, %rdx
    3ac9:      	callq	*%rax
    3acb:      	movq	0xa0(%rsp), %rcx
    3ad3:      	testq	%rcx, %rcx
    3ad6:      	je	0x3b49 <generic_kprobe_process_event+0x37f9>
    3ad8:      	addq	$0x5, %rcx
    3adc:      	leaq	0x40(%rsp), %rdi
    3ae1:      	movl	$0x8, %edx
    3ae6:      	movl	$0x4, %eax
    3aeb:      	movq	0xa0(%rsp), %rdx
    3af3:      	addq	$0x5, %rdx
    3af7:      	movl	$0x8, %esi
    3afc:      	callq	*%rax
    3afe:      	movq	0xa0(%rsp), %r13
    3b06:      	movq	0x40(%rsp), %r12
    3b0b:      	movq	0x8(%rsp), %rbp
    3b10:      	leaq	0x38(%rbp), %rdi
    3b14:      	leaq	0x44(,%r12,8), %rdx
    3b1c:      	addq	%r13, %rdx
    3b1f:      	movl	$0x4, %eax
    3b24:      	movl	$0x4, %esi
    3b29:      	callq	*%rax
    3b2b:      	addq	$0x3c, %rbp
    3b2f:      	leaq	0x45(,%r12,8), %rdx
    3b37:      	addq	%r13, %rdx
    3b3a:      	movl	$0x4, %eax
    3b3f:      	movq	%rbp, %rdi
    3b42:      	movl	$0x4, %esi
    3b47:      	callq	*%rax
    3b49:      	movl	$0x40, %r15d
    3b4f:      	jmp	0x11e0 <generic_kprobe_process_event+0xe90>
    3b54:      	movw	%ax, 0xd0(%rsp)
    3b5c:      	jmp	0x398c <generic_kprobe_process_event+0x363c>
    3b61:      	nopw	%cs:(%rax,%rax)

0000000000003b70 <generic_kprobe_process_filter>:
    3b70:      	pushq	%rbp
    3b71:      	pushq	%r15
    3b73:      	pushq	%r14
    3b75:      	pushq	%r13
    3b77:      	pushq	%r12
    3b79:      	pushq	%rbx
    3b7a:      	subq	$0xe8, %rsp
    3b81:      	movq	%rdi, %rbx
    3b84:      	movl	$0x0, 0xc8(%rsp)
    3b8f:      	movq	(%rip), %rdi            # 0x3b96 <generic_kprobe_process_filter+0x26>
    3b96:      	leaq	0xc8(%rsp), %rsi
    3b9e:      	movl	$0x1, %eax
    3ba3:      	callq	*%rax
    3ba5:      	testq	%rax, %rax
    3ba8:      	je	0x6193 <generic_kprobe_process_filter+0x2623>
    3bae:      	movq	%rax, %r14
    3bb1:      	movl	$0x23, %eax
    3bb6:      	callq	*%rax
    3bb8:      	movq	%rax, %rcx
    3bbb:      	movq	%rax, 0x60(%rsp)
    3bc0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3bc7:      	leaq	0x10(%rsp), %rdi
    3bcc:      	movl	$0x4, %edx
    3bd1:      	movl	$0x71, %eax
    3bd6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3bdb:      	addq	0x60(%rsp), %rdx
    3be0:      	movl	$0x4, %esi
    3be5:      	callq	*%rax
    3be7:      	movl	0x10(%rsp), %eax
    3beb:      	movl	%eax, 0x40(%rsp)
    3bef:      	movq	(%rip), %rdi            # 0x3bf6 <generic_kprobe_process_filter+0x86>
    3bf6:      	leaq	0x40(%rsp), %rsi
    3bfb:      	movl	$0x1, %eax
    3c00:      	callq	*%rax
    3c02:      	testq	%rax, %rax
    3c05:      	movq	%r14, 0x50(%rsp)
    3c0a:      	je	0x3c1a <generic_kprobe_process_filter+0xaa>
    3c0c:      	movq	%rax, %r15
    3c0f:      	cmpq	$0x0, 0x8(%rax)
    3c14:      	jne	0x4b9f <generic_kprobe_process_filter+0x102f>
    3c1a:      	movl	$0xb00, %edx            # imm = 0xB00
    3c1f:      	movq	0x60(%rsp), %rcx
    3c24:      	addq	%rdx, %rcx
    3c27:      	leaq	0x60(%rsp), %rdi
    3c2c:      	movl	$0x8, %esi
    3c31:      	movl	$0x71, %eax
    3c36:      	addq	0x60(%rsp), %rdx
    3c3b:      	movl	$0x8, %esi
    3c40:      	callq	*%rax
    3c42:      	movq	0x60(%rsp), %rcx
    3c47:      	testq	%rcx, %rcx
    3c4a:      	je	0x3ddf <generic_kprobe_process_filter+0x26f>
    3c50:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3c57:      	leaq	0x10(%rsp), %rdi
    3c5c:      	movl	$0x4, %edx
    3c61:      	movl	$0x71, %eax
    3c66:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3c6b:      	addq	0x60(%rsp), %rdx
    3c70:      	movl	$0x4, %esi
    3c75:      	callq	*%rax
    3c77:      	movl	0x10(%rsp), %eax
    3c7b:      	movl	%eax, 0x40(%rsp)
    3c7f:      	movq	(%rip), %rdi            # 0x3c86 <generic_kprobe_process_filter+0x116>
    3c86:      	leaq	0x40(%rsp), %rsi
    3c8b:      	movl	$0x1, %eax
    3c90:      	callq	*%rax
    3c92:      	testq	%rax, %rax
    3c95:      	je	0x3ca5 <generic_kprobe_process_filter+0x135>
    3c97:      	movq	%rax, %r15
    3c9a:      	cmpq	$0x0, 0x8(%rax)
    3c9f:      	jne	0x4b9f <generic_kprobe_process_filter+0x102f>
    3ca5:      	movl	$0xb00, %edx            # imm = 0xB00
    3caa:      	movq	0x60(%rsp), %rcx
    3caf:      	addq	%rdx, %rcx
    3cb2:      	leaq	0x60(%rsp), %rdi
    3cb7:      	movl	$0x8, %esi
    3cbc:      	movl	$0x71, %eax
    3cc1:      	addq	0x60(%rsp), %rdx
    3cc6:      	movl	$0x8, %esi
    3ccb:      	callq	*%rax
    3ccd:      	movq	0x60(%rsp), %rcx
    3cd2:      	testq	%rcx, %rcx
    3cd5:      	je	0x3ddf <generic_kprobe_process_filter+0x26f>
    3cdb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3ce2:      	leaq	0x10(%rsp), %rdi
    3ce7:      	movl	$0x4, %edx
    3cec:      	movl	$0x71, %eax
    3cf1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3cf6:      	addq	0x60(%rsp), %rdx
    3cfb:      	movl	$0x4, %esi
    3d00:      	callq	*%rax
    3d02:      	movl	0x10(%rsp), %eax
    3d06:      	movl	%eax, 0x40(%rsp)
    3d0a:      	movq	(%rip), %rdi            # 0x3d11 <generic_kprobe_process_filter+0x1a1>
    3d11:      	leaq	0x40(%rsp), %rsi
    3d16:      	movl	$0x1, %eax
    3d1b:      	callq	*%rax
    3d1d:      	testq	%rax, %rax
    3d20:      	je	0x3d30 <generic_kprobe_process_filter+0x1c0>
    3d22:      	movq	%rax, %r15
    3d25:      	cmpq	$0x0, 0x8(%rax)
    3d2a:      	jne	0x4b9f <generic_kprobe_process_filter+0x102f>
    3d30:      	movl	$0xb00, %edx            # imm = 0xB00
    3d35:      	movq	0x60(%rsp), %rcx
    3d3a:      	addq	%rdx, %rcx
    3d3d:      	leaq	0x60(%rsp), %rdi
    3d42:      	movl	$0x8, %esi
    3d47:      	movl	$0x71, %eax
    3d4c:      	addq	0x60(%rsp), %rdx
    3d51:      	movl	$0x8, %esi
    3d56:      	callq	*%rax
    3d58:      	movq	0x60(%rsp), %rcx
    3d5d:      	testq	%rcx, %rcx
    3d60:      	je	0x3ddf <generic_kprobe_process_filter+0x26f>
    3d62:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3d69:      	leaq	0x10(%rsp), %rdi
    3d6e:      	movl	$0x4, %edx
    3d73:      	movl	$0x71, %eax
    3d78:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3d7d:      	addq	0x60(%rsp), %rdx
    3d82:      	movl	$0x4, %esi
    3d87:      	callq	*%rax
    3d89:      	movl	0x10(%rsp), %eax
    3d8d:      	movl	%eax, 0x40(%rsp)
    3d91:      	movq	(%rip), %rdi            # 0x3d98 <generic_kprobe_process_filter+0x228>
    3d98:      	leaq	0x40(%rsp), %rsi
    3d9d:      	movl	$0x1, %eax
    3da2:      	callq	*%rax
    3da4:      	testq	%rax, %rax
    3da7:      	je	0x3db7 <generic_kprobe_process_filter+0x247>
    3da9:      	movq	%rax, %r15
    3dac:      	cmpq	$0x0, 0x8(%rax)
    3db1:      	jne	0x4b9f <generic_kprobe_process_filter+0x102f>
    3db7:      	movl	$0xb00, %edx            # imm = 0xB00
    3dbc:      	movq	0x60(%rsp), %rcx
    3dc1:      	addq	%rdx, %rcx
    3dc4:      	leaq	0x60(%rsp), %rdi
    3dc9:      	movl	$0x8, %esi
    3dce:      	movl	$0x71, %eax
    3dd3:      	addq	0x60(%rsp), %rdx
    3dd8:      	movl	$0x8, %esi
    3ddd:      	callq	*%rax
    3ddf:      	movq	%rbx, 0xb8(%rsp)
    3de7:      	movl	$0x23, %eax
    3dec:      	callq	*%rax
    3dee:      	movq	%rax, %r13
    3df1:      	leaq	0xaf4(%rax), %rdx
    3df8:      	leaq	0x60(%rsp), %rdi
    3dfd:      	movl	$0x4, %ecx
    3e02:      	movl	$0x4, %eax
    3e07:      	movl	$0x4, %ebp
    3e0c:      	movl	$0x4, %esi
    3e11:      	callq	*%rax
    3e13:      	movl	0x60(%rsp), %eax
    3e17:      	movl	%eax, 0x5f10(%r14)
    3e1e:      	movl	$0x7d, %eax
    3e23:      	callq	*%rax
    3e25:      	movq	%rax, 0x5f18(%r14)
    3e2c:      	movl	$0x0, 0x5f20(%r14)
    3e37:      	movq	$0x0, 0x5f28(%r14)
    3e42:      	movl	$0x0, 0x5f30(%r14)
    3e4d:      	leaq	0x60(%r13), %rdx
    3e51:      	leaq	0x40(%rsp), %rdi
    3e56:      	movl	$0x8, %ecx
    3e5b:      	movl	$0x71, %eax
    3e60:      	movl	$0x8, %esi
    3e65:      	callq	*%rax
    3e67:      	movq	0x40(%rsp), %rcx
    3e6c:      	xorl	%ebx, %ebx
    3e6e:      	testq	%rcx, %rcx
    3e71:      	je	0x3ee0 <generic_kprobe_process_filter+0x370>
    3e73:      	addq	$0x4, %rcx
    3e77:      	leaq	0x10(%rsp), %rdi
    3e7c:      	movl	$0x4, %edx
    3e81:      	movl	$0x71, %eax
    3e86:      	movq	0x40(%rsp), %rdx
    3e8b:      	addq	$0x4, %rdx
    3e8f:      	movl	$0x4, %esi
    3e94:      	callq	*%rax
    3e96:      	movl	0x10(%rsp), %eax
    3e9a:      	testl	%eax, %eax
    3e9c:      	je	0x3ee0 <generic_kprobe_process_filter+0x370>
    3e9e:      	movq	0x40(%rsp), %rcx
    3ea3:      	shll	$0x4, %eax
    3ea6:      	addq	%rax, %rcx
    3ea9:      	addq	$0x80, %rcx
    3eb0:      	leaq	0x60(%rsp), %rdi
    3eb5:      	movl	$0x10, %edx
    3eba:      	movl	$0x71, %eax
    3ebf:      	movq	0x40(%rsp), %rcx
    3ec4:      	movl	0x10(%rsp), %edx
    3ec8:      	shll	$0x4, %edx
    3ecb:      	addq	%rcx, %rdx
    3ece:      	addq	$0x80, %rdx
    3ed5:      	movl	$0x10, %esi
    3eda:      	callq	*%rax
    3edc:      	movl	0x60(%rsp), %ebx
    3ee0:      	movl	%ebx, 0x5f34(%r14)
    3ee7:      	leaq	0xd00(%r13), %r15
    3eee:      	leaq	0x60(%rsp), %rdi
    3ef3:      	movl	$0x8, %ecx
    3ef8:      	movl	$0x4, %eax
    3efd:      	leaq	0x5f60(%r14), %rbx
    3f04:      	movl	$0x8, %esi
    3f09:      	movq	%r15, %rdx
    3f0c:      	callq	*%rax
    3f0e:      	movq	0x60(%rsp), %r12
    3f13:      	leaq	0x5f68(%r14), %rdi
    3f1a:      	leaq	0x40(%r12), %rdx
    3f1f:      	movl	$0x8, %ecx
    3f24:      	movl	$0x4, %eax
    3f29:      	movl	$0x8, %esi
    3f2e:      	callq	*%rax
    3f30:      	leaq	0x5f70(%r14), %rdi
    3f37:      	leaq	0x30(%r12), %rdx
    3f3c:      	movl	$0x8, %ecx
    3f41:      	movl	$0x4, %eax
    3f46:      	movl	$0x8, %esi
    3f4b:      	callq	*%rax
    3f4d:      	addq	$0x38, %r12
    3f51:      	movl	$0x8, %ecx
    3f56:      	movl	$0x4, %eax
    3f5b:      	movq	%rbx, %rdi
    3f5e:      	movl	$0x8, %esi
    3f63:      	movq	%r12, %rdx
    3f66:      	callq	*%rax
    3f68:      	leaq	0x5f38(%r14), %rbx
    3f6f:      	leaq	0xd70(%r13), %rdx
    3f76:      	leaq	0x10(%rsp), %rdi
    3f7b:      	movl	$0x8, %ecx
    3f80:      	movl	$0x4, %eax
    3f85:      	movl	$0x8, %esi
    3f8a:      	callq	*%rax
    3f8c:      	movq	0x10(%rsp), %rcx
    3f91:      	leaq	0x60(%rsp), %rdi
    3f96:      	movl	$0x48, %edx
    3f9b:      	movl	$0x4, %eax
    3fa0:      	movq	0x10(%rsp), %rdx
    3fa5:      	movl	$0x48, %esi
    3faa:      	callq	*%rax
    3fac:      	movl	$0x218, %edx            # imm = 0x218
    3fb1:      	movq	0x68(%rsp), %rcx
    3fb6:      	addq	%rdx, %rcx
    3fb9:      	movl	$0x4, %eax
    3fbe:      	addq	0x68(%rsp), %rdx
    3fc3:      	movq	%rbx, %rdi
    3fc6:      	movl	$0x4, %esi
    3fcb:      	callq	*%rax
    3fcd:      	leaq	0x5f3c(%r14), %rdi
    3fd4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    3fd9:      	movq	0x70(%rsp), %rcx
    3fde:      	addq	%rdx, %rcx
    3fe1:      	movl	$0x4, %eax
    3fe6:      	addq	0x70(%rsp), %rdx
    3feb:      	movl	$0x4, %esi
    3ff0:      	callq	*%rax
    3ff2:      	leaq	0x5f40(%r14), %rdi
    3ff9:      	movq	0x78(%rsp), %rcx
    3ffe:      	addq	$0x58, %rcx
    4002:      	movl	$0x4, %eax
    4007:      	movq	0x78(%rsp), %rdx
    400c:      	addq	$0x58, %rdx
    4010:      	movl	$0x4, %esi
    4015:      	callq	*%rax
    4017:      	movq	$0x0, 0x58(%rsp)
    4020:      	leaq	0xb58(%r13), %rdx
    4027:      	leaq	0x58(%rsp), %rdi
    402c:      	movl	$0x8, %ecx
    4031:      	movl	$0x4, %eax
    4036:      	movl	$0x8, %esi
    403b:      	callq	*%rax
    403d:      	movq	0x58(%rsp), %rcx
    4042:      	testq	%rcx, %rcx
    4045:      	je	0x40f4 <generic_kprobe_process_filter+0x584>
    404b:      	movl	$0x0, 0xa8(%rsp)
    4056:      	addq	$0x4, %rcx
    405a:      	leaq	0xa8(%rsp), %rdi
    4062:      	movl	$0x4, %edx
    4067:      	movl	$0x4, %eax
    406c:      	movq	0x58(%rsp), %rdx
    4071:      	addq	$0x4, %rdx
    4075:      	movl	$0x4, %esi
    407a:      	callq	*%rax
    407c:      	movq	0x58(%rsp), %rax
    4081:      	movslq	0xa8(%rsp), %rcx
    4089:      	shlq	$0x4, %rcx
    408d:      	addq	%rax, %rcx
    4090:      	addq	$0x80, %rcx
    4097:      	leaq	0x40(%rsp), %rdi
    409c:      	movl	$0x10, %edx
    40a1:      	movl	$0x4, %eax
    40a6:      	movq	0x58(%rsp), %rcx
    40ab:      	movslq	0xa8(%rsp), %rdx
    40b3:      	shlq	$0x4, %rdx
    40b7:      	addq	%rcx, %rdx
    40ba:      	addq	$0x80, %rdx
    40c1:      	movl	$0x10, %esi
    40c6:      	callq	*%rax
    40c8:      	leaq	0x5f44(%r14), %rdi
    40cf:      	movl	$0x158, %edx            # imm = 0x158
    40d4:      	movq	0x48(%rsp), %rcx
    40d9:      	addq	%rdx, %rcx
    40dc:      	movl	$0x4, %esi
    40e1:      	movl	$0x4, %eax
    40e6:      	addq	0x48(%rsp), %rdx
    40eb:      	movl	$0x4, %esi
    40f0:      	callq	*%rax
    40f2:      	jmp	0x40ff <generic_kprobe_process_filter+0x58f>
    40f4:      	movl	$0x0, 0x5f44(%r14)
    40ff:      	leaq	0x5f48(%r14), %rdi
    4106:      	movl	$0x158, %ebx            # imm = 0x158
    410b:      	movq	0x80(%rsp), %rcx
    4113:      	addq	%rbx, %rcx
    4116:      	movl	$0x4, %edx
    411b:      	movl	$0x4, %eax
    4120:      	movq	0x80(%rsp), %rdx
    4128:      	addq	%rbx, %rdx
    412b:      	movl	$0x4, %esi
    4130:      	callq	*%rax
    4132:      	leaq	0x5f4c(%r14), %rdi
    4139:      	movl	$0x118, %edx            # imm = 0x118
    413e:      	movq	0x88(%rsp), %rcx
    4146:      	addq	%rdx, %rcx
    4149:      	movl	$0x4, %esi
    414e:      	movl	$0x4, %eax
    4153:      	addq	0x88(%rsp), %rdx
    415b:      	movl	$0x4, %esi
    4160:      	callq	*%rax
    4162:      	leaq	0x5f50(%r14), %rdi
    4169:      	movl	$0x98, %r12d
    416f:      	movq	0x90(%rsp), %rcx
    4177:      	addq	%r12, %rcx
    417a:      	movl	$0x4, %edx
    417f:      	movl	$0x4, %eax
    4184:      	movq	0x90(%rsp), %rdx
    418c:      	addq	%r12, %rdx
    418f:      	movl	$0x4, %esi
    4194:      	callq	*%rax
    4196:      	leaq	0x5f54(%r14), %rdi
    419d:      	movq	0x98(%rsp), %rcx
    41a5:      	addq	%r12, %rcx
    41a8:      	movl	$0x4, %edx
    41ad:      	movl	$0x4, %eax
    41b2:      	addq	0x98(%rsp), %r12
    41ba:      	movl	$0x4, %esi
    41bf:      	movq	%r12, %rdx
    41c2:      	callq	*%rax
    41c4:      	leaq	0x5f58(%r14), %rdi
    41cb:      	movq	0xa0(%rsp), %rcx
    41d3:      	addq	$0x58, %rcx
    41d7:      	movl	$0x4, %edx
    41dc:      	movl	$0x4, %eax
    41e1:      	movq	0xa0(%rsp), %rdx
    41e9:      	addq	$0x58, %rdx
    41ed:      	movl	$0x4, %esi
    41f2:      	callq	*%rax
    41f4:      	movq	$0x0, 0x40(%rsp)
    41fd:      	movq	$0x0, 0x58(%rsp)
    4206:      	leaq	0x40(%rsp), %rdi
    420b:      	movl	$0x8, %ecx
    4210:      	movl	$0x4, %eax
    4215:      	movl	$0x8, %esi
    421a:      	movq	%r15, %rdx
    421d:      	callq	*%rax
    421f:      	movl	$0x90, %edx
    4224:      	movq	0x40(%rsp), %rcx
    4229:      	addq	%rdx, %rcx
    422c:      	leaq	0x58(%rsp), %rdi
    4231:      	movl	$0x8, %esi
    4236:      	movl	$0x4, %eax
    423b:      	addq	0x40(%rsp), %rdx
    4240:      	movl	$0x8, %esi
    4245:      	callq	*%rax
    4247:      	leaq	0x5f5c(%r14), %rdi
    424e:      	movq	0x58(%rsp), %rcx
    4253:      	addq	%rbx, %rcx
    4256:      	movl	$0x4, %edx
    425b:      	movl	$0x4, %eax
    4260:      	addq	0x58(%rsp), %rbx
    4265:      	movl	$0x4, %esi
    426a:      	movq	%rbx, %rdx
    426d:      	callq	*%rax
    426f:      	cmpl	$0x1, 0x5f34(%r14)
    4277:      	jne	0x4281 <generic_kprobe_process_filter+0x711>
    4279:      	orb	$0x2, 0x5f33(%r14)
    4281:      	leaq	0x5f78(%r14), %rdi
    4288:      	movl	$0x308, %edx            # imm = 0x308
    428d:      	movq	%rdi, 0x8(%rsp)
    4292:      	xorl	%esi, %esi
    4294:      	callq	0x4299 <generic_kprobe_process_filter+0x729>
    4299:      	leaq	0x6290(%r14), %rbp
    42a0:      	addq	$0xa78, %r13            # imm = 0xA78
    42a7:      	leaq	0x40(%rsp), %rdi
    42ac:      	movl	$0x8, %ecx
    42b1:      	movl	$0x4, %eax
    42b6:      	movl	$0x8, %esi
    42bb:      	movq	%r13, %rdx
    42be:      	callq	*%rax
    42c0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    42c5:      	movq	0x40(%rsp), %rcx
    42ca:      	addq	%rdx, %rcx
    42cd:      	leaq	0x60(%rsp), %rdi
    42d2:      	movl	$0x8, %esi
    42d7:      	movl	$0x4, %eax
    42dc:      	addq	0x40(%rsp), %rdx
    42e1:      	movl	$0x8, %esi
    42e6:      	callq	*%rax
    42e8:      	movq	0x60(%rsp), %rbx
    42ed:      	movl	$0x0, 0xcc(%rsp)
    42f8:      	movq	(%rip), %rdi            # 0x42ff <generic_kprobe_process_filter+0x78f>
    42ff:      	leaq	0xcc(%rsp), %rsi
    4307:      	movl	$0x1, %eax
    430c:      	callq	*%rax
    430e:      	testq	%rax, %rax
    4311:      	je	0x4a17 <generic_kprobe_process_filter+0xea7>
    4317:      	movq	%rax, %r12
    431a:      	movq	%rbp, 0x38(%rsp)
    431f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    432a:      	leaq	0x1000(%rax), %r13
    4331:      	movl	$0x23, %eax
    4336:      	callq	*%rax
    4338:      	leaq	0xd50(%rax), %rdx
    433f:      	leaq	0xd8(%rsp), %rdi
    4347:      	movl	$0x8, %ecx
    434c:      	movl	$0x4, %eax
    4351:      	movl	$0x8, %esi
    4356:      	callq	*%rax
    4358:      	movq	0xd8(%rsp), %rbp
    4360:      	leaq	0x48(%rbx), %r15
    4364:      	leaq	0xe0(%rsp), %rdi
    436c:      	movl	$0x8, %ecx
    4371:      	movl	$0x4, %eax
    4376:      	movl	$0x8, %esi
    437b:      	movq	%r15, %rdx
    437e:      	callq	*%rax
    4380:      	movq	0xe0(%rsp), %r14
    4388:      	leaq	0x10(%r14), %rdx
    438c:      	leaq	0x60(%rsp), %rdi
    4391:      	movl	$0x8, %ecx
    4396:      	movl	$0x4, %eax
    439b:      	movl	$0x8, %esi
    43a0:      	callq	*%rax
    43a2:      	cmpq	$0x0, 0x60(%rsp)
    43a8:      	je	0x4676 <generic_kprobe_process_filter+0xb06>
    43ae:      	movq	0x50(%rsp), %r14
    43b3:      	movq	$0x0, 0x68(%rsp)
    43bc:      	movq	$0x0, 0x60(%rsp)
    43c5:      	movq	%r12, 0x70(%rsp)
    43ca:      	movq	$0x0, 0x78(%rsp)
    43d3:      	movq	$0x0, 0x80(%rsp)
    43df:      	movq	$0x0, 0x88(%rsp)
    43eb:      	movq	%r13, 0xc0(%rsp)
    43f3:      	movq	%r13, 0x90(%rsp)
    43fb:      	movl	0x6410(%r14), %eax
    4402:      	movl	%eax, 0x98(%rsp)
    4409:      	leaq	0x18(%rbp), %r13
    440d:      	movb	$0x0, 0x9c(%rsp)
    4415:      	addq	$0x20, %rbp
    4419:      	leaq	0x60(%rsp), %rdi
    441e:      	movl	$0x8, %ecx
    4423:      	movl	$0x4, %eax
    4428:      	addq	$0x40, %rbx
    442c:      	leaq	0x68(%rsp), %r12
    4431:      	leaq	0x78(%rsp), %r14
    4436:      	movl	$0x8, %esi
    443b:      	movq	%rbp, %rdx
    443e:      	callq	*%rax
    4440:      	movl	$0x8, %ecx
    4445:      	movl	$0x4, %eax
    444a:      	movq	%r12, %rdi
    444d:      	movl	$0x8, %esi
    4452:      	movq	%r13, %rdx
    4455:      	callq	*%rax
    4457:      	movl	$0x8, %ecx
    445c:      	movl	$0x4, %eax
    4461:      	movq	%r14, %rdi
    4464:      	movl	$0x8, %esi
    4469:      	movq	%r15, %rdx
    446c:      	callq	*%rax
    446e:      	movl	$0x8, %ecx
    4473:      	movl	$0x4, %eax
    4478:      	leaq	0x80(%rsp), %rdi
    4480:      	movl	$0x8, %esi
    4485:      	movq	%rbx, %rdx
    4488:      	callq	*%rax
    448a:      	movq	0x80(%rsp), %rax
    4492:      	addq	$-0x20, %rax
    4496:      	movq	%rax, 0x88(%rsp)
    449e:      	movq	(%rip), %rax            # 0x44a5 <generic_kprobe_process_filter+0x935>
    44a5:      	cmpb	$0x0, (%rax)
    44a8:      	je	0x46cd <generic_kprobe_process_filter+0xb5d>
    44ae:      	movl	$0x800, %r14d           # imm = 0x800
    44b4:      	movl	$0x8, %ebp
    44b9:      	leaq	0x10(%rsp), %rbx
    44be:      	nop
    44c0:      	movq	0x78(%rsp), %r15
    44c5:      	movq	0x80(%rsp), %rdx
    44cd:      	movq	0x88(%rsp), %r12
    44d5:      	cmpq	0x60(%rsp), %r15
    44da:      	jne	0x44e7 <generic_kprobe_process_filter+0x977>
    44dc:      	cmpq	0x68(%rsp), %rdx
    44e1:      	je	0x488f <generic_kprobe_process_filter+0xd1f>
    44e7:      	movl	$0x4, %eax
    44ec:      	leaq	0xa8(%rsp), %rdi
    44f4:      	movl	$0x8, %esi
    44f9:      	callq	*%rax
    44fb:      	cmpq	0xa8(%rsp), %r15
    4503:      	je	0x4610 <generic_kprobe_process_filter+0xaa0>
    4509:      	leaq	0x18(%r15), %r13
    450d:      	movl	$0x4, %eax
    4512:      	movq	%rbx, %rdi
    4515:      	movl	$0x8, %esi
    451a:      	movq	%r13, %rdx
    451d:      	callq	*%rax
    451f:      	cmpq	%r15, 0x10(%rsp)
    4524:      	je	0x4610 <generic_kprobe_process_filter+0xaa0>
    452a:      	movl	$0x4, %eax
    452f:      	leaq	0x58(%rsp), %rdi
    4534:      	movl	$0x8, %esi
    4539:      	movq	%r13, %rdx
    453c:      	callq	*%rax
    453e:      	addq	$0x20, %r15
    4542:      	movl	$0x4, %eax
    4547:      	leaq	0x40(%rsp), %rdi
    454c:      	movl	$0x10, %ecx
    4551:      	movl	$0x10, %esi
    4556:      	movq	%r15, %rdx
    4559:      	callq	*%rax
    455b:      	movq	0x70(%rsp), %r15
    4560:      	movq	0x90(%rsp), %rax
    4568:      	movl	0x44(%rsp), %r12d
    456d:      	subq	%r15, %rax
    4570:      	movl	0x98(%rsp), %r13d
    4578:      	movl	%r12d, %edx
    457b:      	subl	%r13d, %edx
    457e:      	movl	$0x0, %ecx
    4583:      	cmovbl	%ecx, %edx
    4586:      	addq	0x48(%rsp), %rdx
    458b:      	xorl	%esi, %esi
    458d:      	cmpl	%r12d, %r13d
    4590:      	seta	%sil
    4594:      	movl	%r12d, %ecx
    4597:      	cmovbl	%r13d, %ecx
    459b:      	addl	%ecx, %esi
    459d:      	movl	%r13d, %edi
    45a0:      	subl	%esi, %edi
    45a2:      	movl	%edi, 0x98(%rsp)
    45a9:      	subq	%rsi, %rax
    45ac:      	jb	0x4897 <generic_kprobe_process_filter+0xd27>
    45b2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    45b8:      	ja	0x4897 <generic_kprobe_process_filter+0xd27>
    45be:      	cmpl	%r12d, %r13d
    45c1:      	jbe	0x45c8 <generic_kprobe_process_filter+0xa58>
    45c3:      	movb	$0x2f, (%r15,%rax)
    45c8:      	xorl	%edi, %edi
    45ca:      	cmpl	%r12d, %r13d
    45cd:      	seta	%dil
    45d1:      	movzbl	%cl, %esi
    45d4:      	addq	%rax, %r15
    45d7:      	addq	%r15, %rdi
    45da:      	movl	$0x4, %eax
    45df:      	callq	*%rax
    45e1:      	movq	%r15, 0x90(%rsp)
    45e9:      	cmpl	%r12d, %r13d
    45ec:      	jbe	0x4897 <generic_kprobe_process_filter+0xd27>
    45f2:      	movq	0x58(%rsp), %rax
    45f7:      	movq	%rax, 0x78(%rsp)
    45fc:      	decl	%r14d
    45ff:      	jne	0x44c0 <generic_kprobe_process_filter+0x950>
    4605:      	jmp	0x4897 <generic_kprobe_process_filter+0xd27>
    460a:      	nopw	(%rax,%rax)
    4610:      	leaq	0x10(%r12), %rdx
    4615:      	movl	$0x4, %eax
    461a:      	movq	%rbx, %rdi
    461d:      	movl	$0x8, %esi
    4622:      	callq	*%rax
    4624:      	movq	0x88(%rsp), %rax
    462c:      	cmpq	0x10(%rsp), %rax
    4631:      	je	0x488f <generic_kprobe_process_filter+0xd1f>
    4637:      	addq	$0x18, %r12
    463b:      	movl	$0x4, %eax
    4640:      	leaq	0x78(%rsp), %rdi
    4645:      	movl	$0x8, %esi
    464a:      	movq	%r12, %rdx
    464d:      	callq	*%rax
    464f:      	movq	0x10(%rsp), %rax
    4654:      	movq	%rax, 0x88(%rsp)
    465c:      	addq	$0x20, %rax
    4660:      	movq	%rax, 0x80(%rsp)
    4668:      	decl	%r14d
    466b:      	jne	0x44c0 <generic_kprobe_process_filter+0x950>
    4671:      	jmp	0x4897 <generic_kprobe_process_filter+0xd27>
    4676:      	leaq	0x18(%r14), %rdx
    467a:      	leaq	0x60(%rsp), %rdi
    467f:      	movl	$0x8, %ecx
    4684:      	movl	$0x4, %eax
    4689:      	movl	$0x8, %esi
    468e:      	callq	*%rax
    4690:      	cmpq	%r14, 0x60(%rsp)
    4695:      	je	0x43ae <generic_kprobe_process_filter+0x83e>
    469b:      	movq	0x50(%rsp), %r14
    46a0:      	movl	0x6410(%r14), %ecx
    46a7:      	leal	-0xa(%rcx), %eax
    46aa:      	movl	%eax, 0x6410(%r14)
    46b1:      	cmpl	$0x9, %ecx
    46b4:      	jg	0x5054 <generic_kprobe_process_filter+0x14e4>
    46ba:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    46c5:      	movq	%r13, %rbx
    46c8:      	jmp	0x4918 <generic_kprobe_process_filter+0xda8>
    46cd:      	movl	$0x800, %r14d           # imm = 0x800
    46d3:      	movl	$0x8, %ebp
    46d8:      	leaq	0x10(%rsp), %rbx
    46dd:      	nopl	(%rax)
    46e0:      	movq	0x78(%rsp), %r15
    46e5:      	movq	0x80(%rsp), %rdx
    46ed:      	movq	0x88(%rsp), %r12
    46f5:      	cmpq	0x60(%rsp), %r15
    46fa:      	jne	0x4707 <generic_kprobe_process_filter+0xb97>
    46fc:      	cmpq	0x68(%rsp), %rdx
    4701:      	je	0x488f <generic_kprobe_process_filter+0xd1f>
    4707:      	movl	$0x4, %eax
    470c:      	leaq	0xa8(%rsp), %rdi
    4714:      	movl	$0x8, %esi
    4719:      	callq	*%rax
    471b:      	cmpq	0xa8(%rsp), %r15
    4723:      	je	0x4830 <generic_kprobe_process_filter+0xcc0>
    4729:      	leaq	0x18(%r15), %r13
    472d:      	movl	$0x4, %eax
    4732:      	movq	%rbx, %rdi
    4735:      	movl	$0x8, %esi
    473a:      	movq	%r13, %rdx
    473d:      	callq	*%rax
    473f:      	cmpq	%r15, 0x10(%rsp)
    4744:      	je	0x4830 <generic_kprobe_process_filter+0xcc0>
    474a:      	movl	$0x4, %eax
    474f:      	leaq	0x58(%rsp), %rdi
    4754:      	movl	$0x8, %esi
    4759:      	movq	%r13, %rdx
    475c:      	callq	*%rax
    475e:      	addq	$0x20, %r15
    4762:      	movl	$0x4, %eax
    4767:      	leaq	0x40(%rsp), %rdi
    476c:      	movl	$0x10, %ecx
    4771:      	movl	$0x10, %esi
    4776:      	movq	%r15, %rdx
    4779:      	callq	*%rax
    477b:      	movq	0x70(%rsp), %r15
    4780:      	movq	0x90(%rsp), %rax
    4788:      	movl	0x44(%rsp), %r12d
    478d:      	subq	%r15, %rax
    4790:      	movl	0x98(%rsp), %r13d
    4798:      	movl	%r12d, %edx
    479b:      	subl	%r13d, %edx
    479e:      	movl	$0x0, %ecx
    47a3:      	cmovbl	%ecx, %edx
    47a6:      	addq	0x48(%rsp), %rdx
    47ab:      	xorl	%esi, %esi
    47ad:      	cmpl	%r12d, %r13d
    47b0:      	seta	%sil
    47b4:      	movl	%r12d, %ecx
    47b7:      	cmovbl	%r13d, %ecx
    47bb:      	addl	%ecx, %esi
    47bd:      	movl	%r13d, %edi
    47c0:      	subl	%esi, %edi
    47c2:      	movl	%edi, 0x98(%rsp)
    47c9:      	subq	%rsi, %rax
    47cc:      	jb	0x4897 <generic_kprobe_process_filter+0xd27>
    47d2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    47d8:      	ja	0x4897 <generic_kprobe_process_filter+0xd27>
    47de:      	cmpl	%r12d, %r13d
    47e1:      	jbe	0x47e8 <generic_kprobe_process_filter+0xc78>
    47e3:      	movb	$0x2f, (%r15,%rax)
    47e8:      	xorl	%edi, %edi
    47ea:      	cmpl	%r12d, %r13d
    47ed:      	seta	%dil
    47f1:      	movzbl	%cl, %esi
    47f4:      	addq	%rax, %r15
    47f7:      	addq	%r15, %rdi
    47fa:      	movl	$0x4, %eax
    47ff:      	callq	*%rax
    4801:      	movq	%r15, 0x90(%rsp)
    4809:      	cmpl	%r12d, %r13d
    480c:      	jbe	0x4897 <generic_kprobe_process_filter+0xd27>
    4812:      	movq	0x58(%rsp), %rax
    4817:      	movq	%rax, 0x78(%rsp)
    481c:      	decl	%r14d
    481f:      	jne	0x46e0 <generic_kprobe_process_filter+0xb70>
    4825:      	jmp	0x4897 <generic_kprobe_process_filter+0xd27>
    4827:      	nopw	(%rax,%rax)
    4830:      	leaq	0x10(%r12), %rdx
    4835:      	movl	$0x4, %eax
    483a:      	movq	%rbx, %rdi
    483d:      	movl	$0x8, %esi
    4842:      	callq	*%rax
    4844:      	movq	0x88(%rsp), %rax
    484c:      	cmpq	0x10(%rsp), %rax
    4851:      	je	0x488f <generic_kprobe_process_filter+0xd1f>
    4853:      	addq	$0x18, %r12
    4857:      	movl	$0x4, %eax
    485c:      	leaq	0x78(%rsp), %rdi
    4861:      	movl	$0x8, %esi
    4866:      	movq	%r12, %rdx
    4869:      	callq	*%rax
    486b:      	movq	0x10(%rsp), %rax
    4870:      	movq	%rax, 0x88(%rsp)
    4878:      	addq	$0x20, %rax
    487c:      	movq	%rax, 0x80(%rsp)
    4884:      	decl	%r14d
    4887:      	jne	0x46e0 <generic_kprobe_process_filter+0xb70>
    488d:      	jmp	0x4897 <generic_kprobe_process_filter+0xd27>
    488f:      	movb	$0x1, 0x9c(%rsp)
    4897:      	movq	0x90(%rsp), %rbx
    489f:      	movq	0xc0(%rsp), %rcx
    48a7:      	cmpq	%rcx, %rbx
    48aa:      	je	0x48f8 <generic_kprobe_process_filter+0xd88>
    48ac:      	xorl	%ecx, %ecx
    48ae:      	cmpb	$0x0, 0x9c(%rsp)
    48b6:      	sete	%cl
    48b9:      	addl	%ecx, %ecx
    48bb:      	movl	0x98(%rsp), %eax
    48c2:      	movq	0x50(%rsp), %r14
    48c7:      	movl	%eax, 0x6410(%r14)
    48ce:      	movl	%ecx, 0x6414(%r14)
    48d5:      	testl	%eax, %eax
    48d7:      	movq	0x38(%rsp), %rbp
    48dc:      	jle	0x48ee <generic_kprobe_process_filter+0xd7e>
    48de:      	movl	$0x1000, %ecx           # imm = 0x1000
    48e3:      	subl	%eax, %ecx
    48e5:      	movl	%ecx, 0x6410(%r14)
    48ec:      	movl	%ecx, %eax
    48ee:      	testq	%rbx, %rbx
    48f1:      	jne	0x491d <generic_kprobe_process_filter+0xdad>
    48f3:      	jmp	0x4a17 <generic_kprobe_process_filter+0xea7>
    48f8:      	movq	0x50(%rsp), %r14
    48fd:      	movl	$0x0, 0x6410(%r14)
    4908:      	movl	$0x0, 0x6414(%r14)
    4913:      	xorl	%eax, %eax
    4915:      	movq	%rcx, %rbx
    4918:      	movq	0x38(%rsp), %rbp
    491d:      	xorl	%ecx, %ecx
    491f:      	movq	%r14, %rdx
    4922:      	movl	%eax, %r14d
    4925:      	subl	$0x7f, %r14d
    4929:      	movl	$0x7f, %r15d
    492f:      	cmovbl	%eax, %r15d
    4933:      	cmovbl	%ecx, %r14d
    4937:      	cmpl	$0xff, %eax
    493c:      	movl	$0xff, %ecx
    4941:      	cmovbl	%eax, %ecx
    4944:      	movzbl	%cl, %esi
    4947:      	movl	%esi, 0x6410(%rdx)
    494d:      	movl	$0x4, %eax
    4952:      	movq	%rbp, %rdi
    4955:      	movq	%rbx, %rdx
    4958:      	callq	*%rax
    495a:      	testq	%rax, %rax
    495d:      	je	0x49bc <generic_kprobe_process_filter+0xe4c>
    495f:      	negl	%eax
    4961:      	movw	%ax, 0x60(%rsp)
    4966:      	movw	$0x8, 0x62(%rsp)
    496d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4977:      	movq	%rax, 0x64(%rsp)
    497c:      	movq	(%rip), %rdi            # 0x4983 <generic_kprobe_process_filter+0xe13>
    4983:      	leaq	0x60(%rsp), %rsi
    4988:      	movl	$0x1, %eax
    498d:      	callq	*%rax
    498f:      	testq	%rax, %rax
    4992:      	je	0x4998 <generic_kprobe_process_filter+0xe28>
    4994:      	incl	(%rax)
    4996:      	jmp	0x49bc <generic_kprobe_process_filter+0xe4c>
    4998:      	movl	$0x1, 0x40(%rsp)
    49a0:      	movq	(%rip), %rdi            # 0x49a7 <generic_kprobe_process_filter+0xe37>
    49a7:      	xorl	%ecx, %ecx
    49a9:      	leaq	0x60(%rsp), %rsi
    49ae:      	leaq	0x40(%rsp), %rdx
    49b3:      	movl	$0x2, %eax
    49b8:      	xorl	%ecx, %ecx
    49ba:      	callq	*%rax
    49bc:      	movq	0x50(%rsp), %rax
    49c1:      	leaq	0x6390(%rax), %rdi
    49c8:      	addq	%r14, %rbx
    49cb:      	movq	%rax, %r14
    49ce:      	movl	$0x4, %eax
    49d3:      	movl	%r15d, %esi
    49d6:      	movq	%rbx, %rdx
    49d9:      	callq	*%rax
    49db:      	testq	%rax, %rax
    49de:      	je	0x4a17 <generic_kprobe_process_filter+0xea7>
    49e0:      	negl	%eax
    49e2:      	movw	%ax, 0x60(%rsp)
    49e7:      	movw	$0x8, 0x62(%rsp)
    49ee:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    49f8:      	movq	%rax, 0x64(%rsp)
    49fd:      	movq	(%rip), %rdi            # 0x4a04 <generic_kprobe_process_filter+0xe94>
    4a04:      	leaq	0x60(%rsp), %rsi
    4a09:      	movl	$0x1, %eax
    4a0e:      	callq	*%rax
    4a10:      	testq	%rax, %rax
    4a13:      	je	0x4a44 <generic_kprobe_process_filter+0xed4>
    4a15:      	incl	(%rax)
    4a17:      	movl	0x6410(%r14), %eax
    4a1e:      	leal	-0x101(%rax), %ecx
    4a24:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4a2a:      	ja	0x4a7d <generic_kprobe_process_filter+0xf0d>
    4a2c:      	movq	0x8(%rsp), %rax
    4a31:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4a37:      	movq	0xb8(%rsp), %rbx
    4a3f:      	jmp	0x4b93 <generic_kprobe_process_filter+0x1023>
    4a44:      	movl	$0x1, 0x40(%rsp)
    4a4c:      	movq	(%rip), %rdi            # 0x4a53 <generic_kprobe_process_filter+0xee3>
    4a53:      	xorl	%ecx, %ecx
    4a55:      	leaq	0x60(%rsp), %rsi
    4a5a:      	leaq	0x40(%rsp), %rdx
    4a5f:      	movl	$0x2, %eax
    4a64:      	xorl	%ecx, %ecx
    4a66:      	callq	*%rax
    4a68:      	movl	0x6410(%r14), %eax
    4a6f:      	leal	-0x101(%rax), %ecx
    4a75:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4a7b:      	jbe	0x4a2c <generic_kprobe_process_filter+0xebc>
    4a7d:      	movzbl	%al, %ebx
    4a80:      	leaq	0x5f80(%r14), %rdi
    4a87:      	movl	$0x4, %eax
    4a8c:      	movl	%ebx, %esi
    4a8e:      	movq	%rbp, %rdx
    4a91:      	callq	*%rax
    4a93:      	movq	%rax, %r15
    4a96:      	testq	%rax, %rax
    4a99:      	je	0x4afb <generic_kprobe_process_filter+0xf8b>
    4a9b:      	movl	%r15d, %eax
    4a9e:      	negl	%eax
    4aa0:      	movw	%ax, 0x60(%rsp)
    4aa5:      	movw	$0xf, 0x62(%rsp)
    4aac:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4ab6:      	movq	%rax, 0x64(%rsp)
    4abb:      	movq	(%rip), %rdi            # 0x4ac2 <generic_kprobe_process_filter+0xf52>
    4ac2:      	leaq	0x60(%rsp), %rsi
    4ac7:      	movl	$0x1, %eax
    4acc:      	callq	*%rax
    4ace:      	testq	%rax, %rax
    4ad1:      	je	0x4ad7 <generic_kprobe_process_filter+0xf67>
    4ad3:      	incl	(%rax)
    4ad5:      	jmp	0x4afb <generic_kprobe_process_filter+0xf8b>
    4ad7:      	movl	$0x1, 0x40(%rsp)
    4adf:      	movq	(%rip), %rdi            # 0x4ae6 <generic_kprobe_process_filter+0xf76>
    4ae6:      	xorl	%ecx, %ecx
    4ae8:      	leaq	0x60(%rsp), %rsi
    4aed:      	leaq	0x40(%rsp), %rdx
    4af2:      	movl	$0x2, %eax
    4af7:      	xorl	%ecx, %ecx
    4af9:      	callq	*%rax
    4afb:      	testl	%r15d, %r15d
    4afe:      	cmovel	%ebx, %r15d
    4b02:      	movl	%r15d, 0x5f78(%r14)
    4b09:      	cmpl	$0x7f, %ebx
    4b0c:      	movl	$0x7f, %esi
    4b11:      	cmovbl	%ebx, %esi
    4b14:      	leaq	0x6080(%r14), %rdi
    4b1b:      	leaq	0x6390(%r14), %rdx
    4b22:      	movl	$0x4, %eax
    4b27:      	callq	*%rax
    4b29:      	testq	%rax, %rax
    4b2c:      	movq	0xb8(%rsp), %rbx
    4b34:      	je	0x4b93 <generic_kprobe_process_filter+0x1023>
    4b36:      	negl	%eax
    4b38:      	movw	%ax, 0x60(%rsp)
    4b3d:      	movw	$0xf, 0x62(%rsp)
    4b44:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    4b4e:      	movq	%rax, 0x64(%rsp)
    4b53:      	movq	(%rip), %rdi            # 0x4b5a <generic_kprobe_process_filter+0xfea>
    4b5a:      	leaq	0x60(%rsp), %rsi
    4b5f:      	movl	$0x1, %eax
    4b64:      	callq	*%rax
    4b66:      	testq	%rax, %rax
    4b69:      	je	0x4b6f <generic_kprobe_process_filter+0xfff>
    4b6b:      	incl	(%rax)
    4b6d:      	jmp	0x4b93 <generic_kprobe_process_filter+0x1023>
    4b6f:      	movl	$0x1, 0x40(%rsp)
    4b77:      	movq	(%rip), %rdi            # 0x4b7e <generic_kprobe_process_filter+0x100e>
    4b7e:      	xorl	%ecx, %ecx
    4b80:      	leaq	0x60(%rsp), %rsi
    4b85:      	leaq	0x40(%rsp), %rdx
    4b8a:      	movl	$0x2, %eax
    4b8f:      	xorl	%ecx, %ecx
    4b91:      	callq	*%rax
    4b93:      	leaq	0x5f10(%r14), %r15
    4b9a:      	orb	$0x10, 0x1(%r14)
    4b9f:      	leaq	0x5ef8(%r14), %rsi
    4ba6:      	movq	(%rip), %rdi            # 0x4bad <generic_kprobe_process_filter+0x103d>
    4bad:      	movl	$0x1, %eax
    4bb2:      	callq	*%rax
    4bb4:      	testq	%rax, %rax
    4bb7:      	je	0x6193 <generic_kprobe_process_filter+0x2623>
    4bbd:      	movq	0x5eb8(%r14), %r13
    4bc4:      	cmpq	$0x6, %r13
    4bc8:      	jae	0x4df6 <generic_kprobe_process_filter+0x1286>
    4bce:      	movslq	(%rax), %rcx
    4bd1:      	testq	%rcx, %rcx
    4bd4:      	je	0x4e18 <generic_kprobe_process_filter+0x12a8>
    4bda:      	cmpq	%rcx, %r13
    4bdd:      	jae	0x4df6 <generic_kprobe_process_filter+0x1286>
    4be3:      	movq	%rax, 0x8(%rsp)
    4be8:      	movq	%rcx, 0xc0(%rsp)
    4bf0:      	movq	%rbx, 0xb8(%rsp)
    4bf8:      	movl	%r13d, 0x10(%rsp)
    4bfd:      	movl	$0x0, 0x58(%rsp)
    4c05:      	movq	(%rip), %rdi            # 0x4c0c <generic_kprobe_process_filter+0x109c>
    4c0c:      	leaq	0x10(%rsp), %rsi
    4c11:      	movl	$0x1, %eax
    4c16:      	callq	*%rax
    4c18:      	testq	%rax, %rax
    4c1b:      	movq	%r15, 0x38(%rsp)
    4c20:      	je	0x4e34 <generic_kprobe_process_filter+0x12c4>
    4c26:      	movq	%rax, %rbx
    4c29:      	movl	(%rax), %eax
    4c2b:      	testl	%eax, %eax
    4c2d:      	je	0x4e34 <generic_kprobe_process_filter+0x12c4>
    4c33:      	cmpl	$0x0, 0x68(%r15)
    4c38:      	js	0x613b <generic_kprobe_process_filter+0x25cb>
    4c3e:      	cmpl	$0x1b, %eax
    4c41:      	ja	0x613b <generic_kprobe_process_filter+0x25cb>
    4c47:      	movl	$0x60, %ecx
    4c4c:      	btl	%eax, %ecx
    4c4f:      	jb	0x58cc <generic_kprobe_process_filter+0x1d5c>
    4c55:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4c5a:      	btl	%eax, %ecx
    4c5d:      	jb	0x5839 <generic_kprobe_process_filter+0x1cc9>
    4c63:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4c68:      	btl	%eax, %ecx
    4c6b:      	jae	0x613b <generic_kprobe_process_filter+0x25cb>
    4c71:      	movq	%rbx, %rsi
    4c74:      	addq	$0x4, %rsi
    4c78:      	movq	(%rip), %rdi            # 0x4c7f <generic_kprobe_process_filter+0x110f>
    4c7f:      	movl	$0x1, %eax
    4c84:      	callq	*%rax
    4c86:      	testq	%rax, %rax
    4c89:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    4c8f:      	movq	%rax, %r12
    4c92:      	movq	0x38(%rsp), %rax
    4c97:      	movl	0x68(%rax), %eax
    4c9a:      	cmpl	$0x7f, %eax
    4c9d:      	movl	$0x7f, %r14d
    4ca3:      	cmovll	%eax, %r14d
    4ca7:      	movq	(%rip), %rdi            # 0x4cae <generic_kprobe_process_filter+0x113e>
    4cae:      	leaq	0x58(%rsp), %rsi
    4cb3:      	movl	$0x1, %eax
    4cb8:      	callq	*%rax
    4cba:      	testq	%rax, %rax
    4cbd:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    4cc3:      	movq	%rax, %rbp
    4cc6:      	leal	(,%r14,8), %eax
    4cce:      	movl	%eax, (%rbp)
    4cd1:      	movq	0x38(%rsp), %rax
    4cd6:      	cmpl	$0x0, 0x6c(%rax)
    4cda:      	jne	0x4dbd <generic_kprobe_process_filter+0x124d>
    4ce0:      	movq	0x38(%rsp), %r15
    4ce5:      	movl	0x68(%r15), %ecx
    4ce9:      	movl	%ecx, %eax
    4ceb:      	subl	%r14d, %eax
    4cee:      	movl	%r14d, %edx
    4cf1:      	andl	$0x7f, %edx
    4cf4:      	addl	%edx, %eax
    4cf6:      	addl	%ecx, %edx
    4cf8:      	movl	%r14d, %ecx
    4cfb:      	notl	%ecx
    4cfd:      	addl	%edx, %ecx
    4cff:      	subl	%r14d, %edx
    4d02:      	leal	-0x4(%rdx), %esi
    4d05:      	leaq	0x1f3(%r15), %rdi
    4d0c:      	leal	-0x3(%rdx), %r8d
    4d10:      	addl	$-0x2, %edx
    4d13:      	movq	$-0x3, %r9
    4d1a:      	leal	(%rcx,%r9), %r10d
    4d1e:      	addl	$0x3, %r10d
    4d22:      	andl	$0x7f, %r10d
    4d26:      	movzbl	0x170(%r15,%r10), %r10d
    4d2f:      	movb	%r10b, -0x3(%rdi)
    4d33:      	leaq	(%rax,%r9), %r10
    4d37:      	cmpq	$-0x2, %r10
    4d3b:      	je	0x4db5 <generic_kprobe_process_filter+0x1245>
    4d3d:      	leal	(%rdx,%r9), %r11d
    4d41:      	addl	$0x3, %r11d
    4d45:      	andl	$0x7f, %r11d
    4d49:      	movzbl	0x170(%r15,%r11), %r11d
    4d52:      	movb	%r11b, -0x2(%rdi)
    4d56:      	cmpq	$-0x1, %r10
    4d5a:      	je	0x4db5 <generic_kprobe_process_filter+0x1245>
    4d5c:      	leal	(%r8,%r9), %r10d
    4d60:      	addl	$0x3, %r10d
    4d64:      	andl	$0x7f, %r10d
    4d68:      	movzbl	0x170(%r15,%r10), %r10d
    4d71:      	movb	%r10b, -0x1(%rdi)
    4d75:      	movq	%rax, %r10
    4d78:      	addq	%r9, %r10
    4d7b:      	je	0x4db5 <generic_kprobe_process_filter+0x1245>
    4d7d:      	cmpq	$-0x7f, %r9
    4d81:      	je	0x4db5 <generic_kprobe_process_filter+0x1245>
    4d83:      	leal	(%rsi,%r9), %r10d
    4d87:      	addl	$0x3, %r10d
    4d8b:      	andl	$0x7f, %r10d
    4d8f:      	movzbl	0x170(%r15,%r10), %r10d
    4d98:      	movb	%r10b, (%rdi)
    4d9b:      	addq	$0x4, %rdi
    4d9f:      	leaq	(%rax,%r9), %r10
    4da3:      	addq	$-0x4, %r10
    4da7:      	addq	$-0x4, %r9
    4dab:      	cmpq	$-0x3, %r10
    4daf:      	jne	0x4d1a <generic_kprobe_process_filter+0x11aa>
    4db5:      	movl	$0x1, 0x6c(%r15)
    4dbd:      	cmpl	$0x7f, %r14d
    4dc1:      	ja	0x4de9 <generic_kprobe_process_filter+0x1279>
    4dc3:      	movslq	%r14d, %rsi
    4dc6:      	movq	%rbp, %rdi
    4dc9:      	addq	$0x4, %rdi
    4dcd:      	movq	0x38(%rsp), %rax
    4dd2:      	leaq	0x1f0(%rax), %rdx
    4dd9:      	movl	$0x4, %eax
    4dde:      	callq	*%rax
    4de0:      	testq	%rax, %rax
    4de3:      	js	0x613b <generic_kprobe_process_filter+0x25cb>
    4de9:      	movl	$0x1, %eax
    4dee:      	movq	%r12, %rdi
    4df1:      	jmp	0x58c4 <generic_kprobe_process_filter+0x1d54>
    4df6:      	movl	(%r15), %eax
    4df9:      	movl	%eax, 0x10(%r14)
    4dfd:      	movq	0x8(%r15), %rax
    4e01:      	movq	%rax, 0x18(%r14)
    4e05:      	cmpb	$0x0, 0x5ec0(%r14)
    4e0d:      	jne	0x617e <generic_kprobe_process_filter+0x260e>
    4e13:      	jmp	0x6193 <generic_kprobe_process_filter+0x2623>
    4e18:      	movb	$0x1, 0x5ec0(%r14)
    4e20:      	movl	(%r15), %eax
    4e23:      	movl	%eax, 0x10(%r14)
    4e27:      	movq	0x8(%r15), %rax
    4e2b:      	movq	%rax, 0x18(%r14)
    4e2f:      	jmp	0x617e <generic_kprobe_process_filter+0x260e>
    4e34:      	movq	0x8(%rsp), %r10
    4e39:      	movq	(%rip), %rax            # 0x4e40 <generic_kprobe_process_filter+0x12d0>
    4e40:      	cmpb	$0x0, (%rax)
    4e43:      	je	0x5085 <generic_kprobe_process_filter+0x1515>
    4e49:      	movq	(%rip), %rdi            # 0x4e50 <generic_kprobe_process_filter+0x12e0>
    4e50:      	movl	$0x1, %eax
    4e55:      	movq	0x38(%rsp), %rsi
    4e5a:      	callq	*%rax
    4e5c:      	movq	0x8(%rsp), %r10
    4e61:      	testq	%rax, %rax
    4e64:      	je	0x5085 <generic_kprobe_process_filter+0x1515>
    4e6a:      	movq	%rax, %rbp
    4e6d:      	leal	0x5(%r13), %eax
    4e71:      	movl	%eax, 0x10(%rsp)
    4e75:      	movl	$0x0, 0x58(%rsp)
    4e7d:      	movq	(%rip), %rdi            # 0x4e84 <generic_kprobe_process_filter+0x1314>
    4e84:      	leaq	0x10(%rsp), %rsi
    4e89:      	movl	$0x1, %eax
    4e8e:      	callq	*%rax
    4e90:      	testq	%rax, %rax
    4e93:      	je	0x5080 <generic_kprobe_process_filter+0x1510>
    4e99:      	movq	%rax, %r12
    4e9c:      	movl	(%rax), %eax
    4e9e:      	testl	%eax, %eax
    4ea0:      	je	0x5080 <generic_kprobe_process_filter+0x1510>
    4ea6:      	cmpl	$0x0, (%rbp)
    4eaa:      	js	0x613b <generic_kprobe_process_filter+0x25cb>
    4eb0:      	cmpl	$0x1b, %eax
    4eb3:      	ja	0x613b <generic_kprobe_process_filter+0x25cb>
    4eb9:      	movl	$0x60, %ecx
    4ebe:      	btl	%eax, %ecx
    4ec1:      	jb	0x5b28 <generic_kprobe_process_filter+0x1fb8>
    4ec7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4ecc:      	btl	%eax, %ecx
    4ecf:      	jb	0x5a98 <generic_kprobe_process_filter+0x1f28>
    4ed5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4eda:      	btl	%eax, %ecx
    4edd:      	jae	0x613b <generic_kprobe_process_filter+0x25cb>
    4ee3:      	movq	%r12, %rsi
    4ee6:      	addq	$0x4, %rsi
    4eea:      	movq	(%rip), %rdi            # 0x4ef1 <generic_kprobe_process_filter+0x1381>
    4ef1:      	movl	$0x1, %eax
    4ef6:      	callq	*%rax
    4ef8:      	testq	%rax, %rax
    4efb:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    4f01:      	movq	%rax, %r15
    4f04:      	movl	(%rbp), %eax
    4f07:      	cmpl	$0x7f, %eax
    4f0a:      	movl	$0x7f, %r14d
    4f10:      	cmovll	%eax, %r14d
    4f14:      	movq	(%rip), %rdi            # 0x4f1b <generic_kprobe_process_filter+0x13ab>
    4f1b:      	leaq	0x58(%rsp), %rsi
    4f20:      	movl	$0x1, %eax
    4f25:      	callq	*%rax
    4f27:      	testq	%rax, %rax
    4f2a:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    4f30:      	movq	%rax, %rbx
    4f33:      	leal	(,%r14,8), %eax
    4f3b:      	movl	%eax, (%rbx)
    4f3d:      	cmpl	$0x0, 0x4(%rbp)
    4f41:      	jne	0x501d <generic_kprobe_process_filter+0x14ad>
    4f47:      	movl	(%rbp), %ecx
    4f4a:      	movl	%ecx, %eax
    4f4c:      	subl	%r14d, %eax
    4f4f:      	movl	%r14d, %edx
    4f52:      	andl	$0x7f, %edx
    4f55:      	addl	%edx, %eax
    4f57:      	addl	%ecx, %edx
    4f59:      	movl	%r14d, %ecx
    4f5c:      	notl	%ecx
    4f5e:      	addl	%edx, %ecx
    4f60:      	subl	%r14d, %edx
    4f63:      	leal	-0x4(%rdx), %esi
    4f66:      	leaq	0x18b(%rbp), %rdi
    4f6d:      	leal	-0x3(%rdx), %r8d
    4f71:      	addl	$-0x2, %edx
    4f74:      	movq	$-0x3, %r9
    4f7b:      	leal	(%rcx,%r9), %r10d
    4f7f:      	addl	$0x3, %r10d
    4f83:      	andl	$0x7f, %r10d
    4f87:      	movzbl	0x108(%rbp,%r10), %r10d
    4f90:      	movb	%r10b, -0x3(%rdi)
    4f94:      	leaq	(%rax,%r9), %r10
    4f98:      	cmpq	$-0x2, %r10
    4f9c:      	je	0x5016 <generic_kprobe_process_filter+0x14a6>
    4f9e:      	leal	(%rdx,%r9), %r11d
    4fa2:      	addl	$0x3, %r11d
    4fa6:      	andl	$0x7f, %r11d
    4faa:      	movzbl	0x108(%rbp,%r11), %r11d
    4fb3:      	movb	%r11b, -0x2(%rdi)
    4fb7:      	cmpq	$-0x1, %r10
    4fbb:      	je	0x5016 <generic_kprobe_process_filter+0x14a6>
    4fbd:      	leal	(%r8,%r9), %r10d
    4fc1:      	addl	$0x3, %r10d
    4fc5:      	andl	$0x7f, %r10d
    4fc9:      	movzbl	0x108(%rbp,%r10), %r10d
    4fd2:      	movb	%r10b, -0x1(%rdi)
    4fd6:      	movq	%rax, %r10
    4fd9:      	addq	%r9, %r10
    4fdc:      	je	0x5016 <generic_kprobe_process_filter+0x14a6>
    4fde:      	cmpq	$-0x7f, %r9
    4fe2:      	je	0x5016 <generic_kprobe_process_filter+0x14a6>
    4fe4:      	leal	(%rsi,%r9), %r10d
    4fe8:      	addl	$0x3, %r10d
    4fec:      	andl	$0x7f, %r10d
    4ff0:      	movzbl	0x108(%rbp,%r10), %r10d
    4ff9:      	movb	%r10b, (%rdi)
    4ffc:      	addq	$0x4, %rdi
    5000:      	leaq	(%rax,%r9), %r10
    5004:      	addq	$-0x4, %r10
    5008:      	addq	$-0x4, %r9
    500c:      	cmpq	$-0x3, %r10
    5010:      	jne	0x4f7b <generic_kprobe_process_filter+0x140b>
    5016:      	movl	$0x1, 0x4(%rbp)
    501d:      	cmpl	$0x7f, %r14d
    5021:      	ja	0x5047 <generic_kprobe_process_filter+0x14d7>
    5023:      	movslq	%r14d, %rsi
    5026:      	movq	%rbx, %rdi
    5029:      	addq	$0x4, %rdi
    502d:      	addq	$0x188, %rbp            # imm = 0x188
    5034:      	movl	$0x4, %eax
    5039:      	movq	%rbp, %rdx
    503c:      	callq	*%rax
    503e:      	testq	%rax, %rax
    5041:      	js	0x613b <generic_kprobe_process_filter+0x25cb>
    5047:      	movl	$0x1, %eax
    504c:      	movq	%r15, %rdi
    504f:      	jmp	0x5b20 <generic_kprobe_process_filter+0x1fb0>
    5054:      	movq	%r12, %r13
    5057:      	addq	$0xff6, %r13            # imm = 0xFF6
    505e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5068:      	movq	%rax, 0xff6(%r12)
    5070:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    507b:      	jmp	0x43b3 <generic_kprobe_process_filter+0x843>
    5080:      	movq	0x8(%rsp), %r10
    5085:      	movl	%r13d, %eax
    5088:      	leaq	0x4(,%rax,4), %rcx
    5090:      	movl	0x4(%r10,%rax,4), %eax
    5095:      	leal	(%rax,%rcx), %r14d
    5099:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    50a0:      	addl	%eax, %ecx
    50a2:      	addl	$0x4, %ecx
    50a5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    50ab:      	leaq	0x8(%r14), %rbp
    50af:      	cmpl	$0x5, (%rcx,%r10)
    50b4:      	jb	0x55de <generic_kprobe_process_filter+0x1a6e>
    50ba:      	movl	(%rbp,%r10), %r12d
    50bf:      	movl	0x4(%rbp,%r10), %edi
    50c4:      	movl	0x8(%rbp,%r10), %edx
    50c9:      	movq	$0x0, 0x68(%rsp)
    50d2:      	movq	$0x0, 0x60(%rsp)
    50db:      	cmpl	$0x4, %edx
    50de:      	movl	$0x4, %ecx
    50e3:      	cmovbl	%edx, %ecx
    50e6:      	cmpl	$0x6, %r12d
    50ea:      	jne	0x5100 <generic_kprobe_process_filter+0x1590>
    50ec:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    50f6:      	movq	%rsi, 0x60(%rsp)
    50fb:      	movq	%rsi, 0x68(%rsp)
    5100:      	testl	%edx, %edx
    5102:      	je	0x55e5 <generic_kprobe_process_filter+0x1a75>
    5108:      	movq	0x38(%rsp), %rdx
    510d:      	leaq	0x24(%rdx), %rsi
    5111:      	testb	$0x1, %dil
    5115:      	movq	%rsi, 0xb0(%rsp)
    511d:      	movq	%rsi, %r8
    5120:      	cmoveq	%rdx, %r8
    5124:      	addq	$0x10, %rdx
    5128:      	movq	%rdx, 0xd0(%rsp)
    5130:      	leal	(%rax,%r13,4), %r9d
    5134:      	addl	$0x4, %r9d
    5138:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    513f:      	addq	$0x14, %r9
    5143:      	decq	%rcx
    5146:      	cmpq	$0x3, %rcx
    514a:      	movl	$0x3, %eax
    514f:      	cmovbq	%rcx, %rax
    5153:      	movl	%eax, %eax
    5155:      	leaq	0x4(,%rax,4), %r11
    515d:      	xorl	%r13d, %r13d
    5160:      	movq	%rdi, 0x30(%rsp)
    5165:      	movq	%r8, 0x28(%rsp)
    516a:      	movq	%r9, 0x20(%rsp)
    516f:      	movq	%r11, 0x18(%rsp)
    5174:      	jmp	0x51b0 <generic_kprobe_process_filter+0x1640>
    5176:      	movq	0x8(%rsp), %r10
    517b:      	movq	0x30(%rsp), %rdi
    5180:      	movq	0x28(%rsp), %r8
    5185:      	movq	0x20(%rsp), %r9
    518a:      	movq	0x18(%rsp), %r11
    518f:      	cmpl	$0x6, %r12d
    5193:      	setne	%al
    5196:      	xorb	$0x1, %bl
    5199:      	orb	%al, %bl
    519b:      	movzbl	%bl, %eax
    519e:      	movl	%eax, 0x60(%rsp,%r13)
    51a3:      	addq	$0x4, %r13
    51a7:      	cmpq	%r13, %r11
    51aa:      	je	0x55e5 <generic_kprobe_process_filter+0x1a75>
    51b0:      	leaq	(%r9,%r13), %rax
    51b4:      	movl	(%r8), %ecx
    51b7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    51bd:      	jbe	0x53ca <generic_kprobe_process_filter+0x185a>
    51c3:      	xorl	%r15d, %r15d
    51c6:      	testb	$0x2, %dil
    51ca:      	je	0x53e7 <generic_kprobe_process_filter+0x1877>
    51d0:      	testb	$0x1, %dil
    51d4:      	jne	0x5408 <generic_kprobe_process_filter+0x1898>
    51da:      	movq	0x38(%rsp), %rcx
    51df:      	movl	(%rcx), %eax
    51e1:      	movb	$0x1, %bl
    51e3:      	cmpq	%rax, %r15
    51e6:      	je	0x518f <generic_kprobe_process_filter+0x161f>
    51e8:      	movl	0x10(%rcx), %eax
    51eb:      	cmpq	%rax, %r15
    51ee:      	je	0x518f <generic_kprobe_process_filter+0x161f>
    51f0:      	movl	$0x1, %eax
    51f5:      	movq	0xd0(%rsp), %rsi
    51fd:      	movq	(%rip), %rdi            # 0x5204 <generic_kprobe_process_filter+0x1694>
    5204:      	callq	*%rax
    5206:      	testq	%rax, %rax
    5209:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    520f:      	movq	%rax, %rsi
    5212:      	movl	(%rax), %eax
    5214:      	cmpq	%rax, %r15
    5217:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    521d:      	movl	0x10(%rsi), %eax
    5220:      	cmpq	%rax, %r15
    5223:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5229:      	addq	$0x10, %rsi
    522d:      	movl	$0x1, %eax
    5232:      	movq	(%rip), %rdi            # 0x5239 <generic_kprobe_process_filter+0x16c9>
    5239:      	callq	*%rax
    523b:      	testq	%rax, %rax
    523e:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5244:      	movq	%rax, %rsi
    5247:      	movl	(%rax), %eax
    5249:      	cmpq	%rax, %r15
    524c:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5252:      	movl	0x10(%rsi), %eax
    5255:      	cmpq	%rax, %r15
    5258:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    525e:      	addq	$0x10, %rsi
    5262:      	movl	$0x1, %eax
    5267:      	movq	(%rip), %rdi            # 0x526e <generic_kprobe_process_filter+0x16fe>
    526e:      	callq	*%rax
    5270:      	testq	%rax, %rax
    5273:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5279:      	movq	%rax, %rsi
    527c:      	movl	(%rax), %eax
    527e:      	cmpq	%rax, %r15
    5281:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5287:      	movl	0x10(%rsi), %eax
    528a:      	cmpq	%rax, %r15
    528d:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5293:      	addq	$0x10, %rsi
    5297:      	movl	$0x1, %eax
    529c:      	movq	(%rip), %rdi            # 0x52a3 <generic_kprobe_process_filter+0x1733>
    52a3:      	callq	*%rax
    52a5:      	testq	%rax, %rax
    52a8:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    52ae:      	movq	%rax, %rsi
    52b1:      	movl	(%rax), %eax
    52b3:      	cmpq	%rax, %r15
    52b6:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    52bc:      	movl	0x10(%rsi), %eax
    52bf:      	cmpq	%rax, %r15
    52c2:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    52c8:      	addq	$0x10, %rsi
    52cc:      	movl	$0x1, %eax
    52d1:      	movq	(%rip), %rdi            # 0x52d8 <generic_kprobe_process_filter+0x1768>
    52d8:      	callq	*%rax
    52da:      	testq	%rax, %rax
    52dd:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    52e3:      	movq	%rax, %rsi
    52e6:      	movl	(%rax), %eax
    52e8:      	cmpq	%rax, %r15
    52eb:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    52f1:      	movl	0x10(%rsi), %eax
    52f4:      	cmpq	%rax, %r15
    52f7:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    52fd:      	addq	$0x10, %rsi
    5301:      	movl	$0x1, %eax
    5306:      	movq	(%rip), %rdi            # 0x530d <generic_kprobe_process_filter+0x179d>
    530d:      	callq	*%rax
    530f:      	testq	%rax, %rax
    5312:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5318:      	movq	%rax, %rsi
    531b:      	movl	(%rax), %eax
    531d:      	cmpq	%rax, %r15
    5320:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5326:      	movl	0x10(%rsi), %eax
    5329:      	cmpq	%rax, %r15
    532c:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5332:      	addq	$0x10, %rsi
    5336:      	movl	$0x1, %eax
    533b:      	movq	(%rip), %rdi            # 0x5342 <generic_kprobe_process_filter+0x17d2>
    5342:      	callq	*%rax
    5344:      	testq	%rax, %rax
    5347:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    534d:      	movq	%rax, %rsi
    5350:      	movl	(%rax), %eax
    5352:      	cmpq	%rax, %r15
    5355:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    535b:      	movl	0x10(%rsi), %eax
    535e:      	cmpq	%rax, %r15
    5361:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5367:      	addq	$0x10, %rsi
    536b:      	movl	$0x1, %eax
    5370:      	movq	(%rip), %rdi            # 0x5377 <generic_kprobe_process_filter+0x1807>
    5377:      	callq	*%rax
    5379:      	testq	%rax, %rax
    537c:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5382:      	movq	%rax, %rsi
    5385:      	movl	(%rax), %eax
    5387:      	cmpq	%rax, %r15
    538a:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5390:      	movl	0x10(%rsi), %eax
    5393:      	cmpq	%rax, %r15
    5396:      	movq	0x8(%rsp), %r10
    539b:      	movq	0x30(%rsp), %rdi
    53a0:      	movq	0x28(%rsp), %r8
    53a5:      	movq	0x20(%rsp), %r9
    53aa:      	movq	0x18(%rsp), %r11
    53af:      	je	0x518f <generic_kprobe_process_filter+0x161f>
    53b5:      	addq	$0x10, %rsi
    53b9:      	movl	$0x1, %eax
    53be:      	movq	(%rip), %rcx            # 0x53c5 <generic_kprobe_process_filter+0x1855>
    53c5:      	jmp	0x55a4 <generic_kprobe_process_filter+0x1a34>
    53ca:      	movl	$0x4, %esi
    53cf:      	xorl	%edx, %edx
    53d1:      	divq	%rsi
    53d4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    53d9:      	movl	(%r10,%rax,4), %r15d
    53dd:      	testb	$0x2, %dil
    53e1:      	jne	0x51d0 <generic_kprobe_process_filter+0x1660>
    53e7:      	cmpl	$0x5, %r12d
    53eb:      	jne	0x53f6 <generic_kprobe_process_filter+0x1886>
    53ed:      	cmpq	%rcx, %r15
    53f0:      	jne	0x55d7 <generic_kprobe_process_filter+0x1a67>
    53f6:      	cmpq	%rcx, %r15
    53f9:      	setne	%al
    53fc:      	cmpl	$0x6, %r12d
    5400:      	setne	%bl
    5403:      	jmp	0x5199 <generic_kprobe_process_filter+0x1629>
    5408:      	movq	0xb0(%rsp), %rax
    5410:      	movl	(%rax), %eax
    5412:      	testq	%rax, %rax
    5415:      	je	0x55d7 <generic_kprobe_process_filter+0x1a67>
    541b:      	movb	$0x1, %bl
    541d:      	testq	%r15, %r15
    5420:      	je	0x518f <generic_kprobe_process_filter+0x161f>
    5426:      	cmpq	%rax, %r15
    5429:      	je	0x518f <generic_kprobe_process_filter+0x161f>
    542f:      	movl	$0x1, %eax
    5434:      	movq	0xd0(%rsp), %rsi
    543c:      	movq	(%rip), %rdi            # 0x5443 <generic_kprobe_process_filter+0x18d3>
    5443:      	callq	*%rax
    5445:      	testq	%rax, %rax
    5448:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    544e:      	movq	%rax, %rsi
    5451:      	movl	0x24(%rax), %eax
    5454:      	cmpq	%rax, %r15
    5457:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    545d:      	addq	$0x10, %rsi
    5461:      	movl	$0x1, %eax
    5466:      	movq	(%rip), %rdi            # 0x546d <generic_kprobe_process_filter+0x18fd>
    546d:      	callq	*%rax
    546f:      	testq	%rax, %rax
    5472:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5478:      	movq	%rax, %rsi
    547b:      	movl	0x24(%rax), %eax
    547e:      	cmpq	%rax, %r15
    5481:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5487:      	addq	$0x10, %rsi
    548b:      	movl	$0x1, %eax
    5490:      	movq	(%rip), %rdi            # 0x5497 <generic_kprobe_process_filter+0x1927>
    5497:      	callq	*%rax
    5499:      	testq	%rax, %rax
    549c:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    54a2:      	movq	%rax, %rsi
    54a5:      	movl	0x24(%rax), %eax
    54a8:      	cmpq	%rax, %r15
    54ab:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    54b1:      	addq	$0x10, %rsi
    54b5:      	movl	$0x1, %eax
    54ba:      	movq	(%rip), %rdi            # 0x54c1 <generic_kprobe_process_filter+0x1951>
    54c1:      	callq	*%rax
    54c3:      	testq	%rax, %rax
    54c6:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    54cc:      	movq	%rax, %rsi
    54cf:      	movl	0x24(%rax), %eax
    54d2:      	cmpq	%rax, %r15
    54d5:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    54db:      	addq	$0x10, %rsi
    54df:      	movl	$0x1, %eax
    54e4:      	movq	(%rip), %rdi            # 0x54eb <generic_kprobe_process_filter+0x197b>
    54eb:      	callq	*%rax
    54ed:      	testq	%rax, %rax
    54f0:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    54f6:      	movq	%rax, %rsi
    54f9:      	movl	0x24(%rax), %eax
    54fc:      	cmpq	%rax, %r15
    54ff:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5505:      	addq	$0x10, %rsi
    5509:      	movl	$0x1, %eax
    550e:      	movq	(%rip), %rdi            # 0x5515 <generic_kprobe_process_filter+0x19a5>
    5515:      	callq	*%rax
    5517:      	testq	%rax, %rax
    551a:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5520:      	movq	%rax, %rsi
    5523:      	movl	0x24(%rax), %eax
    5526:      	cmpq	%rax, %r15
    5529:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    552f:      	addq	$0x10, %rsi
    5533:      	movl	$0x1, %eax
    5538:      	movq	(%rip), %rdi            # 0x553f <generic_kprobe_process_filter+0x19cf>
    553f:      	callq	*%rax
    5541:      	testq	%rax, %rax
    5544:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    5546:      	movq	%rax, %rsi
    5549:      	movl	0x24(%rax), %eax
    554c:      	cmpq	%rax, %r15
    554f:      	je	0x5176 <generic_kprobe_process_filter+0x1606>
    5555:      	addq	$0x10, %rsi
    5559:      	movl	$0x1, %eax
    555e:      	movq	(%rip), %rdi            # 0x5565 <generic_kprobe_process_filter+0x19f5>
    5565:      	callq	*%rax
    5567:      	testq	%rax, %rax
    556a:      	je	0x55ad <generic_kprobe_process_filter+0x1a3d>
    556c:      	movq	%rax, %rsi
    556f:      	movl	0x24(%rax), %eax
    5572:      	cmpq	%rax, %r15
    5575:      	movq	0x8(%rsp), %r10
    557a:      	movq	0x30(%rsp), %rdi
    557f:      	movq	0x28(%rsp), %r8
    5584:      	movq	0x20(%rsp), %r9
    5589:      	movq	0x18(%rsp), %r11
    558e:      	je	0x518f <generic_kprobe_process_filter+0x161f>
    5594:      	addq	$0x10, %rsi
    5598:      	movl	$0x1, %eax
    559d:      	movq	(%rip), %rcx            # 0x55a4 <generic_kprobe_process_filter+0x1a34>
    55a4:      	movq	(%rip), %rdi            # 0x55ab <generic_kprobe_process_filter+0x1a3b>
    55ab:      	callq	*%rax
    55ad:      	xorl	%ebx, %ebx
    55af:      	cmpl	$0x5, %r12d
    55b3:      	movq	0x8(%rsp), %r10
    55b8:      	movq	0x30(%rsp), %rdi
    55bd:      	movq	0x28(%rsp), %r8
    55c2:      	movq	0x20(%rsp), %r9
    55c7:      	movq	0x18(%rsp), %r11
    55cc:      	jne	0x518f <generic_kprobe_process_filter+0x161f>
    55d2:      	jmp	0x519b <generic_kprobe_process_filter+0x162b>
    55d7:      	xorl	%ebx, %ebx
    55d9:      	jmp	0x519b <generic_kprobe_process_filter+0x162b>
    55de:      	movl	$0x1, %eax
    55e3:      	jmp	0x5621 <generic_kprobe_process_filter+0x1ab1>
    55e5:      	movl	0x60(%rsp), %esi
    55e9:      	movl	0x64(%rsp), %ecx
    55ed:      	movl	0x68(%rsp), %eax
    55f1:      	movl	0x6c(%rsp), %edx
    55f5:      	cmpl	$0x6, %r12d
    55f9:      	jne	0x5603 <generic_kprobe_process_filter+0x1a93>
    55fb:      	andl	%esi, %ecx
    55fd:      	andl	%edx, %eax
    55ff:      	andl	%ecx, %eax
    5601:      	jmp	0x5609 <generic_kprobe_process_filter+0x1a99>
    5603:      	orl	%esi, %ecx
    5605:      	orl	%edx, %eax
    5607:      	orl	%ecx, %eax
    5609:      	testl	%eax, %eax
    560b:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5611:      	addl	$0x14, %r14d
    5615:      	movl	0x8(%r10,%rbp), %ecx
    561a:      	andl	$0x7, %ecx
    561d:      	leal	(%r14,%rcx,4), %ebp
    5621:      	movq	0x50(%rsp), %r9
    5626:      	movl	%ebp, %ecx
    5628:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    562e:      	movl	(%rcx,%r10), %ecx
    5632:      	addl	$0x4, %ebp
    5635:      	addl	$-0x4, %ecx
    5638:      	xorl	%esi, %esi
    563a:      	movl	$0x4, %r8d
    5640:      	jmp	0x565f <generic_kprobe_process_filter+0x1aef>
    5642:      	nopw	%cs:(%rax,%rax)
    5650:      	xorl	%ecx, %ecx
    5652:      	incq	%rsi
    5655:      	cmpq	$0xa, %rsi
    5659:      	je	0x57e8 <generic_kprobe_process_filter+0x1c78>
    565f:      	testl	%ecx, %ecx
    5661:      	je	0x5650 <generic_kprobe_process_filter+0x1ae0>
    5663:      	movl	%ebp, %r9d
    5666:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    566d:      	movl	(%r9,%r10), %r11d
    5671:      	movq	%r10, %rax
    5674:      	movl	0x4(%r9,%r10), %r10d
    5679:      	movl	0x8(%r9,%rax), %edx
    567e:      	movq	$0x0, 0x68(%rsp)
    5687:      	movq	$0x0, 0x60(%rsp)
    5690:      	cmpl	$0x4, %edx
    5693:      	movl	$0x4, %eax
    5698:      	cmovbl	%edx, %eax
    569b:      	cmpl	$0x6, %r10d
    569f:      	jne	0x56b5 <generic_kprobe_process_filter+0x1b45>
    56a1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    56ab:      	movq	%rdi, 0x60(%rsp)
    56b0:      	movq	%rdi, 0x68(%rsp)
    56b5:      	addl	$0xc, %ebp
    56b8:      	testl	%edx, %edx
    56ba:      	je	0x5790 <generic_kprobe_process_filter+0x1c20>
    56c0:      	andl	$0xf, %r11d
    56c4:      	decq	%rax
    56c7:      	cmpq	$0x3, %rax
    56cb:      	movl	$0x3, %edx
    56d0:      	cmovaeq	%rdx, %rax
    56d4:      	leaq	0x4(,%rax,4), %rbx
    56dc:      	movl	%ebp, %r14d
    56df:      	cmpl	$0x9, %r11d
    56e3:      	jbe	0x571a <generic_kprobe_process_filter+0x1baa>
    56e5:      	xorl	%r11d, %r11d
    56e8:      	jmp	0x5706 <generic_kprobe_process_filter+0x1b96>
    56ea:      	nopw	(%rax,%rax)
    56f0:      	movl	$0x0, 0x60(%rsp,%r11)
    56f9:      	addq	$0x4, %r11
    56fd:      	cmpq	%r11, %rbx
    5700:      	je	0x5790 <generic_kprobe_process_filter+0x1c20>
    5706:      	leaq	(%r14,%r11), %rax
    570a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    570f:      	ja	0x56f0 <generic_kprobe_process_filter+0x1b80>
    5711:      	movl	%eax, %eax
    5713:      	xorl	%edx, %edx
    5715:      	divq	%r8
    5718:      	jmp	0x56f0 <generic_kprobe_process_filter+0x1b80>
    571a:      	xorl	%r15d, %r15d
    571d:      	jmp	0x5761 <generic_kprobe_process_filter+0x1bf1>
    571f:      	nop
    5720:      	cmpl	$0x5, %r10d
    5724:      	setne	%dl
    5727:      	movl	%r10d, %r13d
    572a:      	xorl	$0x6, %r13d
    572e:      	movq	0x50(%rsp), %rax
    5733:      	movl	0x20(%rax,%r11,4), %edi
    5738:      	movl	%r12d, %eax
    573b:      	xorl	%edi, %eax
    573d:      	cmpl	%edi, %r12d
    5740:      	sete	%dil
    5744:      	orb	%dl, %dil
    5747:      	orl	%r13d, %eax
    574a:      	setne	%al
    574d:      	andb	%dil, %al
    5750:      	movzbl	%al, %eax
    5753:      	movl	%eax, 0x60(%rsp,%r15)
    5758:      	addq	$0x4, %r15
    575c:      	cmpq	%r15, %rbx
    575f:      	je	0x5790 <generic_kprobe_process_filter+0x1c20>
    5761:      	leaq	(%r14,%r15), %rdx
    5765:      	xorl	%r12d, %r12d
    5768:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    576e:      	ja	0x5720 <generic_kprobe_process_filter+0x1bb0>
    5770:      	movl	%edx, %eax
    5772:      	xorl	%edx, %edx
    5774:      	divq	%r8
    5777:      	andl	$0x3ff, %eax            # imm = 0x3FF
    577c:      	movq	0x8(%rsp), %rdx
    5781:      	movl	(%rdx,%rax,4), %r12d
    5785:      	jmp	0x5720 <generic_kprobe_process_filter+0x1bb0>
    5787:      	nopw	(%rax,%rax)
    5790:      	movl	0x60(%rsp), %ebx
    5794:      	movl	0x64(%rsp), %edx
    5798:      	movl	0x68(%rsp), %eax
    579c:      	movl	0x6c(%rsp), %r11d
    57a1:      	cmpl	$0x6, %r10d
    57a5:      	jne	0x57b0 <generic_kprobe_process_filter+0x1c40>
    57a7:      	andl	%ebx, %edx
    57a9:      	andl	%r11d, %eax
    57ac:      	andl	%edx, %eax
    57ae:      	jmp	0x57b7 <generic_kprobe_process_filter+0x1c47>
    57b0:      	orl	%ebx, %edx
    57b2:      	orl	%r11d, %eax
    57b5:      	orl	%edx, %eax
    57b7:      	movq	0x8(%rsp), %r10
    57bc:      	testl	%eax, %eax
    57be:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    57c4:      	movl	0x8(%r10,%r9), %edx
    57c9:      	shll	$0x2, %edx
    57cc:      	subl	%edx, %ecx
    57ce:      	andl	$0x1c, %edx
    57d1:      	addl	%edx, %ebp
    57d3:      	addl	$-0xc, %ecx
    57d6:      	movq	0x50(%rsp), %r9
    57db:      	incq	%rsi
    57de:      	cmpq	$0xa, %rsi
    57e2:      	jne	0x565f <generic_kprobe_process_filter+0x1aef>
    57e8:      	movl	%ebp, %ecx
    57ea:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    57f0:      	leal	0x4(%rbp), %ebx
    57f3:      	cmpl	$0x4, (%rcx,%r10)
    57f8:      	je	0x59c8 <generic_kprobe_process_filter+0x1e58>
    57fe:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5804:      	movl	(%rbx,%r10), %ecx
    5808:      	movl	0x4(%rbx,%r10), %edx
    580d:      	movl	0x8(%rbx,%r10), %edi
    5812:      	movq	0xc(%rbx,%r10), %rax
    5817:      	testl	%edi, %edi
    5819:      	je	0x599c <generic_kprobe_process_filter+0x1e2c>
    581f:      	xorl	%esi, %esi
    5821:      	cmpl	$0x2, %ecx
    5824:      	ja	0x59bf <generic_kprobe_process_filter+0x1e4f>
    582a:      	cmpl	%edi, 0x44(%r9)
    582e:      	jne	0x59a5 <generic_kprobe_process_filter+0x1e35>
    5834:      	jmp	0x59bf <generic_kprobe_process_filter+0x1e4f>
    5839:      	movq	%rbx, %rsi
    583c:      	addq	$0x4, %rsi
    5840:      	movq	(%rip), %rdi            # 0x5847 <generic_kprobe_process_filter+0x1cd7>
    5847:      	movl	$0x1, %eax
    584c:      	callq	*%rax
    584e:      	testq	%rax, %rax
    5851:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5857:      	movq	%rax, %r14
    585a:      	movq	(%rip), %rdi            # 0x5861 <generic_kprobe_process_filter+0x1cf1>
    5861:      	leaq	0x58(%rsp), %rsi
    5866:      	movl	$0x1, %eax
    586b:      	callq	*%rax
    586d:      	testq	%rax, %rax
    5870:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5876:      	movq	%rax, %rbp
    5879:      	movl	$0x104, %edx            # imm = 0x104
    587e:      	movq	%rax, %rdi
    5881:      	xorl	%esi, %esi
    5883:      	callq	0x5888 <generic_kprobe_process_filter+0x1d18>
    5888:      	movq	0x38(%rsp), %rsi
    588d:      	movl	0x68(%rsi), %eax
    5890:      	leal	(,%rax,8), %ecx
    5897:      	movl	%ecx, (%rbp)
    589a:      	movq	%rbp, %rdi
    589d:      	addq	$0x4, %rdi
    58a1:      	movzbl	%al, %ecx
    58a4:      	leaq	0x70(%rsi), %rdx
    58a8:      	movl	$0x4, %eax
    58ad:      	movzbl	0x68(%rsi), %esi
    58b1:      	callq	*%rax
    58b3:      	testq	%rax, %rax
    58b6:      	js	0x613b <generic_kprobe_process_filter+0x25cb>
    58bc:      	movl	$0x1, %eax
    58c1:      	movq	%r14, %rdi
    58c4:      	movq	%rbp, %rsi
    58c7:      	jmp	0x5cc7 <generic_kprobe_process_filter+0x2157>
    58cc:      	movl	$0x0, 0x40(%rsp)
    58d4:      	movq	(%rip), %rdi            # 0x58db <generic_kprobe_process_filter+0x1d6b>
    58db:      	leaq	0x40(%rsp), %rsi
    58e0:      	movl	$0x1, %eax
    58e5:      	callq	*%rax
    58e7:      	testq	%rax, %rax
    58ea:      	movq	0x38(%rsp), %rdx
    58ef:      	je	0x5c74 <generic_kprobe_process_filter+0x2104>
    58f5:      	movq	(%rax), %rcx
    58f8:      	cmpq	0x378(%rdx), %rcx
    58ff:      	je	0x5c74 <generic_kprobe_process_filter+0x2104>
    5905:      	movq	%rax, 0xb0(%rsp)
    590d:      	movq	(%rip), %rax            # 0x5914 <generic_kprobe_process_filter+0x1da4>
    5914:      	cmpb	$0x0, (%rax)
    5917:      	je	0x5beb <generic_kprobe_process_filter+0x207b>
    591d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5923:      	xorl	%r14d, %r14d
    5926:      	movq	(%rip), %r12            # 0x592d <generic_kprobe_process_filter+0x1dbd>
    592d:      	movq	0x38(%rsp), %rax
    5932:      	movl	0x10(%rax), %eax
    5935:      	movl	%eax, 0x60(%rsp)
    5939:      	movl	$0x1, %eax
    593e:      	leaq	0x60(%rsp), %rsi
    5943:      	movq	%r12, %rdi
    5946:      	callq	*%rax
    5948:      	testq	%rax, %rax
    594b:      	je	0x5c5d <generic_kprobe_process_filter+0x20ed>
    5951:      	movq	%rax, %rbp
    5954:      	leaq	0x70(%rax), %rsi
    5958:      	movl	$0x1, %eax
    595d:      	movq	(%rip), %rdi            # 0x5964 <generic_kprobe_process_filter+0x1df4>
    5964:      	callq	*%rax
    5966:      	testq	%rax, %rax
    5969:      	je	0x5980 <generic_kprobe_process_filter+0x1e10>
    596b:      	movq	(%rax), %rax
    596e:      	testq	%rax, %rax
    5971:      	je	0x5980 <generic_kprobe_process_filter+0x1e10>
    5973:      	movq	0x38(%rsp), %rcx
    5978:      	lock
    5979:      	orq	%rax, 0x370(%rcx)
    5980:      	subl	$0x1, %r15d
    5984:      	setb	%al
    5987:      	cmpq	%r14, %rbp
    598a:      	je	0x5c5d <generic_kprobe_process_filter+0x20ed>
    5990:      	movq	%rbp, %r14
    5993:      	testb	%al, %al
    5995:      	je	0x592d <generic_kprobe_process_filter+0x1dbd>
    5997:      	jmp	0x5c5d <generic_kprobe_process_filter+0x20ed>
    599c:      	cmpl	$0x2, %ecx
    599f:      	jbe	0x59a5 <generic_kprobe_process_filter+0x1e35>
    59a1:      	xorl	%esi, %esi
    59a3:      	jmp	0x59bf <generic_kprobe_process_filter+0x1e4f>
    59a5:      	andq	0x48(%r9,%rcx,8), %rax
    59aa:      	cmpl	$0x5, %edx
    59ad:      	jne	0x59b8 <generic_kprobe_process_filter+0x1e48>
    59af:      	testq	%rax, %rax
    59b2:      	setne	%sil
    59b6:      	jmp	0x59bf <generic_kprobe_process_filter+0x1e4f>
    59b8:      	testq	%rax, %rax
    59bb:      	sete	%sil
    59bf:      	addl	$0x18, %ebp
    59c2:      	movzbl	%sil, %eax
    59c6:      	movl	%ebp, %ebx
    59c8:      	testl	%eax, %eax
    59ca:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    59d0:      	movl	%ebx, %ecx
    59d2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    59d8:      	leal	0x4(%rbx), %eax
    59db:      	cmpl	$0x4, (%rcx,%r10)
    59e0:      	je	0x6043 <generic_kprobe_process_filter+0x24d3>
    59e6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    59eb:      	movl	(%rax,%r10), %r14d
    59ef:      	movl	0x4(%rax,%r10), %ebp
    59f4:      	movl	$0xe, %eax
    59f9:      	callq	*%rax
    59fb:      	shrq	$0x20, %rax
    59ff:      	movl	%eax, 0x60(%rsp)
    5a03:      	movq	(%rip), %rdi            # 0x5a0a <generic_kprobe_process_filter+0x1e9a>
    5a0a:      	leaq	0x60(%rsp), %rsi
    5a0f:      	movl	$0x1, %eax
    5a14:      	callq	*%rax
    5a16:      	movq	0x8(%rsp), %r10
    5a1b:      	testq	%rax, %rax
    5a1e:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5a24:      	cmpl	$0x5, %r14d
    5a28:      	je	0x5a66 <generic_kprobe_process_filter+0x1ef6>
    5a2a:      	cmpl	$0x6, %r14d
    5a2e:      	jne	0x613b <generic_kprobe_process_filter+0x25cb>
    5a34:      	movq	0x50(%rsp), %rsi
    5a39:      	movq	%rsi, %rcx
    5a3c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5a43:      	testb	$0x1, %bpl
    5a47:      	jne	0x5d09 <generic_kprobe_process_filter+0x2199>
    5a4d:      	movl	0x28(%rax), %edx
    5a50:      	testl	%edx, %edx
    5a52:      	je	0x5d02 <generic_kprobe_process_filter+0x2192>
    5a58:      	cmpl	0x20(%rsi), %edx
    5a5b:      	je	0x5d09 <generic_kprobe_process_filter+0x2199>
    5a61:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5a66:      	movq	0x50(%rsp), %rsi
    5a6b:      	movq	%rsi, %rcx
    5a6e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5a75:      	testb	$0x1, %bpl
    5a79:      	je	0x5d27 <generic_kprobe_process_filter+0x21b7>
    5a7f:      	movl	0x28(%rax), %edx
    5a82:      	testl	%edx, %edx
    5a84:      	je	0x5d20 <generic_kprobe_process_filter+0x21b0>
    5a8a:      	cmpl	0x20(%rsi), %edx
    5a8d:      	je	0x5d27 <generic_kprobe_process_filter+0x21b7>
    5a93:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5a98:      	movq	%r12, %rsi
    5a9b:      	addq	$0x4, %rsi
    5a9f:      	movq	(%rip), %rdi            # 0x5aa6 <generic_kprobe_process_filter+0x1f36>
    5aa6:      	movl	$0x1, %eax
    5aab:      	callq	*%rax
    5aad:      	testq	%rax, %rax
    5ab0:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5ab6:      	movq	%rax, %r14
    5ab9:      	movq	(%rip), %rdi            # 0x5ac0 <generic_kprobe_process_filter+0x1f50>
    5ac0:      	leaq	0x58(%rsp), %rsi
    5ac5:      	movl	$0x1, %eax
    5aca:      	callq	*%rax
    5acc:      	testq	%rax, %rax
    5acf:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5ad5:      	movq	%rax, %rbx
    5ad8:      	movl	$0x104, %edx            # imm = 0x104
    5add:      	movq	%rax, %rdi
    5ae0:      	xorl	%esi, %esi
    5ae2:      	callq	0x5ae7 <generic_kprobe_process_filter+0x1f77>
    5ae7:      	movl	(%rbp), %eax
    5aea:      	leal	(,%rax,8), %ecx
    5af1:      	movl	%ecx, (%rbx)
    5af3:      	movq	%rbx, %rdi
    5af6:      	addq	$0x4, %rdi
    5afa:      	movzbl	%al, %ecx
    5afd:      	movq	%rbp, %rdx
    5b00:      	addq	$0x8, %rdx
    5b04:      	movl	$0x4, %eax
    5b09:      	movzbl	(%rbp), %esi
    5b0d:      	callq	*%rax
    5b0f:      	testq	%rax, %rax
    5b12:      	js	0x613b <generic_kprobe_process_filter+0x25cb>
    5b18:      	movl	$0x1, %eax
    5b1d:      	movq	%r14, %rdi
    5b20:      	movq	%rbx, %rsi
    5b23:      	jmp	0x5e9d <generic_kprobe_process_filter+0x232d>
    5b28:      	movl	$0x0, 0x40(%rsp)
    5b30:      	movq	(%rip), %rdi            # 0x5b37 <generic_kprobe_process_filter+0x1fc7>
    5b37:      	leaq	0x40(%rsp), %rsi
    5b3c:      	movl	$0x1, %eax
    5b41:      	callq	*%rax
    5b43:      	testq	%rax, %rax
    5b46:      	je	0x5e4a <generic_kprobe_process_filter+0x22da>
    5b4c:      	movq	(%rax), %rcx
    5b4f:      	cmpq	0x310(%rbp), %rcx
    5b56:      	je	0x5e4a <generic_kprobe_process_filter+0x22da>
    5b5c:      	movq	%rax, 0xb0(%rsp)
    5b64:      	movq	(%rip), %rax            # 0x5b6b <generic_kprobe_process_filter+0x1ffb>
    5b6b:      	cmpb	$0x0, (%rax)
    5b6e:      	je	0x5dce <generic_kprobe_process_filter+0x225e>
    5b74:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5b7a:      	xorl	%r14d, %r14d
    5b7d:      	movq	0x38(%rsp), %rax
    5b82:      	movl	0x10(%rax), %eax
    5b85:      	movl	%eax, 0x60(%rsp)
    5b89:      	movl	$0x1, %eax
    5b8e:      	movq	(%rip), %rdi            # 0x5b95 <generic_kprobe_process_filter+0x2025>
    5b95:      	leaq	0x60(%rsp), %rsi
    5b9a:      	callq	*%rax
    5b9c:      	testq	%rax, %rax
    5b9f:      	je	0x5e38 <generic_kprobe_process_filter+0x22c8>
    5ba5:      	movq	%rax, %rbx
    5ba8:      	leaq	0x70(%rax), %rsi
    5bac:      	movl	$0x1, %eax
    5bb1:      	movq	(%rip), %rdi            # 0x5bb8 <generic_kprobe_process_filter+0x2048>
    5bb8:      	callq	*%rax
    5bba:      	testq	%rax, %rax
    5bbd:      	je	0x5bcf <generic_kprobe_process_filter+0x205f>
    5bbf:      	movq	(%rax), %rax
    5bc2:      	testq	%rax, %rax
    5bc5:      	je	0x5bcf <generic_kprobe_process_filter+0x205f>
    5bc7:      	lock
    5bc8:      	orq	%rax, 0x308(%rbp)
    5bcf:      	subl	$0x1, %r15d
    5bd3:      	setb	%al
    5bd6:      	cmpq	%r14, %rbx
    5bd9:      	je	0x5e38 <generic_kprobe_process_filter+0x22c8>
    5bdf:      	movq	%rbx, %r14
    5be2:      	testb	%al, %al
    5be4:      	je	0x5b7d <generic_kprobe_process_filter+0x200d>
    5be6:      	jmp	0x5e38 <generic_kprobe_process_filter+0x22c8>
    5beb:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5bf1:      	xorl	%r14d, %r14d
    5bf4:      	movq	(%rip), %r12            # 0x5bfb <generic_kprobe_process_filter+0x208b>
    5bfb:      	movq	0x38(%rsp), %rax
    5c00:      	movl	0x10(%rax), %eax
    5c03:      	movl	%eax, 0x60(%rsp)
    5c07:      	movl	$0x1, %eax
    5c0c:      	leaq	0x60(%rsp), %rsi
    5c11:      	movq	%r12, %rdi
    5c14:      	callq	*%rax
    5c16:      	testq	%rax, %rax
    5c19:      	je	0x5c5d <generic_kprobe_process_filter+0x20ed>
    5c1b:      	movq	%rax, %rbp
    5c1e:      	leaq	0x70(%rax), %rsi
    5c22:      	movl	$0x1, %eax
    5c27:      	movq	(%rip), %rdi            # 0x5c2e <generic_kprobe_process_filter+0x20be>
    5c2e:      	callq	*%rax
    5c30:      	testq	%rax, %rax
    5c33:      	je	0x5c4a <generic_kprobe_process_filter+0x20da>
    5c35:      	movq	(%rax), %rax
    5c38:      	testq	%rax, %rax
    5c3b:      	je	0x5c4a <generic_kprobe_process_filter+0x20da>
    5c3d:      	movq	0x38(%rsp), %rcx
    5c42:      	lock
    5c43:      	orq	%rax, 0x370(%rcx)
    5c4a:      	subl	$0x1, %r15d
    5c4e:      	setb	%al
    5c51:      	cmpq	%r14, %rbp
    5c54:      	je	0x5c5d <generic_kprobe_process_filter+0x20ed>
    5c56:      	movq	%rbp, %r14
    5c59:      	testb	%al, %al
    5c5b:      	je	0x5bfb <generic_kprobe_process_filter+0x208b>
    5c5d:      	movq	0xb0(%rsp), %rax
    5c65:      	movq	(%rax), %rax
    5c68:      	movq	0x38(%rsp), %rdx
    5c6d:      	movq	%rax, 0x378(%rdx)
    5c74:      	movl	0x8(%rbx), %eax
    5c77:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5c7c:      	cmpq	%rcx, %rax
    5c7f:      	je	0x5c9a <generic_kprobe_process_filter+0x212a>
    5c81:      	movq	0x370(%rdx), %rcx
    5c88:      	btq	%rax, %rcx
    5c8c:      	jae	0x5c9a <generic_kprobe_process_filter+0x212a>
    5c8e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5c98:      	jmp	0x5cc9 <generic_kprobe_process_filter+0x2159>
    5c9a:      	movq	(%rip), %rdi            # 0x5ca1 <generic_kprobe_process_filter+0x2131>
    5ca1:      	leaq	0x10(%rsp), %rsi
    5ca6:      	movl	$0x1, %eax
    5cab:      	callq	*%rax
    5cad:      	testq	%rax, %rax
    5cb0:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5cb6:      	movq	%rax, %rdi
    5cb9:      	movq	0x38(%rsp), %rax
    5cbe:      	leaq	0x70(%rax), %rsi
    5cc2:      	movl	$0x1, %eax
    5cc7:      	callq	*%rax
    5cc9:      	movl	(%rbx), %ecx
    5ccb:      	cmpq	$0x25, %rcx
    5ccf:      	movq	0x8(%rsp), %r10
    5cd4:      	ja	0x5cf4 <generic_kprobe_process_filter+0x2184>
    5cd6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5ce0:      	btq	%rcx, %rdx
    5ce4:      	jae	0x5cf4 <generic_kprobe_process_filter+0x2184>
    5ce6:      	testq	%rax, %rax
    5ce9:      	jne	0x613b <generic_kprobe_process_filter+0x25cb>
    5cef:      	jmp	0x4e39 <generic_kprobe_process_filter+0x12c9>
    5cf4:      	testq	%rax, %rax
    5cf7:      	jne	0x4e39 <generic_kprobe_process_filter+0x12c9>
    5cfd:      	jmp	0x613b <generic_kprobe_process_filter+0x25cb>
    5d02:      	movq	$0x1, (%rcx)
    5d09:      	testb	$0x2, %bpl
    5d0d:      	jne	0x5d45 <generic_kprobe_process_filter+0x21d5>
    5d0f:      	movl	0x2c(%rax), %edx
    5d12:      	testl	%edx, %edx
    5d14:      	je	0x5d3e <generic_kprobe_process_filter+0x21ce>
    5d16:      	cmpl	0x24(%rsi), %edx
    5d19:      	je	0x5d45 <generic_kprobe_process_filter+0x21d5>
    5d1b:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5d20:      	movq	$0x1, (%rcx)
    5d27:      	testb	$0x2, %bpl
    5d2b:      	je	0x5d63 <generic_kprobe_process_filter+0x21f3>
    5d2d:      	movl	0x2c(%rax), %edx
    5d30:      	testl	%edx, %edx
    5d32:      	je	0x5d5c <generic_kprobe_process_filter+0x21ec>
    5d34:      	cmpl	0x24(%rsi), %edx
    5d37:      	je	0x5d63 <generic_kprobe_process_filter+0x21f3>
    5d39:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5d3e:      	movq	$0x1, (%rcx)
    5d45:      	testb	$0x4, %bpl
    5d49:      	jne	0x5d81 <generic_kprobe_process_filter+0x2211>
    5d4b:      	movl	0x30(%rax), %edx
    5d4e:      	testl	%edx, %edx
    5d50:      	je	0x5d7a <generic_kprobe_process_filter+0x220a>
    5d52:      	cmpl	0x28(%rsi), %edx
    5d55:      	je	0x5d81 <generic_kprobe_process_filter+0x2211>
    5d57:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5d5c:      	movq	$0x1, (%rcx)
    5d63:      	testb	$0x4, %bpl
    5d67:      	je	0x5dab <generic_kprobe_process_filter+0x223b>
    5d69:      	movl	0x30(%rax), %edx
    5d6c:      	testl	%edx, %edx
    5d6e:      	je	0x5da4 <generic_kprobe_process_filter+0x2234>
    5d70:      	cmpl	0x28(%rsi), %edx
    5d73:      	je	0x5dab <generic_kprobe_process_filter+0x223b>
    5d75:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5d7a:      	movq	$0x1, (%rcx)
    5d81:      	testb	$0x8, %bpl
    5d85:      	jne	0x5ee1 <generic_kprobe_process_filter+0x2371>
    5d8b:      	movl	0x34(%rax), %edx
    5d8e:      	testl	%edx, %edx
    5d90:      	je	0x5eda <generic_kprobe_process_filter+0x236a>
    5d96:      	cmpl	0x2c(%rsi), %edx
    5d99:      	je	0x5ee1 <generic_kprobe_process_filter+0x2371>
    5d9f:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5da4:      	movq	$0x1, (%rcx)
    5dab:      	testb	$0x8, %bpl
    5daf:      	je	0x5eff <generic_kprobe_process_filter+0x238f>
    5db5:      	movl	0x34(%rax), %edx
    5db8:      	testl	%edx, %edx
    5dba:      	je	0x5ef8 <generic_kprobe_process_filter+0x2388>
    5dc0:      	cmpl	0x2c(%rsi), %edx
    5dc3:      	je	0x5eff <generic_kprobe_process_filter+0x238f>
    5dc9:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5dce:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5dd4:      	xorl	%r14d, %r14d
    5dd7:      	movq	0x38(%rsp), %rax
    5ddc:      	movl	0x10(%rax), %eax
    5ddf:      	movl	%eax, 0x60(%rsp)
    5de3:      	movl	$0x1, %eax
    5de8:      	movq	(%rip), %rdi            # 0x5def <generic_kprobe_process_filter+0x227f>
    5def:      	leaq	0x60(%rsp), %rsi
    5df4:      	callq	*%rax
    5df6:      	testq	%rax, %rax
    5df9:      	je	0x5e38 <generic_kprobe_process_filter+0x22c8>
    5dfb:      	movq	%rax, %rbx
    5dfe:      	leaq	0x70(%rax), %rsi
    5e02:      	movl	$0x1, %eax
    5e07:      	movq	(%rip), %rdi            # 0x5e0e <generic_kprobe_process_filter+0x229e>
    5e0e:      	callq	*%rax
    5e10:      	testq	%rax, %rax
    5e13:      	je	0x5e25 <generic_kprobe_process_filter+0x22b5>
    5e15:      	movq	(%rax), %rax
    5e18:      	testq	%rax, %rax
    5e1b:      	je	0x5e25 <generic_kprobe_process_filter+0x22b5>
    5e1d:      	lock
    5e1e:      	orq	%rax, 0x308(%rbp)
    5e25:      	subl	$0x1, %r15d
    5e29:      	setb	%al
    5e2c:      	cmpq	%r14, %rbx
    5e2f:      	je	0x5e38 <generic_kprobe_process_filter+0x22c8>
    5e31:      	movq	%rbx, %r14
    5e34:      	testb	%al, %al
    5e36:      	je	0x5dd7 <generic_kprobe_process_filter+0x2267>
    5e38:      	movq	0xb0(%rsp), %rax
    5e40:      	movq	(%rax), %rax
    5e43:      	movq	%rax, 0x310(%rbp)
    5e4a:      	movl	0x8(%r12), %eax
    5e4f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5e54:      	cmpq	%rcx, %rax
    5e57:      	je	0x5e72 <generic_kprobe_process_filter+0x2302>
    5e59:      	movq	0x308(%rbp), %rcx
    5e60:      	btq	%rax, %rcx
    5e64:      	jae	0x5e72 <generic_kprobe_process_filter+0x2302>
    5e66:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5e70:      	jmp	0x5e9f <generic_kprobe_process_filter+0x232f>
    5e72:      	movq	(%rip), %rdi            # 0x5e79 <generic_kprobe_process_filter+0x2309>
    5e79:      	leaq	0x10(%rsp), %rsi
    5e7e:      	movl	$0x1, %eax
    5e83:      	callq	*%rax
    5e85:      	testq	%rax, %rax
    5e88:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    5e8e:      	movq	%rax, %rdi
    5e91:      	addq	$0x8, %rbp
    5e95:      	movl	$0x1, %eax
    5e9a:      	movq	%rbp, %rsi
    5e9d:      	callq	*%rax
    5e9f:      	movl	(%r12), %ecx
    5ea3:      	cmpq	$0x25, %rcx
    5ea7:      	movq	0x8(%rsp), %r10
    5eac:      	ja	0x5ecc <generic_kprobe_process_filter+0x235c>
    5eae:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5eb8:      	btq	%rcx, %rdx
    5ebc:      	jae	0x5ecc <generic_kprobe_process_filter+0x235c>
    5ebe:      	testq	%rax, %rax
    5ec1:      	jne	0x613b <generic_kprobe_process_filter+0x25cb>
    5ec7:      	jmp	0x5085 <generic_kprobe_process_filter+0x1515>
    5ecc:      	testq	%rax, %rax
    5ecf:      	jne	0x5085 <generic_kprobe_process_filter+0x1515>
    5ed5:      	jmp	0x613b <generic_kprobe_process_filter+0x25cb>
    5eda:      	movq	$0x1, (%rcx)
    5ee1:      	testb	$0x10, %bpl
    5ee5:      	jne	0x5f1d <generic_kprobe_process_filter+0x23ad>
    5ee7:      	movl	0x38(%rax), %edx
    5eea:      	testl	%edx, %edx
    5eec:      	je	0x5f16 <generic_kprobe_process_filter+0x23a6>
    5eee:      	cmpl	0x30(%rsi), %edx
    5ef1:      	je	0x5f1d <generic_kprobe_process_filter+0x23ad>
    5ef3:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5ef8:      	movq	$0x1, (%rcx)
    5eff:      	testb	$0x10, %bpl
    5f03:      	je	0x5f3b <generic_kprobe_process_filter+0x23cb>
    5f05:      	movl	0x38(%rax), %edx
    5f08:      	testl	%edx, %edx
    5f0a:      	je	0x5f34 <generic_kprobe_process_filter+0x23c4>
    5f0c:      	cmpl	0x30(%rsi), %edx
    5f0f:      	je	0x5f3b <generic_kprobe_process_filter+0x23cb>
    5f11:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5f16:      	movq	$0x1, (%rcx)
    5f1d:      	testb	$0x20, %bpl
    5f21:      	jne	0x5f59 <generic_kprobe_process_filter+0x23e9>
    5f23:      	movl	0x3c(%rax), %edx
    5f26:      	testl	%edx, %edx
    5f28:      	je	0x5f52 <generic_kprobe_process_filter+0x23e2>
    5f2a:      	cmpl	0x34(%rsi), %edx
    5f2d:      	je	0x5f59 <generic_kprobe_process_filter+0x23e9>
    5f2f:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5f34:      	movq	$0x1, (%rcx)
    5f3b:      	testb	$0x20, %bpl
    5f3f:      	je	0x5f77 <generic_kprobe_process_filter+0x2407>
    5f41:      	movl	0x3c(%rax), %edx
    5f44:      	testl	%edx, %edx
    5f46:      	je	0x5f70 <generic_kprobe_process_filter+0x2400>
    5f48:      	cmpl	0x34(%rsi), %edx
    5f4b:      	je	0x5f77 <generic_kprobe_process_filter+0x2407>
    5f4d:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5f52:      	movq	$0x1, (%rcx)
    5f59:      	testb	$0x40, %bpl
    5f5d:      	jne	0x5f95 <generic_kprobe_process_filter+0x2425>
    5f5f:      	movl	0x40(%rax), %edx
    5f62:      	testl	%edx, %edx
    5f64:      	je	0x5f8e <generic_kprobe_process_filter+0x241e>
    5f66:      	cmpl	0x38(%rsi), %edx
    5f69:      	je	0x5f95 <generic_kprobe_process_filter+0x2425>
    5f6b:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5f70:      	movq	$0x1, (%rcx)
    5f77:      	testb	$0x40, %bpl
    5f7b:      	je	0x5fb2 <generic_kprobe_process_filter+0x2442>
    5f7d:      	movl	0x40(%rax), %edx
    5f80:      	testl	%edx, %edx
    5f82:      	je	0x5fab <generic_kprobe_process_filter+0x243b>
    5f84:      	cmpl	0x38(%rsi), %edx
    5f87:      	je	0x5fb2 <generic_kprobe_process_filter+0x2442>
    5f89:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5f8e:      	movq	$0x1, (%rcx)
    5f95:      	testb	%bpl, %bpl
    5f98:      	js	0x5fcc <generic_kprobe_process_filter+0x245c>
    5f9a:      	movl	0x44(%rax), %edx
    5f9d:      	testl	%edx, %edx
    5f9f:      	je	0x5fc5 <generic_kprobe_process_filter+0x2455>
    5fa1:      	cmpl	0x3c(%rsi), %edx
    5fa4:      	je	0x5fcc <generic_kprobe_process_filter+0x245c>
    5fa6:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5fab:      	movq	$0x1, (%rcx)
    5fb2:      	testb	%bpl, %bpl
    5fb5:      	jns	0x5fe9 <generic_kprobe_process_filter+0x2479>
    5fb7:      	movl	0x44(%rax), %edx
    5fba:      	testl	%edx, %edx
    5fbc:      	je	0x5fe2 <generic_kprobe_process_filter+0x2472>
    5fbe:      	cmpl	0x3c(%rsi), %edx
    5fc1:      	je	0x5fe9 <generic_kprobe_process_filter+0x2479>
    5fc3:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5fc5:      	movq	$0x1, (%rcx)
    5fcc:      	testl	$0x100, %ebp            # imm = 0x100
    5fd2:      	jne	0x6012 <generic_kprobe_process_filter+0x24a2>
    5fd4:      	movl	0x48(%rax), %edx
    5fd7:      	testl	%edx, %edx
    5fd9:      	je	0x600b <generic_kprobe_process_filter+0x249b>
    5fdb:      	cmpl	0x40(%rsi), %edx
    5fde:      	je	0x6012 <generic_kprobe_process_filter+0x24a2>
    5fe0:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    5fe2:      	movq	$0x1, (%rcx)
    5fe9:      	testl	$0x100, %ebp            # imm = 0x100
    5fef:      	je	0x6121 <generic_kprobe_process_filter+0x25b1>
    5ff5:      	movl	0x48(%rax), %edx
    5ff8:      	testl	%edx, %edx
    5ffa:      	je	0x611a <generic_kprobe_process_filter+0x25aa>
    6000:      	cmpl	0x40(%rsi), %edx
    6003:      	je	0x6121 <generic_kprobe_process_filter+0x25b1>
    6009:      	jmp	0x6037 <generic_kprobe_process_filter+0x24c7>
    600b:      	movq	$0x1, (%rcx)
    6012:      	testl	$0x200, %ebp            # imm = 0x200
    6018:      	jne	0x613b <generic_kprobe_process_filter+0x25cb>
    601e:      	movl	0x4c(%rax), %eax
    6021:      	testl	%eax, %eax
    6023:      	je	0x6134 <generic_kprobe_process_filter+0x25c4>
    6029:      	movq	0x50(%rsp), %rdx
    602e:      	cmpl	0x44(%rdx), %eax
    6031:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    6037:      	addl	$0xc, %ebx
    603a:      	movq	$0x1, (%rcx)
    6041:      	movl	%ebx, %eax
    6043:      	movl	%eax, %ecx
    6045:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    604b:      	cmpl	$0x4, (%rcx,%r10)
    6050:      	movq	0x50(%rsp), %rcx
    6055:      	jne	0x607c <generic_kprobe_process_filter+0x250c>
    6057:      	movq	0x5eb8(%rcx), %rax
    605e:      	andl	$0x1f, %eax
    6061:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6069:      	movb	$0x1, 0x5ee0(%rcx)
    6070:      	movb	$0x1, 0x5ec0(%rcx)
    6077:      	jmp	0x613b <generic_kprobe_process_filter+0x25cb>
    607c:      	addl	$0x4, %eax
    607f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6084:      	movl	(%rax,%r10), %r14d
    6088:      	movl	0x4(%rax,%r10), %ebx
    608d:      	movl	0x8(%rax,%r10), %ebp
    6092:      	movq	0xc(%rax,%r10), %r15
    6097:      	movl	$0xe, %eax
    609c:      	callq	*%rax
    609e:      	shrq	$0x20, %rax
    60a2:      	movl	%eax, 0x60(%rsp)
    60a6:      	movq	(%rip), %rdi            # 0x60ad <generic_kprobe_process_filter+0x253d>
    60ad:      	leaq	0x60(%rsp), %rsi
    60b2:      	movl	$0x1, %eax
    60b7:      	callq	*%rax
    60b9:      	testq	%rax, %rax
    60bc:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    60be:      	testl	%ebp, %ebp
    60c0:      	je	0x60d4 <generic_kprobe_process_filter+0x2564>
    60c2:      	cmpl	$0x2, %r14d
    60c6:      	ja	0x613b <generic_kprobe_process_filter+0x25cb>
    60c8:      	movq	0x50(%rsp), %rcx
    60cd:      	cmpl	%ebp, 0x44(%rcx)
    60d0:      	jne	0x60da <generic_kprobe_process_filter+0x256a>
    60d2:      	jmp	0x613b <generic_kprobe_process_filter+0x25cb>
    60d4:      	cmpl	$0x2, %r14d
    60d8:      	ja	0x613b <generic_kprobe_process_filter+0x25cb>
    60da:      	movq	0x50(%rax,%r14,8), %rax
    60df:      	movq	0x50(%rsp), %rcx
    60e4:      	movq	0x48(%rcx,%r14,8), %rcx
    60e9:      	movq	%rcx, %rdx
    60ec:      	xorq	%rax, %rdx
    60ef:      	testq	%r15, %rdx
    60f2:      	je	0x60fb <generic_kprobe_process_filter+0x258b>
    60f4:      	cmpl	$0x5, %ebx
    60f7:      	jne	0x613b <generic_kprobe_process_filter+0x25cb>
    60f9:      	jmp	0x6105 <generic_kprobe_process_filter+0x2595>
    60fb:      	cmpq	%rcx, %rax
    60fe:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    6100:      	cmpl	$0x6, %ebx
    6103:      	jne	0x613b <generic_kprobe_process_filter+0x25cb>
    6105:      	movq	0x50(%rsp), %rcx
    610a:      	movq	$0x1, 0x5ef0(%rcx)
    6115:      	jmp	0x6057 <generic_kprobe_process_filter+0x24e7>
    611a:      	movq	$0x1, (%rcx)
    6121:      	testl	$0x200, %ebp            # imm = 0x200
    6127:      	je	0x613b <generic_kprobe_process_filter+0x25cb>
    6129:      	movl	0x4c(%rax), %eax
    612c:      	testl	%eax, %eax
    612e:      	jne	0x6029 <generic_kprobe_process_filter+0x24b9>
    6134:      	movq	$0x1, (%rcx)
    613b:      	movq	0x50(%rsp), %rcx
    6140:      	movq	0x5eb8(%rcx), %rax
    6147:      	incq	%rax
    614a:      	movq	%rax, 0x5eb8(%rcx)
    6151:      	cmpq	0xc0(%rsp), %rax
    6159:      	jbe	0x61a7 <generic_kprobe_process_filter+0x2637>
    615b:      	movq	0x38(%rsp), %rdx
    6160:      	movl	(%rdx), %eax
    6162:      	movl	%eax, 0x10(%rcx)
    6165:      	movq	0x8(%rdx), %rax
    6169:      	movq	%rax, 0x18(%rcx)
    616d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6174:      	movq	0xb8(%rsp), %rbx
    617c:      	je	0x6193 <generic_kprobe_process_filter+0x2623>
    617e:      	movq	(%rip), %rsi            # 0x6185 <generic_kprobe_process_filter+0x2615>
    6185:      	xorl	%ecx, %ecx
    6187:      	movl	$0xc, %eax
    618c:      	movq	%rbx, %rdi
    618f:      	xorl	%edx, %edx
    6191:      	callq	*%rax
    6193:      	xorl	%eax, %eax
    6195:      	addq	$0xe8, %rsp
    619c:      	popq	%rbx
    619d:      	popq	%r12
    619f:      	popq	%r13
    61a1:      	popq	%r14
    61a3:      	popq	%r15
    61a5:      	popq	%rbp
    61a6:      	retq
    61a7:      	movq	(%rip), %rsi            # 0x61ae <generic_kprobe_process_filter+0x263e>
    61ae:      	movl	$0x2, %ecx
    61b3:      	movl	$0xc, %eax
    61b8:      	movq	0xb8(%rsp), %rdi
    61c0:      	movl	$0x2, %edx
    61c5:      	jmp	0x6191 <generic_kprobe_process_filter+0x2621>
    61c7:      	nopw	(%rax,%rax)

00000000000061d0 <generic_kprobe_filter_arg>:
    61d0:      	pushq	%rbp
    61d1:      	pushq	%r15
    61d3:      	pushq	%r14
    61d5:      	pushq	%r13
    61d7:      	pushq	%r12
    61d9:      	pushq	%rbx
    61da:      	subq	$0x28, %rsp
    61de:      	movq	%rdi, %rbx
    61e1:      	movl	$0x0, 0xc(%rsp)
    61e9:      	movq	(%rip), %rdi            # 0x61f0 <generic_kprobe_filter_arg+0x20>
    61f0:      	leaq	0xc(%rsp), %rsi
    61f5:      	movl	$0x1, %eax
    61fa:      	callq	*%rax
    61fc:      	testq	%rax, %rax
    61ff:      	je	0x65cc <generic_kprobe_filter_arg+0x3fc>
    6205:      	movq	%rax, %r14
    6208:      	movl	0x5f00(%rax), %r12d
    620f:      	leaq	0x5ef8(%rax), %rsi
    6216:      	movq	(%rip), %rdi            # 0x621d <generic_kprobe_filter_arg+0x4d>
    621d:      	movl	$0x1, %eax
    6222:      	callq	*%rax
    6224:      	testq	%rax, %rax
    6227:      	je	0x65b1 <generic_kprobe_filter_arg+0x3e1>
    622d:      	cmpb	$0x0, 0x5ee0(%r14)
    6235:      	je	0x65b1 <generic_kprobe_filter_arg+0x3e1>
    623b:      	movq	%rax, %r15
    623e:      	movl	%r12d, %eax
    6241:      	andl	$0x7, %eax
    6244:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    624d:      	je	0x62dc <generic_kprobe_filter_arg+0x10c>
    6253:      	movl	%eax, %eax
    6255:      	movl	0x4(%r15,%rax,4), %ecx
    625a:      	leaq	(%rcx,%rax,4), %rdx
    625e:      	addq	$0x4, %rdx
    6262:      	leaq	(%rcx,%rax,4), %rax
    6266:      	addq	$0x8, %rax
    626a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    626f:      	movl	(%rax,%r15), %eax
    6273:      	addq	%rdx, %rax
    6276:      	addq	$0x4, %rax
    627a:      	movl	%eax, %ecx
    627c:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6282:      	movl	(%rcx,%r15), %ecx
    6286:      	addq	%rax, %rcx
    6289:      	movl	%ecx, %eax
    628b:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6290:      	movl	(%rax,%r15), %eax
    6294:      	addq	%rcx, %rax
    6297:      	movl	%eax, %ecx
    6299:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    629f:      	movl	(%rcx,%r15), %ecx
    62a3:      	addq	%rax, %rcx
    62a6:      	movl	%ecx, %eax
    62a8:      	andl	$0x3ff, %eax            # imm = 0x3FF
    62ad:      	movl	(%rax,%r15), %ebp
    62b1:      	addq	%rcx, %rbp
    62b4:      	movl	%ebp, %eax
    62b6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    62bb:      	movq	%rax, (%rsp)
    62bf:      	cmpl	$0x19, (%r15,%rax)
    62c4:      	jae	0x6331 <generic_kprobe_filter_arg+0x161>
    62c6:      	movq	(%rsp), %rax
    62ca:      	cmpq	$0x1, %rax
    62ce:      	je	0x65b1 <generic_kprobe_filter_arg+0x3e1>
    62d4:      	testl	%eax, %eax
    62d6:      	jne	0x658b <generic_kprobe_filter_arg+0x3bb>
    62dc:      	cmpl	$0x1, %r12d
    62e0:      	jg	0x6301 <generic_kprobe_filter_arg+0x131>
    62e2:      	cmpl	$-0x1, %r12d
    62e6:      	je	0x65dd <generic_kprobe_filter_arg+0x40d>
    62ec:      	testl	%r12d, %r12d
    62ef:      	je	0x65ea <generic_kprobe_filter_arg+0x41a>
    62f5:      	cmpl	$0x1, %r12d
    62f9:      	je	0x65fa <generic_kprobe_filter_arg+0x42a>
    62ff:      	jmp	0x631f <generic_kprobe_filter_arg+0x14f>
    6301:      	cmpl	$0x2, %r12d
    6305:      	je	0x660a <generic_kprobe_filter_arg+0x43a>
    630b:      	cmpl	$0x3, %r12d
    630f:      	je	0x661a <generic_kprobe_filter_arg+0x44a>
    6315:      	cmpl	$0x4, %r12d
    6319:      	je	0x662a <generic_kprobe_filter_arg+0x45a>
    631f:      	cmpl	$0x4, %r12d
    6323:      	jg	0x665c <generic_kprobe_filter_arg+0x48c>
    6329:      	incl	%r12d
    632c:      	jmp	0x663a <generic_kprobe_filter_arg+0x46a>
    6331:      	movq	(%rsp), %rax
    6335:      	addq	%r15, %rax
    6338:      	movq	%rax, 0x10(%rsp)
    633d:      	movl	$0x1, %r13d
    6343:      	nopw	%cs:(%rax,%rax)
    6350:      	movq	0x10(%rsp), %rax
    6355:      	movl	(%rax,%r13,4), %edi
    6359:      	testl	$0x3ff, %edi            # imm = 0x3FF
    635f:      	je	0x62c6 <generic_kprobe_filter_arg+0xf6>
    6365:      	addl	%ebp, %edi
    6367:      	andl	$0x3ff, %edi            # imm = 0x3FF
    636d:      	movl	0x4(%r15,%rdi), %ecx
    6372:      	cmpl	$0x23, %ecx
    6375:      	je	0x62dc <generic_kprobe_filter_arg+0x10c>
    637b:      	addq	%r15, %rdi
    637e:      	movl	(%rdi), %eax
    6380:      	cmpq	$0x4, %rax
    6384:      	ja	0x62dc <generic_kprobe_filter_arg+0x10c>
    638a:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
    6393:      	jne	0x62dc <generic_kprobe_filter_arg+0x10c>
    6399:      	movq	0x5e78(%r14,%rax,8), %rax
    63a1:      	andl	$0x7ff, %eax            # imm = 0x7FF
    63a6:      	leaq	(%r14,%rax), %rsi
    63aa:      	addq	$0x90, %rsi
    63b1:      	movl	0xc(%rdi), %eax
    63b4:      	cmpl	$0x1b, %eax
    63b7:      	jle	0x63d8 <generic_kprobe_filter_arg+0x208>
    63b9:      	cmpl	$0x25, %eax
    63bc:      	jg	0x6408 <generic_kprobe_filter_arg+0x238>
    63be:      	leal	-0x1c(%rax), %edx
    63c1:      	cmpl	$0x9, %edx
    63c4:      	jb	0x644e <generic_kprobe_filter_arg+0x27e>
    63ca:      	cmpl	$0x25, %eax
    63cd:      	je	0x6531 <generic_kprobe_filter_arg+0x361>
    63d3:      	jmp	0x6579 <generic_kprobe_filter_arg+0x3a9>
    63d8:      	cmpl	$0x9, %eax
    63db:      	jle	0x642e <generic_kprobe_filter_arg+0x25e>
    63dd:      	leal	-0xa(%rax), %edx
    63e0:      	cmpl	$0x4, %edx
    63e3:      	jb	0x644e <generic_kprobe_filter_arg+0x27e>
    63e5:      	leal	-0xf(%rax), %ecx
    63e8:      	cmpl	$0x2, %ecx
    63eb:      	jb	0x6531 <generic_kprobe_filter_arg+0x361>
    63f1:      	cmpl	$0x11, %eax
    63f4:      	jne	0x6579 <generic_kprobe_filter_arg+0x3a9>
    63fa:      	addq	$0x4, %rsi
    63fe:      	callq	0x6403 <generic_kprobe_filter_arg+0x233>
    6403:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    6408:      	cmpl	$0x29, %eax
    640b:      	jg	0x6520 <generic_kprobe_filter_arg+0x350>
    6411:      	leal	-0x26(%rax), %ecx
    6414:      	cmpl	$0x2, %ecx
    6417:      	jb	0x64db <generic_kprobe_filter_arg+0x30b>
    641d:      	addl	$-0x28, %eax
    6420:      	cmpl	$0x2, %eax
    6423:      	jb	0x64d1 <generic_kprobe_filter_arg+0x301>
    6429:      	jmp	0x6579 <generic_kprobe_filter_arg+0x3a9>
    642e:      	cmpl	$0x4, %eax
    6431:      	jg	0x64be <generic_kprobe_filter_arg+0x2ee>
    6437:      	cmpl	$0x1, %eax
    643a:      	je	0x644e <generic_kprobe_filter_arg+0x27e>
    643c:      	cmpl	$0x2, %eax
    643f:      	je	0x654e <generic_kprobe_filter_arg+0x37e>
    6445:      	cmpl	$0x4, %eax
    6448:      	jne	0x6579 <generic_kprobe_filter_arg+0x3a9>
    644e:      	cmpl	$0xb, %eax
    6451:      	jle	0x649b <generic_kprobe_filter_arg+0x2cb>
    6453:      	cmpl	$0x24, %eax
    6456:      	ja	0x6538 <generic_kprobe_filter_arg+0x368>
    645c:      	movl	%eax, %edx
    645e:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
    6468:      	btq	%rdx, %r8
    646c:      	jb	0x64e2 <generic_kprobe_filter_arg+0x312>
    646e:      	movl	$0x60000000, %ecx       # imm = 0x60000000
    6473:      	btq	%rdx, %rcx
    6477:      	jb	0x6547 <generic_kprobe_filter_arg+0x377>
    647d:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
    6487:      	btq	%rdx, %rcx
    648b:      	jae	0x6538 <generic_kprobe_filter_arg+0x368>
    6491:      	callq	0x6496 <generic_kprobe_filter_arg+0x2c6>
    6496:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    649b:      	leal	-0xa(%rax), %ecx
    649e:      	cmpl	$0x2, %ecx
    64a1:      	jb	0x655f <generic_kprobe_filter_arg+0x38f>
    64a7:      	cmpl	$0x1, %eax
    64aa:      	je	0x6540 <generic_kprobe_filter_arg+0x370>
    64b0:      	cmpl	$0x4, %eax
    64b3:      	je	0x6540 <generic_kprobe_filter_arg+0x370>
    64b9:      	jmp	0x6579 <generic_kprobe_filter_arg+0x3a9>
    64be:      	cmpl	$0x5, %eax
    64c1:      	je	0x64d1 <generic_kprobe_filter_arg+0x301>
    64c3:      	cmpl	$0x6, %eax
    64c6:      	je	0x64db <generic_kprobe_filter_arg+0x30b>
    64c8:      	cmpl	$0x7, %eax
    64cb:      	jne	0x6579 <generic_kprobe_filter_arg+0x3a9>
    64d1:      	callq	0x64d6 <generic_kprobe_filter_arg+0x306>
    64d6:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    64db:      	movl	$0x4, %edx
    64e0:      	jmp	0x6553 <generic_kprobe_filter_arg+0x383>
    64e2:      	cmpl	$0x1e, %ecx
    64e5:      	jne	0x655f <generic_kprobe_filter_arg+0x38f>
    64e7:      	movl	0x10(%rdi), %eax
    64ea:      	andl	$0x7, %eax
    64ed:      	movl	%eax, %ecx
    64ef:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    64f8:      	jne	0x62dc <generic_kprobe_filter_arg+0x10c>
    64fe:      	movq	(%rsi), %rcx
    6501:      	movq	0x5e78(%r14,%rax,8), %rdx
    6509:      	andl	$0x7ff, %edx            # imm = 0x7FF
    650f:      	xorl	%eax, %eax
    6511:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
    651b:      	setne	%al
    651e:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    6520:      	cmpl	$0x2a, %eax
    6523:      	je	0x6531 <generic_kprobe_filter_arg+0x361>
    6525:      	cmpl	$0x2c, %eax
    6528:      	jne	0x6579 <generic_kprobe_filter_arg+0x3a9>
    652a:      	callq	0x652f <generic_kprobe_filter_arg+0x35f>
    652f:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    6531:      	callq	0x6536 <generic_kprobe_filter_arg+0x366>
    6536:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    6538:      	leal	-0xc(%rax), %ecx
    653b:      	cmpl	$0x2, %ecx
    653e:      	jae	0x655a <generic_kprobe_filter_arg+0x38a>
    6540:      	callq	0x6545 <generic_kprobe_filter_arg+0x375>
    6545:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    6547:      	callq	0x654c <generic_kprobe_filter_arg+0x37c>
    654c:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    654e:      	movl	$0x8, %edx
    6553:      	callq	0x6558 <generic_kprobe_filter_arg+0x388>
    6558:      	jmp	0x6570 <generic_kprobe_filter_arg+0x3a0>
    655a:      	cmpl	$0x1c, %eax
    655d:      	jne	0x6579 <generic_kprobe_filter_arg+0x3a9>
    655f:      	callq	0x6564 <generic_kprobe_filter_arg+0x394>
    6564:      	nopw	%cs:(%rax,%rax)
    6570:      	testq	%rax, %rax
    6573:      	je	0x62dc <generic_kprobe_filter_arg+0x10c>
    6579:      	incq	%r13
    657c:      	cmpq	$0x6, %r13
    6580:      	jne	0x6350 <generic_kprobe_filter_arg+0x180>
    6586:      	jmp	0x62c6 <generic_kprobe_filter_arg+0xf6>
    658b:      	movq	(%rsp), %rax
    658f:      	movl	%eax, 0x5f04(%r14)
    6596:      	movq	(%rip), %rsi            # 0x659d <generic_kprobe_filter_arg+0x3cd>
    659d:      	movl	$0x4, %ecx
    65a2:      	movl	$0xc, %eax
    65a7:      	movq	%rbx, %rdi
    65aa:      	movl	$0x4, %edx
    65af:      	callq	*%rax
    65b1:      	movq	(%rip), %rsi            # 0x65b8 <generic_kprobe_filter_arg+0x3e8>
    65b8:      	movl	$0x5, %ecx
    65bd:      	movl	$0xc, %eax
    65c2:      	movq	%rbx, %rdi
    65c5:      	movl	$0x5, %edx
    65ca:      	callq	*%rax
    65cc:      	xorl	%eax, %eax
    65ce:      	addq	$0x28, %rsp
    65d2:      	popq	%rbx
    65d3:      	popq	%r12
    65d5:      	popq	%r13
    65d7:      	popq	%r14
    65d9:      	popq	%r15
    65db:      	popq	%rbp
    65dc:      	retq
    65dd:      	xorl	%r12d, %r12d
    65e0:      	cmpb	$0x0, 0x5ec1(%r14)
    65e8:      	jne	0x663a <generic_kprobe_filter_arg+0x46a>
    65ea:      	movl	$0x1, %r12d
    65f0:      	cmpb	$0x0, 0x5ec2(%r14)
    65f8:      	jne	0x663a <generic_kprobe_filter_arg+0x46a>
    65fa:      	movl	$0x2, %r12d
    6600:      	cmpb	$0x0, 0x5ec3(%r14)
    6608:      	jne	0x663a <generic_kprobe_filter_arg+0x46a>
    660a:      	movl	$0x3, %r12d
    6610:      	cmpb	$0x0, 0x5ec4(%r14)
    6618:      	jne	0x663a <generic_kprobe_filter_arg+0x46a>
    661a:      	movl	$0x4, %r12d
    6620:      	cmpb	$0x0, 0x5ec5(%r14)
    6628:      	jne	0x663a <generic_kprobe_filter_arg+0x46a>
    662a:      	movl	$0x5, %r12d
    6630:      	cmpb	$0x0, 0x5ec6(%r14)
    6638:      	je	0x665c <generic_kprobe_filter_arg+0x48c>
    663a:      	movl	%r12d, 0x5f00(%r14)
    6641:      	movq	(%rip), %rsi            # 0x6648 <generic_kprobe_filter_arg+0x478>
    6648:      	movl	$0x3, %ecx
    664d:      	movl	$0xc, %eax
    6652:      	movq	%rbx, %rdi
    6655:      	movl	$0x3, %edx
    665a:      	callq	*%rax
    665c:      	movq	0x60(%r14), %rbx
    6660:      	movl	$0xe, %eax
    6665:      	callq	*%rax
    6667:      	movq	%rbx, 0x18(%rsp)
    666c:      	movq	%rax, 0x20(%rsp)
    6671:      	movq	(%rip), %rdi            # 0x6678 <generic_kprobe_filter_arg+0x4a8>
    6678:      	leaq	0x18(%rsp), %rsi
    667d:      	movl	$0x1, %eax
    6682:      	callq	*%rax
    6684:      	testq	%rax, %rax
    6687:      	je	0x65cc <generic_kprobe_filter_arg+0x3fc>
    668d:      	movq	(%rip), %rdi            # 0x6694 <generic_kprobe_filter_arg+0x4c4>
    6694:      	leaq	0x18(%rsp), %rsi
    6699:      	movl	$0x3, %eax
    669e:      	callq	*%rax
    66a0:      	jmp	0x65cc <generic_kprobe_filter_arg+0x3fc>
    66a5:      	nopw	%cs:(%rax,%rax)

00000000000066b0 <generic_kprobe_actions>:
    66b0:      	pushq	%rbp
    66b1:      	pushq	%r14
    66b3:      	pushq	%rbx
    66b4:      	subq	$0x10, %rsp
    66b8:      	movq	%rdi, %rbx
    66bb:      	movl	$0x0, 0x8(%rsp)
    66c3:      	movq	(%rip), %rdi            # 0x66ca <generic_kprobe_actions+0x1a>
    66ca:      	leaq	0x8(%rsp), %rsi
    66cf:      	movl	$0x1, %eax
    66d4:      	callq	*%rax
    66d6:      	testq	%rax, %rax
    66d9:      	je	0x67e2 <generic_kprobe_actions+0x132>
    66df:      	movq	%rax, %rsi
    66e2:      	movl	0x5f04(%rax), %r14d
    66e9:      	cmpl	$0x2, %r14d
    66ed:      	jl	0x67e2 <generic_kprobe_actions+0x132>
    66f3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    66fa:      	movq	(%rip), %rdi            # 0x6701 <generic_kprobe_actions+0x51>
    6701:      	movl	$0x1, %eax
    6706:      	callq	*%rax
    6708:      	testq	%rax, %rax
    670b:      	je	0x67e2 <generic_kprobe_actions+0x132>
    6711:      	movl	%r14d, %ecx
    6714:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    671a:      	addl	(%rax,%rcx), %r14d
    671e:      	movb	$0x1, 0x7(%rsp)
    6723:      	movl	$0x0, 0xc(%rsp)
    672b:      	movq	(%rip), %rdi            # 0x6732 <generic_kprobe_actions+0x82>
    6732:      	leaq	0xc(%rsp), %rsi
    6737:      	movq	%rax, %rcx
    673a:      	movl	$0x1, %eax
    673f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
    6746:      	addq	%rcx, %r14
    6749:      	callq	*%rax
    674b:      	testq	%rax, %rax
    674e:      	je	0x675e <generic_kprobe_actions+0xae>
    6750:      	cmpb	$0x0, (%rax)
    6753:      	sete	%al
    6756:      	cmpl	$0x5, (%r14)
    675a:      	jae	0x6766 <generic_kprobe_actions+0xb6>
    675c:      	jmp	0x67c0 <generic_kprobe_actions+0x110>
    675e:      	movb	$0x1, %al
    6760:      	cmpl	$0x5, (%r14)
    6764:      	jb	0x67c0 <generic_kprobe_actions+0x110>
    6766:      	movzbl	%al, %ebp
    6769:      	leaq	0x7(%rsp), %rcx
    676e:      	movq	%rbx, %rdi
    6771:      	xorl	%esi, %esi
    6773:      	movq	%r14, %rdx
    6776:      	movl	%ebp, %r8d
    6779:      	callq	0x677e <generic_kprobe_actions+0xce>
    677e:      	leal	0x4(,%rax,4), %ecx
    6785:      	cmpl	(%r14), %ecx
    6788:      	jae	0x67c0 <generic_kprobe_actions+0x110>
    678a:      	leaq	0x7(%rsp), %rcx
    678f:      	movq	%rbx, %rdi
    6792:      	movl	%eax, %esi
    6794:      	movq	%r14, %rdx
    6797:      	movl	%ebp, %r8d
    679a:      	callq	0x679f <generic_kprobe_actions+0xef>
    679f:      	leal	0x4(,%rax,4), %ecx
    67a6:      	cmpl	(%r14), %ecx
    67a9:      	jae	0x67c0 <generic_kprobe_actions+0x110>
    67ab:      	leaq	0x7(%rsp), %rcx
    67b0:      	movq	%rbx, %rdi
    67b3:      	movl	%eax, %esi
    67b5:      	movq	%r14, %rdx
    67b8:      	movl	%ebp, %r8d
    67bb:      	callq	0x67c0 <generic_kprobe_actions+0x110>
    67c0:      	cmpb	$0x0, 0x7(%rsp)
    67c5:      	je	0x67e2 <generic_kprobe_actions+0x132>
    67c7:      	movq	(%rip), %rsi            # 0x67ce <generic_kprobe_actions+0x11e>
    67ce:      	movl	$0x5, %ecx
    67d3:      	movl	$0xc, %eax
    67d8:      	movq	%rbx, %rdi
    67db:      	movl	$0x5, %edx
    67e0:      	callq	*%rax
    67e2:      	xorl	%eax, %eax
    67e4:      	addq	$0x10, %rsp
    67e8:      	popq	%rbx
    67e9:      	popq	%r14
    67eb:      	popq	%rbp
    67ec:      	retq
    67ed:      	nopl	(%rax)

00000000000067f0 <generic_kprobe_output>:
    67f0:      	pushq	%rbp
    67f1:      	pushq	%r15
    67f3:      	pushq	%r14
    67f5:      	pushq	%r13
    67f7:      	pushq	%r12
    67f9:      	pushq	%rbx
    67fa:      	subq	$0x78, %rsp
    67fe:      	movq	%rdi, %r14
    6801:      	movl	$0x0, 0x24(%rsp)
    6809:      	movq	(%rip), %rdi            # 0x6810 <generic_kprobe_output+0x20>
    6810:      	leaq	0x24(%rsp), %rsi
    6815:      	movl	$0x1, %eax
    681a:      	callq	*%rax
    681c:      	testq	%rax, %rax
    681f:      	je	0x6cc9 <generic_kprobe_output+0x4d9>
    6825:      	movq	%rax, %rbx
    6828:      	cmpq	$0x0, 0x5ee8(%rax)
    6830:      	je	0x6b38 <generic_kprobe_output+0x348>
    6836:      	movl	$0xe, %eax
    683b:      	callq	*%rax
    683d:      	movq	%rax, %r15
    6840:      	shrq	$0x20, %r15
    6844:      	movl	$0x23, %eax
    6849:      	callq	*%rax
    684b:      	movq	%rax, %r12
    684e:      	movl	%r15d, 0x28(%rsp)
    6853:      	movq	(%rip), %rdi            # 0x685a <generic_kprobe_output+0x6a>
    685a:      	leaq	0x28(%rsp), %rsi
    685f:      	movl	$0x1, %eax
    6864:      	callq	*%rax
    6866:      	testq	%rax, %rax
    6869:      	je	0x6b38 <generic_kprobe_output+0x348>
    686f:      	movq	%rax, %r15
    6872:      	leaq	0xd70(%r12), %rdx
    687a:      	leaq	0x70(%rsp), %rdi
    687f:      	movl	$0x8, %ecx
    6884:      	movl	$0x4, %eax
    6889:      	leaq	0x28(%r15), %r13
    688d:      	movl	$0x4, %ebp
    6892:      	movl	$0x8, %esi
    6897:      	callq	*%rax
    6899:      	movq	0x70(%rsp), %rcx
    689e:      	leaq	0x28(%rsp), %rdi
    68a3:      	movl	$0x48, %edx
    68a8:      	movl	$0x4, %eax
    68ad:      	movq	0x70(%rsp), %rdx
    68b2:      	movl	$0x48, %esi
    68b7:      	callq	*%rax
    68b9:      	movl	$0x218, %edx            # imm = 0x218
    68be:      	movq	0x30(%rsp), %rcx
    68c3:      	addq	%rdx, %rcx
    68c6:      	movl	$0x4, %esi
    68cb:      	movl	$0x4, %eax
    68d0:      	addq	0x30(%rsp), %rdx
    68d5:      	movq	%r13, %rdi
    68d8:      	movl	$0x4, %esi
    68dd:      	callq	*%rax
    68df:      	leaq	0x2c(%r15), %rdi
    68e3:      	movl	$0x4d8, %edx            # imm = 0x4D8
    68e8:      	movq	0x38(%rsp), %rcx
    68ed:      	addq	%rdx, %rcx
    68f0:      	movl	$0x4, %esi
    68f5:      	movl	$0x4, %eax
    68fa:      	addq	0x38(%rsp), %rdx
    68ff:      	movl	$0x4, %esi
    6904:      	callq	*%rax
    6906:      	leaq	0x30(%r15), %rdi
    690a:      	movq	0x40(%rsp), %rcx
    690f:      	addq	$0x58, %rcx
    6913:      	movl	$0x4, %edx
    6918:      	movl	$0x4, %eax
    691d:      	movq	0x40(%rsp), %rdx
    6922:      	addq	$0x58, %rdx
    6926:      	movl	$0x4, %esi
    692b:      	callq	*%rax
    692d:      	movq	$0x0, (%rsp)
    6935:      	leaq	0xb58(%r12), %rdx
    693d:      	movq	%rsp, %rdi
    6940:      	movl	$0x8, %ecx
    6945:      	movl	$0x4, %eax
    694a:      	movl	$0x8, %esi
    694f:      	callq	*%rax
    6951:      	movq	(%rsp), %rcx
    6955:      	testq	%rcx, %rcx
    6958:      	je	0x69eb <generic_kprobe_output+0x1fb>
    695e:      	movl	$0x0, 0xc(%rsp)
    6966:      	addq	$0x4, %rcx
    696a:      	leaq	0xc(%rsp), %rdi
    696f:      	movl	$0x4, %eax
    6974:      	movq	(%rsp), %rdx
    6978:      	addq	$0x4, %rdx
    697c:      	movl	$0x4, %esi
    6981:      	callq	*%rax
    6983:      	movq	(%rsp), %rax
    6987:      	movslq	0xc(%rsp), %rcx
    698c:      	shlq	$0x4, %rcx
    6990:      	addq	%rax, %rcx
    6993:      	addq	$0x80, %rcx
    699a:      	leaq	0x10(%rsp), %rdi
    699f:      	movl	$0x10, %edx
    69a4:      	movl	$0x4, %eax
    69a9:      	movq	(%rsp), %rcx
    69ad:      	movslq	0xc(%rsp), %rdx
    69b2:      	shlq	$0x4, %rdx
    69b6:      	addq	%rcx, %rdx
    69b9:      	addq	$0x80, %rdx
    69c0:      	movl	$0x10, %esi
    69c5:      	callq	*%rax
    69c7:      	leaq	0x34(%r15), %rdi
    69cb:      	movl	$0x158, %edx            # imm = 0x158
    69d0:      	movq	0x18(%rsp), %rcx
    69d5:      	addq	%rdx, %rcx
    69d8:      	movl	$0x4, %eax
    69dd:      	addq	0x18(%rsp), %rdx
    69e2:      	movl	$0x4, %esi
    69e7:      	callq	*%rax
    69e9:      	jmp	0x69f3 <generic_kprobe_output+0x203>
    69eb:      	movl	$0x0, 0x34(%r15)
    69f3:      	leaq	0x38(%r15), %rdi
    69f7:      	movl	$0x158, %r13d           # imm = 0x158
    69fd:      	movq	0x48(%rsp), %rcx
    6a02:      	addq	%r13, %rcx
    6a05:      	movl	$0x4, %edx
    6a0a:      	movl	$0x4, %eax
    6a0f:      	movq	0x48(%rsp), %rdx
    6a14:      	addq	%r13, %rdx
    6a17:      	movl	$0x4, %esi
    6a1c:      	callq	*%rax
    6a1e:      	leaq	0x3c(%r15), %rdi
    6a22:      	movl	$0x118, %edx            # imm = 0x118
    6a27:      	movq	0x50(%rsp), %rcx
    6a2c:      	addq	%rdx, %rcx
    6a2f:      	movl	$0x4, %esi
    6a34:      	movl	$0x4, %eax
    6a39:      	addq	0x50(%rsp), %rdx
    6a3e:      	movl	$0x4, %esi
    6a43:      	callq	*%rax
    6a45:      	leaq	0x40(%r15), %rdi
    6a49:      	movl	$0x98, %ebp
    6a4e:      	movq	0x58(%rsp), %rcx
    6a53:      	addq	%rbp, %rcx
    6a56:      	movl	$0x4, %edx
    6a5b:      	movl	$0x4, %eax
    6a60:      	movq	0x58(%rsp), %rdx
    6a65:      	addq	%rbp, %rdx
    6a68:      	movl	$0x4, %esi
    6a6d:      	callq	*%rax
    6a6f:      	leaq	0x44(%r15), %rdi
    6a73:      	movq	0x60(%rsp), %rcx
    6a78:      	addq	%rbp, %rcx
    6a7b:      	movl	$0x4, %edx
    6a80:      	movl	$0x4, %eax
    6a85:      	addq	0x60(%rsp), %rbp
    6a8a:      	movl	$0x4, %esi
    6a8f:      	movq	%rbp, %rdx
    6a92:      	callq	*%rax
    6a94:      	leaq	0x48(%r15), %rdi
    6a98:      	movq	0x68(%rsp), %rcx
    6a9d:      	addq	$0x58, %rcx
    6aa1:      	movl	$0x4, %edx
    6aa6:      	movl	$0x4, %eax
    6aab:      	movq	0x68(%rsp), %rdx
    6ab0:      	addq	$0x58, %rdx
    6ab4:      	movl	$0x4, %esi
    6ab9:      	callq	*%rax
    6abb:      	movq	$0x0, 0x10(%rsp)
    6ac4:      	movq	$0x0, (%rsp)
    6acc:      	addq	$0xd00, %r12            # imm = 0xD00
    6ad3:      	leaq	0x10(%rsp), %rdi
    6ad8:      	movl	$0x8, %ecx
    6add:      	movl	$0x4, %eax
    6ae2:      	movl	$0x8, %esi
    6ae7:      	movq	%r12, %rdx
    6aea:      	callq	*%rax
    6aec:      	movl	$0x90, %edx
    6af1:      	movq	0x10(%rsp), %rcx
    6af6:      	addq	%rdx, %rcx
    6af9:      	movq	%rsp, %rdi
    6afc:      	movl	$0x8, %esi
    6b01:      	movl	$0x4, %eax
    6b06:      	addq	0x10(%rsp), %rdx
    6b0b:      	movl	$0x8, %esi
    6b10:      	callq	*%rax
    6b12:      	addq	$0x4c, %r15
    6b16:      	movq	(%rsp), %rcx
    6b1a:      	addq	%r13, %rcx
    6b1d:      	movl	$0x4, %edx
    6b22:      	movl	$0x4, %eax
    6b27:      	addq	(%rsp), %r13
    6b2b:      	movq	%r15, %rdi
    6b2e:      	movl	$0x4, %esi
    6b33:      	movq	%r13, %rdx
    6b36:      	callq	*%rax
    6b38:      	cmpq	$0x0, 0x5ef0(%rbx)
    6b40:      	je	0x6bf9 <generic_kprobe_output+0x409>
    6b46:      	movl	$0xe, %eax
    6b4b:      	callq	*%rax
    6b4d:      	movq	%rax, %r15
    6b50:      	shrq	$0x20, %r15
    6b54:      	movl	$0x23, %eax
    6b59:      	callq	*%rax
    6b5b:      	movq	%rax, %r12
    6b5e:      	movl	%r15d, 0x28(%rsp)
    6b63:      	movq	(%rip), %rdi            # 0x6b6a <generic_kprobe_output+0x37a>
    6b6a:      	leaq	0x28(%rsp), %rsi
    6b6f:      	movl	$0x1, %eax
    6b74:      	callq	*%rax
    6b76:      	testq	%rax, %rax
    6b79:      	je	0x6bf9 <generic_kprobe_output+0x409>
    6b7b:      	leaq	0x50(%rax), %r15
    6b7f:      	addq	$0xd00, %r12            # imm = 0xD00
    6b86:      	leaq	0x28(%rsp), %rdi
    6b8b:      	movl	$0x8, %ecx
    6b90:      	movq	%rax, %r13
    6b93:      	movl	$0x4, %eax
    6b98:      	movl	$0x8, %esi
    6b9d:      	movq	%r12, %rdx
    6ba0:      	callq	*%rax
    6ba2:      	movq	0x28(%rsp), %r12
    6ba7:      	leaq	0x58(%r13), %rdi
    6bab:      	leaq	0x40(%r12), %rdx
    6bb0:      	movl	$0x8, %ecx
    6bb5:      	movl	$0x4, %eax
    6bba:      	movl	$0x8, %esi
    6bbf:      	callq	*%rax
    6bc1:      	addq	$0x60, %r13
    6bc5:      	leaq	0x30(%r12), %rdx
    6bca:      	movl	$0x8, %ecx
    6bcf:      	movl	$0x4, %eax
    6bd4:      	movq	%r13, %rdi
    6bd7:      	movl	$0x8, %esi
    6bdc:      	callq	*%rax
    6bde:      	addq	$0x38, %r12
    6be2:      	movl	$0x8, %ecx
    6be7:      	movl	$0x4, %eax
    6bec:      	movq	%r15, %rdi
    6bef:      	movl	$0x8, %esi
    6bf4:      	movq	%r12, %rdx
    6bf7:      	callq	*%rax
    6bf9:      	movl	$0x90, %eax
    6bfe:      	addl	0x4(%rbx), %eax
    6c01:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    6c06:      	cmpl	$0x2328, %eax           # imm = 0x2328
    6c0b:      	movl	$0x2328, %r15d          # imm = 0x2328
    6c11:      	cmovbl	%eax, %r15d
    6c15:      	movl	$0x0, 0x10(%rsp)
    6c1d:      	movq	(%rip), %rdi            # 0x6c24 <generic_kprobe_output+0x434>
    6c24:      	leaq	0x10(%rsp), %rsi
    6c29:      	movl	$0x1, %eax
    6c2e:      	callq	*%rax
    6c30:      	testq	%rax, %rax
    6c33:      	je	0x6c87 <generic_kprobe_output+0x497>
    6c35:      	cmpb	$0x0, 0x28(%rax)
    6c39:      	je	0x6c87 <generic_kprobe_output+0x497>
    6c3b:      	movq	(%rip), %rsi            # 0x6c42 <generic_kprobe_output+0x452>
    6c42:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6c47:      	movl	$0x19, %eax
    6c4c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    6c51:      	movq	%r14, %rdi
    6c54:      	movq	%rbx, %rcx
    6c57:      	movq	%r15, %r8
    6c5a:      	callq	*%rax
    6c5c:      	testq	%rax, %rax
    6c5f:      	js	0x6d29 <generic_kprobe_output+0x539>
    6c65:      	movl	$0x0, 0x28(%rsp)
    6c6d:      	movq	(%rip), %rdi            # 0x6c74 <generic_kprobe_output+0x484>
    6c74:      	leaq	0x28(%rsp), %rsi
    6c79:      	movl	$0x1, %eax
    6c7e:      	callq	*%rax
    6c80:      	testq	%rax, %rax
    6c83:      	jne	0x6cc4 <generic_kprobe_output+0x4d4>
    6c85:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6c87:      	movq	(%rip), %rdi            # 0x6c8e <generic_kprobe_output+0x49e>
    6c8e:      	xorl	%ecx, %ecx
    6c90:      	movl	$0x82, %eax
    6c95:      	movq	%rbx, %rsi
    6c98:      	movq	%r15, %rdx
    6c9b:      	xorl	%ecx, %ecx
    6c9d:      	callq	*%rax
    6c9f:      	testq	%rax, %rax
    6ca2:      	js	0x6cda <generic_kprobe_output+0x4ea>
    6ca4:      	movl	$0x0, 0x28(%rsp)
    6cac:      	movq	(%rip), %rdi            # 0x6cb3 <generic_kprobe_output+0x4c3>
    6cb3:      	leaq	0x28(%rsp), %rsi
    6cb8:      	movl	$0x1, %eax
    6cbd:      	callq	*%rax
    6cbf:      	testq	%rax, %rax
    6cc2:      	je	0x6cc9 <generic_kprobe_output+0x4d9>
    6cc4:      	lock
    6cc5:      	incq	0x8(%rax)
    6cc9:      	xorl	%eax, %eax
    6ccb:      	addq	$0x78, %rsp
    6ccf:      	popq	%rbx
    6cd0:      	popq	%r12
    6cd2:      	popq	%r13
    6cd4:      	popq	%r14
    6cd6:      	popq	%r15
    6cd8:      	popq	%rbp
    6cd9:      	retq
    6cda:      	movq	%rax, %rbx
    6cdd:      	movl	$0x0, 0x28(%rsp)
    6ce5:      	movq	(%rip), %rdi            # 0x6cec <generic_kprobe_output+0x4fc>
    6cec:      	leaq	0x28(%rsp), %rsi
    6cf1:      	movl	$0x1, %eax
    6cf6:      	callq	*%rax
    6cf8:      	testq	%rax, %rax
    6cfb:      	je	0x6cc9 <generic_kprobe_output+0x4d9>
    6cfd:      	cmpq	$-0xc, %rbx
    6d01:      	jg	0x6d71 <generic_kprobe_output+0x581>
    6d03:      	cmpq	$-0x1c, %rbx
    6d07:      	je	0x6db3 <generic_kprobe_output+0x5c3>
    6d0d:      	cmpq	$-0x16, %rbx
    6d11:      	je	0x6d62 <generic_kprobe_output+0x572>
    6d13:      	cmpq	$-0x10, %rbx
    6d17:      	jne	0x6da4 <generic_kprobe_output+0x5b4>
    6d1d:      	addq	$0x2f0, %rax            # imm = 0x2F0
    6d23:      	lock
    6d24:      	incq	(%rax)
    6d27:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6d29:      	movq	%rax, %rbx
    6d2c:      	movl	$0x0, 0x28(%rsp)
    6d34:      	movq	(%rip), %rdi            # 0x6d3b <generic_kprobe_output+0x54b>
    6d3b:      	leaq	0x28(%rsp), %rsi
    6d40:      	movl	$0x1, %eax
    6d45:      	callq	*%rax
    6d47:      	testq	%rax, %rax
    6d4a:      	je	0x6cc9 <generic_kprobe_output+0x4d9>
    6d50:      	cmpq	$-0xc, %rbx
    6d54:      	jg	0x6d92 <generic_kprobe_output+0x5a2>
    6d56:      	cmpq	$-0x1c, %rbx
    6d5a:      	je	0x6db3 <generic_kprobe_output+0x5c3>
    6d5c:      	cmpq	$-0x16, %rbx
    6d60:      	jne	0x6d13 <generic_kprobe_output+0x523>
    6d62:      	addq	$0x2f8, %rax            # imm = 0x2F8
    6d68:      	lock
    6d69:      	incq	(%rax)
    6d6c:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6d71:      	cmpq	$-0xb, %rbx
    6d75:      	je	0x6dc2 <generic_kprobe_output+0x5d2>
    6d77:      	cmpq	$-0x7, %rbx
    6d7b:      	je	0x6dd1 <generic_kprobe_output+0x5e1>
    6d7d:      	cmpq	$-0x2, %rbx
    6d81:      	jne	0x6da4 <generic_kprobe_output+0x5b4>
    6d83:      	addq	$0x2e0, %rax            # imm = 0x2E0
    6d89:      	lock
    6d8a:      	incq	(%rax)
    6d8d:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6d92:      	cmpq	$-0xb, %rbx
    6d96:      	je	0x6dc2 <generic_kprobe_output+0x5d2>
    6d98:      	cmpq	$-0x7, %rbx
    6d9c:      	je	0x6dd1 <generic_kprobe_output+0x5e1>
    6d9e:      	cmpq	$-0x2, %rbx
    6da2:      	je	0x6d83 <generic_kprobe_output+0x593>
    6da4:      	addq	$0x2d8, %rax            # imm = 0x2D8
    6daa:      	lock
    6dab:      	incq	(%rax)
    6dae:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6db3:      	addq	$0x300, %rax            # imm = 0x300
    6db9:      	lock
    6dba:      	incq	(%rax)
    6dbd:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6dc2:      	addq	$0x308, %rax            # imm = 0x308
    6dc8:      	lock
    6dc9:      	incq	(%rax)
    6dcc:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>
    6dd1:      	addq	$0x2e8, %rax            # imm = 0x2E8
    6dd7:      	lock
    6dd8:      	incq	(%rax)
    6ddb:      	jmp	0x6cc9 <generic_kprobe_output+0x4d9>

Disassembly of section kprobe.multi/generic_kprobe:

0000000000000000 <generic_kprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_kprobe_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x629 <generic_kprobe_event+0x629>
      38:      	movq	%rax, %r14
      3b:      	movl	$0xae, %eax
      40:      	movq	%rbx, %rdi
      43:      	callq	*%rax
      45:      	leaq	0x5ef8(%r14), %rsi
      4c:      	movl	%eax, 0x5ef8(%r14)
      53:      	movq	(%rip), %rdi            # 0x5a <generic_kprobe_event+0x5a>
      5a:      	movl	$0x1, %eax
      5f:      	callq	*%rax
      61:      	testq	%rax, %rax
      64:      	je	0x629 <generic_kprobe_event+0x629>
      6a:      	movl	0x64(%rax), %ecx
      6d:      	movl	%ecx, 0x14(%rsp)
      71:      	testl	%ecx, %ecx
      73:      	je	0x242 <generic_kprobe_event+0x242>
      79:      	movq	%rax, %r12
      7c:      	movq	(%rip), %rdi            # 0x83 <generic_kprobe_event+0x83>
      83:      	leaq	0x14(%rsp), %rsi
      88:      	movl	$0x1, %eax
      8d:      	callq	*%rax
      8f:      	testq	%rax, %rax
      92:      	je	0x629 <generic_kprobe_event+0x629>
      98:      	movq	%rax, %r15
      9b:      	movl	$0x0, 0x3c(%rsp)
      a3:      	movq	(%rip), %rdi            # 0xaa <generic_kprobe_event+0xaa>
      aa:      	leaq	0x3c(%rsp), %rsi
      af:      	movl	$0x1, %eax
      b4:      	callq	*%rax
      b6:      	testq	%rax, %rax
      b9:      	je	0xdf <generic_kprobe_event+0xdf>
      bb:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      c3:      	jne	0xe3 <generic_kprobe_event+0xe3>
      c5:      	movl	$0x50, %eax
      ca:      	callq	*%rax
      cc:      	movq	%rax, 0x8(%rsp)
      d1:      	testq	%rax, %rax
      d4:      	jne	0x1fd <generic_kprobe_event+0x1fd>
      da:      	jmp	0x629 <generic_kprobe_event+0x629>
      df:      	xorl	%ebp, %ebp
      e1:      	jmp	0xe6 <generic_kprobe_event+0xe6>
      e3:      	movl	0x10(%rax), %ebp
      e6:      	movl	$0x23, %eax
      eb:      	callq	*%rax
      ed:      	movq	$0x0, 0x20(%rsp)
      f6:      	leaq	0xf90(%rax), %rdx
      fd:      	leaq	0x28(%rsp), %rdi
     102:      	movl	$0x8, %ecx
     107:      	movl	$0x71, %eax
     10c:      	movl	$0x8, %esi
     111:      	callq	*%rax
     113:      	movq	0x28(%rsp), %rax
     118:      	testq	%rax, %rax
     11b:      	je	0x629 <generic_kprobe_event+0x629>
     121:      	cmpl	$0xb, %ebp
     124:      	ja	0x629 <generic_kprobe_event+0x629>
     12a:      	movl	%ebp, %edx
     12c:      	leaq	(%rax,%rdx,8), %rcx
     130:      	leaq	0x40(%rsp), %rdi
     135:      	movl	$0x8, %esi
     13a:      	movl	$0x71, %eax
     13f:      	shlq	$0x3, %rdx
     143:      	addq	0x28(%rsp), %rdx
     148:      	movl	$0x8, %esi
     14d:      	callq	*%rax
     14f:      	movq	0x40(%rsp), %rcx
     154:      	testq	%rcx, %rcx
     157:      	je	0x629 <generic_kprobe_event+0x629>
     15d:      	leaq	0x20(%rsp), %rdi
     162:      	movl	$0x8, %edx
     167:      	movl	$0x71, %eax
     16c:      	movq	0x40(%rsp), %rdx
     171:      	movl	$0x8, %esi
     176:      	callq	*%rax
     178:      	movq	0x20(%rsp), %rdx
     17d:      	testq	%rdx, %rdx
     180:      	je	0x629 <generic_kprobe_event+0x629>
     186:      	movq	$0x0, 0x40(%rsp)
     18f:      	addq	$0x100, %rdx            # imm = 0x100
     196:      	leaq	0x40(%rsp), %rdi
     19b:      	movl	$0x8, %ecx
     1a0:      	movl	$0x71, %eax
     1a5:      	movl	$0x8, %esi
     1aa:      	callq	*%rax
     1ac:      	movq	0x40(%rsp), %rdx
     1b1:      	movq	$0x0, 0x40(%rsp)
     1ba:      	testq	%rdx, %rdx
     1bd:      	je	0x1ed <generic_kprobe_event+0x1ed>
     1bf:      	addq	$0x60, %rdx
     1c3:      	leaq	0x40(%rsp), %rdi
     1c8:      	movl	$0x8, %ecx
     1cd:      	movl	$0x71, %eax
     1d2:      	movl	$0x8, %esi
     1d7:      	callq	*%rax
     1d9:      	movq	0x40(%rsp), %rax
     1de:      	movq	%rax, 0x8(%rsp)
     1e3:      	testq	%rax, %rax
     1e6:      	jne	0x1fd <generic_kprobe_event+0x1fd>
     1e8:      	jmp	0x629 <generic_kprobe_event+0x629>
     1ed:      	xorl	%eax, %eax
     1ef:      	movq	%rax, 0x8(%rsp)
     1f4:      	testq	%rax, %rax
     1f7:      	je	0x629 <generic_kprobe_event+0x629>
     1fd:      	movq	%rax, 0x40(%rsp)
     202:      	movq	(%rip), %rdi            # 0x209 <generic_kprobe_event+0x209>
     209:      	leaq	0x40(%rsp), %rsi
     20e:      	movl	$0x1, %eax
     213:      	callq	*%rax
     215:      	testq	%rax, %rax
     218:      	je	0x227 <generic_kprobe_event+0x227>
     21a:      	movq	(%rax), %rax
     21d:      	testq	%rax, %rax
     220:      	je	0x227 <generic_kprobe_event+0x227>
     222:      	movq	%rax, 0x8(%rsp)
     227:      	leaq	0x8(%rsp), %rsi
     22c:      	movl	$0x1, %eax
     231:      	movq	%r15, %rdi
     234:      	callq	*%rax
     236:      	testq	%rax, %rax
     239:      	movq	%r12, %rax
     23c:      	je	0x63d <generic_kprobe_event+0x63d>
     242:      	movl	(%rax), %eax
     244:      	movq	%rax, 0x60(%r14)
     248:      	movq	$0x0, 0x68(%r14)
     250:      	movq	$0x0, 0x5efc(%r14)
     25b:      	movq	$0x0, 0x5eb8(%r14)
     266:      	movq	$0x0, 0x5ec0(%r14)
     271:      	movq	$0x0, 0x5ec8(%r14)
     27c:      	movq	$0x0, 0x5ed0(%r14)
     287:      	movq	$0x0, 0x5ed8(%r14)
     292:      	movb	$0x0, 0x5ee0(%r14)
     29a:      	movl	$0x23, %eax
     29f:      	callq	*%rax
     2a1:      	movq	%rax, %r15
     2a4:      	leaq	0xd70(%rax), %rdx
     2ab:      	leaq	0x20(%rsp), %rdi
     2b0:      	movl	$0x8, %ecx
     2b5:      	movl	$0x4, %eax
     2ba:      	leaq	0x20(%r14), %r12
     2be:      	movl	$0x4, %r13d
     2c4:      	movl	$0x8, %esi
     2c9:      	callq	*%rax
     2cb:      	movq	0x20(%rsp), %rcx
     2d0:      	leaq	0x40(%rsp), %rdi
     2d5:      	movl	$0x48, %edx
     2da:      	movl	$0x4, %eax
     2df:      	movq	0x20(%rsp), %rdx
     2e4:      	movl	$0x48, %esi
     2e9:      	callq	*%rax
     2eb:      	movl	$0x218, %edx            # imm = 0x218
     2f0:      	movq	0x48(%rsp), %rcx
     2f5:      	addq	%rdx, %rcx
     2f8:      	movl	$0x4, %esi
     2fd:      	movl	$0x4, %eax
     302:      	addq	0x48(%rsp), %rdx
     307:      	movq	%r12, %rdi
     30a:      	movl	$0x4, %esi
     30f:      	callq	*%rax
     311:      	leaq	0x24(%r14), %rdi
     315:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31a:      	movq	0x50(%rsp), %rcx
     31f:      	addq	%rdx, %rcx
     322:      	movl	$0x4, %esi
     327:      	movl	$0x4, %eax
     32c:      	addq	0x50(%rsp), %rdx
     331:      	movl	$0x4, %esi
     336:      	callq	*%rax
     338:      	leaq	0x28(%r14), %rdi
     33c:      	movq	0x58(%rsp), %rcx
     341:      	addq	$0x58, %rcx
     345:      	movl	$0x4, %edx
     34a:      	movl	$0x4, %eax
     34f:      	movq	0x58(%rsp), %rdx
     354:      	addq	$0x58, %rdx
     358:      	movl	$0x4, %esi
     35d:      	callq	*%rax
     35f:      	movq	$0x0, 0x8(%rsp)
     368:      	leaq	0xb58(%r15), %rdx
     36f:      	leaq	0x8(%rsp), %rdi
     374:      	movl	$0x8, %ecx
     379:      	movl	$0x4, %eax
     37e:      	movl	$0x8, %esi
     383:      	callq	*%rax
     385:      	movq	0x8(%rsp), %rcx
     38a:      	testq	%rcx, %rcx
     38d:      	je	0x423 <generic_kprobe_event+0x423>
     393:      	movl	$0x0, 0x18(%rsp)
     39b:      	addq	$0x4, %rcx
     39f:      	leaq	0x18(%rsp), %rdi
     3a4:      	movl	$0x4, %eax
     3a9:      	movq	0x8(%rsp), %rdx
     3ae:      	addq	$0x4, %rdx
     3b2:      	movl	$0x4, %esi
     3b7:      	callq	*%rax
     3b9:      	movq	0x8(%rsp), %rax
     3be:      	movslq	0x18(%rsp), %rcx
     3c3:      	shlq	$0x4, %rcx
     3c7:      	addq	%rax, %rcx
     3ca:      	addq	$0x80, %rcx
     3d1:      	leaq	0x28(%rsp), %rdi
     3d6:      	movl	$0x10, %edx
     3db:      	movl	$0x4, %eax
     3e0:      	movq	0x8(%rsp), %rcx
     3e5:      	movslq	0x18(%rsp), %rdx
     3ea:      	shlq	$0x4, %rdx
     3ee:      	addq	%rcx, %rdx
     3f1:      	addq	$0x80, %rdx
     3f8:      	movl	$0x10, %esi
     3fd:      	callq	*%rax
     3ff:      	leaq	0x2c(%r14), %rdi
     403:      	movl	$0x158, %edx            # imm = 0x158
     408:      	movq	0x30(%rsp), %rcx
     40d:      	addq	%rdx, %rcx
     410:      	movl	$0x4, %eax
     415:      	addq	0x30(%rsp), %rdx
     41a:      	movl	$0x4, %esi
     41f:      	callq	*%rax
     421:      	jmp	0x42b <generic_kprobe_event+0x42b>
     423:      	movl	$0x0, 0x2c(%r14)
     42b:      	leaq	0x30(%r14), %rdi
     42f:      	movl	$0x158, %r12d           # imm = 0x158
     435:      	movq	0x60(%rsp), %rcx
     43a:      	addq	%r12, %rcx
     43d:      	movl	$0x4, %edx
     442:      	movl	$0x4, %eax
     447:      	movq	0x60(%rsp), %rdx
     44c:      	addq	%r12, %rdx
     44f:      	movl	$0x4, %esi
     454:      	callq	*%rax
     456:      	leaq	0x34(%r14), %rdi
     45a:      	movl	$0x118, %edx            # imm = 0x118
     45f:      	movq	0x68(%rsp), %rcx
     464:      	addq	%rdx, %rcx
     467:      	movl	$0x4, %esi
     46c:      	movl	$0x4, %eax
     471:      	addq	0x68(%rsp), %rdx
     476:      	movl	$0x4, %esi
     47b:      	callq	*%rax
     47d:      	leaq	0x38(%r14), %rdi
     481:      	movl	$0x98, %r13d
     487:      	movq	0x70(%rsp), %rcx
     48c:      	addq	%r13, %rcx
     48f:      	movl	$0x4, %edx
     494:      	movl	$0x4, %eax
     499:      	movq	0x70(%rsp), %rdx
     49e:      	addq	%r13, %rdx
     4a1:      	movl	$0x4, %esi
     4a6:      	callq	*%rax
     4a8:      	leaq	0x3c(%r14), %rdi
     4ac:      	movq	0x78(%rsp), %rcx
     4b1:      	addq	%r13, %rcx
     4b4:      	movl	$0x4, %edx
     4b9:      	movl	$0x4, %eax
     4be:      	addq	0x78(%rsp), %r13
     4c3:      	movl	$0x4, %esi
     4c8:      	movq	%r13, %rdx
     4cb:      	callq	*%rax
     4cd:      	leaq	0x40(%r14), %rdi
     4d1:      	movq	0x80(%rsp), %rcx
     4d9:      	addq	$0x58, %rcx
     4dd:      	movl	$0x4, %edx
     4e2:      	movl	$0x4, %eax
     4e7:      	movq	0x80(%rsp), %rdx
     4ef:      	addq	$0x58, %rdx
     4f3:      	movl	$0x4, %esi
     4f8:      	callq	*%rax
     4fa:      	movq	$0x0, 0x28(%rsp)
     503:      	movq	$0x0, 0x8(%rsp)
     50c:      	addq	$0xd00, %r15            # imm = 0xD00
     513:      	leaq	0x28(%rsp), %rdi
     518:      	movl	$0x8, %ecx
     51d:      	movl	$0x4, %eax
     522:      	movl	$0x8, %esi
     527:      	movq	%r15, %rdx
     52a:      	callq	*%rax
     52c:      	movl	$0x90, %edx
     531:      	movq	0x28(%rsp), %rcx
     536:      	addq	%rdx, %rcx
     539:      	leaq	0x8(%rsp), %rdi
     53e:      	movl	$0x8, %esi
     543:      	movl	$0x4, %eax
     548:      	addq	0x28(%rsp), %rdx
     54d:      	movl	$0x8, %esi
     552:      	callq	*%rax
     554:      	leaq	0x44(%r14), %rdi
     558:      	movq	0x8(%rsp), %rcx
     55d:      	addq	%r12, %rcx
     560:      	movl	$0x4, %edx
     565:      	movl	$0x4, %eax
     56a:      	addq	0x8(%rsp), %r12
     56f:      	movl	$0x4, %esi
     574:      	movq	%r12, %rdx
     577:      	callq	*%rax
     579:      	leaq	0x48(%r14), %r12
     57d:      	leaq	0x40(%rsp), %rdi
     582:      	movl	$0x8, %ecx
     587:      	movl	$0x4, %eax
     58c:      	movl	$0x8, %esi
     591:      	movq	%r15, %rdx
     594:      	callq	*%rax
     596:      	movq	0x40(%rsp), %r15
     59b:      	leaq	0x50(%r14), %rdi
     59f:      	leaq	0x40(%r15), %rdx
     5a3:      	movl	$0x8, %ecx
     5a8:      	movl	$0x4, %eax
     5ad:      	movl	$0x8, %esi
     5b2:      	callq	*%rax
     5b4:      	movq	%r14, %rdi
     5b7:      	addq	$0x58, %rdi
     5bb:      	leaq	0x30(%r15), %rdx
     5bf:      	movl	$0x8, %ecx
     5c4:      	movl	$0x4, %eax
     5c9:      	movl	$0x8, %esi
     5ce:      	callq	*%rax
     5d0:      	addq	$0x38, %r15
     5d4:      	movl	$0x8, %ecx
     5d9:      	movl	$0x4, %eax
     5de:      	movq	%r12, %rdi
     5e1:      	movl	$0x8, %esi
     5e6:      	movq	%r15, %rdx
     5e9:      	callq	*%rax
     5eb:      	movb	$0x0, 0x5f08(%r14)
     5f3:      	movb	$0x0, 0x1(%r14)
     5f8:      	movq	$0x0, 0x5ee8(%r14)
     603:      	movq	$0x0, 0x5ef0(%r14)
     60e:      	movq	(%rip), %rsi            # 0x615 <generic_kprobe_event+0x615>
     615:      	movl	$0x2, %ecx
     61a:      	movl	$0xc, %eax
     61f:      	movq	%rbx, %rdi
     622:      	movl	$0x2, %edx
     627:      	callq	*%rax
     629:      	xorl	%eax, %eax
     62b:      	addq	$0x88, %rsp
     632:      	popq	%rbx
     633:      	popq	%r12
     635:      	popq	%r13
     637:      	popq	%r14
     639:      	popq	%r15
     63b:      	popq	%rbp
     63c:      	retq
     63d:      	movq	$-0x1, 0x18(%rsp)
     646:      	leaq	0x18(%rsp), %rsi
     64b:      	movl	$0x1, %eax
     650:      	movq	%r15, %rdi
     653:      	callq	*%rax
     655:      	testq	%rax, %rax
     658:      	je	0x629 <generic_kprobe_event+0x629>
     65a:      	movl	$0x1, 0x14(%rsp)
     662:      	movq	(%rip), %rdi            # 0x669 <generic_kprobe_event+0x669>
     669:      	leaq	0x14(%rsp), %rsi
     66e:      	movl	$0x1, %eax
     673:      	callq	*%rax
     675:      	testq	%rax, %rax
     678:      	je	0x629 <generic_kprobe_event+0x629>
     67a:      	movq	%rax, %rdi
     67d:      	leaq	0x8(%rsp), %rsi
     682:      	movl	$0x1, %eax
     687:      	callq	*%rax
     689:      	testq	%rax, %rax
     68c:      	movq	%r12, %rax
     68f:      	jne	0x629 <generic_kprobe_event+0x629>
     691:      	jmp	0x242 <generic_kprobe_event+0x242>

Disassembly of section kprobe.multi/generic_kprobe_override:

0000000000000000 <generic_kprobe_override>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movq	%rdi, %rbx
       8:      	movl	$0xe, %eax
       d:      	callq	*%rax
       f:      	movq	%rax, 0x8(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_kprobe_override+0x1b>
      1b:      	leaq	0x8(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x52 <generic_kprobe_override+0x52>
      2c:      	movslq	(%rax), %rcx
      2f:      	movq	%rax, %rdx
      32:      	movl	$0x3a, %eax
      37:      	movslq	(%rdx), %rsi
      3a:      	movq	%rbx, %rdi
      3d:      	callq	*%rax
      3f:      	movq	(%rip), %rdi            # 0x46 <generic_kprobe_override+0x46>
      46:      	leaq	0x8(%rsp), %rsi
      4b:      	movl	$0x3, %eax
      50:      	callq	*%rax
      52:      	xorl	%eax, %eax
      54:      	addq	$0x10, %rsp
      58:      	popq	%rbx
      59:      	retq

Disassembly of section fmod_ret/security_task_prctl:

0000000000000000 <generic_fmodret_override>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movl	$0xe, %eax
       a:      	callq	*%rax
       c:      	movq	%rax, 0x8(%rsp)
      11:      	movq	(%rip), %rdi            # 0x18 <generic_fmodret_override+0x18>
      18:      	leaq	0x8(%rsp), %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	je	0x48 <generic_fmodret_override+0x48>
      29:      	movq	%rax, %rbx
      2c:      	movq	(%rip), %rdi            # 0x33 <generic_fmodret_override+0x33>
      33:      	leaq	0x8(%rsp), %rsi
      38:      	movl	$0x3, %eax
      3d:      	callq	*%rax
      3f:      	movslq	(%rbx), %rax
      42:      	addq	$0x10, %rsp
      46:      	popq	%rbx
      47:      	retq
      48:      	xorl	%eax, %eax
      4a:      	addq	$0x10, %rsp
      4e:      	popq	%rbx
      4f:      	retq
