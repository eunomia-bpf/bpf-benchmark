
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_retkprobe_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	pushq	%rax
       1:      	movl	0x4(%rdi), %ecx
       4:      	xorl	%eax, %eax
       6:      	cmpq	$0x20, %rcx
       a:      	ja	0x45 <filter_64ty+0x45>
       c:      	movl	$0x101e, %edx           # imm = 0x101E
      11:      	btq	%rcx, %rdx
      15:      	jae	0x1e <filter_64ty+0x1e>
      17:      	callq	0x140 <filter_64ty_selector_val>
      1c:      	popq	%rcx
      1d:      	retq
      1e:      	movl	$0xc00, %edx            # imm = 0xC00
      23:      	btq	%rcx, %rdx
      27:      	jb	0x40 <filter_64ty+0x40>
      29:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      33:      	btq	%rcx, %rdx
      37:      	jae	0x45 <filter_64ty+0x45>
      39:      	callq	0x400 <filter_64ty_range>
      3e:      	popq	%rcx
      3f:      	retq
      40:      	callq	0x380 <filter_64ty_map>
      45:      	popq	%rcx
      46:      	retq
      47:      	nopw	(%rax,%rax)

0000000000000050 <filter_32ty>:
      50:      	pushq	%rax
      51:      	movl	0x4(%rdi), %ecx
      54:      	xorl	%eax, %eax
      56:      	cmpq	$0x20, %rcx
      5a:      	ja	0x95 <filter_32ty+0x45>
      5c:      	movl	$0x101e, %edx           # imm = 0x101E
      61:      	btq	%rcx, %rdx
      65:      	jae	0x6e <filter_32ty+0x1e>
      67:      	callq	0x5e0 <filter_32ty_selector_val>
      6c:      	popq	%rcx
      6d:      	retq
      6e:      	movl	$0xc00, %edx            # imm = 0xC00
      73:      	btq	%rcx, %rdx
      77:      	jb	0x90 <filter_32ty+0x40>
      79:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      83:      	btq	%rcx, %rdx
      87:      	jae	0x95 <filter_32ty+0x45>
      89:      	callq	0x890 <filter_32ty_range>
      8e:      	popq	%rcx
      8f:      	retq
      90:      	callq	0x800 <filter_32ty_map>
      95:      	popq	%rcx
      96:      	retq
      97:      	nopw	(%rax,%rax)

00000000000000a0 <filter_16ty>:
      a0:      	pushq	%rax
      a1:      	movl	0x4(%rdi), %ecx
      a4:      	xorl	%eax, %eax
      a6:      	cmpq	$0x20, %rcx
      aa:      	ja	0xe5 <filter_16ty+0x45>
      ac:      	movl	$0x101e, %edx           # imm = 0x101E
      b1:      	btq	%rcx, %rdx
      b5:      	jae	0xbe <filter_16ty+0x1e>
      b7:      	callq	0xa50 <filter_16ty_selector_val>
      bc:      	popq	%rcx
      bd:      	retq
      be:      	movl	$0xc00, %edx            # imm = 0xC00
      c3:      	btq	%rcx, %rdx
      c7:      	jb	0xe0 <filter_16ty+0x40>
      c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      d3:      	btq	%rcx, %rdx
      d7:      	jae	0xe5 <filter_16ty+0x45>
      d9:      	callq	0xd00 <filter_16ty_range>
      de:      	popq	%rcx
      df:      	retq
      e0:      	callq	0xc70 <filter_16ty_map>
      e5:      	popq	%rcx
      e6:      	retq
      e7:      	nopw	(%rax,%rax)

00000000000000f0 <filter_8ty>:
      f0:      	pushq	%rax
      f1:      	movl	0x4(%rdi), %ecx
      f4:      	xorl	%eax, %eax
      f6:      	cmpq	$0x20, %rcx
      fa:      	ja	0x135 <filter_8ty+0x45>
      fc:      	movl	$0x101e, %edx           # imm = 0x101E
     101:      	btq	%rcx, %rdx
     105:      	jae	0x10e <filter_8ty+0x1e>
     107:      	callq	0xec0 <filter_8ty_selector_val>
     10c:      	popq	%rcx
     10d:      	retq
     10e:      	movl	$0xc00, %edx            # imm = 0xC00
     113:      	btq	%rcx, %rdx
     117:      	jb	0x130 <filter_8ty+0x40>
     119:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     123:      	btq	%rcx, %rdx
     127:      	jae	0x135 <filter_8ty+0x45>
     129:      	callq	0x1170 <filter_8ty_range>
     12e:      	popq	%rcx
     12f:      	retq
     130:      	callq	0x10e0 <filter_8ty_map>
     135:      	popq	%rcx
     136:      	retq
     137:      	nopw	(%rax,%rax)

0000000000000140 <filter_64ty_selector_val>:
     140:      	movl	0x4(%rdi), %ecx
     143:      	movl	$0x1, %eax
     148:      	cmpq	$0x25, %rcx
     14c:      	ja	0x1c4 <filter_64ty_selector_val+0x84>
     14e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     158:      	btq	%rcx, %rdx
     15c:      	jae	0x15f <filter_64ty_selector_val+0x1f>
     15e:      	retq
     15f:      	movl	$0x18, %edx
     164:      	btq	%rcx, %rdx
     168:      	jae	0x180 <filter_64ty_selector_val+0x40>
     16a:      	movq	(%rsi), %rdx
     16d:      	cmpq	0x10(%rdi), %rdx
     171:      	jne	0x2a2 <filter_64ty_selector_val+0x162>
     177:      	xorl	%eax, %eax
     179:      	cmpl	$0x3, %ecx
     17c:      	sete	%al
     17f:      	retq
     180:      	cmpq	$0xc, %rcx
     184:      	jne	0x1c4 <filter_64ty_selector_val+0x84>
     186:      	movq	(%rsi), %rcx
     189:      	testq	%rcx, 0x10(%rdi)
     18d:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     18f:      	movl	0x8(%rdi), %edx
     192:      	cmpl	$0x11, %edx
     195:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     19b:      	testq	%rcx, 0x18(%rdi)
     19f:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1a1:      	cmpl	$0x19, %edx
     1a4:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1aa:      	testq	%rcx, 0x20(%rdi)
     1ae:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1b0:      	cmpl	$0x21, %edx
     1b3:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1b9:      	testq	%rcx, 0x28(%rdi)
     1bd:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1bf:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     1c4:      	cmpl	$0x1, %ecx
     1c7:      	je	0x23a <filter_64ty_selector_val+0xfa>
     1c9:      	cmpl	$0x2, %ecx
     1cc:      	jne	0x36f <filter_64ty_selector_val+0x22f>
     1d2:      	movl	0xc(%rdi), %ecx
     1d5:      	cmpl	$0xc, %ecx
     1d8:      	ja	0x332 <filter_64ty_selector_val+0x1f2>
     1de:      	movl	$0x1402, %edx           # imm = 0x1402
     1e3:      	btl	%ecx, %edx
     1e6:      	jae	0x332 <filter_64ty_selector_val+0x1f2>
     1ec:      	movq	(%rsi), %rcx
     1ef:      	cmpq	0x10(%rdi), %rcx
     1f3:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     1f9:      	movl	0x8(%rdi), %edx
     1fc:      	cmpl	$0x11, %edx
     1ff:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     205:      	cmpq	0x18(%rdi), %rcx
     209:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     20f:      	cmpl	$0x19, %edx
     212:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     218:      	cmpq	0x20(%rdi), %rcx
     21c:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     222:      	cmpl	$0x21, %edx
     225:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     22b:      	cmpq	0x28(%rdi), %rcx
     22f:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     235:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     23a:      	movl	0xc(%rdi), %ecx
     23d:      	cmpl	$0xc, %ecx
     240:      	ja	0x2f3 <filter_64ty_selector_val+0x1b3>
     246:      	movl	$0x1402, %edx           # imm = 0x1402
     24b:      	btl	%ecx, %edx
     24e:      	jae	0x2f3 <filter_64ty_selector_val+0x1b3>
     254:      	movq	(%rsi), %rcx
     257:      	cmpq	0x10(%rdi), %rcx
     25b:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     261:      	movl	0x8(%rdi), %edx
     264:      	cmpl	$0x11, %edx
     267:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     26d:      	cmpq	0x18(%rdi), %rcx
     271:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     277:      	cmpl	$0x19, %edx
     27a:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     280:      	cmpq	0x20(%rdi), %rcx
     284:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     28a:      	cmpl	$0x21, %edx
     28d:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     293:      	cmpq	0x28(%rdi), %rcx
     297:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     29d:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2a2:      	movl	0x8(%rdi), %esi
     2a5:      	cmpl	$0x11, %esi
     2a8:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2aa:      	cmpq	0x18(%rdi), %rdx
     2ae:      	je	0x177 <filter_64ty_selector_val+0x37>
     2b4:      	cmpl	$0x19, %esi
     2b7:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2b9:      	cmpq	0x20(%rdi), %rdx
     2bd:      	je	0x177 <filter_64ty_selector_val+0x37>
     2c3:      	cmpl	$0x21, %esi
     2c6:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2c8:      	cmpq	0x28(%rdi), %rdx
     2cc:      	je	0x177 <filter_64ty_selector_val+0x37>
     2d2:      	cmpl	$0x25, %ecx
     2d5:      	ja	0x36f <filter_64ty_selector_val+0x22f>
     2db:      	movl	%ecx, %ecx
     2dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     2e7:      	btq	%rcx, %rdx
     2eb:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     2f1:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2f3:      	movq	(%rsi), %rcx
     2f6:      	cmpq	0x10(%rdi), %rcx
     2fa:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     300:      	movl	0x8(%rdi), %edx
     303:      	cmpl	$0x11, %edx
     306:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     308:      	cmpq	0x18(%rdi), %rcx
     30c:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     312:      	cmpl	$0x19, %edx
     315:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     317:      	cmpq	0x20(%rdi), %rcx
     31b:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     321:      	cmpl	$0x21, %edx
     324:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     326:      	cmpq	0x28(%rdi), %rcx
     32a:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     330:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     332:      	movq	(%rsi), %rcx
     335:      	cmpq	0x10(%rdi), %rcx
     339:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     33f:      	movl	0x8(%rdi), %edx
     342:      	cmpl	$0x11, %edx
     345:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     347:      	cmpq	0x18(%rdi), %rcx
     34b:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     351:      	cmpl	$0x19, %edx
     354:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     356:      	cmpq	0x20(%rdi), %rcx
     35a:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     360:      	cmpl	$0x21, %edx
     363:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     365:      	cmpq	0x28(%rdi), %rcx
     369:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     36f:      	xorl	%eax, %eax
     371:      	retq
     372:      	nopw	%cs:(%rax,%rax)

0000000000000380 <filter_64ty_map>:
     380:      	pushq	%r14
     382:      	pushq	%rbx
     383:      	subq	$0x18, %rsp
     387:      	movq	%rsi, %r14
     38a:      	movq	%rdi, %rbx
     38d:      	movzbl	0x10(%rdi), %eax
     391:      	movl	%eax, 0xc(%rsp)
     395:      	movq	(%rip), %rdi            # 0x39c <filter_64ty_map+0x1c>
     39c:      	leaq	0xc(%rsp), %rsi
     3a1:      	movl	$0x1, %eax
     3a6:      	callq	*%rax
     3a8:      	testq	%rax, %rax
     3ab:      	je	0x3d9 <filter_64ty_map+0x59>
     3ad:      	movq	%rax, %rdi
     3b0:      	movq	(%r14), %rax
     3b3:      	movq	%rax, 0x10(%rsp)
     3b8:      	leaq	0x10(%rsp), %rsi
     3bd:      	movl	$0x1, %eax
     3c2:      	callq	*%rax
     3c4:      	movl	0x4(%rbx), %ecx
     3c7:      	cmpl	$0xb, %ecx
     3ca:      	je	0x3e3 <filter_64ty_map+0x63>
     3cc:      	cmpl	$0xa, %ecx
     3cf:      	jne	0x3eb <filter_64ty_map+0x6b>
     3d1:      	testq	%rax, %rax
     3d4:      	setne	%al
     3d7:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3d9:      	xorl	%eax, %eax
     3db:      	addq	$0x18, %rsp
     3df:      	popq	%rbx
     3e0:      	popq	%r14
     3e2:      	retq
     3e3:      	testq	%rax, %rax
     3e6:      	sete	%al
     3e9:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3eb:      	xorl	%eax, %eax
     3ed:      	movzbl	%al, %eax
     3f0:      	addq	$0x18, %rsp
     3f4:      	popq	%rbx
     3f5:      	popq	%r14
     3f7:      	retq
     3f8:      	nopl	(%rax,%rax)

0000000000000400 <filter_64ty_range>:
     400:      	movl	0x4(%rdi), %ecx
     403:      	movl	0xc(%rdi), %eax
     406:      	cmpl	$0xc, %eax
     409:      	ja	0x500 <filter_64ty_range+0x100>
     40f:      	movl	$0x1402, %edx           # imm = 0x1402
     414:      	btl	%eax, %edx
     417:      	jae	0x500 <filter_64ty_range+0x100>
     41d:      	movq	(%rsi), %rsi
     420:      	cmpl	$0x1f, %ecx
     423:      	jne	0x493 <filter_64ty_range+0x93>
     425:      	movl	$0x1, %eax
     42a:      	cmpq	%rsi, 0x10(%rdi)
     42e:      	jg	0x43a <filter_64ty_range+0x3a>
     430:      	cmpq	0x18(%rdi), %rsi
     434:      	jle	0x519 <filter_64ty_range+0x119>
     43a:      	movl	0x8(%rdi), %edx
     43d:      	cmpl	$0x19, %edx
     440:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     446:      	cmpq	%rsi, 0x20(%rdi)
     44a:      	jg	0x456 <filter_64ty_range+0x56>
     44c:      	cmpq	0x28(%rdi), %rsi
     450:      	jle	0x519 <filter_64ty_range+0x119>
     456:      	cmpl	$0x29, %edx
     459:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     45f:      	cmpq	%rsi, 0x30(%rdi)
     463:      	jg	0x46f <filter_64ty_range+0x6f>
     465:      	cmpq	0x38(%rdi), %rsi
     469:      	jle	0x519 <filter_64ty_range+0x119>
     46f:      	cmpl	$0x39, %edx
     472:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     478:      	xorl	%edx, %edx
     47a:      	cmpq	%rsi, 0x40(%rdi)
     47e:      	jg	0x5c9 <filter_64ty_range+0x1c9>
     484:      	cmpq	0x48(%rdi), %rsi
     488:      	jle	0x519 <filter_64ty_range+0x119>
     48e:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     493:      	movl	0x8(%rdi), %eax
     496:      	cmpq	%rsi, 0x10(%rdi)
     49a:      	setle	%r8b
     49e:      	cmpq	0x18(%rdi), %rsi
     4a2:      	setle	%dl
     4a5:      	andb	%r8b, %dl
     4a8:      	cmpl	$0x19, %eax
     4ab:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4b1:      	cmpq	%rsi, 0x20(%rdi)
     4b5:      	setle	%r8b
     4b9:      	cmpq	0x28(%rdi), %rsi
     4bd:      	setle	%r9b
     4c1:      	andb	%r8b, %r9b
     4c4:      	orb	%r9b, %dl
     4c7:      	cmpl	$0x29, %eax
     4ca:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4d0:      	cmpq	%rsi, 0x30(%rdi)
     4d4:      	setle	%r8b
     4d8:      	cmpq	0x38(%rdi), %rsi
     4dc:      	setle	%r9b
     4e0:      	andb	%r8b, %r9b
     4e3:      	orb	%r9b, %dl
     4e6:      	cmpl	$0x39, %eax
     4e9:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4ef:      	cmpq	%rsi, 0x40(%rdi)
     4f3:      	setle	%al
     4f6:      	cmpq	0x48(%rdi), %rsi
     4fa:      	setle	%sil
     4fe:      	jmp	0x57d <filter_64ty_range+0x17d>
     500:      	movq	(%rsi), %rsi
     503:      	cmpl	$0x1f, %ecx
     506:      	jne	0x51a <filter_64ty_range+0x11a>
     508:      	movl	$0x1, %eax
     50d:      	cmpq	%rsi, 0x10(%rdi)
     511:      	ja	0x585 <filter_64ty_range+0x185>
     513:      	cmpq	0x18(%rdi), %rsi
     517:      	ja	0x585 <filter_64ty_range+0x185>
     519:      	retq
     51a:      	movl	0x8(%rdi), %eax
     51d:      	cmpq	%rsi, 0x10(%rdi)
     521:      	setbe	%r8b
     525:      	cmpq	0x18(%rdi), %rsi
     529:      	setbe	%dl
     52c:      	andb	%r8b, %dl
     52f:      	cmpl	$0x19, %eax
     532:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     538:      	cmpq	%rsi, 0x20(%rdi)
     53c:      	setbe	%r8b
     540:      	cmpq	0x28(%rdi), %rsi
     544:      	setbe	%r9b
     548:      	andb	%r8b, %r9b
     54b:      	orb	%r9b, %dl
     54e:      	cmpl	$0x29, %eax
     551:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     553:      	cmpq	%rsi, 0x30(%rdi)
     557:      	setbe	%r8b
     55b:      	cmpq	0x38(%rdi), %rsi
     55f:      	setbe	%r9b
     563:      	andb	%r8b, %r9b
     566:      	orb	%r9b, %dl
     569:      	cmpl	$0x39, %eax
     56c:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     56e:      	cmpq	%rsi, 0x40(%rdi)
     572:      	setbe	%al
     575:      	cmpq	0x48(%rdi), %rsi
     579:      	setbe	%sil
     57d:      	andb	%al, %sil
     580:      	orb	%sil, %dl
     583:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     585:      	movl	0x8(%rdi), %edx
     588:      	cmpl	$0x19, %edx
     58b:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     58d:      	cmpq	%rsi, 0x20(%rdi)
     591:      	ja	0x599 <filter_64ty_range+0x199>
     593:      	cmpq	0x28(%rdi), %rsi
     597:      	jbe	0x519 <filter_64ty_range+0x119>
     599:      	cmpl	$0x29, %edx
     59c:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     59e:      	cmpq	%rsi, 0x30(%rdi)
     5a2:      	ja	0x5ae <filter_64ty_range+0x1ae>
     5a4:      	cmpq	0x38(%rdi), %rsi
     5a8:      	jbe	0x519 <filter_64ty_range+0x119>
     5ae:      	cmpl	$0x39, %edx
     5b1:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     5b3:      	xorl	%edx, %edx
     5b5:      	cmpq	%rsi, 0x40(%rdi)
     5b9:      	ja	0x5c9 <filter_64ty_range+0x1c9>
     5bb:      	cmpq	0x48(%rdi), %rsi
     5bf:      	jbe	0x519 <filter_64ty_range+0x119>
     5c5:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     5c7:      	xorl	%edx, %edx
     5c9:      	cmpl	$0x20, %ecx
     5cc:      	sete	%al
     5cf:      	xorb	$0x1, %dl
     5d2:      	andb	%al, %dl
     5d4:      	movzbl	%dl, %eax
     5d7:      	retq
     5d8:      	nopl	(%rax,%rax)

00000000000005e0 <filter_32ty_selector_val>:
     5e0:      	movl	0x4(%rdi), %ecx
     5e3:      	movl	$0x1, %eax
     5e8:      	cmpq	$0x25, %rcx
     5ec:      	ja	0x65d <filter_32ty_selector_val+0x7d>
     5ee:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     5f8:      	btq	%rcx, %rdx
     5fc:      	jae	0x5ff <filter_32ty_selector_val+0x1f>
     5fe:      	retq
     5ff:      	movl	$0x18, %edx
     604:      	btq	%rcx, %rdx
     608:      	jae	0x61e <filter_32ty_selector_val+0x3e>
     60a:      	movl	(%rsi), %edx
     60c:      	cmpl	0x10(%rdi), %edx
     60f:      	jne	0x731 <filter_32ty_selector_val+0x151>
     615:      	xorl	%eax, %eax
     617:      	cmpl	$0x3, %ecx
     61a:      	sete	%al
     61d:      	retq
     61e:      	cmpq	$0xc, %rcx
     622:      	jne	0x65d <filter_32ty_selector_val+0x7d>
     624:      	movl	(%rsi), %ecx
     626:      	testl	%ecx, 0x10(%rdi)
     629:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     62b:      	movl	0x8(%rdi), %edx
     62e:      	cmpl	$0xd, %edx
     631:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     637:      	testl	%ecx, 0x14(%rdi)
     63a:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     63c:      	cmpl	$0x11, %edx
     63f:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     645:      	testl	%ecx, 0x18(%rdi)
     648:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     64a:      	cmpl	$0x15, %edx
     64d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     653:      	testl	%ecx, 0x1c(%rdi)
     656:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     658:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     65d:      	cmpl	$0x1, %ecx
     660:      	je	0x6ce <filter_32ty_selector_val+0xee>
     662:      	cmpl	$0x2, %ecx
     665:      	jne	0x7f1 <filter_32ty_selector_val+0x211>
     66b:      	movl	0xc(%rdi), %ecx
     66e:      	cmpl	$0xc, %ecx
     671:      	ja	0x7b9 <filter_32ty_selector_val+0x1d9>
     677:      	movl	$0x1402, %edx           # imm = 0x1402
     67c:      	btl	%ecx, %edx
     67f:      	jae	0x7b9 <filter_32ty_selector_val+0x1d9>
     685:      	movl	(%rsi), %ecx
     687:      	cmpl	0x10(%rdi), %ecx
     68a:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     690:      	movl	0x8(%rdi), %edx
     693:      	cmpl	$0xd, %edx
     696:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     69c:      	cmpl	0x14(%rdi), %ecx
     69f:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6a5:      	cmpl	$0x11, %edx
     6a8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ae:      	cmpl	0x18(%rdi), %ecx
     6b1:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6b7:      	cmpl	$0x15, %edx
     6ba:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6c0:      	cmpl	0x1c(%rdi), %ecx
     6c3:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6c9:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     6ce:      	movl	0xc(%rdi), %ecx
     6d1:      	cmpl	$0xc, %ecx
     6d4:      	ja	0x77f <filter_32ty_selector_val+0x19f>
     6da:      	movl	$0x1402, %edx           # imm = 0x1402
     6df:      	btl	%ecx, %edx
     6e2:      	jae	0x77f <filter_32ty_selector_val+0x19f>
     6e8:      	movl	(%rsi), %ecx
     6ea:      	cmpl	0x10(%rdi), %ecx
     6ed:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     6f3:      	movl	0x8(%rdi), %edx
     6f6:      	cmpl	$0xd, %edx
     6f9:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ff:      	cmpl	0x14(%rdi), %ecx
     702:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     708:      	cmpl	$0x11, %edx
     70b:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     711:      	cmpl	0x18(%rdi), %ecx
     714:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     71a:      	cmpl	$0x15, %edx
     71d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     723:      	cmpl	0x1c(%rdi), %ecx
     726:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     72c:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     731:      	movl	0x8(%rdi), %esi
     734:      	cmpl	$0xd, %esi
     737:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     739:      	cmpl	0x14(%rdi), %edx
     73c:      	je	0x615 <filter_32ty_selector_val+0x35>
     742:      	cmpl	$0x11, %esi
     745:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     747:      	cmpl	0x18(%rdi), %edx
     74a:      	je	0x615 <filter_32ty_selector_val+0x35>
     750:      	cmpl	$0x15, %esi
     753:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     755:      	cmpl	0x1c(%rdi), %edx
     758:      	je	0x615 <filter_32ty_selector_val+0x35>
     75e:      	cmpl	$0x25, %ecx
     761:      	ja	0x7f1 <filter_32ty_selector_val+0x211>
     767:      	movl	%ecx, %ecx
     769:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     773:      	btq	%rcx, %rdx
     777:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     77d:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     77f:      	movl	(%rsi), %ecx
     781:      	cmpl	0x10(%rdi), %ecx
     784:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     78a:      	movl	0x8(%rdi), %edx
     78d:      	cmpl	$0xd, %edx
     790:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     792:      	cmpl	0x14(%rdi), %ecx
     795:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     79b:      	cmpl	$0x11, %edx
     79e:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7a0:      	cmpl	0x18(%rdi), %ecx
     7a3:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7a9:      	cmpl	$0x15, %edx
     7ac:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7ae:      	cmpl	0x1c(%rdi), %ecx
     7b1:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7b7:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     7b9:      	movl	(%rsi), %ecx
     7bb:      	cmpl	0x10(%rdi), %ecx
     7be:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7c4:      	movl	0x8(%rdi), %edx
     7c7:      	cmpl	$0xd, %edx
     7ca:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7cc:      	cmpl	0x14(%rdi), %ecx
     7cf:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7d5:      	cmpl	$0x11, %edx
     7d8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7da:      	cmpl	0x18(%rdi), %ecx
     7dd:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7e3:      	cmpl	$0x15, %edx
     7e6:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7e8:      	cmpl	0x1c(%rdi), %ecx
     7eb:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7f1:      	xorl	%eax, %eax
     7f3:      	retq
     7f4:      	nopw	%cs:(%rax,%rax)

0000000000000800 <filter_32ty_map>:
     800:      	pushq	%r14
     802:      	pushq	%rbx
     803:      	subq	$0x18, %rsp
     807:      	movq	%rsi, %r14
     80a:      	movq	%rdi, %rbx
     80d:      	movzbl	0x10(%rdi), %eax
     811:      	movl	%eax, 0xc(%rsp)
     815:      	movq	(%rip), %rdi            # 0x81c <filter_32ty_map+0x1c>
     81c:      	leaq	0xc(%rsp), %rsi
     821:      	movl	$0x1, %eax
     826:      	callq	*%rax
     828:      	testq	%rax, %rax
     82b:      	je	0x860 <filter_32ty_map+0x60>
     82d:      	movq	%rax, %rdi
     830:      	movl	(%r14), %eax
     833:      	movq	%rax, 0x10(%rsp)
     838:      	leaq	0x10(%rsp), %rsi
     83d:      	movl	$0x1, %eax
     842:      	callq	*%rax
     844:      	movl	0x4(%rbx), %edx
     847:      	xorl	%ecx, %ecx
     849:      	cmpl	$0x1d, %edx
     84c:      	ja	0x87a <filter_32ty_map+0x7a>
     84e:      	movl	$0x30038400, %esi       # imm = 0x30038400
     853:      	btl	%edx, %esi
     856:      	jae	0x86a <filter_32ty_map+0x6a>
     858:      	testq	%rax, %rax
     85b:      	setne	%cl
     85e:      	jmp	0x87a <filter_32ty_map+0x7a>
     860:      	xorl	%eax, %eax
     862:      	addq	$0x18, %rsp
     866:      	popq	%rbx
     867:      	popq	%r14
     869:      	retq
     86a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     86f:      	btl	%edx, %esi
     872:      	jae	0x87a <filter_32ty_map+0x7a>
     874:      	testq	%rax, %rax
     877:      	sete	%cl
     87a:      	movzbl	%cl, %eax
     87d:      	addq	$0x18, %rsp
     881:      	popq	%rbx
     882:      	popq	%r14
     884:      	retq
     885:      	nopw	%cs:(%rax,%rax)

0000000000000890 <filter_32ty_range>:
     890:      	movl	0x4(%rdi), %ecx
     893:      	movl	0xc(%rdi), %eax
     896:      	cmpl	$0xc, %eax
     899:      	ja	0x97f <filter_32ty_range+0xef>
     89f:      	movl	$0x1402, %edx           # imm = 0x1402
     8a4:      	btl	%eax, %edx
     8a7:      	jae	0x97f <filter_32ty_range+0xef>
     8ad:      	movl	(%rsi), %esi
     8af:      	cmpl	$0x1f, %ecx
     8b2:      	jne	0x91a <filter_32ty_range+0x8a>
     8b4:      	movl	$0x1, %eax
     8b9:      	cmpl	%esi, 0x10(%rdi)
     8bc:      	jg	0x8c7 <filter_32ty_range+0x37>
     8be:      	cmpl	0x14(%rdi), %esi
     8c1:      	jle	0x995 <filter_32ty_range+0x105>
     8c7:      	movl	0x8(%rdi), %edx
     8ca:      	cmpl	$0x11, %edx
     8cd:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8d3:      	cmpl	%esi, 0x18(%rdi)
     8d6:      	jg	0x8e1 <filter_32ty_range+0x51>
     8d8:      	cmpl	0x1c(%rdi), %esi
     8db:      	jle	0x995 <filter_32ty_range+0x105>
     8e1:      	cmpl	$0x19, %edx
     8e4:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8ea:      	cmpl	%esi, 0x20(%rdi)
     8ed:      	jg	0x8f8 <filter_32ty_range+0x68>
     8ef:      	cmpl	0x24(%rdi), %esi
     8f2:      	jle	0x995 <filter_32ty_range+0x105>
     8f8:      	cmpl	$0x21, %edx
     8fb:      	jb	0xa35 <filter_32ty_range+0x1a5>
     901:      	xorl	%edx, %edx
     903:      	cmpl	%esi, 0x28(%rdi)
     906:      	jg	0xa37 <filter_32ty_range+0x1a7>
     90c:      	cmpl	0x2c(%rdi), %esi
     90f:      	jle	0x995 <filter_32ty_range+0x105>
     915:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     91a:      	movl	0x8(%rdi), %eax
     91d:      	cmpl	%esi, 0x10(%rdi)
     920:      	setle	%r8b
     924:      	cmpl	0x14(%rdi), %esi
     927:      	setle	%dl
     92a:      	andb	%r8b, %dl
     92d:      	cmpl	$0x11, %eax
     930:      	jb	0xa37 <filter_32ty_range+0x1a7>
     936:      	cmpl	%esi, 0x18(%rdi)
     939:      	setle	%r8b
     93d:      	cmpl	0x1c(%rdi), %esi
     940:      	setle	%r9b
     944:      	andb	%r8b, %r9b
     947:      	orb	%r9b, %dl
     94a:      	cmpl	$0x19, %eax
     94d:      	jb	0xa37 <filter_32ty_range+0x1a7>
     953:      	cmpl	%esi, 0x20(%rdi)
     956:      	setle	%r8b
     95a:      	cmpl	0x24(%rdi), %esi
     95d:      	setle	%r9b
     961:      	andb	%r8b, %r9b
     964:      	orb	%r9b, %dl
     967:      	cmpl	$0x21, %eax
     96a:      	jb	0xa37 <filter_32ty_range+0x1a7>
     970:      	cmpl	%esi, 0x28(%rdi)
     973:      	setle	%al
     976:      	cmpl	0x2c(%rdi), %esi
     979:      	setle	%sil
     97d:      	jmp	0x9f1 <filter_32ty_range+0x161>
     97f:      	movl	(%rsi), %esi
     981:      	cmpl	$0x1f, %ecx
     984:      	jne	0x996 <filter_32ty_range+0x106>
     986:      	movl	$0x1, %eax
     98b:      	cmpl	%esi, 0x10(%rdi)
     98e:      	ja	0x9f9 <filter_32ty_range+0x169>
     990:      	cmpl	0x14(%rdi), %esi
     993:      	ja	0x9f9 <filter_32ty_range+0x169>
     995:      	retq
     996:      	movl	0x8(%rdi), %eax
     999:      	cmpl	%esi, 0x10(%rdi)
     99c:      	setbe	%r8b
     9a0:      	cmpl	0x14(%rdi), %esi
     9a3:      	setbe	%dl
     9a6:      	andb	%r8b, %dl
     9a9:      	cmpl	$0x11, %eax
     9ac:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9b2:      	cmpl	%esi, 0x18(%rdi)
     9b5:      	setbe	%r8b
     9b9:      	cmpl	0x1c(%rdi), %esi
     9bc:      	setbe	%r9b
     9c0:      	andb	%r8b, %r9b
     9c3:      	orb	%r9b, %dl
     9c6:      	cmpl	$0x19, %eax
     9c9:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9cb:      	cmpl	%esi, 0x20(%rdi)
     9ce:      	setbe	%r8b
     9d2:      	cmpl	0x24(%rdi), %esi
     9d5:      	setbe	%r9b
     9d9:      	andb	%r8b, %r9b
     9dc:      	orb	%r9b, %dl
     9df:      	cmpl	$0x21, %eax
     9e2:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9e4:      	cmpl	%esi, 0x28(%rdi)
     9e7:      	setbe	%al
     9ea:      	cmpl	0x2c(%rdi), %esi
     9ed:      	setbe	%sil
     9f1:      	andb	%al, %sil
     9f4:      	orb	%sil, %dl
     9f7:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     9f9:      	movl	0x8(%rdi), %edx
     9fc:      	cmpl	$0x11, %edx
     9ff:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a01:      	cmpl	%esi, 0x18(%rdi)
     a04:      	ja	0xa0b <filter_32ty_range+0x17b>
     a06:      	cmpl	0x1c(%rdi), %esi
     a09:      	jbe	0x995 <filter_32ty_range+0x105>
     a0b:      	cmpl	$0x19, %edx
     a0e:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a10:      	cmpl	%esi, 0x20(%rdi)
     a13:      	ja	0xa1e <filter_32ty_range+0x18e>
     a15:      	cmpl	0x24(%rdi), %esi
     a18:      	jbe	0x995 <filter_32ty_range+0x105>
     a1e:      	cmpl	$0x21, %edx
     a21:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a23:      	xorl	%edx, %edx
     a25:      	cmpl	%esi, 0x28(%rdi)
     a28:      	ja	0xa37 <filter_32ty_range+0x1a7>
     a2a:      	cmpl	0x2c(%rdi), %esi
     a2d:      	jbe	0x995 <filter_32ty_range+0x105>
     a33:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     a35:      	xorl	%edx, %edx
     a37:      	cmpl	$0x20, %ecx
     a3a:      	sete	%al
     a3d:      	xorb	$0x1, %dl
     a40:      	andb	%al, %dl
     a42:      	movzbl	%dl, %eax
     a45:      	retq
     a46:      	nopw	%cs:(%rax,%rax)

0000000000000a50 <filter_16ty_selector_val>:
     a50:      	movl	0x4(%rdi), %ecx
     a53:      	movl	$0x1, %eax
     a58:      	cmpq	$0x25, %rcx
     a5c:      	ja	0xacf <filter_16ty_selector_val+0x7f>
     a5e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     a68:      	btq	%rcx, %rdx
     a6c:      	jae	0xa6f <filter_16ty_selector_val+0x1f>
     a6e:      	retq
     a6f:      	movl	$0x18, %edx
     a74:      	btq	%rcx, %rdx
     a78:      	jae	0xa8f <filter_16ty_selector_val+0x3f>
     a7a:      	movzwl	(%rsi), %edx
     a7d:      	cmpl	%edx, 0x10(%rdi)
     a80:      	jne	0xba5 <filter_16ty_selector_val+0x155>
     a86:      	xorl	%eax, %eax
     a88:      	cmpl	$0x3, %ecx
     a8b:      	sete	%al
     a8e:      	retq
     a8f:      	cmpq	$0xc, %rcx
     a93:      	jne	0xacf <filter_16ty_selector_val+0x7f>
     a95:      	movzwl	(%rsi), %ecx
     a98:      	testl	%ecx, 0x10(%rdi)
     a9b:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     a9d:      	movl	0x8(%rdi), %edx
     aa0:      	cmpl	$0xd, %edx
     aa3:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     aa9:      	testl	%ecx, 0x14(%rdi)
     aac:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aae:      	cmpl	$0x11, %edx
     ab1:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ab7:      	testl	%ecx, 0x18(%rdi)
     aba:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     abc:      	cmpl	$0x15, %edx
     abf:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ac5:      	testl	%ecx, 0x1c(%rdi)
     ac8:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aca:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     acf:      	cmpl	$0x1, %ecx
     ad2:      	je	0xb41 <filter_16ty_selector_val+0xf1>
     ad4:      	cmpl	$0x2, %ecx
     ad7:      	jne	0xc67 <filter_16ty_selector_val+0x217>
     add:      	movl	0xc(%rdi), %ecx
     ae0:      	cmpl	$0xc, %ecx
     ae3:      	ja	0xc2e <filter_16ty_selector_val+0x1de>
     ae9:      	movl	$0x1402, %edx           # imm = 0x1402
     aee:      	btl	%ecx, %edx
     af1:      	jae	0xc2e <filter_16ty_selector_val+0x1de>
     af7:      	movswl	(%rsi), %ecx
     afa:      	cmpl	%ecx, 0x10(%rdi)
     afd:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b03:      	movl	0x8(%rdi), %edx
     b06:      	cmpl	$0xd, %edx
     b09:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b0f:      	cmpl	%ecx, 0x14(%rdi)
     b12:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b18:      	cmpl	$0x11, %edx
     b1b:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b21:      	cmpl	%ecx, 0x18(%rdi)
     b24:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b2a:      	cmpl	$0x15, %edx
     b2d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b33:      	cmpl	%ecx, 0x1c(%rdi)
     b36:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b3c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     b41:      	movl	0xc(%rdi), %ecx
     b44:      	cmpl	$0xc, %ecx
     b47:      	ja	0xbf3 <filter_16ty_selector_val+0x1a3>
     b4d:      	movl	$0x1402, %edx           # imm = 0x1402
     b52:      	btl	%ecx, %edx
     b55:      	jae	0xbf3 <filter_16ty_selector_val+0x1a3>
     b5b:      	movswl	(%rsi), %ecx
     b5e:      	cmpl	%ecx, 0x10(%rdi)
     b61:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b67:      	movl	0x8(%rdi), %edx
     b6a:      	cmpl	$0xd, %edx
     b6d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b73:      	cmpl	%ecx, 0x14(%rdi)
     b76:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b7c:      	cmpl	$0x11, %edx
     b7f:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b85:      	cmpl	%ecx, 0x18(%rdi)
     b88:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b8e:      	cmpl	$0x15, %edx
     b91:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b97:      	cmpl	%ecx, 0x1c(%rdi)
     b9a:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     ba0:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     ba5:      	movl	0x8(%rdi), %esi
     ba8:      	cmpl	$0xd, %esi
     bab:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bad:      	cmpl	%edx, 0x14(%rdi)
     bb0:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bb6:      	cmpl	$0x11, %esi
     bb9:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bbb:      	cmpl	%edx, 0x18(%rdi)
     bbe:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bc4:      	cmpl	$0x15, %esi
     bc7:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bc9:      	cmpl	%edx, 0x1c(%rdi)
     bcc:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bd2:      	cmpl	$0x25, %ecx
     bd5:      	ja	0xc67 <filter_16ty_selector_val+0x217>
     bdb:      	movl	%ecx, %ecx
     bdd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     be7:      	btq	%rcx, %rdx
     beb:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bf1:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     bf3:      	movzwl	(%rsi), %ecx
     bf6:      	cmpl	%ecx, 0x10(%rdi)
     bf9:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bff:      	movl	0x8(%rdi), %edx
     c02:      	cmpl	$0xd, %edx
     c05:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c07:      	cmpl	%ecx, 0x14(%rdi)
     c0a:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c10:      	cmpl	$0x11, %edx
     c13:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c15:      	cmpl	%ecx, 0x18(%rdi)
     c18:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c1e:      	cmpl	$0x15, %edx
     c21:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c23:      	cmpl	%ecx, 0x1c(%rdi)
     c26:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c2c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     c2e:      	movzwl	(%rsi), %ecx
     c31:      	cmpl	%ecx, 0x10(%rdi)
     c34:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c3a:      	movl	0x8(%rdi), %edx
     c3d:      	cmpl	$0xd, %edx
     c40:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c42:      	cmpl	%ecx, 0x14(%rdi)
     c45:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c4b:      	cmpl	$0x11, %edx
     c4e:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c50:      	cmpl	%ecx, 0x18(%rdi)
     c53:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c59:      	cmpl	$0x15, %edx
     c5c:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c5e:      	cmpl	%ecx, 0x1c(%rdi)
     c61:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c67:      	xorl	%eax, %eax
     c69:      	retq
     c6a:      	nopw	(%rax,%rax)

0000000000000c70 <filter_16ty_map>:
     c70:      	pushq	%r14
     c72:      	pushq	%rbx
     c73:      	subq	$0x18, %rsp
     c77:      	movq	%rsi, %r14
     c7a:      	movq	%rdi, %rbx
     c7d:      	movzbl	0x10(%rdi), %eax
     c81:      	movl	%eax, 0xc(%rsp)
     c85:      	movq	(%rip), %rdi            # 0xc8c <filter_16ty_map+0x1c>
     c8c:      	leaq	0xc(%rsp), %rsi
     c91:      	movl	$0x1, %eax
     c96:      	callq	*%rax
     c98:      	testq	%rax, %rax
     c9b:      	je	0xcd1 <filter_16ty_map+0x61>
     c9d:      	movq	%rax, %rdi
     ca0:      	movzwl	(%r14), %eax
     ca4:      	movq	%rax, 0x10(%rsp)
     ca9:      	leaq	0x10(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	movl	0x4(%rbx), %edx
     cb8:      	xorl	%ecx, %ecx
     cba:      	cmpl	$0x1d, %edx
     cbd:      	ja	0xceb <filter_16ty_map+0x7b>
     cbf:      	movl	$0x30038400, %esi       # imm = 0x30038400
     cc4:      	btl	%edx, %esi
     cc7:      	jae	0xcdb <filter_16ty_map+0x6b>
     cc9:      	testq	%rax, %rax
     ccc:      	setne	%cl
     ccf:      	jmp	0xceb <filter_16ty_map+0x7b>
     cd1:      	xorl	%eax, %eax
     cd3:      	addq	$0x18, %rsp
     cd7:      	popq	%rbx
     cd8:      	popq	%r14
     cda:      	retq
     cdb:      	movl	$0xc0800, %esi          # imm = 0xC0800
     ce0:      	btl	%edx, %esi
     ce3:      	jae	0xceb <filter_16ty_map+0x7b>
     ce5:      	testq	%rax, %rax
     ce8:      	sete	%cl
     ceb:      	movzbl	%cl, %eax
     cee:      	addq	$0x18, %rsp
     cf2:      	popq	%rbx
     cf3:      	popq	%r14
     cf5:      	retq
     cf6:      	nopw	%cs:(%rax,%rax)

0000000000000d00 <filter_16ty_range>:
     d00:      	movl	0x4(%rdi), %ecx
     d03:      	movl	0xc(%rdi), %eax
     d06:      	cmpl	$0xc, %eax
     d09:      	ja	0xdf0 <filter_16ty_range+0xf0>
     d0f:      	movl	$0x1402, %edx           # imm = 0x1402
     d14:      	btl	%eax, %edx
     d17:      	jae	0xdf0 <filter_16ty_range+0xf0>
     d1d:      	movswl	(%rsi), %esi
     d20:      	cmpl	$0x1f, %ecx
     d23:      	jne	0xd8b <filter_16ty_range+0x8b>
     d25:      	movl	$0x1, %eax
     d2a:      	cmpl	%esi, 0x10(%rdi)
     d2d:      	jg	0xd38 <filter_16ty_range+0x38>
     d2f:      	cmpl	%esi, 0x14(%rdi)
     d32:      	jge	0xe07 <filter_16ty_range+0x107>
     d38:      	movl	0x8(%rdi), %edx
     d3b:      	cmpl	$0x11, %edx
     d3e:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d44:      	cmpl	%esi, 0x18(%rdi)
     d47:      	jg	0xd52 <filter_16ty_range+0x52>
     d49:      	cmpl	%esi, 0x1c(%rdi)
     d4c:      	jge	0xe07 <filter_16ty_range+0x107>
     d52:      	cmpl	$0x19, %edx
     d55:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d5b:      	cmpl	%esi, 0x20(%rdi)
     d5e:      	jg	0xd69 <filter_16ty_range+0x69>
     d60:      	cmpl	%esi, 0x24(%rdi)
     d63:      	jge	0xe07 <filter_16ty_range+0x107>
     d69:      	cmpl	$0x21, %edx
     d6c:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d72:      	xorl	%edx, %edx
     d74:      	cmpl	%esi, 0x28(%rdi)
     d77:      	jg	0xea9 <filter_16ty_range+0x1a9>
     d7d:      	cmpl	%esi, 0x2c(%rdi)
     d80:      	jge	0xe07 <filter_16ty_range+0x107>
     d86:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     d8b:      	movl	0x8(%rdi), %eax
     d8e:      	cmpl	%esi, 0x10(%rdi)
     d91:      	setle	%r8b
     d95:      	cmpl	%esi, 0x14(%rdi)
     d98:      	setge	%dl
     d9b:      	andb	%r8b, %dl
     d9e:      	cmpl	$0x11, %eax
     da1:      	jb	0xea9 <filter_16ty_range+0x1a9>
     da7:      	cmpl	%esi, 0x18(%rdi)
     daa:      	setle	%r8b
     dae:      	cmpl	%esi, 0x1c(%rdi)
     db1:      	setge	%r9b
     db5:      	andb	%r8b, %r9b
     db8:      	orb	%r9b, %dl
     dbb:      	cmpl	$0x19, %eax
     dbe:      	jb	0xea9 <filter_16ty_range+0x1a9>
     dc4:      	cmpl	%esi, 0x20(%rdi)
     dc7:      	setle	%r8b
     dcb:      	cmpl	%esi, 0x24(%rdi)
     dce:      	setge	%r9b
     dd2:      	andb	%r8b, %r9b
     dd5:      	orb	%r9b, %dl
     dd8:      	cmpl	$0x21, %eax
     ddb:      	jb	0xea9 <filter_16ty_range+0x1a9>
     de1:      	cmpl	%esi, 0x28(%rdi)
     de4:      	setle	%al
     de7:      	cmpl	%esi, 0x2c(%rdi)
     dea:      	setge	%sil
     dee:      	jmp	0xe63 <filter_16ty_range+0x163>
     df0:      	movzwl	(%rsi), %esi
     df3:      	cmpl	$0x1f, %ecx
     df6:      	jne	0xe08 <filter_16ty_range+0x108>
     df8:      	movl	$0x1, %eax
     dfd:      	cmpl	%esi, 0x10(%rdi)
     e00:      	ja	0xe6b <filter_16ty_range+0x16b>
     e02:      	cmpl	%esi, 0x14(%rdi)
     e05:      	jb	0xe6b <filter_16ty_range+0x16b>
     e07:      	retq
     e08:      	movl	0x8(%rdi), %eax
     e0b:      	cmpl	%esi, 0x10(%rdi)
     e0e:      	setbe	%r8b
     e12:      	cmpl	%esi, 0x14(%rdi)
     e15:      	setae	%dl
     e18:      	andb	%r8b, %dl
     e1b:      	cmpl	$0x11, %eax
     e1e:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e24:      	cmpl	%esi, 0x18(%rdi)
     e27:      	setbe	%r8b
     e2b:      	cmpl	%esi, 0x1c(%rdi)
     e2e:      	setae	%r9b
     e32:      	andb	%r8b, %r9b
     e35:      	orb	%r9b, %dl
     e38:      	cmpl	$0x19, %eax
     e3b:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e3d:      	cmpl	%esi, 0x20(%rdi)
     e40:      	setbe	%r8b
     e44:      	cmpl	%esi, 0x24(%rdi)
     e47:      	setae	%r9b
     e4b:      	andb	%r8b, %r9b
     e4e:      	orb	%r9b, %dl
     e51:      	cmpl	$0x21, %eax
     e54:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e56:      	cmpl	%esi, 0x28(%rdi)
     e59:      	setbe	%al
     e5c:      	cmpl	%esi, 0x2c(%rdi)
     e5f:      	setae	%sil
     e63:      	andb	%al, %sil
     e66:      	orb	%sil, %dl
     e69:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     e6b:      	movl	0x8(%rdi), %edx
     e6e:      	cmpl	$0x11, %edx
     e71:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e73:      	cmpl	%esi, 0x18(%rdi)
     e76:      	ja	0xe7d <filter_16ty_range+0x17d>
     e78:      	cmpl	%esi, 0x1c(%rdi)
     e7b:      	jae	0xe07 <filter_16ty_range+0x107>
     e7d:      	cmpl	$0x19, %edx
     e80:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e82:      	cmpl	%esi, 0x20(%rdi)
     e85:      	ja	0xe90 <filter_16ty_range+0x190>
     e87:      	cmpl	%esi, 0x24(%rdi)
     e8a:      	jae	0xe07 <filter_16ty_range+0x107>
     e90:      	cmpl	$0x21, %edx
     e93:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e95:      	xorl	%edx, %edx
     e97:      	cmpl	%esi, 0x28(%rdi)
     e9a:      	ja	0xea9 <filter_16ty_range+0x1a9>
     e9c:      	cmpl	%esi, 0x2c(%rdi)
     e9f:      	jae	0xe07 <filter_16ty_range+0x107>
     ea5:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     ea7:      	xorl	%edx, %edx
     ea9:      	cmpl	$0x20, %ecx
     eac:      	sete	%al
     eaf:      	xorb	$0x1, %dl
     eb2:      	andb	%al, %dl
     eb4:      	movzbl	%dl, %eax
     eb7:      	retq
     eb8:      	nopl	(%rax,%rax)

0000000000000ec0 <filter_8ty_selector_val>:
     ec0:      	movl	0x4(%rdi), %ecx
     ec3:      	movl	$0x1, %eax
     ec8:      	cmpq	$0x25, %rcx
     ecc:      	ja	0xf3f <filter_8ty_selector_val+0x7f>
     ece:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     ed8:      	btq	%rcx, %rdx
     edc:      	jae	0xedf <filter_8ty_selector_val+0x1f>
     ede:      	retq
     edf:      	movl	$0x18, %edx
     ee4:      	btq	%rcx, %rdx
     ee8:      	jae	0xeff <filter_8ty_selector_val+0x3f>
     eea:      	movzbl	(%rsi), %edx
     eed:      	cmpl	%edx, 0x10(%rdi)
     ef0:      	jne	0x1015 <filter_8ty_selector_val+0x155>
     ef6:      	xorl	%eax, %eax
     ef8:      	cmpl	$0x3, %ecx
     efb:      	sete	%al
     efe:      	retq
     eff:      	cmpq	$0xc, %rcx
     f03:      	jne	0xf3f <filter_8ty_selector_val+0x7f>
     f05:      	movzbl	(%rsi), %ecx
     f08:      	testl	%ecx, 0x10(%rdi)
     f0b:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f0d:      	movl	0x8(%rdi), %edx
     f10:      	cmpl	$0xd, %edx
     f13:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f19:      	testl	%ecx, 0x14(%rdi)
     f1c:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f1e:      	cmpl	$0x11, %edx
     f21:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f27:      	testl	%ecx, 0x18(%rdi)
     f2a:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f2c:      	cmpl	$0x15, %edx
     f2f:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f35:      	testl	%ecx, 0x1c(%rdi)
     f38:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f3a:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     f3f:      	cmpl	$0x1, %ecx
     f42:      	je	0xfb1 <filter_8ty_selector_val+0xf1>
     f44:      	cmpl	$0x2, %ecx
     f47:      	jne	0x10d7 <filter_8ty_selector_val+0x217>
     f4d:      	movl	0xc(%rdi), %ecx
     f50:      	cmpl	$0xc, %ecx
     f53:      	ja	0x109e <filter_8ty_selector_val+0x1de>
     f59:      	movl	$0x1402, %edx           # imm = 0x1402
     f5e:      	btl	%ecx, %edx
     f61:      	jae	0x109e <filter_8ty_selector_val+0x1de>
     f67:      	movsbl	(%rsi), %ecx
     f6a:      	cmpl	%ecx, 0x10(%rdi)
     f6d:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f73:      	movl	0x8(%rdi), %edx
     f76:      	cmpl	$0xd, %edx
     f79:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f7f:      	cmpl	%ecx, 0x14(%rdi)
     f82:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f88:      	cmpl	$0x11, %edx
     f8b:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f91:      	cmpl	%ecx, 0x18(%rdi)
     f94:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f9a:      	cmpl	$0x15, %edx
     f9d:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fa3:      	cmpl	%ecx, 0x1c(%rdi)
     fa6:      	jg	0xede <filter_8ty_selector_val+0x1e>
     fac:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     fb1:      	movl	0xc(%rdi), %ecx
     fb4:      	cmpl	$0xc, %ecx
     fb7:      	ja	0x1063 <filter_8ty_selector_val+0x1a3>
     fbd:      	movl	$0x1402, %edx           # imm = 0x1402
     fc2:      	btl	%ecx, %edx
     fc5:      	jae	0x1063 <filter_8ty_selector_val+0x1a3>
     fcb:      	movsbl	(%rsi), %ecx
     fce:      	cmpl	%ecx, 0x10(%rdi)
     fd1:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fd7:      	movl	0x8(%rdi), %edx
     fda:      	cmpl	$0xd, %edx
     fdd:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fe3:      	cmpl	%ecx, 0x14(%rdi)
     fe6:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fec:      	cmpl	$0x11, %edx
     fef:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     ff5:      	cmpl	%ecx, 0x18(%rdi)
     ff8:      	jl	0xede <filter_8ty_selector_val+0x1e>
     ffe:      	cmpl	$0x15, %edx
    1001:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1007:      	cmpl	%ecx, 0x1c(%rdi)
    100a:      	jl	0xede <filter_8ty_selector_val+0x1e>
    1010:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1015:      	movl	0x8(%rdi), %esi
    1018:      	cmpl	$0xd, %esi
    101b:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    101d:      	cmpl	%edx, 0x14(%rdi)
    1020:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1026:      	cmpl	$0x11, %esi
    1029:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    102b:      	cmpl	%edx, 0x18(%rdi)
    102e:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1034:      	cmpl	$0x15, %esi
    1037:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    1039:      	cmpl	%edx, 0x1c(%rdi)
    103c:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1042:      	cmpl	$0x25, %ecx
    1045:      	ja	0x10d7 <filter_8ty_selector_val+0x217>
    104b:      	movl	%ecx, %ecx
    104d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1057:      	btq	%rcx, %rdx
    105b:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1061:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1063:      	movzbl	(%rsi), %ecx
    1066:      	cmpl	%ecx, 0x10(%rdi)
    1069:      	jb	0xede <filter_8ty_selector_val+0x1e>
    106f:      	movl	0x8(%rdi), %edx
    1072:      	cmpl	$0xd, %edx
    1075:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1077:      	cmpl	%ecx, 0x14(%rdi)
    107a:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1080:      	cmpl	$0x11, %edx
    1083:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1085:      	cmpl	%ecx, 0x18(%rdi)
    1088:      	jb	0xede <filter_8ty_selector_val+0x1e>
    108e:      	cmpl	$0x15, %edx
    1091:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1093:      	cmpl	%ecx, 0x1c(%rdi)
    1096:      	jb	0xede <filter_8ty_selector_val+0x1e>
    109c:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    109e:      	movzbl	(%rsi), %ecx
    10a1:      	cmpl	%ecx, 0x10(%rdi)
    10a4:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10aa:      	movl	0x8(%rdi), %edx
    10ad:      	cmpl	$0xd, %edx
    10b0:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10b2:      	cmpl	%ecx, 0x14(%rdi)
    10b5:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10bb:      	cmpl	$0x11, %edx
    10be:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10c0:      	cmpl	%ecx, 0x18(%rdi)
    10c3:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10c9:      	cmpl	$0x15, %edx
    10cc:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10ce:      	cmpl	%ecx, 0x1c(%rdi)
    10d1:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10d7:      	xorl	%eax, %eax
    10d9:      	retq
    10da:      	nopw	(%rax,%rax)

00000000000010e0 <filter_8ty_map>:
    10e0:      	pushq	%r14
    10e2:      	pushq	%rbx
    10e3:      	subq	$0x18, %rsp
    10e7:      	movq	%rsi, %r14
    10ea:      	movq	%rdi, %rbx
    10ed:      	movzbl	0x10(%rdi), %eax
    10f1:      	movl	%eax, 0xc(%rsp)
    10f5:      	movq	(%rip), %rdi            # 0x10fc <filter_8ty_map+0x1c>
    10fc:      	leaq	0xc(%rsp), %rsi
    1101:      	movl	$0x1, %eax
    1106:      	callq	*%rax
    1108:      	testq	%rax, %rax
    110b:      	je	0x1141 <filter_8ty_map+0x61>
    110d:      	movq	%rax, %rdi
    1110:      	movzbl	(%r14), %eax
    1114:      	movq	%rax, 0x10(%rsp)
    1119:      	leaq	0x10(%rsp), %rsi
    111e:      	movl	$0x1, %eax
    1123:      	callq	*%rax
    1125:      	movl	0x4(%rbx), %edx
    1128:      	xorl	%ecx, %ecx
    112a:      	cmpl	$0x1d, %edx
    112d:      	ja	0x115b <filter_8ty_map+0x7b>
    112f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1134:      	btl	%edx, %esi
    1137:      	jae	0x114b <filter_8ty_map+0x6b>
    1139:      	testq	%rax, %rax
    113c:      	setne	%cl
    113f:      	jmp	0x115b <filter_8ty_map+0x7b>
    1141:      	xorl	%eax, %eax
    1143:      	addq	$0x18, %rsp
    1147:      	popq	%rbx
    1148:      	popq	%r14
    114a:      	retq
    114b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1150:      	btl	%edx, %esi
    1153:      	jae	0x115b <filter_8ty_map+0x7b>
    1155:      	testq	%rax, %rax
    1158:      	sete	%cl
    115b:      	movzbl	%cl, %eax
    115e:      	addq	$0x18, %rsp
    1162:      	popq	%rbx
    1163:      	popq	%r14
    1165:      	retq
    1166:      	nopw	%cs:(%rax,%rax)

0000000000001170 <filter_8ty_range>:
    1170:      	movl	0x4(%rdi), %ecx
    1173:      	movl	0xc(%rdi), %eax
    1176:      	cmpl	$0xc, %eax
    1179:      	ja	0x1260 <filter_8ty_range+0xf0>
    117f:      	movl	$0x1402, %edx           # imm = 0x1402
    1184:      	btl	%eax, %edx
    1187:      	jae	0x1260 <filter_8ty_range+0xf0>
    118d:      	movsbl	(%rsi), %esi
    1190:      	cmpl	$0x1f, %ecx
    1193:      	jne	0x11fb <filter_8ty_range+0x8b>
    1195:      	movl	$0x1, %eax
    119a:      	cmpl	%esi, 0x10(%rdi)
    119d:      	jg	0x11a8 <filter_8ty_range+0x38>
    119f:      	cmpl	%esi, 0x14(%rdi)
    11a2:      	jge	0x1277 <filter_8ty_range+0x107>
    11a8:      	movl	0x8(%rdi), %edx
    11ab:      	cmpl	$0x11, %edx
    11ae:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11b4:      	cmpl	%esi, 0x18(%rdi)
    11b7:      	jg	0x11c2 <filter_8ty_range+0x52>
    11b9:      	cmpl	%esi, 0x1c(%rdi)
    11bc:      	jge	0x1277 <filter_8ty_range+0x107>
    11c2:      	cmpl	$0x19, %edx
    11c5:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11cb:      	cmpl	%esi, 0x20(%rdi)
    11ce:      	jg	0x11d9 <filter_8ty_range+0x69>
    11d0:      	cmpl	%esi, 0x24(%rdi)
    11d3:      	jge	0x1277 <filter_8ty_range+0x107>
    11d9:      	cmpl	$0x21, %edx
    11dc:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11e2:      	xorl	%edx, %edx
    11e4:      	cmpl	%esi, 0x28(%rdi)
    11e7:      	jg	0x1319 <filter_8ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x2c(%rdi)
    11f0:      	jge	0x1277 <filter_8ty_range+0x107>
    11f6:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    11fb:      	movl	0x8(%rdi), %eax
    11fe:      	cmpl	%esi, 0x10(%rdi)
    1201:      	setle	%r8b
    1205:      	cmpl	%esi, 0x14(%rdi)
    1208:      	setge	%dl
    120b:      	andb	%r8b, %dl
    120e:      	cmpl	$0x11, %eax
    1211:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1217:      	cmpl	%esi, 0x18(%rdi)
    121a:      	setle	%r8b
    121e:      	cmpl	%esi, 0x1c(%rdi)
    1221:      	setge	%r9b
    1225:      	andb	%r8b, %r9b
    1228:      	orb	%r9b, %dl
    122b:      	cmpl	$0x19, %eax
    122e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1234:      	cmpl	%esi, 0x20(%rdi)
    1237:      	setle	%r8b
    123b:      	cmpl	%esi, 0x24(%rdi)
    123e:      	setge	%r9b
    1242:      	andb	%r8b, %r9b
    1245:      	orb	%r9b, %dl
    1248:      	cmpl	$0x21, %eax
    124b:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1251:      	cmpl	%esi, 0x28(%rdi)
    1254:      	setle	%al
    1257:      	cmpl	%esi, 0x2c(%rdi)
    125a:      	setge	%sil
    125e:      	jmp	0x12d3 <filter_8ty_range+0x163>
    1260:      	movzbl	(%rsi), %esi
    1263:      	cmpl	$0x1f, %ecx
    1266:      	jne	0x1278 <filter_8ty_range+0x108>
    1268:      	movl	$0x1, %eax
    126d:      	cmpl	%esi, 0x10(%rdi)
    1270:      	ja	0x12db <filter_8ty_range+0x16b>
    1272:      	cmpl	%esi, 0x14(%rdi)
    1275:      	jb	0x12db <filter_8ty_range+0x16b>
    1277:      	retq
    1278:      	movl	0x8(%rdi), %eax
    127b:      	cmpl	%esi, 0x10(%rdi)
    127e:      	setbe	%r8b
    1282:      	cmpl	%esi, 0x14(%rdi)
    1285:      	setae	%dl
    1288:      	andb	%r8b, %dl
    128b:      	cmpl	$0x11, %eax
    128e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1294:      	cmpl	%esi, 0x18(%rdi)
    1297:      	setbe	%r8b
    129b:      	cmpl	%esi, 0x1c(%rdi)
    129e:      	setae	%r9b
    12a2:      	andb	%r8b, %r9b
    12a5:      	orb	%r9b, %dl
    12a8:      	cmpl	$0x19, %eax
    12ab:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12ad:      	cmpl	%esi, 0x20(%rdi)
    12b0:      	setbe	%r8b
    12b4:      	cmpl	%esi, 0x24(%rdi)
    12b7:      	setae	%r9b
    12bb:      	andb	%r8b, %r9b
    12be:      	orb	%r9b, %dl
    12c1:      	cmpl	$0x21, %eax
    12c4:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12c6:      	cmpl	%esi, 0x28(%rdi)
    12c9:      	setbe	%al
    12cc:      	cmpl	%esi, 0x2c(%rdi)
    12cf:      	setae	%sil
    12d3:      	andb	%al, %sil
    12d6:      	orb	%sil, %dl
    12d9:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    12db:      	movl	0x8(%rdi), %edx
    12de:      	cmpl	$0x11, %edx
    12e1:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12e3:      	cmpl	%esi, 0x18(%rdi)
    12e6:      	ja	0x12ed <filter_8ty_range+0x17d>
    12e8:      	cmpl	%esi, 0x1c(%rdi)
    12eb:      	jae	0x1277 <filter_8ty_range+0x107>
    12ed:      	cmpl	$0x19, %edx
    12f0:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12f2:      	cmpl	%esi, 0x20(%rdi)
    12f5:      	ja	0x1300 <filter_8ty_range+0x190>
    12f7:      	cmpl	%esi, 0x24(%rdi)
    12fa:      	jae	0x1277 <filter_8ty_range+0x107>
    1300:      	cmpl	$0x21, %edx
    1303:      	jb	0x1317 <filter_8ty_range+0x1a7>
    1305:      	xorl	%edx, %edx
    1307:      	cmpl	%esi, 0x28(%rdi)
    130a:      	ja	0x1319 <filter_8ty_range+0x1a9>
    130c:      	cmpl	%esi, 0x2c(%rdi)
    130f:      	jae	0x1277 <filter_8ty_range+0x107>
    1315:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    1317:      	xorl	%edx, %edx
    1319:      	cmpl	$0x20, %ecx
    131c:      	sete	%al
    131f:      	xorb	$0x1, %dl
    1322:      	andb	%al, %dl
    1324:      	movzbl	%dl, %eax
    1327:      	retq
    1328:      	nopl	(%rax,%rax)

0000000000001330 <filter_file_buf>:
    1330:      	pushq	%rbx
    1331:      	movq	%rdi, %rbx
    1334:      	movl	(%rsi), %edx
    1336:      	movl	0x4(%rdi), %ecx
    1339:      	testl	%edx, %edx
    133b:      	jne	0x134b <filter_file_buf+0x1b>
    133d:      	movl	%ecx, %eax
    133f:      	andl	$-0x2, %eax
    1342:      	cmpl	$0x24, %eax
    1345:      	je	0x134b <filter_file_buf+0x1b>
    1347:      	xorl	%eax, %eax
    1349:      	popq	%rbx
    134a:      	retq
    134b:      	cmpl	$0x25, %ecx
    134e:      	ja	0x138a <filter_file_buf+0x5a>
    1350:      	movl	%ecx, %eax
    1352:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1357:      	btq	%rax, %rdi
    135b:      	jb	0x13be <filter_file_buf+0x8e>
    135d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1362:      	btq	%rax, %rdi
    1366:      	jb	0x13a8 <filter_file_buf+0x78>
    1368:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1372:      	btq	%rax, %rdi
    1376:      	jae	0x138a <filter_file_buf+0x5a>
    1378:      	movq	%rbx, %rdi
    137b:      	callq	0x1e20 <filter_file_type>
    1380:      	movl	0x4(%rbx), %ecx
    1383:      	cmpl	$0x25, %ecx
    1386:      	jbe	0x13db <filter_file_buf+0xab>
    1388:      	jmp	0x13f1 <filter_file_buf+0xc1>
    138a:      	leal	-0x3(%rcx), %eax
    138d:      	cmpl	$0x2, %eax
    1390:      	jae	0x13d4 <filter_file_buf+0xa4>
    1392:      	addq	$0x4, %rsi
    1396:      	movq	%rbx, %rdi
    1399:      	callq	0x18b0 <filter_char_buf_equal>
    139e:      	movl	0x4(%rbx), %ecx
    13a1:      	cmpl	$0x25, %ecx
    13a4:      	jbe	0x13db <filter_file_buf+0xab>
    13a6:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13a8:      	addq	$0x4, %rsi
    13ac:      	movl	0x10(%rbx), %edi
    13af:      	callq	0x1cd0 <filter_char_buf_postfix>
    13b4:      	movl	0x4(%rbx), %ecx
    13b7:      	cmpl	$0x25, %ecx
    13ba:      	jbe	0x13db <filter_file_buf+0xab>
    13bc:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13be:      	addq	$0x4, %rsi
    13c2:      	movl	0x10(%rbx), %edi
    13c5:      	callq	0x1c30 <filter_char_buf_prefix>
    13ca:      	movl	0x4(%rbx), %ecx
    13cd:      	cmpl	$0x25, %ecx
    13d0:      	jbe	0x13db <filter_file_buf+0xab>
    13d2:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13d4:      	xorl	%eax, %eax
    13d6:      	cmpl	$0x25, %ecx
    13d9:      	ja	0x13f1 <filter_file_buf+0xc1>
    13db:      	movl	%ecx, %ecx
    13dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    13e7:      	btq	%rcx, %rdx
    13eb:      	jae	0x13f1 <filter_file_buf+0xc1>
    13ed:      	xorq	$0x1, %rax
    13f1:      	popq	%rbx
    13f2:      	retq
    13f3:      	nopw	%cs:(%rax,%rax)

0000000000001400 <filter_char_buf>:
    1400:      	pushq	%rbx
    1401:      	movq	%rsi, %rax
    1404:      	movq	%rdi, %rbx
    1407:      	movslq	%edx, %rcx
    140a:      	movl	-0x4(%rsi,%rcx), %edx
    140e:      	movl	%ecx, %esi
    1410:      	addq	%rax, %rsi
    1413:      	movl	0x4(%rdi), %ecx
    1416:      	xorl	%eax, %eax
    1418:      	cmpl	$0x19, %ecx
    141b:      	jg	0x1431 <filter_char_buf+0x31>
    141d:      	leal	-0x3(%rcx), %edi
    1420:      	cmpl	$0x2, %edi
    1423:      	jb	0x1468 <filter_char_buf+0x68>
    1425:      	cmpl	$0x8, %ecx
    1428:      	je	0x145e <filter_char_buf+0x5e>
    142a:      	cmpl	$0x9, %ecx
    142d:      	je	0x1440 <filter_char_buf+0x40>
    142f:      	jmp	0x147f <filter_char_buf+0x7f>
    1431:      	cmpl	$0x20, %ecx
    1434:      	jg	0x144a <filter_char_buf+0x4a>
    1436:      	cmpl	$0x1a, %ecx
    1439:      	je	0x145e <filter_char_buf+0x5e>
    143b:      	cmpl	$0x1b, %ecx
    143e:      	jne	0x147f <filter_char_buf+0x7f>
    1440:      	movl	0x10(%rbx), %edi
    1443:      	callq	0x1cd0 <filter_char_buf_postfix>
    1448:      	jmp	0x147c <filter_char_buf+0x7c>
    144a:      	cmpl	$0x21, %ecx
    144d:      	je	0x1472 <filter_char_buf+0x72>
    144f:      	cmpl	$0x22, %ecx
    1452:      	jne	0x147f <filter_char_buf+0x7f>
    1454:      	movq	%rbx, %rdi
    1457:      	movl	$0x1, %ecx
    145c:      	jmp	0x1477 <filter_char_buf+0x77>
    145e:      	movl	0x10(%rbx), %edi
    1461:      	callq	0x1c30 <filter_char_buf_prefix>
    1466:      	jmp	0x147c <filter_char_buf+0x7c>
    1468:      	movq	%rbx, %rdi
    146b:      	callq	0x18b0 <filter_char_buf_equal>
    1470:      	jmp	0x147c <filter_char_buf+0x7c>
    1472:      	movq	%rbx, %rdi
    1475:      	xorl	%ecx, %ecx
    1477:      	callq	0x1ed0 <filter_char_substring>
    147c:      	movl	0x4(%rbx), %ecx
    147f:      	cmpl	$0x25, %ecx
    1482:      	ja	0x14a1 <filter_char_buf+0xa1>
    1484:      	movl	%ecx, %ecx
    1486:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1490:      	btq	%rcx, %rdx
    1494:      	jae	0x14a1 <filter_char_buf+0xa1>
    1496:      	xorl	%ecx, %ecx
    1498:      	testq	%rax, %rax
    149b:      	sete	%cl
    149e:      	movq	%rcx, %rax
    14a1:      	popq	%rbx
    14a2:      	retq
    14a3:      	nopw	%cs:(%rax,%rax)

00000000000014b0 <filter_inet>:
    14b0:      	pushq	%r15
    14b2:      	pushq	%r14
    14b4:      	pushq	%r12
    14b6:      	pushq	%rbx
    14b7:      	subq	$0x48, %rsp
    14bb:      	movq	$0x0, 0x40(%rsp)
    14c4:      	movq	$0x0, 0x38(%rsp)
    14cd:      	movq	$0x0, 0x30(%rsp)
    14d6:      	movq	$0x0, 0x28(%rsp)
    14df:      	movq	$0x0, 0x20(%rsp)
    14e8:      	movl	$0x0, (%rsp)
    14ef:      	movl	$0x0, 0x4(%rsp)
    14f7:      	movl	0xc(%rdi), %edx
    14fa:      	xorl	%eax, %eax
    14fc:      	cmpl	$0x27, %edx
    14ff:      	jg	0x1517 <filter_inet+0x67>
    1501:      	cmpl	$0x5, %edx
    1504:      	je	0x159c <filter_inet+0xec>
    150a:      	movq	%rsi, %r8
    150d:      	cmpl	$0x7, %edx
    1510:      	je	0x1528 <filter_inet+0x78>
    1512:      	jmp	0x17ad <filter_inet+0x2fd>
    1517:      	cmpl	$0x28, %edx
    151a:      	je	0x1574 <filter_inet+0xc4>
    151c:      	movq	%rsi, %r8
    151f:      	cmpl	$0x29, %edx
    1522:      	jne	0x17ad <filter_inet+0x2fd>
    1528:      	movl	0x4(%rdi), %ecx
    152b:      	xorl	%eax, %eax
    152d:      	cmpl	$0x13, %ecx
    1530:      	jle	0x15a9 <filter_inet+0xf9>
    1532:      	cmpl	$0x17, %ecx
    1535:      	jg	0x1554 <filter_inet+0xa4>
    1537:      	leal	-0x14(%rcx), %edx
    153a:      	cmpl	$0x2, %edx
    153d:      	jb	0x15fa <filter_inet+0x14a>
    1543:      	leal	-0x16(%rcx), %edx
    1546:      	cmpl	$0x2, %edx
    1549:      	jb	0x15f4 <filter_inet+0x144>
    154f:      	jmp	0x17ad <filter_inet+0x2fd>
    1554:      	cmpl	$0x1b, %ecx
    1557:      	jg	0x1637 <filter_inet+0x187>
    155d:      	cmpl	$0x18, %ecx
    1560:      	je	0x166a <filter_inet+0x1ba>
    1566:      	cmpl	$0x19, %ecx
    1569:      	je	0x1660 <filter_inet+0x1b0>
    156f:      	jmp	0x17ad <filter_inet+0x2fd>
    1574:      	movzwl	(%rsi), %eax
    1577:      	movw	%ax, 0x46(%rsp)
    157c:      	movzwl	0x2(%rsi), %eax
    1580:      	movw	%ax, 0x40(%rsp)
    1585:      	movq	0x8(%rsi), %rax
    1589:      	movq	%rax, 0x20(%rsp)
    158e:      	movq	0x10(%rsi), %rax
    1592:      	movq	%rax, 0x28(%rsp)
    1597:      	leaq	0x20(%rsp), %rsi
    159c:      	xorl	%r8d, %r8d
    159f:      	movl	0x4(%rdi), %ecx
    15a2:      	xorl	%eax, %eax
    15a4:      	cmpl	$0x13, %ecx
    15a7:      	jg	0x1532 <filter_inet+0x82>
    15a9:      	cmpl	$0xf, %ecx
    15ac:      	jle	0x15ca <filter_inet+0x11a>
    15ae:      	cmpl	$0x11, %ecx
    15b1:      	jg	0x15e6 <filter_inet+0x136>
    15b3:      	cmpl	$0x10, %ecx
    15b6:      	je	0x15f4 <filter_inet+0x144>
    15b8:      	cmpl	$0x11, %ecx
    15bb:      	jne	0x17ad <filter_inet+0x2fd>
    15c1:      	movzwl	0x24(%rsi), %eax
    15c5:      	jmp	0x17a2 <filter_inet+0x2f2>
    15ca:      	cmpl	$0xd, %ecx
    15cd:      	je	0x166a <filter_inet+0x1ba>
    15d3:      	cmpl	$0xe, %ecx
    15d6:      	je	0x1660 <filter_inet+0x1b0>
    15dc:      	cmpl	$0xf, %ecx
    15df:      	je	0x15fa <filter_inet+0x14a>
    15e1:      	jmp	0x17ad <filter_inet+0x2fd>
    15e6:      	cmpl	$0x12, %ecx
    15e9:      	je	0x15fa <filter_inet+0x14a>
    15eb:      	cmpl	$0x13, %ecx
    15ee:      	jne	0x17ad <filter_inet+0x2fd>
    15f4:      	movzwl	0x22(%rsi), %edx
    15f8:      	jmp	0x15fe <filter_inet+0x14e>
    15fa:      	movzwl	0x20(%rsi), %edx
    15fe:      	movl	%edx, 0x4(%rsp)
    1602:      	xorl	%ebx, %ebx
    1604:      	xorl	%r15d, %r15d
    1607:      	xorl	%r14d, %r14d
    160a:      	xorl	%eax, %eax
    160c:      	cmpl	$0x11, %ecx
    160f:      	jg	0x1681 <filter_inet+0x1d1>
    1611:      	leal	-0xd(%rcx), %edx
    1614:      	cmpl	$0x2, %edx
    1617:      	jb	0x16a8 <filter_inet+0x1f8>
    161d:      	leal	-0xf(%rcx), %edx
    1620:      	cmpl	$0x2, %edx
    1623:      	jb	0x16fd <filter_inet+0x24d>
    1629:      	cmpl	$0x11, %ecx
    162c:      	je	0x17a5 <filter_inet+0x2f5>
    1632:      	jmp	0x17ad <filter_inet+0x2fd>
    1637:      	cmpl	$0x1c, %ecx
    163a:      	je	0x179e <filter_inet+0x2ee>
    1640:      	cmpl	$0x1d, %ecx
    1643:      	jne	0x17ad <filter_inet+0x2fd>
    1649:      	cmpl	$0x7, %edx
    164c:      	jne	0x17d1 <filter_inet+0x321>
    1652:      	testq	%r8, %r8
    1655:      	jne	0x17db <filter_inet+0x32b>
    165b:      	jmp	0x17a5 <filter_inet+0x2f5>
    1660:      	movq	0x10(%rsi), %rbx
    1664:      	movq	0x18(%rsi), %r14
    1668:      	jmp	0x1671 <filter_inet+0x1c1>
    166a:      	movq	(%rsi), %rbx
    166d:      	movq	0x8(%rsi), %r14
    1671:      	movq	%rbx, %r15
    1674:      	shrq	$0x20, %r15
    1678:      	xorl	%edx, %edx
    167a:      	xorl	%eax, %eax
    167c:      	cmpl	$0x11, %ecx
    167f:      	jle	0x1611 <filter_inet+0x161>
    1681:      	cmpl	$0x19, %ecx
    1684:      	ja	0x16f1 <filter_inet+0x241>
    1686:      	movl	$0x500000, %r8d         # imm = 0x500000
    168c:      	btl	%ecx, %r8d
    1690:      	jb	0x1707 <filter_inet+0x257>
    1692:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1698:      	btl	%ecx, %r8d
    169c:      	jb	0x1717 <filter_inet+0x267>
    169e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    16a3:      	btl	%ecx, %edx
    16a6:      	jae	0x16f1 <filter_inet+0x241>
    16a8:      	movzwl	0x26(%rsi), %eax
    16ac:      	cmpl	$0xa, %eax
    16af:      	je	0x1727 <filter_inet+0x277>
    16b1:      	cmpl	$0x2, %eax
    16b4:      	jne	0x1797 <filter_inet+0x2e7>
    16ba:      	movq	%rdi, %r12
    16bd:      	movl	0x10(%rdi), %eax
    16c0:      	movl	%eax, 0x8(%rsp)
    16c4:      	movq	(%rip), %rdi            # 0x16cb <filter_inet+0x21b>
    16cb:      	leaq	0x8(%rsp), %rsi
    16d0:      	movl	$0x1, %eax
    16d5:      	callq	*%rax
    16d7:      	testq	%rax, %rax
    16da:      	je	0x17b9 <filter_inet+0x309>
    16e0:      	movq	%rax, %rdi
    16e3:      	movl	$0x20, 0xc(%rsp)
    16eb:      	movl	%ebx, 0x10(%rsp)
    16ef:      	jmp	0x176b <filter_inet+0x2bb>
    16f1:      	addl	$-0x12, %ecx
    16f4:      	cmpl	$0x2, %ecx
    16f7:      	jae	0x17ad <filter_inet+0x2fd>
    16fd:      	leaq	0x4(%rsp), %rsi
    1702:      	jmp	0x17a8 <filter_inet+0x2f8>
    1707:      	xorl	%eax, %eax
    1709:      	cmpl	$0x400, %edx            # imm = 0x400
    170f:      	setb	%al
    1712:      	jmp	0x17ad <filter_inet+0x2fd>
    1717:      	xorl	%eax, %eax
    1719:      	cmpl	$0x400, %edx            # imm = 0x400
    171f:      	setae	%al
    1722:      	jmp	0x17ad <filter_inet+0x2fd>
    1727:      	movq	%rdi, %r12
    172a:      	movl	0x14(%rdi), %eax
    172d:      	movl	%eax, 0x8(%rsp)
    1731:      	movq	(%rip), %rdi            # 0x1738 <filter_inet+0x288>
    1738:      	leaq	0x8(%rsp), %rsi
    173d:      	movl	$0x1, %eax
    1742:      	callq	*%rax
    1744:      	testq	%rax, %rax
    1747:      	je	0x17b9 <filter_inet+0x309>
    1749:      	movq	%rax, %rdi
    174c:      	movl	$0x80, 0xc(%rsp)
    1754:      	movl	%ebx, 0x10(%rsp)
    1758:      	movl	%r15d, 0x14(%rsp)
    175d:      	movl	%r14d, 0x18(%rsp)
    1762:      	shrq	$0x20, %r14
    1766:      	movl	%r14d, 0x1c(%rsp)
    176b:      	leaq	0xc(%rsp), %rsi
    1770:      	movl	$0x1, %eax
    1775:      	callq	*%rax
    1777:      	movl	0x4(%r12), %ecx
    177c:      	leal	-0x18(%rcx), %edx
    177f:      	cmpl	$0x2, %edx
    1782:      	jb	0x17c6 <filter_inet+0x316>
    1784:      	addl	$-0xd, %ecx
    1787:      	cmpl	$0x1, %ecx
    178a:      	ja	0x1797 <filter_inet+0x2e7>
    178c:      	testq	%rax, %rax
    178f:      	setne	%al
    1792:      	movzbl	%al, %eax
    1795:      	jmp	0x17ad <filter_inet+0x2fd>
    1797:      	xorl	%eax, %eax
    1799:      	movzbl	%al, %eax
    179c:      	jmp	0x17ad <filter_inet+0x2fd>
    179e:      	movzwl	0x26(%rsi), %eax
    17a2:      	movl	%eax, (%rsp)
    17a5:      	movq	%rsp, %rsi
    17a8:      	callq	0x800 <filter_32ty_map>
    17ad:      	addq	$0x48, %rsp
    17b1:      	popq	%rbx
    17b2:      	popq	%r12
    17b4:      	popq	%r14
    17b6:      	popq	%r15
    17b8:      	retq
    17b9:      	movl	0x4(%r12), %eax
    17be:      	andl	$-0x2, %eax
    17c1:      	cmpl	$0x18, %eax
    17c4:      	jmp	0x17c9 <filter_inet+0x319>
    17c6:      	testq	%rax, %rax
    17c9:      	sete	%al
    17cc:      	movzbl	%al, %eax
    17cf:      	jmp	0x17ad <filter_inet+0x2fd>
    17d1:      	cmpl	$0x29, %edx
    17d4:      	jne	0x17e3 <filter_inet+0x333>
    17d6:      	testq	%r8, %r8
    17d9:      	je	0x17e3 <filter_inet+0x333>
    17db:      	movzbl	0x3a(%r8), %eax
    17e0:      	movl	%eax, (%rsp)
    17e3:      	cmpl	$0x29, %edx
    17e6:      	je	0x17a5 <filter_inet+0x2f5>
    17e8:      	cmpl	$0x7, %edx
    17eb:      	je	0x17a5 <filter_inet+0x2f5>
    17ed:      	xorl	%eax, %eax
    17ef:      	jmp	0x17ad <filter_inet+0x2fd>
    17f1:      	nopw	%cs:(%rax,%rax)

0000000000001800 <filter_sockaddr_un>:
    1800:      	pushq	%rbx
    1801:      	subq	$0x10, %rsp
    1805:      	movq	%rsi, %rcx
    1808:      	addq	$0x4, %rsi
    180c:      	movzbl	0x3(%rcx), %edx
    1810:      	movl	0x4(%rdi), %r8d
    1814:      	xorl	%eax, %eax
    1816:      	cmpl	$0x19, %r8d
    181a:      	jg	0x1850 <filter_sockaddr_un+0x50>
    181c:      	leal	-0x3(%r8), %ecx
    1820:      	cmpl	$0x2, %ecx
    1823:      	jae	0x185e <filter_sockaddr_un+0x5e>
    1825:      	movq	%rdi, %rbx
    1828:      	callq	0x18b0 <filter_char_buf_equal>
    182d:      	movl	0x4(%rbx), %ecx
    1830:      	cmpq	$0x25, %rcx
    1834:      	ja	0x184a <filter_sockaddr_un+0x4a>
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x184a <filter_sockaddr_un+0x4a>
    1846:      	xorq	$0x1, %rax
    184a:      	addq	$0x10, %rsp
    184e:      	popq	%rbx
    184f:      	retq
    1850:      	cmpl	$0x1c, %r8d
    1854:      	je	0x1894 <filter_sockaddr_un+0x94>
    1856:      	cmpl	$0x1a, %r8d
    185a:      	je	0x1864 <filter_sockaddr_un+0x64>
    185c:      	jmp	0x184a <filter_sockaddr_un+0x4a>
    185e:      	cmpl	$0x8, %r8d
    1862:      	jne	0x184a <filter_sockaddr_un+0x4a>
    1864:      	movl	0x10(%rdi), %eax
    1867:      	movq	%rdi, %rbx
    186a:      	movl	%eax, %edi
    186c:      	callq	0x1c30 <filter_char_buf_prefix>
    1871:      	movl	0x4(%rbx), %ecx
    1874:      	cmpq	$0x25, %rcx
    1878:      	ja	0x184a <filter_sockaddr_un+0x4a>
    187a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1884:      	btq	%rcx, %rdx
    1888:      	jae	0x184a <filter_sockaddr_un+0x4a>
    188a:      	xorq	$0x1, %rax
    188e:      	addq	$0x10, %rsp
    1892:      	popq	%rbx
    1893:      	retq
    1894:      	movzwl	(%rcx), %eax
    1897:      	movl	%eax, 0xc(%rsp)
    189b:      	leaq	0xc(%rsp), %rsi
    18a0:      	callq	0x800 <filter_32ty_map>
    18a5:      	addq	$0x10, %rsp
    18a9:      	popq	%rbx
    18aa:      	retq
    18ab:      	nopl	(%rax,%rax)

00000000000018b0 <filter_char_buf_equal>:
    18b0:      	pushq	%rbp
    18b1:      	pushq	%r15
    18b3:      	pushq	%r14
    18b5:      	pushq	%r13
    18b7:      	pushq	%r12
    18b9:      	pushq	%rbx
    18ba:      	subq	$0x28, %rsp
    18be:      	movl	$0x0, 0x14(%rsp)
    18c6:      	cmpl	$0x1000, %edx           # imm = 0x1000
    18cc:      	ja	0x1c1e <filter_char_buf_equal+0x36e>
    18d2:      	movl	%edx, %ebp
    18d4:      	movzwl	%bp, %eax
    18d7:      	cmpl	$0x90, %eax
    18dc:      	ja	0x1925 <filter_char_buf_equal+0x75>
    18de:      	testw	%bp, %bp
    18e1:      	je	0x18f4 <filter_char_buf_equal+0x44>
    18e3:      	movl	$0x18, %ecx
    18e8:      	movl	%ebp, %eax
    18ea:      	cltd
    18eb:      	idivl	%ecx
    18ed:      	movl	%ebp, %r14d
    18f0:      	testl	%edx, %edx
    18f2:      	je	0x1914 <filter_char_buf_equal+0x64>
    18f4:      	movl	$0x18, %ecx
    18f9:      	movl	%ebp, %eax
    18fb:      	cltd
    18fc:      	idivl	%ecx
    18fe:      	shll	$0x3, %eax
    1901:      	leal	(%rax,%rax,2), %eax
    1904:      	addl	$0x18, %eax
    1907:      	movzwl	%ax, %r14d
    190b:      	cmpl	$0x90, %r14d
    1912:      	ja	0x1963 <filter_char_buf_equal+0xb3>
    1914:      	movl	%r14d, %eax
    1917:      	cltd
    1918:      	idivl	%ecx
    191a:      	movl	%eax, %r15d
    191d:      	decl	%r15d
    1920:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1925:      	movl	$0x100, %r14d           # imm = 0x100
    192b:      	cmpl	$0x101, %eax            # imm = 0x101
    1930:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    1932:      	movl	$0x200, %r14d           # imm = 0x200
    1938:      	cmpl	$0x201, %eax            # imm = 0x201
    193d:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    193f:      	movl	$0x400, %r14d           # imm = 0x400
    1945:      	cmpl	$0x401, %eax            # imm = 0x401
    194a:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    194c:      	xorl	%r14d, %r14d
    194f:      	cmpl	$0x801, %eax            # imm = 0x801
    1954:      	setae	%r14b
    1958:      	shll	$0xb, %r14d
    195c:      	addl	$0x800, %r14d           # imm = 0x800
    1963:      	leal	-0x100(%r14), %eax
    196a:      	rorxl	$0x8, %eax, %eax
    1970:      	cmpl	$0x2, %eax
    1973:      	jg	0x1986 <filter_char_buf_equal+0xd6>
    1975:      	testl	%eax, %eax
    1977:      	je	0x19a0 <filter_char_buf_equal+0xf0>
    1979:      	cmpl	$0x1, %eax
    197c:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    197e:      	movl	$0x7, %r15d
    1984:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1986:      	cmpl	$0x3, %eax
    1989:      	je	0x19a8 <filter_char_buf_equal+0xf8>
    198b:      	cmpl	$0x7, %eax
    198e:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    1990:      	movl	$0x9, %r15d
    1996:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1998:      	movl	$0xa, %r15d
    199e:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a0:      	movl	$0x6, %r15d
    19a6:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a8:      	movl	$0x8, %r15d
    19ae:      	movl	%r15d, %eax
    19b1:      	andl	$0xf, %eax
    19b4:      	movl	0x10(%rdi,%rax,4), %r13d
    19b9:      	cmpl	$-0x1, %r13d
    19bd:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    19c3:      	movq	%rsi, 0x20(%rsp)
    19c8:      	movq	(%rip), %rdi            # 0x19cf <filter_char_buf_equal+0x11f>
    19cf:      	leaq	0x14(%rsp), %r12
    19d4:      	movl	$0x1, %eax
    19d9:      	movq	%r12, %rsi
    19dc:      	callq	*%rax
    19de:      	movq	%rax, %rbx
    19e1:      	movq	(%rip), %rdi            # 0x19e8 <filter_char_buf_equal+0x138>
    19e8:      	movl	$0x1, %eax
    19ed:      	movq	%r12, %rsi
    19f0:      	callq	*%rax
    19f2:      	movq	%rax, %rcx
    19f5:      	xorl	%eax, %eax
    19f7:      	movq	%rbx, 0x8(%rsp)
    19fc:      	testq	%rbx, %rbx
    19ff:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a05:      	testq	%rcx, %rcx
    1a08:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a0e:      	movq	%rcx, 0x18(%rsp)
    1a13:      	cmpl	$0x5, %r15d
    1a17:      	jg	0x1a5a <filter_char_buf_equal+0x1aa>
    1a19:      	movq	0x8(%rsp), %rax
    1a1e:      	movb	%bpl, (%rax)
    1a21:      	leaq	0x1(%rax), %rdi
    1a25:      	movl	%ebp, %r12d
    1a28:      	movl	$0x4, %eax
    1a2d:      	movq	0x20(%rsp), %rdx
    1a32:      	movl	%ebp, %esi
    1a34:      	callq	*%rax
    1a36:      	subl	%ebp, %r14d
    1a39:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a3b:      	movq	0x8(%rsp), %rax
    1a40:      	leaq	(%rax,%r12), %rdi
    1a44:      	incq	%rdi
    1a47:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a4e:      	movl	$0x4, %eax
    1a53:      	movq	0x18(%rsp), %rdx
    1a58:      	jmp	0x1a9a <filter_char_buf_equal+0x1ea>
    1a5a:      	movq	0x8(%rsp), %rax
    1a5f:      	movw	%bp, (%rax)
    1a62:      	leaq	0x2(%rax), %rdi
    1a66:      	movl	%ebp, %r12d
    1a69:      	movl	$0x4, %eax
    1a6e:      	movq	0x20(%rsp), %rdx
    1a73:      	movl	%ebp, %esi
    1a75:      	callq	*%rax
    1a77:      	subl	%ebp, %r14d
    1a7a:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a7c:      	movq	0x8(%rsp), %rax
    1a81:      	leaq	(%rax,%r12), %rdi
    1a85:      	addq	$0x2, %rdi
    1a89:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a90:      	movl	$0x4, %eax
    1a95:      	movq	0x18(%rsp), %rdx
    1a9a:      	movl	%r14d, %esi
    1a9d:      	callq	*%rax
    1a9f:      	movl	%r13d, 0x4(%rsp)
    1aa4:      	cmpl	$0x4, %r15d
    1aa8:      	jle	0x1ae4 <filter_char_buf_equal+0x234>
    1aaa:      	cmpl	$0x7, %r15d
    1aae:      	jg	0x1b1e <filter_char_buf_equal+0x26e>
    1ab0:      	cmpl	$0x5, %r15d
    1ab4:      	je	0x1bd2 <filter_char_buf_equal+0x322>
    1aba:      	cmpl	$0x6, %r15d
    1abe:      	je	0x1b99 <filter_char_buf_equal+0x2e9>
    1ac4:      	cmpl	$0x7, %r15d
    1ac8:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1ace:      	movq	(%rip), %rdi            # 0x1ad5 <filter_char_buf_equal+0x225>
    1ad5:      	leaq	0x4(%rsp), %rcx
    1ada:      	movl	$0x1, %eax
    1adf:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1ae4:      	cmpl	$0x1, %r15d
    1ae8:      	jle	0x1b4e <filter_char_buf_equal+0x29e>
    1aea:      	cmpl	$0x2, %r15d
    1aee:      	je	0x1bbf <filter_char_buf_equal+0x30f>
    1af4:      	cmpl	$0x3, %r15d
    1af8:      	je	0x1b86 <filter_char_buf_equal+0x2d6>
    1afe:      	cmpl	$0x4, %r15d
    1b02:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b08:      	movq	(%rip), %rdi            # 0x1b0f <filter_char_buf_equal+0x25f>
    1b0f:      	leaq	0x4(%rsp), %rcx
    1b14:      	movl	$0x1, %eax
    1b19:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b1e:      	cmpl	$0x8, %r15d
    1b22:      	je	0x1be5 <filter_char_buf_equal+0x335>
    1b28:      	cmpl	$0x9, %r15d
    1b2c:      	je	0x1bac <filter_char_buf_equal+0x2fc>
    1b2e:      	cmpl	$0xa, %r15d
    1b32:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b38:      	movq	(%rip), %rdi            # 0x1b3f <filter_char_buf_equal+0x28f>
    1b3f:      	leaq	0x4(%rsp), %rcx
    1b44:      	movl	$0x1, %eax
    1b49:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b4e:      	testl	%r15d, %r15d
    1b51:      	je	0x1b73 <filter_char_buf_equal+0x2c3>
    1b53:      	cmpl	$0x1, %r15d
    1b57:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b5d:      	movq	(%rip), %rdi            # 0x1b64 <filter_char_buf_equal+0x2b4>
    1b64:      	leaq	0x4(%rsp), %rcx
    1b69:      	movl	$0x1, %eax
    1b6e:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b73:      	movq	(%rip), %rdi            # 0x1b7a <filter_char_buf_equal+0x2ca>
    1b7a:      	leaq	0x4(%rsp), %rcx
    1b7f:      	movl	$0x1, %eax
    1b84:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b86:      	movq	(%rip), %rdi            # 0x1b8d <filter_char_buf_equal+0x2dd>
    1b8d:      	leaq	0x4(%rsp), %rcx
    1b92:      	movl	$0x1, %eax
    1b97:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b99:      	movq	(%rip), %rdi            # 0x1ba0 <filter_char_buf_equal+0x2f0>
    1ba0:      	leaq	0x4(%rsp), %rcx
    1ba5:      	movl	$0x1, %eax
    1baa:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bac:      	movq	(%rip), %rdi            # 0x1bb3 <filter_char_buf_equal+0x303>
    1bb3:      	leaq	0x4(%rsp), %rcx
    1bb8:      	movl	$0x1, %eax
    1bbd:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bbf:      	movq	(%rip), %rdi            # 0x1bc6 <filter_char_buf_equal+0x316>
    1bc6:      	leaq	0x4(%rsp), %rcx
    1bcb:      	movl	$0x1, %eax
    1bd0:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bd2:      	movq	(%rip), %rdi            # 0x1bd9 <filter_char_buf_equal+0x329>
    1bd9:      	leaq	0x4(%rsp), %rcx
    1bde:      	movl	$0x1, %eax
    1be3:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1be5:      	movq	(%rip), %rdi            # 0x1bec <filter_char_buf_equal+0x33c>
    1bec:      	leaq	0x4(%rsp), %rcx
    1bf1:      	movl	$0x1, %eax
    1bf6:      	leaq	0x4(%rsp), %rsi
    1bfb:      	callq	*%rax
    1bfd:      	testq	%rax, %rax
    1c00:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    1c02:      	movq	%rax, %rdi
    1c05:      	movl	$0x1, %eax
    1c0a:      	movq	0x8(%rsp), %rsi
    1c0f:      	callq	*%rax
    1c11:      	movq	%rax, %rcx
    1c14:      	xorl	%eax, %eax
    1c16:      	testq	%rcx, %rcx
    1c19:      	setne	%al
    1c1c:      	jmp	0x1c20 <filter_char_buf_equal+0x370>
    1c1e:      	xorl	%eax, %eax
    1c20:      	addq	$0x28, %rsp
    1c24:      	popq	%rbx
    1c25:      	popq	%r12
    1c27:      	popq	%r13
    1c29:      	popq	%r14
    1c2b:      	popq	%r15
    1c2d:      	popq	%rbp
    1c2e:      	retq
    1c2f:      	nop

0000000000001c30 <filter_char_buf_prefix>:
    1c30:      	pushq	%rbp
    1c31:      	pushq	%r15
    1c33:      	pushq	%r14
    1c35:      	pushq	%rbx
    1c36:      	pushq	%rax
    1c37:      	movl	%edx, %ebp
    1c39:      	movq	%rsi, %rbx
    1c3c:      	movl	%edi, 0x4(%rsp)
    1c40:      	movl	$0x0, (%rsp)
    1c47:      	movq	(%rip), %rdi            # 0x1c4e <filter_char_buf_prefix+0x1e>
    1c4e:      	leaq	0x4(%rsp), %rsi
    1c53:      	movl	$0x1, %eax
    1c58:      	callq	*%rax
    1c5a:      	movq	%rax, %r14
    1c5d:      	xorl	%eax, %eax
    1c5f:      	testl	%ebp, %ebp
    1c61:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c63:      	testq	%r14, %r14
    1c66:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c68:      	movq	(%rip), %rdi            # 0x1c6f <filter_char_buf_prefix+0x3f>
    1c6f:      	movq	%rsp, %rsi
    1c72:      	movl	$0x1, %eax
    1c77:      	callq	*%rax
    1c79:      	testq	%rax, %rax
    1c7c:      	je	0x1cc3 <filter_char_buf_prefix+0x93>
    1c7e:      	cmpl	$0xff, %ebp
    1c84:      	movl	$0xff, %esi
    1c89:      	cmovbl	%ebp, %esi
    1c8c:      	leal	(,%rsi,8), %ecx
    1c93:      	movl	%ecx, (%rax)
    1c95:      	movq	%rax, %rdi
    1c98:      	addq	$0x4, %rdi
    1c9c:      	movq	%rax, %r15
    1c9f:      	movl	$0x4, %eax
    1ca4:      	movq	%rbx, %rdx
    1ca7:      	callq	*%rax
    1ca9:      	movl	$0x1, %eax
    1cae:      	movq	%r14, %rdi
    1cb1:      	movq	%r15, %rsi
    1cb4:      	callq	*%rax
    1cb6:      	movq	%rax, %rcx
    1cb9:      	xorl	%eax, %eax
    1cbb:      	testq	%rcx, %rcx
    1cbe:      	setne	%al
    1cc1:      	jmp	0x1cc5 <filter_char_buf_prefix+0x95>
    1cc3:      	xorl	%eax, %eax
    1cc5:      	addq	$0x8, %rsp
    1cc9:      	popq	%rbx
    1cca:      	popq	%r14
    1ccc:      	popq	%r15
    1cce:      	popq	%rbp
    1ccf:      	retq

0000000000001cd0 <filter_char_buf_postfix>:
    1cd0:      	pushq	%r15
    1cd2:      	pushq	%r14
    1cd4:      	pushq	%rbx
    1cd5:      	subq	$0x10, %rsp
    1cd9:      	movl	%edx, %ebx
    1cdb:      	movq	%rsi, %r14
    1cde:      	movl	%edi, 0xc(%rsp)
    1ce2:      	movl	$0x0, 0x8(%rsp)
    1cea:      	movq	(%rip), %rdi            # 0x1cf1 <filter_char_buf_postfix+0x21>
    1cf1:      	leaq	0xc(%rsp), %rsi
    1cf6:      	movl	$0x1, %eax
    1cfb:      	callq	*%rax
    1cfd:      	movq	%rax, %r15
    1d00:      	xorl	%eax, %eax
    1d02:      	testl	%ebx, %ebx
    1d04:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d0a:      	testq	%r15, %r15
    1d0d:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d13:      	movq	(%rip), %rdi            # 0x1d1a <filter_char_buf_postfix+0x4a>
    1d1a:      	leaq	0x8(%rsp), %rsi
    1d1f:      	movl	$0x1, %eax
    1d24:      	callq	*%rax
    1d26:      	testq	%rax, %rax
    1d29:      	je	0x1e0e <filter_char_buf_postfix+0x13e>
    1d2f:      	movq	%rax, %rsi
    1d32:      	cmpl	$0x7f, %ebx
    1d35:      	movl	$0x7f, %eax
    1d3a:      	cmovbl	%ebx, %eax
    1d3d:      	shll	$0x3, %eax
    1d40:      	movl	%eax, (%rsi)
    1d42:      	movl	%ebx, %eax
    1d44:      	leal	-0x4(%rbx), %ecx
    1d47:      	movq	%rsi, %rdx
    1d4a:      	addq	$0x7, %rdx
    1d4e:      	leal	-0x3(%rbx), %edi
    1d51:      	leal	-0x2(%rbx), %r8d
    1d55:      	decl	%ebx
    1d57:      	movq	$-0x3, %r9
    1d5e:      	nop
    1d60:      	leal	(%rbx,%r9), %r10d
    1d64:      	addl	$0x3, %r10d
    1d68:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1d6f:      	movzbl	(%r14,%r10), %r10d
    1d74:      	movb	%r10b, -0x3(%rdx)
    1d78:      	leaq	(%rax,%r9), %r10
    1d7c:      	cmpq	$-0x2, %r10
    1d80:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1d82:      	leal	(%r8,%r9), %r11d
    1d86:      	addl	$0x3, %r11d
    1d8a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1d91:      	movzbl	(%r14,%r11), %r11d
    1d96:      	movb	%r11b, -0x2(%rdx)
    1d9a:      	cmpq	$-0x1, %r10
    1d9e:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1da0:      	leal	(%rdi,%r9), %r10d
    1da4:      	addl	$0x3, %r10d
    1da8:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1daf:      	movzbl	(%r14,%r10), %r10d
    1db4:      	movb	%r10b, -0x1(%rdx)
    1db8:      	movq	%rax, %r10
    1dbb:      	addq	%r9, %r10
    1dbe:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc0:      	cmpq	$-0x7f, %r9
    1dc4:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc6:      	leal	(%rcx,%r9), %r10d
    1dca:      	addl	$0x3, %r10d
    1dce:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1dd5:      	movzbl	(%r14,%r10), %r10d
    1dda:      	movb	%r10b, (%rdx)
    1ddd:      	addq	$0x4, %rdx
    1de1:      	leaq	(%rax,%r9), %r10
    1de5:      	addq	$-0x4, %r10
    1de9:      	addq	$-0x4, %r9
    1ded:      	cmpq	$-0x3, %r10
    1df1:      	jne	0x1d60 <filter_char_buf_postfix+0x90>
    1df7:      	movl	$0x1, %eax
    1dfc:      	movq	%r15, %rdi
    1dff:      	callq	*%rax
    1e01:      	movq	%rax, %rcx
    1e04:      	xorl	%eax, %eax
    1e06:      	testq	%rcx, %rcx
    1e09:      	setne	%al
    1e0c:      	jmp	0x1e10 <filter_char_buf_postfix+0x140>
    1e0e:      	xorl	%eax, %eax
    1e10:      	addq	$0x10, %rsp
    1e14:      	popq	%rbx
    1e15:      	popq	%r14
    1e17:      	popq	%r15
    1e19:      	retq
    1e1a:      	nopw	(%rax,%rax)

0000000000001e20 <filter_file_type>:
    1e20:      	pushq	%rbx
    1e21:      	subq	$0x10, %rsp
    1e25:      	movw	$0x0, 0xe(%rsp)
    1e2c:      	movl	(%rsi), %eax
    1e2e:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1e34:      	ja	0x1ebc <filter_file_type+0x9c>
    1e3a:      	movq	%rdi, %rbx
    1e3d:      	leaq	(%rsi,%rax), %rcx
    1e41:      	addq	$0x8, %rcx
    1e45:      	leaq	0xe(%rsp), %rdi
    1e4a:      	movl	$0x2, %edx
    1e4f:      	movl	$0x4, %eax
    1e54:      	movl	(%rsi), %ecx
    1e56:      	leaq	(%rsi,%rcx), %rdx
    1e5a:      	addq	$0x8, %rdx
    1e5e:      	movl	$0x2, %esi
    1e63:      	callq	*%rax
    1e65:      	movl	0x10(%rbx), %edx
    1e68:      	testl	%edx, %edx
    1e6a:      	je	0x1ebc <filter_file_type+0x9c>
    1e6c:      	movzwl	0xe(%rsp), %ecx
    1e71:      	andl	$0xf000, %ecx           # imm = 0xF000
    1e77:      	movl	$0x1, %eax
    1e7c:      	cmpl	%ecx, %edx
    1e7e:      	je	0x1ebe <filter_file_type+0x9e>
    1e80:      	movl	0x8(%rbx), %edx
    1e83:      	cmpl	$0xc, %edx
    1e86:      	jbe	0x1ebc <filter_file_type+0x9c>
    1e88:      	movl	0x14(%rbx), %esi
    1e8b:      	testl	%esi, %esi
    1e8d:      	je	0x1ebc <filter_file_type+0x9c>
    1e8f:      	cmpl	%ecx, %esi
    1e91:      	je	0x1ebe <filter_file_type+0x9e>
    1e93:      	cmpl	$0x11, %edx
    1e96:      	jb	0x1ebc <filter_file_type+0x9c>
    1e98:      	movl	0x18(%rbx), %esi
    1e9b:      	testl	%esi, %esi
    1e9d:      	je	0x1ebc <filter_file_type+0x9c>
    1e9f:      	cmpl	%ecx, %esi
    1ea1:      	je	0x1ebe <filter_file_type+0x9e>
    1ea3:      	cmpl	$0x15, %edx
    1ea6:      	jb	0x1ebc <filter_file_type+0x9c>
    1ea8:      	movl	0x1c(%rbx), %edx
    1eab:      	testl	%edx, %edx
    1ead:      	je	0x1ebc <filter_file_type+0x9c>
    1eaf:      	xorl	%eax, %eax
    1eb1:      	cmpl	%ecx, %edx
    1eb3:      	sete	%al
    1eb6:      	addq	$0x10, %rsp
    1eba:      	popq	%rbx
    1ebb:      	retq
    1ebc:      	xorl	%eax, %eax
    1ebe:      	addq	$0x10, %rsp
    1ec2:      	popq	%rbx
    1ec3:      	retq
    1ec4:      	nopw	%cs:(%rax,%rax)

0000000000001ed0 <filter_char_substring>:
    1ed0:      	pushq	%rbp
    1ed1:      	pushq	%r15
    1ed3:      	pushq	%r14
    1ed5:      	pushq	%r13
    1ed7:      	pushq	%r12
    1ed9:      	pushq	%rbx
    1eda:      	pushq	%rax
    1edb:      	movq	%rsi, %r15
    1ede:      	movq	%rdi, %r14
    1ee1:      	movl	%edx, %ebp
    1ee3:      	testl	%ecx, %ecx
    1ee5:      	je	0x1fbd <filter_char_substring+0xed>
    1eeb:      	testl	%edx, %edx
    1eed:      	je	0x206d <filter_char_substring+0x19d>
    1ef3:      	leaq	0x4(%rsp), %r13
    1ef8:      	xorl	%ebx, %ebx
    1efa:      	xorl	%r12d, %r12d
    1efd:      	nopl	(%rax)
    1f00:      	movl	0x10(%r14,%rbx,4), %eax
    1f05:      	movl	%eax, 0x4(%rsp)
    1f09:      	movl	$0x1, %eax
    1f0e:      	movq	(%rip), %rdi            # 0x1f15 <filter_char_substring+0x45>
    1f15:      	movq	%r13, %rsi
    1f18:      	callq	*%rax
    1f1a:      	testq	%rax, %rax
    1f1d:      	je	0x2100 <filter_char_substring+0x230>
    1f23:      	movq	%r15, %rdx
    1f26:      	xorl	%ecx, %ecx
    1f28:      	jmp	0x1f3b <filter_char_substring+0x6b>
    1f2a:      	nopw	(%rax,%rax)
    1f30:      	incq	%rcx
    1f33:      	incq	%rdx
    1f36:      	cmpq	%rbp, %rcx
    1f39:      	je	0x1f98 <filter_char_substring+0xc8>
    1f3b:      	xorl	%esi, %esi
    1f3d:      	nopl	(%rax)
    1f40:      	leaq	(%rcx,%rsi), %rdi
    1f44:      	cmpq	%rbp, %rdi
    1f47:      	jae	0x1f30 <filter_char_substring+0x60>
    1f49:      	movsbl	(%rax,%rsi), %edi
    1f4d:      	testl	%edi, %edi
    1f4f:      	je	0x1f90 <filter_char_substring+0xc0>
    1f51:      	movsbl	(%rdx,%rsi), %r9d
    1f56:      	leal	-0x41(%r9), %r10d
    1f5a:      	movl	%r9d, %r8d
    1f5d:      	orl	$0x20, %r8d
    1f61:      	cmpl	$0x1a, %r10d
    1f65:      	cmovael	%r9d, %r8d
    1f69:      	leal	-0x41(%rdi), %r10d
    1f6d:      	movl	%edi, %r9d
    1f70:      	orl	$0x20, %r9d
    1f74:      	cmpl	$0x1a, %r10d
    1f78:      	cmovael	%edi, %r9d
    1f7c:      	cmpq	$0x62, %rsi
    1f80:      	ja	0x1f30 <filter_char_substring+0x60>
    1f82:      	incq	%rsi
    1f85:      	cmpl	%r9d, %r8d
    1f88:      	je	0x1f40 <filter_char_substring+0x70>
    1f8a:      	jmp	0x1f30 <filter_char_substring+0x60>
    1f8c:      	nopl	(%rax)
    1f90:      	testl	%ecx, %ecx
    1f92:      	jns	0x2111 <filter_char_substring+0x241>
    1f98:      	leal	0xc(%r12), %eax
    1f9d:      	cmpl	0x8(%r14), %eax
    1fa1:      	jae	0x2100 <filter_char_substring+0x230>
    1fa7:      	addl	$0x4, %r12d
    1fab:      	incq	%rbx
    1fae:      	cmpq	$0x64, %rbx
    1fb2:      	jne	0x1f00 <filter_char_substring+0x30>
    1fb8:      	jmp	0x2100 <filter_char_substring+0x230>
    1fbd:      	testl	%edx, %edx
    1fbf:      	je	0x20b2 <filter_char_substring+0x1e2>
    1fc5:      	leaq	0x4(%rsp), %r13
    1fca:      	xorl	%ebx, %ebx
    1fcc:      	xorl	%r12d, %r12d
    1fcf:      	nop
    1fd0:      	movl	0x10(%r14,%rbx,4), %eax
    1fd5:      	movl	%eax, 0x4(%rsp)
    1fd9:      	movl	$0x1, %eax
    1fde:      	movq	(%rip), %rdi            # 0x1fe5 <filter_char_substring+0x115>
    1fe5:      	movq	%r13, %rsi
    1fe8:      	callq	*%rax
    1fea:      	testq	%rax, %rax
    1fed:      	je	0x2100 <filter_char_substring+0x230>
    1ff3:      	movq	%r15, %rdx
    1ff6:      	xorl	%ecx, %ecx
    1ff8:      	jmp	0x200b <filter_char_substring+0x13b>
    1ffa:      	nopw	(%rax,%rax)
    2000:      	incq	%rcx
    2003:      	incq	%rdx
    2006:      	cmpq	%rbp, %rcx
    2009:      	je	0x2048 <filter_char_substring+0x178>
    200b:      	xorl	%esi, %esi
    200d:      	nopl	(%rax)
    2010:      	leaq	(%rcx,%rsi), %rdi
    2014:      	cmpq	%rbp, %rdi
    2017:      	jae	0x2000 <filter_char_substring+0x130>
    2019:      	movzbl	(%rax,%rsi), %edi
    201d:      	testb	%dil, %dil
    2020:      	je	0x2040 <filter_char_substring+0x170>
    2022:      	cmpq	$0x62, %rsi
    2026:      	ja	0x2000 <filter_char_substring+0x130>
    2028:      	leaq	0x1(%rsi), %r8
    202c:      	cmpb	%dil, (%rdx,%rsi)
    2030:      	movq	%r8, %rsi
    2033:      	je	0x2010 <filter_char_substring+0x140>
    2035:      	jmp	0x2000 <filter_char_substring+0x130>
    2037:      	nopw	(%rax,%rax)
    2040:      	testl	%ecx, %ecx
    2042:      	jns	0x2111 <filter_char_substring+0x241>
    2048:      	leal	0xc(%r12), %eax
    204d:      	cmpl	0x8(%r14), %eax
    2051:      	jae	0x2100 <filter_char_substring+0x230>
    2057:      	addl	$0x4, %r12d
    205b:      	incq	%rbx
    205e:      	cmpq	$0x64, %rbx
    2062:      	jne	0x1fd0 <filter_char_substring+0x100>
    2068:      	jmp	0x2100 <filter_char_substring+0x230>
    206d:      	movl	$0x10, %ebx
    2072:      	movq	(%rip), %r15            # 0x2079 <filter_char_substring+0x1a9>
    2079:      	leaq	0x4(%rsp), %r12
    207e:      	nop
    2080:      	movl	(%r14,%rbx), %eax
    2084:      	movl	%eax, 0x4(%rsp)
    2088:      	movl	$0x1, %eax
    208d:      	movq	%r15, %rdi
    2090:      	movq	%r12, %rsi
    2093:      	callq	*%rax
    2095:      	testq	%rax, %rax
    2098:      	je	0x2100 <filter_char_substring+0x230>
    209a:      	addq	$0x4, %rbx
    209e:      	leal	-0x8(%rbx), %eax
    20a1:      	cmpl	0x8(%r14), %eax
    20a5:      	jae	0x2100 <filter_char_substring+0x230>
    20a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20ae:      	jne	0x2080 <filter_char_substring+0x1b0>
    20b0:      	jmp	0x2100 <filter_char_substring+0x230>
    20b2:      	movl	$0x10, %ebx
    20b7:      	movq	(%rip), %r15            # 0x20be <filter_char_substring+0x1ee>
    20be:      	leaq	0x4(%rsp), %r12
    20c3:      	nopw	%cs:(%rax,%rax)
    20d0:      	movl	(%r14,%rbx), %eax
    20d4:      	movl	%eax, 0x4(%rsp)
    20d8:      	movl	$0x1, %eax
    20dd:      	movq	%r15, %rdi
    20e0:      	movq	%r12, %rsi
    20e3:      	callq	*%rax
    20e5:      	testq	%rax, %rax
    20e8:      	je	0x2100 <filter_char_substring+0x230>
    20ea:      	addq	$0x4, %rbx
    20ee:      	leal	-0x8(%rbx), %eax
    20f1:      	cmpl	0x8(%r14), %eax
    20f5:      	jae	0x2100 <filter_char_substring+0x230>
    20f7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20fe:      	jne	0x20d0 <filter_char_substring+0x200>
    2100:      	xorl	%eax, %eax
    2102:      	addq	$0x8, %rsp
    2106:      	popq	%rbx
    2107:      	popq	%r12
    2109:      	popq	%r13
    210b:      	popq	%r14
    210d:      	popq	%r15
    210f:      	popq	%rbp
    2110:      	retq
    2111:      	movl	$0x1, %eax
    2116:      	jmp	0x2102 <filter_char_substring+0x232>
    2118:      	nopl	(%rax,%rax)

0000000000002120 <do_action>:
    2120:      	pushq	%rbp
    2121:      	pushq	%r15
    2123:      	pushq	%r14
    2125:      	pushq	%r13
    2127:      	pushq	%r12
    2129:      	pushq	%rbx
    212a:      	subq	$0x78, %rsp
    212e:      	movl	%r8d, %ebp
    2131:      	movq	%rcx, 0x38(%rsp)
    2136:      	movq	%rdx, %r15
    2139:      	movl	%esi, %ebx
    213b:      	movq	%rdi, %r14
    213e:      	movl	%esi, %eax
    2140:      	movslq	0x4(%rdx,%rax,4), %r12
    2145:      	movl	$0x0, 0x50(%rsp)
    214d:      	movq	(%rip), %rdi            # 0x2154 <do_action+0x34>
    2154:      	leaq	0x50(%rsp), %rsi
    2159:      	movl	$0x1, %eax
    215e:      	callq	*%rax
    2160:      	movq	%rax, %r13
    2163:      	xorl	%eax, %eax
    2165:      	testq	%r13, %r13
    2168:      	je	0x2980 <do_action+0x860>
    216e:      	cmpl	$0x7, %r12d
    2172:      	jg	0x219c <do_action+0x7c>
    2174:      	cmpl	$0x3, %r12d
    2178:      	jg	0x21d4 <do_action+0xb4>
    217a:      	cmpl	$0x1, %r12d
    217e:      	jg	0x2307 <do_action+0x1e7>
    2184:      	testl	%r12d, %r12d
    2187:      	je	0x25ac <do_action+0x48c>
    218d:      	cmpl	$0x1, %r12d
    2191:      	je	0x2320 <do_action+0x200>
    2197:      	jmp	0x2978 <do_action+0x858>
    219c:      	cmpl	$0xb, %r12d
    21a0:      	jg	0x22d9 <do_action+0x1b9>
    21a6:      	leal	-0xa(%r12), %ecx
    21ab:      	cmpl	$0x2, %ecx
    21ae:      	jb	0x242b <do_action+0x30b>
    21b4:      	cmpl	$0x8, %r12d
    21b8:      	je	0x2518 <do_action+0x3f8>
    21be:      	cmpl	$0x9, %r12d
    21c2:      	jne	0x2978 <do_action+0x858>
    21c8:      	incl	%ebx
    21ca:      	movl	0x4(%r15,%rbx,4), %eax
    21cf:      	jmp	0x24e4 <do_action+0x3c4>
    21d4:      	leal	-0x6(%r12), %eax
    21d9:      	cmpl	$0x2, %eax
    21dc:      	jb	0x2508 <do_action+0x3e8>
    21e2:      	cmpl	$0x4, %r12d
    21e6:      	je	0x2525 <do_action+0x405>
    21ec:      	cmpl	$0x5, %r12d
    21f0:      	jne	0x2978 <do_action+0x858>
    21f6:      	leal	0x1(%rbx), %eax
    21f9:      	movl	0x4(%r15,%rax,4), %eax
    21fe:      	addl	$0x2, %ebx
    2201:      	andl	$0x7, %eax
    2204:      	cmpl	$0x4, %eax
    2207:      	ja	0x2978 <do_action+0x858>
    220d:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    2216:      	jne	0x2978 <do_action+0x858>
    221c:      	movl	0x4(%r15,%rbx,4), %r14d
    2221:      	movq	0x5e78(%r13,%rax,8), %rax
    2229:      	movl	$0x0, 0xc(%rsp)
    2231:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2236:      	movl	0x90(%r13,%rax), %eax
    223e:      	movl	%eax, 0x8(%rsp)
    2242:      	movl	$0xe, %eax
    2247:      	callq	*%rax
    2249:      	shrq	$0x20, %rax
    224d:      	movq	%rax, (%rsp)
    2251:      	movq	(%rip), %rdi            # 0x2258 <do_action+0x138>
    2258:      	movq	%rsp, %rsi
    225b:      	movl	$0x1, %eax
    2260:      	callq	*%rax
    2262:      	testq	%rax, %rax
    2265:      	je	0x2978 <do_action+0x858>
    226b:      	andl	$0x7, %r14d
    226f:      	cmpl	$0x4, %r14d
    2273:      	ja	0x2978 <do_action+0x858>
    2279:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    2282:      	jne	0x2978 <do_action+0x858>
    2288:      	movq	0x5e78(%r13,%r14,8), %rcx
    2290:      	movl	$0x0, 0xc(%rsp)
    2298:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    229e:      	movl	0x90(%r13,%rcx), %ecx
    22a6:      	movl	%ecx, 0x8(%rsp)
    22aa:      	movq	%rax, %r15
    22ad:      	movl	$0xe, %eax
    22b2:      	callq	*%rax
    22b4:      	shrq	$0x20, %rax
    22b8:      	movq	%rax, (%rsp)
    22bc:      	movq	(%rip), %rdi            # 0x22c3 <do_action+0x1a3>
    22c3:      	xorl	%ecx, %ecx
    22c5:      	movq	%rsp, %rsi
    22c8:      	movl	$0x2, %eax
    22cd:      	movq	%r15, %rdx
    22d0:      	xorl	%ecx, %ecx
    22d2:      	callq	*%rax
    22d4:      	jmp	0x2978 <do_action+0x858>
    22d9:      	cmpl	$0xc, %r12d
    22dd:      	je	0x2668 <do_action+0x548>
    22e3:      	cmpl	$0xd, %r12d
    22e7:      	je	0x2534 <do_action+0x414>
    22ed:      	cmpl	$0xe, %r12d
    22f1:      	jne	0x2978 <do_action+0x858>
    22f7:      	addl	$0x2, %ebx
    22fa:      	movzbl	%bpl, %r14d
    22fe:      	xorq	$0x9, %r14
    2302:      	jmp	0x2673 <do_action+0x553>
    2307:      	movl	$0x9, %eax
    230c:      	cmpl	$0x2, %r12d
    2310:      	je	0x24e4 <do_action+0x3c4>
    2316:      	cmpl	$0x3, %r12d
    231a:      	jne	0x2978 <do_action+0x858>
    2320:      	leal	0x1(%rbx), %eax
    2323:      	movl	0x4(%r15,%rax,4), %ebp
    2328:      	addl	$0x2, %ebx
    232b:      	movl	0x4(%r15,%rbx,4), %r14d
    2330:      	movl	$0x0, 0x10(%rsp)
    2338:      	movq	(%rip), %rdi            # 0x233f <do_action+0x21f>
    233f:      	leaq	0x10(%rsp), %rsi
    2344:      	movl	$0x1, %eax
    2349:      	callq	*%rax
    234b:      	xorl	%r15d, %r15d
    234e:      	testq	%rax, %rax
    2351:      	je	0x272b <do_action+0x60b>
    2357:      	movq	%rax, 0x38(%rsp)
    235c:      	andl	$0x7, %ebp
    235f:      	cmpl	$0x4, %ebp
    2362:      	movl	$0x0, %eax
    2367:      	ja	0x272d <do_action+0x60d>
    236d:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2376:      	jne	0x272d <do_action+0x60d>
    237c:      	movq	0x5e78(%r13,%rbp,8), %rax
    2384:      	movl	$0x0, 0xc(%rsp)
    238c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2391:      	movl	0x90(%r13,%rax), %eax
    2399:      	movl	%eax, 0x8(%rsp)
    239d:      	movl	$0xe, %eax
    23a2:      	callq	*%rax
    23a4:      	shrq	$0x20, %rax
    23a8:      	movq	%rax, (%rsp)
    23ac:      	cmpl	$0x1, %r12d
    23b0:      	jne	0x2704 <do_action+0x5e4>
    23b6:      	andl	$0x7, %r14d
    23ba:      	cmpl	$0x4, %r14d
    23be:      	ja	0x272b <do_action+0x60b>
    23c4:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    23cd:      	movl	$0x0, %eax
    23d2:      	jne	0x272d <do_action+0x60d>
    23d8:      	movq	0x5e78(%r13,%r14,8), %rax
    23e0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    23e5:      	leaq	(%rax,%r13), %rdx
    23e9:      	addq	$0x90, %rdx
    23f0:      	movl	0x90(%r13,%rax), %esi
    23f8:      	andl	$0xfff, %esi            # imm = 0xFFF
    23fe:      	addq	$0x8, %rsi
    2402:      	movl	$0x4, %eax
    2407:      	movq	0x38(%rsp), %r14
    240c:      	movq	%r14, %rdi
    240f:      	callq	*%rax
    2411:      	movq	(%rip), %rdi            # 0x2418 <do_action+0x2f8>
    2418:      	xorl	%r15d, %r15d
    241b:      	movq	%rsp, %rsi
    241e:      	movl	$0x2, %eax
    2423:      	movq	%r14, %rdx
    2426:      	jmp	0x24db <do_action+0x3bb>
    242b:      	incl	%ebx
    242d:      	movl	0x4(%r15,%rbx,4), %ecx
    2432:      	andl	$0x7, %ecx
    2435:      	xorl	%r15d, %r15d
    2438:      	cmpl	$0x4, %ecx
    243b:      	ja	0x272d <do_action+0x60d>
    2441:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    244a:      	jne	0x272d <do_action+0x60d>
    2450:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2458:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    245e:      	movq	0xb8(%r13,%rcx), %rcx
    2466:      	movq	%rcx, 0x10(%rsp)
    246b:      	testq	%rcx, %rcx
    246e:      	je	0x272d <do_action+0x60d>
    2474:      	cmpl	$0xa, %r12d
    2478:      	jne	0x2715 <do_action+0x5f5>
    247e:      	movl	$0xe, %eax
    2483:      	callq	*%rax
    2485:      	movq	%rax, %r14
    2488:      	shrq	$0x20, %rax
    248c:      	movl	%eax, (%rsp)
    248f:      	movq	(%rip), %rdi            # 0x2496 <do_action+0x376>
    2496:      	movq	%rsp, %rsi
    2499:      	movl	$0x1, %eax
    249e:      	callq	*%rax
    24a0:      	movq	%rax, %rcx
    24a3:      	testq	%rax, %rax
    24a6:      	movl	$0x0, %eax
    24ab:      	je	0x272d <do_action+0x60d>
    24b1:      	movl	(%rcx), %eax
    24b3:      	movl	%eax, (%rsp)
    24b6:      	movl	%r14d, 0x4(%rsp)
    24bb:      	movq	0x8(%rcx), %rax
    24bf:      	movq	%rax, 0x8(%rsp)
    24c4:      	movq	(%rip), %rdi            # 0x24cb <do_action+0x3ab>
    24cb:      	xorl	%r15d, %r15d
    24ce:      	leaq	0x10(%rsp), %rsi
    24d3:      	movq	%rsp, %rdx
    24d6:      	movl	$0x2, %eax
    24db:      	xorl	%ecx, %ecx
    24dd:      	callq	*%rax
    24df:      	jmp	0x272b <do_action+0x60b>
    24e4:      	movl	$0x3, %r14d
    24ea:      	testb	%bpl, %bpl
    24ed:      	je	0x2673 <do_action+0x553>
    24f3:      	movslq	%eax, %rdi
    24f6:      	movl	$0x6d, %eax
    24fb:      	callq	*%rax
    24fd:      	movl	$0x2, %r14d
    2503:      	jmp	0x2673 <do_action+0x553>
    2508:      	incl	%ebx
    250a:      	movl	0x4(%r15,%rbx,4), %eax
    250f:      	movl	%eax, 0x78(%r13)
    2513:      	jmp	0x2978 <do_action+0x858>
    2518:      	movq	0x38(%rsp), %rax
    251d:      	movb	$0x0, (%rax)
    2520:      	jmp	0x2978 <do_action+0x858>
    2525:      	incl	%ebx
    2527:      	movzbl	%bpl, %r14d
    252b:      	xorq	$0x5, %r14
    252f:      	jmp	0x2673 <do_action+0x553>
    2534:      	movl	$0xe, %eax
    2539:      	callq	*%rax
    253b:      	movq	%rax, 0x20(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <do_action+0x427>
    2547:      	leaq	0x20(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2978 <do_action+0x858>
    255c:      	movq	0x4(%rax), %rax
    2560:      	movq	%rax, 0x10(%rsp)
    2565:      	movl	$0x2, 0x18(%rsp)
    256d:      	movq	(%rip), %rdi            # 0x2574 <do_action+0x454>
    2574:      	leaq	0x10(%rsp), %rsi
    2579:      	movl	$0x1, %eax
    257e:      	callq	*%rax
    2580:      	movl	$0x1, 0x2c(%rsp)
    2588:      	testq	%rax, %rax
    258b:      	je	0x269e <do_action+0x57e>
    2591:      	lock
    2592:      	incl	(%rax)
    2594:      	movq	(%rip), %rdi            # 0x259b <do_action+0x47b>
    259b:      	leaq	0x20(%rsp), %rsi
    25a0:      	movl	$0x3, %eax
    25a5:      	callq	*%rax
    25a7:      	jmp	0x2978 <do_action+0x858>
    25ac:      	leal	0x1(%rbx), %eax
    25af:      	movl	0x4(%r15,%rax,4), %ebp
    25b4:      	leal	0x2(%rbx), %eax
    25b7:      	movl	0x4(%r15,%rax,4), %eax
    25bc:      	movl	%eax, 0x30(%rsp)
    25c0:      	movl	$0x7d, %eax
    25c5:      	callq	*%rax
    25c7:      	movq	%rax, 0x68(%rsp)
    25cc:      	movq	%rax, (%rsp)
    25d0:      	movl	$0x0, 0x20(%rsp)
    25d8:      	movq	%rbp, 0x70(%rsp)
    25dd:      	testq	%rbp, %rbp
    25e0:      	je	0x290a <do_action+0x7ea>
    25e6:      	movq	(%rip), %rdi            # 0x25ed <do_action+0x4cd>
    25ed:      	leaq	0x20(%rsp), %rsi
    25f2:      	movl	$0x1, %eax
    25f7:      	callq	*%rax
    25f9:      	testq	%rax, %rax
    25fc:      	je	0x290a <do_action+0x7ea>
    2602:      	movq	%rax, 0x48(%rsp)
    2607:      	movq	%rax, %rbp
    260a:      	movq	(%rip), %rdi            # 0x2611 <do_action+0x4f1>
    2611:      	leaq	0x20(%rsp), %rsi
    2616:      	movl	$0x1, %eax
    261b:      	callq	*%rax
    261d:      	movq	%rax, %rdx
    2620:      	movq	0x60(%r13), %rax
    2624:      	movq	%rax, (%rbp)
    2628:      	movq	0x70(%r13), %rax
    262c:      	movq	%rbp, 0x40(%rsp)
    2631:      	movq	%rax, 0x8(%rbp)
    2635:      	xorl	%eax, %eax
    2637:      	movq	%rax, 0x60(%rsp)
    263c:      	movl	$0x0, %eax
    2641:      	movl	0x30(%rsp), %ecx
    2645:      	cmpl	$0x2, %ecx
    2648:      	je	0x273f <do_action+0x61f>
    264e:      	cmpl	$0x1, %ecx
    2651:      	je	0x273b <do_action+0x61b>
    2657:      	testl	%ecx, %ecx
    2659:      	jne	0x290a <do_action+0x7ea>
    265f:      	movl	0x7c(%r13), %eax
    2663:      	jmp	0x273f <do_action+0x61f>
    2668:      	addl	$0x3, %ebx
    266b:      	movzbl	%bpl, %r14d
    266f:      	xorq	$0x7, %r14
    2673:      	movl	$0x0, (%rsp)
    267a:      	movq	(%rip), %rdi            # 0x2681 <do_action+0x561>
    2681:      	movq	%rsp, %rsi
    2684:      	movl	$0x1, %eax
    2689:      	callq	*%rax
    268b:      	testq	%rax, %rax
    268e:      	je	0x2978 <do_action+0x858>
    2694:      	lock
    2695:      	incq	(%rax,%r14,8)
    2699:      	jmp	0x2978 <do_action+0x858>
    269e:      	movq	(%rip), %rdi            # 0x26a5 <do_action+0x585>
    26a5:      	leaq	0x10(%rsp), %rsi
    26aa:      	leaq	0x2c(%rsp), %rdx
    26af:      	movl	$0x1, %ecx
    26b4:      	movl	$0x2, %eax
    26b9:      	callq	*%rax
    26bb:      	testq	%rax, %rax
    26be:      	je	0x2594 <do_action+0x474>
    26c4:      	movq	%rax, %r15
    26c7:      	negl	%eax
    26c9:      	movw	%ax, (%rsp)
    26cd:      	movw	$0x3, 0x2(%rsp)
    26d4:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    26de:      	movq	%rax, 0x4(%rsp)
    26e3:      	movq	(%rip), %rdi            # 0x26ea <do_action+0x5ca>
    26ea:      	movq	%rsp, %rsi
    26ed:      	movl	$0x1, %eax
    26f2:      	callq	*%rax
    26f4:      	testq	%rax, %rax
    26f7:      	je	0x298f <do_action+0x86f>
    26fd:      	incl	(%rax)
    26ff:      	jmp	0x29b1 <do_action+0x891>
    2704:      	movq	(%rip), %rdi            # 0x270b <do_action+0x5eb>
    270b:      	movq	%rsp, %rsi
    270e:      	movl	$0x3, %eax
    2713:      	jmp	0x2726 <do_action+0x606>
    2715:      	movq	(%rip), %rdi            # 0x271c <do_action+0x5fc>
    271c:      	leaq	0x10(%rsp), %rsi
    2721:      	movl	$0x3, %eax
    2726:      	callq	*%rax
    2728:      	movq	%rax, %r15
    272b:      	xorl	%eax, %eax
    272d:      	testl	%r15d, %r15d
    2730:      	jne	0x2980 <do_action+0x860>
    2736:      	jmp	0x2978 <do_action+0x858>
    273b:      	movl	0x10(%r13), %eax
    273f:      	movq	%r14, 0x30(%rsp)
    2744:      	movl	%eax, %eax
    2746:      	movq	0x40(%rsp), %rcx
    274b:      	movq	%rax, 0x10(%rcx)
    274f:      	movq	0x48(%rsp), %rdi
    2754:      	addq	$0x18, %rdi
    2758:      	movl	$0xc8, %ecx
    275d:      	movl	$0x4, %eax
    2762:      	movq	%rdi, 0x48(%rsp)
    2767:      	movl	$0xc8, %esi
    276c:      	callq	*%rax
    276e:      	xorl	%r14d, %r14d
    2771:      	movq	%r13, 0x58(%rsp)
    2776:      	jmp	0x2786 <do_action+0x666>
    2778:      	addq	$0x4, %r14
    277c:      	cmpq	$0x14, %r14
    2780:      	je	0x28b3 <do_action+0x793>
    2786:      	movl	$0x0, 0x10(%rsp)
    278e:      	movl	$0x1, %eax
    2793:      	movq	(%rip), %rdi            # 0x279a <do_action+0x67a>
    279a:      	leaq	0x10(%rsp), %rsi
    279f:      	callq	*%rax
    27a1:      	testq	%rax, %rax
    27a4:      	je	0x28b3 <do_action+0x793>
    27aa:      	movq	%rax, %rsi
    27ad:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    27b4:      	movl	$0x1, %eax
    27b9:      	movq	(%rip), %rdi            # 0x27c0 <do_action+0x6a0>
    27c0:      	callq	*%rax
    27c2:      	testq	%rax, %rax
    27c5:      	je	0x28b3 <do_action+0x793>
    27cb:      	cmpl	$-0x1, 0x40(%rax,%r14)
    27d1:      	je	0x28b3 <do_action+0x793>
    27d7:      	movq	0x5e78(%r13,%r14,2), %rax
    27df:      	movl	0x4(%r13), %ecx
    27e3:      	cmpq	%rcx, %rax
    27e6:      	jge	0x28b3 <do_action+0x793>
    27ec:      	cmpq	$0x10, %r14
    27f0:      	je	0x2853 <do_action+0x733>
    27f2:      	movl	$0x0, 0x10(%rsp)
    27fa:      	movl	$0x1, %eax
    27ff:      	movq	(%rip), %rdi            # 0x2806 <do_action+0x6e6>
    2806:      	leaq	0x10(%rsp), %rsi
    280b:      	callq	*%rax
    280d:      	testq	%rax, %rax
    2810:      	je	0x284b <do_action+0x72b>
    2812:      	movq	%rax, %rsi
    2815:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    281c:      	movl	$0x1, %eax
    2821:      	movq	(%rip), %rdi            # 0x2828 <do_action+0x708>
    2828:      	callq	*%rax
    282a:      	testq	%rax, %rax
    282d:      	je	0x284b <do_action+0x72b>
    282f:      	cmpl	$-0x1, 0x44(%rax,%r14)
    2835:      	movq	0x5e78(%r13,%r14,2), %rax
    283d:      	je	0x2853 <do_action+0x733>
    283f:      	movl	0x5e80(%r13,%r14,2), %ebp
    2847:      	subl	%eax, %ebp
    2849:      	jmp	0x285c <do_action+0x73c>
    284b:      	movq	0x5e78(%r13,%r14,2), %rax
    2853:      	movl	0x4(%r13), %ebp
    2857:      	subl	%eax, %ebp
    2859:      	addl	$0x4, %ebp
    285c:      	testl	%ebp, %ebp
    285e:      	jle	0x2778 <do_action+0x658>
    2864:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2869:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    286e:      	cmpl	$0x28, %ebp
    2871:      	movl	$0x28, %ecx
    2876:      	cmovgel	%ecx, %ebp
    2879:      	movzbl	0x60(%rsp), %r13d
    287f:      	movq	0x48(%rsp), %rcx
    2884:      	leaq	(%rcx,%r13), %rdi
    2888:      	movq	0x58(%rsp), %rcx
    288d:      	leaq	(%rcx,%rax), %rdx
    2891:      	addq	$0x90, %rdx
    2898:      	movl	$0x4, %eax
    289d:      	movl	%ebp, %esi
    289f:      	callq	*%rax
    28a1:      	addl	%r13d, %ebp
    28a4:      	movq	0x58(%rsp), %r13
    28a9:      	movq	%rbp, 0x60(%rsp)
    28ae:      	jmp	0x2778 <do_action+0x658>
    28b3:      	movq	(%rip), %rdi            # 0x28ba <do_action+0x79a>
    28ba:      	movl	$0x1, %eax
    28bf:      	movq	0x40(%rsp), %rsi
    28c4:      	callq	*%rax
    28c6:      	testq	%rax, %rax
    28c9:      	je	0x28eb <do_action+0x7cb>
    28cb:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    28d4:      	movq	0x68(%rsp), %rdx
    28d9:      	addq	%rcx, %rdx
    28dc:      	cmpq	%rdx, (%rax)
    28df:      	jbe	0x28eb <do_action+0x7cb>
    28e1:      	movq	0x38(%rsp), %rax
    28e6:      	movb	$0x0, (%rax)
    28e9:      	jmp	0x2905 <do_action+0x7e5>
    28eb:      	movq	(%rip), %rdi            # 0x28f2 <do_action+0x7d2>
    28f2:      	xorl	%ecx, %ecx
    28f4:      	movq	%rsp, %rdx
    28f7:      	movl	$0x2, %eax
    28fc:      	movq	0x40(%rsp), %rsi
    2901:      	xorl	%ecx, %ecx
    2903:      	callq	*%rax
    2905:      	movq	0x30(%rsp), %r14
    290a:      	leal	0x3(%rbx), %eax
    290d:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2913:      	je	0x2936 <do_action+0x816>
    2915:      	orb	$0x2, 0x1(%r13)
    291a:      	movq	(%rip), %rsi            # 0x2921 <do_action+0x801>
    2921:      	xorl	%ecx, %ecx
    2923:      	movl	$0x1b, %eax
    2928:      	movq	%r14, %rdi
    292b:      	xorl	%edx, %edx
    292d:      	callq	*%rax
    292f:      	movq	%rax, 0x80(%r13)
    2936:      	leal	0x4(%rbx), %eax
    2939:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    293f:      	je	0x2968 <do_action+0x848>
    2941:      	orb	$0x4, 0x1(%r13)
    2946:      	movq	(%rip), %rsi            # 0x294d <do_action+0x82d>
    294d:      	movl	$0x100, %ecx            # imm = 0x100
    2952:      	movl	$0x1b, %eax
    2957:      	movl	$0x100, %edx            # imm = 0x100
    295c:      	movq	%r14, %rdi
    295f:      	callq	*%rax
    2961:      	movq	%rax, 0x88(%r13)
    2968:      	addl	$0x5, %ebx
    296b:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2971:      	je	0x2978 <do_action+0x858>
    2973:      	orb	$0x8, 0x1(%r13)
    2978:      	movq	%r12, 0x70(%r13)
    297c:      	incl	%ebx
    297e:      	movl	%ebx, %eax
    2980:      	addq	$0x78, %rsp
    2984:      	popq	%rbx
    2985:      	popq	%r12
    2987:      	popq	%r13
    2989:      	popq	%r14
    298b:      	popq	%r15
    298d:      	popq	%rbp
    298e:      	retq
    298f:      	movl	$0x1, 0x54(%rsp)
    2997:      	movq	(%rip), %rdi            # 0x299e <do_action+0x87e>
    299e:      	xorl	%ecx, %ecx
    29a0:      	movq	%rsp, %rsi
    29a3:      	leaq	0x54(%rsp), %rdx
    29a8:      	movl	$0x2, %eax
    29ad:      	xorl	%ecx, %ecx
    29af:      	callq	*%rax
    29b1:      	testl	%r15d, %r15d
    29b4:      	je	0x2594 <do_action+0x474>
    29ba:      	movq	(%rip), %rdi            # 0x29c1 <do_action+0x8a1>
    29c1:      	leaq	0x10(%rsp), %rsi
    29c6:      	movl	$0x1, %eax
    29cb:      	callq	*%rax
    29cd:      	testq	%rax, %rax
    29d0:      	je	0x2594 <do_action+0x474>
    29d6:      	movl	0x2c(%rsp), %ecx
    29da:      	lock
    29db:      	addl	%ecx, (%rax)
    29dd:      	jmp	0x2594 <do_action+0x474>

Disassembly of section kprobe.multi:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <generic_retkprobe_filter_arg+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x398 <generic_retkprobe_filter_arg+0x398>
      35:      	movq	%rax, %r14
      38:      	movl	0x5f00(%rax), %r12d
      3f:      	leaq	0x5ef8(%rax), %rsi
      46:      	movq	(%rip), %rdi            # 0x4d <generic_retkprobe_filter_arg+0x4d>
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x37d <generic_retkprobe_filter_arg+0x37d>
      5d:      	cmpb	$0x0, 0x5ee0(%r14)
      65:      	je	0x37d <generic_retkprobe_filter_arg+0x37d>
      6b:      	movq	%rax, %r15
      6e:      	movl	%r12d, %eax
      71:      	andl	$0x7, %eax
      74:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      7d:      	je	0xb7 <generic_retkprobe_filter_arg+0xb7>
      7f:      	movl	%eax, %eax
      81:      	movl	0x4(%r15,%rax,4), %ecx
      86:      	leaq	(%rcx,%rax,4), %r13
      8a:      	addq	$0x8, %r13
      8e:      	movq	%r13, %rax
      91:      	movq	%r13, 0x10(%rsp)
      96:      	andl	$0x3ff, %r13d           # imm = 0x3FF
      9d:      	cmpl	$0x19, (%r15,%r13)
      a2:      	jae	0x10c <generic_retkprobe_filter_arg+0x10c>
      a4:      	cmpq	$0x1, %r13
      a8:      	je	0x37d <generic_retkprobe_filter_arg+0x37d>
      ae:      	testl	%r13d, %r13d
      b1:      	jne	0x35b <generic_retkprobe_filter_arg+0x35b>
      b7:      	cmpl	$0x1, %r12d
      bb:      	jg	0xdc <generic_retkprobe_filter_arg+0xdc>
      bd:      	cmpl	$-0x1, %r12d
      c1:      	je	0x3a9 <generic_retkprobe_filter_arg+0x3a9>
      c7:      	testl	%r12d, %r12d
      ca:      	je	0x3b6 <generic_retkprobe_filter_arg+0x3b6>
      d0:      	cmpl	$0x1, %r12d
      d4:      	je	0x3c6 <generic_retkprobe_filter_arg+0x3c6>
      da:      	jmp	0xfa <generic_retkprobe_filter_arg+0xfa>
      dc:      	cmpl	$0x2, %r12d
      e0:      	je	0x3d6 <generic_retkprobe_filter_arg+0x3d6>
      e6:      	cmpl	$0x3, %r12d
      ea:      	je	0x3e6 <generic_retkprobe_filter_arg+0x3e6>
      f0:      	cmpl	$0x4, %r12d
      f4:      	je	0x3f6 <generic_retkprobe_filter_arg+0x3f6>
      fa:      	cmpl	$0x4, %r12d
      fe:      	jg	0x428 <generic_retkprobe_filter_arg+0x428>
     104:      	incl	%r12d
     107:      	jmp	0x406 <generic_retkprobe_filter_arg+0x406>
     10c:      	leaq	(%r15,%r13), %rax
     110:      	movq	%rax, 0x8(%rsp)
     115:      	movl	$0x1, %ebp
     11a:      	nopw	(%rax,%rax)
     120:      	movq	0x8(%rsp), %rax
     125:      	movl	(%rax,%rbp,4), %edi
     128:      	testl	$0x3ff, %edi            # imm = 0x3FF
     12e:      	je	0xa4 <generic_retkprobe_filter_arg+0xa4>
     134:      	addl	0x10(%rsp), %edi
     138:      	andl	$0x3ff, %edi            # imm = 0x3FF
     13e:      	movl	0x4(%r15,%rdi), %ecx
     143:      	cmpl	$0x23, %ecx
     146:      	je	0xb7 <generic_retkprobe_filter_arg+0xb7>
     14c:      	addq	%r15, %rdi
     14f:      	movl	(%rdi), %eax
     151:      	cmpq	$0x4, %rax
     155:      	ja	0xb7 <generic_retkprobe_filter_arg+0xb7>
     15b:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
     164:      	jne	0xb7 <generic_retkprobe_filter_arg+0xb7>
     16a:      	movq	0x5e78(%r14,%rax,8), %rax
     172:      	andl	$0x7ff, %eax            # imm = 0x7FF
     177:      	leaq	(%r14,%rax), %rsi
     17b:      	addq	$0x90, %rsi
     182:      	movl	0xc(%rdi), %eax
     185:      	cmpl	$0x1b, %eax
     188:      	jle	0x1a9 <generic_retkprobe_filter_arg+0x1a9>
     18a:      	cmpl	$0x25, %eax
     18d:      	jg	0x1d9 <generic_retkprobe_filter_arg+0x1d9>
     18f:      	leal	-0x1c(%rax), %edx
     192:      	cmpl	$0x9, %edx
     195:      	jb	0x21f <generic_retkprobe_filter_arg+0x21f>
     19b:      	cmpl	$0x25, %eax
     19e:      	je	0x302 <generic_retkprobe_filter_arg+0x302>
     1a4:      	jmp	0x349 <generic_retkprobe_filter_arg+0x349>
     1a9:      	cmpl	$0x9, %eax
     1ac:      	jle	0x1ff <generic_retkprobe_filter_arg+0x1ff>
     1ae:      	leal	-0xa(%rax), %edx
     1b1:      	cmpl	$0x4, %edx
     1b4:      	jb	0x21f <generic_retkprobe_filter_arg+0x21f>
     1b6:      	leal	-0xf(%rax), %ecx
     1b9:      	cmpl	$0x2, %ecx
     1bc:      	jb	0x302 <generic_retkprobe_filter_arg+0x302>
     1c2:      	cmpl	$0x11, %eax
     1c5:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     1cb:      	addq	$0x4, %rsi
     1cf:      	callq	0x1d4 <generic_retkprobe_filter_arg+0x1d4>
     1d4:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     1d9:      	cmpl	$0x29, %eax
     1dc:      	jg	0x2f1 <generic_retkprobe_filter_arg+0x2f1>
     1e2:      	leal	-0x26(%rax), %ecx
     1e5:      	cmpl	$0x2, %ecx
     1e8:      	jb	0x2ac <generic_retkprobe_filter_arg+0x2ac>
     1ee:      	addl	$-0x28, %eax
     1f1:      	cmpl	$0x2, %eax
     1f4:      	jb	0x2a2 <generic_retkprobe_filter_arg+0x2a2>
     1fa:      	jmp	0x349 <generic_retkprobe_filter_arg+0x349>
     1ff:      	cmpl	$0x4, %eax
     202:      	jg	0x28f <generic_retkprobe_filter_arg+0x28f>
     208:      	cmpl	$0x1, %eax
     20b:      	je	0x21f <generic_retkprobe_filter_arg+0x21f>
     20d:      	cmpl	$0x2, %eax
     210:      	je	0x31f <generic_retkprobe_filter_arg+0x31f>
     216:      	cmpl	$0x4, %eax
     219:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     21f:      	cmpl	$0xb, %eax
     222:      	jle	0x26c <generic_retkprobe_filter_arg+0x26c>
     224:      	cmpl	$0x24, %eax
     227:      	ja	0x309 <generic_retkprobe_filter_arg+0x309>
     22d:      	movl	%eax, %edx
     22f:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
     239:      	btq	%rdx, %r8
     23d:      	jb	0x2b3 <generic_retkprobe_filter_arg+0x2b3>
     23f:      	movl	$0x60000000, %ecx       # imm = 0x60000000
     244:      	btq	%rdx, %rcx
     248:      	jb	0x318 <generic_retkprobe_filter_arg+0x318>
     24e:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
     258:      	btq	%rdx, %rcx
     25c:      	jae	0x309 <generic_retkprobe_filter_arg+0x309>
     262:      	callq	0x267 <generic_retkprobe_filter_arg+0x267>
     267:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     26c:      	leal	-0xa(%rax), %ecx
     26f:      	cmpl	$0x2, %ecx
     272:      	jb	0x330 <generic_retkprobe_filter_arg+0x330>
     278:      	cmpl	$0x1, %eax
     27b:      	je	0x311 <generic_retkprobe_filter_arg+0x311>
     281:      	cmpl	$0x4, %eax
     284:      	je	0x311 <generic_retkprobe_filter_arg+0x311>
     28a:      	jmp	0x349 <generic_retkprobe_filter_arg+0x349>
     28f:      	cmpl	$0x5, %eax
     292:      	je	0x2a2 <generic_retkprobe_filter_arg+0x2a2>
     294:      	cmpl	$0x6, %eax
     297:      	je	0x2ac <generic_retkprobe_filter_arg+0x2ac>
     299:      	cmpl	$0x7, %eax
     29c:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     2a2:      	callq	0x2a7 <generic_retkprobe_filter_arg+0x2a7>
     2a7:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     2ac:      	movl	$0x4, %edx
     2b1:      	jmp	0x324 <generic_retkprobe_filter_arg+0x324>
     2b3:      	cmpl	$0x1e, %ecx
     2b6:      	jne	0x330 <generic_retkprobe_filter_arg+0x330>
     2b8:      	movl	0x10(%rdi), %eax
     2bb:      	andl	$0x7, %eax
     2be:      	movl	%eax, %ecx
     2c0:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2c9:      	jne	0xb7 <generic_retkprobe_filter_arg+0xb7>
     2cf:      	movq	(%rsi), %rcx
     2d2:      	movq	0x5e78(%r14,%rax,8), %rdx
     2da:      	andl	$0x7ff, %edx            # imm = 0x7FF
     2e0:      	xorl	%eax, %eax
     2e2:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
     2ec:      	setne	%al
     2ef:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     2f1:      	cmpl	$0x2a, %eax
     2f4:      	je	0x302 <generic_retkprobe_filter_arg+0x302>
     2f6:      	cmpl	$0x2c, %eax
     2f9:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     2fb:      	callq	0x300 <generic_retkprobe_filter_arg+0x300>
     300:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     302:      	callq	0x307 <generic_retkprobe_filter_arg+0x307>
     307:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     309:      	leal	-0xc(%rax), %ecx
     30c:      	cmpl	$0x2, %ecx
     30f:      	jae	0x32b <generic_retkprobe_filter_arg+0x32b>
     311:      	callq	0x316 <generic_retkprobe_filter_arg+0x316>
     316:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     318:      	callq	0x31d <generic_retkprobe_filter_arg+0x31d>
     31d:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     31f:      	movl	$0x8, %edx
     324:      	callq	0x329 <generic_retkprobe_filter_arg+0x329>
     329:      	jmp	0x340 <generic_retkprobe_filter_arg+0x340>
     32b:      	cmpl	$0x1c, %eax
     32e:      	jne	0x349 <generic_retkprobe_filter_arg+0x349>
     330:      	callq	0x335 <generic_retkprobe_filter_arg+0x335>
     335:      	nopw	%cs:(%rax,%rax)
     340:      	testq	%rax, %rax
     343:      	je	0xb7 <generic_retkprobe_filter_arg+0xb7>
     349:      	incq	%rbp
     34c:      	cmpq	$0x6, %rbp
     350:      	jne	0x120 <generic_retkprobe_filter_arg+0x120>
     356:      	jmp	0xa4 <generic_retkprobe_filter_arg+0xa4>
     35b:      	movl	%r13d, 0x5f04(%r14)
     362:      	movq	(%rip), %rsi            # 0x369 <generic_retkprobe_filter_arg+0x369>
     369:      	movl	$0x4, %ecx
     36e:      	movl	$0xc, %eax
     373:      	movq	%rbx, %rdi
     376:      	movl	$0x4, %edx
     37b:      	callq	*%rax
     37d:      	movq	(%rip), %rsi            # 0x384 <generic_retkprobe_filter_arg+0x384>
     384:      	movl	$0x5, %ecx
     389:      	movl	$0xc, %eax
     38e:      	movq	%rbx, %rdi
     391:      	movl	$0x5, %edx
     396:      	callq	*%rax
     398:      	xorl	%eax, %eax
     39a:      	addq	$0x28, %rsp
     39e:      	popq	%rbx
     39f:      	popq	%r12
     3a1:      	popq	%r13
     3a3:      	popq	%r14
     3a5:      	popq	%r15
     3a7:      	popq	%rbp
     3a8:      	retq
     3a9:      	xorl	%r12d, %r12d
     3ac:      	cmpb	$0x0, 0x5ec1(%r14)
     3b4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3b6:      	movl	$0x1, %r12d
     3bc:      	cmpb	$0x0, 0x5ec2(%r14)
     3c4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3c6:      	movl	$0x2, %r12d
     3cc:      	cmpb	$0x0, 0x5ec3(%r14)
     3d4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3d6:      	movl	$0x3, %r12d
     3dc:      	cmpb	$0x0, 0x5ec4(%r14)
     3e4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3e6:      	movl	$0x4, %r12d
     3ec:      	cmpb	$0x0, 0x5ec5(%r14)
     3f4:      	jne	0x406 <generic_retkprobe_filter_arg+0x406>
     3f6:      	movl	$0x5, %r12d
     3fc:      	cmpb	$0x0, 0x5ec6(%r14)
     404:      	je	0x428 <generic_retkprobe_filter_arg+0x428>
     406:      	movl	%r12d, 0x5f00(%r14)
     40d:      	movq	(%rip), %rsi            # 0x414 <generic_retkprobe_filter_arg+0x414>
     414:      	movl	$0x3, %ecx
     419:      	movl	$0xc, %eax
     41e:      	movq	%rbx, %rdi
     421:      	movl	$0x3, %edx
     426:      	callq	*%rax
     428:      	movq	0x60(%r14), %rbx
     42c:      	movl	$0xe, %eax
     431:      	callq	*%rax
     433:      	movq	%rbx, 0x18(%rsp)
     438:      	movq	%rax, 0x20(%rsp)
     43d:      	movq	(%rip), %rdi            # 0x444 <generic_retkprobe_filter_arg+0x444>
     444:      	leaq	0x18(%rsp), %rsi
     449:      	movl	$0x1, %eax
     44e:      	callq	*%rax
     450:      	testq	%rax, %rax
     453:      	je	0x398 <generic_retkprobe_filter_arg+0x398>
     459:      	movq	(%rip), %rdi            # 0x460 <generic_retkprobe_filter_arg+0x460>
     460:      	leaq	0x18(%rsp), %rsi
     465:      	movl	$0x3, %eax
     46a:      	callq	*%rax
     46c:      	jmp	0x398 <generic_retkprobe_filter_arg+0x398>
     471:      	nopw	%cs:(%rax,%rax)

0000000000000480 <generic_retkprobe_actions>:
     480:      	pushq	%rbp
     481:      	pushq	%r14
     483:      	pushq	%rbx
     484:      	subq	$0x10, %rsp
     488:      	movq	%rdi, %rbx
     48b:      	movl	$0x0, 0x8(%rsp)
     493:      	movq	(%rip), %rdi            # 0x49a <generic_retkprobe_actions+0x1a>
     49a:      	leaq	0x8(%rsp), %rsi
     49f:      	movl	$0x1, %eax
     4a4:      	callq	*%rax
     4a6:      	testq	%rax, %rax
     4a9:      	je	0x5b2 <generic_retkprobe_actions+0x132>
     4af:      	movq	%rax, %rsi
     4b2:      	movl	0x5f04(%rax), %r14d
     4b9:      	cmpl	$0x2, %r14d
     4bd:      	jl	0x5b2 <generic_retkprobe_actions+0x132>
     4c3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     4ca:      	movq	(%rip), %rdi            # 0x4d1 <generic_retkprobe_actions+0x51>
     4d1:      	movl	$0x1, %eax
     4d6:      	callq	*%rax
     4d8:      	testq	%rax, %rax
     4db:      	je	0x5b2 <generic_retkprobe_actions+0x132>
     4e1:      	movl	%r14d, %ecx
     4e4:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     4ea:      	addl	(%rax,%rcx), %r14d
     4ee:      	movb	$0x1, 0x7(%rsp)
     4f3:      	movl	$0x0, 0xc(%rsp)
     4fb:      	movq	(%rip), %rdi            # 0x502 <generic_retkprobe_actions+0x82>
     502:      	leaq	0xc(%rsp), %rsi
     507:      	movq	%rax, %rcx
     50a:      	movl	$0x1, %eax
     50f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
     516:      	addq	%rcx, %r14
     519:      	callq	*%rax
     51b:      	testq	%rax, %rax
     51e:      	je	0x52e <generic_retkprobe_actions+0xae>
     520:      	cmpb	$0x0, (%rax)
     523:      	sete	%al
     526:      	cmpl	$0x5, (%r14)
     52a:      	jae	0x536 <generic_retkprobe_actions+0xb6>
     52c:      	jmp	0x590 <generic_retkprobe_actions+0x110>
     52e:      	movb	$0x1, %al
     530:      	cmpl	$0x5, (%r14)
     534:      	jb	0x590 <generic_retkprobe_actions+0x110>
     536:      	movzbl	%al, %ebp
     539:      	leaq	0x7(%rsp), %rcx
     53e:      	movq	%rbx, %rdi
     541:      	xorl	%esi, %esi
     543:      	movq	%r14, %rdx
     546:      	movl	%ebp, %r8d
     549:      	callq	0x54e <generic_retkprobe_actions+0xce>
     54e:      	leal	0x4(,%rax,4), %ecx
     555:      	cmpl	(%r14), %ecx
     558:      	jae	0x590 <generic_retkprobe_actions+0x110>
     55a:      	leaq	0x7(%rsp), %rcx
     55f:      	movq	%rbx, %rdi
     562:      	movl	%eax, %esi
     564:      	movq	%r14, %rdx
     567:      	movl	%ebp, %r8d
     56a:      	callq	0x56f <generic_retkprobe_actions+0xef>
     56f:      	leal	0x4(,%rax,4), %ecx
     576:      	cmpl	(%r14), %ecx
     579:      	jae	0x590 <generic_retkprobe_actions+0x110>
     57b:      	leaq	0x7(%rsp), %rcx
     580:      	movq	%rbx, %rdi
     583:      	movl	%eax, %esi
     585:      	movq	%r14, %rdx
     588:      	movl	%ebp, %r8d
     58b:      	callq	0x590 <generic_retkprobe_actions+0x110>
     590:      	cmpb	$0x0, 0x7(%rsp)
     595:      	je	0x5b2 <generic_retkprobe_actions+0x132>
     597:      	movq	(%rip), %rsi            # 0x59e <generic_retkprobe_actions+0x11e>
     59e:      	movl	$0x5, %ecx
     5a3:      	movl	$0xc, %eax
     5a8:      	movq	%rbx, %rdi
     5ab:      	movl	$0x5, %edx
     5b0:      	callq	*%rax
     5b2:      	xorl	%eax, %eax
     5b4:      	addq	$0x10, %rsp
     5b8:      	popq	%rbx
     5b9:      	popq	%r14
     5bb:      	popq	%rbp
     5bc:      	retq
     5bd:      	nopl	(%rax)

00000000000005c0 <generic_retkprobe_output>:
     5c0:      	pushq	%r15
     5c2:      	pushq	%r14
     5c4:      	pushq	%rbx
     5c5:      	subq	$0x10, %rsp
     5c9:      	movq	%rdi, %r14
     5cc:      	movl	$0x0, 0x8(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <generic_retkprobe_output+0x1b>
     5db:      	leaq	0x8(%rsp), %rsi
     5e0:      	movl	$0x1, %eax
     5e5:      	callq	*%rax
     5e7:      	testq	%rax, %rax
     5ea:      	je	0x6c3 <generic_retkprobe_output+0x103>
     5f0:      	movq	%rax, %rbx
     5f3:      	movl	$0x90, %eax
     5f8:      	addl	0x4(%rbx), %eax
     5fb:      	andl	$0x7fff, %eax           # imm = 0x7FFF
     600:      	cmpl	$0x2328, %eax           # imm = 0x2328
     605:      	movl	$0x2328, %r15d          # imm = 0x2328
     60b:      	cmovbl	%eax, %r15d
     60f:      	movl	$0x0, 0xc(%rsp)
     617:      	movq	(%rip), %rdi            # 0x61e <generic_retkprobe_output+0x5e>
     61e:      	leaq	0xc(%rsp), %rsi
     623:      	movl	$0x1, %eax
     628:      	callq	*%rax
     62a:      	testq	%rax, %rax
     62d:      	je	0x681 <generic_retkprobe_output+0xc1>
     62f:      	cmpb	$0x0, 0x28(%rax)
     633:      	je	0x681 <generic_retkprobe_output+0xc1>
     635:      	movq	(%rip), %rsi            # 0x63c <generic_retkprobe_output+0x7c>
     63c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     641:      	movl	$0x19, %eax
     646:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     64b:      	movq	%r14, %rdi
     64e:      	movq	%rbx, %rcx
     651:      	movq	%r15, %r8
     654:      	callq	*%rax
     656:      	testq	%rax, %rax
     659:      	js	0x71e <generic_retkprobe_output+0x15e>
     65f:      	movl	$0x0, 0x4(%rsp)
     667:      	movq	(%rip), %rdi            # 0x66e <generic_retkprobe_output+0xae>
     66e:      	leaq	0x4(%rsp), %rsi
     673:      	movl	$0x1, %eax
     678:      	callq	*%rax
     67a:      	testq	%rax, %rax
     67d:      	jne	0x6be <generic_retkprobe_output+0xfe>
     67f:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     681:      	movq	(%rip), %rdi            # 0x688 <generic_retkprobe_output+0xc8>
     688:      	xorl	%ecx, %ecx
     68a:      	movl	$0x82, %eax
     68f:      	movq	%rbx, %rsi
     692:      	movq	%r15, %rdx
     695:      	xorl	%ecx, %ecx
     697:      	callq	*%rax
     699:      	testq	%rax, %rax
     69c:      	js	0x6cf <generic_retkprobe_output+0x10f>
     69e:      	movl	$0x0, 0x4(%rsp)
     6a6:      	movq	(%rip), %rdi            # 0x6ad <generic_retkprobe_output+0xed>
     6ad:      	leaq	0x4(%rsp), %rsi
     6b2:      	movl	$0x1, %eax
     6b7:      	callq	*%rax
     6b9:      	testq	%rax, %rax
     6bc:      	je	0x6c3 <generic_retkprobe_output+0x103>
     6be:      	lock
     6bf:      	incq	0x8(%rax)
     6c3:      	xorl	%eax, %eax
     6c5:      	addq	$0x10, %rsp
     6c9:      	popq	%rbx
     6ca:      	popq	%r14
     6cc:      	popq	%r15
     6ce:      	retq
     6cf:      	movq	%rax, %rbx
     6d2:      	movl	$0x0, 0x4(%rsp)
     6da:      	movq	(%rip), %rdi            # 0x6e1 <generic_retkprobe_output+0x121>
     6e1:      	leaq	0x4(%rsp), %rsi
     6e6:      	movl	$0x1, %eax
     6eb:      	callq	*%rax
     6ed:      	testq	%rax, %rax
     6f0:      	je	0x6c3 <generic_retkprobe_output+0x103>
     6f2:      	cmpq	$-0xc, %rbx
     6f6:      	jg	0x762 <generic_retkprobe_output+0x1a2>
     6f8:      	cmpq	$-0x1c, %rbx
     6fc:      	je	0x7a4 <generic_retkprobe_output+0x1e4>
     702:      	cmpq	$-0x16, %rbx
     706:      	je	0x753 <generic_retkprobe_output+0x193>
     708:      	cmpq	$-0x10, %rbx
     70c:      	jne	0x795 <generic_retkprobe_output+0x1d5>
     712:      	addq	$0x2f0, %rax            # imm = 0x2F0
     718:      	lock
     719:      	incq	(%rax)
     71c:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     71e:      	movq	%rax, %rbx
     721:      	movl	$0x0, 0x4(%rsp)
     729:      	movq	(%rip), %rdi            # 0x730 <generic_retkprobe_output+0x170>
     730:      	leaq	0x4(%rsp), %rsi
     735:      	movl	$0x1, %eax
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x6c3 <generic_retkprobe_output+0x103>
     741:      	cmpq	$-0xc, %rbx
     745:      	jg	0x783 <generic_retkprobe_output+0x1c3>
     747:      	cmpq	$-0x1c, %rbx
     74b:      	je	0x7a4 <generic_retkprobe_output+0x1e4>
     74d:      	cmpq	$-0x16, %rbx
     751:      	jne	0x708 <generic_retkprobe_output+0x148>
     753:      	addq	$0x2f8, %rax            # imm = 0x2F8
     759:      	lock
     75a:      	incq	(%rax)
     75d:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     762:      	cmpq	$-0xb, %rbx
     766:      	je	0x7b3 <generic_retkprobe_output+0x1f3>
     768:      	cmpq	$-0x7, %rbx
     76c:      	je	0x7c2 <generic_retkprobe_output+0x202>
     76e:      	cmpq	$-0x2, %rbx
     772:      	jne	0x795 <generic_retkprobe_output+0x1d5>
     774:      	addq	$0x2e0, %rax            # imm = 0x2E0
     77a:      	lock
     77b:      	incq	(%rax)
     77e:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     783:      	cmpq	$-0xb, %rbx
     787:      	je	0x7b3 <generic_retkprobe_output+0x1f3>
     789:      	cmpq	$-0x7, %rbx
     78d:      	je	0x7c2 <generic_retkprobe_output+0x202>
     78f:      	cmpq	$-0x2, %rbx
     793:      	je	0x774 <generic_retkprobe_output+0x1b4>
     795:      	addq	$0x2d8, %rax            # imm = 0x2D8
     79b:      	lock
     79c:      	incq	(%rax)
     79f:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     7a4:      	addq	$0x300, %rax            # imm = 0x300
     7aa:      	lock
     7ab:      	incq	(%rax)
     7ae:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     7b3:      	addq	$0x308, %rax            # imm = 0x308
     7b9:      	lock
     7ba:      	incq	(%rax)
     7bd:      	jmp	0x6c3 <generic_retkprobe_output+0x103>
     7c2:      	addq	$0x2e8, %rax            # imm = 0x2E8
     7c8:      	lock
     7c9:      	incq	(%rax)
     7cc:      	jmp	0x6c3 <generic_retkprobe_output+0x103>

Disassembly of section kprobe.multi/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movq	0x50(%rdi), %rax
      18:      	movq	%rax, 0xc0(%rsp)
      20:      	movl	$0x0, 0xe0(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <generic_retkprobe_event+0x32>
      32:      	leaq	0xe0(%rsp), %rsi
      3a:      	movl	$0x1, %eax
      3f:      	callq	*%rax
      41:      	xorl	%ebp, %ebp
      43:      	testq	%rax, %rax
      46:      	je	0x1df0 <generic_retkprobe_event+0x1df0>
      4c:      	movq	%rax, %r15
      4f:      	movq	%rax, %rbx
      52:      	movl	$0xae, %eax
      57:      	movq	%r12, %rdi
      5a:      	callq	*%rax
      5c:      	leaq	0x5ef8(%r15), %rsi
      63:      	movl	%eax, 0x5ef8(%r15)
      6a:      	movq	(%rip), %rdi            # 0x71 <generic_retkprobe_event+0x71>
      71:      	movl	$0x1, %eax
      76:      	callq	*%rax
      78:      	testq	%rax, %rax
      7b:      	je	0x1df0 <generic_retkprobe_event+0x1df0>
      81:      	movq	%rax, %r13
      84:      	movl	(%rax), %eax
      86:      	movq	%rax, 0x60(%rbx)
      8a:      	movl	$0xe, %eax
      8f:      	callq	*%rax
      91:      	cmpq	$-0x16, %rax
      95:      	jne	0xb7 <generic_retkprobe_event+0xb7>
      97:      	leaq	0x20(%r12), %rdx
      9c:      	leaq	0x30(%rsp), %rdi
      a1:      	movl	$0x8, %ecx
      a6:      	movl	$0x4, %eax
      ab:      	movl	$0x8, %esi
      b0:      	callq	*%rax
      b2:      	movq	0x30(%rsp), %rax
      b7:      	movq	%rax, 0x68(%rbx)
      bb:      	movl	$0xe, %eax
      c0:      	callq	*%rax
      c2:      	movl	%eax, 0x7c(%rbx)
      c5:      	movq	0x60(%rbx), %rax
      c9:      	movq	0x68(%rbx), %rcx
      cd:      	movq	%rax, 0x30(%rsp)
      d2:      	movq	%rcx, 0x38(%rsp)
      d7:      	movq	(%rip), %rdi            # 0xde <generic_retkprobe_event+0xde>
      de:      	leaq	0x30(%rsp), %rsi
      e3:      	movl	$0x1, %eax
      e8:      	callq	*%rax
      ea:      	testq	%rax, %rax
      ed:      	je	0x1df0 <generic_retkprobe_event+0x1df0>
      f3:      	movq	(%rax), %r14
      f6:      	movq	0x8(%rax), %rcx
      fa:      	movq	%rcx, 0x98(%rsp)
     102:      	movq	0x10(%rax), %rax
     106:      	movq	%rax, 0xa8(%rsp)
     10e:      	movq	(%rip), %rdi            # 0x115 <generic_retkprobe_event+0x115>
     115:      	leaq	0x30(%rsp), %rsi
     11a:      	movl	$0x3, %eax
     11f:      	callq	*%rax
     121:      	movq	%r14, 0x90(%rbx)
     128:      	movl	0x58(%r13), %eax
     12c:      	movl	0x5c(%r13), %r14d
     130:      	testl	%r14d, %r14d
     133:      	movq	%r13, 0x18(%rsp)
     138:      	je	0x1f7 <generic_retkprobe_event+0x1f7>
     13e:      	movl	%eax, 0x28(%rsp)
     142:      	movl	$0x0, 0x5ea0(%rbx)
     14c:      	movq	0xc0(%rsp), %rbp
     154:      	movl	$0x0, 0xe4(%rsp)
     15f:      	movq	(%rip), %rdi            # 0x166 <generic_retkprobe_event+0x166>
     166:      	leaq	0xe4(%rsp), %rsi
     16e:      	movl	$0x1, %eax
     173:      	callq	*%rax
     175:      	testq	%rax, %rax
     178:      	je	0x2e9 <generic_retkprobe_event+0x2e9>
     17e:      	movl	0x5ea0(%rax), %ecx
     184:      	movl	%ecx, 0x98(%rax)
     18a:      	movq	$0xc, 0x5e78(%rax)
     195:      	testl	%ecx, %ecx
     197:      	je	0x3b7 <generic_retkprobe_event+0x3b7>
     19d:      	movl	$0x4, %ebp
     1a2:      	addq	$0x8, %rbp
     1a6:      	movl	0x60(%r13), %eax
     1aa:      	cmpl	$0xb, %eax
     1ad:      	je	0x2fc <generic_retkprobe_event+0x2fc>
     1b3:      	cmpl	$0xa, %eax
     1b6:      	jne	0x312 <generic_retkprobe_event+0x312>
     1bc:      	movl	0x10(%rbx), %eax
     1bf:      	movl	%eax, 0x30(%rsp)
     1c3:      	movl	0x7c(%rbx), %eax
     1c6:      	movl	%eax, 0x34(%rsp)
     1ca:      	movq	0x18(%rbx), %rax
     1ce:      	movq	%rax, 0x38(%rsp)
     1d3:      	movq	(%rip), %rdi            # 0x1da <generic_retkprobe_event+0x1da>
     1da:      	xorl	%ecx, %ecx
     1dc:      	leaq	0xc0(%rsp), %rsi
     1e4:      	leaq	0x30(%rsp), %rdx
     1e9:      	movl	$0x2, %eax
     1ee:      	xorl	%ecx, %ecx
     1f0:      	callq	*%rax
     1f2:      	jmp	0x312 <generic_retkprobe_event+0x312>
     1f7:      	movl	$0x8, %ebp
     1fc:      	addq	$0x90, %r15
     203:      	cmpl	$0x3, %eax
     206:      	jne	0x32c <generic_retkprobe_event+0x32c>
     20c:      	movl	$0x0, (%r15,%rbp)
     214:      	leaq	0x4(%rbp), %r14
     218:      	cmpq	$0x0, 0xa8(%rsp)
     221:      	movq	%r12, 0xb8(%rsp)
     229:      	je	0x41e <generic_retkprobe_event+0x41e>
     22f:      	movq	%r14, 0x28(%rsp)
     234:      	movq	0xc0(%rsp), %r14
     23c:      	leaq	0x30(%rsp), %rdi
     241:      	movl	$0x4, %r12d
     247:      	movl	$0x10, %ecx
     24c:      	movl	$0x4, %eax
     251:      	movq	0x98(%rsp), %rdx
     259:      	movl	$0x10, %esi
     25e:      	callq	*%rax
     260:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     265:      	testl	%eax, %eax
     267:      	js	0x1b3b <generic_retkprobe_event+0x1b3b>
     26d:      	movq	0x38(%rsp), %rsi
     272:      	cmpq	%r14, %rsi
     275:      	movq	%r14, %rax
     278:      	movq	%r14, %r13
     27b:      	cmovbq	%rsi, %r13
     27f:      	testq	%r14, %r14
     282:      	cmovneq	%r13, %rsi
     286:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     28b:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     292:      	ja	0x1b3b <generic_retkprobe_event+0x1b3b>
     298:      	addq	$0xc, %rbp
     29c:      	movq	%rbp, 0x8(%rsp)
     2a1:      	leaq	(%r15,%rbp), %rdi
     2a5:      	movq	0x30(%rsp), %rcx
     2aa:      	movl	$0x4, %eax
     2af:      	movq	0x30(%rsp), %rdx
     2b4:      	movq	%rsi, %rbp
     2b7:      	callq	*%rax
     2b9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2be:      	testl	%eax, %eax
     2c0:      	js	0x1b3b <generic_retkprobe_event+0x1b3b>
     2c6:      	movq	%rbp, %rdx
     2c9:      	testq	%r14, %r14
     2cc:      	je	0xce9 <generic_retkprobe_event+0xce9>
     2d2:      	subq	%r13, %r14
     2d5:      	movq	%r14, (%rsp)
     2d9:      	movq	0x28(%rsp), %r14
     2de:      	jne	0xcf4 <generic_retkprobe_event+0xcf4>
     2e4:      	jmp	0x421 <generic_retkprobe_event+0x421>
     2e9:      	xorl	%ebp, %ebp
     2eb:      	addq	$0x8, %rbp
     2ef:      	movl	0x60(%r13), %eax
     2f3:      	cmpl	$0xb, %eax
     2f6:      	jne	0x1b3 <generic_retkprobe_event+0x1b3>
     2fc:      	movq	(%rip), %rdi            # 0x303 <generic_retkprobe_event+0x303>
     303:      	leaq	0xc0(%rsp), %rsi
     30b:      	movl	$0x3, %eax
     310:      	callq	*%rax
     312:      	andl	$0x1fff, %ebp           # imm = 0x1FFF
     318:      	movl	0x28(%rsp), %eax
     31c:      	addq	$0x90, %r15
     323:      	cmpl	$0x3, %eax
     326:      	je	0x20c <generic_retkprobe_event+0x20c>
     32c:      	cmpl	$0x2, %eax
     32f:      	jne	0x1b57 <generic_retkprobe_event+0x1b57>
     335:      	movq	%rbx, 0x8(%rsp)
     33a:      	movq	%r12, %rbx
     33d:      	movl	$0x0, (%r15,%rbp)
     345:      	movq	0xc0(%rsp), %r14
     34d:      	cmpq	$0xfff, %r14            # imm = 0xFFF
     354:      	movl	$0xfff, %r12d           # imm = 0xFFF
     35a:      	cmovbq	%r14, %r12
     35e:      	leaq	(%r15,%rbp), %rdi
     362:      	addq	$0xc, %rdi
     366:      	movl	$0x4, %eax
     36b:      	movq	0x98(%rsp), %rdx
     373:      	leaq	0x4(%rbp), %r13
     377:      	addq	%rbp, %r15
     37a:      	addq	$0x4, %r15
     37e:      	movl	$0x4, %ebp
     383:      	movl	%r12d, %esi
     386:      	callq	*%rax
     388:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     38d:      	testl	%eax, %eax
     38f:      	js	0x39f <generic_retkprobe_event+0x39f>
     391:      	movl	%r12d, 0x4(%r15)
     395:      	addq	$0x8, %r12
     399:      	movl	%r14d, %ecx
     39c:      	movq	%r12, %rbp
     39f:      	addq	%r13, %rbp
     3a2:      	movl	%ecx, (%r15)
     3a5:      	movq	%rbx, %r12
     3a8:      	movq	0x18(%rsp), %r13
     3ad:      	movq	0x8(%rsp), %rbx
     3b2:      	jmp	0x1b57 <generic_retkprobe_event+0x1b57>
     3b7:      	leaq	0x9c(%rax), %r13
     3be:      	movq	%rbp, 0x30(%rsp)
     3c3:      	movq	$0x0, 0x70(%rsp)
     3cc:      	cmpl	$0x17, %r14d
     3d0:      	movq	%rax, (%rsp)
     3d4:      	movq	%r15, 0x20(%rsp)
     3d9:      	movq	%r12, 0xb8(%rsp)
     3e1:      	jle	0x436 <generic_retkprobe_event+0x436>
     3e3:      	cmpl	$0x18, %r14d
     3e7:      	je	0x451 <generic_retkprobe_event+0x451>
     3e9:      	cmpl	$0x25, %r14d
     3ed:      	je	0x48f <generic_retkprobe_event+0x48f>
     3f3:      	cmpl	$0x2a, %r14d
     3f7:      	jne	0xb32 <generic_retkprobe_event+0xb32>
     3fd:      	movq	$0x0, 0x88(%rsp)
     409:      	movq	%rbp, 0x90(%rsp)
     411:      	leaq	0x88(%rsp), %rax
     419:      	jmp	0x4bc <generic_retkprobe_event+0x4bc>
     41e:      	xorl	%r13d, %r13d
     421:      	movl	%r13d, (%r15,%r14)
     425:      	movl	%r13d, 0x4(%r15,%r14)
     42a:      	addq	$0x8, %r13
     42e:      	movq	%r13, %r12
     431:      	jmp	0x1b44 <generic_retkprobe_event+0x1b44>
     436:      	cmpl	$0xf, %r14d
     43a:      	je	0xa6f <generic_retkprobe_event+0xa6f>
     440:      	cmpl	$0x10, %r14d
     444:      	jne	0xb32 <generic_retkprobe_event+0xb32>
     44a:      	leaq	0x10(%rsp), %r12
     44f:      	jmp	0x479 <generic_retkprobe_event+0x479>
     451:      	leaq	0x10(%rsp), %r12
     456:      	movl	$0x8, %ecx
     45b:      	movl	$0x4, %eax
     460:      	movq	0x30(%rsp), %rdx
     465:      	movq	%r12, %rdi
     468:      	movl	$0x8, %esi
     46d:      	callq	*%rax
     46f:      	movq	0x10(%rsp), %rax
     474:      	movq	%rax, 0x30(%rsp)
     479:      	leaq	0x30(%rsp), %rdx
     47e:      	movl	$0x8, %ecx
     483:      	movl	$0x4, %eax
     488:      	leaq	0x10(%rsp), %rdi
     48d:      	jmp	0x4ac <generic_retkprobe_event+0x4ac>
     48f:      	addq	$0x40, %rbp
     493:      	movq	%rbp, 0x30(%rsp)
     498:      	leaq	0x10(%rsp), %rdi
     49d:      	movl	$0x8, %ecx
     4a2:      	movl	$0x4, %eax
     4a7:      	movq	0x30(%rsp), %rdx
     4ac:      	movl	$0x8, %esi
     4b1:      	callq	*%rax
     4b3:      	movq	0x10(%rsp), %rax
     4b8:      	addq	$0x40, %rax
     4bc:      	movq	%rax, 0x80(%rsp)
     4c4:      	movl	$0x0, 0xb4(%rsp)
     4cf:      	movq	(%rip), %rdi            # 0x4d6 <generic_retkprobe_event+0x4d6>
     4d6:      	leaq	0xb4(%rsp), %rsi
     4de:      	movl	$0x1, %eax
     4e3:      	callq	*%rax
     4e5:      	testq	%rax, %rax
     4e8:      	je	0x59b <generic_retkprobe_event+0x59b>
     4ee:      	movq	%rax, %r12
     4f1:      	addq	$0x1000, %rax           # imm = 0x1000
     4f7:      	movq	%rax, 0x8(%rsp)
     4fc:      	movl	$0x23, %eax
     501:      	callq	*%rax
     503:      	leaq	0xd50(%rax), %rdx
     50a:      	leaq	0xc8(%rsp), %rdi
     512:      	movl	$0x8, %ecx
     517:      	movl	$0x4, %eax
     51c:      	movl	$0x8, %esi
     521:      	callq	*%rax
     523:      	movq	0xc8(%rsp), %rbp
     52b:      	movq	0x80(%rsp), %rax
     533:      	leaq	0x8(%rax), %rdx
     537:      	leaq	0xd0(%rsp), %rdi
     53f:      	movl	$0x8, %ecx
     544:      	movl	$0x4, %eax
     549:      	leaq	0x18(%rbp), %rcx
     54d:      	movq	%rcx, 0xf0(%rsp)
     555:      	movl	$0x8, %esi
     55a:      	movq	%rdx, 0xe8(%rsp)
     562:      	callq	*%rax
     564:      	movq	0xd0(%rsp), %r13
     56c:      	leaq	0x10(%r13), %rdx
     570:      	leaq	0x30(%rsp), %rdi
     575:      	movl	$0x8, %ecx
     57a:      	movl	$0x4, %eax
     57f:      	movl	$0x8, %esi
     584:      	callq	*%rax
     586:      	cmpq	$0x0, 0x30(%rsp)
     58c:      	movl	$0x1000, %r14d          # imm = 0x1000
     592:      	je	0x5a8 <generic_retkprobe_event+0x5a8>
     594:      	movq	0x8(%rsp), %rcx
     599:      	jmp	0x5fb <generic_retkprobe_event+0x5fb>
     59b:      	xorl	%r12d, %r12d
     59e:      	movq	0x18(%rsp), %r13
     5a3:      	jmp	0x1497 <generic_retkprobe_event+0x1497>
     5a8:      	leaq	0x18(%r13), %rdx
     5ac:      	leaq	0x30(%rsp), %rdi
     5b1:      	movl	$0x8, %ecx
     5b6:      	movl	$0x4, %eax
     5bb:      	movl	$0x8, %esi
     5c0:      	callq	*%rax
     5c2:      	cmpq	%r13, 0x30(%rsp)
     5c7:      	movq	0x8(%rsp), %rcx
     5cc:      	je	0x5fb <generic_retkprobe_event+0x5fb>
     5ce:      	movq	%r12, %rcx
     5d1:      	addq	$0xff6, %rcx            # imm = 0xFF6
     5d8:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     5e2:      	movq	%rax, 0xff6(%r12)
     5ea:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     5f5:      	movl	$0xff6, %r14d           # imm = 0xFF6
     5fb:      	movq	$0x0, 0x38(%rsp)
     604:      	movq	$0x0, 0x30(%rsp)
     60d:      	movq	%r12, 0x40(%rsp)
     612:      	movq	$0x0, 0x48(%rsp)
     61b:      	movq	$0x0, 0x50(%rsp)
     624:      	movq	$0x0, 0x58(%rsp)
     62d:      	movq	%rcx, 0x8(%rsp)
     632:      	movq	%rcx, 0x60(%rsp)
     637:      	movl	%r14d, 0x68(%rsp)
     63c:      	movb	$0x0, 0x6c(%rsp)
     641:      	addq	$0x20, %rbp
     645:      	leaq	0x30(%rsp), %rdi
     64a:      	movl	$0x8, %ecx
     64f:      	movl	$0x4, %eax
     654:      	leaq	0x38(%rsp), %r14
     659:      	leaq	0x48(%rsp), %r13
     65e:      	leaq	0x50(%rsp), %r12
     663:      	movl	$0x8, %esi
     668:      	movq	%rbp, %rdx
     66b:      	callq	*%rax
     66d:      	movl	$0x8, %ecx
     672:      	movl	$0x4, %eax
     677:      	movq	0xf0(%rsp), %rdx
     67f:      	movq	%r14, %rdi
     682:      	movl	$0x8, %esi
     687:      	callq	*%rax
     689:      	movl	$0x8, %ecx
     68e:      	movl	$0x4, %eax
     693:      	movq	0xe8(%rsp), %rdx
     69b:      	movq	%r13, %rdi
     69e:      	movl	$0x8, %esi
     6a3:      	callq	*%rax
     6a5:      	movl	$0x8, %ecx
     6aa:      	movl	$0x4, %eax
     6af:      	movq	0x80(%rsp), %rdx
     6b7:      	movq	%r12, %rdi
     6ba:      	movl	$0x8, %esi
     6bf:      	callq	*%rax
     6c1:      	movq	0x50(%rsp), %rax
     6c6:      	addq	$-0x20, %rax
     6ca:      	movq	%rax, 0x58(%rsp)
     6cf:      	movq	(%rip), %rax            # 0x6d6 <generic_retkprobe_event+0x6d6>
     6d6:      	cmpb	$0x0, (%rax)
     6d9:      	je	0x8ad <generic_retkprobe_event+0x8ad>
     6df:      	movl	$0x800, %ebp            # imm = 0x800
     6e4:      	movl	$0x8, %r14d
     6ea:      	movq	0x48(%rsp), %r13
     6ef:      	movq	0x50(%rsp), %rdx
     6f4:      	movq	0x58(%rsp), %r12
     6f9:      	cmpq	0x30(%rsp), %r13
     6fe:      	jne	0x70b <generic_retkprobe_event+0x70b>
     700:      	cmpq	0x38(%rsp), %rdx
     705:      	je	0xbda <generic_retkprobe_event+0xbda>
     70b:      	movl	$0x4, %eax
     710:      	leaq	0xa0(%rsp), %rdi
     718:      	movl	$0x8, %esi
     71d:      	callq	*%rax
     71f:      	cmpq	0xa0(%rsp), %r13
     727:      	movl	$0x8, %r15d
     72d:      	je	0x83f <generic_retkprobe_event+0x83f>
     733:      	leaq	0x18(%r13), %r14
     737:      	movl	$0x4, %eax
     73c:      	leaq	0x10(%rsp), %rdi
     741:      	movl	$0x8, %esi
     746:      	movq	%r14, %rdx
     749:      	callq	*%rax
     74b:      	cmpq	%r13, 0x10(%rsp)
     750:      	je	0x83f <generic_retkprobe_event+0x83f>
     756:      	movl	$0x4, %eax
     75b:      	leaq	0xd8(%rsp), %rdi
     763:      	movl	$0x8, %esi
     768:      	movq	%r14, %rdx
     76b:      	callq	*%rax
     76d:      	addq	$0x20, %r13
     771:      	movl	$0x4, %eax
     776:      	leaq	0x70(%rsp), %rdi
     77b:      	movl	$0x10, %ecx
     780:      	movl	$0x10, %esi
     785:      	movq	%r13, %rdx
     788:      	callq	*%rax
     78a:      	movq	0x40(%rsp), %r14
     78f:      	movq	0x60(%rsp), %rax
     794:      	movl	0x74(%rsp), %r12d
     799:      	subq	%r14, %rax
     79c:      	movl	0x68(%rsp), %r13d
     7a1:      	movl	%r12d, %edx
     7a4:      	subl	%r13d, %edx
     7a7:      	movl	$0x0, %ecx
     7ac:      	cmovbl	%ecx, %edx
     7af:      	addq	0x78(%rsp), %rdx
     7b4:      	xorl	%esi, %esi
     7b6:      	cmpl	%r12d, %r13d
     7b9:      	seta	%sil
     7bd:      	movl	%r12d, %ecx
     7c0:      	cmovbl	%r13d, %ecx
     7c4:      	addl	%ecx, %esi
     7c6:      	movl	%r13d, %edi
     7c9:      	subl	%esi, %edi
     7cb:      	movl	%edi, 0x68(%rsp)
     7cf:      	subq	%rsi, %rax
     7d2:      	movq	0x20(%rsp), %r15
     7d7:      	jb	0xbdf <generic_retkprobe_event+0xbdf>
     7dd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     7e3:      	ja	0xbdf <generic_retkprobe_event+0xbdf>
     7e9:      	cmpl	%r12d, %r13d
     7ec:      	jbe	0x7f3 <generic_retkprobe_event+0x7f3>
     7ee:      	movb	$0x2f, (%r14,%rax)
     7f3:      	xorl	%edi, %edi
     7f5:      	cmpl	%r12d, %r13d
     7f8:      	seta	%dil
     7fc:      	movzbl	%cl, %esi
     7ff:      	addq	%rax, %r14
     802:      	addq	%r14, %rdi
     805:      	movl	$0x4, %eax
     80a:      	callq	*%rax
     80c:      	movq	%r14, 0x60(%rsp)
     811:      	cmpl	%r12d, %r13d
     814:      	jbe	0xbdf <generic_retkprobe_event+0xbdf>
     81a:      	movq	0xd8(%rsp), %rax
     822:      	movq	%rax, 0x48(%rsp)
     827:      	movq	0x18(%rsp), %r13
     82c:      	movl	$0x8, %r14d
     832:      	decl	%ebp
     834:      	jne	0x6ea <generic_retkprobe_event+0x6ea>
     83a:      	jmp	0xbe4 <generic_retkprobe_event+0xbe4>
     83f:      	leaq	0x10(%r12), %rdx
     844:      	movl	$0x4, %eax
     849:      	leaq	0x10(%rsp), %rdi
     84e:      	movl	$0x8, %esi
     853:      	callq	*%rax
     855:      	movq	0x58(%rsp), %rax
     85a:      	cmpq	0x10(%rsp), %rax
     85f:      	movl	$0x8, %r14d
     865:      	je	0xdcd <generic_retkprobe_event+0xdcd>
     86b:      	addq	$0x18, %r12
     86f:      	movl	$0x4, %eax
     874:      	leaq	0x48(%rsp), %rdi
     879:      	movl	$0x8, %esi
     87e:      	movq	%r12, %rdx
     881:      	callq	*%rax
     883:      	movq	0x10(%rsp), %rax
     888:      	movq	%rax, 0x58(%rsp)
     88d:      	addq	$0x20, %rax
     891:      	movq	%rax, 0x50(%rsp)
     896:      	movq	0x18(%rsp), %r13
     89b:      	movq	0x20(%rsp), %r15
     8a0:      	decl	%ebp
     8a2:      	jne	0x6ea <generic_retkprobe_event+0x6ea>
     8a8:      	jmp	0xbe4 <generic_retkprobe_event+0xbe4>
     8ad:      	movl	$0x800, %ebp            # imm = 0x800
     8b2:      	movl	$0x8, %r14d
     8b8:      	jmp	0x8c2 <generic_retkprobe_event+0x8c2>
     8ba:      	decl	%ebp
     8bc:      	je	0xbe4 <generic_retkprobe_event+0xbe4>
     8c2:      	movq	0x48(%rsp), %r13
     8c7:      	movq	0x50(%rsp), %rdx
     8cc:      	movq	0x58(%rsp), %r12
     8d1:      	cmpq	0x30(%rsp), %r13
     8d6:      	jne	0x8e3 <generic_retkprobe_event+0x8e3>
     8d8:      	cmpq	0x38(%rsp), %rdx
     8dd:      	je	0xbda <generic_retkprobe_event+0xbda>
     8e3:      	movl	$0x4, %eax
     8e8:      	leaq	0xa0(%rsp), %rdi
     8f0:      	movl	$0x8, %esi
     8f5:      	callq	*%rax
     8f7:      	cmpq	0xa0(%rsp), %r13
     8ff:      	movl	$0x8, %ecx
     904:      	je	0xa0e <generic_retkprobe_event+0xa0e>
     90a:      	leaq	0x18(%r13), %r14
     90e:      	movl	$0x4, %eax
     913:      	leaq	0x10(%rsp), %rdi
     918:      	movl	$0x8, %esi
     91d:      	movq	%r14, %rdx
     920:      	callq	*%rax
     922:      	movl	$0x8, %ecx
     927:      	cmpq	%r13, 0x10(%rsp)
     92c:      	je	0xa0e <generic_retkprobe_event+0xa0e>
     932:      	movl	$0x4, %eax
     937:      	leaq	0xd8(%rsp), %rdi
     93f:      	movl	$0x8, %esi
     944:      	movq	%r14, %rdx
     947:      	callq	*%rax
     949:      	addq	$0x20, %r13
     94d:      	movl	$0x4, %eax
     952:      	leaq	0x70(%rsp), %rdi
     957:      	movl	$0x10, %ecx
     95c:      	movl	$0x10, %esi
     961:      	movq	%r13, %rdx
     964:      	callq	*%rax
     966:      	movq	0x40(%rsp), %r14
     96b:      	movq	0x60(%rsp), %rax
     970:      	movl	0x74(%rsp), %r12d
     975:      	subq	%r14, %rax
     978:      	movl	0x68(%rsp), %r13d
     97d:      	movl	%r12d, %edx
     980:      	subl	%r13d, %edx
     983:      	movl	$0x0, %ecx
     988:      	cmovbl	%ecx, %edx
     98b:      	addq	0x78(%rsp), %rdx
     990:      	xorl	%esi, %esi
     992:      	cmpl	%r12d, %r13d
     995:      	seta	%sil
     999:      	movl	%r12d, %ecx
     99c:      	cmovbl	%r13d, %ecx
     9a0:      	addl	%ecx, %esi
     9a2:      	movl	%r13d, %edi
     9a5:      	subl	%esi, %edi
     9a7:      	movl	%edi, 0x68(%rsp)
     9ab:      	subq	%rsi, %rax
     9ae:      	jb	0xbdf <generic_retkprobe_event+0xbdf>
     9b4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     9ba:      	ja	0xbdf <generic_retkprobe_event+0xbdf>
     9c0:      	cmpl	%r12d, %r13d
     9c3:      	jbe	0x9ca <generic_retkprobe_event+0x9ca>
     9c5:      	movb	$0x2f, (%r14,%rax)
     9ca:      	xorl	%edi, %edi
     9cc:      	cmpl	%r12d, %r13d
     9cf:      	seta	%dil
     9d3:      	movzbl	%cl, %esi
     9d6:      	addq	%rax, %r14
     9d9:      	addq	%r14, %rdi
     9dc:      	movl	$0x4, %eax
     9e1:      	callq	*%rax
     9e3:      	movq	%r14, 0x60(%rsp)
     9e8:      	cmpl	%r12d, %r13d
     9eb:      	jbe	0xbdf <generic_retkprobe_event+0xbdf>
     9f1:      	movq	0xd8(%rsp), %rax
     9f9:      	movq	%rax, 0x48(%rsp)
     9fe:      	movq	0x18(%rsp), %r13
     a03:      	movl	$0x8, %r14d
     a09:      	jmp	0x8ba <generic_retkprobe_event+0x8ba>
     a0e:      	leaq	0x10(%r12), %rdx
     a13:      	movl	$0x4, %eax
     a18:      	leaq	0x10(%rsp), %rdi
     a1d:      	movl	$0x8, %esi
     a22:      	callq	*%rax
     a24:      	movq	0x58(%rsp), %rax
     a29:      	cmpq	0x10(%rsp), %rax
     a2e:      	movl	$0x8, %r14d
     a34:      	je	0xbda <generic_retkprobe_event+0xbda>
     a3a:      	addq	$0x18, %r12
     a3e:      	movl	$0x4, %eax
     a43:      	leaq	0x48(%rsp), %rdi
     a48:      	movl	$0x8, %esi
     a4d:      	movq	%r12, %rdx
     a50:      	callq	*%rax
     a52:      	movq	0x10(%rsp), %rax
     a57:      	movq	%rax, 0x58(%rsp)
     a5c:      	addq	$0x20, %rax
     a60:      	movq	%rax, 0x50(%rsp)
     a65:      	movq	0x18(%rsp), %r13
     a6a:      	jmp	0x8ba <generic_retkprobe_event+0x8ba>
     a6f:      	leaq	0x70(%rsp), %rdi
     a74:      	leaq	0x30(%rsp), %rdx
     a79:      	movl	$0x8, %ecx
     a7e:      	movl	$0x4, %eax
     a83:      	movl	$0x8, %esi
     a88:      	callq	*%rax
     a8a:      	movq	0x70(%rsp), %rax
     a8f:      	movq	%rax, 0x80(%rsp)
     a97:      	testq	%rax, %rax
     a9a:      	jne	0x4c4 <generic_retkprobe_event+0x4c4>
     aa0:      	movl	$0x0, 0x88(%rsp)
     aab:      	movq	(%rip), %rdi            # 0xab2 <generic_retkprobe_event+0xab2>
     ab2:      	leaq	0x88(%rsp), %rsi
     aba:      	movl	$0x1, %eax
     abf:      	callq	*%rax
     ac1:      	testq	%rax, %rax
     ac4:      	je	0xcdc <generic_retkprobe_event+0xcdc>
     aca:      	movq	%r13, 0x8(%rsp)
     acf:      	xorl	%r12d, %r12d
     ad2:      	cmpl	$0x19, %r14d
     ad6:      	movq	0x18(%rsp), %r13
     adb:      	movq	(%rsp), %rcx
     adf:      	jg	0x101d <generic_retkprobe_event+0x101d>
     ae5:      	cmpl	$0x12, %r14d
     ae9:      	jle	0x1179 <generic_retkprobe_event+0x1179>
     aef:      	cmpl	$0x14, %r14d
     af3:      	jle	0x14d9 <generic_retkprobe_event+0x14d9>
     af9:      	cmpl	$0x15, %r14d
     afd:      	je	0x21a4 <generic_retkprobe_event+0x21a4>
     b03:      	cmpl	$0x16, %r14d
     b07:      	je	0x210c <generic_retkprobe_event+0x210c>
     b0d:      	cmpl	$0x17, %r14d
     b11:      	jne	0x148d <generic_retkprobe_event+0x148d>
     b17:      	movl	$0x0, 0xa0(%rcx)
     b21:      	movl	%ebp, 0x9c(%rcx)
     b27:      	movl	$0x8, %r12d
     b2d:      	jmp	0x148d <generic_retkprobe_event+0x148d>
     b32:      	cmpl	$0x2c, %r14d
     b36:      	ja	0xaa0 <generic_retkprobe_event+0xaa0>
     b3c:      	movl	%r14d, %eax
     b3f:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     b49:      	btq	%rax, %rcx
     b4d:      	jae	0xaa0 <generic_retkprobe_event+0xaa0>
     b53:      	movq	%rbp, 0x10(%rsp)
     b58:      	movl	$0x0, 0xd8(%rsp)
     b63:      	movq	(%rip), %rdi            # 0xb6a <generic_retkprobe_event+0xb6a>
     b6a:      	leaq	0xd8(%rsp), %rsi
     b72:      	movl	$0x1, %eax
     b77:      	callq	*%rax
     b79:      	testq	%rax, %rax
     b7c:      	je	0xcdc <generic_retkprobe_event+0xcdc>
     b82:      	movq	%r13, %rbp
     b85:      	xorl	%r12d, %r12d
     b88:      	cmpl	$0x10, %r14d
     b8c:      	jle	0xde1 <generic_retkprobe_event+0xde1>
     b92:      	cmpl	$0x1e, %r14d
     b96:      	movq	0x18(%rsp), %r13
     b9b:      	jle	0xf61 <generic_retkprobe_event+0xf61>
     ba1:      	cmpl	$0x26, %r14d
     ba5:      	jg	0x1053 <generic_retkprobe_event+0x1053>
     bab:      	leal	-0x1f(%r14), %eax
     baf:      	cmpl	$0x2, %eax
     bb2:      	jae	0x15ad <generic_retkprobe_event+0x15ad>
     bb8:      	leaq	0x10(%rsp), %rdx
     bbd:      	movl	$0x4, %r12d
     bc3:      	movl	$0x1, %ecx
     bc8:      	movl	$0x4, %eax
     bcd:      	movq	%rbp, %rdi
     bd0:      	movl	$0x1, %esi
     bd5:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
     bda:      	movb	$0x1, 0x6c(%rsp)
     bdf:      	movq	0x18(%rsp), %r13
     be4:      	movq	0x60(%rsp), %rax
     be9:      	movq	0x8(%rsp), %rdx
     bee:      	xorl	%ebp, %ebp
     bf0:      	cmpq	%rdx, %rax
     bf3:      	je	0xc23 <generic_retkprobe_event+0xc23>
     bf5:      	cmpb	$0x0, 0x6c(%rsp)
     bfa:      	sete	%cl
     bfd:      	movl	0x68(%rsp), %edx
     c01:      	movl	$0x1000, %r12d          # imm = 0x1000
     c07:      	subl	%edx, %r12d
     c0a:      	testl	%edx, %edx
     c0c:      	cmovlel	%edx, %r12d
     c10:      	testq	%rax, %rax
     c13:      	je	0xcd4 <generic_retkprobe_event+0xcd4>
     c19:      	movb	%cl, %bpl
     c1c:      	addl	%ebp, %ebp
     c1e:      	movq	%rax, %rdx
     c21:      	jmp	0xc26 <generic_retkprobe_event+0xc26>
     c23:      	xorl	%r12d, %r12d
     c26:      	movq	(%rsp), %r14
     c2a:      	movq	%r14, %rdi
     c2d:      	addq	$0xa0, %rdi
     c34:      	andl	$0xfff, %r12d           # imm = 0xFFF
     c3b:      	movl	$0x4, %eax
     c40:      	movl	%r12d, %esi
     c43:      	callq	*%rax
     c45:      	movl	%r12d, 0x9c(%r14)
     c4c:      	leaq	0x30(%rsp), %rdi
     c51:      	movl	$0x8, %ecx
     c56:      	movl	$0x4, %eax
     c5b:      	movq	0xe8(%rsp), %rdx
     c63:      	movl	$0x8, %esi
     c68:      	callq	*%rax
     c6a:      	movq	0x30(%rsp), %rcx
     c6f:      	addq	$0x30, %rcx
     c73:      	leaq	0x70(%rsp), %rdi
     c78:      	movl	$0x8, %edx
     c7d:      	movl	$0x4, %eax
     c82:      	movq	0x30(%rsp), %rdx
     c87:      	addq	$0x30, %rdx
     c8b:      	movl	$0x8, %esi
     c90:      	callq	*%rax
     c92:      	movq	0x70(%rsp), %rcx
     c97:      	leaq	0x10(%rsp), %rdi
     c9c:      	movl	$0x2, %edx
     ca1:      	movl	$0x4, %eax
     ca6:      	movq	0x70(%rsp), %rdx
     cab:      	movl	$0x2, %esi
     cb0:      	callq	*%rax
     cb2:      	movq	%r14, %rcx
     cb5:      	movl	%ebp, 0xa0(%r14,%r12)
     cbd:      	movzwl	0x10(%rsp), %eax
     cc2:      	movw	%ax, 0xa4(%r14,%r12)
     ccb:      	addl	$0xa, %r12d
     ccf:      	jmp	0x148d <generic_retkprobe_event+0x148d>
     cd4:      	xorl	%r12d, %r12d
     cd7:      	jmp	0x1497 <generic_retkprobe_event+0x1497>
     cdc:      	xorl	%r12d, %r12d
     cdf:      	movq	0x18(%rsp), %r13
     ce4:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
     ce9:      	xorl	%eax, %eax
     ceb:      	movq	%rax, (%rsp)
     cef:      	movq	0x28(%rsp), %r14
     cf4:      	cmpq	$0x1, 0xa8(%rsp)
     cfd:      	jne	0xd07 <generic_retkprobe_event+0xd07>
     cff:      	movq	%rdx, %r13
     d02:      	jmp	0x421 <generic_retkprobe_event+0x421>
     d07:      	movq	0x98(%rsp), %rax
     d0f:      	leaq	0x10(%rax), %rdx
     d13:      	leaq	0x30(%rsp), %rdi
     d18:      	movl	$0x4, %r12d
     d1e:      	movl	$0x10, %ecx
     d23:      	movl	$0x4, %eax
     d28:      	movl	$0x10, %esi
     d2d:      	callq	*%rax
     d2f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     d34:      	testl	%eax, %eax
     d36:      	js	0x1b40 <generic_retkprobe_event+0x1b40>
     d3c:      	movq	0x38(%rsp), %rsi
     d41:      	movq	(%rsp), %rax
     d45:      	cmpq	%rax, %rsi
     d48:      	movq	%rax, %r13
     d4b:      	cmovbq	%rsi, %r13
     d4f:      	testq	%rax, %rax
     d52:      	cmovneq	%r13, %rsi
     d56:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     d5b:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     d62:      	ja	0x1b40 <generic_retkprobe_event+0x1b40>
     d68:      	movq	0x8(%rsp), %rax
     d6d:      	addq	%rbp, %rax
     d70:      	movq	%rax, 0x8(%rsp)
     d75:      	leaq	(%r15,%rax), %rdi
     d79:      	movq	0x30(%rsp), %rcx
     d7e:      	movl	$0x4, %eax
     d83:      	movq	0x30(%rsp), %rdx
     d88:      	movq	%rsi, 0x80(%rsp)
     d90:      	movq	0x80(%rsp), %rsi
     d98:      	callq	*%rax
     d9a:      	movq	0x80(%rsp), %rdx
     da2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     da7:      	testl	%eax, %eax
     da9:      	js	0x1b40 <generic_retkprobe_event+0x1b40>
     daf:      	addq	%rdx, %rbp
     db2:      	movq	(%rsp), %r14
     db6:      	testq	%r14, %r14
     db9:      	je	0x1a66 <generic_retkprobe_event+0x1a66>
     dbf:      	subq	%r13, %r14
     dc2:      	jne	0x1a69 <generic_retkprobe_event+0x1a69>
     dc8:      	jmp	0x1e04 <generic_retkprobe_event+0x1e04>
     dcd:      	movb	$0x1, 0x6c(%rsp)
     dd2:      	movq	0x18(%rsp), %r13
     dd7:      	movq	0x20(%rsp), %r15
     ddc:      	jmp	0xbe4 <generic_retkprobe_event+0xbe4>
     de1:      	cmpl	$0x9, %r14d
     de5:      	movq	0x18(%rsp), %r13
     dea:      	jg	0xf92 <generic_retkprobe_event+0xf92>
     df0:      	cmpl	$0x4, %r14d
     df4:      	movq	(%rsp), %rcx
     df8:      	jle	0x11cf <generic_retkprobe_event+0x11cf>
     dfe:      	cmpl	$0x5, %r14d
     e02:      	je	0x17a7 <generic_retkprobe_event+0x17a7>
     e08:      	cmpl	$0x6, %r14d
     e0c:      	je	0xffa <generic_retkprobe_event+0xffa>
     e12:      	movq	%rax, 0x8(%rsp)
     e17:      	cmpl	$0x7, %r14d
     e1b:      	jne	0x148d <generic_retkprobe_event+0x148d>
     e21:      	movq	0x10(%rsp), %r12
     e26:      	movq	%r12, 0xc4(%rcx)
     e2d:      	leaq	0xc2(%rcx), %rdi
     e34:      	leaq	0x10(%r12), %rdx
     e39:      	movq	%rcx, %r14
     e3c:      	movl	$0x2, %ecx
     e41:      	movl	$0x4, %eax
     e46:      	movl	$0x2, %esi
     e4b:      	callq	*%rax
     e4d:      	leaq	0xd6(%r14), %rdi
     e54:      	leaq	0x12(%r12), %rdx
     e59:      	movl	$0x1, %ecx
     e5e:      	movl	$0x4, %eax
     e63:      	movl	$0x1, %esi
     e68:      	callq	*%rax
     e6a:      	leaq	0xd4(%r14), %rdi
     e71:      	leaq	0x226(%r12), %rdx
     e79:      	movl	$0x2, %ecx
     e7e:      	movl	$0x4, %eax
     e83:      	movl	$0x2, %esi
     e88:      	callq	*%rax
     e8a:      	leaq	0xc0(%r14), %rdi
     e91:      	leaq	0x224(%r12), %rdx
     e99:      	movl	$0x2, %ecx
     e9e:      	movl	$0x4, %eax
     ea3:      	movl	$0x2, %esi
     ea8:      	callq	*%rax
     eaa:      	leaq	0xcc(%r14), %rdi
     eb1:      	leaq	0x21c(%r12), %rdx
     eb9:      	movl	$0x4, %ecx
     ebe:      	movl	$0x4, %eax
     ec3:      	movl	$0x4, %esi
     ec8:      	callq	*%rax
     eca:      	leaq	0xd0(%r14), %rdi
     ed1:      	leaq	0x218(%r12), %rdx
     ed9:      	movl	$0x4, %ecx
     ede:      	movl	$0x4, %eax
     ee3:      	movl	$0x4, %esi
     ee8:      	callq	*%rax
     eea:      	leaq	0xac(%r14), %r13
     ef1:      	movq	%rbp, %rax
     ef4:      	movq	$0x0, (%rbp)
     efc:      	movq	$0x0, 0x8(%rbp)
     f04:      	movq	$0x0, 0x10(%rbp)
     f0c:      	movq	$0x0, 0x18(%rbp)
     f14:      	movzwl	0xc2(%r14), %eax
     f1c:      	cmpl	$0xa, %eax
     f1f:      	je	0x251f <generic_retkprobe_event+0x251f>
     f25:      	cmpl	$0x2, %eax
     f28:      	jne	0x2551 <generic_retkprobe_event+0x2551>
     f2e:      	leaq	0x4(%r12), %rdx
     f33:      	movl	$0x4, %ecx
     f38:      	movl	$0x4, %eax
     f3d:      	movq	%rbp, %rdi
     f40:      	movl	$0x4, %esi
     f45:      	callq	*%rax
     f47:      	movl	$0x4, %ecx
     f4c:      	movl	$0x4, %eax
     f51:      	movq	%r13, %rdi
     f54:      	movl	$0x4, %esi
     f59:      	movq	%r12, %rdx
     f5c:      	jmp	0x254f <generic_retkprobe_event+0x254f>
     f61:      	cmpl	$0x1c, %r14d
     f65:      	jg	0x11ad <generic_retkprobe_event+0x11ad>
     f6b:      	cmpl	$0x11, %r14d
     f6f:      	je	0x15ea <generic_retkprobe_event+0x15ea>
     f75:      	cmpl	$0x19, %r14d
     f79:      	je	0x16b6 <generic_retkprobe_event+0x16b6>
     f7f:      	cmpl	$0x1c, %r14d
     f83:      	movq	(%rsp), %rcx
     f87:      	je	0x11df <generic_retkprobe_event+0x11df>
     f8d:      	jmp	0x148d <generic_retkprobe_event+0x148d>
     f92:      	leal	-0xa(%r14), %eax
     f96:      	cmpl	$0x2, %eax
     f99:      	movq	(%rsp), %rcx
     f9d:      	jb	0x11df <generic_retkprobe_event+0x11df>
     fa3:      	leal	-0xc(%r14), %eax
     fa7:      	cmpl	$0x2, %eax
     faa:      	jb	0x1201 <generic_retkprobe_event+0x1201>
     fb0:      	cmpl	$0xe, %r14d
     fb4:      	jne	0x148d <generic_retkprobe_event+0x148d>
     fba:      	leaq	0x30(%rsp), %rdi
     fbf:      	leaq	0x10(%rsp), %r14
     fc4:      	movl	$0x8, %ecx
     fc9:      	movl	$0x4, %eax
     fce:      	movl	$0x8, %esi
     fd3:      	movq	%r14, %rdx
     fd6:      	callq	*%rax
     fd8:      	movq	0x30(%rsp), %rcx
     fdd:      	movl	$0x8, %edx
     fe2:      	movl	$0x4, %eax
     fe7:      	movq	0x30(%rsp), %rdx
     fec:      	movq	%r14, %rdi
     fef:      	movl	$0x8, %esi
     ff4:      	callq	*%rax
     ff6:      	movq	(%rsp), %rcx
     ffa:      	movq	0x10(%rsp), %rdx
     fff:      	movq	%rcx, %rdi
    1002:      	addq	$0xa0, %rdi
    1009:      	movl	$0x1001, %ecx           # imm = 0x1001
    100e:      	movl	$0x2d, %eax
    1013:      	movl	$0x1001, %esi           # imm = 0x1001
    1018:      	jmp	0x19ac <generic_retkprobe_event+0x19ac>
    101d:      	cmpl	$0x20, %r14d
    1021:      	jle	0x13a4 <generic_retkprobe_event+0x13a4>
    1027:      	leal	-0x21(%r14), %edx
    102b:      	cmpl	$0x4, %edx
    102e:      	jae	0x1223 <generic_retkprobe_event+0x1223>
    1034:      	movl	$0x8, %r12d
    103a:      	movl	$0x8, %ecx
    103f:      	movl	$0x4, %eax
    1044:      	movq	0x8(%rsp), %rdi
    1049:      	movl	$0x8, %esi
    104e:      	jmp	0x1484 <generic_retkprobe_event+0x1484>
    1053:      	cmpl	$0x27, %r14d
    1057:      	je	0x1988 <generic_retkprobe_event+0x1988>
    105d:      	cmpl	$0x28, %r14d
    1061:      	je	0x19cb <generic_retkprobe_event+0x19cb>
    1067:      	cmpl	$0x2c, %r14d
    106b:      	movq	(%rsp), %rcx
    106f:      	jne	0x148d <generic_retkprobe_event+0x148d>
    1075:      	movq	0x10(%rsp), %r12
    107a:      	movb	$0x0, 0x30(%rsp)
    107f:      	movq	$0x0, 0x68(%rbp)
    1087:      	movq	$0x0, 0x60(%rbp)
    108f:      	movq	$0x0, 0x58(%rbp)
    1097:      	movq	$0x0, 0x50(%rbp)
    109f:      	movq	$0x0, 0x48(%rbp)
    10a7:      	movq	$0x0, 0x40(%rbp)
    10af:      	movq	$0x0, 0x38(%rbp)
    10b7:      	movq	$0x0, 0x30(%rbp)
    10bf:      	movq	$0x0, 0x28(%rbp)
    10c7:      	movq	$0x0, 0x20(%rbp)
    10cf:      	movq	$0x0, 0x18(%rbp)
    10d7:      	movq	$0x0, 0x10(%rbp)
    10df:      	movq	$0x0, 0x8(%rbp)
    10e7:      	movq	$0x0, (%rbp)
    10ef:      	movl	$0x2, %ecx
    10f4:      	movl	$0x4, %eax
    10f9:      	movq	%rbp, %rdi
    10fc:      	movl	$0x2, %esi
    1101:      	movq	%r12, %rdx
    1104:      	callq	*%rax
    1106:      	testq	%rax, %rax
    1109:      	js	0x278b <generic_retkprobe_event+0x278b>
    110f:      	leaq	0x2(%r12), %r13
    1114:      	leaq	0x30(%rsp), %rdi
    1119:      	movl	$0x1, %ecx
    111e:      	movl	$0x4, %eax
    1123:      	movl	$0x1, %esi
    1128:      	movq	%r13, %rdx
    112b:      	callq	*%rax
    112d:      	testq	%rax, %rax
    1130:      	js	0x278b <generic_retkprobe_event+0x278b>
    1136:      	movq	(%rsp), %rax
    113a:      	movq	%rax, %rdi
    113d:      	addq	$0xa0, %rdi
    1144:      	cmpb	$0x0, 0x30(%rsp)
    1149:      	sete	0x9e(%rax)
    1150:      	je	0x2760 <generic_retkprobe_event+0x2760>
    1156:      	movl	$0x6c, %ecx
    115b:      	movl	$0x2d, %eax
    1160:      	movl	$0x6c, %esi
    1165:      	movq	%r13, %rdx
    1168:      	callq	*%rax
    116a:      	testl	%eax, %eax
    116c:      	js	0x278b <generic_retkprobe_event+0x278b>
    1172:      	decb	%al
    1174:      	jmp	0x2781 <generic_retkprobe_event+0x2781>
    1179:      	cmpl	$0x7, %r14d
    117d:      	jg	0x1465 <generic_retkprobe_event+0x1465>
    1183:      	cmpl	$0x2, %r14d
    1187:      	je	0x1e11 <generic_retkprobe_event+0x1e11>
    118d:      	cmpl	$0x3, %r14d
    1191:      	jne	0x148d <generic_retkprobe_event+0x148d>
    1197:      	movq	$0x0, 0x9c(%rax)
    11a2:      	movl	$0x8, %r12d
    11a8:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    11ad:      	leaq	0x10(%rsp), %rdx
    11b2:      	movl	$0x4, %r12d
    11b8:      	movl	$0x2, %ecx
    11bd:      	movl	$0x4, %eax
    11c2:      	movq	%rbp, %rdi
    11c5:      	movl	$0x2, %esi
    11ca:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    11cf:      	cmpl	$0x1, %r14d
    11d3:      	je	0x1201 <generic_retkprobe_event+0x1201>
    11d5:      	cmpl	$0x4, %r14d
    11d9:      	jne	0x148d <generic_retkprobe_event+0x148d>
    11df:      	movl	$0x8, %r12d
    11e5:      	leaq	0x10(%rsp), %rdx
    11ea:      	movl	$0x8, %ecx
    11ef:      	movl	$0x4, %eax
    11f4:      	movq	%rbp, %rdi
    11f7:      	movl	$0x8, %esi
    11fc:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    1201:      	leaq	0x10(%rsp), %rdx
    1206:      	movl	$0x4, %r12d
    120c:      	movl	$0x4, %ecx
    1211:      	movl	$0x4, %eax
    1216:      	movq	%rbp, %rdi
    1219:      	movl	$0x4, %esi
    121e:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    1223:      	cmpl	$0x2b, %r14d
    1227:      	je	0x22af <generic_retkprobe_event+0x22af>
    122d:      	cmpl	$0x29, %r14d
    1231:      	jne	0x148d <generic_retkprobe_event+0x148d>
    1237:      	movq	%rax, 0x80(%rsp)
    123f:      	addq	$0x18, %rbp
    1243:      	leaq	0x30(%rsp), %rdi
    1248:      	movl	$0x4, %r14d
    124e:      	movl	$0x8, %ecx
    1253:      	movl	$0x4, %eax
    1258:      	movl	$0x8, %esi
    125d:      	movq	%rbp, %rdx
    1260:      	callq	*%rax
    1262:      	movq	0x30(%rsp), %r12
    1267:      	testq	%r12, %r12
    126a:      	je	0x2827 <generic_retkprobe_event+0x2827>
    1270:      	movq	(%rsp), %rbp
    1274:      	movq	%r12, 0xc4(%rbp)
    127b:      	leaq	0xc2(%rbp), %rdi
    1282:      	leaq	0x10(%r12), %rdx
    1287:      	movl	$0x2, %ecx
    128c:      	movl	$0x4, %eax
    1291:      	movl	$0x2, %esi
    1296:      	callq	*%rax
    1298:      	leaq	0xd6(%rbp), %rdi
    129f:      	leaq	0x12(%r12), %rdx
    12a4:      	movl	$0x1, %ecx
    12a9:      	movl	$0x4, %eax
    12ae:      	movl	$0x1, %esi
    12b3:      	callq	*%rax
    12b5:      	leaq	0xd4(%rbp), %rdi
    12bc:      	leaq	0x226(%r12), %rdx
    12c4:      	movl	$0x2, %ecx
    12c9:      	movl	$0x4, %eax
    12ce:      	movl	$0x2, %esi
    12d3:      	callq	*%rax
    12d5:      	leaq	0xc0(%rbp), %rdi
    12dc:      	leaq	0x224(%r12), %rdx
    12e4:      	movl	$0x2, %ecx
    12e9:      	movl	$0x4, %eax
    12ee:      	movl	$0x2, %esi
    12f3:      	callq	*%rax
    12f5:      	leaq	0xcc(%rbp), %rdi
    12fc:      	leaq	0x21c(%r12), %rdx
    1304:      	movl	$0x4, %eax
    1309:      	movl	$0x4, %esi
    130e:      	callq	*%rax
    1310:      	leaq	0xd0(%rbp), %rdi
    1317:      	leaq	0x218(%r12), %rdx
    131f:      	movl	$0x4, %eax
    1324:      	movl	$0x4, %esi
    1329:      	callq	*%rax
    132b:      	leaq	0xac(%rbp), %r13
    1332:      	movq	0x8(%rsp), %rax
    1337:      	movq	$0x0, (%rax)
    133e:      	movq	$0x0, 0x8(%rax)
    1346:      	movq	$0x0, 0x10(%rax)
    134e:      	movq	$0x0, 0x18(%rax)
    1356:      	movzwl	0xc2(%rbp), %eax
    135d:      	cmpl	$0xa, %eax
    1360:      	je	0x279b <generic_retkprobe_event+0x279b>
    1366:      	cmpl	$0x2, %eax
    1369:      	jne	0x27cf <generic_retkprobe_event+0x27cf>
    136f:      	leaq	0x4(%r12), %rdx
    1374:      	movl	$0x4, %ecx
    1379:      	movl	$0x4, %eax
    137e:      	movq	0x8(%rsp), %rdi
    1383:      	movl	$0x4, %esi
    1388:      	callq	*%rax
    138a:      	movl	$0x4, %ecx
    138f:      	movl	$0x4, %eax
    1394:      	movq	%r13, %rdi
    1397:      	movl	$0x4, %esi
    139c:      	movq	%r12, %rdx
    139f:      	jmp	0x27cd <generic_retkprobe_event+0x27cd>
    13a4:      	cmpl	$0x1a, %r14d
    13a8:      	je	0x2359 <generic_retkprobe_event+0x2359>
    13ae:      	cmpl	$0x1b, %r14d
    13b2:      	jne	0x148d <generic_retkprobe_event+0x148d>
    13b8:      	movq	0x8(%rsp), %rax
    13bd:      	movq	$0x0, 0x48(%rax)
    13c5:      	movq	$0x0, 0x40(%rax)
    13cd:      	movq	$0x0, 0x38(%rax)
    13d5:      	movq	$0x0, 0x30(%rax)
    13dd:      	movq	$0x0, 0x28(%rax)
    13e5:      	movq	$0x0, 0x20(%rax)
    13ed:      	movq	$0x0, 0x18(%rax)
    13f5:      	movq	$0x0, 0x10(%rax)
    13fd:      	movq	$0x0, 0x8(%rax)
    1405:      	movq	$0x0, (%rax)
    140c:      	leaq	0xac(%rcx), %rdi
    1413:      	leaq	0x18(%rbp), %rdx
    1417:      	movl	$0x3f, %ecx
    141c:      	movl	$0x2d, %eax
    1421:      	movl	$0x3f, %esi
    1426:      	callq	*%rax
    1428:      	testq	%rax, %rax
    142b:      	js	0x2732 <generic_retkprobe_event+0x2732>
    1431:      	movq	(%rsp), %r14
    1435:      	movq	%r14, %rdi
    1438:      	addq	$0xa4, %rdi
    143f:      	addq	$0x348, %rbp            # imm = 0x348
    1446:      	movl	$0x8, %ecx
    144b:      	movl	$0x4, %eax
    1450:      	movl	$0x8, %esi
    1455:      	movq	%rbp, %rdx
    1458:      	callq	*%rax
    145a:      	movq	%r14, %rcx
    145d:      	movl	$0x50, %r12d
    1463:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    1465:      	cmpl	$0x8, %r14d
    1469:      	je	0x1ebe <generic_retkprobe_event+0x1ebe>
    146f:      	cmpl	$0x12, %r14d
    1473:      	jne	0x148d <generic_retkprobe_event+0x148d>
    1475:      	xorl	%r12d, %r12d
    1478:      	movl	$0x4, %eax
    147d:      	movq	0x8(%rsp), %rdi
    1482:      	xorl	%esi, %esi
    1484:      	movq	%rbp, %rdx
    1487:      	callq	*%rax
    1489:      	movq	(%rsp), %rcx
    148d:      	testl	%r12d, %r12d
    1490:      	movl	$0x4, %ebp
    1495:      	js	0x14a7 <generic_retkprobe_event+0x14a7>
    1497:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    149e:      	addq	$0x4, %r12
    14a2:      	movq	%r12, %rbp
    14a5:      	jmp	0x14bb <generic_retkprobe_event+0x14bb>
    14a7:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    14b1:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    14bb:      	movq	0xb8(%rsp), %r12
    14c3:      	addq	$0x8, %rbp
    14c7:      	movl	0x60(%r13), %eax
    14cb:      	cmpl	$0xb, %eax
    14ce:      	jne	0x1b3 <generic_retkprobe_event+0x1b3>
    14d4:      	jmp	0x2fc <generic_retkprobe_event+0x2fc>
    14d9:      	cmpl	$0x13, %r14d
    14dd:      	je	0x2250 <generic_retkprobe_event+0x2250>
    14e3:      	cmpl	$0x14, %r14d
    14e7:      	jne	0x148d <generic_retkprobe_event+0x148d>
    14e9:      	movq	$0x0, 0x30(%rsp)
    14f2:      	leaq	0x110(%rbp), %rdx
    14f9:      	leaq	0x30(%rsp), %rdi
    14fe:      	movl	$0x8, %ecx
    1503:      	movl	$0x4, %eax
    1508:      	leaq	0xd8(%rbp), %r12
    150f:      	movl	$0x8, %esi
    1514:      	callq	*%rax
    1516:      	movq	0x30(%rsp), %rcx
    151b:      	movl	$0x80, %edx
    1520:      	movl	$0x2d, %eax
    1525:      	movq	0x8(%rsp), %rdi
    152a:      	movq	0x30(%rsp), %rdx
    152f:      	movl	$0x80, %esi
    1534:      	callq	*%rax
    1536:      	movq	(%rsp), %rax
    153a:      	leaq	0x12c(%rax), %rdi
    1541:      	movl	$0x4, %ecx
    1546:      	movl	$0x4, %eax
    154b:      	movl	$0x4, %esi
    1550:      	movq	%r12, %rdx
    1553:      	callq	*%rax
    1555:      	movq	(%rsp), %rax
    1559:      	leaq	0x11c(%rax), %rdi
    1560:      	leaq	0xe0(%rbp), %rdx
    1567:      	movl	$0x8, %ecx
    156c:      	movl	$0x4, %eax
    1571:      	movl	$0x8, %esi
    1576:      	callq	*%rax
    1578:      	movq	(%rsp), %rdi
    157c:      	addq	$0x124, %rdi            # imm = 0x124
    1583:      	addq	$0x118, %rbp            # imm = 0x118
    158a:      	movl	$0x8, %ecx
    158f:      	movl	$0x4, %eax
    1594:      	movl	$0x8, %esi
    1599:      	movq	%rbp, %rdx
    159c:      	callq	*%rax
    159e:      	movq	(%rsp), %rcx
    15a2:      	movl	$0x98, %r12d
    15a8:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    15ad:      	cmpl	$0x26, %r14d
    15b1:      	movq	(%rsp), %rcx
    15b5:      	jne	0x148d <generic_retkprobe_event+0x148d>
    15bb:      	movq	0x10(%rsp), %rsi
    15c0:      	movzwl	%si, %edx
    15c3:      	addq	0xb8(%rsp), %rdx
    15cb:      	shrl	$0x10, %esi
    15ce:      	andl	$0xfff, %esi            # imm = 0xFFF
    15d4:      	movq	%rcx, %rdi
    15d7:      	addq	$0xa0, %rdi
    15de:      	incl	%esi
    15e0:      	movl	$0x2d, %eax
    15e5:      	jmp	0x19ac <generic_retkprobe_event+0x19ac>
    15ea:      	movq	$0x0, 0x38(%rsp)
    15f3:      	movq	$0x0, 0x30(%rsp)
    15fc:      	movl	$0xe, %eax
    1601:      	callq	*%rax
    1603:      	shrq	$0x20, %rax
    1607:      	movq	%rax, 0x30(%rsp)
    160c:      	leaq	0x70(%rsp), %rdi
    1611:      	leaq	0x10(%rsp), %rdx
    1616:      	movl	$0x4, %ecx
    161b:      	movl	$0x4, %eax
    1620:      	movl	$0x4, %r14d
    1626:      	movl	$0x4, %esi
    162b:      	callq	*%rax
    162d:      	movl	0x70(%rsp), %eax
    1631:      	movl	%eax, 0x38(%rsp)
    1635:      	movq	(%rip), %rdi            # 0x163c <generic_retkprobe_event+0x163c>
    163c:      	leaq	0x30(%rsp), %rsi
    1641:      	movl	$0x1, %eax
    1646:      	callq	*%rax
    1648:      	testq	%rax, %rax
    164b:      	je	0x23d7 <generic_retkprobe_event+0x23d7>
    1651:      	movl	(%rax), %r12d
    1654:      	leaq	0x70(%rsp), %rdx
    1659:      	movq	%rax, %r13
    165c:      	movl	$0x4, %eax
    1661:      	movq	%rbp, %rdi
    1664:      	movl	$0x4, %esi
    1669:      	callq	*%rax
    166b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1672:      	movq	(%rsp), %rdi
    1676:      	addq	$0xa0, %rdi
    167d:      	leaq	0x4(%r12), %rsi
    1682:      	movl	$0x4, %eax
    1687:      	movq	%r13, %rdx
    168a:      	callq	*%rax
    168c:      	leaq	(%r12,%rbp), %rdi
    1690:      	addq	$0x8, %rdi
    1694:      	leaq	(%r12,%r13), %rdx
    1698:      	addq	$0x4, %rdx
    169c:      	movl	$0x4, %eax
    16a1:      	movl	$0x4, %esi
    16a6:      	callq	*%rax
    16a8:      	addq	$0xc, %r12
    16ac:      	movq	0x18(%rsp), %r13
    16b1:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    16b6:      	movq	%rax, %r14
    16b9:      	movq	0x10(%rsp), %r13
    16be:      	leaq	0xa0(%rsp), %rdi
    16c6:      	movl	$0x1, %ecx
    16cb:      	movl	$0x4, %eax
    16d0:      	movl	$0x1, %esi
    16d5:      	movq	%r13, %rdx
    16d8:      	callq	*%rax
    16da:      	movzbl	0xa0(%rsp), %eax
    16e2:      	testl	%eax, %eax
    16e4:      	je	0x23e8 <generic_retkprobe_event+0x23e8>
    16ea:      	cmpl	$0x1, %eax
    16ed:      	jne	0x25f3 <generic_retkprobe_event+0x25f3>
    16f3:      	addq	$0x10, %r13
    16f7:      	leaq	0x30(%rsp), %rdi
    16fc:      	movl	$0x4, %r12d
    1702:      	movl	$0x8, %ecx
    1707:      	movl	$0x4, %eax
    170c:      	movl	$0x8, %esi
    1711:      	movq	%r13, %rdx
    1714:      	callq	*%rax
    1716:      	movq	0x30(%rsp), %rdx
    171b:      	leaq	0x70(%rsp), %rdi
    1720:      	movl	$0x8, %ecx
    1725:      	movl	$0x4, %eax
    172a:      	movl	$0x8, %esi
    172f:      	callq	*%rax
    1731:      	movq	0x30(%rsp), %rdx
    1736:      	addq	$0x8, %rdx
    173a:      	leaq	0x88(%rsp), %rdi
    1742:      	movl	$0x8, %ecx
    1747:      	movl	$0x4, %eax
    174c:      	movl	$0x8, %esi
    1751:      	callq	*%rax
    1753:      	movq	0x70(%rsp), %rdx
    1758:      	movq	0x88(%rsp), %rbp
    1760:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1767:      	movl	$0xfff, %r13d           # imm = 0xFFF
    176d:      	cmovbq	%rbp, %r13
    1771:      	movq	%r14, %rdi
    1774:      	addq	$0xa4, %rdi
    177b:      	movl	$0x4, %eax
    1780:      	movl	%r13d, %esi
    1783:      	callq	*%rax
    1785:      	testl	%eax, %eax
    1787:      	js	0x273a <generic_retkprobe_event+0x273a>
    178d:      	movl	%ebp, 0x9c(%r14)
    1794:      	movl	%r13d, 0xa0(%r14)
    179b:      	addq	$0x8, %r13
    179f:      	movq	%r13, %r12
    17a2:      	jmp	0x2870 <generic_retkprobe_event+0x2870>
    17a7:      	movq	0x10(%rsp), %r12
    17ac:      	leaq	0xc4(%rcx), %rdi
    17b3:      	leaq	0x98(%r12), %rdx
    17bb:      	movq	%rcx, %r14
    17be:      	movl	$0x4, %ecx
    17c3:      	movl	$0x4, %eax
    17c8:      	movl	$0x4, %esi
    17cd:      	callq	*%rax
    17cf:      	leaq	0xc8(%r14), %rdi
    17d6:      	leaq	0x70(%r12), %rdx
    17db:      	movl	$0x4, %ecx
    17e0:      	movl	$0x4, %eax
    17e5:      	movl	$0x4, %esi
    17ea:      	callq	*%rax
    17ec:      	leaq	0xcc(%r14), %rdi
    17f3:      	leaq	0x90(%r12), %rdx
    17fb:      	movl	$0x4, %ecx
    1800:      	movl	$0x4, %eax
    1805:      	movl	$0x4, %esi
    180a:      	callq	*%rax
    180c:      	leaq	0xd0(%r14), %rdi
    1813:      	leaq	0xa8(%r12), %rdx
    181b:      	movl	$0x4, %ecx
    1820:      	movl	$0x4, %eax
    1825:      	movl	$0x4, %esi
    182a:      	callq	*%rax
    182c:      	movq	$0x0, 0x30(%rsp)
    1835:      	leaq	0xc8(%r12), %rdx
    183d:      	leaq	0x30(%rsp), %rdi
    1842:      	movl	$0x8, %ecx
    1847:      	movl	$0x4, %eax
    184c:      	movl	$0x8, %esi
    1851:      	callq	*%rax
    1853:      	movq	%r12, 0x80(%rsp)
    185b:      	leaq	0xb8(%r12), %rdx
    1863:      	leaq	0xa0(%rsp), %rdi
    186b:      	movl	$0x2, %ecx
    1870:      	movl	$0x4, %eax
    1875:      	movl	$0x2, %esi
    187a:      	callq	*%rax
    187c:      	movzwl	0xa0(%rsp), %r12d
    1885:      	addq	0x30(%rsp), %r12
    188a:      	leaq	0xb4(%rsp), %rdi
    1892:      	movl	$0x1, %ecx
    1897:      	movl	$0x4, %eax
    189c:      	movl	$0x1, %esi
    18a1:      	movq	%r12, %rdx
    18a4:      	callq	*%rax
    18a6:      	movzbl	0xb4(%rsp), %eax
    18ae:      	shrl	$0x4, %eax
    18b1:      	cmpl	$0x6, %eax
    18b4:      	je	0x2473 <generic_retkprobe_event+0x2473>
    18ba:      	cmpl	$0x4, %eax
    18bd:      	jne	0x31dd <generic_retkprobe_event+0x31dd>
    18c3:      	movq	%rbx, 0x8(%rsp)
    18c8:      	leaq	0x9(%r12), %rdx
    18cd:      	leaq	0xc8(%rsp), %rdi
    18d5:      	movl	$0x1, %ecx
    18da:      	movl	$0x4, %eax
    18df:      	movl	$0x1, %esi
    18e4:      	callq	*%rax
    18e6:      	movzbl	0xc8(%rsp), %eax
    18ee:      	movq	(%rsp), %rsi
    18f2:      	movw	%ax, 0xc0(%rsi)
    18f9:      	movw	$0x2, 0xc2(%rsi)
    1902:      	leaq	0xc(%r12), %rdx
    1907:      	movq	$0x0, (%rbp)
    190f:      	movq	$0x0, 0x8(%rbp)
    1917:      	movq	$0x0, 0x10(%rbp)
    191f:      	movq	$0x0, 0x18(%rbp)
    1927:      	movl	$0x4, %ecx
    192c:      	movl	$0x4, %eax
    1931:      	leaq	0xac(%rsi), %r14
    1938:      	movq	%rbp, %rdi
    193b:      	movl	$0x4, %esi
    1940:      	callq	*%rax
    1942:      	addq	$0x10, %r12
    1946:      	movl	$0x4, %ecx
    194b:      	movl	$0x4, %eax
    1950:      	movq	%r14, %rdi
    1953:      	movl	$0x4, %esi
    1958:      	movq	%r12, %rdx
    195b:      	callq	*%rax
    195d:      	movq	0x80(%rsp), %rax
    1965:      	leaq	0xb6(%rax), %rdx
    196c:      	leaq	0xd0(%rsp), %rdi
    1974:      	movl	$0x2, %ecx
    1979:      	movl	$0x4, %eax
    197e:      	movl	$0x2, %esi
    1983:      	jmp	0x3045 <generic_retkprobe_event+0x3045>
    1988:      	movl	$0x120, %edx            # imm = 0x120
    198d:      	addq	0x10(%rsp), %rdx
    1992:      	movq	(%rsp), %rdi
    1996:      	addq	$0xa0, %rdi
    199d:      	movl	$0x11, %ecx
    19a2:      	movl	$0x2d, %eax
    19a7:      	movl	$0x11, %esi
    19ac:      	callq	*%rax
    19ae:      	movq	%rax, %r12
    19b1:      	testq	%rax, %rax
    19b4:      	js	0x1489 <generic_retkprobe_event+0x1489>
    19ba:      	leal	-0x1(%r12), %eax
    19bf:      	movl	%eax, (%rbp)
    19c2:      	addq	$0x3, %r12
    19c6:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    19cb:      	movq	0x10(%rsp), %r12
    19d0:      	movq	$0x0, 0x10(%rbp)
    19d8:      	movq	$0x0, 0x8(%rbp)
    19e0:      	movq	$0x0, (%rbp)
    19e8:      	movl	$0x2, %ecx
    19ed:      	movl	$0x4, %eax
    19f2:      	movq	%rbp, %rdi
    19f5:      	movl	$0x2, %esi
    19fa:      	movq	%r12, %rdx
    19fd:      	callq	*%rax
    19ff:      	testq	%rax, %rax
    1a02:      	movq	(%rsp), %rcx
    1a06:      	js	0x266e <generic_retkprobe_event+0x266e>
    1a0c:      	movzwl	(%rbp), %eax
    1a10:      	cmpl	$0xa, %eax
    1a13:      	je	0x260e <generic_retkprobe_event+0x260e>
    1a19:      	cmpl	$0x2, %eax
    1a1c:      	jne	0x2650 <generic_retkprobe_event+0x2650>
    1a22:      	leaq	0x4(%r12), %rdx
    1a27:      	leaq	0x30(%rsp), %rdi
    1a2c:      	movl	$0x4, %ecx
    1a31:      	movl	$0x4, %eax
    1a36:      	movl	$0x4, %esi
    1a3b:      	callq	*%rax
    1a3d:      	movl	0x30(%rsp), %eax
    1a41:      	movq	(%rsp), %rdi
    1a45:      	movq	%rax, 0xa4(%rdi)
    1a4c:      	addq	$0x9e, %rdi
    1a53:      	addq	$0x2, %r12
    1a57:      	movl	$0x2, %ecx
    1a5c:      	movl	$0x4, %eax
    1a61:      	jmp	0x2646 <generic_retkprobe_event+0x2646>
    1a66:      	xorl	%r14d, %r14d
    1a69:      	cmpq	$0x3, 0xa8(%rsp)
    1a72:      	jb	0x1e04 <generic_retkprobe_event+0x1e04>
    1a78:      	movq	0x98(%rsp), %rax
    1a80:      	leaq	0x20(%rax), %rdx
    1a84:      	leaq	0x30(%rsp), %rdi
    1a89:      	movl	$0x4, %r12d
    1a8f:      	movl	$0x10, %ecx
    1a94:      	movl	$0x4, %eax
    1a99:      	movl	$0x10, %esi
    1a9e:      	callq	*%rax
    1aa0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1aa5:      	testl	%eax, %eax
    1aa7:      	js	0x1b3b <generic_retkprobe_event+0x1b3b>
    1aad:      	movq	0x38(%rsp), %rax
    1ab2:      	cmpq	%r14, %rax
    1ab5:      	movq	%r14, %rcx
    1ab8:      	cmovbq	%rax, %rcx
    1abc:      	movq	%r14, (%rsp)
    1ac0:      	testq	%r14, %r14
    1ac3:      	movq	%rax, %r14
    1ac6:      	movq	%rcx, %r13
    1ac9:      	cmovneq	%rcx, %r14
    1acd:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1ad2:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1ad9:      	ja	0x1b3b <generic_retkprobe_event+0x1b3b>
    1adb:      	movq	0x80(%rsp), %rdi
    1ae3:      	addq	0x8(%rsp), %rdi
    1ae8:      	movq	%rdi, 0x80(%rsp)
    1af0:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1af6:      	addq	%r15, %rdi
    1af9:      	movq	0x30(%rsp), %rcx
    1afe:      	movl	$0x4, %eax
    1b03:      	movq	0x30(%rsp), %rdx
    1b08:      	movl	%r14d, %esi
    1b0b:      	callq	*%rax
    1b0d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b12:      	testl	%eax, %eax
    1b14:      	js	0x1b3b <generic_retkprobe_event+0x1b3b>
    1b16:      	movq	%r15, 0x20(%rsp)
    1b1b:      	movq	%r14, %r15
    1b1e:      	addq	%r14, %rbp
    1b21:      	cmpq	$0x0, (%rsp)
    1b26:      	je	0x28bf <generic_retkprobe_event+0x28bf>
    1b2c:      	subq	%r13, (%rsp)
    1b30:      	jne	0x28c5 <generic_retkprobe_event+0x28c5>
    1b36:      	jmp	0x28d0 <generic_retkprobe_event+0x28d0>
    1b3b:      	movq	0x28(%rsp), %r14
    1b40:      	movl	%ecx, (%r15,%r14)
    1b44:      	addq	%r14, %r12
    1b47:      	movq	%r12, %rbp
    1b4a:      	movq	0xb8(%rsp), %r12
    1b52:      	movq	0x18(%rsp), %r13
    1b57:      	movl	$0x23, %eax
    1b5c:      	callq	*%rax
    1b5e:      	movq	%rax, %rcx
    1b61:      	movq	%rax, 0x30(%rsp)
    1b66:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1b6d:      	leaq	0x88(%rsp), %rdi
    1b75:      	movl	$0x4, %edx
    1b7a:      	movl	$0x71, %eax
    1b7f:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1b84:      	addq	0x30(%rsp), %rdx
    1b89:      	movl	$0x4, %esi
    1b8e:      	callq	*%rax
    1b90:      	movl	0x88(%rsp), %eax
    1b97:      	movl	%eax, 0x70(%rsp)
    1b9b:      	movq	(%rip), %rdi            # 0x1ba2 <generic_retkprobe_event+0x1ba2>
    1ba2:      	leaq	0x70(%rsp), %rsi
    1ba7:      	movl	$0x1, %eax
    1bac:      	callq	*%rax
    1bae:      	testq	%rax, %rax
    1bb1:      	je	0x1bc1 <generic_retkprobe_event+0x1bc1>
    1bb3:      	movq	%rax, %r15
    1bb6:      	cmpq	$0x0, 0x8(%rax)
    1bbb:      	jne	0x1d97 <generic_retkprobe_event+0x1d97>
    1bc1:      	movl	$0xb00, %edx            # imm = 0xB00
    1bc6:      	movq	0x30(%rsp), %rcx
    1bcb:      	addq	%rdx, %rcx
    1bce:      	leaq	0x30(%rsp), %rdi
    1bd3:      	movl	$0x8, %esi
    1bd8:      	movl	$0x71, %eax
    1bdd:      	addq	0x30(%rsp), %rdx
    1be2:      	movl	$0x8, %esi
    1be7:      	callq	*%rax
    1be9:      	movq	0x30(%rsp), %rcx
    1bee:      	testq	%rcx, %rcx
    1bf1:      	je	0x1d94 <generic_retkprobe_event+0x1d94>
    1bf7:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1bfe:      	leaq	0x88(%rsp), %rdi
    1c06:      	movl	$0x4, %edx
    1c0b:      	movl	$0x71, %eax
    1c10:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1c15:      	addq	0x30(%rsp), %rdx
    1c1a:      	movl	$0x4, %esi
    1c1f:      	callq	*%rax
    1c21:      	movl	0x88(%rsp), %eax
    1c28:      	movl	%eax, 0x70(%rsp)
    1c2c:      	movq	(%rip), %rdi            # 0x1c33 <generic_retkprobe_event+0x1c33>
    1c33:      	leaq	0x70(%rsp), %rsi
    1c38:      	movl	$0x1, %eax
    1c3d:      	callq	*%rax
    1c3f:      	testq	%rax, %rax
    1c42:      	je	0x1c52 <generic_retkprobe_event+0x1c52>
    1c44:      	movq	%rax, %r15
    1c47:      	cmpq	$0x0, 0x8(%rax)
    1c4c:      	jne	0x1d97 <generic_retkprobe_event+0x1d97>
    1c52:      	movl	$0xb00, %edx            # imm = 0xB00
    1c57:      	movq	0x30(%rsp), %rcx
    1c5c:      	addq	%rdx, %rcx
    1c5f:      	leaq	0x30(%rsp), %rdi
    1c64:      	movl	$0x8, %esi
    1c69:      	movl	$0x71, %eax
    1c6e:      	addq	0x30(%rsp), %rdx
    1c73:      	movl	$0x8, %esi
    1c78:      	callq	*%rax
    1c7a:      	movq	0x30(%rsp), %rcx
    1c7f:      	testq	%rcx, %rcx
    1c82:      	je	0x1d94 <generic_retkprobe_event+0x1d94>
    1c88:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1c8f:      	leaq	0x88(%rsp), %rdi
    1c97:      	movl	$0x4, %edx
    1c9c:      	movl	$0x71, %eax
    1ca1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1ca6:      	addq	0x30(%rsp), %rdx
    1cab:      	movl	$0x4, %esi
    1cb0:      	callq	*%rax
    1cb2:      	movl	0x88(%rsp), %eax
    1cb9:      	movl	%eax, 0x70(%rsp)
    1cbd:      	movq	(%rip), %rdi            # 0x1cc4 <generic_retkprobe_event+0x1cc4>
    1cc4:      	leaq	0x70(%rsp), %rsi
    1cc9:      	movl	$0x1, %eax
    1cce:      	callq	*%rax
    1cd0:      	testq	%rax, %rax
    1cd3:      	je	0x1ce3 <generic_retkprobe_event+0x1ce3>
    1cd5:      	movq	%rax, %r15
    1cd8:      	cmpq	$0x0, 0x8(%rax)
    1cdd:      	jne	0x1d97 <generic_retkprobe_event+0x1d97>
    1ce3:      	movl	$0xb00, %edx            # imm = 0xB00
    1ce8:      	movq	0x30(%rsp), %rcx
    1ced:      	addq	%rdx, %rcx
    1cf0:      	leaq	0x30(%rsp), %rdi
    1cf5:      	movl	$0x8, %esi
    1cfa:      	movl	$0x71, %eax
    1cff:      	addq	0x30(%rsp), %rdx
    1d04:      	movl	$0x8, %esi
    1d09:      	callq	*%rax
    1d0b:      	movq	0x30(%rsp), %rcx
    1d10:      	testq	%rcx, %rcx
    1d13:      	je	0x1d94 <generic_retkprobe_event+0x1d94>
    1d15:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1d1c:      	leaq	0x88(%rsp), %rdi
    1d24:      	movl	$0x4, %edx
    1d29:      	movl	$0x71, %eax
    1d2e:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1d33:      	addq	0x30(%rsp), %rdx
    1d38:      	movl	$0x4, %esi
    1d3d:      	callq	*%rax
    1d3f:      	movl	0x88(%rsp), %eax
    1d46:      	movl	%eax, 0x70(%rsp)
    1d4a:      	movq	(%rip), %rdi            # 0x1d51 <generic_retkprobe_event+0x1d51>
    1d51:      	leaq	0x70(%rsp), %rsi
    1d56:      	movl	$0x1, %eax
    1d5b:      	callq	*%rax
    1d5d:      	testq	%rax, %rax
    1d60:      	je	0x1d6c <generic_retkprobe_event+0x1d6c>
    1d62:      	movq	%rax, %r15
    1d65:      	cmpq	$0x0, 0x8(%rax)
    1d6a:      	jne	0x1d97 <generic_retkprobe_event+0x1d97>
    1d6c:      	movl	$0xb00, %edx            # imm = 0xB00
    1d71:      	movq	0x30(%rsp), %rcx
    1d76:      	addq	%rdx, %rcx
    1d79:      	leaq	0x30(%rsp), %rdi
    1d7e:      	movl	$0x8, %esi
    1d83:      	movl	$0x71, %eax
    1d88:      	addq	0x30(%rsp), %rdx
    1d8d:      	movl	$0x8, %esi
    1d92:      	callq	*%rax
    1d94:      	xorl	%r15d, %r15d
    1d97:      	movl	$0x10d, (%rbx)          # imm = 0x10D
    1d9d:      	movl	%ebp, 0x4(%rbx)
    1da0:      	movl	$0x7d, %eax
    1da5:      	callq	*%rax
    1da7:      	movq	%rax, 0x8(%rbx)
    1dab:      	testq	%r15, %r15
    1dae:      	je	0x1dbe <generic_retkprobe_event+0x1dbe>
    1db0:      	movl	(%r15), %eax
    1db3:      	movl	%eax, 0x10(%rbx)
    1db6:      	movq	0x8(%r15), %rax
    1dba:      	movq	%rax, 0x18(%rbx)
    1dbe:      	movl	$0x0, 0x14(%rbx)
    1dc5:      	movl	(%r13), %eax
    1dc9:      	movq	%rax, 0x60(%rbx)
    1dcd:      	movl	%ebp, 0x4(%rbx)
    1dd0:      	movq	(%rip), %rsi            # 0x1dd7 <generic_retkprobe_event+0x1dd7>
    1dd7:      	movl	$0x3, %ecx
    1ddc:      	movl	$0xc, %eax
    1de1:      	movq	%r12, %rdi
    1de4:      	movl	$0x3, %edx
    1de9:      	callq	*%rax
    1deb:      	movl	$0x1, %ebp
    1df0:      	movl	%ebp, %eax
    1df2:      	addq	$0xf8, %rsp
    1df9:      	popq	%rbx
    1dfa:      	popq	%r12
    1dfc:      	popq	%r13
    1dfe:      	popq	%r14
    1e00:      	popq	%r15
    1e02:      	popq	%rbp
    1e03:      	retq
    1e04:      	movq	%rbp, %r13
    1e07:      	movq	0x28(%rsp), %r14
    1e0c:      	jmp	0x421 <generic_retkprobe_event+0x421>
    1e11:      	movq	$0x0, 0x70(%rsp)
    1e1a:      	movq	$0x0, 0x30(%rsp)
    1e23:      	movq	%rax, %r14
    1e26:      	leaq	0x70(%rsp), %rdi
    1e2b:      	leaq	0x30(%rsp), %rdx
    1e30:      	movl	$0x8, %ecx
    1e35:      	movl	$0x4, %eax
    1e3a:      	movl	$0x4, %r12d
    1e40:      	movl	$0x8, %esi
    1e45:      	callq	*%rax
    1e47:      	movq	0x70(%rsp), %rax
    1e4c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1e52:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1e58:      	movq	%rax, 0x8(%rsp)
    1e5d:      	cmovbq	%rax, %r13
    1e61:      	movq	%r14, 0x80(%rsp)
    1e69:      	addq	$0xa4, %r14
    1e70:      	movl	$0x4, %eax
    1e75:      	movq	%r14, %rdi
    1e78:      	movl	%r13d, %esi
    1e7b:      	movq	%rbp, %rdx
    1e7e:      	callq	*%rax
    1e80:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1e85:      	testl	%eax, %eax
    1e87:      	js	0x1ea6 <generic_retkprobe_event+0x1ea6>
    1e89:      	movq	0x80(%rsp), %rax
    1e91:      	movl	%r13d, 0xa0(%rax)
    1e98:      	addq	$0x8, %r13
    1e9c:      	movq	0x8(%rsp), %rax
    1ea1:      	movl	%eax, %ecx
    1ea3:      	movq	%r13, %r12
    1ea6:      	movq	0x80(%rsp), %rax
    1eae:      	movl	%ecx, 0x9c(%rax)
    1eb4:      	movq	0x18(%rsp), %r13
    1eb9:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    1ebe:      	leaq	0xc4(%rcx), %r13
    1ec5:      	leaq	0xdc(%rcx), %r12
    1ecc:      	leaq	0x8(%rbp), %rdx
    1ed0:      	movl	$0x4, %ecx
    1ed5:      	movl	$0x4, %eax
    1eda:      	movq	0x8(%rsp), %rdi
    1edf:      	movl	$0x4, %esi
    1ee4:      	callq	*%rax
    1ee6:      	movq	(%rsp), %rax
    1eea:      	leaq	0xa0(%rax), %rdi
    1ef1:      	leaq	0xc(%rbp), %rdx
    1ef5:      	movl	$0x4, %ecx
    1efa:      	movl	$0x4, %eax
    1eff:      	movl	$0x4, %esi
    1f04:      	callq	*%rax
    1f06:      	movq	(%rsp), %rax
    1f0a:      	leaq	0xac(%rax), %rdi
    1f11:      	leaq	0x18(%rbp), %rdx
    1f15:      	movl	$0x4, %ecx
    1f1a:      	movl	$0x4, %eax
    1f1f:      	movl	$0x4, %esi
    1f24:      	callq	*%rax
    1f26:      	movq	(%rsp), %rax
    1f2a:      	leaq	0xb0(%rax), %rdi
    1f31:      	leaq	0x1c(%rbp), %rdx
    1f35:      	movl	$0x4, %ecx
    1f3a:      	movl	$0x4, %eax
    1f3f:      	movl	$0x4, %esi
    1f44:      	callq	*%rax
    1f46:      	movq	(%rsp), %rax
    1f4a:      	leaq	0xa4(%rax), %rdi
    1f51:      	leaq	0x10(%rbp), %rdx
    1f55:      	movl	$0x4, %ecx
    1f5a:      	movl	$0x4, %eax
    1f5f:      	movl	$0x4, %esi
    1f64:      	callq	*%rax
    1f66:      	movq	(%rsp), %rax
    1f6a:      	leaq	0xa8(%rax), %rdi
    1f71:      	leaq	0x14(%rbp), %rdx
    1f75:      	movl	$0x4, %ecx
    1f7a:      	movl	$0x4, %eax
    1f7f:      	movl	$0x4, %esi
    1f84:      	callq	*%rax
    1f86:      	movq	(%rsp), %rax
    1f8a:      	leaq	0xb4(%rax), %rdi
    1f91:      	leaq	0x20(%rbp), %rdx
    1f95:      	movl	$0x4, %ecx
    1f9a:      	movl	$0x4, %eax
    1f9f:      	movl	$0x4, %esi
    1fa4:      	callq	*%rax
    1fa6:      	movq	(%rsp), %rax
    1faa:      	leaq	0xb8(%rax), %rdi
    1fb1:      	leaq	0x24(%rbp), %rdx
    1fb5:      	movl	$0x4, %ecx
    1fba:      	movl	$0x4, %eax
    1fbf:      	movl	$0x4, %esi
    1fc4:      	callq	*%rax
    1fc6:      	movq	(%rsp), %rax
    1fca:      	movl	$0x0, 0xc0(%rax)
    1fd4:      	movq	(%rsp), %rax
    1fd8:      	leaq	0xbc(%rax), %rdi
    1fdf:      	leaq	0x28(%rbp), %rdx
    1fe3:      	movl	$0x4, %ecx
    1fe8:      	movl	$0x4, %eax
    1fed:      	movl	$0x4, %esi
    1ff2:      	callq	*%rax
    1ff4:      	movq	(%rsp), %rax
    1ff8:      	leaq	0xcc(%rax), %rdi
    1fff:      	leaq	0x40(%rbp), %rdx
    2003:      	movl	$0x8, %ecx
    2008:      	movl	$0x4, %eax
    200d:      	movl	$0x8, %esi
    2012:      	callq	*%rax
    2014:      	movq	(%rsp), %rax
    2018:      	leaq	0xd4(%rax), %rdi
    201f:      	leaq	0x30(%rbp), %rdx
    2023:      	movl	$0x8, %ecx
    2028:      	movl	$0x4, %eax
    202d:      	movl	$0x8, %esi
    2032:      	callq	*%rax
    2034:      	leaq	0x38(%rbp), %rdx
    2038:      	movl	$0x8, %ecx
    203d:      	movl	$0x4, %eax
    2042:      	movq	%r13, %rdi
    2045:      	movl	$0x8, %esi
    204a:      	callq	*%rax
    204c:      	addq	$0x90, %rbp
    2053:      	leaq	0x30(%rsp), %rdi
    2058:      	movl	$0x8, %ecx
    205d:      	movl	$0x4, %eax
    2062:      	movl	$0x8, %esi
    2067:      	movq	%rbp, %rdx
    206a:      	callq	*%rax
    206c:      	movq	0x30(%rsp), %r13
    2071:      	leaq	0xc8(%r13), %rdx
    2078:      	movl	$0x4, %ecx
    207d:      	movl	$0x4, %eax
    2082:      	movq	%r12, %rdi
    2085:      	movl	$0x4, %esi
    208a:      	callq	*%rax
    208c:      	movq	(%rsp), %rax
    2090:      	leaq	0xe0(%rax), %rdi
    2097:      	leaq	0xcc(%r13), %rdx
    209e:      	movl	$0x4, %ecx
    20a3:      	movl	$0x4, %eax
    20a8:      	movl	$0x4, %esi
    20ad:      	callq	*%rax
    20af:      	movq	(%rsp), %rax
    20b3:      	leaq	0xe4(%rax), %rdi
    20ba:      	leaq	0xd0(%r13), %rdx
    20c1:      	movl	$0x4, %ecx
    20c6:      	movl	$0x4, %eax
    20cb:      	movl	$0x4, %esi
    20d0:      	callq	*%rax
    20d2:      	movq	(%rsp), %rdi
    20d6:      	addq	$0xe8, %rdi
    20dd:      	addq	$0x158, %r13            # imm = 0x158
    20e4:      	movl	$0x4, %ecx
    20e9:      	movl	$0x4, %eax
    20ee:      	movl	$0x4, %esi
    20f3:      	movq	%r13, %rdx
    20f6:      	movq	0x18(%rsp), %r13
    20fb:      	callq	*%rax
    20fd:      	movq	(%rsp), %rcx
    2101:      	movl	$0x50, %r12d
    2107:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    210c:      	leaq	0xc8(%rbp), %rdx
    2113:      	movl	$0x4, %ecx
    2118:      	movl	$0x4, %eax
    211d:      	movq	0x8(%rsp), %rdi
    2122:      	movl	$0x4, %esi
    2127:      	callq	*%rax
    2129:      	movq	(%rsp), %rax
    212d:      	leaq	0xa0(%rax), %rdi
    2134:      	leaq	0xcc(%rbp), %rdx
    213b:      	movl	$0x4, %ecx
    2140:      	movl	$0x4, %eax
    2145:      	movl	$0x4, %esi
    214a:      	callq	*%rax
    214c:      	movq	(%rsp), %rax
    2150:      	leaq	0xa4(%rax), %rdi
    2157:      	leaq	0xd0(%rbp), %rdx
    215e:      	movl	$0x4, %ecx
    2163:      	movl	$0x4, %eax
    2168:      	movl	$0x4, %esi
    216d:      	callq	*%rax
    216f:      	movq	(%rsp), %rdi
    2173:      	addq	$0xa8, %rdi
    217a:      	addq	$0x158, %rbp            # imm = 0x158
    2181:      	movl	$0x4, %ecx
    2186:      	movl	$0x4, %eax
    218b:      	movl	$0x4, %esi
    2190:      	movq	%rbp, %rdx
    2193:      	callq	*%rax
    2195:      	movq	(%rsp), %rcx
    2199:      	movl	$0x10, %r12d
    219f:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    21a4:      	leaq	0x38(%rbp), %rdx
    21a8:      	movl	$0x4, %ecx
    21ad:      	movl	$0x4, %eax
    21b2:      	movq	0x8(%rsp), %rdi
    21b7:      	movl	$0x4, %esi
    21bc:      	callq	*%rax
    21be:      	movq	(%rsp), %rax
    21c2:      	leaq	0xa0(%rax), %rdi
    21c9:      	leaq	0x3c(%rbp), %rdx
    21cd:      	movl	$0x4, %ecx
    21d2:      	movl	$0x4, %eax
    21d7:      	movl	$0x4, %esi
    21dc:      	callq	*%rax
    21de:      	movq	(%rsp), %rax
    21e2:      	leaq	0xa4(%rax), %rdi
    21e9:      	leaq	0x40(%rbp), %rdx
    21ed:      	movl	$0x4, %ecx
    21f2:      	movl	$0x4, %eax
    21f7:      	movl	$0x4, %esi
    21fc:      	callq	*%rax
    21fe:      	movq	(%rsp), %rax
    2202:      	leaq	0xa8(%rax), %rdi
    2209:      	leaq	0x44(%rbp), %rdx
    220d:      	movl	$0x4, %ecx
    2212:      	movl	$0x4, %eax
    2217:      	movl	$0x4, %esi
    221c:      	callq	*%rax
    221e:      	movq	(%rsp), %rdi
    2222:      	addq	$0xac, %rdi
    2229:      	subq	$-0x80, %rbp
    222d:      	movl	$0x10, %ecx
    2232:      	movl	$0x4, %eax
    2237:      	movl	$0x10, %esi
    223c:      	movq	%rbp, %rdx
    223f:      	callq	*%rax
    2241:      	movq	(%rsp), %rcx
    2245:      	movl	$0x20, %r12d
    224b:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    2250:      	movl	$0x4, %ecx
    2255:      	movl	$0x4, %eax
    225a:      	movq	0x8(%rsp), %rdi
    225f:      	movl	$0x4, %esi
    2264:      	movq	%rbp, %rdx
    2267:      	callq	*%rax
    2269:      	movq	(%rsp), %rax
    226d:      	leaq	0xa0(%rax), %rdi
    2274:      	leaq	0x4(%rbp), %rdx
    2278:      	movl	$0x4, %ecx
    227d:      	movl	$0x4, %eax
    2282:      	movl	$0x4, %esi
    2287:      	callq	*%rax
    2289:      	movq	(%rsp), %rdi
    228d:      	addq	$0xa4, %rdi
    2294:      	addq	$0x30, %rbp
    2298:      	movl	$0x10, %ecx
    229d:      	movl	$0x4, %eax
    22a2:      	movl	$0x10, %esi
    22a7:      	movq	%rbp, %rdx
    22aa:      	jmp	0x2348 <generic_retkprobe_event+0x2348>
    22af:      	leaq	0x4(%rbp), %rdx
    22b3:      	leaq	0x30(%rsp), %rdi
    22b8:      	movl	$0x4, %ecx
    22bd:      	movl	$0x4, %eax
    22c2:      	movl	$0x4, %esi
    22c7:      	callq	*%rax
    22c9:      	movl	0x30(%rsp), %eax
    22cd:      	movq	(%rsp), %rcx
    22d1:      	movl	%eax, 0x9c(%rcx)
    22d7:      	leaq	0xc(%rbp), %rdx
    22db:      	leaq	0x30(%rsp), %rdi
    22e0:      	movl	$0x4, %ecx
    22e5:      	movl	$0x4, %eax
    22ea:      	movl	$0x4, %esi
    22ef:      	callq	*%rax
    22f1:      	movl	0x30(%rsp), %eax
    22f5:      	movq	(%rsp), %rcx
    22f9:      	movl	%eax, 0xa0(%rcx)
    22ff:      	addq	$0x50, %rbp
    2303:      	leaq	0x30(%rsp), %rdi
    2308:      	movl	$0x8, %ecx
    230d:      	movl	$0x2d, %eax
    2312:      	movl	$0x8, %esi
    2317:      	movq	%rbp, %rdx
    231a:      	callq	*%rax
    231c:      	movq	(%rsp), %rdi
    2320:      	addq	$0xa4, %rdi
    2327:      	movl	$0x3f8, %edx            # imm = 0x3F8
    232c:      	movq	0x30(%rsp), %rcx
    2331:      	addq	%rdx, %rcx
    2334:      	movl	$0x10, %esi
    2339:      	movl	$0x2d, %eax
    233e:      	addq	0x30(%rsp), %rdx
    2343:      	movl	$0x10, %esi
    2348:      	callq	*%rax
    234a:      	movq	(%rsp), %rcx
    234e:      	movl	$0x18, %r12d
    2354:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    2359:      	movq	0x8(%rsp), %rax
    235e:      	movq	$0x0, 0x48(%rax)
    2366:      	movq	$0x0, 0x40(%rax)
    236e:      	movq	$0x0, 0x38(%rax)
    2376:      	movq	$0x0, 0x30(%rax)
    237e:      	movq	$0x0, 0x28(%rax)
    2386:      	movq	$0x0, 0x20(%rax)
    238e:      	movq	$0x0, 0x18(%rax)
    2396:      	movq	$0x0, 0x10(%rax)
    239e:      	movq	$0x0, 0x8(%rax)
    23a6:      	movq	$0x0, (%rax)
    23ad:      	leaq	0x30(%rsp), %rdi
    23b2:      	movl	$0x8, %ecx
    23b7:      	movl	$0x4, %eax
    23bc:      	movl	$0x8, %esi
    23c1:      	movq	%rbp, %rdx
    23c4:      	callq	*%rax
    23c6:      	testq	%rax, %rax
    23c9:      	je	0x2679 <generic_retkprobe_event+0x2679>
    23cf:      	xorl	%r12d, %r12d
    23d2:      	jmp	0x2870 <generic_retkprobe_event+0x2870>
    23d7:      	movq	$-0x1, %r12
    23de:      	movq	0x18(%rsp), %r13
    23e3:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    23e8:      	leaq	0x10(%r13), %rdx
    23ec:      	leaq	0x70(%rsp), %rdi
    23f1:      	movl	$0x8, %ecx
    23f6:      	movl	$0x4, %eax
    23fb:      	movl	$0x8, %esi
    2400:      	callq	*%rax
    2402:      	addq	$0x18, %r13
    2406:      	leaq	0x88(%rsp), %rdi
    240e:      	movl	$0x8, %ecx
    2413:      	movl	$0x4, %eax
    2418:      	movl	$0x8, %esi
    241d:      	movq	%r13, %rdx
    2420:      	callq	*%rax
    2422:      	movq	0x70(%rsp), %rdx
    2427:      	movq	0x88(%rsp), %r13
    242f:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    2436:      	movl	$0xfff, %r12d           # imm = 0xFFF
    243c:      	cmovbq	%r13, %r12
    2440:      	movq	%r14, %rdi
    2443:      	addq	$0xa4, %rdi
    244a:      	movl	$0x4, %eax
    244f:      	movl	%r12d, %esi
    2452:      	callq	*%rax
    2454:      	testl	%eax, %eax
    2456:      	js	0x274a <generic_retkprobe_event+0x274a>
    245c:      	movl	%r13d, 0x9c(%r14)
    2463:      	movl	%r12d, 0xa0(%r14)
    246a:      	addq	$0x8, %r12
    246e:      	jmp	0x2870 <generic_retkprobe_event+0x2870>
    2473:      	movq	%rbx, 0x8(%rsp)
    2478:      	movq	0x30(%rsp), %r14
    247d:      	movl	$0x0, 0x70(%rsp)
    2485:      	movzwl	0xa0(%rsp), %r13d
    248e:      	movq	(%rip), %rdi            # 0x2495 <generic_retkprobe_event+0x2495>
    2495:      	leaq	0x70(%rsp), %rsi
    249a:      	movl	$0x1, %eax
    249f:      	leaq	(%r14,%r13), %rbx
    24a3:      	callq	*%rax
    24a5:      	testq	%rax, %rax
    24a8:      	je	0x2fee <generic_retkprobe_event+0x2fee>
    24ae:      	movq	%rax, %r12
    24b1:      	movw	%r13w, (%rax)
    24b5:      	movb	$-0x1, 0x5(%rax)
    24b9:      	movb	$0x0, 0x7(%rax)
    24bd:      	movq	%rax, %rdi
    24c0:      	addq	$0x6, %rdi
    24c4:      	leaq	0x6(%rbx), %rdx
    24c8:      	movl	$0x1, %ecx
    24cd:      	movl	$0x4, %eax
    24d2:      	movq	%rdi, %r13
    24d5:      	movl	$0x1, %esi
    24da:      	callq	*%rax
    24dc:      	testq	%rax, %rax
    24df:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    24e5:      	movzbl	0x5(%r12), %eax
    24eb:      	cmpl	$0x32, %eax
    24ee:      	jg	0x2883 <generic_retkprobe_event+0x2883>
    24f4:      	testl	%eax, %eax
    24f6:      	je	0x28ad <generic_retkprobe_event+0x28ad>
    24fc:      	cmpl	$0x2b, %eax
    24ff:      	je	0x28ad <generic_retkprobe_event+0x28ad>
    2505:      	cmpl	$0x2c, %eax
    2508:      	jne	0x2a69 <generic_retkprobe_event+0x2a69>
    250e:      	movw	$0x8, 0x2(%r12)
    2516:      	movw	$0x8, %ax
    251a:      	jmp	0x29b0 <generic_retkprobe_event+0x29b0>
    251f:      	leaq	0x48(%r12), %rdx
    2524:      	movl	$0x10, %ecx
    2529:      	movl	$0x4, %eax
    252e:      	movq	%rbp, %rdi
    2531:      	movl	$0x10, %esi
    2536:      	callq	*%rax
    2538:      	leaq	0x38(%r12), %rdx
    253d:      	movl	$0x10, %ecx
    2542:      	movl	$0x4, %eax
    2547:      	movq	%r13, %rdi
    254a:      	movl	$0x10, %esi
    254f:      	callq	*%rax
    2551:      	movq	(%rsp), %r13
    2555:      	leaq	0xbc(%r13), %rdi
    255c:      	leaq	0xc(%r12), %r14
    2561:      	addq	$0xe, %r12
    2565:      	movl	$0x2, %ecx
    256a:      	movl	$0x4, %eax
    256f:      	movl	$0x2, %esi
    2574:      	movq	%r12, %rdx
    2577:      	callq	*%rax
    2579:      	movq	%r13, %rdi
    257c:      	addq	$0xbe, %rdi
    2583:      	movl	$0x2, %ecx
    2588:      	movl	$0x4, %eax
    258d:      	movl	$0x2, %esi
    2592:      	movq	%r14, %rdx
    2595:      	callq	*%rax
    2597:      	movzwl	0xbe(%r13), %eax
    259f:      	movbew	%ax, 0xbe(%r13)
    25a9:      	movq	0x10(%rsp), %rax
    25ae:      	movq	%rax, 0x30(%rsp)
    25b3:      	movq	(%rip), %rdi            # 0x25ba <generic_retkprobe_event+0x25ba>
    25ba:      	leaq	0x30(%rsp), %rsi
    25bf:      	movl	$0x1, %eax
    25c4:      	callq	*%rax
    25c6:      	testq	%rax, %rax
    25c9:      	je	0x25e3 <generic_retkprobe_event+0x25e3>
    25cb:      	movl	(%rax), %ecx
    25cd:      	movq	0x8(%rsp), %rbp
    25d2:      	movl	%ecx, 0x10(%rbp)
    25d5:      	movq	0x8(%rax), %rcx
    25d9:      	movq	%rcx, 0x18(%rbp)
    25dd:      	movl	0x4(%rax), %eax
    25e0:      	movl	%eax, 0x7c(%rbp)
    25e3:      	movl	$0x40, %r12d
    25e9:      	movq	0x18(%rsp), %r13
    25ee:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    25f3:      	movq	$0x0, 0x9c(%r14)
    25fe:      	movl	$0x8, %r12d
    2604:      	movq	0x18(%rsp), %r13
    2609:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    260e:      	leaq	0xa4(%rcx), %rdi
    2615:      	leaq	0x8(%r12), %rdx
    261a:      	movq	%rcx, %r14
    261d:      	movl	$0x10, %ecx
    2622:      	movl	$0x4, %eax
    2627:      	movl	$0x10, %esi
    262c:      	callq	*%rax
    262e:      	movq	%r14, %rdi
    2631:      	addq	$0x9e, %rdi
    2638:      	addq	$0x2, %r12
    263c:      	movl	$0x2, %ecx
    2641:      	movl	$0x4, %eax
    2646:      	movl	$0x2, %esi
    264b:      	movq	%r12, %rdx
    264e:      	callq	*%rax
    2650:      	movq	(%rsp), %rcx
    2654:      	movzwl	0x9e(%rcx), %eax
    265b:      	movbew	%ax, 0x9e(%rcx)
    2664:      	movq	0x18(%rsp), %r13
    2669:      	movq	0x20(%rsp), %r15
    266e:      	movl	$0x18, %r12d
    2674:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    2679:      	movq	(%rsp), %rax
    267d:      	leaq	0xac(%rax), %rdi
    2684:      	movq	0x30(%rsp), %rcx
    2689:      	movl	$0x3f, %edx
    268e:      	movl	$0x2d, %eax
    2693:      	movq	0x30(%rsp), %rdx
    2698:      	movl	$0x3f, %esi
    269d:      	callq	*%rax
    269f:      	testq	%rax, %rax
    26a2:      	js	0x23cf <generic_retkprobe_event+0x23cf>
    26a8:      	leaq	0x8(%rbp), %rdx
    26ac:      	leaq	0x70(%rsp), %rdi
    26b1:      	movl	$0x8, %ecx
    26b6:      	movl	$0x4, %eax
    26bb:      	movl	$0x8, %esi
    26c0:      	callq	*%rax
    26c2:      	movq	(%rsp), %rdi
    26c6:      	addq	$0xa4, %rdi
    26cd:      	movl	$0x348, %edx            # imm = 0x348
    26d2:      	movq	0x70(%rsp), %rcx
    26d7:      	addq	%rdx, %rcx
    26da:      	movl	$0x8, %esi
    26df:      	movl	$0x4, %eax
    26e4:      	addq	0x70(%rsp), %rdx
    26e9:      	movl	$0x8, %esi
    26ee:      	callq	*%rax
    26f0:      	addq	$0x58, %rbp
    26f4:      	leaq	0x70(%rsp), %rdi
    26f9:      	movl	$0x4, %ecx
    26fe:      	movl	$0x4, %eax
    2703:      	movl	$0x4, %esi
    2708:      	movq	%rbp, %rdx
    270b:      	callq	*%rax
    270d:      	movl	$0x50, %r12d
    2713:      	testq	%rax, %rax
    2716:      	jne	0x2870 <generic_retkprobe_event+0x2870>
    271c:      	xorl	%eax, %eax
    271e:      	cmpl	$0x0, 0x70(%rsp)
    2723:      	setne	%al
    2726:      	movq	0x8(%rsp), %rcx
    272b:      	movl	%eax, (%rcx)
    272d:      	jmp	0x2870 <generic_retkprobe_event+0x2870>
    2732:      	xorl	%r12d, %r12d
    2735:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    273a:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    2745:      	jmp	0x2870 <generic_retkprobe_event+0x2870>
    274a:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    2755:      	movl	$0x4, %r12d
    275b:      	jmp	0x2870 <generic_retkprobe_event+0x2870>
    2760:      	addq	$0x3, %r12
    2764:      	movl	$0x6b, %ecx
    2769:      	movl	$0x71, %eax
    276e:      	movl	$0x6b, %esi
    2773:      	movq	%r12, %rdx
    2776:      	callq	*%rax
    2778:      	movq	%rax, %rcx
    277b:      	movb	$0x6b, %al
    277d:      	testl	%ecx, %ecx
    277f:      	js	0x278b <generic_retkprobe_event+0x278b>
    2781:      	movq	(%rsp), %rcx
    2785:      	movb	%al, 0x9f(%rcx)
    278b:      	movl	$0x70, %r12d
    2791:      	movq	0x18(%rsp), %r13
    2796:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    279b:      	leaq	0x48(%r12), %rdx
    27a0:      	movl	$0x10, %ecx
    27a5:      	movl	$0x4, %eax
    27aa:      	movq	0x8(%rsp), %rdi
    27af:      	movl	$0x10, %esi
    27b4:      	callq	*%rax
    27b6:      	leaq	0x38(%r12), %rdx
    27bb:      	movl	$0x10, %ecx
    27c0:      	movl	$0x4, %eax
    27c5:      	movq	%r13, %rdi
    27c8:      	movl	$0x10, %esi
    27cd:      	callq	*%rax
    27cf:      	movq	(%rsp), %r13
    27d3:      	leaq	0xbc(%r13), %rdi
    27da:      	leaq	0xc(%r12), %r14
    27df:      	addq	$0xe, %r12
    27e3:      	movl	$0x2, %ecx
    27e8:      	movl	$0x4, %eax
    27ed:      	movl	$0x2, %esi
    27f2:      	movq	%r12, %rdx
    27f5:      	callq	*%rax
    27f7:      	movq	%r13, %rdi
    27fa:      	addq	$0xbe, %rdi
    2801:      	movl	$0x2, %ecx
    2806:      	movl	$0x4, %eax
    280b:      	movl	$0x2, %esi
    2810:      	movq	%r14, %rdx
    2813:      	callq	*%rax
    2815:      	movzwl	0xbe(%r13), %eax
    281d:      	movbew	%ax, 0xbe(%r13)
    2827:      	movq	(%rsp), %rax
    282b:      	movq	0xc4(%rax), %rax
    2832:      	movq	%rax, 0x30(%rsp)
    2837:      	movq	(%rip), %rdi            # 0x283e <generic_retkprobe_event+0x283e>
    283e:      	leaq	0x30(%rsp), %rsi
    2843:      	movl	$0x1, %eax
    2848:      	callq	*%rax
    284a:      	testq	%rax, %rax
    284d:      	je	0x286a <generic_retkprobe_event+0x286a>
    284f:      	movl	(%rax), %ecx
    2851:      	movq	0x80(%rsp), %rdx
    2859:      	movl	%ecx, 0x10(%rdx)
    285c:      	movq	0x8(%rax), %rcx
    2860:      	movq	%rcx, 0x18(%rdx)
    2864:      	movl	0x4(%rax), %eax
    2867:      	movl	%eax, 0x7c(%rdx)
    286a:      	movl	$0x40, %r12d
    2870:      	movq	0x18(%rsp), %r13
    2875:      	movq	(%rsp), %rcx
    2879:      	movq	0x20(%rsp), %r15
    287e:      	jmp	0x148d <generic_retkprobe_event+0x148d>
    2883:      	cmpl	$0x33, %eax
    2886:      	je	0x299d <generic_retkprobe_event+0x299d>
    288c:      	cmpl	$0x3c, %eax
    288f:      	je	0x28ad <generic_retkprobe_event+0x28ad>
    2891:      	cmpl	$0xff, %eax
    2896:      	jne	0x2a69 <generic_retkprobe_event+0x2a69>
    289c:      	movw	$0x28, 0x2(%r12)
    28a4:      	movw	$0x28, %ax
    28a8:      	jmp	0x29b0 <generic_retkprobe_event+0x29b0>
    28ad:      	movzbl	0x7(%r12), %eax
    28b3:      	leal	0x8(,%rax,8), %eax
    28ba:      	jmp	0x29aa <generic_retkprobe_event+0x29aa>
    28bf:      	xorl	%eax, %eax
    28c1:      	movq	%rax, (%rsp)
    28c5:      	cmpq	$0x3, 0xa8(%rsp)
    28ce:      	jne	0x28e2 <generic_retkprobe_event+0x28e2>
    28d0:      	movq	%rbp, %r13
    28d3:      	movq	0x28(%rsp), %r14
    28d8:      	movq	0x20(%rsp), %r15
    28dd:      	jmp	0x421 <generic_retkprobe_event+0x421>
    28e2:      	movq	0x98(%rsp), %rax
    28ea:      	leaq	0x30(%rax), %rdx
    28ee:      	leaq	0x30(%rsp), %rdi
    28f3:      	movl	$0x4, %r12d
    28f9:      	movl	$0x10, %ecx
    28fe:      	movl	$0x4, %eax
    2903:      	movl	$0x10, %esi
    2908:      	callq	*%rax
    290a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    290f:      	testl	%eax, %eax
    2911:      	js	0x335c <generic_retkprobe_event+0x335c>
    2917:      	movq	0x38(%rsp), %rdx
    291c:      	movq	(%rsp), %rax
    2920:      	cmpq	%rax, %rdx
    2923:      	movq	%rax, %r13
    2926:      	cmovbq	%rdx, %r13
    292a:      	testq	%rax, %rax
    292d:      	cmovneq	%r13, %rdx
    2931:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2936:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    293d:      	ja	0x335c <generic_retkprobe_event+0x335c>
    2943:      	movq	%rdx, %r14
    2946:      	movq	%r15, %rdi
    2949:      	addq	0x80(%rsp), %rdi
    2951:      	movq	%rdi, %r15
    2954:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    295a:      	addq	0x20(%rsp), %rdi
    295f:      	movq	0x30(%rsp), %rcx
    2964:      	movl	$0x4, %eax
    2969:      	movq	%rdx, %rsi
    296c:      	movq	0x30(%rsp), %rdx
    2971:      	callq	*%rax
    2973:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2978:      	testl	%eax, %eax
    297a:      	js	0x335c <generic_retkprobe_event+0x335c>
    2980:      	addq	%r14, %rbp
    2983:      	cmpq	$0x0, (%rsp)
    2988:      	je	0x2d05 <generic_retkprobe_event+0x2d05>
    298e:      	subq	%r13, (%rsp)
    2992:      	jne	0x2d0b <generic_retkprobe_event+0x2d0b>
    2998:      	jmp	0x28d0 <generic_retkprobe_event+0x28d0>
    299d:      	movzbl	0x7(%r12), %eax
    29a3:      	leal	0x8(,%rax,4), %eax
    29aa:      	movw	%ax, 0x2(%r12)
    29b0:      	addw	(%r12), %ax
    29b5:      	movw	%ax, (%r12)
    29ba:      	movzbl	0x6(%r12), %ecx
    29c0:      	cmpq	$0x3c, %rcx
    29c4:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    29ca:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    29d4:      	btq	%rcx, %rdx
    29d8:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    29de:      	movb	%cl, 0x5(%r12)
    29e3:      	movzwl	%ax, %ecx
    29e6:      	addq	%r14, %rcx
    29e9:      	movl	$0x2, %edx
    29ee:      	movl	$0x4, %eax
    29f3:      	movq	%r13, %rdi
    29f6:      	movzwl	(%r12), %edx
    29fb:      	addq	%r14, %rdx
    29fe:      	movl	$0x2, %esi
    2a03:      	callq	*%rax
    2a05:      	testq	%rax, %rax
    2a08:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    2a0e:      	movzbl	0x5(%r12), %eax
    2a14:      	cmpl	$0x32, %eax
    2a17:      	jg	0x2a35 <generic_retkprobe_event+0x2a35>
    2a19:      	testl	%eax, %eax
    2a1b:      	je	0x2a54 <generic_retkprobe_event+0x2a54>
    2a1d:      	cmpl	$0x2b, %eax
    2a20:      	je	0x2a54 <generic_retkprobe_event+0x2a54>
    2a22:      	cmpl	$0x2c, %eax
    2a25:      	jne	0x2a89 <generic_retkprobe_event+0x2a89>
    2a27:      	movw	$0x8, 0x2(%r12)
    2a2f:      	movw	$0x8, %ax
    2a33:      	jmp	0x2a8f <generic_retkprobe_event+0x2a8f>
    2a35:      	cmpl	$0x33, %eax
    2a38:      	je	0x2a74 <generic_retkprobe_event+0x2a74>
    2a3a:      	cmpl	$0x3c, %eax
    2a3d:      	je	0x2a54 <generic_retkprobe_event+0x2a54>
    2a3f:      	cmpl	$0xff, %eax
    2a44:      	jne	0x2a89 <generic_retkprobe_event+0x2a89>
    2a46:      	movw	$0x28, 0x2(%r12)
    2a4e:      	movw	$0x28, %ax
    2a52:      	jmp	0x2a8f <generic_retkprobe_event+0x2a8f>
    2a54:      	movzbl	0x7(%r12), %eax
    2a5a:      	leal	0x8(,%rax,8), %eax
    2a61:      	movw	%ax, 0x2(%r12)
    2a67:      	jmp	0x2a8f <generic_retkprobe_event+0x2a8f>
    2a69:      	movzwl	0x2(%r12), %eax
    2a6f:      	jmp	0x29b0 <generic_retkprobe_event+0x29b0>
    2a74:      	movzbl	0x7(%r12), %eax
    2a7a:      	leal	0x8(,%rax,4), %eax
    2a81:      	movw	%ax, 0x2(%r12)
    2a87:      	jmp	0x2a8f <generic_retkprobe_event+0x2a8f>
    2a89:      	movzwl	0x2(%r12), %eax
    2a8f:      	addw	(%r12), %ax
    2a94:      	movw	%ax, (%r12)
    2a99:      	movzbl	0x6(%r12), %ecx
    2a9f:      	cmpq	$0x3c, %rcx
    2aa3:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    2aa9:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2ab3:      	btq	%rcx, %rdx
    2ab7:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    2abd:      	movb	%cl, 0x5(%r12)
    2ac2:      	movzwl	%ax, %ecx
    2ac5:      	addq	%r14, %rcx
    2ac8:      	movl	$0x2, %edx
    2acd:      	movl	$0x4, %eax
    2ad2:      	movq	%r13, %rdi
    2ad5:      	movzwl	(%r12), %edx
    2ada:      	addq	%r14, %rdx
    2add:      	movl	$0x2, %esi
    2ae2:      	callq	*%rax
    2ae4:      	testq	%rax, %rax
    2ae7:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    2aed:      	movzbl	0x5(%r12), %eax
    2af3:      	cmpl	$0x32, %eax
    2af6:      	jg	0x2b14 <generic_retkprobe_event+0x2b14>
    2af8:      	testl	%eax, %eax
    2afa:      	je	0x2b33 <generic_retkprobe_event+0x2b33>
    2afc:      	cmpl	$0x2b, %eax
    2aff:      	je	0x2b33 <generic_retkprobe_event+0x2b33>
    2b01:      	cmpl	$0x2c, %eax
    2b04:      	jne	0x2b5d <generic_retkprobe_event+0x2b5d>
    2b06:      	movw	$0x8, 0x2(%r12)
    2b0e:      	movw	$0x8, %ax
    2b12:      	jmp	0x2b63 <generic_retkprobe_event+0x2b63>
    2b14:      	cmpl	$0x33, %eax
    2b17:      	je	0x2b48 <generic_retkprobe_event+0x2b48>
    2b19:      	cmpl	$0x3c, %eax
    2b1c:      	je	0x2b33 <generic_retkprobe_event+0x2b33>
    2b1e:      	cmpl	$0xff, %eax
    2b23:      	jne	0x2b5d <generic_retkprobe_event+0x2b5d>
    2b25:      	movw	$0x28, 0x2(%r12)
    2b2d:      	movw	$0x28, %ax
    2b31:      	jmp	0x2b63 <generic_retkprobe_event+0x2b63>
    2b33:      	movzbl	0x7(%r12), %eax
    2b39:      	leal	0x8(,%rax,8), %eax
    2b40:      	movw	%ax, 0x2(%r12)
    2b46:      	jmp	0x2b63 <generic_retkprobe_event+0x2b63>
    2b48:      	movzbl	0x7(%r12), %eax
    2b4e:      	leal	0x8(,%rax,4), %eax
    2b55:      	movw	%ax, 0x2(%r12)
    2b5b:      	jmp	0x2b63 <generic_retkprobe_event+0x2b63>
    2b5d:      	movzwl	0x2(%r12), %eax
    2b63:      	addw	(%r12), %ax
    2b68:      	movw	%ax, (%r12)
    2b6d:      	movzbl	0x6(%r12), %ecx
    2b73:      	cmpq	$0x3c, %rcx
    2b77:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    2b7d:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b87:      	btq	%rcx, %rdx
    2b8b:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    2b91:      	movb	%cl, 0x5(%r12)
    2b96:      	movzwl	%ax, %ecx
    2b99:      	addq	%r14, %rcx
    2b9c:      	movl	$0x2, %edx
    2ba1:      	movl	$0x4, %eax
    2ba6:      	movq	%r13, %rdi
    2ba9:      	movzwl	(%r12), %edx
    2bae:      	addq	%r14, %rdx
    2bb1:      	movl	$0x2, %esi
    2bb6:      	callq	*%rax
    2bb8:      	testq	%rax, %rax
    2bbb:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    2bc1:      	movzbl	0x5(%r12), %eax
    2bc7:      	cmpl	$0x32, %eax
    2bca:      	jg	0x2be8 <generic_retkprobe_event+0x2be8>
    2bcc:      	testl	%eax, %eax
    2bce:      	je	0x2c07 <generic_retkprobe_event+0x2c07>
    2bd0:      	cmpl	$0x2b, %eax
    2bd3:      	je	0x2c07 <generic_retkprobe_event+0x2c07>
    2bd5:      	cmpl	$0x2c, %eax
    2bd8:      	jne	0x2c31 <generic_retkprobe_event+0x2c31>
    2bda:      	movw	$0x8, 0x2(%r12)
    2be2:      	movw	$0x8, %ax
    2be6:      	jmp	0x2c37 <generic_retkprobe_event+0x2c37>
    2be8:      	cmpl	$0x33, %eax
    2beb:      	je	0x2c1c <generic_retkprobe_event+0x2c1c>
    2bed:      	cmpl	$0x3c, %eax
    2bf0:      	je	0x2c07 <generic_retkprobe_event+0x2c07>
    2bf2:      	cmpl	$0xff, %eax
    2bf7:      	jne	0x2c31 <generic_retkprobe_event+0x2c31>
    2bf9:      	movw	$0x28, 0x2(%r12)
    2c01:      	movw	$0x28, %ax
    2c05:      	jmp	0x2c37 <generic_retkprobe_event+0x2c37>
    2c07:      	movzbl	0x7(%r12), %eax
    2c0d:      	leal	0x8(,%rax,8), %eax
    2c14:      	movw	%ax, 0x2(%r12)
    2c1a:      	jmp	0x2c37 <generic_retkprobe_event+0x2c37>
    2c1c:      	movzbl	0x7(%r12), %eax
    2c22:      	leal	0x8(,%rax,4), %eax
    2c29:      	movw	%ax, 0x2(%r12)
    2c2f:      	jmp	0x2c37 <generic_retkprobe_event+0x2c37>
    2c31:      	movzwl	0x2(%r12), %eax
    2c37:      	addw	(%r12), %ax
    2c3c:      	movw	%ax, (%r12)
    2c41:      	movzbl	0x6(%r12), %ecx
    2c47:      	cmpq	$0x3c, %rcx
    2c4b:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    2c51:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2c5b:      	btq	%rcx, %rdx
    2c5f:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    2c65:      	movb	%cl, 0x5(%r12)
    2c6a:      	movzwl	%ax, %ecx
    2c6d:      	addq	%r14, %rcx
    2c70:      	movl	$0x2, %edx
    2c75:      	movl	$0x4, %eax
    2c7a:      	movq	%r13, %rdi
    2c7d:      	movzwl	(%r12), %edx
    2c82:      	addq	%r14, %rdx
    2c85:      	movl	$0x2, %esi
    2c8a:      	callq	*%rax
    2c8c:      	testq	%rax, %rax
    2c8f:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    2c95:      	movzbl	0x5(%r12), %eax
    2c9b:      	cmpl	$0x32, %eax
    2c9e:      	jg	0x2cc3 <generic_retkprobe_event+0x2cc3>
    2ca0:      	testl	%eax, %eax
    2ca2:      	je	0x2ced <generic_retkprobe_event+0x2ced>
    2ca4:      	cmpl	$0x2b, %eax
    2ca7:      	je	0x2ced <generic_retkprobe_event+0x2ced>
    2ca9:      	cmpl	$0x2c, %eax
    2cac:      	jne	0x2deb <generic_retkprobe_event+0x2deb>
    2cb2:      	movw	$0x8, 0x2(%r12)
    2cba:      	movw	$0x8, %ax
    2cbe:      	jmp	0x2df1 <generic_retkprobe_event+0x2df1>
    2cc3:      	cmpl	$0x33, %eax
    2cc6:      	je	0x2dd6 <generic_retkprobe_event+0x2dd6>
    2ccc:      	cmpl	$0x3c, %eax
    2ccf:      	je	0x2ced <generic_retkprobe_event+0x2ced>
    2cd1:      	cmpl	$0xff, %eax
    2cd6:      	jne	0x2deb <generic_retkprobe_event+0x2deb>
    2cdc:      	movw	$0x28, 0x2(%r12)
    2ce4:      	movw	$0x28, %ax
    2ce8:      	jmp	0x2df1 <generic_retkprobe_event+0x2df1>
    2ced:      	movzbl	0x7(%r12), %eax
    2cf3:      	leal	0x8(,%rax,8), %eax
    2cfa:      	movw	%ax, 0x2(%r12)
    2d00:      	jmp	0x2df1 <generic_retkprobe_event+0x2df1>
    2d05:      	xorl	%eax, %eax
    2d07:      	movq	%rax, (%rsp)
    2d0b:      	cmpq	$0x5, 0xa8(%rsp)
    2d14:      	jb	0x28d0 <generic_retkprobe_event+0x28d0>
    2d1a:      	movq	0x98(%rsp), %rax
    2d22:      	leaq	0x40(%rax), %rdx
    2d26:      	leaq	0x30(%rsp), %rdi
    2d2b:      	movl	$0x4, %r12d
    2d31:      	movl	$0x10, %ecx
    2d36:      	movl	$0x4, %eax
    2d3b:      	movl	$0x10, %esi
    2d40:      	callq	*%rax
    2d42:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d47:      	testl	%eax, %eax
    2d49:      	js	0x335c <generic_retkprobe_event+0x335c>
    2d4f:      	movq	0x38(%rsp), %rdx
    2d54:      	movq	(%rsp), %rax
    2d58:      	cmpq	%rax, %rdx
    2d5b:      	movq	%rax, %r13
    2d5e:      	cmovbq	%rdx, %r13
    2d62:      	testq	%rax, %rax
    2d65:      	cmovneq	%r13, %rdx
    2d69:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d6e:      	movq	%rdx, 0x8(%rsp)
    2d73:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2d7a:      	ja	0x335c <generic_retkprobe_event+0x335c>
    2d80:      	movq	%r14, %rdi
    2d83:      	addq	%r15, %rdi
    2d86:      	movq	%rdi, %r14
    2d89:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d8f:      	addq	0x20(%rsp), %rdi
    2d94:      	movq	0x30(%rsp), %rcx
    2d99:      	movl	$0x4, %eax
    2d9e:      	movq	0x8(%rsp), %rsi
    2da3:      	movq	0x30(%rsp), %rdx
    2da8:      	callq	*%rax
    2daa:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2daf:      	testl	%eax, %eax
    2db1:      	js	0x335c <generic_retkprobe_event+0x335c>
    2db7:      	addq	0x8(%rsp), %rbp
    2dbc:      	cmpq	$0x0, (%rsp)
    2dc1:      	je	0x31f5 <generic_retkprobe_event+0x31f5>
    2dc7:      	subq	%r13, (%rsp)
    2dcb:      	jne	0x31fb <generic_retkprobe_event+0x31fb>
    2dd1:      	jmp	0x28d0 <generic_retkprobe_event+0x28d0>
    2dd6:      	movzbl	0x7(%r12), %eax
    2ddc:      	leal	0x8(,%rax,4), %eax
    2de3:      	movw	%ax, 0x2(%r12)
    2de9:      	jmp	0x2df1 <generic_retkprobe_event+0x2df1>
    2deb:      	movzwl	0x2(%r12), %eax
    2df1:      	addw	(%r12), %ax
    2df6:      	movw	%ax, (%r12)
    2dfb:      	movzbl	0x6(%r12), %ecx
    2e01:      	cmpq	$0x3c, %rcx
    2e05:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    2e0b:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2e15:      	btq	%rcx, %rdx
    2e19:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    2e1f:      	movb	%cl, 0x5(%r12)
    2e24:      	movzwl	%ax, %ecx
    2e27:      	addq	%r14, %rcx
    2e2a:      	movl	$0x2, %edx
    2e2f:      	movl	$0x4, %eax
    2e34:      	movq	%r13, %rdi
    2e37:      	movzwl	(%r12), %edx
    2e3c:      	addq	%r14, %rdx
    2e3f:      	movl	$0x2, %esi
    2e44:      	callq	*%rax
    2e46:      	testq	%rax, %rax
    2e49:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    2e4f:      	movzbl	0x5(%r12), %eax
    2e55:      	cmpl	$0x32, %eax
    2e58:      	jg	0x2e76 <generic_retkprobe_event+0x2e76>
    2e5a:      	testl	%eax, %eax
    2e5c:      	je	0x2e95 <generic_retkprobe_event+0x2e95>
    2e5e:      	cmpl	$0x2b, %eax
    2e61:      	je	0x2e95 <generic_retkprobe_event+0x2e95>
    2e63:      	cmpl	$0x2c, %eax
    2e66:      	jne	0x2ebf <generic_retkprobe_event+0x2ebf>
    2e68:      	movw	$0x8, 0x2(%r12)
    2e70:      	movw	$0x8, %ax
    2e74:      	jmp	0x2ec5 <generic_retkprobe_event+0x2ec5>
    2e76:      	cmpl	$0x33, %eax
    2e79:      	je	0x2eaa <generic_retkprobe_event+0x2eaa>
    2e7b:      	cmpl	$0x3c, %eax
    2e7e:      	je	0x2e95 <generic_retkprobe_event+0x2e95>
    2e80:      	cmpl	$0xff, %eax
    2e85:      	jne	0x2ebf <generic_retkprobe_event+0x2ebf>
    2e87:      	movw	$0x28, 0x2(%r12)
    2e8f:      	movw	$0x28, %ax
    2e93:      	jmp	0x2ec5 <generic_retkprobe_event+0x2ec5>
    2e95:      	movzbl	0x7(%r12), %eax
    2e9b:      	leal	0x8(,%rax,8), %eax
    2ea2:      	movw	%ax, 0x2(%r12)
    2ea8:      	jmp	0x2ec5 <generic_retkprobe_event+0x2ec5>
    2eaa:      	movzbl	0x7(%r12), %eax
    2eb0:      	leal	0x8(,%rax,4), %eax
    2eb7:      	movw	%ax, 0x2(%r12)
    2ebd:      	jmp	0x2ec5 <generic_retkprobe_event+0x2ec5>
    2ebf:      	movzwl	0x2(%r12), %eax
    2ec5:      	addw	(%r12), %ax
    2eca:      	movw	%ax, (%r12)
    2ecf:      	movzbl	0x6(%r12), %ecx
    2ed5:      	cmpq	$0x3c, %rcx
    2ed9:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    2edf:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2ee9:      	btq	%rcx, %rdx
    2eed:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    2ef3:      	movb	%cl, 0x5(%r12)
    2ef8:      	movzwl	%ax, %ecx
    2efb:      	addq	%r14, %rcx
    2efe:      	movl	$0x2, %edx
    2f03:      	movl	$0x4, %eax
    2f08:      	movq	%r13, %rdi
    2f0b:      	movzwl	(%r12), %edx
    2f10:      	addq	%r14, %rdx
    2f13:      	movl	$0x2, %esi
    2f18:      	callq	*%rax
    2f1a:      	testq	%rax, %rax
    2f1d:      	js	0x2fee <generic_retkprobe_event+0x2fee>
    2f23:      	movzbl	0x5(%r12), %eax
    2f29:      	cmpl	$0x32, %eax
    2f2c:      	jg	0x2f4a <generic_retkprobe_event+0x2f4a>
    2f2e:      	testl	%eax, %eax
    2f30:      	je	0x2f69 <generic_retkprobe_event+0x2f69>
    2f32:      	cmpl	$0x2b, %eax
    2f35:      	je	0x2f69 <generic_retkprobe_event+0x2f69>
    2f37:      	cmpl	$0x2c, %eax
    2f3a:      	jne	0x2f93 <generic_retkprobe_event+0x2f93>
    2f3c:      	movw	$0x8, 0x2(%r12)
    2f44:      	movw	$0x8, %ax
    2f48:      	jmp	0x2f99 <generic_retkprobe_event+0x2f99>
    2f4a:      	cmpl	$0x33, %eax
    2f4d:      	je	0x2f7e <generic_retkprobe_event+0x2f7e>
    2f4f:      	cmpl	$0x3c, %eax
    2f52:      	je	0x2f69 <generic_retkprobe_event+0x2f69>
    2f54:      	cmpl	$0xff, %eax
    2f59:      	jne	0x2f93 <generic_retkprobe_event+0x2f93>
    2f5b:      	movw	$0x28, 0x2(%r12)
    2f63:      	movw	$0x28, %ax
    2f67:      	jmp	0x2f99 <generic_retkprobe_event+0x2f99>
    2f69:      	movzbl	0x7(%r12), %eax
    2f6f:      	leal	0x8(,%rax,8), %eax
    2f76:      	movw	%ax, 0x2(%r12)
    2f7c:      	jmp	0x2f99 <generic_retkprobe_event+0x2f99>
    2f7e:      	movzbl	0x7(%r12), %eax
    2f84:      	leal	0x8(,%rax,4), %eax
    2f8b:      	movw	%ax, 0x2(%r12)
    2f91:      	jmp	0x2f99 <generic_retkprobe_event+0x2f99>
    2f93:      	movzwl	0x2(%r12), %eax
    2f99:      	addw	(%r12), %ax
    2f9e:      	movw	%ax, (%r12)
    2fa3:      	movzbl	0x6(%r12), %ecx
    2fa9:      	cmpq	$0x3c, %rcx
    2fad:      	ja	0x31e8 <generic_retkprobe_event+0x31e8>
    2fb3:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2fbd:      	btq	%rcx, %rdx
    2fc1:      	jae	0x31e8 <generic_retkprobe_event+0x31e8>
    2fc7:      	movb	%cl, 0x5(%r12)
    2fcc:      	movzwl	%ax, %ecx
    2fcf:      	addq	%r14, %rcx
    2fd2:      	movl	$0x2, %edx
    2fd7:      	movl	$0x4, %eax
    2fdc:      	movzwl	(%r12), %edx
    2fe1:      	addq	%r14, %rdx
    2fe4:      	movq	%r13, %rdi
    2fe7:      	movl	$0x2, %esi
    2fec:      	callq	*%rax
    2fee:      	xorl	%ecx, %ecx
    2ff0:      	movb	%cl, 0xc8(%rsp)
    2ff7:      	movzbl	%cl, %eax
    2ffa:      	movq	(%rsp), %r14
    2ffe:      	movw	%ax, 0xc0(%r14)
    3006:      	movw	$0xa, 0xc2(%r14)
    3010:      	leaq	0x8(%rbx), %rdx
    3014:      	movl	$0x10, %ecx
    3019:      	movl	$0x4, %eax
    301e:      	movq	%rbp, %rdi
    3021:      	movl	$0x10, %esi
    3026:      	callq	*%rax
    3028:      	leaq	0xac(%r14), %rdi
    302f:      	addq	$0x18, %rbx
    3033:      	movl	$0x10, %ecx
    3038:      	movl	$0x4, %eax
    303d:      	movl	$0x10, %esi
    3042:      	movq	%rbx, %rdx
    3045:      	callq	*%rax
    3047:      	movzbl	0xc8(%rsp), %eax
    304f:      	cmpl	$0x11, %eax
    3052:      	je	0x30a6 <generic_retkprobe_event+0x30a6>
    3054:      	cmpl	$0x6, %eax
    3057:      	jne	0x30f6 <generic_retkprobe_event+0x30f6>
    305d:      	movq	0x30(%rsp), %r14
    3062:      	movzwl	0xd0(%rsp), %r12d
    306b:      	leaq	(%r14,%r12), %rdx
    306f:      	movq	(%rsp), %r13
    3073:      	leaq	0xbc(%r13), %rdi
    307a:      	movl	$0x2, %ecx
    307f:      	movl	$0x4, %eax
    3084:      	movl	$0x2, %esi
    3089:      	callq	*%rax
    308b:      	leaq	0xbe(%r13), %rdi
    3092:      	leaq	(%r14,%r12), %rdx
    3096:      	addq	$0x2, %rdx
    309a:      	movl	$0x2, %ecx
    309f:      	movl	$0x4, %eax
    30a4:      	jmp	0x30ed <generic_retkprobe_event+0x30ed>
    30a6:      	movq	0x30(%rsp), %r14
    30ab:      	movzwl	0xd0(%rsp), %r12d
    30b4:      	leaq	(%r14,%r12), %rdx
    30b8:      	movq	(%rsp), %r13
    30bc:      	leaq	0xbc(%r13), %rdi
    30c3:      	movl	$0x2, %ecx
    30c8:      	movl	$0x4, %eax
    30cd:      	movl	$0x2, %esi
    30d2:      	callq	*%rax
    30d4:      	leaq	0xbe(%r13), %rdi
    30db:      	leaq	(%r14,%r12), %rdx
    30df:      	addq	$0x2, %rdx
    30e3:      	movl	$0x2, %ecx
    30e8:      	movl	$0x4, %eax
    30ed:      	movl	$0x2, %esi
    30f2:      	callq	*%rax
    30f4:      	jmp	0x3105 <generic_retkprobe_event+0x3105>
    30f6:      	movq	(%rsp), %r13
    30fa:      	movl	$0x0, 0xbc(%r13)
    3105:      	movzwl	0xbc(%r13), %eax
    310d:      	movzwl	0xbe(%r13), %ecx
    3115:      	movbew	%ax, 0xbc(%r13)
    311f:      	movbew	%cx, 0xbe(%r13)
    3129:      	movq	0x80(%rsp), %rdx
    3131:      	addq	$0xe0, %rdx
    3138:      	leaq	0x70(%rsp), %rdi
    313d:      	movl	$0x8, %ecx
    3142:      	movl	$0x4, %eax
    3147:      	movl	$0x4, %r14d
    314d:      	movl	$0x8, %esi
    3152:      	callq	*%rax
    3154:      	movq	0x70(%rsp), %rcx
    3159:      	testq	%rcx, %rcx
    315c:      	je	0x31ce <generic_retkprobe_event+0x31ce>
    315e:      	addq	$0x5, %rcx
    3162:      	leaq	0x88(%rsp), %rdi
    316a:      	movl	$0x8, %edx
    316f:      	movl	$0x4, %eax
    3174:      	movq	0x70(%rsp), %rdx
    3179:      	addq	$0x5, %rdx
    317d:      	movl	$0x8, %esi
    3182:      	callq	*%rax
    3184:      	movq	0x70(%rsp), %r12
    3189:      	movq	0x88(%rsp), %r13
    3191:      	movq	(%rsp), %rbp
    3195:      	leaq	0xd4(%rbp), %rdi
    319c:      	leaq	(%r12,%r13,8), %rdx
    31a0:      	addq	$0x44, %rdx
    31a4:      	movl	$0x4, %eax
    31a9:      	movl	$0x4, %esi
    31ae:      	callq	*%rax
    31b0:      	movq	%rbp, %rdi
    31b3:      	addq	$0xd8, %rdi
    31ba:      	leaq	(%r12,%r13,8), %rdx
    31be:      	addq	$0x45, %rdx
    31c2:      	movl	$0x4, %eax
    31c7:      	movl	$0x4, %esi
    31cc:      	callq	*%rax
    31ce:      	movq	0x18(%rsp), %r13
    31d3:      	movq	0x8(%rsp), %rbx
    31d8:      	movq	0x20(%rsp), %r15
    31dd:      	movl	$0x40, %r12d
    31e3:      	jmp	0x1489 <generic_retkprobe_event+0x1489>
    31e8:      	movw	%ax, 0xd0(%rsp)
    31f0:      	jmp	0x2ff0 <generic_retkprobe_event+0x2ff0>
    31f5:      	xorl	%eax, %eax
    31f7:      	movq	%rax, (%rsp)
    31fb:      	cmpq	$0x5, 0xa8(%rsp)
    3204:      	je	0x28d0 <generic_retkprobe_event+0x28d0>
    320a:      	movq	0x98(%rsp), %rax
    3212:      	leaq	0x50(%rax), %rdx
    3216:      	leaq	0x30(%rsp), %rdi
    321b:      	movl	$0x4, %r12d
    3221:      	movl	$0x10, %ecx
    3226:      	movl	$0x4, %eax
    322b:      	movl	$0x10, %esi
    3230:      	callq	*%rax
    3232:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3237:      	testl	%eax, %eax
    3239:      	js	0x335c <generic_retkprobe_event+0x335c>
    323f:      	movq	0x38(%rsp), %r15
    3244:      	movq	(%rsp), %rax
    3248:      	cmpq	%rax, %r15
    324b:      	movq	%rax, %r13
    324e:      	cmovbq	%r15, %r13
    3252:      	testq	%rax, %rax
    3255:      	cmovneq	%r13, %r15
    3259:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    325e:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    3265:      	ja	0x335c <generic_retkprobe_event+0x335c>
    326b:      	movq	0x8(%rsp), %rdi
    3270:      	addq	%r14, %rdi
    3273:      	movq	%rdi, %r14
    3276:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    327c:      	addq	0x20(%rsp), %rdi
    3281:      	movq	0x30(%rsp), %rcx
    3286:      	movl	$0x4, %eax
    328b:      	movq	0x30(%rsp), %rdx
    3290:      	movl	%r15d, %esi
    3293:      	callq	*%rax
    3295:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    329a:      	testl	%eax, %eax
    329c:      	js	0x335c <generic_retkprobe_event+0x335c>
    32a2:      	addq	%r15, %rbp
    32a5:      	cmpq	$0x0, (%rsp)
    32aa:      	je	0x32b7 <generic_retkprobe_event+0x32b7>
    32ac:      	subq	%r13, (%rsp)
    32b0:      	jne	0x32bd <generic_retkprobe_event+0x32bd>
    32b2:      	jmp	0x28d0 <generic_retkprobe_event+0x28d0>
    32b7:      	xorl	%eax, %eax
    32b9:      	movq	%rax, (%rsp)
    32bd:      	cmpq	$0x7, 0xa8(%rsp)
    32c6:      	jb	0x28d0 <generic_retkprobe_event+0x28d0>
    32cc:      	movq	0x98(%rsp), %rdx
    32d4:      	addq	$0x60, %rdx
    32d8:      	leaq	0x30(%rsp), %rdi
    32dd:      	movl	$0x4, %r12d
    32e3:      	movl	$0x10, %ecx
    32e8:      	movl	$0x4, %eax
    32ed:      	movl	$0x10, %esi
    32f2:      	callq	*%rax
    32f4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32f9:      	testl	%eax, %eax
    32fb:      	js	0x335c <generic_retkprobe_event+0x335c>
    32fd:      	movq	0x38(%rsp), %rax
    3302:      	movq	(%rsp), %rcx
    3306:      	cmpq	%rcx, %rax
    3309:      	movq	%rcx, %r13
    330c:      	cmovbq	%rax, %r13
    3310:      	testq	%rcx, %rcx
    3313:      	cmoveq	%rax, %r13
    3317:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    331c:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    3323:      	ja	0x335c <generic_retkprobe_event+0x335c>
    3325:      	addq	%r14, %r15
    3328:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    332f:      	addq	0x20(%rsp), %r15
    3334:      	movq	0x30(%rsp), %rcx
    3339:      	movl	$0x4, %eax
    333e:      	movq	0x30(%rsp), %rdx
    3343:      	movq	%r15, %rdi
    3346:      	movl	%r13d, %esi
    3349:      	callq	*%rax
    334b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3350:      	testl	%eax, %eax
    3352:      	js	0x335c <generic_retkprobe_event+0x335c>
    3354:      	addq	%rbp, %r13
    3357:      	jmp	0x28d3 <generic_retkprobe_event+0x28d3>
    335c:      	movq	0x28(%rsp), %r14
    3361:      	movq	0x20(%rsp), %rax
    3366:      	movl	%ecx, (%rax,%r14)
    336a:      	jmp	0x1b44 <generic_retkprobe_event+0x1b44>
