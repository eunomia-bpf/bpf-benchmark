
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_kprobe_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section kprobe.multi:

0000000000000000 <generic_kprobe_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x40, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movl	$0x0, 0x1c(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_kprobe_setup_event+0x1b>
      1b:      	leaq	0x1c(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x343 <generic_kprobe_setup_event+0x343>
      30:      	movq	%rax, %r14
      33:      	leaq	0x5ef8(%rax), %rsi
      3a:      	movq	(%rip), %rdi            # 0x41 <generic_kprobe_setup_event+0x41>
      41:      	movl	$0x1, %eax
      46:      	callq	*%rax
      48:      	testq	%rax, %rax
      4b:      	je	0x343 <generic_kprobe_setup_event+0x343>
      51:      	movq	%rax, %r15
      54:      	cmpl	$0x0, 0x54(%rax)
      58:      	je	0x109 <generic_kprobe_setup_event+0x109>
      5e:      	testq	%rbx, %rbx
      61:      	je	0x343 <generic_kprobe_setup_event+0x343>
      67:      	leaq	0x70(%rbx), %rdx
      6b:      	movq	%rsp, %rdi
      6e:      	movl	$0x8, %ecx
      73:      	movl	$0x4, %eax
      78:      	movl	$0x8, %esi
      7d:      	callq	*%rax
      7f:      	movq	(%rsp), %rax
      83:      	movq	%rax, 0x5e50(%r14)
      8a:      	leaq	0x68(%rbx), %rdx
      8e:      	movq	%rsp, %rdi
      91:      	movl	$0x8, %ecx
      96:      	movl	$0x4, %eax
      9b:      	movl	$0x8, %esi
      a0:      	callq	*%rax
      a2:      	movq	(%rsp), %rax
      a6:      	movq	%rax, 0x5e58(%r14)
      ad:      	leaq	0x60(%rbx), %rdx
      b1:      	movq	%rsp, %rdi
      b4:      	movl	$0x8, %ecx
      b9:      	movl	$0x4, %eax
      be:      	movl	$0x8, %esi
      c3:      	callq	*%rax
      c5:      	movq	(%rsp), %rax
      c9:      	movq	%rax, 0x5e60(%r14)
      d0:      	leaq	0x38(%rbx), %rdx
      d4:      	movq	%rsp, %rdi
      d7:      	movl	$0x8, %ecx
      dc:      	movl	$0x4, %eax
      e1:      	movl	$0x8, %esi
      e6:      	callq	*%rax
      e8:      	movq	(%rsp), %rax
      ec:      	movq	%rax, 0x5e68(%r14)
      f3:      	leaq	0x48(%rbx), %rdx
      f7:      	movq	%rsp, %rdi
      fa:      	movl	$0x8, %ecx
      ff:      	movl	$0x4, %eax
     104:      	jmp	0x1a6 <generic_kprobe_setup_event+0x1a6>
     109:      	leaq	0x70(%rbx), %rdx
     10d:      	movq	%rsp, %rdi
     110:      	movl	$0x8, %ecx
     115:      	movl	$0x4, %eax
     11a:      	movl	$0x8, %esi
     11f:      	callq	*%rax
     121:      	movq	(%rsp), %rax
     125:      	movq	%rax, 0x5e50(%r14)
     12c:      	leaq	0x68(%rbx), %rdx
     130:      	movq	%rsp, %rdi
     133:      	movl	$0x8, %ecx
     138:      	movl	$0x4, %eax
     13d:      	movl	$0x8, %esi
     142:      	callq	*%rax
     144:      	movq	(%rsp), %rax
     148:      	movq	%rax, 0x5e58(%r14)
     14f:      	leaq	0x60(%rbx), %rdx
     153:      	movq	%rsp, %rdi
     156:      	movl	$0x8, %ecx
     15b:      	movl	$0x4, %eax
     160:      	movl	$0x8, %esi
     165:      	callq	*%rax
     167:      	movq	(%rsp), %rax
     16b:      	movq	%rax, 0x5e60(%r14)
     172:      	leaq	0x58(%rbx), %rdx
     176:      	movq	%rsp, %rdi
     179:      	movl	$0x8, %ecx
     17e:      	movl	$0x4, %eax
     183:      	movl	$0x8, %esi
     188:      	callq	*%rax
     18a:      	movq	(%rsp), %rax
     18e:      	movq	%rax, 0x5e68(%r14)
     195:      	leaq	0x48(%rbx), %rdx
     199:      	movq	%rsp, %rdi
     19c:      	movl	$0x8, %ecx
     1a1:      	movl	$0x4, %eax
     1a6:      	movl	$0x8, %esi
     1ab:      	callq	*%rax
     1ad:      	movq	(%rsp), %rax
     1b1:      	movq	%rax, 0x5e70(%r14)
     1b8:      	movb	$0xd, (%r14)
     1bc:      	movw	$0x0, 0x2(%r14)
     1c3:      	movl	$0x0, 0x4(%r14)
     1cb:      	movl	$0x7d, %eax
     1d0:      	callq	*%rax
     1d2:      	movq	%rax, 0x8(%r14)
     1d6:      	movq	$0x0, 0x70(%r14)
     1de:      	movl	$0x0, 0x14(%r14)
     1e6:      	movl	$0xe, %eax
     1eb:      	callq	*%rax
     1ed:      	movl	%eax, 0x7c(%r14)
     1f1:      	movl	$0xe, %eax
     1f6:      	callq	*%rax
     1f8:      	cmpq	$-0x16, %rax
     1fc:      	jne	0x21a <generic_kprobe_setup_event+0x21a>
     1fe:      	leaq	0x20(%rbx), %rdx
     202:      	movq	%rsp, %rdi
     205:      	movl	$0x8, %ecx
     20a:      	movl	$0x4, %eax
     20f:      	movl	$0x8, %esi
     214:      	callq	*%rax
     216:      	movq	(%rsp), %rax
     21a:      	movq	%rax, 0x68(%r14)
     21e:      	cmpl	$0x0, 0x5c(%r15)
     223:      	jle	0x2cd <generic_kprobe_setup_event+0x2cd>
     229:      	movq	0x8(%r14), %rcx
     22d:      	movq	0x60(%r14), %rdx
     231:      	movq	%rcx, (%rsp)
     235:      	movq	$0x1, 0x8(%rsp)
     23e:      	movq	$0x0, 0x10(%rsp)
     247:      	movq	%rdx, 0x30(%rsp)
     24c:      	movq	%rax, 0x38(%rsp)
     251:      	movq	(%rip), %rdi            # 0x258 <generic_kprobe_setup_event+0x258>
     258:      	xorl	%ecx, %ecx
     25a:      	leaq	0x30(%rsp), %rsi
     25f:      	movq	%rsp, %rdx
     262:      	movl	$0x2, %eax
     267:      	xorl	%ecx, %ecx
     269:      	callq	*%rax
     26b:      	testq	%rax, %rax
     26e:      	je	0x2cd <generic_kprobe_setup_event+0x2cd>
     270:      	negl	%eax
     272:      	movw	%ax, 0x24(%rsp)
     277:      	movw	$0x5, 0x26(%rsp)
     27e:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     288:      	movq	%rax, 0x28(%rsp)
     28d:      	movq	(%rip), %rdi            # 0x294 <generic_kprobe_setup_event+0x294>
     294:      	leaq	0x24(%rsp), %rsi
     299:      	movl	$0x1, %eax
     29e:      	callq	*%rax
     2a0:      	testq	%rax, %rax
     2a3:      	je	0x2a9 <generic_kprobe_setup_event+0x2a9>
     2a5:      	incl	(%rax)
     2a7:      	jmp	0x2cd <generic_kprobe_setup_event+0x2cd>
     2a9:      	movl	$0x1, 0x20(%rsp)
     2b1:      	movq	(%rip), %rdi            # 0x2b8 <generic_kprobe_setup_event+0x2b8>
     2b8:      	xorl	%ecx, %ecx
     2ba:      	leaq	0x24(%rsp), %rsi
     2bf:      	leaq	0x20(%rsp), %rdx
     2c4:      	movl	$0x2, %eax
     2c9:      	xorl	%ecx, %ecx
     2cb:      	callq	*%rax
     2cd:      	movl	$0x0, (%rsp)
     2d4:      	movq	(%rip), %rdi            # 0x2db <generic_kprobe_setup_event+0x2db>
     2db:      	movq	%rsp, %rsi
     2de:      	movl	$0x1, %eax
     2e3:      	callq	*%rax
     2e5:      	testq	%rax, %rax
     2e8:      	je	0x30d <generic_kprobe_setup_event+0x30d>
     2ea:      	movq	%rax, %rsi
     2ed:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     2f4:      	movq	(%rip), %rdi            # 0x2fb <generic_kprobe_setup_event+0x2fb>
     2fb:      	movl	$0x1, %eax
     300:      	callq	*%rax
     302:      	testq	%rax, %rax
     305:      	je	0x30d <generic_kprobe_setup_event+0x30d>
     307:      	cmpl	$-0x1, 0x40(%rax)
     30b:      	jne	0x328 <generic_kprobe_setup_event+0x328>
     30d:      	movq	(%rip), %rsi            # 0x314 <generic_kprobe_setup_event+0x314>
     314:      	movl	$0x3, %ecx
     319:      	movl	$0xc, %eax
     31e:      	movq	%rbx, %rdi
     321:      	movl	$0x3, %edx
     326:      	callq	*%rax
     328:      	movq	(%rip), %rsi            # 0x32f <generic_kprobe_setup_event+0x32f>
     32f:      	movl	$0x1, %ecx
     334:      	movl	$0xc, %eax
     339:      	movq	%rbx, %rdi
     33c:      	movl	$0x1, %edx
     341:      	callq	*%rax
     343:      	xorl	%eax, %eax
     345:      	addq	$0x40, %rsp
     349:      	popq	%rbx
     34a:      	popq	%r14
     34c:      	popq	%r15
     34e:      	retq
     34f:      	nop

0000000000000350 <generic_kprobe_process_event>:
     350:      	pushq	%rbp
     351:      	pushq	%r15
     353:      	pushq	%r14
     355:      	pushq	%r13
     357:      	pushq	%r12
     359:      	pushq	%rbx
     35a:      	subq	$0x108, %rsp            # imm = 0x108
     361:      	movq	%rdi, %rbx
     364:      	movl	$0x0, 0xf4(%rsp)
     36f:      	movq	(%rip), %rdi            # 0x376 <generic_kprobe_process_event+0x26>
     376:      	leaq	0xf4(%rsp), %rsi
     37e:      	movl	$0x1, %eax
     383:      	callq	*%rax
     385:      	testq	%rax, %rax
     388:      	je	0xc77 <generic_kprobe_process_event+0x927>
     38e:      	movq	%rax, %r14
     391:      	movl	0x5efc(%rax), %r12d
     398:      	movl	0x4(%rax), %r13d
     39c:      	cmpq	$0x2327, %r13           # imm = 0x2327
     3a3:      	ja	0xbd8 <generic_kprobe_process_event+0x888>
     3a9:      	movl	$0x0, 0xf8(%rsp)
     3b4:      	movq	(%rip), %rdi            # 0x3bb <generic_kprobe_process_event+0x6b>
     3bb:      	leaq	0xf8(%rsp), %rsi
     3c3:      	movl	$0x1, %eax
     3c8:      	callq	*%rax
     3ca:      	testq	%rax, %rax
     3cd:      	je	0xbd8 <generic_kprobe_process_event+0x888>
     3d3:      	movq	%rax, %r15
     3d6:      	leaq	0x5ef8(%rax), %rsi
     3dd:      	movq	(%rip), %rdi            # 0x3e4 <generic_kprobe_process_event+0x94>
     3e4:      	movl	$0x1, %eax
     3e9:      	callq	*%rax
     3eb:      	cmpl	$0x4, %r12d
     3ef:      	jg	0xbd8 <generic_kprobe_process_event+0x888>
     3f5:      	testq	%rax, %rax
     3f8:      	je	0xbd8 <generic_kprobe_process_event+0x888>
     3fe:      	movq	%r13, 0xa8(%rsp)
     406:      	movl	%r12d, %esi
     409:      	andl	$0x7, %esi
     40c:      	movl	%esi, %ecx
     40e:      	movl	0x4(%rax,%rcx,4), %edx
     412:      	movq	%rdx, (%rsp)
     416:      	movslq	0x18(%rax,%rcx,4), %rdi
     41b:      	movl	%edi, %r8d
     41e:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     42a:      	testl	$0x100, %edi            # imm = 0x100
     430:      	movq	%rsi, 0x20(%rsp)
     435:      	movq	%r12, 0x100(%rsp)
     43d:      	jne	0x462 <generic_kprobe_process_event+0x112>
     43f:      	testb	%dil, %dil
     442:      	js	0x470 <generic_kprobe_process_event+0x120>
     444:      	testb	$0x40, %r8b
     448:      	jne	0x4e0 <generic_kprobe_process_event+0x190>
     44e:      	movl	0x40(%rax,%rsi,4), %ecx
     452:      	andl	$0x7, %ecx
     455:      	movq	0x5e50(%r15,%rcx,8), %rcx
     45d:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     462:      	movq	$0x0, 0x8(%rsp)
     46b:      	jmp	0x943 <generic_kprobe_process_event+0x5f3>
     470:      	movzbl	0x2c2(%rax,%rsi,4), %ecx
     478:      	shlb	$0x3, %cl
     47b:      	movb	$0x40, %r13b
     47e:      	subb	%cl, %r13b
     481:      	cmpl	$0x0, 0x54(%rax)
     485:      	movzwl	0x2c0(%rax,%rsi,4), %edx
     48d:      	je	0x50d <generic_kprobe_process_event+0x1bd>
     48f:      	testq	%rbx, %rbx
     492:      	je	0x55a <generic_kprobe_process_event+0x20a>
     498:      	addq	%rbx, %rdx
     49b:      	movq	%rdi, 0x40(%rsp)
     4a0:      	leaq	0x68(%rsp), %rdi
     4a5:      	movl	$0x8, %ecx
     4aa:      	movq	%rax, %r12
     4ad:      	movl	$0x4, %eax
     4b2:      	movl	$0x8, %esi
     4b7:      	movq	%r14, %rbp
     4ba:      	movq	%r8, %r14
     4bd:      	callq	*%rax
     4bf:      	movq	%r14, %r8
     4c2:      	movq	%rbp, %r14
     4c5:      	movq	0x40(%rsp), %rdi
     4ca:      	movq	0x20(%rsp), %rsi
     4cf:      	movq	%r12, %rax
     4d2:      	shlxq	%r13, 0x68(%rsp), %rcx
     4d9:      	sarxq	%r13, %rcx, %rcx
     4de:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     4e0:      	movq	%rax, 0x18(%rsp)
     4e5:      	movl	$0x23, %eax
     4ea:      	movq	%rdi, %r13
     4ed:      	movq	%r14, %r12
     4f0:      	movq	%r8, %r14
     4f3:      	callq	*%rax
     4f5:      	movq	%r14, %r8
     4f8:      	movq	%r12, %r14
     4fb:      	movq	%r13, %rdi
     4fe:      	movq	0x20(%rsp), %rsi
     503:      	movq	%rax, %rcx
     506:      	movq	0x18(%rsp), %rax
     50b:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     50d:      	rorxl	$0x3, %edx, %edx
     513:      	xorl	%ecx, %ecx
     515:      	cmpl	$0x7, %edx
     518:      	jle	0xcbe <generic_kprobe_process_event+0x96e>
     51e:      	cmpl	$0xb, %edx
     521:      	jle	0xe40 <generic_kprobe_process_event+0xaf0>
     527:      	cmpl	$0xd, %edx
     52a:      	jle	0xfa2 <generic_kprobe_process_event+0xc52>
     530:      	cmpl	$0xe, %edx
     533:      	je	0x10ab <generic_kprobe_process_event+0xd5b>
     539:      	cmpl	$0x10, %edx
     53c:      	je	0x104a <generic_kprobe_process_event+0xcfa>
     542:      	cmpl	$0x13, %edx
     545:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     547:      	movl	$0x40, %ecx
     54c:      	subl	%r13d, %ecx
     54f:      	bzhiq	%rcx, 0x98(%rbx), %rcx
     558:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     55a:      	xorl	%ecx, %ecx
     55c:      	movq	%rcx, 0x8(%rsp)
     561:      	cmpl	$0x4, %esi
     564:      	ja	0x943 <generic_kprobe_process_event+0x5f3>
     56a:      	leaq	(%rsi,%rsi,4), %rdx
     56e:      	shll	$0x4, %edx
     571:      	cmpw	$0x0, 0x76(%rax,%rdx)
     577:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     57d:      	leaq	(%rax,%rdx), %r13
     581:      	addq	$0x70, %r13
     585:      	movl	(%r13), %eax
     589:      	addq	%rax, %rcx
     58c:      	movq	%rcx, 0x8(%rsp)
     591:      	cmpw	$0x0, 0x4(%r13)
     597:      	movq	%rdi, 0x40(%rsp)
     59c:      	je	0x5dc <generic_kprobe_process_event+0x28c>
     59e:      	leaq	0x8(%rsp), %rdi
     5a3:      	movl	$0x8, %edx
     5a8:      	movl	$0x4, %eax
     5ad:      	movq	0x8(%rsp), %rdx
     5b2:      	movl	$0x8, %esi
     5b7:      	movq	%r14, %rbp
     5ba:      	movq	%r8, %r14
     5bd:      	callq	*%rax
     5bf:      	movq	%r14, %r8
     5c2:      	movq	%rbp, %r14
     5c5:      	movq	0x40(%rsp), %rdi
     5ca:      	movq	0x20(%rsp), %rcx
     5cf:      	movl	$0x1, %ebp
     5d4:      	testl	%eax, %eax
     5d6:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     5dc:      	cmpw	$0x0, 0xe(%r13)
     5e2:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     5e8:      	movl	0x8(%r13), %ecx
     5ec:      	addq	0x8(%rsp), %rcx
     5f1:      	movq	%rcx, 0x8(%rsp)
     5f6:      	cmpw	$0x0, 0xc(%r13)
     5fc:      	je	0x63c <generic_kprobe_process_event+0x2ec>
     5fe:      	leaq	0x8(%rsp), %rdi
     603:      	movl	$0x8, %edx
     608:      	movl	$0x4, %eax
     60d:      	movq	0x8(%rsp), %rdx
     612:      	movl	$0x8, %esi
     617:      	movq	%r14, %rbp
     61a:      	movq	%r8, %r14
     61d:      	callq	*%rax
     61f:      	movq	%r14, %r8
     622:      	movq	%rbp, %r14
     625:      	movq	0x40(%rsp), %rdi
     62a:      	movq	0x20(%rsp), %rcx
     62f:      	movl	$0x2, %ebp
     634:      	testl	%eax, %eax
     636:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     63c:      	cmpw	$0x0, 0x16(%r13)
     642:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     648:      	movl	0x10(%r13), %ecx
     64c:      	addq	0x8(%rsp), %rcx
     651:      	movq	%rcx, 0x8(%rsp)
     656:      	cmpw	$0x0, 0x14(%r13)
     65c:      	je	0x69c <generic_kprobe_process_event+0x34c>
     65e:      	leaq	0x8(%rsp), %rdi
     663:      	movl	$0x8, %edx
     668:      	movl	$0x4, %eax
     66d:      	movq	0x8(%rsp), %rdx
     672:      	movl	$0x8, %esi
     677:      	movq	%r14, %rbp
     67a:      	movq	%r8, %r14
     67d:      	callq	*%rax
     67f:      	movq	%r14, %r8
     682:      	movq	%rbp, %r14
     685:      	movq	0x40(%rsp), %rdi
     68a:      	movq	0x20(%rsp), %rcx
     68f:      	movl	$0x3, %ebp
     694:      	testl	%eax, %eax
     696:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     69c:      	cmpw	$0x0, 0x1e(%r13)
     6a2:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     6a8:      	movl	0x18(%r13), %ecx
     6ac:      	addq	0x8(%rsp), %rcx
     6b1:      	movq	%rcx, 0x8(%rsp)
     6b6:      	cmpw	$0x0, 0x1c(%r13)
     6bc:      	je	0x6fc <generic_kprobe_process_event+0x3ac>
     6be:      	leaq	0x8(%rsp), %rdi
     6c3:      	movl	$0x8, %edx
     6c8:      	movl	$0x4, %eax
     6cd:      	movq	0x8(%rsp), %rdx
     6d2:      	movl	$0x8, %esi
     6d7:      	movq	%r14, %rbp
     6da:      	movq	%r8, %r14
     6dd:      	callq	*%rax
     6df:      	movq	%r14, %r8
     6e2:      	movq	%rbp, %r14
     6e5:      	movq	0x40(%rsp), %rdi
     6ea:      	movq	0x20(%rsp), %rcx
     6ef:      	movl	$0x4, %ebp
     6f4:      	testl	%eax, %eax
     6f6:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     6fc:      	cmpw	$0x0, 0x26(%r13)
     702:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     708:      	movl	0x20(%r13), %ecx
     70c:      	addq	0x8(%rsp), %rcx
     711:      	movq	%rcx, 0x8(%rsp)
     716:      	cmpw	$0x0, 0x24(%r13)
     71c:      	je	0x75c <generic_kprobe_process_event+0x40c>
     71e:      	leaq	0x8(%rsp), %rdi
     723:      	movl	$0x8, %edx
     728:      	movl	$0x4, %eax
     72d:      	movq	0x8(%rsp), %rdx
     732:      	movl	$0x8, %esi
     737:      	movq	%r14, %rbp
     73a:      	movq	%r8, %r14
     73d:      	callq	*%rax
     73f:      	movq	%r14, %r8
     742:      	movq	%rbp, %r14
     745:      	movq	0x40(%rsp), %rdi
     74a:      	movq	0x20(%rsp), %rcx
     74f:      	movl	$0x5, %ebp
     754:      	testl	%eax, %eax
     756:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     75c:      	cmpw	$0x0, 0x2e(%r13)
     762:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     768:      	movl	0x28(%r13), %ecx
     76c:      	addq	0x8(%rsp), %rcx
     771:      	movq	%rcx, 0x8(%rsp)
     776:      	cmpw	$0x0, 0x2c(%r13)
     77c:      	je	0x7bc <generic_kprobe_process_event+0x46c>
     77e:      	leaq	0x8(%rsp), %rdi
     783:      	movl	$0x8, %edx
     788:      	movl	$0x4, %eax
     78d:      	movq	0x8(%rsp), %rdx
     792:      	movl	$0x8, %esi
     797:      	movq	%r14, %rbp
     79a:      	movq	%r8, %r14
     79d:      	callq	*%rax
     79f:      	movq	%r14, %r8
     7a2:      	movq	%rbp, %r14
     7a5:      	movq	0x40(%rsp), %rdi
     7aa:      	movq	0x20(%rsp), %rcx
     7af:      	movl	$0x6, %ebp
     7b4:      	testl	%eax, %eax
     7b6:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     7bc:      	cmpw	$0x0, 0x36(%r13)
     7c2:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     7c8:      	movl	0x30(%r13), %ecx
     7cc:      	addq	0x8(%rsp), %rcx
     7d1:      	movq	%rcx, 0x8(%rsp)
     7d6:      	cmpw	$0x0, 0x34(%r13)
     7dc:      	je	0x81c <generic_kprobe_process_event+0x4cc>
     7de:      	leaq	0x8(%rsp), %rdi
     7e3:      	movl	$0x8, %edx
     7e8:      	movl	$0x4, %eax
     7ed:      	movq	0x8(%rsp), %rdx
     7f2:      	movl	$0x8, %esi
     7f7:      	movq	%r14, %rbp
     7fa:      	movq	%r8, %r14
     7fd:      	callq	*%rax
     7ff:      	movq	%r14, %r8
     802:      	movq	%rbp, %r14
     805:      	movq	0x40(%rsp), %rdi
     80a:      	movq	0x20(%rsp), %rcx
     80f:      	movl	$0x7, %ebp
     814:      	testl	%eax, %eax
     816:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     81c:      	cmpw	$0x0, 0x3e(%r13)
     822:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     828:      	movl	0x38(%r13), %ecx
     82c:      	addq	0x8(%rsp), %rcx
     831:      	movq	%rcx, 0x8(%rsp)
     836:      	cmpw	$0x0, 0x3c(%r13)
     83c:      	je	0x886 <generic_kprobe_process_event+0x536>
     83e:      	leaq	0x8(%rsp), %rdi
     843:      	movq	%r13, 0x18(%rsp)
     848:      	movl	$0x8, %edx
     84d:      	movl	$0x4, %eax
     852:      	movq	0x8(%rsp), %rdx
     857:      	movl	$0x8, %ebp
     85c:      	movl	$0x8, %esi
     861:      	movq	%r14, %r12
     864:      	movq	%r8, %r14
     867:      	callq	*%rax
     869:      	movq	0x18(%rsp), %r13
     86e:      	movq	%r14, %r8
     871:      	movq	%r12, %r14
     874:      	movq	0x40(%rsp), %rdi
     879:      	movq	0x20(%rsp), %rcx
     87e:      	testl	%eax, %eax
     880:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     886:      	cmpw	$0x0, 0x46(%r13)
     88c:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     892:      	movl	0x40(%r13), %ecx
     896:      	addq	0x8(%rsp), %rcx
     89b:      	movq	%rcx, 0x8(%rsp)
     8a0:      	cmpw	$0x0, 0x44(%r13)
     8a6:      	je	0x8e2 <generic_kprobe_process_event+0x592>
     8a8:      	leaq	0x8(%rsp), %rdi
     8ad:      	movl	$0x8, %edx
     8b2:      	movl	$0x4, %eax
     8b7:      	movq	0x8(%rsp), %rdx
     8bc:      	movl	$0x8, %esi
     8c1:      	movq	%r14, %rbp
     8c4:      	movq	%r8, %r14
     8c7:      	callq	*%rax
     8c9:      	movq	%r14, %r8
     8cc:      	movq	%rbp, %r14
     8cf:      	movq	0x40(%rsp), %rdi
     8d4:      	movq	0x20(%rsp), %rcx
     8d9:      	movl	$0x9, %ebp
     8de:      	testl	%eax, %eax
     8e0:      	js	0x93b <generic_kprobe_process_event+0x5eb>
     8e2:      	cmpw	$0x0, 0x4e(%r13)
     8e8:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     8ea:      	movl	0x48(%r13), %ecx
     8ee:      	addq	0x8(%rsp), %rcx
     8f3:      	movq	%rcx, 0x8(%rsp)
     8f8:      	cmpw	$0x0, 0x4c(%r13)
     8fe:      	je	0x943 <generic_kprobe_process_event+0x5f3>
     900:      	movq	%rdi, %r12
     903:      	leaq	0x8(%rsp), %rdi
     908:      	movl	$0x8, %edx
     90d:      	movl	$0x4, %eax
     912:      	movq	0x8(%rsp), %rdx
     917:      	movl	$0x8, %esi
     91c:      	movq	%r14, %rbp
     91f:      	movq	%r8, %r14
     922:      	callq	*%rax
     924:      	movq	%r14, %r8
     927:      	movq	%rbp, %r14
     92a:      	movq	%r12, %rdi
     92d:      	movq	0x20(%rsp), %rcx
     932:      	movl	$0xa, %ebp
     937:      	testl	%eax, %eax
     939:      	jns	0x943 <generic_kprobe_process_event+0x5f3>
     93b:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     943:      	movq	(%rsp), %rax
     947:      	movl	%eax, %ebp
     949:      	cmpl	$0x2a, %eax
     94c:      	ja	0xb42 <generic_kprobe_process_event+0x7f2>
     952:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     95c:      	btq	%rbp, %rax
     960:      	jae	0xb42 <generic_kprobe_process_event+0x7f2>
     966:      	movq	0x8(%rsp), %rbp
     96b:      	movl	$0x0, 0x48(%rsp)
     973:      	movq	(%rip), %rdi            # 0x97a <generic_kprobe_process_event+0x62a>
     97a:      	leaq	0x48(%rsp), %rsi
     97f:      	movl	$0x1, %eax
     984:      	callq	*%rax
     986:      	testq	%rax, %rax
     989:      	je	0xbc0 <generic_kprobe_process_event+0x870>
     98f:      	movq	%rax, %r12
     992:      	cmpl	$0x0, 0x6420(%rax)
     999:      	je	0xaea <generic_kprobe_process_event+0x79a>
     99f:      	movl	$0x0, 0x6420(%r12)
     9ab:      	movq	(%rip), %rdi            # 0x9b2 <generic_kprobe_process_event+0x662>
     9b2:      	leaq	0x48(%rsp), %rsi
     9b7:      	movl	$0x1, %eax
     9bc:      	callq	*%rax
     9be:      	testq	%rax, %rax
     9c1:      	je	0xbc0 <generic_kprobe_process_event+0x870>
     9c7:      	movq	%rax, %rdx
     9ca:      	movq	0x20(%rsp), %rcx
     9cf:      	movl	0x5ea0(%r12,%rcx,4), %eax
     9d7:      	movq	0xa8(%rsp), %r13
     9df:      	movl	%eax, 0x90(%r12,%r13)
     9e7:      	movq	%r13, %rbp
     9ea:      	addq	$0x4, %rbp
     9ee:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     9f6:      	movl	$0x4, %esi
     9fb:      	testl	%eax, %eax
     9fd:      	jne	0xbca <generic_kprobe_process_event+0x87a>
     a03:      	movq	%r12, %r15
     a06:      	addq	$0x90, %r15
     a0d:      	movl	0x6424(%r12), %eax
     a15:      	movq	%rbx, 0x10(%rsp)
     a1a:      	movl	$0xfff, %ebx            # imm = 0xFFF
     a1f:      	subl	%eax, %ebx
     a21:      	andl	$0xfff, %eax            # imm = 0xFFF
     a26:      	addq	%rax, %rdx
     a29:      	movq	0x6440(%r12), %r13
     a31:      	leaq	(%r15,%rbp), %rdi
     a35:      	addq	$0x4, %rdi
     a39:      	andl	$0xfff, %ebx            # imm = 0xFFF
     a3f:      	movl	$0x4, %eax
     a44:      	addq	%rbp, %r15
     a47:      	movl	%ebx, %esi
     a49:      	callq	*%rax
     a4b:      	movl	%ebx, 0x90(%r12,%rbp)
     a53:      	addq	$0x8, %r13
     a57:      	leaq	0x68(%rsp), %rdi
     a5c:      	movl	$0x8, %ecx
     a61:      	movl	$0x4, %eax
     a66:      	movl	$0x8, %esi
     a6b:      	movq	%r13, %rdx
     a6e:      	movq	0xa8(%rsp), %r13
     a76:      	callq	*%rax
     a78:      	movq	0x68(%rsp), %rcx
     a7d:      	addq	$0x30, %rcx
     a81:      	leaq	0x58(%rsp), %rdi
     a86:      	movl	$0x8, %edx
     a8b:      	movl	$0x4, %eax
     a90:      	movq	0x68(%rsp), %rdx
     a95:      	addq	$0x30, %rdx
     a99:      	movl	$0x8, %esi
     a9e:      	callq	*%rax
     aa0:      	movq	0x58(%rsp), %rcx
     aa5:      	leaq	0xb8(%rsp), %rdi
     aad:      	movl	$0x2, %edx
     ab2:      	movl	$0x4, %eax
     ab7:      	movq	0x58(%rsp), %rdx
     abc:      	movl	$0x2, %esi
     ac1:      	callq	*%rax
     ac3:      	movq	%rbx, %rsi
     ac6:      	movq	0x10(%rsp), %rbx
     acb:      	movl	$0x0, 0x4(%rsi,%r15)
     ad4:      	movzwl	0xb8(%rsp), %eax
     adc:      	movw	%ax, 0x8(%rsi,%r15)
     ae2:      	addl	$0xe, %esi
     ae5:      	jmp	0xbca <generic_kprobe_process_event+0x87a>
     aea:      	movq	%rbp, 0x68(%rsp)
     aef:      	movq	$0x0, 0x58(%rsp)
     af8:      	cmpl	$0x17, (%rsp)
     afc:      	jle	0xba3 <generic_kprobe_process_event+0x853>
     b02:      	cmpl	$0x18, (%rsp)
     b06:      	je	0xd46 <generic_kprobe_process_event+0x9f6>
     b0c:      	cmpl	$0x25, (%rsp)
     b10:      	je	0xda8 <generic_kprobe_process_event+0xa58>
     b16:      	cmpl	$0x2a, (%rsp)
     b1a:      	jne	0xbc0 <generic_kprobe_process_event+0x870>
     b20:      	movq	%r12, %rax
     b23:      	addq	$0x6430, %rax           # imm = 0x6430
     b29:      	movq	$0x0, 0x6430(%r12)
     b35:      	movq	%rbp, 0x6438(%r12)
     b3d:      	jmp	0xddb <generic_kprobe_process_event+0xa8b>
     b42:      	movq	0x8(%rsp), %rax
     b47:      	movq	%rax, 0x18(%rsp)
     b4c:      	cmpl	$0x15, (%rsp)
     b50:      	jg	0xc8b <generic_kprobe_process_event+0x93b>
     b56:      	movl	$0x1fe, %r15d           # imm = 0x1FE
     b5c:      	cmpl	$0x9, (%rsp)
     b60:      	jle	0xd13 <generic_kprobe_process_event+0x9c3>
     b66:      	cmpl	$0x10, (%rsp)
     b6a:      	jle	0xe9c <generic_kprobe_process_event+0xb4c>
     b70:      	cmpl	$0x12, (%rsp)
     b74:      	jle	0xfc7 <generic_kprobe_process_event+0xc77>
     b7a:      	cmpl	$0x13, (%rsp)
     b7e:      	je	0xff3 <generic_kprobe_process_event+0xca3>
     b84:      	cmpl	$0x14, (%rsp)
     b88:      	je	0x10d1 <generic_kprobe_process_event+0xd81>
     b8e:      	cmpl	$0x15, (%rsp)
     b92:      	jne	0x10e3 <generic_kprobe_process_event+0xd93>
     b98:      	movl	$0x20, %r15d
     b9e:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
     ba3:      	cmpl	$0xf, (%rsp)
     ba7:      	je	0xde5 <generic_kprobe_process_event+0xa95>
     bad:      	cmpl	$0x10, (%rsp)
     bb1:      	jne	0xbc0 <generic_kprobe_process_event+0x870>
     bb3:      	leaq	0xb8(%rsp), %r15
     bbb:      	jmp	0xd74 <generic_kprobe_process_event+0xa24>
     bc0:      	xorl	%esi, %esi
     bc2:      	movq	0xa8(%rsp), %r13
     bca:      	addl	%r13d, %esi
     bcd:      	movl	%esi, %r13d
     bd0:      	movq	0x100(%rsp), %r12
     bd8:      	movl	%r13d, 0x4(%r14)
     bdc:      	cmpl	$0x3, %r12d
     be0:      	jg	0xc51 <generic_kprobe_process_event+0x901>
     be2:      	movl	$0x0, 0x68(%rsp)
     bea:      	movq	(%rip), %rdi            # 0xbf1 <generic_kprobe_process_event+0x8a1>
     bf1:      	leaq	0x68(%rsp), %rsi
     bf6:      	movl	$0x1, %eax
     bfb:      	callq	*%rax
     bfd:      	testq	%rax, %rax
     c00:      	je	0xc51 <generic_kprobe_process_event+0x901>
     c02:      	movq	%rax, %rsi
     c05:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     c0c:      	movq	(%rip), %rdi            # 0xc13 <generic_kprobe_process_event+0x8c3>
     c13:      	movl	$0x1, %eax
     c18:      	callq	*%rax
     c1a:      	testq	%rax, %rax
     c1d:      	je	0xc51 <generic_kprobe_process_event+0x901>
     c1f:      	incl	%r12d
     c22:      	movl	%r12d, %ecx
     c25:      	andl	$0x7, %ecx
     c28:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     c2d:      	je	0xc51 <generic_kprobe_process_event+0x901>
     c2f:      	movl	%r12d, 0x5efc(%r14)
     c36:      	movq	(%rip), %rsi            # 0xc3d <generic_kprobe_process_event+0x8ed>
     c3d:      	movl	$0x1, %ecx
     c42:      	movl	$0xc, %eax
     c47:      	movq	%rbx, %rdi
     c4a:      	movl	$0x1, %edx
     c4f:      	callq	*%rax
     c51:      	movl	$0x0, 0x5efc(%r14)
     c5c:      	movq	(%rip), %rsi            # 0xc63 <generic_kprobe_process_event+0x913>
     c63:      	movl	$0x3, %ecx
     c68:      	movl	$0xc, %eax
     c6d:      	movq	%rbx, %rdi
     c70:      	movl	$0x3, %edx
     c75:      	callq	*%rax
     c77:      	xorl	%eax, %eax
     c79:      	addq	$0x108, %rsp            # imm = 0x108
     c80:      	popq	%rbx
     c81:      	popq	%r12
     c83:      	popq	%r13
     c85:      	popq	%r14
     c87:      	popq	%r15
     c89:      	popq	%rbp
     c8a:      	retq
     c8b:      	cmpl	$0x20, (%rsp)
     c8f:      	jg	0xcf4 <generic_kprobe_process_event+0x9a4>
     c91:      	cmpl	$0x1a, (%rsp)
     c95:      	jg	0xec4 <generic_kprobe_process_event+0xb74>
     c9b:      	cmpl	$0x16, (%rsp)
     c9f:      	je	0xf28 <generic_kprobe_process_event+0xbd8>
     ca5:      	cmpl	$0x17, (%rsp)
     ca9:      	je	0xeb9 <generic_kprobe_process_event+0xb69>
     caf:      	cmpl	$0x1a, (%rsp)
     cb3:      	je	0x100e <generic_kprobe_process_event+0xcbe>
     cb9:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     cbe:      	cmpl	$0x3, %edx
     cc1:      	jg	0xe6e <generic_kprobe_process_event+0xb1e>
     cc7:      	cmpl	$0x1, %edx
     cca:      	jg	0xf58 <generic_kprobe_process_event+0xc08>
     cd0:      	testl	%edx, %edx
     cd2:      	je	0x1060 <generic_kprobe_process_event+0xd10>
     cd8:      	cmpl	$0x1, %edx
     cdb:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     ce1:      	movl	$0x40, %ecx
     ce6:      	subl	%r13d, %ecx
     ce9:      	bzhiq	%rcx, 0x8(%rbx), %rcx
     cef:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     cf4:      	cmpl	$0x26, (%rsp)
     cf8:      	jg	0xedf <generic_kprobe_process_event+0xb8f>
     cfe:      	movq	(%rsp), %rax
     d02:      	addl	$-0x21, %eax
     d05:      	cmpl	$0x4, %eax
     d08:      	jb	0xeb9 <generic_kprobe_process_event+0xb69>
     d0e:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     d13:      	cmpl	$0x4, (%rsp)
     d17:      	jg	0xefe <generic_kprobe_process_event+0xbae>
     d1d:      	movq	(%rsp), %rax
     d21:      	addl	$-0x2, %eax
     d24:      	cmpl	$0x2, %eax
     d27:      	jb	0xed4 <generic_kprobe_process_event+0xb84>
     d2d:      	cmpl	$0x1, (%rsp)
     d31:      	je	0xed4 <generic_kprobe_process_event+0xb84>
     d37:      	cmpl	$0x4, (%rsp)
     d3b:      	je	0xeb9 <generic_kprobe_process_event+0xb69>
     d41:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     d46:      	leaq	0xb8(%rsp), %r15
     d4e:      	movl	$0x8, %ecx
     d53:      	movl	$0x4, %eax
     d58:      	movq	0x68(%rsp), %rdx
     d5d:      	movq	%r15, %rdi
     d60:      	movl	$0x8, %esi
     d65:      	callq	*%rax
     d67:      	movq	0xb8(%rsp), %rax
     d6f:      	movq	%rax, 0x68(%rsp)
     d74:      	movq	0xa8(%rsp), %r13
     d7c:      	leaq	0x68(%rsp), %rdx
     d81:      	movl	$0x8, %ecx
     d86:      	movl	$0x4, %eax
     d8b:      	leaq	0xb8(%rsp), %rdi
     d93:      	movl	$0x8, %esi
     d98:      	callq	*%rax
     d9a:      	movq	0xb8(%rsp), %rax
     da2:      	addq	$0x40, %rax
     da6:      	jmp	0xe16 <generic_kprobe_process_event+0xac6>
     da8:      	addq	$0x40, %rbp
     dac:      	movq	%rbp, 0x68(%rsp)
     db1:      	leaq	0xb8(%rsp), %rdi
     db9:      	movl	$0x8, %ecx
     dbe:      	movl	$0x4, %eax
     dc3:      	movq	0x68(%rsp), %rdx
     dc8:      	movl	$0x8, %esi
     dcd:      	callq	*%rax
     dcf:      	movq	0xb8(%rsp), %rax
     dd7:      	addq	$0x40, %rax
     ddb:      	movq	0xa8(%rsp), %r13
     de3:      	jmp	0xe16 <generic_kprobe_process_event+0xac6>
     de5:      	leaq	0x58(%rsp), %rdi
     dea:      	leaq	0x68(%rsp), %rdx
     def:      	movl	$0x8, %ecx
     df4:      	movl	$0x4, %eax
     df9:      	movl	$0x8, %esi
     dfe:      	callq	*%rax
     e00:      	movq	0x58(%rsp), %rax
     e05:      	testq	%rax, %rax
     e08:      	movq	0xa8(%rsp), %r13
     e10:      	je	0xf21 <generic_kprobe_process_event+0xbd1>
     e16:      	movq	%rax, 0x6440(%r12)
     e1e:      	movq	(%rip), %rsi            # 0xe25 <generic_kprobe_process_event+0xad5>
     e25:      	movl	$0x6, %ecx
     e2a:      	movl	$0xc, %eax
     e2f:      	movq	%rbx, %rdi
     e32:      	movl	$0x6, %edx
     e37:      	callq	*%rax
     e39:      	xorl	%esi, %esi
     e3b:      	jmp	0xbca <generic_kprobe_process_event+0x87a>
     e40:      	cmpl	$0x9, %edx
     e43:      	jg	0xf33 <generic_kprobe_process_event+0xbe3>
     e49:      	cmpl	$0x8, %edx
     e4c:      	je	0x1024 <generic_kprobe_process_event+0xcd4>
     e52:      	cmpl	$0x9, %edx
     e55:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     e5b:      	movl	$0x40, %ecx
     e60:      	subl	%r13d, %ecx
     e63:      	bzhiq	%rcx, 0x48(%rbx), %rcx
     e69:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     e6e:      	cmpl	$0x5, %edx
     e71:      	jg	0xf7d <generic_kprobe_process_event+0xc2d>
     e77:      	cmpl	$0x4, %edx
     e7a:      	je	0x1072 <generic_kprobe_process_event+0xd22>
     e80:      	cmpl	$0x5, %edx
     e83:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     e89:      	movl	$0x40, %ecx
     e8e:      	subl	%r13d, %ecx
     e91:      	bzhiq	%rcx, 0x28(%rbx), %rcx
     e97:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     e9c:      	movq	(%rsp), %rax
     ea0:      	addl	$-0xa, %eax
     ea3:      	cmpl	$0x2, %eax
     ea6:      	jb	0xeb9 <generic_kprobe_process_event+0xb69>
     ea8:      	movq	(%rsp), %rax
     eac:      	addl	$-0xc, %eax
     eaf:      	cmpl	$0x2, %eax
     eb2:      	jb	0xed4 <generic_kprobe_process_event+0xb84>
     eb4:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     eb9:      	movl	$0x8, %r15d
     ebf:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
     ec4:      	movq	(%rsp), %rax
     ec8:      	addl	$-0x1d, %eax
     ecb:      	cmpl	$0x4, %eax
     ece:      	jae	0x10d9 <generic_kprobe_process_event+0xd89>
     ed4:      	movl	$0x4, %r15d
     eda:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
     edf:      	cmpl	$0x28, (%rsp)
     ee3:      	jg	0xfe3 <generic_kprobe_process_event+0xc93>
     ee9:      	cmpl	$0x27, (%rsp)
     eed:      	je	0xf28 <generic_kprobe_process_event+0xbd8>
     eef:      	cmpl	$0x28, (%rsp)
     ef3:      	je	0xff3 <generic_kprobe_process_event+0xca3>
     ef9:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     efe:      	cmpl	$0x6, (%rsp)
     f02:      	jg	0xffe <generic_kprobe_process_event+0xcae>
     f08:      	cmpl	$0x5, (%rsp)
     f0c:      	je	0x1019 <generic_kprobe_process_event+0xcc9>
     f12:      	cmpl	$0x6, (%rsp)
     f16:      	je	0x10e6 <generic_kprobe_process_event+0xd96>
     f1c:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     f21:      	xorl	%esi, %esi
     f23:      	jmp	0xbca <generic_kprobe_process_event+0x87a>
     f28:      	movl	$0x10, %r15d
     f2e:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
     f33:      	cmpl	$0xa, %edx
     f36:      	je	0x1037 <generic_kprobe_process_event+0xce7>
     f3c:      	cmpl	$0xb, %edx
     f3f:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     f45:      	movl	$0x40, %ecx
     f4a:      	subl	%r13d, %ecx
     f4d:      	bzhiq	%rcx, 0x58(%rbx), %rcx
     f53:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     f58:      	cmpl	$0x2, %edx
     f5b:      	je	0x1085 <generic_kprobe_process_event+0xd35>
     f61:      	cmpl	$0x3, %edx
     f64:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     f6a:      	movl	$0x40, %ecx
     f6f:      	subl	%r13d, %ecx
     f72:      	bzhiq	%rcx, 0x18(%rbx), %rcx
     f78:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     f7d:      	cmpl	$0x6, %edx
     f80:      	je	0x1098 <generic_kprobe_process_event+0xd48>
     f86:      	cmpl	$0x7, %edx
     f89:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     f8f:      	movl	$0x40, %ecx
     f94:      	subl	%r13d, %ecx
     f97:      	bzhiq	%rcx, 0x38(%rbx), %rcx
     f9d:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     fa2:      	cmpl	$0xc, %edx
     fa5:      	je	0x10be <generic_kprobe_process_event+0xd6e>
     fab:      	cmpl	$0xd, %edx
     fae:      	jne	0x55c <generic_kprobe_process_event+0x20c>
     fb4:      	movl	$0x40, %ecx
     fb9:      	subl	%r13d, %ecx
     fbc:      	bzhiq	%rcx, 0x68(%rbx), %rcx
     fc2:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
     fc7:      	cmpl	$0x11, (%rsp)
     fcb:      	je	0x10e6 <generic_kprobe_process_event+0xd96>
     fd1:      	movq	%rdi, %r15
     fd4:      	cmpl	$0x12, (%rsp)
     fd8:      	je	0x10e6 <generic_kprobe_process_event+0xd96>
     fde:      	jmp	0x10e3 <generic_kprobe_process_event+0xd93>
     fe3:      	cmpl	$0x29, (%rsp)
     fe7:      	je	0x1019 <generic_kprobe_process_event+0xcc9>
     fe9:      	cmpl	$0x2b, (%rsp)
     fed:      	jne	0x10e3 <generic_kprobe_process_event+0xd93>
     ff3:      	movl	$0x18, %r15d
     ff9:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
     ffe:      	cmpl	$0x7, (%rsp)
    1002:      	je	0x1019 <generic_kprobe_process_event+0xcc9>
    1004:      	cmpl	$0x8, (%rsp)
    1008:      	jne	0x10e3 <generic_kprobe_process_event+0xd93>
    100e:      	movl	$0x50, %r15d
    1014:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
    1019:      	movl	$0x40, %r15d
    101f:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
    1024:      	movl	$0x40, %ecx
    1029:      	subl	%r13d, %ecx
    102c:      	bzhiq	%rcx, 0x40(%rbx), %rcx
    1032:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    1037:      	movl	$0x40, %ecx
    103c:      	subl	%r13d, %ecx
    103f:      	bzhiq	%rcx, 0x50(%rbx), %rcx
    1045:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    104a:      	movl	$0x40, %ecx
    104f:      	subl	%r13d, %ecx
    1052:      	bzhiq	%rcx, 0x80(%rbx), %rcx
    105b:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    1060:      	movl	$0x40, %ecx
    1065:      	subl	%r13d, %ecx
    1068:      	bzhiq	%rcx, (%rbx), %rcx
    106d:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    1072:      	movl	$0x40, %ecx
    1077:      	subl	%r13d, %ecx
    107a:      	bzhiq	%rcx, 0x20(%rbx), %rcx
    1080:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    1085:      	movl	$0x40, %ecx
    108a:      	subl	%r13d, %ecx
    108d:      	bzhiq	%rcx, 0x10(%rbx), %rcx
    1093:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    1098:      	movl	$0x40, %ecx
    109d:      	subl	%r13d, %ecx
    10a0:      	bzhiq	%rcx, 0x30(%rbx), %rcx
    10a6:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    10ab:      	movl	$0x40, %ecx
    10b0:      	subl	%r13d, %ecx
    10b3:      	bzhiq	%rcx, 0x70(%rbx), %rcx
    10b9:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    10be:      	movl	$0x40, %ecx
    10c3:      	subl	%r13d, %ecx
    10c6:      	bzhiq	%rcx, 0x60(%rbx), %rcx
    10cc:      	jmp	0x55c <generic_kprobe_process_event+0x20c>
    10d1:      	movl	$0x98, %r15d
    10d7:      	jmp	0x10e6 <generic_kprobe_process_event+0xd96>
    10d9:      	cmpl	$0x1b, (%rsp)
    10dd:      	je	0x100e <generic_kprobe_process_event+0xcbe>
    10e3:      	xorl	%r15d, %r15d
    10e6:      	movq	%r8, %r12
    10e9:      	movq	%rdi, 0x40(%rsp)
    10ee:      	movl	$0x0, 0xfc(%rsp)
    10f9:      	movq	(%rip), %rdi            # 0x1100 <generic_kprobe_process_event+0xdb0>
    1100:      	leaq	0xfc(%rsp), %rsi
    1108:      	movl	$0x1, %eax
    110d:      	callq	*%rax
    110f:      	xorl	%esi, %esi
    1111:      	testq	%rax, %rax
    1114:      	je	0xbc2 <generic_kprobe_process_event+0x872>
    111a:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
    111f:      	subq	%r15, %rcx
    1122:      	cmpq	0xa8(%rsp), %rcx
    112a:      	jbe	0xbc2 <generic_kprobe_process_event+0x872>
    1130:      	movq	0x20(%rsp), %rsi
    1135:      	movl	0x5ea0(%rax,%rsi,4), %ecx
    113c:      	movq	0xa8(%rsp), %rdx
    1144:      	movl	%ecx, 0x90(%rax,%rdx)
    114b:      	addq	$0x4, %rdx
    114f:      	movq	%rdx, 0x5e78(%rax,%rsi,8)
    1157:      	movl	$0x4, %esi
    115c:      	testl	%ecx, %ecx
    115e:      	jne	0xbc2 <generic_kprobe_process_event+0x872>
    1164:      	movq	%rax, %r15
    1167:      	addq	$0x90, %r15
    116e:      	addq	%rdx, %r15
    1171:      	movq	0x18(%rsp), %rsi
    1176:      	movq	%rsi, 0x68(%rsp)
    117b:      	movq	$0x0, 0x58(%rsp)
    1184:      	cmpl	$0x17, (%rsp)
    1188:      	movq	%rax, 0x38(%rsp)
    118d:      	jle	0x11ca <generic_kprobe_process_event+0xe7a>
    118f:      	cmpl	$0x18, (%rsp)
    1193:      	je	0x11e5 <generic_kprobe_process_event+0xe95>
    1195:      	cmpl	$0x25, (%rsp)
    1199:      	je	0x1223 <generic_kprobe_process_event+0xed3>
    119f:      	cmpl	$0x2a, (%rsp)
    11a3:      	jne	0x1848 <generic_kprobe_process_event+0x14f8>
    11a9:      	movq	$0x0, 0xb8(%rsp)
    11b5:      	movq	%rsi, 0xc0(%rsp)
    11bd:      	leaq	0xb8(%rsp), %rax
    11c5:      	jmp	0x1250 <generic_kprobe_process_event+0xf00>
    11ca:      	cmpl	$0xf, (%rsp)
    11ce:      	je	0x176e <generic_kprobe_process_event+0x141e>
    11d4:      	cmpl	$0x10, (%rsp)
    11d8:      	jne	0x1848 <generic_kprobe_process_event+0x14f8>
    11de:      	leaq	0x48(%rsp), %r12
    11e3:      	jmp	0x120d <generic_kprobe_process_event+0xebd>
    11e5:      	leaq	0x48(%rsp), %r12
    11ea:      	movl	$0x8, %ecx
    11ef:      	movl	$0x4, %eax
    11f4:      	movq	0x68(%rsp), %rdx
    11f9:      	movq	%r12, %rdi
    11fc:      	movl	$0x8, %esi
    1201:      	callq	*%rax
    1203:      	movq	0x48(%rsp), %rax
    1208:      	movq	%rax, 0x68(%rsp)
    120d:      	leaq	0x68(%rsp), %rdx
    1212:      	movl	$0x8, %ecx
    1217:      	movl	$0x4, %eax
    121c:      	leaq	0x48(%rsp), %rdi
    1221:      	jmp	0x1240 <generic_kprobe_process_event+0xef0>
    1223:      	addq	$0x40, %rsi
    1227:      	movq	%rsi, 0x68(%rsp)
    122c:      	leaq	0x48(%rsp), %rdi
    1231:      	movl	$0x8, %ecx
    1236:      	movl	$0x4, %eax
    123b:      	movq	0x68(%rsp), %rdx
    1240:      	movl	$0x8, %esi
    1245:      	callq	*%rax
    1247:      	movq	0x48(%rsp), %rax
    124c:      	addq	$0x40, %rax
    1250:      	movq	%rax, 0xd0(%rsp)
    1258:      	movl	$0x0, 0xe4(%rsp)
    1263:      	movq	(%rip), %rdi            # 0x126a <generic_kprobe_process_event+0xf1a>
    126a:      	leaq	0xe4(%rsp), %rsi
    1272:      	movl	$0x1, %eax
    1277:      	callq	*%rax
    1279:      	testq	%rax, %rax
    127c:      	je	0x1683 <generic_kprobe_process_event+0x1333>
    1282:      	movq	%rax, %r12
    1285:      	movq	%r15, 0x30(%rsp)
    128a:      	addq	$0x1000, %rax           # imm = 0x1000
    1290:      	movq	%rax, 0x40(%rsp)
    1295:      	movl	$0x23, %eax
    129a:      	callq	*%rax
    129c:      	leaq	0xd50(%rax), %rdx
    12a3:      	leaq	0xd8(%rsp), %rdi
    12ab:      	movl	$0x8, %ecx
    12b0:      	movl	$0x4, %eax
    12b5:      	movl	$0x8, %esi
    12ba:      	callq	*%rax
    12bc:      	movq	0xd8(%rsp), %rbp
    12c4:      	movq	0xd0(%rsp), %rax
    12cc:      	leaq	0x8(%rax), %rdx
    12d0:      	leaq	0xe8(%rsp), %rdi
    12d8:      	movl	$0x8, %ecx
    12dd:      	movl	$0x4, %eax
    12e2:      	leaq	0x18(%rbp), %rcx
    12e6:      	movq	%rcx, (%rsp)
    12ea:      	movl	$0x8, %esi
    12ef:      	movq	%rdx, 0x18(%rsp)
    12f4:      	callq	*%rax
    12f6:      	movq	0xe8(%rsp), %r13
    12fe:      	leaq	0x10(%r13), %rdx
    1302:      	leaq	0x68(%rsp), %rdi
    1307:      	movl	$0x8, %ecx
    130c:      	movl	$0x4, %eax
    1311:      	movl	$0x8, %esi
    1316:      	callq	*%rax
    1318:      	cmpq	$0x0, 0x68(%rsp)
    131e:      	movl	$0x1000, %r15d          # imm = 0x1000
    1324:      	je	0x132d <generic_kprobe_process_event+0xfdd>
    1326:      	movq	0x40(%rsp), %rcx
    132b:      	jmp	0x1380 <generic_kprobe_process_event+0x1030>
    132d:      	leaq	0x18(%r13), %rdx
    1331:      	leaq	0x68(%rsp), %rdi
    1336:      	movl	$0x8, %ecx
    133b:      	movl	$0x4, %eax
    1340:      	movl	$0x8, %esi
    1345:      	callq	*%rax
    1347:      	cmpq	%r13, 0x68(%rsp)
    134c:      	movq	0x40(%rsp), %rcx
    1351:      	je	0x1380 <generic_kprobe_process_event+0x1030>
    1353:      	movq	%r12, %rcx
    1356:      	addq	$0xff6, %rcx            # imm = 0xFF6
    135d:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    1367:      	movq	%rax, 0xff6(%r12)
    136f:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    137a:      	movl	$0xff6, %r15d           # imm = 0xFF6
    1380:      	movq	$0x0, 0x70(%rsp)
    1389:      	movq	$0x0, 0x68(%rsp)
    1392:      	movq	%r12, 0x78(%rsp)
    1397:      	movq	$0x0, 0x80(%rsp)
    13a3:      	movq	$0x0, 0x88(%rsp)
    13af:      	movq	$0x0, 0x90(%rsp)
    13bb:      	movq	%rcx, 0x40(%rsp)
    13c0:      	movq	%rcx, 0x98(%rsp)
    13c8:      	movl	%r15d, 0xa0(%rsp)
    13d0:      	movb	$0x0, 0xa4(%rsp)
    13d8:      	addq	$0x20, %rbp
    13dc:      	leaq	0x68(%rsp), %rdi
    13e1:      	movl	$0x8, %ecx
    13e6:      	movl	$0x4, %eax
    13eb:      	leaq	0x70(%rsp), %r12
    13f0:      	leaq	0x80(%rsp), %r15
    13f8:      	leaq	0x88(%rsp), %r13
    1400:      	movl	$0x8, %esi
    1405:      	movq	%rbp, %rdx
    1408:      	callq	*%rax
    140a:      	movl	$0x8, %ecx
    140f:      	movl	$0x4, %eax
    1414:      	movq	(%rsp), %rdx
    1418:      	movq	%r12, %rdi
    141b:      	movl	$0x8, %esi
    1420:      	callq	*%rax
    1422:      	movl	$0x8, %ecx
    1427:      	movl	$0x4, %eax
    142c:      	movq	0x18(%rsp), %rdx
    1431:      	movq	%r15, %rdi
    1434:      	movl	$0x8, %esi
    1439:      	callq	*%rax
    143b:      	movl	$0x8, %ecx
    1440:      	movl	$0x4, %eax
    1445:      	movq	0xd0(%rsp), %rdx
    144d:      	movq	%r13, %rdi
    1450:      	movl	$0x8, %esi
    1455:      	callq	*%rax
    1457:      	movq	0x88(%rsp), %rax
    145f:      	addq	$-0x20, %rax
    1463:      	movq	%rax, 0x90(%rsp)
    146b:      	movl	$0x80, %eax
    1470:      	movl	$0x8, %r15d
    1476:      	movq	0x80(%rsp), %r13
    147e:      	movq	0x88(%rsp), %rdx
    1486:      	movq	0x90(%rsp), %r12
    148e:      	cmpq	0x68(%rsp), %r13
    1493:      	jne	0x14a0 <generic_kprobe_process_event+0x1150>
    1495:      	cmpq	0x70(%rsp), %rdx
    149a:      	je	0x1632 <generic_kprobe_process_event+0x12e2>
    14a0:      	movl	%eax, (%rsp)
    14a3:      	movl	$0x4, %eax
    14a8:      	leaq	0xc8(%rsp), %rdi
    14b0:      	movl	$0x8, %esi
    14b5:      	callq	*%rax
    14b7:      	cmpq	0xc8(%rsp), %r13
    14bf:      	je	0x15c7 <generic_kprobe_process_event+0x1277>
    14c5:      	leaq	0x18(%r13), %rbp
    14c9:      	movl	$0x4, %eax
    14ce:      	leaq	0x48(%rsp), %rdi
    14d3:      	movl	$0x8, %esi
    14d8:      	movq	%rbp, %rdx
    14db:      	callq	*%rax
    14dd:      	cmpq	%r13, 0x48(%rsp)
    14e2:      	je	0x15c7 <generic_kprobe_process_event+0x1277>
    14e8:      	movl	$0x4, %eax
    14ed:      	leaq	0x50(%rsp), %rdi
    14f2:      	movl	$0x8, %esi
    14f7:      	movq	%rbp, %rdx
    14fa:      	callq	*%rax
    14fc:      	addq	$0x20, %r13
    1500:      	movl	$0x4, %eax
    1505:      	leaq	0x58(%rsp), %rdi
    150a:      	movl	$0x10, %ecx
    150f:      	movl	$0x10, %esi
    1514:      	movq	%r13, %rdx
    1517:      	callq	*%rax
    1519:      	movq	0x78(%rsp), %r12
    151e:      	movq	0x98(%rsp), %rax
    1526:      	movl	0x5c(%rsp), %ebp
    152a:      	subq	%r12, %rax
    152d:      	movl	0xa0(%rsp), %r13d
    1535:      	movl	%ebp, %edx
    1537:      	subl	%r13d, %edx
    153a:      	movl	$0x0, %ecx
    153f:      	cmovbl	%ecx, %edx
    1542:      	addq	0x60(%rsp), %rdx
    1547:      	xorl	%esi, %esi
    1549:      	cmpl	%ebp, %r13d
    154c:      	seta	%sil
    1550:      	movl	%ebp, %ecx
    1552:      	cmovbl	%r13d, %ecx
    1556:      	addl	%ecx, %esi
    1558:      	movl	%r13d, %edi
    155b:      	subl	%esi, %edi
    155d:      	movl	%edi, 0xa0(%rsp)
    1564:      	subq	%rsi, %rax
    1567:      	jb	0x163a <generic_kprobe_process_event+0x12ea>
    156d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1573:      	ja	0x163a <generic_kprobe_process_event+0x12ea>
    1579:      	cmpl	%ebp, %r13d
    157c:      	jbe	0x1583 <generic_kprobe_process_event+0x1233>
    157e:      	movb	$0x2f, (%r12,%rax)
    1583:      	xorl	%edi, %edi
    1585:      	cmpl	%ebp, %r13d
    1588:      	seta	%dil
    158c:      	movzbl	%cl, %esi
    158f:      	addq	%rax, %r12
    1592:      	addq	%r12, %rdi
    1595:      	movl	$0x4, %eax
    159a:      	callq	*%rax
    159c:      	movq	%r12, 0x98(%rsp)
    15a4:      	cmpl	%ebp, %r13d
    15a7:      	jbe	0x163a <generic_kprobe_process_event+0x12ea>
    15ad:      	movq	0x50(%rsp), %rax
    15b2:      	movq	%rax, 0x80(%rsp)
    15ba:      	movl	(%rsp), %eax
    15bd:      	decl	%eax
    15bf:      	jne	0x1476 <generic_kprobe_process_event+0x1126>
    15c5:      	jmp	0x163a <generic_kprobe_process_event+0x12ea>
    15c7:      	leaq	0x10(%r12), %rdx
    15cc:      	movl	$0x4, %eax
    15d1:      	leaq	0x48(%rsp), %rdi
    15d6:      	movl	$0x8, %esi
    15db:      	callq	*%rax
    15dd:      	movq	0x90(%rsp), %rax
    15e5:      	cmpq	0x48(%rsp), %rax
    15ea:      	movl	$0x8, %ecx
    15ef:      	je	0x1632 <generic_kprobe_process_event+0x12e2>
    15f1:      	addq	$0x18, %r12
    15f5:      	movl	$0x4, %eax
    15fa:      	leaq	0x80(%rsp), %rdi
    1602:      	movl	$0x8, %esi
    1607:      	movq	%r12, %rdx
    160a:      	callq	*%rax
    160c:      	movq	0x48(%rsp), %rax
    1611:      	movq	%rax, 0x90(%rsp)
    1619:      	addq	$0x20, %rax
    161d:      	movq	%rax, 0x88(%rsp)
    1625:      	movl	(%rsp), %eax
    1628:      	decl	%eax
    162a:      	jne	0x1476 <generic_kprobe_process_event+0x1126>
    1630:      	jmp	0x163a <generic_kprobe_process_event+0x12ea>
    1632:      	movb	$0x1, 0xa4(%rsp)
    163a:      	movq	0x98(%rsp), %rax
    1642:      	movq	0x40(%rsp), %rdx
    1647:      	cmpq	%rdx, %rax
    164a:      	je	0x168b <generic_kprobe_process_event+0x133b>
    164c:      	xorl	%ebp, %ebp
    164e:      	cmpb	$0x0, 0xa4(%rsp)
    1656:      	sete	%cl
    1659:      	movl	0xa0(%rsp), %edx
    1660:      	movl	$0x1000, %r13d          # imm = 0x1000
    1666:      	subl	%edx, %r13d
    1669:      	testl	%edx, %edx
    166b:      	cmovlel	%edx, %r13d
    166f:      	testq	%rax, %rax
    1672:      	movq	0x30(%rsp), %r15
    1677:      	je	0x1683 <generic_kprobe_process_event+0x1333>
    1679:      	movb	%cl, %bpl
    167c:      	addl	%ebp, %ebp
    167e:      	movq	%rax, %rdx
    1681:      	jmp	0x1695 <generic_kprobe_process_event+0x1345>
    1683:      	xorl	%r13d, %r13d
    1686:      	jmp	0x1738 <generic_kprobe_process_event+0x13e8>
    168b:      	xorl	%r13d, %r13d
    168e:      	xorl	%ebp, %ebp
    1690:      	movq	0x30(%rsp), %r15
    1695:      	leaq	0x4(%r15), %rdi
    1699:      	andl	$0xfff, %r13d           # imm = 0xFFF
    16a0:      	movl	$0x4, %eax
    16a5:      	movl	%r13d, %esi
    16a8:      	callq	*%rax
    16aa:      	movl	%r13d, (%r15)
    16ad:      	leaq	0x68(%rsp), %rdi
    16b2:      	movl	$0x8, %ecx
    16b7:      	movl	$0x4, %eax
    16bc:      	movq	0x18(%rsp), %rdx
    16c1:      	movl	$0x8, %esi
    16c6:      	callq	*%rax
    16c8:      	movq	0x68(%rsp), %rcx
    16cd:      	addq	$0x30, %rcx
    16d1:      	leaq	0x58(%rsp), %rdi
    16d6:      	movl	$0x8, %edx
    16db:      	movl	$0x4, %eax
    16e0:      	movq	0x68(%rsp), %rdx
    16e5:      	addq	$0x30, %rdx
    16e9:      	movl	$0x8, %esi
    16ee:      	callq	*%rax
    16f0:      	movq	0x58(%rsp), %rcx
    16f5:      	leaq	0x48(%rsp), %rdi
    16fa:      	movl	$0x2, %edx
    16ff:      	movl	$0x4, %eax
    1704:      	movq	0x58(%rsp), %rdx
    1709:      	movl	$0x2, %esi
    170e:      	callq	*%rax
    1710:      	movl	%ebp, 0x4(%r15,%r13)
    1715:      	movzwl	0x48(%rsp), %eax
    171a:      	movw	%ax, 0x8(%r15,%r13)
    1720:      	addl	$0xa, %r13d
    1724:      	movq	0x38(%rsp), %rax
    1729:      	movq	0x20(%rsp), %rcx
    172e:      	movl	$0x4, %esi
    1733:      	testl	%r13d, %r13d
    1736:      	js	0x174b <generic_kprobe_process_event+0x13fb>
    1738:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    173f:      	addq	$0x4, %r13
    1743:      	movq	%r13, %rsi
    1746:      	jmp	0xbc2 <generic_kprobe_process_event+0x872>
    174b:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    1756:      	movq	0xa8(%rsp), %rcx
    175e:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    1769:      	jmp	0xbc2 <generic_kprobe_process_event+0x872>
    176e:      	movq	%rdx, 0xb0(%rsp)
    1776:      	leaq	0x58(%rsp), %rdi
    177b:      	leaq	0x68(%rsp), %rdx
    1780:      	movl	$0x8, %ecx
    1785:      	movl	$0x4, %eax
    178a:      	movl	$0x8, %esi
    178f:      	callq	*%rax
    1791:      	movq	0x58(%rsp), %rax
    1796:      	movq	%rax, 0xd0(%rsp)
    179e:      	testq	%rax, %rax
    17a1:      	jne	0x1258 <generic_kprobe_process_event+0xf08>
    17a7:      	movl	$0x0, 0xe8(%rsp)
    17b2:      	movq	(%rip), %rdi            # 0x17b9 <generic_kprobe_process_event+0x1469>
    17b9:      	leaq	0xe8(%rsp), %rsi
    17c1:      	movl	$0x1, %eax
    17c6:      	callq	*%rax
    17c8:      	testq	%rax, %rax
    17cb:      	je	0x1a65 <generic_kprobe_process_event+0x1715>
    17d1:      	movq	%rax, %rcx
    17d4:      	cmpl	$0x19, (%rsp)
    17d8:      	movq	%rbx, 0x10(%rsp)
    17dd:      	movq	%r14, 0x28(%rsp)
    17e2:      	jg	0x1b74 <generic_kprobe_process_event+0x1824>
    17e8:      	cmpl	$0x12, (%rsp)
    17ec:      	jle	0x1bbd <generic_kprobe_process_event+0x186d>
    17f2:      	movq	(%rsp), %rcx
    17f6:      	movq	%rcx, %rax
    17f9:      	cmpl	$0x14, %ecx
    17fc:      	jle	0x205e <generic_kprobe_process_event+0x1d0e>
    1802:      	cmpl	$0x15, %eax
    1805:      	je	0x28da <generic_kprobe_process_event+0x258a>
    180b:      	cmpl	$0x16, %eax
    180e:      	je	0x2852 <generic_kprobe_process_event+0x2502>
    1814:      	cmpl	$0x17, %eax
    1817:      	movq	0x10(%rsp), %rbx
    181c:      	movq	0x28(%rsp), %r14
    1821:      	movl	$0x0, %r13d
    1827:      	jne	0x1724 <generic_kprobe_process_event+0x13d4>
    182d:      	movl	$0x0, 0x4(%r15)
    1835:      	movq	0x18(%rsp), %rax
    183a:      	movl	%eax, (%r15)
    183d:      	movl	$0x8, %r13d
    1843:      	jmp	0x1724 <generic_kprobe_process_event+0x13d4>
    1848:      	movq	%rdx, 0xb0(%rsp)
    1850:      	cmpl	$0x28, (%rsp)
    1854:      	ja	0x17a7 <generic_kprobe_process_event+0x1457>
    185a:      	movabsq	$0x1c1f2027cf2, %rax    # imm = 0x1C1F2027CF2
    1864:      	btq	%rbp, %rax
    1868:      	jae	0x17a7 <generic_kprobe_process_event+0x1457>
    186e:      	movq	%rsi, 0x50(%rsp)
    1873:      	movl	$0x0, 0xe8(%rsp)
    187e:      	movq	(%rip), %rdi            # 0x1885 <generic_kprobe_process_event+0x1535>
    1885:      	leaq	0xe8(%rsp), %rsi
    188d:      	movl	$0x1, %eax
    1892:      	callq	*%rax
    1894:      	xorl	%ebp, %ebp
    1896:      	testq	%rax, %rax
    1899:      	je	0x3b3f <generic_kprobe_process_event+0x37ef>
    189f:      	cmpl	$0x10, (%rsp)
    18a3:      	movq	%r15, 0x30(%rsp)
    18a8:      	jg	0x1a2e <generic_kprobe_process_event+0x16de>
    18ae:      	cmpl	$0x9, (%rsp)
    18b2:      	jg	0x1a6d <generic_kprobe_process_event+0x171d>
    18b8:      	movq	%r14, 0x28(%rsp)
    18bd:      	movq	%rbx, 0x10(%rsp)
    18c2:      	cmpl	$0x4, (%rsp)
    18c6:      	jle	0x1c36 <generic_kprobe_process_event+0x18e6>
    18cc:      	movq	(%rsp), %rcx
    18d0:      	cmpl	$0x5, %ecx
    18d3:      	je	0x2351 <generic_kprobe_process_event+0x2001>
    18d9:      	movq	%rax, %r15
    18dc:      	movq	%rcx, %rax
    18df:      	cmpl	$0x6, %eax
    18e2:      	je	0x1aee <generic_kprobe_process_event+0x179e>
    18e8:      	cmpl	$0x7, %eax
    18eb:      	movq	0x38(%rsp), %rax
    18f0:      	movq	0x20(%rsp), %rcx
    18f5:      	movl	$0x4, %esi
    18fa:      	movq	0x10(%rsp), %rbx
    18ff:      	movq	0x28(%rsp), %r14
    1904:      	jne	0x2db7 <generic_kprobe_process_event+0x2a67>
    190a:      	movq	0x50(%rsp), %r12
    190f:      	movq	0x30(%rsp), %rbx
    1914:      	movq	%r12, 0x28(%rbx)
    1918:      	leaq	0x26(%rbx), %rdi
    191c:      	leaq	0x10(%r12), %rdx
    1921:      	movl	$0x2, %ecx
    1926:      	movl	$0x4, %eax
    192b:      	movl	$0x2, %esi
    1930:      	callq	*%rax
    1932:      	leaq	0x3a(%rbx), %rdi
    1936:      	leaq	0x12(%r12), %rdx
    193b:      	movl	$0x1, %ecx
    1940:      	movl	$0x4, %eax
    1945:      	movl	$0x1, %esi
    194a:      	callq	*%rax
    194c:      	leaq	0x38(%rbx), %rdi
    1950:      	leaq	0x226(%r12), %rdx
    1958:      	movl	$0x2, %ecx
    195d:      	movl	$0x4, %eax
    1962:      	movl	$0x2, %esi
    1967:      	callq	*%rax
    1969:      	leaq	0x24(%rbx), %rdi
    196d:      	leaq	0x224(%r12), %rdx
    1975:      	movl	$0x2, %ecx
    197a:      	movl	$0x4, %eax
    197f:      	movl	$0x2, %esi
    1984:      	callq	*%rax
    1986:      	leaq	0x30(%rbx), %rdi
    198a:      	leaq	0x21c(%r12), %rdx
    1992:      	movl	$0x4, %ecx
    1997:      	movl	$0x4, %eax
    199c:      	movl	$0x4, %esi
    19a1:      	callq	*%rax
    19a3:      	leaq	0x34(%rbx), %rdi
    19a7:      	leaq	0x218(%r12), %rdx
    19af:      	movl	$0x4, %ecx
    19b4:      	movl	$0x4, %eax
    19b9:      	movl	$0x4, %esi
    19be:      	callq	*%rax
    19c0:      	leaq	0x10(%rbx), %r13
    19c4:      	movq	$0x0, (%rbx)
    19cb:      	movq	$0x0, 0x8(%rbx)
    19d3:      	movq	$0x0, 0x10(%rbx)
    19db:      	movq	$0x0, 0x18(%rbx)
    19e3:      	movzwl	0x26(%rbx), %eax
    19e7:      	cmpl	$0xa, %eax
    19ea:      	je	0x2ba9 <generic_kprobe_process_event+0x2859>
    19f0:      	cmpl	$0x2, %eax
    19f3:      	jne	0x2bdd <generic_kprobe_process_event+0x288d>
    19f9:      	leaq	0x4(%r12), %rdx
    19fe:      	movl	$0x4, %ecx
    1a03:      	movl	$0x4, %eax
    1a08:      	movq	0x30(%rsp), %rdi
    1a0d:      	movl	$0x4, %esi
    1a12:      	callq	*%rax
    1a14:      	movl	$0x4, %ecx
    1a19:      	movl	$0x4, %eax
    1a1e:      	movq	%r13, %rdi
    1a21:      	movl	$0x4, %esi
    1a26:      	movq	%r12, %rdx
    1a29:      	jmp	0x2bdb <generic_kprobe_process_event+0x288b>
    1a2e:      	cmpl	$0x1e, (%rsp)
    1a32:      	jg	0x1b2c <generic_kprobe_process_event+0x17dc>
    1a38:      	movq	(%rsp), %rcx
    1a3c:      	cmpl	$0x1c, %ecx
    1a3f:      	jg	0x1cbe <generic_kprobe_process_event+0x196e>
    1a45:      	movq	%rax, %r15
    1a48:      	movq	%rcx, %rax
    1a4b:      	cmpl	$0x11, %eax
    1a4e:      	je	0x2506 <generic_kprobe_process_event+0x21b6>
    1a54:      	cmpl	$0x19, %eax
    1a57:      	je	0x213a <generic_kprobe_process_event+0x1dea>
    1a5d:      	cmpl	$0x1c, %eax
    1a60:      	jmp	0x1c4f <generic_kprobe_process_event+0x18ff>
    1a65:      	xorl	%r13d, %r13d
    1a68:      	jmp	0x1724 <generic_kprobe_process_event+0x13d4>
    1a6d:      	movq	(%rsp), %rax
    1a71:      	addl	$-0xa, %eax
    1a74:      	cmpl	$0x2, %eax
    1a77:      	jb	0x1c64 <generic_kprobe_process_event+0x1914>
    1a7d:      	movq	(%rsp), %rax
    1a81:      	movq	%rax, %rcx
    1a84:      	addl	$-0xc, %eax
    1a87:      	cmpl	$0x2, %eax
    1a8a:      	jb	0x1c99 <generic_kprobe_process_event+0x1949>
    1a90:      	cmpl	$0xe, %ecx
    1a93:      	movq	0x38(%rsp), %rax
    1a98:      	movq	0x20(%rsp), %rcx
    1a9d:      	movl	$0x4, %esi
    1aa2:      	jne	0x2db7 <generic_kprobe_process_event+0x2a67>
    1aa8:      	movq	%r14, 0x28(%rsp)
    1aad:      	movq	%rbx, 0x10(%rsp)
    1ab2:      	leaq	0x68(%rsp), %rdi
    1ab7:      	leaq	0x50(%rsp), %r12
    1abc:      	movl	$0x8, %ecx
    1ac1:      	movl	$0x4, %eax
    1ac6:      	movl	$0x8, %esi
    1acb:      	movq	%r12, %rdx
    1ace:      	callq	*%rax
    1ad0:      	movq	0x68(%rsp), %rcx
    1ad5:      	movl	$0x8, %edx
    1ada:      	movl	$0x4, %eax
    1adf:      	movq	0x68(%rsp), %rdx
    1ae4:      	movq	%r12, %rdi
    1ae7:      	movl	$0x8, %esi
    1aec:      	callq	*%rax
    1aee:      	movq	0x50(%rsp), %rdx
    1af3:      	movq	0x30(%rsp), %rax
    1af8:      	leaq	0x4(%rax), %rdi
    1afc:      	movl	$0x1ff, %ecx            # imm = 0x1FF
    1b01:      	movl	$0x2d, %eax
    1b06:      	movl	$0x1ff, %esi            # imm = 0x1FF
    1b0b:      	callq	*%rax
    1b0d:      	movq	%rax, %rbp
    1b10:      	testq	%rax, %rax
    1b13:      	js	0x402d <generic_kprobe_process_event+0x3cdd>
    1b19:      	leal	-0x1(%rbp), %eax
    1b1c:      	movq	0x30(%rsp), %rcx
    1b21:      	movl	%eax, (%rcx)
    1b23:      	addq	$0x3, %rbp
    1b27:      	jmp	0x402d <generic_kprobe_process_event+0x3cdd>
    1b2c:      	movq	%r14, %r12
    1b2f:      	movq	%rbx, %r15
    1b32:      	cmpl	$0x26, (%rsp)
    1b36:      	jg	0x1ce3 <generic_kprobe_process_event+0x1993>
    1b3c:      	movq	(%rsp), %rax
    1b40:      	movq	%rax, %rcx
    1b43:      	addl	$-0x1f, %eax
    1b46:      	cmpl	$0x2, %eax
    1b49:      	jae	0x1fd4 <generic_kprobe_process_event+0x1c84>
    1b4f:      	leaq	0x50(%rsp), %rdx
    1b54:      	movl	$0x4, %ebp
    1b59:      	movl	$0x1, %ecx
    1b5e:      	movl	$0x4, %eax
    1b63:      	movq	0x30(%rsp), %rdi
    1b68:      	movl	$0x1, %esi
    1b6d:      	callq	*%rax
    1b6f:      	jmp	0x2da2 <generic_kprobe_process_event+0x2a52>
    1b74:      	movq	%rcx, 0x40(%rsp)
    1b79:      	movq	%r15, %rbp
    1b7c:      	cmpl	$0x20, (%rsp)
    1b80:      	jle	0x1f0d <generic_kprobe_process_event+0x1bbd>
    1b86:      	movq	(%rsp), %rax
    1b8a:      	movq	%rax, %rcx
    1b8d:      	addl	$-0x21, %eax
    1b90:      	cmpl	$0x4, %eax
    1b93:      	jae	0x1da7 <generic_kprobe_process_event+0x1a57>
    1b99:      	movl	$0x8, %r13d
    1b9f:      	movl	$0x8, %ecx
    1ba4:      	movl	$0x4, %eax
    1ba9:      	movq	0x18(%rsp), %rdx
    1bae:      	movq	%rbp, %rdi
    1bb1:      	movl	$0x8, %esi
    1bb6:      	callq	*%rax
    1bb8:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    1bbd:      	movq	%rcx, %rbp
    1bc0:      	movq	(%rsp), %rcx
    1bc4:      	movq	%rcx, %rax
    1bc7:      	cmpl	$0x7, %ecx
    1bca:      	jg	0x201b <generic_kprobe_process_event+0x1ccb>
    1bd0:      	cmpl	$0x2, %eax
    1bd3:      	je	0x2606 <generic_kprobe_process_event+0x22b6>
    1bd9:      	cmpl	$0x3, %eax
    1bdc:      	movq	0x10(%rsp), %rbx
    1be1:      	movq	0x28(%rsp), %r14
    1be6:      	movl	$0x0, %r13d
    1bec:      	jne	0x1724 <generic_kprobe_process_event+0x13d4>
    1bf2:      	leaq	0x90(%rbp), %r13
    1bf9:      	movq	0x40(%rsp), %rcx
    1bfe:      	andl	$0xf, %ecx
    1c01:      	movq	%rcx, %rax
    1c04:      	cmpl	$0x2, %ecx
    1c07:      	jle	0x2d34 <generic_kprobe_process_event+0x29e4>
    1c0d:      	cmpl	$0x3, %eax
    1c10:      	je	0x2fd1 <generic_kprobe_process_event+0x2c81>
    1c16:      	cmpl	$0x4, %eax
    1c19:      	je	0x2fdc <generic_kprobe_process_event+0x2c8c>
    1c1f:      	cmpl	$0x5, %eax
    1c22:      	jne	0x338c <generic_kprobe_process_event+0x303c>
    1c28:      	movq	%rbp, %rax
    1c2b:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1c31:      	jmp	0x2ff0 <generic_kprobe_process_event+0x2ca0>
    1c36:      	movq	(%rsp), %rcx
    1c3a:      	cmpl	$0x1, %ecx
    1c3d:      	movq	0x10(%rsp), %rbx
    1c42:      	movq	0x28(%rsp), %r14
    1c47:      	je	0x1c99 <generic_kprobe_process_event+0x1949>
    1c49:      	movq	%rcx, %rax
    1c4c:      	cmpl	$0x4, %eax
    1c4f:      	movq	0x38(%rsp), %rax
    1c54:      	movq	0x20(%rsp), %rcx
    1c59:      	movl	$0x4, %esi
    1c5e:      	jne	0x2db7 <generic_kprobe_process_event+0x2a67>
    1c64:      	movl	$0x8, %r13d
    1c6a:      	leaq	0x50(%rsp), %rdx
    1c6f:      	movl	$0x8, %ecx
    1c74:      	movl	$0x4, %eax
    1c79:      	movq	0x30(%rsp), %rdi
    1c7e:      	movl	$0x8, %esi
    1c83:      	callq	*%rax
    1c85:      	movl	$0x4, %esi
    1c8a:      	movq	0x20(%rsp), %rcx
    1c8f:      	movq	0x38(%rsp), %rax
    1c94:      	jmp	0x1733 <generic_kprobe_process_event+0x13e3>
    1c99:      	leaq	0x50(%rsp), %rdx
    1c9e:      	movl	$0x4, %ebp
    1ca3:      	movl	$0x4, %ecx
    1ca8:      	movl	$0x4, %eax
    1cad:      	movq	0x30(%rsp), %rdi
    1cb2:      	movl	$0x4, %esi
    1cb7:      	callq	*%rax
    1cb9:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    1cbe:      	leaq	0x50(%rsp), %rdx
    1cc3:      	movl	$0x4, %ebp
    1cc8:      	movl	$0x2, %ecx
    1ccd:      	movl	$0x4, %eax
    1cd2:      	movq	0x30(%rsp), %rdi
    1cd7:      	movl	$0x2, %esi
    1cdc:      	callq	*%rax
    1cde:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    1ce3:      	movq	(%rsp), %rcx
    1ce7:      	cmpl	$0x27, %ecx
    1cea:      	je	0x25c3 <generic_kprobe_process_event+0x2273>
    1cf0:      	movq	%rcx, %rax
    1cf3:      	cmpl	$0x28, %eax
    1cf6:      	movq	0x38(%rsp), %rax
    1cfb:      	movq	0x20(%rsp), %rcx
    1d00:      	movl	$0x4, %esi
    1d05:      	movq	%r15, %rbx
    1d08:      	movq	%r12, %r14
    1d0b:      	jne	0x2db7 <generic_kprobe_process_event+0x2a67>
    1d11:      	movq	0x50(%rsp), %r14
    1d16:      	movq	0x30(%rsp), %rdi
    1d1b:      	movq	$0x0, 0x10(%rdi)
    1d23:      	movq	$0x0, 0x8(%rdi)
    1d2b:      	movq	$0x0, (%rdi)
    1d32:      	movl	$0x2, %ecx
    1d37:      	movl	$0x4, %eax
    1d3c:      	movl	$0x2, %esi
    1d41:      	movq	%r14, %rdx
    1d44:      	callq	*%rax
    1d46:      	testq	%rax, %rax
    1d49:      	js	0x2d9d <generic_kprobe_process_event+0x2a4d>
    1d4f:      	movq	0x30(%rsp), %rax
    1d54:      	movzwl	(%rax), %eax
    1d57:      	cmpl	$0xa, %eax
    1d5a:      	je	0x2d54 <generic_kprobe_process_event+0x2a04>
    1d60:      	cmpl	$0x2, %eax
    1d63:      	jne	0x2d8e <generic_kprobe_process_event+0x2a3e>
    1d69:      	leaq	0x4(%r14), %rdx
    1d6d:      	leaq	0x68(%rsp), %rdi
    1d72:      	movl	$0x4, %ecx
    1d77:      	movl	$0x4, %eax
    1d7c:      	movl	$0x4, %esi
    1d81:      	callq	*%rax
    1d83:      	movl	0x68(%rsp), %eax
    1d87:      	movq	0x30(%rsp), %rcx
    1d8c:      	movq	%rax, 0x8(%rcx)
    1d90:      	leaq	0x2(%rcx), %rdi
    1d94:      	addq	$0x2, %r14
    1d98:      	movl	$0x2, %ecx
    1d9d:      	movl	$0x4, %eax
    1da2:      	jmp	0x2d84 <generic_kprobe_process_event+0x2a34>
    1da7:      	cmpl	$0x2b, %ecx
    1daa:      	je	0x29ca <generic_kprobe_process_event+0x267a>
    1db0:      	cmpl	$0x29, %ecx
    1db3:      	movq	0x10(%rsp), %rbx
    1db8:      	movq	0x28(%rsp), %r14
    1dbd:      	movl	$0x0, %r13d
    1dc3:      	jne	0x1724 <generic_kprobe_process_event+0x13d4>
    1dc9:      	movq	0x18(%rsp), %rdx
    1dce:      	addq	$0x18, %rdx
    1dd2:      	leaq	0x68(%rsp), %rdi
    1dd7:      	movl	$0x4, %ebx
    1ddc:      	movl	$0x8, %ecx
    1de1:      	movl	$0x4, %eax
    1de6:      	movl	$0x8, %esi
    1deb:      	callq	*%rax
    1ded:      	movq	0x68(%rsp), %r12
    1df2:      	testq	%r12, %r12
    1df5:      	je	0x2f8d <generic_kprobe_process_event+0x2c3d>
    1dfb:      	movq	%rbp, %r15
    1dfe:      	movq	%r12, 0x28(%rbp)
    1e02:      	leaq	0x26(%rbp), %rdi
    1e06:      	leaq	0x10(%r12), %rdx
    1e0b:      	movl	$0x2, %ecx
    1e10:      	movl	$0x4, %eax
    1e15:      	movl	$0x2, %esi
    1e1a:      	callq	*%rax
    1e1c:      	leaq	0x3a(%rbp), %rdi
    1e20:      	leaq	0x12(%r12), %rdx
    1e25:      	movl	$0x1, %ecx
    1e2a:      	movl	$0x4, %eax
    1e2f:      	movl	$0x1, %esi
    1e34:      	callq	*%rax
    1e36:      	leaq	0x38(%rbp), %rdi
    1e3a:      	leaq	0x226(%r12), %rdx
    1e42:      	movl	$0x2, %ecx
    1e47:      	movl	$0x4, %eax
    1e4c:      	movl	$0x2, %esi
    1e51:      	callq	*%rax
    1e53:      	leaq	0x24(%rbp), %rdi
    1e57:      	leaq	0x224(%r12), %rdx
    1e5f:      	movl	$0x2, %ecx
    1e64:      	movl	$0x4, %eax
    1e69:      	movl	$0x2, %esi
    1e6e:      	callq	*%rax
    1e70:      	leaq	0x30(%rbp), %rdi
    1e74:      	leaq	0x21c(%r12), %rdx
    1e7c:      	movl	$0x4, %eax
    1e81:      	movl	$0x4, %esi
    1e86:      	callq	*%rax
    1e88:      	leaq	0x34(%rbp), %rdi
    1e8c:      	leaq	0x218(%r12), %rdx
    1e94:      	movl	$0x4, %eax
    1e99:      	movl	$0x4, %esi
    1e9e:      	callq	*%rax
    1ea0:      	leaq	0x10(%rbp), %r13
    1ea4:      	movq	$0x0, (%rbp)
    1eac:      	movq	$0x0, 0x8(%rbp)
    1eb4:      	movq	$0x0, 0x10(%rbp)
    1ebc:      	movq	$0x0, 0x18(%rbp)
    1ec4:      	movzwl	0x26(%rbp), %eax
    1ec8:      	cmpl	$0xa, %eax
    1ecb:      	je	0x2f15 <generic_kprobe_process_event+0x2bc5>
    1ed1:      	cmpl	$0x2, %eax
    1ed4:      	jne	0x2f47 <generic_kprobe_process_event+0x2bf7>
    1eda:      	leaq	0x4(%r12), %rdx
    1edf:      	movl	$0x4, %ecx
    1ee4:      	movl	$0x4, %eax
    1ee9:      	movq	%rbp, %rdi
    1eec:      	movl	$0x4, %esi
    1ef1:      	callq	*%rax
    1ef3:      	movl	$0x4, %ecx
    1ef8:      	movl	$0x4, %eax
    1efd:      	movq	%r13, %rdi
    1f00:      	movl	$0x4, %esi
    1f05:      	movq	%r12, %rdx
    1f08:      	jmp	0x2f45 <generic_kprobe_process_event+0x2bf5>
    1f0d:      	movq	(%rsp), %rcx
    1f11:      	cmpl	$0x1a, %ecx
    1f14:      	je	0x2a63 <generic_kprobe_process_event+0x2713>
    1f1a:      	movq	%rcx, %rax
    1f1d:      	cmpl	$0x1b, %eax
    1f20:      	movq	0x10(%rsp), %rbx
    1f25:      	movq	0x28(%rsp), %r14
    1f2a:      	movl	$0x0, %r13d
    1f30:      	jne	0x1724 <generic_kprobe_process_event+0x13d4>
    1f36:      	movq	$0x0, 0x48(%rbp)
    1f3e:      	movq	$0x0, 0x40(%rbp)
    1f46:      	movq	$0x0, 0x38(%rbp)
    1f4e:      	movq	$0x0, 0x30(%rbp)
    1f56:      	movq	$0x0, 0x28(%rbp)
    1f5e:      	movq	$0x0, 0x20(%rbp)
    1f66:      	movq	$0x0, 0x18(%rbp)
    1f6e:      	movq	$0x0, 0x10(%rbp)
    1f76:      	movq	$0x0, 0x8(%rbp)
    1f7e:      	movq	$0x0, (%rbp)
    1f86:      	leaq	0x10(%rbp), %rdi
    1f8a:      	movq	0x18(%rsp), %rax
    1f8f:      	leaq	0x18(%rax), %rdx
    1f93:      	movl	$0x3f, %ecx
    1f98:      	movl	$0x2d, %eax
    1f9d:      	movl	$0x3f, %esi
    1fa2:      	callq	*%rax
    1fa4:      	testq	%rax, %rax
    1fa7:      	js	0x2ad7 <generic_kprobe_process_event+0x2787>
    1fad:      	addq	$0x8, %rbp
    1fb1:      	movq	0x18(%rsp), %rdx
    1fb6:      	addq	$0x348, %rdx            # imm = 0x348
    1fbd:      	movl	$0x8, %ecx
    1fc2:      	movl	$0x4, %eax
    1fc7:      	movq	%rbp, %rdi
    1fca:      	movl	$0x8, %esi
    1fcf:      	jmp	0x2845 <generic_kprobe_process_event+0x24f5>
    1fd4:      	cmpl	$0x26, %ecx
    1fd7:      	movq	0x38(%rsp), %rax
    1fdc:      	movq	0x20(%rsp), %rcx
    1fe1:      	movl	$0x4, %esi
    1fe6:      	movq	%r15, %rbx
    1fe9:      	movq	%r12, %r14
    1fec:      	jne	0x2db7 <generic_kprobe_process_event+0x2a67>
    1ff2:      	movq	0x50(%rsp), %rsi
    1ff7:      	movzwl	%si, %edx
    1ffa:      	addq	%rbx, %rdx
    1ffd:      	shrl	$0x10, %esi
    2000:      	andl	$0xfff, %esi            # imm = 0xFFF
    2006:      	movq	0x30(%rsp), %rax
    200b:      	leaq	0x4(%rax), %rdi
    200f:      	incl	%esi
    2011:      	movl	$0x2d, %eax
    2016:      	jmp	0x25e5 <generic_kprobe_process_event+0x2295>
    201b:      	cmpl	$0x8, %eax
    201e:      	je	0x266c <generic_kprobe_process_event+0x231c>
    2024:      	cmpl	$0x12, %eax
    2027:      	movq	0x10(%rsp), %rbx
    202c:      	movq	0x28(%rsp), %r14
    2031:      	movl	$0x0, %r13d
    2037:      	jne	0x1724 <generic_kprobe_process_event+0x13d4>
    203d:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    2044:      	movl	$0x4, %eax
    2049:      	movq	0x18(%rsp), %rdx
    204e:      	movq	%r15, %rdi
    2051:      	movl	%r12d, %esi
    2054:      	callq	*%rax
    2056:      	movq	%r12, %r13
    2059:      	jmp	0x1724 <generic_kprobe_process_event+0x13d4>
    205e:      	cmpl	$0x13, %eax
    2061:      	je	0x2970 <generic_kprobe_process_event+0x2620>
    2067:      	cmpl	$0x14, %eax
    206a:      	movq	0x10(%rsp), %rbx
    206f:      	movq	0x28(%rsp), %r14
    2074:      	movl	$0x0, %r13d
    207a:      	jne	0x1724 <generic_kprobe_process_event+0x13d4>
    2080:      	movq	$0x0, 0x68(%rsp)
    2089:      	movq	0x18(%rsp), %r13
    208e:      	leaq	0x110(%r13), %rdx
    2095:      	leaq	0x68(%rsp), %rdi
    209a:      	movl	$0x8, %ecx
    209f:      	movl	$0x4, %eax
    20a4:      	leaq	0xd8(%r13), %r12
    20ab:      	movl	$0x8, %esi
    20b0:      	callq	*%rax
    20b2:      	movq	0x68(%rsp), %rcx
    20b7:      	movl	$0x80, %edx
    20bc:      	movl	$0x2d, %eax
    20c1:      	movq	0x68(%rsp), %rdx
    20c6:      	movq	%r15, %rdi
    20c9:      	movl	$0x80, %esi
    20ce:      	callq	*%rax
    20d0:      	leaq	0x90(%r15), %rdi
    20d7:      	movl	$0x4, %ecx
    20dc:      	movl	$0x4, %eax
    20e1:      	movl	$0x4, %esi
    20e6:      	movq	%r12, %rdx
    20e9:      	callq	*%rax
    20eb:      	leaq	0x80(%r15), %rdi
    20f2:      	leaq	0xe0(%r13), %rdx
    20f9:      	movl	$0x8, %ecx
    20fe:      	movl	$0x4, %eax
    2103:      	movl	$0x8, %esi
    2108:      	callq	*%rax
    210a:      	addq	$0x88, %r15
    2111:      	addq	$0x118, %r13            # imm = 0x118
    2118:      	movl	$0x8, %ecx
    211d:      	movl	$0x4, %eax
    2122:      	movq	%r15, %rdi
    2125:      	movl	$0x8, %esi
    212a:      	movq	%r13, %rdx
    212d:      	callq	*%rax
    212f:      	movl	$0x98, %r13d
    2135:      	jmp	0x1724 <generic_kprobe_process_event+0x13d4>
    213a:      	movq	0x50(%rsp), %r13
    213f:      	leaq	0xd8(%rsp), %rdi
    2147:      	movl	$0x1, %ecx
    214c:      	movl	$0x4, %eax
    2151:      	movl	$0x1, %esi
    2156:      	movq	%r13, %rdx
    2159:      	callq	*%rax
    215b:      	cmpb	$0x1, 0xd8(%rsp)
    2163:      	jne	0x2adf <generic_kprobe_process_event+0x278f>
    2169:      	addq	$0x10, %r13
    216d:      	leaq	0x58(%rsp), %rdi
    2172:      	movl	$0x8, %r12d
    2178:      	movl	$0x8, %ecx
    217d:      	movl	$0x4, %eax
    2182:      	movl	$0x8, %esi
    2187:      	movq	%r13, %rdx
    218a:      	callq	*%rax
    218c:      	movq	0x58(%rsp), %rdx
    2191:      	leaq	0xb8(%rsp), %rdi
    2199:      	movl	$0x8, %ecx
    219e:      	movl	$0x4, %eax
    21a3:      	movl	$0x8, %esi
    21a8:      	callq	*%rax
    21aa:      	movq	0x58(%rsp), %rdx
    21af:      	addq	$0x8, %rdx
    21b3:      	leaq	0x48(%rsp), %rdi
    21b8:      	movl	$0x8, %ecx
    21bd:      	movl	$0x4, %eax
    21c2:      	movl	$0x8, %esi
    21c7:      	callq	*%rax
    21c9:      	movq	0xb8(%rsp), %rax
    21d1:      	movq	%rax, 0xd0(%rsp)
    21d9:      	movq	0x48(%rsp), %rax
    21de:      	movq	%rax, (%rsp)
    21e2:      	movq	0xb0(%rsp), %rax
    21ea:      	addq	%r15, %rax
    21ed:      	addq	$0x90, %rax
    21f3:      	movq	%rax, 0x18(%rsp)
    21f8:      	testb	$0x20, 0x40(%rsp)
    21fd:      	je	0x2e95 <generic_kprobe_process_event+0x2b45>
    2203:      	cmpq	$0x1000, (%rsp)         # imm = 0x1000
    220b:      	jb	0x2e6b <generic_kprobe_process_event+0x2b1b>
    2211:      	movq	0x18(%rsp), %rax
    2216:      	movl	$0x1, (%rax)
    221c:      	movl	$0x0, 0xc8(%rsp)
    2227:      	movq	(%rip), %rdi            # 0x222e <generic_kprobe_process_event+0x1ede>
    222e:      	leaq	0xc8(%rsp), %rsi
    2236:      	movl	$0x1, %eax
    223b:      	callq	*%rax
    223d:      	movq	%rax, 0x40(%rsp)
    2242:      	testq	%rax, %rax
    2245:      	je	0x3545 <generic_kprobe_process_event+0x31f5>
    224b:      	movq	0x40(%rsp), %r12
    2250:      	movl	$0x18, (%r12)
    2258:      	movl	$0xe, %eax
    225d:      	callq	*%rax
    225f:      	leaq	0x10(%r12), %r15
    2264:      	movq	%rax, 0x10(%r12)
    2269:      	cmpq	$-0x16, %rax
    226d:      	jne	0x2291 <generic_kprobe_process_event+0x1f41>
    226f:      	leaq	0x20(%rbx), %rdx
    2273:      	leaq	0x68(%rsp), %rdi
    2278:      	movl	$0x8, %ecx
    227d:      	movl	$0x4, %eax
    2282:      	movl	$0x8, %esi
    2287:      	callq	*%rax
    2289:      	movq	0x68(%rsp), %rax
    228e:      	movq	%rax, (%r15)
    2291:      	movl	$0x7d, %eax
    2296:      	callq	*%rax
    2298:      	movq	0x40(%rsp), %rbp
    229d:      	movq	%rax, 0x18(%rbp)
    22a1:      	movq	(%r15), %rax
    22a4:      	movq	0x8(%r15), %rcx
    22a8:      	movq	0x18(%rsp), %rdx
    22ad:      	movq	%rax, 0x14(%rdx)
    22b1:      	movq	%rcx, 0x1c(%rdx)
    22b5:      	addq	$0x20, %rbp
    22b9:      	movl	$0xa, %r15d
    22bf:      	xorl	%r12d, %r12d
    22c2:      	movq	(%rsp), %r13
    22c6:      	subq	%r12, %r13
    22c9:      	js	0x373f <generic_kprobe_process_event+0x33ef>
    22cf:      	movq	0xd0(%rsp), %rax
    22d7:      	leaq	(%r12,%rax), %rdx
    22db:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    22e2:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    22e7:      	cmovaeq	%rax, %r13
    22eb:      	movl	$0x4, %eax
    22f0:      	movq	%rbp, %rdi
    22f3:      	movl	%r13d, %esi
    22f6:      	callq	*%rax
    22f8:      	testl	%eax, %eax
    22fa:      	js	0x2323 <generic_kprobe_process_event+0x1fd3>
    22fc:      	leal	0x20(%r13), %r8d
    2300:      	movq	0x40(%rsp), %rcx
    2305:      	movl	%r8d, 0x4(%rcx)
    2309:      	movl	$0x19, %eax
    230e:      	movq	%rbx, %rdi
    2311:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    2316:      	movq	(%rip), %rsi            # 0x231d <generic_kprobe_process_event+0x1fcd>
    231d:      	callq	*%rax
    231f:      	testl	%eax, %eax
    2321:      	jns	0x2326 <generic_kprobe_process_event+0x1fd6>
    2323:      	movslq	%eax, %r13
    2326:      	testl	%r13d, %r13d
    2329:      	js	0x3748 <generic_kprobe_process_event+0x33f8>
    232f:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2336:      	addq	%r13, %r12
    2339:      	cmpq	(%rsp), %r12
    233d:      	je	0x37a2 <generic_kprobe_process_event+0x3452>
    2343:      	decl	%r15d
    2346:      	jne	0x22c2 <generic_kprobe_process_event+0x1f72>
    234c:      	jmp	0x3af3 <generic_kprobe_process_event+0x37a3>
    2351:      	movq	0x50(%rsp), %r13
    2356:      	movq	0x30(%rsp), %rbx
    235b:      	leaq	0x28(%rbx), %rdi
    235f:      	leaq	0x98(%r13), %rdx
    2366:      	movl	$0x4, %ecx
    236b:      	movl	$0x4, %eax
    2370:      	movl	$0x4, %esi
    2375:      	callq	*%rax
    2377:      	leaq	0x2c(%rbx), %rdi
    237b:      	leaq	0x70(%r13), %rdx
    237f:      	movl	$0x4, %ecx
    2384:      	movl	$0x4, %eax
    2389:      	movl	$0x4, %esi
    238e:      	callq	*%rax
    2390:      	leaq	0x30(%rbx), %rdi
    2394:      	leaq	0x90(%r13), %rdx
    239b:      	movl	$0x4, %ecx
    23a0:      	movl	$0x4, %eax
    23a5:      	movl	$0x4, %esi
    23aa:      	callq	*%rax
    23ac:      	leaq	0x34(%rbx), %rdi
    23b0:      	leaq	0xa8(%r13), %rdx
    23b7:      	movl	$0x4, %ecx
    23bc:      	movl	$0x4, %eax
    23c1:      	movl	$0x4, %esi
    23c6:      	callq	*%rax
    23c8:      	movq	$0x0, 0x68(%rsp)
    23d1:      	leaq	0xc8(%r13), %rdx
    23d8:      	leaq	0x68(%rsp), %rdi
    23dd:      	movl	$0x8, %ecx
    23e2:      	movl	$0x4, %eax
    23e7:      	movl	$0x8, %esi
    23ec:      	callq	*%rax
    23ee:      	leaq	0xb8(%r13), %rdx
    23f5:      	leaq	0x48(%rsp), %rdi
    23fa:      	movl	$0x2, %ecx
    23ff:      	movl	$0x4, %eax
    2404:      	movl	$0x2, %esi
    2409:      	callq	*%rax
    240b:      	movzwl	0x48(%rsp), %r12d
    2411:      	addq	0x68(%rsp), %r12
    2416:      	leaq	0xe4(%rsp), %rdi
    241e:      	movl	$0x1, %ecx
    2423:      	movl	$0x4, %eax
    2428:      	movl	$0x1, %esi
    242d:      	movq	%r12, %rdx
    2430:      	callq	*%rax
    2432:      	movzbl	0xe4(%rsp), %eax
    243a:      	shrl	$0x4, %eax
    243d:      	cmpl	$0x6, %eax
    2440:      	je	0x2b09 <generic_kprobe_process_event+0x27b9>
    2446:      	cmpl	$0x4, %eax
    2449:      	jne	0x4028 <generic_kprobe_process_event+0x3cd8>
    244f:      	leaq	0x9(%r12), %rdx
    2454:      	leaq	0xd8(%rsp), %rdi
    245c:      	movl	$0x1, %ecx
    2461:      	movl	$0x4, %eax
    2466:      	movl	$0x1, %esi
    246b:      	callq	*%rax
    246d:      	movzbl	0xd8(%rsp), %eax
    2475:      	movq	0x30(%rsp), %rdi
    247a:      	movw	%ax, 0x24(%rdi)
    247e:      	movw	$0x2, 0x26(%rdi)
    2484:      	leaq	0xc(%r12), %rdx
    2489:      	movq	$0x0, (%rdi)
    2490:      	movq	$0x0, 0x8(%rdi)
    2498:      	movq	$0x0, 0x10(%rdi)
    24a0:      	movq	$0x0, 0x18(%rdi)
    24a8:      	movl	$0x4, %ecx
    24ad:      	movl	$0x4, %eax
    24b2:      	leaq	0x10(%rdi), %rbx
    24b6:      	movl	$0x4, %esi
    24bb:      	callq	*%rax
    24bd:      	addq	$0x10, %r12
    24c1:      	movl	$0x4, %ecx
    24c6:      	movl	$0x4, %eax
    24cb:      	movq	%rbx, %rdi
    24ce:      	movl	$0x4, %esi
    24d3:      	movq	%r12, %rdx
    24d6:      	callq	*%rax
    24d8:      	leaq	0xb6(%r13), %rdx
    24df:      	leaq	0xc8(%rsp), %rdi
    24e7:      	movl	$0x2, %ecx
    24ec:      	movl	$0x4, %eax
    24f1:      	movl	$0x2, %esi
    24f6:      	callq	*%rax
    24f8:      	movzbl	0xd8(%rsp), %r12d
    2501:      	jmp	0x3ec6 <generic_kprobe_process_event+0x3b76>
    2506:      	movq	$0x0, 0x70(%rsp)
    250f:      	movl	$0xe, %eax
    2514:      	callq	*%rax
    2516:      	shrq	$0x20, %rax
    251a:      	movq	%rax, 0x68(%rsp)
    251f:      	leaq	0x58(%rsp), %rdi
    2524:      	leaq	0x50(%rsp), %rdx
    2529:      	movl	$0x4, %ecx
    252e:      	movl	$0x4, %eax
    2533:      	movl	$0x4, %r15d
    2539:      	movl	$0x4, %esi
    253e:      	callq	*%rax
    2540:      	movl	0x58(%rsp), %eax
    2544:      	movl	%eax, 0x70(%rsp)
    2548:      	movq	(%rip), %rdi            # 0x254f <generic_kprobe_process_event+0x21ff>
    254f:      	leaq	0x68(%rsp), %rsi
    2554:      	movl	$0x1, %eax
    2559:      	callq	*%rax
    255b:      	testq	%rax, %rax
    255e:      	je	0x2afd <generic_kprobe_process_event+0x27ad>
    2564:      	movq	%rax, %r13
    2567:      	movl	(%rax), %ebp
    2569:      	leaq	0x58(%rsp), %rdx
    256e:      	movl	$0x4, %eax
    2573:      	movq	0x30(%rsp), %r12
    2578:      	movq	%r12, %rdi
    257b:      	movl	$0x4, %esi
    2580:      	callq	*%rax
    2582:      	andl	$0xfff, %ebp            # imm = 0xFFF
    2588:      	leaq	0x4(%r12), %rdi
    258d:      	leaq	0x4(%rbp), %rsi
    2591:      	movl	$0x4, %eax
    2596:      	movq	%r13, %rdx
    2599:      	callq	*%rax
    259b:      	leaq	(%r12,%rbp), %rdi
    259f:      	addq	$0x8, %rdi
    25a3:      	leaq	0x4(,%r13), %rdx
    25ab:      	addq	%rbp, %rdx
    25ae:      	movl	$0x4, %eax
    25b3:      	movl	$0x4, %esi
    25b8:      	callq	*%rax
    25ba:      	addq	$0xc, %rbp
    25be:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    25c3:      	movl	$0x120, %edx            # imm = 0x120
    25c8:      	addq	0x50(%rsp), %rdx
    25cd:      	movq	0x30(%rsp), %rax
    25d2:      	leaq	0x4(%rax), %rdi
    25d6:      	movl	$0x11, %ecx
    25db:      	movl	$0x2d, %eax
    25e0:      	movl	$0x11, %esi
    25e5:      	callq	*%rax
    25e7:      	movq	%rax, %rbp
    25ea:      	testq	%rax, %rax
    25ed:      	js	0x2da2 <generic_kprobe_process_event+0x2a52>
    25f3:      	leal	-0x1(%rbp), %eax
    25f6:      	movq	0x30(%rsp), %rcx
    25fb:      	movl	%eax, (%rcx)
    25fd:      	addq	$0x3, %rbp
    2601:      	jmp	0x2da2 <generic_kprobe_process_event+0x2a52>
    2606:      	movq	0xb0(%rsp), %rax
    260e:      	leaq	(%rax,%rbp), %r14
    2612:      	addq	$0x90, %r14
    2619:      	movq	$0x0, 0x50(%rsp)
    2622:      	testb	$0x10, 0x40(%rsp)
    2627:      	jne	0x2c68 <generic_kprobe_process_event+0x2918>
    262d:      	movl	0x40(%rsp), %r15d
    2632:      	andl	$0xf, %r12d
    2636:      	xorl	%eax, %eax
    2638:      	movq	%r12, %rcx
    263b:      	cmpl	$0x2, %r12d
    263f:      	jle	0x2ef7 <generic_kprobe_process_event+0x2ba7>
    2645:      	cmpl	$0x3, %ecx
    2648:      	je	0x354f <generic_kprobe_process_event+0x31ff>
    264e:      	cmpl	$0x4, %ecx
    2651:      	je	0x3558 <generic_kprobe_process_event+0x3208>
    2657:      	cmpl	$0x5, %ecx
    265a:      	jne	0x356b <generic_kprobe_process_event+0x321b>
    2660:      	leaq	0x5e70(%rbp), %rax
    2667:      	jmp	0x3568 <generic_kprobe_process_event+0x3218>
    266c:      	movq	%r15, %rbx
    266f:      	leaq	0x28(%r15), %r13
    2673:      	leaq	0x40(%r15), %rbp
    2677:      	movq	0x18(%rsp), %r15
    267c:      	leaq	0x8(%r15), %rdx
    2680:      	movl	$0x4, %ecx
    2685:      	movl	$0x4, %eax
    268a:      	movq	%rbx, %rdi
    268d:      	movl	$0x4, %esi
    2692:      	callq	*%rax
    2694:      	leaq	0x4(%rbx), %rdi
    2698:      	leaq	0xc(%r15), %rdx
    269c:      	movl	$0x4, %ecx
    26a1:      	movl	$0x4, %eax
    26a6:      	movl	$0x4, %esi
    26ab:      	callq	*%rax
    26ad:      	leaq	0x10(%rbx), %rdi
    26b1:      	leaq	0x18(%r15), %rdx
    26b5:      	movl	$0x4, %ecx
    26ba:      	movl	$0x4, %eax
    26bf:      	movl	$0x4, %esi
    26c4:      	callq	*%rax
    26c6:      	leaq	0x14(%rbx), %rdi
    26ca:      	leaq	0x1c(%r15), %rdx
    26ce:      	movl	$0x4, %ecx
    26d3:      	movl	$0x4, %eax
    26d8:      	movl	$0x4, %esi
    26dd:      	callq	*%rax
    26df:      	leaq	0x8(%rbx), %rdi
    26e3:      	leaq	0x10(%r15), %rdx
    26e7:      	movl	$0x4, %ecx
    26ec:      	movl	$0x4, %eax
    26f1:      	movl	$0x4, %esi
    26f6:      	callq	*%rax
    26f8:      	leaq	0xc(%rbx), %rdi
    26fc:      	leaq	0x14(%r15), %rdx
    2700:      	movl	$0x4, %ecx
    2705:      	movl	$0x4, %eax
    270a:      	movl	$0x4, %esi
    270f:      	callq	*%rax
    2711:      	leaq	0x18(%rbx), %rdi
    2715:      	leaq	0x20(%r15), %rdx
    2719:      	movl	$0x4, %ecx
    271e:      	movl	$0x4, %eax
    2723:      	movl	$0x4, %esi
    2728:      	callq	*%rax
    272a:      	leaq	0x1c(%rbx), %rdi
    272e:      	leaq	0x24(%r15), %rdx
    2732:      	movl	$0x4, %ecx
    2737:      	movl	$0x4, %eax
    273c:      	movl	$0x4, %esi
    2741:      	callq	*%rax
    2743:      	movl	$0x0, 0x24(%rbx)
    274a:      	leaq	0x20(%rbx), %rdi
    274e:      	leaq	0x28(%r15), %rdx
    2752:      	movl	$0x4, %ecx
    2757:      	movl	$0x4, %eax
    275c:      	movl	$0x4, %esi
    2761:      	callq	*%rax
    2763:      	leaq	0x30(%rbx), %rdi
    2767:      	leaq	0x40(%r15), %rdx
    276b:      	movl	$0x8, %ecx
    2770:      	movl	$0x4, %eax
    2775:      	movl	$0x8, %esi
    277a:      	callq	*%rax
    277c:      	leaq	0x38(%rbx), %rdi
    2780:      	leaq	0x30(%r15), %rdx
    2784:      	movl	$0x8, %ecx
    2789:      	movl	$0x4, %eax
    278e:      	movl	$0x8, %esi
    2793:      	callq	*%rax
    2795:      	leaq	0x38(%r15), %rdx
    2799:      	movl	$0x8, %ecx
    279e:      	movl	$0x4, %eax
    27a3:      	movq	%r13, %rdi
    27a6:      	movl	$0x8, %esi
    27ab:      	callq	*%rax
    27ad:      	addq	$0x90, %r15
    27b4:      	leaq	0x68(%rsp), %rdi
    27b9:      	movl	$0x8, %ecx
    27be:      	movl	$0x4, %eax
    27c3:      	movl	$0x8, %esi
    27c8:      	movq	%r15, %rdx
    27cb:      	callq	*%rax
    27cd:      	movq	0x68(%rsp), %r13
    27d2:      	leaq	0xc8(%r13), %rdx
    27d9:      	movl	$0x4, %ecx
    27de:      	movl	$0x4, %eax
    27e3:      	movq	%rbp, %rdi
    27e6:      	movl	$0x4, %esi
    27eb:      	callq	*%rax
    27ed:      	leaq	0x44(%rbx), %rdi
    27f1:      	leaq	0xcc(%r13), %rdx
    27f8:      	movl	$0x4, %ecx
    27fd:      	movl	$0x4, %eax
    2802:      	movl	$0x4, %esi
    2807:      	callq	*%rax
    2809:      	leaq	0x48(%rbx), %rdi
    280d:      	leaq	0xd0(%r13), %rdx
    2814:      	movl	$0x4, %ecx
    2819:      	movl	$0x4, %eax
    281e:      	movl	$0x4, %esi
    2823:      	callq	*%rax
    2825:      	addq	$0x4c, %rbx
    2829:      	addq	$0x158, %r13            # imm = 0x158
    2830:      	movl	$0x4, %ecx
    2835:      	movl	$0x4, %eax
    283a:      	movq	%rbx, %rdi
    283d:      	movl	$0x4, %esi
    2842:      	movq	%r13, %rdx
    2845:      	callq	*%rax
    2847:      	movl	$0x50, %r13d
    284d:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    2852:      	movq	0x18(%rsp), %r12
    2857:      	leaq	0xc8(%r12), %rdx
    285f:      	movl	$0x4, %ecx
    2864:      	movl	$0x4, %eax
    2869:      	movq	%r15, %rdi
    286c:      	movl	$0x4, %esi
    2871:      	callq	*%rax
    2873:      	leaq	0x4(%r15), %rdi
    2877:      	leaq	0xcc(%r12), %rdx
    287f:      	movl	$0x4, %ecx
    2884:      	movl	$0x4, %eax
    2889:      	movl	$0x4, %esi
    288e:      	callq	*%rax
    2890:      	leaq	0x8(%r15), %rdi
    2894:      	leaq	0xd0(%r12), %rdx
    289c:      	movl	$0x4, %ecx
    28a1:      	movl	$0x4, %eax
    28a6:      	movl	$0x4, %esi
    28ab:      	callq	*%rax
    28ad:      	addq	$0xc, %r15
    28b1:      	addq	$0x158, %r12            # imm = 0x158
    28b8:      	movl	$0x4, %ecx
    28bd:      	movl	$0x4, %eax
    28c2:      	movq	%r15, %rdi
    28c5:      	movl	$0x4, %esi
    28ca:      	movq	%r12, %rdx
    28cd:      	callq	*%rax
    28cf:      	movl	$0x10, %r13d
    28d5:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    28da:      	movq	0x18(%rsp), %r12
    28df:      	leaq	0x38(%r12), %rdx
    28e4:      	movl	$0x4, %ecx
    28e9:      	movl	$0x4, %eax
    28ee:      	movq	%r15, %rdi
    28f1:      	movl	$0x4, %esi
    28f6:      	callq	*%rax
    28f8:      	leaq	0x4(%r15), %rdi
    28fc:      	leaq	0x3c(%r12), %rdx
    2901:      	movl	$0x4, %ecx
    2906:      	movl	$0x4, %eax
    290b:      	movl	$0x4, %esi
    2910:      	callq	*%rax
    2912:      	leaq	0x8(%r15), %rdi
    2916:      	leaq	0x40(%r12), %rdx
    291b:      	movl	$0x4, %ecx
    2920:      	movl	$0x4, %eax
    2925:      	movl	$0x4, %esi
    292a:      	callq	*%rax
    292c:      	leaq	0xc(%r15), %rdi
    2930:      	leaq	0x44(%r12), %rdx
    2935:      	movl	$0x4, %ecx
    293a:      	movl	$0x4, %eax
    293f:      	movl	$0x4, %esi
    2944:      	callq	*%rax
    2946:      	addq	$0x10, %r15
    294a:      	subq	$-0x80, %r12
    294e:      	movl	$0x10, %ecx
    2953:      	movl	$0x4, %eax
    2958:      	movq	%r15, %rdi
    295b:      	movl	$0x10, %esi
    2960:      	movq	%r12, %rdx
    2963:      	callq	*%rax
    2965:      	movl	$0x20, %r13d
    296b:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    2970:      	movl	$0x4, %ecx
    2975:      	movl	$0x4, %eax
    297a:      	movq	%r15, %rbx
    297d:      	movq	0x18(%rsp), %r15
    2982:      	movq	%rbx, %rdi
    2985:      	movl	$0x4, %esi
    298a:      	movq	%r15, %rdx
    298d:      	callq	*%rax
    298f:      	leaq	0x4(%rbx), %rdi
    2993:      	leaq	0x4(%r15), %rdx
    2997:      	movl	$0x4, %ecx
    299c:      	movl	$0x4, %eax
    29a1:      	movl	$0x4, %esi
    29a6:      	callq	*%rax
    29a8:      	addq	$0x8, %rbx
    29ac:      	addq	$0x30, %r15
    29b0:      	movl	$0x10, %ecx
    29b5:      	movl	$0x4, %eax
    29ba:      	movq	%rbx, %rdi
    29bd:      	movl	$0x10, %esi
    29c2:      	movq	%r15, %rdx
    29c5:      	jmp	0x2a56 <generic_kprobe_process_event+0x2706>
    29ca:      	movq	0x18(%rsp), %r15
    29cf:      	leaq	0x4(%r15), %rdx
    29d3:      	leaq	0x68(%rsp), %rdi
    29d8:      	movl	$0x4, %ecx
    29dd:      	movl	$0x4, %eax
    29e2:      	movl	$0x4, %esi
    29e7:      	callq	*%rax
    29e9:      	movl	0x68(%rsp), %eax
    29ed:      	movl	%eax, (%rbp)
    29f0:      	leaq	0xc(%r15), %rdx
    29f4:      	leaq	0x68(%rsp), %rdi
    29f9:      	movl	$0x4, %ecx
    29fe:      	movl	$0x4, %eax
    2a03:      	movl	$0x4, %esi
    2a08:      	callq	*%rax
    2a0a:      	movl	0x68(%rsp), %eax
    2a0e:      	movl	%eax, 0x4(%rbp)
    2a11:      	addq	$0x50, %r15
    2a15:      	leaq	0x68(%rsp), %rdi
    2a1a:      	movl	$0x8, %ecx
    2a1f:      	movl	$0x2d, %eax
    2a24:      	movl	$0x8, %esi
    2a29:      	movq	%r15, %rdx
    2a2c:      	callq	*%rax
    2a2e:      	addq	$0x8, %rbp
    2a32:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2a37:      	movq	0x68(%rsp), %rcx
    2a3c:      	addq	%rdx, %rcx
    2a3f:      	movl	$0x10, %esi
    2a44:      	movl	$0x2d, %eax
    2a49:      	addq	0x68(%rsp), %rdx
    2a4e:      	movq	%rbp, %rdi
    2a51:      	movl	$0x10, %esi
    2a56:      	callq	*%rax
    2a58:      	movl	$0x18, %r13d
    2a5e:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    2a63:      	movq	$0x0, 0x48(%rbp)
    2a6b:      	movq	$0x0, 0x40(%rbp)
    2a73:      	movq	$0x0, 0x38(%rbp)
    2a7b:      	movq	$0x0, 0x30(%rbp)
    2a83:      	movq	$0x0, 0x28(%rbp)
    2a8b:      	movq	$0x0, 0x20(%rbp)
    2a93:      	movq	$0x0, 0x18(%rbp)
    2a9b:      	movq	$0x0, 0x10(%rbp)
    2aa3:      	movq	$0x0, 0x8(%rbp)
    2aab:      	movq	$0x0, (%rbp)
    2ab3:      	leaq	0x68(%rsp), %rdi
    2ab8:      	movl	$0x8, %ecx
    2abd:      	movl	$0x4, %eax
    2ac2:      	movq	0x18(%rsp), %rdx
    2ac7:      	movl	$0x8, %esi
    2acc:      	callq	*%rax
    2ace:      	testq	%rax, %rax
    2ad1:      	je	0x2dbf <generic_kprobe_process_event+0x2a6f>
    2ad7:      	xorl	%r13d, %r13d
    2ada:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    2adf:      	movq	0xb0(%rsp), %rax
    2ae7:      	movq	$0x0, 0x90(%r15,%rax)
    2af3:      	movl	$0x8, %ebp
    2af8:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    2afd:      	movq	$-0x1, %rbp
    2b04:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    2b09:      	movq	0x68(%rsp), %rbp
    2b0e:      	movl	$0x0, 0x58(%rsp)
    2b16:      	movzwl	0x48(%rsp), %r15d
    2b1c:      	movq	(%rip), %rdi            # 0x2b23 <generic_kprobe_process_event+0x27d3>
    2b23:      	leaq	0x58(%rsp), %rsi
    2b28:      	movl	$0x1, %eax
    2b2d:      	leaq	(%r15,%rbp), %r14
    2b31:      	callq	*%rax
    2b33:      	testq	%rax, %rax
    2b36:      	je	0x3e74 <generic_kprobe_process_event+0x3b24>
    2b3c:      	movq	%rax, %rbx
    2b3f:      	movw	%r15w, (%rax)
    2b43:      	movb	$-0x1, 0x5(%rax)
    2b47:      	movb	$0x0, 0x7(%rax)
    2b4b:      	movq	%rax, %r15
    2b4e:      	addq	$0x6, %r15
    2b52:      	leaq	0x6(%r14), %rdx
    2b56:      	movl	$0x1, %ecx
    2b5b:      	movl	$0x4, %eax
    2b60:      	movq	%r15, %rdi
    2b63:      	movl	$0x1, %esi
    2b68:      	callq	*%rax
    2b6a:      	testq	%rax, %rax
    2b6d:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    2b73:      	movzbl	0x5(%rbx), %eax
    2b77:      	cmpl	$0x32, %eax
    2b7a:      	jg	0x3487 <generic_kprobe_process_event+0x3137>
    2b80:      	testl	%eax, %eax
    2b82:      	je	0x3535 <generic_kprobe_process_event+0x31e5>
    2b88:      	cmpl	$0x2b, %eax
    2b8b:      	je	0x3535 <generic_kprobe_process_event+0x31e5>
    2b91:      	cmpl	$0x2c, %eax
    2b94:      	jne	0x3876 <generic_kprobe_process_event+0x3526>
    2b9a:      	movw	$0x8, 0x2(%rbx)
    2ba0:      	movw	$0x8, %ax
    2ba4:      	jmp	0x37ba <generic_kprobe_process_event+0x346a>
    2ba9:      	leaq	0x48(%r12), %rdx
    2bae:      	movl	$0x10, %ecx
    2bb3:      	movl	$0x4, %eax
    2bb8:      	movq	0x30(%rsp), %rdi
    2bbd:      	movl	$0x10, %esi
    2bc2:      	callq	*%rax
    2bc4:      	leaq	0x38(%r12), %rdx
    2bc9:      	movl	$0x10, %ecx
    2bce:      	movl	$0x4, %eax
    2bd3:      	movq	%r13, %rdi
    2bd6:      	movl	$0x10, %esi
    2bdb:      	callq	*%rax
    2bdd:      	movq	0x30(%rsp), %rbp
    2be2:      	leaq	0x20(%rbp), %rdi
    2be6:      	leaq	0xc(%r12), %r13
    2beb:      	addq	$0xe, %r12
    2bef:      	movl	$0x2, %ecx
    2bf4:      	movl	$0x4, %eax
    2bf9:      	movl	$0x2, %esi
    2bfe:      	movq	%r12, %rdx
    2c01:      	callq	*%rax
    2c03:      	leaq	0x22(%rbp), %rdi
    2c07:      	movl	$0x2, %ecx
    2c0c:      	movl	$0x4, %eax
    2c11:      	movl	$0x2, %esi
    2c16:      	movq	%r13, %rdx
    2c19:      	callq	*%rax
    2c1b:      	movzwl	0x22(%rbp), %eax
    2c1f:      	movbew	%ax, 0x22(%rbp)
    2c25:      	movq	0x50(%rsp), %rax
    2c2a:      	movq	%rax, 0x68(%rsp)
    2c2f:      	movq	(%rip), %rdi            # 0x2c36 <generic_kprobe_process_event+0x28e6>
    2c36:      	leaq	0x68(%rsp), %rsi
    2c3b:      	movl	$0x1, %eax
    2c40:      	callq	*%rax
    2c42:      	testq	%rax, %rax
    2c45:      	je	0x4028 <generic_kprobe_process_event+0x3cd8>
    2c4b:      	movl	(%rax), %ecx
    2c4d:      	movq	%r15, %rbp
    2c50:      	movl	%ecx, 0x10(%r15)
    2c54:      	movq	0x8(%rax), %rcx
    2c58:      	movq	%rcx, 0x18(%r15)
    2c5c:      	movl	0x4(%rax), %eax
    2c5f:      	movl	%eax, 0x7c(%r15)
    2c63:      	jmp	0x4028 <generic_kprobe_process_event+0x3cd8>
    2c68:      	movl	$0xe, %eax
    2c6d:      	callq	*%rax
    2c6f:      	cmpq	$-0x16, %rax
    2c73:      	jne	0x2c99 <generic_kprobe_process_event+0x2949>
    2c75:      	movq	0x10(%rsp), %rax
    2c7a:      	leaq	0x20(%rax), %rdx
    2c7e:      	leaq	0x68(%rsp), %rdi
    2c83:      	movl	$0x8, %ecx
    2c88:      	movl	$0x4, %eax
    2c8d:      	movl	$0x8, %esi
    2c92:      	callq	*%rax
    2c94:      	movq	0x68(%rsp), %rax
    2c99:      	movq	0x8(%rbp), %rcx
    2c9d:      	movq	0x60(%rbp), %rdx
    2ca1:      	movq	%rcx, 0x68(%rsp)
    2ca6:      	movq	0x18(%rsp), %rcx
    2cab:      	movq	%rcx, 0x70(%rsp)
    2cb0:      	movq	$0x0, 0x78(%rsp)
    2cb9:      	movq	%rdx, 0x58(%rsp)
    2cbe:      	movq	%rax, 0x60(%rsp)
    2cc3:      	movq	(%rip), %rdi            # 0x2cca <generic_kprobe_process_event+0x297a>
    2cca:      	xorl	%ecx, %ecx
    2ccc:      	leaq	0x58(%rsp), %rsi
    2cd1:      	leaq	0x68(%rsp), %rdx
    2cd6:      	movl	$0x2, %eax
    2cdb:      	xorl	%ecx, %ecx
    2cdd:      	callq	*%rax
    2cdf:      	testq	%rax, %rax
    2ce2:      	je	0x34e0 <generic_kprobe_process_event+0x3190>
    2ce8:      	negl	%eax
    2cea:      	movw	%ax, 0xb8(%rsp)
    2cf2:      	movw	$0x5, 0xba(%rsp)
    2cfc:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2d06:      	movq	%rax, 0xbc(%rsp)
    2d0e:      	movq	(%rip), %rdi            # 0x2d15 <generic_kprobe_process_event+0x29c5>
    2d15:      	leaq	0xb8(%rsp), %rsi
    2d1d:      	movl	$0x1, %eax
    2d22:      	callq	*%rax
    2d24:      	testq	%rax, %rax
    2d27:      	je	0x34b3 <generic_kprobe_process_event+0x3163>
    2d2d:      	incl	(%rax)
    2d2f:      	jmp	0x34e0 <generic_kprobe_process_event+0x3190>
    2d34:      	cmpl	$0x1, %eax
    2d37:      	je	0x2fe7 <generic_kprobe_process_event+0x2c97>
    2d3d:      	cmpl	$0x2, %eax
    2d40:      	jne	0x338c <generic_kprobe_process_event+0x303c>
    2d46:      	movq	%rbp, %rax
    2d49:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2d4f:      	jmp	0x2ff0 <generic_kprobe_process_event+0x2ca0>
    2d54:      	movq	0x30(%rsp), %rbx
    2d59:      	leaq	0x8(%rbx), %rdi
    2d5d:      	leaq	0x8(%r14), %rdx
    2d61:      	movl	$0x10, %ecx
    2d66:      	movl	$0x4, %eax
    2d6b:      	movl	$0x10, %esi
    2d70:      	callq	*%rax
    2d72:      	leaq	0x2(%rbx), %rdi
    2d76:      	addq	$0x2, %r14
    2d7a:      	movl	$0x2, %ecx
    2d7f:      	movl	$0x4, %eax
    2d84:      	movl	$0x2, %esi
    2d89:      	movq	%r14, %rdx
    2d8c:      	callq	*%rax
    2d8e:      	movq	0x30(%rsp), %rbp
    2d93:      	movzwl	0x2(%rbp), %eax
    2d97:      	movbew	%ax, 0x2(%rbp)
    2d9d:      	movl	$0x18, %ebp
    2da2:      	movq	0x38(%rsp), %rax
    2da7:      	movq	0x20(%rsp), %rcx
    2dac:      	movl	$0x4, %esi
    2db1:      	movq	%r15, %rbx
    2db4:      	movq	%r12, %r14
    2db7:      	movq	%rbp, %r13
    2dba:      	jmp	0x1733 <generic_kprobe_process_event+0x13e3>
    2dbf:      	leaq	0x10(%rbp), %rdi
    2dc3:      	movq	0x68(%rsp), %rcx
    2dc8:      	movl	$0x3f, %edx
    2dcd:      	movl	$0x2d, %eax
    2dd2:      	movq	0x68(%rsp), %rdx
    2dd7:      	movl	$0x3f, %esi
    2ddc:      	callq	*%rax
    2dde:      	testq	%rax, %rax
    2de1:      	js	0x2ad7 <generic_kprobe_process_event+0x2787>
    2de7:      	movq	0x18(%rsp), %rbx
    2dec:      	leaq	0x8(%rbx), %rdx
    2df0:      	leaq	0x58(%rsp), %rdi
    2df5:      	movl	$0x8, %ecx
    2dfa:      	movl	$0x4, %eax
    2dff:      	movl	$0x8, %esi
    2e04:      	callq	*%rax
    2e06:      	leaq	0x8(%rbp), %rdi
    2e0a:      	movl	$0x348, %edx            # imm = 0x348
    2e0f:      	movq	0x58(%rsp), %rcx
    2e14:      	addq	%rdx, %rcx
    2e17:      	movl	$0x8, %esi
    2e1c:      	movl	$0x4, %eax
    2e21:      	addq	0x58(%rsp), %rdx
    2e26:      	movl	$0x8, %esi
    2e2b:      	callq	*%rax
    2e2d:      	addq	$0x58, %rbx
    2e31:      	leaq	0x58(%rsp), %rdi
    2e36:      	movl	$0x4, %ecx
    2e3b:      	movl	$0x4, %eax
    2e40:      	movl	$0x4, %esi
    2e45:      	movq	%rbx, %rdx
    2e48:      	callq	*%rax
    2e4a:      	movl	$0x50, %r13d
    2e50:      	testq	%rax, %rax
    2e53:      	jne	0x3c8b <generic_kprobe_process_event+0x393b>
    2e59:      	xorl	%eax, %eax
    2e5b:      	cmpl	$0x0, 0x58(%rsp)
    2e60:      	setne	%al
    2e63:      	movl	%eax, (%rbp)
    2e66:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    2e6b:      	addq	$0x90, %r15
    2e72:      	movq	0xa8(%rsp), %rax
    2e7a:      	movl	$0x0, 0x4(%r15,%rax)
    2e83:      	addq	%r15, %rax
    2e86:      	addq	$0x8, %rax
    2e8a:      	movq	%rax, 0x18(%rsp)
    2e8f:      	movl	$0xc, %r12d
    2e95:      	movq	(%rsp), %rax
    2e99:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2e9f:      	movl	$0xfff, %r13d           # imm = 0xFFF
    2ea5:      	cmovbq	%rax, %r13
    2ea9:      	movq	0x18(%rsp), %rax
    2eae:      	leaq	0x8(%rax), %rdi
    2eb2:      	movl	$0x4, %eax
    2eb7:      	movq	0xd0(%rsp), %rdx
    2ebf:      	movl	$0x4, %ebp
    2ec4:      	movl	%r13d, %esi
    2ec7:      	callq	*%rax
    2ec9:      	testl	%eax, %eax
    2ecb:      	js	0x2ee7 <generic_kprobe_process_event+0x2b97>
    2ecd:      	movq	0x18(%rsp), %rax
    2ed2:      	movq	(%rsp), %rcx
    2ed6:      	movl	%ecx, (%rax)
    2ed8:      	movl	%r13d, 0x4(%rax)
    2edc:      	addq	%r13, %r12
    2edf:      	movq	%r12, %rbp
    2ee2:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    2ee7:      	movq	0x18(%rsp), %rax
    2eec:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    2ef2:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    2ef7:      	cmpl	$0x1, %ecx
    2efa:      	je	0x3561 <generic_kprobe_process_event+0x3211>
    2f00:      	cmpl	$0x2, %ecx
    2f03:      	jne	0x356b <generic_kprobe_process_event+0x321b>
    2f09:      	leaq	0x5e58(%rbp), %rax
    2f10:      	jmp	0x3568 <generic_kprobe_process_event+0x3218>
    2f15:      	leaq	0x48(%r12), %rdx
    2f1a:      	movl	$0x10, %ecx
    2f1f:      	movl	$0x4, %eax
    2f24:      	movq	%rbp, %rdi
    2f27:      	movl	$0x10, %esi
    2f2c:      	callq	*%rax
    2f2e:      	leaq	0x38(%r12), %rdx
    2f33:      	movl	$0x10, %ecx
    2f38:      	movl	$0x4, %eax
    2f3d:      	movq	%r13, %rdi
    2f40:      	movl	$0x10, %esi
    2f45:      	callq	*%rax
    2f47:      	movq	%rbp, %rbx
    2f4a:      	leaq	0x20(%rbp), %rdi
    2f4e:      	leaq	0xc(%r12), %r13
    2f53:      	addq	$0xe, %r12
    2f57:      	movl	$0x2, %ecx
    2f5c:      	movl	$0x4, %eax
    2f61:      	movl	$0x2, %esi
    2f66:      	movq	%r12, %rdx
    2f69:      	callq	*%rax
    2f6b:      	leaq	0x22(%rbp), %rdi
    2f6f:      	movl	$0x2, %ecx
    2f74:      	movl	$0x4, %eax
    2f79:      	movl	$0x2, %esi
    2f7e:      	movq	%r13, %rdx
    2f81:      	callq	*%rax
    2f83:      	movzwl	0x22(%rbp), %eax
    2f87:      	movbew	%ax, 0x22(%rbp)
    2f8d:      	movq	0x28(%rbp), %rax
    2f91:      	movq	%rax, 0x68(%rsp)
    2f96:      	movq	(%rip), %rdi            # 0x2f9d <generic_kprobe_process_event+0x2c4d>
    2f9d:      	leaq	0x68(%rsp), %rsi
    2fa2:      	movl	$0x1, %eax
    2fa7:      	callq	*%rax
    2fa9:      	testq	%rax, %rax
    2fac:      	je	0x2fc6 <generic_kprobe_process_event+0x2c76>
    2fae:      	movl	(%rax), %ecx
    2fb0:      	movq	0x40(%rsp), %rdx
    2fb5:      	movl	%ecx, 0x10(%rdx)
    2fb8:      	movq	0x8(%rax), %rcx
    2fbc:      	movq	%rcx, 0x18(%rdx)
    2fc0:      	movl	0x4(%rax), %eax
    2fc3:      	movl	%eax, 0x7c(%rdx)
    2fc6:      	movl	$0x40, %r13d
    2fcc:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    2fd1:      	movq	%rbp, %rax
    2fd4:      	addq	$0x5e60, %rax           # imm = 0x5E60
    2fda:      	jmp	0x2ff0 <generic_kprobe_process_event+0x2ca0>
    2fdc:      	movq	%rbp, %rax
    2fdf:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2fe5:      	jmp	0x2ff0 <generic_kprobe_process_event+0x2ca0>
    2fe7:      	movq	%rbp, %rax
    2fea:      	addq	$0x5e50, %rax           # imm = 0x5E50
    2ff0:      	movq	(%rax), %rbx
    2ff3:      	testb	$0x10, %r12b
    2ff7:      	jne	0x339e <generic_kprobe_process_event+0x304e>
    2ffd:      	testq	%rbx, %rbx
    3000:      	je	0x3466 <generic_kprobe_process_event+0x3116>
    3006:      	leaq	0x68(%rsp), %rdi
    300b:      	movl	$0x10, %ecx
    3010:      	movl	$0x4, %eax
    3015:      	movq	0x18(%rsp), %rdx
    301a:      	movl	$0x10, %esi
    301f:      	callq	*%rax
    3021:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3026:      	testl	%eax, %eax
    3028:      	js	0x336a <generic_kprobe_process_event+0x301a>
    302e:      	movq	0x70(%rsp), %r14
    3033:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3038:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    303f:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    3045:      	movq	0xa8(%rsp), %rax
    304d:      	leaq	0xc(%rax), %r15
    3051:      	leaq	(%r15,%r13), %rdi
    3055:      	movq	0x68(%rsp), %rcx
    305a:      	movl	$0x4, %eax
    305f:      	movq	0x68(%rsp), %rdx
    3064:      	movl	%r14d, %esi
    3067:      	callq	*%rax
    3069:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    306e:      	testl	%eax, %eax
    3070:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3076:      	cmpq	$0x1, %rbx
    307a:      	je	0x3469 <generic_kprobe_process_event+0x3119>
    3080:      	movq	0x18(%rsp), %rax
    3085:      	leaq	0x10(%rax), %rdx
    3089:      	leaq	0x68(%rsp), %rdi
    308e:      	movl	$0x10, %ecx
    3093:      	movl	$0x4, %eax
    3098:      	movl	$0x10, %esi
    309d:      	callq	*%rax
    309f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30a4:      	testl	%eax, %eax
    30a6:      	js	0x336a <generic_kprobe_process_event+0x301a>
    30ac:      	movq	0x70(%rsp), %rbp
    30b1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    30b6:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    30bd:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    30c3:      	addq	%r14, %r15
    30c6:      	leaq	(%r15,%r13), %rdi
    30ca:      	movq	0x68(%rsp), %rcx
    30cf:      	movl	$0x4, %eax
    30d4:      	movq	0x68(%rsp), %rdx
    30d9:      	movl	%ebp, %esi
    30db:      	callq	*%rax
    30dd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30e2:      	testl	%eax, %eax
    30e4:      	js	0x336a <generic_kprobe_process_event+0x301a>
    30ea:      	addq	%rbp, %r14
    30ed:      	cmpq	$0x3, %rbx
    30f1:      	jb	0x3469 <generic_kprobe_process_event+0x3119>
    30f7:      	movq	0x18(%rsp), %rax
    30fc:      	leaq	0x20(%rax), %rdx
    3100:      	leaq	0x68(%rsp), %rdi
    3105:      	movl	$0x10, %ecx
    310a:      	movl	$0x4, %eax
    310f:      	movl	$0x10, %esi
    3114:      	callq	*%rax
    3116:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    311b:      	testl	%eax, %eax
    311d:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3123:      	movq	0x70(%rsp), %r12
    3128:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    312d:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    3134:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    313a:      	addq	%r15, %rbp
    313d:      	movl	%ebp, %edi
    313f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3145:      	addq	%r13, %rdi
    3148:      	movq	0x68(%rsp), %rcx
    314d:      	movl	$0x4, %eax
    3152:      	movq	0x68(%rsp), %rdx
    3157:      	movl	%r12d, %esi
    315a:      	callq	*%rax
    315c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3161:      	testl	%eax, %eax
    3163:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3169:      	addq	%r12, %r14
    316c:      	cmpq	$0x3, %rbx
    3170:      	je	0x3469 <generic_kprobe_process_event+0x3119>
    3176:      	movq	0x18(%rsp), %rax
    317b:      	leaq	0x30(%rax), %rdx
    317f:      	leaq	0x68(%rsp), %rdi
    3184:      	movl	$0x10, %ecx
    3189:      	movl	$0x4, %eax
    318e:      	movl	$0x10, %esi
    3193:      	callq	*%rax
    3195:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    319a:      	testl	%eax, %eax
    319c:      	js	0x336a <generic_kprobe_process_event+0x301a>
    31a2:      	movq	0x70(%rsp), %rax
    31a7:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    31ac:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    31b2:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    31b8:      	movq	%rax, %r15
    31bb:      	addq	%rbp, %r12
    31be:      	movl	%r12d, %edi
    31c1:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    31c7:      	addq	%r13, %rdi
    31ca:      	movq	0x68(%rsp), %rcx
    31cf:      	movl	$0x4, %eax
    31d4:      	movq	%r15, %rsi
    31d7:      	movq	0x68(%rsp), %rdx
    31dc:      	callq	*%rax
    31de:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31e3:      	testl	%eax, %eax
    31e5:      	js	0x336a <generic_kprobe_process_event+0x301a>
    31eb:      	addq	%r15, %r14
    31ee:      	cmpq	$0x5, %rbx
    31f2:      	jb	0x3469 <generic_kprobe_process_event+0x3119>
    31f8:      	movq	0x18(%rsp), %rax
    31fd:      	leaq	0x40(%rax), %rdx
    3201:      	leaq	0x68(%rsp), %rdi
    3206:      	movl	$0x10, %ecx
    320b:      	movl	$0x4, %eax
    3210:      	movl	$0x10, %esi
    3215:      	callq	*%rax
    3217:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    321c:      	testl	%eax, %eax
    321e:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3224:      	movq	0x70(%rsp), %rax
    3229:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    322e:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3234:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    323a:      	movq	%rax, %rbp
    323d:      	movq	%r15, %rdi
    3240:      	addq	%r12, %rdi
    3243:      	movq	%rdi, %r15
    3246:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    324c:      	addq	%r13, %rdi
    324f:      	movq	0x68(%rsp), %rcx
    3254:      	movl	$0x4, %eax
    3259:      	movq	%rbp, %rsi
    325c:      	movq	0x68(%rsp), %rdx
    3261:      	callq	*%rax
    3263:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3268:      	testl	%eax, %eax
    326a:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3270:      	addq	%rbp, %r14
    3273:      	cmpq	$0x5, %rbx
    3277:      	je	0x3469 <generic_kprobe_process_event+0x3119>
    327d:      	movq	0x18(%rsp), %rax
    3282:      	leaq	0x50(%rax), %rdx
    3286:      	leaq	0x68(%rsp), %rdi
    328b:      	movl	$0x10, %ecx
    3290:      	movl	$0x4, %eax
    3295:      	movl	$0x10, %esi
    329a:      	callq	*%rax
    329c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32a1:      	testl	%eax, %eax
    32a3:      	js	0x336a <generic_kprobe_process_event+0x301a>
    32a9:      	movq	0x70(%rsp), %r12
    32ae:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    32b3:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    32ba:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    32c0:      	addq	%r15, %rbp
    32c3:      	movq	%rbp, %r15
    32c6:      	movl	%ebp, %edi
    32c8:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    32ce:      	addq	%r13, %rdi
    32d1:      	movq	0x68(%rsp), %rcx
    32d6:      	movl	$0x4, %eax
    32db:      	movq	0x68(%rsp), %rdx
    32e0:      	movl	%r12d, %esi
    32e3:      	callq	*%rax
    32e5:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32ea:      	testl	%eax, %eax
    32ec:      	js	0x336a <generic_kprobe_process_event+0x301a>
    32ee:      	addq	%r12, %r14
    32f1:      	cmpq	$0x7, %rbx
    32f5:      	jb	0x3469 <generic_kprobe_process_event+0x3119>
    32fb:      	movq	0x18(%rsp), %rdx
    3300:      	addq	$0x60, %rdx
    3304:      	leaq	0x68(%rsp), %rdi
    3309:      	movl	$0x10, %ecx
    330e:      	movl	$0x4, %eax
    3313:      	movl	$0x10, %esi
    3318:      	callq	*%rax
    331a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    331f:      	testl	%eax, %eax
    3321:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3323:      	movq	0x70(%rsp), %rbx
    3328:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    332d:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    3334:      	ja	0x336a <generic_kprobe_process_event+0x301a>
    3336:      	addq	%r15, %r12
    3339:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    3340:      	addq	%r13, %r12
    3343:      	movq	0x68(%rsp), %rcx
    3348:      	movl	$0x4, %eax
    334d:      	movq	0x68(%rsp), %rdx
    3352:      	movq	%r12, %rdi
    3355:      	movl	%ebx, %esi
    3357:      	callq	*%rax
    3359:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    335e:      	testl	%eax, %eax
    3360:      	js	0x336a <generic_kprobe_process_event+0x301a>
    3362:      	addq	%rbx, %r14
    3365:      	jmp	0x3469 <generic_kprobe_process_event+0x3119>
    336a:      	movq	0xb0(%rsp), %rax
    3372:      	movl	%ecx, (%r13,%rax)
    3377:      	movq	0x10(%rsp), %rbx
    337c:      	movq	0x28(%rsp), %r14
    3381:      	movl	$0x4, %r13d
    3387:      	jmp	0x1724 <generic_kprobe_process_event+0x13d4>
    338c:      	xorl	%ebx, %ebx
    338e:      	movl	$0x0, %r14d
    3394:      	testb	$0x10, %r12b
    3398:      	je	0x3469 <generic_kprobe_process_event+0x3119>
    339e:      	movl	$0xe, %eax
    33a3:      	callq	*%rax
    33a5:      	cmpq	$-0x16, %rax
    33a9:      	jne	0x33cf <generic_kprobe_process_event+0x307f>
    33ab:      	movq	0x10(%rsp), %rax
    33b0:      	leaq	0x20(%rax), %rdx
    33b4:      	leaq	0x68(%rsp), %rdi
    33b9:      	movl	$0x8, %ecx
    33be:      	movl	$0x4, %eax
    33c3:      	movl	$0x8, %esi
    33c8:      	callq	*%rax
    33ca:      	movq	0x68(%rsp), %rax
    33cf:      	movq	0x8(%rbp), %rcx
    33d3:      	movq	0x60(%rbp), %rdx
    33d7:      	movq	%rcx, 0x68(%rsp)
    33dc:      	movq	0x18(%rsp), %rcx
    33e1:      	movq	%rcx, 0x70(%rsp)
    33e6:      	movq	%rbx, 0x78(%rsp)
    33eb:      	movq	%rdx, 0x58(%rsp)
    33f0:      	movq	%rax, 0x60(%rsp)
    33f5:      	movq	(%rip), %rdi            # 0x33fc <generic_kprobe_process_event+0x30ac>
    33fc:      	xorl	%ecx, %ecx
    33fe:      	leaq	0x58(%rsp), %rsi
    3403:      	leaq	0x68(%rsp), %rdx
    3408:      	movl	$0x2, %eax
    340d:      	xorl	%ecx, %ecx
    340f:      	callq	*%rax
    3411:      	testq	%rax, %rax
    3414:      	je	0x3519 <generic_kprobe_process_event+0x31c9>
    341a:      	negl	%eax
    341c:      	movw	%ax, 0xb8(%rsp)
    3424:      	movw	$0x5, 0xba(%rsp)
    342e:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    3438:      	movq	%rax, 0xbc(%rsp)
    3440:      	movq	(%rip), %rdi            # 0x3447 <generic_kprobe_process_event+0x30f7>
    3447:      	leaq	0xb8(%rsp), %rsi
    344f:      	movl	$0x1, %eax
    3454:      	callq	*%rax
    3456:      	testq	%rax, %rax
    3459:      	je	0x34f2 <generic_kprobe_process_event+0x31a2>
    345f:      	incl	(%rax)
    3461:      	jmp	0x3519 <generic_kprobe_process_event+0x31c9>
    3466:      	xorl	%r14d, %r14d
    3469:      	movq	0xb0(%rsp), %rax
    3471:      	movl	%r14d, (%r13,%rax)
    3476:      	movl	%r14d, 0x4(%r13,%rax)
    347b:      	addq	$0x8, %r14
    347f:      	movq	%r14, %r13
    3482:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    3487:      	cmpl	$0x33, %eax
    348a:      	je	0x37ab <generic_kprobe_process_event+0x345b>
    3490:      	cmpl	$0x3c, %eax
    3493:      	je	0x3535 <generic_kprobe_process_event+0x31e5>
    3499:      	cmpl	$0xff, %eax
    349e:      	jne	0x3876 <generic_kprobe_process_event+0x3526>
    34a4:      	movw	$0x28, 0x2(%rbx)
    34aa:      	movw	$0x28, %ax
    34ae:      	jmp	0x37ba <generic_kprobe_process_event+0x346a>
    34b3:      	movl	$0x1, 0xc8(%rsp)
    34be:      	movq	(%rip), %rdi            # 0x34c5 <generic_kprobe_process_event+0x3175>
    34c5:      	xorl	%ecx, %ecx
    34c7:      	leaq	0xb8(%rsp), %rsi
    34cf:      	leaq	0xc8(%rsp), %rdx
    34d7:      	movl	$0x2, %eax
    34dc:      	xorl	%ecx, %ecx
    34de:      	callq	*%rax
    34e0:      	movl	$0xfffffffc, (%r14)     # imm = 0xFFFFFFFC
    34e7:      	movl	$0x4, %r13d
    34ed:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    34f2:      	movl	$0x1, 0x48(%rsp)
    34fa:      	movq	(%rip), %rdi            # 0x3501 <generic_kprobe_process_event+0x31b1>
    3501:      	xorl	%ecx, %ecx
    3503:      	leaq	0xb8(%rsp), %rsi
    350b:      	leaq	0x48(%rsp), %rdx
    3510:      	movl	$0x2, %eax
    3515:      	xorl	%ecx, %ecx
    3517:      	callq	*%rax
    3519:      	movq	0xb0(%rsp), %rax
    3521:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    352a:      	movl	$0x4, %r13d
    3530:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    3535:      	movzbl	0x7(%rbx), %eax
    3539:      	leal	0x8(,%rax,8), %eax
    3540:      	jmp	0x37b6 <generic_kprobe_process_event+0x3466>
    3545:      	movl	$0x4, %ebp
    354a:      	jmp	0x3b3f <generic_kprobe_process_event+0x37ef>
    354f:      	leaq	0x5e60(%rbp), %rax
    3556:      	jmp	0x3568 <generic_kprobe_process_event+0x3218>
    3558:      	leaq	0x5e68(%rbp), %rax
    355f:      	jmp	0x3568 <generic_kprobe_process_event+0x3218>
    3561:      	leaq	0x5e50(%rbp), %rax
    3568:      	movq	(%rax), %rax
    356b:      	movq	%rax, 0x48(%rsp)
    3570:      	leaq	0x50(%rsp), %rdi
    3575:      	leaq	0x48(%rsp), %rdx
    357a:      	movl	$0x8, %ecx
    357f:      	movl	$0x4, %eax
    3584:      	movl	$0x8, %ebx
    3589:      	movl	$0x8, %esi
    358e:      	callq	*%rax
    3590:      	movq	0x50(%rsp), %r12
    3595:      	testb	$0x20, %r15b
    3599:      	je	0x36f3 <generic_kprobe_process_event+0x33a3>
    359f:      	cmpq	$0x1000, %r12           # imm = 0x1000
    35a6:      	jb	0x36cf <generic_kprobe_process_event+0x337f>
    35ac:      	movl	$0x1, (%r14)
    35b3:      	movl	$0x0, 0x58(%rsp)
    35bb:      	movq	(%rip), %rdi            # 0x35c2 <generic_kprobe_process_event+0x3272>
    35c2:      	leaq	0x58(%rsp), %rsi
    35c7:      	movl	$0x1, %eax
    35cc:      	callq	*%rax
    35ce:      	movq	%rax, (%rsp)
    35d2:      	testq	%rax, %rax
    35d5:      	je	0x3734 <generic_kprobe_process_event+0x33e4>
    35db:      	movq	(%rsp), %rbx
    35df:      	movl	$0x18, (%rbx)
    35e5:      	movl	$0xe, %eax
    35ea:      	callq	*%rax
    35ec:      	leaq	0x10(%rbx), %r15
    35f0:      	movq	%rax, 0x10(%rbx)
    35f4:      	cmpq	$-0x16, %rax
    35f8:      	jne	0x3621 <generic_kprobe_process_event+0x32d1>
    35fa:      	movq	0x10(%rsp), %rax
    35ff:      	leaq	0x20(%rax), %rdx
    3603:      	leaq	0x68(%rsp), %rdi
    3608:      	movl	$0x8, %ecx
    360d:      	movl	$0x4, %eax
    3612:      	movl	$0x8, %esi
    3617:      	callq	*%rax
    3619:      	movq	0x68(%rsp), %rax
    361e:      	movq	%rax, (%r15)
    3621:      	movl	$0x7d, %eax
    3626:      	callq	*%rax
    3628:      	movq	(%rsp), %r13
    362c:      	movq	%rax, 0x18(%r13)
    3630:      	movq	(%r15), %rax
    3633:      	movq	0x8(%r15), %rcx
    3637:      	movq	%rax, 0x14(%r14)
    363b:      	movq	%rcx, 0x1c(%r14)
    363f:      	addq	$0x20, %r13
    3643:      	movl	$0xa, %r15d
    3649:      	xorl	%ebx, %ebx
    364b:      	movq	%r12, %rbp
    364e:      	subq	%rbx, %rbp
    3651:      	js	0x38a8 <generic_kprobe_process_event+0x3558>
    3657:      	movq	0x18(%rsp), %rax
    365c:      	leaq	(%rbx,%rax), %rdx
    3660:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    3667:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    366c:      	cmovaeq	%rax, %rbp
    3670:      	movl	$0x4, %eax
    3675:      	movq	%r13, %rdi
    3678:      	movl	%ebp, %esi
    367a:      	callq	*%rax
    367c:      	testl	%eax, %eax
    367e:      	js	0x36a8 <generic_kprobe_process_event+0x3358>
    3680:      	leal	0x20(%rbp), %r8d
    3684:      	movq	(%rsp), %rcx
    3688:      	movl	%r8d, 0x4(%rcx)
    368c:      	movl	$0x19, %eax
    3691:      	movq	0x10(%rsp), %rdi
    3696:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    369b:      	movq	(%rip), %rsi            # 0x36a2 <generic_kprobe_process_event+0x3352>
    36a2:      	callq	*%rax
    36a4:      	testl	%eax, %eax
    36a6:      	jns	0x36ab <generic_kprobe_process_event+0x335b>
    36a8:      	movslq	%eax, %rbp
    36ab:      	testl	%ebp, %ebp
    36ad:      	js	0x38b1 <generic_kprobe_process_event+0x3561>
    36b3:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    36b9:      	addq	%rbp, %rbx
    36bc:      	cmpq	%r12, %rbx
    36bf:      	je	0x390b <generic_kprobe_process_event+0x35bb>
    36c5:      	decl	%r15d
    36c8:      	jne	0x364b <generic_kprobe_process_event+0x32fb>
    36ca:      	jmp	0x3c51 <generic_kprobe_process_event+0x3901>
    36cf:      	addq	$0x90, %rbp
    36d6:      	movq	0xa8(%rsp), %rax
    36de:      	movl	$0x0, 0x4(%rbp,%rax)
    36e6:      	leaq	(%rax,%rbp), %r14
    36ea:      	addq	$0x8, %r14
    36ee:      	movl	$0xc, %ebx
    36f3:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    36fa:      	movl	$0xfff, %r13d           # imm = 0xFFF
    3700:      	cmovbq	%r12, %r13
    3704:      	leaq	0x8(%r14), %rdi
    3708:      	movl	$0x4, %eax
    370d:      	movq	0x18(%rsp), %rdx
    3712:      	movl	%r13d, %esi
    3715:      	callq	*%rax
    3717:      	testl	%eax, %eax
    3719:      	js	0x372d <generic_kprobe_process_event+0x33dd>
    371b:      	movl	%r12d, (%r14)
    371e:      	movl	%r13d, 0x4(%r14)
    3722:      	addq	%r13, %rbx
    3725:      	movq	%rbx, %r13
    3728:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    372d:      	movl	$0xfffffffe, (%r14)     # imm = 0xFFFFFFFE
    3734:      	movl	$0x4, %r13d
    373a:      	jmp	0x3c8b <generic_kprobe_process_event+0x393b>
    373f:      	movq	$-0x1, %r12
    3746:      	jmp	0x374b <generic_kprobe_process_event+0x33fb>
    3748:      	movq	%r13, %r12
    374b:      	movl	$0x0, 0x68(%rsp)
    3753:      	movq	(%rip), %rdi            # 0x375a <generic_kprobe_process_event+0x340a>
    375a:      	leaq	0x68(%rsp), %rsi
    375f:      	movl	$0x1, %eax
    3764:      	callq	*%rax
    3766:      	testq	%rax, %rax
    3769:      	je	0x3af3 <generic_kprobe_process_event+0x37a3>
    376f:      	cmpq	$-0xc, %r12
    3773:      	jg	0x387f <generic_kprobe_process_event+0x352f>
    3779:      	cmpq	$-0x1c, %r12
    377d:      	je	0x3ac9 <generic_kprobe_process_event+0x3779>
    3783:      	cmpq	$-0x16, %r12
    3787:      	je	0x3ae1 <generic_kprobe_process_event+0x3791>
    378d:      	cmpq	$-0x10, %r12
    3791:      	jne	0x3ad9 <generic_kprobe_process_event+0x3789>
    3797:      	addq	$0x558, %rax            # imm = 0x558
    379d:      	jmp	0x3aef <generic_kprobe_process_event+0x379f>
    37a2:      	movq	(%rsp), %r12
    37a6:      	jmp	0x3af3 <generic_kprobe_process_event+0x37a3>
    37ab:      	movzbl	0x7(%rbx), %eax
    37af:      	leal	0x8(,%rax,4), %eax
    37b6:      	movw	%ax, 0x2(%rbx)
    37ba:      	addw	(%rbx), %ax
    37bd:      	movw	%ax, (%rbx)
    37c0:      	movzbl	0x6(%rbx), %r12d
    37c5:      	cmpq	$0x3c, %r12
    37c9:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    37cf:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    37d9:      	btq	%r12, %rcx
    37dd:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    37e3:      	movb	%r12b, 0x5(%rbx)
    37e7:      	movzwl	%ax, %ecx
    37ea:      	addq	%rbp, %rcx
    37ed:      	movl	$0x2, %edx
    37f2:      	movl	$0x4, %eax
    37f7:      	movzwl	(%rbx), %edx
    37fa:      	addq	%rbp, %rdx
    37fd:      	movq	%r15, %rdi
    3800:      	movl	$0x2, %esi
    3805:      	callq	*%rax
    3807:      	testq	%rax, %rax
    380a:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    3810:      	movzbl	0x5(%rbx), %eax
    3814:      	cmpl	$0x32, %eax
    3817:      	jg	0x383a <generic_kprobe_process_event+0x34ea>
    3819:      	testl	%eax, %eax
    381b:      	je	0x3862 <generic_kprobe_process_event+0x3512>
    381d:      	cmpl	$0x2b, %eax
    3820:      	je	0x3862 <generic_kprobe_process_event+0x3512>
    3822:      	cmpl	$0x2c, %eax
    3825:      	jne	0x3924 <generic_kprobe_process_event+0x35d4>
    382b:      	movw	$0x8, 0x2(%rbx)
    3831:      	movw	$0x8, %ax
    3835:      	jmp	0x3928 <generic_kprobe_process_event+0x35d8>
    383a:      	cmpl	$0x33, %eax
    383d:      	je	0x3913 <generic_kprobe_process_event+0x35c3>
    3843:      	cmpl	$0x3c, %eax
    3846:      	je	0x3862 <generic_kprobe_process_event+0x3512>
    3848:      	cmpl	$0xff, %eax
    384d:      	jne	0x3924 <generic_kprobe_process_event+0x35d4>
    3853:      	movw	$0x28, 0x2(%rbx)
    3859:      	movw	$0x28, %ax
    385d:      	jmp	0x3928 <generic_kprobe_process_event+0x35d8>
    3862:      	movzbl	0x7(%rbx), %eax
    3866:      	leal	0x8(,%rax,8), %eax
    386d:      	movw	%ax, 0x2(%rbx)
    3871:      	jmp	0x3928 <generic_kprobe_process_event+0x35d8>
    3876:      	movzwl	0x2(%rbx), %eax
    387a:      	jmp	0x37ba <generic_kprobe_process_event+0x346a>
    387f:      	cmpq	$-0xb, %r12
    3883:      	je	0x3ad1 <generic_kprobe_process_event+0x3781>
    3889:      	cmpq	$-0x7, %r12
    388d:      	je	0x3ae9 <generic_kprobe_process_event+0x3799>
    3893:      	cmpq	$-0x2, %r12
    3897:      	jne	0x3ad9 <generic_kprobe_process_event+0x3789>
    389d:      	addq	$0x548, %rax            # imm = 0x548
    38a3:      	jmp	0x3aef <generic_kprobe_process_event+0x379f>
    38a8:      	movq	$-0x1, %rbx
    38af:      	jmp	0x38b4 <generic_kprobe_process_event+0x3564>
    38b1:      	movq	%rbp, %rbx
    38b4:      	movl	$0x0, 0x68(%rsp)
    38bc:      	movq	(%rip), %rdi            # 0x38c3 <generic_kprobe_process_event+0x3573>
    38c3:      	leaq	0x68(%rsp), %rsi
    38c8:      	movl	$0x1, %eax
    38cd:      	callq	*%rax
    38cf:      	testq	%rax, %rax
    38d2:      	je	0x3c51 <generic_kprobe_process_event+0x3901>
    38d8:      	cmpq	$-0xc, %rbx
    38dc:      	jg	0x39cf <generic_kprobe_process_event+0x367f>
    38e2:      	cmpq	$-0x1c, %rbx
    38e6:      	je	0x3c27 <generic_kprobe_process_event+0x38d7>
    38ec:      	cmpq	$-0x16, %rbx
    38f0:      	je	0x3c37 <generic_kprobe_process_event+0x38e7>
    38f6:      	cmpq	$-0x10, %rbx
    38fa:      	jne	0x3c47 <generic_kprobe_process_event+0x38f7>
    3900:      	addq	$0x558, %rax            # imm = 0x558
    3906:      	jmp	0x3c4d <generic_kprobe_process_event+0x38fd>
    390b:      	movq	%r12, %rbx
    390e:      	jmp	0x3c51 <generic_kprobe_process_event+0x3901>
    3913:      	movzbl	0x7(%rbx), %eax
    3917:      	leal	0x8(,%rax,4), %eax
    391e:      	movw	%ax, 0x2(%rbx)
    3922:      	jmp	0x3928 <generic_kprobe_process_event+0x35d8>
    3924:      	movzwl	0x2(%rbx), %eax
    3928:      	addw	(%rbx), %ax
    392b:      	movw	%ax, (%rbx)
    392e:      	movzbl	0x6(%rbx), %r12d
    3933:      	cmpq	$0x3c, %r12
    3937:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    393d:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3947:      	btq	%r12, %rcx
    394b:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    3951:      	movb	%r12b, 0x5(%rbx)
    3955:      	movzwl	%ax, %ecx
    3958:      	addq	%rbp, %rcx
    395b:      	movl	$0x2, %edx
    3960:      	movl	$0x4, %eax
    3965:      	movzwl	(%rbx), %edx
    3968:      	addq	%rbp, %rdx
    396b:      	movq	%r15, %rdi
    396e:      	movl	$0x2, %esi
    3973:      	callq	*%rax
    3975:      	testq	%rax, %rax
    3978:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    397e:      	movzbl	0x5(%rbx), %eax
    3982:      	cmpl	$0x32, %eax
    3985:      	jg	0x39a1 <generic_kprobe_process_event+0x3651>
    3987:      	testl	%eax, %eax
    3989:      	je	0x39be <generic_kprobe_process_event+0x366e>
    398b:      	cmpl	$0x2b, %eax
    398e:      	je	0x39be <generic_kprobe_process_event+0x366e>
    3990:      	cmpl	$0x2c, %eax
    3993:      	jne	0x3a09 <generic_kprobe_process_event+0x36b9>
    3995:      	movw	$0x8, 0x2(%rbx)
    399b:      	movw	$0x8, %ax
    399f:      	jmp	0x3a0d <generic_kprobe_process_event+0x36bd>
    39a1:      	cmpl	$0x33, %eax
    39a4:      	je	0x39f8 <generic_kprobe_process_event+0x36a8>
    39a6:      	cmpl	$0x3c, %eax
    39a9:      	je	0x39be <generic_kprobe_process_event+0x366e>
    39ab:      	cmpl	$0xff, %eax
    39b0:      	jne	0x3a09 <generic_kprobe_process_event+0x36b9>
    39b2:      	movw	$0x28, 0x2(%rbx)
    39b8:      	movw	$0x28, %ax
    39bc:      	jmp	0x3a0d <generic_kprobe_process_event+0x36bd>
    39be:      	movzbl	0x7(%rbx), %eax
    39c2:      	leal	0x8(,%rax,8), %eax
    39c9:      	movw	%ax, 0x2(%rbx)
    39cd:      	jmp	0x3a0d <generic_kprobe_process_event+0x36bd>
    39cf:      	cmpq	$-0xb, %rbx
    39d3:      	je	0x3c2f <generic_kprobe_process_event+0x38df>
    39d9:      	cmpq	$-0x7, %rbx
    39dd:      	je	0x3c3f <generic_kprobe_process_event+0x38ef>
    39e3:      	cmpq	$-0x2, %rbx
    39e7:      	jne	0x3c47 <generic_kprobe_process_event+0x38f7>
    39ed:      	addq	$0x548, %rax            # imm = 0x548
    39f3:      	jmp	0x3c4d <generic_kprobe_process_event+0x38fd>
    39f8:      	movzbl	0x7(%rbx), %eax
    39fc:      	leal	0x8(,%rax,4), %eax
    3a03:      	movw	%ax, 0x2(%rbx)
    3a07:      	jmp	0x3a0d <generic_kprobe_process_event+0x36bd>
    3a09:      	movzwl	0x2(%rbx), %eax
    3a0d:      	addw	(%rbx), %ax
    3a10:      	movw	%ax, (%rbx)
    3a13:      	movzbl	0x6(%rbx), %r12d
    3a18:      	cmpq	$0x3c, %r12
    3a1c:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    3a22:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3a2c:      	btq	%r12, %rcx
    3a30:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    3a36:      	movb	%r12b, 0x5(%rbx)
    3a3a:      	movzwl	%ax, %ecx
    3a3d:      	addq	%rbp, %rcx
    3a40:      	movl	$0x2, %edx
    3a45:      	movl	$0x4, %eax
    3a4a:      	movzwl	(%rbx), %edx
    3a4d:      	addq	%rbp, %rdx
    3a50:      	movq	%r15, %rdi
    3a53:      	movl	$0x2, %esi
    3a58:      	callq	*%rax
    3a5a:      	testq	%rax, %rax
    3a5d:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    3a63:      	movzbl	0x5(%rbx), %eax
    3a67:      	cmpl	$0x32, %eax
    3a6a:      	jg	0x3a8d <generic_kprobe_process_event+0x373d>
    3a6c:      	testl	%eax, %eax
    3a6e:      	je	0x3ab5 <generic_kprobe_process_event+0x3765>
    3a70:      	cmpl	$0x2b, %eax
    3a73:      	je	0x3ab5 <generic_kprobe_process_event+0x3765>
    3a75:      	cmpl	$0x2c, %eax
    3a78:      	jne	0x3b67 <generic_kprobe_process_event+0x3817>
    3a7e:      	movw	$0x8, 0x2(%rbx)
    3a84:      	movw	$0x8, %ax
    3a88:      	jmp	0x3b6b <generic_kprobe_process_event+0x381b>
    3a8d:      	cmpl	$0x33, %eax
    3a90:      	je	0x3b56 <generic_kprobe_process_event+0x3806>
    3a96:      	cmpl	$0x3c, %eax
    3a99:      	je	0x3ab5 <generic_kprobe_process_event+0x3765>
    3a9b:      	cmpl	$0xff, %eax
    3aa0:      	jne	0x3b67 <generic_kprobe_process_event+0x3817>
    3aa6:      	movw	$0x28, 0x2(%rbx)
    3aac:      	movw	$0x28, %ax
    3ab0:      	jmp	0x3b6b <generic_kprobe_process_event+0x381b>
    3ab5:      	movzbl	0x7(%rbx), %eax
    3ab9:      	leal	0x8(,%rax,8), %eax
    3ac0:      	movw	%ax, 0x2(%rbx)
    3ac4:      	jmp	0x3b6b <generic_kprobe_process_event+0x381b>
    3ac9:      	addq	$0x568, %rax            # imm = 0x568
    3acf:      	jmp	0x3aef <generic_kprobe_process_event+0x379f>
    3ad1:      	addq	$0x570, %rax            # imm = 0x570
    3ad7:      	jmp	0x3aef <generic_kprobe_process_event+0x379f>
    3ad9:      	addq	$0x540, %rax            # imm = 0x540
    3adf:      	jmp	0x3aef <generic_kprobe_process_event+0x379f>
    3ae1:      	addq	$0x560, %rax            # imm = 0x560
    3ae7:      	jmp	0x3aef <generic_kprobe_process_event+0x379f>
    3ae9:      	addq	$0x550, %rax            # imm = 0x550
    3aef:      	lock
    3af0:      	incq	(%rax)
    3af3:      	testl	%r12d, %r12d
    3af6:      	js	0x3b19 <generic_kprobe_process_event+0x37c9>
    3af8:      	movq	0x18(%rsp), %rax
    3afd:      	movq	$0x0, 0x4(%rax)
    3b05:      	movq	(%rsp), %rdx
    3b09:      	movl	%edx, %ecx
    3b0b:      	subl	%r12d, %ecx
    3b0e:      	xorl	%eax, %eax
    3b10:      	cmpq	$-0x1, %rdx
    3b14:      	cmovnel	%ecx, %eax
    3b17:      	jmp	0x3b2e <generic_kprobe_process_event+0x37de>
    3b19:      	movq	0x18(%rsp), %rax
    3b1e:      	movl	%r12d, 0x4(%rax)
    3b22:      	movl	$0x0, 0x8(%rax)
    3b29:      	xorl	%eax, %eax
    3b2b:      	xorl	%r12d, %r12d
    3b2e:      	movq	0x18(%rsp), %rcx
    3b33:      	movl	%eax, 0xc(%rcx)
    3b36:      	movl	%r12d, 0x10(%rcx)
    3b3a:      	movl	$0x24, %ebp
    3b3f:      	movq	0x38(%rsp), %rax
    3b44:      	movq	0x20(%rsp), %rcx
    3b49:      	movl	$0x4, %esi
    3b4e:      	movq	%rbp, %r13
    3b51:      	jmp	0x1733 <generic_kprobe_process_event+0x13e3>
    3b56:      	movzbl	0x7(%rbx), %eax
    3b5a:      	leal	0x8(,%rax,4), %eax
    3b61:      	movw	%ax, 0x2(%rbx)
    3b65:      	jmp	0x3b6b <generic_kprobe_process_event+0x381b>
    3b67:      	movzwl	0x2(%rbx), %eax
    3b6b:      	addw	(%rbx), %ax
    3b6e:      	movw	%ax, (%rbx)
    3b71:      	movzbl	0x6(%rbx), %r12d
    3b76:      	cmpq	$0x3c, %r12
    3b7a:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    3b80:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3b8a:      	btq	%r12, %rcx
    3b8e:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    3b94:      	movb	%r12b, 0x5(%rbx)
    3b98:      	movzwl	%ax, %ecx
    3b9b:      	addq	%rbp, %rcx
    3b9e:      	movl	$0x2, %edx
    3ba3:      	movl	$0x4, %eax
    3ba8:      	movzwl	(%rbx), %edx
    3bab:      	addq	%rbp, %rdx
    3bae:      	movq	%r15, %rdi
    3bb1:      	movl	$0x2, %esi
    3bb6:      	callq	*%rax
    3bb8:      	testq	%rax, %rax
    3bbb:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    3bc1:      	movzbl	0x5(%rbx), %eax
    3bc5:      	cmpl	$0x32, %eax
    3bc8:      	jg	0x3beb <generic_kprobe_process_event+0x389b>
    3bca:      	testl	%eax, %eax
    3bcc:      	je	0x3c13 <generic_kprobe_process_event+0x38c3>
    3bce:      	cmpl	$0x2b, %eax
    3bd1:      	je	0x3c13 <generic_kprobe_process_event+0x38c3>
    3bd3:      	cmpl	$0x2c, %eax
    3bd6:      	jne	0x3cab <generic_kprobe_process_event+0x395b>
    3bdc:      	movw	$0x8, 0x2(%rbx)
    3be2:      	movw	$0x8, %ax
    3be6:      	jmp	0x3caf <generic_kprobe_process_event+0x395f>
    3beb:      	cmpl	$0x33, %eax
    3bee:      	je	0x3c9a <generic_kprobe_process_event+0x394a>
    3bf4:      	cmpl	$0x3c, %eax
    3bf7:      	je	0x3c13 <generic_kprobe_process_event+0x38c3>
    3bf9:      	cmpl	$0xff, %eax
    3bfe:      	jne	0x3cab <generic_kprobe_process_event+0x395b>
    3c04:      	movw	$0x28, 0x2(%rbx)
    3c0a:      	movw	$0x28, %ax
    3c0e:      	jmp	0x3caf <generic_kprobe_process_event+0x395f>
    3c13:      	movzbl	0x7(%rbx), %eax
    3c17:      	leal	0x8(,%rax,8), %eax
    3c1e:      	movw	%ax, 0x2(%rbx)
    3c22:      	jmp	0x3caf <generic_kprobe_process_event+0x395f>
    3c27:      	addq	$0x568, %rax            # imm = 0x568
    3c2d:      	jmp	0x3c4d <generic_kprobe_process_event+0x38fd>
    3c2f:      	addq	$0x570, %rax            # imm = 0x570
    3c35:      	jmp	0x3c4d <generic_kprobe_process_event+0x38fd>
    3c37:      	addq	$0x560, %rax            # imm = 0x560
    3c3d:      	jmp	0x3c4d <generic_kprobe_process_event+0x38fd>
    3c3f:      	addq	$0x550, %rax            # imm = 0x550
    3c45:      	jmp	0x3c4d <generic_kprobe_process_event+0x38fd>
    3c47:      	addq	$0x540, %rax            # imm = 0x540
    3c4d:      	lock
    3c4e:      	incq	(%rax)
    3c51:      	testl	%ebx, %ebx
    3c53:      	js	0x3c6d <generic_kprobe_process_event+0x391d>
    3c55:      	movq	$0x0, 0x4(%r14)
    3c5d:      	movl	%r12d, %ecx
    3c60:      	subl	%ebx, %ecx
    3c62:      	xorl	%eax, %eax
    3c64:      	cmpq	$-0x1, %r12
    3c68:      	cmovnel	%ecx, %eax
    3c6b:      	jmp	0x3c7d <generic_kprobe_process_event+0x392d>
    3c6d:      	movl	%ebx, 0x4(%r14)
    3c71:      	movl	$0x0, 0x8(%r14)
    3c79:      	xorl	%eax, %eax
    3c7b:      	xorl	%ebx, %ebx
    3c7d:      	movl	%eax, 0xc(%r14)
    3c81:      	movl	%ebx, 0x10(%r14)
    3c85:      	movl	$0x24, %r13d
    3c8b:      	movq	0x10(%rsp), %rbx
    3c90:      	movq	0x28(%rsp), %r14
    3c95:      	jmp	0x1724 <generic_kprobe_process_event+0x13d4>
    3c9a:      	movzbl	0x7(%rbx), %eax
    3c9e:      	leal	0x8(,%rax,4), %eax
    3ca5:      	movw	%ax, 0x2(%rbx)
    3ca9:      	jmp	0x3caf <generic_kprobe_process_event+0x395f>
    3cab:      	movzwl	0x2(%rbx), %eax
    3caf:      	addw	(%rbx), %ax
    3cb2:      	movw	%ax, (%rbx)
    3cb5:      	movzbl	0x6(%rbx), %r12d
    3cba:      	cmpq	$0x3c, %r12
    3cbe:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    3cc4:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3cce:      	btq	%r12, %rcx
    3cd2:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    3cd8:      	movb	%r12b, 0x5(%rbx)
    3cdc:      	movzwl	%ax, %ecx
    3cdf:      	addq	%rbp, %rcx
    3ce2:      	movl	$0x2, %edx
    3ce7:      	movl	$0x4, %eax
    3cec:      	movzwl	(%rbx), %edx
    3cef:      	addq	%rbp, %rdx
    3cf2:      	movq	%r15, %rdi
    3cf5:      	movl	$0x2, %esi
    3cfa:      	callq	*%rax
    3cfc:      	testq	%rax, %rax
    3cff:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    3d05:      	movzbl	0x5(%rbx), %eax
    3d09:      	cmpl	$0x32, %eax
    3d0c:      	jg	0x3d28 <generic_kprobe_process_event+0x39d8>
    3d0e:      	testl	%eax, %eax
    3d10:      	je	0x3d45 <generic_kprobe_process_event+0x39f5>
    3d12:      	cmpl	$0x2b, %eax
    3d15:      	je	0x3d45 <generic_kprobe_process_event+0x39f5>
    3d17:      	cmpl	$0x2c, %eax
    3d1a:      	jne	0x3d67 <generic_kprobe_process_event+0x3a17>
    3d1c:      	movw	$0x8, 0x2(%rbx)
    3d22:      	movw	$0x8, %ax
    3d26:      	jmp	0x3d6b <generic_kprobe_process_event+0x3a1b>
    3d28:      	cmpl	$0x33, %eax
    3d2b:      	je	0x3d56 <generic_kprobe_process_event+0x3a06>
    3d2d:      	cmpl	$0x3c, %eax
    3d30:      	je	0x3d45 <generic_kprobe_process_event+0x39f5>
    3d32:      	cmpl	$0xff, %eax
    3d37:      	jne	0x3d67 <generic_kprobe_process_event+0x3a17>
    3d39:      	movw	$0x28, 0x2(%rbx)
    3d3f:      	movw	$0x28, %ax
    3d43:      	jmp	0x3d6b <generic_kprobe_process_event+0x3a1b>
    3d45:      	movzbl	0x7(%rbx), %eax
    3d49:      	leal	0x8(,%rax,8), %eax
    3d50:      	movw	%ax, 0x2(%rbx)
    3d54:      	jmp	0x3d6b <generic_kprobe_process_event+0x3a1b>
    3d56:      	movzbl	0x7(%rbx), %eax
    3d5a:      	leal	0x8(,%rax,4), %eax
    3d61:      	movw	%ax, 0x2(%rbx)
    3d65:      	jmp	0x3d6b <generic_kprobe_process_event+0x3a1b>
    3d67:      	movzwl	0x2(%rbx), %eax
    3d6b:      	addw	(%rbx), %ax
    3d6e:      	movw	%ax, (%rbx)
    3d71:      	movzbl	0x6(%rbx), %r12d
    3d76:      	cmpq	$0x3c, %r12
    3d7a:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    3d80:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3d8a:      	btq	%r12, %rcx
    3d8e:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    3d94:      	movb	%r12b, 0x5(%rbx)
    3d98:      	movzwl	%ax, %ecx
    3d9b:      	addq	%rbp, %rcx
    3d9e:      	movl	$0x2, %edx
    3da3:      	movl	$0x4, %eax
    3da8:      	movzwl	(%rbx), %edx
    3dab:      	addq	%rbp, %rdx
    3dae:      	movq	%r15, %rdi
    3db1:      	movl	$0x2, %esi
    3db6:      	callq	*%rax
    3db8:      	testq	%rax, %rax
    3dbb:      	js	0x3e74 <generic_kprobe_process_event+0x3b24>
    3dc1:      	movzbl	0x5(%rbx), %eax
    3dc5:      	cmpl	$0x32, %eax
    3dc8:      	jg	0x3de4 <generic_kprobe_process_event+0x3a94>
    3dca:      	testl	%eax, %eax
    3dcc:      	je	0x3e01 <generic_kprobe_process_event+0x3ab1>
    3dce:      	cmpl	$0x2b, %eax
    3dd1:      	je	0x3e01 <generic_kprobe_process_event+0x3ab1>
    3dd3:      	cmpl	$0x2c, %eax
    3dd6:      	jne	0x3e23 <generic_kprobe_process_event+0x3ad3>
    3dd8:      	movw	$0x8, 0x2(%rbx)
    3dde:      	movw	$0x8, %ax
    3de2:      	jmp	0x3e27 <generic_kprobe_process_event+0x3ad7>
    3de4:      	cmpl	$0x33, %eax
    3de7:      	je	0x3e12 <generic_kprobe_process_event+0x3ac2>
    3de9:      	cmpl	$0x3c, %eax
    3dec:      	je	0x3e01 <generic_kprobe_process_event+0x3ab1>
    3dee:      	cmpl	$0xff, %eax
    3df3:      	jne	0x3e23 <generic_kprobe_process_event+0x3ad3>
    3df5:      	movw	$0x28, 0x2(%rbx)
    3dfb:      	movw	$0x28, %ax
    3dff:      	jmp	0x3e27 <generic_kprobe_process_event+0x3ad7>
    3e01:      	movzbl	0x7(%rbx), %eax
    3e05:      	leal	0x8(,%rax,8), %eax
    3e0c:      	movw	%ax, 0x2(%rbx)
    3e10:      	jmp	0x3e27 <generic_kprobe_process_event+0x3ad7>
    3e12:      	movzbl	0x7(%rbx), %eax
    3e16:      	leal	0x8(,%rax,4), %eax
    3e1d:      	movw	%ax, 0x2(%rbx)
    3e21:      	jmp	0x3e27 <generic_kprobe_process_event+0x3ad7>
    3e23:      	movzwl	0x2(%rbx), %eax
    3e27:      	addw	(%rbx), %ax
    3e2a:      	movw	%ax, (%rbx)
    3e2d:      	movzbl	0x6(%rbx), %r12d
    3e32:      	cmpq	$0x3c, %r12
    3e36:      	ja	0x404e <generic_kprobe_process_event+0x3cfe>
    3e3c:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3e46:      	btq	%r12, %rcx
    3e4a:      	jae	0x404e <generic_kprobe_process_event+0x3cfe>
    3e50:      	movb	%r12b, 0x5(%rbx)
    3e54:      	movzwl	%ax, %ecx
    3e57:      	addq	%rbp, %rcx
    3e5a:      	movl	$0x2, %edx
    3e5f:      	movl	$0x4, %eax
    3e64:      	movzwl	(%rbx), %edx
    3e67:      	addq	%rbp, %rdx
    3e6a:      	movq	%r15, %rdi
    3e6d:      	movl	$0x2, %esi
    3e72:      	callq	*%rax
    3e74:      	xorl	%r12d, %r12d
    3e77:      	movb	%r12b, 0xd8(%rsp)
    3e7f:      	movzbl	%r12b, %eax
    3e83:      	movq	0x30(%rsp), %rbx
    3e88:      	movw	%ax, 0x24(%rbx)
    3e8c:      	movw	$0xa, 0x26(%rbx)
    3e92:      	leaq	0x8(%r14), %rdx
    3e96:      	movl	$0x10, %ecx
    3e9b:      	movl	$0x4, %eax
    3ea0:      	movq	%rbx, %rdi
    3ea3:      	movl	$0x10, %esi
    3ea8:      	callq	*%rax
    3eaa:      	leaq	0x10(%rbx), %rdi
    3eae:      	addq	$0x18, %r14
    3eb2:      	movl	$0x10, %ecx
    3eb7:      	movl	$0x4, %eax
    3ebc:      	movl	$0x10, %esi
    3ec1:      	movq	%r14, %rdx
    3ec4:      	callq	*%rax
    3ec6:      	cmpb	$0x11, %r12b
    3eca:      	je	0x3f1d <generic_kprobe_process_event+0x3bcd>
    3ecc:      	movzbl	%r12b, %eax
    3ed0:      	cmpl	$0x6, %eax
    3ed3:      	jne	0x3f68 <generic_kprobe_process_event+0x3c18>
    3ed9:      	movq	0x68(%rsp), %r15
    3ede:      	movzwl	0xc8(%rsp), %r12d
    3ee7:      	leaq	(%r15,%r12), %rdx
    3eeb:      	movq	0x30(%rsp), %rbx
    3ef0:      	leaq	0x20(%rbx), %rdi
    3ef4:      	movl	$0x2, %ecx
    3ef9:      	movl	$0x4, %eax
    3efe:      	movl	$0x2, %esi
    3f03:      	callq	*%rax
    3f05:      	leaq	0x22(%rbx), %rdi
    3f09:      	leaq	(%r15,%r12), %rdx
    3f0d:      	addq	$0x2, %rdx
    3f11:      	movl	$0x2, %ecx
    3f16:      	movl	$0x4, %eax
    3f1b:      	jmp	0x3f5f <generic_kprobe_process_event+0x3c0f>
    3f1d:      	movq	0x68(%rsp), %r15
    3f22:      	movzwl	0xc8(%rsp), %r12d
    3f2b:      	leaq	(%r15,%r12), %rdx
    3f2f:      	movq	0x30(%rsp), %rbx
    3f34:      	leaq	0x20(%rbx), %rdi
    3f38:      	movl	$0x2, %ecx
    3f3d:      	movl	$0x4, %eax
    3f42:      	movl	$0x2, %esi
    3f47:      	callq	*%rax
    3f49:      	leaq	0x22(%rbx), %rdi
    3f4d:      	leaq	(%r15,%r12), %rdx
    3f51:      	addq	$0x2, %rdx
    3f55:      	movl	$0x2, %ecx
    3f5a:      	movl	$0x4, %eax
    3f5f:      	movl	$0x2, %esi
    3f64:      	callq	*%rax
    3f66:      	jmp	0x3f74 <generic_kprobe_process_event+0x3c24>
    3f68:      	movq	0x30(%rsp), %rax
    3f6d:      	movl	$0x0, 0x20(%rax)
    3f74:      	movq	0x30(%rsp), %rdx
    3f79:      	movzwl	0x20(%rdx), %eax
    3f7d:      	movzwl	0x22(%rdx), %ecx
    3f81:      	movbew	%ax, 0x20(%rdx)
    3f87:      	movbew	%cx, 0x22(%rdx)
    3f8d:      	addq	$0xe0, %r13
    3f94:      	leaq	0x58(%rsp), %rdi
    3f99:      	movl	$0x8, %ecx
    3f9e:      	movl	$0x4, %eax
    3fa3:      	movl	$0x4, %r15d
    3fa9:      	movl	$0x8, %esi
    3fae:      	movq	%r13, %rdx
    3fb1:      	callq	*%rax
    3fb3:      	movq	0x58(%rsp), %rcx
    3fb8:      	testq	%rcx, %rcx
    3fbb:      	je	0x4028 <generic_kprobe_process_event+0x3cd8>
    3fbd:      	addq	$0x5, %rcx
    3fc1:      	leaq	0xb8(%rsp), %rdi
    3fc9:      	movl	$0x8, %edx
    3fce:      	movl	$0x4, %eax
    3fd3:      	movq	0x58(%rsp), %rdx
    3fd8:      	addq	$0x5, %rdx
    3fdc:      	movl	$0x8, %esi
    3fe1:      	callq	*%rax
    3fe3:      	movq	0x58(%rsp), %r12
    3fe8:      	movq	0xb8(%rsp), %r13
    3ff0:      	movq	0x30(%rsp), %rbx
    3ff5:      	leaq	0x38(%rbx), %rdi
    3ff9:      	leaq	(%r12,%r13,8), %rdx
    3ffd:      	addq	$0x44, %rdx
    4001:      	movl	$0x4, %eax
    4006:      	movl	$0x4, %esi
    400b:      	callq	*%rax
    400d:      	addq	$0x3c, %rbx
    4011:      	leaq	(%r12,%r13,8), %rdx
    4015:      	addq	$0x45, %rdx
    4019:      	movl	$0x4, %eax
    401e:      	movq	%rbx, %rdi
    4021:      	movl	$0x4, %esi
    4026:      	callq	*%rax
    4028:      	movl	$0x40, %ebp
    402d:      	movq	0x38(%rsp), %rax
    4032:      	movq	0x20(%rsp), %rcx
    4037:      	movl	$0x4, %esi
    403c:      	movq	0x10(%rsp), %rbx
    4041:      	movq	0x28(%rsp), %r14
    4046:      	movq	%rbp, %r13
    4049:      	jmp	0x1733 <generic_kprobe_process_event+0x13e3>
    404e:      	movw	%ax, 0xc8(%rsp)
    4056:      	jmp	0x3e77 <generic_kprobe_process_event+0x3b27>
    405b:      	nopl	(%rax,%rax)

0000000000004060 <generic_kprobe_process_filter>:
    4060:      	pushq	%rbp
    4061:      	pushq	%r15
    4063:      	pushq	%r14
    4065:      	pushq	%r13
    4067:      	pushq	%r12
    4069:      	pushq	%rbx
    406a:      	subq	$0xf8, %rsp
    4071:      	movq	%rdi, %rbp
    4074:      	movl	$0x0, 0xc8(%rsp)
    407f:      	movq	(%rip), %rdi            # 0x4086 <generic_kprobe_process_filter+0x26>
    4086:      	leaq	0xc8(%rsp), %rsi
    408e:      	movl	$0x1, %eax
    4093:      	callq	*%rax
    4095:      	testq	%rax, %rax
    4098:      	je	0x6316 <generic_kprobe_process_filter+0x22b6>
    409e:      	movq	%rax, %r12
    40a1:      	movl	$0x23, %eax
    40a6:      	callq	*%rax
    40a8:      	movq	%rax, %rcx
    40ab:      	movq	%rax, 0x50(%rsp)
    40b0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    40b7:      	leaq	0x48(%rsp), %rdi
    40bc:      	movl	$0x4, %edx
    40c1:      	movl	$0x71, %eax
    40c6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    40cb:      	addq	0x50(%rsp), %rdx
    40d0:      	movl	$0x4, %esi
    40d5:      	callq	*%rax
    40d7:      	movl	0x48(%rsp), %eax
    40db:      	movl	%eax, 0x38(%rsp)
    40df:      	movq	(%rip), %rdi            # 0x40e6 <generic_kprobe_process_filter+0x86>
    40e6:      	leaq	0x38(%rsp), %rsi
    40eb:      	movl	$0x1, %eax
    40f0:      	callq	*%rax
    40f2:      	testq	%rax, %rax
    40f5:      	movq	%r12, 0x30(%rsp)
    40fa:      	je	0x410a <generic_kprobe_process_filter+0xaa>
    40fc:      	movq	%rax, %r14
    40ff:      	cmpq	$0x0, 0x8(%rax)
    4104:      	jne	0x4f22 <generic_kprobe_process_filter+0xec2>
    410a:      	movl	$0xb00, %edx            # imm = 0xB00
    410f:      	movq	0x50(%rsp), %rcx
    4114:      	addq	%rdx, %rcx
    4117:      	leaq	0x50(%rsp), %rdi
    411c:      	movl	$0x8, %esi
    4121:      	movl	$0x71, %eax
    4126:      	addq	0x50(%rsp), %rdx
    412b:      	movl	$0x8, %esi
    4130:      	callq	*%rax
    4132:      	movq	0x50(%rsp), %rcx
    4137:      	testq	%rcx, %rcx
    413a:      	je	0x42cf <generic_kprobe_process_filter+0x26f>
    4140:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4147:      	leaq	0x48(%rsp), %rdi
    414c:      	movl	$0x4, %edx
    4151:      	movl	$0x71, %eax
    4156:      	movl	$0xaf4, %edx            # imm = 0xAF4
    415b:      	addq	0x50(%rsp), %rdx
    4160:      	movl	$0x4, %esi
    4165:      	callq	*%rax
    4167:      	movl	0x48(%rsp), %eax
    416b:      	movl	%eax, 0x38(%rsp)
    416f:      	movq	(%rip), %rdi            # 0x4176 <generic_kprobe_process_filter+0x116>
    4176:      	leaq	0x38(%rsp), %rsi
    417b:      	movl	$0x1, %eax
    4180:      	callq	*%rax
    4182:      	testq	%rax, %rax
    4185:      	je	0x4195 <generic_kprobe_process_filter+0x135>
    4187:      	movq	%rax, %r14
    418a:      	cmpq	$0x0, 0x8(%rax)
    418f:      	jne	0x4f22 <generic_kprobe_process_filter+0xec2>
    4195:      	movl	$0xb00, %edx            # imm = 0xB00
    419a:      	movq	0x50(%rsp), %rcx
    419f:      	addq	%rdx, %rcx
    41a2:      	leaq	0x50(%rsp), %rdi
    41a7:      	movl	$0x8, %esi
    41ac:      	movl	$0x71, %eax
    41b1:      	addq	0x50(%rsp), %rdx
    41b6:      	movl	$0x8, %esi
    41bb:      	callq	*%rax
    41bd:      	movq	0x50(%rsp), %rcx
    41c2:      	testq	%rcx, %rcx
    41c5:      	je	0x42cf <generic_kprobe_process_filter+0x26f>
    41cb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    41d2:      	leaq	0x48(%rsp), %rdi
    41d7:      	movl	$0x4, %edx
    41dc:      	movl	$0x71, %eax
    41e1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    41e6:      	addq	0x50(%rsp), %rdx
    41eb:      	movl	$0x4, %esi
    41f0:      	callq	*%rax
    41f2:      	movl	0x48(%rsp), %eax
    41f6:      	movl	%eax, 0x38(%rsp)
    41fa:      	movq	(%rip), %rdi            # 0x4201 <generic_kprobe_process_filter+0x1a1>
    4201:      	leaq	0x38(%rsp), %rsi
    4206:      	movl	$0x1, %eax
    420b:      	callq	*%rax
    420d:      	testq	%rax, %rax
    4210:      	je	0x4220 <generic_kprobe_process_filter+0x1c0>
    4212:      	movq	%rax, %r14
    4215:      	cmpq	$0x0, 0x8(%rax)
    421a:      	jne	0x4f22 <generic_kprobe_process_filter+0xec2>
    4220:      	movl	$0xb00, %edx            # imm = 0xB00
    4225:      	movq	0x50(%rsp), %rcx
    422a:      	addq	%rdx, %rcx
    422d:      	leaq	0x50(%rsp), %rdi
    4232:      	movl	$0x8, %esi
    4237:      	movl	$0x71, %eax
    423c:      	addq	0x50(%rsp), %rdx
    4241:      	movl	$0x8, %esi
    4246:      	callq	*%rax
    4248:      	movq	0x50(%rsp), %rcx
    424d:      	testq	%rcx, %rcx
    4250:      	je	0x42cf <generic_kprobe_process_filter+0x26f>
    4252:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4259:      	leaq	0x48(%rsp), %rdi
    425e:      	movl	$0x4, %edx
    4263:      	movl	$0x71, %eax
    4268:      	movl	$0xaf4, %edx            # imm = 0xAF4
    426d:      	addq	0x50(%rsp), %rdx
    4272:      	movl	$0x4, %esi
    4277:      	callq	*%rax
    4279:      	movl	0x48(%rsp), %eax
    427d:      	movl	%eax, 0x38(%rsp)
    4281:      	movq	(%rip), %rdi            # 0x4288 <generic_kprobe_process_filter+0x228>
    4288:      	leaq	0x38(%rsp), %rsi
    428d:      	movl	$0x1, %eax
    4292:      	callq	*%rax
    4294:      	testq	%rax, %rax
    4297:      	je	0x42a7 <generic_kprobe_process_filter+0x247>
    4299:      	movq	%rax, %r14
    429c:      	cmpq	$0x0, 0x8(%rax)
    42a1:      	jne	0x4f22 <generic_kprobe_process_filter+0xec2>
    42a7:      	movl	$0xb00, %edx            # imm = 0xB00
    42ac:      	movq	0x50(%rsp), %rcx
    42b1:      	addq	%rdx, %rcx
    42b4:      	leaq	0x50(%rsp), %rdi
    42b9:      	movl	$0x8, %esi
    42be:      	movl	$0x71, %eax
    42c3:      	addq	0x50(%rsp), %rdx
    42c8:      	movl	$0x8, %esi
    42cd:      	callq	*%rax
    42cf:      	movl	$0x23, %eax
    42d4:      	callq	*%rax
    42d6:      	movq	%rax, %r13
    42d9:      	leaq	0xaf4(%rax), %rdx
    42e0:      	leaq	0x50(%rsp), %rdi
    42e5:      	movl	$0x4, %ecx
    42ea:      	movl	$0x4, %eax
    42ef:      	movl	$0x4, %r14d
    42f5:      	movl	$0x4, %esi
    42fa:      	callq	*%rax
    42fc:      	movl	0x50(%rsp), %eax
    4300:      	movl	%eax, 0x5f10(%r12)
    4308:      	movl	$0x7d, %eax
    430d:      	callq	*%rax
    430f:      	movq	%rax, 0x5f18(%r12)
    4317:      	movl	$0x0, 0x5f20(%r12)
    4323:      	movq	$0x0, 0x5f28(%r12)
    432f:      	movl	$0x0, 0x5f30(%r12)
    433b:      	leaq	0x60(%r13), %rdx
    433f:      	leaq	0x38(%rsp), %rdi
    4344:      	movl	$0x8, %ecx
    4349:      	movl	$0x71, %eax
    434e:      	movl	$0x8, %esi
    4353:      	callq	*%rax
    4355:      	movq	0x38(%rsp), %rcx
    435a:      	xorl	%ebx, %ebx
    435c:      	testq	%rcx, %rcx
    435f:      	je	0x43ce <generic_kprobe_process_filter+0x36e>
    4361:      	addq	$0x4, %rcx
    4365:      	leaq	0x48(%rsp), %rdi
    436a:      	movl	$0x4, %edx
    436f:      	movl	$0x71, %eax
    4374:      	movq	0x38(%rsp), %rdx
    4379:      	addq	$0x4, %rdx
    437d:      	movl	$0x4, %esi
    4382:      	callq	*%rax
    4384:      	movl	0x48(%rsp), %eax
    4388:      	testl	%eax, %eax
    438a:      	je	0x43ce <generic_kprobe_process_filter+0x36e>
    438c:      	movq	0x38(%rsp), %rcx
    4391:      	shll	$0x4, %eax
    4394:      	addq	%rax, %rcx
    4397:      	addq	$0x80, %rcx
    439e:      	leaq	0x50(%rsp), %rdi
    43a3:      	movl	$0x10, %edx
    43a8:      	movl	$0x71, %eax
    43ad:      	movq	0x38(%rsp), %rcx
    43b2:      	movl	0x48(%rsp), %edx
    43b6:      	shll	$0x4, %edx
    43b9:      	addq	%rcx, %rdx
    43bc:      	addq	$0x80, %rdx
    43c3:      	movl	$0x10, %esi
    43c8:      	callq	*%rax
    43ca:      	movl	0x50(%rsp), %ebx
    43ce:      	movl	%ebx, 0x5f34(%r12)
    43d6:      	leaq	0xd00(%r13), %r15
    43dd:      	leaq	0x50(%rsp), %rdi
    43e2:      	movl	$0x8, %ecx
    43e7:      	movl	$0x4, %eax
    43ec:      	leaq	0x5f60(%r12), %rbx
    43f4:      	movl	$0x8, %esi
    43f9:      	movq	%r15, %rdx
    43fc:      	callq	*%rax
    43fe:      	movq	0x50(%rsp), %r12
    4403:      	movq	0x30(%rsp), %rax
    4408:      	leaq	0x5f68(%rax), %rdi
    440f:      	leaq	0x40(%r12), %rdx
    4414:      	movl	$0x8, %ecx
    4419:      	movl	$0x4, %eax
    441e:      	movl	$0x8, %esi
    4423:      	callq	*%rax
    4425:      	movq	0x30(%rsp), %rax
    442a:      	leaq	0x5f70(%rax), %rdi
    4431:      	leaq	0x30(%r12), %rdx
    4436:      	movl	$0x8, %ecx
    443b:      	movl	$0x4, %eax
    4440:      	movl	$0x8, %esi
    4445:      	callq	*%rax
    4447:      	addq	$0x38, %r12
    444b:      	movl	$0x8, %ecx
    4450:      	movl	$0x4, %eax
    4455:      	movq	%rbx, %rdi
    4458:      	movl	$0x8, %esi
    445d:      	movq	%r12, %rdx
    4460:      	movq	0x30(%rsp), %r12
    4465:      	callq	*%rax
    4467:      	leaq	0x5f38(%r12), %rbx
    446f:      	leaq	0xd70(%r13), %rdx
    4476:      	leaq	0x48(%rsp), %rdi
    447b:      	movl	$0x8, %ecx
    4480:      	movl	$0x4, %eax
    4485:      	movl	$0x8, %esi
    448a:      	callq	*%rax
    448c:      	movq	0x48(%rsp), %rcx
    4491:      	leaq	0x50(%rsp), %rdi
    4496:      	movl	$0x48, %edx
    449b:      	movl	$0x4, %eax
    44a0:      	movq	0x48(%rsp), %rdx
    44a5:      	movl	$0x48, %esi
    44aa:      	callq	*%rax
    44ac:      	movl	$0x218, %edx            # imm = 0x218
    44b1:      	movq	0x58(%rsp), %rcx
    44b6:      	addq	%rdx, %rcx
    44b9:      	movl	$0x4, %eax
    44be:      	addq	0x58(%rsp), %rdx
    44c3:      	movq	%rbx, %rdi
    44c6:      	movl	$0x4, %esi
    44cb:      	callq	*%rax
    44cd:      	leaq	0x5f3c(%r12), %rdi
    44d5:      	movl	$0x4d8, %edx            # imm = 0x4D8
    44da:      	movq	0x60(%rsp), %rcx
    44df:      	addq	%rdx, %rcx
    44e2:      	movl	$0x4, %eax
    44e7:      	addq	0x60(%rsp), %rdx
    44ec:      	movl	$0x4, %esi
    44f1:      	callq	*%rax
    44f3:      	leaq	0x5f40(%r12), %rdi
    44fb:      	movq	0x68(%rsp), %rcx
    4500:      	addq	$0x58, %rcx
    4504:      	movl	$0x4, %eax
    4509:      	movq	0x68(%rsp), %rdx
    450e:      	addq	$0x58, %rdx
    4512:      	movl	$0x4, %esi
    4517:      	callq	*%rax
    4519:      	movq	$0x0, 0xa0(%rsp)
    4525:      	leaq	0xb58(%r13), %rdx
    452c:      	leaq	0xa0(%rsp), %rdi
    4534:      	movl	$0x8, %ecx
    4539:      	movl	$0x4, %eax
    453e:      	movl	$0x8, %esi
    4543:      	callq	*%rax
    4545:      	movq	0xa0(%rsp), %rcx
    454d:      	testq	%rcx, %rcx
    4550:      	je	0x4609 <generic_kprobe_process_filter+0x5a9>
    4556:      	movl	$0x0, 0xc0(%rsp)
    4561:      	addq	$0x4, %rcx
    4565:      	leaq	0xc0(%rsp), %rdi
    456d:      	movl	$0x4, %edx
    4572:      	movl	$0x4, %eax
    4577:      	movq	0xa0(%rsp), %rdx
    457f:      	addq	$0x4, %rdx
    4583:      	movl	$0x4, %esi
    4588:      	callq	*%rax
    458a:      	movq	0xa0(%rsp), %rax
    4592:      	movslq	0xc0(%rsp), %rcx
    459a:      	shlq	$0x4, %rcx
    459e:      	addq	%rax, %rcx
    45a1:      	addq	$0x80, %rcx
    45a8:      	leaq	0x38(%rsp), %rdi
    45ad:      	movl	$0x10, %edx
    45b2:      	movl	$0x4, %eax
    45b7:      	movq	0xa0(%rsp), %rcx
    45bf:      	movslq	0xc0(%rsp), %rdx
    45c7:      	shlq	$0x4, %rdx
    45cb:      	addq	%rcx, %rdx
    45ce:      	addq	$0x80, %rdx
    45d5:      	movl	$0x10, %esi
    45da:      	callq	*%rax
    45dc:      	leaq	0x5f44(%r12), %rdi
    45e4:      	movl	$0x158, %edx            # imm = 0x158
    45e9:      	movq	0x40(%rsp), %rcx
    45ee:      	addq	%rdx, %rcx
    45f1:      	movl	$0x4, %esi
    45f6:      	movl	$0x4, %eax
    45fb:      	addq	0x40(%rsp), %rdx
    4600:      	movl	$0x4, %esi
    4605:      	callq	*%rax
    4607:      	jmp	0x4615 <generic_kprobe_process_filter+0x5b5>
    4609:      	movl	$0x0, 0x5f44(%r12)
    4615:      	movq	%rbp, 0xb0(%rsp)
    461d:      	leaq	0x5f48(%r12), %rdi
    4625:      	movl	$0x158, %ebx            # imm = 0x158
    462a:      	movq	0x70(%rsp), %rcx
    462f:      	addq	%rbx, %rcx
    4632:      	movl	$0x4, %edx
    4637:      	movl	$0x4, %eax
    463c:      	movq	0x70(%rsp), %rdx
    4641:      	addq	%rbx, %rdx
    4644:      	movl	$0x4, %esi
    4649:      	callq	*%rax
    464b:      	leaq	0x5f4c(%r12), %rdi
    4653:      	movl	$0x118, %edx            # imm = 0x118
    4658:      	movq	0x78(%rsp), %rcx
    465d:      	addq	%rdx, %rcx
    4660:      	movl	$0x4, %esi
    4665:      	movl	$0x4, %eax
    466a:      	addq	0x78(%rsp), %rdx
    466f:      	movl	$0x4, %esi
    4674:      	callq	*%rax
    4676:      	leaq	0x5f50(%r12), %rdi
    467e:      	movl	$0x98, %r12d
    4684:      	movq	0x80(%rsp), %rcx
    468c:      	addq	%r12, %rcx
    468f:      	movl	$0x4, %edx
    4694:      	movl	$0x4, %eax
    4699:      	movq	0x80(%rsp), %rdx
    46a1:      	addq	%r12, %rdx
    46a4:      	movl	$0x4, %esi
    46a9:      	callq	*%rax
    46ab:      	movq	0x30(%rsp), %rax
    46b0:      	leaq	0x5f54(%rax), %rdi
    46b7:      	movq	0x88(%rsp), %rcx
    46bf:      	addq	%r12, %rcx
    46c2:      	movl	$0x4, %edx
    46c7:      	movl	$0x4, %eax
    46cc:      	addq	0x88(%rsp), %r12
    46d4:      	movl	$0x4, %esi
    46d9:      	movq	%r12, %rdx
    46dc:      	movq	0x30(%rsp), %r12
    46e1:      	callq	*%rax
    46e3:      	leaq	0x5f58(%r12), %rdi
    46eb:      	movq	0x90(%rsp), %rcx
    46f3:      	addq	$0x58, %rcx
    46f7:      	movl	$0x4, %edx
    46fc:      	movl	$0x4, %eax
    4701:      	movq	0x90(%rsp), %rdx
    4709:      	addq	$0x58, %rdx
    470d:      	movl	$0x4, %esi
    4712:      	callq	*%rax
    4714:      	movq	$0x0, 0x38(%rsp)
    471d:      	movq	$0x0, 0xa0(%rsp)
    4729:      	leaq	0x38(%rsp), %rdi
    472e:      	movl	$0x8, %ecx
    4733:      	movl	$0x4, %eax
    4738:      	movl	$0x8, %esi
    473d:      	movq	%r15, %rdx
    4740:      	callq	*%rax
    4742:      	movl	$0x90, %edx
    4747:      	movq	0x38(%rsp), %rcx
    474c:      	addq	%rdx, %rcx
    474f:      	leaq	0xa0(%rsp), %rdi
    4757:      	movl	$0x8, %esi
    475c:      	movl	$0x4, %eax
    4761:      	addq	0x38(%rsp), %rdx
    4766:      	movl	$0x8, %esi
    476b:      	callq	*%rax
    476d:      	leaq	0x5f5c(%r12), %rdi
    4775:      	movq	0xa0(%rsp), %rcx
    477d:      	addq	%rbx, %rcx
    4780:      	movl	$0x4, %edx
    4785:      	movl	$0x4, %eax
    478a:      	addq	0xa0(%rsp), %rbx
    4792:      	movl	$0x4, %esi
    4797:      	movq	%rbx, %rdx
    479a:      	callq	*%rax
    479c:      	cmpl	$0x1, 0x5f34(%r12)
    47a5:      	jne	0x47b0 <generic_kprobe_process_filter+0x750>
    47a7:      	orb	$0x2, 0x5f33(%r12)
    47b0:      	leaq	0x5f78(%r12), %rdi
    47b8:      	movl	$0x308, %edx            # imm = 0x308
    47bd:      	movq	%rdi, 0xa8(%rsp)
    47c5:      	xorl	%esi, %esi
    47c7:      	callq	0x47cc <generic_kprobe_process_filter+0x76c>
    47cc:      	leaq	0x6290(%r12), %rax
    47d4:      	movq	%rax, 0x8(%rsp)
    47d9:      	addq	$0xa78, %r13            # imm = 0xA78
    47e0:      	leaq	0x38(%rsp), %rdi
    47e5:      	movl	$0x8, %ecx
    47ea:      	movl	$0x4, %eax
    47ef:      	movl	$0x8, %esi
    47f4:      	movq	%r13, %rdx
    47f7:      	callq	*%rax
    47f9:      	movl	$0x5f8, %edx            # imm = 0x5F8
    47fe:      	movq	0x38(%rsp), %rcx
    4803:      	addq	%rdx, %rcx
    4806:      	leaq	0x50(%rsp), %rdi
    480b:      	movl	$0x8, %esi
    4810:      	movl	$0x4, %eax
    4815:      	addq	0x38(%rsp), %rdx
    481a:      	movl	$0x8, %esi
    481f:      	callq	*%rax
    4821:      	movq	0x50(%rsp), %rbx
    4826:      	movl	$0x0, 0xcc(%rsp)
    4831:      	movq	(%rip), %rdi            # 0x4838 <generic_kprobe_process_filter+0x7d8>
    4838:      	leaq	0xcc(%rsp), %rsi
    4840:      	movl	$0x1, %eax
    4845:      	callq	*%rax
    4847:      	testq	%rax, %rax
    484a:      	je	0x4b8c <generic_kprobe_process_filter+0xb2c>
    4850:      	movq	%rax, %r15
    4853:      	movl	$0x1000, 0x6410(%r12)   # imm = 0x1000
    485f:      	leaq	0x1000(%rax), %r13
    4866:      	movl	$0x23, %eax
    486b:      	callq	*%rax
    486d:      	leaq	0xd50(%rax), %rdx
    4874:      	leaq	0xe8(%rsp), %rdi
    487c:      	movl	$0x8, %ecx
    4881:      	movl	$0x4, %eax
    4886:      	movl	$0x8, %esi
    488b:      	callq	*%rax
    488d:      	movq	0xe8(%rsp), %r12
    4895:      	leaq	0x48(%rbx), %rbp
    4899:      	leaq	0xf0(%rsp), %rdi
    48a1:      	movl	$0x8, %ecx
    48a6:      	movl	$0x4, %eax
    48ab:      	movl	$0x8, %esi
    48b0:      	movq	%rbp, %rdx
    48b3:      	callq	*%rax
    48b5:      	movq	0xf0(%rsp), %r14
    48bd:      	leaq	0x10(%r14), %rdx
    48c1:      	leaq	0x50(%rsp), %rdi
    48c6:      	movl	$0x8, %ecx
    48cb:      	movl	$0x4, %eax
    48d0:      	movl	$0x8, %esi
    48d5:      	callq	*%rax
    48d7:      	cmpq	$0x0, 0x50(%rsp)
    48dd:      	je	0x4c16 <generic_kprobe_process_filter+0xbb6>
    48e3:      	movq	%rbp, 0xb8(%rsp)
    48eb:      	movq	$0x0, 0x58(%rsp)
    48f4:      	movq	$0x0, 0x50(%rsp)
    48fd:      	movq	%r15, 0x60(%rsp)
    4902:      	movq	$0x0, 0x68(%rsp)
    490b:      	movq	$0x0, 0x70(%rsp)
    4914:      	movq	$0x0, 0x78(%rsp)
    491d:      	movq	%r13, 0x28(%rsp)
    4922:      	movq	%r13, 0x80(%rsp)
    492a:      	movq	0x30(%rsp), %rax
    492f:      	movl	0x6410(%rax), %eax
    4935:      	movl	%eax, 0x88(%rsp)
    493c:      	leaq	0x18(%r12), %r15
    4941:      	movb	$0x0, 0x8c(%rsp)
    4949:      	addq	$0x20, %r12
    494d:      	leaq	0x50(%rsp), %rdi
    4952:      	movl	$0x8, %r14d
    4958:      	movl	$0x4, %eax
    495d:      	addq	$0x40, %rbx
    4961:      	leaq	0x58(%rsp), %r13
    4966:      	leaq	0x68(%rsp), %rbp
    496b:      	movl	$0x8, %esi
    4970:      	movq	%r12, %rdx
    4973:      	callq	*%rax
    4975:      	movl	$0x8, %ecx
    497a:      	movl	$0x4, %eax
    497f:      	movq	%r13, %rdi
    4982:      	movl	$0x8, %esi
    4987:      	movq	%r15, %rdx
    498a:      	callq	*%rax
    498c:      	movl	$0x8, %ecx
    4991:      	movl	$0x4, %eax
    4996:      	movq	0xb8(%rsp), %rdx
    499e:      	movq	%rbp, %rdi
    49a1:      	movl	$0x8, %esi
    49a6:      	callq	*%rax
    49a8:      	movl	$0x8, %ecx
    49ad:      	movl	$0x4, %eax
    49b2:      	leaq	0x70(%rsp), %rdi
    49b7:      	movl	$0x8, %esi
    49bc:      	movq	%rbx, %rdx
    49bf:      	callq	*%rax
    49c1:      	movq	0x70(%rsp), %rax
    49c6:      	addq	$-0x20, %rax
    49ca:      	movq	%rax, 0x78(%rsp)
    49cf:      	movl	$0x80, %ebp
    49d4:      	leaq	0x48(%rsp), %rbx
    49d9:      	nopl	(%rax)
    49e0:      	movq	0x68(%rsp), %r15
    49e5:      	movq	0x70(%rsp), %rdx
    49ea:      	movq	0x78(%rsp), %r12
    49ef:      	cmpq	0x50(%rsp), %r15
    49f4:      	jne	0x4a01 <generic_kprobe_process_filter+0x9a1>
    49f6:      	cmpq	0x58(%rsp), %rdx
    49fb:      	je	0x4c75 <generic_kprobe_process_filter+0xc15>
    4a01:      	movl	$0x4, %eax
    4a06:      	leaq	0xc0(%rsp), %rdi
    4a0e:      	movl	$0x8, %esi
    4a13:      	callq	*%rax
    4a15:      	cmpq	0xc0(%rsp), %r15
    4a1d:      	je	0x4b30 <generic_kprobe_process_filter+0xad0>
    4a23:      	leaq	0x18(%r15), %r13
    4a27:      	movl	$0x4, %eax
    4a2c:      	movq	%rbx, %rdi
    4a2f:      	movl	$0x8, %esi
    4a34:      	movq	%r13, %rdx
    4a37:      	callq	*%rax
    4a39:      	cmpq	%r15, 0x48(%rsp)
    4a3e:      	je	0x4b30 <generic_kprobe_process_filter+0xad0>
    4a44:      	movl	$0x4, %eax
    4a49:      	leaq	0xa0(%rsp), %rdi
    4a51:      	movl	$0x8, %esi
    4a56:      	movq	%r13, %rdx
    4a59:      	callq	*%rax
    4a5b:      	addq	$0x20, %r15
    4a5f:      	movl	$0x4, %eax
    4a64:      	leaq	0x38(%rsp), %rdi
    4a69:      	movl	$0x10, %ecx
    4a6e:      	movl	$0x10, %esi
    4a73:      	movq	%r15, %rdx
    4a76:      	callq	*%rax
    4a78:      	movq	0x60(%rsp), %r15
    4a7d:      	movq	0x80(%rsp), %rax
    4a85:      	movl	0x3c(%rsp), %r12d
    4a8a:      	subq	%r15, %rax
    4a8d:      	movl	0x88(%rsp), %r13d
    4a95:      	movl	%r12d, %edx
    4a98:      	subl	%r13d, %edx
    4a9b:      	movl	$0x0, %ecx
    4aa0:      	cmovbl	%ecx, %edx
    4aa3:      	addq	0x40(%rsp), %rdx
    4aa8:      	xorl	%esi, %esi
    4aaa:      	cmpl	%r12d, %r13d
    4aad:      	seta	%sil
    4ab1:      	movl	%r12d, %ecx
    4ab4:      	cmovbl	%r13d, %ecx
    4ab8:      	addl	%ecx, %esi
    4aba:      	movl	%r13d, %edi
    4abd:      	subl	%esi, %edi
    4abf:      	movl	%edi, 0x88(%rsp)
    4ac6:      	subq	%rsi, %rax
    4ac9:      	jb	0x4c7d <generic_kprobe_process_filter+0xc1d>
    4acf:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4ad5:      	ja	0x4c7d <generic_kprobe_process_filter+0xc1d>
    4adb:      	cmpl	%r12d, %r13d
    4ade:      	jbe	0x4ae5 <generic_kprobe_process_filter+0xa85>
    4ae0:      	movb	$0x2f, (%r15,%rax)
    4ae5:      	xorl	%edi, %edi
    4ae7:      	cmpl	%r12d, %r13d
    4aea:      	seta	%dil
    4aee:      	movzbl	%cl, %esi
    4af1:      	addq	%rax, %r15
    4af4:      	addq	%r15, %rdi
    4af7:      	movl	$0x4, %eax
    4afc:      	callq	*%rax
    4afe:      	movq	%r15, 0x80(%rsp)
    4b06:      	cmpl	%r12d, %r13d
    4b09:      	jbe	0x4c7d <generic_kprobe_process_filter+0xc1d>
    4b0f:      	movq	0xa0(%rsp), %rax
    4b17:      	movq	%rax, 0x68(%rsp)
    4b1c:      	decl	%ebp
    4b1e:      	jne	0x49e0 <generic_kprobe_process_filter+0x980>
    4b24:      	jmp	0x4c7d <generic_kprobe_process_filter+0xc1d>
    4b29:      	nopl	(%rax)
    4b30:      	leaq	0x10(%r12), %rdx
    4b35:      	movl	$0x4, %eax
    4b3a:      	movq	%rbx, %rdi
    4b3d:      	movl	$0x8, %esi
    4b42:      	callq	*%rax
    4b44:      	movq	0x78(%rsp), %rax
    4b49:      	cmpq	0x48(%rsp), %rax
    4b4e:      	je	0x4dac <generic_kprobe_process_filter+0xd4c>
    4b54:      	addq	$0x18, %r12
    4b58:      	movl	$0x4, %eax
    4b5d:      	leaq	0x68(%rsp), %rdi
    4b62:      	movl	$0x8, %esi
    4b67:      	movq	%r12, %rdx
    4b6a:      	callq	*%rax
    4b6c:      	movq	0x48(%rsp), %rax
    4b71:      	movq	%rax, 0x78(%rsp)
    4b76:      	addq	$0x20, %rax
    4b7a:      	movq	%rax, 0x70(%rsp)
    4b7f:      	decl	%ebp
    4b81:      	jne	0x49e0 <generic_kprobe_process_filter+0x980>
    4b87:      	jmp	0x4c7d <generic_kprobe_process_filter+0xc1d>
    4b8c:      	movq	0xb0(%rsp), %rbp
    4b94:      	movl	0x6410(%r12), %eax
    4b9c:      	leal	-0x101(%rax), %ecx
    4ba2:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4ba8:      	jbe	0x4f06 <generic_kprobe_process_filter+0xea6>
    4bae:      	movzbl	%al, %ebx
    4bb1:      	leaq	0x5f80(%r12), %rdi
    4bb9:      	movl	$0x4, %eax
    4bbe:      	movq	0x8(%rsp), %rdx
    4bc3:      	movl	%ebx, %esi
    4bc5:      	callq	*%rax
    4bc7:      	movq	%rax, %r15
    4bca:      	testq	%rax, %rax
    4bcd:      	je	0x4d0d <generic_kprobe_process_filter+0xcad>
    4bd3:      	movl	%r15d, %eax
    4bd6:      	negl	%eax
    4bd8:      	movw	%ax, 0x50(%rsp)
    4bdd:      	movw	$0xf, 0x52(%rsp)
    4be4:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4bee:      	movq	%rax, 0x54(%rsp)
    4bf3:      	movq	(%rip), %rdi            # 0x4bfa <generic_kprobe_process_filter+0xb9a>
    4bfa:      	leaq	0x50(%rsp), %rsi
    4bff:      	movl	$0x1, %eax
    4c04:      	callq	*%rax
    4c06:      	testq	%rax, %rax
    4c09:      	je	0x4ce9 <generic_kprobe_process_filter+0xc89>
    4c0f:      	incl	(%rax)
    4c11:      	jmp	0x4d0d <generic_kprobe_process_filter+0xcad>
    4c16:      	leaq	0x18(%r14), %rdx
    4c1a:      	leaq	0x50(%rsp), %rdi
    4c1f:      	movl	$0x8, %ecx
    4c24:      	movl	$0x4, %eax
    4c29:      	movl	$0x8, %esi
    4c2e:      	callq	*%rax
    4c30:      	cmpq	%r14, 0x50(%rsp)
    4c35:      	je	0x48e3 <generic_kprobe_process_filter+0x883>
    4c3b:      	movq	0x30(%rsp), %rdx
    4c40:      	movl	0x6410(%rdx), %ecx
    4c46:      	leal	-0xa(%rcx), %eax
    4c49:      	movl	%eax, 0x6410(%rdx)
    4c4f:      	cmpl	$0x9, %ecx
    4c52:      	jg	0x5449 <generic_kprobe_process_filter+0x13e9>
    4c58:      	movl	$0xffffffdc, 0x6414(%rdx) # imm = 0xFFFFFFDC
    4c62:      	movq	%r13, %rbx
    4c65:      	movq	0xb0(%rsp), %rbp
    4c6d:      	movq	%rdx, %r12
    4c70:      	jmp	0x4df4 <generic_kprobe_process_filter+0xd94>
    4c75:      	movb	$0x1, 0x8c(%rsp)
    4c7d:      	movq	0x80(%rsp), %rbx
    4c85:      	movq	0x28(%rsp), %rcx
    4c8a:      	cmpq	%rcx, %rbx
    4c8d:      	je	0x4dca <generic_kprobe_process_filter+0xd6a>
    4c93:      	xorl	%ecx, %ecx
    4c95:      	cmpb	$0x0, 0x8c(%rsp)
    4c9d:      	sete	%cl
    4ca0:      	addl	%ecx, %ecx
    4ca2:      	movl	0x88(%rsp), %eax
    4ca9:      	movq	0x30(%rsp), %r12
    4cae:      	movl	%eax, 0x6410(%r12)
    4cb6:      	movl	%ecx, 0x6414(%r12)
    4cbe:      	testl	%eax, %eax
    4cc0:      	movq	0xb0(%rsp), %rbp
    4cc8:      	jle	0x4cdb <generic_kprobe_process_filter+0xc7b>
    4cca:      	movl	$0x1000, %ecx           # imm = 0x1000
    4ccf:      	subl	%eax, %ecx
    4cd1:      	movl	%ecx, 0x6410(%r12)
    4cd9:      	movl	%ecx, %eax
    4cdb:      	testq	%rbx, %rbx
    4cde:      	jne	0x4df4 <generic_kprobe_process_filter+0xd94>
    4ce4:      	jmp	0x4eec <generic_kprobe_process_filter+0xe8c>
    4ce9:      	movl	$0x1, 0x38(%rsp)
    4cf1:      	movq	(%rip), %rdi            # 0x4cf8 <generic_kprobe_process_filter+0xc98>
    4cf8:      	xorl	%ecx, %ecx
    4cfa:      	leaq	0x50(%rsp), %rsi
    4cff:      	leaq	0x38(%rsp), %rdx
    4d04:      	movl	$0x2, %eax
    4d09:      	xorl	%ecx, %ecx
    4d0b:      	callq	*%rax
    4d0d:      	testl	%r15d, %r15d
    4d10:      	cmovel	%ebx, %r15d
    4d14:      	movl	%r15d, 0x5f78(%r12)
    4d1c:      	cmpl	$0x7f, %ebx
    4d1f:      	movl	$0x7f, %esi
    4d24:      	cmovbl	%ebx, %esi
    4d27:      	leaq	0x6080(%r12), %rdi
    4d2f:      	leaq	0x6390(%r12), %rdx
    4d37:      	movl	$0x4, %eax
    4d3c:      	callq	*%rax
    4d3e:      	testq	%rax, %rax
    4d41:      	je	0x4f14 <generic_kprobe_process_filter+0xeb4>
    4d47:      	negl	%eax
    4d49:      	movw	%ax, 0x50(%rsp)
    4d4e:      	movw	$0xf, 0x52(%rsp)
    4d55:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    4d5f:      	movq	%rax, 0x54(%rsp)
    4d64:      	movq	(%rip), %rdi            # 0x4d6b <generic_kprobe_process_filter+0xd0b>
    4d6b:      	leaq	0x50(%rsp), %rsi
    4d70:      	movl	$0x1, %eax
    4d75:      	callq	*%rax
    4d77:      	testq	%rax, %rax
    4d7a:      	je	0x4d83 <generic_kprobe_process_filter+0xd23>
    4d7c:      	incl	(%rax)
    4d7e:      	jmp	0x4f14 <generic_kprobe_process_filter+0xeb4>
    4d83:      	movl	$0x1, 0x38(%rsp)
    4d8b:      	movq	(%rip), %rdi            # 0x4d92 <generic_kprobe_process_filter+0xd32>
    4d92:      	xorl	%ecx, %ecx
    4d94:      	leaq	0x50(%rsp), %rsi
    4d99:      	leaq	0x38(%rsp), %rdx
    4d9e:      	movl	$0x2, %eax
    4da3:      	xorl	%ecx, %ecx
    4da5:      	callq	*%rax
    4da7:      	jmp	0x4f14 <generic_kprobe_process_filter+0xeb4>
    4dac:      	movb	$0x1, 0x8c(%rsp)
    4db4:      	movq	0x80(%rsp), %rbx
    4dbc:      	movq	0x28(%rsp), %rcx
    4dc1:      	cmpq	%rcx, %rbx
    4dc4:      	jne	0x4c93 <generic_kprobe_process_filter+0xc33>
    4dca:      	movq	0x30(%rsp), %r12
    4dcf:      	movl	$0x0, 0x6410(%r12)
    4ddb:      	movl	$0x0, 0x6414(%r12)
    4de7:      	xorl	%eax, %eax
    4de9:      	movq	%rcx, %rbx
    4dec:      	movq	0xb0(%rsp), %rbp
    4df4:      	xorl	%ecx, %ecx
    4df6:      	movl	%eax, %r14d
    4df9:      	subl	$0x7f, %r14d
    4dfd:      	movl	$0x7f, %r15d
    4e03:      	cmovbl	%eax, %r15d
    4e07:      	cmovbl	%ecx, %r14d
    4e0b:      	cmpl	$0xff, %eax
    4e10:      	movl	$0xff, %ecx
    4e15:      	cmovbl	%eax, %ecx
    4e18:      	movzbl	%cl, %esi
    4e1b:      	movl	%esi, 0x6410(%r12)
    4e23:      	movl	$0x4, %eax
    4e28:      	movq	0x8(%rsp), %rdi
    4e2d:      	movq	%rbx, %rdx
    4e30:      	callq	*%rax
    4e32:      	testq	%rax, %rax
    4e35:      	je	0x4e94 <generic_kprobe_process_filter+0xe34>
    4e37:      	negl	%eax
    4e39:      	movw	%ax, 0x50(%rsp)
    4e3e:      	movw	$0x8, 0x52(%rsp)
    4e45:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4e4f:      	movq	%rax, 0x54(%rsp)
    4e54:      	movq	(%rip), %rdi            # 0x4e5b <generic_kprobe_process_filter+0xdfb>
    4e5b:      	leaq	0x50(%rsp), %rsi
    4e60:      	movl	$0x1, %eax
    4e65:      	callq	*%rax
    4e67:      	testq	%rax, %rax
    4e6a:      	je	0x4e70 <generic_kprobe_process_filter+0xe10>
    4e6c:      	incl	(%rax)
    4e6e:      	jmp	0x4e94 <generic_kprobe_process_filter+0xe34>
    4e70:      	movl	$0x1, 0x38(%rsp)
    4e78:      	movq	(%rip), %rdi            # 0x4e7f <generic_kprobe_process_filter+0xe1f>
    4e7f:      	xorl	%ecx, %ecx
    4e81:      	leaq	0x50(%rsp), %rsi
    4e86:      	leaq	0x38(%rsp), %rdx
    4e8b:      	movl	$0x2, %eax
    4e90:      	xorl	%ecx, %ecx
    4e92:      	callq	*%rax
    4e94:      	leaq	0x6390(%r12), %rdi
    4e9c:      	addq	%r14, %rbx
    4e9f:      	movl	$0x4, %eax
    4ea4:      	movl	%r15d, %esi
    4ea7:      	movq	%rbx, %rdx
    4eaa:      	callq	*%rax
    4eac:      	testq	%rax, %rax
    4eaf:      	je	0x4eec <generic_kprobe_process_filter+0xe8c>
    4eb1:      	negl	%eax
    4eb3:      	movw	%ax, 0x50(%rsp)
    4eb8:      	movw	$0x8, 0x52(%rsp)
    4ebf:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4ec9:      	movq	%rax, 0x54(%rsp)
    4ece:      	movq	(%rip), %rdi            # 0x4ed5 <generic_kprobe_process_filter+0xe75>
    4ed5:      	leaq	0x50(%rsp), %rsi
    4eda:      	movl	$0x1, %eax
    4edf:      	callq	*%rax
    4ee1:      	testq	%rax, %rax
    4ee4:      	je	0x5406 <generic_kprobe_process_filter+0x13a6>
    4eea:      	incl	(%rax)
    4eec:      	movl	0x6410(%r12), %eax
    4ef4:      	leal	-0x101(%rax), %ecx
    4efa:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4f00:      	ja	0x4bae <generic_kprobe_process_filter+0xb4e>
    4f06:      	movq	0xa8(%rsp), %rax
    4f0e:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4f14:      	leaq	0x5f10(%r12), %r14
    4f1c:      	orb	$0x10, 0x1(%r12)
    4f22:      	leaq	0x5ef8(%r12), %rsi
    4f2a:      	movq	(%rip), %rdi            # 0x4f31 <generic_kprobe_process_filter+0xed1>
    4f31:      	movl	$0x1, %eax
    4f36:      	callq	*%rax
    4f38:      	testq	%rax, %rax
    4f3b:      	je	0x6316 <generic_kprobe_process_filter+0x22b6>
    4f41:      	movq	0x5eb8(%r12), %rbx
    4f49:      	cmpq	$0x6, %rbx
    4f4d:      	jae	0x518a <generic_kprobe_process_filter+0x112a>
    4f53:      	movslq	(%rax), %rcx
    4f56:      	testq	%rcx, %rcx
    4f59:      	je	0x51af <generic_kprobe_process_filter+0x114f>
    4f5f:      	cmpq	%rcx, %rbx
    4f62:      	jae	0x518a <generic_kprobe_process_filter+0x112a>
    4f68:      	movq	%rax, 0x8(%rsp)
    4f6d:      	movq	%rcx, 0xb8(%rsp)
    4f75:      	movq	%rbp, 0xb0(%rsp)
    4f7d:      	movl	%ebx, 0x50(%rsp)
    4f81:      	movl	$0x0, 0x38(%rsp)
    4f89:      	movq	(%rip), %rdi            # 0x4f90 <generic_kprobe_process_filter+0xf30>
    4f90:      	leaq	0x50(%rsp), %rsi
    4f95:      	movl	$0x1, %eax
    4f9a:      	callq	*%rax
    4f9c:      	testq	%rax, %rax
    4f9f:      	movq	%r14, 0x28(%rsp)
    4fa4:      	je	0x51ce <generic_kprobe_process_filter+0x116e>
    4faa:      	movq	%rax, %r13
    4fad:      	movl	(%rax), %eax
    4faf:      	testl	%eax, %eax
    4fb1:      	je	0x51ce <generic_kprobe_process_filter+0x116e>
    4fb7:      	cmpl	$0x0, 0x68(%r14)
    4fbc:      	js	0x62bc <generic_kprobe_process_filter+0x225c>
    4fc2:      	cmpl	$0x1b, %eax
    4fc5:      	ja	0x62bc <generic_kprobe_process_filter+0x225c>
    4fcb:      	movl	$0x60, %ecx
    4fd0:      	btl	%eax, %ecx
    4fd3:      	jb	0x5618 <generic_kprobe_process_filter+0x15b8>
    4fd9:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4fde:      	btl	%eax, %ecx
    4fe1:      	jb	0x5588 <generic_kprobe_process_filter+0x1528>
    4fe7:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4fec:      	btl	%eax, %ecx
    4fef:      	jae	0x62bc <generic_kprobe_process_filter+0x225c>
    4ff5:      	movq	%r13, %rsi
    4ff8:      	addq	$0x4, %rsi
    4ffc:      	movq	(%rip), %rdi            # 0x5003 <generic_kprobe_process_filter+0xfa3>
    5003:      	movl	$0x1, %eax
    5008:      	callq	*%rax
    500a:      	testq	%rax, %rax
    500d:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5013:      	movq	%rax, %r15
    5016:      	movq	0x28(%rsp), %rax
    501b:      	movl	0x68(%rax), %eax
    501e:      	cmpl	$0x7f, %eax
    5021:      	movl	$0x7f, %r14d
    5027:      	cmovll	%eax, %r14d
    502b:      	movq	(%rip), %rdi            # 0x5032 <generic_kprobe_process_filter+0xfd2>
    5032:      	leaq	0x38(%rsp), %rsi
    5037:      	movl	$0x1, %eax
    503c:      	callq	*%rax
    503e:      	testq	%rax, %rax
    5041:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5047:      	movq	%rax, %rbp
    504a:      	leal	(,%r14,8), %eax
    5052:      	movl	%eax, (%rbp)
    5055:      	movq	0x28(%rsp), %rax
    505a:      	cmpl	$0x0, 0x6c(%rax)
    505e:      	jne	0x5151 <generic_kprobe_process_filter+0x10f1>
    5064:      	movq	%r15, 0xa8(%rsp)
    506c:      	movq	0x28(%rsp), %r15
    5071:      	movl	0x68(%r15), %ecx
    5075:      	movl	%ecx, %eax
    5077:      	subl	%r14d, %eax
    507a:      	movl	%r14d, %edx
    507d:      	andl	$0x7f, %edx
    5080:      	addl	%edx, %eax
    5082:      	addl	%ecx, %edx
    5084:      	movl	%r14d, %ecx
    5087:      	notl	%ecx
    5089:      	addl	%edx, %ecx
    508b:      	subl	%r14d, %edx
    508e:      	leal	-0x4(%rdx), %esi
    5091:      	leaq	0x1f3(%r15), %rdi
    5098:      	leal	-0x3(%rdx), %r8d
    509c:      	addl	$-0x2, %edx
    509f:      	movq	$-0x3, %r9
    50a6:      	leal	(%rcx,%r9), %r10d
    50aa:      	addl	$0x3, %r10d
    50ae:      	andl	$0x7f, %r10d
    50b2:      	movzbl	0x170(%r15,%r10), %r10d
    50bb:      	movb	%r10b, -0x3(%rdi)
    50bf:      	leaq	(%rax,%r9), %r10
    50c3:      	cmpq	$-0x2, %r10
    50c7:      	je	0x5141 <generic_kprobe_process_filter+0x10e1>
    50c9:      	leal	(%rdx,%r9), %r11d
    50cd:      	addl	$0x3, %r11d
    50d1:      	andl	$0x7f, %r11d
    50d5:      	movzbl	0x170(%r15,%r11), %r11d
    50de:      	movb	%r11b, -0x2(%rdi)
    50e2:      	cmpq	$-0x1, %r10
    50e6:      	je	0x5141 <generic_kprobe_process_filter+0x10e1>
    50e8:      	leal	(%r8,%r9), %r10d
    50ec:      	addl	$0x3, %r10d
    50f0:      	andl	$0x7f, %r10d
    50f4:      	movzbl	0x170(%r15,%r10), %r10d
    50fd:      	movb	%r10b, -0x1(%rdi)
    5101:      	movq	%rax, %r10
    5104:      	addq	%r9, %r10
    5107:      	je	0x5141 <generic_kprobe_process_filter+0x10e1>
    5109:      	cmpq	$-0x7f, %r9
    510d:      	je	0x5141 <generic_kprobe_process_filter+0x10e1>
    510f:      	leal	(%rsi,%r9), %r10d
    5113:      	addl	$0x3, %r10d
    5117:      	andl	$0x7f, %r10d
    511b:      	movzbl	0x170(%r15,%r10), %r10d
    5124:      	movb	%r10b, (%rdi)
    5127:      	addq	$0x4, %rdi
    512b:      	leaq	(%rax,%r9), %r10
    512f:      	addq	$-0x4, %r10
    5133:      	addq	$-0x4, %r9
    5137:      	cmpq	$-0x3, %r10
    513b:      	jne	0x50a6 <generic_kprobe_process_filter+0x1046>
    5141:      	movl	$0x1, 0x6c(%r15)
    5149:      	movq	0xa8(%rsp), %r15
    5151:      	cmpl	$0x7f, %r14d
    5155:      	ja	0x517d <generic_kprobe_process_filter+0x111d>
    5157:      	movslq	%r14d, %rsi
    515a:      	movq	%rbp, %rdi
    515d:      	addq	$0x4, %rdi
    5161:      	movq	0x28(%rsp), %rax
    5166:      	leaq	0x1f0(%rax), %rdx
    516d:      	movl	$0x4, %eax
    5172:      	callq	*%rax
    5174:      	testq	%rax, %rax
    5177:      	js	0x62bc <generic_kprobe_process_filter+0x225c>
    517d:      	movl	$0x1, %eax
    5182:      	movq	%r15, %rdi
    5185:      	jmp	0x5613 <generic_kprobe_process_filter+0x15b3>
    518a:      	movl	(%r14), %eax
    518d:      	movl	%eax, 0x10(%r12)
    5192:      	movq	0x8(%r14), %rax
    5196:      	movq	%rax, 0x18(%r12)
    519b:      	cmpb	$0x0, 0x5ec0(%r12)
    51a4:      	jne	0x6301 <generic_kprobe_process_filter+0x22a1>
    51aa:      	jmp	0x6316 <generic_kprobe_process_filter+0x22b6>
    51af:      	movb	$0x1, 0x5ec0(%r12)
    51b8:      	movl	(%r14), %eax
    51bb:      	movl	%eax, 0x10(%r12)
    51c0:      	movq	0x8(%r14), %rax
    51c4:      	movq	%rax, 0x18(%r12)
    51c9:      	jmp	0x6301 <generic_kprobe_process_filter+0x22a1>
    51ce:      	movq	0x8(%rsp), %r10
    51d3:      	movq	(%rip), %rax            # 0x51da <generic_kprobe_process_filter+0x117a>
    51da:      	cmpb	$0x0, (%rax)
    51dd:      	je	0x5480 <generic_kprobe_process_filter+0x1420>
    51e3:      	movq	(%rip), %rdi            # 0x51ea <generic_kprobe_process_filter+0x118a>
    51ea:      	movl	$0x1, %eax
    51ef:      	movq	0x28(%rsp), %rsi
    51f4:      	callq	*%rax
    51f6:      	movq	0x8(%rsp), %r10
    51fb:      	testq	%rax, %rax
    51fe:      	je	0x5480 <generic_kprobe_process_filter+0x1420>
    5204:      	movq	%rax, %rbp
    5207:      	leal	0x5(%rbx), %eax
    520a:      	movl	%eax, 0x50(%rsp)
    520e:      	movl	$0x0, 0x38(%rsp)
    5216:      	movq	(%rip), %rdi            # 0x521d <generic_kprobe_process_filter+0x11bd>
    521d:      	leaq	0x50(%rsp), %rsi
    5222:      	movl	$0x1, %eax
    5227:      	callq	*%rax
    5229:      	testq	%rax, %rax
    522c:      	je	0x547b <generic_kprobe_process_filter+0x141b>
    5232:      	movq	%rax, %r13
    5235:      	movl	(%rax), %eax
    5237:      	testl	%eax, %eax
    5239:      	je	0x547b <generic_kprobe_process_filter+0x141b>
    523f:      	cmpl	$0x0, (%rbp)
    5243:      	js	0x62bc <generic_kprobe_process_filter+0x225c>
    5249:      	cmpl	$0x1b, %eax
    524c:      	ja	0x62bc <generic_kprobe_process_filter+0x225c>
    5252:      	movl	$0x60, %ecx
    5257:      	btl	%eax, %ecx
    525a:      	jb	0x5736 <generic_kprobe_process_filter+0x16d6>
    5260:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    5265:      	btl	%eax, %ecx
    5268:      	jb	0x56a8 <generic_kprobe_process_filter+0x1648>
    526e:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5273:      	btl	%eax, %ecx
    5276:      	jae	0x62bc <generic_kprobe_process_filter+0x225c>
    527c:      	movq	%r13, %rsi
    527f:      	addq	$0x4, %rsi
    5283:      	movq	(%rip), %rdi            # 0x528a <generic_kprobe_process_filter+0x122a>
    528a:      	movl	$0x1, %eax
    528f:      	callq	*%rax
    5291:      	testq	%rax, %rax
    5294:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    529a:      	movq	%rax, %r15
    529d:      	movl	(%rbp), %eax
    52a0:      	cmpl	$0x7f, %eax
    52a3:      	movl	$0x7f, %r14d
    52a9:      	cmovll	%eax, %r14d
    52ad:      	movq	(%rip), %rdi            # 0x52b4 <generic_kprobe_process_filter+0x1254>
    52b4:      	leaq	0x38(%rsp), %rsi
    52b9:      	movl	$0x1, %eax
    52be:      	callq	*%rax
    52c0:      	testq	%rax, %rax
    52c3:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    52c9:      	movq	%rax, %rcx
    52cc:      	leal	(,%r14,8), %eax
    52d4:      	movl	%eax, (%rcx)
    52d6:      	cmpl	$0x0, 0x4(%rbp)
    52da:      	jne	0x53c6 <generic_kprobe_process_filter+0x1366>
    52e0:      	movq	%rcx, 0xa8(%rsp)
    52e8:      	movl	(%rbp), %ecx
    52eb:      	movl	%ecx, %eax
    52ed:      	subl	%r14d, %eax
    52f0:      	movl	%r14d, %edx
    52f3:      	andl	$0x7f, %edx
    52f6:      	addl	%edx, %eax
    52f8:      	addl	%ecx, %edx
    52fa:      	movl	%r14d, %ecx
    52fd:      	notl	%ecx
    52ff:      	addl	%edx, %ecx
    5301:      	subl	%r14d, %edx
    5304:      	leal	-0x4(%rdx), %esi
    5307:      	leaq	0x18b(%rbp), %rdi
    530e:      	leal	-0x3(%rdx), %r8d
    5312:      	addl	$-0x2, %edx
    5315:      	movq	$-0x3, %r9
    531c:      	leal	(%rcx,%r9), %r10d
    5320:      	addl	$0x3, %r10d
    5324:      	andl	$0x7f, %r10d
    5328:      	movzbl	0x108(%rbp,%r10), %r10d
    5331:      	movb	%r10b, -0x3(%rdi)
    5335:      	leaq	(%rax,%r9), %r10
    5339:      	cmpq	$-0x2, %r10
    533d:      	je	0x53b7 <generic_kprobe_process_filter+0x1357>
    533f:      	leal	(%rdx,%r9), %r11d
    5343:      	addl	$0x3, %r11d
    5347:      	andl	$0x7f, %r11d
    534b:      	movzbl	0x108(%rbp,%r11), %r11d
    5354:      	movb	%r11b, -0x2(%rdi)
    5358:      	cmpq	$-0x1, %r10
    535c:      	je	0x53b7 <generic_kprobe_process_filter+0x1357>
    535e:      	leal	(%r8,%r9), %r10d
    5362:      	addl	$0x3, %r10d
    5366:      	andl	$0x7f, %r10d
    536a:      	movzbl	0x108(%rbp,%r10), %r10d
    5373:      	movb	%r10b, -0x1(%rdi)
    5377:      	movq	%rax, %r10
    537a:      	addq	%r9, %r10
    537d:      	je	0x53b7 <generic_kprobe_process_filter+0x1357>
    537f:      	cmpq	$-0x7f, %r9
    5383:      	je	0x53b7 <generic_kprobe_process_filter+0x1357>
    5385:      	leal	(%rsi,%r9), %r10d
    5389:      	addl	$0x3, %r10d
    538d:      	andl	$0x7f, %r10d
    5391:      	movzbl	0x108(%rbp,%r10), %r10d
    539a:      	movb	%r10b, (%rdi)
    539d:      	addq	$0x4, %rdi
    53a1:      	leaq	(%rax,%r9), %r10
    53a5:      	addq	$-0x4, %r10
    53a9:      	addq	$-0x4, %r9
    53ad:      	cmpq	$-0x3, %r10
    53b1:      	jne	0x531c <generic_kprobe_process_filter+0x12bc>
    53b7:      	movl	$0x1, 0x4(%rbp)
    53be:      	movq	0xa8(%rsp), %rcx
    53c6:      	cmpl	$0x7f, %r14d
    53ca:      	ja	0x53f6 <generic_kprobe_process_filter+0x1396>
    53cc:      	movslq	%r14d, %rsi
    53cf:      	movq	%rcx, %rdi
    53d2:      	addq	$0x4, %rdi
    53d6:      	addq	$0x188, %rbp            # imm = 0x188
    53dd:      	movl	$0x4, %eax
    53e2:      	movq	%rbp, %rdx
    53e5:      	movq	%rcx, %r14
    53e8:      	callq	*%rax
    53ea:      	movq	%r14, %rcx
    53ed:      	testq	%rax, %rax
    53f0:      	js	0x62bc <generic_kprobe_process_filter+0x225c>
    53f6:      	movl	$0x1, %eax
    53fb:      	movq	%r15, %rdi
    53fe:      	movq	%rcx, %rsi
    5401:      	jmp	0x5796 <generic_kprobe_process_filter+0x1736>
    5406:      	movl	$0x1, 0x38(%rsp)
    540e:      	movq	(%rip), %rdi            # 0x5415 <generic_kprobe_process_filter+0x13b5>
    5415:      	xorl	%ecx, %ecx
    5417:      	leaq	0x50(%rsp), %rsi
    541c:      	leaq	0x38(%rsp), %rdx
    5421:      	movl	$0x2, %eax
    5426:      	xorl	%ecx, %ecx
    5428:      	callq	*%rax
    542a:      	movl	0x6410(%r12), %eax
    5432:      	leal	-0x101(%rax), %ecx
    5438:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    543e:      	jbe	0x4f06 <generic_kprobe_process_filter+0xea6>
    5444:      	jmp	0x4bae <generic_kprobe_process_filter+0xb4e>
    5449:      	movq	%rbp, 0xb8(%rsp)
    5451:      	movq	%r15, %r13
    5454:      	addq	$0xff6, %r13            # imm = 0xFF6
    545b:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5465:      	movq	%rax, 0xff6(%r15)
    546c:      	movw	$0x2964, 0xffe(%r15)    # imm = 0x2964
    5476:      	jmp	0x48eb <generic_kprobe_process_filter+0x88b>
    547b:      	movq	0x8(%rsp), %r10
    5480:      	movl	%ebx, %eax
    5482:      	leaq	0x4(,%rax,4), %rcx
    548a:      	movl	0x4(%r10,%rax,4), %eax
    548f:      	leal	(%rax,%rcx), %edx
    5492:      	andl	$0x3ff, %edx            # imm = 0x3FF
    5498:      	addl	%eax, %ecx
    549a:      	addl	$0x4, %ecx
    549d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    54a3:      	leaq	0x8(%rdx), %rbp
    54a7:      	cmpl	$0x5, (%rcx,%r10)
    54ac:      	jb	0x557e <generic_kprobe_process_filter+0x151e>
    54b2:      	movq	%rdx, 0xd8(%rsp)
    54ba:      	movl	(%rbp,%r10), %edi
    54bf:      	movl	0x4(%rbp,%r10), %r8d
    54c4:      	movl	0x8(%rbp,%r10), %edx
    54c9:      	movq	$0x0, 0x58(%rsp)
    54d2:      	movq	$0x0, 0x50(%rsp)
    54db:      	cmpl	$0x4, %edx
    54de:      	movl	$0x4, %ecx
    54e3:      	cmovbl	%edx, %ecx
    54e6:      	cmpl	$0x6, %edi
    54e9:      	jne	0x54ff <generic_kprobe_process_filter+0x149f>
    54eb:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    54f5:      	movq	%rsi, 0x50(%rsp)
    54fa:      	movq	%rsi, 0x58(%rsp)
    54ff:      	testl	%edx, %edx
    5501:      	movq	0x28(%rsp), %r14
    5506:      	je	0x5c82 <generic_kprobe_process_filter+0x1c22>
    550c:      	leaq	0x24(%r14), %rdx
    5510:      	testb	$0x1, %r8b
    5514:      	movq	%rdx, 0xe0(%rsp)
    551c:      	movq	%rdx, %r9
    551f:      	cmoveq	%r14, %r9
    5523:      	leaq	0x10(%r14), %rdx
    5527:      	movq	%rdx, 0xd0(%rsp)
    552f:      	leal	(%rax,%rbx,4), %r11d
    5533:      	addl	$0x4, %r11d
    5537:      	andl	$0x3ff, %r11d           # imm = 0x3FF
    553e:      	addq	$0x14, %r11
    5542:      	decq	%rcx
    5545:      	cmpq	$0x3, %rcx
    5549:      	movl	$0x3, %eax
    554e:      	cmovbq	%rcx, %rax
    5552:      	movl	%eax, %eax
    5554:      	leaq	0x4(,%rax,4), %rax
    555c:      	movq	%rax, 0xa8(%rsp)
    5564:      	xorl	%ebx, %ebx
    5566:      	movl	%edi, 0x4(%rsp)
    556a:      	movq	%r8, 0x20(%rsp)
    556f:      	movq	%r9, 0x18(%rsp)
    5574:      	movq	%r11, 0x10(%rsp)
    5579:      	jmp	0x581c <generic_kprobe_process_filter+0x17bc>
    557e:      	movl	$0x1, %eax
    5583:      	jmp	0x5cc3 <generic_kprobe_process_filter+0x1c63>
    5588:      	movq	%r13, %rsi
    558b:      	addq	$0x4, %rsi
    558f:      	movq	(%rip), %rdi            # 0x5596 <generic_kprobe_process_filter+0x1536>
    5596:      	movl	$0x1, %eax
    559b:      	callq	*%rax
    559d:      	testq	%rax, %rax
    55a0:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    55a6:      	movq	%rax, %r14
    55a9:      	movq	(%rip), %rdi            # 0x55b0 <generic_kprobe_process_filter+0x1550>
    55b0:      	leaq	0x38(%rsp), %rsi
    55b5:      	movl	$0x1, %eax
    55ba:      	callq	*%rax
    55bc:      	testq	%rax, %rax
    55bf:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    55c5:      	movq	%rax, %rbp
    55c8:      	movl	$0x104, %edx            # imm = 0x104
    55cd:      	movq	%rax, %rdi
    55d0:      	xorl	%esi, %esi
    55d2:      	callq	0x55d7 <generic_kprobe_process_filter+0x1577>
    55d7:      	movq	0x28(%rsp), %rsi
    55dc:      	movl	0x68(%rsi), %eax
    55df:      	leal	(,%rax,8), %ecx
    55e6:      	movl	%ecx, (%rbp)
    55e9:      	movq	%rbp, %rdi
    55ec:      	addq	$0x4, %rdi
    55f0:      	movzbl	%al, %ecx
    55f3:      	leaq	0x70(%rsi), %rdx
    55f7:      	movl	$0x4, %eax
    55fc:      	movzbl	0x68(%rsi), %esi
    5600:      	callq	*%rax
    5602:      	testq	%rax, %rax
    5605:      	js	0x62bc <generic_kprobe_process_filter+0x225c>
    560b:      	movl	$0x1, %eax
    5610:      	movq	%r14, %rdi
    5613:      	movq	%rbp, %rsi
    5616:      	jmp	0x5671 <generic_kprobe_process_filter+0x1611>
    5618:      	movl	0x8(%r13), %eax
    561c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5621:      	cmpq	%rcx, %rax
    5624:      	movq	0x28(%rsp), %rcx
    5629:      	je	0x5644 <generic_kprobe_process_filter+0x15e4>
    562b:      	movq	0x370(%rcx), %rcx
    5632:      	btq	%rax, %rcx
    5636:      	jae	0x5644 <generic_kprobe_process_filter+0x15e4>
    5638:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5642:      	jmp	0x5673 <generic_kprobe_process_filter+0x1613>
    5644:      	movq	(%rip), %rdi            # 0x564b <generic_kprobe_process_filter+0x15eb>
    564b:      	leaq	0x50(%rsp), %rsi
    5650:      	movl	$0x1, %eax
    5655:      	callq	*%rax
    5657:      	testq	%rax, %rax
    565a:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5660:      	movq	%rax, %rdi
    5663:      	movq	0x28(%rsp), %rax
    5668:      	leaq	0x70(%rax), %rsi
    566c:      	movl	$0x1, %eax
    5671:      	callq	*%rax
    5673:      	movl	(%r13), %ecx
    5677:      	cmpq	$0x25, %rcx
    567b:      	movq	0x8(%rsp), %r10
    5680:      	ja	0x575d <generic_kprobe_process_filter+0x16fd>
    5686:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5690:      	btq	%rcx, %rdx
    5694:      	jae	0x575d <generic_kprobe_process_filter+0x16fd>
    569a:      	testq	%rax, %rax
    569d:      	jne	0x62bc <generic_kprobe_process_filter+0x225c>
    56a3:      	jmp	0x51d3 <generic_kprobe_process_filter+0x1173>
    56a8:      	movq	%r13, %rsi
    56ab:      	addq	$0x4, %rsi
    56af:      	movq	(%rip), %rdi            # 0x56b6 <generic_kprobe_process_filter+0x1656>
    56b6:      	movl	$0x1, %eax
    56bb:      	callq	*%rax
    56bd:      	testq	%rax, %rax
    56c0:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    56c6:      	movq	%rax, %r14
    56c9:      	movq	(%rip), %rdi            # 0x56d0 <generic_kprobe_process_filter+0x1670>
    56d0:      	leaq	0x38(%rsp), %rsi
    56d5:      	movl	$0x1, %eax
    56da:      	callq	*%rax
    56dc:      	testq	%rax, %rax
    56df:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    56e5:      	movq	%rax, %r15
    56e8:      	movl	$0x104, %edx            # imm = 0x104
    56ed:      	movq	%rax, %rdi
    56f0:      	xorl	%esi, %esi
    56f2:      	callq	0x56f7 <generic_kprobe_process_filter+0x1697>
    56f7:      	movl	(%rbp), %eax
    56fa:      	leal	(,%rax,8), %ecx
    5701:      	movl	%ecx, (%r15)
    5704:      	movq	%r15, %rdi
    5707:      	addq	$0x4, %rdi
    570b:      	movzbl	%al, %ecx
    570e:      	movq	%rbp, %rdx
    5711:      	addq	$0x8, %rdx
    5715:      	movl	$0x4, %eax
    571a:      	movzbl	(%rbp), %esi
    571e:      	callq	*%rax
    5720:      	testq	%rax, %rax
    5723:      	js	0x62bc <generic_kprobe_process_filter+0x225c>
    5729:      	movl	$0x1, %eax
    572e:      	movq	%r14, %rdi
    5731:      	movq	%r15, %rsi
    5734:      	jmp	0x5796 <generic_kprobe_process_filter+0x1736>
    5736:      	movl	0x8(%r13), %eax
    573a:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    573f:      	cmpq	%rcx, %rax
    5742:      	je	0x576b <generic_kprobe_process_filter+0x170b>
    5744:      	movq	0x308(%rbp), %rcx
    574b:      	btq	%rax, %rcx
    574f:      	jae	0x576b <generic_kprobe_process_filter+0x170b>
    5751:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    575b:      	jmp	0x5798 <generic_kprobe_process_filter+0x1738>
    575d:      	testq	%rax, %rax
    5760:      	jne	0x51d3 <generic_kprobe_process_filter+0x1173>
    5766:      	jmp	0x62bc <generic_kprobe_process_filter+0x225c>
    576b:      	movq	(%rip), %rdi            # 0x5772 <generic_kprobe_process_filter+0x1712>
    5772:      	leaq	0x50(%rsp), %rsi
    5777:      	movl	$0x1, %eax
    577c:      	callq	*%rax
    577e:      	testq	%rax, %rax
    5781:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5787:      	movq	%rax, %rdi
    578a:      	addq	$0x8, %rbp
    578e:      	movl	$0x1, %eax
    5793:      	movq	%rbp, %rsi
    5796:      	callq	*%rax
    5798:      	movl	(%r13), %ecx
    579c:      	cmpq	$0x25, %rcx
    57a0:      	movq	0x8(%rsp), %r10
    57a5:      	ja	0x57c5 <generic_kprobe_process_filter+0x1765>
    57a7:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    57b1:      	btq	%rcx, %rdx
    57b5:      	jae	0x57c5 <generic_kprobe_process_filter+0x1765>
    57b7:      	testq	%rax, %rax
    57ba:      	jne	0x62bc <generic_kprobe_process_filter+0x225c>
    57c0:      	jmp	0x5480 <generic_kprobe_process_filter+0x1420>
    57c5:      	testq	%rax, %rax
    57c8:      	jne	0x5480 <generic_kprobe_process_filter+0x1420>
    57ce:      	jmp	0x62bc <generic_kprobe_process_filter+0x225c>
    57d3:      	movq	0x30(%rsp), %r12
    57d8:      	movq	0x28(%rsp), %r14
    57dd:      	movq	0x8(%rsp), %r10
    57e2:      	movl	0x4(%rsp), %edi
    57e6:      	movq	0x20(%rsp), %r8
    57eb:      	movq	0x18(%rsp), %r9
    57f0:      	movq	0x10(%rsp), %r11
    57f5:      	cmpl	$0x6, %edi
    57f8:      	setne	%al
    57fb:      	xorb	$0x1, %r13b
    57ff:      	orb	%al, %r13b
    5802:      	movzbl	%r13b, %eax
    5806:      	movl	%eax, 0x50(%rsp,%rbx)
    580a:      	addq	$0x4, %rbx
    580e:      	cmpq	%rbx, 0xa8(%rsp)
    5816:      	je	0x5c82 <generic_kprobe_process_filter+0x1c22>
    581c:      	leaq	(%r11,%rbx), %rax
    5820:      	movl	(%r9), %ecx
    5823:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    5829:      	jbe	0x5a51 <generic_kprobe_process_filter+0x19f1>
    582f:      	xorl	%r15d, %r15d
    5832:      	testb	$0x2, %r8b
    5836:      	je	0x5a6e <generic_kprobe_process_filter+0x1a0e>
    583c:      	testb	$0x1, %r8b
    5840:      	jne	0x5a8e <generic_kprobe_process_filter+0x1a2e>
    5846:      	movl	(%r14), %eax
    5849:      	movb	$0x1, %r13b
    584c:      	cmpq	%rax, %r15
    584f:      	je	0x57f5 <generic_kprobe_process_filter+0x1795>
    5851:      	movl	0x10(%r14), %eax
    5855:      	cmpq	%rax, %r15
    5858:      	je	0x57f5 <generic_kprobe_process_filter+0x1795>
    585a:      	movl	$0x1, %eax
    585f:      	movq	0xd0(%rsp), %rsi
    5867:      	movq	(%rip), %rdi            # 0x586e <generic_kprobe_process_filter+0x180e>
    586e:      	callq	*%rax
    5870:      	testq	%rax, %rax
    5873:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5879:      	movq	%rax, %rsi
    587c:      	movl	(%rax), %eax
    587e:      	cmpq	%rax, %r15
    5881:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5887:      	movl	0x10(%rsi), %eax
    588a:      	cmpq	%rax, %r15
    588d:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5893:      	addq	$0x10, %rsi
    5897:      	movl	$0x1, %eax
    589c:      	movq	(%rip), %rdi            # 0x58a3 <generic_kprobe_process_filter+0x1843>
    58a3:      	callq	*%rax
    58a5:      	testq	%rax, %rax
    58a8:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    58ae:      	movq	%rax, %rsi
    58b1:      	movl	(%rax), %eax
    58b3:      	cmpq	%rax, %r15
    58b6:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    58bc:      	movl	0x10(%rsi), %eax
    58bf:      	cmpq	%rax, %r15
    58c2:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    58c8:      	addq	$0x10, %rsi
    58cc:      	movl	$0x1, %eax
    58d1:      	movq	(%rip), %rdi            # 0x58d8 <generic_kprobe_process_filter+0x1878>
    58d8:      	callq	*%rax
    58da:      	testq	%rax, %rax
    58dd:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    58e3:      	movq	%rax, %rsi
    58e6:      	movl	(%rax), %eax
    58e8:      	cmpq	%rax, %r15
    58eb:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    58f1:      	movl	0x10(%rsi), %eax
    58f4:      	cmpq	%rax, %r15
    58f7:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    58fd:      	addq	$0x10, %rsi
    5901:      	movl	$0x1, %eax
    5906:      	movq	(%rip), %rdi            # 0x590d <generic_kprobe_process_filter+0x18ad>
    590d:      	callq	*%rax
    590f:      	testq	%rax, %rax
    5912:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5918:      	movq	%rax, %rsi
    591b:      	movl	(%rax), %eax
    591d:      	cmpq	%rax, %r15
    5920:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5926:      	movl	0x10(%rsi), %eax
    5929:      	cmpq	%rax, %r15
    592c:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5932:      	addq	$0x10, %rsi
    5936:      	movl	$0x1, %eax
    593b:      	movq	(%rip), %rdi            # 0x5942 <generic_kprobe_process_filter+0x18e2>
    5942:      	callq	*%rax
    5944:      	testq	%rax, %rax
    5947:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    594d:      	movq	%rax, %rsi
    5950:      	movl	(%rax), %eax
    5952:      	cmpq	%rax, %r15
    5955:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    595b:      	movl	0x10(%rsi), %eax
    595e:      	cmpq	%rax, %r15
    5961:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5967:      	addq	$0x10, %rsi
    596b:      	movl	$0x1, %eax
    5970:      	movq	(%rip), %rdi            # 0x5977 <generic_kprobe_process_filter+0x1917>
    5977:      	callq	*%rax
    5979:      	testq	%rax, %rax
    597c:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5982:      	movq	%rax, %rsi
    5985:      	movl	(%rax), %eax
    5987:      	cmpq	%rax, %r15
    598a:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    5990:      	movl	0x10(%rsi), %eax
    5993:      	cmpq	%rax, %r15
    5996:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    599c:      	addq	$0x10, %rsi
    59a0:      	movl	$0x1, %eax
    59a5:      	movq	(%rip), %rdi            # 0x59ac <generic_kprobe_process_filter+0x194c>
    59ac:      	callq	*%rax
    59ae:      	testq	%rax, %rax
    59b1:      	movq	0x30(%rsp), %r12
    59b6:      	movq	0x28(%rsp), %r14
    59bb:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    59c1:      	movq	%rax, %rsi
    59c4:      	movl	(%rax), %eax
    59c6:      	cmpq	%rax, %r15
    59c9:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    59cf:      	movl	0x10(%rsi), %eax
    59d2:      	cmpq	%rax, %r15
    59d5:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    59db:      	addq	$0x10, %rsi
    59df:      	movl	$0x1, %eax
    59e4:      	movq	(%rip), %rdi            # 0x59eb <generic_kprobe_process_filter+0x198b>
    59eb:      	callq	*%rax
    59ed:      	testq	%rax, %rax
    59f0:      	movq	0x30(%rsp), %r12
    59f5:      	movq	0x28(%rsp), %r14
    59fa:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5a00:      	movq	%rax, %rsi
    5a03:      	movl	(%rax), %eax
    5a05:      	cmpq	%rax, %r15
    5a08:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    5a0e:      	movl	0x10(%rsi), %eax
    5a11:      	cmpq	%rax, %r15
    5a14:      	movq	0x30(%rsp), %r12
    5a19:      	movq	0x28(%rsp), %r14
    5a1e:      	movq	0x8(%rsp), %r10
    5a23:      	movl	0x4(%rsp), %edi
    5a27:      	movq	0x20(%rsp), %r8
    5a2c:      	movq	0x18(%rsp), %r9
    5a31:      	movq	0x10(%rsp), %r11
    5a36:      	je	0x57f5 <generic_kprobe_process_filter+0x1795>
    5a3c:      	addq	$0x10, %rsi
    5a40:      	movl	$0x1, %eax
    5a45:      	movq	(%rip), %rcx            # 0x5a4c <generic_kprobe_process_filter+0x19ec>
    5a4c:      	jmp	0x5c3e <generic_kprobe_process_filter+0x1bde>
    5a51:      	movl	$0x4, %esi
    5a56:      	xorl	%edx, %edx
    5a58:      	divq	%rsi
    5a5b:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5a60:      	movl	(%r10,%rax,4), %r15d
    5a64:      	testb	$0x2, %r8b
    5a68:      	jne	0x583c <generic_kprobe_process_filter+0x17dc>
    5a6e:      	cmpl	$0x5, %edi
    5a71:      	jne	0x5a7c <generic_kprobe_process_filter+0x1a1c>
    5a73:      	cmpq	%rcx, %r15
    5a76:      	jne	0x5c7a <generic_kprobe_process_filter+0x1c1a>
    5a7c:      	cmpq	%rcx, %r15
    5a7f:      	setne	%al
    5a82:      	cmpl	$0x6, %edi
    5a85:      	setne	%r13b
    5a89:      	jmp	0x57ff <generic_kprobe_process_filter+0x179f>
    5a8e:      	movq	0xe0(%rsp), %rax
    5a96:      	movl	(%rax), %eax
    5a98:      	testq	%rax, %rax
    5a9b:      	je	0x5c7a <generic_kprobe_process_filter+0x1c1a>
    5aa1:      	movb	$0x1, %r13b
    5aa4:      	testq	%r15, %r15
    5aa7:      	je	0x57f5 <generic_kprobe_process_filter+0x1795>
    5aad:      	cmpq	%rax, %r15
    5ab0:      	je	0x57f5 <generic_kprobe_process_filter+0x1795>
    5ab6:      	movl	$0x1, %eax
    5abb:      	movq	0xd0(%rsp), %rsi
    5ac3:      	movq	(%rip), %rdi            # 0x5aca <generic_kprobe_process_filter+0x1a6a>
    5aca:      	callq	*%rax
    5acc:      	testq	%rax, %rax
    5acf:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5ad5:      	movq	%rax, %rsi
    5ad8:      	movl	0x24(%rax), %eax
    5adb:      	cmpq	%rax, %r15
    5ade:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5ae4:      	addq	$0x10, %rsi
    5ae8:      	movl	$0x1, %eax
    5aed:      	movq	(%rip), %rdi            # 0x5af4 <generic_kprobe_process_filter+0x1a94>
    5af4:      	callq	*%rax
    5af6:      	testq	%rax, %rax
    5af9:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5aff:      	movq	%rax, %rsi
    5b02:      	movl	0x24(%rax), %eax
    5b05:      	cmpq	%rax, %r15
    5b08:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5b0e:      	addq	$0x10, %rsi
    5b12:      	movl	$0x1, %eax
    5b17:      	movq	(%rip), %rdi            # 0x5b1e <generic_kprobe_process_filter+0x1abe>
    5b1e:      	callq	*%rax
    5b20:      	testq	%rax, %rax
    5b23:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5b29:      	movq	%rax, %rsi
    5b2c:      	movl	0x24(%rax), %eax
    5b2f:      	cmpq	%rax, %r15
    5b32:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5b38:      	addq	$0x10, %rsi
    5b3c:      	movl	$0x1, %eax
    5b41:      	movq	(%rip), %rdi            # 0x5b48 <generic_kprobe_process_filter+0x1ae8>
    5b48:      	callq	*%rax
    5b4a:      	testq	%rax, %rax
    5b4d:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5b53:      	movq	%rax, %rsi
    5b56:      	movl	0x24(%rax), %eax
    5b59:      	cmpq	%rax, %r15
    5b5c:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5b62:      	addq	$0x10, %rsi
    5b66:      	movl	$0x1, %eax
    5b6b:      	movq	(%rip), %rdi            # 0x5b72 <generic_kprobe_process_filter+0x1b12>
    5b72:      	callq	*%rax
    5b74:      	testq	%rax, %rax
    5b77:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5b7d:      	movq	%rax, %rsi
    5b80:      	movl	0x24(%rax), %eax
    5b83:      	cmpq	%rax, %r15
    5b86:      	je	0x57dd <generic_kprobe_process_filter+0x177d>
    5b8c:      	addq	$0x10, %rsi
    5b90:      	movl	$0x1, %eax
    5b95:      	movq	(%rip), %rdi            # 0x5b9c <generic_kprobe_process_filter+0x1b3c>
    5b9c:      	callq	*%rax
    5b9e:      	testq	%rax, %rax
    5ba1:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5ba7:      	movq	%rax, %rsi
    5baa:      	movl	0x24(%rax), %eax
    5bad:      	cmpq	%rax, %r15
    5bb0:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    5bb6:      	addq	$0x10, %rsi
    5bba:      	movl	$0x1, %eax
    5bbf:      	movq	(%rip), %rdi            # 0x5bc6 <generic_kprobe_process_filter+0x1b66>
    5bc6:      	callq	*%rax
    5bc8:      	testq	%rax, %rax
    5bcb:      	movq	0x30(%rsp), %r12
    5bd0:      	movq	0x28(%rsp), %r14
    5bd5:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5bd7:      	movq	%rax, %rsi
    5bda:      	movl	0x24(%rax), %eax
    5bdd:      	cmpq	%rax, %r15
    5be0:      	je	0x57d3 <generic_kprobe_process_filter+0x1773>
    5be6:      	addq	$0x10, %rsi
    5bea:      	movl	$0x1, %eax
    5bef:      	movq	(%rip), %rdi            # 0x5bf6 <generic_kprobe_process_filter+0x1b96>
    5bf6:      	callq	*%rax
    5bf8:      	testq	%rax, %rax
    5bfb:      	movq	0x30(%rsp), %r12
    5c00:      	movq	0x28(%rsp), %r14
    5c05:      	je	0x5c51 <generic_kprobe_process_filter+0x1bf1>
    5c07:      	movq	%rax, %rsi
    5c0a:      	movl	0x24(%rax), %eax
    5c0d:      	cmpq	%rax, %r15
    5c10:      	movq	0x8(%rsp), %r10
    5c15:      	movl	0x4(%rsp), %edi
    5c19:      	movq	0x20(%rsp), %r8
    5c1e:      	movq	0x18(%rsp), %r9
    5c23:      	movq	0x10(%rsp), %r11
    5c28:      	je	0x57f5 <generic_kprobe_process_filter+0x1795>
    5c2e:      	addq	$0x10, %rsi
    5c32:      	movl	$0x1, %eax
    5c37:      	movq	(%rip), %rcx            # 0x5c3e <generic_kprobe_process_filter+0x1bde>
    5c3e:      	movq	(%rip), %rdi            # 0x5c45 <generic_kprobe_process_filter+0x1be5>
    5c45:      	callq	*%rax
    5c47:      	movq	0x30(%rsp), %r12
    5c4c:      	movq	0x28(%rsp), %r14
    5c51:      	xorl	%r13d, %r13d
    5c54:      	movl	0x4(%rsp), %edi
    5c58:      	cmpl	$0x5, %edi
    5c5b:      	movq	0x8(%rsp), %r10
    5c60:      	movq	0x20(%rsp), %r8
    5c65:      	movq	0x18(%rsp), %r9
    5c6a:      	movq	0x10(%rsp), %r11
    5c6f:      	jne	0x57f5 <generic_kprobe_process_filter+0x1795>
    5c75:      	jmp	0x5802 <generic_kprobe_process_filter+0x17a2>
    5c7a:      	xorl	%r13d, %r13d
    5c7d:      	jmp	0x5802 <generic_kprobe_process_filter+0x17a2>
    5c82:      	movl	0x50(%rsp), %esi
    5c86:      	movl	0x54(%rsp), %ecx
    5c8a:      	movl	0x58(%rsp), %eax
    5c8e:      	movl	0x5c(%rsp), %edx
    5c92:      	cmpl	$0x6, %edi
    5c95:      	jne	0x5c9f <generic_kprobe_process_filter+0x1c3f>
    5c97:      	andl	%esi, %ecx
    5c99:      	andl	%edx, %eax
    5c9b:      	andl	%ecx, %eax
    5c9d:      	jmp	0x5ca5 <generic_kprobe_process_filter+0x1c45>
    5c9f:      	orl	%esi, %ecx
    5ca1:      	orl	%edx, %eax
    5ca3:      	orl	%ecx, %eax
    5ca5:      	testl	%eax, %eax
    5ca7:      	movq	0xd8(%rsp), %rdx
    5caf:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5cb5:      	addl	$0x14, %edx
    5cb8:      	movl	0x8(%r10,%rbp), %ecx
    5cbd:      	andl	$0x7, %ecx
    5cc0:      	leal	(%rdx,%rcx,4), %ebp
    5cc3:      	movl	%ebp, %ecx
    5cc5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5ccb:      	movl	(%rcx,%r10), %ecx
    5ccf:      	addl	$0x4, %ebp
    5cd2:      	addl	$-0x4, %ecx
    5cd5:      	xorl	%esi, %esi
    5cd7:      	movl	$0x4, %r8d
    5cdd:      	jmp	0x5cef <generic_kprobe_process_filter+0x1c8f>
    5cdf:      	nop
    5ce0:      	xorl	%ecx, %ecx
    5ce2:      	incq	%rsi
    5ce5:      	cmpq	$0xa, %rsi
    5ce9:      	je	0x5e78 <generic_kprobe_process_filter+0x1e18>
    5cef:      	testl	%ecx, %ecx
    5cf1:      	je	0x5ce0 <generic_kprobe_process_filter+0x1c80>
    5cf3:      	movl	%ebp, %r9d
    5cf6:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5cfd:      	movl	(%r9,%r10), %r11d
    5d01:      	movq	%r10, %rax
    5d04:      	movl	0x4(%r9,%r10), %r10d
    5d09:      	movl	0x8(%r9,%rax), %edx
    5d0e:      	movq	$0x0, 0x58(%rsp)
    5d17:      	movq	$0x0, 0x50(%rsp)
    5d20:      	cmpl	$0x4, %edx
    5d23:      	movl	$0x4, %eax
    5d28:      	cmovbl	%edx, %eax
    5d2b:      	cmpl	$0x6, %r10d
    5d2f:      	jne	0x5d45 <generic_kprobe_process_filter+0x1ce5>
    5d31:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5d3b:      	movq	%rdi, 0x50(%rsp)
    5d40:      	movq	%rdi, 0x58(%rsp)
    5d45:      	addl	$0xc, %ebp
    5d48:      	testl	%edx, %edx
    5d4a:      	je	0x5e20 <generic_kprobe_process_filter+0x1dc0>
    5d50:      	andl	$0xf, %r11d
    5d54:      	decq	%rax
    5d57:      	cmpq	$0x3, %rax
    5d5b:      	movl	$0x3, %edx
    5d60:      	cmovaeq	%rdx, %rax
    5d64:      	leaq	0x4(,%rax,4), %rbx
    5d6c:      	movl	%ebp, %r14d
    5d6f:      	cmpl	$0x9, %r11d
    5d73:      	jbe	0x5daa <generic_kprobe_process_filter+0x1d4a>
    5d75:      	xorl	%r11d, %r11d
    5d78:      	jmp	0x5d96 <generic_kprobe_process_filter+0x1d36>
    5d7a:      	nopw	(%rax,%rax)
    5d80:      	movl	$0x0, 0x50(%rsp,%r11)
    5d89:      	addq	$0x4, %r11
    5d8d:      	cmpq	%r11, %rbx
    5d90:      	je	0x5e20 <generic_kprobe_process_filter+0x1dc0>
    5d96:      	leaq	(%r14,%r11), %rax
    5d9a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5d9f:      	ja	0x5d80 <generic_kprobe_process_filter+0x1d20>
    5da1:      	movl	%eax, %eax
    5da3:      	xorl	%edx, %edx
    5da5:      	divq	%r8
    5da8:      	jmp	0x5d80 <generic_kprobe_process_filter+0x1d20>
    5daa:      	xorl	%r15d, %r15d
    5dad:      	jmp	0x5df1 <generic_kprobe_process_filter+0x1d91>
    5daf:      	nop
    5db0:      	cmpl	$0x5, %r10d
    5db4:      	setne	%dl
    5db7:      	movl	%r10d, %r13d
    5dba:      	xorl	$0x6, %r13d
    5dbe:      	movq	0x30(%rsp), %rax
    5dc3:      	movl	0x20(%rax,%r11,4), %edi
    5dc8:      	movl	%r12d, %eax
    5dcb:      	xorl	%edi, %eax
    5dcd:      	cmpl	%edi, %r12d
    5dd0:      	sete	%dil
    5dd4:      	orb	%dl, %dil
    5dd7:      	orl	%r13d, %eax
    5dda:      	setne	%al
    5ddd:      	andb	%dil, %al
    5de0:      	movzbl	%al, %eax
    5de3:      	movl	%eax, 0x50(%rsp,%r15)
    5de8:      	addq	$0x4, %r15
    5dec:      	cmpq	%r15, %rbx
    5def:      	je	0x5e20 <generic_kprobe_process_filter+0x1dc0>
    5df1:      	leaq	(%r14,%r15), %rdx
    5df5:      	xorl	%r12d, %r12d
    5df8:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    5dfe:      	ja	0x5db0 <generic_kprobe_process_filter+0x1d50>
    5e00:      	movl	%edx, %eax
    5e02:      	xorl	%edx, %edx
    5e04:      	divq	%r8
    5e07:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e0c:      	movq	0x8(%rsp), %rdx
    5e11:      	movl	(%rdx,%rax,4), %r12d
    5e15:      	jmp	0x5db0 <generic_kprobe_process_filter+0x1d50>
    5e17:      	nopw	(%rax,%rax)
    5e20:      	movl	0x50(%rsp), %ebx
    5e24:      	movl	0x54(%rsp), %edx
    5e28:      	movl	0x58(%rsp), %eax
    5e2c:      	movl	0x5c(%rsp), %r11d
    5e31:      	cmpl	$0x6, %r10d
    5e35:      	jne	0x5e40 <generic_kprobe_process_filter+0x1de0>
    5e37:      	andl	%ebx, %edx
    5e39:      	andl	%r11d, %eax
    5e3c:      	andl	%edx, %eax
    5e3e:      	jmp	0x5e47 <generic_kprobe_process_filter+0x1de7>
    5e40:      	orl	%ebx, %edx
    5e42:      	orl	%r11d, %eax
    5e45:      	orl	%edx, %eax
    5e47:      	movq	0x30(%rsp), %r12
    5e4c:      	movq	0x8(%rsp), %r10
    5e51:      	testl	%eax, %eax
    5e53:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5e59:      	movl	0x8(%r10,%r9), %edx
    5e5e:      	shll	$0x2, %edx
    5e61:      	subl	%edx, %ecx
    5e63:      	andl	$0x1c, %edx
    5e66:      	addl	%edx, %ebp
    5e68:      	addl	$-0xc, %ecx
    5e6b:      	incq	%rsi
    5e6e:      	cmpq	$0xa, %rsi
    5e72:      	jne	0x5cef <generic_kprobe_process_filter+0x1c8f>
    5e78:      	movl	%ebp, %ecx
    5e7a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5e80:      	leal	0x4(%rbp), %ebx
    5e83:      	cmpl	$0x4, (%rcx,%r10)
    5e88:      	je	0x5ee3 <generic_kprobe_process_filter+0x1e83>
    5e8a:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5e90:      	movl	(%rbx,%r10), %ecx
    5e94:      	movl	0x4(%rbx,%r10), %edx
    5e99:      	movl	0x8(%rbx,%r10), %edi
    5e9e:      	movq	0xc(%rbx,%r10), %rax
    5ea3:      	testl	%edi, %edi
    5ea5:      	je	0x5eb7 <generic_kprobe_process_filter+0x1e57>
    5ea7:      	xorl	%esi, %esi
    5ea9:      	cmpl	$0x2, %ecx
    5eac:      	ja	0x5eda <generic_kprobe_process_filter+0x1e7a>
    5eae:      	cmpl	%edi, 0x44(%r12)
    5eb3:      	jne	0x5ec0 <generic_kprobe_process_filter+0x1e60>
    5eb5:      	jmp	0x5eda <generic_kprobe_process_filter+0x1e7a>
    5eb7:      	cmpl	$0x2, %ecx
    5eba:      	jbe	0x5ec0 <generic_kprobe_process_filter+0x1e60>
    5ebc:      	xorl	%esi, %esi
    5ebe:      	jmp	0x5eda <generic_kprobe_process_filter+0x1e7a>
    5ec0:      	andq	0x48(%r12,%rcx,8), %rax
    5ec5:      	cmpl	$0x5, %edx
    5ec8:      	jne	0x5ed3 <generic_kprobe_process_filter+0x1e73>
    5eca:      	testq	%rax, %rax
    5ecd:      	setne	%sil
    5ed1:      	jmp	0x5eda <generic_kprobe_process_filter+0x1e7a>
    5ed3:      	testq	%rax, %rax
    5ed6:      	sete	%sil
    5eda:      	addl	$0x18, %ebp
    5edd:      	movzbl	%sil, %eax
    5ee1:      	movl	%ebp, %ebx
    5ee3:      	testl	%eax, %eax
    5ee5:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5eeb:      	movl	%ebx, %ecx
    5eed:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5ef3:      	leal	0x4(%rbx), %eax
    5ef6:      	cmpl	$0x4, (%rcx,%r10)
    5efb:      	je	0x61cf <generic_kprobe_process_filter+0x216f>
    5f01:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5f06:      	movl	(%rax,%r10), %r14d
    5f0a:      	movl	0x4(%rax,%r10), %ebp
    5f0f:      	movl	$0xe, %eax
    5f14:      	callq	*%rax
    5f16:      	shrq	$0x20, %rax
    5f1a:      	movl	%eax, 0x50(%rsp)
    5f1e:      	movq	(%rip), %rdi            # 0x5f25 <generic_kprobe_process_filter+0x1ec5>
    5f25:      	leaq	0x50(%rsp), %rsi
    5f2a:      	movl	$0x1, %eax
    5f2f:      	callq	*%rax
    5f31:      	movq	0x8(%rsp), %r10
    5f36:      	testq	%rax, %rax
    5f39:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    5f3f:      	cmpl	$0x5, %r14d
    5f43:      	je	0x5f72 <generic_kprobe_process_filter+0x1f12>
    5f45:      	cmpl	$0x6, %r14d
    5f49:      	jne	0x62bc <generic_kprobe_process_filter+0x225c>
    5f4f:      	movq	%r12, %rcx
    5f52:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5f59:      	testb	$0x1, %bpl
    5f5d:      	jne	0x5f9c <generic_kprobe_process_filter+0x1f3c>
    5f5f:      	movl	0x28(%rax), %edx
    5f62:      	testl	%edx, %edx
    5f64:      	je	0x5f95 <generic_kprobe_process_filter+0x1f35>
    5f66:      	cmpl	0x20(%r12), %edx
    5f6b:      	je	0x5f9c <generic_kprobe_process_filter+0x1f3c>
    5f6d:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    5f72:      	movq	%r12, %rcx
    5f75:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5f7c:      	testb	$0x1, %bpl
    5f80:      	je	0x5fbc <generic_kprobe_process_filter+0x1f5c>
    5f82:      	movl	0x28(%rax), %edx
    5f85:      	testl	%edx, %edx
    5f87:      	je	0x5fb5 <generic_kprobe_process_filter+0x1f55>
    5f89:      	cmpl	0x20(%r12), %edx
    5f8e:      	je	0x5fbc <generic_kprobe_process_filter+0x1f5c>
    5f90:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    5f95:      	movq	$0x1, (%rcx)
    5f9c:      	testb	$0x2, %bpl
    5fa0:      	jne	0x5fdc <generic_kprobe_process_filter+0x1f7c>
    5fa2:      	movl	0x2c(%rax), %edx
    5fa5:      	testl	%edx, %edx
    5fa7:      	je	0x5fd5 <generic_kprobe_process_filter+0x1f75>
    5fa9:      	cmpl	0x24(%r12), %edx
    5fae:      	je	0x5fdc <generic_kprobe_process_filter+0x1f7c>
    5fb0:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    5fb5:      	movq	$0x1, (%rcx)
    5fbc:      	testb	$0x2, %bpl
    5fc0:      	je	0x5ffc <generic_kprobe_process_filter+0x1f9c>
    5fc2:      	movl	0x2c(%rax), %edx
    5fc5:      	testl	%edx, %edx
    5fc7:      	je	0x5ff5 <generic_kprobe_process_filter+0x1f95>
    5fc9:      	cmpl	0x24(%r12), %edx
    5fce:      	je	0x5ffc <generic_kprobe_process_filter+0x1f9c>
    5fd0:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    5fd5:      	movq	$0x1, (%rcx)
    5fdc:      	testb	$0x4, %bpl
    5fe0:      	jne	0x601c <generic_kprobe_process_filter+0x1fbc>
    5fe2:      	movl	0x30(%rax), %edx
    5fe5:      	testl	%edx, %edx
    5fe7:      	je	0x6015 <generic_kprobe_process_filter+0x1fb5>
    5fe9:      	cmpl	0x28(%r12), %edx
    5fee:      	je	0x601c <generic_kprobe_process_filter+0x1fbc>
    5ff0:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    5ff5:      	movq	$0x1, (%rcx)
    5ffc:      	testb	$0x4, %bpl
    6000:      	je	0x603c <generic_kprobe_process_filter+0x1fdc>
    6002:      	movl	0x30(%rax), %edx
    6005:      	testl	%edx, %edx
    6007:      	je	0x6035 <generic_kprobe_process_filter+0x1fd5>
    6009:      	cmpl	0x28(%r12), %edx
    600e:      	je	0x603c <generic_kprobe_process_filter+0x1fdc>
    6010:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6015:      	movq	$0x1, (%rcx)
    601c:      	testb	$0x8, %bpl
    6020:      	jne	0x605c <generic_kprobe_process_filter+0x1ffc>
    6022:      	movl	0x34(%rax), %edx
    6025:      	testl	%edx, %edx
    6027:      	je	0x6055 <generic_kprobe_process_filter+0x1ff5>
    6029:      	cmpl	0x2c(%r12), %edx
    602e:      	je	0x605c <generic_kprobe_process_filter+0x1ffc>
    6030:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6035:      	movq	$0x1, (%rcx)
    603c:      	testb	$0x8, %bpl
    6040:      	je	0x607c <generic_kprobe_process_filter+0x201c>
    6042:      	movl	0x34(%rax), %edx
    6045:      	testl	%edx, %edx
    6047:      	je	0x6075 <generic_kprobe_process_filter+0x2015>
    6049:      	cmpl	0x2c(%r12), %edx
    604e:      	je	0x607c <generic_kprobe_process_filter+0x201c>
    6050:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6055:      	movq	$0x1, (%rcx)
    605c:      	testb	$0x10, %bpl
    6060:      	jne	0x609c <generic_kprobe_process_filter+0x203c>
    6062:      	movl	0x38(%rax), %edx
    6065:      	testl	%edx, %edx
    6067:      	je	0x6095 <generic_kprobe_process_filter+0x2035>
    6069:      	cmpl	0x30(%r12), %edx
    606e:      	je	0x609c <generic_kprobe_process_filter+0x203c>
    6070:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6075:      	movq	$0x1, (%rcx)
    607c:      	testb	$0x10, %bpl
    6080:      	je	0x60bc <generic_kprobe_process_filter+0x205c>
    6082:      	movl	0x38(%rax), %edx
    6085:      	testl	%edx, %edx
    6087:      	je	0x60b5 <generic_kprobe_process_filter+0x2055>
    6089:      	cmpl	0x30(%r12), %edx
    608e:      	je	0x60bc <generic_kprobe_process_filter+0x205c>
    6090:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6095:      	movq	$0x1, (%rcx)
    609c:      	testb	$0x20, %bpl
    60a0:      	jne	0x60dc <generic_kprobe_process_filter+0x207c>
    60a2:      	movl	0x3c(%rax), %edx
    60a5:      	testl	%edx, %edx
    60a7:      	je	0x60d5 <generic_kprobe_process_filter+0x2075>
    60a9:      	cmpl	0x34(%r12), %edx
    60ae:      	je	0x60dc <generic_kprobe_process_filter+0x207c>
    60b0:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    60b5:      	movq	$0x1, (%rcx)
    60bc:      	testb	$0x20, %bpl
    60c0:      	je	0x60fc <generic_kprobe_process_filter+0x209c>
    60c2:      	movl	0x3c(%rax), %edx
    60c5:      	testl	%edx, %edx
    60c7:      	je	0x60f5 <generic_kprobe_process_filter+0x2095>
    60c9:      	cmpl	0x34(%r12), %edx
    60ce:      	je	0x60fc <generic_kprobe_process_filter+0x209c>
    60d0:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    60d5:      	movq	$0x1, (%rcx)
    60dc:      	testb	$0x40, %bpl
    60e0:      	jne	0x611c <generic_kprobe_process_filter+0x20bc>
    60e2:      	movl	0x40(%rax), %edx
    60e5:      	testl	%edx, %edx
    60e7:      	je	0x6115 <generic_kprobe_process_filter+0x20b5>
    60e9:      	cmpl	0x38(%r12), %edx
    60ee:      	je	0x611c <generic_kprobe_process_filter+0x20bc>
    60f0:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    60f5:      	movq	$0x1, (%rcx)
    60fc:      	testb	$0x40, %bpl
    6100:      	je	0x613b <generic_kprobe_process_filter+0x20db>
    6102:      	movl	0x40(%rax), %edx
    6105:      	testl	%edx, %edx
    6107:      	je	0x6134 <generic_kprobe_process_filter+0x20d4>
    6109:      	cmpl	0x38(%r12), %edx
    610e:      	je	0x613b <generic_kprobe_process_filter+0x20db>
    6110:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6115:      	movq	$0x1, (%rcx)
    611c:      	testb	%bpl, %bpl
    611f:      	js	0x6157 <generic_kprobe_process_filter+0x20f7>
    6121:      	movl	0x44(%rax), %edx
    6124:      	testl	%edx, %edx
    6126:      	je	0x6150 <generic_kprobe_process_filter+0x20f0>
    6128:      	cmpl	0x3c(%r12), %edx
    612d:      	je	0x6157 <generic_kprobe_process_filter+0x20f7>
    612f:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6134:      	movq	$0x1, (%rcx)
    613b:      	testb	%bpl, %bpl
    613e:      	jns	0x6176 <generic_kprobe_process_filter+0x2116>
    6140:      	movl	0x44(%rax), %edx
    6143:      	testl	%edx, %edx
    6145:      	je	0x616f <generic_kprobe_process_filter+0x210f>
    6147:      	cmpl	0x3c(%r12), %edx
    614c:      	je	0x6176 <generic_kprobe_process_filter+0x2116>
    614e:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    6150:      	movq	$0x1, (%rcx)
    6157:      	testl	$0x100, %ebp            # imm = 0x100
    615d:      	jne	0x61a1 <generic_kprobe_process_filter+0x2141>
    615f:      	movl	0x48(%rax), %edx
    6162:      	testl	%edx, %edx
    6164:      	je	0x619a <generic_kprobe_process_filter+0x213a>
    6166:      	cmpl	0x40(%r12), %edx
    616b:      	je	0x61a1 <generic_kprobe_process_filter+0x2141>
    616d:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    616f:      	movq	$0x1, (%rcx)
    6176:      	testl	$0x100, %ebp            # imm = 0x100
    617c:      	je	0x62a2 <generic_kprobe_process_filter+0x2242>
    6182:      	movl	0x48(%rax), %edx
    6185:      	testl	%edx, %edx
    6187:      	je	0x629b <generic_kprobe_process_filter+0x223b>
    618d:      	cmpl	0x40(%r12), %edx
    6192:      	je	0x62a2 <generic_kprobe_process_filter+0x2242>
    6198:      	jmp	0x61c3 <generic_kprobe_process_filter+0x2163>
    619a:      	movq	$0x1, (%rcx)
    61a1:      	testl	$0x200, %ebp            # imm = 0x200
    61a7:      	jne	0x62bc <generic_kprobe_process_filter+0x225c>
    61ad:      	movl	0x4c(%rax), %eax
    61b0:      	testl	%eax, %eax
    61b2:      	je	0x62b5 <generic_kprobe_process_filter+0x2255>
    61b8:      	cmpl	0x44(%r12), %eax
    61bd:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    61c3:      	addl	$0xc, %ebx
    61c6:      	movq	$0x1, (%rcx)
    61cd:      	movl	%ebx, %eax
    61cf:      	movl	%eax, %ecx
    61d1:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    61d7:      	cmpl	$0x4, (%rcx,%r10)
    61dc:      	jne	0x6209 <generic_kprobe_process_filter+0x21a9>
    61de:      	movq	0x5eb8(%r12), %rax
    61e6:      	andl	$0x1f, %eax
    61e9:      	movb	$0x1, 0x5ec1(%r12,%rax)
    61f2:      	movb	$0x1, 0x5ee0(%r12)
    61fb:      	movb	$0x1, 0x5ec0(%r12)
    6204:      	jmp	0x62bc <generic_kprobe_process_filter+0x225c>
    6209:      	addl	$0x4, %eax
    620c:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6211:      	movl	(%rax,%r10), %r14d
    6215:      	movl	0x4(%rax,%r10), %ebx
    621a:      	movl	0x8(%rax,%r10), %ebp
    621f:      	movq	0xc(%rax,%r10), %r15
    6224:      	movl	$0xe, %eax
    6229:      	callq	*%rax
    622b:      	shrq	$0x20, %rax
    622f:      	movl	%eax, 0x50(%rsp)
    6233:      	movq	(%rip), %rdi            # 0x623a <generic_kprobe_process_filter+0x21da>
    623a:      	leaq	0x50(%rsp), %rsi
    623f:      	movl	$0x1, %eax
    6244:      	callq	*%rax
    6246:      	testq	%rax, %rax
    6249:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    624b:      	testl	%ebp, %ebp
    624d:      	je	0x625e <generic_kprobe_process_filter+0x21fe>
    624f:      	cmpl	$0x2, %r14d
    6253:      	ja	0x62bc <generic_kprobe_process_filter+0x225c>
    6255:      	cmpl	%ebp, 0x44(%r12)
    625a:      	jne	0x6264 <generic_kprobe_process_filter+0x2204>
    625c:      	jmp	0x62bc <generic_kprobe_process_filter+0x225c>
    625e:      	cmpl	$0x2, %r14d
    6262:      	ja	0x62bc <generic_kprobe_process_filter+0x225c>
    6264:      	movq	0x50(%rax,%r14,8), %rax
    6269:      	movq	0x48(%r12,%r14,8), %rcx
    626e:      	movq	%rcx, %rdx
    6271:      	xorq	%rax, %rdx
    6274:      	testq	%r15, %rdx
    6277:      	je	0x6280 <generic_kprobe_process_filter+0x2220>
    6279:      	cmpl	$0x5, %ebx
    627c:      	jne	0x62bc <generic_kprobe_process_filter+0x225c>
    627e:      	jmp	0x628a <generic_kprobe_process_filter+0x222a>
    6280:      	cmpq	%rcx, %rax
    6283:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    6285:      	cmpl	$0x6, %ebx
    6288:      	jne	0x62bc <generic_kprobe_process_filter+0x225c>
    628a:      	movq	$0x1, 0x5ef0(%r12)
    6296:      	jmp	0x61de <generic_kprobe_process_filter+0x217e>
    629b:      	movq	$0x1, (%rcx)
    62a2:      	testl	$0x200, %ebp            # imm = 0x200
    62a8:      	je	0x62bc <generic_kprobe_process_filter+0x225c>
    62aa:      	movl	0x4c(%rax), %eax
    62ad:      	testl	%eax, %eax
    62af:      	jne	0x61b8 <generic_kprobe_process_filter+0x2158>
    62b5:      	movq	$0x1, (%rcx)
    62bc:      	movq	0x5eb8(%r12), %rax
    62c4:      	incq	%rax
    62c7:      	movq	%rax, 0x5eb8(%r12)
    62cf:      	cmpq	0xb8(%rsp), %rax
    62d7:      	jbe	0x632a <generic_kprobe_process_filter+0x22ca>
    62d9:      	movq	0x28(%rsp), %rcx
    62de:      	movl	(%rcx), %eax
    62e0:      	movl	%eax, 0x10(%r12)
    62e5:      	movq	0x8(%rcx), %rax
    62e9:      	movq	%rax, 0x18(%r12)
    62ee:      	cmpb	$0x0, 0x5ec0(%r12)
    62f7:      	movq	0xb0(%rsp), %rbp
    62ff:      	je	0x6316 <generic_kprobe_process_filter+0x22b6>
    6301:      	movq	(%rip), %rsi            # 0x6308 <generic_kprobe_process_filter+0x22a8>
    6308:      	xorl	%ecx, %ecx
    630a:      	movl	$0xc, %eax
    630f:      	movq	%rbp, %rdi
    6312:      	xorl	%edx, %edx
    6314:      	callq	*%rax
    6316:      	xorl	%eax, %eax
    6318:      	addq	$0xf8, %rsp
    631f:      	popq	%rbx
    6320:      	popq	%r12
    6322:      	popq	%r13
    6324:      	popq	%r14
    6326:      	popq	%r15
    6328:      	popq	%rbp
    6329:      	retq
    632a:      	movq	(%rip), %rsi            # 0x6331 <generic_kprobe_process_filter+0x22d1>
    6331:      	movl	$0x2, %ecx
    6336:      	movl	$0xc, %eax
    633b:      	movq	0xb0(%rsp), %rdi
    6343:      	movl	$0x2, %edx
    6348:      	jmp	0x6314 <generic_kprobe_process_filter+0x22b4>
    634a:      	nopw	(%rax,%rax)

0000000000006350 <generic_kprobe_filter_arg>:
    6350:      	pushq	%rbp
    6351:      	pushq	%r15
    6353:      	pushq	%r14
    6355:      	pushq	%r13
    6357:      	pushq	%r12
    6359:      	pushq	%rbx
    635a:      	subq	$0xc8, %rsp
    6361:      	movq	%rdi, %r13
    6364:      	movl	$0x0, 0xb4(%rsp)
    636f:      	movq	(%rip), %rdi            # 0x6376 <generic_kprobe_filter_arg+0x26>
    6376:      	leaq	0xb4(%rsp), %rsi
    637e:      	movl	$0x1, %eax
    6383:      	callq	*%rax
    6385:      	testq	%rax, %rax
    6388:      	je	0x6523 <generic_kprobe_filter_arg+0x1d3>
    638e:      	movq	%rax, %r14
    6391:      	movl	0x5f00(%rax), %ebx
    6397:      	leaq	0x5ef8(%rax), %rsi
    639e:      	movq	(%rip), %rdi            # 0x63a5 <generic_kprobe_filter_arg+0x55>
    63a5:      	movl	$0x1, %eax
    63aa:      	callq	*%rax
    63ac:      	testq	%rax, %rax
    63af:      	je	0x6508 <generic_kprobe_filter_arg+0x1b8>
    63b5:      	cmpb	$0x0, 0x5ee0(%r14)
    63bd:      	je	0x6508 <generic_kprobe_filter_arg+0x1b8>
    63c3:      	movq	%rax, %r15
    63c6:      	movl	%ebx, %eax
    63c8:      	andl	$0x7, %eax
    63cb:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    63d4:      	je	0x645d <generic_kprobe_filter_arg+0x10d>
    63da:      	movl	%eax, %eax
    63dc:      	movl	0x4(%r15,%rax,4), %ecx
    63e1:      	leaq	(%rcx,%rax,4), %rdx
    63e5:      	addq	$0x4, %rdx
    63e9:      	leaq	(%rcx,%rax,4), %rax
    63ed:      	addq	$0x8, %rax
    63f1:      	andl	$0x3ff, %eax            # imm = 0x3FF
    63f6:      	movl	(%rax,%r15), %eax
    63fa:      	addq	%rdx, %rax
    63fd:      	addq	$0x4, %rax
    6401:      	movl	%eax, %ecx
    6403:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6409:      	movl	(%rcx,%r15), %ecx
    640d:      	addq	%rax, %rcx
    6410:      	movl	%ecx, %eax
    6412:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6417:      	movl	(%rax,%r15), %eax
    641b:      	addq	%rcx, %rax
    641e:      	movl	%eax, %ecx
    6420:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6426:      	movl	(%rcx,%r15), %ecx
    642a:      	addq	%rax, %rcx
    642d:      	movl	%ecx, %eax
    642f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6434:      	movl	(%rax,%r15), %r9d
    6438:      	addq	%rcx, %r9
    643b:      	movl	%r9d, %edi
    643e:      	andl	$0x3ff, %edi            # imm = 0x3FF
    6444:      	cmpl	$0x19, (%r15,%rdi)
    6449:      	jae	0x64a9 <generic_kprobe_filter_arg+0x159>
    644b:      	cmpq	$0x1, %rdi
    644f:      	je	0x6508 <generic_kprobe_filter_arg+0x1b8>
    6455:      	testl	%edi, %edi
    6457:      	jne	0x64e6 <generic_kprobe_filter_arg+0x196>
    645d:      	cmpl	$0x1, %ebx
    6460:      	jg	0x647e <generic_kprobe_filter_arg+0x12e>
    6462:      	cmpl	$-0x1, %ebx
    6465:      	je	0x6537 <generic_kprobe_filter_arg+0x1e7>
    646b:      	testl	%ebx, %ebx
    646d:      	je	0x6543 <generic_kprobe_filter_arg+0x1f3>
    6473:      	cmpl	$0x1, %ebx
    6476:      	je	0x6552 <generic_kprobe_filter_arg+0x202>
    647c:      	jmp	0x6499 <generic_kprobe_filter_arg+0x149>
    647e:      	cmpl	$0x2, %ebx
    6481:      	je	0x6561 <generic_kprobe_filter_arg+0x211>
    6487:      	cmpl	$0x3, %ebx
    648a:      	je	0x6570 <generic_kprobe_filter_arg+0x220>
    6490:      	cmpl	$0x4, %ebx
    6493:      	je	0x657f <generic_kprobe_filter_arg+0x22f>
    6499:      	cmpl	$0x4, %ebx
    649c:      	jg	0x65b0 <generic_kprobe_filter_arg+0x260>
    64a2:      	incl	%ebx
    64a4:      	jmp	0x658e <generic_kprobe_filter_arg+0x23e>
    64a9:      	leaq	(%r15,%rdi), %rax
    64ad:      	movq	%rax, 0xc0(%rsp)
    64b5:      	xorl	%r11d, %r11d
    64b8:      	leaq	0x80(%rsp), %rax
    64c0:      	movq	%rax, 0x38(%rsp)
    64c5:      	movq	%rbx, 0xb8(%rsp)
    64cd:      	movq	%rdi, 0x10(%rsp)
    64d2:      	movq	%r9, 0x18(%rsp)
    64d7:      	movq	%r15, 0x68(%rsp)
    64dc:      	movq	%r13, 0x78(%rsp)
    64e1:      	jmp	0x6625 <generic_kprobe_filter_arg+0x2d5>
    64e6:      	movl	%edi, 0x5f04(%r14)
    64ed:      	movq	(%rip), %rsi            # 0x64f4 <generic_kprobe_filter_arg+0x1a4>
    64f4:      	movl	$0x4, %ecx
    64f9:      	movl	$0xc, %eax
    64fe:      	movq	%r13, %rdi
    6501:      	movl	$0x4, %edx
    6506:      	callq	*%rax
    6508:      	movq	(%rip), %rsi            # 0x650f <generic_kprobe_filter_arg+0x1bf>
    650f:      	movl	$0x5, %ecx
    6514:      	movl	$0xc, %eax
    6519:      	movq	%r13, %rdi
    651c:      	movl	$0x5, %edx
    6521:      	callq	*%rax
    6523:      	xorl	%eax, %eax
    6525:      	addq	$0xc8, %rsp
    652c:      	popq	%rbx
    652d:      	popq	%r12
    652f:      	popq	%r13
    6531:      	popq	%r14
    6533:      	popq	%r15
    6535:      	popq	%rbp
    6536:      	retq
    6537:      	xorl	%ebx, %ebx
    6539:      	cmpb	$0x0, 0x5ec1(%r14)
    6541:      	jne	0x658e <generic_kprobe_filter_arg+0x23e>
    6543:      	movl	$0x1, %ebx
    6548:      	cmpb	$0x0, 0x5ec2(%r14)
    6550:      	jne	0x658e <generic_kprobe_filter_arg+0x23e>
    6552:      	movl	$0x2, %ebx
    6557:      	cmpb	$0x0, 0x5ec3(%r14)
    655f:      	jne	0x658e <generic_kprobe_filter_arg+0x23e>
    6561:      	movl	$0x3, %ebx
    6566:      	cmpb	$0x0, 0x5ec4(%r14)
    656e:      	jne	0x658e <generic_kprobe_filter_arg+0x23e>
    6570:      	movl	$0x4, %ebx
    6575:      	cmpb	$0x0, 0x5ec5(%r14)
    657d:      	jne	0x658e <generic_kprobe_filter_arg+0x23e>
    657f:      	movl	$0x5, %ebx
    6584:      	cmpb	$0x0, 0x5ec6(%r14)
    658c:      	je	0x65b0 <generic_kprobe_filter_arg+0x260>
    658e:      	movl	%ebx, 0x5f00(%r14)
    6595:      	movq	(%rip), %rsi            # 0x659c <generic_kprobe_filter_arg+0x24c>
    659c:      	movl	$0x3, %ecx
    65a1:      	movl	$0xc, %eax
    65a6:      	movq	%r13, %rdi
    65a9:      	movl	$0x3, %edx
    65ae:      	callq	*%rax
    65b0:      	movq	0x60(%r14), %rbx
    65b4:      	movl	$0xe, %eax
    65b9:      	callq	*%rax
    65bb:      	movq	%rbx, 0x40(%rsp)
    65c0:      	movq	%rax, 0x48(%rsp)
    65c5:      	movq	(%rip), %rdi            # 0x65cc <generic_kprobe_filter_arg+0x27c>
    65cc:      	leaq	0x40(%rsp), %rsi
    65d1:      	movl	$0x1, %eax
    65d6:      	callq	*%rax
    65d8:      	testq	%rax, %rax
    65db:      	je	0x6523 <generic_kprobe_filter_arg+0x1d3>
    65e1:      	movq	(%rip), %rdi            # 0x65e8 <generic_kprobe_filter_arg+0x298>
    65e8:      	leaq	0x40(%rsp), %rsi
    65ed:      	movl	$0x3, %eax
    65f2:      	callq	*%rax
    65f4:      	jmp	0x6523 <generic_kprobe_filter_arg+0x1d3>
    65f9:      	testq	%rax, %rax
    65fc:      	setne	%cl
    65ff:      	movzbl	%cl, %ebx
    6602:      	movq	0x78(%rsp), %r13
    6607:      	testq	%rbx, %rbx
    660a:      	movq	0xb8(%rsp), %rbx
    6612:      	je	0x645d <generic_kprobe_filter_arg+0x10d>
    6618:      	incq	%r11
    661b:      	cmpq	$0x5, %r11
    661f:      	je	0x644b <generic_kprobe_filter_arg+0xfb>
    6625:      	movq	0xc0(%rsp), %rax
    662d:      	movl	0x4(%rax,%r11,4), %r12d
    6632:      	testl	$0x3ff, %r12d           # imm = 0x3FF
    6639:      	je	0x644b <generic_kprobe_filter_arg+0xfb>
    663f:      	addl	%r9d, %r12d
    6642:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    6649:      	movl	0x4(%r15,%r12), %eax
    664e:      	cmpl	$0x23, %eax
    6651:      	je	0x645d <generic_kprobe_filter_arg+0x10d>
    6657:      	addq	%r15, %r12
    665a:      	movl	(%r12), %ecx
    665e:      	cmpq	$0x4, %rcx
    6662:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    6668:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6671:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    6677:      	movq	0x5e78(%r14,%rcx,8), %rcx
    667f:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6685:      	leaq	(%r14,%rcx), %rsi
    6689:      	addq	$0x90, %rsi
    6690:      	movl	0xc(%r12), %ecx
    6695:      	cmpl	$0x10, %ecx
    6698:      	jle	0x66f4 <generic_kprobe_filter_arg+0x3a4>
    669a:      	leal	-0x1c(%rcx), %edx
    669d:      	cmpl	$0x9, %edx
    66a0:      	jb	0x681e <generic_kprobe_filter_arg+0x4ce>
    66a6:      	movq	%rsi, %r8
    66a9:      	cmpl	$0x2a, %ecx
    66ac:      	ja	0x6b43 <generic_kprobe_filter_arg+0x7f3>
    66b2:      	movl	%ecx, %edx
    66b4:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
    66be:      	btq	%rdx, %rsi
    66c2:      	jb	0x671c <generic_kprobe_filter_arg+0x3cc>
    66c4:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
    66ce:      	btq	%rdx, %rsi
    66d2:      	jb	0x677b <generic_kprobe_filter_arg+0x42b>
    66d8:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
    66e2:      	btq	%rdx, %rsi
    66e6:      	jae	0x6b43 <generic_kprobe_filter_arg+0x7f3>
    66ec:      	movq	%r8, %rsi
    66ef:      	jmp	0x6b53 <generic_kprobe_filter_arg+0x803>
    66f4:      	cmpl	$0x6, %ecx
    66f7:      	jg	0x6757 <generic_kprobe_filter_arg+0x407>
    66f9:      	cmpl	$0x3, %ecx
    66fc:      	jle	0x67d3 <generic_kprobe_filter_arg+0x483>
    6702:      	cmpl	$0x4, %ecx
    6705:      	je	0x681e <generic_kprobe_filter_arg+0x4ce>
    670b:      	movq	%rsi, %r8
    670e:      	cmpl	$0x5, %ecx
    6711:      	je	0x677b <generic_kprobe_filter_arg+0x42b>
    6713:      	cmpl	$0x6, %ecx
    6716:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    671c:      	movq	%r8, %rsi
    671f:      	movl	(%r8), %ebp
    6722:      	addq	$0x4, %rsi
    6726:      	cmpl	$0x19, %eax
    6729:      	jg	0x69d7 <generic_kprobe_filter_arg+0x687>
    672f:      	leal	-0x3(%rax), %ecx
    6732:      	cmpl	$0x2, %ecx
    6735:      	jb	0x7330 <generic_kprobe_filter_arg+0xfe0>
    673b:      	cmpl	$0x8, %eax
    673e:      	je	0x7287 <generic_kprobe_filter_arg+0xf37>
    6744:      	movl	$0x0, %ebx
    6749:      	cmpl	$0x9, %eax
    674c:      	je	0x69f7 <generic_kprobe_filter_arg+0x6a7>
    6752:      	jmp	0x9317 <generic_kprobe_filter_arg+0x2fc7>
    6757:      	leal	-0xa(%rcx), %edx
    675a:      	cmpl	$0x4, %edx
    675d:      	jb	0x681e <generic_kprobe_filter_arg+0x4ce>
    6763:      	leal	-0xf(%rcx), %edx
    6766:      	cmpl	$0x2, %edx
    6769:      	jb	0x6b53 <generic_kprobe_filter_arg+0x803>
    676f:      	movq	%rsi, %r8
    6772:      	cmpl	$0x7, %ecx
    6775:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    677b:      	movq	$0x0, 0x60(%rsp)
    6784:      	movq	$0x0, 0x58(%rsp)
    678d:      	movq	$0x0, 0x50(%rsp)
    6796:      	movq	$0x0, 0x48(%rsp)
    679f:      	movq	$0x0, 0x40(%rsp)
    67a8:      	cmpl	$0x27, %ecx
    67ab:      	jg	0x694c <generic_kprobe_filter_arg+0x5fc>
    67b1:      	cmpl	$0x5, %ecx
    67b4:      	movq	%r8, %rsi
    67b7:      	je	0x70d4 <generic_kprobe_filter_arg+0xd84>
    67bd:      	movq	%rsi, %rdx
    67c0:      	movl	$0x0, %ebx
    67c5:      	cmpl	$0x7, %ecx
    67c8:      	je	0x70d6 <generic_kprobe_filter_arg+0xd86>
    67ce:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    67d3:      	cmpl	$0x1, %ecx
    67d6:      	je	0x681e <generic_kprobe_filter_arg+0x4ce>
    67d8:      	cmpl	$0x2, %ecx
    67db:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    67e1:      	movl	0x4(%rsi), %ebp
    67e4:      	addq	$0x8, %rsi
    67e8:      	cmpl	$0x19, %eax
    67eb:      	jg	0x73b4 <generic_kprobe_filter_arg+0x1064>
    67f1:      	leal	-0x3(%rax), %ecx
    67f4:      	cmpl	$0x2, %ecx
    67f7:      	jb	0x7c3c <generic_kprobe_filter_arg+0x18ec>
    67fd:      	movq	%rsi, 0x8(%rsp)
    6802:      	cmpl	$0x8, %eax
    6805:      	je	0x7b9c <generic_kprobe_filter_arg+0x184c>
    680b:      	movl	$0x0, %ebx
    6810:      	cmpl	$0x9, %eax
    6813:      	je	0x73d9 <generic_kprobe_filter_arg+0x1089>
    6819:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    681e:      	movq	%rsi, 0x8(%rsp)
    6823:      	cmpl	$0xb, %ecx
    6826:      	jle	0x68b7 <generic_kprobe_filter_arg+0x567>
    682c:      	cmpl	$0x24, %ecx
    682f:      	ja	0x68fe <generic_kprobe_filter_arg+0x5ae>
    6835:      	movl	%ecx, %edx
    6837:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    6841:      	btq	%rdx, %rsi
    6845:      	jb	0x68d2 <generic_kprobe_filter_arg+0x582>
    684b:      	movl	$0x60000000, %esi       # imm = 0x60000000
    6850:      	btq	%rdx, %rsi
    6854:      	jb	0x6ca9 <generic_kprobe_filter_arg+0x959>
    685a:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6864:      	btq	%rdx, %rsi
    6868:      	jae	0x68fe <generic_kprobe_filter_arg+0x5ae>
    686e:      	cmpl	$0x20, %eax
    6871:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    6877:      	movl	%eax, %ecx
    6879:      	movl	$0x101e, %edx           # imm = 0x101E
    687e:      	btq	%rcx, %rdx
    6882:      	jae	0x752f <generic_kprobe_filter_arg+0x11df>
    6888:      	movl	0x10(%r12), %ecx
    688d:      	cmpl	$0x2, %eax
    6890:      	jle	0x7a3c <generic_kprobe_filter_arg+0x16ec>
    6896:      	leal	-0x3(%rax), %edx
    6899:      	cmpl	$0x2, %edx
    689c:      	movq	0x8(%rsp), %rdx
    68a1:      	jae	0x806f <generic_kprobe_filter_arg+0x1d1f>
    68a7:      	movzbl	(%rdx), %edx
    68aa:      	cmpl	%edx, %ecx
    68ac:      	jne	0x838d <generic_kprobe_filter_arg+0x203d>
    68b2:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    68b7:      	leal	-0xa(%rcx), %edx
    68ba:      	cmpl	$0x2, %edx
    68bd:      	jb	0x6d43 <generic_kprobe_filter_arg+0x9f3>
    68c3:      	cmpl	$0x1, %ecx
    68c6:      	je	0x690a <generic_kprobe_filter_arg+0x5ba>
    68c8:      	cmpl	$0x4, %ecx
    68cb:      	je	0x690a <generic_kprobe_filter_arg+0x5ba>
    68cd:      	jmp	0x6618 <generic_kprobe_filter_arg+0x2c8>
    68d2:      	cmpl	$0x9, %eax
    68d5:      	jle	0x6cf2 <generic_kprobe_filter_arg+0x9a2>
    68db:      	cmpl	$0x1d, %eax
    68de:      	jg	0x7159 <generic_kprobe_filter_arg+0xe09>
    68e4:      	leal	-0xa(%rax), %edx
    68e7:      	cmpl	$0x2, %edx
    68ea:      	jb	0x6dd9 <generic_kprobe_filter_arg+0xa89>
    68f0:      	cmpl	$0xc, %eax
    68f3:      	je	0x6d59 <generic_kprobe_filter_arg+0xa09>
    68f9:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    68fe:      	leal	-0xc(%rcx), %edx
    6901:      	cmpl	$0x2, %edx
    6904:      	jae	0x6d3a <generic_kprobe_filter_arg+0x9ea>
    690a:      	cmpl	$0x20, %eax
    690d:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    6913:      	movl	%eax, %edx
    6915:      	movl	$0x101e, %esi           # imm = 0x101E
    691a:      	btq	%rdx, %rsi
    691e:      	jae	0x696e <generic_kprobe_filter_arg+0x61e>
    6920:      	movl	0x10(%r12), %edx
    6925:      	cmpl	$0x2, %eax
    6928:      	jle	0x6cff <generic_kprobe_filter_arg+0x9af>
    692e:      	leal	-0x3(%rax), %esi
    6931:      	cmpl	$0x2, %esi
    6934:      	jae	0x7514 <generic_kprobe_filter_arg+0x11c4>
    693a:      	movq	0x8(%rsp), %rsi
    693f:      	cmpl	%edx, (%rsi)
    6941:      	jne	0x8611 <generic_kprobe_filter_arg+0x22c1>
    6947:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    694c:      	cmpl	$0x28, %ecx
    694f:      	movq	%r8, %rsi
    6952:      	je	0x70ac <generic_kprobe_filter_arg+0xd5c>
    6958:      	movq	%rsi, %rdx
    695b:      	movl	$0x0, %ebx
    6960:      	cmpl	$0x29, %ecx
    6963:      	je	0x70d6 <generic_kprobe_filter_arg+0xd86>
    6969:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    696e:      	movl	$0xc00, %esi            # imm = 0xC00
    6973:      	btq	%rdx, %rsi
    6977:      	jb	0x7046 <generic_kprobe_filter_arg+0xcf6>
    697d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6987:      	btq	%rdx, %rsi
    698b:      	jae	0x645d <generic_kprobe_filter_arg+0x10d>
    6991:      	cmpl	$0x1f, %eax
    6994:      	jne	0x7681 <generic_kprobe_filter_arg+0x1331>
    699a:      	movl	0x10(%r12), %esi
    699f:      	movl	0x14(%r12), %edx
    69a4:      	cmpl	$0xc, %ecx
    69a7:      	ja	0x8434 <generic_kprobe_filter_arg+0x20e4>
    69ad:      	movl	$0x1402, %eax           # imm = 0x1402
    69b2:      	btl	%ecx, %eax
    69b5:      	jae	0x8434 <generic_kprobe_filter_arg+0x20e4>
    69bb:      	movq	0x8(%rsp), %rax
    69c0:      	movl	(%rax), %eax
    69c2:      	cmpl	%eax, %esi
    69c4:      	jg	0x8447 <generic_kprobe_filter_arg+0x20f7>
    69ca:      	cmpl	%edx, %eax
    69cc:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    69d2:      	jmp	0x8447 <generic_kprobe_filter_arg+0x20f7>
    69d7:      	cmpl	$0x20, %eax
    69da:      	jg	0x71a5 <generic_kprobe_filter_arg+0xe55>
    69e0:      	cmpl	$0x1a, %eax
    69e3:      	je	0x7287 <generic_kprobe_filter_arg+0xf37>
    69e9:      	movl	$0x0, %ebx
    69ee:      	cmpl	$0x1b, %eax
    69f1:      	jne	0x9317 <generic_kprobe_filter_arg+0x2fc7>
    69f7:      	movq	%rsi, 0x8(%rsp)
    69fc:      	movq	%r11, 0x20(%rsp)
    6a01:      	movl	0x10(%r12), %eax
    6a06:      	movl	%eax, 0x40(%rsp)
    6a0a:      	movl	$0x0, 0x80(%rsp)
    6a15:      	movl	$0x1, %eax
    6a1a:      	leaq	0x40(%rsp), %rsi
    6a1f:      	movq	(%rip), %rdi            # 0x6a26 <generic_kprobe_filter_arg+0x6d6>
    6a26:      	callq	*%rax
    6a28:      	testl	%ebp, %ebp
    6a2a:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    6a30:      	movl	$0x0, %ebx
    6a35:      	testq	%rax, %rax
    6a38:      	je	0x9308 <generic_kprobe_filter_arg+0x2fb8>
    6a3e:      	movq	%rax, 0x28(%rsp)
    6a43:      	movl	$0x1, %eax
    6a48:      	movq	0x38(%rsp), %rsi
    6a4d:      	movq	(%rip), %rdi            # 0x6a54 <generic_kprobe_filter_arg+0x704>
    6a54:      	callq	*%rax
    6a56:      	testq	%rax, %rax
    6a59:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    6a5f:      	movq	%rax, %rdi
    6a62:      	cmpl	$0x7f, %ebp
    6a65:      	movl	$0x7f, %eax
    6a6a:      	cmovbl	%ebp, %eax
    6a6d:      	shll	$0x3, %eax
    6a70:      	movl	%eax, (%rdi)
    6a72:      	movq	%rbp, %rax
    6a75:      	negq	%rax
    6a78:      	movl	$0x3, %ecx
    6a7d:      	subq	%rbp, %rcx
    6a80:      	leal	-0x4(%rbp), %edx
    6a83:      	movq	%rdi, 0x70(%rsp)
    6a88:      	addq	$0x7, %rdi
    6a8c:      	movl	$0x2, %r8d
    6a92:      	subq	%rbp, %r8
    6a95:      	leal	-0x3(%rbp), %r9d
    6a99:      	movl	$0x1, %r10d
    6a9f:      	subq	%rbp, %r10
    6aa2:      	leal	-0x2(%rbp), %r11d
    6aa6:      	decl	%ebp
    6aa8:      	xorl	%ebx, %ebx
    6aaa:      	movq	0x8(%rsp), %rsi
    6aaf:      	leal	(%rbx,%rbp), %r13d
    6ab3:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6aba:      	movzbl	(%rsi,%r13), %r13d
    6abf:      	movb	%r13b, -0x3(%rdi)
    6ac3:      	cmpq	%rbx, %r10
    6ac6:      	je	0x6b20 <generic_kprobe_filter_arg+0x7d0>
    6ac8:      	leal	(%r11,%rbx), %r13d
    6acc:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6ad3:      	movzbl	(%rsi,%r13), %r13d
    6ad8:      	movb	%r13b, -0x2(%rdi)
    6adc:      	cmpq	%rbx, %r8
    6adf:      	je	0x6b20 <generic_kprobe_filter_arg+0x7d0>
    6ae1:      	leal	(%r9,%rbx), %r13d
    6ae5:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6aec:      	movzbl	(%rsi,%r13), %r13d
    6af1:      	movb	%r13b, -0x1(%rdi)
    6af5:      	cmpq	%rbx, %rcx
    6af8:      	je	0x6b20 <generic_kprobe_filter_arg+0x7d0>
    6afa:      	cmpq	$-0x7c, %rbx
    6afe:      	je	0x6b20 <generic_kprobe_filter_arg+0x7d0>
    6b00:      	leal	(%rdx,%rbx), %r13d
    6b04:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6b0b:      	movzbl	(%rsi,%r13), %r13d
    6b10:      	movb	%r13b, (%rdi)
    6b13:      	addq	$-0x4, %rbx
    6b17:      	addq	$0x4, %rdi
    6b1b:      	cmpq	%rbx, %rax
    6b1e:      	jne	0x6aaf <generic_kprobe_filter_arg+0x75f>
    6b20:      	movl	$0x1, %eax
    6b25:      	movq	0x28(%rsp), %rdi
    6b2a:      	movq	0x70(%rsp), %rsi
    6b2f:      	callq	*%rax
    6b31:      	xorl	%ebx, %ebx
    6b33:      	testq	%rax, %rax
    6b36:      	setne	%bl
    6b39:      	movq	0x78(%rsp), %r13
    6b3e:      	jmp	0x9308 <generic_kprobe_filter_arg+0x2fb8>
    6b43:      	cmpl	$0x11, %ecx
    6b46:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    6b4c:      	movq	%r8, %rsi
    6b4f:      	addq	$0x4, %rsi
    6b53:      	movq	%rsi, 0x8(%rsp)
    6b58:      	movl	(%rsi), %ebp
    6b5a:      	movl	%eax, %ecx
    6b5c:      	andl	$-0x2, %ecx
    6b5f:      	cmpl	$0x24, %ecx
    6b62:      	je	0x6b6c <generic_kprobe_filter_arg+0x81c>
    6b64:      	testl	%ebp, %ebp
    6b66:      	je	0x645d <generic_kprobe_filter_arg+0x10d>
    6b6c:      	cmpl	$0x25, %eax
    6b6f:      	movq	0x8(%rsp), %rsi
    6b74:      	ja	0x6c74 <generic_kprobe_filter_arg+0x924>
    6b7a:      	movl	%eax, %ecx
    6b7c:      	movl	$0x4000100, %edx        # imm = 0x4000100
    6b81:      	btq	%rcx, %rdx
    6b85:      	jb	0x6f9e <generic_kprobe_filter_arg+0xc4e>
    6b8b:      	movl	$0x8000200, %edx        # imm = 0x8000200
    6b90:      	btq	%rcx, %rdx
    6b94:      	jb	0x6e53 <generic_kprobe_filter_arg+0xb03>
    6b9a:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    6ba4:      	btq	%rcx, %rdx
    6ba8:      	jae	0x6c74 <generic_kprobe_filter_arg+0x924>
    6bae:      	movw	$0x0, 0x40(%rsp)
    6bb5:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6bbb:      	ja	0x6c93 <generic_kprobe_filter_arg+0x943>
    6bc1:      	movq	%r11, 0x20(%rsp)
    6bc6:      	leaq	(%rsi,%rbp), %rcx
    6bca:      	addq	$0x8, %rcx
    6bce:      	movl	$0x4, %eax
    6bd3:      	leaq	0x40(%rsp), %rdi
    6bd8:      	movl	$0x2, %edx
    6bdd:      	movl	(%rsi), %ecx
    6bdf:      	leaq	(%rsi,%rcx), %rdx
    6be3:      	addq	$0x8, %rdx
    6be7:      	movl	$0x2, %esi
    6bec:      	callq	*%rax
    6bee:      	movl	0x10(%r12), %ecx
    6bf3:      	testl	%ecx, %ecx
    6bf5:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    6bfb:      	movzwl	0x40(%rsp), %eax
    6c00:      	andl	$0xf000, %eax           # imm = 0xF000
    6c05:      	movl	$0x1, %ebx
    6c0a:      	cmpl	%eax, %ecx
    6c0c:      	je	0x912b <generic_kprobe_filter_arg+0x2ddb>
    6c12:      	movl	0x8(%r12), %ecx
    6c17:      	cmpl	$0xd, %ecx
    6c1a:      	movq	0x10(%rsp), %rdi
    6c1f:      	movq	0x18(%rsp), %r9
    6c24:      	movq	0x20(%rsp), %r11
    6c29:      	jb	0x6c93 <generic_kprobe_filter_arg+0x943>
    6c2b:      	movl	0x14(%r12), %edx
    6c30:      	testl	%edx, %edx
    6c32:      	je	0x6c93 <generic_kprobe_filter_arg+0x943>
    6c34:      	cmpl	%eax, %edx
    6c36:      	je	0x913a <generic_kprobe_filter_arg+0x2dea>
    6c3c:      	cmpl	$0x11, %ecx
    6c3f:      	jb	0x6c93 <generic_kprobe_filter_arg+0x943>
    6c41:      	movl	0x18(%r12), %edx
    6c46:      	testl	%edx, %edx
    6c48:      	je	0x6c93 <generic_kprobe_filter_arg+0x943>
    6c4a:      	cmpl	%eax, %edx
    6c4c:      	je	0x913a <generic_kprobe_filter_arg+0x2dea>
    6c52:      	cmpl	$0x15, %ecx
    6c55:      	jb	0x9654 <generic_kprobe_filter_arg+0x3304>
    6c5b:      	movl	0x1c(%r12), %ecx
    6c60:      	testl	%ecx, %ecx
    6c62:      	je	0x9654 <generic_kprobe_filter_arg+0x3304>
    6c68:      	xorl	%ebx, %ebx
    6c6a:      	cmpl	%eax, %ecx
    6c6c:      	sete	%bl
    6c6f:      	jmp	0x9656 <generic_kprobe_filter_arg+0x3306>
    6c74:      	addl	$-0x3, %eax
    6c77:      	cmpl	$0x2, %eax
    6c7a:      	jae	0x6c93 <generic_kprobe_filter_arg+0x943>
    6c7c:      	movl	$0x0, 0x80(%rsp)
    6c87:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6c8d:      	jbe	0x762b <generic_kprobe_filter_arg+0x12db>
    6c93:      	xorl	%ebx, %ebx
    6c95:      	movl	0x4(%r12), %eax
    6c9a:      	cmpq	$0x25, %rax
    6c9e:      	jbe	0x9149 <generic_kprobe_filter_arg+0x2df9>
    6ca4:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    6ca9:      	cmpl	$0x20, %eax
    6cac:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    6cb2:      	movl	%eax, %ecx
    6cb4:      	movl	$0x101e, %edx           # imm = 0x101E
    6cb9:      	btq	%rcx, %rdx
    6cbd:      	jae	0x7565 <generic_kprobe_filter_arg+0x1215>
    6cc3:      	movl	0x10(%r12), %ecx
    6cc8:      	cmpl	$0x2, %eax
    6ccb:      	jle	0x7a63 <generic_kprobe_filter_arg+0x1713>
    6cd1:      	leal	-0x3(%rax), %edx
    6cd4:      	cmpl	$0x2, %edx
    6cd7:      	movq	0x8(%rsp), %rdx
    6cdc:      	jae	0x808d <generic_kprobe_filter_arg+0x1d3d>
    6ce2:      	movzwl	(%rdx), %edx
    6ce5:      	cmpl	%edx, %ecx
    6ce7:      	jne	0x83da <generic_kprobe_filter_arg+0x208a>
    6ced:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    6cf2:      	leal	-0x1(%rax), %edx
    6cf5:      	cmpl	$0x4, %edx
    6cf8:      	jb	0x6d59 <generic_kprobe_filter_arg+0xa09>
    6cfa:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    6cff:      	cmpl	$0x1, %eax
    6d02:      	je	0x77ef <generic_kprobe_filter_arg+0x149f>
    6d08:      	cmpl	$0x2, %eax
    6d0b:      	jne	0x8611 <generic_kprobe_filter_arg+0x22c1>
    6d11:      	cmpl	$0xc, %ecx
    6d14:      	ja	0x8604 <generic_kprobe_filter_arg+0x22b4>
    6d1a:      	movl	$0x1402, %esi           # imm = 0x1402
    6d1f:      	btl	%ecx, %esi
    6d22:      	jae	0x8604 <generic_kprobe_filter_arg+0x22b4>
    6d28:      	movq	0x8(%rsp), %rsi
    6d2d:      	cmpl	%edx, (%rsi)
    6d2f:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    6d35:      	jmp	0x8611 <generic_kprobe_filter_arg+0x22c1>
    6d3a:      	cmpl	$0x1c, %ecx
    6d3d:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    6d43:      	cmpl	$0x20, %eax
    6d46:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    6d4c:      	movl	%eax, %edx
    6d4e:      	movl	$0x101e, %esi           # imm = 0x101E
    6d53:      	btq	%rdx, %rsi
    6d57:      	jae	0x6d82 <generic_kprobe_filter_arg+0xa32>
    6d59:      	movq	0x10(%r12), %rdx
    6d5e:      	cmpl	$0x2, %eax
    6d61:      	jle	0x6da6 <generic_kprobe_filter_arg+0xa56>
    6d63:      	leal	-0x3(%rax), %esi
    6d66:      	cmpl	$0x2, %esi
    6d69:      	jae	0x7090 <generic_kprobe_filter_arg+0xd40>
    6d6f:      	movq	0x8(%rsp), %rsi
    6d74:      	cmpq	%rdx, (%rsi)
    6d77:      	jne	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    6d7d:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    6d82:      	movl	$0xc00, %esi            # imm = 0xC00
    6d87:      	btq	%rdx, %rsi
    6d8b:      	jb	0x6dd9 <generic_kprobe_filter_arg+0xa89>
    6d8d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6d97:      	btq	%rdx, %rsi
    6d9b:      	jb	0x7165 <generic_kprobe_filter_arg+0xe15>
    6da1:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    6da6:      	cmpl	$0x1, %eax
    6da9:      	je	0x760a <generic_kprobe_filter_arg+0x12ba>
    6daf:      	cmpl	$0x2, %eax
    6db2:      	jne	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    6db8:      	cmpl	$0xc, %ecx
    6dbb:      	je	0x6dc6 <generic_kprobe_filter_arg+0xa76>
    6dbd:      	cmpl	$0xa, %ecx
    6dc0:      	jne	0x7fd5 <generic_kprobe_filter_arg+0x1c85>
    6dc6:      	movq	0x8(%rsp), %rsi
    6dcb:      	cmpq	%rdx, (%rsi)
    6dce:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    6dd4:      	jmp	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    6dd9:      	movq	%r11, %rbp
    6ddc:      	movzbl	0x10(%r12), %eax
    6de2:      	movl	%eax, 0x80(%rsp)
    6de9:      	movl	$0x1, %eax
    6dee:      	movq	0x38(%rsp), %rsi
    6df3:      	movq	(%rip), %rdi            # 0x6dfa <generic_kprobe_filter_arg+0xaaa>
    6dfa:      	callq	*%rax
    6dfc:      	testq	%rax, %rax
    6dff:      	je	0x7b4b <generic_kprobe_filter_arg+0x17fb>
    6e05:      	movq	%rax, %rdi
    6e08:      	movq	0x8(%rsp), %rax
    6e0d:      	movq	(%rax), %rax
    6e10:      	movq	%rax, 0x40(%rsp)
    6e15:      	movl	$0x1, %eax
    6e1a:      	leaq	0x40(%rsp), %rsi
    6e1f:      	callq	*%rax
    6e21:      	movl	0x4(%r12), %ecx
    6e26:      	cmpl	$0xb, %ecx
    6e29:      	je	0x7b77 <generic_kprobe_filter_arg+0x1827>
    6e2f:      	cmpl	$0xa, %ecx
    6e32:      	movq	0x10(%rsp), %rdi
    6e37:      	movq	0x18(%rsp), %r9
    6e3c:      	movq	%rbp, %r11
    6e3f:      	jne	0x7b92 <generic_kprobe_filter_arg+0x1842>
    6e45:      	testq	%rax, %rax
    6e48:      	setne	%al
    6e4b:      	movzbl	%al, %ebx
    6e4e:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    6e53:      	movq	%r11, 0x20(%rsp)
    6e58:      	movl	0x10(%r12), %eax
    6e5d:      	movl	%eax, 0x40(%rsp)
    6e61:      	movl	$0x0, 0x80(%rsp)
    6e6c:      	movl	$0x1, %eax
    6e71:      	leaq	0x40(%rsp), %rsi
    6e76:      	movq	(%rip), %rdi            # 0x6e7d <generic_kprobe_filter_arg+0xb2d>
    6e7d:      	callq	*%rax
    6e7f:      	testl	%ebp, %ebp
    6e81:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    6e87:      	movl	$0x0, %ebx
    6e8c:      	testq	%rax, %rax
    6e8f:      	je	0x912b <generic_kprobe_filter_arg+0x2ddb>
    6e95:      	movq	%rax, 0x28(%rsp)
    6e9a:      	movl	$0x1, %eax
    6e9f:      	movq	0x38(%rsp), %rsi
    6ea4:      	movq	(%rip), %rdi            # 0x6eab <generic_kprobe_filter_arg+0xb5b>
    6eab:      	callq	*%rax
    6ead:      	testq	%rax, %rax
    6eb0:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    6eb6:      	movq	%rax, %rdi
    6eb9:      	cmpl	$0x7f, %ebp
    6ebc:      	movl	$0x7f, %eax
    6ec1:      	cmovbl	%ebp, %eax
    6ec4:      	shll	$0x3, %eax
    6ec7:      	movl	%eax, (%rdi)
    6ec9:      	movq	%rbp, %rax
    6ecc:      	negq	%rax
    6ecf:      	movl	$0x3, %ecx
    6ed4:      	subq	%rbp, %rcx
    6ed7:      	leal	-0x4(%rbp), %edx
    6eda:      	movq	%rdi, 0x70(%rsp)
    6edf:      	addq	$0x7, %rdi
    6ee3:      	movl	$0x2, %r8d
    6ee9:      	subq	%rbp, %r8
    6eec:      	leal	-0x3(%rbp), %r9d
    6ef0:      	movl	$0x1, %r10d
    6ef6:      	subq	%rbp, %r10
    6ef9:      	leal	-0x2(%rbp), %r11d
    6efd:      	decl	%ebp
    6eff:      	xorl	%ebx, %ebx
    6f01:      	movq	0x8(%rsp), %rsi
    6f06:      	leal	(%rbx,%rbp), %r13d
    6f0a:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6f11:      	movzbl	0x4(%rsi,%r13), %r13d
    6f17:      	movb	%r13b, -0x3(%rdi)
    6f1b:      	cmpq	%rbx, %r10
    6f1e:      	je	0x6f7b <generic_kprobe_filter_arg+0xc2b>
    6f20:      	leal	(%r11,%rbx), %r13d
    6f24:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6f2b:      	movzbl	0x4(%rsi,%r13), %r13d
    6f31:      	movb	%r13b, -0x2(%rdi)
    6f35:      	cmpq	%rbx, %r8
    6f38:      	je	0x6f7b <generic_kprobe_filter_arg+0xc2b>
    6f3a:      	leal	(%r9,%rbx), %r13d
    6f3e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6f45:      	movzbl	0x4(%rsi,%r13), %r13d
    6f4b:      	movb	%r13b, -0x1(%rdi)
    6f4f:      	cmpq	%rbx, %rcx
    6f52:      	je	0x6f7b <generic_kprobe_filter_arg+0xc2b>
    6f54:      	cmpq	$-0x7c, %rbx
    6f58:      	je	0x6f7b <generic_kprobe_filter_arg+0xc2b>
    6f5a:      	leal	(%rdx,%rbx), %r13d
    6f5e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6f65:      	movzbl	0x4(%rsi,%r13), %r13d
    6f6b:      	movb	%r13b, (%rdi)
    6f6e:      	addq	$-0x4, %rbx
    6f72:      	addq	$0x4, %rdi
    6f76:      	cmpq	%rbx, %rax
    6f79:      	jne	0x6f06 <generic_kprobe_filter_arg+0xbb6>
    6f7b:      	movl	$0x1, %eax
    6f80:      	movq	0x28(%rsp), %rdi
    6f85:      	movq	0x70(%rsp), %rsi
    6f8a:      	callq	*%rax
    6f8c:      	xorl	%ebx, %ebx
    6f8e:      	testq	%rax, %rax
    6f91:      	setne	%bl
    6f94:      	movq	0x78(%rsp), %r13
    6f99:      	jmp	0x912b <generic_kprobe_filter_arg+0x2ddb>
    6f9e:      	movq	%r11, 0x20(%rsp)
    6fa3:      	movl	0x10(%r12), %eax
    6fa8:      	movl	%eax, 0x40(%rsp)
    6fac:      	movl	$0x0, 0x80(%rsp)
    6fb7:      	movl	$0x1, %eax
    6fbc:      	leaq	0x40(%rsp), %rsi
    6fc1:      	movq	(%rip), %rdi            # 0x6fc8 <generic_kprobe_filter_arg+0xc78>
    6fc8:      	callq	*%rax
    6fca:      	testl	%ebp, %ebp
    6fcc:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    6fd2:      	movl	$0x0, %ebx
    6fd7:      	testq	%rax, %rax
    6fda:      	je	0x912b <generic_kprobe_filter_arg+0x2ddb>
    6fe0:      	movq	%rax, 0x28(%rsp)
    6fe5:      	movl	$0x1, %eax
    6fea:      	movq	0x38(%rsp), %rsi
    6fef:      	movq	(%rip), %rdi            # 0x6ff6 <generic_kprobe_filter_arg+0xca6>
    6ff6:      	callq	*%rax
    6ff8:      	testq	%rax, %rax
    6ffb:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    7001:      	movq	%rax, %rbx
    7004:      	movq	0x8(%rsp), %rdx
    7009:      	addq	$0x4, %rdx
    700d:      	cmpl	$0xff, %ebp
    7013:      	movl	$0xff, %eax
    7018:      	cmovael	%eax, %ebp
    701b:      	leal	(,%rbp,8), %eax
    7022:      	movl	%eax, (%rbx)
    7024:      	movq	%rbx, %rdi
    7027:      	addq	$0x4, %rdi
    702b:      	movl	$0x4, %eax
    7030:      	movl	%ebp, %esi
    7032:      	callq	*%rax
    7034:      	movl	$0x1, %eax
    7039:      	movq	0x28(%rsp), %rdi
    703e:      	movq	%rbx, %rsi
    7041:      	jmp	0x911d <generic_kprobe_filter_arg+0x2dcd>
    7046:      	movq	%r11, %rbp
    7049:      	movzbl	0x10(%r12), %eax
    704f:      	movl	%eax, 0x80(%rsp)
    7056:      	movl	$0x1, %eax
    705b:      	movq	0x38(%rsp), %rsi
    7060:      	movq	(%rip), %rdi            # 0x7067 <generic_kprobe_filter_arg+0xd17>
    7067:      	callq	*%rax
    7069:      	testq	%rax, %rax
    706c:      	je	0x7b4b <generic_kprobe_filter_arg+0x17fb>
    7072:      	movq	%rax, %rdi
    7075:      	movq	0x8(%rsp), %rax
    707a:      	movl	(%rax), %eax
    707c:      	movq	%rax, 0x40(%rsp)
    7081:      	movl	$0x1, %eax
    7086:      	leaq	0x40(%rsp), %rsi
    708b:      	jmp	0x7b14 <generic_kprobe_filter_arg+0x17c4>
    7090:      	cmpl	$0xc, %eax
    7093:      	jne	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    7099:      	movq	0x8(%rsp), %rsi
    709e:      	testq	%rdx, (%rsi)
    70a1:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    70a7:      	jmp	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    70ac:      	movzwl	(%rsi), %edx
    70af:      	movw	%dx, 0x66(%rsp)
    70b4:      	movzwl	0x2(%rsi), %edx
    70b8:      	movw	%dx, 0x60(%rsp)
    70bd:      	movq	0x8(%rsi), %rdx
    70c1:      	movq	%rdx, 0x40(%rsp)
    70c6:      	movq	0x10(%rsi), %rdx
    70ca:      	movq	%rdx, 0x48(%rsp)
    70cf:      	leaq	0x40(%rsp), %rsi
    70d4:      	xorl	%edx, %edx
    70d6:      	cmpl	$0x13, %eax
    70d9:      	jle	0x7102 <generic_kprobe_filter_arg+0xdb2>
    70db:      	cmpl	$0x17, %eax
    70de:      	jg	0x7134 <generic_kprobe_filter_arg+0xde4>
    70e0:      	leal	-0x14(%rax), %ecx
    70e3:      	cmpl	$0x2, %ecx
    70e6:      	jb	0x76d3 <generic_kprobe_filter_arg+0x1383>
    70ec:      	leal	-0x16(%rax), %ecx
    70ef:      	movl	$0x0, %ebx
    70f4:      	cmpl	$0x2, %ecx
    70f7:      	jb	0x76cc <generic_kprobe_filter_arg+0x137c>
    70fd:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7102:      	cmpl	$0xf, %eax
    7105:      	jle	0x738f <generic_kprobe_filter_arg+0x103f>
    710b:      	cmpl	$0x11, %eax
    710e:      	jg	0x76b9 <generic_kprobe_filter_arg+0x1369>
    7114:      	cmpl	$0x10, %eax
    7117:      	je	0x76cc <generic_kprobe_filter_arg+0x137c>
    711d:      	movl	$0x0, %ebx
    7122:      	cmpl	$0x11, %eax
    7125:      	jne	0x6602 <generic_kprobe_filter_arg+0x2b2>
    712b:      	movzwl	0x24(%rsi), %ebx
    712f:      	jmp	0x7f3e <generic_kprobe_filter_arg+0x1bee>
    7134:      	cmpl	$0x1b, %eax
    7137:      	jg	0x770c <generic_kprobe_filter_arg+0x13bc>
    713d:      	cmpl	$0x18, %eax
    7140:      	je	0x7746 <generic_kprobe_filter_arg+0x13f6>
    7146:      	movl	$0x0, %ebx
    714b:      	cmpl	$0x19, %eax
    714e:      	je	0x773c <generic_kprobe_filter_arg+0x13ec>
    7154:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7159:      	leal	-0x1f(%rax), %edx
    715c:      	cmpl	$0x2, %edx
    715f:      	jae	0x7c6e <generic_kprobe_filter_arg+0x191e>
    7165:      	cmpl	$0x1f, %eax
    7168:      	jne	0x735d <generic_kprobe_filter_arg+0x100d>
    716e:      	movq	0x10(%r12), %rsi
    7173:      	movq	0x18(%r12), %rdx
    7178:      	cmpl	$0xa, %ecx
    717b:      	je	0x7186 <generic_kprobe_filter_arg+0xe36>
    717d:      	cmpl	$0xc, %ecx
    7180:      	jne	0x7e91 <generic_kprobe_filter_arg+0x1b41>
    7186:      	movq	0x8(%rsp), %rax
    718b:      	movq	(%rax), %rax
    718e:      	cmpq	%rax, %rsi
    7191:      	jg	0x7ea7 <generic_kprobe_filter_arg+0x1b57>
    7197:      	cmpq	%rdx, %rax
    719a:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    71a0:      	jmp	0x7ea7 <generic_kprobe_filter_arg+0x1b57>
    71a5:      	cmpl	$0x21, %eax
    71a8:      	je	0x7818 <generic_kprobe_filter_arg+0x14c8>
    71ae:      	movl	$0x0, %ebx
    71b3:      	cmpl	$0x22, %eax
    71b6:      	jne	0x9317 <generic_kprobe_filter_arg+0x2fc7>
    71bc:      	movq	%rsi, 0x8(%rsp)
    71c1:      	xorl	%ebx, %ebx
    71c3:      	xorl	%r13d, %r13d
    71c6:      	movq	%r11, %r15
    71c9:      	movl	0x10(%r12,%rbx,4), %eax
    71ce:      	movl	%eax, 0x40(%rsp)
    71d2:      	movl	$0x1, %eax
    71d7:      	leaq	0x40(%rsp), %rsi
    71dc:      	movq	(%rip), %rdi            # 0x71e3 <generic_kprobe_filter_arg+0xe93>
    71e3:      	callq	*%rax
    71e5:      	testq	%rax, %rax
    71e8:      	je	0x86e3 <generic_kprobe_filter_arg+0x2393>
    71ee:      	testl	%ebp, %ebp
    71f0:      	movq	%r15, %r11
    71f3:      	movq	0x68(%rsp), %r15
    71f8:      	je	0x7264 <generic_kprobe_filter_arg+0xf14>
    71fa:      	movq	0x8(%rsp), %rdx
    71ff:      	xorl	%ecx, %ecx
    7201:      	jmp	0x720e <generic_kprobe_filter_arg+0xebe>
    7203:      	incq	%rcx
    7206:      	incq	%rdx
    7209:      	cmpq	%rbp, %rcx
    720c:      	je	0x7264 <generic_kprobe_filter_arg+0xf14>
    720e:      	xorl	%esi, %esi
    7210:      	leaq	(%rcx,%rsi), %rdi
    7214:      	cmpq	%rbp, %rdi
    7217:      	jae	0x7203 <generic_kprobe_filter_arg+0xeb3>
    7219:      	movsbl	(%rax,%rsi), %edi
    721d:      	testl	%edi, %edi
    721f:      	je	0x725c <generic_kprobe_filter_arg+0xf0c>
    7221:      	movsbl	(%rdx,%rsi), %r9d
    7226:      	leal	-0x41(%r9), %r10d
    722a:      	movl	%r9d, %r8d
    722d:      	orl	$0x20, %r8d
    7231:      	cmpl	$0x1a, %r10d
    7235:      	cmovael	%r9d, %r8d
    7239:      	leal	-0x41(%rdi), %r10d
    723d:      	movl	%edi, %r9d
    7240:      	orl	$0x20, %r9d
    7244:      	cmpl	$0x1a, %r10d
    7248:      	cmovael	%edi, %r9d
    724c:      	cmpq	$0x62, %rsi
    7250:      	ja	0x7203 <generic_kprobe_filter_arg+0xeb3>
    7252:      	incq	%rsi
    7255:      	cmpl	%r9d, %r8d
    7258:      	je	0x7210 <generic_kprobe_filter_arg+0xec0>
    725a:      	jmp	0x7203 <generic_kprobe_filter_arg+0xeb3>
    725c:      	testl	%ecx, %ecx
    725e:      	jns	0x89d8 <generic_kprobe_filter_arg+0x2688>
    7264:      	leal	0xc(%r13), %eax
    7268:      	cmpl	0x8(%r12), %eax
    726d:      	jae	0x7280 <generic_kprobe_filter_arg+0xf30>
    726f:      	addl	$0x4, %r13d
    7273:      	incq	%rbx
    7276:      	cmpq	$0x64, %rbx
    727a:      	jne	0x71c6 <generic_kprobe_filter_arg+0xe76>
    7280:      	xorl	%ebx, %ebx
    7282:      	jmp	0x89dd <generic_kprobe_filter_arg+0x268d>
    7287:      	movq	%rsi, 0x8(%rsp)
    728c:      	movq	%r11, 0x20(%rsp)
    7291:      	movl	0x10(%r12), %eax
    7296:      	movl	%eax, 0x40(%rsp)
    729a:      	movl	$0x0, 0x80(%rsp)
    72a5:      	movl	$0x1, %eax
    72aa:      	leaq	0x40(%rsp), %rsi
    72af:      	movq	(%rip), %rdi            # 0x72b6 <generic_kprobe_filter_arg+0xf66>
    72b6:      	callq	*%rax
    72b8:      	testl	%ebp, %ebp
    72ba:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    72c0:      	movl	$0x0, %ebx
    72c5:      	testq	%rax, %rax
    72c8:      	je	0x9308 <generic_kprobe_filter_arg+0x2fb8>
    72ce:      	movq	%rax, 0x28(%rsp)
    72d3:      	movl	$0x1, %eax
    72d8:      	movq	0x38(%rsp), %rsi
    72dd:      	movq	(%rip), %rdi            # 0x72e4 <generic_kprobe_filter_arg+0xf94>
    72e4:      	callq	*%rax
    72e6:      	testq	%rax, %rax
    72e9:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    72ef:      	cmpl	$0xff, %ebp
    72f5:      	movl	$0xff, %ecx
    72fa:      	cmovael	%ecx, %ebp
    72fd:      	leal	(,%rbp,8), %ecx
    7304:      	movl	%ecx, (%rax)
    7306:      	movq	%rax, %rdi
    7309:      	addq	$0x4, %rdi
    730d:      	movq	%rax, %rbx
    7310:      	movl	$0x4, %eax
    7315:      	movq	0x8(%rsp), %rdx
    731a:      	movl	%ebp, %esi
    731c:      	callq	*%rax
    731e:      	movl	$0x1, %eax
    7323:      	movq	0x28(%rsp), %rdi
    7328:      	movq	%rbx, %rsi
    732b:      	jmp	0x92fa <generic_kprobe_filter_arg+0x2faa>
    7330:      	movl	$0x0, 0x80(%rsp)
    733b:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    7341:      	jbe	0x78d2 <generic_kprobe_filter_arg+0x1582>
    7347:      	xorl	%ebx, %ebx
    7349:      	movl	0x4(%r12), %eax
    734e:      	cmpq	$0x25, %rax
    7352:      	jbe	0x9326 <generic_kprobe_filter_arg+0x2fd6>
    7358:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    735d:      	movq	0x10(%r12), %rsi
    7362:      	movq	0x18(%r12), %rax
    7367:      	cmpl	$0xc, %ecx
    736a:      	je	0x7375 <generic_kprobe_filter_arg+0x1025>
    736c:      	cmpl	$0xa, %ecx
    736f:      	jne	0x7ee9 <generic_kprobe_filter_arg+0x1b99>
    7375:      	movq	0x8(%rsp), %rdx
    737a:      	movq	(%rdx), %rdx
    737d:      	cmpq	%rdx, %rsi
    7380:      	setle	%sil
    7384:      	cmpq	%rax, %rdx
    7387:      	setle	%al
    738a:      	jmp	0x7efe <generic_kprobe_filter_arg+0x1bae>
    738f:      	cmpl	$0xd, %eax
    7392:      	je	0x7746 <generic_kprobe_filter_arg+0x13f6>
    7398:      	cmpl	$0xe, %eax
    739b:      	je	0x773c <generic_kprobe_filter_arg+0x13ec>
    73a1:      	movl	$0x0, %ebx
    73a6:      	cmpl	$0xf, %eax
    73a9:      	je	0x76d3 <generic_kprobe_filter_arg+0x1383>
    73af:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    73b4:      	cmpl	$0x20, %eax
    73b7:      	movq	%rsi, 0x8(%rsp)
    73bc:      	jg	0x79a8 <generic_kprobe_filter_arg+0x1658>
    73c2:      	cmpl	$0x1a, %eax
    73c5:      	je	0x7b9c <generic_kprobe_filter_arg+0x184c>
    73cb:      	movl	$0x0, %ebx
    73d0:      	cmpl	$0x1b, %eax
    73d3:      	jne	0x95e5 <generic_kprobe_filter_arg+0x3295>
    73d9:      	movq	%r11, 0x20(%rsp)
    73de:      	movl	0x10(%r12), %eax
    73e3:      	movl	%eax, 0x40(%rsp)
    73e7:      	movl	$0x0, 0x80(%rsp)
    73f2:      	movl	$0x1, %eax
    73f7:      	leaq	0x40(%rsp), %rsi
    73fc:      	movq	(%rip), %rdi            # 0x7403 <generic_kprobe_filter_arg+0x10b3>
    7403:      	callq	*%rax
    7405:      	testl	%ebp, %ebp
    7407:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    740d:      	movq	%rax, %r13
    7410:      	movl	$0x0, %ebx
    7415:      	testq	%rax, %rax
    7418:      	je	0x95d6 <generic_kprobe_filter_arg+0x3286>
    741e:      	movl	$0x1, %eax
    7423:      	movq	0x38(%rsp), %rsi
    7428:      	movq	(%rip), %rdi            # 0x742f <generic_kprobe_filter_arg+0x10df>
    742f:      	callq	*%rax
    7431:      	testq	%rax, %rax
    7434:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    743a:      	movq	%rax, %rdi
    743d:      	movq	%r13, 0x28(%rsp)
    7442:      	cmpl	$0x7f, %ebp
    7445:      	movl	$0x7f, %eax
    744a:      	cmovbl	%ebp, %eax
    744d:      	shll	$0x3, %eax
    7450:      	movl	%eax, (%rdi)
    7452:      	movq	%rbp, %rax
    7455:      	negq	%rax
    7458:      	movl	$0x3, %ecx
    745d:      	subq	%rbp, %rcx
    7460:      	leal	-0x4(%rbp), %edx
    7463:      	movq	%rdi, 0x70(%rsp)
    7468:      	addq	$0x7, %rdi
    746c:      	movl	$0x2, %r8d
    7472:      	subq	%rbp, %r8
    7475:      	leal	-0x3(%rbp), %r9d
    7479:      	movl	$0x1, %r10d
    747f:      	subq	%rbp, %r10
    7482:      	leal	-0x2(%rbp), %r11d
    7486:      	decl	%ebp
    7488:      	xorl	%ebx, %ebx
    748a:      	movq	0x8(%rsp), %rsi
    748f:      	leal	(%rbx,%rbp), %r13d
    7493:      	andl	$0xfff, %r13d           # imm = 0xFFF
    749a:      	movzbl	(%rsi,%r13), %r13d
    749f:      	movb	%r13b, -0x3(%rdi)
    74a3:      	cmpq	%rbx, %r10
    74a6:      	je	0x7500 <generic_kprobe_filter_arg+0x11b0>
    74a8:      	leal	(%r11,%rbx), %r13d
    74ac:      	andl	$0xfff, %r13d           # imm = 0xFFF
    74b3:      	movzbl	(%rsi,%r13), %r13d
    74b8:      	movb	%r13b, -0x2(%rdi)
    74bc:      	cmpq	%rbx, %r8
    74bf:      	je	0x7500 <generic_kprobe_filter_arg+0x11b0>
    74c1:      	leal	(%r9,%rbx), %r13d
    74c5:      	andl	$0xfff, %r13d           # imm = 0xFFF
    74cc:      	movzbl	(%rsi,%r13), %r13d
    74d1:      	movb	%r13b, -0x1(%rdi)
    74d5:      	cmpq	%rbx, %rcx
    74d8:      	je	0x7500 <generic_kprobe_filter_arg+0x11b0>
    74da:      	cmpq	$-0x7c, %rbx
    74de:      	je	0x7500 <generic_kprobe_filter_arg+0x11b0>
    74e0:      	leal	(%rdx,%rbx), %r13d
    74e4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    74eb:      	movzbl	(%rsi,%r13), %r13d
    74f0:      	movb	%r13b, (%rdi)
    74f3:      	addq	$-0x4, %rbx
    74f7:      	addq	$0x4, %rdi
    74fb:      	cmpq	%rbx, %rax
    74fe:      	jne	0x748f <generic_kprobe_filter_arg+0x113f>
    7500:      	movl	$0x1, %eax
    7505:      	movq	0x28(%rsp), %rdi
    750a:      	movq	0x70(%rsp), %rsi
    750f:      	jmp	0x95c8 <generic_kprobe_filter_arg+0x3278>
    7514:      	cmpl	$0xc, %eax
    7517:      	jne	0x8611 <generic_kprobe_filter_arg+0x22c1>
    751d:      	movq	0x8(%rsp), %rsi
    7522:      	testl	%edx, (%rsi)
    7524:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    752a:      	jmp	0x8611 <generic_kprobe_filter_arg+0x22c1>
    752f:      	movl	$0xc00, %edx            # imm = 0xC00
    7534:      	btq	%rcx, %rdx
    7538:      	jb	0x7a8a <generic_kprobe_filter_arg+0x173a>
    753e:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7548:      	btq	%rcx, %rdx
    754c:      	jae	0x645d <generic_kprobe_filter_arg+0x10d>
    7552:      	cmpl	$0x1f, %eax
    7555:      	jne	0x81e4 <generic_kprobe_filter_arg+0x1e94>
    755b:      	movq	0x8(%rsp), %rax
    7560:      	movzbl	(%rax), %eax
    7563:      	jmp	0x7599 <generic_kprobe_filter_arg+0x1249>
    7565:      	movl	$0xc00, %edx            # imm = 0xC00
    756a:      	btq	%rcx, %rdx
    756e:      	jb	0x7ad2 <generic_kprobe_filter_arg+0x1782>
    7574:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    757e:      	btq	%rcx, %rdx
    7582:      	jae	0x645d <generic_kprobe_filter_arg+0x10d>
    7588:      	cmpl	$0x1f, %eax
    758b:      	jne	0x81f3 <generic_kprobe_filter_arg+0x1ea3>
    7591:      	movq	0x8(%rsp), %rax
    7596:      	movzwl	(%rax), %eax
    7599:      	cmpl	%eax, 0x10(%r12)
    759e:      	ja	0x75ab <generic_kprobe_filter_arg+0x125b>
    75a0:      	cmpl	%eax, 0x14(%r12)
    75a5:      	jae	0x6618 <generic_kprobe_filter_arg+0x2c8>
    75ab:      	movl	0x8(%r12), %ecx
    75b0:      	cmpl	$0x11, %ecx
    75b3:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    75b9:      	cmpl	%eax, 0x18(%r12)
    75be:      	ja	0x75cb <generic_kprobe_filter_arg+0x127b>
    75c0:      	cmpl	%eax, 0x1c(%r12)
    75c5:      	jae	0x6618 <generic_kprobe_filter_arg+0x2c8>
    75cb:      	cmpl	$0x19, %ecx
    75ce:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    75d4:      	cmpl	%eax, 0x20(%r12)
    75d9:      	ja	0x75e6 <generic_kprobe_filter_arg+0x1296>
    75db:      	cmpl	%eax, 0x24(%r12)
    75e0:      	jae	0x6618 <generic_kprobe_filter_arg+0x2c8>
    75e6:      	cmpl	$0x21, %ecx
    75e9:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    75ef:      	cmpl	%eax, 0x28(%r12)
    75f4:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    75fa:      	cmpl	%eax, 0x2c(%r12)
    75ff:      	jae	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7605:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    760a:      	cmpl	$0xc, %ecx
    760d:      	je	0x7618 <generic_kprobe_filter_arg+0x12c8>
    760f:      	cmpl	$0xa, %ecx
    7612:      	jne	0x7fc5 <generic_kprobe_filter_arg+0x1c75>
    7618:      	movq	0x8(%rsp), %rsi
    761d:      	cmpq	%rdx, (%rsi)
    7620:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7626:      	jmp	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    762b:      	movzwl	%bp, %eax
    762e:      	cmpl	$0x90, %eax
    7633:      	movq	%r11, 0x20(%rsp)
    7638:      	ja	0x7cdf <generic_kprobe_filter_arg+0x198f>
    763e:      	testw	%bp, %bp
    7641:      	je	0x7653 <generic_kprobe_filter_arg+0x1303>
    7643:      	movl	%ebp, %eax
    7645:      	movl	$0x18, %ecx
    764a:      	cltd
    764b:      	idivl	%ecx
    764d:      	movl	%ebp, %esi
    764f:      	testl	%edx, %edx
    7651:      	je	0x7675 <generic_kprobe_filter_arg+0x1325>
    7653:      	movl	%ebp, %eax
    7655:      	movl	$0x18, %ecx
    765a:      	cltd
    765b:      	idivl	%ecx
    765d:      	shll	$0x3, %eax
    7660:      	leal	(%rax,%rax,2), %eax
    7663:      	addl	$0x18, %eax
    7666:      	movzwl	%ax, %esi
    7669:      	cmpl	$0x90, %esi
    766f:      	ja	0x7cf3 <generic_kprobe_filter_arg+0x19a3>
    7675:      	movl	%esi, %eax
    7677:      	cltd
    7678:      	idivl	%ecx
    767a:      	decl	%eax
    767c:      	jmp	0x7d04 <generic_kprobe_filter_arg+0x19b4>
    7681:      	movl	0x10(%r12), %esi
    7686:      	movl	0x14(%r12), %eax
    768b:      	cmpl	$0xc, %ecx
    768e:      	ja	0x8492 <generic_kprobe_filter_arg+0x2142>
    7694:      	movl	$0x1402, %edx           # imm = 0x1402
    7699:      	btl	%ecx, %edx
    769c:      	jae	0x8492 <generic_kprobe_filter_arg+0x2142>
    76a2:      	movq	0x8(%rsp), %rdx
    76a7:      	movl	(%rdx), %edx
    76a9:      	cmpl	%edx, %esi
    76ab:      	setle	%sil
    76af:      	cmpl	%eax, %edx
    76b1:      	setle	%al
    76b4:      	jmp	0x84a4 <generic_kprobe_filter_arg+0x2154>
    76b9:      	cmpl	$0x12, %eax
    76bc:      	je	0x76d3 <generic_kprobe_filter_arg+0x1383>
    76be:      	movl	$0x0, %ebx
    76c3:      	cmpl	$0x13, %eax
    76c6:      	jne	0x6602 <generic_kprobe_filter_arg+0x2b2>
    76cc:      	movzwl	0x22(%rsi), %r13d
    76d1:      	jmp	0x76d8 <generic_kprobe_filter_arg+0x1388>
    76d3:      	movzwl	0x20(%rsi), %r13d
    76d8:      	xorl	%edx, %edx
    76da:      	xorl	%ebp, %ebp
    76dc:      	xorl	%r8d, %r8d
    76df:      	xorl	%ebx, %ebx
    76e1:      	cmpl	$0x11, %eax
    76e4:      	jg	0x775e <generic_kprobe_filter_arg+0x140e>
    76e6:      	leal	-0xd(%rax), %ecx
    76e9:      	cmpl	$0x2, %ecx
    76ec:      	jb	0x7791 <generic_kprobe_filter_arg+0x1441>
    76f2:      	leal	-0xf(%rax), %ecx
    76f5:      	cmpl	$0x2, %ecx
    76f8:      	jb	0x7934 <generic_kprobe_filter_arg+0x15e4>
    76fe:      	cmpl	$0x11, %eax
    7701:      	je	0x7f3e <generic_kprobe_filter_arg+0x1bee>
    7707:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    770c:      	cmpl	$0x1c, %eax
    770f:      	je	0x7f3a <generic_kprobe_filter_arg+0x1bea>
    7715:      	movl	$0x0, %ebx
    771a:      	cmpl	$0x1d, %eax
    771d:      	jne	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7723:      	cmpl	$0x7, %ecx
    7726:      	jne	0x8582 <generic_kprobe_filter_arg+0x2232>
    772c:      	testq	%rdx, %rdx
    772f:      	jne	0x858e <generic_kprobe_filter_arg+0x223e>
    7735:      	xorl	%ebx, %ebx
    7737:      	jmp	0x85a0 <generic_kprobe_filter_arg+0x2250>
    773c:      	movq	0x10(%rsi), %rdx
    7740:      	movq	0x18(%rsi), %r8
    7744:      	jmp	0x774d <generic_kprobe_filter_arg+0x13fd>
    7746:      	movq	(%rsi), %rdx
    7749:      	movq	0x8(%rsi), %r8
    774d:      	movq	%rdx, %rbp
    7750:      	shrq	$0x20, %rbp
    7754:      	xorl	%r13d, %r13d
    7757:      	xorl	%ebx, %ebx
    7759:      	cmpl	$0x11, %eax
    775c:      	jle	0x76e6 <generic_kprobe_filter_arg+0x1396>
    775e:      	cmpl	$0x19, %eax
    7761:      	ja	0x7928 <generic_kprobe_filter_arg+0x15d8>
    7767:      	movl	$0x500000, %ecx         # imm = 0x500000
    776c:      	btl	%eax, %ecx
    776f:      	jb	0x7cb9 <generic_kprobe_filter_arg+0x1969>
    7775:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    777a:      	btl	%eax, %ecx
    777d:      	jb	0x7ccc <generic_kprobe_filter_arg+0x197c>
    7783:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7788:      	btl	%eax, %ecx
    778b:      	jae	0x7928 <generic_kprobe_filter_arg+0x15d8>
    7791:      	movzwl	0x26(%rsi), %eax
    7795:      	cmpl	$0xa, %eax
    7798:      	je	0x7de6 <generic_kprobe_filter_arg+0x1a96>
    779e:      	cmpl	$0x2, %eax
    77a1:      	jne	0x7e87 <generic_kprobe_filter_arg+0x1b37>
    77a7:      	movq	%rdx, %r13
    77aa:      	movq	%r11, 0x20(%rsp)
    77af:      	movl	0x10(%r12), %eax
    77b4:      	movl	%eax, 0x34(%rsp)
    77b8:      	movl	$0x1, %eax
    77bd:      	leaq	0x34(%rsp), %rsi
    77c2:      	movq	(%rip), %rdi            # 0x77c9 <generic_kprobe_filter_arg+0x1479>
    77c9:      	callq	*%rax
    77cb:      	testq	%rax, %rax
    77ce:      	je	0x80ab <generic_kprobe_filter_arg+0x1d5b>
    77d4:      	movq	%rax, %rdi
    77d7:      	movl	$0x20, 0x80(%rsp)
    77e2:      	movl	%r13d, 0x84(%rsp)
    77ea:      	jmp	0x7e45 <generic_kprobe_filter_arg+0x1af5>
    77ef:      	cmpl	$0xc, %ecx
    77f2:      	ja	0x85f5 <generic_kprobe_filter_arg+0x22a5>
    77f8:      	movl	$0x1402, %esi           # imm = 0x1402
    77fd:      	btl	%ecx, %esi
    7800:      	jae	0x85f5 <generic_kprobe_filter_arg+0x22a5>
    7806:      	movq	0x8(%rsp), %rsi
    780b:      	cmpl	%edx, (%rsi)
    780d:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7813:      	jmp	0x8611 <generic_kprobe_filter_arg+0x22c1>
    7818:      	movq	%rsi, 0x8(%rsp)
    781d:      	xorl	%ebx, %ebx
    781f:      	xorl	%r13d, %r13d
    7822:      	movq	%r11, %r15
    7825:      	movl	0x10(%r12,%rbx,4), %eax
    782a:      	movl	%eax, 0x40(%rsp)
    782e:      	movl	$0x1, %eax
    7833:      	leaq	0x40(%rsp), %rsi
    7838:      	movq	(%rip), %rdi            # 0x783f <generic_kprobe_filter_arg+0x14ef>
    783f:      	callq	*%rax
    7841:      	testq	%rax, %rax
    7844:      	je	0x86cf <generic_kprobe_filter_arg+0x237f>
    784a:      	testl	%ebp, %ebp
    784c:      	movq	0x18(%rsp), %r9
    7851:      	movq	%r15, %r11
    7854:      	movq	0x68(%rsp), %r15
    7859:      	je	0x78af <generic_kprobe_filter_arg+0x155f>
    785b:      	movq	0x8(%rsp), %rdx
    7860:      	xorl	%ecx, %ecx
    7862:      	jmp	0x786f <generic_kprobe_filter_arg+0x151f>
    7864:      	incq	%rcx
    7867:      	incq	%rdx
    786a:      	cmpq	%rbp, %rcx
    786d:      	je	0x78af <generic_kprobe_filter_arg+0x155f>
    786f:      	xorl	%esi, %esi
    7871:      	nopw	%cs:(%rax,%rax)
    7880:      	leaq	(%rcx,%rsi), %rdi
    7884:      	cmpq	%rbp, %rdi
    7887:      	jae	0x7864 <generic_kprobe_filter_arg+0x1514>
    7889:      	movzbl	(%rax,%rsi), %edi
    788d:      	testb	%dil, %dil
    7890:      	je	0x78a7 <generic_kprobe_filter_arg+0x1557>
    7892:      	cmpq	$0x62, %rsi
    7896:      	ja	0x7864 <generic_kprobe_filter_arg+0x1514>
    7898:      	leaq	0x1(%rsi), %r8
    789c:      	cmpb	%dil, (%rdx,%rsi)
    78a0:      	movq	%r8, %rsi
    78a3:      	je	0x7880 <generic_kprobe_filter_arg+0x1530>
    78a5:      	jmp	0x7864 <generic_kprobe_filter_arg+0x1514>
    78a7:      	testl	%ecx, %ecx
    78a9:      	jns	0x89b5 <generic_kprobe_filter_arg+0x2665>
    78af:      	leal	0xc(%r13), %eax
    78b3:      	cmpl	0x8(%r12), %eax
    78b8:      	jae	0x78cb <generic_kprobe_filter_arg+0x157b>
    78ba:      	addl	$0x4, %r13d
    78be:      	incq	%rbx
    78c1:      	cmpq	$0x64, %rbx
    78c5:      	jne	0x7822 <generic_kprobe_filter_arg+0x14d2>
    78cb:      	xorl	%ebx, %ebx
    78cd:      	jmp	0x89ba <generic_kprobe_filter_arg+0x266a>
    78d2:      	movzwl	%bp, %eax
    78d5:      	cmpl	$0x90, %eax
    78da:      	movq	%r11, 0x20(%rsp)
    78df:      	ja	0x80bb <generic_kprobe_filter_arg+0x1d6b>
    78e5:      	testw	%bp, %bp
    78e8:      	je	0x78fa <generic_kprobe_filter_arg+0x15aa>
    78ea:      	movl	%ebp, %eax
    78ec:      	movl	$0x18, %ecx
    78f1:      	cltd
    78f2:      	idivl	%ecx
    78f4:      	movl	%ebp, %edi
    78f6:      	testl	%edx, %edx
    78f8:      	je	0x791c <generic_kprobe_filter_arg+0x15cc>
    78fa:      	movl	%ebp, %eax
    78fc:      	movl	$0x18, %ecx
    7901:      	cltd
    7902:      	idivl	%ecx
    7904:      	shll	$0x3, %eax
    7907:      	leal	(%rax,%rax,2), %eax
    790a:      	addl	$0x18, %eax
    790d:      	movzwl	%ax, %edi
    7910:      	cmpl	$0x90, %edi
    7916:      	ja	0x80cf <generic_kprobe_filter_arg+0x1d7f>
    791c:      	movl	%edi, %eax
    791e:      	cltd
    791f:      	idivl	%ecx
    7921:      	decl	%eax
    7923:      	jmp	0x80e0 <generic_kprobe_filter_arg+0x1d90>
    7928:      	addl	$-0x12, %eax
    792b:      	cmpl	$0x2, %eax
    792e:      	jae	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7934:      	movq	%r11, %rbp
    7937:      	movzbl	0x10(%r12), %eax
    793d:      	movl	%eax, 0x34(%rsp)
    7941:      	movl	$0x1, %eax
    7946:      	movq	(%rip), %rdi            # 0x794d <generic_kprobe_filter_arg+0x15fd>
    794d:      	leaq	0x34(%rsp), %rsi
    7952:      	callq	*%rax
    7954:      	testq	%rax, %rax
    7957:      	je	0x7c5a <generic_kprobe_filter_arg+0x190a>
    795d:      	movq	%rax, %rdi
    7960:      	movzwl	%r13w, %eax
    7964:      	movq	%rax, 0x80(%rsp)
    796c:      	movl	$0x1, %eax
    7971:      	movq	0x38(%rsp), %rsi
    7976:      	callq	*%rax
    7978:      	movl	0x4(%r12), %edx
    797d:      	xorl	%ecx, %ecx
    797f:      	cmpl	$0x1d, %edx
    7982:      	ja	0x8ff9 <generic_kprobe_filter_arg+0x2ca9>
    7988:      	movl	$0x30038400, %esi       # imm = 0x30038400
    798d:      	btl	%edx, %esi
    7990:      	movq	0x10(%rsp), %rdi
    7995:      	movq	0x18(%rsp), %r9
    799a:      	movq	%rbp, %r11
    799d:      	jb	0x65f9 <generic_kprobe_filter_arg+0x2a9>
    79a3:      	jmp	0x7fac <generic_kprobe_filter_arg+0x1c5c>
    79a8:      	cmpl	$0x21, %eax
    79ab:      	je	0x8278 <generic_kprobe_filter_arg+0x1f28>
    79b1:      	movl	$0x0, %ebx
    79b6:      	cmpl	$0x22, %eax
    79b9:      	jne	0x95e5 <generic_kprobe_filter_arg+0x3295>
    79bf:      	movl	$0x10, %r13d
    79c5:      	movq	%r11, %r15
    79c8:      	movl	(%r12,%r13), %eax
    79cc:      	movl	%eax, 0x40(%rsp)
    79d0:      	movl	$0x1, %eax
    79d5:      	leaq	0x40(%rsp), %rsi
    79da:      	movq	(%rip), %rdi            # 0x79e1 <generic_kprobe_filter_arg+0x1691>
    79e1:      	callq	*%rax
    79e3:      	testq	%rax, %rax
    79e6:      	je	0x8ce2 <generic_kprobe_filter_arg+0x2992>
    79ec:      	movq	0x8(%rsp), %rdi
    79f1:      	movq	%rax, %rsi
    79f4:      	movq	%rbp, %rdx
    79f7:      	callq	0x79fc <generic_kprobe_filter_arg+0x16ac>
    79fc:      	testl	%eax, %eax
    79fe:      	jns	0x8ce6 <generic_kprobe_filter_arg+0x2996>
    7a04:      	addq	$0x4, %r13
    7a08:      	leal	-0x8(%r13), %eax
    7a0c:      	cmpl	0x8(%r12), %eax
    7a11:      	movq	0x10(%rsp), %rdi
    7a16:      	movq	0x18(%rsp), %r9
    7a1b:      	movq	%r15, %r11
    7a1e:      	jae	0x8d92 <generic_kprobe_filter_arg+0x2a42>
    7a24:      	movl	$0x0, %ebx
    7a29:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    7a30:      	movq	0x68(%rsp), %r15
    7a35:      	jne	0x79c5 <generic_kprobe_filter_arg+0x1675>
    7a37:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    7a3c:      	cmpl	$0x1, %eax
    7a3f:      	je	0x837d <generic_kprobe_filter_arg+0x202d>
    7a45:      	cmpl	$0x2, %eax
    7a48:      	jne	0x838d <generic_kprobe_filter_arg+0x203d>
    7a4e:      	movq	0x8(%rsp), %rdx
    7a53:      	movzbl	(%rdx), %edx
    7a56:      	cmpl	%edx, %ecx
    7a58:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7a5e:      	jmp	0x838d <generic_kprobe_filter_arg+0x203d>
    7a63:      	cmpl	$0x1, %eax
    7a66:      	je	0x83ca <generic_kprobe_filter_arg+0x207a>
    7a6c:      	cmpl	$0x2, %eax
    7a6f:      	jne	0x83da <generic_kprobe_filter_arg+0x208a>
    7a75:      	movq	0x8(%rsp), %rdx
    7a7a:      	movzwl	(%rdx), %edx
    7a7d:      	cmpl	%edx, %ecx
    7a7f:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7a85:      	jmp	0x83da <generic_kprobe_filter_arg+0x208a>
    7a8a:      	movq	%r11, %rbp
    7a8d:      	movzbl	0x10(%r12), %eax
    7a93:      	movl	%eax, 0x80(%rsp)
    7a9a:      	movl	$0x1, %eax
    7a9f:      	movq	0x38(%rsp), %rsi
    7aa4:      	movq	(%rip), %rdi            # 0x7aab <generic_kprobe_filter_arg+0x175b>
    7aab:      	callq	*%rax
    7aad:      	testq	%rax, %rax
    7ab0:      	je	0x7b4b <generic_kprobe_filter_arg+0x17fb>
    7ab6:      	movq	%rax, %rdi
    7ab9:      	movq	0x8(%rsp), %rax
    7abe:      	movzbl	(%rax), %eax
    7ac1:      	movq	%rax, 0x40(%rsp)
    7ac6:      	movl	$0x1, %eax
    7acb:      	leaq	0x40(%rsp), %rsi
    7ad0:      	jmp	0x7b14 <generic_kprobe_filter_arg+0x17c4>
    7ad2:      	movq	%r11, %rbp
    7ad5:      	movzbl	0x10(%r12), %eax
    7adb:      	movl	%eax, 0x80(%rsp)
    7ae2:      	movl	$0x1, %eax
    7ae7:      	movq	0x38(%rsp), %rsi
    7aec:      	movq	(%rip), %rdi            # 0x7af3 <generic_kprobe_filter_arg+0x17a3>
    7af3:      	callq	*%rax
    7af5:      	testq	%rax, %rax
    7af8:      	je	0x7b4b <generic_kprobe_filter_arg+0x17fb>
    7afa:      	movq	%rax, %rdi
    7afd:      	movq	0x8(%rsp), %rax
    7b02:      	movzwl	(%rax), %eax
    7b05:      	movq	%rax, 0x40(%rsp)
    7b0a:      	movl	$0x1, %eax
    7b0f:      	leaq	0x40(%rsp), %rsi
    7b14:      	callq	*%rax
    7b16:      	movl	0x4(%r12), %edx
    7b1b:      	xorl	%ecx, %ecx
    7b1d:      	cmpl	$0x1d, %edx
    7b20:      	ja	0x8c43 <generic_kprobe_filter_arg+0x28f3>
    7b26:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7b2b:      	btl	%edx, %esi
    7b2e:      	movq	0x10(%rsp), %rdi
    7b33:      	movq	0x18(%rsp), %r9
    7b38:      	movq	%rbp, %r11
    7b3b:      	jae	0x7b5f <generic_kprobe_filter_arg+0x180f>
    7b3d:      	testq	%rax, %rax
    7b40:      	setne	%cl
    7b43:      	movzbl	%cl, %ebx
    7b46:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    7b4b:      	xorl	%ebx, %ebx
    7b4d:      	movq	0x10(%rsp), %rdi
    7b52:      	movq	0x18(%rsp), %r9
    7b57:      	movq	%rbp, %r11
    7b5a:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    7b5f:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7b64:      	btl	%edx, %esi
    7b67:      	jae	0x7b6f <generic_kprobe_filter_arg+0x181f>
    7b69:      	testq	%rax, %rax
    7b6c:      	sete	%cl
    7b6f:      	movzbl	%cl, %ebx
    7b72:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    7b77:      	testq	%rax, %rax
    7b7a:      	sete	%al
    7b7d:      	movq	0x10(%rsp), %rdi
    7b82:      	movq	0x18(%rsp), %r9
    7b87:      	movq	%rbp, %r11
    7b8a:      	movzbl	%al, %ebx
    7b8d:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    7b92:      	xorl	%eax, %eax
    7b94:      	movzbl	%al, %ebx
    7b97:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    7b9c:      	movq	%r11, 0x20(%rsp)
    7ba1:      	movl	0x10(%r12), %eax
    7ba6:      	movl	%eax, 0x40(%rsp)
    7baa:      	movl	$0x0, 0x80(%rsp)
    7bb5:      	movl	$0x1, %eax
    7bba:      	leaq	0x40(%rsp), %rsi
    7bbf:      	movq	(%rip), %rdi            # 0x7bc6 <generic_kprobe_filter_arg+0x1876>
    7bc6:      	callq	*%rax
    7bc8:      	testl	%ebp, %ebp
    7bca:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    7bd0:      	movq	%rax, %r13
    7bd3:      	movl	$0x0, %ebx
    7bd8:      	testq	%rax, %rax
    7bdb:      	je	0x95d6 <generic_kprobe_filter_arg+0x3286>
    7be1:      	movl	$0x1, %eax
    7be6:      	movq	0x38(%rsp), %rsi
    7beb:      	movq	(%rip), %rdi            # 0x7bf2 <generic_kprobe_filter_arg+0x18a2>
    7bf2:      	callq	*%rax
    7bf4:      	testq	%rax, %rax
    7bf7:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    7bfd:      	cmpl	$0xff, %ebp
    7c03:      	movl	$0xff, %ecx
    7c08:      	cmovael	%ecx, %ebp
    7c0b:      	leal	(,%rbp,8), %ecx
    7c12:      	movl	%ecx, (%rax)
    7c14:      	movq	%rax, %rdi
    7c17:      	addq	$0x4, %rdi
    7c1b:      	movq	%rax, %rbx
    7c1e:      	movl	$0x4, %eax
    7c23:      	movq	0x8(%rsp), %rdx
    7c28:      	movl	%ebp, %esi
    7c2a:      	callq	*%rax
    7c2c:      	movl	$0x1, %eax
    7c31:      	movq	%r13, %rdi
    7c34:      	movq	%rbx, %rsi
    7c37:      	jmp	0x95c8 <generic_kprobe_filter_arg+0x3278>
    7c3c:      	movl	$0x0, 0x80(%rsp)
    7c47:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    7c4d:      	jbe	0x8327 <generic_kprobe_filter_arg+0x1fd7>
    7c53:      	xorl	%ebx, %ebx
    7c55:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    7c5a:      	xorl	%ebx, %ebx
    7c5c:      	movq	0x10(%rsp), %rdi
    7c61:      	movq	0x18(%rsp), %r9
    7c66:      	movq	%rbp, %r11
    7c69:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7c6e:      	cmpl	$0x1e, %eax
    7c71:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    7c77:      	movl	0x10(%r12), %eax
    7c7c:      	andl	$0x7, %eax
    7c7f:      	movl	%eax, %ecx
    7c81:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    7c8a:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    7c90:      	movq	0x8(%rsp), %rcx
    7c95:      	movq	(%rcx), %rcx
    7c98:      	movq	0x5e78(%r14,%rax,8), %rax
    7ca0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    7ca5:      	xorl	%ebx, %ebx
    7ca7:      	andnq	0x90(%r14,%rax), %rcx, %rax
    7cb1:      	setne	%bl
    7cb4:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    7cb9:      	movzwl	%r13w, %eax
    7cbd:      	xorl	%ebx, %ebx
    7cbf:      	cmpl	$0x400, %eax            # imm = 0x400
    7cc4:      	setb	%bl
    7cc7:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7ccc:      	movzwl	%r13w, %eax
    7cd0:      	xorl	%ebx, %ebx
    7cd2:      	cmpl	$0x400, %eax            # imm = 0x400
    7cd7:      	setae	%bl
    7cda:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7cdf:      	cmpl	$0x101, %eax            # imm = 0x101
    7ce4:      	movl	$0x100, %esi            # imm = 0x100
    7ce9:      	movl	$0x1fe, %eax            # imm = 0x1FE
    7cee:      	cmovael	%eax, %esi
    7cf1:      	movl	%esi, %eax
    7cf3:      	movzwl	%ax, %ecx
    7cf6:      	xorl	%eax, %eax
    7cf8:      	cmpl	$0x100, %ecx            # imm = 0x100
    7cfe:      	sete	%al
    7d01:      	xorl	$0x7, %eax
    7d04:      	movl	%eax, %ecx
    7d06:      	andl	$0xf, %ecx
    7d09:      	movl	0x10(%r12,%rcx,4), %ecx
    7d0e:      	cmpl	$-0x1, %ecx
    7d11:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    7d17:      	movl	%ecx, 0xa0(%rsp)
    7d1e:      	movq	%rsi, 0x98(%rsp)
    7d26:      	movl	%eax, 0x70(%rsp)
    7d2a:      	movl	$0x1, %eax
    7d2f:      	movq	(%rip), %rdi            # 0x7d36 <generic_kprobe_filter_arg+0x19e6>
    7d36:      	movq	0x38(%rsp), %rbx
    7d3b:      	movq	%rbx, %rsi
    7d3e:      	callq	*%rax
    7d40:      	movq	%rax, 0x28(%rsp)
    7d45:      	movl	$0x1, %eax
    7d4a:      	movq	(%rip), %rdi            # 0x7d51 <generic_kprobe_filter_arg+0x1a01>
    7d51:      	movq	%rbx, %rsi
    7d54:      	callq	*%rax
    7d56:      	cmpq	$0x0, 0x28(%rsp)
    7d5c:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    7d62:      	movl	$0x0, %ebx
    7d67:      	testq	%rax, %rax
    7d6a:      	movq	0x10(%rsp), %rdi
    7d6f:      	movq	0x18(%rsp), %r9
    7d74:      	movq	0x20(%rsp), %r11
    7d79:      	je	0x913a <generic_kprobe_filter_arg+0x2dea>
    7d7f:      	movq	%rax, 0xa8(%rsp)
    7d87:      	movq	0x8(%rsp), %rdx
    7d8c:      	addq	$0x4, %rdx
    7d90:      	movl	0x70(%rsp), %ebx
    7d94:      	cmpl	$0x5, %ebx
    7d97:      	jg	0x8740 <generic_kprobe_filter_arg+0x23f0>
    7d9d:      	movq	0x28(%rsp), %rax
    7da2:      	movb	%bpl, (%rax)
    7da5:      	leaq	0x1(%rax), %rdi
    7da9:      	movl	$0x4, %eax
    7dae:      	movl	%ebp, %esi
    7db0:      	callq	*%rax
    7db2:      	movq	0x98(%rsp), %rsi
    7dba:      	subl	%ebp, %esi
    7dbc:      	jbe	0x8783 <generic_kprobe_filter_arg+0x2433>
    7dc2:      	movq	0x28(%rsp), %rax
    7dc7:      	leaq	(%rax,%rbp), %rdi
    7dcb:      	incq	%rdi
    7dce:      	andl	$0xfff, %esi            # imm = 0xFFF
    7dd4:      	movl	$0x4, %eax
    7dd9:      	movq	0xa8(%rsp), %rdx
    7de1:      	jmp	0x8781 <generic_kprobe_filter_arg+0x2431>
    7de6:      	movq	%r8, %rbx
    7de9:      	movq	%rdx, %r13
    7dec:      	movq	%r11, 0x20(%rsp)
    7df1:      	movl	0x14(%r12), %eax
    7df6:      	movl	%eax, 0x34(%rsp)
    7dfa:      	movl	$0x1, %eax
    7dff:      	movq	(%rip), %rdi            # 0x7e06 <generic_kprobe_filter_arg+0x1ab6>
    7e06:      	leaq	0x34(%rsp), %rsi
    7e0b:      	callq	*%rax
    7e0d:      	testq	%rax, %rax
    7e10:      	je	0x80ab <generic_kprobe_filter_arg+0x1d5b>
    7e16:      	movq	%rax, %rdi
    7e19:      	movl	$0x80, 0x80(%rsp)
    7e24:      	movl	%r13d, 0x84(%rsp)
    7e2c:      	movl	%ebp, 0x88(%rsp)
    7e33:      	movl	%ebx, 0x8c(%rsp)
    7e3a:      	shrq	$0x20, %rbx
    7e3e:      	movl	%ebx, 0x90(%rsp)
    7e45:      	movl	$0x1, %eax
    7e4a:      	movq	0x38(%rsp), %rsi
    7e4f:      	callq	*%rax
    7e51:      	movl	0x4(%r12), %ecx
    7e56:      	leal	-0x18(%rcx), %edx
    7e59:      	cmpl	$0x2, %edx
    7e5c:      	jb	0x8417 <generic_kprobe_filter_arg+0x20c7>
    7e62:      	addl	$-0xd, %ecx
    7e65:      	cmpl	$0x1, %ecx
    7e68:      	movq	0x10(%rsp), %rdi
    7e6d:      	movq	0x18(%rsp), %r9
    7e72:      	movq	0x20(%rsp), %r11
    7e77:      	ja	0x7e87 <generic_kprobe_filter_arg+0x1b37>
    7e79:      	testq	%rax, %rax
    7e7c:      	setne	%al
    7e7f:      	movzbl	%al, %ebx
    7e82:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7e87:      	xorl	%eax, %eax
    7e89:      	movzbl	%al, %ebx
    7e8c:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    7e91:      	movq	0x8(%rsp), %rax
    7e96:      	movq	(%rax), %rax
    7e99:      	cmpq	%rax, %rsi
    7e9c:      	ja	0x7ea7 <generic_kprobe_filter_arg+0x1b57>
    7e9e:      	cmpq	%rdx, %rax
    7ea1:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7ea7:      	movl	0x8(%r12), %edx
    7eac:      	cmpl	$0x19, %edx
    7eaf:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    7eb5:      	movq	0x20(%r12), %rdi
    7eba:      	movq	0x28(%r12), %rsi
    7ebf:      	cmpl	$0xc, %ecx
    7ec2:      	je	0x7ecd <generic_kprobe_filter_arg+0x1b7d>
    7ec4:      	cmpl	$0xa, %ecx
    7ec7:      	jne	0x8532 <generic_kprobe_filter_arg+0x21e2>
    7ecd:      	cmpq	%rax, %rdi
    7ed0:      	movq	0x10(%rsp), %rdi
    7ed5:      	jg	0x8545 <generic_kprobe_filter_arg+0x21f5>
    7edb:      	cmpq	%rsi, %rax
    7ede:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7ee4:      	jmp	0x8545 <generic_kprobe_filter_arg+0x21f5>
    7ee9:      	movq	0x8(%rsp), %rdx
    7eee:      	movq	(%rdx), %rdx
    7ef1:      	cmpq	%rdx, %rsi
    7ef4:      	setbe	%sil
    7ef8:      	cmpq	%rax, %rdx
    7efb:      	setbe	%al
    7efe:      	andb	%sil, %al
    7f01:      	movl	0x8(%r12), %esi
    7f06:      	cmpl	$0x19, %esi
    7f09:      	jb	0x9179 <generic_kprobe_filter_arg+0x2e29>
    7f0f:      	movq	0x20(%r12), %r8
    7f14:      	movq	0x28(%r12), %rdi
    7f19:      	cmpl	$0xc, %ecx
    7f1c:      	je	0x7f27 <generic_kprobe_filter_arg+0x1bd7>
    7f1e:      	cmpl	$0xa, %ecx
    7f21:      	jne	0x84ea <generic_kprobe_filter_arg+0x219a>
    7f27:      	cmpq	%rdx, %r8
    7f2a:      	setle	%r8b
    7f2e:      	cmpq	%rdi, %rdx
    7f31:      	setle	%dil
    7f35:      	jmp	0x84f8 <generic_kprobe_filter_arg+0x21a8>
    7f3a:      	movzwl	0x26(%rsi), %ebx
    7f3e:      	movq	%r11, %r13
    7f41:      	movzbl	0x10(%r12), %eax
    7f47:      	movl	%eax, 0x34(%rsp)
    7f4b:      	movl	$0x1, %eax
    7f50:      	movq	(%rip), %rdi            # 0x7f57 <generic_kprobe_filter_arg+0x1c07>
    7f57:      	leaq	0x34(%rsp), %rsi
    7f5c:      	callq	*%rax
    7f5e:      	testq	%rax, %rax
    7f61:      	je	0x85e1 <generic_kprobe_filter_arg+0x2291>
    7f67:      	movq	%rax, %rdi
    7f6a:      	movzwl	%bx, %eax
    7f6d:      	movq	%rax, 0x80(%rsp)
    7f75:      	movl	$0x1, %eax
    7f7a:      	movq	0x38(%rsp), %rsi
    7f7f:      	callq	*%rax
    7f81:      	movl	0x4(%r12), %edx
    7f86:      	xorl	%ecx, %ecx
    7f88:      	cmpl	$0x1d, %edx
    7f8b:      	ja	0x8f8a <generic_kprobe_filter_arg+0x2c3a>
    7f91:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7f96:      	btl	%edx, %esi
    7f99:      	movq	0x10(%rsp), %rdi
    7f9e:      	movq	0x18(%rsp), %r9
    7fa3:      	movq	%r13, %r11
    7fa6:      	jb	0x65f9 <generic_kprobe_filter_arg+0x2a9>
    7fac:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7fb1:      	btl	%edx, %esi
    7fb4:      	jae	0x65ff <generic_kprobe_filter_arg+0x2af>
    7fba:      	testq	%rax, %rax
    7fbd:      	sete	%cl
    7fc0:      	jmp	0x65ff <generic_kprobe_filter_arg+0x2af>
    7fc5:      	movq	0x8(%rsp), %rsi
    7fca:      	cmpq	%rdx, (%rsi)
    7fcd:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7fd3:      	jmp	0x7fe3 <generic_kprobe_filter_arg+0x1c93>
    7fd5:      	movq	0x8(%rsp), %rsi
    7fda:      	cmpq	%rdx, (%rsi)
    7fdd:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    7fe3:      	movl	0x8(%r12), %edx
    7fe8:      	cmpl	$0x11, %edx
    7feb:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    7ff1:      	movq	0x18(%r12), %rsi
    7ff6:      	cmpl	$0x2, %eax
    7ff9:      	jle	0x801b <generic_kprobe_filter_arg+0x1ccb>
    7ffb:      	leal	-0x3(%rax), %edi
    7ffe:      	cmpl	$0x2, %edi
    8001:      	jae	0x804e <generic_kprobe_filter_arg+0x1cfe>
    8003:      	movq	0x8(%rsp), %rdi
    8008:      	cmpq	%rsi, (%rdi)
    800b:      	movq	0x10(%rsp), %rdi
    8010:      	jne	0x8b80 <generic_kprobe_filter_arg+0x2830>
    8016:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    801b:      	cmpl	$0x1, %eax
    801e:      	je	0x81c3 <generic_kprobe_filter_arg+0x1e73>
    8024:      	cmpl	$0x2, %eax
    8027:      	jne	0x8b80 <generic_kprobe_filter_arg+0x2830>
    802d:      	cmpl	$0xc, %ecx
    8030:      	je	0x803b <generic_kprobe_filter_arg+0x1ceb>
    8032:      	cmpl	$0xa, %ecx
    8035:      	jne	0x8b72 <generic_kprobe_filter_arg+0x2822>
    803b:      	movq	0x8(%rsp), %r8
    8040:      	cmpq	%rsi, (%r8)
    8043:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8049:      	jmp	0x8b80 <generic_kprobe_filter_arg+0x2830>
    804e:      	cmpl	$0xc, %eax
    8051:      	movq	0x10(%rsp), %rdi
    8056:      	jne	0x8b80 <generic_kprobe_filter_arg+0x2830>
    805c:      	movq	0x8(%rsp), %r8
    8061:      	testq	%rsi, (%r8)
    8064:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    806a:      	jmp	0x8b80 <generic_kprobe_filter_arg+0x2830>
    806f:      	cmpl	$0xc, %eax
    8072:      	jne	0x838d <generic_kprobe_filter_arg+0x203d>
    8078:      	movq	0x8(%rsp), %rdx
    807d:      	movzbl	(%rdx), %edx
    8080:      	testl	%edx, %ecx
    8082:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8088:      	jmp	0x838d <generic_kprobe_filter_arg+0x203d>
    808d:      	cmpl	$0xc, %eax
    8090:      	jne	0x83da <generic_kprobe_filter_arg+0x208a>
    8096:      	movq	0x8(%rsp), %rdx
    809b:      	movzwl	(%rdx), %edx
    809e:      	testl	%edx, %ecx
    80a0:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    80a6:      	jmp	0x83da <generic_kprobe_filter_arg+0x208a>
    80ab:      	movl	0x4(%r12), %eax
    80b0:      	andl	$-0x2, %eax
    80b3:      	cmpl	$0x18, %eax
    80b6:      	jmp	0x841a <generic_kprobe_filter_arg+0x20ca>
    80bb:      	cmpl	$0x101, %eax            # imm = 0x101
    80c0:      	movl	$0x100, %edi            # imm = 0x100
    80c5:      	movl	$0x1fe, %eax            # imm = 0x1FE
    80ca:      	cmovael	%eax, %edi
    80cd:      	movl	%edi, %eax
    80cf:      	movzwl	%ax, %ecx
    80d2:      	xorl	%eax, %eax
    80d4:      	cmpl	$0x100, %ecx            # imm = 0x100
    80da:      	sete	%al
    80dd:      	xorl	$0x7, %eax
    80e0:      	movl	%eax, %ecx
    80e2:      	andl	$0xf, %ecx
    80e5:      	movl	0x10(%r12,%rcx,4), %ecx
    80ea:      	cmpl	$-0x1, %ecx
    80ed:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    80f3:      	movl	%ecx, 0xa0(%rsp)
    80fa:      	movq	%rdi, 0x98(%rsp)
    8102:      	movl	%eax, 0x70(%rsp)
    8106:      	movq	%rsi, 0x8(%rsp)
    810b:      	movl	$0x1, %eax
    8110:      	movq	(%rip), %rdi            # 0x8117 <generic_kprobe_filter_arg+0x1dc7>
    8117:      	movq	0x38(%rsp), %rbx
    811c:      	movq	%rbx, %rsi
    811f:      	callq	*%rax
    8121:      	movq	%rax, 0x28(%rsp)
    8126:      	movl	$0x1, %eax
    812b:      	movq	(%rip), %rdi            # 0x8132 <generic_kprobe_filter_arg+0x1de2>
    8132:      	movq	%rbx, %rsi
    8135:      	callq	*%rax
    8137:      	cmpq	$0x0, 0x28(%rsp)
    813d:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    8143:      	movl	$0x0, %ebx
    8148:      	testq	%rax, %rax
    814b:      	movq	0x10(%rsp), %rdi
    8150:      	movq	0x18(%rsp), %r9
    8155:      	movq	0x20(%rsp), %r11
    815a:      	je	0x9317 <generic_kprobe_filter_arg+0x2fc7>
    8160:      	movq	%rax, 0xa8(%rsp)
    8168:      	movl	0x70(%rsp), %ebx
    816c:      	cmpl	$0x5, %ebx
    816f:      	jg	0x8a4a <generic_kprobe_filter_arg+0x26fa>
    8175:      	movq	0x28(%rsp), %rax
    817a:      	movb	%bpl, (%rax)
    817d:      	leaq	0x1(%rax), %rdi
    8181:      	movl	$0x4, %eax
    8186:      	movq	0x8(%rsp), %rdx
    818b:      	movl	%ebp, %esi
    818d:      	callq	*%rax
    818f:      	movq	0x98(%rsp), %rsi
    8197:      	subl	%ebp, %esi
    8199:      	jbe	0x8a92 <generic_kprobe_filter_arg+0x2742>
    819f:      	movq	0x28(%rsp), %rax
    81a4:      	leaq	(%rax,%rbp), %rdi
    81a8:      	incq	%rdi
    81ab:      	andl	$0xfff, %esi            # imm = 0xFFF
    81b1:      	movl	$0x4, %eax
    81b6:      	movq	0xa8(%rsp), %rdx
    81be:      	jmp	0x8a90 <generic_kprobe_filter_arg+0x2740>
    81c3:      	cmpl	$0xc, %ecx
    81c6:      	je	0x81d1 <generic_kprobe_filter_arg+0x1e81>
    81c8:      	cmpl	$0xa, %ecx
    81cb:      	jne	0x8b62 <generic_kprobe_filter_arg+0x2812>
    81d1:      	movq	0x8(%rsp), %r8
    81d6:      	cmpq	%rsi, (%r8)
    81d9:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    81df:      	jmp	0x8b80 <generic_kprobe_filter_arg+0x2830>
    81e4:      	movl	0x8(%r12), %edx
    81e9:      	movq	0x8(%rsp), %rax
    81ee:      	movzbl	(%rax), %ecx
    81f1:      	jmp	0x8200 <generic_kprobe_filter_arg+0x1eb0>
    81f3:      	movl	0x8(%r12), %edx
    81f8:      	movq	0x8(%rsp), %rax
    81fd:      	movzwl	(%rax), %ecx
    8200:      	cmpl	%ecx, 0x10(%r12)
    8205:      	setbe	%sil
    8209:      	cmpl	%ecx, 0x14(%r12)
    820e:      	setae	%al
    8211:      	andb	%sil, %al
    8214:      	cmpl	$0x11, %edx
    8217:      	jb	0x9179 <generic_kprobe_filter_arg+0x2e29>
    821d:      	cmpl	%ecx, 0x18(%r12)
    8222:      	setbe	%sil
    8226:      	cmpl	%ecx, 0x1c(%r12)
    822b:      	setae	%dil
    822f:      	andb	%sil, %dil
    8232:      	orb	%dil, %al
    8235:      	cmpl	$0x19, %edx
    8238:      	jb	0x9174 <generic_kprobe_filter_arg+0x2e24>
    823e:      	cmpl	%ecx, 0x20(%r12)
    8243:      	setbe	%sil
    8247:      	cmpl	%ecx, 0x24(%r12)
    824c:      	setae	%dil
    8250:      	andb	%sil, %dil
    8253:      	orb	%dil, %al
    8256:      	cmpl	$0x21, %edx
    8259:      	jb	0x9174 <generic_kprobe_filter_arg+0x2e24>
    825f:      	cmpl	%ecx, 0x28(%r12)
    8264:      	setbe	%dl
    8267:      	cmpl	%ecx, 0x2c(%r12)
    826c:      	setae	%cl
    826f:      	andb	%dl, %cl
    8271:      	orb	%cl, %al
    8273:      	jmp	0x9174 <generic_kprobe_filter_arg+0x2e24>
    8278:      	xorl	%ebx, %ebx
    827a:      	xorl	%r13d, %r13d
    827d:      	movq	%r11, %r15
    8280:      	movl	0x10(%r12,%rbx,4), %eax
    8285:      	movl	%eax, 0x40(%rsp)
    8289:      	movl	$0x1, %eax
    828e:      	leaq	0x40(%rsp), %rsi
    8293:      	movq	(%rip), %rdi            # 0x829a <generic_kprobe_filter_arg+0x1f4a>
    829a:      	callq	*%rax
    829c:      	testq	%rax, %rax
    829f:      	je	0x8c79 <generic_kprobe_filter_arg+0x2929>
    82a5:      	testl	%ebp, %ebp
    82a7:      	movq	0x18(%rsp), %r9
    82ac:      	movq	%r15, %r11
    82af:      	movq	0x68(%rsp), %r15
    82b4:      	je	0x82ff <generic_kprobe_filter_arg+0x1faf>
    82b6:      	movq	0x8(%rsp), %rdx
    82bb:      	xorl	%ecx, %ecx
    82bd:      	jmp	0x82ca <generic_kprobe_filter_arg+0x1f7a>
    82bf:      	incq	%rcx
    82c2:      	incq	%rdx
    82c5:      	cmpq	%rbp, %rcx
    82c8:      	je	0x82ff <generic_kprobe_filter_arg+0x1faf>
    82ca:      	xorl	%esi, %esi
    82cc:      	nopl	(%rax)
    82d0:      	leaq	(%rcx,%rsi), %rdi
    82d4:      	cmpq	%rbp, %rdi
    82d7:      	jae	0x82bf <generic_kprobe_filter_arg+0x1f6f>
    82d9:      	movzbl	(%rax,%rsi), %edi
    82dd:      	testb	%dil, %dil
    82e0:      	je	0x82f7 <generic_kprobe_filter_arg+0x1fa7>
    82e2:      	cmpq	$0x62, %rsi
    82e6:      	ja	0x82bf <generic_kprobe_filter_arg+0x1f6f>
    82e8:      	leaq	0x1(%rsi), %r8
    82ec:      	cmpb	%dil, (%rdx,%rsi)
    82f0:      	movq	%r8, %rsi
    82f3:      	je	0x82d0 <generic_kprobe_filter_arg+0x1f80>
    82f5:      	jmp	0x82bf <generic_kprobe_filter_arg+0x1f6f>
    82f7:      	testl	%ecx, %ecx
    82f9:      	jns	0x8fea <generic_kprobe_filter_arg+0x2c9a>
    82ff:      	leal	0xc(%r13), %eax
    8303:      	cmpl	0x8(%r12), %eax
    8308:      	jae	0x831b <generic_kprobe_filter_arg+0x1fcb>
    830a:      	addl	$0x4, %r13d
    830e:      	incq	%rbx
    8311:      	cmpq	$0x64, %rbx
    8315:      	jne	0x827d <generic_kprobe_filter_arg+0x1f2d>
    831b:      	xorl	%ebx, %ebx
    831d:      	movq	0x10(%rsp), %rdi
    8322:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    8327:      	movzwl	%bp, %eax
    832a:      	cmpl	$0x90, %eax
    832f:      	movq	%r11, 0x20(%rsp)
    8334:      	ja	0x8812 <generic_kprobe_filter_arg+0x24c2>
    833a:      	testw	%bp, %bp
    833d:      	je	0x834f <generic_kprobe_filter_arg+0x1fff>
    833f:      	movl	%ebp, %eax
    8341:      	movl	$0x18, %ecx
    8346:      	cltd
    8347:      	idivl	%ecx
    8349:      	movl	%ebp, %edi
    834b:      	testl	%edx, %edx
    834d:      	je	0x8371 <generic_kprobe_filter_arg+0x2021>
    834f:      	movl	%ebp, %eax
    8351:      	movl	$0x18, %ecx
    8356:      	cltd
    8357:      	idivl	%ecx
    8359:      	shll	$0x3, %eax
    835c:      	leal	(%rax,%rax,2), %eax
    835f:      	addl	$0x18, %eax
    8362:      	movzwl	%ax, %edi
    8365:      	cmpl	$0x90, %edi
    836b:      	ja	0x8826 <generic_kprobe_filter_arg+0x24d6>
    8371:      	movl	%edi, %eax
    8373:      	cltd
    8374:      	idivl	%ecx
    8376:      	decl	%eax
    8378:      	jmp	0x8837 <generic_kprobe_filter_arg+0x24e7>
    837d:      	movq	0x8(%rsp), %rdx
    8382:      	movzbl	(%rdx), %edx
    8385:      	cmpl	%edx, %ecx
    8387:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    838d:      	movl	0x8(%r12), %ecx
    8392:      	cmpl	$0xd, %ecx
    8395:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    839b:      	movl	0x14(%r12), %edx
    83a0:      	cmpl	$0x2, %eax
    83a3:      	jle	0x86f2 <generic_kprobe_filter_arg+0x23a2>
    83a9:      	leal	-0x3(%rax), %esi
    83ac:      	cmpl	$0x2, %esi
    83af:      	jae	0x8c07 <generic_kprobe_filter_arg+0x28b7>
    83b5:      	movq	0x8(%rsp), %rsi
    83ba:      	movzbl	(%rsi), %esi
    83bd:      	cmpl	%esi, %edx
    83bf:      	jne	0x8d12 <generic_kprobe_filter_arg+0x29c2>
    83c5:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    83ca:      	movq	0x8(%rsp), %rdx
    83cf:      	movzwl	(%rdx), %edx
    83d2:      	cmpl	%edx, %ecx
    83d4:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    83da:      	movl	0x8(%r12), %ecx
    83df:      	cmpl	$0xd, %ecx
    83e2:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    83e8:      	movl	0x14(%r12), %edx
    83ed:      	cmpl	$0x2, %eax
    83f0:      	jle	0x8719 <generic_kprobe_filter_arg+0x23c9>
    83f6:      	leal	-0x3(%rax), %esi
    83f9:      	cmpl	$0x2, %esi
    83fc:      	jae	0x8c25 <generic_kprobe_filter_arg+0x28d5>
    8402:      	movq	0x8(%rsp), %rsi
    8407:      	movzwl	(%rsi), %esi
    840a:      	cmpl	%esi, %edx
    840c:      	jne	0x8d5a <generic_kprobe_filter_arg+0x2a0a>
    8412:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    8417:      	testq	%rax, %rax
    841a:      	sete	%al
    841d:      	movq	0x10(%rsp), %rdi
    8422:      	movq	0x18(%rsp), %r9
    8427:      	movq	0x20(%rsp), %r11
    842c:      	movzbl	%al, %ebx
    842f:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    8434:      	movq	0x8(%rsp), %rax
    8439:      	movl	(%rax), %eax
    843b:      	cmpl	%eax, %esi
    843d:      	ja	0x8447 <generic_kprobe_filter_arg+0x20f7>
    843f:      	cmpl	%edx, %eax
    8441:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8447:      	movl	0x8(%r12), %edx
    844c:      	cmpl	$0x11, %edx
    844f:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    8455:      	movl	0x18(%r12), %edi
    845a:      	movl	0x1c(%r12), %esi
    845f:      	cmpl	$0xc, %ecx
    8462:      	ja	0x895e <generic_kprobe_filter_arg+0x260e>
    8468:      	movl	$0x1402, %r8d           # imm = 0x1402
    846e:      	btl	%ecx, %r8d
    8472:      	jae	0x895e <generic_kprobe_filter_arg+0x260e>
    8478:      	cmpl	%eax, %edi
    847a:      	movq	0x10(%rsp), %rdi
    847f:      	jg	0x896f <generic_kprobe_filter_arg+0x261f>
    8485:      	cmpl	%esi, %eax
    8487:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    848d:      	jmp	0x896f <generic_kprobe_filter_arg+0x261f>
    8492:      	movq	0x8(%rsp), %rdx
    8497:      	movl	(%rdx), %edx
    8499:      	cmpl	%edx, %esi
    849b:      	setbe	%sil
    849f:      	cmpl	%eax, %edx
    84a1:      	setbe	%al
    84a4:      	andb	%sil, %al
    84a7:      	movl	0x8(%r12), %esi
    84ac:      	cmpl	$0x11, %esi
    84af:      	jb	0x9179 <generic_kprobe_filter_arg+0x2e29>
    84b5:      	movl	0x18(%r12), %r8d
    84ba:      	movl	0x1c(%r12), %edi
    84bf:      	cmpl	$0xc, %ecx
    84c2:      	ja	0x890d <generic_kprobe_filter_arg+0x25bd>
    84c8:      	movl	$0x1402, %r10d          # imm = 0x1402
    84ce:      	btl	%ecx, %r10d
    84d2:      	jae	0x890d <generic_kprobe_filter_arg+0x25bd>
    84d8:      	cmpl	%edx, %r8d
    84db:      	setle	%r8b
    84df:      	cmpl	%edi, %edx
    84e1:      	setle	%dil
    84e5:      	jmp	0x891a <generic_kprobe_filter_arg+0x25ca>
    84ea:      	cmpq	%rdx, %r8
    84ed:      	setbe	%r8b
    84f1:      	cmpq	%rdi, %rdx
    84f4:      	setbe	%dil
    84f8:      	andb	%r8b, %dil
    84fb:      	orb	%dil, %al
    84fe:      	cmpl	$0x29, %esi
    8501:      	jb	0x9174 <generic_kprobe_filter_arg+0x2e24>
    8507:      	movq	0x30(%r12), %r8
    850c:      	movq	0x38(%r12), %rdi
    8511:      	cmpl	$0xc, %ecx
    8514:      	je	0x851f <generic_kprobe_filter_arg+0x21cf>
    8516:      	cmpl	$0xa, %ecx
    8519:      	jne	0x8a00 <generic_kprobe_filter_arg+0x26b0>
    851f:      	cmpq	%rdx, %r8
    8522:      	setle	%r8b
    8526:      	cmpq	%rdi, %rdx
    8529:      	setle	%dil
    852d:      	jmp	0x8a0e <generic_kprobe_filter_arg+0x26be>
    8532:      	cmpq	%rax, %rdi
    8535:      	movq	0x10(%rsp), %rdi
    853a:      	ja	0x8545 <generic_kprobe_filter_arg+0x21f5>
    853c:      	cmpq	%rsi, %rax
    853f:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8545:      	cmpl	$0x29, %edx
    8548:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    854e:      	movq	0x30(%r12), %rdi
    8553:      	movq	0x38(%r12), %rsi
    8558:      	cmpl	$0xc, %ecx
    855b:      	je	0x8566 <generic_kprobe_filter_arg+0x2216>
    855d:      	cmpl	$0xa, %ecx
    8560:      	jne	0x8b17 <generic_kprobe_filter_arg+0x27c7>
    8566:      	cmpq	%rax, %rdi
    8569:      	movq	0x10(%rsp), %rdi
    856e:      	jg	0x8b2a <generic_kprobe_filter_arg+0x27da>
    8574:      	cmpq	%rsi, %rax
    8577:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    857d:      	jmp	0x8b2a <generic_kprobe_filter_arg+0x27da>
    8582:      	xorl	%ebx, %ebx
    8584:      	cmpl	$0x29, %ecx
    8587:      	jne	0x8592 <generic_kprobe_filter_arg+0x2242>
    8589:      	testq	%rdx, %rdx
    858c:      	je	0x8592 <generic_kprobe_filter_arg+0x2242>
    858e:      	movzbl	0x3a(%rdx), %ebx
    8592:      	cmpl	$0x29, %ecx
    8595:      	je	0x85a0 <generic_kprobe_filter_arg+0x2250>
    8597:      	cmpl	$0x7, %ecx
    859a:      	jne	0x8a43 <generic_kprobe_filter_arg+0x26f3>
    85a0:      	movq	%r11, %r13
    85a3:      	movzbl	0x10(%r12), %eax
    85a9:      	movl	%eax, 0x34(%rsp)
    85ad:      	movl	$0x1, %eax
    85b2:      	movq	(%rip), %rdi            # 0x85b9 <generic_kprobe_filter_arg+0x2269>
    85b9:      	leaq	0x34(%rsp), %rsi
    85be:      	callq	*%rax
    85c0:      	testq	%rax, %rax
    85c3:      	je	0x85e1 <generic_kprobe_filter_arg+0x2291>
    85c5:      	movq	%rax, %rdi
    85c8:      	movl	%ebx, %eax
    85ca:      	movq	%rax, 0x80(%rsp)
    85d2:      	movl	$0x1, %eax
    85d7:      	movq	0x38(%rsp), %rsi
    85dc:      	jmp	0x7f7f <generic_kprobe_filter_arg+0x1c2f>
    85e1:      	xorl	%ebx, %ebx
    85e3:      	movq	0x10(%rsp), %rdi
    85e8:      	movq	0x18(%rsp), %r9
    85ed:      	movq	%r13, %r11
    85f0:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    85f5:      	movq	0x8(%rsp), %rsi
    85fa:      	cmpl	%edx, (%rsi)
    85fc:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8602:      	jmp	0x8611 <generic_kprobe_filter_arg+0x22c1>
    8604:      	movq	0x8(%rsp), %rsi
    8609:      	cmpl	%edx, (%rsi)
    860b:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8611:      	movl	0x8(%r12), %edx
    8616:      	cmpl	$0xd, %edx
    8619:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    861f:      	movl	0x14(%r12), %esi
    8624:      	cmpl	$0x2, %eax
    8627:      	jle	0x8648 <generic_kprobe_filter_arg+0x22f8>
    8629:      	leal	-0x3(%rax), %edi
    862c:      	cmpl	$0x2, %edi
    862f:      	jae	0x8682 <generic_kprobe_filter_arg+0x2332>
    8631:      	movq	0x8(%rsp), %rdi
    8636:      	cmpl	%esi, (%rdi)
    8638:      	movq	0x10(%rsp), %rdi
    863d:      	jne	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    8643:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    8648:      	cmpl	$0x1, %eax
    864b:      	je	0x86a3 <generic_kprobe_filter_arg+0x2353>
    864d:      	cmpl	$0x2, %eax
    8650:      	jne	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    8656:      	cmpl	$0xc, %ecx
    8659:      	ja	0x8e4e <generic_kprobe_filter_arg+0x2afe>
    865f:      	movl	$0x1402, %r8d           # imm = 0x1402
    8665:      	btl	%ecx, %r8d
    8669:      	jae	0x8e4e <generic_kprobe_filter_arg+0x2afe>
    866f:      	movq	0x8(%rsp), %r8
    8674:      	cmpl	%esi, (%r8)
    8677:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    867d:      	jmp	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    8682:      	cmpl	$0xc, %eax
    8685:      	movq	0x10(%rsp), %rdi
    868a:      	jne	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    8690:      	movq	0x8(%rsp), %r8
    8695:      	testl	%esi, (%r8)
    8698:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    869e:      	jmp	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    86a3:      	cmpl	$0xc, %ecx
    86a6:      	ja	0x8e3e <generic_kprobe_filter_arg+0x2aee>
    86ac:      	movl	$0x1402, %r8d           # imm = 0x1402
    86b2:      	btl	%ecx, %r8d
    86b6:      	jae	0x8e3e <generic_kprobe_filter_arg+0x2aee>
    86bc:      	movq	0x8(%rsp), %r8
    86c1:      	cmpl	%esi, (%r8)
    86c4:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    86ca:      	jmp	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    86cf:      	xorl	%ebx, %ebx
    86d1:      	movq	0x18(%rsp), %r9
    86d6:      	movq	%r15, %r11
    86d9:      	movq	0x68(%rsp), %r15
    86de:      	jmp	0x89ba <generic_kprobe_filter_arg+0x266a>
    86e3:      	xorl	%ebx, %ebx
    86e5:      	movq	%r15, %r11
    86e8:      	movq	0x68(%rsp), %r15
    86ed:      	jmp	0x89dd <generic_kprobe_filter_arg+0x268d>
    86f2:      	cmpl	$0x1, %eax
    86f5:      	je	0x8d02 <generic_kprobe_filter_arg+0x29b2>
    86fb:      	cmpl	$0x2, %eax
    86fe:      	jne	0x8d12 <generic_kprobe_filter_arg+0x29c2>
    8704:      	movq	0x8(%rsp), %rsi
    8709:      	movzbl	(%rsi), %esi
    870c:      	cmpl	%esi, %edx
    870e:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8714:      	jmp	0x8d12 <generic_kprobe_filter_arg+0x29c2>
    8719:      	cmpl	$0x1, %eax
    871c:      	je	0x8d4a <generic_kprobe_filter_arg+0x29fa>
    8722:      	cmpl	$0x2, %eax
    8725:      	jne	0x8d5a <generic_kprobe_filter_arg+0x2a0a>
    872b:      	movq	0x8(%rsp), %rsi
    8730:      	movzwl	(%rsi), %esi
    8733:      	cmpl	%esi, %edx
    8735:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    873b:      	jmp	0x8d5a <generic_kprobe_filter_arg+0x2a0a>
    8740:      	movq	0x28(%rsp), %rax
    8745:      	movw	%bp, (%rax)
    8748:      	leaq	0x2(%rax), %rdi
    874c:      	movl	$0x4, %eax
    8751:      	movl	%ebp, %esi
    8753:      	callq	*%rax
    8755:      	movq	0x98(%rsp), %rsi
    875d:      	subl	%ebp, %esi
    875f:      	jbe	0x8783 <generic_kprobe_filter_arg+0x2433>
    8761:      	movq	0x28(%rsp), %rax
    8766:      	leaq	(%rax,%rbp), %rdi
    876a:      	addq	$0x2, %rdi
    876e:      	andl	$0xfff, %esi            # imm = 0xFFF
    8774:      	movl	$0x4, %eax
    8779:      	movq	0xa8(%rsp), %rdx
    8781:      	callq	*%rax
    8783:      	movl	0xa0(%rsp), %eax
    878a:      	movl	%eax, 0x40(%rsp)
    878e:      	cmpl	$0x3, %ebx
    8791:      	jg	0x87d2 <generic_kprobe_filter_arg+0x2482>
    8793:      	cmpl	$0x1, %ebx
    8796:      	movq	0x10(%rsp), %rdi
    879b:      	movq	0x18(%rsp), %r9
    87a0:      	movq	0x20(%rsp), %r11
    87a5:      	jg	0x8c92 <generic_kprobe_filter_arg+0x2942>
    87ab:      	testl	%ebx, %ebx
    87ad:      	je	0x90bf <generic_kprobe_filter_arg+0x2d6f>
    87b3:      	cmpl	$0x1, %ebx
    87b6:      	jne	0x6c93 <generic_kprobe_filter_arg+0x943>
    87bc:      	movl	$0x1, %eax
    87c1:      	leaq	0x40(%rsp), %rsi
    87c6:      	movq	(%rip), %rdi            # 0x87cd <generic_kprobe_filter_arg+0x247d>
    87cd:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    87d2:      	cmpl	$0x5, %ebx
    87d5:      	movq	0x10(%rsp), %rdi
    87da:      	movq	0x18(%rsp), %r9
    87df:      	movq	0x20(%rsp), %r11
    87e4:      	jg	0x8cba <generic_kprobe_filter_arg+0x296a>
    87ea:      	cmpl	$0x4, %ebx
    87ed:      	je	0x90d2 <generic_kprobe_filter_arg+0x2d82>
    87f3:      	cmpl	$0x5, %ebx
    87f6:      	jne	0x6c93 <generic_kprobe_filter_arg+0x943>
    87fc:      	movl	$0x1, %eax
    8801:      	leaq	0x40(%rsp), %rsi
    8806:      	movq	(%rip), %rdi            # 0x880d <generic_kprobe_filter_arg+0x24bd>
    880d:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    8812:      	cmpl	$0x101, %eax            # imm = 0x101
    8817:      	movl	$0x100, %edi            # imm = 0x100
    881c:      	movl	$0x1fe, %eax            # imm = 0x1FE
    8821:      	cmovael	%eax, %edi
    8824:      	movl	%edi, %eax
    8826:      	movzwl	%ax, %ecx
    8829:      	xorl	%eax, %eax
    882b:      	cmpl	$0x100, %ecx            # imm = 0x100
    8831:      	sete	%al
    8834:      	xorl	$0x7, %eax
    8837:      	movl	%eax, %ecx
    8839:      	andl	$0xf, %ecx
    883c:      	movl	0x10(%r12,%rcx,4), %ecx
    8841:      	cmpl	$-0x1, %ecx
    8844:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    884a:      	movl	%ecx, 0x98(%rsp)
    8851:      	movq	%rdi, 0xa0(%rsp)
    8859:      	movl	%eax, 0x70(%rsp)
    885d:      	movq	%rsi, 0x8(%rsp)
    8862:      	movl	$0x1, %eax
    8867:      	movq	(%rip), %rdi            # 0x886e <generic_kprobe_filter_arg+0x251e>
    886e:      	movq	0x38(%rsp), %rbx
    8873:      	movq	%rbx, %rsi
    8876:      	callq	*%rax
    8878:      	movq	%rax, 0x28(%rsp)
    887d:      	movl	$0x1, %eax
    8882:      	movq	(%rip), %rdi            # 0x8889 <generic_kprobe_filter_arg+0x2539>
    8889:      	movq	%rbx, %rsi
    888c:      	callq	*%rax
    888e:      	cmpq	$0x0, 0x28(%rsp)
    8894:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    889a:      	movl	$0x0, %ebx
    889f:      	testq	%rax, %rax
    88a2:      	movq	0x10(%rsp), %rdi
    88a7:      	movq	0x18(%rsp), %r9
    88ac:      	movq	0x20(%rsp), %r11
    88b1:      	je	0x95e5 <generic_kprobe_filter_arg+0x3295>
    88b7:      	movq	%rax, %r13
    88ba:      	movl	0x70(%rsp), %ebx
    88be:      	cmpl	$0x5, %ebx
    88c1:      	jg	0x900b <generic_kprobe_filter_arg+0x2cbb>
    88c7:      	movq	0x28(%rsp), %rax
    88cc:      	movb	%bpl, (%rax)
    88cf:      	leaq	0x1(%rax), %rdi
    88d3:      	movl	$0x4, %eax
    88d8:      	movq	0x8(%rsp), %rdx
    88dd:      	movl	%ebp, %esi
    88df:      	callq	*%rax
    88e1:      	movq	0xa0(%rsp), %rsi
    88e9:      	subl	%ebp, %esi
    88eb:      	jbe	0x904e <generic_kprobe_filter_arg+0x2cfe>
    88f1:      	movq	0x28(%rsp), %rax
    88f6:      	leaq	(%rax,%rbp), %rdi
    88fa:      	incq	%rdi
    88fd:      	andl	$0xfff, %esi            # imm = 0xFFF
    8903:      	movl	$0x4, %eax
    8908:      	jmp	0x9049 <generic_kprobe_filter_arg+0x2cf9>
    890d:      	cmpl	%edx, %r8d
    8910:      	setbe	%r8b
    8914:      	cmpl	%edi, %edx
    8916:      	setbe	%dil
    891a:      	andb	%r8b, %dil
    891d:      	orb	%dil, %al
    8920:      	cmpl	$0x19, %esi
    8923:      	jb	0x9174 <generic_kprobe_filter_arg+0x2e24>
    8929:      	movl	0x20(%r12), %r8d
    892e:      	movl	0x24(%r12), %edi
    8933:      	cmpl	$0xc, %ecx
    8936:      	ja	0x8d9e <generic_kprobe_filter_arg+0x2a4e>
    893c:      	movl	$0x1402, %r10d          # imm = 0x1402
    8942:      	btl	%ecx, %r10d
    8946:      	jae	0x8d9e <generic_kprobe_filter_arg+0x2a4e>
    894c:      	cmpl	%edx, %r8d
    894f:      	setle	%r8b
    8953:      	cmpl	%edi, %edx
    8955:      	setle	%dil
    8959:      	jmp	0x8dab <generic_kprobe_filter_arg+0x2a5b>
    895e:      	cmpl	%eax, %edi
    8960:      	movq	0x10(%rsp), %rdi
    8965:      	ja	0x896f <generic_kprobe_filter_arg+0x261f>
    8967:      	cmpl	%esi, %eax
    8969:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    896f:      	cmpl	$0x19, %edx
    8972:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    8978:      	movl	0x20(%r12), %edi
    897d:      	movl	0x24(%r12), %esi
    8982:      	cmpl	$0xc, %ecx
    8985:      	ja	0x8dec <generic_kprobe_filter_arg+0x2a9c>
    898b:      	movl	$0x1402, %r8d           # imm = 0x1402
    8991:      	btl	%ecx, %r8d
    8995:      	jae	0x8dec <generic_kprobe_filter_arg+0x2a9c>
    899b:      	cmpl	%eax, %edi
    899d:      	movq	0x10(%rsp), %rdi
    89a2:      	jg	0x8dfd <generic_kprobe_filter_arg+0x2aad>
    89a8:      	cmpl	%esi, %eax
    89aa:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    89b0:      	jmp	0x8dfd <generic_kprobe_filter_arg+0x2aad>
    89b5:      	movl	$0x1, %ebx
    89ba:      	movq	0x78(%rsp), %r13
    89bf:      	movq	0x10(%rsp), %rdi
    89c4:      	movl	0x4(%r12), %eax
    89c9:      	cmpq	$0x25, %rax
    89cd:      	jbe	0x9326 <generic_kprobe_filter_arg+0x2fd6>
    89d3:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    89d8:      	movl	$0x1, %ebx
    89dd:      	movq	0x78(%rsp), %r13
    89e2:      	movq	0x10(%rsp), %rdi
    89e7:      	movq	0x18(%rsp), %r9
    89ec:      	movl	0x4(%r12), %eax
    89f1:      	cmpq	$0x25, %rax
    89f5:      	jbe	0x9326 <generic_kprobe_filter_arg+0x2fd6>
    89fb:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    8a00:      	cmpq	%rdx, %r8
    8a03:      	setbe	%r8b
    8a07:      	cmpq	%rdi, %rdx
    8a0a:      	setbe	%dil
    8a0e:      	andb	%r8b, %dil
    8a11:      	orb	%dil, %al
    8a14:      	cmpl	$0x39, %esi
    8a17:      	jb	0x9174 <generic_kprobe_filter_arg+0x2e24>
    8a1d:      	movq	0x40(%r12), %rdi
    8a22:      	movq	0x48(%r12), %rsi
    8a27:      	cmpl	$0xc, %ecx
    8a2a:      	je	0x8a35 <generic_kprobe_filter_arg+0x26e5>
    8a2c:      	cmpl	$0xa, %ecx
    8a2f:      	jne	0x8f15 <generic_kprobe_filter_arg+0x2bc5>
    8a35:      	cmpq	%rdx, %rdi
    8a38:      	setle	%cl
    8a3b:      	cmpq	%rsi, %rdx
    8a3e:      	jmp	0x8de4 <generic_kprobe_filter_arg+0x2a94>
    8a43:      	xorl	%ebx, %ebx
    8a45:      	jmp	0x6602 <generic_kprobe_filter_arg+0x2b2>
    8a4a:      	movq	0x28(%rsp), %rax
    8a4f:      	movw	%bp, (%rax)
    8a52:      	leaq	0x2(%rax), %rdi
    8a56:      	movl	$0x4, %eax
    8a5b:      	movq	0x8(%rsp), %rdx
    8a60:      	movl	%ebp, %esi
    8a62:      	callq	*%rax
    8a64:      	movq	0x98(%rsp), %rsi
    8a6c:      	subl	%ebp, %esi
    8a6e:      	jbe	0x8a92 <generic_kprobe_filter_arg+0x2742>
    8a70:      	movq	0x28(%rsp), %rax
    8a75:      	leaq	(%rax,%rbp), %rdi
    8a79:      	addq	$0x2, %rdi
    8a7d:      	andl	$0xfff, %esi            # imm = 0xFFF
    8a83:      	movl	$0x4, %eax
    8a88:      	movq	0xa8(%rsp), %rdx
    8a90:      	callq	*%rax
    8a92:      	movl	0xa0(%rsp), %eax
    8a99:      	movl	%eax, 0x40(%rsp)
    8a9d:      	cmpl	$0x3, %ebx
    8aa0:      	jg	0x8adc <generic_kprobe_filter_arg+0x278c>
    8aa2:      	cmpl	$0x1, %ebx
    8aa5:      	movq	0x18(%rsp), %r9
    8aaa:      	movq	0x20(%rsp), %r11
    8aaf:      	jg	0x8f23 <generic_kprobe_filter_arg+0x2bd3>
    8ab5:      	testl	%ebx, %ebx
    8ab7:      	je	0x929c <generic_kprobe_filter_arg+0x2f4c>
    8abd:      	cmpl	$0x1, %ebx
    8ac0:      	jne	0x933f <generic_kprobe_filter_arg+0x2fef>
    8ac6:      	movl	$0x1, %eax
    8acb:      	leaq	0x40(%rsp), %rsi
    8ad0:      	movq	(%rip), %rdi            # 0x8ad7 <generic_kprobe_filter_arg+0x2787>
    8ad7:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    8adc:      	cmpl	$0x5, %ebx
    8adf:      	movq	0x18(%rsp), %r9
    8ae4:      	movq	0x20(%rsp), %r11
    8ae9:      	jg	0x8f4b <generic_kprobe_filter_arg+0x2bfb>
    8aef:      	cmpl	$0x4, %ebx
    8af2:      	je	0x92af <generic_kprobe_filter_arg+0x2f5f>
    8af8:      	cmpl	$0x5, %ebx
    8afb:      	jne	0x933f <generic_kprobe_filter_arg+0x2fef>
    8b01:      	movl	$0x1, %eax
    8b06:      	leaq	0x40(%rsp), %rsi
    8b0b:      	movq	(%rip), %rdi            # 0x8b12 <generic_kprobe_filter_arg+0x27c2>
    8b12:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    8b17:      	cmpq	%rax, %rdi
    8b1a:      	movq	0x10(%rsp), %rdi
    8b1f:      	ja	0x8b2a <generic_kprobe_filter_arg+0x27da>
    8b21:      	cmpq	%rsi, %rax
    8b24:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8b2a:      	cmpl	$0x39, %edx
    8b2d:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    8b33:      	movq	0x40(%r12), %rsi
    8b38:      	movq	0x48(%r12), %rdx
    8b3d:      	cmpl	$0xc, %ecx
    8b40:      	je	0x8b4b <generic_kprobe_filter_arg+0x27fb>
    8b42:      	cmpl	$0xa, %ecx
    8b45:      	jne	0x8f73 <generic_kprobe_filter_arg+0x2c23>
    8b4b:      	cmpq	%rax, %rsi
    8b4e:      	jg	0x645d <generic_kprobe_filter_arg+0x10d>
    8b54:      	cmpq	%rdx, %rax
    8b57:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8b5d:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    8b62:      	movq	0x8(%rsp), %r8
    8b67:      	cmpq	%rsi, (%r8)
    8b6a:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8b70:      	jmp	0x8b80 <generic_kprobe_filter_arg+0x2830>
    8b72:      	movq	0x8(%rsp), %r8
    8b77:      	cmpq	%rsi, (%r8)
    8b7a:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8b80:      	cmpl	$0x19, %edx
    8b83:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    8b89:      	movq	0x20(%r12), %rsi
    8b8e:      	cmpl	$0x2, %eax
    8b91:      	jle	0x8bb3 <generic_kprobe_filter_arg+0x2863>
    8b93:      	leal	-0x3(%rax), %edi
    8b96:      	cmpl	$0x2, %edi
    8b99:      	jae	0x8be6 <generic_kprobe_filter_arg+0x2896>
    8b9b:      	movq	0x8(%rsp), %rdi
    8ba0:      	cmpq	%rsi, (%rdi)
    8ba3:      	movq	0x10(%rsp), %rdi
    8ba8:      	jne	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    8bae:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    8bb3:      	cmpl	$0x1, %eax
    8bb6:      	je	0x8c58 <generic_kprobe_filter_arg+0x2908>
    8bbc:      	cmpl	$0x2, %eax
    8bbf:      	jne	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    8bc5:      	cmpl	$0xc, %ecx
    8bc8:      	je	0x8bd3 <generic_kprobe_filter_arg+0x2883>
    8bca:      	cmpl	$0xa, %ecx
    8bcd:      	jne	0x9196 <generic_kprobe_filter_arg+0x2e46>
    8bd3:      	movq	0x8(%rsp), %r8
    8bd8:      	cmpq	%rsi, (%r8)
    8bdb:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8be1:      	jmp	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    8be6:      	cmpl	$0xc, %eax
    8be9:      	movq	0x10(%rsp), %rdi
    8bee:      	jne	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    8bf4:      	movq	0x8(%rsp), %r8
    8bf9:      	testq	%rsi, (%r8)
    8bfc:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8c02:      	jmp	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    8c07:      	cmpl	$0xc, %eax
    8c0a:      	jne	0x8d12 <generic_kprobe_filter_arg+0x29c2>
    8c10:      	movq	0x8(%rsp), %rsi
    8c15:      	movzbl	(%rsi), %esi
    8c18:      	testl	%esi, %edx
    8c1a:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8c20:      	jmp	0x8d12 <generic_kprobe_filter_arg+0x29c2>
    8c25:      	cmpl	$0xc, %eax
    8c28:      	jne	0x8d5a <generic_kprobe_filter_arg+0x2a0a>
    8c2e:      	movq	0x8(%rsp), %rsi
    8c33:      	movzwl	(%rsi), %esi
    8c36:      	testl	%esi, %edx
    8c38:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8c3e:      	jmp	0x8d5a <generic_kprobe_filter_arg+0x2a0a>
    8c43:      	movq	0x10(%rsp), %rdi
    8c48:      	movq	0x18(%rsp), %r9
    8c4d:      	movq	%rbp, %r11
    8c50:      	movzbl	%cl, %ebx
    8c53:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    8c58:      	cmpl	$0xc, %ecx
    8c5b:      	je	0x8c66 <generic_kprobe_filter_arg+0x2916>
    8c5d:      	cmpl	$0xa, %ecx
    8c60:      	jne	0x9186 <generic_kprobe_filter_arg+0x2e36>
    8c66:      	movq	0x8(%rsp), %r8
    8c6b:      	cmpq	%rsi, (%r8)
    8c6e:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8c74:      	jmp	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    8c79:      	xorl	%ebx, %ebx
    8c7b:      	movq	0x18(%rsp), %r9
    8c80:      	movq	%r15, %r11
    8c83:      	movq	0x68(%rsp), %r15
    8c88:      	movq	0x10(%rsp), %rdi
    8c8d:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    8c92:      	cmpl	$0x2, %ebx
    8c95:      	je	0x90e5 <generic_kprobe_filter_arg+0x2d95>
    8c9b:      	cmpl	$0x3, %ebx
    8c9e:      	jne	0x6c93 <generic_kprobe_filter_arg+0x943>
    8ca4:      	movl	$0x1, %eax
    8ca9:      	leaq	0x40(%rsp), %rsi
    8cae:      	movq	(%rip), %rdi            # 0x8cb5 <generic_kprobe_filter_arg+0x2965>
    8cb5:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    8cba:      	cmpl	$0x6, %ebx
    8cbd:      	je	0x90f8 <generic_kprobe_filter_arg+0x2da8>
    8cc3:      	cmpl	$0x7, %ebx
    8cc6:      	jne	0x6c93 <generic_kprobe_filter_arg+0x943>
    8ccc:      	movl	$0x1, %eax
    8cd1:      	leaq	0x40(%rsp), %rsi
    8cd6:      	movq	(%rip), %rdi            # 0x8cdd <generic_kprobe_filter_arg+0x298d>
    8cdd:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    8ce2:      	xorl	%ebx, %ebx
    8ce4:      	jmp	0x8ceb <generic_kprobe_filter_arg+0x299b>
    8ce6:      	movl	$0x1, %ebx
    8ceb:      	movq	0x10(%rsp), %rdi
    8cf0:      	movq	0x18(%rsp), %r9
    8cf5:      	movq	%r15, %r11
    8cf8:      	movq	0x68(%rsp), %r15
    8cfd:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    8d02:      	movq	0x8(%rsp), %rsi
    8d07:      	movzbl	(%rsi), %esi
    8d0a:      	cmpl	%esi, %edx
    8d0c:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8d12:      	cmpl	$0x11, %ecx
    8d15:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    8d1b:      	movl	0x18(%r12), %edx
    8d20:      	cmpl	$0x2, %eax
    8d23:      	jle	0x8f9c <generic_kprobe_filter_arg+0x2c4c>
    8d29:      	leal	-0x3(%rax), %esi
    8d2c:      	cmpl	$0x2, %esi
    8d2f:      	jae	0x922a <generic_kprobe_filter_arg+0x2eda>
    8d35:      	movq	0x8(%rsp), %rsi
    8d3a:      	movzbl	(%rsi), %esi
    8d3d:      	cmpl	%esi, %edx
    8d3f:      	jne	0x93ac <generic_kprobe_filter_arg+0x305c>
    8d45:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    8d4a:      	movq	0x8(%rsp), %rsi
    8d4f:      	movzwl	(%rsi), %esi
    8d52:      	cmpl	%esi, %edx
    8d54:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8d5a:      	cmpl	$0x11, %ecx
    8d5d:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    8d63:      	movl	0x18(%r12), %edx
    8d68:      	cmpl	$0x2, %eax
    8d6b:      	jle	0x8fc3 <generic_kprobe_filter_arg+0x2c73>
    8d71:      	leal	-0x3(%rax), %esi
    8d74:      	cmpl	$0x2, %esi
    8d77:      	jae	0x9248 <generic_kprobe_filter_arg+0x2ef8>
    8d7d:      	movq	0x8(%rsp), %rsi
    8d82:      	movzwl	(%rsi), %esi
    8d85:      	cmpl	%esi, %edx
    8d87:      	jne	0x93fb <generic_kprobe_filter_arg+0x30ab>
    8d8d:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    8d92:      	xorl	%ebx, %ebx
    8d94:      	movq	0x68(%rsp), %r15
    8d99:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    8d9e:      	cmpl	%edx, %r8d
    8da1:      	setbe	%r8b
    8da5:      	cmpl	%edi, %edx
    8da7:      	setbe	%dil
    8dab:      	andb	%r8b, %dil
    8dae:      	orb	%dil, %al
    8db1:      	cmpl	$0x21, %esi
    8db4:      	jb	0x9174 <generic_kprobe_filter_arg+0x2e24>
    8dba:      	movl	0x28(%r12), %edi
    8dbf:      	movl	0x2c(%r12), %esi
    8dc4:      	cmpl	$0xc, %ecx
    8dc7:      	ja	0x9166 <generic_kprobe_filter_arg+0x2e16>
    8dcd:      	movl	$0x1402, %r8d           # imm = 0x1402
    8dd3:      	btl	%ecx, %r8d
    8dd7:      	jae	0x9166 <generic_kprobe_filter_arg+0x2e16>
    8ddd:      	cmpl	%edx, %edi
    8ddf:      	setle	%cl
    8de2:      	cmpl	%esi, %edx
    8de4:      	setle	%dl
    8de7:      	jmp	0x9170 <generic_kprobe_filter_arg+0x2e20>
    8dec:      	cmpl	%eax, %edi
    8dee:      	movq	0x10(%rsp), %rdi
    8df3:      	ja	0x8dfd <generic_kprobe_filter_arg+0x2aad>
    8df5:      	cmpl	%esi, %eax
    8df7:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8dfd:      	cmpl	$0x21, %edx
    8e00:      	jb	0x645d <generic_kprobe_filter_arg+0x10d>
    8e06:      	movl	0x28(%r12), %esi
    8e0b:      	movl	0x2c(%r12), %edx
    8e10:      	cmpl	$0xc, %ecx
    8e13:      	ja	0x9266 <generic_kprobe_filter_arg+0x2f16>
    8e19:      	movl	$0x1402, %r8d           # imm = 0x1402
    8e1f:      	btl	%ecx, %r8d
    8e23:      	jae	0x9266 <generic_kprobe_filter_arg+0x2f16>
    8e29:      	cmpl	%eax, %esi
    8e2b:      	jg	0x645d <generic_kprobe_filter_arg+0x10d>
    8e31:      	cmpl	%edx, %eax
    8e33:      	jle	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8e39:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    8e3e:      	movq	0x8(%rsp), %r8
    8e43:      	cmpl	%esi, (%r8)
    8e46:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8e4c:      	jmp	0x8e5c <generic_kprobe_filter_arg+0x2b0c>
    8e4e:      	movq	0x8(%rsp), %r8
    8e53:      	cmpl	%esi, (%r8)
    8e56:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8e5c:      	cmpl	$0x11, %edx
    8e5f:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    8e65:      	movl	0x18(%r12), %esi
    8e6a:      	cmpl	$0x2, %eax
    8e6d:      	jle	0x8e8e <generic_kprobe_filter_arg+0x2b3e>
    8e6f:      	leal	-0x3(%rax), %edi
    8e72:      	cmpl	$0x2, %edi
    8e75:      	jae	0x8ec8 <generic_kprobe_filter_arg+0x2b78>
    8e77:      	movq	0x8(%rsp), %rdi
    8e7c:      	cmpl	%esi, (%rdi)
    8e7e:      	movq	0x10(%rsp), %rdi
    8e83:      	jne	0x9463 <generic_kprobe_filter_arg+0x3113>
    8e89:      	jmp	0x9571 <generic_kprobe_filter_arg+0x3221>
    8e8e:      	cmpl	$0x1, %eax
    8e91:      	je	0x8ee9 <generic_kprobe_filter_arg+0x2b99>
    8e93:      	cmpl	$0x2, %eax
    8e96:      	jne	0x9463 <generic_kprobe_filter_arg+0x3113>
    8e9c:      	cmpl	$0xc, %ecx
    8e9f:      	ja	0x9455 <generic_kprobe_filter_arg+0x3105>
    8ea5:      	movl	$0x1402, %r8d           # imm = 0x1402
    8eab:      	btl	%ecx, %r8d
    8eaf:      	jae	0x9455 <generic_kprobe_filter_arg+0x3105>
    8eb5:      	movq	0x8(%rsp), %r8
    8eba:      	cmpl	%esi, (%r8)
    8ebd:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8ec3:      	jmp	0x9463 <generic_kprobe_filter_arg+0x3113>
    8ec8:      	cmpl	$0xc, %eax
    8ecb:      	movq	0x10(%rsp), %rdi
    8ed0:      	jne	0x9463 <generic_kprobe_filter_arg+0x3113>
    8ed6:      	movq	0x8(%rsp), %r8
    8edb:      	testl	%esi, (%r8)
    8ede:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8ee4:      	jmp	0x9463 <generic_kprobe_filter_arg+0x3113>
    8ee9:      	cmpl	$0xc, %ecx
    8eec:      	ja	0x9445 <generic_kprobe_filter_arg+0x30f5>
    8ef2:      	movl	$0x1402, %r8d           # imm = 0x1402
    8ef8:      	btl	%ecx, %r8d
    8efc:      	jae	0x9445 <generic_kprobe_filter_arg+0x30f5>
    8f02:      	movq	0x8(%rsp), %r8
    8f07:      	cmpl	%esi, (%r8)
    8f0a:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8f10:      	jmp	0x9463 <generic_kprobe_filter_arg+0x3113>
    8f15:      	cmpq	%rdx, %rdi
    8f18:      	setbe	%cl
    8f1b:      	cmpq	%rsi, %rdx
    8f1e:      	jmp	0x916d <generic_kprobe_filter_arg+0x2e1d>
    8f23:      	cmpl	$0x2, %ebx
    8f26:      	je	0x92c2 <generic_kprobe_filter_arg+0x2f72>
    8f2c:      	cmpl	$0x3, %ebx
    8f2f:      	jne	0x933f <generic_kprobe_filter_arg+0x2fef>
    8f35:      	movl	$0x1, %eax
    8f3a:      	leaq	0x40(%rsp), %rsi
    8f3f:      	movq	(%rip), %rdi            # 0x8f46 <generic_kprobe_filter_arg+0x2bf6>
    8f46:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    8f4b:      	cmpl	$0x6, %ebx
    8f4e:      	je	0x92d5 <generic_kprobe_filter_arg+0x2f85>
    8f54:      	cmpl	$0x7, %ebx
    8f57:      	jne	0x933f <generic_kprobe_filter_arg+0x2fef>
    8f5d:      	movl	$0x1, %eax
    8f62:      	leaq	0x40(%rsp), %rsi
    8f67:      	movq	(%rip), %rdi            # 0x8f6e <generic_kprobe_filter_arg+0x2c1e>
    8f6e:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    8f73:      	cmpq	%rax, %rsi
    8f76:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    8f7c:      	cmpq	%rdx, %rax
    8f7f:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8f85:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    8f8a:      	movq	0x10(%rsp), %rdi
    8f8f:      	movq	0x18(%rsp), %r9
    8f94:      	movq	%r13, %r11
    8f97:      	jmp	0x65ff <generic_kprobe_filter_arg+0x2af>
    8f9c:      	cmpl	$0x1, %eax
    8f9f:      	je	0x939c <generic_kprobe_filter_arg+0x304c>
    8fa5:      	cmpl	$0x2, %eax
    8fa8:      	jne	0x93ac <generic_kprobe_filter_arg+0x305c>
    8fae:      	movq	0x8(%rsp), %rsi
    8fb3:      	movzbl	(%rsi), %esi
    8fb6:      	cmpl	%esi, %edx
    8fb8:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8fbe:      	jmp	0x93ac <generic_kprobe_filter_arg+0x305c>
    8fc3:      	cmpl	$0x1, %eax
    8fc6:      	je	0x93eb <generic_kprobe_filter_arg+0x309b>
    8fcc:      	cmpl	$0x2, %eax
    8fcf:      	jne	0x93fb <generic_kprobe_filter_arg+0x30ab>
    8fd5:      	movq	0x8(%rsp), %rsi
    8fda:      	movzwl	(%rsi), %esi
    8fdd:      	cmpl	%esi, %edx
    8fdf:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    8fe5:      	jmp	0x93fb <generic_kprobe_filter_arg+0x30ab>
    8fea:      	movl	$0x1, %ebx
    8fef:      	movq	0x10(%rsp), %rdi
    8ff4:      	jmp	0x95e5 <generic_kprobe_filter_arg+0x3295>
    8ff9:      	movq	0x10(%rsp), %rdi
    8ffe:      	movq	0x18(%rsp), %r9
    9003:      	movq	%rbp, %r11
    9006:      	jmp	0x65ff <generic_kprobe_filter_arg+0x2af>
    900b:      	movq	0x28(%rsp), %rax
    9010:      	movw	%bp, (%rax)
    9013:      	leaq	0x2(%rax), %rdi
    9017:      	movl	$0x4, %eax
    901c:      	movq	0x8(%rsp), %rdx
    9021:      	movl	%ebp, %esi
    9023:      	callq	*%rax
    9025:      	movq	0xa0(%rsp), %rsi
    902d:      	subl	%ebp, %esi
    902f:      	jbe	0x904e <generic_kprobe_filter_arg+0x2cfe>
    9031:      	movq	0x28(%rsp), %rax
    9036:      	leaq	(%rax,%rbp), %rdi
    903a:      	addq	$0x2, %rdi
    903e:      	andl	$0xfff, %esi            # imm = 0xFFF
    9044:      	movl	$0x4, %eax
    9049:      	movq	%r13, %rdx
    904c:      	callq	*%rax
    904e:      	movl	0x98(%rsp), %eax
    9055:      	movl	%eax, 0x40(%rsp)
    9059:      	cmpl	$0x3, %ebx
    905c:      	jg	0x908e <generic_kprobe_filter_arg+0x2d3e>
    905e:      	cmpl	$0x1, %ebx
    9061:      	leaq	0x40(%rsp), %rsi
    9066:      	jg	0x9356 <generic_kprobe_filter_arg+0x3006>
    906c:      	testl	%ebx, %ebx
    906e:      	je	0x957e <generic_kprobe_filter_arg+0x322e>
    9074:      	cmpl	$0x1, %ebx
    9077:      	jne	0x95d4 <generic_kprobe_filter_arg+0x3284>
    907d:      	movl	$0x1, %eax
    9082:      	movq	(%rip), %rdi            # 0x9089 <generic_kprobe_filter_arg+0x2d39>
    9089:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    908e:      	cmpl	$0x5, %ebx
    9091:      	leaq	0x40(%rsp), %rsi
    9096:      	jg	0x9379 <generic_kprobe_filter_arg+0x3029>
    909c:      	cmpl	$0x4, %ebx
    909f:      	je	0x958c <generic_kprobe_filter_arg+0x323c>
    90a5:      	cmpl	$0x5, %ebx
    90a8:      	jne	0x95d4 <generic_kprobe_filter_arg+0x3284>
    90ae:      	movl	$0x1, %eax
    90b3:      	movq	(%rip), %rdi            # 0x90ba <generic_kprobe_filter_arg+0x2d6a>
    90ba:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    90bf:      	movl	$0x1, %eax
    90c4:      	movq	(%rip), %rdi            # 0x90cb <generic_kprobe_filter_arg+0x2d7b>
    90cb:      	leaq	0x40(%rsp), %rsi
    90d0:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    90d2:      	movl	$0x1, %eax
    90d7:      	leaq	0x40(%rsp), %rsi
    90dc:      	movq	(%rip), %rdi            # 0x90e3 <generic_kprobe_filter_arg+0x2d93>
    90e3:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    90e5:      	movl	$0x1, %eax
    90ea:      	leaq	0x40(%rsp), %rsi
    90ef:      	movq	(%rip), %rdi            # 0x90f6 <generic_kprobe_filter_arg+0x2da6>
    90f6:      	jmp	0x9109 <generic_kprobe_filter_arg+0x2db9>
    90f8:      	movl	$0x1, %eax
    90fd:      	leaq	0x40(%rsp), %rsi
    9102:      	movq	(%rip), %rdi            # 0x9109 <generic_kprobe_filter_arg+0x2db9>
    9109:      	callq	*%rax
    910b:      	testq	%rax, %rax
    910e:      	je	0x9129 <generic_kprobe_filter_arg+0x2dd9>
    9110:      	movq	%rax, %rdi
    9113:      	movl	$0x1, %eax
    9118:      	movq	0x28(%rsp), %rsi
    911d:      	callq	*%rax
    911f:      	xorl	%ebx, %ebx
    9121:      	testq	%rax, %rax
    9124:      	setne	%bl
    9127:      	jmp	0x912b <generic_kprobe_filter_arg+0x2ddb>
    9129:      	xorl	%ebx, %ebx
    912b:      	movq	0x10(%rsp), %rdi
    9130:      	movq	0x18(%rsp), %r9
    9135:      	movq	0x20(%rsp), %r11
    913a:      	movl	0x4(%r12), %eax
    913f:      	cmpq	$0x25, %rax
    9143:      	ja	0x6607 <generic_kprobe_filter_arg+0x2b7>
    9149:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9153:      	btq	%rax, %rcx
    9157:      	jae	0x6607 <generic_kprobe_filter_arg+0x2b7>
    915d:      	xorq	$0x1, %rbx
    9161:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    9166:      	cmpl	%edx, %edi
    9168:      	setbe	%cl
    916b:      	cmpl	%esi, %edx
    916d:      	setbe	%dl
    9170:      	andb	%cl, %dl
    9172:      	orb	%dl, %al
    9174:      	movq	0x10(%rsp), %rdi
    9179:      	testb	%al, %al
    917b:      	je	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9181:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    9186:      	movq	0x8(%rsp), %r8
    918b:      	cmpq	%rsi, (%r8)
    918e:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9194:      	jmp	0x91a4 <generic_kprobe_filter_arg+0x2e54>
    9196:      	movq	0x8(%rsp), %r8
    919b:      	cmpq	%rsi, (%r8)
    919e:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    91a4:      	cmpl	$0x21, %edx
    91a7:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    91ad:      	movq	0x28(%r12), %rdx
    91b2:      	cmpl	$0x2, %eax
    91b5:      	jle	0x91e4 <generic_kprobe_filter_arg+0x2e94>
    91b7:      	leal	-0x3(%rax), %ecx
    91ba:      	cmpl	$0x2, %ecx
    91bd:      	jb	0x9217 <generic_kprobe_filter_arg+0x2ec7>
    91bf:      	cmpl	$0x6, %eax
    91c2:      	je	0x6618 <generic_kprobe_filter_arg+0x2c8>
    91c8:      	cmpl	$0xc, %eax
    91cb:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    91d1:      	movq	0x8(%rsp), %rcx
    91d6:      	testq	%rdx, (%rcx)
    91d9:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    91df:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    91e4:      	cmpl	$0x1, %eax
    91e7:      	je	0x927b <generic_kprobe_filter_arg+0x2f2b>
    91ed:      	cmpl	$0x2, %eax
    91f0:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    91f6:      	cmpl	$0xc, %ecx
    91f9:      	je	0x9204 <generic_kprobe_filter_arg+0x2eb4>
    91fb:      	cmpl	$0xa, %ecx
    91fe:      	jne	0x961d <generic_kprobe_filter_arg+0x32cd>
    9204:      	movq	0x8(%rsp), %rcx
    9209:      	cmpq	%rdx, (%rcx)
    920c:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9212:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    9217:      	movq	0x8(%rsp), %rcx
    921c:      	cmpq	%rdx, (%rcx)
    921f:      	je	0x9571 <generic_kprobe_filter_arg+0x3221>
    9225:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    922a:      	cmpl	$0xc, %eax
    922d:      	jne	0x93ac <generic_kprobe_filter_arg+0x305c>
    9233:      	movq	0x8(%rsp), %rsi
    9238:      	movzbl	(%rsi), %esi
    923b:      	testl	%esi, %edx
    923d:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9243:      	jmp	0x93ac <generic_kprobe_filter_arg+0x305c>
    9248:      	cmpl	$0xc, %eax
    924b:      	jne	0x93fb <generic_kprobe_filter_arg+0x30ab>
    9251:      	movq	0x8(%rsp), %rsi
    9256:      	movzwl	(%rsi), %esi
    9259:      	testl	%esi, %edx
    925b:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9261:      	jmp	0x93fb <generic_kprobe_filter_arg+0x30ab>
    9266:      	cmpl	%eax, %esi
    9268:      	ja	0x645d <generic_kprobe_filter_arg+0x10d>
    926e:      	cmpl	%edx, %eax
    9270:      	jbe	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9276:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    927b:      	cmpl	$0xc, %ecx
    927e:      	movq	0x8(%rsp), %rsi
    9283:      	je	0x928e <generic_kprobe_filter_arg+0x2f3e>
    9285:      	cmpl	$0xa, %ecx
    9288:      	jne	0x962d <generic_kprobe_filter_arg+0x32dd>
    928e:      	cmpq	%rdx, (%rsi)
    9291:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9297:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    929c:      	movl	$0x1, %eax
    92a1:      	movq	(%rip), %rdi            # 0x92a8 <generic_kprobe_filter_arg+0x2f58>
    92a8:      	leaq	0x40(%rsp), %rsi
    92ad:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    92af:      	movl	$0x1, %eax
    92b4:      	leaq	0x40(%rsp), %rsi
    92b9:      	movq	(%rip), %rdi            # 0x92c0 <generic_kprobe_filter_arg+0x2f70>
    92c0:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    92c2:      	movl	$0x1, %eax
    92c7:      	leaq	0x40(%rsp), %rsi
    92cc:      	movq	(%rip), %rdi            # 0x92d3 <generic_kprobe_filter_arg+0x2f83>
    92d3:      	jmp	0x92e6 <generic_kprobe_filter_arg+0x2f96>
    92d5:      	movl	$0x1, %eax
    92da:      	leaq	0x40(%rsp), %rsi
    92df:      	movq	(%rip), %rdi            # 0x92e6 <generic_kprobe_filter_arg+0x2f96>
    92e6:      	callq	*%rax
    92e8:      	testq	%rax, %rax
    92eb:      	je	0x9306 <generic_kprobe_filter_arg+0x2fb6>
    92ed:      	movq	%rax, %rdi
    92f0:      	movl	$0x1, %eax
    92f5:      	movq	0x28(%rsp), %rsi
    92fa:      	callq	*%rax
    92fc:      	xorl	%ebx, %ebx
    92fe:      	testq	%rax, %rax
    9301:      	setne	%bl
    9304:      	jmp	0x9308 <generic_kprobe_filter_arg+0x2fb8>
    9306:      	xorl	%ebx, %ebx
    9308:      	movq	0x10(%rsp), %rdi
    930d:      	movq	0x18(%rsp), %r9
    9312:      	movq	0x20(%rsp), %r11
    9317:      	movl	0x4(%r12), %eax
    931c:      	cmpq	$0x25, %rax
    9320:      	ja	0x6607 <generic_kprobe_filter_arg+0x2b7>
    9326:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9330:      	btq	%rax, %rcx
    9334:      	jb	0x960d <generic_kprobe_filter_arg+0x32bd>
    933a:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    933f:      	xorl	%ebx, %ebx
    9341:      	movq	0x10(%rsp), %rdi
    9346:      	movl	0x4(%r12), %eax
    934b:      	cmpq	$0x25, %rax
    934f:      	jbe	0x9326 <generic_kprobe_filter_arg+0x2fd6>
    9351:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    9356:      	cmpl	$0x2, %ebx
    9359:      	je	0x959a <generic_kprobe_filter_arg+0x324a>
    935f:      	cmpl	$0x3, %ebx
    9362:      	jne	0x95d4 <generic_kprobe_filter_arg+0x3284>
    9368:      	movl	$0x1, %eax
    936d:      	movq	(%rip), %rdi            # 0x9374 <generic_kprobe_filter_arg+0x3024>
    9374:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    9379:      	cmpl	$0x6, %ebx
    937c:      	je	0x95a8 <generic_kprobe_filter_arg+0x3258>
    9382:      	cmpl	$0x7, %ebx
    9385:      	jne	0x95d4 <generic_kprobe_filter_arg+0x3284>
    938b:      	movl	$0x1, %eax
    9390:      	movq	(%rip), %rdi            # 0x9397 <generic_kprobe_filter_arg+0x3047>
    9397:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    939c:      	movq	0x8(%rsp), %rsi
    93a1:      	movzbl	(%rsi), %esi
    93a4:      	cmpl	%esi, %edx
    93a6:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    93ac:      	cmpl	$0x15, %ecx
    93af:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    93b5:      	movl	0x1c(%r12), %ecx
    93ba:      	cmpl	$0x2, %eax
    93bd:      	jle	0x9514 <generic_kprobe_filter_arg+0x31c4>
    93c3:      	leal	-0x3(%rax), %edx
    93c6:      	cmpl	$0x2, %edx
    93c9:      	jb	0x9557 <generic_kprobe_filter_arg+0x3207>
    93cf:      	cmpl	$0x6, %eax
    93d2:      	je	0x6618 <generic_kprobe_filter_arg+0x2c8>
    93d8:      	cmpl	$0xc, %eax
    93db:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    93e1:      	movq	0x8(%rsp), %rdx
    93e6:      	movzbl	(%rdx), %edx
    93e9:      	jmp	0x9438 <generic_kprobe_filter_arg+0x30e8>
    93eb:      	movq	0x8(%rsp), %rsi
    93f0:      	movzwl	(%rsi), %esi
    93f3:      	cmpl	%esi, %edx
    93f5:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    93fb:      	cmpl	$0x15, %ecx
    93fe:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    9404:      	movl	0x1c(%r12), %ecx
    9409:      	cmpl	$0x2, %eax
    940c:      	jle	0x9530 <generic_kprobe_filter_arg+0x31e0>
    9412:      	leal	-0x3(%rax), %edx
    9415:      	cmpl	$0x2, %edx
    9418:      	jb	0x9561 <generic_kprobe_filter_arg+0x3211>
    941e:      	cmpl	$0x6, %eax
    9421:      	je	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9427:      	cmpl	$0xc, %eax
    942a:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    9430:      	movq	0x8(%rsp), %rdx
    9435:      	movzwl	(%rdx), %edx
    9438:      	testl	%edx, %ecx
    943a:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9440:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    9445:      	movq	0x8(%rsp), %r8
    944a:      	cmpl	%esi, (%r8)
    944d:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9453:      	jmp	0x9463 <generic_kprobe_filter_arg+0x3113>
    9455:      	movq	0x8(%rsp), %r8
    945a:      	cmpl	%esi, (%r8)
    945d:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9463:      	cmpl	$0x15, %edx
    9466:      	jb	0x969a <generic_kprobe_filter_arg+0x334a>
    946c:      	movl	0x1c(%r12), %edx
    9471:      	cmpl	$0x2, %eax
    9474:      	jle	0x94a2 <generic_kprobe_filter_arg+0x3152>
    9476:      	leal	-0x3(%rax), %ecx
    9479:      	cmpl	$0x2, %ecx
    947c:      	jb	0x94d9 <generic_kprobe_filter_arg+0x3189>
    947e:      	cmpl	$0x6, %eax
    9481:      	je	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9487:      	cmpl	$0xc, %eax
    948a:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    9490:      	movq	0x8(%rsp), %rcx
    9495:      	testl	%edx, (%rcx)
    9497:      	jne	0x6618 <generic_kprobe_filter_arg+0x2c8>
    949d:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    94a2:      	cmpl	$0x1, %eax
    94a5:      	je	0x94eb <generic_kprobe_filter_arg+0x319b>
    94a7:      	cmpl	$0x2, %eax
    94aa:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    94b0:      	cmpl	$0xc, %ecx
    94b3:      	ja	0x967e <generic_kprobe_filter_arg+0x332e>
    94b9:      	movl	$0x1402, %esi           # imm = 0x1402
    94be:      	btl	%ecx, %esi
    94c1:      	jae	0x967e <generic_kprobe_filter_arg+0x332e>
    94c7:      	movq	0x8(%rsp), %rcx
    94cc:      	cmpl	%edx, (%rcx)
    94ce:      	jl	0x6618 <generic_kprobe_filter_arg+0x2c8>
    94d4:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    94d9:      	movq	0x8(%rsp), %rcx
    94de:      	cmpl	%edx, (%rcx)
    94e0:      	je	0x9571 <generic_kprobe_filter_arg+0x3221>
    94e6:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    94eb:      	cmpl	$0xc, %ecx
    94ee:      	ja	0x968d <generic_kprobe_filter_arg+0x333d>
    94f4:      	movl	$0x1402, %esi           # imm = 0x1402
    94f9:      	btl	%ecx, %esi
    94fc:      	jae	0x968d <generic_kprobe_filter_arg+0x333d>
    9502:      	movq	0x8(%rsp), %rcx
    9507:      	cmpl	%edx, (%rcx)
    9509:      	jg	0x6618 <generic_kprobe_filter_arg+0x2c8>
    950f:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    9514:      	cmpl	$0x1, %eax
    9517:      	je	0x9638 <generic_kprobe_filter_arg+0x32e8>
    951d:      	cmpl	$0x2, %eax
    9520:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    9526:      	movq	0x8(%rsp), %rdx
    952b:      	movzbl	(%rdx), %edx
    952e:      	jmp	0x954a <generic_kprobe_filter_arg+0x31fa>
    9530:      	cmpl	$0x1, %eax
    9533:      	je	0x9642 <generic_kprobe_filter_arg+0x32f2>
    9539:      	cmpl	$0x2, %eax
    953c:      	jne	0x645d <generic_kprobe_filter_arg+0x10d>
    9542:      	movq	0x8(%rsp), %rdx
    9547:      	movzwl	(%rdx), %edx
    954a:      	cmpl	%edx, %ecx
    954c:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9552:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    9557:      	movq	0x8(%rsp), %rdx
    955c:      	movzbl	(%rdx), %edx
    955f:      	jmp	0x9569 <generic_kprobe_filter_arg+0x3219>
    9561:      	movq	0x8(%rsp), %rdx
    9566:      	movzwl	(%rdx), %edx
    9569:      	cmpl	%edx, %ecx
    956b:      	jne	0x969a <generic_kprobe_filter_arg+0x334a>
    9571:      	xorl	%ebx, %ebx
    9573:      	cmpl	$0x3, %eax
    9576:      	sete	%bl
    9579:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    957e:      	movl	$0x1, %eax
    9583:      	movq	(%rip), %rdi            # 0x958a <generic_kprobe_filter_arg+0x323a>
    958a:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    958c:      	movl	$0x1, %eax
    9591:      	movq	(%rip), %rdi            # 0x9598 <generic_kprobe_filter_arg+0x3248>
    9598:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    959a:      	movl	$0x1, %eax
    959f:      	movq	(%rip), %rdi            # 0x95a6 <generic_kprobe_filter_arg+0x3256>
    95a6:      	jmp	0x95b4 <generic_kprobe_filter_arg+0x3264>
    95a8:      	movl	$0x1, %eax
    95ad:      	movq	(%rip), %rdi            # 0x95b4 <generic_kprobe_filter_arg+0x3264>
    95b4:      	callq	*%rax
    95b6:      	testq	%rax, %rax
    95b9:      	je	0x95d4 <generic_kprobe_filter_arg+0x3284>
    95bb:      	movq	%rax, %rdi
    95be:      	movl	$0x1, %eax
    95c3:      	movq	0x28(%rsp), %rsi
    95c8:      	callq	*%rax
    95ca:      	xorl	%ebx, %ebx
    95cc:      	testq	%rax, %rax
    95cf:      	setne	%bl
    95d2:      	jmp	0x95d6 <generic_kprobe_filter_arg+0x3286>
    95d4:      	xorl	%ebx, %ebx
    95d6:      	movq	0x10(%rsp), %rdi
    95db:      	movq	0x18(%rsp), %r9
    95e0:      	movq	0x20(%rsp), %r11
    95e5:      	movl	0x4(%r12), %eax
    95ea:      	cmpq	$0x25, %rax
    95ee:      	ja	0x6602 <generic_kprobe_filter_arg+0x2b2>
    95f4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    95fe:      	btq	%rax, %rcx
    9602:      	movq	0x78(%rsp), %r13
    9607:      	jae	0x6607 <generic_kprobe_filter_arg+0x2b7>
    960d:      	xorl	%eax, %eax
    960f:      	testq	%rbx, %rbx
    9612:      	sete	%al
    9615:      	movq	%rax, %rbx
    9618:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    961d:      	movq	0x8(%rsp), %rcx
    9622:      	cmpq	%rdx, (%rcx)
    9625:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    962b:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    962d:      	cmpq	%rdx, (%rsi)
    9630:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9636:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    9638:      	movq	0x8(%rsp), %rdx
    963d:      	movzbl	(%rdx), %edx
    9640:      	jmp	0x964a <generic_kprobe_filter_arg+0x32fa>
    9642:      	movq	0x8(%rsp), %rdx
    9647:      	movzwl	(%rdx), %edx
    964a:      	cmpl	%edx, %ecx
    964c:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    9652:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    9654:      	xorl	%ebx, %ebx
    9656:      	movq	0x10(%rsp), %rdi
    965b:      	movq	0x18(%rsp), %r9
    9660:      	movq	0x20(%rsp), %r11
    9665:      	movq	0x68(%rsp), %r15
    966a:      	movl	0x4(%r12), %eax
    966f:      	cmpq	$0x25, %rax
    9673:      	jbe	0x9149 <generic_kprobe_filter_arg+0x2df9>
    9679:      	jmp	0x6607 <generic_kprobe_filter_arg+0x2b7>
    967e:      	movq	0x8(%rsp), %rcx
    9683:      	cmpl	%edx, (%rcx)
    9685:      	jb	0x6618 <generic_kprobe_filter_arg+0x2c8>
    968b:      	jmp	0x969a <generic_kprobe_filter_arg+0x334a>
    968d:      	movq	0x8(%rsp), %rcx
    9692:      	cmpl	%edx, (%rcx)
    9694:      	ja	0x6618 <generic_kprobe_filter_arg+0x2c8>
    969a:      	orl	$0x2, %eax
    969d:      	cmpl	$0x6, %eax
    96a0:      	je	0x6618 <generic_kprobe_filter_arg+0x2c8>
    96a6:      	jmp	0x645d <generic_kprobe_filter_arg+0x10d>
    96ab:      	nopl	(%rax,%rax)

00000000000096b0 <generic_kprobe_actions>:
    96b0:      	pushq	%rbp
    96b1:      	pushq	%r15
    96b3:      	pushq	%r14
    96b5:      	pushq	%r13
    96b7:      	pushq	%r12
    96b9:      	pushq	%rbx
    96ba:      	subq	$0xa8, %rsp
    96c1:      	movq	%rdi, 0x88(%rsp)
    96c9:      	movl	$0x0, 0x94(%rsp)
    96d4:      	movq	(%rip), %rdi            # 0x96db <generic_kprobe_actions+0x2b>
    96db:      	leaq	0x94(%rsp), %rsi
    96e3:      	movl	$0x1, %eax
    96e8:      	callq	*%rax
    96ea:      	testq	%rax, %rax
    96ed:      	je	0xa453 <generic_kprobe_actions+0xda3>
    96f3:      	movq	%rax, %rsi
    96f6:      	movl	0x5f04(%rax), %ebx
    96fc:      	cmpl	$0x2, %ebx
    96ff:      	jl	0xa453 <generic_kprobe_actions+0xda3>
    9705:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    970c:      	movq	(%rip), %rdi            # 0x9713 <generic_kprobe_actions+0x63>
    9713:      	movl	$0x1, %eax
    9718:      	callq	*%rax
    971a:      	testq	%rax, %rax
    971d:      	je	0xa453 <generic_kprobe_actions+0xda3>
    9723:      	movq	%rax, %r14
    9726:      	movl	%ebx, %eax
    9728:      	andl	$0x7ff, %eax            # imm = 0x7FF
    972d:      	addl	(%r14,%rax), %ebx
    9731:      	movl	$0x0, 0x98(%rsp)
    973c:      	movq	(%rip), %rdi            # 0x9743 <generic_kprobe_actions+0x93>
    9743:      	leaq	0x98(%rsp), %rsi
    974b:      	movl	$0x1, %eax
    9750:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    9756:      	callq	*%rax
    9758:      	movb	$0x1, %cl
    975a:      	movl	%ecx, 0x5c(%rsp)
    975e:      	testq	%rax, %rax
    9761:      	je	0x977e <generic_kprobe_actions+0xce>
    9763:      	xorl	%ecx, %ecx
    9765:      	cmpb	$0x0, (%rax)
    9768:      	sete	%cl
    976b:      	movq	%rcx, 0x78(%rsp)
    9770:      	xorq	$0x9, %rcx
    9774:      	movq	%rcx, 0xa0(%rsp)
    977c:      	jmp	0x9792 <generic_kprobe_actions+0xe2>
    977e:      	movl	$0x8, %eax
    9783:      	movq	%rax, 0xa0(%rsp)
    978b:      	movb	$0x1, %al
    978d:      	movq	%rax, 0x78(%rsp)
    9792:      	addq	%rbx, %r14
    9795:      	xorl	%r13d, %r13d
    9798:      	xorl	%r15d, %r15d
    979b:      	movq	%r14, 0x30(%rsp)
    97a0:      	jmp	0x97ca <generic_kprobe_actions+0x11a>
    97a2:      	incl	%r15d
    97a5:      	movl	0x4(%r14,%r15,4), %eax
    97aa:      	movl	%eax, 0x78(%rdx)
    97ad:      	nopl	(%rax)
    97b0:      	movq	%r12, 0x70(%rdx)
    97b4:      	incl	%r15d
    97b7:      	movl	%r15d, %ebx
    97ba:      	incl	%r13d
    97bd:      	movl	%ebx, %r15d
    97c0:      	cmpl	$0x3, %r13d
    97c4:      	je	0xa42c <generic_kprobe_actions+0xd7c>
    97ca:      	leal	0x4(,%r15,4), %eax
    97d2:      	cmpl	(%r14), %eax
    97d5:      	jae	0xa42c <generic_kprobe_actions+0xd7c>
    97db:      	movl	%r15d, %eax
    97de:      	movslq	0x4(%r14,%rax,4), %r12
    97e3:      	movl	$0x0, 0x9c(%rsp)
    97ee:      	movl	$0x1, %eax
    97f3:      	movq	(%rip), %rdi            # 0x97fa <generic_kprobe_actions+0x14a>
    97fa:      	leaq	0x9c(%rsp), %rsi
    9802:      	callq	*%rax
    9804:      	xorl	%ebx, %ebx
    9806:      	testq	%rax, %rax
    9809:      	je	0x97ba <generic_kprobe_actions+0x10a>
    980b:      	movq	%rax, %rdx
    980e:      	cmpl	$0x7, %r12d
    9812:      	jg	0x9840 <generic_kprobe_actions+0x190>
    9814:      	cmpl	$0x3, %r12d
    9818:      	jg	0x987e <generic_kprobe_actions+0x1ce>
    981a:      	cmpl	$0x1, %r12d
    981e:      	jg	0x99cc <generic_kprobe_actions+0x31c>
    9824:      	testl	%r12d, %r12d
    9827:      	je	0x9c45 <generic_kprobe_actions+0x595>
    982d:      	cmpl	$0x1, %r12d
    9831:      	je	0x99e5 <generic_kprobe_actions+0x335>
    9837:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    983c:      	nopl	(%rax)
    9840:      	cmpl	$0xb, %r12d
    9844:      	jg	0x9998 <generic_kprobe_actions+0x2e8>
    984a:      	leal	-0xa(%r12), %eax
    984f:      	cmpl	$0x2, %eax
    9852:      	jb	0x9a68 <generic_kprobe_actions+0x3b8>
    9858:      	cmpl	$0x8, %r12d
    985c:      	je	0x9b26 <generic_kprobe_actions+0x476>
    9862:      	cmpl	$0x9, %r12d
    9866:      	jne	0x97b0 <generic_kprobe_actions+0x100>
    986c:      	movq	%rdx, 0x18(%rsp)
    9871:      	incl	%r15d
    9874:      	movl	0x4(%r14,%r15,4), %eax
    9879:      	jmp	0x9d08 <generic_kprobe_actions+0x658>
    987e:      	leal	-0x6(%r12), %eax
    9883:      	cmpl	$0x2, %eax
    9886:      	jb	0x97a2 <generic_kprobe_actions+0xf2>
    988c:      	cmpl	$0x4, %r12d
    9890:      	je	0x9b33 <generic_kprobe_actions+0x483>
    9896:      	cmpl	$0x5, %r12d
    989a:      	jne	0x97b0 <generic_kprobe_actions+0x100>
    98a0:      	leal	0x1(%r15), %eax
    98a4:      	movl	0x4(%r14,%rax,4), %eax
    98a9:      	addl	$0x2, %r15d
    98ad:      	movl	0x4(%r14,%r15,4), %ebx
    98b2:      	movq	$0x0, 0x10(%rsp)
    98bb:      	movq	$0x0, 0x8(%rsp)
    98c4:      	andl	$0x7, %eax
    98c7:      	cmpl	$0x4, %eax
    98ca:      	ja	0x97b0 <generic_kprobe_actions+0x100>
    98d0:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    98d8:      	jne	0x97b0 <generic_kprobe_actions+0x100>
    98de:      	movq	0x5e78(%rdx,%rax,8), %rax
    98e6:      	andl	$0x7ff, %eax            # imm = 0x7FF
    98eb:      	movl	0x90(%rdx,%rax), %eax
    98f2:      	movl	%eax, 0x10(%rsp)
    98f6:      	movl	$0xe, %eax
    98fb:      	movq	%rdx, %rbp
    98fe:      	callq	*%rax
    9900:      	shrq	$0x20, %rax
    9904:      	movq	%rax, 0x8(%rsp)
    9909:      	movl	$0x1, %eax
    990e:      	leaq	0x8(%rsp), %rsi
    9913:      	movq	(%rip), %rdi            # 0x991a <generic_kprobe_actions+0x26a>
    991a:      	callq	*%rax
    991c:      	movq	%rbp, %rdx
    991f:      	testq	%rax, %rax
    9922:      	je	0x97b0 <generic_kprobe_actions+0x100>
    9928:      	andl	$0x7, %ebx
    992b:      	cmpl	$0x4, %ebx
    992e:      	ja	0x97b0 <generic_kprobe_actions+0x100>
    9934:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    993c:      	jne	0x97b0 <generic_kprobe_actions+0x100>
    9942:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    994a:      	movl	$0x0, 0x14(%rsp)
    9952:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    9958:      	movl	0x90(%rdx,%rcx), %ecx
    995f:      	movl	%ecx, 0x10(%rsp)
    9963:      	movq	%rax, %rbx
    9966:      	movl	$0xe, %eax
    996b:      	callq	*%rax
    996d:      	shrq	$0x20, %rax
    9971:      	movq	%rax, 0x8(%rsp)
    9976:      	movl	$0x2, %eax
    997b:      	xorl	%ecx, %ecx
    997d:      	leaq	0x8(%rsp), %rsi
    9982:      	movq	(%rip), %rdi            # 0x9989 <generic_kprobe_actions+0x2d9>
    9989:      	movq	%rbx, %rdx
    998c:      	xorl	%ecx, %ecx
    998e:      	callq	*%rax
    9990:      	movq	%rbp, %rdx
    9993:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    9998:      	cmpl	$0xc, %r12d
    999c:      	movq	%rdx, 0x18(%rsp)
    99a1:      	je	0x9d3c <generic_kprobe_actions+0x68c>
    99a7:      	cmpl	$0xd, %r12d
    99ab:      	je	0x9bc7 <generic_kprobe_actions+0x517>
    99b1:      	cmpl	$0xe, %r12d
    99b5:      	jne	0x97b0 <generic_kprobe_actions+0x100>
    99bb:      	addl	$0x2, %r15d
    99bf:      	movq	0xa0(%rsp), %r14
    99c7:      	jmp	0xa00d <generic_kprobe_actions+0x95d>
    99cc:      	movl	$0x9, %eax
    99d1:      	cmpl	$0x2, %r12d
    99d5:      	je	0x9d03 <generic_kprobe_actions+0x653>
    99db:      	cmpl	$0x3, %r12d
    99df:      	jne	0x97b0 <generic_kprobe_actions+0x100>
    99e5:      	movq	%rdx, %rbp
    99e8:      	leal	0x1(%r15), %eax
    99ec:      	movq	%r14, %rcx
    99ef:      	movl	0x4(%r14,%rax,4), %r14d
    99f4:      	addl	$0x2, %r15d
    99f8:      	movl	0x4(%rcx,%r15,4), %eax
    99fd:      	movq	%rax, 0x50(%rsp)
    9a02:      	movq	$0x0, 0x10(%rsp)
    9a0b:      	movq	$0x0, 0x8(%rsp)
    9a14:      	movl	$0x0, 0x20(%rsp)
    9a1c:      	movl	$0x1, %eax
    9a21:      	leaq	0x20(%rsp), %rsi
    9a26:      	movq	(%rip), %rdi            # 0x9a2d <generic_kprobe_actions+0x37d>
    9a2d:      	callq	*%rax
    9a2f:      	xorl	%ecx, %ecx
    9a31:      	testq	%rax, %rax
    9a34:      	je	0xa05d <generic_kprobe_actions+0x9ad>
    9a3a:      	andl	$0x7, %r14d
    9a3e:      	cmpl	$0x4, %r14d
    9a42:      	movq	%rbp, %rdx
    9a45:      	ja	0x9a56 <generic_kprobe_actions+0x3a6>
    9a47:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    9a50:      	je	0x9e2b <generic_kprobe_actions+0x77b>
    9a56:      	movq	0x30(%rsp), %r14
    9a5b:      	testl	%ecx, %ecx
    9a5d:      	jne	0x97ba <generic_kprobe_actions+0x10a>
    9a63:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    9a68:      	incl	%r15d
    9a6b:      	movl	0x4(%r14,%r15,4), %eax
    9a70:      	andl	$0x7, %eax
    9a73:      	xorl	%ecx, %ecx
    9a75:      	cmpl	$0x4, %eax
    9a78:      	ja	0xa065 <generic_kprobe_actions+0x9b5>
    9a7e:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    9a86:      	jne	0xa065 <generic_kprobe_actions+0x9b5>
    9a8c:      	movq	0x5e78(%rdx,%rax,8), %rax
    9a94:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9a99:      	movq	0xb8(%rdx,%rax), %rax
    9aa1:      	movq	%rax, 0x20(%rsp)
    9aa6:      	testq	%rax, %rax
    9aa9:      	je	0xa065 <generic_kprobe_actions+0x9b5>
    9aaf:      	movq	%rdx, %rbp
    9ab2:      	cmpl	$0xa, %r12d
    9ab6:      	jne	0xa072 <generic_kprobe_actions+0x9c2>
    9abc:      	movl	$0xe, %eax
    9ac1:      	callq	*%rax
    9ac3:      	movq	%rax, 0x50(%rsp)
    9ac8:      	shrq	$0x20, %rax
    9acc:      	movl	%eax, 0x8(%rsp)
    9ad0:      	movl	$0x1, %eax
    9ad5:      	leaq	0x8(%rsp), %rsi
    9ada:      	movq	(%rip), %rdi            # 0x9ae1 <generic_kprobe_actions+0x431>
    9ae1:      	callq	*%rax
    9ae3:      	xorl	%ecx, %ecx
    9ae5:      	testq	%rax, %rax
    9ae8:      	movq	%rbp, %rdx
    9aeb:      	je	0xa065 <generic_kprobe_actions+0x9b5>
    9af1:      	movl	(%rax), %ecx
    9af3:      	movl	%ecx, 0x8(%rsp)
    9af7:      	movq	0x50(%rsp), %rcx
    9afc:      	movl	%ecx, 0xc(%rsp)
    9b00:      	movq	0x8(%rax), %rax
    9b04:      	movq	%rax, 0x10(%rsp)
    9b09:      	xorl	%ecx, %ecx
    9b0b:      	movl	$0x2, %eax
    9b10:      	leaq	0x20(%rsp), %rsi
    9b15:      	leaq	0x8(%rsp), %rdx
    9b1a:      	movq	(%rip), %rdi            # 0x9b21 <generic_kprobe_actions+0x471>
    9b21:      	jmp	0x9ee2 <generic_kprobe_actions+0x832>
    9b26:      	movl	$0x0, 0x5c(%rsp)
    9b2e:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    9b33:      	movq	%rdx, 0x18(%rsp)
    9b38:      	incl	%r15d
    9b3b:      	movl	$0x5, %r14d
    9b41:      	cmpb	$0x0, 0x78(%rsp)
    9b46:      	je	0xa00d <generic_kprobe_actions+0x95d>
    9b4c:      	movl	%r15d, %eax
    9b4f:      	movq	0x30(%rsp), %rcx
    9b54:      	movl	0x4(%rcx,%rax,4), %eax
    9b58:      	movl	%eax, 0x60(%rsp)
    9b5c:      	movl	$0xe, %eax
    9b61:      	callq	*%rax
    9b63:      	movq	%rax, 0x20(%rsp)
    9b68:      	movl	$0x1, %eax
    9b6d:      	leaq	0x20(%rsp), %r14
    9b72:      	movq	(%rip), %rbp            # 0x9b79 <generic_kprobe_actions+0x4c9>
    9b79:      	movq	%rbp, %rdi
    9b7c:      	movq	%r14, %rsi
    9b7f:      	callq	*%rax
    9b81:      	testq	%rax, %rax
    9b84:      	je	0x9f5e <generic_kprobe_actions+0x8ae>
    9b8a:      	movq	%rax, %rbx
    9b8d:      	movl	$0xe0011, 0x8(%rsp)     # imm = 0xE0011
    9b95:      	movq	$0x35c, 0xc(%rsp)       # imm = 0x35C
    9b9e:      	movl	$0x1, %eax
    9ba3:      	leaq	0x8(%rsp), %r14
    9ba8:      	movq	(%rip), %rbp            # 0x9baf <generic_kprobe_actions+0x4ff>
    9baf:      	movq	%rbp, %rdi
    9bb2:      	movq	%r14, %rsi
    9bb5:      	callq	*%rax
    9bb7:      	testq	%rax, %rax
    9bba:      	je	0x9fe3 <generic_kprobe_actions+0x933>
    9bc0:      	incl	(%rax)
    9bc2:      	jmp	0xa001 <generic_kprobe_actions+0x951>
    9bc7:      	movl	$0xe, %eax
    9bcc:      	callq	*%rax
    9bce:      	movq	%rax, 0x40(%rsp)
    9bd3:      	movl	$0x1, %eax
    9bd8:      	leaq	0x40(%rsp), %rsi
    9bdd:      	movq	(%rip), %rdi            # 0x9be4 <generic_kprobe_actions+0x534>
    9be4:      	callq	*%rax
    9be6:      	testq	%rax, %rax
    9be9:      	je	0xa03d <generic_kprobe_actions+0x98d>
    9bef:      	movq	0x4(%rax), %rax
    9bf3:      	movq	%rax, 0x20(%rsp)
    9bf8:      	movl	$0x2, 0x28(%rsp)
    9c00:      	movl	$0x1, %eax
    9c05:      	leaq	0x20(%rsp), %rbx
    9c0a:      	movq	(%rip), %rbp            # 0x9c11 <generic_kprobe_actions+0x561>
    9c11:      	movq	%rbp, %rdi
    9c14:      	movq	%rbx, %rsi
    9c17:      	callq	*%rax
    9c19:      	movl	$0x1, 0x3c(%rsp)
    9c21:      	testq	%rax, %rax
    9c24:      	je	0x9ef8 <generic_kprobe_actions+0x848>
    9c2a:      	lock
    9c2b:      	incl	(%rax)
    9c2d:      	movl	$0x3, %eax
    9c32:      	leaq	0x40(%rsp), %rsi
    9c37:      	movq	(%rip), %rdi            # 0x9c3e <generic_kprobe_actions+0x58e>
    9c3e:      	callq	*%rax
    9c40:      	jmp	0xa03d <generic_kprobe_actions+0x98d>
    9c45:      	movq	%rdx, 0x18(%rsp)
    9c4a:      	leal	0x1(%r15), %eax
    9c4e:      	movl	0x4(%r14,%rax,4), %ebp
    9c53:      	leal	0x2(%r15), %eax
    9c57:      	movl	0x4(%r14,%rax,4), %ebx
    9c5c:      	movl	$0x7d, %eax
    9c61:      	callq	*%rax
    9c63:      	movq	%rax, 0x8(%rsp)
    9c68:      	movl	$0x0, 0x40(%rsp)
    9c70:      	movq	%rbp, 0x70(%rsp)
    9c75:      	testq	%rbp, %rbp
    9c78:      	je	0xa2c3 <generic_kprobe_actions+0xc13>
    9c7e:      	movl	$0x1, %eax
    9c83:      	movq	(%rip), %rdi            # 0x9c8a <generic_kprobe_actions+0x5da>
    9c8a:      	leaq	0x40(%rsp), %rsi
    9c8f:      	callq	*%rax
    9c91:      	testq	%rax, %rax
    9c94:      	je	0xa2c3 <generic_kprobe_actions+0xc13>
    9c9a:      	movq	%rax, 0x50(%rsp)
    9c9f:      	movq	%rax, %rbp
    9ca2:      	movl	$0x1, %eax
    9ca7:      	leaq	0x40(%rsp), %rsi
    9cac:      	movq	(%rip), %rdi            # 0x9cb3 <generic_kprobe_actions+0x603>
    9cb3:      	callq	*%rax
    9cb5:      	movq	%rax, %rdx
    9cb8:      	movq	0x18(%rsp), %rcx
    9cbd:      	movq	0x60(%rcx), %rax
    9cc1:      	movq	%rax, (%rbp)
    9cc5:      	movq	0x70(%rcx), %rax
    9cc9:      	movq	%rbp, 0x80(%rsp)
    9cd1:      	movq	%rax, 0x8(%rbp)
    9cd5:      	xorl	%ebp, %ebp
    9cd7:      	movl	$0x0, %eax
    9cdc:      	cmpl	$0x2, %ebx
    9cdf:      	je	0xa0fe <generic_kprobe_actions+0xa4e>
    9ce5:      	cmpl	$0x1, %ebx
    9ce8:      	je	0xa0fb <generic_kprobe_actions+0xa4b>
    9cee:      	testl	%ebx, %ebx
    9cf0:      	jne	0xa2c3 <generic_kprobe_actions+0xc13>
    9cf6:      	movq	0x18(%rsp), %rax
    9cfb:      	movl	0x7c(%rax), %eax
    9cfe:      	jmp	0xa0fe <generic_kprobe_actions+0xa4e>
    9d03:      	movq	%rdx, 0x18(%rsp)
    9d08:      	movl	%r15d, %ebx
    9d0b:      	movl	$0x3, %r14d
    9d11:      	cmpb	$0x0, 0x78(%rsp)
    9d16:      	leaq	0x8(%rsp), %rsi
    9d1b:      	je	0xa015 <generic_kprobe_actions+0x965>
    9d21:      	movslq	%eax, %rdi
    9d24:      	movl	$0x6d, %eax
    9d29:      	movq	%rsi, %r14
    9d2c:      	callq	*%rax
    9d2e:      	movq	%r14, %rsi
    9d31:      	movl	$0x2, %r14d
    9d37:      	jmp	0xa015 <generic_kprobe_actions+0x965>
    9d3c:      	leal	0x3(%r15), %ebx
    9d40:      	movl	$0x7, %r14d
    9d46:      	cmpb	$0x0, 0x78(%rsp)
    9d4b:      	je	0xa010 <generic_kprobe_actions+0x960>
    9d51:      	movl	%ebx, %eax
    9d53:      	movq	0x30(%rsp), %rcx
    9d58:      	movl	0x4(%rcx,%rax,4), %eax
    9d5c:      	cmpq	$0x4, %rax
    9d60:      	ja	0x9d70 <generic_kprobe_actions+0x6c0>
    9d62:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    9d6a:      	je	0xa343 <generic_kprobe_actions+0xc93>
    9d70:      	xorl	%r14d, %r14d
    9d73:      	leal	0x2(%r15), %eax
    9d77:      	incl	%r15d
    9d7a:      	movq	0x30(%rsp), %rcx
    9d7f:      	movl	0x4(%rcx,%rax,4), %ebp
    9d83:      	movl	0x4(%rcx,%r15,4), %r15d
    9d88:      	movl	0x60(%rdx), %ecx
    9d8b:      	movl	$0xe, %eax
    9d90:      	shlq	$0x20, %r14
    9d94:      	orq	%rcx, %r14
    9d97:      	callq	*%rax
    9d99:      	movq	%rax, 0x60(%rsp)
    9d9e:      	movw	%r15w, 0x20(%rsp)
    9da4:      	movw	%bp, 0x22(%rsp)
    9da9:      	movq	%r14, 0x24(%rsp)
    9dae:      	movl	$0x1, %eax
    9db3:      	leaq	0x60(%rsp), %r14
    9db8:      	movq	(%rip), %rbp            # 0x9dbf <generic_kprobe_actions+0x70f>
    9dbf:      	movq	%rbp, %rdi
    9dc2:      	movq	%r14, %rsi
    9dc5:      	callq	*%rax
    9dc7:      	testq	%rax, %rax
    9dca:      	je	0x9f79 <generic_kprobe_actions+0x8c9>
    9dd0:      	movq	%rax, %r15
    9dd3:      	movq	0x4(%rax), %rax
    9dd7:      	movq	%rax, 0x40(%rsp)
    9ddc:      	movl	$0x1, 0x48(%rsp)
    9de4:      	movl	$0x1, %eax
    9de9:      	leaq	0x40(%rsp), %rbp
    9dee:      	movq	(%rip), %r14            # 0x9df5 <generic_kprobe_actions+0x745>
    9df5:      	movq	%r14, %rdi
    9df8:      	movq	%rbp, %rsi
    9dfb:      	callq	*%rax
    9dfd:      	movl	$0x1, 0x6c(%rsp)
    9e05:      	testq	%rax, %rax
    9e08:      	je	0xa098 <generic_kprobe_actions+0x9e8>
    9e0e:      	lock
    9e0f:      	incl	(%rax)
    9e11:      	movl	0x28(%rsp), %eax
    9e15:      	movl	%eax, 0x8(%r15)
    9e19:      	movq	0x20(%rsp), %rax
    9e1e:      	movq	%rax, (%r15)
    9e21:      	leaq	0x8(%rsp), %rsi
    9e26:      	jmp	0xa3ce <generic_kprobe_actions+0xd1e>
    9e2b:      	movq	%rax, 0x70(%rsp)
    9e30:      	movq	0x5e78(%rdx,%r14,8), %rax
    9e38:      	movl	$0x0, 0x14(%rsp)
    9e40:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9e45:      	movl	0x90(%rdx,%rax), %eax
    9e4c:      	movl	%eax, 0x10(%rsp)
    9e50:      	movl	$0xe, %eax
    9e55:      	callq	*%rax
    9e57:      	shrq	$0x20, %rax
    9e5b:      	movq	%rax, 0x8(%rsp)
    9e60:      	cmpl	$0x1, %r12d
    9e64:      	jne	0xa047 <generic_kprobe_actions+0x997>
    9e6a:      	movq	0x50(%rsp), %rax
    9e6f:      	andl	$0x7, %eax
    9e72:      	cmpl	$0x4, %eax
    9e75:      	movq	0x30(%rsp), %r14
    9e7a:      	movl	$0x0, %ecx
    9e7f:      	ja	0xa062 <generic_kprobe_actions+0x9b2>
    9e85:      	movq	%rbp, %rdx
    9e88:      	cmpl	$0x0, 0x5ea0(%rbp,%rax,4)
    9e90:      	jne	0xa065 <generic_kprobe_actions+0x9b5>
    9e96:      	movq	0x5e78(%rdx,%rax,8), %rax
    9e9e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9ea3:      	addq	%rax, %rdx
    9ea6:      	addq	$0x90, %rdx
    9ead:      	movl	0x90(%rbp,%rax), %esi
    9eb4:      	andl	$0xfff, %esi            # imm = 0xFFF
    9eba:      	addq	$0x8, %rsi
    9ebe:      	movl	$0x4, %eax
    9ec3:      	movq	0x70(%rsp), %rdi
    9ec8:      	callq	*%rax
    9eca:      	xorl	%ecx, %ecx
    9ecc:      	movl	$0x2, %eax
    9ed1:      	leaq	0x8(%rsp), %rsi
    9ed6:      	movq	(%rip), %rdi            # 0x9edd <generic_kprobe_actions+0x82d>
    9edd:      	movq	0x70(%rsp), %rdx
    9ee2:      	xorl	%ecx, %ecx
    9ee4:      	callq	*%rax
    9ee6:      	xorl	%ecx, %ecx
    9ee8:      	movq	%rbp, %rdx
    9eeb:      	testl	%ecx, %ecx
    9eed:      	jne	0x97ba <generic_kprobe_actions+0x10a>
    9ef3:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    9ef8:      	movl	$0x2, %eax
    9efd:      	movl	$0x1, %ecx
    9f02:      	leaq	0x3c(%rsp), %rdx
    9f07:      	movq	%rbp, %rdi
    9f0a:      	movq	%rbx, %rsi
    9f0d:      	callq	*%rax
    9f0f:      	testq	%rax, %rax
    9f12:      	je	0x9c2d <generic_kprobe_actions+0x57d>
    9f18:      	movq	%rax, %rbx
    9f1b:      	negl	%eax
    9f1d:      	movw	%ax, 0x8(%rsp)
    9f22:      	movw	$0x3, 0xa(%rsp)
    9f29:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9f33:      	movq	%rax, 0xc(%rsp)
    9f38:      	movl	$0x1, %eax
    9f3d:      	leaq	0x8(%rsp), %rbp
    9f42:      	movq	(%rip), %rdi            # 0x9f49 <generic_kprobe_actions+0x899>
    9f49:      	movq	%rbp, %rsi
    9f4c:      	callq	*%rax
    9f4e:      	testq	%rax, %rax
    9f51:      	je	0xa35d <generic_kprobe_actions+0xcad>
    9f57:      	incl	(%rax)
    9f59:      	jmp	0xa37f <generic_kprobe_actions+0xccf>
    9f5e:      	movl	$0x2, %eax
    9f63:      	xorl	%ecx, %ecx
    9f65:      	leaq	0x60(%rsp), %rdx
    9f6a:      	movq	%rbp, %rdi
    9f6d:      	movq	%r14, %rsi
    9f70:      	xorl	%ecx, %ecx
    9f72:      	callq	*%rax
    9f74:      	jmp	0xa007 <generic_kprobe_actions+0x957>
    9f79:      	movl	$0x2, %eax
    9f7e:      	xorl	%ecx, %ecx
    9f80:      	leaq	0x20(%rsp), %rdx
    9f85:      	movq	%rbp, %rdi
    9f88:      	movq	%r14, %rsi
    9f8b:      	xorl	%ecx, %ecx
    9f8d:      	callq	*%rax
    9f8f:      	testq	%rax, %rax
    9f92:      	leaq	0x40(%rsp), %rbp
    9f97:      	leaq	0x8(%rsp), %rsi
    9f9c:      	je	0xa3ce <generic_kprobe_actions+0xd1e>
    9fa2:      	negl	%eax
    9fa4:      	movw	%ax, 0x8(%rsp)
    9fa9:      	movw	$0x3, 0xa(%rsp)
    9fb0:      	movabsq	$0x20000006b, %rax      # imm = 0x20000006B
    9fba:      	movq	%rax, 0xc(%rsp)
    9fbf:      	movl	$0x1, %eax
    9fc4:      	movq	(%rip), %r14            # 0x9fcb <generic_kprobe_actions+0x91b>
    9fcb:      	movq	%r14, %rdi
    9fce:      	movq	%rsi, %r15
    9fd1:      	callq	*%rax
    9fd3:      	testq	%rax, %rax
    9fd6:      	je	0xa3af <generic_kprobe_actions+0xcff>
    9fdc:      	incl	(%rax)
    9fde:      	jmp	0xa3cb <generic_kprobe_actions+0xd1b>
    9fe3:      	movl	$0x1, 0x40(%rsp)
    9feb:      	movl	$0x2, %eax
    9ff0:      	xorl	%ecx, %ecx
    9ff2:      	leaq	0x40(%rsp), %rdx
    9ff7:      	movq	%rbp, %rdi
    9ffa:      	movq	%r14, %rsi
    9ffd:      	xorl	%ecx, %ecx
    9fff:      	callq	*%rax
    a001:      	movl	0x60(%rsp), %eax
    a005:      	movl	%eax, (%rbx)
    a007:      	movl	$0x4, %r14d
    a00d:      	movl	%r15d, %ebx
    a010:      	leaq	0x8(%rsp), %rsi
    a015:      	movl	$0x0, 0x8(%rsp)
    a01d:      	movl	$0x1, %eax
    a022:      	movq	(%rip), %rdi            # 0xa029 <generic_kprobe_actions+0x979>
    a029:      	callq	*%rax
    a02b:      	testq	%rax, %rax
    a02e:      	je	0xa035 <generic_kprobe_actions+0x985>
    a030:      	lock
    a031:      	incq	(%rax,%r14,8)
    a035:      	movl	%ebx, %r15d
    a038:      	movq	0x30(%rsp), %r14
    a03d:      	movq	0x18(%rsp), %rdx
    a042:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    a047:      	movl	$0x3, %eax
    a04c:      	leaq	0x8(%rsp), %rsi
    a051:      	movq	(%rip), %rdi            # 0xa058 <generic_kprobe_actions+0x9a8>
    a058:      	callq	*%rax
    a05a:      	movq	%rax, %rcx
    a05d:      	movq	0x30(%rsp), %r14
    a062:      	movq	%rbp, %rdx
    a065:      	testl	%ecx, %ecx
    a067:      	jne	0x97ba <generic_kprobe_actions+0x10a>
    a06d:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    a072:      	movl	$0x3, %eax
    a077:      	leaq	0x20(%rsp), %rsi
    a07c:      	movq	(%rip), %rdi            # 0xa083 <generic_kprobe_actions+0x9d3>
    a083:      	callq	*%rax
    a085:      	movq	%rax, %rcx
    a088:      	movq	%rbp, %rdx
    a08b:      	testl	%ecx, %ecx
    a08d:      	jne	0x97ba <generic_kprobe_actions+0x10a>
    a093:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    a098:      	movl	$0x2, %eax
    a09d:      	movl	$0x1, %ecx
    a0a2:      	leaq	0x6c(%rsp), %rdx
    a0a7:      	movq	%r14, %rdi
    a0aa:      	movq	%rbp, %rsi
    a0ad:      	callq	*%rax
    a0af:      	testq	%rax, %rax
    a0b2:      	je	0x9e11 <generic_kprobe_actions+0x761>
    a0b8:      	movq	%rax, %r14
    a0bb:      	negl	%eax
    a0bd:      	movw	%ax, 0x8(%rsp)
    a0c2:      	movw	$0x3, 0xa(%rsp)
    a0c9:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    a0d3:      	movq	%rax, 0xc(%rsp)
    a0d8:      	movl	$0x1, %eax
    a0dd:      	leaq	0x8(%rsp), %rsi
    a0e2:      	movq	(%rip), %rdi            # 0xa0e9 <generic_kprobe_actions+0xa39>
    a0e9:      	callq	*%rax
    a0eb:      	testq	%rax, %rax
    a0ee:      	je	0xa3d9 <generic_kprobe_actions+0xd29>
    a0f4:      	incl	(%rax)
    a0f6:      	jmp	0xa3fd <generic_kprobe_actions+0xd4d>
    a0fb:      	movl	0x10(%rcx), %eax
    a0fe:      	movl	%eax, %eax
    a100:      	movq	0x80(%rsp), %rcx
    a108:      	movq	%rax, 0x10(%rcx)
    a10c:      	movq	0x50(%rsp), %rdi
    a111:      	addq	$0x18, %rdi
    a115:      	movl	$0x4, %eax
    a11a:      	movl	$0xc8, %ecx
    a11f:      	movq	%rdi, 0x50(%rsp)
    a124:      	movl	$0xc8, %esi
    a129:      	callq	*%rax
    a12b:      	xorl	%r14d, %r14d
    a12e:      	jmp	0xa13e <generic_kprobe_actions+0xa8e>
    a130:      	addq	$0x4, %r14
    a134:      	cmpq	$0x14, %r14
    a138:      	je	0xa267 <generic_kprobe_actions+0xbb7>
    a13e:      	movl	$0x0, 0x20(%rsp)
    a146:      	movl	$0x1, %eax
    a14b:      	movq	(%rip), %rdi            # 0xa152 <generic_kprobe_actions+0xaa2>
    a152:      	leaq	0x20(%rsp), %rsi
    a157:      	callq	*%rax
    a159:      	testq	%rax, %rax
    a15c:      	je	0xa267 <generic_kprobe_actions+0xbb7>
    a162:      	movq	%rax, %rsi
    a165:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a16c:      	movl	$0x1, %eax
    a171:      	movq	(%rip), %rdi            # 0xa178 <generic_kprobe_actions+0xac8>
    a178:      	callq	*%rax
    a17a:      	testq	%rax, %rax
    a17d:      	je	0xa267 <generic_kprobe_actions+0xbb7>
    a183:      	cmpl	$-0x1, 0x40(%rax,%r14)
    a189:      	movq	0x18(%rsp), %rdx
    a18e:      	je	0xa267 <generic_kprobe_actions+0xbb7>
    a194:      	movq	0x5e78(%rdx,%r14,2), %rax
    a19c:      	movl	0x4(%rdx), %ecx
    a19f:      	cmpq	%rcx, %rax
    a1a2:      	jge	0xa267 <generic_kprobe_actions+0xbb7>
    a1a8:      	cmpq	$0x10, %r14
    a1ac:      	je	0xa219 <generic_kprobe_actions+0xb69>
    a1ae:      	movl	$0x0, 0x20(%rsp)
    a1b6:      	movl	$0x1, %eax
    a1bb:      	movq	(%rip), %rdi            # 0xa1c2 <generic_kprobe_actions+0xb12>
    a1c2:      	leaq	0x20(%rsp), %rsi
    a1c7:      	callq	*%rax
    a1c9:      	testq	%rax, %rax
    a1cc:      	je	0xa20c <generic_kprobe_actions+0xb5c>
    a1ce:      	movq	%rax, %rsi
    a1d1:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a1d8:      	movl	$0x1, %eax
    a1dd:      	movq	(%rip), %rdi            # 0xa1e4 <generic_kprobe_actions+0xb34>
    a1e4:      	callq	*%rax
    a1e6:      	testq	%rax, %rax
    a1e9:      	je	0xa20c <generic_kprobe_actions+0xb5c>
    a1eb:      	cmpl	$-0x1, 0x44(%rax,%r14)
    a1f1:      	movq	0x18(%rsp), %rdx
    a1f6:      	movq	0x5e78(%rdx,%r14,2), %rax
    a1fe:      	je	0xa219 <generic_kprobe_actions+0xb69>
    a200:      	movl	0x5e80(%rdx,%r14,2), %ebx
    a208:      	subl	%eax, %ebx
    a20a:      	jmp	0xa221 <generic_kprobe_actions+0xb71>
    a20c:      	movq	0x18(%rsp), %rdx
    a211:      	movq	0x5e78(%rdx,%r14,2), %rax
    a219:      	movl	0x4(%rdx), %ebx
    a21c:      	subl	%eax, %ebx
    a21e:      	addl	$0x4, %ebx
    a221:      	testl	%ebx, %ebx
    a223:      	jle	0xa130 <generic_kprobe_actions+0xa80>
    a229:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    a22e:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    a233:      	cmpl	$0x28, %ebx
    a236:      	movl	$0x28, %ecx
    a23b:      	cmovgel	%ecx, %ebx
    a23e:      	movzbl	%bpl, %ebp
    a242:      	movq	0x50(%rsp), %rcx
    a247:      	leaq	(%rcx,%rbp), %rdi
    a24b:      	addq	%rax, %rdx
    a24e:      	addq	$0x90, %rdx
    a255:      	movl	$0x4, %eax
    a25a:      	movl	%ebx, %esi
    a25c:      	callq	*%rax
    a25e:      	addl	%ebp, %ebx
    a260:      	movl	%ebx, %ebp
    a262:      	jmp	0xa130 <generic_kprobe_actions+0xa80>
    a267:      	movl	$0x1, %eax
    a26c:      	movq	(%rip), %rdi            # 0xa273 <generic_kprobe_actions+0xbc3>
    a273:      	movq	0x80(%rsp), %rsi
    a27b:      	callq	*%rax
    a27d:      	testq	%rax, %rax
    a280:      	movq	0x30(%rsp), %r14
    a285:      	je	0xa2a4 <generic_kprobe_actions+0xbf4>
    a287:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    a290:      	addq	0x8(%rsp), %rcx
    a295:      	cmpq	%rcx, (%rax)
    a298:      	jbe	0xa2a4 <generic_kprobe_actions+0xbf4>
    a29a:      	movl	$0x0, 0x5c(%rsp)
    a2a2:      	jmp	0xa2c3 <generic_kprobe_actions+0xc13>
    a2a4:      	movl	$0x2, %eax
    a2a9:      	xorl	%ecx, %ecx
    a2ab:      	movq	(%rip), %rdi            # 0xa2b2 <generic_kprobe_actions+0xc02>
    a2b2:      	leaq	0x8(%rsp), %rdx
    a2b7:      	movq	0x80(%rsp), %rsi
    a2bf:      	xorl	%ecx, %ecx
    a2c1:      	callq	*%rax
    a2c3:      	leal	0x3(%r15), %eax
    a2c7:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    a2cd:      	movq	0x18(%rsp), %rdx
    a2d2:      	je	0xa2fe <generic_kprobe_actions+0xc4e>
    a2d4:      	orb	$0x2, 0x1(%rdx)
    a2d8:      	movl	$0x1b, %eax
    a2dd:      	xorl	%ecx, %ecx
    a2df:      	movq	(%rip), %rsi            # 0xa2e6 <generic_kprobe_actions+0xc36>
    a2e6:      	movq	0x88(%rsp), %rdi
    a2ee:      	xorl	%edx, %edx
    a2f0:      	callq	*%rax
    a2f2:      	movq	0x18(%rsp), %rdx
    a2f7:      	movq	%rax, 0x80(%rdx)
    a2fe:      	addl	$0x4, %r15d
    a302:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    a308:      	je	0x97b0 <generic_kprobe_actions+0x100>
    a30e:      	orb	$0x4, 0x1(%rdx)
    a312:      	movl	$0x1b, %eax
    a317:      	movq	(%rip), %rsi            # 0xa31e <generic_kprobe_actions+0xc6e>
    a31e:      	movl	$0x100, %ecx            # imm = 0x100
    a323:      	movq	0x88(%rsp), %rdi
    a32b:      	movl	$0x100, %edx            # imm = 0x100
    a330:      	callq	*%rax
    a332:      	movq	0x18(%rsp), %rdx
    a337:      	movq	%rax, 0x88(%rdx)
    a33e:      	jmp	0x97b0 <generic_kprobe_actions+0x100>
    a343:      	movq	0x5e78(%rdx,%rax,8), %rax
    a34b:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a350:      	movq	0x90(%rdx,%rax), %r14
    a358:      	jmp	0x9d73 <generic_kprobe_actions+0x6c3>
    a35d:      	movl	$0x1, 0x60(%rsp)
    a365:      	movl	$0x2, %eax
    a36a:      	xorl	%ecx, %ecx
    a36c:      	leaq	0x60(%rsp), %rdx
    a371:      	movq	(%rip), %rdi            # 0xa378 <generic_kprobe_actions+0xcc8>
    a378:      	movq	%rbp, %rsi
    a37b:      	xorl	%ecx, %ecx
    a37d:      	callq	*%rax
    a37f:      	testl	%ebx, %ebx
    a381:      	je	0x9c2d <generic_kprobe_actions+0x57d>
    a387:      	movl	$0x1, %eax
    a38c:      	leaq	0x20(%rsp), %rsi
    a391:      	movq	(%rip), %rdi            # 0xa398 <generic_kprobe_actions+0xce8>
    a398:      	callq	*%rax
    a39a:      	testq	%rax, %rax
    a39d:      	je	0x9c2d <generic_kprobe_actions+0x57d>
    a3a3:      	movl	0x3c(%rsp), %ecx
    a3a7:      	lock
    a3a8:      	addl	%ecx, (%rax)
    a3aa:      	jmp	0x9c2d <generic_kprobe_actions+0x57d>
    a3af:      	movl	$0x1, 0x40(%rsp)
    a3b7:      	movl	$0x2, %eax
    a3bc:      	xorl	%ecx, %ecx
    a3be:      	movq	%r15, %rsi
    a3c1:      	movq	%r14, %rdi
    a3c4:      	movq	%rbp, %rdx
    a3c7:      	xorl	%ecx, %ecx
    a3c9:      	callq	*%rax
    a3cb:      	movq	%r15, %rsi
    a3ce:      	movl	$0x6, %r14d
    a3d4:      	jmp	0xa015 <generic_kprobe_actions+0x965>
    a3d9:      	movl	$0x1, 0x3c(%rsp)
    a3e1:      	movl	$0x2, %eax
    a3e6:      	xorl	%ecx, %ecx
    a3e8:      	leaq	0x3c(%rsp), %rdx
    a3ed:      	leaq	0x8(%rsp), %rsi
    a3f2:      	movq	(%rip), %rdi            # 0xa3f9 <generic_kprobe_actions+0xd49>
    a3f9:      	xorl	%ecx, %ecx
    a3fb:      	callq	*%rax
    a3fd:      	testl	%r14d, %r14d
    a400:      	je	0x9e11 <generic_kprobe_actions+0x761>
    a406:      	movl	$0x1, %eax
    a40b:      	movq	(%rip), %rdi            # 0xa412 <generic_kprobe_actions+0xd62>
    a412:      	movq	%rbp, %rsi
    a415:      	callq	*%rax
    a417:      	testq	%rax, %rax
    a41a:      	je	0x9e11 <generic_kprobe_actions+0x761>
    a420:      	movl	0x6c(%rsp), %ecx
    a424:      	lock
    a425:      	addl	%ecx, (%rax)
    a427:      	jmp	0x9e11 <generic_kprobe_actions+0x761>
    a42c:      	cmpb	$0x0, 0x5c(%rsp)
    a431:      	je	0xa453 <generic_kprobe_actions+0xda3>
    a433:      	movq	(%rip), %rsi            # 0xa43a <generic_kprobe_actions+0xd8a>
    a43a:      	movl	$0x5, %ecx
    a43f:      	movl	$0xc, %eax
    a444:      	movq	0x88(%rsp), %rdi
    a44c:      	movl	$0x5, %edx
    a451:      	callq	*%rax
    a453:      	xorl	%eax, %eax
    a455:      	addq	$0xa8, %rsp
    a45c:      	popq	%rbx
    a45d:      	popq	%r12
    a45f:      	popq	%r13
    a461:      	popq	%r14
    a463:      	popq	%r15
    a465:      	popq	%rbp
    a466:      	retq
    a467:      	nopw	(%rax,%rax)

000000000000a470 <generic_kprobe_output>:
    a470:      	pushq	%rbp
    a471:      	pushq	%r15
    a473:      	pushq	%r14
    a475:      	pushq	%r13
    a477:      	pushq	%r12
    a479:      	pushq	%rbx
    a47a:      	subq	$0x78, %rsp
    a47e:      	movq	%rdi, %rbx
    a481:      	movl	$0x0, 0x14(%rsp)
    a489:      	movq	(%rip), %rdi            # 0xa490 <generic_kprobe_output+0x20>
    a490:      	leaq	0x14(%rsp), %rsi
    a495:      	movl	$0x1, %eax
    a49a:      	callq	*%rax
    a49c:      	testq	%rax, %rax
    a49f:      	je	0xa97a <generic_kprobe_output+0x50a>
    a4a5:      	movq	%rax, %r14
    a4a8:      	cmpq	$0x0, 0x5ee8(%rax)
    a4b0:      	je	0xa7c4 <generic_kprobe_output+0x354>
    a4b6:      	movl	$0xe, %eax
    a4bb:      	callq	*%rax
    a4bd:      	movq	%rax, %r15
    a4c0:      	shrq	$0x20, %r15
    a4c4:      	movl	$0x23, %eax
    a4c9:      	callq	*%rax
    a4cb:      	movq	%rax, %r12
    a4ce:      	movl	%r15d, 0x28(%rsp)
    a4d3:      	movq	(%rip), %rdi            # 0xa4da <generic_kprobe_output+0x6a>
    a4da:      	leaq	0x28(%rsp), %rsi
    a4df:      	movl	$0x1, %eax
    a4e4:      	callq	*%rax
    a4e6:      	testq	%rax, %rax
    a4e9:      	je	0xa7c4 <generic_kprobe_output+0x354>
    a4ef:      	movq	%rax, %r15
    a4f2:      	leaq	0xd70(%r12), %rdx
    a4fa:      	leaq	0x70(%rsp), %rdi
    a4ff:      	movl	$0x8, %ecx
    a504:      	movl	$0x4, %eax
    a509:      	leaq	0x28(%r15), %r13
    a50d:      	movl	$0x4, %ebp
    a512:      	movl	$0x8, %esi
    a517:      	callq	*%rax
    a519:      	movq	0x70(%rsp), %rcx
    a51e:      	leaq	0x28(%rsp), %rdi
    a523:      	movl	$0x48, %edx
    a528:      	movl	$0x4, %eax
    a52d:      	movq	0x70(%rsp), %rdx
    a532:      	movl	$0x48, %esi
    a537:      	callq	*%rax
    a539:      	movl	$0x218, %edx            # imm = 0x218
    a53e:      	movq	0x30(%rsp), %rcx
    a543:      	addq	%rdx, %rcx
    a546:      	movl	$0x4, %esi
    a54b:      	movl	$0x4, %eax
    a550:      	addq	0x30(%rsp), %rdx
    a555:      	movq	%r13, %rdi
    a558:      	movl	$0x4, %esi
    a55d:      	callq	*%rax
    a55f:      	leaq	0x2c(%r15), %rdi
    a563:      	movl	$0x4d8, %edx            # imm = 0x4D8
    a568:      	movq	0x38(%rsp), %rcx
    a56d:      	addq	%rdx, %rcx
    a570:      	movl	$0x4, %esi
    a575:      	movl	$0x4, %eax
    a57a:      	addq	0x38(%rsp), %rdx
    a57f:      	movl	$0x4, %esi
    a584:      	callq	*%rax
    a586:      	leaq	0x30(%r15), %rdi
    a58a:      	movq	0x40(%rsp), %rcx
    a58f:      	addq	$0x58, %rcx
    a593:      	movl	$0x4, %edx
    a598:      	movl	$0x4, %eax
    a59d:      	movq	0x40(%rsp), %rdx
    a5a2:      	addq	$0x58, %rdx
    a5a6:      	movl	$0x4, %esi
    a5ab:      	callq	*%rax
    a5ad:      	movq	$0x0, 0x8(%rsp)
    a5b6:      	leaq	0xb58(%r12), %rdx
    a5be:      	leaq	0x8(%rsp), %rdi
    a5c3:      	movl	$0x8, %ecx
    a5c8:      	movl	$0x4, %eax
    a5cd:      	movl	$0x8, %esi
    a5d2:      	callq	*%rax
    a5d4:      	movq	0x8(%rsp), %rcx
    a5d9:      	testq	%rcx, %rcx
    a5dc:      	je	0xa672 <generic_kprobe_output+0x202>
    a5e2:      	movl	$0x0, 0x10(%rsp)
    a5ea:      	addq	$0x4, %rcx
    a5ee:      	leaq	0x10(%rsp), %rdi
    a5f3:      	movl	$0x4, %eax
    a5f8:      	movq	0x8(%rsp), %rdx
    a5fd:      	addq	$0x4, %rdx
    a601:      	movl	$0x4, %esi
    a606:      	callq	*%rax
    a608:      	movq	0x8(%rsp), %rax
    a60d:      	movslq	0x10(%rsp), %rcx
    a612:      	shlq	$0x4, %rcx
    a616:      	addq	%rax, %rcx
    a619:      	addq	$0x80, %rcx
    a620:      	leaq	0x18(%rsp), %rdi
    a625:      	movl	$0x10, %edx
    a62a:      	movl	$0x4, %eax
    a62f:      	movq	0x8(%rsp), %rcx
    a634:      	movslq	0x10(%rsp), %rdx
    a639:      	shlq	$0x4, %rdx
    a63d:      	addq	%rcx, %rdx
    a640:      	addq	$0x80, %rdx
    a647:      	movl	$0x10, %esi
    a64c:      	callq	*%rax
    a64e:      	leaq	0x34(%r15), %rdi
    a652:      	movl	$0x158, %edx            # imm = 0x158
    a657:      	movq	0x20(%rsp), %rcx
    a65c:      	addq	%rdx, %rcx
    a65f:      	movl	$0x4, %eax
    a664:      	addq	0x20(%rsp), %rdx
    a669:      	movl	$0x4, %esi
    a66e:      	callq	*%rax
    a670:      	jmp	0xa67a <generic_kprobe_output+0x20a>
    a672:      	movl	$0x0, 0x34(%r15)
    a67a:      	leaq	0x38(%r15), %rdi
    a67e:      	movl	$0x158, %r13d           # imm = 0x158
    a684:      	movq	0x48(%rsp), %rcx
    a689:      	addq	%r13, %rcx
    a68c:      	movl	$0x4, %edx
    a691:      	movl	$0x4, %eax
    a696:      	movq	0x48(%rsp), %rdx
    a69b:      	addq	%r13, %rdx
    a69e:      	movl	$0x4, %esi
    a6a3:      	callq	*%rax
    a6a5:      	leaq	0x3c(%r15), %rdi
    a6a9:      	movl	$0x118, %edx            # imm = 0x118
    a6ae:      	movq	0x50(%rsp), %rcx
    a6b3:      	addq	%rdx, %rcx
    a6b6:      	movl	$0x4, %esi
    a6bb:      	movl	$0x4, %eax
    a6c0:      	addq	0x50(%rsp), %rdx
    a6c5:      	movl	$0x4, %esi
    a6ca:      	callq	*%rax
    a6cc:      	leaq	0x40(%r15), %rdi
    a6d0:      	movl	$0x98, %ebp
    a6d5:      	movq	0x58(%rsp), %rcx
    a6da:      	addq	%rbp, %rcx
    a6dd:      	movl	$0x4, %edx
    a6e2:      	movl	$0x4, %eax
    a6e7:      	movq	0x58(%rsp), %rdx
    a6ec:      	addq	%rbp, %rdx
    a6ef:      	movl	$0x4, %esi
    a6f4:      	callq	*%rax
    a6f6:      	leaq	0x44(%r15), %rdi
    a6fa:      	movq	0x60(%rsp), %rcx
    a6ff:      	addq	%rbp, %rcx
    a702:      	movl	$0x4, %edx
    a707:      	movl	$0x4, %eax
    a70c:      	addq	0x60(%rsp), %rbp
    a711:      	movl	$0x4, %esi
    a716:      	movq	%rbp, %rdx
    a719:      	callq	*%rax
    a71b:      	leaq	0x48(%r15), %rdi
    a71f:      	movq	0x68(%rsp), %rcx
    a724:      	addq	$0x58, %rcx
    a728:      	movl	$0x4, %edx
    a72d:      	movl	$0x4, %eax
    a732:      	movq	0x68(%rsp), %rdx
    a737:      	addq	$0x58, %rdx
    a73b:      	movl	$0x4, %esi
    a740:      	callq	*%rax
    a742:      	movq	$0x0, 0x18(%rsp)
    a74b:      	movq	$0x0, 0x8(%rsp)
    a754:      	addq	$0xd00, %r12            # imm = 0xD00
    a75b:      	leaq	0x18(%rsp), %rdi
    a760:      	movl	$0x8, %ecx
    a765:      	movl	$0x4, %eax
    a76a:      	movl	$0x8, %esi
    a76f:      	movq	%r12, %rdx
    a772:      	callq	*%rax
    a774:      	movl	$0x90, %edx
    a779:      	movq	0x18(%rsp), %rcx
    a77e:      	addq	%rdx, %rcx
    a781:      	leaq	0x8(%rsp), %rdi
    a786:      	movl	$0x8, %esi
    a78b:      	movl	$0x4, %eax
    a790:      	addq	0x18(%rsp), %rdx
    a795:      	movl	$0x8, %esi
    a79a:      	callq	*%rax
    a79c:      	addq	$0x4c, %r15
    a7a0:      	movq	0x8(%rsp), %rcx
    a7a5:      	addq	%r13, %rcx
    a7a8:      	movl	$0x4, %edx
    a7ad:      	movl	$0x4, %eax
    a7b2:      	addq	0x8(%rsp), %r13
    a7b7:      	movq	%r15, %rdi
    a7ba:      	movl	$0x4, %esi
    a7bf:      	movq	%r13, %rdx
    a7c2:      	callq	*%rax
    a7c4:      	cmpq	$0x0, 0x5ef0(%r14)
    a7cc:      	je	0xa885 <generic_kprobe_output+0x415>
    a7d2:      	movl	$0xe, %eax
    a7d7:      	callq	*%rax
    a7d9:      	movq	%rax, %r15
    a7dc:      	shrq	$0x20, %r15
    a7e0:      	movl	$0x23, %eax
    a7e5:      	callq	*%rax
    a7e7:      	movq	%rax, %r12
    a7ea:      	movl	%r15d, 0x28(%rsp)
    a7ef:      	movq	(%rip), %rdi            # 0xa7f6 <generic_kprobe_output+0x386>
    a7f6:      	leaq	0x28(%rsp), %rsi
    a7fb:      	movl	$0x1, %eax
    a800:      	callq	*%rax
    a802:      	testq	%rax, %rax
    a805:      	je	0xa885 <generic_kprobe_output+0x415>
    a807:      	leaq	0x50(%rax), %r15
    a80b:      	addq	$0xd00, %r12            # imm = 0xD00
    a812:      	leaq	0x28(%rsp), %rdi
    a817:      	movl	$0x8, %ecx
    a81c:      	movq	%rax, %r13
    a81f:      	movl	$0x4, %eax
    a824:      	movl	$0x8, %esi
    a829:      	movq	%r12, %rdx
    a82c:      	callq	*%rax
    a82e:      	movq	0x28(%rsp), %r12
    a833:      	leaq	0x58(%r13), %rdi
    a837:      	leaq	0x40(%r12), %rdx
    a83c:      	movl	$0x8, %ecx
    a841:      	movl	$0x4, %eax
    a846:      	movl	$0x8, %esi
    a84b:      	callq	*%rax
    a84d:      	addq	$0x60, %r13
    a851:      	leaq	0x30(%r12), %rdx
    a856:      	movl	$0x8, %ecx
    a85b:      	movl	$0x4, %eax
    a860:      	movq	%r13, %rdi
    a863:      	movl	$0x8, %esi
    a868:      	callq	*%rax
    a86a:      	addq	$0x38, %r12
    a86e:      	movl	$0x8, %ecx
    a873:      	movl	$0x4, %eax
    a878:      	movq	%r15, %rdi
    a87b:      	movl	$0x8, %esi
    a880:      	movq	%r12, %rdx
    a883:      	callq	*%rax
    a885:      	movl	$0x90, %eax
    a88a:      	addl	0x4(%r14), %eax
    a88e:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    a893:      	cmpl	$0x2328, %eax           # imm = 0x2328
    a898:      	movl	$0x2328, %r8d           # imm = 0x2328
    a89e:      	cmovbl	%eax, %r8d
    a8a2:      	movq	(%rip), %rsi            # 0xa8a9 <generic_kprobe_output+0x439>
    a8a9:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    a8ae:      	movl	$0x19, %eax
    a8b3:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    a8b8:      	movq	%rbx, %rdi
    a8bb:      	movq	%r14, %rcx
    a8be:      	callq	*%rax
    a8c0:      	testq	%rax, %rax
    a8c3:      	js	0xa8f3 <generic_kprobe_output+0x483>
    a8c5:      	movl	$0x0, 0x28(%rsp)
    a8cd:      	movq	(%rip), %rdi            # 0xa8d4 <generic_kprobe_output+0x464>
    a8d4:      	leaq	0x28(%rsp), %rsi
    a8d9:      	movl	$0x1, %eax
    a8de:      	callq	*%rax
    a8e0:      	testq	%rax, %rax
    a8e3:      	je	0xa97a <generic_kprobe_output+0x50a>
    a8e9:      	lock
    a8ea:      	incq	0x8(%rax)
    a8ee:      	jmp	0xa97a <generic_kprobe_output+0x50a>
    a8f3:      	movq	%rax, %rbx
    a8f6:      	movl	$0x0, 0x28(%rsp)
    a8fe:      	movq	(%rip), %rdi            # 0xa905 <generic_kprobe_output+0x495>
    a905:      	leaq	0x28(%rsp), %rsi
    a90a:      	movl	$0x1, %eax
    a90f:      	callq	*%rax
    a911:      	testq	%rax, %rax
    a914:      	je	0xa97a <generic_kprobe_output+0x50a>
    a916:      	cmpq	$-0xc, %rbx
    a91a:      	jg	0xa936 <generic_kprobe_output+0x4c6>
    a91c:      	cmpq	$-0x1c, %rbx
    a920:      	je	0xa950 <generic_kprobe_output+0x4e0>
    a922:      	cmpq	$-0x16, %rbx
    a926:      	je	0xa968 <generic_kprobe_output+0x4f8>
    a928:      	cmpq	$-0x10, %rbx
    a92c:      	jne	0xa960 <generic_kprobe_output+0x4f0>
    a92e:      	addq	$0x2f0, %rax            # imm = 0x2F0
    a934:      	jmp	0xa976 <generic_kprobe_output+0x506>
    a936:      	cmpq	$-0xb, %rbx
    a93a:      	je	0xa958 <generic_kprobe_output+0x4e8>
    a93c:      	cmpq	$-0x7, %rbx
    a940:      	je	0xa970 <generic_kprobe_output+0x500>
    a942:      	cmpq	$-0x2, %rbx
    a946:      	jne	0xa960 <generic_kprobe_output+0x4f0>
    a948:      	addq	$0x2e0, %rax            # imm = 0x2E0
    a94e:      	jmp	0xa976 <generic_kprobe_output+0x506>
    a950:      	addq	$0x300, %rax            # imm = 0x300
    a956:      	jmp	0xa976 <generic_kprobe_output+0x506>
    a958:      	addq	$0x308, %rax            # imm = 0x308
    a95e:      	jmp	0xa976 <generic_kprobe_output+0x506>
    a960:      	addq	$0x2d8, %rax            # imm = 0x2D8
    a966:      	jmp	0xa976 <generic_kprobe_output+0x506>
    a968:      	addq	$0x2f8, %rax            # imm = 0x2F8
    a96e:      	jmp	0xa976 <generic_kprobe_output+0x506>
    a970:      	addq	$0x2e8, %rax            # imm = 0x2E8
    a976:      	lock
    a977:      	incq	(%rax)
    a97a:      	xorl	%eax, %eax
    a97c:      	addq	$0x78, %rsp
    a980:      	popq	%rbx
    a981:      	popq	%r12
    a983:      	popq	%r13
    a985:      	popq	%r14
    a987:      	popq	%r15
    a989:      	popq	%rbp
    a98a:      	retq
    a98b:      	nopl	(%rax,%rax)

000000000000a990 <generic_kprobe_path>:
    a990:      	pushq	%rbp
    a991:      	pushq	%r15
    a993:      	pushq	%r14
    a995:      	pushq	%r13
    a997:      	pushq	%r12
    a999:      	pushq	%rbx
    a99a:      	subq	$0x88, %rsp
    a9a1:      	movq	%rdi, %rbp
    a9a4:      	movl	$0x0, 0x70(%rsp)
    a9ac:      	movq	(%rip), %rdi            # 0xa9b3 <generic_kprobe_path+0x23>
    a9b3:      	leaq	0x70(%rsp), %rsi
    a9b8:      	movl	$0x1, %eax
    a9bd:      	callq	*%rax
    a9bf:      	testq	%rax, %rax
    a9c2:      	je	0x16809 <generic_kprobe_path+0xbe79>
    a9c8:      	movq	%rax, %r14
    a9cb:      	movl	0x6420(%rax), %eax
    a9d1:      	cmpl	$0x1, %eax
    a9d4:      	je	0xaa76 <generic_kprobe_path+0xe6>
    a9da:      	testl	%eax, %eax
    a9dc:      	jne	0x16809 <generic_kprobe_path+0xbe79>
    a9e2:      	movq	0x6440(%r14), %r12
    a9e9:      	movl	$0x0, 0x10(%rsp)
    a9f1:      	movq	(%rip), %rdi            # 0xa9f8 <generic_kprobe_path+0x68>
    a9f8:      	leaq	0x10(%rsp), %rsi
    a9fd:      	movl	$0x1, %eax
    aa02:      	callq	*%rax
    aa04:      	testq	%rax, %rax
    aa07:      	je	0x16809 <generic_kprobe_path+0xbe79>
    aa0d:      	movq	%rax, %r15
    aa10:      	addq	$0x8, %r12
    aa14:      	leaq	0x58(%rsp), %rdi
    aa19:      	movl	$0x8, %ecx
    aa1e:      	movl	$0x4, %eax
    aa23:      	movl	$0x8, %esi
    aa28:      	movq	%r12, %rdx
    aa2b:      	callq	*%rax
    aa2d:      	testq	%rax, %rax
    aa30:      	je	0x164b9 <generic_kprobe_path+0xbb29>
    aa36:      	negl	%eax
    aa38:      	movw	%ax, 0x18(%rsp)
    aa3d:      	movw	$0x6, 0x1a(%rsp)
    aa44:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    aa4e:      	movq	%rax, 0x1c(%rsp)
    aa53:      	movq	(%rip), %rdi            # 0xaa5a <generic_kprobe_path+0xca>
    aa5a:      	leaq	0x18(%rsp), %rsi
    aa5f:      	movl	$0x1, %eax
    aa64:      	callq	*%rax
    aa66:      	testq	%rax, %rax
    aa69:      	je	0x16498 <generic_kprobe_path+0xbb08>
    aa6f:      	incl	(%rax)
    aa71:      	jmp	0x164b9 <generic_kprobe_path+0xbb29>
    aa76:      	movq	0x6448(%r14), %rax
    aa7d:      	movq	%rax, 0x18(%rsp)
    aa82:      	movq	0x6450(%r14), %rax
    aa89:      	movq	%rax, 0x20(%rsp)
    aa8e:      	movq	$0x0, 0x28(%rsp)
    aa97:      	movq	0x6458(%r14), %rax
    aa9e:      	movq	%rax, 0x30(%rsp)
    aaa3:      	movq	0x6460(%r14), %rax
    aaaa:      	movq	%rax, 0x38(%rsp)
    aaaf:      	movq	0x6468(%r14), %rax
    aab6:      	movq	%rax, 0x40(%rsp)
    aabb:      	movq	$0x0, 0x48(%rsp)
    aac4:      	movl	$0x0, 0x50(%rsp)
    aacc:      	movb	$0x0, 0x54(%rsp)
    aad1:      	movl	$0x0, 0x74(%rsp)
    aad9:      	movq	(%rip), %rdi            # 0xaae0 <generic_kprobe_path+0x150>
    aae0:      	leaq	0x74(%rsp), %rsi
    aae5:      	movl	$0x1, %eax
    aaea:      	callq	*%rax
    aaec:      	testq	%rax, %rax
    aaef:      	je	0x16809 <generic_kprobe_path+0xbe79>
    aaf5:      	movq	%rbp, 0x78(%rsp)
    aafa:      	movq	%rax, 0x28(%rsp)
    aaff:      	movl	0x6424(%r14), %edx
    ab06:      	movl	%edx, %ecx
    ab08:      	andl	$0xfff, %ecx            # imm = 0xFFF
    ab0e:      	movq	%rax, %rsi
    ab11:      	movq	%rax, 0x80(%rsp)
    ab19:      	addq	%rax, %rcx
    ab1c:      	movq	%rcx, 0x48(%rsp)
    ab21:      	movl	%edx, 0x50(%rsp)
    ab25:      	movl	$0x200, %eax            # imm = 0x200
    ab2a:      	movl	$0x8, %r13d
    ab30:      	movq	%rsp, %rbp
    ab33:      	movl	%eax, 0x6c(%rsp)
    ab37:      	movq	0x30(%rsp), %r12
    ab3c:      	movq	0x38(%rsp), %rdx
    ab41:      	movq	0x40(%rsp), %r15
    ab46:      	cmpq	0x18(%rsp), %r12
    ab4b:      	jne	0xab58 <generic_kprobe_path+0x1c8>
    ab4d:      	cmpq	0x20(%rsp), %rdx
    ab52:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ab58:      	movl	$0x4, %eax
    ab5d:      	leaq	0x10(%rsp), %rdi
    ab62:      	movl	$0x8, %esi
    ab67:      	callq	*%rax
    ab69:      	cmpq	0x10(%rsp), %r12
    ab6e:      	je	0xac6d <generic_kprobe_path+0x2dd>
    ab74:      	leaq	0x18(%r12), %rbx
    ab79:      	movl	$0x4, %eax
    ab7e:      	movq	%rbp, %rdi
    ab81:      	movl	$0x8, %esi
    ab86:      	movq	%rbx, %rdx
    ab89:      	callq	*%rax
    ab8b:      	cmpq	%r12, (%rsp)
    ab8f:      	je	0xac6d <generic_kprobe_path+0x2dd>
    ab95:      	movl	$0x4, %eax
    ab9a:      	leaq	0x8(%rsp), %rdi
    ab9f:      	movl	$0x8, %esi
    aba4:      	movq	%rbx, %rdx
    aba7:      	callq	*%rax
    aba9:      	addq	$0x20, %r12
    abad:      	movl	$0x4, %eax
    abb2:      	leaq	0x58(%rsp), %rdi
    abb7:      	movl	$0x10, %ecx
    abbc:      	movl	$0x10, %esi
    abc1:      	movq	%r12, %rdx
    abc4:      	callq	*%rax
    abc6:      	movq	0x28(%rsp), %rbx
    abcb:      	movq	0x48(%rsp), %rax
    abd0:      	movl	0x5c(%rsp), %r15d
    abd5:      	subq	%rbx, %rax
    abd8:      	movl	0x50(%rsp), %r12d
    abdd:      	movl	%r15d, %edx
    abe0:      	subl	%r12d, %edx
    abe3:      	movl	$0x0, %ecx
    abe8:      	cmovbl	%ecx, %edx
    abeb:      	addq	0x60(%rsp), %rdx
    abf0:      	xorl	%esi, %esi
    abf2:      	cmpl	%r15d, %r12d
    abf5:      	seta	%sil
    abf9:      	movl	%r15d, %ecx
    abfc:      	cmovbl	%r12d, %ecx
    ac00:      	addl	%ecx, %esi
    ac02:      	movl	%r12d, %edi
    ac05:      	subl	%esi, %edi
    ac07:      	movl	%edi, 0x50(%rsp)
    ac0b:      	subq	%rsi, %rax
    ac0e:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ac14:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ac1a:      	ja	0x16402 <generic_kprobe_path+0xba72>
    ac20:      	cmpl	%r15d, %r12d
    ac23:      	jbe	0xac29 <generic_kprobe_path+0x299>
    ac25:      	movb	$0x2f, (%rbx,%rax)
    ac29:      	xorl	%edi, %edi
    ac2b:      	cmpl	%r15d, %r12d
    ac2e:      	seta	%dil
    ac32:      	movzbl	%cl, %esi
    ac35:      	addq	%rax, %rbx
    ac38:      	addq	%rbx, %rdi
    ac3b:      	movl	$0x4, %eax
    ac40:      	callq	*%rax
    ac42:      	movq	%rbx, 0x48(%rsp)
    ac47:      	cmpl	%r15d, %r12d
    ac4a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    ac50:      	movq	0x8(%rsp), %r12
    ac55:      	movq	%r12, 0x30(%rsp)
    ac5a:      	movq	0x38(%rsp), %rdx
    ac5f:      	movq	0x40(%rsp), %r15
    ac64:      	cmpq	0x18(%rsp), %r12
    ac69:      	je	0xacc5 <generic_kprobe_path+0x335>
    ac6b:      	jmp	0xacd0 <generic_kprobe_path+0x340>
    ac6d:      	leaq	0x10(%r15), %rdx
    ac71:      	movl	$0x4, %eax
    ac76:      	movq	%rbp, %rdi
    ac79:      	movl	$0x8, %esi
    ac7e:      	callq	*%rax
    ac80:      	movq	0x40(%rsp), %rax
    ac85:      	cmpq	(%rsp), %rax
    ac89:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ac8f:      	addq	$0x18, %r15
    ac93:      	movl	$0x4, %eax
    ac98:      	leaq	0x30(%rsp), %rdi
    ac9d:      	movl	$0x8, %esi
    aca2:      	movq	%r15, %rdx
    aca5:      	callq	*%rax
    aca7:      	movq	(%rsp), %r15
    acab:      	movq	%r15, 0x40(%rsp)
    acb0:      	leaq	0x20(%r15), %rdx
    acb4:      	movq	%rdx, 0x38(%rsp)
    acb9:      	movq	0x30(%rsp), %r12
    acbe:      	cmpq	0x18(%rsp), %r12
    acc3:      	jne	0xacd0 <generic_kprobe_path+0x340>
    acc5:      	cmpq	0x20(%rsp), %rdx
    acca:      	je	0x163fd <generic_kprobe_path+0xba6d>
    acd0:      	movl	$0x4, %eax
    acd5:      	leaq	0x10(%rsp), %rdi
    acda:      	movl	$0x8, %esi
    acdf:      	callq	*%rax
    ace1:      	cmpq	0x10(%rsp), %r12
    ace6:      	je	0xade5 <generic_kprobe_path+0x455>
    acec:      	leaq	0x18(%r12), %rbx
    acf1:      	movl	$0x4, %eax
    acf6:      	movq	%rbp, %rdi
    acf9:      	movl	$0x8, %esi
    acfe:      	movq	%rbx, %rdx
    ad01:      	callq	*%rax
    ad03:      	cmpq	%r12, (%rsp)
    ad07:      	je	0xade5 <generic_kprobe_path+0x455>
    ad0d:      	movl	$0x4, %eax
    ad12:      	leaq	0x8(%rsp), %rdi
    ad17:      	movl	$0x8, %esi
    ad1c:      	movq	%rbx, %rdx
    ad1f:      	callq	*%rax
    ad21:      	addq	$0x20, %r12
    ad25:      	movl	$0x4, %eax
    ad2a:      	leaq	0x58(%rsp), %rdi
    ad2f:      	movl	$0x10, %ecx
    ad34:      	movl	$0x10, %esi
    ad39:      	movq	%r12, %rdx
    ad3c:      	callq	*%rax
    ad3e:      	movq	0x28(%rsp), %rbx
    ad43:      	movq	0x48(%rsp), %rax
    ad48:      	movl	0x5c(%rsp), %r15d
    ad4d:      	subq	%rbx, %rax
    ad50:      	movl	0x50(%rsp), %r12d
    ad55:      	movl	%r15d, %edx
    ad58:      	subl	%r12d, %edx
    ad5b:      	movl	$0x0, %ecx
    ad60:      	cmovbl	%ecx, %edx
    ad63:      	addq	0x60(%rsp), %rdx
    ad68:      	xorl	%esi, %esi
    ad6a:      	cmpl	%r15d, %r12d
    ad6d:      	seta	%sil
    ad71:      	movl	%r15d, %ecx
    ad74:      	cmovbl	%r12d, %ecx
    ad78:      	addl	%ecx, %esi
    ad7a:      	movl	%r12d, %edi
    ad7d:      	subl	%esi, %edi
    ad7f:      	movl	%edi, 0x50(%rsp)
    ad83:      	subq	%rsi, %rax
    ad86:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ad8c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ad92:      	ja	0x16402 <generic_kprobe_path+0xba72>
    ad98:      	cmpl	%r15d, %r12d
    ad9b:      	jbe	0xada1 <generic_kprobe_path+0x411>
    ad9d:      	movb	$0x2f, (%rbx,%rax)
    ada1:      	xorl	%edi, %edi
    ada3:      	cmpl	%r15d, %r12d
    ada6:      	seta	%dil
    adaa:      	movzbl	%cl, %esi
    adad:      	addq	%rax, %rbx
    adb0:      	addq	%rbx, %rdi
    adb3:      	movl	$0x4, %eax
    adb8:      	callq	*%rax
    adba:      	movq	%rbx, 0x48(%rsp)
    adbf:      	cmpl	%r15d, %r12d
    adc2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    adc8:      	movq	0x8(%rsp), %r12
    adcd:      	movq	%r12, 0x30(%rsp)
    add2:      	movq	0x38(%rsp), %rdx
    add7:      	movq	0x40(%rsp), %r15
    addc:      	cmpq	0x18(%rsp), %r12
    ade1:      	je	0xae3d <generic_kprobe_path+0x4ad>
    ade3:      	jmp	0xae48 <generic_kprobe_path+0x4b8>
    ade5:      	leaq	0x10(%r15), %rdx
    ade9:      	movl	$0x4, %eax
    adee:      	movq	%rbp, %rdi
    adf1:      	movl	$0x8, %esi
    adf6:      	callq	*%rax
    adf8:      	movq	0x40(%rsp), %rax
    adfd:      	cmpq	(%rsp), %rax
    ae01:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ae07:      	addq	$0x18, %r15
    ae0b:      	movl	$0x4, %eax
    ae10:      	leaq	0x30(%rsp), %rdi
    ae15:      	movl	$0x8, %esi
    ae1a:      	movq	%r15, %rdx
    ae1d:      	callq	*%rax
    ae1f:      	movq	(%rsp), %r15
    ae23:      	movq	%r15, 0x40(%rsp)
    ae28:      	leaq	0x20(%r15), %rdx
    ae2c:      	movq	%rdx, 0x38(%rsp)
    ae31:      	movq	0x30(%rsp), %r12
    ae36:      	cmpq	0x18(%rsp), %r12
    ae3b:      	jne	0xae48 <generic_kprobe_path+0x4b8>
    ae3d:      	cmpq	0x20(%rsp), %rdx
    ae42:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ae48:      	movl	$0x4, %eax
    ae4d:      	leaq	0x10(%rsp), %rdi
    ae52:      	movl	$0x8, %esi
    ae57:      	callq	*%rax
    ae59:      	cmpq	0x10(%rsp), %r12
    ae5e:      	je	0xaf5d <generic_kprobe_path+0x5cd>
    ae64:      	leaq	0x18(%r12), %rbx
    ae69:      	movl	$0x4, %eax
    ae6e:      	movq	%rbp, %rdi
    ae71:      	movl	$0x8, %esi
    ae76:      	movq	%rbx, %rdx
    ae79:      	callq	*%rax
    ae7b:      	cmpq	%r12, (%rsp)
    ae7f:      	je	0xaf5d <generic_kprobe_path+0x5cd>
    ae85:      	movl	$0x4, %eax
    ae8a:      	leaq	0x8(%rsp), %rdi
    ae8f:      	movl	$0x8, %esi
    ae94:      	movq	%rbx, %rdx
    ae97:      	callq	*%rax
    ae99:      	addq	$0x20, %r12
    ae9d:      	movl	$0x4, %eax
    aea2:      	leaq	0x58(%rsp), %rdi
    aea7:      	movl	$0x10, %ecx
    aeac:      	movl	$0x10, %esi
    aeb1:      	movq	%r12, %rdx
    aeb4:      	callq	*%rax
    aeb6:      	movq	0x28(%rsp), %rbx
    aebb:      	movq	0x48(%rsp), %rax
    aec0:      	movl	0x5c(%rsp), %r15d
    aec5:      	subq	%rbx, %rax
    aec8:      	movl	0x50(%rsp), %r12d
    aecd:      	movl	%r15d, %edx
    aed0:      	subl	%r12d, %edx
    aed3:      	movl	$0x0, %ecx
    aed8:      	cmovbl	%ecx, %edx
    aedb:      	addq	0x60(%rsp), %rdx
    aee0:      	xorl	%esi, %esi
    aee2:      	cmpl	%r15d, %r12d
    aee5:      	seta	%sil
    aee9:      	movl	%r15d, %ecx
    aeec:      	cmovbl	%r12d, %ecx
    aef0:      	addl	%ecx, %esi
    aef2:      	movl	%r12d, %edi
    aef5:      	subl	%esi, %edi
    aef7:      	movl	%edi, 0x50(%rsp)
    aefb:      	subq	%rsi, %rax
    aefe:      	jb	0x16402 <generic_kprobe_path+0xba72>
    af04:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    af0a:      	ja	0x16402 <generic_kprobe_path+0xba72>
    af10:      	cmpl	%r15d, %r12d
    af13:      	jbe	0xaf19 <generic_kprobe_path+0x589>
    af15:      	movb	$0x2f, (%rbx,%rax)
    af19:      	xorl	%edi, %edi
    af1b:      	cmpl	%r15d, %r12d
    af1e:      	seta	%dil
    af22:      	movzbl	%cl, %esi
    af25:      	addq	%rax, %rbx
    af28:      	addq	%rbx, %rdi
    af2b:      	movl	$0x4, %eax
    af30:      	callq	*%rax
    af32:      	movq	%rbx, 0x48(%rsp)
    af37:      	cmpl	%r15d, %r12d
    af3a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    af40:      	movq	0x8(%rsp), %r12
    af45:      	movq	%r12, 0x30(%rsp)
    af4a:      	movq	0x38(%rsp), %rdx
    af4f:      	movq	0x40(%rsp), %r15
    af54:      	cmpq	0x18(%rsp), %r12
    af59:      	je	0xafb5 <generic_kprobe_path+0x625>
    af5b:      	jmp	0xafc0 <generic_kprobe_path+0x630>
    af5d:      	leaq	0x10(%r15), %rdx
    af61:      	movl	$0x4, %eax
    af66:      	movq	%rbp, %rdi
    af69:      	movl	$0x8, %esi
    af6e:      	callq	*%rax
    af70:      	movq	0x40(%rsp), %rax
    af75:      	cmpq	(%rsp), %rax
    af79:      	je	0x163fd <generic_kprobe_path+0xba6d>
    af7f:      	addq	$0x18, %r15
    af83:      	movl	$0x4, %eax
    af88:      	leaq	0x30(%rsp), %rdi
    af8d:      	movl	$0x8, %esi
    af92:      	movq	%r15, %rdx
    af95:      	callq	*%rax
    af97:      	movq	(%rsp), %r15
    af9b:      	movq	%r15, 0x40(%rsp)
    afa0:      	leaq	0x20(%r15), %rdx
    afa4:      	movq	%rdx, 0x38(%rsp)
    afa9:      	movq	0x30(%rsp), %r12
    afae:      	cmpq	0x18(%rsp), %r12
    afb3:      	jne	0xafc0 <generic_kprobe_path+0x630>
    afb5:      	cmpq	0x20(%rsp), %rdx
    afba:      	je	0x163fd <generic_kprobe_path+0xba6d>
    afc0:      	movl	$0x4, %eax
    afc5:      	leaq	0x10(%rsp), %rdi
    afca:      	movl	$0x8, %esi
    afcf:      	callq	*%rax
    afd1:      	cmpq	0x10(%rsp), %r12
    afd6:      	je	0xb0d5 <generic_kprobe_path+0x745>
    afdc:      	leaq	0x18(%r12), %rbx
    afe1:      	movl	$0x4, %eax
    afe6:      	movq	%rbp, %rdi
    afe9:      	movl	$0x8, %esi
    afee:      	movq	%rbx, %rdx
    aff1:      	callq	*%rax
    aff3:      	cmpq	%r12, (%rsp)
    aff7:      	je	0xb0d5 <generic_kprobe_path+0x745>
    affd:      	movl	$0x4, %eax
    b002:      	leaq	0x8(%rsp), %rdi
    b007:      	movl	$0x8, %esi
    b00c:      	movq	%rbx, %rdx
    b00f:      	callq	*%rax
    b011:      	addq	$0x20, %r12
    b015:      	movl	$0x4, %eax
    b01a:      	leaq	0x58(%rsp), %rdi
    b01f:      	movl	$0x10, %ecx
    b024:      	movl	$0x10, %esi
    b029:      	movq	%r12, %rdx
    b02c:      	callq	*%rax
    b02e:      	movq	0x28(%rsp), %rbx
    b033:      	movq	0x48(%rsp), %rax
    b038:      	movl	0x5c(%rsp), %r15d
    b03d:      	subq	%rbx, %rax
    b040:      	movl	0x50(%rsp), %r12d
    b045:      	movl	%r15d, %edx
    b048:      	subl	%r12d, %edx
    b04b:      	movl	$0x0, %ecx
    b050:      	cmovbl	%ecx, %edx
    b053:      	addq	0x60(%rsp), %rdx
    b058:      	xorl	%esi, %esi
    b05a:      	cmpl	%r15d, %r12d
    b05d:      	seta	%sil
    b061:      	movl	%r15d, %ecx
    b064:      	cmovbl	%r12d, %ecx
    b068:      	addl	%ecx, %esi
    b06a:      	movl	%r12d, %edi
    b06d:      	subl	%esi, %edi
    b06f:      	movl	%edi, 0x50(%rsp)
    b073:      	subq	%rsi, %rax
    b076:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b07c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b082:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b088:      	cmpl	%r15d, %r12d
    b08b:      	jbe	0xb091 <generic_kprobe_path+0x701>
    b08d:      	movb	$0x2f, (%rbx,%rax)
    b091:      	xorl	%edi, %edi
    b093:      	cmpl	%r15d, %r12d
    b096:      	seta	%dil
    b09a:      	movzbl	%cl, %esi
    b09d:      	addq	%rax, %rbx
    b0a0:      	addq	%rbx, %rdi
    b0a3:      	movl	$0x4, %eax
    b0a8:      	callq	*%rax
    b0aa:      	movq	%rbx, 0x48(%rsp)
    b0af:      	cmpl	%r15d, %r12d
    b0b2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b0b8:      	movq	0x8(%rsp), %r12
    b0bd:      	movq	%r12, 0x30(%rsp)
    b0c2:      	movq	0x38(%rsp), %rdx
    b0c7:      	movq	0x40(%rsp), %r15
    b0cc:      	cmpq	0x18(%rsp), %r12
    b0d1:      	je	0xb12d <generic_kprobe_path+0x79d>
    b0d3:      	jmp	0xb138 <generic_kprobe_path+0x7a8>
    b0d5:      	leaq	0x10(%r15), %rdx
    b0d9:      	movl	$0x4, %eax
    b0de:      	movq	%rbp, %rdi
    b0e1:      	movl	$0x8, %esi
    b0e6:      	callq	*%rax
    b0e8:      	movq	0x40(%rsp), %rax
    b0ed:      	cmpq	(%rsp), %rax
    b0f1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b0f7:      	addq	$0x18, %r15
    b0fb:      	movl	$0x4, %eax
    b100:      	leaq	0x30(%rsp), %rdi
    b105:      	movl	$0x8, %esi
    b10a:      	movq	%r15, %rdx
    b10d:      	callq	*%rax
    b10f:      	movq	(%rsp), %r15
    b113:      	movq	%r15, 0x40(%rsp)
    b118:      	leaq	0x20(%r15), %rdx
    b11c:      	movq	%rdx, 0x38(%rsp)
    b121:      	movq	0x30(%rsp), %r12
    b126:      	cmpq	0x18(%rsp), %r12
    b12b:      	jne	0xb138 <generic_kprobe_path+0x7a8>
    b12d:      	cmpq	0x20(%rsp), %rdx
    b132:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b138:      	movl	$0x4, %eax
    b13d:      	leaq	0x10(%rsp), %rdi
    b142:      	movl	$0x8, %esi
    b147:      	callq	*%rax
    b149:      	cmpq	0x10(%rsp), %r12
    b14e:      	je	0xb24d <generic_kprobe_path+0x8bd>
    b154:      	leaq	0x18(%r12), %rbx
    b159:      	movl	$0x4, %eax
    b15e:      	movq	%rbp, %rdi
    b161:      	movl	$0x8, %esi
    b166:      	movq	%rbx, %rdx
    b169:      	callq	*%rax
    b16b:      	cmpq	%r12, (%rsp)
    b16f:      	je	0xb24d <generic_kprobe_path+0x8bd>
    b175:      	movl	$0x4, %eax
    b17a:      	leaq	0x8(%rsp), %rdi
    b17f:      	movl	$0x8, %esi
    b184:      	movq	%rbx, %rdx
    b187:      	callq	*%rax
    b189:      	addq	$0x20, %r12
    b18d:      	movl	$0x4, %eax
    b192:      	leaq	0x58(%rsp), %rdi
    b197:      	movl	$0x10, %ecx
    b19c:      	movl	$0x10, %esi
    b1a1:      	movq	%r12, %rdx
    b1a4:      	callq	*%rax
    b1a6:      	movq	0x28(%rsp), %rbx
    b1ab:      	movq	0x48(%rsp), %rax
    b1b0:      	movl	0x5c(%rsp), %r15d
    b1b5:      	subq	%rbx, %rax
    b1b8:      	movl	0x50(%rsp), %r12d
    b1bd:      	movl	%r15d, %edx
    b1c0:      	subl	%r12d, %edx
    b1c3:      	movl	$0x0, %ecx
    b1c8:      	cmovbl	%ecx, %edx
    b1cb:      	addq	0x60(%rsp), %rdx
    b1d0:      	xorl	%esi, %esi
    b1d2:      	cmpl	%r15d, %r12d
    b1d5:      	seta	%sil
    b1d9:      	movl	%r15d, %ecx
    b1dc:      	cmovbl	%r12d, %ecx
    b1e0:      	addl	%ecx, %esi
    b1e2:      	movl	%r12d, %edi
    b1e5:      	subl	%esi, %edi
    b1e7:      	movl	%edi, 0x50(%rsp)
    b1eb:      	subq	%rsi, %rax
    b1ee:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b1f4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b1fa:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b200:      	cmpl	%r15d, %r12d
    b203:      	jbe	0xb209 <generic_kprobe_path+0x879>
    b205:      	movb	$0x2f, (%rbx,%rax)
    b209:      	xorl	%edi, %edi
    b20b:      	cmpl	%r15d, %r12d
    b20e:      	seta	%dil
    b212:      	movzbl	%cl, %esi
    b215:      	addq	%rax, %rbx
    b218:      	addq	%rbx, %rdi
    b21b:      	movl	$0x4, %eax
    b220:      	callq	*%rax
    b222:      	movq	%rbx, 0x48(%rsp)
    b227:      	cmpl	%r15d, %r12d
    b22a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b230:      	movq	0x8(%rsp), %r12
    b235:      	movq	%r12, 0x30(%rsp)
    b23a:      	movq	0x38(%rsp), %rdx
    b23f:      	movq	0x40(%rsp), %r15
    b244:      	cmpq	0x18(%rsp), %r12
    b249:      	je	0xb2a5 <generic_kprobe_path+0x915>
    b24b:      	jmp	0xb2b0 <generic_kprobe_path+0x920>
    b24d:      	leaq	0x10(%r15), %rdx
    b251:      	movl	$0x4, %eax
    b256:      	movq	%rbp, %rdi
    b259:      	movl	$0x8, %esi
    b25e:      	callq	*%rax
    b260:      	movq	0x40(%rsp), %rax
    b265:      	cmpq	(%rsp), %rax
    b269:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b26f:      	addq	$0x18, %r15
    b273:      	movl	$0x4, %eax
    b278:      	leaq	0x30(%rsp), %rdi
    b27d:      	movl	$0x8, %esi
    b282:      	movq	%r15, %rdx
    b285:      	callq	*%rax
    b287:      	movq	(%rsp), %r15
    b28b:      	movq	%r15, 0x40(%rsp)
    b290:      	leaq	0x20(%r15), %rdx
    b294:      	movq	%rdx, 0x38(%rsp)
    b299:      	movq	0x30(%rsp), %r12
    b29e:      	cmpq	0x18(%rsp), %r12
    b2a3:      	jne	0xb2b0 <generic_kprobe_path+0x920>
    b2a5:      	cmpq	0x20(%rsp), %rdx
    b2aa:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b2b0:      	movl	$0x4, %eax
    b2b5:      	leaq	0x10(%rsp), %rdi
    b2ba:      	movl	$0x8, %esi
    b2bf:      	callq	*%rax
    b2c1:      	cmpq	0x10(%rsp), %r12
    b2c6:      	je	0xb3c5 <generic_kprobe_path+0xa35>
    b2cc:      	leaq	0x18(%r12), %rbx
    b2d1:      	movl	$0x4, %eax
    b2d6:      	movq	%rbp, %rdi
    b2d9:      	movl	$0x8, %esi
    b2de:      	movq	%rbx, %rdx
    b2e1:      	callq	*%rax
    b2e3:      	cmpq	%r12, (%rsp)
    b2e7:      	je	0xb3c5 <generic_kprobe_path+0xa35>
    b2ed:      	movl	$0x4, %eax
    b2f2:      	leaq	0x8(%rsp), %rdi
    b2f7:      	movl	$0x8, %esi
    b2fc:      	movq	%rbx, %rdx
    b2ff:      	callq	*%rax
    b301:      	addq	$0x20, %r12
    b305:      	movl	$0x4, %eax
    b30a:      	leaq	0x58(%rsp), %rdi
    b30f:      	movl	$0x10, %ecx
    b314:      	movl	$0x10, %esi
    b319:      	movq	%r12, %rdx
    b31c:      	callq	*%rax
    b31e:      	movq	0x28(%rsp), %rbx
    b323:      	movq	0x48(%rsp), %rax
    b328:      	movl	0x5c(%rsp), %r15d
    b32d:      	subq	%rbx, %rax
    b330:      	movl	0x50(%rsp), %r12d
    b335:      	movl	%r15d, %edx
    b338:      	subl	%r12d, %edx
    b33b:      	movl	$0x0, %ecx
    b340:      	cmovbl	%ecx, %edx
    b343:      	addq	0x60(%rsp), %rdx
    b348:      	xorl	%esi, %esi
    b34a:      	cmpl	%r15d, %r12d
    b34d:      	seta	%sil
    b351:      	movl	%r15d, %ecx
    b354:      	cmovbl	%r12d, %ecx
    b358:      	addl	%ecx, %esi
    b35a:      	movl	%r12d, %edi
    b35d:      	subl	%esi, %edi
    b35f:      	movl	%edi, 0x50(%rsp)
    b363:      	subq	%rsi, %rax
    b366:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b36c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b372:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b378:      	cmpl	%r15d, %r12d
    b37b:      	jbe	0xb381 <generic_kprobe_path+0x9f1>
    b37d:      	movb	$0x2f, (%rbx,%rax)
    b381:      	xorl	%edi, %edi
    b383:      	cmpl	%r15d, %r12d
    b386:      	seta	%dil
    b38a:      	movzbl	%cl, %esi
    b38d:      	addq	%rax, %rbx
    b390:      	addq	%rbx, %rdi
    b393:      	movl	$0x4, %eax
    b398:      	callq	*%rax
    b39a:      	movq	%rbx, 0x48(%rsp)
    b39f:      	cmpl	%r15d, %r12d
    b3a2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b3a8:      	movq	0x8(%rsp), %r12
    b3ad:      	movq	%r12, 0x30(%rsp)
    b3b2:      	movq	0x38(%rsp), %rdx
    b3b7:      	movq	0x40(%rsp), %r15
    b3bc:      	cmpq	0x18(%rsp), %r12
    b3c1:      	je	0xb41d <generic_kprobe_path+0xa8d>
    b3c3:      	jmp	0xb428 <generic_kprobe_path+0xa98>
    b3c5:      	leaq	0x10(%r15), %rdx
    b3c9:      	movl	$0x4, %eax
    b3ce:      	movq	%rbp, %rdi
    b3d1:      	movl	$0x8, %esi
    b3d6:      	callq	*%rax
    b3d8:      	movq	0x40(%rsp), %rax
    b3dd:      	cmpq	(%rsp), %rax
    b3e1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b3e7:      	addq	$0x18, %r15
    b3eb:      	movl	$0x4, %eax
    b3f0:      	leaq	0x30(%rsp), %rdi
    b3f5:      	movl	$0x8, %esi
    b3fa:      	movq	%r15, %rdx
    b3fd:      	callq	*%rax
    b3ff:      	movq	(%rsp), %r15
    b403:      	movq	%r15, 0x40(%rsp)
    b408:      	leaq	0x20(%r15), %rdx
    b40c:      	movq	%rdx, 0x38(%rsp)
    b411:      	movq	0x30(%rsp), %r12
    b416:      	cmpq	0x18(%rsp), %r12
    b41b:      	jne	0xb428 <generic_kprobe_path+0xa98>
    b41d:      	cmpq	0x20(%rsp), %rdx
    b422:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b428:      	movl	$0x4, %eax
    b42d:      	leaq	0x10(%rsp), %rdi
    b432:      	movl	$0x8, %esi
    b437:      	callq	*%rax
    b439:      	cmpq	0x10(%rsp), %r12
    b43e:      	je	0xb53d <generic_kprobe_path+0xbad>
    b444:      	leaq	0x18(%r12), %rbx
    b449:      	movl	$0x4, %eax
    b44e:      	movq	%rbp, %rdi
    b451:      	movl	$0x8, %esi
    b456:      	movq	%rbx, %rdx
    b459:      	callq	*%rax
    b45b:      	cmpq	%r12, (%rsp)
    b45f:      	je	0xb53d <generic_kprobe_path+0xbad>
    b465:      	movl	$0x4, %eax
    b46a:      	leaq	0x8(%rsp), %rdi
    b46f:      	movl	$0x8, %esi
    b474:      	movq	%rbx, %rdx
    b477:      	callq	*%rax
    b479:      	addq	$0x20, %r12
    b47d:      	movl	$0x4, %eax
    b482:      	leaq	0x58(%rsp), %rdi
    b487:      	movl	$0x10, %ecx
    b48c:      	movl	$0x10, %esi
    b491:      	movq	%r12, %rdx
    b494:      	callq	*%rax
    b496:      	movq	0x28(%rsp), %rbx
    b49b:      	movq	0x48(%rsp), %rax
    b4a0:      	movl	0x5c(%rsp), %r15d
    b4a5:      	subq	%rbx, %rax
    b4a8:      	movl	0x50(%rsp), %r12d
    b4ad:      	movl	%r15d, %edx
    b4b0:      	subl	%r12d, %edx
    b4b3:      	movl	$0x0, %ecx
    b4b8:      	cmovbl	%ecx, %edx
    b4bb:      	addq	0x60(%rsp), %rdx
    b4c0:      	xorl	%esi, %esi
    b4c2:      	cmpl	%r15d, %r12d
    b4c5:      	seta	%sil
    b4c9:      	movl	%r15d, %ecx
    b4cc:      	cmovbl	%r12d, %ecx
    b4d0:      	addl	%ecx, %esi
    b4d2:      	movl	%r12d, %edi
    b4d5:      	subl	%esi, %edi
    b4d7:      	movl	%edi, 0x50(%rsp)
    b4db:      	subq	%rsi, %rax
    b4de:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b4e4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b4ea:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b4f0:      	cmpl	%r15d, %r12d
    b4f3:      	jbe	0xb4f9 <generic_kprobe_path+0xb69>
    b4f5:      	movb	$0x2f, (%rbx,%rax)
    b4f9:      	xorl	%edi, %edi
    b4fb:      	cmpl	%r15d, %r12d
    b4fe:      	seta	%dil
    b502:      	movzbl	%cl, %esi
    b505:      	addq	%rax, %rbx
    b508:      	addq	%rbx, %rdi
    b50b:      	movl	$0x4, %eax
    b510:      	callq	*%rax
    b512:      	movq	%rbx, 0x48(%rsp)
    b517:      	cmpl	%r15d, %r12d
    b51a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b520:      	movq	0x8(%rsp), %r12
    b525:      	movq	%r12, 0x30(%rsp)
    b52a:      	movq	0x38(%rsp), %rdx
    b52f:      	movq	0x40(%rsp), %r15
    b534:      	cmpq	0x18(%rsp), %r12
    b539:      	je	0xb595 <generic_kprobe_path+0xc05>
    b53b:      	jmp	0xb5a0 <generic_kprobe_path+0xc10>
    b53d:      	leaq	0x10(%r15), %rdx
    b541:      	movl	$0x4, %eax
    b546:      	movq	%rbp, %rdi
    b549:      	movl	$0x8, %esi
    b54e:      	callq	*%rax
    b550:      	movq	0x40(%rsp), %rax
    b555:      	cmpq	(%rsp), %rax
    b559:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b55f:      	addq	$0x18, %r15
    b563:      	movl	$0x4, %eax
    b568:      	leaq	0x30(%rsp), %rdi
    b56d:      	movl	$0x8, %esi
    b572:      	movq	%r15, %rdx
    b575:      	callq	*%rax
    b577:      	movq	(%rsp), %r15
    b57b:      	movq	%r15, 0x40(%rsp)
    b580:      	leaq	0x20(%r15), %rdx
    b584:      	movq	%rdx, 0x38(%rsp)
    b589:      	movq	0x30(%rsp), %r12
    b58e:      	cmpq	0x18(%rsp), %r12
    b593:      	jne	0xb5a0 <generic_kprobe_path+0xc10>
    b595:      	cmpq	0x20(%rsp), %rdx
    b59a:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b5a0:      	movl	$0x4, %eax
    b5a5:      	leaq	0x10(%rsp), %rdi
    b5aa:      	movl	$0x8, %esi
    b5af:      	callq	*%rax
    b5b1:      	cmpq	0x10(%rsp), %r12
    b5b6:      	je	0xb6b5 <generic_kprobe_path+0xd25>
    b5bc:      	leaq	0x18(%r12), %rbx
    b5c1:      	movl	$0x4, %eax
    b5c6:      	movq	%rbp, %rdi
    b5c9:      	movl	$0x8, %esi
    b5ce:      	movq	%rbx, %rdx
    b5d1:      	callq	*%rax
    b5d3:      	cmpq	%r12, (%rsp)
    b5d7:      	je	0xb6b5 <generic_kprobe_path+0xd25>
    b5dd:      	movl	$0x4, %eax
    b5e2:      	leaq	0x8(%rsp), %rdi
    b5e7:      	movl	$0x8, %esi
    b5ec:      	movq	%rbx, %rdx
    b5ef:      	callq	*%rax
    b5f1:      	addq	$0x20, %r12
    b5f5:      	movl	$0x4, %eax
    b5fa:      	leaq	0x58(%rsp), %rdi
    b5ff:      	movl	$0x10, %ecx
    b604:      	movl	$0x10, %esi
    b609:      	movq	%r12, %rdx
    b60c:      	callq	*%rax
    b60e:      	movq	0x28(%rsp), %rbx
    b613:      	movq	0x48(%rsp), %rax
    b618:      	movl	0x5c(%rsp), %r15d
    b61d:      	subq	%rbx, %rax
    b620:      	movl	0x50(%rsp), %r12d
    b625:      	movl	%r15d, %edx
    b628:      	subl	%r12d, %edx
    b62b:      	movl	$0x0, %ecx
    b630:      	cmovbl	%ecx, %edx
    b633:      	addq	0x60(%rsp), %rdx
    b638:      	xorl	%esi, %esi
    b63a:      	cmpl	%r15d, %r12d
    b63d:      	seta	%sil
    b641:      	movl	%r15d, %ecx
    b644:      	cmovbl	%r12d, %ecx
    b648:      	addl	%ecx, %esi
    b64a:      	movl	%r12d, %edi
    b64d:      	subl	%esi, %edi
    b64f:      	movl	%edi, 0x50(%rsp)
    b653:      	subq	%rsi, %rax
    b656:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b65c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b662:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b668:      	cmpl	%r15d, %r12d
    b66b:      	jbe	0xb671 <generic_kprobe_path+0xce1>
    b66d:      	movb	$0x2f, (%rbx,%rax)
    b671:      	xorl	%edi, %edi
    b673:      	cmpl	%r15d, %r12d
    b676:      	seta	%dil
    b67a:      	movzbl	%cl, %esi
    b67d:      	addq	%rax, %rbx
    b680:      	addq	%rbx, %rdi
    b683:      	movl	$0x4, %eax
    b688:      	callq	*%rax
    b68a:      	movq	%rbx, 0x48(%rsp)
    b68f:      	cmpl	%r15d, %r12d
    b692:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b698:      	movq	0x8(%rsp), %r12
    b69d:      	movq	%r12, 0x30(%rsp)
    b6a2:      	movq	0x38(%rsp), %rdx
    b6a7:      	movq	0x40(%rsp), %r15
    b6ac:      	cmpq	0x18(%rsp), %r12
    b6b1:      	je	0xb70d <generic_kprobe_path+0xd7d>
    b6b3:      	jmp	0xb718 <generic_kprobe_path+0xd88>
    b6b5:      	leaq	0x10(%r15), %rdx
    b6b9:      	movl	$0x4, %eax
    b6be:      	movq	%rbp, %rdi
    b6c1:      	movl	$0x8, %esi
    b6c6:      	callq	*%rax
    b6c8:      	movq	0x40(%rsp), %rax
    b6cd:      	cmpq	(%rsp), %rax
    b6d1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b6d7:      	addq	$0x18, %r15
    b6db:      	movl	$0x4, %eax
    b6e0:      	leaq	0x30(%rsp), %rdi
    b6e5:      	movl	$0x8, %esi
    b6ea:      	movq	%r15, %rdx
    b6ed:      	callq	*%rax
    b6ef:      	movq	(%rsp), %r15
    b6f3:      	movq	%r15, 0x40(%rsp)
    b6f8:      	leaq	0x20(%r15), %rdx
    b6fc:      	movq	%rdx, 0x38(%rsp)
    b701:      	movq	0x30(%rsp), %r12
    b706:      	cmpq	0x18(%rsp), %r12
    b70b:      	jne	0xb718 <generic_kprobe_path+0xd88>
    b70d:      	cmpq	0x20(%rsp), %rdx
    b712:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b718:      	movl	$0x4, %eax
    b71d:      	leaq	0x10(%rsp), %rdi
    b722:      	movl	$0x8, %esi
    b727:      	callq	*%rax
    b729:      	cmpq	0x10(%rsp), %r12
    b72e:      	je	0xb82d <generic_kprobe_path+0xe9d>
    b734:      	leaq	0x18(%r12), %rbx
    b739:      	movl	$0x4, %eax
    b73e:      	movq	%rbp, %rdi
    b741:      	movl	$0x8, %esi
    b746:      	movq	%rbx, %rdx
    b749:      	callq	*%rax
    b74b:      	cmpq	%r12, (%rsp)
    b74f:      	je	0xb82d <generic_kprobe_path+0xe9d>
    b755:      	movl	$0x4, %eax
    b75a:      	leaq	0x8(%rsp), %rdi
    b75f:      	movl	$0x8, %esi
    b764:      	movq	%rbx, %rdx
    b767:      	callq	*%rax
    b769:      	addq	$0x20, %r12
    b76d:      	movl	$0x4, %eax
    b772:      	leaq	0x58(%rsp), %rdi
    b777:      	movl	$0x10, %ecx
    b77c:      	movl	$0x10, %esi
    b781:      	movq	%r12, %rdx
    b784:      	callq	*%rax
    b786:      	movq	0x28(%rsp), %rbx
    b78b:      	movq	0x48(%rsp), %rax
    b790:      	movl	0x5c(%rsp), %r15d
    b795:      	subq	%rbx, %rax
    b798:      	movl	0x50(%rsp), %r12d
    b79d:      	movl	%r15d, %edx
    b7a0:      	subl	%r12d, %edx
    b7a3:      	movl	$0x0, %ecx
    b7a8:      	cmovbl	%ecx, %edx
    b7ab:      	addq	0x60(%rsp), %rdx
    b7b0:      	xorl	%esi, %esi
    b7b2:      	cmpl	%r15d, %r12d
    b7b5:      	seta	%sil
    b7b9:      	movl	%r15d, %ecx
    b7bc:      	cmovbl	%r12d, %ecx
    b7c0:      	addl	%ecx, %esi
    b7c2:      	movl	%r12d, %edi
    b7c5:      	subl	%esi, %edi
    b7c7:      	movl	%edi, 0x50(%rsp)
    b7cb:      	subq	%rsi, %rax
    b7ce:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b7d4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b7da:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b7e0:      	cmpl	%r15d, %r12d
    b7e3:      	jbe	0xb7e9 <generic_kprobe_path+0xe59>
    b7e5:      	movb	$0x2f, (%rbx,%rax)
    b7e9:      	xorl	%edi, %edi
    b7eb:      	cmpl	%r15d, %r12d
    b7ee:      	seta	%dil
    b7f2:      	movzbl	%cl, %esi
    b7f5:      	addq	%rax, %rbx
    b7f8:      	addq	%rbx, %rdi
    b7fb:      	movl	$0x4, %eax
    b800:      	callq	*%rax
    b802:      	movq	%rbx, 0x48(%rsp)
    b807:      	cmpl	%r15d, %r12d
    b80a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b810:      	movq	0x8(%rsp), %r12
    b815:      	movq	%r12, 0x30(%rsp)
    b81a:      	movq	0x38(%rsp), %rdx
    b81f:      	movq	0x40(%rsp), %r15
    b824:      	cmpq	0x18(%rsp), %r12
    b829:      	je	0xb885 <generic_kprobe_path+0xef5>
    b82b:      	jmp	0xb890 <generic_kprobe_path+0xf00>
    b82d:      	leaq	0x10(%r15), %rdx
    b831:      	movl	$0x4, %eax
    b836:      	movq	%rbp, %rdi
    b839:      	movl	$0x8, %esi
    b83e:      	callq	*%rax
    b840:      	movq	0x40(%rsp), %rax
    b845:      	cmpq	(%rsp), %rax
    b849:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b84f:      	addq	$0x18, %r15
    b853:      	movl	$0x4, %eax
    b858:      	leaq	0x30(%rsp), %rdi
    b85d:      	movl	$0x8, %esi
    b862:      	movq	%r15, %rdx
    b865:      	callq	*%rax
    b867:      	movq	(%rsp), %r15
    b86b:      	movq	%r15, 0x40(%rsp)
    b870:      	leaq	0x20(%r15), %rdx
    b874:      	movq	%rdx, 0x38(%rsp)
    b879:      	movq	0x30(%rsp), %r12
    b87e:      	cmpq	0x18(%rsp), %r12
    b883:      	jne	0xb890 <generic_kprobe_path+0xf00>
    b885:      	cmpq	0x20(%rsp), %rdx
    b88a:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b890:      	movl	$0x4, %eax
    b895:      	leaq	0x10(%rsp), %rdi
    b89a:      	movl	$0x8, %esi
    b89f:      	callq	*%rax
    b8a1:      	cmpq	0x10(%rsp), %r12
    b8a6:      	je	0xb99e <generic_kprobe_path+0x100e>
    b8ac:      	leaq	0x18(%r12), %rbx
    b8b1:      	movl	$0x4, %eax
    b8b6:      	movq	%rbp, %rdi
    b8b9:      	movl	$0x8, %esi
    b8be:      	movq	%rbx, %rdx
    b8c1:      	callq	*%rax
    b8c3:      	cmpq	%r12, (%rsp)
    b8c7:      	je	0xb99e <generic_kprobe_path+0x100e>
    b8cd:      	movl	$0x4, %eax
    b8d2:      	leaq	0x8(%rsp), %rdi
    b8d7:      	movl	$0x8, %esi
    b8dc:      	movq	%rbx, %rdx
    b8df:      	callq	*%rax
    b8e1:      	addq	$0x20, %r12
    b8e5:      	movl	$0x4, %eax
    b8ea:      	leaq	0x58(%rsp), %rdi
    b8ef:      	movl	$0x10, %ecx
    b8f4:      	movl	$0x10, %esi
    b8f9:      	movq	%r12, %rdx
    b8fc:      	callq	*%rax
    b8fe:      	movq	0x28(%rsp), %rbx
    b903:      	movq	0x48(%rsp), %rax
    b908:      	movl	0x5c(%rsp), %r15d
    b90d:      	subq	%rbx, %rax
    b910:      	movl	0x50(%rsp), %r12d
    b915:      	movl	%r15d, %edx
    b918:      	subl	%r12d, %edx
    b91b:      	movl	$0x0, %ecx
    b920:      	cmovbl	%ecx, %edx
    b923:      	addq	0x60(%rsp), %rdx
    b928:      	xorl	%esi, %esi
    b92a:      	cmpl	%r15d, %r12d
    b92d:      	seta	%sil
    b931:      	movl	%r15d, %ecx
    b934:      	cmovbl	%r12d, %ecx
    b938:      	addl	%ecx, %esi
    b93a:      	movl	%r12d, %edi
    b93d:      	subl	%esi, %edi
    b93f:      	movl	%edi, 0x50(%rsp)
    b943:      	subq	%rsi, %rax
    b946:      	jb	0x16402 <generic_kprobe_path+0xba72>
    b94c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b952:      	ja	0x16402 <generic_kprobe_path+0xba72>
    b958:      	cmpl	%r15d, %r12d
    b95b:      	jbe	0xb961 <generic_kprobe_path+0xfd1>
    b95d:      	movb	$0x2f, (%rbx,%rax)
    b961:      	xorl	%edi, %edi
    b963:      	cmpl	%r15d, %r12d
    b966:      	seta	%dil
    b96a:      	movzbl	%cl, %esi
    b96d:      	addq	%rax, %rbx
    b970:      	addq	%rbx, %rdi
    b973:      	movl	$0x4, %eax
    b978:      	callq	*%rax
    b97a:      	movq	%rbx, 0x48(%rsp)
    b97f:      	cmpl	%r15d, %r12d
    b982:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    b988:      	movq	0x8(%rsp), %r12
    b98d:      	movq	%r12, 0x30(%rsp)
    b992:      	movq	0x38(%rsp), %rdx
    b997:      	movq	0x40(%rsp), %r15
    b99c:      	jmp	0xb9ef <generic_kprobe_path+0x105f>
    b99e:      	leaq	0x10(%r15), %rdx
    b9a2:      	movl	$0x4, %eax
    b9a7:      	movq	%rbp, %rdi
    b9aa:      	movl	$0x8, %esi
    b9af:      	callq	*%rax
    b9b1:      	movq	0x40(%rsp), %rax
    b9b6:      	cmpq	(%rsp), %rax
    b9ba:      	je	0x163fd <generic_kprobe_path+0xba6d>
    b9c0:      	addq	$0x18, %r15
    b9c4:      	movl	$0x4, %eax
    b9c9:      	leaq	0x30(%rsp), %rdi
    b9ce:      	movl	$0x8, %esi
    b9d3:      	movq	%r15, %rdx
    b9d6:      	callq	*%rax
    b9d8:      	movq	(%rsp), %r15
    b9dc:      	movq	%r15, 0x40(%rsp)
    b9e1:      	leaq	0x20(%r15), %rdx
    b9e5:      	movq	%rdx, 0x38(%rsp)
    b9ea:      	movq	0x30(%rsp), %r12
    b9ef:      	cmpq	0x18(%rsp), %r12
    b9f4:      	jne	0xba01 <generic_kprobe_path+0x1071>
    b9f6:      	cmpq	0x20(%rsp), %rdx
    b9fb:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ba01:      	movl	$0x4, %eax
    ba06:      	leaq	0x10(%rsp), %rdi
    ba0b:      	movl	$0x8, %esi
    ba10:      	callq	*%rax
    ba12:      	cmpq	0x10(%rsp), %r12
    ba17:      	je	0xbb0f <generic_kprobe_path+0x117f>
    ba1d:      	leaq	0x18(%r12), %rbx
    ba22:      	movl	$0x4, %eax
    ba27:      	movq	%rbp, %rdi
    ba2a:      	movl	$0x8, %esi
    ba2f:      	movq	%rbx, %rdx
    ba32:      	callq	*%rax
    ba34:      	cmpq	%r12, (%rsp)
    ba38:      	je	0xbb0f <generic_kprobe_path+0x117f>
    ba3e:      	movl	$0x4, %eax
    ba43:      	leaq	0x8(%rsp), %rdi
    ba48:      	movl	$0x8, %esi
    ba4d:      	movq	%rbx, %rdx
    ba50:      	callq	*%rax
    ba52:      	addq	$0x20, %r12
    ba56:      	movl	$0x4, %eax
    ba5b:      	leaq	0x58(%rsp), %rdi
    ba60:      	movl	$0x10, %ecx
    ba65:      	movl	$0x10, %esi
    ba6a:      	movq	%r12, %rdx
    ba6d:      	callq	*%rax
    ba6f:      	movq	0x28(%rsp), %rbx
    ba74:      	movq	0x48(%rsp), %rax
    ba79:      	movl	0x5c(%rsp), %r15d
    ba7e:      	subq	%rbx, %rax
    ba81:      	movl	0x50(%rsp), %r12d
    ba86:      	movl	%r15d, %edx
    ba89:      	subl	%r12d, %edx
    ba8c:      	movl	$0x0, %ecx
    ba91:      	cmovbl	%ecx, %edx
    ba94:      	addq	0x60(%rsp), %rdx
    ba99:      	xorl	%esi, %esi
    ba9b:      	cmpl	%r15d, %r12d
    ba9e:      	seta	%sil
    baa2:      	movl	%r15d, %ecx
    baa5:      	cmovbl	%r12d, %ecx
    baa9:      	addl	%ecx, %esi
    baab:      	movl	%r12d, %edi
    baae:      	subl	%esi, %edi
    bab0:      	movl	%edi, 0x50(%rsp)
    bab4:      	subq	%rsi, %rax
    bab7:      	jb	0x16402 <generic_kprobe_path+0xba72>
    babd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bac3:      	ja	0x16402 <generic_kprobe_path+0xba72>
    bac9:      	cmpl	%r15d, %r12d
    bacc:      	jbe	0xbad2 <generic_kprobe_path+0x1142>
    bace:      	movb	$0x2f, (%rbx,%rax)
    bad2:      	xorl	%edi, %edi
    bad4:      	cmpl	%r15d, %r12d
    bad7:      	seta	%dil
    badb:      	movzbl	%cl, %esi
    bade:      	addq	%rax, %rbx
    bae1:      	addq	%rbx, %rdi
    bae4:      	movl	$0x4, %eax
    bae9:      	callq	*%rax
    baeb:      	movq	%rbx, 0x48(%rsp)
    baf0:      	cmpl	%r15d, %r12d
    baf3:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    baf9:      	movq	0x8(%rsp), %r12
    bafe:      	movq	%r12, 0x30(%rsp)
    bb03:      	movq	0x38(%rsp), %rdx
    bb08:      	movq	0x40(%rsp), %r15
    bb0d:      	jmp	0xbb60 <generic_kprobe_path+0x11d0>
    bb0f:      	leaq	0x10(%r15), %rdx
    bb13:      	movl	$0x4, %eax
    bb18:      	movq	%rbp, %rdi
    bb1b:      	movl	$0x8, %esi
    bb20:      	callq	*%rax
    bb22:      	movq	0x40(%rsp), %rax
    bb27:      	cmpq	(%rsp), %rax
    bb2b:      	je	0x163fd <generic_kprobe_path+0xba6d>
    bb31:      	addq	$0x18, %r15
    bb35:      	movl	$0x4, %eax
    bb3a:      	leaq	0x30(%rsp), %rdi
    bb3f:      	movl	$0x8, %esi
    bb44:      	movq	%r15, %rdx
    bb47:      	callq	*%rax
    bb49:      	movq	(%rsp), %r15
    bb4d:      	movq	%r15, 0x40(%rsp)
    bb52:      	leaq	0x20(%r15), %rdx
    bb56:      	movq	%rdx, 0x38(%rsp)
    bb5b:      	movq	0x30(%rsp), %r12
    bb60:      	cmpq	0x18(%rsp), %r12
    bb65:      	jne	0xbb72 <generic_kprobe_path+0x11e2>
    bb67:      	cmpq	0x20(%rsp), %rdx
    bb6c:      	je	0x163fd <generic_kprobe_path+0xba6d>
    bb72:      	movl	$0x4, %eax
    bb77:      	leaq	0x10(%rsp), %rdi
    bb7c:      	movl	$0x8, %esi
    bb81:      	callq	*%rax
    bb83:      	cmpq	0x10(%rsp), %r12
    bb88:      	je	0xbc80 <generic_kprobe_path+0x12f0>
    bb8e:      	leaq	0x18(%r12), %rbx
    bb93:      	movl	$0x4, %eax
    bb98:      	movq	%rbp, %rdi
    bb9b:      	movl	$0x8, %esi
    bba0:      	movq	%rbx, %rdx
    bba3:      	callq	*%rax
    bba5:      	cmpq	%r12, (%rsp)
    bba9:      	je	0xbc80 <generic_kprobe_path+0x12f0>
    bbaf:      	movl	$0x4, %eax
    bbb4:      	leaq	0x8(%rsp), %rdi
    bbb9:      	movl	$0x8, %esi
    bbbe:      	movq	%rbx, %rdx
    bbc1:      	callq	*%rax
    bbc3:      	addq	$0x20, %r12
    bbc7:      	movl	$0x4, %eax
    bbcc:      	leaq	0x58(%rsp), %rdi
    bbd1:      	movl	$0x10, %ecx
    bbd6:      	movl	$0x10, %esi
    bbdb:      	movq	%r12, %rdx
    bbde:      	callq	*%rax
    bbe0:      	movq	0x28(%rsp), %rbx
    bbe5:      	movq	0x48(%rsp), %rax
    bbea:      	movl	0x5c(%rsp), %r15d
    bbef:      	subq	%rbx, %rax
    bbf2:      	movl	0x50(%rsp), %r12d
    bbf7:      	movl	%r15d, %edx
    bbfa:      	subl	%r12d, %edx
    bbfd:      	movl	$0x0, %ecx
    bc02:      	cmovbl	%ecx, %edx
    bc05:      	addq	0x60(%rsp), %rdx
    bc0a:      	xorl	%esi, %esi
    bc0c:      	cmpl	%r15d, %r12d
    bc0f:      	seta	%sil
    bc13:      	movl	%r15d, %ecx
    bc16:      	cmovbl	%r12d, %ecx
    bc1a:      	addl	%ecx, %esi
    bc1c:      	movl	%r12d, %edi
    bc1f:      	subl	%esi, %edi
    bc21:      	movl	%edi, 0x50(%rsp)
    bc25:      	subq	%rsi, %rax
    bc28:      	jb	0x16402 <generic_kprobe_path+0xba72>
    bc2e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bc34:      	ja	0x16402 <generic_kprobe_path+0xba72>
    bc3a:      	cmpl	%r15d, %r12d
    bc3d:      	jbe	0xbc43 <generic_kprobe_path+0x12b3>
    bc3f:      	movb	$0x2f, (%rbx,%rax)
    bc43:      	xorl	%edi, %edi
    bc45:      	cmpl	%r15d, %r12d
    bc48:      	seta	%dil
    bc4c:      	movzbl	%cl, %esi
    bc4f:      	addq	%rax, %rbx
    bc52:      	addq	%rbx, %rdi
    bc55:      	movl	$0x4, %eax
    bc5a:      	callq	*%rax
    bc5c:      	movq	%rbx, 0x48(%rsp)
    bc61:      	cmpl	%r15d, %r12d
    bc64:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    bc6a:      	movq	0x8(%rsp), %r12
    bc6f:      	movq	%r12, 0x30(%rsp)
    bc74:      	movq	0x38(%rsp), %rdx
    bc79:      	movq	0x40(%rsp), %r15
    bc7e:      	jmp	0xbcd1 <generic_kprobe_path+0x1341>
    bc80:      	leaq	0x10(%r15), %rdx
    bc84:      	movl	$0x4, %eax
    bc89:      	movq	%rbp, %rdi
    bc8c:      	movl	$0x8, %esi
    bc91:      	callq	*%rax
    bc93:      	movq	0x40(%rsp), %rax
    bc98:      	cmpq	(%rsp), %rax
    bc9c:      	je	0x163fd <generic_kprobe_path+0xba6d>
    bca2:      	addq	$0x18, %r15
    bca6:      	movl	$0x4, %eax
    bcab:      	leaq	0x30(%rsp), %rdi
    bcb0:      	movl	$0x8, %esi
    bcb5:      	movq	%r15, %rdx
    bcb8:      	callq	*%rax
    bcba:      	movq	(%rsp), %r15
    bcbe:      	movq	%r15, 0x40(%rsp)
    bcc3:      	leaq	0x20(%r15), %rdx
    bcc7:      	movq	%rdx, 0x38(%rsp)
    bccc:      	movq	0x30(%rsp), %r12
    bcd1:      	cmpq	0x18(%rsp), %r12
    bcd6:      	jne	0xbce3 <generic_kprobe_path+0x1353>
    bcd8:      	cmpq	0x20(%rsp), %rdx
    bcdd:      	je	0x163fd <generic_kprobe_path+0xba6d>
    bce3:      	movl	$0x4, %eax
    bce8:      	leaq	0x10(%rsp), %rdi
    bced:      	movl	$0x8, %esi
    bcf2:      	callq	*%rax
    bcf4:      	cmpq	0x10(%rsp), %r12
    bcf9:      	je	0xbdf1 <generic_kprobe_path+0x1461>
    bcff:      	leaq	0x18(%r12), %rbx
    bd04:      	movl	$0x4, %eax
    bd09:      	movq	%rbp, %rdi
    bd0c:      	movl	$0x8, %esi
    bd11:      	movq	%rbx, %rdx
    bd14:      	callq	*%rax
    bd16:      	cmpq	%r12, (%rsp)
    bd1a:      	je	0xbdf1 <generic_kprobe_path+0x1461>
    bd20:      	movl	$0x4, %eax
    bd25:      	leaq	0x8(%rsp), %rdi
    bd2a:      	movl	$0x8, %esi
    bd2f:      	movq	%rbx, %rdx
    bd32:      	callq	*%rax
    bd34:      	addq	$0x20, %r12
    bd38:      	movl	$0x4, %eax
    bd3d:      	leaq	0x58(%rsp), %rdi
    bd42:      	movl	$0x10, %ecx
    bd47:      	movl	$0x10, %esi
    bd4c:      	movq	%r12, %rdx
    bd4f:      	callq	*%rax
    bd51:      	movq	0x28(%rsp), %rbx
    bd56:      	movq	0x48(%rsp), %rax
    bd5b:      	movl	0x5c(%rsp), %r15d
    bd60:      	subq	%rbx, %rax
    bd63:      	movl	0x50(%rsp), %r12d
    bd68:      	movl	%r15d, %edx
    bd6b:      	subl	%r12d, %edx
    bd6e:      	movl	$0x0, %ecx
    bd73:      	cmovbl	%ecx, %edx
    bd76:      	addq	0x60(%rsp), %rdx
    bd7b:      	xorl	%esi, %esi
    bd7d:      	cmpl	%r15d, %r12d
    bd80:      	seta	%sil
    bd84:      	movl	%r15d, %ecx
    bd87:      	cmovbl	%r12d, %ecx
    bd8b:      	addl	%ecx, %esi
    bd8d:      	movl	%r12d, %edi
    bd90:      	subl	%esi, %edi
    bd92:      	movl	%edi, 0x50(%rsp)
    bd96:      	subq	%rsi, %rax
    bd99:      	jb	0x16402 <generic_kprobe_path+0xba72>
    bd9f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bda5:      	ja	0x16402 <generic_kprobe_path+0xba72>
    bdab:      	cmpl	%r15d, %r12d
    bdae:      	jbe	0xbdb4 <generic_kprobe_path+0x1424>
    bdb0:      	movb	$0x2f, (%rbx,%rax)
    bdb4:      	xorl	%edi, %edi
    bdb6:      	cmpl	%r15d, %r12d
    bdb9:      	seta	%dil
    bdbd:      	movzbl	%cl, %esi
    bdc0:      	addq	%rax, %rbx
    bdc3:      	addq	%rbx, %rdi
    bdc6:      	movl	$0x4, %eax
    bdcb:      	callq	*%rax
    bdcd:      	movq	%rbx, 0x48(%rsp)
    bdd2:      	cmpl	%r15d, %r12d
    bdd5:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    bddb:      	movq	0x8(%rsp), %r12
    bde0:      	movq	%r12, 0x30(%rsp)
    bde5:      	movq	0x38(%rsp), %rdx
    bdea:      	movq	0x40(%rsp), %r15
    bdef:      	jmp	0xbe42 <generic_kprobe_path+0x14b2>
    bdf1:      	leaq	0x10(%r15), %rdx
    bdf5:      	movl	$0x4, %eax
    bdfa:      	movq	%rbp, %rdi
    bdfd:      	movl	$0x8, %esi
    be02:      	callq	*%rax
    be04:      	movq	0x40(%rsp), %rax
    be09:      	cmpq	(%rsp), %rax
    be0d:      	je	0x163fd <generic_kprobe_path+0xba6d>
    be13:      	addq	$0x18, %r15
    be17:      	movl	$0x4, %eax
    be1c:      	leaq	0x30(%rsp), %rdi
    be21:      	movl	$0x8, %esi
    be26:      	movq	%r15, %rdx
    be29:      	callq	*%rax
    be2b:      	movq	(%rsp), %r15
    be2f:      	movq	%r15, 0x40(%rsp)
    be34:      	leaq	0x20(%r15), %rdx
    be38:      	movq	%rdx, 0x38(%rsp)
    be3d:      	movq	0x30(%rsp), %r12
    be42:      	cmpq	0x18(%rsp), %r12
    be47:      	jne	0xbe54 <generic_kprobe_path+0x14c4>
    be49:      	cmpq	0x20(%rsp), %rdx
    be4e:      	je	0x163fd <generic_kprobe_path+0xba6d>
    be54:      	movl	$0x4, %eax
    be59:      	leaq	0x10(%rsp), %rdi
    be5e:      	movl	$0x8, %esi
    be63:      	callq	*%rax
    be65:      	cmpq	0x10(%rsp), %r12
    be6a:      	je	0xbf62 <generic_kprobe_path+0x15d2>
    be70:      	leaq	0x18(%r12), %rbx
    be75:      	movl	$0x4, %eax
    be7a:      	movq	%rbp, %rdi
    be7d:      	movl	$0x8, %esi
    be82:      	movq	%rbx, %rdx
    be85:      	callq	*%rax
    be87:      	cmpq	%r12, (%rsp)
    be8b:      	je	0xbf62 <generic_kprobe_path+0x15d2>
    be91:      	movl	$0x4, %eax
    be96:      	leaq	0x8(%rsp), %rdi
    be9b:      	movl	$0x8, %esi
    bea0:      	movq	%rbx, %rdx
    bea3:      	callq	*%rax
    bea5:      	addq	$0x20, %r12
    bea9:      	movl	$0x4, %eax
    beae:      	leaq	0x58(%rsp), %rdi
    beb3:      	movl	$0x10, %ecx
    beb8:      	movl	$0x10, %esi
    bebd:      	movq	%r12, %rdx
    bec0:      	callq	*%rax
    bec2:      	movq	0x28(%rsp), %rbx
    bec7:      	movq	0x48(%rsp), %rax
    becc:      	movl	0x5c(%rsp), %r15d
    bed1:      	subq	%rbx, %rax
    bed4:      	movl	0x50(%rsp), %r12d
    bed9:      	movl	%r15d, %edx
    bedc:      	subl	%r12d, %edx
    bedf:      	movl	$0x0, %ecx
    bee4:      	cmovbl	%ecx, %edx
    bee7:      	addq	0x60(%rsp), %rdx
    beec:      	xorl	%esi, %esi
    beee:      	cmpl	%r15d, %r12d
    bef1:      	seta	%sil
    bef5:      	movl	%r15d, %ecx
    bef8:      	cmovbl	%r12d, %ecx
    befc:      	addl	%ecx, %esi
    befe:      	movl	%r12d, %edi
    bf01:      	subl	%esi, %edi
    bf03:      	movl	%edi, 0x50(%rsp)
    bf07:      	subq	%rsi, %rax
    bf0a:      	jb	0x16402 <generic_kprobe_path+0xba72>
    bf10:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bf16:      	ja	0x16402 <generic_kprobe_path+0xba72>
    bf1c:      	cmpl	%r15d, %r12d
    bf1f:      	jbe	0xbf25 <generic_kprobe_path+0x1595>
    bf21:      	movb	$0x2f, (%rbx,%rax)
    bf25:      	xorl	%edi, %edi
    bf27:      	cmpl	%r15d, %r12d
    bf2a:      	seta	%dil
    bf2e:      	movzbl	%cl, %esi
    bf31:      	addq	%rax, %rbx
    bf34:      	addq	%rbx, %rdi
    bf37:      	movl	$0x4, %eax
    bf3c:      	callq	*%rax
    bf3e:      	movq	%rbx, 0x48(%rsp)
    bf43:      	cmpl	%r15d, %r12d
    bf46:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    bf4c:      	movq	0x8(%rsp), %r12
    bf51:      	movq	%r12, 0x30(%rsp)
    bf56:      	movq	0x38(%rsp), %rdx
    bf5b:      	movq	0x40(%rsp), %r15
    bf60:      	jmp	0xbfb3 <generic_kprobe_path+0x1623>
    bf62:      	leaq	0x10(%r15), %rdx
    bf66:      	movl	$0x4, %eax
    bf6b:      	movq	%rbp, %rdi
    bf6e:      	movl	$0x8, %esi
    bf73:      	callq	*%rax
    bf75:      	movq	0x40(%rsp), %rax
    bf7a:      	cmpq	(%rsp), %rax
    bf7e:      	je	0x163fd <generic_kprobe_path+0xba6d>
    bf84:      	addq	$0x18, %r15
    bf88:      	movl	$0x4, %eax
    bf8d:      	leaq	0x30(%rsp), %rdi
    bf92:      	movl	$0x8, %esi
    bf97:      	movq	%r15, %rdx
    bf9a:      	callq	*%rax
    bf9c:      	movq	(%rsp), %r15
    bfa0:      	movq	%r15, 0x40(%rsp)
    bfa5:      	leaq	0x20(%r15), %rdx
    bfa9:      	movq	%rdx, 0x38(%rsp)
    bfae:      	movq	0x30(%rsp), %r12
    bfb3:      	cmpq	0x18(%rsp), %r12
    bfb8:      	jne	0xbfc5 <generic_kprobe_path+0x1635>
    bfba:      	cmpq	0x20(%rsp), %rdx
    bfbf:      	je	0x163fd <generic_kprobe_path+0xba6d>
    bfc5:      	movl	$0x4, %eax
    bfca:      	leaq	0x10(%rsp), %rdi
    bfcf:      	movl	$0x8, %esi
    bfd4:      	callq	*%rax
    bfd6:      	cmpq	0x10(%rsp), %r12
    bfdb:      	je	0xc0d3 <generic_kprobe_path+0x1743>
    bfe1:      	leaq	0x18(%r12), %rbx
    bfe6:      	movl	$0x4, %eax
    bfeb:      	movq	%rbp, %rdi
    bfee:      	movl	$0x8, %esi
    bff3:      	movq	%rbx, %rdx
    bff6:      	callq	*%rax
    bff8:      	cmpq	%r12, (%rsp)
    bffc:      	je	0xc0d3 <generic_kprobe_path+0x1743>
    c002:      	movl	$0x4, %eax
    c007:      	leaq	0x8(%rsp), %rdi
    c00c:      	movl	$0x8, %esi
    c011:      	movq	%rbx, %rdx
    c014:      	callq	*%rax
    c016:      	addq	$0x20, %r12
    c01a:      	movl	$0x4, %eax
    c01f:      	leaq	0x58(%rsp), %rdi
    c024:      	movl	$0x10, %ecx
    c029:      	movl	$0x10, %esi
    c02e:      	movq	%r12, %rdx
    c031:      	callq	*%rax
    c033:      	movq	0x28(%rsp), %rbx
    c038:      	movq	0x48(%rsp), %rax
    c03d:      	movl	0x5c(%rsp), %r15d
    c042:      	subq	%rbx, %rax
    c045:      	movl	0x50(%rsp), %r12d
    c04a:      	movl	%r15d, %edx
    c04d:      	subl	%r12d, %edx
    c050:      	movl	$0x0, %ecx
    c055:      	cmovbl	%ecx, %edx
    c058:      	addq	0x60(%rsp), %rdx
    c05d:      	xorl	%esi, %esi
    c05f:      	cmpl	%r15d, %r12d
    c062:      	seta	%sil
    c066:      	movl	%r15d, %ecx
    c069:      	cmovbl	%r12d, %ecx
    c06d:      	addl	%ecx, %esi
    c06f:      	movl	%r12d, %edi
    c072:      	subl	%esi, %edi
    c074:      	movl	%edi, 0x50(%rsp)
    c078:      	subq	%rsi, %rax
    c07b:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c081:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c087:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c08d:      	cmpl	%r15d, %r12d
    c090:      	jbe	0xc096 <generic_kprobe_path+0x1706>
    c092:      	movb	$0x2f, (%rbx,%rax)
    c096:      	xorl	%edi, %edi
    c098:      	cmpl	%r15d, %r12d
    c09b:      	seta	%dil
    c09f:      	movzbl	%cl, %esi
    c0a2:      	addq	%rax, %rbx
    c0a5:      	addq	%rbx, %rdi
    c0a8:      	movl	$0x4, %eax
    c0ad:      	callq	*%rax
    c0af:      	movq	%rbx, 0x48(%rsp)
    c0b4:      	cmpl	%r15d, %r12d
    c0b7:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c0bd:      	movq	0x8(%rsp), %r12
    c0c2:      	movq	%r12, 0x30(%rsp)
    c0c7:      	movq	0x38(%rsp), %rdx
    c0cc:      	movq	0x40(%rsp), %r15
    c0d1:      	jmp	0xc124 <generic_kprobe_path+0x1794>
    c0d3:      	leaq	0x10(%r15), %rdx
    c0d7:      	movl	$0x4, %eax
    c0dc:      	movq	%rbp, %rdi
    c0df:      	movl	$0x8, %esi
    c0e4:      	callq	*%rax
    c0e6:      	movq	0x40(%rsp), %rax
    c0eb:      	cmpq	(%rsp), %rax
    c0ef:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c0f5:      	addq	$0x18, %r15
    c0f9:      	movl	$0x4, %eax
    c0fe:      	leaq	0x30(%rsp), %rdi
    c103:      	movl	$0x8, %esi
    c108:      	movq	%r15, %rdx
    c10b:      	callq	*%rax
    c10d:      	movq	(%rsp), %r15
    c111:      	movq	%r15, 0x40(%rsp)
    c116:      	leaq	0x20(%r15), %rdx
    c11a:      	movq	%rdx, 0x38(%rsp)
    c11f:      	movq	0x30(%rsp), %r12
    c124:      	cmpq	0x18(%rsp), %r12
    c129:      	jne	0xc136 <generic_kprobe_path+0x17a6>
    c12b:      	cmpq	0x20(%rsp), %rdx
    c130:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c136:      	movl	$0x4, %eax
    c13b:      	leaq	0x10(%rsp), %rdi
    c140:      	movl	$0x8, %esi
    c145:      	callq	*%rax
    c147:      	cmpq	0x10(%rsp), %r12
    c14c:      	je	0xc244 <generic_kprobe_path+0x18b4>
    c152:      	leaq	0x18(%r12), %rbx
    c157:      	movl	$0x4, %eax
    c15c:      	movq	%rbp, %rdi
    c15f:      	movl	$0x8, %esi
    c164:      	movq	%rbx, %rdx
    c167:      	callq	*%rax
    c169:      	cmpq	%r12, (%rsp)
    c16d:      	je	0xc244 <generic_kprobe_path+0x18b4>
    c173:      	movl	$0x4, %eax
    c178:      	leaq	0x8(%rsp), %rdi
    c17d:      	movl	$0x8, %esi
    c182:      	movq	%rbx, %rdx
    c185:      	callq	*%rax
    c187:      	addq	$0x20, %r12
    c18b:      	movl	$0x4, %eax
    c190:      	leaq	0x58(%rsp), %rdi
    c195:      	movl	$0x10, %ecx
    c19a:      	movl	$0x10, %esi
    c19f:      	movq	%r12, %rdx
    c1a2:      	callq	*%rax
    c1a4:      	movq	0x28(%rsp), %rbx
    c1a9:      	movq	0x48(%rsp), %rax
    c1ae:      	movl	0x5c(%rsp), %r15d
    c1b3:      	subq	%rbx, %rax
    c1b6:      	movl	0x50(%rsp), %r12d
    c1bb:      	movl	%r15d, %edx
    c1be:      	subl	%r12d, %edx
    c1c1:      	movl	$0x0, %ecx
    c1c6:      	cmovbl	%ecx, %edx
    c1c9:      	addq	0x60(%rsp), %rdx
    c1ce:      	xorl	%esi, %esi
    c1d0:      	cmpl	%r15d, %r12d
    c1d3:      	seta	%sil
    c1d7:      	movl	%r15d, %ecx
    c1da:      	cmovbl	%r12d, %ecx
    c1de:      	addl	%ecx, %esi
    c1e0:      	movl	%r12d, %edi
    c1e3:      	subl	%esi, %edi
    c1e5:      	movl	%edi, 0x50(%rsp)
    c1e9:      	subq	%rsi, %rax
    c1ec:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c1f2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c1f8:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c1fe:      	cmpl	%r15d, %r12d
    c201:      	jbe	0xc207 <generic_kprobe_path+0x1877>
    c203:      	movb	$0x2f, (%rbx,%rax)
    c207:      	xorl	%edi, %edi
    c209:      	cmpl	%r15d, %r12d
    c20c:      	seta	%dil
    c210:      	movzbl	%cl, %esi
    c213:      	addq	%rax, %rbx
    c216:      	addq	%rbx, %rdi
    c219:      	movl	$0x4, %eax
    c21e:      	callq	*%rax
    c220:      	movq	%rbx, 0x48(%rsp)
    c225:      	cmpl	%r15d, %r12d
    c228:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c22e:      	movq	0x8(%rsp), %r12
    c233:      	movq	%r12, 0x30(%rsp)
    c238:      	movq	0x38(%rsp), %rdx
    c23d:      	movq	0x40(%rsp), %r15
    c242:      	jmp	0xc295 <generic_kprobe_path+0x1905>
    c244:      	leaq	0x10(%r15), %rdx
    c248:      	movl	$0x4, %eax
    c24d:      	movq	%rbp, %rdi
    c250:      	movl	$0x8, %esi
    c255:      	callq	*%rax
    c257:      	movq	0x40(%rsp), %rax
    c25c:      	cmpq	(%rsp), %rax
    c260:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c266:      	addq	$0x18, %r15
    c26a:      	movl	$0x4, %eax
    c26f:      	leaq	0x30(%rsp), %rdi
    c274:      	movl	$0x8, %esi
    c279:      	movq	%r15, %rdx
    c27c:      	callq	*%rax
    c27e:      	movq	(%rsp), %r15
    c282:      	movq	%r15, 0x40(%rsp)
    c287:      	leaq	0x20(%r15), %rdx
    c28b:      	movq	%rdx, 0x38(%rsp)
    c290:      	movq	0x30(%rsp), %r12
    c295:      	cmpq	0x18(%rsp), %r12
    c29a:      	jne	0xc2a7 <generic_kprobe_path+0x1917>
    c29c:      	cmpq	0x20(%rsp), %rdx
    c2a1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c2a7:      	movl	$0x4, %eax
    c2ac:      	leaq	0x10(%rsp), %rdi
    c2b1:      	movl	$0x8, %esi
    c2b6:      	callq	*%rax
    c2b8:      	cmpq	0x10(%rsp), %r12
    c2bd:      	je	0xc3b5 <generic_kprobe_path+0x1a25>
    c2c3:      	leaq	0x18(%r12), %rbx
    c2c8:      	movl	$0x4, %eax
    c2cd:      	movq	%rbp, %rdi
    c2d0:      	movl	$0x8, %esi
    c2d5:      	movq	%rbx, %rdx
    c2d8:      	callq	*%rax
    c2da:      	cmpq	%r12, (%rsp)
    c2de:      	je	0xc3b5 <generic_kprobe_path+0x1a25>
    c2e4:      	movl	$0x4, %eax
    c2e9:      	leaq	0x8(%rsp), %rdi
    c2ee:      	movl	$0x8, %esi
    c2f3:      	movq	%rbx, %rdx
    c2f6:      	callq	*%rax
    c2f8:      	addq	$0x20, %r12
    c2fc:      	movl	$0x4, %eax
    c301:      	leaq	0x58(%rsp), %rdi
    c306:      	movl	$0x10, %ecx
    c30b:      	movl	$0x10, %esi
    c310:      	movq	%r12, %rdx
    c313:      	callq	*%rax
    c315:      	movq	0x28(%rsp), %rbx
    c31a:      	movq	0x48(%rsp), %rax
    c31f:      	movl	0x5c(%rsp), %r15d
    c324:      	subq	%rbx, %rax
    c327:      	movl	0x50(%rsp), %r12d
    c32c:      	movl	%r15d, %edx
    c32f:      	subl	%r12d, %edx
    c332:      	movl	$0x0, %ecx
    c337:      	cmovbl	%ecx, %edx
    c33a:      	addq	0x60(%rsp), %rdx
    c33f:      	xorl	%esi, %esi
    c341:      	cmpl	%r15d, %r12d
    c344:      	seta	%sil
    c348:      	movl	%r15d, %ecx
    c34b:      	cmovbl	%r12d, %ecx
    c34f:      	addl	%ecx, %esi
    c351:      	movl	%r12d, %edi
    c354:      	subl	%esi, %edi
    c356:      	movl	%edi, 0x50(%rsp)
    c35a:      	subq	%rsi, %rax
    c35d:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c363:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c369:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c36f:      	cmpl	%r15d, %r12d
    c372:      	jbe	0xc378 <generic_kprobe_path+0x19e8>
    c374:      	movb	$0x2f, (%rbx,%rax)
    c378:      	xorl	%edi, %edi
    c37a:      	cmpl	%r15d, %r12d
    c37d:      	seta	%dil
    c381:      	movzbl	%cl, %esi
    c384:      	addq	%rax, %rbx
    c387:      	addq	%rbx, %rdi
    c38a:      	movl	$0x4, %eax
    c38f:      	callq	*%rax
    c391:      	movq	%rbx, 0x48(%rsp)
    c396:      	cmpl	%r15d, %r12d
    c399:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c39f:      	movq	0x8(%rsp), %r12
    c3a4:      	movq	%r12, 0x30(%rsp)
    c3a9:      	movq	0x38(%rsp), %rdx
    c3ae:      	movq	0x40(%rsp), %r15
    c3b3:      	jmp	0xc406 <generic_kprobe_path+0x1a76>
    c3b5:      	leaq	0x10(%r15), %rdx
    c3b9:      	movl	$0x4, %eax
    c3be:      	movq	%rbp, %rdi
    c3c1:      	movl	$0x8, %esi
    c3c6:      	callq	*%rax
    c3c8:      	movq	0x40(%rsp), %rax
    c3cd:      	cmpq	(%rsp), %rax
    c3d1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c3d7:      	addq	$0x18, %r15
    c3db:      	movl	$0x4, %eax
    c3e0:      	leaq	0x30(%rsp), %rdi
    c3e5:      	movl	$0x8, %esi
    c3ea:      	movq	%r15, %rdx
    c3ed:      	callq	*%rax
    c3ef:      	movq	(%rsp), %r15
    c3f3:      	movq	%r15, 0x40(%rsp)
    c3f8:      	leaq	0x20(%r15), %rdx
    c3fc:      	movq	%rdx, 0x38(%rsp)
    c401:      	movq	0x30(%rsp), %r12
    c406:      	cmpq	0x18(%rsp), %r12
    c40b:      	jne	0xc418 <generic_kprobe_path+0x1a88>
    c40d:      	cmpq	0x20(%rsp), %rdx
    c412:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c418:      	movl	$0x4, %eax
    c41d:      	leaq	0x10(%rsp), %rdi
    c422:      	movl	$0x8, %esi
    c427:      	callq	*%rax
    c429:      	cmpq	0x10(%rsp), %r12
    c42e:      	je	0xc526 <generic_kprobe_path+0x1b96>
    c434:      	leaq	0x18(%r12), %rbx
    c439:      	movl	$0x4, %eax
    c43e:      	movq	%rbp, %rdi
    c441:      	movl	$0x8, %esi
    c446:      	movq	%rbx, %rdx
    c449:      	callq	*%rax
    c44b:      	cmpq	%r12, (%rsp)
    c44f:      	je	0xc526 <generic_kprobe_path+0x1b96>
    c455:      	movl	$0x4, %eax
    c45a:      	leaq	0x8(%rsp), %rdi
    c45f:      	movl	$0x8, %esi
    c464:      	movq	%rbx, %rdx
    c467:      	callq	*%rax
    c469:      	addq	$0x20, %r12
    c46d:      	movl	$0x4, %eax
    c472:      	leaq	0x58(%rsp), %rdi
    c477:      	movl	$0x10, %ecx
    c47c:      	movl	$0x10, %esi
    c481:      	movq	%r12, %rdx
    c484:      	callq	*%rax
    c486:      	movq	0x28(%rsp), %rbx
    c48b:      	movq	0x48(%rsp), %rax
    c490:      	movl	0x5c(%rsp), %r15d
    c495:      	subq	%rbx, %rax
    c498:      	movl	0x50(%rsp), %r12d
    c49d:      	movl	%r15d, %edx
    c4a0:      	subl	%r12d, %edx
    c4a3:      	movl	$0x0, %ecx
    c4a8:      	cmovbl	%ecx, %edx
    c4ab:      	addq	0x60(%rsp), %rdx
    c4b0:      	xorl	%esi, %esi
    c4b2:      	cmpl	%r15d, %r12d
    c4b5:      	seta	%sil
    c4b9:      	movl	%r15d, %ecx
    c4bc:      	cmovbl	%r12d, %ecx
    c4c0:      	addl	%ecx, %esi
    c4c2:      	movl	%r12d, %edi
    c4c5:      	subl	%esi, %edi
    c4c7:      	movl	%edi, 0x50(%rsp)
    c4cb:      	subq	%rsi, %rax
    c4ce:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c4d4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c4da:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c4e0:      	cmpl	%r15d, %r12d
    c4e3:      	jbe	0xc4e9 <generic_kprobe_path+0x1b59>
    c4e5:      	movb	$0x2f, (%rbx,%rax)
    c4e9:      	xorl	%edi, %edi
    c4eb:      	cmpl	%r15d, %r12d
    c4ee:      	seta	%dil
    c4f2:      	movzbl	%cl, %esi
    c4f5:      	addq	%rax, %rbx
    c4f8:      	addq	%rbx, %rdi
    c4fb:      	movl	$0x4, %eax
    c500:      	callq	*%rax
    c502:      	movq	%rbx, 0x48(%rsp)
    c507:      	cmpl	%r15d, %r12d
    c50a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c510:      	movq	0x8(%rsp), %r12
    c515:      	movq	%r12, 0x30(%rsp)
    c51a:      	movq	0x38(%rsp), %rdx
    c51f:      	movq	0x40(%rsp), %r15
    c524:      	jmp	0xc577 <generic_kprobe_path+0x1be7>
    c526:      	leaq	0x10(%r15), %rdx
    c52a:      	movl	$0x4, %eax
    c52f:      	movq	%rbp, %rdi
    c532:      	movl	$0x8, %esi
    c537:      	callq	*%rax
    c539:      	movq	0x40(%rsp), %rax
    c53e:      	cmpq	(%rsp), %rax
    c542:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c548:      	addq	$0x18, %r15
    c54c:      	movl	$0x4, %eax
    c551:      	leaq	0x30(%rsp), %rdi
    c556:      	movl	$0x8, %esi
    c55b:      	movq	%r15, %rdx
    c55e:      	callq	*%rax
    c560:      	movq	(%rsp), %r15
    c564:      	movq	%r15, 0x40(%rsp)
    c569:      	leaq	0x20(%r15), %rdx
    c56d:      	movq	%rdx, 0x38(%rsp)
    c572:      	movq	0x30(%rsp), %r12
    c577:      	cmpq	0x18(%rsp), %r12
    c57c:      	jne	0xc589 <generic_kprobe_path+0x1bf9>
    c57e:      	cmpq	0x20(%rsp), %rdx
    c583:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c589:      	movl	$0x4, %eax
    c58e:      	leaq	0x10(%rsp), %rdi
    c593:      	movl	$0x8, %esi
    c598:      	callq	*%rax
    c59a:      	cmpq	0x10(%rsp), %r12
    c59f:      	je	0xc697 <generic_kprobe_path+0x1d07>
    c5a5:      	leaq	0x18(%r12), %rbx
    c5aa:      	movl	$0x4, %eax
    c5af:      	movq	%rbp, %rdi
    c5b2:      	movl	$0x8, %esi
    c5b7:      	movq	%rbx, %rdx
    c5ba:      	callq	*%rax
    c5bc:      	cmpq	%r12, (%rsp)
    c5c0:      	je	0xc697 <generic_kprobe_path+0x1d07>
    c5c6:      	movl	$0x4, %eax
    c5cb:      	leaq	0x8(%rsp), %rdi
    c5d0:      	movl	$0x8, %esi
    c5d5:      	movq	%rbx, %rdx
    c5d8:      	callq	*%rax
    c5da:      	addq	$0x20, %r12
    c5de:      	movl	$0x4, %eax
    c5e3:      	leaq	0x58(%rsp), %rdi
    c5e8:      	movl	$0x10, %ecx
    c5ed:      	movl	$0x10, %esi
    c5f2:      	movq	%r12, %rdx
    c5f5:      	callq	*%rax
    c5f7:      	movq	0x28(%rsp), %rbx
    c5fc:      	movq	0x48(%rsp), %rax
    c601:      	movl	0x5c(%rsp), %r15d
    c606:      	subq	%rbx, %rax
    c609:      	movl	0x50(%rsp), %r12d
    c60e:      	movl	%r15d, %edx
    c611:      	subl	%r12d, %edx
    c614:      	movl	$0x0, %ecx
    c619:      	cmovbl	%ecx, %edx
    c61c:      	addq	0x60(%rsp), %rdx
    c621:      	xorl	%esi, %esi
    c623:      	cmpl	%r15d, %r12d
    c626:      	seta	%sil
    c62a:      	movl	%r15d, %ecx
    c62d:      	cmovbl	%r12d, %ecx
    c631:      	addl	%ecx, %esi
    c633:      	movl	%r12d, %edi
    c636:      	subl	%esi, %edi
    c638:      	movl	%edi, 0x50(%rsp)
    c63c:      	subq	%rsi, %rax
    c63f:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c645:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c64b:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c651:      	cmpl	%r15d, %r12d
    c654:      	jbe	0xc65a <generic_kprobe_path+0x1cca>
    c656:      	movb	$0x2f, (%rbx,%rax)
    c65a:      	xorl	%edi, %edi
    c65c:      	cmpl	%r15d, %r12d
    c65f:      	seta	%dil
    c663:      	movzbl	%cl, %esi
    c666:      	addq	%rax, %rbx
    c669:      	addq	%rbx, %rdi
    c66c:      	movl	$0x4, %eax
    c671:      	callq	*%rax
    c673:      	movq	%rbx, 0x48(%rsp)
    c678:      	cmpl	%r15d, %r12d
    c67b:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c681:      	movq	0x8(%rsp), %r12
    c686:      	movq	%r12, 0x30(%rsp)
    c68b:      	movq	0x38(%rsp), %rdx
    c690:      	movq	0x40(%rsp), %r15
    c695:      	jmp	0xc6e8 <generic_kprobe_path+0x1d58>
    c697:      	leaq	0x10(%r15), %rdx
    c69b:      	movl	$0x4, %eax
    c6a0:      	movq	%rbp, %rdi
    c6a3:      	movl	$0x8, %esi
    c6a8:      	callq	*%rax
    c6aa:      	movq	0x40(%rsp), %rax
    c6af:      	cmpq	(%rsp), %rax
    c6b3:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c6b9:      	addq	$0x18, %r15
    c6bd:      	movl	$0x4, %eax
    c6c2:      	leaq	0x30(%rsp), %rdi
    c6c7:      	movl	$0x8, %esi
    c6cc:      	movq	%r15, %rdx
    c6cf:      	callq	*%rax
    c6d1:      	movq	(%rsp), %r15
    c6d5:      	movq	%r15, 0x40(%rsp)
    c6da:      	leaq	0x20(%r15), %rdx
    c6de:      	movq	%rdx, 0x38(%rsp)
    c6e3:      	movq	0x30(%rsp), %r12
    c6e8:      	cmpq	0x18(%rsp), %r12
    c6ed:      	jne	0xc6fa <generic_kprobe_path+0x1d6a>
    c6ef:      	cmpq	0x20(%rsp), %rdx
    c6f4:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c6fa:      	movl	$0x4, %eax
    c6ff:      	leaq	0x10(%rsp), %rdi
    c704:      	movl	$0x8, %esi
    c709:      	callq	*%rax
    c70b:      	cmpq	0x10(%rsp), %r12
    c710:      	je	0xc808 <generic_kprobe_path+0x1e78>
    c716:      	leaq	0x18(%r12), %rbx
    c71b:      	movl	$0x4, %eax
    c720:      	movq	%rbp, %rdi
    c723:      	movl	$0x8, %esi
    c728:      	movq	%rbx, %rdx
    c72b:      	callq	*%rax
    c72d:      	cmpq	%r12, (%rsp)
    c731:      	je	0xc808 <generic_kprobe_path+0x1e78>
    c737:      	movl	$0x4, %eax
    c73c:      	leaq	0x8(%rsp), %rdi
    c741:      	movl	$0x8, %esi
    c746:      	movq	%rbx, %rdx
    c749:      	callq	*%rax
    c74b:      	addq	$0x20, %r12
    c74f:      	movl	$0x4, %eax
    c754:      	leaq	0x58(%rsp), %rdi
    c759:      	movl	$0x10, %ecx
    c75e:      	movl	$0x10, %esi
    c763:      	movq	%r12, %rdx
    c766:      	callq	*%rax
    c768:      	movq	0x28(%rsp), %rbx
    c76d:      	movq	0x48(%rsp), %rax
    c772:      	movl	0x5c(%rsp), %r15d
    c777:      	subq	%rbx, %rax
    c77a:      	movl	0x50(%rsp), %r12d
    c77f:      	movl	%r15d, %edx
    c782:      	subl	%r12d, %edx
    c785:      	movl	$0x0, %ecx
    c78a:      	cmovbl	%ecx, %edx
    c78d:      	addq	0x60(%rsp), %rdx
    c792:      	xorl	%esi, %esi
    c794:      	cmpl	%r15d, %r12d
    c797:      	seta	%sil
    c79b:      	movl	%r15d, %ecx
    c79e:      	cmovbl	%r12d, %ecx
    c7a2:      	addl	%ecx, %esi
    c7a4:      	movl	%r12d, %edi
    c7a7:      	subl	%esi, %edi
    c7a9:      	movl	%edi, 0x50(%rsp)
    c7ad:      	subq	%rsi, %rax
    c7b0:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c7b6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c7bc:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c7c2:      	cmpl	%r15d, %r12d
    c7c5:      	jbe	0xc7cb <generic_kprobe_path+0x1e3b>
    c7c7:      	movb	$0x2f, (%rbx,%rax)
    c7cb:      	xorl	%edi, %edi
    c7cd:      	cmpl	%r15d, %r12d
    c7d0:      	seta	%dil
    c7d4:      	movzbl	%cl, %esi
    c7d7:      	addq	%rax, %rbx
    c7da:      	addq	%rbx, %rdi
    c7dd:      	movl	$0x4, %eax
    c7e2:      	callq	*%rax
    c7e4:      	movq	%rbx, 0x48(%rsp)
    c7e9:      	cmpl	%r15d, %r12d
    c7ec:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c7f2:      	movq	0x8(%rsp), %r12
    c7f7:      	movq	%r12, 0x30(%rsp)
    c7fc:      	movq	0x38(%rsp), %rdx
    c801:      	movq	0x40(%rsp), %r15
    c806:      	jmp	0xc859 <generic_kprobe_path+0x1ec9>
    c808:      	leaq	0x10(%r15), %rdx
    c80c:      	movl	$0x4, %eax
    c811:      	movq	%rbp, %rdi
    c814:      	movl	$0x8, %esi
    c819:      	callq	*%rax
    c81b:      	movq	0x40(%rsp), %rax
    c820:      	cmpq	(%rsp), %rax
    c824:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c82a:      	addq	$0x18, %r15
    c82e:      	movl	$0x4, %eax
    c833:      	leaq	0x30(%rsp), %rdi
    c838:      	movl	$0x8, %esi
    c83d:      	movq	%r15, %rdx
    c840:      	callq	*%rax
    c842:      	movq	(%rsp), %r15
    c846:      	movq	%r15, 0x40(%rsp)
    c84b:      	leaq	0x20(%r15), %rdx
    c84f:      	movq	%rdx, 0x38(%rsp)
    c854:      	movq	0x30(%rsp), %r12
    c859:      	cmpq	0x18(%rsp), %r12
    c85e:      	jne	0xc86b <generic_kprobe_path+0x1edb>
    c860:      	cmpq	0x20(%rsp), %rdx
    c865:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c86b:      	movl	$0x4, %eax
    c870:      	leaq	0x10(%rsp), %rdi
    c875:      	movl	$0x8, %esi
    c87a:      	callq	*%rax
    c87c:      	cmpq	0x10(%rsp), %r12
    c881:      	je	0xc979 <generic_kprobe_path+0x1fe9>
    c887:      	leaq	0x18(%r12), %rbx
    c88c:      	movl	$0x4, %eax
    c891:      	movq	%rbp, %rdi
    c894:      	movl	$0x8, %esi
    c899:      	movq	%rbx, %rdx
    c89c:      	callq	*%rax
    c89e:      	cmpq	%r12, (%rsp)
    c8a2:      	je	0xc979 <generic_kprobe_path+0x1fe9>
    c8a8:      	movl	$0x4, %eax
    c8ad:      	leaq	0x8(%rsp), %rdi
    c8b2:      	movl	$0x8, %esi
    c8b7:      	movq	%rbx, %rdx
    c8ba:      	callq	*%rax
    c8bc:      	addq	$0x20, %r12
    c8c0:      	movl	$0x4, %eax
    c8c5:      	leaq	0x58(%rsp), %rdi
    c8ca:      	movl	$0x10, %ecx
    c8cf:      	movl	$0x10, %esi
    c8d4:      	movq	%r12, %rdx
    c8d7:      	callq	*%rax
    c8d9:      	movq	0x28(%rsp), %rbx
    c8de:      	movq	0x48(%rsp), %rax
    c8e3:      	movl	0x5c(%rsp), %r15d
    c8e8:      	subq	%rbx, %rax
    c8eb:      	movl	0x50(%rsp), %r12d
    c8f0:      	movl	%r15d, %edx
    c8f3:      	subl	%r12d, %edx
    c8f6:      	movl	$0x0, %ecx
    c8fb:      	cmovbl	%ecx, %edx
    c8fe:      	addq	0x60(%rsp), %rdx
    c903:      	xorl	%esi, %esi
    c905:      	cmpl	%r15d, %r12d
    c908:      	seta	%sil
    c90c:      	movl	%r15d, %ecx
    c90f:      	cmovbl	%r12d, %ecx
    c913:      	addl	%ecx, %esi
    c915:      	movl	%r12d, %edi
    c918:      	subl	%esi, %edi
    c91a:      	movl	%edi, 0x50(%rsp)
    c91e:      	subq	%rsi, %rax
    c921:      	jb	0x16402 <generic_kprobe_path+0xba72>
    c927:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c92d:      	ja	0x16402 <generic_kprobe_path+0xba72>
    c933:      	cmpl	%r15d, %r12d
    c936:      	jbe	0xc93c <generic_kprobe_path+0x1fac>
    c938:      	movb	$0x2f, (%rbx,%rax)
    c93c:      	xorl	%edi, %edi
    c93e:      	cmpl	%r15d, %r12d
    c941:      	seta	%dil
    c945:      	movzbl	%cl, %esi
    c948:      	addq	%rax, %rbx
    c94b:      	addq	%rbx, %rdi
    c94e:      	movl	$0x4, %eax
    c953:      	callq	*%rax
    c955:      	movq	%rbx, 0x48(%rsp)
    c95a:      	cmpl	%r15d, %r12d
    c95d:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    c963:      	movq	0x8(%rsp), %r12
    c968:      	movq	%r12, 0x30(%rsp)
    c96d:      	movq	0x38(%rsp), %rdx
    c972:      	movq	0x40(%rsp), %r15
    c977:      	jmp	0xc9ca <generic_kprobe_path+0x203a>
    c979:      	leaq	0x10(%r15), %rdx
    c97d:      	movl	$0x4, %eax
    c982:      	movq	%rbp, %rdi
    c985:      	movl	$0x8, %esi
    c98a:      	callq	*%rax
    c98c:      	movq	0x40(%rsp), %rax
    c991:      	cmpq	(%rsp), %rax
    c995:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c99b:      	addq	$0x18, %r15
    c99f:      	movl	$0x4, %eax
    c9a4:      	leaq	0x30(%rsp), %rdi
    c9a9:      	movl	$0x8, %esi
    c9ae:      	movq	%r15, %rdx
    c9b1:      	callq	*%rax
    c9b3:      	movq	(%rsp), %r15
    c9b7:      	movq	%r15, 0x40(%rsp)
    c9bc:      	leaq	0x20(%r15), %rdx
    c9c0:      	movq	%rdx, 0x38(%rsp)
    c9c5:      	movq	0x30(%rsp), %r12
    c9ca:      	cmpq	0x18(%rsp), %r12
    c9cf:      	jne	0xc9dc <generic_kprobe_path+0x204c>
    c9d1:      	cmpq	0x20(%rsp), %rdx
    c9d6:      	je	0x163fd <generic_kprobe_path+0xba6d>
    c9dc:      	movl	$0x4, %eax
    c9e1:      	leaq	0x10(%rsp), %rdi
    c9e6:      	movl	$0x8, %esi
    c9eb:      	callq	*%rax
    c9ed:      	cmpq	0x10(%rsp), %r12
    c9f2:      	je	0xcaea <generic_kprobe_path+0x215a>
    c9f8:      	leaq	0x18(%r12), %rbx
    c9fd:      	movl	$0x4, %eax
    ca02:      	movq	%rbp, %rdi
    ca05:      	movl	$0x8, %esi
    ca0a:      	movq	%rbx, %rdx
    ca0d:      	callq	*%rax
    ca0f:      	cmpq	%r12, (%rsp)
    ca13:      	je	0xcaea <generic_kprobe_path+0x215a>
    ca19:      	movl	$0x4, %eax
    ca1e:      	leaq	0x8(%rsp), %rdi
    ca23:      	movl	$0x8, %esi
    ca28:      	movq	%rbx, %rdx
    ca2b:      	callq	*%rax
    ca2d:      	addq	$0x20, %r12
    ca31:      	movl	$0x4, %eax
    ca36:      	leaq	0x58(%rsp), %rdi
    ca3b:      	movl	$0x10, %ecx
    ca40:      	movl	$0x10, %esi
    ca45:      	movq	%r12, %rdx
    ca48:      	callq	*%rax
    ca4a:      	movq	0x28(%rsp), %rbx
    ca4f:      	movq	0x48(%rsp), %rax
    ca54:      	movl	0x5c(%rsp), %r15d
    ca59:      	subq	%rbx, %rax
    ca5c:      	movl	0x50(%rsp), %r12d
    ca61:      	movl	%r15d, %edx
    ca64:      	subl	%r12d, %edx
    ca67:      	movl	$0x0, %ecx
    ca6c:      	cmovbl	%ecx, %edx
    ca6f:      	addq	0x60(%rsp), %rdx
    ca74:      	xorl	%esi, %esi
    ca76:      	cmpl	%r15d, %r12d
    ca79:      	seta	%sil
    ca7d:      	movl	%r15d, %ecx
    ca80:      	cmovbl	%r12d, %ecx
    ca84:      	addl	%ecx, %esi
    ca86:      	movl	%r12d, %edi
    ca89:      	subl	%esi, %edi
    ca8b:      	movl	%edi, 0x50(%rsp)
    ca8f:      	subq	%rsi, %rax
    ca92:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ca98:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ca9e:      	ja	0x16402 <generic_kprobe_path+0xba72>
    caa4:      	cmpl	%r15d, %r12d
    caa7:      	jbe	0xcaad <generic_kprobe_path+0x211d>
    caa9:      	movb	$0x2f, (%rbx,%rax)
    caad:      	xorl	%edi, %edi
    caaf:      	cmpl	%r15d, %r12d
    cab2:      	seta	%dil
    cab6:      	movzbl	%cl, %esi
    cab9:      	addq	%rax, %rbx
    cabc:      	addq	%rbx, %rdi
    cabf:      	movl	$0x4, %eax
    cac4:      	callq	*%rax
    cac6:      	movq	%rbx, 0x48(%rsp)
    cacb:      	cmpl	%r15d, %r12d
    cace:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    cad4:      	movq	0x8(%rsp), %r12
    cad9:      	movq	%r12, 0x30(%rsp)
    cade:      	movq	0x38(%rsp), %rdx
    cae3:      	movq	0x40(%rsp), %r15
    cae8:      	jmp	0xcb3b <generic_kprobe_path+0x21ab>
    caea:      	leaq	0x10(%r15), %rdx
    caee:      	movl	$0x4, %eax
    caf3:      	movq	%rbp, %rdi
    caf6:      	movl	$0x8, %esi
    cafb:      	callq	*%rax
    cafd:      	movq	0x40(%rsp), %rax
    cb02:      	cmpq	(%rsp), %rax
    cb06:      	je	0x163fd <generic_kprobe_path+0xba6d>
    cb0c:      	addq	$0x18, %r15
    cb10:      	movl	$0x4, %eax
    cb15:      	leaq	0x30(%rsp), %rdi
    cb1a:      	movl	$0x8, %esi
    cb1f:      	movq	%r15, %rdx
    cb22:      	callq	*%rax
    cb24:      	movq	(%rsp), %r15
    cb28:      	movq	%r15, 0x40(%rsp)
    cb2d:      	leaq	0x20(%r15), %rdx
    cb31:      	movq	%rdx, 0x38(%rsp)
    cb36:      	movq	0x30(%rsp), %r12
    cb3b:      	cmpq	0x18(%rsp), %r12
    cb40:      	jne	0xcb4d <generic_kprobe_path+0x21bd>
    cb42:      	cmpq	0x20(%rsp), %rdx
    cb47:      	je	0x163fd <generic_kprobe_path+0xba6d>
    cb4d:      	movl	$0x4, %eax
    cb52:      	leaq	0x10(%rsp), %rdi
    cb57:      	movl	$0x8, %esi
    cb5c:      	callq	*%rax
    cb5e:      	cmpq	0x10(%rsp), %r12
    cb63:      	je	0xcc5b <generic_kprobe_path+0x22cb>
    cb69:      	leaq	0x18(%r12), %rbx
    cb6e:      	movl	$0x4, %eax
    cb73:      	movq	%rbp, %rdi
    cb76:      	movl	$0x8, %esi
    cb7b:      	movq	%rbx, %rdx
    cb7e:      	callq	*%rax
    cb80:      	cmpq	%r12, (%rsp)
    cb84:      	je	0xcc5b <generic_kprobe_path+0x22cb>
    cb8a:      	movl	$0x4, %eax
    cb8f:      	leaq	0x8(%rsp), %rdi
    cb94:      	movl	$0x8, %esi
    cb99:      	movq	%rbx, %rdx
    cb9c:      	callq	*%rax
    cb9e:      	addq	$0x20, %r12
    cba2:      	movl	$0x4, %eax
    cba7:      	leaq	0x58(%rsp), %rdi
    cbac:      	movl	$0x10, %ecx
    cbb1:      	movl	$0x10, %esi
    cbb6:      	movq	%r12, %rdx
    cbb9:      	callq	*%rax
    cbbb:      	movq	0x28(%rsp), %rbx
    cbc0:      	movq	0x48(%rsp), %rax
    cbc5:      	movl	0x5c(%rsp), %r15d
    cbca:      	subq	%rbx, %rax
    cbcd:      	movl	0x50(%rsp), %r12d
    cbd2:      	movl	%r15d, %edx
    cbd5:      	subl	%r12d, %edx
    cbd8:      	movl	$0x0, %ecx
    cbdd:      	cmovbl	%ecx, %edx
    cbe0:      	addq	0x60(%rsp), %rdx
    cbe5:      	xorl	%esi, %esi
    cbe7:      	cmpl	%r15d, %r12d
    cbea:      	seta	%sil
    cbee:      	movl	%r15d, %ecx
    cbf1:      	cmovbl	%r12d, %ecx
    cbf5:      	addl	%ecx, %esi
    cbf7:      	movl	%r12d, %edi
    cbfa:      	subl	%esi, %edi
    cbfc:      	movl	%edi, 0x50(%rsp)
    cc00:      	subq	%rsi, %rax
    cc03:      	jb	0x16402 <generic_kprobe_path+0xba72>
    cc09:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cc0f:      	ja	0x16402 <generic_kprobe_path+0xba72>
    cc15:      	cmpl	%r15d, %r12d
    cc18:      	jbe	0xcc1e <generic_kprobe_path+0x228e>
    cc1a:      	movb	$0x2f, (%rbx,%rax)
    cc1e:      	xorl	%edi, %edi
    cc20:      	cmpl	%r15d, %r12d
    cc23:      	seta	%dil
    cc27:      	movzbl	%cl, %esi
    cc2a:      	addq	%rax, %rbx
    cc2d:      	addq	%rbx, %rdi
    cc30:      	movl	$0x4, %eax
    cc35:      	callq	*%rax
    cc37:      	movq	%rbx, 0x48(%rsp)
    cc3c:      	cmpl	%r15d, %r12d
    cc3f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    cc45:      	movq	0x8(%rsp), %r12
    cc4a:      	movq	%r12, 0x30(%rsp)
    cc4f:      	movq	0x38(%rsp), %rdx
    cc54:      	movq	0x40(%rsp), %r15
    cc59:      	jmp	0xccac <generic_kprobe_path+0x231c>
    cc5b:      	leaq	0x10(%r15), %rdx
    cc5f:      	movl	$0x4, %eax
    cc64:      	movq	%rbp, %rdi
    cc67:      	movl	$0x8, %esi
    cc6c:      	callq	*%rax
    cc6e:      	movq	0x40(%rsp), %rax
    cc73:      	cmpq	(%rsp), %rax
    cc77:      	je	0x163fd <generic_kprobe_path+0xba6d>
    cc7d:      	addq	$0x18, %r15
    cc81:      	movl	$0x4, %eax
    cc86:      	leaq	0x30(%rsp), %rdi
    cc8b:      	movl	$0x8, %esi
    cc90:      	movq	%r15, %rdx
    cc93:      	callq	*%rax
    cc95:      	movq	(%rsp), %r15
    cc99:      	movq	%r15, 0x40(%rsp)
    cc9e:      	leaq	0x20(%r15), %rdx
    cca2:      	movq	%rdx, 0x38(%rsp)
    cca7:      	movq	0x30(%rsp), %r12
    ccac:      	cmpq	0x18(%rsp), %r12
    ccb1:      	jne	0xccbe <generic_kprobe_path+0x232e>
    ccb3:      	cmpq	0x20(%rsp), %rdx
    ccb8:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ccbe:      	movl	$0x4, %eax
    ccc3:      	leaq	0x10(%rsp), %rdi
    ccc8:      	movl	$0x8, %esi
    cccd:      	callq	*%rax
    cccf:      	cmpq	0x10(%rsp), %r12
    ccd4:      	je	0xcdcc <generic_kprobe_path+0x243c>
    ccda:      	leaq	0x18(%r12), %rbx
    ccdf:      	movl	$0x4, %eax
    cce4:      	movq	%rbp, %rdi
    cce7:      	movl	$0x8, %esi
    ccec:      	movq	%rbx, %rdx
    ccef:      	callq	*%rax
    ccf1:      	cmpq	%r12, (%rsp)
    ccf5:      	je	0xcdcc <generic_kprobe_path+0x243c>
    ccfb:      	movl	$0x4, %eax
    cd00:      	leaq	0x8(%rsp), %rdi
    cd05:      	movl	$0x8, %esi
    cd0a:      	movq	%rbx, %rdx
    cd0d:      	callq	*%rax
    cd0f:      	addq	$0x20, %r12
    cd13:      	movl	$0x4, %eax
    cd18:      	leaq	0x58(%rsp), %rdi
    cd1d:      	movl	$0x10, %ecx
    cd22:      	movl	$0x10, %esi
    cd27:      	movq	%r12, %rdx
    cd2a:      	callq	*%rax
    cd2c:      	movq	0x28(%rsp), %rbx
    cd31:      	movq	0x48(%rsp), %rax
    cd36:      	movl	0x5c(%rsp), %r15d
    cd3b:      	subq	%rbx, %rax
    cd3e:      	movl	0x50(%rsp), %r12d
    cd43:      	movl	%r15d, %edx
    cd46:      	subl	%r12d, %edx
    cd49:      	movl	$0x0, %ecx
    cd4e:      	cmovbl	%ecx, %edx
    cd51:      	addq	0x60(%rsp), %rdx
    cd56:      	xorl	%esi, %esi
    cd58:      	cmpl	%r15d, %r12d
    cd5b:      	seta	%sil
    cd5f:      	movl	%r15d, %ecx
    cd62:      	cmovbl	%r12d, %ecx
    cd66:      	addl	%ecx, %esi
    cd68:      	movl	%r12d, %edi
    cd6b:      	subl	%esi, %edi
    cd6d:      	movl	%edi, 0x50(%rsp)
    cd71:      	subq	%rsi, %rax
    cd74:      	jb	0x16402 <generic_kprobe_path+0xba72>
    cd7a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cd80:      	ja	0x16402 <generic_kprobe_path+0xba72>
    cd86:      	cmpl	%r15d, %r12d
    cd89:      	jbe	0xcd8f <generic_kprobe_path+0x23ff>
    cd8b:      	movb	$0x2f, (%rbx,%rax)
    cd8f:      	xorl	%edi, %edi
    cd91:      	cmpl	%r15d, %r12d
    cd94:      	seta	%dil
    cd98:      	movzbl	%cl, %esi
    cd9b:      	addq	%rax, %rbx
    cd9e:      	addq	%rbx, %rdi
    cda1:      	movl	$0x4, %eax
    cda6:      	callq	*%rax
    cda8:      	movq	%rbx, 0x48(%rsp)
    cdad:      	cmpl	%r15d, %r12d
    cdb0:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    cdb6:      	movq	0x8(%rsp), %r12
    cdbb:      	movq	%r12, 0x30(%rsp)
    cdc0:      	movq	0x38(%rsp), %rdx
    cdc5:      	movq	0x40(%rsp), %r15
    cdca:      	jmp	0xce1d <generic_kprobe_path+0x248d>
    cdcc:      	leaq	0x10(%r15), %rdx
    cdd0:      	movl	$0x4, %eax
    cdd5:      	movq	%rbp, %rdi
    cdd8:      	movl	$0x8, %esi
    cddd:      	callq	*%rax
    cddf:      	movq	0x40(%rsp), %rax
    cde4:      	cmpq	(%rsp), %rax
    cde8:      	je	0x163fd <generic_kprobe_path+0xba6d>
    cdee:      	addq	$0x18, %r15
    cdf2:      	movl	$0x4, %eax
    cdf7:      	leaq	0x30(%rsp), %rdi
    cdfc:      	movl	$0x8, %esi
    ce01:      	movq	%r15, %rdx
    ce04:      	callq	*%rax
    ce06:      	movq	(%rsp), %r15
    ce0a:      	movq	%r15, 0x40(%rsp)
    ce0f:      	leaq	0x20(%r15), %rdx
    ce13:      	movq	%rdx, 0x38(%rsp)
    ce18:      	movq	0x30(%rsp), %r12
    ce1d:      	cmpq	0x18(%rsp), %r12
    ce22:      	jne	0xce2f <generic_kprobe_path+0x249f>
    ce24:      	cmpq	0x20(%rsp), %rdx
    ce29:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ce2f:      	movl	$0x4, %eax
    ce34:      	leaq	0x10(%rsp), %rdi
    ce39:      	movl	$0x8, %esi
    ce3e:      	callq	*%rax
    ce40:      	cmpq	0x10(%rsp), %r12
    ce45:      	je	0xcf3d <generic_kprobe_path+0x25ad>
    ce4b:      	leaq	0x18(%r12), %rbx
    ce50:      	movl	$0x4, %eax
    ce55:      	movq	%rbp, %rdi
    ce58:      	movl	$0x8, %esi
    ce5d:      	movq	%rbx, %rdx
    ce60:      	callq	*%rax
    ce62:      	cmpq	%r12, (%rsp)
    ce66:      	je	0xcf3d <generic_kprobe_path+0x25ad>
    ce6c:      	movl	$0x4, %eax
    ce71:      	leaq	0x8(%rsp), %rdi
    ce76:      	movl	$0x8, %esi
    ce7b:      	movq	%rbx, %rdx
    ce7e:      	callq	*%rax
    ce80:      	addq	$0x20, %r12
    ce84:      	movl	$0x4, %eax
    ce89:      	leaq	0x58(%rsp), %rdi
    ce8e:      	movl	$0x10, %ecx
    ce93:      	movl	$0x10, %esi
    ce98:      	movq	%r12, %rdx
    ce9b:      	callq	*%rax
    ce9d:      	movq	0x28(%rsp), %rbx
    cea2:      	movq	0x48(%rsp), %rax
    cea7:      	movl	0x5c(%rsp), %r15d
    ceac:      	subq	%rbx, %rax
    ceaf:      	movl	0x50(%rsp), %r12d
    ceb4:      	movl	%r15d, %edx
    ceb7:      	subl	%r12d, %edx
    ceba:      	movl	$0x0, %ecx
    cebf:      	cmovbl	%ecx, %edx
    cec2:      	addq	0x60(%rsp), %rdx
    cec7:      	xorl	%esi, %esi
    cec9:      	cmpl	%r15d, %r12d
    cecc:      	seta	%sil
    ced0:      	movl	%r15d, %ecx
    ced3:      	cmovbl	%r12d, %ecx
    ced7:      	addl	%ecx, %esi
    ced9:      	movl	%r12d, %edi
    cedc:      	subl	%esi, %edi
    cede:      	movl	%edi, 0x50(%rsp)
    cee2:      	subq	%rsi, %rax
    cee5:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ceeb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cef1:      	ja	0x16402 <generic_kprobe_path+0xba72>
    cef7:      	cmpl	%r15d, %r12d
    cefa:      	jbe	0xcf00 <generic_kprobe_path+0x2570>
    cefc:      	movb	$0x2f, (%rbx,%rax)
    cf00:      	xorl	%edi, %edi
    cf02:      	cmpl	%r15d, %r12d
    cf05:      	seta	%dil
    cf09:      	movzbl	%cl, %esi
    cf0c:      	addq	%rax, %rbx
    cf0f:      	addq	%rbx, %rdi
    cf12:      	movl	$0x4, %eax
    cf17:      	callq	*%rax
    cf19:      	movq	%rbx, 0x48(%rsp)
    cf1e:      	cmpl	%r15d, %r12d
    cf21:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    cf27:      	movq	0x8(%rsp), %r12
    cf2c:      	movq	%r12, 0x30(%rsp)
    cf31:      	movq	0x38(%rsp), %rdx
    cf36:      	movq	0x40(%rsp), %r15
    cf3b:      	jmp	0xcf8e <generic_kprobe_path+0x25fe>
    cf3d:      	leaq	0x10(%r15), %rdx
    cf41:      	movl	$0x4, %eax
    cf46:      	movq	%rbp, %rdi
    cf49:      	movl	$0x8, %esi
    cf4e:      	callq	*%rax
    cf50:      	movq	0x40(%rsp), %rax
    cf55:      	cmpq	(%rsp), %rax
    cf59:      	je	0x163fd <generic_kprobe_path+0xba6d>
    cf5f:      	addq	$0x18, %r15
    cf63:      	movl	$0x4, %eax
    cf68:      	leaq	0x30(%rsp), %rdi
    cf6d:      	movl	$0x8, %esi
    cf72:      	movq	%r15, %rdx
    cf75:      	callq	*%rax
    cf77:      	movq	(%rsp), %r15
    cf7b:      	movq	%r15, 0x40(%rsp)
    cf80:      	leaq	0x20(%r15), %rdx
    cf84:      	movq	%rdx, 0x38(%rsp)
    cf89:      	movq	0x30(%rsp), %r12
    cf8e:      	cmpq	0x18(%rsp), %r12
    cf93:      	jne	0xcfa0 <generic_kprobe_path+0x2610>
    cf95:      	cmpq	0x20(%rsp), %rdx
    cf9a:      	je	0x163fd <generic_kprobe_path+0xba6d>
    cfa0:      	movl	$0x4, %eax
    cfa5:      	leaq	0x10(%rsp), %rdi
    cfaa:      	movl	$0x8, %esi
    cfaf:      	callq	*%rax
    cfb1:      	cmpq	0x10(%rsp), %r12
    cfb6:      	je	0xd0ae <generic_kprobe_path+0x271e>
    cfbc:      	leaq	0x18(%r12), %rbx
    cfc1:      	movl	$0x4, %eax
    cfc6:      	movq	%rbp, %rdi
    cfc9:      	movl	$0x8, %esi
    cfce:      	movq	%rbx, %rdx
    cfd1:      	callq	*%rax
    cfd3:      	cmpq	%r12, (%rsp)
    cfd7:      	je	0xd0ae <generic_kprobe_path+0x271e>
    cfdd:      	movl	$0x4, %eax
    cfe2:      	leaq	0x8(%rsp), %rdi
    cfe7:      	movl	$0x8, %esi
    cfec:      	movq	%rbx, %rdx
    cfef:      	callq	*%rax
    cff1:      	addq	$0x20, %r12
    cff5:      	movl	$0x4, %eax
    cffa:      	leaq	0x58(%rsp), %rdi
    cfff:      	movl	$0x10, %ecx
    d004:      	movl	$0x10, %esi
    d009:      	movq	%r12, %rdx
    d00c:      	callq	*%rax
    d00e:      	movq	0x28(%rsp), %rbx
    d013:      	movq	0x48(%rsp), %rax
    d018:      	movl	0x5c(%rsp), %r15d
    d01d:      	subq	%rbx, %rax
    d020:      	movl	0x50(%rsp), %r12d
    d025:      	movl	%r15d, %edx
    d028:      	subl	%r12d, %edx
    d02b:      	movl	$0x0, %ecx
    d030:      	cmovbl	%ecx, %edx
    d033:      	addq	0x60(%rsp), %rdx
    d038:      	xorl	%esi, %esi
    d03a:      	cmpl	%r15d, %r12d
    d03d:      	seta	%sil
    d041:      	movl	%r15d, %ecx
    d044:      	cmovbl	%r12d, %ecx
    d048:      	addl	%ecx, %esi
    d04a:      	movl	%r12d, %edi
    d04d:      	subl	%esi, %edi
    d04f:      	movl	%edi, 0x50(%rsp)
    d053:      	subq	%rsi, %rax
    d056:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d05c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d062:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d068:      	cmpl	%r15d, %r12d
    d06b:      	jbe	0xd071 <generic_kprobe_path+0x26e1>
    d06d:      	movb	$0x2f, (%rbx,%rax)
    d071:      	xorl	%edi, %edi
    d073:      	cmpl	%r15d, %r12d
    d076:      	seta	%dil
    d07a:      	movzbl	%cl, %esi
    d07d:      	addq	%rax, %rbx
    d080:      	addq	%rbx, %rdi
    d083:      	movl	$0x4, %eax
    d088:      	callq	*%rax
    d08a:      	movq	%rbx, 0x48(%rsp)
    d08f:      	cmpl	%r15d, %r12d
    d092:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d098:      	movq	0x8(%rsp), %r12
    d09d:      	movq	%r12, 0x30(%rsp)
    d0a2:      	movq	0x38(%rsp), %rdx
    d0a7:      	movq	0x40(%rsp), %r15
    d0ac:      	jmp	0xd0ff <generic_kprobe_path+0x276f>
    d0ae:      	leaq	0x10(%r15), %rdx
    d0b2:      	movl	$0x4, %eax
    d0b7:      	movq	%rbp, %rdi
    d0ba:      	movl	$0x8, %esi
    d0bf:      	callq	*%rax
    d0c1:      	movq	0x40(%rsp), %rax
    d0c6:      	cmpq	(%rsp), %rax
    d0ca:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d0d0:      	addq	$0x18, %r15
    d0d4:      	movl	$0x4, %eax
    d0d9:      	leaq	0x30(%rsp), %rdi
    d0de:      	movl	$0x8, %esi
    d0e3:      	movq	%r15, %rdx
    d0e6:      	callq	*%rax
    d0e8:      	movq	(%rsp), %r15
    d0ec:      	movq	%r15, 0x40(%rsp)
    d0f1:      	leaq	0x20(%r15), %rdx
    d0f5:      	movq	%rdx, 0x38(%rsp)
    d0fa:      	movq	0x30(%rsp), %r12
    d0ff:      	cmpq	0x18(%rsp), %r12
    d104:      	jne	0xd111 <generic_kprobe_path+0x2781>
    d106:      	cmpq	0x20(%rsp), %rdx
    d10b:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d111:      	movl	$0x4, %eax
    d116:      	leaq	0x10(%rsp), %rdi
    d11b:      	movl	$0x8, %esi
    d120:      	callq	*%rax
    d122:      	cmpq	0x10(%rsp), %r12
    d127:      	je	0xd21f <generic_kprobe_path+0x288f>
    d12d:      	leaq	0x18(%r12), %rbx
    d132:      	movl	$0x4, %eax
    d137:      	movq	%rbp, %rdi
    d13a:      	movl	$0x8, %esi
    d13f:      	movq	%rbx, %rdx
    d142:      	callq	*%rax
    d144:      	cmpq	%r12, (%rsp)
    d148:      	je	0xd21f <generic_kprobe_path+0x288f>
    d14e:      	movl	$0x4, %eax
    d153:      	leaq	0x8(%rsp), %rdi
    d158:      	movl	$0x8, %esi
    d15d:      	movq	%rbx, %rdx
    d160:      	callq	*%rax
    d162:      	addq	$0x20, %r12
    d166:      	movl	$0x4, %eax
    d16b:      	leaq	0x58(%rsp), %rdi
    d170:      	movl	$0x10, %ecx
    d175:      	movl	$0x10, %esi
    d17a:      	movq	%r12, %rdx
    d17d:      	callq	*%rax
    d17f:      	movq	0x28(%rsp), %rbx
    d184:      	movq	0x48(%rsp), %rax
    d189:      	movl	0x5c(%rsp), %r15d
    d18e:      	subq	%rbx, %rax
    d191:      	movl	0x50(%rsp), %r12d
    d196:      	movl	%r15d, %edx
    d199:      	subl	%r12d, %edx
    d19c:      	movl	$0x0, %ecx
    d1a1:      	cmovbl	%ecx, %edx
    d1a4:      	addq	0x60(%rsp), %rdx
    d1a9:      	xorl	%esi, %esi
    d1ab:      	cmpl	%r15d, %r12d
    d1ae:      	seta	%sil
    d1b2:      	movl	%r15d, %ecx
    d1b5:      	cmovbl	%r12d, %ecx
    d1b9:      	addl	%ecx, %esi
    d1bb:      	movl	%r12d, %edi
    d1be:      	subl	%esi, %edi
    d1c0:      	movl	%edi, 0x50(%rsp)
    d1c4:      	subq	%rsi, %rax
    d1c7:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d1cd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d1d3:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d1d9:      	cmpl	%r15d, %r12d
    d1dc:      	jbe	0xd1e2 <generic_kprobe_path+0x2852>
    d1de:      	movb	$0x2f, (%rbx,%rax)
    d1e2:      	xorl	%edi, %edi
    d1e4:      	cmpl	%r15d, %r12d
    d1e7:      	seta	%dil
    d1eb:      	movzbl	%cl, %esi
    d1ee:      	addq	%rax, %rbx
    d1f1:      	addq	%rbx, %rdi
    d1f4:      	movl	$0x4, %eax
    d1f9:      	callq	*%rax
    d1fb:      	movq	%rbx, 0x48(%rsp)
    d200:      	cmpl	%r15d, %r12d
    d203:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d209:      	movq	0x8(%rsp), %r12
    d20e:      	movq	%r12, 0x30(%rsp)
    d213:      	movq	0x38(%rsp), %rdx
    d218:      	movq	0x40(%rsp), %r15
    d21d:      	jmp	0xd270 <generic_kprobe_path+0x28e0>
    d21f:      	leaq	0x10(%r15), %rdx
    d223:      	movl	$0x4, %eax
    d228:      	movq	%rbp, %rdi
    d22b:      	movl	$0x8, %esi
    d230:      	callq	*%rax
    d232:      	movq	0x40(%rsp), %rax
    d237:      	cmpq	(%rsp), %rax
    d23b:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d241:      	addq	$0x18, %r15
    d245:      	movl	$0x4, %eax
    d24a:      	leaq	0x30(%rsp), %rdi
    d24f:      	movl	$0x8, %esi
    d254:      	movq	%r15, %rdx
    d257:      	callq	*%rax
    d259:      	movq	(%rsp), %r15
    d25d:      	movq	%r15, 0x40(%rsp)
    d262:      	leaq	0x20(%r15), %rdx
    d266:      	movq	%rdx, 0x38(%rsp)
    d26b:      	movq	0x30(%rsp), %r12
    d270:      	cmpq	0x18(%rsp), %r12
    d275:      	jne	0xd282 <generic_kprobe_path+0x28f2>
    d277:      	cmpq	0x20(%rsp), %rdx
    d27c:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d282:      	movl	$0x4, %eax
    d287:      	leaq	0x10(%rsp), %rdi
    d28c:      	movl	$0x8, %esi
    d291:      	callq	*%rax
    d293:      	cmpq	0x10(%rsp), %r12
    d298:      	je	0xd390 <generic_kprobe_path+0x2a00>
    d29e:      	leaq	0x18(%r12), %rbx
    d2a3:      	movl	$0x4, %eax
    d2a8:      	movq	%rbp, %rdi
    d2ab:      	movl	$0x8, %esi
    d2b0:      	movq	%rbx, %rdx
    d2b3:      	callq	*%rax
    d2b5:      	cmpq	%r12, (%rsp)
    d2b9:      	je	0xd390 <generic_kprobe_path+0x2a00>
    d2bf:      	movl	$0x4, %eax
    d2c4:      	leaq	0x8(%rsp), %rdi
    d2c9:      	movl	$0x8, %esi
    d2ce:      	movq	%rbx, %rdx
    d2d1:      	callq	*%rax
    d2d3:      	addq	$0x20, %r12
    d2d7:      	movl	$0x4, %eax
    d2dc:      	leaq	0x58(%rsp), %rdi
    d2e1:      	movl	$0x10, %ecx
    d2e6:      	movl	$0x10, %esi
    d2eb:      	movq	%r12, %rdx
    d2ee:      	callq	*%rax
    d2f0:      	movq	0x28(%rsp), %rbx
    d2f5:      	movq	0x48(%rsp), %rax
    d2fa:      	movl	0x5c(%rsp), %r15d
    d2ff:      	subq	%rbx, %rax
    d302:      	movl	0x50(%rsp), %r12d
    d307:      	movl	%r15d, %edx
    d30a:      	subl	%r12d, %edx
    d30d:      	movl	$0x0, %ecx
    d312:      	cmovbl	%ecx, %edx
    d315:      	addq	0x60(%rsp), %rdx
    d31a:      	xorl	%esi, %esi
    d31c:      	cmpl	%r15d, %r12d
    d31f:      	seta	%sil
    d323:      	movl	%r15d, %ecx
    d326:      	cmovbl	%r12d, %ecx
    d32a:      	addl	%ecx, %esi
    d32c:      	movl	%r12d, %edi
    d32f:      	subl	%esi, %edi
    d331:      	movl	%edi, 0x50(%rsp)
    d335:      	subq	%rsi, %rax
    d338:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d33e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d344:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d34a:      	cmpl	%r15d, %r12d
    d34d:      	jbe	0xd353 <generic_kprobe_path+0x29c3>
    d34f:      	movb	$0x2f, (%rbx,%rax)
    d353:      	xorl	%edi, %edi
    d355:      	cmpl	%r15d, %r12d
    d358:      	seta	%dil
    d35c:      	movzbl	%cl, %esi
    d35f:      	addq	%rax, %rbx
    d362:      	addq	%rbx, %rdi
    d365:      	movl	$0x4, %eax
    d36a:      	callq	*%rax
    d36c:      	movq	%rbx, 0x48(%rsp)
    d371:      	cmpl	%r15d, %r12d
    d374:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d37a:      	movq	0x8(%rsp), %r12
    d37f:      	movq	%r12, 0x30(%rsp)
    d384:      	movq	0x38(%rsp), %rdx
    d389:      	movq	0x40(%rsp), %r15
    d38e:      	jmp	0xd3e1 <generic_kprobe_path+0x2a51>
    d390:      	leaq	0x10(%r15), %rdx
    d394:      	movl	$0x4, %eax
    d399:      	movq	%rbp, %rdi
    d39c:      	movl	$0x8, %esi
    d3a1:      	callq	*%rax
    d3a3:      	movq	0x40(%rsp), %rax
    d3a8:      	cmpq	(%rsp), %rax
    d3ac:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d3b2:      	addq	$0x18, %r15
    d3b6:      	movl	$0x4, %eax
    d3bb:      	leaq	0x30(%rsp), %rdi
    d3c0:      	movl	$0x8, %esi
    d3c5:      	movq	%r15, %rdx
    d3c8:      	callq	*%rax
    d3ca:      	movq	(%rsp), %r15
    d3ce:      	movq	%r15, 0x40(%rsp)
    d3d3:      	leaq	0x20(%r15), %rdx
    d3d7:      	movq	%rdx, 0x38(%rsp)
    d3dc:      	movq	0x30(%rsp), %r12
    d3e1:      	cmpq	0x18(%rsp), %r12
    d3e6:      	jne	0xd3f3 <generic_kprobe_path+0x2a63>
    d3e8:      	cmpq	0x20(%rsp), %rdx
    d3ed:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d3f3:      	movl	$0x4, %eax
    d3f8:      	leaq	0x10(%rsp), %rdi
    d3fd:      	movl	$0x8, %esi
    d402:      	callq	*%rax
    d404:      	cmpq	0x10(%rsp), %r12
    d409:      	je	0xd501 <generic_kprobe_path+0x2b71>
    d40f:      	leaq	0x18(%r12), %rbx
    d414:      	movl	$0x4, %eax
    d419:      	movq	%rbp, %rdi
    d41c:      	movl	$0x8, %esi
    d421:      	movq	%rbx, %rdx
    d424:      	callq	*%rax
    d426:      	cmpq	%r12, (%rsp)
    d42a:      	je	0xd501 <generic_kprobe_path+0x2b71>
    d430:      	movl	$0x4, %eax
    d435:      	leaq	0x8(%rsp), %rdi
    d43a:      	movl	$0x8, %esi
    d43f:      	movq	%rbx, %rdx
    d442:      	callq	*%rax
    d444:      	addq	$0x20, %r12
    d448:      	movl	$0x4, %eax
    d44d:      	leaq	0x58(%rsp), %rdi
    d452:      	movl	$0x10, %ecx
    d457:      	movl	$0x10, %esi
    d45c:      	movq	%r12, %rdx
    d45f:      	callq	*%rax
    d461:      	movq	0x28(%rsp), %rbx
    d466:      	movq	0x48(%rsp), %rax
    d46b:      	movl	0x5c(%rsp), %r15d
    d470:      	subq	%rbx, %rax
    d473:      	movl	0x50(%rsp), %r12d
    d478:      	movl	%r15d, %edx
    d47b:      	subl	%r12d, %edx
    d47e:      	movl	$0x0, %ecx
    d483:      	cmovbl	%ecx, %edx
    d486:      	addq	0x60(%rsp), %rdx
    d48b:      	xorl	%esi, %esi
    d48d:      	cmpl	%r15d, %r12d
    d490:      	seta	%sil
    d494:      	movl	%r15d, %ecx
    d497:      	cmovbl	%r12d, %ecx
    d49b:      	addl	%ecx, %esi
    d49d:      	movl	%r12d, %edi
    d4a0:      	subl	%esi, %edi
    d4a2:      	movl	%edi, 0x50(%rsp)
    d4a6:      	subq	%rsi, %rax
    d4a9:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d4af:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d4b5:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d4bb:      	cmpl	%r15d, %r12d
    d4be:      	jbe	0xd4c4 <generic_kprobe_path+0x2b34>
    d4c0:      	movb	$0x2f, (%rbx,%rax)
    d4c4:      	xorl	%edi, %edi
    d4c6:      	cmpl	%r15d, %r12d
    d4c9:      	seta	%dil
    d4cd:      	movzbl	%cl, %esi
    d4d0:      	addq	%rax, %rbx
    d4d3:      	addq	%rbx, %rdi
    d4d6:      	movl	$0x4, %eax
    d4db:      	callq	*%rax
    d4dd:      	movq	%rbx, 0x48(%rsp)
    d4e2:      	cmpl	%r15d, %r12d
    d4e5:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d4eb:      	movq	0x8(%rsp), %r12
    d4f0:      	movq	%r12, 0x30(%rsp)
    d4f5:      	movq	0x38(%rsp), %rdx
    d4fa:      	movq	0x40(%rsp), %r15
    d4ff:      	jmp	0xd552 <generic_kprobe_path+0x2bc2>
    d501:      	leaq	0x10(%r15), %rdx
    d505:      	movl	$0x4, %eax
    d50a:      	movq	%rbp, %rdi
    d50d:      	movl	$0x8, %esi
    d512:      	callq	*%rax
    d514:      	movq	0x40(%rsp), %rax
    d519:      	cmpq	(%rsp), %rax
    d51d:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d523:      	addq	$0x18, %r15
    d527:      	movl	$0x4, %eax
    d52c:      	leaq	0x30(%rsp), %rdi
    d531:      	movl	$0x8, %esi
    d536:      	movq	%r15, %rdx
    d539:      	callq	*%rax
    d53b:      	movq	(%rsp), %r15
    d53f:      	movq	%r15, 0x40(%rsp)
    d544:      	leaq	0x20(%r15), %rdx
    d548:      	movq	%rdx, 0x38(%rsp)
    d54d:      	movq	0x30(%rsp), %r12
    d552:      	cmpq	0x18(%rsp), %r12
    d557:      	jne	0xd564 <generic_kprobe_path+0x2bd4>
    d559:      	cmpq	0x20(%rsp), %rdx
    d55e:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d564:      	movl	$0x4, %eax
    d569:      	leaq	0x10(%rsp), %rdi
    d56e:      	movl	$0x8, %esi
    d573:      	callq	*%rax
    d575:      	cmpq	0x10(%rsp), %r12
    d57a:      	je	0xd672 <generic_kprobe_path+0x2ce2>
    d580:      	leaq	0x18(%r12), %rbx
    d585:      	movl	$0x4, %eax
    d58a:      	movq	%rbp, %rdi
    d58d:      	movl	$0x8, %esi
    d592:      	movq	%rbx, %rdx
    d595:      	callq	*%rax
    d597:      	cmpq	%r12, (%rsp)
    d59b:      	je	0xd672 <generic_kprobe_path+0x2ce2>
    d5a1:      	movl	$0x4, %eax
    d5a6:      	leaq	0x8(%rsp), %rdi
    d5ab:      	movl	$0x8, %esi
    d5b0:      	movq	%rbx, %rdx
    d5b3:      	callq	*%rax
    d5b5:      	addq	$0x20, %r12
    d5b9:      	movl	$0x4, %eax
    d5be:      	leaq	0x58(%rsp), %rdi
    d5c3:      	movl	$0x10, %ecx
    d5c8:      	movl	$0x10, %esi
    d5cd:      	movq	%r12, %rdx
    d5d0:      	callq	*%rax
    d5d2:      	movq	0x28(%rsp), %rbx
    d5d7:      	movq	0x48(%rsp), %rax
    d5dc:      	movl	0x5c(%rsp), %r15d
    d5e1:      	subq	%rbx, %rax
    d5e4:      	movl	0x50(%rsp), %r12d
    d5e9:      	movl	%r15d, %edx
    d5ec:      	subl	%r12d, %edx
    d5ef:      	movl	$0x0, %ecx
    d5f4:      	cmovbl	%ecx, %edx
    d5f7:      	addq	0x60(%rsp), %rdx
    d5fc:      	xorl	%esi, %esi
    d5fe:      	cmpl	%r15d, %r12d
    d601:      	seta	%sil
    d605:      	movl	%r15d, %ecx
    d608:      	cmovbl	%r12d, %ecx
    d60c:      	addl	%ecx, %esi
    d60e:      	movl	%r12d, %edi
    d611:      	subl	%esi, %edi
    d613:      	movl	%edi, 0x50(%rsp)
    d617:      	subq	%rsi, %rax
    d61a:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d620:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d626:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d62c:      	cmpl	%r15d, %r12d
    d62f:      	jbe	0xd635 <generic_kprobe_path+0x2ca5>
    d631:      	movb	$0x2f, (%rbx,%rax)
    d635:      	xorl	%edi, %edi
    d637:      	cmpl	%r15d, %r12d
    d63a:      	seta	%dil
    d63e:      	movzbl	%cl, %esi
    d641:      	addq	%rax, %rbx
    d644:      	addq	%rbx, %rdi
    d647:      	movl	$0x4, %eax
    d64c:      	callq	*%rax
    d64e:      	movq	%rbx, 0x48(%rsp)
    d653:      	cmpl	%r15d, %r12d
    d656:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d65c:      	movq	0x8(%rsp), %r12
    d661:      	movq	%r12, 0x30(%rsp)
    d666:      	movq	0x38(%rsp), %rdx
    d66b:      	movq	0x40(%rsp), %r15
    d670:      	jmp	0xd6c3 <generic_kprobe_path+0x2d33>
    d672:      	leaq	0x10(%r15), %rdx
    d676:      	movl	$0x4, %eax
    d67b:      	movq	%rbp, %rdi
    d67e:      	movl	$0x8, %esi
    d683:      	callq	*%rax
    d685:      	movq	0x40(%rsp), %rax
    d68a:      	cmpq	(%rsp), %rax
    d68e:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d694:      	addq	$0x18, %r15
    d698:      	movl	$0x4, %eax
    d69d:      	leaq	0x30(%rsp), %rdi
    d6a2:      	movl	$0x8, %esi
    d6a7:      	movq	%r15, %rdx
    d6aa:      	callq	*%rax
    d6ac:      	movq	(%rsp), %r15
    d6b0:      	movq	%r15, 0x40(%rsp)
    d6b5:      	leaq	0x20(%r15), %rdx
    d6b9:      	movq	%rdx, 0x38(%rsp)
    d6be:      	movq	0x30(%rsp), %r12
    d6c3:      	cmpq	0x18(%rsp), %r12
    d6c8:      	jne	0xd6d5 <generic_kprobe_path+0x2d45>
    d6ca:      	cmpq	0x20(%rsp), %rdx
    d6cf:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d6d5:      	movl	$0x4, %eax
    d6da:      	leaq	0x10(%rsp), %rdi
    d6df:      	movl	$0x8, %esi
    d6e4:      	callq	*%rax
    d6e6:      	cmpq	0x10(%rsp), %r12
    d6eb:      	je	0xd7e3 <generic_kprobe_path+0x2e53>
    d6f1:      	leaq	0x18(%r12), %rbx
    d6f6:      	movl	$0x4, %eax
    d6fb:      	movq	%rbp, %rdi
    d6fe:      	movl	$0x8, %esi
    d703:      	movq	%rbx, %rdx
    d706:      	callq	*%rax
    d708:      	cmpq	%r12, (%rsp)
    d70c:      	je	0xd7e3 <generic_kprobe_path+0x2e53>
    d712:      	movl	$0x4, %eax
    d717:      	leaq	0x8(%rsp), %rdi
    d71c:      	movl	$0x8, %esi
    d721:      	movq	%rbx, %rdx
    d724:      	callq	*%rax
    d726:      	addq	$0x20, %r12
    d72a:      	movl	$0x4, %eax
    d72f:      	leaq	0x58(%rsp), %rdi
    d734:      	movl	$0x10, %ecx
    d739:      	movl	$0x10, %esi
    d73e:      	movq	%r12, %rdx
    d741:      	callq	*%rax
    d743:      	movq	0x28(%rsp), %rbx
    d748:      	movq	0x48(%rsp), %rax
    d74d:      	movl	0x5c(%rsp), %r15d
    d752:      	subq	%rbx, %rax
    d755:      	movl	0x50(%rsp), %r12d
    d75a:      	movl	%r15d, %edx
    d75d:      	subl	%r12d, %edx
    d760:      	movl	$0x0, %ecx
    d765:      	cmovbl	%ecx, %edx
    d768:      	addq	0x60(%rsp), %rdx
    d76d:      	xorl	%esi, %esi
    d76f:      	cmpl	%r15d, %r12d
    d772:      	seta	%sil
    d776:      	movl	%r15d, %ecx
    d779:      	cmovbl	%r12d, %ecx
    d77d:      	addl	%ecx, %esi
    d77f:      	movl	%r12d, %edi
    d782:      	subl	%esi, %edi
    d784:      	movl	%edi, 0x50(%rsp)
    d788:      	subq	%rsi, %rax
    d78b:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d791:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d797:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d79d:      	cmpl	%r15d, %r12d
    d7a0:      	jbe	0xd7a6 <generic_kprobe_path+0x2e16>
    d7a2:      	movb	$0x2f, (%rbx,%rax)
    d7a6:      	xorl	%edi, %edi
    d7a8:      	cmpl	%r15d, %r12d
    d7ab:      	seta	%dil
    d7af:      	movzbl	%cl, %esi
    d7b2:      	addq	%rax, %rbx
    d7b5:      	addq	%rbx, %rdi
    d7b8:      	movl	$0x4, %eax
    d7bd:      	callq	*%rax
    d7bf:      	movq	%rbx, 0x48(%rsp)
    d7c4:      	cmpl	%r15d, %r12d
    d7c7:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d7cd:      	movq	0x8(%rsp), %r12
    d7d2:      	movq	%r12, 0x30(%rsp)
    d7d7:      	movq	0x38(%rsp), %rdx
    d7dc:      	movq	0x40(%rsp), %r15
    d7e1:      	jmp	0xd834 <generic_kprobe_path+0x2ea4>
    d7e3:      	leaq	0x10(%r15), %rdx
    d7e7:      	movl	$0x4, %eax
    d7ec:      	movq	%rbp, %rdi
    d7ef:      	movl	$0x8, %esi
    d7f4:      	callq	*%rax
    d7f6:      	movq	0x40(%rsp), %rax
    d7fb:      	cmpq	(%rsp), %rax
    d7ff:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d805:      	addq	$0x18, %r15
    d809:      	movl	$0x4, %eax
    d80e:      	leaq	0x30(%rsp), %rdi
    d813:      	movl	$0x8, %esi
    d818:      	movq	%r15, %rdx
    d81b:      	callq	*%rax
    d81d:      	movq	(%rsp), %r15
    d821:      	movq	%r15, 0x40(%rsp)
    d826:      	leaq	0x20(%r15), %rdx
    d82a:      	movq	%rdx, 0x38(%rsp)
    d82f:      	movq	0x30(%rsp), %r12
    d834:      	cmpq	0x18(%rsp), %r12
    d839:      	jne	0xd846 <generic_kprobe_path+0x2eb6>
    d83b:      	cmpq	0x20(%rsp), %rdx
    d840:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d846:      	movl	$0x4, %eax
    d84b:      	leaq	0x10(%rsp), %rdi
    d850:      	movl	$0x8, %esi
    d855:      	callq	*%rax
    d857:      	cmpq	0x10(%rsp), %r12
    d85c:      	je	0xd954 <generic_kprobe_path+0x2fc4>
    d862:      	leaq	0x18(%r12), %rbx
    d867:      	movl	$0x4, %eax
    d86c:      	movq	%rbp, %rdi
    d86f:      	movl	$0x8, %esi
    d874:      	movq	%rbx, %rdx
    d877:      	callq	*%rax
    d879:      	cmpq	%r12, (%rsp)
    d87d:      	je	0xd954 <generic_kprobe_path+0x2fc4>
    d883:      	movl	$0x4, %eax
    d888:      	leaq	0x8(%rsp), %rdi
    d88d:      	movl	$0x8, %esi
    d892:      	movq	%rbx, %rdx
    d895:      	callq	*%rax
    d897:      	addq	$0x20, %r12
    d89b:      	movl	$0x4, %eax
    d8a0:      	leaq	0x58(%rsp), %rdi
    d8a5:      	movl	$0x10, %ecx
    d8aa:      	movl	$0x10, %esi
    d8af:      	movq	%r12, %rdx
    d8b2:      	callq	*%rax
    d8b4:      	movq	0x28(%rsp), %rbx
    d8b9:      	movq	0x48(%rsp), %rax
    d8be:      	movl	0x5c(%rsp), %r15d
    d8c3:      	subq	%rbx, %rax
    d8c6:      	movl	0x50(%rsp), %r12d
    d8cb:      	movl	%r15d, %edx
    d8ce:      	subl	%r12d, %edx
    d8d1:      	movl	$0x0, %ecx
    d8d6:      	cmovbl	%ecx, %edx
    d8d9:      	addq	0x60(%rsp), %rdx
    d8de:      	xorl	%esi, %esi
    d8e0:      	cmpl	%r15d, %r12d
    d8e3:      	seta	%sil
    d8e7:      	movl	%r15d, %ecx
    d8ea:      	cmovbl	%r12d, %ecx
    d8ee:      	addl	%ecx, %esi
    d8f0:      	movl	%r12d, %edi
    d8f3:      	subl	%esi, %edi
    d8f5:      	movl	%edi, 0x50(%rsp)
    d8f9:      	subq	%rsi, %rax
    d8fc:      	jb	0x16402 <generic_kprobe_path+0xba72>
    d902:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d908:      	ja	0x16402 <generic_kprobe_path+0xba72>
    d90e:      	cmpl	%r15d, %r12d
    d911:      	jbe	0xd917 <generic_kprobe_path+0x2f87>
    d913:      	movb	$0x2f, (%rbx,%rax)
    d917:      	xorl	%edi, %edi
    d919:      	cmpl	%r15d, %r12d
    d91c:      	seta	%dil
    d920:      	movzbl	%cl, %esi
    d923:      	addq	%rax, %rbx
    d926:      	addq	%rbx, %rdi
    d929:      	movl	$0x4, %eax
    d92e:      	callq	*%rax
    d930:      	movq	%rbx, 0x48(%rsp)
    d935:      	cmpl	%r15d, %r12d
    d938:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    d93e:      	movq	0x8(%rsp), %r12
    d943:      	movq	%r12, 0x30(%rsp)
    d948:      	movq	0x38(%rsp), %rdx
    d94d:      	movq	0x40(%rsp), %r15
    d952:      	jmp	0xd9a5 <generic_kprobe_path+0x3015>
    d954:      	leaq	0x10(%r15), %rdx
    d958:      	movl	$0x4, %eax
    d95d:      	movq	%rbp, %rdi
    d960:      	movl	$0x8, %esi
    d965:      	callq	*%rax
    d967:      	movq	0x40(%rsp), %rax
    d96c:      	cmpq	(%rsp), %rax
    d970:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d976:      	addq	$0x18, %r15
    d97a:      	movl	$0x4, %eax
    d97f:      	leaq	0x30(%rsp), %rdi
    d984:      	movl	$0x8, %esi
    d989:      	movq	%r15, %rdx
    d98c:      	callq	*%rax
    d98e:      	movq	(%rsp), %r15
    d992:      	movq	%r15, 0x40(%rsp)
    d997:      	leaq	0x20(%r15), %rdx
    d99b:      	movq	%rdx, 0x38(%rsp)
    d9a0:      	movq	0x30(%rsp), %r12
    d9a5:      	cmpq	0x18(%rsp), %r12
    d9aa:      	jne	0xd9b7 <generic_kprobe_path+0x3027>
    d9ac:      	cmpq	0x20(%rsp), %rdx
    d9b1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    d9b7:      	movl	$0x4, %eax
    d9bc:      	leaq	0x10(%rsp), %rdi
    d9c1:      	movl	$0x8, %esi
    d9c6:      	callq	*%rax
    d9c8:      	cmpq	0x10(%rsp), %r12
    d9cd:      	je	0xdac5 <generic_kprobe_path+0x3135>
    d9d3:      	leaq	0x18(%r12), %rbx
    d9d8:      	movl	$0x4, %eax
    d9dd:      	movq	%rbp, %rdi
    d9e0:      	movl	$0x8, %esi
    d9e5:      	movq	%rbx, %rdx
    d9e8:      	callq	*%rax
    d9ea:      	cmpq	%r12, (%rsp)
    d9ee:      	je	0xdac5 <generic_kprobe_path+0x3135>
    d9f4:      	movl	$0x4, %eax
    d9f9:      	leaq	0x8(%rsp), %rdi
    d9fe:      	movl	$0x8, %esi
    da03:      	movq	%rbx, %rdx
    da06:      	callq	*%rax
    da08:      	addq	$0x20, %r12
    da0c:      	movl	$0x4, %eax
    da11:      	leaq	0x58(%rsp), %rdi
    da16:      	movl	$0x10, %ecx
    da1b:      	movl	$0x10, %esi
    da20:      	movq	%r12, %rdx
    da23:      	callq	*%rax
    da25:      	movq	0x28(%rsp), %rbx
    da2a:      	movq	0x48(%rsp), %rax
    da2f:      	movl	0x5c(%rsp), %r15d
    da34:      	subq	%rbx, %rax
    da37:      	movl	0x50(%rsp), %r12d
    da3c:      	movl	%r15d, %edx
    da3f:      	subl	%r12d, %edx
    da42:      	movl	$0x0, %ecx
    da47:      	cmovbl	%ecx, %edx
    da4a:      	addq	0x60(%rsp), %rdx
    da4f:      	xorl	%esi, %esi
    da51:      	cmpl	%r15d, %r12d
    da54:      	seta	%sil
    da58:      	movl	%r15d, %ecx
    da5b:      	cmovbl	%r12d, %ecx
    da5f:      	addl	%ecx, %esi
    da61:      	movl	%r12d, %edi
    da64:      	subl	%esi, %edi
    da66:      	movl	%edi, 0x50(%rsp)
    da6a:      	subq	%rsi, %rax
    da6d:      	jb	0x16402 <generic_kprobe_path+0xba72>
    da73:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    da79:      	ja	0x16402 <generic_kprobe_path+0xba72>
    da7f:      	cmpl	%r15d, %r12d
    da82:      	jbe	0xda88 <generic_kprobe_path+0x30f8>
    da84:      	movb	$0x2f, (%rbx,%rax)
    da88:      	xorl	%edi, %edi
    da8a:      	cmpl	%r15d, %r12d
    da8d:      	seta	%dil
    da91:      	movzbl	%cl, %esi
    da94:      	addq	%rax, %rbx
    da97:      	addq	%rbx, %rdi
    da9a:      	movl	$0x4, %eax
    da9f:      	callq	*%rax
    daa1:      	movq	%rbx, 0x48(%rsp)
    daa6:      	cmpl	%r15d, %r12d
    daa9:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    daaf:      	movq	0x8(%rsp), %r12
    dab4:      	movq	%r12, 0x30(%rsp)
    dab9:      	movq	0x38(%rsp), %rdx
    dabe:      	movq	0x40(%rsp), %r15
    dac3:      	jmp	0xdb16 <generic_kprobe_path+0x3186>
    dac5:      	leaq	0x10(%r15), %rdx
    dac9:      	movl	$0x4, %eax
    dace:      	movq	%rbp, %rdi
    dad1:      	movl	$0x8, %esi
    dad6:      	callq	*%rax
    dad8:      	movq	0x40(%rsp), %rax
    dadd:      	cmpq	(%rsp), %rax
    dae1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    dae7:      	addq	$0x18, %r15
    daeb:      	movl	$0x4, %eax
    daf0:      	leaq	0x30(%rsp), %rdi
    daf5:      	movl	$0x8, %esi
    dafa:      	movq	%r15, %rdx
    dafd:      	callq	*%rax
    daff:      	movq	(%rsp), %r15
    db03:      	movq	%r15, 0x40(%rsp)
    db08:      	leaq	0x20(%r15), %rdx
    db0c:      	movq	%rdx, 0x38(%rsp)
    db11:      	movq	0x30(%rsp), %r12
    db16:      	cmpq	0x18(%rsp), %r12
    db1b:      	jne	0xdb28 <generic_kprobe_path+0x3198>
    db1d:      	cmpq	0x20(%rsp), %rdx
    db22:      	je	0x163fd <generic_kprobe_path+0xba6d>
    db28:      	movl	$0x4, %eax
    db2d:      	leaq	0x10(%rsp), %rdi
    db32:      	movl	$0x8, %esi
    db37:      	callq	*%rax
    db39:      	cmpq	0x10(%rsp), %r12
    db3e:      	je	0xdc36 <generic_kprobe_path+0x32a6>
    db44:      	leaq	0x18(%r12), %rbx
    db49:      	movl	$0x4, %eax
    db4e:      	movq	%rbp, %rdi
    db51:      	movl	$0x8, %esi
    db56:      	movq	%rbx, %rdx
    db59:      	callq	*%rax
    db5b:      	cmpq	%r12, (%rsp)
    db5f:      	je	0xdc36 <generic_kprobe_path+0x32a6>
    db65:      	movl	$0x4, %eax
    db6a:      	leaq	0x8(%rsp), %rdi
    db6f:      	movl	$0x8, %esi
    db74:      	movq	%rbx, %rdx
    db77:      	callq	*%rax
    db79:      	addq	$0x20, %r12
    db7d:      	movl	$0x4, %eax
    db82:      	leaq	0x58(%rsp), %rdi
    db87:      	movl	$0x10, %ecx
    db8c:      	movl	$0x10, %esi
    db91:      	movq	%r12, %rdx
    db94:      	callq	*%rax
    db96:      	movq	0x28(%rsp), %rbx
    db9b:      	movq	0x48(%rsp), %rax
    dba0:      	movl	0x5c(%rsp), %r15d
    dba5:      	subq	%rbx, %rax
    dba8:      	movl	0x50(%rsp), %r12d
    dbad:      	movl	%r15d, %edx
    dbb0:      	subl	%r12d, %edx
    dbb3:      	movl	$0x0, %ecx
    dbb8:      	cmovbl	%ecx, %edx
    dbbb:      	addq	0x60(%rsp), %rdx
    dbc0:      	xorl	%esi, %esi
    dbc2:      	cmpl	%r15d, %r12d
    dbc5:      	seta	%sil
    dbc9:      	movl	%r15d, %ecx
    dbcc:      	cmovbl	%r12d, %ecx
    dbd0:      	addl	%ecx, %esi
    dbd2:      	movl	%r12d, %edi
    dbd5:      	subl	%esi, %edi
    dbd7:      	movl	%edi, 0x50(%rsp)
    dbdb:      	subq	%rsi, %rax
    dbde:      	jb	0x16402 <generic_kprobe_path+0xba72>
    dbe4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dbea:      	ja	0x16402 <generic_kprobe_path+0xba72>
    dbf0:      	cmpl	%r15d, %r12d
    dbf3:      	jbe	0xdbf9 <generic_kprobe_path+0x3269>
    dbf5:      	movb	$0x2f, (%rbx,%rax)
    dbf9:      	xorl	%edi, %edi
    dbfb:      	cmpl	%r15d, %r12d
    dbfe:      	seta	%dil
    dc02:      	movzbl	%cl, %esi
    dc05:      	addq	%rax, %rbx
    dc08:      	addq	%rbx, %rdi
    dc0b:      	movl	$0x4, %eax
    dc10:      	callq	*%rax
    dc12:      	movq	%rbx, 0x48(%rsp)
    dc17:      	cmpl	%r15d, %r12d
    dc1a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    dc20:      	movq	0x8(%rsp), %r12
    dc25:      	movq	%r12, 0x30(%rsp)
    dc2a:      	movq	0x38(%rsp), %rdx
    dc2f:      	movq	0x40(%rsp), %r15
    dc34:      	jmp	0xdc87 <generic_kprobe_path+0x32f7>
    dc36:      	leaq	0x10(%r15), %rdx
    dc3a:      	movl	$0x4, %eax
    dc3f:      	movq	%rbp, %rdi
    dc42:      	movl	$0x8, %esi
    dc47:      	callq	*%rax
    dc49:      	movq	0x40(%rsp), %rax
    dc4e:      	cmpq	(%rsp), %rax
    dc52:      	je	0x163fd <generic_kprobe_path+0xba6d>
    dc58:      	addq	$0x18, %r15
    dc5c:      	movl	$0x4, %eax
    dc61:      	leaq	0x30(%rsp), %rdi
    dc66:      	movl	$0x8, %esi
    dc6b:      	movq	%r15, %rdx
    dc6e:      	callq	*%rax
    dc70:      	movq	(%rsp), %r15
    dc74:      	movq	%r15, 0x40(%rsp)
    dc79:      	leaq	0x20(%r15), %rdx
    dc7d:      	movq	%rdx, 0x38(%rsp)
    dc82:      	movq	0x30(%rsp), %r12
    dc87:      	cmpq	0x18(%rsp), %r12
    dc8c:      	jne	0xdc99 <generic_kprobe_path+0x3309>
    dc8e:      	cmpq	0x20(%rsp), %rdx
    dc93:      	je	0x163fd <generic_kprobe_path+0xba6d>
    dc99:      	movl	$0x4, %eax
    dc9e:      	leaq	0x10(%rsp), %rdi
    dca3:      	movl	$0x8, %esi
    dca8:      	callq	*%rax
    dcaa:      	cmpq	0x10(%rsp), %r12
    dcaf:      	je	0xdda7 <generic_kprobe_path+0x3417>
    dcb5:      	leaq	0x18(%r12), %rbx
    dcba:      	movl	$0x4, %eax
    dcbf:      	movq	%rbp, %rdi
    dcc2:      	movl	$0x8, %esi
    dcc7:      	movq	%rbx, %rdx
    dcca:      	callq	*%rax
    dccc:      	cmpq	%r12, (%rsp)
    dcd0:      	je	0xdda7 <generic_kprobe_path+0x3417>
    dcd6:      	movl	$0x4, %eax
    dcdb:      	leaq	0x8(%rsp), %rdi
    dce0:      	movl	$0x8, %esi
    dce5:      	movq	%rbx, %rdx
    dce8:      	callq	*%rax
    dcea:      	addq	$0x20, %r12
    dcee:      	movl	$0x4, %eax
    dcf3:      	leaq	0x58(%rsp), %rdi
    dcf8:      	movl	$0x10, %ecx
    dcfd:      	movl	$0x10, %esi
    dd02:      	movq	%r12, %rdx
    dd05:      	callq	*%rax
    dd07:      	movq	0x28(%rsp), %rbx
    dd0c:      	movq	0x48(%rsp), %rax
    dd11:      	movl	0x5c(%rsp), %r15d
    dd16:      	subq	%rbx, %rax
    dd19:      	movl	0x50(%rsp), %r12d
    dd1e:      	movl	%r15d, %edx
    dd21:      	subl	%r12d, %edx
    dd24:      	movl	$0x0, %ecx
    dd29:      	cmovbl	%ecx, %edx
    dd2c:      	addq	0x60(%rsp), %rdx
    dd31:      	xorl	%esi, %esi
    dd33:      	cmpl	%r15d, %r12d
    dd36:      	seta	%sil
    dd3a:      	movl	%r15d, %ecx
    dd3d:      	cmovbl	%r12d, %ecx
    dd41:      	addl	%ecx, %esi
    dd43:      	movl	%r12d, %edi
    dd46:      	subl	%esi, %edi
    dd48:      	movl	%edi, 0x50(%rsp)
    dd4c:      	subq	%rsi, %rax
    dd4f:      	jb	0x16402 <generic_kprobe_path+0xba72>
    dd55:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dd5b:      	ja	0x16402 <generic_kprobe_path+0xba72>
    dd61:      	cmpl	%r15d, %r12d
    dd64:      	jbe	0xdd6a <generic_kprobe_path+0x33da>
    dd66:      	movb	$0x2f, (%rbx,%rax)
    dd6a:      	xorl	%edi, %edi
    dd6c:      	cmpl	%r15d, %r12d
    dd6f:      	seta	%dil
    dd73:      	movzbl	%cl, %esi
    dd76:      	addq	%rax, %rbx
    dd79:      	addq	%rbx, %rdi
    dd7c:      	movl	$0x4, %eax
    dd81:      	callq	*%rax
    dd83:      	movq	%rbx, 0x48(%rsp)
    dd88:      	cmpl	%r15d, %r12d
    dd8b:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    dd91:      	movq	0x8(%rsp), %r12
    dd96:      	movq	%r12, 0x30(%rsp)
    dd9b:      	movq	0x38(%rsp), %rdx
    dda0:      	movq	0x40(%rsp), %r15
    dda5:      	jmp	0xddf8 <generic_kprobe_path+0x3468>
    dda7:      	leaq	0x10(%r15), %rdx
    ddab:      	movl	$0x4, %eax
    ddb0:      	movq	%rbp, %rdi
    ddb3:      	movl	$0x8, %esi
    ddb8:      	callq	*%rax
    ddba:      	movq	0x40(%rsp), %rax
    ddbf:      	cmpq	(%rsp), %rax
    ddc3:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ddc9:      	addq	$0x18, %r15
    ddcd:      	movl	$0x4, %eax
    ddd2:      	leaq	0x30(%rsp), %rdi
    ddd7:      	movl	$0x8, %esi
    dddc:      	movq	%r15, %rdx
    dddf:      	callq	*%rax
    dde1:      	movq	(%rsp), %r15
    dde5:      	movq	%r15, 0x40(%rsp)
    ddea:      	leaq	0x20(%r15), %rdx
    ddee:      	movq	%rdx, 0x38(%rsp)
    ddf3:      	movq	0x30(%rsp), %r12
    ddf8:      	cmpq	0x18(%rsp), %r12
    ddfd:      	jne	0xde0a <generic_kprobe_path+0x347a>
    ddff:      	cmpq	0x20(%rsp), %rdx
    de04:      	je	0x163fd <generic_kprobe_path+0xba6d>
    de0a:      	movl	$0x4, %eax
    de0f:      	leaq	0x10(%rsp), %rdi
    de14:      	movl	$0x8, %esi
    de19:      	callq	*%rax
    de1b:      	cmpq	0x10(%rsp), %r12
    de20:      	je	0xdf18 <generic_kprobe_path+0x3588>
    de26:      	leaq	0x18(%r12), %rbx
    de2b:      	movl	$0x4, %eax
    de30:      	movq	%rbp, %rdi
    de33:      	movl	$0x8, %esi
    de38:      	movq	%rbx, %rdx
    de3b:      	callq	*%rax
    de3d:      	cmpq	%r12, (%rsp)
    de41:      	je	0xdf18 <generic_kprobe_path+0x3588>
    de47:      	movl	$0x4, %eax
    de4c:      	leaq	0x8(%rsp), %rdi
    de51:      	movl	$0x8, %esi
    de56:      	movq	%rbx, %rdx
    de59:      	callq	*%rax
    de5b:      	addq	$0x20, %r12
    de5f:      	movl	$0x4, %eax
    de64:      	leaq	0x58(%rsp), %rdi
    de69:      	movl	$0x10, %ecx
    de6e:      	movl	$0x10, %esi
    de73:      	movq	%r12, %rdx
    de76:      	callq	*%rax
    de78:      	movq	0x28(%rsp), %rbx
    de7d:      	movq	0x48(%rsp), %rax
    de82:      	movl	0x5c(%rsp), %r15d
    de87:      	subq	%rbx, %rax
    de8a:      	movl	0x50(%rsp), %r12d
    de8f:      	movl	%r15d, %edx
    de92:      	subl	%r12d, %edx
    de95:      	movl	$0x0, %ecx
    de9a:      	cmovbl	%ecx, %edx
    de9d:      	addq	0x60(%rsp), %rdx
    dea2:      	xorl	%esi, %esi
    dea4:      	cmpl	%r15d, %r12d
    dea7:      	seta	%sil
    deab:      	movl	%r15d, %ecx
    deae:      	cmovbl	%r12d, %ecx
    deb2:      	addl	%ecx, %esi
    deb4:      	movl	%r12d, %edi
    deb7:      	subl	%esi, %edi
    deb9:      	movl	%edi, 0x50(%rsp)
    debd:      	subq	%rsi, %rax
    dec0:      	jb	0x16402 <generic_kprobe_path+0xba72>
    dec6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    decc:      	ja	0x16402 <generic_kprobe_path+0xba72>
    ded2:      	cmpl	%r15d, %r12d
    ded5:      	jbe	0xdedb <generic_kprobe_path+0x354b>
    ded7:      	movb	$0x2f, (%rbx,%rax)
    dedb:      	xorl	%edi, %edi
    dedd:      	cmpl	%r15d, %r12d
    dee0:      	seta	%dil
    dee4:      	movzbl	%cl, %esi
    dee7:      	addq	%rax, %rbx
    deea:      	addq	%rbx, %rdi
    deed:      	movl	$0x4, %eax
    def2:      	callq	*%rax
    def4:      	movq	%rbx, 0x48(%rsp)
    def9:      	cmpl	%r15d, %r12d
    defc:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    df02:      	movq	0x8(%rsp), %r12
    df07:      	movq	%r12, 0x30(%rsp)
    df0c:      	movq	0x38(%rsp), %rdx
    df11:      	movq	0x40(%rsp), %r15
    df16:      	jmp	0xdf69 <generic_kprobe_path+0x35d9>
    df18:      	leaq	0x10(%r15), %rdx
    df1c:      	movl	$0x4, %eax
    df21:      	movq	%rbp, %rdi
    df24:      	movl	$0x8, %esi
    df29:      	callq	*%rax
    df2b:      	movq	0x40(%rsp), %rax
    df30:      	cmpq	(%rsp), %rax
    df34:      	je	0x163fd <generic_kprobe_path+0xba6d>
    df3a:      	addq	$0x18, %r15
    df3e:      	movl	$0x4, %eax
    df43:      	leaq	0x30(%rsp), %rdi
    df48:      	movl	$0x8, %esi
    df4d:      	movq	%r15, %rdx
    df50:      	callq	*%rax
    df52:      	movq	(%rsp), %r15
    df56:      	movq	%r15, 0x40(%rsp)
    df5b:      	leaq	0x20(%r15), %rdx
    df5f:      	movq	%rdx, 0x38(%rsp)
    df64:      	movq	0x30(%rsp), %r12
    df69:      	cmpq	0x18(%rsp), %r12
    df6e:      	jne	0xdf7b <generic_kprobe_path+0x35eb>
    df70:      	cmpq	0x20(%rsp), %rdx
    df75:      	je	0x163fd <generic_kprobe_path+0xba6d>
    df7b:      	movl	$0x4, %eax
    df80:      	leaq	0x10(%rsp), %rdi
    df85:      	movl	$0x8, %esi
    df8a:      	callq	*%rax
    df8c:      	cmpq	0x10(%rsp), %r12
    df91:      	je	0xe089 <generic_kprobe_path+0x36f9>
    df97:      	leaq	0x18(%r12), %rbx
    df9c:      	movl	$0x4, %eax
    dfa1:      	movq	%rbp, %rdi
    dfa4:      	movl	$0x8, %esi
    dfa9:      	movq	%rbx, %rdx
    dfac:      	callq	*%rax
    dfae:      	cmpq	%r12, (%rsp)
    dfb2:      	je	0xe089 <generic_kprobe_path+0x36f9>
    dfb8:      	movl	$0x4, %eax
    dfbd:      	leaq	0x8(%rsp), %rdi
    dfc2:      	movl	$0x8, %esi
    dfc7:      	movq	%rbx, %rdx
    dfca:      	callq	*%rax
    dfcc:      	addq	$0x20, %r12
    dfd0:      	movl	$0x4, %eax
    dfd5:      	leaq	0x58(%rsp), %rdi
    dfda:      	movl	$0x10, %ecx
    dfdf:      	movl	$0x10, %esi
    dfe4:      	movq	%r12, %rdx
    dfe7:      	callq	*%rax
    dfe9:      	movq	0x28(%rsp), %rbx
    dfee:      	movq	0x48(%rsp), %rax
    dff3:      	movl	0x5c(%rsp), %r15d
    dff8:      	subq	%rbx, %rax
    dffb:      	movl	0x50(%rsp), %r12d
    e000:      	movl	%r15d, %edx
    e003:      	subl	%r12d, %edx
    e006:      	movl	$0x0, %ecx
    e00b:      	cmovbl	%ecx, %edx
    e00e:      	addq	0x60(%rsp), %rdx
    e013:      	xorl	%esi, %esi
    e015:      	cmpl	%r15d, %r12d
    e018:      	seta	%sil
    e01c:      	movl	%r15d, %ecx
    e01f:      	cmovbl	%r12d, %ecx
    e023:      	addl	%ecx, %esi
    e025:      	movl	%r12d, %edi
    e028:      	subl	%esi, %edi
    e02a:      	movl	%edi, 0x50(%rsp)
    e02e:      	subq	%rsi, %rax
    e031:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e037:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e03d:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e043:      	cmpl	%r15d, %r12d
    e046:      	jbe	0xe04c <generic_kprobe_path+0x36bc>
    e048:      	movb	$0x2f, (%rbx,%rax)
    e04c:      	xorl	%edi, %edi
    e04e:      	cmpl	%r15d, %r12d
    e051:      	seta	%dil
    e055:      	movzbl	%cl, %esi
    e058:      	addq	%rax, %rbx
    e05b:      	addq	%rbx, %rdi
    e05e:      	movl	$0x4, %eax
    e063:      	callq	*%rax
    e065:      	movq	%rbx, 0x48(%rsp)
    e06a:      	cmpl	%r15d, %r12d
    e06d:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e073:      	movq	0x8(%rsp), %r12
    e078:      	movq	%r12, 0x30(%rsp)
    e07d:      	movq	0x38(%rsp), %rdx
    e082:      	movq	0x40(%rsp), %r15
    e087:      	jmp	0xe0da <generic_kprobe_path+0x374a>
    e089:      	leaq	0x10(%r15), %rdx
    e08d:      	movl	$0x4, %eax
    e092:      	movq	%rbp, %rdi
    e095:      	movl	$0x8, %esi
    e09a:      	callq	*%rax
    e09c:      	movq	0x40(%rsp), %rax
    e0a1:      	cmpq	(%rsp), %rax
    e0a5:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e0ab:      	addq	$0x18, %r15
    e0af:      	movl	$0x4, %eax
    e0b4:      	leaq	0x30(%rsp), %rdi
    e0b9:      	movl	$0x8, %esi
    e0be:      	movq	%r15, %rdx
    e0c1:      	callq	*%rax
    e0c3:      	movq	(%rsp), %r15
    e0c7:      	movq	%r15, 0x40(%rsp)
    e0cc:      	leaq	0x20(%r15), %rdx
    e0d0:      	movq	%rdx, 0x38(%rsp)
    e0d5:      	movq	0x30(%rsp), %r12
    e0da:      	cmpq	0x18(%rsp), %r12
    e0df:      	jne	0xe0ec <generic_kprobe_path+0x375c>
    e0e1:      	cmpq	0x20(%rsp), %rdx
    e0e6:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e0ec:      	movl	$0x4, %eax
    e0f1:      	leaq	0x10(%rsp), %rdi
    e0f6:      	movl	$0x8, %esi
    e0fb:      	callq	*%rax
    e0fd:      	cmpq	0x10(%rsp), %r12
    e102:      	je	0xe1fa <generic_kprobe_path+0x386a>
    e108:      	leaq	0x18(%r12), %rbx
    e10d:      	movl	$0x4, %eax
    e112:      	movq	%rbp, %rdi
    e115:      	movl	$0x8, %esi
    e11a:      	movq	%rbx, %rdx
    e11d:      	callq	*%rax
    e11f:      	cmpq	%r12, (%rsp)
    e123:      	je	0xe1fa <generic_kprobe_path+0x386a>
    e129:      	movl	$0x4, %eax
    e12e:      	leaq	0x8(%rsp), %rdi
    e133:      	movl	$0x8, %esi
    e138:      	movq	%rbx, %rdx
    e13b:      	callq	*%rax
    e13d:      	addq	$0x20, %r12
    e141:      	movl	$0x4, %eax
    e146:      	leaq	0x58(%rsp), %rdi
    e14b:      	movl	$0x10, %ecx
    e150:      	movl	$0x10, %esi
    e155:      	movq	%r12, %rdx
    e158:      	callq	*%rax
    e15a:      	movq	0x28(%rsp), %rbx
    e15f:      	movq	0x48(%rsp), %rax
    e164:      	movl	0x5c(%rsp), %r15d
    e169:      	subq	%rbx, %rax
    e16c:      	movl	0x50(%rsp), %r12d
    e171:      	movl	%r15d, %edx
    e174:      	subl	%r12d, %edx
    e177:      	movl	$0x0, %ecx
    e17c:      	cmovbl	%ecx, %edx
    e17f:      	addq	0x60(%rsp), %rdx
    e184:      	xorl	%esi, %esi
    e186:      	cmpl	%r15d, %r12d
    e189:      	seta	%sil
    e18d:      	movl	%r15d, %ecx
    e190:      	cmovbl	%r12d, %ecx
    e194:      	addl	%ecx, %esi
    e196:      	movl	%r12d, %edi
    e199:      	subl	%esi, %edi
    e19b:      	movl	%edi, 0x50(%rsp)
    e19f:      	subq	%rsi, %rax
    e1a2:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e1a8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e1ae:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e1b4:      	cmpl	%r15d, %r12d
    e1b7:      	jbe	0xe1bd <generic_kprobe_path+0x382d>
    e1b9:      	movb	$0x2f, (%rbx,%rax)
    e1bd:      	xorl	%edi, %edi
    e1bf:      	cmpl	%r15d, %r12d
    e1c2:      	seta	%dil
    e1c6:      	movzbl	%cl, %esi
    e1c9:      	addq	%rax, %rbx
    e1cc:      	addq	%rbx, %rdi
    e1cf:      	movl	$0x4, %eax
    e1d4:      	callq	*%rax
    e1d6:      	movq	%rbx, 0x48(%rsp)
    e1db:      	cmpl	%r15d, %r12d
    e1de:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e1e4:      	movq	0x8(%rsp), %r12
    e1e9:      	movq	%r12, 0x30(%rsp)
    e1ee:      	movq	0x38(%rsp), %rdx
    e1f3:      	movq	0x40(%rsp), %r15
    e1f8:      	jmp	0xe24b <generic_kprobe_path+0x38bb>
    e1fa:      	leaq	0x10(%r15), %rdx
    e1fe:      	movl	$0x4, %eax
    e203:      	movq	%rbp, %rdi
    e206:      	movl	$0x8, %esi
    e20b:      	callq	*%rax
    e20d:      	movq	0x40(%rsp), %rax
    e212:      	cmpq	(%rsp), %rax
    e216:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e21c:      	addq	$0x18, %r15
    e220:      	movl	$0x4, %eax
    e225:      	leaq	0x30(%rsp), %rdi
    e22a:      	movl	$0x8, %esi
    e22f:      	movq	%r15, %rdx
    e232:      	callq	*%rax
    e234:      	movq	(%rsp), %r15
    e238:      	movq	%r15, 0x40(%rsp)
    e23d:      	leaq	0x20(%r15), %rdx
    e241:      	movq	%rdx, 0x38(%rsp)
    e246:      	movq	0x30(%rsp), %r12
    e24b:      	cmpq	0x18(%rsp), %r12
    e250:      	jne	0xe25d <generic_kprobe_path+0x38cd>
    e252:      	cmpq	0x20(%rsp), %rdx
    e257:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e25d:      	movl	$0x4, %eax
    e262:      	leaq	0x10(%rsp), %rdi
    e267:      	movl	$0x8, %esi
    e26c:      	callq	*%rax
    e26e:      	cmpq	0x10(%rsp), %r12
    e273:      	je	0xe36b <generic_kprobe_path+0x39db>
    e279:      	leaq	0x18(%r12), %rbx
    e27e:      	movl	$0x4, %eax
    e283:      	movq	%rbp, %rdi
    e286:      	movl	$0x8, %esi
    e28b:      	movq	%rbx, %rdx
    e28e:      	callq	*%rax
    e290:      	cmpq	%r12, (%rsp)
    e294:      	je	0xe36b <generic_kprobe_path+0x39db>
    e29a:      	movl	$0x4, %eax
    e29f:      	leaq	0x8(%rsp), %rdi
    e2a4:      	movl	$0x8, %esi
    e2a9:      	movq	%rbx, %rdx
    e2ac:      	callq	*%rax
    e2ae:      	addq	$0x20, %r12
    e2b2:      	movl	$0x4, %eax
    e2b7:      	leaq	0x58(%rsp), %rdi
    e2bc:      	movl	$0x10, %ecx
    e2c1:      	movl	$0x10, %esi
    e2c6:      	movq	%r12, %rdx
    e2c9:      	callq	*%rax
    e2cb:      	movq	0x28(%rsp), %rbx
    e2d0:      	movq	0x48(%rsp), %rax
    e2d5:      	movl	0x5c(%rsp), %r15d
    e2da:      	subq	%rbx, %rax
    e2dd:      	movl	0x50(%rsp), %r12d
    e2e2:      	movl	%r15d, %edx
    e2e5:      	subl	%r12d, %edx
    e2e8:      	movl	$0x0, %ecx
    e2ed:      	cmovbl	%ecx, %edx
    e2f0:      	addq	0x60(%rsp), %rdx
    e2f5:      	xorl	%esi, %esi
    e2f7:      	cmpl	%r15d, %r12d
    e2fa:      	seta	%sil
    e2fe:      	movl	%r15d, %ecx
    e301:      	cmovbl	%r12d, %ecx
    e305:      	addl	%ecx, %esi
    e307:      	movl	%r12d, %edi
    e30a:      	subl	%esi, %edi
    e30c:      	movl	%edi, 0x50(%rsp)
    e310:      	subq	%rsi, %rax
    e313:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e319:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e31f:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e325:      	cmpl	%r15d, %r12d
    e328:      	jbe	0xe32e <generic_kprobe_path+0x399e>
    e32a:      	movb	$0x2f, (%rbx,%rax)
    e32e:      	xorl	%edi, %edi
    e330:      	cmpl	%r15d, %r12d
    e333:      	seta	%dil
    e337:      	movzbl	%cl, %esi
    e33a:      	addq	%rax, %rbx
    e33d:      	addq	%rbx, %rdi
    e340:      	movl	$0x4, %eax
    e345:      	callq	*%rax
    e347:      	movq	%rbx, 0x48(%rsp)
    e34c:      	cmpl	%r15d, %r12d
    e34f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e355:      	movq	0x8(%rsp), %r12
    e35a:      	movq	%r12, 0x30(%rsp)
    e35f:      	movq	0x38(%rsp), %rdx
    e364:      	movq	0x40(%rsp), %r15
    e369:      	jmp	0xe3bc <generic_kprobe_path+0x3a2c>
    e36b:      	leaq	0x10(%r15), %rdx
    e36f:      	movl	$0x4, %eax
    e374:      	movq	%rbp, %rdi
    e377:      	movl	$0x8, %esi
    e37c:      	callq	*%rax
    e37e:      	movq	0x40(%rsp), %rax
    e383:      	cmpq	(%rsp), %rax
    e387:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e38d:      	addq	$0x18, %r15
    e391:      	movl	$0x4, %eax
    e396:      	leaq	0x30(%rsp), %rdi
    e39b:      	movl	$0x8, %esi
    e3a0:      	movq	%r15, %rdx
    e3a3:      	callq	*%rax
    e3a5:      	movq	(%rsp), %r15
    e3a9:      	movq	%r15, 0x40(%rsp)
    e3ae:      	leaq	0x20(%r15), %rdx
    e3b2:      	movq	%rdx, 0x38(%rsp)
    e3b7:      	movq	0x30(%rsp), %r12
    e3bc:      	cmpq	0x18(%rsp), %r12
    e3c1:      	jne	0xe3ce <generic_kprobe_path+0x3a3e>
    e3c3:      	cmpq	0x20(%rsp), %rdx
    e3c8:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e3ce:      	movl	$0x4, %eax
    e3d3:      	leaq	0x10(%rsp), %rdi
    e3d8:      	movl	$0x8, %esi
    e3dd:      	callq	*%rax
    e3df:      	cmpq	0x10(%rsp), %r12
    e3e4:      	je	0xe4dc <generic_kprobe_path+0x3b4c>
    e3ea:      	leaq	0x18(%r12), %rbx
    e3ef:      	movl	$0x4, %eax
    e3f4:      	movq	%rbp, %rdi
    e3f7:      	movl	$0x8, %esi
    e3fc:      	movq	%rbx, %rdx
    e3ff:      	callq	*%rax
    e401:      	cmpq	%r12, (%rsp)
    e405:      	je	0xe4dc <generic_kprobe_path+0x3b4c>
    e40b:      	movl	$0x4, %eax
    e410:      	leaq	0x8(%rsp), %rdi
    e415:      	movl	$0x8, %esi
    e41a:      	movq	%rbx, %rdx
    e41d:      	callq	*%rax
    e41f:      	addq	$0x20, %r12
    e423:      	movl	$0x4, %eax
    e428:      	leaq	0x58(%rsp), %rdi
    e42d:      	movl	$0x10, %ecx
    e432:      	movl	$0x10, %esi
    e437:      	movq	%r12, %rdx
    e43a:      	callq	*%rax
    e43c:      	movq	0x28(%rsp), %rbx
    e441:      	movq	0x48(%rsp), %rax
    e446:      	movl	0x5c(%rsp), %r15d
    e44b:      	subq	%rbx, %rax
    e44e:      	movl	0x50(%rsp), %r12d
    e453:      	movl	%r15d, %edx
    e456:      	subl	%r12d, %edx
    e459:      	movl	$0x0, %ecx
    e45e:      	cmovbl	%ecx, %edx
    e461:      	addq	0x60(%rsp), %rdx
    e466:      	xorl	%esi, %esi
    e468:      	cmpl	%r15d, %r12d
    e46b:      	seta	%sil
    e46f:      	movl	%r15d, %ecx
    e472:      	cmovbl	%r12d, %ecx
    e476:      	addl	%ecx, %esi
    e478:      	movl	%r12d, %edi
    e47b:      	subl	%esi, %edi
    e47d:      	movl	%edi, 0x50(%rsp)
    e481:      	subq	%rsi, %rax
    e484:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e48a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e490:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e496:      	cmpl	%r15d, %r12d
    e499:      	jbe	0xe49f <generic_kprobe_path+0x3b0f>
    e49b:      	movb	$0x2f, (%rbx,%rax)
    e49f:      	xorl	%edi, %edi
    e4a1:      	cmpl	%r15d, %r12d
    e4a4:      	seta	%dil
    e4a8:      	movzbl	%cl, %esi
    e4ab:      	addq	%rax, %rbx
    e4ae:      	addq	%rbx, %rdi
    e4b1:      	movl	$0x4, %eax
    e4b6:      	callq	*%rax
    e4b8:      	movq	%rbx, 0x48(%rsp)
    e4bd:      	cmpl	%r15d, %r12d
    e4c0:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e4c6:      	movq	0x8(%rsp), %r12
    e4cb:      	movq	%r12, 0x30(%rsp)
    e4d0:      	movq	0x38(%rsp), %rdx
    e4d5:      	movq	0x40(%rsp), %r15
    e4da:      	jmp	0xe52d <generic_kprobe_path+0x3b9d>
    e4dc:      	leaq	0x10(%r15), %rdx
    e4e0:      	movl	$0x4, %eax
    e4e5:      	movq	%rbp, %rdi
    e4e8:      	movl	$0x8, %esi
    e4ed:      	callq	*%rax
    e4ef:      	movq	0x40(%rsp), %rax
    e4f4:      	cmpq	(%rsp), %rax
    e4f8:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e4fe:      	addq	$0x18, %r15
    e502:      	movl	$0x4, %eax
    e507:      	leaq	0x30(%rsp), %rdi
    e50c:      	movl	$0x8, %esi
    e511:      	movq	%r15, %rdx
    e514:      	callq	*%rax
    e516:      	movq	(%rsp), %r15
    e51a:      	movq	%r15, 0x40(%rsp)
    e51f:      	leaq	0x20(%r15), %rdx
    e523:      	movq	%rdx, 0x38(%rsp)
    e528:      	movq	0x30(%rsp), %r12
    e52d:      	cmpq	0x18(%rsp), %r12
    e532:      	jne	0xe53f <generic_kprobe_path+0x3baf>
    e534:      	cmpq	0x20(%rsp), %rdx
    e539:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e53f:      	movl	$0x4, %eax
    e544:      	leaq	0x10(%rsp), %rdi
    e549:      	movl	$0x8, %esi
    e54e:      	callq	*%rax
    e550:      	cmpq	0x10(%rsp), %r12
    e555:      	je	0xe64d <generic_kprobe_path+0x3cbd>
    e55b:      	leaq	0x18(%r12), %rbx
    e560:      	movl	$0x4, %eax
    e565:      	movq	%rbp, %rdi
    e568:      	movl	$0x8, %esi
    e56d:      	movq	%rbx, %rdx
    e570:      	callq	*%rax
    e572:      	cmpq	%r12, (%rsp)
    e576:      	je	0xe64d <generic_kprobe_path+0x3cbd>
    e57c:      	movl	$0x4, %eax
    e581:      	leaq	0x8(%rsp), %rdi
    e586:      	movl	$0x8, %esi
    e58b:      	movq	%rbx, %rdx
    e58e:      	callq	*%rax
    e590:      	addq	$0x20, %r12
    e594:      	movl	$0x4, %eax
    e599:      	leaq	0x58(%rsp), %rdi
    e59e:      	movl	$0x10, %ecx
    e5a3:      	movl	$0x10, %esi
    e5a8:      	movq	%r12, %rdx
    e5ab:      	callq	*%rax
    e5ad:      	movq	0x28(%rsp), %rbx
    e5b2:      	movq	0x48(%rsp), %rax
    e5b7:      	movl	0x5c(%rsp), %r15d
    e5bc:      	subq	%rbx, %rax
    e5bf:      	movl	0x50(%rsp), %r12d
    e5c4:      	movl	%r15d, %edx
    e5c7:      	subl	%r12d, %edx
    e5ca:      	movl	$0x0, %ecx
    e5cf:      	cmovbl	%ecx, %edx
    e5d2:      	addq	0x60(%rsp), %rdx
    e5d7:      	xorl	%esi, %esi
    e5d9:      	cmpl	%r15d, %r12d
    e5dc:      	seta	%sil
    e5e0:      	movl	%r15d, %ecx
    e5e3:      	cmovbl	%r12d, %ecx
    e5e7:      	addl	%ecx, %esi
    e5e9:      	movl	%r12d, %edi
    e5ec:      	subl	%esi, %edi
    e5ee:      	movl	%edi, 0x50(%rsp)
    e5f2:      	subq	%rsi, %rax
    e5f5:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e5fb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e601:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e607:      	cmpl	%r15d, %r12d
    e60a:      	jbe	0xe610 <generic_kprobe_path+0x3c80>
    e60c:      	movb	$0x2f, (%rbx,%rax)
    e610:      	xorl	%edi, %edi
    e612:      	cmpl	%r15d, %r12d
    e615:      	seta	%dil
    e619:      	movzbl	%cl, %esi
    e61c:      	addq	%rax, %rbx
    e61f:      	addq	%rbx, %rdi
    e622:      	movl	$0x4, %eax
    e627:      	callq	*%rax
    e629:      	movq	%rbx, 0x48(%rsp)
    e62e:      	cmpl	%r15d, %r12d
    e631:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e637:      	movq	0x8(%rsp), %r12
    e63c:      	movq	%r12, 0x30(%rsp)
    e641:      	movq	0x38(%rsp), %rdx
    e646:      	movq	0x40(%rsp), %r15
    e64b:      	jmp	0xe69e <generic_kprobe_path+0x3d0e>
    e64d:      	leaq	0x10(%r15), %rdx
    e651:      	movl	$0x4, %eax
    e656:      	movq	%rbp, %rdi
    e659:      	movl	$0x8, %esi
    e65e:      	callq	*%rax
    e660:      	movq	0x40(%rsp), %rax
    e665:      	cmpq	(%rsp), %rax
    e669:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e66f:      	addq	$0x18, %r15
    e673:      	movl	$0x4, %eax
    e678:      	leaq	0x30(%rsp), %rdi
    e67d:      	movl	$0x8, %esi
    e682:      	movq	%r15, %rdx
    e685:      	callq	*%rax
    e687:      	movq	(%rsp), %r15
    e68b:      	movq	%r15, 0x40(%rsp)
    e690:      	leaq	0x20(%r15), %rdx
    e694:      	movq	%rdx, 0x38(%rsp)
    e699:      	movq	0x30(%rsp), %r12
    e69e:      	cmpq	0x18(%rsp), %r12
    e6a3:      	jne	0xe6b0 <generic_kprobe_path+0x3d20>
    e6a5:      	cmpq	0x20(%rsp), %rdx
    e6aa:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e6b0:      	movl	$0x4, %eax
    e6b5:      	leaq	0x10(%rsp), %rdi
    e6ba:      	movl	$0x8, %esi
    e6bf:      	callq	*%rax
    e6c1:      	cmpq	0x10(%rsp), %r12
    e6c6:      	je	0xe7be <generic_kprobe_path+0x3e2e>
    e6cc:      	leaq	0x18(%r12), %rbx
    e6d1:      	movl	$0x4, %eax
    e6d6:      	movq	%rbp, %rdi
    e6d9:      	movl	$0x8, %esi
    e6de:      	movq	%rbx, %rdx
    e6e1:      	callq	*%rax
    e6e3:      	cmpq	%r12, (%rsp)
    e6e7:      	je	0xe7be <generic_kprobe_path+0x3e2e>
    e6ed:      	movl	$0x4, %eax
    e6f2:      	leaq	0x8(%rsp), %rdi
    e6f7:      	movl	$0x8, %esi
    e6fc:      	movq	%rbx, %rdx
    e6ff:      	callq	*%rax
    e701:      	addq	$0x20, %r12
    e705:      	movl	$0x4, %eax
    e70a:      	leaq	0x58(%rsp), %rdi
    e70f:      	movl	$0x10, %ecx
    e714:      	movl	$0x10, %esi
    e719:      	movq	%r12, %rdx
    e71c:      	callq	*%rax
    e71e:      	movq	0x28(%rsp), %rbx
    e723:      	movq	0x48(%rsp), %rax
    e728:      	movl	0x5c(%rsp), %r15d
    e72d:      	subq	%rbx, %rax
    e730:      	movl	0x50(%rsp), %r12d
    e735:      	movl	%r15d, %edx
    e738:      	subl	%r12d, %edx
    e73b:      	movl	$0x0, %ecx
    e740:      	cmovbl	%ecx, %edx
    e743:      	addq	0x60(%rsp), %rdx
    e748:      	xorl	%esi, %esi
    e74a:      	cmpl	%r15d, %r12d
    e74d:      	seta	%sil
    e751:      	movl	%r15d, %ecx
    e754:      	cmovbl	%r12d, %ecx
    e758:      	addl	%ecx, %esi
    e75a:      	movl	%r12d, %edi
    e75d:      	subl	%esi, %edi
    e75f:      	movl	%edi, 0x50(%rsp)
    e763:      	subq	%rsi, %rax
    e766:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e76c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e772:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e778:      	cmpl	%r15d, %r12d
    e77b:      	jbe	0xe781 <generic_kprobe_path+0x3df1>
    e77d:      	movb	$0x2f, (%rbx,%rax)
    e781:      	xorl	%edi, %edi
    e783:      	cmpl	%r15d, %r12d
    e786:      	seta	%dil
    e78a:      	movzbl	%cl, %esi
    e78d:      	addq	%rax, %rbx
    e790:      	addq	%rbx, %rdi
    e793:      	movl	$0x4, %eax
    e798:      	callq	*%rax
    e79a:      	movq	%rbx, 0x48(%rsp)
    e79f:      	cmpl	%r15d, %r12d
    e7a2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e7a8:      	movq	0x8(%rsp), %r12
    e7ad:      	movq	%r12, 0x30(%rsp)
    e7b2:      	movq	0x38(%rsp), %rdx
    e7b7:      	movq	0x40(%rsp), %r15
    e7bc:      	jmp	0xe80f <generic_kprobe_path+0x3e7f>
    e7be:      	leaq	0x10(%r15), %rdx
    e7c2:      	movl	$0x4, %eax
    e7c7:      	movq	%rbp, %rdi
    e7ca:      	movl	$0x8, %esi
    e7cf:      	callq	*%rax
    e7d1:      	movq	0x40(%rsp), %rax
    e7d6:      	cmpq	(%rsp), %rax
    e7da:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e7e0:      	addq	$0x18, %r15
    e7e4:      	movl	$0x4, %eax
    e7e9:      	leaq	0x30(%rsp), %rdi
    e7ee:      	movl	$0x8, %esi
    e7f3:      	movq	%r15, %rdx
    e7f6:      	callq	*%rax
    e7f8:      	movq	(%rsp), %r15
    e7fc:      	movq	%r15, 0x40(%rsp)
    e801:      	leaq	0x20(%r15), %rdx
    e805:      	movq	%rdx, 0x38(%rsp)
    e80a:      	movq	0x30(%rsp), %r12
    e80f:      	cmpq	0x18(%rsp), %r12
    e814:      	jne	0xe821 <generic_kprobe_path+0x3e91>
    e816:      	cmpq	0x20(%rsp), %rdx
    e81b:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e821:      	movl	$0x4, %eax
    e826:      	leaq	0x10(%rsp), %rdi
    e82b:      	movl	$0x8, %esi
    e830:      	callq	*%rax
    e832:      	cmpq	0x10(%rsp), %r12
    e837:      	je	0xe92f <generic_kprobe_path+0x3f9f>
    e83d:      	leaq	0x18(%r12), %rbx
    e842:      	movl	$0x4, %eax
    e847:      	movq	%rbp, %rdi
    e84a:      	movl	$0x8, %esi
    e84f:      	movq	%rbx, %rdx
    e852:      	callq	*%rax
    e854:      	cmpq	%r12, (%rsp)
    e858:      	je	0xe92f <generic_kprobe_path+0x3f9f>
    e85e:      	movl	$0x4, %eax
    e863:      	leaq	0x8(%rsp), %rdi
    e868:      	movl	$0x8, %esi
    e86d:      	movq	%rbx, %rdx
    e870:      	callq	*%rax
    e872:      	addq	$0x20, %r12
    e876:      	movl	$0x4, %eax
    e87b:      	leaq	0x58(%rsp), %rdi
    e880:      	movl	$0x10, %ecx
    e885:      	movl	$0x10, %esi
    e88a:      	movq	%r12, %rdx
    e88d:      	callq	*%rax
    e88f:      	movq	0x28(%rsp), %rbx
    e894:      	movq	0x48(%rsp), %rax
    e899:      	movl	0x5c(%rsp), %r15d
    e89e:      	subq	%rbx, %rax
    e8a1:      	movl	0x50(%rsp), %r12d
    e8a6:      	movl	%r15d, %edx
    e8a9:      	subl	%r12d, %edx
    e8ac:      	movl	$0x0, %ecx
    e8b1:      	cmovbl	%ecx, %edx
    e8b4:      	addq	0x60(%rsp), %rdx
    e8b9:      	xorl	%esi, %esi
    e8bb:      	cmpl	%r15d, %r12d
    e8be:      	seta	%sil
    e8c2:      	movl	%r15d, %ecx
    e8c5:      	cmovbl	%r12d, %ecx
    e8c9:      	addl	%ecx, %esi
    e8cb:      	movl	%r12d, %edi
    e8ce:      	subl	%esi, %edi
    e8d0:      	movl	%edi, 0x50(%rsp)
    e8d4:      	subq	%rsi, %rax
    e8d7:      	jb	0x16402 <generic_kprobe_path+0xba72>
    e8dd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e8e3:      	ja	0x16402 <generic_kprobe_path+0xba72>
    e8e9:      	cmpl	%r15d, %r12d
    e8ec:      	jbe	0xe8f2 <generic_kprobe_path+0x3f62>
    e8ee:      	movb	$0x2f, (%rbx,%rax)
    e8f2:      	xorl	%edi, %edi
    e8f4:      	cmpl	%r15d, %r12d
    e8f7:      	seta	%dil
    e8fb:      	movzbl	%cl, %esi
    e8fe:      	addq	%rax, %rbx
    e901:      	addq	%rbx, %rdi
    e904:      	movl	$0x4, %eax
    e909:      	callq	*%rax
    e90b:      	movq	%rbx, 0x48(%rsp)
    e910:      	cmpl	%r15d, %r12d
    e913:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    e919:      	movq	0x8(%rsp), %r12
    e91e:      	movq	%r12, 0x30(%rsp)
    e923:      	movq	0x38(%rsp), %rdx
    e928:      	movq	0x40(%rsp), %r15
    e92d:      	jmp	0xe980 <generic_kprobe_path+0x3ff0>
    e92f:      	leaq	0x10(%r15), %rdx
    e933:      	movl	$0x4, %eax
    e938:      	movq	%rbp, %rdi
    e93b:      	movl	$0x8, %esi
    e940:      	callq	*%rax
    e942:      	movq	0x40(%rsp), %rax
    e947:      	cmpq	(%rsp), %rax
    e94b:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e951:      	addq	$0x18, %r15
    e955:      	movl	$0x4, %eax
    e95a:      	leaq	0x30(%rsp), %rdi
    e95f:      	movl	$0x8, %esi
    e964:      	movq	%r15, %rdx
    e967:      	callq	*%rax
    e969:      	movq	(%rsp), %r15
    e96d:      	movq	%r15, 0x40(%rsp)
    e972:      	leaq	0x20(%r15), %rdx
    e976:      	movq	%rdx, 0x38(%rsp)
    e97b:      	movq	0x30(%rsp), %r12
    e980:      	cmpq	0x18(%rsp), %r12
    e985:      	jne	0xe992 <generic_kprobe_path+0x4002>
    e987:      	cmpq	0x20(%rsp), %rdx
    e98c:      	je	0x163fd <generic_kprobe_path+0xba6d>
    e992:      	movl	$0x4, %eax
    e997:      	leaq	0x10(%rsp), %rdi
    e99c:      	movl	$0x8, %esi
    e9a1:      	callq	*%rax
    e9a3:      	cmpq	0x10(%rsp), %r12
    e9a8:      	je	0xeaa0 <generic_kprobe_path+0x4110>
    e9ae:      	leaq	0x18(%r12), %rbx
    e9b3:      	movl	$0x4, %eax
    e9b8:      	movq	%rbp, %rdi
    e9bb:      	movl	$0x8, %esi
    e9c0:      	movq	%rbx, %rdx
    e9c3:      	callq	*%rax
    e9c5:      	cmpq	%r12, (%rsp)
    e9c9:      	je	0xeaa0 <generic_kprobe_path+0x4110>
    e9cf:      	movl	$0x4, %eax
    e9d4:      	leaq	0x8(%rsp), %rdi
    e9d9:      	movl	$0x8, %esi
    e9de:      	movq	%rbx, %rdx
    e9e1:      	callq	*%rax
    e9e3:      	addq	$0x20, %r12
    e9e7:      	movl	$0x4, %eax
    e9ec:      	leaq	0x58(%rsp), %rdi
    e9f1:      	movl	$0x10, %ecx
    e9f6:      	movl	$0x10, %esi
    e9fb:      	movq	%r12, %rdx
    e9fe:      	callq	*%rax
    ea00:      	movq	0x28(%rsp), %rbx
    ea05:      	movq	0x48(%rsp), %rax
    ea0a:      	movl	0x5c(%rsp), %r15d
    ea0f:      	subq	%rbx, %rax
    ea12:      	movl	0x50(%rsp), %r12d
    ea17:      	movl	%r15d, %edx
    ea1a:      	subl	%r12d, %edx
    ea1d:      	movl	$0x0, %ecx
    ea22:      	cmovbl	%ecx, %edx
    ea25:      	addq	0x60(%rsp), %rdx
    ea2a:      	xorl	%esi, %esi
    ea2c:      	cmpl	%r15d, %r12d
    ea2f:      	seta	%sil
    ea33:      	movl	%r15d, %ecx
    ea36:      	cmovbl	%r12d, %ecx
    ea3a:      	addl	%ecx, %esi
    ea3c:      	movl	%r12d, %edi
    ea3f:      	subl	%esi, %edi
    ea41:      	movl	%edi, 0x50(%rsp)
    ea45:      	subq	%rsi, %rax
    ea48:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ea4e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ea54:      	ja	0x16402 <generic_kprobe_path+0xba72>
    ea5a:      	cmpl	%r15d, %r12d
    ea5d:      	jbe	0xea63 <generic_kprobe_path+0x40d3>
    ea5f:      	movb	$0x2f, (%rbx,%rax)
    ea63:      	xorl	%edi, %edi
    ea65:      	cmpl	%r15d, %r12d
    ea68:      	seta	%dil
    ea6c:      	movzbl	%cl, %esi
    ea6f:      	addq	%rax, %rbx
    ea72:      	addq	%rbx, %rdi
    ea75:      	movl	$0x4, %eax
    ea7a:      	callq	*%rax
    ea7c:      	movq	%rbx, 0x48(%rsp)
    ea81:      	cmpl	%r15d, %r12d
    ea84:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    ea8a:      	movq	0x8(%rsp), %r12
    ea8f:      	movq	%r12, 0x30(%rsp)
    ea94:      	movq	0x38(%rsp), %rdx
    ea99:      	movq	0x40(%rsp), %r15
    ea9e:      	jmp	0xeaf1 <generic_kprobe_path+0x4161>
    eaa0:      	leaq	0x10(%r15), %rdx
    eaa4:      	movl	$0x4, %eax
    eaa9:      	movq	%rbp, %rdi
    eaac:      	movl	$0x8, %esi
    eab1:      	callq	*%rax
    eab3:      	movq	0x40(%rsp), %rax
    eab8:      	cmpq	(%rsp), %rax
    eabc:      	je	0x163fd <generic_kprobe_path+0xba6d>
    eac2:      	addq	$0x18, %r15
    eac6:      	movl	$0x4, %eax
    eacb:      	leaq	0x30(%rsp), %rdi
    ead0:      	movl	$0x8, %esi
    ead5:      	movq	%r15, %rdx
    ead8:      	callq	*%rax
    eada:      	movq	(%rsp), %r15
    eade:      	movq	%r15, 0x40(%rsp)
    eae3:      	leaq	0x20(%r15), %rdx
    eae7:      	movq	%rdx, 0x38(%rsp)
    eaec:      	movq	0x30(%rsp), %r12
    eaf1:      	cmpq	0x18(%rsp), %r12
    eaf6:      	jne	0xeb03 <generic_kprobe_path+0x4173>
    eaf8:      	cmpq	0x20(%rsp), %rdx
    eafd:      	je	0x163fd <generic_kprobe_path+0xba6d>
    eb03:      	movl	$0x4, %eax
    eb08:      	leaq	0x10(%rsp), %rdi
    eb0d:      	movl	$0x8, %esi
    eb12:      	callq	*%rax
    eb14:      	cmpq	0x10(%rsp), %r12
    eb19:      	je	0xec11 <generic_kprobe_path+0x4281>
    eb1f:      	leaq	0x18(%r12), %rbx
    eb24:      	movl	$0x4, %eax
    eb29:      	movq	%rbp, %rdi
    eb2c:      	movl	$0x8, %esi
    eb31:      	movq	%rbx, %rdx
    eb34:      	callq	*%rax
    eb36:      	cmpq	%r12, (%rsp)
    eb3a:      	je	0xec11 <generic_kprobe_path+0x4281>
    eb40:      	movl	$0x4, %eax
    eb45:      	leaq	0x8(%rsp), %rdi
    eb4a:      	movl	$0x8, %esi
    eb4f:      	movq	%rbx, %rdx
    eb52:      	callq	*%rax
    eb54:      	addq	$0x20, %r12
    eb58:      	movl	$0x4, %eax
    eb5d:      	leaq	0x58(%rsp), %rdi
    eb62:      	movl	$0x10, %ecx
    eb67:      	movl	$0x10, %esi
    eb6c:      	movq	%r12, %rdx
    eb6f:      	callq	*%rax
    eb71:      	movq	0x28(%rsp), %rbx
    eb76:      	movq	0x48(%rsp), %rax
    eb7b:      	movl	0x5c(%rsp), %r15d
    eb80:      	subq	%rbx, %rax
    eb83:      	movl	0x50(%rsp), %r12d
    eb88:      	movl	%r15d, %edx
    eb8b:      	subl	%r12d, %edx
    eb8e:      	movl	$0x0, %ecx
    eb93:      	cmovbl	%ecx, %edx
    eb96:      	addq	0x60(%rsp), %rdx
    eb9b:      	xorl	%esi, %esi
    eb9d:      	cmpl	%r15d, %r12d
    eba0:      	seta	%sil
    eba4:      	movl	%r15d, %ecx
    eba7:      	cmovbl	%r12d, %ecx
    ebab:      	addl	%ecx, %esi
    ebad:      	movl	%r12d, %edi
    ebb0:      	subl	%esi, %edi
    ebb2:      	movl	%edi, 0x50(%rsp)
    ebb6:      	subq	%rsi, %rax
    ebb9:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ebbf:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ebc5:      	ja	0x16402 <generic_kprobe_path+0xba72>
    ebcb:      	cmpl	%r15d, %r12d
    ebce:      	jbe	0xebd4 <generic_kprobe_path+0x4244>
    ebd0:      	movb	$0x2f, (%rbx,%rax)
    ebd4:      	xorl	%edi, %edi
    ebd6:      	cmpl	%r15d, %r12d
    ebd9:      	seta	%dil
    ebdd:      	movzbl	%cl, %esi
    ebe0:      	addq	%rax, %rbx
    ebe3:      	addq	%rbx, %rdi
    ebe6:      	movl	$0x4, %eax
    ebeb:      	callq	*%rax
    ebed:      	movq	%rbx, 0x48(%rsp)
    ebf2:      	cmpl	%r15d, %r12d
    ebf5:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    ebfb:      	movq	0x8(%rsp), %r12
    ec00:      	movq	%r12, 0x30(%rsp)
    ec05:      	movq	0x38(%rsp), %rdx
    ec0a:      	movq	0x40(%rsp), %r15
    ec0f:      	jmp	0xec62 <generic_kprobe_path+0x42d2>
    ec11:      	leaq	0x10(%r15), %rdx
    ec15:      	movl	$0x4, %eax
    ec1a:      	movq	%rbp, %rdi
    ec1d:      	movl	$0x8, %esi
    ec22:      	callq	*%rax
    ec24:      	movq	0x40(%rsp), %rax
    ec29:      	cmpq	(%rsp), %rax
    ec2d:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ec33:      	addq	$0x18, %r15
    ec37:      	movl	$0x4, %eax
    ec3c:      	leaq	0x30(%rsp), %rdi
    ec41:      	movl	$0x8, %esi
    ec46:      	movq	%r15, %rdx
    ec49:      	callq	*%rax
    ec4b:      	movq	(%rsp), %r15
    ec4f:      	movq	%r15, 0x40(%rsp)
    ec54:      	leaq	0x20(%r15), %rdx
    ec58:      	movq	%rdx, 0x38(%rsp)
    ec5d:      	movq	0x30(%rsp), %r12
    ec62:      	cmpq	0x18(%rsp), %r12
    ec67:      	jne	0xec74 <generic_kprobe_path+0x42e4>
    ec69:      	cmpq	0x20(%rsp), %rdx
    ec6e:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ec74:      	movl	$0x4, %eax
    ec79:      	leaq	0x10(%rsp), %rdi
    ec7e:      	movl	$0x8, %esi
    ec83:      	callq	*%rax
    ec85:      	cmpq	0x10(%rsp), %r12
    ec8a:      	je	0xed82 <generic_kprobe_path+0x43f2>
    ec90:      	leaq	0x18(%r12), %rbx
    ec95:      	movl	$0x4, %eax
    ec9a:      	movq	%rbp, %rdi
    ec9d:      	movl	$0x8, %esi
    eca2:      	movq	%rbx, %rdx
    eca5:      	callq	*%rax
    eca7:      	cmpq	%r12, (%rsp)
    ecab:      	je	0xed82 <generic_kprobe_path+0x43f2>
    ecb1:      	movl	$0x4, %eax
    ecb6:      	leaq	0x8(%rsp), %rdi
    ecbb:      	movl	$0x8, %esi
    ecc0:      	movq	%rbx, %rdx
    ecc3:      	callq	*%rax
    ecc5:      	addq	$0x20, %r12
    ecc9:      	movl	$0x4, %eax
    ecce:      	leaq	0x58(%rsp), %rdi
    ecd3:      	movl	$0x10, %ecx
    ecd8:      	movl	$0x10, %esi
    ecdd:      	movq	%r12, %rdx
    ece0:      	callq	*%rax
    ece2:      	movq	0x28(%rsp), %rbx
    ece7:      	movq	0x48(%rsp), %rax
    ecec:      	movl	0x5c(%rsp), %r15d
    ecf1:      	subq	%rbx, %rax
    ecf4:      	movl	0x50(%rsp), %r12d
    ecf9:      	movl	%r15d, %edx
    ecfc:      	subl	%r12d, %edx
    ecff:      	movl	$0x0, %ecx
    ed04:      	cmovbl	%ecx, %edx
    ed07:      	addq	0x60(%rsp), %rdx
    ed0c:      	xorl	%esi, %esi
    ed0e:      	cmpl	%r15d, %r12d
    ed11:      	seta	%sil
    ed15:      	movl	%r15d, %ecx
    ed18:      	cmovbl	%r12d, %ecx
    ed1c:      	addl	%ecx, %esi
    ed1e:      	movl	%r12d, %edi
    ed21:      	subl	%esi, %edi
    ed23:      	movl	%edi, 0x50(%rsp)
    ed27:      	subq	%rsi, %rax
    ed2a:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ed30:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ed36:      	ja	0x16402 <generic_kprobe_path+0xba72>
    ed3c:      	cmpl	%r15d, %r12d
    ed3f:      	jbe	0xed45 <generic_kprobe_path+0x43b5>
    ed41:      	movb	$0x2f, (%rbx,%rax)
    ed45:      	xorl	%edi, %edi
    ed47:      	cmpl	%r15d, %r12d
    ed4a:      	seta	%dil
    ed4e:      	movzbl	%cl, %esi
    ed51:      	addq	%rax, %rbx
    ed54:      	addq	%rbx, %rdi
    ed57:      	movl	$0x4, %eax
    ed5c:      	callq	*%rax
    ed5e:      	movq	%rbx, 0x48(%rsp)
    ed63:      	cmpl	%r15d, %r12d
    ed66:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    ed6c:      	movq	0x8(%rsp), %r12
    ed71:      	movq	%r12, 0x30(%rsp)
    ed76:      	movq	0x38(%rsp), %rdx
    ed7b:      	movq	0x40(%rsp), %r15
    ed80:      	jmp	0xedd3 <generic_kprobe_path+0x4443>
    ed82:      	leaq	0x10(%r15), %rdx
    ed86:      	movl	$0x4, %eax
    ed8b:      	movq	%rbp, %rdi
    ed8e:      	movl	$0x8, %esi
    ed93:      	callq	*%rax
    ed95:      	movq	0x40(%rsp), %rax
    ed9a:      	cmpq	(%rsp), %rax
    ed9e:      	je	0x163fd <generic_kprobe_path+0xba6d>
    eda4:      	addq	$0x18, %r15
    eda8:      	movl	$0x4, %eax
    edad:      	leaq	0x30(%rsp), %rdi
    edb2:      	movl	$0x8, %esi
    edb7:      	movq	%r15, %rdx
    edba:      	callq	*%rax
    edbc:      	movq	(%rsp), %r15
    edc0:      	movq	%r15, 0x40(%rsp)
    edc5:      	leaq	0x20(%r15), %rdx
    edc9:      	movq	%rdx, 0x38(%rsp)
    edce:      	movq	0x30(%rsp), %r12
    edd3:      	cmpq	0x18(%rsp), %r12
    edd8:      	jne	0xede5 <generic_kprobe_path+0x4455>
    edda:      	cmpq	0x20(%rsp), %rdx
    eddf:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ede5:      	movl	$0x4, %eax
    edea:      	leaq	0x10(%rsp), %rdi
    edef:      	movl	$0x8, %esi
    edf4:      	callq	*%rax
    edf6:      	cmpq	0x10(%rsp), %r12
    edfb:      	je	0xeef3 <generic_kprobe_path+0x4563>
    ee01:      	leaq	0x18(%r12), %rbx
    ee06:      	movl	$0x4, %eax
    ee0b:      	movq	%rbp, %rdi
    ee0e:      	movl	$0x8, %esi
    ee13:      	movq	%rbx, %rdx
    ee16:      	callq	*%rax
    ee18:      	cmpq	%r12, (%rsp)
    ee1c:      	je	0xeef3 <generic_kprobe_path+0x4563>
    ee22:      	movl	$0x4, %eax
    ee27:      	leaq	0x8(%rsp), %rdi
    ee2c:      	movl	$0x8, %esi
    ee31:      	movq	%rbx, %rdx
    ee34:      	callq	*%rax
    ee36:      	addq	$0x20, %r12
    ee3a:      	movl	$0x4, %eax
    ee3f:      	leaq	0x58(%rsp), %rdi
    ee44:      	movl	$0x10, %ecx
    ee49:      	movl	$0x10, %esi
    ee4e:      	movq	%r12, %rdx
    ee51:      	callq	*%rax
    ee53:      	movq	0x28(%rsp), %rbx
    ee58:      	movq	0x48(%rsp), %rax
    ee5d:      	movl	0x5c(%rsp), %r15d
    ee62:      	subq	%rbx, %rax
    ee65:      	movl	0x50(%rsp), %r12d
    ee6a:      	movl	%r15d, %edx
    ee6d:      	subl	%r12d, %edx
    ee70:      	movl	$0x0, %ecx
    ee75:      	cmovbl	%ecx, %edx
    ee78:      	addq	0x60(%rsp), %rdx
    ee7d:      	xorl	%esi, %esi
    ee7f:      	cmpl	%r15d, %r12d
    ee82:      	seta	%sil
    ee86:      	movl	%r15d, %ecx
    ee89:      	cmovbl	%r12d, %ecx
    ee8d:      	addl	%ecx, %esi
    ee8f:      	movl	%r12d, %edi
    ee92:      	subl	%esi, %edi
    ee94:      	movl	%edi, 0x50(%rsp)
    ee98:      	subq	%rsi, %rax
    ee9b:      	jb	0x16402 <generic_kprobe_path+0xba72>
    eea1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eea7:      	ja	0x16402 <generic_kprobe_path+0xba72>
    eead:      	cmpl	%r15d, %r12d
    eeb0:      	jbe	0xeeb6 <generic_kprobe_path+0x4526>
    eeb2:      	movb	$0x2f, (%rbx,%rax)
    eeb6:      	xorl	%edi, %edi
    eeb8:      	cmpl	%r15d, %r12d
    eebb:      	seta	%dil
    eebf:      	movzbl	%cl, %esi
    eec2:      	addq	%rax, %rbx
    eec5:      	addq	%rbx, %rdi
    eec8:      	movl	$0x4, %eax
    eecd:      	callq	*%rax
    eecf:      	movq	%rbx, 0x48(%rsp)
    eed4:      	cmpl	%r15d, %r12d
    eed7:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    eedd:      	movq	0x8(%rsp), %r12
    eee2:      	movq	%r12, 0x30(%rsp)
    eee7:      	movq	0x38(%rsp), %rdx
    eeec:      	movq	0x40(%rsp), %r15
    eef1:      	jmp	0xef44 <generic_kprobe_path+0x45b4>
    eef3:      	leaq	0x10(%r15), %rdx
    eef7:      	movl	$0x4, %eax
    eefc:      	movq	%rbp, %rdi
    eeff:      	movl	$0x8, %esi
    ef04:      	callq	*%rax
    ef06:      	movq	0x40(%rsp), %rax
    ef0b:      	cmpq	(%rsp), %rax
    ef0f:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ef15:      	addq	$0x18, %r15
    ef19:      	movl	$0x4, %eax
    ef1e:      	leaq	0x30(%rsp), %rdi
    ef23:      	movl	$0x8, %esi
    ef28:      	movq	%r15, %rdx
    ef2b:      	callq	*%rax
    ef2d:      	movq	(%rsp), %r15
    ef31:      	movq	%r15, 0x40(%rsp)
    ef36:      	leaq	0x20(%r15), %rdx
    ef3a:      	movq	%rdx, 0x38(%rsp)
    ef3f:      	movq	0x30(%rsp), %r12
    ef44:      	cmpq	0x18(%rsp), %r12
    ef49:      	jne	0xef56 <generic_kprobe_path+0x45c6>
    ef4b:      	cmpq	0x20(%rsp), %rdx
    ef50:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ef56:      	movl	$0x4, %eax
    ef5b:      	leaq	0x10(%rsp), %rdi
    ef60:      	movl	$0x8, %esi
    ef65:      	callq	*%rax
    ef67:      	cmpq	0x10(%rsp), %r12
    ef6c:      	je	0xf064 <generic_kprobe_path+0x46d4>
    ef72:      	leaq	0x18(%r12), %rbx
    ef77:      	movl	$0x4, %eax
    ef7c:      	movq	%rbp, %rdi
    ef7f:      	movl	$0x8, %esi
    ef84:      	movq	%rbx, %rdx
    ef87:      	callq	*%rax
    ef89:      	cmpq	%r12, (%rsp)
    ef8d:      	je	0xf064 <generic_kprobe_path+0x46d4>
    ef93:      	movl	$0x4, %eax
    ef98:      	leaq	0x8(%rsp), %rdi
    ef9d:      	movl	$0x8, %esi
    efa2:      	movq	%rbx, %rdx
    efa5:      	callq	*%rax
    efa7:      	addq	$0x20, %r12
    efab:      	movl	$0x4, %eax
    efb0:      	leaq	0x58(%rsp), %rdi
    efb5:      	movl	$0x10, %ecx
    efba:      	movl	$0x10, %esi
    efbf:      	movq	%r12, %rdx
    efc2:      	callq	*%rax
    efc4:      	movq	0x28(%rsp), %rbx
    efc9:      	movq	0x48(%rsp), %rax
    efce:      	movl	0x5c(%rsp), %r15d
    efd3:      	subq	%rbx, %rax
    efd6:      	movl	0x50(%rsp), %r12d
    efdb:      	movl	%r15d, %edx
    efde:      	subl	%r12d, %edx
    efe1:      	movl	$0x0, %ecx
    efe6:      	cmovbl	%ecx, %edx
    efe9:      	addq	0x60(%rsp), %rdx
    efee:      	xorl	%esi, %esi
    eff0:      	cmpl	%r15d, %r12d
    eff3:      	seta	%sil
    eff7:      	movl	%r15d, %ecx
    effa:      	cmovbl	%r12d, %ecx
    effe:      	addl	%ecx, %esi
    f000:      	movl	%r12d, %edi
    f003:      	subl	%esi, %edi
    f005:      	movl	%edi, 0x50(%rsp)
    f009:      	subq	%rsi, %rax
    f00c:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f012:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f018:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f01e:      	cmpl	%r15d, %r12d
    f021:      	jbe	0xf027 <generic_kprobe_path+0x4697>
    f023:      	movb	$0x2f, (%rbx,%rax)
    f027:      	xorl	%edi, %edi
    f029:      	cmpl	%r15d, %r12d
    f02c:      	seta	%dil
    f030:      	movzbl	%cl, %esi
    f033:      	addq	%rax, %rbx
    f036:      	addq	%rbx, %rdi
    f039:      	movl	$0x4, %eax
    f03e:      	callq	*%rax
    f040:      	movq	%rbx, 0x48(%rsp)
    f045:      	cmpl	%r15d, %r12d
    f048:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f04e:      	movq	0x8(%rsp), %r12
    f053:      	movq	%r12, 0x30(%rsp)
    f058:      	movq	0x38(%rsp), %rdx
    f05d:      	movq	0x40(%rsp), %r15
    f062:      	jmp	0xf0b5 <generic_kprobe_path+0x4725>
    f064:      	leaq	0x10(%r15), %rdx
    f068:      	movl	$0x4, %eax
    f06d:      	movq	%rbp, %rdi
    f070:      	movl	$0x8, %esi
    f075:      	callq	*%rax
    f077:      	movq	0x40(%rsp), %rax
    f07c:      	cmpq	(%rsp), %rax
    f080:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f086:      	addq	$0x18, %r15
    f08a:      	movl	$0x4, %eax
    f08f:      	leaq	0x30(%rsp), %rdi
    f094:      	movl	$0x8, %esi
    f099:      	movq	%r15, %rdx
    f09c:      	callq	*%rax
    f09e:      	movq	(%rsp), %r15
    f0a2:      	movq	%r15, 0x40(%rsp)
    f0a7:      	leaq	0x20(%r15), %rdx
    f0ab:      	movq	%rdx, 0x38(%rsp)
    f0b0:      	movq	0x30(%rsp), %r12
    f0b5:      	cmpq	0x18(%rsp), %r12
    f0ba:      	jne	0xf0c7 <generic_kprobe_path+0x4737>
    f0bc:      	cmpq	0x20(%rsp), %rdx
    f0c1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f0c7:      	movl	$0x4, %eax
    f0cc:      	leaq	0x10(%rsp), %rdi
    f0d1:      	movl	$0x8, %esi
    f0d6:      	callq	*%rax
    f0d8:      	cmpq	0x10(%rsp), %r12
    f0dd:      	je	0xf1d5 <generic_kprobe_path+0x4845>
    f0e3:      	leaq	0x18(%r12), %rbx
    f0e8:      	movl	$0x4, %eax
    f0ed:      	movq	%rbp, %rdi
    f0f0:      	movl	$0x8, %esi
    f0f5:      	movq	%rbx, %rdx
    f0f8:      	callq	*%rax
    f0fa:      	cmpq	%r12, (%rsp)
    f0fe:      	je	0xf1d5 <generic_kprobe_path+0x4845>
    f104:      	movl	$0x4, %eax
    f109:      	leaq	0x8(%rsp), %rdi
    f10e:      	movl	$0x8, %esi
    f113:      	movq	%rbx, %rdx
    f116:      	callq	*%rax
    f118:      	addq	$0x20, %r12
    f11c:      	movl	$0x4, %eax
    f121:      	leaq	0x58(%rsp), %rdi
    f126:      	movl	$0x10, %ecx
    f12b:      	movl	$0x10, %esi
    f130:      	movq	%r12, %rdx
    f133:      	callq	*%rax
    f135:      	movq	0x28(%rsp), %rbx
    f13a:      	movq	0x48(%rsp), %rax
    f13f:      	movl	0x5c(%rsp), %r15d
    f144:      	subq	%rbx, %rax
    f147:      	movl	0x50(%rsp), %r12d
    f14c:      	movl	%r15d, %edx
    f14f:      	subl	%r12d, %edx
    f152:      	movl	$0x0, %ecx
    f157:      	cmovbl	%ecx, %edx
    f15a:      	addq	0x60(%rsp), %rdx
    f15f:      	xorl	%esi, %esi
    f161:      	cmpl	%r15d, %r12d
    f164:      	seta	%sil
    f168:      	movl	%r15d, %ecx
    f16b:      	cmovbl	%r12d, %ecx
    f16f:      	addl	%ecx, %esi
    f171:      	movl	%r12d, %edi
    f174:      	subl	%esi, %edi
    f176:      	movl	%edi, 0x50(%rsp)
    f17a:      	subq	%rsi, %rax
    f17d:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f183:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f189:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f18f:      	cmpl	%r15d, %r12d
    f192:      	jbe	0xf198 <generic_kprobe_path+0x4808>
    f194:      	movb	$0x2f, (%rbx,%rax)
    f198:      	xorl	%edi, %edi
    f19a:      	cmpl	%r15d, %r12d
    f19d:      	seta	%dil
    f1a1:      	movzbl	%cl, %esi
    f1a4:      	addq	%rax, %rbx
    f1a7:      	addq	%rbx, %rdi
    f1aa:      	movl	$0x4, %eax
    f1af:      	callq	*%rax
    f1b1:      	movq	%rbx, 0x48(%rsp)
    f1b6:      	cmpl	%r15d, %r12d
    f1b9:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f1bf:      	movq	0x8(%rsp), %r12
    f1c4:      	movq	%r12, 0x30(%rsp)
    f1c9:      	movq	0x38(%rsp), %rdx
    f1ce:      	movq	0x40(%rsp), %r15
    f1d3:      	jmp	0xf226 <generic_kprobe_path+0x4896>
    f1d5:      	leaq	0x10(%r15), %rdx
    f1d9:      	movl	$0x4, %eax
    f1de:      	movq	%rbp, %rdi
    f1e1:      	movl	$0x8, %esi
    f1e6:      	callq	*%rax
    f1e8:      	movq	0x40(%rsp), %rax
    f1ed:      	cmpq	(%rsp), %rax
    f1f1:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f1f7:      	addq	$0x18, %r15
    f1fb:      	movl	$0x4, %eax
    f200:      	leaq	0x30(%rsp), %rdi
    f205:      	movl	$0x8, %esi
    f20a:      	movq	%r15, %rdx
    f20d:      	callq	*%rax
    f20f:      	movq	(%rsp), %r15
    f213:      	movq	%r15, 0x40(%rsp)
    f218:      	leaq	0x20(%r15), %rdx
    f21c:      	movq	%rdx, 0x38(%rsp)
    f221:      	movq	0x30(%rsp), %r12
    f226:      	cmpq	0x18(%rsp), %r12
    f22b:      	jne	0xf238 <generic_kprobe_path+0x48a8>
    f22d:      	cmpq	0x20(%rsp), %rdx
    f232:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f238:      	movl	$0x4, %eax
    f23d:      	leaq	0x10(%rsp), %rdi
    f242:      	movl	$0x8, %esi
    f247:      	callq	*%rax
    f249:      	cmpq	0x10(%rsp), %r12
    f24e:      	je	0xf346 <generic_kprobe_path+0x49b6>
    f254:      	leaq	0x18(%r12), %rbx
    f259:      	movl	$0x4, %eax
    f25e:      	movq	%rbp, %rdi
    f261:      	movl	$0x8, %esi
    f266:      	movq	%rbx, %rdx
    f269:      	callq	*%rax
    f26b:      	cmpq	%r12, (%rsp)
    f26f:      	je	0xf346 <generic_kprobe_path+0x49b6>
    f275:      	movl	$0x4, %eax
    f27a:      	leaq	0x8(%rsp), %rdi
    f27f:      	movl	$0x8, %esi
    f284:      	movq	%rbx, %rdx
    f287:      	callq	*%rax
    f289:      	addq	$0x20, %r12
    f28d:      	movl	$0x4, %eax
    f292:      	leaq	0x58(%rsp), %rdi
    f297:      	movl	$0x10, %ecx
    f29c:      	movl	$0x10, %esi
    f2a1:      	movq	%r12, %rdx
    f2a4:      	callq	*%rax
    f2a6:      	movq	0x28(%rsp), %rbx
    f2ab:      	movq	0x48(%rsp), %rax
    f2b0:      	movl	0x5c(%rsp), %r15d
    f2b5:      	subq	%rbx, %rax
    f2b8:      	movl	0x50(%rsp), %r12d
    f2bd:      	movl	%r15d, %edx
    f2c0:      	subl	%r12d, %edx
    f2c3:      	movl	$0x0, %ecx
    f2c8:      	cmovbl	%ecx, %edx
    f2cb:      	addq	0x60(%rsp), %rdx
    f2d0:      	xorl	%esi, %esi
    f2d2:      	cmpl	%r15d, %r12d
    f2d5:      	seta	%sil
    f2d9:      	movl	%r15d, %ecx
    f2dc:      	cmovbl	%r12d, %ecx
    f2e0:      	addl	%ecx, %esi
    f2e2:      	movl	%r12d, %edi
    f2e5:      	subl	%esi, %edi
    f2e7:      	movl	%edi, 0x50(%rsp)
    f2eb:      	subq	%rsi, %rax
    f2ee:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f2f4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f2fa:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f300:      	cmpl	%r15d, %r12d
    f303:      	jbe	0xf309 <generic_kprobe_path+0x4979>
    f305:      	movb	$0x2f, (%rbx,%rax)
    f309:      	xorl	%edi, %edi
    f30b:      	cmpl	%r15d, %r12d
    f30e:      	seta	%dil
    f312:      	movzbl	%cl, %esi
    f315:      	addq	%rax, %rbx
    f318:      	addq	%rbx, %rdi
    f31b:      	movl	$0x4, %eax
    f320:      	callq	*%rax
    f322:      	movq	%rbx, 0x48(%rsp)
    f327:      	cmpl	%r15d, %r12d
    f32a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f330:      	movq	0x8(%rsp), %r12
    f335:      	movq	%r12, 0x30(%rsp)
    f33a:      	movq	0x38(%rsp), %rdx
    f33f:      	movq	0x40(%rsp), %r15
    f344:      	jmp	0xf397 <generic_kprobe_path+0x4a07>
    f346:      	leaq	0x10(%r15), %rdx
    f34a:      	movl	$0x4, %eax
    f34f:      	movq	%rbp, %rdi
    f352:      	movl	$0x8, %esi
    f357:      	callq	*%rax
    f359:      	movq	0x40(%rsp), %rax
    f35e:      	cmpq	(%rsp), %rax
    f362:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f368:      	addq	$0x18, %r15
    f36c:      	movl	$0x4, %eax
    f371:      	leaq	0x30(%rsp), %rdi
    f376:      	movl	$0x8, %esi
    f37b:      	movq	%r15, %rdx
    f37e:      	callq	*%rax
    f380:      	movq	(%rsp), %r15
    f384:      	movq	%r15, 0x40(%rsp)
    f389:      	leaq	0x20(%r15), %rdx
    f38d:      	movq	%rdx, 0x38(%rsp)
    f392:      	movq	0x30(%rsp), %r12
    f397:      	cmpq	0x18(%rsp), %r12
    f39c:      	jne	0xf3a9 <generic_kprobe_path+0x4a19>
    f39e:      	cmpq	0x20(%rsp), %rdx
    f3a3:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f3a9:      	movl	$0x4, %eax
    f3ae:      	leaq	0x10(%rsp), %rdi
    f3b3:      	movl	$0x8, %esi
    f3b8:      	callq	*%rax
    f3ba:      	cmpq	0x10(%rsp), %r12
    f3bf:      	je	0xf4b7 <generic_kprobe_path+0x4b27>
    f3c5:      	leaq	0x18(%r12), %rbx
    f3ca:      	movl	$0x4, %eax
    f3cf:      	movq	%rbp, %rdi
    f3d2:      	movl	$0x8, %esi
    f3d7:      	movq	%rbx, %rdx
    f3da:      	callq	*%rax
    f3dc:      	cmpq	%r12, (%rsp)
    f3e0:      	je	0xf4b7 <generic_kprobe_path+0x4b27>
    f3e6:      	movl	$0x4, %eax
    f3eb:      	leaq	0x8(%rsp), %rdi
    f3f0:      	movl	$0x8, %esi
    f3f5:      	movq	%rbx, %rdx
    f3f8:      	callq	*%rax
    f3fa:      	addq	$0x20, %r12
    f3fe:      	movl	$0x4, %eax
    f403:      	leaq	0x58(%rsp), %rdi
    f408:      	movl	$0x10, %ecx
    f40d:      	movl	$0x10, %esi
    f412:      	movq	%r12, %rdx
    f415:      	callq	*%rax
    f417:      	movq	0x28(%rsp), %rbx
    f41c:      	movq	0x48(%rsp), %rax
    f421:      	movl	0x5c(%rsp), %r15d
    f426:      	subq	%rbx, %rax
    f429:      	movl	0x50(%rsp), %r12d
    f42e:      	movl	%r15d, %edx
    f431:      	subl	%r12d, %edx
    f434:      	movl	$0x0, %ecx
    f439:      	cmovbl	%ecx, %edx
    f43c:      	addq	0x60(%rsp), %rdx
    f441:      	xorl	%esi, %esi
    f443:      	cmpl	%r15d, %r12d
    f446:      	seta	%sil
    f44a:      	movl	%r15d, %ecx
    f44d:      	cmovbl	%r12d, %ecx
    f451:      	addl	%ecx, %esi
    f453:      	movl	%r12d, %edi
    f456:      	subl	%esi, %edi
    f458:      	movl	%edi, 0x50(%rsp)
    f45c:      	subq	%rsi, %rax
    f45f:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f465:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f46b:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f471:      	cmpl	%r15d, %r12d
    f474:      	jbe	0xf47a <generic_kprobe_path+0x4aea>
    f476:      	movb	$0x2f, (%rbx,%rax)
    f47a:      	xorl	%edi, %edi
    f47c:      	cmpl	%r15d, %r12d
    f47f:      	seta	%dil
    f483:      	movzbl	%cl, %esi
    f486:      	addq	%rax, %rbx
    f489:      	addq	%rbx, %rdi
    f48c:      	movl	$0x4, %eax
    f491:      	callq	*%rax
    f493:      	movq	%rbx, 0x48(%rsp)
    f498:      	cmpl	%r15d, %r12d
    f49b:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f4a1:      	movq	0x8(%rsp), %r12
    f4a6:      	movq	%r12, 0x30(%rsp)
    f4ab:      	movq	0x38(%rsp), %rdx
    f4b0:      	movq	0x40(%rsp), %r15
    f4b5:      	jmp	0xf508 <generic_kprobe_path+0x4b78>
    f4b7:      	leaq	0x10(%r15), %rdx
    f4bb:      	movl	$0x4, %eax
    f4c0:      	movq	%rbp, %rdi
    f4c3:      	movl	$0x8, %esi
    f4c8:      	callq	*%rax
    f4ca:      	movq	0x40(%rsp), %rax
    f4cf:      	cmpq	(%rsp), %rax
    f4d3:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f4d9:      	addq	$0x18, %r15
    f4dd:      	movl	$0x4, %eax
    f4e2:      	leaq	0x30(%rsp), %rdi
    f4e7:      	movl	$0x8, %esi
    f4ec:      	movq	%r15, %rdx
    f4ef:      	callq	*%rax
    f4f1:      	movq	(%rsp), %r15
    f4f5:      	movq	%r15, 0x40(%rsp)
    f4fa:      	leaq	0x20(%r15), %rdx
    f4fe:      	movq	%rdx, 0x38(%rsp)
    f503:      	movq	0x30(%rsp), %r12
    f508:      	cmpq	0x18(%rsp), %r12
    f50d:      	jne	0xf51a <generic_kprobe_path+0x4b8a>
    f50f:      	cmpq	0x20(%rsp), %rdx
    f514:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f51a:      	movl	$0x4, %eax
    f51f:      	leaq	0x10(%rsp), %rdi
    f524:      	movl	$0x8, %esi
    f529:      	callq	*%rax
    f52b:      	cmpq	0x10(%rsp), %r12
    f530:      	je	0xf628 <generic_kprobe_path+0x4c98>
    f536:      	leaq	0x18(%r12), %rbx
    f53b:      	movl	$0x4, %eax
    f540:      	movq	%rbp, %rdi
    f543:      	movl	$0x8, %esi
    f548:      	movq	%rbx, %rdx
    f54b:      	callq	*%rax
    f54d:      	cmpq	%r12, (%rsp)
    f551:      	je	0xf628 <generic_kprobe_path+0x4c98>
    f557:      	movl	$0x4, %eax
    f55c:      	leaq	0x8(%rsp), %rdi
    f561:      	movl	$0x8, %esi
    f566:      	movq	%rbx, %rdx
    f569:      	callq	*%rax
    f56b:      	addq	$0x20, %r12
    f56f:      	movl	$0x4, %eax
    f574:      	leaq	0x58(%rsp), %rdi
    f579:      	movl	$0x10, %ecx
    f57e:      	movl	$0x10, %esi
    f583:      	movq	%r12, %rdx
    f586:      	callq	*%rax
    f588:      	movq	0x28(%rsp), %rbx
    f58d:      	movq	0x48(%rsp), %rax
    f592:      	movl	0x5c(%rsp), %r15d
    f597:      	subq	%rbx, %rax
    f59a:      	movl	0x50(%rsp), %r12d
    f59f:      	movl	%r15d, %edx
    f5a2:      	subl	%r12d, %edx
    f5a5:      	movl	$0x0, %ecx
    f5aa:      	cmovbl	%ecx, %edx
    f5ad:      	addq	0x60(%rsp), %rdx
    f5b2:      	xorl	%esi, %esi
    f5b4:      	cmpl	%r15d, %r12d
    f5b7:      	seta	%sil
    f5bb:      	movl	%r15d, %ecx
    f5be:      	cmovbl	%r12d, %ecx
    f5c2:      	addl	%ecx, %esi
    f5c4:      	movl	%r12d, %edi
    f5c7:      	subl	%esi, %edi
    f5c9:      	movl	%edi, 0x50(%rsp)
    f5cd:      	subq	%rsi, %rax
    f5d0:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f5d6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f5dc:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f5e2:      	cmpl	%r15d, %r12d
    f5e5:      	jbe	0xf5eb <generic_kprobe_path+0x4c5b>
    f5e7:      	movb	$0x2f, (%rbx,%rax)
    f5eb:      	xorl	%edi, %edi
    f5ed:      	cmpl	%r15d, %r12d
    f5f0:      	seta	%dil
    f5f4:      	movzbl	%cl, %esi
    f5f7:      	addq	%rax, %rbx
    f5fa:      	addq	%rbx, %rdi
    f5fd:      	movl	$0x4, %eax
    f602:      	callq	*%rax
    f604:      	movq	%rbx, 0x48(%rsp)
    f609:      	cmpl	%r15d, %r12d
    f60c:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f612:      	movq	0x8(%rsp), %r12
    f617:      	movq	%r12, 0x30(%rsp)
    f61c:      	movq	0x38(%rsp), %rdx
    f621:      	movq	0x40(%rsp), %r15
    f626:      	jmp	0xf679 <generic_kprobe_path+0x4ce9>
    f628:      	leaq	0x10(%r15), %rdx
    f62c:      	movl	$0x4, %eax
    f631:      	movq	%rbp, %rdi
    f634:      	movl	$0x8, %esi
    f639:      	callq	*%rax
    f63b:      	movq	0x40(%rsp), %rax
    f640:      	cmpq	(%rsp), %rax
    f644:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f64a:      	addq	$0x18, %r15
    f64e:      	movl	$0x4, %eax
    f653:      	leaq	0x30(%rsp), %rdi
    f658:      	movl	$0x8, %esi
    f65d:      	movq	%r15, %rdx
    f660:      	callq	*%rax
    f662:      	movq	(%rsp), %r15
    f666:      	movq	%r15, 0x40(%rsp)
    f66b:      	leaq	0x20(%r15), %rdx
    f66f:      	movq	%rdx, 0x38(%rsp)
    f674:      	movq	0x30(%rsp), %r12
    f679:      	cmpq	0x18(%rsp), %r12
    f67e:      	jne	0xf68b <generic_kprobe_path+0x4cfb>
    f680:      	cmpq	0x20(%rsp), %rdx
    f685:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f68b:      	movl	$0x4, %eax
    f690:      	leaq	0x10(%rsp), %rdi
    f695:      	movl	$0x8, %esi
    f69a:      	callq	*%rax
    f69c:      	cmpq	0x10(%rsp), %r12
    f6a1:      	je	0xf799 <generic_kprobe_path+0x4e09>
    f6a7:      	leaq	0x18(%r12), %rbx
    f6ac:      	movl	$0x4, %eax
    f6b1:      	movq	%rbp, %rdi
    f6b4:      	movl	$0x8, %esi
    f6b9:      	movq	%rbx, %rdx
    f6bc:      	callq	*%rax
    f6be:      	cmpq	%r12, (%rsp)
    f6c2:      	je	0xf799 <generic_kprobe_path+0x4e09>
    f6c8:      	movl	$0x4, %eax
    f6cd:      	leaq	0x8(%rsp), %rdi
    f6d2:      	movl	$0x8, %esi
    f6d7:      	movq	%rbx, %rdx
    f6da:      	callq	*%rax
    f6dc:      	addq	$0x20, %r12
    f6e0:      	movl	$0x4, %eax
    f6e5:      	leaq	0x58(%rsp), %rdi
    f6ea:      	movl	$0x10, %ecx
    f6ef:      	movl	$0x10, %esi
    f6f4:      	movq	%r12, %rdx
    f6f7:      	callq	*%rax
    f6f9:      	movq	0x28(%rsp), %rbx
    f6fe:      	movq	0x48(%rsp), %rax
    f703:      	movl	0x5c(%rsp), %r15d
    f708:      	subq	%rbx, %rax
    f70b:      	movl	0x50(%rsp), %r12d
    f710:      	movl	%r15d, %edx
    f713:      	subl	%r12d, %edx
    f716:      	movl	$0x0, %ecx
    f71b:      	cmovbl	%ecx, %edx
    f71e:      	addq	0x60(%rsp), %rdx
    f723:      	xorl	%esi, %esi
    f725:      	cmpl	%r15d, %r12d
    f728:      	seta	%sil
    f72c:      	movl	%r15d, %ecx
    f72f:      	cmovbl	%r12d, %ecx
    f733:      	addl	%ecx, %esi
    f735:      	movl	%r12d, %edi
    f738:      	subl	%esi, %edi
    f73a:      	movl	%edi, 0x50(%rsp)
    f73e:      	subq	%rsi, %rax
    f741:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f747:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f74d:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f753:      	cmpl	%r15d, %r12d
    f756:      	jbe	0xf75c <generic_kprobe_path+0x4dcc>
    f758:      	movb	$0x2f, (%rbx,%rax)
    f75c:      	xorl	%edi, %edi
    f75e:      	cmpl	%r15d, %r12d
    f761:      	seta	%dil
    f765:      	movzbl	%cl, %esi
    f768:      	addq	%rax, %rbx
    f76b:      	addq	%rbx, %rdi
    f76e:      	movl	$0x4, %eax
    f773:      	callq	*%rax
    f775:      	movq	%rbx, 0x48(%rsp)
    f77a:      	cmpl	%r15d, %r12d
    f77d:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f783:      	movq	0x8(%rsp), %r12
    f788:      	movq	%r12, 0x30(%rsp)
    f78d:      	movq	0x38(%rsp), %rdx
    f792:      	movq	0x40(%rsp), %r15
    f797:      	jmp	0xf7ea <generic_kprobe_path+0x4e5a>
    f799:      	leaq	0x10(%r15), %rdx
    f79d:      	movl	$0x4, %eax
    f7a2:      	movq	%rbp, %rdi
    f7a5:      	movl	$0x8, %esi
    f7aa:      	callq	*%rax
    f7ac:      	movq	0x40(%rsp), %rax
    f7b1:      	cmpq	(%rsp), %rax
    f7b5:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f7bb:      	addq	$0x18, %r15
    f7bf:      	movl	$0x4, %eax
    f7c4:      	leaq	0x30(%rsp), %rdi
    f7c9:      	movl	$0x8, %esi
    f7ce:      	movq	%r15, %rdx
    f7d1:      	callq	*%rax
    f7d3:      	movq	(%rsp), %r15
    f7d7:      	movq	%r15, 0x40(%rsp)
    f7dc:      	leaq	0x20(%r15), %rdx
    f7e0:      	movq	%rdx, 0x38(%rsp)
    f7e5:      	movq	0x30(%rsp), %r12
    f7ea:      	cmpq	0x18(%rsp), %r12
    f7ef:      	jne	0xf7fc <generic_kprobe_path+0x4e6c>
    f7f1:      	cmpq	0x20(%rsp), %rdx
    f7f6:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f7fc:      	movl	$0x4, %eax
    f801:      	leaq	0x10(%rsp), %rdi
    f806:      	movl	$0x8, %esi
    f80b:      	callq	*%rax
    f80d:      	cmpq	0x10(%rsp), %r12
    f812:      	je	0xf90a <generic_kprobe_path+0x4f7a>
    f818:      	leaq	0x18(%r12), %rbx
    f81d:      	movl	$0x4, %eax
    f822:      	movq	%rbp, %rdi
    f825:      	movl	$0x8, %esi
    f82a:      	movq	%rbx, %rdx
    f82d:      	callq	*%rax
    f82f:      	cmpq	%r12, (%rsp)
    f833:      	je	0xf90a <generic_kprobe_path+0x4f7a>
    f839:      	movl	$0x4, %eax
    f83e:      	leaq	0x8(%rsp), %rdi
    f843:      	movl	$0x8, %esi
    f848:      	movq	%rbx, %rdx
    f84b:      	callq	*%rax
    f84d:      	addq	$0x20, %r12
    f851:      	movl	$0x4, %eax
    f856:      	leaq	0x58(%rsp), %rdi
    f85b:      	movl	$0x10, %ecx
    f860:      	movl	$0x10, %esi
    f865:      	movq	%r12, %rdx
    f868:      	callq	*%rax
    f86a:      	movq	0x28(%rsp), %rbx
    f86f:      	movq	0x48(%rsp), %rax
    f874:      	movl	0x5c(%rsp), %r15d
    f879:      	subq	%rbx, %rax
    f87c:      	movl	0x50(%rsp), %r12d
    f881:      	movl	%r15d, %edx
    f884:      	subl	%r12d, %edx
    f887:      	movl	$0x0, %ecx
    f88c:      	cmovbl	%ecx, %edx
    f88f:      	addq	0x60(%rsp), %rdx
    f894:      	xorl	%esi, %esi
    f896:      	cmpl	%r15d, %r12d
    f899:      	seta	%sil
    f89d:      	movl	%r15d, %ecx
    f8a0:      	cmovbl	%r12d, %ecx
    f8a4:      	addl	%ecx, %esi
    f8a6:      	movl	%r12d, %edi
    f8a9:      	subl	%esi, %edi
    f8ab:      	movl	%edi, 0x50(%rsp)
    f8af:      	subq	%rsi, %rax
    f8b2:      	jb	0x16402 <generic_kprobe_path+0xba72>
    f8b8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f8be:      	ja	0x16402 <generic_kprobe_path+0xba72>
    f8c4:      	cmpl	%r15d, %r12d
    f8c7:      	jbe	0xf8cd <generic_kprobe_path+0x4f3d>
    f8c9:      	movb	$0x2f, (%rbx,%rax)
    f8cd:      	xorl	%edi, %edi
    f8cf:      	cmpl	%r15d, %r12d
    f8d2:      	seta	%dil
    f8d6:      	movzbl	%cl, %esi
    f8d9:      	addq	%rax, %rbx
    f8dc:      	addq	%rbx, %rdi
    f8df:      	movl	$0x4, %eax
    f8e4:      	callq	*%rax
    f8e6:      	movq	%rbx, 0x48(%rsp)
    f8eb:      	cmpl	%r15d, %r12d
    f8ee:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    f8f4:      	movq	0x8(%rsp), %r12
    f8f9:      	movq	%r12, 0x30(%rsp)
    f8fe:      	movq	0x38(%rsp), %rdx
    f903:      	movq	0x40(%rsp), %r15
    f908:      	jmp	0xf95b <generic_kprobe_path+0x4fcb>
    f90a:      	leaq	0x10(%r15), %rdx
    f90e:      	movl	$0x4, %eax
    f913:      	movq	%rbp, %rdi
    f916:      	movl	$0x8, %esi
    f91b:      	callq	*%rax
    f91d:      	movq	0x40(%rsp), %rax
    f922:      	cmpq	(%rsp), %rax
    f926:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f92c:      	addq	$0x18, %r15
    f930:      	movl	$0x4, %eax
    f935:      	leaq	0x30(%rsp), %rdi
    f93a:      	movl	$0x8, %esi
    f93f:      	movq	%r15, %rdx
    f942:      	callq	*%rax
    f944:      	movq	(%rsp), %r15
    f948:      	movq	%r15, 0x40(%rsp)
    f94d:      	leaq	0x20(%r15), %rdx
    f951:      	movq	%rdx, 0x38(%rsp)
    f956:      	movq	0x30(%rsp), %r12
    f95b:      	cmpq	0x18(%rsp), %r12
    f960:      	jne	0xf96d <generic_kprobe_path+0x4fdd>
    f962:      	cmpq	0x20(%rsp), %rdx
    f967:      	je	0x163fd <generic_kprobe_path+0xba6d>
    f96d:      	movl	$0x4, %eax
    f972:      	leaq	0x10(%rsp), %rdi
    f977:      	movl	$0x8, %esi
    f97c:      	callq	*%rax
    f97e:      	cmpq	0x10(%rsp), %r12
    f983:      	je	0xfa7b <generic_kprobe_path+0x50eb>
    f989:      	leaq	0x18(%r12), %rbx
    f98e:      	movl	$0x4, %eax
    f993:      	movq	%rbp, %rdi
    f996:      	movl	$0x8, %esi
    f99b:      	movq	%rbx, %rdx
    f99e:      	callq	*%rax
    f9a0:      	cmpq	%r12, (%rsp)
    f9a4:      	je	0xfa7b <generic_kprobe_path+0x50eb>
    f9aa:      	movl	$0x4, %eax
    f9af:      	leaq	0x8(%rsp), %rdi
    f9b4:      	movl	$0x8, %esi
    f9b9:      	movq	%rbx, %rdx
    f9bc:      	callq	*%rax
    f9be:      	addq	$0x20, %r12
    f9c2:      	movl	$0x4, %eax
    f9c7:      	leaq	0x58(%rsp), %rdi
    f9cc:      	movl	$0x10, %ecx
    f9d1:      	movl	$0x10, %esi
    f9d6:      	movq	%r12, %rdx
    f9d9:      	callq	*%rax
    f9db:      	movq	0x28(%rsp), %rbx
    f9e0:      	movq	0x48(%rsp), %rax
    f9e5:      	movl	0x5c(%rsp), %r15d
    f9ea:      	subq	%rbx, %rax
    f9ed:      	movl	0x50(%rsp), %r12d
    f9f2:      	movl	%r15d, %edx
    f9f5:      	subl	%r12d, %edx
    f9f8:      	movl	$0x0, %ecx
    f9fd:      	cmovbl	%ecx, %edx
    fa00:      	addq	0x60(%rsp), %rdx
    fa05:      	xorl	%esi, %esi
    fa07:      	cmpl	%r15d, %r12d
    fa0a:      	seta	%sil
    fa0e:      	movl	%r15d, %ecx
    fa11:      	cmovbl	%r12d, %ecx
    fa15:      	addl	%ecx, %esi
    fa17:      	movl	%r12d, %edi
    fa1a:      	subl	%esi, %edi
    fa1c:      	movl	%edi, 0x50(%rsp)
    fa20:      	subq	%rsi, %rax
    fa23:      	jb	0x16402 <generic_kprobe_path+0xba72>
    fa29:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fa2f:      	ja	0x16402 <generic_kprobe_path+0xba72>
    fa35:      	cmpl	%r15d, %r12d
    fa38:      	jbe	0xfa3e <generic_kprobe_path+0x50ae>
    fa3a:      	movb	$0x2f, (%rbx,%rax)
    fa3e:      	xorl	%edi, %edi
    fa40:      	cmpl	%r15d, %r12d
    fa43:      	seta	%dil
    fa47:      	movzbl	%cl, %esi
    fa4a:      	addq	%rax, %rbx
    fa4d:      	addq	%rbx, %rdi
    fa50:      	movl	$0x4, %eax
    fa55:      	callq	*%rax
    fa57:      	movq	%rbx, 0x48(%rsp)
    fa5c:      	cmpl	%r15d, %r12d
    fa5f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    fa65:      	movq	0x8(%rsp), %r12
    fa6a:      	movq	%r12, 0x30(%rsp)
    fa6f:      	movq	0x38(%rsp), %rdx
    fa74:      	movq	0x40(%rsp), %r15
    fa79:      	jmp	0xfacc <generic_kprobe_path+0x513c>
    fa7b:      	leaq	0x10(%r15), %rdx
    fa7f:      	movl	$0x4, %eax
    fa84:      	movq	%rbp, %rdi
    fa87:      	movl	$0x8, %esi
    fa8c:      	callq	*%rax
    fa8e:      	movq	0x40(%rsp), %rax
    fa93:      	cmpq	(%rsp), %rax
    fa97:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fa9d:      	addq	$0x18, %r15
    faa1:      	movl	$0x4, %eax
    faa6:      	leaq	0x30(%rsp), %rdi
    faab:      	movl	$0x8, %esi
    fab0:      	movq	%r15, %rdx
    fab3:      	callq	*%rax
    fab5:      	movq	(%rsp), %r15
    fab9:      	movq	%r15, 0x40(%rsp)
    fabe:      	leaq	0x20(%r15), %rdx
    fac2:      	movq	%rdx, 0x38(%rsp)
    fac7:      	movq	0x30(%rsp), %r12
    facc:      	cmpq	0x18(%rsp), %r12
    fad1:      	jne	0xfade <generic_kprobe_path+0x514e>
    fad3:      	cmpq	0x20(%rsp), %rdx
    fad8:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fade:      	movl	$0x4, %eax
    fae3:      	leaq	0x10(%rsp), %rdi
    fae8:      	movl	$0x8, %esi
    faed:      	callq	*%rax
    faef:      	cmpq	0x10(%rsp), %r12
    faf4:      	je	0xfbec <generic_kprobe_path+0x525c>
    fafa:      	leaq	0x18(%r12), %rbx
    faff:      	movl	$0x4, %eax
    fb04:      	movq	%rbp, %rdi
    fb07:      	movl	$0x8, %esi
    fb0c:      	movq	%rbx, %rdx
    fb0f:      	callq	*%rax
    fb11:      	cmpq	%r12, (%rsp)
    fb15:      	je	0xfbec <generic_kprobe_path+0x525c>
    fb1b:      	movl	$0x4, %eax
    fb20:      	leaq	0x8(%rsp), %rdi
    fb25:      	movl	$0x8, %esi
    fb2a:      	movq	%rbx, %rdx
    fb2d:      	callq	*%rax
    fb2f:      	addq	$0x20, %r12
    fb33:      	movl	$0x4, %eax
    fb38:      	leaq	0x58(%rsp), %rdi
    fb3d:      	movl	$0x10, %ecx
    fb42:      	movl	$0x10, %esi
    fb47:      	movq	%r12, %rdx
    fb4a:      	callq	*%rax
    fb4c:      	movq	0x28(%rsp), %rbx
    fb51:      	movq	0x48(%rsp), %rax
    fb56:      	movl	0x5c(%rsp), %r15d
    fb5b:      	subq	%rbx, %rax
    fb5e:      	movl	0x50(%rsp), %r12d
    fb63:      	movl	%r15d, %edx
    fb66:      	subl	%r12d, %edx
    fb69:      	movl	$0x0, %ecx
    fb6e:      	cmovbl	%ecx, %edx
    fb71:      	addq	0x60(%rsp), %rdx
    fb76:      	xorl	%esi, %esi
    fb78:      	cmpl	%r15d, %r12d
    fb7b:      	seta	%sil
    fb7f:      	movl	%r15d, %ecx
    fb82:      	cmovbl	%r12d, %ecx
    fb86:      	addl	%ecx, %esi
    fb88:      	movl	%r12d, %edi
    fb8b:      	subl	%esi, %edi
    fb8d:      	movl	%edi, 0x50(%rsp)
    fb91:      	subq	%rsi, %rax
    fb94:      	jb	0x16402 <generic_kprobe_path+0xba72>
    fb9a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fba0:      	ja	0x16402 <generic_kprobe_path+0xba72>
    fba6:      	cmpl	%r15d, %r12d
    fba9:      	jbe	0xfbaf <generic_kprobe_path+0x521f>
    fbab:      	movb	$0x2f, (%rbx,%rax)
    fbaf:      	xorl	%edi, %edi
    fbb1:      	cmpl	%r15d, %r12d
    fbb4:      	seta	%dil
    fbb8:      	movzbl	%cl, %esi
    fbbb:      	addq	%rax, %rbx
    fbbe:      	addq	%rbx, %rdi
    fbc1:      	movl	$0x4, %eax
    fbc6:      	callq	*%rax
    fbc8:      	movq	%rbx, 0x48(%rsp)
    fbcd:      	cmpl	%r15d, %r12d
    fbd0:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    fbd6:      	movq	0x8(%rsp), %r12
    fbdb:      	movq	%r12, 0x30(%rsp)
    fbe0:      	movq	0x38(%rsp), %rdx
    fbe5:      	movq	0x40(%rsp), %r15
    fbea:      	jmp	0xfc3d <generic_kprobe_path+0x52ad>
    fbec:      	leaq	0x10(%r15), %rdx
    fbf0:      	movl	$0x4, %eax
    fbf5:      	movq	%rbp, %rdi
    fbf8:      	movl	$0x8, %esi
    fbfd:      	callq	*%rax
    fbff:      	movq	0x40(%rsp), %rax
    fc04:      	cmpq	(%rsp), %rax
    fc08:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fc0e:      	addq	$0x18, %r15
    fc12:      	movl	$0x4, %eax
    fc17:      	leaq	0x30(%rsp), %rdi
    fc1c:      	movl	$0x8, %esi
    fc21:      	movq	%r15, %rdx
    fc24:      	callq	*%rax
    fc26:      	movq	(%rsp), %r15
    fc2a:      	movq	%r15, 0x40(%rsp)
    fc2f:      	leaq	0x20(%r15), %rdx
    fc33:      	movq	%rdx, 0x38(%rsp)
    fc38:      	movq	0x30(%rsp), %r12
    fc3d:      	cmpq	0x18(%rsp), %r12
    fc42:      	jne	0xfc4f <generic_kprobe_path+0x52bf>
    fc44:      	cmpq	0x20(%rsp), %rdx
    fc49:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fc4f:      	movl	$0x4, %eax
    fc54:      	leaq	0x10(%rsp), %rdi
    fc59:      	movl	$0x8, %esi
    fc5e:      	callq	*%rax
    fc60:      	cmpq	0x10(%rsp), %r12
    fc65:      	je	0xfd5d <generic_kprobe_path+0x53cd>
    fc6b:      	leaq	0x18(%r12), %rbx
    fc70:      	movl	$0x4, %eax
    fc75:      	movq	%rbp, %rdi
    fc78:      	movl	$0x8, %esi
    fc7d:      	movq	%rbx, %rdx
    fc80:      	callq	*%rax
    fc82:      	cmpq	%r12, (%rsp)
    fc86:      	je	0xfd5d <generic_kprobe_path+0x53cd>
    fc8c:      	movl	$0x4, %eax
    fc91:      	leaq	0x8(%rsp), %rdi
    fc96:      	movl	$0x8, %esi
    fc9b:      	movq	%rbx, %rdx
    fc9e:      	callq	*%rax
    fca0:      	addq	$0x20, %r12
    fca4:      	movl	$0x4, %eax
    fca9:      	leaq	0x58(%rsp), %rdi
    fcae:      	movl	$0x10, %ecx
    fcb3:      	movl	$0x10, %esi
    fcb8:      	movq	%r12, %rdx
    fcbb:      	callq	*%rax
    fcbd:      	movq	0x28(%rsp), %rbx
    fcc2:      	movq	0x48(%rsp), %rax
    fcc7:      	movl	0x5c(%rsp), %r15d
    fccc:      	subq	%rbx, %rax
    fccf:      	movl	0x50(%rsp), %r12d
    fcd4:      	movl	%r15d, %edx
    fcd7:      	subl	%r12d, %edx
    fcda:      	movl	$0x0, %ecx
    fcdf:      	cmovbl	%ecx, %edx
    fce2:      	addq	0x60(%rsp), %rdx
    fce7:      	xorl	%esi, %esi
    fce9:      	cmpl	%r15d, %r12d
    fcec:      	seta	%sil
    fcf0:      	movl	%r15d, %ecx
    fcf3:      	cmovbl	%r12d, %ecx
    fcf7:      	addl	%ecx, %esi
    fcf9:      	movl	%r12d, %edi
    fcfc:      	subl	%esi, %edi
    fcfe:      	movl	%edi, 0x50(%rsp)
    fd02:      	subq	%rsi, %rax
    fd05:      	jb	0x16402 <generic_kprobe_path+0xba72>
    fd0b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fd11:      	ja	0x16402 <generic_kprobe_path+0xba72>
    fd17:      	cmpl	%r15d, %r12d
    fd1a:      	jbe	0xfd20 <generic_kprobe_path+0x5390>
    fd1c:      	movb	$0x2f, (%rbx,%rax)
    fd20:      	xorl	%edi, %edi
    fd22:      	cmpl	%r15d, %r12d
    fd25:      	seta	%dil
    fd29:      	movzbl	%cl, %esi
    fd2c:      	addq	%rax, %rbx
    fd2f:      	addq	%rbx, %rdi
    fd32:      	movl	$0x4, %eax
    fd37:      	callq	*%rax
    fd39:      	movq	%rbx, 0x48(%rsp)
    fd3e:      	cmpl	%r15d, %r12d
    fd41:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    fd47:      	movq	0x8(%rsp), %r12
    fd4c:      	movq	%r12, 0x30(%rsp)
    fd51:      	movq	0x38(%rsp), %rdx
    fd56:      	movq	0x40(%rsp), %r15
    fd5b:      	jmp	0xfdae <generic_kprobe_path+0x541e>
    fd5d:      	leaq	0x10(%r15), %rdx
    fd61:      	movl	$0x4, %eax
    fd66:      	movq	%rbp, %rdi
    fd69:      	movl	$0x8, %esi
    fd6e:      	callq	*%rax
    fd70:      	movq	0x40(%rsp), %rax
    fd75:      	cmpq	(%rsp), %rax
    fd79:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fd7f:      	addq	$0x18, %r15
    fd83:      	movl	$0x4, %eax
    fd88:      	leaq	0x30(%rsp), %rdi
    fd8d:      	movl	$0x8, %esi
    fd92:      	movq	%r15, %rdx
    fd95:      	callq	*%rax
    fd97:      	movq	(%rsp), %r15
    fd9b:      	movq	%r15, 0x40(%rsp)
    fda0:      	leaq	0x20(%r15), %rdx
    fda4:      	movq	%rdx, 0x38(%rsp)
    fda9:      	movq	0x30(%rsp), %r12
    fdae:      	cmpq	0x18(%rsp), %r12
    fdb3:      	jne	0xfdc0 <generic_kprobe_path+0x5430>
    fdb5:      	cmpq	0x20(%rsp), %rdx
    fdba:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fdc0:      	movl	$0x4, %eax
    fdc5:      	leaq	0x10(%rsp), %rdi
    fdca:      	movl	$0x8, %esi
    fdcf:      	callq	*%rax
    fdd1:      	cmpq	0x10(%rsp), %r12
    fdd6:      	je	0xfece <generic_kprobe_path+0x553e>
    fddc:      	leaq	0x18(%r12), %rbx
    fde1:      	movl	$0x4, %eax
    fde6:      	movq	%rbp, %rdi
    fde9:      	movl	$0x8, %esi
    fdee:      	movq	%rbx, %rdx
    fdf1:      	callq	*%rax
    fdf3:      	cmpq	%r12, (%rsp)
    fdf7:      	je	0xfece <generic_kprobe_path+0x553e>
    fdfd:      	movl	$0x4, %eax
    fe02:      	leaq	0x8(%rsp), %rdi
    fe07:      	movl	$0x8, %esi
    fe0c:      	movq	%rbx, %rdx
    fe0f:      	callq	*%rax
    fe11:      	addq	$0x20, %r12
    fe15:      	movl	$0x4, %eax
    fe1a:      	leaq	0x58(%rsp), %rdi
    fe1f:      	movl	$0x10, %ecx
    fe24:      	movl	$0x10, %esi
    fe29:      	movq	%r12, %rdx
    fe2c:      	callq	*%rax
    fe2e:      	movq	0x28(%rsp), %rbx
    fe33:      	movq	0x48(%rsp), %rax
    fe38:      	movl	0x5c(%rsp), %r15d
    fe3d:      	subq	%rbx, %rax
    fe40:      	movl	0x50(%rsp), %r12d
    fe45:      	movl	%r15d, %edx
    fe48:      	subl	%r12d, %edx
    fe4b:      	movl	$0x0, %ecx
    fe50:      	cmovbl	%ecx, %edx
    fe53:      	addq	0x60(%rsp), %rdx
    fe58:      	xorl	%esi, %esi
    fe5a:      	cmpl	%r15d, %r12d
    fe5d:      	seta	%sil
    fe61:      	movl	%r15d, %ecx
    fe64:      	cmovbl	%r12d, %ecx
    fe68:      	addl	%ecx, %esi
    fe6a:      	movl	%r12d, %edi
    fe6d:      	subl	%esi, %edi
    fe6f:      	movl	%edi, 0x50(%rsp)
    fe73:      	subq	%rsi, %rax
    fe76:      	jb	0x16402 <generic_kprobe_path+0xba72>
    fe7c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fe82:      	ja	0x16402 <generic_kprobe_path+0xba72>
    fe88:      	cmpl	%r15d, %r12d
    fe8b:      	jbe	0xfe91 <generic_kprobe_path+0x5501>
    fe8d:      	movb	$0x2f, (%rbx,%rax)
    fe91:      	xorl	%edi, %edi
    fe93:      	cmpl	%r15d, %r12d
    fe96:      	seta	%dil
    fe9a:      	movzbl	%cl, %esi
    fe9d:      	addq	%rax, %rbx
    fea0:      	addq	%rbx, %rdi
    fea3:      	movl	$0x4, %eax
    fea8:      	callq	*%rax
    feaa:      	movq	%rbx, 0x48(%rsp)
    feaf:      	cmpl	%r15d, %r12d
    feb2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
    feb8:      	movq	0x8(%rsp), %r12
    febd:      	movq	%r12, 0x30(%rsp)
    fec2:      	movq	0x38(%rsp), %rdx
    fec7:      	movq	0x40(%rsp), %r15
    fecc:      	jmp	0xff1f <generic_kprobe_path+0x558f>
    fece:      	leaq	0x10(%r15), %rdx
    fed2:      	movl	$0x4, %eax
    fed7:      	movq	%rbp, %rdi
    feda:      	movl	$0x8, %esi
    fedf:      	callq	*%rax
    fee1:      	movq	0x40(%rsp), %rax
    fee6:      	cmpq	(%rsp), %rax
    feea:      	je	0x163fd <generic_kprobe_path+0xba6d>
    fef0:      	addq	$0x18, %r15
    fef4:      	movl	$0x4, %eax
    fef9:      	leaq	0x30(%rsp), %rdi
    fefe:      	movl	$0x8, %esi
    ff03:      	movq	%r15, %rdx
    ff06:      	callq	*%rax
    ff08:      	movq	(%rsp), %r15
    ff0c:      	movq	%r15, 0x40(%rsp)
    ff11:      	leaq	0x20(%r15), %rdx
    ff15:      	movq	%rdx, 0x38(%rsp)
    ff1a:      	movq	0x30(%rsp), %r12
    ff1f:      	cmpq	0x18(%rsp), %r12
    ff24:      	jne	0xff31 <generic_kprobe_path+0x55a1>
    ff26:      	cmpq	0x20(%rsp), %rdx
    ff2b:      	je	0x163fd <generic_kprobe_path+0xba6d>
    ff31:      	movl	$0x4, %eax
    ff36:      	leaq	0x10(%rsp), %rdi
    ff3b:      	movl	$0x8, %esi
    ff40:      	callq	*%rax
    ff42:      	cmpq	0x10(%rsp), %r12
    ff47:      	je	0x1003f <generic_kprobe_path+0x56af>
    ff4d:      	leaq	0x18(%r12), %rbx
    ff52:      	movl	$0x4, %eax
    ff57:      	movq	%rbp, %rdi
    ff5a:      	movl	$0x8, %esi
    ff5f:      	movq	%rbx, %rdx
    ff62:      	callq	*%rax
    ff64:      	cmpq	%r12, (%rsp)
    ff68:      	je	0x1003f <generic_kprobe_path+0x56af>
    ff6e:      	movl	$0x4, %eax
    ff73:      	leaq	0x8(%rsp), %rdi
    ff78:      	movl	$0x8, %esi
    ff7d:      	movq	%rbx, %rdx
    ff80:      	callq	*%rax
    ff82:      	addq	$0x20, %r12
    ff86:      	movl	$0x4, %eax
    ff8b:      	leaq	0x58(%rsp), %rdi
    ff90:      	movl	$0x10, %ecx
    ff95:      	movl	$0x10, %esi
    ff9a:      	movq	%r12, %rdx
    ff9d:      	callq	*%rax
    ff9f:      	movq	0x28(%rsp), %rbx
    ffa4:      	movq	0x48(%rsp), %rax
    ffa9:      	movl	0x5c(%rsp), %r15d
    ffae:      	subq	%rbx, %rax
    ffb1:      	movl	0x50(%rsp), %r12d
    ffb6:      	movl	%r15d, %edx
    ffb9:      	subl	%r12d, %edx
    ffbc:      	movl	$0x0, %ecx
    ffc1:      	cmovbl	%ecx, %edx
    ffc4:      	addq	0x60(%rsp), %rdx
    ffc9:      	xorl	%esi, %esi
    ffcb:      	cmpl	%r15d, %r12d
    ffce:      	seta	%sil
    ffd2:      	movl	%r15d, %ecx
    ffd5:      	cmovbl	%r12d, %ecx
    ffd9:      	addl	%ecx, %esi
    ffdb:      	movl	%r12d, %edi
    ffde:      	subl	%esi, %edi
    ffe0:      	movl	%edi, 0x50(%rsp)
    ffe4:      	subq	%rsi, %rax
    ffe7:      	jb	0x16402 <generic_kprobe_path+0xba72>
    ffed:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fff3:      	ja	0x16402 <generic_kprobe_path+0xba72>
    fff9:      	cmpl	%r15d, %r12d
    fffc:      	jbe	0x10002 <generic_kprobe_path+0x5672>
    fffe:      	movb	$0x2f, (%rbx,%rax)
   10002:      	xorl	%edi, %edi
   10004:      	cmpl	%r15d, %r12d
   10007:      	seta	%dil
   1000b:      	movzbl	%cl, %esi
   1000e:      	addq	%rax, %rbx
   10011:      	addq	%rbx, %rdi
   10014:      	movl	$0x4, %eax
   10019:      	callq	*%rax
   1001b:      	movq	%rbx, 0x48(%rsp)
   10020:      	cmpl	%r15d, %r12d
   10023:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   10029:      	movq	0x8(%rsp), %r12
   1002e:      	movq	%r12, 0x30(%rsp)
   10033:      	movq	0x38(%rsp), %rdx
   10038:      	movq	0x40(%rsp), %r15
   1003d:      	jmp	0x10090 <generic_kprobe_path+0x5700>
   1003f:      	leaq	0x10(%r15), %rdx
   10043:      	movl	$0x4, %eax
   10048:      	movq	%rbp, %rdi
   1004b:      	movl	$0x8, %esi
   10050:      	callq	*%rax
   10052:      	movq	0x40(%rsp), %rax
   10057:      	cmpq	(%rsp), %rax
   1005b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10061:      	addq	$0x18, %r15
   10065:      	movl	$0x4, %eax
   1006a:      	leaq	0x30(%rsp), %rdi
   1006f:      	movl	$0x8, %esi
   10074:      	movq	%r15, %rdx
   10077:      	callq	*%rax
   10079:      	movq	(%rsp), %r15
   1007d:      	movq	%r15, 0x40(%rsp)
   10082:      	leaq	0x20(%r15), %rdx
   10086:      	movq	%rdx, 0x38(%rsp)
   1008b:      	movq	0x30(%rsp), %r12
   10090:      	cmpq	0x18(%rsp), %r12
   10095:      	jne	0x100a2 <generic_kprobe_path+0x5712>
   10097:      	cmpq	0x20(%rsp), %rdx
   1009c:      	je	0x163fd <generic_kprobe_path+0xba6d>
   100a2:      	movl	$0x4, %eax
   100a7:      	leaq	0x10(%rsp), %rdi
   100ac:      	movl	$0x8, %esi
   100b1:      	callq	*%rax
   100b3:      	cmpq	0x10(%rsp), %r12
   100b8:      	je	0x101b0 <generic_kprobe_path+0x5820>
   100be:      	leaq	0x18(%r12), %rbx
   100c3:      	movl	$0x4, %eax
   100c8:      	movq	%rbp, %rdi
   100cb:      	movl	$0x8, %esi
   100d0:      	movq	%rbx, %rdx
   100d3:      	callq	*%rax
   100d5:      	cmpq	%r12, (%rsp)
   100d9:      	je	0x101b0 <generic_kprobe_path+0x5820>
   100df:      	movl	$0x4, %eax
   100e4:      	leaq	0x8(%rsp), %rdi
   100e9:      	movl	$0x8, %esi
   100ee:      	movq	%rbx, %rdx
   100f1:      	callq	*%rax
   100f3:      	addq	$0x20, %r12
   100f7:      	movl	$0x4, %eax
   100fc:      	leaq	0x58(%rsp), %rdi
   10101:      	movl	$0x10, %ecx
   10106:      	movl	$0x10, %esi
   1010b:      	movq	%r12, %rdx
   1010e:      	callq	*%rax
   10110:      	movq	0x28(%rsp), %rbx
   10115:      	movq	0x48(%rsp), %rax
   1011a:      	movl	0x5c(%rsp), %r15d
   1011f:      	subq	%rbx, %rax
   10122:      	movl	0x50(%rsp), %r12d
   10127:      	movl	%r15d, %edx
   1012a:      	subl	%r12d, %edx
   1012d:      	movl	$0x0, %ecx
   10132:      	cmovbl	%ecx, %edx
   10135:      	addq	0x60(%rsp), %rdx
   1013a:      	xorl	%esi, %esi
   1013c:      	cmpl	%r15d, %r12d
   1013f:      	seta	%sil
   10143:      	movl	%r15d, %ecx
   10146:      	cmovbl	%r12d, %ecx
   1014a:      	addl	%ecx, %esi
   1014c:      	movl	%r12d, %edi
   1014f:      	subl	%esi, %edi
   10151:      	movl	%edi, 0x50(%rsp)
   10155:      	subq	%rsi, %rax
   10158:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1015e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10164:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1016a:      	cmpl	%r15d, %r12d
   1016d:      	jbe	0x10173 <generic_kprobe_path+0x57e3>
   1016f:      	movb	$0x2f, (%rbx,%rax)
   10173:      	xorl	%edi, %edi
   10175:      	cmpl	%r15d, %r12d
   10178:      	seta	%dil
   1017c:      	movzbl	%cl, %esi
   1017f:      	addq	%rax, %rbx
   10182:      	addq	%rbx, %rdi
   10185:      	movl	$0x4, %eax
   1018a:      	callq	*%rax
   1018c:      	movq	%rbx, 0x48(%rsp)
   10191:      	cmpl	%r15d, %r12d
   10194:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1019a:      	movq	0x8(%rsp), %r12
   1019f:      	movq	%r12, 0x30(%rsp)
   101a4:      	movq	0x38(%rsp), %rdx
   101a9:      	movq	0x40(%rsp), %r15
   101ae:      	jmp	0x10201 <generic_kprobe_path+0x5871>
   101b0:      	leaq	0x10(%r15), %rdx
   101b4:      	movl	$0x4, %eax
   101b9:      	movq	%rbp, %rdi
   101bc:      	movl	$0x8, %esi
   101c1:      	callq	*%rax
   101c3:      	movq	0x40(%rsp), %rax
   101c8:      	cmpq	(%rsp), %rax
   101cc:      	je	0x163fd <generic_kprobe_path+0xba6d>
   101d2:      	addq	$0x18, %r15
   101d6:      	movl	$0x4, %eax
   101db:      	leaq	0x30(%rsp), %rdi
   101e0:      	movl	$0x8, %esi
   101e5:      	movq	%r15, %rdx
   101e8:      	callq	*%rax
   101ea:      	movq	(%rsp), %r15
   101ee:      	movq	%r15, 0x40(%rsp)
   101f3:      	leaq	0x20(%r15), %rdx
   101f7:      	movq	%rdx, 0x38(%rsp)
   101fc:      	movq	0x30(%rsp), %r12
   10201:      	cmpq	0x18(%rsp), %r12
   10206:      	jne	0x10213 <generic_kprobe_path+0x5883>
   10208:      	cmpq	0x20(%rsp), %rdx
   1020d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10213:      	movl	$0x4, %eax
   10218:      	leaq	0x10(%rsp), %rdi
   1021d:      	movl	$0x8, %esi
   10222:      	callq	*%rax
   10224:      	cmpq	0x10(%rsp), %r12
   10229:      	je	0x10321 <generic_kprobe_path+0x5991>
   1022f:      	leaq	0x18(%r12), %rbx
   10234:      	movl	$0x4, %eax
   10239:      	movq	%rbp, %rdi
   1023c:      	movl	$0x8, %esi
   10241:      	movq	%rbx, %rdx
   10244:      	callq	*%rax
   10246:      	cmpq	%r12, (%rsp)
   1024a:      	je	0x10321 <generic_kprobe_path+0x5991>
   10250:      	movl	$0x4, %eax
   10255:      	leaq	0x8(%rsp), %rdi
   1025a:      	movl	$0x8, %esi
   1025f:      	movq	%rbx, %rdx
   10262:      	callq	*%rax
   10264:      	addq	$0x20, %r12
   10268:      	movl	$0x4, %eax
   1026d:      	leaq	0x58(%rsp), %rdi
   10272:      	movl	$0x10, %ecx
   10277:      	movl	$0x10, %esi
   1027c:      	movq	%r12, %rdx
   1027f:      	callq	*%rax
   10281:      	movq	0x28(%rsp), %rbx
   10286:      	movq	0x48(%rsp), %rax
   1028b:      	movl	0x5c(%rsp), %r15d
   10290:      	subq	%rbx, %rax
   10293:      	movl	0x50(%rsp), %r12d
   10298:      	movl	%r15d, %edx
   1029b:      	subl	%r12d, %edx
   1029e:      	movl	$0x0, %ecx
   102a3:      	cmovbl	%ecx, %edx
   102a6:      	addq	0x60(%rsp), %rdx
   102ab:      	xorl	%esi, %esi
   102ad:      	cmpl	%r15d, %r12d
   102b0:      	seta	%sil
   102b4:      	movl	%r15d, %ecx
   102b7:      	cmovbl	%r12d, %ecx
   102bb:      	addl	%ecx, %esi
   102bd:      	movl	%r12d, %edi
   102c0:      	subl	%esi, %edi
   102c2:      	movl	%edi, 0x50(%rsp)
   102c6:      	subq	%rsi, %rax
   102c9:      	jb	0x16402 <generic_kprobe_path+0xba72>
   102cf:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   102d5:      	ja	0x16402 <generic_kprobe_path+0xba72>
   102db:      	cmpl	%r15d, %r12d
   102de:      	jbe	0x102e4 <generic_kprobe_path+0x5954>
   102e0:      	movb	$0x2f, (%rbx,%rax)
   102e4:      	xorl	%edi, %edi
   102e6:      	cmpl	%r15d, %r12d
   102e9:      	seta	%dil
   102ed:      	movzbl	%cl, %esi
   102f0:      	addq	%rax, %rbx
   102f3:      	addq	%rbx, %rdi
   102f6:      	movl	$0x4, %eax
   102fb:      	callq	*%rax
   102fd:      	movq	%rbx, 0x48(%rsp)
   10302:      	cmpl	%r15d, %r12d
   10305:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1030b:      	movq	0x8(%rsp), %r12
   10310:      	movq	%r12, 0x30(%rsp)
   10315:      	movq	0x38(%rsp), %rdx
   1031a:      	movq	0x40(%rsp), %r15
   1031f:      	jmp	0x10372 <generic_kprobe_path+0x59e2>
   10321:      	leaq	0x10(%r15), %rdx
   10325:      	movl	$0x4, %eax
   1032a:      	movq	%rbp, %rdi
   1032d:      	movl	$0x8, %esi
   10332:      	callq	*%rax
   10334:      	movq	0x40(%rsp), %rax
   10339:      	cmpq	(%rsp), %rax
   1033d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10343:      	addq	$0x18, %r15
   10347:      	movl	$0x4, %eax
   1034c:      	leaq	0x30(%rsp), %rdi
   10351:      	movl	$0x8, %esi
   10356:      	movq	%r15, %rdx
   10359:      	callq	*%rax
   1035b:      	movq	(%rsp), %r15
   1035f:      	movq	%r15, 0x40(%rsp)
   10364:      	leaq	0x20(%r15), %rdx
   10368:      	movq	%rdx, 0x38(%rsp)
   1036d:      	movq	0x30(%rsp), %r12
   10372:      	cmpq	0x18(%rsp), %r12
   10377:      	jne	0x10384 <generic_kprobe_path+0x59f4>
   10379:      	cmpq	0x20(%rsp), %rdx
   1037e:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10384:      	movl	$0x4, %eax
   10389:      	leaq	0x10(%rsp), %rdi
   1038e:      	movl	$0x8, %esi
   10393:      	callq	*%rax
   10395:      	cmpq	0x10(%rsp), %r12
   1039a:      	je	0x10492 <generic_kprobe_path+0x5b02>
   103a0:      	leaq	0x18(%r12), %rbx
   103a5:      	movl	$0x4, %eax
   103aa:      	movq	%rbp, %rdi
   103ad:      	movl	$0x8, %esi
   103b2:      	movq	%rbx, %rdx
   103b5:      	callq	*%rax
   103b7:      	cmpq	%r12, (%rsp)
   103bb:      	je	0x10492 <generic_kprobe_path+0x5b02>
   103c1:      	movl	$0x4, %eax
   103c6:      	leaq	0x8(%rsp), %rdi
   103cb:      	movl	$0x8, %esi
   103d0:      	movq	%rbx, %rdx
   103d3:      	callq	*%rax
   103d5:      	addq	$0x20, %r12
   103d9:      	movl	$0x4, %eax
   103de:      	leaq	0x58(%rsp), %rdi
   103e3:      	movl	$0x10, %ecx
   103e8:      	movl	$0x10, %esi
   103ed:      	movq	%r12, %rdx
   103f0:      	callq	*%rax
   103f2:      	movq	0x28(%rsp), %rbx
   103f7:      	movq	0x48(%rsp), %rax
   103fc:      	movl	0x5c(%rsp), %r15d
   10401:      	subq	%rbx, %rax
   10404:      	movl	0x50(%rsp), %r12d
   10409:      	movl	%r15d, %edx
   1040c:      	subl	%r12d, %edx
   1040f:      	movl	$0x0, %ecx
   10414:      	cmovbl	%ecx, %edx
   10417:      	addq	0x60(%rsp), %rdx
   1041c:      	xorl	%esi, %esi
   1041e:      	cmpl	%r15d, %r12d
   10421:      	seta	%sil
   10425:      	movl	%r15d, %ecx
   10428:      	cmovbl	%r12d, %ecx
   1042c:      	addl	%ecx, %esi
   1042e:      	movl	%r12d, %edi
   10431:      	subl	%esi, %edi
   10433:      	movl	%edi, 0x50(%rsp)
   10437:      	subq	%rsi, %rax
   1043a:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10440:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10446:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1044c:      	cmpl	%r15d, %r12d
   1044f:      	jbe	0x10455 <generic_kprobe_path+0x5ac5>
   10451:      	movb	$0x2f, (%rbx,%rax)
   10455:      	xorl	%edi, %edi
   10457:      	cmpl	%r15d, %r12d
   1045a:      	seta	%dil
   1045e:      	movzbl	%cl, %esi
   10461:      	addq	%rax, %rbx
   10464:      	addq	%rbx, %rdi
   10467:      	movl	$0x4, %eax
   1046c:      	callq	*%rax
   1046e:      	movq	%rbx, 0x48(%rsp)
   10473:      	cmpl	%r15d, %r12d
   10476:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1047c:      	movq	0x8(%rsp), %r12
   10481:      	movq	%r12, 0x30(%rsp)
   10486:      	movq	0x38(%rsp), %rdx
   1048b:      	movq	0x40(%rsp), %r15
   10490:      	jmp	0x104e3 <generic_kprobe_path+0x5b53>
   10492:      	leaq	0x10(%r15), %rdx
   10496:      	movl	$0x4, %eax
   1049b:      	movq	%rbp, %rdi
   1049e:      	movl	$0x8, %esi
   104a3:      	callq	*%rax
   104a5:      	movq	0x40(%rsp), %rax
   104aa:      	cmpq	(%rsp), %rax
   104ae:      	je	0x163fd <generic_kprobe_path+0xba6d>
   104b4:      	addq	$0x18, %r15
   104b8:      	movl	$0x4, %eax
   104bd:      	leaq	0x30(%rsp), %rdi
   104c2:      	movl	$0x8, %esi
   104c7:      	movq	%r15, %rdx
   104ca:      	callq	*%rax
   104cc:      	movq	(%rsp), %r15
   104d0:      	movq	%r15, 0x40(%rsp)
   104d5:      	leaq	0x20(%r15), %rdx
   104d9:      	movq	%rdx, 0x38(%rsp)
   104de:      	movq	0x30(%rsp), %r12
   104e3:      	cmpq	0x18(%rsp), %r12
   104e8:      	jne	0x104f5 <generic_kprobe_path+0x5b65>
   104ea:      	cmpq	0x20(%rsp), %rdx
   104ef:      	je	0x163fd <generic_kprobe_path+0xba6d>
   104f5:      	movl	$0x4, %eax
   104fa:      	leaq	0x10(%rsp), %rdi
   104ff:      	movl	$0x8, %esi
   10504:      	callq	*%rax
   10506:      	cmpq	0x10(%rsp), %r12
   1050b:      	je	0x10603 <generic_kprobe_path+0x5c73>
   10511:      	leaq	0x18(%r12), %rbx
   10516:      	movl	$0x4, %eax
   1051b:      	movq	%rbp, %rdi
   1051e:      	movl	$0x8, %esi
   10523:      	movq	%rbx, %rdx
   10526:      	callq	*%rax
   10528:      	cmpq	%r12, (%rsp)
   1052c:      	je	0x10603 <generic_kprobe_path+0x5c73>
   10532:      	movl	$0x4, %eax
   10537:      	leaq	0x8(%rsp), %rdi
   1053c:      	movl	$0x8, %esi
   10541:      	movq	%rbx, %rdx
   10544:      	callq	*%rax
   10546:      	addq	$0x20, %r12
   1054a:      	movl	$0x4, %eax
   1054f:      	leaq	0x58(%rsp), %rdi
   10554:      	movl	$0x10, %ecx
   10559:      	movl	$0x10, %esi
   1055e:      	movq	%r12, %rdx
   10561:      	callq	*%rax
   10563:      	movq	0x28(%rsp), %rbx
   10568:      	movq	0x48(%rsp), %rax
   1056d:      	movl	0x5c(%rsp), %r15d
   10572:      	subq	%rbx, %rax
   10575:      	movl	0x50(%rsp), %r12d
   1057a:      	movl	%r15d, %edx
   1057d:      	subl	%r12d, %edx
   10580:      	movl	$0x0, %ecx
   10585:      	cmovbl	%ecx, %edx
   10588:      	addq	0x60(%rsp), %rdx
   1058d:      	xorl	%esi, %esi
   1058f:      	cmpl	%r15d, %r12d
   10592:      	seta	%sil
   10596:      	movl	%r15d, %ecx
   10599:      	cmovbl	%r12d, %ecx
   1059d:      	addl	%ecx, %esi
   1059f:      	movl	%r12d, %edi
   105a2:      	subl	%esi, %edi
   105a4:      	movl	%edi, 0x50(%rsp)
   105a8:      	subq	%rsi, %rax
   105ab:      	jb	0x16402 <generic_kprobe_path+0xba72>
   105b1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   105b7:      	ja	0x16402 <generic_kprobe_path+0xba72>
   105bd:      	cmpl	%r15d, %r12d
   105c0:      	jbe	0x105c6 <generic_kprobe_path+0x5c36>
   105c2:      	movb	$0x2f, (%rbx,%rax)
   105c6:      	xorl	%edi, %edi
   105c8:      	cmpl	%r15d, %r12d
   105cb:      	seta	%dil
   105cf:      	movzbl	%cl, %esi
   105d2:      	addq	%rax, %rbx
   105d5:      	addq	%rbx, %rdi
   105d8:      	movl	$0x4, %eax
   105dd:      	callq	*%rax
   105df:      	movq	%rbx, 0x48(%rsp)
   105e4:      	cmpl	%r15d, %r12d
   105e7:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   105ed:      	movq	0x8(%rsp), %r12
   105f2:      	movq	%r12, 0x30(%rsp)
   105f7:      	movq	0x38(%rsp), %rdx
   105fc:      	movq	0x40(%rsp), %r15
   10601:      	jmp	0x10654 <generic_kprobe_path+0x5cc4>
   10603:      	leaq	0x10(%r15), %rdx
   10607:      	movl	$0x4, %eax
   1060c:      	movq	%rbp, %rdi
   1060f:      	movl	$0x8, %esi
   10614:      	callq	*%rax
   10616:      	movq	0x40(%rsp), %rax
   1061b:      	cmpq	(%rsp), %rax
   1061f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10625:      	addq	$0x18, %r15
   10629:      	movl	$0x4, %eax
   1062e:      	leaq	0x30(%rsp), %rdi
   10633:      	movl	$0x8, %esi
   10638:      	movq	%r15, %rdx
   1063b:      	callq	*%rax
   1063d:      	movq	(%rsp), %r15
   10641:      	movq	%r15, 0x40(%rsp)
   10646:      	leaq	0x20(%r15), %rdx
   1064a:      	movq	%rdx, 0x38(%rsp)
   1064f:      	movq	0x30(%rsp), %r12
   10654:      	cmpq	0x18(%rsp), %r12
   10659:      	jne	0x10666 <generic_kprobe_path+0x5cd6>
   1065b:      	cmpq	0x20(%rsp), %rdx
   10660:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10666:      	movl	$0x4, %eax
   1066b:      	leaq	0x10(%rsp), %rdi
   10670:      	movl	$0x8, %esi
   10675:      	callq	*%rax
   10677:      	cmpq	0x10(%rsp), %r12
   1067c:      	je	0x10774 <generic_kprobe_path+0x5de4>
   10682:      	leaq	0x18(%r12), %rbx
   10687:      	movl	$0x4, %eax
   1068c:      	movq	%rbp, %rdi
   1068f:      	movl	$0x8, %esi
   10694:      	movq	%rbx, %rdx
   10697:      	callq	*%rax
   10699:      	cmpq	%r12, (%rsp)
   1069d:      	je	0x10774 <generic_kprobe_path+0x5de4>
   106a3:      	movl	$0x4, %eax
   106a8:      	leaq	0x8(%rsp), %rdi
   106ad:      	movl	$0x8, %esi
   106b2:      	movq	%rbx, %rdx
   106b5:      	callq	*%rax
   106b7:      	addq	$0x20, %r12
   106bb:      	movl	$0x4, %eax
   106c0:      	leaq	0x58(%rsp), %rdi
   106c5:      	movl	$0x10, %ecx
   106ca:      	movl	$0x10, %esi
   106cf:      	movq	%r12, %rdx
   106d2:      	callq	*%rax
   106d4:      	movq	0x28(%rsp), %rbx
   106d9:      	movq	0x48(%rsp), %rax
   106de:      	movl	0x5c(%rsp), %r15d
   106e3:      	subq	%rbx, %rax
   106e6:      	movl	0x50(%rsp), %r12d
   106eb:      	movl	%r15d, %edx
   106ee:      	subl	%r12d, %edx
   106f1:      	movl	$0x0, %ecx
   106f6:      	cmovbl	%ecx, %edx
   106f9:      	addq	0x60(%rsp), %rdx
   106fe:      	xorl	%esi, %esi
   10700:      	cmpl	%r15d, %r12d
   10703:      	seta	%sil
   10707:      	movl	%r15d, %ecx
   1070a:      	cmovbl	%r12d, %ecx
   1070e:      	addl	%ecx, %esi
   10710:      	movl	%r12d, %edi
   10713:      	subl	%esi, %edi
   10715:      	movl	%edi, 0x50(%rsp)
   10719:      	subq	%rsi, %rax
   1071c:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10722:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10728:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1072e:      	cmpl	%r15d, %r12d
   10731:      	jbe	0x10737 <generic_kprobe_path+0x5da7>
   10733:      	movb	$0x2f, (%rbx,%rax)
   10737:      	xorl	%edi, %edi
   10739:      	cmpl	%r15d, %r12d
   1073c:      	seta	%dil
   10740:      	movzbl	%cl, %esi
   10743:      	addq	%rax, %rbx
   10746:      	addq	%rbx, %rdi
   10749:      	movl	$0x4, %eax
   1074e:      	callq	*%rax
   10750:      	movq	%rbx, 0x48(%rsp)
   10755:      	cmpl	%r15d, %r12d
   10758:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1075e:      	movq	0x8(%rsp), %r12
   10763:      	movq	%r12, 0x30(%rsp)
   10768:      	movq	0x38(%rsp), %rdx
   1076d:      	movq	0x40(%rsp), %r15
   10772:      	jmp	0x107c5 <generic_kprobe_path+0x5e35>
   10774:      	leaq	0x10(%r15), %rdx
   10778:      	movl	$0x4, %eax
   1077d:      	movq	%rbp, %rdi
   10780:      	movl	$0x8, %esi
   10785:      	callq	*%rax
   10787:      	movq	0x40(%rsp), %rax
   1078c:      	cmpq	(%rsp), %rax
   10790:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10796:      	addq	$0x18, %r15
   1079a:      	movl	$0x4, %eax
   1079f:      	leaq	0x30(%rsp), %rdi
   107a4:      	movl	$0x8, %esi
   107a9:      	movq	%r15, %rdx
   107ac:      	callq	*%rax
   107ae:      	movq	(%rsp), %r15
   107b2:      	movq	%r15, 0x40(%rsp)
   107b7:      	leaq	0x20(%r15), %rdx
   107bb:      	movq	%rdx, 0x38(%rsp)
   107c0:      	movq	0x30(%rsp), %r12
   107c5:      	cmpq	0x18(%rsp), %r12
   107ca:      	jne	0x107d7 <generic_kprobe_path+0x5e47>
   107cc:      	cmpq	0x20(%rsp), %rdx
   107d1:      	je	0x163fd <generic_kprobe_path+0xba6d>
   107d7:      	movl	$0x4, %eax
   107dc:      	leaq	0x10(%rsp), %rdi
   107e1:      	movl	$0x8, %esi
   107e6:      	callq	*%rax
   107e8:      	cmpq	0x10(%rsp), %r12
   107ed:      	je	0x108e5 <generic_kprobe_path+0x5f55>
   107f3:      	leaq	0x18(%r12), %rbx
   107f8:      	movl	$0x4, %eax
   107fd:      	movq	%rbp, %rdi
   10800:      	movl	$0x8, %esi
   10805:      	movq	%rbx, %rdx
   10808:      	callq	*%rax
   1080a:      	cmpq	%r12, (%rsp)
   1080e:      	je	0x108e5 <generic_kprobe_path+0x5f55>
   10814:      	movl	$0x4, %eax
   10819:      	leaq	0x8(%rsp), %rdi
   1081e:      	movl	$0x8, %esi
   10823:      	movq	%rbx, %rdx
   10826:      	callq	*%rax
   10828:      	addq	$0x20, %r12
   1082c:      	movl	$0x4, %eax
   10831:      	leaq	0x58(%rsp), %rdi
   10836:      	movl	$0x10, %ecx
   1083b:      	movl	$0x10, %esi
   10840:      	movq	%r12, %rdx
   10843:      	callq	*%rax
   10845:      	movq	0x28(%rsp), %rbx
   1084a:      	movq	0x48(%rsp), %rax
   1084f:      	movl	0x5c(%rsp), %r15d
   10854:      	subq	%rbx, %rax
   10857:      	movl	0x50(%rsp), %r12d
   1085c:      	movl	%r15d, %edx
   1085f:      	subl	%r12d, %edx
   10862:      	movl	$0x0, %ecx
   10867:      	cmovbl	%ecx, %edx
   1086a:      	addq	0x60(%rsp), %rdx
   1086f:      	xorl	%esi, %esi
   10871:      	cmpl	%r15d, %r12d
   10874:      	seta	%sil
   10878:      	movl	%r15d, %ecx
   1087b:      	cmovbl	%r12d, %ecx
   1087f:      	addl	%ecx, %esi
   10881:      	movl	%r12d, %edi
   10884:      	subl	%esi, %edi
   10886:      	movl	%edi, 0x50(%rsp)
   1088a:      	subq	%rsi, %rax
   1088d:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10893:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10899:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1089f:      	cmpl	%r15d, %r12d
   108a2:      	jbe	0x108a8 <generic_kprobe_path+0x5f18>
   108a4:      	movb	$0x2f, (%rbx,%rax)
   108a8:      	xorl	%edi, %edi
   108aa:      	cmpl	%r15d, %r12d
   108ad:      	seta	%dil
   108b1:      	movzbl	%cl, %esi
   108b4:      	addq	%rax, %rbx
   108b7:      	addq	%rbx, %rdi
   108ba:      	movl	$0x4, %eax
   108bf:      	callq	*%rax
   108c1:      	movq	%rbx, 0x48(%rsp)
   108c6:      	cmpl	%r15d, %r12d
   108c9:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   108cf:      	movq	0x8(%rsp), %r12
   108d4:      	movq	%r12, 0x30(%rsp)
   108d9:      	movq	0x38(%rsp), %rdx
   108de:      	movq	0x40(%rsp), %r15
   108e3:      	jmp	0x10936 <generic_kprobe_path+0x5fa6>
   108e5:      	leaq	0x10(%r15), %rdx
   108e9:      	movl	$0x4, %eax
   108ee:      	movq	%rbp, %rdi
   108f1:      	movl	$0x8, %esi
   108f6:      	callq	*%rax
   108f8:      	movq	0x40(%rsp), %rax
   108fd:      	cmpq	(%rsp), %rax
   10901:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10907:      	addq	$0x18, %r15
   1090b:      	movl	$0x4, %eax
   10910:      	leaq	0x30(%rsp), %rdi
   10915:      	movl	$0x8, %esi
   1091a:      	movq	%r15, %rdx
   1091d:      	callq	*%rax
   1091f:      	movq	(%rsp), %r15
   10923:      	movq	%r15, 0x40(%rsp)
   10928:      	leaq	0x20(%r15), %rdx
   1092c:      	movq	%rdx, 0x38(%rsp)
   10931:      	movq	0x30(%rsp), %r12
   10936:      	cmpq	0x18(%rsp), %r12
   1093b:      	jne	0x10948 <generic_kprobe_path+0x5fb8>
   1093d:      	cmpq	0x20(%rsp), %rdx
   10942:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10948:      	movl	$0x4, %eax
   1094d:      	leaq	0x10(%rsp), %rdi
   10952:      	movl	$0x8, %esi
   10957:      	callq	*%rax
   10959:      	cmpq	0x10(%rsp), %r12
   1095e:      	je	0x10a56 <generic_kprobe_path+0x60c6>
   10964:      	leaq	0x18(%r12), %rbx
   10969:      	movl	$0x4, %eax
   1096e:      	movq	%rbp, %rdi
   10971:      	movl	$0x8, %esi
   10976:      	movq	%rbx, %rdx
   10979:      	callq	*%rax
   1097b:      	cmpq	%r12, (%rsp)
   1097f:      	je	0x10a56 <generic_kprobe_path+0x60c6>
   10985:      	movl	$0x4, %eax
   1098a:      	leaq	0x8(%rsp), %rdi
   1098f:      	movl	$0x8, %esi
   10994:      	movq	%rbx, %rdx
   10997:      	callq	*%rax
   10999:      	addq	$0x20, %r12
   1099d:      	movl	$0x4, %eax
   109a2:      	leaq	0x58(%rsp), %rdi
   109a7:      	movl	$0x10, %ecx
   109ac:      	movl	$0x10, %esi
   109b1:      	movq	%r12, %rdx
   109b4:      	callq	*%rax
   109b6:      	movq	0x28(%rsp), %rbx
   109bb:      	movq	0x48(%rsp), %rax
   109c0:      	movl	0x5c(%rsp), %r15d
   109c5:      	subq	%rbx, %rax
   109c8:      	movl	0x50(%rsp), %r12d
   109cd:      	movl	%r15d, %edx
   109d0:      	subl	%r12d, %edx
   109d3:      	movl	$0x0, %ecx
   109d8:      	cmovbl	%ecx, %edx
   109db:      	addq	0x60(%rsp), %rdx
   109e0:      	xorl	%esi, %esi
   109e2:      	cmpl	%r15d, %r12d
   109e5:      	seta	%sil
   109e9:      	movl	%r15d, %ecx
   109ec:      	cmovbl	%r12d, %ecx
   109f0:      	addl	%ecx, %esi
   109f2:      	movl	%r12d, %edi
   109f5:      	subl	%esi, %edi
   109f7:      	movl	%edi, 0x50(%rsp)
   109fb:      	subq	%rsi, %rax
   109fe:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10a04:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10a0a:      	ja	0x16402 <generic_kprobe_path+0xba72>
   10a10:      	cmpl	%r15d, %r12d
   10a13:      	jbe	0x10a19 <generic_kprobe_path+0x6089>
   10a15:      	movb	$0x2f, (%rbx,%rax)
   10a19:      	xorl	%edi, %edi
   10a1b:      	cmpl	%r15d, %r12d
   10a1e:      	seta	%dil
   10a22:      	movzbl	%cl, %esi
   10a25:      	addq	%rax, %rbx
   10a28:      	addq	%rbx, %rdi
   10a2b:      	movl	$0x4, %eax
   10a30:      	callq	*%rax
   10a32:      	movq	%rbx, 0x48(%rsp)
   10a37:      	cmpl	%r15d, %r12d
   10a3a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   10a40:      	movq	0x8(%rsp), %r12
   10a45:      	movq	%r12, 0x30(%rsp)
   10a4a:      	movq	0x38(%rsp), %rdx
   10a4f:      	movq	0x40(%rsp), %r15
   10a54:      	jmp	0x10aa7 <generic_kprobe_path+0x6117>
   10a56:      	leaq	0x10(%r15), %rdx
   10a5a:      	movl	$0x4, %eax
   10a5f:      	movq	%rbp, %rdi
   10a62:      	movl	$0x8, %esi
   10a67:      	callq	*%rax
   10a69:      	movq	0x40(%rsp), %rax
   10a6e:      	cmpq	(%rsp), %rax
   10a72:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10a78:      	addq	$0x18, %r15
   10a7c:      	movl	$0x4, %eax
   10a81:      	leaq	0x30(%rsp), %rdi
   10a86:      	movl	$0x8, %esi
   10a8b:      	movq	%r15, %rdx
   10a8e:      	callq	*%rax
   10a90:      	movq	(%rsp), %r15
   10a94:      	movq	%r15, 0x40(%rsp)
   10a99:      	leaq	0x20(%r15), %rdx
   10a9d:      	movq	%rdx, 0x38(%rsp)
   10aa2:      	movq	0x30(%rsp), %r12
   10aa7:      	cmpq	0x18(%rsp), %r12
   10aac:      	jne	0x10ab9 <generic_kprobe_path+0x6129>
   10aae:      	cmpq	0x20(%rsp), %rdx
   10ab3:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10ab9:      	movl	$0x4, %eax
   10abe:      	leaq	0x10(%rsp), %rdi
   10ac3:      	movl	$0x8, %esi
   10ac8:      	callq	*%rax
   10aca:      	cmpq	0x10(%rsp), %r12
   10acf:      	je	0x10bc7 <generic_kprobe_path+0x6237>
   10ad5:      	leaq	0x18(%r12), %rbx
   10ada:      	movl	$0x4, %eax
   10adf:      	movq	%rbp, %rdi
   10ae2:      	movl	$0x8, %esi
   10ae7:      	movq	%rbx, %rdx
   10aea:      	callq	*%rax
   10aec:      	cmpq	%r12, (%rsp)
   10af0:      	je	0x10bc7 <generic_kprobe_path+0x6237>
   10af6:      	movl	$0x4, %eax
   10afb:      	leaq	0x8(%rsp), %rdi
   10b00:      	movl	$0x8, %esi
   10b05:      	movq	%rbx, %rdx
   10b08:      	callq	*%rax
   10b0a:      	addq	$0x20, %r12
   10b0e:      	movl	$0x4, %eax
   10b13:      	leaq	0x58(%rsp), %rdi
   10b18:      	movl	$0x10, %ecx
   10b1d:      	movl	$0x10, %esi
   10b22:      	movq	%r12, %rdx
   10b25:      	callq	*%rax
   10b27:      	movq	0x28(%rsp), %rbx
   10b2c:      	movq	0x48(%rsp), %rax
   10b31:      	movl	0x5c(%rsp), %r15d
   10b36:      	subq	%rbx, %rax
   10b39:      	movl	0x50(%rsp), %r12d
   10b3e:      	movl	%r15d, %edx
   10b41:      	subl	%r12d, %edx
   10b44:      	movl	$0x0, %ecx
   10b49:      	cmovbl	%ecx, %edx
   10b4c:      	addq	0x60(%rsp), %rdx
   10b51:      	xorl	%esi, %esi
   10b53:      	cmpl	%r15d, %r12d
   10b56:      	seta	%sil
   10b5a:      	movl	%r15d, %ecx
   10b5d:      	cmovbl	%r12d, %ecx
   10b61:      	addl	%ecx, %esi
   10b63:      	movl	%r12d, %edi
   10b66:      	subl	%esi, %edi
   10b68:      	movl	%edi, 0x50(%rsp)
   10b6c:      	subq	%rsi, %rax
   10b6f:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10b75:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10b7b:      	ja	0x16402 <generic_kprobe_path+0xba72>
   10b81:      	cmpl	%r15d, %r12d
   10b84:      	jbe	0x10b8a <generic_kprobe_path+0x61fa>
   10b86:      	movb	$0x2f, (%rbx,%rax)
   10b8a:      	xorl	%edi, %edi
   10b8c:      	cmpl	%r15d, %r12d
   10b8f:      	seta	%dil
   10b93:      	movzbl	%cl, %esi
   10b96:      	addq	%rax, %rbx
   10b99:      	addq	%rbx, %rdi
   10b9c:      	movl	$0x4, %eax
   10ba1:      	callq	*%rax
   10ba3:      	movq	%rbx, 0x48(%rsp)
   10ba8:      	cmpl	%r15d, %r12d
   10bab:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   10bb1:      	movq	0x8(%rsp), %r12
   10bb6:      	movq	%r12, 0x30(%rsp)
   10bbb:      	movq	0x38(%rsp), %rdx
   10bc0:      	movq	0x40(%rsp), %r15
   10bc5:      	jmp	0x10c18 <generic_kprobe_path+0x6288>
   10bc7:      	leaq	0x10(%r15), %rdx
   10bcb:      	movl	$0x4, %eax
   10bd0:      	movq	%rbp, %rdi
   10bd3:      	movl	$0x8, %esi
   10bd8:      	callq	*%rax
   10bda:      	movq	0x40(%rsp), %rax
   10bdf:      	cmpq	(%rsp), %rax
   10be3:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10be9:      	addq	$0x18, %r15
   10bed:      	movl	$0x4, %eax
   10bf2:      	leaq	0x30(%rsp), %rdi
   10bf7:      	movl	$0x8, %esi
   10bfc:      	movq	%r15, %rdx
   10bff:      	callq	*%rax
   10c01:      	movq	(%rsp), %r15
   10c05:      	movq	%r15, 0x40(%rsp)
   10c0a:      	leaq	0x20(%r15), %rdx
   10c0e:      	movq	%rdx, 0x38(%rsp)
   10c13:      	movq	0x30(%rsp), %r12
   10c18:      	cmpq	0x18(%rsp), %r12
   10c1d:      	jne	0x10c2a <generic_kprobe_path+0x629a>
   10c1f:      	cmpq	0x20(%rsp), %rdx
   10c24:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10c2a:      	movl	$0x4, %eax
   10c2f:      	leaq	0x10(%rsp), %rdi
   10c34:      	movl	$0x8, %esi
   10c39:      	callq	*%rax
   10c3b:      	cmpq	0x10(%rsp), %r12
   10c40:      	je	0x10d38 <generic_kprobe_path+0x63a8>
   10c46:      	leaq	0x18(%r12), %rbx
   10c4b:      	movl	$0x4, %eax
   10c50:      	movq	%rbp, %rdi
   10c53:      	movl	$0x8, %esi
   10c58:      	movq	%rbx, %rdx
   10c5b:      	callq	*%rax
   10c5d:      	cmpq	%r12, (%rsp)
   10c61:      	je	0x10d38 <generic_kprobe_path+0x63a8>
   10c67:      	movl	$0x4, %eax
   10c6c:      	leaq	0x8(%rsp), %rdi
   10c71:      	movl	$0x8, %esi
   10c76:      	movq	%rbx, %rdx
   10c79:      	callq	*%rax
   10c7b:      	addq	$0x20, %r12
   10c7f:      	movl	$0x4, %eax
   10c84:      	leaq	0x58(%rsp), %rdi
   10c89:      	movl	$0x10, %ecx
   10c8e:      	movl	$0x10, %esi
   10c93:      	movq	%r12, %rdx
   10c96:      	callq	*%rax
   10c98:      	movq	0x28(%rsp), %rbx
   10c9d:      	movq	0x48(%rsp), %rax
   10ca2:      	movl	0x5c(%rsp), %r15d
   10ca7:      	subq	%rbx, %rax
   10caa:      	movl	0x50(%rsp), %r12d
   10caf:      	movl	%r15d, %edx
   10cb2:      	subl	%r12d, %edx
   10cb5:      	movl	$0x0, %ecx
   10cba:      	cmovbl	%ecx, %edx
   10cbd:      	addq	0x60(%rsp), %rdx
   10cc2:      	xorl	%esi, %esi
   10cc4:      	cmpl	%r15d, %r12d
   10cc7:      	seta	%sil
   10ccb:      	movl	%r15d, %ecx
   10cce:      	cmovbl	%r12d, %ecx
   10cd2:      	addl	%ecx, %esi
   10cd4:      	movl	%r12d, %edi
   10cd7:      	subl	%esi, %edi
   10cd9:      	movl	%edi, 0x50(%rsp)
   10cdd:      	subq	%rsi, %rax
   10ce0:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10ce6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10cec:      	ja	0x16402 <generic_kprobe_path+0xba72>
   10cf2:      	cmpl	%r15d, %r12d
   10cf5:      	jbe	0x10cfb <generic_kprobe_path+0x636b>
   10cf7:      	movb	$0x2f, (%rbx,%rax)
   10cfb:      	xorl	%edi, %edi
   10cfd:      	cmpl	%r15d, %r12d
   10d00:      	seta	%dil
   10d04:      	movzbl	%cl, %esi
   10d07:      	addq	%rax, %rbx
   10d0a:      	addq	%rbx, %rdi
   10d0d:      	movl	$0x4, %eax
   10d12:      	callq	*%rax
   10d14:      	movq	%rbx, 0x48(%rsp)
   10d19:      	cmpl	%r15d, %r12d
   10d1c:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   10d22:      	movq	0x8(%rsp), %r12
   10d27:      	movq	%r12, 0x30(%rsp)
   10d2c:      	movq	0x38(%rsp), %rdx
   10d31:      	movq	0x40(%rsp), %r15
   10d36:      	jmp	0x10d89 <generic_kprobe_path+0x63f9>
   10d38:      	leaq	0x10(%r15), %rdx
   10d3c:      	movl	$0x4, %eax
   10d41:      	movq	%rbp, %rdi
   10d44:      	movl	$0x8, %esi
   10d49:      	callq	*%rax
   10d4b:      	movq	0x40(%rsp), %rax
   10d50:      	cmpq	(%rsp), %rax
   10d54:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10d5a:      	addq	$0x18, %r15
   10d5e:      	movl	$0x4, %eax
   10d63:      	leaq	0x30(%rsp), %rdi
   10d68:      	movl	$0x8, %esi
   10d6d:      	movq	%r15, %rdx
   10d70:      	callq	*%rax
   10d72:      	movq	(%rsp), %r15
   10d76:      	movq	%r15, 0x40(%rsp)
   10d7b:      	leaq	0x20(%r15), %rdx
   10d7f:      	movq	%rdx, 0x38(%rsp)
   10d84:      	movq	0x30(%rsp), %r12
   10d89:      	cmpq	0x18(%rsp), %r12
   10d8e:      	jne	0x10d9b <generic_kprobe_path+0x640b>
   10d90:      	cmpq	0x20(%rsp), %rdx
   10d95:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10d9b:      	movl	$0x4, %eax
   10da0:      	leaq	0x10(%rsp), %rdi
   10da5:      	movl	$0x8, %esi
   10daa:      	callq	*%rax
   10dac:      	cmpq	0x10(%rsp), %r12
   10db1:      	je	0x10ea9 <generic_kprobe_path+0x6519>
   10db7:      	leaq	0x18(%r12), %rbx
   10dbc:      	movl	$0x4, %eax
   10dc1:      	movq	%rbp, %rdi
   10dc4:      	movl	$0x8, %esi
   10dc9:      	movq	%rbx, %rdx
   10dcc:      	callq	*%rax
   10dce:      	cmpq	%r12, (%rsp)
   10dd2:      	je	0x10ea9 <generic_kprobe_path+0x6519>
   10dd8:      	movl	$0x4, %eax
   10ddd:      	leaq	0x8(%rsp), %rdi
   10de2:      	movl	$0x8, %esi
   10de7:      	movq	%rbx, %rdx
   10dea:      	callq	*%rax
   10dec:      	addq	$0x20, %r12
   10df0:      	movl	$0x4, %eax
   10df5:      	leaq	0x58(%rsp), %rdi
   10dfa:      	movl	$0x10, %ecx
   10dff:      	movl	$0x10, %esi
   10e04:      	movq	%r12, %rdx
   10e07:      	callq	*%rax
   10e09:      	movq	0x28(%rsp), %rbx
   10e0e:      	movq	0x48(%rsp), %rax
   10e13:      	movl	0x5c(%rsp), %r15d
   10e18:      	subq	%rbx, %rax
   10e1b:      	movl	0x50(%rsp), %r12d
   10e20:      	movl	%r15d, %edx
   10e23:      	subl	%r12d, %edx
   10e26:      	movl	$0x0, %ecx
   10e2b:      	cmovbl	%ecx, %edx
   10e2e:      	addq	0x60(%rsp), %rdx
   10e33:      	xorl	%esi, %esi
   10e35:      	cmpl	%r15d, %r12d
   10e38:      	seta	%sil
   10e3c:      	movl	%r15d, %ecx
   10e3f:      	cmovbl	%r12d, %ecx
   10e43:      	addl	%ecx, %esi
   10e45:      	movl	%r12d, %edi
   10e48:      	subl	%esi, %edi
   10e4a:      	movl	%edi, 0x50(%rsp)
   10e4e:      	subq	%rsi, %rax
   10e51:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10e57:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10e5d:      	ja	0x16402 <generic_kprobe_path+0xba72>
   10e63:      	cmpl	%r15d, %r12d
   10e66:      	jbe	0x10e6c <generic_kprobe_path+0x64dc>
   10e68:      	movb	$0x2f, (%rbx,%rax)
   10e6c:      	xorl	%edi, %edi
   10e6e:      	cmpl	%r15d, %r12d
   10e71:      	seta	%dil
   10e75:      	movzbl	%cl, %esi
   10e78:      	addq	%rax, %rbx
   10e7b:      	addq	%rbx, %rdi
   10e7e:      	movl	$0x4, %eax
   10e83:      	callq	*%rax
   10e85:      	movq	%rbx, 0x48(%rsp)
   10e8a:      	cmpl	%r15d, %r12d
   10e8d:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   10e93:      	movq	0x8(%rsp), %r12
   10e98:      	movq	%r12, 0x30(%rsp)
   10e9d:      	movq	0x38(%rsp), %rdx
   10ea2:      	movq	0x40(%rsp), %r15
   10ea7:      	jmp	0x10efa <generic_kprobe_path+0x656a>
   10ea9:      	leaq	0x10(%r15), %rdx
   10ead:      	movl	$0x4, %eax
   10eb2:      	movq	%rbp, %rdi
   10eb5:      	movl	$0x8, %esi
   10eba:      	callq	*%rax
   10ebc:      	movq	0x40(%rsp), %rax
   10ec1:      	cmpq	(%rsp), %rax
   10ec5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10ecb:      	addq	$0x18, %r15
   10ecf:      	movl	$0x4, %eax
   10ed4:      	leaq	0x30(%rsp), %rdi
   10ed9:      	movl	$0x8, %esi
   10ede:      	movq	%r15, %rdx
   10ee1:      	callq	*%rax
   10ee3:      	movq	(%rsp), %r15
   10ee7:      	movq	%r15, 0x40(%rsp)
   10eec:      	leaq	0x20(%r15), %rdx
   10ef0:      	movq	%rdx, 0x38(%rsp)
   10ef5:      	movq	0x30(%rsp), %r12
   10efa:      	cmpq	0x18(%rsp), %r12
   10eff:      	jne	0x10f0c <generic_kprobe_path+0x657c>
   10f01:      	cmpq	0x20(%rsp), %rdx
   10f06:      	je	0x163fd <generic_kprobe_path+0xba6d>
   10f0c:      	movl	$0x4, %eax
   10f11:      	leaq	0x10(%rsp), %rdi
   10f16:      	movl	$0x8, %esi
   10f1b:      	callq	*%rax
   10f1d:      	cmpq	0x10(%rsp), %r12
   10f22:      	je	0x1101a <generic_kprobe_path+0x668a>
   10f28:      	leaq	0x18(%r12), %rbx
   10f2d:      	movl	$0x4, %eax
   10f32:      	movq	%rbp, %rdi
   10f35:      	movl	$0x8, %esi
   10f3a:      	movq	%rbx, %rdx
   10f3d:      	callq	*%rax
   10f3f:      	cmpq	%r12, (%rsp)
   10f43:      	je	0x1101a <generic_kprobe_path+0x668a>
   10f49:      	movl	$0x4, %eax
   10f4e:      	leaq	0x8(%rsp), %rdi
   10f53:      	movl	$0x8, %esi
   10f58:      	movq	%rbx, %rdx
   10f5b:      	callq	*%rax
   10f5d:      	addq	$0x20, %r12
   10f61:      	movl	$0x4, %eax
   10f66:      	leaq	0x58(%rsp), %rdi
   10f6b:      	movl	$0x10, %ecx
   10f70:      	movl	$0x10, %esi
   10f75:      	movq	%r12, %rdx
   10f78:      	callq	*%rax
   10f7a:      	movq	0x28(%rsp), %rbx
   10f7f:      	movq	0x48(%rsp), %rax
   10f84:      	movl	0x5c(%rsp), %r15d
   10f89:      	subq	%rbx, %rax
   10f8c:      	movl	0x50(%rsp), %r12d
   10f91:      	movl	%r15d, %edx
   10f94:      	subl	%r12d, %edx
   10f97:      	movl	$0x0, %ecx
   10f9c:      	cmovbl	%ecx, %edx
   10f9f:      	addq	0x60(%rsp), %rdx
   10fa4:      	xorl	%esi, %esi
   10fa6:      	cmpl	%r15d, %r12d
   10fa9:      	seta	%sil
   10fad:      	movl	%r15d, %ecx
   10fb0:      	cmovbl	%r12d, %ecx
   10fb4:      	addl	%ecx, %esi
   10fb6:      	movl	%r12d, %edi
   10fb9:      	subl	%esi, %edi
   10fbb:      	movl	%edi, 0x50(%rsp)
   10fbf:      	subq	%rsi, %rax
   10fc2:      	jb	0x16402 <generic_kprobe_path+0xba72>
   10fc8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10fce:      	ja	0x16402 <generic_kprobe_path+0xba72>
   10fd4:      	cmpl	%r15d, %r12d
   10fd7:      	jbe	0x10fdd <generic_kprobe_path+0x664d>
   10fd9:      	movb	$0x2f, (%rbx,%rax)
   10fdd:      	xorl	%edi, %edi
   10fdf:      	cmpl	%r15d, %r12d
   10fe2:      	seta	%dil
   10fe6:      	movzbl	%cl, %esi
   10fe9:      	addq	%rax, %rbx
   10fec:      	addq	%rbx, %rdi
   10fef:      	movl	$0x4, %eax
   10ff4:      	callq	*%rax
   10ff6:      	movq	%rbx, 0x48(%rsp)
   10ffb:      	cmpl	%r15d, %r12d
   10ffe:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11004:      	movq	0x8(%rsp), %r12
   11009:      	movq	%r12, 0x30(%rsp)
   1100e:      	movq	0x38(%rsp), %rdx
   11013:      	movq	0x40(%rsp), %r15
   11018:      	jmp	0x1106b <generic_kprobe_path+0x66db>
   1101a:      	leaq	0x10(%r15), %rdx
   1101e:      	movl	$0x4, %eax
   11023:      	movq	%rbp, %rdi
   11026:      	movl	$0x8, %esi
   1102b:      	callq	*%rax
   1102d:      	movq	0x40(%rsp), %rax
   11032:      	cmpq	(%rsp), %rax
   11036:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1103c:      	addq	$0x18, %r15
   11040:      	movl	$0x4, %eax
   11045:      	leaq	0x30(%rsp), %rdi
   1104a:      	movl	$0x8, %esi
   1104f:      	movq	%r15, %rdx
   11052:      	callq	*%rax
   11054:      	movq	(%rsp), %r15
   11058:      	movq	%r15, 0x40(%rsp)
   1105d:      	leaq	0x20(%r15), %rdx
   11061:      	movq	%rdx, 0x38(%rsp)
   11066:      	movq	0x30(%rsp), %r12
   1106b:      	cmpq	0x18(%rsp), %r12
   11070:      	jne	0x1107d <generic_kprobe_path+0x66ed>
   11072:      	cmpq	0x20(%rsp), %rdx
   11077:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1107d:      	movl	$0x4, %eax
   11082:      	leaq	0x10(%rsp), %rdi
   11087:      	movl	$0x8, %esi
   1108c:      	callq	*%rax
   1108e:      	cmpq	0x10(%rsp), %r12
   11093:      	je	0x1118b <generic_kprobe_path+0x67fb>
   11099:      	leaq	0x18(%r12), %rbx
   1109e:      	movl	$0x4, %eax
   110a3:      	movq	%rbp, %rdi
   110a6:      	movl	$0x8, %esi
   110ab:      	movq	%rbx, %rdx
   110ae:      	callq	*%rax
   110b0:      	cmpq	%r12, (%rsp)
   110b4:      	je	0x1118b <generic_kprobe_path+0x67fb>
   110ba:      	movl	$0x4, %eax
   110bf:      	leaq	0x8(%rsp), %rdi
   110c4:      	movl	$0x8, %esi
   110c9:      	movq	%rbx, %rdx
   110cc:      	callq	*%rax
   110ce:      	addq	$0x20, %r12
   110d2:      	movl	$0x4, %eax
   110d7:      	leaq	0x58(%rsp), %rdi
   110dc:      	movl	$0x10, %ecx
   110e1:      	movl	$0x10, %esi
   110e6:      	movq	%r12, %rdx
   110e9:      	callq	*%rax
   110eb:      	movq	0x28(%rsp), %rbx
   110f0:      	movq	0x48(%rsp), %rax
   110f5:      	movl	0x5c(%rsp), %r15d
   110fa:      	subq	%rbx, %rax
   110fd:      	movl	0x50(%rsp), %r12d
   11102:      	movl	%r15d, %edx
   11105:      	subl	%r12d, %edx
   11108:      	movl	$0x0, %ecx
   1110d:      	cmovbl	%ecx, %edx
   11110:      	addq	0x60(%rsp), %rdx
   11115:      	xorl	%esi, %esi
   11117:      	cmpl	%r15d, %r12d
   1111a:      	seta	%sil
   1111e:      	movl	%r15d, %ecx
   11121:      	cmovbl	%r12d, %ecx
   11125:      	addl	%ecx, %esi
   11127:      	movl	%r12d, %edi
   1112a:      	subl	%esi, %edi
   1112c:      	movl	%edi, 0x50(%rsp)
   11130:      	subq	%rsi, %rax
   11133:      	jb	0x16402 <generic_kprobe_path+0xba72>
   11139:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1113f:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11145:      	cmpl	%r15d, %r12d
   11148:      	jbe	0x1114e <generic_kprobe_path+0x67be>
   1114a:      	movb	$0x2f, (%rbx,%rax)
   1114e:      	xorl	%edi, %edi
   11150:      	cmpl	%r15d, %r12d
   11153:      	seta	%dil
   11157:      	movzbl	%cl, %esi
   1115a:      	addq	%rax, %rbx
   1115d:      	addq	%rbx, %rdi
   11160:      	movl	$0x4, %eax
   11165:      	callq	*%rax
   11167:      	movq	%rbx, 0x48(%rsp)
   1116c:      	cmpl	%r15d, %r12d
   1116f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11175:      	movq	0x8(%rsp), %r12
   1117a:      	movq	%r12, 0x30(%rsp)
   1117f:      	movq	0x38(%rsp), %rdx
   11184:      	movq	0x40(%rsp), %r15
   11189:      	jmp	0x111dc <generic_kprobe_path+0x684c>
   1118b:      	leaq	0x10(%r15), %rdx
   1118f:      	movl	$0x4, %eax
   11194:      	movq	%rbp, %rdi
   11197:      	movl	$0x8, %esi
   1119c:      	callq	*%rax
   1119e:      	movq	0x40(%rsp), %rax
   111a3:      	cmpq	(%rsp), %rax
   111a7:      	je	0x163fd <generic_kprobe_path+0xba6d>
   111ad:      	addq	$0x18, %r15
   111b1:      	movl	$0x4, %eax
   111b6:      	leaq	0x30(%rsp), %rdi
   111bb:      	movl	$0x8, %esi
   111c0:      	movq	%r15, %rdx
   111c3:      	callq	*%rax
   111c5:      	movq	(%rsp), %r15
   111c9:      	movq	%r15, 0x40(%rsp)
   111ce:      	leaq	0x20(%r15), %rdx
   111d2:      	movq	%rdx, 0x38(%rsp)
   111d7:      	movq	0x30(%rsp), %r12
   111dc:      	cmpq	0x18(%rsp), %r12
   111e1:      	jne	0x111ee <generic_kprobe_path+0x685e>
   111e3:      	cmpq	0x20(%rsp), %rdx
   111e8:      	je	0x163fd <generic_kprobe_path+0xba6d>
   111ee:      	movl	$0x4, %eax
   111f3:      	leaq	0x10(%rsp), %rdi
   111f8:      	movl	$0x8, %esi
   111fd:      	callq	*%rax
   111ff:      	cmpq	0x10(%rsp), %r12
   11204:      	je	0x112fc <generic_kprobe_path+0x696c>
   1120a:      	leaq	0x18(%r12), %rbx
   1120f:      	movl	$0x4, %eax
   11214:      	movq	%rbp, %rdi
   11217:      	movl	$0x8, %esi
   1121c:      	movq	%rbx, %rdx
   1121f:      	callq	*%rax
   11221:      	cmpq	%r12, (%rsp)
   11225:      	je	0x112fc <generic_kprobe_path+0x696c>
   1122b:      	movl	$0x4, %eax
   11230:      	leaq	0x8(%rsp), %rdi
   11235:      	movl	$0x8, %esi
   1123a:      	movq	%rbx, %rdx
   1123d:      	callq	*%rax
   1123f:      	addq	$0x20, %r12
   11243:      	movl	$0x4, %eax
   11248:      	leaq	0x58(%rsp), %rdi
   1124d:      	movl	$0x10, %ecx
   11252:      	movl	$0x10, %esi
   11257:      	movq	%r12, %rdx
   1125a:      	callq	*%rax
   1125c:      	movq	0x28(%rsp), %rbx
   11261:      	movq	0x48(%rsp), %rax
   11266:      	movl	0x5c(%rsp), %r15d
   1126b:      	subq	%rbx, %rax
   1126e:      	movl	0x50(%rsp), %r12d
   11273:      	movl	%r15d, %edx
   11276:      	subl	%r12d, %edx
   11279:      	movl	$0x0, %ecx
   1127e:      	cmovbl	%ecx, %edx
   11281:      	addq	0x60(%rsp), %rdx
   11286:      	xorl	%esi, %esi
   11288:      	cmpl	%r15d, %r12d
   1128b:      	seta	%sil
   1128f:      	movl	%r15d, %ecx
   11292:      	cmovbl	%r12d, %ecx
   11296:      	addl	%ecx, %esi
   11298:      	movl	%r12d, %edi
   1129b:      	subl	%esi, %edi
   1129d:      	movl	%edi, 0x50(%rsp)
   112a1:      	subq	%rsi, %rax
   112a4:      	jb	0x16402 <generic_kprobe_path+0xba72>
   112aa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   112b0:      	ja	0x16402 <generic_kprobe_path+0xba72>
   112b6:      	cmpl	%r15d, %r12d
   112b9:      	jbe	0x112bf <generic_kprobe_path+0x692f>
   112bb:      	movb	$0x2f, (%rbx,%rax)
   112bf:      	xorl	%edi, %edi
   112c1:      	cmpl	%r15d, %r12d
   112c4:      	seta	%dil
   112c8:      	movzbl	%cl, %esi
   112cb:      	addq	%rax, %rbx
   112ce:      	addq	%rbx, %rdi
   112d1:      	movl	$0x4, %eax
   112d6:      	callq	*%rax
   112d8:      	movq	%rbx, 0x48(%rsp)
   112dd:      	cmpl	%r15d, %r12d
   112e0:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   112e6:      	movq	0x8(%rsp), %r12
   112eb:      	movq	%r12, 0x30(%rsp)
   112f0:      	movq	0x38(%rsp), %rdx
   112f5:      	movq	0x40(%rsp), %r15
   112fa:      	jmp	0x1134d <generic_kprobe_path+0x69bd>
   112fc:      	leaq	0x10(%r15), %rdx
   11300:      	movl	$0x4, %eax
   11305:      	movq	%rbp, %rdi
   11308:      	movl	$0x8, %esi
   1130d:      	callq	*%rax
   1130f:      	movq	0x40(%rsp), %rax
   11314:      	cmpq	(%rsp), %rax
   11318:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1131e:      	addq	$0x18, %r15
   11322:      	movl	$0x4, %eax
   11327:      	leaq	0x30(%rsp), %rdi
   1132c:      	movl	$0x8, %esi
   11331:      	movq	%r15, %rdx
   11334:      	callq	*%rax
   11336:      	movq	(%rsp), %r15
   1133a:      	movq	%r15, 0x40(%rsp)
   1133f:      	leaq	0x20(%r15), %rdx
   11343:      	movq	%rdx, 0x38(%rsp)
   11348:      	movq	0x30(%rsp), %r12
   1134d:      	cmpq	0x18(%rsp), %r12
   11352:      	jne	0x1135f <generic_kprobe_path+0x69cf>
   11354:      	cmpq	0x20(%rsp), %rdx
   11359:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1135f:      	movl	$0x4, %eax
   11364:      	leaq	0x10(%rsp), %rdi
   11369:      	movl	$0x8, %esi
   1136e:      	callq	*%rax
   11370:      	cmpq	0x10(%rsp), %r12
   11375:      	je	0x1146d <generic_kprobe_path+0x6add>
   1137b:      	leaq	0x18(%r12), %rbx
   11380:      	movl	$0x4, %eax
   11385:      	movq	%rbp, %rdi
   11388:      	movl	$0x8, %esi
   1138d:      	movq	%rbx, %rdx
   11390:      	callq	*%rax
   11392:      	cmpq	%r12, (%rsp)
   11396:      	je	0x1146d <generic_kprobe_path+0x6add>
   1139c:      	movl	$0x4, %eax
   113a1:      	leaq	0x8(%rsp), %rdi
   113a6:      	movl	$0x8, %esi
   113ab:      	movq	%rbx, %rdx
   113ae:      	callq	*%rax
   113b0:      	addq	$0x20, %r12
   113b4:      	movl	$0x4, %eax
   113b9:      	leaq	0x58(%rsp), %rdi
   113be:      	movl	$0x10, %ecx
   113c3:      	movl	$0x10, %esi
   113c8:      	movq	%r12, %rdx
   113cb:      	callq	*%rax
   113cd:      	movq	0x28(%rsp), %rbx
   113d2:      	movq	0x48(%rsp), %rax
   113d7:      	movl	0x5c(%rsp), %r15d
   113dc:      	subq	%rbx, %rax
   113df:      	movl	0x50(%rsp), %r12d
   113e4:      	movl	%r15d, %edx
   113e7:      	subl	%r12d, %edx
   113ea:      	movl	$0x0, %ecx
   113ef:      	cmovbl	%ecx, %edx
   113f2:      	addq	0x60(%rsp), %rdx
   113f7:      	xorl	%esi, %esi
   113f9:      	cmpl	%r15d, %r12d
   113fc:      	seta	%sil
   11400:      	movl	%r15d, %ecx
   11403:      	cmovbl	%r12d, %ecx
   11407:      	addl	%ecx, %esi
   11409:      	movl	%r12d, %edi
   1140c:      	subl	%esi, %edi
   1140e:      	movl	%edi, 0x50(%rsp)
   11412:      	subq	%rsi, %rax
   11415:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1141b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11421:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11427:      	cmpl	%r15d, %r12d
   1142a:      	jbe	0x11430 <generic_kprobe_path+0x6aa0>
   1142c:      	movb	$0x2f, (%rbx,%rax)
   11430:      	xorl	%edi, %edi
   11432:      	cmpl	%r15d, %r12d
   11435:      	seta	%dil
   11439:      	movzbl	%cl, %esi
   1143c:      	addq	%rax, %rbx
   1143f:      	addq	%rbx, %rdi
   11442:      	movl	$0x4, %eax
   11447:      	callq	*%rax
   11449:      	movq	%rbx, 0x48(%rsp)
   1144e:      	cmpl	%r15d, %r12d
   11451:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11457:      	movq	0x8(%rsp), %r12
   1145c:      	movq	%r12, 0x30(%rsp)
   11461:      	movq	0x38(%rsp), %rdx
   11466:      	movq	0x40(%rsp), %r15
   1146b:      	jmp	0x114be <generic_kprobe_path+0x6b2e>
   1146d:      	leaq	0x10(%r15), %rdx
   11471:      	movl	$0x4, %eax
   11476:      	movq	%rbp, %rdi
   11479:      	movl	$0x8, %esi
   1147e:      	callq	*%rax
   11480:      	movq	0x40(%rsp), %rax
   11485:      	cmpq	(%rsp), %rax
   11489:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1148f:      	addq	$0x18, %r15
   11493:      	movl	$0x4, %eax
   11498:      	leaq	0x30(%rsp), %rdi
   1149d:      	movl	$0x8, %esi
   114a2:      	movq	%r15, %rdx
   114a5:      	callq	*%rax
   114a7:      	movq	(%rsp), %r15
   114ab:      	movq	%r15, 0x40(%rsp)
   114b0:      	leaq	0x20(%r15), %rdx
   114b4:      	movq	%rdx, 0x38(%rsp)
   114b9:      	movq	0x30(%rsp), %r12
   114be:      	cmpq	0x18(%rsp), %r12
   114c3:      	jne	0x114d0 <generic_kprobe_path+0x6b40>
   114c5:      	cmpq	0x20(%rsp), %rdx
   114ca:      	je	0x163fd <generic_kprobe_path+0xba6d>
   114d0:      	movl	$0x4, %eax
   114d5:      	leaq	0x10(%rsp), %rdi
   114da:      	movl	$0x8, %esi
   114df:      	callq	*%rax
   114e1:      	cmpq	0x10(%rsp), %r12
   114e6:      	je	0x115de <generic_kprobe_path+0x6c4e>
   114ec:      	leaq	0x18(%r12), %rbx
   114f1:      	movl	$0x4, %eax
   114f6:      	movq	%rbp, %rdi
   114f9:      	movl	$0x8, %esi
   114fe:      	movq	%rbx, %rdx
   11501:      	callq	*%rax
   11503:      	cmpq	%r12, (%rsp)
   11507:      	je	0x115de <generic_kprobe_path+0x6c4e>
   1150d:      	movl	$0x4, %eax
   11512:      	leaq	0x8(%rsp), %rdi
   11517:      	movl	$0x8, %esi
   1151c:      	movq	%rbx, %rdx
   1151f:      	callq	*%rax
   11521:      	addq	$0x20, %r12
   11525:      	movl	$0x4, %eax
   1152a:      	leaq	0x58(%rsp), %rdi
   1152f:      	movl	$0x10, %ecx
   11534:      	movl	$0x10, %esi
   11539:      	movq	%r12, %rdx
   1153c:      	callq	*%rax
   1153e:      	movq	0x28(%rsp), %rbx
   11543:      	movq	0x48(%rsp), %rax
   11548:      	movl	0x5c(%rsp), %r15d
   1154d:      	subq	%rbx, %rax
   11550:      	movl	0x50(%rsp), %r12d
   11555:      	movl	%r15d, %edx
   11558:      	subl	%r12d, %edx
   1155b:      	movl	$0x0, %ecx
   11560:      	cmovbl	%ecx, %edx
   11563:      	addq	0x60(%rsp), %rdx
   11568:      	xorl	%esi, %esi
   1156a:      	cmpl	%r15d, %r12d
   1156d:      	seta	%sil
   11571:      	movl	%r15d, %ecx
   11574:      	cmovbl	%r12d, %ecx
   11578:      	addl	%ecx, %esi
   1157a:      	movl	%r12d, %edi
   1157d:      	subl	%esi, %edi
   1157f:      	movl	%edi, 0x50(%rsp)
   11583:      	subq	%rsi, %rax
   11586:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1158c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11592:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11598:      	cmpl	%r15d, %r12d
   1159b:      	jbe	0x115a1 <generic_kprobe_path+0x6c11>
   1159d:      	movb	$0x2f, (%rbx,%rax)
   115a1:      	xorl	%edi, %edi
   115a3:      	cmpl	%r15d, %r12d
   115a6:      	seta	%dil
   115aa:      	movzbl	%cl, %esi
   115ad:      	addq	%rax, %rbx
   115b0:      	addq	%rbx, %rdi
   115b3:      	movl	$0x4, %eax
   115b8:      	callq	*%rax
   115ba:      	movq	%rbx, 0x48(%rsp)
   115bf:      	cmpl	%r15d, %r12d
   115c2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   115c8:      	movq	0x8(%rsp), %r12
   115cd:      	movq	%r12, 0x30(%rsp)
   115d2:      	movq	0x38(%rsp), %rdx
   115d7:      	movq	0x40(%rsp), %r15
   115dc:      	jmp	0x1162f <generic_kprobe_path+0x6c9f>
   115de:      	leaq	0x10(%r15), %rdx
   115e2:      	movl	$0x4, %eax
   115e7:      	movq	%rbp, %rdi
   115ea:      	movl	$0x8, %esi
   115ef:      	callq	*%rax
   115f1:      	movq	0x40(%rsp), %rax
   115f6:      	cmpq	(%rsp), %rax
   115fa:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11600:      	addq	$0x18, %r15
   11604:      	movl	$0x4, %eax
   11609:      	leaq	0x30(%rsp), %rdi
   1160e:      	movl	$0x8, %esi
   11613:      	movq	%r15, %rdx
   11616:      	callq	*%rax
   11618:      	movq	(%rsp), %r15
   1161c:      	movq	%r15, 0x40(%rsp)
   11621:      	leaq	0x20(%r15), %rdx
   11625:      	movq	%rdx, 0x38(%rsp)
   1162a:      	movq	0x30(%rsp), %r12
   1162f:      	cmpq	0x18(%rsp), %r12
   11634:      	jne	0x11641 <generic_kprobe_path+0x6cb1>
   11636:      	cmpq	0x20(%rsp), %rdx
   1163b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11641:      	movl	$0x4, %eax
   11646:      	leaq	0x10(%rsp), %rdi
   1164b:      	movl	$0x8, %esi
   11650:      	callq	*%rax
   11652:      	cmpq	0x10(%rsp), %r12
   11657:      	je	0x1174f <generic_kprobe_path+0x6dbf>
   1165d:      	leaq	0x18(%r12), %rbx
   11662:      	movl	$0x4, %eax
   11667:      	movq	%rbp, %rdi
   1166a:      	movl	$0x8, %esi
   1166f:      	movq	%rbx, %rdx
   11672:      	callq	*%rax
   11674:      	cmpq	%r12, (%rsp)
   11678:      	je	0x1174f <generic_kprobe_path+0x6dbf>
   1167e:      	movl	$0x4, %eax
   11683:      	leaq	0x8(%rsp), %rdi
   11688:      	movl	$0x8, %esi
   1168d:      	movq	%rbx, %rdx
   11690:      	callq	*%rax
   11692:      	addq	$0x20, %r12
   11696:      	movl	$0x4, %eax
   1169b:      	leaq	0x58(%rsp), %rdi
   116a0:      	movl	$0x10, %ecx
   116a5:      	movl	$0x10, %esi
   116aa:      	movq	%r12, %rdx
   116ad:      	callq	*%rax
   116af:      	movq	0x28(%rsp), %rbx
   116b4:      	movq	0x48(%rsp), %rax
   116b9:      	movl	0x5c(%rsp), %r15d
   116be:      	subq	%rbx, %rax
   116c1:      	movl	0x50(%rsp), %r12d
   116c6:      	movl	%r15d, %edx
   116c9:      	subl	%r12d, %edx
   116cc:      	movl	$0x0, %ecx
   116d1:      	cmovbl	%ecx, %edx
   116d4:      	addq	0x60(%rsp), %rdx
   116d9:      	xorl	%esi, %esi
   116db:      	cmpl	%r15d, %r12d
   116de:      	seta	%sil
   116e2:      	movl	%r15d, %ecx
   116e5:      	cmovbl	%r12d, %ecx
   116e9:      	addl	%ecx, %esi
   116eb:      	movl	%r12d, %edi
   116ee:      	subl	%esi, %edi
   116f0:      	movl	%edi, 0x50(%rsp)
   116f4:      	subq	%rsi, %rax
   116f7:      	jb	0x16402 <generic_kprobe_path+0xba72>
   116fd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11703:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11709:      	cmpl	%r15d, %r12d
   1170c:      	jbe	0x11712 <generic_kprobe_path+0x6d82>
   1170e:      	movb	$0x2f, (%rbx,%rax)
   11712:      	xorl	%edi, %edi
   11714:      	cmpl	%r15d, %r12d
   11717:      	seta	%dil
   1171b:      	movzbl	%cl, %esi
   1171e:      	addq	%rax, %rbx
   11721:      	addq	%rbx, %rdi
   11724:      	movl	$0x4, %eax
   11729:      	callq	*%rax
   1172b:      	movq	%rbx, 0x48(%rsp)
   11730:      	cmpl	%r15d, %r12d
   11733:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11739:      	movq	0x8(%rsp), %r12
   1173e:      	movq	%r12, 0x30(%rsp)
   11743:      	movq	0x38(%rsp), %rdx
   11748:      	movq	0x40(%rsp), %r15
   1174d:      	jmp	0x117a0 <generic_kprobe_path+0x6e10>
   1174f:      	leaq	0x10(%r15), %rdx
   11753:      	movl	$0x4, %eax
   11758:      	movq	%rbp, %rdi
   1175b:      	movl	$0x8, %esi
   11760:      	callq	*%rax
   11762:      	movq	0x40(%rsp), %rax
   11767:      	cmpq	(%rsp), %rax
   1176b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11771:      	addq	$0x18, %r15
   11775:      	movl	$0x4, %eax
   1177a:      	leaq	0x30(%rsp), %rdi
   1177f:      	movl	$0x8, %esi
   11784:      	movq	%r15, %rdx
   11787:      	callq	*%rax
   11789:      	movq	(%rsp), %r15
   1178d:      	movq	%r15, 0x40(%rsp)
   11792:      	leaq	0x20(%r15), %rdx
   11796:      	movq	%rdx, 0x38(%rsp)
   1179b:      	movq	0x30(%rsp), %r12
   117a0:      	cmpq	0x18(%rsp), %r12
   117a5:      	jne	0x117b2 <generic_kprobe_path+0x6e22>
   117a7:      	cmpq	0x20(%rsp), %rdx
   117ac:      	je	0x163fd <generic_kprobe_path+0xba6d>
   117b2:      	movl	$0x4, %eax
   117b7:      	leaq	0x10(%rsp), %rdi
   117bc:      	movl	$0x8, %esi
   117c1:      	callq	*%rax
   117c3:      	cmpq	0x10(%rsp), %r12
   117c8:      	je	0x118c0 <generic_kprobe_path+0x6f30>
   117ce:      	leaq	0x18(%r12), %rbx
   117d3:      	movl	$0x4, %eax
   117d8:      	movq	%rbp, %rdi
   117db:      	movl	$0x8, %esi
   117e0:      	movq	%rbx, %rdx
   117e3:      	callq	*%rax
   117e5:      	cmpq	%r12, (%rsp)
   117e9:      	je	0x118c0 <generic_kprobe_path+0x6f30>
   117ef:      	movl	$0x4, %eax
   117f4:      	leaq	0x8(%rsp), %rdi
   117f9:      	movl	$0x8, %esi
   117fe:      	movq	%rbx, %rdx
   11801:      	callq	*%rax
   11803:      	addq	$0x20, %r12
   11807:      	movl	$0x4, %eax
   1180c:      	leaq	0x58(%rsp), %rdi
   11811:      	movl	$0x10, %ecx
   11816:      	movl	$0x10, %esi
   1181b:      	movq	%r12, %rdx
   1181e:      	callq	*%rax
   11820:      	movq	0x28(%rsp), %rbx
   11825:      	movq	0x48(%rsp), %rax
   1182a:      	movl	0x5c(%rsp), %r15d
   1182f:      	subq	%rbx, %rax
   11832:      	movl	0x50(%rsp), %r12d
   11837:      	movl	%r15d, %edx
   1183a:      	subl	%r12d, %edx
   1183d:      	movl	$0x0, %ecx
   11842:      	cmovbl	%ecx, %edx
   11845:      	addq	0x60(%rsp), %rdx
   1184a:      	xorl	%esi, %esi
   1184c:      	cmpl	%r15d, %r12d
   1184f:      	seta	%sil
   11853:      	movl	%r15d, %ecx
   11856:      	cmovbl	%r12d, %ecx
   1185a:      	addl	%ecx, %esi
   1185c:      	movl	%r12d, %edi
   1185f:      	subl	%esi, %edi
   11861:      	movl	%edi, 0x50(%rsp)
   11865:      	subq	%rsi, %rax
   11868:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1186e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11874:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1187a:      	cmpl	%r15d, %r12d
   1187d:      	jbe	0x11883 <generic_kprobe_path+0x6ef3>
   1187f:      	movb	$0x2f, (%rbx,%rax)
   11883:      	xorl	%edi, %edi
   11885:      	cmpl	%r15d, %r12d
   11888:      	seta	%dil
   1188c:      	movzbl	%cl, %esi
   1188f:      	addq	%rax, %rbx
   11892:      	addq	%rbx, %rdi
   11895:      	movl	$0x4, %eax
   1189a:      	callq	*%rax
   1189c:      	movq	%rbx, 0x48(%rsp)
   118a1:      	cmpl	%r15d, %r12d
   118a4:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   118aa:      	movq	0x8(%rsp), %r12
   118af:      	movq	%r12, 0x30(%rsp)
   118b4:      	movq	0x38(%rsp), %rdx
   118b9:      	movq	0x40(%rsp), %r15
   118be:      	jmp	0x11911 <generic_kprobe_path+0x6f81>
   118c0:      	leaq	0x10(%r15), %rdx
   118c4:      	movl	$0x4, %eax
   118c9:      	movq	%rbp, %rdi
   118cc:      	movl	$0x8, %esi
   118d1:      	callq	*%rax
   118d3:      	movq	0x40(%rsp), %rax
   118d8:      	cmpq	(%rsp), %rax
   118dc:      	je	0x163fd <generic_kprobe_path+0xba6d>
   118e2:      	addq	$0x18, %r15
   118e6:      	movl	$0x4, %eax
   118eb:      	leaq	0x30(%rsp), %rdi
   118f0:      	movl	$0x8, %esi
   118f5:      	movq	%r15, %rdx
   118f8:      	callq	*%rax
   118fa:      	movq	(%rsp), %r15
   118fe:      	movq	%r15, 0x40(%rsp)
   11903:      	leaq	0x20(%r15), %rdx
   11907:      	movq	%rdx, 0x38(%rsp)
   1190c:      	movq	0x30(%rsp), %r12
   11911:      	cmpq	0x18(%rsp), %r12
   11916:      	jne	0x11923 <generic_kprobe_path+0x6f93>
   11918:      	cmpq	0x20(%rsp), %rdx
   1191d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11923:      	movl	$0x4, %eax
   11928:      	leaq	0x10(%rsp), %rdi
   1192d:      	movl	$0x8, %esi
   11932:      	callq	*%rax
   11934:      	cmpq	0x10(%rsp), %r12
   11939:      	je	0x11a31 <generic_kprobe_path+0x70a1>
   1193f:      	leaq	0x18(%r12), %rbx
   11944:      	movl	$0x4, %eax
   11949:      	movq	%rbp, %rdi
   1194c:      	movl	$0x8, %esi
   11951:      	movq	%rbx, %rdx
   11954:      	callq	*%rax
   11956:      	cmpq	%r12, (%rsp)
   1195a:      	je	0x11a31 <generic_kprobe_path+0x70a1>
   11960:      	movl	$0x4, %eax
   11965:      	leaq	0x8(%rsp), %rdi
   1196a:      	movl	$0x8, %esi
   1196f:      	movq	%rbx, %rdx
   11972:      	callq	*%rax
   11974:      	addq	$0x20, %r12
   11978:      	movl	$0x4, %eax
   1197d:      	leaq	0x58(%rsp), %rdi
   11982:      	movl	$0x10, %ecx
   11987:      	movl	$0x10, %esi
   1198c:      	movq	%r12, %rdx
   1198f:      	callq	*%rax
   11991:      	movq	0x28(%rsp), %rbx
   11996:      	movq	0x48(%rsp), %rax
   1199b:      	movl	0x5c(%rsp), %r15d
   119a0:      	subq	%rbx, %rax
   119a3:      	movl	0x50(%rsp), %r12d
   119a8:      	movl	%r15d, %edx
   119ab:      	subl	%r12d, %edx
   119ae:      	movl	$0x0, %ecx
   119b3:      	cmovbl	%ecx, %edx
   119b6:      	addq	0x60(%rsp), %rdx
   119bb:      	xorl	%esi, %esi
   119bd:      	cmpl	%r15d, %r12d
   119c0:      	seta	%sil
   119c4:      	movl	%r15d, %ecx
   119c7:      	cmovbl	%r12d, %ecx
   119cb:      	addl	%ecx, %esi
   119cd:      	movl	%r12d, %edi
   119d0:      	subl	%esi, %edi
   119d2:      	movl	%edi, 0x50(%rsp)
   119d6:      	subq	%rsi, %rax
   119d9:      	jb	0x16402 <generic_kprobe_path+0xba72>
   119df:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   119e5:      	ja	0x16402 <generic_kprobe_path+0xba72>
   119eb:      	cmpl	%r15d, %r12d
   119ee:      	jbe	0x119f4 <generic_kprobe_path+0x7064>
   119f0:      	movb	$0x2f, (%rbx,%rax)
   119f4:      	xorl	%edi, %edi
   119f6:      	cmpl	%r15d, %r12d
   119f9:      	seta	%dil
   119fd:      	movzbl	%cl, %esi
   11a00:      	addq	%rax, %rbx
   11a03:      	addq	%rbx, %rdi
   11a06:      	movl	$0x4, %eax
   11a0b:      	callq	*%rax
   11a0d:      	movq	%rbx, 0x48(%rsp)
   11a12:      	cmpl	%r15d, %r12d
   11a15:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11a1b:      	movq	0x8(%rsp), %r12
   11a20:      	movq	%r12, 0x30(%rsp)
   11a25:      	movq	0x38(%rsp), %rdx
   11a2a:      	movq	0x40(%rsp), %r15
   11a2f:      	jmp	0x11a82 <generic_kprobe_path+0x70f2>
   11a31:      	leaq	0x10(%r15), %rdx
   11a35:      	movl	$0x4, %eax
   11a3a:      	movq	%rbp, %rdi
   11a3d:      	movl	$0x8, %esi
   11a42:      	callq	*%rax
   11a44:      	movq	0x40(%rsp), %rax
   11a49:      	cmpq	(%rsp), %rax
   11a4d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11a53:      	addq	$0x18, %r15
   11a57:      	movl	$0x4, %eax
   11a5c:      	leaq	0x30(%rsp), %rdi
   11a61:      	movl	$0x8, %esi
   11a66:      	movq	%r15, %rdx
   11a69:      	callq	*%rax
   11a6b:      	movq	(%rsp), %r15
   11a6f:      	movq	%r15, 0x40(%rsp)
   11a74:      	leaq	0x20(%r15), %rdx
   11a78:      	movq	%rdx, 0x38(%rsp)
   11a7d:      	movq	0x30(%rsp), %r12
   11a82:      	cmpq	0x18(%rsp), %r12
   11a87:      	jne	0x11a94 <generic_kprobe_path+0x7104>
   11a89:      	cmpq	0x20(%rsp), %rdx
   11a8e:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11a94:      	movl	$0x4, %eax
   11a99:      	leaq	0x10(%rsp), %rdi
   11a9e:      	movl	$0x8, %esi
   11aa3:      	callq	*%rax
   11aa5:      	cmpq	0x10(%rsp), %r12
   11aaa:      	je	0x11ba2 <generic_kprobe_path+0x7212>
   11ab0:      	leaq	0x18(%r12), %rbx
   11ab5:      	movl	$0x4, %eax
   11aba:      	movq	%rbp, %rdi
   11abd:      	movl	$0x8, %esi
   11ac2:      	movq	%rbx, %rdx
   11ac5:      	callq	*%rax
   11ac7:      	cmpq	%r12, (%rsp)
   11acb:      	je	0x11ba2 <generic_kprobe_path+0x7212>
   11ad1:      	movl	$0x4, %eax
   11ad6:      	leaq	0x8(%rsp), %rdi
   11adb:      	movl	$0x8, %esi
   11ae0:      	movq	%rbx, %rdx
   11ae3:      	callq	*%rax
   11ae5:      	addq	$0x20, %r12
   11ae9:      	movl	$0x4, %eax
   11aee:      	leaq	0x58(%rsp), %rdi
   11af3:      	movl	$0x10, %ecx
   11af8:      	movl	$0x10, %esi
   11afd:      	movq	%r12, %rdx
   11b00:      	callq	*%rax
   11b02:      	movq	0x28(%rsp), %rbx
   11b07:      	movq	0x48(%rsp), %rax
   11b0c:      	movl	0x5c(%rsp), %r15d
   11b11:      	subq	%rbx, %rax
   11b14:      	movl	0x50(%rsp), %r12d
   11b19:      	movl	%r15d, %edx
   11b1c:      	subl	%r12d, %edx
   11b1f:      	movl	$0x0, %ecx
   11b24:      	cmovbl	%ecx, %edx
   11b27:      	addq	0x60(%rsp), %rdx
   11b2c:      	xorl	%esi, %esi
   11b2e:      	cmpl	%r15d, %r12d
   11b31:      	seta	%sil
   11b35:      	movl	%r15d, %ecx
   11b38:      	cmovbl	%r12d, %ecx
   11b3c:      	addl	%ecx, %esi
   11b3e:      	movl	%r12d, %edi
   11b41:      	subl	%esi, %edi
   11b43:      	movl	%edi, 0x50(%rsp)
   11b47:      	subq	%rsi, %rax
   11b4a:      	jb	0x16402 <generic_kprobe_path+0xba72>
   11b50:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11b56:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11b5c:      	cmpl	%r15d, %r12d
   11b5f:      	jbe	0x11b65 <generic_kprobe_path+0x71d5>
   11b61:      	movb	$0x2f, (%rbx,%rax)
   11b65:      	xorl	%edi, %edi
   11b67:      	cmpl	%r15d, %r12d
   11b6a:      	seta	%dil
   11b6e:      	movzbl	%cl, %esi
   11b71:      	addq	%rax, %rbx
   11b74:      	addq	%rbx, %rdi
   11b77:      	movl	$0x4, %eax
   11b7c:      	callq	*%rax
   11b7e:      	movq	%rbx, 0x48(%rsp)
   11b83:      	cmpl	%r15d, %r12d
   11b86:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11b8c:      	movq	0x8(%rsp), %r12
   11b91:      	movq	%r12, 0x30(%rsp)
   11b96:      	movq	0x38(%rsp), %rdx
   11b9b:      	movq	0x40(%rsp), %r15
   11ba0:      	jmp	0x11bf3 <generic_kprobe_path+0x7263>
   11ba2:      	leaq	0x10(%r15), %rdx
   11ba6:      	movl	$0x4, %eax
   11bab:      	movq	%rbp, %rdi
   11bae:      	movl	$0x8, %esi
   11bb3:      	callq	*%rax
   11bb5:      	movq	0x40(%rsp), %rax
   11bba:      	cmpq	(%rsp), %rax
   11bbe:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11bc4:      	addq	$0x18, %r15
   11bc8:      	movl	$0x4, %eax
   11bcd:      	leaq	0x30(%rsp), %rdi
   11bd2:      	movl	$0x8, %esi
   11bd7:      	movq	%r15, %rdx
   11bda:      	callq	*%rax
   11bdc:      	movq	(%rsp), %r15
   11be0:      	movq	%r15, 0x40(%rsp)
   11be5:      	leaq	0x20(%r15), %rdx
   11be9:      	movq	%rdx, 0x38(%rsp)
   11bee:      	movq	0x30(%rsp), %r12
   11bf3:      	cmpq	0x18(%rsp), %r12
   11bf8:      	jne	0x11c05 <generic_kprobe_path+0x7275>
   11bfa:      	cmpq	0x20(%rsp), %rdx
   11bff:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11c05:      	movl	$0x4, %eax
   11c0a:      	leaq	0x10(%rsp), %rdi
   11c0f:      	movl	$0x8, %esi
   11c14:      	callq	*%rax
   11c16:      	cmpq	0x10(%rsp), %r12
   11c1b:      	je	0x11d13 <generic_kprobe_path+0x7383>
   11c21:      	leaq	0x18(%r12), %rbx
   11c26:      	movl	$0x4, %eax
   11c2b:      	movq	%rbp, %rdi
   11c2e:      	movl	$0x8, %esi
   11c33:      	movq	%rbx, %rdx
   11c36:      	callq	*%rax
   11c38:      	cmpq	%r12, (%rsp)
   11c3c:      	je	0x11d13 <generic_kprobe_path+0x7383>
   11c42:      	movl	$0x4, %eax
   11c47:      	leaq	0x8(%rsp), %rdi
   11c4c:      	movl	$0x8, %esi
   11c51:      	movq	%rbx, %rdx
   11c54:      	callq	*%rax
   11c56:      	addq	$0x20, %r12
   11c5a:      	movl	$0x4, %eax
   11c5f:      	leaq	0x58(%rsp), %rdi
   11c64:      	movl	$0x10, %ecx
   11c69:      	movl	$0x10, %esi
   11c6e:      	movq	%r12, %rdx
   11c71:      	callq	*%rax
   11c73:      	movq	0x28(%rsp), %rbx
   11c78:      	movq	0x48(%rsp), %rax
   11c7d:      	movl	0x5c(%rsp), %r15d
   11c82:      	subq	%rbx, %rax
   11c85:      	movl	0x50(%rsp), %r12d
   11c8a:      	movl	%r15d, %edx
   11c8d:      	subl	%r12d, %edx
   11c90:      	movl	$0x0, %ecx
   11c95:      	cmovbl	%ecx, %edx
   11c98:      	addq	0x60(%rsp), %rdx
   11c9d:      	xorl	%esi, %esi
   11c9f:      	cmpl	%r15d, %r12d
   11ca2:      	seta	%sil
   11ca6:      	movl	%r15d, %ecx
   11ca9:      	cmovbl	%r12d, %ecx
   11cad:      	addl	%ecx, %esi
   11caf:      	movl	%r12d, %edi
   11cb2:      	subl	%esi, %edi
   11cb4:      	movl	%edi, 0x50(%rsp)
   11cb8:      	subq	%rsi, %rax
   11cbb:      	jb	0x16402 <generic_kprobe_path+0xba72>
   11cc1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11cc7:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11ccd:      	cmpl	%r15d, %r12d
   11cd0:      	jbe	0x11cd6 <generic_kprobe_path+0x7346>
   11cd2:      	movb	$0x2f, (%rbx,%rax)
   11cd6:      	xorl	%edi, %edi
   11cd8:      	cmpl	%r15d, %r12d
   11cdb:      	seta	%dil
   11cdf:      	movzbl	%cl, %esi
   11ce2:      	addq	%rax, %rbx
   11ce5:      	addq	%rbx, %rdi
   11ce8:      	movl	$0x4, %eax
   11ced:      	callq	*%rax
   11cef:      	movq	%rbx, 0x48(%rsp)
   11cf4:      	cmpl	%r15d, %r12d
   11cf7:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11cfd:      	movq	0x8(%rsp), %r12
   11d02:      	movq	%r12, 0x30(%rsp)
   11d07:      	movq	0x38(%rsp), %rdx
   11d0c:      	movq	0x40(%rsp), %r15
   11d11:      	jmp	0x11d64 <generic_kprobe_path+0x73d4>
   11d13:      	leaq	0x10(%r15), %rdx
   11d17:      	movl	$0x4, %eax
   11d1c:      	movq	%rbp, %rdi
   11d1f:      	movl	$0x8, %esi
   11d24:      	callq	*%rax
   11d26:      	movq	0x40(%rsp), %rax
   11d2b:      	cmpq	(%rsp), %rax
   11d2f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11d35:      	addq	$0x18, %r15
   11d39:      	movl	$0x4, %eax
   11d3e:      	leaq	0x30(%rsp), %rdi
   11d43:      	movl	$0x8, %esi
   11d48:      	movq	%r15, %rdx
   11d4b:      	callq	*%rax
   11d4d:      	movq	(%rsp), %r15
   11d51:      	movq	%r15, 0x40(%rsp)
   11d56:      	leaq	0x20(%r15), %rdx
   11d5a:      	movq	%rdx, 0x38(%rsp)
   11d5f:      	movq	0x30(%rsp), %r12
   11d64:      	cmpq	0x18(%rsp), %r12
   11d69:      	jne	0x11d76 <generic_kprobe_path+0x73e6>
   11d6b:      	cmpq	0x20(%rsp), %rdx
   11d70:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11d76:      	movl	$0x4, %eax
   11d7b:      	leaq	0x10(%rsp), %rdi
   11d80:      	movl	$0x8, %esi
   11d85:      	callq	*%rax
   11d87:      	cmpq	0x10(%rsp), %r12
   11d8c:      	je	0x11e84 <generic_kprobe_path+0x74f4>
   11d92:      	leaq	0x18(%r12), %rbx
   11d97:      	movl	$0x4, %eax
   11d9c:      	movq	%rbp, %rdi
   11d9f:      	movl	$0x8, %esi
   11da4:      	movq	%rbx, %rdx
   11da7:      	callq	*%rax
   11da9:      	cmpq	%r12, (%rsp)
   11dad:      	je	0x11e84 <generic_kprobe_path+0x74f4>
   11db3:      	movl	$0x4, %eax
   11db8:      	leaq	0x8(%rsp), %rdi
   11dbd:      	movl	$0x8, %esi
   11dc2:      	movq	%rbx, %rdx
   11dc5:      	callq	*%rax
   11dc7:      	addq	$0x20, %r12
   11dcb:      	movl	$0x4, %eax
   11dd0:      	leaq	0x58(%rsp), %rdi
   11dd5:      	movl	$0x10, %ecx
   11dda:      	movl	$0x10, %esi
   11ddf:      	movq	%r12, %rdx
   11de2:      	callq	*%rax
   11de4:      	movq	0x28(%rsp), %rbx
   11de9:      	movq	0x48(%rsp), %rax
   11dee:      	movl	0x5c(%rsp), %r15d
   11df3:      	subq	%rbx, %rax
   11df6:      	movl	0x50(%rsp), %r12d
   11dfb:      	movl	%r15d, %edx
   11dfe:      	subl	%r12d, %edx
   11e01:      	movl	$0x0, %ecx
   11e06:      	cmovbl	%ecx, %edx
   11e09:      	addq	0x60(%rsp), %rdx
   11e0e:      	xorl	%esi, %esi
   11e10:      	cmpl	%r15d, %r12d
   11e13:      	seta	%sil
   11e17:      	movl	%r15d, %ecx
   11e1a:      	cmovbl	%r12d, %ecx
   11e1e:      	addl	%ecx, %esi
   11e20:      	movl	%r12d, %edi
   11e23:      	subl	%esi, %edi
   11e25:      	movl	%edi, 0x50(%rsp)
   11e29:      	subq	%rsi, %rax
   11e2c:      	jb	0x16402 <generic_kprobe_path+0xba72>
   11e32:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11e38:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11e3e:      	cmpl	%r15d, %r12d
   11e41:      	jbe	0x11e47 <generic_kprobe_path+0x74b7>
   11e43:      	movb	$0x2f, (%rbx,%rax)
   11e47:      	xorl	%edi, %edi
   11e49:      	cmpl	%r15d, %r12d
   11e4c:      	seta	%dil
   11e50:      	movzbl	%cl, %esi
   11e53:      	addq	%rax, %rbx
   11e56:      	addq	%rbx, %rdi
   11e59:      	movl	$0x4, %eax
   11e5e:      	callq	*%rax
   11e60:      	movq	%rbx, 0x48(%rsp)
   11e65:      	cmpl	%r15d, %r12d
   11e68:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11e6e:      	movq	0x8(%rsp), %r12
   11e73:      	movq	%r12, 0x30(%rsp)
   11e78:      	movq	0x38(%rsp), %rdx
   11e7d:      	movq	0x40(%rsp), %r15
   11e82:      	jmp	0x11ed5 <generic_kprobe_path+0x7545>
   11e84:      	leaq	0x10(%r15), %rdx
   11e88:      	movl	$0x4, %eax
   11e8d:      	movq	%rbp, %rdi
   11e90:      	movl	$0x8, %esi
   11e95:      	callq	*%rax
   11e97:      	movq	0x40(%rsp), %rax
   11e9c:      	cmpq	(%rsp), %rax
   11ea0:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11ea6:      	addq	$0x18, %r15
   11eaa:      	movl	$0x4, %eax
   11eaf:      	leaq	0x30(%rsp), %rdi
   11eb4:      	movl	$0x8, %esi
   11eb9:      	movq	%r15, %rdx
   11ebc:      	callq	*%rax
   11ebe:      	movq	(%rsp), %r15
   11ec2:      	movq	%r15, 0x40(%rsp)
   11ec7:      	leaq	0x20(%r15), %rdx
   11ecb:      	movq	%rdx, 0x38(%rsp)
   11ed0:      	movq	0x30(%rsp), %r12
   11ed5:      	cmpq	0x18(%rsp), %r12
   11eda:      	jne	0x11ee7 <generic_kprobe_path+0x7557>
   11edc:      	cmpq	0x20(%rsp), %rdx
   11ee1:      	je	0x163fd <generic_kprobe_path+0xba6d>
   11ee7:      	movl	$0x4, %eax
   11eec:      	leaq	0x10(%rsp), %rdi
   11ef1:      	movl	$0x8, %esi
   11ef6:      	callq	*%rax
   11ef8:      	cmpq	0x10(%rsp), %r12
   11efd:      	je	0x11ff5 <generic_kprobe_path+0x7665>
   11f03:      	leaq	0x18(%r12), %rbx
   11f08:      	movl	$0x4, %eax
   11f0d:      	movq	%rbp, %rdi
   11f10:      	movl	$0x8, %esi
   11f15:      	movq	%rbx, %rdx
   11f18:      	callq	*%rax
   11f1a:      	cmpq	%r12, (%rsp)
   11f1e:      	je	0x11ff5 <generic_kprobe_path+0x7665>
   11f24:      	movl	$0x4, %eax
   11f29:      	leaq	0x8(%rsp), %rdi
   11f2e:      	movl	$0x8, %esi
   11f33:      	movq	%rbx, %rdx
   11f36:      	callq	*%rax
   11f38:      	addq	$0x20, %r12
   11f3c:      	movl	$0x4, %eax
   11f41:      	leaq	0x58(%rsp), %rdi
   11f46:      	movl	$0x10, %ecx
   11f4b:      	movl	$0x10, %esi
   11f50:      	movq	%r12, %rdx
   11f53:      	callq	*%rax
   11f55:      	movq	0x28(%rsp), %rbx
   11f5a:      	movq	0x48(%rsp), %rax
   11f5f:      	movl	0x5c(%rsp), %r15d
   11f64:      	subq	%rbx, %rax
   11f67:      	movl	0x50(%rsp), %r12d
   11f6c:      	movl	%r15d, %edx
   11f6f:      	subl	%r12d, %edx
   11f72:      	movl	$0x0, %ecx
   11f77:      	cmovbl	%ecx, %edx
   11f7a:      	addq	0x60(%rsp), %rdx
   11f7f:      	xorl	%esi, %esi
   11f81:      	cmpl	%r15d, %r12d
   11f84:      	seta	%sil
   11f88:      	movl	%r15d, %ecx
   11f8b:      	cmovbl	%r12d, %ecx
   11f8f:      	addl	%ecx, %esi
   11f91:      	movl	%r12d, %edi
   11f94:      	subl	%esi, %edi
   11f96:      	movl	%edi, 0x50(%rsp)
   11f9a:      	subq	%rsi, %rax
   11f9d:      	jb	0x16402 <generic_kprobe_path+0xba72>
   11fa3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11fa9:      	ja	0x16402 <generic_kprobe_path+0xba72>
   11faf:      	cmpl	%r15d, %r12d
   11fb2:      	jbe	0x11fb8 <generic_kprobe_path+0x7628>
   11fb4:      	movb	$0x2f, (%rbx,%rax)
   11fb8:      	xorl	%edi, %edi
   11fba:      	cmpl	%r15d, %r12d
   11fbd:      	seta	%dil
   11fc1:      	movzbl	%cl, %esi
   11fc4:      	addq	%rax, %rbx
   11fc7:      	addq	%rbx, %rdi
   11fca:      	movl	$0x4, %eax
   11fcf:      	callq	*%rax
   11fd1:      	movq	%rbx, 0x48(%rsp)
   11fd6:      	cmpl	%r15d, %r12d
   11fd9:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   11fdf:      	movq	0x8(%rsp), %r12
   11fe4:      	movq	%r12, 0x30(%rsp)
   11fe9:      	movq	0x38(%rsp), %rdx
   11fee:      	movq	0x40(%rsp), %r15
   11ff3:      	jmp	0x12046 <generic_kprobe_path+0x76b6>
   11ff5:      	leaq	0x10(%r15), %rdx
   11ff9:      	movl	$0x4, %eax
   11ffe:      	movq	%rbp, %rdi
   12001:      	movl	$0x8, %esi
   12006:      	callq	*%rax
   12008:      	movq	0x40(%rsp), %rax
   1200d:      	cmpq	(%rsp), %rax
   12011:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12017:      	addq	$0x18, %r15
   1201b:      	movl	$0x4, %eax
   12020:      	leaq	0x30(%rsp), %rdi
   12025:      	movl	$0x8, %esi
   1202a:      	movq	%r15, %rdx
   1202d:      	callq	*%rax
   1202f:      	movq	(%rsp), %r15
   12033:      	movq	%r15, 0x40(%rsp)
   12038:      	leaq	0x20(%r15), %rdx
   1203c:      	movq	%rdx, 0x38(%rsp)
   12041:      	movq	0x30(%rsp), %r12
   12046:      	cmpq	0x18(%rsp), %r12
   1204b:      	jne	0x12058 <generic_kprobe_path+0x76c8>
   1204d:      	cmpq	0x20(%rsp), %rdx
   12052:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12058:      	movl	$0x4, %eax
   1205d:      	leaq	0x10(%rsp), %rdi
   12062:      	movl	$0x8, %esi
   12067:      	callq	*%rax
   12069:      	cmpq	0x10(%rsp), %r12
   1206e:      	je	0x12166 <generic_kprobe_path+0x77d6>
   12074:      	leaq	0x18(%r12), %rbx
   12079:      	movl	$0x4, %eax
   1207e:      	movq	%rbp, %rdi
   12081:      	movl	$0x8, %esi
   12086:      	movq	%rbx, %rdx
   12089:      	callq	*%rax
   1208b:      	cmpq	%r12, (%rsp)
   1208f:      	je	0x12166 <generic_kprobe_path+0x77d6>
   12095:      	movl	$0x4, %eax
   1209a:      	leaq	0x8(%rsp), %rdi
   1209f:      	movl	$0x8, %esi
   120a4:      	movq	%rbx, %rdx
   120a7:      	callq	*%rax
   120a9:      	addq	$0x20, %r12
   120ad:      	movl	$0x4, %eax
   120b2:      	leaq	0x58(%rsp), %rdi
   120b7:      	movl	$0x10, %ecx
   120bc:      	movl	$0x10, %esi
   120c1:      	movq	%r12, %rdx
   120c4:      	callq	*%rax
   120c6:      	movq	0x28(%rsp), %rbx
   120cb:      	movq	0x48(%rsp), %rax
   120d0:      	movl	0x5c(%rsp), %r15d
   120d5:      	subq	%rbx, %rax
   120d8:      	movl	0x50(%rsp), %r12d
   120dd:      	movl	%r15d, %edx
   120e0:      	subl	%r12d, %edx
   120e3:      	movl	$0x0, %ecx
   120e8:      	cmovbl	%ecx, %edx
   120eb:      	addq	0x60(%rsp), %rdx
   120f0:      	xorl	%esi, %esi
   120f2:      	cmpl	%r15d, %r12d
   120f5:      	seta	%sil
   120f9:      	movl	%r15d, %ecx
   120fc:      	cmovbl	%r12d, %ecx
   12100:      	addl	%ecx, %esi
   12102:      	movl	%r12d, %edi
   12105:      	subl	%esi, %edi
   12107:      	movl	%edi, 0x50(%rsp)
   1210b:      	subq	%rsi, %rax
   1210e:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12114:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1211a:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12120:      	cmpl	%r15d, %r12d
   12123:      	jbe	0x12129 <generic_kprobe_path+0x7799>
   12125:      	movb	$0x2f, (%rbx,%rax)
   12129:      	xorl	%edi, %edi
   1212b:      	cmpl	%r15d, %r12d
   1212e:      	seta	%dil
   12132:      	movzbl	%cl, %esi
   12135:      	addq	%rax, %rbx
   12138:      	addq	%rbx, %rdi
   1213b:      	movl	$0x4, %eax
   12140:      	callq	*%rax
   12142:      	movq	%rbx, 0x48(%rsp)
   12147:      	cmpl	%r15d, %r12d
   1214a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12150:      	movq	0x8(%rsp), %r12
   12155:      	movq	%r12, 0x30(%rsp)
   1215a:      	movq	0x38(%rsp), %rdx
   1215f:      	movq	0x40(%rsp), %r15
   12164:      	jmp	0x121b7 <generic_kprobe_path+0x7827>
   12166:      	leaq	0x10(%r15), %rdx
   1216a:      	movl	$0x4, %eax
   1216f:      	movq	%rbp, %rdi
   12172:      	movl	$0x8, %esi
   12177:      	callq	*%rax
   12179:      	movq	0x40(%rsp), %rax
   1217e:      	cmpq	(%rsp), %rax
   12182:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12188:      	addq	$0x18, %r15
   1218c:      	movl	$0x4, %eax
   12191:      	leaq	0x30(%rsp), %rdi
   12196:      	movl	$0x8, %esi
   1219b:      	movq	%r15, %rdx
   1219e:      	callq	*%rax
   121a0:      	movq	(%rsp), %r15
   121a4:      	movq	%r15, 0x40(%rsp)
   121a9:      	leaq	0x20(%r15), %rdx
   121ad:      	movq	%rdx, 0x38(%rsp)
   121b2:      	movq	0x30(%rsp), %r12
   121b7:      	cmpq	0x18(%rsp), %r12
   121bc:      	jne	0x121c9 <generic_kprobe_path+0x7839>
   121be:      	cmpq	0x20(%rsp), %rdx
   121c3:      	je	0x163fd <generic_kprobe_path+0xba6d>
   121c9:      	movl	$0x4, %eax
   121ce:      	leaq	0x10(%rsp), %rdi
   121d3:      	movl	$0x8, %esi
   121d8:      	callq	*%rax
   121da:      	cmpq	0x10(%rsp), %r12
   121df:      	je	0x122d7 <generic_kprobe_path+0x7947>
   121e5:      	leaq	0x18(%r12), %rbx
   121ea:      	movl	$0x4, %eax
   121ef:      	movq	%rbp, %rdi
   121f2:      	movl	$0x8, %esi
   121f7:      	movq	%rbx, %rdx
   121fa:      	callq	*%rax
   121fc:      	cmpq	%r12, (%rsp)
   12200:      	je	0x122d7 <generic_kprobe_path+0x7947>
   12206:      	movl	$0x4, %eax
   1220b:      	leaq	0x8(%rsp), %rdi
   12210:      	movl	$0x8, %esi
   12215:      	movq	%rbx, %rdx
   12218:      	callq	*%rax
   1221a:      	addq	$0x20, %r12
   1221e:      	movl	$0x4, %eax
   12223:      	leaq	0x58(%rsp), %rdi
   12228:      	movl	$0x10, %ecx
   1222d:      	movl	$0x10, %esi
   12232:      	movq	%r12, %rdx
   12235:      	callq	*%rax
   12237:      	movq	0x28(%rsp), %rbx
   1223c:      	movq	0x48(%rsp), %rax
   12241:      	movl	0x5c(%rsp), %r15d
   12246:      	subq	%rbx, %rax
   12249:      	movl	0x50(%rsp), %r12d
   1224e:      	movl	%r15d, %edx
   12251:      	subl	%r12d, %edx
   12254:      	movl	$0x0, %ecx
   12259:      	cmovbl	%ecx, %edx
   1225c:      	addq	0x60(%rsp), %rdx
   12261:      	xorl	%esi, %esi
   12263:      	cmpl	%r15d, %r12d
   12266:      	seta	%sil
   1226a:      	movl	%r15d, %ecx
   1226d:      	cmovbl	%r12d, %ecx
   12271:      	addl	%ecx, %esi
   12273:      	movl	%r12d, %edi
   12276:      	subl	%esi, %edi
   12278:      	movl	%edi, 0x50(%rsp)
   1227c:      	subq	%rsi, %rax
   1227f:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12285:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1228b:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12291:      	cmpl	%r15d, %r12d
   12294:      	jbe	0x1229a <generic_kprobe_path+0x790a>
   12296:      	movb	$0x2f, (%rbx,%rax)
   1229a:      	xorl	%edi, %edi
   1229c:      	cmpl	%r15d, %r12d
   1229f:      	seta	%dil
   122a3:      	movzbl	%cl, %esi
   122a6:      	addq	%rax, %rbx
   122a9:      	addq	%rbx, %rdi
   122ac:      	movl	$0x4, %eax
   122b1:      	callq	*%rax
   122b3:      	movq	%rbx, 0x48(%rsp)
   122b8:      	cmpl	%r15d, %r12d
   122bb:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   122c1:      	movq	0x8(%rsp), %r12
   122c6:      	movq	%r12, 0x30(%rsp)
   122cb:      	movq	0x38(%rsp), %rdx
   122d0:      	movq	0x40(%rsp), %r15
   122d5:      	jmp	0x12328 <generic_kprobe_path+0x7998>
   122d7:      	leaq	0x10(%r15), %rdx
   122db:      	movl	$0x4, %eax
   122e0:      	movq	%rbp, %rdi
   122e3:      	movl	$0x8, %esi
   122e8:      	callq	*%rax
   122ea:      	movq	0x40(%rsp), %rax
   122ef:      	cmpq	(%rsp), %rax
   122f3:      	je	0x163fd <generic_kprobe_path+0xba6d>
   122f9:      	addq	$0x18, %r15
   122fd:      	movl	$0x4, %eax
   12302:      	leaq	0x30(%rsp), %rdi
   12307:      	movl	$0x8, %esi
   1230c:      	movq	%r15, %rdx
   1230f:      	callq	*%rax
   12311:      	movq	(%rsp), %r15
   12315:      	movq	%r15, 0x40(%rsp)
   1231a:      	leaq	0x20(%r15), %rdx
   1231e:      	movq	%rdx, 0x38(%rsp)
   12323:      	movq	0x30(%rsp), %r12
   12328:      	cmpq	0x18(%rsp), %r12
   1232d:      	jne	0x1233a <generic_kprobe_path+0x79aa>
   1232f:      	cmpq	0x20(%rsp), %rdx
   12334:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1233a:      	movl	$0x4, %eax
   1233f:      	leaq	0x10(%rsp), %rdi
   12344:      	movl	$0x8, %esi
   12349:      	callq	*%rax
   1234b:      	cmpq	0x10(%rsp), %r12
   12350:      	je	0x12448 <generic_kprobe_path+0x7ab8>
   12356:      	leaq	0x18(%r12), %rbx
   1235b:      	movl	$0x4, %eax
   12360:      	movq	%rbp, %rdi
   12363:      	movl	$0x8, %esi
   12368:      	movq	%rbx, %rdx
   1236b:      	callq	*%rax
   1236d:      	cmpq	%r12, (%rsp)
   12371:      	je	0x12448 <generic_kprobe_path+0x7ab8>
   12377:      	movl	$0x4, %eax
   1237c:      	leaq	0x8(%rsp), %rdi
   12381:      	movl	$0x8, %esi
   12386:      	movq	%rbx, %rdx
   12389:      	callq	*%rax
   1238b:      	addq	$0x20, %r12
   1238f:      	movl	$0x4, %eax
   12394:      	leaq	0x58(%rsp), %rdi
   12399:      	movl	$0x10, %ecx
   1239e:      	movl	$0x10, %esi
   123a3:      	movq	%r12, %rdx
   123a6:      	callq	*%rax
   123a8:      	movq	0x28(%rsp), %rbx
   123ad:      	movq	0x48(%rsp), %rax
   123b2:      	movl	0x5c(%rsp), %r15d
   123b7:      	subq	%rbx, %rax
   123ba:      	movl	0x50(%rsp), %r12d
   123bf:      	movl	%r15d, %edx
   123c2:      	subl	%r12d, %edx
   123c5:      	movl	$0x0, %ecx
   123ca:      	cmovbl	%ecx, %edx
   123cd:      	addq	0x60(%rsp), %rdx
   123d2:      	xorl	%esi, %esi
   123d4:      	cmpl	%r15d, %r12d
   123d7:      	seta	%sil
   123db:      	movl	%r15d, %ecx
   123de:      	cmovbl	%r12d, %ecx
   123e2:      	addl	%ecx, %esi
   123e4:      	movl	%r12d, %edi
   123e7:      	subl	%esi, %edi
   123e9:      	movl	%edi, 0x50(%rsp)
   123ed:      	subq	%rsi, %rax
   123f0:      	jb	0x16402 <generic_kprobe_path+0xba72>
   123f6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   123fc:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12402:      	cmpl	%r15d, %r12d
   12405:      	jbe	0x1240b <generic_kprobe_path+0x7a7b>
   12407:      	movb	$0x2f, (%rbx,%rax)
   1240b:      	xorl	%edi, %edi
   1240d:      	cmpl	%r15d, %r12d
   12410:      	seta	%dil
   12414:      	movzbl	%cl, %esi
   12417:      	addq	%rax, %rbx
   1241a:      	addq	%rbx, %rdi
   1241d:      	movl	$0x4, %eax
   12422:      	callq	*%rax
   12424:      	movq	%rbx, 0x48(%rsp)
   12429:      	cmpl	%r15d, %r12d
   1242c:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12432:      	movq	0x8(%rsp), %r12
   12437:      	movq	%r12, 0x30(%rsp)
   1243c:      	movq	0x38(%rsp), %rdx
   12441:      	movq	0x40(%rsp), %r15
   12446:      	jmp	0x12499 <generic_kprobe_path+0x7b09>
   12448:      	leaq	0x10(%r15), %rdx
   1244c:      	movl	$0x4, %eax
   12451:      	movq	%rbp, %rdi
   12454:      	movl	$0x8, %esi
   12459:      	callq	*%rax
   1245b:      	movq	0x40(%rsp), %rax
   12460:      	cmpq	(%rsp), %rax
   12464:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1246a:      	addq	$0x18, %r15
   1246e:      	movl	$0x4, %eax
   12473:      	leaq	0x30(%rsp), %rdi
   12478:      	movl	$0x8, %esi
   1247d:      	movq	%r15, %rdx
   12480:      	callq	*%rax
   12482:      	movq	(%rsp), %r15
   12486:      	movq	%r15, 0x40(%rsp)
   1248b:      	leaq	0x20(%r15), %rdx
   1248f:      	movq	%rdx, 0x38(%rsp)
   12494:      	movq	0x30(%rsp), %r12
   12499:      	cmpq	0x18(%rsp), %r12
   1249e:      	jne	0x124ab <generic_kprobe_path+0x7b1b>
   124a0:      	cmpq	0x20(%rsp), %rdx
   124a5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   124ab:      	movl	$0x4, %eax
   124b0:      	leaq	0x10(%rsp), %rdi
   124b5:      	movl	$0x8, %esi
   124ba:      	callq	*%rax
   124bc:      	cmpq	0x10(%rsp), %r12
   124c1:      	je	0x125b9 <generic_kprobe_path+0x7c29>
   124c7:      	leaq	0x18(%r12), %rbx
   124cc:      	movl	$0x4, %eax
   124d1:      	movq	%rbp, %rdi
   124d4:      	movl	$0x8, %esi
   124d9:      	movq	%rbx, %rdx
   124dc:      	callq	*%rax
   124de:      	cmpq	%r12, (%rsp)
   124e2:      	je	0x125b9 <generic_kprobe_path+0x7c29>
   124e8:      	movl	$0x4, %eax
   124ed:      	leaq	0x8(%rsp), %rdi
   124f2:      	movl	$0x8, %esi
   124f7:      	movq	%rbx, %rdx
   124fa:      	callq	*%rax
   124fc:      	addq	$0x20, %r12
   12500:      	movl	$0x4, %eax
   12505:      	leaq	0x58(%rsp), %rdi
   1250a:      	movl	$0x10, %ecx
   1250f:      	movl	$0x10, %esi
   12514:      	movq	%r12, %rdx
   12517:      	callq	*%rax
   12519:      	movq	0x28(%rsp), %rbx
   1251e:      	movq	0x48(%rsp), %rax
   12523:      	movl	0x5c(%rsp), %r15d
   12528:      	subq	%rbx, %rax
   1252b:      	movl	0x50(%rsp), %r12d
   12530:      	movl	%r15d, %edx
   12533:      	subl	%r12d, %edx
   12536:      	movl	$0x0, %ecx
   1253b:      	cmovbl	%ecx, %edx
   1253e:      	addq	0x60(%rsp), %rdx
   12543:      	xorl	%esi, %esi
   12545:      	cmpl	%r15d, %r12d
   12548:      	seta	%sil
   1254c:      	movl	%r15d, %ecx
   1254f:      	cmovbl	%r12d, %ecx
   12553:      	addl	%ecx, %esi
   12555:      	movl	%r12d, %edi
   12558:      	subl	%esi, %edi
   1255a:      	movl	%edi, 0x50(%rsp)
   1255e:      	subq	%rsi, %rax
   12561:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12567:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1256d:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12573:      	cmpl	%r15d, %r12d
   12576:      	jbe	0x1257c <generic_kprobe_path+0x7bec>
   12578:      	movb	$0x2f, (%rbx,%rax)
   1257c:      	xorl	%edi, %edi
   1257e:      	cmpl	%r15d, %r12d
   12581:      	seta	%dil
   12585:      	movzbl	%cl, %esi
   12588:      	addq	%rax, %rbx
   1258b:      	addq	%rbx, %rdi
   1258e:      	movl	$0x4, %eax
   12593:      	callq	*%rax
   12595:      	movq	%rbx, 0x48(%rsp)
   1259a:      	cmpl	%r15d, %r12d
   1259d:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   125a3:      	movq	0x8(%rsp), %r12
   125a8:      	movq	%r12, 0x30(%rsp)
   125ad:      	movq	0x38(%rsp), %rdx
   125b2:      	movq	0x40(%rsp), %r15
   125b7:      	jmp	0x1260a <generic_kprobe_path+0x7c7a>
   125b9:      	leaq	0x10(%r15), %rdx
   125bd:      	movl	$0x4, %eax
   125c2:      	movq	%rbp, %rdi
   125c5:      	movl	$0x8, %esi
   125ca:      	callq	*%rax
   125cc:      	movq	0x40(%rsp), %rax
   125d1:      	cmpq	(%rsp), %rax
   125d5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   125db:      	addq	$0x18, %r15
   125df:      	movl	$0x4, %eax
   125e4:      	leaq	0x30(%rsp), %rdi
   125e9:      	movl	$0x8, %esi
   125ee:      	movq	%r15, %rdx
   125f1:      	callq	*%rax
   125f3:      	movq	(%rsp), %r15
   125f7:      	movq	%r15, 0x40(%rsp)
   125fc:      	leaq	0x20(%r15), %rdx
   12600:      	movq	%rdx, 0x38(%rsp)
   12605:      	movq	0x30(%rsp), %r12
   1260a:      	cmpq	0x18(%rsp), %r12
   1260f:      	jne	0x1261c <generic_kprobe_path+0x7c8c>
   12611:      	cmpq	0x20(%rsp), %rdx
   12616:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1261c:      	movl	$0x4, %eax
   12621:      	leaq	0x10(%rsp), %rdi
   12626:      	movl	$0x8, %esi
   1262b:      	callq	*%rax
   1262d:      	cmpq	0x10(%rsp), %r12
   12632:      	je	0x1272a <generic_kprobe_path+0x7d9a>
   12638:      	leaq	0x18(%r12), %rbx
   1263d:      	movl	$0x4, %eax
   12642:      	movq	%rbp, %rdi
   12645:      	movl	$0x8, %esi
   1264a:      	movq	%rbx, %rdx
   1264d:      	callq	*%rax
   1264f:      	cmpq	%r12, (%rsp)
   12653:      	je	0x1272a <generic_kprobe_path+0x7d9a>
   12659:      	movl	$0x4, %eax
   1265e:      	leaq	0x8(%rsp), %rdi
   12663:      	movl	$0x8, %esi
   12668:      	movq	%rbx, %rdx
   1266b:      	callq	*%rax
   1266d:      	addq	$0x20, %r12
   12671:      	movl	$0x4, %eax
   12676:      	leaq	0x58(%rsp), %rdi
   1267b:      	movl	$0x10, %ecx
   12680:      	movl	$0x10, %esi
   12685:      	movq	%r12, %rdx
   12688:      	callq	*%rax
   1268a:      	movq	0x28(%rsp), %rbx
   1268f:      	movq	0x48(%rsp), %rax
   12694:      	movl	0x5c(%rsp), %r15d
   12699:      	subq	%rbx, %rax
   1269c:      	movl	0x50(%rsp), %r12d
   126a1:      	movl	%r15d, %edx
   126a4:      	subl	%r12d, %edx
   126a7:      	movl	$0x0, %ecx
   126ac:      	cmovbl	%ecx, %edx
   126af:      	addq	0x60(%rsp), %rdx
   126b4:      	xorl	%esi, %esi
   126b6:      	cmpl	%r15d, %r12d
   126b9:      	seta	%sil
   126bd:      	movl	%r15d, %ecx
   126c0:      	cmovbl	%r12d, %ecx
   126c4:      	addl	%ecx, %esi
   126c6:      	movl	%r12d, %edi
   126c9:      	subl	%esi, %edi
   126cb:      	movl	%edi, 0x50(%rsp)
   126cf:      	subq	%rsi, %rax
   126d2:      	jb	0x16402 <generic_kprobe_path+0xba72>
   126d8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   126de:      	ja	0x16402 <generic_kprobe_path+0xba72>
   126e4:      	cmpl	%r15d, %r12d
   126e7:      	jbe	0x126ed <generic_kprobe_path+0x7d5d>
   126e9:      	movb	$0x2f, (%rbx,%rax)
   126ed:      	xorl	%edi, %edi
   126ef:      	cmpl	%r15d, %r12d
   126f2:      	seta	%dil
   126f6:      	movzbl	%cl, %esi
   126f9:      	addq	%rax, %rbx
   126fc:      	addq	%rbx, %rdi
   126ff:      	movl	$0x4, %eax
   12704:      	callq	*%rax
   12706:      	movq	%rbx, 0x48(%rsp)
   1270b:      	cmpl	%r15d, %r12d
   1270e:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12714:      	movq	0x8(%rsp), %r12
   12719:      	movq	%r12, 0x30(%rsp)
   1271e:      	movq	0x38(%rsp), %rdx
   12723:      	movq	0x40(%rsp), %r15
   12728:      	jmp	0x1277b <generic_kprobe_path+0x7deb>
   1272a:      	leaq	0x10(%r15), %rdx
   1272e:      	movl	$0x4, %eax
   12733:      	movq	%rbp, %rdi
   12736:      	movl	$0x8, %esi
   1273b:      	callq	*%rax
   1273d:      	movq	0x40(%rsp), %rax
   12742:      	cmpq	(%rsp), %rax
   12746:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1274c:      	addq	$0x18, %r15
   12750:      	movl	$0x4, %eax
   12755:      	leaq	0x30(%rsp), %rdi
   1275a:      	movl	$0x8, %esi
   1275f:      	movq	%r15, %rdx
   12762:      	callq	*%rax
   12764:      	movq	(%rsp), %r15
   12768:      	movq	%r15, 0x40(%rsp)
   1276d:      	leaq	0x20(%r15), %rdx
   12771:      	movq	%rdx, 0x38(%rsp)
   12776:      	movq	0x30(%rsp), %r12
   1277b:      	cmpq	0x18(%rsp), %r12
   12780:      	jne	0x1278d <generic_kprobe_path+0x7dfd>
   12782:      	cmpq	0x20(%rsp), %rdx
   12787:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1278d:      	movl	$0x4, %eax
   12792:      	leaq	0x10(%rsp), %rdi
   12797:      	movl	$0x8, %esi
   1279c:      	callq	*%rax
   1279e:      	cmpq	0x10(%rsp), %r12
   127a3:      	je	0x1289b <generic_kprobe_path+0x7f0b>
   127a9:      	leaq	0x18(%r12), %rbx
   127ae:      	movl	$0x4, %eax
   127b3:      	movq	%rbp, %rdi
   127b6:      	movl	$0x8, %esi
   127bb:      	movq	%rbx, %rdx
   127be:      	callq	*%rax
   127c0:      	cmpq	%r12, (%rsp)
   127c4:      	je	0x1289b <generic_kprobe_path+0x7f0b>
   127ca:      	movl	$0x4, %eax
   127cf:      	leaq	0x8(%rsp), %rdi
   127d4:      	movl	$0x8, %esi
   127d9:      	movq	%rbx, %rdx
   127dc:      	callq	*%rax
   127de:      	addq	$0x20, %r12
   127e2:      	movl	$0x4, %eax
   127e7:      	leaq	0x58(%rsp), %rdi
   127ec:      	movl	$0x10, %ecx
   127f1:      	movl	$0x10, %esi
   127f6:      	movq	%r12, %rdx
   127f9:      	callq	*%rax
   127fb:      	movq	0x28(%rsp), %rbx
   12800:      	movq	0x48(%rsp), %rax
   12805:      	movl	0x5c(%rsp), %r15d
   1280a:      	subq	%rbx, %rax
   1280d:      	movl	0x50(%rsp), %r12d
   12812:      	movl	%r15d, %edx
   12815:      	subl	%r12d, %edx
   12818:      	movl	$0x0, %ecx
   1281d:      	cmovbl	%ecx, %edx
   12820:      	addq	0x60(%rsp), %rdx
   12825:      	xorl	%esi, %esi
   12827:      	cmpl	%r15d, %r12d
   1282a:      	seta	%sil
   1282e:      	movl	%r15d, %ecx
   12831:      	cmovbl	%r12d, %ecx
   12835:      	addl	%ecx, %esi
   12837:      	movl	%r12d, %edi
   1283a:      	subl	%esi, %edi
   1283c:      	movl	%edi, 0x50(%rsp)
   12840:      	subq	%rsi, %rax
   12843:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12849:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1284f:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12855:      	cmpl	%r15d, %r12d
   12858:      	jbe	0x1285e <generic_kprobe_path+0x7ece>
   1285a:      	movb	$0x2f, (%rbx,%rax)
   1285e:      	xorl	%edi, %edi
   12860:      	cmpl	%r15d, %r12d
   12863:      	seta	%dil
   12867:      	movzbl	%cl, %esi
   1286a:      	addq	%rax, %rbx
   1286d:      	addq	%rbx, %rdi
   12870:      	movl	$0x4, %eax
   12875:      	callq	*%rax
   12877:      	movq	%rbx, 0x48(%rsp)
   1287c:      	cmpl	%r15d, %r12d
   1287f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12885:      	movq	0x8(%rsp), %r12
   1288a:      	movq	%r12, 0x30(%rsp)
   1288f:      	movq	0x38(%rsp), %rdx
   12894:      	movq	0x40(%rsp), %r15
   12899:      	jmp	0x128ec <generic_kprobe_path+0x7f5c>
   1289b:      	leaq	0x10(%r15), %rdx
   1289f:      	movl	$0x4, %eax
   128a4:      	movq	%rbp, %rdi
   128a7:      	movl	$0x8, %esi
   128ac:      	callq	*%rax
   128ae:      	movq	0x40(%rsp), %rax
   128b3:      	cmpq	(%rsp), %rax
   128b7:      	je	0x163fd <generic_kprobe_path+0xba6d>
   128bd:      	addq	$0x18, %r15
   128c1:      	movl	$0x4, %eax
   128c6:      	leaq	0x30(%rsp), %rdi
   128cb:      	movl	$0x8, %esi
   128d0:      	movq	%r15, %rdx
   128d3:      	callq	*%rax
   128d5:      	movq	(%rsp), %r15
   128d9:      	movq	%r15, 0x40(%rsp)
   128de:      	leaq	0x20(%r15), %rdx
   128e2:      	movq	%rdx, 0x38(%rsp)
   128e7:      	movq	0x30(%rsp), %r12
   128ec:      	cmpq	0x18(%rsp), %r12
   128f1:      	jne	0x128fe <generic_kprobe_path+0x7f6e>
   128f3:      	cmpq	0x20(%rsp), %rdx
   128f8:      	je	0x163fd <generic_kprobe_path+0xba6d>
   128fe:      	movl	$0x4, %eax
   12903:      	leaq	0x10(%rsp), %rdi
   12908:      	movl	$0x8, %esi
   1290d:      	callq	*%rax
   1290f:      	cmpq	0x10(%rsp), %r12
   12914:      	je	0x12a0c <generic_kprobe_path+0x807c>
   1291a:      	leaq	0x18(%r12), %rbx
   1291f:      	movl	$0x4, %eax
   12924:      	movq	%rbp, %rdi
   12927:      	movl	$0x8, %esi
   1292c:      	movq	%rbx, %rdx
   1292f:      	callq	*%rax
   12931:      	cmpq	%r12, (%rsp)
   12935:      	je	0x12a0c <generic_kprobe_path+0x807c>
   1293b:      	movl	$0x4, %eax
   12940:      	leaq	0x8(%rsp), %rdi
   12945:      	movl	$0x8, %esi
   1294a:      	movq	%rbx, %rdx
   1294d:      	callq	*%rax
   1294f:      	addq	$0x20, %r12
   12953:      	movl	$0x4, %eax
   12958:      	leaq	0x58(%rsp), %rdi
   1295d:      	movl	$0x10, %ecx
   12962:      	movl	$0x10, %esi
   12967:      	movq	%r12, %rdx
   1296a:      	callq	*%rax
   1296c:      	movq	0x28(%rsp), %rbx
   12971:      	movq	0x48(%rsp), %rax
   12976:      	movl	0x5c(%rsp), %r15d
   1297b:      	subq	%rbx, %rax
   1297e:      	movl	0x50(%rsp), %r12d
   12983:      	movl	%r15d, %edx
   12986:      	subl	%r12d, %edx
   12989:      	movl	$0x0, %ecx
   1298e:      	cmovbl	%ecx, %edx
   12991:      	addq	0x60(%rsp), %rdx
   12996:      	xorl	%esi, %esi
   12998:      	cmpl	%r15d, %r12d
   1299b:      	seta	%sil
   1299f:      	movl	%r15d, %ecx
   129a2:      	cmovbl	%r12d, %ecx
   129a6:      	addl	%ecx, %esi
   129a8:      	movl	%r12d, %edi
   129ab:      	subl	%esi, %edi
   129ad:      	movl	%edi, 0x50(%rsp)
   129b1:      	subq	%rsi, %rax
   129b4:      	jb	0x16402 <generic_kprobe_path+0xba72>
   129ba:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   129c0:      	ja	0x16402 <generic_kprobe_path+0xba72>
   129c6:      	cmpl	%r15d, %r12d
   129c9:      	jbe	0x129cf <generic_kprobe_path+0x803f>
   129cb:      	movb	$0x2f, (%rbx,%rax)
   129cf:      	xorl	%edi, %edi
   129d1:      	cmpl	%r15d, %r12d
   129d4:      	seta	%dil
   129d8:      	movzbl	%cl, %esi
   129db:      	addq	%rax, %rbx
   129de:      	addq	%rbx, %rdi
   129e1:      	movl	$0x4, %eax
   129e6:      	callq	*%rax
   129e8:      	movq	%rbx, 0x48(%rsp)
   129ed:      	cmpl	%r15d, %r12d
   129f0:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   129f6:      	movq	0x8(%rsp), %r12
   129fb:      	movq	%r12, 0x30(%rsp)
   12a00:      	movq	0x38(%rsp), %rdx
   12a05:      	movq	0x40(%rsp), %r15
   12a0a:      	jmp	0x12a5d <generic_kprobe_path+0x80cd>
   12a0c:      	leaq	0x10(%r15), %rdx
   12a10:      	movl	$0x4, %eax
   12a15:      	movq	%rbp, %rdi
   12a18:      	movl	$0x8, %esi
   12a1d:      	callq	*%rax
   12a1f:      	movq	0x40(%rsp), %rax
   12a24:      	cmpq	(%rsp), %rax
   12a28:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12a2e:      	addq	$0x18, %r15
   12a32:      	movl	$0x4, %eax
   12a37:      	leaq	0x30(%rsp), %rdi
   12a3c:      	movl	$0x8, %esi
   12a41:      	movq	%r15, %rdx
   12a44:      	callq	*%rax
   12a46:      	movq	(%rsp), %r15
   12a4a:      	movq	%r15, 0x40(%rsp)
   12a4f:      	leaq	0x20(%r15), %rdx
   12a53:      	movq	%rdx, 0x38(%rsp)
   12a58:      	movq	0x30(%rsp), %r12
   12a5d:      	cmpq	0x18(%rsp), %r12
   12a62:      	jne	0x12a6f <generic_kprobe_path+0x80df>
   12a64:      	cmpq	0x20(%rsp), %rdx
   12a69:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12a6f:      	movl	$0x4, %eax
   12a74:      	leaq	0x10(%rsp), %rdi
   12a79:      	movl	$0x8, %esi
   12a7e:      	callq	*%rax
   12a80:      	cmpq	0x10(%rsp), %r12
   12a85:      	je	0x12b7d <generic_kprobe_path+0x81ed>
   12a8b:      	leaq	0x18(%r12), %rbx
   12a90:      	movl	$0x4, %eax
   12a95:      	movq	%rbp, %rdi
   12a98:      	movl	$0x8, %esi
   12a9d:      	movq	%rbx, %rdx
   12aa0:      	callq	*%rax
   12aa2:      	cmpq	%r12, (%rsp)
   12aa6:      	je	0x12b7d <generic_kprobe_path+0x81ed>
   12aac:      	movl	$0x4, %eax
   12ab1:      	leaq	0x8(%rsp), %rdi
   12ab6:      	movl	$0x8, %esi
   12abb:      	movq	%rbx, %rdx
   12abe:      	callq	*%rax
   12ac0:      	addq	$0x20, %r12
   12ac4:      	movl	$0x4, %eax
   12ac9:      	leaq	0x58(%rsp), %rdi
   12ace:      	movl	$0x10, %ecx
   12ad3:      	movl	$0x10, %esi
   12ad8:      	movq	%r12, %rdx
   12adb:      	callq	*%rax
   12add:      	movq	0x28(%rsp), %rbx
   12ae2:      	movq	0x48(%rsp), %rax
   12ae7:      	movl	0x5c(%rsp), %r15d
   12aec:      	subq	%rbx, %rax
   12aef:      	movl	0x50(%rsp), %r12d
   12af4:      	movl	%r15d, %edx
   12af7:      	subl	%r12d, %edx
   12afa:      	movl	$0x0, %ecx
   12aff:      	cmovbl	%ecx, %edx
   12b02:      	addq	0x60(%rsp), %rdx
   12b07:      	xorl	%esi, %esi
   12b09:      	cmpl	%r15d, %r12d
   12b0c:      	seta	%sil
   12b10:      	movl	%r15d, %ecx
   12b13:      	cmovbl	%r12d, %ecx
   12b17:      	addl	%ecx, %esi
   12b19:      	movl	%r12d, %edi
   12b1c:      	subl	%esi, %edi
   12b1e:      	movl	%edi, 0x50(%rsp)
   12b22:      	subq	%rsi, %rax
   12b25:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12b2b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12b31:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12b37:      	cmpl	%r15d, %r12d
   12b3a:      	jbe	0x12b40 <generic_kprobe_path+0x81b0>
   12b3c:      	movb	$0x2f, (%rbx,%rax)
   12b40:      	xorl	%edi, %edi
   12b42:      	cmpl	%r15d, %r12d
   12b45:      	seta	%dil
   12b49:      	movzbl	%cl, %esi
   12b4c:      	addq	%rax, %rbx
   12b4f:      	addq	%rbx, %rdi
   12b52:      	movl	$0x4, %eax
   12b57:      	callq	*%rax
   12b59:      	movq	%rbx, 0x48(%rsp)
   12b5e:      	cmpl	%r15d, %r12d
   12b61:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12b67:      	movq	0x8(%rsp), %r12
   12b6c:      	movq	%r12, 0x30(%rsp)
   12b71:      	movq	0x38(%rsp), %rdx
   12b76:      	movq	0x40(%rsp), %r15
   12b7b:      	jmp	0x12bce <generic_kprobe_path+0x823e>
   12b7d:      	leaq	0x10(%r15), %rdx
   12b81:      	movl	$0x4, %eax
   12b86:      	movq	%rbp, %rdi
   12b89:      	movl	$0x8, %esi
   12b8e:      	callq	*%rax
   12b90:      	movq	0x40(%rsp), %rax
   12b95:      	cmpq	(%rsp), %rax
   12b99:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12b9f:      	addq	$0x18, %r15
   12ba3:      	movl	$0x4, %eax
   12ba8:      	leaq	0x30(%rsp), %rdi
   12bad:      	movl	$0x8, %esi
   12bb2:      	movq	%r15, %rdx
   12bb5:      	callq	*%rax
   12bb7:      	movq	(%rsp), %r15
   12bbb:      	movq	%r15, 0x40(%rsp)
   12bc0:      	leaq	0x20(%r15), %rdx
   12bc4:      	movq	%rdx, 0x38(%rsp)
   12bc9:      	movq	0x30(%rsp), %r12
   12bce:      	cmpq	0x18(%rsp), %r12
   12bd3:      	jne	0x12be0 <generic_kprobe_path+0x8250>
   12bd5:      	cmpq	0x20(%rsp), %rdx
   12bda:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12be0:      	movl	$0x4, %eax
   12be5:      	leaq	0x10(%rsp), %rdi
   12bea:      	movl	$0x8, %esi
   12bef:      	callq	*%rax
   12bf1:      	cmpq	0x10(%rsp), %r12
   12bf6:      	je	0x12cee <generic_kprobe_path+0x835e>
   12bfc:      	leaq	0x18(%r12), %rbx
   12c01:      	movl	$0x4, %eax
   12c06:      	movq	%rbp, %rdi
   12c09:      	movl	$0x8, %esi
   12c0e:      	movq	%rbx, %rdx
   12c11:      	callq	*%rax
   12c13:      	cmpq	%r12, (%rsp)
   12c17:      	je	0x12cee <generic_kprobe_path+0x835e>
   12c1d:      	movl	$0x4, %eax
   12c22:      	leaq	0x8(%rsp), %rdi
   12c27:      	movl	$0x8, %esi
   12c2c:      	movq	%rbx, %rdx
   12c2f:      	callq	*%rax
   12c31:      	addq	$0x20, %r12
   12c35:      	movl	$0x4, %eax
   12c3a:      	leaq	0x58(%rsp), %rdi
   12c3f:      	movl	$0x10, %ecx
   12c44:      	movl	$0x10, %esi
   12c49:      	movq	%r12, %rdx
   12c4c:      	callq	*%rax
   12c4e:      	movq	0x28(%rsp), %rbx
   12c53:      	movq	0x48(%rsp), %rax
   12c58:      	movl	0x5c(%rsp), %r15d
   12c5d:      	subq	%rbx, %rax
   12c60:      	movl	0x50(%rsp), %r12d
   12c65:      	movl	%r15d, %edx
   12c68:      	subl	%r12d, %edx
   12c6b:      	movl	$0x0, %ecx
   12c70:      	cmovbl	%ecx, %edx
   12c73:      	addq	0x60(%rsp), %rdx
   12c78:      	xorl	%esi, %esi
   12c7a:      	cmpl	%r15d, %r12d
   12c7d:      	seta	%sil
   12c81:      	movl	%r15d, %ecx
   12c84:      	cmovbl	%r12d, %ecx
   12c88:      	addl	%ecx, %esi
   12c8a:      	movl	%r12d, %edi
   12c8d:      	subl	%esi, %edi
   12c8f:      	movl	%edi, 0x50(%rsp)
   12c93:      	subq	%rsi, %rax
   12c96:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12c9c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12ca2:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12ca8:      	cmpl	%r15d, %r12d
   12cab:      	jbe	0x12cb1 <generic_kprobe_path+0x8321>
   12cad:      	movb	$0x2f, (%rbx,%rax)
   12cb1:      	xorl	%edi, %edi
   12cb3:      	cmpl	%r15d, %r12d
   12cb6:      	seta	%dil
   12cba:      	movzbl	%cl, %esi
   12cbd:      	addq	%rax, %rbx
   12cc0:      	addq	%rbx, %rdi
   12cc3:      	movl	$0x4, %eax
   12cc8:      	callq	*%rax
   12cca:      	movq	%rbx, 0x48(%rsp)
   12ccf:      	cmpl	%r15d, %r12d
   12cd2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12cd8:      	movq	0x8(%rsp), %r12
   12cdd:      	movq	%r12, 0x30(%rsp)
   12ce2:      	movq	0x38(%rsp), %rdx
   12ce7:      	movq	0x40(%rsp), %r15
   12cec:      	jmp	0x12d3f <generic_kprobe_path+0x83af>
   12cee:      	leaq	0x10(%r15), %rdx
   12cf2:      	movl	$0x4, %eax
   12cf7:      	movq	%rbp, %rdi
   12cfa:      	movl	$0x8, %esi
   12cff:      	callq	*%rax
   12d01:      	movq	0x40(%rsp), %rax
   12d06:      	cmpq	(%rsp), %rax
   12d0a:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12d10:      	addq	$0x18, %r15
   12d14:      	movl	$0x4, %eax
   12d19:      	leaq	0x30(%rsp), %rdi
   12d1e:      	movl	$0x8, %esi
   12d23:      	movq	%r15, %rdx
   12d26:      	callq	*%rax
   12d28:      	movq	(%rsp), %r15
   12d2c:      	movq	%r15, 0x40(%rsp)
   12d31:      	leaq	0x20(%r15), %rdx
   12d35:      	movq	%rdx, 0x38(%rsp)
   12d3a:      	movq	0x30(%rsp), %r12
   12d3f:      	cmpq	0x18(%rsp), %r12
   12d44:      	jne	0x12d51 <generic_kprobe_path+0x83c1>
   12d46:      	cmpq	0x20(%rsp), %rdx
   12d4b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12d51:      	movl	$0x4, %eax
   12d56:      	leaq	0x10(%rsp), %rdi
   12d5b:      	movl	$0x8, %esi
   12d60:      	callq	*%rax
   12d62:      	cmpq	0x10(%rsp), %r12
   12d67:      	je	0x12e5f <generic_kprobe_path+0x84cf>
   12d6d:      	leaq	0x18(%r12), %rbx
   12d72:      	movl	$0x4, %eax
   12d77:      	movq	%rbp, %rdi
   12d7a:      	movl	$0x8, %esi
   12d7f:      	movq	%rbx, %rdx
   12d82:      	callq	*%rax
   12d84:      	cmpq	%r12, (%rsp)
   12d88:      	je	0x12e5f <generic_kprobe_path+0x84cf>
   12d8e:      	movl	$0x4, %eax
   12d93:      	leaq	0x8(%rsp), %rdi
   12d98:      	movl	$0x8, %esi
   12d9d:      	movq	%rbx, %rdx
   12da0:      	callq	*%rax
   12da2:      	addq	$0x20, %r12
   12da6:      	movl	$0x4, %eax
   12dab:      	leaq	0x58(%rsp), %rdi
   12db0:      	movl	$0x10, %ecx
   12db5:      	movl	$0x10, %esi
   12dba:      	movq	%r12, %rdx
   12dbd:      	callq	*%rax
   12dbf:      	movq	0x28(%rsp), %rbx
   12dc4:      	movq	0x48(%rsp), %rax
   12dc9:      	movl	0x5c(%rsp), %r15d
   12dce:      	subq	%rbx, %rax
   12dd1:      	movl	0x50(%rsp), %r12d
   12dd6:      	movl	%r15d, %edx
   12dd9:      	subl	%r12d, %edx
   12ddc:      	movl	$0x0, %ecx
   12de1:      	cmovbl	%ecx, %edx
   12de4:      	addq	0x60(%rsp), %rdx
   12de9:      	xorl	%esi, %esi
   12deb:      	cmpl	%r15d, %r12d
   12dee:      	seta	%sil
   12df2:      	movl	%r15d, %ecx
   12df5:      	cmovbl	%r12d, %ecx
   12df9:      	addl	%ecx, %esi
   12dfb:      	movl	%r12d, %edi
   12dfe:      	subl	%esi, %edi
   12e00:      	movl	%edi, 0x50(%rsp)
   12e04:      	subq	%rsi, %rax
   12e07:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12e0d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12e13:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12e19:      	cmpl	%r15d, %r12d
   12e1c:      	jbe	0x12e22 <generic_kprobe_path+0x8492>
   12e1e:      	movb	$0x2f, (%rbx,%rax)
   12e22:      	xorl	%edi, %edi
   12e24:      	cmpl	%r15d, %r12d
   12e27:      	seta	%dil
   12e2b:      	movzbl	%cl, %esi
   12e2e:      	addq	%rax, %rbx
   12e31:      	addq	%rbx, %rdi
   12e34:      	movl	$0x4, %eax
   12e39:      	callq	*%rax
   12e3b:      	movq	%rbx, 0x48(%rsp)
   12e40:      	cmpl	%r15d, %r12d
   12e43:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12e49:      	movq	0x8(%rsp), %r12
   12e4e:      	movq	%r12, 0x30(%rsp)
   12e53:      	movq	0x38(%rsp), %rdx
   12e58:      	movq	0x40(%rsp), %r15
   12e5d:      	jmp	0x12eb0 <generic_kprobe_path+0x8520>
   12e5f:      	leaq	0x10(%r15), %rdx
   12e63:      	movl	$0x4, %eax
   12e68:      	movq	%rbp, %rdi
   12e6b:      	movl	$0x8, %esi
   12e70:      	callq	*%rax
   12e72:      	movq	0x40(%rsp), %rax
   12e77:      	cmpq	(%rsp), %rax
   12e7b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12e81:      	addq	$0x18, %r15
   12e85:      	movl	$0x4, %eax
   12e8a:      	leaq	0x30(%rsp), %rdi
   12e8f:      	movl	$0x8, %esi
   12e94:      	movq	%r15, %rdx
   12e97:      	callq	*%rax
   12e99:      	movq	(%rsp), %r15
   12e9d:      	movq	%r15, 0x40(%rsp)
   12ea2:      	leaq	0x20(%r15), %rdx
   12ea6:      	movq	%rdx, 0x38(%rsp)
   12eab:      	movq	0x30(%rsp), %r12
   12eb0:      	cmpq	0x18(%rsp), %r12
   12eb5:      	jne	0x12ec2 <generic_kprobe_path+0x8532>
   12eb7:      	cmpq	0x20(%rsp), %rdx
   12ebc:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12ec2:      	movl	$0x4, %eax
   12ec7:      	leaq	0x10(%rsp), %rdi
   12ecc:      	movl	$0x8, %esi
   12ed1:      	callq	*%rax
   12ed3:      	cmpq	0x10(%rsp), %r12
   12ed8:      	je	0x12fd0 <generic_kprobe_path+0x8640>
   12ede:      	leaq	0x18(%r12), %rbx
   12ee3:      	movl	$0x4, %eax
   12ee8:      	movq	%rbp, %rdi
   12eeb:      	movl	$0x8, %esi
   12ef0:      	movq	%rbx, %rdx
   12ef3:      	callq	*%rax
   12ef5:      	cmpq	%r12, (%rsp)
   12ef9:      	je	0x12fd0 <generic_kprobe_path+0x8640>
   12eff:      	movl	$0x4, %eax
   12f04:      	leaq	0x8(%rsp), %rdi
   12f09:      	movl	$0x8, %esi
   12f0e:      	movq	%rbx, %rdx
   12f11:      	callq	*%rax
   12f13:      	addq	$0x20, %r12
   12f17:      	movl	$0x4, %eax
   12f1c:      	leaq	0x58(%rsp), %rdi
   12f21:      	movl	$0x10, %ecx
   12f26:      	movl	$0x10, %esi
   12f2b:      	movq	%r12, %rdx
   12f2e:      	callq	*%rax
   12f30:      	movq	0x28(%rsp), %rbx
   12f35:      	movq	0x48(%rsp), %rax
   12f3a:      	movl	0x5c(%rsp), %r15d
   12f3f:      	subq	%rbx, %rax
   12f42:      	movl	0x50(%rsp), %r12d
   12f47:      	movl	%r15d, %edx
   12f4a:      	subl	%r12d, %edx
   12f4d:      	movl	$0x0, %ecx
   12f52:      	cmovbl	%ecx, %edx
   12f55:      	addq	0x60(%rsp), %rdx
   12f5a:      	xorl	%esi, %esi
   12f5c:      	cmpl	%r15d, %r12d
   12f5f:      	seta	%sil
   12f63:      	movl	%r15d, %ecx
   12f66:      	cmovbl	%r12d, %ecx
   12f6a:      	addl	%ecx, %esi
   12f6c:      	movl	%r12d, %edi
   12f6f:      	subl	%esi, %edi
   12f71:      	movl	%edi, 0x50(%rsp)
   12f75:      	subq	%rsi, %rax
   12f78:      	jb	0x16402 <generic_kprobe_path+0xba72>
   12f7e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12f84:      	ja	0x16402 <generic_kprobe_path+0xba72>
   12f8a:      	cmpl	%r15d, %r12d
   12f8d:      	jbe	0x12f93 <generic_kprobe_path+0x8603>
   12f8f:      	movb	$0x2f, (%rbx,%rax)
   12f93:      	xorl	%edi, %edi
   12f95:      	cmpl	%r15d, %r12d
   12f98:      	seta	%dil
   12f9c:      	movzbl	%cl, %esi
   12f9f:      	addq	%rax, %rbx
   12fa2:      	addq	%rbx, %rdi
   12fa5:      	movl	$0x4, %eax
   12faa:      	callq	*%rax
   12fac:      	movq	%rbx, 0x48(%rsp)
   12fb1:      	cmpl	%r15d, %r12d
   12fb4:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   12fba:      	movq	0x8(%rsp), %r12
   12fbf:      	movq	%r12, 0x30(%rsp)
   12fc4:      	movq	0x38(%rsp), %rdx
   12fc9:      	movq	0x40(%rsp), %r15
   12fce:      	jmp	0x13021 <generic_kprobe_path+0x8691>
   12fd0:      	leaq	0x10(%r15), %rdx
   12fd4:      	movl	$0x4, %eax
   12fd9:      	movq	%rbp, %rdi
   12fdc:      	movl	$0x8, %esi
   12fe1:      	callq	*%rax
   12fe3:      	movq	0x40(%rsp), %rax
   12fe8:      	cmpq	(%rsp), %rax
   12fec:      	je	0x163fd <generic_kprobe_path+0xba6d>
   12ff2:      	addq	$0x18, %r15
   12ff6:      	movl	$0x4, %eax
   12ffb:      	leaq	0x30(%rsp), %rdi
   13000:      	movl	$0x8, %esi
   13005:      	movq	%r15, %rdx
   13008:      	callq	*%rax
   1300a:      	movq	(%rsp), %r15
   1300e:      	movq	%r15, 0x40(%rsp)
   13013:      	leaq	0x20(%r15), %rdx
   13017:      	movq	%rdx, 0x38(%rsp)
   1301c:      	movq	0x30(%rsp), %r12
   13021:      	cmpq	0x18(%rsp), %r12
   13026:      	jne	0x13033 <generic_kprobe_path+0x86a3>
   13028:      	cmpq	0x20(%rsp), %rdx
   1302d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13033:      	movl	$0x4, %eax
   13038:      	leaq	0x10(%rsp), %rdi
   1303d:      	movl	$0x8, %esi
   13042:      	callq	*%rax
   13044:      	cmpq	0x10(%rsp), %r12
   13049:      	je	0x13141 <generic_kprobe_path+0x87b1>
   1304f:      	leaq	0x18(%r12), %rbx
   13054:      	movl	$0x4, %eax
   13059:      	movq	%rbp, %rdi
   1305c:      	movl	$0x8, %esi
   13061:      	movq	%rbx, %rdx
   13064:      	callq	*%rax
   13066:      	cmpq	%r12, (%rsp)
   1306a:      	je	0x13141 <generic_kprobe_path+0x87b1>
   13070:      	movl	$0x4, %eax
   13075:      	leaq	0x8(%rsp), %rdi
   1307a:      	movl	$0x8, %esi
   1307f:      	movq	%rbx, %rdx
   13082:      	callq	*%rax
   13084:      	addq	$0x20, %r12
   13088:      	movl	$0x4, %eax
   1308d:      	leaq	0x58(%rsp), %rdi
   13092:      	movl	$0x10, %ecx
   13097:      	movl	$0x10, %esi
   1309c:      	movq	%r12, %rdx
   1309f:      	callq	*%rax
   130a1:      	movq	0x28(%rsp), %rbx
   130a6:      	movq	0x48(%rsp), %rax
   130ab:      	movl	0x5c(%rsp), %r15d
   130b0:      	subq	%rbx, %rax
   130b3:      	movl	0x50(%rsp), %r12d
   130b8:      	movl	%r15d, %edx
   130bb:      	subl	%r12d, %edx
   130be:      	movl	$0x0, %ecx
   130c3:      	cmovbl	%ecx, %edx
   130c6:      	addq	0x60(%rsp), %rdx
   130cb:      	xorl	%esi, %esi
   130cd:      	cmpl	%r15d, %r12d
   130d0:      	seta	%sil
   130d4:      	movl	%r15d, %ecx
   130d7:      	cmovbl	%r12d, %ecx
   130db:      	addl	%ecx, %esi
   130dd:      	movl	%r12d, %edi
   130e0:      	subl	%esi, %edi
   130e2:      	movl	%edi, 0x50(%rsp)
   130e6:      	subq	%rsi, %rax
   130e9:      	jb	0x16402 <generic_kprobe_path+0xba72>
   130ef:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   130f5:      	ja	0x16402 <generic_kprobe_path+0xba72>
   130fb:      	cmpl	%r15d, %r12d
   130fe:      	jbe	0x13104 <generic_kprobe_path+0x8774>
   13100:      	movb	$0x2f, (%rbx,%rax)
   13104:      	xorl	%edi, %edi
   13106:      	cmpl	%r15d, %r12d
   13109:      	seta	%dil
   1310d:      	movzbl	%cl, %esi
   13110:      	addq	%rax, %rbx
   13113:      	addq	%rbx, %rdi
   13116:      	movl	$0x4, %eax
   1311b:      	callq	*%rax
   1311d:      	movq	%rbx, 0x48(%rsp)
   13122:      	cmpl	%r15d, %r12d
   13125:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1312b:      	movq	0x8(%rsp), %r12
   13130:      	movq	%r12, 0x30(%rsp)
   13135:      	movq	0x38(%rsp), %rdx
   1313a:      	movq	0x40(%rsp), %r15
   1313f:      	jmp	0x13192 <generic_kprobe_path+0x8802>
   13141:      	leaq	0x10(%r15), %rdx
   13145:      	movl	$0x4, %eax
   1314a:      	movq	%rbp, %rdi
   1314d:      	movl	$0x8, %esi
   13152:      	callq	*%rax
   13154:      	movq	0x40(%rsp), %rax
   13159:      	cmpq	(%rsp), %rax
   1315d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13163:      	addq	$0x18, %r15
   13167:      	movl	$0x4, %eax
   1316c:      	leaq	0x30(%rsp), %rdi
   13171:      	movl	$0x8, %esi
   13176:      	movq	%r15, %rdx
   13179:      	callq	*%rax
   1317b:      	movq	(%rsp), %r15
   1317f:      	movq	%r15, 0x40(%rsp)
   13184:      	leaq	0x20(%r15), %rdx
   13188:      	movq	%rdx, 0x38(%rsp)
   1318d:      	movq	0x30(%rsp), %r12
   13192:      	cmpq	0x18(%rsp), %r12
   13197:      	jne	0x131a4 <generic_kprobe_path+0x8814>
   13199:      	cmpq	0x20(%rsp), %rdx
   1319e:      	je	0x163fd <generic_kprobe_path+0xba6d>
   131a4:      	movl	$0x4, %eax
   131a9:      	leaq	0x10(%rsp), %rdi
   131ae:      	movl	$0x8, %esi
   131b3:      	callq	*%rax
   131b5:      	cmpq	0x10(%rsp), %r12
   131ba:      	je	0x132b2 <generic_kprobe_path+0x8922>
   131c0:      	leaq	0x18(%r12), %rbx
   131c5:      	movl	$0x4, %eax
   131ca:      	movq	%rbp, %rdi
   131cd:      	movl	$0x8, %esi
   131d2:      	movq	%rbx, %rdx
   131d5:      	callq	*%rax
   131d7:      	cmpq	%r12, (%rsp)
   131db:      	je	0x132b2 <generic_kprobe_path+0x8922>
   131e1:      	movl	$0x4, %eax
   131e6:      	leaq	0x8(%rsp), %rdi
   131eb:      	movl	$0x8, %esi
   131f0:      	movq	%rbx, %rdx
   131f3:      	callq	*%rax
   131f5:      	addq	$0x20, %r12
   131f9:      	movl	$0x4, %eax
   131fe:      	leaq	0x58(%rsp), %rdi
   13203:      	movl	$0x10, %ecx
   13208:      	movl	$0x10, %esi
   1320d:      	movq	%r12, %rdx
   13210:      	callq	*%rax
   13212:      	movq	0x28(%rsp), %rbx
   13217:      	movq	0x48(%rsp), %rax
   1321c:      	movl	0x5c(%rsp), %r15d
   13221:      	subq	%rbx, %rax
   13224:      	movl	0x50(%rsp), %r12d
   13229:      	movl	%r15d, %edx
   1322c:      	subl	%r12d, %edx
   1322f:      	movl	$0x0, %ecx
   13234:      	cmovbl	%ecx, %edx
   13237:      	addq	0x60(%rsp), %rdx
   1323c:      	xorl	%esi, %esi
   1323e:      	cmpl	%r15d, %r12d
   13241:      	seta	%sil
   13245:      	movl	%r15d, %ecx
   13248:      	cmovbl	%r12d, %ecx
   1324c:      	addl	%ecx, %esi
   1324e:      	movl	%r12d, %edi
   13251:      	subl	%esi, %edi
   13253:      	movl	%edi, 0x50(%rsp)
   13257:      	subq	%rsi, %rax
   1325a:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13260:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13266:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1326c:      	cmpl	%r15d, %r12d
   1326f:      	jbe	0x13275 <generic_kprobe_path+0x88e5>
   13271:      	movb	$0x2f, (%rbx,%rax)
   13275:      	xorl	%edi, %edi
   13277:      	cmpl	%r15d, %r12d
   1327a:      	seta	%dil
   1327e:      	movzbl	%cl, %esi
   13281:      	addq	%rax, %rbx
   13284:      	addq	%rbx, %rdi
   13287:      	movl	$0x4, %eax
   1328c:      	callq	*%rax
   1328e:      	movq	%rbx, 0x48(%rsp)
   13293:      	cmpl	%r15d, %r12d
   13296:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1329c:      	movq	0x8(%rsp), %r12
   132a1:      	movq	%r12, 0x30(%rsp)
   132a6:      	movq	0x38(%rsp), %rdx
   132ab:      	movq	0x40(%rsp), %r15
   132b0:      	jmp	0x13303 <generic_kprobe_path+0x8973>
   132b2:      	leaq	0x10(%r15), %rdx
   132b6:      	movl	$0x4, %eax
   132bb:      	movq	%rbp, %rdi
   132be:      	movl	$0x8, %esi
   132c3:      	callq	*%rax
   132c5:      	movq	0x40(%rsp), %rax
   132ca:      	cmpq	(%rsp), %rax
   132ce:      	je	0x163fd <generic_kprobe_path+0xba6d>
   132d4:      	addq	$0x18, %r15
   132d8:      	movl	$0x4, %eax
   132dd:      	leaq	0x30(%rsp), %rdi
   132e2:      	movl	$0x8, %esi
   132e7:      	movq	%r15, %rdx
   132ea:      	callq	*%rax
   132ec:      	movq	(%rsp), %r15
   132f0:      	movq	%r15, 0x40(%rsp)
   132f5:      	leaq	0x20(%r15), %rdx
   132f9:      	movq	%rdx, 0x38(%rsp)
   132fe:      	movq	0x30(%rsp), %r12
   13303:      	cmpq	0x18(%rsp), %r12
   13308:      	jne	0x13315 <generic_kprobe_path+0x8985>
   1330a:      	cmpq	0x20(%rsp), %rdx
   1330f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13315:      	movl	$0x4, %eax
   1331a:      	leaq	0x10(%rsp), %rdi
   1331f:      	movl	$0x8, %esi
   13324:      	callq	*%rax
   13326:      	cmpq	0x10(%rsp), %r12
   1332b:      	je	0x13423 <generic_kprobe_path+0x8a93>
   13331:      	leaq	0x18(%r12), %rbx
   13336:      	movl	$0x4, %eax
   1333b:      	movq	%rbp, %rdi
   1333e:      	movl	$0x8, %esi
   13343:      	movq	%rbx, %rdx
   13346:      	callq	*%rax
   13348:      	cmpq	%r12, (%rsp)
   1334c:      	je	0x13423 <generic_kprobe_path+0x8a93>
   13352:      	movl	$0x4, %eax
   13357:      	leaq	0x8(%rsp), %rdi
   1335c:      	movl	$0x8, %esi
   13361:      	movq	%rbx, %rdx
   13364:      	callq	*%rax
   13366:      	addq	$0x20, %r12
   1336a:      	movl	$0x4, %eax
   1336f:      	leaq	0x58(%rsp), %rdi
   13374:      	movl	$0x10, %ecx
   13379:      	movl	$0x10, %esi
   1337e:      	movq	%r12, %rdx
   13381:      	callq	*%rax
   13383:      	movq	0x28(%rsp), %rbx
   13388:      	movq	0x48(%rsp), %rax
   1338d:      	movl	0x5c(%rsp), %r15d
   13392:      	subq	%rbx, %rax
   13395:      	movl	0x50(%rsp), %r12d
   1339a:      	movl	%r15d, %edx
   1339d:      	subl	%r12d, %edx
   133a0:      	movl	$0x0, %ecx
   133a5:      	cmovbl	%ecx, %edx
   133a8:      	addq	0x60(%rsp), %rdx
   133ad:      	xorl	%esi, %esi
   133af:      	cmpl	%r15d, %r12d
   133b2:      	seta	%sil
   133b6:      	movl	%r15d, %ecx
   133b9:      	cmovbl	%r12d, %ecx
   133bd:      	addl	%ecx, %esi
   133bf:      	movl	%r12d, %edi
   133c2:      	subl	%esi, %edi
   133c4:      	movl	%edi, 0x50(%rsp)
   133c8:      	subq	%rsi, %rax
   133cb:      	jb	0x16402 <generic_kprobe_path+0xba72>
   133d1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   133d7:      	ja	0x16402 <generic_kprobe_path+0xba72>
   133dd:      	cmpl	%r15d, %r12d
   133e0:      	jbe	0x133e6 <generic_kprobe_path+0x8a56>
   133e2:      	movb	$0x2f, (%rbx,%rax)
   133e6:      	xorl	%edi, %edi
   133e8:      	cmpl	%r15d, %r12d
   133eb:      	seta	%dil
   133ef:      	movzbl	%cl, %esi
   133f2:      	addq	%rax, %rbx
   133f5:      	addq	%rbx, %rdi
   133f8:      	movl	$0x4, %eax
   133fd:      	callq	*%rax
   133ff:      	movq	%rbx, 0x48(%rsp)
   13404:      	cmpl	%r15d, %r12d
   13407:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1340d:      	movq	0x8(%rsp), %r12
   13412:      	movq	%r12, 0x30(%rsp)
   13417:      	movq	0x38(%rsp), %rdx
   1341c:      	movq	0x40(%rsp), %r15
   13421:      	jmp	0x13474 <generic_kprobe_path+0x8ae4>
   13423:      	leaq	0x10(%r15), %rdx
   13427:      	movl	$0x4, %eax
   1342c:      	movq	%rbp, %rdi
   1342f:      	movl	$0x8, %esi
   13434:      	callq	*%rax
   13436:      	movq	0x40(%rsp), %rax
   1343b:      	cmpq	(%rsp), %rax
   1343f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13445:      	addq	$0x18, %r15
   13449:      	movl	$0x4, %eax
   1344e:      	leaq	0x30(%rsp), %rdi
   13453:      	movl	$0x8, %esi
   13458:      	movq	%r15, %rdx
   1345b:      	callq	*%rax
   1345d:      	movq	(%rsp), %r15
   13461:      	movq	%r15, 0x40(%rsp)
   13466:      	leaq	0x20(%r15), %rdx
   1346a:      	movq	%rdx, 0x38(%rsp)
   1346f:      	movq	0x30(%rsp), %r12
   13474:      	cmpq	0x18(%rsp), %r12
   13479:      	jne	0x13486 <generic_kprobe_path+0x8af6>
   1347b:      	cmpq	0x20(%rsp), %rdx
   13480:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13486:      	movl	$0x4, %eax
   1348b:      	leaq	0x10(%rsp), %rdi
   13490:      	movl	$0x8, %esi
   13495:      	callq	*%rax
   13497:      	cmpq	0x10(%rsp), %r12
   1349c:      	je	0x13594 <generic_kprobe_path+0x8c04>
   134a2:      	leaq	0x18(%r12), %rbx
   134a7:      	movl	$0x4, %eax
   134ac:      	movq	%rbp, %rdi
   134af:      	movl	$0x8, %esi
   134b4:      	movq	%rbx, %rdx
   134b7:      	callq	*%rax
   134b9:      	cmpq	%r12, (%rsp)
   134bd:      	je	0x13594 <generic_kprobe_path+0x8c04>
   134c3:      	movl	$0x4, %eax
   134c8:      	leaq	0x8(%rsp), %rdi
   134cd:      	movl	$0x8, %esi
   134d2:      	movq	%rbx, %rdx
   134d5:      	callq	*%rax
   134d7:      	addq	$0x20, %r12
   134db:      	movl	$0x4, %eax
   134e0:      	leaq	0x58(%rsp), %rdi
   134e5:      	movl	$0x10, %ecx
   134ea:      	movl	$0x10, %esi
   134ef:      	movq	%r12, %rdx
   134f2:      	callq	*%rax
   134f4:      	movq	0x28(%rsp), %rbx
   134f9:      	movq	0x48(%rsp), %rax
   134fe:      	movl	0x5c(%rsp), %r15d
   13503:      	subq	%rbx, %rax
   13506:      	movl	0x50(%rsp), %r12d
   1350b:      	movl	%r15d, %edx
   1350e:      	subl	%r12d, %edx
   13511:      	movl	$0x0, %ecx
   13516:      	cmovbl	%ecx, %edx
   13519:      	addq	0x60(%rsp), %rdx
   1351e:      	xorl	%esi, %esi
   13520:      	cmpl	%r15d, %r12d
   13523:      	seta	%sil
   13527:      	movl	%r15d, %ecx
   1352a:      	cmovbl	%r12d, %ecx
   1352e:      	addl	%ecx, %esi
   13530:      	movl	%r12d, %edi
   13533:      	subl	%esi, %edi
   13535:      	movl	%edi, 0x50(%rsp)
   13539:      	subq	%rsi, %rax
   1353c:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13542:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13548:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1354e:      	cmpl	%r15d, %r12d
   13551:      	jbe	0x13557 <generic_kprobe_path+0x8bc7>
   13553:      	movb	$0x2f, (%rbx,%rax)
   13557:      	xorl	%edi, %edi
   13559:      	cmpl	%r15d, %r12d
   1355c:      	seta	%dil
   13560:      	movzbl	%cl, %esi
   13563:      	addq	%rax, %rbx
   13566:      	addq	%rbx, %rdi
   13569:      	movl	$0x4, %eax
   1356e:      	callq	*%rax
   13570:      	movq	%rbx, 0x48(%rsp)
   13575:      	cmpl	%r15d, %r12d
   13578:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1357e:      	movq	0x8(%rsp), %r12
   13583:      	movq	%r12, 0x30(%rsp)
   13588:      	movq	0x38(%rsp), %rdx
   1358d:      	movq	0x40(%rsp), %r15
   13592:      	jmp	0x135e5 <generic_kprobe_path+0x8c55>
   13594:      	leaq	0x10(%r15), %rdx
   13598:      	movl	$0x4, %eax
   1359d:      	movq	%rbp, %rdi
   135a0:      	movl	$0x8, %esi
   135a5:      	callq	*%rax
   135a7:      	movq	0x40(%rsp), %rax
   135ac:      	cmpq	(%rsp), %rax
   135b0:      	je	0x163fd <generic_kprobe_path+0xba6d>
   135b6:      	addq	$0x18, %r15
   135ba:      	movl	$0x4, %eax
   135bf:      	leaq	0x30(%rsp), %rdi
   135c4:      	movl	$0x8, %esi
   135c9:      	movq	%r15, %rdx
   135cc:      	callq	*%rax
   135ce:      	movq	(%rsp), %r15
   135d2:      	movq	%r15, 0x40(%rsp)
   135d7:      	leaq	0x20(%r15), %rdx
   135db:      	movq	%rdx, 0x38(%rsp)
   135e0:      	movq	0x30(%rsp), %r12
   135e5:      	cmpq	0x18(%rsp), %r12
   135ea:      	jne	0x135f7 <generic_kprobe_path+0x8c67>
   135ec:      	cmpq	0x20(%rsp), %rdx
   135f1:      	je	0x163fd <generic_kprobe_path+0xba6d>
   135f7:      	movl	$0x4, %eax
   135fc:      	leaq	0x10(%rsp), %rdi
   13601:      	movl	$0x8, %esi
   13606:      	callq	*%rax
   13608:      	cmpq	0x10(%rsp), %r12
   1360d:      	je	0x13705 <generic_kprobe_path+0x8d75>
   13613:      	leaq	0x18(%r12), %rbx
   13618:      	movl	$0x4, %eax
   1361d:      	movq	%rbp, %rdi
   13620:      	movl	$0x8, %esi
   13625:      	movq	%rbx, %rdx
   13628:      	callq	*%rax
   1362a:      	cmpq	%r12, (%rsp)
   1362e:      	je	0x13705 <generic_kprobe_path+0x8d75>
   13634:      	movl	$0x4, %eax
   13639:      	leaq	0x8(%rsp), %rdi
   1363e:      	movl	$0x8, %esi
   13643:      	movq	%rbx, %rdx
   13646:      	callq	*%rax
   13648:      	addq	$0x20, %r12
   1364c:      	movl	$0x4, %eax
   13651:      	leaq	0x58(%rsp), %rdi
   13656:      	movl	$0x10, %ecx
   1365b:      	movl	$0x10, %esi
   13660:      	movq	%r12, %rdx
   13663:      	callq	*%rax
   13665:      	movq	0x28(%rsp), %rbx
   1366a:      	movq	0x48(%rsp), %rax
   1366f:      	movl	0x5c(%rsp), %r15d
   13674:      	subq	%rbx, %rax
   13677:      	movl	0x50(%rsp), %r12d
   1367c:      	movl	%r15d, %edx
   1367f:      	subl	%r12d, %edx
   13682:      	movl	$0x0, %ecx
   13687:      	cmovbl	%ecx, %edx
   1368a:      	addq	0x60(%rsp), %rdx
   1368f:      	xorl	%esi, %esi
   13691:      	cmpl	%r15d, %r12d
   13694:      	seta	%sil
   13698:      	movl	%r15d, %ecx
   1369b:      	cmovbl	%r12d, %ecx
   1369f:      	addl	%ecx, %esi
   136a1:      	movl	%r12d, %edi
   136a4:      	subl	%esi, %edi
   136a6:      	movl	%edi, 0x50(%rsp)
   136aa:      	subq	%rsi, %rax
   136ad:      	jb	0x16402 <generic_kprobe_path+0xba72>
   136b3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   136b9:      	ja	0x16402 <generic_kprobe_path+0xba72>
   136bf:      	cmpl	%r15d, %r12d
   136c2:      	jbe	0x136c8 <generic_kprobe_path+0x8d38>
   136c4:      	movb	$0x2f, (%rbx,%rax)
   136c8:      	xorl	%edi, %edi
   136ca:      	cmpl	%r15d, %r12d
   136cd:      	seta	%dil
   136d1:      	movzbl	%cl, %esi
   136d4:      	addq	%rax, %rbx
   136d7:      	addq	%rbx, %rdi
   136da:      	movl	$0x4, %eax
   136df:      	callq	*%rax
   136e1:      	movq	%rbx, 0x48(%rsp)
   136e6:      	cmpl	%r15d, %r12d
   136e9:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   136ef:      	movq	0x8(%rsp), %r12
   136f4:      	movq	%r12, 0x30(%rsp)
   136f9:      	movq	0x38(%rsp), %rdx
   136fe:      	movq	0x40(%rsp), %r15
   13703:      	jmp	0x13756 <generic_kprobe_path+0x8dc6>
   13705:      	leaq	0x10(%r15), %rdx
   13709:      	movl	$0x4, %eax
   1370e:      	movq	%rbp, %rdi
   13711:      	movl	$0x8, %esi
   13716:      	callq	*%rax
   13718:      	movq	0x40(%rsp), %rax
   1371d:      	cmpq	(%rsp), %rax
   13721:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13727:      	addq	$0x18, %r15
   1372b:      	movl	$0x4, %eax
   13730:      	leaq	0x30(%rsp), %rdi
   13735:      	movl	$0x8, %esi
   1373a:      	movq	%r15, %rdx
   1373d:      	callq	*%rax
   1373f:      	movq	(%rsp), %r15
   13743:      	movq	%r15, 0x40(%rsp)
   13748:      	leaq	0x20(%r15), %rdx
   1374c:      	movq	%rdx, 0x38(%rsp)
   13751:      	movq	0x30(%rsp), %r12
   13756:      	cmpq	0x18(%rsp), %r12
   1375b:      	jne	0x13768 <generic_kprobe_path+0x8dd8>
   1375d:      	cmpq	0x20(%rsp), %rdx
   13762:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13768:      	movl	$0x4, %eax
   1376d:      	leaq	0x10(%rsp), %rdi
   13772:      	movl	$0x8, %esi
   13777:      	callq	*%rax
   13779:      	cmpq	0x10(%rsp), %r12
   1377e:      	je	0x13876 <generic_kprobe_path+0x8ee6>
   13784:      	leaq	0x18(%r12), %rbx
   13789:      	movl	$0x4, %eax
   1378e:      	movq	%rbp, %rdi
   13791:      	movl	$0x8, %esi
   13796:      	movq	%rbx, %rdx
   13799:      	callq	*%rax
   1379b:      	cmpq	%r12, (%rsp)
   1379f:      	je	0x13876 <generic_kprobe_path+0x8ee6>
   137a5:      	movl	$0x4, %eax
   137aa:      	leaq	0x8(%rsp), %rdi
   137af:      	movl	$0x8, %esi
   137b4:      	movq	%rbx, %rdx
   137b7:      	callq	*%rax
   137b9:      	addq	$0x20, %r12
   137bd:      	movl	$0x4, %eax
   137c2:      	leaq	0x58(%rsp), %rdi
   137c7:      	movl	$0x10, %ecx
   137cc:      	movl	$0x10, %esi
   137d1:      	movq	%r12, %rdx
   137d4:      	callq	*%rax
   137d6:      	movq	0x28(%rsp), %rbx
   137db:      	movq	0x48(%rsp), %rax
   137e0:      	movl	0x5c(%rsp), %r15d
   137e5:      	subq	%rbx, %rax
   137e8:      	movl	0x50(%rsp), %r12d
   137ed:      	movl	%r15d, %edx
   137f0:      	subl	%r12d, %edx
   137f3:      	movl	$0x0, %ecx
   137f8:      	cmovbl	%ecx, %edx
   137fb:      	addq	0x60(%rsp), %rdx
   13800:      	xorl	%esi, %esi
   13802:      	cmpl	%r15d, %r12d
   13805:      	seta	%sil
   13809:      	movl	%r15d, %ecx
   1380c:      	cmovbl	%r12d, %ecx
   13810:      	addl	%ecx, %esi
   13812:      	movl	%r12d, %edi
   13815:      	subl	%esi, %edi
   13817:      	movl	%edi, 0x50(%rsp)
   1381b:      	subq	%rsi, %rax
   1381e:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13824:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1382a:      	ja	0x16402 <generic_kprobe_path+0xba72>
   13830:      	cmpl	%r15d, %r12d
   13833:      	jbe	0x13839 <generic_kprobe_path+0x8ea9>
   13835:      	movb	$0x2f, (%rbx,%rax)
   13839:      	xorl	%edi, %edi
   1383b:      	cmpl	%r15d, %r12d
   1383e:      	seta	%dil
   13842:      	movzbl	%cl, %esi
   13845:      	addq	%rax, %rbx
   13848:      	addq	%rbx, %rdi
   1384b:      	movl	$0x4, %eax
   13850:      	callq	*%rax
   13852:      	movq	%rbx, 0x48(%rsp)
   13857:      	cmpl	%r15d, %r12d
   1385a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   13860:      	movq	0x8(%rsp), %r12
   13865:      	movq	%r12, 0x30(%rsp)
   1386a:      	movq	0x38(%rsp), %rdx
   1386f:      	movq	0x40(%rsp), %r15
   13874:      	jmp	0x138c7 <generic_kprobe_path+0x8f37>
   13876:      	leaq	0x10(%r15), %rdx
   1387a:      	movl	$0x4, %eax
   1387f:      	movq	%rbp, %rdi
   13882:      	movl	$0x8, %esi
   13887:      	callq	*%rax
   13889:      	movq	0x40(%rsp), %rax
   1388e:      	cmpq	(%rsp), %rax
   13892:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13898:      	addq	$0x18, %r15
   1389c:      	movl	$0x4, %eax
   138a1:      	leaq	0x30(%rsp), %rdi
   138a6:      	movl	$0x8, %esi
   138ab:      	movq	%r15, %rdx
   138ae:      	callq	*%rax
   138b0:      	movq	(%rsp), %r15
   138b4:      	movq	%r15, 0x40(%rsp)
   138b9:      	leaq	0x20(%r15), %rdx
   138bd:      	movq	%rdx, 0x38(%rsp)
   138c2:      	movq	0x30(%rsp), %r12
   138c7:      	cmpq	0x18(%rsp), %r12
   138cc:      	jne	0x138d9 <generic_kprobe_path+0x8f49>
   138ce:      	cmpq	0x20(%rsp), %rdx
   138d3:      	je	0x163fd <generic_kprobe_path+0xba6d>
   138d9:      	movl	$0x4, %eax
   138de:      	leaq	0x10(%rsp), %rdi
   138e3:      	movl	$0x8, %esi
   138e8:      	callq	*%rax
   138ea:      	cmpq	0x10(%rsp), %r12
   138ef:      	je	0x139e7 <generic_kprobe_path+0x9057>
   138f5:      	leaq	0x18(%r12), %rbx
   138fa:      	movl	$0x4, %eax
   138ff:      	movq	%rbp, %rdi
   13902:      	movl	$0x8, %esi
   13907:      	movq	%rbx, %rdx
   1390a:      	callq	*%rax
   1390c:      	cmpq	%r12, (%rsp)
   13910:      	je	0x139e7 <generic_kprobe_path+0x9057>
   13916:      	movl	$0x4, %eax
   1391b:      	leaq	0x8(%rsp), %rdi
   13920:      	movl	$0x8, %esi
   13925:      	movq	%rbx, %rdx
   13928:      	callq	*%rax
   1392a:      	addq	$0x20, %r12
   1392e:      	movl	$0x4, %eax
   13933:      	leaq	0x58(%rsp), %rdi
   13938:      	movl	$0x10, %ecx
   1393d:      	movl	$0x10, %esi
   13942:      	movq	%r12, %rdx
   13945:      	callq	*%rax
   13947:      	movq	0x28(%rsp), %rbx
   1394c:      	movq	0x48(%rsp), %rax
   13951:      	movl	0x5c(%rsp), %r15d
   13956:      	subq	%rbx, %rax
   13959:      	movl	0x50(%rsp), %r12d
   1395e:      	movl	%r15d, %edx
   13961:      	subl	%r12d, %edx
   13964:      	movl	$0x0, %ecx
   13969:      	cmovbl	%ecx, %edx
   1396c:      	addq	0x60(%rsp), %rdx
   13971:      	xorl	%esi, %esi
   13973:      	cmpl	%r15d, %r12d
   13976:      	seta	%sil
   1397a:      	movl	%r15d, %ecx
   1397d:      	cmovbl	%r12d, %ecx
   13981:      	addl	%ecx, %esi
   13983:      	movl	%r12d, %edi
   13986:      	subl	%esi, %edi
   13988:      	movl	%edi, 0x50(%rsp)
   1398c:      	subq	%rsi, %rax
   1398f:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13995:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1399b:      	ja	0x16402 <generic_kprobe_path+0xba72>
   139a1:      	cmpl	%r15d, %r12d
   139a4:      	jbe	0x139aa <generic_kprobe_path+0x901a>
   139a6:      	movb	$0x2f, (%rbx,%rax)
   139aa:      	xorl	%edi, %edi
   139ac:      	cmpl	%r15d, %r12d
   139af:      	seta	%dil
   139b3:      	movzbl	%cl, %esi
   139b6:      	addq	%rax, %rbx
   139b9:      	addq	%rbx, %rdi
   139bc:      	movl	$0x4, %eax
   139c1:      	callq	*%rax
   139c3:      	movq	%rbx, 0x48(%rsp)
   139c8:      	cmpl	%r15d, %r12d
   139cb:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   139d1:      	movq	0x8(%rsp), %r12
   139d6:      	movq	%r12, 0x30(%rsp)
   139db:      	movq	0x38(%rsp), %rdx
   139e0:      	movq	0x40(%rsp), %r15
   139e5:      	jmp	0x13a38 <generic_kprobe_path+0x90a8>
   139e7:      	leaq	0x10(%r15), %rdx
   139eb:      	movl	$0x4, %eax
   139f0:      	movq	%rbp, %rdi
   139f3:      	movl	$0x8, %esi
   139f8:      	callq	*%rax
   139fa:      	movq	0x40(%rsp), %rax
   139ff:      	cmpq	(%rsp), %rax
   13a03:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13a09:      	addq	$0x18, %r15
   13a0d:      	movl	$0x4, %eax
   13a12:      	leaq	0x30(%rsp), %rdi
   13a17:      	movl	$0x8, %esi
   13a1c:      	movq	%r15, %rdx
   13a1f:      	callq	*%rax
   13a21:      	movq	(%rsp), %r15
   13a25:      	movq	%r15, 0x40(%rsp)
   13a2a:      	leaq	0x20(%r15), %rdx
   13a2e:      	movq	%rdx, 0x38(%rsp)
   13a33:      	movq	0x30(%rsp), %r12
   13a38:      	cmpq	0x18(%rsp), %r12
   13a3d:      	jne	0x13a4a <generic_kprobe_path+0x90ba>
   13a3f:      	cmpq	0x20(%rsp), %rdx
   13a44:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13a4a:      	movl	$0x4, %eax
   13a4f:      	leaq	0x10(%rsp), %rdi
   13a54:      	movl	$0x8, %esi
   13a59:      	callq	*%rax
   13a5b:      	cmpq	0x10(%rsp), %r12
   13a60:      	je	0x13b58 <generic_kprobe_path+0x91c8>
   13a66:      	leaq	0x18(%r12), %rbx
   13a6b:      	movl	$0x4, %eax
   13a70:      	movq	%rbp, %rdi
   13a73:      	movl	$0x8, %esi
   13a78:      	movq	%rbx, %rdx
   13a7b:      	callq	*%rax
   13a7d:      	cmpq	%r12, (%rsp)
   13a81:      	je	0x13b58 <generic_kprobe_path+0x91c8>
   13a87:      	movl	$0x4, %eax
   13a8c:      	leaq	0x8(%rsp), %rdi
   13a91:      	movl	$0x8, %esi
   13a96:      	movq	%rbx, %rdx
   13a99:      	callq	*%rax
   13a9b:      	addq	$0x20, %r12
   13a9f:      	movl	$0x4, %eax
   13aa4:      	leaq	0x58(%rsp), %rdi
   13aa9:      	movl	$0x10, %ecx
   13aae:      	movl	$0x10, %esi
   13ab3:      	movq	%r12, %rdx
   13ab6:      	callq	*%rax
   13ab8:      	movq	0x28(%rsp), %rbx
   13abd:      	movq	0x48(%rsp), %rax
   13ac2:      	movl	0x5c(%rsp), %r15d
   13ac7:      	subq	%rbx, %rax
   13aca:      	movl	0x50(%rsp), %r12d
   13acf:      	movl	%r15d, %edx
   13ad2:      	subl	%r12d, %edx
   13ad5:      	movl	$0x0, %ecx
   13ada:      	cmovbl	%ecx, %edx
   13add:      	addq	0x60(%rsp), %rdx
   13ae2:      	xorl	%esi, %esi
   13ae4:      	cmpl	%r15d, %r12d
   13ae7:      	seta	%sil
   13aeb:      	movl	%r15d, %ecx
   13aee:      	cmovbl	%r12d, %ecx
   13af2:      	addl	%ecx, %esi
   13af4:      	movl	%r12d, %edi
   13af7:      	subl	%esi, %edi
   13af9:      	movl	%edi, 0x50(%rsp)
   13afd:      	subq	%rsi, %rax
   13b00:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13b06:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13b0c:      	ja	0x16402 <generic_kprobe_path+0xba72>
   13b12:      	cmpl	%r15d, %r12d
   13b15:      	jbe	0x13b1b <generic_kprobe_path+0x918b>
   13b17:      	movb	$0x2f, (%rbx,%rax)
   13b1b:      	xorl	%edi, %edi
   13b1d:      	cmpl	%r15d, %r12d
   13b20:      	seta	%dil
   13b24:      	movzbl	%cl, %esi
   13b27:      	addq	%rax, %rbx
   13b2a:      	addq	%rbx, %rdi
   13b2d:      	movl	$0x4, %eax
   13b32:      	callq	*%rax
   13b34:      	movq	%rbx, 0x48(%rsp)
   13b39:      	cmpl	%r15d, %r12d
   13b3c:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   13b42:      	movq	0x8(%rsp), %r12
   13b47:      	movq	%r12, 0x30(%rsp)
   13b4c:      	movq	0x38(%rsp), %rdx
   13b51:      	movq	0x40(%rsp), %r15
   13b56:      	jmp	0x13ba9 <generic_kprobe_path+0x9219>
   13b58:      	leaq	0x10(%r15), %rdx
   13b5c:      	movl	$0x4, %eax
   13b61:      	movq	%rbp, %rdi
   13b64:      	movl	$0x8, %esi
   13b69:      	callq	*%rax
   13b6b:      	movq	0x40(%rsp), %rax
   13b70:      	cmpq	(%rsp), %rax
   13b74:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13b7a:      	addq	$0x18, %r15
   13b7e:      	movl	$0x4, %eax
   13b83:      	leaq	0x30(%rsp), %rdi
   13b88:      	movl	$0x8, %esi
   13b8d:      	movq	%r15, %rdx
   13b90:      	callq	*%rax
   13b92:      	movq	(%rsp), %r15
   13b96:      	movq	%r15, 0x40(%rsp)
   13b9b:      	leaq	0x20(%r15), %rdx
   13b9f:      	movq	%rdx, 0x38(%rsp)
   13ba4:      	movq	0x30(%rsp), %r12
   13ba9:      	cmpq	0x18(%rsp), %r12
   13bae:      	jne	0x13bbb <generic_kprobe_path+0x922b>
   13bb0:      	cmpq	0x20(%rsp), %rdx
   13bb5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13bbb:      	movl	$0x4, %eax
   13bc0:      	leaq	0x10(%rsp), %rdi
   13bc5:      	movl	$0x8, %esi
   13bca:      	callq	*%rax
   13bcc:      	cmpq	0x10(%rsp), %r12
   13bd1:      	je	0x13cc9 <generic_kprobe_path+0x9339>
   13bd7:      	leaq	0x18(%r12), %rbx
   13bdc:      	movl	$0x4, %eax
   13be1:      	movq	%rbp, %rdi
   13be4:      	movl	$0x8, %esi
   13be9:      	movq	%rbx, %rdx
   13bec:      	callq	*%rax
   13bee:      	cmpq	%r12, (%rsp)
   13bf2:      	je	0x13cc9 <generic_kprobe_path+0x9339>
   13bf8:      	movl	$0x4, %eax
   13bfd:      	leaq	0x8(%rsp), %rdi
   13c02:      	movl	$0x8, %esi
   13c07:      	movq	%rbx, %rdx
   13c0a:      	callq	*%rax
   13c0c:      	addq	$0x20, %r12
   13c10:      	movl	$0x4, %eax
   13c15:      	leaq	0x58(%rsp), %rdi
   13c1a:      	movl	$0x10, %ecx
   13c1f:      	movl	$0x10, %esi
   13c24:      	movq	%r12, %rdx
   13c27:      	callq	*%rax
   13c29:      	movq	0x28(%rsp), %rbx
   13c2e:      	movq	0x48(%rsp), %rax
   13c33:      	movl	0x5c(%rsp), %r15d
   13c38:      	subq	%rbx, %rax
   13c3b:      	movl	0x50(%rsp), %r12d
   13c40:      	movl	%r15d, %edx
   13c43:      	subl	%r12d, %edx
   13c46:      	movl	$0x0, %ecx
   13c4b:      	cmovbl	%ecx, %edx
   13c4e:      	addq	0x60(%rsp), %rdx
   13c53:      	xorl	%esi, %esi
   13c55:      	cmpl	%r15d, %r12d
   13c58:      	seta	%sil
   13c5c:      	movl	%r15d, %ecx
   13c5f:      	cmovbl	%r12d, %ecx
   13c63:      	addl	%ecx, %esi
   13c65:      	movl	%r12d, %edi
   13c68:      	subl	%esi, %edi
   13c6a:      	movl	%edi, 0x50(%rsp)
   13c6e:      	subq	%rsi, %rax
   13c71:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13c77:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13c7d:      	ja	0x16402 <generic_kprobe_path+0xba72>
   13c83:      	cmpl	%r15d, %r12d
   13c86:      	jbe	0x13c8c <generic_kprobe_path+0x92fc>
   13c88:      	movb	$0x2f, (%rbx,%rax)
   13c8c:      	xorl	%edi, %edi
   13c8e:      	cmpl	%r15d, %r12d
   13c91:      	seta	%dil
   13c95:      	movzbl	%cl, %esi
   13c98:      	addq	%rax, %rbx
   13c9b:      	addq	%rbx, %rdi
   13c9e:      	movl	$0x4, %eax
   13ca3:      	callq	*%rax
   13ca5:      	movq	%rbx, 0x48(%rsp)
   13caa:      	cmpl	%r15d, %r12d
   13cad:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   13cb3:      	movq	0x8(%rsp), %r12
   13cb8:      	movq	%r12, 0x30(%rsp)
   13cbd:      	movq	0x38(%rsp), %rdx
   13cc2:      	movq	0x40(%rsp), %r15
   13cc7:      	jmp	0x13d1a <generic_kprobe_path+0x938a>
   13cc9:      	leaq	0x10(%r15), %rdx
   13ccd:      	movl	$0x4, %eax
   13cd2:      	movq	%rbp, %rdi
   13cd5:      	movl	$0x8, %esi
   13cda:      	callq	*%rax
   13cdc:      	movq	0x40(%rsp), %rax
   13ce1:      	cmpq	(%rsp), %rax
   13ce5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13ceb:      	addq	$0x18, %r15
   13cef:      	movl	$0x4, %eax
   13cf4:      	leaq	0x30(%rsp), %rdi
   13cf9:      	movl	$0x8, %esi
   13cfe:      	movq	%r15, %rdx
   13d01:      	callq	*%rax
   13d03:      	movq	(%rsp), %r15
   13d07:      	movq	%r15, 0x40(%rsp)
   13d0c:      	leaq	0x20(%r15), %rdx
   13d10:      	movq	%rdx, 0x38(%rsp)
   13d15:      	movq	0x30(%rsp), %r12
   13d1a:      	cmpq	0x18(%rsp), %r12
   13d1f:      	jne	0x13d2c <generic_kprobe_path+0x939c>
   13d21:      	cmpq	0x20(%rsp), %rdx
   13d26:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13d2c:      	movl	$0x4, %eax
   13d31:      	leaq	0x10(%rsp), %rdi
   13d36:      	movl	$0x8, %esi
   13d3b:      	callq	*%rax
   13d3d:      	cmpq	0x10(%rsp), %r12
   13d42:      	je	0x13e3a <generic_kprobe_path+0x94aa>
   13d48:      	leaq	0x18(%r12), %rbx
   13d4d:      	movl	$0x4, %eax
   13d52:      	movq	%rbp, %rdi
   13d55:      	movl	$0x8, %esi
   13d5a:      	movq	%rbx, %rdx
   13d5d:      	callq	*%rax
   13d5f:      	cmpq	%r12, (%rsp)
   13d63:      	je	0x13e3a <generic_kprobe_path+0x94aa>
   13d69:      	movl	$0x4, %eax
   13d6e:      	leaq	0x8(%rsp), %rdi
   13d73:      	movl	$0x8, %esi
   13d78:      	movq	%rbx, %rdx
   13d7b:      	callq	*%rax
   13d7d:      	addq	$0x20, %r12
   13d81:      	movl	$0x4, %eax
   13d86:      	leaq	0x58(%rsp), %rdi
   13d8b:      	movl	$0x10, %ecx
   13d90:      	movl	$0x10, %esi
   13d95:      	movq	%r12, %rdx
   13d98:      	callq	*%rax
   13d9a:      	movq	0x28(%rsp), %rbx
   13d9f:      	movq	0x48(%rsp), %rax
   13da4:      	movl	0x5c(%rsp), %r15d
   13da9:      	subq	%rbx, %rax
   13dac:      	movl	0x50(%rsp), %r12d
   13db1:      	movl	%r15d, %edx
   13db4:      	subl	%r12d, %edx
   13db7:      	movl	$0x0, %ecx
   13dbc:      	cmovbl	%ecx, %edx
   13dbf:      	addq	0x60(%rsp), %rdx
   13dc4:      	xorl	%esi, %esi
   13dc6:      	cmpl	%r15d, %r12d
   13dc9:      	seta	%sil
   13dcd:      	movl	%r15d, %ecx
   13dd0:      	cmovbl	%r12d, %ecx
   13dd4:      	addl	%ecx, %esi
   13dd6:      	movl	%r12d, %edi
   13dd9:      	subl	%esi, %edi
   13ddb:      	movl	%edi, 0x50(%rsp)
   13ddf:      	subq	%rsi, %rax
   13de2:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13de8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13dee:      	ja	0x16402 <generic_kprobe_path+0xba72>
   13df4:      	cmpl	%r15d, %r12d
   13df7:      	jbe	0x13dfd <generic_kprobe_path+0x946d>
   13df9:      	movb	$0x2f, (%rbx,%rax)
   13dfd:      	xorl	%edi, %edi
   13dff:      	cmpl	%r15d, %r12d
   13e02:      	seta	%dil
   13e06:      	movzbl	%cl, %esi
   13e09:      	addq	%rax, %rbx
   13e0c:      	addq	%rbx, %rdi
   13e0f:      	movl	$0x4, %eax
   13e14:      	callq	*%rax
   13e16:      	movq	%rbx, 0x48(%rsp)
   13e1b:      	cmpl	%r15d, %r12d
   13e1e:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   13e24:      	movq	0x8(%rsp), %r12
   13e29:      	movq	%r12, 0x30(%rsp)
   13e2e:      	movq	0x38(%rsp), %rdx
   13e33:      	movq	0x40(%rsp), %r15
   13e38:      	jmp	0x13e8b <generic_kprobe_path+0x94fb>
   13e3a:      	leaq	0x10(%r15), %rdx
   13e3e:      	movl	$0x4, %eax
   13e43:      	movq	%rbp, %rdi
   13e46:      	movl	$0x8, %esi
   13e4b:      	callq	*%rax
   13e4d:      	movq	0x40(%rsp), %rax
   13e52:      	cmpq	(%rsp), %rax
   13e56:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13e5c:      	addq	$0x18, %r15
   13e60:      	movl	$0x4, %eax
   13e65:      	leaq	0x30(%rsp), %rdi
   13e6a:      	movl	$0x8, %esi
   13e6f:      	movq	%r15, %rdx
   13e72:      	callq	*%rax
   13e74:      	movq	(%rsp), %r15
   13e78:      	movq	%r15, 0x40(%rsp)
   13e7d:      	leaq	0x20(%r15), %rdx
   13e81:      	movq	%rdx, 0x38(%rsp)
   13e86:      	movq	0x30(%rsp), %r12
   13e8b:      	cmpq	0x18(%rsp), %r12
   13e90:      	jne	0x13e9d <generic_kprobe_path+0x950d>
   13e92:      	cmpq	0x20(%rsp), %rdx
   13e97:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13e9d:      	movl	$0x4, %eax
   13ea2:      	leaq	0x10(%rsp), %rdi
   13ea7:      	movl	$0x8, %esi
   13eac:      	callq	*%rax
   13eae:      	cmpq	0x10(%rsp), %r12
   13eb3:      	je	0x13fab <generic_kprobe_path+0x961b>
   13eb9:      	leaq	0x18(%r12), %rbx
   13ebe:      	movl	$0x4, %eax
   13ec3:      	movq	%rbp, %rdi
   13ec6:      	movl	$0x8, %esi
   13ecb:      	movq	%rbx, %rdx
   13ece:      	callq	*%rax
   13ed0:      	cmpq	%r12, (%rsp)
   13ed4:      	je	0x13fab <generic_kprobe_path+0x961b>
   13eda:      	movl	$0x4, %eax
   13edf:      	leaq	0x8(%rsp), %rdi
   13ee4:      	movl	$0x8, %esi
   13ee9:      	movq	%rbx, %rdx
   13eec:      	callq	*%rax
   13eee:      	addq	$0x20, %r12
   13ef2:      	movl	$0x4, %eax
   13ef7:      	leaq	0x58(%rsp), %rdi
   13efc:      	movl	$0x10, %ecx
   13f01:      	movl	$0x10, %esi
   13f06:      	movq	%r12, %rdx
   13f09:      	callq	*%rax
   13f0b:      	movq	0x28(%rsp), %rbx
   13f10:      	movq	0x48(%rsp), %rax
   13f15:      	movl	0x5c(%rsp), %r15d
   13f1a:      	subq	%rbx, %rax
   13f1d:      	movl	0x50(%rsp), %r12d
   13f22:      	movl	%r15d, %edx
   13f25:      	subl	%r12d, %edx
   13f28:      	movl	$0x0, %ecx
   13f2d:      	cmovbl	%ecx, %edx
   13f30:      	addq	0x60(%rsp), %rdx
   13f35:      	xorl	%esi, %esi
   13f37:      	cmpl	%r15d, %r12d
   13f3a:      	seta	%sil
   13f3e:      	movl	%r15d, %ecx
   13f41:      	cmovbl	%r12d, %ecx
   13f45:      	addl	%ecx, %esi
   13f47:      	movl	%r12d, %edi
   13f4a:      	subl	%esi, %edi
   13f4c:      	movl	%edi, 0x50(%rsp)
   13f50:      	subq	%rsi, %rax
   13f53:      	jb	0x16402 <generic_kprobe_path+0xba72>
   13f59:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13f5f:      	ja	0x16402 <generic_kprobe_path+0xba72>
   13f65:      	cmpl	%r15d, %r12d
   13f68:      	jbe	0x13f6e <generic_kprobe_path+0x95de>
   13f6a:      	movb	$0x2f, (%rbx,%rax)
   13f6e:      	xorl	%edi, %edi
   13f70:      	cmpl	%r15d, %r12d
   13f73:      	seta	%dil
   13f77:      	movzbl	%cl, %esi
   13f7a:      	addq	%rax, %rbx
   13f7d:      	addq	%rbx, %rdi
   13f80:      	movl	$0x4, %eax
   13f85:      	callq	*%rax
   13f87:      	movq	%rbx, 0x48(%rsp)
   13f8c:      	cmpl	%r15d, %r12d
   13f8f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   13f95:      	movq	0x8(%rsp), %r12
   13f9a:      	movq	%r12, 0x30(%rsp)
   13f9f:      	movq	0x38(%rsp), %rdx
   13fa4:      	movq	0x40(%rsp), %r15
   13fa9:      	jmp	0x13ffc <generic_kprobe_path+0x966c>
   13fab:      	leaq	0x10(%r15), %rdx
   13faf:      	movl	$0x4, %eax
   13fb4:      	movq	%rbp, %rdi
   13fb7:      	movl	$0x8, %esi
   13fbc:      	callq	*%rax
   13fbe:      	movq	0x40(%rsp), %rax
   13fc3:      	cmpq	(%rsp), %rax
   13fc7:      	je	0x163fd <generic_kprobe_path+0xba6d>
   13fcd:      	addq	$0x18, %r15
   13fd1:      	movl	$0x4, %eax
   13fd6:      	leaq	0x30(%rsp), %rdi
   13fdb:      	movl	$0x8, %esi
   13fe0:      	movq	%r15, %rdx
   13fe3:      	callq	*%rax
   13fe5:      	movq	(%rsp), %r15
   13fe9:      	movq	%r15, 0x40(%rsp)
   13fee:      	leaq	0x20(%r15), %rdx
   13ff2:      	movq	%rdx, 0x38(%rsp)
   13ff7:      	movq	0x30(%rsp), %r12
   13ffc:      	cmpq	0x18(%rsp), %r12
   14001:      	jne	0x1400e <generic_kprobe_path+0x967e>
   14003:      	cmpq	0x20(%rsp), %rdx
   14008:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1400e:      	movl	$0x4, %eax
   14013:      	leaq	0x10(%rsp), %rdi
   14018:      	movl	$0x8, %esi
   1401d:      	callq	*%rax
   1401f:      	cmpq	0x10(%rsp), %r12
   14024:      	je	0x1411c <generic_kprobe_path+0x978c>
   1402a:      	leaq	0x18(%r12), %rbx
   1402f:      	movl	$0x4, %eax
   14034:      	movq	%rbp, %rdi
   14037:      	movl	$0x8, %esi
   1403c:      	movq	%rbx, %rdx
   1403f:      	callq	*%rax
   14041:      	cmpq	%r12, (%rsp)
   14045:      	je	0x1411c <generic_kprobe_path+0x978c>
   1404b:      	movl	$0x4, %eax
   14050:      	leaq	0x8(%rsp), %rdi
   14055:      	movl	$0x8, %esi
   1405a:      	movq	%rbx, %rdx
   1405d:      	callq	*%rax
   1405f:      	addq	$0x20, %r12
   14063:      	movl	$0x4, %eax
   14068:      	leaq	0x58(%rsp), %rdi
   1406d:      	movl	$0x10, %ecx
   14072:      	movl	$0x10, %esi
   14077:      	movq	%r12, %rdx
   1407a:      	callq	*%rax
   1407c:      	movq	0x28(%rsp), %rbx
   14081:      	movq	0x48(%rsp), %rax
   14086:      	movl	0x5c(%rsp), %r15d
   1408b:      	subq	%rbx, %rax
   1408e:      	movl	0x50(%rsp), %r12d
   14093:      	movl	%r15d, %edx
   14096:      	subl	%r12d, %edx
   14099:      	movl	$0x0, %ecx
   1409e:      	cmovbl	%ecx, %edx
   140a1:      	addq	0x60(%rsp), %rdx
   140a6:      	xorl	%esi, %esi
   140a8:      	cmpl	%r15d, %r12d
   140ab:      	seta	%sil
   140af:      	movl	%r15d, %ecx
   140b2:      	cmovbl	%r12d, %ecx
   140b6:      	addl	%ecx, %esi
   140b8:      	movl	%r12d, %edi
   140bb:      	subl	%esi, %edi
   140bd:      	movl	%edi, 0x50(%rsp)
   140c1:      	subq	%rsi, %rax
   140c4:      	jb	0x16402 <generic_kprobe_path+0xba72>
   140ca:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   140d0:      	ja	0x16402 <generic_kprobe_path+0xba72>
   140d6:      	cmpl	%r15d, %r12d
   140d9:      	jbe	0x140df <generic_kprobe_path+0x974f>
   140db:      	movb	$0x2f, (%rbx,%rax)
   140df:      	xorl	%edi, %edi
   140e1:      	cmpl	%r15d, %r12d
   140e4:      	seta	%dil
   140e8:      	movzbl	%cl, %esi
   140eb:      	addq	%rax, %rbx
   140ee:      	addq	%rbx, %rdi
   140f1:      	movl	$0x4, %eax
   140f6:      	callq	*%rax
   140f8:      	movq	%rbx, 0x48(%rsp)
   140fd:      	cmpl	%r15d, %r12d
   14100:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14106:      	movq	0x8(%rsp), %r12
   1410b:      	movq	%r12, 0x30(%rsp)
   14110:      	movq	0x38(%rsp), %rdx
   14115:      	movq	0x40(%rsp), %r15
   1411a:      	jmp	0x1416d <generic_kprobe_path+0x97dd>
   1411c:      	leaq	0x10(%r15), %rdx
   14120:      	movl	$0x4, %eax
   14125:      	movq	%rbp, %rdi
   14128:      	movl	$0x8, %esi
   1412d:      	callq	*%rax
   1412f:      	movq	0x40(%rsp), %rax
   14134:      	cmpq	(%rsp), %rax
   14138:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1413e:      	addq	$0x18, %r15
   14142:      	movl	$0x4, %eax
   14147:      	leaq	0x30(%rsp), %rdi
   1414c:      	movl	$0x8, %esi
   14151:      	movq	%r15, %rdx
   14154:      	callq	*%rax
   14156:      	movq	(%rsp), %r15
   1415a:      	movq	%r15, 0x40(%rsp)
   1415f:      	leaq	0x20(%r15), %rdx
   14163:      	movq	%rdx, 0x38(%rsp)
   14168:      	movq	0x30(%rsp), %r12
   1416d:      	cmpq	0x18(%rsp), %r12
   14172:      	jne	0x1417f <generic_kprobe_path+0x97ef>
   14174:      	cmpq	0x20(%rsp), %rdx
   14179:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1417f:      	movl	$0x4, %eax
   14184:      	leaq	0x10(%rsp), %rdi
   14189:      	movl	$0x8, %esi
   1418e:      	callq	*%rax
   14190:      	cmpq	0x10(%rsp), %r12
   14195:      	je	0x1428d <generic_kprobe_path+0x98fd>
   1419b:      	leaq	0x18(%r12), %rbx
   141a0:      	movl	$0x4, %eax
   141a5:      	movq	%rbp, %rdi
   141a8:      	movl	$0x8, %esi
   141ad:      	movq	%rbx, %rdx
   141b0:      	callq	*%rax
   141b2:      	cmpq	%r12, (%rsp)
   141b6:      	je	0x1428d <generic_kprobe_path+0x98fd>
   141bc:      	movl	$0x4, %eax
   141c1:      	leaq	0x8(%rsp), %rdi
   141c6:      	movl	$0x8, %esi
   141cb:      	movq	%rbx, %rdx
   141ce:      	callq	*%rax
   141d0:      	addq	$0x20, %r12
   141d4:      	movl	$0x4, %eax
   141d9:      	leaq	0x58(%rsp), %rdi
   141de:      	movl	$0x10, %ecx
   141e3:      	movl	$0x10, %esi
   141e8:      	movq	%r12, %rdx
   141eb:      	callq	*%rax
   141ed:      	movq	0x28(%rsp), %rbx
   141f2:      	movq	0x48(%rsp), %rax
   141f7:      	movl	0x5c(%rsp), %r15d
   141fc:      	subq	%rbx, %rax
   141ff:      	movl	0x50(%rsp), %r12d
   14204:      	movl	%r15d, %edx
   14207:      	subl	%r12d, %edx
   1420a:      	movl	$0x0, %ecx
   1420f:      	cmovbl	%ecx, %edx
   14212:      	addq	0x60(%rsp), %rdx
   14217:      	xorl	%esi, %esi
   14219:      	cmpl	%r15d, %r12d
   1421c:      	seta	%sil
   14220:      	movl	%r15d, %ecx
   14223:      	cmovbl	%r12d, %ecx
   14227:      	addl	%ecx, %esi
   14229:      	movl	%r12d, %edi
   1422c:      	subl	%esi, %edi
   1422e:      	movl	%edi, 0x50(%rsp)
   14232:      	subq	%rsi, %rax
   14235:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1423b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14241:      	ja	0x16402 <generic_kprobe_path+0xba72>
   14247:      	cmpl	%r15d, %r12d
   1424a:      	jbe	0x14250 <generic_kprobe_path+0x98c0>
   1424c:      	movb	$0x2f, (%rbx,%rax)
   14250:      	xorl	%edi, %edi
   14252:      	cmpl	%r15d, %r12d
   14255:      	seta	%dil
   14259:      	movzbl	%cl, %esi
   1425c:      	addq	%rax, %rbx
   1425f:      	addq	%rbx, %rdi
   14262:      	movl	$0x4, %eax
   14267:      	callq	*%rax
   14269:      	movq	%rbx, 0x48(%rsp)
   1426e:      	cmpl	%r15d, %r12d
   14271:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14277:      	movq	0x8(%rsp), %r12
   1427c:      	movq	%r12, 0x30(%rsp)
   14281:      	movq	0x38(%rsp), %rdx
   14286:      	movq	0x40(%rsp), %r15
   1428b:      	jmp	0x142de <generic_kprobe_path+0x994e>
   1428d:      	leaq	0x10(%r15), %rdx
   14291:      	movl	$0x4, %eax
   14296:      	movq	%rbp, %rdi
   14299:      	movl	$0x8, %esi
   1429e:      	callq	*%rax
   142a0:      	movq	0x40(%rsp), %rax
   142a5:      	cmpq	(%rsp), %rax
   142a9:      	je	0x163fd <generic_kprobe_path+0xba6d>
   142af:      	addq	$0x18, %r15
   142b3:      	movl	$0x4, %eax
   142b8:      	leaq	0x30(%rsp), %rdi
   142bd:      	movl	$0x8, %esi
   142c2:      	movq	%r15, %rdx
   142c5:      	callq	*%rax
   142c7:      	movq	(%rsp), %r15
   142cb:      	movq	%r15, 0x40(%rsp)
   142d0:      	leaq	0x20(%r15), %rdx
   142d4:      	movq	%rdx, 0x38(%rsp)
   142d9:      	movq	0x30(%rsp), %r12
   142de:      	cmpq	0x18(%rsp), %r12
   142e3:      	jne	0x142f0 <generic_kprobe_path+0x9960>
   142e5:      	cmpq	0x20(%rsp), %rdx
   142ea:      	je	0x163fd <generic_kprobe_path+0xba6d>
   142f0:      	movl	$0x4, %eax
   142f5:      	leaq	0x10(%rsp), %rdi
   142fa:      	movl	$0x8, %esi
   142ff:      	callq	*%rax
   14301:      	cmpq	0x10(%rsp), %r12
   14306:      	je	0x143fe <generic_kprobe_path+0x9a6e>
   1430c:      	leaq	0x18(%r12), %rbx
   14311:      	movl	$0x4, %eax
   14316:      	movq	%rbp, %rdi
   14319:      	movl	$0x8, %esi
   1431e:      	movq	%rbx, %rdx
   14321:      	callq	*%rax
   14323:      	cmpq	%r12, (%rsp)
   14327:      	je	0x143fe <generic_kprobe_path+0x9a6e>
   1432d:      	movl	$0x4, %eax
   14332:      	leaq	0x8(%rsp), %rdi
   14337:      	movl	$0x8, %esi
   1433c:      	movq	%rbx, %rdx
   1433f:      	callq	*%rax
   14341:      	addq	$0x20, %r12
   14345:      	movl	$0x4, %eax
   1434a:      	leaq	0x58(%rsp), %rdi
   1434f:      	movl	$0x10, %ecx
   14354:      	movl	$0x10, %esi
   14359:      	movq	%r12, %rdx
   1435c:      	callq	*%rax
   1435e:      	movq	0x28(%rsp), %rbx
   14363:      	movq	0x48(%rsp), %rax
   14368:      	movl	0x5c(%rsp), %r15d
   1436d:      	subq	%rbx, %rax
   14370:      	movl	0x50(%rsp), %r12d
   14375:      	movl	%r15d, %edx
   14378:      	subl	%r12d, %edx
   1437b:      	movl	$0x0, %ecx
   14380:      	cmovbl	%ecx, %edx
   14383:      	addq	0x60(%rsp), %rdx
   14388:      	xorl	%esi, %esi
   1438a:      	cmpl	%r15d, %r12d
   1438d:      	seta	%sil
   14391:      	movl	%r15d, %ecx
   14394:      	cmovbl	%r12d, %ecx
   14398:      	addl	%ecx, %esi
   1439a:      	movl	%r12d, %edi
   1439d:      	subl	%esi, %edi
   1439f:      	movl	%edi, 0x50(%rsp)
   143a3:      	subq	%rsi, %rax
   143a6:      	jb	0x16402 <generic_kprobe_path+0xba72>
   143ac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   143b2:      	ja	0x16402 <generic_kprobe_path+0xba72>
   143b8:      	cmpl	%r15d, %r12d
   143bb:      	jbe	0x143c1 <generic_kprobe_path+0x9a31>
   143bd:      	movb	$0x2f, (%rbx,%rax)
   143c1:      	xorl	%edi, %edi
   143c3:      	cmpl	%r15d, %r12d
   143c6:      	seta	%dil
   143ca:      	movzbl	%cl, %esi
   143cd:      	addq	%rax, %rbx
   143d0:      	addq	%rbx, %rdi
   143d3:      	movl	$0x4, %eax
   143d8:      	callq	*%rax
   143da:      	movq	%rbx, 0x48(%rsp)
   143df:      	cmpl	%r15d, %r12d
   143e2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   143e8:      	movq	0x8(%rsp), %r12
   143ed:      	movq	%r12, 0x30(%rsp)
   143f2:      	movq	0x38(%rsp), %rdx
   143f7:      	movq	0x40(%rsp), %r15
   143fc:      	jmp	0x1444f <generic_kprobe_path+0x9abf>
   143fe:      	leaq	0x10(%r15), %rdx
   14402:      	movl	$0x4, %eax
   14407:      	movq	%rbp, %rdi
   1440a:      	movl	$0x8, %esi
   1440f:      	callq	*%rax
   14411:      	movq	0x40(%rsp), %rax
   14416:      	cmpq	(%rsp), %rax
   1441a:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14420:      	addq	$0x18, %r15
   14424:      	movl	$0x4, %eax
   14429:      	leaq	0x30(%rsp), %rdi
   1442e:      	movl	$0x8, %esi
   14433:      	movq	%r15, %rdx
   14436:      	callq	*%rax
   14438:      	movq	(%rsp), %r15
   1443c:      	movq	%r15, 0x40(%rsp)
   14441:      	leaq	0x20(%r15), %rdx
   14445:      	movq	%rdx, 0x38(%rsp)
   1444a:      	movq	0x30(%rsp), %r12
   1444f:      	cmpq	0x18(%rsp), %r12
   14454:      	jne	0x14461 <generic_kprobe_path+0x9ad1>
   14456:      	cmpq	0x20(%rsp), %rdx
   1445b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14461:      	movl	$0x4, %eax
   14466:      	leaq	0x10(%rsp), %rdi
   1446b:      	movl	$0x8, %esi
   14470:      	callq	*%rax
   14472:      	cmpq	0x10(%rsp), %r12
   14477:      	je	0x1456f <generic_kprobe_path+0x9bdf>
   1447d:      	leaq	0x18(%r12), %rbx
   14482:      	movl	$0x4, %eax
   14487:      	movq	%rbp, %rdi
   1448a:      	movl	$0x8, %esi
   1448f:      	movq	%rbx, %rdx
   14492:      	callq	*%rax
   14494:      	cmpq	%r12, (%rsp)
   14498:      	je	0x1456f <generic_kprobe_path+0x9bdf>
   1449e:      	movl	$0x4, %eax
   144a3:      	leaq	0x8(%rsp), %rdi
   144a8:      	movl	$0x8, %esi
   144ad:      	movq	%rbx, %rdx
   144b0:      	callq	*%rax
   144b2:      	addq	$0x20, %r12
   144b6:      	movl	$0x4, %eax
   144bb:      	leaq	0x58(%rsp), %rdi
   144c0:      	movl	$0x10, %ecx
   144c5:      	movl	$0x10, %esi
   144ca:      	movq	%r12, %rdx
   144cd:      	callq	*%rax
   144cf:      	movq	0x28(%rsp), %rbx
   144d4:      	movq	0x48(%rsp), %rax
   144d9:      	movl	0x5c(%rsp), %r15d
   144de:      	subq	%rbx, %rax
   144e1:      	movl	0x50(%rsp), %r12d
   144e6:      	movl	%r15d, %edx
   144e9:      	subl	%r12d, %edx
   144ec:      	movl	$0x0, %ecx
   144f1:      	cmovbl	%ecx, %edx
   144f4:      	addq	0x60(%rsp), %rdx
   144f9:      	xorl	%esi, %esi
   144fb:      	cmpl	%r15d, %r12d
   144fe:      	seta	%sil
   14502:      	movl	%r15d, %ecx
   14505:      	cmovbl	%r12d, %ecx
   14509:      	addl	%ecx, %esi
   1450b:      	movl	%r12d, %edi
   1450e:      	subl	%esi, %edi
   14510:      	movl	%edi, 0x50(%rsp)
   14514:      	subq	%rsi, %rax
   14517:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1451d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14523:      	ja	0x16402 <generic_kprobe_path+0xba72>
   14529:      	cmpl	%r15d, %r12d
   1452c:      	jbe	0x14532 <generic_kprobe_path+0x9ba2>
   1452e:      	movb	$0x2f, (%rbx,%rax)
   14532:      	xorl	%edi, %edi
   14534:      	cmpl	%r15d, %r12d
   14537:      	seta	%dil
   1453b:      	movzbl	%cl, %esi
   1453e:      	addq	%rax, %rbx
   14541:      	addq	%rbx, %rdi
   14544:      	movl	$0x4, %eax
   14549:      	callq	*%rax
   1454b:      	movq	%rbx, 0x48(%rsp)
   14550:      	cmpl	%r15d, %r12d
   14553:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14559:      	movq	0x8(%rsp), %r12
   1455e:      	movq	%r12, 0x30(%rsp)
   14563:      	movq	0x38(%rsp), %rdx
   14568:      	movq	0x40(%rsp), %r15
   1456d:      	jmp	0x145c0 <generic_kprobe_path+0x9c30>
   1456f:      	leaq	0x10(%r15), %rdx
   14573:      	movl	$0x4, %eax
   14578:      	movq	%rbp, %rdi
   1457b:      	movl	$0x8, %esi
   14580:      	callq	*%rax
   14582:      	movq	0x40(%rsp), %rax
   14587:      	cmpq	(%rsp), %rax
   1458b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14591:      	addq	$0x18, %r15
   14595:      	movl	$0x4, %eax
   1459a:      	leaq	0x30(%rsp), %rdi
   1459f:      	movl	$0x8, %esi
   145a4:      	movq	%r15, %rdx
   145a7:      	callq	*%rax
   145a9:      	movq	(%rsp), %r15
   145ad:      	movq	%r15, 0x40(%rsp)
   145b2:      	leaq	0x20(%r15), %rdx
   145b6:      	movq	%rdx, 0x38(%rsp)
   145bb:      	movq	0x30(%rsp), %r12
   145c0:      	cmpq	0x18(%rsp), %r12
   145c5:      	jne	0x145d2 <generic_kprobe_path+0x9c42>
   145c7:      	cmpq	0x20(%rsp), %rdx
   145cc:      	je	0x163fd <generic_kprobe_path+0xba6d>
   145d2:      	movl	$0x4, %eax
   145d7:      	leaq	0x10(%rsp), %rdi
   145dc:      	movl	$0x8, %esi
   145e1:      	callq	*%rax
   145e3:      	cmpq	0x10(%rsp), %r12
   145e8:      	je	0x146e0 <generic_kprobe_path+0x9d50>
   145ee:      	leaq	0x18(%r12), %rbx
   145f3:      	movl	$0x4, %eax
   145f8:      	movq	%rbp, %rdi
   145fb:      	movl	$0x8, %esi
   14600:      	movq	%rbx, %rdx
   14603:      	callq	*%rax
   14605:      	cmpq	%r12, (%rsp)
   14609:      	je	0x146e0 <generic_kprobe_path+0x9d50>
   1460f:      	movl	$0x4, %eax
   14614:      	leaq	0x8(%rsp), %rdi
   14619:      	movl	$0x8, %esi
   1461e:      	movq	%rbx, %rdx
   14621:      	callq	*%rax
   14623:      	addq	$0x20, %r12
   14627:      	movl	$0x4, %eax
   1462c:      	leaq	0x58(%rsp), %rdi
   14631:      	movl	$0x10, %ecx
   14636:      	movl	$0x10, %esi
   1463b:      	movq	%r12, %rdx
   1463e:      	callq	*%rax
   14640:      	movq	0x28(%rsp), %rbx
   14645:      	movq	0x48(%rsp), %rax
   1464a:      	movl	0x5c(%rsp), %r15d
   1464f:      	subq	%rbx, %rax
   14652:      	movl	0x50(%rsp), %r12d
   14657:      	movl	%r15d, %edx
   1465a:      	subl	%r12d, %edx
   1465d:      	movl	$0x0, %ecx
   14662:      	cmovbl	%ecx, %edx
   14665:      	addq	0x60(%rsp), %rdx
   1466a:      	xorl	%esi, %esi
   1466c:      	cmpl	%r15d, %r12d
   1466f:      	seta	%sil
   14673:      	movl	%r15d, %ecx
   14676:      	cmovbl	%r12d, %ecx
   1467a:      	addl	%ecx, %esi
   1467c:      	movl	%r12d, %edi
   1467f:      	subl	%esi, %edi
   14681:      	movl	%edi, 0x50(%rsp)
   14685:      	subq	%rsi, %rax
   14688:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1468e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14694:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1469a:      	cmpl	%r15d, %r12d
   1469d:      	jbe	0x146a3 <generic_kprobe_path+0x9d13>
   1469f:      	movb	$0x2f, (%rbx,%rax)
   146a3:      	xorl	%edi, %edi
   146a5:      	cmpl	%r15d, %r12d
   146a8:      	seta	%dil
   146ac:      	movzbl	%cl, %esi
   146af:      	addq	%rax, %rbx
   146b2:      	addq	%rbx, %rdi
   146b5:      	movl	$0x4, %eax
   146ba:      	callq	*%rax
   146bc:      	movq	%rbx, 0x48(%rsp)
   146c1:      	cmpl	%r15d, %r12d
   146c4:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   146ca:      	movq	0x8(%rsp), %r12
   146cf:      	movq	%r12, 0x30(%rsp)
   146d4:      	movq	0x38(%rsp), %rdx
   146d9:      	movq	0x40(%rsp), %r15
   146de:      	jmp	0x14731 <generic_kprobe_path+0x9da1>
   146e0:      	leaq	0x10(%r15), %rdx
   146e4:      	movl	$0x4, %eax
   146e9:      	movq	%rbp, %rdi
   146ec:      	movl	$0x8, %esi
   146f1:      	callq	*%rax
   146f3:      	movq	0x40(%rsp), %rax
   146f8:      	cmpq	(%rsp), %rax
   146fc:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14702:      	addq	$0x18, %r15
   14706:      	movl	$0x4, %eax
   1470b:      	leaq	0x30(%rsp), %rdi
   14710:      	movl	$0x8, %esi
   14715:      	movq	%r15, %rdx
   14718:      	callq	*%rax
   1471a:      	movq	(%rsp), %r15
   1471e:      	movq	%r15, 0x40(%rsp)
   14723:      	leaq	0x20(%r15), %rdx
   14727:      	movq	%rdx, 0x38(%rsp)
   1472c:      	movq	0x30(%rsp), %r12
   14731:      	cmpq	0x18(%rsp), %r12
   14736:      	jne	0x14743 <generic_kprobe_path+0x9db3>
   14738:      	cmpq	0x20(%rsp), %rdx
   1473d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14743:      	movl	$0x4, %eax
   14748:      	leaq	0x10(%rsp), %rdi
   1474d:      	movl	$0x8, %esi
   14752:      	callq	*%rax
   14754:      	cmpq	0x10(%rsp), %r12
   14759:      	je	0x14851 <generic_kprobe_path+0x9ec1>
   1475f:      	leaq	0x18(%r12), %rbx
   14764:      	movl	$0x4, %eax
   14769:      	movq	%rbp, %rdi
   1476c:      	movl	$0x8, %esi
   14771:      	movq	%rbx, %rdx
   14774:      	callq	*%rax
   14776:      	cmpq	%r12, (%rsp)
   1477a:      	je	0x14851 <generic_kprobe_path+0x9ec1>
   14780:      	movl	$0x4, %eax
   14785:      	leaq	0x8(%rsp), %rdi
   1478a:      	movl	$0x8, %esi
   1478f:      	movq	%rbx, %rdx
   14792:      	callq	*%rax
   14794:      	addq	$0x20, %r12
   14798:      	movl	$0x4, %eax
   1479d:      	leaq	0x58(%rsp), %rdi
   147a2:      	movl	$0x10, %ecx
   147a7:      	movl	$0x10, %esi
   147ac:      	movq	%r12, %rdx
   147af:      	callq	*%rax
   147b1:      	movq	0x28(%rsp), %rbx
   147b6:      	movq	0x48(%rsp), %rax
   147bb:      	movl	0x5c(%rsp), %r15d
   147c0:      	subq	%rbx, %rax
   147c3:      	movl	0x50(%rsp), %r12d
   147c8:      	movl	%r15d, %edx
   147cb:      	subl	%r12d, %edx
   147ce:      	movl	$0x0, %ecx
   147d3:      	cmovbl	%ecx, %edx
   147d6:      	addq	0x60(%rsp), %rdx
   147db:      	xorl	%esi, %esi
   147dd:      	cmpl	%r15d, %r12d
   147e0:      	seta	%sil
   147e4:      	movl	%r15d, %ecx
   147e7:      	cmovbl	%r12d, %ecx
   147eb:      	addl	%ecx, %esi
   147ed:      	movl	%r12d, %edi
   147f0:      	subl	%esi, %edi
   147f2:      	movl	%edi, 0x50(%rsp)
   147f6:      	subq	%rsi, %rax
   147f9:      	jb	0x16402 <generic_kprobe_path+0xba72>
   147ff:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14805:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1480b:      	cmpl	%r15d, %r12d
   1480e:      	jbe	0x14814 <generic_kprobe_path+0x9e84>
   14810:      	movb	$0x2f, (%rbx,%rax)
   14814:      	xorl	%edi, %edi
   14816:      	cmpl	%r15d, %r12d
   14819:      	seta	%dil
   1481d:      	movzbl	%cl, %esi
   14820:      	addq	%rax, %rbx
   14823:      	addq	%rbx, %rdi
   14826:      	movl	$0x4, %eax
   1482b:      	callq	*%rax
   1482d:      	movq	%rbx, 0x48(%rsp)
   14832:      	cmpl	%r15d, %r12d
   14835:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1483b:      	movq	0x8(%rsp), %r12
   14840:      	movq	%r12, 0x30(%rsp)
   14845:      	movq	0x38(%rsp), %rdx
   1484a:      	movq	0x40(%rsp), %r15
   1484f:      	jmp	0x148a2 <generic_kprobe_path+0x9f12>
   14851:      	leaq	0x10(%r15), %rdx
   14855:      	movl	$0x4, %eax
   1485a:      	movq	%rbp, %rdi
   1485d:      	movl	$0x8, %esi
   14862:      	callq	*%rax
   14864:      	movq	0x40(%rsp), %rax
   14869:      	cmpq	(%rsp), %rax
   1486d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14873:      	addq	$0x18, %r15
   14877:      	movl	$0x4, %eax
   1487c:      	leaq	0x30(%rsp), %rdi
   14881:      	movl	$0x8, %esi
   14886:      	movq	%r15, %rdx
   14889:      	callq	*%rax
   1488b:      	movq	(%rsp), %r15
   1488f:      	movq	%r15, 0x40(%rsp)
   14894:      	leaq	0x20(%r15), %rdx
   14898:      	movq	%rdx, 0x38(%rsp)
   1489d:      	movq	0x30(%rsp), %r12
   148a2:      	cmpq	0x18(%rsp), %r12
   148a7:      	jne	0x148b4 <generic_kprobe_path+0x9f24>
   148a9:      	cmpq	0x20(%rsp), %rdx
   148ae:      	je	0x163fd <generic_kprobe_path+0xba6d>
   148b4:      	movl	$0x4, %eax
   148b9:      	leaq	0x10(%rsp), %rdi
   148be:      	movl	$0x8, %esi
   148c3:      	callq	*%rax
   148c5:      	cmpq	0x10(%rsp), %r12
   148ca:      	je	0x149c2 <generic_kprobe_path+0xa032>
   148d0:      	leaq	0x18(%r12), %rbx
   148d5:      	movl	$0x4, %eax
   148da:      	movq	%rbp, %rdi
   148dd:      	movl	$0x8, %esi
   148e2:      	movq	%rbx, %rdx
   148e5:      	callq	*%rax
   148e7:      	cmpq	%r12, (%rsp)
   148eb:      	je	0x149c2 <generic_kprobe_path+0xa032>
   148f1:      	movl	$0x4, %eax
   148f6:      	leaq	0x8(%rsp), %rdi
   148fb:      	movl	$0x8, %esi
   14900:      	movq	%rbx, %rdx
   14903:      	callq	*%rax
   14905:      	addq	$0x20, %r12
   14909:      	movl	$0x4, %eax
   1490e:      	leaq	0x58(%rsp), %rdi
   14913:      	movl	$0x10, %ecx
   14918:      	movl	$0x10, %esi
   1491d:      	movq	%r12, %rdx
   14920:      	callq	*%rax
   14922:      	movq	0x28(%rsp), %rbx
   14927:      	movq	0x48(%rsp), %rax
   1492c:      	movl	0x5c(%rsp), %r15d
   14931:      	subq	%rbx, %rax
   14934:      	movl	0x50(%rsp), %r12d
   14939:      	movl	%r15d, %edx
   1493c:      	subl	%r12d, %edx
   1493f:      	movl	$0x0, %ecx
   14944:      	cmovbl	%ecx, %edx
   14947:      	addq	0x60(%rsp), %rdx
   1494c:      	xorl	%esi, %esi
   1494e:      	cmpl	%r15d, %r12d
   14951:      	seta	%sil
   14955:      	movl	%r15d, %ecx
   14958:      	cmovbl	%r12d, %ecx
   1495c:      	addl	%ecx, %esi
   1495e:      	movl	%r12d, %edi
   14961:      	subl	%esi, %edi
   14963:      	movl	%edi, 0x50(%rsp)
   14967:      	subq	%rsi, %rax
   1496a:      	jb	0x16402 <generic_kprobe_path+0xba72>
   14970:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14976:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1497c:      	cmpl	%r15d, %r12d
   1497f:      	jbe	0x14985 <generic_kprobe_path+0x9ff5>
   14981:      	movb	$0x2f, (%rbx,%rax)
   14985:      	xorl	%edi, %edi
   14987:      	cmpl	%r15d, %r12d
   1498a:      	seta	%dil
   1498e:      	movzbl	%cl, %esi
   14991:      	addq	%rax, %rbx
   14994:      	addq	%rbx, %rdi
   14997:      	movl	$0x4, %eax
   1499c:      	callq	*%rax
   1499e:      	movq	%rbx, 0x48(%rsp)
   149a3:      	cmpl	%r15d, %r12d
   149a6:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   149ac:      	movq	0x8(%rsp), %r12
   149b1:      	movq	%r12, 0x30(%rsp)
   149b6:      	movq	0x38(%rsp), %rdx
   149bb:      	movq	0x40(%rsp), %r15
   149c0:      	jmp	0x14a13 <generic_kprobe_path+0xa083>
   149c2:      	leaq	0x10(%r15), %rdx
   149c6:      	movl	$0x4, %eax
   149cb:      	movq	%rbp, %rdi
   149ce:      	movl	$0x8, %esi
   149d3:      	callq	*%rax
   149d5:      	movq	0x40(%rsp), %rax
   149da:      	cmpq	(%rsp), %rax
   149de:      	je	0x163fd <generic_kprobe_path+0xba6d>
   149e4:      	addq	$0x18, %r15
   149e8:      	movl	$0x4, %eax
   149ed:      	leaq	0x30(%rsp), %rdi
   149f2:      	movl	$0x8, %esi
   149f7:      	movq	%r15, %rdx
   149fa:      	callq	*%rax
   149fc:      	movq	(%rsp), %r15
   14a00:      	movq	%r15, 0x40(%rsp)
   14a05:      	leaq	0x20(%r15), %rdx
   14a09:      	movq	%rdx, 0x38(%rsp)
   14a0e:      	movq	0x30(%rsp), %r12
   14a13:      	cmpq	0x18(%rsp), %r12
   14a18:      	jne	0x14a25 <generic_kprobe_path+0xa095>
   14a1a:      	cmpq	0x20(%rsp), %rdx
   14a1f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14a25:      	movl	$0x4, %eax
   14a2a:      	leaq	0x10(%rsp), %rdi
   14a2f:      	movl	$0x8, %esi
   14a34:      	callq	*%rax
   14a36:      	cmpq	0x10(%rsp), %r12
   14a3b:      	je	0x14b33 <generic_kprobe_path+0xa1a3>
   14a41:      	leaq	0x18(%r12), %rbx
   14a46:      	movl	$0x4, %eax
   14a4b:      	movq	%rbp, %rdi
   14a4e:      	movl	$0x8, %esi
   14a53:      	movq	%rbx, %rdx
   14a56:      	callq	*%rax
   14a58:      	cmpq	%r12, (%rsp)
   14a5c:      	je	0x14b33 <generic_kprobe_path+0xa1a3>
   14a62:      	movl	$0x4, %eax
   14a67:      	leaq	0x8(%rsp), %rdi
   14a6c:      	movl	$0x8, %esi
   14a71:      	movq	%rbx, %rdx
   14a74:      	callq	*%rax
   14a76:      	addq	$0x20, %r12
   14a7a:      	movl	$0x4, %eax
   14a7f:      	leaq	0x58(%rsp), %rdi
   14a84:      	movl	$0x10, %ecx
   14a89:      	movl	$0x10, %esi
   14a8e:      	movq	%r12, %rdx
   14a91:      	callq	*%rax
   14a93:      	movq	0x28(%rsp), %rbx
   14a98:      	movq	0x48(%rsp), %rax
   14a9d:      	movl	0x5c(%rsp), %r15d
   14aa2:      	subq	%rbx, %rax
   14aa5:      	movl	0x50(%rsp), %r12d
   14aaa:      	movl	%r15d, %edx
   14aad:      	subl	%r12d, %edx
   14ab0:      	movl	$0x0, %ecx
   14ab5:      	cmovbl	%ecx, %edx
   14ab8:      	addq	0x60(%rsp), %rdx
   14abd:      	xorl	%esi, %esi
   14abf:      	cmpl	%r15d, %r12d
   14ac2:      	seta	%sil
   14ac6:      	movl	%r15d, %ecx
   14ac9:      	cmovbl	%r12d, %ecx
   14acd:      	addl	%ecx, %esi
   14acf:      	movl	%r12d, %edi
   14ad2:      	subl	%esi, %edi
   14ad4:      	movl	%edi, 0x50(%rsp)
   14ad8:      	subq	%rsi, %rax
   14adb:      	jb	0x16402 <generic_kprobe_path+0xba72>
   14ae1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14ae7:      	ja	0x16402 <generic_kprobe_path+0xba72>
   14aed:      	cmpl	%r15d, %r12d
   14af0:      	jbe	0x14af6 <generic_kprobe_path+0xa166>
   14af2:      	movb	$0x2f, (%rbx,%rax)
   14af6:      	xorl	%edi, %edi
   14af8:      	cmpl	%r15d, %r12d
   14afb:      	seta	%dil
   14aff:      	movzbl	%cl, %esi
   14b02:      	addq	%rax, %rbx
   14b05:      	addq	%rbx, %rdi
   14b08:      	movl	$0x4, %eax
   14b0d:      	callq	*%rax
   14b0f:      	movq	%rbx, 0x48(%rsp)
   14b14:      	cmpl	%r15d, %r12d
   14b17:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14b1d:      	movq	0x8(%rsp), %r12
   14b22:      	movq	%r12, 0x30(%rsp)
   14b27:      	movq	0x38(%rsp), %rdx
   14b2c:      	movq	0x40(%rsp), %r15
   14b31:      	jmp	0x14b84 <generic_kprobe_path+0xa1f4>
   14b33:      	leaq	0x10(%r15), %rdx
   14b37:      	movl	$0x4, %eax
   14b3c:      	movq	%rbp, %rdi
   14b3f:      	movl	$0x8, %esi
   14b44:      	callq	*%rax
   14b46:      	movq	0x40(%rsp), %rax
   14b4b:      	cmpq	(%rsp), %rax
   14b4f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14b55:      	addq	$0x18, %r15
   14b59:      	movl	$0x4, %eax
   14b5e:      	leaq	0x30(%rsp), %rdi
   14b63:      	movl	$0x8, %esi
   14b68:      	movq	%r15, %rdx
   14b6b:      	callq	*%rax
   14b6d:      	movq	(%rsp), %r15
   14b71:      	movq	%r15, 0x40(%rsp)
   14b76:      	leaq	0x20(%r15), %rdx
   14b7a:      	movq	%rdx, 0x38(%rsp)
   14b7f:      	movq	0x30(%rsp), %r12
   14b84:      	cmpq	0x18(%rsp), %r12
   14b89:      	jne	0x14b96 <generic_kprobe_path+0xa206>
   14b8b:      	cmpq	0x20(%rsp), %rdx
   14b90:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14b96:      	movl	$0x4, %eax
   14b9b:      	leaq	0x10(%rsp), %rdi
   14ba0:      	movl	$0x8, %esi
   14ba5:      	callq	*%rax
   14ba7:      	cmpq	0x10(%rsp), %r12
   14bac:      	je	0x14ca4 <generic_kprobe_path+0xa314>
   14bb2:      	leaq	0x18(%r12), %rbx
   14bb7:      	movl	$0x4, %eax
   14bbc:      	movq	%rbp, %rdi
   14bbf:      	movl	$0x8, %esi
   14bc4:      	movq	%rbx, %rdx
   14bc7:      	callq	*%rax
   14bc9:      	cmpq	%r12, (%rsp)
   14bcd:      	je	0x14ca4 <generic_kprobe_path+0xa314>
   14bd3:      	movl	$0x4, %eax
   14bd8:      	leaq	0x8(%rsp), %rdi
   14bdd:      	movl	$0x8, %esi
   14be2:      	movq	%rbx, %rdx
   14be5:      	callq	*%rax
   14be7:      	addq	$0x20, %r12
   14beb:      	movl	$0x4, %eax
   14bf0:      	leaq	0x58(%rsp), %rdi
   14bf5:      	movl	$0x10, %ecx
   14bfa:      	movl	$0x10, %esi
   14bff:      	movq	%r12, %rdx
   14c02:      	callq	*%rax
   14c04:      	movq	0x28(%rsp), %rbx
   14c09:      	movq	0x48(%rsp), %rax
   14c0e:      	movl	0x5c(%rsp), %r15d
   14c13:      	subq	%rbx, %rax
   14c16:      	movl	0x50(%rsp), %r12d
   14c1b:      	movl	%r15d, %edx
   14c1e:      	subl	%r12d, %edx
   14c21:      	movl	$0x0, %ecx
   14c26:      	cmovbl	%ecx, %edx
   14c29:      	addq	0x60(%rsp), %rdx
   14c2e:      	xorl	%esi, %esi
   14c30:      	cmpl	%r15d, %r12d
   14c33:      	seta	%sil
   14c37:      	movl	%r15d, %ecx
   14c3a:      	cmovbl	%r12d, %ecx
   14c3e:      	addl	%ecx, %esi
   14c40:      	movl	%r12d, %edi
   14c43:      	subl	%esi, %edi
   14c45:      	movl	%edi, 0x50(%rsp)
   14c49:      	subq	%rsi, %rax
   14c4c:      	jb	0x16402 <generic_kprobe_path+0xba72>
   14c52:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14c58:      	ja	0x16402 <generic_kprobe_path+0xba72>
   14c5e:      	cmpl	%r15d, %r12d
   14c61:      	jbe	0x14c67 <generic_kprobe_path+0xa2d7>
   14c63:      	movb	$0x2f, (%rbx,%rax)
   14c67:      	xorl	%edi, %edi
   14c69:      	cmpl	%r15d, %r12d
   14c6c:      	seta	%dil
   14c70:      	movzbl	%cl, %esi
   14c73:      	addq	%rax, %rbx
   14c76:      	addq	%rbx, %rdi
   14c79:      	movl	$0x4, %eax
   14c7e:      	callq	*%rax
   14c80:      	movq	%rbx, 0x48(%rsp)
   14c85:      	cmpl	%r15d, %r12d
   14c88:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14c8e:      	movq	0x8(%rsp), %r12
   14c93:      	movq	%r12, 0x30(%rsp)
   14c98:      	movq	0x38(%rsp), %rdx
   14c9d:      	movq	0x40(%rsp), %r15
   14ca2:      	jmp	0x14cf5 <generic_kprobe_path+0xa365>
   14ca4:      	leaq	0x10(%r15), %rdx
   14ca8:      	movl	$0x4, %eax
   14cad:      	movq	%rbp, %rdi
   14cb0:      	movl	$0x8, %esi
   14cb5:      	callq	*%rax
   14cb7:      	movq	0x40(%rsp), %rax
   14cbc:      	cmpq	(%rsp), %rax
   14cc0:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14cc6:      	addq	$0x18, %r15
   14cca:      	movl	$0x4, %eax
   14ccf:      	leaq	0x30(%rsp), %rdi
   14cd4:      	movl	$0x8, %esi
   14cd9:      	movq	%r15, %rdx
   14cdc:      	callq	*%rax
   14cde:      	movq	(%rsp), %r15
   14ce2:      	movq	%r15, 0x40(%rsp)
   14ce7:      	leaq	0x20(%r15), %rdx
   14ceb:      	movq	%rdx, 0x38(%rsp)
   14cf0:      	movq	0x30(%rsp), %r12
   14cf5:      	cmpq	0x18(%rsp), %r12
   14cfa:      	jne	0x14d07 <generic_kprobe_path+0xa377>
   14cfc:      	cmpq	0x20(%rsp), %rdx
   14d01:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14d07:      	movl	$0x4, %eax
   14d0c:      	leaq	0x10(%rsp), %rdi
   14d11:      	movl	$0x8, %esi
   14d16:      	callq	*%rax
   14d18:      	cmpq	0x10(%rsp), %r12
   14d1d:      	je	0x14e15 <generic_kprobe_path+0xa485>
   14d23:      	leaq	0x18(%r12), %rbx
   14d28:      	movl	$0x4, %eax
   14d2d:      	movq	%rbp, %rdi
   14d30:      	movl	$0x8, %esi
   14d35:      	movq	%rbx, %rdx
   14d38:      	callq	*%rax
   14d3a:      	cmpq	%r12, (%rsp)
   14d3e:      	je	0x14e15 <generic_kprobe_path+0xa485>
   14d44:      	movl	$0x4, %eax
   14d49:      	leaq	0x8(%rsp), %rdi
   14d4e:      	movl	$0x8, %esi
   14d53:      	movq	%rbx, %rdx
   14d56:      	callq	*%rax
   14d58:      	addq	$0x20, %r12
   14d5c:      	movl	$0x4, %eax
   14d61:      	leaq	0x58(%rsp), %rdi
   14d66:      	movl	$0x10, %ecx
   14d6b:      	movl	$0x10, %esi
   14d70:      	movq	%r12, %rdx
   14d73:      	callq	*%rax
   14d75:      	movq	0x28(%rsp), %rbx
   14d7a:      	movq	0x48(%rsp), %rax
   14d7f:      	movl	0x5c(%rsp), %r15d
   14d84:      	subq	%rbx, %rax
   14d87:      	movl	0x50(%rsp), %r12d
   14d8c:      	movl	%r15d, %edx
   14d8f:      	subl	%r12d, %edx
   14d92:      	movl	$0x0, %ecx
   14d97:      	cmovbl	%ecx, %edx
   14d9a:      	addq	0x60(%rsp), %rdx
   14d9f:      	xorl	%esi, %esi
   14da1:      	cmpl	%r15d, %r12d
   14da4:      	seta	%sil
   14da8:      	movl	%r15d, %ecx
   14dab:      	cmovbl	%r12d, %ecx
   14daf:      	addl	%ecx, %esi
   14db1:      	movl	%r12d, %edi
   14db4:      	subl	%esi, %edi
   14db6:      	movl	%edi, 0x50(%rsp)
   14dba:      	subq	%rsi, %rax
   14dbd:      	jb	0x16402 <generic_kprobe_path+0xba72>
   14dc3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14dc9:      	ja	0x16402 <generic_kprobe_path+0xba72>
   14dcf:      	cmpl	%r15d, %r12d
   14dd2:      	jbe	0x14dd8 <generic_kprobe_path+0xa448>
   14dd4:      	movb	$0x2f, (%rbx,%rax)
   14dd8:      	xorl	%edi, %edi
   14dda:      	cmpl	%r15d, %r12d
   14ddd:      	seta	%dil
   14de1:      	movzbl	%cl, %esi
   14de4:      	addq	%rax, %rbx
   14de7:      	addq	%rbx, %rdi
   14dea:      	movl	$0x4, %eax
   14def:      	callq	*%rax
   14df1:      	movq	%rbx, 0x48(%rsp)
   14df6:      	cmpl	%r15d, %r12d
   14df9:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14dff:      	movq	0x8(%rsp), %r12
   14e04:      	movq	%r12, 0x30(%rsp)
   14e09:      	movq	0x38(%rsp), %rdx
   14e0e:      	movq	0x40(%rsp), %r15
   14e13:      	jmp	0x14e66 <generic_kprobe_path+0xa4d6>
   14e15:      	leaq	0x10(%r15), %rdx
   14e19:      	movl	$0x4, %eax
   14e1e:      	movq	%rbp, %rdi
   14e21:      	movl	$0x8, %esi
   14e26:      	callq	*%rax
   14e28:      	movq	0x40(%rsp), %rax
   14e2d:      	cmpq	(%rsp), %rax
   14e31:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14e37:      	addq	$0x18, %r15
   14e3b:      	movl	$0x4, %eax
   14e40:      	leaq	0x30(%rsp), %rdi
   14e45:      	movl	$0x8, %esi
   14e4a:      	movq	%r15, %rdx
   14e4d:      	callq	*%rax
   14e4f:      	movq	(%rsp), %r15
   14e53:      	movq	%r15, 0x40(%rsp)
   14e58:      	leaq	0x20(%r15), %rdx
   14e5c:      	movq	%rdx, 0x38(%rsp)
   14e61:      	movq	0x30(%rsp), %r12
   14e66:      	cmpq	0x18(%rsp), %r12
   14e6b:      	jne	0x14e78 <generic_kprobe_path+0xa4e8>
   14e6d:      	cmpq	0x20(%rsp), %rdx
   14e72:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14e78:      	movl	$0x4, %eax
   14e7d:      	leaq	0x10(%rsp), %rdi
   14e82:      	movl	$0x8, %esi
   14e87:      	callq	*%rax
   14e89:      	cmpq	0x10(%rsp), %r12
   14e8e:      	je	0x14f86 <generic_kprobe_path+0xa5f6>
   14e94:      	leaq	0x18(%r12), %rbx
   14e99:      	movl	$0x4, %eax
   14e9e:      	movq	%rbp, %rdi
   14ea1:      	movl	$0x8, %esi
   14ea6:      	movq	%rbx, %rdx
   14ea9:      	callq	*%rax
   14eab:      	cmpq	%r12, (%rsp)
   14eaf:      	je	0x14f86 <generic_kprobe_path+0xa5f6>
   14eb5:      	movl	$0x4, %eax
   14eba:      	leaq	0x8(%rsp), %rdi
   14ebf:      	movl	$0x8, %esi
   14ec4:      	movq	%rbx, %rdx
   14ec7:      	callq	*%rax
   14ec9:      	addq	$0x20, %r12
   14ecd:      	movl	$0x4, %eax
   14ed2:      	leaq	0x58(%rsp), %rdi
   14ed7:      	movl	$0x10, %ecx
   14edc:      	movl	$0x10, %esi
   14ee1:      	movq	%r12, %rdx
   14ee4:      	callq	*%rax
   14ee6:      	movq	0x28(%rsp), %rbx
   14eeb:      	movq	0x48(%rsp), %rax
   14ef0:      	movl	0x5c(%rsp), %r15d
   14ef5:      	subq	%rbx, %rax
   14ef8:      	movl	0x50(%rsp), %r12d
   14efd:      	movl	%r15d, %edx
   14f00:      	subl	%r12d, %edx
   14f03:      	movl	$0x0, %ecx
   14f08:      	cmovbl	%ecx, %edx
   14f0b:      	addq	0x60(%rsp), %rdx
   14f10:      	xorl	%esi, %esi
   14f12:      	cmpl	%r15d, %r12d
   14f15:      	seta	%sil
   14f19:      	movl	%r15d, %ecx
   14f1c:      	cmovbl	%r12d, %ecx
   14f20:      	addl	%ecx, %esi
   14f22:      	movl	%r12d, %edi
   14f25:      	subl	%esi, %edi
   14f27:      	movl	%edi, 0x50(%rsp)
   14f2b:      	subq	%rsi, %rax
   14f2e:      	jb	0x16402 <generic_kprobe_path+0xba72>
   14f34:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14f3a:      	ja	0x16402 <generic_kprobe_path+0xba72>
   14f40:      	cmpl	%r15d, %r12d
   14f43:      	jbe	0x14f49 <generic_kprobe_path+0xa5b9>
   14f45:      	movb	$0x2f, (%rbx,%rax)
   14f49:      	xorl	%edi, %edi
   14f4b:      	cmpl	%r15d, %r12d
   14f4e:      	seta	%dil
   14f52:      	movzbl	%cl, %esi
   14f55:      	addq	%rax, %rbx
   14f58:      	addq	%rbx, %rdi
   14f5b:      	movl	$0x4, %eax
   14f60:      	callq	*%rax
   14f62:      	movq	%rbx, 0x48(%rsp)
   14f67:      	cmpl	%r15d, %r12d
   14f6a:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   14f70:      	movq	0x8(%rsp), %r12
   14f75:      	movq	%r12, 0x30(%rsp)
   14f7a:      	movq	0x38(%rsp), %rdx
   14f7f:      	movq	0x40(%rsp), %r15
   14f84:      	jmp	0x14fd7 <generic_kprobe_path+0xa647>
   14f86:      	leaq	0x10(%r15), %rdx
   14f8a:      	movl	$0x4, %eax
   14f8f:      	movq	%rbp, %rdi
   14f92:      	movl	$0x8, %esi
   14f97:      	callq	*%rax
   14f99:      	movq	0x40(%rsp), %rax
   14f9e:      	cmpq	(%rsp), %rax
   14fa2:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14fa8:      	addq	$0x18, %r15
   14fac:      	movl	$0x4, %eax
   14fb1:      	leaq	0x30(%rsp), %rdi
   14fb6:      	movl	$0x8, %esi
   14fbb:      	movq	%r15, %rdx
   14fbe:      	callq	*%rax
   14fc0:      	movq	(%rsp), %r15
   14fc4:      	movq	%r15, 0x40(%rsp)
   14fc9:      	leaq	0x20(%r15), %rdx
   14fcd:      	movq	%rdx, 0x38(%rsp)
   14fd2:      	movq	0x30(%rsp), %r12
   14fd7:      	cmpq	0x18(%rsp), %r12
   14fdc:      	jne	0x14fe9 <generic_kprobe_path+0xa659>
   14fde:      	cmpq	0x20(%rsp), %rdx
   14fe3:      	je	0x163fd <generic_kprobe_path+0xba6d>
   14fe9:      	movl	$0x4, %eax
   14fee:      	leaq	0x10(%rsp), %rdi
   14ff3:      	movl	$0x8, %esi
   14ff8:      	callq	*%rax
   14ffa:      	cmpq	0x10(%rsp), %r12
   14fff:      	je	0x150f7 <generic_kprobe_path+0xa767>
   15005:      	leaq	0x18(%r12), %rbx
   1500a:      	movl	$0x4, %eax
   1500f:      	movq	%rbp, %rdi
   15012:      	movl	$0x8, %esi
   15017:      	movq	%rbx, %rdx
   1501a:      	callq	*%rax
   1501c:      	cmpq	%r12, (%rsp)
   15020:      	je	0x150f7 <generic_kprobe_path+0xa767>
   15026:      	movl	$0x4, %eax
   1502b:      	leaq	0x8(%rsp), %rdi
   15030:      	movl	$0x8, %esi
   15035:      	movq	%rbx, %rdx
   15038:      	callq	*%rax
   1503a:      	addq	$0x20, %r12
   1503e:      	movl	$0x4, %eax
   15043:      	leaq	0x58(%rsp), %rdi
   15048:      	movl	$0x10, %ecx
   1504d:      	movl	$0x10, %esi
   15052:      	movq	%r12, %rdx
   15055:      	callq	*%rax
   15057:      	movq	0x28(%rsp), %rbx
   1505c:      	movq	0x48(%rsp), %rax
   15061:      	movl	0x5c(%rsp), %r15d
   15066:      	subq	%rbx, %rax
   15069:      	movl	0x50(%rsp), %r12d
   1506e:      	movl	%r15d, %edx
   15071:      	subl	%r12d, %edx
   15074:      	movl	$0x0, %ecx
   15079:      	cmovbl	%ecx, %edx
   1507c:      	addq	0x60(%rsp), %rdx
   15081:      	xorl	%esi, %esi
   15083:      	cmpl	%r15d, %r12d
   15086:      	seta	%sil
   1508a:      	movl	%r15d, %ecx
   1508d:      	cmovbl	%r12d, %ecx
   15091:      	addl	%ecx, %esi
   15093:      	movl	%r12d, %edi
   15096:      	subl	%esi, %edi
   15098:      	movl	%edi, 0x50(%rsp)
   1509c:      	subq	%rsi, %rax
   1509f:      	jb	0x16402 <generic_kprobe_path+0xba72>
   150a5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   150ab:      	ja	0x16402 <generic_kprobe_path+0xba72>
   150b1:      	cmpl	%r15d, %r12d
   150b4:      	jbe	0x150ba <generic_kprobe_path+0xa72a>
   150b6:      	movb	$0x2f, (%rbx,%rax)
   150ba:      	xorl	%edi, %edi
   150bc:      	cmpl	%r15d, %r12d
   150bf:      	seta	%dil
   150c3:      	movzbl	%cl, %esi
   150c6:      	addq	%rax, %rbx
   150c9:      	addq	%rbx, %rdi
   150cc:      	movl	$0x4, %eax
   150d1:      	callq	*%rax
   150d3:      	movq	%rbx, 0x48(%rsp)
   150d8:      	cmpl	%r15d, %r12d
   150db:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   150e1:      	movq	0x8(%rsp), %r12
   150e6:      	movq	%r12, 0x30(%rsp)
   150eb:      	movq	0x38(%rsp), %rdx
   150f0:      	movq	0x40(%rsp), %r15
   150f5:      	jmp	0x15148 <generic_kprobe_path+0xa7b8>
   150f7:      	leaq	0x10(%r15), %rdx
   150fb:      	movl	$0x4, %eax
   15100:      	movq	%rbp, %rdi
   15103:      	movl	$0x8, %esi
   15108:      	callq	*%rax
   1510a:      	movq	0x40(%rsp), %rax
   1510f:      	cmpq	(%rsp), %rax
   15113:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15119:      	addq	$0x18, %r15
   1511d:      	movl	$0x4, %eax
   15122:      	leaq	0x30(%rsp), %rdi
   15127:      	movl	$0x8, %esi
   1512c:      	movq	%r15, %rdx
   1512f:      	callq	*%rax
   15131:      	movq	(%rsp), %r15
   15135:      	movq	%r15, 0x40(%rsp)
   1513a:      	leaq	0x20(%r15), %rdx
   1513e:      	movq	%rdx, 0x38(%rsp)
   15143:      	movq	0x30(%rsp), %r12
   15148:      	cmpq	0x18(%rsp), %r12
   1514d:      	jne	0x1515a <generic_kprobe_path+0xa7ca>
   1514f:      	cmpq	0x20(%rsp), %rdx
   15154:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1515a:      	movl	$0x4, %eax
   1515f:      	leaq	0x10(%rsp), %rdi
   15164:      	movl	$0x8, %esi
   15169:      	callq	*%rax
   1516b:      	cmpq	0x10(%rsp), %r12
   15170:      	je	0x15268 <generic_kprobe_path+0xa8d8>
   15176:      	leaq	0x18(%r12), %rbx
   1517b:      	movl	$0x4, %eax
   15180:      	movq	%rbp, %rdi
   15183:      	movl	$0x8, %esi
   15188:      	movq	%rbx, %rdx
   1518b:      	callq	*%rax
   1518d:      	cmpq	%r12, (%rsp)
   15191:      	je	0x15268 <generic_kprobe_path+0xa8d8>
   15197:      	movl	$0x4, %eax
   1519c:      	leaq	0x8(%rsp), %rdi
   151a1:      	movl	$0x8, %esi
   151a6:      	movq	%rbx, %rdx
   151a9:      	callq	*%rax
   151ab:      	addq	$0x20, %r12
   151af:      	movl	$0x4, %eax
   151b4:      	leaq	0x58(%rsp), %rdi
   151b9:      	movl	$0x10, %ecx
   151be:      	movl	$0x10, %esi
   151c3:      	movq	%r12, %rdx
   151c6:      	callq	*%rax
   151c8:      	movq	0x28(%rsp), %rbx
   151cd:      	movq	0x48(%rsp), %rax
   151d2:      	movl	0x5c(%rsp), %r15d
   151d7:      	subq	%rbx, %rax
   151da:      	movl	0x50(%rsp), %r12d
   151df:      	movl	%r15d, %edx
   151e2:      	subl	%r12d, %edx
   151e5:      	movl	$0x0, %ecx
   151ea:      	cmovbl	%ecx, %edx
   151ed:      	addq	0x60(%rsp), %rdx
   151f2:      	xorl	%esi, %esi
   151f4:      	cmpl	%r15d, %r12d
   151f7:      	seta	%sil
   151fb:      	movl	%r15d, %ecx
   151fe:      	cmovbl	%r12d, %ecx
   15202:      	addl	%ecx, %esi
   15204:      	movl	%r12d, %edi
   15207:      	subl	%esi, %edi
   15209:      	movl	%edi, 0x50(%rsp)
   1520d:      	subq	%rsi, %rax
   15210:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15216:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1521c:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15222:      	cmpl	%r15d, %r12d
   15225:      	jbe	0x1522b <generic_kprobe_path+0xa89b>
   15227:      	movb	$0x2f, (%rbx,%rax)
   1522b:      	xorl	%edi, %edi
   1522d:      	cmpl	%r15d, %r12d
   15230:      	seta	%dil
   15234:      	movzbl	%cl, %esi
   15237:      	addq	%rax, %rbx
   1523a:      	addq	%rbx, %rdi
   1523d:      	movl	$0x4, %eax
   15242:      	callq	*%rax
   15244:      	movq	%rbx, 0x48(%rsp)
   15249:      	cmpl	%r15d, %r12d
   1524c:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15252:      	movq	0x8(%rsp), %r12
   15257:      	movq	%r12, 0x30(%rsp)
   1525c:      	movq	0x38(%rsp), %rdx
   15261:      	movq	0x40(%rsp), %r15
   15266:      	jmp	0x152b9 <generic_kprobe_path+0xa929>
   15268:      	leaq	0x10(%r15), %rdx
   1526c:      	movl	$0x4, %eax
   15271:      	movq	%rbp, %rdi
   15274:      	movl	$0x8, %esi
   15279:      	callq	*%rax
   1527b:      	movq	0x40(%rsp), %rax
   15280:      	cmpq	(%rsp), %rax
   15284:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1528a:      	addq	$0x18, %r15
   1528e:      	movl	$0x4, %eax
   15293:      	leaq	0x30(%rsp), %rdi
   15298:      	movl	$0x8, %esi
   1529d:      	movq	%r15, %rdx
   152a0:      	callq	*%rax
   152a2:      	movq	(%rsp), %r15
   152a6:      	movq	%r15, 0x40(%rsp)
   152ab:      	leaq	0x20(%r15), %rdx
   152af:      	movq	%rdx, 0x38(%rsp)
   152b4:      	movq	0x30(%rsp), %r12
   152b9:      	cmpq	0x18(%rsp), %r12
   152be:      	jne	0x152cb <generic_kprobe_path+0xa93b>
   152c0:      	cmpq	0x20(%rsp), %rdx
   152c5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   152cb:      	movl	$0x4, %eax
   152d0:      	leaq	0x10(%rsp), %rdi
   152d5:      	movl	$0x8, %esi
   152da:      	callq	*%rax
   152dc:      	cmpq	0x10(%rsp), %r12
   152e1:      	je	0x153d9 <generic_kprobe_path+0xaa49>
   152e7:      	leaq	0x18(%r12), %rbx
   152ec:      	movl	$0x4, %eax
   152f1:      	movq	%rbp, %rdi
   152f4:      	movl	$0x8, %esi
   152f9:      	movq	%rbx, %rdx
   152fc:      	callq	*%rax
   152fe:      	cmpq	%r12, (%rsp)
   15302:      	je	0x153d9 <generic_kprobe_path+0xaa49>
   15308:      	movl	$0x4, %eax
   1530d:      	leaq	0x8(%rsp), %rdi
   15312:      	movl	$0x8, %esi
   15317:      	movq	%rbx, %rdx
   1531a:      	callq	*%rax
   1531c:      	addq	$0x20, %r12
   15320:      	movl	$0x4, %eax
   15325:      	leaq	0x58(%rsp), %rdi
   1532a:      	movl	$0x10, %ecx
   1532f:      	movl	$0x10, %esi
   15334:      	movq	%r12, %rdx
   15337:      	callq	*%rax
   15339:      	movq	0x28(%rsp), %rbx
   1533e:      	movq	0x48(%rsp), %rax
   15343:      	movl	0x5c(%rsp), %r15d
   15348:      	subq	%rbx, %rax
   1534b:      	movl	0x50(%rsp), %r12d
   15350:      	movl	%r15d, %edx
   15353:      	subl	%r12d, %edx
   15356:      	movl	$0x0, %ecx
   1535b:      	cmovbl	%ecx, %edx
   1535e:      	addq	0x60(%rsp), %rdx
   15363:      	xorl	%esi, %esi
   15365:      	cmpl	%r15d, %r12d
   15368:      	seta	%sil
   1536c:      	movl	%r15d, %ecx
   1536f:      	cmovbl	%r12d, %ecx
   15373:      	addl	%ecx, %esi
   15375:      	movl	%r12d, %edi
   15378:      	subl	%esi, %edi
   1537a:      	movl	%edi, 0x50(%rsp)
   1537e:      	subq	%rsi, %rax
   15381:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15387:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1538d:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15393:      	cmpl	%r15d, %r12d
   15396:      	jbe	0x1539c <generic_kprobe_path+0xaa0c>
   15398:      	movb	$0x2f, (%rbx,%rax)
   1539c:      	xorl	%edi, %edi
   1539e:      	cmpl	%r15d, %r12d
   153a1:      	seta	%dil
   153a5:      	movzbl	%cl, %esi
   153a8:      	addq	%rax, %rbx
   153ab:      	addq	%rbx, %rdi
   153ae:      	movl	$0x4, %eax
   153b3:      	callq	*%rax
   153b5:      	movq	%rbx, 0x48(%rsp)
   153ba:      	cmpl	%r15d, %r12d
   153bd:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   153c3:      	movq	0x8(%rsp), %r12
   153c8:      	movq	%r12, 0x30(%rsp)
   153cd:      	movq	0x38(%rsp), %rdx
   153d2:      	movq	0x40(%rsp), %r15
   153d7:      	jmp	0x1542a <generic_kprobe_path+0xaa9a>
   153d9:      	leaq	0x10(%r15), %rdx
   153dd:      	movl	$0x4, %eax
   153e2:      	movq	%rbp, %rdi
   153e5:      	movl	$0x8, %esi
   153ea:      	callq	*%rax
   153ec:      	movq	0x40(%rsp), %rax
   153f1:      	cmpq	(%rsp), %rax
   153f5:      	je	0x163fd <generic_kprobe_path+0xba6d>
   153fb:      	addq	$0x18, %r15
   153ff:      	movl	$0x4, %eax
   15404:      	leaq	0x30(%rsp), %rdi
   15409:      	movl	$0x8, %esi
   1540e:      	movq	%r15, %rdx
   15411:      	callq	*%rax
   15413:      	movq	(%rsp), %r15
   15417:      	movq	%r15, 0x40(%rsp)
   1541c:      	leaq	0x20(%r15), %rdx
   15420:      	movq	%rdx, 0x38(%rsp)
   15425:      	movq	0x30(%rsp), %r12
   1542a:      	cmpq	0x18(%rsp), %r12
   1542f:      	jne	0x1543c <generic_kprobe_path+0xaaac>
   15431:      	cmpq	0x20(%rsp), %rdx
   15436:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1543c:      	movl	$0x4, %eax
   15441:      	leaq	0x10(%rsp), %rdi
   15446:      	movl	$0x8, %esi
   1544b:      	callq	*%rax
   1544d:      	cmpq	0x10(%rsp), %r12
   15452:      	je	0x1554a <generic_kprobe_path+0xabba>
   15458:      	leaq	0x18(%r12), %rbx
   1545d:      	movl	$0x4, %eax
   15462:      	movq	%rbp, %rdi
   15465:      	movl	$0x8, %esi
   1546a:      	movq	%rbx, %rdx
   1546d:      	callq	*%rax
   1546f:      	cmpq	%r12, (%rsp)
   15473:      	je	0x1554a <generic_kprobe_path+0xabba>
   15479:      	movl	$0x4, %eax
   1547e:      	leaq	0x8(%rsp), %rdi
   15483:      	movl	$0x8, %esi
   15488:      	movq	%rbx, %rdx
   1548b:      	callq	*%rax
   1548d:      	addq	$0x20, %r12
   15491:      	movl	$0x4, %eax
   15496:      	leaq	0x58(%rsp), %rdi
   1549b:      	movl	$0x10, %ecx
   154a0:      	movl	$0x10, %esi
   154a5:      	movq	%r12, %rdx
   154a8:      	callq	*%rax
   154aa:      	movq	0x28(%rsp), %rbx
   154af:      	movq	0x48(%rsp), %rax
   154b4:      	movl	0x5c(%rsp), %r15d
   154b9:      	subq	%rbx, %rax
   154bc:      	movl	0x50(%rsp), %r12d
   154c1:      	movl	%r15d, %edx
   154c4:      	subl	%r12d, %edx
   154c7:      	movl	$0x0, %ecx
   154cc:      	cmovbl	%ecx, %edx
   154cf:      	addq	0x60(%rsp), %rdx
   154d4:      	xorl	%esi, %esi
   154d6:      	cmpl	%r15d, %r12d
   154d9:      	seta	%sil
   154dd:      	movl	%r15d, %ecx
   154e0:      	cmovbl	%r12d, %ecx
   154e4:      	addl	%ecx, %esi
   154e6:      	movl	%r12d, %edi
   154e9:      	subl	%esi, %edi
   154eb:      	movl	%edi, 0x50(%rsp)
   154ef:      	subq	%rsi, %rax
   154f2:      	jb	0x16402 <generic_kprobe_path+0xba72>
   154f8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   154fe:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15504:      	cmpl	%r15d, %r12d
   15507:      	jbe	0x1550d <generic_kprobe_path+0xab7d>
   15509:      	movb	$0x2f, (%rbx,%rax)
   1550d:      	xorl	%edi, %edi
   1550f:      	cmpl	%r15d, %r12d
   15512:      	seta	%dil
   15516:      	movzbl	%cl, %esi
   15519:      	addq	%rax, %rbx
   1551c:      	addq	%rbx, %rdi
   1551f:      	movl	$0x4, %eax
   15524:      	callq	*%rax
   15526:      	movq	%rbx, 0x48(%rsp)
   1552b:      	cmpl	%r15d, %r12d
   1552e:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15534:      	movq	0x8(%rsp), %r12
   15539:      	movq	%r12, 0x30(%rsp)
   1553e:      	movq	0x38(%rsp), %rdx
   15543:      	movq	0x40(%rsp), %r15
   15548:      	jmp	0x1559b <generic_kprobe_path+0xac0b>
   1554a:      	leaq	0x10(%r15), %rdx
   1554e:      	movl	$0x4, %eax
   15553:      	movq	%rbp, %rdi
   15556:      	movl	$0x8, %esi
   1555b:      	callq	*%rax
   1555d:      	movq	0x40(%rsp), %rax
   15562:      	cmpq	(%rsp), %rax
   15566:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1556c:      	addq	$0x18, %r15
   15570:      	movl	$0x4, %eax
   15575:      	leaq	0x30(%rsp), %rdi
   1557a:      	movl	$0x8, %esi
   1557f:      	movq	%r15, %rdx
   15582:      	callq	*%rax
   15584:      	movq	(%rsp), %r15
   15588:      	movq	%r15, 0x40(%rsp)
   1558d:      	leaq	0x20(%r15), %rdx
   15591:      	movq	%rdx, 0x38(%rsp)
   15596:      	movq	0x30(%rsp), %r12
   1559b:      	cmpq	0x18(%rsp), %r12
   155a0:      	jne	0x155ad <generic_kprobe_path+0xac1d>
   155a2:      	cmpq	0x20(%rsp), %rdx
   155a7:      	je	0x163fd <generic_kprobe_path+0xba6d>
   155ad:      	movl	$0x4, %eax
   155b2:      	leaq	0x10(%rsp), %rdi
   155b7:      	movl	$0x8, %esi
   155bc:      	callq	*%rax
   155be:      	cmpq	0x10(%rsp), %r12
   155c3:      	je	0x156bb <generic_kprobe_path+0xad2b>
   155c9:      	leaq	0x18(%r12), %rbx
   155ce:      	movl	$0x4, %eax
   155d3:      	movq	%rbp, %rdi
   155d6:      	movl	$0x8, %esi
   155db:      	movq	%rbx, %rdx
   155de:      	callq	*%rax
   155e0:      	cmpq	%r12, (%rsp)
   155e4:      	je	0x156bb <generic_kprobe_path+0xad2b>
   155ea:      	movl	$0x4, %eax
   155ef:      	leaq	0x8(%rsp), %rdi
   155f4:      	movl	$0x8, %esi
   155f9:      	movq	%rbx, %rdx
   155fc:      	callq	*%rax
   155fe:      	addq	$0x20, %r12
   15602:      	movl	$0x4, %eax
   15607:      	leaq	0x58(%rsp), %rdi
   1560c:      	movl	$0x10, %ecx
   15611:      	movl	$0x10, %esi
   15616:      	movq	%r12, %rdx
   15619:      	callq	*%rax
   1561b:      	movq	0x28(%rsp), %rbx
   15620:      	movq	0x48(%rsp), %rax
   15625:      	movl	0x5c(%rsp), %r15d
   1562a:      	subq	%rbx, %rax
   1562d:      	movl	0x50(%rsp), %r12d
   15632:      	movl	%r15d, %edx
   15635:      	subl	%r12d, %edx
   15638:      	movl	$0x0, %ecx
   1563d:      	cmovbl	%ecx, %edx
   15640:      	addq	0x60(%rsp), %rdx
   15645:      	xorl	%esi, %esi
   15647:      	cmpl	%r15d, %r12d
   1564a:      	seta	%sil
   1564e:      	movl	%r15d, %ecx
   15651:      	cmovbl	%r12d, %ecx
   15655:      	addl	%ecx, %esi
   15657:      	movl	%r12d, %edi
   1565a:      	subl	%esi, %edi
   1565c:      	movl	%edi, 0x50(%rsp)
   15660:      	subq	%rsi, %rax
   15663:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15669:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1566f:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15675:      	cmpl	%r15d, %r12d
   15678:      	jbe	0x1567e <generic_kprobe_path+0xacee>
   1567a:      	movb	$0x2f, (%rbx,%rax)
   1567e:      	xorl	%edi, %edi
   15680:      	cmpl	%r15d, %r12d
   15683:      	seta	%dil
   15687:      	movzbl	%cl, %esi
   1568a:      	addq	%rax, %rbx
   1568d:      	addq	%rbx, %rdi
   15690:      	movl	$0x4, %eax
   15695:      	callq	*%rax
   15697:      	movq	%rbx, 0x48(%rsp)
   1569c:      	cmpl	%r15d, %r12d
   1569f:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   156a5:      	movq	0x8(%rsp), %r12
   156aa:      	movq	%r12, 0x30(%rsp)
   156af:      	movq	0x38(%rsp), %rdx
   156b4:      	movq	0x40(%rsp), %r15
   156b9:      	jmp	0x1570c <generic_kprobe_path+0xad7c>
   156bb:      	leaq	0x10(%r15), %rdx
   156bf:      	movl	$0x4, %eax
   156c4:      	movq	%rbp, %rdi
   156c7:      	movl	$0x8, %esi
   156cc:      	callq	*%rax
   156ce:      	movq	0x40(%rsp), %rax
   156d3:      	cmpq	(%rsp), %rax
   156d7:      	je	0x163fd <generic_kprobe_path+0xba6d>
   156dd:      	addq	$0x18, %r15
   156e1:      	movl	$0x4, %eax
   156e6:      	leaq	0x30(%rsp), %rdi
   156eb:      	movl	$0x8, %esi
   156f0:      	movq	%r15, %rdx
   156f3:      	callq	*%rax
   156f5:      	movq	(%rsp), %r15
   156f9:      	movq	%r15, 0x40(%rsp)
   156fe:      	leaq	0x20(%r15), %rdx
   15702:      	movq	%rdx, 0x38(%rsp)
   15707:      	movq	0x30(%rsp), %r12
   1570c:      	cmpq	0x18(%rsp), %r12
   15711:      	jne	0x1571e <generic_kprobe_path+0xad8e>
   15713:      	cmpq	0x20(%rsp), %rdx
   15718:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1571e:      	movl	$0x4, %eax
   15723:      	leaq	0x10(%rsp), %rdi
   15728:      	movl	$0x8, %esi
   1572d:      	callq	*%rax
   1572f:      	cmpq	0x10(%rsp), %r12
   15734:      	je	0x1582c <generic_kprobe_path+0xae9c>
   1573a:      	leaq	0x18(%r12), %rbx
   1573f:      	movl	$0x4, %eax
   15744:      	movq	%rbp, %rdi
   15747:      	movl	$0x8, %esi
   1574c:      	movq	%rbx, %rdx
   1574f:      	callq	*%rax
   15751:      	cmpq	%r12, (%rsp)
   15755:      	je	0x1582c <generic_kprobe_path+0xae9c>
   1575b:      	movl	$0x4, %eax
   15760:      	leaq	0x8(%rsp), %rdi
   15765:      	movl	$0x8, %esi
   1576a:      	movq	%rbx, %rdx
   1576d:      	callq	*%rax
   1576f:      	addq	$0x20, %r12
   15773:      	movl	$0x4, %eax
   15778:      	leaq	0x58(%rsp), %rdi
   1577d:      	movl	$0x10, %ecx
   15782:      	movl	$0x10, %esi
   15787:      	movq	%r12, %rdx
   1578a:      	callq	*%rax
   1578c:      	movq	0x28(%rsp), %rbx
   15791:      	movq	0x48(%rsp), %rax
   15796:      	movl	0x5c(%rsp), %r15d
   1579b:      	subq	%rbx, %rax
   1579e:      	movl	0x50(%rsp), %r12d
   157a3:      	movl	%r15d, %edx
   157a6:      	subl	%r12d, %edx
   157a9:      	movl	$0x0, %ecx
   157ae:      	cmovbl	%ecx, %edx
   157b1:      	addq	0x60(%rsp), %rdx
   157b6:      	xorl	%esi, %esi
   157b8:      	cmpl	%r15d, %r12d
   157bb:      	seta	%sil
   157bf:      	movl	%r15d, %ecx
   157c2:      	cmovbl	%r12d, %ecx
   157c6:      	addl	%ecx, %esi
   157c8:      	movl	%r12d, %edi
   157cb:      	subl	%esi, %edi
   157cd:      	movl	%edi, 0x50(%rsp)
   157d1:      	subq	%rsi, %rax
   157d4:      	jb	0x16402 <generic_kprobe_path+0xba72>
   157da:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   157e0:      	ja	0x16402 <generic_kprobe_path+0xba72>
   157e6:      	cmpl	%r15d, %r12d
   157e9:      	jbe	0x157ef <generic_kprobe_path+0xae5f>
   157eb:      	movb	$0x2f, (%rbx,%rax)
   157ef:      	xorl	%edi, %edi
   157f1:      	cmpl	%r15d, %r12d
   157f4:      	seta	%dil
   157f8:      	movzbl	%cl, %esi
   157fb:      	addq	%rax, %rbx
   157fe:      	addq	%rbx, %rdi
   15801:      	movl	$0x4, %eax
   15806:      	callq	*%rax
   15808:      	movq	%rbx, 0x48(%rsp)
   1580d:      	cmpl	%r15d, %r12d
   15810:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15816:      	movq	0x8(%rsp), %r12
   1581b:      	movq	%r12, 0x30(%rsp)
   15820:      	movq	0x38(%rsp), %rdx
   15825:      	movq	0x40(%rsp), %r15
   1582a:      	jmp	0x1587d <generic_kprobe_path+0xaeed>
   1582c:      	leaq	0x10(%r15), %rdx
   15830:      	movl	$0x4, %eax
   15835:      	movq	%rbp, %rdi
   15838:      	movl	$0x8, %esi
   1583d:      	callq	*%rax
   1583f:      	movq	0x40(%rsp), %rax
   15844:      	cmpq	(%rsp), %rax
   15848:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1584e:      	addq	$0x18, %r15
   15852:      	movl	$0x4, %eax
   15857:      	leaq	0x30(%rsp), %rdi
   1585c:      	movl	$0x8, %esi
   15861:      	movq	%r15, %rdx
   15864:      	callq	*%rax
   15866:      	movq	(%rsp), %r15
   1586a:      	movq	%r15, 0x40(%rsp)
   1586f:      	leaq	0x20(%r15), %rdx
   15873:      	movq	%rdx, 0x38(%rsp)
   15878:      	movq	0x30(%rsp), %r12
   1587d:      	cmpq	0x18(%rsp), %r12
   15882:      	jne	0x1588f <generic_kprobe_path+0xaeff>
   15884:      	cmpq	0x20(%rsp), %rdx
   15889:      	je	0x163fd <generic_kprobe_path+0xba6d>
   1588f:      	movl	$0x4, %eax
   15894:      	leaq	0x10(%rsp), %rdi
   15899:      	movl	$0x8, %esi
   1589e:      	callq	*%rax
   158a0:      	cmpq	0x10(%rsp), %r12
   158a5:      	je	0x1599d <generic_kprobe_path+0xb00d>
   158ab:      	leaq	0x18(%r12), %rbx
   158b0:      	movl	$0x4, %eax
   158b5:      	movq	%rbp, %rdi
   158b8:      	movl	$0x8, %esi
   158bd:      	movq	%rbx, %rdx
   158c0:      	callq	*%rax
   158c2:      	cmpq	%r12, (%rsp)
   158c6:      	je	0x1599d <generic_kprobe_path+0xb00d>
   158cc:      	movl	$0x4, %eax
   158d1:      	leaq	0x8(%rsp), %rdi
   158d6:      	movl	$0x8, %esi
   158db:      	movq	%rbx, %rdx
   158de:      	callq	*%rax
   158e0:      	addq	$0x20, %r12
   158e4:      	movl	$0x4, %eax
   158e9:      	leaq	0x58(%rsp), %rdi
   158ee:      	movl	$0x10, %ecx
   158f3:      	movl	$0x10, %esi
   158f8:      	movq	%r12, %rdx
   158fb:      	callq	*%rax
   158fd:      	movq	0x28(%rsp), %rbx
   15902:      	movq	0x48(%rsp), %rax
   15907:      	movl	0x5c(%rsp), %r15d
   1590c:      	subq	%rbx, %rax
   1590f:      	movl	0x50(%rsp), %r12d
   15914:      	movl	%r15d, %edx
   15917:      	subl	%r12d, %edx
   1591a:      	movl	$0x0, %ecx
   1591f:      	cmovbl	%ecx, %edx
   15922:      	addq	0x60(%rsp), %rdx
   15927:      	xorl	%esi, %esi
   15929:      	cmpl	%r15d, %r12d
   1592c:      	seta	%sil
   15930:      	movl	%r15d, %ecx
   15933:      	cmovbl	%r12d, %ecx
   15937:      	addl	%ecx, %esi
   15939:      	movl	%r12d, %edi
   1593c:      	subl	%esi, %edi
   1593e:      	movl	%edi, 0x50(%rsp)
   15942:      	subq	%rsi, %rax
   15945:      	jb	0x16402 <generic_kprobe_path+0xba72>
   1594b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15951:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15957:      	cmpl	%r15d, %r12d
   1595a:      	jbe	0x15960 <generic_kprobe_path+0xafd0>
   1595c:      	movb	$0x2f, (%rbx,%rax)
   15960:      	xorl	%edi, %edi
   15962:      	cmpl	%r15d, %r12d
   15965:      	seta	%dil
   15969:      	movzbl	%cl, %esi
   1596c:      	addq	%rax, %rbx
   1596f:      	addq	%rbx, %rdi
   15972:      	movl	$0x4, %eax
   15977:      	callq	*%rax
   15979:      	movq	%rbx, 0x48(%rsp)
   1597e:      	cmpl	%r15d, %r12d
   15981:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15987:      	movq	0x8(%rsp), %r12
   1598c:      	movq	%r12, 0x30(%rsp)
   15991:      	movq	0x38(%rsp), %rdx
   15996:      	movq	0x40(%rsp), %r15
   1599b:      	jmp	0x159ee <generic_kprobe_path+0xb05e>
   1599d:      	leaq	0x10(%r15), %rdx
   159a1:      	movl	$0x4, %eax
   159a6:      	movq	%rbp, %rdi
   159a9:      	movl	$0x8, %esi
   159ae:      	callq	*%rax
   159b0:      	movq	0x40(%rsp), %rax
   159b5:      	cmpq	(%rsp), %rax
   159b9:      	je	0x163fd <generic_kprobe_path+0xba6d>
   159bf:      	addq	$0x18, %r15
   159c3:      	movl	$0x4, %eax
   159c8:      	leaq	0x30(%rsp), %rdi
   159cd:      	movl	$0x8, %esi
   159d2:      	movq	%r15, %rdx
   159d5:      	callq	*%rax
   159d7:      	movq	(%rsp), %r15
   159db:      	movq	%r15, 0x40(%rsp)
   159e0:      	leaq	0x20(%r15), %rdx
   159e4:      	movq	%rdx, 0x38(%rsp)
   159e9:      	movq	0x30(%rsp), %r12
   159ee:      	cmpq	0x18(%rsp), %r12
   159f3:      	jne	0x15a00 <generic_kprobe_path+0xb070>
   159f5:      	cmpq	0x20(%rsp), %rdx
   159fa:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15a00:      	movl	$0x4, %eax
   15a05:      	leaq	0x10(%rsp), %rdi
   15a0a:      	movl	$0x8, %esi
   15a0f:      	callq	*%rax
   15a11:      	cmpq	0x10(%rsp), %r12
   15a16:      	je	0x15b0e <generic_kprobe_path+0xb17e>
   15a1c:      	leaq	0x18(%r12), %rbx
   15a21:      	movl	$0x4, %eax
   15a26:      	movq	%rbp, %rdi
   15a29:      	movl	$0x8, %esi
   15a2e:      	movq	%rbx, %rdx
   15a31:      	callq	*%rax
   15a33:      	cmpq	%r12, (%rsp)
   15a37:      	je	0x15b0e <generic_kprobe_path+0xb17e>
   15a3d:      	movl	$0x4, %eax
   15a42:      	leaq	0x8(%rsp), %rdi
   15a47:      	movl	$0x8, %esi
   15a4c:      	movq	%rbx, %rdx
   15a4f:      	callq	*%rax
   15a51:      	addq	$0x20, %r12
   15a55:      	movl	$0x4, %eax
   15a5a:      	leaq	0x58(%rsp), %rdi
   15a5f:      	movl	$0x10, %ecx
   15a64:      	movl	$0x10, %esi
   15a69:      	movq	%r12, %rdx
   15a6c:      	callq	*%rax
   15a6e:      	movq	0x28(%rsp), %rbx
   15a73:      	movq	0x48(%rsp), %rax
   15a78:      	movl	0x5c(%rsp), %r15d
   15a7d:      	subq	%rbx, %rax
   15a80:      	movl	0x50(%rsp), %r12d
   15a85:      	movl	%r15d, %edx
   15a88:      	subl	%r12d, %edx
   15a8b:      	movl	$0x0, %ecx
   15a90:      	cmovbl	%ecx, %edx
   15a93:      	addq	0x60(%rsp), %rdx
   15a98:      	xorl	%esi, %esi
   15a9a:      	cmpl	%r15d, %r12d
   15a9d:      	seta	%sil
   15aa1:      	movl	%r15d, %ecx
   15aa4:      	cmovbl	%r12d, %ecx
   15aa8:      	addl	%ecx, %esi
   15aaa:      	movl	%r12d, %edi
   15aad:      	subl	%esi, %edi
   15aaf:      	movl	%edi, 0x50(%rsp)
   15ab3:      	subq	%rsi, %rax
   15ab6:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15abc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15ac2:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15ac8:      	cmpl	%r15d, %r12d
   15acb:      	jbe	0x15ad1 <generic_kprobe_path+0xb141>
   15acd:      	movb	$0x2f, (%rbx,%rax)
   15ad1:      	xorl	%edi, %edi
   15ad3:      	cmpl	%r15d, %r12d
   15ad6:      	seta	%dil
   15ada:      	movzbl	%cl, %esi
   15add:      	addq	%rax, %rbx
   15ae0:      	addq	%rbx, %rdi
   15ae3:      	movl	$0x4, %eax
   15ae8:      	callq	*%rax
   15aea:      	movq	%rbx, 0x48(%rsp)
   15aef:      	cmpl	%r15d, %r12d
   15af2:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15af8:      	movq	0x8(%rsp), %r12
   15afd:      	movq	%r12, 0x30(%rsp)
   15b02:      	movq	0x38(%rsp), %rdx
   15b07:      	movq	0x40(%rsp), %r15
   15b0c:      	jmp	0x15b5f <generic_kprobe_path+0xb1cf>
   15b0e:      	leaq	0x10(%r15), %rdx
   15b12:      	movl	$0x4, %eax
   15b17:      	movq	%rbp, %rdi
   15b1a:      	movl	$0x8, %esi
   15b1f:      	callq	*%rax
   15b21:      	movq	0x40(%rsp), %rax
   15b26:      	cmpq	(%rsp), %rax
   15b2a:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15b30:      	addq	$0x18, %r15
   15b34:      	movl	$0x4, %eax
   15b39:      	leaq	0x30(%rsp), %rdi
   15b3e:      	movl	$0x8, %esi
   15b43:      	movq	%r15, %rdx
   15b46:      	callq	*%rax
   15b48:      	movq	(%rsp), %r15
   15b4c:      	movq	%r15, 0x40(%rsp)
   15b51:      	leaq	0x20(%r15), %rdx
   15b55:      	movq	%rdx, 0x38(%rsp)
   15b5a:      	movq	0x30(%rsp), %r12
   15b5f:      	cmpq	0x18(%rsp), %r12
   15b64:      	jne	0x15b71 <generic_kprobe_path+0xb1e1>
   15b66:      	cmpq	0x20(%rsp), %rdx
   15b6b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15b71:      	movl	$0x4, %eax
   15b76:      	leaq	0x10(%rsp), %rdi
   15b7b:      	movl	$0x8, %esi
   15b80:      	callq	*%rax
   15b82:      	cmpq	0x10(%rsp), %r12
   15b87:      	je	0x15c7f <generic_kprobe_path+0xb2ef>
   15b8d:      	leaq	0x18(%r12), %rbx
   15b92:      	movl	$0x4, %eax
   15b97:      	movq	%rbp, %rdi
   15b9a:      	movl	$0x8, %esi
   15b9f:      	movq	%rbx, %rdx
   15ba2:      	callq	*%rax
   15ba4:      	cmpq	%r12, (%rsp)
   15ba8:      	je	0x15c7f <generic_kprobe_path+0xb2ef>
   15bae:      	movl	$0x4, %eax
   15bb3:      	leaq	0x8(%rsp), %rdi
   15bb8:      	movl	$0x8, %esi
   15bbd:      	movq	%rbx, %rdx
   15bc0:      	callq	*%rax
   15bc2:      	addq	$0x20, %r12
   15bc6:      	movl	$0x4, %eax
   15bcb:      	leaq	0x58(%rsp), %rdi
   15bd0:      	movl	$0x10, %ecx
   15bd5:      	movl	$0x10, %esi
   15bda:      	movq	%r12, %rdx
   15bdd:      	callq	*%rax
   15bdf:      	movq	0x28(%rsp), %rbx
   15be4:      	movq	0x48(%rsp), %rax
   15be9:      	movl	0x5c(%rsp), %r15d
   15bee:      	subq	%rbx, %rax
   15bf1:      	movl	0x50(%rsp), %r12d
   15bf6:      	movl	%r15d, %edx
   15bf9:      	subl	%r12d, %edx
   15bfc:      	movl	$0x0, %ecx
   15c01:      	cmovbl	%ecx, %edx
   15c04:      	addq	0x60(%rsp), %rdx
   15c09:      	xorl	%esi, %esi
   15c0b:      	cmpl	%r15d, %r12d
   15c0e:      	seta	%sil
   15c12:      	movl	%r15d, %ecx
   15c15:      	cmovbl	%r12d, %ecx
   15c19:      	addl	%ecx, %esi
   15c1b:      	movl	%r12d, %edi
   15c1e:      	subl	%esi, %edi
   15c20:      	movl	%edi, 0x50(%rsp)
   15c24:      	subq	%rsi, %rax
   15c27:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15c2d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15c33:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15c39:      	cmpl	%r15d, %r12d
   15c3c:      	jbe	0x15c42 <generic_kprobe_path+0xb2b2>
   15c3e:      	movb	$0x2f, (%rbx,%rax)
   15c42:      	xorl	%edi, %edi
   15c44:      	cmpl	%r15d, %r12d
   15c47:      	seta	%dil
   15c4b:      	movzbl	%cl, %esi
   15c4e:      	addq	%rax, %rbx
   15c51:      	addq	%rbx, %rdi
   15c54:      	movl	$0x4, %eax
   15c59:      	callq	*%rax
   15c5b:      	movq	%rbx, 0x48(%rsp)
   15c60:      	cmpl	%r15d, %r12d
   15c63:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15c69:      	movq	0x8(%rsp), %r12
   15c6e:      	movq	%r12, 0x30(%rsp)
   15c73:      	movq	0x38(%rsp), %rdx
   15c78:      	movq	0x40(%rsp), %r15
   15c7d:      	jmp	0x15cd0 <generic_kprobe_path+0xb340>
   15c7f:      	leaq	0x10(%r15), %rdx
   15c83:      	movl	$0x4, %eax
   15c88:      	movq	%rbp, %rdi
   15c8b:      	movl	$0x8, %esi
   15c90:      	callq	*%rax
   15c92:      	movq	0x40(%rsp), %rax
   15c97:      	cmpq	(%rsp), %rax
   15c9b:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15ca1:      	addq	$0x18, %r15
   15ca5:      	movl	$0x4, %eax
   15caa:      	leaq	0x30(%rsp), %rdi
   15caf:      	movl	$0x8, %esi
   15cb4:      	movq	%r15, %rdx
   15cb7:      	callq	*%rax
   15cb9:      	movq	(%rsp), %r15
   15cbd:      	movq	%r15, 0x40(%rsp)
   15cc2:      	leaq	0x20(%r15), %rdx
   15cc6:      	movq	%rdx, 0x38(%rsp)
   15ccb:      	movq	0x30(%rsp), %r12
   15cd0:      	cmpq	0x18(%rsp), %r12
   15cd5:      	jne	0x15ce2 <generic_kprobe_path+0xb352>
   15cd7:      	cmpq	0x20(%rsp), %rdx
   15cdc:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15ce2:      	movl	$0x4, %eax
   15ce7:      	leaq	0x10(%rsp), %rdi
   15cec:      	movl	$0x8, %esi
   15cf1:      	callq	*%rax
   15cf3:      	cmpq	0x10(%rsp), %r12
   15cf8:      	je	0x15df0 <generic_kprobe_path+0xb460>
   15cfe:      	leaq	0x18(%r12), %rbx
   15d03:      	movl	$0x4, %eax
   15d08:      	movq	%rbp, %rdi
   15d0b:      	movl	$0x8, %esi
   15d10:      	movq	%rbx, %rdx
   15d13:      	callq	*%rax
   15d15:      	cmpq	%r12, (%rsp)
   15d19:      	je	0x15df0 <generic_kprobe_path+0xb460>
   15d1f:      	movl	$0x4, %eax
   15d24:      	leaq	0x8(%rsp), %rdi
   15d29:      	movl	$0x8, %esi
   15d2e:      	movq	%rbx, %rdx
   15d31:      	callq	*%rax
   15d33:      	addq	$0x20, %r12
   15d37:      	movl	$0x4, %eax
   15d3c:      	leaq	0x58(%rsp), %rdi
   15d41:      	movl	$0x10, %ecx
   15d46:      	movl	$0x10, %esi
   15d4b:      	movq	%r12, %rdx
   15d4e:      	callq	*%rax
   15d50:      	movq	0x28(%rsp), %rbx
   15d55:      	movq	0x48(%rsp), %rax
   15d5a:      	movl	0x5c(%rsp), %r15d
   15d5f:      	subq	%rbx, %rax
   15d62:      	movl	0x50(%rsp), %r12d
   15d67:      	movl	%r15d, %edx
   15d6a:      	subl	%r12d, %edx
   15d6d:      	movl	$0x0, %ecx
   15d72:      	cmovbl	%ecx, %edx
   15d75:      	addq	0x60(%rsp), %rdx
   15d7a:      	xorl	%esi, %esi
   15d7c:      	cmpl	%r15d, %r12d
   15d7f:      	seta	%sil
   15d83:      	movl	%r15d, %ecx
   15d86:      	cmovbl	%r12d, %ecx
   15d8a:      	addl	%ecx, %esi
   15d8c:      	movl	%r12d, %edi
   15d8f:      	subl	%esi, %edi
   15d91:      	movl	%edi, 0x50(%rsp)
   15d95:      	subq	%rsi, %rax
   15d98:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15d9e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15da4:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15daa:      	cmpl	%r15d, %r12d
   15dad:      	jbe	0x15db3 <generic_kprobe_path+0xb423>
   15daf:      	movb	$0x2f, (%rbx,%rax)
   15db3:      	xorl	%edi, %edi
   15db5:      	cmpl	%r15d, %r12d
   15db8:      	seta	%dil
   15dbc:      	movzbl	%cl, %esi
   15dbf:      	addq	%rax, %rbx
   15dc2:      	addq	%rbx, %rdi
   15dc5:      	movl	$0x4, %eax
   15dca:      	callq	*%rax
   15dcc:      	movq	%rbx, 0x48(%rsp)
   15dd1:      	cmpl	%r15d, %r12d
   15dd4:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15dda:      	movq	0x8(%rsp), %r12
   15ddf:      	movq	%r12, 0x30(%rsp)
   15de4:      	movq	0x38(%rsp), %rdx
   15de9:      	movq	0x40(%rsp), %r15
   15dee:      	jmp	0x15e41 <generic_kprobe_path+0xb4b1>
   15df0:      	leaq	0x10(%r15), %rdx
   15df4:      	movl	$0x4, %eax
   15df9:      	movq	%rbp, %rdi
   15dfc:      	movl	$0x8, %esi
   15e01:      	callq	*%rax
   15e03:      	movq	0x40(%rsp), %rax
   15e08:      	cmpq	(%rsp), %rax
   15e0c:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15e12:      	addq	$0x18, %r15
   15e16:      	movl	$0x4, %eax
   15e1b:      	leaq	0x30(%rsp), %rdi
   15e20:      	movl	$0x8, %esi
   15e25:      	movq	%r15, %rdx
   15e28:      	callq	*%rax
   15e2a:      	movq	(%rsp), %r15
   15e2e:      	movq	%r15, 0x40(%rsp)
   15e33:      	leaq	0x20(%r15), %rdx
   15e37:      	movq	%rdx, 0x38(%rsp)
   15e3c:      	movq	0x30(%rsp), %r12
   15e41:      	cmpq	0x18(%rsp), %r12
   15e46:      	jne	0x15e53 <generic_kprobe_path+0xb4c3>
   15e48:      	cmpq	0x20(%rsp), %rdx
   15e4d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15e53:      	movl	$0x4, %eax
   15e58:      	leaq	0x10(%rsp), %rdi
   15e5d:      	movl	$0x8, %esi
   15e62:      	callq	*%rax
   15e64:      	cmpq	0x10(%rsp), %r12
   15e69:      	je	0x15f61 <generic_kprobe_path+0xb5d1>
   15e6f:      	leaq	0x18(%r12), %rbx
   15e74:      	movl	$0x4, %eax
   15e79:      	movq	%rbp, %rdi
   15e7c:      	movl	$0x8, %esi
   15e81:      	movq	%rbx, %rdx
   15e84:      	callq	*%rax
   15e86:      	cmpq	%r12, (%rsp)
   15e8a:      	je	0x15f61 <generic_kprobe_path+0xb5d1>
   15e90:      	movl	$0x4, %eax
   15e95:      	leaq	0x8(%rsp), %rdi
   15e9a:      	movl	$0x8, %esi
   15e9f:      	movq	%rbx, %rdx
   15ea2:      	callq	*%rax
   15ea4:      	addq	$0x20, %r12
   15ea8:      	movl	$0x4, %eax
   15ead:      	leaq	0x58(%rsp), %rdi
   15eb2:      	movl	$0x10, %ecx
   15eb7:      	movl	$0x10, %esi
   15ebc:      	movq	%r12, %rdx
   15ebf:      	callq	*%rax
   15ec1:      	movq	0x28(%rsp), %rbx
   15ec6:      	movq	0x48(%rsp), %rax
   15ecb:      	movl	0x5c(%rsp), %r15d
   15ed0:      	subq	%rbx, %rax
   15ed3:      	movl	0x50(%rsp), %r12d
   15ed8:      	movl	%r15d, %edx
   15edb:      	subl	%r12d, %edx
   15ede:      	movl	$0x0, %ecx
   15ee3:      	cmovbl	%ecx, %edx
   15ee6:      	addq	0x60(%rsp), %rdx
   15eeb:      	xorl	%esi, %esi
   15eed:      	cmpl	%r15d, %r12d
   15ef0:      	seta	%sil
   15ef4:      	movl	%r15d, %ecx
   15ef7:      	cmovbl	%r12d, %ecx
   15efb:      	addl	%ecx, %esi
   15efd:      	movl	%r12d, %edi
   15f00:      	subl	%esi, %edi
   15f02:      	movl	%edi, 0x50(%rsp)
   15f06:      	subq	%rsi, %rax
   15f09:      	jb	0x16402 <generic_kprobe_path+0xba72>
   15f0f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15f15:      	ja	0x16402 <generic_kprobe_path+0xba72>
   15f1b:      	cmpl	%r15d, %r12d
   15f1e:      	jbe	0x15f24 <generic_kprobe_path+0xb594>
   15f20:      	movb	$0x2f, (%rbx,%rax)
   15f24:      	xorl	%edi, %edi
   15f26:      	cmpl	%r15d, %r12d
   15f29:      	seta	%dil
   15f2d:      	movzbl	%cl, %esi
   15f30:      	addq	%rax, %rbx
   15f33:      	addq	%rbx, %rdi
   15f36:      	movl	$0x4, %eax
   15f3b:      	callq	*%rax
   15f3d:      	movq	%rbx, 0x48(%rsp)
   15f42:      	cmpl	%r15d, %r12d
   15f45:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   15f4b:      	movq	0x8(%rsp), %r12
   15f50:      	movq	%r12, 0x30(%rsp)
   15f55:      	movq	0x38(%rsp), %rdx
   15f5a:      	movq	0x40(%rsp), %r15
   15f5f:      	jmp	0x15fb2 <generic_kprobe_path+0xb622>
   15f61:      	leaq	0x10(%r15), %rdx
   15f65:      	movl	$0x4, %eax
   15f6a:      	movq	%rbp, %rdi
   15f6d:      	movl	$0x8, %esi
   15f72:      	callq	*%rax
   15f74:      	movq	0x40(%rsp), %rax
   15f79:      	cmpq	(%rsp), %rax
   15f7d:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15f83:      	addq	$0x18, %r15
   15f87:      	movl	$0x4, %eax
   15f8c:      	leaq	0x30(%rsp), %rdi
   15f91:      	movl	$0x8, %esi
   15f96:      	movq	%r15, %rdx
   15f99:      	callq	*%rax
   15f9b:      	movq	(%rsp), %r15
   15f9f:      	movq	%r15, 0x40(%rsp)
   15fa4:      	leaq	0x20(%r15), %rdx
   15fa8:      	movq	%rdx, 0x38(%rsp)
   15fad:      	movq	0x30(%rsp), %r12
   15fb2:      	cmpq	0x18(%rsp), %r12
   15fb7:      	jne	0x15fc4 <generic_kprobe_path+0xb634>
   15fb9:      	cmpq	0x20(%rsp), %rdx
   15fbe:      	je	0x163fd <generic_kprobe_path+0xba6d>
   15fc4:      	movl	$0x4, %eax
   15fc9:      	leaq	0x10(%rsp), %rdi
   15fce:      	movl	$0x8, %esi
   15fd3:      	callq	*%rax
   15fd5:      	cmpq	0x10(%rsp), %r12
   15fda:      	je	0x160d2 <generic_kprobe_path+0xb742>
   15fe0:      	leaq	0x18(%r12), %rbx
   15fe5:      	movl	$0x4, %eax
   15fea:      	movq	%rbp, %rdi
   15fed:      	movl	$0x8, %esi
   15ff2:      	movq	%rbx, %rdx
   15ff5:      	callq	*%rax
   15ff7:      	cmpq	%r12, (%rsp)
   15ffb:      	je	0x160d2 <generic_kprobe_path+0xb742>
   16001:      	movl	$0x4, %eax
   16006:      	leaq	0x8(%rsp), %rdi
   1600b:      	movl	$0x8, %esi
   16010:      	movq	%rbx, %rdx
   16013:      	callq	*%rax
   16015:      	addq	$0x20, %r12
   16019:      	movl	$0x4, %eax
   1601e:      	leaq	0x58(%rsp), %rdi
   16023:      	movl	$0x10, %ecx
   16028:      	movl	$0x10, %esi
   1602d:      	movq	%r12, %rdx
   16030:      	callq	*%rax
   16032:      	movq	0x28(%rsp), %rbx
   16037:      	movq	0x48(%rsp), %rax
   1603c:      	movl	0x5c(%rsp), %r15d
   16041:      	subq	%rbx, %rax
   16044:      	movl	0x50(%rsp), %r12d
   16049:      	movl	%r15d, %edx
   1604c:      	subl	%r12d, %edx
   1604f:      	movl	$0x0, %ecx
   16054:      	cmovbl	%ecx, %edx
   16057:      	addq	0x60(%rsp), %rdx
   1605c:      	xorl	%esi, %esi
   1605e:      	cmpl	%r15d, %r12d
   16061:      	seta	%sil
   16065:      	movl	%r15d, %ecx
   16068:      	cmovbl	%r12d, %ecx
   1606c:      	addl	%ecx, %esi
   1606e:      	movl	%r12d, %edi
   16071:      	subl	%esi, %edi
   16073:      	movl	%edi, 0x50(%rsp)
   16077:      	subq	%rsi, %rax
   1607a:      	jb	0x16402 <generic_kprobe_path+0xba72>
   16080:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16086:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1608c:      	cmpl	%r15d, %r12d
   1608f:      	jbe	0x16095 <generic_kprobe_path+0xb705>
   16091:      	movb	$0x2f, (%rbx,%rax)
   16095:      	xorl	%edi, %edi
   16097:      	cmpl	%r15d, %r12d
   1609a:      	seta	%dil
   1609e:      	movzbl	%cl, %esi
   160a1:      	addq	%rax, %rbx
   160a4:      	addq	%rbx, %rdi
   160a7:      	movl	$0x4, %eax
   160ac:      	callq	*%rax
   160ae:      	movq	%rbx, 0x48(%rsp)
   160b3:      	cmpl	%r15d, %r12d
   160b6:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   160bc:      	movq	0x8(%rsp), %r12
   160c1:      	movq	%r12, 0x30(%rsp)
   160c6:      	movq	0x38(%rsp), %rdx
   160cb:      	movq	0x40(%rsp), %r15
   160d0:      	jmp	0x16123 <generic_kprobe_path+0xb793>
   160d2:      	leaq	0x10(%r15), %rdx
   160d6:      	movl	$0x4, %eax
   160db:      	movq	%rbp, %rdi
   160de:      	movl	$0x8, %esi
   160e3:      	callq	*%rax
   160e5:      	movq	0x40(%rsp), %rax
   160ea:      	cmpq	(%rsp), %rax
   160ee:      	je	0x163fd <generic_kprobe_path+0xba6d>
   160f4:      	addq	$0x18, %r15
   160f8:      	movl	$0x4, %eax
   160fd:      	leaq	0x30(%rsp), %rdi
   16102:      	movl	$0x8, %esi
   16107:      	movq	%r15, %rdx
   1610a:      	callq	*%rax
   1610c:      	movq	(%rsp), %r15
   16110:      	movq	%r15, 0x40(%rsp)
   16115:      	leaq	0x20(%r15), %rdx
   16119:      	movq	%rdx, 0x38(%rsp)
   1611e:      	movq	0x30(%rsp), %r12
   16123:      	cmpq	0x18(%rsp), %r12
   16128:      	jne	0x16135 <generic_kprobe_path+0xb7a5>
   1612a:      	cmpq	0x20(%rsp), %rdx
   1612f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   16135:      	movl	$0x4, %eax
   1613a:      	leaq	0x10(%rsp), %rdi
   1613f:      	movl	$0x8, %esi
   16144:      	callq	*%rax
   16146:      	cmpq	0x10(%rsp), %r12
   1614b:      	je	0x16243 <generic_kprobe_path+0xb8b3>
   16151:      	leaq	0x18(%r12), %rbx
   16156:      	movl	$0x4, %eax
   1615b:      	movq	%rbp, %rdi
   1615e:      	movl	$0x8, %esi
   16163:      	movq	%rbx, %rdx
   16166:      	callq	*%rax
   16168:      	cmpq	%r12, (%rsp)
   1616c:      	je	0x16243 <generic_kprobe_path+0xb8b3>
   16172:      	movl	$0x4, %eax
   16177:      	leaq	0x8(%rsp), %rdi
   1617c:      	movl	$0x8, %esi
   16181:      	movq	%rbx, %rdx
   16184:      	callq	*%rax
   16186:      	addq	$0x20, %r12
   1618a:      	movl	$0x4, %eax
   1618f:      	leaq	0x58(%rsp), %rdi
   16194:      	movl	$0x10, %ecx
   16199:      	movl	$0x10, %esi
   1619e:      	movq	%r12, %rdx
   161a1:      	callq	*%rax
   161a3:      	movq	0x28(%rsp), %rbx
   161a8:      	movq	0x48(%rsp), %rax
   161ad:      	movl	0x5c(%rsp), %r15d
   161b2:      	subq	%rbx, %rax
   161b5:      	movl	0x50(%rsp), %r12d
   161ba:      	movl	%r15d, %edx
   161bd:      	subl	%r12d, %edx
   161c0:      	movl	$0x0, %ecx
   161c5:      	cmovbl	%ecx, %edx
   161c8:      	addq	0x60(%rsp), %rdx
   161cd:      	xorl	%esi, %esi
   161cf:      	cmpl	%r15d, %r12d
   161d2:      	seta	%sil
   161d6:      	movl	%r15d, %ecx
   161d9:      	cmovbl	%r12d, %ecx
   161dd:      	addl	%ecx, %esi
   161df:      	movl	%r12d, %edi
   161e2:      	subl	%esi, %edi
   161e4:      	movl	%edi, 0x50(%rsp)
   161e8:      	subq	%rsi, %rax
   161eb:      	jb	0x16402 <generic_kprobe_path+0xba72>
   161f1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   161f7:      	ja	0x16402 <generic_kprobe_path+0xba72>
   161fd:      	cmpl	%r15d, %r12d
   16200:      	jbe	0x16206 <generic_kprobe_path+0xb876>
   16202:      	movb	$0x2f, (%rbx,%rax)
   16206:      	xorl	%edi, %edi
   16208:      	cmpl	%r15d, %r12d
   1620b:      	seta	%dil
   1620f:      	movzbl	%cl, %esi
   16212:      	addq	%rax, %rbx
   16215:      	addq	%rbx, %rdi
   16218:      	movl	$0x4, %eax
   1621d:      	callq	*%rax
   1621f:      	movq	%rbx, 0x48(%rsp)
   16224:      	cmpl	%r15d, %r12d
   16227:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1622d:      	movq	0x8(%rsp), %r12
   16232:      	movq	%r12, 0x30(%rsp)
   16237:      	movq	0x38(%rsp), %rdx
   1623c:      	movq	0x40(%rsp), %r15
   16241:      	jmp	0x16294 <generic_kprobe_path+0xb904>
   16243:      	leaq	0x10(%r15), %rdx
   16247:      	movl	$0x4, %eax
   1624c:      	movq	%rbp, %rdi
   1624f:      	movl	$0x8, %esi
   16254:      	callq	*%rax
   16256:      	movq	0x40(%rsp), %rax
   1625b:      	cmpq	(%rsp), %rax
   1625f:      	je	0x163fd <generic_kprobe_path+0xba6d>
   16265:      	addq	$0x18, %r15
   16269:      	movl	$0x4, %eax
   1626e:      	leaq	0x30(%rsp), %rdi
   16273:      	movl	$0x8, %esi
   16278:      	movq	%r15, %rdx
   1627b:      	callq	*%rax
   1627d:      	movq	(%rsp), %r15
   16281:      	movq	%r15, 0x40(%rsp)
   16286:      	leaq	0x20(%r15), %rdx
   1628a:      	movq	%rdx, 0x38(%rsp)
   1628f:      	movq	0x30(%rsp), %r12
   16294:      	cmpq	0x18(%rsp), %r12
   16299:      	jne	0x162a6 <generic_kprobe_path+0xb916>
   1629b:      	cmpq	0x20(%rsp), %rdx
   162a0:      	je	0x163fd <generic_kprobe_path+0xba6d>
   162a6:      	movl	$0x4, %eax
   162ab:      	leaq	0x10(%rsp), %rdi
   162b0:      	movl	$0x8, %esi
   162b5:      	callq	*%rax
   162b7:      	cmpq	0x10(%rsp), %r12
   162bc:      	je	0x163a6 <generic_kprobe_path+0xba16>
   162c2:      	leaq	0x18(%r12), %rbx
   162c7:      	movl	$0x4, %eax
   162cc:      	movq	%rbp, %rdi
   162cf:      	movl	$0x8, %esi
   162d4:      	movq	%rbx, %rdx
   162d7:      	callq	*%rax
   162d9:      	cmpq	%r12, (%rsp)
   162dd:      	je	0x163a6 <generic_kprobe_path+0xba16>
   162e3:      	movl	$0x4, %eax
   162e8:      	leaq	0x8(%rsp), %rdi
   162ed:      	movl	$0x8, %esi
   162f2:      	movq	%rbx, %rdx
   162f5:      	callq	*%rax
   162f7:      	addq	$0x20, %r12
   162fb:      	movl	$0x4, %eax
   16300:      	leaq	0x58(%rsp), %rdi
   16305:      	movl	$0x10, %ecx
   1630a:      	movl	$0x10, %esi
   1630f:      	movq	%r12, %rdx
   16312:      	callq	*%rax
   16314:      	movq	0x28(%rsp), %rbx
   16319:      	movq	0x48(%rsp), %rax
   1631e:      	movl	0x5c(%rsp), %r15d
   16323:      	subq	%rbx, %rax
   16326:      	movl	0x50(%rsp), %r12d
   1632b:      	movl	%r15d, %edx
   1632e:      	subl	%r12d, %edx
   16331:      	movl	$0x0, %ecx
   16336:      	cmovbl	%ecx, %edx
   16339:      	addq	0x60(%rsp), %rdx
   1633e:      	xorl	%esi, %esi
   16340:      	cmpl	%r15d, %r12d
   16343:      	seta	%sil
   16347:      	movl	%r15d, %ecx
   1634a:      	cmovbl	%r12d, %ecx
   1634e:      	addl	%ecx, %esi
   16350:      	movl	%r12d, %edi
   16353:      	subl	%esi, %edi
   16355:      	movl	%edi, 0x50(%rsp)
   16359:      	subq	%rsi, %rax
   1635c:      	jb	0x16402 <generic_kprobe_path+0xba72>
   16362:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16368:      	ja	0x16402 <generic_kprobe_path+0xba72>
   1636e:      	cmpl	%r15d, %r12d
   16371:      	jbe	0x16377 <generic_kprobe_path+0xb9e7>
   16373:      	movb	$0x2f, (%rbx,%rax)
   16377:      	xorl	%edi, %edi
   16379:      	cmpl	%r15d, %r12d
   1637c:      	seta	%dil
   16380:      	movzbl	%cl, %esi
   16383:      	addq	%rax, %rbx
   16386:      	addq	%rbx, %rdi
   16389:      	movl	$0x4, %eax
   1638e:      	callq	*%rax
   16390:      	movq	%rbx, 0x48(%rsp)
   16395:      	cmpl	%r15d, %r12d
   16398:      	jbe	0x16402 <generic_kprobe_path+0xba72>
   1639a:      	movq	0x8(%rsp), %rax
   1639f:      	movq	%rax, 0x30(%rsp)
   163a4:      	jmp	0x163ee <generic_kprobe_path+0xba5e>
   163a6:      	leaq	0x10(%r15), %rdx
   163aa:      	movl	$0x4, %eax
   163af:      	movq	%rbp, %rdi
   163b2:      	movl	$0x8, %esi
   163b7:      	callq	*%rax
   163b9:      	movq	0x40(%rsp), %rax
   163be:      	cmpq	(%rsp), %rax
   163c2:      	je	0x163fd <generic_kprobe_path+0xba6d>
   163c4:      	addq	$0x18, %r15
   163c8:      	movl	$0x4, %eax
   163cd:      	leaq	0x30(%rsp), %rdi
   163d2:      	movl	$0x8, %esi
   163d7:      	movq	%r15, %rdx
   163da:      	callq	*%rax
   163dc:      	movq	(%rsp), %rax
   163e0:      	movq	%rax, 0x40(%rsp)
   163e5:      	addq	$0x20, %rax
   163e9:      	movq	%rax, 0x38(%rsp)
   163ee:      	movl	0x6c(%rsp), %eax
   163f2:      	addl	$-0x80, %eax
   163f5:      	jne	0xab33 <generic_kprobe_path+0x1a3>
   163fb:      	jmp	0x16402 <generic_kprobe_path+0xba72>
   163fd:      	movb	$0x1, 0x54(%rsp)
   16402:      	movl	0x6428(%r14), %eax
   16409:      	incl	%eax
   1640b:      	movl	%eax, 0x6428(%r14)
   16412:      	movl	0x48(%rsp), %ecx
   16416:      	subl	0x80(%rsp), %ecx
   1641d:      	movl	%ecx, 0x6424(%r14)
   16424:      	cmpb	$0x0, 0x54(%rsp)
   16429:      	jne	0x16471 <generic_kprobe_path+0xbae1>
   1642b:      	cmpl	$0x8, %eax
   1642e:      	je	0x16471 <generic_kprobe_path+0xbae1>
   16430:      	movq	0x30(%rsp), %rax
   16435:      	movq	%rax, 0x6458(%r14)
   1643c:      	movq	0x38(%rsp), %rax
   16441:      	movq	%rax, 0x6460(%r14)
   16448:      	movq	0x40(%rsp), %rax
   1644d:      	movq	%rax, 0x6468(%r14)
   16454:      	movq	(%rip), %rcx            # 0x1645b <generic_kprobe_path+0xbacb>
   1645b:      	movl	$0x6, %edx
   16460:      	movl	$0xc, %eax
   16465:      	movq	0x78(%rsp), %rdi
   1646a:      	movl	$0x6, %edx
   1646f:      	jmp	0x1648c <generic_kprobe_path+0xbafc>
   16471:      	movq	(%rip), %rcx            # 0x16478 <generic_kprobe_path+0xbae8>
   16478:      	movl	$0x1, %edx
   1647d:      	movl	$0xc, %eax
   16482:      	movq	0x78(%rsp), %rdi
   16487:      	movl	$0x1, %edx
   1648c:      	movq	(%rip), %rsi            # 0x16493 <generic_kprobe_path+0xbb03>
   16493:      	jmp	0x16807 <generic_kprobe_path+0xbe77>
   16498:      	movl	$0x1, (%rsp)
   1649f:      	movq	(%rip), %rdi            # 0x164a6 <generic_kprobe_path+0xbb16>
   164a6:      	xorl	%ecx, %ecx
   164a8:      	leaq	0x18(%rsp), %rsi
   164ad:      	movq	%rsp, %rdx
   164b0:      	movl	$0x2, %eax
   164b5:      	xorl	%ecx, %ecx
   164b7:      	callq	*%rax
   164b9:      	movq	0x58(%rsp), %r12
   164be:      	leaq	0x10(%r12), %rdx
   164c3:      	leaq	0x18(%rsp), %rdi
   164c8:      	movl	$0x8, %ecx
   164cd:      	movl	$0x4, %eax
   164d2:      	leaq	0xfff(%r15), %rbx
   164d9:      	movl	$0x8, %esi
   164de:      	callq	*%rax
   164e0:      	cmpq	$0x0, 0x18(%rsp)
   164e6:      	jne	0x1652f <generic_kprobe_path+0xbb9f>
   164e8:      	leaq	0x18(%r12), %rdx
   164ed:      	leaq	0x18(%rsp), %rdi
   164f2:      	movl	$0x8, %ecx
   164f7:      	movl	$0x4, %eax
   164fc:      	movl	$0x8, %esi
   16501:      	callq	*%rax
   16503:      	cmpq	%r12, 0x18(%rsp)
   16508:      	je	0x1652f <generic_kprobe_path+0xbb9f>
   1650a:      	movq	%r15, %rbx
   1650d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   16514:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   1651e:      	movq	%rax, 0xff5(%r15)
   16525:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   1652f:      	movl	$0x23, %eax
   16534:      	callq	*%rax
   16536:      	leaq	0xd50(%rax), %rdx
   1653d:      	movq	%rsp, %rdi
   16540:      	movl	$0x8, %ecx
   16545:      	movl	$0x4, %eax
   1654a:      	movl	$0x8, %esi
   1654f:      	callq	*%rax
   16551:      	testq	%rax, %rax
   16554:      	je	0x165b3 <generic_kprobe_path+0xbc23>
   16556:      	negl	%eax
   16558:      	movw	%ax, 0x18(%rsp)
   1655d:      	movw	$0x6, 0x1a(%rsp)
   16564:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   1656e:      	movq	%rax, 0x1c(%rsp)
   16573:      	movq	(%rip), %rdi            # 0x1657a <generic_kprobe_path+0xbbea>
   1657a:      	leaq	0x18(%rsp), %rsi
   1657f:      	movl	$0x1, %eax
   16584:      	callq	*%rax
   16586:      	testq	%rax, %rax
   16589:      	je	0x1658f <generic_kprobe_path+0xbbff>
   1658b:      	incl	(%rax)
   1658d:      	jmp	0x165b3 <generic_kprobe_path+0xbc23>
   1658f:      	movl	$0x1, 0x8(%rsp)
   16597:      	movq	(%rip), %rdi            # 0x1659e <generic_kprobe_path+0xbc0e>
   1659e:      	xorl	%ecx, %ecx
   165a0:      	leaq	0x18(%rsp), %rsi
   165a5:      	leaq	0x8(%rsp), %rdx
   165aa:      	movl	$0x2, %eax
   165af:      	xorl	%ecx, %ecx
   165b1:      	callq	*%rax
   165b3:      	movq	(%rsp), %rdx
   165b7:      	leaq	0x18(%rdx), %r13
   165bb:      	movq	0x6440(%r14), %r12
   165c2:      	leaq	0x6448(%r14), %rdi
   165c9:      	addq	$0x20, %rdx
   165cd:      	movl	$0x8, %ecx
   165d2:      	movl	$0x4, %eax
   165d7:      	movl	$0x8, %esi
   165dc:      	callq	*%rax
   165de:      	testq	%rax, %rax
   165e1:      	je	0x16640 <generic_kprobe_path+0xbcb0>
   165e3:      	negl	%eax
   165e5:      	movw	%ax, 0x18(%rsp)
   165ea:      	movw	$0x6, 0x1a(%rsp)
   165f1:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   165fb:      	movq	%rax, 0x1c(%rsp)
   16600:      	movq	(%rip), %rdi            # 0x16607 <generic_kprobe_path+0xbc77>
   16607:      	leaq	0x18(%rsp), %rsi
   1660c:      	movl	$0x1, %eax
   16611:      	callq	*%rax
   16613:      	testq	%rax, %rax
   16616:      	je	0x1661c <generic_kprobe_path+0xbc8c>
   16618:      	incl	(%rax)
   1661a:      	jmp	0x16640 <generic_kprobe_path+0xbcb0>
   1661c:      	movl	$0x1, 0x8(%rsp)
   16624:      	movq	(%rip), %rdi            # 0x1662b <generic_kprobe_path+0xbc9b>
   1662b:      	xorl	%ecx, %ecx
   1662d:      	leaq	0x18(%rsp), %rsi
   16632:      	leaq	0x8(%rsp), %rdx
   16637:      	movl	$0x2, %eax
   1663c:      	xorl	%ecx, %ecx
   1663e:      	callq	*%rax
   16640:      	leaq	0x6450(%r14), %rdi
   16647:      	movl	$0x8, %ecx
   1664c:      	movl	$0x4, %eax
   16651:      	movl	$0x8, %esi
   16656:      	movq	%r13, %rdx
   16659:      	callq	*%rax
   1665b:      	testq	%rax, %rax
   1665e:      	je	0x166bd <generic_kprobe_path+0xbd2d>
   16660:      	negl	%eax
   16662:      	movw	%ax, 0x18(%rsp)
   16667:      	movw	$0x6, 0x1a(%rsp)
   1666e:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   16678:      	movq	%rax, 0x1c(%rsp)
   1667d:      	movq	(%rip), %rdi            # 0x16684 <generic_kprobe_path+0xbcf4>
   16684:      	leaq	0x18(%rsp), %rsi
   16689:      	movl	$0x1, %eax
   1668e:      	callq	*%rax
   16690:      	testq	%rax, %rax
   16693:      	je	0x16699 <generic_kprobe_path+0xbd09>
   16695:      	incl	(%rax)
   16697:      	jmp	0x166bd <generic_kprobe_path+0xbd2d>
   16699:      	movl	$0x1, 0x8(%rsp)
   166a1:      	movq	(%rip), %rdi            # 0x166a8 <generic_kprobe_path+0xbd18>
   166a8:      	xorl	%ecx, %ecx
   166aa:      	leaq	0x18(%rsp), %rsi
   166af:      	leaq	0x8(%rsp), %rdx
   166b4:      	movl	$0x2, %eax
   166b9:      	xorl	%ecx, %ecx
   166bb:      	callq	*%rax
   166bd:      	leaq	0x6458(%r14), %rdi
   166c4:      	leaq	0x8(%r12), %rdx
   166c9:      	movl	$0x8, %ecx
   166ce:      	movl	$0x4, %eax
   166d3:      	movl	$0x8, %esi
   166d8:      	callq	*%rax
   166da:      	testq	%rax, %rax
   166dd:      	je	0x1673c <generic_kprobe_path+0xbdac>
   166df:      	negl	%eax
   166e1:      	movw	%ax, 0x18(%rsp)
   166e6:      	movw	$0x6, 0x1a(%rsp)
   166ed:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   166f7:      	movq	%rax, 0x1c(%rsp)
   166fc:      	movq	(%rip), %rdi            # 0x16703 <generic_kprobe_path+0xbd73>
   16703:      	leaq	0x18(%rsp), %rsi
   16708:      	movl	$0x1, %eax
   1670d:      	callq	*%rax
   1670f:      	testq	%rax, %rax
   16712:      	je	0x16718 <generic_kprobe_path+0xbd88>
   16714:      	incl	(%rax)
   16716:      	jmp	0x1673c <generic_kprobe_path+0xbdac>
   16718:      	movl	$0x1, 0x8(%rsp)
   16720:      	movq	(%rip), %rdi            # 0x16727 <generic_kprobe_path+0xbd97>
   16727:      	xorl	%ecx, %ecx
   16729:      	leaq	0x18(%rsp), %rsi
   1672e:      	leaq	0x8(%rsp), %rdx
   16733:      	movl	$0x2, %eax
   16738:      	xorl	%ecx, %ecx
   1673a:      	callq	*%rax
   1673c:      	movq	%r14, %rdi
   1673f:      	addq	$0x6460, %rdi           # imm = 0x6460
   16746:      	movl	$0x8, %ecx
   1674b:      	movl	$0x4, %eax
   16750:      	movl	$0x8, %esi
   16755:      	movq	%r12, %rdx
   16758:      	callq	*%rax
   1675a:      	testq	%rax, %rax
   1675d:      	je	0x167bc <generic_kprobe_path+0xbe2c>
   1675f:      	negl	%eax
   16761:      	movw	%ax, 0x18(%rsp)
   16766:      	movw	$0x6, 0x1a(%rsp)
   1676d:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   16777:      	movq	%rax, 0x1c(%rsp)
   1677c:      	movq	(%rip), %rdi            # 0x16783 <generic_kprobe_path+0xbdf3>
   16783:      	leaq	0x18(%rsp), %rsi
   16788:      	movl	$0x1, %eax
   1678d:      	callq	*%rax
   1678f:      	testq	%rax, %rax
   16792:      	je	0x16798 <generic_kprobe_path+0xbe08>
   16794:      	incl	(%rax)
   16796:      	jmp	0x167bc <generic_kprobe_path+0xbe2c>
   16798:      	movl	$0x1, 0x8(%rsp)
   167a0:      	movq	(%rip), %rdi            # 0x167a7 <generic_kprobe_path+0xbe17>
   167a7:      	xorl	%ecx, %ecx
   167a9:      	leaq	0x18(%rsp), %rsi
   167ae:      	leaq	0x8(%rsp), %rdx
   167b3:      	movl	$0x2, %eax
   167b8:      	xorl	%ecx, %ecx
   167ba:      	callq	*%rax
   167bc:      	movq	0x6460(%r14), %rax
   167c3:      	addq	$-0x20, %rax
   167c7:      	movq	%rax, 0x6468(%r14)
   167ce:      	movl	$0x0, 0x6428(%r14)
   167d9:      	subl	%r15d, %ebx
   167dc:      	movl	%ebx, 0x6424(%r14)
   167e3:      	movl	$0x1, 0x6420(%r14)
   167ee:      	movq	(%rip), %rsi            # 0x167f5 <generic_kprobe_path+0xbe65>
   167f5:      	movl	$0x6, %ecx
   167fa:      	movl	$0xc, %eax
   167ff:      	movq	%rbp, %rdi
   16802:      	movl	$0x6, %edx
   16807:      	callq	*%rax
   16809:      	xorl	%eax, %eax
   1680b:      	addq	$0x88, %rsp
   16812:      	popq	%rbx
   16813:      	popq	%r12
   16815:      	popq	%r13
   16817:      	popq	%r14
   16819:      	popq	%r15
   1681b:      	popq	%rbp
   1681c:      	retq

Disassembly of section kprobe.multi/generic_kprobe:

0000000000000000 <generic_kprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_kprobe_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x634 <generic_kprobe_event+0x634>
      38:      	movq	%rax, %r14
      3b:      	movl	$0xae, %eax
      40:      	movq	%rbx, %rdi
      43:      	callq	*%rax
      45:      	leaq	0x5ef8(%r14), %rsi
      4c:      	movl	%eax, 0x5ef8(%r14)
      53:      	movq	(%rip), %rdi            # 0x5a <generic_kprobe_event+0x5a>
      5a:      	movl	$0x1, %eax
      5f:      	callq	*%rax
      61:      	testq	%rax, %rax
      64:      	je	0x634 <generic_kprobe_event+0x634>
      6a:      	movl	0x64(%rax), %ecx
      6d:      	movl	%ecx, 0x14(%rsp)
      71:      	testl	%ecx, %ecx
      73:      	je	0x242 <generic_kprobe_event+0x242>
      79:      	movq	%rax, %r12
      7c:      	movq	(%rip), %rdi            # 0x83 <generic_kprobe_event+0x83>
      83:      	leaq	0x14(%rsp), %rsi
      88:      	movl	$0x1, %eax
      8d:      	callq	*%rax
      8f:      	testq	%rax, %rax
      92:      	je	0x634 <generic_kprobe_event+0x634>
      98:      	movq	%rax, %r15
      9b:      	movl	$0x0, 0x3c(%rsp)
      a3:      	movq	(%rip), %rdi            # 0xaa <generic_kprobe_event+0xaa>
      aa:      	leaq	0x3c(%rsp), %rsi
      af:      	movl	$0x1, %eax
      b4:      	callq	*%rax
      b6:      	testq	%rax, %rax
      b9:      	je	0xdf <generic_kprobe_event+0xdf>
      bb:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      c3:      	jne	0xe3 <generic_kprobe_event+0xe3>
      c5:      	movl	$0x50, %eax
      ca:      	callq	*%rax
      cc:      	movq	%rax, 0x8(%rsp)
      d1:      	testq	%rax, %rax
      d4:      	jne	0x1fd <generic_kprobe_event+0x1fd>
      da:      	jmp	0x634 <generic_kprobe_event+0x634>
      df:      	xorl	%ebp, %ebp
      e1:      	jmp	0xe6 <generic_kprobe_event+0xe6>
      e3:      	movl	0x10(%rax), %ebp
      e6:      	movl	$0x23, %eax
      eb:      	callq	*%rax
      ed:      	movq	$0x0, 0x20(%rsp)
      f6:      	leaq	0xf90(%rax), %rdx
      fd:      	leaq	0x28(%rsp), %rdi
     102:      	movl	$0x8, %ecx
     107:      	movl	$0x71, %eax
     10c:      	movl	$0x8, %esi
     111:      	callq	*%rax
     113:      	movq	0x28(%rsp), %rax
     118:      	testq	%rax, %rax
     11b:      	je	0x634 <generic_kprobe_event+0x634>
     121:      	cmpl	$0xb, %ebp
     124:      	ja	0x634 <generic_kprobe_event+0x634>
     12a:      	movl	%ebp, %edx
     12c:      	leaq	(%rax,%rdx,8), %rcx
     130:      	leaq	0x40(%rsp), %rdi
     135:      	movl	$0x8, %esi
     13a:      	movl	$0x71, %eax
     13f:      	shlq	$0x3, %rdx
     143:      	addq	0x28(%rsp), %rdx
     148:      	movl	$0x8, %esi
     14d:      	callq	*%rax
     14f:      	movq	0x40(%rsp), %rcx
     154:      	testq	%rcx, %rcx
     157:      	je	0x634 <generic_kprobe_event+0x634>
     15d:      	leaq	0x20(%rsp), %rdi
     162:      	movl	$0x8, %edx
     167:      	movl	$0x71, %eax
     16c:      	movq	0x40(%rsp), %rdx
     171:      	movl	$0x8, %esi
     176:      	callq	*%rax
     178:      	movq	0x20(%rsp), %rdx
     17d:      	testq	%rdx, %rdx
     180:      	je	0x634 <generic_kprobe_event+0x634>
     186:      	movq	$0x0, 0x40(%rsp)
     18f:      	addq	$0x100, %rdx            # imm = 0x100
     196:      	leaq	0x40(%rsp), %rdi
     19b:      	movl	$0x8, %ecx
     1a0:      	movl	$0x71, %eax
     1a5:      	movl	$0x8, %esi
     1aa:      	callq	*%rax
     1ac:      	movq	0x40(%rsp), %rdx
     1b1:      	movq	$0x0, 0x40(%rsp)
     1ba:      	testq	%rdx, %rdx
     1bd:      	je	0x1ed <generic_kprobe_event+0x1ed>
     1bf:      	addq	$0x60, %rdx
     1c3:      	leaq	0x40(%rsp), %rdi
     1c8:      	movl	$0x8, %ecx
     1cd:      	movl	$0x71, %eax
     1d2:      	movl	$0x8, %esi
     1d7:      	callq	*%rax
     1d9:      	movq	0x40(%rsp), %rax
     1de:      	movq	%rax, 0x8(%rsp)
     1e3:      	testq	%rax, %rax
     1e6:      	jne	0x1fd <generic_kprobe_event+0x1fd>
     1e8:      	jmp	0x634 <generic_kprobe_event+0x634>
     1ed:      	xorl	%eax, %eax
     1ef:      	movq	%rax, 0x8(%rsp)
     1f4:      	testq	%rax, %rax
     1f7:      	je	0x634 <generic_kprobe_event+0x634>
     1fd:      	movq	%rax, 0x40(%rsp)
     202:      	movq	(%rip), %rdi            # 0x209 <generic_kprobe_event+0x209>
     209:      	leaq	0x40(%rsp), %rsi
     20e:      	movl	$0x1, %eax
     213:      	callq	*%rax
     215:      	testq	%rax, %rax
     218:      	je	0x227 <generic_kprobe_event+0x227>
     21a:      	movq	(%rax), %rax
     21d:      	testq	%rax, %rax
     220:      	je	0x227 <generic_kprobe_event+0x227>
     222:      	movq	%rax, 0x8(%rsp)
     227:      	leaq	0x8(%rsp), %rsi
     22c:      	movl	$0x1, %eax
     231:      	movq	%r15, %rdi
     234:      	callq	*%rax
     236:      	testq	%rax, %rax
     239:      	movq	%r12, %rax
     23c:      	je	0x648 <generic_kprobe_event+0x648>
     242:      	movl	(%rax), %eax
     244:      	movq	%rax, 0x60(%r14)
     248:      	movq	$0x0, 0x68(%r14)
     250:      	movq	$0x0, 0x5efc(%r14)
     25b:      	movl	$0x0, 0x6420(%r14)
     266:      	movq	$0x0, 0x5eb8(%r14)
     271:      	movq	$0x0, 0x5ec0(%r14)
     27c:      	movq	$0x0, 0x5ec8(%r14)
     287:      	movq	$0x0, 0x5ed0(%r14)
     292:      	movq	$0x0, 0x5ed8(%r14)
     29d:      	movb	$0x0, 0x5ee0(%r14)
     2a5:      	movl	$0x23, %eax
     2aa:      	callq	*%rax
     2ac:      	movq	%rax, %r15
     2af:      	leaq	0xd70(%rax), %rdx
     2b6:      	leaq	0x20(%rsp), %rdi
     2bb:      	movl	$0x8, %ecx
     2c0:      	movl	$0x4, %eax
     2c5:      	leaq	0x20(%r14), %r12
     2c9:      	movl	$0x4, %r13d
     2cf:      	movl	$0x8, %esi
     2d4:      	callq	*%rax
     2d6:      	movq	0x20(%rsp), %rcx
     2db:      	leaq	0x40(%rsp), %rdi
     2e0:      	movl	$0x48, %edx
     2e5:      	movl	$0x4, %eax
     2ea:      	movq	0x20(%rsp), %rdx
     2ef:      	movl	$0x48, %esi
     2f4:      	callq	*%rax
     2f6:      	movl	$0x218, %edx            # imm = 0x218
     2fb:      	movq	0x48(%rsp), %rcx
     300:      	addq	%rdx, %rcx
     303:      	movl	$0x4, %esi
     308:      	movl	$0x4, %eax
     30d:      	addq	0x48(%rsp), %rdx
     312:      	movq	%r12, %rdi
     315:      	movl	$0x4, %esi
     31a:      	callq	*%rax
     31c:      	leaq	0x24(%r14), %rdi
     320:      	movl	$0x4d8, %edx            # imm = 0x4D8
     325:      	movq	0x50(%rsp), %rcx
     32a:      	addq	%rdx, %rcx
     32d:      	movl	$0x4, %esi
     332:      	movl	$0x4, %eax
     337:      	addq	0x50(%rsp), %rdx
     33c:      	movl	$0x4, %esi
     341:      	callq	*%rax
     343:      	leaq	0x28(%r14), %rdi
     347:      	movq	0x58(%rsp), %rcx
     34c:      	addq	$0x58, %rcx
     350:      	movl	$0x4, %edx
     355:      	movl	$0x4, %eax
     35a:      	movq	0x58(%rsp), %rdx
     35f:      	addq	$0x58, %rdx
     363:      	movl	$0x4, %esi
     368:      	callq	*%rax
     36a:      	movq	$0x0, 0x8(%rsp)
     373:      	leaq	0xb58(%r15), %rdx
     37a:      	leaq	0x8(%rsp), %rdi
     37f:      	movl	$0x8, %ecx
     384:      	movl	$0x4, %eax
     389:      	movl	$0x8, %esi
     38e:      	callq	*%rax
     390:      	movq	0x8(%rsp), %rcx
     395:      	testq	%rcx, %rcx
     398:      	je	0x42e <generic_kprobe_event+0x42e>
     39e:      	movl	$0x0, 0x18(%rsp)
     3a6:      	addq	$0x4, %rcx
     3aa:      	leaq	0x18(%rsp), %rdi
     3af:      	movl	$0x4, %eax
     3b4:      	movq	0x8(%rsp), %rdx
     3b9:      	addq	$0x4, %rdx
     3bd:      	movl	$0x4, %esi
     3c2:      	callq	*%rax
     3c4:      	movq	0x8(%rsp), %rax
     3c9:      	movslq	0x18(%rsp), %rcx
     3ce:      	shlq	$0x4, %rcx
     3d2:      	addq	%rax, %rcx
     3d5:      	addq	$0x80, %rcx
     3dc:      	leaq	0x28(%rsp), %rdi
     3e1:      	movl	$0x10, %edx
     3e6:      	movl	$0x4, %eax
     3eb:      	movq	0x8(%rsp), %rcx
     3f0:      	movslq	0x18(%rsp), %rdx
     3f5:      	shlq	$0x4, %rdx
     3f9:      	addq	%rcx, %rdx
     3fc:      	addq	$0x80, %rdx
     403:      	movl	$0x10, %esi
     408:      	callq	*%rax
     40a:      	leaq	0x2c(%r14), %rdi
     40e:      	movl	$0x158, %edx            # imm = 0x158
     413:      	movq	0x30(%rsp), %rcx
     418:      	addq	%rdx, %rcx
     41b:      	movl	$0x4, %eax
     420:      	addq	0x30(%rsp), %rdx
     425:      	movl	$0x4, %esi
     42a:      	callq	*%rax
     42c:      	jmp	0x436 <generic_kprobe_event+0x436>
     42e:      	movl	$0x0, 0x2c(%r14)
     436:      	leaq	0x30(%r14), %rdi
     43a:      	movl	$0x158, %r12d           # imm = 0x158
     440:      	movq	0x60(%rsp), %rcx
     445:      	addq	%r12, %rcx
     448:      	movl	$0x4, %edx
     44d:      	movl	$0x4, %eax
     452:      	movq	0x60(%rsp), %rdx
     457:      	addq	%r12, %rdx
     45a:      	movl	$0x4, %esi
     45f:      	callq	*%rax
     461:      	leaq	0x34(%r14), %rdi
     465:      	movl	$0x118, %edx            # imm = 0x118
     46a:      	movq	0x68(%rsp), %rcx
     46f:      	addq	%rdx, %rcx
     472:      	movl	$0x4, %esi
     477:      	movl	$0x4, %eax
     47c:      	addq	0x68(%rsp), %rdx
     481:      	movl	$0x4, %esi
     486:      	callq	*%rax
     488:      	leaq	0x38(%r14), %rdi
     48c:      	movl	$0x98, %r13d
     492:      	movq	0x70(%rsp), %rcx
     497:      	addq	%r13, %rcx
     49a:      	movl	$0x4, %edx
     49f:      	movl	$0x4, %eax
     4a4:      	movq	0x70(%rsp), %rdx
     4a9:      	addq	%r13, %rdx
     4ac:      	movl	$0x4, %esi
     4b1:      	callq	*%rax
     4b3:      	leaq	0x3c(%r14), %rdi
     4b7:      	movq	0x78(%rsp), %rcx
     4bc:      	addq	%r13, %rcx
     4bf:      	movl	$0x4, %edx
     4c4:      	movl	$0x4, %eax
     4c9:      	addq	0x78(%rsp), %r13
     4ce:      	movl	$0x4, %esi
     4d3:      	movq	%r13, %rdx
     4d6:      	callq	*%rax
     4d8:      	leaq	0x40(%r14), %rdi
     4dc:      	movq	0x80(%rsp), %rcx
     4e4:      	addq	$0x58, %rcx
     4e8:      	movl	$0x4, %edx
     4ed:      	movl	$0x4, %eax
     4f2:      	movq	0x80(%rsp), %rdx
     4fa:      	addq	$0x58, %rdx
     4fe:      	movl	$0x4, %esi
     503:      	callq	*%rax
     505:      	movq	$0x0, 0x28(%rsp)
     50e:      	movq	$0x0, 0x8(%rsp)
     517:      	addq	$0xd00, %r15            # imm = 0xD00
     51e:      	leaq	0x28(%rsp), %rdi
     523:      	movl	$0x8, %ecx
     528:      	movl	$0x4, %eax
     52d:      	movl	$0x8, %esi
     532:      	movq	%r15, %rdx
     535:      	callq	*%rax
     537:      	movl	$0x90, %edx
     53c:      	movq	0x28(%rsp), %rcx
     541:      	addq	%rdx, %rcx
     544:      	leaq	0x8(%rsp), %rdi
     549:      	movl	$0x8, %esi
     54e:      	movl	$0x4, %eax
     553:      	addq	0x28(%rsp), %rdx
     558:      	movl	$0x8, %esi
     55d:      	callq	*%rax
     55f:      	leaq	0x44(%r14), %rdi
     563:      	movq	0x8(%rsp), %rcx
     568:      	addq	%r12, %rcx
     56b:      	movl	$0x4, %edx
     570:      	movl	$0x4, %eax
     575:      	addq	0x8(%rsp), %r12
     57a:      	movl	$0x4, %esi
     57f:      	movq	%r12, %rdx
     582:      	callq	*%rax
     584:      	leaq	0x48(%r14), %r12
     588:      	leaq	0x40(%rsp), %rdi
     58d:      	movl	$0x8, %ecx
     592:      	movl	$0x4, %eax
     597:      	movl	$0x8, %esi
     59c:      	movq	%r15, %rdx
     59f:      	callq	*%rax
     5a1:      	movq	0x40(%rsp), %r15
     5a6:      	leaq	0x50(%r14), %rdi
     5aa:      	leaq	0x40(%r15), %rdx
     5ae:      	movl	$0x8, %ecx
     5b3:      	movl	$0x4, %eax
     5b8:      	movl	$0x8, %esi
     5bd:      	callq	*%rax
     5bf:      	movq	%r14, %rdi
     5c2:      	addq	$0x58, %rdi
     5c6:      	leaq	0x30(%r15), %rdx
     5ca:      	movl	$0x8, %ecx
     5cf:      	movl	$0x4, %eax
     5d4:      	movl	$0x8, %esi
     5d9:      	callq	*%rax
     5db:      	addq	$0x38, %r15
     5df:      	movl	$0x8, %ecx
     5e4:      	movl	$0x4, %eax
     5e9:      	movq	%r12, %rdi
     5ec:      	movl	$0x8, %esi
     5f1:      	movq	%r15, %rdx
     5f4:      	callq	*%rax
     5f6:      	movb	$0x0, 0x5f08(%r14)
     5fe:      	movb	$0x0, 0x1(%r14)
     603:      	movq	$0x0, 0x5ee8(%r14)
     60e:      	movq	$0x0, 0x5ef0(%r14)
     619:      	movq	(%rip), %rsi            # 0x620 <generic_kprobe_event+0x620>
     620:      	movl	$0x2, %ecx
     625:      	movl	$0xc, %eax
     62a:      	movq	%rbx, %rdi
     62d:      	movl	$0x2, %edx
     632:      	callq	*%rax
     634:      	xorl	%eax, %eax
     636:      	addq	$0x88, %rsp
     63d:      	popq	%rbx
     63e:      	popq	%r12
     640:      	popq	%r13
     642:      	popq	%r14
     644:      	popq	%r15
     646:      	popq	%rbp
     647:      	retq
     648:      	movq	$-0x1, 0x18(%rsp)
     651:      	leaq	0x18(%rsp), %rsi
     656:      	movl	$0x1, %eax
     65b:      	movq	%r15, %rdi
     65e:      	callq	*%rax
     660:      	testq	%rax, %rax
     663:      	je	0x634 <generic_kprobe_event+0x634>
     665:      	movl	$0x1, 0x14(%rsp)
     66d:      	movq	(%rip), %rdi            # 0x674 <generic_kprobe_event+0x674>
     674:      	leaq	0x14(%rsp), %rsi
     679:      	movl	$0x1, %eax
     67e:      	callq	*%rax
     680:      	testq	%rax, %rax
     683:      	je	0x634 <generic_kprobe_event+0x634>
     685:      	movq	%rax, %rdi
     688:      	leaq	0x8(%rsp), %rsi
     68d:      	movl	$0x1, %eax
     692:      	callq	*%rax
     694:      	testq	%rax, %rax
     697:      	movq	%r12, %rax
     69a:      	jne	0x634 <generic_kprobe_event+0x634>
     69c:      	jmp	0x242 <generic_kprobe_event+0x242>

Disassembly of section kprobe.multi/generic_kprobe_override:

0000000000000000 <generic_kprobe_override>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movq	%rdi, %rbx
       8:      	movl	$0xe, %eax
       d:      	callq	*%rax
       f:      	movq	%rax, 0x8(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_kprobe_override+0x1b>
      1b:      	leaq	0x8(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x52 <generic_kprobe_override+0x52>
      2c:      	movslq	(%rax), %rcx
      2f:      	movq	%rax, %rdx
      32:      	movl	$0x3a, %eax
      37:      	movslq	(%rdx), %rsi
      3a:      	movq	%rbx, %rdi
      3d:      	callq	*%rax
      3f:      	movq	(%rip), %rdi            # 0x46 <generic_kprobe_override+0x46>
      46:      	leaq	0x8(%rsp), %rsi
      4b:      	movl	$0x3, %eax
      50:      	callq	*%rax
      52:      	xorl	%eax, %eax
      54:      	addq	$0x10, %rsp
      58:      	popq	%rbx
      59:      	retq

Disassembly of section fmod_ret/security_task_prctl:

0000000000000000 <generic_fmodret_override>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movl	$0xe, %eax
       a:      	callq	*%rax
       c:      	movq	%rax, 0x8(%rsp)
      11:      	movq	(%rip), %rdi            # 0x18 <generic_fmodret_override+0x18>
      18:      	leaq	0x8(%rsp), %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	je	0x48 <generic_fmodret_override+0x48>
      29:      	movq	%rax, %rbx
      2c:      	movq	(%rip), %rdi            # 0x33 <generic_fmodret_override+0x33>
      33:      	leaq	0x8(%rsp), %rsi
      38:      	movl	$0x3, %eax
      3d:      	callq	*%rax
      3f:      	movslq	(%rbx), %rax
      42:      	addq	$0x10, %rsp
      46:      	popq	%rbx
      47:      	retq
      48:      	xorl	%eax, %eax
      4a:      	addq	$0x10, %rsp
      4e:      	popq	%rbx
      4f:      	retq
