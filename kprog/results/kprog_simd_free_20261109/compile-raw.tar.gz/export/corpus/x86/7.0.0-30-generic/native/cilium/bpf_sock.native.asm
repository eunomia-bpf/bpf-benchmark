
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_sock.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq
