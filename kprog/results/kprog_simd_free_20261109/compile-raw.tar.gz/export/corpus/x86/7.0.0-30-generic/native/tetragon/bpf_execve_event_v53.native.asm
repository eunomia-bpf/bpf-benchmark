
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_execve_event_v53.native.o:	file format elf64-x86-64

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x48, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x8(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <execve_rate+0x20>
      20:      	leaq	0x8(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x2a7 <execve_rate+0x2a7>
      35:      	movq	0x8(%rax), %r15
      39:      	movq	%rax, %r12
      3c:      	movq	0x10(%rax), %rax
      40:      	movq	%rax, 0x18(%rsp)
      45:      	movl	$0x0, 0xc(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <execve_rate+0x54>
      54:      	leaq	0xc(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	testq	%rax, %rax
      63:      	je	0x28c <execve_rate+0x28c>
      69:      	movq	0x8(%rax), %r13
      6d:      	testq	%r13, %r13
      70:      	je	0x28c <execve_rate+0x28c>
      76:      	movq	%rax, %rbp
      79:      	movq	(%rip), %rdi            # 0x80 <execve_rate+0x80>
      80:      	leaq	0x18(%rsp), %rsi
      85:      	movl	$0x1, %eax
      8a:      	callq	*%rax
      8c:      	testq	%rax, %rax
      8f:      	je	0xc6 <execve_rate+0xc6>
      91:      	movq	%rax, %r14
      94:      	movq	0x10(%rax), %rax
      98:      	movq	%r15, %rcx
      9b:      	subq	%rax, %rcx
      9e:      	cmpq	%r13, %rcx
      a1:      	jbe	0x11c <execve_rate+0x11c>
      a3:      	leaq	(,%r13,2), %rdx
      ab:      	cmpq	%rdx, %rcx
      ae:      	jbe	0x124 <execve_rate+0x124>
      b0:      	movq	$0x0, 0x8(%r14)
      b8:      	movq	%r15, %rax
      bb:      	xorl	%edx, %edx
      bd:      	divq	%r13
      c0:      	imulq	%r13, %rax
      c4:      	jmp	0x12e <execve_rate+0x12e>
      c6:      	movq	$0x1, 0x20(%rsp)
      cf:      	movq	$0x0, 0x28(%rsp)
      d8:      	movq	%r15, %rax
      db:      	xorl	%edx, %edx
      dd:      	divq	%r13
      e0:      	imulq	%r13, %rax
      e4:      	movq	%rax, 0x30(%rsp)
      e9:      	movq	$0x0, 0x38(%rsp)
      f2:      	movq	$0x0, 0x40(%rsp)
      fb:      	movq	(%rip), %rdi            # 0x102 <execve_rate+0x102>
     102:      	xorl	%ecx, %ecx
     104:      	leaq	0x18(%rsp), %rsi
     109:      	leaq	0x20(%rsp), %rdx
     10e:      	movl	$0x2, %eax
     113:      	xorl	%ecx, %ecx
     115:      	callq	*%rax
     117:      	jmp	0x28c <execve_rate+0x28c>
     11c:      	movq	(%r14), %rcx
     11f:      	incq	%rcx
     122:      	jmp	0x137 <execve_rate+0x137>
     124:      	movq	(%r14), %rcx
     127:      	movq	%rcx, 0x8(%r14)
     12b:      	addq	%r13, %rax
     12e:      	movq	%rax, 0x10(%r14)
     132:      	movl	$0x1, %ecx
     137:      	movq	%rcx, (%r14)
     13a:      	movq	%r13, %rcx
     13d:      	subq	%r15, %rcx
     140:      	addq	%rax, %rcx
     143:      	imulq	0x8(%r14), %rcx
     148:      	movq	%rcx, %rax
     14b:      	xorl	%edx, %edx
     14d:      	divq	%r13
     150:      	addq	(%r14), %rax
     153:      	movq	%rax, 0x18(%r14)
     157:      	cmpq	$0x0, 0x20(%r14)
     15c:      	jne	0x2a7 <execve_rate+0x2a7>
     162:      	cmpq	(%rbp), %rax
     166:      	jb	0x28c <execve_rate+0x28c>
     16c:      	movq	%r15, 0x20(%r14)
     170:      	movl	$0x0, 0x14(%rsp)
     178:      	movq	(%rip), %rdi            # 0x17f <execve_rate+0x17f>
     17f:      	leaq	0x14(%rsp), %rcx
     184:      	movl	$0x1, %eax
     189:      	movl	$0x0, 0x10(%rsp)
     191:      	leaq	0x10(%rsp), %rsi
     196:      	callq	*%rax
     198:      	testq	%rax, %rax
     19b:      	je	0x285 <execve_rate+0x285>
     1a1:      	movl	$0xa0, 0x4(%rax)
     1a8:      	movq	%r12, %rsi
     1ab:      	addq	$0x10, %rsi
     1af:      	movq	%r15, 0x8(%rax)
     1b3:      	movw	$0x1b, (%rax)
     1b8:      	movq	%rax, %rdi
     1bb:      	addq	$0x10, %rdi
     1bf:      	movl	$0x90, %edx
     1c4:      	movq	%rax, %r15
     1c7:      	callq	0x1cc <execve_rate+0x1cc>
     1cc:      	movq	(%rip), %rsi            # 0x1d3 <execve_rate+0x1d3>
     1d3:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     1d8:      	movl	$0xa0, %edx
     1dd:      	movl	$0x19, %eax
     1e2:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     1e7:      	movl	$0xa0, %r8d
     1ed:      	movq	%rbx, %rdi
     1f0:      	movq	%r15, %rcx
     1f3:      	callq	*%rax
     1f5:      	testq	%rax, %rax
     1f8:      	jns	0x285 <execve_rate+0x285>
     1fe:      	movq	%rax, %r15
     201:      	movl	$0x0, 0x20(%rsp)
     209:      	movq	(%rip), %rdi            # 0x210 <execve_rate+0x210>
     210:      	leaq	0x20(%rsp), %rsi
     215:      	movl	$0x1, %eax
     21a:      	callq	*%rax
     21c:      	testq	%rax, %rax
     21f:      	je	0x285 <execve_rate+0x285>
     221:      	cmpq	$-0xc, %r15
     225:      	jg	0x241 <execve_rate+0x241>
     227:      	cmpq	$-0x1c, %r15
     22b:      	je	0x25b <execve_rate+0x25b>
     22d:      	cmpq	$-0x16, %r15
     231:      	je	0x273 <execve_rate+0x273>
     233:      	cmpq	$-0x10, %r15
     237:      	jne	0x26b <execve_rate+0x26b>
     239:      	addq	$0x600, %rax            # imm = 0x600
     23f:      	jmp	0x281 <execve_rate+0x281>
     241:      	cmpq	$-0xb, %r15
     245:      	je	0x263 <execve_rate+0x263>
     247:      	cmpq	$-0x7, %r15
     24b:      	je	0x27b <execve_rate+0x27b>
     24d:      	cmpq	$-0x2, %r15
     251:      	jne	0x26b <execve_rate+0x26b>
     253:      	addq	$0x5f0, %rax            # imm = 0x5F0
     259:      	jmp	0x281 <execve_rate+0x281>
     25b:      	addq	$0x610, %rax            # imm = 0x610
     261:      	jmp	0x281 <execve_rate+0x281>
     263:      	addq	$0x618, %rax            # imm = 0x618
     269:      	jmp	0x281 <execve_rate+0x281>
     26b:      	addq	$0x5e8, %rax            # imm = 0x5E8
     271:      	jmp	0x281 <execve_rate+0x281>
     273:      	addq	$0x608, %rax            # imm = 0x608
     279:      	jmp	0x281 <execve_rate+0x281>
     27b:      	addq	$0x5f8, %rax            # imm = 0x5F8
     281:      	lock
     282:      	incq	(%rax)
     285:      	cmpq	$0x0, 0x20(%r14)
     28a:      	jne	0x2a7 <execve_rate+0x2a7>
     28c:      	movq	(%rip), %rsi            # 0x293 <execve_rate+0x293>
     293:      	movl	$0x1, %ecx
     298:      	movl	$0xc, %eax
     29d:      	movq	%rbx, %rdi
     2a0:      	movl	$0x1, %edx
     2a5:      	callq	*%rax
     2a7:      	xorl	%eax, %eax
     2a9:      	addq	$0x48, %rsp
     2ad:      	popq	%rbx
     2ae:      	popq	%r12
     2b0:      	popq	%r13
     2b2:      	popq	%r14
     2b4:      	popq	%r15
     2b6:      	popq	%rbp
     2b7:      	retq
     2b8:      	nopl	(%rax,%rax)

00000000000002c0 <execve_send>:
     2c0:      	pushq	%rbp
     2c1:      	pushq	%r15
     2c3:      	pushq	%r14
     2c5:      	pushq	%r13
     2c7:      	pushq	%r12
     2c9:      	pushq	%rbx
     2ca:      	subq	$0xa8, %rsp
     2d1:      	movq	%rdi, %rbp
     2d4:      	movl	$0x0, 0x78(%rsp)
     2dc:      	movq	(%rip), %rdi            # 0x2e3 <execve_send+0x23>
     2e3:      	leaq	0x78(%rsp), %rsi
     2e8:      	movl	$0x1, %eax
     2ed:      	callq	*%rax
     2ef:      	testq	%rax, %rax
     2f2:      	je	0x11ce <execve_send+0xf0e>
     2f8:      	movq	%rax, %r14
     2fb:      	movl	$0x23, %eax
     300:      	callq	*%rax
     302:      	leaq	0xa78(%rax), %rdx
     309:      	leaq	0x8(%rsp), %rdi
     30e:      	movl	$0x8, %ecx
     313:      	movl	$0x4, %eax
     318:      	leaq	0x16c0(%r14), %rcx
     31f:      	movq	%rcx, 0x80(%rsp)
     327:      	movl	$0x8, %esi
     32c:      	callq	*%rax
     32e:      	movl	$0x5f8, %edx            # imm = 0x5F8
     333:      	movq	0x8(%rsp), %rcx
     338:      	addq	%rdx, %rcx
     33b:      	leaq	0x18(%rsp), %rdi
     340:      	movl	$0x8, %esi
     345:      	movl	$0x4, %eax
     34a:      	addq	0x8(%rsp), %rdx
     34f:      	movl	$0x8, %esi
     354:      	callq	*%rax
     356:      	movq	0x18(%rsp), %rbx
     35b:      	movl	$0x0, 0x7c(%rsp)
     363:      	movq	(%rip), %rdi            # 0x36a <execve_send+0xaa>
     36a:      	leaq	0x7c(%rsp), %rsi
     36f:      	movl	$0x1, %eax
     374:      	callq	*%rax
     376:      	testq	%rax, %rax
     379:      	je	0x8b6 <execve_send+0x5f6>
     37f:      	movq	%rax, %r15
     382:      	movq	%rbp, 0x68(%rsp)
     387:      	movq	%r14, 0x58(%rsp)
     38c:      	movl	$0x1000, 0x1840(%r14)   # imm = 0x1000
     397:      	leaq	0x1000(%rax), %r12
     39e:      	movl	$0x23, %eax
     3a3:      	callq	*%rax
     3a5:      	leaq	0xd50(%rax), %rdx
     3ac:      	leaq	0x90(%rsp), %rdi
     3b4:      	movl	$0x8, %ecx
     3b9:      	movl	$0x4, %eax
     3be:      	movl	$0x8, %esi
     3c3:      	callq	*%rax
     3c5:      	movq	0x90(%rsp), %rbp
     3cd:      	leaq	0x48(%rbx), %r13
     3d1:      	leaq	0x98(%rsp), %rdi
     3d9:      	movl	$0x8, %ecx
     3de:      	movl	$0x4, %eax
     3e3:      	movl	$0x8, %esi
     3e8:      	movq	%r13, %rdx
     3eb:      	callq	*%rax
     3ed:      	movq	0x98(%rsp), %r14
     3f5:      	leaq	0x10(%r14), %rdx
     3f9:      	leaq	0x18(%rsp), %rdi
     3fe:      	movl	$0x8, %ecx
     403:      	movl	$0x4, %eax
     408:      	movl	$0x8, %esi
     40d:      	callq	*%rax
     40f:      	cmpq	$0x0, 0x18(%rsp)
     415:      	je	0x6a1 <execve_send+0x3e1>
     41b:      	movq	%r13, 0x60(%rsp)
     420:      	movq	0x58(%rsp), %r14
     425:      	movq	$0x0, 0x20(%rsp)
     42e:      	movq	$0x0, 0x18(%rsp)
     437:      	movq	%r15, 0x28(%rsp)
     43c:      	movq	$0x0, 0x30(%rsp)
     445:      	movq	$0x0, 0x38(%rsp)
     44e:      	movq	$0x0, 0x40(%rsp)
     457:      	movq	%r12, 0x88(%rsp)
     45f:      	movq	%r12, 0x48(%rsp)
     464:      	movl	0x1840(%r14), %eax
     46b:      	movl	%eax, 0x50(%rsp)
     46f:      	leaq	0x18(%rbp), %r15
     473:      	movb	$0x0, 0x54(%rsp)
     478:      	addq	$0x20, %rbp
     47c:      	leaq	0x18(%rsp), %rdi
     481:      	movl	$0x8, %r12d
     487:      	movl	$0x4, %eax
     48c:      	addq	$0x40, %rbx
     490:      	leaq	0x20(%rsp), %r14
     495:      	leaq	0x30(%rsp), %r13
     49a:      	movl	$0x8, %esi
     49f:      	movq	%rbp, %rdx
     4a2:      	callq	*%rax
     4a4:      	movl	$0x8, %ecx
     4a9:      	movl	$0x4, %eax
     4ae:      	movq	%r14, %rdi
     4b1:      	movl	$0x8, %esi
     4b6:      	movq	%r15, %rdx
     4b9:      	callq	*%rax
     4bb:      	movl	$0x8, %ecx
     4c0:      	movl	$0x4, %eax
     4c5:      	movq	0x60(%rsp), %rdx
     4ca:      	movq	%r13, %rdi
     4cd:      	movl	$0x8, %esi
     4d2:      	callq	*%rax
     4d4:      	movl	$0x8, %ecx
     4d9:      	movl	$0x4, %eax
     4de:      	leaq	0x38(%rsp), %rdi
     4e3:      	movl	$0x8, %esi
     4e8:      	movq	%rbx, %rdx
     4eb:      	callq	*%rax
     4ed:      	movq	0x38(%rsp), %rax
     4f2:      	addq	$-0x20, %rax
     4f6:      	movq	%rax, 0x40(%rsp)
     4fb:      	movl	$0x80, %r13d
     501:      	movq	%rsp, %rbp
     504:      	jmp	0x519 <execve_send+0x259>
     506:      	nopw	%cs:(%rax,%rax)
     510:      	decl	%r13d
     513:      	je	0x6fd <execve_send+0x43d>
     519:      	movq	0x30(%rsp), %r15
     51e:      	movq	0x38(%rsp), %rdx
     523:      	movq	0x40(%rsp), %rbx
     528:      	cmpq	0x18(%rsp), %r15
     52d:      	jne	0x53a <execve_send+0x27a>
     52f:      	cmpq	0x20(%rsp), %rdx
     534:      	je	0x6f8 <execve_send+0x438>
     53a:      	movl	$0x4, %eax
     53f:      	leaq	0xa0(%rsp), %rdi
     547:      	movl	$0x8, %esi
     54c:      	callq	*%rax
     54e:      	cmpq	0xa0(%rsp), %r15
     556:      	je	0x650 <execve_send+0x390>
     55c:      	leaq	0x18(%r15), %r14
     560:      	movl	$0x4, %eax
     565:      	movq	%rbp, %rdi
     568:      	movl	$0x8, %esi
     56d:      	movq	%r14, %rdx
     570:      	callq	*%rax
     572:      	cmpq	%r15, (%rsp)
     576:      	je	0x650 <execve_send+0x390>
     57c:      	movl	$0x4, %eax
     581:      	leaq	0x70(%rsp), %rdi
     586:      	movl	$0x8, %esi
     58b:      	movq	%r14, %rdx
     58e:      	callq	*%rax
     590:      	addq	$0x20, %r15
     594:      	movl	$0x4, %eax
     599:      	leaq	0x8(%rsp), %rdi
     59e:      	movl	$0x10, %ecx
     5a3:      	movl	$0x10, %esi
     5a8:      	movq	%r15, %rdx
     5ab:      	callq	*%rax
     5ad:      	movq	0x28(%rsp), %rbx
     5b2:      	movq	0x48(%rsp), %rax
     5b7:      	movl	0xc(%rsp), %r14d
     5bc:      	subq	%rbx, %rax
     5bf:      	movl	0x50(%rsp), %r15d
     5c4:      	movl	%r14d, %edx
     5c7:      	subl	%r15d, %edx
     5ca:      	movl	$0x0, %ecx
     5cf:      	cmovbl	%ecx, %edx
     5d2:      	addq	0x10(%rsp), %rdx
     5d7:      	xorl	%esi, %esi
     5d9:      	cmpl	%r14d, %r15d
     5dc:      	seta	%sil
     5e0:      	movl	%r14d, %ecx
     5e3:      	cmovbl	%r15d, %ecx
     5e7:      	addl	%ecx, %esi
     5e9:      	movl	%r15d, %edi
     5ec:      	subl	%esi, %edi
     5ee:      	movl	%edi, 0x50(%rsp)
     5f2:      	subq	%rsi, %rax
     5f5:      	jb	0x6fd <execve_send+0x43d>
     5fb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     601:      	ja	0x6fd <execve_send+0x43d>
     607:      	cmpl	%r14d, %r15d
     60a:      	jbe	0x610 <execve_send+0x350>
     60c:      	movb	$0x2f, (%rbx,%rax)
     610:      	xorl	%edi, %edi
     612:      	cmpl	%r14d, %r15d
     615:      	seta	%dil
     619:      	movzbl	%cl, %esi
     61c:      	addq	%rax, %rbx
     61f:      	addq	%rbx, %rdi
     622:      	movl	$0x4, %eax
     627:      	callq	*%rax
     629:      	movq	%rbx, 0x48(%rsp)
     62e:      	cmpl	%r14d, %r15d
     631:      	jbe	0x6fd <execve_send+0x43d>
     637:      	movq	0x70(%rsp), %rax
     63c:      	movq	%rax, 0x30(%rsp)
     641:      	jmp	0x510 <execve_send+0x250>
     646:      	nopw	%cs:(%rax,%rax)
     650:      	leaq	0x10(%rbx), %rdx
     654:      	movl	$0x4, %eax
     659:      	movq	%rbp, %rdi
     65c:      	movl	$0x8, %esi
     661:      	callq	*%rax
     663:      	movq	0x40(%rsp), %rax
     668:      	cmpq	(%rsp), %rax
     66c:      	je	0x755 <execve_send+0x495>
     672:      	addq	$0x18, %rbx
     676:      	movl	$0x4, %eax
     67b:      	leaq	0x30(%rsp), %rdi
     680:      	movl	$0x8, %esi
     685:      	movq	%rbx, %rdx
     688:      	callq	*%rax
     68a:      	movq	(%rsp), %rax
     68e:      	movq	%rax, 0x40(%rsp)
     693:      	addq	$0x20, %rax
     697:      	movq	%rax, 0x38(%rsp)
     69c:      	jmp	0x510 <execve_send+0x250>
     6a1:      	leaq	0x18(%r14), %rdx
     6a5:      	leaq	0x18(%rsp), %rdi
     6aa:      	movl	$0x8, %ecx
     6af:      	movl	$0x4, %eax
     6b4:      	movl	$0x8, %esi
     6b9:      	callq	*%rax
     6bb:      	cmpq	%r14, 0x18(%rsp)
     6c0:      	je	0x41b <execve_send+0x15b>
     6c6:      	movq	0x58(%rsp), %r14
     6cb:      	movl	0x1840(%r14), %ecx
     6d2:      	leal	-0xa(%rcx), %eax
     6d5:      	movl	%eax, 0x1840(%r14)
     6dc:      	cmpl	$0x9, %ecx
     6df:      	jg	0xd30 <execve_send+0xa70>
     6e5:      	movl	$0xffffffdc, 0x1844(%r14) # imm = 0xFFFFFFDC
     6f0:      	movq	%r12, %rbx
     6f3:      	jmp	0x78c <execve_send+0x4cc>
     6f8:      	movb	$0x1, 0x54(%rsp)
     6fd:      	movq	0x48(%rsp), %rbx
     702:      	movq	0x88(%rsp), %rcx
     70a:      	cmpq	%rcx, %rbx
     70d:      	je	0x76c <execve_send+0x4ac>
     70f:      	xorl	%ecx, %ecx
     711:      	cmpb	$0x0, 0x54(%rsp)
     716:      	sete	%cl
     719:      	addl	%ecx, %ecx
     71b:      	movl	0x50(%rsp), %eax
     71f:      	movq	0x58(%rsp), %r14
     724:      	movl	%eax, 0x1840(%r14)
     72b:      	movl	%ecx, 0x1844(%r14)
     732:      	testl	%eax, %eax
     734:      	movq	0x68(%rsp), %rbp
     739:      	jle	0x74b <execve_send+0x48b>
     73b:      	movl	$0x1000, %ecx           # imm = 0x1000
     740:      	subl	%eax, %ecx
     742:      	movl	%ecx, 0x1840(%r14)
     749:      	movl	%ecx, %eax
     74b:      	testq	%rbx, %rbx
     74e:      	jne	0x791 <execve_send+0x4d1>
     750:      	jmp	0x8b6 <execve_send+0x5f6>
     755:      	movb	$0x1, 0x54(%rsp)
     75a:      	movq	0x48(%rsp), %rbx
     75f:      	movq	0x88(%rsp), %rcx
     767:      	cmpq	%rcx, %rbx
     76a:      	jne	0x70f <execve_send+0x44f>
     76c:      	movq	0x58(%rsp), %r14
     771:      	movl	$0x0, 0x1840(%r14)
     77c:      	movl	$0x0, 0x1844(%r14)
     787:      	xorl	%eax, %eax
     789:      	movq	%rcx, %rbx
     78c:      	movq	0x68(%rsp), %rbp
     791:      	xorl	%ecx, %ecx
     793:      	movq	%r14, %rdx
     796:      	movl	%eax, %r14d
     799:      	subl	$0x7f, %r14d
     79d:      	movl	$0x7f, %r15d
     7a3:      	cmovbl	%eax, %r15d
     7a7:      	cmovbl	%ecx, %r14d
     7ab:      	cmpl	$0xff, %eax
     7b0:      	movl	$0xff, %ecx
     7b5:      	cmovbl	%eax, %ecx
     7b8:      	movzbl	%cl, %esi
     7bb:      	movl	%esi, 0x1840(%rdx)
     7c1:      	movl	$0x4, %eax
     7c6:      	movq	0x80(%rsp), %rdi
     7ce:      	movq	%rbx, %rdx
     7d1:      	callq	*%rax
     7d3:      	testq	%rax, %rax
     7d6:      	je	0x835 <execve_send+0x575>
     7d8:      	negl	%eax
     7da:      	movw	%ax, 0x18(%rsp)
     7df:      	movw	$0x8, 0x1a(%rsp)
     7e6:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
     7f0:      	movq	%rax, 0x1c(%rsp)
     7f5:      	movq	(%rip), %rdi            # 0x7fc <execve_send+0x53c>
     7fc:      	leaq	0x18(%rsp), %rsi
     801:      	movl	$0x1, %eax
     806:      	callq	*%rax
     808:      	testq	%rax, %rax
     80b:      	je	0x811 <execve_send+0x551>
     80d:      	incl	(%rax)
     80f:      	jmp	0x835 <execve_send+0x575>
     811:      	movl	$0x1, 0x8(%rsp)
     819:      	movq	(%rip), %rdi            # 0x820 <execve_send+0x560>
     820:      	xorl	%ecx, %ecx
     822:      	leaq	0x18(%rsp), %rsi
     827:      	leaq	0x8(%rsp), %rdx
     82c:      	movl	$0x2, %eax
     831:      	xorl	%ecx, %ecx
     833:      	callq	*%rax
     835:      	movq	0x58(%rsp), %rax
     83a:      	leaq	0x17c0(%rax), %rdi
     841:      	addq	%r14, %rbx
     844:      	movq	%rax, %r14
     847:      	movl	$0x4, %eax
     84c:      	movl	%r15d, %esi
     84f:      	movq	%rbx, %rdx
     852:      	callq	*%rax
     854:      	testq	%rax, %rax
     857:      	je	0x8b6 <execve_send+0x5f6>
     859:      	negl	%eax
     85b:      	movw	%ax, 0x18(%rsp)
     860:      	movw	$0x8, 0x1a(%rsp)
     867:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
     871:      	movq	%rax, 0x1c(%rsp)
     876:      	movq	(%rip), %rdi            # 0x87d <execve_send+0x5bd>
     87d:      	leaq	0x18(%rsp), %rsi
     882:      	movl	$0x1, %eax
     887:      	callq	*%rax
     889:      	testq	%rax, %rax
     88c:      	je	0x892 <execve_send+0x5d2>
     88e:      	incl	(%rax)
     890:      	jmp	0x8b6 <execve_send+0x5f6>
     892:      	movl	$0x1, 0x8(%rsp)
     89a:      	movq	(%rip), %rdi            # 0x8a1 <execve_send+0x5e1>
     8a1:      	xorl	%ecx, %ecx
     8a3:      	leaq	0x18(%rsp), %rsi
     8a8:      	leaq	0x8(%rsp), %rdx
     8ad:      	movl	$0x2, %eax
     8b2:      	xorl	%ecx, %ecx
     8b4:      	callq	*%rax
     8b6:      	movl	$0xe, %eax
     8bb:      	callq	*%rax
     8bd:      	shrq	$0x20, %rax
     8c1:      	movl	%eax, 0x18(%rsp)
     8c5:      	movq	(%rip), %rdi            # 0x8cc <execve_send+0x60c>
     8cc:      	leaq	0x18(%rsp), %rsi
     8d1:      	movl	$0x1, %eax
     8d6:      	callq	*%rax
     8d8:      	testq	%rax, %rax
     8db:      	je	0x10fe <execve_send+0xe3e>
     8e1:      	movq	%rax, %r12
     8e4:      	movq	(%rax), %rax
     8e7:      	movq	0x8(%r12), %rcx
     8ec:      	movq	%rcx, 0x138(%r14)
     8f3:      	movq	%rax, 0x130(%r14)
     8fa:      	movl	0x20(%r12), %eax
     8ff:      	movl	0x144(%r14), %ecx
     906:      	movl	%ecx, (%r12)
     90a:      	movq	0x170(%r14), %rcx
     911:      	movq	%rcx, 0x8(%r12)
     916:      	movl	0x14c(%r14), %ecx
     91d:      	movl	%ecx, 0x24(%r12)
     922:      	movq	0xa0(%r14), %rdx
     929:      	movq	0xa8(%r14), %rsi
     930:      	movq	%rdx, 0x10(%r12)
     935:      	movq	%rsi, 0x18(%r12)
     93a:      	testb	$0x1, %al
     93c:      	je	0x946 <execve_send+0x686>
     93e:      	orb	$0x40, 0x15d(%r14)
     946:      	movl	%eax, %edx
     948:      	andl	$-0x2, %edx
     94b:      	movl	%edx, %esi
     94d:      	orl	$0x2000000, %esi        # imm = 0x2000000
     953:      	cmpl	$0x1, %ecx
     956:      	cmovnel	%edx, %esi
     959:      	movl	%esi, 0x20(%r12)
     95e:      	testl	$0x2000000, %esi        # imm = 0x2000000
     964:      	jne	0x9dc <execve_send+0x71c>
     966:      	cmpl	$0x1, %eax
     969:      	jne	0x9e9 <execve_send+0x729>
     96b:      	movq	0x128(%r14), %rax
     972:      	movq	%rax, 0x48(%r12)
     977:      	movq	0x120(%r14), %rax
     97e:      	movq	%rax, 0x40(%r12)
     983:      	movq	0x118(%r14), %rax
     98a:      	movq	%rax, 0x38(%r12)
     98f:      	movq	0x108(%r14), %rax
     996:      	movq	0x110(%r14), %rcx
     99d:      	movq	%rcx, 0x30(%r12)
     9a2:      	movq	%rax, 0x28(%r12)
     9a7:      	movq	0xe0(%r14), %rax
     9ae:      	movq	%rax, 0x50(%r12)
     9b3:      	movq	0xe8(%r14), %rax
     9ba:      	movq	%rax, 0x58(%r12)
     9bf:      	movq	0xf0(%r14), %rax
     9c6:      	movq	%rax, 0x60(%r12)
     9cb:      	movq	(%rip), %rax            # 0x9d2 <execve_send+0x712>
     9d2:      	cmpb	$0x0, (%rax)
     9d5:      	jne	0x9f9 <execve_send+0x739>
     9d7:      	jmp	0xc94 <execve_send+0x9d4>
     9dc:      	orb	$0x2, 0x15f(%r14)
     9e4:      	cmpl	$0x1, %eax
     9e7:      	je	0x96b <execve_send+0x6ab>
     9e9:      	movq	(%rip), %rax            # 0x9f0 <execve_send+0x730>
     9f0:      	cmpb	$0x0, (%rax)
     9f3:      	je	0xc94 <execve_send+0x9d4>
     9f9:      	movl	$0x0, 0x70(%rsp)
     a01:      	movq	(%rip), %rdi            # 0xa08 <execve_send+0x748>
     a08:      	leaq	0x70(%rsp), %rsi
     a0d:      	movl	$0x1, %eax
     a12:      	callq	*%rax
     a14:      	testq	%rax, %rax
     a17:      	je	0xc94 <execve_send+0x9d4>
     a1d:      	testb	$0x40, 0x15d(%r14)
     a25:      	jne	0xa55 <execve_send+0x795>
     a27:      	leaq	0x68(%r12), %rsi
     a2c:      	movl	$0x318, %edx            # imm = 0x318
     a31:      	movq	%rax, %rdi
     a34:      	movq	%rax, %rbx
     a37:      	callq	0xa3c <execve_send+0x77c>
     a3c:      	movq	(%rip), %rdi            # 0xa43 <execve_send+0x783>
     a43:      	xorl	%ecx, %ecx
     a45:      	movl	$0x2, %eax
     a4a:      	movq	%r12, %rsi
     a4d:      	movq	%rbx, %rdx
     a50:      	jmp	0xc90 <execve_send+0x9d0>
     a55:      	movl	$0x23, %eax
     a5a:      	callq	*%rax
     a5c:      	movq	%rax, %rcx
     a5f:      	movq	%rax, 0x18(%rsp)
     a64:      	addq	$0xb00, %rcx            # imm = 0xB00
     a6b:      	leaq	0x18(%rsp), %rdi
     a70:      	movl	$0x8, %edx
     a75:      	movl	$0x71, %eax
     a7a:      	movl	$0xb00, %edx            # imm = 0xB00
     a7f:      	addq	0x18(%rsp), %rdx
     a84:      	movl	$0x8, %esi
     a89:      	callq	*%rax
     a8b:      	movq	0x18(%rsp), %rcx
     a90:      	testq	%rcx, %rcx
     a93:      	je	0xc94 <execve_send+0x9d4>
     a99:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     aa0:      	movq	%rsp, %rdi
     aa3:      	movl	$0x4, %edx
     aa8:      	movl	$0x71, %eax
     aad:      	movl	$0xaf4, %edx            # imm = 0xAF4
     ab2:      	addq	0x18(%rsp), %rdx
     ab7:      	movl	$0x4, %esi
     abc:      	callq	*%rax
     abe:      	movl	(%rsp), %eax
     ac1:      	movl	%eax, 0x8(%rsp)
     ac5:      	movq	(%rip), %rdi            # 0xacc <execve_send+0x80c>
     acc:      	leaq	0x8(%rsp), %rsi
     ad1:      	movl	$0x1, %eax
     ad6:      	callq	*%rax
     ad8:      	testq	%rax, %rax
     adb:      	je	0xaeb <execve_send+0x82b>
     add:      	movq	%rax, %rdx
     ae0:      	cmpq	$0x0, 0x8(%rax)
     ae5:      	jne	0xc7b <execve_send+0x9bb>
     aeb:      	movl	$0xb00, %edx            # imm = 0xB00
     af0:      	movq	0x18(%rsp), %rcx
     af5:      	addq	%rdx, %rcx
     af8:      	leaq	0x18(%rsp), %rdi
     afd:      	movl	$0x8, %esi
     b02:      	movl	$0x71, %eax
     b07:      	addq	0x18(%rsp), %rdx
     b0c:      	movl	$0x8, %esi
     b11:      	callq	*%rax
     b13:      	movq	0x18(%rsp), %rcx
     b18:      	testq	%rcx, %rcx
     b1b:      	je	0xc94 <execve_send+0x9d4>
     b21:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     b28:      	movq	%rsp, %rdi
     b2b:      	movl	$0x4, %edx
     b30:      	movl	$0x71, %eax
     b35:      	movl	$0xaf4, %edx            # imm = 0xAF4
     b3a:      	addq	0x18(%rsp), %rdx
     b3f:      	movl	$0x4, %esi
     b44:      	callq	*%rax
     b46:      	movl	(%rsp), %eax
     b49:      	movl	%eax, 0x8(%rsp)
     b4d:      	movq	(%rip), %rdi            # 0xb54 <execve_send+0x894>
     b54:      	leaq	0x8(%rsp), %rsi
     b59:      	movl	$0x1, %eax
     b5e:      	callq	*%rax
     b60:      	testq	%rax, %rax
     b63:      	je	0xb73 <execve_send+0x8b3>
     b65:      	movq	%rax, %rdx
     b68:      	cmpq	$0x0, 0x8(%rax)
     b6d:      	jne	0xc7b <execve_send+0x9bb>
     b73:      	movl	$0xb00, %edx            # imm = 0xB00
     b78:      	movq	0x18(%rsp), %rcx
     b7d:      	addq	%rdx, %rcx
     b80:      	leaq	0x18(%rsp), %rdi
     b85:      	movl	$0x8, %esi
     b8a:      	movl	$0x71, %eax
     b8f:      	addq	0x18(%rsp), %rdx
     b94:      	movl	$0x8, %esi
     b99:      	callq	*%rax
     b9b:      	movq	0x18(%rsp), %rcx
     ba0:      	testq	%rcx, %rcx
     ba3:      	je	0xc94 <execve_send+0x9d4>
     ba9:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     bb0:      	movq	%rsp, %rdi
     bb3:      	movl	$0x4, %edx
     bb8:      	movl	$0x71, %eax
     bbd:      	movl	$0xaf4, %edx            # imm = 0xAF4
     bc2:      	addq	0x18(%rsp), %rdx
     bc7:      	movl	$0x4, %esi
     bcc:      	callq	*%rax
     bce:      	movl	(%rsp), %eax
     bd1:      	movl	%eax, 0x8(%rsp)
     bd5:      	movq	(%rip), %rdi            # 0xbdc <execve_send+0x91c>
     bdc:      	leaq	0x8(%rsp), %rsi
     be1:      	movl	$0x1, %eax
     be6:      	callq	*%rax
     be8:      	testq	%rax, %rax
     beb:      	je	0xbfb <execve_send+0x93b>
     bed:      	movq	%rax, %rdx
     bf0:      	cmpq	$0x0, 0x8(%rax)
     bf5:      	jne	0xc7b <execve_send+0x9bb>
     bfb:      	movl	$0xb00, %edx            # imm = 0xB00
     c00:      	movq	0x18(%rsp), %rcx
     c05:      	addq	%rdx, %rcx
     c08:      	leaq	0x18(%rsp), %rdi
     c0d:      	movl	$0x8, %esi
     c12:      	movl	$0x71, %eax
     c17:      	addq	0x18(%rsp), %rdx
     c1c:      	movl	$0x8, %esi
     c21:      	callq	*%rax
     c23:      	movq	0x18(%rsp), %rcx
     c28:      	testq	%rcx, %rcx
     c2b:      	je	0xc94 <execve_send+0x9d4>
     c2d:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     c34:      	movq	%rsp, %rdi
     c37:      	movl	$0x4, %edx
     c3c:      	movl	$0x71, %eax
     c41:      	movl	$0xaf4, %edx            # imm = 0xAF4
     c46:      	addq	0x18(%rsp), %rdx
     c4b:      	movl	$0x4, %esi
     c50:      	callq	*%rax
     c52:      	movl	(%rsp), %eax
     c55:      	movl	%eax, 0x8(%rsp)
     c59:      	movq	(%rip), %rdi            # 0xc60 <execve_send+0x9a0>
     c60:      	leaq	0x8(%rsp), %rsi
     c65:      	movl	$0x1, %eax
     c6a:      	callq	*%rax
     c6c:      	testq	%rax, %rax
     c6f:      	je	0xc94 <execve_send+0x9d4>
     c71:      	movq	%rax, %rdx
     c74:      	cmpq	$0x0, 0x8(%rax)
     c79:      	je	0xc94 <execve_send+0x9d4>
     c7b:      	addq	$0x68, %rdx
     c7f:      	movq	(%rip), %rdi            # 0xc86 <execve_send+0x9c6>
     c86:      	xorl	%ecx, %ecx
     c88:      	movl	$0x2, %eax
     c8d:      	movq	%r12, %rsi
     c90:      	xorl	%ecx, %ecx
     c92:      	callq	*%rax
     c94:      	leaq	0x140(%r14), %r13
     c9b:      	leaq	0x68(%r12), %rbx
     ca0:      	movl	$0x308, %edx            # imm = 0x308
     ca5:      	movq	%rbx, %rdi
     ca8:      	xorl	%esi, %esi
     caa:      	callq	0xcaf <execve_send+0x9ef>
     caf:      	movl	0x1840(%r14), %eax
     cb6:      	leal	-0x101(%rax), %ecx
     cbc:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
     cc2:      	ja	0xccf <execve_send+0xa0f>
     cc4:      	movl	$0xffffffff, (%rbx)     # imm = 0xFFFFFFFF
     cca:      	jmp	0xe15 <execve_send+0xb55>
     ccf:      	movzbl	%al, %ebx
     cd2:      	leaq	0x70(%r12), %rdi
     cd7:      	movl	$0x4, %eax
     cdc:      	movq	0x80(%rsp), %rdx
     ce4:      	movl	%ebx, %esi
     ce6:      	callq	*%rax
     ce8:      	movq	%rax, %r15
     ceb:      	testq	%rax, %rax
     cee:      	je	0xd83 <execve_send+0xac3>
     cf4:      	movl	%r15d, %eax
     cf7:      	negl	%eax
     cf9:      	movw	%ax, 0x18(%rsp)
     cfe:      	movw	$0xf, 0x1a(%rsp)
     d05:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
     d0f:      	movq	%rax, 0x1c(%rsp)
     d14:      	movq	(%rip), %rdi            # 0xd1b <execve_send+0xa5b>
     d1b:      	leaq	0x18(%rsp), %rsi
     d20:      	movl	$0x1, %eax
     d25:      	callq	*%rax
     d27:      	testq	%rax, %rax
     d2a:      	je	0xd5f <execve_send+0xa9f>
     d2c:      	incl	(%rax)
     d2e:      	jmp	0xd83 <execve_send+0xac3>
     d30:      	movq	%r13, 0x60(%rsp)
     d35:      	movq	%r15, %r12
     d38:      	addq	$0xff6, %r12            # imm = 0xFF6
     d3f:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     d49:      	movq	%rax, 0xff6(%r15)
     d50:      	movw	$0x2964, 0xffe(%r15)    # imm = 0x2964
     d5a:      	jmp	0x425 <execve_send+0x165>
     d5f:      	movl	$0x1, 0x8(%rsp)
     d67:      	movq	(%rip), %rdi            # 0xd6e <execve_send+0xaae>
     d6e:      	xorl	%ecx, %ecx
     d70:      	leaq	0x18(%rsp), %rsi
     d75:      	leaq	0x8(%rsp), %rdx
     d7a:      	movl	$0x2, %eax
     d7f:      	xorl	%ecx, %ecx
     d81:      	callq	*%rax
     d83:      	testl	%r15d, %r15d
     d86:      	cmovel	%ebx, %r15d
     d8a:      	movl	%r15d, 0x68(%r12)
     d8f:      	cmpl	$0x7f, %ebx
     d92:      	movl	$0x7f, %esi
     d97:      	cmovbl	%ebx, %esi
     d9a:      	leaq	0x170(%r12), %rdi
     da2:      	movq	%r14, %rdx
     da5:      	addq	$0x17c0, %rdx           # imm = 0x17C0
     dac:      	movl	$0x4, %eax
     db1:      	callq	*%rax
     db3:      	testq	%rax, %rax
     db6:      	je	0xe15 <execve_send+0xb55>
     db8:      	negl	%eax
     dba:      	movw	%ax, 0x18(%rsp)
     dbf:      	movw	$0xf, 0x1a(%rsp)
     dc6:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
     dd0:      	movq	%rax, 0x1c(%rsp)
     dd5:      	movq	(%rip), %rdi            # 0xddc <execve_send+0xb1c>
     ddc:      	leaq	0x18(%rsp), %rsi
     de1:      	movl	$0x1, %eax
     de6:      	callq	*%rax
     de8:      	testq	%rax, %rax
     deb:      	je	0xdf1 <execve_send+0xb31>
     ded:      	incl	(%rax)
     def:      	jmp	0xe15 <execve_send+0xb55>
     df1:      	movl	$0x1, 0x8(%rsp)
     df9:      	movq	(%rip), %rdi            # 0xe00 <execve_send+0xb40>
     e00:      	xorl	%ecx, %ecx
     e02:      	leaq	0x18(%rsp), %rsi
     e07:      	leaq	0x8(%rsp), %rdx
     e0c:      	movl	$0x2, %eax
     e11:      	xorl	%ecx, %ecx
     e13:      	callq	*%rax
     e15:      	movl	0x1848(%r14), %eax
     e1c:      	movl	0x184c(%r14), %ecx
     e23:      	cmpl	$0xfe, %eax
     e28:      	movl	$0xfe, %ebx
     e2d:      	cmovbl	%eax, %ebx
     e30:      	leaq	0x270(%r12), %rdi
     e38:      	addq	%rcx, %r13
     e3b:      	movl	$0x4, %eax
     e40:      	movl	%ebx, %esi
     e42:      	movq	%r13, %rdx
     e45:      	callq	*%rax
     e47:      	testq	%rax, %rax
     e4a:      	je	0xea9 <execve_send+0xbe9>
     e4c:      	negl	%eax
     e4e:      	movw	%ax, 0x18(%rsp)
     e53:      	movw	$0x9, 0x1a(%rsp)
     e5a:      	movabsq	$0x4000001af, %rax      # imm = 0x4000001AF
     e64:      	movq	%rax, 0x1c(%rsp)
     e69:      	movq	(%rip), %rdi            # 0xe70 <execve_send+0xbb0>
     e70:      	leaq	0x18(%rsp), %rsi
     e75:      	movl	$0x1, %eax
     e7a:      	callq	*%rax
     e7c:      	testq	%rax, %rax
     e7f:      	je	0xe85 <execve_send+0xbc5>
     e81:      	incl	(%rax)
     e83:      	jmp	0xea9 <execve_send+0xbe9>
     e85:      	movl	$0x1, 0x8(%rsp)
     e8d:      	movq	(%rip), %rdi            # 0xe94 <execve_send+0xbd4>
     e94:      	xorl	%ecx, %ecx
     e96:      	leaq	0x18(%rsp), %rsi
     e9b:      	leaq	0x8(%rsp), %rdx
     ea0:      	movl	$0x2, %eax
     ea5:      	xorl	%ecx, %ecx
     ea7:      	callq	*%rax
     ea9:      	movw	$0x0, 0x270(%r12,%rbx)
     eb4:      	movl	$0x23, %eax
     eb9:      	callq	*%rax
     ebb:      	movq	%rax, %rcx
     ebe:      	movq	%rax, 0x18(%rsp)
     ec3:      	addq	$0xb00, %rcx            # imm = 0xB00
     eca:      	leaq	0x18(%rsp), %rdi
     ecf:      	movl	$0x8, %edx
     ed4:      	movl	$0x71, %eax
     ed9:      	movl	$0xb00, %edx            # imm = 0xB00
     ede:      	addq	0x18(%rsp), %rdx
     ee3:      	movl	$0x8, %esi
     ee8:      	callq	*%rax
     eea:      	movq	0x18(%rsp), %rcx
     eef:      	testq	%rcx, %rcx
     ef2:      	je	0x10d9 <execve_send+0xe19>
     ef8:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     eff:      	movq	%rsp, %rdi
     f02:      	movl	$0x4, %edx
     f07:      	movl	$0x71, %eax
     f0c:      	movl	$0xaf4, %edx            # imm = 0xAF4
     f11:      	addq	0x18(%rsp), %rdx
     f16:      	movl	$0x4, %esi
     f1b:      	callq	*%rax
     f1d:      	movl	(%rsp), %eax
     f20:      	movl	%eax, 0x8(%rsp)
     f24:      	movq	(%rip), %rdi            # 0xf2b <execve_send+0xc6b>
     f2b:      	leaq	0x8(%rsp), %rsi
     f30:      	movl	$0x1, %eax
     f35:      	callq	*%rax
     f37:      	testq	%rax, %rax
     f3a:      	je	0xf47 <execve_send+0xc87>
     f3c:      	cmpq	$0x0, 0x8(%rax)
     f41:      	jne	0x10ca <execve_send+0xe0a>
     f47:      	movl	$0xb00, %edx            # imm = 0xB00
     f4c:      	movq	0x18(%rsp), %rcx
     f51:      	addq	%rdx, %rcx
     f54:      	leaq	0x18(%rsp), %rdi
     f59:      	movl	$0x8, %esi
     f5e:      	movl	$0x71, %eax
     f63:      	addq	0x18(%rsp), %rdx
     f68:      	movl	$0x8, %esi
     f6d:      	callq	*%rax
     f6f:      	movq	0x18(%rsp), %rcx
     f74:      	testq	%rcx, %rcx
     f77:      	je	0x10d9 <execve_send+0xe19>
     f7d:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     f84:      	movq	%rsp, %rdi
     f87:      	movl	$0x4, %edx
     f8c:      	movl	$0x71, %eax
     f91:      	movl	$0xaf4, %edx            # imm = 0xAF4
     f96:      	addq	0x18(%rsp), %rdx
     f9b:      	movl	$0x4, %esi
     fa0:      	callq	*%rax
     fa2:      	movl	(%rsp), %eax
     fa5:      	movl	%eax, 0x8(%rsp)
     fa9:      	movq	(%rip), %rdi            # 0xfb0 <execve_send+0xcf0>
     fb0:      	leaq	0x8(%rsp), %rsi
     fb5:      	movl	$0x1, %eax
     fba:      	callq	*%rax
     fbc:      	testq	%rax, %rax
     fbf:      	je	0xfcc <execve_send+0xd0c>
     fc1:      	cmpq	$0x0, 0x8(%rax)
     fc6:      	jne	0x10ca <execve_send+0xe0a>
     fcc:      	movl	$0xb00, %edx            # imm = 0xB00
     fd1:      	movq	0x18(%rsp), %rcx
     fd6:      	addq	%rdx, %rcx
     fd9:      	leaq	0x18(%rsp), %rdi
     fde:      	movl	$0x8, %esi
     fe3:      	movl	$0x71, %eax
     fe8:      	addq	0x18(%rsp), %rdx
     fed:      	movl	$0x8, %esi
     ff2:      	callq	*%rax
     ff4:      	movq	0x18(%rsp), %rcx
     ff9:      	testq	%rcx, %rcx
     ffc:      	je	0x10d9 <execve_send+0xe19>
    1002:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1009:      	movq	%rsp, %rdi
    100c:      	movl	$0x4, %edx
    1011:      	movl	$0x71, %eax
    1016:      	movl	$0xaf4, %edx            # imm = 0xAF4
    101b:      	addq	0x18(%rsp), %rdx
    1020:      	movl	$0x4, %esi
    1025:      	callq	*%rax
    1027:      	movl	(%rsp), %eax
    102a:      	movl	%eax, 0x8(%rsp)
    102e:      	movq	(%rip), %rdi            # 0x1035 <execve_send+0xd75>
    1035:      	leaq	0x8(%rsp), %rsi
    103a:      	movl	$0x1, %eax
    103f:      	callq	*%rax
    1041:      	testq	%rax, %rax
    1044:      	je	0x104d <execve_send+0xd8d>
    1046:      	cmpq	$0x0, 0x8(%rax)
    104b:      	jne	0x10ca <execve_send+0xe0a>
    104d:      	movl	$0xb00, %edx            # imm = 0xB00
    1052:      	movq	0x18(%rsp), %rcx
    1057:      	addq	%rdx, %rcx
    105a:      	leaq	0x18(%rsp), %rdi
    105f:      	movl	$0x8, %esi
    1064:      	movl	$0x71, %eax
    1069:      	addq	0x18(%rsp), %rdx
    106e:      	movl	$0x8, %esi
    1073:      	callq	*%rax
    1075:      	movq	0x18(%rsp), %rcx
    107a:      	testq	%rcx, %rcx
    107d:      	je	0x10d9 <execve_send+0xe19>
    107f:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1086:      	movq	%rsp, %rdi
    1089:      	movl	$0x4, %edx
    108e:      	movl	$0x71, %eax
    1093:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1098:      	addq	0x18(%rsp), %rdx
    109d:      	movl	$0x4, %esi
    10a2:      	callq	*%rax
    10a4:      	movl	(%rsp), %eax
    10a7:      	movl	%eax, 0x8(%rsp)
    10ab:      	movq	(%rip), %rdi            # 0x10b2 <execve_send+0xdf2>
    10b2:      	leaq	0x8(%rsp), %rsi
    10b7:      	movl	$0x1, %eax
    10bc:      	callq	*%rax
    10be:      	testq	%rax, %rax
    10c1:      	je	0x10d9 <execve_send+0xe19>
    10c3:      	cmpq	$0x0, 0x8(%rax)
    10c8:      	je	0x10d9 <execve_send+0xe19>
    10ca:      	movq	0x370(%rax), %rax
    10d1:      	orq	%rax, 0x370(%r12)
    10d9:      	movq	%r12, %rsi
    10dc:      	addq	$0x70, %rsi
    10e0:      	movq	(%rip), %rdi            # 0x10e7 <execve_send+0xe27>
    10e7:      	movl	$0x1, %eax
    10ec:      	callq	*%rax
    10ee:      	testq	%rax, %rax
    10f1:      	je	0x10fe <execve_send+0xe3e>
    10f3:      	movq	(%rax), %rax
    10f6:      	orq	%rax, 0x370(%r12)
    10fe:      	movb	$0x0, 0x1(%r14)
    1103:      	movl	0x140(%r14), %eax
    110a:      	cmpl	$0x1710, %eax           # imm = 0x1710
    110f:      	movl	$0x1710, %r8d           # imm = 0x1710
    1115:      	cmovbl	%eax, %r8d
    1119:      	addl	$0x140, %r8d            # imm = 0x140
    1120:      	movq	(%rip), %rsi            # 0x1127 <execve_send+0xe67>
    1127:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    112c:      	movl	$0x19, %eax
    1131:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    1136:      	movq	%rbp, %rdi
    1139:      	movq	%r14, %rcx
    113c:      	callq	*%rax
    113e:      	testq	%rax, %rax
    1141:      	jns	0x11ce <execve_send+0xf0e>
    1147:      	movq	%rax, %rbx
    114a:      	movl	$0x0, 0x18(%rsp)
    1152:      	movq	(%rip), %rdi            # 0x1159 <execve_send+0xe99>
    1159:      	leaq	0x18(%rsp), %rsi
    115e:      	movl	$0x1, %eax
    1163:      	callq	*%rax
    1165:      	testq	%rax, %rax
    1168:      	je	0x11ce <execve_send+0xf0e>
    116a:      	cmpq	$-0xc, %rbx
    116e:      	jg	0x118a <execve_send+0xeca>
    1170:      	cmpq	$-0x1c, %rbx
    1174:      	je	0x11a4 <execve_send+0xee4>
    1176:      	cmpq	$-0x16, %rbx
    117a:      	je	0x11bc <execve_send+0xefc>
    117c:      	cmpq	$-0x10, %rbx
    1180:      	jne	0x11b4 <execve_send+0xef4>
    1182:      	addq	$0x130, %rax            # imm = 0x130
    1188:      	jmp	0x11ca <execve_send+0xf0a>
    118a:      	cmpq	$-0xb, %rbx
    118e:      	je	0x11ac <execve_send+0xeec>
    1190:      	cmpq	$-0x7, %rbx
    1194:      	je	0x11c4 <execve_send+0xf04>
    1196:      	cmpq	$-0x2, %rbx
    119a:      	jne	0x11b4 <execve_send+0xef4>
    119c:      	addq	$0x120, %rax            # imm = 0x120
    11a2:      	jmp	0x11ca <execve_send+0xf0a>
    11a4:      	addq	$0x140, %rax            # imm = 0x140
    11aa:      	jmp	0x11ca <execve_send+0xf0a>
    11ac:      	addq	$0x148, %rax            # imm = 0x148
    11b2:      	jmp	0x11ca <execve_send+0xf0a>
    11b4:      	addq	$0x118, %rax            # imm = 0x118
    11ba:      	jmp	0x11ca <execve_send+0xf0a>
    11bc:      	addq	$0x138, %rax            # imm = 0x138
    11c2:      	jmp	0x11ca <execve_send+0xf0a>
    11c4:      	addq	$0x128, %rax            # imm = 0x128
    11ca:      	lock
    11cb:      	incq	(%rax)
    11ce:      	xorl	%eax, %eax
    11d0:      	addq	$0xa8, %rsp
    11d7:      	popq	%rbx
    11d8:      	popq	%r12
    11da:      	popq	%r13
    11dc:      	popq	%r14
    11de:      	popq	%r15
    11e0:      	popq	%rbp
    11e1:      	retq

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %r15
      14:      	movl	$0x23, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, 0xa0(%rsp)
      23:      	movzwl	0x8(%r15), %r12d
      28:      	movl	$0x0, 0xb0(%rsp)
      33:      	movq	(%rip), %rdi            # 0x3a <event_execve+0x3a>
      3a:      	leaq	0xb0(%rsp), %rsi
      42:      	movl	$0x1, %eax
      47:      	callq	*%rax
      49:      	testq	%rax, %rax
      4c:      	je	0x2522 <event_execve+0x2522>
      52:      	movq	%rax, %r14
      55:      	movl	$0xe, %eax
      5a:      	callq	*%rax
      5c:      	movq	%rax, %r13
      5f:      	movl	$0x23, %eax
      64:      	callq	*%rax
      66:      	movq	%rax, %rcx
      69:      	movq	%rax, 0x28(%rsp)
      6e:      	addq	$0xb00, %rcx            # imm = 0xB00
      75:      	leaq	0x28(%rsp), %rdi
      7a:      	movl	$0x8, %edx
      7f:      	movl	$0x71, %eax
      84:      	movl	$0xb00, %edx            # imm = 0xB00
      89:      	addq	0x28(%rsp), %rdx
      8e:      	movl	$0x8, %esi
      93:      	callq	*%rax
      95:      	movq	0x28(%rsp), %rcx
      9a:      	testq	%rcx, %rcx
      9d:      	je	0x28e <event_execve+0x28e>
      a3:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      aa:      	leaq	0x18(%rsp), %rdi
      af:      	movl	$0x4, %edx
      b4:      	movl	$0x71, %eax
      b9:      	movl	$0xaf4, %edx            # imm = 0xAF4
      be:      	addq	0x28(%rsp), %rdx
      c3:      	movl	$0x4, %esi
      c8:      	callq	*%rax
      ca:      	movl	0x18(%rsp), %eax
      ce:      	movl	%eax, (%rsp)
      d1:      	movq	(%rip), %rdi            # 0xd8 <event_execve+0xd8>
      d8:      	movq	%rsp, %rsi
      db:      	movl	$0x1, %eax
      e0:      	callq	*%rax
      e2:      	testq	%rax, %rax
      e5:      	je	0xf2 <event_execve+0xf2>
      e7:      	cmpq	$0x0, 0x8(%rax)
      ec:      	jne	0x275 <event_execve+0x275>
      f2:      	movl	$0xb00, %edx            # imm = 0xB00
      f7:      	movq	0x28(%rsp), %rcx
      fc:      	addq	%rdx, %rcx
      ff:      	leaq	0x28(%rsp), %rdi
     104:      	movl	$0x8, %esi
     109:      	movl	$0x71, %eax
     10e:      	addq	0x28(%rsp), %rdx
     113:      	movl	$0x8, %esi
     118:      	callq	*%rax
     11a:      	movq	0x28(%rsp), %rcx
     11f:      	testq	%rcx, %rcx
     122:      	je	0x28e <event_execve+0x28e>
     128:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     12f:      	leaq	0x18(%rsp), %rdi
     134:      	movl	$0x4, %edx
     139:      	movl	$0x71, %eax
     13e:      	movl	$0xaf4, %edx            # imm = 0xAF4
     143:      	addq	0x28(%rsp), %rdx
     148:      	movl	$0x4, %esi
     14d:      	callq	*%rax
     14f:      	movl	0x18(%rsp), %eax
     153:      	movl	%eax, (%rsp)
     156:      	movq	(%rip), %rdi            # 0x15d <event_execve+0x15d>
     15d:      	movq	%rsp, %rsi
     160:      	movl	$0x1, %eax
     165:      	callq	*%rax
     167:      	testq	%rax, %rax
     16a:      	je	0x177 <event_execve+0x177>
     16c:      	cmpq	$0x0, 0x8(%rax)
     171:      	jne	0x275 <event_execve+0x275>
     177:      	movl	$0xb00, %edx            # imm = 0xB00
     17c:      	movq	0x28(%rsp), %rcx
     181:      	addq	%rdx, %rcx
     184:      	leaq	0x28(%rsp), %rdi
     189:      	movl	$0x8, %esi
     18e:      	movl	$0x71, %eax
     193:      	addq	0x28(%rsp), %rdx
     198:      	movl	$0x8, %esi
     19d:      	callq	*%rax
     19f:      	movq	0x28(%rsp), %rcx
     1a4:      	testq	%rcx, %rcx
     1a7:      	je	0x28e <event_execve+0x28e>
     1ad:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     1b4:      	leaq	0x18(%rsp), %rdi
     1b9:      	movl	$0x4, %edx
     1be:      	movl	$0x71, %eax
     1c3:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1c8:      	addq	0x28(%rsp), %rdx
     1cd:      	movl	$0x4, %esi
     1d2:      	callq	*%rax
     1d4:      	movl	0x18(%rsp), %eax
     1d8:      	movl	%eax, (%rsp)
     1db:      	movq	(%rip), %rdi            # 0x1e2 <event_execve+0x1e2>
     1e2:      	movq	%rsp, %rsi
     1e5:      	movl	$0x1, %eax
     1ea:      	callq	*%rax
     1ec:      	testq	%rax, %rax
     1ef:      	je	0x1f8 <event_execve+0x1f8>
     1f1:      	cmpq	$0x0, 0x8(%rax)
     1f6:      	jne	0x275 <event_execve+0x275>
     1f8:      	movl	$0xb00, %edx            # imm = 0xB00
     1fd:      	movq	0x28(%rsp), %rcx
     202:      	addq	%rdx, %rcx
     205:      	leaq	0x28(%rsp), %rdi
     20a:      	movl	$0x8, %esi
     20f:      	movl	$0x71, %eax
     214:      	addq	0x28(%rsp), %rdx
     219:      	movl	$0x8, %esi
     21e:      	callq	*%rax
     220:      	movq	0x28(%rsp), %rcx
     225:      	testq	%rcx, %rcx
     228:      	je	0x28e <event_execve+0x28e>
     22a:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     231:      	leaq	0x18(%rsp), %rdi
     236:      	movl	$0x4, %edx
     23b:      	movl	$0x71, %eax
     240:      	movl	$0xaf4, %edx            # imm = 0xAF4
     245:      	addq	0x28(%rsp), %rdx
     24a:      	movl	$0x4, %esi
     24f:      	callq	*%rax
     251:      	movl	0x18(%rsp), %eax
     255:      	movl	%eax, (%rsp)
     258:      	movq	(%rip), %rdi            # 0x25f <event_execve+0x25f>
     25f:      	movq	%rsp, %rsi
     262:      	movl	$0x1, %eax
     267:      	callq	*%rax
     269:      	testq	%rax, %rax
     26c:      	je	0x28e <event_execve+0x28e>
     26e:      	cmpq	$0x0, 0x8(%rax)
     273:      	je	0x28e <event_execve+0x28e>
     275:      	movq	(%rax), %rcx
     278:      	movq	0x8(%rax), %rax
     27c:      	movq	%rax, 0xa8(%r14)
     283:      	movq	%rcx, 0xa0(%r14)
     28a:      	xorl	%eax, %eax
     28c:      	jmp	0x2f9 <event_execve+0x2f9>
     28e:      	movq	0xa0(%rsp), %rax
     296:      	leaq	0xb00(%rax), %rdx
     29d:      	leaq	0x28(%rsp), %rdi
     2a2:      	movl	$0x8, %ecx
     2a7:      	movl	$0x71, %eax
     2ac:      	movl	$0x8, %esi
     2b1:      	callq	*%rax
     2b3:      	movq	0x28(%rsp), %rdx
     2b8:      	testq	%rdx, %rdx
     2bb:      	je	0x2e0 <event_execve+0x2e0>
     2bd:      	addq	$0xaf4, %rdx            # imm = 0xAF4
     2c4:      	leaq	0x28(%rsp), %rdi
     2c9:      	movl	$0x4, %ecx
     2ce:      	movl	$0x71, %eax
     2d3:      	movl	$0x4, %esi
     2d8:      	callq	*%rax
     2da:      	movl	0x28(%rsp), %eax
     2de:      	jmp	0x2e2 <event_execve+0x2e2>
     2e0:      	xorl	%eax, %eax
     2e2:      	movl	%eax, 0xa0(%r14)
     2e9:      	movq	$0x0, 0xa8(%r14)
     2f4:      	movl	$0x40, %eax
     2f9:      	movq	%rax, 0xb0(%r14)
     300:      	movl	$0x1, 0x15c(%r14)
     30b:      	movq	%r13, %rax
     30e:      	shrq	$0x20, %rax
     312:      	movq	$0x0, 0x178(%r14)
     31d:      	movl	%eax, 0x144(%r14)
     324:      	movl	%r13d, 0x148(%r14)
     32b:      	movl	$0x23, %eax
     330:      	callq	*%rax
     332:      	leaq	0x60(%rax), %rdx
     336:      	movq	%rsp, %rdi
     339:      	movl	$0x8, %ecx
     33e:      	movl	$0x71, %eax
     343:      	movl	$0x8, %esi
     348:      	callq	*%rax
     34a:      	movq	(%rsp), %rcx
     34e:      	xorl	%ebx, %ebx
     350:      	testq	%rcx, %rcx
     353:      	je	0x3bf <event_execve+0x3bf>
     355:      	addq	$0x4, %rcx
     359:      	leaq	0x18(%rsp), %rdi
     35e:      	movl	$0x4, %edx
     363:      	movl	$0x71, %eax
     368:      	movq	(%rsp), %rdx
     36c:      	addq	$0x4, %rdx
     370:      	movl	$0x4, %esi
     375:      	callq	*%rax
     377:      	movl	0x18(%rsp), %eax
     37b:      	testl	%eax, %eax
     37d:      	je	0x3bf <event_execve+0x3bf>
     37f:      	movq	(%rsp), %rcx
     383:      	shll	$0x4, %eax
     386:      	addq	%rax, %rcx
     389:      	addq	$0x80, %rcx
     390:      	leaq	0x28(%rsp), %rdi
     395:      	movl	$0x10, %edx
     39a:      	movl	$0x71, %eax
     39f:      	movq	(%rsp), %rcx
     3a3:      	movl	0x18(%rsp), %edx
     3a7:      	shll	$0x4, %edx
     3aa:      	addq	%rcx, %rdx
     3ad:      	addq	$0x80, %rdx
     3b4:      	movl	$0x10, %esi
     3b9:      	callq	*%rax
     3bb:      	movl	0x28(%rsp), %ebx
     3bf:      	movl	%ebx, 0x14c(%r14)
     3c6:      	movl	$0x7d, %eax
     3cb:      	callq	*%rax
     3cd:      	movq	%rax, 0x170(%r14)
     3d4:      	movl	$0x40, 0x140(%r14)
     3df:      	movl	$0x23, %eax
     3e4:      	callq	*%rax
     3e6:      	movq	$0x0, 0x28(%rsp)
     3ef:      	testq	%rax, %rax
     3f2:      	je	0x418 <event_execve+0x418>
     3f4:      	movq	%rax, %rdx
     3f7:      	addq	$0x70, %rdx
     3fb:      	leaq	0x28(%rsp), %rdi
     400:      	movl	$0x8, %ecx
     405:      	movl	$0x4, %eax
     40a:      	movl	$0x8, %esi
     40f:      	callq	*%rax
     411:      	movq	0x28(%rsp), %rax
     416:      	jmp	0x41a <event_execve+0x41a>
     418:      	xorl	%eax, %eax
     41a:      	movl	%eax, 0x158(%r14)
     421:      	movq	%r13, 0x28(%rsp)
     426:      	movq	(%rip), %rdi            # 0x42d <event_execve+0x42d>
     42d:      	leaq	0x28(%rsp), %rsi
     432:      	movl	$0x1, %eax
     437:      	addq	%r15, %r12
     43a:      	callq	*%rax
     43c:      	testq	%rax, %rax
     43f:      	je	0x49d <event_execve+0x49d>
     441:      	movl	(%rax), %ecx
     443:      	movl	%ecx, 0x150(%r14)
     44a:      	movq	0x8(%rax), %rcx
     44e:      	movq	%rcx, 0x168(%r14)
     455:      	movl	0x4(%rax), %eax
     458:      	movl	%eax, 0x160(%r14)
     45f:      	movq	%r13, 0x28(%rsp)
     464:      	movq	(%rip), %rdi            # 0x46b <event_execve+0x46b>
     46b:      	leaq	0x28(%rsp), %rsi
     470:      	movl	$0x3, %eax
     475:      	callq	*%rax
     477:      	testl	%eax, %eax
     479:      	je	0x4c0 <event_execve+0x4c0>
     47b:      	movl	$0x2, (%rsp)
     482:      	movq	(%rip), %rdi            # 0x489 <event_execve+0x489>
     489:      	movq	%rsp, %rsi
     48c:      	movl	$0x1, %eax
     491:      	callq	*%rax
     493:      	testq	%rax, %rax
     496:      	je	0x4e0 <event_execve+0x4e0>
     498:      	incq	(%rax)
     49b:      	jmp	0x4e0 <event_execve+0x4e0>
     49d:      	movl	$0x0, 0x150(%r14)
     4a8:      	movq	$0x0, 0x168(%r14)
     4b3:      	movl	$0x0, 0x160(%r14)
     4be:      	jmp	0x4e0 <event_execve+0x4e0>
     4c0:      	movl	$0x0, (%rsp)
     4c7:      	movq	(%rip), %rdi            # 0x4ce <event_execve+0x4ce>
     4ce:      	movq	%rsp, %rsi
     4d1:      	movl	$0x1, %eax
     4d6:      	callq	*%rax
     4d8:      	testq	%rax, %rax
     4db:      	je	0x4e0 <event_execve+0x4e0>
     4dd:      	decq	(%rax)
     4e0:      	leaq	0x180(%r14), %rdi
     4e7:      	movl	$0xff, %ecx
     4ec:      	movl	$0x2d, %eax
     4f1:      	movl	$0xff, %esi
     4f6:      	movq	%r12, %rdx
     4f9:      	callq	*%rax
     4fb:      	testl	%eax, %eax
     4fd:      	movq	%r15, 0x10(%rsp)
     502:      	js	0x648 <event_execve+0x648>
     508:      	je	0x654 <event_execve+0x654>
     50e:      	cmpl	$0xff, %eax
     513:      	jne	0x65b <event_execve+0x65b>
     519:      	movl	$0x0, (%rsp)
     520:      	movq	(%rip), %rdi            # 0x527 <event_execve+0x527>
     527:      	movq	%rsp, %rsi
     52a:      	movl	$0x1, %eax
     52f:      	callq	*%rax
     531:      	testq	%rax, %rax
     534:      	je	0x648 <event_execve+0x648>
     53a:      	movq	%rax, %rbp
     53d:      	movq	%rax, %r13
     540:      	movl	$0x18, (%rbp)
     547:      	movl	$0xe, %eax
     54c:      	callq	*%rax
     54e:      	leaq	0x10(%rbp), %rbx
     552:      	movq	%rax, 0x10(%rbp)
     556:      	cmpq	$-0x16, %rax
     55a:      	jne	0x57e <event_execve+0x57e>
     55c:      	leaq	0x20(%r15), %rdx
     560:      	leaq	0x28(%rsp), %rdi
     565:      	movl	$0x8, %ecx
     56a:      	movl	$0x4, %eax
     56f:      	movl	$0x8, %esi
     574:      	callq	*%rax
     576:      	movq	0x28(%rsp), %rax
     57b:      	movq	%rax, (%rbx)
     57e:      	movl	$0x7d, %eax
     583:      	callq	*%rax
     585:      	movq	%rax, 0x18(%r13)
     589:      	movq	(%rbx), %rax
     58c:      	movq	0x8(%rbx), %rcx
     590:      	movq	%rax, 0x190(%r14)
     597:      	movq	%rcx, 0x198(%r14)
     59e:      	addq	$0x20, %rbp
     5a2:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     5a7:      	movl	$0x2d, %eax
     5ac:      	movq	%rbp, %rdi
     5af:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     5b4:      	movq	%r12, %rdx
     5b7:      	callq	*%rax
     5b9:      	testq	%rax, %rax
     5bc:      	js	0x7c3 <event_execve+0x7c3>
     5c2:      	je	0x666 <event_execve+0x666>
     5c8:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     5cd:      	movq	%r15, %rdi
     5d0:      	movq	%rax, %r15
     5d3:      	leal	0x1f(%rax), %r8d
     5d7:      	andl	$0x7fff, %r8d           # imm = 0x7FFF
     5de:      	movl	%r8d, 0x4(%r13)
     5e2:      	movq	(%rip), %rsi            # 0x5e9 <event_execve+0x5e9>
     5e9:      	movl	$0x19, %eax
     5ee:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     5f3:      	movq	%r13, %rcx
     5f6:      	callq	*%rax
     5f8:      	testq	%rax, %rax
     5fb:      	jns	0x6b3 <event_execve+0x6b3>
     601:      	movq	%rax, %rbx
     604:      	movl	$0x0, 0x28(%rsp)
     60c:      	movq	(%rip), %rdi            # 0x613 <event_execve+0x613>
     613:      	leaq	0x28(%rsp), %rsi
     618:      	movl	$0x1, %eax
     61d:      	callq	*%rax
     61f:      	testq	%rax, %rax
     622:      	je	0x6b3 <event_execve+0x6b3>
     628:      	cmpq	$-0xc, %rbx
     62c:      	jg	0x66f <event_execve+0x66f>
     62e:      	cmpq	$-0x1c, %rbx
     632:      	je	0x689 <event_execve+0x689>
     634:      	cmpq	$-0x16, %rbx
     638:      	je	0x6a1 <event_execve+0x6a1>
     63a:      	cmpq	$-0x10, %rbx
     63e:      	jne	0x699 <event_execve+0x699>
     640:      	addq	$0x558, %rax            # imm = 0x558
     646:      	jmp	0x6af <event_execve+0x6af>
     648:      	xorl	%ecx, %ecx
     64a:      	movl	$0x100, %eax            # imm = 0x100
     64f:      	jmp	0x7f4 <event_execve+0x7f4>
     654:      	movl	%eax, %ecx
     656:      	jmp	0x7f4 <event_execve+0x7f4>
     65b:      	movl	%eax, %ecx
     65d:      	decl	%ecx
     65f:      	xorl	%eax, %eax
     661:      	jmp	0x7f4 <event_execve+0x7f4>
     666:      	xorl	%ecx, %ecx
     668:      	xorl	%edx, %edx
     66a:      	jmp	0x7d1 <event_execve+0x7d1>
     66f:      	cmpq	$-0xb, %rbx
     673:      	je	0x691 <event_execve+0x691>
     675:      	cmpq	$-0x7, %rbx
     679:      	je	0x6a9 <event_execve+0x6a9>
     67b:      	cmpq	$-0x2, %rbx
     67f:      	jne	0x699 <event_execve+0x699>
     681:      	addq	$0x548, %rax            # imm = 0x548
     687:      	jmp	0x6af <event_execve+0x6af>
     689:      	addq	$0x568, %rax            # imm = 0x568
     68f:      	jmp	0x6af <event_execve+0x6af>
     691:      	addq	$0x570, %rax            # imm = 0x570
     697:      	jmp	0x6af <event_execve+0x6af>
     699:      	addq	$0x540, %rax            # imm = 0x540
     69f:      	jmp	0x6af <event_execve+0x6af>
     6a1:      	addq	$0x560, %rax            # imm = 0x560
     6a7:      	jmp	0x6af <event_execve+0x6af>
     6a9:      	addq	$0x550, %rax            # imm = 0x550
     6af:      	lock
     6b0:      	incq	(%rax)
     6b3:      	movq	%r15, %rax
     6b6:      	decq	%r15
     6b9:      	cmpq	$0x7fdf, %rax           # imm = 0x7FDF
     6bf:      	jne	0x76f <event_execve+0x76f>
     6c5:      	addq	%r15, %r12
     6c8:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     6cd:      	movl	$0x2d, %eax
     6d2:      	movq	%rbp, %rdi
     6d5:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     6da:      	movq	%r12, %rdx
     6dd:      	callq	*%rax
     6df:      	testq	%rax, %rax
     6e2:      	js	0x7be <event_execve+0x7be>
     6e8:      	je	0x76f <event_execve+0x76f>
     6ee:      	leal	0x1f(%rax), %r8d
     6f2:      	andl	$0x7fff, %r8d           # imm = 0x7FFF
     6f9:      	movl	%r8d, 0x4(%r13)
     6fd:      	movq	(%rip), %rsi            # 0x704 <event_execve+0x704>
     704:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     709:      	movq	%rax, %r12
     70c:      	movl	$0x19, %eax
     711:      	movq	0x10(%rsp), %rdi
     716:      	decq	%r12
     719:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     71e:      	movq	%r13, %rcx
     721:      	callq	*%rax
     723:      	testq	%rax, %rax
     726:      	jns	0x7b8 <event_execve+0x7b8>
     72c:      	movq	%rax, %rbx
     72f:      	movl	$0x0, 0x28(%rsp)
     737:      	movq	(%rip), %rdi            # 0x73e <event_execve+0x73e>
     73e:      	leaq	0x28(%rsp), %rsi
     743:      	movl	$0x1, %eax
     748:      	callq	*%rax
     74a:      	testq	%rax, %rax
     74d:      	je	0x7b8 <event_execve+0x7b8>
     74f:      	cmpq	$-0xc, %rbx
     753:      	jg	0x774 <event_execve+0x774>
     755:      	cmpq	$-0x1c, %rbx
     759:      	je	0x78e <event_execve+0x78e>
     75b:      	cmpq	$-0x16, %rbx
     75f:      	je	0x7a6 <event_execve+0x7a6>
     761:      	cmpq	$-0x10, %rbx
     765:      	jne	0x79e <event_execve+0x79e>
     767:      	addq	$0x558, %rax            # imm = 0x558
     76d:      	jmp	0x7b4 <event_execve+0x7b4>
     76f:      	movq	%r15, %rax
     772:      	jmp	0x7be <event_execve+0x7be>
     774:      	cmpq	$-0xb, %rbx
     778:      	je	0x796 <event_execve+0x796>
     77a:      	cmpq	$-0x7, %rbx
     77e:      	je	0x7ae <event_execve+0x7ae>
     780:      	cmpq	$-0x2, %rbx
     784:      	jne	0x79e <event_execve+0x79e>
     786:      	addq	$0x548, %rax            # imm = 0x548
     78c:      	jmp	0x7b4 <event_execve+0x7b4>
     78e:      	addq	$0x568, %rax            # imm = 0x568
     794:      	jmp	0x7b4 <event_execve+0x7b4>
     796:      	addq	$0x570, %rax            # imm = 0x570
     79c:      	jmp	0x7b4 <event_execve+0x7b4>
     79e:      	addq	$0x540, %rax            # imm = 0x540
     7a4:      	jmp	0x7b4 <event_execve+0x7b4>
     7a6:      	addq	$0x560, %rax            # imm = 0x560
     7ac:      	jmp	0x7b4 <event_execve+0x7b4>
     7ae:      	addq	$0x550, %rax            # imm = 0x550
     7b4:      	lock
     7b5:      	incq	(%rax)
     7b8:      	addq	%r15, %r12
     7bb:      	movq	%r12, %rax
     7be:      	movq	0x10(%rsp), %r15
     7c3:      	movl	%eax, %ecx
     7c5:      	sarl	$0x1f, %ecx
     7c8:      	andl	%eax, %ecx
     7ca:      	xorl	%edx, %edx
     7cc:      	testl	%eax, %eax
     7ce:      	cmovgl	%eax, %edx
     7d1:      	movl	%ecx, 0x180(%r14)
     7d8:      	movq	$0x0, 0x184(%r14)
     7e3:      	movl	%edx, 0x18c(%r14)
     7ea:      	movl	$0x20, %ecx
     7ef:      	movl	$0x800000, %eax         # imm = 0x800000
     7f4:      	movw	%cx, 0x178(%r14)
     7fc:      	orl	%eax, 0x15c(%r14)
     803:      	addl	%ecx, 0x140(%r14)
     80a:      	movl	$0x23, %eax
     80f:      	callq	*%rax
     811:      	movl	$0x0, 0xa8(%rsp)
     81c:      	leaq	0xa78(%rax), %rdx
     823:      	leaq	0x20(%rsp), %rdi
     828:      	movl	$0x8, %ecx
     82d:      	movl	$0x4, %eax
     832:      	movl	$0x8, %esi
     837:      	callq	*%rax
     839:      	testq	%rax, %rax
     83c:      	je	0x898 <event_execve+0x898>
     83e:      	negl	%eax
     840:      	movw	%ax, 0x28(%rsp)
     845:      	movw	$0x9, 0x2a(%rsp)
     84c:      	movabsq	$0x400000042, %rax      # imm = 0x400000042
     856:      	movq	%rax, 0x2c(%rsp)
     85b:      	movq	(%rip), %rdi            # 0x862 <event_execve+0x862>
     862:      	leaq	0x28(%rsp), %rsi
     867:      	movl	$0x1, %eax
     86c:      	callq	*%rax
     86e:      	testq	%rax, %rax
     871:      	je	0x877 <event_execve+0x877>
     873:      	incl	(%rax)
     875:      	jmp	0x898 <event_execve+0x898>
     877:      	movl	$0x1, (%rsp)
     87e:      	movq	(%rip), %rdi            # 0x885 <event_execve+0x885>
     885:      	xorl	%ecx, %ecx
     887:      	leaq	0x28(%rsp), %rsi
     88c:      	movq	%rsp, %rdx
     88f:      	movl	$0x2, %eax
     894:      	xorl	%ecx, %ecx
     896:      	callq	*%rax
     898:      	leaq	0x140(%r14), %r12
     89f:      	movq	0x20(%rsp), %rcx
     8a4:      	xorl	%ebp, %ebp
     8a6:      	movl	$0x0, %r13d
     8ac:      	testq	%rcx, %rcx
     8af:      	je	0xdba <event_execve+0xdba>
     8b5:      	addq	$0x2b8, %rcx            # imm = 0x2B8
     8bc:      	movq	%rsp, %rdi
     8bf:      	movl	$0x8, %edx
     8c4:      	movl	$0x4, %eax
     8c9:      	movl	$0x2b8, %edx            # imm = 0x2B8
     8ce:      	addq	0x20(%rsp), %rdx
     8d3:      	movl	$0x8, %esi
     8d8:      	callq	*%rax
     8da:      	testq	%rax, %rax
     8dd:      	je	0x93c <event_execve+0x93c>
     8df:      	negl	%eax
     8e1:      	movw	%ax, 0x28(%rsp)
     8e6:      	movw	$0x9, 0x2a(%rsp)
     8ed:      	movabsq	$0x400000047, %rax      # imm = 0x400000047
     8f7:      	movq	%rax, 0x2c(%rsp)
     8fc:      	movq	(%rip), %rdi            # 0x903 <event_execve+0x903>
     903:      	leaq	0x28(%rsp), %rsi
     908:      	movl	$0x1, %eax
     90d:      	callq	*%rax
     90f:      	testq	%rax, %rax
     912:      	je	0x918 <event_execve+0x918>
     914:      	incl	(%rax)
     916:      	jmp	0x93c <event_execve+0x93c>
     918:      	movl	$0x1, 0x18(%rsp)
     920:      	movq	(%rip), %rdi            # 0x927 <event_execve+0x927>
     927:      	xorl	%ecx, %ecx
     929:      	leaq	0x28(%rsp), %rsi
     92e:      	leaq	0x18(%rsp), %rdx
     933:      	movl	$0x2, %eax
     938:      	xorl	%ecx, %ecx
     93a:      	callq	*%rax
     93c:      	movl	$0x2c0, %edx            # imm = 0x2C0
     941:      	movq	0x20(%rsp), %rcx
     946:      	addq	%rdx, %rcx
     949:      	leaq	0x18(%rsp), %rdi
     94e:      	movl	$0x8, %esi
     953:      	movl	$0x4, %eax
     958:      	addq	0x20(%rsp), %rdx
     95d:      	movl	$0x8, %esi
     962:      	callq	*%rax
     964:      	testq	%rax, %rax
     967:      	je	0x9a4 <event_execve+0x9a4>
     969:      	negl	%eax
     96b:      	movw	%ax, 0x28(%rsp)
     970:      	movw	$0x9, 0x2a(%rsp)
     977:      	movabsq	$0x400000048, %rax      # imm = 0x400000048
     981:      	movq	%rax, 0x2c(%rsp)
     986:      	movq	(%rip), %rdi            # 0x98d <event_execve+0x98d>
     98d:      	leaq	0x28(%rsp), %rsi
     992:      	movl	$0x1, %eax
     997:      	callq	*%rax
     999:      	testq	%rax, %rax
     99c:      	je	0xadc <event_execve+0xadc>
     9a2:      	incl	(%rax)
     9a4:      	cmpq	$0x0, (%rsp)
     9a9:      	movl	$0x0, %r13d
     9af:      	je	0xdba <event_execve+0xdba>
     9b5:      	cmpq	$0x0, 0x18(%rsp)
     9bb:      	movl	$0x0, %r13d
     9c1:      	je	0xdba <event_execve+0xdba>
     9c7:      	movq	(%rip), %rdi            # 0x9ce <event_execve+0x9ce>
     9ce:      	leaq	0xa8(%rsp), %rsi
     9d6:      	movl	$0x1, %eax
     9db:      	callq	*%rax
     9dd:      	movl	$0x0, %r13d
     9e3:      	testq	%rax, %rax
     9e6:      	je	0xdba <event_execve+0xdba>
     9ec:      	movq	%rax, %rdi
     9ef:      	movq	(%rsp), %rcx
     9f3:      	movl	$0x1000, %edx           # imm = 0x1000
     9f8:      	movl	$0x2d, %eax
     9fd:      	movq	(%rsp), %rdx
     a01:      	movl	$0x1000, %esi           # imm = 0x1000
     a06:      	callq	*%rax
     a08:      	movl	$0x0, %r13d
     a0e:      	testq	%rax, %rax
     a11:      	js	0xdba <event_execve+0xdba>
     a17:      	movq	%rax, %rbx
     a1a:      	addq	(%rsp), %rbx
     a1e:      	movq	%rbx, (%rsp)
     a22:      	movl	0x140(%r14), %r13d
     a29:      	andl	$0x1ff, %r13d           # imm = 0x1FF
     a30:      	movl	%r13d, 0x184c(%r14)
     a37:      	movq	0x18(%rsp), %rax
     a3c:      	movq	%rax, %rdx
     a3f:      	subq	%rbx, %rdx
     a42:      	cmpq	$0x3ff, %rdx            # imm = 0x3FF
     a49:      	ja	0xb16 <event_execve+0xb16>
     a4f:      	leaq	(%r14,%r13), %rdi
     a53:      	addq	$0x140, %rdi            # imm = 0x140
     a5a:      	movq	%r12, %rcx
     a5d:      	subq	%rdi, %rcx
     a60:      	addq	$0x400, %rcx            # imm = 0x400
     a67:      	cmpq	%rcx, %rdx
     a6a:      	jae	0xb16 <event_execve+0xb16>
     a70:      	decl	%edx
     a72:      	andl	$0x3ff, %edx            # imm = 0x3FF
     a78:      	xorl	%r13d, %r13d
     a7b:      	cmpq	%rbx, %rax
     a7e:      	cmovnel	%edx, %r13d
     a82:      	movl	$0x4, %eax
     a87:      	movq	(%rsp), %rdx
     a8b:      	movl	%r13d, %esi
     a8e:      	callq	*%rax
     a90:      	testq	%rax, %rax
     a93:      	je	0xdab <event_execve+0xdab>
     a99:      	movq	%rax, %rbx
     a9c:      	negl	%eax
     a9e:      	movw	%ax, 0x28(%rsp)
     aa3:      	movw	$0x9, 0x2a(%rsp)
     aaa:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     ab4:      	movq	%rax, 0x2c(%rsp)
     ab9:      	movq	(%rip), %rdi            # 0xac0 <event_execve+0xac0>
     ac0:      	leaq	0x28(%rsp), %rsi
     ac5:      	movl	$0x1, %eax
     aca:      	callq	*%rax
     acc:      	testq	%rax, %rax
     acf:      	je	0xc79 <event_execve+0xc79>
     ad5:      	incl	(%rax)
     ad7:      	jmp	0xc9d <event_execve+0xc9d>
     adc:      	movl	$0x1, 0x70(%rsp)
     ae4:      	movq	(%rip), %rdi            # 0xaeb <event_execve+0xaeb>
     aeb:      	xorl	%ecx, %ecx
     aed:      	leaq	0x28(%rsp), %rsi
     af2:      	leaq	0x70(%rsp), %rdx
     af7:      	movl	$0x2, %eax
     afc:      	xorl	%ecx, %ecx
     afe:      	callq	*%rax
     b00:      	cmpq	$0x0, (%rsp)
     b05:      	movl	$0x0, %r13d
     b0b:      	jne	0x9b5 <event_execve+0x9b5>
     b11:      	jmp	0xdba <event_execve+0xdba>
     b16:      	movq	%rdx, 0x78(%rsp)
     b1b:      	movl	$0x0, 0x70(%rsp)
     b23:      	movq	(%rip), %rdi            # 0xb2a <event_execve+0xb2a>
     b2a:      	leaq	0x70(%rsp), %rsi
     b2f:      	movl	$0x1, %eax
     b34:      	callq	*%rax
     b36:      	testq	%rax, %rax
     b39:      	je	0xc6c <event_execve+0xc6c>
     b3f:      	movq	%rax, %r15
     b42:      	movq	%rbx, 0x80(%rsp)
     b4a:      	movq	%r12, 0x88(%rsp)
     b52:      	addq	%r14, %r13
     b55:      	movl	$0x18, (%rax)
     b5b:      	movl	$0xe, %eax
     b60:      	callq	*%rax
     b62:      	leaq	0x10(%r15), %rbx
     b66:      	movq	%rax, 0x10(%r15)
     b6a:      	cmpq	$-0x16, %rax
     b6e:      	jne	0xb97 <event_execve+0xb97>
     b70:      	movq	0x10(%rsp), %rax
     b75:      	leaq	0x20(%rax), %rdx
     b79:      	leaq	0x28(%rsp), %rdi
     b7e:      	movl	$0x8, %ecx
     b83:      	movl	$0x4, %eax
     b88:      	movl	$0x8, %esi
     b8d:      	callq	*%rax
     b8f:      	movq	0x28(%rsp), %rax
     b94:      	movq	%rax, (%rbx)
     b97:      	movl	$0x7d, %eax
     b9c:      	callq	*%rax
     b9e:      	movq	%rax, 0x18(%r15)
     ba2:      	movq	(%rbx), %rax
     ba5:      	movq	0x8(%rbx), %rcx
     ba9:      	movq	%rax, 0x150(%r13)
     bb0:      	movq	%r13, 0x90(%rsp)
     bb8:      	movq	%rcx, 0x158(%r13)
     bbf:      	movq	%r15, 0x98(%rsp)
     bc7:      	addq	$0x20, %r15
     bcb:      	movl	$0xa, %r13d
     bd1:      	xorl	%ebx, %ebx
     bd3:      	movq	0x78(%rsp), %rdx
     bd8:      	movq	%rdx, %r12
     bdb:      	subq	%rbx, %r12
     bde:      	js	0xcb5 <event_execve+0xcb5>
     be4:      	movq	0x80(%rsp), %rax
     bec:      	leaq	(%rbx,%rax), %rdx
     bf0:      	cmpq	$0x7fe0, %r12           # imm = 0x7FE0
     bf7:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
     bfc:      	cmovaeq	%rax, %r12
     c00:      	movl	$0x4, %eax
     c05:      	movq	%r15, %rdi
     c08:      	movl	%r12d, %esi
     c0b:      	callq	*%rax
     c0d:      	testl	%eax, %eax
     c0f:      	js	0xc3e <event_execve+0xc3e>
     c11:      	leal	0x20(%r12), %r8d
     c16:      	movq	0x98(%rsp), %rcx
     c1e:      	movl	%r8d, 0x4(%rcx)
     c22:      	movl	$0x19, %eax
     c27:      	movq	0x10(%rsp), %rdi
     c2c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     c31:      	movq	(%rip), %rsi            # 0xc38 <event_execve+0xc38>
     c38:      	callq	*%rax
     c3a:      	testl	%eax, %eax
     c3c:      	jns	0xc41 <event_execve+0xc41>
     c3e:      	movslq	%eax, %r12
     c41:      	testl	%r12d, %r12d
     c44:      	movq	0x78(%rsp), %rdx
     c49:      	js	0xcbe <event_execve+0xcbe>
     c4b:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
     c52:      	addq	%r12, %rbx
     c55:      	cmpq	%rdx, %rbx
     c58:      	je	0xd06 <event_execve+0xd06>
     c5e:      	decl	%r13d
     c61:      	jne	0xbd8 <event_execve+0xbd8>
     c67:      	jmp	0xd4f <event_execve+0xd4f>
     c6c:      	xorl	%r13d, %r13d
     c6f:      	movq	0x10(%rsp), %r15
     c74:      	jmp	0xdab <event_execve+0xdab>
     c79:      	movl	$0x1, 0x70(%rsp)
     c81:      	movq	(%rip), %rdi            # 0xc88 <event_execve+0xc88>
     c88:      	xorl	%ecx, %ecx
     c8a:      	leaq	0x28(%rsp), %rsi
     c8f:      	leaq	0x70(%rsp), %rdx
     c94:      	movl	$0x2, %eax
     c99:      	xorl	%ecx, %ecx
     c9b:      	callq	*%rax
     c9d:      	testl	%ebx, %ebx
     c9f:      	jns	0xdab <event_execve+0xdab>
     ca5:      	orb	$0x2, 0x15d(%r14)
     cad:      	xorl	%r13d, %r13d
     cb0:      	jmp	0xdab <event_execve+0xdab>
     cb5:      	movq	$-0x1, %rbx
     cbc:      	jmp	0xcc1 <event_execve+0xcc1>
     cbe:      	movq	%r12, %rbx
     cc1:      	movl	$0x0, 0x28(%rsp)
     cc9:      	movq	(%rip), %rdi            # 0xcd0 <event_execve+0xcd0>
     cd0:      	leaq	0x28(%rsp), %rsi
     cd5:      	movl	$0x1, %eax
     cda:      	callq	*%rax
     cdc:      	testq	%rax, %rax
     cdf:      	movq	0x78(%rsp), %rdx
     ce4:      	je	0xd4f <event_execve+0xd4f>
     ce6:      	cmpq	$-0xc, %rbx
     cea:      	jg	0xd0b <event_execve+0xd0b>
     cec:      	cmpq	$-0x1c, %rbx
     cf0:      	je	0xd25 <event_execve+0xd25>
     cf2:      	cmpq	$-0x16, %rbx
     cf6:      	je	0xd3d <event_execve+0xd3d>
     cf8:      	cmpq	$-0x10, %rbx
     cfc:      	jne	0xd35 <event_execve+0xd35>
     cfe:      	addq	$0x558, %rax            # imm = 0x558
     d04:      	jmp	0xd4b <event_execve+0xd4b>
     d06:      	movq	%rdx, %rbx
     d09:      	jmp	0xd4f <event_execve+0xd4f>
     d0b:      	cmpq	$-0xb, %rbx
     d0f:      	je	0xd2d <event_execve+0xd2d>
     d11:      	cmpq	$-0x7, %rbx
     d15:      	je	0xd45 <event_execve+0xd45>
     d17:      	cmpq	$-0x2, %rbx
     d1b:      	jne	0xd35 <event_execve+0xd35>
     d1d:      	addq	$0x548, %rax            # imm = 0x548
     d23:      	jmp	0xd4b <event_execve+0xd4b>
     d25:      	addq	$0x568, %rax            # imm = 0x568
     d2b:      	jmp	0xd4b <event_execve+0xd4b>
     d2d:      	addq	$0x570, %rax            # imm = 0x570
     d33:      	jmp	0xd4b <event_execve+0xd4b>
     d35:      	addq	$0x540, %rax            # imm = 0x540
     d3b:      	jmp	0xd4b <event_execve+0xd4b>
     d3d:      	addq	$0x560, %rax            # imm = 0x560
     d43:      	jmp	0xd4b <event_execve+0xd4b>
     d45:      	addq	$0x550, %rax            # imm = 0x550
     d4b:      	lock
     d4c:      	incq	(%rax)
     d4f:      	movl	%edx, %eax
     d51:      	subl	%ebx, %eax
     d53:      	xorl	%ecx, %ecx
     d55:      	cmpq	$-0x1, %rdx
     d59:      	cmovel	%ecx, %eax
     d5c:      	testl	%ebx, %ebx
     d5e:      	movl	$0x0, %edx
     d63:      	cmovsl	%ebx, %edx
     d66:      	cmovsl	%ecx, %eax
     d69:      	cmovgl	%ebx, %ecx
     d6c:      	movq	0x90(%rsp), %rsi
     d74:      	movl	%edx, 0x140(%rsi)
     d7a:      	movl	$0x0, 0x144(%rsi)
     d84:      	movl	%eax, 0x148(%rsi)
     d8a:      	movl	%ecx, 0x14c(%rsi)
     d90:      	orb	$0x1, 0x15f(%r14)
     d98:      	movl	$0x20, %r13d
     d9e:      	movq	0x10(%rsp), %r15
     da3:      	movq	0x88(%rsp), %r12
     dab:      	movl	%r13d, 0x1848(%r14)
     db2:      	movw	%r13w, 0x17a(%r14)
     dba:      	addl	0x140(%r14), %r13d
     dc1:      	movl	%r13d, 0x140(%r14)
     dc8:      	testb	$0x20, 0x15d(%r14)
     dd0:      	jne	0x190c <event_execve+0x190c>
     dd6:      	movq	%r13, 0x80(%rsp)
     dde:      	movq	%r12, 0x88(%rsp)
     de6:      	movl	0x144(%r14), %ebx
     ded:      	movl	$0x23, %eax
     df2:      	callq	*%rax
     df4:      	movl	$0x0, (%rsp)
     dfb:      	testq	%rax, %rax
     dfe:      	je	0x146b <event_execve+0x146b>
     e04:      	movq	%rax, %r13
     e07:      	leaq	0xaf4(%rax), %rdx
     e0e:      	movq	%rsp, %rdi
     e11:      	movl	$0x4, %ecx
     e16:      	movl	$0x71, %eax
     e1b:      	movl	$0x4, %esi
     e20:      	callq	*%rax
     e22:      	cmpl	%ebx, (%rsp)
     e25:      	je	0x146e <event_execve+0x146e>
     e2b:      	addq	$0xb00, %r13            # imm = 0xB00
     e32:      	leaq	0x28(%rsp), %rdi
     e37:      	movl	$0x8, %ecx
     e3c:      	movl	$0x71, %eax
     e41:      	movl	$0x8, %esi
     e46:      	movq	%r13, %rdx
     e49:      	callq	*%rax
     e4b:      	movq	0x28(%rsp), %r13
     e50:      	testq	%r13, %r13
     e53:      	je	0x146b <event_execve+0x146b>
     e59:      	leaq	0xaf4(%r13), %rdx
     e60:      	movq	%rsp, %rdi
     e63:      	movl	$0x4, %ecx
     e68:      	movl	$0x71, %eax
     e6d:      	movl	$0x4, %esi
     e72:      	callq	*%rax
     e74:      	cmpl	%ebx, (%rsp)
     e77:      	je	0x146e <event_execve+0x146e>
     e7d:      	addq	$0xb00, %r13            # imm = 0xB00
     e84:      	leaq	0x28(%rsp), %rdi
     e89:      	movl	$0x8, %ecx
     e8e:      	movl	$0x71, %eax
     e93:      	movl	$0x8, %esi
     e98:      	movq	%r13, %rdx
     e9b:      	callq	*%rax
     e9d:      	movq	0x28(%rsp), %r13
     ea2:      	testq	%r13, %r13
     ea5:      	je	0x146b <event_execve+0x146b>
     eab:      	leaq	0xaf4(%r13), %rdx
     eb2:      	movq	%rsp, %rdi
     eb5:      	movl	$0x4, %ecx
     eba:      	movl	$0x71, %eax
     ebf:      	movl	$0x4, %esi
     ec4:      	callq	*%rax
     ec6:      	cmpl	%ebx, (%rsp)
     ec9:      	je	0x146e <event_execve+0x146e>
     ecf:      	addq	$0xb00, %r13            # imm = 0xB00
     ed6:      	leaq	0x28(%rsp), %rdi
     edb:      	movl	$0x8, %ecx
     ee0:      	movl	$0x71, %eax
     ee5:      	movl	$0x8, %esi
     eea:      	movq	%r13, %rdx
     eed:      	callq	*%rax
     eef:      	movq	0x28(%rsp), %r13
     ef4:      	testq	%r13, %r13
     ef7:      	je	0x146b <event_execve+0x146b>
     efd:      	leaq	0xaf4(%r13), %rdx
     f04:      	movq	%rsp, %rdi
     f07:      	movl	$0x4, %ecx
     f0c:      	movl	$0x71, %eax
     f11:      	movl	$0x4, %esi
     f16:      	callq	*%rax
     f18:      	cmpl	%ebx, (%rsp)
     f1b:      	je	0x146e <event_execve+0x146e>
     f21:      	addq	$0xb00, %r13            # imm = 0xB00
     f28:      	leaq	0x28(%rsp), %rdi
     f2d:      	movl	$0x8, %ecx
     f32:      	movl	$0x71, %eax
     f37:      	movl	$0x8, %esi
     f3c:      	movq	%r13, %rdx
     f3f:      	callq	*%rax
     f41:      	movq	0x28(%rsp), %r13
     f46:      	testq	%r13, %r13
     f49:      	je	0x146b <event_execve+0x146b>
     f4f:      	leaq	0xaf4(%r13), %rdx
     f56:      	movq	%rsp, %rdi
     f59:      	movl	$0x4, %ecx
     f5e:      	movl	$0x71, %eax
     f63:      	movl	$0x4, %esi
     f68:      	callq	*%rax
     f6a:      	cmpl	%ebx, (%rsp)
     f6d:      	je	0x146e <event_execve+0x146e>
     f73:      	addq	$0xb00, %r13            # imm = 0xB00
     f7a:      	leaq	0x28(%rsp), %rdi
     f7f:      	movl	$0x8, %ecx
     f84:      	movl	$0x71, %eax
     f89:      	movl	$0x8, %esi
     f8e:      	movq	%r13, %rdx
     f91:      	callq	*%rax
     f93:      	movq	0x28(%rsp), %r13
     f98:      	testq	%r13, %r13
     f9b:      	je	0x146b <event_execve+0x146b>
     fa1:      	leaq	0xaf4(%r13), %rdx
     fa8:      	movq	%rsp, %rdi
     fab:      	movl	$0x4, %ecx
     fb0:      	movl	$0x71, %eax
     fb5:      	movl	$0x4, %esi
     fba:      	callq	*%rax
     fbc:      	cmpl	%ebx, (%rsp)
     fbf:      	je	0x146e <event_execve+0x146e>
     fc5:      	addq	$0xb00, %r13            # imm = 0xB00
     fcc:      	leaq	0x28(%rsp), %rdi
     fd1:      	movl	$0x8, %ecx
     fd6:      	movl	$0x71, %eax
     fdb:      	movl	$0x8, %esi
     fe0:      	movq	%r13, %rdx
     fe3:      	callq	*%rax
     fe5:      	movq	0x28(%rsp), %r13
     fea:      	testq	%r13, %r13
     fed:      	je	0x146b <event_execve+0x146b>
     ff3:      	leaq	0xaf4(%r13), %rdx
     ffa:      	movq	%rsp, %rdi
     ffd:      	movl	$0x4, %ecx
    1002:      	movl	$0x71, %eax
    1007:      	movl	$0x4, %esi
    100c:      	callq	*%rax
    100e:      	cmpl	%ebx, (%rsp)
    1011:      	je	0x146e <event_execve+0x146e>
    1017:      	addq	$0xb00, %r13            # imm = 0xB00
    101e:      	leaq	0x28(%rsp), %rdi
    1023:      	movl	$0x8, %ecx
    1028:      	movl	$0x71, %eax
    102d:      	movl	$0x8, %esi
    1032:      	movq	%r13, %rdx
    1035:      	callq	*%rax
    1037:      	movq	0x28(%rsp), %r13
    103c:      	testq	%r13, %r13
    103f:      	je	0x146b <event_execve+0x146b>
    1045:      	leaq	0xaf4(%r13), %rdx
    104c:      	movq	%rsp, %rdi
    104f:      	movl	$0x4, %ecx
    1054:      	movl	$0x71, %eax
    1059:      	movl	$0x4, %esi
    105e:      	callq	*%rax
    1060:      	cmpl	%ebx, (%rsp)
    1063:      	je	0x2539 <event_execve+0x2539>
    1069:      	addq	$0xb00, %r13            # imm = 0xB00
    1070:      	leaq	0x28(%rsp), %rdi
    1075:      	movl	$0x8, %ecx
    107a:      	movl	$0x71, %eax
    107f:      	movl	$0x8, %esi
    1084:      	movq	%r13, %rdx
    1087:      	callq	*%rax
    1089:      	movq	0x28(%rsp), %r13
    108e:      	testq	%r13, %r13
    1091:      	je	0x2536 <event_execve+0x2536>
    1097:      	leaq	0xaf4(%r13), %rdx
    109e:      	movq	%rsp, %rdi
    10a1:      	movl	$0x4, %ecx
    10a6:      	movl	$0x71, %eax
    10ab:      	movl	$0x4, %esi
    10b0:      	callq	*%rax
    10b2:      	cmpl	%ebx, (%rsp)
    10b5:      	je	0x2539 <event_execve+0x2539>
    10bb:      	addq	$0xb00, %r13            # imm = 0xB00
    10c2:      	leaq	0x28(%rsp), %rdi
    10c7:      	movl	$0x8, %ecx
    10cc:      	movl	$0x71, %eax
    10d1:      	movl	$0x8, %esi
    10d6:      	movq	%r13, %rdx
    10d9:      	callq	*%rax
    10db:      	movq	0x28(%rsp), %r13
    10e0:      	testq	%r13, %r13
    10e3:      	je	0x2536 <event_execve+0x2536>
    10e9:      	leaq	0xaf4(%r13), %rdx
    10f0:      	movq	%rsp, %rdi
    10f3:      	movl	$0x4, %ecx
    10f8:      	movl	$0x71, %eax
    10fd:      	movl	$0x4, %esi
    1102:      	callq	*%rax
    1104:      	cmpl	%ebx, (%rsp)
    1107:      	je	0x2539 <event_execve+0x2539>
    110d:      	addq	$0xb00, %r13            # imm = 0xB00
    1114:      	leaq	0x28(%rsp), %rdi
    1119:      	movl	$0x8, %ecx
    111e:      	movl	$0x71, %eax
    1123:      	movl	$0x8, %esi
    1128:      	movq	%r13, %rdx
    112b:      	callq	*%rax
    112d:      	movq	0x28(%rsp), %r13
    1132:      	testq	%r13, %r13
    1135:      	je	0x2536 <event_execve+0x2536>
    113b:      	leaq	0xaf4(%r13), %rdx
    1142:      	movq	%rsp, %rdi
    1145:      	movl	$0x4, %ecx
    114a:      	movl	$0x71, %eax
    114f:      	movl	$0x4, %esi
    1154:      	callq	*%rax
    1156:      	cmpl	%ebx, (%rsp)
    1159:      	je	0x2539 <event_execve+0x2539>
    115f:      	addq	$0xb00, %r13            # imm = 0xB00
    1166:      	leaq	0x28(%rsp), %rdi
    116b:      	movl	$0x8, %ecx
    1170:      	movl	$0x71, %eax
    1175:      	movl	$0x8, %esi
    117a:      	movq	%r13, %rdx
    117d:      	callq	*%rax
    117f:      	movq	0x28(%rsp), %r13
    1184:      	testq	%r13, %r13
    1187:      	je	0x2536 <event_execve+0x2536>
    118d:      	leaq	0xaf4(%r13), %rdx
    1194:      	movq	%rsp, %rdi
    1197:      	movl	$0x4, %ecx
    119c:      	movl	$0x71, %eax
    11a1:      	movl	$0x4, %esi
    11a6:      	callq	*%rax
    11a8:      	cmpl	%ebx, (%rsp)
    11ab:      	je	0x2539 <event_execve+0x2539>
    11b1:      	addq	$0xb00, %r13            # imm = 0xB00
    11b8:      	leaq	0x28(%rsp), %rdi
    11bd:      	movl	$0x8, %ecx
    11c2:      	movl	$0x71, %eax
    11c7:      	movl	$0x8, %esi
    11cc:      	movq	%r13, %rdx
    11cf:      	callq	*%rax
    11d1:      	movq	0x28(%rsp), %r13
    11d6:      	testq	%r13, %r13
    11d9:      	je	0x2536 <event_execve+0x2536>
    11df:      	leaq	0xaf4(%r13), %rdx
    11e6:      	movq	%rsp, %rdi
    11e9:      	movl	$0x4, %ecx
    11ee:      	movl	$0x71, %eax
    11f3:      	movl	$0x4, %esi
    11f8:      	callq	*%rax
    11fa:      	cmpl	%ebx, (%rsp)
    11fd:      	je	0x2539 <event_execve+0x2539>
    1203:      	addq	$0xb00, %r13            # imm = 0xB00
    120a:      	leaq	0x28(%rsp), %rdi
    120f:      	movl	$0x8, %ecx
    1214:      	movl	$0x71, %eax
    1219:      	movl	$0x8, %esi
    121e:      	movq	%r13, %rdx
    1221:      	callq	*%rax
    1223:      	movq	0x28(%rsp), %r13
    1228:      	testq	%r13, %r13
    122b:      	je	0x2536 <event_execve+0x2536>
    1231:      	leaq	0xaf4(%r13), %rdx
    1238:      	movq	%rsp, %rdi
    123b:      	movl	$0x4, %ecx
    1240:      	movl	$0x71, %eax
    1245:      	movl	$0x4, %esi
    124a:      	callq	*%rax
    124c:      	cmpl	%ebx, (%rsp)
    124f:      	je	0x2539 <event_execve+0x2539>
    1255:      	addq	$0xb00, %r13            # imm = 0xB00
    125c:      	leaq	0x28(%rsp), %rdi
    1261:      	movl	$0x8, %ecx
    1266:      	movl	$0x71, %eax
    126b:      	movl	$0x8, %esi
    1270:      	movq	%r13, %rdx
    1273:      	callq	*%rax
    1275:      	movq	0x28(%rsp), %r13
    127a:      	testq	%r13, %r13
    127d:      	je	0x2536 <event_execve+0x2536>
    1283:      	leaq	0xaf4(%r13), %rdx
    128a:      	movq	%rsp, %rdi
    128d:      	movl	$0x4, %ecx
    1292:      	movl	$0x71, %eax
    1297:      	movl	$0x4, %esi
    129c:      	callq	*%rax
    129e:      	cmpl	%ebx, (%rsp)
    12a1:      	je	0x2539 <event_execve+0x2539>
    12a7:      	addq	$0xb00, %r13            # imm = 0xB00
    12ae:      	leaq	0x28(%rsp), %rdi
    12b3:      	movl	$0x8, %ecx
    12b8:      	movl	$0x71, %eax
    12bd:      	movl	$0x8, %esi
    12c2:      	movq	%r13, %rdx
    12c5:      	callq	*%rax
    12c7:      	movq	0x28(%rsp), %r13
    12cc:      	testq	%r13, %r13
    12cf:      	je	0x2536 <event_execve+0x2536>
    12d5:      	leaq	0xaf4(%r13), %rdx
    12dc:      	movq	%rsp, %rdi
    12df:      	movl	$0x4, %ecx
    12e4:      	movl	$0x71, %eax
    12e9:      	movl	$0x4, %esi
    12ee:      	callq	*%rax
    12f0:      	cmpl	%ebx, (%rsp)
    12f3:      	je	0x2539 <event_execve+0x2539>
    12f9:      	addq	$0xb00, %r13            # imm = 0xB00
    1300:      	leaq	0x28(%rsp), %rdi
    1305:      	movl	$0x8, %ecx
    130a:      	movl	$0x71, %eax
    130f:      	movl	$0x8, %esi
    1314:      	movq	%r13, %rdx
    1317:      	callq	*%rax
    1319:      	movq	0x28(%rsp), %r13
    131e:      	testq	%r13, %r13
    1321:      	je	0x2536 <event_execve+0x2536>
    1327:      	leaq	0xaf4(%r13), %rdx
    132e:      	movq	%rsp, %rdi
    1331:      	movl	$0x4, %ecx
    1336:      	movl	$0x71, %eax
    133b:      	movl	$0x4, %esi
    1340:      	callq	*%rax
    1342:      	cmpl	%ebx, (%rsp)
    1345:      	je	0x2539 <event_execve+0x2539>
    134b:      	addq	$0xb00, %r13            # imm = 0xB00
    1352:      	leaq	0x28(%rsp), %rdi
    1357:      	movl	$0x8, %ecx
    135c:      	movl	$0x71, %eax
    1361:      	movl	$0x8, %esi
    1366:      	movq	%r13, %rdx
    1369:      	callq	*%rax
    136b:      	movq	0x28(%rsp), %r13
    1370:      	testq	%r13, %r13
    1373:      	je	0x2536 <event_execve+0x2536>
    1379:      	leaq	0xaf4(%r13), %rdx
    1380:      	movq	%rsp, %rdi
    1383:      	movl	$0x4, %ecx
    1388:      	movl	$0x71, %eax
    138d:      	movl	$0x4, %esi
    1392:      	callq	*%rax
    1394:      	cmpl	%ebx, (%rsp)
    1397:      	je	0x2539 <event_execve+0x2539>
    139d:      	addq	$0xb00, %r13            # imm = 0xB00
    13a4:      	leaq	0x28(%rsp), %rdi
    13a9:      	movl	$0x8, %ecx
    13ae:      	movl	$0x71, %eax
    13b3:      	movl	$0x8, %esi
    13b8:      	movq	%r13, %rdx
    13bb:      	callq	*%rax
    13bd:      	movq	0x28(%rsp), %r13
    13c2:      	testq	%r13, %r13
    13c5:      	je	0x2536 <event_execve+0x2536>
    13cb:      	leaq	0xaf4(%r13), %rdx
    13d2:      	movq	%rsp, %rdi
    13d5:      	movl	$0x4, %ecx
    13da:      	movl	$0x71, %eax
    13df:      	movl	$0x4, %esi
    13e4:      	callq	*%rax
    13e6:      	cmpl	%ebx, (%rsp)
    13e9:      	je	0x2539 <event_execve+0x2539>
    13ef:      	addq	$0xb00, %r13            # imm = 0xB00
    13f6:      	leaq	0x28(%rsp), %rdi
    13fb:      	movl	$0x8, %ecx
    1400:      	movl	$0x71, %eax
    1405:      	movl	$0x8, %esi
    140a:      	movq	%r13, %rdx
    140d:      	callq	*%rax
    140f:      	movq	0x28(%rsp), %r13
    1414:      	testq	%r13, %r13
    1417:      	je	0x2536 <event_execve+0x2536>
    141d:      	leaq	0xaf4(%r13), %rdx
    1424:      	movq	%rsp, %rdi
    1427:      	movl	$0x4, %ecx
    142c:      	movl	$0x71, %eax
    1431:      	movl	$0x4, %esi
    1436:      	callq	*%rax
    1438:      	cmpl	%ebx, (%rsp)
    143b:      	je	0x2539 <event_execve+0x2539>
    1441:      	addq	$0xb00, %r13            # imm = 0xB00
    1448:      	leaq	0x28(%rsp), %rdi
    144d:      	movl	$0x8, %ecx
    1452:      	movl	$0x71, %eax
    1457:      	movl	$0x8, %esi
    145c:      	movq	%r13, %rdx
    145f:      	callq	*%rax
    1461:      	movq	0x28(%rsp), %r13
    1466:      	jmp	0x2539 <event_execve+0x2539>
    146b:      	xorl	%r13d, %r13d
    146e:      	xorl	%ebp, %ebp
    1470:      	cmpl	%ebx, (%rsp)
    1473:      	cmovneq	%rbp, %r13
    1477:      	addq	$0xd50, %r13            # imm = 0xD50
    147e:      	leaq	0xb8(%rsp), %rdi
    1486:      	movl	$0x8, %ecx
    148b:      	movl	$0x4, %eax
    1490:      	movl	$0x8, %esi
    1495:      	movq	%r13, %rdx
    1498:      	callq	*%rax
    149a:      	movq	0xb8(%rsp), %rbx
    14a2:      	testq	%rbx, %rbx
    14a5:      	je	0x1583 <event_execve+0x1583>
    14ab:      	movl	$0x0, 0xb4(%rsp)
    14b6:      	movq	(%rip), %rdi            # 0x14bd <event_execve+0x14bd>
    14bd:      	leaq	0xb4(%rsp), %rsi
    14c5:      	movl	$0x1, %eax
    14ca:      	callq	*%rax
    14cc:      	testq	%rax, %rax
    14cf:      	je	0x1598 <event_execve+0x1598>
    14d5:      	movq	%rax, %r13
    14d8:      	leaq	0x28(%rbx), %rax
    14dc:      	movq	%rax, 0x98(%rsp)
    14e4:      	leaq	0x1000(%r13), %rax
    14eb:      	movq	%rax, 0x78(%rsp)
    14f0:      	movl	$0x23, %eax
    14f5:      	callq	*%rax
    14f7:      	leaq	0xd50(%rax), %rdx
    14fe:      	leaq	0xc0(%rsp), %rdi
    1506:      	movl	$0x8, %ecx
    150b:      	movl	$0x4, %eax
    1510:      	movl	$0x8, %esi
    1515:      	callq	*%rax
    1517:      	movq	0xc0(%rsp), %rbp
    151f:      	addq	$0x30, %rbx
    1523:      	leaq	0xa8(%rsp), %rdi
    152b:      	movl	$0x8, %ecx
    1530:      	movl	$0x4, %eax
    1535:      	leaq	0x18(%rbp), %rcx
    1539:      	movq	%rcx, 0x90(%rsp)
    1541:      	movl	$0x8, %esi
    1546:      	movq	%rbx, %rdx
    1549:      	callq	*%rax
    154b:      	movq	0xa8(%rsp), %r12
    1553:      	leaq	0x10(%r12), %rdx
    1558:      	leaq	0x28(%rsp), %rdi
    155d:      	movl	$0x8, %ecx
    1562:      	movl	$0x4, %eax
    1567:      	movl	$0x8, %esi
    156c:      	callq	*%rax
    156e:      	cmpq	$0x0, 0x28(%rsp)
    1574:      	movl	$0x1000, %r15d          # imm = 0x1000
    157a:      	je	0x15a7 <event_execve+0x15a7>
    157c:      	movq	0x78(%rsp), %rcx
    1581:      	jmp	0x15f9 <event_execve+0x15f9>
    1583:      	orb	$0x20, 0x15d(%r14)
    158b:      	movq	0x88(%rsp), %r12
    1593:      	jmp	0x1908 <event_execve+0x1908>
    1598:      	xorl	%ebp, %ebp
    159a:      	movq	0x88(%rsp), %r12
    15a2:      	jmp	0x1908 <event_execve+0x1908>
    15a7:      	leaq	0x18(%r12), %rdx
    15ac:      	leaq	0x28(%rsp), %rdi
    15b1:      	movl	$0x8, %ecx
    15b6:      	movl	$0x4, %eax
    15bb:      	movl	$0x8, %esi
    15c0:      	callq	*%rax
    15c2:      	cmpq	%r12, 0x28(%rsp)
    15c7:      	movq	0x78(%rsp), %rcx
    15cc:      	je	0x15f9 <event_execve+0x15f9>
    15ce:      	movq	%r13, %rcx
    15d1:      	addq	$0xff6, %rcx            # imm = 0xFF6
    15d8:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    15e2:      	movq	%rax, 0xff6(%r13)
    15e9:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
    15f3:      	movl	$0xff6, %r15d           # imm = 0xFF6
    15f9:      	movq	$0x0, 0x30(%rsp)
    1602:      	movq	$0x0, 0x28(%rsp)
    160b:      	movq	%r13, 0x38(%rsp)
    1610:      	movq	$0x0, 0x40(%rsp)
    1619:      	movq	$0x0, 0x48(%rsp)
    1622:      	movq	$0x0, 0x50(%rsp)
    162b:      	movq	%rcx, 0x78(%rsp)
    1630:      	movq	%rcx, 0x58(%rsp)
    1635:      	movl	%r15d, 0x60(%rsp)
    163a:      	movb	$0x0, 0x64(%rsp)
    163f:      	addq	$0x20, %rbp
    1643:      	leaq	0x28(%rsp), %rdi
    1648:      	movl	$0x8, %r15d
    164e:      	movl	$0x4, %eax
    1653:      	leaq	0x30(%rsp), %r12
    1658:      	leaq	0x40(%rsp), %r13
    165d:      	movl	$0x8, %esi
    1662:      	movq	%rbp, %rdx
    1665:      	callq	*%rax
    1667:      	movl	$0x8, %ecx
    166c:      	movl	$0x4, %eax
    1671:      	movq	0x90(%rsp), %rdx
    1679:      	movq	%r12, %rdi
    167c:      	movl	$0x8, %esi
    1681:      	callq	*%rax
    1683:      	movl	$0x8, %ecx
    1688:      	movl	$0x4, %eax
    168d:      	movq	%r13, %rdi
    1690:      	movl	$0x8, %esi
    1695:      	movq	%rbx, %rdx
    1698:      	callq	*%rax
    169a:      	movl	$0x8, %ecx
    169f:      	movl	$0x4, %eax
    16a4:      	movq	0x98(%rsp), %rdx
    16ac:      	leaq	0x48(%rsp), %rdi
    16b1:      	movl	$0x8, %esi
    16b6:      	callq	*%rax
    16b8:      	movq	0x48(%rsp), %rax
    16bd:      	addq	$-0x20, %rax
    16c1:      	movq	%rax, 0x50(%rsp)
    16c6:      	movl	$0x80, %ebx
    16cb:      	nopl	(%rax,%rax)
    16d0:      	movq	0x40(%rsp), %rbp
    16d5:      	movq	0x48(%rsp), %rdx
    16da:      	movq	0x50(%rsp), %r13
    16df:      	cmpq	0x28(%rsp), %rbp
    16e4:      	jne	0x16f1 <event_execve+0x16f1>
    16e6:      	cmpq	0x30(%rsp), %rdx
    16eb:      	je	0x1856 <event_execve+0x1856>
    16f1:      	movl	$0x4, %eax
    16f6:      	leaq	0x70(%rsp), %rdi
    16fb:      	movl	$0x8, %esi
    1700:      	callq	*%rax
    1702:      	cmpq	0x70(%rsp), %rbp
    1707:      	je	0x1800 <event_execve+0x1800>
    170d:      	leaq	0x18(%rbp), %r12
    1711:      	movl	$0x4, %eax
    1716:      	leaq	0x18(%rsp), %rdi
    171b:      	movl	$0x8, %esi
    1720:      	movq	%r12, %rdx
    1723:      	callq	*%rax
    1725:      	cmpq	%rbp, 0x18(%rsp)
    172a:      	je	0x1800 <event_execve+0x1800>
    1730:      	movl	$0x4, %eax
    1735:      	leaq	0x20(%rsp), %rdi
    173a:      	movl	$0x8, %esi
    173f:      	movq	%r12, %rdx
    1742:      	callq	*%rax
    1744:      	addq	$0x20, %rbp
    1748:      	movl	$0x4, %eax
    174d:      	movq	%rsp, %rdi
    1750:      	movl	$0x10, %ecx
    1755:      	movl	$0x10, %esi
    175a:      	movq	%rbp, %rdx
    175d:      	callq	*%rax
    175f:      	movq	0x38(%rsp), %r12
    1764:      	movq	0x58(%rsp), %rax
    1769:      	movl	0x4(%rsp), %ebp
    176d:      	subq	%r12, %rax
    1770:      	movl	0x60(%rsp), %r13d
    1775:      	movl	%ebp, %edx
    1777:      	subl	%r13d, %edx
    177a:      	movl	$0x0, %ecx
    177f:      	cmovbl	%ecx, %edx
    1782:      	addq	0x8(%rsp), %rdx
    1787:      	xorl	%esi, %esi
    1789:      	cmpl	%ebp, %r13d
    178c:      	seta	%sil
    1790:      	movl	%ebp, %ecx
    1792:      	cmovbl	%r13d, %ecx
    1796:      	addl	%ecx, %esi
    1798:      	movl	%r13d, %edi
    179b:      	subl	%esi, %edi
    179d:      	movl	%edi, 0x60(%rsp)
    17a1:      	subq	%rsi, %rax
    17a4:      	jb	0x185b <event_execve+0x185b>
    17aa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    17b0:      	ja	0x185b <event_execve+0x185b>
    17b6:      	cmpl	%ebp, %r13d
    17b9:      	jbe	0x17c0 <event_execve+0x17c0>
    17bb:      	movb	$0x2f, (%r12,%rax)
    17c0:      	xorl	%edi, %edi
    17c2:      	cmpl	%ebp, %r13d
    17c5:      	seta	%dil
    17c9:      	movzbl	%cl, %esi
    17cc:      	addq	%rax, %r12
    17cf:      	addq	%r12, %rdi
    17d2:      	movl	$0x4, %eax
    17d7:      	callq	*%rax
    17d9:      	movq	%r12, 0x58(%rsp)
    17de:      	cmpl	%ebp, %r13d
    17e1:      	jbe	0x185b <event_execve+0x185b>
    17e3:      	movq	0x20(%rsp), %rax
    17e8:      	movq	%rax, 0x40(%rsp)
    17ed:      	decl	%ebx
    17ef:      	jne	0x16d0 <event_execve+0x16d0>
    17f5:      	jmp	0x185b <event_execve+0x185b>
    17f7:      	nopw	(%rax,%rax)
    1800:      	leaq	0x10(%r13), %rdx
    1804:      	movl	$0x4, %eax
    1809:      	leaq	0x18(%rsp), %rdi
    180e:      	movl	$0x8, %esi
    1813:      	callq	*%rax
    1815:      	movq	0x50(%rsp), %rax
    181a:      	cmpq	0x18(%rsp), %rax
    181f:      	je	0x1856 <event_execve+0x1856>
    1821:      	addq	$0x18, %r13
    1825:      	movl	$0x4, %eax
    182a:      	leaq	0x40(%rsp), %rdi
    182f:      	movl	$0x8, %esi
    1834:      	movq	%r13, %rdx
    1837:      	callq	*%rax
    1839:      	movq	0x18(%rsp), %rax
    183e:      	movq	%rax, 0x50(%rsp)
    1843:      	addq	$0x20, %rax
    1847:      	movq	%rax, 0x48(%rsp)
    184c:      	decl	%ebx
    184e:      	jne	0x16d0 <event_execve+0x16d0>
    1854:      	jmp	0x185b <event_execve+0x185b>
    1856:      	movb	$0x1, 0x64(%rsp)
    185b:      	movq	0x58(%rsp), %rax
    1860:      	movq	0x78(%rsp), %rdx
    1865:      	cmpq	%rdx, %rax
    1868:      	movq	0x88(%rsp), %r12
    1870:      	je	0x18a7 <event_execve+0x18a7>
    1872:      	xorl	%ebx, %ebx
    1874:      	cmpb	$0x0, 0x64(%rsp)
    1879:      	sete	%cl
    187c:      	movl	0x60(%rsp), %edx
    1880:      	movl	$0x1000, %ebp           # imm = 0x1000
    1885:      	subl	%edx, %ebp
    1887:      	testl	%edx, %edx
    1889:      	cmovlel	%edx, %ebp
    188c:      	testq	%rax, %rax
    188f:      	movq	0x10(%rsp), %r15
    1894:      	movq	0x80(%rsp), %rdi
    189c:      	je	0x1906 <event_execve+0x1906>
    189e:      	movb	%cl, %bl
    18a0:      	addl	%ebx, %ebx
    18a2:      	movq	%rax, %rdx
    18a5:      	jmp	0x18b8 <event_execve+0x18b8>
    18a7:      	xorl	%ebp, %ebp
    18a9:      	xorl	%ebx, %ebx
    18ab:      	movq	0x10(%rsp), %r15
    18b0:      	movq	0x80(%rsp), %rdi
    18b8:      	andl	$0x3ff, %edi            # imm = 0x3FF
    18be:      	andl	$0xfff, %ebp            # imm = 0xFFF
    18c4:      	addq	%r12, %rdi
    18c7:      	movl	$0x4, %eax
    18cc:      	movl	%ebp, %esi
    18ce:      	callq	*%rax
    18d0:      	movl	0x15c(%r14), %eax
    18d7:      	movl	%eax, %ecx
    18d9:      	orl	$0x1000, %ecx           # imm = 0x1000
    18df:      	testl	%ebp, %ebp
    18e1:      	cmovnel	%eax, %ecx
    18e4:      	movl	%ecx, %eax
    18e6:      	orl	$0x400000, %eax         # imm = 0x400000
    18eb:      	testl	%ebx, %ebx
    18ed:      	cmovel	%ecx, %eax
    18f0:      	andl	$0xffffdbff, %eax       # imm = 0xFFFFDBFF
    18f5:      	movl	%eax, 0x15c(%r14)
    18fc:      	movw	%bp, 0x17c(%r14)
    1904:      	jmp	0x1908 <event_execve+0x1908>
    1906:      	xorl	%ebp, %ebp
    1908:      	movl	(%r12), %r13d
    190c:      	addl	%ebp, %r13d
    190f:      	movl	%r13d, (%r12)
    1913:      	movq	$0x0, (%rsp)
    191b:      	movq	(%rip), %rax            # 0x1922 <event_execve+0x1922>
    1922:      	xorl	%r12d, %r12d
    1925:      	cmpb	$0x0, (%rax)
    1928:      	je	0x1d50 <event_execve+0x1d50>
    192e:      	cmpl	$0x3ff, %r13d           # imm = 0x3FF
    1935:      	ja	0x1d50 <event_execve+0x1d50>
    193b:      	movl	$0x23, %eax
    1940:      	callq	*%rax
    1942:      	leaq	0xa78(%rax), %rdx
    1949:      	movq	%rsp, %rdi
    194c:      	movl	$0x8, %ecx
    1951:      	movl	$0x4, %eax
    1956:      	movl	$0x8, %esi
    195b:      	callq	*%rax
    195d:      	movq	(%rsp), %rcx
    1961:      	testq	%rcx, %rcx
    1964:      	je	0x1d50 <event_execve+0x1d50>
    196a:      	addq	$0x2c8, %rcx            # imm = 0x2C8
    1971:      	leaq	0x18(%rsp), %rdi
    1976:      	movl	$0x8, %edx
    197b:      	movl	$0x4, %eax
    1980:      	movl	$0x2c8, %edx            # imm = 0x2C8
    1985:      	addq	(%rsp), %rdx
    1989:      	movl	$0x8, %esi
    198e:      	callq	*%rax
    1990:      	testq	%rax, %rax
    1993:      	je	0x19f2 <event_execve+0x19f2>
    1995:      	negl	%eax
    1997:      	movw	%ax, 0x28(%rsp)
    199c:      	movw	$0x9, 0x2a(%rsp)
    19a3:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    19ad:      	movq	%rax, 0x2c(%rsp)
    19b2:      	movq	(%rip), %rdi            # 0x19b9 <event_execve+0x19b9>
    19b9:      	leaq	0x28(%rsp), %rsi
    19be:      	movl	$0x1, %eax
    19c3:      	callq	*%rax
    19c5:      	testq	%rax, %rax
    19c8:      	je	0x19ce <event_execve+0x19ce>
    19ca:      	incl	(%rax)
    19cc:      	jmp	0x19f2 <event_execve+0x19f2>
    19ce:      	movl	$0x1, 0x20(%rsp)
    19d6:      	movq	(%rip), %rdi            # 0x19dd <event_execve+0x19dd>
    19dd:      	xorl	%ecx, %ecx
    19df:      	leaq	0x28(%rsp), %rsi
    19e4:      	leaq	0x20(%rsp), %rdx
    19e9:      	movl	$0x2, %eax
    19ee:      	xorl	%ecx, %ecx
    19f0:      	callq	*%rax
    19f2:      	movl	$0x2d0, %edx            # imm = 0x2D0
    19f7:      	movq	(%rsp), %rcx
    19fb:      	addq	%rdx, %rcx
    19fe:      	leaq	0x20(%rsp), %rdi
    1a03:      	movl	$0x8, %esi
    1a08:      	movl	$0x4, %eax
    1a0d:      	addq	(%rsp), %rdx
    1a11:      	movl	$0x8, %esi
    1a16:      	callq	*%rax
    1a18:      	testq	%rax, %rax
    1a1b:      	je	0x1a58 <event_execve+0x1a58>
    1a1d:      	negl	%eax
    1a1f:      	movw	%ax, 0x28(%rsp)
    1a24:      	movw	$0x9, 0x2a(%rsp)
    1a2b:      	movabsq	$0x40000009b, %rax      # imm = 0x40000009B
    1a35:      	movq	%rax, 0x2c(%rsp)
    1a3a:      	movq	(%rip), %rdi            # 0x1a41 <event_execve+0x1a41>
    1a41:      	leaq	0x28(%rsp), %rsi
    1a46:      	movl	$0x1, %eax
    1a4b:      	callq	*%rax
    1a4d:      	testq	%rax, %rax
    1a50:      	je	0x1c0c <event_execve+0x1c0c>
    1a56:      	incl	(%rax)
    1a58:      	movq	0x18(%rsp), %rbp
    1a5d:      	testq	%rbp, %rbp
    1a60:      	je	0x1d50 <event_execve+0x1d50>
    1a66:      	movq	0x20(%rsp), %rax
    1a6b:      	testq	%rax, %rax
    1a6e:      	je	0x1d50 <event_execve+0x1d50>
    1a74:      	movl	%r13d, %r13d
    1a77:      	movq	%rax, %r12
    1a7a:      	subq	%rbp, %r12
    1a7d:      	cmpq	$0x3ff, %r12            # imm = 0x3FF
    1a84:      	ja	0x1ad8 <event_execve+0x1ad8>
    1a86:      	leaq	(%r14,%r13), %rdi
    1a8a:      	addq	$0x140, %rdi            # imm = 0x140
    1a91:      	leaq	0x540(%r14), %rcx
    1a98:      	subq	%rdi, %rcx
    1a9b:      	cmpq	%rcx, %r12
    1a9e:      	jae	0x1ad8 <event_execve+0x1ad8>
    1aa0:      	decl	%r12d
    1aa3:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    1aaa:      	xorl	%ebx, %ebx
    1aac:      	cmpq	%rbp, %rax
    1aaf:      	cmovel	%ebx, %r12d
    1ab3:      	movl	$0x4, %eax
    1ab8:      	movq	0x18(%rsp), %rdx
    1abd:      	movl	%r12d, %esi
    1ac0:      	callq	*%rax
    1ac2:      	andl	$0x80000000, %eax       # imm = 0x80000000
    1ac7:      	movl	%eax, %ecx
    1ac9:      	shrl	$0x1c, %ecx
    1acc:      	testq	%rax, %rax
    1acf:      	cmovnel	%ebx, %r12d
    1ad3:      	jmp	0x1d41 <event_execve+0x1d41>
    1ad8:      	movl	$0x0, 0x70(%rsp)
    1ae0:      	movq	(%rip), %rdi            # 0x1ae7 <event_execve+0x1ae7>
    1ae7:      	leaq	0x70(%rsp), %rsi
    1aec:      	movl	$0x1, %eax
    1af1:      	callq	*%rax
    1af3:      	testq	%rax, %rax
    1af6:      	je	0x1c43 <event_execve+0x1c43>
    1afc:      	movq	%rax, %rbx
    1aff:      	movq	%rbp, 0x88(%rsp)
    1b07:      	addq	%r14, %r13
    1b0a:      	movl	$0x18, (%rax)
    1b10:      	movl	$0xe, %eax
    1b15:      	callq	*%rax
    1b17:      	leaq	0x10(%rbx), %rcx
    1b1b:      	movq	%rax, 0x10(%rbx)
    1b1f:      	cmpq	$-0x16, %rax
    1b23:      	movq	%rbx, %rbp
    1b26:      	movq	%rcx, %rbx
    1b29:      	jne	0x1b4d <event_execve+0x1b4d>
    1b2b:      	leaq	0x20(%r15), %rdx
    1b2f:      	leaq	0x28(%rsp), %rdi
    1b34:      	movl	$0x8, %ecx
    1b39:      	movl	$0x4, %eax
    1b3e:      	movl	$0x8, %esi
    1b43:      	callq	*%rax
    1b45:      	movq	0x28(%rsp), %rax
    1b4a:      	movq	%rax, (%rbx)
    1b4d:      	movl	$0x7d, %eax
    1b52:      	callq	*%rax
    1b54:      	movq	%rax, 0x18(%rbp)
    1b58:      	movq	(%rbx), %rax
    1b5b:      	movq	0x8(%rbx), %rcx
    1b5f:      	movq	%rax, 0x150(%r13)
    1b66:      	movq	%r13, 0x80(%rsp)
    1b6e:      	movq	%rcx, 0x158(%r13)
    1b75:      	movq	%rbp, 0x78(%rsp)
    1b7a:      	movq	%rbp, %r15
    1b7d:      	addq	$0x20, %r15
    1b81:      	movl	$0xa, %ebx
    1b86:      	xorl	%r13d, %r13d
    1b89:      	movq	%r12, %rbp
    1b8c:      	subq	%r13, %rbp
    1b8f:      	js	0x1c4d <event_execve+0x1c4d>
    1b95:      	movq	0x88(%rsp), %rax
    1b9d:      	leaq	(%rax,%r13), %rdx
    1ba1:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    1ba8:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    1bad:      	cmovaeq	%rax, %rbp
    1bb1:      	movl	$0x4, %eax
    1bb6:      	movq	%r15, %rdi
    1bb9:      	movl	%ebp, %esi
    1bbb:      	callq	*%rax
    1bbd:      	testl	%eax, %eax
    1bbf:      	js	0x1bea <event_execve+0x1bea>
    1bc1:      	leal	0x20(%rbp), %r8d
    1bc5:      	movq	0x78(%rsp), %rcx
    1bca:      	movl	%r8d, 0x4(%rcx)
    1bce:      	movl	$0x19, %eax
    1bd3:      	movq	0x10(%rsp), %rdi
    1bd8:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    1bdd:      	movq	(%rip), %rsi            # 0x1be4 <event_execve+0x1be4>
    1be4:      	callq	*%rax
    1be6:      	testl	%eax, %eax
    1be8:      	jns	0x1bed <event_execve+0x1bed>
    1bea:      	movslq	%eax, %rbp
    1bed:      	testl	%ebp, %ebp
    1bef:      	js	0x1c56 <event_execve+0x1c56>
    1bf1:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    1bf7:      	addq	%rbp, %r13
    1bfa:      	cmpq	%r12, %r13
    1bfd:      	je	0x1c99 <event_execve+0x1c99>
    1c03:      	decl	%ebx
    1c05:      	jne	0x1b89 <event_execve+0x1b89>
    1c07:      	jmp	0x1ce2 <event_execve+0x1ce2>
    1c0c:      	movl	$0x1, 0x70(%rsp)
    1c14:      	movq	(%rip), %rdi            # 0x1c1b <event_execve+0x1c1b>
    1c1b:      	xorl	%ecx, %ecx
    1c1d:      	leaq	0x28(%rsp), %rsi
    1c22:      	leaq	0x70(%rsp), %rdx
    1c27:      	movl	$0x2, %eax
    1c2c:      	xorl	%ecx, %ecx
    1c2e:      	callq	*%rax
    1c30:      	movq	0x18(%rsp), %rbp
    1c35:      	testq	%rbp, %rbp
    1c38:      	jne	0x1a66 <event_execve+0x1a66>
    1c3e:      	jmp	0x1d50 <event_execve+0x1d50>
    1c43:      	xorl	%ecx, %ecx
    1c45:      	xorl	%r12d, %r12d
    1c48:      	jmp	0x1d41 <event_execve+0x1d41>
    1c4d:      	movq	$-0x1, %r13
    1c54:      	jmp	0x1c59 <event_execve+0x1c59>
    1c56:      	movq	%rbp, %r13
    1c59:      	movl	$0x0, 0x28(%rsp)
    1c61:      	movq	(%rip), %rdi            # 0x1c68 <event_execve+0x1c68>
    1c68:      	leaq	0x28(%rsp), %rsi
    1c6d:      	movl	$0x1, %eax
    1c72:      	callq	*%rax
    1c74:      	testq	%rax, %rax
    1c77:      	je	0x1ce2 <event_execve+0x1ce2>
    1c79:      	cmpq	$-0xc, %r13
    1c7d:      	jg	0x1c9e <event_execve+0x1c9e>
    1c7f:      	cmpq	$-0x1c, %r13
    1c83:      	je	0x1cb8 <event_execve+0x1cb8>
    1c85:      	cmpq	$-0x16, %r13
    1c89:      	je	0x1cd0 <event_execve+0x1cd0>
    1c8b:      	cmpq	$-0x10, %r13
    1c8f:      	jne	0x1cc8 <event_execve+0x1cc8>
    1c91:      	addq	$0x558, %rax            # imm = 0x558
    1c97:      	jmp	0x1cde <event_execve+0x1cde>
    1c99:      	movq	%r12, %r13
    1c9c:      	jmp	0x1ce2 <event_execve+0x1ce2>
    1c9e:      	cmpq	$-0xb, %r13
    1ca2:      	je	0x1cc0 <event_execve+0x1cc0>
    1ca4:      	cmpq	$-0x7, %r13
    1ca8:      	je	0x1cd8 <event_execve+0x1cd8>
    1caa:      	cmpq	$-0x2, %r13
    1cae:      	jne	0x1cc8 <event_execve+0x1cc8>
    1cb0:      	addq	$0x548, %rax            # imm = 0x548
    1cb6:      	jmp	0x1cde <event_execve+0x1cde>
    1cb8:      	addq	$0x568, %rax            # imm = 0x568
    1cbe:      	jmp	0x1cde <event_execve+0x1cde>
    1cc0:      	addq	$0x570, %rax            # imm = 0x570
    1cc6:      	jmp	0x1cde <event_execve+0x1cde>
    1cc8:      	addq	$0x540, %rax            # imm = 0x540
    1cce:      	jmp	0x1cde <event_execve+0x1cde>
    1cd0:      	addq	$0x560, %rax            # imm = 0x560
    1cd6:      	jmp	0x1cde <event_execve+0x1cde>
    1cd8:      	addq	$0x550, %rax            # imm = 0x550
    1cde:      	lock
    1cdf:      	incq	(%rax)
    1ce2:      	testl	%r13d, %r13d
    1ce5:      	js	0x1d0b <event_execve+0x1d0b>
    1ce7:      	movq	0x80(%rsp), %rdx
    1cef:      	movq	$0x0, 0x140(%rdx)
    1cfa:      	movl	%r12d, %ecx
    1cfd:      	subl	%r13d, %ecx
    1d00:      	xorl	%eax, %eax
    1d02:      	cmpq	$-0x1, %r12
    1d06:      	cmovnel	%ecx, %eax
    1d09:      	jmp	0x1d29 <event_execve+0x1d29>
    1d0b:      	movq	0x80(%rsp), %rdx
    1d13:      	movl	%r13d, 0x140(%rdx)
    1d1a:      	movl	$0x0, 0x144(%rdx)
    1d24:      	xorl	%eax, %eax
    1d26:      	xorl	%r13d, %r13d
    1d29:      	movl	%eax, 0x148(%rdx)
    1d2f:      	movl	%r13d, 0x14c(%rdx)
    1d36:      	movl	$0x20, %r12d
    1d3c:      	movl	$0x2, %ecx
    1d41:      	movw	%r12w, 0x17e(%r14)
    1d49:      	orl	%ecx, 0x15c(%r14)
    1d50:      	movl	0x140(%r14), %eax
    1d57:      	leal	(%rax,%r12), %ecx
    1d5b:      	movl	%ecx, 0x140(%r14)
    1d62:      	movw	$0x5, (%r14)
    1d68:      	movq	0x170(%r14), %rcx
    1d6f:      	movq	%rcx, 0x8(%r14)
    1d73:      	leal	0x140(%rax,%r12), %eax
    1d7b:      	movl	%eax, 0x4(%r14)
    1d7f:      	movq	0xa0(%rsp), %rbp
    1d87:      	leaq	0xd00(%rbp), %r12
    1d8e:      	leaq	0x28(%rsp), %rdi
    1d93:      	movl	$0x8, %ecx
    1d98:      	movl	$0x4, %eax
    1d9d:      	leaq	0xb8(%r14), %rbx
    1da4:      	movl	$0x4, %r13d
    1daa:      	movl	$0x8, %esi
    1daf:      	movq	%r12, %rdx
    1db2:      	callq	*%rax
    1db4:      	movq	0x28(%rsp), %rcx
    1db9:      	addq	$0x8, %rcx
    1dbd:      	movl	$0x4, %edx
    1dc2:      	movl	$0x4, %eax
    1dc7:      	movq	0x28(%rsp), %rdx
    1dcc:      	addq	$0x8, %rdx
    1dd0:      	movq	%rbx, %rdi
    1dd3:      	movl	$0x4, %esi
    1dd8:      	callq	*%rax
    1dda:      	leaq	0xbc(%r14), %rdi
    1de1:      	movq	0x28(%rsp), %rcx
    1de6:      	addq	$0xc, %rcx
    1dea:      	movl	$0x4, %edx
    1def:      	movl	$0x4, %eax
    1df4:      	movq	0x28(%rsp), %rdx
    1df9:      	addq	$0xc, %rdx
    1dfd:      	movl	$0x4, %esi
    1e02:      	callq	*%rax
    1e04:      	leaq	0xc8(%r14), %rdi
    1e0b:      	movq	0x28(%rsp), %rcx
    1e10:      	addq	$0x18, %rcx
    1e14:      	movl	$0x4, %edx
    1e19:      	movl	$0x4, %eax
    1e1e:      	movq	0x28(%rsp), %rdx
    1e23:      	addq	$0x18, %rdx
    1e27:      	movl	$0x4, %esi
    1e2c:      	callq	*%rax
    1e2e:      	leaq	0xcc(%r14), %rdi
    1e35:      	movq	0x28(%rsp), %rcx
    1e3a:      	addq	$0x1c, %rcx
    1e3e:      	movl	$0x4, %edx
    1e43:      	movl	$0x4, %eax
    1e48:      	movq	0x28(%rsp), %rdx
    1e4d:      	addq	$0x1c, %rdx
    1e51:      	movl	$0x4, %esi
    1e56:      	callq	*%rax
    1e58:      	leaq	0xc0(%r14), %rdi
    1e5f:      	movq	0x28(%rsp), %rcx
    1e64:      	addq	$0x10, %rcx
    1e68:      	movl	$0x4, %edx
    1e6d:      	movl	$0x4, %eax
    1e72:      	movq	0x28(%rsp), %rdx
    1e77:      	addq	$0x10, %rdx
    1e7b:      	movl	$0x4, %esi
    1e80:      	callq	*%rax
    1e82:      	leaq	0xc4(%r14), %rdi
    1e89:      	movq	0x28(%rsp), %rcx
    1e8e:      	addq	$0x14, %rcx
    1e92:      	movl	$0x4, %edx
    1e97:      	movl	$0x4, %eax
    1e9c:      	movq	0x28(%rsp), %rdx
    1ea1:      	addq	$0x14, %rdx
    1ea5:      	movl	$0x4, %esi
    1eaa:      	callq	*%rax
    1eac:      	leaq	0xd0(%r14), %rdi
    1eb3:      	movq	0x28(%rsp), %rcx
    1eb8:      	addq	$0x20, %rcx
    1ebc:      	movl	$0x4, %edx
    1ec1:      	movl	$0x4, %eax
    1ec6:      	movq	0x28(%rsp), %rdx
    1ecb:      	addq	$0x20, %rdx
    1ecf:      	movl	$0x4, %esi
    1ed4:      	callq	*%rax
    1ed6:      	leaq	0xd4(%r14), %rdi
    1edd:      	movq	0x28(%rsp), %rcx
    1ee2:      	addq	$0x24, %rcx
    1ee6:      	movl	$0x4, %edx
    1eeb:      	movl	$0x4, %eax
    1ef0:      	movq	0x28(%rsp), %rdx
    1ef5:      	addq	$0x24, %rdx
    1ef9:      	movl	$0x4, %esi
    1efe:      	callq	*%rax
    1f00:      	leaq	0xd8(%r14), %rdi
    1f07:      	movq	0x28(%rsp), %rcx
    1f0c:      	addq	$0x28, %rcx
    1f10:      	movl	$0x4, %edx
    1f15:      	movl	$0x4, %eax
    1f1a:      	movq	0x28(%rsp), %rdx
    1f1f:      	addq	$0x28, %rdx
    1f23:      	movl	$0x4, %esi
    1f28:      	callq	*%rax
    1f2a:      	movq	0x28(%rsp), %rbx
    1f2f:      	leaq	0xe8(%r14), %rdi
    1f36:      	leaq	0x40(%rbx), %rdx
    1f3a:      	movl	$0x8, %ecx
    1f3f:      	movl	$0x4, %eax
    1f44:      	leaq	0xe0(%r14), %r15
    1f4b:      	movl	$0x8, %esi
    1f50:      	callq	*%rax
    1f52:      	leaq	0xf0(%r14), %rdi
    1f59:      	leaq	0x30(%rbx), %rdx
    1f5d:      	movl	$0x8, %ecx
    1f62:      	movl	$0x4, %eax
    1f67:      	movl	$0x8, %esi
    1f6c:      	callq	*%rax
    1f6e:      	addq	$0x38, %rbx
    1f72:      	movl	$0x8, %ecx
    1f77:      	movl	$0x4, %eax
    1f7c:      	movq	%r15, %rdi
    1f7f:      	movl	$0x8, %esi
    1f84:      	movq	%rbx, %rdx
    1f87:      	callq	*%rax
    1f89:      	movl	0xc8(%r14), %eax
    1f90:      	movl	%eax, 0x154(%r14)
    1f97:      	leaq	0xd70(%rbp), %rdx
    1f9e:      	leaq	0x18(%rsp), %rdi
    1fa3:      	movl	$0x8, %ecx
    1fa8:      	movl	$0x4, %eax
    1fad:      	leaq	0x108(%r14), %rbx
    1fb4:      	movl	$0x8, %esi
    1fb9:      	callq	*%rax
    1fbb:      	movq	0x18(%rsp), %rcx
    1fc0:      	leaq	0x28(%rsp), %rdi
    1fc5:      	movl	$0x48, %edx
    1fca:      	movl	$0x4, %eax
    1fcf:      	movq	0x18(%rsp), %rdx
    1fd4:      	movl	$0x48, %esi
    1fd9:      	callq	*%rax
    1fdb:      	movl	$0x218, %edx            # imm = 0x218
    1fe0:      	movq	0x30(%rsp), %rcx
    1fe5:      	addq	%rdx, %rcx
    1fe8:      	movl	$0x4, %esi
    1fed:      	movl	$0x4, %eax
    1ff2:      	addq	0x30(%rsp), %rdx
    1ff7:      	movq	%rbx, %rdi
    1ffa:      	movl	$0x4, %esi
    1fff:      	callq	*%rax
    2001:      	leaq	0x10c(%r14), %rdi
    2008:      	movl	$0x4d8, %edx            # imm = 0x4D8
    200d:      	movq	0x38(%rsp), %rcx
    2012:      	addq	%rdx, %rcx
    2015:      	movl	$0x4, %esi
    201a:      	movl	$0x4, %eax
    201f:      	addq	0x38(%rsp), %rdx
    2024:      	movl	$0x4, %esi
    2029:      	callq	*%rax
    202b:      	leaq	0x110(%r14), %rdi
    2032:      	movq	0x40(%rsp), %rcx
    2037:      	addq	$0x58, %rcx
    203b:      	movl	$0x4, %edx
    2040:      	movl	$0x4, %eax
    2045:      	movq	0x40(%rsp), %rdx
    204a:      	addq	$0x58, %rdx
    204e:      	movl	$0x4, %esi
    2053:      	callq	*%rax
    2055:      	movq	$0x0, 0x20(%rsp)
    205e:      	leaq	0xb58(%rbp), %rdx
    2065:      	leaq	0x20(%rsp), %rdi
    206a:      	movl	$0x8, %ecx
    206f:      	movl	$0x4, %eax
    2074:      	movl	$0x8, %esi
    2079:      	callq	*%rax
    207b:      	movq	0x20(%rsp), %rcx
    2080:      	testq	%rcx, %rcx
    2083:      	je	0x211a <event_execve+0x211a>
    2089:      	movl	$0x0, 0x70(%rsp)
    2091:      	addq	$0x4, %rcx
    2095:      	leaq	0x70(%rsp), %rdi
    209a:      	movl	$0x4, %eax
    209f:      	movq	0x20(%rsp), %rdx
    20a4:      	addq	$0x4, %rdx
    20a8:      	movl	$0x4, %esi
    20ad:      	callq	*%rax
    20af:      	movq	0x20(%rsp), %rax
    20b4:      	movslq	0x70(%rsp), %rcx
    20b9:      	shlq	$0x4, %rcx
    20bd:      	addq	%rax, %rcx
    20c0:      	addq	$0x80, %rcx
    20c7:      	movq	%rsp, %rdi
    20ca:      	movl	$0x10, %edx
    20cf:      	movl	$0x4, %eax
    20d4:      	movq	0x20(%rsp), %rcx
    20d9:      	movslq	0x70(%rsp), %rdx
    20de:      	shlq	$0x4, %rdx
    20e2:      	addq	%rcx, %rdx
    20e5:      	addq	$0x80, %rdx
    20ec:      	movl	$0x10, %esi
    20f1:      	callq	*%rax
    20f3:      	leaq	0x114(%r14), %rdi
    20fa:      	movl	$0x158, %edx            # imm = 0x158
    20ff:      	movq	0x8(%rsp), %rcx
    2104:      	addq	%rdx, %rcx
    2107:      	movl	$0x4, %eax
    210c:      	addq	0x8(%rsp), %rdx
    2111:      	movl	$0x4, %esi
    2116:      	callq	*%rax
    2118:      	jmp	0x2125 <event_execve+0x2125>
    211a:      	movl	$0x0, 0x114(%r14)
    2125:      	leaq	0x118(%r14), %rdi
    212c:      	movl	$0x158, %ebx            # imm = 0x158
    2131:      	movq	0x48(%rsp), %rcx
    2136:      	addq	%rbx, %rcx
    2139:      	movl	$0x4, %edx
    213e:      	movl	$0x4, %eax
    2143:      	movq	0x48(%rsp), %rdx
    2148:      	addq	%rbx, %rdx
    214b:      	movl	$0x4, %esi
    2150:      	callq	*%rax
    2152:      	leaq	0x11c(%r14), %rdi
    2159:      	movl	$0x118, %edx            # imm = 0x118
    215e:      	movq	0x50(%rsp), %rcx
    2163:      	addq	%rdx, %rcx
    2166:      	movl	$0x4, %esi
    216b:      	movl	$0x4, %eax
    2170:      	addq	0x50(%rsp), %rdx
    2175:      	movl	$0x4, %esi
    217a:      	callq	*%rax
    217c:      	leaq	0x120(%r14), %rdi
    2183:      	movl	$0x98, %r15d
    2189:      	movq	0x58(%rsp), %rcx
    218e:      	addq	%r15, %rcx
    2191:      	movl	$0x4, %edx
    2196:      	movl	$0x4, %eax
    219b:      	movq	0x58(%rsp), %rdx
    21a0:      	addq	%r15, %rdx
    21a3:      	movl	$0x4, %esi
    21a8:      	callq	*%rax
    21aa:      	leaq	0x124(%r14), %rdi
    21b1:      	movq	0x60(%rsp), %rcx
    21b6:      	addq	%r15, %rcx
    21b9:      	movl	$0x4, %edx
    21be:      	movl	$0x4, %eax
    21c3:      	addq	0x60(%rsp), %r15
    21c8:      	movl	$0x4, %esi
    21cd:      	movq	%r15, %rdx
    21d0:      	callq	*%rax
    21d2:      	leaq	0x128(%r14), %rdi
    21d9:      	movq	0x68(%rsp), %rcx
    21de:      	addq	$0x58, %rcx
    21e2:      	movl	$0x4, %edx
    21e7:      	movl	$0x4, %eax
    21ec:      	movq	0x68(%rsp), %rdx
    21f1:      	addq	$0x58, %rdx
    21f5:      	movl	$0x4, %esi
    21fa:      	callq	*%rax
    21fc:      	movq	$0x0, (%rsp)
    2204:      	movq	$0x0, 0x20(%rsp)
    220d:      	movq	%rsp, %rdi
    2210:      	movl	$0x8, %ecx
    2215:      	movl	$0x4, %eax
    221a:      	movl	$0x8, %esi
    221f:      	movq	%r12, %rdx
    2222:      	callq	*%rax
    2224:      	movl	$0x90, %edx
    2229:      	movq	(%rsp), %rcx
    222d:      	addq	%rdx, %rcx
    2230:      	leaq	0x20(%rsp), %rdi
    2235:      	movl	$0x8, %esi
    223a:      	movl	$0x4, %eax
    223f:      	addq	(%rsp), %rdx
    2243:      	movl	$0x8, %esi
    2248:      	callq	*%rax
    224a:      	leaq	0x12c(%r14), %rdi
    2251:      	movq	0x20(%rsp), %rcx
    2256:      	addq	%rbx, %rcx
    2259:      	movl	$0x4, %edx
    225e:      	movl	$0x4, %eax
    2263:      	addq	0x20(%rsp), %rbx
    2268:      	movl	$0x4, %esi
    226d:      	movq	%rbx, %rdx
    2270:      	callq	*%rax
    2272:      	leaq	0x10(%r14), %r12
    2276:      	movl	$0x0, 0x20(%rsp)
    227e:      	xorl	%ebx, %ebx
    2280:      	movl	$0x90, %edx
    2285:      	movq	%r12, %rdi
    2288:      	xorl	%esi, %esi
    228a:      	callq	0x228f <event_execve+0x228f>
    228f:      	movq	(%rip), %rdi            # 0x2296 <event_execve+0x2296>
    2296:      	leaq	0x20(%rsp), %rsi
    229b:      	movl	$0x1, %eax
    22a0:      	callq	*%rax
    22a2:      	testq	%rax, %rax
    22a5:      	je	0x22b8 <event_execve+0x22b8>
    22a7:      	movl	0x10(%rax), %ebx
    22aa:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
    22b2:      	sete	%bpl
    22b6:      	jmp	0x22ba <event_execve+0x22ba>
    22b8:      	xorl	%ebp, %ebp
    22ba:      	movq	0x10(%rsp), %r15
    22bf:      	movq	$0x0, 0x18(%rsp)
    22c8:      	movq	0xa0(%rsp), %rdx
    22d0:      	addq	$0xf90, %rdx            # imm = 0xF90
    22d7:      	movq	%rsp, %rdi
    22da:      	movl	$0x8, %ecx
    22df:      	movl	$0x71, %eax
    22e4:      	movl	$0x8, %esi
    22e9:      	callq	*%rax
    22eb:      	movq	(%rsp), %rcx
    22ef:      	testq	%rcx, %rcx
    22f2:      	je	0x24ee <event_execve+0x24ee>
    22f8:      	testb	%bpl, %bpl
    22fb:      	je	0x2374 <event_execve+0x2374>
    22fd:      	addq	$0x88, %rcx
    2304:      	leaq	0x18(%rsp), %rdi
    2309:      	movl	$0x8, %edx
    230e:      	movl	$0x71, %eax
    2313:      	movl	$0x88, %edx
    2318:      	addq	(%rsp), %rdx
    231c:      	movl	$0x8, %esi
    2321:      	callq	*%rax
    2323:      	movq	0x18(%rsp), %rbx
    2328:      	testq	%rbx, %rbx
    232b:      	je	0x24ee <event_execve+0x24ee>
    2331:      	movl	$0x50, %eax
    2336:      	callq	*%rax
    2338:      	xorl	%ebp, %ebp
    233a:      	movq	%rax, (%r12)
    233e:      	testq	%rax, %rax
    2341:      	je	0x2443 <event_execve+0x2443>
    2347:      	movq	%rax, 0x28(%rsp)
    234c:      	movq	(%rip), %rdi            # 0x2353 <event_execve+0x2353>
    2353:      	leaq	0x28(%rsp), %rsi
    2358:      	movl	$0x1, %eax
    235d:      	callq	*%rax
    235f:      	testq	%rax, %rax
    2362:      	je	0x244b <event_execve+0x244b>
    2368:      	movq	(%rax), %rax
    236b:      	movq	%rax, 0x18(%r14)
    236f:      	jmp	0x2451 <event_execve+0x2451>
    2374:      	cmpl	$0xb, %ebx
    2377:      	ja	0x24ee <event_execve+0x24ee>
    237d:      	movl	%ebx, %edx
    237f:      	leaq	(%rcx,%rdx,8), %rcx
    2383:      	leaq	0x28(%rsp), %rdi
    2388:      	movl	$0x8, %esi
    238d:      	movl	$0x71, %eax
    2392:      	shlq	$0x3, %rdx
    2396:      	addq	(%rsp), %rdx
    239a:      	movl	$0x8, %esi
    239f:      	callq	*%rax
    23a1:      	movq	0x28(%rsp), %rcx
    23a6:      	testq	%rcx, %rcx
    23a9:      	je	0x24db <event_execve+0x24db>
    23af:      	leaq	0x18(%rsp), %rdi
    23b4:      	movl	$0x8, %edx
    23b9:      	movl	$0x71, %eax
    23be:      	movq	0x28(%rsp), %rdx
    23c3:      	movl	$0x8, %esi
    23c8:      	callq	*%rax
    23ca:      	movq	0x18(%rsp), %rbx
    23cf:      	testq	%rbx, %rbx
    23d2:      	je	0x24ee <event_execve+0x24ee>
    23d8:      	xorl	%ebp, %ebp
    23da:      	movq	$0x0, 0x28(%rsp)
    23e3:      	leaq	0x100(%rbx), %rdx
    23ea:      	leaq	0x28(%rsp), %rdi
    23ef:      	movl	$0x8, %ecx
    23f4:      	movl	$0x71, %eax
    23f9:      	movl	$0x8, %esi
    23fe:      	callq	*%rax
    2400:      	movq	0x28(%rsp), %rdx
    2405:      	movq	$0x0, 0x28(%rsp)
    240e:      	testq	%rdx, %rdx
    2411:      	je	0x24c7 <event_execve+0x24c7>
    2417:      	addq	$0x60, %rdx
    241b:      	leaq	0x28(%rsp), %rdi
    2420:      	movl	$0x8, %ecx
    2425:      	movl	$0x71, %eax
    242a:      	movl	$0x8, %esi
    242f:      	callq	*%rax
    2431:      	movq	0x28(%rsp), %rax
    2436:      	movq	%rax, (%r12)
    243a:      	testq	%rax, %rax
    243d:      	jne	0x2347 <event_execve+0x2347>
    2443:      	orl	$0x200000, %ebp         # imm = 0x200000
    2449:      	jmp	0x2451 <event_execve+0x2451>
    244b:      	xorl	%eax, %eax
    244d:      	movq	%rax, 0x18(%r14)
    2451:      	addq	$0x100, %rbx            # imm = 0x100
    2458:      	movq	%rsp, %rdi
    245b:      	movl	$0x8, %ecx
    2460:      	movl	$0x4, %eax
    2465:      	movl	$0x8, %esi
    246a:      	movq	%rbx, %rdx
    246d:      	callq	*%rax
    246f:      	movq	(%rsp), %rcx
    2473:      	addq	$0x10, %rcx
    2477:      	leaq	0x28(%rsp), %rdi
    247c:      	movl	$0x8, %edx
    2481:      	movl	$0x4, %eax
    2486:      	movq	(%rsp), %rdx
    248a:      	addq	$0x10, %rdx
    248e:      	movl	$0x8, %esi
    2493:      	callq	*%rax
    2495:      	movl	$0x10000, %ecx          # imm = 0x10000
    249a:      	testq	%rax, %rax
    249d:      	jne	0x24c3 <event_execve+0x24c3>
    249f:      	movq	0x28(%rsp), %rdx
    24a4:      	testq	%rdx, %rdx
    24a7:      	je	0x24c3 <event_execve+0x24c3>
    24a9:      	movq	%r14, %rdi
    24ac:      	addq	$0x20, %rdi
    24b0:      	movl	$0x80, %ecx
    24b5:      	movl	$0x2d, %eax
    24ba:      	movl	$0x80, %esi
    24bf:      	callq	*%rax
    24c1:      	xorl	%ecx, %ecx
    24c3:      	orl	%ebp, %ecx
    24c5:      	jmp	0x24f0 <event_execve+0x24f0>
    24c7:      	xorl	%eax, %eax
    24c9:      	movq	%rax, (%r12)
    24cd:      	testq	%rax, %rax
    24d0:      	jne	0x2347 <event_execve+0x2347>
    24d6:      	jmp	0x2443 <event_execve+0x2443>
    24db:      	movq	0x18(%rsp), %rbx
    24e0:      	movl	$0x80000, %ebp          # imm = 0x80000
    24e5:      	testq	%rbx, %rbx
    24e8:      	jne	0x23da <event_execve+0x23da>
    24ee:      	xorl	%ecx, %ecx
    24f0:      	orl	%ecx, 0x15c(%r14)
    24f7:      	movq	$0x0, 0x130(%r14)
    2502:      	movq	$0x0, 0x138(%r14)
    250d:      	movq	(%rip), %rsi            # 0x2514 <event_execve+0x2514>
    2514:      	xorl	%ecx, %ecx
    2516:      	movl	$0xc, %eax
    251b:      	movq	%r15, %rdi
    251e:      	xorl	%edx, %edx
    2520:      	callq	*%rax
    2522:      	xorl	%eax, %eax
    2524:      	addq	$0xc8, %rsp
    252b:      	popq	%rbx
    252c:      	popq	%r12
    252e:      	popq	%r13
    2530:      	popq	%r14
    2532:      	popq	%r15
    2534:      	popq	%rbp
    2535:      	retq
    2536:      	xorl	%r13d, %r13d
    2539:      	movq	0x10(%rsp), %r15
    253e:      	jmp	0x146e <event_execve+0x146e>
