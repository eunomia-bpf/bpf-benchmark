
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/vfsstat.native.o:	file format elf64-x86-64

Disassembly of section kprobe/vfs_read:

0000000000000000 <kprobe_vfs_read>:
       0:      	movq	(%rip), %rax            # 0x7 <kprobe_vfs_read+0x7>
       7:      	lock
       8:      	incq	(%rax)
       b:      	xorl	%eax, %eax
       d:      	retq

Disassembly of section kprobe/vfs_write:

0000000000000000 <kprobe_vfs_write>:
       0:      	movq	(%rip), %rax            # 0x7 <kprobe_vfs_write+0x7>
       7:      	lock
       8:      	incq	0x8(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section kprobe/vfs_fsync:

0000000000000000 <kprobe_vfs_fsync>:
       0:      	movq	(%rip), %rax            # 0x7 <kprobe_vfs_fsync+0x7>
       7:      	lock
       8:      	incq	0x10(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section kprobe/vfs_open:

0000000000000000 <kprobe_vfs_open>:
       0:      	movq	(%rip), %rax            # 0x7 <kprobe_vfs_open+0x7>
       7:      	lock
       8:      	incq	0x18(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section kprobe/vfs_create:

0000000000000000 <kprobe_vfs_create>:
       0:      	movq	(%rip), %rax            # 0x7 <kprobe_vfs_create+0x7>
       7:      	lock
       8:      	incq	0x20(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section fentry/vfs_read:

0000000000000000 <fentry_vfs_read>:
       0:      	movq	(%rip), %rax            # 0x7 <fentry_vfs_read+0x7>
       7:      	lock
       8:      	incq	(%rax)
       b:      	xorl	%eax, %eax
       d:      	retq

Disassembly of section fentry/vfs_write:

0000000000000000 <fentry_vfs_write>:
       0:      	movq	(%rip), %rax            # 0x7 <fentry_vfs_write+0x7>
       7:      	lock
       8:      	incq	0x8(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section fentry/vfs_fsync:

0000000000000000 <fentry_vfs_fsync>:
       0:      	movq	(%rip), %rax            # 0x7 <fentry_vfs_fsync+0x7>
       7:      	lock
       8:      	incq	0x10(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section fentry/vfs_open:

0000000000000000 <fentry_vfs_open>:
       0:      	movq	(%rip), %rax            # 0x7 <fentry_vfs_open+0x7>
       7:      	lock
       8:      	incq	0x18(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq

Disassembly of section fentry/vfs_create:

0000000000000000 <fentry_vfs_create>:
       0:      	movq	(%rip), %rax            # 0x7 <fentry_vfs_create+0x7>
       7:      	lock
       8:      	incq	0x20(%rax)
       c:      	xorl	%eax, %eax
       e:      	retq
