
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_rawtp_v53.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section raw_tp:

0000000000000000 <generic_rawtp_setup_event>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	str	wzr, [sp, #0x1c]
      18:      	adrp	x20, 0x0 <generic_rawtp_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x1c
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x1c
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x1a8 <generic_rawtp_setup_event+0x1a8>
      3c:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x1a8 <generic_rawtp_setup_event+0x1a8>
      60:      	mov	w24, #0x8               // =8
      64:      	add	x8, sp, #0x8
      68:      	mov	w9, #0x4                // =4
      6c:      	add	x0, sp, #0x8
      70:      	mov	w1, #0x8                // =8
      74:      	mov	x2, x19
      78:      	mov	w23, #0x4               // =4
      7c:      	blr	x9
      80:      	ldr	x8, [sp, #0x8]
      84:      	add	x2, x19, #0x8
      88:      	mov	w9, #0x4                // =4
      8c:      	add	x0, sp, #0x8
      90:      	str	x8, [x22, #0x5e50]
      94:      	add	x8, sp, #0x8
      98:      	mov	w1, #0x8                // =8
      9c:      	blr	x9
      a0:      	ldr	x8, [sp, #0x8]
      a4:      	add	x2, x19, #0x10
      a8:      	mov	w9, #0x4                // =4
      ac:      	add	x0, sp, #0x8
      b0:      	str	x8, [x22, #0x5e58]
      b4:      	add	x8, sp, #0x8
      b8:      	mov	w1, #0x8                // =8
      bc:      	blr	x9
      c0:      	ldr	x8, [sp, #0x8]
      c4:      	add	x2, x19, #0x18
      c8:      	mov	w9, #0x4                // =4
      cc:      	add	x0, sp, #0x8
      d0:      	str	x8, [x22, #0x5e60]
      d4:      	add	x8, sp, #0x8
      d8:      	mov	w1, #0x8                // =8
      dc:      	blr	x9
      e0:      	ldr	x8, [sp, #0x8]
      e4:      	add	x2, x19, #0x20
      e8:      	add	x0, sp, #0x8
      ec:      	mov	w1, #0x8                // =8
      f0:      	str	x8, [x22, #0x5e68]
      f4:      	add	x8, sp, #0x8
      f8:      	blr	x23
      fc:      	ldr	x8, [sp, #0x8]
     100:      	mov	w23, #0xe               // =14
     104:      	strh	wzr, [x22, #0x2]
     108:      	str	wzr, [x22, #0x4]
     10c:      	strb	w23, [x22]
     110:      	str	x8, [x22, #0x5e70]
     114:      	mov	w8, #0x7d               // =125
     118:      	blr	x8
     11c:      	str	x0, [x22, #0x8]
     120:      	str	xzr, [x22, #0x70]
     124:      	str	wzr, [x22, #0x14]
     128:      	blr	x23
     12c:      	str	w0, [x22, #0x7c]
     130:      	str	wzr, [sp, #0x8]
     134:      	mov	w8, #0x1                // =1
     138:      	add	x9, sp, #0x8
     13c:      	add	x1, sp, #0x8
     140:      	mov	x0, x20
     144:      	blr	x8
     148:      	adrp	x20, 0x0 <generic_rawtp_setup_event>
     14c:      	ldr	x20, [x20]
     150:      	cbz	x0, 0x178 <generic_rawtp_setup_event+0x178>
     154:      	mov	w8, #0x5ef8             // =24312
     158:      	add	x1, x0, x8
     15c:      	mov	w8, #0x1                // =1
     160:      	mov	x0, x21
     164:      	blr	x8
     168:      	cbz	x0, 0x178 <generic_rawtp_setup_event+0x178>
     16c:      	ldr	w8, [x0, #0x40]
     170:      	cmn	w8, #0x1
     174:      	b.ne	0x190 <generic_rawtp_setup_event+0x190>
     178:      	mov	w8, #0x3                // =3
     17c:      	mov	w9, #0xc                // =12
     180:      	mov	x0, x19
     184:      	mov	x1, x20
     188:      	mov	w2, #0x3                // =3
     18c:      	blr	x9
     190:      	mov	w8, #0x1                // =1
     194:      	mov	w9, #0xc                // =12
     198:      	mov	x0, x19
     19c:      	mov	x1, x20
     1a0:      	mov	w2, #0x1                // =1
     1a4:      	blr	x9
     1a8:      	ldp	x20, x19, [sp, #0x40]
     1ac:      	mov	w0, wzr
     1b0:      	ldr	x30, [sp, #0x10]
     1b4:      	ldp	x22, x21, [sp, #0x30]
     1b8:      	ldp	x24, x23, [sp, #0x20]
     1bc:      	add	sp, sp, #0x50
     1c0:      	ret
     1c4:      	nop
     1c8:      	nop
     1cc:      	nop

00000000000001d0 <generic_rawtp_process_event>:
     1d0:      	sub	sp, sp, #0x150
     1d4:      	str	x29, [sp, #0x100]
     1d8:      	stp	x30, x25, [sp, #0x110]
     1dc:      	stp	x24, x23, [sp, #0x120]
     1e0:      	stp	x22, x21, [sp, #0x130]
     1e4:      	stp	x20, x19, [sp, #0x140]
     1e8:      	str	wzr, [sp, #0x5c]
     1ec:      	adrp	x22, 0x0 <generic_rawtp_setup_event>
     1f0:      	mov	w8, #0x1                // =1
     1f4:      	add	x9, sp, #0x5c
     1f8:      	ldr	x22, [x22]
     1fc:      	mov	x19, x0
     200:      	add	x1, sp, #0x5c
     204:      	mov	x0, x22
     208:      	blr	x8
     20c:      	cbz	x0, 0xa6c <generic_rawtp_process_event+0x89c>
     210:      	ldr	w24, [x0, #0x4]
     214:      	mov	w29, #0x5efc            // =24316
     218:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     21c:      	mov	x20, x0
     220:      	ldr	w21, [x0, x29]
     224:      	ldr	x25, [x25]
     228:      	lsr	w8, w24, #3
     22c:      	cmp	w8, #0x464
     230:      	b.hi	0x9d8 <generic_rawtp_process_event+0x808>
     234:      	str	wzr, [sp, #0x68]
     238:      	mov	w8, #0x1                // =1
     23c:      	add	x9, sp, #0x68
     240:      	add	x1, sp, #0x68
     244:      	mov	x0, x22
     248:      	blr	x8
     24c:      	cbz	x0, 0x9d8 <generic_rawtp_process_event+0x808>
     250:      	mov	w8, #0x5ef8             // =24312
     254:      	mov	x23, x0
     258:      	add	x1, x0, x8
     25c:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     260:      	mov	w8, #0x1                // =1
     264:      	ldr	x0, [x0]
     268:      	blr	x8
     26c:      	cmp	w21, #0x4
     270:      	ccmp	x0, #0x0, #0x4, le
     274:      	b.eq	0x9d8 <generic_rawtp_process_event+0x808>
     278:      	and	x29, x21, #0x7
     27c:      	str	x21, [sp, #0x50]
     280:      	str	x24, [sp, #0x108]
     284:      	add	x8, x0, x29, lsl #2
     288:      	add	x25, x23, x29, lsl #2
     28c:      	ldrsw	x21, [x8, #0x18]
     290:      	ldr	w24, [x8, #0x4]
     294:      	mov	w8, #0x5ea0             // =24224
     298:      	str	wzr, [x25, x8]
     29c:      	and	x10, x21, #0xffffffff
     2a0:      	tbnz	w21, #0x8, 0x2c4 <generic_rawtp_process_event+0xf4>
     2a4:      	tbnz	w21, #0x7, 0x2cc <generic_rawtp_process_event+0xfc>
     2a8:      	tbnz	w10, #0x6, 0x2d8 <generic_rawtp_process_event+0x108>
     2ac:      	add	x8, x0, x29, lsl #2
     2b0:      	ldr	w8, [x8, #0x40]
     2b4:      	and	x8, x8, #0x7
     2b8:      	add	x8, x23, x8, lsl #3
     2bc:      	ldr	x8, [x8, #0x5e50]
     2c0:      	b	0x2fc <generic_rawtp_process_event+0x12c>
     2c4:      	str	xzr, [sp, #0x60]
     2c8:      	b	0x678 <generic_rawtp_process_event+0x4a8>
     2cc:      	mov	x8, xzr
     2d0:      	str	xzr, [sp, #0x60]
     2d4:      	b	0x300 <generic_rawtp_process_event+0x130>
     2d8:      	mov	w8, #0x23               // =35
     2dc:      	mov	x23, x0
     2e0:      	mov	x22, x10
     2e4:      	blr	x8
     2e8:      	mov	x10, x22
     2ec:      	adrp	x22, 0x0 <generic_rawtp_setup_event>
     2f0:      	mov	x8, x0
     2f4:      	ldr	x22, [x22]
     2f8:      	mov	x0, x23
     2fc:      	str	x8, [sp, #0x60]
     300:      	cmp	w29, #0x4
     304:      	b.hi	0x678 <generic_rawtp_process_event+0x4a8>
     308:      	mov	w9, #0x50               // =80
     30c:      	umaddl	x11, w29, w9, x0
     310:      	ldrh	w9, [x11, #0x76]
     314:      	cbz	w9, 0x678 <generic_rawtp_process_event+0x4a8>
     318:      	ldur	w9, [x11, #0x70]
     31c:      	str	x11, [sp, #0x48]
     320:      	add	x8, x8, x9
     324:      	str	x8, [sp, #0x60]
     328:      	ldurh	w9, [x11, #0x74]
     32c:      	cbz	w9, 0x36c <generic_rawtp_process_event+0x19c>
     330:      	mov	w9, #0x8                // =8
     334:      	mov	x23, x21
     338:      	mov	x21, x22
     33c:      	mov	x22, x10
     340:      	mov	w10, #0x4               // =4
     344:      	add	x11, sp, #0x60
     348:      	ldr	x2, [sp, #0x60]
     34c:      	add	x0, sp, #0x60
     350:      	mov	w1, #0x8                // =8
     354:      	blr	x10
     358:      	ldr	x11, [sp, #0x48]
     35c:      	mov	x10, x22
     360:      	mov	x22, x21
     364:      	mov	x21, x23
     368:      	tbnz	w0, #0x1f, 0x65c <generic_rawtp_process_event+0x48c>
     36c:      	ldurh	w8, [x11, #0x7e]
     370:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     374:      	ldr	x8, [sp, #0x60]
     378:      	ldur	w9, [x11, #0x78]
     37c:      	add	x8, x8, x9
     380:      	str	x8, [sp, #0x60]
     384:      	ldurh	w9, [x11, #0x7c]
     388:      	cbz	w9, 0x3c8 <generic_rawtp_process_event+0x1f8>
     38c:      	mov	w9, #0x8                // =8
     390:      	mov	x23, x21
     394:      	mov	x21, x22
     398:      	mov	x22, x10
     39c:      	mov	w10, #0x4               // =4
     3a0:      	add	x11, sp, #0x60
     3a4:      	ldr	x2, [sp, #0x60]
     3a8:      	add	x0, sp, #0x60
     3ac:      	mov	w1, #0x8                // =8
     3b0:      	blr	x10
     3b4:      	ldr	x11, [sp, #0x48]
     3b8:      	mov	x10, x22
     3bc:      	mov	x22, x21
     3c0:      	mov	x21, x23
     3c4:      	tbnz	w0, #0x1f, 0x664 <generic_rawtp_process_event+0x494>
     3c8:      	ldurh	w8, [x11, #0x86]
     3cc:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	ldur	w9, [x11, #0x80]
     3d8:      	add	x8, x8, x9
     3dc:      	str	x8, [sp, #0x60]
     3e0:      	ldurh	w9, [x11, #0x84]
     3e4:      	cbz	w9, 0x424 <generic_rawtp_process_event+0x254>
     3e8:      	mov	w9, #0x8                // =8
     3ec:      	mov	x23, x21
     3f0:      	mov	x21, x22
     3f4:      	mov	x22, x10
     3f8:      	mov	w10, #0x4               // =4
     3fc:      	add	x11, sp, #0x60
     400:      	ldr	x2, [sp, #0x60]
     404:      	add	x0, sp, #0x60
     408:      	mov	w1, #0x8                // =8
     40c:      	blr	x10
     410:      	ldr	x11, [sp, #0x48]
     414:      	mov	x10, x22
     418:      	mov	x22, x21
     41c:      	mov	x21, x23
     420:      	tbnz	w0, #0x1f, 0x66c <generic_rawtp_process_event+0x49c>
     424:      	ldurh	w8, [x11, #0x8e]
     428:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     42c:      	ldr	x8, [sp, #0x60]
     430:      	ldur	w9, [x11, #0x88]
     434:      	add	x8, x8, x9
     438:      	str	x8, [sp, #0x60]
     43c:      	ldurh	w9, [x11, #0x8c]
     440:      	cbz	w9, 0x484 <generic_rawtp_process_event+0x2b4>
     444:      	mov	w9, #0x8                // =8
     448:      	mov	x23, x21
     44c:      	mov	x21, x22
     450:      	mov	x22, x10
     454:      	add	x10, sp, #0x60
     458:      	mov	w11, #0x4               // =4
     45c:      	ldr	x2, [sp, #0x60]
     460:      	add	x0, sp, #0x60
     464:      	mov	w1, #0x8                // =8
     468:      	blr	x11
     46c:      	ldr	x11, [sp, #0x48]
     470:      	mov	w9, #0x4                // =4
     474:      	mov	x10, x22
     478:      	mov	x22, x21
     47c:      	mov	x21, x23
     480:      	tbnz	w0, #0x1f, 0x670 <generic_rawtp_process_event+0x4a0>
     484:      	ldurh	w8, [x11, #0x96]
     488:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     48c:      	ldr	x8, [sp, #0x60]
     490:      	ldur	w9, [x11, #0x90]
     494:      	add	x8, x8, x9
     498:      	str	x8, [sp, #0x60]
     49c:      	ldurh	w9, [x11, #0x94]
     4a0:      	cbz	w9, 0x4e0 <generic_rawtp_process_event+0x310>
     4a4:      	mov	w9, #0x8                // =8
     4a8:      	mov	x23, x21
     4ac:      	mov	x21, x22
     4b0:      	mov	x22, x10
     4b4:      	mov	w10, #0x4               // =4
     4b8:      	add	x11, sp, #0x60
     4bc:      	ldr	x2, [sp, #0x60]
     4c0:      	add	x0, sp, #0x60
     4c4:      	mov	w1, #0x8                // =8
     4c8:      	blr	x10
     4cc:      	ldr	x11, [sp, #0x48]
     4d0:      	mov	x10, x22
     4d4:      	mov	x22, x21
     4d8:      	mov	x21, x23
     4dc:      	tbnz	w0, #0x1f, 0x1370 <generic_rawtp_process_event+0x11a0>
     4e0:      	ldurh	w8, [x11, #0x9e]
     4e4:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     4e8:      	ldr	x8, [sp, #0x60]
     4ec:      	ldur	w9, [x11, #0x98]
     4f0:      	add	x8, x8, x9
     4f4:      	str	x8, [sp, #0x60]
     4f8:      	ldurh	w9, [x11, #0x9c]
     4fc:      	cbz	w9, 0x538 <generic_rawtp_process_event+0x368>
     500:      	mov	w9, #0x8                // =8
     504:      	mov	x23, x21
     508:      	mov	x21, x22
     50c:      	mov	x22, x10
     510:      	mov	w10, #0x4               // =4
     514:      	add	x11, sp, #0x60
     518:      	ldr	x2, [sp, #0x60]
     51c:      	add	x0, sp, #0x60
     520:      	mov	w1, #0x8                // =8
     524:      	blr	x10
     528:      	mov	x10, x22
     52c:      	mov	x22, x21
     530:      	mov	x21, x23
     534:      	tbnz	w0, #0x1f, 0x1484 <generic_rawtp_process_event+0x12b4>
     538:      	ldr	x23, [sp, #0x48]
     53c:      	ldurh	w8, [x23, #0xa6]
     540:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     544:      	ldr	x8, [sp, #0x60]
     548:      	ldur	w9, [x23, #0xa0]
     54c:      	add	x8, x8, x9
     550:      	str	x10, [sp, #0x40]
     554:      	str	x8, [sp, #0x60]
     558:      	ldurh	w9, [x23, #0xa4]
     55c:      	cbz	w9, 0x580 <generic_rawtp_process_event+0x3b0>
     560:      	mov	w9, #0x8                // =8
     564:      	mov	w10, #0x4               // =4
     568:      	add	x11, sp, #0x60
     56c:      	ldr	x2, [sp, #0x60]
     570:      	add	x0, sp, #0x60
     574:      	mov	w1, #0x8                // =8
     578:      	blr	x10
     57c:      	tbnz	w0, #0x1f, 0x163c <generic_rawtp_process_event+0x146c>
     580:      	ldurh	w8, [x23, #0xae]
     584:      	ldr	x10, [sp, #0x40]
     588:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     58c:      	ldr	x8, [sp, #0x60]
     590:      	ldur	w9, [x23, #0xa8]
     594:      	add	x8, x8, x9
     598:      	str	x8, [sp, #0x60]
     59c:      	ldurh	w9, [x23, #0xac]
     5a0:      	cbz	w9, 0x5cc <generic_rawtp_process_event+0x3fc>
     5a4:      	mov	w11, #0x8               // =8
     5a8:      	mov	w9, #0x4                // =4
     5ac:      	add	x10, sp, #0x60
     5b0:      	ldr	x2, [sp, #0x60]
     5b4:      	add	x0, sp, #0x60
     5b8:      	mov	w1, #0x8                // =8
     5bc:      	blr	x9
     5c0:      	ldr	x10, [sp, #0x40]
     5c4:      	mov	w9, #0x8                // =8
     5c8:      	tbnz	w0, #0x1f, 0x670 <generic_rawtp_process_event+0x4a0>
     5cc:      	ldurh	w8, [x23, #0xb6]
     5d0:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     5d4:      	ldr	x8, [sp, #0x60]
     5d8:      	ldur	w9, [x23, #0xb0]
     5dc:      	add	x8, x8, x9
     5e0:      	str	x8, [sp, #0x60]
     5e4:      	ldurh	w9, [x23, #0xb4]
     5e8:      	cbz	w9, 0x60c <generic_rawtp_process_event+0x43c>
     5ec:      	mov	w9, #0x8                // =8
     5f0:      	mov	w10, #0x4               // =4
     5f4:      	add	x11, sp, #0x60
     5f8:      	ldr	x2, [sp, #0x60]
     5fc:      	add	x0, sp, #0x60
     600:      	mov	w1, #0x8                // =8
     604:      	blr	x10
     608:      	tbnz	w0, #0x1f, 0x21b0 <generic_rawtp_process_event+0x1fe0>
     60c:      	ldp	x10, x11, [sp, #0x40]
     610:      	ldurh	w8, [x11, #0xbe]
     614:      	cbz	w8, 0x678 <generic_rawtp_process_event+0x4a8>
     618:      	ldr	x8, [sp, #0x60]
     61c:      	ldur	w9, [x11, #0xb8]
     620:      	add	x8, x8, x9
     624:      	str	x8, [sp, #0x60]
     628:      	ldurh	w9, [x11, #0xbc]
     62c:      	cbz	w9, 0x678 <generic_rawtp_process_event+0x4a8>
     630:      	mov	w9, #0x8                // =8
     634:      	mov	w10, #0x4               // =4
     638:      	add	x11, sp, #0x60
     63c:      	ldr	x2, [sp, #0x60]
     640:      	add	x0, sp, #0x60
     644:      	mov	w1, #0x8                // =8
     648:      	blr	x10
     64c:      	ldr	x10, [sp, #0x40]
     650:      	tbz	w0, #0x1f, 0x678 <generic_rawtp_process_event+0x4a8>
     654:      	mov	w9, #0xa                // =10
     658:      	b	0x670 <generic_rawtp_process_event+0x4a0>
     65c:      	mov	w9, #0x1                // =1
     660:      	b	0x670 <generic_rawtp_process_event+0x4a0>
     664:      	mov	w9, #0x2                // =2
     668:      	b	0x670 <generic_rawtp_process_event+0x4a0>
     66c:      	mov	w9, #0x3                // =3
     670:      	mov	w8, #0x5ea0             // =24224
     674:      	str	w9, [x25, x8]
     678:      	mov	x9, #0x8000             // =32768
     67c:      	mov	w8, #0x1                // =1
     680:      	cmp	w24, #0x2a
     684:      	movk	x9, #0x101, lsl #16
     688:      	lsl	x8, x8, x24
     68c:      	movk	x9, #0x420, lsl #32
     690:      	and	x8, x8, x9
     694:      	ccmp	x8, #0x0, #0x4, ls
     698:      	b.eq	0x788 <generic_rawtp_process_event+0x5b8>
     69c:      	str	wzr, [sp, #0xe8]
     6a0:      	ldr	x21, [sp, #0x60]
     6a4:      	mov	w8, #0x1                // =1
     6a8:      	add	x9, sp, #0xe8
     6ac:      	add	x1, sp, #0xe8
     6b0:      	mov	x0, x22
     6b4:      	blr	x8
     6b8:      	cbz	x0, 0x724 <generic_rawtp_process_event+0x554>
     6bc:      	mov	w8, #0x6420             // =25632
     6c0:      	mov	x23, x0
     6c4:      	add	x25, x0, x8
     6c8:      	ldr	w8, [x25]
     6cc:      	cbz	w8, 0x73c <generic_rawtp_process_event+0x56c>
     6d0:      	str	wzr, [x25]
     6d4:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     6d8:      	mov	w8, #0x1                // =1
     6dc:      	add	x9, sp, #0xe8
     6e0:      	ldr	x0, [x0]
     6e4:      	add	x1, sp, #0xe8
     6e8:      	blr	x8
     6ec:      	ldr	x21, [sp, #0x50]
     6f0:      	cbz	x0, 0x7d0 <generic_rawtp_process_event+0x600>
     6f4:      	add	x8, x23, x29, lsl #2
     6f8:      	mov	w9, #0x5ea0             // =24224
     6fc:      	ldr	x24, [sp, #0x108]
     700:      	add	x11, x23, x29, lsl #3
     704:      	ldr	w10, [x8, x9]
     708:      	add	x8, x23, #0x90
     70c:      	add	x9, x24, #0x4
     710:      	str	w10, [x8, x24]
     714:      	str	x9, [x11, #0x5e78]
     718:      	cbz	w10, 0x838 <generic_rawtp_process_event+0x668>
     71c:      	mov	w8, #0x4                // =4
     720:      	b	0x8ec <generic_rawtp_process_event+0x71c>
     724:      	mov	x8, xzr
     728:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     72c:      	mov	w29, #0x5efc            // =24316
     730:      	ldr	x25, [x25]
     734:      	ldr	x21, [sp, #0x50]
     738:      	b	0x9d0 <generic_rawtp_process_event+0x800>
     73c:      	add	x8, sp, #0xe0
     740:      	cmp	w24, #0x17
     744:      	str	x21, [sp, #0x98]
     748:      	str	xzr, [x8, #0x10]
     74c:      	b.le	0x7e4 <generic_rawtp_process_event+0x614>
     750:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     754:      	cmp	w24, #0x18
     758:      	mov	w29, #0x5efc            // =24316
     75c:      	ldr	x25, [x25]
     760:      	b.eq	0x93c <generic_rawtp_process_event+0x76c>
     764:      	cmp	w24, #0x25
     768:      	b.eq	0x980 <generic_rawtp_process_event+0x7b0>
     76c:      	cmp	w24, #0x2a
     770:      	b.ne	0xabc <generic_rawtp_process_event+0x8ec>
     774:      	mov	w8, #0x6430             // =25648
     778:      	str	xzr, [x23, #0x6430]
     77c:      	str	x21, [x23, #0x6438]
     780:      	add	x8, x23, x8
     784:      	b	0x9ac <generic_rawtp_process_event+0x7dc>
     788:      	ldr	x25, [sp, #0x60]
     78c:      	cmp	w24, #0x15
     790:      	b.gt	0x80c <generic_rawtp_process_event+0x63c>
     794:      	mov	w23, #0x1fe             // =510
     798:      	cmp	w24, #0x9
     79c:      	b.le	0x914 <generic_rawtp_process_event+0x744>
     7a0:      	cmp	w24, #0x10
     7a4:      	b.le	0xac4 <generic_rawtp_process_event+0x8f4>
     7a8:      	cmp	w24, #0x12
     7ac:      	b.le	0xb3c <generic_rawtp_process_event+0x96c>
     7b0:      	cmp	w24, #0x13
     7b4:      	b.eq	0xb64 <generic_rawtp_process_event+0x994>
     7b8:      	cmp	w24, #0x14
     7bc:      	b.eq	0xb8c <generic_rawtp_process_event+0x9bc>
     7c0:      	cmp	w24, #0x15
     7c4:      	b.ne	0xb9c <generic_rawtp_process_event+0x9cc>
     7c8:      	mov	w23, #0x20              // =32
     7cc:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     7d0:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     7d4:      	mov	x8, xzr
     7d8:      	mov	w29, #0x5efc            // =24316
     7dc:      	ldr	x25, [x25]
     7e0:      	b	0x9d0 <generic_rawtp_process_event+0x800>
     7e4:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     7e8:      	add	x21, sp, #0xe0
     7ec:      	cmp	w24, #0xf
     7f0:      	ldr	x25, [x25]
     7f4:      	mov	w29, #0x5efc            // =24316
     7f8:      	b.eq	0xa8c <generic_rawtp_process_event+0x8bc>
     7fc:      	cmp	w24, #0x10
     800:      	b.ne	0xabc <generic_rawtp_process_event+0x8ec>
     804:      	add	x24, sp, #0x70
     808:      	b	0x960 <generic_rawtp_process_event+0x790>
     80c:      	cmp	w24, #0x20
     810:      	b.gt	0x8fc <generic_rawtp_process_event+0x72c>
     814:      	cmp	w24, #0x1a
     818:      	b.gt	0xae8 <generic_rawtp_process_event+0x918>
     81c:      	cmp	w24, #0x16
     820:      	b.eq	0xb34 <generic_rawtp_process_event+0x964>
     824:      	cmp	w24, #0x17
     828:      	b.eq	0xae0 <generic_rawtp_process_event+0x910>
     82c:      	cmp	w24, #0x1a
     830:      	b.eq	0xb7c <generic_rawtp_process_event+0x9ac>
     834:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     838:      	add	x21, x8, x9
     83c:      	ldr	w8, [x25, #0x4]
     840:      	ldr	x25, [x23, #0x6440]
     844:      	mov	w24, #0x4               // =4
     848:      	and	x9, x8, #0xfff
     84c:      	add	x2, x0, x9
     850:      	mov	w9, #0xfff              // =4095
     854:      	add	x0, x21, #0x4
     858:      	sub	w8, w9, w8
     85c:      	and	w23, w8, #0xfff
     860:      	mov	w8, #0x4                // =4
     864:      	mov	w1, w23
     868:      	blr	x8
     86c:      	str	w23, [x21]
     870:      	add	x2, x25, #0x8
     874:      	mov	w25, #0x8               // =8
     878:      	add	x8, sp, #0x98
     87c:      	mov	w9, #0x4                // =4
     880:      	add	x0, sp, #0x98
     884:      	mov	w1, #0x8                // =8
     888:      	blr	x9
     88c:      	ldr	x8, [sp, #0x98]
     890:      	add	x9, sp, #0xf0
     894:      	mov	w10, #0x4               // =4
     898:      	add	x0, sp, #0xf0
     89c:      	mov	w1, #0x8                // =8
     8a0:      	add	x8, x8, #0x30
     8a4:      	ldr	x8, [sp, #0x98]
     8a8:      	add	x2, x8, #0x30
     8ac:      	blr	x10
     8b0:      	add	x11, sp, #0xe0
     8b4:      	mov	w9, #0x2                // =2
     8b8:      	add	x10, sp, #0x70
     8bc:      	ldr	x8, [x11, #0x10]
     8c0:      	add	x0, sp, #0x70
     8c4:      	mov	w1, #0x2                // =2
     8c8:      	ldr	x2, [x11, #0x10]
     8cc:      	blr	x24
     8d0:      	add	x8, x21, x23
     8d4:      	ldr	x24, [sp, #0x108]
     8d8:      	ldr	x21, [sp, #0x50]
     8dc:      	str	wzr, [x8, #0x4]
     8e0:      	ldrh	w9, [sp, #0x70]
     8e4:      	strh	w9, [x8, #0x8]
     8e8:      	add	w8, w23, #0xe
     8ec:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     8f0:      	mov	w29, #0x5efc            // =24316
     8f4:      	ldr	x25, [x25]
     8f8:      	b	0x9d4 <generic_rawtp_process_event+0x804>
     8fc:      	cmp	w24, #0x26
     900:      	b.gt	0xafc <generic_rawtp_process_event+0x92c>
     904:      	sub	w8, w24, #0x21
     908:      	cmp	w8, #0x4
     90c:      	b.lo	0xae0 <generic_rawtp_process_event+0x910>
     910:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     914:      	cmp	w24, #0x4
     918:      	b.gt	0xb18 <generic_rawtp_process_event+0x948>
     91c:      	sub	w8, w24, #0x2
     920:      	cmp	w8, #0x2
     924:      	b.lo	0xaf4 <generic_rawtp_process_event+0x924>
     928:      	cmp	w24, #0x1
     92c:      	b.eq	0xaf4 <generic_rawtp_process_event+0x924>
     930:      	cmp	w24, #0x4
     934:      	b.eq	0xae0 <generic_rawtp_process_event+0x910>
     938:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     93c:      	add	x24, sp, #0x70
     940:      	mov	w8, #0x8                // =8
     944:      	mov	w9, #0x4                // =4
     948:      	ldr	x2, [sp, #0x98]
     94c:      	add	x0, sp, #0x70
     950:      	mov	w1, #0x8                // =8
     954:      	blr	x9
     958:      	ldr	x8, [sp, #0x70]
     95c:      	str	x8, [sp, #0x98]
     960:      	mov	w8, #0x8                // =8
     964:      	mov	w9, #0x4                // =4
     968:      	add	x10, sp, #0x98
     96c:      	add	x0, sp, #0x70
     970:      	add	x2, sp, #0x98
     974:      	mov	w1, #0x8                // =8
     978:      	blr	x9
     97c:      	b	0x9a4 <generic_rawtp_process_event+0x7d4>
     980:      	add	x8, x21, #0x40
     984:      	mov	w9, #0x8                // =8
     988:      	mov	w10, #0x4               // =4
     98c:      	str	x8, [sp, #0x98]
     990:      	add	x11, sp, #0x70
     994:      	add	x0, sp, #0x70
     998:      	mov	w1, #0x8                // =8
     99c:      	ldr	x2, [sp, #0x98]
     9a0:      	blr	x10
     9a4:      	ldr	x8, [sp, #0x70]
     9a8:      	add	x8, x8, #0x40
     9ac:      	ldr	x21, [sp, #0x50]
     9b0:      	str	x8, [x23, #0x6440]
     9b4:      	mov	w8, #0x6                // =6
     9b8:      	mov	w9, #0xc                // =12
     9bc:      	mov	x0, x19
     9c0:      	mov	x1, x25
     9c4:      	mov	w2, #0x6                // =6
     9c8:      	blr	x9
     9cc:      	mov	x8, xzr
     9d0:      	ldr	x24, [sp, #0x108]
     9d4:      	add	w24, w24, w8
     9d8:      	cmp	w21, #0x3
     9dc:      	str	w24, [x20, #0x4]
     9e0:      	b.gt	0xa50 <generic_rawtp_process_event+0x880>
     9e4:      	str	wzr, [sp, #0x98]
     9e8:      	mov	w8, #0x1                // =1
     9ec:      	add	x9, sp, #0x98
     9f0:      	add	x1, sp, #0x98
     9f4:      	mov	x0, x22
     9f8:      	blr	x8
     9fc:      	cbz	x0, 0xa50 <generic_rawtp_process_event+0x880>
     a00:      	mov	w8, #0x5ef8             // =24312
     a04:      	add	x1, x0, x8
     a08:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     a0c:      	mov	w8, #0x1                // =1
     a10:      	ldr	x0, [x0]
     a14:      	blr	x8
     a18:      	cbz	x0, 0xa50 <generic_rawtp_process_event+0x880>
     a1c:      	add	w8, w21, #0x1
     a20:      	and	w9, w8, #0x7
     a24:      	add	x9, x0, w9, uxtw #2
     a28:      	ldr	w9, [x9, #0x40]
     a2c:      	cmn	w9, #0x1
     a30:      	b.eq	0xa50 <generic_rawtp_process_event+0x880>
     a34:      	str	w8, [x20, x29]
     a38:      	mov	w8, #0x1                // =1
     a3c:      	mov	w9, #0xc                // =12
     a40:      	mov	x0, x19
     a44:      	mov	x1, x25
     a48:      	mov	w2, #0x1                // =1
     a4c:      	blr	x9
     a50:      	str	wzr, [x20, x29]
     a54:      	mov	w8, #0x3                // =3
     a58:      	mov	w9, #0xc                // =12
     a5c:      	mov	x0, x19
     a60:      	mov	x1, x25
     a64:      	mov	w2, #0x3                // =3
     a68:      	blr	x9
     a6c:      	ldp	x20, x19, [sp, #0x140]
     a70:      	mov	w0, wzr
     a74:      	ldr	x29, [sp, #0x100]
     a78:      	ldp	x22, x21, [sp, #0x130]
     a7c:      	ldp	x24, x23, [sp, #0x120]
     a80:      	ldp	x30, x25, [sp, #0x110]
     a84:      	add	sp, sp, #0x150
     a88:      	ret
     a8c:      	mov	w8, #0x8                // =8
     a90:      	mov	w9, #0x4                // =4
     a94:      	add	x10, sp, #0xf0
     a98:      	add	x11, sp, #0x98
     a9c:      	add	x0, sp, #0xf0
     aa0:      	add	x2, sp, #0x98
     aa4:      	mov	w1, #0x8                // =8
     aa8:      	blr	x9
     aac:      	ldr	x8, [x21, #0x10]
     ab0:      	ldr	x21, [sp, #0x50]
     ab4:      	cbnz	x8, 0x9b0 <generic_rawtp_process_event+0x7e0>
     ab8:      	b	0x9d0 <generic_rawtp_process_event+0x800>
     abc:      	mov	x8, xzr
     ac0:      	b	0x734 <generic_rawtp_process_event+0x564>
     ac4:      	sub	w8, w24, #0xa
     ac8:      	cmp	w8, #0x2
     acc:      	b.lo	0xae0 <generic_rawtp_process_event+0x910>
     ad0:      	sub	w8, w24, #0xc
     ad4:      	cmp	w8, #0x2
     ad8:      	b.lo	0xaf4 <generic_rawtp_process_event+0x924>
     adc:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     ae0:      	mov	w23, #0x8               // =8
     ae4:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     ae8:      	sub	w8, w24, #0x1d
     aec:      	cmp	w8, #0x4
     af0:      	b.hs	0xb94 <generic_rawtp_process_event+0x9c4>
     af4:      	mov	w23, #0x4               // =4
     af8:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     afc:      	cmp	w24, #0x28
     b00:      	b.gt	0xb54 <generic_rawtp_process_event+0x984>
     b04:      	cmp	w24, #0x27
     b08:      	b.eq	0xb34 <generic_rawtp_process_event+0x964>
     b0c:      	cmp	w24, #0x28
     b10:      	b.eq	0xb64 <generic_rawtp_process_event+0x994>
     b14:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     b18:      	cmp	w24, #0x6
     b1c:      	b.gt	0xb6c <generic_rawtp_process_event+0x99c>
     b20:      	cmp	w24, #0x5
     b24:      	b.eq	0xb84 <generic_rawtp_process_event+0x9b4>
     b28:      	cmp	w24, #0x6
     b2c:      	b.eq	0xba0 <generic_rawtp_process_event+0x9d0>
     b30:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     b34:      	mov	w23, #0x10              // =16
     b38:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     b3c:      	cmp	w24, #0x11
     b40:      	b.eq	0xba0 <generic_rawtp_process_event+0x9d0>
     b44:      	cmp	w24, #0x12
     b48:      	mov	x23, x21
     b4c:      	b.eq	0xba0 <generic_rawtp_process_event+0x9d0>
     b50:      	b	0xb9c <generic_rawtp_process_event+0x9cc>
     b54:      	cmp	w24, #0x29
     b58:      	b.eq	0xb84 <generic_rawtp_process_event+0x9b4>
     b5c:      	cmp	w24, #0x2b
     b60:      	b.ne	0xb9c <generic_rawtp_process_event+0x9cc>
     b64:      	mov	w23, #0x18              // =24
     b68:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     b6c:      	cmp	w24, #0x7
     b70:      	b.eq	0xb84 <generic_rawtp_process_event+0x9b4>
     b74:      	cmp	w24, #0x8
     b78:      	b.ne	0xb9c <generic_rawtp_process_event+0x9cc>
     b7c:      	mov	w23, #0x50              // =80
     b80:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     b84:      	mov	w23, #0x40              // =64
     b88:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     b8c:      	mov	w23, #0x98              // =152
     b90:      	b	0xba0 <generic_rawtp_process_event+0x9d0>
     b94:      	cmp	w24, #0x1b
     b98:      	b.eq	0xb7c <generic_rawtp_process_event+0x9ac>
     b9c:      	mov	x23, xzr
     ba0:      	str	x10, [sp, #0x40]
     ba4:      	str	wzr, [sp, #0x6c]
     ba8:      	mov	w8, #0x1                // =1
     bac:      	add	x9, sp, #0x6c
     bb0:      	add	x1, sp, #0x6c
     bb4:      	mov	x0, x22
     bb8:      	blr	x8
     bbc:      	mov	x8, xzr
     bc0:      	cbz	x0, 0x728 <generic_rawtp_process_event+0x558>
     bc4:      	ldr	x10, [sp, #0x108]
     bc8:      	mov	w9, #0x3ffb             // =16379
     bcc:      	sub	x9, x9, x23
     bd0:      	cmp	x9, x10
     bd4:      	b.ls	0x728 <generic_rawtp_process_event+0x558>
     bd8:      	add	x23, x0, x29, lsl #2
     bdc:      	mov	w8, #0x5ea0             // =24224
     be0:      	ldr	x9, [sp, #0x108]
     be4:      	add	x10, x0, #0x90
     be8:      	str	x25, [sp, #0x48]
     bec:      	ldr	w8, [x23, x8]
     bf0:      	add	x25, x9, #0x4
     bf4:      	str	w8, [x10, x9]
     bf8:      	add	x9, x0, x29, lsl #3
     bfc:      	str	x25, [x9, #0x5e78]
     c00:      	cbz	w8, 0xc0c <generic_rawtp_process_event+0xa3c>
     c04:      	mov	w8, #0x4                // =4
     c08:      	b	0x728 <generic_rawtp_process_event+0x558>
     c0c:      	add	x8, x10, x25
     c10:      	cmp	w24, #0x17
     c14:      	str	x10, [sp, #0x20]
     c18:      	str	x8, [sp, #0x30]
     c1c:      	ldr	x8, [sp, #0x48]
     c20:      	str	x8, [sp, #0x98]
     c24:      	add	x8, sp, #0xe0
     c28:      	str	xzr, [x8, #0x10]
     c2c:      	b.le	0xc58 <generic_rawtp_process_event+0xa88>
     c30:      	cmp	w24, #0x18
     c34:      	b.eq	0xc74 <generic_rawtp_process_event+0xaa4>
     c38:      	cmp	w24, #0x25
     c3c:      	b.eq	0xcc4 <generic_rawtp_process_event+0xaf4>
     c40:      	cmp	w24, #0x2a
     c44:      	b.ne	0x11f0 <generic_rawtp_process_event+0x1020>
     c48:      	ldr	x8, [sp, #0x48]
     c4c:      	stp	xzr, x8, [sp, #0x70]
     c50:      	add	x8, sp, #0x70
     c54:      	b	0xcf8 <generic_rawtp_process_event+0xb28>
     c58:      	cmp	w24, #0xf
     c5c:      	b.eq	0x1144 <generic_rawtp_process_event+0xf74>
     c60:      	cmp	w24, #0x10
     c64:      	b.ne	0x11f0 <generic_rawtp_process_event+0x1020>
     c68:      	add	x21, sp, #0xe8
     c6c:      	add	x24, sp, #0xe0
     c70:      	b	0xca0 <generic_rawtp_process_event+0xad0>
     c74:      	add	x21, sp, #0xe8
     c78:      	mov	w8, #0x8                // =8
     c7c:      	mov	w9, #0x4                // =4
     c80:      	ldr	x10, [sp, #0x48]
     c84:      	ldr	x2, [sp, #0x98]
     c88:      	add	x0, sp, #0xe8
     c8c:      	mov	w1, #0x8                // =8
     c90:      	blr	x9
     c94:      	add	x24, sp, #0xe0
     c98:      	ldr	x8, [x24, #0x8]
     c9c:      	str	x8, [sp, #0x98]
     ca0:      	mov	w8, #0x8                // =8
     ca4:      	mov	w9, #0x4                // =4
     ca8:      	add	x10, sp, #0x98
     cac:      	add	x0, sp, #0xe8
     cb0:      	add	x2, sp, #0x98
     cb4:      	mov	w1, #0x8                // =8
     cb8:      	blr	x9
     cbc:      	ldr	x8, [x24, #0x8]
     cc0:      	b	0xcf4 <generic_rawtp_process_event+0xb24>
     cc4:      	ldr	x8, [sp, #0x48]
     cc8:      	mov	w9, #0x8                // =8
     ccc:      	mov	w10, #0x4               // =4
     cd0:      	add	x11, sp, #0xe8
     cd4:      	add	x0, sp, #0xe8
     cd8:      	mov	w1, #0x8                // =8
     cdc:      	add	x8, x8, #0x40
     ce0:      	str	x8, [sp, #0x98]
     ce4:      	ldr	x2, [sp, #0x98]
     ce8:      	blr	x10
     cec:      	add	x8, sp, #0xe0
     cf0:      	ldr	x8, [x8, #0x8]
     cf4:      	add	x8, x8, #0x40
     cf8:      	str	x8, [sp, #0x38]
     cfc:      	str	wzr, [sp, #0x84]
     d00:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     d04:      	mov	w8, #0x1                // =1
     d08:      	add	x9, sp, #0x84
     d0c:      	ldr	x0, [x0]
     d10:      	add	x1, sp, #0x84
     d14:      	blr	x8
     d18:      	cbz	x0, 0x106c <generic_rawtp_process_event+0xe9c>
     d1c:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     d20:      	stp	x0, x23, [sp, #0x10]
     d24:      	str	x8, [sp, #0x40]
     d28:      	mov	w8, #0x23               // =35
     d2c:      	blr	x8
     d30:      	add	x2, x0, #0xb30
     d34:      	mov	w24, #0x8               // =8
     d38:      	add	x8, sp, #0x88
     d3c:      	mov	w9, #0x4                // =4
     d40:      	add	x0, sp, #0x88
     d44:      	mov	w1, #0x8                // =8
     d48:      	mov	w29, #0x4               // =4
     d4c:      	blr	x9
     d50:      	ldr	x21, [sp, #0x88]
     d54:      	mov	w9, #0x4                // =4
     d58:      	add	x0, sp, #0x90
     d5c:      	mov	w1, #0x8                // =8
     d60:      	add	x8, x21, #0x18
     d64:      	str	x8, [sp, #0x48]
     d68:      	ldr	x8, [sp, #0x38]
     d6c:      	add	x2, x8, #0x8
     d70:      	add	x8, sp, #0x90
     d74:      	str	x2, [sp, #0x28]
     d78:      	blr	x9
     d7c:      	ldr	x23, [sp, #0x90]
     d80:      	add	x25, sp, #0x98
     d84:      	add	x0, sp, #0x98
     d88:      	mov	w1, #0x8                // =8
     d8c:      	add	x2, x23, #0x10
     d90:      	blr	x29
     d94:      	ldr	x8, [sp, #0x98]
     d98:      	cbz	x8, 0xdac <generic_rawtp_process_event+0xbdc>
     d9c:      	ldr	x9, [sp, #0x40]
     da0:      	ldr	x10, [sp, #0x10]
     da4:      	mov	w8, #0x1000             // =4096
     da8:      	b	0xdf8 <generic_rawtp_process_event+0xc28>
     dac:      	add	x2, x23, #0x18
     db0:      	mov	w8, #0x8                // =8
     db4:      	mov	w9, #0x4                // =4
     db8:      	add	x10, sp, #0x98
     dbc:      	add	x0, sp, #0x98
     dc0:      	mov	w1, #0x8                // =8
     dc4:      	blr	x9
     dc8:      	ldr	x8, [sp, #0x98]
     dcc:      	cmp	x8, x23
     dd0:      	b.eq	0xd9c <generic_rawtp_process_event+0xbcc>
     dd4:      	ldr	x10, [sp, #0x10]
     dd8:      	mov	w8, #0x2964             // =10596
     ddc:      	strh	w8, [x10, #0xffe]
     de0:      	adrp	x8, 0x0 <generic_rawtp_setup_event>
     de4:      	add	x8, x8, #0x0
     de8:      	add	x9, x10, #0xff6
     dec:      	ldr	x8, [x8]
     df0:      	str	x8, [x9]
     df4:      	mov	w8, #0xff6              // =4086
     df8:      	stp	xzr, xzr, [sp, #0x98]
     dfc:      	add	x2, x21, #0x20
     e00:      	mov	w21, #0x8               // =8
     e04:      	add	x0, sp, #0x98
     e08:      	mov	w1, #0x8                // =8
     e0c:      	add	x23, x25, #0x8
     e10:      	stp	x10, xzr, [sp, #0xa8]
     e14:      	add	x10, sp, #0x98
     e18:      	add	x29, x25, #0x18
     e1c:      	stp	xzr, xzr, [sp, #0xb8]
     e20:      	add	x25, x10, #0x20
     e24:      	mov	w24, #0x4               // =4
     e28:      	str	x9, [sp, #0x40]
     e2c:      	str	x9, [sp, #0xc8]
     e30:      	str	w8, [sp, #0xd0]
     e34:      	mov	w8, #0x4                // =4
     e38:      	strb	wzr, [sp, #0xd4]
     e3c:      	blr	x8
     e40:      	ldr	x2, [sp, #0x48]
     e44:      	mov	w8, #0x4                // =4
     e48:      	mov	x0, x23
     e4c:      	mov	w1, #0x8                // =8
     e50:      	mov	w23, #0x8               // =8
     e54:      	blr	x8
     e58:      	ldr	x2, [sp, #0x28]
     e5c:      	mov	w8, #0x4                // =4
     e60:      	mov	x0, x29
     e64:      	mov	w1, #0x8                // =8
     e68:      	str	x29, [sp, #0x48]
     e6c:      	blr	x8
     e70:      	ldr	x2, [sp, #0x38]
     e74:      	mov	x0, x25
     e78:      	mov	w1, #0x8                // =8
     e7c:      	blr	x24
     e80:      	ldr	x8, [sp, #0xb8]
     e84:      	mov	w25, #0x80              // =128
     e88:      	sub	x8, x8, #0x20
     e8c:      	str	x8, [sp, #0xc0]
     e90:      	b	0xe9c <generic_rawtp_process_event+0xccc>
     e94:      	subs	w25, w25, #0x1
     e98:      	b.eq	0x102c <generic_rawtp_process_event+0xe5c>
     e9c:      	ldp	x29, x2, [sp, #0xb0]
     ea0:      	ldp	x8, x9, [sp, #0x98]
     ea4:      	cmp	x29, x8
     ea8:      	ccmp	x2, x9, #0x0, eq
     eac:      	b.eq	0x1024 <generic_rawtp_process_event+0xe54>
     eb0:      	ldr	x24, [sp, #0xc0]
     eb4:      	mov	w8, #0x4                // =4
     eb8:      	add	x9, sp, #0xd8
     ebc:      	add	x0, sp, #0xd8
     ec0:      	mov	w1, #0x8                // =8
     ec4:      	blr	x8
     ec8:      	ldr	x8, [sp, #0xd8]
     ecc:      	mov	w21, #0x8               // =8
     ed0:      	cmp	x29, x8
     ed4:      	b.eq	0xfcc <generic_rawtp_process_event+0xdfc>
     ed8:      	add	x23, x29, #0x18
     edc:      	mov	w8, #0x4                // =4
     ee0:      	add	x9, sp, #0xe8
     ee4:      	add	x0, sp, #0xe8
     ee8:      	mov	w1, #0x8                // =8
     eec:      	mov	x2, x23
     ef0:      	blr	x8
     ef4:      	add	x8, sp, #0xe0
     ef8:      	ldr	x8, [x8, #0x8]
     efc:      	cmp	x8, x29
     f00:      	b.eq	0xfcc <generic_rawtp_process_event+0xdfc>
     f04:      	mov	w8, #0x4                // =4
     f08:      	add	x9, sp, #0xe0
     f0c:      	add	x0, sp, #0xe0
     f10:      	mov	w1, #0x8                // =8
     f14:      	mov	x2, x23
     f18:      	blr	x8
     f1c:      	add	x2, x29, #0x20
     f20:      	mov	w8, #0x4                // =4
     f24:      	mov	w9, #0x10               // =16
     f28:      	add	x10, sp, #0xf0
     f2c:      	add	x0, sp, #0xf0
     f30:      	mov	w1, #0x10               // =16
     f34:      	blr	x8
     f38:      	add	x8, sp, #0xe0
     f3c:      	ldr	w23, [sp, #0xf4]
     f40:      	ldr	x10, [sp, #0xc8]
     f44:      	ldr	w24, [sp, #0xd0]
     f48:      	ldr	x9, [x8, #0x18]
     f4c:      	ldr	x8, [sp, #0xa8]
     f50:      	sub	x12, x10, x8
     f54:      	subs	w10, w23, w24
     f58:      	csel	w10, wzr, w10, lo
     f5c:      	cmp	w24, w23
     f60:      	csel	w11, w24, w23, lo
     f64:      	cinc	w13, w11, hi
     f68:      	sub	w14, w24, w13
     f6c:      	subs	x12, x12, x13
     f70:      	str	w14, [sp, #0xd0]
     f74:      	b.lo	0x102c <generic_rawtp_process_event+0xe5c>
     f78:      	cmp	x12, #0xfff
     f7c:      	b.hi	0x102c <generic_rawtp_process_event+0xe5c>
     f80:      	cmp	w24, w23
     f84:      	b.ls	0xf90 <generic_rawtp_process_event+0xdc0>
     f88:      	mov	w13, #0x2f              // =47
     f8c:      	strb	w13, [x8, x12]
     f90:      	add	x29, x8, x12
     f94:      	cmp	w24, w23
     f98:      	add	x2, x9, x10
     f9c:      	and	w1, w11, #0xff
     fa0:      	mov	w8, #0x4                // =4
     fa4:      	cinc	x0, x29, hi
     fa8:      	blr	x8
     fac:      	cmp	w24, w23
     fb0:      	str	x29, [sp, #0xc8]
     fb4:      	b.ls	0x102c <generic_rawtp_process_event+0xe5c>
     fb8:      	add	x8, sp, #0xe0
     fbc:      	mov	w23, #0x8               // =8
     fc0:      	ldr	x8, [x8]
     fc4:      	str	x8, [sp, #0xb0]
     fc8:      	b	0xe94 <generic_rawtp_process_event+0xcc4>
     fcc:      	add	x2, x24, #0x10
     fd0:      	mov	w8, #0x4                // =4
     fd4:      	add	x9, sp, #0xe8
     fd8:      	add	x0, sp, #0xe8
     fdc:      	mov	w1, #0x8                // =8
     fe0:      	blr	x8
     fe4:      	add	x9, sp, #0xe0
     fe8:      	ldr	x8, [sp, #0xc0]
     fec:      	mov	w23, #0x8               // =8
     ff0:      	ldr	x9, [x9, #0x8]
     ff4:      	cmp	x8, x9
     ff8:      	b.eq	0x1024 <generic_rawtp_process_event+0xe54>
     ffc:      	ldr	x0, [sp, #0x48]
    1000:      	add	x2, x24, #0x18
    1004:      	mov	w8, #0x4                // =4
    1008:      	mov	w1, #0x8                // =8
    100c:      	blr	x8
    1010:      	add	x8, sp, #0xe0
    1014:      	ldr	x8, [x8, #0x8]
    1018:      	add	x9, x8, #0x20
    101c:      	stp	x9, x8, [sp, #0xb8]
    1020:      	b	0xe94 <generic_rawtp_process_event+0xcc4>
    1024:      	mov	w8, #0x1                // =1
    1028:      	strb	w8, [sp, #0xd4]
    102c:      	ldr	x8, [sp, #0xc8]
    1030:      	ldr	x2, [sp, #0x40]
    1034:      	cmp	x8, x2
    1038:      	b.eq	0x1074 <generic_rawtp_process_event+0xea4>
    103c:      	ldrb	w9, [sp, #0xd4]
    1040:      	mov	w11, #0x1000            // =4096
    1044:      	cmp	w9, #0x0
    1048:      	ldr	w9, [sp, #0xd0]
    104c:      	cset	w10, eq
    1050:      	sub	w11, w11, w9
    1054:      	cmp	w9, #0x0
    1058:      	csel	w9, w11, w9, gt
    105c:      	cbz	x8, 0x106c <generic_rawtp_process_event+0xe9c>
    1060:      	lsl	w21, w10, #1
    1064:      	mov	x2, x8
    1068:      	b	0x107c <generic_rawtp_process_event+0xeac>
    106c:      	mov	x23, xzr
    1070:      	b	0x1118 <generic_rawtp_process_event+0xf48>
    1074:      	mov	w9, wzr
    1078:      	mov	w21, wzr
    107c:      	ldr	x29, [sp, #0x30]
    1080:      	and	w23, w9, #0xfff
    1084:      	mov	w8, #0x4                // =4
    1088:      	mov	w24, #0x4               // =4
    108c:      	mov	w1, w23
    1090:      	add	x0, x29, #0x4
    1094:      	blr	x8
    1098:      	str	w23, [x29]
    109c:      	ldr	x2, [sp, #0x28]
    10a0:      	mov	w25, #0x8               // =8
    10a4:      	add	x8, sp, #0x98
    10a8:      	mov	w9, #0x4                // =4
    10ac:      	add	x0, sp, #0x98
    10b0:      	mov	w1, #0x8                // =8
    10b4:      	blr	x9
    10b8:      	ldr	x8, [sp, #0x98]
    10bc:      	add	x9, sp, #0xf0
    10c0:      	mov	w10, #0x4               // =4
    10c4:      	add	x0, sp, #0xf0
    10c8:      	mov	w1, #0x8                // =8
    10cc:      	add	x8, x8, #0x30
    10d0:      	ldr	x8, [sp, #0x98]
    10d4:      	add	x2, x8, #0x30
    10d8:      	blr	x10
    10dc:      	add	x11, sp, #0xe0
    10e0:      	mov	w9, #0x2                // =2
    10e4:      	add	x10, sp, #0xe8
    10e8:      	ldr	x8, [x11, #0x10]
    10ec:      	add	x0, sp, #0xe8
    10f0:      	mov	w1, #0x2                // =2
    10f4:      	ldr	x2, [x11, #0x10]
    10f8:      	blr	x24
    10fc:      	add	x8, x29, x23
    1100:      	add	w23, w23, #0xa
    1104:      	str	w21, [x8, #0x4]
    1108:      	ldrh	w9, [sp, #0xe8]
    110c:      	strh	w9, [x8, #0x8]
    1110:      	mov	w10, #0x5ea0            // =24224
    1114:      	tbnz	w23, #0x1f, 0x1124 <generic_rawtp_process_event+0xf54>
    1118:      	and	x8, x23, #0x7fffffff
    111c:      	add	x8, x8, #0x4
    1120:      	b	0x728 <generic_rawtp_process_event+0x558>
    1124:      	ldr	x9, [sp, #0x18]
    1128:      	mov	w8, #-0x1               // =-1
    112c:      	str	w8, [x9, x10]
    1130:      	ldr	x9, [sp, #0x108]
    1134:      	ldr	x10, [sp, #0x20]
    1138:      	str	w8, [x10, x9]
    113c:      	mov	w8, #0x4                // =4
    1140:      	b	0x728 <generic_rawtp_process_event+0x558>
    1144:      	mov	w8, #0x8                // =8
    1148:      	mov	w9, #0x4                // =4
    114c:      	add	x10, sp, #0xf0
    1150:      	add	x11, sp, #0x98
    1154:      	add	x0, sp, #0xf0
    1158:      	add	x2, sp, #0x98
    115c:      	mov	w1, #0x8                // =8
    1160:      	blr	x9
    1164:      	add	x8, sp, #0xe0
    1168:      	ldr	x8, [x8, #0x10]
    116c:      	str	x8, [sp, #0x38]
    1170:      	cbnz	x8, 0xcfc <generic_rawtp_process_event+0xb2c>
    1174:      	str	x23, [sp, #0x18]
    1178:      	str	wzr, [sp, #0x90]
    117c:      	mov	w8, #0x1                // =1
    1180:      	add	x9, sp, #0x90
    1184:      	add	x1, sp, #0x90
    1188:      	mov	x0, x22
    118c:      	blr	x8
    1190:      	mov	x23, xzr
    1194:      	cbz	x0, 0x1110 <generic_rawtp_process_event+0xf40>
    1198:      	cmp	w24, #0x19
    119c:      	str	x19, [sp, #0x8]
    11a0:      	b.gt	0x148c <generic_rawtp_process_event+0x12bc>
    11a4:      	mov	x8, x24
    11a8:      	cmp	w24, #0x12
    11ac:      	b.le	0x14bc <generic_rawtp_process_event+0x12ec>
    11b0:      	cmp	w24, #0x14
    11b4:      	b.le	0x1868 <generic_rawtp_process_event+0x1698>
    11b8:      	cmp	w8, #0x15
    11bc:      	b.eq	0x1f74 <generic_rawtp_process_event+0x1da4>
    11c0:      	cmp	w8, #0x16
    11c4:      	b.eq	0x1f14 <generic_rawtp_process_event+0x1d44>
    11c8:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    11cc:      	cmp	w8, #0x17
    11d0:      	ldr	x22, [x22]
    11d4:      	ldr	x19, [sp, #0x8]
    11d8:      	b.ne	0x1110 <generic_rawtp_process_event+0xf40>
    11dc:      	ldr	x8, [sp, #0x30]
    11e0:      	ldr	x9, [sp, #0x48]
    11e4:      	mov	w23, #0x8               // =8
    11e8:      	stp	w9, wzr, [x8]
    11ec:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    11f0:      	cmp	w24, #0x28
    11f4:      	b.hi	0x1174 <generic_rawtp_process_event+0xfa4>
    11f8:      	mov	x9, #0x7cf2             // =31986
    11fc:      	mov	w8, #0x1                // =1
    1200:      	movk	x9, #0xf202, lsl #16
    1204:      	lsl	x8, x8, x24
    1208:      	movk	x9, #0x1c1, lsl #32
    120c:      	tst	x8, x9
    1210:      	b.eq	0x1174 <generic_rawtp_process_event+0xfa4>
    1214:      	ldr	x9, [sp, #0x48]
    1218:      	add	x8, sp, #0xe0
    121c:      	str	x23, [sp, #0x18]
    1220:      	add	x1, sp, #0x90
    1224:      	mov	x0, x22
    1228:      	str	wzr, [sp, #0x90]
    122c:      	str	x9, [x8]
    1230:      	mov	w8, #0x1                // =1
    1234:      	add	x9, sp, #0x90
    1238:      	blr	x8
    123c:      	mov	x23, xzr
    1240:      	cbz	x0, 0x1110 <generic_rawtp_process_event+0xf40>
    1244:      	cmp	w24, #0x10
    1248:      	b.gt	0x1378 <generic_rawtp_process_event+0x11a8>
    124c:      	cmp	w24, #0x9
    1250:      	b.gt	0x13a4 <generic_rawtp_process_event+0x11d4>
    1254:      	cmp	w24, #0x4
    1258:      	str	x19, [sp, #0x8]
    125c:      	b.le	0x1518 <generic_rawtp_process_event+0x1348>
    1260:      	cmp	w24, #0x5
    1264:      	b.eq	0x1af0 <generic_rawtp_process_event+0x1920>
    1268:      	mov	x8, x24
    126c:      	cmp	w8, #0x6
    1270:      	b.eq	0x1408 <generic_rawtp_process_event+0x1238>
    1274:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    1278:      	cmp	w8, #0x7
    127c:      	mov	w10, #0x5ea0            // =24224
    1280:      	ldr	x22, [x22]
    1284:      	ldr	x19, [sp, #0x8]
    1288:      	b.ne	0x1114 <generic_rawtp_process_event+0xf44>
    128c:      	add	x8, sp, #0xe0
    1290:      	ldr	x29, [sp, #0x30]
    1294:      	mov	x21, x0
    1298:      	mov	w25, #0x2               // =2
    129c:      	ldr	x23, [x8]
    12a0:      	mov	w8, #0x4                // =4
    12a4:      	mov	w1, #0x2                // =2
    12a8:      	mov	w24, #0x4               // =4
    12ac:      	str	x23, [x29, #0x28]
    12b0:      	add	x0, x29, #0x26
    12b4:      	add	x2, x23, #0x10
    12b8:      	blr	x8
    12bc:      	add	x0, x29, #0x3a
    12c0:      	add	x2, x23, #0x12
    12c4:      	mov	w8, #0x1                // =1
    12c8:      	mov	w9, #0x4                // =4
    12cc:      	mov	w1, #0x1                // =1
    12d0:      	blr	x9
    12d4:      	add	x0, x29, #0x38
    12d8:      	add	x2, x23, #0x21e
    12dc:      	mov	w8, #0x4                // =4
    12e0:      	mov	w1, #0x2                // =2
    12e4:      	blr	x8
    12e8:      	add	x0, x29, #0x24
    12ec:      	add	x2, x23, #0x21c
    12f0:      	mov	w8, #0x4                // =4
    12f4:      	mov	w1, #0x2                // =2
    12f8:      	blr	x8
    12fc:      	add	x0, x29, #0x30
    1300:      	add	x2, x23, #0x214
    1304:      	mov	w8, #0x4                // =4
    1308:      	mov	w1, #0x4                // =4
    130c:      	blr	x8
    1310:      	add	x0, x29, #0x34
    1314:      	add	x2, x23, #0x210
    1318:      	mov	w1, #0x4                // =4
    131c:      	blr	x24
    1320:      	ldrh	w8, [x29, #0x26]
    1324:      	mov	x24, x29
    1328:      	stp	xzr, xzr, [x29]
    132c:      	cmp	w8, #0xa
    1330:      	str	xzr, [x29, #0x18]
    1334:      	str	xzr, [x24, #0x10]!
    1338:      	b.eq	0x224c <generic_rawtp_process_event+0x207c>
    133c:      	cmp	w8, #0x2
    1340:      	b.ne	0x2278 <generic_rawtp_process_event+0x20a8>
    1344:      	ldr	x0, [sp, #0x30]
    1348:      	add	x2, x23, #0x4
    134c:      	mov	w8, #0x4                // =4
    1350:      	mov	w1, #0x4                // =4
    1354:      	mov	w25, #0x4               // =4
    1358:      	blr	x8
    135c:      	mov	x0, x24
    1360:      	mov	w1, #0x4                // =4
    1364:      	mov	x2, x23
    1368:      	blr	x25
    136c:      	b	0x2278 <generic_rawtp_process_event+0x20a8>
    1370:      	mov	w9, #0x5                // =5
    1374:      	b	0x670 <generic_rawtp_process_event+0x4a0>
    1378:      	cmp	w24, #0x1e
    137c:      	b.gt	0x1444 <generic_rawtp_process_event+0x1274>
    1380:      	cmp	w24, #0x1c
    1384:      	b.gt	0x157c <generic_rawtp_process_event+0x13ac>
    1388:      	mov	x8, x24
    138c:      	cmp	w8, #0x11
    1390:      	b.eq	0x1c54 <generic_rawtp_process_event+0x1a84>
    1394:      	cmp	w8, #0x19
    1398:      	b.eq	0x1910 <generic_rawtp_process_event+0x1740>
    139c:      	cmp	w8, #0x1c
    13a0:      	b	0x1534 <generic_rawtp_process_event+0x1364>
    13a4:      	sub	w8, w24, #0xa
    13a8:      	cmp	w8, #0x2
    13ac:      	b.lo	0x153c <generic_rawtp_process_event+0x136c>
    13b0:      	sub	w8, w24, #0xc
    13b4:      	cmp	w8, #0x2
    13b8:      	b.lo	0x155c <generic_rawtp_process_event+0x138c>
    13bc:      	mov	x9, x24
    13c0:      	mov	w10, #0x5ea0            // =24224
    13c4:      	cmp	w9, #0xe
    13c8:      	b.ne	0x1114 <generic_rawtp_process_event+0xf44>
    13cc:      	str	x19, [sp, #0x8]
    13d0:      	mov	w21, #0x8               // =8
    13d4:      	add	x8, sp, #0x98
    13d8:      	add	x24, sp, #0xe0
    13dc:      	mov	w9, #0x4                // =4
    13e0:      	add	x0, sp, #0x98
    13e4:      	add	x2, sp, #0xe0
    13e8:      	mov	w1, #0x8                // =8
    13ec:      	mov	w23, #0x4               // =4
    13f0:      	blr	x9
    13f4:      	ldr	x8, [sp, #0x98]
    13f8:      	add	x0, sp, #0xe0
    13fc:      	mov	w1, #0x8                // =8
    1400:      	ldr	x2, [sp, #0x98]
    1404:      	blr	x23
    1408:      	add	x8, sp, #0xe0
    140c:      	mov	w9, #0x2d               // =45
    1410:      	mov	w1, #0x1ff              // =511
    1414:      	ldr	x2, [x8]
    1418:      	ldr	x8, [sp, #0x30]
    141c:      	add	x0, x8, #0x4
    1420:      	mov	w8, #0x1ff              // =511
    1424:      	blr	x9
    1428:      	mov	x23, x0
    142c:      	tbnz	x0, #0x3f, 0x3468 <generic_rawtp_process_event+0x3298>
    1430:      	ldr	x9, [sp, #0x30]
    1434:      	sub	w8, w23, #0x1
    1438:      	add	x23, x23, #0x3
    143c:      	str	w8, [x9]
    1440:      	b	0x3468 <generic_rawtp_process_event+0x3298>
    1444:      	mov	x29, x19
    1448:      	mov	x25, x22
    144c:      	cmp	w24, #0x26
    1450:      	b.gt	0x15a0 <generic_rawtp_process_event+0x13d0>
    1454:      	sub	w8, w24, #0x1f
    1458:      	cmp	w8, #0x2
    145c:      	b.hs	0x17f0 <generic_rawtp_process_event+0x1620>
    1460:      	ldr	x0, [sp, #0x30]
    1464:      	mov	w8, #0x1                // =1
    1468:      	add	x9, sp, #0xe0
    146c:      	mov	w10, #0x4               // =4
    1470:      	add	x2, sp, #0xe0
    1474:      	mov	w1, #0x1                // =1
    1478:      	mov	w23, #0x4               // =4
    147c:      	blr	x10
    1480:      	b	0x2438 <generic_rawtp_process_event+0x2268>
    1484:      	mov	w9, #0x6                // =6
    1488:      	b	0x670 <generic_rawtp_process_event+0x4a0>
    148c:      	cmp	w24, #0x20
    1490:      	b.le	0x176c <generic_rawtp_process_event+0x159c>
    1494:      	sub	w8, w24, #0x21
    1498:      	cmp	w8, #0x4
    149c:      	b.hs	0x1648 <generic_rawtp_process_event+0x1478>
    14a0:      	ldr	x0, [sp, #0x30]
    14a4:      	ldr	x2, [sp, #0x48]
    14a8:      	mov	w23, #0x8               // =8
    14ac:      	mov	w8, #0x4                // =4
    14b0:      	mov	w1, #0x8                // =8
    14b4:      	blr	x8
    14b8:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    14bc:      	cmp	w24, #0x7
    14c0:      	b.gt	0x1830 <generic_rawtp_process_event+0x1660>
    14c4:      	mov	x29, x0
    14c8:      	cmp	w8, #0x2
    14cc:      	b.eq	0x1d48 <generic_rawtp_process_event+0x1b78>
    14d0:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    14d4:      	cmp	w8, #0x3
    14d8:      	ldr	x22, [x22]
    14dc:      	ldr	x19, [sp, #0x8]
    14e0:      	b.ne	0x1110 <generic_rawtp_process_event+0xf40>
    14e4:      	add	x24, x29, #0x90
    14e8:      	and	w8, w21, #0xf
    14ec:      	add	x25, x24, x25
    14f0:      	cmp	w8, #0x2
    14f4:      	b.le	0x23d4 <generic_rawtp_process_event+0x2204>
    14f8:      	cmp	w8, #0x3
    14fc:      	b.eq	0x2570 <generic_rawtp_process_event+0x23a0>
    1500:      	cmp	w8, #0x4
    1504:      	b.eq	0x2578 <generic_rawtp_process_event+0x23a8>
    1508:      	cmp	w8, #0x5
    150c:      	b.ne	0x25cc <generic_rawtp_process_event+0x23fc>
    1510:      	mov	w8, #0x5e70             // =24176
    1514:      	b	0x2584 <generic_rawtp_process_event+0x23b4>
    1518:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    151c:      	cmp	w24, #0x1
    1520:      	ldr	x22, [x22]
    1524:      	ldr	x19, [sp, #0x8]
    1528:      	b.eq	0x155c <generic_rawtp_process_event+0x138c>
    152c:      	mov	x8, x24
    1530:      	cmp	w8, #0x4
    1534:      	mov	w10, #0x5ea0            // =24224
    1538:      	b.ne	0x1114 <generic_rawtp_process_event+0xf44>
    153c:      	ldr	x0, [sp, #0x30]
    1540:      	mov	w23, #0x8               // =8
    1544:      	mov	w8, #0x4                // =4
    1548:      	add	x9, sp, #0xe0
    154c:      	add	x2, sp, #0xe0
    1550:      	mov	w1, #0x8                // =8
    1554:      	blr	x8
    1558:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    155c:      	ldr	x0, [sp, #0x30]
    1560:      	add	x8, sp, #0xe0
    1564:      	mov	w9, #0x4                // =4
    1568:      	add	x2, sp, #0xe0
    156c:      	mov	w1, #0x4                // =4
    1570:      	mov	w23, #0x4               // =4
    1574:      	blr	x9
    1578:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    157c:      	ldr	x0, [sp, #0x30]
    1580:      	mov	w8, #0x2                // =2
    1584:      	add	x9, sp, #0xe0
    1588:      	mov	w10, #0x4               // =4
    158c:      	add	x2, sp, #0xe0
    1590:      	mov	w1, #0x2                // =2
    1594:      	mov	w23, #0x4               // =4
    1598:      	blr	x10
    159c:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    15a0:      	cmp	w24, #0x27
    15a4:      	b.eq	0x1d08 <generic_rawtp_process_event+0x1b38>
    15a8:      	mov	x8, x24
    15ac:      	mov	w10, #0x5ea0            // =24224
    15b0:      	mov	x22, x25
    15b4:      	mov	x19, x29
    15b8:      	cmp	w8, #0x28
    15bc:      	b.ne	0x1114 <generic_rawtp_process_event+0xf44>
    15c0:      	ldr	x0, [sp, #0x30]
    15c4:      	add	x8, sp, #0xe0
    15c8:      	mov	w9, #0x4                // =4
    15cc:      	mov	w1, #0x2                // =2
    15d0:      	ldr	x23, [x8]
    15d4:      	mov	w8, #0x2                // =2
    15d8:      	str	xzr, [x0]
    15dc:      	stp	xzr, xzr, [x0, #0x8]
    15e0:      	mov	x2, x23
    15e4:      	blr	x9
    15e8:      	tbnz	x0, #0x3f, 0x2434 <generic_rawtp_process_event+0x2264>
    15ec:      	ldr	x8, [sp, #0x30]
    15f0:      	ldrh	w8, [x8]
    15f4:      	cmp	w8, #0xa
    15f8:      	b.eq	0x23ec <generic_rawtp_process_event+0x221c>
    15fc:      	cmp	w8, #0x2
    1600:      	b.ne	0x2420 <generic_rawtp_process_event+0x2250>
    1604:      	add	x2, x23, #0x4
    1608:      	add	x8, sp, #0x98
    160c:      	mov	w9, #0x4                // =4
    1610:      	add	x0, sp, #0x98
    1614:      	mov	w1, #0x4                // =4
    1618:      	mov	w21, #0x4               // =4
    161c:      	blr	x9
    1620:      	ldr	w8, [sp, #0x98]
    1624:      	ldr	x9, [sp, #0x30]
    1628:      	add	x2, x23, #0x2
    162c:      	add	x0, x9, #0x2
    1630:      	str	x8, [x9, #0x8]
    1634:      	mov	w8, #0x2                // =2
    1638:      	b	0x2418 <generic_rawtp_process_event+0x2248>
    163c:      	ldr	x10, [sp, #0x40]
    1640:      	mov	w9, #0x7                // =7
    1644:      	b	0x670 <generic_rawtp_process_event+0x4a0>
    1648:      	mov	x9, x24
    164c:      	cmp	w9, #0x2b
    1650:      	b.eq	0x2030 <generic_rawtp_process_event+0x1e60>
    1654:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    1658:      	cmp	w9, #0x29
    165c:      	ldr	x22, [x22]
    1660:      	ldr	x19, [sp, #0x8]
    1664:      	b.ne	0x1110 <generic_rawtp_process_event+0xf40>
    1668:      	ldr	x8, [sp, #0x48]
    166c:      	mov	w9, #0x4                // =4
    1670:      	add	x10, sp, #0x98
    1674:      	mov	x21, x0
    1678:      	add	x0, sp, #0x98
    167c:      	mov	w1, #0x8                // =8
    1680:      	add	x2, x8, #0x18
    1684:      	mov	w8, #0x8                // =8
    1688:      	blr	x9
    168c:      	ldr	x23, [sp, #0x98]
    1690:      	cbz	x23, 0x2528 <generic_rawtp_process_event+0x2358>
    1694:      	ldr	x29, [sp, #0x30]
    1698:      	add	x2, x23, #0x10
    169c:      	mov	w25, #0x2               // =2
    16a0:      	mov	w8, #0x4                // =4
    16a4:      	str	x23, [x29, #0x28]
    16a8:      	add	x0, x29, #0x26
    16ac:      	mov	w1, #0x2                // =2
    16b0:      	mov	w24, #0x4               // =4
    16b4:      	blr	x8
    16b8:      	add	x0, x29, #0x3a
    16bc:      	add	x2, x23, #0x12
    16c0:      	mov	w8, #0x1                // =1
    16c4:      	mov	w9, #0x4                // =4
    16c8:      	mov	w1, #0x1                // =1
    16cc:      	blr	x9
    16d0:      	add	x0, x29, #0x38
    16d4:      	add	x2, x23, #0x21e
    16d8:      	mov	w8, #0x4                // =4
    16dc:      	mov	w1, #0x2                // =2
    16e0:      	blr	x8
    16e4:      	add	x0, x29, #0x24
    16e8:      	add	x2, x23, #0x21c
    16ec:      	mov	w8, #0x4                // =4
    16f0:      	mov	w1, #0x2                // =2
    16f4:      	blr	x8
    16f8:      	add	x0, x29, #0x30
    16fc:      	add	x2, x23, #0x214
    1700:      	mov	w8, #0x4                // =4
    1704:      	mov	w1, #0x4                // =4
    1708:      	blr	x8
    170c:      	add	x0, x29, #0x34
    1710:      	add	x2, x23, #0x210
    1714:      	mov	w1, #0x4                // =4
    1718:      	blr	x24
    171c:      	ldrh	w8, [x29, #0x26]
    1720:      	mov	x24, x29
    1724:      	stp	xzr, xzr, [x29]
    1728:      	cmp	w8, #0xa
    172c:      	str	xzr, [x29, #0x18]
    1730:      	str	xzr, [x24, #0x10]!
    1734:      	b.eq	0x24b8 <generic_rawtp_process_event+0x22e8>
    1738:      	cmp	w8, #0x2
    173c:      	b.ne	0x24e4 <generic_rawtp_process_event+0x2314>
    1740:      	ldr	x0, [sp, #0x30]
    1744:      	add	x2, x23, #0x4
    1748:      	mov	w8, #0x4                // =4
    174c:      	mov	w1, #0x4                // =4
    1750:      	mov	w25, #0x4               // =4
    1754:      	blr	x8
    1758:      	mov	x0, x24
    175c:      	mov	w1, #0x4                // =4
    1760:      	mov	x2, x23
    1764:      	blr	x25
    1768:      	b	0x24e4 <generic_rawtp_process_event+0x2314>
    176c:      	cmp	w24, #0x1a
    1770:      	b.eq	0x20c0 <generic_rawtp_process_event+0x1ef0>
    1774:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    1778:      	mov	x8, x24
    177c:      	ldr	x22, [x22]
    1780:      	ldr	x19, [sp, #0x8]
    1784:      	cmp	w8, #0x1b
    1788:      	b.ne	0x1110 <generic_rawtp_process_event+0xf40>
    178c:      	ldr	x10, [sp, #0x30]
    1790:      	ldr	x8, [sp, #0x48]
    1794:      	mov	w9, #0x2d               // =45
    1798:      	mov	w1, #0x3f               // =63
    179c:      	mov	x0, x10
    17a0:      	stp	xzr, xzr, [x10, #0x40]
    17a4:      	stp	xzr, xzr, [x10, #0x30]
    17a8:      	stp	xzr, xzr, [x10, #0x20]
    17ac:      	str	xzr, [x10, #0x18]
    17b0:      	stp	xzr, xzr, [x10]
    17b4:      	add	x2, x8, #0x18
    17b8:      	mov	w8, #0x3f               // =63
    17bc:      	str	xzr, [x0, #0x10]!
    17c0:      	blr	x9
    17c4:      	tbnz	x0, #0x3f, 0x2304 <generic_rawtp_process_event+0x2134>
    17c8:      	ldr	x8, [sp, #0x30]
    17cc:      	mov	w9, #0x4                // =4
    17d0:      	mov	w1, #0x8                // =8
    17d4:      	add	x0, x8, #0x8
    17d8:      	ldr	x8, [sp, #0x48]
    17dc:      	add	x2, x8, #0x360
    17e0:      	mov	w8, #0x8                // =8
    17e4:      	blr	x9
    17e8:      	mov	w23, #0x50              // =80
    17ec:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    17f0:      	mov	x9, x24
    17f4:      	mov	w10, #0x5ea0            // =24224
    17f8:      	mov	x22, x25
    17fc:      	mov	x19, x29
    1800:      	cmp	w9, #0x26
    1804:      	b.ne	0x1114 <generic_rawtp_process_event+0xf44>
    1808:      	add	x8, sp, #0xe0
    180c:      	ldr	x9, [sp, #0x30]
    1810:      	ldr	x8, [x8]
    1814:      	add	x0, x9, #0x4
    1818:      	add	x2, x19, w8, uxth
    181c:      	ubfx	w8, w8, #16, #12
    1820:      	add	w1, w8, #0x1
    1824:      	mov	w8, #0x2d               // =45
    1828:      	blr	x8
    182c:      	b	0x1d2c <generic_rawtp_process_event+0x1b5c>
    1830:      	cmp	w8, #0x8
    1834:      	b.eq	0x1d98 <generic_rawtp_process_event+0x1bc8>
    1838:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    183c:      	cmp	w8, #0x12
    1840:      	ldr	x22, [x22]
    1844:      	ldr	x19, [sp, #0x8]
    1848:      	b.ne	0x1110 <generic_rawtp_process_event+0xf40>
    184c:      	ldp	x8, x2, [sp, #0x40]
    1850:      	and	x23, x8, #0x3ff
    1854:      	ldr	x0, [sp, #0x30]
    1858:      	mov	w8, #0x4                // =4
    185c:      	mov	w1, w23
    1860:      	blr	x8
    1864:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    1868:      	cmp	w8, #0x13
    186c:      	b.eq	0x1fec <generic_rawtp_process_event+0x1e1c>
    1870:      	adrp	x22, 0x1000 <generic_rawtp_process_event+0xe30>
    1874:      	cmp	w8, #0x14
    1878:      	ldr	x22, [x22]
    187c:      	ldr	x19, [sp, #0x8]
    1880:      	b.ne	0x1110 <generic_rawtp_process_event+0xf40>
    1884:      	ldr	x29, [sp, #0x48]
    1888:      	str	xzr, [sp, #0x98]
    188c:      	mov	w24, #0x8               // =8
    1890:      	add	x8, sp, #0x98
    1894:      	mov	w9, #0x4                // =4
    1898:      	add	x0, sp, #0x98
    189c:      	mov	w1, #0x8                // =8
    18a0:      	mov	w21, #0x4               // =4
    18a4:      	add	x2, x29, #0x110
    18a8:      	add	x23, x29, #0xd8
    18ac:      	blr	x9
    18b0:      	ldr	x8, [sp, #0x98]
    18b4:      	mov	w9, #0x80               // =128
    18b8:      	mov	w10, #0x2d              // =45
    18bc:      	ldr	x25, [sp, #0x30]
    18c0:      	mov	w1, #0x80               // =128
    18c4:      	mov	x0, x25
    18c8:      	ldr	x2, [sp, #0x98]
    18cc:      	blr	x10
    18d0:      	add	x0, x25, #0x90
    18d4:      	mov	w8, #0x4                // =4
    18d8:      	mov	w1, #0x4                // =4
    18dc:      	mov	x2, x23
    18e0:      	blr	x8
    18e4:      	add	x0, x25, #0x80
    18e8:      	add	x2, x29, #0xe0
    18ec:      	mov	w8, #0x4                // =4
    18f0:      	mov	w1, #0x8                // =8
    18f4:      	blr	x8
    18f8:      	add	x0, x25, #0x88
    18fc:      	add	x2, x29, #0x118
    1900:      	mov	w1, #0x8                // =8
    1904:      	blr	x21
    1908:      	mov	w23, #0x98              // =152
    190c:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    1910:      	add	x8, sp, #0xe0
    1914:      	mov	w9, #0x4                // =4
    1918:      	add	x10, sp, #0x88
    191c:      	ldr	x23, [x8]
    1920:      	mov	w8, #0x1                // =1
    1924:      	mov	x29, x0
    1928:      	add	x0, sp, #0x88
    192c:      	mov	w1, #0x1                // =1
    1930:      	mov	x2, x23
    1934:      	blr	x9
    1938:      	ldrb	w8, [sp, #0x88]
    193c:      	cmp	w8, #0x1
    1940:      	b.ne	0x21a0 <generic_rawtp_process_event+0x1fd0>
    1944:      	add	x2, x23, #0x10
    1948:      	mov	w23, #0x8               // =8
    194c:      	add	x8, sp, #0xf0
    1950:      	mov	w9, #0x4                // =4
    1954:      	add	x0, sp, #0xf0
    1958:      	mov	w1, #0x8                // =8
    195c:      	mov	w24, #0x4               // =4
    1960:      	blr	x9
    1964:      	add	x8, sp, #0xe0
    1968:      	mov	w9, #0x4                // =4
    196c:      	add	x0, sp, #0x70
    1970:      	ldr	x2, [x8, #0x10]
    1974:      	add	x8, sp, #0x70
    1978:      	mov	w1, #0x8                // =8
    197c:      	blr	x9
    1980:      	add	x8, sp, #0xe0
    1984:      	add	x0, sp, #0xe8
    1988:      	mov	w1, #0x8                // =8
    198c:      	ldr	x8, [x8, #0x10]
    1990:      	add	x2, x8, #0x8
    1994:      	add	x8, sp, #0xe8
    1998:      	blr	x24
    199c:      	add	x8, sp, #0xe0
    19a0:      	ldr	x9, [sp, #0x70]
    19a4:      	ldr	x8, [x8, #0x8]
    19a8:      	stp	x9, x8, [sp, #0x40]
    19ac:      	add	x8, x29, #0x90
    19b0:      	add	x29, x8, x25
    19b4:      	tbz	w21, #0x5, 0x245c <generic_rawtp_process_event+0x228c>
    19b8:      	ldr	x9, [sp, #0x48]
    19bc:      	cmp	x9, #0x1, lsl #12       // =0x1000
    19c0:      	b.lo	0x2448 <generic_rawtp_process_event+0x2278>
    19c4:      	mov	w8, #0x1                // =1
    19c8:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    19cc:      	add	x9, sp, #0xd8
    19d0:      	str	w8, [x29]
    19d4:      	str	wzr, [sp, #0xd8]
    19d8:      	add	x1, sp, #0xd8
    19dc:      	ldr	x0, [x0]
    19e0:      	blr	x8
    19e4:      	str	x0, [sp, #0x38]
    19e8:      	cbz	x0, 0x273c <generic_rawtp_process_event+0x256c>
    19ec:      	ldr	x23, [sp, #0x38]
    19f0:      	mov	w8, #0x18               // =24
    19f4:      	str	w8, [x23]
    19f8:      	mov	w8, #0xe                // =14
    19fc:      	blr	x8
    1a00:      	str	x0, [x23, #0x10]!
    1a04:      	cmn	x0, #0x16
    1a08:      	b.ne	0x1a30 <generic_rawtp_process_event+0x1860>
    1a0c:      	add	x2, x19, #0xe8
    1a10:      	mov	w8, #0x8                // =8
    1a14:      	mov	w9, #0x4                // =4
    1a18:      	add	x10, sp, #0x98
    1a1c:      	add	x0, sp, #0x98
    1a20:      	mov	w1, #0x8                // =8
    1a24:      	blr	x9
    1a28:      	ldr	x8, [sp, #0x98]
    1a2c:      	str	x8, [x23]
    1a30:      	mov	w8, #0x7d               // =125
    1a34:      	blr	x8
    1a38:      	ldr	x11, [sp, #0x38]
    1a3c:      	mov	x21, xzr
    1a40:      	mov	x10, x29
    1a44:      	mov	w25, #0xa               // =10
    1a48:      	str	x0, [x11, #0x18]
    1a4c:      	ldp	x8, x9, [x23]
    1a50:      	add	x23, x11, #0x20
    1a54:      	stur	x9, [x29, #0x1c]
    1a58:      	stur	x8, [x29, #0x14]
    1a5c:      	ldr	x8, [sp, #0x48]
    1a60:      	subs	x8, x8, x21
    1a64:      	b.mi	0x2ba8 <generic_rawtp_process_event+0x29d8>
    1a68:      	ldr	x9, [sp, #0x40]
    1a6c:      	mov	x0, x23
    1a70:      	add	x2, x21, x9
    1a74:      	mov	w9, #0x7fe0             // =32736
    1a78:      	cmp	x8, x9
    1a7c:      	csel	x24, x8, x9, lo
    1a80:      	mov	w8, #0x4                // =4
    1a84:      	mov	w1, w24
    1a88:      	blr	x8
    1a8c:      	tbnz	w0, #0x1f, 0x1ac8 <generic_rawtp_process_event+0x18f8>
    1a90:      	ldr	x3, [sp, #0x38]
    1a94:      	add	w4, w24, #0x20
    1a98:      	adrp	x1, 0x1000 <generic_rawtp_process_event+0xe30>
    1a9c:      	mov	w8, #0x19               // =25
    1aa0:      	str	w4, [x3, #0x4]
    1aa4:      	mov	w9, #-0x1               // =-1
    1aa8:      	mov	x0, x19
    1aac:      	mov	w2, #-0x1               // =-1
    1ab0:      	ldr	x1, [x1]
    1ab4:      	blr	x8
    1ab8:      	sxtw	x8, w0
    1abc:      	tst	w0, #0x80000000
    1ac0:      	csel	x8, x24, x8, eq
    1ac4:      	b	0x1acc <generic_rawtp_process_event+0x18fc>
    1ac8:      	sxtw	x8, w0
    1acc:      	tbnz	w8, #0x1f, 0x2bb0 <generic_rawtp_process_event+0x29e0>
    1ad0:      	and	x8, x8, #0x7fffffff
    1ad4:      	add	x21, x8, x21
    1ad8:      	ldr	x8, [sp, #0x48]
    1adc:      	cmp	x21, x8
    1ae0:      	b.eq	0x2bfc <generic_rawtp_process_event+0x2a2c>
    1ae4:      	subs	w25, w25, #0x1
    1ae8:      	b.ne	0x1a5c <generic_rawtp_process_event+0x188c>
    1aec:      	b	0x2f60 <generic_rawtp_process_event+0x2d90>
    1af0:      	add	x8, sp, #0xe0
    1af4:      	ldr	x23, [sp, #0x30]
    1af8:      	mov	w1, #0x4                // =4
    1afc:      	mov	w21, #0x4               // =4
    1b00:      	ldr	x24, [x8]
    1b04:      	mov	w8, #0x4                // =4
    1b08:      	add	x0, x23, #0x28
    1b0c:      	add	x2, x24, #0x98
    1b10:      	blr	x8
    1b14:      	add	x0, x23, #0x2c
    1b18:      	add	x2, x24, #0x70
    1b1c:      	mov	w8, #0x4                // =4
    1b20:      	mov	w1, #0x4                // =4
    1b24:      	blr	x8
    1b28:      	add	x0, x23, #0x30
    1b2c:      	add	x2, x24, #0x90
    1b30:      	mov	w8, #0x4                // =4
    1b34:      	mov	w1, #0x4                // =4
    1b38:      	blr	x8
    1b3c:      	add	x0, x23, #0x34
    1b40:      	add	x2, x24, #0xa8
    1b44:      	mov	w8, #0x4                // =4
    1b48:      	mov	w1, #0x4                // =4
    1b4c:      	blr	x8
    1b50:      	str	xzr, [sp, #0x98]
    1b54:      	add	x2, x24, #0xc8
    1b58:      	mov	w8, #0x8                // =8
    1b5c:      	add	x9, sp, #0x98
    1b60:      	mov	w10, #0x4               // =4
    1b64:      	add	x0, sp, #0x98
    1b68:      	mov	w1, #0x8                // =8
    1b6c:      	blr	x10
    1b70:      	str	x24, [sp, #0x48]
    1b74:      	add	x2, x24, #0xb8
    1b78:      	mov	w8, #0x2                // =2
    1b7c:      	add	x9, sp, #0xe8
    1b80:      	mov	w10, #0x4               // =4
    1b84:      	add	x0, sp, #0xe8
    1b88:      	mov	w1, #0x2                // =2
    1b8c:      	blr	x10
    1b90:      	ldr	x8, [sp, #0x98]
    1b94:      	ldrh	w9, [sp, #0xe8]
    1b98:      	add	x0, sp, #0x84
    1b9c:      	mov	w1, #0x1                // =1
    1ba0:      	add	x23, x8, x9
    1ba4:      	mov	w8, #0x1                // =1
    1ba8:      	add	x9, sp, #0x84
    1bac:      	mov	x2, x23
    1bb0:      	blr	x21
    1bb4:      	ldrb	w8, [sp, #0x84]
    1bb8:      	lsr	w8, w8, #4
    1bbc:      	cmp	w8, #0x6
    1bc0:      	b.eq	0x21c4 <generic_rawtp_process_event+0x1ff4>
    1bc4:      	cmp	w8, #0x4
    1bc8:      	b.ne	0x3464 <generic_rawtp_process_event+0x3294>
    1bcc:      	add	x2, x23, #0x9
    1bd0:      	mov	w8, #0x1                // =1
    1bd4:      	add	x9, sp, #0x88
    1bd8:      	mov	w10, #0x4               // =4
    1bdc:      	add	x0, sp, #0x88
    1be0:      	mov	w1, #0x1                // =1
    1be4:      	mov	w21, #0x4               // =4
    1be8:      	blr	x10
    1bec:      	ldr	x0, [sp, #0x30]
    1bf0:      	ldrb	w8, [sp, #0x88]
    1bf4:      	mov	w25, #0x2               // =2
    1bf8:      	add	x2, x23, #0xc
    1bfc:      	mov	w1, #0x4                // =4
    1c00:      	mov	x24, x0
    1c04:      	strh	w8, [x0, #0x24]
    1c08:      	strh	w25, [x0, #0x26]
    1c0c:      	stp	xzr, xzr, [x0]
    1c10:      	str	xzr, [x0, #0x18]
    1c14:      	mov	w8, #0x4                // =4
    1c18:      	str	xzr, [x24, #0x10]!
    1c1c:      	blr	x8
    1c20:      	add	x2, x23, #0x10
    1c24:      	mov	w8, #0x4                // =4
    1c28:      	mov	x0, x24
    1c2c:      	mov	w1, #0x4                // =4
    1c30:      	blr	x8
    1c34:      	ldr	x8, [sp, #0x48]
    1c38:      	add	x0, sp, #0xd8
    1c3c:      	mov	w1, #0x2                // =2
    1c40:      	add	x2, x8, #0xb6
    1c44:      	add	x8, sp, #0xd8
    1c48:      	blr	x21
    1c4c:      	ldrb	w25, [sp, #0x88]
    1c50:      	b	0x3324 <generic_rawtp_process_event+0x3154>
    1c54:      	str	xzr, [sp, #0xa0]
    1c58:      	mov	w8, #0xe                // =14
    1c5c:      	blr	x8
    1c60:      	lsr	x8, x0, #32
    1c64:      	add	x9, sp, #0xf0
    1c68:      	add	x10, sp, #0xe0
    1c6c:      	str	x8, [sp, #0x98]
    1c70:      	mov	w8, #0x4                // =4
    1c74:      	add	x0, sp, #0xf0
    1c78:      	add	x2, sp, #0xe0
    1c7c:      	mov	w1, #0x4                // =4
    1c80:      	blr	x8
    1c84:      	ldr	w8, [sp, #0xf0]
    1c88:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1c8c:      	add	x9, sp, #0x98
    1c90:      	add	x1, sp, #0x98
    1c94:      	str	w8, [sp, #0xa0]
    1c98:      	mov	w8, #0x1                // =1
    1c9c:      	ldr	x0, [x0]
    1ca0:      	blr	x8
    1ca4:      	cbz	x0, 0x21bc <generic_rawtp_process_event+0x1fec>
    1ca8:      	ldr	x25, [sp, #0x30]
    1cac:      	ldr	w21, [x0]
    1cb0:      	add	x8, sp, #0xf0
    1cb4:      	mov	w9, #0x4                // =4
    1cb8:      	mov	x23, x0
    1cbc:      	add	x2, sp, #0xf0
    1cc0:      	mov	w1, #0x4                // =4
    1cc4:      	mov	w24, #0x4               // =4
    1cc8:      	mov	x0, x25
    1ccc:      	blr	x9
    1cd0:      	and	x21, x21, #0xfff
    1cd4:      	add	x0, x25, #0x4
    1cd8:      	mov	w8, #0x4                // =4
    1cdc:      	mov	x2, x23
    1ce0:      	add	x1, x21, #0x4
    1ce4:      	blr	x8
    1ce8:      	add	w21, w21, #0x8
    1cec:      	mov	w1, #0x4                // =4
    1cf0:      	add	x8, x21, x23
    1cf4:      	add	x0, x25, x21
    1cf8:      	sub	x2, x8, #0x4
    1cfc:      	blr	x24
    1d00:      	add	x23, x21, #0x4
    1d04:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    1d08:      	add	x8, sp, #0xe0
    1d0c:      	mov	w9, #0x2d               // =45
    1d10:      	mov	w1, #0x11               // =17
    1d14:      	ldr	x8, [x8]
    1d18:      	add	x2, x8, #0x118
    1d1c:      	ldr	x8, [sp, #0x30]
    1d20:      	add	x0, x8, #0x4
    1d24:      	mov	w8, #0x11               // =17
    1d28:      	blr	x9
    1d2c:      	mov	x23, x0
    1d30:      	tbnz	x0, #0x3f, 0x2438 <generic_rawtp_process_event+0x2268>
    1d34:      	ldr	x9, [sp, #0x30]
    1d38:      	sub	w8, w23, #0x1
    1d3c:      	add	x23, x23, #0x3
    1d40:      	str	w8, [x9]
    1d44:      	b	0x2438 <generic_rawtp_process_event+0x2268>
    1d48:      	add	x23, x29, #0x90
    1d4c:      	add	x8, x23, x25
    1d50:      	str	x8, [sp, #0x38]
    1d54:      	add	x8, sp, #0xe0
    1d58:      	str	xzr, [x8]
    1d5c:      	tbnz	w21, #0x4, 0x230c <generic_rawtp_process_event+0x213c>
    1d60:      	ldr	x9, [sp, #0x40]
    1d64:      	mov	x8, xzr
    1d68:      	and	x25, x21, #0xffffffff
    1d6c:      	and	w9, w9, #0xf
    1d70:      	cmp	w9, #0x2
    1d74:      	b.le	0x24a0 <generic_rawtp_process_event+0x22d0>
    1d78:      	cmp	w9, #0x3
    1d7c:      	b.eq	0x2744 <generic_rawtp_process_event+0x2574>
    1d80:      	cmp	w9, #0x4
    1d84:      	b.eq	0x274c <generic_rawtp_process_event+0x257c>
    1d88:      	cmp	w9, #0x5
    1d8c:      	b.ne	0x2760 <generic_rawtp_process_event+0x2590>
    1d90:      	mov	w8, #0x5e70             // =24176
    1d94:      	b	0x2758 <generic_rawtp_process_event+0x2588>
    1d98:      	ldr	x29, [sp, #0x48]
    1d9c:      	ldr	x25, [sp, #0x30]
    1da0:      	mov	w8, #0x4                // =4
    1da4:      	mov	w1, #0x4                // =4
    1da8:      	mov	w21, #0x4               // =4
    1dac:      	add	x2, x29, #0x8
    1db0:      	mov	x0, x25
    1db4:      	add	x23, x25, #0x28
    1db8:      	add	x19, x25, #0x40
    1dbc:      	blr	x8
    1dc0:      	add	x0, x25, #0x4
    1dc4:      	add	x2, x29, #0xc
    1dc8:      	mov	w8, #0x4                // =4
    1dcc:      	mov	w1, #0x4                // =4
    1dd0:      	blr	x8
    1dd4:      	add	x0, x25, #0x10
    1dd8:      	add	x2, x29, #0x18
    1ddc:      	mov	w8, #0x4                // =4
    1de0:      	mov	w1, #0x4                // =4
    1de4:      	blr	x8
    1de8:      	add	x0, x25, #0x14
    1dec:      	add	x2, x29, #0x1c
    1df0:      	mov	w8, #0x4                // =4
    1df4:      	mov	w1, #0x4                // =4
    1df8:      	blr	x8
    1dfc:      	add	x0, x25, #0x8
    1e00:      	add	x2, x29, #0x10
    1e04:      	mov	w8, #0x4                // =4
    1e08:      	mov	w1, #0x4                // =4
    1e0c:      	blr	x8
    1e10:      	add	x0, x25, #0xc
    1e14:      	add	x2, x29, #0x14
    1e18:      	mov	w8, #0x4                // =4
    1e1c:      	mov	w1, #0x4                // =4
    1e20:      	blr	x8
    1e24:      	add	x0, x25, #0x18
    1e28:      	add	x2, x29, #0x20
    1e2c:      	mov	w8, #0x4                // =4
    1e30:      	mov	w1, #0x4                // =4
    1e34:      	blr	x8
    1e38:      	add	x0, x25, #0x1c
    1e3c:      	add	x2, x29, #0x24
    1e40:      	mov	w8, #0x4                // =4
    1e44:      	mov	w1, #0x4                // =4
    1e48:      	blr	x8
    1e4c:      	str	wzr, [x25, #0x24]
    1e50:      	add	x0, x25, #0x20
    1e54:      	add	x2, x29, #0x28
    1e58:      	mov	w8, #0x4                // =4
    1e5c:      	mov	w1, #0x4                // =4
    1e60:      	blr	x8
    1e64:      	add	x0, x25, #0x30
    1e68:      	add	x2, x29, #0x40
    1e6c:      	mov	w24, #0x8               // =8
    1e70:      	mov	w8, #0x4                // =4
    1e74:      	mov	w1, #0x8                // =8
    1e78:      	blr	x8
    1e7c:      	add	x0, x25, #0x38
    1e80:      	add	x2, x29, #0x30
    1e84:      	mov	w8, #0x4                // =4
    1e88:      	mov	w1, #0x8                // =8
    1e8c:      	blr	x8
    1e90:      	add	x2, x29, #0x38
    1e94:      	mov	w8, #0x4                // =4
    1e98:      	mov	x0, x23
    1e9c:      	mov	w1, #0x8                // =8
    1ea0:      	blr	x8
    1ea4:      	add	x2, x29, #0x90
    1ea8:      	add	x8, sp, #0x98
    1eac:      	mov	w9, #0x4                // =4
    1eb0:      	add	x0, sp, #0x98
    1eb4:      	mov	w1, #0x8                // =8
    1eb8:      	blr	x9
    1ebc:      	ldr	x23, [sp, #0x98]
    1ec0:      	mov	w8, #0x4                // =4
    1ec4:      	mov	x0, x19
    1ec8:      	mov	w1, #0x4                // =4
    1ecc:      	add	x2, x23, #0xc8
    1ed0:      	blr	x8
    1ed4:      	add	x0, x25, #0x44
    1ed8:      	add	x2, x23, #0xcc
    1edc:      	mov	w8, #0x4                // =4
    1ee0:      	mov	w1, #0x4                // =4
    1ee4:      	blr	x8
    1ee8:      	add	x0, x25, #0x48
    1eec:      	add	x2, x23, #0xd0
    1ef0:      	mov	w8, #0x4                // =4
    1ef4:      	mov	w1, #0x4                // =4
    1ef8:      	blr	x8
    1efc:      	add	x0, x25, #0x4c
    1f00:      	add	x2, x23, #0x158
    1f04:      	mov	w1, #0x4                // =4
    1f08:      	blr	x21
    1f0c:      	mov	w23, #0x50              // =80
    1f10:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    1f14:      	ldr	x24, [sp, #0x48]
    1f18:      	ldr	x23, [sp, #0x30]
    1f1c:      	mov	w8, #0x4                // =4
    1f20:      	mov	w1, #0x4                // =4
    1f24:      	mov	w21, #0x4               // =4
    1f28:      	add	x2, x24, #0xc8
    1f2c:      	mov	x0, x23
    1f30:      	blr	x8
    1f34:      	add	x0, x23, #0x4
    1f38:      	add	x2, x24, #0xcc
    1f3c:      	mov	w8, #0x4                // =4
    1f40:      	mov	w1, #0x4                // =4
    1f44:      	blr	x8
    1f48:      	add	x0, x23, #0x8
    1f4c:      	add	x2, x24, #0xd0
    1f50:      	mov	w8, #0x4                // =4
    1f54:      	mov	w1, #0x4                // =4
    1f58:      	blr	x8
    1f5c:      	add	x0, x23, #0xc
    1f60:      	add	x2, x24, #0x158
    1f64:      	mov	w1, #0x4                // =4
    1f68:      	blr	x21
    1f6c:      	mov	w23, #0x10              // =16
    1f70:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    1f74:      	ldr	x24, [sp, #0x48]
    1f78:      	ldr	x23, [sp, #0x30]
    1f7c:      	mov	w8, #0x4                // =4
    1f80:      	mov	w1, #0x4                // =4
    1f84:      	mov	w21, #0x4               // =4
    1f88:      	add	x2, x24, #0x38
    1f8c:      	mov	x0, x23
    1f90:      	blr	x8
    1f94:      	add	x0, x23, #0x4
    1f98:      	add	x2, x24, #0x3c
    1f9c:      	mov	w8, #0x4                // =4
    1fa0:      	mov	w1, #0x4                // =4
    1fa4:      	blr	x8
    1fa8:      	add	x0, x23, #0x8
    1fac:      	add	x2, x24, #0x40
    1fb0:      	mov	w8, #0x4                // =4
    1fb4:      	mov	w1, #0x4                // =4
    1fb8:      	blr	x8
    1fbc:      	add	x0, x23, #0xc
    1fc0:      	add	x2, x24, #0x44
    1fc4:      	mov	w8, #0x4                // =4
    1fc8:      	mov	w1, #0x4                // =4
    1fcc:      	blr	x8
    1fd0:      	add	x0, x23, #0x10
    1fd4:      	add	x2, x24, #0x80
    1fd8:      	mov	w8, #0x10               // =16
    1fdc:      	mov	w1, #0x10               // =16
    1fe0:      	blr	x21
    1fe4:      	mov	w23, #0x20              // =32
    1fe8:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    1fec:      	ldr	x23, [sp, #0x30]
    1ff0:      	ldr	x24, [sp, #0x48]
    1ff4:      	mov	w8, #0x4                // =4
    1ff8:      	mov	w1, #0x4                // =4
    1ffc:      	mov	w21, #0x4               // =4
    2000:      	mov	x0, x23
    2004:      	mov	x2, x24
    2008:      	blr	x8
    200c:      	add	x0, x23, #0x4
    2010:      	add	x2, x24, #0x4
    2014:      	mov	w8, #0x4                // =4
    2018:      	mov	w1, #0x4                // =4
    201c:      	blr	x8
    2020:      	add	x0, x23, #0x8
    2024:      	add	x2, x24, #0x30
    2028:      	mov	w8, #0x10               // =16
    202c:      	b	0x20b0 <generic_rawtp_process_event+0x1ee0>
    2030:      	ldr	x24, [sp, #0x48]
    2034:      	add	x8, sp, #0x98
    2038:      	mov	w9, #0x4                // =4
    203c:      	add	x0, sp, #0x98
    2040:      	mov	w1, #0x4                // =4
    2044:      	mov	w21, #0x4               // =4
    2048:      	add	x2, x24, #0x4
    204c:      	blr	x9
    2050:      	ldr	w8, [sp, #0x98]
    2054:      	ldr	x23, [sp, #0x30]
    2058:      	add	x2, x24, #0xc
    205c:      	add	x0, sp, #0x98
    2060:      	mov	w1, #0x4                // =4
    2064:      	str	w8, [x23]
    2068:      	add	x8, sp, #0x98
    206c:      	blr	x21
    2070:      	ldr	w8, [sp, #0x98]
    2074:      	add	x2, x24, #0x50
    2078:      	add	x9, sp, #0x98
    207c:      	mov	w10, #0x2d              // =45
    2080:      	str	w8, [x23, #0x4]
    2084:      	mov	w8, #0x8                // =8
    2088:      	add	x0, sp, #0x98
    208c:      	mov	w1, #0x8                // =8
    2090:      	mov	w21, #0x2d              // =45
    2094:      	blr	x10
    2098:      	ldr	x8, [sp, #0x98]
    209c:      	add	x0, x23, #0x8
    20a0:      	mov	w9, #0x10               // =16
    20a4:      	add	x8, x8, #0x3f8
    20a8:      	ldr	x8, [sp, #0x98]
    20ac:      	add	x2, x8, #0x3f8
    20b0:      	mov	w1, #0x10               // =16
    20b4:      	blr	x21
    20b8:      	mov	w23, #0x18              // =24
    20bc:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    20c0:      	ldr	x11, [sp, #0x30]
    20c4:      	ldr	x2, [sp, #0x48]
    20c8:      	mov	w8, #0x8                // =8
    20cc:      	mov	w9, #0x4                // =4
    20d0:      	add	x10, sp, #0x98
    20d4:      	add	x0, sp, #0x98
    20d8:      	mov	w1, #0x8                // =8
    20dc:      	stp	xzr, xzr, [x11, #0x40]
    20e0:      	stp	xzr, xzr, [x11, #0x30]
    20e4:      	stp	xzr, xzr, [x11, #0x20]
    20e8:      	stp	xzr, xzr, [x11, #0x10]
    20ec:      	stp	xzr, xzr, [x11]
    20f0:      	blr	x9
    20f4:      	mov	x23, xzr
    20f8:      	cbnz	x0, 0x2b98 <generic_rawtp_process_event+0x29c8>
    20fc:      	ldr	x8, [sp, #0x30]
    2100:      	mov	w9, #0x3f               // =63
    2104:      	mov	w10, #0x2d              // =45
    2108:      	mov	w1, #0x3f               // =63
    210c:      	add	x0, x8, #0x10
    2110:      	ldr	x8, [sp, #0x98]
    2114:      	ldr	x2, [sp, #0x98]
    2118:      	blr	x10
    211c:      	tbnz	x0, #0x3f, 0x2304 <generic_rawtp_process_event+0x2134>
    2120:      	ldr	x24, [sp, #0x48]
    2124:      	mov	w21, #0x8               // =8
    2128:      	add	x8, sp, #0xf0
    212c:      	mov	w9, #0x4                // =4
    2130:      	add	x0, sp, #0xf0
    2134:      	mov	w1, #0x8                // =8
    2138:      	mov	w23, #0x4               // =4
    213c:      	add	x2, x24, #0x8
    2140:      	blr	x9
    2144:      	ldr	x8, [sp, #0x30]
    2148:      	add	x10, sp, #0xe0
    214c:      	mov	w9, #0x4                // =4
    2150:      	mov	w1, #0x8                // =8
    2154:      	add	x0, x8, #0x8
    2158:      	ldr	x8, [x10, #0x10]
    215c:      	add	x8, x8, #0x360
    2160:      	ldr	x8, [x10, #0x10]
    2164:      	add	x2, x8, #0x360
    2168:      	blr	x9
    216c:      	add	x2, x24, #0x58
    2170:      	add	x8, sp, #0xf0
    2174:      	add	x0, sp, #0xf0
    2178:      	mov	w1, #0x4                // =4
    217c:      	blr	x23
    2180:      	cbnz	x0, 0x2198 <generic_rawtp_process_event+0x1fc8>
    2184:      	ldr	w8, [sp, #0xf0]
    2188:      	ldr	x9, [sp, #0x30]
    218c:      	cmp	w8, #0x0
    2190:      	cset	w8, ne
    2194:      	str	w8, [x9]
    2198:      	mov	w23, #0x50              // =80
    219c:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    21a0:      	add	x8, x29, x25
    21a4:      	mov	w23, #0x8               // =8
    21a8:      	str	xzr, [x8, #0x90]
    21ac:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    21b0:      	ldr	x10, [sp, #0x40]
    21b4:      	mov	w9, #0x9                // =9
    21b8:      	b	0x670 <generic_rawtp_process_event+0x4a0>
    21bc:      	mov	x23, #-0x1              // =-1
    21c0:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    21c4:      	str	wzr, [sp, #0xf0]
    21c8:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    21cc:      	ldr	x29, [sp, #0x98]
    21d0:      	mov	w8, #0x1                // =1
    21d4:      	add	x9, sp, #0xf0
    21d8:      	add	x1, sp, #0xf0
    21dc:      	ldrh	w23, [sp, #0xe8]
    21e0:      	ldr	x0, [x0]
    21e4:      	add	x21, x29, x23
    21e8:      	blr	x8
    21ec:      	cbz	x0, 0x32e0 <generic_rawtp_process_event+0x3110>
    21f0:      	mov	w8, #0xff               // =255
    21f4:      	strh	w23, [x0]
    21f8:      	strb	wzr, [x0, #0x7]
    21fc:      	add	x23, x0, #0x6
    2200:      	add	x2, x21, #0x6
    2204:      	mov	w9, #0x4                // =4
    2208:      	strb	w8, [x0, #0x5]
    220c:      	mov	w8, #0x1                // =1
    2210:      	mov	x24, x0
    2214:      	mov	x0, x23
    2218:      	mov	w1, #0x1                // =1
    221c:      	blr	x9
    2220:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    2224:      	ldrb	w8, [x24, #0x5]
    2228:      	cmp	w8, #0x32
    222c:      	b.gt	0x26b8 <generic_rawtp_process_event+0x24e8>
    2230:      	cbz	w8, 0x2730 <generic_rawtp_process_event+0x2560>
    2234:      	cmp	w8, #0x2b
    2238:      	b.eq	0x2730 <generic_rawtp_process_event+0x2560>
    223c:      	cmp	w8, #0x2c
    2240:      	b.ne	0x2cc4 <generic_rawtp_process_event+0x2af4>
    2244:      	mov	w8, #0x8                // =8
    2248:      	b	0x2c10 <generic_rawtp_process_event+0x2a40>
    224c:      	ldr	x0, [sp, #0x30]
    2250:      	add	x2, x23, #0x48
    2254:      	mov	w25, #0x10              // =16
    2258:      	mov	w8, #0x4                // =4
    225c:      	mov	w1, #0x10               // =16
    2260:      	mov	w29, #0x4               // =4
    2264:      	blr	x8
    2268:      	add	x2, x23, #0x38
    226c:      	mov	x0, x24
    2270:      	mov	w1, #0x10               // =16
    2274:      	blr	x29
    2278:      	ldr	x29, [sp, #0x30]
    227c:      	add	x24, x23, #0xc
    2280:      	add	x2, x23, #0xe
    2284:      	mov	w23, #0x2               // =2
    2288:      	mov	w8, #0x4                // =4
    228c:      	mov	w1, #0x2                // =2
    2290:      	mov	w25, #0x4               // =4
    2294:      	add	x0, x29, #0x20
    2298:      	blr	x8
    229c:      	add	x0, x29, #0x22
    22a0:      	mov	w1, #0x2                // =2
    22a4:      	mov	x2, x24
    22a8:      	blr	x25
    22ac:      	ldrh	w8, [x29, #0x22]
    22b0:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    22b4:      	add	x9, sp, #0x98
    22b8:      	add	x1, sp, #0x98
    22bc:      	rev	w8, w8
    22c0:      	lsr	w8, w8, #16
    22c4:      	strh	w8, [x29, #0x22]
    22c8:      	add	x8, sp, #0xe0
    22cc:      	ldr	x8, [x8]
    22d0:      	str	x8, [sp, #0x98]
    22d4:      	mov	w8, #0x1                // =1
    22d8:      	ldr	x0, [x0]
    22dc:      	blr	x8
    22e0:      	cbz	x0, 0x3464 <generic_rawtp_process_event+0x3294>
    22e4:      	ldr	w8, [x0]
    22e8:      	mov	w23, #0x40              // =64
    22ec:      	str	w8, [x21, #0x10]
    22f0:      	ldr	x8, [x0, #0x8]
    22f4:      	str	x8, [x21, #0x18]
    22f8:      	ldr	w8, [x0, #0x4]
    22fc:      	str	w8, [x21, #0x7c]
    2300:      	b	0x3468 <generic_rawtp_process_event+0x3298>
    2304:      	mov	x23, xzr
    2308:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    230c:      	mov	w8, #0xe                // =14
    2310:      	blr	x8
    2314:      	cmn	x0, #0x16
    2318:      	b.ne	0x2340 <generic_rawtp_process_event+0x2170>
    231c:      	ldr	x8, [sp, #0x8]
    2320:      	mov	w9, #0x4                // =4
    2324:      	add	x10, sp, #0x98
    2328:      	add	x0, sp, #0x98
    232c:      	mov	w1, #0x8                // =8
    2330:      	add	x2, x8, #0xe8
    2334:      	mov	w8, #0x8                // =8
    2338:      	blr	x9
    233c:      	ldr	x0, [sp, #0x98]
    2340:      	ldr	x10, [x29, #0x8]
    2344:      	ldr	x9, [sp, #0x48]
    2348:      	mov	x3, xzr
    234c:      	add	x1, sp, #0xf0
    2350:      	add	x2, sp, #0x98
    2354:      	ldr	x8, [x29, #0x60]
    2358:      	str	xzr, [sp, #0xa8]
    235c:      	stp	x10, x9, [sp, #0x98]
    2360:      	add	x9, sp, #0xe0
    2364:      	add	x10, sp, #0x98
    2368:      	stp	x8, x0, [x9, #0x10]
    236c:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2370:      	mov	w8, #0x2                // =2
    2374:      	add	x9, sp, #0xf0
    2378:      	ldr	x0, [x0]
    237c:      	blr	x8
    2380:      	cbz	x0, 0x26fc <generic_rawtp_process_event+0x252c>
    2384:      	neg	w8, w0
    2388:      	adrp	x23, 0x2000 <generic_rawtp_process_event+0x1e30>
    238c:      	mov	w9, #0x1                // =1
    2390:      	strh	w8, [sp, #0x70]
    2394:      	mov	w8, #0x5                // =5
    2398:      	add	x1, sp, #0x70
    239c:      	mov	w21, #0x1               // =1
    23a0:      	strh	w8, [sp, #0x72]
    23a4:      	mov	x8, #0x46               // =70
    23a8:      	movk	x8, #0x2, lsl #32
    23ac:      	stur	x8, [sp, #0x74]
    23b0:      	add	x8, sp, #0x70
    23b4:      	ldr	x23, [x23]
    23b8:      	mov	x0, x23
    23bc:      	blr	x9
    23c0:      	cbz	x0, 0x26d8 <generic_rawtp_process_event+0x2508>
    23c4:      	ldr	w8, [x0]
    23c8:      	add	w8, w8, #0x1
    23cc:      	str	w8, [x0]
    23d0:      	b	0x26fc <generic_rawtp_process_event+0x252c>
    23d4:      	cmp	w8, #0x1
    23d8:      	b.eq	0x2580 <generic_rawtp_process_event+0x23b0>
    23dc:      	cmp	w8, #0x2
    23e0:      	b.ne	0x25cc <generic_rawtp_process_event+0x23fc>
    23e4:      	mov	w8, #0x5e58             // =24152
    23e8:      	b	0x2584 <generic_rawtp_process_event+0x23b4>
    23ec:      	ldr	x24, [sp, #0x30]
    23f0:      	add	x2, x23, #0x8
    23f4:      	mov	w8, #0x10               // =16
    23f8:      	mov	w9, #0x4                // =4
    23fc:      	mov	w1, #0x10               // =16
    2400:      	mov	w21, #0x4               // =4
    2404:      	add	x0, x24, #0x8
    2408:      	blr	x9
    240c:      	add	x0, x24, #0x2
    2410:      	add	x2, x23, #0x2
    2414:      	mov	w8, #0x2                // =2
    2418:      	mov	w1, #0x2                // =2
    241c:      	blr	x21
    2420:      	ldr	x9, [sp, #0x30]
    2424:      	ldrh	w8, [x9, #0x2]
    2428:      	rev	w8, w8
    242c:      	lsr	w8, w8, #16
    2430:      	strh	w8, [x9, #0x2]
    2434:      	mov	w23, #0x18              // =24
    2438:      	mov	w10, #0x5ea0            // =24224
    243c:      	mov	x22, x25
    2440:      	mov	x19, x29
    2444:      	b	0x1114 <generic_rawtp_process_event+0xf44>
    2448:      	ldr	x9, [sp, #0x108]
    244c:      	str	wzr, [x29]
    2450:      	mov	w23, #0xc               // =12
    2454:      	add	x8, x8, x9
    2458:      	add	x29, x8, #0x8
    245c:      	ldp	x2, x9, [sp, #0x40]
    2460:      	mov	w8, #0xfff              // =4095
    2464:      	add	x0, x29, #0x8
    2468:      	cmp	x9, #0xfff
    246c:      	csel	x24, x9, x8, lo
    2470:      	mov	w8, #0x4                // =4
    2474:      	mov	w1, w24
    2478:      	blr	x8
    247c:      	tbnz	w0, #0x1f, 0x2490 <generic_rawtp_process_event+0x22c0>
    2480:      	ldr	x8, [sp, #0x48]
    2484:      	add	x23, x23, x24
    2488:      	stp	w8, w24, [x29]
    248c:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    2490:      	mov	w8, #-0x2               // =-2
    2494:      	mov	w23, #0x4               // =4
    2498:      	str	w8, [x29]
    249c:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    24a0:      	cmp	w9, #0x1
    24a4:      	b.eq	0x2754 <generic_rawtp_process_event+0x2584>
    24a8:      	cmp	w9, #0x2
    24ac:      	b.ne	0x2760 <generic_rawtp_process_event+0x2590>
    24b0:      	mov	w8, #0x5e58             // =24152
    24b4:      	b	0x2758 <generic_rawtp_process_event+0x2588>
    24b8:      	ldr	x0, [sp, #0x30]
    24bc:      	add	x2, x23, #0x48
    24c0:      	mov	w25, #0x10              // =16
    24c4:      	mov	w8, #0x4                // =4
    24c8:      	mov	w1, #0x10               // =16
    24cc:      	mov	w29, #0x4               // =4
    24d0:      	blr	x8
    24d4:      	add	x2, x23, #0x38
    24d8:      	mov	x0, x24
    24dc:      	mov	w1, #0x10               // =16
    24e0:      	blr	x29
    24e4:      	ldr	x29, [sp, #0x30]
    24e8:      	add	x24, x23, #0xc
    24ec:      	add	x2, x23, #0xe
    24f0:      	mov	w23, #0x2               // =2
    24f4:      	mov	w8, #0x4                // =4
    24f8:      	mov	w1, #0x2                // =2
    24fc:      	mov	w25, #0x4               // =4
    2500:      	add	x0, x29, #0x20
    2504:      	blr	x8
    2508:      	add	x0, x29, #0x22
    250c:      	mov	w1, #0x2                // =2
    2510:      	mov	x2, x24
    2514:      	blr	x25
    2518:      	ldrh	w8, [x29, #0x22]
    251c:      	rev	w8, w8
    2520:      	lsr	w8, w8, #16
    2524:      	strh	w8, [x29, #0x22]
    2528:      	ldr	x8, [sp, #0x30]
    252c:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2530:      	add	x9, sp, #0x98
    2534:      	add	x1, sp, #0x98
    2538:      	ldr	x8, [x8, #0x28]
    253c:      	str	x8, [sp, #0x98]
    2540:      	mov	w8, #0x1                // =1
    2544:      	ldr	x0, [x0]
    2548:      	blr	x8
    254c:      	cbz	x0, 0x2568 <generic_rawtp_process_event+0x2398>
    2550:      	ldr	w8, [x0]
    2554:      	str	w8, [x21, #0x10]
    2558:      	ldr	x8, [x0, #0x8]
    255c:      	str	x8, [x21, #0x18]
    2560:      	ldr	w8, [x0, #0x4]
    2564:      	str	w8, [x21, #0x7c]
    2568:      	mov	w23, #0x40              // =64
    256c:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    2570:      	mov	w8, #0x5e60             // =24160
    2574:      	b	0x2584 <generic_rawtp_process_event+0x23b4>
    2578:      	mov	w8, #0x5e68             // =24168
    257c:      	b	0x2584 <generic_rawtp_process_event+0x23b4>
    2580:      	mov	w8, #0x5e50             // =24144
    2584:      	add	x8, x29, x8
    2588:      	ldr	x21, [x8]
    258c:      	ldr	x8, [sp, #0x40]
    2590:      	tbnz	w8, #0x4, 0x25dc <generic_rawtp_process_event+0x240c>
    2594:      	cbz	x21, 0x26a8 <generic_rawtp_process_event+0x24d8>
    2598:      	ldr	x2, [sp, #0x48]
    259c:      	mov	w8, #0x10               // =16
    25a0:      	mov	w9, #0x4                // =4
    25a4:      	add	x10, sp, #0x98
    25a8:      	add	x0, sp, #0x98
    25ac:      	mov	w1, #0x10               // =16
    25b0:      	blr	x9
    25b4:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    25b8:      	ldr	x23, [sp, #0xa0]
    25bc:      	cmp	x23, #0xffe
    25c0:      	b.ls	0x2928 <generic_rawtp_process_event+0x2758>
    25c4:      	mov	w8, #-0x3               // =-3
    25c8:      	b	0x2b90 <generic_rawtp_process_event+0x29c0>
    25cc:      	ldr	x8, [sp, #0x40]
    25d0:      	mov	x21, xzr
    25d4:      	mov	x23, xzr
    25d8:      	tbz	w8, #0x4, 0x26ac <generic_rawtp_process_event+0x24dc>
    25dc:      	mov	w8, #0xe                // =14
    25e0:      	blr	x8
    25e4:      	cmn	x0, #0x16
    25e8:      	b.ne	0x2610 <generic_rawtp_process_event+0x2440>
    25ec:      	ldr	x8, [sp, #0x8]
    25f0:      	mov	w9, #0x4                // =4
    25f4:      	add	x10, sp, #0x98
    25f8:      	add	x0, sp, #0x98
    25fc:      	mov	w1, #0x8                // =8
    2600:      	add	x2, x8, #0xe8
    2604:      	mov	w8, #0x8                // =8
    2608:      	blr	x9
    260c:      	ldr	x0, [sp, #0x98]
    2610:      	ldr	x10, [x29, #0x8]
    2614:      	ldr	x9, [sp, #0x48]
    2618:      	mov	x3, xzr
    261c:      	add	x1, sp, #0xf0
    2620:      	add	x2, sp, #0x98
    2624:      	ldr	x8, [x29, #0x60]
    2628:      	str	x21, [sp, #0xa8]
    262c:      	stp	x10, x9, [sp, #0x98]
    2630:      	add	x9, sp, #0xe0
    2634:      	add	x10, sp, #0x98
    2638:      	stp	x8, x0, [x9, #0x10]
    263c:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2640:      	mov	w8, #0x2                // =2
    2644:      	add	x9, sp, #0xf0
    2648:      	ldr	x0, [x0]
    264c:      	blr	x8
    2650:      	cbz	x0, 0x2728 <generic_rawtp_process_event+0x2558>
    2654:      	neg	w8, w0
    2658:      	adrp	x23, 0x2000 <generic_rawtp_process_event+0x1e30>
    265c:      	mov	w9, #0x1                // =1
    2660:      	strh	w8, [sp, #0x70]
    2664:      	mov	w8, #0x5                // =5
    2668:      	add	x1, sp, #0x70
    266c:      	mov	w21, #0x1               // =1
    2670:      	strh	w8, [sp, #0x72]
    2674:      	mov	x8, #0x57               // =87
    2678:      	movk	x8, #0x2, lsl #32
    267c:      	stur	x8, [sp, #0x74]
    2680:      	add	x8, sp, #0x70
    2684:      	ldr	x23, [x23]
    2688:      	mov	x0, x23
    268c:      	blr	x9
    2690:      	cbz	x0, 0x2704 <generic_rawtp_process_event+0x2534>
    2694:      	ldr	w8, [x0]
    2698:      	add	w8, w8, #0x1
    269c:      	str	w8, [x0]
    26a0:      	mov	w8, #-0x4               // =-4
    26a4:      	b	0x2b90 <generic_rawtp_process_event+0x29c0>
    26a8:      	mov	x23, xzr
    26ac:      	stp	w23, w23, [x25]
    26b0:      	add	x23, x23, #0x8
    26b4:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    26b8:      	cmp	w8, #0x33
    26bc:      	b.eq	0x2c04 <generic_rawtp_process_event+0x2a34>
    26c0:      	cmp	w8, #0x3c
    26c4:      	b.eq	0x2730 <generic_rawtp_process_event+0x2560>
    26c8:      	cmp	w8, #0xff
    26cc:      	b.ne	0x2cc4 <generic_rawtp_process_event+0x2af4>
    26d0:      	mov	w8, #0x28               // =40
    26d4:      	b	0x2c10 <generic_rawtp_process_event+0x2a40>
    26d8:      	str	w21, [sp, #0xd8]
    26dc:      	mov	x3, xzr
    26e0:      	mov	w8, #0x2                // =2
    26e4:      	add	x9, sp, #0x70
    26e8:      	add	x10, sp, #0xd8
    26ec:      	add	x1, sp, #0x70
    26f0:      	add	x2, sp, #0xd8
    26f4:      	mov	x0, x23
    26f8:      	blr	x8
    26fc:      	mov	w8, #-0x4               // =-4
    2700:      	b	0x2918 <generic_rawtp_process_event+0x2748>
    2704:      	str	w21, [sp, #0xe8]
    2708:      	mov	x3, xzr
    270c:      	mov	w8, #0x2                // =2
    2710:      	add	x9, sp, #0x70
    2714:      	add	x10, sp, #0xe8
    2718:      	add	x1, sp, #0x70
    271c:      	add	x2, sp, #0xe8
    2720:      	mov	x0, x23
    2724:      	blr	x8
    2728:      	mov	w8, #-0x4               // =-4
    272c:      	b	0x2b90 <generic_rawtp_process_event+0x29c0>
    2730:      	ldrb	w8, [x24, #0x7]
    2734:      	lsl	w8, w8, #3
    2738:      	b	0x2c0c <generic_rawtp_process_event+0x2a3c>
    273c:      	mov	w23, #0x4               // =4
    2740:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    2744:      	mov	w8, #0x5e60             // =24160
    2748:      	b	0x2758 <generic_rawtp_process_event+0x2588>
    274c:      	mov	w8, #0x5e68             // =24168
    2750:      	b	0x2758 <generic_rawtp_process_event+0x2588>
    2754:      	mov	w8, #0x5e50             // =24144
    2758:      	add	x8, x29, x8
    275c:      	ldr	x8, [x8]
    2760:      	add	x21, sp, #0xe0
    2764:      	mov	w24, #0x8               // =8
    2768:      	add	x9, sp, #0xe0
    276c:      	str	x8, [x21, #0x8]
    2770:      	mov	w8, #0x4                // =4
    2774:      	add	x10, sp, #0xe8
    2778:      	add	x0, sp, #0xe0
    277c:      	add	x2, sp, #0xe8
    2780:      	mov	w1, #0x8                // =8
    2784:      	blr	x8
    2788:      	ldr	x21, [x21]
    278c:      	tbz	w25, #0x5, 0x28dc <generic_rawtp_process_event+0x270c>
    2790:      	cmp	x21, #0x1, lsl #12      // =0x1000
    2794:      	b.lo	0x28c0 <generic_rawtp_process_event+0x26f0>
    2798:      	ldr	x9, [sp, #0x38]
    279c:      	mov	w8, #0x1                // =1
    27a0:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    27a4:      	add	x1, sp, #0xf0
    27a8:      	str	w8, [x9]
    27ac:      	str	wzr, [sp, #0xf0]
    27b0:      	add	x9, sp, #0xf0
    27b4:      	ldr	x0, [x0]
    27b8:      	blr	x8
    27bc:      	cbz	x0, 0x2b94 <generic_rawtp_process_event+0x29c4>
    27c0:      	mov	w8, #0x18               // =24
    27c4:      	mov	x22, x0
    27c8:      	str	w8, [x0]
    27cc:      	mov	w8, #0xe                // =14
    27d0:      	blr	x8
    27d4:      	mov	x23, x22
    27d8:      	cmn	x0, #0x16
    27dc:      	str	x0, [x23, #0x10]!
    27e0:      	b.ne	0x280c <generic_rawtp_process_event+0x263c>
    27e4:      	ldr	x8, [sp, #0x8]
    27e8:      	mov	w9, #0x4                // =4
    27ec:      	add	x10, sp, #0x98
    27f0:      	add	x0, sp, #0x98
    27f4:      	mov	w1, #0x8                // =8
    27f8:      	add	x2, x8, #0xe8
    27fc:      	mov	w8, #0x8                // =8
    2800:      	blr	x9
    2804:      	ldr	x8, [sp, #0x98]
    2808:      	str	x8, [x23]
    280c:      	mov	w8, #0x7d               // =125
    2810:      	blr	x8
    2814:      	str	x0, [x22, #0x18]
    2818:      	ldr	x10, [sp, #0x38]
    281c:      	mov	x25, xzr
    2820:      	add	x19, x22, #0x20
    2824:      	mov	w29, #0xa               // =10
    2828:      	mov	w24, #0x7fe0            // =32736
    282c:      	ldp	x8, x9, [x23]
    2830:      	stur	x9, [x10, #0x1c]
    2834:      	stur	x8, [x10, #0x14]
    2838:      	subs	x8, x21, x25
    283c:      	b.mi	0x2d08 <generic_rawtp_process_event+0x2b38>
    2840:      	ldr	x9, [sp, #0x48]
    2844:      	cmp	x8, x24
    2848:      	mov	x0, x19
    284c:      	csel	x23, x8, x24, lo
    2850:      	mov	w8, #0x4                // =4
    2854:      	mov	w1, w23
    2858:      	add	x2, x25, x9
    285c:      	blr	x8
    2860:      	tbnz	w0, #0x1f, 0x289c <generic_rawtp_process_event+0x26cc>
    2864:      	add	w4, w23, #0x20
    2868:      	adrp	x1, 0x2000 <generic_rawtp_process_event+0x1e30>
    286c:      	ldr	x0, [sp, #0x8]
    2870:      	mov	w8, #0x19               // =25
    2874:      	str	w4, [x22, #0x4]
    2878:      	mov	w9, #-0x1               // =-1
    287c:      	mov	w2, #-0x1               // =-1
    2880:      	mov	x3, x22
    2884:      	ldr	x1, [x1]
    2888:      	blr	x8
    288c:      	sxtw	x8, w0
    2890:      	tst	w0, #0x80000000
    2894:      	csel	x8, x23, x8, eq
    2898:      	b	0x28a0 <generic_rawtp_process_event+0x26d0>
    289c:      	sxtw	x8, w0
    28a0:      	tbnz	w8, #0x1f, 0x2d10 <generic_rawtp_process_event+0x2b40>
    28a4:      	and	x8, x8, #0x7fffffff
    28a8:      	add	x25, x8, x25
    28ac:      	cmp	x25, x21
    28b0:      	b.eq	0x2d5c <generic_rawtp_process_event+0x2b8c>
    28b4:      	subs	w29, w29, #0x1
    28b8:      	b.ne	0x2838 <generic_rawtp_process_event+0x2668>
    28bc:      	b	0x30a0 <generic_rawtp_process_event+0x2ed0>
    28c0:      	ldr	x8, [sp, #0x38]
    28c4:      	mov	w24, #0xc               // =12
    28c8:      	str	wzr, [x8]
    28cc:      	ldr	x8, [sp, #0x108]
    28d0:      	add	x8, x23, x8
    28d4:      	add	x8, x8, #0x8
    28d8:      	str	x8, [sp, #0x38]
    28dc:      	cmp	x21, #0xfff
    28e0:      	mov	w8, #0xfff              // =4095
    28e4:      	ldr	x2, [sp, #0x48]
    28e8:      	csel	x23, x21, x8, lo
    28ec:      	ldr	x8, [sp, #0x38]
    28f0:      	mov	w1, w23
    28f4:      	add	x0, x8, #0x8
    28f8:      	mov	w8, #0x4                // =4
    28fc:      	blr	x8
    2900:      	tbnz	w0, #0x1f, 0x2914 <generic_rawtp_process_event+0x2744>
    2904:      	ldr	x8, [sp, #0x38]
    2908:      	stp	w21, w23, [x8]
    290c:      	add	x23, x24, x23
    2910:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    2914:      	mov	w8, #-0x2               // =-2
    2918:      	ldr	x9, [sp, #0x38]
    291c:      	mov	w23, #0x4               // =4
    2920:      	str	w8, [x9]
    2924:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    2928:      	ldr	x8, [sp, #0x108]
    292c:      	mov	w9, #0x4                // =4
    2930:      	mov	w1, w23
    2934:      	add	x29, x8, #0xc
    2938:      	ldr	x8, [sp, #0x98]
    293c:      	add	x0, x24, x29
    2940:      	ldr	x2, [sp, #0x98]
    2944:      	blr	x9
    2948:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    294c:      	cmp	x21, #0x1
    2950:      	b.eq	0x26ac <generic_rawtp_process_event+0x24dc>
    2954:      	ldr	x8, [sp, #0x48]
    2958:      	mov	w9, #0x4                // =4
    295c:      	add	x10, sp, #0x98
    2960:      	add	x0, sp, #0x98
    2964:      	mov	w1, #0x10               // =16
    2968:      	add	x2, x8, #0x10
    296c:      	mov	w8, #0x10               // =16
    2970:      	blr	x9
    2974:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2978:      	ldr	x22, [sp, #0xa0]
    297c:      	cmp	x22, #0xffe
    2980:      	b.hi	0x25c4 <generic_rawtp_process_event+0x23f4>
    2984:      	add	x29, x23, x29
    2988:      	ldr	x8, [sp, #0x98]
    298c:      	mov	w9, #0x4                // =4
    2990:      	mov	w1, w22
    2994:      	add	x0, x24, x29
    2998:      	ldr	x2, [sp, #0x98]
    299c:      	blr	x9
    29a0:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    29a4:      	add	x23, x22, x23
    29a8:      	cmp	x21, #0x3
    29ac:      	b.lo	0x26ac <generic_rawtp_process_event+0x24dc>
    29b0:      	ldr	x8, [sp, #0x48]
    29b4:      	mov	w9, #0x4                // =4
    29b8:      	add	x10, sp, #0x98
    29bc:      	add	x0, sp, #0x98
    29c0:      	mov	w1, #0x10               // =16
    29c4:      	add	x2, x8, #0x20
    29c8:      	mov	w8, #0x10               // =16
    29cc:      	blr	x9
    29d0:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    29d4:      	ldr	x19, [sp, #0xa0]
    29d8:      	cmp	x19, #0xffe
    29dc:      	b.hi	0x25c4 <generic_rawtp_process_event+0x23f4>
    29e0:      	add	x29, x22, x29
    29e4:      	mov	w9, #0x4                // =4
    29e8:      	mov	w1, w19
    29ec:      	and	x8, x29, #0x3fff
    29f0:      	add	x0, x24, x8
    29f4:      	ldr	x8, [sp, #0x98]
    29f8:      	ldr	x2, [sp, #0x98]
    29fc:      	blr	x9
    2a00:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2a04:      	add	x23, x19, x23
    2a08:      	cmp	x21, #0x3
    2a0c:      	b.eq	0x26ac <generic_rawtp_process_event+0x24dc>
    2a10:      	ldr	x8, [sp, #0x48]
    2a14:      	mov	w9, #0x4                // =4
    2a18:      	add	x10, sp, #0x98
    2a1c:      	add	x0, sp, #0x98
    2a20:      	mov	w1, #0x10               // =16
    2a24:      	add	x2, x8, #0x30
    2a28:      	mov	w8, #0x10               // =16
    2a2c:      	blr	x9
    2a30:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2a34:      	ldr	x22, [sp, #0xa0]
    2a38:      	cmp	x22, #0xffe
    2a3c:      	b.hi	0x25c4 <generic_rawtp_process_event+0x23f4>
    2a40:      	add	x29, x19, x29
    2a44:      	mov	w9, #0x4                // =4
    2a48:      	mov	w1, w22
    2a4c:      	and	x8, x29, #0x3fff
    2a50:      	add	x0, x24, x8
    2a54:      	ldr	x8, [sp, #0x98]
    2a58:      	ldr	x2, [sp, #0x98]
    2a5c:      	blr	x9
    2a60:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2a64:      	add	x23, x22, x23
    2a68:      	cmp	x21, #0x5
    2a6c:      	b.lo	0x26ac <generic_rawtp_process_event+0x24dc>
    2a70:      	ldr	x8, [sp, #0x48]
    2a74:      	mov	w9, #0x4                // =4
    2a78:      	add	x10, sp, #0x98
    2a7c:      	add	x0, sp, #0x98
    2a80:      	mov	w1, #0x10               // =16
    2a84:      	add	x2, x8, #0x40
    2a88:      	mov	w8, #0x10               // =16
    2a8c:      	blr	x9
    2a90:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2a94:      	ldr	x19, [sp, #0xa0]
    2a98:      	cmp	x19, #0xffe
    2a9c:      	b.hi	0x25c4 <generic_rawtp_process_event+0x23f4>
    2aa0:      	add	x29, x22, x29
    2aa4:      	mov	w9, #0x4                // =4
    2aa8:      	mov	w1, w19
    2aac:      	and	x8, x29, #0x3fff
    2ab0:      	add	x0, x24, x8
    2ab4:      	ldr	x8, [sp, #0x98]
    2ab8:      	ldr	x2, [sp, #0x98]
    2abc:      	blr	x9
    2ac0:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2ac4:      	add	x23, x19, x23
    2ac8:      	cmp	x21, #0x5
    2acc:      	b.eq	0x26ac <generic_rawtp_process_event+0x24dc>
    2ad0:      	ldr	x8, [sp, #0x48]
    2ad4:      	mov	w9, #0x4                // =4
    2ad8:      	add	x10, sp, #0x98
    2adc:      	add	x0, sp, #0x98
    2ae0:      	mov	w1, #0x10               // =16
    2ae4:      	add	x2, x8, #0x50
    2ae8:      	mov	w8, #0x10               // =16
    2aec:      	blr	x9
    2af0:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2af4:      	ldr	x22, [sp, #0xa0]
    2af8:      	cmp	x22, #0xffe
    2afc:      	b.hi	0x25c4 <generic_rawtp_process_event+0x23f4>
    2b00:      	add	x29, x19, x29
    2b04:      	mov	w9, #0x4                // =4
    2b08:      	mov	w1, w22
    2b0c:      	and	x8, x29, #0x3fff
    2b10:      	add	x0, x24, x8
    2b14:      	ldr	x8, [sp, #0x98]
    2b18:      	ldr	x2, [sp, #0x98]
    2b1c:      	blr	x9
    2b20:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2b24:      	add	x23, x22, x23
    2b28:      	cmp	x21, #0x7
    2b2c:      	b.lo	0x26ac <generic_rawtp_process_event+0x24dc>
    2b30:      	ldr	x8, [sp, #0x48]
    2b34:      	mov	w9, #0x4                // =4
    2b38:      	add	x10, sp, #0x98
    2b3c:      	add	x0, sp, #0x98
    2b40:      	mov	w1, #0x10               // =16
    2b44:      	add	x2, x8, #0x60
    2b48:      	mov	w8, #0x10               // =16
    2b4c:      	blr	x9
    2b50:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2b54:      	ldr	x21, [sp, #0xa0]
    2b58:      	cmp	x21, #0xffe
    2b5c:      	b.hi	0x25c4 <generic_rawtp_process_event+0x23f4>
    2b60:      	add	x8, x22, x29
    2b64:      	mov	w9, #0x4                // =4
    2b68:      	mov	w1, w21
    2b6c:      	and	x8, x8, #0x3fff
    2b70:      	add	x0, x24, x8
    2b74:      	ldr	x8, [sp, #0x98]
    2b78:      	ldr	x2, [sp, #0x98]
    2b7c:      	blr	x9
    2b80:      	tbnz	w0, #0x1f, 0x2b8c <generic_rawtp_process_event+0x29bc>
    2b84:      	add	x23, x21, x23
    2b88:      	b	0x26ac <generic_rawtp_process_event+0x24dc>
    2b8c:      	mov	w8, #-0x2               // =-2
    2b90:      	str	w8, [x25]
    2b94:      	mov	w23, #0x4               // =4
    2b98:      	adrp	x22, 0x2000 <generic_rawtp_process_event+0x1e30>
    2b9c:      	ldr	x22, [x22]
    2ba0:      	ldr	x19, [sp, #0x8]
    2ba4:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    2ba8:      	mov	x21, #-0x1              // =-1
    2bac:      	b	0x2bb4 <generic_rawtp_process_event+0x29e4>
    2bb0:      	mov	x21, x8
    2bb4:      	str	wzr, [sp, #0x98]
    2bb8:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2bbc:      	mov	w8, #0x1                // =1
    2bc0:      	add	x9, sp, #0x98
    2bc4:      	ldr	x0, [x0]
    2bc8:      	add	x1, sp, #0x98
    2bcc:      	blr	x8
    2bd0:      	cbz	x0, 0x2f60 <generic_rawtp_process_event+0x2d90>
    2bd4:      	cmn	x21, #0xc
    2bd8:      	b.gt	0x2ce8 <generic_rawtp_process_event+0x2b18>
    2bdc:      	cmn	x21, #0x1c
    2be0:      	b.eq	0x2f2c <generic_rawtp_process_event+0x2d5c>
    2be4:      	cmn	x21, #0x16
    2be8:      	b.eq	0x2f44 <generic_rawtp_process_event+0x2d74>
    2bec:      	cmn	x21, #0x10
    2bf0:      	b.ne	0x2f3c <generic_rawtp_process_event+0x2d6c>
    2bf4:      	add	x8, x0, #0x558
    2bf8:      	b	0x2f50 <generic_rawtp_process_event+0x2d80>
    2bfc:      	ldr	x21, [sp, #0x48]
    2c00:      	b	0x2f60 <generic_rawtp_process_event+0x2d90>
    2c04:      	ldrb	w8, [x24, #0x7]
    2c08:      	lsl	w8, w8, #2
    2c0c:      	add	w8, w8, #0x8
    2c10:      	strh	w8, [x24, #0x2]
    2c14:      	ldrh	w9, [x24]
    2c18:      	ldrb	w25, [x24, #0x6]
    2c1c:      	add	w8, w9, w8
    2c20:      	cmp	w25, #0x3c
    2c24:      	strh	w8, [x24]
    2c28:      	b.hi	0x2ce0 <generic_rawtp_process_event+0x2b10>
    2c2c:      	mov	x19, #0x1               // =1
    2c30:      	mov	w9, #0x1                // =1
    2c34:      	movk	x19, #0x1800, lsl #32
    2c38:      	lsl	x9, x9, x25
    2c3c:      	movk	x19, #0x1008, lsl #48
    2c40:      	tst	x9, x19
    2c44:      	b.eq	0x2ce0 <generic_rawtp_process_event+0x2b10>
    2c48:      	strb	w25, [x24, #0x5]
    2c4c:      	add	x8, x29, w8, uxth
    2c50:      	mov	w9, #0x2                // =2
    2c54:      	mov	w10, #0x4               // =4
    2c58:      	mov	x0, x23
    2c5c:      	mov	w1, #0x2                // =2
    2c60:      	ldrh	w8, [x24]
    2c64:      	add	x2, x29, x8
    2c68:      	blr	x10
    2c6c:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    2c70:      	ldrb	w8, [x24, #0x5]
    2c74:      	cmp	w8, #0x32
    2c78:      	b.gt	0x2c98 <generic_rawtp_process_event+0x2ac8>
    2c7c:      	cbz	w8, 0x2cb8 <generic_rawtp_process_event+0x2ae8>
    2c80:      	cmp	w8, #0x2b
    2c84:      	b.eq	0x2cb8 <generic_rawtp_process_event+0x2ae8>
    2c88:      	cmp	w8, #0x2c
    2c8c:      	b.ne	0x2e18 <generic_rawtp_process_event+0x2c48>
    2c90:      	mov	w8, #0x8                // =8
    2c94:      	b	0x2d70 <generic_rawtp_process_event+0x2ba0>
    2c98:      	cmp	w8, #0x33
    2c9c:      	b.eq	0x2d64 <generic_rawtp_process_event+0x2b94>
    2ca0:      	cmp	w8, #0x3c
    2ca4:      	b.eq	0x2cb8 <generic_rawtp_process_event+0x2ae8>
    2ca8:      	cmp	w8, #0xff
    2cac:      	b.ne	0x2e18 <generic_rawtp_process_event+0x2c48>
    2cb0:      	mov	w8, #0x28               // =40
    2cb4:      	b	0x2d70 <generic_rawtp_process_event+0x2ba0>
    2cb8:      	ldrb	w8, [x24, #0x7]
    2cbc:      	lsl	w8, w8, #3
    2cc0:      	b	0x2d6c <generic_rawtp_process_event+0x2b9c>
    2cc4:      	ldrh	w8, [x24, #0x2]
    2cc8:      	ldrh	w9, [x24]
    2ccc:      	ldrb	w25, [x24, #0x6]
    2cd0:      	add	w8, w9, w8
    2cd4:      	cmp	w25, #0x3c
    2cd8:      	strh	w8, [x24]
    2cdc:      	b.ls	0x2c2c <generic_rawtp_process_event+0x2a5c>
    2ce0:      	strh	w8, [sp, #0xd8]
    2ce4:      	b	0x32e4 <generic_rawtp_process_event+0x3114>
    2ce8:      	cmn	x21, #0xb
    2cec:      	b.eq	0x2f34 <generic_rawtp_process_event+0x2d64>
    2cf0:      	cmn	x21, #0x7
    2cf4:      	b.eq	0x2f4c <generic_rawtp_process_event+0x2d7c>
    2cf8:      	cmn	x21, #0x2
    2cfc:      	b.ne	0x2f3c <generic_rawtp_process_event+0x2d6c>
    2d00:      	add	x8, x0, #0x548
    2d04:      	b	0x2f50 <generic_rawtp_process_event+0x2d80>
    2d08:      	mov	x25, #-0x1              // =-1
    2d0c:      	b	0x2d14 <generic_rawtp_process_event+0x2b44>
    2d10:      	mov	x25, x8
    2d14:      	str	wzr, [sp, #0x98]
    2d18:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2d1c:      	mov	w8, #0x1                // =1
    2d20:      	add	x9, sp, #0x98
    2d24:      	ldr	x0, [x0]
    2d28:      	add	x1, sp, #0x98
    2d2c:      	blr	x8
    2d30:      	cbz	x0, 0x30a0 <generic_rawtp_process_event+0x2ed0>
    2d34:      	cmn	x25, #0xc
    2d38:      	b.gt	0x2e38 <generic_rawtp_process_event+0x2c68>
    2d3c:      	cmn	x25, #0x1c
    2d40:      	b.eq	0x306c <generic_rawtp_process_event+0x2e9c>
    2d44:      	cmn	x25, #0x16
    2d48:      	b.eq	0x3074 <generic_rawtp_process_event+0x2ea4>
    2d4c:      	cmn	x25, #0x10
    2d50:      	b.ne	0x308c <generic_rawtp_process_event+0x2ebc>
    2d54:      	add	x8, x0, #0x558
    2d58:      	b	0x3090 <generic_rawtp_process_event+0x2ec0>
    2d5c:      	mov	x25, x21
    2d60:      	b	0x30a0 <generic_rawtp_process_event+0x2ed0>
    2d64:      	ldrb	w8, [x24, #0x7]
    2d68:      	lsl	w8, w8, #2
    2d6c:      	add	w8, w8, #0x8
    2d70:      	strh	w8, [x24, #0x2]
    2d74:      	ldrh	w9, [x24]
    2d78:      	ldrb	w25, [x24, #0x6]
    2d7c:      	add	w8, w9, w8
    2d80:      	cmp	w25, #0x3c
    2d84:      	strh	w8, [x24]
    2d88:      	b.hi	0x3498 <generic_rawtp_process_event+0x32c8>
    2d8c:      	mov	w9, #0x1                // =1
    2d90:      	lsl	x9, x9, x25
    2d94:      	tst	x9, x19
    2d98:      	b.eq	0x3498 <generic_rawtp_process_event+0x32c8>
    2d9c:      	strb	w25, [x24, #0x5]
    2da0:      	add	x8, x29, w8, uxth
    2da4:      	mov	w9, #0x2                // =2
    2da8:      	mov	w10, #0x4               // =4
    2dac:      	mov	x0, x23
    2db0:      	mov	w1, #0x2                // =2
    2db4:      	ldrh	w8, [x24]
    2db8:      	add	x2, x29, x8
    2dbc:      	blr	x10
    2dc0:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    2dc4:      	ldrb	w8, [x24, #0x5]
    2dc8:      	cmp	w8, #0x32
    2dcc:      	b.gt	0x2dec <generic_rawtp_process_event+0x2c1c>
    2dd0:      	cbz	w8, 0x2e0c <generic_rawtp_process_event+0x2c3c>
    2dd4:      	cmp	w8, #0x2b
    2dd8:      	b.eq	0x2e0c <generic_rawtp_process_event+0x2c3c>
    2ddc:      	cmp	w8, #0x2c
    2de0:      	b.ne	0x2f0c <generic_rawtp_process_event+0x2d3c>
    2de4:      	mov	w8, #0x8                // =8
    2de8:      	b	0x2e64 <generic_rawtp_process_event+0x2c94>
    2dec:      	cmp	w8, #0x33
    2df0:      	b.eq	0x2e58 <generic_rawtp_process_event+0x2c88>
    2df4:      	cmp	w8, #0x3c
    2df8:      	b.eq	0x2e0c <generic_rawtp_process_event+0x2c3c>
    2dfc:      	cmp	w8, #0xff
    2e00:      	b.ne	0x2f0c <generic_rawtp_process_event+0x2d3c>
    2e04:      	mov	w8, #0x28               // =40
    2e08:      	b	0x2e64 <generic_rawtp_process_event+0x2c94>
    2e0c:      	ldrb	w8, [x24, #0x7]
    2e10:      	lsl	w8, w8, #3
    2e14:      	b	0x2e60 <generic_rawtp_process_event+0x2c90>
    2e18:      	ldrh	w8, [x24, #0x2]
    2e1c:      	ldrh	w9, [x24]
    2e20:      	ldrb	w25, [x24, #0x6]
    2e24:      	add	w8, w9, w8
    2e28:      	cmp	w25, #0x3c
    2e2c:      	strh	w8, [x24]
    2e30:      	b.ls	0x2d8c <generic_rawtp_process_event+0x2bbc>
    2e34:      	b	0x3498 <generic_rawtp_process_event+0x32c8>
    2e38:      	cmn	x25, #0xb
    2e3c:      	b.eq	0x307c <generic_rawtp_process_event+0x2eac>
    2e40:      	cmn	x25, #0x7
    2e44:      	b.eq	0x3084 <generic_rawtp_process_event+0x2eb4>
    2e48:      	cmn	x25, #0x2
    2e4c:      	b.ne	0x308c <generic_rawtp_process_event+0x2ebc>
    2e50:      	add	x8, x0, #0x548
    2e54:      	b	0x3090 <generic_rawtp_process_event+0x2ec0>
    2e58:      	ldrb	w8, [x24, #0x7]
    2e5c:      	lsl	w8, w8, #2
    2e60:      	add	w8, w8, #0x8
    2e64:      	strh	w8, [x24, #0x2]
    2e68:      	ldrh	w9, [x24]
    2e6c:      	ldrb	w25, [x24, #0x6]
    2e70:      	add	w8, w9, w8
    2e74:      	cmp	w25, #0x3c
    2e78:      	strh	w8, [x24]
    2e7c:      	b.hi	0x3498 <generic_rawtp_process_event+0x32c8>
    2e80:      	mov	w9, #0x1                // =1
    2e84:      	lsl	x9, x9, x25
    2e88:      	tst	x9, x19
    2e8c:      	b.eq	0x3498 <generic_rawtp_process_event+0x32c8>
    2e90:      	strb	w25, [x24, #0x5]
    2e94:      	add	x8, x29, w8, uxth
    2e98:      	mov	w9, #0x2                // =2
    2e9c:      	mov	w10, #0x4               // =4
    2ea0:      	mov	x0, x23
    2ea4:      	mov	w1, #0x2                // =2
    2ea8:      	ldrh	w8, [x24]
    2eac:      	add	x2, x29, x8
    2eb0:      	blr	x10
    2eb4:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    2eb8:      	ldrb	w8, [x24, #0x5]
    2ebc:      	cmp	w8, #0x32
    2ec0:      	b.gt	0x2ee0 <generic_rawtp_process_event+0x2d10>
    2ec4:      	cbz	w8, 0x2f00 <generic_rawtp_process_event+0x2d30>
    2ec8:      	cmp	w8, #0x2b
    2ecc:      	b.eq	0x2f00 <generic_rawtp_process_event+0x2d30>
    2ed0:      	cmp	w8, #0x2c
    2ed4:      	b.ne	0x304c <generic_rawtp_process_event+0x2e7c>
    2ed8:      	mov	w8, #0x8                // =8
    2edc:      	b	0x2fa4 <generic_rawtp_process_event+0x2dd4>
    2ee0:      	cmp	w8, #0x33
    2ee4:      	b.eq	0x2f98 <generic_rawtp_process_event+0x2dc8>
    2ee8:      	cmp	w8, #0x3c
    2eec:      	b.eq	0x2f00 <generic_rawtp_process_event+0x2d30>
    2ef0:      	cmp	w8, #0xff
    2ef4:      	b.ne	0x304c <generic_rawtp_process_event+0x2e7c>
    2ef8:      	mov	w8, #0x28               // =40
    2efc:      	b	0x2fa4 <generic_rawtp_process_event+0x2dd4>
    2f00:      	ldrb	w8, [x24, #0x7]
    2f04:      	lsl	w8, w8, #3
    2f08:      	b	0x2fa0 <generic_rawtp_process_event+0x2dd0>
    2f0c:      	ldrh	w8, [x24, #0x2]
    2f10:      	ldrh	w9, [x24]
    2f14:      	ldrb	w25, [x24, #0x6]
    2f18:      	add	w8, w9, w8
    2f1c:      	cmp	w25, #0x3c
    2f20:      	strh	w8, [x24]
    2f24:      	b.ls	0x2e80 <generic_rawtp_process_event+0x2cb0>
    2f28:      	b	0x3498 <generic_rawtp_process_event+0x32c8>
    2f2c:      	add	x8, x0, #0x568
    2f30:      	b	0x2f50 <generic_rawtp_process_event+0x2d80>
    2f34:      	add	x8, x0, #0x570
    2f38:      	b	0x2f50 <generic_rawtp_process_event+0x2d80>
    2f3c:      	add	x8, x0, #0x540
    2f40:      	b	0x2f50 <generic_rawtp_process_event+0x2d80>
    2f44:      	add	x8, x0, #0x560
    2f48:      	b	0x2f50 <generic_rawtp_process_event+0x2d80>
    2f4c:      	add	x8, x0, #0x550
    2f50:      	ldaxr	x9, [x8]
    2f54:      	add	x9, x9, #0x1
    2f58:      	stlxr	w10, x9, [x8]
    2f5c:      	cbnz	w10, 0x2f50 <generic_rawtp_process_event+0x2d80>
    2f60:      	tbnz	w21, #0x1f, 0x2f7c <generic_rawtp_process_event+0x2dac>
    2f64:      	ldr	x9, [sp, #0x48]
    2f68:      	stur	xzr, [x29, #0x4]
    2f6c:      	sub	w8, w9, w21
    2f70:      	cmn	x9, #0x1
    2f74:      	csel	w8, wzr, w8, eq
    2f78:      	b	0x2f8c <generic_rawtp_process_event+0x2dbc>
    2f7c:      	mov	w8, wzr
    2f80:      	mov	x9, x29
    2f84:      	stp	w21, wzr, [x29, #0x4]
    2f88:      	mov	w21, wzr
    2f8c:      	stp	w8, w21, [x29, #0xc]
    2f90:      	mov	w23, #0x24              // =36
    2f94:      	b	0x1110 <generic_rawtp_process_event+0xf40>
    2f98:      	ldrb	w8, [x24, #0x7]
    2f9c:      	lsl	w8, w8, #2
    2fa0:      	add	w8, w8, #0x8
    2fa4:      	strh	w8, [x24, #0x2]
    2fa8:      	ldrh	w9, [x24]
    2fac:      	ldrb	w25, [x24, #0x6]
    2fb0:      	add	w8, w9, w8
    2fb4:      	cmp	w25, #0x3c
    2fb8:      	strh	w8, [x24]
    2fbc:      	b.hi	0x3498 <generic_rawtp_process_event+0x32c8>
    2fc0:      	mov	w9, #0x1                // =1
    2fc4:      	lsl	x9, x9, x25
    2fc8:      	tst	x9, x19
    2fcc:      	b.eq	0x3498 <generic_rawtp_process_event+0x32c8>
    2fd0:      	strb	w25, [x24, #0x5]
    2fd4:      	add	x8, x29, w8, uxth
    2fd8:      	mov	w9, #0x2                // =2
    2fdc:      	mov	w10, #0x4               // =4
    2fe0:      	mov	x0, x23
    2fe4:      	mov	w1, #0x2                // =2
    2fe8:      	ldrh	w8, [x24]
    2fec:      	add	x2, x29, x8
    2ff0:      	blr	x10
    2ff4:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    2ff8:      	ldrb	w8, [x24, #0x5]
    2ffc:      	cmp	w8, #0x32
    3000:      	b.gt	0x3020 <generic_rawtp_process_event+0x2e50>
    3004:      	cbz	w8, 0x3040 <generic_rawtp_process_event+0x2e70>
    3008:      	cmp	w8, #0x2b
    300c:      	b.eq	0x3040 <generic_rawtp_process_event+0x2e70>
    3010:      	cmp	w8, #0x2c
    3014:      	b.ne	0x3190 <generic_rawtp_process_event+0x2fc0>
    3018:      	mov	w8, #0x8                // =8
    301c:      	b	0x30e8 <generic_rawtp_process_event+0x2f18>
    3020:      	cmp	w8, #0x33
    3024:      	b.eq	0x30dc <generic_rawtp_process_event+0x2f0c>
    3028:      	cmp	w8, #0x3c
    302c:      	b.eq	0x3040 <generic_rawtp_process_event+0x2e70>
    3030:      	cmp	w8, #0xff
    3034:      	b.ne	0x3190 <generic_rawtp_process_event+0x2fc0>
    3038:      	mov	w8, #0x28               // =40
    303c:      	b	0x30e8 <generic_rawtp_process_event+0x2f18>
    3040:      	ldrb	w8, [x24, #0x7]
    3044:      	lsl	w8, w8, #3
    3048:      	b	0x30e4 <generic_rawtp_process_event+0x2f14>
    304c:      	ldrh	w8, [x24, #0x2]
    3050:      	ldrh	w9, [x24]
    3054:      	ldrb	w25, [x24, #0x6]
    3058:      	add	w8, w9, w8
    305c:      	cmp	w25, #0x3c
    3060:      	strh	w8, [x24]
    3064:      	b.ls	0x2fc0 <generic_rawtp_process_event+0x2df0>
    3068:      	b	0x3498 <generic_rawtp_process_event+0x32c8>
    306c:      	add	x8, x0, #0x568
    3070:      	b	0x3090 <generic_rawtp_process_event+0x2ec0>
    3074:      	add	x8, x0, #0x560
    3078:      	b	0x3090 <generic_rawtp_process_event+0x2ec0>
    307c:      	add	x8, x0, #0x570
    3080:      	b	0x3090 <generic_rawtp_process_event+0x2ec0>
    3084:      	add	x8, x0, #0x550
    3088:      	b	0x3090 <generic_rawtp_process_event+0x2ec0>
    308c:      	add	x8, x0, #0x540
    3090:      	ldaxr	x9, [x8]
    3094:      	add	x9, x9, #0x1
    3098:      	stlxr	w10, x9, [x8]
    309c:      	cbnz	w10, 0x3090 <generic_rawtp_process_event+0x2ec0>
    30a0:      	tbnz	w25, #0x1f, 0x30bc <generic_rawtp_process_event+0x2eec>
    30a4:      	ldr	x8, [sp, #0x38]
    30a8:      	cmn	x21, #0x1
    30ac:      	stur	xzr, [x8, #0x4]
    30b0:      	sub	w8, w21, w25
    30b4:      	csel	w8, wzr, w8, eq
    30b8:      	b	0x30cc <generic_rawtp_process_event+0x2efc>
    30bc:      	ldr	x9, [sp, #0x38]
    30c0:      	mov	w8, wzr
    30c4:      	stp	w25, wzr, [x9, #0x4]
    30c8:      	mov	w25, wzr
    30cc:      	ldr	x9, [sp, #0x38]
    30d0:      	mov	w23, #0x24              // =36
    30d4:      	stp	w8, w25, [x9, #0xc]
    30d8:      	b	0x2b98 <generic_rawtp_process_event+0x29c8>
    30dc:      	ldrb	w8, [x24, #0x7]
    30e0:      	lsl	w8, w8, #2
    30e4:      	add	w8, w8, #0x8
    30e8:      	strh	w8, [x24, #0x2]
    30ec:      	ldrh	w9, [x24]
    30f0:      	ldrb	w25, [x24, #0x6]
    30f4:      	add	w8, w9, w8
    30f8:      	cmp	w25, #0x3c
    30fc:      	strh	w8, [x24]
    3100:      	b.hi	0x3498 <generic_rawtp_process_event+0x32c8>
    3104:      	mov	w9, #0x1                // =1
    3108:      	lsl	x9, x9, x25
    310c:      	tst	x9, x19
    3110:      	b.eq	0x3498 <generic_rawtp_process_event+0x32c8>
    3114:      	strb	w25, [x24, #0x5]
    3118:      	add	x8, x29, w8, uxth
    311c:      	mov	w9, #0x2                // =2
    3120:      	mov	w10, #0x4               // =4
    3124:      	mov	x0, x23
    3128:      	mov	w1, #0x2                // =2
    312c:      	ldrh	w8, [x24]
    3130:      	add	x2, x29, x8
    3134:      	blr	x10
    3138:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    313c:      	ldrb	w8, [x24, #0x5]
    3140:      	cmp	w8, #0x32
    3144:      	b.gt	0x3164 <generic_rawtp_process_event+0x2f94>
    3148:      	cbz	w8, 0x3184 <generic_rawtp_process_event+0x2fb4>
    314c:      	cmp	w8, #0x2b
    3150:      	b.eq	0x3184 <generic_rawtp_process_event+0x2fb4>
    3154:      	cmp	w8, #0x2c
    3158:      	b.ne	0x3264 <generic_rawtp_process_event+0x3094>
    315c:      	mov	w8, #0x8                // =8
    3160:      	b	0x31bc <generic_rawtp_process_event+0x2fec>
    3164:      	cmp	w8, #0x33
    3168:      	b.eq	0x31b0 <generic_rawtp_process_event+0x2fe0>
    316c:      	cmp	w8, #0x3c
    3170:      	b.eq	0x3184 <generic_rawtp_process_event+0x2fb4>
    3174:      	cmp	w8, #0xff
    3178:      	b.ne	0x3264 <generic_rawtp_process_event+0x3094>
    317c:      	mov	w8, #0x28               // =40
    3180:      	b	0x31bc <generic_rawtp_process_event+0x2fec>
    3184:      	ldrb	w8, [x24, #0x7]
    3188:      	lsl	w8, w8, #3
    318c:      	b	0x31b8 <generic_rawtp_process_event+0x2fe8>
    3190:      	ldrh	w8, [x24, #0x2]
    3194:      	ldrh	w9, [x24]
    3198:      	ldrb	w25, [x24, #0x6]
    319c:      	add	w8, w9, w8
    31a0:      	cmp	w25, #0x3c
    31a4:      	strh	w8, [x24]
    31a8:      	b.ls	0x3104 <generic_rawtp_process_event+0x2f34>
    31ac:      	b	0x3498 <generic_rawtp_process_event+0x32c8>
    31b0:      	ldrb	w8, [x24, #0x7]
    31b4:      	lsl	w8, w8, #2
    31b8:      	add	w8, w8, #0x8
    31bc:      	strh	w8, [x24, #0x2]
    31c0:      	ldrh	w9, [x24]
    31c4:      	ldrb	w25, [x24, #0x6]
    31c8:      	add	w8, w9, w8
    31cc:      	cmp	w25, #0x3c
    31d0:      	strh	w8, [x24]
    31d4:      	b.hi	0x3498 <generic_rawtp_process_event+0x32c8>
    31d8:      	mov	w9, #0x1                // =1
    31dc:      	lsl	x9, x9, x25
    31e0:      	tst	x9, x19
    31e4:      	b.eq	0x3498 <generic_rawtp_process_event+0x32c8>
    31e8:      	strb	w25, [x24, #0x5]
    31ec:      	add	x8, x29, w8, uxth
    31f0:      	mov	w9, #0x2                // =2
    31f4:      	mov	w10, #0x4               // =4
    31f8:      	mov	x0, x23
    31fc:      	mov	w1, #0x2                // =2
    3200:      	ldrh	w8, [x24]
    3204:      	add	x2, x29, x8
    3208:      	blr	x10
    320c:      	tbnz	x0, #0x3f, 0x32e0 <generic_rawtp_process_event+0x3110>
    3210:      	ldrb	w8, [x24, #0x5]
    3214:      	cmp	w8, #0x32
    3218:      	b.gt	0x3238 <generic_rawtp_process_event+0x3068>
    321c:      	cbz	w8, 0x3258 <generic_rawtp_process_event+0x3088>
    3220:      	cmp	w8, #0x2b
    3224:      	b.eq	0x3258 <generic_rawtp_process_event+0x3088>
    3228:      	cmp	w8, #0x2c
    322c:      	b.ne	0x347c <generic_rawtp_process_event+0x32ac>
    3230:      	mov	w8, #0x8                // =8
    3234:      	b	0x3290 <generic_rawtp_process_event+0x30c0>
    3238:      	cmp	w8, #0x33
    323c:      	b.eq	0x3284 <generic_rawtp_process_event+0x30b4>
    3240:      	cmp	w8, #0x3c
    3244:      	b.eq	0x3258 <generic_rawtp_process_event+0x3088>
    3248:      	cmp	w8, #0xff
    324c:      	b.ne	0x347c <generic_rawtp_process_event+0x32ac>
    3250:      	mov	w8, #0x28               // =40
    3254:      	b	0x3290 <generic_rawtp_process_event+0x30c0>
    3258:      	ldrb	w8, [x24, #0x7]
    325c:      	lsl	w8, w8, #3
    3260:      	b	0x328c <generic_rawtp_process_event+0x30bc>
    3264:      	ldrh	w8, [x24, #0x2]
    3268:      	ldrh	w9, [x24]
    326c:      	ldrb	w25, [x24, #0x6]
    3270:      	add	w8, w9, w8
    3274:      	cmp	w25, #0x3c
    3278:      	strh	w8, [x24]
    327c:      	b.ls	0x31d8 <generic_rawtp_process_event+0x3008>
    3280:      	b	0x3498 <generic_rawtp_process_event+0x32c8>
    3284:      	ldrb	w8, [x24, #0x7]
    3288:      	lsl	w8, w8, #2
    328c:      	add	w8, w8, #0x8
    3290:      	strh	w8, [x24, #0x2]
    3294:      	ldrh	w9, [x24]
    3298:      	ldrb	w25, [x24, #0x6]
    329c:      	add	w8, w9, w8
    32a0:      	cmp	w25, #0x3c
    32a4:      	strh	w8, [x24]
    32a8:      	b.hi	0x3498 <generic_rawtp_process_event+0x32c8>
    32ac:      	mov	w9, #0x1                // =1
    32b0:      	lsl	x9, x9, x25
    32b4:      	tst	x9, x19
    32b8:      	b.eq	0x3498 <generic_rawtp_process_event+0x32c8>
    32bc:      	strb	w25, [x24, #0x5]
    32c0:      	add	x8, x29, w8, uxth
    32c4:      	mov	w9, #0x2                // =2
    32c8:      	mov	w10, #0x4               // =4
    32cc:      	mov	x0, x23
    32d0:      	mov	w1, #0x2                // =2
    32d4:      	ldrh	w8, [x24]
    32d8:      	add	x2, x29, x8
    32dc:      	blr	x10
    32e0:      	mov	w25, wzr
    32e4:      	ldr	x29, [sp, #0x30]
    32e8:      	mov	w8, #0xa                // =10
    32ec:      	strb	w25, [sp, #0x88]
    32f0:      	add	x2, x21, #0x8
    32f4:      	mov	w23, #0x10              // =16
    32f8:      	mov	w1, #0x10               // =16
    32fc:      	mov	w24, #0x4               // =4
    3300:      	strh	w25, [x29, #0x24]
    3304:      	strh	w8, [x29, #0x26]
    3308:      	mov	w8, #0x4                // =4
    330c:      	mov	x0, x29
    3310:      	blr	x8
    3314:      	add	x0, x29, #0x10
    3318:      	add	x2, x21, #0x18
    331c:      	mov	w1, #0x10               // =16
    3320:      	blr	x24
    3324:      	cmp	w25, #0x11
    3328:      	b.eq	0x336c <generic_rawtp_process_event+0x319c>
    332c:      	cmp	w25, #0x6
    3330:      	b.ne	0x33ac <generic_rawtp_process_event+0x31dc>
    3334:      	ldr	x8, [sp, #0x98]
    3338:      	ldrh	w9, [sp, #0xd8]
    333c:      	mov	w21, #0x2               // =2
    3340:      	mov	w1, #0x2                // =2
    3344:      	mov	w24, #0x4               // =4
    3348:      	add	x23, x8, x9
    334c:      	ldr	x25, [sp, #0x30]
    3350:      	add	x0, x25, #0x20
    3354:      	mov	w8, #0x4                // =4
    3358:      	mov	x2, x23
    335c:      	blr	x8
    3360:      	add	x0, x25, #0x22
    3364:      	add	x2, x23, #0x2
    3368:      	b	0x33a0 <generic_rawtp_process_event+0x31d0>
    336c:      	ldr	x8, [sp, #0x98]
    3370:      	ldrh	w9, [sp, #0xd8]
    3374:      	mov	w21, #0x2               // =2
    3378:      	mov	w1, #0x2                // =2
    337c:      	mov	w24, #0x4               // =4
    3380:      	add	x23, x8, x9
    3384:      	ldr	x25, [sp, #0x30]
    3388:      	add	x0, x25, #0x20
    338c:      	mov	w8, #0x4                // =4
    3390:      	mov	x2, x23
    3394:      	blr	x8
    3398:      	add	x0, x25, #0x22
    339c:      	add	x2, x23, #0x2
    33a0:      	mov	w1, #0x2                // =2
    33a4:      	blr	x24
    33a8:      	b	0x33b4 <generic_rawtp_process_event+0x31e4>
    33ac:      	ldr	x8, [sp, #0x30]
    33b0:      	str	wzr, [x8, #0x20]
    33b4:      	ldr	x9, [sp, #0x30]
    33b8:      	add	x10, sp, #0xf0
    33bc:      	add	x0, sp, #0xf0
    33c0:      	mov	w1, #0x8                // =8
    33c4:      	ldrh	w8, [x9, #0x20]
    33c8:      	rev	w8, w8
    33cc:      	lsr	w8, w8, #16
    33d0:      	strh	w8, [x9, #0x20]
    33d4:      	ldrh	w8, [x9, #0x22]
    33d8:      	rev	w8, w8
    33dc:      	lsr	w8, w8, #16
    33e0:      	strh	w8, [x9, #0x22]
    33e4:      	ldr	x8, [sp, #0x48]
    33e8:      	mov	w9, #0x4                // =4
    33ec:      	add	x2, x8, #0xe0
    33f0:      	mov	w8, #0x8                // =8
    33f4:      	blr	x9
    33f8:      	add	x8, sp, #0xe0
    33fc:      	ldr	x8, [x8, #0x10]
    3400:      	cbz	x8, 0x3464 <generic_rawtp_process_event+0x3294>
    3404:      	add	x8, x8, #0x5
    3408:      	mov	w9, #0x8                // =8
    340c:      	add	x10, sp, #0x70
    3410:      	mov	w11, #0x4               // =4
    3414:      	add	x23, sp, #0xe0
    3418:      	ldr	x8, [x23, #0x10]
    341c:      	add	x0, sp, #0x70
    3420:      	mov	w1, #0x8                // =8
    3424:      	mov	w21, #0x4               // =4
    3428:      	add	x2, x8, #0x5
    342c:      	blr	x11
    3430:      	ldr	x8, [x23, #0x10]
    3434:      	ldr	x9, [sp, #0x70]
    3438:      	mov	w1, #0x4                // =4
    343c:      	add	x23, x8, x9, lsl #3
    3440:      	ldr	x24, [sp, #0x30]
    3444:      	add	x0, x24, #0x38
    3448:      	mov	w8, #0x4                // =4
    344c:      	add	x2, x23, #0x44
    3450:      	blr	x8
    3454:      	add	x0, x24, #0x3c
    3458:      	add	x2, x23, #0x45
    345c:      	mov	w1, #0x4                // =4
    3460:      	blr	x21
    3464:      	mov	w23, #0x40              // =64
    3468:      	adrp	x22, 0x3000 <generic_rawtp_process_event+0x2e30>
    346c:      	mov	w10, #0x5ea0            // =24224
    3470:      	ldr	x22, [x22]
    3474:      	ldr	x19, [sp, #0x8]
    3478:      	b	0x1114 <generic_rawtp_process_event+0xf44>
    347c:      	ldrh	w8, [x24, #0x2]
    3480:      	ldrh	w9, [x24]
    3484:      	ldrb	w25, [x24, #0x6]
    3488:      	add	w8, w9, w8
    348c:      	cmp	w25, #0x3c
    3490:      	strh	w8, [x24]
    3494:      	b.ls	0x32ac <generic_rawtp_process_event+0x30dc>
    3498:      	strh	w8, [sp, #0xd8]
    349c:      	b	0x32e4 <generic_rawtp_process_event+0x3114>

00000000000034a0 <generic_rawtp_process_filter>:
    34a0:      	sub	sp, sp, #0x130
    34a4:      	str	x29, [sp, #0xe0]
    34a8:      	stp	x30, x25, [sp, #0xf0]
    34ac:      	stp	x24, x23, [sp, #0x100]
    34b0:      	stp	x22, x21, [sp, #0x110]
    34b4:      	stp	x20, x19, [sp, #0x120]
    34b8:      	mov	x22, x0
    34bc:      	str	wzr, [sp, #0x54]
    34c0:      	adrp	x0, 0x3000 <generic_rawtp_process_event+0x2e30>
    34c4:      	mov	w8, #0x1                // =1
    34c8:      	ldr	x0, [x0]
    34cc:      	add	x9, sp, #0x54
    34d0:      	add	x1, sp, #0x54
    34d4:      	blr	x8
    34d8:      	cbz	x0, 0x5374 <generic_rawtp_process_filter+0x1ed4>
    34dc:      	mov	w8, #0x5ec0             // =24256
    34e0:      	mov	x20, x0
    34e4:      	add	x29, x0, x8
    34e8:      	mov	w8, #0x23               // =35
    34ec:      	blr	x8
    34f0:      	str	x0, [sp, #0x58]
    34f4:      	add	x8, x0, #0x8d4
    34f8:      	mov	w9, #0x4                // =4
    34fc:      	mov	w10, #0x71              // =113
    3500:      	add	x11, sp, #0xd8
    3504:      	add	x0, sp, #0xd8
    3508:      	mov	w1, #0x4                // =4
    350c:      	ldr	x8, [sp, #0x58]
    3510:      	add	x2, x8, #0x8d4
    3514:      	blr	x10
    3518:      	ldr	w8, [sp, #0xd8]
    351c:      	adrp	x19, 0x3000 <generic_rawtp_process_event+0x2e30>
    3520:      	add	x9, sp, #0xc8
    3524:      	add	x1, sp, #0xc8
    3528:      	str	w8, [sp, #0xc8]
    352c:      	mov	w8, #0x1                // =1
    3530:      	ldr	x19, [x19]
    3534:      	mov	x0, x19
    3538:      	blr	x8
    353c:      	cbz	x0, 0x354c <generic_rawtp_process_filter+0xac>
    3540:      	ldr	x8, [x0, #0x8]
    3544:      	mov	x24, x0
    3548:      	cbnz	x8, 0x417c <generic_rawtp_process_filter+0xcdc>
    354c:      	ldr	x8, [sp, #0x58]
    3550:      	mov	w9, #0x8                // =8
    3554:      	mov	w10, #0x71              // =113
    3558:      	add	x11, sp, #0x58
    355c:      	add	x0, sp, #0x58
    3560:      	mov	w1, #0x8                // =8
    3564:      	add	x8, x8, #0x8e0
    3568:      	ldr	x8, [sp, #0x58]
    356c:      	add	x2, x8, #0x8e0
    3570:      	blr	x10
    3574:      	ldr	x8, [sp, #0x58]
    3578:      	cbz	x8, 0x36f4 <generic_rawtp_process_filter+0x254>
    357c:      	add	x8, x8, #0x8d4
    3580:      	mov	w9, #0x4                // =4
    3584:      	mov	w10, #0x71              // =113
    3588:      	add	x11, sp, #0xd8
    358c:      	ldr	x8, [sp, #0x58]
    3590:      	add	x0, sp, #0xd8
    3594:      	mov	w1, #0x4                // =4
    3598:      	add	x2, x8, #0x8d4
    359c:      	blr	x10
    35a0:      	ldr	w8, [sp, #0xd8]
    35a4:      	add	x9, sp, #0xc8
    35a8:      	add	x1, sp, #0xc8
    35ac:      	mov	x0, x19
    35b0:      	str	w8, [sp, #0xc8]
    35b4:      	mov	w8, #0x1                // =1
    35b8:      	blr	x8
    35bc:      	cbz	x0, 0x35cc <generic_rawtp_process_filter+0x12c>
    35c0:      	ldr	x8, [x0, #0x8]
    35c4:      	mov	x24, x0
    35c8:      	cbnz	x8, 0x417c <generic_rawtp_process_filter+0xcdc>
    35cc:      	ldr	x8, [sp, #0x58]
    35d0:      	mov	w9, #0x8                // =8
    35d4:      	mov	w10, #0x71              // =113
    35d8:      	add	x11, sp, #0x58
    35dc:      	add	x0, sp, #0x58
    35e0:      	mov	w1, #0x8                // =8
    35e4:      	add	x8, x8, #0x8e0
    35e8:      	ldr	x8, [sp, #0x58]
    35ec:      	add	x2, x8, #0x8e0
    35f0:      	blr	x10
    35f4:      	ldr	x8, [sp, #0x58]
    35f8:      	cbz	x8, 0x36f4 <generic_rawtp_process_filter+0x254>
    35fc:      	add	x8, x8, #0x8d4
    3600:      	mov	w9, #0x4                // =4
    3604:      	mov	w10, #0x71              // =113
    3608:      	add	x11, sp, #0xd8
    360c:      	ldr	x8, [sp, #0x58]
    3610:      	add	x0, sp, #0xd8
    3614:      	mov	w1, #0x4                // =4
    3618:      	add	x2, x8, #0x8d4
    361c:      	blr	x10
    3620:      	ldr	w8, [sp, #0xd8]
    3624:      	add	x9, sp, #0xc8
    3628:      	add	x1, sp, #0xc8
    362c:      	mov	x0, x19
    3630:      	str	w8, [sp, #0xc8]
    3634:      	mov	w8, #0x1                // =1
    3638:      	blr	x8
    363c:      	cbz	x0, 0x364c <generic_rawtp_process_filter+0x1ac>
    3640:      	ldr	x8, [x0, #0x8]
    3644:      	mov	x24, x0
    3648:      	cbnz	x8, 0x417c <generic_rawtp_process_filter+0xcdc>
    364c:      	ldr	x8, [sp, #0x58]
    3650:      	mov	w9, #0x8                // =8
    3654:      	mov	w10, #0x71              // =113
    3658:      	add	x11, sp, #0x58
    365c:      	add	x0, sp, #0x58
    3660:      	mov	w1, #0x8                // =8
    3664:      	add	x8, x8, #0x8e0
    3668:      	ldr	x8, [sp, #0x58]
    366c:      	add	x2, x8, #0x8e0
    3670:      	blr	x10
    3674:      	ldr	x8, [sp, #0x58]
    3678:      	cbz	x8, 0x36f4 <generic_rawtp_process_filter+0x254>
    367c:      	add	x8, x8, #0x8d4
    3680:      	mov	w9, #0x4                // =4
    3684:      	mov	w10, #0x71              // =113
    3688:      	add	x11, sp, #0xd8
    368c:      	ldr	x8, [sp, #0x58]
    3690:      	add	x0, sp, #0xd8
    3694:      	mov	w1, #0x4                // =4
    3698:      	add	x2, x8, #0x8d4
    369c:      	blr	x10
    36a0:      	ldr	w8, [sp, #0xd8]
    36a4:      	add	x9, sp, #0xc8
    36a8:      	add	x1, sp, #0xc8
    36ac:      	mov	x0, x19
    36b0:      	str	w8, [sp, #0xc8]
    36b4:      	mov	w8, #0x1                // =1
    36b8:      	blr	x8
    36bc:      	cbz	x0, 0x36cc <generic_rawtp_process_filter+0x22c>
    36c0:      	ldr	x8, [x0, #0x8]
    36c4:      	mov	x24, x0
    36c8:      	cbnz	x8, 0x417c <generic_rawtp_process_filter+0xcdc>
    36cc:      	ldr	x8, [sp, #0x58]
    36d0:      	mov	w9, #0x8                // =8
    36d4:      	mov	w10, #0x71              // =113
    36d8:      	add	x11, sp, #0x58
    36dc:      	add	x0, sp, #0x58
    36e0:      	mov	w1, #0x8                // =8
    36e4:      	add	x8, x8, #0x8e0
    36e8:      	ldr	x8, [sp, #0x58]
    36ec:      	add	x2, x8, #0x8e0
    36f0:      	blr	x10
    36f4:      	mov	w8, #0x23               // =35
    36f8:      	blr	x8
    36fc:      	add	x2, x0, #0x8d4
    3700:      	mov	w8, #0x4                // =4
    3704:      	add	x9, sp, #0x58
    3708:      	mov	x24, x0
    370c:      	add	x0, sp, #0x58
    3710:      	mov	w1, #0x4                // =4
    3714:      	blr	x8
    3718:      	ldr	w8, [sp, #0x58]
    371c:      	mov	x19, x29
    3720:      	str	w8, [x19, #0x50]!
    3724:      	mov	w8, #0x7d               // =125
    3728:      	blr	x8
    372c:      	str	x0, [x20, #0x5f18]
    3730:      	str	wzr, [x19, #0x10]
    3734:      	add	x2, x24, #0x60
    3738:      	mov	w8, #0x8                // =8
    373c:      	mov	w9, #0x71               // =113
    3740:      	add	x10, sp, #0xc8
    3744:      	str	xzr, [x20, #0x5f28]
    3748:      	str	x19, [sp, #0x48]
    374c:      	add	x0, sp, #0xc8
    3750:      	mov	w1, #0x8                // =8
    3754:      	str	wzr, [x19, #0x20]
    3758:      	blr	x9
    375c:      	ldr	x8, [sp, #0xc8]
    3760:      	cbz	x8, 0x37d0 <generic_rawtp_process_filter+0x330>
    3764:      	add	x8, x8, #0x4
    3768:      	mov	w9, #0x4                // =4
    376c:      	mov	w10, #0x71              // =113
    3770:      	add	x11, sp, #0xd8
    3774:      	ldr	x8, [sp, #0xc8]
    3778:      	add	x0, sp, #0xd8
    377c:      	mov	w1, #0x4                // =4
    3780:      	add	x2, x8, #0x4
    3784:      	blr	x10
    3788:      	ldr	w8, [sp, #0xd8]
    378c:      	cbz	w8, 0x37d0 <generic_rawtp_process_filter+0x330>
    3790:      	ldr	x9, [sp, #0xc8]
    3794:      	lsl	w8, w8, #4
    3798:      	mov	w10, #0x71              // =113
    379c:      	add	x11, sp, #0x58
    37a0:      	add	x0, sp, #0x58
    37a4:      	mov	w1, #0x10               // =16
    37a8:      	add	x8, x9, x8
    37ac:      	mov	w9, #0x10               // =16
    37b0:      	add	x8, x8, #0x80
    37b4:      	ldr	w9, [sp, #0xd8]
    37b8:      	ldr	x8, [sp, #0xc8]
    37bc:      	lsl	w9, w9, #4
    37c0:      	add	x8, x8, x9
    37c4:      	add	x2, x8, #0x80
    37c8:      	blr	x10
    37cc:      	ldr	w8, [sp, #0x58]
    37d0:      	str	w8, [x29, #0x74]
    37d4:      	mov	w8, #0x5f60             // =24416
    37d8:      	str	x20, [sp, #0xe8]
    37dc:      	add	x23, x24, #0xae0
    37e0:      	mov	w19, #0x8               // =8
    37e4:      	add	x25, x20, x8
    37e8:      	add	x8, sp, #0x58
    37ec:      	mov	w9, #0x4                // =4
    37f0:      	add	x0, sp, #0x58
    37f4:      	mov	w1, #0x8                // =8
    37f8:      	mov	x2, x23
    37fc:      	mov	w21, #0x4               // =4
    3800:      	blr	x9
    3804:      	ldr	x20, [sp, #0x58]
    3808:      	ldr	x9, [sp, #0xe8]
    380c:      	mov	w8, #0x5f68             // =24424
    3810:      	mov	w1, #0x8                // =8
    3814:      	add	x0, x9, x8
    3818:      	add	x2, x20, #0x40
    381c:      	mov	w8, #0x4                // =4
    3820:      	blr	x8
    3824:      	ldr	x9, [sp, #0xe8]
    3828:      	mov	w8, #0x5f70             // =24432
    382c:      	add	x2, x20, #0x30
    3830:      	mov	w1, #0x8                // =8
    3834:      	add	x0, x9, x8
    3838:      	mov	w8, #0x4                // =4
    383c:      	blr	x8
    3840:      	add	x2, x20, #0x38
    3844:      	mov	w8, #0x4                // =4
    3848:      	mov	x0, x25
    384c:      	mov	w1, #0x8                // =8
    3850:      	blr	x8
    3854:      	ldr	x9, [sp, #0xe8]
    3858:      	mov	w8, #0x5f38             // =24376
    385c:      	add	x2, x24, #0xb50
    3860:      	add	x0, sp, #0xd8
    3864:      	mov	w1, #0x8                // =8
    3868:      	add	x25, x9, x8
    386c:      	add	x8, sp, #0xd8
    3870:      	mov	w9, #0x4                // =4
    3874:      	blr	x9
    3878:      	add	x12, sp, #0xd8
    387c:      	mov	w9, #0x48               // =72
    3880:      	add	x10, sp, #0x58
    3884:      	ldr	x8, [x12]
    3888:      	mov	w11, #0x4               // =4
    388c:      	add	x0, sp, #0x58
    3890:      	mov	w1, #0x48               // =72
    3894:      	ldr	x2, [x12]
    3898:      	blr	x11
    389c:      	ldr	x8, [sp, #0x60]
    38a0:      	mov	w9, #0x4                // =4
    38a4:      	mov	x0, x25
    38a8:      	mov	w1, #0x4                // =4
    38ac:      	add	x8, x8, #0x218
    38b0:      	ldr	x8, [sp, #0x60]
    38b4:      	ldr	x25, [sp, #0xe8]
    38b8:      	add	x2, x8, #0x218
    38bc:      	blr	x9
    38c0:      	mov	w8, #0x5f3c             // =24380
    38c4:      	mov	w9, #0x4                // =4
    38c8:      	mov	w1, #0x4                // =4
    38cc:      	add	x0, x25, x8
    38d0:      	ldr	x8, [sp, #0x68]
    38d4:      	add	x8, x8, #0x4d8
    38d8:      	ldr	x8, [sp, #0x68]
    38dc:      	add	x2, x8, #0x4d8
    38e0:      	blr	x9
    38e4:      	mov	w8, #0x5f40             // =24384
    38e8:      	mov	w9, #0x4                // =4
    38ec:      	mov	w1, #0x4                // =4
    38f0:      	add	x0, x25, x8
    38f4:      	ldr	x8, [sp, #0x70]
    38f8:      	add	x8, x8, #0x58
    38fc:      	ldr	x8, [sp, #0x70]
    3900:      	add	x2, x8, #0x58
    3904:      	blr	x9
    3908:      	str	xzr, [sp, #0xc0]
    390c:      	add	x2, x24, #0x938
    3910:      	add	x8, sp, #0xc0
    3914:      	add	x0, sp, #0xc0
    3918:      	mov	w1, #0x8                // =8
    391c:      	blr	x21
    3920:      	ldr	x8, [sp, #0xc0]
    3924:      	cbz	x8, 0x39ac <generic_rawtp_process_filter+0x50c>
    3928:      	str	wzr, [sp, #0xb8]
    392c:      	add	x8, x8, #0x4
    3930:      	add	x9, sp, #0xb8
    3934:      	mov	w10, #0x4               // =4
    3938:      	add	x0, sp, #0xb8
    393c:      	mov	w1, #0x4                // =4
    3940:      	mov	w19, #0x4               // =4
    3944:      	ldr	x8, [sp, #0xc0]
    3948:      	add	x2, x8, #0x4
    394c:      	blr	x10
    3950:      	ldr	x8, [sp, #0xc0]
    3954:      	ldrsw	x9, [sp, #0xb8]
    3958:      	add	x10, sp, #0xc8
    395c:      	mov	w11, #0x4               // =4
    3960:      	add	x0, sp, #0xc8
    3964:      	mov	w1, #0x10               // =16
    3968:      	add	x8, x8, x9, lsl #4
    396c:      	mov	w9, #0x10               // =16
    3970:      	add	x8, x8, #0x80
    3974:      	ldr	x8, [sp, #0xc0]
    3978:      	ldrsw	x9, [sp, #0xb8]
    397c:      	add	x8, x8, x9, lsl #4
    3980:      	add	x2, x8, #0x80
    3984:      	blr	x11
    3988:      	mov	w8, #0x5f44             // =24388
    398c:      	mov	w1, #0x4                // =4
    3990:      	add	x0, x25, x8
    3994:      	ldr	x8, [sp, #0xd0]
    3998:      	add	x8, x8, #0x158
    399c:      	ldr	x8, [sp, #0xd0]
    39a0:      	add	x2, x8, #0x158
    39a4:      	blr	x19
    39a8:      	b	0x39b0 <generic_rawtp_process_filter+0x510>
    39ac:      	str	wzr, [x29, #0x84]
    39b0:      	mov	w8, #0x5f48             // =24392
    39b4:      	mov	w9, #0x4                // =4
    39b8:      	mov	w1, #0x4                // =4
    39bc:      	mov	w19, #0x4               // =4
    39c0:      	add	x0, x25, x8
    39c4:      	ldr	x8, [sp, #0x78]
    39c8:      	add	x8, x8, #0x158
    39cc:      	ldr	x8, [sp, #0x78]
    39d0:      	add	x2, x8, #0x158
    39d4:      	blr	x9
    39d8:      	mov	w8, #0x5f4c             // =24396
    39dc:      	mov	w9, #0x4                // =4
    39e0:      	mov	w1, #0x4                // =4
    39e4:      	add	x0, x25, x8
    39e8:      	ldr	x8, [sp, #0x80]
    39ec:      	add	x8, x8, #0x118
    39f0:      	ldr	x8, [sp, #0x80]
    39f4:      	add	x2, x8, #0x118
    39f8:      	blr	x9
    39fc:      	mov	w8, #0x5f50             // =24400
    3a00:      	mov	w9, #0x4                // =4
    3a04:      	mov	w1, #0x4                // =4
    3a08:      	add	x0, x25, x8
    3a0c:      	ldr	x8, [sp, #0x88]
    3a10:      	add	x8, x8, #0x98
    3a14:      	ldr	x8, [sp, #0x88]
    3a18:      	add	x2, x8, #0x98
    3a1c:      	blr	x9
    3a20:      	mov	w8, #0x5f54             // =24404
    3a24:      	mov	w9, #0x4                // =4
    3a28:      	mov	w1, #0x4                // =4
    3a2c:      	add	x0, x25, x8
    3a30:      	ldr	x8, [sp, #0x90]
    3a34:      	add	x8, x8, #0x98
    3a38:      	ldr	x8, [sp, #0x90]
    3a3c:      	add	x2, x8, #0x98
    3a40:      	blr	x9
    3a44:      	mov	w8, #0x5f58             // =24408
    3a48:      	mov	w9, #0x4                // =4
    3a4c:      	mov	w1, #0x4                // =4
    3a50:      	add	x0, x25, x8
    3a54:      	ldr	x8, [sp, #0x98]
    3a58:      	add	x8, x8, #0x58
    3a5c:      	ldr	x8, [sp, #0x98]
    3a60:      	add	x2, x8, #0x58
    3a64:      	blr	x9
    3a68:      	stp	xzr, xzr, [sp, #0xc0]
    3a6c:      	mov	w20, #0x8               // =8
    3a70:      	add	x8, sp, #0xc8
    3a74:      	mov	w9, #0x4                // =4
    3a78:      	add	x0, sp, #0xc8
    3a7c:      	mov	w1, #0x8                // =8
    3a80:      	mov	x2, x23
    3a84:      	blr	x9
    3a88:      	ldr	x8, [sp, #0xc8]
    3a8c:      	add	x9, sp, #0xc0
    3a90:      	mov	w10, #0x4               // =4
    3a94:      	add	x0, sp, #0xc0
    3a98:      	mov	w1, #0x8                // =8
    3a9c:      	add	x8, x8, #0x90
    3aa0:      	ldr	x8, [sp, #0xc8]
    3aa4:      	add	x2, x8, #0x90
    3aa8:      	blr	x10
    3aac:      	mov	w8, #0x5f5c             // =24412
    3ab0:      	mov	w1, #0x4                // =4
    3ab4:      	add	x0, x25, x8
    3ab8:      	ldr	x8, [sp, #0xc0]
    3abc:      	add	x8, x8, #0x158
    3ac0:      	ldr	x8, [sp, #0xc0]
    3ac4:      	add	x2, x8, #0x158
    3ac8:      	blr	x19
    3acc:      	ldr	w8, [x29, #0x74]
    3ad0:      	cmp	w8, #0x1
    3ad4:      	b.ne	0x3ae4 <generic_rawtp_process_filter+0x644>
    3ad8:      	ldr	w8, [x29, #0x70]
    3adc:      	orr	w8, w8, #0x2000000
    3ae0:      	str	w8, [x29, #0x70]
    3ae4:      	add	x0, x29, #0xb8
    3ae8:      	mov	w1, wzr
    3aec:      	mov	w2, #0x308              // =776
    3af0:      	bl	0x3af0 <generic_rawtp_process_filter+0x650>
    3af4:      	mov	w8, #0x6290             // =25232
    3af8:      	add	x2, x24, #0x858
    3afc:      	mov	w19, #0x8               // =8
    3b00:      	mov	w9, #0x4                // =4
    3b04:      	add	x0, sp, #0xc8
    3b08:      	mov	w1, #0x8                // =8
    3b0c:      	mov	w20, #0x4               // =4
    3b10:      	add	x21, x25, x8
    3b14:      	add	x8, sp, #0xc8
    3b18:      	blr	x9
    3b1c:      	ldr	x8, [sp, #0xc8]
    3b20:      	add	x9, sp, #0x58
    3b24:      	add	x0, sp, #0x58
    3b28:      	mov	w1, #0x8                // =8
    3b2c:      	add	x8, x8, #0x528
    3b30:      	ldr	x8, [sp, #0xc8]
    3b34:      	add	x2, x8, #0x528
    3b38:      	blr	x20
    3b3c:      	str	wzr, [sp, #0xa4]
    3b40:      	adrp	x0, 0x3000 <generic_rawtp_process_event+0x2e30>
    3b44:      	ldr	x19, [sp, #0x58]
    3b48:      	mov	w8, #0x1                // =1
    3b4c:      	add	x9, sp, #0xa4
    3b50:      	add	x1, sp, #0xa4
    3b54:      	ldr	x0, [x0]
    3b58:      	blr	x8
    3b5c:      	cbz	x0, 0x3fcc <generic_rawtp_process_filter+0xb2c>
    3b60:      	mov	w8, #0x1000             // =4096
    3b64:      	stp	x21, x22, [sp, #0x30]
    3b68:      	mov	x24, x0
    3b6c:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    3b70:      	str	x29, [sp, #0x40]
    3b74:      	str	w8, [x29, #0x550]
    3b78:      	mov	w8, #0x23               // =35
    3b7c:      	blr	x8
    3b80:      	add	x2, x0, #0xb30
    3b84:      	mov	w23, #0x8               // =8
    3b88:      	add	x8, sp, #0xa8
    3b8c:      	mov	w9, #0x4                // =4
    3b90:      	add	x0, sp, #0xa8
    3b94:      	mov	w1, #0x8                // =8
    3b98:      	mov	w29, #0x4               // =4
    3b9c:      	blr	x9
    3ba0:      	ldr	x22, [sp, #0xa8]
    3ba4:      	add	x25, x19, #0x48
    3ba8:      	add	x8, sp, #0xb0
    3bac:      	mov	w9, #0x4                // =4
    3bb0:      	add	x0, sp, #0xb0
    3bb4:      	mov	w1, #0x8                // =8
    3bb8:      	mov	x2, x25
    3bbc:      	blr	x9
    3bc0:      	ldr	x21, [sp, #0xb0]
    3bc4:      	add	x8, sp, #0x58
    3bc8:      	add	x0, sp, #0x58
    3bcc:      	mov	w1, #0x8                // =8
    3bd0:      	add	x2, x21, #0x10
    3bd4:      	blr	x29
    3bd8:      	ldr	x8, [sp, #0x58]
    3bdc:      	cbz	x8, 0x3e50 <generic_rawtp_process_filter+0x9b0>
    3be0:      	ldr	x8, [sp, #0x40]
    3be4:      	stp	xzr, xzr, [sp, #0x58]
    3be8:      	add	x21, x22, #0x18
    3bec:      	add	x9, sp, #0x58
    3bf0:      	add	x2, x22, #0x20
    3bf4:      	mov	w22, #0x8               // =8
    3bf8:      	stp	x24, xzr, [sp, #0x68]
    3bfc:      	add	x0, sp, #0x58
    3c00:      	mov	w1, #0x8                // =8
    3c04:      	add	x29, x19, #0x40
    3c08:      	add	x19, x9, #0x8
    3c0c:      	add	x24, x9, #0x18
    3c10:      	stp	xzr, xzr, [sp, #0x78]
    3c14:      	add	x23, x9, #0x20
    3c18:      	str	x20, [sp, #0x88]
    3c1c:      	str	x20, [sp, #0x28]
    3c20:      	mov	w20, #0x4               // =4
    3c24:      	ldr	w8, [x8, #0x550]
    3c28:      	strb	wzr, [sp, #0x94]
    3c2c:      	str	w8, [sp, #0x90]
    3c30:      	mov	w8, #0x4                // =4
    3c34:      	blr	x8
    3c38:      	mov	w8, #0x4                // =4
    3c3c:      	mov	x0, x19
    3c40:      	mov	w1, #0x8                // =8
    3c44:      	mov	x2, x21
    3c48:      	blr	x8
    3c4c:      	mov	w8, #0x4                // =4
    3c50:      	mov	x0, x24
    3c54:      	mov	w1, #0x8                // =8
    3c58:      	mov	x2, x25
    3c5c:      	blr	x8
    3c60:      	mov	x0, x23
    3c64:      	mov	w1, #0x8                // =8
    3c68:      	mov	x2, x29
    3c6c:      	blr	x20
    3c70:      	ldr	x8, [sp, #0x78]
    3c74:      	mov	w19, #0x80              // =128
    3c78:      	add	x21, sp, #0xb8
    3c7c:      	add	x23, sp, #0xd8
    3c80:      	sub	x8, x8, #0x20
    3c84:      	str	x8, [sp, #0x80]
    3c88:      	b	0x3c94 <generic_rawtp_process_filter+0x7f4>
    3c8c:      	subs	w19, w19, #0x1
    3c90:      	b.eq	0x3e00 <generic_rawtp_process_filter+0x960>
    3c94:      	ldp	x20, x2, [sp, #0x70]
    3c98:      	ldp	x8, x9, [sp, #0x58]
    3c9c:      	cmp	x20, x8
    3ca0:      	ccmp	x2, x9, #0x0, eq
    3ca4:      	b.eq	0x3df8 <generic_rawtp_process_filter+0x958>
    3ca8:      	ldr	x29, [sp, #0x80]
    3cac:      	mov	w8, #0x4                // =4
    3cb0:      	add	x0, sp, #0xb8
    3cb4:      	mov	w1, #0x8                // =8
    3cb8:      	blr	x8
    3cbc:      	ldr	x8, [sp, #0xb8]
    3cc0:      	cmp	x20, x8
    3cc4:      	b.eq	0x3dac <generic_rawtp_process_filter+0x90c>
    3cc8:      	add	x25, x20, #0x18
    3ccc:      	mov	w8, #0x4                // =4
    3cd0:      	add	x0, sp, #0xd8
    3cd4:      	mov	w1, #0x8                // =8
    3cd8:      	mov	x2, x25
    3cdc:      	blr	x8
    3ce0:      	add	x8, sp, #0xd8
    3ce4:      	ldr	x8, [x8]
    3ce8:      	cmp	x8, x20
    3cec:      	b.eq	0x3dac <generic_rawtp_process_filter+0x90c>
    3cf0:      	mov	w8, #0x4                // =4
    3cf4:      	add	x9, sp, #0xc0
    3cf8:      	add	x0, sp, #0xc0
    3cfc:      	mov	w1, #0x8                // =8
    3d00:      	mov	x2, x25
    3d04:      	blr	x8
    3d08:      	add	x2, x20, #0x20
    3d0c:      	mov	w8, #0x4                // =4
    3d10:      	mov	w9, #0x10               // =16
    3d14:      	add	x10, sp, #0xc8
    3d18:      	add	x0, sp, #0xc8
    3d1c:      	mov	w1, #0x10               // =16
    3d20:      	blr	x8
    3d24:      	ldr	w20, [sp, #0xcc]
    3d28:      	ldr	x8, [sp, #0x68]
    3d2c:      	ldr	x10, [sp, #0x88]
    3d30:      	sub	x12, x10, x8
    3d34:      	ldr	w25, [sp, #0x90]
    3d38:      	subs	w10, w20, w25
    3d3c:      	ldr	x9, [sp, #0xd0]
    3d40:      	csel	w10, wzr, w10, lo
    3d44:      	cmp	w25, w20
    3d48:      	csel	w11, w25, w20, lo
    3d4c:      	cinc	w13, w11, hi
    3d50:      	sub	w14, w25, w13
    3d54:      	subs	x12, x12, x13
    3d58:      	str	w14, [sp, #0x90]
    3d5c:      	b.lo	0x3e00 <generic_rawtp_process_filter+0x960>
    3d60:      	cmp	x12, #0xfff
    3d64:      	b.hi	0x3e00 <generic_rawtp_process_filter+0x960>
    3d68:      	cmp	w25, w20
    3d6c:      	b.ls	0x3d78 <generic_rawtp_process_filter+0x8d8>
    3d70:      	mov	w13, #0x2f              // =47
    3d74:      	strb	w13, [x8, x12]
    3d78:      	add	x29, x8, x12
    3d7c:      	cmp	w25, w20
    3d80:      	add	x2, x9, x10
    3d84:      	and	w1, w11, #0xff
    3d88:      	mov	w8, #0x4                // =4
    3d8c:      	cinc	x0, x29, hi
    3d90:      	blr	x8
    3d94:      	cmp	w25, w20
    3d98:      	str	x29, [sp, #0x88]
    3d9c:      	b.ls	0x3e00 <generic_rawtp_process_filter+0x960>
    3da0:      	ldr	x8, [sp, #0xc0]
    3da4:      	str	x8, [sp, #0x70]
    3da8:      	b	0x3c8c <generic_rawtp_process_filter+0x7ec>
    3dac:      	add	x2, x29, #0x10
    3db0:      	mov	w8, #0x4                // =4
    3db4:      	add	x0, sp, #0xd8
    3db8:      	mov	w1, #0x8                // =8
    3dbc:      	blr	x8
    3dc0:      	add	x20, sp, #0xd8
    3dc4:      	ldr	x8, [sp, #0x80]
    3dc8:      	ldr	x9, [x20]
    3dcc:      	cmp	x8, x9
    3dd0:      	b.eq	0x3df8 <generic_rawtp_process_filter+0x958>
    3dd4:      	add	x2, x29, #0x18
    3dd8:      	mov	w8, #0x4                // =4
    3ddc:      	mov	x0, x24
    3de0:      	mov	w1, #0x8                // =8
    3de4:      	blr	x8
    3de8:      	ldr	x8, [x20]
    3dec:      	add	x9, x8, #0x20
    3df0:      	stp	x9, x8, [sp, #0x78]
    3df4:      	b	0x3c8c <generic_rawtp_process_filter+0x7ec>
    3df8:      	mov	w8, #0x1                // =1
    3dfc:      	strb	w8, [sp, #0x94]
    3e00:      	ldr	x24, [sp, #0x88]
    3e04:      	ldr	x9, [sp, #0x28]
    3e08:      	cmp	x24, x9
    3e0c:      	b.eq	0x3ea0 <generic_rawtp_process_filter+0xa00>
    3e10:      	ldrb	w8, [sp, #0x94]
    3e14:      	ldp	x22, x29, [sp, #0x38]
    3e18:      	cmp	w8, #0x0
    3e1c:      	ldr	x21, [sp, #0x30]
    3e20:      	cset	w8, eq
    3e24:      	lsl	w9, w8, #1
    3e28:      	ldr	w8, [sp, #0x90]
    3e2c:      	str	w9, [x29, #0x554]
    3e30:      	cmp	w8, #0x1
    3e34:      	str	w8, [x29, #0x550]
    3e38:      	b.lt	0x3e48 <generic_rawtp_process_filter+0x9a8>
    3e3c:      	mov	w9, #0x1000             // =4096
    3e40:      	sub	w8, w9, w8
    3e44:      	str	w8, [x29, #0x550]
    3e48:      	cbnz	x24, 0x3eb4 <generic_rawtp_process_filter+0xa14>
    3e4c:      	b	0x3fcc <generic_rawtp_process_filter+0xb2c>
    3e50:      	add	x2, x21, #0x18
    3e54:      	mov	w8, #0x8                // =8
    3e58:      	mov	w9, #0x4                // =4
    3e5c:      	add	x10, sp, #0x58
    3e60:      	add	x0, sp, #0x58
    3e64:      	mov	w1, #0x8                // =8
    3e68:      	blr	x9
    3e6c:      	ldr	x8, [sp, #0x58]
    3e70:      	cmp	x8, x21
    3e74:      	b.eq	0x3be0 <generic_rawtp_process_filter+0x740>
    3e78:      	ldr	x29, [sp, #0x40]
    3e7c:      	ldr	w9, [x29, #0x550]
    3e80:      	sub	w8, w9, #0xa
    3e84:      	cmp	w9, #0x9
    3e88:      	str	w8, [x29, #0x550]
    3e8c:      	b.gt	0x4370 <generic_rawtp_process_filter+0xed0>
    3e90:      	mov	w9, #-0x24              // =-36
    3e94:      	mov	x24, x20
    3e98:      	str	w9, [x29, #0x554]
    3e9c:      	b	0x3eb0 <generic_rawtp_process_filter+0xa10>
    3ea0:      	ldr	x29, [sp, #0x40]
    3ea4:      	mov	w8, wzr
    3ea8:      	mov	x24, x9
    3eac:      	str	xzr, [x29, #0x550]
    3eb0:      	ldp	x21, x22, [sp, #0x30]
    3eb4:      	subs	w9, w8, #0x7f
    3eb8:      	mov	w10, #0x7f              // =127
    3ebc:      	mov	x11, x29
    3ec0:      	mov	x0, x21
    3ec4:      	mov	x2, x24
    3ec8:      	csel	w29, w8, w10, lo
    3ecc:      	csel	w19, wzr, w9, lo
    3ed0:      	cmp	w8, #0xff
    3ed4:      	mov	w9, #0xff               // =255
    3ed8:      	csel	w8, w8, w9, lo
    3edc:      	and	w1, w8, #0xff
    3ee0:      	str	w1, [x11, #0x550]
    3ee4:      	mov	w8, #0x4                // =4
    3ee8:      	blr	x8
    3eec:      	adrp	x25, 0x3000 <generic_rawtp_process_event+0x2e30>
    3ef0:      	ldr	x25, [x25]
    3ef4:      	cbz	x0, 0x3f64 <generic_rawtp_process_filter+0xac4>
    3ef8:      	neg	w8, w0
    3efc:      	mov	w9, #0x1                // =1
    3f00:      	add	x1, sp, #0x58
    3f04:      	strh	w8, [sp, #0x58]
    3f08:      	mov	w8, #0x8                // =8
    3f0c:      	mov	x0, x25
    3f10:      	mov	w20, #0x1               // =1
    3f14:      	strh	w8, [sp, #0x5a]
    3f18:      	mov	x8, #0x2de              // =734
    3f1c:      	movk	x8, #0x4, lsl #32
    3f20:      	stur	x8, [sp, #0x5c]
    3f24:      	add	x8, sp, #0x58
    3f28:      	blr	x9
    3f2c:      	cbz	x0, 0x3f40 <generic_rawtp_process_filter+0xaa0>
    3f30:      	ldr	w8, [x0]
    3f34:      	add	w8, w8, #0x1
    3f38:      	str	w8, [x0]
    3f3c:      	b	0x3f64 <generic_rawtp_process_filter+0xac4>
    3f40:      	str	w20, [sp, #0xc8]
    3f44:      	mov	x3, xzr
    3f48:      	mov	w8, #0x2                // =2
    3f4c:      	add	x9, sp, #0x58
    3f50:      	add	x10, sp, #0xc8
    3f54:      	add	x1, sp, #0x58
    3f58:      	add	x2, sp, #0xc8
    3f5c:      	mov	x0, x25
    3f60:      	blr	x8
    3f64:      	ldr	x9, [sp, #0xe8]
    3f68:      	mov	w8, #0x6390             // =25488
    3f6c:      	add	x2, x24, x19
    3f70:      	mov	w1, w29
    3f74:      	add	x0, x9, x8
    3f78:      	mov	w8, #0x4                // =4
    3f7c:      	blr	x8
    3f80:      	ldr	x29, [sp, #0x40]
    3f84:      	cbz	x0, 0x3fcc <generic_rawtp_process_filter+0xb2c>
    3f88:      	neg	w8, w0
    3f8c:      	mov	w9, #0x1                // =1
    3f90:      	add	x1, sp, #0x58
    3f94:      	strh	w8, [sp, #0x58]
    3f98:      	mov	w8, #0x8                // =8
    3f9c:      	mov	x0, x25
    3fa0:      	mov	w19, #0x1               // =1
    3fa4:      	strh	w8, [sp, #0x5a]
    3fa8:      	mov	x8, #0x2e0              // =736
    3fac:      	movk	x8, #0x4, lsl #32
    3fb0:      	stur	x8, [sp, #0x5c]
    3fb4:      	add	x8, sp, #0x58
    3fb8:      	blr	x9
    3fbc:      	cbz	x0, 0x3ff0 <generic_rawtp_process_filter+0xb50>
    3fc0:      	ldr	w8, [x0]
    3fc4:      	add	w8, w8, #0x1
    3fc8:      	str	w8, [x0]
    3fcc:      	ldr	w8, [x29, #0x550]
    3fd0:      	sub	w9, w8, #0x101
    3fd4:      	cmn	w9, #0x101
    3fd8:      	b.hi	0x4024 <generic_rawtp_process_filter+0xb84>
    3fdc:      	ldr	x20, [sp, #0xe8]
    3fe0:      	ldr	x24, [sp, #0x48]
    3fe4:      	mov	w8, #-0x1               // =-1
    3fe8:      	stur	w8, [x29, #0xb8]
    3fec:      	b	0x4170 <generic_rawtp_process_filter+0xcd0>
    3ff0:      	str	w19, [sp, #0xc8]
    3ff4:      	mov	x3, xzr
    3ff8:      	mov	w8, #0x2                // =2
    3ffc:      	add	x9, sp, #0x58
    4000:      	add	x10, sp, #0xc8
    4004:      	add	x1, sp, #0x58
    4008:      	add	x2, sp, #0xc8
    400c:      	mov	x0, x25
    4010:      	blr	x8
    4014:      	ldr	w8, [x29, #0x550]
    4018:      	sub	w9, w8, #0x101
    401c:      	cmn	w9, #0x101
    4020:      	b.ls	0x3fdc <generic_rawtp_process_filter+0xb3c>
    4024:      	ldr	x20, [sp, #0xe8]
    4028:      	and	x24, x8, #0xff
    402c:      	mov	w8, #0x5f80             // =24448
    4030:      	mov	x2, x21
    4034:      	mov	w1, w24
    4038:      	add	x0, x20, x8
    403c:      	mov	w8, #0x4                // =4
    4040:      	blr	x8
    4044:      	mov	x23, x0
    4048:      	cbz	x0, 0x40c4 <generic_rawtp_process_filter+0xc24>
    404c:      	neg	w8, w23
    4050:      	adrp	x25, 0x4000 <generic_rawtp_process_filter+0xb60>
    4054:      	mov	w9, #0x1                // =1
    4058:      	strh	w8, [sp, #0x58]
    405c:      	mov	w8, #0xf                // =15
    4060:      	add	x1, sp, #0x58
    4064:      	mov	w19, #0x1               // =1
    4068:      	strh	w8, [sp, #0x5a]
    406c:      	mov	x8, #0x164              // =356
    4070:      	movk	x8, #0x4, lsl #32
    4074:      	stur	x8, [sp, #0x5c]
    4078:      	add	x8, sp, #0x58
    407c:      	ldr	x25, [x25]
    4080:      	mov	x0, x25
    4084:      	blr	x9
    4088:      	cbz	x0, 0x409c <generic_rawtp_process_filter+0xbfc>
    408c:      	ldr	w8, [x0]
    4090:      	add	w8, w8, #0x1
    4094:      	str	w8, [x0]
    4098:      	b	0x40c0 <generic_rawtp_process_filter+0xc20>
    409c:      	str	w19, [sp, #0xc8]
    40a0:      	mov	x3, xzr
    40a4:      	mov	w8, #0x2                // =2
    40a8:      	add	x9, sp, #0x58
    40ac:      	add	x10, sp, #0xc8
    40b0:      	add	x1, sp, #0x58
    40b4:      	add	x2, sp, #0xc8
    40b8:      	mov	x0, x25
    40bc:      	blr	x8
    40c0:      	ldr	x20, [sp, #0xe8]
    40c4:      	cmp	w23, #0x0
    40c8:      	csel	w8, w24, w23, eq
    40cc:      	cmp	w24, #0x7f
    40d0:      	stur	w8, [x29, #0xb8]
    40d4:      	mov	w8, #0x7f               // =127
    40d8:      	csel	w1, w24, w8, lo
    40dc:      	mov	w8, #0x6080             // =24704
    40e0:      	add	x0, x20, x8
    40e4:      	mov	w8, #0x6390             // =25488
    40e8:      	add	x2, x20, x8
    40ec:      	mov	w8, #0x4                // =4
    40f0:      	blr	x8
    40f4:      	ldr	x24, [sp, #0x48]
    40f8:      	cbz	x0, 0x4170 <generic_rawtp_process_filter+0xcd0>
    40fc:      	neg	w8, w0
    4100:      	adrp	x23, 0x4000 <generic_rawtp_process_filter+0xb60>
    4104:      	mov	w9, #0x1                // =1
    4108:      	strh	w8, [sp, #0x58]
    410c:      	mov	w8, #0xf                // =15
    4110:      	add	x1, sp, #0x58
    4114:      	mov	w19, #0x1               // =1
    4118:      	strh	w8, [sp, #0x5a]
    411c:      	mov	x8, #0x16a              // =362
    4120:      	movk	x8, #0x4, lsl #32
    4124:      	stur	x8, [sp, #0x5c]
    4128:      	add	x8, sp, #0x58
    412c:      	ldr	x23, [x23]
    4130:      	mov	x0, x23
    4134:      	blr	x9
    4138:      	cbz	x0, 0x414c <generic_rawtp_process_filter+0xcac>
    413c:      	ldr	w8, [x0]
    4140:      	add	w8, w8, #0x1
    4144:      	str	w8, [x0]
    4148:      	b	0x4170 <generic_rawtp_process_filter+0xcd0>
    414c:      	str	w19, [sp, #0xc8]
    4150:      	mov	x3, xzr
    4154:      	mov	w8, #0x2                // =2
    4158:      	add	x9, sp, #0x58
    415c:      	add	x10, sp, #0xc8
    4160:      	add	x1, sp, #0x58
    4164:      	add	x2, sp, #0xc8
    4168:      	mov	x0, x23
    416c:      	blr	x8
    4170:      	ldrb	w8, [x20, #0x1]
    4174:      	orr	w8, w8, #0x10
    4178:      	strb	w8, [x20, #0x1]
    417c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4180:      	mov	w8, #0x5ef8             // =24312
    4184:      	ldr	x0, [x0]
    4188:      	add	x1, x20, x8
    418c:      	mov	w8, #0x1                // =1
    4190:      	blr	x8
    4194:      	cbz	x0, 0x5374 <generic_rawtp_process_filter+0x1ed4>
    4198:      	ldr	x21, [x20, #0x5eb8]
    419c:      	cmp	x21, #0x6
    41a0:      	b.hs	0x4338 <generic_rawtp_process_filter+0xe98>
    41a4:      	ldrsw	x8, [x0]
    41a8:      	mov	x23, x0
    41ac:      	cbz	w8, 0x4354 <generic_rawtp_process_filter+0xeb4>
    41b0:      	cmp	x21, x8
    41b4:      	b.hs	0x4338 <generic_rawtp_process_filter+0xe98>
    41b8:      	str	x8, [sp, #0x28]
    41bc:      	stp	x29, x24, [sp, #0x40]
    41c0:      	adrp	x24, 0x4000 <generic_rawtp_process_filter+0xb60>
    41c4:      	mov	w8, #0x1                // =1
    41c8:      	add	x9, sp, #0x58
    41cc:      	str	x20, [sp, #0xe8]
    41d0:      	add	x1, sp, #0x58
    41d4:      	str	x22, [sp, #0x38]
    41d8:      	str	w21, [sp, #0x58]
    41dc:      	str	wzr, [sp, #0xc8]
    41e0:      	ldr	x24, [x24]
    41e4:      	mov	x0, x24
    41e8:      	blr	x8
    41ec:      	cbz	x0, 0x44a0 <generic_rawtp_process_filter+0x1000>
    41f0:      	ldr	w8, [x0]
    41f4:      	mov	x25, x0
    41f8:      	cbz	w8, 0x44a0 <generic_rawtp_process_filter+0x1000>
    41fc:      	ldr	x9, [sp, #0x48]
    4200:      	ldr	w9, [x9, #0x68]
    4204:      	tbnz	w9, #0x1f, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4208:      	cmp	w8, #0x1b
    420c:      	b.hi	0x531c <generic_rawtp_process_filter+0x1e7c>
    4210:      	mov	w9, #0x1                // =1
    4214:      	lsl	w9, w9, w8
    4218:      	tst	w9, #0x60
    421c:      	b.ne	0x4414 <generic_rawtp_process_filter+0xf74>
    4220:      	mov	w10, #0x100             // =256
    4224:      	movk	w10, #0x400, lsl #16
    4228:      	tst	w9, w10
    422c:      	b.ne	0x4390 <generic_rawtp_process_filter+0xef0>
    4230:      	mov	w9, #0x1                // =1
    4234:      	lsl	w8, w9, w8
    4238:      	mov	w9, #0x200              // =512
    423c:      	movk	w9, #0x800, lsl #16
    4240:      	tst	w8, w9
    4244:      	b.eq	0x531c <generic_rawtp_process_filter+0x1e7c>
    4248:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    424c:      	add	x1, x25, #0x4
    4250:      	mov	w8, #0x1                // =1
    4254:      	ldr	x0, [x0]
    4258:      	blr	x8
    425c:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4260:      	ldr	x8, [sp, #0x48]
    4264:      	mov	x20, x0
    4268:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    426c:      	mov	w9, #0x7f               // =127
    4270:      	ldr	w8, [x8, #0x68]
    4274:      	ldr	x0, [x0]
    4278:      	add	x1, sp, #0xc8
    427c:      	cmp	w8, #0x7f
    4280:      	csel	w19, w8, w9, lt
    4284:      	mov	w8, #0x1                // =1
    4288:      	add	x9, sp, #0xc8
    428c:      	blr	x8
    4290:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4294:      	sxtw	x1, w19
    4298:      	mov	x29, x0
    429c:      	lsl	w8, w1, #3
    42a0:      	str	w8, [x0]
    42a4:      	ldr	x8, [sp, #0x48]
    42a8:      	ldr	w8, [x8, #0x6c]
    42ac:      	cbnz	w8, 0x430c <generic_rawtp_process_filter+0xe6c>
    42b0:      	ldr	x11, [sp, #0x48]
    42b4:      	and	w13, w1, #0x7f
    42b8:      	mov	x8, xzr
    42bc:      	ldr	w12, [x11, #0x68]
    42c0:      	add	x9, x11, #0x1f0
    42c4:      	add	x10, x11, #0x170
    42c8:      	sub	w11, w12, w1
    42cc:      	add	w12, w12, w13
    42d0:      	add	w11, w11, w13
    42d4:      	mvn	w13, w1
    42d8:      	add	w12, w13, w12
    42dc:      	cmp	x8, #0x7f
    42e0:      	b.eq	0x4300 <generic_rawtp_process_filter+0xe60>
    42e4:      	and	x13, x12, #0x7f
    42e8:      	sub	w12, w12, #0x1
    42ec:      	ldrb	w13, [x10, x13]
    42f0:      	strb	w13, [x9, x8]
    42f4:      	add	x8, x8, #0x1
    42f8:      	cmp	x11, x8
    42fc:      	b.ne	0x42dc <generic_rawtp_process_filter+0xe3c>
    4300:      	ldr	x9, [sp, #0x48]
    4304:      	mov	w8, #0x1                // =1
    4308:      	str	w8, [x9, #0x6c]
    430c:      	cmp	w1, #0x7f
    4310:      	b.hi	0x432c <generic_rawtp_process_filter+0xe8c>
    4314:      	ldr	x8, [sp, #0x48]
    4318:      	add	x0, x29, #0x4
    431c:      	add	x2, x8, #0x1f0
    4320:      	mov	w8, #0x4                // =4
    4324:      	blr	x8
    4328:      	tbnz	x0, #0x3f, 0x531c <generic_rawtp_process_filter+0x1e7c>
    432c:      	mov	w8, #0x1                // =1
    4330:      	mov	x0, x20
    4334:      	b	0x440c <generic_rawtp_process_filter+0xf6c>
    4338:      	ldr	w8, [x24]
    433c:      	str	w8, [x20, #0x10]
    4340:      	ldr	x8, [x24, #0x8]
    4344:      	str	x8, [x20, #0x18]
    4348:      	ldrb	w8, [x29]
    434c:      	cbnz	w8, 0x5358 <generic_rawtp_process_filter+0x1eb8>
    4350:      	b	0x5374 <generic_rawtp_process_filter+0x1ed4>
    4354:      	mov	w8, #0x1                // =1
    4358:      	strb	w8, [x29]
    435c:      	ldr	w8, [x24]
    4360:      	str	w8, [x20, #0x10]
    4364:      	ldr	x8, [x24, #0x8]
    4368:      	str	x8, [x20, #0x18]
    436c:      	b	0x5358 <generic_rawtp_process_filter+0x1eb8>
    4370:      	mov	w8, #0x2964             // =10596
    4374:      	add	x20, x24, #0xff6
    4378:      	strh	w8, [x24, #0xffe]
    437c:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0xb60>
    4380:      	add	x8, x8, #0x0
    4384:      	ldr	x8, [x8]
    4388:      	str	x8, [x20]
    438c:      	b	0x3be0 <generic_rawtp_process_filter+0x740>
    4390:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4394:      	add	x1, x25, #0x4
    4398:      	mov	w8, #0x1                // =1
    439c:      	ldr	x0, [x0]
    43a0:      	blr	x8
    43a4:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    43a8:      	mov	x19, x0
    43ac:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    43b0:      	mov	w8, #0x1                // =1
    43b4:      	ldr	x0, [x0]
    43b8:      	add	x9, sp, #0xc8
    43bc:      	add	x1, sp, #0xc8
    43c0:      	blr	x8
    43c4:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    43c8:      	mov	w1, wzr
    43cc:      	mov	w2, #0x104              // =260
    43d0:      	mov	x29, x0
    43d4:      	bl	0x43d4 <generic_rawtp_process_filter+0xf34>
    43d8:      	ldr	x10, [sp, #0x48]
    43dc:      	mov	x0, x29
    43e0:      	ldr	w8, [x10, #0x68]
    43e4:      	add	x2, x10, #0x70
    43e8:      	lsl	w9, w8, #3
    43ec:      	and	x8, x8, #0xff
    43f0:      	str	w9, [x0], #0x4
    43f4:      	mov	w9, #0x4                // =4
    43f8:      	ldrb	w1, [x10, #0x68]
    43fc:      	blr	x9
    4400:      	tbnz	x0, #0x3f, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4404:      	mov	w8, #0x1                // =1
    4408:      	mov	x0, x19
    440c:      	mov	x1, x29
    4410:      	b	0x4468 <generic_rawtp_process_filter+0xfc8>
    4414:      	ldr	w8, [x25, #0x8]
    4418:      	cmn	w8, #0x1
    441c:      	b.eq	0x4440 <generic_rawtp_process_filter+0xfa0>
    4420:      	ldr	x9, [sp, #0x48]
    4424:      	ldr	x9, [x9, #0x370]
    4428:      	lsr	x8, x9, x8
    442c:      	tbz	w8, #0x0, 0x4440 <generic_rawtp_process_filter+0xfa0>
    4430:      	mov	x0, #0xffee             // =65518
    4434:      	movk	x0, #0xadc0, lsl #16
    4438:      	movk	x0, #0xb, lsl #32
    443c:      	b	0x446c <generic_rawtp_process_filter+0xfcc>
    4440:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4444:      	mov	w8, #0x1                // =1
    4448:      	add	x9, sp, #0x58
    444c:      	ldr	x0, [x0]
    4450:      	add	x1, sp, #0x58
    4454:      	blr	x8
    4458:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    445c:      	ldr	x8, [sp, #0x48]
    4460:      	add	x1, x8, #0x70
    4464:      	mov	w8, #0x1                // =1
    4468:      	blr	x8
    446c:      	ldr	w8, [x25]
    4470:      	cmp	w8, #0x25
    4474:      	b.hi	0x449c <generic_rawtp_process_filter+0xffc>
    4478:      	mov	w9, #0x1                // =1
    447c:      	lsl	x8, x9, x8
    4480:      	mov	x9, #0x50               // =80
    4484:      	movk	x9, #0xc00, lsl #16
    4488:      	movk	x9, #0x20, lsl #32
    448c:      	tst	x8, x9
    4490:      	b.eq	0x449c <generic_rawtp_process_filter+0xffc>
    4494:      	cbnz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4498:      	b	0x44a0 <generic_rawtp_process_filter+0x1000>
    449c:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    44a0:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0xb60>
    44a4:      	ldr	x8, [x8]
    44a8:      	ldrb	w8, [x8]
    44ac:      	cbz	w8, 0x4724 <generic_rawtp_process_filter+0x1284>
    44b0:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    44b4:      	mov	w8, #0x1                // =1
    44b8:      	ldr	x0, [x0]
    44bc:      	ldr	x1, [sp, #0x48]
    44c0:      	blr	x8
    44c4:      	cbz	x0, 0x4724 <generic_rawtp_process_filter+0x1284>
    44c8:      	add	w8, w21, #0x5
    44cc:      	str	wzr, [sp, #0xc8]
    44d0:      	add	x9, sp, #0x58
    44d4:      	mov	x25, x0
    44d8:      	str	w8, [sp, #0x58]
    44dc:      	mov	w8, #0x1                // =1
    44e0:      	add	x1, sp, #0x58
    44e4:      	mov	x0, x24
    44e8:      	blr	x8
    44ec:      	cbz	x0, 0x4724 <generic_rawtp_process_filter+0x1284>
    44f0:      	ldr	w8, [x0]
    44f4:      	mov	x24, x0
    44f8:      	cbz	w8, 0x4724 <generic_rawtp_process_filter+0x1284>
    44fc:      	ldr	w9, [x25]
    4500:      	tbnz	w9, #0x1f, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4504:      	cmp	w8, #0x1b
    4508:      	b.hi	0x531c <generic_rawtp_process_filter+0x1e7c>
    450c:      	mov	w9, #0x1                // =1
    4510:      	lsl	w9, w9, w8
    4514:      	tst	w9, #0x60
    4518:      	b.ne	0x46a0 <generic_rawtp_process_filter+0x1200>
    451c:      	mov	w10, #0x100             // =256
    4520:      	movk	w10, #0x400, lsl #16
    4524:      	tst	w9, w10
    4528:      	b.ne	0x4620 <generic_rawtp_process_filter+0x1180>
    452c:      	mov	w9, #0x1                // =1
    4530:      	lsl	w8, w9, w8
    4534:      	mov	w9, #0x200              // =512
    4538:      	movk	w9, #0x800, lsl #16
    453c:      	tst	w8, w9
    4540:      	b.eq	0x531c <generic_rawtp_process_filter+0x1e7c>
    4544:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4548:      	add	x1, x24, #0x4
    454c:      	mov	w8, #0x1                // =1
    4550:      	ldr	x0, [x0]
    4554:      	blr	x8
    4558:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    455c:      	ldr	w8, [x25]
    4560:      	mov	x20, x0
    4564:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4568:      	mov	w9, #0x7f               // =127
    456c:      	ldr	x0, [x0]
    4570:      	add	x1, sp, #0xc8
    4574:      	cmp	w8, #0x7f
    4578:      	csel	w19, w8, w9, lt
    457c:      	mov	w8, #0x1                // =1
    4580:      	add	x9, sp, #0xc8
    4584:      	blr	x8
    4588:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    458c:      	sxtw	x1, w19
    4590:      	mov	x29, x0
    4594:      	lsl	w8, w1, #3
    4598:      	str	w8, [x0]
    459c:      	ldr	w8, [x25, #0x4]
    45a0:      	cbnz	w8, 0x45f8 <generic_rawtp_process_filter+0x1158>
    45a4:      	ldr	w12, [x25]
    45a8:      	and	w13, w1, #0x7f
    45ac:      	mov	x8, xzr
    45b0:      	add	x9, x25, #0x188
    45b4:      	add	x10, x25, #0x108
    45b8:      	sub	w11, w12, w1
    45bc:      	add	w12, w12, w13
    45c0:      	add	w11, w11, w13
    45c4:      	mvn	w13, w1
    45c8:      	add	w12, w13, w12
    45cc:      	cmp	x8, #0x7f
    45d0:      	b.eq	0x45f0 <generic_rawtp_process_filter+0x1150>
    45d4:      	and	x13, x12, #0x7f
    45d8:      	sub	w12, w12, #0x1
    45dc:      	ldrb	w13, [x10, x13]
    45e0:      	strb	w13, [x9, x8]
    45e4:      	add	x8, x8, #0x1
    45e8:      	cmp	x11, x8
    45ec:      	b.ne	0x45cc <generic_rawtp_process_filter+0x112c>
    45f0:      	mov	w8, #0x1                // =1
    45f4:      	str	w8, [x25, #0x4]
    45f8:      	cmp	w1, #0x7f
    45fc:      	b.hi	0x4614 <generic_rawtp_process_filter+0x1174>
    4600:      	add	x0, x29, #0x4
    4604:      	add	x2, x25, #0x188
    4608:      	mov	w8, #0x4                // =4
    460c:      	blr	x8
    4610:      	tbnz	x0, #0x3f, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4614:      	mov	w8, #0x1                // =1
    4618:      	mov	x0, x20
    461c:      	b	0x4698 <generic_rawtp_process_filter+0x11f8>
    4620:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4624:      	add	x1, x24, #0x4
    4628:      	mov	w8, #0x1                // =1
    462c:      	ldr	x0, [x0]
    4630:      	blr	x8
    4634:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4638:      	mov	x19, x0
    463c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4640:      	mov	w8, #0x1                // =1
    4644:      	ldr	x0, [x0]
    4648:      	add	x9, sp, #0xc8
    464c:      	add	x1, sp, #0xc8
    4650:      	blr	x8
    4654:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4658:      	mov	w1, wzr
    465c:      	mov	w2, #0x104              // =260
    4660:      	mov	x29, x0
    4664:      	bl	0x4664 <generic_rawtp_process_filter+0x11c4>
    4668:      	ldr	w8, [x25]
    466c:      	mov	x0, x29
    4670:      	add	x2, x25, #0x8
    4674:      	lsl	w9, w8, #3
    4678:      	and	x8, x8, #0xff
    467c:      	str	w9, [x0], #0x4
    4680:      	mov	w9, #0x4                // =4
    4684:      	ldrb	w1, [x25]
    4688:      	blr	x9
    468c:      	tbnz	x0, #0x3f, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4690:      	mov	w8, #0x1                // =1
    4694:      	mov	x0, x19
    4698:      	mov	x1, x29
    469c:      	b	0x46ec <generic_rawtp_process_filter+0x124c>
    46a0:      	ldr	w8, [x24, #0x8]
    46a4:      	cmn	w8, #0x1
    46a8:      	b.eq	0x46c8 <generic_rawtp_process_filter+0x1228>
    46ac:      	ldr	x9, [x25, #0x308]
    46b0:      	lsr	x8, x9, x8
    46b4:      	tbz	w8, #0x0, 0x46c8 <generic_rawtp_process_filter+0x1228>
    46b8:      	mov	x0, #0xffee             // =65518
    46bc:      	movk	x0, #0xadc0, lsl #16
    46c0:      	movk	x0, #0xb, lsl #32
    46c4:      	b	0x46f0 <generic_rawtp_process_filter+0x1250>
    46c8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    46cc:      	mov	w8, #0x1                // =1
    46d0:      	add	x9, sp, #0x58
    46d4:      	ldr	x0, [x0]
    46d8:      	add	x1, sp, #0x58
    46dc:      	blr	x8
    46e0:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    46e4:      	add	x1, x25, #0x8
    46e8:      	mov	w8, #0x1                // =1
    46ec:      	blr	x8
    46f0:      	ldr	w8, [x24]
    46f4:      	cmp	w8, #0x25
    46f8:      	b.hi	0x4720 <generic_rawtp_process_filter+0x1280>
    46fc:      	mov	w9, #0x1                // =1
    4700:      	lsl	x8, x9, x8
    4704:      	mov	x9, #0x50               // =80
    4708:      	movk	x9, #0xc00, lsl #16
    470c:      	movk	x9, #0x20, lsl #32
    4710:      	tst	x8, x9
    4714:      	b.eq	0x4720 <generic_rawtp_process_filter+0x1280>
    4718:      	cbnz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    471c:      	b	0x4724 <generic_rawtp_process_filter+0x1284>
    4720:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4724:      	lsl	w8, w21, #2
    4728:      	add	x9, x8, #0x4
    472c:      	ldr	w8, [x9, x23]
    4730:      	add	w9, w8, w9
    4734:      	and	w11, w9, #0x3ff
    4738:      	add	w9, w9, #0x4
    473c:      	and	x9, x9, #0x3ff
    4740:      	add	x10, x11, #0x8
    4744:      	ldr	w9, [x9, x23]
    4748:      	cmp	w9, #0x5
    474c:      	b.lo	0x47dc <generic_rawtp_process_filter+0x133c>
    4750:      	add	x9, x10, x23
    4754:      	ldr	w10, [x9, #0x8]
    4758:      	ldp	w12, w22, [x9]
    475c:      	stp	x9, x11, [sp, #0x8]
    4760:      	mov	w9, #0x4                // =4
    4764:      	cmp	w10, #0x4
    4768:      	stp	xzr, xzr, [sp, #0x58]
    476c:      	csel	w9, w10, w9, lo
    4770:      	cmp	w12, #0x6
    4774:      	b.ne	0x4780 <generic_rawtp_process_filter+0x12e0>
    4778:      	mov	x11, #0x100000001       // =4294967297
    477c:      	stp	x11, x11, [sp, #0x58]
    4780:      	cbz	w10, 0x4be4 <generic_rawtp_process_filter+0x1744>
    4784:      	ldr	x10, [sp, #0x48]
    4788:      	add	w8, w8, w21, lsl #2
    478c:      	tst	x22, #0x1
    4790:      	add	x25, sp, #0x58
    4794:      	str	w12, [sp, #0x30]
    4798:      	add	w8, w8, #0x4
    479c:      	and	x8, x8, #0x3ff
    47a0:      	add	x21, x8, #0x14
    47a4:      	sub	x8, x9, #0x1
    47a8:      	mov	w9, #0x3                // =3
    47ac:      	add	x11, x10, #0x24
    47b0:      	str	x11, [sp, #0x20]
    47b4:      	csel	x11, x10, x11, eq
    47b8:      	cmp	x8, #0x3
    47bc:      	add	x10, x10, #0x10
    47c0:      	csel	x8, x8, x9, lo
    47c4:      	and	x9, x21, #0x7fc
    47c8:      	mov	x20, x11
    47cc:      	str	x10, [sp, #0x18]
    47d0:      	add	x24, x23, x9
    47d4:      	add	x19, x8, #0x1
    47d8:      	b	0x4814 <generic_rawtp_process_filter+0x1374>
    47dc:      	mov	w9, #0x1                // =1
    47e0:      	mov	w8, w10
    47e4:      	b	0x4c2c <generic_rawtp_process_filter+0x178c>
    47e8:      	mov	w8, #0x1                // =1
    47ec:      	ldr	w12, [sp, #0x30]
    47f0:      	mov	x11, x20
    47f4:      	cmp	w12, #0x6
    47f8:      	eor	w8, w8, #0x1
    47fc:      	csinc	w9, w8, wzr, eq
    4800:      	str	w9, [x25], #0x4
    4804:      	add	x21, x21, #0x4
    4808:      	add	x24, x24, #0x4
    480c:      	subs	x19, x19, #0x1
    4810:      	b.eq	0x4be4 <generic_rawtp_process_filter+0x1744>
    4814:      	cmp	x21, #0x3e8
    4818:      	b.ls	0x4a3c <generic_rawtp_process_filter+0x159c>
    481c:      	mov	x29, xzr
    4820:      	tbz	w22, #0x1, 0x4a44 <generic_rawtp_process_filter+0x15a4>
    4824:      	tbnz	w22, #0x0, 0x4a70 <generic_rawtp_process_filter+0x15d0>
    4828:      	ldr	x10, [sp, #0x48]
    482c:      	mov	w8, #0x1                // =1
    4830:      	ldr	w9, [x10]
    4834:      	cmp	x29, x9
    4838:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    483c:      	ldr	w9, [x10, #0x10]
    4840:      	cmp	x29, x9
    4844:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    4848:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    484c:      	mov	w8, #0x1                // =1
    4850:      	ldr	x0, [x0]
    4854:      	ldr	x1, [sp, #0x18]
    4858:      	blr	x8
    485c:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4860:      	ldr	w9, [x0]
    4864:      	mov	x1, x0
    4868:      	mov	w8, #0x1                // =1
    486c:      	cmp	x29, x9
    4870:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    4874:      	ldr	w9, [x1, #0x10]!
    4878:      	ldr	w12, [sp, #0x30]
    487c:      	mov	x11, x20
    4880:      	cmp	x29, x9
    4884:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    4888:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    488c:      	mov	w8, #0x1                // =1
    4890:      	ldr	x0, [x0]
    4894:      	blr	x8
    4898:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    489c:      	ldr	w9, [x0]
    48a0:      	mov	x1, x0
    48a4:      	mov	w8, #0x1                // =1
    48a8:      	cmp	x29, x9
    48ac:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    48b0:      	ldr	w9, [x1, #0x10]!
    48b4:      	ldr	w12, [sp, #0x30]
    48b8:      	mov	x11, x20
    48bc:      	cmp	x29, x9
    48c0:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    48c4:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    48c8:      	mov	w8, #0x1                // =1
    48cc:      	ldr	x0, [x0]
    48d0:      	blr	x8
    48d4:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    48d8:      	ldr	w9, [x0]
    48dc:      	mov	x1, x0
    48e0:      	mov	w8, #0x1                // =1
    48e4:      	cmp	x29, x9
    48e8:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    48ec:      	ldr	w9, [x1, #0x10]!
    48f0:      	ldr	w12, [sp, #0x30]
    48f4:      	mov	x11, x20
    48f8:      	cmp	x29, x9
    48fc:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    4900:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4904:      	mov	w8, #0x1                // =1
    4908:      	ldr	x0, [x0]
    490c:      	blr	x8
    4910:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4914:      	ldr	w9, [x0]
    4918:      	mov	x1, x0
    491c:      	mov	w8, #0x1                // =1
    4920:      	cmp	x29, x9
    4924:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    4928:      	ldr	w9, [x1, #0x10]!
    492c:      	ldr	w12, [sp, #0x30]
    4930:      	mov	x11, x20
    4934:      	cmp	x29, x9
    4938:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    493c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4940:      	mov	w8, #0x1                // =1
    4944:      	ldr	x0, [x0]
    4948:      	blr	x8
    494c:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4950:      	ldr	w9, [x0]
    4954:      	mov	x1, x0
    4958:      	mov	w8, #0x1                // =1
    495c:      	cmp	x29, x9
    4960:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    4964:      	ldr	w9, [x1, #0x10]!
    4968:      	ldr	w12, [sp, #0x30]
    496c:      	mov	x11, x20
    4970:      	cmp	x29, x9
    4974:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    4978:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    497c:      	mov	w8, #0x1                // =1
    4980:      	ldr	x0, [x0]
    4984:      	blr	x8
    4988:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    498c:      	ldr	w9, [x0]
    4990:      	mov	x1, x0
    4994:      	mov	w8, #0x1                // =1
    4998:      	cmp	x29, x9
    499c:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    49a0:      	ldr	w9, [x1, #0x10]!
    49a4:      	ldr	w12, [sp, #0x30]
    49a8:      	mov	x11, x20
    49ac:      	cmp	x29, x9
    49b0:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    49b4:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    49b8:      	mov	w8, #0x1                // =1
    49bc:      	ldr	x0, [x0]
    49c0:      	blr	x8
    49c4:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    49c8:      	ldr	w9, [x0]
    49cc:      	mov	x1, x0
    49d0:      	mov	w8, #0x1                // =1
    49d4:      	cmp	x29, x9
    49d8:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    49dc:      	ldr	w9, [x1, #0x10]!
    49e0:      	ldr	w12, [sp, #0x30]
    49e4:      	mov	x11, x20
    49e8:      	cmp	x29, x9
    49ec:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    49f0:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    49f4:      	mov	w8, #0x1                // =1
    49f8:      	ldr	x0, [x0]
    49fc:      	blr	x8
    4a00:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4a04:      	ldr	w9, [x0]
    4a08:      	mov	x1, x0
    4a0c:      	mov	w8, #0x1                // =1
    4a10:      	cmp	x29, x9
    4a14:      	b.eq	0x47ec <generic_rawtp_process_filter+0x134c>
    4a18:      	ldr	w9, [x1, #0x10]!
    4a1c:      	ldr	w12, [sp, #0x30]
    4a20:      	mov	x11, x20
    4a24:      	cmp	x29, x9
    4a28:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    4a2c:      	adrp	x9, 0x4000 <generic_rawtp_process_filter+0xb60>
    4a30:      	mov	w8, #0x1                // =1
    4a34:      	ldr	x9, [x9]
    4a38:      	b	0x4bbc <generic_rawtp_process_filter+0x171c>
    4a3c:      	ldr	w29, [x24]
    4a40:      	tbnz	w22, #0x1, 0x4824 <generic_rawtp_process_filter+0x1384>
    4a44:      	ldr	w8, [x11]
    4a48:      	cmp	w12, #0x5
    4a4c:      	b.ne	0x4a60 <generic_rawtp_process_filter+0x15c0>
    4a50:      	cmp	x29, x8
    4a54:      	b.eq	0x4a60 <generic_rawtp_process_filter+0x15c0>
    4a58:      	mov	w9, wzr
    4a5c:      	b	0x4800 <generic_rawtp_process_filter+0x1360>
    4a60:      	cmp	w12, #0x6
    4a64:      	ccmp	x29, x8, #0x0, eq
    4a68:      	cset	w9, ne
    4a6c:      	b	0x4800 <generic_rawtp_process_filter+0x1360>
    4a70:      	ldr	x8, [sp, #0x20]
    4a74:      	ldr	w9, [x8]
    4a78:      	cbz	w9, 0x4800 <generic_rawtp_process_filter+0x1360>
    4a7c:      	mov	w8, #0x1                // =1
    4a80:      	cbz	x29, 0x47f4 <generic_rawtp_process_filter+0x1354>
    4a84:      	cmp	x29, x9
    4a88:      	b.eq	0x47f4 <generic_rawtp_process_filter+0x1354>
    4a8c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4a90:      	mov	w8, #0x1                // =1
    4a94:      	ldr	x0, [x0]
    4a98:      	ldr	x1, [sp, #0x18]
    4a9c:      	blr	x8
    4aa0:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4aa4:      	ldr	w8, [x0, #0x24]
    4aa8:      	cmp	x29, x8
    4aac:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4ab0:      	add	x1, x0, #0x10
    4ab4:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4ab8:      	mov	w8, #0x1                // =1
    4abc:      	ldr	x0, [x0]
    4ac0:      	blr	x8
    4ac4:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4ac8:      	ldr	w8, [x0, #0x24]
    4acc:      	cmp	x29, x8
    4ad0:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4ad4:      	add	x1, x0, #0x10
    4ad8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4adc:      	mov	w8, #0x1                // =1
    4ae0:      	ldr	x0, [x0]
    4ae4:      	blr	x8
    4ae8:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4aec:      	ldr	w8, [x0, #0x24]
    4af0:      	cmp	x29, x8
    4af4:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4af8:      	add	x1, x0, #0x10
    4afc:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4b00:      	mov	w8, #0x1                // =1
    4b04:      	ldr	x0, [x0]
    4b08:      	blr	x8
    4b0c:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4b10:      	ldr	w8, [x0, #0x24]
    4b14:      	cmp	x29, x8
    4b18:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4b1c:      	add	x1, x0, #0x10
    4b20:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4b24:      	mov	w8, #0x1                // =1
    4b28:      	ldr	x0, [x0]
    4b2c:      	blr	x8
    4b30:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4b34:      	ldr	w8, [x0, #0x24]
    4b38:      	cmp	x29, x8
    4b3c:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4b40:      	add	x1, x0, #0x10
    4b44:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4b48:      	mov	w8, #0x1                // =1
    4b4c:      	ldr	x0, [x0]
    4b50:      	blr	x8
    4b54:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4b58:      	ldr	w8, [x0, #0x24]
    4b5c:      	cmp	x29, x8
    4b60:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4b64:      	add	x1, x0, #0x10
    4b68:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4b6c:      	mov	w8, #0x1                // =1
    4b70:      	ldr	x0, [x0]
    4b74:      	blr	x8
    4b78:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4b7c:      	ldr	w8, [x0, #0x24]
    4b80:      	cmp	x29, x8
    4b84:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4b88:      	add	x1, x0, #0x10
    4b8c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4b90:      	mov	w8, #0x1                // =1
    4b94:      	ldr	x0, [x0]
    4b98:      	blr	x8
    4b9c:      	cbz	x0, 0x4bc8 <generic_rawtp_process_filter+0x1728>
    4ba0:      	ldr	w8, [x0, #0x24]
    4ba4:      	cmp	x29, x8
    4ba8:      	b.eq	0x47e8 <generic_rawtp_process_filter+0x1348>
    4bac:      	adrp	x9, 0x4000 <generic_rawtp_process_filter+0xb60>
    4bb0:      	add	x1, x0, #0x10
    4bb4:      	mov	w8, #0x1                // =1
    4bb8:      	ldr	x9, [x9]
    4bbc:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4bc0:      	ldr	x0, [x0]
    4bc4:      	blr	x8
    4bc8:      	ldr	w12, [sp, #0x30]
    4bcc:      	mov	w8, wzr
    4bd0:      	mov	w9, wzr
    4bd4:      	mov	x11, x20
    4bd8:      	cmp	w12, #0x5
    4bdc:      	b.ne	0x47f4 <generic_rawtp_process_filter+0x1354>
    4be0:      	b	0x4800 <generic_rawtp_process_filter+0x1360>
    4be4:      	ldp	w8, w9, [sp, #0x58]
    4be8:      	ldp	w10, w11, [sp, #0x60]
    4bec:      	cmp	w12, #0x6
    4bf0:      	b.ne	0x4c04 <generic_rawtp_process_filter+0x1764>
    4bf4:      	and	w8, w9, w8
    4bf8:      	and	w9, w10, w11
    4bfc:      	and	w9, w8, w9
    4c00:      	b	0x4c10 <generic_rawtp_process_filter+0x1770>
    4c04:      	orr	w8, w9, w8
    4c08:      	orr	w9, w10, w11
    4c0c:      	orr	w9, w8, w9
    4c10:      	ldr	x8, [sp, #0x10]
    4c14:      	cbz	w9, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4c18:      	ldr	x10, [sp, #0x8]
    4c1c:      	add	w8, w8, #0x14
    4c20:      	ldr	w10, [x10, #0x8]
    4c24:      	ubfiz	w10, w10, #2, #3
    4c28:      	add	w8, w10, w8
    4c2c:      	and	x10, x8, #0x3ff
    4c30:      	add	w8, w8, #0x4
    4c34:      	mov	w19, #0xa               // =10
    4c38:      	ldr	w10, [x10, x23]
    4c3c:      	mov	w20, #0x4               // =4
    4c40:      	mov	x25, #0x100000001       // =4294967297
    4c44:      	sub	w22, w10, #0x4
    4c48:      	ldr	x10, [sp, #0xe8]
    4c4c:      	add	x10, x10, #0x20
    4c50:      	str	x10, [sp, #0x30]
    4c54:      	b	0x4c6c <generic_rawtp_process_filter+0x17cc>
    4c58:      	orr	w8, w9, w8
    4c5c:      	orr	w9, w10, w11
    4c60:      	orr	w9, w8, w9
    4c64:      	cbnz	w9, 0x4e20 <generic_rawtp_process_filter+0x1980>
    4c68:      	b	0x531c <generic_rawtp_process_filter+0x1e7c>
    4c6c:      	cbz	w22, 0x4e34 <generic_rawtp_process_filter+0x1994>
    4c70:      	and	x9, x8, #0x3ff
    4c74:      	add	x10, x9, x23
    4c78:      	ldr	w29, [x10, #0x8]
    4c7c:      	ldp	w9, w24, [x10]
    4c80:      	stp	xzr, xzr, [sp, #0x58]
    4c84:      	cmp	w29, #0x4
    4c88:      	csel	w10, w29, w20, lo
    4c8c:      	cmp	w24, #0x6
    4c90:      	b.ne	0x4c98 <generic_rawtp_process_filter+0x17f8>
    4c94:      	stp	x25, x25, [sp, #0x58]
    4c98:      	add	w21, w8, #0xc
    4c9c:      	cbz	w29, 0x4e00 <generic_rawtp_process_filter+0x1960>
    4ca0:      	and	x9, x9, #0xf
    4ca4:      	cmp	w9, #0xa
    4ca8:      	b.lo	0x4cd4 <generic_rawtp_process_filter+0x1834>
    4cac:      	sub	x8, x10, #0x1
    4cb0:      	mov	w9, #0x3                // =3
    4cb4:      	add	x0, sp, #0x58
    4cb8:      	mov	w1, wzr
    4cbc:      	cmp	x8, #0x3
    4cc0:      	csel	x8, x8, x9, lo
    4cc4:      	lsl	x8, x8, #2
    4cc8:      	add	x2, x8, #0x4
    4ccc:      	bl	0x4ccc <generic_rawtp_process_filter+0x182c>
    4cd0:      	b	0x4e00 <generic_rawtp_process_filter+0x1960>
    4cd4:      	cmp	w21, #0x3e8
    4cd8:      	b.ls	0x4ce4 <generic_rawtp_process_filter+0x1844>
    4cdc:      	mov	w11, wzr
    4ce0:      	b	0x4cec <generic_rawtp_process_filter+0x184c>
    4ce4:      	and	w11, w21, #0xfffffffc
    4ce8:      	ldr	w11, [x23, w11, uxtw]
    4cec:      	ldr	x12, [sp, #0x30]
    4cf0:      	cmp	w24, #0x5
    4cf4:      	sub	x10, x10, #0x1
    4cf8:      	ldr	w9, [x12, x9, lsl #2]
    4cfc:      	cset	w12, ne
    4d00:      	cmp	w24, #0x6
    4d04:      	cset	w13, ne
    4d08:      	cmp	w11, w9
    4d0c:      	csinc	w11, w12, wzr, ne
    4d10:      	csinc	w12, w13, wzr, eq
    4d14:      	and	w11, w11, w12
    4d18:      	str	w11, [sp, #0x58]
    4d1c:      	cbz	x10, 0x4e00 <generic_rawtp_process_filter+0x1960>
    4d20:      	add	w11, w8, #0x10
    4d24:      	cmp	w11, #0x3e8
    4d28:      	b.ls	0x4d34 <generic_rawtp_process_filter+0x1894>
    4d2c:      	mov	w11, wzr
    4d30:      	b	0x4d3c <generic_rawtp_process_filter+0x189c>
    4d34:      	and	w11, w11, #0xfffffffc
    4d38:      	ldr	w11, [x23, w11, uxtw]
    4d3c:      	cmp	w24, #0x5
    4d40:      	cset	w12, ne
    4d44:      	cmp	w24, #0x6
    4d48:      	cset	w13, ne
    4d4c:      	cmp	w11, w9
    4d50:      	csinc	w11, w12, wzr, ne
    4d54:      	csinc	w12, w13, wzr, eq
    4d58:      	cmp	x10, #0x1
    4d5c:      	and	w11, w11, w12
    4d60:      	str	w11, [sp, #0x5c]
    4d64:      	b.eq	0x4e00 <generic_rawtp_process_filter+0x1960>
    4d68:      	add	w11, w8, #0x14
    4d6c:      	cmp	w11, #0x3e8
    4d70:      	b.ls	0x4d7c <generic_rawtp_process_filter+0x18dc>
    4d74:      	mov	w11, wzr
    4d78:      	b	0x4d84 <generic_rawtp_process_filter+0x18e4>
    4d7c:      	and	w11, w11, #0xfffffffc
    4d80:      	ldr	w11, [x23, w11, uxtw]
    4d84:      	cmp	w24, #0x5
    4d88:      	cset	w12, ne
    4d8c:      	cmp	w24, #0x6
    4d90:      	cset	w13, ne
    4d94:      	cmp	w11, w9
    4d98:      	csinc	w11, w12, wzr, ne
    4d9c:      	csinc	w12, w13, wzr, eq
    4da0:      	cmp	x10, #0x2
    4da4:      	and	w11, w11, w12
    4da8:      	str	w11, [sp, #0x60]
    4dac:      	b.eq	0x4e00 <generic_rawtp_process_filter+0x1960>
    4db0:      	add	w8, w8, #0x18
    4db4:      	cmp	w8, #0x3e8
    4db8:      	b.ls	0x4dc4 <generic_rawtp_process_filter+0x1924>
    4dbc:      	mov	w8, wzr
    4dc0:      	b	0x4dcc <generic_rawtp_process_filter+0x192c>
    4dc4:      	and	w8, w8, #0xfffffffc
    4dc8:      	ldr	w8, [x23, w8, uxtw]
    4dcc:      	cmp	w24, #0x5
    4dd0:      	cset	w10, ne
    4dd4:      	cmp	w24, #0x6
    4dd8:      	cset	w11, ne
    4ddc:      	cmp	w8, w9
    4de0:      	csinc	w8, w10, wzr, ne
    4de4:      	csinc	w9, w11, wzr, eq
    4de8:      	and	w8, w8, w9
    4dec:      	str	w8, [sp, #0x64]
    4df0:      	nop
    4df4:      	nop
    4df8:      	nop
    4dfc:      	nop
    4e00:      	ldp	w8, w9, [sp, #0x58]
    4e04:      	ldp	w10, w11, [sp, #0x60]
    4e08:      	cmp	w24, #0x6
    4e0c:      	b.ne	0x4c58 <generic_rawtp_process_filter+0x17b8>
    4e10:      	and	w8, w9, w8
    4e14:      	and	w9, w10, w11
    4e18:      	and	w9, w8, w9
    4e1c:      	cbz	w9, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4e20:      	lsl	w8, w29, #2
    4e24:      	sub	w10, w22, w29, lsl #2
    4e28:      	and	w8, w8, #0x1c
    4e2c:      	sub	w22, w10, #0xc
    4e30:      	add	w8, w8, w21
    4e34:      	subs	x19, x19, #0x1
    4e38:      	b.ne	0x4c6c <generic_rawtp_process_filter+0x17cc>
    4e3c:      	mov	w10, w8
    4e40:      	add	w19, w8, #0x4
    4e44:      	and	x10, x10, #0x3ff
    4e48:      	ldr	w10, [x10, x23]
    4e4c:      	cmp	w10, #0x4
    4e50:      	b.ne	0x4ee8 <generic_rawtp_process_filter+0x1a48>
    4e54:      	cbz	w9, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4e58:      	mov	w8, w19
    4e5c:      	and	x8, x8, #0x3ff
    4e60:      	ldr	w9, [x8, x23]
    4e64:      	add	w8, w19, #0x4
    4e68:      	cmp	w9, #0x4
    4e6c:      	mov	w9, w8
    4e70:      	b.eq	0x5218 <generic_rawtp_process_filter+0x1d78>
    4e74:      	and	x8, x8, #0x3ff
    4e78:      	add	x8, x8, x23
    4e7c:      	ldp	w20, w22, [x8]
    4e80:      	mov	w8, #0xe                // =14
    4e84:      	blr	x8
    4e88:      	lsr	x8, x0, #32
    4e8c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0xb60>
    4e90:      	add	x9, sp, #0x58
    4e94:      	str	w8, [sp, #0x58]
    4e98:      	mov	w8, #0x1                // =1
    4e9c:      	add	x1, sp, #0x58
    4ea0:      	ldr	x0, [x0]
    4ea4:      	blr	x8
    4ea8:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    4eac:      	cmp	w20, #0x5
    4eb0:      	b.eq	0x4f64 <generic_rawtp_process_filter+0x1ac4>
    4eb4:      	cmp	w20, #0x6
    4eb8:      	b.ne	0x531c <generic_rawtp_process_filter+0x1e7c>
    4ebc:      	ldr	x11, [sp, #0xe8]
    4ec0:      	mov	w8, #0x5ee8             // =24296
    4ec4:      	add	x8, x11, x8
    4ec8:      	tbnz	w22, #0x0, 0x4f98 <generic_rawtp_process_filter+0x1af8>
    4ecc:      	ldr	w9, [x0, #0x28]
    4ed0:      	cbz	w9, 0x4f90 <generic_rawtp_process_filter+0x1af0>
    4ed4:      	ldr	x10, [sp, #0x30]
    4ed8:      	ldr	w10, [x10]
    4edc:      	cmp	w9, w10
    4ee0:      	b.eq	0x4f98 <generic_rawtp_process_filter+0x1af8>
    4ee4:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    4ee8:      	and	x9, x19, #0x3ff
    4eec:      	add	w19, w8, #0x18
    4ef0:      	add	x9, x9, x23
    4ef4:      	ldp	w8, w10, [x9]
    4ef8:      	ldr	w12, [x9, #0x8]
    4efc:      	ldur	x11, [x9, #0xc]
    4f00:      	cbz	w12, 0x4f24 <generic_rawtp_process_filter+0x1a84>
    4f04:      	ldr	x14, [sp, #0xe8]
    4f08:      	mov	w9, wzr
    4f0c:      	cmp	w8, #0x2
    4f10:      	b.hi	0x4e54 <generic_rawtp_process_filter+0x19b4>
    4f14:      	ldr	w13, [x14, #0x44]
    4f18:      	cmp	w13, w12
    4f1c:      	b.ne	0x4f38 <generic_rawtp_process_filter+0x1a98>
    4f20:      	b	0x4e54 <generic_rawtp_process_filter+0x19b4>
    4f24:      	ldr	x14, [sp, #0xe8]
    4f28:      	cmp	w8, #0x2
    4f2c:      	b.ls	0x4f38 <generic_rawtp_process_filter+0x1a98>
    4f30:      	mov	w9, wzr
    4f34:      	b	0x4e54 <generic_rawtp_process_filter+0x19b4>
    4f38:      	add	x9, x14, #0x48
    4f3c:      	cmp	w10, #0x5
    4f40:      	ldr	x8, [x9, x8, lsl #3]
    4f44:      	and	x8, x8, x11
    4f48:      	b.ne	0x4f58 <generic_rawtp_process_filter+0x1ab8>
    4f4c:      	cmp	x8, #0x0
    4f50:      	cset	w9, ne
    4f54:      	b	0x4e54 <generic_rawtp_process_filter+0x19b4>
    4f58:      	cmp	x8, #0x0
    4f5c:      	cset	w9, eq
    4f60:      	b	0x4e54 <generic_rawtp_process_filter+0x19b4>
    4f64:      	ldr	x11, [sp, #0xe8]
    4f68:      	mov	w8, #0x5ee8             // =24296
    4f6c:      	add	x8, x11, x8
    4f70:      	tbz	w22, #0x0, 0x4fbc <generic_rawtp_process_filter+0x1b1c>
    4f74:      	ldr	w9, [x0, #0x28]
    4f78:      	cbz	w9, 0x4fb4 <generic_rawtp_process_filter+0x1b14>
    4f7c:      	ldr	x10, [sp, #0x30]
    4f80:      	ldr	w10, [x10]
    4f84:      	cmp	w9, w10
    4f88:      	b.eq	0x4fbc <generic_rawtp_process_filter+0x1b1c>
    4f8c:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    4f90:      	mov	w9, #0x1                // =1
    4f94:      	str	x9, [x8]
    4f98:      	tbnz	w22, #0x1, 0x4fe0 <generic_rawtp_process_filter+0x1b40>
    4f9c:      	ldr	w9, [x0, #0x2c]
    4fa0:      	cbz	w9, 0x4fd8 <generic_rawtp_process_filter+0x1b38>
    4fa4:      	ldr	w10, [x11, #0x24]
    4fa8:      	cmp	w9, w10
    4fac:      	b.eq	0x4fe0 <generic_rawtp_process_filter+0x1b40>
    4fb0:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    4fb4:      	mov	w9, #0x1                // =1
    4fb8:      	str	x9, [x8]
    4fbc:      	tbz	w22, #0x1, 0x5004 <generic_rawtp_process_filter+0x1b64>
    4fc0:      	ldr	w9, [x0, #0x2c]
    4fc4:      	cbz	w9, 0x4ffc <generic_rawtp_process_filter+0x1b5c>
    4fc8:      	ldr	w10, [x11, #0x24]
    4fcc:      	cmp	w9, w10
    4fd0:      	b.eq	0x5004 <generic_rawtp_process_filter+0x1b64>
    4fd4:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    4fd8:      	mov	w9, #0x1                // =1
    4fdc:      	str	x9, [x8]
    4fe0:      	tbnz	w22, #0x2, 0x5028 <generic_rawtp_process_filter+0x1b88>
    4fe4:      	ldr	w9, [x0, #0x30]
    4fe8:      	cbz	w9, 0x5020 <generic_rawtp_process_filter+0x1b80>
    4fec:      	ldr	w10, [x11, #0x28]
    4ff0:      	cmp	w9, w10
    4ff4:      	b.eq	0x5028 <generic_rawtp_process_filter+0x1b88>
    4ff8:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    4ffc:      	mov	w9, #0x1                // =1
    5000:      	str	x9, [x8]
    5004:      	tbz	w22, #0x2, 0x504c <generic_rawtp_process_filter+0x1bac>
    5008:      	ldr	w9, [x0, #0x30]
    500c:      	cbz	w9, 0x5044 <generic_rawtp_process_filter+0x1ba4>
    5010:      	ldr	w10, [x11, #0x28]
    5014:      	cmp	w9, w10
    5018:      	b.eq	0x504c <generic_rawtp_process_filter+0x1bac>
    501c:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    5020:      	mov	w9, #0x1                // =1
    5024:      	str	x9, [x8]
    5028:      	tbnz	w22, #0x3, 0x5070 <generic_rawtp_process_filter+0x1bd0>
    502c:      	ldr	w9, [x0, #0x34]
    5030:      	cbz	w9, 0x5068 <generic_rawtp_process_filter+0x1bc8>
    5034:      	ldr	w10, [x11, #0x2c]
    5038:      	cmp	w9, w10
    503c:      	b.eq	0x5070 <generic_rawtp_process_filter+0x1bd0>
    5040:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    5044:      	mov	w9, #0x1                // =1
    5048:      	str	x9, [x8]
    504c:      	tbz	w22, #0x3, 0x5094 <generic_rawtp_process_filter+0x1bf4>
    5050:      	ldr	w9, [x0, #0x34]
    5054:      	cbz	w9, 0x508c <generic_rawtp_process_filter+0x1bec>
    5058:      	ldr	w10, [x11, #0x2c]
    505c:      	cmp	w9, w10
    5060:      	b.eq	0x5094 <generic_rawtp_process_filter+0x1bf4>
    5064:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    5068:      	mov	w9, #0x1                // =1
    506c:      	str	x9, [x8]
    5070:      	tbnz	w22, #0x4, 0x50b8 <generic_rawtp_process_filter+0x1c18>
    5074:      	ldr	w9, [x0, #0x38]
    5078:      	cbz	w9, 0x50b0 <generic_rawtp_process_filter+0x1c10>
    507c:      	ldr	w10, [x11, #0x30]
    5080:      	cmp	w9, w10
    5084:      	b.eq	0x50b8 <generic_rawtp_process_filter+0x1c18>
    5088:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    508c:      	mov	w9, #0x1                // =1
    5090:      	str	x9, [x8]
    5094:      	tbz	w22, #0x4, 0x50dc <generic_rawtp_process_filter+0x1c3c>
    5098:      	ldr	w9, [x0, #0x38]
    509c:      	cbz	w9, 0x50d4 <generic_rawtp_process_filter+0x1c34>
    50a0:      	ldr	w10, [x11, #0x30]
    50a4:      	cmp	w9, w10
    50a8:      	b.eq	0x50dc <generic_rawtp_process_filter+0x1c3c>
    50ac:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    50b0:      	mov	w9, #0x1                // =1
    50b4:      	str	x9, [x8]
    50b8:      	tbnz	w22, #0x5, 0x5100 <generic_rawtp_process_filter+0x1c60>
    50bc:      	ldr	w9, [x0, #0x3c]
    50c0:      	cbz	w9, 0x50f8 <generic_rawtp_process_filter+0x1c58>
    50c4:      	ldr	w10, [x11, #0x34]
    50c8:      	cmp	w9, w10
    50cc:      	b.eq	0x5100 <generic_rawtp_process_filter+0x1c60>
    50d0:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    50d4:      	mov	w9, #0x1                // =1
    50d8:      	str	x9, [x8]
    50dc:      	tbz	w22, #0x5, 0x5124 <generic_rawtp_process_filter+0x1c84>
    50e0:      	ldr	w9, [x0, #0x3c]
    50e4:      	cbz	w9, 0x511c <generic_rawtp_process_filter+0x1c7c>
    50e8:      	ldr	w10, [x11, #0x34]
    50ec:      	cmp	w9, w10
    50f0:      	b.eq	0x5124 <generic_rawtp_process_filter+0x1c84>
    50f4:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    50f8:      	mov	w9, #0x1                // =1
    50fc:      	str	x9, [x8]
    5100:      	tbnz	w22, #0x6, 0x5148 <generic_rawtp_process_filter+0x1ca8>
    5104:      	ldr	w9, [x0, #0x40]
    5108:      	cbz	w9, 0x5140 <generic_rawtp_process_filter+0x1ca0>
    510c:      	ldr	w10, [x11, #0x38]
    5110:      	cmp	w9, w10
    5114:      	b.eq	0x5148 <generic_rawtp_process_filter+0x1ca8>
    5118:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    511c:      	mov	w9, #0x1                // =1
    5120:      	str	x9, [x8]
    5124:      	tbz	w22, #0x6, 0x516c <generic_rawtp_process_filter+0x1ccc>
    5128:      	ldr	w9, [x0, #0x40]
    512c:      	cbz	w9, 0x5164 <generic_rawtp_process_filter+0x1cc4>
    5130:      	ldr	w10, [x11, #0x38]
    5134:      	cmp	w9, w10
    5138:      	b.eq	0x516c <generic_rawtp_process_filter+0x1ccc>
    513c:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    5140:      	mov	w9, #0x1                // =1
    5144:      	str	x9, [x8]
    5148:      	tbnz	w22, #0x7, 0x5190 <generic_rawtp_process_filter+0x1cf0>
    514c:      	ldr	w9, [x0, #0x44]
    5150:      	cbz	w9, 0x5188 <generic_rawtp_process_filter+0x1ce8>
    5154:      	ldr	w10, [x11, #0x3c]
    5158:      	cmp	w9, w10
    515c:      	b.eq	0x5190 <generic_rawtp_process_filter+0x1cf0>
    5160:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    5164:      	mov	w9, #0x1                // =1
    5168:      	str	x9, [x8]
    516c:      	tbz	w22, #0x7, 0x51b8 <generic_rawtp_process_filter+0x1d18>
    5170:      	ldr	w9, [x0, #0x44]
    5174:      	cbz	w9, 0x51b0 <generic_rawtp_process_filter+0x1d10>
    5178:      	ldr	w10, [x11, #0x3c]
    517c:      	cmp	w9, w10
    5180:      	b.eq	0x51b8 <generic_rawtp_process_filter+0x1d18>
    5184:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    5188:      	mov	w9, #0x1                // =1
    518c:      	str	x9, [x8]
    5190:      	tbnz	w22, #0x8, 0x51e0 <generic_rawtp_process_filter+0x1d40>
    5194:      	ldr	w9, [x0, #0x48]
    5198:      	cbz	w9, 0x51d8 <generic_rawtp_process_filter+0x1d38>
    519c:      	ldr	x10, [sp, #0xe8]
    51a0:      	ldr	w10, [x10, #0x40]
    51a4:      	cmp	w9, w10
    51a8:      	b.eq	0x51e0 <generic_rawtp_process_filter+0x1d40>
    51ac:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    51b0:      	mov	w9, #0x1                // =1
    51b4:      	str	x9, [x8]
    51b8:      	tbz	w22, #0x8, 0x51f0 <generic_rawtp_process_filter+0x1d50>
    51bc:      	ldr	w9, [x0, #0x48]
    51c0:      	cbz	w9, 0x51e8 <generic_rawtp_process_filter+0x1d48>
    51c4:      	ldr	x10, [sp, #0xe8]
    51c8:      	ldr	w10, [x10, #0x40]
    51cc:      	cmp	w9, w10
    51d0:      	b.eq	0x51f0 <generic_rawtp_process_filter+0x1d50>
    51d4:      	b	0x520c <generic_rawtp_process_filter+0x1d6c>
    51d8:      	mov	w9, #0x1                // =1
    51dc:      	str	x9, [x8]
    51e0:      	tbz	w22, #0x9, 0x51f4 <generic_rawtp_process_filter+0x1d54>
    51e4:      	b	0x531c <generic_rawtp_process_filter+0x1e7c>
    51e8:      	mov	w9, #0x1                // =1
    51ec:      	str	x9, [x8]
    51f0:      	tbz	w22, #0x9, 0x531c <generic_rawtp_process_filter+0x1e7c>
    51f4:      	ldr	w9, [x0, #0x4c]
    51f8:      	cbz	w9, 0x5314 <generic_rawtp_process_filter+0x1e74>
    51fc:      	ldr	x10, [sp, #0xe8]
    5200:      	ldr	w10, [x10, #0x44]
    5204:      	cmp	w9, w10
    5208:      	b.eq	0x531c <generic_rawtp_process_filter+0x1e7c>
    520c:      	add	w9, w19, #0xc
    5210:      	mov	w10, #0x1               // =1
    5214:      	str	x10, [x8]
    5218:      	and	x8, x9, #0x3ff
    521c:      	adrp	x24, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5220:      	ldr	w8, [x8, x23]
    5224:      	ldr	x24, [x24]
    5228:      	cmp	w8, #0x4
    522c:      	b.ne	0x5260 <generic_rawtp_process_filter+0x1dc0>
    5230:      	ldr	x9, [sp, #0xe8]
    5234:      	mov	w8, #0x5eb8             // =24248
    5238:      	add	x8, x9, x8
    523c:      	ldr	x9, [x9, #0x5eb8]
    5240:      	and	x9, x9, #0x1f
    5244:      	add	x8, x8, x9
    5248:      	mov	w9, #0x1                // =1
    524c:      	strb	w9, [x8, #0x9]
    5250:      	ldr	x8, [sp, #0x40]
    5254:      	strb	w9, [x8, #0x20]
    5258:      	strb	w9, [x8]
    525c:      	b	0x531c <generic_rawtp_process_filter+0x1e7c>
    5260:      	add	w8, w9, #0x4
    5264:      	and	x8, x8, #0x3ff
    5268:      	add	x8, x8, x23
    526c:      	ldp	w21, w19, [x8]
    5270:      	ldr	w22, [x8, #0x8]
    5274:      	ldur	x20, [x8, #0xc]
    5278:      	mov	w8, #0xe                // =14
    527c:      	blr	x8
    5280:      	lsr	x8, x0, #32
    5284:      	add	x9, sp, #0x58
    5288:      	add	x1, sp, #0x58
    528c:      	str	w8, [sp, #0x58]
    5290:      	mov	w8, #0x1                // =1
    5294:      	mov	x0, x24
    5298:      	blr	x8
    529c:      	cbz	x0, 0x531c <generic_rawtp_process_filter+0x1e7c>
    52a0:      	cmp	w21, #0x2
    52a4:      	cbz	w22, 0x52c0 <generic_rawtp_process_filter+0x1e20>
    52a8:      	b.hi	0x531c <generic_rawtp_process_filter+0x1e7c>
    52ac:      	ldr	x8, [sp, #0xe8]
    52b0:      	ldr	w8, [x8, #0x44]
    52b4:      	cmp	w8, w22
    52b8:      	b.ne	0x52c4 <generic_rawtp_process_filter+0x1e24>
    52bc:      	b	0x531c <generic_rawtp_process_filter+0x1e7c>
    52c0:      	b.hi	0x531c <generic_rawtp_process_filter+0x1e7c>
    52c4:      	ldr	x8, [sp, #0xe8]
    52c8:      	lsl	x10, x21, #3
    52cc:      	add	x9, x8, #0x48
    52d0:      	add	x8, x0, x21, lsl #3
    52d4:      	ldr	x8, [x8, #0x50]
    52d8:      	ldr	x9, [x9, x10]
    52dc:      	eor	x10, x9, x8
    52e0:      	tst	x10, x20
    52e4:      	b.eq	0x52f4 <generic_rawtp_process_filter+0x1e54>
    52e8:      	cmp	w19, #0x5
    52ec:      	b.eq	0x5304 <generic_rawtp_process_filter+0x1e64>
    52f0:      	b	0x531c <generic_rawtp_process_filter+0x1e7c>
    52f4:      	cmp	x8, x9
    52f8:      	b.eq	0x531c <generic_rawtp_process_filter+0x1e7c>
    52fc:      	cmp	w19, #0x6
    5300:      	b.ne	0x531c <generic_rawtp_process_filter+0x1e7c>
    5304:      	ldr	x9, [sp, #0xe8]
    5308:      	mov	w8, #0x1                // =1
    530c:      	str	x8, [x9, #0x5ef0]
    5310:      	b	0x5230 <generic_rawtp_process_filter+0x1d90>
    5314:      	mov	w9, #0x1                // =1
    5318:      	str	x9, [x8]
    531c:      	ldr	x9, [sp, #0xe8]
    5320:      	ldr	x10, [sp, #0x28]
    5324:      	ldr	x8, [x9, #0x5eb8]
    5328:      	add	x8, x8, #0x1
    532c:      	cmp	x8, x10
    5330:      	str	x8, [x9, #0x5eb8]
    5334:      	b.ls	0x5394 <generic_rawtp_process_filter+0x1ef4>
    5338:      	ldr	x10, [sp, #0x48]
    533c:      	ldr	w8, [x10]
    5340:      	str	w8, [x9, #0x10]
    5344:      	ldr	x8, [x10, #0x8]
    5348:      	str	x8, [x9, #0x18]
    534c:      	ldp	x22, x8, [sp, #0x38]
    5350:      	ldrb	w8, [x8]
    5354:      	cbz	w8, 0x5374 <generic_rawtp_process_filter+0x1ed4>
    5358:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1b60>
    535c:      	mov	x8, xzr
    5360:      	mov	w9, #0xc                // =12
    5364:      	ldr	x1, [x1]
    5368:      	mov	x0, x22
    536c:      	mov	w2, wzr
    5370:      	blr	x9
    5374:      	ldp	x20, x19, [sp, #0x120]
    5378:      	mov	w0, wzr
    537c:      	ldr	x29, [sp, #0xe0]
    5380:      	ldp	x22, x21, [sp, #0x110]
    5384:      	ldp	x24, x23, [sp, #0x100]
    5388:      	ldp	x30, x25, [sp, #0xf0]
    538c:      	add	sp, sp, #0x130
    5390:      	ret
    5394:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5398:      	mov	w8, #0x2                // =2
    539c:      	mov	w9, #0xc                // =12
    53a0:      	ldr	x1, [x1]
    53a4:      	ldr	x0, [sp, #0x38]
    53a8:      	mov	w2, #0x2                // =2
    53ac:      	b	0x5370 <generic_rawtp_process_filter+0x1ed0>

00000000000053b0 <generic_rawtp_filter_arg>:
    53b0:      	sub	sp, sp, #0xf0
    53b4:      	str	x29, [sp, #0xa0]
    53b8:      	stp	x30, x25, [sp, #0xb0]
    53bc:      	stp	x24, x23, [sp, #0xc0]
    53c0:      	stp	x22, x21, [sp, #0xd0]
    53c4:      	stp	x20, x19, [sp, #0xe0]
    53c8:      	mov	x19, x0
    53cc:      	str	wzr, [sp, #0xa8]
    53d0:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    53d4:      	mov	w8, #0x1                // =1
    53d8:      	ldr	x0, [x0]
    53dc:      	add	x9, sp, #0xa8
    53e0:      	add	x1, sp, #0xa8
    53e4:      	blr	x8
    53e8:      	cbz	x0, 0x5558 <generic_rawtp_filter_arg+0x1a8>
    53ec:      	mov	w8, #0x5ec1             // =24257
    53f0:      	mov	x20, x0
    53f4:      	add	x22, x0, x8
    53f8:      	mov	w8, #0x5ef8             // =24312
    53fc:      	add	x1, x0, x8
    5400:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5404:      	ldur	w23, [x22, #0x3f]
    5408:      	mov	w8, #0x1                // =1
    540c:      	ldr	x0, [x0]
    5410:      	blr	x8
    5414:      	cbz	x0, 0x553c <generic_rawtp_filter_arg+0x18c>
    5418:      	ldrb	w8, [x22, #0x1f]
    541c:      	cbz	w8, 0x553c <generic_rawtp_filter_arg+0x18c>
    5420:      	and	x8, x23, #0x7
    5424:      	mov	w10, #0x5ec1            // =24257
    5428:      	stp	x23, x22, [sp, #0x50]
    542c:      	add	x9, x20, x8
    5430:      	ldrb	w9, [x9, x10]
    5434:      	cbz	w9, 0x54ac <generic_rawtp_filter_arg+0xfc>
    5438:      	lsl	w8, w8, #2
    543c:      	mov	x21, x0
    5440:      	add	x8, x8, #0x4
    5444:      	ldr	w9, [x8, x0]
    5448:      	add	x8, x8, x9
    544c:      	add	x8, x8, #0x4
    5450:      	and	x9, x8, #0x3ff
    5454:      	ldr	w9, [x9, x0]
    5458:      	add	x8, x8, x9
    545c:      	and	x9, x8, #0x3ff
    5460:      	ldr	w9, [x9, x0]
    5464:      	add	x8, x8, x9
    5468:      	and	x9, x8, #0x3ff
    546c:      	ldr	w9, [x9, x0]
    5470:      	add	x8, x8, x9
    5474:      	and	x9, x8, #0x3ff
    5478:      	ldr	w9, [x9, x0]
    547c:      	add	x8, x8, x9
    5480:      	and	x9, x8, #0x3ff
    5484:      	ldr	w9, [x9, x0]
    5488:      	add	x16, x8, x9
    548c:      	and	x15, x16, #0x3ff
    5490:      	add	x17, x0, x15
    5494:      	ldr	w8, [x17]
    5498:      	cmp	w8, #0x19
    549c:      	b.hs	0x5500 <generic_rawtp_filter_arg+0x150>
    54a0:      	cmp	w15, #0x1
    54a4:      	b.eq	0x553c <generic_rawtp_filter_arg+0x18c>
    54a8:      	cbnz	w15, 0x5518 <generic_rawtp_filter_arg+0x168>
    54ac:      	ldr	x8, [sp, #0x50]
    54b0:      	cmp	w8, #0x1
    54b4:      	b.gt	0x54d4 <generic_rawtp_filter_arg+0x124>
    54b8:      	ldr	x9, [sp, #0x58]
    54bc:      	cmn	w8, #0x1
    54c0:      	b.eq	0x5578 <generic_rawtp_filter_arg+0x1c8>
    54c4:      	cbz	w8, 0x5588 <generic_rawtp_filter_arg+0x1d8>
    54c8:      	cmp	w8, #0x1
    54cc:      	b.eq	0x5598 <generic_rawtp_filter_arg+0x1e8>
    54d0:      	b	0x54f0 <generic_rawtp_filter_arg+0x140>
    54d4:      	ldr	x9, [sp, #0x58]
    54d8:      	cmp	w8, #0x2
    54dc:      	b.eq	0x55a8 <generic_rawtp_filter_arg+0x1f8>
    54e0:      	cmp	w8, #0x3
    54e4:      	b.eq	0x55b8 <generic_rawtp_filter_arg+0x208>
    54e8:      	cmp	w8, #0x4
    54ec:      	b.eq	0x55c8 <generic_rawtp_filter_arg+0x218>
    54f0:      	cmp	w8, #0x4
    54f4:      	b.gt	0x55f4 <generic_rawtp_filter_arg+0x244>
    54f8:      	add	w8, w8, #0x1
    54fc:      	b	0x55d4 <generic_rawtp_filter_arg+0x224>
    5500:      	mov	x25, xzr
    5504:      	mov	w2, #0x5ea0             // =24224
    5508:      	mov	w12, #0x1               // =1
    550c:      	stp	x19, x17, [sp, #0x30]
    5510:      	stp	x16, x15, [sp, #0x40]
    5514:      	b	0x5654 <generic_rawtp_filter_arg+0x2a4>
    5518:      	ldr	x8, [sp, #0x58]
    551c:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5520:      	mov	w9, #0xc                // =12
    5524:      	mov	x0, x19
    5528:      	stur	w15, [x8, #0x43]
    552c:      	mov	w8, #0x4                // =4
    5530:      	mov	w2, #0x4                // =4
    5534:      	ldr	x1, [x1]
    5538:      	blr	x9
    553c:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5540:      	mov	w8, #0x5                // =5
    5544:      	mov	w9, #0xc                // =12
    5548:      	ldr	x1, [x1]
    554c:      	mov	x0, x19
    5550:      	mov	w2, #0x5                // =5
    5554:      	blr	x9
    5558:      	ldp	x20, x19, [sp, #0xe0]
    555c:      	mov	w0, wzr
    5560:      	ldr	x29, [sp, #0xa0]
    5564:      	ldp	x22, x21, [sp, #0xd0]
    5568:      	ldp	x24, x23, [sp, #0xc0]
    556c:      	ldp	x30, x25, [sp, #0xb0]
    5570:      	add	sp, sp, #0xf0
    5574:      	ret
    5578:      	ldrb	w8, [x9]
    557c:      	cbz	w8, 0x5588 <generic_rawtp_filter_arg+0x1d8>
    5580:      	mov	w8, wzr
    5584:      	b	0x55d4 <generic_rawtp_filter_arg+0x224>
    5588:      	ldrb	w8, [x9, #0x1]
    558c:      	cbz	w8, 0x5598 <generic_rawtp_filter_arg+0x1e8>
    5590:      	mov	w8, #0x1                // =1
    5594:      	b	0x55d4 <generic_rawtp_filter_arg+0x224>
    5598:      	ldrb	w8, [x9, #0x2]
    559c:      	cbz	w8, 0x55a8 <generic_rawtp_filter_arg+0x1f8>
    55a0:      	mov	w8, #0x2                // =2
    55a4:      	b	0x55d4 <generic_rawtp_filter_arg+0x224>
    55a8:      	ldrb	w8, [x9, #0x3]
    55ac:      	cbz	w8, 0x55b8 <generic_rawtp_filter_arg+0x208>
    55b0:      	mov	w8, #0x3                // =3
    55b4:      	b	0x55d4 <generic_rawtp_filter_arg+0x224>
    55b8:      	ldrb	w8, [x9, #0x4]
    55bc:      	cbz	w8, 0x55c8 <generic_rawtp_filter_arg+0x218>
    55c0:      	mov	w8, #0x4                // =4
    55c4:      	b	0x55d4 <generic_rawtp_filter_arg+0x224>
    55c8:      	ldrb	w8, [x9, #0x5]
    55cc:      	cbz	w8, 0x55f4 <generic_rawtp_filter_arg+0x244>
    55d0:      	mov	w8, #0x5                // =5
    55d4:      	stur	w8, [x9, #0x3f]
    55d8:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1b60>
    55dc:      	mov	w8, #0x3                // =3
    55e0:      	mov	w9, #0xc                // =12
    55e4:      	ldr	x1, [x1]
    55e8:      	mov	x0, x19
    55ec:      	mov	w2, #0x3                // =3
    55f0:      	blr	x9
    55f4:      	ldr	x19, [x20, #0x60]
    55f8:      	mov	w8, #0xe                // =14
    55fc:      	blr	x8
    5600:      	stp	x19, x0, [sp, #0x60]
    5604:      	adrp	x19, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5608:      	mov	w8, #0x1                // =1
    560c:      	add	x9, sp, #0x60
    5610:      	add	x1, sp, #0x60
    5614:      	ldr	x19, [x19]
    5618:      	mov	x0, x19
    561c:      	blr	x8
    5620:      	cbz	x0, 0x5558 <generic_rawtp_filter_arg+0x1a8>
    5624:      	mov	w8, #0x3                // =3
    5628:      	add	x9, sp, #0x60
    562c:      	add	x1, sp, #0x60
    5630:      	mov	x0, x19
    5634:      	blr	x8
    5638:      	b	0x5558 <generic_rawtp_filter_arg+0x1a8>
    563c:      	cmp	w8, #0x3
    5640:      	cset	w23, eq
    5644:      	cbz	x23, 0x54ac <generic_rawtp_filter_arg+0xfc>
    5648:      	add	x25, x25, #0x1
    564c:      	cmp	x25, #0x5
    5650:      	b.eq	0x54a0 <generic_rawtp_filter_arg+0xf0>
    5654:      	add	x8, x17, x25, lsl #2
    5658:      	ldr	w8, [x8, #0x4]
    565c:      	tst	w8, #0x3ff
    5660:      	b.eq	0x54a0 <generic_rawtp_filter_arg+0xf0>
    5664:      	add	w8, w16, w8
    5668:      	and	x8, x8, #0x3ff
    566c:      	add	x29, x21, x8
    5670:      	ldr	w8, [x29, #0x4]
    5674:      	cmp	w8, #0x23
    5678:      	b.eq	0x54ac <generic_rawtp_filter_arg+0xfc>
    567c:      	ldr	w9, [x29]
    5680:      	cmp	w9, #0x4
    5684:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    5688:      	add	x10, x20, x9, lsl #2
    568c:      	ldr	w10, [x10, x2]
    5690:      	cbnz	w10, 0x54ac <generic_rawtp_filter_arg+0xfc>
    5694:      	add	x9, x20, x9, lsl #3
    5698:      	ldr	x9, [x9, #0x5e78]
    569c:      	and	x9, x9, #0x7ff
    56a0:      	add	x9, x20, x9
    56a4:      	add	x22, x9, #0x90
    56a8:      	ldr	w9, [x29, #0xc]
    56ac:      	cmp	w9, #0x10
    56b0:      	b.le	0x5700 <generic_rawtp_filter_arg+0x350>
    56b4:      	sub	w10, w9, #0x1c
    56b8:      	cmp	w10, #0x9
    56bc:      	b.lo	0x5870 <generic_rawtp_filter_arg+0x4c0>
    56c0:      	cmp	w9, #0x2a
    56c4:      	b.hi	0x56f0 <generic_rawtp_filter_arg+0x340>
    56c8:      	lsl	x10, x12, x9
    56cc:      	tst	x10, #0xc000000000
    56d0:      	b.ne	0x5728 <generic_rawtp_filter_arg+0x378>
    56d4:      	lsl	x10, x12, x9
    56d8:      	tst	x10, #0x30000000000
    56dc:      	b.ne	0x5b18 <generic_rawtp_filter_arg+0x768>
    56e0:      	lsl	x10, x12, x9
    56e4:      	mov	x11, #0x42000000000     // =4535485464576
    56e8:      	tst	x10, x11
    56ec:      	b.ne	0x5770 <generic_rawtp_filter_arg+0x3c0>
    56f0:      	cmp	w9, #0x11
    56f4:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    56f8:      	add	x22, x22, #0x4
    56fc:      	b	0x5770 <generic_rawtp_filter_arg+0x3c0>
    5700:      	cmp	w9, #0x6
    5704:      	b.gt	0x5758 <generic_rawtp_filter_arg+0x3a8>
    5708:      	cmp	w9, #0x3
    570c:      	b.le	0x582c <generic_rawtp_filter_arg+0x47c>
    5710:      	cmp	w9, #0x4
    5714:      	b.eq	0x5870 <generic_rawtp_filter_arg+0x4c0>
    5718:      	cmp	w9, #0x5
    571c:      	b.eq	0x5b18 <generic_rawtp_filter_arg+0x768>
    5720:      	cmp	w9, #0x6
    5724:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    5728:      	ldr	w24, [x22], #0x4
    572c:      	mov	x23, xzr
    5730:      	cmp	w8, #0x19
    5734:      	b.gt	0x59cc <generic_rawtp_filter_arg+0x61c>
    5738:      	sub	w9, w8, #0x3
    573c:      	cmp	w9, #0x2
    5740:      	b.lo	0x60cc <generic_rawtp_filter_arg+0xd1c>
    5744:      	cmp	w8, #0x8
    5748:      	b.eq	0x6034 <generic_rawtp_filter_arg+0xc84>
    574c:      	cmp	w8, #0x9
    5750:      	b.eq	0x59e4 <generic_rawtp_filter_arg+0x634>
    5754:      	b	0x65e8 <generic_rawtp_filter_arg+0x1238>
    5758:      	sub	w10, w9, #0xa
    575c:      	cmp	w10, #0x4
    5760:      	b.lo	0x5870 <generic_rawtp_filter_arg+0x4c0>
    5764:      	sub	w10, w9, #0xf
    5768:      	cmp	w10, #0x2
    576c:      	b.hs	0x5b10 <generic_rawtp_filter_arg+0x760>
    5770:      	ldr	w24, [x22]
    5774:      	and	w9, w8, #0xfffffffe
    5778:      	cmp	w9, #0x24
    577c:      	b.eq	0x5784 <generic_rawtp_filter_arg+0x3d4>
    5780:      	cbz	w24, 0x54ac <generic_rawtp_filter_arg+0xfc>
    5784:      	cmp	w8, #0x25
    5788:      	b.hi	0x5ab0 <generic_rawtp_filter_arg+0x700>
    578c:      	mov	w10, #0x100             // =256
    5790:      	lsl	x9, x12, x8
    5794:      	movk	w10, #0x400, lsl #16
    5798:      	tst	x9, x10
    579c:      	b.ne	0x5d70 <generic_rawtp_filter_arg+0x9c0>
    57a0:      	mov	w10, #0x200             // =512
    57a4:      	lsl	x9, x12, x8
    57a8:      	movk	w10, #0x800, lsl #16
    57ac:      	tst	x9, x10
    57b0:      	b.ne	0x5c90 <generic_rawtp_filter_arg+0x8e0>
    57b4:      	lsl	x9, x12, x8
    57b8:      	tst	x9, #0x3000000000
    57bc:      	b.eq	0x5ab0 <generic_rawtp_filter_arg+0x700>
    57c0:      	cmp	w24, #0x1fe
    57c4:      	strh	wzr, [sp, #0x60]
    57c8:      	b.hi	0x5ac8 <generic_rawtp_filter_arg+0x718>
    57cc:      	add	x8, x22, #0x4
    57d0:      	mov	w10, #0x4               // =4
    57d4:      	add	x11, sp, #0x60
    57d8:      	mov	w12, #0x2               // =2
    57dc:      	add	x0, sp, #0x60
    57e0:      	mov	w1, #0x2                // =2
    57e4:      	add	x9, x8, x24
    57e8:      	add	x9, x9, #0x4
    57ec:      	ldr	w9, [x22]
    57f0:      	add	x8, x8, x9
    57f4:      	add	x2, x8, #0x4
    57f8:      	blr	x10
    57fc:      	ldr	w9, [x29, #0x10]
    5800:      	cbz	w9, 0x7c68 <generic_rawtp_filter_arg+0x28b8>
    5804:      	ldrh	w8, [sp, #0x60]
    5808:      	ldp	x16, x15, [sp, #0x40]
    580c:      	mov	w2, #0x5ea0             // =24224
    5810:      	mov	w12, #0x1               // =1
    5814:      	and	w8, w8, #0xf000
    5818:      	ldr	x17, [sp, #0x38]
    581c:      	cmp	w9, w8
    5820:      	b.ne	0x6da4 <generic_rawtp_filter_arg+0x19f4>
    5824:      	mov	w23, #0x1               // =1
    5828:      	b	0x7c7c <generic_rawtp_filter_arg+0x28cc>
    582c:      	cmp	w9, #0x1
    5830:      	b.eq	0x5870 <generic_rawtp_filter_arg+0x4c0>
    5834:      	cmp	w9, #0x2
    5838:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    583c:      	add	x24, x22, #0x8
    5840:      	ldr	w22, [x22, #0x4]
    5844:      	mov	x23, xzr
    5848:      	cmp	w8, #0x19
    584c:      	b.gt	0x6130 <generic_rawtp_filter_arg+0xd80>
    5850:      	sub	w9, w8, #0x3
    5854:      	cmp	w9, #0x2
    5858:      	b.lo	0x689c <generic_rawtp_filter_arg+0x14ec>
    585c:      	cmp	w8, #0x8
    5860:      	b.eq	0x6810 <generic_rawtp_filter_arg+0x1460>
    5864:      	cmp	w8, #0x9
    5868:      	b.eq	0x6148 <generic_rawtp_filter_arg+0xd98>
    586c:      	b	0x80ac <generic_rawtp_filter_arg+0x2cfc>
    5870:      	cmp	w9, #0xb
    5874:      	b.le	0x58e4 <generic_rawtp_filter_arg+0x534>
    5878:      	cmp	w9, #0x24
    587c:      	b.hi	0x592c <generic_rawtp_filter_arg+0x57c>
    5880:      	lsl	x10, x12, x9
    5884:      	tst	x10, #0x1e00000000
    5888:      	b.ne	0x5904 <generic_rawtp_filter_arg+0x554>
    588c:      	lsl	x10, x12, x9
    5890:      	tst	x10, #0x60000000
    5894:      	b.ne	0x5ad0 <generic_rawtp_filter_arg+0x720>
    5898:      	lsl	x10, x12, x9
    589c:      	tst	x10, #0x180000000
    58a0:      	b.eq	0x592c <generic_rawtp_filter_arg+0x57c>
    58a4:      	cmp	w8, #0x20
    58a8:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    58ac:      	lsl	x9, x12, x8
    58b0:      	mov	w10, #0x101e            // =4126
    58b4:      	tst	x9, x10
    58b8:      	b.eq	0x622c <generic_rawtp_filter_arg+0xe7c>
    58bc:      	ldr	w9, [x29, #0x10]
    58c0:      	cmp	w8, #0x2
    58c4:      	b.le	0x6738 <generic_rawtp_filter_arg+0x1388>
    58c8:      	sub	w10, w8, #0x3
    58cc:      	cmp	w10, #0x2
    58d0:      	b.hs	0x6c60 <generic_rawtp_filter_arg+0x18b0>
    58d4:      	ldrb	w10, [x22]
    58d8:      	cmp	w9, w10
    58dc:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    58e0:      	b	0x6fc4 <generic_rawtp_filter_arg+0x1c14>
    58e4:      	sub	w10, w9, #0xa
    58e8:      	cmp	w10, #0x2
    58ec:      	b.lo	0x5ba8 <generic_rawtp_filter_arg+0x7f8>
    58f0:      	cmp	w9, #0x1
    58f4:      	b.eq	0x5938 <generic_rawtp_filter_arg+0x588>
    58f8:      	cmp	w9, #0x4
    58fc:      	b.eq	0x5938 <generic_rawtp_filter_arg+0x588>
    5900:      	b	0x5648 <generic_rawtp_filter_arg+0x298>
    5904:      	cmp	w8, #0x9
    5908:      	b.le	0x5b58 <generic_rawtp_filter_arg+0x7a8>
    590c:      	cmp	w8, #0x1d
    5910:      	b.gt	0x5f00 <generic_rawtp_filter_arg+0xb50>
    5914:      	sub	w10, w8, #0xa
    5918:      	cmp	w10, #0x2
    591c:      	b.lo	0x5c34 <generic_rawtp_filter_arg+0x884>
    5920:      	cmp	w8, #0xc
    5924:      	b.eq	0x5bc0 <generic_rawtp_filter_arg+0x810>
    5928:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    592c:      	sub	w10, w9, #0xc
    5930:      	cmp	w10, #0x2
    5934:      	b.hs	0x5ba0 <generic_rawtp_filter_arg+0x7f0>
    5938:      	cmp	w8, #0x20
    593c:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    5940:      	lsl	x10, x12, x8
    5944:      	mov	w11, #0x101e            // =4126
    5948:      	tst	x10, x11
    594c:      	b.eq	0x5978 <generic_rawtp_filter_arg+0x5c8>
    5950:      	ldr	w10, [x29, #0x10]
    5954:      	cmp	w8, #0x2
    5958:      	b.le	0x5b68 <generic_rawtp_filter_arg+0x7b8>
    595c:      	sub	w11, w8, #0x3
    5960:      	cmp	w11, #0x2
    5964:      	b.hs	0x6214 <generic_rawtp_filter_arg+0xe64>
    5968:      	ldr	w11, [x22]
    596c:      	cmp	w11, w10
    5970:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    5974:      	b	0x7240 <generic_rawtp_filter_arg+0x1e90>
    5978:      	lsl	x10, x12, x8
    597c:      	tst	x10, #0xc00
    5980:      	b.ne	0x5e08 <generic_rawtp_filter_arg+0xa58>
    5984:      	lsl	x10, x12, x8
    5988:      	tst	x10, #0x180000000
    598c:      	b.eq	0x54ac <generic_rawtp_filter_arg+0xfc>
    5990:      	cmp	w8, #0x1f
    5994:      	b.ne	0x6398 <generic_rawtp_filter_arg+0xfe8>
    5998:      	ldp	w11, w10, [x29, #0x10]
    599c:      	cmp	w9, #0xc
    59a0:      	b.hi	0x7040 <generic_rawtp_filter_arg+0x1c90>
    59a4:      	lsl	w8, w12, w9
    59a8:      	mov	w13, #0x1402            // =5122
    59ac:      	tst	w8, w13
    59b0:      	b.eq	0x7040 <generic_rawtp_filter_arg+0x1c90>
    59b4:      	ldr	w8, [x22]
    59b8:      	cmp	w11, w8
    59bc:      	b.gt	0x7054 <generic_rawtp_filter_arg+0x1ca4>
    59c0:      	cmp	w8, w10
    59c4:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    59c8:      	b	0x7054 <generic_rawtp_filter_arg+0x1ca4>
    59cc:      	cmp	w8, #0x20
    59d0:      	b.gt	0x5f40 <generic_rawtp_filter_arg+0xb90>
    59d4:      	cmp	w8, #0x1a
    59d8:      	b.eq	0x6034 <generic_rawtp_filter_arg+0xc84>
    59dc:      	cmp	w8, #0x1b
    59e0:      	b.ne	0x65e8 <generic_rawtp_filter_arg+0x1238>
    59e4:      	ldr	w8, [x29, #0x10]
    59e8:      	str	wzr, [sp, #0x88]
    59ec:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    59f0:      	add	x9, sp, #0x60
    59f4:      	add	x1, sp, #0x60
    59f8:      	str	w8, [sp, #0x60]
    59fc:      	mov	w8, #0x1                // =1
    5a00:      	ldr	x0, [x0]
    5a04:      	blr	x8
    5a08:      	mov	x23, xzr
    5a0c:      	cbz	w24, 0x65d8 <generic_rawtp_filter_arg+0x1228>
    5a10:      	cbz	x0, 0x65d8 <generic_rawtp_filter_arg+0x1228>
    5a14:      	mov	x19, x0
    5a18:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5a1c:      	mov	w8, #0x1                // =1
    5a20:      	ldr	x0, [x0]
    5a24:      	add	x9, sp, #0x88
    5a28:      	add	x1, sp, #0x88
    5a2c:      	blr	x8
    5a30:      	cbz	x0, 0x65d0 <generic_rawtp_filter_arg+0x1220>
    5a34:      	cmp	w24, #0x7f
    5a38:      	mov	w9, #0x7f               // =127
    5a3c:      	mov	w11, #0x1               // =1
    5a40:      	mov	x1, x0
    5a44:      	mov	x8, xzr
    5a48:      	sub	w12, w24, #0x2
    5a4c:      	sub	w13, w24, #0x1
    5a50:      	csel	w9, w24, w9, lo
    5a54:      	sub	x11, x11, x24
    5a58:      	lsl	w10, w9, #3
    5a5c:      	mov	x9, x0
    5a60:      	str	w10, [x9], #0x5
    5a64:      	neg	x10, x24
    5a68:      	add	w14, w13, w8
    5a6c:      	cmp	x11, x8
    5a70:      	and	x14, x14, #0xfff
    5a74:      	ldrb	w14, [x22, x14]
    5a78:      	sturb	w14, [x9, #-0x1]
    5a7c:      	b.eq	0x5aa4 <generic_rawtp_filter_arg+0x6f4>
    5a80:      	cmn	x8, #0x7e
    5a84:      	b.eq	0x5aa4 <generic_rawtp_filter_arg+0x6f4>
    5a88:      	add	w14, w12, w8
    5a8c:      	sub	x8, x8, #0x2
    5a90:      	and	x14, x14, #0xfff
    5a94:      	cmp	x10, x8
    5a98:      	ldrb	w14, [x22, x14]
    5a9c:      	strb	w14, [x9], #0x2
    5aa0:      	b.ne	0x5a68 <generic_rawtp_filter_arg+0x6b8>
    5aa4:      	mov	w8, #0x1                // =1
    5aa8:      	mov	x0, x19
    5aac:      	b	0x60bc <generic_rawtp_filter_arg+0xd0c>
    5ab0:      	sub	w8, w8, #0x3
    5ab4:      	cmp	w8, #0x2
    5ab8:      	b.hs	0x5ac8 <generic_rawtp_filter_arg+0x718>
    5abc:      	cmp	w24, #0x1fe
    5ac0:      	str	wzr, [sp, #0x88]
    5ac4:      	b.ls	0x6334 <generic_rawtp_filter_arg+0xf84>
    5ac8:      	mov	x23, xzr
    5acc:      	b	0x7c7c <generic_rawtp_filter_arg+0x28cc>
    5ad0:      	cmp	w8, #0x20
    5ad4:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    5ad8:      	lsl	x9, x12, x8
    5adc:      	mov	w10, #0x101e            // =4126
    5ae0:      	tst	x9, x10
    5ae4:      	b.eq	0x6258 <generic_rawtp_filter_arg+0xea8>
    5ae8:      	ldr	w9, [x29, #0x10]
    5aec:      	cmp	w8, #0x2
    5af0:      	b.le	0x6758 <generic_rawtp_filter_arg+0x13a8>
    5af4:      	sub	w10, w8, #0x3
    5af8:      	cmp	w10, #0x2
    5afc:      	b.hs	0x6c78 <generic_rawtp_filter_arg+0x18c8>
    5b00:      	ldrh	w10, [x22]
    5b04:      	cmp	w9, w10
    5b08:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    5b0c:      	b	0x7004 <generic_rawtp_filter_arg+0x1c54>
    5b10:      	cmp	w9, #0x7
    5b14:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    5b18:      	mov	x23, xzr
    5b1c:      	cmp	w9, #0x27
    5b20:      	stp	xzr, xzr, [sp, #0x78]
    5b24:      	str	xzr, [sp, #0x60]
    5b28:      	stp	xzr, xzr, [sp, #0x68]
    5b2c:      	b.gt	0x5b40 <generic_rawtp_filter_arg+0x790>
    5b30:      	cmp	w9, #0x5
    5b34:      	b.eq	0x5e5c <generic_rawtp_filter_arg+0xaac>
    5b38:      	cmp	w9, #0x7
    5b3c:      	b	0x5b4c <generic_rawtp_filter_arg+0x79c>
    5b40:      	cmp	w9, #0x28
    5b44:      	b.eq	0x5e64 <generic_rawtp_filter_arg+0xab4>
    5b48:      	cmp	w9, #0x29
    5b4c:      	mov	x10, x22
    5b50:      	b.eq	0x5e8c <generic_rawtp_filter_arg+0xadc>
    5b54:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    5b58:      	sub	w10, w8, #0x1
    5b5c:      	cmp	w10, #0x4
    5b60:      	b.lo	0x5bc0 <generic_rawtp_filter_arg+0x810>
    5b64:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    5b68:      	cmp	w8, #0x1
    5b6c:      	b.eq	0x64ec <generic_rawtp_filter_arg+0x113c>
    5b70:      	cmp	w8, #0x2
    5b74:      	b.ne	0x7240 <generic_rawtp_filter_arg+0x1e90>
    5b78:      	cmp	w9, #0xc
    5b7c:      	b.hi	0x7234 <generic_rawtp_filter_arg+0x1e84>
    5b80:      	lsl	w11, w12, w9
    5b84:      	mov	w13, #0x1402            // =5122
    5b88:      	tst	w11, w13
    5b8c:      	b.eq	0x7234 <generic_rawtp_filter_arg+0x1e84>
    5b90:      	ldr	w11, [x22]
    5b94:      	cmp	w11, w10
    5b98:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    5b9c:      	b	0x7240 <generic_rawtp_filter_arg+0x1e90>
    5ba0:      	cmp	w9, #0x1c
    5ba4:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    5ba8:      	cmp	w8, #0x20
    5bac:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    5bb0:      	lsl	x10, x12, x8
    5bb4:      	mov	w11, #0x101e            // =4126
    5bb8:      	tst	x10, x11
    5bbc:      	b.eq	0x5be8 <generic_rawtp_filter_arg+0x838>
    5bc0:      	ldr	x10, [x29, #0x10]
    5bc4:      	cmp	w8, #0x2
    5bc8:      	b.le	0x5c04 <generic_rawtp_filter_arg+0x854>
    5bcc:      	sub	w11, w8, #0x3
    5bd0:      	cmp	w11, #0x2
    5bd4:      	b.hs	0x5e44 <generic_rawtp_filter_arg+0xa94>
    5bd8:      	ldr	x11, [x22]
    5bdc:      	cmp	x11, x10
    5be0:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    5be4:      	b	0x6bbc <generic_rawtp_filter_arg+0x180c>
    5be8:      	lsl	x10, x12, x8
    5bec:      	tst	x10, #0xc00
    5bf0:      	b.ne	0x5c34 <generic_rawtp_filter_arg+0x884>
    5bf4:      	lsl	x10, x12, x8
    5bf8:      	tst	x10, #0x180000000
    5bfc:      	b.ne	0x5f0c <generic_rawtp_filter_arg+0xb5c>
    5c00:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    5c04:      	cmp	w8, #0x1
    5c08:      	b.eq	0x62fc <generic_rawtp_filter_arg+0xf4c>
    5c0c:      	cmp	w8, #0x2
    5c10:      	b.ne	0x6bbc <generic_rawtp_filter_arg+0x180c>
    5c14:      	cmp	w9, #0xc
    5c18:      	b.eq	0x5c24 <generic_rawtp_filter_arg+0x874>
    5c1c:      	cmp	w9, #0xa
    5c20:      	b.ne	0x6bb0 <generic_rawtp_filter_arg+0x1800>
    5c24:      	ldr	x11, [x22]
    5c28:      	cmp	x11, x10
    5c2c:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    5c30:      	b	0x6bbc <generic_rawtp_filter_arg+0x180c>
    5c34:      	ldrb	w8, [x29, #0x10]
    5c38:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5c3c:      	add	x9, sp, #0x88
    5c40:      	add	x1, sp, #0x88
    5c44:      	str	w8, [sp, #0x88]
    5c48:      	mov	w8, #0x1                // =1
    5c4c:      	ldr	x0, [x0]
    5c50:      	blr	x8
    5c54:      	cbz	x0, 0x631c <generic_rawtp_filter_arg+0xf6c>
    5c58:      	ldr	x8, [x22]
    5c5c:      	add	x9, sp, #0x60
    5c60:      	add	x1, sp, #0x60
    5c64:      	str	x8, [sp, #0x60]
    5c68:      	mov	w8, #0x1                // =1
    5c6c:      	blr	x8
    5c70:      	ldr	w8, [x29, #0x4]
    5c74:      	cmp	w8, #0xb
    5c78:      	b.eq	0x67f0 <generic_rawtp_filter_arg+0x1440>
    5c7c:      	cmp	w8, #0xa
    5c80:      	mov	w12, #0x1               // =1
    5c84:      	b.eq	0x6a6c <generic_rawtp_filter_arg+0x16bc>
    5c88:      	mov	w8, wzr
    5c8c:      	b	0x6a74 <generic_rawtp_filter_arg+0x16c4>
    5c90:      	ldr	w8, [x29, #0x10]
    5c94:      	str	wzr, [sp, #0x88]
    5c98:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5c9c:      	add	x9, sp, #0x60
    5ca0:      	add	x1, sp, #0x60
    5ca4:      	str	w8, [sp, #0x60]
    5ca8:      	mov	w8, #0x1                // =1
    5cac:      	ldr	x0, [x0]
    5cb0:      	blr	x8
    5cb4:      	mov	x23, xzr
    5cb8:      	cbz	w24, 0x6c50 <generic_rawtp_filter_arg+0x18a0>
    5cbc:      	mov	w12, #0x1               // =1
    5cc0:      	cbz	x0, 0x6c54 <generic_rawtp_filter_arg+0x18a4>
    5cc4:      	mov	x19, x0
    5cc8:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5ccc:      	mov	w8, #0x1                // =1
    5cd0:      	ldr	x0, [x0]
    5cd4:      	add	x9, sp, #0x88
    5cd8:      	add	x1, sp, #0x88
    5cdc:      	mov	w23, #0x1               // =1
    5ce0:      	blr	x8
    5ce4:      	cbz	x0, 0x6c48 <generic_rawtp_filter_arg+0x1898>
    5ce8:      	cmp	w24, #0x7f
    5cec:      	mov	w10, #0x7f              // =127
    5cf0:      	mov	x1, x0
    5cf4:      	mov	x8, xzr
    5cf8:      	add	x9, x22, #0x4
    5cfc:      	sub	x12, x23, x24
    5d00:      	sub	w13, w24, #0x2
    5d04:      	sub	w14, w24, #0x1
    5d08:      	csel	w10, w24, w10, lo
    5d0c:      	lsl	w11, w10, #3
    5d10:      	mov	x10, x0
    5d14:      	str	w11, [x10], #0x5
    5d18:      	neg	x11, x24
    5d1c:      	add	w15, w14, w8
    5d20:      	cmp	x12, x8
    5d24:      	and	x15, x15, #0xfff
    5d28:      	ldrb	w15, [x9, x15]
    5d2c:      	sturb	w15, [x10, #-0x1]
    5d30:      	b.eq	0x5d58 <generic_rawtp_filter_arg+0x9a8>
    5d34:      	cmn	x8, #0x7e
    5d38:      	b.eq	0x5d58 <generic_rawtp_filter_arg+0x9a8>
    5d3c:      	add	w15, w13, w8
    5d40:      	sub	x8, x8, #0x2
    5d44:      	and	x15, x15, #0xfff
    5d48:      	cmp	x11, x8
    5d4c:      	ldrb	w15, [x9, x15]
    5d50:      	strb	w15, [x10], #0x2
    5d54:      	b.ne	0x5d1c <generic_rawtp_filter_arg+0x96c>
    5d58:      	mov	w8, #0x1                // =1
    5d5c:      	mov	x0, x19
    5d60:      	blr	x8
    5d64:      	cmp	x0, #0x0
    5d68:      	cset	w23, ne
    5d6c:      	b	0x6c4c <generic_rawtp_filter_arg+0x189c>
    5d70:      	ldr	w8, [x29, #0x10]
    5d74:      	str	wzr, [sp, #0x88]
    5d78:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5d7c:      	add	x9, sp, #0x60
    5d80:      	add	x1, sp, #0x60
    5d84:      	str	w8, [sp, #0x60]
    5d88:      	mov	w8, #0x1                // =1
    5d8c:      	ldr	x0, [x0]
    5d90:      	blr	x8
    5d94:      	mov	x23, xzr
    5d98:      	cbz	w24, 0x7c6c <generic_rawtp_filter_arg+0x28bc>
    5d9c:      	cbz	x0, 0x7c6c <generic_rawtp_filter_arg+0x28bc>
    5da0:      	mov	x19, x0
    5da4:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5da8:      	mov	w8, #0x1                // =1
    5dac:      	ldr	x0, [x0]
    5db0:      	add	x9, sp, #0x88
    5db4:      	add	x1, sp, #0x88
    5db8:      	blr	x8
    5dbc:      	cbz	x0, 0x6df4 <generic_rawtp_filter_arg+0x1a44>
    5dc0:      	cmp	w24, #0xff
    5dc4:      	mov	w8, #0xff               // =255
    5dc8:      	add	x2, x22, #0x4
    5dcc:      	mov	x22, x0
    5dd0:      	csel	w1, w24, w8, lo
    5dd4:      	mov	x8, x0
    5dd8:      	lsl	w9, w1, #3
    5ddc:      	str	w9, [x8], #0x4
    5de0:      	mov	w9, #0x4                // =4
    5de4:      	mov	x0, x8
    5de8:      	blr	x9
    5dec:      	mov	w8, #0x1                // =1
    5df0:      	mov	x0, x19
    5df4:      	mov	x1, x22
    5df8:      	blr	x8
    5dfc:      	cmp	x0, #0x0
    5e00:      	cset	w23, ne
    5e04:      	b	0x6df8 <generic_rawtp_filter_arg+0x1a48>
    5e08:      	ldrb	w8, [x29, #0x10]
    5e0c:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5e10:      	add	x9, sp, #0x88
    5e14:      	add	x1, sp, #0x88
    5e18:      	str	w8, [sp, #0x88]
    5e1c:      	mov	w8, #0x1                // =1
    5e20:      	ldr	x0, [x0]
    5e24:      	blr	x8
    5e28:      	cbz	x0, 0x6b94 <generic_rawtp_filter_arg+0x17e4>
    5e2c:      	ldr	w8, [x22]
    5e30:      	add	x9, sp, #0x60
    5e34:      	add	x1, sp, #0x60
    5e38:      	str	x8, [sp, #0x60]
    5e3c:      	mov	w8, #0x1                // =1
    5e40:      	b	0x6b5c <generic_rawtp_filter_arg+0x17ac>
    5e44:      	cmp	w8, #0xc
    5e48:      	b.ne	0x6bbc <generic_rawtp_filter_arg+0x180c>
    5e4c:      	ldr	x11, [x22]
    5e50:      	tst	x11, x10
    5e54:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    5e58:      	b	0x6bbc <generic_rawtp_filter_arg+0x180c>
    5e5c:      	mov	x10, xzr
    5e60:      	b	0x5e8c <generic_rawtp_filter_arg+0xadc>
    5e64:      	ldrh	w11, [x22]
    5e68:      	mov	x10, xzr
    5e6c:      	strh	w11, [sp, #0x86]
    5e70:      	ldrh	w11, [x22, #0x2]
    5e74:      	strh	w11, [sp, #0x80]
    5e78:      	ldr	x11, [x22, #0x8]
    5e7c:      	str	x11, [sp, #0x60]
    5e80:      	ldr	x11, [x22, #0x10]
    5e84:      	add	x22, sp, #0x60
    5e88:      	str	x11, [sp, #0x68]
    5e8c:      	mov	x23, xzr
    5e90:      	cmp	w8, #0x13
    5e94:      	b.le	0x5ebc <generic_rawtp_filter_arg+0xb0c>
    5e98:      	cmp	w8, #0x17
    5e9c:      	b.gt	0x5ee4 <generic_rawtp_filter_arg+0xb34>
    5ea0:      	sub	w9, w8, #0x14
    5ea4:      	cmp	w9, #0x2
    5ea8:      	b.lo	0x63ec <generic_rawtp_filter_arg+0x103c>
    5eac:      	sub	w9, w8, #0x16
    5eb0:      	cmp	w9, #0x2
    5eb4:      	b.lo	0x63d8 <generic_rawtp_filter_arg+0x1028>
    5eb8:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    5ebc:      	cmp	w8, #0xf
    5ec0:      	b.le	0x6114 <generic_rawtp_filter_arg+0xd64>
    5ec4:      	cmp	w8, #0x11
    5ec8:      	b.gt	0x63c8 <generic_rawtp_filter_arg+0x1018>
    5ecc:      	cmp	w8, #0x10
    5ed0:      	b.eq	0x63d8 <generic_rawtp_filter_arg+0x1028>
    5ed4:      	cmp	w8, #0x11
    5ed8:      	b.ne	0x5644 <generic_rawtp_filter_arg+0x294>
    5edc:      	ldrh	w23, [x22, #0x24]
    5ee0:      	b	0x6b28 <generic_rawtp_filter_arg+0x1778>
    5ee4:      	cmp	w8, #0x1b
    5ee8:      	b.gt	0x6400 <generic_rawtp_filter_arg+0x1050>
    5eec:      	cmp	w8, #0x18
    5ef0:      	b.eq	0x6430 <generic_rawtp_filter_arg+0x1080>
    5ef4:      	cmp	w8, #0x19
    5ef8:      	b.eq	0x6424 <generic_rawtp_filter_arg+0x1074>
    5efc:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    5f00:      	sub	w10, w8, #0x1f
    5f04:      	cmp	w10, #0x2
    5f08:      	b.hs	0x68b0 <generic_rawtp_filter_arg+0x1500>
    5f0c:      	cmp	w8, #0x1f
    5f10:      	b.ne	0x60ec <generic_rawtp_filter_arg+0xd3c>
    5f14:      	ldp	x11, x10, [x29, #0x10]
    5f18:      	cmp	w9, #0xa
    5f1c:      	b.eq	0x5f28 <generic_rawtp_filter_arg+0xb78>
    5f20:      	cmp	w9, #0xc
    5f24:      	b.ne	0x6a98 <generic_rawtp_filter_arg+0x16e8>
    5f28:      	ldr	x8, [x22]
    5f2c:      	cmp	x11, x8
    5f30:      	b.gt	0x6aac <generic_rawtp_filter_arg+0x16fc>
    5f34:      	cmp	x8, x10
    5f38:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    5f3c:      	b	0x6aac <generic_rawtp_filter_arg+0x16fc>
    5f40:      	cmp	w8, #0x21
    5f44:      	b.eq	0x6514 <generic_rawtp_filter_arg+0x1164>
    5f48:      	cmp	w8, #0x22
    5f4c:      	b.ne	0x65e8 <generic_rawtp_filter_arg+0x1238>
    5f50:      	mov	x23, xzr
    5f54:      	mov	w19, wzr
    5f58:      	add	x8, x29, #0x10
    5f5c:      	str	x8, [sp, #0x28]
    5f60:      	ldr	x8, [sp, #0x28]
    5f64:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1b60>
    5f68:      	add	x9, sp, #0x60
    5f6c:      	add	x1, sp, #0x60
    5f70:      	ldr	w8, [x8, x23, lsl #2]
    5f74:      	str	w8, [sp, #0x60]
    5f78:      	mov	w8, #0x1                // =1
    5f7c:      	ldr	x0, [x0]
    5f80:      	blr	x8
    5f84:      	cbz	x0, 0x65d0 <generic_rawtp_filter_arg+0x1220>
    5f88:      	cbz	w24, 0x6010 <generic_rawtp_filter_arg+0xc60>
    5f8c:      	mov	x8, xzr
    5f90:      	mov	x9, x22
    5f94:      	mov	x10, x24
    5f98:      	b	0x5fb0 <generic_rawtp_filter_arg+0xc00>
    5f9c:      	add	x8, x8, #0x1
    5fa0:      	sub	x10, x10, #0x1
    5fa4:      	add	x9, x9, #0x1
    5fa8:      	cmp	x8, x24
    5fac:      	b.eq	0x6010 <generic_rawtp_filter_arg+0xc60>
    5fb0:      	mov	x11, xzr
    5fb4:      	nop
    5fb8:      	nop
    5fbc:      	nop
    5fc0:      	cmp	x10, x11
    5fc4:      	b.eq	0x5f9c <generic_rawtp_filter_arg+0xbec>
    5fc8:      	ldrb	w12, [x0, x11]
    5fcc:      	cbz	w12, 0x600c <generic_rawtp_filter_arg+0xc5c>
    5fd0:      	ldrb	w13, [x9, x11]
    5fd4:      	sub	w14, w13, #0x41
    5fd8:      	orr	w15, w13, #0x20
    5fdc:      	cmp	w14, #0x1a
    5fe0:      	sub	w14, w12, #0x41
    5fe4:      	csel	w13, w15, w13, lo
    5fe8:      	orr	w15, w12, #0x20
    5fec:      	cmp	w14, #0x1a
    5ff0:      	csel	w12, w15, w12, lo
    5ff4:      	cmp	x11, #0x62
    5ff8:      	b.hi	0x5f9c <generic_rawtp_filter_arg+0xbec>
    5ffc:      	add	x11, x11, #0x1
    6000:      	cmp	w13, w12
    6004:      	b.eq	0x5fc0 <generic_rawtp_filter_arg+0xc10>
    6008:      	b	0x5f9c <generic_rawtp_filter_arg+0xbec>
    600c:      	tbz	w8, #0x1f, 0x70e4 <generic_rawtp_filter_arg+0x1d34>
    6010:      	ldr	w9, [x29, #0x8]
    6014:      	add	w8, w19, #0xc
    6018:      	cmp	w8, w9
    601c:      	b.hs	0x65d0 <generic_rawtp_filter_arg+0x1220>
    6020:      	add	x23, x23, #0x1
    6024:      	add	w19, w19, #0x4
    6028:      	cmp	x23, #0x64
    602c:      	b.ne	0x5f60 <generic_rawtp_filter_arg+0xbb0>
    6030:      	b	0x65d0 <generic_rawtp_filter_arg+0x1220>
    6034:      	ldr	w8, [x29, #0x10]
    6038:      	str	wzr, [sp, #0x88]
    603c:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6040:      	add	x9, sp, #0x60
    6044:      	add	x1, sp, #0x60
    6048:      	str	w8, [sp, #0x60]
    604c:      	mov	w8, #0x1                // =1
    6050:      	ldr	x0, [x0]
    6054:      	blr	x8
    6058:      	mov	x23, xzr
    605c:      	cbz	w24, 0x65d8 <generic_rawtp_filter_arg+0x1228>
    6060:      	cbz	x0, 0x65d8 <generic_rawtp_filter_arg+0x1228>
    6064:      	mov	x19, x0
    6068:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    606c:      	mov	w8, #0x1                // =1
    6070:      	ldr	x0, [x0]
    6074:      	add	x9, sp, #0x88
    6078:      	add	x1, sp, #0x88
    607c:      	blr	x8
    6080:      	cbz	x0, 0x65d0 <generic_rawtp_filter_arg+0x1220>
    6084:      	cmp	w24, #0xff
    6088:      	mov	w8, #0xff               // =255
    608c:      	mov	x2, x22
    6090:      	csel	w1, w24, w8, lo
    6094:      	mov	x8, x0
    6098:      	mov	x24, x0
    609c:      	lsl	w9, w1, #3
    60a0:      	str	w9, [x8], #0x4
    60a4:      	mov	w9, #0x4                // =4
    60a8:      	mov	x0, x8
    60ac:      	blr	x9
    60b0:      	mov	w8, #0x1                // =1
    60b4:      	mov	x0, x19
    60b8:      	mov	x1, x24
    60bc:      	blr	x8
    60c0:      	cmp	x0, #0x0
    60c4:      	cset	w23, ne
    60c8:      	b	0x65d4 <generic_rawtp_filter_arg+0x1224>
    60cc:      	cmp	w24, #0x1fe
    60d0:      	str	wzr, [sp, #0x88]
    60d4:      	b.ls	0x6610 <generic_rawtp_filter_arg+0x1260>
    60d8:      	mov	x23, xzr
    60dc:      	ldr	w8, [x29, #0x4]
    60e0:      	cmp	w8, #0x25
    60e4:      	b.ls	0x65f4 <generic_rawtp_filter_arg+0x1244>
    60e8:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    60ec:      	ldp	x11, x8, [x29, #0x10]
    60f0:      	cmp	w9, #0xc
    60f4:      	b.eq	0x6100 <generic_rawtp_filter_arg+0xd50>
    60f8:      	cmp	w9, #0xa
    60fc:      	b.ne	0x6ae4 <generic_rawtp_filter_arg+0x1734>
    6100:      	ldr	x10, [x22]
    6104:      	cmp	x11, x10
    6108:      	ccmp	x10, x8, #0x0, le
    610c:      	cset	w8, le
    6110:      	b	0x6af4 <generic_rawtp_filter_arg+0x1744>
    6114:      	cmp	w8, #0xd
    6118:      	b.eq	0x6430 <generic_rawtp_filter_arg+0x1080>
    611c:      	cmp	w8, #0xe
    6120:      	b.eq	0x6424 <generic_rawtp_filter_arg+0x1074>
    6124:      	cmp	w8, #0xf
    6128:      	b.eq	0x63ec <generic_rawtp_filter_arg+0x103c>
    612c:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6130:      	cmp	w8, #0x20
    6134:      	b.gt	0x66b8 <generic_rawtp_filter_arg+0x1308>
    6138:      	cmp	w8, #0x1a
    613c:      	b.eq	0x6810 <generic_rawtp_filter_arg+0x1460>
    6140:      	cmp	w8, #0x1b
    6144:      	b.ne	0x80ac <generic_rawtp_filter_arg+0x2cfc>
    6148:      	ldr	w8, [x29, #0x10]
    614c:      	str	wzr, [sp, #0x88]
    6150:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6154:      	add	x9, sp, #0x60
    6158:      	add	x1, sp, #0x60
    615c:      	mov	w19, #0x1               // =1
    6160:      	str	w8, [sp, #0x60]
    6164:      	mov	w8, #0x1                // =1
    6168:      	ldr	x0, [x0]
    616c:      	blr	x8
    6170:      	mov	x23, xzr
    6174:      	cbz	w22, 0x809c <generic_rawtp_filter_arg+0x2cec>
    6178:      	cbz	x0, 0x809c <generic_rawtp_filter_arg+0x2cec>
    617c:      	mov	x23, x0
    6180:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6184:      	mov	w8, #0x1                // =1
    6188:      	ldr	x0, [x0]
    618c:      	add	x9, sp, #0x88
    6190:      	add	x1, sp, #0x88
    6194:      	blr	x8
    6198:      	cbz	x0, 0x8098 <generic_rawtp_filter_arg+0x2ce8>
    619c:      	cmp	w22, #0x7f
    61a0:      	mov	w9, #0x7f               // =127
    61a4:      	mov	x1, x0
    61a8:      	mov	x8, xzr
    61ac:      	sub	x11, x19, x22
    61b0:      	sub	w12, w22, #0x2
    61b4:      	sub	w13, w22, #0x1
    61b8:      	csel	w9, w22, w9, lo
    61bc:      	lsl	w10, w9, #3
    61c0:      	mov	x9, x0
    61c4:      	str	w10, [x9], #0x5
    61c8:      	neg	x10, x22
    61cc:      	add	w14, w13, w8
    61d0:      	cmp	x11, x8
    61d4:      	and	x14, x14, #0xfff
    61d8:      	ldrb	w14, [x24, x14]
    61dc:      	sturb	w14, [x9, #-0x1]
    61e0:      	b.eq	0x6208 <generic_rawtp_filter_arg+0xe58>
    61e4:      	cmn	x8, #0x7e
    61e8:      	b.eq	0x6208 <generic_rawtp_filter_arg+0xe58>
    61ec:      	add	w14, w12, w8
    61f0:      	sub	x8, x8, #0x2
    61f4:      	and	x14, x14, #0xfff
    61f8:      	cmp	x10, x8
    61fc:      	ldrb	w14, [x24, x14]
    6200:      	strb	w14, [x9], #0x2
    6204:      	b.ne	0x61cc <generic_rawtp_filter_arg+0xe1c>
    6208:      	mov	w8, #0x1                // =1
    620c:      	mov	x0, x23
    6210:      	b	0x8088 <generic_rawtp_filter_arg+0x2cd8>
    6214:      	cmp	w8, #0xc
    6218:      	b.ne	0x7240 <generic_rawtp_filter_arg+0x1e90>
    621c:      	ldr	w11, [x22]
    6220:      	tst	w11, w10
    6224:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    6228:      	b	0x7240 <generic_rawtp_filter_arg+0x1e90>
    622c:      	lsl	x9, x12, x8
    6230:      	tst	x9, #0xc00
    6234:      	b.ne	0x6778 <generic_rawtp_filter_arg+0x13c8>
    6238:      	lsl	x9, x12, x8
    623c:      	tst	x9, #0x180000000
    6240:      	b.eq	0x54ac <generic_rawtp_filter_arg+0xfc>
    6244:      	cmp	w8, #0x1f
    6248:      	b.ne	0x6e00 <generic_rawtp_filter_arg+0x1a50>
    624c:      	ldr	w9, [x29, #0x10]
    6250:      	ldrb	w8, [x22]
    6254:      	b	0x6280 <generic_rawtp_filter_arg+0xed0>
    6258:      	lsl	x9, x12, x8
    625c:      	tst	x9, #0xc00
    6260:      	b.ne	0x67b4 <generic_rawtp_filter_arg+0x1404>
    6264:      	lsl	x9, x12, x8
    6268:      	tst	x9, #0x180000000
    626c:      	b.eq	0x54ac <generic_rawtp_filter_arg+0xfc>
    6270:      	cmp	w8, #0x1f
    6274:      	b.ne	0x6e24 <generic_rawtp_filter_arg+0x1a74>
    6278:      	ldr	w9, [x29, #0x10]
    627c:      	ldrh	w8, [x22]
    6280:      	cmp	w9, w8
    6284:      	b.hi	0x6294 <generic_rawtp_filter_arg+0xee4>
    6288:      	ldr	w9, [x29, #0x14]
    628c:      	cmp	w9, w8
    6290:      	b.hs	0x5648 <generic_rawtp_filter_arg+0x298>
    6294:      	ldr	w9, [x29, #0x8]
    6298:      	cmp	w9, #0x11
    629c:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    62a0:      	ldr	w10, [x29, #0x18]
    62a4:      	cmp	w10, w8
    62a8:      	b.hi	0x62b8 <generic_rawtp_filter_arg+0xf08>
    62ac:      	ldr	w10, [x29, #0x1c]
    62b0:      	cmp	w10, w8
    62b4:      	b.hs	0x5648 <generic_rawtp_filter_arg+0x298>
    62b8:      	cmp	w9, #0x19
    62bc:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    62c0:      	ldr	w10, [x29, #0x20]
    62c4:      	cmp	w10, w8
    62c8:      	b.hi	0x62d8 <generic_rawtp_filter_arg+0xf28>
    62cc:      	ldr	w10, [x29, #0x24]
    62d0:      	cmp	w10, w8
    62d4:      	b.hs	0x5648 <generic_rawtp_filter_arg+0x298>
    62d8:      	cmp	w9, #0x21
    62dc:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    62e0:      	ldr	w9, [x29, #0x28]
    62e4:      	cmp	w9, w8
    62e8:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    62ec:      	ldr	w9, [x29, #0x2c]
    62f0:      	cmp	w9, w8
    62f4:      	b.hs	0x5648 <generic_rawtp_filter_arg+0x298>
    62f8:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    62fc:      	cmp	w9, #0xc
    6300:      	b.eq	0x630c <generic_rawtp_filter_arg+0xf5c>
    6304:      	cmp	w9, #0xa
    6308:      	b.ne	0x6ba0 <generic_rawtp_filter_arg+0x17f0>
    630c:      	ldr	x11, [x22]
    6310:      	cmp	x11, x10
    6314:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    6318:      	b	0x6bbc <generic_rawtp_filter_arg+0x180c>
    631c:      	ldp	x16, x15, [sp, #0x40]
    6320:      	mov	x23, xzr
    6324:      	mov	w2, #0x5ea0             // =24224
    6328:      	mov	w12, #0x1               // =1
    632c:      	ldr	x17, [sp, #0x38]
    6330:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6334:      	and	w8, w24, #0xffff
    6338:      	cmp	w8, #0x90
    633c:      	b.hi	0x6910 <generic_rawtp_filter_arg+0x1560>
    6340:      	and	w8, w24, #0xff
    6344:      	mov	w9, #0xab               // =171
    6348:      	tst	w24, #0xffff
    634c:      	mul	w8, w8, w9
    6350:      	mov	w9, #0x18               // =24
    6354:      	lsr	w8, w8, #12
    6358:      	msub	w8, w8, w9, w24
    635c:      	b.eq	0x636c <generic_rawtp_filter_arg+0xfbc>
    6360:      	tst	w8, #0xff
    6364:      	mov	w11, w24
    6368:      	b.eq	0x6380 <generic_rawtp_filter_arg+0xfd0>
    636c:      	sub	w8, w24, w8, uxtb
    6370:      	and	w9, w8, #0xffff
    6374:      	add	w11, w8, #0x18
    6378:      	cmp	w9, #0x78
    637c:      	b.hi	0x6924 <generic_rawtp_filter_arg+0x1574>
    6380:      	and	w8, w11, #0xff
    6384:      	mov	w9, #0xab               // =171
    6388:      	mul	w8, w8, w9
    638c:      	lsr	w8, w8, #12
    6390:      	sub	w10, w8, #0x1
    6394:      	b	0x6934 <generic_rawtp_filter_arg+0x1584>
    6398:      	ldp	w11, w8, [x29, #0x10]
    639c:      	cmp	w9, #0xc
    63a0:      	b.hi	0x7098 <generic_rawtp_filter_arg+0x1ce8>
    63a4:      	lsl	w10, w12, w9
    63a8:      	mov	w13, #0x1402            // =5122
    63ac:      	tst	w10, w13
    63b0:      	b.eq	0x7098 <generic_rawtp_filter_arg+0x1ce8>
    63b4:      	ldr	w10, [x22]
    63b8:      	cmp	w11, w10
    63bc:      	ccmp	w10, w8, #0x0, le
    63c0:      	cset	w8, le
    63c4:      	b	0x70a8 <generic_rawtp_filter_arg+0x1cf8>
    63c8:      	cmp	w8, #0x12
    63cc:      	b.eq	0x63ec <generic_rawtp_filter_arg+0x103c>
    63d0:      	cmp	w8, #0x13
    63d4:      	b.ne	0x5644 <generic_rawtp_filter_arg+0x294>
    63d8:      	ldrh	w24, [x22, #0x22]
    63dc:      	mov	w11, wzr
    63e0:      	mov	w13, wzr
    63e4:      	mov	x19, xzr
    63e8:      	b	0x643c <generic_rawtp_filter_arg+0x108c>
    63ec:      	ldrh	w24, [x22, #0x20]
    63f0:      	mov	w11, wzr
    63f4:      	mov	w13, wzr
    63f8:      	mov	x19, xzr
    63fc:      	b	0x643c <generic_rawtp_filter_arg+0x108c>
    6400:      	cmp	w8, #0x1c
    6404:      	b.eq	0x6b24 <generic_rawtp_filter_arg+0x1774>
    6408:      	cmp	w8, #0x1d
    640c:      	b.ne	0x5644 <generic_rawtp_filter_arg+0x294>
    6410:      	cmp	w9, #0x7
    6414:      	b.ne	0x7170 <generic_rawtp_filter_arg+0x1dc0>
    6418:      	cbnz	x10, 0x7180 <generic_rawtp_filter_arg+0x1dd0>
    641c:      	mov	x19, xzr
    6420:      	b	0x7194 <generic_rawtp_filter_arg+0x1de4>
    6424:      	ldp	w11, w13, [x22, #0x10]
    6428:      	ldr	x19, [x22, #0x18]
    642c:      	b	0x6438 <generic_rawtp_filter_arg+0x1088>
    6430:      	ldp	w11, w13, [x22]
    6434:      	ldr	x19, [x22, #0x8]
    6438:      	mov	x24, xzr
    643c:      	mov	x23, xzr
    6440:      	cmp	w8, #0x11
    6444:      	b.gt	0x6470 <generic_rawtp_filter_arg+0x10c0>
    6448:      	sub	w9, w8, #0xd
    644c:      	cmp	w9, #0x2
    6450:      	b.lo	0x649c <generic_rawtp_filter_arg+0x10ec>
    6454:      	ldr	x19, [sp, #0x30]
    6458:      	sub	w9, w8, #0xf
    645c:      	cmp	w9, #0x2
    6460:      	b.lo	0x6684 <generic_rawtp_filter_arg+0x12d4>
    6464:      	cmp	w8, #0x11
    6468:      	b.eq	0x6b28 <generic_rawtp_filter_arg+0x1778>
    646c:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6470:      	cmp	w8, #0x19
    6474:      	b.hi	0x6674 <generic_rawtp_filter_arg+0x12c4>
    6478:      	lsl	w9, w12, w8
    647c:      	mov	w10, #0x500000          // =5242880
    6480:      	tst	w9, w10
    6484:      	b.ne	0x68f0 <generic_rawtp_filter_arg+0x1540>
    6488:      	mov	w10, #0xa00000          // =10485760
    648c:      	tst	w9, w10
    6490:      	b.ne	0x6900 <generic_rawtp_filter_arg+0x1550>
    6494:      	tst	w9, #0x3000000
    6498:      	b.eq	0x6674 <generic_rawtp_filter_arg+0x12c4>
    649c:      	ldrh	w8, [x22, #0x26]
    64a0:      	cmp	w8, #0xa
    64a4:      	b.eq	0x69fc <generic_rawtp_filter_arg+0x164c>
    64a8:      	cmp	w8, #0x2
    64ac:      	b.ne	0x6a88 <generic_rawtp_filter_arg+0x16d8>
    64b0:      	ldr	w8, [x29, #0x10]
    64b4:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    64b8:      	add	x9, sp, #0xac
    64bc:      	add	x1, sp, #0xac
    64c0:      	str	w8, [sp, #0xac]
    64c4:      	mov	w8, #0x1                // =1
    64c8:      	mov	w22, w11
    64cc:      	ldr	x0, [x0]
    64d0:      	blr	x8
    64d4:      	ldr	x19, [sp, #0x30]
    64d8:      	cbz	x0, 0x7308 <generic_rawtp_filter_arg+0x1f58>
    64dc:      	mov	w8, #0x20               // =32
    64e0:      	add	x1, sp, #0x88
    64e4:      	stp	w8, w22, [sp, #0x88]
    64e8:      	b	0x6a44 <generic_rawtp_filter_arg+0x1694>
    64ec:      	cmp	w9, #0xc
    64f0:      	b.hi	0x7224 <generic_rawtp_filter_arg+0x1e74>
    64f4:      	lsl	w11, w12, w9
    64f8:      	mov	w13, #0x1402            // =5122
    64fc:      	tst	w11, w13
    6500:      	b.eq	0x7224 <generic_rawtp_filter_arg+0x1e74>
    6504:      	ldr	w11, [x22]
    6508:      	cmp	w11, w10
    650c:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    6510:      	b	0x7240 <generic_rawtp_filter_arg+0x1e90>
    6514:      	mov	x19, xzr
    6518:      	mov	w23, wzr
    651c:      	add	x8, x29, #0x10
    6520:      	str	x8, [sp, #0x28]
    6524:      	ldr	x8, [sp, #0x28]
    6528:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    652c:      	add	x9, sp, #0x60
    6530:      	add	x1, sp, #0x60
    6534:      	ldr	w8, [x8, x19, lsl #2]
    6538:      	str	w8, [sp, #0x60]
    653c:      	mov	w8, #0x1                // =1
    6540:      	ldr	x0, [x0]
    6544:      	blr	x8
    6548:      	cbz	x0, 0x65d0 <generic_rawtp_filter_arg+0x1220>
    654c:      	cbz	w24, 0x65b0 <generic_rawtp_filter_arg+0x1200>
    6550:      	mov	x8, xzr
    6554:      	mov	x9, x22
    6558:      	mov	x10, x24
    655c:      	b	0x6574 <generic_rawtp_filter_arg+0x11c4>
    6560:      	add	x8, x8, #0x1
    6564:      	sub	x10, x10, #0x1
    6568:      	add	x9, x9, #0x1
    656c:      	cmp	x8, x24
    6570:      	b.eq	0x65b0 <generic_rawtp_filter_arg+0x1200>
    6574:      	mov	x11, xzr
    6578:      	nop
    657c:      	nop
    6580:      	cmp	x10, x11
    6584:      	b.eq	0x6560 <generic_rawtp_filter_arg+0x11b0>
    6588:      	ldrb	w12, [x0, x11]
    658c:      	cbz	w12, 0x65ac <generic_rawtp_filter_arg+0x11fc>
    6590:      	cmp	x11, #0x62
    6594:      	b.hi	0x6560 <generic_rawtp_filter_arg+0x11b0>
    6598:      	ldrb	w13, [x9, x11]
    659c:      	add	x11, x11, #0x1
    65a0:      	cmp	w13, w12
    65a4:      	b.eq	0x6580 <generic_rawtp_filter_arg+0x11d0>
    65a8:      	b	0x6560 <generic_rawtp_filter_arg+0x11b0>
    65ac:      	tbz	w8, #0x1f, 0x70e4 <generic_rawtp_filter_arg+0x1d34>
    65b0:      	ldr	w9, [x29, #0x8]
    65b4:      	add	w8, w23, #0xc
    65b8:      	cmp	w8, w9
    65bc:      	b.hs	0x65d0 <generic_rawtp_filter_arg+0x1220>
    65c0:      	add	x19, x19, #0x1
    65c4:      	add	w23, w23, #0x4
    65c8:      	cmp	x19, #0x64
    65cc:      	b.ne	0x6524 <generic_rawtp_filter_arg+0x1174>
    65d0:      	mov	x23, xzr
    65d4:      	ldr	x19, [sp, #0x30]
    65d8:      	ldp	x16, x15, [sp, #0x40]
    65dc:      	mov	w2, #0x5ea0             // =24224
    65e0:      	mov	w12, #0x1               // =1
    65e4:      	ldr	x17, [sp, #0x38]
    65e8:      	ldr	w8, [x29, #0x4]
    65ec:      	cmp	w8, #0x25
    65f0:      	b.hi	0x5644 <generic_rawtp_filter_arg+0x294>
    65f4:      	mov	x9, #0x50               // =80
    65f8:      	lsl	x8, x12, x8
    65fc:      	movk	x9, #0xc00, lsl #16
    6600:      	movk	x9, #0x20, lsl #32
    6604:      	tst	x8, x9
    6608:      	b.ne	0x80d4 <generic_rawtp_filter_arg+0x2d24>
    660c:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6610:      	and	w8, w24, #0xffff
    6614:      	cmp	w8, #0x90
    6618:      	b.hi	0x6c90 <generic_rawtp_filter_arg+0x18e0>
    661c:      	and	w8, w24, #0xff
    6620:      	mov	w9, #0xab               // =171
    6624:      	tst	w24, #0xffff
    6628:      	mul	w8, w8, w9
    662c:      	mov	w9, #0x18               // =24
    6630:      	lsr	w8, w8, #12
    6634:      	msub	w8, w8, w9, w24
    6638:      	b.eq	0x6648 <generic_rawtp_filter_arg+0x1298>
    663c:      	tst	w8, #0xff
    6640:      	mov	w11, w24
    6644:      	b.eq	0x665c <generic_rawtp_filter_arg+0x12ac>
    6648:      	sub	w8, w24, w8, uxtb
    664c:      	and	w9, w8, #0xffff
    6650:      	add	w11, w8, #0x18
    6654:      	cmp	w9, #0x78
    6658:      	b.hi	0x6ca4 <generic_rawtp_filter_arg+0x18f4>
    665c:      	and	w8, w11, #0xff
    6660:      	mov	w9, #0xab               // =171
    6664:      	mul	w8, w8, w9
    6668:      	lsr	w8, w8, #12
    666c:      	sub	w10, w8, #0x1
    6670:      	b	0x6cb4 <generic_rawtp_filter_arg+0x1904>
    6674:      	ldr	x19, [sp, #0x30]
    6678:      	sub	w8, w8, #0x12
    667c:      	cmp	w8, #0x2
    6680:      	b.hs	0x5644 <generic_rawtp_filter_arg+0x294>
    6684:      	ldrb	w8, [x29, #0x10]
    6688:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    668c:      	add	x9, sp, #0xac
    6690:      	add	x1, sp, #0xac
    6694:      	str	w8, [sp, #0xac]
    6698:      	mov	w8, #0x1                // =1
    669c:      	ldr	x0, [x0]
    66a0:      	blr	x8
    66a4:      	cbz	x0, 0x6b94 <generic_rawtp_filter_arg+0x17e4>
    66a8:      	str	x24, [sp, #0x88]
    66ac:      	mov	w8, #0x1                // =1
    66b0:      	add	x9, sp, #0x88
    66b4:      	b	0x6b58 <generic_rawtp_filter_arg+0x17a8>
    66b8:      	cmp	w8, #0x21
    66bc:      	b.eq	0x6e90 <generic_rawtp_filter_arg+0x1ae0>
    66c0:      	cmp	w8, #0x22
    66c4:      	b.ne	0x80ac <generic_rawtp_filter_arg+0x2cfc>
    66c8:      	mov	w19, #0x10              // =16
    66cc:      	ldr	w8, [x29, x19]
    66d0:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    66d4:      	add	x9, sp, #0x60
    66d8:      	add	x1, sp, #0x60
    66dc:      	str	w8, [sp, #0x60]
    66e0:      	mov	w8, #0x1                // =1
    66e4:      	ldr	x0, [x0]
    66e8:      	blr	x8
    66ec:      	cbz	x0, 0x7860 <generic_rawtp_filter_arg+0x24b0>
    66f0:      	mov	x1, x0
    66f4:      	mov	x0, x24
    66f8:      	mov	x2, x22
    66fc:      	bl	0x66fc <generic_rawtp_filter_arg+0x134c>
    6700:      	tbz	w0, #0x1f, 0x7868 <generic_rawtp_filter_arg+0x24b8>
    6704:      	ldr	w8, [x29, #0x8]
    6708:      	add	x19, x19, #0x4
    670c:      	mov	w12, #0x1               // =1
    6710:      	mov	x23, xzr
    6714:      	sub	w9, w19, #0x8
    6718:      	cmp	w9, w8
    671c:      	b.hs	0x7870 <generic_rawtp_filter_arg+0x24c0>
    6720:      	ldp	x16, x15, [sp, #0x40]
    6724:      	cmp	x19, #0x1a0
    6728:      	mov	w2, #0x5ea0             // =24224
    672c:      	ldr	x17, [sp, #0x38]
    6730:      	b.ne	0x66cc <generic_rawtp_filter_arg+0x131c>
    6734:      	b	0x80ac <generic_rawtp_filter_arg+0x2cfc>
    6738:      	cmp	w8, #0x1
    673c:      	b.eq	0x6fb8 <generic_rawtp_filter_arg+0x1c08>
    6740:      	cmp	w8, #0x2
    6744:      	b.ne	0x6fc4 <generic_rawtp_filter_arg+0x1c14>
    6748:      	ldrb	w10, [x22]
    674c:      	cmp	w9, w10
    6750:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    6754:      	b	0x6fc4 <generic_rawtp_filter_arg+0x1c14>
    6758:      	cmp	w8, #0x1
    675c:      	b.eq	0x6ff8 <generic_rawtp_filter_arg+0x1c48>
    6760:      	cmp	w8, #0x2
    6764:      	b.ne	0x7004 <generic_rawtp_filter_arg+0x1c54>
    6768:      	ldrh	w10, [x22]
    676c:      	cmp	w9, w10
    6770:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    6774:      	b	0x7004 <generic_rawtp_filter_arg+0x1c54>
    6778:      	ldrb	w8, [x29, #0x10]
    677c:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6780:      	add	x9, sp, #0x88
    6784:      	add	x1, sp, #0x88
    6788:      	str	w8, [sp, #0x88]
    678c:      	mov	w8, #0x1                // =1
    6790:      	ldr	x0, [x0]
    6794:      	blr	x8
    6798:      	cbz	x0, 0x6b94 <generic_rawtp_filter_arg+0x17e4>
    679c:      	ldrb	w8, [x22]
    67a0:      	add	x9, sp, #0x60
    67a4:      	add	x1, sp, #0x60
    67a8:      	str	x8, [sp, #0x60]
    67ac:      	mov	w8, #0x1                // =1
    67b0:      	b	0x6b5c <generic_rawtp_filter_arg+0x17ac>
    67b4:      	ldrb	w8, [x29, #0x10]
    67b8:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    67bc:      	add	x9, sp, #0x88
    67c0:      	add	x1, sp, #0x88
    67c4:      	str	w8, [sp, #0x88]
    67c8:      	mov	w8, #0x1                // =1
    67cc:      	ldr	x0, [x0]
    67d0:      	blr	x8
    67d4:      	cbz	x0, 0x6b94 <generic_rawtp_filter_arg+0x17e4>
    67d8:      	ldrh	w8, [x22]
    67dc:      	add	x9, sp, #0x60
    67e0:      	add	x1, sp, #0x60
    67e4:      	str	x8, [sp, #0x60]
    67e8:      	mov	w8, #0x1                // =1
    67ec:      	b	0x6b5c <generic_rawtp_filter_arg+0x17ac>
    67f0:      	ldp	x16, x15, [sp, #0x40]
    67f4:      	cmp	x0, #0x0
    67f8:      	mov	w2, #0x5ea0             // =24224
    67fc:      	mov	w12, #0x1               // =1
    6800:      	cset	w8, eq
    6804:      	ldr	x17, [sp, #0x38]
    6808:      	mov	w23, w8
    680c:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6810:      	ldr	w8, [x29, #0x10]
    6814:      	str	wzr, [sp, #0x88]
    6818:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    681c:      	add	x9, sp, #0x60
    6820:      	add	x1, sp, #0x60
    6824:      	str	w8, [sp, #0x60]
    6828:      	mov	w8, #0x1                // =1
    682c:      	ldr	x0, [x0]
    6830:      	blr	x8
    6834:      	mov	x23, xzr
    6838:      	cbz	w22, 0x809c <generic_rawtp_filter_arg+0x2cec>
    683c:      	cbz	x0, 0x809c <generic_rawtp_filter_arg+0x2cec>
    6840:      	mov	x19, x0
    6844:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6848:      	mov	w8, #0x1                // =1
    684c:      	ldr	x0, [x0]
    6850:      	add	x9, sp, #0x88
    6854:      	add	x1, sp, #0x88
    6858:      	blr	x8
    685c:      	cbz	x0, 0x8098 <generic_rawtp_filter_arg+0x2ce8>
    6860:      	cmp	w22, #0xff
    6864:      	mov	w8, #0xff               // =255
    6868:      	mov	x2, x24
    686c:      	csel	w1, w22, w8, lo
    6870:      	mov	x8, x0
    6874:      	mov	x22, x0
    6878:      	lsl	w9, w1, #3
    687c:      	str	w9, [x8], #0x4
    6880:      	mov	w9, #0x4                // =4
    6884:      	mov	x0, x8
    6888:      	blr	x9
    688c:      	mov	w8, #0x1                // =1
    6890:      	mov	x0, x19
    6894:      	mov	x1, x22
    6898:      	b	0x8088 <generic_rawtp_filter_arg+0x2cd8>
    689c:      	cmp	w22, #0x1fe
    68a0:      	str	wzr, [sp, #0x88]
    68a4:      	b.ls	0x6f54 <generic_rawtp_filter_arg+0x1ba4>
    68a8:      	mov	x23, xzr
    68ac:      	b	0x80ac <generic_rawtp_filter_arg+0x2cfc>
    68b0:      	cmp	w8, #0x1e
    68b4:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    68b8:      	ldr	w8, [x29, #0x10]
    68bc:      	and	x8, x8, #0x7
    68c0:      	add	x9, x20, x8, lsl #2
    68c4:      	ldr	w9, [x9, x2]
    68c8:      	cbnz	w9, 0x54ac <generic_rawtp_filter_arg+0xfc>
    68cc:      	add	x8, x20, x8, lsl #3
    68d0:      	ldr	x9, [x22]
    68d4:      	ldr	x8, [x8, #0x5e78]
    68d8:      	and	x8, x8, #0x7ff
    68dc:      	add	x8, x20, x8
    68e0:      	ldr	x8, [x8, #0x90]
    68e4:      	bics	xzr, x8, x9
    68e8:      	cset	w23, ne
    68ec:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    68f0:      	ldr	x19, [sp, #0x30]
    68f4:      	cmp	x24, #0x400
    68f8:      	cset	w23, lo
    68fc:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6900:      	ldr	x19, [sp, #0x30]
    6904:      	cmp	x24, #0x3ff
    6908:      	cset	w23, hi
    690c:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6910:      	and	w8, w24, #0xffff
    6914:      	mov	w9, #0x1fe              // =510
    6918:      	cmp	w8, #0x100
    691c:      	mov	w8, #0x100              // =256
    6920:      	csel	w11, w9, w8, hi
    6924:      	and	w8, w11, #0xffff
    6928:      	cmp	w8, #0x100
    692c:      	mov	w8, #0x6                // =6
    6930:      	cinc	w10, w8, ne
    6934:      	add	x8, x29, #0x10
    6938:      	and	w9, w10, #0xf
    693c:      	ldr	w8, [x8, w9, uxtw #2]
    6940:      	cmn	w8, #0x1
    6944:      	b.eq	0x7c68 <generic_rawtp_filter_arg+0x28b8>
    6948:      	str	w11, [sp, #0x10]
    694c:      	stp	w8, w10, [sp, #0x1c]
    6950:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6954:      	mov	w8, #0x1                // =1
    6958:      	add	x23, sp, #0x88
    695c:      	add	x1, sp, #0x88
    6960:      	ldr	x0, [x0]
    6964:      	blr	x8
    6968:      	str	x0, [sp, #0x28]
    696c:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6970:      	mov	w8, #0x1                // =1
    6974:      	add	x1, sp, #0x88
    6978:      	ldr	x0, [x0]
    697c:      	blr	x8
    6980:      	ldr	x9, [sp, #0x28]
    6984:      	mov	x23, xzr
    6988:      	cbz	x9, 0x7c6c <generic_rawtp_filter_arg+0x28bc>
    698c:      	ldp	x16, x15, [sp, #0x40]
    6990:      	mov	w2, #0x5ea0             // =24224
    6994:      	mov	w12, #0x1               // =1
    6998:      	ldr	x17, [sp, #0x38]
    699c:      	cbz	x0, 0x7c7c <generic_rawtp_filter_arg+0x28cc>
    69a0:      	ldr	w23, [sp, #0x20]
    69a4:      	mov	x8, x9
    69a8:      	str	x0, [sp, #0x8]
    69ac:      	add	x2, x22, #0x4
    69b0:      	mov	x22, x9
    69b4:      	mov	x0, x8
    69b8:      	cmp	w23, #0x5
    69bc:      	b.gt	0x737c <generic_rawtp_filter_arg+0x1fcc>
    69c0:      	strb	w24, [x0], #0x1
    69c4:      	mov	w8, #0x4                // =4
    69c8:      	mov	w1, w24
    69cc:      	blr	x8
    69d0:      	ldr	w8, [sp, #0x10]
    69d4:      	and	w8, w8, #0xffff
    69d8:      	cmp	w8, w24
    69dc:      	b.ls	0x73b8 <generic_rawtp_filter_arg+0x2008>
    69e0:      	add	x9, x22, x24
    69e4:      	sub	w8, w8, w24
    69e8:      	ldr	x2, [sp, #0x8]
    69ec:      	add	x0, x9, #0x1
    69f0:      	and	w1, w8, #0xfff
    69f4:      	mov	w8, #0x4                // =4
    69f8:      	b	0x73b4 <generic_rawtp_filter_arg+0x2004>
    69fc:      	ldr	w8, [x29, #0x14]
    6a00:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6a04:      	add	x9, sp, #0xac
    6a08:      	add	x1, sp, #0xac
    6a0c:      	str	w8, [sp, #0xac]
    6a10:      	mov	w8, #0x1                // =1
    6a14:      	mov	w23, w13
    6a18:      	mov	w22, w11
    6a1c:      	ldr	x0, [x0]
    6a20:      	blr	x8
    6a24:      	cbz	x0, 0x7310 <generic_rawtp_filter_arg+0x1f60>
    6a28:      	mov	w8, #0x80               // =128
    6a2c:      	stp	w23, w19, [sp, #0x90]
    6a30:      	add	x1, sp, #0x88
    6a34:      	stp	w8, w22, [sp, #0x88]
    6a38:      	lsr	x8, x19, #32
    6a3c:      	ldr	x19, [sp, #0x30]
    6a40:      	str	w8, [sp, #0x98]
    6a44:      	mov	w8, #0x1                // =1
    6a48:      	blr	x8
    6a4c:      	ldr	w8, [x29, #0x4]
    6a50:      	sub	w9, w8, #0x18
    6a54:      	cmp	w9, #0x2
    6a58:      	b.lo	0x7038 <generic_rawtp_filter_arg+0x1c88>
    6a5c:      	sub	w8, w8, #0xd
    6a60:      	mov	w12, #0x1               // =1
    6a64:      	cmp	w8, #0x1
    6a68:      	b.hi	0x5c88 <generic_rawtp_filter_arg+0x8d8>
    6a6c:      	cmp	x0, #0x0
    6a70:      	cset	w8, ne
    6a74:      	ldp	x16, x15, [sp, #0x40]
    6a78:      	mov	w2, #0x5ea0             // =24224
    6a7c:      	mov	w23, w8
    6a80:      	ldr	x17, [sp, #0x38]
    6a84:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6a88:      	ldr	x19, [sp, #0x30]
    6a8c:      	mov	w8, wzr
    6a90:      	mov	w23, wzr
    6a94:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    6a98:      	ldr	x8, [x22]
    6a9c:      	cmp	x11, x8
    6aa0:      	b.hi	0x6aac <generic_rawtp_filter_arg+0x16fc>
    6aa4:      	cmp	x8, x10
    6aa8:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    6aac:      	ldr	w10, [x29, #0x8]
    6ab0:      	cmp	w10, #0x19
    6ab4:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    6ab8:      	ldp	x12, x11, [x29, #0x20]
    6abc:      	cmp	w9, #0xc
    6ac0:      	b.eq	0x6acc <generic_rawtp_filter_arg+0x171c>
    6ac4:      	cmp	w9, #0xa
    6ac8:      	b.ne	0x7128 <generic_rawtp_filter_arg+0x1d78>
    6acc:      	cmp	x12, x8
    6ad0:      	mov	w12, #0x1               // =1
    6ad4:      	b.gt	0x713c <generic_rawtp_filter_arg+0x1d8c>
    6ad8:      	cmp	x8, x11
    6adc:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    6ae0:      	b	0x713c <generic_rawtp_filter_arg+0x1d8c>
    6ae4:      	ldr	x10, [x22]
    6ae8:      	cmp	x11, x10
    6aec:      	ccmp	x10, x8, #0x2, ls
    6af0:      	cset	w8, ls
    6af4:      	ldr	w11, [x29, #0x8]
    6af8:      	cmp	w11, #0x19
    6afc:      	b.lo	0x7a84 <generic_rawtp_filter_arg+0x26d4>
    6b00:      	ldp	x13, x12, [x29, #0x20]
    6b04:      	cmp	w9, #0xc
    6b08:      	b.eq	0x6b14 <generic_rawtp_filter_arg+0x1764>
    6b0c:      	cmp	w9, #0xa
    6b10:      	b.ne	0x70ec <generic_rawtp_filter_arg+0x1d3c>
    6b14:      	cmp	x13, x10
    6b18:      	ccmp	x10, x12, #0x0, le
    6b1c:      	cset	w12, le
    6b20:      	b	0x70f8 <generic_rawtp_filter_arg+0x1d48>
    6b24:      	ldrh	w23, [x22, #0x26]
    6b28:      	ldrb	w8, [x29, #0x10]
    6b2c:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6b30:      	add	x9, sp, #0xac
    6b34:      	add	x1, sp, #0xac
    6b38:      	str	w8, [sp, #0xac]
    6b3c:      	mov	w8, #0x1                // =1
    6b40:      	ldr	x0, [x0]
    6b44:      	blr	x8
    6b48:      	cbz	x0, 0x6b94 <generic_rawtp_filter_arg+0x17e4>
    6b4c:      	str	x23, [sp, #0x88]
    6b50:      	mov	w8, #0x1                // =1
    6b54:      	add	x9, sp, #0x88
    6b58:      	add	x1, sp, #0x88
    6b5c:      	blr	x8
    6b60:      	ldr	w9, [x29, #0x4]
    6b64:      	mov	w8, wzr
    6b68:      	mov	w12, #0x1               // =1
    6b6c:      	cmp	w9, #0x1d
    6b70:      	b.hi	0x7210 <generic_rawtp_filter_arg+0x1e60>
    6b74:      	mov	w10, #0x8400            // =33792
    6b78:      	lsl	w9, w12, w9
    6b7c:      	movk	w10, #0x3003, lsl #16
    6b80:      	tst	w9, w10
    6b84:      	b.eq	0x71f8 <generic_rawtp_filter_arg+0x1e48>
    6b88:      	cmp	x0, #0x0
    6b8c:      	cset	w8, ne
    6b90:      	b	0x7210 <generic_rawtp_filter_arg+0x1e60>
    6b94:      	mov	x23, xzr
    6b98:      	mov	w12, #0x1               // =1
    6b9c:      	b	0x7214 <generic_rawtp_filter_arg+0x1e64>
    6ba0:      	ldr	x11, [x22]
    6ba4:      	cmp	x11, x10
    6ba8:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    6bac:      	b	0x6bbc <generic_rawtp_filter_arg+0x180c>
    6bb0:      	ldr	x11, [x22]
    6bb4:      	cmp	x11, x10
    6bb8:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    6bbc:      	ldr	w10, [x29, #0x8]
    6bc0:      	cmp	w10, #0x11
    6bc4:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    6bc8:      	ldr	x11, [x29, #0x18]
    6bcc:      	cmp	w8, #0x2
    6bd0:      	b.le	0x6bf4 <generic_rawtp_filter_arg+0x1844>
    6bd4:      	sub	w12, w8, #0x3
    6bd8:      	cmp	w12, #0x2
    6bdc:      	b.hs	0x6c28 <generic_rawtp_filter_arg+0x1878>
    6be0:      	ldr	x12, [x22]
    6be4:      	cmp	x12, x11
    6be8:      	mov	w12, #0x1               // =1
    6bec:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    6bf0:      	b	0x773c <generic_rawtp_filter_arg+0x238c>
    6bf4:      	cmp	w8, #0x1
    6bf8:      	b.eq	0x6d80 <generic_rawtp_filter_arg+0x19d0>
    6bfc:      	cmp	w8, #0x2
    6c00:      	b.ne	0x773c <generic_rawtp_filter_arg+0x238c>
    6c04:      	cmp	w9, #0xc
    6c08:      	b.eq	0x6c14 <generic_rawtp_filter_arg+0x1864>
    6c0c:      	cmp	w9, #0xa
    6c10:      	b.ne	0x772c <generic_rawtp_filter_arg+0x237c>
    6c14:      	ldr	x12, [x22]
    6c18:      	cmp	x12, x11
    6c1c:      	mov	w12, #0x1               // =1
    6c20:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    6c24:      	b	0x773c <generic_rawtp_filter_arg+0x238c>
    6c28:      	cmp	w8, #0xc
    6c2c:      	mov	w12, #0x1               // =1
    6c30:      	b.ne	0x773c <generic_rawtp_filter_arg+0x238c>
    6c34:      	ldr	x12, [x22]
    6c38:      	tst	x12, x11
    6c3c:      	mov	w12, #0x1               // =1
    6c40:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    6c44:      	b	0x773c <generic_rawtp_filter_arg+0x238c>
    6c48:      	mov	x23, xzr
    6c4c:      	ldr	x19, [sp, #0x30]
    6c50:      	mov	w12, #0x1               // =1
    6c54:      	ldp	x16, x15, [sp, #0x40]
    6c58:      	mov	w2, #0x5ea0             // =24224
    6c5c:      	b	0x7c78 <generic_rawtp_filter_arg+0x28c8>
    6c60:      	cmp	w8, #0xc
    6c64:      	b.ne	0x6fc4 <generic_rawtp_filter_arg+0x1c14>
    6c68:      	ldrb	w10, [x22]
    6c6c:      	tst	w9, w10
    6c70:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    6c74:      	b	0x6fc4 <generic_rawtp_filter_arg+0x1c14>
    6c78:      	cmp	w8, #0xc
    6c7c:      	b.ne	0x7004 <generic_rawtp_filter_arg+0x1c54>
    6c80:      	ldrh	w10, [x22]
    6c84:      	tst	w9, w10
    6c88:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    6c8c:      	b	0x7004 <generic_rawtp_filter_arg+0x1c54>
    6c90:      	and	w8, w24, #0xffff
    6c94:      	mov	w9, #0x1fe              // =510
    6c98:      	cmp	w8, #0x100
    6c9c:      	mov	w8, #0x100              // =256
    6ca0:      	csel	w11, w9, w8, hi
    6ca4:      	and	w8, w11, #0xffff
    6ca8:      	cmp	w8, #0x100
    6cac:      	mov	w8, #0x6                // =6
    6cb0:      	cinc	w10, w8, ne
    6cb4:      	add	x8, x29, #0x10
    6cb8:      	and	w9, w10, #0xf
    6cbc:      	ldr	w8, [x8, w9, uxtw #2]
    6cc0:      	cmn	w8, #0x1
    6cc4:      	b.eq	0x7ad8 <generic_rawtp_filter_arg+0x2728>
    6cc8:      	str	w11, [sp, #0x10]
    6ccc:      	str	w8, [sp, #0x1c]
    6cd0:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6cd4:      	mov	w8, #0x1                // =1
    6cd8:      	add	x23, sp, #0x88
    6cdc:      	add	x1, sp, #0x88
    6ce0:      	str	w10, [sp, #0x28]
    6ce4:      	ldr	x0, [x0]
    6ce8:      	blr	x8
    6cec:      	str	x0, [sp, #0x20]
    6cf0:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6cf4:      	mov	w8, #0x1                // =1
    6cf8:      	add	x1, sp, #0x88
    6cfc:      	ldr	x0, [x0]
    6d00:      	blr	x8
    6d04:      	ldr	x9, [sp, #0x20]
    6d08:      	mov	x23, xzr
    6d0c:      	cbz	x9, 0x65d8 <generic_rawtp_filter_arg+0x1228>
    6d10:      	ldp	x16, x15, [sp, #0x40]
    6d14:      	mov	w2, #0x5ea0             // =24224
    6d18:      	mov	w12, #0x1               // =1
    6d1c:      	ldr	x17, [sp, #0x38]
    6d20:      	cbz	x0, 0x65e8 <generic_rawtp_filter_arg+0x1238>
    6d24:      	mov	x8, x9
    6d28:      	ldr	w9, [sp, #0x28]
    6d2c:      	mov	x23, x0
    6d30:      	cmp	w9, #0x5
    6d34:      	b.gt	0x7618 <generic_rawtp_filter_arg+0x2268>
    6d38:      	mov	x0, x8
    6d3c:      	mov	x9, x8
    6d40:      	mov	w8, #0x4                // =4
    6d44:      	mov	w1, w24
    6d48:      	mov	x2, x22
    6d4c:      	strb	w24, [x0], #0x1
    6d50:      	mov	x22, x9
    6d54:      	blr	x8
    6d58:      	ldr	w8, [sp, #0x10]
    6d5c:      	and	w8, w8, #0xffff
    6d60:      	cmp	w8, w24
    6d64:      	b.ls	0x7664 <generic_rawtp_filter_arg+0x22b4>
    6d68:      	add	x9, x22, x24
    6d6c:      	sub	w8, w8, w24
    6d70:      	add	x0, x9, #0x1
    6d74:      	and	w1, w8, #0xfff
    6d78:      	mov	w8, #0x4                // =4
    6d7c:      	b	0x765c <generic_rawtp_filter_arg+0x22ac>
    6d80:      	cmp	w9, #0xc
    6d84:      	b.eq	0x6d90 <generic_rawtp_filter_arg+0x19e0>
    6d88:      	cmp	w9, #0xa
    6d8c:      	b.ne	0x7718 <generic_rawtp_filter_arg+0x2368>
    6d90:      	ldr	x12, [x22]
    6d94:      	cmp	x12, x11
    6d98:      	mov	w12, #0x1               // =1
    6d9c:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    6da0:      	b	0x773c <generic_rawtp_filter_arg+0x238c>
    6da4:      	ldr	w9, [x29, #0x8]
    6da8:      	cmp	w9, #0xd
    6dac:      	b.lo	0x5ac8 <generic_rawtp_filter_arg+0x718>
    6db0:      	ldr	w10, [x29, #0x14]
    6db4:      	cbz	w10, 0x5ac8 <generic_rawtp_filter_arg+0x718>
    6db8:      	cmp	w10, w8
    6dbc:      	b.eq	0x5824 <generic_rawtp_filter_arg+0x474>
    6dc0:      	cmp	w9, #0x11
    6dc4:      	b.lo	0x5ac8 <generic_rawtp_filter_arg+0x718>
    6dc8:      	ldr	w10, [x29, #0x18]
    6dcc:      	cbz	w10, 0x5ac8 <generic_rawtp_filter_arg+0x718>
    6dd0:      	cmp	w10, w8
    6dd4:      	b.eq	0x5824 <generic_rawtp_filter_arg+0x474>
    6dd8:      	cmp	w9, #0x15
    6ddc:      	b.lo	0x6df4 <generic_rawtp_filter_arg+0x1a44>
    6de0:      	ldr	w9, [x29, #0x1c]
    6de4:      	cbz	w9, 0x6df4 <generic_rawtp_filter_arg+0x1a44>
    6de8:      	cmp	w9, w8
    6dec:      	cset	w23, eq
    6df0:      	b	0x6df8 <generic_rawtp_filter_arg+0x1a48>
    6df4:      	mov	x23, xzr
    6df8:      	ldr	x19, [sp, #0x30]
    6dfc:      	b	0x7c6c <generic_rawtp_filter_arg+0x28bc>
    6e00:      	ldp	w8, w11, [x29, #0x10]
    6e04:      	ldrb	w9, [x22]
    6e08:      	cmp	w8, w9
    6e0c:      	ldr	w10, [x29, #0x8]
    6e10:      	ccmp	w11, w9, #0x0, ls
    6e14:      	cset	w8, hs
    6e18:      	cmp	w10, #0x11
    6e1c:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    6e20:      	b	0x6e44 <generic_rawtp_filter_arg+0x1a94>
    6e24:      	ldp	w8, w11, [x29, #0x10]
    6e28:      	ldrh	w9, [x22]
    6e2c:      	cmp	w8, w9
    6e30:      	ldr	w10, [x29, #0x8]
    6e34:      	ccmp	w11, w9, #0x0, ls
    6e38:      	cset	w8, hs
    6e3c:      	cmp	w10, #0x11
    6e40:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    6e44:      	ldp	w11, w12, [x29, #0x18]
    6e48:      	cmp	w11, w9
    6e4c:      	ccmp	w12, w9, #0x0, ls
    6e50:      	mov	w12, #0x1               // =1
    6e54:      	csinc	w8, w8, wzr, lo
    6e58:      	cmp	w10, #0x19
    6e5c:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    6e60:      	ldp	w11, w12, [x29, #0x20]
    6e64:      	cmp	w11, w9
    6e68:      	ccmp	w12, w9, #0x0, ls
    6e6c:      	mov	w12, #0x1               // =1
    6e70:      	csinc	w8, w8, wzr, lo
    6e74:      	cmp	w10, #0x21
    6e78:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    6e7c:      	ldp	w10, w11, [x29, #0x28]
    6e80:      	cmp	w10, w9
    6e84:      	ccmp	w11, w9, #0x0, ls
    6e88:      	csinc	w8, w8, wzr, lo
    6e8c:      	b	0x7cbc <generic_rawtp_filter_arg+0x290c>
    6e90:      	mov	x19, xzr
    6e94:      	mov	w23, wzr
    6e98:      	add	x8, x29, #0x10
    6e9c:      	str	x8, [sp, #0x28]
    6ea0:      	ldr	x8, [sp, #0x28]
    6ea4:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0xc50>
    6ea8:      	add	x9, sp, #0x60
    6eac:      	add	x1, sp, #0x60
    6eb0:      	ldr	w8, [x8, x19, lsl #2]
    6eb4:      	str	w8, [sp, #0x60]
    6eb8:      	mov	w8, #0x1                // =1
    6ebc:      	ldr	x0, [x0]
    6ec0:      	blr	x8
    6ec4:      	cbz	x0, 0x8098 <generic_rawtp_filter_arg+0x2ce8>
    6ec8:      	cbz	w22, 0x6f30 <generic_rawtp_filter_arg+0x1b80>
    6ecc:      	mov	x8, xzr
    6ed0:      	mov	x9, x24
    6ed4:      	mov	x10, x22
    6ed8:      	b	0x6ef0 <generic_rawtp_filter_arg+0x1b40>
    6edc:      	add	x8, x8, #0x1
    6ee0:      	sub	x10, x10, #0x1
    6ee4:      	add	x9, x9, #0x1
    6ee8:      	cmp	x8, x22
    6eec:      	b.eq	0x6f30 <generic_rawtp_filter_arg+0x1b80>
    6ef0:      	mov	x11, xzr
    6ef4:      	nop
    6ef8:      	nop
    6efc:      	nop
    6f00:      	cmp	x10, x11
    6f04:      	b.eq	0x6edc <generic_rawtp_filter_arg+0x1b2c>
    6f08:      	ldrb	w12, [x0, x11]
    6f0c:      	cbz	w12, 0x6f2c <generic_rawtp_filter_arg+0x1b7c>
    6f10:      	cmp	x11, #0x62
    6f14:      	b.hi	0x6edc <generic_rawtp_filter_arg+0x1b2c>
    6f18:      	ldrb	w13, [x9, x11]
    6f1c:      	add	x11, x11, #0x1
    6f20:      	cmp	w13, w12
    6f24:      	b.eq	0x6f00 <generic_rawtp_filter_arg+0x1b50>
    6f28:      	b	0x6edc <generic_rawtp_filter_arg+0x1b2c>
    6f2c:      	tbz	w8, #0x1f, 0x7b4c <generic_rawtp_filter_arg+0x279c>
    6f30:      	ldr	w9, [x29, #0x8]
    6f34:      	add	w8, w23, #0xc
    6f38:      	cmp	w8, w9
    6f3c:      	b.hs	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    6f40:      	add	x19, x19, #0x1
    6f44:      	add	w23, w23, #0x4
    6f48:      	cmp	x19, #0x64
    6f4c:      	b.ne	0x6ea0 <generic_rawtp_filter_arg+0x1af0>
    6f50:      	b	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    6f54:      	and	w8, w22, #0xffff
    6f58:      	cmp	w8, #0x90
    6f5c:      	b.hi	0x743c <generic_rawtp_filter_arg+0x208c>
    6f60:      	and	w8, w22, #0xff
    6f64:      	mov	w9, #0xab               // =171
    6f68:      	tst	w22, #0xffff
    6f6c:      	mul	w8, w8, w9
    6f70:      	mov	w9, #0x18               // =24
    6f74:      	lsr	w8, w8, #12
    6f78:      	msub	w8, w8, w9, w22
    6f7c:      	b.eq	0x6f8c <generic_rawtp_filter_arg+0x1bdc>
    6f80:      	tst	w8, #0xff
    6f84:      	mov	w11, w22
    6f88:      	b.eq	0x6fa0 <generic_rawtp_filter_arg+0x1bf0>
    6f8c:      	sub	w8, w22, w8, uxtb
    6f90:      	and	w9, w8, #0xffff
    6f94:      	add	w11, w8, #0x18
    6f98:      	cmp	w9, #0x78
    6f9c:      	b.hi	0x7450 <generic_rawtp_filter_arg+0x20a0>
    6fa0:      	and	w8, w11, #0xff
    6fa4:      	mov	w9, #0xab               // =171
    6fa8:      	mul	w8, w8, w9
    6fac:      	lsr	w8, w8, #12
    6fb0:      	sub	w10, w8, #0x1
    6fb4:      	b	0x7460 <generic_rawtp_filter_arg+0x20b0>
    6fb8:      	ldrb	w10, [x22]
    6fbc:      	cmp	w9, w10
    6fc0:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    6fc4:      	ldr	w9, [x29, #0x8]
    6fc8:      	cmp	w9, #0xd
    6fcc:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    6fd0:      	ldr	w10, [x29, #0x14]
    6fd4:      	cmp	w8, #0x2
    6fd8:      	b.le	0x733c <generic_rawtp_filter_arg+0x1f8c>
    6fdc:      	sub	w11, w8, #0x3
    6fe0:      	cmp	w11, #0x2
    6fe4:      	b.hs	0x77c4 <generic_rawtp_filter_arg+0x2414>
    6fe8:      	ldrb	w11, [x22]
    6fec:      	cmp	w10, w11
    6ff0:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    6ff4:      	b	0x7888 <generic_rawtp_filter_arg+0x24d8>
    6ff8:      	ldrh	w10, [x22]
    6ffc:      	cmp	w9, w10
    7000:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7004:      	ldr	w9, [x29, #0x8]
    7008:      	cmp	w9, #0xd
    700c:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7010:      	ldr	w10, [x29, #0x14]
    7014:      	cmp	w8, #0x2
    7018:      	b.le	0x735c <generic_rawtp_filter_arg+0x1fac>
    701c:      	sub	w11, w8, #0x3
    7020:      	cmp	w11, #0x2
    7024:      	b.hs	0x77dc <generic_rawtp_filter_arg+0x242c>
    7028:      	ldrh	w11, [x22]
    702c:      	cmp	w10, w11
    7030:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    7034:      	b	0x78c4 <generic_rawtp_filter_arg+0x2514>
    7038:      	cmp	x0, #0x0
    703c:      	b	0x7320 <generic_rawtp_filter_arg+0x1f70>
    7040:      	ldr	w8, [x22]
    7044:      	cmp	w11, w8
    7048:      	b.hi	0x7054 <generic_rawtp_filter_arg+0x1ca4>
    704c:      	cmp	w8, w10
    7050:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    7054:      	ldr	w10, [x29, #0x8]
    7058:      	cmp	w10, #0x11
    705c:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    7060:      	ldp	w12, w11, [x29, #0x18]
    7064:      	mov	w13, #0x1               // =1
    7068:      	cmp	w9, #0xc
    706c:      	b.hi	0x756c <generic_rawtp_filter_arg+0x21bc>
    7070:      	lsl	w13, w13, w9
    7074:      	mov	w14, #0x1402            // =5122
    7078:      	tst	w13, w14
    707c:      	b.eq	0x756c <generic_rawtp_filter_arg+0x21bc>
    7080:      	cmp	w12, w8
    7084:      	mov	w12, #0x1               // =1
    7088:      	b.gt	0x7580 <generic_rawtp_filter_arg+0x21d0>
    708c:      	cmp	w8, w11
    7090:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    7094:      	b	0x7580 <generic_rawtp_filter_arg+0x21d0>
    7098:      	ldr	w10, [x22]
    709c:      	cmp	w11, w10
    70a0:      	ccmp	w10, w8, #0x2, ls
    70a4:      	cset	w8, ls
    70a8:      	ldr	w11, [x29, #0x8]
    70ac:      	cmp	w11, #0x11
    70b0:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    70b4:      	ldp	w13, w12, [x29, #0x18]
    70b8:      	mov	w14, #0x1               // =1
    70bc:      	cmp	w9, #0xc
    70c0:      	b.hi	0x7520 <generic_rawtp_filter_arg+0x2170>
    70c4:      	lsl	w14, w14, w9
    70c8:      	mov	w1, #0x1402             // =5122
    70cc:      	tst	w14, w1
    70d0:      	b.eq	0x7520 <generic_rawtp_filter_arg+0x2170>
    70d4:      	cmp	w13, w10
    70d8:      	ccmp	w10, w12, #0x0, le
    70dc:      	cset	w12, le
    70e0:      	b	0x752c <generic_rawtp_filter_arg+0x217c>
    70e4:      	mov	w23, #0x1               // =1
    70e8:      	b	0x65d4 <generic_rawtp_filter_arg+0x1224>
    70ec:      	cmp	x13, x10
    70f0:      	ccmp	x10, x12, #0x2, ls
    70f4:      	cset	w12, ls
    70f8:      	orr	w8, w8, w12
    70fc:      	cmp	w11, #0x29
    7100:      	b.lo	0x7a84 <generic_rawtp_filter_arg+0x26d4>
    7104:      	ldp	x13, x12, [x29, #0x30]
    7108:      	cmp	w9, #0xc
    710c:      	b.eq	0x7118 <generic_rawtp_filter_arg+0x1d68>
    7110:      	cmp	w9, #0xa
    7114:      	b.ne	0x75c0 <generic_rawtp_filter_arg+0x2210>
    7118:      	cmp	x13, x10
    711c:      	ccmp	x10, x12, #0x0, le
    7120:      	cset	w12, le
    7124:      	b	0x75cc <generic_rawtp_filter_arg+0x221c>
    7128:      	cmp	x12, x8
    712c:      	mov	w12, #0x1               // =1
    7130:      	b.hi	0x713c <generic_rawtp_filter_arg+0x1d8c>
    7134:      	cmp	x8, x11
    7138:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    713c:      	cmp	w10, #0x29
    7140:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    7144:      	ldp	x12, x11, [x29, #0x30]
    7148:      	cmp	w9, #0xc
    714c:      	b.eq	0x7158 <generic_rawtp_filter_arg+0x1da8>
    7150:      	cmp	w9, #0xa
    7154:      	b.ne	0x76d4 <generic_rawtp_filter_arg+0x2324>
    7158:      	cmp	x12, x8
    715c:      	mov	w12, #0x1               // =1
    7160:      	b.gt	0x76e8 <generic_rawtp_filter_arg+0x2338>
    7164:      	cmp	x8, x11
    7168:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    716c:      	b	0x76e8 <generic_rawtp_filter_arg+0x2338>
    7170:      	mov	x19, xzr
    7174:      	cmp	w9, #0x29
    7178:      	b.ne	0x7184 <generic_rawtp_filter_arg+0x1dd4>
    717c:      	cbz	x10, 0x7184 <generic_rawtp_filter_arg+0x1dd4>
    7180:      	ldrb	w19, [x10, #0x3a]
    7184:      	cmp	w9, #0x29
    7188:      	b.eq	0x7194 <generic_rawtp_filter_arg+0x1de4>
    718c:      	cmp	w9, #0x7
    7190:      	b.ne	0x760c <generic_rawtp_filter_arg+0x225c>
    7194:      	ldrb	w8, [x29, #0x10]
    7198:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    719c:      	add	x9, sp, #0xac
    71a0:      	add	x1, sp, #0xac
    71a4:      	str	w8, [sp, #0xac]
    71a8:      	mov	w8, #0x1                // =1
    71ac:      	ldr	x0, [x0]
    71b0:      	blr	x8
    71b4:      	cbz	x0, 0x75fc <generic_rawtp_filter_arg+0x224c>
    71b8:      	str	x19, [sp, #0x88]
    71bc:      	mov	w8, #0x1                // =1
    71c0:      	add	x9, sp, #0x88
    71c4:      	add	x1, sp, #0x88
    71c8:      	blr	x8
    71cc:      	ldr	w9, [x29, #0x4]
    71d0:      	mov	w8, wzr
    71d4:      	cmp	w9, #0x1d
    71d8:      	b.hi	0x80e4 <generic_rawtp_filter_arg+0x2d34>
    71dc:      	ldr	x19, [sp, #0x30]
    71e0:      	mov	w12, #0x1               // =1
    71e4:      	mov	w10, #0x8400            // =33792
    71e8:      	lsl	w9, w12, w9
    71ec:      	movk	w10, #0x3003, lsl #16
    71f0:      	tst	w9, w10
    71f4:      	b.ne	0x6b88 <generic_rawtp_filter_arg+0x17d8>
    71f8:      	mov	w10, #0x800             // =2048
    71fc:      	movk	w10, #0xc, lsl #16
    7200:      	tst	w9, w10
    7204:      	b.eq	0x7210 <generic_rawtp_filter_arg+0x1e60>
    7208:      	cmp	x0, #0x0
    720c:      	cset	w8, eq
    7210:      	mov	w23, w8
    7214:      	ldp	x16, x15, [sp, #0x40]
    7218:      	mov	w2, #0x5ea0             // =24224
    721c:      	ldr	x17, [sp, #0x38]
    7220:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    7224:      	ldr	w11, [x22]
    7228:      	cmp	w11, w10
    722c:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7230:      	b	0x7240 <generic_rawtp_filter_arg+0x1e90>
    7234:      	ldr	w11, [x22]
    7238:      	cmp	w11, w10
    723c:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7240:      	ldr	w10, [x29, #0x8]
    7244:      	cmp	w10, #0xd
    7248:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    724c:      	ldr	w11, [x29, #0x14]
    7250:      	cmp	w8, #0x2
    7254:      	b.le	0x7278 <generic_rawtp_filter_arg+0x1ec8>
    7258:      	sub	w12, w8, #0x3
    725c:      	cmp	w12, #0x2
    7260:      	b.hs	0x72b8 <generic_rawtp_filter_arg+0x1f08>
    7264:      	ldr	w12, [x22]
    7268:      	cmp	w12, w11
    726c:      	mov	w12, #0x1               // =1
    7270:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    7274:      	b	0x79b0 <generic_rawtp_filter_arg+0x2600>
    7278:      	cmp	w8, #0x1
    727c:      	b.eq	0x72d8 <generic_rawtp_filter_arg+0x1f28>
    7280:      	cmp	w8, #0x2
    7284:      	b.ne	0x79b0 <generic_rawtp_filter_arg+0x2600>
    7288:      	mov	w12, #0x1               // =1
    728c:      	cmp	w9, #0xc
    7290:      	b.hi	0x79a0 <generic_rawtp_filter_arg+0x25f0>
    7294:      	lsl	w12, w12, w9
    7298:      	mov	w13, #0x1402            // =5122
    729c:      	tst	w12, w13
    72a0:      	b.eq	0x79a0 <generic_rawtp_filter_arg+0x25f0>
    72a4:      	ldr	w12, [x22]
    72a8:      	cmp	w12, w11
    72ac:      	mov	w12, #0x1               // =1
    72b0:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    72b4:      	b	0x79b0 <generic_rawtp_filter_arg+0x2600>
    72b8:      	cmp	w8, #0xc
    72bc:      	mov	w12, #0x1               // =1
    72c0:      	b.ne	0x79b0 <generic_rawtp_filter_arg+0x2600>
    72c4:      	ldr	w12, [x22]
    72c8:      	tst	w12, w11
    72cc:      	mov	w12, #0x1               // =1
    72d0:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    72d4:      	b	0x79b0 <generic_rawtp_filter_arg+0x2600>
    72d8:      	mov	w12, #0x1               // =1
    72dc:      	cmp	w9, #0xc
    72e0:      	b.hi	0x798c <generic_rawtp_filter_arg+0x25dc>
    72e4:      	lsl	w12, w12, w9
    72e8:      	mov	w13, #0x1402            // =5122
    72ec:      	tst	w12, w13
    72f0:      	b.eq	0x798c <generic_rawtp_filter_arg+0x25dc>
    72f4:      	ldr	w12, [x22]
    72f8:      	cmp	w12, w11
    72fc:      	mov	w12, #0x1               // =1
    7300:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    7304:      	b	0x79b0 <generic_rawtp_filter_arg+0x2600>
    7308:      	ldr	w8, [x29, #0x4]
    730c:      	b	0x7318 <generic_rawtp_filter_arg+0x1f68>
    7310:      	ldr	w8, [x29, #0x4]
    7314:      	ldr	x19, [sp, #0x30]
    7318:      	and	w8, w8, #0xfffffffe
    731c:      	cmp	w8, #0x18
    7320:      	cset	w8, eq
    7324:      	ldp	x16, x15, [sp, #0x40]
    7328:      	mov	w2, #0x5ea0             // =24224
    732c:      	mov	w12, #0x1               // =1
    7330:      	mov	w23, w8
    7334:      	ldr	x17, [sp, #0x38]
    7338:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    733c:      	cmp	w8, #0x1
    7340:      	b.eq	0x787c <generic_rawtp_filter_arg+0x24cc>
    7344:      	cmp	w8, #0x2
    7348:      	b.ne	0x7888 <generic_rawtp_filter_arg+0x24d8>
    734c:      	ldrb	w11, [x22]
    7350:      	cmp	w10, w11
    7354:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7358:      	b	0x7888 <generic_rawtp_filter_arg+0x24d8>
    735c:      	cmp	w8, #0x1
    7360:      	b.eq	0x78b8 <generic_rawtp_filter_arg+0x2508>
    7364:      	cmp	w8, #0x2
    7368:      	b.ne	0x78c4 <generic_rawtp_filter_arg+0x2514>
    736c:      	ldrh	w11, [x22]
    7370:      	cmp	w10, w11
    7374:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7378:      	b	0x78c4 <generic_rawtp_filter_arg+0x2514>
    737c:      	strh	w24, [x0], #0x2
    7380:      	mov	w8, #0x4                // =4
    7384:      	mov	w1, w24
    7388:      	blr	x8
    738c:      	ldr	w8, [sp, #0x10]
    7390:      	and	w8, w8, #0xffff
    7394:      	cmp	w8, w24
    7398:      	b.ls	0x73b8 <generic_rawtp_filter_arg+0x2008>
    739c:      	add	x9, x22, x24
    73a0:      	sub	w8, w8, w24
    73a4:      	ldr	x2, [sp, #0x8]
    73a8:      	add	x0, x9, #0x2
    73ac:      	and	w1, w8, #0xfff
    73b0:      	mov	w8, #0x4                // =4
    73b4:      	blr	x8
    73b8:      	ldr	w8, [sp, #0x1c]
    73bc:      	cmp	w23, #0x3
    73c0:      	str	w8, [sp, #0x60]
    73c4:      	b.gt	0x7400 <generic_rawtp_filter_arg+0x2050>
    73c8:      	ldp	x16, x15, [sp, #0x40]
    73cc:      	cmp	w23, #0x1
    73d0:      	mov	w2, #0x5ea0             // =24224
    73d4:      	mov	w12, #0x1               // =1
    73d8:      	ldr	x17, [sp, #0x38]
    73dc:      	b.gt	0x7818 <generic_rawtp_filter_arg+0x2468>
    73e0:      	cbz	w23, 0x7bf8 <generic_rawtp_filter_arg+0x2848>
    73e4:      	cmp	w23, #0x1
    73e8:      	b.ne	0x5ac8 <generic_rawtp_filter_arg+0x718>
    73ec:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    73f0:      	mov	w8, #0x1                // =1
    73f4:      	add	x9, sp, #0x60
    73f8:      	ldr	x0, [x0]
    73fc:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    7400:      	ldp	x16, x15, [sp, #0x40]
    7404:      	cmp	w23, #0x5
    7408:      	mov	w2, #0x5ea0             // =24224
    740c:      	mov	w12, #0x1               // =1
    7410:      	ldr	x17, [sp, #0x38]
    7414:      	b.gt	0x783c <generic_rawtp_filter_arg+0x248c>
    7418:      	cmp	w23, #0x4
    741c:      	b.eq	0x7c0c <generic_rawtp_filter_arg+0x285c>
    7420:      	cmp	w23, #0x5
    7424:      	b.ne	0x5ac8 <generic_rawtp_filter_arg+0x718>
    7428:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    742c:      	mov	w8, #0x1                // =1
    7430:      	add	x9, sp, #0x60
    7434:      	ldr	x0, [x0]
    7438:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    743c:      	and	w8, w22, #0xffff
    7440:      	mov	w9, #0x1fe              // =510
    7444:      	cmp	w8, #0x100
    7448:      	mov	w8, #0x100              // =256
    744c:      	csel	w11, w9, w8, hi
    7450:      	and	w8, w11, #0xffff
    7454:      	cmp	w8, #0x100
    7458:      	mov	w8, #0x6                // =6
    745c:      	cinc	w10, w8, ne
    7460:      	add	x8, x29, #0x10
    7464:      	and	w9, w10, #0xf
    7468:      	ldr	w8, [x8, w9, uxtw #2]
    746c:      	cmn	w8, #0x1
    7470:      	b.eq	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    7474:      	stp	w11, w8, [sp, #0x1c]
    7478:      	str	w10, [sp, #0x28]
    747c:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7480:      	mov	w8, #0x1                // =1
    7484:      	add	x19, sp, #0x88
    7488:      	add	x1, sp, #0x88
    748c:      	ldr	x0, [x0]
    7490:      	blr	x8
    7494:      	mov	x9, x0
    7498:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    749c:      	mov	w8, #0x1                // =1
    74a0:      	ldr	x0, [x0]
    74a4:      	add	x1, sp, #0x88
    74a8:      	mov	x19, x9
    74ac:      	blr	x8
    74b0:      	mov	x23, xzr
    74b4:      	cbz	x19, 0x809c <generic_rawtp_filter_arg+0x2cec>
    74b8:      	ldp	x16, x15, [sp, #0x40]
    74bc:      	mov	w2, #0x5ea0             // =24224
    74c0:      	mov	w12, #0x1               // =1
    74c4:      	ldr	x17, [sp, #0x38]
    74c8:      	cbz	x0, 0x80ac <generic_rawtp_filter_arg+0x2cfc>
    74cc:      	ldr	w23, [sp, #0x28]
    74d0:      	str	x0, [sp, #0x10]
    74d4:      	mov	x0, x19
    74d8:      	cmp	w23, #0x5
    74dc:      	b.gt	0x7b54 <generic_rawtp_filter_arg+0x27a4>
    74e0:      	strb	w22, [x0], #0x1
    74e4:      	mov	w8, #0x4                // =4
    74e8:      	mov	w1, w22
    74ec:      	mov	x2, x24
    74f0:      	blr	x8
    74f4:      	ldr	w8, [sp, #0x1c]
    74f8:      	and	w8, w8, #0xffff
    74fc:      	cmp	w8, w22
    7500:      	b.ls	0x7b94 <generic_rawtp_filter_arg+0x27e4>
    7504:      	add	x9, x19, x22
    7508:      	sub	w8, w8, w22
    750c:      	ldr	x2, [sp, #0x10]
    7510:      	add	x0, x9, #0x1
    7514:      	and	w1, w8, #0xfff
    7518:      	mov	w8, #0x4                // =4
    751c:      	b	0x7b90 <generic_rawtp_filter_arg+0x27e0>
    7520:      	cmp	w13, w10
    7524:      	ccmp	w10, w12, #0x2, ls
    7528:      	cset	w12, ls
    752c:      	orr	w8, w8, w12
    7530:      	cmp	w11, #0x19
    7534:      	mov	w12, #0x1               // =1
    7538:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    753c:      	ldp	w13, w12, [x29, #0x20]
    7540:      	mov	w14, #0x1               // =1
    7544:      	cmp	w9, #0xc
    7548:      	b.hi	0x78f4 <generic_rawtp_filter_arg+0x2544>
    754c:      	lsl	w14, w14, w9
    7550:      	mov	w1, #0x1402             // =5122
    7554:      	tst	w14, w1
    7558:      	b.eq	0x78f4 <generic_rawtp_filter_arg+0x2544>
    755c:      	cmp	w13, w10
    7560:      	ccmp	w10, w12, #0x0, le
    7564:      	cset	w12, le
    7568:      	b	0x7900 <generic_rawtp_filter_arg+0x2550>
    756c:      	cmp	w12, w8
    7570:      	mov	w12, #0x1               // =1
    7574:      	b.hi	0x7580 <generic_rawtp_filter_arg+0x21d0>
    7578:      	cmp	w8, w11
    757c:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    7580:      	cmp	w10, #0x19
    7584:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    7588:      	ldp	w12, w11, [x29, #0x20]
    758c:      	mov	w13, #0x1               // =1
    7590:      	cmp	w9, #0xc
    7594:      	b.hi	0x7940 <generic_rawtp_filter_arg+0x2590>
    7598:      	lsl	w13, w13, w9
    759c:      	mov	w14, #0x1402            // =5122
    75a0:      	tst	w13, w14
    75a4:      	b.eq	0x7940 <generic_rawtp_filter_arg+0x2590>
    75a8:      	cmp	w12, w8
    75ac:      	mov	w12, #0x1               // =1
    75b0:      	b.gt	0x7954 <generic_rawtp_filter_arg+0x25a4>
    75b4:      	cmp	w8, w11
    75b8:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    75bc:      	b	0x7954 <generic_rawtp_filter_arg+0x25a4>
    75c0:      	cmp	x13, x10
    75c4:      	ccmp	x10, x12, #0x2, ls
    75c8:      	cset	w12, ls
    75cc:      	orr	w8, w8, w12
    75d0:      	cmp	w11, #0x39
    75d4:      	b.lo	0x7a84 <generic_rawtp_filter_arg+0x26d4>
    75d8:      	ldp	x12, x11, [x29, #0x40]
    75dc:      	cmp	w9, #0xc
    75e0:      	b.eq	0x75ec <generic_rawtp_filter_arg+0x223c>
    75e4:      	cmp	w9, #0xa
    75e8:      	b.ne	0x7a74 <generic_rawtp_filter_arg+0x26c4>
    75ec:      	cmp	x12, x10
    75f0:      	ccmp	x10, x11, #0x0, le
    75f4:      	cset	w9, le
    75f8:      	b	0x7a80 <generic_rawtp_filter_arg+0x26d0>
    75fc:      	ldr	x19, [sp, #0x30]
    7600:      	mov	x23, xzr
    7604:      	mov	w12, #0x1               // =1
    7608:      	b	0x7214 <generic_rawtp_filter_arg+0x1e64>
    760c:      	ldr	x19, [sp, #0x30]
    7610:      	mov	x23, xzr
    7614:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    7618:      	mov	x0, x8
    761c:      	mov	x9, x8
    7620:      	mov	w8, #0x4                // =4
    7624:      	mov	w1, w24
    7628:      	mov	x2, x22
    762c:      	strh	w24, [x0], #0x2
    7630:      	mov	x22, x9
    7634:      	blr	x8
    7638:      	ldr	w8, [sp, #0x10]
    763c:      	and	w8, w8, #0xffff
    7640:      	cmp	w8, w24
    7644:      	b.ls	0x7664 <generic_rawtp_filter_arg+0x22b4>
    7648:      	add	x9, x22, x24
    764c:      	sub	w8, w8, w24
    7650:      	add	x0, x9, #0x2
    7654:      	and	w1, w8, #0xfff
    7658:      	mov	w8, #0x4                // =4
    765c:      	mov	x2, x23
    7660:      	blr	x8
    7664:      	ldr	w8, [sp, #0x1c]
    7668:      	str	w8, [sp, #0x60]
    766c:      	ldr	w8, [sp, #0x28]
    7670:      	cmp	w8, #0x3
    7674:      	b.gt	0x76a4 <generic_rawtp_filter_arg+0x22f4>
    7678:      	cmp	w8, #0x1
    767c:      	mov	w12, #0x1               // =1
    7680:      	b.gt	0x7a90 <generic_rawtp_filter_arg+0x26e0>
    7684:      	cbz	w8, 0x7dcc <generic_rawtp_filter_arg+0x2a1c>
    7688:      	cmp	w8, #0x1
    768c:      	b.ne	0x7ad8 <generic_rawtp_filter_arg+0x2728>
    7690:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7694:      	mov	w8, #0x1                // =1
    7698:      	add	x9, sp, #0x60
    769c:      	ldr	x0, [x0]
    76a0:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    76a4:      	cmp	w8, #0x5
    76a8:      	mov	w12, #0x1               // =1
    76ac:      	b.gt	0x7ab4 <generic_rawtp_filter_arg+0x2704>
    76b0:      	cmp	w8, #0x4
    76b4:      	b.eq	0x7de0 <generic_rawtp_filter_arg+0x2a30>
    76b8:      	cmp	w8, #0x5
    76bc:      	b.ne	0x7ad8 <generic_rawtp_filter_arg+0x2728>
    76c0:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    76c4:      	mov	w8, #0x1                // =1
    76c8:      	add	x9, sp, #0x60
    76cc:      	ldr	x0, [x0]
    76d0:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    76d4:      	cmp	x12, x8
    76d8:      	mov	w12, #0x1               // =1
    76dc:      	b.hi	0x76e8 <generic_rawtp_filter_arg+0x2338>
    76e0:      	cmp	x8, x11
    76e4:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    76e8:      	cmp	w10, #0x39
    76ec:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    76f0:      	ldp	x11, x10, [x29, #0x40]
    76f4:      	cmp	w9, #0xc
    76f8:      	b.eq	0x7704 <generic_rawtp_filter_arg+0x2354>
    76fc:      	cmp	w9, #0xa
    7700:      	b.ne	0x7af8 <generic_rawtp_filter_arg+0x2748>
    7704:      	cmp	x11, x8
    7708:      	b.gt	0x54ac <generic_rawtp_filter_arg+0xfc>
    770c:      	cmp	x8, x10
    7710:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    7714:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    7718:      	ldr	x12, [x22]
    771c:      	cmp	x12, x11
    7720:      	mov	w12, #0x1               // =1
    7724:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7728:      	b	0x773c <generic_rawtp_filter_arg+0x238c>
    772c:      	ldr	x12, [x22]
    7730:      	cmp	x12, x11
    7734:      	mov	w12, #0x1               // =1
    7738:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    773c:      	cmp	w10, #0x19
    7740:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7744:      	ldr	x11, [x29, #0x20]
    7748:      	cmp	w8, #0x2
    774c:      	b.le	0x7770 <generic_rawtp_filter_arg+0x23c0>
    7750:      	sub	w12, w8, #0x3
    7754:      	cmp	w12, #0x2
    7758:      	b.hs	0x77a4 <generic_rawtp_filter_arg+0x23f4>
    775c:      	ldr	x12, [x22]
    7760:      	cmp	x12, x11
    7764:      	mov	w12, #0x1               // =1
    7768:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    776c:      	b	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    7770:      	cmp	w8, #0x1
    7774:      	b.eq	0x77f4 <generic_rawtp_filter_arg+0x2444>
    7778:      	cmp	w8, #0x2
    777c:      	b.ne	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    7780:      	cmp	w9, #0xc
    7784:      	b.eq	0x7790 <generic_rawtp_filter_arg+0x23e0>
    7788:      	cmp	w9, #0xa
    778c:      	b.ne	0x7cd8 <generic_rawtp_filter_arg+0x2928>
    7790:      	ldr	x12, [x22]
    7794:      	cmp	x12, x11
    7798:      	mov	w12, #0x1               // =1
    779c:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    77a0:      	b	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    77a4:      	cmp	w8, #0xc
    77a8:      	mov	w12, #0x1               // =1
    77ac:      	b.ne	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    77b0:      	ldr	x12, [x22]
    77b4:      	tst	x12, x11
    77b8:      	mov	w12, #0x1               // =1
    77bc:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    77c0:      	b	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    77c4:      	cmp	w8, #0xc
    77c8:      	b.ne	0x7888 <generic_rawtp_filter_arg+0x24d8>
    77cc:      	ldrb	w11, [x22]
    77d0:      	tst	w10, w11
    77d4:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    77d8:      	b	0x7888 <generic_rawtp_filter_arg+0x24d8>
    77dc:      	cmp	w8, #0xc
    77e0:      	b.ne	0x78c4 <generic_rawtp_filter_arg+0x2514>
    77e4:      	ldrh	w11, [x22]
    77e8:      	tst	w10, w11
    77ec:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    77f0:      	b	0x78c4 <generic_rawtp_filter_arg+0x2514>
    77f4:      	cmp	w9, #0xc
    77f8:      	b.eq	0x7804 <generic_rawtp_filter_arg+0x2454>
    77fc:      	cmp	w9, #0xa
    7800:      	b.ne	0x7cc4 <generic_rawtp_filter_arg+0x2914>
    7804:      	ldr	x12, [x22]
    7808:      	cmp	x12, x11
    780c:      	mov	w12, #0x1               // =1
    7810:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    7814:      	b	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    7818:      	cmp	w23, #0x2
    781c:      	b.eq	0x7c20 <generic_rawtp_filter_arg+0x2870>
    7820:      	cmp	w23, #0x3
    7824:      	b.ne	0x5ac8 <generic_rawtp_filter_arg+0x718>
    7828:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    782c:      	mov	w8, #0x1                // =1
    7830:      	add	x9, sp, #0x60
    7834:      	ldr	x0, [x0]
    7838:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    783c:      	cmp	w23, #0x6
    7840:      	b.eq	0x7c34 <generic_rawtp_filter_arg+0x2884>
    7844:      	cmp	w23, #0x7
    7848:      	b.ne	0x5ac8 <generic_rawtp_filter_arg+0x718>
    784c:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7850:      	mov	w8, #0x1                // =1
    7854:      	add	x9, sp, #0x60
    7858:      	ldr	x0, [x0]
    785c:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    7860:      	mov	x23, xzr
    7864:      	b	0x786c <generic_rawtp_filter_arg+0x24bc>
    7868:      	mov	w23, #0x1               // =1
    786c:      	mov	w12, #0x1               // =1
    7870:      	ldp	x16, x15, [sp, #0x40]
    7874:      	mov	w2, #0x5ea0             // =24224
    7878:      	b	0x80a8 <generic_rawtp_filter_arg+0x2cf8>
    787c:      	ldrb	w11, [x22]
    7880:      	cmp	w10, w11
    7884:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7888:      	cmp	w9, #0x11
    788c:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7890:      	ldr	w10, [x29, #0x18]
    7894:      	cmp	w8, #0x2
    7898:      	b.le	0x7b0c <generic_rawtp_filter_arg+0x275c>
    789c:      	sub	w11, w8, #0x3
    78a0:      	cmp	w11, #0x2
    78a4:      	b.hs	0x7d68 <generic_rawtp_filter_arg+0x29b8>
    78a8:      	ldrb	w11, [x22]
    78ac:      	cmp	w10, w11
    78b0:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    78b4:      	b	0x7e98 <generic_rawtp_filter_arg+0x2ae8>
    78b8:      	ldrh	w11, [x22]
    78bc:      	cmp	w10, w11
    78c0:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    78c4:      	cmp	w9, #0x11
    78c8:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    78cc:      	ldr	w10, [x29, #0x18]
    78d0:      	cmp	w8, #0x2
    78d4:      	b.le	0x7b2c <generic_rawtp_filter_arg+0x277c>
    78d8:      	sub	w11, w8, #0x3
    78dc:      	cmp	w11, #0x2
    78e0:      	b.hs	0x7d80 <generic_rawtp_filter_arg+0x29d0>
    78e4:      	ldrh	w11, [x22]
    78e8:      	cmp	w10, w11
    78ec:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    78f0:      	b	0x7edc <generic_rawtp_filter_arg+0x2b2c>
    78f4:      	cmp	w13, w10
    78f8:      	ccmp	w10, w12, #0x2, ls
    78fc:      	cset	w12, ls
    7900:      	orr	w8, w8, w12
    7904:      	cmp	w11, #0x21
    7908:      	mov	w12, #0x1               // =1
    790c:      	b.lo	0x7cbc <generic_rawtp_filter_arg+0x290c>
    7910:      	ldp	w12, w11, [x29, #0x28]
    7914:      	mov	w13, #0x1               // =1
    7918:      	cmp	w9, #0xc
    791c:      	b.hi	0x7ca8 <generic_rawtp_filter_arg+0x28f8>
    7920:      	lsl	w9, w13, w9
    7924:      	mov	w13, #0x1402            // =5122
    7928:      	tst	w9, w13
    792c:      	b.eq	0x7ca8 <generic_rawtp_filter_arg+0x28f8>
    7930:      	cmp	w12, w10
    7934:      	ccmp	w10, w11, #0x0, le
    7938:      	cset	w9, le
    793c:      	b	0x7cb4 <generic_rawtp_filter_arg+0x2904>
    7940:      	cmp	w12, w8
    7944:      	mov	w12, #0x1               // =1
    7948:      	b.hi	0x7954 <generic_rawtp_filter_arg+0x25a4>
    794c:      	cmp	w8, w11
    7950:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    7954:      	cmp	w10, #0x21
    7958:      	b.lo	0x54ac <generic_rawtp_filter_arg+0xfc>
    795c:      	ldp	w11, w10, [x29, #0x28]
    7960:      	cmp	w9, #0xc
    7964:      	b.hi	0x7d98 <generic_rawtp_filter_arg+0x29e8>
    7968:      	lsl	w9, w12, w9
    796c:      	mov	w13, #0x1402            // =5122
    7970:      	tst	w9, w13
    7974:      	b.eq	0x7d98 <generic_rawtp_filter_arg+0x29e8>
    7978:      	cmp	w11, w8
    797c:      	b.gt	0x54ac <generic_rawtp_filter_arg+0xfc>
    7980:      	cmp	w8, w10
    7984:      	b.le	0x5648 <generic_rawtp_filter_arg+0x298>
    7988:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    798c:      	ldr	w12, [x22]
    7990:      	cmp	w12, w11
    7994:      	mov	w12, #0x1               // =1
    7998:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    799c:      	b	0x79b0 <generic_rawtp_filter_arg+0x2600>
    79a0:      	ldr	w12, [x22]
    79a4:      	cmp	w12, w11
    79a8:      	mov	w12, #0x1               // =1
    79ac:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    79b0:      	cmp	w10, #0x11
    79b4:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    79b8:      	ldr	w11, [x29, #0x18]
    79bc:      	cmp	w8, #0x2
    79c0:      	b.le	0x79e4 <generic_rawtp_filter_arg+0x2634>
    79c4:      	sub	w12, w8, #0x3
    79c8:      	cmp	w12, #0x2
    79cc:      	b.hs	0x7a24 <generic_rawtp_filter_arg+0x2674>
    79d0:      	ldr	w12, [x22]
    79d4:      	cmp	w12, w11
    79d8:      	mov	w12, #0x1               // =1
    79dc:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    79e0:      	b	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    79e4:      	cmp	w8, #0x1
    79e8:      	b.eq	0x7a44 <generic_rawtp_filter_arg+0x2694>
    79ec:      	cmp	w8, #0x2
    79f0:      	b.ne	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    79f4:      	mov	w12, #0x1               // =1
    79f8:      	cmp	w9, #0xc
    79fc:      	b.hi	0x7f28 <generic_rawtp_filter_arg+0x2b78>
    7a00:      	lsl	w12, w12, w9
    7a04:      	mov	w13, #0x1402            // =5122
    7a08:      	tst	w12, w13
    7a0c:      	b.eq	0x7f28 <generic_rawtp_filter_arg+0x2b78>
    7a10:      	ldr	w12, [x22]
    7a14:      	cmp	w12, w11
    7a18:      	mov	w12, #0x1               // =1
    7a1c:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    7a20:      	b	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    7a24:      	cmp	w8, #0xc
    7a28:      	mov	w12, #0x1               // =1
    7a2c:      	b.ne	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    7a30:      	ldr	w12, [x22]
    7a34:      	tst	w12, w11
    7a38:      	mov	w12, #0x1               // =1
    7a3c:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    7a40:      	b	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    7a44:      	mov	w12, #0x1               // =1
    7a48:      	cmp	w9, #0xc
    7a4c:      	b.hi	0x7f14 <generic_rawtp_filter_arg+0x2b64>
    7a50:      	lsl	w12, w12, w9
    7a54:      	mov	w13, #0x1402            // =5122
    7a58:      	tst	w12, w13
    7a5c:      	b.eq	0x7f14 <generic_rawtp_filter_arg+0x2b64>
    7a60:      	ldr	w12, [x22]
    7a64:      	cmp	w12, w11
    7a68:      	mov	w12, #0x1               // =1
    7a6c:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    7a70:      	b	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    7a74:      	cmp	x12, x10
    7a78:      	ccmp	x10, x11, #0x2, ls
    7a7c:      	cset	w9, ls
    7a80:      	orr	w8, w8, w9
    7a84:      	mov	w12, #0x1               // =1
    7a88:      	tbz	w8, #0x0, 0x5648 <generic_rawtp_filter_arg+0x298>
    7a8c:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    7a90:      	cmp	w8, #0x2
    7a94:      	b.eq	0x7df4 <generic_rawtp_filter_arg+0x2a44>
    7a98:      	cmp	w8, #0x3
    7a9c:      	b.ne	0x7ad8 <generic_rawtp_filter_arg+0x2728>
    7aa0:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7aa4:      	mov	w8, #0x1                // =1
    7aa8:      	add	x9, sp, #0x60
    7aac:      	ldr	x0, [x0]
    7ab0:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    7ab4:      	cmp	w8, #0x6
    7ab8:      	b.eq	0x7e08 <generic_rawtp_filter_arg+0x2a58>
    7abc:      	cmp	w8, #0x7
    7ac0:      	b.ne	0x7ad8 <generic_rawtp_filter_arg+0x2728>
    7ac4:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7ac8:      	mov	w8, #0x1                // =1
    7acc:      	add	x9, sp, #0x60
    7ad0:      	ldr	x0, [x0]
    7ad4:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    7ad8:      	ldp	x16, x15, [sp, #0x40]
    7adc:      	mov	x23, xzr
    7ae0:      	mov	w2, #0x5ea0             // =24224
    7ae4:      	ldr	x17, [sp, #0x38]
    7ae8:      	ldr	w8, [x29, #0x4]
    7aec:      	cmp	w8, #0x25
    7af0:      	b.ls	0x65f4 <generic_rawtp_filter_arg+0x1244>
    7af4:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    7af8:      	cmp	x11, x8
    7afc:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    7b00:      	cmp	x8, x10
    7b04:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    7b08:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    7b0c:      	cmp	w8, #0x1
    7b10:      	b.eq	0x7e8c <generic_rawtp_filter_arg+0x2adc>
    7b14:      	cmp	w8, #0x2
    7b18:      	b.ne	0x7e98 <generic_rawtp_filter_arg+0x2ae8>
    7b1c:      	ldrb	w11, [x22]
    7b20:      	cmp	w10, w11
    7b24:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7b28:      	b	0x7e98 <generic_rawtp_filter_arg+0x2ae8>
    7b2c:      	cmp	w8, #0x1
    7b30:      	b.eq	0x7ed0 <generic_rawtp_filter_arg+0x2b20>
    7b34:      	cmp	w8, #0x2
    7b38:      	b.ne	0x7edc <generic_rawtp_filter_arg+0x2b2c>
    7b3c:      	ldrh	w11, [x22]
    7b40:      	cmp	w10, w11
    7b44:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7b48:      	b	0x7edc <generic_rawtp_filter_arg+0x2b2c>
    7b4c:      	mov	w23, #0x1               // =1
    7b50:      	b	0x809c <generic_rawtp_filter_arg+0x2cec>
    7b54:      	strh	w22, [x0], #0x2
    7b58:      	mov	w8, #0x4                // =4
    7b5c:      	mov	w1, w22
    7b60:      	mov	x2, x24
    7b64:      	blr	x8
    7b68:      	ldr	w8, [sp, #0x1c]
    7b6c:      	and	w8, w8, #0xffff
    7b70:      	cmp	w8, w22
    7b74:      	b.ls	0x7b94 <generic_rawtp_filter_arg+0x27e4>
    7b78:      	add	x9, x19, x22
    7b7c:      	sub	w8, w8, w22
    7b80:      	ldr	x2, [sp, #0x10]
    7b84:      	add	x0, x9, #0x2
    7b88:      	and	w1, w8, #0xfff
    7b8c:      	mov	w8, #0x4                // =4
    7b90:      	blr	x8
    7b94:      	ldr	w8, [sp, #0x20]
    7b98:      	cmp	w23, #0x3
    7b9c:      	str	w8, [sp, #0x60]
    7ba0:      	b.gt	0x7bcc <generic_rawtp_filter_arg+0x281c>
    7ba4:      	cmp	w23, #0x1
    7ba8:      	b.gt	0x7e44 <generic_rawtp_filter_arg+0x2a94>
    7bac:      	cbz	w23, 0x8028 <generic_rawtp_filter_arg+0x2c78>
    7bb0:      	cmp	w23, #0x1
    7bb4:      	b.ne	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    7bb8:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7bbc:      	mov	w8, #0x1                // =1
    7bc0:      	add	x9, sp, #0x60
    7bc4:      	ldr	x0, [x0]
    7bc8:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    7bcc:      	cmp	w23, #0x5
    7bd0:      	b.gt	0x7e68 <generic_rawtp_filter_arg+0x2ab8>
    7bd4:      	cmp	w23, #0x4
    7bd8:      	b.eq	0x803c <generic_rawtp_filter_arg+0x2c8c>
    7bdc:      	cmp	w23, #0x5
    7be0:      	b.ne	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    7be4:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7be8:      	mov	w8, #0x1                // =1
    7bec:      	add	x9, sp, #0x60
    7bf0:      	ldr	x0, [x0]
    7bf4:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    7bf8:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7bfc:      	mov	w8, #0x1                // =1
    7c00:      	add	x9, sp, #0x60
    7c04:      	ldr	x0, [x0]
    7c08:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    7c0c:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7c10:      	mov	w8, #0x1                // =1
    7c14:      	add	x9, sp, #0x60
    7c18:      	ldr	x0, [x0]
    7c1c:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    7c20:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7c24:      	mov	w8, #0x1                // =1
    7c28:      	add	x9, sp, #0x60
    7c2c:      	ldr	x0, [x0]
    7c30:      	b	0x7c44 <generic_rawtp_filter_arg+0x2894>
    7c34:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7c38:      	mov	w8, #0x1                // =1
    7c3c:      	add	x9, sp, #0x60
    7c40:      	ldr	x0, [x0]
    7c44:      	add	x1, sp, #0x60
    7c48:      	blr	x8
    7c4c:      	cbz	x0, 0x7c68 <generic_rawtp_filter_arg+0x28b8>
    7c50:      	mov	w8, #0x1                // =1
    7c54:      	mov	x1, x22
    7c58:      	blr	x8
    7c5c:      	cmp	x0, #0x0
    7c60:      	cset	w23, ne
    7c64:      	b	0x7c6c <generic_rawtp_filter_arg+0x28bc>
    7c68:      	mov	x23, xzr
    7c6c:      	ldp	x16, x15, [sp, #0x40]
    7c70:      	mov	w2, #0x5ea0             // =24224
    7c74:      	mov	w12, #0x1               // =1
    7c78:      	ldr	x17, [sp, #0x38]
    7c7c:      	ldr	w8, [x29, #0x4]
    7c80:      	cmp	w8, #0x25
    7c84:      	b.hi	0x5644 <generic_rawtp_filter_arg+0x294>
    7c88:      	mov	x9, #0x50               // =80
    7c8c:      	lsl	x8, x12, x8
    7c90:      	movk	x9, #0xc00, lsl #16
    7c94:      	movk	x9, #0x20, lsl #32
    7c98:      	tst	x8, x9
    7c9c:      	b.eq	0x5644 <generic_rawtp_filter_arg+0x294>
    7ca0:      	eor	x23, x23, #0x1
    7ca4:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    7ca8:      	cmp	w12, w10
    7cac:      	ccmp	w10, w11, #0x2, ls
    7cb0:      	cset	w9, ls
    7cb4:      	orr	w8, w8, w9
    7cb8:      	mov	w12, #0x1               // =1
    7cbc:      	tbz	w8, #0x0, 0x5648 <generic_rawtp_filter_arg+0x298>
    7cc0:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    7cc4:      	ldr	x12, [x22]
    7cc8:      	cmp	x12, x11
    7ccc:      	mov	w12, #0x1               // =1
    7cd0:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7cd4:      	b	0x7ce8 <generic_rawtp_filter_arg+0x2938>
    7cd8:      	ldr	x12, [x22]
    7cdc:      	cmp	x12, x11
    7ce0:      	mov	w12, #0x1               // =1
    7ce4:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7ce8:      	cmp	w10, #0x21
    7cec:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7cf0:      	ldr	x10, [x29, #0x28]
    7cf4:      	cmp	w8, #0x2
    7cf8:      	b.le	0x7d28 <generic_rawtp_filter_arg+0x2978>
    7cfc:      	sub	w9, w8, #0x3
    7d00:      	cmp	w9, #0x2
    7d04:      	b.lo	0x7d58 <generic_rawtp_filter_arg+0x29a8>
    7d08:      	cmp	w8, #0x6
    7d0c:      	b.eq	0x5648 <generic_rawtp_filter_arg+0x298>
    7d10:      	cmp	w8, #0xc
    7d14:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7d18:      	ldr	x9, [x22]
    7d1c:      	tst	x9, x10
    7d20:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    7d24:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7d28:      	cmp	w8, #0x1
    7d2c:      	b.eq	0x7dac <generic_rawtp_filter_arg+0x29fc>
    7d30:      	cmp	w8, #0x2
    7d34:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7d38:      	cmp	w9, #0xc
    7d3c:      	b.eq	0x7d48 <generic_rawtp_filter_arg+0x2998>
    7d40:      	cmp	w9, #0xa
    7d44:      	b.ne	0x80f0 <generic_rawtp_filter_arg+0x2d40>
    7d48:      	ldr	x9, [x22]
    7d4c:      	cmp	x9, x10
    7d50:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    7d54:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7d58:      	ldr	x9, [x22]
    7d5c:      	cmp	x9, x10
    7d60:      	b.ne	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7d64:      	b	0x563c <generic_rawtp_filter_arg+0x28c>
    7d68:      	cmp	w8, #0xc
    7d6c:      	b.ne	0x7e98 <generic_rawtp_filter_arg+0x2ae8>
    7d70:      	ldrb	w11, [x22]
    7d74:      	tst	w10, w11
    7d78:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    7d7c:      	b	0x7e98 <generic_rawtp_filter_arg+0x2ae8>
    7d80:      	cmp	w8, #0xc
    7d84:      	b.ne	0x7edc <generic_rawtp_filter_arg+0x2b2c>
    7d88:      	ldrh	w11, [x22]
    7d8c:      	tst	w10, w11
    7d90:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    7d94:      	b	0x7edc <generic_rawtp_filter_arg+0x2b2c>
    7d98:      	cmp	w11, w8
    7d9c:      	b.hi	0x54ac <generic_rawtp_filter_arg+0xfc>
    7da0:      	cmp	w8, w10
    7da4:      	b.ls	0x5648 <generic_rawtp_filter_arg+0x298>
    7da8:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    7dac:      	cmp	w9, #0xc
    7db0:      	b.eq	0x7dbc <generic_rawtp_filter_arg+0x2a0c>
    7db4:      	cmp	w9, #0xa
    7db8:      	b.ne	0x8100 <generic_rawtp_filter_arg+0x2d50>
    7dbc:      	ldr	x9, [x22]
    7dc0:      	cmp	x9, x10
    7dc4:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    7dc8:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7dcc:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7dd0:      	mov	w8, #0x1                // =1
    7dd4:      	add	x9, sp, #0x60
    7dd8:      	ldr	x0, [x0]
    7ddc:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    7de0:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7de4:      	mov	w8, #0x1                // =1
    7de8:      	add	x9, sp, #0x60
    7dec:      	ldr	x0, [x0]
    7df0:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    7df4:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7df8:      	mov	w8, #0x1                // =1
    7dfc:      	add	x9, sp, #0x60
    7e00:      	ldr	x0, [x0]
    7e04:      	b	0x7e18 <generic_rawtp_filter_arg+0x2a68>
    7e08:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7e0c:      	mov	w8, #0x1                // =1
    7e10:      	add	x9, sp, #0x60
    7e14:      	ldr	x0, [x0]
    7e18:      	add	x1, sp, #0x60
    7e1c:      	blr	x8
    7e20:      	cbz	x0, 0x7e3c <generic_rawtp_filter_arg+0x2a8c>
    7e24:      	mov	w8, #0x1                // =1
    7e28:      	mov	x1, x22
    7e2c:      	blr	x8
    7e30:      	cmp	x0, #0x0
    7e34:      	cset	w23, ne
    7e38:      	b	0x65d8 <generic_rawtp_filter_arg+0x1228>
    7e3c:      	mov	x23, xzr
    7e40:      	b	0x65d8 <generic_rawtp_filter_arg+0x1228>
    7e44:      	cmp	w23, #0x2
    7e48:      	b.eq	0x8050 <generic_rawtp_filter_arg+0x2ca0>
    7e4c:      	cmp	w23, #0x3
    7e50:      	b.ne	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    7e54:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7e58:      	mov	w8, #0x1                // =1
    7e5c:      	add	x9, sp, #0x60
    7e60:      	ldr	x0, [x0]
    7e64:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    7e68:      	cmp	w23, #0x6
    7e6c:      	b.eq	0x8064 <generic_rawtp_filter_arg+0x2cb4>
    7e70:      	cmp	w23, #0x7
    7e74:      	b.ne	0x8098 <generic_rawtp_filter_arg+0x2ce8>
    7e78:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1c50>
    7e7c:      	mov	w8, #0x1                // =1
    7e80:      	add	x9, sp, #0x60
    7e84:      	ldr	x0, [x0]
    7e88:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    7e8c:      	ldrb	w11, [x22]
    7e90:      	cmp	w10, w11
    7e94:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7e98:      	cmp	w9, #0x15
    7e9c:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7ea0:      	ldr	w9, [x29, #0x1c]
    7ea4:      	cmp	w8, #0x2
    7ea8:      	b.le	0x7fe0 <generic_rawtp_filter_arg+0x2c30>
    7eac:      	sub	w10, w8, #0x3
    7eb0:      	cmp	w10, #0x2
    7eb4:      	b.lo	0x8010 <generic_rawtp_filter_arg+0x2c60>
    7eb8:      	cmp	w8, #0x6
    7ebc:      	b.eq	0x5648 <generic_rawtp_filter_arg+0x298>
    7ec0:      	cmp	w8, #0xc
    7ec4:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7ec8:      	ldrb	w10, [x22]
    7ecc:      	b	0x7f6c <generic_rawtp_filter_arg+0x2bbc>
    7ed0:      	ldrh	w11, [x22]
    7ed4:      	cmp	w10, w11
    7ed8:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7edc:      	cmp	w9, #0x15
    7ee0:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7ee4:      	ldr	w9, [x29, #0x1c]
    7ee8:      	cmp	w8, #0x2
    7eec:      	b.le	0x7ff8 <generic_rawtp_filter_arg+0x2c48>
    7ef0:      	sub	w10, w8, #0x3
    7ef4:      	cmp	w10, #0x2
    7ef8:      	b.lo	0x8018 <generic_rawtp_filter_arg+0x2c68>
    7efc:      	cmp	w8, #0x6
    7f00:      	b.eq	0x5648 <generic_rawtp_filter_arg+0x298>
    7f04:      	cmp	w8, #0xc
    7f08:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7f0c:      	ldrh	w10, [x22]
    7f10:      	b	0x7f6c <generic_rawtp_filter_arg+0x2bbc>
    7f14:      	ldr	w12, [x22]
    7f18:      	cmp	w12, w11
    7f1c:      	mov	w12, #0x1               // =1
    7f20:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    7f24:      	b	0x7f38 <generic_rawtp_filter_arg+0x2b88>
    7f28:      	ldr	w12, [x22]
    7f2c:      	cmp	w12, w11
    7f30:      	mov	w12, #0x1               // =1
    7f34:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    7f38:      	cmp	w10, #0x15
    7f3c:      	b.lo	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7f40:      	ldr	w10, [x29, #0x1c]
    7f44:      	cmp	w8, #0x2
    7f48:      	b.le	0x7f78 <generic_rawtp_filter_arg+0x2bc8>
    7f4c:      	sub	w9, w8, #0x3
    7f50:      	cmp	w9, #0x2
    7f54:      	b.lo	0x7fb0 <generic_rawtp_filter_arg+0x2c00>
    7f58:      	cmp	w8, #0x6
    7f5c:      	b.eq	0x5648 <generic_rawtp_filter_arg+0x298>
    7f60:      	cmp	w8, #0xc
    7f64:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7f68:      	ldr	w9, [x22]
    7f6c:      	tst	w9, w10
    7f70:      	b.ne	0x5648 <generic_rawtp_filter_arg+0x298>
    7f74:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7f78:      	cmp	w8, #0x1
    7f7c:      	b.eq	0x7fb8 <generic_rawtp_filter_arg+0x2c08>
    7f80:      	cmp	w8, #0x2
    7f84:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7f88:      	cmp	w9, #0xc
    7f8c:      	b.hi	0x8120 <generic_rawtp_filter_arg+0x2d70>
    7f90:      	lsl	w9, w12, w9
    7f94:      	mov	w11, #0x1402            // =5122
    7f98:      	tst	w9, w11
    7f9c:      	b.eq	0x8120 <generic_rawtp_filter_arg+0x2d70>
    7fa0:      	ldr	w9, [x22]
    7fa4:      	cmp	w9, w10
    7fa8:      	b.lt	0x5648 <generic_rawtp_filter_arg+0x298>
    7fac:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7fb0:      	ldr	w9, [x22]
    7fb4:      	b	0x801c <generic_rawtp_filter_arg+0x2c6c>
    7fb8:      	cmp	w9, #0xc
    7fbc:      	b.hi	0x8130 <generic_rawtp_filter_arg+0x2d80>
    7fc0:      	lsl	w9, w12, w9
    7fc4:      	mov	w11, #0x1402            // =5122
    7fc8:      	tst	w9, w11
    7fcc:      	b.eq	0x8130 <generic_rawtp_filter_arg+0x2d80>
    7fd0:      	ldr	w9, [x22]
    7fd4:      	cmp	w9, w10
    7fd8:      	b.gt	0x5648 <generic_rawtp_filter_arg+0x298>
    7fdc:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    7fe0:      	cmp	w8, #0x1
    7fe4:      	b.eq	0x8110 <generic_rawtp_filter_arg+0x2d60>
    7fe8:      	cmp	w8, #0x2
    7fec:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    7ff0:      	ldrb	w10, [x22]
    7ff4:      	b	0x8134 <generic_rawtp_filter_arg+0x2d84>
    7ff8:      	cmp	w8, #0x1
    7ffc:      	b.eq	0x8118 <generic_rawtp_filter_arg+0x2d68>
    8000:      	cmp	w8, #0x2
    8004:      	b.ne	0x54ac <generic_rawtp_filter_arg+0xfc>
    8008:      	ldrh	w10, [x22]
    800c:      	b	0x8134 <generic_rawtp_filter_arg+0x2d84>
    8010:      	ldrb	w10, [x22]
    8014:      	b	0x801c <generic_rawtp_filter_arg+0x2c6c>
    8018:      	ldrh	w10, [x22]
    801c:      	cmp	w9, w10
    8020:      	b.eq	0x563c <generic_rawtp_filter_arg+0x28c>
    8024:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    8028:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    802c:      	mov	w8, #0x1                // =1
    8030:      	add	x9, sp, #0x60
    8034:      	ldr	x0, [x0]
    8038:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    803c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8040:      	mov	w8, #0x1                // =1
    8044:      	add	x9, sp, #0x60
    8048:      	ldr	x0, [x0]
    804c:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    8050:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8054:      	mov	w8, #0x1                // =1
    8058:      	add	x9, sp, #0x60
    805c:      	ldr	x0, [x0]
    8060:      	b	0x8074 <generic_rawtp_filter_arg+0x2cc4>
    8064:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8068:      	mov	w8, #0x1                // =1
    806c:      	add	x9, sp, #0x60
    8070:      	ldr	x0, [x0]
    8074:      	add	x1, sp, #0x60
    8078:      	blr	x8
    807c:      	cbz	x0, 0x8098 <generic_rawtp_filter_arg+0x2ce8>
    8080:      	mov	w8, #0x1                // =1
    8084:      	mov	x1, x19
    8088:      	blr	x8
    808c:      	cmp	x0, #0x0
    8090:      	cset	w23, ne
    8094:      	b	0x809c <generic_rawtp_filter_arg+0x2cec>
    8098:      	mov	x23, xzr
    809c:      	ldp	x16, x15, [sp, #0x40]
    80a0:      	mov	w2, #0x5ea0             // =24224
    80a4:      	mov	w12, #0x1               // =1
    80a8:      	ldr	x17, [sp, #0x38]
    80ac:      	ldr	w8, [x29, #0x4]
    80b0:      	cmp	w8, #0x25
    80b4:      	b.hi	0x80dc <generic_rawtp_filter_arg+0x2d2c>
    80b8:      	mov	x9, #0x50               // =80
    80bc:      	ldr	x19, [sp, #0x30]
    80c0:      	lsl	x8, x12, x8
    80c4:      	movk	x9, #0xc00, lsl #16
    80c8:      	movk	x9, #0x20, lsl #32
    80cc:      	tst	x8, x9
    80d0:      	b.eq	0x5644 <generic_rawtp_filter_arg+0x294>
    80d4:      	cmp	x23, #0x0
    80d8:      	b	0x5640 <generic_rawtp_filter_arg+0x290>
    80dc:      	ldr	x19, [sp, #0x30]
    80e0:      	b	0x5644 <generic_rawtp_filter_arg+0x294>
    80e4:      	ldr	x19, [sp, #0x30]
    80e8:      	mov	w12, #0x1               // =1
    80ec:      	b	0x7210 <generic_rawtp_filter_arg+0x1e60>
    80f0:      	ldr	x9, [x22]
    80f4:      	cmp	x9, x10
    80f8:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    80fc:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    8100:      	ldr	x9, [x22]
    8104:      	cmp	x9, x10
    8108:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    810c:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    8110:      	ldrb	w10, [x22]
    8114:      	b	0x8124 <generic_rawtp_filter_arg+0x2d74>
    8118:      	ldrh	w10, [x22]
    811c:      	b	0x8124 <generic_rawtp_filter_arg+0x2d74>
    8120:      	ldr	w9, [x22]
    8124:      	cmp	w9, w10
    8128:      	b.lo	0x5648 <generic_rawtp_filter_arg+0x298>
    812c:      	b	0x813c <generic_rawtp_filter_arg+0x2d8c>
    8130:      	ldr	w9, [x22]
    8134:      	cmp	w9, w10
    8138:      	b.hi	0x5648 <generic_rawtp_filter_arg+0x298>
    813c:      	orr	w8, w8, #0x2
    8140:      	cmp	w8, #0x6
    8144:      	b.eq	0x5648 <generic_rawtp_filter_arg+0x298>
    8148:      	b	0x54ac <generic_rawtp_filter_arg+0xfc>
    814c:      	nop

0000000000008150 <generic_rawtp_actions>:
    8150:      	sub	sp, sp, #0xe0
    8154:      	str	x29, [sp, #0x90]
    8158:      	stp	x30, x25, [sp, #0xa0]
    815c:      	stp	x24, x23, [sp, #0xb0]
    8160:      	stp	x22, x21, [sp, #0xc0]
    8164:      	stp	x20, x19, [sp, #0xd0]
    8168:      	str	x0, [sp, #0x50]
    816c:      	str	wzr, [sp, #0x5c]
    8170:      	adrp	x29, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8174:      	mov	w8, #0x1                // =1
    8178:      	add	x9, sp, #0x5c
    817c:      	add	x1, sp, #0x5c
    8180:      	ldr	x29, [x29]
    8184:      	mov	x0, x29
    8188:      	blr	x8
    818c:      	cbz	x0, 0x8c18 <generic_rawtp_actions+0xac8>
    8190:      	mov	w8, #0x5f04             // =24324
    8194:      	ldr	w19, [x0, x8]
    8198:      	cmp	w19, #0x2
    819c:      	b.lt	0x8c18 <generic_rawtp_actions+0xac8>
    81a0:      	mov	w8, #0x5ef8             // =24312
    81a4:      	add	x1, x0, x8
    81a8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    81ac:      	mov	w8, #0x1                // =1
    81b0:      	ldr	x0, [x0]
    81b4:      	blr	x8
    81b8:      	cbz	x0, 0x8c18 <generic_rawtp_actions+0xac8>
    81bc:      	and	x8, x19, #0x7ff
    81c0:      	add	x9, sp, #0x60
    81c4:      	add	x1, sp, #0x60
    81c8:      	ldr	w8, [x0, x8]
    81cc:      	str	wzr, [sp, #0x60]
    81d0:      	add	w8, w8, w19
    81d4:      	and	w8, w8, #0x7ff
    81d8:      	add	x21, x0, x8
    81dc:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    81e0:      	mov	w8, #0x1                // =1
    81e4:      	ldr	x0, [x0]
    81e8:      	blr	x8
    81ec:      	cbz	x0, 0x8234 <generic_rawtp_actions+0xe4>
    81f0:      	ldrb	w8, [x0]
    81f4:      	mov	w11, #0x6               // =6
    81f8:      	mov	w14, #0x7               // =7
    81fc:      	mov	w10, #0x8               // =8
    8200:      	mov	w12, #0x5               // =5
    8204:      	mov	w13, #0x9               // =9
    8208:      	ands	w8, w8, #0xff
    820c:      	cset	w9, eq
    8210:      	cmp	w8, #0x0
    8214:      	str	w9, [sp, #0x48]
    8218:      	mov	w9, #0x4                // =4
    821c:      	csel	x8, x11, x14, eq
    8220:      	csel	x11, x10, x13, eq
    8224:      	str	x8, [sp, #0x30]
    8228:      	csel	x8, x9, x12, eq
    822c:      	stp	x11, x8, [sp, #0x38]
    8230:      	b	0x8254 <generic_rawtp_actions+0x104>
    8234:      	mov	w8, #0x1                // =1
    8238:      	str	w8, [sp, #0x48]
    823c:      	mov	w8, #0x4                // =4
    8240:      	str	x8, [sp, #0x40]
    8244:      	mov	w8, #0x8                // =8
    8248:      	str	x8, [sp, #0x38]
    824c:      	mov	w8, #0x6                // =6
    8250:      	str	x8, [sp, #0x30]
    8254:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8258:      	mov	w23, wzr
    825c:      	mov	w24, wzr
    8260:      	ldr	x25, [x25]
    8264:      	add	x20, sp, #0x64
    8268:      	mov	w8, #0x1                // =1
    826c:      	str	w8, [sp, #0x4c]
    8270:      	b	0x8290 <generic_rawtp_actions+0x140>
    8274:      	nop
    8278:      	nop
    827c:      	nop
    8280:      	mov	w24, wzr
    8284:      	add	w23, w23, #0x1
    8288:      	cmp	w23, #0x3
    828c:      	b.eq	0x8bf4 <generic_rawtp_actions+0xaa4>
    8290:      	ldr	w9, [x21]
    8294:      	lsl	w8, w24, #2
    8298:      	add	w8, w8, #0x4
    829c:      	cmp	w8, w9
    82a0:      	b.hs	0x8bf4 <generic_rawtp_actions+0xaa4>
    82a4:      	add	x8, x21, w24, uxtw #2
    82a8:      	add	x1, sp, #0x64
    82ac:      	mov	x0, x29
    82b0:      	ldrsw	x19, [x8, #0x4]
    82b4:      	str	wzr, [sp, #0x64]
    82b8:      	mov	w8, #0x1                // =1
    82bc:      	blr	x8
    82c0:      	cbz	x0, 0x8280 <generic_rawtp_actions+0x130>
    82c4:      	mov	x22, x0
    82c8:      	cmp	w19, #0x7
    82cc:      	b.gt	0x8300 <generic_rawtp_actions+0x1b0>
    82d0:      	cmp	w19, #0x3
    82d4:      	b.gt	0x8350 <generic_rawtp_actions+0x200>
    82d8:      	cmp	w19, #0x1
    82dc:      	b.gt	0x83d0 <generic_rawtp_actions+0x280>
    82e0:      	cbz	w19, 0x8534 <generic_rawtp_actions+0x3e4>
    82e4:      	cmp	w19, #0x1
    82e8:      	b.eq	0x83e0 <generic_rawtp_actions+0x290>
    82ec:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    82f0:      	b	0x8638 <generic_rawtp_actions+0x4e8>
    82f4:      	nop
    82f8:      	nop
    82fc:      	nop
    8300:      	cmp	w19, #0xb
    8304:      	b.gt	0x83a8 <generic_rawtp_actions+0x258>
    8308:      	sub	w8, w19, #0xa
    830c:      	cmp	w8, #0x2
    8310:      	b.lo	0x8444 <generic_rawtp_actions+0x2f4>
    8314:      	cmp	w19, #0x8
    8318:      	b.eq	0x848c <generic_rawtp_actions+0x33c>
    831c:      	cmp	w19, #0x9
    8320:      	b.ne	0x863c <generic_rawtp_actions+0x4ec>
    8324:      	add	w24, w24, #0x1
    8328:      	add	x8, x21, w24, uxtw #2
    832c:      	ldr	w0, [x8, #0x4]
    8330:      	ldr	w8, [sp, #0x48]
    8334:      	add	x25, sp, #0x68
    8338:      	cbz	w8, 0x85dc <generic_rawtp_actions+0x48c>
    833c:      	sxtw	x8, w0
    8340:      	mov	w9, #0x6d               // =109
    8344:      	blr	x9
    8348:      	mov	w20, #0x2               // =2
    834c:      	b	0x85f0 <generic_rawtp_actions+0x4a0>
    8350:      	sub	w8, w19, #0x6
    8354:      	cmp	w8, #0x2
    8358:      	b.lo	0x8478 <generic_rawtp_actions+0x328>
    835c:      	cmp	w19, #0x4
    8360:      	b.eq	0x8494 <generic_rawtp_actions+0x344>
    8364:      	cmp	w19, #0x5
    8368:      	b.ne	0x863c <generic_rawtp_actions+0x4ec>
    836c:      	add	w8, w24, #0x1
    8370:      	add	x9, x21, #0x4
    8374:      	add	w24, w24, #0x2
    8378:      	ldr	w8, [x9, w8, uxtw #2]
    837c:      	ldr	w20, [x9, w24, uxtw #2]
    8380:      	stp	xzr, xzr, [sp, #0x68]
    8384:      	and	x8, x8, #0x7
    8388:      	cmp	w8, #0x4
    838c:      	b.hi	0x83a0 <generic_rawtp_actions+0x250>
    8390:      	add	x9, x22, x8, lsl #2
    8394:      	mov	w10, #0x5ea0            // =24224
    8398:      	ldr	w9, [x9, x10]
    839c:      	cbz	w9, 0x8818 <generic_rawtp_actions+0x6c8>
    83a0:      	add	x20, sp, #0x64
    83a4:      	b	0x863c <generic_rawtp_actions+0x4ec>
    83a8:      	cmp	w19, #0xc
    83ac:      	b.eq	0x85e4 <generic_rawtp_actions+0x494>
    83b0:      	cmp	w19, #0xd
    83b4:      	b.eq	0x84a4 <generic_rawtp_actions+0x354>
    83b8:      	cmp	w19, #0xe
    83bc:      	b.ne	0x863c <generic_rawtp_actions+0x4ec>
    83c0:      	ldr	x20, [sp, #0x38]
    83c4:      	add	x25, sp, #0x68
    83c8:      	add	w24, w24, #0x2
    83cc:      	b	0x85f0 <generic_rawtp_actions+0x4a0>
    83d0:      	cmp	w19, #0x2
    83d4:      	b.eq	0x85cc <generic_rawtp_actions+0x47c>
    83d8:      	cmp	w19, #0x3
    83dc:      	b.ne	0x82ec <generic_rawtp_actions+0x19c>
    83e0:      	add	w8, w24, #0x1
    83e4:      	add	x9, x21, #0x4
    83e8:      	add	w24, w24, #0x2
    83ec:      	ldr	w20, [x9, w24, uxtw #2]
    83f0:      	mov	x25, x21
    83f4:      	ldr	w21, [x9, w8, uxtw #2]
    83f8:      	str	wzr, [sp, #0x78]
    83fc:      	stp	xzr, xzr, [sp, #0x68]
    8400:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8404:      	mov	w8, #0x1                // =1
    8408:      	add	x9, sp, #0x78
    840c:      	add	x1, sp, #0x78
    8410:      	ldr	x0, [x0]
    8414:      	blr	x8
    8418:      	cbz	x0, 0x842c <generic_rawtp_actions+0x2dc>
    841c:      	and	x8, x21, #0x7
    8420:      	cmp	w8, #0x4
    8424:      	b.ls	0x8654 <generic_rawtp_actions+0x504>
    8428:      	mov	w0, wzr
    842c:      	mov	x21, x25
    8430:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8434:      	add	x20, sp, #0x64
    8438:      	ldr	x25, [x25]
    843c:      	cbnz	w0, 0x8280 <generic_rawtp_actions+0x130>
    8440:      	b	0x863c <generic_rawtp_actions+0x4ec>
    8444:      	add	w24, w24, #0x1
    8448:      	add	x8, x21, w24, uxtw #2
    844c:      	ldr	w8, [x8, #0x4]
    8450:      	and	x8, x8, #0x7
    8454:      	cmp	w8, #0x4
    8458:      	b.hi	0x846c <generic_rawtp_actions+0x31c>
    845c:      	add	x9, x22, x8, lsl #2
    8460:      	mov	w10, #0x5ea0            // =24224
    8464:      	ldr	w9, [x9, x10]
    8468:      	cbz	w9, 0x8670 <generic_rawtp_actions+0x520>
    846c:      	mov	w0, wzr
    8470:      	cbnz	w0, 0x8280 <generic_rawtp_actions+0x130>
    8474:      	b	0x863c <generic_rawtp_actions+0x4ec>
    8478:      	add	w24, w24, #0x1
    847c:      	add	x8, x21, w24, uxtw #2
    8480:      	ldr	w8, [x8, #0x4]
    8484:      	str	w8, [x22, #0x78]
    8488:      	b	0x863c <generic_rawtp_actions+0x4ec>
    848c:      	str	wzr, [sp, #0x4c]
    8490:      	b	0x863c <generic_rawtp_actions+0x4ec>
    8494:      	ldr	x20, [sp, #0x40]
    8498:      	add	x25, sp, #0x68
    849c:      	add	w24, w24, #0x1
    84a0:      	b	0x85f0 <generic_rawtp_actions+0x4a0>
    84a4:      	mov	w8, #0xe                // =14
    84a8:      	blr	x8
    84ac:      	str	x0, [sp, #0x88]
    84b0:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    84b4:      	mov	w8, #0x1                // =1
    84b8:      	add	x9, sp, #0x88
    84bc:      	ldr	x0, [x0]
    84c0:      	add	x1, sp, #0x88
    84c4:      	blr	x8
    84c8:      	cbz	x0, 0x863c <generic_rawtp_actions+0x4ec>
    84cc:      	ldur	x8, [x0, #0x4]
    84d0:      	mov	x20, x21
    84d4:      	add	x21, sp, #0x78
    84d8:      	add	x1, sp, #0x78
    84dc:      	str	x8, [sp, #0x78]
    84e0:      	mov	w8, #0x2                // =2
    84e4:      	mov	x0, x25
    84e8:      	str	w8, [sp, #0x80]
    84ec:      	mov	w8, #0x1                // =1
    84f0:      	blr	x8
    84f4:      	mov	w9, #0x1                // =1
    84f8:      	str	w9, [sp, #0x98]
    84fc:      	cbz	x0, 0x87a8 <generic_rawtp_actions+0x658>
    8500:      	ldaxr	w8, [x0]
    8504:      	add	w8, w8, #0x1
    8508:      	stlxr	w9, w8, [x0]
    850c:      	cbnz	w9, 0x8500 <generic_rawtp_actions+0x3b0>
    8510:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8514:      	mov	w8, #0x3                // =3
    8518:      	add	x9, sp, #0x88
    851c:      	ldr	x0, [x0]
    8520:      	add	x1, sp, #0x88
    8524:      	blr	x8
    8528:      	mov	x21, x20
    852c:      	add	x20, sp, #0x64
    8530:      	b	0x863c <generic_rawtp_actions+0x4ec>
    8534:      	add	w8, w24, #0x1
    8538:      	add	x9, x21, #0x4
    853c:      	ldr	w25, [x9, w8, uxtw #2]
    8540:      	add	w8, w24, #0x2
    8544:      	ldr	w20, [x9, w8, uxtw #2]
    8548:      	mov	w8, #0x7d               // =125
    854c:      	blr	x8
    8550:      	str	x0, [sp, #0x68]
    8554:      	str	wzr, [sp, #0x88]
    8558:      	str	x25, [sp, #0x18]
    855c:      	cbz	w25, 0x8afc <generic_rawtp_actions+0x9ac>
    8560:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8564:      	mov	w8, #0x1                // =1
    8568:      	add	x9, sp, #0x88
    856c:      	ldr	x0, [x0]
    8570:      	add	x1, sp, #0x88
    8574:      	blr	x8
    8578:      	cbz	x0, 0x8afc <generic_rawtp_actions+0x9ac>
    857c:      	mov	x25, x0
    8580:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8584:      	mov	w8, #0x1                // =1
    8588:      	ldr	x0, [x0]
    858c:      	add	x9, sp, #0x88
    8590:      	add	x1, sp, #0x88
    8594:      	blr	x8
    8598:      	ldr	x8, [x22, #0x60]
    859c:      	mov	x2, x0
    85a0:      	cmp	w20, #0x2
    85a4:      	str	x8, [x25]
    85a8:      	ldr	x8, [x22, #0x70]
    85ac:      	str	x8, [x25, #0x8]
    85b0:      	b.eq	0x891c <generic_rawtp_actions+0x7cc>
    85b4:      	cmp	w20, #0x1
    85b8:      	b.eq	0x8910 <generic_rawtp_actions+0x7c0>
    85bc:      	cbnz	w20, 0x8afc <generic_rawtp_actions+0x9ac>
    85c0:      	ldr	w8, [x22, #0x7c]
    85c4:      	str	x21, [sp, #0x8]
    85c8:      	b	0x8924 <generic_rawtp_actions+0x7d4>
    85cc:      	mov	w0, #0x9                // =9
    85d0:      	ldr	w8, [sp, #0x48]
    85d4:      	add	x25, sp, #0x68
    85d8:      	cbnz	w8, 0x833c <generic_rawtp_actions+0x1ec>
    85dc:      	mov	w20, #0x3               // =3
    85e0:      	b	0x85f0 <generic_rawtp_actions+0x4a0>
    85e4:      	ldr	x20, [sp, #0x30]
    85e8:      	add	x25, sp, #0x68
    85ec:      	add	w24, w24, #0x3
    85f0:      	str	wzr, [sp, #0x68]
    85f4:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    85f8:      	mov	w8, #0x1                // =1
    85fc:      	add	x1, sp, #0x68
    8600:      	ldr	x0, [x0]
    8604:      	blr	x8
    8608:      	cbz	x0, 0x8630 <generic_rawtp_actions+0x4e0>
    860c:      	add	x8, x0, x20, lsl #3
    8610:      	nop
    8614:      	nop
    8618:      	nop
    861c:      	nop
    8620:      	ldaxr	x9, [x8]
    8624:      	add	x9, x9, #0x1
    8628:      	stlxr	w10, x9, [x8]
    862c:      	cbnz	w10, 0x8620 <generic_rawtp_actions+0x4d0>
    8630:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8634:      	add	x20, sp, #0x64
    8638:      	ldr	x25, [x25]
    863c:      	add	w24, w24, #0x1
    8640:      	str	x19, [x22, #0x70]
    8644:      	add	w23, w23, #0x1
    8648:      	cmp	w23, #0x3
    864c:      	b.ne	0x8290 <generic_rawtp_actions+0x140>
    8650:      	b	0x8bf4 <generic_rawtp_actions+0xaa4>
    8654:      	add	x9, x22, x8, lsl #2
    8658:      	mov	w10, #0x5ea0            // =24224
    865c:      	ldr	w9, [x9, x10]
    8660:      	cbz	w9, 0x8708 <generic_rawtp_actions+0x5b8>
    8664:      	mov	x21, x25
    8668:      	mov	w0, wzr
    866c:      	b	0x8430 <generic_rawtp_actions+0x2e0>
    8670:      	add	x8, x22, x8, lsl #3
    8674:      	ldr	x8, [x8, #0x5e78]
    8678:      	and	x8, x8, #0x7ff
    867c:      	add	x8, x22, x8
    8680:      	ldr	x8, [x8, #0xb8]
    8684:      	str	x8, [sp, #0x78]
    8688:      	cbz	x8, 0x846c <generic_rawtp_actions+0x31c>
    868c:      	cmp	w19, #0xa
    8690:      	b.ne	0x88f0 <generic_rawtp_actions+0x7a0>
    8694:      	mov	w8, #0xe                // =14
    8698:      	add	x25, sp, #0x68
    869c:      	mov	x20, x21
    86a0:      	blr	x8
    86a4:      	lsr	x8, x0, #32
    86a8:      	mov	x21, x0
    86ac:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    86b0:      	str	w8, [sp, #0x68]
    86b4:      	mov	w8, #0x1                // =1
    86b8:      	add	x1, sp, #0x68
    86bc:      	ldr	x0, [x0]
    86c0:      	blr	x8
    86c4:      	cbz	x0, 0x86fc <generic_rawtp_actions+0x5ac>
    86c8:      	ldr	w8, [x0]
    86cc:      	mov	x3, xzr
    86d0:      	add	x9, sp, #0x78
    86d4:      	add	x1, sp, #0x78
    86d8:      	stp	w8, w21, [sp, #0x68]
    86dc:      	ldr	x8, [x0, #0x8]
    86e0:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    86e4:      	add	x2, sp, #0x68
    86e8:      	str	x8, [sp, #0x70]
    86ec:      	mov	w8, #0x2                // =2
    86f0:      	ldr	x0, [x0]
    86f4:      	blr	x8
    86f8:      	mov	w0, wzr
    86fc:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8700:      	mov	x21, x20
    8704:      	b	0x8434 <generic_rawtp_actions+0x2e4>
    8708:      	add	x8, x22, x8, lsl #3
    870c:      	mov	x21, x0
    8710:      	ldr	x8, [x8, #0x5e78]
    8714:      	str	wzr, [sp, #0x74]
    8718:      	and	x8, x8, #0x7ff
    871c:      	add	x8, x22, x8
    8720:      	ldr	w8, [x8, #0x90]
    8724:      	str	w8, [sp, #0x70]
    8728:      	mov	w8, #0xe                // =14
    872c:      	blr	x8
    8730:      	lsr	x8, x0, #32
    8734:      	cmp	w19, #0x1
    8738:      	str	x8, [sp, #0x68]
    873c:      	b.ne	0x88d4 <generic_rawtp_actions+0x784>
    8740:      	and	x8, x20, #0x7
    8744:      	cmp	w8, #0x4
    8748:      	b.hi	0x8428 <generic_rawtp_actions+0x2d8>
    874c:      	add	x9, x22, x8, lsl #2
    8750:      	mov	w10, #0x5ea0            // =24224
    8754:      	add	x20, sp, #0x68
    8758:      	ldr	w9, [x9, x10]
    875c:      	cbnz	w9, 0x8428 <generic_rawtp_actions+0x2d8>
    8760:      	add	x8, x22, x8, lsl #3
    8764:      	mov	x0, x21
    8768:      	ldr	x8, [x8, #0x5e78]
    876c:      	and	x8, x8, #0x7ff
    8770:      	add	x2, x22, x8
    8774:      	ldr	w8, [x2, #0x90]!
    8778:      	and	x8, x8, #0xfff
    877c:      	add	x1, x8, #0x8
    8780:      	mov	w8, #0x4                // =4
    8784:      	blr	x8
    8788:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    878c:      	mov	x3, xzr
    8790:      	mov	w8, #0x2                // =2
    8794:      	ldr	x0, [x0]
    8798:      	add	x1, sp, #0x68
    879c:      	mov	x2, x21
    87a0:      	blr	x8
    87a4:      	b	0x8428 <generic_rawtp_actions+0x2d8>
    87a8:      	mov	w8, #0x2                // =2
    87ac:      	add	x10, sp, #0x98
    87b0:      	add	x1, sp, #0x78
    87b4:      	add	x2, sp, #0x98
    87b8:      	mov	x0, x25
    87bc:      	mov	w3, #0x1                // =1
    87c0:      	blr	x8
    87c4:      	cbz	x0, 0x8510 <generic_rawtp_actions+0x3c0>
    87c8:      	mov	x21, x0
    87cc:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    87d0:      	add	x9, sp, #0x68
    87d4:      	add	x1, sp, #0x68
    87d8:      	neg	w8, w21
    87dc:      	strh	w8, [sp, #0x68]
    87e0:      	mov	w8, #0x3                // =3
    87e4:      	strh	w8, [sp, #0x6a]
    87e8:      	mov	x8, #0x3b               // =59
    87ec:      	movk	x8, #0x2, lsl #32
    87f0:      	stur	x8, [sp, #0x6c]
    87f4:      	mov	w8, #0x1                // =1
    87f8:      	ldr	x25, [x25]
    87fc:      	mov	x0, x25
    8800:      	blr	x8
    8804:      	cbz	x0, 0x8b80 <generic_rawtp_actions+0xa30>
    8808:      	ldr	w8, [x0]
    880c:      	add	w8, w8, #0x1
    8810:      	str	w8, [x0]
    8814:      	b	0x8ba8 <generic_rawtp_actions+0xa58>
    8818:      	add	x8, x22, x8, lsl #3
    881c:      	ldr	x8, [x8, #0x5e78]
    8820:      	and	x8, x8, #0x7ff
    8824:      	add	x8, x22, x8
    8828:      	ldr	w8, [x8, #0x90]
    882c:      	str	w8, [sp, #0x70]
    8830:      	mov	w8, #0xe                // =14
    8834:      	blr	x8
    8838:      	lsr	x8, x0, #32
    883c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8840:      	add	x9, sp, #0x68
    8844:      	str	x8, [sp, #0x68]
    8848:      	mov	w8, #0x1                // =1
    884c:      	add	x1, sp, #0x68
    8850:      	ldr	x0, [x0]
    8854:      	blr	x8
    8858:      	cbz	x0, 0x83a0 <generic_rawtp_actions+0x250>
    885c:      	and	x8, x20, #0x7
    8860:      	cmp	w8, #0x4
    8864:      	b.hi	0x83a0 <generic_rawtp_actions+0x250>
    8868:      	add	x9, x22, x8, lsl #2
    886c:      	mov	w10, #0x5ea0            // =24224
    8870:      	ldr	w9, [x9, x10]
    8874:      	cbnz	w9, 0x83a0 <generic_rawtp_actions+0x250>
    8878:      	add	x8, x22, x8, lsl #3
    887c:      	mov	x20, x21
    8880:      	mov	x21, x0
    8884:      	ldr	x8, [x8, #0x5e78]
    8888:      	str	wzr, [sp, #0x74]
    888c:      	and	x8, x8, #0x7ff
    8890:      	add	x8, x22, x8
    8894:      	ldr	w8, [x8, #0x90]
    8898:      	str	w8, [sp, #0x70]
    889c:      	mov	w8, #0xe                // =14
    88a0:      	blr	x8
    88a4:      	lsr	x8, x0, #32
    88a8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    88ac:      	mov	x3, xzr
    88b0:      	str	x8, [sp, #0x68]
    88b4:      	mov	w8, #0x2                // =2
    88b8:      	add	x9, sp, #0x68
    88bc:      	add	x1, sp, #0x68
    88c0:      	ldr	x0, [x0]
    88c4:      	mov	x2, x21
    88c8:      	mov	x21, x20
    88cc:      	blr	x8
    88d0:      	b	0x83a0 <generic_rawtp_actions+0x250>
    88d4:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    88d8:      	mov	w8, #0x3                // =3
    88dc:      	add	x9, sp, #0x68
    88e0:      	ldr	x0, [x0]
    88e4:      	add	x1, sp, #0x68
    88e8:      	blr	x8
    88ec:      	b	0x842c <generic_rawtp_actions+0x2dc>
    88f0:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    88f4:      	mov	w8, #0x3                // =3
    88f8:      	add	x9, sp, #0x78
    88fc:      	ldr	x0, [x0]
    8900:      	add	x1, sp, #0x78
    8904:      	blr	x8
    8908:      	cbnz	w0, 0x8280 <generic_rawtp_actions+0x130>
    890c:      	b	0x863c <generic_rawtp_actions+0x4ec>
    8910:      	ldr	w8, [x22, #0x10]
    8914:      	str	x21, [sp, #0x8]
    8918:      	b	0x8924 <generic_rawtp_actions+0x7d4>
    891c:      	str	x21, [sp, #0x8]
    8920:      	mov	x8, xzr
    8924:      	str	x8, [x25, #0x10]
    8928:      	str	x25, [sp, #0x10]
    892c:      	add	x0, x25, #0x18
    8930:      	mov	w8, #0x4                // =4
    8934:      	mov	w9, #0xc8               // =200
    8938:      	mov	w1, #0xc8               // =200
    893c:      	str	x0, [sp, #0x20]
    8940:      	blr	x8
    8944:      	str	wzr, [sp, #0x2c]
    8948:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    894c:      	mov	w8, #0x5e78             // =24184
    8950:      	mov	x21, xzr
    8954:      	ldr	x25, [x25]
    8958:      	add	x20, x22, x8
    895c:      	b	0x8970 <generic_rawtp_actions+0x820>
    8960:      	add	x21, x21, #0x4
    8964:      	add	x20, x20, #0x8
    8968:      	cmp	x21, #0x14
    896c:      	b.eq	0x8a98 <generic_rawtp_actions+0x948>
    8970:      	str	wzr, [sp, #0x78]
    8974:      	mov	w8, #0x1                // =1
    8978:      	add	x9, sp, #0x78
    897c:      	add	x1, sp, #0x78
    8980:      	mov	x0, x29
    8984:      	blr	x8
    8988:      	cbz	x0, 0x8a98 <generic_rawtp_actions+0x948>
    898c:      	mov	w8, #0x5ef8             // =24312
    8990:      	add	x1, x0, x8
    8994:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8998:      	mov	w8, #0x1                // =1
    899c:      	ldr	x0, [x0]
    89a0:      	blr	x8
    89a4:      	cbz	x0, 0x8a98 <generic_rawtp_actions+0x948>
    89a8:      	add	x8, x0, x21
    89ac:      	ldr	w8, [x8, #0x40]
    89b0:      	cmn	w8, #0x1
    89b4:      	b.eq	0x8a98 <generic_rawtp_actions+0x948>
    89b8:      	ldr	x8, [x20]
    89bc:      	ldr	w9, [x22, #0x4]
    89c0:      	cmp	x8, x9
    89c4:      	b.ge	0x8a98 <generic_rawtp_actions+0x948>
    89c8:      	cmp	x21, #0x10
    89cc:      	b.eq	0x8a2c <generic_rawtp_actions+0x8dc>
    89d0:      	str	wzr, [sp, #0x78]
    89d4:      	mov	w8, #0x1                // =1
    89d8:      	add	x9, sp, #0x78
    89dc:      	add	x1, sp, #0x78
    89e0:      	mov	x0, x29
    89e4:      	blr	x8
    89e8:      	cbz	x0, 0x8a28 <generic_rawtp_actions+0x8d8>
    89ec:      	mov	w8, #0x5ef8             // =24312
    89f0:      	add	x1, x0, x8
    89f4:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    89f8:      	mov	w8, #0x1                // =1
    89fc:      	ldr	x0, [x0]
    8a00:      	blr	x8
    8a04:      	cbz	x0, 0x8a28 <generic_rawtp_actions+0x8d8>
    8a08:      	add	x8, x0, x21
    8a0c:      	ldr	w9, [x8, #0x44]
    8a10:      	ldr	x8, [x20]
    8a14:      	cmn	w9, #0x1
    8a18:      	b.eq	0x8a2c <generic_rawtp_actions+0x8dc>
    8a1c:      	ldr	w9, [x20, #0x8]
    8a20:      	sub	w9, w9, w8
    8a24:      	b	0x8a38 <generic_rawtp_actions+0x8e8>
    8a28:      	ldr	x8, [x20]
    8a2c:      	ldr	w9, [x22, #0x4]
    8a30:      	sub	w9, w9, w8
    8a34:      	add	w9, w9, #0x4
    8a38:      	cmp	w9, #0x1
    8a3c:      	b.lt	0x8960 <generic_rawtp_actions+0x810>
    8a40:      	mov	w10, #0x3ffc            // =16380
    8a44:      	cmp	w9, #0x28
    8a48:      	add	w8, w8, w10
    8a4c:      	mov	w10, #0x28              // =40
    8a50:      	csel	w29, w9, w10, lt
    8a54:      	ldr	w9, [sp, #0x2c]
    8a58:      	and	x8, x8, #0x3fff
    8a5c:      	add	x8, x22, x8
    8a60:      	mov	w1, w29
    8a64:      	add	x2, x8, #0x90
    8a68:      	mov	w8, #0x4                // =4
    8a6c:      	and	w25, w9, #0xff
    8a70:      	ldr	x9, [sp, #0x20]
    8a74:      	add	x0, x9, x25
    8a78:      	blr	x8
    8a7c:      	add	w8, w29, w25
    8a80:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8a84:      	adrp	x29, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8a88:      	str	w8, [sp, #0x2c]
    8a8c:      	ldr	x25, [x25]
    8a90:      	ldr	x29, [x29]
    8a94:      	b	0x8960 <generic_rawtp_actions+0x810>
    8a98:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8a9c:      	mov	w8, #0x1                // =1
    8aa0:      	ldr	x0, [x0]
    8aa4:      	ldr	x1, [sp, #0x10]
    8aa8:      	blr	x8
    8aac:      	ldr	x21, [sp, #0x8]
    8ab0:      	cbz	x0, 0x8adc <generic_rawtp_actions+0x98c>
    8ab4:      	ldr	x9, [sp, #0x68]
    8ab8:      	ldr	x11, [sp, #0x18]
    8abc:      	mov	x10, #-0x4240           // =-16960
    8ac0:      	movk	x10, #0xfff0, lsl #16
    8ac4:      	ldr	x8, [x0]
    8ac8:      	madd	x9, x11, x10, x9
    8acc:      	cmp	x8, x9
    8ad0:      	b.ls	0x8adc <generic_rawtp_actions+0x98c>
    8ad4:      	str	wzr, [sp, #0x4c]
    8ad8:      	b	0x8b04 <generic_rawtp_actions+0x9b4>
    8adc:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8ae0:      	mov	x3, xzr
    8ae4:      	mov	w8, #0x2                // =2
    8ae8:      	ldr	x0, [x0]
    8aec:      	ldr	x1, [sp, #0x10]
    8af0:      	add	x9, sp, #0x68
    8af4:      	add	x2, sp, #0x68
    8af8:      	blr	x8
    8afc:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8b00:      	ldr	x25, [x25]
    8b04:      	add	w8, w24, #0x3
    8b08:      	add	x20, sp, #0x64
    8b0c:      	add	x8, x21, w8, uxtw #2
    8b10:      	ldr	w8, [x8, #0x4]
    8b14:      	cbz	w8, 0x8b40 <generic_rawtp_actions+0x9f0>
    8b18:      	ldrb	w8, [x22, #0x1]
    8b1c:      	adrp	x1, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8b20:      	ldr	x0, [sp, #0x50]
    8b24:      	mov	x2, xzr
    8b28:      	orr	w8, w8, #0x2
    8b2c:      	strb	w8, [x22, #0x1]
    8b30:      	mov	w8, #0x1b               // =27
    8b34:      	ldr	x1, [x1]
    8b38:      	blr	x8
    8b3c:      	str	x0, [x22, #0x80]
    8b40:      	add	w24, w24, #0x4
    8b44:      	add	x8, x21, w24, uxtw #2
    8b48:      	ldr	w8, [x8, #0x4]
    8b4c:      	cbz	w8, 0x863c <generic_rawtp_actions+0x4ec>
    8b50:      	ldrb	w8, [x22, #0x1]
    8b54:      	adrp	x1, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8b58:      	ldr	x0, [sp, #0x50]
    8b5c:      	mov	w9, #0x100              // =256
    8b60:      	mov	w2, #0x100              // =256
    8b64:      	orr	w8, w8, #0x4
    8b68:      	strb	w8, [x22, #0x1]
    8b6c:      	mov	w8, #0x1b               // =27
    8b70:      	ldr	x1, [x1]
    8b74:      	blr	x8
    8b78:      	str	x0, [x22, #0x88]
    8b7c:      	b	0x863c <generic_rawtp_actions+0x4ec>
    8b80:      	mov	w8, #0x1                // =1
    8b84:      	mov	x3, xzr
    8b88:      	add	x9, sp, #0x9c
    8b8c:      	str	w8, [sp, #0x9c]
    8b90:      	mov	w8, #0x2                // =2
    8b94:      	add	x10, sp, #0x68
    8b98:      	add	x1, sp, #0x68
    8b9c:      	add	x2, sp, #0x9c
    8ba0:      	mov	x0, x25
    8ba4:      	blr	x8
    8ba8:      	adrp	x25, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8bac:      	ldr	x25, [x25]
    8bb0:      	cbz	w21, 0x8510 <generic_rawtp_actions+0x3c0>
    8bb4:      	mov	w8, #0x1                // =1
    8bb8:      	add	x9, sp, #0x78
    8bbc:      	add	x1, sp, #0x78
    8bc0:      	mov	x0, x25
    8bc4:      	blr	x8
    8bc8:      	cbz	x0, 0x8510 <generic_rawtp_actions+0x3c0>
    8bcc:      	ldr	w8, [sp, #0x98]
    8bd0:      	nop
    8bd4:      	nop
    8bd8:      	nop
    8bdc:      	nop
    8be0:      	ldaxr	w9, [x0]
    8be4:      	add	w9, w9, w8
    8be8:      	stlxr	w10, w9, [x0]
    8bec:      	cbnz	w10, 0x8be0 <generic_rawtp_actions+0xa90>
    8bf0:      	b	0x8510 <generic_rawtp_actions+0x3c0>
    8bf4:      	ldr	w8, [sp, #0x4c]
    8bf8:      	cbz	w8, 0x8c18 <generic_rawtp_actions+0xac8>
    8bfc:      	adrp	x1, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8c00:      	mov	w8, #0x5                // =5
    8c04:      	mov	w9, #0xc                // =12
    8c08:      	ldr	x1, [x1]
    8c0c:      	ldr	x0, [sp, #0x50]
    8c10:      	mov	w2, #0x5                // =5
    8c14:      	blr	x9
    8c18:      	ldp	x20, x19, [sp, #0xd0]
    8c1c:      	mov	w0, wzr
    8c20:      	ldr	x29, [sp, #0x90]
    8c24:      	ldp	x22, x21, [sp, #0xc0]
    8c28:      	ldp	x24, x23, [sp, #0xb0]
    8c2c:      	ldp	x30, x25, [sp, #0xa0]
    8c30:      	add	sp, sp, #0xe0
    8c34:      	ret
    8c38:      	nop
    8c3c:      	nop

0000000000008c40 <generic_rawtp_output>:
    8c40:      	sub	sp, sp, #0xc0
    8c44:      	str	x29, [sp, #0x70]
    8c48:      	stp	x30, x25, [sp, #0x80]
    8c4c:      	stp	x24, x23, [sp, #0x90]
    8c50:      	stp	x22, x21, [sp, #0xa0]
    8c54:      	stp	x20, x19, [sp, #0xb0]
    8c58:      	mov	x19, x0
    8c5c:      	str	wzr, [sp, #0x4]
    8c60:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8c64:      	mov	w8, #0x1                // =1
    8c68:      	ldr	x0, [x0]
    8c6c:      	add	x9, sp, #0x4
    8c70:      	add	x1, sp, #0x4
    8c74:      	blr	x8
    8c78:      	cbz	x0, 0x90d8 <generic_rawtp_output+0x498>
    8c7c:      	adrp	x21, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8c80:      	ldr	x8, [x0, #0x5ee8]
    8c84:      	mov	x20, x0
    8c88:      	ldr	x21, [x21]
    8c8c:      	cbz	x8, 0x8f18 <generic_rawtp_output+0x2d8>
    8c90:      	mov	w8, #0xe                // =14
    8c94:      	blr	x8
    8c98:      	mov	w8, #0x23               // =35
    8c9c:      	lsr	x22, x0, #32
    8ca0:      	blr	x8
    8ca4:      	str	w22, [sp, #0x28]
    8ca8:      	mov	w8, #0x1                // =1
    8cac:      	add	x9, sp, #0x28
    8cb0:      	mov	x23, x0
    8cb4:      	add	x1, sp, #0x28
    8cb8:      	mov	x0, x21
    8cbc:      	blr	x8
    8cc0:      	cbz	x0, 0x8f18 <generic_rawtp_output+0x2d8>
    8cc4:      	add	x2, x23, #0xb50
    8cc8:      	mov	w29, #0x8               // =8
    8ccc:      	add	x8, sp, #0x78
    8cd0:      	mov	w9, #0x4                // =4
    8cd4:      	mov	x22, x0
    8cd8:      	add	x24, x0, #0x28
    8cdc:      	add	x0, sp, #0x78
    8ce0:      	mov	w1, #0x8                // =8
    8ce4:      	mov	w25, #0x4               // =4
    8ce8:      	blr	x9
    8cec:      	ldr	x8, [sp, #0x78]
    8cf0:      	mov	w9, #0x48               // =72
    8cf4:      	add	x10, sp, #0x28
    8cf8:      	mov	w11, #0x4               // =4
    8cfc:      	ldr	x2, [sp, #0x78]
    8d00:      	add	x0, sp, #0x28
    8d04:      	mov	w1, #0x48               // =72
    8d08:      	blr	x11
    8d0c:      	ldr	x8, [sp, #0x30]
    8d10:      	mov	w9, #0x4                // =4
    8d14:      	mov	x0, x24
    8d18:      	mov	w1, #0x4                // =4
    8d1c:      	add	x8, x8, #0x218
    8d20:      	ldr	x8, [sp, #0x30]
    8d24:      	add	x2, x8, #0x218
    8d28:      	blr	x9
    8d2c:      	ldr	x8, [sp, #0x38]
    8d30:      	add	x0, x22, #0x2c
    8d34:      	mov	w9, #0x4                // =4
    8d38:      	mov	w1, #0x4                // =4
    8d3c:      	add	x8, x8, #0x4d8
    8d40:      	ldr	x8, [sp, #0x38]
    8d44:      	add	x2, x8, #0x4d8
    8d48:      	blr	x9
    8d4c:      	ldr	x8, [sp, #0x40]
    8d50:      	add	x0, x22, #0x30
    8d54:      	mov	w9, #0x4                // =4
    8d58:      	mov	w1, #0x4                // =4
    8d5c:      	add	x8, x8, #0x58
    8d60:      	ldr	x8, [sp, #0x40]
    8d64:      	add	x2, x8, #0x58
    8d68:      	blr	x9
    8d6c:      	str	xzr, [sp, #0x20]
    8d70:      	add	x2, x23, #0x938
    8d74:      	add	x8, sp, #0x20
    8d78:      	add	x0, sp, #0x20
    8d7c:      	mov	w1, #0x8                // =8
    8d80:      	blr	x25
    8d84:      	ldr	x8, [sp, #0x20]
    8d88:      	cbz	x8, 0x8e0c <generic_rawtp_output+0x1cc>
    8d8c:      	str	wzr, [sp, #0x1c]
    8d90:      	add	x8, x8, #0x4
    8d94:      	add	x9, sp, #0x1c
    8d98:      	mov	w10, #0x4               // =4
    8d9c:      	add	x0, sp, #0x1c
    8da0:      	mov	w1, #0x4                // =4
    8da4:      	mov	w24, #0x4               // =4
    8da8:      	ldr	x8, [sp, #0x20]
    8dac:      	add	x2, x8, #0x4
    8db0:      	blr	x10
    8db4:      	ldr	x8, [sp, #0x20]
    8db8:      	ldrsw	x9, [sp, #0x1c]
    8dbc:      	add	x10, sp, #0x8
    8dc0:      	mov	w11, #0x4               // =4
    8dc4:      	add	x0, sp, #0x8
    8dc8:      	mov	w1, #0x10               // =16
    8dcc:      	add	x8, x8, x9, lsl #4
    8dd0:      	mov	w9, #0x10               // =16
    8dd4:      	add	x8, x8, #0x80
    8dd8:      	ldr	x8, [sp, #0x20]
    8ddc:      	ldrsw	x9, [sp, #0x1c]
    8de0:      	add	x8, x8, x9, lsl #4
    8de4:      	add	x2, x8, #0x80
    8de8:      	blr	x11
    8dec:      	ldr	x8, [sp, #0x10]
    8df0:      	add	x0, x22, #0x34
    8df4:      	mov	w1, #0x4                // =4
    8df8:      	add	x8, x8, #0x158
    8dfc:      	ldr	x8, [sp, #0x10]
    8e00:      	add	x2, x8, #0x158
    8e04:      	blr	x24
    8e08:      	b	0x8e10 <generic_rawtp_output+0x1d0>
    8e0c:      	str	wzr, [x22, #0x34]
    8e10:      	ldr	x8, [sp, #0x48]
    8e14:      	add	x0, x22, #0x38
    8e18:      	mov	w9, #0x4                // =4
    8e1c:      	mov	w1, #0x4                // =4
    8e20:      	mov	w24, #0x4               // =4
    8e24:      	add	x8, x8, #0x158
    8e28:      	ldr	x8, [sp, #0x48]
    8e2c:      	add	x2, x8, #0x158
    8e30:      	blr	x9
    8e34:      	ldr	x8, [sp, #0x50]
    8e38:      	add	x0, x22, #0x3c
    8e3c:      	mov	w9, #0x4                // =4
    8e40:      	mov	w1, #0x4                // =4
    8e44:      	add	x8, x8, #0x118
    8e48:      	ldr	x8, [sp, #0x50]
    8e4c:      	add	x2, x8, #0x118
    8e50:      	blr	x9
    8e54:      	ldr	x8, [sp, #0x58]
    8e58:      	add	x0, x22, #0x40
    8e5c:      	mov	w9, #0x4                // =4
    8e60:      	mov	w1, #0x4                // =4
    8e64:      	add	x8, x8, #0x98
    8e68:      	ldr	x8, [sp, #0x58]
    8e6c:      	add	x2, x8, #0x98
    8e70:      	blr	x9
    8e74:      	ldr	x8, [sp, #0x60]
    8e78:      	add	x0, x22, #0x44
    8e7c:      	mov	w9, #0x4                // =4
    8e80:      	mov	w1, #0x4                // =4
    8e84:      	add	x8, x8, #0x98
    8e88:      	ldr	x8, [sp, #0x60]
    8e8c:      	add	x2, x8, #0x98
    8e90:      	blr	x9
    8e94:      	ldr	x8, [sp, #0x68]
    8e98:      	add	x0, x22, #0x48
    8e9c:      	mov	w9, #0x4                // =4
    8ea0:      	mov	w1, #0x4                // =4
    8ea4:      	add	x8, x8, #0x58
    8ea8:      	ldr	x8, [sp, #0x68]
    8eac:      	add	x2, x8, #0x58
    8eb0:      	blr	x9
    8eb4:      	str	xzr, [sp, #0x8]
    8eb8:      	str	xzr, [sp, #0x20]
    8ebc:      	add	x2, x23, #0xae0
    8ec0:      	mov	w23, #0x8               // =8
    8ec4:      	add	x8, sp, #0x8
    8ec8:      	mov	w9, #0x4                // =4
    8ecc:      	add	x0, sp, #0x8
    8ed0:      	mov	w1, #0x8                // =8
    8ed4:      	blr	x9
    8ed8:      	ldr	x8, [sp, #0x8]
    8edc:      	add	x9, sp, #0x20
    8ee0:      	mov	w10, #0x4               // =4
    8ee4:      	add	x0, sp, #0x20
    8ee8:      	mov	w1, #0x8                // =8
    8eec:      	add	x8, x8, #0x90
    8ef0:      	ldr	x8, [sp, #0x8]
    8ef4:      	add	x2, x8, #0x90
    8ef8:      	blr	x10
    8efc:      	ldr	x8, [sp, #0x20]
    8f00:      	add	x0, x22, #0x4c
    8f04:      	mov	w1, #0x4                // =4
    8f08:      	add	x8, x8, #0x158
    8f0c:      	ldr	x8, [sp, #0x20]
    8f10:      	add	x2, x8, #0x158
    8f14:      	blr	x24
    8f18:      	ldr	x8, [x20, #0x5ef0]
    8f1c:      	cbz	x8, 0x8fb8 <generic_rawtp_output+0x378>
    8f20:      	mov	w8, #0xe                // =14
    8f24:      	blr	x8
    8f28:      	mov	w8, #0x23               // =35
    8f2c:      	lsr	x23, x0, #32
    8f30:      	blr	x8
    8f34:      	str	w23, [sp, #0x28]
    8f38:      	mov	w8, #0x1                // =1
    8f3c:      	add	x9, sp, #0x28
    8f40:      	mov	x22, x0
    8f44:      	add	x1, sp, #0x28
    8f48:      	mov	x0, x21
    8f4c:      	blr	x8
    8f50:      	cbz	x0, 0x8fb8 <generic_rawtp_output+0x378>
    8f54:      	add	x2, x22, #0xae0
    8f58:      	mov	w22, #0x8               // =8
    8f5c:      	add	x8, sp, #0x28
    8f60:      	mov	w9, #0x4                // =4
    8f64:      	add	x21, x0, #0x50
    8f68:      	mov	x24, x0
    8f6c:      	add	x0, sp, #0x28
    8f70:      	mov	w1, #0x8                // =8
    8f74:      	mov	w23, #0x4               // =4
    8f78:      	blr	x9
    8f7c:      	ldr	x25, [sp, #0x28]
    8f80:      	add	x0, x24, #0x58
    8f84:      	mov	w8, #0x4                // =4
    8f88:      	mov	w1, #0x8                // =8
    8f8c:      	add	x2, x25, #0x40
    8f90:      	blr	x8
    8f94:      	add	x0, x24, #0x60
    8f98:      	add	x2, x25, #0x30
    8f9c:      	mov	w8, #0x4                // =4
    8fa0:      	mov	w1, #0x8                // =8
    8fa4:      	blr	x8
    8fa8:      	add	x2, x25, #0x38
    8fac:      	mov	x0, x21
    8fb0:      	mov	w1, #0x8                // =8
    8fb4:      	blr	x23
    8fb8:      	ldr	w8, [x20, #0x4]
    8fbc:      	mov	w9, #0x2328             // =9000
    8fc0:      	adrp	x1, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8fc4:      	mov	x0, x19
    8fc8:      	ldr	x1, [x1]
    8fcc:      	mov	w2, #-0x1               // =-1
    8fd0:      	mov	x3, x20
    8fd4:      	add	w8, w8, #0x90
    8fd8:      	and	w8, w8, #0x7fff
    8fdc:      	cmp	w8, w9
    8fe0:      	csel	w4, w8, w9, lo
    8fe4:      	mov	w8, #-0x1               // =-1
    8fe8:      	mov	w9, #0x19               // =25
    8fec:      	blr	x9
    8ff0:      	tbnz	x0, #0x3f, 0x9034 <generic_rawtp_output+0x3f4>
    8ff4:      	str	wzr, [sp, #0x28]
    8ff8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2c50>
    8ffc:      	mov	w8, #0x1                // =1
    9000:      	add	x9, sp, #0x28
    9004:      	ldr	x0, [x0]
    9008:      	add	x1, sp, #0x28
    900c:      	blr	x8
    9010:      	cbz	x0, 0x90d8 <generic_rawtp_output+0x498>
    9014:      	add	x8, x0, #0x8
    9018:      	nop
    901c:      	nop
    9020:      	ldaxr	x9, [x8]
    9024:      	add	x9, x9, #0x1
    9028:      	stlxr	w10, x9, [x8]
    902c:      	cbnz	w10, 0x9020 <generic_rawtp_output+0x3e0>
    9030:      	b	0x90d8 <generic_rawtp_output+0x498>
    9034:      	mov	x19, x0
    9038:      	str	wzr, [sp, #0x28]
    903c:      	adrp	x0, 0x9000 <generic_rawtp_output+0x3c0>
    9040:      	mov	w8, #0x1                // =1
    9044:      	ldr	x0, [x0]
    9048:      	add	x9, sp, #0x28
    904c:      	add	x1, sp, #0x28
    9050:      	blr	x8
    9054:      	cbz	x0, 0x90d8 <generic_rawtp_output+0x498>
    9058:      	mov	x8, x19
    905c:      	cmn	x19, #0xc
    9060:      	b.gt	0x9084 <generic_rawtp_output+0x444>
    9064:      	cmn	x8, #0x1c
    9068:      	b.eq	0x90a4 <generic_rawtp_output+0x464>
    906c:      	cmn	x8, #0x16
    9070:      	b.eq	0x90bc <generic_rawtp_output+0x47c>
    9074:      	cmn	x8, #0x10
    9078:      	b.ne	0x90b4 <generic_rawtp_output+0x474>
    907c:      	add	x8, x0, #0x328
    9080:      	b	0x90c8 <generic_rawtp_output+0x488>
    9084:      	cmn	x8, #0xb
    9088:      	b.eq	0x90ac <generic_rawtp_output+0x46c>
    908c:      	cmn	x8, #0x7
    9090:      	b.eq	0x90c4 <generic_rawtp_output+0x484>
    9094:      	cmn	x8, #0x2
    9098:      	b.ne	0x90b4 <generic_rawtp_output+0x474>
    909c:      	add	x8, x0, #0x318
    90a0:      	b	0x90c8 <generic_rawtp_output+0x488>
    90a4:      	add	x8, x0, #0x338
    90a8:      	b	0x90c8 <generic_rawtp_output+0x488>
    90ac:      	add	x8, x0, #0x340
    90b0:      	b	0x90c8 <generic_rawtp_output+0x488>
    90b4:      	add	x8, x0, #0x310
    90b8:      	b	0x90c8 <generic_rawtp_output+0x488>
    90bc:      	add	x8, x0, #0x330
    90c0:      	b	0x90c8 <generic_rawtp_output+0x488>
    90c4:      	add	x8, x0, #0x320
    90c8:      	ldaxr	x9, [x8]
    90cc:      	add	x9, x9, #0x1
    90d0:      	stlxr	w10, x9, [x8]
    90d4:      	cbnz	w10, 0x90c8 <generic_rawtp_output+0x488>
    90d8:      	ldp	x20, x19, [sp, #0xb0]
    90dc:      	mov	w0, wzr
    90e0:      	ldr	x29, [sp, #0x70]
    90e4:      	ldp	x22, x21, [sp, #0xa0]
    90e8:      	ldp	x24, x23, [sp, #0x90]
    90ec:      	ldp	x30, x25, [sp, #0x80]
    90f0:      	add	sp, sp, #0xc0
    90f4:      	ret
    90f8:      	nop
    90fc:      	nop

0000000000009100 <generic_rawtp_path>:
    9100:      	sub	sp, sp, #0xe0
    9104:      	str	x29, [sp, #0x90]
    9108:      	stp	x30, x25, [sp, #0xa0]
    910c:      	stp	x24, x23, [sp, #0xb0]
    9110:      	stp	x22, x21, [sp, #0xc0]
    9114:      	stp	x20, x19, [sp, #0xd0]
    9118:      	mov	x19, x0
    911c:      	str	wzr, [sp, #0x28]
    9120:      	adrp	x0, 0x9000 <generic_rawtp_output+0x3c0>
    9124:      	mov	w8, #0x1                // =1
    9128:      	ldr	x0, [x0]
    912c:      	add	x9, sp, #0x28
    9130:      	add	x1, sp, #0x28
    9134:      	blr	x8
    9138:      	cbz	x0, 0x14f9c <generic_rawtp_path+0xbe9c>
    913c:      	mov	w8, #0x6420             // =25632
    9140:      	add	x25, x0, x8
    9144:      	ldr	w8, [x25]
    9148:      	cmp	w8, #0x1
    914c:      	b.eq	0x91f8 <generic_rawtp_path+0xf8>
    9150:      	cbnz	w8, 0x14f9c <generic_rawtp_path+0xbe9c>
    9154:      	mov	x20, x0
    9158:      	ldr	x22, [x0, #0x6440]
    915c:      	str	wzr, [sp, #0x70]
    9160:      	adrp	x0, 0x9000 <generic_rawtp_output+0x3c0>
    9164:      	mov	w8, #0x1                // =1
    9168:      	add	x9, sp, #0x70
    916c:      	ldr	x0, [x0]
    9170:      	add	x1, sp, #0x70
    9174:      	blr	x8
    9178:      	cbz	x0, 0x14f9c <generic_rawtp_path+0xbe9c>
    917c:      	str	x19, [sp, #0x20]
    9180:      	add	x2, x22, #0x8
    9184:      	mov	w8, #0x8                // =8
    9188:      	mov	w9, #0x4                // =4
    918c:      	add	x10, sp, #0x80
    9190:      	mov	x21, x0
    9194:      	add	x29, x0, #0xfff
    9198:      	add	x0, sp, #0x80
    919c:      	mov	w1, #0x8                // =8
    91a0:      	blr	x9
    91a4:      	adrp	x22, 0x9000 <generic_rawtp_output+0x3c0>
    91a8:      	ldr	x22, [x22]
    91ac:      	cbz	x0, 0x14c28 <generic_rawtp_path+0xbb28>
    91b0:      	neg	w8, w0
    91b4:      	mov	w9, #0x1                // =1
    91b8:      	add	x1, sp, #0x30
    91bc:      	strh	w8, [sp, #0x30]
    91c0:      	mov	w8, #0x6                // =6
    91c4:      	mov	x0, x22
    91c8:      	mov	w23, #0x1               // =1
    91cc:      	strh	w8, [sp, #0x32]
    91d0:      	mov	x8, #0x2c               // =44
    91d4:      	movk	x8, #0x4, lsl #32
    91d8:      	stur	x8, [sp, #0x34]
    91dc:      	add	x8, sp, #0x30
    91e0:      	blr	x9
    91e4:      	cbz	x0, 0x14c04 <generic_rawtp_path+0xbb04>
    91e8:      	ldr	w8, [x0]
    91ec:      	add	w8, w8, #0x1
    91f0:      	str	w8, [x0]
    91f4:      	b	0x14c28 <generic_rawtp_path+0xbb28>
    91f8:      	ldr	x8, [x0, #0x6448]
    91fc:      	ldr	x9, [x0, #0x6450]
    9200:      	mov	x20, x0
    9204:      	add	x1, sp, #0x2c
    9208:      	str	xzr, [sp, #0x60]
    920c:      	str	wzr, [sp, #0x68]
    9210:      	strb	wzr, [sp, #0x6c]
    9214:      	str	wzr, [sp, #0x2c]
    9218:      	stp	x8, x9, [sp, #0x30]
    921c:      	ldr	x8, [x0, #0x6458]
    9220:      	ldr	x9, [x0, #0x6468]
    9224:      	stp	xzr, x8, [sp, #0x40]
    9228:      	ldr	x8, [x0, #0x6460]
    922c:      	adrp	x0, 0x9000 <generic_rawtp_output+0x3c0>
    9230:      	stp	x8, x9, [sp, #0x50]
    9234:      	mov	w8, #0x1                // =1
    9238:      	add	x9, sp, #0x2c
    923c:      	ldr	x0, [x0]
    9240:      	blr	x8
    9244:      	cbz	x0, 0x14f9c <generic_rawtp_path+0xbe9c>
    9248:      	str	x0, [sp, #0x40]
    924c:      	add	x10, sp, #0x30
    9250:      	stp	x20, x19, [sp, #0x18]
    9254:      	mov	w20, #0x200             // =512
    9258:      	mov	w29, #0x8               // =8
    925c:      	ldr	w8, [x25, #0x4]
    9260:      	add	x22, x10, #0x18
    9264:      	add	x19, sp, #0x70
    9268:      	and	x9, x8, #0xfff
    926c:      	str	x0, [sp, #0x10]
    9270:      	str	w8, [sp, #0x68]
    9274:      	add	x9, x0, x9
    9278:      	str	x9, [sp, #0x60]
    927c:      	ldp	x21, x2, [sp, #0x48]
    9280:      	ldp	x8, x9, [sp, #0x30]
    9284:      	cmp	x21, x8
    9288:      	ccmp	x2, x9, #0x0, eq
    928c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9290:      	ldr	x24, [sp, #0x58]
    9294:      	mov	w8, #0x4                // =4
    9298:      	add	x0, sp, #0x70
    929c:      	mov	w1, #0x8                // =8
    92a0:      	blr	x8
    92a4:      	ldr	x8, [sp, #0x70]
    92a8:      	cmp	x21, x8
    92ac:      	b.eq	0x93a8 <generic_rawtp_path+0x2a8>
    92b0:      	add	x23, x21, #0x18
    92b4:      	mov	w8, #0x4                // =4
    92b8:      	add	x9, sp, #0x98
    92bc:      	add	x0, sp, #0x98
    92c0:      	mov	w1, #0x8                // =8
    92c4:      	mov	x2, x23
    92c8:      	blr	x8
    92cc:      	ldr	x8, [sp, #0x98]
    92d0:      	cmp	x8, x21
    92d4:      	b.eq	0x93a8 <generic_rawtp_path+0x2a8>
    92d8:      	mov	w8, #0x4                // =4
    92dc:      	add	x9, sp, #0x78
    92e0:      	add	x0, sp, #0x78
    92e4:      	mov	w1, #0x8                // =8
    92e8:      	mov	x2, x23
    92ec:      	blr	x8
    92f0:      	add	x2, x21, #0x20
    92f4:      	mov	w8, #0x4                // =4
    92f8:      	mov	w9, #0x10               // =16
    92fc:      	add	x10, sp, #0x80
    9300:      	add	x0, sp, #0x80
    9304:      	mov	w1, #0x10               // =16
    9308:      	blr	x8
    930c:      	ldr	w21, [sp, #0x84]
    9310:      	ldr	x8, [sp, #0x40]
    9314:      	ldr	x10, [sp, #0x60]
    9318:      	sub	x12, x10, x8
    931c:      	ldr	w23, [sp, #0x68]
    9320:      	subs	w10, w21, w23
    9324:      	ldr	x9, [sp, #0x88]
    9328:      	csel	w10, wzr, w10, lo
    932c:      	cmp	w23, w21
    9330:      	csel	w11, w23, w21, lo
    9334:      	cinc	w13, w11, hi
    9338:      	sub	w14, w23, w13
    933c:      	subs	x12, x12, x13
    9340:      	str	w14, [sp, #0x68]
    9344:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9348:      	cmp	x12, #0xfff
    934c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9350:      	cmp	w23, w21
    9354:      	b.ls	0x9360 <generic_rawtp_path+0x260>
    9358:      	mov	w13, #0x2f              // =47
    935c:      	strb	w13, [x8, x12]
    9360:      	add	x19, x8, x12
    9364:      	cmp	w23, w21
    9368:      	add	x2, x9, x10
    936c:      	and	w1, w11, #0xff
    9370:      	mov	w8, #0x4                // =4
    9374:      	cinc	x0, x19, hi
    9378:      	blr	x8
    937c:      	cmp	w23, w21
    9380:      	str	x19, [sp, #0x60]
    9384:      	add	x19, sp, #0x70
    9388:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    938c:      	ldr	x21, [sp, #0x78]
    9390:      	ldp	x2, x24, [sp, #0x50]
    9394:      	str	x21, [sp, #0x48]
    9398:      	ldr	x8, [sp, #0x30]
    939c:      	cmp	x21, x8
    93a0:      	b.eq	0x9400 <generic_rawtp_path+0x300>
    93a4:      	b	0x940c <generic_rawtp_path+0x30c>
    93a8:      	add	x2, x24, #0x10
    93ac:      	mov	w8, #0x4                // =4
    93b0:      	add	x9, sp, #0x98
    93b4:      	add	x0, sp, #0x98
    93b8:      	mov	w1, #0x8                // =8
    93bc:      	blr	x8
    93c0:      	ldr	x8, [sp, #0x58]
    93c4:      	ldr	x9, [sp, #0x98]
    93c8:      	cmp	x8, x9
    93cc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    93d0:      	add	x2, x24, #0x18
    93d4:      	mov	w8, #0x4                // =4
    93d8:      	mov	x0, x22
    93dc:      	mov	w1, #0x8                // =8
    93e0:      	blr	x8
    93e4:      	ldr	x24, [sp, #0x98]
    93e8:      	ldr	x21, [sp, #0x48]
    93ec:      	add	x2, x24, #0x20
    93f0:      	stp	x2, x24, [sp, #0x50]
    93f4:      	ldr	x8, [sp, #0x30]
    93f8:      	cmp	x21, x8
    93fc:      	b.ne	0x940c <generic_rawtp_path+0x30c>
    9400:      	ldr	x8, [sp, #0x38]
    9404:      	cmp	x2, x8
    9408:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    940c:      	mov	w8, #0x4                // =4
    9410:      	add	x0, sp, #0x70
    9414:      	mov	w1, #0x8                // =8
    9418:      	blr	x8
    941c:      	ldr	x8, [sp, #0x70]
    9420:      	cmp	x21, x8
    9424:      	b.eq	0x9520 <generic_rawtp_path+0x420>
    9428:      	add	x23, x21, #0x18
    942c:      	mov	w8, #0x4                // =4
    9430:      	add	x9, sp, #0x98
    9434:      	add	x0, sp, #0x98
    9438:      	mov	w1, #0x8                // =8
    943c:      	mov	x2, x23
    9440:      	blr	x8
    9444:      	ldr	x8, [sp, #0x98]
    9448:      	cmp	x8, x21
    944c:      	b.eq	0x9520 <generic_rawtp_path+0x420>
    9450:      	mov	w8, #0x4                // =4
    9454:      	add	x9, sp, #0x78
    9458:      	add	x0, sp, #0x78
    945c:      	mov	w1, #0x8                // =8
    9460:      	mov	x2, x23
    9464:      	blr	x8
    9468:      	add	x2, x21, #0x20
    946c:      	mov	w8, #0x4                // =4
    9470:      	mov	w9, #0x10               // =16
    9474:      	add	x10, sp, #0x80
    9478:      	add	x0, sp, #0x80
    947c:      	mov	w1, #0x10               // =16
    9480:      	blr	x8
    9484:      	ldr	w21, [sp, #0x84]
    9488:      	ldr	x8, [sp, #0x40]
    948c:      	ldr	x10, [sp, #0x60]
    9490:      	sub	x12, x10, x8
    9494:      	ldr	w23, [sp, #0x68]
    9498:      	subs	w10, w21, w23
    949c:      	ldr	x9, [sp, #0x88]
    94a0:      	csel	w10, wzr, w10, lo
    94a4:      	cmp	w23, w21
    94a8:      	csel	w11, w23, w21, lo
    94ac:      	cinc	w13, w11, hi
    94b0:      	sub	w14, w23, w13
    94b4:      	subs	x12, x12, x13
    94b8:      	str	w14, [sp, #0x68]
    94bc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    94c0:      	cmp	x12, #0xfff
    94c4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    94c8:      	cmp	w23, w21
    94cc:      	b.ls	0x94d8 <generic_rawtp_path+0x3d8>
    94d0:      	mov	w13, #0x2f              // =47
    94d4:      	strb	w13, [x8, x12]
    94d8:      	add	x19, x8, x12
    94dc:      	cmp	w23, w21
    94e0:      	add	x2, x9, x10
    94e4:      	and	w1, w11, #0xff
    94e8:      	mov	w8, #0x4                // =4
    94ec:      	cinc	x0, x19, hi
    94f0:      	blr	x8
    94f4:      	cmp	w23, w21
    94f8:      	str	x19, [sp, #0x60]
    94fc:      	add	x19, sp, #0x70
    9500:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    9504:      	ldr	x21, [sp, #0x78]
    9508:      	ldp	x2, x24, [sp, #0x50]
    950c:      	str	x21, [sp, #0x48]
    9510:      	ldr	x8, [sp, #0x30]
    9514:      	cmp	x21, x8
    9518:      	b.eq	0x9578 <generic_rawtp_path+0x478>
    951c:      	b	0x9584 <generic_rawtp_path+0x484>
    9520:      	add	x2, x24, #0x10
    9524:      	mov	w8, #0x4                // =4
    9528:      	add	x9, sp, #0x98
    952c:      	add	x0, sp, #0x98
    9530:      	mov	w1, #0x8                // =8
    9534:      	blr	x8
    9538:      	ldr	x8, [sp, #0x58]
    953c:      	ldr	x9, [sp, #0x98]
    9540:      	cmp	x8, x9
    9544:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9548:      	add	x2, x24, #0x18
    954c:      	mov	w8, #0x4                // =4
    9550:      	mov	x0, x22
    9554:      	mov	w1, #0x8                // =8
    9558:      	blr	x8
    955c:      	ldr	x24, [sp, #0x98]
    9560:      	ldr	x21, [sp, #0x48]
    9564:      	add	x2, x24, #0x20
    9568:      	stp	x2, x24, [sp, #0x50]
    956c:      	ldr	x8, [sp, #0x30]
    9570:      	cmp	x21, x8
    9574:      	b.ne	0x9584 <generic_rawtp_path+0x484>
    9578:      	ldr	x8, [sp, #0x38]
    957c:      	cmp	x2, x8
    9580:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9584:      	mov	w8, #0x4                // =4
    9588:      	add	x0, sp, #0x70
    958c:      	mov	w1, #0x8                // =8
    9590:      	blr	x8
    9594:      	ldr	x8, [sp, #0x70]
    9598:      	cmp	x21, x8
    959c:      	b.eq	0x9698 <generic_rawtp_path+0x598>
    95a0:      	add	x23, x21, #0x18
    95a4:      	mov	w8, #0x4                // =4
    95a8:      	add	x9, sp, #0x98
    95ac:      	add	x0, sp, #0x98
    95b0:      	mov	w1, #0x8                // =8
    95b4:      	mov	x2, x23
    95b8:      	blr	x8
    95bc:      	ldr	x8, [sp, #0x98]
    95c0:      	cmp	x8, x21
    95c4:      	b.eq	0x9698 <generic_rawtp_path+0x598>
    95c8:      	mov	w8, #0x4                // =4
    95cc:      	add	x9, sp, #0x78
    95d0:      	add	x0, sp, #0x78
    95d4:      	mov	w1, #0x8                // =8
    95d8:      	mov	x2, x23
    95dc:      	blr	x8
    95e0:      	add	x2, x21, #0x20
    95e4:      	mov	w8, #0x4                // =4
    95e8:      	mov	w9, #0x10               // =16
    95ec:      	add	x10, sp, #0x80
    95f0:      	add	x0, sp, #0x80
    95f4:      	mov	w1, #0x10               // =16
    95f8:      	blr	x8
    95fc:      	ldr	w21, [sp, #0x84]
    9600:      	ldr	x8, [sp, #0x40]
    9604:      	ldr	x10, [sp, #0x60]
    9608:      	sub	x12, x10, x8
    960c:      	ldr	w23, [sp, #0x68]
    9610:      	subs	w10, w21, w23
    9614:      	ldr	x9, [sp, #0x88]
    9618:      	csel	w10, wzr, w10, lo
    961c:      	cmp	w23, w21
    9620:      	csel	w11, w23, w21, lo
    9624:      	cinc	w13, w11, hi
    9628:      	sub	w14, w23, w13
    962c:      	subs	x12, x12, x13
    9630:      	str	w14, [sp, #0x68]
    9634:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9638:      	cmp	x12, #0xfff
    963c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9640:      	cmp	w23, w21
    9644:      	b.ls	0x9650 <generic_rawtp_path+0x550>
    9648:      	mov	w13, #0x2f              // =47
    964c:      	strb	w13, [x8, x12]
    9650:      	add	x19, x8, x12
    9654:      	cmp	w23, w21
    9658:      	add	x2, x9, x10
    965c:      	and	w1, w11, #0xff
    9660:      	mov	w8, #0x4                // =4
    9664:      	cinc	x0, x19, hi
    9668:      	blr	x8
    966c:      	cmp	w23, w21
    9670:      	str	x19, [sp, #0x60]
    9674:      	add	x19, sp, #0x70
    9678:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    967c:      	ldr	x21, [sp, #0x78]
    9680:      	ldp	x2, x24, [sp, #0x50]
    9684:      	str	x21, [sp, #0x48]
    9688:      	ldr	x8, [sp, #0x30]
    968c:      	cmp	x21, x8
    9690:      	b.eq	0x96f0 <generic_rawtp_path+0x5f0>
    9694:      	b	0x96fc <generic_rawtp_path+0x5fc>
    9698:      	add	x2, x24, #0x10
    969c:      	mov	w8, #0x4                // =4
    96a0:      	add	x9, sp, #0x98
    96a4:      	add	x0, sp, #0x98
    96a8:      	mov	w1, #0x8                // =8
    96ac:      	blr	x8
    96b0:      	ldr	x8, [sp, #0x58]
    96b4:      	ldr	x9, [sp, #0x98]
    96b8:      	cmp	x8, x9
    96bc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    96c0:      	add	x2, x24, #0x18
    96c4:      	mov	w8, #0x4                // =4
    96c8:      	mov	x0, x22
    96cc:      	mov	w1, #0x8                // =8
    96d0:      	blr	x8
    96d4:      	ldr	x24, [sp, #0x98]
    96d8:      	ldr	x21, [sp, #0x48]
    96dc:      	add	x2, x24, #0x20
    96e0:      	stp	x2, x24, [sp, #0x50]
    96e4:      	ldr	x8, [sp, #0x30]
    96e8:      	cmp	x21, x8
    96ec:      	b.ne	0x96fc <generic_rawtp_path+0x5fc>
    96f0:      	ldr	x8, [sp, #0x38]
    96f4:      	cmp	x2, x8
    96f8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    96fc:      	mov	w8, #0x4                // =4
    9700:      	add	x0, sp, #0x70
    9704:      	mov	w1, #0x8                // =8
    9708:      	blr	x8
    970c:      	ldr	x8, [sp, #0x70]
    9710:      	cmp	x21, x8
    9714:      	b.eq	0x9810 <generic_rawtp_path+0x710>
    9718:      	add	x23, x21, #0x18
    971c:      	mov	w8, #0x4                // =4
    9720:      	add	x9, sp, #0x98
    9724:      	add	x0, sp, #0x98
    9728:      	mov	w1, #0x8                // =8
    972c:      	mov	x2, x23
    9730:      	blr	x8
    9734:      	ldr	x8, [sp, #0x98]
    9738:      	cmp	x8, x21
    973c:      	b.eq	0x9810 <generic_rawtp_path+0x710>
    9740:      	mov	w8, #0x4                // =4
    9744:      	add	x9, sp, #0x78
    9748:      	add	x0, sp, #0x78
    974c:      	mov	w1, #0x8                // =8
    9750:      	mov	x2, x23
    9754:      	blr	x8
    9758:      	add	x2, x21, #0x20
    975c:      	mov	w8, #0x4                // =4
    9760:      	mov	w9, #0x10               // =16
    9764:      	add	x10, sp, #0x80
    9768:      	add	x0, sp, #0x80
    976c:      	mov	w1, #0x10               // =16
    9770:      	blr	x8
    9774:      	ldr	w21, [sp, #0x84]
    9778:      	ldr	x8, [sp, #0x40]
    977c:      	ldr	x10, [sp, #0x60]
    9780:      	sub	x12, x10, x8
    9784:      	ldr	w23, [sp, #0x68]
    9788:      	subs	w10, w21, w23
    978c:      	ldr	x9, [sp, #0x88]
    9790:      	csel	w10, wzr, w10, lo
    9794:      	cmp	w23, w21
    9798:      	csel	w11, w23, w21, lo
    979c:      	cinc	w13, w11, hi
    97a0:      	sub	w14, w23, w13
    97a4:      	subs	x12, x12, x13
    97a8:      	str	w14, [sp, #0x68]
    97ac:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    97b0:      	cmp	x12, #0xfff
    97b4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    97b8:      	cmp	w23, w21
    97bc:      	b.ls	0x97c8 <generic_rawtp_path+0x6c8>
    97c0:      	mov	w13, #0x2f              // =47
    97c4:      	strb	w13, [x8, x12]
    97c8:      	add	x19, x8, x12
    97cc:      	cmp	w23, w21
    97d0:      	add	x2, x9, x10
    97d4:      	and	w1, w11, #0xff
    97d8:      	mov	w8, #0x4                // =4
    97dc:      	cinc	x0, x19, hi
    97e0:      	blr	x8
    97e4:      	cmp	w23, w21
    97e8:      	str	x19, [sp, #0x60]
    97ec:      	add	x19, sp, #0x70
    97f0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    97f4:      	ldr	x21, [sp, #0x78]
    97f8:      	ldp	x2, x24, [sp, #0x50]
    97fc:      	str	x21, [sp, #0x48]
    9800:      	ldr	x8, [sp, #0x30]
    9804:      	cmp	x21, x8
    9808:      	b.eq	0x9868 <generic_rawtp_path+0x768>
    980c:      	b	0x9874 <generic_rawtp_path+0x774>
    9810:      	add	x2, x24, #0x10
    9814:      	mov	w8, #0x4                // =4
    9818:      	add	x9, sp, #0x98
    981c:      	add	x0, sp, #0x98
    9820:      	mov	w1, #0x8                // =8
    9824:      	blr	x8
    9828:      	ldr	x8, [sp, #0x58]
    982c:      	ldr	x9, [sp, #0x98]
    9830:      	cmp	x8, x9
    9834:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9838:      	add	x2, x24, #0x18
    983c:      	mov	w8, #0x4                // =4
    9840:      	mov	x0, x22
    9844:      	mov	w1, #0x8                // =8
    9848:      	blr	x8
    984c:      	ldr	x24, [sp, #0x98]
    9850:      	ldr	x21, [sp, #0x48]
    9854:      	add	x2, x24, #0x20
    9858:      	stp	x2, x24, [sp, #0x50]
    985c:      	ldr	x8, [sp, #0x30]
    9860:      	cmp	x21, x8
    9864:      	b.ne	0x9874 <generic_rawtp_path+0x774>
    9868:      	ldr	x8, [sp, #0x38]
    986c:      	cmp	x2, x8
    9870:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9874:      	mov	w8, #0x4                // =4
    9878:      	add	x0, sp, #0x70
    987c:      	mov	w1, #0x8                // =8
    9880:      	blr	x8
    9884:      	ldr	x8, [sp, #0x70]
    9888:      	cmp	x21, x8
    988c:      	b.eq	0x9988 <generic_rawtp_path+0x888>
    9890:      	add	x23, x21, #0x18
    9894:      	mov	w8, #0x4                // =4
    9898:      	add	x9, sp, #0x98
    989c:      	add	x0, sp, #0x98
    98a0:      	mov	w1, #0x8                // =8
    98a4:      	mov	x2, x23
    98a8:      	blr	x8
    98ac:      	ldr	x8, [sp, #0x98]
    98b0:      	cmp	x8, x21
    98b4:      	b.eq	0x9988 <generic_rawtp_path+0x888>
    98b8:      	mov	w8, #0x4                // =4
    98bc:      	add	x9, sp, #0x78
    98c0:      	add	x0, sp, #0x78
    98c4:      	mov	w1, #0x8                // =8
    98c8:      	mov	x2, x23
    98cc:      	blr	x8
    98d0:      	add	x2, x21, #0x20
    98d4:      	mov	w8, #0x4                // =4
    98d8:      	mov	w9, #0x10               // =16
    98dc:      	add	x10, sp, #0x80
    98e0:      	add	x0, sp, #0x80
    98e4:      	mov	w1, #0x10               // =16
    98e8:      	blr	x8
    98ec:      	ldr	w21, [sp, #0x84]
    98f0:      	ldr	x8, [sp, #0x40]
    98f4:      	ldr	x10, [sp, #0x60]
    98f8:      	sub	x12, x10, x8
    98fc:      	ldr	w23, [sp, #0x68]
    9900:      	subs	w10, w21, w23
    9904:      	ldr	x9, [sp, #0x88]
    9908:      	csel	w10, wzr, w10, lo
    990c:      	cmp	w23, w21
    9910:      	csel	w11, w23, w21, lo
    9914:      	cinc	w13, w11, hi
    9918:      	sub	w14, w23, w13
    991c:      	subs	x12, x12, x13
    9920:      	str	w14, [sp, #0x68]
    9924:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9928:      	cmp	x12, #0xfff
    992c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9930:      	cmp	w23, w21
    9934:      	b.ls	0x9940 <generic_rawtp_path+0x840>
    9938:      	mov	w13, #0x2f              // =47
    993c:      	strb	w13, [x8, x12]
    9940:      	add	x19, x8, x12
    9944:      	cmp	w23, w21
    9948:      	add	x2, x9, x10
    994c:      	and	w1, w11, #0xff
    9950:      	mov	w8, #0x4                // =4
    9954:      	cinc	x0, x19, hi
    9958:      	blr	x8
    995c:      	cmp	w23, w21
    9960:      	str	x19, [sp, #0x60]
    9964:      	add	x19, sp, #0x70
    9968:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    996c:      	ldr	x21, [sp, #0x78]
    9970:      	ldp	x2, x24, [sp, #0x50]
    9974:      	str	x21, [sp, #0x48]
    9978:      	ldr	x8, [sp, #0x30]
    997c:      	cmp	x21, x8
    9980:      	b.eq	0x99e0 <generic_rawtp_path+0x8e0>
    9984:      	b	0x99ec <generic_rawtp_path+0x8ec>
    9988:      	add	x2, x24, #0x10
    998c:      	mov	w8, #0x4                // =4
    9990:      	add	x9, sp, #0x98
    9994:      	add	x0, sp, #0x98
    9998:      	mov	w1, #0x8                // =8
    999c:      	blr	x8
    99a0:      	ldr	x8, [sp, #0x58]
    99a4:      	ldr	x9, [sp, #0x98]
    99a8:      	cmp	x8, x9
    99ac:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    99b0:      	add	x2, x24, #0x18
    99b4:      	mov	w8, #0x4                // =4
    99b8:      	mov	x0, x22
    99bc:      	mov	w1, #0x8                // =8
    99c0:      	blr	x8
    99c4:      	ldr	x24, [sp, #0x98]
    99c8:      	ldr	x21, [sp, #0x48]
    99cc:      	add	x2, x24, #0x20
    99d0:      	stp	x2, x24, [sp, #0x50]
    99d4:      	ldr	x8, [sp, #0x30]
    99d8:      	cmp	x21, x8
    99dc:      	b.ne	0x99ec <generic_rawtp_path+0x8ec>
    99e0:      	ldr	x8, [sp, #0x38]
    99e4:      	cmp	x2, x8
    99e8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    99ec:      	mov	w8, #0x4                // =4
    99f0:      	add	x0, sp, #0x70
    99f4:      	mov	w1, #0x8                // =8
    99f8:      	blr	x8
    99fc:      	ldr	x8, [sp, #0x70]
    9a00:      	cmp	x21, x8
    9a04:      	b.eq	0x9b00 <generic_rawtp_path+0xa00>
    9a08:      	add	x23, x21, #0x18
    9a0c:      	mov	w8, #0x4                // =4
    9a10:      	add	x9, sp, #0x98
    9a14:      	add	x0, sp, #0x98
    9a18:      	mov	w1, #0x8                // =8
    9a1c:      	mov	x2, x23
    9a20:      	blr	x8
    9a24:      	ldr	x8, [sp, #0x98]
    9a28:      	cmp	x8, x21
    9a2c:      	b.eq	0x9b00 <generic_rawtp_path+0xa00>
    9a30:      	mov	w8, #0x4                // =4
    9a34:      	add	x9, sp, #0x78
    9a38:      	add	x0, sp, #0x78
    9a3c:      	mov	w1, #0x8                // =8
    9a40:      	mov	x2, x23
    9a44:      	blr	x8
    9a48:      	add	x2, x21, #0x20
    9a4c:      	mov	w8, #0x4                // =4
    9a50:      	mov	w9, #0x10               // =16
    9a54:      	add	x10, sp, #0x80
    9a58:      	add	x0, sp, #0x80
    9a5c:      	mov	w1, #0x10               // =16
    9a60:      	blr	x8
    9a64:      	ldr	w21, [sp, #0x84]
    9a68:      	ldr	x8, [sp, #0x40]
    9a6c:      	ldr	x10, [sp, #0x60]
    9a70:      	sub	x12, x10, x8
    9a74:      	ldr	w23, [sp, #0x68]
    9a78:      	subs	w10, w21, w23
    9a7c:      	ldr	x9, [sp, #0x88]
    9a80:      	csel	w10, wzr, w10, lo
    9a84:      	cmp	w23, w21
    9a88:      	csel	w11, w23, w21, lo
    9a8c:      	cinc	w13, w11, hi
    9a90:      	sub	w14, w23, w13
    9a94:      	subs	x12, x12, x13
    9a98:      	str	w14, [sp, #0x68]
    9a9c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9aa0:      	cmp	x12, #0xfff
    9aa4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9aa8:      	cmp	w23, w21
    9aac:      	b.ls	0x9ab8 <generic_rawtp_path+0x9b8>
    9ab0:      	mov	w13, #0x2f              // =47
    9ab4:      	strb	w13, [x8, x12]
    9ab8:      	add	x19, x8, x12
    9abc:      	cmp	w23, w21
    9ac0:      	add	x2, x9, x10
    9ac4:      	and	w1, w11, #0xff
    9ac8:      	mov	w8, #0x4                // =4
    9acc:      	cinc	x0, x19, hi
    9ad0:      	blr	x8
    9ad4:      	cmp	w23, w21
    9ad8:      	str	x19, [sp, #0x60]
    9adc:      	add	x19, sp, #0x70
    9ae0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    9ae4:      	ldr	x21, [sp, #0x78]
    9ae8:      	ldp	x2, x24, [sp, #0x50]
    9aec:      	str	x21, [sp, #0x48]
    9af0:      	ldr	x8, [sp, #0x30]
    9af4:      	cmp	x21, x8
    9af8:      	b.eq	0x9b58 <generic_rawtp_path+0xa58>
    9afc:      	b	0x9b64 <generic_rawtp_path+0xa64>
    9b00:      	add	x2, x24, #0x10
    9b04:      	mov	w8, #0x4                // =4
    9b08:      	add	x9, sp, #0x98
    9b0c:      	add	x0, sp, #0x98
    9b10:      	mov	w1, #0x8                // =8
    9b14:      	blr	x8
    9b18:      	ldr	x8, [sp, #0x58]
    9b1c:      	ldr	x9, [sp, #0x98]
    9b20:      	cmp	x8, x9
    9b24:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9b28:      	add	x2, x24, #0x18
    9b2c:      	mov	w8, #0x4                // =4
    9b30:      	mov	x0, x22
    9b34:      	mov	w1, #0x8                // =8
    9b38:      	blr	x8
    9b3c:      	ldr	x24, [sp, #0x98]
    9b40:      	ldr	x21, [sp, #0x48]
    9b44:      	add	x2, x24, #0x20
    9b48:      	stp	x2, x24, [sp, #0x50]
    9b4c:      	ldr	x8, [sp, #0x30]
    9b50:      	cmp	x21, x8
    9b54:      	b.ne	0x9b64 <generic_rawtp_path+0xa64>
    9b58:      	ldr	x8, [sp, #0x38]
    9b5c:      	cmp	x2, x8
    9b60:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9b64:      	mov	w8, #0x4                // =4
    9b68:      	add	x0, sp, #0x70
    9b6c:      	mov	w1, #0x8                // =8
    9b70:      	blr	x8
    9b74:      	ldr	x8, [sp, #0x70]
    9b78:      	cmp	x21, x8
    9b7c:      	b.eq	0x9c78 <generic_rawtp_path+0xb78>
    9b80:      	add	x23, x21, #0x18
    9b84:      	mov	w8, #0x4                // =4
    9b88:      	add	x9, sp, #0x98
    9b8c:      	add	x0, sp, #0x98
    9b90:      	mov	w1, #0x8                // =8
    9b94:      	mov	x2, x23
    9b98:      	blr	x8
    9b9c:      	ldr	x8, [sp, #0x98]
    9ba0:      	cmp	x8, x21
    9ba4:      	b.eq	0x9c78 <generic_rawtp_path+0xb78>
    9ba8:      	mov	w8, #0x4                // =4
    9bac:      	add	x9, sp, #0x78
    9bb0:      	add	x0, sp, #0x78
    9bb4:      	mov	w1, #0x8                // =8
    9bb8:      	mov	x2, x23
    9bbc:      	blr	x8
    9bc0:      	add	x2, x21, #0x20
    9bc4:      	mov	w8, #0x4                // =4
    9bc8:      	mov	w9, #0x10               // =16
    9bcc:      	add	x10, sp, #0x80
    9bd0:      	add	x0, sp, #0x80
    9bd4:      	mov	w1, #0x10               // =16
    9bd8:      	blr	x8
    9bdc:      	ldr	w21, [sp, #0x84]
    9be0:      	ldr	x8, [sp, #0x40]
    9be4:      	ldr	x10, [sp, #0x60]
    9be8:      	sub	x12, x10, x8
    9bec:      	ldr	w23, [sp, #0x68]
    9bf0:      	subs	w10, w21, w23
    9bf4:      	ldr	x9, [sp, #0x88]
    9bf8:      	csel	w10, wzr, w10, lo
    9bfc:      	cmp	w23, w21
    9c00:      	csel	w11, w23, w21, lo
    9c04:      	cinc	w13, w11, hi
    9c08:      	sub	w14, w23, w13
    9c0c:      	subs	x12, x12, x13
    9c10:      	str	w14, [sp, #0x68]
    9c14:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9c18:      	cmp	x12, #0xfff
    9c1c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9c20:      	cmp	w23, w21
    9c24:      	b.ls	0x9c30 <generic_rawtp_path+0xb30>
    9c28:      	mov	w13, #0x2f              // =47
    9c2c:      	strb	w13, [x8, x12]
    9c30:      	add	x19, x8, x12
    9c34:      	cmp	w23, w21
    9c38:      	add	x2, x9, x10
    9c3c:      	and	w1, w11, #0xff
    9c40:      	mov	w8, #0x4                // =4
    9c44:      	cinc	x0, x19, hi
    9c48:      	blr	x8
    9c4c:      	cmp	w23, w21
    9c50:      	str	x19, [sp, #0x60]
    9c54:      	add	x19, sp, #0x70
    9c58:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    9c5c:      	ldr	x21, [sp, #0x78]
    9c60:      	ldp	x2, x24, [sp, #0x50]
    9c64:      	str	x21, [sp, #0x48]
    9c68:      	ldr	x8, [sp, #0x30]
    9c6c:      	cmp	x21, x8
    9c70:      	b.eq	0x9cd0 <generic_rawtp_path+0xbd0>
    9c74:      	b	0x9cdc <generic_rawtp_path+0xbdc>
    9c78:      	add	x2, x24, #0x10
    9c7c:      	mov	w8, #0x4                // =4
    9c80:      	add	x9, sp, #0x98
    9c84:      	add	x0, sp, #0x98
    9c88:      	mov	w1, #0x8                // =8
    9c8c:      	blr	x8
    9c90:      	ldr	x8, [sp, #0x58]
    9c94:      	ldr	x9, [sp, #0x98]
    9c98:      	cmp	x8, x9
    9c9c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9ca0:      	add	x2, x24, #0x18
    9ca4:      	mov	w8, #0x4                // =4
    9ca8:      	mov	x0, x22
    9cac:      	mov	w1, #0x8                // =8
    9cb0:      	blr	x8
    9cb4:      	ldr	x24, [sp, #0x98]
    9cb8:      	ldr	x21, [sp, #0x48]
    9cbc:      	add	x2, x24, #0x20
    9cc0:      	stp	x2, x24, [sp, #0x50]
    9cc4:      	ldr	x8, [sp, #0x30]
    9cc8:      	cmp	x21, x8
    9ccc:      	b.ne	0x9cdc <generic_rawtp_path+0xbdc>
    9cd0:      	ldr	x8, [sp, #0x38]
    9cd4:      	cmp	x2, x8
    9cd8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9cdc:      	mov	w8, #0x4                // =4
    9ce0:      	add	x0, sp, #0x70
    9ce4:      	mov	w1, #0x8                // =8
    9ce8:      	blr	x8
    9cec:      	ldr	x8, [sp, #0x70]
    9cf0:      	cmp	x21, x8
    9cf4:      	b.eq	0x9df0 <generic_rawtp_path+0xcf0>
    9cf8:      	add	x23, x21, #0x18
    9cfc:      	mov	w8, #0x4                // =4
    9d00:      	add	x9, sp, #0x98
    9d04:      	add	x0, sp, #0x98
    9d08:      	mov	w1, #0x8                // =8
    9d0c:      	mov	x2, x23
    9d10:      	blr	x8
    9d14:      	ldr	x8, [sp, #0x98]
    9d18:      	cmp	x8, x21
    9d1c:      	b.eq	0x9df0 <generic_rawtp_path+0xcf0>
    9d20:      	mov	w8, #0x4                // =4
    9d24:      	add	x9, sp, #0x78
    9d28:      	add	x0, sp, #0x78
    9d2c:      	mov	w1, #0x8                // =8
    9d30:      	mov	x2, x23
    9d34:      	blr	x8
    9d38:      	add	x2, x21, #0x20
    9d3c:      	mov	w8, #0x4                // =4
    9d40:      	mov	w9, #0x10               // =16
    9d44:      	add	x10, sp, #0x80
    9d48:      	add	x0, sp, #0x80
    9d4c:      	mov	w1, #0x10               // =16
    9d50:      	blr	x8
    9d54:      	ldr	w21, [sp, #0x84]
    9d58:      	ldr	x8, [sp, #0x40]
    9d5c:      	ldr	x10, [sp, #0x60]
    9d60:      	sub	x12, x10, x8
    9d64:      	ldr	w23, [sp, #0x68]
    9d68:      	subs	w10, w21, w23
    9d6c:      	ldr	x9, [sp, #0x88]
    9d70:      	csel	w10, wzr, w10, lo
    9d74:      	cmp	w23, w21
    9d78:      	csel	w11, w23, w21, lo
    9d7c:      	cinc	w13, w11, hi
    9d80:      	sub	w14, w23, w13
    9d84:      	subs	x12, x12, x13
    9d88:      	str	w14, [sp, #0x68]
    9d8c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9d90:      	cmp	x12, #0xfff
    9d94:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9d98:      	cmp	w23, w21
    9d9c:      	b.ls	0x9da8 <generic_rawtp_path+0xca8>
    9da0:      	mov	w13, #0x2f              // =47
    9da4:      	strb	w13, [x8, x12]
    9da8:      	add	x19, x8, x12
    9dac:      	cmp	w23, w21
    9db0:      	add	x2, x9, x10
    9db4:      	and	w1, w11, #0xff
    9db8:      	mov	w8, #0x4                // =4
    9dbc:      	cinc	x0, x19, hi
    9dc0:      	blr	x8
    9dc4:      	cmp	w23, w21
    9dc8:      	str	x19, [sp, #0x60]
    9dcc:      	add	x19, sp, #0x70
    9dd0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    9dd4:      	ldr	x21, [sp, #0x78]
    9dd8:      	ldp	x2, x24, [sp, #0x50]
    9ddc:      	str	x21, [sp, #0x48]
    9de0:      	ldr	x8, [sp, #0x30]
    9de4:      	cmp	x21, x8
    9de8:      	b.eq	0x9e48 <generic_rawtp_path+0xd48>
    9dec:      	b	0x9e54 <generic_rawtp_path+0xd54>
    9df0:      	add	x2, x24, #0x10
    9df4:      	mov	w8, #0x4                // =4
    9df8:      	add	x9, sp, #0x98
    9dfc:      	add	x0, sp, #0x98
    9e00:      	mov	w1, #0x8                // =8
    9e04:      	blr	x8
    9e08:      	ldr	x8, [sp, #0x58]
    9e0c:      	ldr	x9, [sp, #0x98]
    9e10:      	cmp	x8, x9
    9e14:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9e18:      	add	x2, x24, #0x18
    9e1c:      	mov	w8, #0x4                // =4
    9e20:      	mov	x0, x22
    9e24:      	mov	w1, #0x8                // =8
    9e28:      	blr	x8
    9e2c:      	ldr	x24, [sp, #0x98]
    9e30:      	ldr	x21, [sp, #0x48]
    9e34:      	add	x2, x24, #0x20
    9e38:      	stp	x2, x24, [sp, #0x50]
    9e3c:      	ldr	x8, [sp, #0x30]
    9e40:      	cmp	x21, x8
    9e44:      	b.ne	0x9e54 <generic_rawtp_path+0xd54>
    9e48:      	ldr	x8, [sp, #0x38]
    9e4c:      	cmp	x2, x8
    9e50:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9e54:      	mov	w8, #0x4                // =4
    9e58:      	add	x0, sp, #0x70
    9e5c:      	mov	w1, #0x8                // =8
    9e60:      	blr	x8
    9e64:      	ldr	x8, [sp, #0x70]
    9e68:      	cmp	x21, x8
    9e6c:      	b.eq	0x9f68 <generic_rawtp_path+0xe68>
    9e70:      	add	x23, x21, #0x18
    9e74:      	mov	w8, #0x4                // =4
    9e78:      	add	x9, sp, #0x98
    9e7c:      	add	x0, sp, #0x98
    9e80:      	mov	w1, #0x8                // =8
    9e84:      	mov	x2, x23
    9e88:      	blr	x8
    9e8c:      	ldr	x8, [sp, #0x98]
    9e90:      	cmp	x8, x21
    9e94:      	b.eq	0x9f68 <generic_rawtp_path+0xe68>
    9e98:      	mov	w8, #0x4                // =4
    9e9c:      	add	x9, sp, #0x78
    9ea0:      	add	x0, sp, #0x78
    9ea4:      	mov	w1, #0x8                // =8
    9ea8:      	mov	x2, x23
    9eac:      	blr	x8
    9eb0:      	add	x2, x21, #0x20
    9eb4:      	mov	w8, #0x4                // =4
    9eb8:      	mov	w9, #0x10               // =16
    9ebc:      	add	x10, sp, #0x80
    9ec0:      	add	x0, sp, #0x80
    9ec4:      	mov	w1, #0x10               // =16
    9ec8:      	blr	x8
    9ecc:      	ldr	w21, [sp, #0x84]
    9ed0:      	ldr	x8, [sp, #0x40]
    9ed4:      	ldr	x10, [sp, #0x60]
    9ed8:      	sub	x12, x10, x8
    9edc:      	ldr	w23, [sp, #0x68]
    9ee0:      	subs	w10, w21, w23
    9ee4:      	ldr	x9, [sp, #0x88]
    9ee8:      	csel	w10, wzr, w10, lo
    9eec:      	cmp	w23, w21
    9ef0:      	csel	w11, w23, w21, lo
    9ef4:      	cinc	w13, w11, hi
    9ef8:      	sub	w14, w23, w13
    9efc:      	subs	x12, x12, x13
    9f00:      	str	w14, [sp, #0x68]
    9f04:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    9f08:      	cmp	x12, #0xfff
    9f0c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    9f10:      	cmp	w23, w21
    9f14:      	b.ls	0x9f20 <generic_rawtp_path+0xe20>
    9f18:      	mov	w13, #0x2f              // =47
    9f1c:      	strb	w13, [x8, x12]
    9f20:      	add	x19, x8, x12
    9f24:      	cmp	w23, w21
    9f28:      	add	x2, x9, x10
    9f2c:      	and	w1, w11, #0xff
    9f30:      	mov	w8, #0x4                // =4
    9f34:      	cinc	x0, x19, hi
    9f38:      	blr	x8
    9f3c:      	cmp	w23, w21
    9f40:      	str	x19, [sp, #0x60]
    9f44:      	add	x19, sp, #0x70
    9f48:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    9f4c:      	ldr	x21, [sp, #0x78]
    9f50:      	ldp	x2, x24, [sp, #0x50]
    9f54:      	str	x21, [sp, #0x48]
    9f58:      	ldr	x8, [sp, #0x30]
    9f5c:      	cmp	x21, x8
    9f60:      	b.eq	0x9fc0 <generic_rawtp_path+0xec0>
    9f64:      	b	0x9fcc <generic_rawtp_path+0xecc>
    9f68:      	add	x2, x24, #0x10
    9f6c:      	mov	w8, #0x4                // =4
    9f70:      	add	x9, sp, #0x98
    9f74:      	add	x0, sp, #0x98
    9f78:      	mov	w1, #0x8                // =8
    9f7c:      	blr	x8
    9f80:      	ldr	x8, [sp, #0x58]
    9f84:      	ldr	x9, [sp, #0x98]
    9f88:      	cmp	x8, x9
    9f8c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9f90:      	add	x2, x24, #0x18
    9f94:      	mov	w8, #0x4                // =4
    9f98:      	mov	x0, x22
    9f9c:      	mov	w1, #0x8                // =8
    9fa0:      	blr	x8
    9fa4:      	ldr	x24, [sp, #0x98]
    9fa8:      	ldr	x21, [sp, #0x48]
    9fac:      	add	x2, x24, #0x20
    9fb0:      	stp	x2, x24, [sp, #0x50]
    9fb4:      	ldr	x8, [sp, #0x30]
    9fb8:      	cmp	x21, x8
    9fbc:      	b.ne	0x9fcc <generic_rawtp_path+0xecc>
    9fc0:      	ldr	x8, [sp, #0x38]
    9fc4:      	cmp	x2, x8
    9fc8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    9fcc:      	mov	w8, #0x4                // =4
    9fd0:      	add	x0, sp, #0x70
    9fd4:      	mov	w1, #0x8                // =8
    9fd8:      	blr	x8
    9fdc:      	ldr	x8, [sp, #0x70]
    9fe0:      	cmp	x21, x8
    9fe4:      	b.eq	0xa0d4 <generic_rawtp_path+0xfd4>
    9fe8:      	add	x23, x21, #0x18
    9fec:      	mov	w8, #0x4                // =4
    9ff0:      	add	x9, sp, #0x98
    9ff4:      	add	x0, sp, #0x98
    9ff8:      	mov	w1, #0x8                // =8
    9ffc:      	mov	x2, x23
    a000:      	blr	x8
    a004:      	ldr	x8, [sp, #0x98]
    a008:      	cmp	x8, x21
    a00c:      	b.eq	0xa0d4 <generic_rawtp_path+0xfd4>
    a010:      	mov	w8, #0x4                // =4
    a014:      	add	x9, sp, #0x78
    a018:      	add	x0, sp, #0x78
    a01c:      	mov	w1, #0x8                // =8
    a020:      	mov	x2, x23
    a024:      	blr	x8
    a028:      	add	x2, x21, #0x20
    a02c:      	mov	w8, #0x4                // =4
    a030:      	mov	w9, #0x10               // =16
    a034:      	add	x10, sp, #0x80
    a038:      	add	x0, sp, #0x80
    a03c:      	mov	w1, #0x10               // =16
    a040:      	blr	x8
    a044:      	ldr	w21, [sp, #0x84]
    a048:      	ldr	x8, [sp, #0x40]
    a04c:      	ldr	x10, [sp, #0x60]
    a050:      	sub	x12, x10, x8
    a054:      	ldr	w23, [sp, #0x68]
    a058:      	subs	w10, w21, w23
    a05c:      	ldr	x9, [sp, #0x88]
    a060:      	csel	w10, wzr, w10, lo
    a064:      	cmp	w23, w21
    a068:      	csel	w11, w23, w21, lo
    a06c:      	cinc	w13, w11, hi
    a070:      	sub	w14, w23, w13
    a074:      	subs	x12, x12, x13
    a078:      	str	w14, [sp, #0x68]
    a07c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a080:      	cmp	x12, #0xfff
    a084:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a088:      	cmp	w23, w21
    a08c:      	b.ls	0xa098 <generic_rawtp_path+0xf98>
    a090:      	mov	w13, #0x2f              // =47
    a094:      	strb	w13, [x8, x12]
    a098:      	add	x19, x8, x12
    a09c:      	cmp	w23, w21
    a0a0:      	add	x2, x9, x10
    a0a4:      	and	w1, w11, #0xff
    a0a8:      	mov	w8, #0x4                // =4
    a0ac:      	cinc	x0, x19, hi
    a0b0:      	blr	x8
    a0b4:      	cmp	w23, w21
    a0b8:      	str	x19, [sp, #0x60]
    a0bc:      	add	x19, sp, #0x70
    a0c0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a0c4:      	ldr	x21, [sp, #0x78]
    a0c8:      	ldp	x2, x24, [sp, #0x50]
    a0cc:      	str	x21, [sp, #0x48]
    a0d0:      	b	0xa120 <generic_rawtp_path+0x1020>
    a0d4:      	add	x2, x24, #0x10
    a0d8:      	mov	w8, #0x4                // =4
    a0dc:      	add	x9, sp, #0x98
    a0e0:      	add	x0, sp, #0x98
    a0e4:      	mov	w1, #0x8                // =8
    a0e8:      	blr	x8
    a0ec:      	ldr	x8, [sp, #0x58]
    a0f0:      	ldr	x9, [sp, #0x98]
    a0f4:      	cmp	x8, x9
    a0f8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a0fc:      	add	x2, x24, #0x18
    a100:      	mov	w8, #0x4                // =4
    a104:      	mov	x0, x22
    a108:      	mov	w1, #0x8                // =8
    a10c:      	blr	x8
    a110:      	ldr	x24, [sp, #0x98]
    a114:      	ldr	x21, [sp, #0x48]
    a118:      	add	x2, x24, #0x20
    a11c:      	stp	x2, x24, [sp, #0x50]
    a120:      	ldr	x8, [sp, #0x30]
    a124:      	cmp	x21, x8
    a128:      	b.ne	0xa138 <generic_rawtp_path+0x1038>
    a12c:      	ldr	x8, [sp, #0x38]
    a130:      	cmp	x2, x8
    a134:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a138:      	mov	w8, #0x4                // =4
    a13c:      	add	x0, sp, #0x70
    a140:      	mov	w1, #0x8                // =8
    a144:      	blr	x8
    a148:      	ldr	x8, [sp, #0x70]
    a14c:      	cmp	x21, x8
    a150:      	b.eq	0xa240 <generic_rawtp_path+0x1140>
    a154:      	add	x23, x21, #0x18
    a158:      	mov	w8, #0x4                // =4
    a15c:      	add	x9, sp, #0x98
    a160:      	add	x0, sp, #0x98
    a164:      	mov	w1, #0x8                // =8
    a168:      	mov	x2, x23
    a16c:      	blr	x8
    a170:      	ldr	x8, [sp, #0x98]
    a174:      	cmp	x8, x21
    a178:      	b.eq	0xa240 <generic_rawtp_path+0x1140>
    a17c:      	mov	w8, #0x4                // =4
    a180:      	add	x9, sp, #0x78
    a184:      	add	x0, sp, #0x78
    a188:      	mov	w1, #0x8                // =8
    a18c:      	mov	x2, x23
    a190:      	blr	x8
    a194:      	add	x2, x21, #0x20
    a198:      	mov	w8, #0x4                // =4
    a19c:      	mov	w9, #0x10               // =16
    a1a0:      	add	x10, sp, #0x80
    a1a4:      	add	x0, sp, #0x80
    a1a8:      	mov	w1, #0x10               // =16
    a1ac:      	blr	x8
    a1b0:      	ldr	w21, [sp, #0x84]
    a1b4:      	ldr	x8, [sp, #0x40]
    a1b8:      	ldr	x10, [sp, #0x60]
    a1bc:      	sub	x12, x10, x8
    a1c0:      	ldr	w23, [sp, #0x68]
    a1c4:      	subs	w10, w21, w23
    a1c8:      	ldr	x9, [sp, #0x88]
    a1cc:      	csel	w10, wzr, w10, lo
    a1d0:      	cmp	w23, w21
    a1d4:      	csel	w11, w23, w21, lo
    a1d8:      	cinc	w13, w11, hi
    a1dc:      	sub	w14, w23, w13
    a1e0:      	subs	x12, x12, x13
    a1e4:      	str	w14, [sp, #0x68]
    a1e8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a1ec:      	cmp	x12, #0xfff
    a1f0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a1f4:      	cmp	w23, w21
    a1f8:      	b.ls	0xa204 <generic_rawtp_path+0x1104>
    a1fc:      	mov	w13, #0x2f              // =47
    a200:      	strb	w13, [x8, x12]
    a204:      	add	x19, x8, x12
    a208:      	cmp	w23, w21
    a20c:      	add	x2, x9, x10
    a210:      	and	w1, w11, #0xff
    a214:      	mov	w8, #0x4                // =4
    a218:      	cinc	x0, x19, hi
    a21c:      	blr	x8
    a220:      	cmp	w23, w21
    a224:      	str	x19, [sp, #0x60]
    a228:      	add	x19, sp, #0x70
    a22c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a230:      	ldr	x21, [sp, #0x78]
    a234:      	ldp	x2, x24, [sp, #0x50]
    a238:      	str	x21, [sp, #0x48]
    a23c:      	b	0xa28c <generic_rawtp_path+0x118c>
    a240:      	add	x2, x24, #0x10
    a244:      	mov	w8, #0x4                // =4
    a248:      	add	x9, sp, #0x98
    a24c:      	add	x0, sp, #0x98
    a250:      	mov	w1, #0x8                // =8
    a254:      	blr	x8
    a258:      	ldr	x8, [sp, #0x58]
    a25c:      	ldr	x9, [sp, #0x98]
    a260:      	cmp	x8, x9
    a264:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a268:      	add	x2, x24, #0x18
    a26c:      	mov	w8, #0x4                // =4
    a270:      	mov	x0, x22
    a274:      	mov	w1, #0x8                // =8
    a278:      	blr	x8
    a27c:      	ldr	x24, [sp, #0x98]
    a280:      	ldr	x21, [sp, #0x48]
    a284:      	add	x2, x24, #0x20
    a288:      	stp	x2, x24, [sp, #0x50]
    a28c:      	ldr	x8, [sp, #0x30]
    a290:      	cmp	x21, x8
    a294:      	b.ne	0xa2a4 <generic_rawtp_path+0x11a4>
    a298:      	ldr	x8, [sp, #0x38]
    a29c:      	cmp	x2, x8
    a2a0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a2a4:      	mov	w8, #0x4                // =4
    a2a8:      	add	x0, sp, #0x70
    a2ac:      	mov	w1, #0x8                // =8
    a2b0:      	blr	x8
    a2b4:      	ldr	x8, [sp, #0x70]
    a2b8:      	cmp	x21, x8
    a2bc:      	b.eq	0xa3ac <generic_rawtp_path+0x12ac>
    a2c0:      	add	x23, x21, #0x18
    a2c4:      	mov	w8, #0x4                // =4
    a2c8:      	add	x9, sp, #0x98
    a2cc:      	add	x0, sp, #0x98
    a2d0:      	mov	w1, #0x8                // =8
    a2d4:      	mov	x2, x23
    a2d8:      	blr	x8
    a2dc:      	ldr	x8, [sp, #0x98]
    a2e0:      	cmp	x8, x21
    a2e4:      	b.eq	0xa3ac <generic_rawtp_path+0x12ac>
    a2e8:      	mov	w8, #0x4                // =4
    a2ec:      	add	x9, sp, #0x78
    a2f0:      	add	x0, sp, #0x78
    a2f4:      	mov	w1, #0x8                // =8
    a2f8:      	mov	x2, x23
    a2fc:      	blr	x8
    a300:      	add	x2, x21, #0x20
    a304:      	mov	w8, #0x4                // =4
    a308:      	mov	w9, #0x10               // =16
    a30c:      	add	x10, sp, #0x80
    a310:      	add	x0, sp, #0x80
    a314:      	mov	w1, #0x10               // =16
    a318:      	blr	x8
    a31c:      	ldr	w21, [sp, #0x84]
    a320:      	ldr	x8, [sp, #0x40]
    a324:      	ldr	x10, [sp, #0x60]
    a328:      	sub	x12, x10, x8
    a32c:      	ldr	w23, [sp, #0x68]
    a330:      	subs	w10, w21, w23
    a334:      	ldr	x9, [sp, #0x88]
    a338:      	csel	w10, wzr, w10, lo
    a33c:      	cmp	w23, w21
    a340:      	csel	w11, w23, w21, lo
    a344:      	cinc	w13, w11, hi
    a348:      	sub	w14, w23, w13
    a34c:      	subs	x12, x12, x13
    a350:      	str	w14, [sp, #0x68]
    a354:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a358:      	cmp	x12, #0xfff
    a35c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a360:      	cmp	w23, w21
    a364:      	b.ls	0xa370 <generic_rawtp_path+0x1270>
    a368:      	mov	w13, #0x2f              // =47
    a36c:      	strb	w13, [x8, x12]
    a370:      	add	x19, x8, x12
    a374:      	cmp	w23, w21
    a378:      	add	x2, x9, x10
    a37c:      	and	w1, w11, #0xff
    a380:      	mov	w8, #0x4                // =4
    a384:      	cinc	x0, x19, hi
    a388:      	blr	x8
    a38c:      	cmp	w23, w21
    a390:      	str	x19, [sp, #0x60]
    a394:      	add	x19, sp, #0x70
    a398:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a39c:      	ldr	x21, [sp, #0x78]
    a3a0:      	ldp	x2, x24, [sp, #0x50]
    a3a4:      	str	x21, [sp, #0x48]
    a3a8:      	b	0xa3f8 <generic_rawtp_path+0x12f8>
    a3ac:      	add	x2, x24, #0x10
    a3b0:      	mov	w8, #0x4                // =4
    a3b4:      	add	x9, sp, #0x98
    a3b8:      	add	x0, sp, #0x98
    a3bc:      	mov	w1, #0x8                // =8
    a3c0:      	blr	x8
    a3c4:      	ldr	x8, [sp, #0x58]
    a3c8:      	ldr	x9, [sp, #0x98]
    a3cc:      	cmp	x8, x9
    a3d0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a3d4:      	add	x2, x24, #0x18
    a3d8:      	mov	w8, #0x4                // =4
    a3dc:      	mov	x0, x22
    a3e0:      	mov	w1, #0x8                // =8
    a3e4:      	blr	x8
    a3e8:      	ldr	x24, [sp, #0x98]
    a3ec:      	ldr	x21, [sp, #0x48]
    a3f0:      	add	x2, x24, #0x20
    a3f4:      	stp	x2, x24, [sp, #0x50]
    a3f8:      	ldr	x8, [sp, #0x30]
    a3fc:      	cmp	x21, x8
    a400:      	b.ne	0xa410 <generic_rawtp_path+0x1310>
    a404:      	ldr	x8, [sp, #0x38]
    a408:      	cmp	x2, x8
    a40c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a410:      	mov	w8, #0x4                // =4
    a414:      	add	x0, sp, #0x70
    a418:      	mov	w1, #0x8                // =8
    a41c:      	blr	x8
    a420:      	ldr	x8, [sp, #0x70]
    a424:      	cmp	x21, x8
    a428:      	b.eq	0xa518 <generic_rawtp_path+0x1418>
    a42c:      	add	x23, x21, #0x18
    a430:      	mov	w8, #0x4                // =4
    a434:      	add	x9, sp, #0x98
    a438:      	add	x0, sp, #0x98
    a43c:      	mov	w1, #0x8                // =8
    a440:      	mov	x2, x23
    a444:      	blr	x8
    a448:      	ldr	x8, [sp, #0x98]
    a44c:      	cmp	x8, x21
    a450:      	b.eq	0xa518 <generic_rawtp_path+0x1418>
    a454:      	mov	w8, #0x4                // =4
    a458:      	add	x9, sp, #0x78
    a45c:      	add	x0, sp, #0x78
    a460:      	mov	w1, #0x8                // =8
    a464:      	mov	x2, x23
    a468:      	blr	x8
    a46c:      	add	x2, x21, #0x20
    a470:      	mov	w8, #0x4                // =4
    a474:      	mov	w9, #0x10               // =16
    a478:      	add	x10, sp, #0x80
    a47c:      	add	x0, sp, #0x80
    a480:      	mov	w1, #0x10               // =16
    a484:      	blr	x8
    a488:      	ldr	w21, [sp, #0x84]
    a48c:      	ldr	x8, [sp, #0x40]
    a490:      	ldr	x10, [sp, #0x60]
    a494:      	sub	x12, x10, x8
    a498:      	ldr	w23, [sp, #0x68]
    a49c:      	subs	w10, w21, w23
    a4a0:      	ldr	x9, [sp, #0x88]
    a4a4:      	csel	w10, wzr, w10, lo
    a4a8:      	cmp	w23, w21
    a4ac:      	csel	w11, w23, w21, lo
    a4b0:      	cinc	w13, w11, hi
    a4b4:      	sub	w14, w23, w13
    a4b8:      	subs	x12, x12, x13
    a4bc:      	str	w14, [sp, #0x68]
    a4c0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a4c4:      	cmp	x12, #0xfff
    a4c8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a4cc:      	cmp	w23, w21
    a4d0:      	b.ls	0xa4dc <generic_rawtp_path+0x13dc>
    a4d4:      	mov	w13, #0x2f              // =47
    a4d8:      	strb	w13, [x8, x12]
    a4dc:      	add	x19, x8, x12
    a4e0:      	cmp	w23, w21
    a4e4:      	add	x2, x9, x10
    a4e8:      	and	w1, w11, #0xff
    a4ec:      	mov	w8, #0x4                // =4
    a4f0:      	cinc	x0, x19, hi
    a4f4:      	blr	x8
    a4f8:      	cmp	w23, w21
    a4fc:      	str	x19, [sp, #0x60]
    a500:      	add	x19, sp, #0x70
    a504:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a508:      	ldr	x21, [sp, #0x78]
    a50c:      	ldp	x2, x24, [sp, #0x50]
    a510:      	str	x21, [sp, #0x48]
    a514:      	b	0xa564 <generic_rawtp_path+0x1464>
    a518:      	add	x2, x24, #0x10
    a51c:      	mov	w8, #0x4                // =4
    a520:      	add	x9, sp, #0x98
    a524:      	add	x0, sp, #0x98
    a528:      	mov	w1, #0x8                // =8
    a52c:      	blr	x8
    a530:      	ldr	x8, [sp, #0x58]
    a534:      	ldr	x9, [sp, #0x98]
    a538:      	cmp	x8, x9
    a53c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a540:      	add	x2, x24, #0x18
    a544:      	mov	w8, #0x4                // =4
    a548:      	mov	x0, x22
    a54c:      	mov	w1, #0x8                // =8
    a550:      	blr	x8
    a554:      	ldr	x24, [sp, #0x98]
    a558:      	ldr	x21, [sp, #0x48]
    a55c:      	add	x2, x24, #0x20
    a560:      	stp	x2, x24, [sp, #0x50]
    a564:      	ldr	x8, [sp, #0x30]
    a568:      	cmp	x21, x8
    a56c:      	b.ne	0xa57c <generic_rawtp_path+0x147c>
    a570:      	ldr	x8, [sp, #0x38]
    a574:      	cmp	x2, x8
    a578:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a57c:      	mov	w8, #0x4                // =4
    a580:      	add	x0, sp, #0x70
    a584:      	mov	w1, #0x8                // =8
    a588:      	blr	x8
    a58c:      	ldr	x8, [sp, #0x70]
    a590:      	cmp	x21, x8
    a594:      	b.eq	0xa684 <generic_rawtp_path+0x1584>
    a598:      	add	x23, x21, #0x18
    a59c:      	mov	w8, #0x4                // =4
    a5a0:      	add	x9, sp, #0x98
    a5a4:      	add	x0, sp, #0x98
    a5a8:      	mov	w1, #0x8                // =8
    a5ac:      	mov	x2, x23
    a5b0:      	blr	x8
    a5b4:      	ldr	x8, [sp, #0x98]
    a5b8:      	cmp	x8, x21
    a5bc:      	b.eq	0xa684 <generic_rawtp_path+0x1584>
    a5c0:      	mov	w8, #0x4                // =4
    a5c4:      	add	x9, sp, #0x78
    a5c8:      	add	x0, sp, #0x78
    a5cc:      	mov	w1, #0x8                // =8
    a5d0:      	mov	x2, x23
    a5d4:      	blr	x8
    a5d8:      	add	x2, x21, #0x20
    a5dc:      	mov	w8, #0x4                // =4
    a5e0:      	mov	w9, #0x10               // =16
    a5e4:      	add	x10, sp, #0x80
    a5e8:      	add	x0, sp, #0x80
    a5ec:      	mov	w1, #0x10               // =16
    a5f0:      	blr	x8
    a5f4:      	ldr	w21, [sp, #0x84]
    a5f8:      	ldr	x8, [sp, #0x40]
    a5fc:      	ldr	x10, [sp, #0x60]
    a600:      	sub	x12, x10, x8
    a604:      	ldr	w23, [sp, #0x68]
    a608:      	subs	w10, w21, w23
    a60c:      	ldr	x9, [sp, #0x88]
    a610:      	csel	w10, wzr, w10, lo
    a614:      	cmp	w23, w21
    a618:      	csel	w11, w23, w21, lo
    a61c:      	cinc	w13, w11, hi
    a620:      	sub	w14, w23, w13
    a624:      	subs	x12, x12, x13
    a628:      	str	w14, [sp, #0x68]
    a62c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a630:      	cmp	x12, #0xfff
    a634:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a638:      	cmp	w23, w21
    a63c:      	b.ls	0xa648 <generic_rawtp_path+0x1548>
    a640:      	mov	w13, #0x2f              // =47
    a644:      	strb	w13, [x8, x12]
    a648:      	add	x19, x8, x12
    a64c:      	cmp	w23, w21
    a650:      	add	x2, x9, x10
    a654:      	and	w1, w11, #0xff
    a658:      	mov	w8, #0x4                // =4
    a65c:      	cinc	x0, x19, hi
    a660:      	blr	x8
    a664:      	cmp	w23, w21
    a668:      	str	x19, [sp, #0x60]
    a66c:      	add	x19, sp, #0x70
    a670:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a674:      	ldr	x21, [sp, #0x78]
    a678:      	ldp	x2, x24, [sp, #0x50]
    a67c:      	str	x21, [sp, #0x48]
    a680:      	b	0xa6d0 <generic_rawtp_path+0x15d0>
    a684:      	add	x2, x24, #0x10
    a688:      	mov	w8, #0x4                // =4
    a68c:      	add	x9, sp, #0x98
    a690:      	add	x0, sp, #0x98
    a694:      	mov	w1, #0x8                // =8
    a698:      	blr	x8
    a69c:      	ldr	x8, [sp, #0x58]
    a6a0:      	ldr	x9, [sp, #0x98]
    a6a4:      	cmp	x8, x9
    a6a8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a6ac:      	add	x2, x24, #0x18
    a6b0:      	mov	w8, #0x4                // =4
    a6b4:      	mov	x0, x22
    a6b8:      	mov	w1, #0x8                // =8
    a6bc:      	blr	x8
    a6c0:      	ldr	x24, [sp, #0x98]
    a6c4:      	ldr	x21, [sp, #0x48]
    a6c8:      	add	x2, x24, #0x20
    a6cc:      	stp	x2, x24, [sp, #0x50]
    a6d0:      	ldr	x8, [sp, #0x30]
    a6d4:      	cmp	x21, x8
    a6d8:      	b.ne	0xa6e8 <generic_rawtp_path+0x15e8>
    a6dc:      	ldr	x8, [sp, #0x38]
    a6e0:      	cmp	x2, x8
    a6e4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a6e8:      	mov	w8, #0x4                // =4
    a6ec:      	add	x0, sp, #0x70
    a6f0:      	mov	w1, #0x8                // =8
    a6f4:      	blr	x8
    a6f8:      	ldr	x8, [sp, #0x70]
    a6fc:      	cmp	x21, x8
    a700:      	b.eq	0xa7f0 <generic_rawtp_path+0x16f0>
    a704:      	add	x23, x21, #0x18
    a708:      	mov	w8, #0x4                // =4
    a70c:      	add	x9, sp, #0x98
    a710:      	add	x0, sp, #0x98
    a714:      	mov	w1, #0x8                // =8
    a718:      	mov	x2, x23
    a71c:      	blr	x8
    a720:      	ldr	x8, [sp, #0x98]
    a724:      	cmp	x8, x21
    a728:      	b.eq	0xa7f0 <generic_rawtp_path+0x16f0>
    a72c:      	mov	w8, #0x4                // =4
    a730:      	add	x9, sp, #0x78
    a734:      	add	x0, sp, #0x78
    a738:      	mov	w1, #0x8                // =8
    a73c:      	mov	x2, x23
    a740:      	blr	x8
    a744:      	add	x2, x21, #0x20
    a748:      	mov	w8, #0x4                // =4
    a74c:      	mov	w9, #0x10               // =16
    a750:      	add	x10, sp, #0x80
    a754:      	add	x0, sp, #0x80
    a758:      	mov	w1, #0x10               // =16
    a75c:      	blr	x8
    a760:      	ldr	w21, [sp, #0x84]
    a764:      	ldr	x8, [sp, #0x40]
    a768:      	ldr	x10, [sp, #0x60]
    a76c:      	sub	x12, x10, x8
    a770:      	ldr	w23, [sp, #0x68]
    a774:      	subs	w10, w21, w23
    a778:      	ldr	x9, [sp, #0x88]
    a77c:      	csel	w10, wzr, w10, lo
    a780:      	cmp	w23, w21
    a784:      	csel	w11, w23, w21, lo
    a788:      	cinc	w13, w11, hi
    a78c:      	sub	w14, w23, w13
    a790:      	subs	x12, x12, x13
    a794:      	str	w14, [sp, #0x68]
    a798:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a79c:      	cmp	x12, #0xfff
    a7a0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a7a4:      	cmp	w23, w21
    a7a8:      	b.ls	0xa7b4 <generic_rawtp_path+0x16b4>
    a7ac:      	mov	w13, #0x2f              // =47
    a7b0:      	strb	w13, [x8, x12]
    a7b4:      	add	x19, x8, x12
    a7b8:      	cmp	w23, w21
    a7bc:      	add	x2, x9, x10
    a7c0:      	and	w1, w11, #0xff
    a7c4:      	mov	w8, #0x4                // =4
    a7c8:      	cinc	x0, x19, hi
    a7cc:      	blr	x8
    a7d0:      	cmp	w23, w21
    a7d4:      	str	x19, [sp, #0x60]
    a7d8:      	add	x19, sp, #0x70
    a7dc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a7e0:      	ldr	x21, [sp, #0x78]
    a7e4:      	ldp	x2, x24, [sp, #0x50]
    a7e8:      	str	x21, [sp, #0x48]
    a7ec:      	b	0xa83c <generic_rawtp_path+0x173c>
    a7f0:      	add	x2, x24, #0x10
    a7f4:      	mov	w8, #0x4                // =4
    a7f8:      	add	x9, sp, #0x98
    a7fc:      	add	x0, sp, #0x98
    a800:      	mov	w1, #0x8                // =8
    a804:      	blr	x8
    a808:      	ldr	x8, [sp, #0x58]
    a80c:      	ldr	x9, [sp, #0x98]
    a810:      	cmp	x8, x9
    a814:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a818:      	add	x2, x24, #0x18
    a81c:      	mov	w8, #0x4                // =4
    a820:      	mov	x0, x22
    a824:      	mov	w1, #0x8                // =8
    a828:      	blr	x8
    a82c:      	ldr	x24, [sp, #0x98]
    a830:      	ldr	x21, [sp, #0x48]
    a834:      	add	x2, x24, #0x20
    a838:      	stp	x2, x24, [sp, #0x50]
    a83c:      	ldr	x8, [sp, #0x30]
    a840:      	cmp	x21, x8
    a844:      	b.ne	0xa854 <generic_rawtp_path+0x1754>
    a848:      	ldr	x8, [sp, #0x38]
    a84c:      	cmp	x2, x8
    a850:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a854:      	mov	w8, #0x4                // =4
    a858:      	add	x0, sp, #0x70
    a85c:      	mov	w1, #0x8                // =8
    a860:      	blr	x8
    a864:      	ldr	x8, [sp, #0x70]
    a868:      	cmp	x21, x8
    a86c:      	b.eq	0xa95c <generic_rawtp_path+0x185c>
    a870:      	add	x23, x21, #0x18
    a874:      	mov	w8, #0x4                // =4
    a878:      	add	x9, sp, #0x98
    a87c:      	add	x0, sp, #0x98
    a880:      	mov	w1, #0x8                // =8
    a884:      	mov	x2, x23
    a888:      	blr	x8
    a88c:      	ldr	x8, [sp, #0x98]
    a890:      	cmp	x8, x21
    a894:      	b.eq	0xa95c <generic_rawtp_path+0x185c>
    a898:      	mov	w8, #0x4                // =4
    a89c:      	add	x9, sp, #0x78
    a8a0:      	add	x0, sp, #0x78
    a8a4:      	mov	w1, #0x8                // =8
    a8a8:      	mov	x2, x23
    a8ac:      	blr	x8
    a8b0:      	add	x2, x21, #0x20
    a8b4:      	mov	w8, #0x4                // =4
    a8b8:      	mov	w9, #0x10               // =16
    a8bc:      	add	x10, sp, #0x80
    a8c0:      	add	x0, sp, #0x80
    a8c4:      	mov	w1, #0x10               // =16
    a8c8:      	blr	x8
    a8cc:      	ldr	w21, [sp, #0x84]
    a8d0:      	ldr	x8, [sp, #0x40]
    a8d4:      	ldr	x10, [sp, #0x60]
    a8d8:      	sub	x12, x10, x8
    a8dc:      	ldr	w23, [sp, #0x68]
    a8e0:      	subs	w10, w21, w23
    a8e4:      	ldr	x9, [sp, #0x88]
    a8e8:      	csel	w10, wzr, w10, lo
    a8ec:      	cmp	w23, w21
    a8f0:      	csel	w11, w23, w21, lo
    a8f4:      	cinc	w13, w11, hi
    a8f8:      	sub	w14, w23, w13
    a8fc:      	subs	x12, x12, x13
    a900:      	str	w14, [sp, #0x68]
    a904:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    a908:      	cmp	x12, #0xfff
    a90c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    a910:      	cmp	w23, w21
    a914:      	b.ls	0xa920 <generic_rawtp_path+0x1820>
    a918:      	mov	w13, #0x2f              // =47
    a91c:      	strb	w13, [x8, x12]
    a920:      	add	x19, x8, x12
    a924:      	cmp	w23, w21
    a928:      	add	x2, x9, x10
    a92c:      	and	w1, w11, #0xff
    a930:      	mov	w8, #0x4                // =4
    a934:      	cinc	x0, x19, hi
    a938:      	blr	x8
    a93c:      	cmp	w23, w21
    a940:      	str	x19, [sp, #0x60]
    a944:      	add	x19, sp, #0x70
    a948:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    a94c:      	ldr	x21, [sp, #0x78]
    a950:      	ldp	x2, x24, [sp, #0x50]
    a954:      	str	x21, [sp, #0x48]
    a958:      	b	0xa9a8 <generic_rawtp_path+0x18a8>
    a95c:      	add	x2, x24, #0x10
    a960:      	mov	w8, #0x4                // =4
    a964:      	add	x9, sp, #0x98
    a968:      	add	x0, sp, #0x98
    a96c:      	mov	w1, #0x8                // =8
    a970:      	blr	x8
    a974:      	ldr	x8, [sp, #0x58]
    a978:      	ldr	x9, [sp, #0x98]
    a97c:      	cmp	x8, x9
    a980:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a984:      	add	x2, x24, #0x18
    a988:      	mov	w8, #0x4                // =4
    a98c:      	mov	x0, x22
    a990:      	mov	w1, #0x8                // =8
    a994:      	blr	x8
    a998:      	ldr	x24, [sp, #0x98]
    a99c:      	ldr	x21, [sp, #0x48]
    a9a0:      	add	x2, x24, #0x20
    a9a4:      	stp	x2, x24, [sp, #0x50]
    a9a8:      	ldr	x8, [sp, #0x30]
    a9ac:      	cmp	x21, x8
    a9b0:      	b.ne	0xa9c0 <generic_rawtp_path+0x18c0>
    a9b4:      	ldr	x8, [sp, #0x38]
    a9b8:      	cmp	x2, x8
    a9bc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    a9c0:      	mov	w8, #0x4                // =4
    a9c4:      	add	x0, sp, #0x70
    a9c8:      	mov	w1, #0x8                // =8
    a9cc:      	blr	x8
    a9d0:      	ldr	x8, [sp, #0x70]
    a9d4:      	cmp	x21, x8
    a9d8:      	b.eq	0xaac8 <generic_rawtp_path+0x19c8>
    a9dc:      	add	x23, x21, #0x18
    a9e0:      	mov	w8, #0x4                // =4
    a9e4:      	add	x9, sp, #0x98
    a9e8:      	add	x0, sp, #0x98
    a9ec:      	mov	w1, #0x8                // =8
    a9f0:      	mov	x2, x23
    a9f4:      	blr	x8
    a9f8:      	ldr	x8, [sp, #0x98]
    a9fc:      	cmp	x8, x21
    aa00:      	b.eq	0xaac8 <generic_rawtp_path+0x19c8>
    aa04:      	mov	w8, #0x4                // =4
    aa08:      	add	x9, sp, #0x78
    aa0c:      	add	x0, sp, #0x78
    aa10:      	mov	w1, #0x8                // =8
    aa14:      	mov	x2, x23
    aa18:      	blr	x8
    aa1c:      	add	x2, x21, #0x20
    aa20:      	mov	w8, #0x4                // =4
    aa24:      	mov	w9, #0x10               // =16
    aa28:      	add	x10, sp, #0x80
    aa2c:      	add	x0, sp, #0x80
    aa30:      	mov	w1, #0x10               // =16
    aa34:      	blr	x8
    aa38:      	ldr	w21, [sp, #0x84]
    aa3c:      	ldr	x8, [sp, #0x40]
    aa40:      	ldr	x10, [sp, #0x60]
    aa44:      	sub	x12, x10, x8
    aa48:      	ldr	w23, [sp, #0x68]
    aa4c:      	subs	w10, w21, w23
    aa50:      	ldr	x9, [sp, #0x88]
    aa54:      	csel	w10, wzr, w10, lo
    aa58:      	cmp	w23, w21
    aa5c:      	csel	w11, w23, w21, lo
    aa60:      	cinc	w13, w11, hi
    aa64:      	sub	w14, w23, w13
    aa68:      	subs	x12, x12, x13
    aa6c:      	str	w14, [sp, #0x68]
    aa70:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    aa74:      	cmp	x12, #0xfff
    aa78:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    aa7c:      	cmp	w23, w21
    aa80:      	b.ls	0xaa8c <generic_rawtp_path+0x198c>
    aa84:      	mov	w13, #0x2f              // =47
    aa88:      	strb	w13, [x8, x12]
    aa8c:      	add	x19, x8, x12
    aa90:      	cmp	w23, w21
    aa94:      	add	x2, x9, x10
    aa98:      	and	w1, w11, #0xff
    aa9c:      	mov	w8, #0x4                // =4
    aaa0:      	cinc	x0, x19, hi
    aaa4:      	blr	x8
    aaa8:      	cmp	w23, w21
    aaac:      	str	x19, [sp, #0x60]
    aab0:      	add	x19, sp, #0x70
    aab4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    aab8:      	ldr	x21, [sp, #0x78]
    aabc:      	ldp	x2, x24, [sp, #0x50]
    aac0:      	str	x21, [sp, #0x48]
    aac4:      	b	0xab14 <generic_rawtp_path+0x1a14>
    aac8:      	add	x2, x24, #0x10
    aacc:      	mov	w8, #0x4                // =4
    aad0:      	add	x9, sp, #0x98
    aad4:      	add	x0, sp, #0x98
    aad8:      	mov	w1, #0x8                // =8
    aadc:      	blr	x8
    aae0:      	ldr	x8, [sp, #0x58]
    aae4:      	ldr	x9, [sp, #0x98]
    aae8:      	cmp	x8, x9
    aaec:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    aaf0:      	add	x2, x24, #0x18
    aaf4:      	mov	w8, #0x4                // =4
    aaf8:      	mov	x0, x22
    aafc:      	mov	w1, #0x8                // =8
    ab00:      	blr	x8
    ab04:      	ldr	x24, [sp, #0x98]
    ab08:      	ldr	x21, [sp, #0x48]
    ab0c:      	add	x2, x24, #0x20
    ab10:      	stp	x2, x24, [sp, #0x50]
    ab14:      	ldr	x8, [sp, #0x30]
    ab18:      	cmp	x21, x8
    ab1c:      	b.ne	0xab2c <generic_rawtp_path+0x1a2c>
    ab20:      	ldr	x8, [sp, #0x38]
    ab24:      	cmp	x2, x8
    ab28:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ab2c:      	mov	w8, #0x4                // =4
    ab30:      	add	x0, sp, #0x70
    ab34:      	mov	w1, #0x8                // =8
    ab38:      	blr	x8
    ab3c:      	ldr	x8, [sp, #0x70]
    ab40:      	cmp	x21, x8
    ab44:      	b.eq	0xac34 <generic_rawtp_path+0x1b34>
    ab48:      	add	x23, x21, #0x18
    ab4c:      	mov	w8, #0x4                // =4
    ab50:      	add	x9, sp, #0x98
    ab54:      	add	x0, sp, #0x98
    ab58:      	mov	w1, #0x8                // =8
    ab5c:      	mov	x2, x23
    ab60:      	blr	x8
    ab64:      	ldr	x8, [sp, #0x98]
    ab68:      	cmp	x8, x21
    ab6c:      	b.eq	0xac34 <generic_rawtp_path+0x1b34>
    ab70:      	mov	w8, #0x4                // =4
    ab74:      	add	x9, sp, #0x78
    ab78:      	add	x0, sp, #0x78
    ab7c:      	mov	w1, #0x8                // =8
    ab80:      	mov	x2, x23
    ab84:      	blr	x8
    ab88:      	add	x2, x21, #0x20
    ab8c:      	mov	w8, #0x4                // =4
    ab90:      	mov	w9, #0x10               // =16
    ab94:      	add	x10, sp, #0x80
    ab98:      	add	x0, sp, #0x80
    ab9c:      	mov	w1, #0x10               // =16
    aba0:      	blr	x8
    aba4:      	ldr	w21, [sp, #0x84]
    aba8:      	ldr	x8, [sp, #0x40]
    abac:      	ldr	x10, [sp, #0x60]
    abb0:      	sub	x12, x10, x8
    abb4:      	ldr	w23, [sp, #0x68]
    abb8:      	subs	w10, w21, w23
    abbc:      	ldr	x9, [sp, #0x88]
    abc0:      	csel	w10, wzr, w10, lo
    abc4:      	cmp	w23, w21
    abc8:      	csel	w11, w23, w21, lo
    abcc:      	cinc	w13, w11, hi
    abd0:      	sub	w14, w23, w13
    abd4:      	subs	x12, x12, x13
    abd8:      	str	w14, [sp, #0x68]
    abdc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    abe0:      	cmp	x12, #0xfff
    abe4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    abe8:      	cmp	w23, w21
    abec:      	b.ls	0xabf8 <generic_rawtp_path+0x1af8>
    abf0:      	mov	w13, #0x2f              // =47
    abf4:      	strb	w13, [x8, x12]
    abf8:      	add	x19, x8, x12
    abfc:      	cmp	w23, w21
    ac00:      	add	x2, x9, x10
    ac04:      	and	w1, w11, #0xff
    ac08:      	mov	w8, #0x4                // =4
    ac0c:      	cinc	x0, x19, hi
    ac10:      	blr	x8
    ac14:      	cmp	w23, w21
    ac18:      	str	x19, [sp, #0x60]
    ac1c:      	add	x19, sp, #0x70
    ac20:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ac24:      	ldr	x21, [sp, #0x78]
    ac28:      	ldp	x2, x24, [sp, #0x50]
    ac2c:      	str	x21, [sp, #0x48]
    ac30:      	b	0xac80 <generic_rawtp_path+0x1b80>
    ac34:      	add	x2, x24, #0x10
    ac38:      	mov	w8, #0x4                // =4
    ac3c:      	add	x9, sp, #0x98
    ac40:      	add	x0, sp, #0x98
    ac44:      	mov	w1, #0x8                // =8
    ac48:      	blr	x8
    ac4c:      	ldr	x8, [sp, #0x58]
    ac50:      	ldr	x9, [sp, #0x98]
    ac54:      	cmp	x8, x9
    ac58:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ac5c:      	add	x2, x24, #0x18
    ac60:      	mov	w8, #0x4                // =4
    ac64:      	mov	x0, x22
    ac68:      	mov	w1, #0x8                // =8
    ac6c:      	blr	x8
    ac70:      	ldr	x24, [sp, #0x98]
    ac74:      	ldr	x21, [sp, #0x48]
    ac78:      	add	x2, x24, #0x20
    ac7c:      	stp	x2, x24, [sp, #0x50]
    ac80:      	ldr	x8, [sp, #0x30]
    ac84:      	cmp	x21, x8
    ac88:      	b.ne	0xac98 <generic_rawtp_path+0x1b98>
    ac8c:      	ldr	x8, [sp, #0x38]
    ac90:      	cmp	x2, x8
    ac94:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ac98:      	mov	w8, #0x4                // =4
    ac9c:      	add	x0, sp, #0x70
    aca0:      	mov	w1, #0x8                // =8
    aca4:      	blr	x8
    aca8:      	ldr	x8, [sp, #0x70]
    acac:      	cmp	x21, x8
    acb0:      	b.eq	0xada0 <generic_rawtp_path+0x1ca0>
    acb4:      	add	x23, x21, #0x18
    acb8:      	mov	w8, #0x4                // =4
    acbc:      	add	x9, sp, #0x98
    acc0:      	add	x0, sp, #0x98
    acc4:      	mov	w1, #0x8                // =8
    acc8:      	mov	x2, x23
    accc:      	blr	x8
    acd0:      	ldr	x8, [sp, #0x98]
    acd4:      	cmp	x8, x21
    acd8:      	b.eq	0xada0 <generic_rawtp_path+0x1ca0>
    acdc:      	mov	w8, #0x4                // =4
    ace0:      	add	x9, sp, #0x78
    ace4:      	add	x0, sp, #0x78
    ace8:      	mov	w1, #0x8                // =8
    acec:      	mov	x2, x23
    acf0:      	blr	x8
    acf4:      	add	x2, x21, #0x20
    acf8:      	mov	w8, #0x4                // =4
    acfc:      	mov	w9, #0x10               // =16
    ad00:      	add	x10, sp, #0x80
    ad04:      	add	x0, sp, #0x80
    ad08:      	mov	w1, #0x10               // =16
    ad0c:      	blr	x8
    ad10:      	ldr	w21, [sp, #0x84]
    ad14:      	ldr	x8, [sp, #0x40]
    ad18:      	ldr	x10, [sp, #0x60]
    ad1c:      	sub	x12, x10, x8
    ad20:      	ldr	w23, [sp, #0x68]
    ad24:      	subs	w10, w21, w23
    ad28:      	ldr	x9, [sp, #0x88]
    ad2c:      	csel	w10, wzr, w10, lo
    ad30:      	cmp	w23, w21
    ad34:      	csel	w11, w23, w21, lo
    ad38:      	cinc	w13, w11, hi
    ad3c:      	sub	w14, w23, w13
    ad40:      	subs	x12, x12, x13
    ad44:      	str	w14, [sp, #0x68]
    ad48:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ad4c:      	cmp	x12, #0xfff
    ad50:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ad54:      	cmp	w23, w21
    ad58:      	b.ls	0xad64 <generic_rawtp_path+0x1c64>
    ad5c:      	mov	w13, #0x2f              // =47
    ad60:      	strb	w13, [x8, x12]
    ad64:      	add	x19, x8, x12
    ad68:      	cmp	w23, w21
    ad6c:      	add	x2, x9, x10
    ad70:      	and	w1, w11, #0xff
    ad74:      	mov	w8, #0x4                // =4
    ad78:      	cinc	x0, x19, hi
    ad7c:      	blr	x8
    ad80:      	cmp	w23, w21
    ad84:      	str	x19, [sp, #0x60]
    ad88:      	add	x19, sp, #0x70
    ad8c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ad90:      	ldr	x21, [sp, #0x78]
    ad94:      	ldp	x2, x24, [sp, #0x50]
    ad98:      	str	x21, [sp, #0x48]
    ad9c:      	b	0xadec <generic_rawtp_path+0x1cec>
    ada0:      	add	x2, x24, #0x10
    ada4:      	mov	w8, #0x4                // =4
    ada8:      	add	x9, sp, #0x98
    adac:      	add	x0, sp, #0x98
    adb0:      	mov	w1, #0x8                // =8
    adb4:      	blr	x8
    adb8:      	ldr	x8, [sp, #0x58]
    adbc:      	ldr	x9, [sp, #0x98]
    adc0:      	cmp	x8, x9
    adc4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    adc8:      	add	x2, x24, #0x18
    adcc:      	mov	w8, #0x4                // =4
    add0:      	mov	x0, x22
    add4:      	mov	w1, #0x8                // =8
    add8:      	blr	x8
    addc:      	ldr	x24, [sp, #0x98]
    ade0:      	ldr	x21, [sp, #0x48]
    ade4:      	add	x2, x24, #0x20
    ade8:      	stp	x2, x24, [sp, #0x50]
    adec:      	ldr	x8, [sp, #0x30]
    adf0:      	cmp	x21, x8
    adf4:      	b.ne	0xae04 <generic_rawtp_path+0x1d04>
    adf8:      	ldr	x8, [sp, #0x38]
    adfc:      	cmp	x2, x8
    ae00:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ae04:      	mov	w8, #0x4                // =4
    ae08:      	add	x0, sp, #0x70
    ae0c:      	mov	w1, #0x8                // =8
    ae10:      	blr	x8
    ae14:      	ldr	x8, [sp, #0x70]
    ae18:      	cmp	x21, x8
    ae1c:      	b.eq	0xaf0c <generic_rawtp_path+0x1e0c>
    ae20:      	add	x23, x21, #0x18
    ae24:      	mov	w8, #0x4                // =4
    ae28:      	add	x9, sp, #0x98
    ae2c:      	add	x0, sp, #0x98
    ae30:      	mov	w1, #0x8                // =8
    ae34:      	mov	x2, x23
    ae38:      	blr	x8
    ae3c:      	ldr	x8, [sp, #0x98]
    ae40:      	cmp	x8, x21
    ae44:      	b.eq	0xaf0c <generic_rawtp_path+0x1e0c>
    ae48:      	mov	w8, #0x4                // =4
    ae4c:      	add	x9, sp, #0x78
    ae50:      	add	x0, sp, #0x78
    ae54:      	mov	w1, #0x8                // =8
    ae58:      	mov	x2, x23
    ae5c:      	blr	x8
    ae60:      	add	x2, x21, #0x20
    ae64:      	mov	w8, #0x4                // =4
    ae68:      	mov	w9, #0x10               // =16
    ae6c:      	add	x10, sp, #0x80
    ae70:      	add	x0, sp, #0x80
    ae74:      	mov	w1, #0x10               // =16
    ae78:      	blr	x8
    ae7c:      	ldr	w21, [sp, #0x84]
    ae80:      	ldr	x8, [sp, #0x40]
    ae84:      	ldr	x10, [sp, #0x60]
    ae88:      	sub	x12, x10, x8
    ae8c:      	ldr	w23, [sp, #0x68]
    ae90:      	subs	w10, w21, w23
    ae94:      	ldr	x9, [sp, #0x88]
    ae98:      	csel	w10, wzr, w10, lo
    ae9c:      	cmp	w23, w21
    aea0:      	csel	w11, w23, w21, lo
    aea4:      	cinc	w13, w11, hi
    aea8:      	sub	w14, w23, w13
    aeac:      	subs	x12, x12, x13
    aeb0:      	str	w14, [sp, #0x68]
    aeb4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    aeb8:      	cmp	x12, #0xfff
    aebc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    aec0:      	cmp	w23, w21
    aec4:      	b.ls	0xaed0 <generic_rawtp_path+0x1dd0>
    aec8:      	mov	w13, #0x2f              // =47
    aecc:      	strb	w13, [x8, x12]
    aed0:      	add	x19, x8, x12
    aed4:      	cmp	w23, w21
    aed8:      	add	x2, x9, x10
    aedc:      	and	w1, w11, #0xff
    aee0:      	mov	w8, #0x4                // =4
    aee4:      	cinc	x0, x19, hi
    aee8:      	blr	x8
    aeec:      	cmp	w23, w21
    aef0:      	str	x19, [sp, #0x60]
    aef4:      	add	x19, sp, #0x70
    aef8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    aefc:      	ldr	x21, [sp, #0x78]
    af00:      	ldp	x2, x24, [sp, #0x50]
    af04:      	str	x21, [sp, #0x48]
    af08:      	b	0xaf58 <generic_rawtp_path+0x1e58>
    af0c:      	add	x2, x24, #0x10
    af10:      	mov	w8, #0x4                // =4
    af14:      	add	x9, sp, #0x98
    af18:      	add	x0, sp, #0x98
    af1c:      	mov	w1, #0x8                // =8
    af20:      	blr	x8
    af24:      	ldr	x8, [sp, #0x58]
    af28:      	ldr	x9, [sp, #0x98]
    af2c:      	cmp	x8, x9
    af30:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    af34:      	add	x2, x24, #0x18
    af38:      	mov	w8, #0x4                // =4
    af3c:      	mov	x0, x22
    af40:      	mov	w1, #0x8                // =8
    af44:      	blr	x8
    af48:      	ldr	x24, [sp, #0x98]
    af4c:      	ldr	x21, [sp, #0x48]
    af50:      	add	x2, x24, #0x20
    af54:      	stp	x2, x24, [sp, #0x50]
    af58:      	ldr	x8, [sp, #0x30]
    af5c:      	cmp	x21, x8
    af60:      	b.ne	0xaf70 <generic_rawtp_path+0x1e70>
    af64:      	ldr	x8, [sp, #0x38]
    af68:      	cmp	x2, x8
    af6c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    af70:      	mov	w8, #0x4                // =4
    af74:      	add	x0, sp, #0x70
    af78:      	mov	w1, #0x8                // =8
    af7c:      	blr	x8
    af80:      	ldr	x8, [sp, #0x70]
    af84:      	cmp	x21, x8
    af88:      	b.eq	0xb078 <generic_rawtp_path+0x1f78>
    af8c:      	add	x23, x21, #0x18
    af90:      	mov	w8, #0x4                // =4
    af94:      	add	x9, sp, #0x98
    af98:      	add	x0, sp, #0x98
    af9c:      	mov	w1, #0x8                // =8
    afa0:      	mov	x2, x23
    afa4:      	blr	x8
    afa8:      	ldr	x8, [sp, #0x98]
    afac:      	cmp	x8, x21
    afb0:      	b.eq	0xb078 <generic_rawtp_path+0x1f78>
    afb4:      	mov	w8, #0x4                // =4
    afb8:      	add	x9, sp, #0x78
    afbc:      	add	x0, sp, #0x78
    afc0:      	mov	w1, #0x8                // =8
    afc4:      	mov	x2, x23
    afc8:      	blr	x8
    afcc:      	add	x2, x21, #0x20
    afd0:      	mov	w8, #0x4                // =4
    afd4:      	mov	w9, #0x10               // =16
    afd8:      	add	x10, sp, #0x80
    afdc:      	add	x0, sp, #0x80
    afe0:      	mov	w1, #0x10               // =16
    afe4:      	blr	x8
    afe8:      	ldr	w21, [sp, #0x84]
    afec:      	ldr	x8, [sp, #0x40]
    aff0:      	ldr	x10, [sp, #0x60]
    aff4:      	sub	x12, x10, x8
    aff8:      	ldr	w23, [sp, #0x68]
    affc:      	subs	w10, w21, w23
    b000:      	ldr	x9, [sp, #0x88]
    b004:      	csel	w10, wzr, w10, lo
    b008:      	cmp	w23, w21
    b00c:      	csel	w11, w23, w21, lo
    b010:      	cinc	w13, w11, hi
    b014:      	sub	w14, w23, w13
    b018:      	subs	x12, x12, x13
    b01c:      	str	w14, [sp, #0x68]
    b020:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b024:      	cmp	x12, #0xfff
    b028:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b02c:      	cmp	w23, w21
    b030:      	b.ls	0xb03c <generic_rawtp_path+0x1f3c>
    b034:      	mov	w13, #0x2f              // =47
    b038:      	strb	w13, [x8, x12]
    b03c:      	add	x19, x8, x12
    b040:      	cmp	w23, w21
    b044:      	add	x2, x9, x10
    b048:      	and	w1, w11, #0xff
    b04c:      	mov	w8, #0x4                // =4
    b050:      	cinc	x0, x19, hi
    b054:      	blr	x8
    b058:      	cmp	w23, w21
    b05c:      	str	x19, [sp, #0x60]
    b060:      	add	x19, sp, #0x70
    b064:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b068:      	ldr	x21, [sp, #0x78]
    b06c:      	ldp	x2, x24, [sp, #0x50]
    b070:      	str	x21, [sp, #0x48]
    b074:      	b	0xb0c4 <generic_rawtp_path+0x1fc4>
    b078:      	add	x2, x24, #0x10
    b07c:      	mov	w8, #0x4                // =4
    b080:      	add	x9, sp, #0x98
    b084:      	add	x0, sp, #0x98
    b088:      	mov	w1, #0x8                // =8
    b08c:      	blr	x8
    b090:      	ldr	x8, [sp, #0x58]
    b094:      	ldr	x9, [sp, #0x98]
    b098:      	cmp	x8, x9
    b09c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b0a0:      	add	x2, x24, #0x18
    b0a4:      	mov	w8, #0x4                // =4
    b0a8:      	mov	x0, x22
    b0ac:      	mov	w1, #0x8                // =8
    b0b0:      	blr	x8
    b0b4:      	ldr	x24, [sp, #0x98]
    b0b8:      	ldr	x21, [sp, #0x48]
    b0bc:      	add	x2, x24, #0x20
    b0c0:      	stp	x2, x24, [sp, #0x50]
    b0c4:      	ldr	x8, [sp, #0x30]
    b0c8:      	cmp	x21, x8
    b0cc:      	b.ne	0xb0dc <generic_rawtp_path+0x1fdc>
    b0d0:      	ldr	x8, [sp, #0x38]
    b0d4:      	cmp	x2, x8
    b0d8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b0dc:      	mov	w8, #0x4                // =4
    b0e0:      	add	x0, sp, #0x70
    b0e4:      	mov	w1, #0x8                // =8
    b0e8:      	blr	x8
    b0ec:      	ldr	x8, [sp, #0x70]
    b0f0:      	cmp	x21, x8
    b0f4:      	b.eq	0xb1e4 <generic_rawtp_path+0x20e4>
    b0f8:      	add	x23, x21, #0x18
    b0fc:      	mov	w8, #0x4                // =4
    b100:      	add	x9, sp, #0x98
    b104:      	add	x0, sp, #0x98
    b108:      	mov	w1, #0x8                // =8
    b10c:      	mov	x2, x23
    b110:      	blr	x8
    b114:      	ldr	x8, [sp, #0x98]
    b118:      	cmp	x8, x21
    b11c:      	b.eq	0xb1e4 <generic_rawtp_path+0x20e4>
    b120:      	mov	w8, #0x4                // =4
    b124:      	add	x9, sp, #0x78
    b128:      	add	x0, sp, #0x78
    b12c:      	mov	w1, #0x8                // =8
    b130:      	mov	x2, x23
    b134:      	blr	x8
    b138:      	add	x2, x21, #0x20
    b13c:      	mov	w8, #0x4                // =4
    b140:      	mov	w9, #0x10               // =16
    b144:      	add	x10, sp, #0x80
    b148:      	add	x0, sp, #0x80
    b14c:      	mov	w1, #0x10               // =16
    b150:      	blr	x8
    b154:      	ldr	w21, [sp, #0x84]
    b158:      	ldr	x8, [sp, #0x40]
    b15c:      	ldr	x10, [sp, #0x60]
    b160:      	sub	x12, x10, x8
    b164:      	ldr	w23, [sp, #0x68]
    b168:      	subs	w10, w21, w23
    b16c:      	ldr	x9, [sp, #0x88]
    b170:      	csel	w10, wzr, w10, lo
    b174:      	cmp	w23, w21
    b178:      	csel	w11, w23, w21, lo
    b17c:      	cinc	w13, w11, hi
    b180:      	sub	w14, w23, w13
    b184:      	subs	x12, x12, x13
    b188:      	str	w14, [sp, #0x68]
    b18c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b190:      	cmp	x12, #0xfff
    b194:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b198:      	cmp	w23, w21
    b19c:      	b.ls	0xb1a8 <generic_rawtp_path+0x20a8>
    b1a0:      	mov	w13, #0x2f              // =47
    b1a4:      	strb	w13, [x8, x12]
    b1a8:      	add	x19, x8, x12
    b1ac:      	cmp	w23, w21
    b1b0:      	add	x2, x9, x10
    b1b4:      	and	w1, w11, #0xff
    b1b8:      	mov	w8, #0x4                // =4
    b1bc:      	cinc	x0, x19, hi
    b1c0:      	blr	x8
    b1c4:      	cmp	w23, w21
    b1c8:      	str	x19, [sp, #0x60]
    b1cc:      	add	x19, sp, #0x70
    b1d0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b1d4:      	ldr	x21, [sp, #0x78]
    b1d8:      	ldp	x2, x24, [sp, #0x50]
    b1dc:      	str	x21, [sp, #0x48]
    b1e0:      	b	0xb230 <generic_rawtp_path+0x2130>
    b1e4:      	add	x2, x24, #0x10
    b1e8:      	mov	w8, #0x4                // =4
    b1ec:      	add	x9, sp, #0x98
    b1f0:      	add	x0, sp, #0x98
    b1f4:      	mov	w1, #0x8                // =8
    b1f8:      	blr	x8
    b1fc:      	ldr	x8, [sp, #0x58]
    b200:      	ldr	x9, [sp, #0x98]
    b204:      	cmp	x8, x9
    b208:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b20c:      	add	x2, x24, #0x18
    b210:      	mov	w8, #0x4                // =4
    b214:      	mov	x0, x22
    b218:      	mov	w1, #0x8                // =8
    b21c:      	blr	x8
    b220:      	ldr	x24, [sp, #0x98]
    b224:      	ldr	x21, [sp, #0x48]
    b228:      	add	x2, x24, #0x20
    b22c:      	stp	x2, x24, [sp, #0x50]
    b230:      	ldr	x8, [sp, #0x30]
    b234:      	cmp	x21, x8
    b238:      	b.ne	0xb248 <generic_rawtp_path+0x2148>
    b23c:      	ldr	x8, [sp, #0x38]
    b240:      	cmp	x2, x8
    b244:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b248:      	mov	w8, #0x4                // =4
    b24c:      	add	x0, sp, #0x70
    b250:      	mov	w1, #0x8                // =8
    b254:      	blr	x8
    b258:      	ldr	x8, [sp, #0x70]
    b25c:      	cmp	x21, x8
    b260:      	b.eq	0xb350 <generic_rawtp_path+0x2250>
    b264:      	add	x23, x21, #0x18
    b268:      	mov	w8, #0x4                // =4
    b26c:      	add	x9, sp, #0x98
    b270:      	add	x0, sp, #0x98
    b274:      	mov	w1, #0x8                // =8
    b278:      	mov	x2, x23
    b27c:      	blr	x8
    b280:      	ldr	x8, [sp, #0x98]
    b284:      	cmp	x8, x21
    b288:      	b.eq	0xb350 <generic_rawtp_path+0x2250>
    b28c:      	mov	w8, #0x4                // =4
    b290:      	add	x9, sp, #0x78
    b294:      	add	x0, sp, #0x78
    b298:      	mov	w1, #0x8                // =8
    b29c:      	mov	x2, x23
    b2a0:      	blr	x8
    b2a4:      	add	x2, x21, #0x20
    b2a8:      	mov	w8, #0x4                // =4
    b2ac:      	mov	w9, #0x10               // =16
    b2b0:      	add	x10, sp, #0x80
    b2b4:      	add	x0, sp, #0x80
    b2b8:      	mov	w1, #0x10               // =16
    b2bc:      	blr	x8
    b2c0:      	ldr	w21, [sp, #0x84]
    b2c4:      	ldr	x8, [sp, #0x40]
    b2c8:      	ldr	x10, [sp, #0x60]
    b2cc:      	sub	x12, x10, x8
    b2d0:      	ldr	w23, [sp, #0x68]
    b2d4:      	subs	w10, w21, w23
    b2d8:      	ldr	x9, [sp, #0x88]
    b2dc:      	csel	w10, wzr, w10, lo
    b2e0:      	cmp	w23, w21
    b2e4:      	csel	w11, w23, w21, lo
    b2e8:      	cinc	w13, w11, hi
    b2ec:      	sub	w14, w23, w13
    b2f0:      	subs	x12, x12, x13
    b2f4:      	str	w14, [sp, #0x68]
    b2f8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b2fc:      	cmp	x12, #0xfff
    b300:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b304:      	cmp	w23, w21
    b308:      	b.ls	0xb314 <generic_rawtp_path+0x2214>
    b30c:      	mov	w13, #0x2f              // =47
    b310:      	strb	w13, [x8, x12]
    b314:      	add	x19, x8, x12
    b318:      	cmp	w23, w21
    b31c:      	add	x2, x9, x10
    b320:      	and	w1, w11, #0xff
    b324:      	mov	w8, #0x4                // =4
    b328:      	cinc	x0, x19, hi
    b32c:      	blr	x8
    b330:      	cmp	w23, w21
    b334:      	str	x19, [sp, #0x60]
    b338:      	add	x19, sp, #0x70
    b33c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b340:      	ldr	x21, [sp, #0x78]
    b344:      	ldp	x2, x24, [sp, #0x50]
    b348:      	str	x21, [sp, #0x48]
    b34c:      	b	0xb39c <generic_rawtp_path+0x229c>
    b350:      	add	x2, x24, #0x10
    b354:      	mov	w8, #0x4                // =4
    b358:      	add	x9, sp, #0x98
    b35c:      	add	x0, sp, #0x98
    b360:      	mov	w1, #0x8                // =8
    b364:      	blr	x8
    b368:      	ldr	x8, [sp, #0x58]
    b36c:      	ldr	x9, [sp, #0x98]
    b370:      	cmp	x8, x9
    b374:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b378:      	add	x2, x24, #0x18
    b37c:      	mov	w8, #0x4                // =4
    b380:      	mov	x0, x22
    b384:      	mov	w1, #0x8                // =8
    b388:      	blr	x8
    b38c:      	ldr	x24, [sp, #0x98]
    b390:      	ldr	x21, [sp, #0x48]
    b394:      	add	x2, x24, #0x20
    b398:      	stp	x2, x24, [sp, #0x50]
    b39c:      	ldr	x8, [sp, #0x30]
    b3a0:      	cmp	x21, x8
    b3a4:      	b.ne	0xb3b4 <generic_rawtp_path+0x22b4>
    b3a8:      	ldr	x8, [sp, #0x38]
    b3ac:      	cmp	x2, x8
    b3b0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b3b4:      	mov	w8, #0x4                // =4
    b3b8:      	add	x0, sp, #0x70
    b3bc:      	mov	w1, #0x8                // =8
    b3c0:      	blr	x8
    b3c4:      	ldr	x8, [sp, #0x70]
    b3c8:      	cmp	x21, x8
    b3cc:      	b.eq	0xb4bc <generic_rawtp_path+0x23bc>
    b3d0:      	add	x23, x21, #0x18
    b3d4:      	mov	w8, #0x4                // =4
    b3d8:      	add	x9, sp, #0x98
    b3dc:      	add	x0, sp, #0x98
    b3e0:      	mov	w1, #0x8                // =8
    b3e4:      	mov	x2, x23
    b3e8:      	blr	x8
    b3ec:      	ldr	x8, [sp, #0x98]
    b3f0:      	cmp	x8, x21
    b3f4:      	b.eq	0xb4bc <generic_rawtp_path+0x23bc>
    b3f8:      	mov	w8, #0x4                // =4
    b3fc:      	add	x9, sp, #0x78
    b400:      	add	x0, sp, #0x78
    b404:      	mov	w1, #0x8                // =8
    b408:      	mov	x2, x23
    b40c:      	blr	x8
    b410:      	add	x2, x21, #0x20
    b414:      	mov	w8, #0x4                // =4
    b418:      	mov	w9, #0x10               // =16
    b41c:      	add	x10, sp, #0x80
    b420:      	add	x0, sp, #0x80
    b424:      	mov	w1, #0x10               // =16
    b428:      	blr	x8
    b42c:      	ldr	w21, [sp, #0x84]
    b430:      	ldr	x8, [sp, #0x40]
    b434:      	ldr	x10, [sp, #0x60]
    b438:      	sub	x12, x10, x8
    b43c:      	ldr	w23, [sp, #0x68]
    b440:      	subs	w10, w21, w23
    b444:      	ldr	x9, [sp, #0x88]
    b448:      	csel	w10, wzr, w10, lo
    b44c:      	cmp	w23, w21
    b450:      	csel	w11, w23, w21, lo
    b454:      	cinc	w13, w11, hi
    b458:      	sub	w14, w23, w13
    b45c:      	subs	x12, x12, x13
    b460:      	str	w14, [sp, #0x68]
    b464:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b468:      	cmp	x12, #0xfff
    b46c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b470:      	cmp	w23, w21
    b474:      	b.ls	0xb480 <generic_rawtp_path+0x2380>
    b478:      	mov	w13, #0x2f              // =47
    b47c:      	strb	w13, [x8, x12]
    b480:      	add	x19, x8, x12
    b484:      	cmp	w23, w21
    b488:      	add	x2, x9, x10
    b48c:      	and	w1, w11, #0xff
    b490:      	mov	w8, #0x4                // =4
    b494:      	cinc	x0, x19, hi
    b498:      	blr	x8
    b49c:      	cmp	w23, w21
    b4a0:      	str	x19, [sp, #0x60]
    b4a4:      	add	x19, sp, #0x70
    b4a8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b4ac:      	ldr	x21, [sp, #0x78]
    b4b0:      	ldp	x2, x24, [sp, #0x50]
    b4b4:      	str	x21, [sp, #0x48]
    b4b8:      	b	0xb508 <generic_rawtp_path+0x2408>
    b4bc:      	add	x2, x24, #0x10
    b4c0:      	mov	w8, #0x4                // =4
    b4c4:      	add	x9, sp, #0x98
    b4c8:      	add	x0, sp, #0x98
    b4cc:      	mov	w1, #0x8                // =8
    b4d0:      	blr	x8
    b4d4:      	ldr	x8, [sp, #0x58]
    b4d8:      	ldr	x9, [sp, #0x98]
    b4dc:      	cmp	x8, x9
    b4e0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b4e4:      	add	x2, x24, #0x18
    b4e8:      	mov	w8, #0x4                // =4
    b4ec:      	mov	x0, x22
    b4f0:      	mov	w1, #0x8                // =8
    b4f4:      	blr	x8
    b4f8:      	ldr	x24, [sp, #0x98]
    b4fc:      	ldr	x21, [sp, #0x48]
    b500:      	add	x2, x24, #0x20
    b504:      	stp	x2, x24, [sp, #0x50]
    b508:      	ldr	x8, [sp, #0x30]
    b50c:      	cmp	x21, x8
    b510:      	b.ne	0xb520 <generic_rawtp_path+0x2420>
    b514:      	ldr	x8, [sp, #0x38]
    b518:      	cmp	x2, x8
    b51c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b520:      	mov	w8, #0x4                // =4
    b524:      	add	x0, sp, #0x70
    b528:      	mov	w1, #0x8                // =8
    b52c:      	blr	x8
    b530:      	ldr	x8, [sp, #0x70]
    b534:      	cmp	x21, x8
    b538:      	b.eq	0xb628 <generic_rawtp_path+0x2528>
    b53c:      	add	x23, x21, #0x18
    b540:      	mov	w8, #0x4                // =4
    b544:      	add	x9, sp, #0x98
    b548:      	add	x0, sp, #0x98
    b54c:      	mov	w1, #0x8                // =8
    b550:      	mov	x2, x23
    b554:      	blr	x8
    b558:      	ldr	x8, [sp, #0x98]
    b55c:      	cmp	x8, x21
    b560:      	b.eq	0xb628 <generic_rawtp_path+0x2528>
    b564:      	mov	w8, #0x4                // =4
    b568:      	add	x9, sp, #0x78
    b56c:      	add	x0, sp, #0x78
    b570:      	mov	w1, #0x8                // =8
    b574:      	mov	x2, x23
    b578:      	blr	x8
    b57c:      	add	x2, x21, #0x20
    b580:      	mov	w8, #0x4                // =4
    b584:      	mov	w9, #0x10               // =16
    b588:      	add	x10, sp, #0x80
    b58c:      	add	x0, sp, #0x80
    b590:      	mov	w1, #0x10               // =16
    b594:      	blr	x8
    b598:      	ldr	w21, [sp, #0x84]
    b59c:      	ldr	x8, [sp, #0x40]
    b5a0:      	ldr	x10, [sp, #0x60]
    b5a4:      	sub	x12, x10, x8
    b5a8:      	ldr	w23, [sp, #0x68]
    b5ac:      	subs	w10, w21, w23
    b5b0:      	ldr	x9, [sp, #0x88]
    b5b4:      	csel	w10, wzr, w10, lo
    b5b8:      	cmp	w23, w21
    b5bc:      	csel	w11, w23, w21, lo
    b5c0:      	cinc	w13, w11, hi
    b5c4:      	sub	w14, w23, w13
    b5c8:      	subs	x12, x12, x13
    b5cc:      	str	w14, [sp, #0x68]
    b5d0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b5d4:      	cmp	x12, #0xfff
    b5d8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b5dc:      	cmp	w23, w21
    b5e0:      	b.ls	0xb5ec <generic_rawtp_path+0x24ec>
    b5e4:      	mov	w13, #0x2f              // =47
    b5e8:      	strb	w13, [x8, x12]
    b5ec:      	add	x19, x8, x12
    b5f0:      	cmp	w23, w21
    b5f4:      	add	x2, x9, x10
    b5f8:      	and	w1, w11, #0xff
    b5fc:      	mov	w8, #0x4                // =4
    b600:      	cinc	x0, x19, hi
    b604:      	blr	x8
    b608:      	cmp	w23, w21
    b60c:      	str	x19, [sp, #0x60]
    b610:      	add	x19, sp, #0x70
    b614:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b618:      	ldr	x21, [sp, #0x78]
    b61c:      	ldp	x2, x24, [sp, #0x50]
    b620:      	str	x21, [sp, #0x48]
    b624:      	b	0xb674 <generic_rawtp_path+0x2574>
    b628:      	add	x2, x24, #0x10
    b62c:      	mov	w8, #0x4                // =4
    b630:      	add	x9, sp, #0x98
    b634:      	add	x0, sp, #0x98
    b638:      	mov	w1, #0x8                // =8
    b63c:      	blr	x8
    b640:      	ldr	x8, [sp, #0x58]
    b644:      	ldr	x9, [sp, #0x98]
    b648:      	cmp	x8, x9
    b64c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b650:      	add	x2, x24, #0x18
    b654:      	mov	w8, #0x4                // =4
    b658:      	mov	x0, x22
    b65c:      	mov	w1, #0x8                // =8
    b660:      	blr	x8
    b664:      	ldr	x24, [sp, #0x98]
    b668:      	ldr	x21, [sp, #0x48]
    b66c:      	add	x2, x24, #0x20
    b670:      	stp	x2, x24, [sp, #0x50]
    b674:      	ldr	x8, [sp, #0x30]
    b678:      	cmp	x21, x8
    b67c:      	b.ne	0xb68c <generic_rawtp_path+0x258c>
    b680:      	ldr	x8, [sp, #0x38]
    b684:      	cmp	x2, x8
    b688:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b68c:      	mov	w8, #0x4                // =4
    b690:      	add	x0, sp, #0x70
    b694:      	mov	w1, #0x8                // =8
    b698:      	blr	x8
    b69c:      	ldr	x8, [sp, #0x70]
    b6a0:      	cmp	x21, x8
    b6a4:      	b.eq	0xb794 <generic_rawtp_path+0x2694>
    b6a8:      	add	x23, x21, #0x18
    b6ac:      	mov	w8, #0x4                // =4
    b6b0:      	add	x9, sp, #0x98
    b6b4:      	add	x0, sp, #0x98
    b6b8:      	mov	w1, #0x8                // =8
    b6bc:      	mov	x2, x23
    b6c0:      	blr	x8
    b6c4:      	ldr	x8, [sp, #0x98]
    b6c8:      	cmp	x8, x21
    b6cc:      	b.eq	0xb794 <generic_rawtp_path+0x2694>
    b6d0:      	mov	w8, #0x4                // =4
    b6d4:      	add	x9, sp, #0x78
    b6d8:      	add	x0, sp, #0x78
    b6dc:      	mov	w1, #0x8                // =8
    b6e0:      	mov	x2, x23
    b6e4:      	blr	x8
    b6e8:      	add	x2, x21, #0x20
    b6ec:      	mov	w8, #0x4                // =4
    b6f0:      	mov	w9, #0x10               // =16
    b6f4:      	add	x10, sp, #0x80
    b6f8:      	add	x0, sp, #0x80
    b6fc:      	mov	w1, #0x10               // =16
    b700:      	blr	x8
    b704:      	ldr	w21, [sp, #0x84]
    b708:      	ldr	x8, [sp, #0x40]
    b70c:      	ldr	x10, [sp, #0x60]
    b710:      	sub	x12, x10, x8
    b714:      	ldr	w23, [sp, #0x68]
    b718:      	subs	w10, w21, w23
    b71c:      	ldr	x9, [sp, #0x88]
    b720:      	csel	w10, wzr, w10, lo
    b724:      	cmp	w23, w21
    b728:      	csel	w11, w23, w21, lo
    b72c:      	cinc	w13, w11, hi
    b730:      	sub	w14, w23, w13
    b734:      	subs	x12, x12, x13
    b738:      	str	w14, [sp, #0x68]
    b73c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b740:      	cmp	x12, #0xfff
    b744:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b748:      	cmp	w23, w21
    b74c:      	b.ls	0xb758 <generic_rawtp_path+0x2658>
    b750:      	mov	w13, #0x2f              // =47
    b754:      	strb	w13, [x8, x12]
    b758:      	add	x19, x8, x12
    b75c:      	cmp	w23, w21
    b760:      	add	x2, x9, x10
    b764:      	and	w1, w11, #0xff
    b768:      	mov	w8, #0x4                // =4
    b76c:      	cinc	x0, x19, hi
    b770:      	blr	x8
    b774:      	cmp	w23, w21
    b778:      	str	x19, [sp, #0x60]
    b77c:      	add	x19, sp, #0x70
    b780:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b784:      	ldr	x21, [sp, #0x78]
    b788:      	ldp	x2, x24, [sp, #0x50]
    b78c:      	str	x21, [sp, #0x48]
    b790:      	b	0xb7e0 <generic_rawtp_path+0x26e0>
    b794:      	add	x2, x24, #0x10
    b798:      	mov	w8, #0x4                // =4
    b79c:      	add	x9, sp, #0x98
    b7a0:      	add	x0, sp, #0x98
    b7a4:      	mov	w1, #0x8                // =8
    b7a8:      	blr	x8
    b7ac:      	ldr	x8, [sp, #0x58]
    b7b0:      	ldr	x9, [sp, #0x98]
    b7b4:      	cmp	x8, x9
    b7b8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b7bc:      	add	x2, x24, #0x18
    b7c0:      	mov	w8, #0x4                // =4
    b7c4:      	mov	x0, x22
    b7c8:      	mov	w1, #0x8                // =8
    b7cc:      	blr	x8
    b7d0:      	ldr	x24, [sp, #0x98]
    b7d4:      	ldr	x21, [sp, #0x48]
    b7d8:      	add	x2, x24, #0x20
    b7dc:      	stp	x2, x24, [sp, #0x50]
    b7e0:      	ldr	x8, [sp, #0x30]
    b7e4:      	cmp	x21, x8
    b7e8:      	b.ne	0xb7f8 <generic_rawtp_path+0x26f8>
    b7ec:      	ldr	x8, [sp, #0x38]
    b7f0:      	cmp	x2, x8
    b7f4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b7f8:      	mov	w8, #0x4                // =4
    b7fc:      	add	x0, sp, #0x70
    b800:      	mov	w1, #0x8                // =8
    b804:      	blr	x8
    b808:      	ldr	x8, [sp, #0x70]
    b80c:      	cmp	x21, x8
    b810:      	b.eq	0xb900 <generic_rawtp_path+0x2800>
    b814:      	add	x23, x21, #0x18
    b818:      	mov	w8, #0x4                // =4
    b81c:      	add	x9, sp, #0x98
    b820:      	add	x0, sp, #0x98
    b824:      	mov	w1, #0x8                // =8
    b828:      	mov	x2, x23
    b82c:      	blr	x8
    b830:      	ldr	x8, [sp, #0x98]
    b834:      	cmp	x8, x21
    b838:      	b.eq	0xb900 <generic_rawtp_path+0x2800>
    b83c:      	mov	w8, #0x4                // =4
    b840:      	add	x9, sp, #0x78
    b844:      	add	x0, sp, #0x78
    b848:      	mov	w1, #0x8                // =8
    b84c:      	mov	x2, x23
    b850:      	blr	x8
    b854:      	add	x2, x21, #0x20
    b858:      	mov	w8, #0x4                // =4
    b85c:      	mov	w9, #0x10               // =16
    b860:      	add	x10, sp, #0x80
    b864:      	add	x0, sp, #0x80
    b868:      	mov	w1, #0x10               // =16
    b86c:      	blr	x8
    b870:      	ldr	w21, [sp, #0x84]
    b874:      	ldr	x8, [sp, #0x40]
    b878:      	ldr	x10, [sp, #0x60]
    b87c:      	sub	x12, x10, x8
    b880:      	ldr	w23, [sp, #0x68]
    b884:      	subs	w10, w21, w23
    b888:      	ldr	x9, [sp, #0x88]
    b88c:      	csel	w10, wzr, w10, lo
    b890:      	cmp	w23, w21
    b894:      	csel	w11, w23, w21, lo
    b898:      	cinc	w13, w11, hi
    b89c:      	sub	w14, w23, w13
    b8a0:      	subs	x12, x12, x13
    b8a4:      	str	w14, [sp, #0x68]
    b8a8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    b8ac:      	cmp	x12, #0xfff
    b8b0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    b8b4:      	cmp	w23, w21
    b8b8:      	b.ls	0xb8c4 <generic_rawtp_path+0x27c4>
    b8bc:      	mov	w13, #0x2f              // =47
    b8c0:      	strb	w13, [x8, x12]
    b8c4:      	add	x19, x8, x12
    b8c8:      	cmp	w23, w21
    b8cc:      	add	x2, x9, x10
    b8d0:      	and	w1, w11, #0xff
    b8d4:      	mov	w8, #0x4                // =4
    b8d8:      	cinc	x0, x19, hi
    b8dc:      	blr	x8
    b8e0:      	cmp	w23, w21
    b8e4:      	str	x19, [sp, #0x60]
    b8e8:      	add	x19, sp, #0x70
    b8ec:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    b8f0:      	ldr	x21, [sp, #0x78]
    b8f4:      	ldp	x2, x24, [sp, #0x50]
    b8f8:      	str	x21, [sp, #0x48]
    b8fc:      	b	0xb94c <generic_rawtp_path+0x284c>
    b900:      	add	x2, x24, #0x10
    b904:      	mov	w8, #0x4                // =4
    b908:      	add	x9, sp, #0x98
    b90c:      	add	x0, sp, #0x98
    b910:      	mov	w1, #0x8                // =8
    b914:      	blr	x8
    b918:      	ldr	x8, [sp, #0x58]
    b91c:      	ldr	x9, [sp, #0x98]
    b920:      	cmp	x8, x9
    b924:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b928:      	add	x2, x24, #0x18
    b92c:      	mov	w8, #0x4                // =4
    b930:      	mov	x0, x22
    b934:      	mov	w1, #0x8                // =8
    b938:      	blr	x8
    b93c:      	ldr	x24, [sp, #0x98]
    b940:      	ldr	x21, [sp, #0x48]
    b944:      	add	x2, x24, #0x20
    b948:      	stp	x2, x24, [sp, #0x50]
    b94c:      	ldr	x8, [sp, #0x30]
    b950:      	cmp	x21, x8
    b954:      	b.ne	0xb964 <generic_rawtp_path+0x2864>
    b958:      	ldr	x8, [sp, #0x38]
    b95c:      	cmp	x2, x8
    b960:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    b964:      	mov	w8, #0x4                // =4
    b968:      	add	x0, sp, #0x70
    b96c:      	mov	w1, #0x8                // =8
    b970:      	blr	x8
    b974:      	ldr	x8, [sp, #0x70]
    b978:      	cmp	x21, x8
    b97c:      	b.eq	0xba6c <generic_rawtp_path+0x296c>
    b980:      	add	x23, x21, #0x18
    b984:      	mov	w8, #0x4                // =4
    b988:      	add	x9, sp, #0x98
    b98c:      	add	x0, sp, #0x98
    b990:      	mov	w1, #0x8                // =8
    b994:      	mov	x2, x23
    b998:      	blr	x8
    b99c:      	ldr	x8, [sp, #0x98]
    b9a0:      	cmp	x8, x21
    b9a4:      	b.eq	0xba6c <generic_rawtp_path+0x296c>
    b9a8:      	mov	w8, #0x4                // =4
    b9ac:      	add	x9, sp, #0x78
    b9b0:      	add	x0, sp, #0x78
    b9b4:      	mov	w1, #0x8                // =8
    b9b8:      	mov	x2, x23
    b9bc:      	blr	x8
    b9c0:      	add	x2, x21, #0x20
    b9c4:      	mov	w8, #0x4                // =4
    b9c8:      	mov	w9, #0x10               // =16
    b9cc:      	add	x10, sp, #0x80
    b9d0:      	add	x0, sp, #0x80
    b9d4:      	mov	w1, #0x10               // =16
    b9d8:      	blr	x8
    b9dc:      	ldr	w21, [sp, #0x84]
    b9e0:      	ldr	x8, [sp, #0x40]
    b9e4:      	ldr	x10, [sp, #0x60]
    b9e8:      	sub	x12, x10, x8
    b9ec:      	ldr	w23, [sp, #0x68]
    b9f0:      	subs	w10, w21, w23
    b9f4:      	ldr	x9, [sp, #0x88]
    b9f8:      	csel	w10, wzr, w10, lo
    b9fc:      	cmp	w23, w21
    ba00:      	csel	w11, w23, w21, lo
    ba04:      	cinc	w13, w11, hi
    ba08:      	sub	w14, w23, w13
    ba0c:      	subs	x12, x12, x13
    ba10:      	str	w14, [sp, #0x68]
    ba14:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ba18:      	cmp	x12, #0xfff
    ba1c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ba20:      	cmp	w23, w21
    ba24:      	b.ls	0xba30 <generic_rawtp_path+0x2930>
    ba28:      	mov	w13, #0x2f              // =47
    ba2c:      	strb	w13, [x8, x12]
    ba30:      	add	x19, x8, x12
    ba34:      	cmp	w23, w21
    ba38:      	add	x2, x9, x10
    ba3c:      	and	w1, w11, #0xff
    ba40:      	mov	w8, #0x4                // =4
    ba44:      	cinc	x0, x19, hi
    ba48:      	blr	x8
    ba4c:      	cmp	w23, w21
    ba50:      	str	x19, [sp, #0x60]
    ba54:      	add	x19, sp, #0x70
    ba58:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ba5c:      	ldr	x21, [sp, #0x78]
    ba60:      	ldp	x2, x24, [sp, #0x50]
    ba64:      	str	x21, [sp, #0x48]
    ba68:      	b	0xbab8 <generic_rawtp_path+0x29b8>
    ba6c:      	add	x2, x24, #0x10
    ba70:      	mov	w8, #0x4                // =4
    ba74:      	add	x9, sp, #0x98
    ba78:      	add	x0, sp, #0x98
    ba7c:      	mov	w1, #0x8                // =8
    ba80:      	blr	x8
    ba84:      	ldr	x8, [sp, #0x58]
    ba88:      	ldr	x9, [sp, #0x98]
    ba8c:      	cmp	x8, x9
    ba90:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ba94:      	add	x2, x24, #0x18
    ba98:      	mov	w8, #0x4                // =4
    ba9c:      	mov	x0, x22
    baa0:      	mov	w1, #0x8                // =8
    baa4:      	blr	x8
    baa8:      	ldr	x24, [sp, #0x98]
    baac:      	ldr	x21, [sp, #0x48]
    bab0:      	add	x2, x24, #0x20
    bab4:      	stp	x2, x24, [sp, #0x50]
    bab8:      	ldr	x8, [sp, #0x30]
    babc:      	cmp	x21, x8
    bac0:      	b.ne	0xbad0 <generic_rawtp_path+0x29d0>
    bac4:      	ldr	x8, [sp, #0x38]
    bac8:      	cmp	x2, x8
    bacc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bad0:      	mov	w8, #0x4                // =4
    bad4:      	add	x0, sp, #0x70
    bad8:      	mov	w1, #0x8                // =8
    badc:      	blr	x8
    bae0:      	ldr	x8, [sp, #0x70]
    bae4:      	cmp	x21, x8
    bae8:      	b.eq	0xbbd8 <generic_rawtp_path+0x2ad8>
    baec:      	add	x23, x21, #0x18
    baf0:      	mov	w8, #0x4                // =4
    baf4:      	add	x9, sp, #0x98
    baf8:      	add	x0, sp, #0x98
    bafc:      	mov	w1, #0x8                // =8
    bb00:      	mov	x2, x23
    bb04:      	blr	x8
    bb08:      	ldr	x8, [sp, #0x98]
    bb0c:      	cmp	x8, x21
    bb10:      	b.eq	0xbbd8 <generic_rawtp_path+0x2ad8>
    bb14:      	mov	w8, #0x4                // =4
    bb18:      	add	x9, sp, #0x78
    bb1c:      	add	x0, sp, #0x78
    bb20:      	mov	w1, #0x8                // =8
    bb24:      	mov	x2, x23
    bb28:      	blr	x8
    bb2c:      	add	x2, x21, #0x20
    bb30:      	mov	w8, #0x4                // =4
    bb34:      	mov	w9, #0x10               // =16
    bb38:      	add	x10, sp, #0x80
    bb3c:      	add	x0, sp, #0x80
    bb40:      	mov	w1, #0x10               // =16
    bb44:      	blr	x8
    bb48:      	ldr	w21, [sp, #0x84]
    bb4c:      	ldr	x8, [sp, #0x40]
    bb50:      	ldr	x10, [sp, #0x60]
    bb54:      	sub	x12, x10, x8
    bb58:      	ldr	w23, [sp, #0x68]
    bb5c:      	subs	w10, w21, w23
    bb60:      	ldr	x9, [sp, #0x88]
    bb64:      	csel	w10, wzr, w10, lo
    bb68:      	cmp	w23, w21
    bb6c:      	csel	w11, w23, w21, lo
    bb70:      	cinc	w13, w11, hi
    bb74:      	sub	w14, w23, w13
    bb78:      	subs	x12, x12, x13
    bb7c:      	str	w14, [sp, #0x68]
    bb80:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    bb84:      	cmp	x12, #0xfff
    bb88:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    bb8c:      	cmp	w23, w21
    bb90:      	b.ls	0xbb9c <generic_rawtp_path+0x2a9c>
    bb94:      	mov	w13, #0x2f              // =47
    bb98:      	strb	w13, [x8, x12]
    bb9c:      	add	x19, x8, x12
    bba0:      	cmp	w23, w21
    bba4:      	add	x2, x9, x10
    bba8:      	and	w1, w11, #0xff
    bbac:      	mov	w8, #0x4                // =4
    bbb0:      	cinc	x0, x19, hi
    bbb4:      	blr	x8
    bbb8:      	cmp	w23, w21
    bbbc:      	str	x19, [sp, #0x60]
    bbc0:      	add	x19, sp, #0x70
    bbc4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    bbc8:      	ldr	x21, [sp, #0x78]
    bbcc:      	ldp	x2, x24, [sp, #0x50]
    bbd0:      	str	x21, [sp, #0x48]
    bbd4:      	b	0xbc24 <generic_rawtp_path+0x2b24>
    bbd8:      	add	x2, x24, #0x10
    bbdc:      	mov	w8, #0x4                // =4
    bbe0:      	add	x9, sp, #0x98
    bbe4:      	add	x0, sp, #0x98
    bbe8:      	mov	w1, #0x8                // =8
    bbec:      	blr	x8
    bbf0:      	ldr	x8, [sp, #0x58]
    bbf4:      	ldr	x9, [sp, #0x98]
    bbf8:      	cmp	x8, x9
    bbfc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bc00:      	add	x2, x24, #0x18
    bc04:      	mov	w8, #0x4                // =4
    bc08:      	mov	x0, x22
    bc0c:      	mov	w1, #0x8                // =8
    bc10:      	blr	x8
    bc14:      	ldr	x24, [sp, #0x98]
    bc18:      	ldr	x21, [sp, #0x48]
    bc1c:      	add	x2, x24, #0x20
    bc20:      	stp	x2, x24, [sp, #0x50]
    bc24:      	ldr	x8, [sp, #0x30]
    bc28:      	cmp	x21, x8
    bc2c:      	b.ne	0xbc3c <generic_rawtp_path+0x2b3c>
    bc30:      	ldr	x8, [sp, #0x38]
    bc34:      	cmp	x2, x8
    bc38:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bc3c:      	mov	w8, #0x4                // =4
    bc40:      	add	x0, sp, #0x70
    bc44:      	mov	w1, #0x8                // =8
    bc48:      	blr	x8
    bc4c:      	ldr	x8, [sp, #0x70]
    bc50:      	cmp	x21, x8
    bc54:      	b.eq	0xbd44 <generic_rawtp_path+0x2c44>
    bc58:      	add	x23, x21, #0x18
    bc5c:      	mov	w8, #0x4                // =4
    bc60:      	add	x9, sp, #0x98
    bc64:      	add	x0, sp, #0x98
    bc68:      	mov	w1, #0x8                // =8
    bc6c:      	mov	x2, x23
    bc70:      	blr	x8
    bc74:      	ldr	x8, [sp, #0x98]
    bc78:      	cmp	x8, x21
    bc7c:      	b.eq	0xbd44 <generic_rawtp_path+0x2c44>
    bc80:      	mov	w8, #0x4                // =4
    bc84:      	add	x9, sp, #0x78
    bc88:      	add	x0, sp, #0x78
    bc8c:      	mov	w1, #0x8                // =8
    bc90:      	mov	x2, x23
    bc94:      	blr	x8
    bc98:      	add	x2, x21, #0x20
    bc9c:      	mov	w8, #0x4                // =4
    bca0:      	mov	w9, #0x10               // =16
    bca4:      	add	x10, sp, #0x80
    bca8:      	add	x0, sp, #0x80
    bcac:      	mov	w1, #0x10               // =16
    bcb0:      	blr	x8
    bcb4:      	ldr	w21, [sp, #0x84]
    bcb8:      	ldr	x8, [sp, #0x40]
    bcbc:      	ldr	x10, [sp, #0x60]
    bcc0:      	sub	x12, x10, x8
    bcc4:      	ldr	w23, [sp, #0x68]
    bcc8:      	subs	w10, w21, w23
    bccc:      	ldr	x9, [sp, #0x88]
    bcd0:      	csel	w10, wzr, w10, lo
    bcd4:      	cmp	w23, w21
    bcd8:      	csel	w11, w23, w21, lo
    bcdc:      	cinc	w13, w11, hi
    bce0:      	sub	w14, w23, w13
    bce4:      	subs	x12, x12, x13
    bce8:      	str	w14, [sp, #0x68]
    bcec:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    bcf0:      	cmp	x12, #0xfff
    bcf4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    bcf8:      	cmp	w23, w21
    bcfc:      	b.ls	0xbd08 <generic_rawtp_path+0x2c08>
    bd00:      	mov	w13, #0x2f              // =47
    bd04:      	strb	w13, [x8, x12]
    bd08:      	add	x19, x8, x12
    bd0c:      	cmp	w23, w21
    bd10:      	add	x2, x9, x10
    bd14:      	and	w1, w11, #0xff
    bd18:      	mov	w8, #0x4                // =4
    bd1c:      	cinc	x0, x19, hi
    bd20:      	blr	x8
    bd24:      	cmp	w23, w21
    bd28:      	str	x19, [sp, #0x60]
    bd2c:      	add	x19, sp, #0x70
    bd30:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    bd34:      	ldr	x21, [sp, #0x78]
    bd38:      	ldp	x2, x24, [sp, #0x50]
    bd3c:      	str	x21, [sp, #0x48]
    bd40:      	b	0xbd90 <generic_rawtp_path+0x2c90>
    bd44:      	add	x2, x24, #0x10
    bd48:      	mov	w8, #0x4                // =4
    bd4c:      	add	x9, sp, #0x98
    bd50:      	add	x0, sp, #0x98
    bd54:      	mov	w1, #0x8                // =8
    bd58:      	blr	x8
    bd5c:      	ldr	x8, [sp, #0x58]
    bd60:      	ldr	x9, [sp, #0x98]
    bd64:      	cmp	x8, x9
    bd68:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bd6c:      	add	x2, x24, #0x18
    bd70:      	mov	w8, #0x4                // =4
    bd74:      	mov	x0, x22
    bd78:      	mov	w1, #0x8                // =8
    bd7c:      	blr	x8
    bd80:      	ldr	x24, [sp, #0x98]
    bd84:      	ldr	x21, [sp, #0x48]
    bd88:      	add	x2, x24, #0x20
    bd8c:      	stp	x2, x24, [sp, #0x50]
    bd90:      	ldr	x8, [sp, #0x30]
    bd94:      	cmp	x21, x8
    bd98:      	b.ne	0xbda8 <generic_rawtp_path+0x2ca8>
    bd9c:      	ldr	x8, [sp, #0x38]
    bda0:      	cmp	x2, x8
    bda4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bda8:      	mov	w8, #0x4                // =4
    bdac:      	add	x0, sp, #0x70
    bdb0:      	mov	w1, #0x8                // =8
    bdb4:      	blr	x8
    bdb8:      	ldr	x8, [sp, #0x70]
    bdbc:      	cmp	x21, x8
    bdc0:      	b.eq	0xbeb0 <generic_rawtp_path+0x2db0>
    bdc4:      	add	x23, x21, #0x18
    bdc8:      	mov	w8, #0x4                // =4
    bdcc:      	add	x9, sp, #0x98
    bdd0:      	add	x0, sp, #0x98
    bdd4:      	mov	w1, #0x8                // =8
    bdd8:      	mov	x2, x23
    bddc:      	blr	x8
    bde0:      	ldr	x8, [sp, #0x98]
    bde4:      	cmp	x8, x21
    bde8:      	b.eq	0xbeb0 <generic_rawtp_path+0x2db0>
    bdec:      	mov	w8, #0x4                // =4
    bdf0:      	add	x9, sp, #0x78
    bdf4:      	add	x0, sp, #0x78
    bdf8:      	mov	w1, #0x8                // =8
    bdfc:      	mov	x2, x23
    be00:      	blr	x8
    be04:      	add	x2, x21, #0x20
    be08:      	mov	w8, #0x4                // =4
    be0c:      	mov	w9, #0x10               // =16
    be10:      	add	x10, sp, #0x80
    be14:      	add	x0, sp, #0x80
    be18:      	mov	w1, #0x10               // =16
    be1c:      	blr	x8
    be20:      	ldr	w21, [sp, #0x84]
    be24:      	ldr	x8, [sp, #0x40]
    be28:      	ldr	x10, [sp, #0x60]
    be2c:      	sub	x12, x10, x8
    be30:      	ldr	w23, [sp, #0x68]
    be34:      	subs	w10, w21, w23
    be38:      	ldr	x9, [sp, #0x88]
    be3c:      	csel	w10, wzr, w10, lo
    be40:      	cmp	w23, w21
    be44:      	csel	w11, w23, w21, lo
    be48:      	cinc	w13, w11, hi
    be4c:      	sub	w14, w23, w13
    be50:      	subs	x12, x12, x13
    be54:      	str	w14, [sp, #0x68]
    be58:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    be5c:      	cmp	x12, #0xfff
    be60:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    be64:      	cmp	w23, w21
    be68:      	b.ls	0xbe74 <generic_rawtp_path+0x2d74>
    be6c:      	mov	w13, #0x2f              // =47
    be70:      	strb	w13, [x8, x12]
    be74:      	add	x19, x8, x12
    be78:      	cmp	w23, w21
    be7c:      	add	x2, x9, x10
    be80:      	and	w1, w11, #0xff
    be84:      	mov	w8, #0x4                // =4
    be88:      	cinc	x0, x19, hi
    be8c:      	blr	x8
    be90:      	cmp	w23, w21
    be94:      	str	x19, [sp, #0x60]
    be98:      	add	x19, sp, #0x70
    be9c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    bea0:      	ldr	x21, [sp, #0x78]
    bea4:      	ldp	x2, x24, [sp, #0x50]
    bea8:      	str	x21, [sp, #0x48]
    beac:      	b	0xbefc <generic_rawtp_path+0x2dfc>
    beb0:      	add	x2, x24, #0x10
    beb4:      	mov	w8, #0x4                // =4
    beb8:      	add	x9, sp, #0x98
    bebc:      	add	x0, sp, #0x98
    bec0:      	mov	w1, #0x8                // =8
    bec4:      	blr	x8
    bec8:      	ldr	x8, [sp, #0x58]
    becc:      	ldr	x9, [sp, #0x98]
    bed0:      	cmp	x8, x9
    bed4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bed8:      	add	x2, x24, #0x18
    bedc:      	mov	w8, #0x4                // =4
    bee0:      	mov	x0, x22
    bee4:      	mov	w1, #0x8                // =8
    bee8:      	blr	x8
    beec:      	ldr	x24, [sp, #0x98]
    bef0:      	ldr	x21, [sp, #0x48]
    bef4:      	add	x2, x24, #0x20
    bef8:      	stp	x2, x24, [sp, #0x50]
    befc:      	ldr	x8, [sp, #0x30]
    bf00:      	cmp	x21, x8
    bf04:      	b.ne	0xbf14 <generic_rawtp_path+0x2e14>
    bf08:      	ldr	x8, [sp, #0x38]
    bf0c:      	cmp	x2, x8
    bf10:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    bf14:      	mov	w8, #0x4                // =4
    bf18:      	add	x0, sp, #0x70
    bf1c:      	mov	w1, #0x8                // =8
    bf20:      	blr	x8
    bf24:      	ldr	x8, [sp, #0x70]
    bf28:      	cmp	x21, x8
    bf2c:      	b.eq	0xc01c <generic_rawtp_path+0x2f1c>
    bf30:      	add	x23, x21, #0x18
    bf34:      	mov	w8, #0x4                // =4
    bf38:      	add	x9, sp, #0x98
    bf3c:      	add	x0, sp, #0x98
    bf40:      	mov	w1, #0x8                // =8
    bf44:      	mov	x2, x23
    bf48:      	blr	x8
    bf4c:      	ldr	x8, [sp, #0x98]
    bf50:      	cmp	x8, x21
    bf54:      	b.eq	0xc01c <generic_rawtp_path+0x2f1c>
    bf58:      	mov	w8, #0x4                // =4
    bf5c:      	add	x9, sp, #0x78
    bf60:      	add	x0, sp, #0x78
    bf64:      	mov	w1, #0x8                // =8
    bf68:      	mov	x2, x23
    bf6c:      	blr	x8
    bf70:      	add	x2, x21, #0x20
    bf74:      	mov	w8, #0x4                // =4
    bf78:      	mov	w9, #0x10               // =16
    bf7c:      	add	x10, sp, #0x80
    bf80:      	add	x0, sp, #0x80
    bf84:      	mov	w1, #0x10               // =16
    bf88:      	blr	x8
    bf8c:      	ldr	w21, [sp, #0x84]
    bf90:      	ldr	x8, [sp, #0x40]
    bf94:      	ldr	x10, [sp, #0x60]
    bf98:      	sub	x12, x10, x8
    bf9c:      	ldr	w23, [sp, #0x68]
    bfa0:      	subs	w10, w21, w23
    bfa4:      	ldr	x9, [sp, #0x88]
    bfa8:      	csel	w10, wzr, w10, lo
    bfac:      	cmp	w23, w21
    bfb0:      	csel	w11, w23, w21, lo
    bfb4:      	cinc	w13, w11, hi
    bfb8:      	sub	w14, w23, w13
    bfbc:      	subs	x12, x12, x13
    bfc0:      	str	w14, [sp, #0x68]
    bfc4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    bfc8:      	cmp	x12, #0xfff
    bfcc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    bfd0:      	cmp	w23, w21
    bfd4:      	b.ls	0xbfe0 <generic_rawtp_path+0x2ee0>
    bfd8:      	mov	w13, #0x2f              // =47
    bfdc:      	strb	w13, [x8, x12]
    bfe0:      	add	x19, x8, x12
    bfe4:      	cmp	w23, w21
    bfe8:      	add	x2, x9, x10
    bfec:      	and	w1, w11, #0xff
    bff0:      	mov	w8, #0x4                // =4
    bff4:      	cinc	x0, x19, hi
    bff8:      	blr	x8
    bffc:      	cmp	w23, w21
    c000:      	str	x19, [sp, #0x60]
    c004:      	add	x19, sp, #0x70
    c008:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c00c:      	ldr	x21, [sp, #0x78]
    c010:      	ldp	x2, x24, [sp, #0x50]
    c014:      	str	x21, [sp, #0x48]
    c018:      	b	0xc068 <generic_rawtp_path+0x2f68>
    c01c:      	add	x2, x24, #0x10
    c020:      	mov	w8, #0x4                // =4
    c024:      	add	x9, sp, #0x98
    c028:      	add	x0, sp, #0x98
    c02c:      	mov	w1, #0x8                // =8
    c030:      	blr	x8
    c034:      	ldr	x8, [sp, #0x58]
    c038:      	ldr	x9, [sp, #0x98]
    c03c:      	cmp	x8, x9
    c040:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c044:      	add	x2, x24, #0x18
    c048:      	mov	w8, #0x4                // =4
    c04c:      	mov	x0, x22
    c050:      	mov	w1, #0x8                // =8
    c054:      	blr	x8
    c058:      	ldr	x24, [sp, #0x98]
    c05c:      	ldr	x21, [sp, #0x48]
    c060:      	add	x2, x24, #0x20
    c064:      	stp	x2, x24, [sp, #0x50]
    c068:      	ldr	x8, [sp, #0x30]
    c06c:      	cmp	x21, x8
    c070:      	b.ne	0xc080 <generic_rawtp_path+0x2f80>
    c074:      	ldr	x8, [sp, #0x38]
    c078:      	cmp	x2, x8
    c07c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c080:      	mov	w8, #0x4                // =4
    c084:      	add	x0, sp, #0x70
    c088:      	mov	w1, #0x8                // =8
    c08c:      	blr	x8
    c090:      	ldr	x8, [sp, #0x70]
    c094:      	cmp	x21, x8
    c098:      	b.eq	0xc188 <generic_rawtp_path+0x3088>
    c09c:      	add	x23, x21, #0x18
    c0a0:      	mov	w8, #0x4                // =4
    c0a4:      	add	x9, sp, #0x98
    c0a8:      	add	x0, sp, #0x98
    c0ac:      	mov	w1, #0x8                // =8
    c0b0:      	mov	x2, x23
    c0b4:      	blr	x8
    c0b8:      	ldr	x8, [sp, #0x98]
    c0bc:      	cmp	x8, x21
    c0c0:      	b.eq	0xc188 <generic_rawtp_path+0x3088>
    c0c4:      	mov	w8, #0x4                // =4
    c0c8:      	add	x9, sp, #0x78
    c0cc:      	add	x0, sp, #0x78
    c0d0:      	mov	w1, #0x8                // =8
    c0d4:      	mov	x2, x23
    c0d8:      	blr	x8
    c0dc:      	add	x2, x21, #0x20
    c0e0:      	mov	w8, #0x4                // =4
    c0e4:      	mov	w9, #0x10               // =16
    c0e8:      	add	x10, sp, #0x80
    c0ec:      	add	x0, sp, #0x80
    c0f0:      	mov	w1, #0x10               // =16
    c0f4:      	blr	x8
    c0f8:      	ldr	w21, [sp, #0x84]
    c0fc:      	ldr	x8, [sp, #0x40]
    c100:      	ldr	x10, [sp, #0x60]
    c104:      	sub	x12, x10, x8
    c108:      	ldr	w23, [sp, #0x68]
    c10c:      	subs	w10, w21, w23
    c110:      	ldr	x9, [sp, #0x88]
    c114:      	csel	w10, wzr, w10, lo
    c118:      	cmp	w23, w21
    c11c:      	csel	w11, w23, w21, lo
    c120:      	cinc	w13, w11, hi
    c124:      	sub	w14, w23, w13
    c128:      	subs	x12, x12, x13
    c12c:      	str	w14, [sp, #0x68]
    c130:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c134:      	cmp	x12, #0xfff
    c138:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c13c:      	cmp	w23, w21
    c140:      	b.ls	0xc14c <generic_rawtp_path+0x304c>
    c144:      	mov	w13, #0x2f              // =47
    c148:      	strb	w13, [x8, x12]
    c14c:      	add	x19, x8, x12
    c150:      	cmp	w23, w21
    c154:      	add	x2, x9, x10
    c158:      	and	w1, w11, #0xff
    c15c:      	mov	w8, #0x4                // =4
    c160:      	cinc	x0, x19, hi
    c164:      	blr	x8
    c168:      	cmp	w23, w21
    c16c:      	str	x19, [sp, #0x60]
    c170:      	add	x19, sp, #0x70
    c174:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c178:      	ldr	x21, [sp, #0x78]
    c17c:      	ldp	x2, x24, [sp, #0x50]
    c180:      	str	x21, [sp, #0x48]
    c184:      	b	0xc1d4 <generic_rawtp_path+0x30d4>
    c188:      	add	x2, x24, #0x10
    c18c:      	mov	w8, #0x4                // =4
    c190:      	add	x9, sp, #0x98
    c194:      	add	x0, sp, #0x98
    c198:      	mov	w1, #0x8                // =8
    c19c:      	blr	x8
    c1a0:      	ldr	x8, [sp, #0x58]
    c1a4:      	ldr	x9, [sp, #0x98]
    c1a8:      	cmp	x8, x9
    c1ac:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c1b0:      	add	x2, x24, #0x18
    c1b4:      	mov	w8, #0x4                // =4
    c1b8:      	mov	x0, x22
    c1bc:      	mov	w1, #0x8                // =8
    c1c0:      	blr	x8
    c1c4:      	ldr	x24, [sp, #0x98]
    c1c8:      	ldr	x21, [sp, #0x48]
    c1cc:      	add	x2, x24, #0x20
    c1d0:      	stp	x2, x24, [sp, #0x50]
    c1d4:      	ldr	x8, [sp, #0x30]
    c1d8:      	cmp	x21, x8
    c1dc:      	b.ne	0xc1ec <generic_rawtp_path+0x30ec>
    c1e0:      	ldr	x8, [sp, #0x38]
    c1e4:      	cmp	x2, x8
    c1e8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c1ec:      	mov	w8, #0x4                // =4
    c1f0:      	add	x0, sp, #0x70
    c1f4:      	mov	w1, #0x8                // =8
    c1f8:      	blr	x8
    c1fc:      	ldr	x8, [sp, #0x70]
    c200:      	cmp	x21, x8
    c204:      	b.eq	0xc2f4 <generic_rawtp_path+0x31f4>
    c208:      	add	x23, x21, #0x18
    c20c:      	mov	w8, #0x4                // =4
    c210:      	add	x9, sp, #0x98
    c214:      	add	x0, sp, #0x98
    c218:      	mov	w1, #0x8                // =8
    c21c:      	mov	x2, x23
    c220:      	blr	x8
    c224:      	ldr	x8, [sp, #0x98]
    c228:      	cmp	x8, x21
    c22c:      	b.eq	0xc2f4 <generic_rawtp_path+0x31f4>
    c230:      	mov	w8, #0x4                // =4
    c234:      	add	x9, sp, #0x78
    c238:      	add	x0, sp, #0x78
    c23c:      	mov	w1, #0x8                // =8
    c240:      	mov	x2, x23
    c244:      	blr	x8
    c248:      	add	x2, x21, #0x20
    c24c:      	mov	w8, #0x4                // =4
    c250:      	mov	w9, #0x10               // =16
    c254:      	add	x10, sp, #0x80
    c258:      	add	x0, sp, #0x80
    c25c:      	mov	w1, #0x10               // =16
    c260:      	blr	x8
    c264:      	ldr	w21, [sp, #0x84]
    c268:      	ldr	x8, [sp, #0x40]
    c26c:      	ldr	x10, [sp, #0x60]
    c270:      	sub	x12, x10, x8
    c274:      	ldr	w23, [sp, #0x68]
    c278:      	subs	w10, w21, w23
    c27c:      	ldr	x9, [sp, #0x88]
    c280:      	csel	w10, wzr, w10, lo
    c284:      	cmp	w23, w21
    c288:      	csel	w11, w23, w21, lo
    c28c:      	cinc	w13, w11, hi
    c290:      	sub	w14, w23, w13
    c294:      	subs	x12, x12, x13
    c298:      	str	w14, [sp, #0x68]
    c29c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c2a0:      	cmp	x12, #0xfff
    c2a4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c2a8:      	cmp	w23, w21
    c2ac:      	b.ls	0xc2b8 <generic_rawtp_path+0x31b8>
    c2b0:      	mov	w13, #0x2f              // =47
    c2b4:      	strb	w13, [x8, x12]
    c2b8:      	add	x19, x8, x12
    c2bc:      	cmp	w23, w21
    c2c0:      	add	x2, x9, x10
    c2c4:      	and	w1, w11, #0xff
    c2c8:      	mov	w8, #0x4                // =4
    c2cc:      	cinc	x0, x19, hi
    c2d0:      	blr	x8
    c2d4:      	cmp	w23, w21
    c2d8:      	str	x19, [sp, #0x60]
    c2dc:      	add	x19, sp, #0x70
    c2e0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c2e4:      	ldr	x21, [sp, #0x78]
    c2e8:      	ldp	x2, x24, [sp, #0x50]
    c2ec:      	str	x21, [sp, #0x48]
    c2f0:      	b	0xc340 <generic_rawtp_path+0x3240>
    c2f4:      	add	x2, x24, #0x10
    c2f8:      	mov	w8, #0x4                // =4
    c2fc:      	add	x9, sp, #0x98
    c300:      	add	x0, sp, #0x98
    c304:      	mov	w1, #0x8                // =8
    c308:      	blr	x8
    c30c:      	ldr	x8, [sp, #0x58]
    c310:      	ldr	x9, [sp, #0x98]
    c314:      	cmp	x8, x9
    c318:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c31c:      	add	x2, x24, #0x18
    c320:      	mov	w8, #0x4                // =4
    c324:      	mov	x0, x22
    c328:      	mov	w1, #0x8                // =8
    c32c:      	blr	x8
    c330:      	ldr	x24, [sp, #0x98]
    c334:      	ldr	x21, [sp, #0x48]
    c338:      	add	x2, x24, #0x20
    c33c:      	stp	x2, x24, [sp, #0x50]
    c340:      	ldr	x8, [sp, #0x30]
    c344:      	cmp	x21, x8
    c348:      	b.ne	0xc358 <generic_rawtp_path+0x3258>
    c34c:      	ldr	x8, [sp, #0x38]
    c350:      	cmp	x2, x8
    c354:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c358:      	mov	w8, #0x4                // =4
    c35c:      	add	x0, sp, #0x70
    c360:      	mov	w1, #0x8                // =8
    c364:      	blr	x8
    c368:      	ldr	x8, [sp, #0x70]
    c36c:      	cmp	x21, x8
    c370:      	b.eq	0xc460 <generic_rawtp_path+0x3360>
    c374:      	add	x23, x21, #0x18
    c378:      	mov	w8, #0x4                // =4
    c37c:      	add	x9, sp, #0x98
    c380:      	add	x0, sp, #0x98
    c384:      	mov	w1, #0x8                // =8
    c388:      	mov	x2, x23
    c38c:      	blr	x8
    c390:      	ldr	x8, [sp, #0x98]
    c394:      	cmp	x8, x21
    c398:      	b.eq	0xc460 <generic_rawtp_path+0x3360>
    c39c:      	mov	w8, #0x4                // =4
    c3a0:      	add	x9, sp, #0x78
    c3a4:      	add	x0, sp, #0x78
    c3a8:      	mov	w1, #0x8                // =8
    c3ac:      	mov	x2, x23
    c3b0:      	blr	x8
    c3b4:      	add	x2, x21, #0x20
    c3b8:      	mov	w8, #0x4                // =4
    c3bc:      	mov	w9, #0x10               // =16
    c3c0:      	add	x10, sp, #0x80
    c3c4:      	add	x0, sp, #0x80
    c3c8:      	mov	w1, #0x10               // =16
    c3cc:      	blr	x8
    c3d0:      	ldr	w21, [sp, #0x84]
    c3d4:      	ldr	x8, [sp, #0x40]
    c3d8:      	ldr	x10, [sp, #0x60]
    c3dc:      	sub	x12, x10, x8
    c3e0:      	ldr	w23, [sp, #0x68]
    c3e4:      	subs	w10, w21, w23
    c3e8:      	ldr	x9, [sp, #0x88]
    c3ec:      	csel	w10, wzr, w10, lo
    c3f0:      	cmp	w23, w21
    c3f4:      	csel	w11, w23, w21, lo
    c3f8:      	cinc	w13, w11, hi
    c3fc:      	sub	w14, w23, w13
    c400:      	subs	x12, x12, x13
    c404:      	str	w14, [sp, #0x68]
    c408:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c40c:      	cmp	x12, #0xfff
    c410:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c414:      	cmp	w23, w21
    c418:      	b.ls	0xc424 <generic_rawtp_path+0x3324>
    c41c:      	mov	w13, #0x2f              // =47
    c420:      	strb	w13, [x8, x12]
    c424:      	add	x19, x8, x12
    c428:      	cmp	w23, w21
    c42c:      	add	x2, x9, x10
    c430:      	and	w1, w11, #0xff
    c434:      	mov	w8, #0x4                // =4
    c438:      	cinc	x0, x19, hi
    c43c:      	blr	x8
    c440:      	cmp	w23, w21
    c444:      	str	x19, [sp, #0x60]
    c448:      	add	x19, sp, #0x70
    c44c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c450:      	ldr	x21, [sp, #0x78]
    c454:      	ldp	x2, x24, [sp, #0x50]
    c458:      	str	x21, [sp, #0x48]
    c45c:      	b	0xc4ac <generic_rawtp_path+0x33ac>
    c460:      	add	x2, x24, #0x10
    c464:      	mov	w8, #0x4                // =4
    c468:      	add	x9, sp, #0x98
    c46c:      	add	x0, sp, #0x98
    c470:      	mov	w1, #0x8                // =8
    c474:      	blr	x8
    c478:      	ldr	x8, [sp, #0x58]
    c47c:      	ldr	x9, [sp, #0x98]
    c480:      	cmp	x8, x9
    c484:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c488:      	add	x2, x24, #0x18
    c48c:      	mov	w8, #0x4                // =4
    c490:      	mov	x0, x22
    c494:      	mov	w1, #0x8                // =8
    c498:      	blr	x8
    c49c:      	ldr	x24, [sp, #0x98]
    c4a0:      	ldr	x21, [sp, #0x48]
    c4a4:      	add	x2, x24, #0x20
    c4a8:      	stp	x2, x24, [sp, #0x50]
    c4ac:      	ldr	x8, [sp, #0x30]
    c4b0:      	cmp	x21, x8
    c4b4:      	b.ne	0xc4c4 <generic_rawtp_path+0x33c4>
    c4b8:      	ldr	x8, [sp, #0x38]
    c4bc:      	cmp	x2, x8
    c4c0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c4c4:      	mov	w8, #0x4                // =4
    c4c8:      	add	x0, sp, #0x70
    c4cc:      	mov	w1, #0x8                // =8
    c4d0:      	blr	x8
    c4d4:      	ldr	x8, [sp, #0x70]
    c4d8:      	cmp	x21, x8
    c4dc:      	b.eq	0xc5cc <generic_rawtp_path+0x34cc>
    c4e0:      	add	x23, x21, #0x18
    c4e4:      	mov	w8, #0x4                // =4
    c4e8:      	add	x9, sp, #0x98
    c4ec:      	add	x0, sp, #0x98
    c4f0:      	mov	w1, #0x8                // =8
    c4f4:      	mov	x2, x23
    c4f8:      	blr	x8
    c4fc:      	ldr	x8, [sp, #0x98]
    c500:      	cmp	x8, x21
    c504:      	b.eq	0xc5cc <generic_rawtp_path+0x34cc>
    c508:      	mov	w8, #0x4                // =4
    c50c:      	add	x9, sp, #0x78
    c510:      	add	x0, sp, #0x78
    c514:      	mov	w1, #0x8                // =8
    c518:      	mov	x2, x23
    c51c:      	blr	x8
    c520:      	add	x2, x21, #0x20
    c524:      	mov	w8, #0x4                // =4
    c528:      	mov	w9, #0x10               // =16
    c52c:      	add	x10, sp, #0x80
    c530:      	add	x0, sp, #0x80
    c534:      	mov	w1, #0x10               // =16
    c538:      	blr	x8
    c53c:      	ldr	w21, [sp, #0x84]
    c540:      	ldr	x8, [sp, #0x40]
    c544:      	ldr	x10, [sp, #0x60]
    c548:      	sub	x12, x10, x8
    c54c:      	ldr	w23, [sp, #0x68]
    c550:      	subs	w10, w21, w23
    c554:      	ldr	x9, [sp, #0x88]
    c558:      	csel	w10, wzr, w10, lo
    c55c:      	cmp	w23, w21
    c560:      	csel	w11, w23, w21, lo
    c564:      	cinc	w13, w11, hi
    c568:      	sub	w14, w23, w13
    c56c:      	subs	x12, x12, x13
    c570:      	str	w14, [sp, #0x68]
    c574:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c578:      	cmp	x12, #0xfff
    c57c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c580:      	cmp	w23, w21
    c584:      	b.ls	0xc590 <generic_rawtp_path+0x3490>
    c588:      	mov	w13, #0x2f              // =47
    c58c:      	strb	w13, [x8, x12]
    c590:      	add	x19, x8, x12
    c594:      	cmp	w23, w21
    c598:      	add	x2, x9, x10
    c59c:      	and	w1, w11, #0xff
    c5a0:      	mov	w8, #0x4                // =4
    c5a4:      	cinc	x0, x19, hi
    c5a8:      	blr	x8
    c5ac:      	cmp	w23, w21
    c5b0:      	str	x19, [sp, #0x60]
    c5b4:      	add	x19, sp, #0x70
    c5b8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c5bc:      	ldr	x21, [sp, #0x78]
    c5c0:      	ldp	x2, x24, [sp, #0x50]
    c5c4:      	str	x21, [sp, #0x48]
    c5c8:      	b	0xc618 <generic_rawtp_path+0x3518>
    c5cc:      	add	x2, x24, #0x10
    c5d0:      	mov	w8, #0x4                // =4
    c5d4:      	add	x9, sp, #0x98
    c5d8:      	add	x0, sp, #0x98
    c5dc:      	mov	w1, #0x8                // =8
    c5e0:      	blr	x8
    c5e4:      	ldr	x8, [sp, #0x58]
    c5e8:      	ldr	x9, [sp, #0x98]
    c5ec:      	cmp	x8, x9
    c5f0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c5f4:      	add	x2, x24, #0x18
    c5f8:      	mov	w8, #0x4                // =4
    c5fc:      	mov	x0, x22
    c600:      	mov	w1, #0x8                // =8
    c604:      	blr	x8
    c608:      	ldr	x24, [sp, #0x98]
    c60c:      	ldr	x21, [sp, #0x48]
    c610:      	add	x2, x24, #0x20
    c614:      	stp	x2, x24, [sp, #0x50]
    c618:      	ldr	x8, [sp, #0x30]
    c61c:      	cmp	x21, x8
    c620:      	b.ne	0xc630 <generic_rawtp_path+0x3530>
    c624:      	ldr	x8, [sp, #0x38]
    c628:      	cmp	x2, x8
    c62c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c630:      	mov	w8, #0x4                // =4
    c634:      	add	x0, sp, #0x70
    c638:      	mov	w1, #0x8                // =8
    c63c:      	blr	x8
    c640:      	ldr	x8, [sp, #0x70]
    c644:      	cmp	x21, x8
    c648:      	b.eq	0xc738 <generic_rawtp_path+0x3638>
    c64c:      	add	x23, x21, #0x18
    c650:      	mov	w8, #0x4                // =4
    c654:      	add	x9, sp, #0x98
    c658:      	add	x0, sp, #0x98
    c65c:      	mov	w1, #0x8                // =8
    c660:      	mov	x2, x23
    c664:      	blr	x8
    c668:      	ldr	x8, [sp, #0x98]
    c66c:      	cmp	x8, x21
    c670:      	b.eq	0xc738 <generic_rawtp_path+0x3638>
    c674:      	mov	w8, #0x4                // =4
    c678:      	add	x9, sp, #0x78
    c67c:      	add	x0, sp, #0x78
    c680:      	mov	w1, #0x8                // =8
    c684:      	mov	x2, x23
    c688:      	blr	x8
    c68c:      	add	x2, x21, #0x20
    c690:      	mov	w8, #0x4                // =4
    c694:      	mov	w9, #0x10               // =16
    c698:      	add	x10, sp, #0x80
    c69c:      	add	x0, sp, #0x80
    c6a0:      	mov	w1, #0x10               // =16
    c6a4:      	blr	x8
    c6a8:      	ldr	w21, [sp, #0x84]
    c6ac:      	ldr	x8, [sp, #0x40]
    c6b0:      	ldr	x10, [sp, #0x60]
    c6b4:      	sub	x12, x10, x8
    c6b8:      	ldr	w23, [sp, #0x68]
    c6bc:      	subs	w10, w21, w23
    c6c0:      	ldr	x9, [sp, #0x88]
    c6c4:      	csel	w10, wzr, w10, lo
    c6c8:      	cmp	w23, w21
    c6cc:      	csel	w11, w23, w21, lo
    c6d0:      	cinc	w13, w11, hi
    c6d4:      	sub	w14, w23, w13
    c6d8:      	subs	x12, x12, x13
    c6dc:      	str	w14, [sp, #0x68]
    c6e0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c6e4:      	cmp	x12, #0xfff
    c6e8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c6ec:      	cmp	w23, w21
    c6f0:      	b.ls	0xc6fc <generic_rawtp_path+0x35fc>
    c6f4:      	mov	w13, #0x2f              // =47
    c6f8:      	strb	w13, [x8, x12]
    c6fc:      	add	x19, x8, x12
    c700:      	cmp	w23, w21
    c704:      	add	x2, x9, x10
    c708:      	and	w1, w11, #0xff
    c70c:      	mov	w8, #0x4                // =4
    c710:      	cinc	x0, x19, hi
    c714:      	blr	x8
    c718:      	cmp	w23, w21
    c71c:      	str	x19, [sp, #0x60]
    c720:      	add	x19, sp, #0x70
    c724:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c728:      	ldr	x21, [sp, #0x78]
    c72c:      	ldp	x2, x24, [sp, #0x50]
    c730:      	str	x21, [sp, #0x48]
    c734:      	b	0xc784 <generic_rawtp_path+0x3684>
    c738:      	add	x2, x24, #0x10
    c73c:      	mov	w8, #0x4                // =4
    c740:      	add	x9, sp, #0x98
    c744:      	add	x0, sp, #0x98
    c748:      	mov	w1, #0x8                // =8
    c74c:      	blr	x8
    c750:      	ldr	x8, [sp, #0x58]
    c754:      	ldr	x9, [sp, #0x98]
    c758:      	cmp	x8, x9
    c75c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c760:      	add	x2, x24, #0x18
    c764:      	mov	w8, #0x4                // =4
    c768:      	mov	x0, x22
    c76c:      	mov	w1, #0x8                // =8
    c770:      	blr	x8
    c774:      	ldr	x24, [sp, #0x98]
    c778:      	ldr	x21, [sp, #0x48]
    c77c:      	add	x2, x24, #0x20
    c780:      	stp	x2, x24, [sp, #0x50]
    c784:      	ldr	x8, [sp, #0x30]
    c788:      	cmp	x21, x8
    c78c:      	b.ne	0xc79c <generic_rawtp_path+0x369c>
    c790:      	ldr	x8, [sp, #0x38]
    c794:      	cmp	x2, x8
    c798:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c79c:      	mov	w8, #0x4                // =4
    c7a0:      	add	x0, sp, #0x70
    c7a4:      	mov	w1, #0x8                // =8
    c7a8:      	blr	x8
    c7ac:      	ldr	x8, [sp, #0x70]
    c7b0:      	cmp	x21, x8
    c7b4:      	b.eq	0xc8a4 <generic_rawtp_path+0x37a4>
    c7b8:      	add	x23, x21, #0x18
    c7bc:      	mov	w8, #0x4                // =4
    c7c0:      	add	x9, sp, #0x98
    c7c4:      	add	x0, sp, #0x98
    c7c8:      	mov	w1, #0x8                // =8
    c7cc:      	mov	x2, x23
    c7d0:      	blr	x8
    c7d4:      	ldr	x8, [sp, #0x98]
    c7d8:      	cmp	x8, x21
    c7dc:      	b.eq	0xc8a4 <generic_rawtp_path+0x37a4>
    c7e0:      	mov	w8, #0x4                // =4
    c7e4:      	add	x9, sp, #0x78
    c7e8:      	add	x0, sp, #0x78
    c7ec:      	mov	w1, #0x8                // =8
    c7f0:      	mov	x2, x23
    c7f4:      	blr	x8
    c7f8:      	add	x2, x21, #0x20
    c7fc:      	mov	w8, #0x4                // =4
    c800:      	mov	w9, #0x10               // =16
    c804:      	add	x10, sp, #0x80
    c808:      	add	x0, sp, #0x80
    c80c:      	mov	w1, #0x10               // =16
    c810:      	blr	x8
    c814:      	ldr	w21, [sp, #0x84]
    c818:      	ldr	x8, [sp, #0x40]
    c81c:      	ldr	x10, [sp, #0x60]
    c820:      	sub	x12, x10, x8
    c824:      	ldr	w23, [sp, #0x68]
    c828:      	subs	w10, w21, w23
    c82c:      	ldr	x9, [sp, #0x88]
    c830:      	csel	w10, wzr, w10, lo
    c834:      	cmp	w23, w21
    c838:      	csel	w11, w23, w21, lo
    c83c:      	cinc	w13, w11, hi
    c840:      	sub	w14, w23, w13
    c844:      	subs	x12, x12, x13
    c848:      	str	w14, [sp, #0x68]
    c84c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c850:      	cmp	x12, #0xfff
    c854:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c858:      	cmp	w23, w21
    c85c:      	b.ls	0xc868 <generic_rawtp_path+0x3768>
    c860:      	mov	w13, #0x2f              // =47
    c864:      	strb	w13, [x8, x12]
    c868:      	add	x19, x8, x12
    c86c:      	cmp	w23, w21
    c870:      	add	x2, x9, x10
    c874:      	and	w1, w11, #0xff
    c878:      	mov	w8, #0x4                // =4
    c87c:      	cinc	x0, x19, hi
    c880:      	blr	x8
    c884:      	cmp	w23, w21
    c888:      	str	x19, [sp, #0x60]
    c88c:      	add	x19, sp, #0x70
    c890:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    c894:      	ldr	x21, [sp, #0x78]
    c898:      	ldp	x2, x24, [sp, #0x50]
    c89c:      	str	x21, [sp, #0x48]
    c8a0:      	b	0xc8f0 <generic_rawtp_path+0x37f0>
    c8a4:      	add	x2, x24, #0x10
    c8a8:      	mov	w8, #0x4                // =4
    c8ac:      	add	x9, sp, #0x98
    c8b0:      	add	x0, sp, #0x98
    c8b4:      	mov	w1, #0x8                // =8
    c8b8:      	blr	x8
    c8bc:      	ldr	x8, [sp, #0x58]
    c8c0:      	ldr	x9, [sp, #0x98]
    c8c4:      	cmp	x8, x9
    c8c8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c8cc:      	add	x2, x24, #0x18
    c8d0:      	mov	w8, #0x4                // =4
    c8d4:      	mov	x0, x22
    c8d8:      	mov	w1, #0x8                // =8
    c8dc:      	blr	x8
    c8e0:      	ldr	x24, [sp, #0x98]
    c8e4:      	ldr	x21, [sp, #0x48]
    c8e8:      	add	x2, x24, #0x20
    c8ec:      	stp	x2, x24, [sp, #0x50]
    c8f0:      	ldr	x8, [sp, #0x30]
    c8f4:      	cmp	x21, x8
    c8f8:      	b.ne	0xc908 <generic_rawtp_path+0x3808>
    c8fc:      	ldr	x8, [sp, #0x38]
    c900:      	cmp	x2, x8
    c904:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    c908:      	mov	w8, #0x4                // =4
    c90c:      	add	x0, sp, #0x70
    c910:      	mov	w1, #0x8                // =8
    c914:      	blr	x8
    c918:      	ldr	x8, [sp, #0x70]
    c91c:      	cmp	x21, x8
    c920:      	b.eq	0xca10 <generic_rawtp_path+0x3910>
    c924:      	add	x23, x21, #0x18
    c928:      	mov	w8, #0x4                // =4
    c92c:      	add	x9, sp, #0x98
    c930:      	add	x0, sp, #0x98
    c934:      	mov	w1, #0x8                // =8
    c938:      	mov	x2, x23
    c93c:      	blr	x8
    c940:      	ldr	x8, [sp, #0x98]
    c944:      	cmp	x8, x21
    c948:      	b.eq	0xca10 <generic_rawtp_path+0x3910>
    c94c:      	mov	w8, #0x4                // =4
    c950:      	add	x9, sp, #0x78
    c954:      	add	x0, sp, #0x78
    c958:      	mov	w1, #0x8                // =8
    c95c:      	mov	x2, x23
    c960:      	blr	x8
    c964:      	add	x2, x21, #0x20
    c968:      	mov	w8, #0x4                // =4
    c96c:      	mov	w9, #0x10               // =16
    c970:      	add	x10, sp, #0x80
    c974:      	add	x0, sp, #0x80
    c978:      	mov	w1, #0x10               // =16
    c97c:      	blr	x8
    c980:      	ldr	w21, [sp, #0x84]
    c984:      	ldr	x8, [sp, #0x40]
    c988:      	ldr	x10, [sp, #0x60]
    c98c:      	sub	x12, x10, x8
    c990:      	ldr	w23, [sp, #0x68]
    c994:      	subs	w10, w21, w23
    c998:      	ldr	x9, [sp, #0x88]
    c99c:      	csel	w10, wzr, w10, lo
    c9a0:      	cmp	w23, w21
    c9a4:      	csel	w11, w23, w21, lo
    c9a8:      	cinc	w13, w11, hi
    c9ac:      	sub	w14, w23, w13
    c9b0:      	subs	x12, x12, x13
    c9b4:      	str	w14, [sp, #0x68]
    c9b8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    c9bc:      	cmp	x12, #0xfff
    c9c0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    c9c4:      	cmp	w23, w21
    c9c8:      	b.ls	0xc9d4 <generic_rawtp_path+0x38d4>
    c9cc:      	mov	w13, #0x2f              // =47
    c9d0:      	strb	w13, [x8, x12]
    c9d4:      	add	x19, x8, x12
    c9d8:      	cmp	w23, w21
    c9dc:      	add	x2, x9, x10
    c9e0:      	and	w1, w11, #0xff
    c9e4:      	mov	w8, #0x4                // =4
    c9e8:      	cinc	x0, x19, hi
    c9ec:      	blr	x8
    c9f0:      	cmp	w23, w21
    c9f4:      	str	x19, [sp, #0x60]
    c9f8:      	add	x19, sp, #0x70
    c9fc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ca00:      	ldr	x21, [sp, #0x78]
    ca04:      	ldp	x2, x24, [sp, #0x50]
    ca08:      	str	x21, [sp, #0x48]
    ca0c:      	b	0xca5c <generic_rawtp_path+0x395c>
    ca10:      	add	x2, x24, #0x10
    ca14:      	mov	w8, #0x4                // =4
    ca18:      	add	x9, sp, #0x98
    ca1c:      	add	x0, sp, #0x98
    ca20:      	mov	w1, #0x8                // =8
    ca24:      	blr	x8
    ca28:      	ldr	x8, [sp, #0x58]
    ca2c:      	ldr	x9, [sp, #0x98]
    ca30:      	cmp	x8, x9
    ca34:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ca38:      	add	x2, x24, #0x18
    ca3c:      	mov	w8, #0x4                // =4
    ca40:      	mov	x0, x22
    ca44:      	mov	w1, #0x8                // =8
    ca48:      	blr	x8
    ca4c:      	ldr	x24, [sp, #0x98]
    ca50:      	ldr	x21, [sp, #0x48]
    ca54:      	add	x2, x24, #0x20
    ca58:      	stp	x2, x24, [sp, #0x50]
    ca5c:      	ldr	x8, [sp, #0x30]
    ca60:      	cmp	x21, x8
    ca64:      	b.ne	0xca74 <generic_rawtp_path+0x3974>
    ca68:      	ldr	x8, [sp, #0x38]
    ca6c:      	cmp	x2, x8
    ca70:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ca74:      	mov	w8, #0x4                // =4
    ca78:      	add	x0, sp, #0x70
    ca7c:      	mov	w1, #0x8                // =8
    ca80:      	blr	x8
    ca84:      	ldr	x8, [sp, #0x70]
    ca88:      	cmp	x21, x8
    ca8c:      	b.eq	0xcb7c <generic_rawtp_path+0x3a7c>
    ca90:      	add	x23, x21, #0x18
    ca94:      	mov	w8, #0x4                // =4
    ca98:      	add	x9, sp, #0x98
    ca9c:      	add	x0, sp, #0x98
    caa0:      	mov	w1, #0x8                // =8
    caa4:      	mov	x2, x23
    caa8:      	blr	x8
    caac:      	ldr	x8, [sp, #0x98]
    cab0:      	cmp	x8, x21
    cab4:      	b.eq	0xcb7c <generic_rawtp_path+0x3a7c>
    cab8:      	mov	w8, #0x4                // =4
    cabc:      	add	x9, sp, #0x78
    cac0:      	add	x0, sp, #0x78
    cac4:      	mov	w1, #0x8                // =8
    cac8:      	mov	x2, x23
    cacc:      	blr	x8
    cad0:      	add	x2, x21, #0x20
    cad4:      	mov	w8, #0x4                // =4
    cad8:      	mov	w9, #0x10               // =16
    cadc:      	add	x10, sp, #0x80
    cae0:      	add	x0, sp, #0x80
    cae4:      	mov	w1, #0x10               // =16
    cae8:      	blr	x8
    caec:      	ldr	w21, [sp, #0x84]
    caf0:      	ldr	x8, [sp, #0x40]
    caf4:      	ldr	x10, [sp, #0x60]
    caf8:      	sub	x12, x10, x8
    cafc:      	ldr	w23, [sp, #0x68]
    cb00:      	subs	w10, w21, w23
    cb04:      	ldr	x9, [sp, #0x88]
    cb08:      	csel	w10, wzr, w10, lo
    cb0c:      	cmp	w23, w21
    cb10:      	csel	w11, w23, w21, lo
    cb14:      	cinc	w13, w11, hi
    cb18:      	sub	w14, w23, w13
    cb1c:      	subs	x12, x12, x13
    cb20:      	str	w14, [sp, #0x68]
    cb24:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    cb28:      	cmp	x12, #0xfff
    cb2c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    cb30:      	cmp	w23, w21
    cb34:      	b.ls	0xcb40 <generic_rawtp_path+0x3a40>
    cb38:      	mov	w13, #0x2f              // =47
    cb3c:      	strb	w13, [x8, x12]
    cb40:      	add	x19, x8, x12
    cb44:      	cmp	w23, w21
    cb48:      	add	x2, x9, x10
    cb4c:      	and	w1, w11, #0xff
    cb50:      	mov	w8, #0x4                // =4
    cb54:      	cinc	x0, x19, hi
    cb58:      	blr	x8
    cb5c:      	cmp	w23, w21
    cb60:      	str	x19, [sp, #0x60]
    cb64:      	add	x19, sp, #0x70
    cb68:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    cb6c:      	ldr	x21, [sp, #0x78]
    cb70:      	ldp	x2, x24, [sp, #0x50]
    cb74:      	str	x21, [sp, #0x48]
    cb78:      	b	0xcbc8 <generic_rawtp_path+0x3ac8>
    cb7c:      	add	x2, x24, #0x10
    cb80:      	mov	w8, #0x4                // =4
    cb84:      	add	x9, sp, #0x98
    cb88:      	add	x0, sp, #0x98
    cb8c:      	mov	w1, #0x8                // =8
    cb90:      	blr	x8
    cb94:      	ldr	x8, [sp, #0x58]
    cb98:      	ldr	x9, [sp, #0x98]
    cb9c:      	cmp	x8, x9
    cba0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    cba4:      	add	x2, x24, #0x18
    cba8:      	mov	w8, #0x4                // =4
    cbac:      	mov	x0, x22
    cbb0:      	mov	w1, #0x8                // =8
    cbb4:      	blr	x8
    cbb8:      	ldr	x24, [sp, #0x98]
    cbbc:      	ldr	x21, [sp, #0x48]
    cbc0:      	add	x2, x24, #0x20
    cbc4:      	stp	x2, x24, [sp, #0x50]
    cbc8:      	ldr	x8, [sp, #0x30]
    cbcc:      	cmp	x21, x8
    cbd0:      	b.ne	0xcbe0 <generic_rawtp_path+0x3ae0>
    cbd4:      	ldr	x8, [sp, #0x38]
    cbd8:      	cmp	x2, x8
    cbdc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    cbe0:      	mov	w8, #0x4                // =4
    cbe4:      	add	x0, sp, #0x70
    cbe8:      	mov	w1, #0x8                // =8
    cbec:      	blr	x8
    cbf0:      	ldr	x8, [sp, #0x70]
    cbf4:      	cmp	x21, x8
    cbf8:      	b.eq	0xcce8 <generic_rawtp_path+0x3be8>
    cbfc:      	add	x23, x21, #0x18
    cc00:      	mov	w8, #0x4                // =4
    cc04:      	add	x9, sp, #0x98
    cc08:      	add	x0, sp, #0x98
    cc0c:      	mov	w1, #0x8                // =8
    cc10:      	mov	x2, x23
    cc14:      	blr	x8
    cc18:      	ldr	x8, [sp, #0x98]
    cc1c:      	cmp	x8, x21
    cc20:      	b.eq	0xcce8 <generic_rawtp_path+0x3be8>
    cc24:      	mov	w8, #0x4                // =4
    cc28:      	add	x9, sp, #0x78
    cc2c:      	add	x0, sp, #0x78
    cc30:      	mov	w1, #0x8                // =8
    cc34:      	mov	x2, x23
    cc38:      	blr	x8
    cc3c:      	add	x2, x21, #0x20
    cc40:      	mov	w8, #0x4                // =4
    cc44:      	mov	w9, #0x10               // =16
    cc48:      	add	x10, sp, #0x80
    cc4c:      	add	x0, sp, #0x80
    cc50:      	mov	w1, #0x10               // =16
    cc54:      	blr	x8
    cc58:      	ldr	w21, [sp, #0x84]
    cc5c:      	ldr	x8, [sp, #0x40]
    cc60:      	ldr	x10, [sp, #0x60]
    cc64:      	sub	x12, x10, x8
    cc68:      	ldr	w23, [sp, #0x68]
    cc6c:      	subs	w10, w21, w23
    cc70:      	ldr	x9, [sp, #0x88]
    cc74:      	csel	w10, wzr, w10, lo
    cc78:      	cmp	w23, w21
    cc7c:      	csel	w11, w23, w21, lo
    cc80:      	cinc	w13, w11, hi
    cc84:      	sub	w14, w23, w13
    cc88:      	subs	x12, x12, x13
    cc8c:      	str	w14, [sp, #0x68]
    cc90:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    cc94:      	cmp	x12, #0xfff
    cc98:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    cc9c:      	cmp	w23, w21
    cca0:      	b.ls	0xccac <generic_rawtp_path+0x3bac>
    cca4:      	mov	w13, #0x2f              // =47
    cca8:      	strb	w13, [x8, x12]
    ccac:      	add	x19, x8, x12
    ccb0:      	cmp	w23, w21
    ccb4:      	add	x2, x9, x10
    ccb8:      	and	w1, w11, #0xff
    ccbc:      	mov	w8, #0x4                // =4
    ccc0:      	cinc	x0, x19, hi
    ccc4:      	blr	x8
    ccc8:      	cmp	w23, w21
    cccc:      	str	x19, [sp, #0x60]
    ccd0:      	add	x19, sp, #0x70
    ccd4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ccd8:      	ldr	x21, [sp, #0x78]
    ccdc:      	ldp	x2, x24, [sp, #0x50]
    cce0:      	str	x21, [sp, #0x48]
    cce4:      	b	0xcd34 <generic_rawtp_path+0x3c34>
    cce8:      	add	x2, x24, #0x10
    ccec:      	mov	w8, #0x4                // =4
    ccf0:      	add	x9, sp, #0x98
    ccf4:      	add	x0, sp, #0x98
    ccf8:      	mov	w1, #0x8                // =8
    ccfc:      	blr	x8
    cd00:      	ldr	x8, [sp, #0x58]
    cd04:      	ldr	x9, [sp, #0x98]
    cd08:      	cmp	x8, x9
    cd0c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    cd10:      	add	x2, x24, #0x18
    cd14:      	mov	w8, #0x4                // =4
    cd18:      	mov	x0, x22
    cd1c:      	mov	w1, #0x8                // =8
    cd20:      	blr	x8
    cd24:      	ldr	x24, [sp, #0x98]
    cd28:      	ldr	x21, [sp, #0x48]
    cd2c:      	add	x2, x24, #0x20
    cd30:      	stp	x2, x24, [sp, #0x50]
    cd34:      	ldr	x8, [sp, #0x30]
    cd38:      	cmp	x21, x8
    cd3c:      	b.ne	0xcd4c <generic_rawtp_path+0x3c4c>
    cd40:      	ldr	x8, [sp, #0x38]
    cd44:      	cmp	x2, x8
    cd48:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    cd4c:      	mov	w8, #0x4                // =4
    cd50:      	add	x0, sp, #0x70
    cd54:      	mov	w1, #0x8                // =8
    cd58:      	blr	x8
    cd5c:      	ldr	x8, [sp, #0x70]
    cd60:      	cmp	x21, x8
    cd64:      	b.eq	0xce54 <generic_rawtp_path+0x3d54>
    cd68:      	add	x23, x21, #0x18
    cd6c:      	mov	w8, #0x4                // =4
    cd70:      	add	x9, sp, #0x98
    cd74:      	add	x0, sp, #0x98
    cd78:      	mov	w1, #0x8                // =8
    cd7c:      	mov	x2, x23
    cd80:      	blr	x8
    cd84:      	ldr	x8, [sp, #0x98]
    cd88:      	cmp	x8, x21
    cd8c:      	b.eq	0xce54 <generic_rawtp_path+0x3d54>
    cd90:      	mov	w8, #0x4                // =4
    cd94:      	add	x9, sp, #0x78
    cd98:      	add	x0, sp, #0x78
    cd9c:      	mov	w1, #0x8                // =8
    cda0:      	mov	x2, x23
    cda4:      	blr	x8
    cda8:      	add	x2, x21, #0x20
    cdac:      	mov	w8, #0x4                // =4
    cdb0:      	mov	w9, #0x10               // =16
    cdb4:      	add	x10, sp, #0x80
    cdb8:      	add	x0, sp, #0x80
    cdbc:      	mov	w1, #0x10               // =16
    cdc0:      	blr	x8
    cdc4:      	ldr	w21, [sp, #0x84]
    cdc8:      	ldr	x8, [sp, #0x40]
    cdcc:      	ldr	x10, [sp, #0x60]
    cdd0:      	sub	x12, x10, x8
    cdd4:      	ldr	w23, [sp, #0x68]
    cdd8:      	subs	w10, w21, w23
    cddc:      	ldr	x9, [sp, #0x88]
    cde0:      	csel	w10, wzr, w10, lo
    cde4:      	cmp	w23, w21
    cde8:      	csel	w11, w23, w21, lo
    cdec:      	cinc	w13, w11, hi
    cdf0:      	sub	w14, w23, w13
    cdf4:      	subs	x12, x12, x13
    cdf8:      	str	w14, [sp, #0x68]
    cdfc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ce00:      	cmp	x12, #0xfff
    ce04:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ce08:      	cmp	w23, w21
    ce0c:      	b.ls	0xce18 <generic_rawtp_path+0x3d18>
    ce10:      	mov	w13, #0x2f              // =47
    ce14:      	strb	w13, [x8, x12]
    ce18:      	add	x19, x8, x12
    ce1c:      	cmp	w23, w21
    ce20:      	add	x2, x9, x10
    ce24:      	and	w1, w11, #0xff
    ce28:      	mov	w8, #0x4                // =4
    ce2c:      	cinc	x0, x19, hi
    ce30:      	blr	x8
    ce34:      	cmp	w23, w21
    ce38:      	str	x19, [sp, #0x60]
    ce3c:      	add	x19, sp, #0x70
    ce40:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ce44:      	ldr	x21, [sp, #0x78]
    ce48:      	ldp	x2, x24, [sp, #0x50]
    ce4c:      	str	x21, [sp, #0x48]
    ce50:      	b	0xcea0 <generic_rawtp_path+0x3da0>
    ce54:      	add	x2, x24, #0x10
    ce58:      	mov	w8, #0x4                // =4
    ce5c:      	add	x9, sp, #0x98
    ce60:      	add	x0, sp, #0x98
    ce64:      	mov	w1, #0x8                // =8
    ce68:      	blr	x8
    ce6c:      	ldr	x8, [sp, #0x58]
    ce70:      	ldr	x9, [sp, #0x98]
    ce74:      	cmp	x8, x9
    ce78:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ce7c:      	add	x2, x24, #0x18
    ce80:      	mov	w8, #0x4                // =4
    ce84:      	mov	x0, x22
    ce88:      	mov	w1, #0x8                // =8
    ce8c:      	blr	x8
    ce90:      	ldr	x24, [sp, #0x98]
    ce94:      	ldr	x21, [sp, #0x48]
    ce98:      	add	x2, x24, #0x20
    ce9c:      	stp	x2, x24, [sp, #0x50]
    cea0:      	ldr	x8, [sp, #0x30]
    cea4:      	cmp	x21, x8
    cea8:      	b.ne	0xceb8 <generic_rawtp_path+0x3db8>
    ceac:      	ldr	x8, [sp, #0x38]
    ceb0:      	cmp	x2, x8
    ceb4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ceb8:      	mov	w8, #0x4                // =4
    cebc:      	add	x0, sp, #0x70
    cec0:      	mov	w1, #0x8                // =8
    cec4:      	blr	x8
    cec8:      	ldr	x8, [sp, #0x70]
    cecc:      	cmp	x21, x8
    ced0:      	b.eq	0xcfc0 <generic_rawtp_path+0x3ec0>
    ced4:      	add	x23, x21, #0x18
    ced8:      	mov	w8, #0x4                // =4
    cedc:      	add	x9, sp, #0x98
    cee0:      	add	x0, sp, #0x98
    cee4:      	mov	w1, #0x8                // =8
    cee8:      	mov	x2, x23
    ceec:      	blr	x8
    cef0:      	ldr	x8, [sp, #0x98]
    cef4:      	cmp	x8, x21
    cef8:      	b.eq	0xcfc0 <generic_rawtp_path+0x3ec0>
    cefc:      	mov	w8, #0x4                // =4
    cf00:      	add	x9, sp, #0x78
    cf04:      	add	x0, sp, #0x78
    cf08:      	mov	w1, #0x8                // =8
    cf0c:      	mov	x2, x23
    cf10:      	blr	x8
    cf14:      	add	x2, x21, #0x20
    cf18:      	mov	w8, #0x4                // =4
    cf1c:      	mov	w9, #0x10               // =16
    cf20:      	add	x10, sp, #0x80
    cf24:      	add	x0, sp, #0x80
    cf28:      	mov	w1, #0x10               // =16
    cf2c:      	blr	x8
    cf30:      	ldr	w21, [sp, #0x84]
    cf34:      	ldr	x8, [sp, #0x40]
    cf38:      	ldr	x10, [sp, #0x60]
    cf3c:      	sub	x12, x10, x8
    cf40:      	ldr	w23, [sp, #0x68]
    cf44:      	subs	w10, w21, w23
    cf48:      	ldr	x9, [sp, #0x88]
    cf4c:      	csel	w10, wzr, w10, lo
    cf50:      	cmp	w23, w21
    cf54:      	csel	w11, w23, w21, lo
    cf58:      	cinc	w13, w11, hi
    cf5c:      	sub	w14, w23, w13
    cf60:      	subs	x12, x12, x13
    cf64:      	str	w14, [sp, #0x68]
    cf68:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    cf6c:      	cmp	x12, #0xfff
    cf70:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    cf74:      	cmp	w23, w21
    cf78:      	b.ls	0xcf84 <generic_rawtp_path+0x3e84>
    cf7c:      	mov	w13, #0x2f              // =47
    cf80:      	strb	w13, [x8, x12]
    cf84:      	add	x19, x8, x12
    cf88:      	cmp	w23, w21
    cf8c:      	add	x2, x9, x10
    cf90:      	and	w1, w11, #0xff
    cf94:      	mov	w8, #0x4                // =4
    cf98:      	cinc	x0, x19, hi
    cf9c:      	blr	x8
    cfa0:      	cmp	w23, w21
    cfa4:      	str	x19, [sp, #0x60]
    cfa8:      	add	x19, sp, #0x70
    cfac:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    cfb0:      	ldr	x21, [sp, #0x78]
    cfb4:      	ldp	x2, x24, [sp, #0x50]
    cfb8:      	str	x21, [sp, #0x48]
    cfbc:      	b	0xd00c <generic_rawtp_path+0x3f0c>
    cfc0:      	add	x2, x24, #0x10
    cfc4:      	mov	w8, #0x4                // =4
    cfc8:      	add	x9, sp, #0x98
    cfcc:      	add	x0, sp, #0x98
    cfd0:      	mov	w1, #0x8                // =8
    cfd4:      	blr	x8
    cfd8:      	ldr	x8, [sp, #0x58]
    cfdc:      	ldr	x9, [sp, #0x98]
    cfe0:      	cmp	x8, x9
    cfe4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    cfe8:      	add	x2, x24, #0x18
    cfec:      	mov	w8, #0x4                // =4
    cff0:      	mov	x0, x22
    cff4:      	mov	w1, #0x8                // =8
    cff8:      	blr	x8
    cffc:      	ldr	x24, [sp, #0x98]
    d000:      	ldr	x21, [sp, #0x48]
    d004:      	add	x2, x24, #0x20
    d008:      	stp	x2, x24, [sp, #0x50]
    d00c:      	ldr	x8, [sp, #0x30]
    d010:      	cmp	x21, x8
    d014:      	b.ne	0xd024 <generic_rawtp_path+0x3f24>
    d018:      	ldr	x8, [sp, #0x38]
    d01c:      	cmp	x2, x8
    d020:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d024:      	mov	w8, #0x4                // =4
    d028:      	add	x0, sp, #0x70
    d02c:      	mov	w1, #0x8                // =8
    d030:      	blr	x8
    d034:      	ldr	x8, [sp, #0x70]
    d038:      	cmp	x21, x8
    d03c:      	b.eq	0xd12c <generic_rawtp_path+0x402c>
    d040:      	add	x23, x21, #0x18
    d044:      	mov	w8, #0x4                // =4
    d048:      	add	x9, sp, #0x98
    d04c:      	add	x0, sp, #0x98
    d050:      	mov	w1, #0x8                // =8
    d054:      	mov	x2, x23
    d058:      	blr	x8
    d05c:      	ldr	x8, [sp, #0x98]
    d060:      	cmp	x8, x21
    d064:      	b.eq	0xd12c <generic_rawtp_path+0x402c>
    d068:      	mov	w8, #0x4                // =4
    d06c:      	add	x9, sp, #0x78
    d070:      	add	x0, sp, #0x78
    d074:      	mov	w1, #0x8                // =8
    d078:      	mov	x2, x23
    d07c:      	blr	x8
    d080:      	add	x2, x21, #0x20
    d084:      	mov	w8, #0x4                // =4
    d088:      	mov	w9, #0x10               // =16
    d08c:      	add	x10, sp, #0x80
    d090:      	add	x0, sp, #0x80
    d094:      	mov	w1, #0x10               // =16
    d098:      	blr	x8
    d09c:      	ldr	w21, [sp, #0x84]
    d0a0:      	ldr	x8, [sp, #0x40]
    d0a4:      	ldr	x10, [sp, #0x60]
    d0a8:      	sub	x12, x10, x8
    d0ac:      	ldr	w23, [sp, #0x68]
    d0b0:      	subs	w10, w21, w23
    d0b4:      	ldr	x9, [sp, #0x88]
    d0b8:      	csel	w10, wzr, w10, lo
    d0bc:      	cmp	w23, w21
    d0c0:      	csel	w11, w23, w21, lo
    d0c4:      	cinc	w13, w11, hi
    d0c8:      	sub	w14, w23, w13
    d0cc:      	subs	x12, x12, x13
    d0d0:      	str	w14, [sp, #0x68]
    d0d4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d0d8:      	cmp	x12, #0xfff
    d0dc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d0e0:      	cmp	w23, w21
    d0e4:      	b.ls	0xd0f0 <generic_rawtp_path+0x3ff0>
    d0e8:      	mov	w13, #0x2f              // =47
    d0ec:      	strb	w13, [x8, x12]
    d0f0:      	add	x19, x8, x12
    d0f4:      	cmp	w23, w21
    d0f8:      	add	x2, x9, x10
    d0fc:      	and	w1, w11, #0xff
    d100:      	mov	w8, #0x4                // =4
    d104:      	cinc	x0, x19, hi
    d108:      	blr	x8
    d10c:      	cmp	w23, w21
    d110:      	str	x19, [sp, #0x60]
    d114:      	add	x19, sp, #0x70
    d118:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d11c:      	ldr	x21, [sp, #0x78]
    d120:      	ldp	x2, x24, [sp, #0x50]
    d124:      	str	x21, [sp, #0x48]
    d128:      	b	0xd178 <generic_rawtp_path+0x4078>
    d12c:      	add	x2, x24, #0x10
    d130:      	mov	w8, #0x4                // =4
    d134:      	add	x9, sp, #0x98
    d138:      	add	x0, sp, #0x98
    d13c:      	mov	w1, #0x8                // =8
    d140:      	blr	x8
    d144:      	ldr	x8, [sp, #0x58]
    d148:      	ldr	x9, [sp, #0x98]
    d14c:      	cmp	x8, x9
    d150:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d154:      	add	x2, x24, #0x18
    d158:      	mov	w8, #0x4                // =4
    d15c:      	mov	x0, x22
    d160:      	mov	w1, #0x8                // =8
    d164:      	blr	x8
    d168:      	ldr	x24, [sp, #0x98]
    d16c:      	ldr	x21, [sp, #0x48]
    d170:      	add	x2, x24, #0x20
    d174:      	stp	x2, x24, [sp, #0x50]
    d178:      	ldr	x8, [sp, #0x30]
    d17c:      	cmp	x21, x8
    d180:      	b.ne	0xd190 <generic_rawtp_path+0x4090>
    d184:      	ldr	x8, [sp, #0x38]
    d188:      	cmp	x2, x8
    d18c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d190:      	mov	w8, #0x4                // =4
    d194:      	add	x0, sp, #0x70
    d198:      	mov	w1, #0x8                // =8
    d19c:      	blr	x8
    d1a0:      	ldr	x8, [sp, #0x70]
    d1a4:      	cmp	x21, x8
    d1a8:      	b.eq	0xd298 <generic_rawtp_path+0x4198>
    d1ac:      	add	x23, x21, #0x18
    d1b0:      	mov	w8, #0x4                // =4
    d1b4:      	add	x9, sp, #0x98
    d1b8:      	add	x0, sp, #0x98
    d1bc:      	mov	w1, #0x8                // =8
    d1c0:      	mov	x2, x23
    d1c4:      	blr	x8
    d1c8:      	ldr	x8, [sp, #0x98]
    d1cc:      	cmp	x8, x21
    d1d0:      	b.eq	0xd298 <generic_rawtp_path+0x4198>
    d1d4:      	mov	w8, #0x4                // =4
    d1d8:      	add	x9, sp, #0x78
    d1dc:      	add	x0, sp, #0x78
    d1e0:      	mov	w1, #0x8                // =8
    d1e4:      	mov	x2, x23
    d1e8:      	blr	x8
    d1ec:      	add	x2, x21, #0x20
    d1f0:      	mov	w8, #0x4                // =4
    d1f4:      	mov	w9, #0x10               // =16
    d1f8:      	add	x10, sp, #0x80
    d1fc:      	add	x0, sp, #0x80
    d200:      	mov	w1, #0x10               // =16
    d204:      	blr	x8
    d208:      	ldr	w21, [sp, #0x84]
    d20c:      	ldr	x8, [sp, #0x40]
    d210:      	ldr	x10, [sp, #0x60]
    d214:      	sub	x12, x10, x8
    d218:      	ldr	w23, [sp, #0x68]
    d21c:      	subs	w10, w21, w23
    d220:      	ldr	x9, [sp, #0x88]
    d224:      	csel	w10, wzr, w10, lo
    d228:      	cmp	w23, w21
    d22c:      	csel	w11, w23, w21, lo
    d230:      	cinc	w13, w11, hi
    d234:      	sub	w14, w23, w13
    d238:      	subs	x12, x12, x13
    d23c:      	str	w14, [sp, #0x68]
    d240:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d244:      	cmp	x12, #0xfff
    d248:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d24c:      	cmp	w23, w21
    d250:      	b.ls	0xd25c <generic_rawtp_path+0x415c>
    d254:      	mov	w13, #0x2f              // =47
    d258:      	strb	w13, [x8, x12]
    d25c:      	add	x19, x8, x12
    d260:      	cmp	w23, w21
    d264:      	add	x2, x9, x10
    d268:      	and	w1, w11, #0xff
    d26c:      	mov	w8, #0x4                // =4
    d270:      	cinc	x0, x19, hi
    d274:      	blr	x8
    d278:      	cmp	w23, w21
    d27c:      	str	x19, [sp, #0x60]
    d280:      	add	x19, sp, #0x70
    d284:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d288:      	ldr	x21, [sp, #0x78]
    d28c:      	ldp	x2, x24, [sp, #0x50]
    d290:      	str	x21, [sp, #0x48]
    d294:      	b	0xd2e4 <generic_rawtp_path+0x41e4>
    d298:      	add	x2, x24, #0x10
    d29c:      	mov	w8, #0x4                // =4
    d2a0:      	add	x9, sp, #0x98
    d2a4:      	add	x0, sp, #0x98
    d2a8:      	mov	w1, #0x8                // =8
    d2ac:      	blr	x8
    d2b0:      	ldr	x8, [sp, #0x58]
    d2b4:      	ldr	x9, [sp, #0x98]
    d2b8:      	cmp	x8, x9
    d2bc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d2c0:      	add	x2, x24, #0x18
    d2c4:      	mov	w8, #0x4                // =4
    d2c8:      	mov	x0, x22
    d2cc:      	mov	w1, #0x8                // =8
    d2d0:      	blr	x8
    d2d4:      	ldr	x24, [sp, #0x98]
    d2d8:      	ldr	x21, [sp, #0x48]
    d2dc:      	add	x2, x24, #0x20
    d2e0:      	stp	x2, x24, [sp, #0x50]
    d2e4:      	ldr	x8, [sp, #0x30]
    d2e8:      	cmp	x21, x8
    d2ec:      	b.ne	0xd2fc <generic_rawtp_path+0x41fc>
    d2f0:      	ldr	x8, [sp, #0x38]
    d2f4:      	cmp	x2, x8
    d2f8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d2fc:      	mov	w8, #0x4                // =4
    d300:      	add	x0, sp, #0x70
    d304:      	mov	w1, #0x8                // =8
    d308:      	blr	x8
    d30c:      	ldr	x8, [sp, #0x70]
    d310:      	cmp	x21, x8
    d314:      	b.eq	0xd404 <generic_rawtp_path+0x4304>
    d318:      	add	x23, x21, #0x18
    d31c:      	mov	w8, #0x4                // =4
    d320:      	add	x9, sp, #0x98
    d324:      	add	x0, sp, #0x98
    d328:      	mov	w1, #0x8                // =8
    d32c:      	mov	x2, x23
    d330:      	blr	x8
    d334:      	ldr	x8, [sp, #0x98]
    d338:      	cmp	x8, x21
    d33c:      	b.eq	0xd404 <generic_rawtp_path+0x4304>
    d340:      	mov	w8, #0x4                // =4
    d344:      	add	x9, sp, #0x78
    d348:      	add	x0, sp, #0x78
    d34c:      	mov	w1, #0x8                // =8
    d350:      	mov	x2, x23
    d354:      	blr	x8
    d358:      	add	x2, x21, #0x20
    d35c:      	mov	w8, #0x4                // =4
    d360:      	mov	w9, #0x10               // =16
    d364:      	add	x10, sp, #0x80
    d368:      	add	x0, sp, #0x80
    d36c:      	mov	w1, #0x10               // =16
    d370:      	blr	x8
    d374:      	ldr	w21, [sp, #0x84]
    d378:      	ldr	x8, [sp, #0x40]
    d37c:      	ldr	x10, [sp, #0x60]
    d380:      	sub	x12, x10, x8
    d384:      	ldr	w23, [sp, #0x68]
    d388:      	subs	w10, w21, w23
    d38c:      	ldr	x9, [sp, #0x88]
    d390:      	csel	w10, wzr, w10, lo
    d394:      	cmp	w23, w21
    d398:      	csel	w11, w23, w21, lo
    d39c:      	cinc	w13, w11, hi
    d3a0:      	sub	w14, w23, w13
    d3a4:      	subs	x12, x12, x13
    d3a8:      	str	w14, [sp, #0x68]
    d3ac:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d3b0:      	cmp	x12, #0xfff
    d3b4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d3b8:      	cmp	w23, w21
    d3bc:      	b.ls	0xd3c8 <generic_rawtp_path+0x42c8>
    d3c0:      	mov	w13, #0x2f              // =47
    d3c4:      	strb	w13, [x8, x12]
    d3c8:      	add	x19, x8, x12
    d3cc:      	cmp	w23, w21
    d3d0:      	add	x2, x9, x10
    d3d4:      	and	w1, w11, #0xff
    d3d8:      	mov	w8, #0x4                // =4
    d3dc:      	cinc	x0, x19, hi
    d3e0:      	blr	x8
    d3e4:      	cmp	w23, w21
    d3e8:      	str	x19, [sp, #0x60]
    d3ec:      	add	x19, sp, #0x70
    d3f0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d3f4:      	ldr	x21, [sp, #0x78]
    d3f8:      	ldp	x2, x24, [sp, #0x50]
    d3fc:      	str	x21, [sp, #0x48]
    d400:      	b	0xd450 <generic_rawtp_path+0x4350>
    d404:      	add	x2, x24, #0x10
    d408:      	mov	w8, #0x4                // =4
    d40c:      	add	x9, sp, #0x98
    d410:      	add	x0, sp, #0x98
    d414:      	mov	w1, #0x8                // =8
    d418:      	blr	x8
    d41c:      	ldr	x8, [sp, #0x58]
    d420:      	ldr	x9, [sp, #0x98]
    d424:      	cmp	x8, x9
    d428:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d42c:      	add	x2, x24, #0x18
    d430:      	mov	w8, #0x4                // =4
    d434:      	mov	x0, x22
    d438:      	mov	w1, #0x8                // =8
    d43c:      	blr	x8
    d440:      	ldr	x24, [sp, #0x98]
    d444:      	ldr	x21, [sp, #0x48]
    d448:      	add	x2, x24, #0x20
    d44c:      	stp	x2, x24, [sp, #0x50]
    d450:      	ldr	x8, [sp, #0x30]
    d454:      	cmp	x21, x8
    d458:      	b.ne	0xd468 <generic_rawtp_path+0x4368>
    d45c:      	ldr	x8, [sp, #0x38]
    d460:      	cmp	x2, x8
    d464:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d468:      	mov	w8, #0x4                // =4
    d46c:      	add	x0, sp, #0x70
    d470:      	mov	w1, #0x8                // =8
    d474:      	blr	x8
    d478:      	ldr	x8, [sp, #0x70]
    d47c:      	cmp	x21, x8
    d480:      	b.eq	0xd570 <generic_rawtp_path+0x4470>
    d484:      	add	x23, x21, #0x18
    d488:      	mov	w8, #0x4                // =4
    d48c:      	add	x9, sp, #0x98
    d490:      	add	x0, sp, #0x98
    d494:      	mov	w1, #0x8                // =8
    d498:      	mov	x2, x23
    d49c:      	blr	x8
    d4a0:      	ldr	x8, [sp, #0x98]
    d4a4:      	cmp	x8, x21
    d4a8:      	b.eq	0xd570 <generic_rawtp_path+0x4470>
    d4ac:      	mov	w8, #0x4                // =4
    d4b0:      	add	x9, sp, #0x78
    d4b4:      	add	x0, sp, #0x78
    d4b8:      	mov	w1, #0x8                // =8
    d4bc:      	mov	x2, x23
    d4c0:      	blr	x8
    d4c4:      	add	x2, x21, #0x20
    d4c8:      	mov	w8, #0x4                // =4
    d4cc:      	mov	w9, #0x10               // =16
    d4d0:      	add	x10, sp, #0x80
    d4d4:      	add	x0, sp, #0x80
    d4d8:      	mov	w1, #0x10               // =16
    d4dc:      	blr	x8
    d4e0:      	ldr	w21, [sp, #0x84]
    d4e4:      	ldr	x8, [sp, #0x40]
    d4e8:      	ldr	x10, [sp, #0x60]
    d4ec:      	sub	x12, x10, x8
    d4f0:      	ldr	w23, [sp, #0x68]
    d4f4:      	subs	w10, w21, w23
    d4f8:      	ldr	x9, [sp, #0x88]
    d4fc:      	csel	w10, wzr, w10, lo
    d500:      	cmp	w23, w21
    d504:      	csel	w11, w23, w21, lo
    d508:      	cinc	w13, w11, hi
    d50c:      	sub	w14, w23, w13
    d510:      	subs	x12, x12, x13
    d514:      	str	w14, [sp, #0x68]
    d518:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d51c:      	cmp	x12, #0xfff
    d520:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d524:      	cmp	w23, w21
    d528:      	b.ls	0xd534 <generic_rawtp_path+0x4434>
    d52c:      	mov	w13, #0x2f              // =47
    d530:      	strb	w13, [x8, x12]
    d534:      	add	x19, x8, x12
    d538:      	cmp	w23, w21
    d53c:      	add	x2, x9, x10
    d540:      	and	w1, w11, #0xff
    d544:      	mov	w8, #0x4                // =4
    d548:      	cinc	x0, x19, hi
    d54c:      	blr	x8
    d550:      	cmp	w23, w21
    d554:      	str	x19, [sp, #0x60]
    d558:      	add	x19, sp, #0x70
    d55c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d560:      	ldr	x21, [sp, #0x78]
    d564:      	ldp	x2, x24, [sp, #0x50]
    d568:      	str	x21, [sp, #0x48]
    d56c:      	b	0xd5bc <generic_rawtp_path+0x44bc>
    d570:      	add	x2, x24, #0x10
    d574:      	mov	w8, #0x4                // =4
    d578:      	add	x9, sp, #0x98
    d57c:      	add	x0, sp, #0x98
    d580:      	mov	w1, #0x8                // =8
    d584:      	blr	x8
    d588:      	ldr	x8, [sp, #0x58]
    d58c:      	ldr	x9, [sp, #0x98]
    d590:      	cmp	x8, x9
    d594:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d598:      	add	x2, x24, #0x18
    d59c:      	mov	w8, #0x4                // =4
    d5a0:      	mov	x0, x22
    d5a4:      	mov	w1, #0x8                // =8
    d5a8:      	blr	x8
    d5ac:      	ldr	x24, [sp, #0x98]
    d5b0:      	ldr	x21, [sp, #0x48]
    d5b4:      	add	x2, x24, #0x20
    d5b8:      	stp	x2, x24, [sp, #0x50]
    d5bc:      	ldr	x8, [sp, #0x30]
    d5c0:      	cmp	x21, x8
    d5c4:      	b.ne	0xd5d4 <generic_rawtp_path+0x44d4>
    d5c8:      	ldr	x8, [sp, #0x38]
    d5cc:      	cmp	x2, x8
    d5d0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d5d4:      	mov	w8, #0x4                // =4
    d5d8:      	add	x0, sp, #0x70
    d5dc:      	mov	w1, #0x8                // =8
    d5e0:      	blr	x8
    d5e4:      	ldr	x8, [sp, #0x70]
    d5e8:      	cmp	x21, x8
    d5ec:      	b.eq	0xd6dc <generic_rawtp_path+0x45dc>
    d5f0:      	add	x23, x21, #0x18
    d5f4:      	mov	w8, #0x4                // =4
    d5f8:      	add	x9, sp, #0x98
    d5fc:      	add	x0, sp, #0x98
    d600:      	mov	w1, #0x8                // =8
    d604:      	mov	x2, x23
    d608:      	blr	x8
    d60c:      	ldr	x8, [sp, #0x98]
    d610:      	cmp	x8, x21
    d614:      	b.eq	0xd6dc <generic_rawtp_path+0x45dc>
    d618:      	mov	w8, #0x4                // =4
    d61c:      	add	x9, sp, #0x78
    d620:      	add	x0, sp, #0x78
    d624:      	mov	w1, #0x8                // =8
    d628:      	mov	x2, x23
    d62c:      	blr	x8
    d630:      	add	x2, x21, #0x20
    d634:      	mov	w8, #0x4                // =4
    d638:      	mov	w9, #0x10               // =16
    d63c:      	add	x10, sp, #0x80
    d640:      	add	x0, sp, #0x80
    d644:      	mov	w1, #0x10               // =16
    d648:      	blr	x8
    d64c:      	ldr	w21, [sp, #0x84]
    d650:      	ldr	x8, [sp, #0x40]
    d654:      	ldr	x10, [sp, #0x60]
    d658:      	sub	x12, x10, x8
    d65c:      	ldr	w23, [sp, #0x68]
    d660:      	subs	w10, w21, w23
    d664:      	ldr	x9, [sp, #0x88]
    d668:      	csel	w10, wzr, w10, lo
    d66c:      	cmp	w23, w21
    d670:      	csel	w11, w23, w21, lo
    d674:      	cinc	w13, w11, hi
    d678:      	sub	w14, w23, w13
    d67c:      	subs	x12, x12, x13
    d680:      	str	w14, [sp, #0x68]
    d684:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d688:      	cmp	x12, #0xfff
    d68c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d690:      	cmp	w23, w21
    d694:      	b.ls	0xd6a0 <generic_rawtp_path+0x45a0>
    d698:      	mov	w13, #0x2f              // =47
    d69c:      	strb	w13, [x8, x12]
    d6a0:      	add	x19, x8, x12
    d6a4:      	cmp	w23, w21
    d6a8:      	add	x2, x9, x10
    d6ac:      	and	w1, w11, #0xff
    d6b0:      	mov	w8, #0x4                // =4
    d6b4:      	cinc	x0, x19, hi
    d6b8:      	blr	x8
    d6bc:      	cmp	w23, w21
    d6c0:      	str	x19, [sp, #0x60]
    d6c4:      	add	x19, sp, #0x70
    d6c8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d6cc:      	ldr	x21, [sp, #0x78]
    d6d0:      	ldp	x2, x24, [sp, #0x50]
    d6d4:      	str	x21, [sp, #0x48]
    d6d8:      	b	0xd728 <generic_rawtp_path+0x4628>
    d6dc:      	add	x2, x24, #0x10
    d6e0:      	mov	w8, #0x4                // =4
    d6e4:      	add	x9, sp, #0x98
    d6e8:      	add	x0, sp, #0x98
    d6ec:      	mov	w1, #0x8                // =8
    d6f0:      	blr	x8
    d6f4:      	ldr	x8, [sp, #0x58]
    d6f8:      	ldr	x9, [sp, #0x98]
    d6fc:      	cmp	x8, x9
    d700:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d704:      	add	x2, x24, #0x18
    d708:      	mov	w8, #0x4                // =4
    d70c:      	mov	x0, x22
    d710:      	mov	w1, #0x8                // =8
    d714:      	blr	x8
    d718:      	ldr	x24, [sp, #0x98]
    d71c:      	ldr	x21, [sp, #0x48]
    d720:      	add	x2, x24, #0x20
    d724:      	stp	x2, x24, [sp, #0x50]
    d728:      	ldr	x8, [sp, #0x30]
    d72c:      	cmp	x21, x8
    d730:      	b.ne	0xd740 <generic_rawtp_path+0x4640>
    d734:      	ldr	x8, [sp, #0x38]
    d738:      	cmp	x2, x8
    d73c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d740:      	mov	w8, #0x4                // =4
    d744:      	add	x0, sp, #0x70
    d748:      	mov	w1, #0x8                // =8
    d74c:      	blr	x8
    d750:      	ldr	x8, [sp, #0x70]
    d754:      	cmp	x21, x8
    d758:      	b.eq	0xd848 <generic_rawtp_path+0x4748>
    d75c:      	add	x23, x21, #0x18
    d760:      	mov	w8, #0x4                // =4
    d764:      	add	x9, sp, #0x98
    d768:      	add	x0, sp, #0x98
    d76c:      	mov	w1, #0x8                // =8
    d770:      	mov	x2, x23
    d774:      	blr	x8
    d778:      	ldr	x8, [sp, #0x98]
    d77c:      	cmp	x8, x21
    d780:      	b.eq	0xd848 <generic_rawtp_path+0x4748>
    d784:      	mov	w8, #0x4                // =4
    d788:      	add	x9, sp, #0x78
    d78c:      	add	x0, sp, #0x78
    d790:      	mov	w1, #0x8                // =8
    d794:      	mov	x2, x23
    d798:      	blr	x8
    d79c:      	add	x2, x21, #0x20
    d7a0:      	mov	w8, #0x4                // =4
    d7a4:      	mov	w9, #0x10               // =16
    d7a8:      	add	x10, sp, #0x80
    d7ac:      	add	x0, sp, #0x80
    d7b0:      	mov	w1, #0x10               // =16
    d7b4:      	blr	x8
    d7b8:      	ldr	w21, [sp, #0x84]
    d7bc:      	ldr	x8, [sp, #0x40]
    d7c0:      	ldr	x10, [sp, #0x60]
    d7c4:      	sub	x12, x10, x8
    d7c8:      	ldr	w23, [sp, #0x68]
    d7cc:      	subs	w10, w21, w23
    d7d0:      	ldr	x9, [sp, #0x88]
    d7d4:      	csel	w10, wzr, w10, lo
    d7d8:      	cmp	w23, w21
    d7dc:      	csel	w11, w23, w21, lo
    d7e0:      	cinc	w13, w11, hi
    d7e4:      	sub	w14, w23, w13
    d7e8:      	subs	x12, x12, x13
    d7ec:      	str	w14, [sp, #0x68]
    d7f0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d7f4:      	cmp	x12, #0xfff
    d7f8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d7fc:      	cmp	w23, w21
    d800:      	b.ls	0xd80c <generic_rawtp_path+0x470c>
    d804:      	mov	w13, #0x2f              // =47
    d808:      	strb	w13, [x8, x12]
    d80c:      	add	x19, x8, x12
    d810:      	cmp	w23, w21
    d814:      	add	x2, x9, x10
    d818:      	and	w1, w11, #0xff
    d81c:      	mov	w8, #0x4                // =4
    d820:      	cinc	x0, x19, hi
    d824:      	blr	x8
    d828:      	cmp	w23, w21
    d82c:      	str	x19, [sp, #0x60]
    d830:      	add	x19, sp, #0x70
    d834:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d838:      	ldr	x21, [sp, #0x78]
    d83c:      	ldp	x2, x24, [sp, #0x50]
    d840:      	str	x21, [sp, #0x48]
    d844:      	b	0xd894 <generic_rawtp_path+0x4794>
    d848:      	add	x2, x24, #0x10
    d84c:      	mov	w8, #0x4                // =4
    d850:      	add	x9, sp, #0x98
    d854:      	add	x0, sp, #0x98
    d858:      	mov	w1, #0x8                // =8
    d85c:      	blr	x8
    d860:      	ldr	x8, [sp, #0x58]
    d864:      	ldr	x9, [sp, #0x98]
    d868:      	cmp	x8, x9
    d86c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d870:      	add	x2, x24, #0x18
    d874:      	mov	w8, #0x4                // =4
    d878:      	mov	x0, x22
    d87c:      	mov	w1, #0x8                // =8
    d880:      	blr	x8
    d884:      	ldr	x24, [sp, #0x98]
    d888:      	ldr	x21, [sp, #0x48]
    d88c:      	add	x2, x24, #0x20
    d890:      	stp	x2, x24, [sp, #0x50]
    d894:      	ldr	x8, [sp, #0x30]
    d898:      	cmp	x21, x8
    d89c:      	b.ne	0xd8ac <generic_rawtp_path+0x47ac>
    d8a0:      	ldr	x8, [sp, #0x38]
    d8a4:      	cmp	x2, x8
    d8a8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d8ac:      	mov	w8, #0x4                // =4
    d8b0:      	add	x0, sp, #0x70
    d8b4:      	mov	w1, #0x8                // =8
    d8b8:      	blr	x8
    d8bc:      	ldr	x8, [sp, #0x70]
    d8c0:      	cmp	x21, x8
    d8c4:      	b.eq	0xd9b4 <generic_rawtp_path+0x48b4>
    d8c8:      	add	x23, x21, #0x18
    d8cc:      	mov	w8, #0x4                // =4
    d8d0:      	add	x9, sp, #0x98
    d8d4:      	add	x0, sp, #0x98
    d8d8:      	mov	w1, #0x8                // =8
    d8dc:      	mov	x2, x23
    d8e0:      	blr	x8
    d8e4:      	ldr	x8, [sp, #0x98]
    d8e8:      	cmp	x8, x21
    d8ec:      	b.eq	0xd9b4 <generic_rawtp_path+0x48b4>
    d8f0:      	mov	w8, #0x4                // =4
    d8f4:      	add	x9, sp, #0x78
    d8f8:      	add	x0, sp, #0x78
    d8fc:      	mov	w1, #0x8                // =8
    d900:      	mov	x2, x23
    d904:      	blr	x8
    d908:      	add	x2, x21, #0x20
    d90c:      	mov	w8, #0x4                // =4
    d910:      	mov	w9, #0x10               // =16
    d914:      	add	x10, sp, #0x80
    d918:      	add	x0, sp, #0x80
    d91c:      	mov	w1, #0x10               // =16
    d920:      	blr	x8
    d924:      	ldr	w21, [sp, #0x84]
    d928:      	ldr	x8, [sp, #0x40]
    d92c:      	ldr	x10, [sp, #0x60]
    d930:      	sub	x12, x10, x8
    d934:      	ldr	w23, [sp, #0x68]
    d938:      	subs	w10, w21, w23
    d93c:      	ldr	x9, [sp, #0x88]
    d940:      	csel	w10, wzr, w10, lo
    d944:      	cmp	w23, w21
    d948:      	csel	w11, w23, w21, lo
    d94c:      	cinc	w13, w11, hi
    d950:      	sub	w14, w23, w13
    d954:      	subs	x12, x12, x13
    d958:      	str	w14, [sp, #0x68]
    d95c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    d960:      	cmp	x12, #0xfff
    d964:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    d968:      	cmp	w23, w21
    d96c:      	b.ls	0xd978 <generic_rawtp_path+0x4878>
    d970:      	mov	w13, #0x2f              // =47
    d974:      	strb	w13, [x8, x12]
    d978:      	add	x19, x8, x12
    d97c:      	cmp	w23, w21
    d980:      	add	x2, x9, x10
    d984:      	and	w1, w11, #0xff
    d988:      	mov	w8, #0x4                // =4
    d98c:      	cinc	x0, x19, hi
    d990:      	blr	x8
    d994:      	cmp	w23, w21
    d998:      	str	x19, [sp, #0x60]
    d99c:      	add	x19, sp, #0x70
    d9a0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    d9a4:      	ldr	x21, [sp, #0x78]
    d9a8:      	ldp	x2, x24, [sp, #0x50]
    d9ac:      	str	x21, [sp, #0x48]
    d9b0:      	b	0xda00 <generic_rawtp_path+0x4900>
    d9b4:      	add	x2, x24, #0x10
    d9b8:      	mov	w8, #0x4                // =4
    d9bc:      	add	x9, sp, #0x98
    d9c0:      	add	x0, sp, #0x98
    d9c4:      	mov	w1, #0x8                // =8
    d9c8:      	blr	x8
    d9cc:      	ldr	x8, [sp, #0x58]
    d9d0:      	ldr	x9, [sp, #0x98]
    d9d4:      	cmp	x8, x9
    d9d8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    d9dc:      	add	x2, x24, #0x18
    d9e0:      	mov	w8, #0x4                // =4
    d9e4:      	mov	x0, x22
    d9e8:      	mov	w1, #0x8                // =8
    d9ec:      	blr	x8
    d9f0:      	ldr	x24, [sp, #0x98]
    d9f4:      	ldr	x21, [sp, #0x48]
    d9f8:      	add	x2, x24, #0x20
    d9fc:      	stp	x2, x24, [sp, #0x50]
    da00:      	ldr	x8, [sp, #0x30]
    da04:      	cmp	x21, x8
    da08:      	b.ne	0xda18 <generic_rawtp_path+0x4918>
    da0c:      	ldr	x8, [sp, #0x38]
    da10:      	cmp	x2, x8
    da14:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    da18:      	mov	w8, #0x4                // =4
    da1c:      	add	x0, sp, #0x70
    da20:      	mov	w1, #0x8                // =8
    da24:      	blr	x8
    da28:      	ldr	x8, [sp, #0x70]
    da2c:      	cmp	x21, x8
    da30:      	b.eq	0xdb20 <generic_rawtp_path+0x4a20>
    da34:      	add	x23, x21, #0x18
    da38:      	mov	w8, #0x4                // =4
    da3c:      	add	x9, sp, #0x98
    da40:      	add	x0, sp, #0x98
    da44:      	mov	w1, #0x8                // =8
    da48:      	mov	x2, x23
    da4c:      	blr	x8
    da50:      	ldr	x8, [sp, #0x98]
    da54:      	cmp	x8, x21
    da58:      	b.eq	0xdb20 <generic_rawtp_path+0x4a20>
    da5c:      	mov	w8, #0x4                // =4
    da60:      	add	x9, sp, #0x78
    da64:      	add	x0, sp, #0x78
    da68:      	mov	w1, #0x8                // =8
    da6c:      	mov	x2, x23
    da70:      	blr	x8
    da74:      	add	x2, x21, #0x20
    da78:      	mov	w8, #0x4                // =4
    da7c:      	mov	w9, #0x10               // =16
    da80:      	add	x10, sp, #0x80
    da84:      	add	x0, sp, #0x80
    da88:      	mov	w1, #0x10               // =16
    da8c:      	blr	x8
    da90:      	ldr	w21, [sp, #0x84]
    da94:      	ldr	x8, [sp, #0x40]
    da98:      	ldr	x10, [sp, #0x60]
    da9c:      	sub	x12, x10, x8
    daa0:      	ldr	w23, [sp, #0x68]
    daa4:      	subs	w10, w21, w23
    daa8:      	ldr	x9, [sp, #0x88]
    daac:      	csel	w10, wzr, w10, lo
    dab0:      	cmp	w23, w21
    dab4:      	csel	w11, w23, w21, lo
    dab8:      	cinc	w13, w11, hi
    dabc:      	sub	w14, w23, w13
    dac0:      	subs	x12, x12, x13
    dac4:      	str	w14, [sp, #0x68]
    dac8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    dacc:      	cmp	x12, #0xfff
    dad0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    dad4:      	cmp	w23, w21
    dad8:      	b.ls	0xdae4 <generic_rawtp_path+0x49e4>
    dadc:      	mov	w13, #0x2f              // =47
    dae0:      	strb	w13, [x8, x12]
    dae4:      	add	x19, x8, x12
    dae8:      	cmp	w23, w21
    daec:      	add	x2, x9, x10
    daf0:      	and	w1, w11, #0xff
    daf4:      	mov	w8, #0x4                // =4
    daf8:      	cinc	x0, x19, hi
    dafc:      	blr	x8
    db00:      	cmp	w23, w21
    db04:      	str	x19, [sp, #0x60]
    db08:      	add	x19, sp, #0x70
    db0c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    db10:      	ldr	x21, [sp, #0x78]
    db14:      	ldp	x2, x24, [sp, #0x50]
    db18:      	str	x21, [sp, #0x48]
    db1c:      	b	0xdb6c <generic_rawtp_path+0x4a6c>
    db20:      	add	x2, x24, #0x10
    db24:      	mov	w8, #0x4                // =4
    db28:      	add	x9, sp, #0x98
    db2c:      	add	x0, sp, #0x98
    db30:      	mov	w1, #0x8                // =8
    db34:      	blr	x8
    db38:      	ldr	x8, [sp, #0x58]
    db3c:      	ldr	x9, [sp, #0x98]
    db40:      	cmp	x8, x9
    db44:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    db48:      	add	x2, x24, #0x18
    db4c:      	mov	w8, #0x4                // =4
    db50:      	mov	x0, x22
    db54:      	mov	w1, #0x8                // =8
    db58:      	blr	x8
    db5c:      	ldr	x24, [sp, #0x98]
    db60:      	ldr	x21, [sp, #0x48]
    db64:      	add	x2, x24, #0x20
    db68:      	stp	x2, x24, [sp, #0x50]
    db6c:      	ldr	x8, [sp, #0x30]
    db70:      	cmp	x21, x8
    db74:      	b.ne	0xdb84 <generic_rawtp_path+0x4a84>
    db78:      	ldr	x8, [sp, #0x38]
    db7c:      	cmp	x2, x8
    db80:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    db84:      	mov	w8, #0x4                // =4
    db88:      	add	x0, sp, #0x70
    db8c:      	mov	w1, #0x8                // =8
    db90:      	blr	x8
    db94:      	ldr	x8, [sp, #0x70]
    db98:      	cmp	x21, x8
    db9c:      	b.eq	0xdc8c <generic_rawtp_path+0x4b8c>
    dba0:      	add	x23, x21, #0x18
    dba4:      	mov	w8, #0x4                // =4
    dba8:      	add	x9, sp, #0x98
    dbac:      	add	x0, sp, #0x98
    dbb0:      	mov	w1, #0x8                // =8
    dbb4:      	mov	x2, x23
    dbb8:      	blr	x8
    dbbc:      	ldr	x8, [sp, #0x98]
    dbc0:      	cmp	x8, x21
    dbc4:      	b.eq	0xdc8c <generic_rawtp_path+0x4b8c>
    dbc8:      	mov	w8, #0x4                // =4
    dbcc:      	add	x9, sp, #0x78
    dbd0:      	add	x0, sp, #0x78
    dbd4:      	mov	w1, #0x8                // =8
    dbd8:      	mov	x2, x23
    dbdc:      	blr	x8
    dbe0:      	add	x2, x21, #0x20
    dbe4:      	mov	w8, #0x4                // =4
    dbe8:      	mov	w9, #0x10               // =16
    dbec:      	add	x10, sp, #0x80
    dbf0:      	add	x0, sp, #0x80
    dbf4:      	mov	w1, #0x10               // =16
    dbf8:      	blr	x8
    dbfc:      	ldr	w21, [sp, #0x84]
    dc00:      	ldr	x8, [sp, #0x40]
    dc04:      	ldr	x10, [sp, #0x60]
    dc08:      	sub	x12, x10, x8
    dc0c:      	ldr	w23, [sp, #0x68]
    dc10:      	subs	w10, w21, w23
    dc14:      	ldr	x9, [sp, #0x88]
    dc18:      	csel	w10, wzr, w10, lo
    dc1c:      	cmp	w23, w21
    dc20:      	csel	w11, w23, w21, lo
    dc24:      	cinc	w13, w11, hi
    dc28:      	sub	w14, w23, w13
    dc2c:      	subs	x12, x12, x13
    dc30:      	str	w14, [sp, #0x68]
    dc34:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    dc38:      	cmp	x12, #0xfff
    dc3c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    dc40:      	cmp	w23, w21
    dc44:      	b.ls	0xdc50 <generic_rawtp_path+0x4b50>
    dc48:      	mov	w13, #0x2f              // =47
    dc4c:      	strb	w13, [x8, x12]
    dc50:      	add	x19, x8, x12
    dc54:      	cmp	w23, w21
    dc58:      	add	x2, x9, x10
    dc5c:      	and	w1, w11, #0xff
    dc60:      	mov	w8, #0x4                // =4
    dc64:      	cinc	x0, x19, hi
    dc68:      	blr	x8
    dc6c:      	cmp	w23, w21
    dc70:      	str	x19, [sp, #0x60]
    dc74:      	add	x19, sp, #0x70
    dc78:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    dc7c:      	ldr	x21, [sp, #0x78]
    dc80:      	ldp	x2, x24, [sp, #0x50]
    dc84:      	str	x21, [sp, #0x48]
    dc88:      	b	0xdcd8 <generic_rawtp_path+0x4bd8>
    dc8c:      	add	x2, x24, #0x10
    dc90:      	mov	w8, #0x4                // =4
    dc94:      	add	x9, sp, #0x98
    dc98:      	add	x0, sp, #0x98
    dc9c:      	mov	w1, #0x8                // =8
    dca0:      	blr	x8
    dca4:      	ldr	x8, [sp, #0x58]
    dca8:      	ldr	x9, [sp, #0x98]
    dcac:      	cmp	x8, x9
    dcb0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    dcb4:      	add	x2, x24, #0x18
    dcb8:      	mov	w8, #0x4                // =4
    dcbc:      	mov	x0, x22
    dcc0:      	mov	w1, #0x8                // =8
    dcc4:      	blr	x8
    dcc8:      	ldr	x24, [sp, #0x98]
    dccc:      	ldr	x21, [sp, #0x48]
    dcd0:      	add	x2, x24, #0x20
    dcd4:      	stp	x2, x24, [sp, #0x50]
    dcd8:      	ldr	x8, [sp, #0x30]
    dcdc:      	cmp	x21, x8
    dce0:      	b.ne	0xdcf0 <generic_rawtp_path+0x4bf0>
    dce4:      	ldr	x8, [sp, #0x38]
    dce8:      	cmp	x2, x8
    dcec:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    dcf0:      	mov	w8, #0x4                // =4
    dcf4:      	add	x0, sp, #0x70
    dcf8:      	mov	w1, #0x8                // =8
    dcfc:      	blr	x8
    dd00:      	ldr	x8, [sp, #0x70]
    dd04:      	cmp	x21, x8
    dd08:      	b.eq	0xddf8 <generic_rawtp_path+0x4cf8>
    dd0c:      	add	x23, x21, #0x18
    dd10:      	mov	w8, #0x4                // =4
    dd14:      	add	x9, sp, #0x98
    dd18:      	add	x0, sp, #0x98
    dd1c:      	mov	w1, #0x8                // =8
    dd20:      	mov	x2, x23
    dd24:      	blr	x8
    dd28:      	ldr	x8, [sp, #0x98]
    dd2c:      	cmp	x8, x21
    dd30:      	b.eq	0xddf8 <generic_rawtp_path+0x4cf8>
    dd34:      	mov	w8, #0x4                // =4
    dd38:      	add	x9, sp, #0x78
    dd3c:      	add	x0, sp, #0x78
    dd40:      	mov	w1, #0x8                // =8
    dd44:      	mov	x2, x23
    dd48:      	blr	x8
    dd4c:      	add	x2, x21, #0x20
    dd50:      	mov	w8, #0x4                // =4
    dd54:      	mov	w9, #0x10               // =16
    dd58:      	add	x10, sp, #0x80
    dd5c:      	add	x0, sp, #0x80
    dd60:      	mov	w1, #0x10               // =16
    dd64:      	blr	x8
    dd68:      	ldr	w21, [sp, #0x84]
    dd6c:      	ldr	x8, [sp, #0x40]
    dd70:      	ldr	x10, [sp, #0x60]
    dd74:      	sub	x12, x10, x8
    dd78:      	ldr	w23, [sp, #0x68]
    dd7c:      	subs	w10, w21, w23
    dd80:      	ldr	x9, [sp, #0x88]
    dd84:      	csel	w10, wzr, w10, lo
    dd88:      	cmp	w23, w21
    dd8c:      	csel	w11, w23, w21, lo
    dd90:      	cinc	w13, w11, hi
    dd94:      	sub	w14, w23, w13
    dd98:      	subs	x12, x12, x13
    dd9c:      	str	w14, [sp, #0x68]
    dda0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    dda4:      	cmp	x12, #0xfff
    dda8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ddac:      	cmp	w23, w21
    ddb0:      	b.ls	0xddbc <generic_rawtp_path+0x4cbc>
    ddb4:      	mov	w13, #0x2f              // =47
    ddb8:      	strb	w13, [x8, x12]
    ddbc:      	add	x19, x8, x12
    ddc0:      	cmp	w23, w21
    ddc4:      	add	x2, x9, x10
    ddc8:      	and	w1, w11, #0xff
    ddcc:      	mov	w8, #0x4                // =4
    ddd0:      	cinc	x0, x19, hi
    ddd4:      	blr	x8
    ddd8:      	cmp	w23, w21
    dddc:      	str	x19, [sp, #0x60]
    dde0:      	add	x19, sp, #0x70
    dde4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    dde8:      	ldr	x21, [sp, #0x78]
    ddec:      	ldp	x2, x24, [sp, #0x50]
    ddf0:      	str	x21, [sp, #0x48]
    ddf4:      	b	0xde44 <generic_rawtp_path+0x4d44>
    ddf8:      	add	x2, x24, #0x10
    ddfc:      	mov	w8, #0x4                // =4
    de00:      	add	x9, sp, #0x98
    de04:      	add	x0, sp, #0x98
    de08:      	mov	w1, #0x8                // =8
    de0c:      	blr	x8
    de10:      	ldr	x8, [sp, #0x58]
    de14:      	ldr	x9, [sp, #0x98]
    de18:      	cmp	x8, x9
    de1c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    de20:      	add	x2, x24, #0x18
    de24:      	mov	w8, #0x4                // =4
    de28:      	mov	x0, x22
    de2c:      	mov	w1, #0x8                // =8
    de30:      	blr	x8
    de34:      	ldr	x24, [sp, #0x98]
    de38:      	ldr	x21, [sp, #0x48]
    de3c:      	add	x2, x24, #0x20
    de40:      	stp	x2, x24, [sp, #0x50]
    de44:      	ldr	x8, [sp, #0x30]
    de48:      	cmp	x21, x8
    de4c:      	b.ne	0xde5c <generic_rawtp_path+0x4d5c>
    de50:      	ldr	x8, [sp, #0x38]
    de54:      	cmp	x2, x8
    de58:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    de5c:      	mov	w8, #0x4                // =4
    de60:      	add	x0, sp, #0x70
    de64:      	mov	w1, #0x8                // =8
    de68:      	blr	x8
    de6c:      	ldr	x8, [sp, #0x70]
    de70:      	cmp	x21, x8
    de74:      	b.eq	0xdf64 <generic_rawtp_path+0x4e64>
    de78:      	add	x23, x21, #0x18
    de7c:      	mov	w8, #0x4                // =4
    de80:      	add	x9, sp, #0x98
    de84:      	add	x0, sp, #0x98
    de88:      	mov	w1, #0x8                // =8
    de8c:      	mov	x2, x23
    de90:      	blr	x8
    de94:      	ldr	x8, [sp, #0x98]
    de98:      	cmp	x8, x21
    de9c:      	b.eq	0xdf64 <generic_rawtp_path+0x4e64>
    dea0:      	mov	w8, #0x4                // =4
    dea4:      	add	x9, sp, #0x78
    dea8:      	add	x0, sp, #0x78
    deac:      	mov	w1, #0x8                // =8
    deb0:      	mov	x2, x23
    deb4:      	blr	x8
    deb8:      	add	x2, x21, #0x20
    debc:      	mov	w8, #0x4                // =4
    dec0:      	mov	w9, #0x10               // =16
    dec4:      	add	x10, sp, #0x80
    dec8:      	add	x0, sp, #0x80
    decc:      	mov	w1, #0x10               // =16
    ded0:      	blr	x8
    ded4:      	ldr	w21, [sp, #0x84]
    ded8:      	ldr	x8, [sp, #0x40]
    dedc:      	ldr	x10, [sp, #0x60]
    dee0:      	sub	x12, x10, x8
    dee4:      	ldr	w23, [sp, #0x68]
    dee8:      	subs	w10, w21, w23
    deec:      	ldr	x9, [sp, #0x88]
    def0:      	csel	w10, wzr, w10, lo
    def4:      	cmp	w23, w21
    def8:      	csel	w11, w23, w21, lo
    defc:      	cinc	w13, w11, hi
    df00:      	sub	w14, w23, w13
    df04:      	subs	x12, x12, x13
    df08:      	str	w14, [sp, #0x68]
    df0c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    df10:      	cmp	x12, #0xfff
    df14:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    df18:      	cmp	w23, w21
    df1c:      	b.ls	0xdf28 <generic_rawtp_path+0x4e28>
    df20:      	mov	w13, #0x2f              // =47
    df24:      	strb	w13, [x8, x12]
    df28:      	add	x19, x8, x12
    df2c:      	cmp	w23, w21
    df30:      	add	x2, x9, x10
    df34:      	and	w1, w11, #0xff
    df38:      	mov	w8, #0x4                // =4
    df3c:      	cinc	x0, x19, hi
    df40:      	blr	x8
    df44:      	cmp	w23, w21
    df48:      	str	x19, [sp, #0x60]
    df4c:      	add	x19, sp, #0x70
    df50:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    df54:      	ldr	x21, [sp, #0x78]
    df58:      	ldp	x2, x24, [sp, #0x50]
    df5c:      	str	x21, [sp, #0x48]
    df60:      	b	0xdfb0 <generic_rawtp_path+0x4eb0>
    df64:      	add	x2, x24, #0x10
    df68:      	mov	w8, #0x4                // =4
    df6c:      	add	x9, sp, #0x98
    df70:      	add	x0, sp, #0x98
    df74:      	mov	w1, #0x8                // =8
    df78:      	blr	x8
    df7c:      	ldr	x8, [sp, #0x58]
    df80:      	ldr	x9, [sp, #0x98]
    df84:      	cmp	x8, x9
    df88:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    df8c:      	add	x2, x24, #0x18
    df90:      	mov	w8, #0x4                // =4
    df94:      	mov	x0, x22
    df98:      	mov	w1, #0x8                // =8
    df9c:      	blr	x8
    dfa0:      	ldr	x24, [sp, #0x98]
    dfa4:      	ldr	x21, [sp, #0x48]
    dfa8:      	add	x2, x24, #0x20
    dfac:      	stp	x2, x24, [sp, #0x50]
    dfb0:      	ldr	x8, [sp, #0x30]
    dfb4:      	cmp	x21, x8
    dfb8:      	b.ne	0xdfc8 <generic_rawtp_path+0x4ec8>
    dfbc:      	ldr	x8, [sp, #0x38]
    dfc0:      	cmp	x2, x8
    dfc4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    dfc8:      	mov	w8, #0x4                // =4
    dfcc:      	add	x0, sp, #0x70
    dfd0:      	mov	w1, #0x8                // =8
    dfd4:      	blr	x8
    dfd8:      	ldr	x8, [sp, #0x70]
    dfdc:      	cmp	x21, x8
    dfe0:      	b.eq	0xe0d0 <generic_rawtp_path+0x4fd0>
    dfe4:      	add	x23, x21, #0x18
    dfe8:      	mov	w8, #0x4                // =4
    dfec:      	add	x9, sp, #0x98
    dff0:      	add	x0, sp, #0x98
    dff4:      	mov	w1, #0x8                // =8
    dff8:      	mov	x2, x23
    dffc:      	blr	x8
    e000:      	ldr	x8, [sp, #0x98]
    e004:      	cmp	x8, x21
    e008:      	b.eq	0xe0d0 <generic_rawtp_path+0x4fd0>
    e00c:      	mov	w8, #0x4                // =4
    e010:      	add	x9, sp, #0x78
    e014:      	add	x0, sp, #0x78
    e018:      	mov	w1, #0x8                // =8
    e01c:      	mov	x2, x23
    e020:      	blr	x8
    e024:      	add	x2, x21, #0x20
    e028:      	mov	w8, #0x4                // =4
    e02c:      	mov	w9, #0x10               // =16
    e030:      	add	x10, sp, #0x80
    e034:      	add	x0, sp, #0x80
    e038:      	mov	w1, #0x10               // =16
    e03c:      	blr	x8
    e040:      	ldr	w21, [sp, #0x84]
    e044:      	ldr	x8, [sp, #0x40]
    e048:      	ldr	x10, [sp, #0x60]
    e04c:      	sub	x12, x10, x8
    e050:      	ldr	w23, [sp, #0x68]
    e054:      	subs	w10, w21, w23
    e058:      	ldr	x9, [sp, #0x88]
    e05c:      	csel	w10, wzr, w10, lo
    e060:      	cmp	w23, w21
    e064:      	csel	w11, w23, w21, lo
    e068:      	cinc	w13, w11, hi
    e06c:      	sub	w14, w23, w13
    e070:      	subs	x12, x12, x13
    e074:      	str	w14, [sp, #0x68]
    e078:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e07c:      	cmp	x12, #0xfff
    e080:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e084:      	cmp	w23, w21
    e088:      	b.ls	0xe094 <generic_rawtp_path+0x4f94>
    e08c:      	mov	w13, #0x2f              // =47
    e090:      	strb	w13, [x8, x12]
    e094:      	add	x19, x8, x12
    e098:      	cmp	w23, w21
    e09c:      	add	x2, x9, x10
    e0a0:      	and	w1, w11, #0xff
    e0a4:      	mov	w8, #0x4                // =4
    e0a8:      	cinc	x0, x19, hi
    e0ac:      	blr	x8
    e0b0:      	cmp	w23, w21
    e0b4:      	str	x19, [sp, #0x60]
    e0b8:      	add	x19, sp, #0x70
    e0bc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e0c0:      	ldr	x21, [sp, #0x78]
    e0c4:      	ldp	x2, x24, [sp, #0x50]
    e0c8:      	str	x21, [sp, #0x48]
    e0cc:      	b	0xe11c <generic_rawtp_path+0x501c>
    e0d0:      	add	x2, x24, #0x10
    e0d4:      	mov	w8, #0x4                // =4
    e0d8:      	add	x9, sp, #0x98
    e0dc:      	add	x0, sp, #0x98
    e0e0:      	mov	w1, #0x8                // =8
    e0e4:      	blr	x8
    e0e8:      	ldr	x8, [sp, #0x58]
    e0ec:      	ldr	x9, [sp, #0x98]
    e0f0:      	cmp	x8, x9
    e0f4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e0f8:      	add	x2, x24, #0x18
    e0fc:      	mov	w8, #0x4                // =4
    e100:      	mov	x0, x22
    e104:      	mov	w1, #0x8                // =8
    e108:      	blr	x8
    e10c:      	ldr	x24, [sp, #0x98]
    e110:      	ldr	x21, [sp, #0x48]
    e114:      	add	x2, x24, #0x20
    e118:      	stp	x2, x24, [sp, #0x50]
    e11c:      	ldr	x8, [sp, #0x30]
    e120:      	cmp	x21, x8
    e124:      	b.ne	0xe134 <generic_rawtp_path+0x5034>
    e128:      	ldr	x8, [sp, #0x38]
    e12c:      	cmp	x2, x8
    e130:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e134:      	mov	w8, #0x4                // =4
    e138:      	add	x0, sp, #0x70
    e13c:      	mov	w1, #0x8                // =8
    e140:      	blr	x8
    e144:      	ldr	x8, [sp, #0x70]
    e148:      	cmp	x21, x8
    e14c:      	b.eq	0xe23c <generic_rawtp_path+0x513c>
    e150:      	add	x23, x21, #0x18
    e154:      	mov	w8, #0x4                // =4
    e158:      	add	x9, sp, #0x98
    e15c:      	add	x0, sp, #0x98
    e160:      	mov	w1, #0x8                // =8
    e164:      	mov	x2, x23
    e168:      	blr	x8
    e16c:      	ldr	x8, [sp, #0x98]
    e170:      	cmp	x8, x21
    e174:      	b.eq	0xe23c <generic_rawtp_path+0x513c>
    e178:      	mov	w8, #0x4                // =4
    e17c:      	add	x9, sp, #0x78
    e180:      	add	x0, sp, #0x78
    e184:      	mov	w1, #0x8                // =8
    e188:      	mov	x2, x23
    e18c:      	blr	x8
    e190:      	add	x2, x21, #0x20
    e194:      	mov	w8, #0x4                // =4
    e198:      	mov	w9, #0x10               // =16
    e19c:      	add	x10, sp, #0x80
    e1a0:      	add	x0, sp, #0x80
    e1a4:      	mov	w1, #0x10               // =16
    e1a8:      	blr	x8
    e1ac:      	ldr	w21, [sp, #0x84]
    e1b0:      	ldr	x8, [sp, #0x40]
    e1b4:      	ldr	x10, [sp, #0x60]
    e1b8:      	sub	x12, x10, x8
    e1bc:      	ldr	w23, [sp, #0x68]
    e1c0:      	subs	w10, w21, w23
    e1c4:      	ldr	x9, [sp, #0x88]
    e1c8:      	csel	w10, wzr, w10, lo
    e1cc:      	cmp	w23, w21
    e1d0:      	csel	w11, w23, w21, lo
    e1d4:      	cinc	w13, w11, hi
    e1d8:      	sub	w14, w23, w13
    e1dc:      	subs	x12, x12, x13
    e1e0:      	str	w14, [sp, #0x68]
    e1e4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e1e8:      	cmp	x12, #0xfff
    e1ec:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e1f0:      	cmp	w23, w21
    e1f4:      	b.ls	0xe200 <generic_rawtp_path+0x5100>
    e1f8:      	mov	w13, #0x2f              // =47
    e1fc:      	strb	w13, [x8, x12]
    e200:      	add	x19, x8, x12
    e204:      	cmp	w23, w21
    e208:      	add	x2, x9, x10
    e20c:      	and	w1, w11, #0xff
    e210:      	mov	w8, #0x4                // =4
    e214:      	cinc	x0, x19, hi
    e218:      	blr	x8
    e21c:      	cmp	w23, w21
    e220:      	str	x19, [sp, #0x60]
    e224:      	add	x19, sp, #0x70
    e228:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e22c:      	ldr	x21, [sp, #0x78]
    e230:      	ldp	x2, x24, [sp, #0x50]
    e234:      	str	x21, [sp, #0x48]
    e238:      	b	0xe288 <generic_rawtp_path+0x5188>
    e23c:      	add	x2, x24, #0x10
    e240:      	mov	w8, #0x4                // =4
    e244:      	add	x9, sp, #0x98
    e248:      	add	x0, sp, #0x98
    e24c:      	mov	w1, #0x8                // =8
    e250:      	blr	x8
    e254:      	ldr	x8, [sp, #0x58]
    e258:      	ldr	x9, [sp, #0x98]
    e25c:      	cmp	x8, x9
    e260:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e264:      	add	x2, x24, #0x18
    e268:      	mov	w8, #0x4                // =4
    e26c:      	mov	x0, x22
    e270:      	mov	w1, #0x8                // =8
    e274:      	blr	x8
    e278:      	ldr	x24, [sp, #0x98]
    e27c:      	ldr	x21, [sp, #0x48]
    e280:      	add	x2, x24, #0x20
    e284:      	stp	x2, x24, [sp, #0x50]
    e288:      	ldr	x8, [sp, #0x30]
    e28c:      	cmp	x21, x8
    e290:      	b.ne	0xe2a0 <generic_rawtp_path+0x51a0>
    e294:      	ldr	x8, [sp, #0x38]
    e298:      	cmp	x2, x8
    e29c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e2a0:      	mov	w8, #0x4                // =4
    e2a4:      	add	x0, sp, #0x70
    e2a8:      	mov	w1, #0x8                // =8
    e2ac:      	blr	x8
    e2b0:      	ldr	x8, [sp, #0x70]
    e2b4:      	cmp	x21, x8
    e2b8:      	b.eq	0xe3a8 <generic_rawtp_path+0x52a8>
    e2bc:      	add	x23, x21, #0x18
    e2c0:      	mov	w8, #0x4                // =4
    e2c4:      	add	x9, sp, #0x98
    e2c8:      	add	x0, sp, #0x98
    e2cc:      	mov	w1, #0x8                // =8
    e2d0:      	mov	x2, x23
    e2d4:      	blr	x8
    e2d8:      	ldr	x8, [sp, #0x98]
    e2dc:      	cmp	x8, x21
    e2e0:      	b.eq	0xe3a8 <generic_rawtp_path+0x52a8>
    e2e4:      	mov	w8, #0x4                // =4
    e2e8:      	add	x9, sp, #0x78
    e2ec:      	add	x0, sp, #0x78
    e2f0:      	mov	w1, #0x8                // =8
    e2f4:      	mov	x2, x23
    e2f8:      	blr	x8
    e2fc:      	add	x2, x21, #0x20
    e300:      	mov	w8, #0x4                // =4
    e304:      	mov	w9, #0x10               // =16
    e308:      	add	x10, sp, #0x80
    e30c:      	add	x0, sp, #0x80
    e310:      	mov	w1, #0x10               // =16
    e314:      	blr	x8
    e318:      	ldr	w21, [sp, #0x84]
    e31c:      	ldr	x8, [sp, #0x40]
    e320:      	ldr	x10, [sp, #0x60]
    e324:      	sub	x12, x10, x8
    e328:      	ldr	w23, [sp, #0x68]
    e32c:      	subs	w10, w21, w23
    e330:      	ldr	x9, [sp, #0x88]
    e334:      	csel	w10, wzr, w10, lo
    e338:      	cmp	w23, w21
    e33c:      	csel	w11, w23, w21, lo
    e340:      	cinc	w13, w11, hi
    e344:      	sub	w14, w23, w13
    e348:      	subs	x12, x12, x13
    e34c:      	str	w14, [sp, #0x68]
    e350:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e354:      	cmp	x12, #0xfff
    e358:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e35c:      	cmp	w23, w21
    e360:      	b.ls	0xe36c <generic_rawtp_path+0x526c>
    e364:      	mov	w13, #0x2f              // =47
    e368:      	strb	w13, [x8, x12]
    e36c:      	add	x19, x8, x12
    e370:      	cmp	w23, w21
    e374:      	add	x2, x9, x10
    e378:      	and	w1, w11, #0xff
    e37c:      	mov	w8, #0x4                // =4
    e380:      	cinc	x0, x19, hi
    e384:      	blr	x8
    e388:      	cmp	w23, w21
    e38c:      	str	x19, [sp, #0x60]
    e390:      	add	x19, sp, #0x70
    e394:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e398:      	ldr	x21, [sp, #0x78]
    e39c:      	ldp	x2, x24, [sp, #0x50]
    e3a0:      	str	x21, [sp, #0x48]
    e3a4:      	b	0xe3f4 <generic_rawtp_path+0x52f4>
    e3a8:      	add	x2, x24, #0x10
    e3ac:      	mov	w8, #0x4                // =4
    e3b0:      	add	x9, sp, #0x98
    e3b4:      	add	x0, sp, #0x98
    e3b8:      	mov	w1, #0x8                // =8
    e3bc:      	blr	x8
    e3c0:      	ldr	x8, [sp, #0x58]
    e3c4:      	ldr	x9, [sp, #0x98]
    e3c8:      	cmp	x8, x9
    e3cc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e3d0:      	add	x2, x24, #0x18
    e3d4:      	mov	w8, #0x4                // =4
    e3d8:      	mov	x0, x22
    e3dc:      	mov	w1, #0x8                // =8
    e3e0:      	blr	x8
    e3e4:      	ldr	x24, [sp, #0x98]
    e3e8:      	ldr	x21, [sp, #0x48]
    e3ec:      	add	x2, x24, #0x20
    e3f0:      	stp	x2, x24, [sp, #0x50]
    e3f4:      	ldr	x8, [sp, #0x30]
    e3f8:      	cmp	x21, x8
    e3fc:      	b.ne	0xe40c <generic_rawtp_path+0x530c>
    e400:      	ldr	x8, [sp, #0x38]
    e404:      	cmp	x2, x8
    e408:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e40c:      	mov	w8, #0x4                // =4
    e410:      	add	x0, sp, #0x70
    e414:      	mov	w1, #0x8                // =8
    e418:      	blr	x8
    e41c:      	ldr	x8, [sp, #0x70]
    e420:      	cmp	x21, x8
    e424:      	b.eq	0xe514 <generic_rawtp_path+0x5414>
    e428:      	add	x23, x21, #0x18
    e42c:      	mov	w8, #0x4                // =4
    e430:      	add	x9, sp, #0x98
    e434:      	add	x0, sp, #0x98
    e438:      	mov	w1, #0x8                // =8
    e43c:      	mov	x2, x23
    e440:      	blr	x8
    e444:      	ldr	x8, [sp, #0x98]
    e448:      	cmp	x8, x21
    e44c:      	b.eq	0xe514 <generic_rawtp_path+0x5414>
    e450:      	mov	w8, #0x4                // =4
    e454:      	add	x9, sp, #0x78
    e458:      	add	x0, sp, #0x78
    e45c:      	mov	w1, #0x8                // =8
    e460:      	mov	x2, x23
    e464:      	blr	x8
    e468:      	add	x2, x21, #0x20
    e46c:      	mov	w8, #0x4                // =4
    e470:      	mov	w9, #0x10               // =16
    e474:      	add	x10, sp, #0x80
    e478:      	add	x0, sp, #0x80
    e47c:      	mov	w1, #0x10               // =16
    e480:      	blr	x8
    e484:      	ldr	w21, [sp, #0x84]
    e488:      	ldr	x8, [sp, #0x40]
    e48c:      	ldr	x10, [sp, #0x60]
    e490:      	sub	x12, x10, x8
    e494:      	ldr	w23, [sp, #0x68]
    e498:      	subs	w10, w21, w23
    e49c:      	ldr	x9, [sp, #0x88]
    e4a0:      	csel	w10, wzr, w10, lo
    e4a4:      	cmp	w23, w21
    e4a8:      	csel	w11, w23, w21, lo
    e4ac:      	cinc	w13, w11, hi
    e4b0:      	sub	w14, w23, w13
    e4b4:      	subs	x12, x12, x13
    e4b8:      	str	w14, [sp, #0x68]
    e4bc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e4c0:      	cmp	x12, #0xfff
    e4c4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e4c8:      	cmp	w23, w21
    e4cc:      	b.ls	0xe4d8 <generic_rawtp_path+0x53d8>
    e4d0:      	mov	w13, #0x2f              // =47
    e4d4:      	strb	w13, [x8, x12]
    e4d8:      	add	x19, x8, x12
    e4dc:      	cmp	w23, w21
    e4e0:      	add	x2, x9, x10
    e4e4:      	and	w1, w11, #0xff
    e4e8:      	mov	w8, #0x4                // =4
    e4ec:      	cinc	x0, x19, hi
    e4f0:      	blr	x8
    e4f4:      	cmp	w23, w21
    e4f8:      	str	x19, [sp, #0x60]
    e4fc:      	add	x19, sp, #0x70
    e500:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e504:      	ldr	x21, [sp, #0x78]
    e508:      	ldp	x2, x24, [sp, #0x50]
    e50c:      	str	x21, [sp, #0x48]
    e510:      	b	0xe560 <generic_rawtp_path+0x5460>
    e514:      	add	x2, x24, #0x10
    e518:      	mov	w8, #0x4                // =4
    e51c:      	add	x9, sp, #0x98
    e520:      	add	x0, sp, #0x98
    e524:      	mov	w1, #0x8                // =8
    e528:      	blr	x8
    e52c:      	ldr	x8, [sp, #0x58]
    e530:      	ldr	x9, [sp, #0x98]
    e534:      	cmp	x8, x9
    e538:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e53c:      	add	x2, x24, #0x18
    e540:      	mov	w8, #0x4                // =4
    e544:      	mov	x0, x22
    e548:      	mov	w1, #0x8                // =8
    e54c:      	blr	x8
    e550:      	ldr	x24, [sp, #0x98]
    e554:      	ldr	x21, [sp, #0x48]
    e558:      	add	x2, x24, #0x20
    e55c:      	stp	x2, x24, [sp, #0x50]
    e560:      	ldr	x8, [sp, #0x30]
    e564:      	cmp	x21, x8
    e568:      	b.ne	0xe578 <generic_rawtp_path+0x5478>
    e56c:      	ldr	x8, [sp, #0x38]
    e570:      	cmp	x2, x8
    e574:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e578:      	mov	w8, #0x4                // =4
    e57c:      	add	x0, sp, #0x70
    e580:      	mov	w1, #0x8                // =8
    e584:      	blr	x8
    e588:      	ldr	x8, [sp, #0x70]
    e58c:      	cmp	x21, x8
    e590:      	b.eq	0xe680 <generic_rawtp_path+0x5580>
    e594:      	add	x23, x21, #0x18
    e598:      	mov	w8, #0x4                // =4
    e59c:      	add	x9, sp, #0x98
    e5a0:      	add	x0, sp, #0x98
    e5a4:      	mov	w1, #0x8                // =8
    e5a8:      	mov	x2, x23
    e5ac:      	blr	x8
    e5b0:      	ldr	x8, [sp, #0x98]
    e5b4:      	cmp	x8, x21
    e5b8:      	b.eq	0xe680 <generic_rawtp_path+0x5580>
    e5bc:      	mov	w8, #0x4                // =4
    e5c0:      	add	x9, sp, #0x78
    e5c4:      	add	x0, sp, #0x78
    e5c8:      	mov	w1, #0x8                // =8
    e5cc:      	mov	x2, x23
    e5d0:      	blr	x8
    e5d4:      	add	x2, x21, #0x20
    e5d8:      	mov	w8, #0x4                // =4
    e5dc:      	mov	w9, #0x10               // =16
    e5e0:      	add	x10, sp, #0x80
    e5e4:      	add	x0, sp, #0x80
    e5e8:      	mov	w1, #0x10               // =16
    e5ec:      	blr	x8
    e5f0:      	ldr	w21, [sp, #0x84]
    e5f4:      	ldr	x8, [sp, #0x40]
    e5f8:      	ldr	x10, [sp, #0x60]
    e5fc:      	sub	x12, x10, x8
    e600:      	ldr	w23, [sp, #0x68]
    e604:      	subs	w10, w21, w23
    e608:      	ldr	x9, [sp, #0x88]
    e60c:      	csel	w10, wzr, w10, lo
    e610:      	cmp	w23, w21
    e614:      	csel	w11, w23, w21, lo
    e618:      	cinc	w13, w11, hi
    e61c:      	sub	w14, w23, w13
    e620:      	subs	x12, x12, x13
    e624:      	str	w14, [sp, #0x68]
    e628:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e62c:      	cmp	x12, #0xfff
    e630:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e634:      	cmp	w23, w21
    e638:      	b.ls	0xe644 <generic_rawtp_path+0x5544>
    e63c:      	mov	w13, #0x2f              // =47
    e640:      	strb	w13, [x8, x12]
    e644:      	add	x19, x8, x12
    e648:      	cmp	w23, w21
    e64c:      	add	x2, x9, x10
    e650:      	and	w1, w11, #0xff
    e654:      	mov	w8, #0x4                // =4
    e658:      	cinc	x0, x19, hi
    e65c:      	blr	x8
    e660:      	cmp	w23, w21
    e664:      	str	x19, [sp, #0x60]
    e668:      	add	x19, sp, #0x70
    e66c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e670:      	ldr	x21, [sp, #0x78]
    e674:      	ldp	x2, x24, [sp, #0x50]
    e678:      	str	x21, [sp, #0x48]
    e67c:      	b	0xe6cc <generic_rawtp_path+0x55cc>
    e680:      	add	x2, x24, #0x10
    e684:      	mov	w8, #0x4                // =4
    e688:      	add	x9, sp, #0x98
    e68c:      	add	x0, sp, #0x98
    e690:      	mov	w1, #0x8                // =8
    e694:      	blr	x8
    e698:      	ldr	x8, [sp, #0x58]
    e69c:      	ldr	x9, [sp, #0x98]
    e6a0:      	cmp	x8, x9
    e6a4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e6a8:      	add	x2, x24, #0x18
    e6ac:      	mov	w8, #0x4                // =4
    e6b0:      	mov	x0, x22
    e6b4:      	mov	w1, #0x8                // =8
    e6b8:      	blr	x8
    e6bc:      	ldr	x24, [sp, #0x98]
    e6c0:      	ldr	x21, [sp, #0x48]
    e6c4:      	add	x2, x24, #0x20
    e6c8:      	stp	x2, x24, [sp, #0x50]
    e6cc:      	ldr	x8, [sp, #0x30]
    e6d0:      	cmp	x21, x8
    e6d4:      	b.ne	0xe6e4 <generic_rawtp_path+0x55e4>
    e6d8:      	ldr	x8, [sp, #0x38]
    e6dc:      	cmp	x2, x8
    e6e0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e6e4:      	mov	w8, #0x4                // =4
    e6e8:      	add	x0, sp, #0x70
    e6ec:      	mov	w1, #0x8                // =8
    e6f0:      	blr	x8
    e6f4:      	ldr	x8, [sp, #0x70]
    e6f8:      	cmp	x21, x8
    e6fc:      	b.eq	0xe7ec <generic_rawtp_path+0x56ec>
    e700:      	add	x23, x21, #0x18
    e704:      	mov	w8, #0x4                // =4
    e708:      	add	x9, sp, #0x98
    e70c:      	add	x0, sp, #0x98
    e710:      	mov	w1, #0x8                // =8
    e714:      	mov	x2, x23
    e718:      	blr	x8
    e71c:      	ldr	x8, [sp, #0x98]
    e720:      	cmp	x8, x21
    e724:      	b.eq	0xe7ec <generic_rawtp_path+0x56ec>
    e728:      	mov	w8, #0x4                // =4
    e72c:      	add	x9, sp, #0x78
    e730:      	add	x0, sp, #0x78
    e734:      	mov	w1, #0x8                // =8
    e738:      	mov	x2, x23
    e73c:      	blr	x8
    e740:      	add	x2, x21, #0x20
    e744:      	mov	w8, #0x4                // =4
    e748:      	mov	w9, #0x10               // =16
    e74c:      	add	x10, sp, #0x80
    e750:      	add	x0, sp, #0x80
    e754:      	mov	w1, #0x10               // =16
    e758:      	blr	x8
    e75c:      	ldr	w21, [sp, #0x84]
    e760:      	ldr	x8, [sp, #0x40]
    e764:      	ldr	x10, [sp, #0x60]
    e768:      	sub	x12, x10, x8
    e76c:      	ldr	w23, [sp, #0x68]
    e770:      	subs	w10, w21, w23
    e774:      	ldr	x9, [sp, #0x88]
    e778:      	csel	w10, wzr, w10, lo
    e77c:      	cmp	w23, w21
    e780:      	csel	w11, w23, w21, lo
    e784:      	cinc	w13, w11, hi
    e788:      	sub	w14, w23, w13
    e78c:      	subs	x12, x12, x13
    e790:      	str	w14, [sp, #0x68]
    e794:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e798:      	cmp	x12, #0xfff
    e79c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e7a0:      	cmp	w23, w21
    e7a4:      	b.ls	0xe7b0 <generic_rawtp_path+0x56b0>
    e7a8:      	mov	w13, #0x2f              // =47
    e7ac:      	strb	w13, [x8, x12]
    e7b0:      	add	x19, x8, x12
    e7b4:      	cmp	w23, w21
    e7b8:      	add	x2, x9, x10
    e7bc:      	and	w1, w11, #0xff
    e7c0:      	mov	w8, #0x4                // =4
    e7c4:      	cinc	x0, x19, hi
    e7c8:      	blr	x8
    e7cc:      	cmp	w23, w21
    e7d0:      	str	x19, [sp, #0x60]
    e7d4:      	add	x19, sp, #0x70
    e7d8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e7dc:      	ldr	x21, [sp, #0x78]
    e7e0:      	ldp	x2, x24, [sp, #0x50]
    e7e4:      	str	x21, [sp, #0x48]
    e7e8:      	b	0xe838 <generic_rawtp_path+0x5738>
    e7ec:      	add	x2, x24, #0x10
    e7f0:      	mov	w8, #0x4                // =4
    e7f4:      	add	x9, sp, #0x98
    e7f8:      	add	x0, sp, #0x98
    e7fc:      	mov	w1, #0x8                // =8
    e800:      	blr	x8
    e804:      	ldr	x8, [sp, #0x58]
    e808:      	ldr	x9, [sp, #0x98]
    e80c:      	cmp	x8, x9
    e810:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e814:      	add	x2, x24, #0x18
    e818:      	mov	w8, #0x4                // =4
    e81c:      	mov	x0, x22
    e820:      	mov	w1, #0x8                // =8
    e824:      	blr	x8
    e828:      	ldr	x24, [sp, #0x98]
    e82c:      	ldr	x21, [sp, #0x48]
    e830:      	add	x2, x24, #0x20
    e834:      	stp	x2, x24, [sp, #0x50]
    e838:      	ldr	x8, [sp, #0x30]
    e83c:      	cmp	x21, x8
    e840:      	b.ne	0xe850 <generic_rawtp_path+0x5750>
    e844:      	ldr	x8, [sp, #0x38]
    e848:      	cmp	x2, x8
    e84c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e850:      	mov	w8, #0x4                // =4
    e854:      	add	x0, sp, #0x70
    e858:      	mov	w1, #0x8                // =8
    e85c:      	blr	x8
    e860:      	ldr	x8, [sp, #0x70]
    e864:      	cmp	x21, x8
    e868:      	b.eq	0xe958 <generic_rawtp_path+0x5858>
    e86c:      	add	x23, x21, #0x18
    e870:      	mov	w8, #0x4                // =4
    e874:      	add	x9, sp, #0x98
    e878:      	add	x0, sp, #0x98
    e87c:      	mov	w1, #0x8                // =8
    e880:      	mov	x2, x23
    e884:      	blr	x8
    e888:      	ldr	x8, [sp, #0x98]
    e88c:      	cmp	x8, x21
    e890:      	b.eq	0xe958 <generic_rawtp_path+0x5858>
    e894:      	mov	w8, #0x4                // =4
    e898:      	add	x9, sp, #0x78
    e89c:      	add	x0, sp, #0x78
    e8a0:      	mov	w1, #0x8                // =8
    e8a4:      	mov	x2, x23
    e8a8:      	blr	x8
    e8ac:      	add	x2, x21, #0x20
    e8b0:      	mov	w8, #0x4                // =4
    e8b4:      	mov	w9, #0x10               // =16
    e8b8:      	add	x10, sp, #0x80
    e8bc:      	add	x0, sp, #0x80
    e8c0:      	mov	w1, #0x10               // =16
    e8c4:      	blr	x8
    e8c8:      	ldr	w21, [sp, #0x84]
    e8cc:      	ldr	x8, [sp, #0x40]
    e8d0:      	ldr	x10, [sp, #0x60]
    e8d4:      	sub	x12, x10, x8
    e8d8:      	ldr	w23, [sp, #0x68]
    e8dc:      	subs	w10, w21, w23
    e8e0:      	ldr	x9, [sp, #0x88]
    e8e4:      	csel	w10, wzr, w10, lo
    e8e8:      	cmp	w23, w21
    e8ec:      	csel	w11, w23, w21, lo
    e8f0:      	cinc	w13, w11, hi
    e8f4:      	sub	w14, w23, w13
    e8f8:      	subs	x12, x12, x13
    e8fc:      	str	w14, [sp, #0x68]
    e900:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    e904:      	cmp	x12, #0xfff
    e908:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    e90c:      	cmp	w23, w21
    e910:      	b.ls	0xe91c <generic_rawtp_path+0x581c>
    e914:      	mov	w13, #0x2f              // =47
    e918:      	strb	w13, [x8, x12]
    e91c:      	add	x19, x8, x12
    e920:      	cmp	w23, w21
    e924:      	add	x2, x9, x10
    e928:      	and	w1, w11, #0xff
    e92c:      	mov	w8, #0x4                // =4
    e930:      	cinc	x0, x19, hi
    e934:      	blr	x8
    e938:      	cmp	w23, w21
    e93c:      	str	x19, [sp, #0x60]
    e940:      	add	x19, sp, #0x70
    e944:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    e948:      	ldr	x21, [sp, #0x78]
    e94c:      	ldp	x2, x24, [sp, #0x50]
    e950:      	str	x21, [sp, #0x48]
    e954:      	b	0xe9a4 <generic_rawtp_path+0x58a4>
    e958:      	add	x2, x24, #0x10
    e95c:      	mov	w8, #0x4                // =4
    e960:      	add	x9, sp, #0x98
    e964:      	add	x0, sp, #0x98
    e968:      	mov	w1, #0x8                // =8
    e96c:      	blr	x8
    e970:      	ldr	x8, [sp, #0x58]
    e974:      	ldr	x9, [sp, #0x98]
    e978:      	cmp	x8, x9
    e97c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e980:      	add	x2, x24, #0x18
    e984:      	mov	w8, #0x4                // =4
    e988:      	mov	x0, x22
    e98c:      	mov	w1, #0x8                // =8
    e990:      	blr	x8
    e994:      	ldr	x24, [sp, #0x98]
    e998:      	ldr	x21, [sp, #0x48]
    e99c:      	add	x2, x24, #0x20
    e9a0:      	stp	x2, x24, [sp, #0x50]
    e9a4:      	ldr	x8, [sp, #0x30]
    e9a8:      	cmp	x21, x8
    e9ac:      	b.ne	0xe9bc <generic_rawtp_path+0x58bc>
    e9b0:      	ldr	x8, [sp, #0x38]
    e9b4:      	cmp	x2, x8
    e9b8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    e9bc:      	mov	w8, #0x4                // =4
    e9c0:      	add	x0, sp, #0x70
    e9c4:      	mov	w1, #0x8                // =8
    e9c8:      	blr	x8
    e9cc:      	ldr	x8, [sp, #0x70]
    e9d0:      	cmp	x21, x8
    e9d4:      	b.eq	0xeac4 <generic_rawtp_path+0x59c4>
    e9d8:      	add	x23, x21, #0x18
    e9dc:      	mov	w8, #0x4                // =4
    e9e0:      	add	x9, sp, #0x98
    e9e4:      	add	x0, sp, #0x98
    e9e8:      	mov	w1, #0x8                // =8
    e9ec:      	mov	x2, x23
    e9f0:      	blr	x8
    e9f4:      	ldr	x8, [sp, #0x98]
    e9f8:      	cmp	x8, x21
    e9fc:      	b.eq	0xeac4 <generic_rawtp_path+0x59c4>
    ea00:      	mov	w8, #0x4                // =4
    ea04:      	add	x9, sp, #0x78
    ea08:      	add	x0, sp, #0x78
    ea0c:      	mov	w1, #0x8                // =8
    ea10:      	mov	x2, x23
    ea14:      	blr	x8
    ea18:      	add	x2, x21, #0x20
    ea1c:      	mov	w8, #0x4                // =4
    ea20:      	mov	w9, #0x10               // =16
    ea24:      	add	x10, sp, #0x80
    ea28:      	add	x0, sp, #0x80
    ea2c:      	mov	w1, #0x10               // =16
    ea30:      	blr	x8
    ea34:      	ldr	w21, [sp, #0x84]
    ea38:      	ldr	x8, [sp, #0x40]
    ea3c:      	ldr	x10, [sp, #0x60]
    ea40:      	sub	x12, x10, x8
    ea44:      	ldr	w23, [sp, #0x68]
    ea48:      	subs	w10, w21, w23
    ea4c:      	ldr	x9, [sp, #0x88]
    ea50:      	csel	w10, wzr, w10, lo
    ea54:      	cmp	w23, w21
    ea58:      	csel	w11, w23, w21, lo
    ea5c:      	cinc	w13, w11, hi
    ea60:      	sub	w14, w23, w13
    ea64:      	subs	x12, x12, x13
    ea68:      	str	w14, [sp, #0x68]
    ea6c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ea70:      	cmp	x12, #0xfff
    ea74:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ea78:      	cmp	w23, w21
    ea7c:      	b.ls	0xea88 <generic_rawtp_path+0x5988>
    ea80:      	mov	w13, #0x2f              // =47
    ea84:      	strb	w13, [x8, x12]
    ea88:      	add	x19, x8, x12
    ea8c:      	cmp	w23, w21
    ea90:      	add	x2, x9, x10
    ea94:      	and	w1, w11, #0xff
    ea98:      	mov	w8, #0x4                // =4
    ea9c:      	cinc	x0, x19, hi
    eaa0:      	blr	x8
    eaa4:      	cmp	w23, w21
    eaa8:      	str	x19, [sp, #0x60]
    eaac:      	add	x19, sp, #0x70
    eab0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    eab4:      	ldr	x21, [sp, #0x78]
    eab8:      	ldp	x2, x24, [sp, #0x50]
    eabc:      	str	x21, [sp, #0x48]
    eac0:      	b	0xeb10 <generic_rawtp_path+0x5a10>
    eac4:      	add	x2, x24, #0x10
    eac8:      	mov	w8, #0x4                // =4
    eacc:      	add	x9, sp, #0x98
    ead0:      	add	x0, sp, #0x98
    ead4:      	mov	w1, #0x8                // =8
    ead8:      	blr	x8
    eadc:      	ldr	x8, [sp, #0x58]
    eae0:      	ldr	x9, [sp, #0x98]
    eae4:      	cmp	x8, x9
    eae8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    eaec:      	add	x2, x24, #0x18
    eaf0:      	mov	w8, #0x4                // =4
    eaf4:      	mov	x0, x22
    eaf8:      	mov	w1, #0x8                // =8
    eafc:      	blr	x8
    eb00:      	ldr	x24, [sp, #0x98]
    eb04:      	ldr	x21, [sp, #0x48]
    eb08:      	add	x2, x24, #0x20
    eb0c:      	stp	x2, x24, [sp, #0x50]
    eb10:      	ldr	x8, [sp, #0x30]
    eb14:      	cmp	x21, x8
    eb18:      	b.ne	0xeb28 <generic_rawtp_path+0x5a28>
    eb1c:      	ldr	x8, [sp, #0x38]
    eb20:      	cmp	x2, x8
    eb24:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    eb28:      	mov	w8, #0x4                // =4
    eb2c:      	add	x0, sp, #0x70
    eb30:      	mov	w1, #0x8                // =8
    eb34:      	blr	x8
    eb38:      	ldr	x8, [sp, #0x70]
    eb3c:      	cmp	x21, x8
    eb40:      	b.eq	0xec30 <generic_rawtp_path+0x5b30>
    eb44:      	add	x23, x21, #0x18
    eb48:      	mov	w8, #0x4                // =4
    eb4c:      	add	x9, sp, #0x98
    eb50:      	add	x0, sp, #0x98
    eb54:      	mov	w1, #0x8                // =8
    eb58:      	mov	x2, x23
    eb5c:      	blr	x8
    eb60:      	ldr	x8, [sp, #0x98]
    eb64:      	cmp	x8, x21
    eb68:      	b.eq	0xec30 <generic_rawtp_path+0x5b30>
    eb6c:      	mov	w8, #0x4                // =4
    eb70:      	add	x9, sp, #0x78
    eb74:      	add	x0, sp, #0x78
    eb78:      	mov	w1, #0x8                // =8
    eb7c:      	mov	x2, x23
    eb80:      	blr	x8
    eb84:      	add	x2, x21, #0x20
    eb88:      	mov	w8, #0x4                // =4
    eb8c:      	mov	w9, #0x10               // =16
    eb90:      	add	x10, sp, #0x80
    eb94:      	add	x0, sp, #0x80
    eb98:      	mov	w1, #0x10               // =16
    eb9c:      	blr	x8
    eba0:      	ldr	w21, [sp, #0x84]
    eba4:      	ldr	x8, [sp, #0x40]
    eba8:      	ldr	x10, [sp, #0x60]
    ebac:      	sub	x12, x10, x8
    ebb0:      	ldr	w23, [sp, #0x68]
    ebb4:      	subs	w10, w21, w23
    ebb8:      	ldr	x9, [sp, #0x88]
    ebbc:      	csel	w10, wzr, w10, lo
    ebc0:      	cmp	w23, w21
    ebc4:      	csel	w11, w23, w21, lo
    ebc8:      	cinc	w13, w11, hi
    ebcc:      	sub	w14, w23, w13
    ebd0:      	subs	x12, x12, x13
    ebd4:      	str	w14, [sp, #0x68]
    ebd8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ebdc:      	cmp	x12, #0xfff
    ebe0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ebe4:      	cmp	w23, w21
    ebe8:      	b.ls	0xebf4 <generic_rawtp_path+0x5af4>
    ebec:      	mov	w13, #0x2f              // =47
    ebf0:      	strb	w13, [x8, x12]
    ebf4:      	add	x19, x8, x12
    ebf8:      	cmp	w23, w21
    ebfc:      	add	x2, x9, x10
    ec00:      	and	w1, w11, #0xff
    ec04:      	mov	w8, #0x4                // =4
    ec08:      	cinc	x0, x19, hi
    ec0c:      	blr	x8
    ec10:      	cmp	w23, w21
    ec14:      	str	x19, [sp, #0x60]
    ec18:      	add	x19, sp, #0x70
    ec1c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ec20:      	ldr	x21, [sp, #0x78]
    ec24:      	ldp	x2, x24, [sp, #0x50]
    ec28:      	str	x21, [sp, #0x48]
    ec2c:      	b	0xec7c <generic_rawtp_path+0x5b7c>
    ec30:      	add	x2, x24, #0x10
    ec34:      	mov	w8, #0x4                // =4
    ec38:      	add	x9, sp, #0x98
    ec3c:      	add	x0, sp, #0x98
    ec40:      	mov	w1, #0x8                // =8
    ec44:      	blr	x8
    ec48:      	ldr	x8, [sp, #0x58]
    ec4c:      	ldr	x9, [sp, #0x98]
    ec50:      	cmp	x8, x9
    ec54:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ec58:      	add	x2, x24, #0x18
    ec5c:      	mov	w8, #0x4                // =4
    ec60:      	mov	x0, x22
    ec64:      	mov	w1, #0x8                // =8
    ec68:      	blr	x8
    ec6c:      	ldr	x24, [sp, #0x98]
    ec70:      	ldr	x21, [sp, #0x48]
    ec74:      	add	x2, x24, #0x20
    ec78:      	stp	x2, x24, [sp, #0x50]
    ec7c:      	ldr	x8, [sp, #0x30]
    ec80:      	cmp	x21, x8
    ec84:      	b.ne	0xec94 <generic_rawtp_path+0x5b94>
    ec88:      	ldr	x8, [sp, #0x38]
    ec8c:      	cmp	x2, x8
    ec90:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ec94:      	mov	w8, #0x4                // =4
    ec98:      	add	x0, sp, #0x70
    ec9c:      	mov	w1, #0x8                // =8
    eca0:      	blr	x8
    eca4:      	ldr	x8, [sp, #0x70]
    eca8:      	cmp	x21, x8
    ecac:      	b.eq	0xed9c <generic_rawtp_path+0x5c9c>
    ecb0:      	add	x23, x21, #0x18
    ecb4:      	mov	w8, #0x4                // =4
    ecb8:      	add	x9, sp, #0x98
    ecbc:      	add	x0, sp, #0x98
    ecc0:      	mov	w1, #0x8                // =8
    ecc4:      	mov	x2, x23
    ecc8:      	blr	x8
    eccc:      	ldr	x8, [sp, #0x98]
    ecd0:      	cmp	x8, x21
    ecd4:      	b.eq	0xed9c <generic_rawtp_path+0x5c9c>
    ecd8:      	mov	w8, #0x4                // =4
    ecdc:      	add	x9, sp, #0x78
    ece0:      	add	x0, sp, #0x78
    ece4:      	mov	w1, #0x8                // =8
    ece8:      	mov	x2, x23
    ecec:      	blr	x8
    ecf0:      	add	x2, x21, #0x20
    ecf4:      	mov	w8, #0x4                // =4
    ecf8:      	mov	w9, #0x10               // =16
    ecfc:      	add	x10, sp, #0x80
    ed00:      	add	x0, sp, #0x80
    ed04:      	mov	w1, #0x10               // =16
    ed08:      	blr	x8
    ed0c:      	ldr	w21, [sp, #0x84]
    ed10:      	ldr	x8, [sp, #0x40]
    ed14:      	ldr	x10, [sp, #0x60]
    ed18:      	sub	x12, x10, x8
    ed1c:      	ldr	w23, [sp, #0x68]
    ed20:      	subs	w10, w21, w23
    ed24:      	ldr	x9, [sp, #0x88]
    ed28:      	csel	w10, wzr, w10, lo
    ed2c:      	cmp	w23, w21
    ed30:      	csel	w11, w23, w21, lo
    ed34:      	cinc	w13, w11, hi
    ed38:      	sub	w14, w23, w13
    ed3c:      	subs	x12, x12, x13
    ed40:      	str	w14, [sp, #0x68]
    ed44:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ed48:      	cmp	x12, #0xfff
    ed4c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ed50:      	cmp	w23, w21
    ed54:      	b.ls	0xed60 <generic_rawtp_path+0x5c60>
    ed58:      	mov	w13, #0x2f              // =47
    ed5c:      	strb	w13, [x8, x12]
    ed60:      	add	x19, x8, x12
    ed64:      	cmp	w23, w21
    ed68:      	add	x2, x9, x10
    ed6c:      	and	w1, w11, #0xff
    ed70:      	mov	w8, #0x4                // =4
    ed74:      	cinc	x0, x19, hi
    ed78:      	blr	x8
    ed7c:      	cmp	w23, w21
    ed80:      	str	x19, [sp, #0x60]
    ed84:      	add	x19, sp, #0x70
    ed88:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    ed8c:      	ldr	x21, [sp, #0x78]
    ed90:      	ldp	x2, x24, [sp, #0x50]
    ed94:      	str	x21, [sp, #0x48]
    ed98:      	b	0xede8 <generic_rawtp_path+0x5ce8>
    ed9c:      	add	x2, x24, #0x10
    eda0:      	mov	w8, #0x4                // =4
    eda4:      	add	x9, sp, #0x98
    eda8:      	add	x0, sp, #0x98
    edac:      	mov	w1, #0x8                // =8
    edb0:      	blr	x8
    edb4:      	ldr	x8, [sp, #0x58]
    edb8:      	ldr	x9, [sp, #0x98]
    edbc:      	cmp	x8, x9
    edc0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    edc4:      	add	x2, x24, #0x18
    edc8:      	mov	w8, #0x4                // =4
    edcc:      	mov	x0, x22
    edd0:      	mov	w1, #0x8                // =8
    edd4:      	blr	x8
    edd8:      	ldr	x24, [sp, #0x98]
    eddc:      	ldr	x21, [sp, #0x48]
    ede0:      	add	x2, x24, #0x20
    ede4:      	stp	x2, x24, [sp, #0x50]
    ede8:      	ldr	x8, [sp, #0x30]
    edec:      	cmp	x21, x8
    edf0:      	b.ne	0xee00 <generic_rawtp_path+0x5d00>
    edf4:      	ldr	x8, [sp, #0x38]
    edf8:      	cmp	x2, x8
    edfc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ee00:      	mov	w8, #0x4                // =4
    ee04:      	add	x0, sp, #0x70
    ee08:      	mov	w1, #0x8                // =8
    ee0c:      	blr	x8
    ee10:      	ldr	x8, [sp, #0x70]
    ee14:      	cmp	x21, x8
    ee18:      	b.eq	0xef08 <generic_rawtp_path+0x5e08>
    ee1c:      	add	x23, x21, #0x18
    ee20:      	mov	w8, #0x4                // =4
    ee24:      	add	x9, sp, #0x98
    ee28:      	add	x0, sp, #0x98
    ee2c:      	mov	w1, #0x8                // =8
    ee30:      	mov	x2, x23
    ee34:      	blr	x8
    ee38:      	ldr	x8, [sp, #0x98]
    ee3c:      	cmp	x8, x21
    ee40:      	b.eq	0xef08 <generic_rawtp_path+0x5e08>
    ee44:      	mov	w8, #0x4                // =4
    ee48:      	add	x9, sp, #0x78
    ee4c:      	add	x0, sp, #0x78
    ee50:      	mov	w1, #0x8                // =8
    ee54:      	mov	x2, x23
    ee58:      	blr	x8
    ee5c:      	add	x2, x21, #0x20
    ee60:      	mov	w8, #0x4                // =4
    ee64:      	mov	w9, #0x10               // =16
    ee68:      	add	x10, sp, #0x80
    ee6c:      	add	x0, sp, #0x80
    ee70:      	mov	w1, #0x10               // =16
    ee74:      	blr	x8
    ee78:      	ldr	w21, [sp, #0x84]
    ee7c:      	ldr	x8, [sp, #0x40]
    ee80:      	ldr	x10, [sp, #0x60]
    ee84:      	sub	x12, x10, x8
    ee88:      	ldr	w23, [sp, #0x68]
    ee8c:      	subs	w10, w21, w23
    ee90:      	ldr	x9, [sp, #0x88]
    ee94:      	csel	w10, wzr, w10, lo
    ee98:      	cmp	w23, w21
    ee9c:      	csel	w11, w23, w21, lo
    eea0:      	cinc	w13, w11, hi
    eea4:      	sub	w14, w23, w13
    eea8:      	subs	x12, x12, x13
    eeac:      	str	w14, [sp, #0x68]
    eeb0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    eeb4:      	cmp	x12, #0xfff
    eeb8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    eebc:      	cmp	w23, w21
    eec0:      	b.ls	0xeecc <generic_rawtp_path+0x5dcc>
    eec4:      	mov	w13, #0x2f              // =47
    eec8:      	strb	w13, [x8, x12]
    eecc:      	add	x19, x8, x12
    eed0:      	cmp	w23, w21
    eed4:      	add	x2, x9, x10
    eed8:      	and	w1, w11, #0xff
    eedc:      	mov	w8, #0x4                // =4
    eee0:      	cinc	x0, x19, hi
    eee4:      	blr	x8
    eee8:      	cmp	w23, w21
    eeec:      	str	x19, [sp, #0x60]
    eef0:      	add	x19, sp, #0x70
    eef4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    eef8:      	ldr	x21, [sp, #0x78]
    eefc:      	ldp	x2, x24, [sp, #0x50]
    ef00:      	str	x21, [sp, #0x48]
    ef04:      	b	0xef54 <generic_rawtp_path+0x5e54>
    ef08:      	add	x2, x24, #0x10
    ef0c:      	mov	w8, #0x4                // =4
    ef10:      	add	x9, sp, #0x98
    ef14:      	add	x0, sp, #0x98
    ef18:      	mov	w1, #0x8                // =8
    ef1c:      	blr	x8
    ef20:      	ldr	x8, [sp, #0x58]
    ef24:      	ldr	x9, [sp, #0x98]
    ef28:      	cmp	x8, x9
    ef2c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ef30:      	add	x2, x24, #0x18
    ef34:      	mov	w8, #0x4                // =4
    ef38:      	mov	x0, x22
    ef3c:      	mov	w1, #0x8                // =8
    ef40:      	blr	x8
    ef44:      	ldr	x24, [sp, #0x98]
    ef48:      	ldr	x21, [sp, #0x48]
    ef4c:      	add	x2, x24, #0x20
    ef50:      	stp	x2, x24, [sp, #0x50]
    ef54:      	ldr	x8, [sp, #0x30]
    ef58:      	cmp	x21, x8
    ef5c:      	b.ne	0xef6c <generic_rawtp_path+0x5e6c>
    ef60:      	ldr	x8, [sp, #0x38]
    ef64:      	cmp	x2, x8
    ef68:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ef6c:      	mov	w8, #0x4                // =4
    ef70:      	add	x0, sp, #0x70
    ef74:      	mov	w1, #0x8                // =8
    ef78:      	blr	x8
    ef7c:      	ldr	x8, [sp, #0x70]
    ef80:      	cmp	x21, x8
    ef84:      	b.eq	0xf074 <generic_rawtp_path+0x5f74>
    ef88:      	add	x23, x21, #0x18
    ef8c:      	mov	w8, #0x4                // =4
    ef90:      	add	x9, sp, #0x98
    ef94:      	add	x0, sp, #0x98
    ef98:      	mov	w1, #0x8                // =8
    ef9c:      	mov	x2, x23
    efa0:      	blr	x8
    efa4:      	ldr	x8, [sp, #0x98]
    efa8:      	cmp	x8, x21
    efac:      	b.eq	0xf074 <generic_rawtp_path+0x5f74>
    efb0:      	mov	w8, #0x4                // =4
    efb4:      	add	x9, sp, #0x78
    efb8:      	add	x0, sp, #0x78
    efbc:      	mov	w1, #0x8                // =8
    efc0:      	mov	x2, x23
    efc4:      	blr	x8
    efc8:      	add	x2, x21, #0x20
    efcc:      	mov	w8, #0x4                // =4
    efd0:      	mov	w9, #0x10               // =16
    efd4:      	add	x10, sp, #0x80
    efd8:      	add	x0, sp, #0x80
    efdc:      	mov	w1, #0x10               // =16
    efe0:      	blr	x8
    efe4:      	ldr	w21, [sp, #0x84]
    efe8:      	ldr	x8, [sp, #0x40]
    efec:      	ldr	x10, [sp, #0x60]
    eff0:      	sub	x12, x10, x8
    eff4:      	ldr	w23, [sp, #0x68]
    eff8:      	subs	w10, w21, w23
    effc:      	ldr	x9, [sp, #0x88]
    f000:      	csel	w10, wzr, w10, lo
    f004:      	cmp	w23, w21
    f008:      	csel	w11, w23, w21, lo
    f00c:      	cinc	w13, w11, hi
    f010:      	sub	w14, w23, w13
    f014:      	subs	x12, x12, x13
    f018:      	str	w14, [sp, #0x68]
    f01c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f020:      	cmp	x12, #0xfff
    f024:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f028:      	cmp	w23, w21
    f02c:      	b.ls	0xf038 <generic_rawtp_path+0x5f38>
    f030:      	mov	w13, #0x2f              // =47
    f034:      	strb	w13, [x8, x12]
    f038:      	add	x19, x8, x12
    f03c:      	cmp	w23, w21
    f040:      	add	x2, x9, x10
    f044:      	and	w1, w11, #0xff
    f048:      	mov	w8, #0x4                // =4
    f04c:      	cinc	x0, x19, hi
    f050:      	blr	x8
    f054:      	cmp	w23, w21
    f058:      	str	x19, [sp, #0x60]
    f05c:      	add	x19, sp, #0x70
    f060:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f064:      	ldr	x21, [sp, #0x78]
    f068:      	ldp	x2, x24, [sp, #0x50]
    f06c:      	str	x21, [sp, #0x48]
    f070:      	b	0xf0c0 <generic_rawtp_path+0x5fc0>
    f074:      	add	x2, x24, #0x10
    f078:      	mov	w8, #0x4                // =4
    f07c:      	add	x9, sp, #0x98
    f080:      	add	x0, sp, #0x98
    f084:      	mov	w1, #0x8                // =8
    f088:      	blr	x8
    f08c:      	ldr	x8, [sp, #0x58]
    f090:      	ldr	x9, [sp, #0x98]
    f094:      	cmp	x8, x9
    f098:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f09c:      	add	x2, x24, #0x18
    f0a0:      	mov	w8, #0x4                // =4
    f0a4:      	mov	x0, x22
    f0a8:      	mov	w1, #0x8                // =8
    f0ac:      	blr	x8
    f0b0:      	ldr	x24, [sp, #0x98]
    f0b4:      	ldr	x21, [sp, #0x48]
    f0b8:      	add	x2, x24, #0x20
    f0bc:      	stp	x2, x24, [sp, #0x50]
    f0c0:      	ldr	x8, [sp, #0x30]
    f0c4:      	cmp	x21, x8
    f0c8:      	b.ne	0xf0d8 <generic_rawtp_path+0x5fd8>
    f0cc:      	ldr	x8, [sp, #0x38]
    f0d0:      	cmp	x2, x8
    f0d4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f0d8:      	mov	w8, #0x4                // =4
    f0dc:      	add	x0, sp, #0x70
    f0e0:      	mov	w1, #0x8                // =8
    f0e4:      	blr	x8
    f0e8:      	ldr	x8, [sp, #0x70]
    f0ec:      	cmp	x21, x8
    f0f0:      	b.eq	0xf1e0 <generic_rawtp_path+0x60e0>
    f0f4:      	add	x23, x21, #0x18
    f0f8:      	mov	w8, #0x4                // =4
    f0fc:      	add	x9, sp, #0x98
    f100:      	add	x0, sp, #0x98
    f104:      	mov	w1, #0x8                // =8
    f108:      	mov	x2, x23
    f10c:      	blr	x8
    f110:      	ldr	x8, [sp, #0x98]
    f114:      	cmp	x8, x21
    f118:      	b.eq	0xf1e0 <generic_rawtp_path+0x60e0>
    f11c:      	mov	w8, #0x4                // =4
    f120:      	add	x9, sp, #0x78
    f124:      	add	x0, sp, #0x78
    f128:      	mov	w1, #0x8                // =8
    f12c:      	mov	x2, x23
    f130:      	blr	x8
    f134:      	add	x2, x21, #0x20
    f138:      	mov	w8, #0x4                // =4
    f13c:      	mov	w9, #0x10               // =16
    f140:      	add	x10, sp, #0x80
    f144:      	add	x0, sp, #0x80
    f148:      	mov	w1, #0x10               // =16
    f14c:      	blr	x8
    f150:      	ldr	w21, [sp, #0x84]
    f154:      	ldr	x8, [sp, #0x40]
    f158:      	ldr	x10, [sp, #0x60]
    f15c:      	sub	x12, x10, x8
    f160:      	ldr	w23, [sp, #0x68]
    f164:      	subs	w10, w21, w23
    f168:      	ldr	x9, [sp, #0x88]
    f16c:      	csel	w10, wzr, w10, lo
    f170:      	cmp	w23, w21
    f174:      	csel	w11, w23, w21, lo
    f178:      	cinc	w13, w11, hi
    f17c:      	sub	w14, w23, w13
    f180:      	subs	x12, x12, x13
    f184:      	str	w14, [sp, #0x68]
    f188:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f18c:      	cmp	x12, #0xfff
    f190:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f194:      	cmp	w23, w21
    f198:      	b.ls	0xf1a4 <generic_rawtp_path+0x60a4>
    f19c:      	mov	w13, #0x2f              // =47
    f1a0:      	strb	w13, [x8, x12]
    f1a4:      	add	x19, x8, x12
    f1a8:      	cmp	w23, w21
    f1ac:      	add	x2, x9, x10
    f1b0:      	and	w1, w11, #0xff
    f1b4:      	mov	w8, #0x4                // =4
    f1b8:      	cinc	x0, x19, hi
    f1bc:      	blr	x8
    f1c0:      	cmp	w23, w21
    f1c4:      	str	x19, [sp, #0x60]
    f1c8:      	add	x19, sp, #0x70
    f1cc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f1d0:      	ldr	x21, [sp, #0x78]
    f1d4:      	ldp	x2, x24, [sp, #0x50]
    f1d8:      	str	x21, [sp, #0x48]
    f1dc:      	b	0xf22c <generic_rawtp_path+0x612c>
    f1e0:      	add	x2, x24, #0x10
    f1e4:      	mov	w8, #0x4                // =4
    f1e8:      	add	x9, sp, #0x98
    f1ec:      	add	x0, sp, #0x98
    f1f0:      	mov	w1, #0x8                // =8
    f1f4:      	blr	x8
    f1f8:      	ldr	x8, [sp, #0x58]
    f1fc:      	ldr	x9, [sp, #0x98]
    f200:      	cmp	x8, x9
    f204:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f208:      	add	x2, x24, #0x18
    f20c:      	mov	w8, #0x4                // =4
    f210:      	mov	x0, x22
    f214:      	mov	w1, #0x8                // =8
    f218:      	blr	x8
    f21c:      	ldr	x24, [sp, #0x98]
    f220:      	ldr	x21, [sp, #0x48]
    f224:      	add	x2, x24, #0x20
    f228:      	stp	x2, x24, [sp, #0x50]
    f22c:      	ldr	x8, [sp, #0x30]
    f230:      	cmp	x21, x8
    f234:      	b.ne	0xf244 <generic_rawtp_path+0x6144>
    f238:      	ldr	x8, [sp, #0x38]
    f23c:      	cmp	x2, x8
    f240:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f244:      	mov	w8, #0x4                // =4
    f248:      	add	x0, sp, #0x70
    f24c:      	mov	w1, #0x8                // =8
    f250:      	blr	x8
    f254:      	ldr	x8, [sp, #0x70]
    f258:      	cmp	x21, x8
    f25c:      	b.eq	0xf34c <generic_rawtp_path+0x624c>
    f260:      	add	x23, x21, #0x18
    f264:      	mov	w8, #0x4                // =4
    f268:      	add	x9, sp, #0x98
    f26c:      	add	x0, sp, #0x98
    f270:      	mov	w1, #0x8                // =8
    f274:      	mov	x2, x23
    f278:      	blr	x8
    f27c:      	ldr	x8, [sp, #0x98]
    f280:      	cmp	x8, x21
    f284:      	b.eq	0xf34c <generic_rawtp_path+0x624c>
    f288:      	mov	w8, #0x4                // =4
    f28c:      	add	x9, sp, #0x78
    f290:      	add	x0, sp, #0x78
    f294:      	mov	w1, #0x8                // =8
    f298:      	mov	x2, x23
    f29c:      	blr	x8
    f2a0:      	add	x2, x21, #0x20
    f2a4:      	mov	w8, #0x4                // =4
    f2a8:      	mov	w9, #0x10               // =16
    f2ac:      	add	x10, sp, #0x80
    f2b0:      	add	x0, sp, #0x80
    f2b4:      	mov	w1, #0x10               // =16
    f2b8:      	blr	x8
    f2bc:      	ldr	w21, [sp, #0x84]
    f2c0:      	ldr	x8, [sp, #0x40]
    f2c4:      	ldr	x10, [sp, #0x60]
    f2c8:      	sub	x12, x10, x8
    f2cc:      	ldr	w23, [sp, #0x68]
    f2d0:      	subs	w10, w21, w23
    f2d4:      	ldr	x9, [sp, #0x88]
    f2d8:      	csel	w10, wzr, w10, lo
    f2dc:      	cmp	w23, w21
    f2e0:      	csel	w11, w23, w21, lo
    f2e4:      	cinc	w13, w11, hi
    f2e8:      	sub	w14, w23, w13
    f2ec:      	subs	x12, x12, x13
    f2f0:      	str	w14, [sp, #0x68]
    f2f4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f2f8:      	cmp	x12, #0xfff
    f2fc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f300:      	cmp	w23, w21
    f304:      	b.ls	0xf310 <generic_rawtp_path+0x6210>
    f308:      	mov	w13, #0x2f              // =47
    f30c:      	strb	w13, [x8, x12]
    f310:      	add	x19, x8, x12
    f314:      	cmp	w23, w21
    f318:      	add	x2, x9, x10
    f31c:      	and	w1, w11, #0xff
    f320:      	mov	w8, #0x4                // =4
    f324:      	cinc	x0, x19, hi
    f328:      	blr	x8
    f32c:      	cmp	w23, w21
    f330:      	str	x19, [sp, #0x60]
    f334:      	add	x19, sp, #0x70
    f338:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f33c:      	ldr	x21, [sp, #0x78]
    f340:      	ldp	x2, x24, [sp, #0x50]
    f344:      	str	x21, [sp, #0x48]
    f348:      	b	0xf398 <generic_rawtp_path+0x6298>
    f34c:      	add	x2, x24, #0x10
    f350:      	mov	w8, #0x4                // =4
    f354:      	add	x9, sp, #0x98
    f358:      	add	x0, sp, #0x98
    f35c:      	mov	w1, #0x8                // =8
    f360:      	blr	x8
    f364:      	ldr	x8, [sp, #0x58]
    f368:      	ldr	x9, [sp, #0x98]
    f36c:      	cmp	x8, x9
    f370:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f374:      	add	x2, x24, #0x18
    f378:      	mov	w8, #0x4                // =4
    f37c:      	mov	x0, x22
    f380:      	mov	w1, #0x8                // =8
    f384:      	blr	x8
    f388:      	ldr	x24, [sp, #0x98]
    f38c:      	ldr	x21, [sp, #0x48]
    f390:      	add	x2, x24, #0x20
    f394:      	stp	x2, x24, [sp, #0x50]
    f398:      	ldr	x8, [sp, #0x30]
    f39c:      	cmp	x21, x8
    f3a0:      	b.ne	0xf3b0 <generic_rawtp_path+0x62b0>
    f3a4:      	ldr	x8, [sp, #0x38]
    f3a8:      	cmp	x2, x8
    f3ac:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f3b0:      	mov	w8, #0x4                // =4
    f3b4:      	add	x0, sp, #0x70
    f3b8:      	mov	w1, #0x8                // =8
    f3bc:      	blr	x8
    f3c0:      	ldr	x8, [sp, #0x70]
    f3c4:      	cmp	x21, x8
    f3c8:      	b.eq	0xf4b8 <generic_rawtp_path+0x63b8>
    f3cc:      	add	x23, x21, #0x18
    f3d0:      	mov	w8, #0x4                // =4
    f3d4:      	add	x9, sp, #0x98
    f3d8:      	add	x0, sp, #0x98
    f3dc:      	mov	w1, #0x8                // =8
    f3e0:      	mov	x2, x23
    f3e4:      	blr	x8
    f3e8:      	ldr	x8, [sp, #0x98]
    f3ec:      	cmp	x8, x21
    f3f0:      	b.eq	0xf4b8 <generic_rawtp_path+0x63b8>
    f3f4:      	mov	w8, #0x4                // =4
    f3f8:      	add	x9, sp, #0x78
    f3fc:      	add	x0, sp, #0x78
    f400:      	mov	w1, #0x8                // =8
    f404:      	mov	x2, x23
    f408:      	blr	x8
    f40c:      	add	x2, x21, #0x20
    f410:      	mov	w8, #0x4                // =4
    f414:      	mov	w9, #0x10               // =16
    f418:      	add	x10, sp, #0x80
    f41c:      	add	x0, sp, #0x80
    f420:      	mov	w1, #0x10               // =16
    f424:      	blr	x8
    f428:      	ldr	w21, [sp, #0x84]
    f42c:      	ldr	x8, [sp, #0x40]
    f430:      	ldr	x10, [sp, #0x60]
    f434:      	sub	x12, x10, x8
    f438:      	ldr	w23, [sp, #0x68]
    f43c:      	subs	w10, w21, w23
    f440:      	ldr	x9, [sp, #0x88]
    f444:      	csel	w10, wzr, w10, lo
    f448:      	cmp	w23, w21
    f44c:      	csel	w11, w23, w21, lo
    f450:      	cinc	w13, w11, hi
    f454:      	sub	w14, w23, w13
    f458:      	subs	x12, x12, x13
    f45c:      	str	w14, [sp, #0x68]
    f460:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f464:      	cmp	x12, #0xfff
    f468:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f46c:      	cmp	w23, w21
    f470:      	b.ls	0xf47c <generic_rawtp_path+0x637c>
    f474:      	mov	w13, #0x2f              // =47
    f478:      	strb	w13, [x8, x12]
    f47c:      	add	x19, x8, x12
    f480:      	cmp	w23, w21
    f484:      	add	x2, x9, x10
    f488:      	and	w1, w11, #0xff
    f48c:      	mov	w8, #0x4                // =4
    f490:      	cinc	x0, x19, hi
    f494:      	blr	x8
    f498:      	cmp	w23, w21
    f49c:      	str	x19, [sp, #0x60]
    f4a0:      	add	x19, sp, #0x70
    f4a4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f4a8:      	ldr	x21, [sp, #0x78]
    f4ac:      	ldp	x2, x24, [sp, #0x50]
    f4b0:      	str	x21, [sp, #0x48]
    f4b4:      	b	0xf504 <generic_rawtp_path+0x6404>
    f4b8:      	add	x2, x24, #0x10
    f4bc:      	mov	w8, #0x4                // =4
    f4c0:      	add	x9, sp, #0x98
    f4c4:      	add	x0, sp, #0x98
    f4c8:      	mov	w1, #0x8                // =8
    f4cc:      	blr	x8
    f4d0:      	ldr	x8, [sp, #0x58]
    f4d4:      	ldr	x9, [sp, #0x98]
    f4d8:      	cmp	x8, x9
    f4dc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f4e0:      	add	x2, x24, #0x18
    f4e4:      	mov	w8, #0x4                // =4
    f4e8:      	mov	x0, x22
    f4ec:      	mov	w1, #0x8                // =8
    f4f0:      	blr	x8
    f4f4:      	ldr	x24, [sp, #0x98]
    f4f8:      	ldr	x21, [sp, #0x48]
    f4fc:      	add	x2, x24, #0x20
    f500:      	stp	x2, x24, [sp, #0x50]
    f504:      	ldr	x8, [sp, #0x30]
    f508:      	cmp	x21, x8
    f50c:      	b.ne	0xf51c <generic_rawtp_path+0x641c>
    f510:      	ldr	x8, [sp, #0x38]
    f514:      	cmp	x2, x8
    f518:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f51c:      	mov	w8, #0x4                // =4
    f520:      	add	x0, sp, #0x70
    f524:      	mov	w1, #0x8                // =8
    f528:      	blr	x8
    f52c:      	ldr	x8, [sp, #0x70]
    f530:      	cmp	x21, x8
    f534:      	b.eq	0xf624 <generic_rawtp_path+0x6524>
    f538:      	add	x23, x21, #0x18
    f53c:      	mov	w8, #0x4                // =4
    f540:      	add	x9, sp, #0x98
    f544:      	add	x0, sp, #0x98
    f548:      	mov	w1, #0x8                // =8
    f54c:      	mov	x2, x23
    f550:      	blr	x8
    f554:      	ldr	x8, [sp, #0x98]
    f558:      	cmp	x8, x21
    f55c:      	b.eq	0xf624 <generic_rawtp_path+0x6524>
    f560:      	mov	w8, #0x4                // =4
    f564:      	add	x9, sp, #0x78
    f568:      	add	x0, sp, #0x78
    f56c:      	mov	w1, #0x8                // =8
    f570:      	mov	x2, x23
    f574:      	blr	x8
    f578:      	add	x2, x21, #0x20
    f57c:      	mov	w8, #0x4                // =4
    f580:      	mov	w9, #0x10               // =16
    f584:      	add	x10, sp, #0x80
    f588:      	add	x0, sp, #0x80
    f58c:      	mov	w1, #0x10               // =16
    f590:      	blr	x8
    f594:      	ldr	w21, [sp, #0x84]
    f598:      	ldr	x8, [sp, #0x40]
    f59c:      	ldr	x10, [sp, #0x60]
    f5a0:      	sub	x12, x10, x8
    f5a4:      	ldr	w23, [sp, #0x68]
    f5a8:      	subs	w10, w21, w23
    f5ac:      	ldr	x9, [sp, #0x88]
    f5b0:      	csel	w10, wzr, w10, lo
    f5b4:      	cmp	w23, w21
    f5b8:      	csel	w11, w23, w21, lo
    f5bc:      	cinc	w13, w11, hi
    f5c0:      	sub	w14, w23, w13
    f5c4:      	subs	x12, x12, x13
    f5c8:      	str	w14, [sp, #0x68]
    f5cc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f5d0:      	cmp	x12, #0xfff
    f5d4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f5d8:      	cmp	w23, w21
    f5dc:      	b.ls	0xf5e8 <generic_rawtp_path+0x64e8>
    f5e0:      	mov	w13, #0x2f              // =47
    f5e4:      	strb	w13, [x8, x12]
    f5e8:      	add	x19, x8, x12
    f5ec:      	cmp	w23, w21
    f5f0:      	add	x2, x9, x10
    f5f4:      	and	w1, w11, #0xff
    f5f8:      	mov	w8, #0x4                // =4
    f5fc:      	cinc	x0, x19, hi
    f600:      	blr	x8
    f604:      	cmp	w23, w21
    f608:      	str	x19, [sp, #0x60]
    f60c:      	add	x19, sp, #0x70
    f610:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f614:      	ldr	x21, [sp, #0x78]
    f618:      	ldp	x2, x24, [sp, #0x50]
    f61c:      	str	x21, [sp, #0x48]
    f620:      	b	0xf670 <generic_rawtp_path+0x6570>
    f624:      	add	x2, x24, #0x10
    f628:      	mov	w8, #0x4                // =4
    f62c:      	add	x9, sp, #0x98
    f630:      	add	x0, sp, #0x98
    f634:      	mov	w1, #0x8                // =8
    f638:      	blr	x8
    f63c:      	ldr	x8, [sp, #0x58]
    f640:      	ldr	x9, [sp, #0x98]
    f644:      	cmp	x8, x9
    f648:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f64c:      	add	x2, x24, #0x18
    f650:      	mov	w8, #0x4                // =4
    f654:      	mov	x0, x22
    f658:      	mov	w1, #0x8                // =8
    f65c:      	blr	x8
    f660:      	ldr	x24, [sp, #0x98]
    f664:      	ldr	x21, [sp, #0x48]
    f668:      	add	x2, x24, #0x20
    f66c:      	stp	x2, x24, [sp, #0x50]
    f670:      	ldr	x8, [sp, #0x30]
    f674:      	cmp	x21, x8
    f678:      	b.ne	0xf688 <generic_rawtp_path+0x6588>
    f67c:      	ldr	x8, [sp, #0x38]
    f680:      	cmp	x2, x8
    f684:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f688:      	mov	w8, #0x4                // =4
    f68c:      	add	x0, sp, #0x70
    f690:      	mov	w1, #0x8                // =8
    f694:      	blr	x8
    f698:      	ldr	x8, [sp, #0x70]
    f69c:      	cmp	x21, x8
    f6a0:      	b.eq	0xf790 <generic_rawtp_path+0x6690>
    f6a4:      	add	x23, x21, #0x18
    f6a8:      	mov	w8, #0x4                // =4
    f6ac:      	add	x9, sp, #0x98
    f6b0:      	add	x0, sp, #0x98
    f6b4:      	mov	w1, #0x8                // =8
    f6b8:      	mov	x2, x23
    f6bc:      	blr	x8
    f6c0:      	ldr	x8, [sp, #0x98]
    f6c4:      	cmp	x8, x21
    f6c8:      	b.eq	0xf790 <generic_rawtp_path+0x6690>
    f6cc:      	mov	w8, #0x4                // =4
    f6d0:      	add	x9, sp, #0x78
    f6d4:      	add	x0, sp, #0x78
    f6d8:      	mov	w1, #0x8                // =8
    f6dc:      	mov	x2, x23
    f6e0:      	blr	x8
    f6e4:      	add	x2, x21, #0x20
    f6e8:      	mov	w8, #0x4                // =4
    f6ec:      	mov	w9, #0x10               // =16
    f6f0:      	add	x10, sp, #0x80
    f6f4:      	add	x0, sp, #0x80
    f6f8:      	mov	w1, #0x10               // =16
    f6fc:      	blr	x8
    f700:      	ldr	w21, [sp, #0x84]
    f704:      	ldr	x8, [sp, #0x40]
    f708:      	ldr	x10, [sp, #0x60]
    f70c:      	sub	x12, x10, x8
    f710:      	ldr	w23, [sp, #0x68]
    f714:      	subs	w10, w21, w23
    f718:      	ldr	x9, [sp, #0x88]
    f71c:      	csel	w10, wzr, w10, lo
    f720:      	cmp	w23, w21
    f724:      	csel	w11, w23, w21, lo
    f728:      	cinc	w13, w11, hi
    f72c:      	sub	w14, w23, w13
    f730:      	subs	x12, x12, x13
    f734:      	str	w14, [sp, #0x68]
    f738:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f73c:      	cmp	x12, #0xfff
    f740:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f744:      	cmp	w23, w21
    f748:      	b.ls	0xf754 <generic_rawtp_path+0x6654>
    f74c:      	mov	w13, #0x2f              // =47
    f750:      	strb	w13, [x8, x12]
    f754:      	add	x19, x8, x12
    f758:      	cmp	w23, w21
    f75c:      	add	x2, x9, x10
    f760:      	and	w1, w11, #0xff
    f764:      	mov	w8, #0x4                // =4
    f768:      	cinc	x0, x19, hi
    f76c:      	blr	x8
    f770:      	cmp	w23, w21
    f774:      	str	x19, [sp, #0x60]
    f778:      	add	x19, sp, #0x70
    f77c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f780:      	ldr	x21, [sp, #0x78]
    f784:      	ldp	x2, x24, [sp, #0x50]
    f788:      	str	x21, [sp, #0x48]
    f78c:      	b	0xf7dc <generic_rawtp_path+0x66dc>
    f790:      	add	x2, x24, #0x10
    f794:      	mov	w8, #0x4                // =4
    f798:      	add	x9, sp, #0x98
    f79c:      	add	x0, sp, #0x98
    f7a0:      	mov	w1, #0x8                // =8
    f7a4:      	blr	x8
    f7a8:      	ldr	x8, [sp, #0x58]
    f7ac:      	ldr	x9, [sp, #0x98]
    f7b0:      	cmp	x8, x9
    f7b4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f7b8:      	add	x2, x24, #0x18
    f7bc:      	mov	w8, #0x4                // =4
    f7c0:      	mov	x0, x22
    f7c4:      	mov	w1, #0x8                // =8
    f7c8:      	blr	x8
    f7cc:      	ldr	x24, [sp, #0x98]
    f7d0:      	ldr	x21, [sp, #0x48]
    f7d4:      	add	x2, x24, #0x20
    f7d8:      	stp	x2, x24, [sp, #0x50]
    f7dc:      	ldr	x8, [sp, #0x30]
    f7e0:      	cmp	x21, x8
    f7e4:      	b.ne	0xf7f4 <generic_rawtp_path+0x66f4>
    f7e8:      	ldr	x8, [sp, #0x38]
    f7ec:      	cmp	x2, x8
    f7f0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f7f4:      	mov	w8, #0x4                // =4
    f7f8:      	add	x0, sp, #0x70
    f7fc:      	mov	w1, #0x8                // =8
    f800:      	blr	x8
    f804:      	ldr	x8, [sp, #0x70]
    f808:      	cmp	x21, x8
    f80c:      	b.eq	0xf8fc <generic_rawtp_path+0x67fc>
    f810:      	add	x23, x21, #0x18
    f814:      	mov	w8, #0x4                // =4
    f818:      	add	x9, sp, #0x98
    f81c:      	add	x0, sp, #0x98
    f820:      	mov	w1, #0x8                // =8
    f824:      	mov	x2, x23
    f828:      	blr	x8
    f82c:      	ldr	x8, [sp, #0x98]
    f830:      	cmp	x8, x21
    f834:      	b.eq	0xf8fc <generic_rawtp_path+0x67fc>
    f838:      	mov	w8, #0x4                // =4
    f83c:      	add	x9, sp, #0x78
    f840:      	add	x0, sp, #0x78
    f844:      	mov	w1, #0x8                // =8
    f848:      	mov	x2, x23
    f84c:      	blr	x8
    f850:      	add	x2, x21, #0x20
    f854:      	mov	w8, #0x4                // =4
    f858:      	mov	w9, #0x10               // =16
    f85c:      	add	x10, sp, #0x80
    f860:      	add	x0, sp, #0x80
    f864:      	mov	w1, #0x10               // =16
    f868:      	blr	x8
    f86c:      	ldr	w21, [sp, #0x84]
    f870:      	ldr	x8, [sp, #0x40]
    f874:      	ldr	x10, [sp, #0x60]
    f878:      	sub	x12, x10, x8
    f87c:      	ldr	w23, [sp, #0x68]
    f880:      	subs	w10, w21, w23
    f884:      	ldr	x9, [sp, #0x88]
    f888:      	csel	w10, wzr, w10, lo
    f88c:      	cmp	w23, w21
    f890:      	csel	w11, w23, w21, lo
    f894:      	cinc	w13, w11, hi
    f898:      	sub	w14, w23, w13
    f89c:      	subs	x12, x12, x13
    f8a0:      	str	w14, [sp, #0x68]
    f8a4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    f8a8:      	cmp	x12, #0xfff
    f8ac:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    f8b0:      	cmp	w23, w21
    f8b4:      	b.ls	0xf8c0 <generic_rawtp_path+0x67c0>
    f8b8:      	mov	w13, #0x2f              // =47
    f8bc:      	strb	w13, [x8, x12]
    f8c0:      	add	x19, x8, x12
    f8c4:      	cmp	w23, w21
    f8c8:      	add	x2, x9, x10
    f8cc:      	and	w1, w11, #0xff
    f8d0:      	mov	w8, #0x4                // =4
    f8d4:      	cinc	x0, x19, hi
    f8d8:      	blr	x8
    f8dc:      	cmp	w23, w21
    f8e0:      	str	x19, [sp, #0x60]
    f8e4:      	add	x19, sp, #0x70
    f8e8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    f8ec:      	ldr	x21, [sp, #0x78]
    f8f0:      	ldp	x2, x24, [sp, #0x50]
    f8f4:      	str	x21, [sp, #0x48]
    f8f8:      	b	0xf948 <generic_rawtp_path+0x6848>
    f8fc:      	add	x2, x24, #0x10
    f900:      	mov	w8, #0x4                // =4
    f904:      	add	x9, sp, #0x98
    f908:      	add	x0, sp, #0x98
    f90c:      	mov	w1, #0x8                // =8
    f910:      	blr	x8
    f914:      	ldr	x8, [sp, #0x58]
    f918:      	ldr	x9, [sp, #0x98]
    f91c:      	cmp	x8, x9
    f920:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f924:      	add	x2, x24, #0x18
    f928:      	mov	w8, #0x4                // =4
    f92c:      	mov	x0, x22
    f930:      	mov	w1, #0x8                // =8
    f934:      	blr	x8
    f938:      	ldr	x24, [sp, #0x98]
    f93c:      	ldr	x21, [sp, #0x48]
    f940:      	add	x2, x24, #0x20
    f944:      	stp	x2, x24, [sp, #0x50]
    f948:      	ldr	x8, [sp, #0x30]
    f94c:      	cmp	x21, x8
    f950:      	b.ne	0xf960 <generic_rawtp_path+0x6860>
    f954:      	ldr	x8, [sp, #0x38]
    f958:      	cmp	x2, x8
    f95c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    f960:      	mov	w8, #0x4                // =4
    f964:      	add	x0, sp, #0x70
    f968:      	mov	w1, #0x8                // =8
    f96c:      	blr	x8
    f970:      	ldr	x8, [sp, #0x70]
    f974:      	cmp	x21, x8
    f978:      	b.eq	0xfa68 <generic_rawtp_path+0x6968>
    f97c:      	add	x23, x21, #0x18
    f980:      	mov	w8, #0x4                // =4
    f984:      	add	x9, sp, #0x98
    f988:      	add	x0, sp, #0x98
    f98c:      	mov	w1, #0x8                // =8
    f990:      	mov	x2, x23
    f994:      	blr	x8
    f998:      	ldr	x8, [sp, #0x98]
    f99c:      	cmp	x8, x21
    f9a0:      	b.eq	0xfa68 <generic_rawtp_path+0x6968>
    f9a4:      	mov	w8, #0x4                // =4
    f9a8:      	add	x9, sp, #0x78
    f9ac:      	add	x0, sp, #0x78
    f9b0:      	mov	w1, #0x8                // =8
    f9b4:      	mov	x2, x23
    f9b8:      	blr	x8
    f9bc:      	add	x2, x21, #0x20
    f9c0:      	mov	w8, #0x4                // =4
    f9c4:      	mov	w9, #0x10               // =16
    f9c8:      	add	x10, sp, #0x80
    f9cc:      	add	x0, sp, #0x80
    f9d0:      	mov	w1, #0x10               // =16
    f9d4:      	blr	x8
    f9d8:      	ldr	w21, [sp, #0x84]
    f9dc:      	ldr	x8, [sp, #0x40]
    f9e0:      	ldr	x10, [sp, #0x60]
    f9e4:      	sub	x12, x10, x8
    f9e8:      	ldr	w23, [sp, #0x68]
    f9ec:      	subs	w10, w21, w23
    f9f0:      	ldr	x9, [sp, #0x88]
    f9f4:      	csel	w10, wzr, w10, lo
    f9f8:      	cmp	w23, w21
    f9fc:      	csel	w11, w23, w21, lo
    fa00:      	cinc	w13, w11, hi
    fa04:      	sub	w14, w23, w13
    fa08:      	subs	x12, x12, x13
    fa0c:      	str	w14, [sp, #0x68]
    fa10:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    fa14:      	cmp	x12, #0xfff
    fa18:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    fa1c:      	cmp	w23, w21
    fa20:      	b.ls	0xfa2c <generic_rawtp_path+0x692c>
    fa24:      	mov	w13, #0x2f              // =47
    fa28:      	strb	w13, [x8, x12]
    fa2c:      	add	x19, x8, x12
    fa30:      	cmp	w23, w21
    fa34:      	add	x2, x9, x10
    fa38:      	and	w1, w11, #0xff
    fa3c:      	mov	w8, #0x4                // =4
    fa40:      	cinc	x0, x19, hi
    fa44:      	blr	x8
    fa48:      	cmp	w23, w21
    fa4c:      	str	x19, [sp, #0x60]
    fa50:      	add	x19, sp, #0x70
    fa54:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    fa58:      	ldr	x21, [sp, #0x78]
    fa5c:      	ldp	x2, x24, [sp, #0x50]
    fa60:      	str	x21, [sp, #0x48]
    fa64:      	b	0xfab4 <generic_rawtp_path+0x69b4>
    fa68:      	add	x2, x24, #0x10
    fa6c:      	mov	w8, #0x4                // =4
    fa70:      	add	x9, sp, #0x98
    fa74:      	add	x0, sp, #0x98
    fa78:      	mov	w1, #0x8                // =8
    fa7c:      	blr	x8
    fa80:      	ldr	x8, [sp, #0x58]
    fa84:      	ldr	x9, [sp, #0x98]
    fa88:      	cmp	x8, x9
    fa8c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    fa90:      	add	x2, x24, #0x18
    fa94:      	mov	w8, #0x4                // =4
    fa98:      	mov	x0, x22
    fa9c:      	mov	w1, #0x8                // =8
    faa0:      	blr	x8
    faa4:      	ldr	x24, [sp, #0x98]
    faa8:      	ldr	x21, [sp, #0x48]
    faac:      	add	x2, x24, #0x20
    fab0:      	stp	x2, x24, [sp, #0x50]
    fab4:      	ldr	x8, [sp, #0x30]
    fab8:      	cmp	x21, x8
    fabc:      	b.ne	0xfacc <generic_rawtp_path+0x69cc>
    fac0:      	ldr	x8, [sp, #0x38]
    fac4:      	cmp	x2, x8
    fac8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    facc:      	mov	w8, #0x4                // =4
    fad0:      	add	x0, sp, #0x70
    fad4:      	mov	w1, #0x8                // =8
    fad8:      	blr	x8
    fadc:      	ldr	x8, [sp, #0x70]
    fae0:      	cmp	x21, x8
    fae4:      	b.eq	0xfbd4 <generic_rawtp_path+0x6ad4>
    fae8:      	add	x23, x21, #0x18
    faec:      	mov	w8, #0x4                // =4
    faf0:      	add	x9, sp, #0x98
    faf4:      	add	x0, sp, #0x98
    faf8:      	mov	w1, #0x8                // =8
    fafc:      	mov	x2, x23
    fb00:      	blr	x8
    fb04:      	ldr	x8, [sp, #0x98]
    fb08:      	cmp	x8, x21
    fb0c:      	b.eq	0xfbd4 <generic_rawtp_path+0x6ad4>
    fb10:      	mov	w8, #0x4                // =4
    fb14:      	add	x9, sp, #0x78
    fb18:      	add	x0, sp, #0x78
    fb1c:      	mov	w1, #0x8                // =8
    fb20:      	mov	x2, x23
    fb24:      	blr	x8
    fb28:      	add	x2, x21, #0x20
    fb2c:      	mov	w8, #0x4                // =4
    fb30:      	mov	w9, #0x10               // =16
    fb34:      	add	x10, sp, #0x80
    fb38:      	add	x0, sp, #0x80
    fb3c:      	mov	w1, #0x10               // =16
    fb40:      	blr	x8
    fb44:      	ldr	w21, [sp, #0x84]
    fb48:      	ldr	x8, [sp, #0x40]
    fb4c:      	ldr	x10, [sp, #0x60]
    fb50:      	sub	x12, x10, x8
    fb54:      	ldr	w23, [sp, #0x68]
    fb58:      	subs	w10, w21, w23
    fb5c:      	ldr	x9, [sp, #0x88]
    fb60:      	csel	w10, wzr, w10, lo
    fb64:      	cmp	w23, w21
    fb68:      	csel	w11, w23, w21, lo
    fb6c:      	cinc	w13, w11, hi
    fb70:      	sub	w14, w23, w13
    fb74:      	subs	x12, x12, x13
    fb78:      	str	w14, [sp, #0x68]
    fb7c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    fb80:      	cmp	x12, #0xfff
    fb84:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    fb88:      	cmp	w23, w21
    fb8c:      	b.ls	0xfb98 <generic_rawtp_path+0x6a98>
    fb90:      	mov	w13, #0x2f              // =47
    fb94:      	strb	w13, [x8, x12]
    fb98:      	add	x19, x8, x12
    fb9c:      	cmp	w23, w21
    fba0:      	add	x2, x9, x10
    fba4:      	and	w1, w11, #0xff
    fba8:      	mov	w8, #0x4                // =4
    fbac:      	cinc	x0, x19, hi
    fbb0:      	blr	x8
    fbb4:      	cmp	w23, w21
    fbb8:      	str	x19, [sp, #0x60]
    fbbc:      	add	x19, sp, #0x70
    fbc0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    fbc4:      	ldr	x21, [sp, #0x78]
    fbc8:      	ldp	x2, x24, [sp, #0x50]
    fbcc:      	str	x21, [sp, #0x48]
    fbd0:      	b	0xfc20 <generic_rawtp_path+0x6b20>
    fbd4:      	add	x2, x24, #0x10
    fbd8:      	mov	w8, #0x4                // =4
    fbdc:      	add	x9, sp, #0x98
    fbe0:      	add	x0, sp, #0x98
    fbe4:      	mov	w1, #0x8                // =8
    fbe8:      	blr	x8
    fbec:      	ldr	x8, [sp, #0x58]
    fbf0:      	ldr	x9, [sp, #0x98]
    fbf4:      	cmp	x8, x9
    fbf8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    fbfc:      	add	x2, x24, #0x18
    fc00:      	mov	w8, #0x4                // =4
    fc04:      	mov	x0, x22
    fc08:      	mov	w1, #0x8                // =8
    fc0c:      	blr	x8
    fc10:      	ldr	x24, [sp, #0x98]
    fc14:      	ldr	x21, [sp, #0x48]
    fc18:      	add	x2, x24, #0x20
    fc1c:      	stp	x2, x24, [sp, #0x50]
    fc20:      	ldr	x8, [sp, #0x30]
    fc24:      	cmp	x21, x8
    fc28:      	b.ne	0xfc38 <generic_rawtp_path+0x6b38>
    fc2c:      	ldr	x8, [sp, #0x38]
    fc30:      	cmp	x2, x8
    fc34:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    fc38:      	mov	w8, #0x4                // =4
    fc3c:      	add	x0, sp, #0x70
    fc40:      	mov	w1, #0x8                // =8
    fc44:      	blr	x8
    fc48:      	ldr	x8, [sp, #0x70]
    fc4c:      	cmp	x21, x8
    fc50:      	b.eq	0xfd40 <generic_rawtp_path+0x6c40>
    fc54:      	add	x23, x21, #0x18
    fc58:      	mov	w8, #0x4                // =4
    fc5c:      	add	x9, sp, #0x98
    fc60:      	add	x0, sp, #0x98
    fc64:      	mov	w1, #0x8                // =8
    fc68:      	mov	x2, x23
    fc6c:      	blr	x8
    fc70:      	ldr	x8, [sp, #0x98]
    fc74:      	cmp	x8, x21
    fc78:      	b.eq	0xfd40 <generic_rawtp_path+0x6c40>
    fc7c:      	mov	w8, #0x4                // =4
    fc80:      	add	x9, sp, #0x78
    fc84:      	add	x0, sp, #0x78
    fc88:      	mov	w1, #0x8                // =8
    fc8c:      	mov	x2, x23
    fc90:      	blr	x8
    fc94:      	add	x2, x21, #0x20
    fc98:      	mov	w8, #0x4                // =4
    fc9c:      	mov	w9, #0x10               // =16
    fca0:      	add	x10, sp, #0x80
    fca4:      	add	x0, sp, #0x80
    fca8:      	mov	w1, #0x10               // =16
    fcac:      	blr	x8
    fcb0:      	ldr	w21, [sp, #0x84]
    fcb4:      	ldr	x8, [sp, #0x40]
    fcb8:      	ldr	x10, [sp, #0x60]
    fcbc:      	sub	x12, x10, x8
    fcc0:      	ldr	w23, [sp, #0x68]
    fcc4:      	subs	w10, w21, w23
    fcc8:      	ldr	x9, [sp, #0x88]
    fccc:      	csel	w10, wzr, w10, lo
    fcd0:      	cmp	w23, w21
    fcd4:      	csel	w11, w23, w21, lo
    fcd8:      	cinc	w13, w11, hi
    fcdc:      	sub	w14, w23, w13
    fce0:      	subs	x12, x12, x13
    fce4:      	str	w14, [sp, #0x68]
    fce8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    fcec:      	cmp	x12, #0xfff
    fcf0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    fcf4:      	cmp	w23, w21
    fcf8:      	b.ls	0xfd04 <generic_rawtp_path+0x6c04>
    fcfc:      	mov	w13, #0x2f              // =47
    fd00:      	strb	w13, [x8, x12]
    fd04:      	add	x19, x8, x12
    fd08:      	cmp	w23, w21
    fd0c:      	add	x2, x9, x10
    fd10:      	and	w1, w11, #0xff
    fd14:      	mov	w8, #0x4                // =4
    fd18:      	cinc	x0, x19, hi
    fd1c:      	blr	x8
    fd20:      	cmp	w23, w21
    fd24:      	str	x19, [sp, #0x60]
    fd28:      	add	x19, sp, #0x70
    fd2c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    fd30:      	ldr	x21, [sp, #0x78]
    fd34:      	ldp	x2, x24, [sp, #0x50]
    fd38:      	str	x21, [sp, #0x48]
    fd3c:      	b	0xfd8c <generic_rawtp_path+0x6c8c>
    fd40:      	add	x2, x24, #0x10
    fd44:      	mov	w8, #0x4                // =4
    fd48:      	add	x9, sp, #0x98
    fd4c:      	add	x0, sp, #0x98
    fd50:      	mov	w1, #0x8                // =8
    fd54:      	blr	x8
    fd58:      	ldr	x8, [sp, #0x58]
    fd5c:      	ldr	x9, [sp, #0x98]
    fd60:      	cmp	x8, x9
    fd64:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    fd68:      	add	x2, x24, #0x18
    fd6c:      	mov	w8, #0x4                // =4
    fd70:      	mov	x0, x22
    fd74:      	mov	w1, #0x8                // =8
    fd78:      	blr	x8
    fd7c:      	ldr	x24, [sp, #0x98]
    fd80:      	ldr	x21, [sp, #0x48]
    fd84:      	add	x2, x24, #0x20
    fd88:      	stp	x2, x24, [sp, #0x50]
    fd8c:      	ldr	x8, [sp, #0x30]
    fd90:      	cmp	x21, x8
    fd94:      	b.ne	0xfda4 <generic_rawtp_path+0x6ca4>
    fd98:      	ldr	x8, [sp, #0x38]
    fd9c:      	cmp	x2, x8
    fda0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    fda4:      	mov	w8, #0x4                // =4
    fda8:      	add	x0, sp, #0x70
    fdac:      	mov	w1, #0x8                // =8
    fdb0:      	blr	x8
    fdb4:      	ldr	x8, [sp, #0x70]
    fdb8:      	cmp	x21, x8
    fdbc:      	b.eq	0xfeac <generic_rawtp_path+0x6dac>
    fdc0:      	add	x23, x21, #0x18
    fdc4:      	mov	w8, #0x4                // =4
    fdc8:      	add	x9, sp, #0x98
    fdcc:      	add	x0, sp, #0x98
    fdd0:      	mov	w1, #0x8                // =8
    fdd4:      	mov	x2, x23
    fdd8:      	blr	x8
    fddc:      	ldr	x8, [sp, #0x98]
    fde0:      	cmp	x8, x21
    fde4:      	b.eq	0xfeac <generic_rawtp_path+0x6dac>
    fde8:      	mov	w8, #0x4                // =4
    fdec:      	add	x9, sp, #0x78
    fdf0:      	add	x0, sp, #0x78
    fdf4:      	mov	w1, #0x8                // =8
    fdf8:      	mov	x2, x23
    fdfc:      	blr	x8
    fe00:      	add	x2, x21, #0x20
    fe04:      	mov	w8, #0x4                // =4
    fe08:      	mov	w9, #0x10               // =16
    fe0c:      	add	x10, sp, #0x80
    fe10:      	add	x0, sp, #0x80
    fe14:      	mov	w1, #0x10               // =16
    fe18:      	blr	x8
    fe1c:      	ldr	w21, [sp, #0x84]
    fe20:      	ldr	x8, [sp, #0x40]
    fe24:      	ldr	x10, [sp, #0x60]
    fe28:      	sub	x12, x10, x8
    fe2c:      	ldr	w23, [sp, #0x68]
    fe30:      	subs	w10, w21, w23
    fe34:      	ldr	x9, [sp, #0x88]
    fe38:      	csel	w10, wzr, w10, lo
    fe3c:      	cmp	w23, w21
    fe40:      	csel	w11, w23, w21, lo
    fe44:      	cinc	w13, w11, hi
    fe48:      	sub	w14, w23, w13
    fe4c:      	subs	x12, x12, x13
    fe50:      	str	w14, [sp, #0x68]
    fe54:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    fe58:      	cmp	x12, #0xfff
    fe5c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    fe60:      	cmp	w23, w21
    fe64:      	b.ls	0xfe70 <generic_rawtp_path+0x6d70>
    fe68:      	mov	w13, #0x2f              // =47
    fe6c:      	strb	w13, [x8, x12]
    fe70:      	add	x19, x8, x12
    fe74:      	cmp	w23, w21
    fe78:      	add	x2, x9, x10
    fe7c:      	and	w1, w11, #0xff
    fe80:      	mov	w8, #0x4                // =4
    fe84:      	cinc	x0, x19, hi
    fe88:      	blr	x8
    fe8c:      	cmp	w23, w21
    fe90:      	str	x19, [sp, #0x60]
    fe94:      	add	x19, sp, #0x70
    fe98:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
    fe9c:      	ldr	x21, [sp, #0x78]
    fea0:      	ldp	x2, x24, [sp, #0x50]
    fea4:      	str	x21, [sp, #0x48]
    fea8:      	b	0xfef8 <generic_rawtp_path+0x6df8>
    feac:      	add	x2, x24, #0x10
    feb0:      	mov	w8, #0x4                // =4
    feb4:      	add	x9, sp, #0x98
    feb8:      	add	x0, sp, #0x98
    febc:      	mov	w1, #0x8                // =8
    fec0:      	blr	x8
    fec4:      	ldr	x8, [sp, #0x58]
    fec8:      	ldr	x9, [sp, #0x98]
    fecc:      	cmp	x8, x9
    fed0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    fed4:      	add	x2, x24, #0x18
    fed8:      	mov	w8, #0x4                // =4
    fedc:      	mov	x0, x22
    fee0:      	mov	w1, #0x8                // =8
    fee4:      	blr	x8
    fee8:      	ldr	x24, [sp, #0x98]
    feec:      	ldr	x21, [sp, #0x48]
    fef0:      	add	x2, x24, #0x20
    fef4:      	stp	x2, x24, [sp, #0x50]
    fef8:      	ldr	x8, [sp, #0x30]
    fefc:      	cmp	x21, x8
    ff00:      	b.ne	0xff10 <generic_rawtp_path+0x6e10>
    ff04:      	ldr	x8, [sp, #0x38]
    ff08:      	cmp	x2, x8
    ff0c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
    ff10:      	mov	w8, #0x4                // =4
    ff14:      	add	x0, sp, #0x70
    ff18:      	mov	w1, #0x8                // =8
    ff1c:      	blr	x8
    ff20:      	ldr	x8, [sp, #0x70]
    ff24:      	cmp	x21, x8
    ff28:      	b.eq	0x10018 <generic_rawtp_path+0x6f18>
    ff2c:      	add	x23, x21, #0x18
    ff30:      	mov	w8, #0x4                // =4
    ff34:      	add	x9, sp, #0x98
    ff38:      	add	x0, sp, #0x98
    ff3c:      	mov	w1, #0x8                // =8
    ff40:      	mov	x2, x23
    ff44:      	blr	x8
    ff48:      	ldr	x8, [sp, #0x98]
    ff4c:      	cmp	x8, x21
    ff50:      	b.eq	0x10018 <generic_rawtp_path+0x6f18>
    ff54:      	mov	w8, #0x4                // =4
    ff58:      	add	x9, sp, #0x78
    ff5c:      	add	x0, sp, #0x78
    ff60:      	mov	w1, #0x8                // =8
    ff64:      	mov	x2, x23
    ff68:      	blr	x8
    ff6c:      	add	x2, x21, #0x20
    ff70:      	mov	w8, #0x4                // =4
    ff74:      	mov	w9, #0x10               // =16
    ff78:      	add	x10, sp, #0x80
    ff7c:      	add	x0, sp, #0x80
    ff80:      	mov	w1, #0x10               // =16
    ff84:      	blr	x8
    ff88:      	ldr	w21, [sp, #0x84]
    ff8c:      	ldr	x8, [sp, #0x40]
    ff90:      	ldr	x10, [sp, #0x60]
    ff94:      	sub	x12, x10, x8
    ff98:      	ldr	w23, [sp, #0x68]
    ff9c:      	subs	w10, w21, w23
    ffa0:      	ldr	x9, [sp, #0x88]
    ffa4:      	csel	w10, wzr, w10, lo
    ffa8:      	cmp	w23, w21
    ffac:      	csel	w11, w23, w21, lo
    ffb0:      	cinc	w13, w11, hi
    ffb4:      	sub	w14, w23, w13
    ffb8:      	subs	x12, x12, x13
    ffbc:      	str	w14, [sp, #0x68]
    ffc0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
    ffc4:      	cmp	x12, #0xfff
    ffc8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
    ffcc:      	cmp	w23, w21
    ffd0:      	b.ls	0xffdc <generic_rawtp_path+0x6edc>
    ffd4:      	mov	w13, #0x2f              // =47
    ffd8:      	strb	w13, [x8, x12]
    ffdc:      	add	x19, x8, x12
    ffe0:      	cmp	w23, w21
    ffe4:      	add	x2, x9, x10
    ffe8:      	and	w1, w11, #0xff
    ffec:      	mov	w8, #0x4                // =4
    fff0:      	cinc	x0, x19, hi
    fff4:      	blr	x8
    fff8:      	cmp	w23, w21
    fffc:      	str	x19, [sp, #0x60]
   10000:      	add	x19, sp, #0x70
   10004:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10008:      	ldr	x21, [sp, #0x78]
   1000c:      	ldp	x2, x24, [sp, #0x50]
   10010:      	str	x21, [sp, #0x48]
   10014:      	b	0x10064 <generic_rawtp_path+0x6f64>
   10018:      	add	x2, x24, #0x10
   1001c:      	mov	w8, #0x4                // =4
   10020:      	add	x9, sp, #0x98
   10024:      	add	x0, sp, #0x98
   10028:      	mov	w1, #0x8                // =8
   1002c:      	blr	x8
   10030:      	ldr	x8, [sp, #0x58]
   10034:      	ldr	x9, [sp, #0x98]
   10038:      	cmp	x8, x9
   1003c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10040:      	add	x2, x24, #0x18
   10044:      	mov	w8, #0x4                // =4
   10048:      	mov	x0, x22
   1004c:      	mov	w1, #0x8                // =8
   10050:      	blr	x8
   10054:      	ldr	x24, [sp, #0x98]
   10058:      	ldr	x21, [sp, #0x48]
   1005c:      	add	x2, x24, #0x20
   10060:      	stp	x2, x24, [sp, #0x50]
   10064:      	ldr	x8, [sp, #0x30]
   10068:      	cmp	x21, x8
   1006c:      	b.ne	0x1007c <generic_rawtp_path+0x6f7c>
   10070:      	ldr	x8, [sp, #0x38]
   10074:      	cmp	x2, x8
   10078:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1007c:      	mov	w8, #0x4                // =4
   10080:      	add	x0, sp, #0x70
   10084:      	mov	w1, #0x8                // =8
   10088:      	blr	x8
   1008c:      	ldr	x8, [sp, #0x70]
   10090:      	cmp	x21, x8
   10094:      	b.eq	0x10184 <generic_rawtp_path+0x7084>
   10098:      	add	x23, x21, #0x18
   1009c:      	mov	w8, #0x4                // =4
   100a0:      	add	x9, sp, #0x98
   100a4:      	add	x0, sp, #0x98
   100a8:      	mov	w1, #0x8                // =8
   100ac:      	mov	x2, x23
   100b0:      	blr	x8
   100b4:      	ldr	x8, [sp, #0x98]
   100b8:      	cmp	x8, x21
   100bc:      	b.eq	0x10184 <generic_rawtp_path+0x7084>
   100c0:      	mov	w8, #0x4                // =4
   100c4:      	add	x9, sp, #0x78
   100c8:      	add	x0, sp, #0x78
   100cc:      	mov	w1, #0x8                // =8
   100d0:      	mov	x2, x23
   100d4:      	blr	x8
   100d8:      	add	x2, x21, #0x20
   100dc:      	mov	w8, #0x4                // =4
   100e0:      	mov	w9, #0x10               // =16
   100e4:      	add	x10, sp, #0x80
   100e8:      	add	x0, sp, #0x80
   100ec:      	mov	w1, #0x10               // =16
   100f0:      	blr	x8
   100f4:      	ldr	w21, [sp, #0x84]
   100f8:      	ldr	x8, [sp, #0x40]
   100fc:      	ldr	x10, [sp, #0x60]
   10100:      	sub	x12, x10, x8
   10104:      	ldr	w23, [sp, #0x68]
   10108:      	subs	w10, w21, w23
   1010c:      	ldr	x9, [sp, #0x88]
   10110:      	csel	w10, wzr, w10, lo
   10114:      	cmp	w23, w21
   10118:      	csel	w11, w23, w21, lo
   1011c:      	cinc	w13, w11, hi
   10120:      	sub	w14, w23, w13
   10124:      	subs	x12, x12, x13
   10128:      	str	w14, [sp, #0x68]
   1012c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10130:      	cmp	x12, #0xfff
   10134:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10138:      	cmp	w23, w21
   1013c:      	b.ls	0x10148 <generic_rawtp_path+0x7048>
   10140:      	mov	w13, #0x2f              // =47
   10144:      	strb	w13, [x8, x12]
   10148:      	add	x19, x8, x12
   1014c:      	cmp	w23, w21
   10150:      	add	x2, x9, x10
   10154:      	and	w1, w11, #0xff
   10158:      	mov	w8, #0x4                // =4
   1015c:      	cinc	x0, x19, hi
   10160:      	blr	x8
   10164:      	cmp	w23, w21
   10168:      	str	x19, [sp, #0x60]
   1016c:      	add	x19, sp, #0x70
   10170:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10174:      	ldr	x21, [sp, #0x78]
   10178:      	ldp	x2, x24, [sp, #0x50]
   1017c:      	str	x21, [sp, #0x48]
   10180:      	b	0x101d0 <generic_rawtp_path+0x70d0>
   10184:      	add	x2, x24, #0x10
   10188:      	mov	w8, #0x4                // =4
   1018c:      	add	x9, sp, #0x98
   10190:      	add	x0, sp, #0x98
   10194:      	mov	w1, #0x8                // =8
   10198:      	blr	x8
   1019c:      	ldr	x8, [sp, #0x58]
   101a0:      	ldr	x9, [sp, #0x98]
   101a4:      	cmp	x8, x9
   101a8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   101ac:      	add	x2, x24, #0x18
   101b0:      	mov	w8, #0x4                // =4
   101b4:      	mov	x0, x22
   101b8:      	mov	w1, #0x8                // =8
   101bc:      	blr	x8
   101c0:      	ldr	x24, [sp, #0x98]
   101c4:      	ldr	x21, [sp, #0x48]
   101c8:      	add	x2, x24, #0x20
   101cc:      	stp	x2, x24, [sp, #0x50]
   101d0:      	ldr	x8, [sp, #0x30]
   101d4:      	cmp	x21, x8
   101d8:      	b.ne	0x101e8 <generic_rawtp_path+0x70e8>
   101dc:      	ldr	x8, [sp, #0x38]
   101e0:      	cmp	x2, x8
   101e4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   101e8:      	mov	w8, #0x4                // =4
   101ec:      	add	x0, sp, #0x70
   101f0:      	mov	w1, #0x8                // =8
   101f4:      	blr	x8
   101f8:      	ldr	x8, [sp, #0x70]
   101fc:      	cmp	x21, x8
   10200:      	b.eq	0x102f0 <generic_rawtp_path+0x71f0>
   10204:      	add	x23, x21, #0x18
   10208:      	mov	w8, #0x4                // =4
   1020c:      	add	x9, sp, #0x98
   10210:      	add	x0, sp, #0x98
   10214:      	mov	w1, #0x8                // =8
   10218:      	mov	x2, x23
   1021c:      	blr	x8
   10220:      	ldr	x8, [sp, #0x98]
   10224:      	cmp	x8, x21
   10228:      	b.eq	0x102f0 <generic_rawtp_path+0x71f0>
   1022c:      	mov	w8, #0x4                // =4
   10230:      	add	x9, sp, #0x78
   10234:      	add	x0, sp, #0x78
   10238:      	mov	w1, #0x8                // =8
   1023c:      	mov	x2, x23
   10240:      	blr	x8
   10244:      	add	x2, x21, #0x20
   10248:      	mov	w8, #0x4                // =4
   1024c:      	mov	w9, #0x10               // =16
   10250:      	add	x10, sp, #0x80
   10254:      	add	x0, sp, #0x80
   10258:      	mov	w1, #0x10               // =16
   1025c:      	blr	x8
   10260:      	ldr	w21, [sp, #0x84]
   10264:      	ldr	x8, [sp, #0x40]
   10268:      	ldr	x10, [sp, #0x60]
   1026c:      	sub	x12, x10, x8
   10270:      	ldr	w23, [sp, #0x68]
   10274:      	subs	w10, w21, w23
   10278:      	ldr	x9, [sp, #0x88]
   1027c:      	csel	w10, wzr, w10, lo
   10280:      	cmp	w23, w21
   10284:      	csel	w11, w23, w21, lo
   10288:      	cinc	w13, w11, hi
   1028c:      	sub	w14, w23, w13
   10290:      	subs	x12, x12, x13
   10294:      	str	w14, [sp, #0x68]
   10298:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   1029c:      	cmp	x12, #0xfff
   102a0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   102a4:      	cmp	w23, w21
   102a8:      	b.ls	0x102b4 <generic_rawtp_path+0x71b4>
   102ac:      	mov	w13, #0x2f              // =47
   102b0:      	strb	w13, [x8, x12]
   102b4:      	add	x19, x8, x12
   102b8:      	cmp	w23, w21
   102bc:      	add	x2, x9, x10
   102c0:      	and	w1, w11, #0xff
   102c4:      	mov	w8, #0x4                // =4
   102c8:      	cinc	x0, x19, hi
   102cc:      	blr	x8
   102d0:      	cmp	w23, w21
   102d4:      	str	x19, [sp, #0x60]
   102d8:      	add	x19, sp, #0x70
   102dc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   102e0:      	ldr	x21, [sp, #0x78]
   102e4:      	ldp	x2, x24, [sp, #0x50]
   102e8:      	str	x21, [sp, #0x48]
   102ec:      	b	0x1033c <generic_rawtp_path+0x723c>
   102f0:      	add	x2, x24, #0x10
   102f4:      	mov	w8, #0x4                // =4
   102f8:      	add	x9, sp, #0x98
   102fc:      	add	x0, sp, #0x98
   10300:      	mov	w1, #0x8                // =8
   10304:      	blr	x8
   10308:      	ldr	x8, [sp, #0x58]
   1030c:      	ldr	x9, [sp, #0x98]
   10310:      	cmp	x8, x9
   10314:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10318:      	add	x2, x24, #0x18
   1031c:      	mov	w8, #0x4                // =4
   10320:      	mov	x0, x22
   10324:      	mov	w1, #0x8                // =8
   10328:      	blr	x8
   1032c:      	ldr	x24, [sp, #0x98]
   10330:      	ldr	x21, [sp, #0x48]
   10334:      	add	x2, x24, #0x20
   10338:      	stp	x2, x24, [sp, #0x50]
   1033c:      	ldr	x8, [sp, #0x30]
   10340:      	cmp	x21, x8
   10344:      	b.ne	0x10354 <generic_rawtp_path+0x7254>
   10348:      	ldr	x8, [sp, #0x38]
   1034c:      	cmp	x2, x8
   10350:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10354:      	mov	w8, #0x4                // =4
   10358:      	add	x0, sp, #0x70
   1035c:      	mov	w1, #0x8                // =8
   10360:      	blr	x8
   10364:      	ldr	x8, [sp, #0x70]
   10368:      	cmp	x21, x8
   1036c:      	b.eq	0x1045c <generic_rawtp_path+0x735c>
   10370:      	add	x23, x21, #0x18
   10374:      	mov	w8, #0x4                // =4
   10378:      	add	x9, sp, #0x98
   1037c:      	add	x0, sp, #0x98
   10380:      	mov	w1, #0x8                // =8
   10384:      	mov	x2, x23
   10388:      	blr	x8
   1038c:      	ldr	x8, [sp, #0x98]
   10390:      	cmp	x8, x21
   10394:      	b.eq	0x1045c <generic_rawtp_path+0x735c>
   10398:      	mov	w8, #0x4                // =4
   1039c:      	add	x9, sp, #0x78
   103a0:      	add	x0, sp, #0x78
   103a4:      	mov	w1, #0x8                // =8
   103a8:      	mov	x2, x23
   103ac:      	blr	x8
   103b0:      	add	x2, x21, #0x20
   103b4:      	mov	w8, #0x4                // =4
   103b8:      	mov	w9, #0x10               // =16
   103bc:      	add	x10, sp, #0x80
   103c0:      	add	x0, sp, #0x80
   103c4:      	mov	w1, #0x10               // =16
   103c8:      	blr	x8
   103cc:      	ldr	w21, [sp, #0x84]
   103d0:      	ldr	x8, [sp, #0x40]
   103d4:      	ldr	x10, [sp, #0x60]
   103d8:      	sub	x12, x10, x8
   103dc:      	ldr	w23, [sp, #0x68]
   103e0:      	subs	w10, w21, w23
   103e4:      	ldr	x9, [sp, #0x88]
   103e8:      	csel	w10, wzr, w10, lo
   103ec:      	cmp	w23, w21
   103f0:      	csel	w11, w23, w21, lo
   103f4:      	cinc	w13, w11, hi
   103f8:      	sub	w14, w23, w13
   103fc:      	subs	x12, x12, x13
   10400:      	str	w14, [sp, #0x68]
   10404:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10408:      	cmp	x12, #0xfff
   1040c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10410:      	cmp	w23, w21
   10414:      	b.ls	0x10420 <generic_rawtp_path+0x7320>
   10418:      	mov	w13, #0x2f              // =47
   1041c:      	strb	w13, [x8, x12]
   10420:      	add	x19, x8, x12
   10424:      	cmp	w23, w21
   10428:      	add	x2, x9, x10
   1042c:      	and	w1, w11, #0xff
   10430:      	mov	w8, #0x4                // =4
   10434:      	cinc	x0, x19, hi
   10438:      	blr	x8
   1043c:      	cmp	w23, w21
   10440:      	str	x19, [sp, #0x60]
   10444:      	add	x19, sp, #0x70
   10448:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1044c:      	ldr	x21, [sp, #0x78]
   10450:      	ldp	x2, x24, [sp, #0x50]
   10454:      	str	x21, [sp, #0x48]
   10458:      	b	0x104a8 <generic_rawtp_path+0x73a8>
   1045c:      	add	x2, x24, #0x10
   10460:      	mov	w8, #0x4                // =4
   10464:      	add	x9, sp, #0x98
   10468:      	add	x0, sp, #0x98
   1046c:      	mov	w1, #0x8                // =8
   10470:      	blr	x8
   10474:      	ldr	x8, [sp, #0x58]
   10478:      	ldr	x9, [sp, #0x98]
   1047c:      	cmp	x8, x9
   10480:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10484:      	add	x2, x24, #0x18
   10488:      	mov	w8, #0x4                // =4
   1048c:      	mov	x0, x22
   10490:      	mov	w1, #0x8                // =8
   10494:      	blr	x8
   10498:      	ldr	x24, [sp, #0x98]
   1049c:      	ldr	x21, [sp, #0x48]
   104a0:      	add	x2, x24, #0x20
   104a4:      	stp	x2, x24, [sp, #0x50]
   104a8:      	ldr	x8, [sp, #0x30]
   104ac:      	cmp	x21, x8
   104b0:      	b.ne	0x104c0 <generic_rawtp_path+0x73c0>
   104b4:      	ldr	x8, [sp, #0x38]
   104b8:      	cmp	x2, x8
   104bc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   104c0:      	mov	w8, #0x4                // =4
   104c4:      	add	x0, sp, #0x70
   104c8:      	mov	w1, #0x8                // =8
   104cc:      	blr	x8
   104d0:      	ldr	x8, [sp, #0x70]
   104d4:      	cmp	x21, x8
   104d8:      	b.eq	0x105c8 <generic_rawtp_path+0x74c8>
   104dc:      	add	x23, x21, #0x18
   104e0:      	mov	w8, #0x4                // =4
   104e4:      	add	x9, sp, #0x98
   104e8:      	add	x0, sp, #0x98
   104ec:      	mov	w1, #0x8                // =8
   104f0:      	mov	x2, x23
   104f4:      	blr	x8
   104f8:      	ldr	x8, [sp, #0x98]
   104fc:      	cmp	x8, x21
   10500:      	b.eq	0x105c8 <generic_rawtp_path+0x74c8>
   10504:      	mov	w8, #0x4                // =4
   10508:      	add	x9, sp, #0x78
   1050c:      	add	x0, sp, #0x78
   10510:      	mov	w1, #0x8                // =8
   10514:      	mov	x2, x23
   10518:      	blr	x8
   1051c:      	add	x2, x21, #0x20
   10520:      	mov	w8, #0x4                // =4
   10524:      	mov	w9, #0x10               // =16
   10528:      	add	x10, sp, #0x80
   1052c:      	add	x0, sp, #0x80
   10530:      	mov	w1, #0x10               // =16
   10534:      	blr	x8
   10538:      	ldr	w21, [sp, #0x84]
   1053c:      	ldr	x8, [sp, #0x40]
   10540:      	ldr	x10, [sp, #0x60]
   10544:      	sub	x12, x10, x8
   10548:      	ldr	w23, [sp, #0x68]
   1054c:      	subs	w10, w21, w23
   10550:      	ldr	x9, [sp, #0x88]
   10554:      	csel	w10, wzr, w10, lo
   10558:      	cmp	w23, w21
   1055c:      	csel	w11, w23, w21, lo
   10560:      	cinc	w13, w11, hi
   10564:      	sub	w14, w23, w13
   10568:      	subs	x12, x12, x13
   1056c:      	str	w14, [sp, #0x68]
   10570:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10574:      	cmp	x12, #0xfff
   10578:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   1057c:      	cmp	w23, w21
   10580:      	b.ls	0x1058c <generic_rawtp_path+0x748c>
   10584:      	mov	w13, #0x2f              // =47
   10588:      	strb	w13, [x8, x12]
   1058c:      	add	x19, x8, x12
   10590:      	cmp	w23, w21
   10594:      	add	x2, x9, x10
   10598:      	and	w1, w11, #0xff
   1059c:      	mov	w8, #0x4                // =4
   105a0:      	cinc	x0, x19, hi
   105a4:      	blr	x8
   105a8:      	cmp	w23, w21
   105ac:      	str	x19, [sp, #0x60]
   105b0:      	add	x19, sp, #0x70
   105b4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   105b8:      	ldr	x21, [sp, #0x78]
   105bc:      	ldp	x2, x24, [sp, #0x50]
   105c0:      	str	x21, [sp, #0x48]
   105c4:      	b	0x10614 <generic_rawtp_path+0x7514>
   105c8:      	add	x2, x24, #0x10
   105cc:      	mov	w8, #0x4                // =4
   105d0:      	add	x9, sp, #0x98
   105d4:      	add	x0, sp, #0x98
   105d8:      	mov	w1, #0x8                // =8
   105dc:      	blr	x8
   105e0:      	ldr	x8, [sp, #0x58]
   105e4:      	ldr	x9, [sp, #0x98]
   105e8:      	cmp	x8, x9
   105ec:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   105f0:      	add	x2, x24, #0x18
   105f4:      	mov	w8, #0x4                // =4
   105f8:      	mov	x0, x22
   105fc:      	mov	w1, #0x8                // =8
   10600:      	blr	x8
   10604:      	ldr	x24, [sp, #0x98]
   10608:      	ldr	x21, [sp, #0x48]
   1060c:      	add	x2, x24, #0x20
   10610:      	stp	x2, x24, [sp, #0x50]
   10614:      	ldr	x8, [sp, #0x30]
   10618:      	cmp	x21, x8
   1061c:      	b.ne	0x1062c <generic_rawtp_path+0x752c>
   10620:      	ldr	x8, [sp, #0x38]
   10624:      	cmp	x2, x8
   10628:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1062c:      	mov	w8, #0x4                // =4
   10630:      	add	x0, sp, #0x70
   10634:      	mov	w1, #0x8                // =8
   10638:      	blr	x8
   1063c:      	ldr	x8, [sp, #0x70]
   10640:      	cmp	x21, x8
   10644:      	b.eq	0x10734 <generic_rawtp_path+0x7634>
   10648:      	add	x23, x21, #0x18
   1064c:      	mov	w8, #0x4                // =4
   10650:      	add	x9, sp, #0x98
   10654:      	add	x0, sp, #0x98
   10658:      	mov	w1, #0x8                // =8
   1065c:      	mov	x2, x23
   10660:      	blr	x8
   10664:      	ldr	x8, [sp, #0x98]
   10668:      	cmp	x8, x21
   1066c:      	b.eq	0x10734 <generic_rawtp_path+0x7634>
   10670:      	mov	w8, #0x4                // =4
   10674:      	add	x9, sp, #0x78
   10678:      	add	x0, sp, #0x78
   1067c:      	mov	w1, #0x8                // =8
   10680:      	mov	x2, x23
   10684:      	blr	x8
   10688:      	add	x2, x21, #0x20
   1068c:      	mov	w8, #0x4                // =4
   10690:      	mov	w9, #0x10               // =16
   10694:      	add	x10, sp, #0x80
   10698:      	add	x0, sp, #0x80
   1069c:      	mov	w1, #0x10               // =16
   106a0:      	blr	x8
   106a4:      	ldr	w21, [sp, #0x84]
   106a8:      	ldr	x8, [sp, #0x40]
   106ac:      	ldr	x10, [sp, #0x60]
   106b0:      	sub	x12, x10, x8
   106b4:      	ldr	w23, [sp, #0x68]
   106b8:      	subs	w10, w21, w23
   106bc:      	ldr	x9, [sp, #0x88]
   106c0:      	csel	w10, wzr, w10, lo
   106c4:      	cmp	w23, w21
   106c8:      	csel	w11, w23, w21, lo
   106cc:      	cinc	w13, w11, hi
   106d0:      	sub	w14, w23, w13
   106d4:      	subs	x12, x12, x13
   106d8:      	str	w14, [sp, #0x68]
   106dc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   106e0:      	cmp	x12, #0xfff
   106e4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   106e8:      	cmp	w23, w21
   106ec:      	b.ls	0x106f8 <generic_rawtp_path+0x75f8>
   106f0:      	mov	w13, #0x2f              // =47
   106f4:      	strb	w13, [x8, x12]
   106f8:      	add	x19, x8, x12
   106fc:      	cmp	w23, w21
   10700:      	add	x2, x9, x10
   10704:      	and	w1, w11, #0xff
   10708:      	mov	w8, #0x4                // =4
   1070c:      	cinc	x0, x19, hi
   10710:      	blr	x8
   10714:      	cmp	w23, w21
   10718:      	str	x19, [sp, #0x60]
   1071c:      	add	x19, sp, #0x70
   10720:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10724:      	ldr	x21, [sp, #0x78]
   10728:      	ldp	x2, x24, [sp, #0x50]
   1072c:      	str	x21, [sp, #0x48]
   10730:      	b	0x10780 <generic_rawtp_path+0x7680>
   10734:      	add	x2, x24, #0x10
   10738:      	mov	w8, #0x4                // =4
   1073c:      	add	x9, sp, #0x98
   10740:      	add	x0, sp, #0x98
   10744:      	mov	w1, #0x8                // =8
   10748:      	blr	x8
   1074c:      	ldr	x8, [sp, #0x58]
   10750:      	ldr	x9, [sp, #0x98]
   10754:      	cmp	x8, x9
   10758:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1075c:      	add	x2, x24, #0x18
   10760:      	mov	w8, #0x4                // =4
   10764:      	mov	x0, x22
   10768:      	mov	w1, #0x8                // =8
   1076c:      	blr	x8
   10770:      	ldr	x24, [sp, #0x98]
   10774:      	ldr	x21, [sp, #0x48]
   10778:      	add	x2, x24, #0x20
   1077c:      	stp	x2, x24, [sp, #0x50]
   10780:      	ldr	x8, [sp, #0x30]
   10784:      	cmp	x21, x8
   10788:      	b.ne	0x10798 <generic_rawtp_path+0x7698>
   1078c:      	ldr	x8, [sp, #0x38]
   10790:      	cmp	x2, x8
   10794:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10798:      	mov	w8, #0x4                // =4
   1079c:      	add	x0, sp, #0x70
   107a0:      	mov	w1, #0x8                // =8
   107a4:      	blr	x8
   107a8:      	ldr	x8, [sp, #0x70]
   107ac:      	cmp	x21, x8
   107b0:      	b.eq	0x108a0 <generic_rawtp_path+0x77a0>
   107b4:      	add	x23, x21, #0x18
   107b8:      	mov	w8, #0x4                // =4
   107bc:      	add	x9, sp, #0x98
   107c0:      	add	x0, sp, #0x98
   107c4:      	mov	w1, #0x8                // =8
   107c8:      	mov	x2, x23
   107cc:      	blr	x8
   107d0:      	ldr	x8, [sp, #0x98]
   107d4:      	cmp	x8, x21
   107d8:      	b.eq	0x108a0 <generic_rawtp_path+0x77a0>
   107dc:      	mov	w8, #0x4                // =4
   107e0:      	add	x9, sp, #0x78
   107e4:      	add	x0, sp, #0x78
   107e8:      	mov	w1, #0x8                // =8
   107ec:      	mov	x2, x23
   107f0:      	blr	x8
   107f4:      	add	x2, x21, #0x20
   107f8:      	mov	w8, #0x4                // =4
   107fc:      	mov	w9, #0x10               // =16
   10800:      	add	x10, sp, #0x80
   10804:      	add	x0, sp, #0x80
   10808:      	mov	w1, #0x10               // =16
   1080c:      	blr	x8
   10810:      	ldr	w21, [sp, #0x84]
   10814:      	ldr	x8, [sp, #0x40]
   10818:      	ldr	x10, [sp, #0x60]
   1081c:      	sub	x12, x10, x8
   10820:      	ldr	w23, [sp, #0x68]
   10824:      	subs	w10, w21, w23
   10828:      	ldr	x9, [sp, #0x88]
   1082c:      	csel	w10, wzr, w10, lo
   10830:      	cmp	w23, w21
   10834:      	csel	w11, w23, w21, lo
   10838:      	cinc	w13, w11, hi
   1083c:      	sub	w14, w23, w13
   10840:      	subs	x12, x12, x13
   10844:      	str	w14, [sp, #0x68]
   10848:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   1084c:      	cmp	x12, #0xfff
   10850:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10854:      	cmp	w23, w21
   10858:      	b.ls	0x10864 <generic_rawtp_path+0x7764>
   1085c:      	mov	w13, #0x2f              // =47
   10860:      	strb	w13, [x8, x12]
   10864:      	add	x19, x8, x12
   10868:      	cmp	w23, w21
   1086c:      	add	x2, x9, x10
   10870:      	and	w1, w11, #0xff
   10874:      	mov	w8, #0x4                // =4
   10878:      	cinc	x0, x19, hi
   1087c:      	blr	x8
   10880:      	cmp	w23, w21
   10884:      	str	x19, [sp, #0x60]
   10888:      	add	x19, sp, #0x70
   1088c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10890:      	ldr	x21, [sp, #0x78]
   10894:      	ldp	x2, x24, [sp, #0x50]
   10898:      	str	x21, [sp, #0x48]
   1089c:      	b	0x108ec <generic_rawtp_path+0x77ec>
   108a0:      	add	x2, x24, #0x10
   108a4:      	mov	w8, #0x4                // =4
   108a8:      	add	x9, sp, #0x98
   108ac:      	add	x0, sp, #0x98
   108b0:      	mov	w1, #0x8                // =8
   108b4:      	blr	x8
   108b8:      	ldr	x8, [sp, #0x58]
   108bc:      	ldr	x9, [sp, #0x98]
   108c0:      	cmp	x8, x9
   108c4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   108c8:      	add	x2, x24, #0x18
   108cc:      	mov	w8, #0x4                // =4
   108d0:      	mov	x0, x22
   108d4:      	mov	w1, #0x8                // =8
   108d8:      	blr	x8
   108dc:      	ldr	x24, [sp, #0x98]
   108e0:      	ldr	x21, [sp, #0x48]
   108e4:      	add	x2, x24, #0x20
   108e8:      	stp	x2, x24, [sp, #0x50]
   108ec:      	ldr	x8, [sp, #0x30]
   108f0:      	cmp	x21, x8
   108f4:      	b.ne	0x10904 <generic_rawtp_path+0x7804>
   108f8:      	ldr	x8, [sp, #0x38]
   108fc:      	cmp	x2, x8
   10900:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10904:      	mov	w8, #0x4                // =4
   10908:      	add	x0, sp, #0x70
   1090c:      	mov	w1, #0x8                // =8
   10910:      	blr	x8
   10914:      	ldr	x8, [sp, #0x70]
   10918:      	cmp	x21, x8
   1091c:      	b.eq	0x10a0c <generic_rawtp_path+0x790c>
   10920:      	add	x23, x21, #0x18
   10924:      	mov	w8, #0x4                // =4
   10928:      	add	x9, sp, #0x98
   1092c:      	add	x0, sp, #0x98
   10930:      	mov	w1, #0x8                // =8
   10934:      	mov	x2, x23
   10938:      	blr	x8
   1093c:      	ldr	x8, [sp, #0x98]
   10940:      	cmp	x8, x21
   10944:      	b.eq	0x10a0c <generic_rawtp_path+0x790c>
   10948:      	mov	w8, #0x4                // =4
   1094c:      	add	x9, sp, #0x78
   10950:      	add	x0, sp, #0x78
   10954:      	mov	w1, #0x8                // =8
   10958:      	mov	x2, x23
   1095c:      	blr	x8
   10960:      	add	x2, x21, #0x20
   10964:      	mov	w8, #0x4                // =4
   10968:      	mov	w9, #0x10               // =16
   1096c:      	add	x10, sp, #0x80
   10970:      	add	x0, sp, #0x80
   10974:      	mov	w1, #0x10               // =16
   10978:      	blr	x8
   1097c:      	ldr	w21, [sp, #0x84]
   10980:      	ldr	x8, [sp, #0x40]
   10984:      	ldr	x10, [sp, #0x60]
   10988:      	sub	x12, x10, x8
   1098c:      	ldr	w23, [sp, #0x68]
   10990:      	subs	w10, w21, w23
   10994:      	ldr	x9, [sp, #0x88]
   10998:      	csel	w10, wzr, w10, lo
   1099c:      	cmp	w23, w21
   109a0:      	csel	w11, w23, w21, lo
   109a4:      	cinc	w13, w11, hi
   109a8:      	sub	w14, w23, w13
   109ac:      	subs	x12, x12, x13
   109b0:      	str	w14, [sp, #0x68]
   109b4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   109b8:      	cmp	x12, #0xfff
   109bc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   109c0:      	cmp	w23, w21
   109c4:      	b.ls	0x109d0 <generic_rawtp_path+0x78d0>
   109c8:      	mov	w13, #0x2f              // =47
   109cc:      	strb	w13, [x8, x12]
   109d0:      	add	x19, x8, x12
   109d4:      	cmp	w23, w21
   109d8:      	add	x2, x9, x10
   109dc:      	and	w1, w11, #0xff
   109e0:      	mov	w8, #0x4                // =4
   109e4:      	cinc	x0, x19, hi
   109e8:      	blr	x8
   109ec:      	cmp	w23, w21
   109f0:      	str	x19, [sp, #0x60]
   109f4:      	add	x19, sp, #0x70
   109f8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   109fc:      	ldr	x21, [sp, #0x78]
   10a00:      	ldp	x2, x24, [sp, #0x50]
   10a04:      	str	x21, [sp, #0x48]
   10a08:      	b	0x10a58 <generic_rawtp_path+0x7958>
   10a0c:      	add	x2, x24, #0x10
   10a10:      	mov	w8, #0x4                // =4
   10a14:      	add	x9, sp, #0x98
   10a18:      	add	x0, sp, #0x98
   10a1c:      	mov	w1, #0x8                // =8
   10a20:      	blr	x8
   10a24:      	ldr	x8, [sp, #0x58]
   10a28:      	ldr	x9, [sp, #0x98]
   10a2c:      	cmp	x8, x9
   10a30:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10a34:      	add	x2, x24, #0x18
   10a38:      	mov	w8, #0x4                // =4
   10a3c:      	mov	x0, x22
   10a40:      	mov	w1, #0x8                // =8
   10a44:      	blr	x8
   10a48:      	ldr	x24, [sp, #0x98]
   10a4c:      	ldr	x21, [sp, #0x48]
   10a50:      	add	x2, x24, #0x20
   10a54:      	stp	x2, x24, [sp, #0x50]
   10a58:      	ldr	x8, [sp, #0x30]
   10a5c:      	cmp	x21, x8
   10a60:      	b.ne	0x10a70 <generic_rawtp_path+0x7970>
   10a64:      	ldr	x8, [sp, #0x38]
   10a68:      	cmp	x2, x8
   10a6c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10a70:      	mov	w8, #0x4                // =4
   10a74:      	add	x0, sp, #0x70
   10a78:      	mov	w1, #0x8                // =8
   10a7c:      	blr	x8
   10a80:      	ldr	x8, [sp, #0x70]
   10a84:      	cmp	x21, x8
   10a88:      	b.eq	0x10b78 <generic_rawtp_path+0x7a78>
   10a8c:      	add	x23, x21, #0x18
   10a90:      	mov	w8, #0x4                // =4
   10a94:      	add	x9, sp, #0x98
   10a98:      	add	x0, sp, #0x98
   10a9c:      	mov	w1, #0x8                // =8
   10aa0:      	mov	x2, x23
   10aa4:      	blr	x8
   10aa8:      	ldr	x8, [sp, #0x98]
   10aac:      	cmp	x8, x21
   10ab0:      	b.eq	0x10b78 <generic_rawtp_path+0x7a78>
   10ab4:      	mov	w8, #0x4                // =4
   10ab8:      	add	x9, sp, #0x78
   10abc:      	add	x0, sp, #0x78
   10ac0:      	mov	w1, #0x8                // =8
   10ac4:      	mov	x2, x23
   10ac8:      	blr	x8
   10acc:      	add	x2, x21, #0x20
   10ad0:      	mov	w8, #0x4                // =4
   10ad4:      	mov	w9, #0x10               // =16
   10ad8:      	add	x10, sp, #0x80
   10adc:      	add	x0, sp, #0x80
   10ae0:      	mov	w1, #0x10               // =16
   10ae4:      	blr	x8
   10ae8:      	ldr	w21, [sp, #0x84]
   10aec:      	ldr	x8, [sp, #0x40]
   10af0:      	ldr	x10, [sp, #0x60]
   10af4:      	sub	x12, x10, x8
   10af8:      	ldr	w23, [sp, #0x68]
   10afc:      	subs	w10, w21, w23
   10b00:      	ldr	x9, [sp, #0x88]
   10b04:      	csel	w10, wzr, w10, lo
   10b08:      	cmp	w23, w21
   10b0c:      	csel	w11, w23, w21, lo
   10b10:      	cinc	w13, w11, hi
   10b14:      	sub	w14, w23, w13
   10b18:      	subs	x12, x12, x13
   10b1c:      	str	w14, [sp, #0x68]
   10b20:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10b24:      	cmp	x12, #0xfff
   10b28:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10b2c:      	cmp	w23, w21
   10b30:      	b.ls	0x10b3c <generic_rawtp_path+0x7a3c>
   10b34:      	mov	w13, #0x2f              // =47
   10b38:      	strb	w13, [x8, x12]
   10b3c:      	add	x19, x8, x12
   10b40:      	cmp	w23, w21
   10b44:      	add	x2, x9, x10
   10b48:      	and	w1, w11, #0xff
   10b4c:      	mov	w8, #0x4                // =4
   10b50:      	cinc	x0, x19, hi
   10b54:      	blr	x8
   10b58:      	cmp	w23, w21
   10b5c:      	str	x19, [sp, #0x60]
   10b60:      	add	x19, sp, #0x70
   10b64:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10b68:      	ldr	x21, [sp, #0x78]
   10b6c:      	ldp	x2, x24, [sp, #0x50]
   10b70:      	str	x21, [sp, #0x48]
   10b74:      	b	0x10bc4 <generic_rawtp_path+0x7ac4>
   10b78:      	add	x2, x24, #0x10
   10b7c:      	mov	w8, #0x4                // =4
   10b80:      	add	x9, sp, #0x98
   10b84:      	add	x0, sp, #0x98
   10b88:      	mov	w1, #0x8                // =8
   10b8c:      	blr	x8
   10b90:      	ldr	x8, [sp, #0x58]
   10b94:      	ldr	x9, [sp, #0x98]
   10b98:      	cmp	x8, x9
   10b9c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10ba0:      	add	x2, x24, #0x18
   10ba4:      	mov	w8, #0x4                // =4
   10ba8:      	mov	x0, x22
   10bac:      	mov	w1, #0x8                // =8
   10bb0:      	blr	x8
   10bb4:      	ldr	x24, [sp, #0x98]
   10bb8:      	ldr	x21, [sp, #0x48]
   10bbc:      	add	x2, x24, #0x20
   10bc0:      	stp	x2, x24, [sp, #0x50]
   10bc4:      	ldr	x8, [sp, #0x30]
   10bc8:      	cmp	x21, x8
   10bcc:      	b.ne	0x10bdc <generic_rawtp_path+0x7adc>
   10bd0:      	ldr	x8, [sp, #0x38]
   10bd4:      	cmp	x2, x8
   10bd8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10bdc:      	mov	w8, #0x4                // =4
   10be0:      	add	x0, sp, #0x70
   10be4:      	mov	w1, #0x8                // =8
   10be8:      	blr	x8
   10bec:      	ldr	x8, [sp, #0x70]
   10bf0:      	cmp	x21, x8
   10bf4:      	b.eq	0x10ce4 <generic_rawtp_path+0x7be4>
   10bf8:      	add	x23, x21, #0x18
   10bfc:      	mov	w8, #0x4                // =4
   10c00:      	add	x9, sp, #0x98
   10c04:      	add	x0, sp, #0x98
   10c08:      	mov	w1, #0x8                // =8
   10c0c:      	mov	x2, x23
   10c10:      	blr	x8
   10c14:      	ldr	x8, [sp, #0x98]
   10c18:      	cmp	x8, x21
   10c1c:      	b.eq	0x10ce4 <generic_rawtp_path+0x7be4>
   10c20:      	mov	w8, #0x4                // =4
   10c24:      	add	x9, sp, #0x78
   10c28:      	add	x0, sp, #0x78
   10c2c:      	mov	w1, #0x8                // =8
   10c30:      	mov	x2, x23
   10c34:      	blr	x8
   10c38:      	add	x2, x21, #0x20
   10c3c:      	mov	w8, #0x4                // =4
   10c40:      	mov	w9, #0x10               // =16
   10c44:      	add	x10, sp, #0x80
   10c48:      	add	x0, sp, #0x80
   10c4c:      	mov	w1, #0x10               // =16
   10c50:      	blr	x8
   10c54:      	ldr	w21, [sp, #0x84]
   10c58:      	ldr	x8, [sp, #0x40]
   10c5c:      	ldr	x10, [sp, #0x60]
   10c60:      	sub	x12, x10, x8
   10c64:      	ldr	w23, [sp, #0x68]
   10c68:      	subs	w10, w21, w23
   10c6c:      	ldr	x9, [sp, #0x88]
   10c70:      	csel	w10, wzr, w10, lo
   10c74:      	cmp	w23, w21
   10c78:      	csel	w11, w23, w21, lo
   10c7c:      	cinc	w13, w11, hi
   10c80:      	sub	w14, w23, w13
   10c84:      	subs	x12, x12, x13
   10c88:      	str	w14, [sp, #0x68]
   10c8c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10c90:      	cmp	x12, #0xfff
   10c94:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10c98:      	cmp	w23, w21
   10c9c:      	b.ls	0x10ca8 <generic_rawtp_path+0x7ba8>
   10ca0:      	mov	w13, #0x2f              // =47
   10ca4:      	strb	w13, [x8, x12]
   10ca8:      	add	x19, x8, x12
   10cac:      	cmp	w23, w21
   10cb0:      	add	x2, x9, x10
   10cb4:      	and	w1, w11, #0xff
   10cb8:      	mov	w8, #0x4                // =4
   10cbc:      	cinc	x0, x19, hi
   10cc0:      	blr	x8
   10cc4:      	cmp	w23, w21
   10cc8:      	str	x19, [sp, #0x60]
   10ccc:      	add	x19, sp, #0x70
   10cd0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10cd4:      	ldr	x21, [sp, #0x78]
   10cd8:      	ldp	x2, x24, [sp, #0x50]
   10cdc:      	str	x21, [sp, #0x48]
   10ce0:      	b	0x10d30 <generic_rawtp_path+0x7c30>
   10ce4:      	add	x2, x24, #0x10
   10ce8:      	mov	w8, #0x4                // =4
   10cec:      	add	x9, sp, #0x98
   10cf0:      	add	x0, sp, #0x98
   10cf4:      	mov	w1, #0x8                // =8
   10cf8:      	blr	x8
   10cfc:      	ldr	x8, [sp, #0x58]
   10d00:      	ldr	x9, [sp, #0x98]
   10d04:      	cmp	x8, x9
   10d08:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10d0c:      	add	x2, x24, #0x18
   10d10:      	mov	w8, #0x4                // =4
   10d14:      	mov	x0, x22
   10d18:      	mov	w1, #0x8                // =8
   10d1c:      	blr	x8
   10d20:      	ldr	x24, [sp, #0x98]
   10d24:      	ldr	x21, [sp, #0x48]
   10d28:      	add	x2, x24, #0x20
   10d2c:      	stp	x2, x24, [sp, #0x50]
   10d30:      	ldr	x8, [sp, #0x30]
   10d34:      	cmp	x21, x8
   10d38:      	b.ne	0x10d48 <generic_rawtp_path+0x7c48>
   10d3c:      	ldr	x8, [sp, #0x38]
   10d40:      	cmp	x2, x8
   10d44:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10d48:      	mov	w8, #0x4                // =4
   10d4c:      	add	x0, sp, #0x70
   10d50:      	mov	w1, #0x8                // =8
   10d54:      	blr	x8
   10d58:      	ldr	x8, [sp, #0x70]
   10d5c:      	cmp	x21, x8
   10d60:      	b.eq	0x10e50 <generic_rawtp_path+0x7d50>
   10d64:      	add	x23, x21, #0x18
   10d68:      	mov	w8, #0x4                // =4
   10d6c:      	add	x9, sp, #0x98
   10d70:      	add	x0, sp, #0x98
   10d74:      	mov	w1, #0x8                // =8
   10d78:      	mov	x2, x23
   10d7c:      	blr	x8
   10d80:      	ldr	x8, [sp, #0x98]
   10d84:      	cmp	x8, x21
   10d88:      	b.eq	0x10e50 <generic_rawtp_path+0x7d50>
   10d8c:      	mov	w8, #0x4                // =4
   10d90:      	add	x9, sp, #0x78
   10d94:      	add	x0, sp, #0x78
   10d98:      	mov	w1, #0x8                // =8
   10d9c:      	mov	x2, x23
   10da0:      	blr	x8
   10da4:      	add	x2, x21, #0x20
   10da8:      	mov	w8, #0x4                // =4
   10dac:      	mov	w9, #0x10               // =16
   10db0:      	add	x10, sp, #0x80
   10db4:      	add	x0, sp, #0x80
   10db8:      	mov	w1, #0x10               // =16
   10dbc:      	blr	x8
   10dc0:      	ldr	w21, [sp, #0x84]
   10dc4:      	ldr	x8, [sp, #0x40]
   10dc8:      	ldr	x10, [sp, #0x60]
   10dcc:      	sub	x12, x10, x8
   10dd0:      	ldr	w23, [sp, #0x68]
   10dd4:      	subs	w10, w21, w23
   10dd8:      	ldr	x9, [sp, #0x88]
   10ddc:      	csel	w10, wzr, w10, lo
   10de0:      	cmp	w23, w21
   10de4:      	csel	w11, w23, w21, lo
   10de8:      	cinc	w13, w11, hi
   10dec:      	sub	w14, w23, w13
   10df0:      	subs	x12, x12, x13
   10df4:      	str	w14, [sp, #0x68]
   10df8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10dfc:      	cmp	x12, #0xfff
   10e00:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10e04:      	cmp	w23, w21
   10e08:      	b.ls	0x10e14 <generic_rawtp_path+0x7d14>
   10e0c:      	mov	w13, #0x2f              // =47
   10e10:      	strb	w13, [x8, x12]
   10e14:      	add	x19, x8, x12
   10e18:      	cmp	w23, w21
   10e1c:      	add	x2, x9, x10
   10e20:      	and	w1, w11, #0xff
   10e24:      	mov	w8, #0x4                // =4
   10e28:      	cinc	x0, x19, hi
   10e2c:      	blr	x8
   10e30:      	cmp	w23, w21
   10e34:      	str	x19, [sp, #0x60]
   10e38:      	add	x19, sp, #0x70
   10e3c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10e40:      	ldr	x21, [sp, #0x78]
   10e44:      	ldp	x2, x24, [sp, #0x50]
   10e48:      	str	x21, [sp, #0x48]
   10e4c:      	b	0x10e9c <generic_rawtp_path+0x7d9c>
   10e50:      	add	x2, x24, #0x10
   10e54:      	mov	w8, #0x4                // =4
   10e58:      	add	x9, sp, #0x98
   10e5c:      	add	x0, sp, #0x98
   10e60:      	mov	w1, #0x8                // =8
   10e64:      	blr	x8
   10e68:      	ldr	x8, [sp, #0x58]
   10e6c:      	ldr	x9, [sp, #0x98]
   10e70:      	cmp	x8, x9
   10e74:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10e78:      	add	x2, x24, #0x18
   10e7c:      	mov	w8, #0x4                // =4
   10e80:      	mov	x0, x22
   10e84:      	mov	w1, #0x8                // =8
   10e88:      	blr	x8
   10e8c:      	ldr	x24, [sp, #0x98]
   10e90:      	ldr	x21, [sp, #0x48]
   10e94:      	add	x2, x24, #0x20
   10e98:      	stp	x2, x24, [sp, #0x50]
   10e9c:      	ldr	x8, [sp, #0x30]
   10ea0:      	cmp	x21, x8
   10ea4:      	b.ne	0x10eb4 <generic_rawtp_path+0x7db4>
   10ea8:      	ldr	x8, [sp, #0x38]
   10eac:      	cmp	x2, x8
   10eb0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10eb4:      	str	x25, [sp, #0x8]
   10eb8:      	mov	w8, #0x4                // =4
   10ebc:      	add	x0, sp, #0x70
   10ec0:      	mov	w1, #0x8                // =8
   10ec4:      	blr	x8
   10ec8:      	ldr	x8, [sp, #0x70]
   10ecc:      	cmp	x21, x8
   10ed0:      	b.eq	0x10fc4 <generic_rawtp_path+0x7ec4>
   10ed4:      	add	x23, x21, #0x18
   10ed8:      	mov	w8, #0x4                // =4
   10edc:      	add	x9, sp, #0x98
   10ee0:      	add	x0, sp, #0x98
   10ee4:      	mov	w1, #0x8                // =8
   10ee8:      	mov	x2, x23
   10eec:      	blr	x8
   10ef0:      	ldr	x8, [sp, #0x98]
   10ef4:      	cmp	x8, x21
   10ef8:      	b.eq	0x10fc4 <generic_rawtp_path+0x7ec4>
   10efc:      	mov	w8, #0x4                // =4
   10f00:      	add	x9, sp, #0x78
   10f04:      	add	x0, sp, #0x78
   10f08:      	mov	w1, #0x8                // =8
   10f0c:      	mov	x2, x23
   10f10:      	blr	x8
   10f14:      	add	x2, x21, #0x20
   10f18:      	mov	w8, #0x4                // =4
   10f1c:      	mov	w9, #0x10               // =16
   10f20:      	add	x10, sp, #0x80
   10f24:      	add	x0, sp, #0x80
   10f28:      	mov	w1, #0x10               // =16
   10f2c:      	blr	x8
   10f30:      	ldr	w21, [sp, #0x84]
   10f34:      	ldr	x8, [sp, #0x40]
   10f38:      	ldr	x10, [sp, #0x60]
   10f3c:      	sub	x12, x10, x8
   10f40:      	ldr	w23, [sp, #0x68]
   10f44:      	subs	w10, w21, w23
   10f48:      	ldr	x9, [sp, #0x88]
   10f4c:      	ldr	x25, [sp, #0x8]
   10f50:      	csel	w10, wzr, w10, lo
   10f54:      	cmp	w23, w21
   10f58:      	csel	w11, w23, w21, lo
   10f5c:      	cinc	w13, w11, hi
   10f60:      	sub	w14, w23, w13
   10f64:      	subs	x12, x12, x13
   10f68:      	str	w14, [sp, #0x68]
   10f6c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   10f70:      	cmp	x12, #0xfff
   10f74:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   10f78:      	cmp	w23, w21
   10f7c:      	b.ls	0x10f88 <generic_rawtp_path+0x7e88>
   10f80:      	mov	w13, #0x2f              // =47
   10f84:      	strb	w13, [x8, x12]
   10f88:      	add	x19, x8, x12
   10f8c:      	cmp	w23, w21
   10f90:      	add	x2, x9, x10
   10f94:      	and	w1, w11, #0xff
   10f98:      	mov	w8, #0x4                // =4
   10f9c:      	cinc	x0, x19, hi
   10fa0:      	blr	x8
   10fa4:      	ldr	x25, [sp, #0x8]
   10fa8:      	cmp	w23, w21
   10fac:      	str	x19, [sp, #0x60]
   10fb0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   10fb4:      	ldr	x21, [sp, #0x78]
   10fb8:      	ldp	x2, x24, [sp, #0x50]
   10fbc:      	str	x21, [sp, #0x48]
   10fc0:      	b	0x11014 <generic_rawtp_path+0x7f14>
   10fc4:      	add	x2, x24, #0x10
   10fc8:      	mov	w8, #0x4                // =4
   10fcc:      	add	x9, sp, #0x98
   10fd0:      	add	x0, sp, #0x98
   10fd4:      	mov	w1, #0x8                // =8
   10fd8:      	blr	x8
   10fdc:      	ldr	x8, [sp, #0x58]
   10fe0:      	ldr	x9, [sp, #0x98]
   10fe4:      	cmp	x8, x9
   10fe8:      	ldr	x25, [sp, #0x8]
   10fec:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   10ff0:      	add	x2, x24, #0x18
   10ff4:      	mov	w8, #0x4                // =4
   10ff8:      	mov	x0, x22
   10ffc:      	mov	w1, #0x8                // =8
   11000:      	blr	x8
   11004:      	ldr	x24, [sp, #0x98]
   11008:      	ldr	x21, [sp, #0x48]
   1100c:      	add	x2, x24, #0x20
   11010:      	stp	x2, x24, [sp, #0x50]
   11014:      	ldr	x8, [sp, #0x30]
   11018:      	ldr	x25, [sp, #0x8]
   1101c:      	add	x9, sp, #0x70
   11020:      	cmp	x21, x8
   11024:      	b.ne	0x11034 <generic_rawtp_path+0x7f34>
   11028:      	ldr	x8, [sp, #0x38]
   1102c:      	cmp	x2, x8
   11030:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11034:      	mov	w8, #0x4                // =4
   11038:      	add	x0, sp, #0x70
   1103c:      	mov	w1, #0x8                // =8
   11040:      	blr	x8
   11044:      	ldr	x8, [sp, #0x70]
   11048:      	cmp	x21, x8
   1104c:      	b.eq	0x11140 <generic_rawtp_path+0x8040>
   11050:      	add	x23, x21, #0x18
   11054:      	mov	w8, #0x4                // =4
   11058:      	add	x9, sp, #0x98
   1105c:      	add	x0, sp, #0x98
   11060:      	mov	w1, #0x8                // =8
   11064:      	mov	x2, x23
   11068:      	blr	x8
   1106c:      	ldr	x8, [sp, #0x98]
   11070:      	cmp	x8, x21
   11074:      	b.eq	0x11140 <generic_rawtp_path+0x8040>
   11078:      	mov	w8, #0x4                // =4
   1107c:      	add	x9, sp, #0x78
   11080:      	add	x0, sp, #0x78
   11084:      	mov	w1, #0x8                // =8
   11088:      	mov	x2, x23
   1108c:      	blr	x8
   11090:      	add	x2, x21, #0x20
   11094:      	mov	w8, #0x4                // =4
   11098:      	mov	w9, #0x10               // =16
   1109c:      	add	x10, sp, #0x80
   110a0:      	add	x0, sp, #0x80
   110a4:      	mov	w1, #0x10               // =16
   110a8:      	blr	x8
   110ac:      	ldr	w21, [sp, #0x84]
   110b0:      	ldr	x8, [sp, #0x40]
   110b4:      	ldr	x10, [sp, #0x60]
   110b8:      	sub	x12, x10, x8
   110bc:      	ldr	w23, [sp, #0x68]
   110c0:      	subs	w10, w21, w23
   110c4:      	ldr	x9, [sp, #0x88]
   110c8:      	ldr	x25, [sp, #0x8]
   110cc:      	csel	w10, wzr, w10, lo
   110d0:      	cmp	w23, w21
   110d4:      	csel	w11, w23, w21, lo
   110d8:      	cinc	w13, w11, hi
   110dc:      	sub	w14, w23, w13
   110e0:      	subs	x12, x12, x13
   110e4:      	str	w14, [sp, #0x68]
   110e8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   110ec:      	cmp	x12, #0xfff
   110f0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   110f4:      	cmp	w23, w21
   110f8:      	b.ls	0x11104 <generic_rawtp_path+0x8004>
   110fc:      	mov	w13, #0x2f              // =47
   11100:      	strb	w13, [x8, x12]
   11104:      	add	x19, x8, x12
   11108:      	cmp	w23, w21
   1110c:      	add	x2, x9, x10
   11110:      	and	w1, w11, #0xff
   11114:      	mov	w8, #0x4                // =4
   11118:      	cinc	x0, x19, hi
   1111c:      	blr	x8
   11120:      	ldr	x25, [sp, #0x8]
   11124:      	cmp	w23, w21
   11128:      	str	x19, [sp, #0x60]
   1112c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11130:      	ldr	x21, [sp, #0x78]
   11134:      	ldp	x2, x24, [sp, #0x50]
   11138:      	str	x21, [sp, #0x48]
   1113c:      	b	0x11190 <generic_rawtp_path+0x8090>
   11140:      	add	x2, x24, #0x10
   11144:      	mov	w8, #0x4                // =4
   11148:      	add	x9, sp, #0x98
   1114c:      	add	x0, sp, #0x98
   11150:      	mov	w1, #0x8                // =8
   11154:      	blr	x8
   11158:      	ldr	x8, [sp, #0x58]
   1115c:      	ldr	x9, [sp, #0x98]
   11160:      	cmp	x8, x9
   11164:      	ldr	x25, [sp, #0x8]
   11168:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1116c:      	add	x2, x24, #0x18
   11170:      	mov	w8, #0x4                // =4
   11174:      	mov	x0, x22
   11178:      	mov	w1, #0x8                // =8
   1117c:      	blr	x8
   11180:      	ldr	x24, [sp, #0x98]
   11184:      	ldr	x21, [sp, #0x48]
   11188:      	add	x2, x24, #0x20
   1118c:      	stp	x2, x24, [sp, #0x50]
   11190:      	ldr	x8, [sp, #0x30]
   11194:      	ldr	x25, [sp, #0x8]
   11198:      	add	x9, sp, #0x70
   1119c:      	cmp	x21, x8
   111a0:      	b.ne	0x111b0 <generic_rawtp_path+0x80b0>
   111a4:      	ldr	x8, [sp, #0x38]
   111a8:      	cmp	x2, x8
   111ac:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   111b0:      	mov	w8, #0x4                // =4
   111b4:      	add	x0, sp, #0x70
   111b8:      	mov	w1, #0x8                // =8
   111bc:      	blr	x8
   111c0:      	ldr	x8, [sp, #0x70]
   111c4:      	cmp	x21, x8
   111c8:      	b.eq	0x112bc <generic_rawtp_path+0x81bc>
   111cc:      	add	x23, x21, #0x18
   111d0:      	mov	w8, #0x4                // =4
   111d4:      	add	x9, sp, #0x98
   111d8:      	add	x0, sp, #0x98
   111dc:      	mov	w1, #0x8                // =8
   111e0:      	mov	x2, x23
   111e4:      	blr	x8
   111e8:      	ldr	x8, [sp, #0x98]
   111ec:      	cmp	x8, x21
   111f0:      	b.eq	0x112bc <generic_rawtp_path+0x81bc>
   111f4:      	mov	w8, #0x4                // =4
   111f8:      	add	x9, sp, #0x78
   111fc:      	add	x0, sp, #0x78
   11200:      	mov	w1, #0x8                // =8
   11204:      	mov	x2, x23
   11208:      	blr	x8
   1120c:      	add	x2, x21, #0x20
   11210:      	mov	w8, #0x4                // =4
   11214:      	mov	w9, #0x10               // =16
   11218:      	add	x10, sp, #0x80
   1121c:      	add	x0, sp, #0x80
   11220:      	mov	w1, #0x10               // =16
   11224:      	blr	x8
   11228:      	ldr	w21, [sp, #0x84]
   1122c:      	ldr	x8, [sp, #0x40]
   11230:      	ldr	x10, [sp, #0x60]
   11234:      	sub	x12, x10, x8
   11238:      	ldr	w23, [sp, #0x68]
   1123c:      	subs	w10, w21, w23
   11240:      	ldr	x9, [sp, #0x88]
   11244:      	ldr	x25, [sp, #0x8]
   11248:      	csel	w10, wzr, w10, lo
   1124c:      	cmp	w23, w21
   11250:      	csel	w11, w23, w21, lo
   11254:      	cinc	w13, w11, hi
   11258:      	sub	w14, w23, w13
   1125c:      	subs	x12, x12, x13
   11260:      	str	w14, [sp, #0x68]
   11264:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11268:      	cmp	x12, #0xfff
   1126c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11270:      	cmp	w23, w21
   11274:      	b.ls	0x11280 <generic_rawtp_path+0x8180>
   11278:      	mov	w13, #0x2f              // =47
   1127c:      	strb	w13, [x8, x12]
   11280:      	add	x19, x8, x12
   11284:      	cmp	w23, w21
   11288:      	add	x2, x9, x10
   1128c:      	and	w1, w11, #0xff
   11290:      	mov	w8, #0x4                // =4
   11294:      	cinc	x0, x19, hi
   11298:      	blr	x8
   1129c:      	ldr	x25, [sp, #0x8]
   112a0:      	cmp	w23, w21
   112a4:      	str	x19, [sp, #0x60]
   112a8:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   112ac:      	ldr	x21, [sp, #0x78]
   112b0:      	ldp	x2, x24, [sp, #0x50]
   112b4:      	str	x21, [sp, #0x48]
   112b8:      	b	0x1130c <generic_rawtp_path+0x820c>
   112bc:      	add	x2, x24, #0x10
   112c0:      	mov	w8, #0x4                // =4
   112c4:      	add	x9, sp, #0x98
   112c8:      	add	x0, sp, #0x98
   112cc:      	mov	w1, #0x8                // =8
   112d0:      	blr	x8
   112d4:      	ldr	x8, [sp, #0x58]
   112d8:      	ldr	x9, [sp, #0x98]
   112dc:      	cmp	x8, x9
   112e0:      	ldr	x25, [sp, #0x8]
   112e4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   112e8:      	add	x2, x24, #0x18
   112ec:      	mov	w8, #0x4                // =4
   112f0:      	mov	x0, x22
   112f4:      	mov	w1, #0x8                // =8
   112f8:      	blr	x8
   112fc:      	ldr	x24, [sp, #0x98]
   11300:      	ldr	x21, [sp, #0x48]
   11304:      	add	x2, x24, #0x20
   11308:      	stp	x2, x24, [sp, #0x50]
   1130c:      	ldr	x8, [sp, #0x30]
   11310:      	ldr	x25, [sp, #0x8]
   11314:      	add	x9, sp, #0x70
   11318:      	cmp	x21, x8
   1131c:      	b.ne	0x1132c <generic_rawtp_path+0x822c>
   11320:      	ldr	x8, [sp, #0x38]
   11324:      	cmp	x2, x8
   11328:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1132c:      	mov	w8, #0x4                // =4
   11330:      	add	x0, sp, #0x70
   11334:      	mov	w1, #0x8                // =8
   11338:      	blr	x8
   1133c:      	ldr	x8, [sp, #0x70]
   11340:      	cmp	x21, x8
   11344:      	b.eq	0x11438 <generic_rawtp_path+0x8338>
   11348:      	add	x23, x21, #0x18
   1134c:      	mov	w8, #0x4                // =4
   11350:      	add	x9, sp, #0x98
   11354:      	add	x0, sp, #0x98
   11358:      	mov	w1, #0x8                // =8
   1135c:      	mov	x2, x23
   11360:      	blr	x8
   11364:      	ldr	x8, [sp, #0x98]
   11368:      	cmp	x8, x21
   1136c:      	b.eq	0x11438 <generic_rawtp_path+0x8338>
   11370:      	mov	w8, #0x4                // =4
   11374:      	add	x9, sp, #0x78
   11378:      	add	x0, sp, #0x78
   1137c:      	mov	w1, #0x8                // =8
   11380:      	mov	x2, x23
   11384:      	blr	x8
   11388:      	add	x2, x21, #0x20
   1138c:      	mov	w8, #0x4                // =4
   11390:      	mov	w9, #0x10               // =16
   11394:      	add	x10, sp, #0x80
   11398:      	add	x0, sp, #0x80
   1139c:      	mov	w1, #0x10               // =16
   113a0:      	blr	x8
   113a4:      	ldr	w21, [sp, #0x84]
   113a8:      	ldr	x8, [sp, #0x40]
   113ac:      	ldr	x10, [sp, #0x60]
   113b0:      	sub	x12, x10, x8
   113b4:      	ldr	w23, [sp, #0x68]
   113b8:      	subs	w10, w21, w23
   113bc:      	ldr	x9, [sp, #0x88]
   113c0:      	ldr	x25, [sp, #0x8]
   113c4:      	csel	w10, wzr, w10, lo
   113c8:      	cmp	w23, w21
   113cc:      	csel	w11, w23, w21, lo
   113d0:      	cinc	w13, w11, hi
   113d4:      	sub	w14, w23, w13
   113d8:      	subs	x12, x12, x13
   113dc:      	str	w14, [sp, #0x68]
   113e0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   113e4:      	cmp	x12, #0xfff
   113e8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   113ec:      	cmp	w23, w21
   113f0:      	b.ls	0x113fc <generic_rawtp_path+0x82fc>
   113f4:      	mov	w13, #0x2f              // =47
   113f8:      	strb	w13, [x8, x12]
   113fc:      	add	x19, x8, x12
   11400:      	cmp	w23, w21
   11404:      	add	x2, x9, x10
   11408:      	and	w1, w11, #0xff
   1140c:      	mov	w8, #0x4                // =4
   11410:      	cinc	x0, x19, hi
   11414:      	blr	x8
   11418:      	ldr	x25, [sp, #0x8]
   1141c:      	cmp	w23, w21
   11420:      	str	x19, [sp, #0x60]
   11424:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11428:      	ldr	x21, [sp, #0x78]
   1142c:      	ldp	x2, x24, [sp, #0x50]
   11430:      	str	x21, [sp, #0x48]
   11434:      	b	0x11488 <generic_rawtp_path+0x8388>
   11438:      	add	x2, x24, #0x10
   1143c:      	mov	w8, #0x4                // =4
   11440:      	add	x9, sp, #0x98
   11444:      	add	x0, sp, #0x98
   11448:      	mov	w1, #0x8                // =8
   1144c:      	blr	x8
   11450:      	ldr	x8, [sp, #0x58]
   11454:      	ldr	x9, [sp, #0x98]
   11458:      	cmp	x8, x9
   1145c:      	ldr	x25, [sp, #0x8]
   11460:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11464:      	add	x2, x24, #0x18
   11468:      	mov	w8, #0x4                // =4
   1146c:      	mov	x0, x22
   11470:      	mov	w1, #0x8                // =8
   11474:      	blr	x8
   11478:      	ldr	x24, [sp, #0x98]
   1147c:      	ldr	x21, [sp, #0x48]
   11480:      	add	x2, x24, #0x20
   11484:      	stp	x2, x24, [sp, #0x50]
   11488:      	ldr	x8, [sp, #0x30]
   1148c:      	ldr	x25, [sp, #0x8]
   11490:      	add	x9, sp, #0x70
   11494:      	cmp	x21, x8
   11498:      	b.ne	0x114a8 <generic_rawtp_path+0x83a8>
   1149c:      	ldr	x8, [sp, #0x38]
   114a0:      	cmp	x2, x8
   114a4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   114a8:      	mov	w8, #0x4                // =4
   114ac:      	add	x0, sp, #0x70
   114b0:      	mov	w1, #0x8                // =8
   114b4:      	blr	x8
   114b8:      	ldr	x8, [sp, #0x70]
   114bc:      	cmp	x21, x8
   114c0:      	b.eq	0x115b4 <generic_rawtp_path+0x84b4>
   114c4:      	add	x23, x21, #0x18
   114c8:      	mov	w8, #0x4                // =4
   114cc:      	add	x9, sp, #0x98
   114d0:      	add	x0, sp, #0x98
   114d4:      	mov	w1, #0x8                // =8
   114d8:      	mov	x2, x23
   114dc:      	blr	x8
   114e0:      	ldr	x8, [sp, #0x98]
   114e4:      	cmp	x8, x21
   114e8:      	b.eq	0x115b4 <generic_rawtp_path+0x84b4>
   114ec:      	mov	w8, #0x4                // =4
   114f0:      	add	x9, sp, #0x78
   114f4:      	add	x0, sp, #0x78
   114f8:      	mov	w1, #0x8                // =8
   114fc:      	mov	x2, x23
   11500:      	blr	x8
   11504:      	add	x2, x21, #0x20
   11508:      	mov	w8, #0x4                // =4
   1150c:      	mov	w9, #0x10               // =16
   11510:      	add	x10, sp, #0x80
   11514:      	add	x0, sp, #0x80
   11518:      	mov	w1, #0x10               // =16
   1151c:      	blr	x8
   11520:      	ldr	w21, [sp, #0x84]
   11524:      	ldr	x8, [sp, #0x40]
   11528:      	ldr	x10, [sp, #0x60]
   1152c:      	sub	x12, x10, x8
   11530:      	ldr	w23, [sp, #0x68]
   11534:      	subs	w10, w21, w23
   11538:      	ldr	x9, [sp, #0x88]
   1153c:      	ldr	x25, [sp, #0x8]
   11540:      	csel	w10, wzr, w10, lo
   11544:      	cmp	w23, w21
   11548:      	csel	w11, w23, w21, lo
   1154c:      	cinc	w13, w11, hi
   11550:      	sub	w14, w23, w13
   11554:      	subs	x12, x12, x13
   11558:      	str	w14, [sp, #0x68]
   1155c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11560:      	cmp	x12, #0xfff
   11564:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11568:      	cmp	w23, w21
   1156c:      	b.ls	0x11578 <generic_rawtp_path+0x8478>
   11570:      	mov	w13, #0x2f              // =47
   11574:      	strb	w13, [x8, x12]
   11578:      	add	x19, x8, x12
   1157c:      	cmp	w23, w21
   11580:      	add	x2, x9, x10
   11584:      	and	w1, w11, #0xff
   11588:      	mov	w8, #0x4                // =4
   1158c:      	cinc	x0, x19, hi
   11590:      	blr	x8
   11594:      	ldr	x25, [sp, #0x8]
   11598:      	cmp	w23, w21
   1159c:      	str	x19, [sp, #0x60]
   115a0:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   115a4:      	ldr	x21, [sp, #0x78]
   115a8:      	ldp	x2, x24, [sp, #0x50]
   115ac:      	str	x21, [sp, #0x48]
   115b0:      	b	0x11604 <generic_rawtp_path+0x8504>
   115b4:      	add	x2, x24, #0x10
   115b8:      	mov	w8, #0x4                // =4
   115bc:      	add	x9, sp, #0x98
   115c0:      	add	x0, sp, #0x98
   115c4:      	mov	w1, #0x8                // =8
   115c8:      	blr	x8
   115cc:      	ldr	x8, [sp, #0x58]
   115d0:      	ldr	x9, [sp, #0x98]
   115d4:      	cmp	x8, x9
   115d8:      	ldr	x25, [sp, #0x8]
   115dc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   115e0:      	add	x2, x24, #0x18
   115e4:      	mov	w8, #0x4                // =4
   115e8:      	mov	x0, x22
   115ec:      	mov	w1, #0x8                // =8
   115f0:      	blr	x8
   115f4:      	ldr	x24, [sp, #0x98]
   115f8:      	ldr	x21, [sp, #0x48]
   115fc:      	add	x2, x24, #0x20
   11600:      	stp	x2, x24, [sp, #0x50]
   11604:      	ldr	x8, [sp, #0x30]
   11608:      	ldr	x25, [sp, #0x8]
   1160c:      	add	x9, sp, #0x70
   11610:      	cmp	x21, x8
   11614:      	b.ne	0x11624 <generic_rawtp_path+0x8524>
   11618:      	ldr	x8, [sp, #0x38]
   1161c:      	cmp	x2, x8
   11620:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11624:      	mov	w8, #0x4                // =4
   11628:      	add	x0, sp, #0x70
   1162c:      	mov	w1, #0x8                // =8
   11630:      	blr	x8
   11634:      	ldr	x8, [sp, #0x70]
   11638:      	cmp	x21, x8
   1163c:      	b.eq	0x11730 <generic_rawtp_path+0x8630>
   11640:      	add	x23, x21, #0x18
   11644:      	mov	w8, #0x4                // =4
   11648:      	add	x9, sp, #0x98
   1164c:      	add	x0, sp, #0x98
   11650:      	mov	w1, #0x8                // =8
   11654:      	mov	x2, x23
   11658:      	blr	x8
   1165c:      	ldr	x8, [sp, #0x98]
   11660:      	cmp	x8, x21
   11664:      	b.eq	0x11730 <generic_rawtp_path+0x8630>
   11668:      	mov	w8, #0x4                // =4
   1166c:      	add	x9, sp, #0x78
   11670:      	add	x0, sp, #0x78
   11674:      	mov	w1, #0x8                // =8
   11678:      	mov	x2, x23
   1167c:      	blr	x8
   11680:      	add	x2, x21, #0x20
   11684:      	mov	w8, #0x4                // =4
   11688:      	mov	w9, #0x10               // =16
   1168c:      	add	x10, sp, #0x80
   11690:      	add	x0, sp, #0x80
   11694:      	mov	w1, #0x10               // =16
   11698:      	blr	x8
   1169c:      	ldr	w21, [sp, #0x84]
   116a0:      	ldr	x8, [sp, #0x40]
   116a4:      	ldr	x10, [sp, #0x60]
   116a8:      	sub	x12, x10, x8
   116ac:      	ldr	w23, [sp, #0x68]
   116b0:      	subs	w10, w21, w23
   116b4:      	ldr	x9, [sp, #0x88]
   116b8:      	ldr	x25, [sp, #0x8]
   116bc:      	csel	w10, wzr, w10, lo
   116c0:      	cmp	w23, w21
   116c4:      	csel	w11, w23, w21, lo
   116c8:      	cinc	w13, w11, hi
   116cc:      	sub	w14, w23, w13
   116d0:      	subs	x12, x12, x13
   116d4:      	str	w14, [sp, #0x68]
   116d8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   116dc:      	cmp	x12, #0xfff
   116e0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   116e4:      	cmp	w23, w21
   116e8:      	b.ls	0x116f4 <generic_rawtp_path+0x85f4>
   116ec:      	mov	w13, #0x2f              // =47
   116f0:      	strb	w13, [x8, x12]
   116f4:      	add	x19, x8, x12
   116f8:      	cmp	w23, w21
   116fc:      	add	x2, x9, x10
   11700:      	and	w1, w11, #0xff
   11704:      	mov	w8, #0x4                // =4
   11708:      	cinc	x0, x19, hi
   1170c:      	blr	x8
   11710:      	ldr	x25, [sp, #0x8]
   11714:      	cmp	w23, w21
   11718:      	str	x19, [sp, #0x60]
   1171c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11720:      	ldr	x21, [sp, #0x78]
   11724:      	ldp	x2, x24, [sp, #0x50]
   11728:      	str	x21, [sp, #0x48]
   1172c:      	b	0x11780 <generic_rawtp_path+0x8680>
   11730:      	add	x2, x24, #0x10
   11734:      	mov	w8, #0x4                // =4
   11738:      	add	x9, sp, #0x98
   1173c:      	add	x0, sp, #0x98
   11740:      	mov	w1, #0x8                // =8
   11744:      	blr	x8
   11748:      	ldr	x8, [sp, #0x58]
   1174c:      	ldr	x9, [sp, #0x98]
   11750:      	cmp	x8, x9
   11754:      	ldr	x25, [sp, #0x8]
   11758:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1175c:      	add	x2, x24, #0x18
   11760:      	mov	w8, #0x4                // =4
   11764:      	mov	x0, x22
   11768:      	mov	w1, #0x8                // =8
   1176c:      	blr	x8
   11770:      	ldr	x24, [sp, #0x98]
   11774:      	ldr	x21, [sp, #0x48]
   11778:      	add	x2, x24, #0x20
   1177c:      	stp	x2, x24, [sp, #0x50]
   11780:      	ldr	x8, [sp, #0x30]
   11784:      	ldr	x25, [sp, #0x8]
   11788:      	add	x9, sp, #0x70
   1178c:      	cmp	x21, x8
   11790:      	b.ne	0x117a0 <generic_rawtp_path+0x86a0>
   11794:      	ldr	x8, [sp, #0x38]
   11798:      	cmp	x2, x8
   1179c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   117a0:      	mov	w8, #0x4                // =4
   117a4:      	add	x0, sp, #0x70
   117a8:      	mov	w1, #0x8                // =8
   117ac:      	blr	x8
   117b0:      	ldr	x8, [sp, #0x70]
   117b4:      	cmp	x21, x8
   117b8:      	b.eq	0x118ac <generic_rawtp_path+0x87ac>
   117bc:      	add	x23, x21, #0x18
   117c0:      	mov	w8, #0x4                // =4
   117c4:      	add	x9, sp, #0x98
   117c8:      	add	x0, sp, #0x98
   117cc:      	mov	w1, #0x8                // =8
   117d0:      	mov	x2, x23
   117d4:      	blr	x8
   117d8:      	ldr	x8, [sp, #0x98]
   117dc:      	cmp	x8, x21
   117e0:      	b.eq	0x118ac <generic_rawtp_path+0x87ac>
   117e4:      	mov	w8, #0x4                // =4
   117e8:      	add	x9, sp, #0x78
   117ec:      	add	x0, sp, #0x78
   117f0:      	mov	w1, #0x8                // =8
   117f4:      	mov	x2, x23
   117f8:      	blr	x8
   117fc:      	add	x2, x21, #0x20
   11800:      	mov	w8, #0x4                // =4
   11804:      	mov	w9, #0x10               // =16
   11808:      	add	x10, sp, #0x80
   1180c:      	add	x0, sp, #0x80
   11810:      	mov	w1, #0x10               // =16
   11814:      	blr	x8
   11818:      	ldr	w21, [sp, #0x84]
   1181c:      	ldr	x8, [sp, #0x40]
   11820:      	ldr	x10, [sp, #0x60]
   11824:      	sub	x12, x10, x8
   11828:      	ldr	w23, [sp, #0x68]
   1182c:      	subs	w10, w21, w23
   11830:      	ldr	x9, [sp, #0x88]
   11834:      	ldr	x25, [sp, #0x8]
   11838:      	csel	w10, wzr, w10, lo
   1183c:      	cmp	w23, w21
   11840:      	csel	w11, w23, w21, lo
   11844:      	cinc	w13, w11, hi
   11848:      	sub	w14, w23, w13
   1184c:      	subs	x12, x12, x13
   11850:      	str	w14, [sp, #0x68]
   11854:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11858:      	cmp	x12, #0xfff
   1185c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11860:      	cmp	w23, w21
   11864:      	b.ls	0x11870 <generic_rawtp_path+0x8770>
   11868:      	mov	w13, #0x2f              // =47
   1186c:      	strb	w13, [x8, x12]
   11870:      	add	x19, x8, x12
   11874:      	cmp	w23, w21
   11878:      	add	x2, x9, x10
   1187c:      	and	w1, w11, #0xff
   11880:      	mov	w8, #0x4                // =4
   11884:      	cinc	x0, x19, hi
   11888:      	blr	x8
   1188c:      	ldr	x25, [sp, #0x8]
   11890:      	cmp	w23, w21
   11894:      	str	x19, [sp, #0x60]
   11898:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1189c:      	ldr	x21, [sp, #0x78]
   118a0:      	ldp	x2, x24, [sp, #0x50]
   118a4:      	str	x21, [sp, #0x48]
   118a8:      	b	0x118fc <generic_rawtp_path+0x87fc>
   118ac:      	add	x2, x24, #0x10
   118b0:      	mov	w8, #0x4                // =4
   118b4:      	add	x9, sp, #0x98
   118b8:      	add	x0, sp, #0x98
   118bc:      	mov	w1, #0x8                // =8
   118c0:      	blr	x8
   118c4:      	ldr	x8, [sp, #0x58]
   118c8:      	ldr	x9, [sp, #0x98]
   118cc:      	cmp	x8, x9
   118d0:      	ldr	x25, [sp, #0x8]
   118d4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   118d8:      	add	x2, x24, #0x18
   118dc:      	mov	w8, #0x4                // =4
   118e0:      	mov	x0, x22
   118e4:      	mov	w1, #0x8                // =8
   118e8:      	blr	x8
   118ec:      	ldr	x24, [sp, #0x98]
   118f0:      	ldr	x21, [sp, #0x48]
   118f4:      	add	x2, x24, #0x20
   118f8:      	stp	x2, x24, [sp, #0x50]
   118fc:      	ldr	x8, [sp, #0x30]
   11900:      	ldr	x25, [sp, #0x8]
   11904:      	add	x9, sp, #0x70
   11908:      	cmp	x21, x8
   1190c:      	b.ne	0x1191c <generic_rawtp_path+0x881c>
   11910:      	ldr	x8, [sp, #0x38]
   11914:      	cmp	x2, x8
   11918:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1191c:      	mov	w8, #0x4                // =4
   11920:      	add	x0, sp, #0x70
   11924:      	mov	w1, #0x8                // =8
   11928:      	blr	x8
   1192c:      	ldr	x8, [sp, #0x70]
   11930:      	cmp	x21, x8
   11934:      	b.eq	0x11a28 <generic_rawtp_path+0x8928>
   11938:      	add	x23, x21, #0x18
   1193c:      	mov	w8, #0x4                // =4
   11940:      	add	x9, sp, #0x98
   11944:      	add	x0, sp, #0x98
   11948:      	mov	w1, #0x8                // =8
   1194c:      	mov	x2, x23
   11950:      	blr	x8
   11954:      	ldr	x8, [sp, #0x98]
   11958:      	cmp	x8, x21
   1195c:      	b.eq	0x11a28 <generic_rawtp_path+0x8928>
   11960:      	mov	w8, #0x4                // =4
   11964:      	add	x9, sp, #0x78
   11968:      	add	x0, sp, #0x78
   1196c:      	mov	w1, #0x8                // =8
   11970:      	mov	x2, x23
   11974:      	blr	x8
   11978:      	add	x2, x21, #0x20
   1197c:      	mov	w8, #0x4                // =4
   11980:      	mov	w9, #0x10               // =16
   11984:      	add	x10, sp, #0x80
   11988:      	add	x0, sp, #0x80
   1198c:      	mov	w1, #0x10               // =16
   11990:      	blr	x8
   11994:      	ldr	w21, [sp, #0x84]
   11998:      	ldr	x8, [sp, #0x40]
   1199c:      	ldr	x10, [sp, #0x60]
   119a0:      	sub	x12, x10, x8
   119a4:      	ldr	w23, [sp, #0x68]
   119a8:      	subs	w10, w21, w23
   119ac:      	ldr	x9, [sp, #0x88]
   119b0:      	ldr	x25, [sp, #0x8]
   119b4:      	csel	w10, wzr, w10, lo
   119b8:      	cmp	w23, w21
   119bc:      	csel	w11, w23, w21, lo
   119c0:      	cinc	w13, w11, hi
   119c4:      	sub	w14, w23, w13
   119c8:      	subs	x12, x12, x13
   119cc:      	str	w14, [sp, #0x68]
   119d0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   119d4:      	cmp	x12, #0xfff
   119d8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   119dc:      	cmp	w23, w21
   119e0:      	b.ls	0x119ec <generic_rawtp_path+0x88ec>
   119e4:      	mov	w13, #0x2f              // =47
   119e8:      	strb	w13, [x8, x12]
   119ec:      	add	x19, x8, x12
   119f0:      	cmp	w23, w21
   119f4:      	add	x2, x9, x10
   119f8:      	and	w1, w11, #0xff
   119fc:      	mov	w8, #0x4                // =4
   11a00:      	cinc	x0, x19, hi
   11a04:      	blr	x8
   11a08:      	ldr	x25, [sp, #0x8]
   11a0c:      	cmp	w23, w21
   11a10:      	str	x19, [sp, #0x60]
   11a14:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11a18:      	ldr	x21, [sp, #0x78]
   11a1c:      	ldp	x2, x24, [sp, #0x50]
   11a20:      	str	x21, [sp, #0x48]
   11a24:      	b	0x11a78 <generic_rawtp_path+0x8978>
   11a28:      	add	x2, x24, #0x10
   11a2c:      	mov	w8, #0x4                // =4
   11a30:      	add	x9, sp, #0x98
   11a34:      	add	x0, sp, #0x98
   11a38:      	mov	w1, #0x8                // =8
   11a3c:      	blr	x8
   11a40:      	ldr	x8, [sp, #0x58]
   11a44:      	ldr	x9, [sp, #0x98]
   11a48:      	cmp	x8, x9
   11a4c:      	ldr	x25, [sp, #0x8]
   11a50:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11a54:      	add	x2, x24, #0x18
   11a58:      	mov	w8, #0x4                // =4
   11a5c:      	mov	x0, x22
   11a60:      	mov	w1, #0x8                // =8
   11a64:      	blr	x8
   11a68:      	ldr	x24, [sp, #0x98]
   11a6c:      	ldr	x21, [sp, #0x48]
   11a70:      	add	x2, x24, #0x20
   11a74:      	stp	x2, x24, [sp, #0x50]
   11a78:      	ldr	x8, [sp, #0x30]
   11a7c:      	ldr	x25, [sp, #0x8]
   11a80:      	add	x9, sp, #0x70
   11a84:      	cmp	x21, x8
   11a88:      	b.ne	0x11a98 <generic_rawtp_path+0x8998>
   11a8c:      	ldr	x8, [sp, #0x38]
   11a90:      	cmp	x2, x8
   11a94:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11a98:      	mov	w8, #0x4                // =4
   11a9c:      	add	x0, sp, #0x70
   11aa0:      	mov	w1, #0x8                // =8
   11aa4:      	blr	x8
   11aa8:      	ldr	x8, [sp, #0x70]
   11aac:      	cmp	x21, x8
   11ab0:      	b.eq	0x11ba4 <generic_rawtp_path+0x8aa4>
   11ab4:      	add	x23, x21, #0x18
   11ab8:      	mov	w8, #0x4                // =4
   11abc:      	add	x9, sp, #0x98
   11ac0:      	add	x0, sp, #0x98
   11ac4:      	mov	w1, #0x8                // =8
   11ac8:      	mov	x2, x23
   11acc:      	blr	x8
   11ad0:      	ldr	x8, [sp, #0x98]
   11ad4:      	cmp	x8, x21
   11ad8:      	b.eq	0x11ba4 <generic_rawtp_path+0x8aa4>
   11adc:      	mov	w8, #0x4                // =4
   11ae0:      	add	x9, sp, #0x78
   11ae4:      	add	x0, sp, #0x78
   11ae8:      	mov	w1, #0x8                // =8
   11aec:      	mov	x2, x23
   11af0:      	blr	x8
   11af4:      	add	x2, x21, #0x20
   11af8:      	mov	w8, #0x4                // =4
   11afc:      	mov	w9, #0x10               // =16
   11b00:      	add	x10, sp, #0x80
   11b04:      	add	x0, sp, #0x80
   11b08:      	mov	w1, #0x10               // =16
   11b0c:      	blr	x8
   11b10:      	ldr	w21, [sp, #0x84]
   11b14:      	ldr	x8, [sp, #0x40]
   11b18:      	ldr	x10, [sp, #0x60]
   11b1c:      	sub	x12, x10, x8
   11b20:      	ldr	w23, [sp, #0x68]
   11b24:      	subs	w10, w21, w23
   11b28:      	ldr	x9, [sp, #0x88]
   11b2c:      	ldr	x25, [sp, #0x8]
   11b30:      	csel	w10, wzr, w10, lo
   11b34:      	cmp	w23, w21
   11b38:      	csel	w11, w23, w21, lo
   11b3c:      	cinc	w13, w11, hi
   11b40:      	sub	w14, w23, w13
   11b44:      	subs	x12, x12, x13
   11b48:      	str	w14, [sp, #0x68]
   11b4c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11b50:      	cmp	x12, #0xfff
   11b54:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11b58:      	cmp	w23, w21
   11b5c:      	b.ls	0x11b68 <generic_rawtp_path+0x8a68>
   11b60:      	mov	w13, #0x2f              // =47
   11b64:      	strb	w13, [x8, x12]
   11b68:      	add	x19, x8, x12
   11b6c:      	cmp	w23, w21
   11b70:      	add	x2, x9, x10
   11b74:      	and	w1, w11, #0xff
   11b78:      	mov	w8, #0x4                // =4
   11b7c:      	cinc	x0, x19, hi
   11b80:      	blr	x8
   11b84:      	ldr	x25, [sp, #0x8]
   11b88:      	cmp	w23, w21
   11b8c:      	str	x19, [sp, #0x60]
   11b90:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11b94:      	ldr	x21, [sp, #0x78]
   11b98:      	ldp	x2, x24, [sp, #0x50]
   11b9c:      	str	x21, [sp, #0x48]
   11ba0:      	b	0x11bf4 <generic_rawtp_path+0x8af4>
   11ba4:      	add	x2, x24, #0x10
   11ba8:      	mov	w8, #0x4                // =4
   11bac:      	add	x9, sp, #0x98
   11bb0:      	add	x0, sp, #0x98
   11bb4:      	mov	w1, #0x8                // =8
   11bb8:      	blr	x8
   11bbc:      	ldr	x8, [sp, #0x58]
   11bc0:      	ldr	x9, [sp, #0x98]
   11bc4:      	cmp	x8, x9
   11bc8:      	ldr	x25, [sp, #0x8]
   11bcc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11bd0:      	add	x2, x24, #0x18
   11bd4:      	mov	w8, #0x4                // =4
   11bd8:      	mov	x0, x22
   11bdc:      	mov	w1, #0x8                // =8
   11be0:      	blr	x8
   11be4:      	ldr	x24, [sp, #0x98]
   11be8:      	ldr	x21, [sp, #0x48]
   11bec:      	add	x2, x24, #0x20
   11bf0:      	stp	x2, x24, [sp, #0x50]
   11bf4:      	ldr	x8, [sp, #0x30]
   11bf8:      	ldr	x25, [sp, #0x8]
   11bfc:      	add	x9, sp, #0x70
   11c00:      	cmp	x21, x8
   11c04:      	b.ne	0x11c14 <generic_rawtp_path+0x8b14>
   11c08:      	ldr	x8, [sp, #0x38]
   11c0c:      	cmp	x2, x8
   11c10:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11c14:      	mov	w8, #0x4                // =4
   11c18:      	add	x0, sp, #0x70
   11c1c:      	mov	w1, #0x8                // =8
   11c20:      	blr	x8
   11c24:      	ldr	x8, [sp, #0x70]
   11c28:      	cmp	x21, x8
   11c2c:      	b.eq	0x11d20 <generic_rawtp_path+0x8c20>
   11c30:      	add	x23, x21, #0x18
   11c34:      	mov	w8, #0x4                // =4
   11c38:      	add	x9, sp, #0x98
   11c3c:      	add	x0, sp, #0x98
   11c40:      	mov	w1, #0x8                // =8
   11c44:      	mov	x2, x23
   11c48:      	blr	x8
   11c4c:      	ldr	x8, [sp, #0x98]
   11c50:      	cmp	x8, x21
   11c54:      	b.eq	0x11d20 <generic_rawtp_path+0x8c20>
   11c58:      	mov	w8, #0x4                // =4
   11c5c:      	add	x9, sp, #0x78
   11c60:      	add	x0, sp, #0x78
   11c64:      	mov	w1, #0x8                // =8
   11c68:      	mov	x2, x23
   11c6c:      	blr	x8
   11c70:      	add	x2, x21, #0x20
   11c74:      	mov	w8, #0x4                // =4
   11c78:      	mov	w9, #0x10               // =16
   11c7c:      	add	x10, sp, #0x80
   11c80:      	add	x0, sp, #0x80
   11c84:      	mov	w1, #0x10               // =16
   11c88:      	blr	x8
   11c8c:      	ldr	w21, [sp, #0x84]
   11c90:      	ldr	x8, [sp, #0x40]
   11c94:      	ldr	x10, [sp, #0x60]
   11c98:      	sub	x12, x10, x8
   11c9c:      	ldr	w23, [sp, #0x68]
   11ca0:      	subs	w10, w21, w23
   11ca4:      	ldr	x9, [sp, #0x88]
   11ca8:      	ldr	x25, [sp, #0x8]
   11cac:      	csel	w10, wzr, w10, lo
   11cb0:      	cmp	w23, w21
   11cb4:      	csel	w11, w23, w21, lo
   11cb8:      	cinc	w13, w11, hi
   11cbc:      	sub	w14, w23, w13
   11cc0:      	subs	x12, x12, x13
   11cc4:      	str	w14, [sp, #0x68]
   11cc8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11ccc:      	cmp	x12, #0xfff
   11cd0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11cd4:      	cmp	w23, w21
   11cd8:      	b.ls	0x11ce4 <generic_rawtp_path+0x8be4>
   11cdc:      	mov	w13, #0x2f              // =47
   11ce0:      	strb	w13, [x8, x12]
   11ce4:      	add	x19, x8, x12
   11ce8:      	cmp	w23, w21
   11cec:      	add	x2, x9, x10
   11cf0:      	and	w1, w11, #0xff
   11cf4:      	mov	w8, #0x4                // =4
   11cf8:      	cinc	x0, x19, hi
   11cfc:      	blr	x8
   11d00:      	ldr	x25, [sp, #0x8]
   11d04:      	cmp	w23, w21
   11d08:      	str	x19, [sp, #0x60]
   11d0c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11d10:      	ldr	x21, [sp, #0x78]
   11d14:      	ldp	x2, x24, [sp, #0x50]
   11d18:      	str	x21, [sp, #0x48]
   11d1c:      	b	0x11d70 <generic_rawtp_path+0x8c70>
   11d20:      	add	x2, x24, #0x10
   11d24:      	mov	w8, #0x4                // =4
   11d28:      	add	x9, sp, #0x98
   11d2c:      	add	x0, sp, #0x98
   11d30:      	mov	w1, #0x8                // =8
   11d34:      	blr	x8
   11d38:      	ldr	x8, [sp, #0x58]
   11d3c:      	ldr	x9, [sp, #0x98]
   11d40:      	cmp	x8, x9
   11d44:      	ldr	x25, [sp, #0x8]
   11d48:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11d4c:      	add	x2, x24, #0x18
   11d50:      	mov	w8, #0x4                // =4
   11d54:      	mov	x0, x22
   11d58:      	mov	w1, #0x8                // =8
   11d5c:      	blr	x8
   11d60:      	ldr	x24, [sp, #0x98]
   11d64:      	ldr	x21, [sp, #0x48]
   11d68:      	add	x2, x24, #0x20
   11d6c:      	stp	x2, x24, [sp, #0x50]
   11d70:      	ldr	x8, [sp, #0x30]
   11d74:      	ldr	x25, [sp, #0x8]
   11d78:      	add	x9, sp, #0x70
   11d7c:      	cmp	x21, x8
   11d80:      	b.ne	0x11d90 <generic_rawtp_path+0x8c90>
   11d84:      	ldr	x8, [sp, #0x38]
   11d88:      	cmp	x2, x8
   11d8c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11d90:      	mov	w8, #0x4                // =4
   11d94:      	add	x0, sp, #0x70
   11d98:      	mov	w1, #0x8                // =8
   11d9c:      	blr	x8
   11da0:      	ldr	x8, [sp, #0x70]
   11da4:      	cmp	x21, x8
   11da8:      	b.eq	0x11e9c <generic_rawtp_path+0x8d9c>
   11dac:      	add	x23, x21, #0x18
   11db0:      	mov	w8, #0x4                // =4
   11db4:      	add	x9, sp, #0x98
   11db8:      	add	x0, sp, #0x98
   11dbc:      	mov	w1, #0x8                // =8
   11dc0:      	mov	x2, x23
   11dc4:      	blr	x8
   11dc8:      	ldr	x8, [sp, #0x98]
   11dcc:      	cmp	x8, x21
   11dd0:      	b.eq	0x11e9c <generic_rawtp_path+0x8d9c>
   11dd4:      	mov	w8, #0x4                // =4
   11dd8:      	add	x9, sp, #0x78
   11ddc:      	add	x0, sp, #0x78
   11de0:      	mov	w1, #0x8                // =8
   11de4:      	mov	x2, x23
   11de8:      	blr	x8
   11dec:      	add	x2, x21, #0x20
   11df0:      	mov	w8, #0x4                // =4
   11df4:      	mov	w9, #0x10               // =16
   11df8:      	add	x10, sp, #0x80
   11dfc:      	add	x0, sp, #0x80
   11e00:      	mov	w1, #0x10               // =16
   11e04:      	blr	x8
   11e08:      	ldr	w21, [sp, #0x84]
   11e0c:      	ldr	x8, [sp, #0x40]
   11e10:      	ldr	x10, [sp, #0x60]
   11e14:      	sub	x12, x10, x8
   11e18:      	ldr	w23, [sp, #0x68]
   11e1c:      	subs	w10, w21, w23
   11e20:      	ldr	x9, [sp, #0x88]
   11e24:      	ldr	x25, [sp, #0x8]
   11e28:      	csel	w10, wzr, w10, lo
   11e2c:      	cmp	w23, w21
   11e30:      	csel	w11, w23, w21, lo
   11e34:      	cinc	w13, w11, hi
   11e38:      	sub	w14, w23, w13
   11e3c:      	subs	x12, x12, x13
   11e40:      	str	w14, [sp, #0x68]
   11e44:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11e48:      	cmp	x12, #0xfff
   11e4c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11e50:      	cmp	w23, w21
   11e54:      	b.ls	0x11e60 <generic_rawtp_path+0x8d60>
   11e58:      	mov	w13, #0x2f              // =47
   11e5c:      	strb	w13, [x8, x12]
   11e60:      	add	x19, x8, x12
   11e64:      	cmp	w23, w21
   11e68:      	add	x2, x9, x10
   11e6c:      	and	w1, w11, #0xff
   11e70:      	mov	w8, #0x4                // =4
   11e74:      	cinc	x0, x19, hi
   11e78:      	blr	x8
   11e7c:      	ldr	x25, [sp, #0x8]
   11e80:      	cmp	w23, w21
   11e84:      	str	x19, [sp, #0x60]
   11e88:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   11e8c:      	ldr	x21, [sp, #0x78]
   11e90:      	ldp	x2, x24, [sp, #0x50]
   11e94:      	str	x21, [sp, #0x48]
   11e98:      	b	0x11eec <generic_rawtp_path+0x8dec>
   11e9c:      	add	x2, x24, #0x10
   11ea0:      	mov	w8, #0x4                // =4
   11ea4:      	add	x9, sp, #0x98
   11ea8:      	add	x0, sp, #0x98
   11eac:      	mov	w1, #0x8                // =8
   11eb0:      	blr	x8
   11eb4:      	ldr	x8, [sp, #0x58]
   11eb8:      	ldr	x9, [sp, #0x98]
   11ebc:      	cmp	x8, x9
   11ec0:      	ldr	x25, [sp, #0x8]
   11ec4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11ec8:      	add	x2, x24, #0x18
   11ecc:      	mov	w8, #0x4                // =4
   11ed0:      	mov	x0, x22
   11ed4:      	mov	w1, #0x8                // =8
   11ed8:      	blr	x8
   11edc:      	ldr	x24, [sp, #0x98]
   11ee0:      	ldr	x21, [sp, #0x48]
   11ee4:      	add	x2, x24, #0x20
   11ee8:      	stp	x2, x24, [sp, #0x50]
   11eec:      	ldr	x8, [sp, #0x30]
   11ef0:      	ldr	x25, [sp, #0x8]
   11ef4:      	add	x9, sp, #0x70
   11ef8:      	cmp	x21, x8
   11efc:      	b.ne	0x11f0c <generic_rawtp_path+0x8e0c>
   11f00:      	ldr	x8, [sp, #0x38]
   11f04:      	cmp	x2, x8
   11f08:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   11f0c:      	mov	w8, #0x4                // =4
   11f10:      	add	x0, sp, #0x70
   11f14:      	mov	w1, #0x8                // =8
   11f18:      	blr	x8
   11f1c:      	ldr	x8, [sp, #0x70]
   11f20:      	cmp	x21, x8
   11f24:      	b.eq	0x12018 <generic_rawtp_path+0x8f18>
   11f28:      	add	x23, x21, #0x18
   11f2c:      	mov	w8, #0x4                // =4
   11f30:      	add	x9, sp, #0x98
   11f34:      	add	x0, sp, #0x98
   11f38:      	mov	w1, #0x8                // =8
   11f3c:      	mov	x2, x23
   11f40:      	blr	x8
   11f44:      	ldr	x8, [sp, #0x98]
   11f48:      	cmp	x8, x21
   11f4c:      	b.eq	0x12018 <generic_rawtp_path+0x8f18>
   11f50:      	mov	w8, #0x4                // =4
   11f54:      	add	x9, sp, #0x78
   11f58:      	add	x0, sp, #0x78
   11f5c:      	mov	w1, #0x8                // =8
   11f60:      	mov	x2, x23
   11f64:      	blr	x8
   11f68:      	add	x2, x21, #0x20
   11f6c:      	mov	w8, #0x4                // =4
   11f70:      	mov	w9, #0x10               // =16
   11f74:      	add	x10, sp, #0x80
   11f78:      	add	x0, sp, #0x80
   11f7c:      	mov	w1, #0x10               // =16
   11f80:      	blr	x8
   11f84:      	ldr	w21, [sp, #0x84]
   11f88:      	ldr	x8, [sp, #0x40]
   11f8c:      	ldr	x10, [sp, #0x60]
   11f90:      	sub	x12, x10, x8
   11f94:      	ldr	w23, [sp, #0x68]
   11f98:      	subs	w10, w21, w23
   11f9c:      	ldr	x9, [sp, #0x88]
   11fa0:      	ldr	x25, [sp, #0x8]
   11fa4:      	csel	w10, wzr, w10, lo
   11fa8:      	cmp	w23, w21
   11fac:      	csel	w11, w23, w21, lo
   11fb0:      	cinc	w13, w11, hi
   11fb4:      	sub	w14, w23, w13
   11fb8:      	subs	x12, x12, x13
   11fbc:      	str	w14, [sp, #0x68]
   11fc0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   11fc4:      	cmp	x12, #0xfff
   11fc8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   11fcc:      	cmp	w23, w21
   11fd0:      	b.ls	0x11fdc <generic_rawtp_path+0x8edc>
   11fd4:      	mov	w13, #0x2f              // =47
   11fd8:      	strb	w13, [x8, x12]
   11fdc:      	add	x19, x8, x12
   11fe0:      	cmp	w23, w21
   11fe4:      	add	x2, x9, x10
   11fe8:      	and	w1, w11, #0xff
   11fec:      	mov	w8, #0x4                // =4
   11ff0:      	cinc	x0, x19, hi
   11ff4:      	blr	x8
   11ff8:      	ldr	x25, [sp, #0x8]
   11ffc:      	cmp	w23, w21
   12000:      	str	x19, [sp, #0x60]
   12004:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12008:      	ldr	x21, [sp, #0x78]
   1200c:      	ldp	x2, x24, [sp, #0x50]
   12010:      	str	x21, [sp, #0x48]
   12014:      	b	0x12068 <generic_rawtp_path+0x8f68>
   12018:      	add	x2, x24, #0x10
   1201c:      	mov	w8, #0x4                // =4
   12020:      	add	x9, sp, #0x98
   12024:      	add	x0, sp, #0x98
   12028:      	mov	w1, #0x8                // =8
   1202c:      	blr	x8
   12030:      	ldr	x8, [sp, #0x58]
   12034:      	ldr	x9, [sp, #0x98]
   12038:      	cmp	x8, x9
   1203c:      	ldr	x25, [sp, #0x8]
   12040:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12044:      	add	x2, x24, #0x18
   12048:      	mov	w8, #0x4                // =4
   1204c:      	mov	x0, x22
   12050:      	mov	w1, #0x8                // =8
   12054:      	blr	x8
   12058:      	ldr	x24, [sp, #0x98]
   1205c:      	ldr	x21, [sp, #0x48]
   12060:      	add	x2, x24, #0x20
   12064:      	stp	x2, x24, [sp, #0x50]
   12068:      	ldr	x8, [sp, #0x30]
   1206c:      	ldr	x25, [sp, #0x8]
   12070:      	add	x9, sp, #0x70
   12074:      	cmp	x21, x8
   12078:      	b.ne	0x12088 <generic_rawtp_path+0x8f88>
   1207c:      	ldr	x8, [sp, #0x38]
   12080:      	cmp	x2, x8
   12084:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12088:      	mov	w8, #0x4                // =4
   1208c:      	add	x0, sp, #0x70
   12090:      	mov	w1, #0x8                // =8
   12094:      	blr	x8
   12098:      	ldr	x8, [sp, #0x70]
   1209c:      	cmp	x21, x8
   120a0:      	b.eq	0x12194 <generic_rawtp_path+0x9094>
   120a4:      	add	x23, x21, #0x18
   120a8:      	mov	w8, #0x4                // =4
   120ac:      	add	x9, sp, #0x98
   120b0:      	add	x0, sp, #0x98
   120b4:      	mov	w1, #0x8                // =8
   120b8:      	mov	x2, x23
   120bc:      	blr	x8
   120c0:      	ldr	x8, [sp, #0x98]
   120c4:      	cmp	x8, x21
   120c8:      	b.eq	0x12194 <generic_rawtp_path+0x9094>
   120cc:      	mov	w8, #0x4                // =4
   120d0:      	add	x9, sp, #0x78
   120d4:      	add	x0, sp, #0x78
   120d8:      	mov	w1, #0x8                // =8
   120dc:      	mov	x2, x23
   120e0:      	blr	x8
   120e4:      	add	x2, x21, #0x20
   120e8:      	mov	w8, #0x4                // =4
   120ec:      	mov	w9, #0x10               // =16
   120f0:      	add	x10, sp, #0x80
   120f4:      	add	x0, sp, #0x80
   120f8:      	mov	w1, #0x10               // =16
   120fc:      	blr	x8
   12100:      	ldr	w21, [sp, #0x84]
   12104:      	ldr	x8, [sp, #0x40]
   12108:      	ldr	x10, [sp, #0x60]
   1210c:      	sub	x12, x10, x8
   12110:      	ldr	w23, [sp, #0x68]
   12114:      	subs	w10, w21, w23
   12118:      	ldr	x9, [sp, #0x88]
   1211c:      	ldr	x25, [sp, #0x8]
   12120:      	csel	w10, wzr, w10, lo
   12124:      	cmp	w23, w21
   12128:      	csel	w11, w23, w21, lo
   1212c:      	cinc	w13, w11, hi
   12130:      	sub	w14, w23, w13
   12134:      	subs	x12, x12, x13
   12138:      	str	w14, [sp, #0x68]
   1213c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12140:      	cmp	x12, #0xfff
   12144:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12148:      	cmp	w23, w21
   1214c:      	b.ls	0x12158 <generic_rawtp_path+0x9058>
   12150:      	mov	w13, #0x2f              // =47
   12154:      	strb	w13, [x8, x12]
   12158:      	add	x19, x8, x12
   1215c:      	cmp	w23, w21
   12160:      	add	x2, x9, x10
   12164:      	and	w1, w11, #0xff
   12168:      	mov	w8, #0x4                // =4
   1216c:      	cinc	x0, x19, hi
   12170:      	blr	x8
   12174:      	ldr	x25, [sp, #0x8]
   12178:      	cmp	w23, w21
   1217c:      	str	x19, [sp, #0x60]
   12180:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12184:      	ldr	x21, [sp, #0x78]
   12188:      	ldp	x2, x24, [sp, #0x50]
   1218c:      	str	x21, [sp, #0x48]
   12190:      	b	0x121e4 <generic_rawtp_path+0x90e4>
   12194:      	add	x2, x24, #0x10
   12198:      	mov	w8, #0x4                // =4
   1219c:      	add	x9, sp, #0x98
   121a0:      	add	x0, sp, #0x98
   121a4:      	mov	w1, #0x8                // =8
   121a8:      	blr	x8
   121ac:      	ldr	x8, [sp, #0x58]
   121b0:      	ldr	x9, [sp, #0x98]
   121b4:      	cmp	x8, x9
   121b8:      	ldr	x25, [sp, #0x8]
   121bc:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   121c0:      	add	x2, x24, #0x18
   121c4:      	mov	w8, #0x4                // =4
   121c8:      	mov	x0, x22
   121cc:      	mov	w1, #0x8                // =8
   121d0:      	blr	x8
   121d4:      	ldr	x24, [sp, #0x98]
   121d8:      	ldr	x21, [sp, #0x48]
   121dc:      	add	x2, x24, #0x20
   121e0:      	stp	x2, x24, [sp, #0x50]
   121e4:      	ldr	x8, [sp, #0x30]
   121e8:      	ldr	x25, [sp, #0x8]
   121ec:      	add	x9, sp, #0x70
   121f0:      	cmp	x21, x8
   121f4:      	b.ne	0x12204 <generic_rawtp_path+0x9104>
   121f8:      	ldr	x8, [sp, #0x38]
   121fc:      	cmp	x2, x8
   12200:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12204:      	mov	w8, #0x4                // =4
   12208:      	add	x0, sp, #0x70
   1220c:      	mov	w1, #0x8                // =8
   12210:      	blr	x8
   12214:      	ldr	x8, [sp, #0x70]
   12218:      	cmp	x21, x8
   1221c:      	b.eq	0x12310 <generic_rawtp_path+0x9210>
   12220:      	add	x23, x21, #0x18
   12224:      	mov	w8, #0x4                // =4
   12228:      	add	x9, sp, #0x98
   1222c:      	add	x0, sp, #0x98
   12230:      	mov	w1, #0x8                // =8
   12234:      	mov	x2, x23
   12238:      	blr	x8
   1223c:      	ldr	x8, [sp, #0x98]
   12240:      	cmp	x8, x21
   12244:      	b.eq	0x12310 <generic_rawtp_path+0x9210>
   12248:      	mov	w8, #0x4                // =4
   1224c:      	add	x9, sp, #0x78
   12250:      	add	x0, sp, #0x78
   12254:      	mov	w1, #0x8                // =8
   12258:      	mov	x2, x23
   1225c:      	blr	x8
   12260:      	add	x2, x21, #0x20
   12264:      	mov	w8, #0x4                // =4
   12268:      	mov	w9, #0x10               // =16
   1226c:      	add	x10, sp, #0x80
   12270:      	add	x0, sp, #0x80
   12274:      	mov	w1, #0x10               // =16
   12278:      	blr	x8
   1227c:      	ldr	w21, [sp, #0x84]
   12280:      	ldr	x8, [sp, #0x40]
   12284:      	ldr	x10, [sp, #0x60]
   12288:      	sub	x12, x10, x8
   1228c:      	ldr	w23, [sp, #0x68]
   12290:      	subs	w10, w21, w23
   12294:      	ldr	x9, [sp, #0x88]
   12298:      	ldr	x25, [sp, #0x8]
   1229c:      	csel	w10, wzr, w10, lo
   122a0:      	cmp	w23, w21
   122a4:      	csel	w11, w23, w21, lo
   122a8:      	cinc	w13, w11, hi
   122ac:      	sub	w14, w23, w13
   122b0:      	subs	x12, x12, x13
   122b4:      	str	w14, [sp, #0x68]
   122b8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   122bc:      	cmp	x12, #0xfff
   122c0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   122c4:      	cmp	w23, w21
   122c8:      	b.ls	0x122d4 <generic_rawtp_path+0x91d4>
   122cc:      	mov	w13, #0x2f              // =47
   122d0:      	strb	w13, [x8, x12]
   122d4:      	add	x19, x8, x12
   122d8:      	cmp	w23, w21
   122dc:      	add	x2, x9, x10
   122e0:      	and	w1, w11, #0xff
   122e4:      	mov	w8, #0x4                // =4
   122e8:      	cinc	x0, x19, hi
   122ec:      	blr	x8
   122f0:      	ldr	x25, [sp, #0x8]
   122f4:      	cmp	w23, w21
   122f8:      	str	x19, [sp, #0x60]
   122fc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12300:      	ldr	x21, [sp, #0x78]
   12304:      	ldp	x2, x24, [sp, #0x50]
   12308:      	str	x21, [sp, #0x48]
   1230c:      	b	0x12360 <generic_rawtp_path+0x9260>
   12310:      	add	x2, x24, #0x10
   12314:      	mov	w8, #0x4                // =4
   12318:      	add	x9, sp, #0x98
   1231c:      	add	x0, sp, #0x98
   12320:      	mov	w1, #0x8                // =8
   12324:      	blr	x8
   12328:      	ldr	x8, [sp, #0x58]
   1232c:      	ldr	x9, [sp, #0x98]
   12330:      	cmp	x8, x9
   12334:      	ldr	x25, [sp, #0x8]
   12338:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1233c:      	add	x2, x24, #0x18
   12340:      	mov	w8, #0x4                // =4
   12344:      	mov	x0, x22
   12348:      	mov	w1, #0x8                // =8
   1234c:      	blr	x8
   12350:      	ldr	x24, [sp, #0x98]
   12354:      	ldr	x21, [sp, #0x48]
   12358:      	add	x2, x24, #0x20
   1235c:      	stp	x2, x24, [sp, #0x50]
   12360:      	ldr	x8, [sp, #0x30]
   12364:      	ldr	x25, [sp, #0x8]
   12368:      	add	x9, sp, #0x70
   1236c:      	cmp	x21, x8
   12370:      	b.ne	0x12380 <generic_rawtp_path+0x9280>
   12374:      	ldr	x8, [sp, #0x38]
   12378:      	cmp	x2, x8
   1237c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12380:      	mov	w8, #0x4                // =4
   12384:      	add	x0, sp, #0x70
   12388:      	mov	w1, #0x8                // =8
   1238c:      	blr	x8
   12390:      	ldr	x8, [sp, #0x70]
   12394:      	cmp	x21, x8
   12398:      	b.eq	0x1248c <generic_rawtp_path+0x938c>
   1239c:      	add	x23, x21, #0x18
   123a0:      	mov	w8, #0x4                // =4
   123a4:      	add	x9, sp, #0x98
   123a8:      	add	x0, sp, #0x98
   123ac:      	mov	w1, #0x8                // =8
   123b0:      	mov	x2, x23
   123b4:      	blr	x8
   123b8:      	ldr	x8, [sp, #0x98]
   123bc:      	cmp	x8, x21
   123c0:      	b.eq	0x1248c <generic_rawtp_path+0x938c>
   123c4:      	mov	w8, #0x4                // =4
   123c8:      	add	x9, sp, #0x78
   123cc:      	add	x0, sp, #0x78
   123d0:      	mov	w1, #0x8                // =8
   123d4:      	mov	x2, x23
   123d8:      	blr	x8
   123dc:      	add	x2, x21, #0x20
   123e0:      	mov	w8, #0x4                // =4
   123e4:      	mov	w9, #0x10               // =16
   123e8:      	add	x10, sp, #0x80
   123ec:      	add	x0, sp, #0x80
   123f0:      	mov	w1, #0x10               // =16
   123f4:      	blr	x8
   123f8:      	ldr	w21, [sp, #0x84]
   123fc:      	ldr	x8, [sp, #0x40]
   12400:      	ldr	x10, [sp, #0x60]
   12404:      	sub	x12, x10, x8
   12408:      	ldr	w23, [sp, #0x68]
   1240c:      	subs	w10, w21, w23
   12410:      	ldr	x9, [sp, #0x88]
   12414:      	ldr	x25, [sp, #0x8]
   12418:      	csel	w10, wzr, w10, lo
   1241c:      	cmp	w23, w21
   12420:      	csel	w11, w23, w21, lo
   12424:      	cinc	w13, w11, hi
   12428:      	sub	w14, w23, w13
   1242c:      	subs	x12, x12, x13
   12430:      	str	w14, [sp, #0x68]
   12434:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12438:      	cmp	x12, #0xfff
   1243c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12440:      	cmp	w23, w21
   12444:      	b.ls	0x12450 <generic_rawtp_path+0x9350>
   12448:      	mov	w13, #0x2f              // =47
   1244c:      	strb	w13, [x8, x12]
   12450:      	add	x19, x8, x12
   12454:      	cmp	w23, w21
   12458:      	add	x2, x9, x10
   1245c:      	and	w1, w11, #0xff
   12460:      	mov	w8, #0x4                // =4
   12464:      	cinc	x0, x19, hi
   12468:      	blr	x8
   1246c:      	ldr	x25, [sp, #0x8]
   12470:      	cmp	w23, w21
   12474:      	str	x19, [sp, #0x60]
   12478:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1247c:      	ldr	x21, [sp, #0x78]
   12480:      	ldp	x2, x24, [sp, #0x50]
   12484:      	str	x21, [sp, #0x48]
   12488:      	b	0x124dc <generic_rawtp_path+0x93dc>
   1248c:      	add	x2, x24, #0x10
   12490:      	mov	w8, #0x4                // =4
   12494:      	add	x9, sp, #0x98
   12498:      	add	x0, sp, #0x98
   1249c:      	mov	w1, #0x8                // =8
   124a0:      	blr	x8
   124a4:      	ldr	x8, [sp, #0x58]
   124a8:      	ldr	x9, [sp, #0x98]
   124ac:      	cmp	x8, x9
   124b0:      	ldr	x25, [sp, #0x8]
   124b4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   124b8:      	add	x2, x24, #0x18
   124bc:      	mov	w8, #0x4                // =4
   124c0:      	mov	x0, x22
   124c4:      	mov	w1, #0x8                // =8
   124c8:      	blr	x8
   124cc:      	ldr	x24, [sp, #0x98]
   124d0:      	ldr	x21, [sp, #0x48]
   124d4:      	add	x2, x24, #0x20
   124d8:      	stp	x2, x24, [sp, #0x50]
   124dc:      	ldr	x8, [sp, #0x30]
   124e0:      	ldr	x25, [sp, #0x8]
   124e4:      	add	x9, sp, #0x70
   124e8:      	cmp	x21, x8
   124ec:      	b.ne	0x124fc <generic_rawtp_path+0x93fc>
   124f0:      	ldr	x8, [sp, #0x38]
   124f4:      	cmp	x2, x8
   124f8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   124fc:      	mov	w8, #0x4                // =4
   12500:      	add	x0, sp, #0x70
   12504:      	mov	w1, #0x8                // =8
   12508:      	blr	x8
   1250c:      	ldr	x8, [sp, #0x70]
   12510:      	cmp	x21, x8
   12514:      	b.eq	0x12608 <generic_rawtp_path+0x9508>
   12518:      	add	x23, x21, #0x18
   1251c:      	mov	w8, #0x4                // =4
   12520:      	add	x9, sp, #0x98
   12524:      	add	x0, sp, #0x98
   12528:      	mov	w1, #0x8                // =8
   1252c:      	mov	x2, x23
   12530:      	blr	x8
   12534:      	ldr	x8, [sp, #0x98]
   12538:      	cmp	x8, x21
   1253c:      	b.eq	0x12608 <generic_rawtp_path+0x9508>
   12540:      	mov	w8, #0x4                // =4
   12544:      	add	x9, sp, #0x78
   12548:      	add	x0, sp, #0x78
   1254c:      	mov	w1, #0x8                // =8
   12550:      	mov	x2, x23
   12554:      	blr	x8
   12558:      	add	x2, x21, #0x20
   1255c:      	mov	w8, #0x4                // =4
   12560:      	mov	w9, #0x10               // =16
   12564:      	add	x10, sp, #0x80
   12568:      	add	x0, sp, #0x80
   1256c:      	mov	w1, #0x10               // =16
   12570:      	blr	x8
   12574:      	ldr	w21, [sp, #0x84]
   12578:      	ldr	x8, [sp, #0x40]
   1257c:      	ldr	x10, [sp, #0x60]
   12580:      	sub	x12, x10, x8
   12584:      	ldr	w23, [sp, #0x68]
   12588:      	subs	w10, w21, w23
   1258c:      	ldr	x9, [sp, #0x88]
   12590:      	ldr	x25, [sp, #0x8]
   12594:      	csel	w10, wzr, w10, lo
   12598:      	cmp	w23, w21
   1259c:      	csel	w11, w23, w21, lo
   125a0:      	cinc	w13, w11, hi
   125a4:      	sub	w14, w23, w13
   125a8:      	subs	x12, x12, x13
   125ac:      	str	w14, [sp, #0x68]
   125b0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   125b4:      	cmp	x12, #0xfff
   125b8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   125bc:      	cmp	w23, w21
   125c0:      	b.ls	0x125cc <generic_rawtp_path+0x94cc>
   125c4:      	mov	w13, #0x2f              // =47
   125c8:      	strb	w13, [x8, x12]
   125cc:      	add	x19, x8, x12
   125d0:      	cmp	w23, w21
   125d4:      	add	x2, x9, x10
   125d8:      	and	w1, w11, #0xff
   125dc:      	mov	w8, #0x4                // =4
   125e0:      	cinc	x0, x19, hi
   125e4:      	blr	x8
   125e8:      	ldr	x25, [sp, #0x8]
   125ec:      	cmp	w23, w21
   125f0:      	str	x19, [sp, #0x60]
   125f4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   125f8:      	ldr	x21, [sp, #0x78]
   125fc:      	ldp	x2, x24, [sp, #0x50]
   12600:      	str	x21, [sp, #0x48]
   12604:      	b	0x12658 <generic_rawtp_path+0x9558>
   12608:      	add	x2, x24, #0x10
   1260c:      	mov	w8, #0x4                // =4
   12610:      	add	x9, sp, #0x98
   12614:      	add	x0, sp, #0x98
   12618:      	mov	w1, #0x8                // =8
   1261c:      	blr	x8
   12620:      	ldr	x8, [sp, #0x58]
   12624:      	ldr	x9, [sp, #0x98]
   12628:      	cmp	x8, x9
   1262c:      	ldr	x25, [sp, #0x8]
   12630:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12634:      	add	x2, x24, #0x18
   12638:      	mov	w8, #0x4                // =4
   1263c:      	mov	x0, x22
   12640:      	mov	w1, #0x8                // =8
   12644:      	blr	x8
   12648:      	ldr	x24, [sp, #0x98]
   1264c:      	ldr	x21, [sp, #0x48]
   12650:      	add	x2, x24, #0x20
   12654:      	stp	x2, x24, [sp, #0x50]
   12658:      	ldr	x8, [sp, #0x30]
   1265c:      	ldr	x25, [sp, #0x8]
   12660:      	add	x9, sp, #0x70
   12664:      	cmp	x21, x8
   12668:      	b.ne	0x12678 <generic_rawtp_path+0x9578>
   1266c:      	ldr	x8, [sp, #0x38]
   12670:      	cmp	x2, x8
   12674:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12678:      	mov	w8, #0x4                // =4
   1267c:      	add	x0, sp, #0x70
   12680:      	mov	w1, #0x8                // =8
   12684:      	blr	x8
   12688:      	ldr	x8, [sp, #0x70]
   1268c:      	cmp	x21, x8
   12690:      	b.eq	0x12784 <generic_rawtp_path+0x9684>
   12694:      	add	x23, x21, #0x18
   12698:      	mov	w8, #0x4                // =4
   1269c:      	add	x9, sp, #0x98
   126a0:      	add	x0, sp, #0x98
   126a4:      	mov	w1, #0x8                // =8
   126a8:      	mov	x2, x23
   126ac:      	blr	x8
   126b0:      	ldr	x8, [sp, #0x98]
   126b4:      	cmp	x8, x21
   126b8:      	b.eq	0x12784 <generic_rawtp_path+0x9684>
   126bc:      	mov	w8, #0x4                // =4
   126c0:      	add	x9, sp, #0x78
   126c4:      	add	x0, sp, #0x78
   126c8:      	mov	w1, #0x8                // =8
   126cc:      	mov	x2, x23
   126d0:      	blr	x8
   126d4:      	add	x2, x21, #0x20
   126d8:      	mov	w8, #0x4                // =4
   126dc:      	mov	w9, #0x10               // =16
   126e0:      	add	x10, sp, #0x80
   126e4:      	add	x0, sp, #0x80
   126e8:      	mov	w1, #0x10               // =16
   126ec:      	blr	x8
   126f0:      	ldr	w21, [sp, #0x84]
   126f4:      	ldr	x8, [sp, #0x40]
   126f8:      	ldr	x10, [sp, #0x60]
   126fc:      	sub	x12, x10, x8
   12700:      	ldr	w23, [sp, #0x68]
   12704:      	subs	w10, w21, w23
   12708:      	ldr	x9, [sp, #0x88]
   1270c:      	ldr	x25, [sp, #0x8]
   12710:      	csel	w10, wzr, w10, lo
   12714:      	cmp	w23, w21
   12718:      	csel	w11, w23, w21, lo
   1271c:      	cinc	w13, w11, hi
   12720:      	sub	w14, w23, w13
   12724:      	subs	x12, x12, x13
   12728:      	str	w14, [sp, #0x68]
   1272c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12730:      	cmp	x12, #0xfff
   12734:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12738:      	cmp	w23, w21
   1273c:      	b.ls	0x12748 <generic_rawtp_path+0x9648>
   12740:      	mov	w13, #0x2f              // =47
   12744:      	strb	w13, [x8, x12]
   12748:      	add	x19, x8, x12
   1274c:      	cmp	w23, w21
   12750:      	add	x2, x9, x10
   12754:      	and	w1, w11, #0xff
   12758:      	mov	w8, #0x4                // =4
   1275c:      	cinc	x0, x19, hi
   12760:      	blr	x8
   12764:      	ldr	x25, [sp, #0x8]
   12768:      	cmp	w23, w21
   1276c:      	str	x19, [sp, #0x60]
   12770:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12774:      	ldr	x21, [sp, #0x78]
   12778:      	ldp	x2, x24, [sp, #0x50]
   1277c:      	str	x21, [sp, #0x48]
   12780:      	b	0x127d4 <generic_rawtp_path+0x96d4>
   12784:      	add	x2, x24, #0x10
   12788:      	mov	w8, #0x4                // =4
   1278c:      	add	x9, sp, #0x98
   12790:      	add	x0, sp, #0x98
   12794:      	mov	w1, #0x8                // =8
   12798:      	blr	x8
   1279c:      	ldr	x8, [sp, #0x58]
   127a0:      	ldr	x9, [sp, #0x98]
   127a4:      	cmp	x8, x9
   127a8:      	ldr	x25, [sp, #0x8]
   127ac:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   127b0:      	add	x2, x24, #0x18
   127b4:      	mov	w8, #0x4                // =4
   127b8:      	mov	x0, x22
   127bc:      	mov	w1, #0x8                // =8
   127c0:      	blr	x8
   127c4:      	ldr	x24, [sp, #0x98]
   127c8:      	ldr	x21, [sp, #0x48]
   127cc:      	add	x2, x24, #0x20
   127d0:      	stp	x2, x24, [sp, #0x50]
   127d4:      	ldr	x8, [sp, #0x30]
   127d8:      	ldr	x25, [sp, #0x8]
   127dc:      	add	x9, sp, #0x70
   127e0:      	cmp	x21, x8
   127e4:      	b.ne	0x127f4 <generic_rawtp_path+0x96f4>
   127e8:      	ldr	x8, [sp, #0x38]
   127ec:      	cmp	x2, x8
   127f0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   127f4:      	mov	w8, #0x4                // =4
   127f8:      	add	x0, sp, #0x70
   127fc:      	mov	w1, #0x8                // =8
   12800:      	blr	x8
   12804:      	ldr	x8, [sp, #0x70]
   12808:      	cmp	x21, x8
   1280c:      	b.eq	0x12900 <generic_rawtp_path+0x9800>
   12810:      	add	x23, x21, #0x18
   12814:      	mov	w8, #0x4                // =4
   12818:      	add	x9, sp, #0x98
   1281c:      	add	x0, sp, #0x98
   12820:      	mov	w1, #0x8                // =8
   12824:      	mov	x2, x23
   12828:      	blr	x8
   1282c:      	ldr	x8, [sp, #0x98]
   12830:      	cmp	x8, x21
   12834:      	b.eq	0x12900 <generic_rawtp_path+0x9800>
   12838:      	mov	w8, #0x4                // =4
   1283c:      	add	x9, sp, #0x78
   12840:      	add	x0, sp, #0x78
   12844:      	mov	w1, #0x8                // =8
   12848:      	mov	x2, x23
   1284c:      	blr	x8
   12850:      	add	x2, x21, #0x20
   12854:      	mov	w8, #0x4                // =4
   12858:      	mov	w9, #0x10               // =16
   1285c:      	add	x10, sp, #0x80
   12860:      	add	x0, sp, #0x80
   12864:      	mov	w1, #0x10               // =16
   12868:      	blr	x8
   1286c:      	ldr	w21, [sp, #0x84]
   12870:      	ldr	x8, [sp, #0x40]
   12874:      	ldr	x10, [sp, #0x60]
   12878:      	sub	x12, x10, x8
   1287c:      	ldr	w23, [sp, #0x68]
   12880:      	subs	w10, w21, w23
   12884:      	ldr	x9, [sp, #0x88]
   12888:      	ldr	x25, [sp, #0x8]
   1288c:      	csel	w10, wzr, w10, lo
   12890:      	cmp	w23, w21
   12894:      	csel	w11, w23, w21, lo
   12898:      	cinc	w13, w11, hi
   1289c:      	sub	w14, w23, w13
   128a0:      	subs	x12, x12, x13
   128a4:      	str	w14, [sp, #0x68]
   128a8:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   128ac:      	cmp	x12, #0xfff
   128b0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   128b4:      	cmp	w23, w21
   128b8:      	b.ls	0x128c4 <generic_rawtp_path+0x97c4>
   128bc:      	mov	w13, #0x2f              // =47
   128c0:      	strb	w13, [x8, x12]
   128c4:      	add	x19, x8, x12
   128c8:      	cmp	w23, w21
   128cc:      	add	x2, x9, x10
   128d0:      	and	w1, w11, #0xff
   128d4:      	mov	w8, #0x4                // =4
   128d8:      	cinc	x0, x19, hi
   128dc:      	blr	x8
   128e0:      	ldr	x25, [sp, #0x8]
   128e4:      	cmp	w23, w21
   128e8:      	str	x19, [sp, #0x60]
   128ec:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   128f0:      	ldr	x21, [sp, #0x78]
   128f4:      	ldp	x2, x24, [sp, #0x50]
   128f8:      	str	x21, [sp, #0x48]
   128fc:      	b	0x12950 <generic_rawtp_path+0x9850>
   12900:      	add	x2, x24, #0x10
   12904:      	mov	w8, #0x4                // =4
   12908:      	add	x9, sp, #0x98
   1290c:      	add	x0, sp, #0x98
   12910:      	mov	w1, #0x8                // =8
   12914:      	blr	x8
   12918:      	ldr	x8, [sp, #0x58]
   1291c:      	ldr	x9, [sp, #0x98]
   12920:      	cmp	x8, x9
   12924:      	ldr	x25, [sp, #0x8]
   12928:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1292c:      	add	x2, x24, #0x18
   12930:      	mov	w8, #0x4                // =4
   12934:      	mov	x0, x22
   12938:      	mov	w1, #0x8                // =8
   1293c:      	blr	x8
   12940:      	ldr	x24, [sp, #0x98]
   12944:      	ldr	x21, [sp, #0x48]
   12948:      	add	x2, x24, #0x20
   1294c:      	stp	x2, x24, [sp, #0x50]
   12950:      	ldr	x8, [sp, #0x30]
   12954:      	ldr	x25, [sp, #0x8]
   12958:      	add	x9, sp, #0x70
   1295c:      	cmp	x21, x8
   12960:      	b.ne	0x12970 <generic_rawtp_path+0x9870>
   12964:      	ldr	x8, [sp, #0x38]
   12968:      	cmp	x2, x8
   1296c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12970:      	mov	w8, #0x4                // =4
   12974:      	add	x0, sp, #0x70
   12978:      	mov	w1, #0x8                // =8
   1297c:      	blr	x8
   12980:      	ldr	x8, [sp, #0x70]
   12984:      	cmp	x21, x8
   12988:      	b.eq	0x12a7c <generic_rawtp_path+0x997c>
   1298c:      	add	x23, x21, #0x18
   12990:      	mov	w8, #0x4                // =4
   12994:      	add	x9, sp, #0x98
   12998:      	add	x0, sp, #0x98
   1299c:      	mov	w1, #0x8                // =8
   129a0:      	mov	x2, x23
   129a4:      	blr	x8
   129a8:      	ldr	x8, [sp, #0x98]
   129ac:      	cmp	x8, x21
   129b0:      	b.eq	0x12a7c <generic_rawtp_path+0x997c>
   129b4:      	mov	w8, #0x4                // =4
   129b8:      	add	x9, sp, #0x78
   129bc:      	add	x0, sp, #0x78
   129c0:      	mov	w1, #0x8                // =8
   129c4:      	mov	x2, x23
   129c8:      	blr	x8
   129cc:      	add	x2, x21, #0x20
   129d0:      	mov	w8, #0x4                // =4
   129d4:      	mov	w9, #0x10               // =16
   129d8:      	add	x10, sp, #0x80
   129dc:      	add	x0, sp, #0x80
   129e0:      	mov	w1, #0x10               // =16
   129e4:      	blr	x8
   129e8:      	ldr	w21, [sp, #0x84]
   129ec:      	ldr	x8, [sp, #0x40]
   129f0:      	ldr	x10, [sp, #0x60]
   129f4:      	sub	x12, x10, x8
   129f8:      	ldr	w23, [sp, #0x68]
   129fc:      	subs	w10, w21, w23
   12a00:      	ldr	x9, [sp, #0x88]
   12a04:      	ldr	x25, [sp, #0x8]
   12a08:      	csel	w10, wzr, w10, lo
   12a0c:      	cmp	w23, w21
   12a10:      	csel	w11, w23, w21, lo
   12a14:      	cinc	w13, w11, hi
   12a18:      	sub	w14, w23, w13
   12a1c:      	subs	x12, x12, x13
   12a20:      	str	w14, [sp, #0x68]
   12a24:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12a28:      	cmp	x12, #0xfff
   12a2c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12a30:      	cmp	w23, w21
   12a34:      	b.ls	0x12a40 <generic_rawtp_path+0x9940>
   12a38:      	mov	w13, #0x2f              // =47
   12a3c:      	strb	w13, [x8, x12]
   12a40:      	add	x19, x8, x12
   12a44:      	cmp	w23, w21
   12a48:      	add	x2, x9, x10
   12a4c:      	and	w1, w11, #0xff
   12a50:      	mov	w8, #0x4                // =4
   12a54:      	cinc	x0, x19, hi
   12a58:      	blr	x8
   12a5c:      	ldr	x25, [sp, #0x8]
   12a60:      	cmp	w23, w21
   12a64:      	str	x19, [sp, #0x60]
   12a68:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12a6c:      	ldr	x21, [sp, #0x78]
   12a70:      	ldp	x2, x24, [sp, #0x50]
   12a74:      	str	x21, [sp, #0x48]
   12a78:      	b	0x12acc <generic_rawtp_path+0x99cc>
   12a7c:      	add	x2, x24, #0x10
   12a80:      	mov	w8, #0x4                // =4
   12a84:      	add	x9, sp, #0x98
   12a88:      	add	x0, sp, #0x98
   12a8c:      	mov	w1, #0x8                // =8
   12a90:      	blr	x8
   12a94:      	ldr	x8, [sp, #0x58]
   12a98:      	ldr	x9, [sp, #0x98]
   12a9c:      	cmp	x8, x9
   12aa0:      	ldr	x25, [sp, #0x8]
   12aa4:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12aa8:      	add	x2, x24, #0x18
   12aac:      	mov	w8, #0x4                // =4
   12ab0:      	mov	x0, x22
   12ab4:      	mov	w1, #0x8                // =8
   12ab8:      	blr	x8
   12abc:      	ldr	x24, [sp, #0x98]
   12ac0:      	ldr	x21, [sp, #0x48]
   12ac4:      	add	x2, x24, #0x20
   12ac8:      	stp	x2, x24, [sp, #0x50]
   12acc:      	ldr	x8, [sp, #0x30]
   12ad0:      	ldr	x25, [sp, #0x8]
   12ad4:      	add	x9, sp, #0x70
   12ad8:      	cmp	x21, x8
   12adc:      	b.ne	0x12aec <generic_rawtp_path+0x99ec>
   12ae0:      	ldr	x8, [sp, #0x38]
   12ae4:      	cmp	x2, x8
   12ae8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12aec:      	mov	w8, #0x4                // =4
   12af0:      	add	x0, sp, #0x70
   12af4:      	mov	w1, #0x8                // =8
   12af8:      	blr	x8
   12afc:      	ldr	x8, [sp, #0x70]
   12b00:      	cmp	x21, x8
   12b04:      	b.eq	0x12bf8 <generic_rawtp_path+0x9af8>
   12b08:      	add	x23, x21, #0x18
   12b0c:      	mov	w8, #0x4                // =4
   12b10:      	add	x9, sp, #0x98
   12b14:      	add	x0, sp, #0x98
   12b18:      	mov	w1, #0x8                // =8
   12b1c:      	mov	x2, x23
   12b20:      	blr	x8
   12b24:      	ldr	x8, [sp, #0x98]
   12b28:      	cmp	x8, x21
   12b2c:      	b.eq	0x12bf8 <generic_rawtp_path+0x9af8>
   12b30:      	mov	w8, #0x4                // =4
   12b34:      	add	x9, sp, #0x78
   12b38:      	add	x0, sp, #0x78
   12b3c:      	mov	w1, #0x8                // =8
   12b40:      	mov	x2, x23
   12b44:      	blr	x8
   12b48:      	add	x2, x21, #0x20
   12b4c:      	mov	w8, #0x4                // =4
   12b50:      	mov	w9, #0x10               // =16
   12b54:      	add	x10, sp, #0x80
   12b58:      	add	x0, sp, #0x80
   12b5c:      	mov	w1, #0x10               // =16
   12b60:      	blr	x8
   12b64:      	ldr	w21, [sp, #0x84]
   12b68:      	ldr	x8, [sp, #0x40]
   12b6c:      	ldr	x10, [sp, #0x60]
   12b70:      	sub	x12, x10, x8
   12b74:      	ldr	w23, [sp, #0x68]
   12b78:      	subs	w10, w21, w23
   12b7c:      	ldr	x9, [sp, #0x88]
   12b80:      	ldr	x25, [sp, #0x8]
   12b84:      	csel	w10, wzr, w10, lo
   12b88:      	cmp	w23, w21
   12b8c:      	csel	w11, w23, w21, lo
   12b90:      	cinc	w13, w11, hi
   12b94:      	sub	w14, w23, w13
   12b98:      	subs	x12, x12, x13
   12b9c:      	str	w14, [sp, #0x68]
   12ba0:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12ba4:      	cmp	x12, #0xfff
   12ba8:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12bac:      	cmp	w23, w21
   12bb0:      	b.ls	0x12bbc <generic_rawtp_path+0x9abc>
   12bb4:      	mov	w13, #0x2f              // =47
   12bb8:      	strb	w13, [x8, x12]
   12bbc:      	add	x19, x8, x12
   12bc0:      	cmp	w23, w21
   12bc4:      	add	x2, x9, x10
   12bc8:      	and	w1, w11, #0xff
   12bcc:      	mov	w8, #0x4                // =4
   12bd0:      	cinc	x0, x19, hi
   12bd4:      	blr	x8
   12bd8:      	ldr	x25, [sp, #0x8]
   12bdc:      	cmp	w23, w21
   12be0:      	str	x19, [sp, #0x60]
   12be4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12be8:      	ldr	x21, [sp, #0x78]
   12bec:      	ldp	x2, x24, [sp, #0x50]
   12bf0:      	str	x21, [sp, #0x48]
   12bf4:      	b	0x12c48 <generic_rawtp_path+0x9b48>
   12bf8:      	add	x2, x24, #0x10
   12bfc:      	mov	w8, #0x4                // =4
   12c00:      	add	x9, sp, #0x98
   12c04:      	add	x0, sp, #0x98
   12c08:      	mov	w1, #0x8                // =8
   12c0c:      	blr	x8
   12c10:      	ldr	x8, [sp, #0x58]
   12c14:      	ldr	x9, [sp, #0x98]
   12c18:      	cmp	x8, x9
   12c1c:      	ldr	x25, [sp, #0x8]
   12c20:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12c24:      	add	x2, x24, #0x18
   12c28:      	mov	w8, #0x4                // =4
   12c2c:      	mov	x0, x22
   12c30:      	mov	w1, #0x8                // =8
   12c34:      	blr	x8
   12c38:      	ldr	x24, [sp, #0x98]
   12c3c:      	ldr	x21, [sp, #0x48]
   12c40:      	add	x2, x24, #0x20
   12c44:      	stp	x2, x24, [sp, #0x50]
   12c48:      	ldr	x8, [sp, #0x30]
   12c4c:      	ldr	x25, [sp, #0x8]
   12c50:      	add	x9, sp, #0x70
   12c54:      	cmp	x21, x8
   12c58:      	b.ne	0x12c68 <generic_rawtp_path+0x9b68>
   12c5c:      	ldr	x8, [sp, #0x38]
   12c60:      	cmp	x2, x8
   12c64:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12c68:      	mov	w8, #0x4                // =4
   12c6c:      	add	x0, sp, #0x70
   12c70:      	mov	w1, #0x8                // =8
   12c74:      	blr	x8
   12c78:      	ldr	x8, [sp, #0x70]
   12c7c:      	cmp	x21, x8
   12c80:      	b.eq	0x12d74 <generic_rawtp_path+0x9c74>
   12c84:      	add	x23, x21, #0x18
   12c88:      	mov	w8, #0x4                // =4
   12c8c:      	add	x9, sp, #0x98
   12c90:      	add	x0, sp, #0x98
   12c94:      	mov	w1, #0x8                // =8
   12c98:      	mov	x2, x23
   12c9c:      	blr	x8
   12ca0:      	ldr	x8, [sp, #0x98]
   12ca4:      	cmp	x8, x21
   12ca8:      	b.eq	0x12d74 <generic_rawtp_path+0x9c74>
   12cac:      	mov	w8, #0x4                // =4
   12cb0:      	add	x9, sp, #0x78
   12cb4:      	add	x0, sp, #0x78
   12cb8:      	mov	w1, #0x8                // =8
   12cbc:      	mov	x2, x23
   12cc0:      	blr	x8
   12cc4:      	add	x2, x21, #0x20
   12cc8:      	mov	w8, #0x4                // =4
   12ccc:      	mov	w9, #0x10               // =16
   12cd0:      	add	x10, sp, #0x80
   12cd4:      	add	x0, sp, #0x80
   12cd8:      	mov	w1, #0x10               // =16
   12cdc:      	blr	x8
   12ce0:      	ldr	w21, [sp, #0x84]
   12ce4:      	ldr	x8, [sp, #0x40]
   12ce8:      	ldr	x10, [sp, #0x60]
   12cec:      	sub	x12, x10, x8
   12cf0:      	ldr	w23, [sp, #0x68]
   12cf4:      	subs	w10, w21, w23
   12cf8:      	ldr	x9, [sp, #0x88]
   12cfc:      	ldr	x25, [sp, #0x8]
   12d00:      	csel	w10, wzr, w10, lo
   12d04:      	cmp	w23, w21
   12d08:      	csel	w11, w23, w21, lo
   12d0c:      	cinc	w13, w11, hi
   12d10:      	sub	w14, w23, w13
   12d14:      	subs	x12, x12, x13
   12d18:      	str	w14, [sp, #0x68]
   12d1c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12d20:      	cmp	x12, #0xfff
   12d24:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12d28:      	cmp	w23, w21
   12d2c:      	b.ls	0x12d38 <generic_rawtp_path+0x9c38>
   12d30:      	mov	w13, #0x2f              // =47
   12d34:      	strb	w13, [x8, x12]
   12d38:      	add	x19, x8, x12
   12d3c:      	cmp	w23, w21
   12d40:      	add	x2, x9, x10
   12d44:      	and	w1, w11, #0xff
   12d48:      	mov	w8, #0x4                // =4
   12d4c:      	cinc	x0, x19, hi
   12d50:      	blr	x8
   12d54:      	ldr	x25, [sp, #0x8]
   12d58:      	cmp	w23, w21
   12d5c:      	str	x19, [sp, #0x60]
   12d60:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12d64:      	ldr	x21, [sp, #0x78]
   12d68:      	ldp	x2, x24, [sp, #0x50]
   12d6c:      	str	x21, [sp, #0x48]
   12d70:      	b	0x12dc4 <generic_rawtp_path+0x9cc4>
   12d74:      	add	x2, x24, #0x10
   12d78:      	mov	w8, #0x4                // =4
   12d7c:      	add	x9, sp, #0x98
   12d80:      	add	x0, sp, #0x98
   12d84:      	mov	w1, #0x8                // =8
   12d88:      	blr	x8
   12d8c:      	ldr	x8, [sp, #0x58]
   12d90:      	ldr	x9, [sp, #0x98]
   12d94:      	cmp	x8, x9
   12d98:      	ldr	x25, [sp, #0x8]
   12d9c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12da0:      	add	x2, x24, #0x18
   12da4:      	mov	w8, #0x4                // =4
   12da8:      	mov	x0, x22
   12dac:      	mov	w1, #0x8                // =8
   12db0:      	blr	x8
   12db4:      	ldr	x24, [sp, #0x98]
   12db8:      	ldr	x21, [sp, #0x48]
   12dbc:      	add	x2, x24, #0x20
   12dc0:      	stp	x2, x24, [sp, #0x50]
   12dc4:      	ldr	x8, [sp, #0x30]
   12dc8:      	ldr	x25, [sp, #0x8]
   12dcc:      	add	x9, sp, #0x70
   12dd0:      	cmp	x21, x8
   12dd4:      	b.ne	0x12de4 <generic_rawtp_path+0x9ce4>
   12dd8:      	ldr	x8, [sp, #0x38]
   12ddc:      	cmp	x2, x8
   12de0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12de4:      	mov	w8, #0x4                // =4
   12de8:      	add	x0, sp, #0x70
   12dec:      	mov	w1, #0x8                // =8
   12df0:      	blr	x8
   12df4:      	ldr	x8, [sp, #0x70]
   12df8:      	cmp	x21, x8
   12dfc:      	b.eq	0x12ef0 <generic_rawtp_path+0x9df0>
   12e00:      	add	x23, x21, #0x18
   12e04:      	mov	w8, #0x4                // =4
   12e08:      	add	x9, sp, #0x98
   12e0c:      	add	x0, sp, #0x98
   12e10:      	mov	w1, #0x8                // =8
   12e14:      	mov	x2, x23
   12e18:      	blr	x8
   12e1c:      	ldr	x8, [sp, #0x98]
   12e20:      	cmp	x8, x21
   12e24:      	b.eq	0x12ef0 <generic_rawtp_path+0x9df0>
   12e28:      	mov	w8, #0x4                // =4
   12e2c:      	add	x9, sp, #0x78
   12e30:      	add	x0, sp, #0x78
   12e34:      	mov	w1, #0x8                // =8
   12e38:      	mov	x2, x23
   12e3c:      	blr	x8
   12e40:      	add	x2, x21, #0x20
   12e44:      	mov	w8, #0x4                // =4
   12e48:      	mov	w9, #0x10               // =16
   12e4c:      	add	x10, sp, #0x80
   12e50:      	add	x0, sp, #0x80
   12e54:      	mov	w1, #0x10               // =16
   12e58:      	blr	x8
   12e5c:      	ldr	w21, [sp, #0x84]
   12e60:      	ldr	x8, [sp, #0x40]
   12e64:      	ldr	x10, [sp, #0x60]
   12e68:      	sub	x12, x10, x8
   12e6c:      	ldr	w23, [sp, #0x68]
   12e70:      	subs	w10, w21, w23
   12e74:      	ldr	x9, [sp, #0x88]
   12e78:      	ldr	x25, [sp, #0x8]
   12e7c:      	csel	w10, wzr, w10, lo
   12e80:      	cmp	w23, w21
   12e84:      	csel	w11, w23, w21, lo
   12e88:      	cinc	w13, w11, hi
   12e8c:      	sub	w14, w23, w13
   12e90:      	subs	x12, x12, x13
   12e94:      	str	w14, [sp, #0x68]
   12e98:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   12e9c:      	cmp	x12, #0xfff
   12ea0:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   12ea4:      	cmp	w23, w21
   12ea8:      	b.ls	0x12eb4 <generic_rawtp_path+0x9db4>
   12eac:      	mov	w13, #0x2f              // =47
   12eb0:      	strb	w13, [x8, x12]
   12eb4:      	add	x19, x8, x12
   12eb8:      	cmp	w23, w21
   12ebc:      	add	x2, x9, x10
   12ec0:      	and	w1, w11, #0xff
   12ec4:      	mov	w8, #0x4                // =4
   12ec8:      	cinc	x0, x19, hi
   12ecc:      	blr	x8
   12ed0:      	ldr	x25, [sp, #0x8]
   12ed4:      	cmp	w23, w21
   12ed8:      	str	x19, [sp, #0x60]
   12edc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   12ee0:      	ldr	x21, [sp, #0x78]
   12ee4:      	ldp	x2, x24, [sp, #0x50]
   12ee8:      	str	x21, [sp, #0x48]
   12eec:      	b	0x12f40 <generic_rawtp_path+0x9e40>
   12ef0:      	add	x2, x24, #0x10
   12ef4:      	mov	w8, #0x4                // =4
   12ef8:      	add	x9, sp, #0x98
   12efc:      	add	x0, sp, #0x98
   12f00:      	mov	w1, #0x8                // =8
   12f04:      	blr	x8
   12f08:      	ldr	x8, [sp, #0x58]
   12f0c:      	ldr	x9, [sp, #0x98]
   12f10:      	cmp	x8, x9
   12f14:      	ldr	x25, [sp, #0x8]
   12f18:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12f1c:      	add	x2, x24, #0x18
   12f20:      	mov	w8, #0x4                // =4
   12f24:      	mov	x0, x22
   12f28:      	mov	w1, #0x8                // =8
   12f2c:      	blr	x8
   12f30:      	ldr	x24, [sp, #0x98]
   12f34:      	ldr	x21, [sp, #0x48]
   12f38:      	add	x2, x24, #0x20
   12f3c:      	stp	x2, x24, [sp, #0x50]
   12f40:      	ldr	x8, [sp, #0x30]
   12f44:      	ldr	x25, [sp, #0x8]
   12f48:      	add	x9, sp, #0x70
   12f4c:      	cmp	x21, x8
   12f50:      	b.ne	0x12f60 <generic_rawtp_path+0x9e60>
   12f54:      	ldr	x8, [sp, #0x38]
   12f58:      	cmp	x2, x8
   12f5c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   12f60:      	mov	w8, #0x4                // =4
   12f64:      	add	x0, sp, #0x70
   12f68:      	mov	w1, #0x8                // =8
   12f6c:      	blr	x8
   12f70:      	ldr	x8, [sp, #0x70]
   12f74:      	cmp	x21, x8
   12f78:      	b.eq	0x1306c <generic_rawtp_path+0x9f6c>
   12f7c:      	add	x23, x21, #0x18
   12f80:      	mov	w8, #0x4                // =4
   12f84:      	add	x9, sp, #0x98
   12f88:      	add	x0, sp, #0x98
   12f8c:      	mov	w1, #0x8                // =8
   12f90:      	mov	x2, x23
   12f94:      	blr	x8
   12f98:      	ldr	x8, [sp, #0x98]
   12f9c:      	cmp	x8, x21
   12fa0:      	b.eq	0x1306c <generic_rawtp_path+0x9f6c>
   12fa4:      	mov	w8, #0x4                // =4
   12fa8:      	add	x9, sp, #0x78
   12fac:      	add	x0, sp, #0x78
   12fb0:      	mov	w1, #0x8                // =8
   12fb4:      	mov	x2, x23
   12fb8:      	blr	x8
   12fbc:      	add	x2, x21, #0x20
   12fc0:      	mov	w8, #0x4                // =4
   12fc4:      	mov	w9, #0x10               // =16
   12fc8:      	add	x10, sp, #0x80
   12fcc:      	add	x0, sp, #0x80
   12fd0:      	mov	w1, #0x10               // =16
   12fd4:      	blr	x8
   12fd8:      	ldr	w21, [sp, #0x84]
   12fdc:      	ldr	x8, [sp, #0x40]
   12fe0:      	ldr	x10, [sp, #0x60]
   12fe4:      	sub	x12, x10, x8
   12fe8:      	ldr	w23, [sp, #0x68]
   12fec:      	subs	w10, w21, w23
   12ff0:      	ldr	x9, [sp, #0x88]
   12ff4:      	ldr	x25, [sp, #0x8]
   12ff8:      	csel	w10, wzr, w10, lo
   12ffc:      	cmp	w23, w21
   13000:      	csel	w11, w23, w21, lo
   13004:      	cinc	w13, w11, hi
   13008:      	sub	w14, w23, w13
   1300c:      	subs	x12, x12, x13
   13010:      	str	w14, [sp, #0x68]
   13014:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13018:      	cmp	x12, #0xfff
   1301c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13020:      	cmp	w23, w21
   13024:      	b.ls	0x13030 <generic_rawtp_path+0x9f30>
   13028:      	mov	w13, #0x2f              // =47
   1302c:      	strb	w13, [x8, x12]
   13030:      	add	x19, x8, x12
   13034:      	cmp	w23, w21
   13038:      	add	x2, x9, x10
   1303c:      	and	w1, w11, #0xff
   13040:      	mov	w8, #0x4                // =4
   13044:      	cinc	x0, x19, hi
   13048:      	blr	x8
   1304c:      	ldr	x25, [sp, #0x8]
   13050:      	cmp	w23, w21
   13054:      	str	x19, [sp, #0x60]
   13058:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1305c:      	ldr	x21, [sp, #0x78]
   13060:      	ldp	x2, x24, [sp, #0x50]
   13064:      	str	x21, [sp, #0x48]
   13068:      	b	0x130bc <generic_rawtp_path+0x9fbc>
   1306c:      	add	x2, x24, #0x10
   13070:      	mov	w8, #0x4                // =4
   13074:      	add	x9, sp, #0x98
   13078:      	add	x0, sp, #0x98
   1307c:      	mov	w1, #0x8                // =8
   13080:      	blr	x8
   13084:      	ldr	x8, [sp, #0x58]
   13088:      	ldr	x9, [sp, #0x98]
   1308c:      	cmp	x8, x9
   13090:      	ldr	x25, [sp, #0x8]
   13094:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13098:      	add	x2, x24, #0x18
   1309c:      	mov	w8, #0x4                // =4
   130a0:      	mov	x0, x22
   130a4:      	mov	w1, #0x8                // =8
   130a8:      	blr	x8
   130ac:      	ldr	x24, [sp, #0x98]
   130b0:      	ldr	x21, [sp, #0x48]
   130b4:      	add	x2, x24, #0x20
   130b8:      	stp	x2, x24, [sp, #0x50]
   130bc:      	ldr	x8, [sp, #0x30]
   130c0:      	ldr	x25, [sp, #0x8]
   130c4:      	add	x9, sp, #0x70
   130c8:      	cmp	x21, x8
   130cc:      	b.ne	0x130dc <generic_rawtp_path+0x9fdc>
   130d0:      	ldr	x8, [sp, #0x38]
   130d4:      	cmp	x2, x8
   130d8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   130dc:      	mov	w8, #0x4                // =4
   130e0:      	add	x0, sp, #0x70
   130e4:      	mov	w1, #0x8                // =8
   130e8:      	blr	x8
   130ec:      	ldr	x8, [sp, #0x70]
   130f0:      	cmp	x21, x8
   130f4:      	b.eq	0x131e8 <generic_rawtp_path+0xa0e8>
   130f8:      	add	x23, x21, #0x18
   130fc:      	mov	w8, #0x4                // =4
   13100:      	add	x9, sp, #0x98
   13104:      	add	x0, sp, #0x98
   13108:      	mov	w1, #0x8                // =8
   1310c:      	mov	x2, x23
   13110:      	blr	x8
   13114:      	ldr	x8, [sp, #0x98]
   13118:      	cmp	x8, x21
   1311c:      	b.eq	0x131e8 <generic_rawtp_path+0xa0e8>
   13120:      	mov	w8, #0x4                // =4
   13124:      	add	x9, sp, #0x78
   13128:      	add	x0, sp, #0x78
   1312c:      	mov	w1, #0x8                // =8
   13130:      	mov	x2, x23
   13134:      	blr	x8
   13138:      	add	x2, x21, #0x20
   1313c:      	mov	w8, #0x4                // =4
   13140:      	mov	w9, #0x10               // =16
   13144:      	add	x10, sp, #0x80
   13148:      	add	x0, sp, #0x80
   1314c:      	mov	w1, #0x10               // =16
   13150:      	blr	x8
   13154:      	ldr	w21, [sp, #0x84]
   13158:      	ldr	x8, [sp, #0x40]
   1315c:      	ldr	x10, [sp, #0x60]
   13160:      	sub	x12, x10, x8
   13164:      	ldr	w23, [sp, #0x68]
   13168:      	subs	w10, w21, w23
   1316c:      	ldr	x9, [sp, #0x88]
   13170:      	ldr	x25, [sp, #0x8]
   13174:      	csel	w10, wzr, w10, lo
   13178:      	cmp	w23, w21
   1317c:      	csel	w11, w23, w21, lo
   13180:      	cinc	w13, w11, hi
   13184:      	sub	w14, w23, w13
   13188:      	subs	x12, x12, x13
   1318c:      	str	w14, [sp, #0x68]
   13190:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13194:      	cmp	x12, #0xfff
   13198:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   1319c:      	cmp	w23, w21
   131a0:      	b.ls	0x131ac <generic_rawtp_path+0xa0ac>
   131a4:      	mov	w13, #0x2f              // =47
   131a8:      	strb	w13, [x8, x12]
   131ac:      	add	x19, x8, x12
   131b0:      	cmp	w23, w21
   131b4:      	add	x2, x9, x10
   131b8:      	and	w1, w11, #0xff
   131bc:      	mov	w8, #0x4                // =4
   131c0:      	cinc	x0, x19, hi
   131c4:      	blr	x8
   131c8:      	ldr	x25, [sp, #0x8]
   131cc:      	cmp	w23, w21
   131d0:      	str	x19, [sp, #0x60]
   131d4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   131d8:      	ldr	x21, [sp, #0x78]
   131dc:      	ldp	x2, x24, [sp, #0x50]
   131e0:      	str	x21, [sp, #0x48]
   131e4:      	b	0x13238 <generic_rawtp_path+0xa138>
   131e8:      	add	x2, x24, #0x10
   131ec:      	mov	w8, #0x4                // =4
   131f0:      	add	x9, sp, #0x98
   131f4:      	add	x0, sp, #0x98
   131f8:      	mov	w1, #0x8                // =8
   131fc:      	blr	x8
   13200:      	ldr	x8, [sp, #0x58]
   13204:      	ldr	x9, [sp, #0x98]
   13208:      	cmp	x8, x9
   1320c:      	ldr	x25, [sp, #0x8]
   13210:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13214:      	add	x2, x24, #0x18
   13218:      	mov	w8, #0x4                // =4
   1321c:      	mov	x0, x22
   13220:      	mov	w1, #0x8                // =8
   13224:      	blr	x8
   13228:      	ldr	x24, [sp, #0x98]
   1322c:      	ldr	x21, [sp, #0x48]
   13230:      	add	x2, x24, #0x20
   13234:      	stp	x2, x24, [sp, #0x50]
   13238:      	ldr	x8, [sp, #0x30]
   1323c:      	ldr	x25, [sp, #0x8]
   13240:      	add	x9, sp, #0x70
   13244:      	cmp	x21, x8
   13248:      	b.ne	0x13258 <generic_rawtp_path+0xa158>
   1324c:      	ldr	x8, [sp, #0x38]
   13250:      	cmp	x2, x8
   13254:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13258:      	mov	w8, #0x4                // =4
   1325c:      	add	x0, sp, #0x70
   13260:      	mov	w1, #0x8                // =8
   13264:      	blr	x8
   13268:      	ldr	x8, [sp, #0x70]
   1326c:      	cmp	x21, x8
   13270:      	b.eq	0x13364 <generic_rawtp_path+0xa264>
   13274:      	add	x23, x21, #0x18
   13278:      	mov	w8, #0x4                // =4
   1327c:      	add	x9, sp, #0x98
   13280:      	add	x0, sp, #0x98
   13284:      	mov	w1, #0x8                // =8
   13288:      	mov	x2, x23
   1328c:      	blr	x8
   13290:      	ldr	x8, [sp, #0x98]
   13294:      	cmp	x8, x21
   13298:      	b.eq	0x13364 <generic_rawtp_path+0xa264>
   1329c:      	mov	w8, #0x4                // =4
   132a0:      	add	x9, sp, #0x78
   132a4:      	add	x0, sp, #0x78
   132a8:      	mov	w1, #0x8                // =8
   132ac:      	mov	x2, x23
   132b0:      	blr	x8
   132b4:      	add	x2, x21, #0x20
   132b8:      	mov	w8, #0x4                // =4
   132bc:      	mov	w9, #0x10               // =16
   132c0:      	add	x10, sp, #0x80
   132c4:      	add	x0, sp, #0x80
   132c8:      	mov	w1, #0x10               // =16
   132cc:      	blr	x8
   132d0:      	ldr	w21, [sp, #0x84]
   132d4:      	ldr	x8, [sp, #0x40]
   132d8:      	ldr	x10, [sp, #0x60]
   132dc:      	sub	x12, x10, x8
   132e0:      	ldr	w23, [sp, #0x68]
   132e4:      	subs	w10, w21, w23
   132e8:      	ldr	x9, [sp, #0x88]
   132ec:      	ldr	x25, [sp, #0x8]
   132f0:      	csel	w10, wzr, w10, lo
   132f4:      	cmp	w23, w21
   132f8:      	csel	w11, w23, w21, lo
   132fc:      	cinc	w13, w11, hi
   13300:      	sub	w14, w23, w13
   13304:      	subs	x12, x12, x13
   13308:      	str	w14, [sp, #0x68]
   1330c:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13310:      	cmp	x12, #0xfff
   13314:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13318:      	cmp	w23, w21
   1331c:      	b.ls	0x13328 <generic_rawtp_path+0xa228>
   13320:      	mov	w13, #0x2f              // =47
   13324:      	strb	w13, [x8, x12]
   13328:      	add	x19, x8, x12
   1332c:      	cmp	w23, w21
   13330:      	add	x2, x9, x10
   13334:      	and	w1, w11, #0xff
   13338:      	mov	w8, #0x4                // =4
   1333c:      	cinc	x0, x19, hi
   13340:      	blr	x8
   13344:      	ldr	x25, [sp, #0x8]
   13348:      	cmp	w23, w21
   1334c:      	str	x19, [sp, #0x60]
   13350:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   13354:      	ldr	x21, [sp, #0x78]
   13358:      	ldp	x2, x24, [sp, #0x50]
   1335c:      	str	x21, [sp, #0x48]
   13360:      	b	0x133b4 <generic_rawtp_path+0xa2b4>
   13364:      	add	x2, x24, #0x10
   13368:      	mov	w8, #0x4                // =4
   1336c:      	add	x9, sp, #0x98
   13370:      	add	x0, sp, #0x98
   13374:      	mov	w1, #0x8                // =8
   13378:      	blr	x8
   1337c:      	ldr	x8, [sp, #0x58]
   13380:      	ldr	x9, [sp, #0x98]
   13384:      	cmp	x8, x9
   13388:      	ldr	x25, [sp, #0x8]
   1338c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13390:      	add	x2, x24, #0x18
   13394:      	mov	w8, #0x4                // =4
   13398:      	mov	x0, x22
   1339c:      	mov	w1, #0x8                // =8
   133a0:      	blr	x8
   133a4:      	ldr	x24, [sp, #0x98]
   133a8:      	ldr	x21, [sp, #0x48]
   133ac:      	add	x2, x24, #0x20
   133b0:      	stp	x2, x24, [sp, #0x50]
   133b4:      	ldr	x8, [sp, #0x30]
   133b8:      	ldr	x25, [sp, #0x8]
   133bc:      	add	x9, sp, #0x70
   133c0:      	cmp	x21, x8
   133c4:      	b.ne	0x133d4 <generic_rawtp_path+0xa2d4>
   133c8:      	ldr	x8, [sp, #0x38]
   133cc:      	cmp	x2, x8
   133d0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   133d4:      	mov	w8, #0x4                // =4
   133d8:      	add	x0, sp, #0x70
   133dc:      	mov	w1, #0x8                // =8
   133e0:      	blr	x8
   133e4:      	ldr	x8, [sp, #0x70]
   133e8:      	cmp	x21, x8
   133ec:      	b.eq	0x134e0 <generic_rawtp_path+0xa3e0>
   133f0:      	add	x23, x21, #0x18
   133f4:      	mov	w8, #0x4                // =4
   133f8:      	add	x9, sp, #0x98
   133fc:      	add	x0, sp, #0x98
   13400:      	mov	w1, #0x8                // =8
   13404:      	mov	x2, x23
   13408:      	blr	x8
   1340c:      	ldr	x8, [sp, #0x98]
   13410:      	cmp	x8, x21
   13414:      	b.eq	0x134e0 <generic_rawtp_path+0xa3e0>
   13418:      	mov	w8, #0x4                // =4
   1341c:      	add	x9, sp, #0x78
   13420:      	add	x0, sp, #0x78
   13424:      	mov	w1, #0x8                // =8
   13428:      	mov	x2, x23
   1342c:      	blr	x8
   13430:      	add	x2, x21, #0x20
   13434:      	mov	w8, #0x4                // =4
   13438:      	mov	w9, #0x10               // =16
   1343c:      	add	x10, sp, #0x80
   13440:      	add	x0, sp, #0x80
   13444:      	mov	w1, #0x10               // =16
   13448:      	blr	x8
   1344c:      	ldr	w21, [sp, #0x84]
   13450:      	ldr	x8, [sp, #0x40]
   13454:      	ldr	x10, [sp, #0x60]
   13458:      	sub	x12, x10, x8
   1345c:      	ldr	w23, [sp, #0x68]
   13460:      	subs	w10, w21, w23
   13464:      	ldr	x9, [sp, #0x88]
   13468:      	ldr	x25, [sp, #0x8]
   1346c:      	csel	w10, wzr, w10, lo
   13470:      	cmp	w23, w21
   13474:      	csel	w11, w23, w21, lo
   13478:      	cinc	w13, w11, hi
   1347c:      	sub	w14, w23, w13
   13480:      	subs	x12, x12, x13
   13484:      	str	w14, [sp, #0x68]
   13488:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   1348c:      	cmp	x12, #0xfff
   13490:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13494:      	cmp	w23, w21
   13498:      	b.ls	0x134a4 <generic_rawtp_path+0xa3a4>
   1349c:      	mov	w13, #0x2f              // =47
   134a0:      	strb	w13, [x8, x12]
   134a4:      	add	x19, x8, x12
   134a8:      	cmp	w23, w21
   134ac:      	add	x2, x9, x10
   134b0:      	and	w1, w11, #0xff
   134b4:      	mov	w8, #0x4                // =4
   134b8:      	cinc	x0, x19, hi
   134bc:      	blr	x8
   134c0:      	ldr	x25, [sp, #0x8]
   134c4:      	cmp	w23, w21
   134c8:      	str	x19, [sp, #0x60]
   134cc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   134d0:      	ldr	x21, [sp, #0x78]
   134d4:      	ldp	x2, x24, [sp, #0x50]
   134d8:      	str	x21, [sp, #0x48]
   134dc:      	b	0x13530 <generic_rawtp_path+0xa430>
   134e0:      	add	x2, x24, #0x10
   134e4:      	mov	w8, #0x4                // =4
   134e8:      	add	x9, sp, #0x98
   134ec:      	add	x0, sp, #0x98
   134f0:      	mov	w1, #0x8                // =8
   134f4:      	blr	x8
   134f8:      	ldr	x8, [sp, #0x58]
   134fc:      	ldr	x9, [sp, #0x98]
   13500:      	cmp	x8, x9
   13504:      	ldr	x25, [sp, #0x8]
   13508:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1350c:      	add	x2, x24, #0x18
   13510:      	mov	w8, #0x4                // =4
   13514:      	mov	x0, x22
   13518:      	mov	w1, #0x8                // =8
   1351c:      	blr	x8
   13520:      	ldr	x24, [sp, #0x98]
   13524:      	ldr	x21, [sp, #0x48]
   13528:      	add	x2, x24, #0x20
   1352c:      	stp	x2, x24, [sp, #0x50]
   13530:      	ldr	x8, [sp, #0x30]
   13534:      	ldr	x25, [sp, #0x8]
   13538:      	add	x9, sp, #0x70
   1353c:      	cmp	x21, x8
   13540:      	b.ne	0x13550 <generic_rawtp_path+0xa450>
   13544:      	ldr	x8, [sp, #0x38]
   13548:      	cmp	x2, x8
   1354c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13550:      	mov	w8, #0x4                // =4
   13554:      	add	x0, sp, #0x70
   13558:      	mov	w1, #0x8                // =8
   1355c:      	blr	x8
   13560:      	ldr	x8, [sp, #0x70]
   13564:      	cmp	x21, x8
   13568:      	b.eq	0x1365c <generic_rawtp_path+0xa55c>
   1356c:      	add	x23, x21, #0x18
   13570:      	mov	w8, #0x4                // =4
   13574:      	add	x9, sp, #0x98
   13578:      	add	x0, sp, #0x98
   1357c:      	mov	w1, #0x8                // =8
   13580:      	mov	x2, x23
   13584:      	blr	x8
   13588:      	ldr	x8, [sp, #0x98]
   1358c:      	cmp	x8, x21
   13590:      	b.eq	0x1365c <generic_rawtp_path+0xa55c>
   13594:      	mov	w8, #0x4                // =4
   13598:      	add	x9, sp, #0x78
   1359c:      	add	x0, sp, #0x78
   135a0:      	mov	w1, #0x8                // =8
   135a4:      	mov	x2, x23
   135a8:      	blr	x8
   135ac:      	add	x2, x21, #0x20
   135b0:      	mov	w8, #0x4                // =4
   135b4:      	mov	w9, #0x10               // =16
   135b8:      	add	x10, sp, #0x80
   135bc:      	add	x0, sp, #0x80
   135c0:      	mov	w1, #0x10               // =16
   135c4:      	blr	x8
   135c8:      	ldr	w21, [sp, #0x84]
   135cc:      	ldr	x8, [sp, #0x40]
   135d0:      	ldr	x10, [sp, #0x60]
   135d4:      	sub	x12, x10, x8
   135d8:      	ldr	w23, [sp, #0x68]
   135dc:      	subs	w10, w21, w23
   135e0:      	ldr	x9, [sp, #0x88]
   135e4:      	ldr	x25, [sp, #0x8]
   135e8:      	csel	w10, wzr, w10, lo
   135ec:      	cmp	w23, w21
   135f0:      	csel	w11, w23, w21, lo
   135f4:      	cinc	w13, w11, hi
   135f8:      	sub	w14, w23, w13
   135fc:      	subs	x12, x12, x13
   13600:      	str	w14, [sp, #0x68]
   13604:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13608:      	cmp	x12, #0xfff
   1360c:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13610:      	cmp	w23, w21
   13614:      	b.ls	0x13620 <generic_rawtp_path+0xa520>
   13618:      	mov	w13, #0x2f              // =47
   1361c:      	strb	w13, [x8, x12]
   13620:      	add	x19, x8, x12
   13624:      	cmp	w23, w21
   13628:      	add	x2, x9, x10
   1362c:      	and	w1, w11, #0xff
   13630:      	mov	w8, #0x4                // =4
   13634:      	cinc	x0, x19, hi
   13638:      	blr	x8
   1363c:      	ldr	x25, [sp, #0x8]
   13640:      	cmp	w23, w21
   13644:      	str	x19, [sp, #0x60]
   13648:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1364c:      	ldr	x21, [sp, #0x78]
   13650:      	ldp	x2, x24, [sp, #0x50]
   13654:      	str	x21, [sp, #0x48]
   13658:      	b	0x136ac <generic_rawtp_path+0xa5ac>
   1365c:      	add	x2, x24, #0x10
   13660:      	mov	w8, #0x4                // =4
   13664:      	add	x9, sp, #0x98
   13668:      	add	x0, sp, #0x98
   1366c:      	mov	w1, #0x8                // =8
   13670:      	blr	x8
   13674:      	ldr	x8, [sp, #0x58]
   13678:      	ldr	x9, [sp, #0x98]
   1367c:      	cmp	x8, x9
   13680:      	ldr	x25, [sp, #0x8]
   13684:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13688:      	add	x2, x24, #0x18
   1368c:      	mov	w8, #0x4                // =4
   13690:      	mov	x0, x22
   13694:      	mov	w1, #0x8                // =8
   13698:      	blr	x8
   1369c:      	ldr	x24, [sp, #0x98]
   136a0:      	ldr	x21, [sp, #0x48]
   136a4:      	add	x2, x24, #0x20
   136a8:      	stp	x2, x24, [sp, #0x50]
   136ac:      	ldr	x8, [sp, #0x30]
   136b0:      	ldr	x25, [sp, #0x8]
   136b4:      	add	x9, sp, #0x70
   136b8:      	cmp	x21, x8
   136bc:      	b.ne	0x136cc <generic_rawtp_path+0xa5cc>
   136c0:      	ldr	x8, [sp, #0x38]
   136c4:      	cmp	x2, x8
   136c8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   136cc:      	mov	w8, #0x4                // =4
   136d0:      	add	x0, sp, #0x70
   136d4:      	mov	w1, #0x8                // =8
   136d8:      	blr	x8
   136dc:      	ldr	x8, [sp, #0x70]
   136e0:      	cmp	x21, x8
   136e4:      	b.eq	0x137d8 <generic_rawtp_path+0xa6d8>
   136e8:      	add	x23, x21, #0x18
   136ec:      	mov	w8, #0x4                // =4
   136f0:      	add	x9, sp, #0x98
   136f4:      	add	x0, sp, #0x98
   136f8:      	mov	w1, #0x8                // =8
   136fc:      	mov	x2, x23
   13700:      	blr	x8
   13704:      	ldr	x8, [sp, #0x98]
   13708:      	cmp	x8, x21
   1370c:      	b.eq	0x137d8 <generic_rawtp_path+0xa6d8>
   13710:      	mov	w8, #0x4                // =4
   13714:      	add	x9, sp, #0x78
   13718:      	add	x0, sp, #0x78
   1371c:      	mov	w1, #0x8                // =8
   13720:      	mov	x2, x23
   13724:      	blr	x8
   13728:      	add	x2, x21, #0x20
   1372c:      	mov	w8, #0x4                // =4
   13730:      	mov	w9, #0x10               // =16
   13734:      	add	x10, sp, #0x80
   13738:      	add	x0, sp, #0x80
   1373c:      	mov	w1, #0x10               // =16
   13740:      	blr	x8
   13744:      	ldr	w21, [sp, #0x84]
   13748:      	ldr	x8, [sp, #0x40]
   1374c:      	ldr	x10, [sp, #0x60]
   13750:      	sub	x12, x10, x8
   13754:      	ldr	w23, [sp, #0x68]
   13758:      	subs	w10, w21, w23
   1375c:      	ldr	x9, [sp, #0x88]
   13760:      	ldr	x25, [sp, #0x8]
   13764:      	csel	w10, wzr, w10, lo
   13768:      	cmp	w23, w21
   1376c:      	csel	w11, w23, w21, lo
   13770:      	cinc	w13, w11, hi
   13774:      	sub	w14, w23, w13
   13778:      	subs	x12, x12, x13
   1377c:      	str	w14, [sp, #0x68]
   13780:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13784:      	cmp	x12, #0xfff
   13788:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   1378c:      	cmp	w23, w21
   13790:      	b.ls	0x1379c <generic_rawtp_path+0xa69c>
   13794:      	mov	w13, #0x2f              // =47
   13798:      	strb	w13, [x8, x12]
   1379c:      	add	x19, x8, x12
   137a0:      	cmp	w23, w21
   137a4:      	add	x2, x9, x10
   137a8:      	and	w1, w11, #0xff
   137ac:      	mov	w8, #0x4                // =4
   137b0:      	cinc	x0, x19, hi
   137b4:      	blr	x8
   137b8:      	ldr	x25, [sp, #0x8]
   137bc:      	cmp	w23, w21
   137c0:      	str	x19, [sp, #0x60]
   137c4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   137c8:      	ldr	x21, [sp, #0x78]
   137cc:      	ldp	x2, x24, [sp, #0x50]
   137d0:      	str	x21, [sp, #0x48]
   137d4:      	b	0x13828 <generic_rawtp_path+0xa728>
   137d8:      	add	x2, x24, #0x10
   137dc:      	mov	w8, #0x4                // =4
   137e0:      	add	x9, sp, #0x98
   137e4:      	add	x0, sp, #0x98
   137e8:      	mov	w1, #0x8                // =8
   137ec:      	blr	x8
   137f0:      	ldr	x8, [sp, #0x58]
   137f4:      	ldr	x9, [sp, #0x98]
   137f8:      	cmp	x8, x9
   137fc:      	ldr	x25, [sp, #0x8]
   13800:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13804:      	add	x2, x24, #0x18
   13808:      	mov	w8, #0x4                // =4
   1380c:      	mov	x0, x22
   13810:      	mov	w1, #0x8                // =8
   13814:      	blr	x8
   13818:      	ldr	x24, [sp, #0x98]
   1381c:      	ldr	x21, [sp, #0x48]
   13820:      	add	x2, x24, #0x20
   13824:      	stp	x2, x24, [sp, #0x50]
   13828:      	ldr	x8, [sp, #0x30]
   1382c:      	ldr	x25, [sp, #0x8]
   13830:      	add	x9, sp, #0x70
   13834:      	cmp	x21, x8
   13838:      	b.ne	0x13848 <generic_rawtp_path+0xa748>
   1383c:      	ldr	x8, [sp, #0x38]
   13840:      	cmp	x2, x8
   13844:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13848:      	mov	w8, #0x4                // =4
   1384c:      	add	x0, sp, #0x70
   13850:      	mov	w1, #0x8                // =8
   13854:      	blr	x8
   13858:      	ldr	x8, [sp, #0x70]
   1385c:      	cmp	x21, x8
   13860:      	b.eq	0x13954 <generic_rawtp_path+0xa854>
   13864:      	add	x23, x21, #0x18
   13868:      	mov	w8, #0x4                // =4
   1386c:      	add	x9, sp, #0x98
   13870:      	add	x0, sp, #0x98
   13874:      	mov	w1, #0x8                // =8
   13878:      	mov	x2, x23
   1387c:      	blr	x8
   13880:      	ldr	x8, [sp, #0x98]
   13884:      	cmp	x8, x21
   13888:      	b.eq	0x13954 <generic_rawtp_path+0xa854>
   1388c:      	mov	w8, #0x4                // =4
   13890:      	add	x9, sp, #0x78
   13894:      	add	x0, sp, #0x78
   13898:      	mov	w1, #0x8                // =8
   1389c:      	mov	x2, x23
   138a0:      	blr	x8
   138a4:      	add	x2, x21, #0x20
   138a8:      	mov	w8, #0x4                // =4
   138ac:      	mov	w9, #0x10               // =16
   138b0:      	add	x10, sp, #0x80
   138b4:      	add	x0, sp, #0x80
   138b8:      	mov	w1, #0x10               // =16
   138bc:      	blr	x8
   138c0:      	ldr	w21, [sp, #0x84]
   138c4:      	ldr	x8, [sp, #0x40]
   138c8:      	ldr	x10, [sp, #0x60]
   138cc:      	sub	x12, x10, x8
   138d0:      	ldr	w23, [sp, #0x68]
   138d4:      	subs	w10, w21, w23
   138d8:      	ldr	x9, [sp, #0x88]
   138dc:      	ldr	x25, [sp, #0x8]
   138e0:      	csel	w10, wzr, w10, lo
   138e4:      	cmp	w23, w21
   138e8:      	csel	w11, w23, w21, lo
   138ec:      	cinc	w13, w11, hi
   138f0:      	sub	w14, w23, w13
   138f4:      	subs	x12, x12, x13
   138f8:      	str	w14, [sp, #0x68]
   138fc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13900:      	cmp	x12, #0xfff
   13904:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13908:      	cmp	w23, w21
   1390c:      	b.ls	0x13918 <generic_rawtp_path+0xa818>
   13910:      	mov	w13, #0x2f              // =47
   13914:      	strb	w13, [x8, x12]
   13918:      	add	x19, x8, x12
   1391c:      	cmp	w23, w21
   13920:      	add	x2, x9, x10
   13924:      	and	w1, w11, #0xff
   13928:      	mov	w8, #0x4                // =4
   1392c:      	cinc	x0, x19, hi
   13930:      	blr	x8
   13934:      	ldr	x25, [sp, #0x8]
   13938:      	cmp	w23, w21
   1393c:      	str	x19, [sp, #0x60]
   13940:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   13944:      	ldr	x21, [sp, #0x78]
   13948:      	ldp	x2, x24, [sp, #0x50]
   1394c:      	str	x21, [sp, #0x48]
   13950:      	b	0x139a4 <generic_rawtp_path+0xa8a4>
   13954:      	add	x2, x24, #0x10
   13958:      	mov	w8, #0x4                // =4
   1395c:      	add	x9, sp, #0x98
   13960:      	add	x0, sp, #0x98
   13964:      	mov	w1, #0x8                // =8
   13968:      	blr	x8
   1396c:      	ldr	x8, [sp, #0x58]
   13970:      	ldr	x9, [sp, #0x98]
   13974:      	cmp	x8, x9
   13978:      	ldr	x25, [sp, #0x8]
   1397c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13980:      	add	x2, x24, #0x18
   13984:      	mov	w8, #0x4                // =4
   13988:      	mov	x0, x22
   1398c:      	mov	w1, #0x8                // =8
   13990:      	blr	x8
   13994:      	ldr	x24, [sp, #0x98]
   13998:      	ldr	x21, [sp, #0x48]
   1399c:      	add	x2, x24, #0x20
   139a0:      	stp	x2, x24, [sp, #0x50]
   139a4:      	ldr	x8, [sp, #0x30]
   139a8:      	ldr	x25, [sp, #0x8]
   139ac:      	add	x9, sp, #0x70
   139b0:      	cmp	x21, x8
   139b4:      	b.ne	0x139c4 <generic_rawtp_path+0xa8c4>
   139b8:      	ldr	x8, [sp, #0x38]
   139bc:      	cmp	x2, x8
   139c0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   139c4:      	mov	w8, #0x4                // =4
   139c8:      	add	x0, sp, #0x70
   139cc:      	mov	w1, #0x8                // =8
   139d0:      	blr	x8
   139d4:      	ldr	x8, [sp, #0x70]
   139d8:      	cmp	x21, x8
   139dc:      	b.eq	0x13ad0 <generic_rawtp_path+0xa9d0>
   139e0:      	add	x23, x21, #0x18
   139e4:      	mov	w8, #0x4                // =4
   139e8:      	add	x9, sp, #0x98
   139ec:      	add	x0, sp, #0x98
   139f0:      	mov	w1, #0x8                // =8
   139f4:      	mov	x2, x23
   139f8:      	blr	x8
   139fc:      	ldr	x8, [sp, #0x98]
   13a00:      	cmp	x8, x21
   13a04:      	b.eq	0x13ad0 <generic_rawtp_path+0xa9d0>
   13a08:      	mov	w8, #0x4                // =4
   13a0c:      	add	x9, sp, #0x78
   13a10:      	add	x0, sp, #0x78
   13a14:      	mov	w1, #0x8                // =8
   13a18:      	mov	x2, x23
   13a1c:      	blr	x8
   13a20:      	add	x2, x21, #0x20
   13a24:      	mov	w8, #0x4                // =4
   13a28:      	mov	w9, #0x10               // =16
   13a2c:      	add	x10, sp, #0x80
   13a30:      	add	x0, sp, #0x80
   13a34:      	mov	w1, #0x10               // =16
   13a38:      	blr	x8
   13a3c:      	ldr	w21, [sp, #0x84]
   13a40:      	ldr	x8, [sp, #0x40]
   13a44:      	ldr	x10, [sp, #0x60]
   13a48:      	sub	x12, x10, x8
   13a4c:      	ldr	w23, [sp, #0x68]
   13a50:      	subs	w10, w21, w23
   13a54:      	ldr	x9, [sp, #0x88]
   13a58:      	ldr	x25, [sp, #0x8]
   13a5c:      	csel	w10, wzr, w10, lo
   13a60:      	cmp	w23, w21
   13a64:      	csel	w11, w23, w21, lo
   13a68:      	cinc	w13, w11, hi
   13a6c:      	sub	w14, w23, w13
   13a70:      	subs	x12, x12, x13
   13a74:      	str	w14, [sp, #0x68]
   13a78:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13a7c:      	cmp	x12, #0xfff
   13a80:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13a84:      	cmp	w23, w21
   13a88:      	b.ls	0x13a94 <generic_rawtp_path+0xa994>
   13a8c:      	mov	w13, #0x2f              // =47
   13a90:      	strb	w13, [x8, x12]
   13a94:      	add	x19, x8, x12
   13a98:      	cmp	w23, w21
   13a9c:      	add	x2, x9, x10
   13aa0:      	and	w1, w11, #0xff
   13aa4:      	mov	w8, #0x4                // =4
   13aa8:      	cinc	x0, x19, hi
   13aac:      	blr	x8
   13ab0:      	ldr	x25, [sp, #0x8]
   13ab4:      	cmp	w23, w21
   13ab8:      	str	x19, [sp, #0x60]
   13abc:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   13ac0:      	ldr	x21, [sp, #0x78]
   13ac4:      	ldp	x2, x24, [sp, #0x50]
   13ac8:      	str	x21, [sp, #0x48]
   13acc:      	b	0x13b20 <generic_rawtp_path+0xaa20>
   13ad0:      	add	x2, x24, #0x10
   13ad4:      	mov	w8, #0x4                // =4
   13ad8:      	add	x9, sp, #0x98
   13adc:      	add	x0, sp, #0x98
   13ae0:      	mov	w1, #0x8                // =8
   13ae4:      	blr	x8
   13ae8:      	ldr	x8, [sp, #0x58]
   13aec:      	ldr	x9, [sp, #0x98]
   13af0:      	cmp	x8, x9
   13af4:      	ldr	x25, [sp, #0x8]
   13af8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13afc:      	add	x2, x24, #0x18
   13b00:      	mov	w8, #0x4                // =4
   13b04:      	mov	x0, x22
   13b08:      	mov	w1, #0x8                // =8
   13b0c:      	blr	x8
   13b10:      	ldr	x24, [sp, #0x98]
   13b14:      	ldr	x21, [sp, #0x48]
   13b18:      	add	x2, x24, #0x20
   13b1c:      	stp	x2, x24, [sp, #0x50]
   13b20:      	ldr	x8, [sp, #0x30]
   13b24:      	ldr	x25, [sp, #0x8]
   13b28:      	add	x9, sp, #0x70
   13b2c:      	cmp	x21, x8
   13b30:      	b.ne	0x13b40 <generic_rawtp_path+0xaa40>
   13b34:      	ldr	x8, [sp, #0x38]
   13b38:      	cmp	x2, x8
   13b3c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13b40:      	mov	w8, #0x4                // =4
   13b44:      	add	x0, sp, #0x70
   13b48:      	mov	w1, #0x8                // =8
   13b4c:      	blr	x8
   13b50:      	ldr	x8, [sp, #0x70]
   13b54:      	cmp	x21, x8
   13b58:      	b.eq	0x13c4c <generic_rawtp_path+0xab4c>
   13b5c:      	add	x23, x21, #0x18
   13b60:      	mov	w8, #0x4                // =4
   13b64:      	add	x9, sp, #0x98
   13b68:      	add	x0, sp, #0x98
   13b6c:      	mov	w1, #0x8                // =8
   13b70:      	mov	x2, x23
   13b74:      	blr	x8
   13b78:      	ldr	x8, [sp, #0x98]
   13b7c:      	cmp	x8, x21
   13b80:      	b.eq	0x13c4c <generic_rawtp_path+0xab4c>
   13b84:      	mov	w8, #0x4                // =4
   13b88:      	add	x9, sp, #0x78
   13b8c:      	add	x0, sp, #0x78
   13b90:      	mov	w1, #0x8                // =8
   13b94:      	mov	x2, x23
   13b98:      	blr	x8
   13b9c:      	add	x2, x21, #0x20
   13ba0:      	mov	w8, #0x4                // =4
   13ba4:      	mov	w9, #0x10               // =16
   13ba8:      	add	x10, sp, #0x80
   13bac:      	add	x0, sp, #0x80
   13bb0:      	mov	w1, #0x10               // =16
   13bb4:      	blr	x8
   13bb8:      	ldr	w21, [sp, #0x84]
   13bbc:      	ldr	x8, [sp, #0x40]
   13bc0:      	ldr	x10, [sp, #0x60]
   13bc4:      	sub	x12, x10, x8
   13bc8:      	ldr	w23, [sp, #0x68]
   13bcc:      	subs	w10, w21, w23
   13bd0:      	ldr	x9, [sp, #0x88]
   13bd4:      	ldr	x25, [sp, #0x8]
   13bd8:      	csel	w10, wzr, w10, lo
   13bdc:      	cmp	w23, w21
   13be0:      	csel	w11, w23, w21, lo
   13be4:      	cinc	w13, w11, hi
   13be8:      	sub	w14, w23, w13
   13bec:      	subs	x12, x12, x13
   13bf0:      	str	w14, [sp, #0x68]
   13bf4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13bf8:      	cmp	x12, #0xfff
   13bfc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13c00:      	cmp	w23, w21
   13c04:      	b.ls	0x13c10 <generic_rawtp_path+0xab10>
   13c08:      	mov	w13, #0x2f              // =47
   13c0c:      	strb	w13, [x8, x12]
   13c10:      	add	x19, x8, x12
   13c14:      	cmp	w23, w21
   13c18:      	add	x2, x9, x10
   13c1c:      	and	w1, w11, #0xff
   13c20:      	mov	w8, #0x4                // =4
   13c24:      	cinc	x0, x19, hi
   13c28:      	blr	x8
   13c2c:      	ldr	x25, [sp, #0x8]
   13c30:      	cmp	w23, w21
   13c34:      	str	x19, [sp, #0x60]
   13c38:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   13c3c:      	ldr	x21, [sp, #0x78]
   13c40:      	ldp	x2, x24, [sp, #0x50]
   13c44:      	str	x21, [sp, #0x48]
   13c48:      	b	0x13c9c <generic_rawtp_path+0xab9c>
   13c4c:      	add	x2, x24, #0x10
   13c50:      	mov	w8, #0x4                // =4
   13c54:      	add	x9, sp, #0x98
   13c58:      	add	x0, sp, #0x98
   13c5c:      	mov	w1, #0x8                // =8
   13c60:      	blr	x8
   13c64:      	ldr	x8, [sp, #0x58]
   13c68:      	ldr	x9, [sp, #0x98]
   13c6c:      	cmp	x8, x9
   13c70:      	ldr	x25, [sp, #0x8]
   13c74:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13c78:      	add	x2, x24, #0x18
   13c7c:      	mov	w8, #0x4                // =4
   13c80:      	mov	x0, x22
   13c84:      	mov	w1, #0x8                // =8
   13c88:      	blr	x8
   13c8c:      	ldr	x24, [sp, #0x98]
   13c90:      	ldr	x21, [sp, #0x48]
   13c94:      	add	x2, x24, #0x20
   13c98:      	stp	x2, x24, [sp, #0x50]
   13c9c:      	ldr	x8, [sp, #0x30]
   13ca0:      	ldr	x25, [sp, #0x8]
   13ca4:      	add	x9, sp, #0x70
   13ca8:      	cmp	x21, x8
   13cac:      	b.ne	0x13cbc <generic_rawtp_path+0xabbc>
   13cb0:      	ldr	x8, [sp, #0x38]
   13cb4:      	cmp	x2, x8
   13cb8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13cbc:      	mov	w8, #0x4                // =4
   13cc0:      	add	x0, sp, #0x70
   13cc4:      	mov	w1, #0x8                // =8
   13cc8:      	blr	x8
   13ccc:      	ldr	x8, [sp, #0x70]
   13cd0:      	cmp	x21, x8
   13cd4:      	b.eq	0x13dc8 <generic_rawtp_path+0xacc8>
   13cd8:      	add	x23, x21, #0x18
   13cdc:      	mov	w8, #0x4                // =4
   13ce0:      	add	x9, sp, #0x98
   13ce4:      	add	x0, sp, #0x98
   13ce8:      	mov	w1, #0x8                // =8
   13cec:      	mov	x2, x23
   13cf0:      	blr	x8
   13cf4:      	ldr	x8, [sp, #0x98]
   13cf8:      	cmp	x8, x21
   13cfc:      	b.eq	0x13dc8 <generic_rawtp_path+0xacc8>
   13d00:      	mov	w8, #0x4                // =4
   13d04:      	add	x9, sp, #0x78
   13d08:      	add	x0, sp, #0x78
   13d0c:      	mov	w1, #0x8                // =8
   13d10:      	mov	x2, x23
   13d14:      	blr	x8
   13d18:      	add	x2, x21, #0x20
   13d1c:      	mov	w8, #0x4                // =4
   13d20:      	mov	w9, #0x10               // =16
   13d24:      	add	x10, sp, #0x80
   13d28:      	add	x0, sp, #0x80
   13d2c:      	mov	w1, #0x10               // =16
   13d30:      	blr	x8
   13d34:      	ldr	w21, [sp, #0x84]
   13d38:      	ldr	x8, [sp, #0x40]
   13d3c:      	ldr	x10, [sp, #0x60]
   13d40:      	sub	x12, x10, x8
   13d44:      	ldr	w23, [sp, #0x68]
   13d48:      	subs	w10, w21, w23
   13d4c:      	ldr	x9, [sp, #0x88]
   13d50:      	ldr	x25, [sp, #0x8]
   13d54:      	csel	w10, wzr, w10, lo
   13d58:      	cmp	w23, w21
   13d5c:      	csel	w11, w23, w21, lo
   13d60:      	cinc	w13, w11, hi
   13d64:      	sub	w14, w23, w13
   13d68:      	subs	x12, x12, x13
   13d6c:      	str	w14, [sp, #0x68]
   13d70:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13d74:      	cmp	x12, #0xfff
   13d78:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13d7c:      	cmp	w23, w21
   13d80:      	b.ls	0x13d8c <generic_rawtp_path+0xac8c>
   13d84:      	mov	w13, #0x2f              // =47
   13d88:      	strb	w13, [x8, x12]
   13d8c:      	add	x19, x8, x12
   13d90:      	cmp	w23, w21
   13d94:      	add	x2, x9, x10
   13d98:      	and	w1, w11, #0xff
   13d9c:      	mov	w8, #0x4                // =4
   13da0:      	cinc	x0, x19, hi
   13da4:      	blr	x8
   13da8:      	ldr	x25, [sp, #0x8]
   13dac:      	cmp	w23, w21
   13db0:      	str	x19, [sp, #0x60]
   13db4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   13db8:      	ldr	x21, [sp, #0x78]
   13dbc:      	ldp	x2, x24, [sp, #0x50]
   13dc0:      	str	x21, [sp, #0x48]
   13dc4:      	b	0x13e18 <generic_rawtp_path+0xad18>
   13dc8:      	add	x2, x24, #0x10
   13dcc:      	mov	w8, #0x4                // =4
   13dd0:      	add	x9, sp, #0x98
   13dd4:      	add	x0, sp, #0x98
   13dd8:      	mov	w1, #0x8                // =8
   13ddc:      	blr	x8
   13de0:      	ldr	x8, [sp, #0x58]
   13de4:      	ldr	x9, [sp, #0x98]
   13de8:      	cmp	x8, x9
   13dec:      	ldr	x25, [sp, #0x8]
   13df0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13df4:      	add	x2, x24, #0x18
   13df8:      	mov	w8, #0x4                // =4
   13dfc:      	mov	x0, x22
   13e00:      	mov	w1, #0x8                // =8
   13e04:      	blr	x8
   13e08:      	ldr	x24, [sp, #0x98]
   13e0c:      	ldr	x21, [sp, #0x48]
   13e10:      	add	x2, x24, #0x20
   13e14:      	stp	x2, x24, [sp, #0x50]
   13e18:      	ldr	x8, [sp, #0x30]
   13e1c:      	ldr	x25, [sp, #0x8]
   13e20:      	add	x9, sp, #0x70
   13e24:      	cmp	x21, x8
   13e28:      	b.ne	0x13e38 <generic_rawtp_path+0xad38>
   13e2c:      	ldr	x8, [sp, #0x38]
   13e30:      	cmp	x2, x8
   13e34:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13e38:      	mov	w8, #0x4                // =4
   13e3c:      	add	x0, sp, #0x70
   13e40:      	mov	w1, #0x8                // =8
   13e44:      	blr	x8
   13e48:      	ldr	x8, [sp, #0x70]
   13e4c:      	cmp	x21, x8
   13e50:      	b.eq	0x13f44 <generic_rawtp_path+0xae44>
   13e54:      	add	x23, x21, #0x18
   13e58:      	mov	w8, #0x4                // =4
   13e5c:      	add	x9, sp, #0x98
   13e60:      	add	x0, sp, #0x98
   13e64:      	mov	w1, #0x8                // =8
   13e68:      	mov	x2, x23
   13e6c:      	blr	x8
   13e70:      	ldr	x8, [sp, #0x98]
   13e74:      	cmp	x8, x21
   13e78:      	b.eq	0x13f44 <generic_rawtp_path+0xae44>
   13e7c:      	mov	w8, #0x4                // =4
   13e80:      	add	x9, sp, #0x78
   13e84:      	add	x0, sp, #0x78
   13e88:      	mov	w1, #0x8                // =8
   13e8c:      	mov	x2, x23
   13e90:      	blr	x8
   13e94:      	add	x2, x21, #0x20
   13e98:      	mov	w8, #0x4                // =4
   13e9c:      	mov	w9, #0x10               // =16
   13ea0:      	add	x10, sp, #0x80
   13ea4:      	add	x0, sp, #0x80
   13ea8:      	mov	w1, #0x10               // =16
   13eac:      	blr	x8
   13eb0:      	ldr	w21, [sp, #0x84]
   13eb4:      	ldr	x8, [sp, #0x40]
   13eb8:      	ldr	x10, [sp, #0x60]
   13ebc:      	sub	x12, x10, x8
   13ec0:      	ldr	w23, [sp, #0x68]
   13ec4:      	subs	w10, w21, w23
   13ec8:      	ldr	x9, [sp, #0x88]
   13ecc:      	ldr	x25, [sp, #0x8]
   13ed0:      	csel	w10, wzr, w10, lo
   13ed4:      	cmp	w23, w21
   13ed8:      	csel	w11, w23, w21, lo
   13edc:      	cinc	w13, w11, hi
   13ee0:      	sub	w14, w23, w13
   13ee4:      	subs	x12, x12, x13
   13ee8:      	str	w14, [sp, #0x68]
   13eec:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   13ef0:      	cmp	x12, #0xfff
   13ef4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   13ef8:      	cmp	w23, w21
   13efc:      	b.ls	0x13f08 <generic_rawtp_path+0xae08>
   13f00:      	mov	w13, #0x2f              // =47
   13f04:      	strb	w13, [x8, x12]
   13f08:      	add	x19, x8, x12
   13f0c:      	cmp	w23, w21
   13f10:      	add	x2, x9, x10
   13f14:      	and	w1, w11, #0xff
   13f18:      	mov	w8, #0x4                // =4
   13f1c:      	cinc	x0, x19, hi
   13f20:      	blr	x8
   13f24:      	ldr	x25, [sp, #0x8]
   13f28:      	cmp	w23, w21
   13f2c:      	str	x19, [sp, #0x60]
   13f30:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   13f34:      	ldr	x21, [sp, #0x78]
   13f38:      	ldp	x2, x24, [sp, #0x50]
   13f3c:      	str	x21, [sp, #0x48]
   13f40:      	b	0x13f94 <generic_rawtp_path+0xae94>
   13f44:      	add	x2, x24, #0x10
   13f48:      	mov	w8, #0x4                // =4
   13f4c:      	add	x9, sp, #0x98
   13f50:      	add	x0, sp, #0x98
   13f54:      	mov	w1, #0x8                // =8
   13f58:      	blr	x8
   13f5c:      	ldr	x8, [sp, #0x58]
   13f60:      	ldr	x9, [sp, #0x98]
   13f64:      	cmp	x8, x9
   13f68:      	ldr	x25, [sp, #0x8]
   13f6c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13f70:      	add	x2, x24, #0x18
   13f74:      	mov	w8, #0x4                // =4
   13f78:      	mov	x0, x22
   13f7c:      	mov	w1, #0x8                // =8
   13f80:      	blr	x8
   13f84:      	ldr	x24, [sp, #0x98]
   13f88:      	ldr	x21, [sp, #0x48]
   13f8c:      	add	x2, x24, #0x20
   13f90:      	stp	x2, x24, [sp, #0x50]
   13f94:      	ldr	x8, [sp, #0x30]
   13f98:      	ldr	x25, [sp, #0x8]
   13f9c:      	add	x9, sp, #0x70
   13fa0:      	cmp	x21, x8
   13fa4:      	b.ne	0x13fb4 <generic_rawtp_path+0xaeb4>
   13fa8:      	ldr	x8, [sp, #0x38]
   13fac:      	cmp	x2, x8
   13fb0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   13fb4:      	mov	w8, #0x4                // =4
   13fb8:      	add	x0, sp, #0x70
   13fbc:      	mov	w1, #0x8                // =8
   13fc0:      	blr	x8
   13fc4:      	ldr	x8, [sp, #0x70]
   13fc8:      	cmp	x21, x8
   13fcc:      	b.eq	0x140c0 <generic_rawtp_path+0xafc0>
   13fd0:      	add	x23, x21, #0x18
   13fd4:      	mov	w8, #0x4                // =4
   13fd8:      	add	x9, sp, #0x98
   13fdc:      	add	x0, sp, #0x98
   13fe0:      	mov	w1, #0x8                // =8
   13fe4:      	mov	x2, x23
   13fe8:      	blr	x8
   13fec:      	ldr	x8, [sp, #0x98]
   13ff0:      	cmp	x8, x21
   13ff4:      	b.eq	0x140c0 <generic_rawtp_path+0xafc0>
   13ff8:      	mov	w8, #0x4                // =4
   13ffc:      	add	x9, sp, #0x78
   14000:      	add	x0, sp, #0x78
   14004:      	mov	w1, #0x8                // =8
   14008:      	mov	x2, x23
   1400c:      	blr	x8
   14010:      	add	x2, x21, #0x20
   14014:      	mov	w8, #0x4                // =4
   14018:      	mov	w9, #0x10               // =16
   1401c:      	add	x10, sp, #0x80
   14020:      	add	x0, sp, #0x80
   14024:      	mov	w1, #0x10               // =16
   14028:      	blr	x8
   1402c:      	ldr	w21, [sp, #0x84]
   14030:      	ldr	x8, [sp, #0x40]
   14034:      	ldr	x10, [sp, #0x60]
   14038:      	sub	x12, x10, x8
   1403c:      	ldr	w23, [sp, #0x68]
   14040:      	subs	w10, w21, w23
   14044:      	ldr	x9, [sp, #0x88]
   14048:      	ldr	x25, [sp, #0x8]
   1404c:      	csel	w10, wzr, w10, lo
   14050:      	cmp	w23, w21
   14054:      	csel	w11, w23, w21, lo
   14058:      	cinc	w13, w11, hi
   1405c:      	sub	w14, w23, w13
   14060:      	subs	x12, x12, x13
   14064:      	str	w14, [sp, #0x68]
   14068:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   1406c:      	cmp	x12, #0xfff
   14070:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   14074:      	cmp	w23, w21
   14078:      	b.ls	0x14084 <generic_rawtp_path+0xaf84>
   1407c:      	mov	w13, #0x2f              // =47
   14080:      	strb	w13, [x8, x12]
   14084:      	add	x19, x8, x12
   14088:      	cmp	w23, w21
   1408c:      	add	x2, x9, x10
   14090:      	and	w1, w11, #0xff
   14094:      	mov	w8, #0x4                // =4
   14098:      	cinc	x0, x19, hi
   1409c:      	blr	x8
   140a0:      	ldr	x25, [sp, #0x8]
   140a4:      	cmp	w23, w21
   140a8:      	str	x19, [sp, #0x60]
   140ac:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   140b0:      	ldr	x21, [sp, #0x78]
   140b4:      	ldp	x2, x24, [sp, #0x50]
   140b8:      	str	x21, [sp, #0x48]
   140bc:      	b	0x14110 <generic_rawtp_path+0xb010>
   140c0:      	add	x2, x24, #0x10
   140c4:      	mov	w8, #0x4                // =4
   140c8:      	add	x9, sp, #0x98
   140cc:      	add	x0, sp, #0x98
   140d0:      	mov	w1, #0x8                // =8
   140d4:      	blr	x8
   140d8:      	ldr	x8, [sp, #0x58]
   140dc:      	ldr	x9, [sp, #0x98]
   140e0:      	cmp	x8, x9
   140e4:      	ldr	x25, [sp, #0x8]
   140e8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   140ec:      	add	x2, x24, #0x18
   140f0:      	mov	w8, #0x4                // =4
   140f4:      	mov	x0, x22
   140f8:      	mov	w1, #0x8                // =8
   140fc:      	blr	x8
   14100:      	ldr	x24, [sp, #0x98]
   14104:      	ldr	x21, [sp, #0x48]
   14108:      	add	x2, x24, #0x20
   1410c:      	stp	x2, x24, [sp, #0x50]
   14110:      	ldr	x8, [sp, #0x30]
   14114:      	ldr	x25, [sp, #0x8]
   14118:      	add	x9, sp, #0x70
   1411c:      	cmp	x21, x8
   14120:      	b.ne	0x14130 <generic_rawtp_path+0xb030>
   14124:      	ldr	x8, [sp, #0x38]
   14128:      	cmp	x2, x8
   1412c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14130:      	mov	w8, #0x4                // =4
   14134:      	add	x0, sp, #0x70
   14138:      	mov	w1, #0x8                // =8
   1413c:      	blr	x8
   14140:      	ldr	x8, [sp, #0x70]
   14144:      	cmp	x21, x8
   14148:      	b.eq	0x1423c <generic_rawtp_path+0xb13c>
   1414c:      	add	x23, x21, #0x18
   14150:      	mov	w8, #0x4                // =4
   14154:      	add	x9, sp, #0x98
   14158:      	add	x0, sp, #0x98
   1415c:      	mov	w1, #0x8                // =8
   14160:      	mov	x2, x23
   14164:      	blr	x8
   14168:      	ldr	x8, [sp, #0x98]
   1416c:      	cmp	x8, x21
   14170:      	b.eq	0x1423c <generic_rawtp_path+0xb13c>
   14174:      	mov	w8, #0x4                // =4
   14178:      	add	x9, sp, #0x78
   1417c:      	add	x0, sp, #0x78
   14180:      	mov	w1, #0x8                // =8
   14184:      	mov	x2, x23
   14188:      	blr	x8
   1418c:      	add	x2, x21, #0x20
   14190:      	mov	w8, #0x4                // =4
   14194:      	mov	w9, #0x10               // =16
   14198:      	add	x10, sp, #0x80
   1419c:      	add	x0, sp, #0x80
   141a0:      	mov	w1, #0x10               // =16
   141a4:      	blr	x8
   141a8:      	ldr	w21, [sp, #0x84]
   141ac:      	ldr	x8, [sp, #0x40]
   141b0:      	ldr	x10, [sp, #0x60]
   141b4:      	sub	x12, x10, x8
   141b8:      	ldr	w23, [sp, #0x68]
   141bc:      	subs	w10, w21, w23
   141c0:      	ldr	x9, [sp, #0x88]
   141c4:      	ldr	x25, [sp, #0x8]
   141c8:      	csel	w10, wzr, w10, lo
   141cc:      	cmp	w23, w21
   141d0:      	csel	w11, w23, w21, lo
   141d4:      	cinc	w13, w11, hi
   141d8:      	sub	w14, w23, w13
   141dc:      	subs	x12, x12, x13
   141e0:      	str	w14, [sp, #0x68]
   141e4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   141e8:      	cmp	x12, #0xfff
   141ec:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   141f0:      	cmp	w23, w21
   141f4:      	b.ls	0x14200 <generic_rawtp_path+0xb100>
   141f8:      	mov	w13, #0x2f              // =47
   141fc:      	strb	w13, [x8, x12]
   14200:      	add	x19, x8, x12
   14204:      	cmp	w23, w21
   14208:      	add	x2, x9, x10
   1420c:      	and	w1, w11, #0xff
   14210:      	mov	w8, #0x4                // =4
   14214:      	cinc	x0, x19, hi
   14218:      	blr	x8
   1421c:      	ldr	x25, [sp, #0x8]
   14220:      	cmp	w23, w21
   14224:      	str	x19, [sp, #0x60]
   14228:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1422c:      	ldr	x21, [sp, #0x78]
   14230:      	ldp	x2, x24, [sp, #0x50]
   14234:      	str	x21, [sp, #0x48]
   14238:      	b	0x1428c <generic_rawtp_path+0xb18c>
   1423c:      	add	x2, x24, #0x10
   14240:      	mov	w8, #0x4                // =4
   14244:      	add	x9, sp, #0x98
   14248:      	add	x0, sp, #0x98
   1424c:      	mov	w1, #0x8                // =8
   14250:      	blr	x8
   14254:      	ldr	x8, [sp, #0x58]
   14258:      	ldr	x9, [sp, #0x98]
   1425c:      	cmp	x8, x9
   14260:      	ldr	x25, [sp, #0x8]
   14264:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14268:      	add	x2, x24, #0x18
   1426c:      	mov	w8, #0x4                // =4
   14270:      	mov	x0, x22
   14274:      	mov	w1, #0x8                // =8
   14278:      	blr	x8
   1427c:      	ldr	x24, [sp, #0x98]
   14280:      	ldr	x21, [sp, #0x48]
   14284:      	add	x2, x24, #0x20
   14288:      	stp	x2, x24, [sp, #0x50]
   1428c:      	ldr	x8, [sp, #0x30]
   14290:      	ldr	x25, [sp, #0x8]
   14294:      	add	x9, sp, #0x70
   14298:      	cmp	x21, x8
   1429c:      	b.ne	0x142ac <generic_rawtp_path+0xb1ac>
   142a0:      	ldr	x8, [sp, #0x38]
   142a4:      	cmp	x2, x8
   142a8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   142ac:      	mov	w8, #0x4                // =4
   142b0:      	add	x0, sp, #0x70
   142b4:      	mov	w1, #0x8                // =8
   142b8:      	blr	x8
   142bc:      	ldr	x8, [sp, #0x70]
   142c0:      	cmp	x21, x8
   142c4:      	b.eq	0x143b8 <generic_rawtp_path+0xb2b8>
   142c8:      	add	x23, x21, #0x18
   142cc:      	mov	w8, #0x4                // =4
   142d0:      	add	x9, sp, #0x98
   142d4:      	add	x0, sp, #0x98
   142d8:      	mov	w1, #0x8                // =8
   142dc:      	mov	x2, x23
   142e0:      	blr	x8
   142e4:      	ldr	x8, [sp, #0x98]
   142e8:      	cmp	x8, x21
   142ec:      	b.eq	0x143b8 <generic_rawtp_path+0xb2b8>
   142f0:      	mov	w8, #0x4                // =4
   142f4:      	add	x9, sp, #0x78
   142f8:      	add	x0, sp, #0x78
   142fc:      	mov	w1, #0x8                // =8
   14300:      	mov	x2, x23
   14304:      	blr	x8
   14308:      	add	x2, x21, #0x20
   1430c:      	mov	w8, #0x4                // =4
   14310:      	mov	w9, #0x10               // =16
   14314:      	add	x10, sp, #0x80
   14318:      	add	x0, sp, #0x80
   1431c:      	mov	w1, #0x10               // =16
   14320:      	blr	x8
   14324:      	ldr	w21, [sp, #0x84]
   14328:      	ldr	x8, [sp, #0x40]
   1432c:      	ldr	x10, [sp, #0x60]
   14330:      	sub	x12, x10, x8
   14334:      	ldr	w23, [sp, #0x68]
   14338:      	subs	w10, w21, w23
   1433c:      	ldr	x9, [sp, #0x88]
   14340:      	ldr	x25, [sp, #0x8]
   14344:      	csel	w10, wzr, w10, lo
   14348:      	cmp	w23, w21
   1434c:      	csel	w11, w23, w21, lo
   14350:      	cinc	w13, w11, hi
   14354:      	sub	w14, w23, w13
   14358:      	subs	x12, x12, x13
   1435c:      	str	w14, [sp, #0x68]
   14360:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   14364:      	cmp	x12, #0xfff
   14368:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   1436c:      	cmp	w23, w21
   14370:      	b.ls	0x1437c <generic_rawtp_path+0xb27c>
   14374:      	mov	w13, #0x2f              // =47
   14378:      	strb	w13, [x8, x12]
   1437c:      	add	x19, x8, x12
   14380:      	cmp	w23, w21
   14384:      	add	x2, x9, x10
   14388:      	and	w1, w11, #0xff
   1438c:      	mov	w8, #0x4                // =4
   14390:      	cinc	x0, x19, hi
   14394:      	blr	x8
   14398:      	ldr	x25, [sp, #0x8]
   1439c:      	cmp	w23, w21
   143a0:      	str	x19, [sp, #0x60]
   143a4:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   143a8:      	ldr	x21, [sp, #0x78]
   143ac:      	ldp	x2, x24, [sp, #0x50]
   143b0:      	str	x21, [sp, #0x48]
   143b4:      	b	0x14408 <generic_rawtp_path+0xb308>
   143b8:      	add	x2, x24, #0x10
   143bc:      	mov	w8, #0x4                // =4
   143c0:      	add	x9, sp, #0x98
   143c4:      	add	x0, sp, #0x98
   143c8:      	mov	w1, #0x8                // =8
   143cc:      	blr	x8
   143d0:      	ldr	x8, [sp, #0x58]
   143d4:      	ldr	x9, [sp, #0x98]
   143d8:      	cmp	x8, x9
   143dc:      	ldr	x25, [sp, #0x8]
   143e0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   143e4:      	add	x2, x24, #0x18
   143e8:      	mov	w8, #0x4                // =4
   143ec:      	mov	x0, x22
   143f0:      	mov	w1, #0x8                // =8
   143f4:      	blr	x8
   143f8:      	ldr	x24, [sp, #0x98]
   143fc:      	ldr	x21, [sp, #0x48]
   14400:      	add	x2, x24, #0x20
   14404:      	stp	x2, x24, [sp, #0x50]
   14408:      	ldr	x8, [sp, #0x30]
   1440c:      	ldr	x25, [sp, #0x8]
   14410:      	add	x9, sp, #0x70
   14414:      	cmp	x21, x8
   14418:      	b.ne	0x14428 <generic_rawtp_path+0xb328>
   1441c:      	ldr	x8, [sp, #0x38]
   14420:      	cmp	x2, x8
   14424:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14428:      	mov	w8, #0x4                // =4
   1442c:      	add	x0, sp, #0x70
   14430:      	mov	w1, #0x8                // =8
   14434:      	blr	x8
   14438:      	ldr	x8, [sp, #0x70]
   1443c:      	cmp	x21, x8
   14440:      	b.eq	0x14534 <generic_rawtp_path+0xb434>
   14444:      	add	x23, x21, #0x18
   14448:      	mov	w8, #0x4                // =4
   1444c:      	add	x9, sp, #0x98
   14450:      	add	x0, sp, #0x98
   14454:      	mov	w1, #0x8                // =8
   14458:      	mov	x2, x23
   1445c:      	blr	x8
   14460:      	ldr	x8, [sp, #0x98]
   14464:      	cmp	x8, x21
   14468:      	b.eq	0x14534 <generic_rawtp_path+0xb434>
   1446c:      	mov	w8, #0x4                // =4
   14470:      	add	x9, sp, #0x78
   14474:      	add	x0, sp, #0x78
   14478:      	mov	w1, #0x8                // =8
   1447c:      	mov	x2, x23
   14480:      	blr	x8
   14484:      	add	x2, x21, #0x20
   14488:      	mov	w8, #0x4                // =4
   1448c:      	mov	w9, #0x10               // =16
   14490:      	add	x10, sp, #0x80
   14494:      	add	x0, sp, #0x80
   14498:      	mov	w1, #0x10               // =16
   1449c:      	blr	x8
   144a0:      	ldr	w21, [sp, #0x84]
   144a4:      	ldr	x8, [sp, #0x40]
   144a8:      	ldr	x10, [sp, #0x60]
   144ac:      	sub	x12, x10, x8
   144b0:      	ldr	w23, [sp, #0x68]
   144b4:      	subs	w10, w21, w23
   144b8:      	ldr	x9, [sp, #0x88]
   144bc:      	ldr	x25, [sp, #0x8]
   144c0:      	csel	w10, wzr, w10, lo
   144c4:      	cmp	w23, w21
   144c8:      	csel	w11, w23, w21, lo
   144cc:      	cinc	w13, w11, hi
   144d0:      	sub	w14, w23, w13
   144d4:      	subs	x12, x12, x13
   144d8:      	str	w14, [sp, #0x68]
   144dc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   144e0:      	cmp	x12, #0xfff
   144e4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   144e8:      	cmp	w23, w21
   144ec:      	b.ls	0x144f8 <generic_rawtp_path+0xb3f8>
   144f0:      	mov	w13, #0x2f              // =47
   144f4:      	strb	w13, [x8, x12]
   144f8:      	add	x19, x8, x12
   144fc:      	cmp	w23, w21
   14500:      	add	x2, x9, x10
   14504:      	and	w1, w11, #0xff
   14508:      	mov	w8, #0x4                // =4
   1450c:      	cinc	x0, x19, hi
   14510:      	blr	x8
   14514:      	ldr	x25, [sp, #0x8]
   14518:      	cmp	w23, w21
   1451c:      	str	x19, [sp, #0x60]
   14520:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   14524:      	ldr	x21, [sp, #0x78]
   14528:      	ldp	x2, x24, [sp, #0x50]
   1452c:      	str	x21, [sp, #0x48]
   14530:      	b	0x14584 <generic_rawtp_path+0xb484>
   14534:      	add	x2, x24, #0x10
   14538:      	mov	w8, #0x4                // =4
   1453c:      	add	x9, sp, #0x98
   14540:      	add	x0, sp, #0x98
   14544:      	mov	w1, #0x8                // =8
   14548:      	blr	x8
   1454c:      	ldr	x8, [sp, #0x58]
   14550:      	ldr	x9, [sp, #0x98]
   14554:      	cmp	x8, x9
   14558:      	ldr	x25, [sp, #0x8]
   1455c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14560:      	add	x2, x24, #0x18
   14564:      	mov	w8, #0x4                // =4
   14568:      	mov	x0, x22
   1456c:      	mov	w1, #0x8                // =8
   14570:      	blr	x8
   14574:      	ldr	x24, [sp, #0x98]
   14578:      	ldr	x21, [sp, #0x48]
   1457c:      	add	x2, x24, #0x20
   14580:      	stp	x2, x24, [sp, #0x50]
   14584:      	ldr	x8, [sp, #0x30]
   14588:      	ldr	x25, [sp, #0x8]
   1458c:      	add	x9, sp, #0x70
   14590:      	cmp	x21, x8
   14594:      	b.ne	0x145a4 <generic_rawtp_path+0xb4a4>
   14598:      	ldr	x8, [sp, #0x38]
   1459c:      	cmp	x2, x8
   145a0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   145a4:      	mov	w8, #0x4                // =4
   145a8:      	add	x0, sp, #0x70
   145ac:      	mov	w1, #0x8                // =8
   145b0:      	blr	x8
   145b4:      	ldr	x8, [sp, #0x70]
   145b8:      	cmp	x21, x8
   145bc:      	b.eq	0x146b0 <generic_rawtp_path+0xb5b0>
   145c0:      	add	x23, x21, #0x18
   145c4:      	mov	w8, #0x4                // =4
   145c8:      	add	x9, sp, #0x98
   145cc:      	add	x0, sp, #0x98
   145d0:      	mov	w1, #0x8                // =8
   145d4:      	mov	x2, x23
   145d8:      	blr	x8
   145dc:      	ldr	x8, [sp, #0x98]
   145e0:      	cmp	x8, x21
   145e4:      	b.eq	0x146b0 <generic_rawtp_path+0xb5b0>
   145e8:      	mov	w8, #0x4                // =4
   145ec:      	add	x9, sp, #0x78
   145f0:      	add	x0, sp, #0x78
   145f4:      	mov	w1, #0x8                // =8
   145f8:      	mov	x2, x23
   145fc:      	blr	x8
   14600:      	add	x2, x21, #0x20
   14604:      	mov	w8, #0x4                // =4
   14608:      	mov	w9, #0x10               // =16
   1460c:      	add	x10, sp, #0x80
   14610:      	add	x0, sp, #0x80
   14614:      	mov	w1, #0x10               // =16
   14618:      	blr	x8
   1461c:      	ldr	w21, [sp, #0x84]
   14620:      	ldr	x8, [sp, #0x40]
   14624:      	ldr	x10, [sp, #0x60]
   14628:      	sub	x12, x10, x8
   1462c:      	ldr	w23, [sp, #0x68]
   14630:      	subs	w10, w21, w23
   14634:      	ldr	x9, [sp, #0x88]
   14638:      	ldr	x25, [sp, #0x8]
   1463c:      	csel	w10, wzr, w10, lo
   14640:      	cmp	w23, w21
   14644:      	csel	w11, w23, w21, lo
   14648:      	cinc	w13, w11, hi
   1464c:      	sub	w14, w23, w13
   14650:      	subs	x12, x12, x13
   14654:      	str	w14, [sp, #0x68]
   14658:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   1465c:      	cmp	x12, #0xfff
   14660:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   14664:      	cmp	w23, w21
   14668:      	b.ls	0x14674 <generic_rawtp_path+0xb574>
   1466c:      	mov	w13, #0x2f              // =47
   14670:      	strb	w13, [x8, x12]
   14674:      	add	x19, x8, x12
   14678:      	cmp	w23, w21
   1467c:      	add	x2, x9, x10
   14680:      	and	w1, w11, #0xff
   14684:      	mov	w8, #0x4                // =4
   14688:      	cinc	x0, x19, hi
   1468c:      	blr	x8
   14690:      	ldr	x25, [sp, #0x8]
   14694:      	cmp	w23, w21
   14698:      	str	x19, [sp, #0x60]
   1469c:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   146a0:      	ldr	x21, [sp, #0x78]
   146a4:      	ldp	x2, x24, [sp, #0x50]
   146a8:      	str	x21, [sp, #0x48]
   146ac:      	b	0x14700 <generic_rawtp_path+0xb600>
   146b0:      	add	x2, x24, #0x10
   146b4:      	mov	w8, #0x4                // =4
   146b8:      	add	x9, sp, #0x98
   146bc:      	add	x0, sp, #0x98
   146c0:      	mov	w1, #0x8                // =8
   146c4:      	blr	x8
   146c8:      	ldr	x8, [sp, #0x58]
   146cc:      	ldr	x9, [sp, #0x98]
   146d0:      	cmp	x8, x9
   146d4:      	ldr	x25, [sp, #0x8]
   146d8:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   146dc:      	add	x2, x24, #0x18
   146e0:      	mov	w8, #0x4                // =4
   146e4:      	mov	x0, x22
   146e8:      	mov	w1, #0x8                // =8
   146ec:      	blr	x8
   146f0:      	ldr	x24, [sp, #0x98]
   146f4:      	ldr	x21, [sp, #0x48]
   146f8:      	add	x2, x24, #0x20
   146fc:      	stp	x2, x24, [sp, #0x50]
   14700:      	ldr	x8, [sp, #0x30]
   14704:      	ldr	x25, [sp, #0x8]
   14708:      	add	x9, sp, #0x70
   1470c:      	cmp	x21, x8
   14710:      	b.ne	0x14720 <generic_rawtp_path+0xb620>
   14714:      	ldr	x8, [sp, #0x38]
   14718:      	cmp	x2, x8
   1471c:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14720:      	mov	w8, #0x4                // =4
   14724:      	add	x0, sp, #0x70
   14728:      	mov	w1, #0x8                // =8
   1472c:      	blr	x8
   14730:      	ldr	x8, [sp, #0x70]
   14734:      	cmp	x21, x8
   14738:      	b.eq	0x1482c <generic_rawtp_path+0xb72c>
   1473c:      	add	x23, x21, #0x18
   14740:      	mov	w8, #0x4                // =4
   14744:      	add	x9, sp, #0x98
   14748:      	add	x0, sp, #0x98
   1474c:      	mov	w1, #0x8                // =8
   14750:      	mov	x2, x23
   14754:      	blr	x8
   14758:      	ldr	x8, [sp, #0x98]
   1475c:      	cmp	x8, x21
   14760:      	b.eq	0x1482c <generic_rawtp_path+0xb72c>
   14764:      	mov	w8, #0x4                // =4
   14768:      	add	x9, sp, #0x78
   1476c:      	add	x0, sp, #0x78
   14770:      	mov	w1, #0x8                // =8
   14774:      	mov	x2, x23
   14778:      	blr	x8
   1477c:      	add	x2, x21, #0x20
   14780:      	mov	w8, #0x4                // =4
   14784:      	mov	w9, #0x10               // =16
   14788:      	add	x10, sp, #0x80
   1478c:      	add	x0, sp, #0x80
   14790:      	mov	w1, #0x10               // =16
   14794:      	blr	x8
   14798:      	ldr	w21, [sp, #0x84]
   1479c:      	ldr	x8, [sp, #0x40]
   147a0:      	ldr	x10, [sp, #0x60]
   147a4:      	sub	x12, x10, x8
   147a8:      	ldr	w23, [sp, #0x68]
   147ac:      	subs	w10, w21, w23
   147b0:      	ldr	x9, [sp, #0x88]
   147b4:      	ldr	x25, [sp, #0x8]
   147b8:      	csel	w10, wzr, w10, lo
   147bc:      	cmp	w23, w21
   147c0:      	csel	w11, w23, w21, lo
   147c4:      	cinc	w13, w11, hi
   147c8:      	sub	w14, w23, w13
   147cc:      	subs	x12, x12, x13
   147d0:      	str	w14, [sp, #0x68]
   147d4:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   147d8:      	cmp	x12, #0xfff
   147dc:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   147e0:      	cmp	w23, w21
   147e4:      	b.ls	0x147f0 <generic_rawtp_path+0xb6f0>
   147e8:      	mov	w13, #0x2f              // =47
   147ec:      	strb	w13, [x8, x12]
   147f0:      	add	x19, x8, x12
   147f4:      	cmp	w23, w21
   147f8:      	add	x2, x9, x10
   147fc:      	and	w1, w11, #0xff
   14800:      	mov	w8, #0x4                // =4
   14804:      	cinc	x0, x19, hi
   14808:      	blr	x8
   1480c:      	ldr	x25, [sp, #0x8]
   14810:      	cmp	w23, w21
   14814:      	str	x19, [sp, #0x60]
   14818:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   1481c:      	ldr	x21, [sp, #0x78]
   14820:      	ldp	x2, x24, [sp, #0x50]
   14824:      	str	x21, [sp, #0x48]
   14828:      	b	0x1487c <generic_rawtp_path+0xb77c>
   1482c:      	add	x2, x24, #0x10
   14830:      	mov	w8, #0x4                // =4
   14834:      	add	x9, sp, #0x98
   14838:      	add	x0, sp, #0x98
   1483c:      	mov	w1, #0x8                // =8
   14840:      	blr	x8
   14844:      	ldr	x8, [sp, #0x58]
   14848:      	ldr	x9, [sp, #0x98]
   1484c:      	cmp	x8, x9
   14850:      	ldr	x25, [sp, #0x8]
   14854:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14858:      	add	x2, x24, #0x18
   1485c:      	mov	w8, #0x4                // =4
   14860:      	mov	x0, x22
   14864:      	mov	w1, #0x8                // =8
   14868:      	blr	x8
   1486c:      	ldr	x24, [sp, #0x98]
   14870:      	ldr	x21, [sp, #0x48]
   14874:      	add	x2, x24, #0x20
   14878:      	stp	x2, x24, [sp, #0x50]
   1487c:      	ldr	x8, [sp, #0x30]
   14880:      	ldr	x25, [sp, #0x8]
   14884:      	add	x9, sp, #0x70
   14888:      	cmp	x21, x8
   1488c:      	b.ne	0x1489c <generic_rawtp_path+0xb79c>
   14890:      	ldr	x8, [sp, #0x38]
   14894:      	cmp	x2, x8
   14898:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   1489c:      	mov	w8, #0x4                // =4
   148a0:      	add	x0, sp, #0x70
   148a4:      	mov	w1, #0x8                // =8
   148a8:      	blr	x8
   148ac:      	ldr	x8, [sp, #0x70]
   148b0:      	cmp	x21, x8
   148b4:      	b.eq	0x149a8 <generic_rawtp_path+0xb8a8>
   148b8:      	add	x23, x21, #0x18
   148bc:      	mov	w8, #0x4                // =4
   148c0:      	add	x9, sp, #0x98
   148c4:      	add	x0, sp, #0x98
   148c8:      	mov	w1, #0x8                // =8
   148cc:      	mov	x2, x23
   148d0:      	blr	x8
   148d4:      	ldr	x8, [sp, #0x98]
   148d8:      	cmp	x8, x21
   148dc:      	b.eq	0x149a8 <generic_rawtp_path+0xb8a8>
   148e0:      	mov	w8, #0x4                // =4
   148e4:      	add	x9, sp, #0x78
   148e8:      	add	x0, sp, #0x78
   148ec:      	mov	w1, #0x8                // =8
   148f0:      	mov	x2, x23
   148f4:      	blr	x8
   148f8:      	add	x2, x21, #0x20
   148fc:      	mov	w8, #0x4                // =4
   14900:      	mov	w9, #0x10               // =16
   14904:      	add	x10, sp, #0x80
   14908:      	add	x0, sp, #0x80
   1490c:      	mov	w1, #0x10               // =16
   14910:      	blr	x8
   14914:      	ldr	w21, [sp, #0x84]
   14918:      	ldr	x8, [sp, #0x40]
   1491c:      	ldr	x10, [sp, #0x60]
   14920:      	sub	x12, x10, x8
   14924:      	ldr	w23, [sp, #0x68]
   14928:      	subs	w10, w21, w23
   1492c:      	ldr	x9, [sp, #0x88]
   14930:      	ldr	x25, [sp, #0x8]
   14934:      	csel	w10, wzr, w10, lo
   14938:      	cmp	w23, w21
   1493c:      	csel	w11, w23, w21, lo
   14940:      	cinc	w13, w11, hi
   14944:      	sub	w14, w23, w13
   14948:      	subs	x12, x12, x13
   1494c:      	str	w14, [sp, #0x68]
   14950:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   14954:      	cmp	x12, #0xfff
   14958:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   1495c:      	cmp	w23, w21
   14960:      	b.ls	0x1496c <generic_rawtp_path+0xb86c>
   14964:      	mov	w13, #0x2f              // =47
   14968:      	strb	w13, [x8, x12]
   1496c:      	add	x19, x8, x12
   14970:      	cmp	w23, w21
   14974:      	add	x2, x9, x10
   14978:      	and	w1, w11, #0xff
   1497c:      	mov	w8, #0x4                // =4
   14980:      	cinc	x0, x19, hi
   14984:      	blr	x8
   14988:      	ldr	x25, [sp, #0x8]
   1498c:      	cmp	w23, w21
   14990:      	str	x19, [sp, #0x60]
   14994:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   14998:      	ldr	x21, [sp, #0x78]
   1499c:      	ldp	x2, x24, [sp, #0x50]
   149a0:      	str	x21, [sp, #0x48]
   149a4:      	b	0x149f8 <generic_rawtp_path+0xb8f8>
   149a8:      	add	x2, x24, #0x10
   149ac:      	mov	w8, #0x4                // =4
   149b0:      	add	x9, sp, #0x98
   149b4:      	add	x0, sp, #0x98
   149b8:      	mov	w1, #0x8                // =8
   149bc:      	blr	x8
   149c0:      	ldr	x8, [sp, #0x58]
   149c4:      	ldr	x9, [sp, #0x98]
   149c8:      	cmp	x8, x9
   149cc:      	ldr	x25, [sp, #0x8]
   149d0:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   149d4:      	add	x2, x24, #0x18
   149d8:      	mov	w8, #0x4                // =4
   149dc:      	mov	x0, x22
   149e0:      	mov	w1, #0x8                // =8
   149e4:      	blr	x8
   149e8:      	ldr	x24, [sp, #0x98]
   149ec:      	ldr	x21, [sp, #0x48]
   149f0:      	add	x2, x24, #0x20
   149f4:      	stp	x2, x24, [sp, #0x50]
   149f8:      	ldr	x8, [sp, #0x30]
   149fc:      	ldr	x25, [sp, #0x8]
   14a00:      	add	x9, sp, #0x70
   14a04:      	cmp	x21, x8
   14a08:      	b.ne	0x14a18 <generic_rawtp_path+0xb918>
   14a0c:      	ldr	x8, [sp, #0x38]
   14a10:      	cmp	x2, x8
   14a14:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14a18:      	mov	w8, #0x4                // =4
   14a1c:      	add	x0, sp, #0x70
   14a20:      	mov	w1, #0x8                // =8
   14a24:      	blr	x8
   14a28:      	ldr	x8, [sp, #0x70]
   14a2c:      	cmp	x21, x8
   14a30:      	b.eq	0x14b20 <generic_rawtp_path+0xba20>
   14a34:      	add	x23, x21, #0x18
   14a38:      	mov	w8, #0x4                // =4
   14a3c:      	add	x9, sp, #0x98
   14a40:      	add	x0, sp, #0x98
   14a44:      	mov	w1, #0x8                // =8
   14a48:      	mov	x2, x23
   14a4c:      	blr	x8
   14a50:      	ldr	x8, [sp, #0x98]
   14a54:      	cmp	x8, x21
   14a58:      	b.eq	0x14b20 <generic_rawtp_path+0xba20>
   14a5c:      	mov	w8, #0x4                // =4
   14a60:      	add	x9, sp, #0x78
   14a64:      	add	x0, sp, #0x78
   14a68:      	mov	w1, #0x8                // =8
   14a6c:      	mov	x2, x23
   14a70:      	blr	x8
   14a74:      	add	x2, x21, #0x20
   14a78:      	mov	w8, #0x4                // =4
   14a7c:      	mov	w9, #0x10               // =16
   14a80:      	add	x10, sp, #0x80
   14a84:      	add	x0, sp, #0x80
   14a88:      	mov	w1, #0x10               // =16
   14a8c:      	blr	x8
   14a90:      	ldr	w21, [sp, #0x84]
   14a94:      	ldr	x8, [sp, #0x40]
   14a98:      	ldr	x10, [sp, #0x60]
   14a9c:      	sub	x12, x10, x8
   14aa0:      	ldr	w23, [sp, #0x68]
   14aa4:      	subs	w10, w21, w23
   14aa8:      	ldr	x9, [sp, #0x88]
   14aac:      	ldr	x25, [sp, #0x8]
   14ab0:      	csel	w10, wzr, w10, lo
   14ab4:      	cmp	w23, w21
   14ab8:      	csel	w11, w23, w21, lo
   14abc:      	cinc	w13, w11, hi
   14ac0:      	sub	w14, w23, w13
   14ac4:      	subs	x12, x12, x13
   14ac8:      	str	w14, [sp, #0x68]
   14acc:      	b.lo	0x14b88 <generic_rawtp_path+0xba88>
   14ad0:      	cmp	x12, #0xfff
   14ad4:      	b.hi	0x14b88 <generic_rawtp_path+0xba88>
   14ad8:      	cmp	w23, w21
   14adc:      	b.ls	0x14ae8 <generic_rawtp_path+0xb9e8>
   14ae0:      	mov	w13, #0x2f              // =47
   14ae4:      	strb	w13, [x8, x12]
   14ae8:      	add	x19, x8, x12
   14aec:      	cmp	w23, w21
   14af0:      	add	x2, x9, x10
   14af4:      	and	w1, w11, #0xff
   14af8:      	mov	w8, #0x4                // =4
   14afc:      	cinc	x0, x19, hi
   14b00:      	blr	x8
   14b04:      	ldr	x25, [sp, #0x8]
   14b08:      	cmp	w23, w21
   14b0c:      	str	x19, [sp, #0x60]
   14b10:      	b.ls	0x14b88 <generic_rawtp_path+0xba88>
   14b14:      	ldr	x8, [sp, #0x78]
   14b18:      	str	x8, [sp, #0x48]
   14b1c:      	b	0x14b6c <generic_rawtp_path+0xba6c>
   14b20:      	add	x2, x24, #0x10
   14b24:      	mov	w8, #0x4                // =4
   14b28:      	add	x9, sp, #0x98
   14b2c:      	add	x0, sp, #0x98
   14b30:      	mov	w1, #0x8                // =8
   14b34:      	blr	x8
   14b38:      	ldr	x8, [sp, #0x58]
   14b3c:      	ldr	x9, [sp, #0x98]
   14b40:      	cmp	x8, x9
   14b44:      	ldr	x25, [sp, #0x8]
   14b48:      	b.eq	0x14b80 <generic_rawtp_path+0xba80>
   14b4c:      	add	x2, x24, #0x18
   14b50:      	mov	w8, #0x4                // =4
   14b54:      	mov	x0, x22
   14b58:      	mov	w1, #0x8                // =8
   14b5c:      	blr	x8
   14b60:      	ldr	x8, [sp, #0x98]
   14b64:      	add	x9, x8, #0x20
   14b68:      	stp	x9, x8, [sp, #0x50]
   14b6c:      	ldr	x25, [sp, #0x8]
   14b70:      	subs	w20, w20, #0x80
   14b74:      	add	x19, sp, #0x70
   14b78:      	b.ne	0x927c <generic_rawtp_path+0x17c>
   14b7c:      	b	0x14b88 <generic_rawtp_path+0xba88>
   14b80:      	mov	w8, #0x1                // =1
   14b84:      	strb	w8, [sp, #0x6c]
   14b88:      	ldr	w8, [x25, #0x8]
   14b8c:      	ldp	x10, x20, [sp, #0x10]
   14b90:      	add	w8, w8, #0x1
   14b94:      	str	w8, [x25, #0x8]
   14b98:      	ldr	w9, [sp, #0x60]
   14b9c:      	sub	w9, w9, w10
   14ba0:      	str	w9, [x25, #0x4]
   14ba4:      	ldrb	w9, [sp, #0x6c]
   14ba8:      	cbnz	w9, 0x14be0 <generic_rawtp_path+0xbae0>
   14bac:      	cmp	w8, #0x8
   14bb0:      	b.eq	0x14be0 <generic_rawtp_path+0xbae0>
   14bb4:      	ldp	x8, x9, [sp, #0x48]
   14bb8:      	mov	w2, #0x6                // =6
   14bbc:      	str	x8, [x20, #0x6458]
   14bc0:      	ldr	x8, [sp, #0x58]
   14bc4:      	str	x9, [x20, #0x6460]
   14bc8:      	adrp	x9, 0x14000 <generic_rawtp_path+0xaf00>
   14bcc:      	str	x8, [x20, #0x6468]
   14bd0:      	mov	w8, #0xc                // =12
   14bd4:      	ldr	x9, [x9]
   14bd8:      	ldr	x0, [sp, #0x20]
   14bdc:      	b	0x14bf4 <generic_rawtp_path+0xbaf4>
   14be0:      	adrp	x9, 0x14000 <generic_rawtp_path+0xaf00>
   14be4:      	mov	w2, #0x1                // =1
   14be8:      	mov	w8, #0xc                // =12
   14bec:      	ldr	x9, [x9]
   14bf0:      	ldr	x0, [sp, #0x20]
   14bf4:      	adrp	x1, 0x14000 <generic_rawtp_path+0xaf00>
   14bf8:      	ldr	x1, [x1]
   14bfc:      	blr	x8
   14c00:      	b	0x14f9c <generic_rawtp_path+0xbe9c>
   14c04:      	str	w23, [sp, #0x98]
   14c08:      	mov	x3, xzr
   14c0c:      	mov	w8, #0x2                // =2
   14c10:      	add	x9, sp, #0x30
   14c14:      	add	x10, sp, #0x98
   14c18:      	add	x1, sp, #0x30
   14c1c:      	add	x2, sp, #0x98
   14c20:      	mov	x0, x22
   14c24:      	blr	x8
   14c28:      	ldr	x23, [sp, #0x80]
   14c2c:      	mov	w8, #0x8                // =8
   14c30:      	mov	w9, #0x4                // =4
   14c34:      	add	x10, sp, #0x30
   14c38:      	add	x0, sp, #0x30
   14c3c:      	mov	w1, #0x8                // =8
   14c40:      	add	x2, x23, #0x10
   14c44:      	blr	x9
   14c48:      	ldr	x8, [sp, #0x30]
   14c4c:      	cbnz	x8, 0x14c94 <generic_rawtp_path+0xbb94>
   14c50:      	add	x2, x23, #0x18
   14c54:      	mov	w8, #0x8                // =8
   14c58:      	mov	w9, #0x4                // =4
   14c5c:      	add	x10, sp, #0x30
   14c60:      	add	x0, sp, #0x30
   14c64:      	mov	w1, #0x8                // =8
   14c68:      	blr	x9
   14c6c:      	ldr	x8, [sp, #0x30]
   14c70:      	cmp	x8, x23
   14c74:      	b.eq	0x14c94 <generic_rawtp_path+0xbb94>
   14c78:      	adrp	x8, 0x14000 <generic_rawtp_path+0xaf00>
   14c7c:      	add	x8, x8, #0x0
   14c80:      	add	x29, x21, #0xff5
   14c84:      	ldr	x8, [x8]
   14c88:      	str	x8, [x29]
   14c8c:      	mov	w8, #0x2964             // =10596
   14c90:      	strh	w8, [x29, #0x8]
   14c94:      	mov	w8, #0x23               // =35
   14c98:      	blr	x8
   14c9c:      	add	x2, x0, #0xb30
   14ca0:      	mov	w8, #0x8                // =8
   14ca4:      	mov	w9, #0x4                // =4
   14ca8:      	add	x10, sp, #0x98
   14cac:      	add	x0, sp, #0x98
   14cb0:      	mov	w1, #0x8                // =8
   14cb4:      	blr	x9
   14cb8:      	cbz	x0, 0x14d28 <generic_rawtp_path+0xbc28>
   14cbc:      	neg	w8, w0
   14cc0:      	mov	w9, #0x1                // =1
   14cc4:      	add	x1, sp, #0x30
   14cc8:      	strh	w8, [sp, #0x30]
   14ccc:      	mov	w8, #0x6                // =6
   14cd0:      	mov	x0, x22
   14cd4:      	mov	w23, #0x1               // =1
   14cd8:      	strh	w8, [sp, #0x32]
   14cdc:      	mov	x8, #0x33               // =51
   14ce0:      	movk	x8, #0x4, lsl #32
   14ce4:      	stur	x8, [sp, #0x34]
   14ce8:      	add	x8, sp, #0x30
   14cec:      	blr	x9
   14cf0:      	cbz	x0, 0x14d04 <generic_rawtp_path+0xbc04>
   14cf4:      	ldr	w8, [x0]
   14cf8:      	add	w8, w8, #0x1
   14cfc:      	str	w8, [x0]
   14d00:      	b	0x14d28 <generic_rawtp_path+0xbc28>
   14d04:      	str	w23, [sp, #0x78]
   14d08:      	mov	x3, xzr
   14d0c:      	mov	w8, #0x2                // =2
   14d10:      	add	x9, sp, #0x30
   14d14:      	add	x10, sp, #0x78
   14d18:      	add	x1, sp, #0x30
   14d1c:      	add	x2, sp, #0x78
   14d20:      	mov	x0, x22
   14d24:      	blr	x8
   14d28:      	ldr	x8, [sp, #0x98]
   14d2c:      	mov	w9, #0x6448             // =25672
   14d30:      	ldr	x23, [x20, #0x6440]
   14d34:      	mov	w1, #0x8                // =8
   14d38:      	add	x0, x20, x9
   14d3c:      	mov	w9, #0x4                // =4
   14d40:      	add	x24, x8, #0x18
   14d44:      	add	x2, x8, #0x20
   14d48:      	mov	w8, #0x8                // =8
   14d4c:      	blr	x9
   14d50:      	cbz	x0, 0x14dc0 <generic_rawtp_path+0xbcc0>
   14d54:      	neg	w8, w0
   14d58:      	mov	w9, #0x1                // =1
   14d5c:      	add	x1, sp, #0x30
   14d60:      	strh	w8, [sp, #0x30]
   14d64:      	mov	w8, #0x6                // =6
   14d68:      	mov	x0, x22
   14d6c:      	mov	w19, #0x1               // =1
   14d70:      	strh	w8, [sp, #0x32]
   14d74:      	mov	x8, #0x38               // =56
   14d78:      	movk	x8, #0x4, lsl #32
   14d7c:      	stur	x8, [sp, #0x34]
   14d80:      	add	x8, sp, #0x30
   14d84:      	blr	x9
   14d88:      	cbz	x0, 0x14d9c <generic_rawtp_path+0xbc9c>
   14d8c:      	ldr	w8, [x0]
   14d90:      	add	w8, w8, #0x1
   14d94:      	str	w8, [x0]
   14d98:      	b	0x14dc0 <generic_rawtp_path+0xbcc0>
   14d9c:      	str	w19, [sp, #0x78]
   14da0:      	mov	x3, xzr
   14da4:      	mov	w8, #0x2                // =2
   14da8:      	add	x9, sp, #0x30
   14dac:      	add	x10, sp, #0x78
   14db0:      	add	x1, sp, #0x30
   14db4:      	add	x2, sp, #0x78
   14db8:      	mov	x0, x22
   14dbc:      	blr	x8
   14dc0:      	mov	w8, #0x6450             // =25680
   14dc4:      	mov	w9, #0x4                // =4
   14dc8:      	mov	w1, #0x8                // =8
   14dcc:      	mov	x2, x24
   14dd0:      	add	x0, x20, x8
   14dd4:      	mov	w8, #0x8                // =8
   14dd8:      	blr	x9
   14ddc:      	cbz	x0, 0x14e4c <generic_rawtp_path+0xbd4c>
   14de0:      	neg	w8, w0
   14de4:      	mov	w9, #0x1                // =1
   14de8:      	add	x1, sp, #0x30
   14dec:      	strh	w8, [sp, #0x30]
   14df0:      	mov	w8, #0x6                // =6
   14df4:      	mov	x0, x22
   14df8:      	mov	w19, #0x1               // =1
   14dfc:      	strh	w8, [sp, #0x32]
   14e00:      	mov	x8, #0x39               // =57
   14e04:      	movk	x8, #0x4, lsl #32
   14e08:      	stur	x8, [sp, #0x34]
   14e0c:      	add	x8, sp, #0x30
   14e10:      	blr	x9
   14e14:      	cbz	x0, 0x14e28 <generic_rawtp_path+0xbd28>
   14e18:      	ldr	w8, [x0]
   14e1c:      	add	w8, w8, #0x1
   14e20:      	str	w8, [x0]
   14e24:      	b	0x14e4c <generic_rawtp_path+0xbd4c>
   14e28:      	str	w19, [sp, #0x78]
   14e2c:      	mov	x3, xzr
   14e30:      	mov	w8, #0x2                // =2
   14e34:      	add	x9, sp, #0x30
   14e38:      	add	x10, sp, #0x78
   14e3c:      	add	x1, sp, #0x30
   14e40:      	add	x2, sp, #0x78
   14e44:      	mov	x0, x22
   14e48:      	blr	x8
   14e4c:      	mov	w8, #0x6458             // =25688
   14e50:      	add	x2, x23, #0x8
   14e54:      	mov	w9, #0x4                // =4
   14e58:      	mov	w1, #0x8                // =8
   14e5c:      	add	x0, x20, x8
   14e60:      	mov	w8, #0x8                // =8
   14e64:      	blr	x9
   14e68:      	cbz	x0, 0x14ed8 <generic_rawtp_path+0xbdd8>
   14e6c:      	neg	w8, w0
   14e70:      	mov	w9, #0x1                // =1
   14e74:      	add	x1, sp, #0x30
   14e78:      	strh	w8, [sp, #0x30]
   14e7c:      	mov	w8, #0x6                // =6
   14e80:      	mov	x0, x22
   14e84:      	mov	w19, #0x1               // =1
   14e88:      	strh	w8, [sp, #0x32]
   14e8c:      	mov	x8, #0x3a               // =58
   14e90:      	movk	x8, #0x4, lsl #32
   14e94:      	stur	x8, [sp, #0x34]
   14e98:      	add	x8, sp, #0x30
   14e9c:      	blr	x9
   14ea0:      	cbz	x0, 0x14eb4 <generic_rawtp_path+0xbdb4>
   14ea4:      	ldr	w8, [x0]
   14ea8:      	add	w8, w8, #0x1
   14eac:      	str	w8, [x0]
   14eb0:      	b	0x14ed8 <generic_rawtp_path+0xbdd8>
   14eb4:      	str	w19, [sp, #0x78]
   14eb8:      	mov	x3, xzr
   14ebc:      	mov	w8, #0x2                // =2
   14ec0:      	add	x9, sp, #0x30
   14ec4:      	add	x10, sp, #0x78
   14ec8:      	add	x1, sp, #0x30
   14ecc:      	add	x2, sp, #0x78
   14ed0:      	mov	x0, x22
   14ed4:      	blr	x8
   14ed8:      	mov	w8, #0x6460             // =25696
   14edc:      	mov	w9, #0x4                // =4
   14ee0:      	mov	w1, #0x8                // =8
   14ee4:      	mov	x2, x23
   14ee8:      	add	x0, x20, x8
   14eec:      	mov	w8, #0x8                // =8
   14ef0:      	blr	x9
   14ef4:      	cbz	x0, 0x14f64 <generic_rawtp_path+0xbe64>
   14ef8:      	neg	w8, w0
   14efc:      	mov	w9, #0x1                // =1
   14f00:      	add	x1, sp, #0x30
   14f04:      	strh	w8, [sp, #0x30]
   14f08:      	mov	w8, #0x6                // =6
   14f0c:      	mov	x0, x22
   14f10:      	mov	w19, #0x1               // =1
   14f14:      	strh	w8, [sp, #0x32]
   14f18:      	mov	x8, #0x3b               // =59
   14f1c:      	movk	x8, #0x4, lsl #32
   14f20:      	stur	x8, [sp, #0x34]
   14f24:      	add	x8, sp, #0x30
   14f28:      	blr	x9
   14f2c:      	cbz	x0, 0x14f40 <generic_rawtp_path+0xbe40>
   14f30:      	ldr	w8, [x0]
   14f34:      	add	w8, w8, #0x1
   14f38:      	str	w8, [x0]
   14f3c:      	b	0x14f64 <generic_rawtp_path+0xbe64>
   14f40:      	str	w19, [sp, #0x78]
   14f44:      	mov	x3, xzr
   14f48:      	mov	w8, #0x2                // =2
   14f4c:      	add	x9, sp, #0x30
   14f50:      	add	x10, sp, #0x78
   14f54:      	add	x1, sp, #0x30
   14f58:      	add	x2, sp, #0x78
   14f5c:      	mov	x0, x22
   14f60:      	blr	x8
   14f64:      	ldr	x8, [x20, #0x6460]
   14f68:      	mov	w9, #0x1                // =1
   14f6c:      	adrp	x1, 0x14000 <generic_rawtp_path+0xaf00>
   14f70:      	mov	w2, #0x6                // =6
   14f74:      	str	w9, [x25]
   14f78:      	mov	w9, #0xc                // =12
   14f7c:      	sub	x8, x8, #0x20
   14f80:      	str	x8, [x20, #0x6468]
   14f84:      	sub	w8, w29, w21
   14f88:      	stp	w8, wzr, [x25, #0x4]
   14f8c:      	mov	w8, #0x6                // =6
   14f90:      	ldr	x1, [x1]
   14f94:      	ldr	x0, [sp, #0x20]
   14f98:      	blr	x9
   14f9c:      	ldp	x20, x19, [sp, #0xd0]
   14fa0:      	mov	w0, wzr
   14fa4:      	ldr	x29, [sp, #0x90]
   14fa8:      	ldp	x22, x21, [sp, #0xc0]
   14fac:      	ldp	x24, x23, [sp, #0xb0]
   14fb0:      	ldp	x30, x25, [sp, #0xa0]
   14fb4:      	add	sp, sp, #0xe0
   14fb8:      	ret

Disassembly of section raw_tp/generic_tracepoint:

0000000000000000 <generic_rawtp_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_rawtp_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	adrp	x0, 0x0 <generic_rawtp_event>
      48:      	mov	w8, #0x1                // =1
      4c:      	str	wzr, [x21]
      50:      	mov	x1, x21
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
      60:      	ldr	w8, [x0, #0x64]
      64:      	str	w8, [sp, #0x1c]
      68:      	cbz	w8, 0x224 <generic_rawtp_event+0x224>
      6c:      	adrp	x22, 0x0 <generic_rawtp_event>
      70:      	mov	w8, #0x1                // =1
      74:      	add	x9, sp, #0x1c
      78:      	ldr	x22, [x22]
      7c:      	mov	x24, x0
      80:      	add	x1, sp, #0x1c
      84:      	mov	x0, x22
      88:      	blr	x8
      8c:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
      90:      	mov	x23, x0
      94:      	str	wzr, [sp, #0x84]
      98:      	adrp	x0, 0x0 <generic_rawtp_event>
      9c:      	mov	w8, #0x1                // =1
      a0:      	ldr	x0, [x0]
      a4:      	add	x9, sp, #0x84
      a8:      	add	x1, sp, #0x84
      ac:      	blr	x8
      b0:      	cbz	x0, 0xdc <generic_rawtp_event+0xdc>
      b4:      	ldr	x8, [x0, #0x20]
      b8:      	mov	w9, #0x7270             // =29296
      bc:      	movk	w9, #0x6367, lsl #16
      c0:      	cmp	x8, x9
      c4:      	b.ne	0xe4 <generic_rawtp_event+0xe4>
      c8:      	mov	w8, #0x50               // =80
      cc:      	blr	x8
      d0:      	str	x0, [sp, #0x30]
      d4:      	cbnz	x0, 0x1d8 <generic_rawtp_event+0x1d8>
      d8:      	b	0x540 <generic_rawtp_event+0x540>
      dc:      	mov	w25, wzr
      e0:      	b	0xe8 <generic_rawtp_event+0xe8>
      e4:      	ldr	w25, [x0, #0x10]
      e8:      	mov	w8, #0x23               // =35
      ec:      	blr	x8
      f0:      	str	xzr, [sp, #0x88]
      f4:      	add	x2, x0, #0xcd0
      f8:      	mov	w8, #0x8                // =8
      fc:      	mov	w9, #0x71               // =113
     100:      	add	x10, sp, #0x20
     104:      	add	x0, sp, #0x20
     108:      	mov	w1, #0x8                // =8
     10c:      	blr	x9
     110:      	ldr	x8, [sp, #0x20]
     114:      	cbz	x8, 0x540 <generic_rawtp_event+0x540>
     118:      	cmp	w25, #0xb
     11c:      	b.hi	0x540 <generic_rawtp_event+0x540>
     120:      	ubfiz	x9, x25, #3, #32
     124:      	mov	w10, #0x8               // =8
     128:      	mov	w11, #0x71              // =113
     12c:      	add	x12, sp, #0x38
     130:      	add	x0, sp, #0x38
     134:      	mov	w1, #0x8                // =8
     138:      	add	x8, x8, x9
     13c:      	ldr	x8, [sp, #0x20]
     140:      	add	x2, x8, x9
     144:      	blr	x11
     148:      	ldr	x8, [sp, #0x38]
     14c:      	cbz	x8, 0x540 <generic_rawtp_event+0x540>
     150:      	mov	w9, #0x8                // =8
     154:      	mov	w10, #0x71              // =113
     158:      	add	x11, sp, #0x88
     15c:      	ldr	x2, [sp, #0x38]
     160:      	add	x0, sp, #0x88
     164:      	mov	w1, #0x8                // =8
     168:      	blr	x10
     16c:      	ldr	x8, [sp, #0x88]
     170:      	cbz	x8, 0x540 <generic_rawtp_event+0x540>
     174:      	str	xzr, [sp, #0x38]
     178:      	add	x2, x8, #0x100
     17c:      	mov	w8, #0x8                // =8
     180:      	mov	w9, #0x71               // =113
     184:      	add	x10, sp, #0x38
     188:      	add	x0, sp, #0x38
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x9
     194:      	ldr	x8, [sp, #0x38]
     198:      	str	xzr, [sp, #0x38]
     19c:      	cbz	x8, 0x1cc <generic_rawtp_event+0x1cc>
     1a0:      	add	x2, x8, #0x60
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	w9, #0x71               // =113
     1ac:      	add	x10, sp, #0x38
     1b0:      	add	x0, sp, #0x38
     1b4:      	mov	w1, #0x8                // =8
     1b8:      	blr	x9
     1bc:      	ldr	x0, [sp, #0x38]
     1c0:      	str	x0, [sp, #0x30]
     1c4:      	cbnz	x0, 0x1d8 <generic_rawtp_event+0x1d8>
     1c8:      	b	0x540 <generic_rawtp_event+0x540>
     1cc:      	mov	x0, xzr
     1d0:      	str	xzr, [sp, #0x30]
     1d4:      	cbz	xzr, 0x540 <generic_rawtp_event+0x540>
     1d8:      	str	x0, [sp, #0x38]
     1dc:      	adrp	x0, 0x0 <generic_rawtp_event>
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x9, sp, #0x38
     1e8:      	ldr	x0, [x0]
     1ec:      	add	x1, sp, #0x38
     1f0:      	blr	x8
     1f4:      	cbz	x0, 0x204 <generic_rawtp_event+0x204>
     1f8:      	ldr	x8, [x0]
     1fc:      	cbz	x8, 0x204 <generic_rawtp_event+0x204>
     200:      	str	x8, [sp, #0x30]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x9, sp, #0x30
     20c:      	add	x1, sp, #0x30
     210:      	mov	x0, x23
     214:      	blr	x8
     218:      	mov	x8, x0
     21c:      	mov	x0, x24
     220:      	cbz	x8, 0x55c <generic_rawtp_event+0x55c>
     224:      	ldr	w9, [x0]
     228:      	mov	w8, #0x6420             // =25632
     22c:      	stur	xzr, [x21, #0x4]
     230:      	str	xzr, [x20, #0x5eb8]
     234:      	str	xzr, [x20, #0x5ec0]
     238:      	str	wzr, [x20, x8]
     23c:      	mov	w8, #0x23               // =35
     240:      	str	xzr, [x20, #0x5ec8]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x9, xzr, [x20, #0x60]
     250:      	mov	w9, #0x5eb8             // =24248
     254:      	add	x9, x20, x9
     258:      	strb	wzr, [x9, #0x28]
     25c:      	blr	x8
     260:      	add	x2, x0, #0xb50
     264:      	mov	w25, #0x8               // =8
     268:      	add	x8, sp, #0x88
     26c:      	mov	w9, #0x4                // =4
     270:      	mov	x22, x0
     274:      	add	x0, sp, #0x88
     278:      	mov	w1, #0x8                // =8
     27c:      	add	x23, x20, #0x20
     280:      	mov	w24, #0x4               // =4
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x88]
     28c:      	mov	w9, #0x48               // =72
     290:      	add	x10, sp, #0x38
     294:      	mov	w11, #0x4               // =4
     298:      	ldr	x2, [sp, #0x88]
     29c:      	add	x0, sp, #0x38
     2a0:      	mov	w1, #0x48               // =72
     2a4:      	blr	x11
     2a8:      	ldr	x8, [sp, #0x40]
     2ac:      	mov	w9, #0x4                // =4
     2b0:      	mov	x0, x23
     2b4:      	mov	w1, #0x4                // =4
     2b8:      	add	x8, x8, #0x218
     2bc:      	ldr	x8, [sp, #0x40]
     2c0:      	add	x2, x8, #0x218
     2c4:      	blr	x9
     2c8:      	ldr	x8, [sp, #0x48]
     2cc:      	add	x0, x20, #0x24
     2d0:      	mov	w9, #0x4                // =4
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	add	x8, x8, #0x4d8
     2dc:      	ldr	x8, [sp, #0x48]
     2e0:      	add	x2, x8, #0x4d8
     2e4:      	blr	x9
     2e8:      	ldr	x8, [sp, #0x50]
     2ec:      	add	x0, x20, #0x28
     2f0:      	mov	w9, #0x4                // =4
     2f4:      	mov	w1, #0x4                // =4
     2f8:      	add	x8, x8, #0x58
     2fc:      	ldr	x8, [sp, #0x50]
     300:      	add	x2, x8, #0x58
     304:      	blr	x9
     308:      	str	xzr, [sp, #0x30]
     30c:      	add	x2, x22, #0x938
     310:      	add	x8, sp, #0x30
     314:      	add	x0, sp, #0x30
     318:      	mov	w1, #0x8                // =8
     31c:      	blr	x24
     320:      	ldr	x8, [sp, #0x30]
     324:      	cbz	x8, 0x3a8 <generic_rawtp_event+0x3a8>
     328:      	str	wzr, [sp, #0x10]
     32c:      	add	x8, x8, #0x4
     330:      	add	x9, sp, #0x10
     334:      	mov	w10, #0x4               // =4
     338:      	add	x0, sp, #0x10
     33c:      	mov	w1, #0x4                // =4
     340:      	mov	w23, #0x4               // =4
     344:      	ldr	x8, [sp, #0x30]
     348:      	add	x2, x8, #0x4
     34c:      	blr	x10
     350:      	ldr	x8, [sp, #0x30]
     354:      	ldrsw	x9, [sp, #0x10]
     358:      	add	x10, sp, #0x20
     35c:      	mov	w11, #0x4               // =4
     360:      	add	x0, sp, #0x20
     364:      	mov	w1, #0x10               // =16
     368:      	add	x8, x8, x9, lsl #4
     36c:      	mov	w9, #0x10               // =16
     370:      	add	x8, x8, #0x80
     374:      	ldr	x8, [sp, #0x30]
     378:      	ldrsw	x9, [sp, #0x10]
     37c:      	add	x8, x8, x9, lsl #4
     380:      	add	x2, x8, #0x80
     384:      	blr	x11
     388:      	ldr	x8, [sp, #0x28]
     38c:      	add	x0, x20, #0x2c
     390:      	mov	w1, #0x4                // =4
     394:      	add	x8, x8, #0x158
     398:      	ldr	x8, [sp, #0x28]
     39c:      	add	x2, x8, #0x158
     3a0:      	blr	x23
     3a4:      	b	0x3ac <generic_rawtp_event+0x3ac>
     3a8:      	str	wzr, [x20, #0x2c]
     3ac:      	ldr	x8, [sp, #0x58]
     3b0:      	add	x0, x20, #0x30
     3b4:      	mov	w9, #0x4                // =4
     3b8:      	mov	w1, #0x4                // =4
     3bc:      	mov	w24, #0x4               // =4
     3c0:      	add	x8, x8, #0x158
     3c4:      	ldr	x8, [sp, #0x58]
     3c8:      	add	x2, x8, #0x158
     3cc:      	blr	x9
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	add	x0, x20, #0x34
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w1, #0x4                // =4
     3e0:      	add	x8, x8, #0x118
     3e4:      	ldr	x8, [sp, #0x60]
     3e8:      	add	x2, x8, #0x118
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x68]
     3f4:      	add	x0, x20, #0x38
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x8, x8, #0x98
     404:      	ldr	x8, [sp, #0x68]
     408:      	add	x2, x8, #0x98
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x70]
     414:      	add	x0, x20, #0x3c
     418:      	mov	w9, #0x4                // =4
     41c:      	mov	w1, #0x4                // =4
     420:      	add	x8, x8, #0x98
     424:      	ldr	x8, [sp, #0x70]
     428:      	add	x2, x8, #0x98
     42c:      	blr	x9
     430:      	ldr	x8, [sp, #0x78]
     434:      	add	x0, x20, #0x40
     438:      	mov	w9, #0x4                // =4
     43c:      	mov	w1, #0x4                // =4
     440:      	add	x8, x8, #0x58
     444:      	ldr	x8, [sp, #0x78]
     448:      	add	x2, x8, #0x58
     44c:      	blr	x9
     450:      	str	xzr, [sp, #0x20]
     454:      	str	xzr, [sp, #0x30]
     458:      	add	x22, x22, #0xae0
     45c:      	mov	w25, #0x8               // =8
     460:      	add	x8, sp, #0x20
     464:      	mov	w9, #0x4                // =4
     468:      	add	x0, sp, #0x20
     46c:      	mov	w1, #0x8                // =8
     470:      	mov	x2, x22
     474:      	blr	x9
     478:      	ldr	x8, [sp, #0x20]
     47c:      	add	x9, sp, #0x30
     480:      	mov	w10, #0x4               // =4
     484:      	add	x0, sp, #0x30
     488:      	mov	w1, #0x8                // =8
     48c:      	add	x8, x8, #0x90
     490:      	ldr	x8, [sp, #0x20]
     494:      	add	x2, x8, #0x90
     498:      	blr	x10
     49c:      	ldr	x8, [sp, #0x30]
     4a0:      	add	x0, x20, #0x44
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	mov	w1, #0x4                // =4
     4ac:      	add	x8, x8, #0x158
     4b0:      	ldr	x8, [sp, #0x30]
     4b4:      	add	x2, x8, #0x158
     4b8:      	blr	x9
     4bc:      	add	x8, sp, #0x38
     4c0:      	mov	w9, #0x4                // =4
     4c4:      	add	x0, sp, #0x38
     4c8:      	mov	w1, #0x8                // =8
     4cc:      	mov	x2, x22
     4d0:      	add	x23, x20, #0x48
     4d4:      	blr	x9
     4d8:      	ldr	x22, [sp, #0x38]
     4dc:      	add	x0, x20, #0x50
     4e0:      	mov	w8, #0x4                // =4
     4e4:      	mov	w1, #0x8                // =8
     4e8:      	add	x2, x22, #0x40
     4ec:      	blr	x8
     4f0:      	add	x0, x20, #0x58
     4f4:      	add	x2, x22, #0x30
     4f8:      	mov	w8, #0x4                // =4
     4fc:      	mov	w1, #0x8                // =8
     500:      	blr	x8
     504:      	add	x2, x22, #0x38
     508:      	mov	x0, x23
     50c:      	mov	w1, #0x8                // =8
     510:      	blr	x24
     514:      	strb	wzr, [x21, #0x10]
     518:      	strb	wzr, [x20, #0x1]
     51c:      	adrp	x1, 0x0 <generic_rawtp_event>
     520:      	mov	w8, #0x2                // =2
     524:      	mov	w9, #0xc                // =12
     528:      	mov	x0, x19
     52c:      	str	xzr, [x20, #0x5ee8]
     530:      	str	xzr, [x20, #0x5ef0]
     534:      	ldr	x1, [x1]
     538:      	mov	w2, #0x2                // =2
     53c:      	blr	x9
     540:      	ldp	x20, x19, [sp, #0xc0]
     544:      	mov	w0, wzr
     548:      	ldp	x22, x21, [sp, #0xb0]
     54c:      	ldp	x24, x23, [sp, #0xa0]
     550:      	ldp	x30, x25, [sp, #0x90]
     554:      	add	sp, sp, #0xd0
     558:      	ret
     55c:      	mov	x8, #-0x1               // =-1
     560:      	mov	w9, #0x1                // =1
     564:      	add	x1, sp, #0x10
     568:      	str	x8, [sp, #0x10]
     56c:      	add	x8, sp, #0x10
     570:      	mov	x0, x23
     574:      	mov	w25, #0x1               // =1
     578:      	blr	x9
     57c:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
     580:      	str	w25, [sp, #0x1c]
     584:      	add	x8, sp, #0x1c
     588:      	add	x1, sp, #0x1c
     58c:      	mov	x0, x22
     590:      	blr	x25
     594:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
     598:      	mov	w8, #0x1                // =1
     59c:      	add	x9, sp, #0x30
     5a0:      	add	x1, sp, #0x30
     5a4:      	blr	x8
     5a8:      	mov	x8, x0
     5ac:      	mov	x0, x24
     5b0:      	cbnz	x8, 0x540 <generic_rawtp_event+0x540>
     5b4:      	b	0x224 <generic_rawtp_event+0x224>
