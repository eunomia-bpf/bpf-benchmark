
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_multi_retkprobe_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section kprobe.multi:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	sub	sp, sp, #0xf0
       4:      	str	x29, [sp, #0xa0]
       8:      	stp	x30, x25, [sp, #0xb0]
       c:      	stp	x24, x23, [sp, #0xc0]
      10:      	stp	x22, x21, [sp, #0xd0]
      14:      	stp	x20, x19, [sp, #0xe0]
      18:      	mov	x23, x0
      1c:      	str	wzr, [sp, #0xa8]
      20:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0xa8
      30:      	add	x1, sp, #0xa8
      34:      	blr	x8
      38:      	cbz	x0, 0x337c <generic_retkprobe_filter_arg+0x337c>
      3c:      	mov	w8, #0x5ec1             // =24257
      40:      	mov	x20, x0
      44:      	add	x19, x0, x8
      48:      	mov	w8, #0x5ef8             // =24312
      4c:      	add	x1, x0, x8
      50:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      54:      	ldur	w21, [x19, #0x3f]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x3360 <generic_retkprobe_filter_arg+0x3360>
      68:      	ldrb	w8, [x19, #0x1f]
      6c:      	cbz	w8, 0x3360 <generic_retkprobe_filter_arg+0x3360>
      70:      	and	x8, x21, #0x7
      74:      	mov	w10, #0x5ec1            // =24257
      78:      	str	x21, [sp, #0x58]
      7c:      	add	x9, x20, x8
      80:      	ldrb	w9, [x9, x10]
      84:      	cbz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
      88:      	lsl	w8, w8, #2
      8c:      	add	x8, x8, #0x4
      90:      	ldr	w9, [x8, x0]
      94:      	add	x8, x8, x9
      98:      	add	x12, x8, #0x4
      9c:      	and	x8, x12, #0x3ff
      a0:      	add	x16, x0, x8
      a4:      	str	x8, [sp, #0x40]
      a8:      	ldr	w8, [x16]
      ac:      	cmp	w8, #0x19
      b0:      	b.hs	0x110 <generic_retkprobe_filter_arg+0x110>
      b4:      	ldr	x8, [sp, #0x40]
      b8:      	cmp	w8, #0x1
      bc:      	b.eq	0x3360 <generic_retkprobe_filter_arg+0x3360>
      c0:      	cbnz	w8, 0x333c <generic_retkprobe_filter_arg+0x333c>
      c4:      	ldr	x8, [sp, #0x58]
      c8:      	cmp	w8, #0x1
      cc:      	b.gt	0xe8 <generic_retkprobe_filter_arg+0xe8>
      d0:      	cmn	w8, #0x1
      d4:      	b.eq	0x339c <generic_retkprobe_filter_arg+0x339c>
      d8:      	cbz	w8, 0x33ac <generic_retkprobe_filter_arg+0x33ac>
      dc:      	cmp	w8, #0x1
      e0:      	b.eq	0x33bc <generic_retkprobe_filter_arg+0x33bc>
      e4:      	b	0x100 <generic_retkprobe_filter_arg+0x100>
      e8:      	cmp	w8, #0x2
      ec:      	b.eq	0x33cc <generic_retkprobe_filter_arg+0x33cc>
      f0:      	cmp	w8, #0x3
      f4:      	b.eq	0x33dc <generic_retkprobe_filter_arg+0x33dc>
      f8:      	cmp	w8, #0x4
      fc:      	b.eq	0x33ec <generic_retkprobe_filter_arg+0x33ec>
     100:      	cmp	w8, #0x4
     104:      	b.gt	0x3418 <generic_retkprobe_filter_arg+0x3418>
     108:      	add	w8, w8, #0x1
     10c:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
     110:      	mov	x24, xzr
     114:      	mov	w17, #0x1               // =1
     118:      	stp	x19, x0, [sp, #0x30]
     11c:      	stp	x12, x16, [sp, #0x48]
     120:      	b	0x14c <generic_retkprobe_filter_arg+0x14c>
     124:      	orr	w8, w8, #0x2
     128:      	cmp	w8, #0x6
     12c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
     130:      	nop
     134:      	nop
     138:      	nop
     13c:      	nop
     140:      	add	x24, x24, #0x1
     144:      	cmp	x24, #0x5
     148:      	b.eq	0xb4 <generic_retkprobe_filter_arg+0xb4>
     14c:      	add	x8, x16, x24, lsl #2
     150:      	ldr	w8, [x8, #0x4]
     154:      	tst	w8, #0x3ff
     158:      	b.eq	0xb4 <generic_retkprobe_filter_arg+0xb4>
     15c:      	add	w8, w12, w8
     160:      	and	x8, x8, #0x3ff
     164:      	add	x21, x0, x8
     168:      	ldr	w8, [x21, #0x4]
     16c:      	cmp	w8, #0x23
     170:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     174:      	ldr	w9, [x21]
     178:      	cmp	w9, #0x4
     17c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     180:      	add	x10, x20, x9, lsl #2
     184:      	mov	w11, #0x5ea0            // =24224
     188:      	ldr	w10, [x10, x11]
     18c:      	cbnz	w10, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     190:      	add	x9, x20, x9, lsl #3
     194:      	ldr	x9, [x9, #0x5e78]
     198:      	and	x9, x9, #0x7ff
     19c:      	add	x9, x20, x9
     1a0:      	add	x25, x9, #0x90
     1a4:      	ldr	w9, [x21, #0xc]
     1a8:      	cmp	w9, #0x1b
     1ac:      	b.le	0x1d0 <generic_retkprobe_filter_arg+0x1d0>
     1b0:      	cmp	w9, #0x25
     1b4:      	b.gt	0x200 <generic_retkprobe_filter_arg+0x200>
     1b8:      	sub	w10, w9, #0x1c
     1bc:      	cmp	w10, #0x9
     1c0:      	b.lo	0x244 <generic_retkprobe_filter_arg+0x244>
     1c4:      	cmp	w9, #0x25
     1c8:      	b.eq	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     1cc:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
     1d0:      	cmp	w9, #0x9
     1d4:      	b.le	0x224 <generic_retkprobe_filter_arg+0x224>
     1d8:      	sub	w10, w9, #0xa
     1dc:      	cmp	w10, #0x4
     1e0:      	b.lo	0x244 <generic_retkprobe_filter_arg+0x244>
     1e4:      	sub	w10, w9, #0xf
     1e8:      	cmp	w10, #0x2
     1ec:      	b.lo	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     1f0:      	cmp	w9, #0x11
     1f4:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     1f8:      	add	x25, x25, #0x4
     1fc:      	b	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     200:      	cmp	w9, #0x29
     204:      	b.gt	0x370 <generic_retkprobe_filter_arg+0x370>
     208:      	sub	w10, w9, #0x26
     20c:      	cmp	w10, #0x2
     210:      	b.lo	0x318 <generic_retkprobe_filter_arg+0x318>
     214:      	sub	w10, w9, #0x28
     218:      	cmp	w10, #0x2
     21c:      	b.lo	0x2f0 <generic_retkprobe_filter_arg+0x2f0>
     220:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
     224:      	cmp	w9, #0x4
     228:      	b.gt	0x2d8 <generic_retkprobe_filter_arg+0x2d8>
     22c:      	cmp	w9, #0x1
     230:      	b.eq	0x244 <generic_retkprobe_filter_arg+0x244>
     234:      	cmp	w9, #0x2
     238:      	b.eq	0x824 <generic_retkprobe_filter_arg+0x824>
     23c:      	cmp	w9, #0x4
     240:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     244:      	cmp	w9, #0xb
     248:      	b.le	0x2b8 <generic_retkprobe_filter_arg+0x2b8>
     24c:      	cmp	w9, #0x24
     250:      	b.hi	0x4b0 <generic_retkprobe_filter_arg+0x4b0>
     254:      	lsl	x10, x17, x9
     258:      	tst	x10, #0x1e00000000
     25c:      	b.ne	0x348 <generic_retkprobe_filter_arg+0x348>
     260:      	lsl	x10, x17, x9
     264:      	tst	x10, #0x60000000
     268:      	b.ne	0x66c <generic_retkprobe_filter_arg+0x66c>
     26c:      	lsl	x10, x17, x9
     270:      	tst	x10, #0x180000000
     274:      	b.eq	0x4b0 <generic_retkprobe_filter_arg+0x4b0>
     278:      	cmp	w8, #0x20
     27c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     280:      	lsl	x9, x17, x8
     284:      	mov	w10, #0x101e            // =4126
     288:      	tst	x9, x10
     28c:      	b.eq	0xcb8 <generic_retkprobe_filter_arg+0xcb8>
     290:      	ldr	w9, [x21, #0x10]
     294:      	cmp	w8, #0x2
     298:      	b.le	0x1230 <generic_retkprobe_filter_arg+0x1230>
     29c:      	sub	w10, w8, #0x3
     2a0:      	cmp	w10, #0x2
     2a4:      	b.hs	0x1844 <generic_retkprobe_filter_arg+0x1844>
     2a8:      	ldrb	w10, [x25]
     2ac:      	cmp	w9, w10
     2b0:      	b.ne	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
     2b4:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     2b8:      	sub	w10, w9, #0xa
     2bc:      	cmp	w10, #0x2
     2c0:      	b.lo	0x898 <generic_retkprobe_filter_arg+0x898>
     2c4:      	cmp	w9, #0x1
     2c8:      	b.eq	0x4bc <generic_retkprobe_filter_arg+0x4bc>
     2cc:      	cmp	w9, #0x4
     2d0:      	b.eq	0x4bc <generic_retkprobe_filter_arg+0x4bc>
     2d4:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
     2d8:      	cmp	w9, #0x5
     2dc:      	b.eq	0x2f0 <generic_retkprobe_filter_arg+0x2f0>
     2e0:      	cmp	w9, #0x6
     2e4:      	b.eq	0x318 <generic_retkprobe_filter_arg+0x318>
     2e8:      	cmp	w9, #0x7
     2ec:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     2f0:      	mov	x22, xzr
     2f4:      	cmp	w9, #0x27
     2f8:      	stp	xzr, xzr, [sp, #0x78]
     2fc:      	str	xzr, [sp, #0x60]
     300:      	stp	xzr, xzr, [sp, #0x68]
     304:      	b.gt	0x4fc <generic_retkprobe_filter_arg+0x4fc>
     308:      	cmp	w9, #0x5
     30c:      	b.eq	0x9c8 <generic_retkprobe_filter_arg+0x9c8>
     310:      	cmp	w9, #0x7
     314:      	b	0x508 <generic_retkprobe_filter_arg+0x508>
     318:      	ldr	w29, [x25], #0x4
     31c:      	mov	x22, xzr
     320:      	cmp	w8, #0x19
     324:      	b.gt	0x568 <generic_retkprobe_filter_arg+0x568>
     328:      	sub	w9, w8, #0x3
     32c:      	cmp	w9, #0x2
     330:      	b.lo	0xc48 <generic_retkprobe_filter_arg+0xc48>
     334:      	cmp	w8, #0x8
     338:      	b.eq	0xbb0 <generic_retkprobe_filter_arg+0xbb0>
     33c:      	cmp	w8, #0x9
     340:      	b.eq	0x580 <generic_retkprobe_filter_arg+0x580>
     344:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     348:      	cmp	w8, #0x9
     34c:      	b.le	0x814 <generic_retkprobe_filter_arg+0x814>
     350:      	cmp	w8, #0x1d
     354:      	b.gt	0xb70 <generic_retkprobe_filter_arg+0xb70>
     358:      	sub	w10, w8, #0xa
     35c:      	cmp	w10, #0x2
     360:      	b.lo	0x924 <generic_retkprobe_filter_arg+0x924>
     364:      	cmp	w8, #0xc
     368:      	b.eq	0x8b0 <generic_retkprobe_filter_arg+0x8b0>
     36c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     370:      	cmp	w9, #0x2a
     374:      	b.eq	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     378:      	cmp	w9, #0x2c
     37c:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     380:      	ldrb	w29, [x25, #0x3]
     384:      	add	x10, x25, #0x4
     388:      	cmp	w8, #0x19
     38c:      	b.gt	0xf44 <generic_retkprobe_filter_arg+0xf44>
     390:      	sub	w9, w8, #0x3
     394:      	cmp	w9, #0x2
     398:      	b.hs	0x14b4 <generic_retkprobe_filter_arg+0x14b4>
     39c:      	cmp	w29, #0x90
     3a0:      	str	wzr, [sp, #0x88]
     3a4:      	b.hi	0x1550 <generic_retkprobe_filter_arg+0x1550>
     3a8:      	mov	w8, #0xaaab             // =43691
     3ac:      	mov	w9, #0x18               // =24
     3b0:      	movk	w8, #0xaaa, lsl #16
     3b4:      	umull	x8, w29, w8
     3b8:      	lsr	x8, x8, #32
     3bc:      	msub	w8, w8, w9, w29
     3c0:      	cbz	w29, 0x3cc <generic_retkprobe_filter_arg+0x3cc>
     3c4:      	mov	w13, w29
     3c8:      	cbz	w8, 0x3e0 <generic_retkprobe_filter_arg+0x3e0>
     3cc:      	sub	w8, w29, w8, uxtb
     3d0:      	add	w9, w8, #0x18
     3d4:      	cmp	w8, #0x78
     3d8:      	and	w13, w9, #0xffff
     3dc:      	b.hi	0x1554 <generic_retkprobe_filter_arg+0x1554>
     3e0:      	and	w8, w13, #0xff
     3e4:      	mov	w9, #0xab               // =171
     3e8:      	mul	w8, w8, w9
     3ec:      	lsr	w8, w8, #12
     3f0:      	sub	w11, w8, #0x1
     3f4:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
     3f8:      	ldr	w29, [x25]
     3fc:      	and	w9, w8, #0xfffffffe
     400:      	cmp	w9, #0x24
     404:      	b.eq	0x40c <generic_retkprobe_filter_arg+0x40c>
     408:      	cbz	w29, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     40c:      	cmp	w8, #0x25
     410:      	b.hi	0x64c <generic_retkprobe_filter_arg+0x64c>
     414:      	mov	w10, #0x100             // =256
     418:      	lsl	x9, x17, x8
     41c:      	movk	w10, #0x400, lsl #16
     420:      	tst	x9, x10
     424:      	b.ne	0x77c <generic_retkprobe_filter_arg+0x77c>
     428:      	mov	w10, #0x200             // =512
     42c:      	lsl	x9, x17, x8
     430:      	movk	w10, #0x800, lsl #16
     434:      	tst	x9, x10
     438:      	b.ne	0x6ac <generic_retkprobe_filter_arg+0x6ac>
     43c:      	lsl	x9, x17, x8
     440:      	tst	x9, #0x3000000000
     444:      	b.eq	0x64c <generic_retkprobe_filter_arg+0x64c>
     448:      	cmp	w29, #0x1, lsl #12      // =0x1000
     44c:      	strh	wzr, [sp, #0x60]
     450:      	b.hi	0x664 <generic_retkprobe_filter_arg+0x664>
     454:      	add	x8, x25, #0x4
     458:      	mov	w10, #0x4               // =4
     45c:      	add	x11, sp, #0x60
     460:      	mov	w12, #0x2               // =2
     464:      	add	x0, sp, #0x60
     468:      	mov	w1, #0x2                // =2
     46c:      	add	x9, x8, x29
     470:      	add	x9, x9, #0x4
     474:      	ldr	w9, [x25]
     478:      	add	x8, x8, x9
     47c:      	add	x2, x8, #0x4
     480:      	blr	x10
     484:      	ldr	w9, [x21, #0x10]
     488:      	cbz	w9, 0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
     48c:      	ldrh	w8, [sp, #0x60]
     490:      	ldr	x0, [sp, #0x38]
     494:      	mov	w17, #0x1               // =1
     498:      	and	w8, w8, #0xf000
     49c:      	ldp	x12, x16, [sp, #0x48]
     4a0:      	cmp	w9, w8
     4a4:      	b.ne	0x1874 <generic_retkprobe_filter_arg+0x1874>
     4a8:      	mov	w22, #0x1               // =1
     4ac:      	b	0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
     4b0:      	sub	w10, w9, #0xc
     4b4:      	cmp	w10, #0x2
     4b8:      	b.hs	0x890 <generic_retkprobe_filter_arg+0x890>
     4bc:      	cmp	w8, #0x20
     4c0:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     4c4:      	lsl	x10, x17, x8
     4c8:      	mov	w11, #0x101e            // =4126
     4cc:      	tst	x10, x11
     4d0:      	b.eq	0x514 <generic_retkprobe_filter_arg+0x514>
     4d4:      	ldr	w10, [x21, #0x10]
     4d8:      	cmp	w8, #0x2
     4dc:      	b.le	0x858 <generic_retkprobe_filter_arg+0x858>
     4e0:      	sub	w11, w8, #0x3
     4e4:      	cmp	w11, #0x2
     4e8:      	b.hs	0xca0 <generic_retkprobe_filter_arg+0xca0>
     4ec:      	ldr	w11, [x25]
     4f0:      	cmp	w11, w10
     4f4:      	b.ne	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     4f8:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     4fc:      	cmp	w9, #0x28
     500:      	b.eq	0x9d0 <generic_retkprobe_filter_arg+0x9d0>
     504:      	cmp	w9, #0x29
     508:      	mov	x10, x25
     50c:      	b.eq	0x9f8 <generic_retkprobe_filter_arg+0x9f8>
     510:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     514:      	lsl	x10, x17, x8
     518:      	tst	x10, #0xc00
     51c:      	b.ne	0x990 <generic_retkprobe_filter_arg+0x990>
     520:      	lsl	x10, x17, x8
     524:      	tst	x10, #0x180000000
     528:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     52c:      	cmp	w8, #0x1f
     530:      	b.ne	0xf14 <generic_retkprobe_filter_arg+0xf14>
     534:      	ldp	w11, w10, [x21, #0x10]
     538:      	cmp	w9, #0xc
     53c:      	b.hi	0x1a44 <generic_retkprobe_filter_arg+0x1a44>
     540:      	lsl	w8, w17, w9
     544:      	mov	w13, #0x1402            // =5122
     548:      	tst	w8, w13
     54c:      	b.eq	0x1a44 <generic_retkprobe_filter_arg+0x1a44>
     550:      	ldr	w8, [x25]
     554:      	cmp	w11, w8
     558:      	b.gt	0x1a58 <generic_retkprobe_filter_arg+0x1a58>
     55c:      	cmp	w8, w10
     560:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
     564:      	b	0x1a58 <generic_retkprobe_filter_arg+0x1a58>
     568:      	cmp	w8, #0x20
     56c:      	b.gt	0xa6c <generic_retkprobe_filter_arg+0xa6c>
     570:      	cmp	w8, #0x1a
     574:      	b.eq	0xbb0 <generic_retkprobe_filter_arg+0xbb0>
     578:      	cmp	w8, #0x1b
     57c:      	b.ne	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     580:      	ldr	w8, [x21, #0x10]
     584:      	str	wzr, [sp, #0x88]
     588:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     58c:      	add	x9, sp, #0x60
     590:      	add	x1, sp, #0x60
     594:      	str	w8, [sp, #0x60]
     598:      	mov	w8, #0x1                // =1
     59c:      	ldr	x0, [x0]
     5a0:      	blr	x8
     5a4:      	mov	x22, xzr
     5a8:      	cbz	w29, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     5ac:      	cbz	x0, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     5b0:      	mov	x19, x0
     5b4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     5b8:      	mov	w8, #0x1                // =1
     5bc:      	ldr	x0, [x0]
     5c0:      	add	x9, sp, #0x88
     5c4:      	add	x1, sp, #0x88
     5c8:      	blr	x8
     5cc:      	cbz	x0, 0x130c <generic_retkprobe_filter_arg+0x130c>
     5d0:      	cmp	w29, #0x7f
     5d4:      	mov	w9, #0x7f               // =127
     5d8:      	mov	w11, #0x1               // =1
     5dc:      	mov	x1, x0
     5e0:      	mov	x8, xzr
     5e4:      	sub	w12, w29, #0x2
     5e8:      	sub	w13, w29, #0x1
     5ec:      	csel	w9, w29, w9, lo
     5f0:      	sub	x11, x11, x29
     5f4:      	lsl	w10, w9, #3
     5f8:      	mov	x9, x0
     5fc:      	str	w10, [x9], #0x5
     600:      	neg	x10, x29
     604:      	add	w14, w13, w8
     608:      	cmp	x11, x8
     60c:      	and	x14, x14, #0xfff
     610:      	ldrb	w14, [x25, x14]
     614:      	sturb	w14, [x9, #-0x1]
     618:      	b.eq	0x640 <generic_retkprobe_filter_arg+0x640>
     61c:      	cmn	x8, #0x7e
     620:      	b.eq	0x640 <generic_retkprobe_filter_arg+0x640>
     624:      	add	w14, w12, w8
     628:      	sub	x8, x8, #0x2
     62c:      	and	x14, x14, #0xfff
     630:      	cmp	x10, x8
     634:      	ldrb	w14, [x25, x14]
     638:      	strb	w14, [x9], #0x2
     63c:      	b.ne	0x604 <generic_retkprobe_filter_arg+0x604>
     640:      	mov	w8, #0x1                // =1
     644:      	mov	x0, x19
     648:      	b	0xc38 <generic_retkprobe_filter_arg+0xc38>
     64c:      	sub	w8, w8, #0x3
     650:      	cmp	w8, #0x2
     654:      	b.hs	0x664 <generic_retkprobe_filter_arg+0x664>
     658:      	cmp	w29, #0x1, lsl #12      // =0x1000
     65c:      	str	wzr, [sp, #0x88]
     660:      	b.ls	0xda8 <generic_retkprobe_filter_arg+0xda8>
     664:      	mov	x22, xzr
     668:      	b	0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
     66c:      	cmp	w8, #0x20
     670:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     674:      	lsl	x9, x17, x8
     678:      	mov	w10, #0x101e            // =4126
     67c:      	tst	x9, x10
     680:      	b.eq	0xce4 <generic_retkprobe_filter_arg+0xce4>
     684:      	ldr	w9, [x21, #0x10]
     688:      	cmp	w8, #0x2
     68c:      	b.le	0x1250 <generic_retkprobe_filter_arg+0x1250>
     690:      	sub	w10, w8, #0x3
     694:      	cmp	w10, #0x2
     698:      	b.hs	0x185c <generic_retkprobe_filter_arg+0x185c>
     69c:      	ldrh	w10, [x25]
     6a0:      	cmp	w9, w10
     6a4:      	b.ne	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
     6a8:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     6ac:      	ldr	w8, [x21, #0x10]
     6b0:      	str	wzr, [sp, #0x88]
     6b4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6b8:      	add	x9, sp, #0x60
     6bc:      	add	x1, sp, #0x60
     6c0:      	str	w8, [sp, #0x60]
     6c4:      	mov	w8, #0x1                // =1
     6c8:      	ldr	x0, [x0]
     6cc:      	blr	x8
     6d0:      	mov	x22, xzr
     6d4:      	cbz	w29, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     6d8:      	cbz	x0, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     6dc:      	mov	x19, x0
     6e0:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6e4:      	mov	w8, #0x1                // =1
     6e8:      	ldr	x0, [x0]
     6ec:      	add	x9, sp, #0x88
     6f0:      	add	x1, sp, #0x88
     6f4:      	blr	x8
     6f8:      	cbz	x0, 0x18c4 <generic_retkprobe_filter_arg+0x18c4>
     6fc:      	cmp	w29, #0x7f
     700:      	mov	w10, #0x7f              // =127
     704:      	mov	w12, #0x1               // =1
     708:      	mov	x1, x0
     70c:      	mov	x8, xzr
     710:      	add	x9, x25, #0x4
     714:      	sub	w13, w29, #0x2
     718:      	sub	w14, w29, #0x1
     71c:      	csel	w10, w29, w10, lo
     720:      	sub	x12, x12, x29
     724:      	lsl	w11, w10, #3
     728:      	mov	x10, x0
     72c:      	str	w11, [x10], #0x5
     730:      	neg	x11, x29
     734:      	add	w15, w14, w8
     738:      	cmp	x12, x8
     73c:      	and	x15, x15, #0xfff
     740:      	ldrb	w15, [x9, x15]
     744:      	sturb	w15, [x10, #-0x1]
     748:      	b.eq	0x770 <generic_retkprobe_filter_arg+0x770>
     74c:      	cmn	x8, #0x7e
     750:      	b.eq	0x770 <generic_retkprobe_filter_arg+0x770>
     754:      	add	w15, w13, w8
     758:      	sub	x8, x8, #0x2
     75c:      	and	x15, x15, #0xfff
     760:      	cmp	x11, x8
     764:      	ldrb	w15, [x9, x15]
     768:      	strb	w15, [x10], #0x2
     76c:      	b.ne	0x734 <generic_retkprobe_filter_arg+0x734>
     770:      	mov	w8, #0x1                // =1
     774:      	mov	x0, x19
     778:      	b	0x804 <generic_retkprobe_filter_arg+0x804>
     77c:      	ldr	w8, [x21, #0x10]
     780:      	str	wzr, [sp, #0x88]
     784:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     788:      	add	x9, sp, #0x60
     78c:      	add	x1, sp, #0x60
     790:      	str	w8, [sp, #0x60]
     794:      	mov	w8, #0x1                // =1
     798:      	ldr	x0, [x0]
     79c:      	blr	x8
     7a0:      	mov	x22, xzr
     7a4:      	cbz	w29, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     7a8:      	cbz	x0, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     7ac:      	mov	x19, x0
     7b0:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     7b4:      	mov	w8, #0x1                // =1
     7b8:      	ldr	x0, [x0]
     7bc:      	add	x9, sp, #0x88
     7c0:      	add	x1, sp, #0x88
     7c4:      	blr	x8
     7c8:      	cbz	x0, 0x18c4 <generic_retkprobe_filter_arg+0x18c4>
     7cc:      	cmp	w29, #0xff
     7d0:      	mov	w8, #0xff               // =255
     7d4:      	add	x2, x25, #0x4
     7d8:      	mov	x22, x0
     7dc:      	csel	w1, w29, w8, lo
     7e0:      	mov	x8, x0
     7e4:      	lsl	w9, w1, #3
     7e8:      	str	w9, [x8], #0x4
     7ec:      	mov	w9, #0x4                // =4
     7f0:      	mov	x0, x8
     7f4:      	blr	x9
     7f8:      	mov	w8, #0x1                // =1
     7fc:      	mov	x0, x19
     800:      	mov	x1, x22
     804:      	blr	x8
     808:      	cmp	x0, #0x0
     80c:      	cset	w22, ne
     810:      	b	0x18c8 <generic_retkprobe_filter_arg+0x18c8>
     814:      	sub	w10, w8, #0x1
     818:      	cmp	w10, #0x4
     81c:      	b.lo	0x8b0 <generic_retkprobe_filter_arg+0x8b0>
     820:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     824:      	add	x29, x25, #0x8
     828:      	ldr	w25, [x25, #0x4]
     82c:      	mov	x22, xzr
     830:      	cmp	w8, #0x19
     834:      	b.gt	0xe18 <generic_retkprobe_filter_arg+0xe18>
     838:      	sub	w9, w8, #0x3
     83c:      	cmp	w9, #0x2
     840:      	b.lo	0x1658 <generic_retkprobe_filter_arg+0x1658>
     844:      	cmp	w8, #0x8
     848:      	b.eq	0x15cc <generic_retkprobe_filter_arg+0x15cc>
     84c:      	cmp	w8, #0x9
     850:      	b.eq	0xe30 <generic_retkprobe_filter_arg+0xe30>
     854:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
     858:      	cmp	w8, #0x1
     85c:      	b.eq	0x1080 <generic_retkprobe_filter_arg+0x1080>
     860:      	cmp	w8, #0x2
     864:      	b.ne	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     868:      	cmp	w9, #0xc
     86c:      	b.hi	0x1de8 <generic_retkprobe_filter_arg+0x1de8>
     870:      	lsl	w11, w17, w9
     874:      	mov	w13, #0x1402            // =5122
     878:      	tst	w11, w13
     87c:      	b.eq	0x1de8 <generic_retkprobe_filter_arg+0x1de8>
     880:      	ldr	w11, [x25]
     884:      	cmp	w11, w10
     888:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
     88c:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     890:      	cmp	w9, #0x1c
     894:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     898:      	cmp	w8, #0x20
     89c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     8a0:      	lsl	x10, x17, x8
     8a4:      	mov	w11, #0x101e            // =4126
     8a8:      	tst	x10, x11
     8ac:      	b.eq	0x8d8 <generic_retkprobe_filter_arg+0x8d8>
     8b0:      	ldr	x10, [x21, #0x10]
     8b4:      	cmp	w8, #0x2
     8b8:      	b.le	0x8f4 <generic_retkprobe_filter_arg+0x8f4>
     8bc:      	sub	w11, w8, #0x3
     8c0:      	cmp	w11, #0x2
     8c4:      	b.hs	0xb58 <generic_retkprobe_filter_arg+0xb58>
     8c8:      	ldr	x11, [x25]
     8cc:      	cmp	x11, x10
     8d0:      	b.ne	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     8d4:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     8d8:      	lsl	x10, x17, x8
     8dc:      	tst	x10, #0xc00
     8e0:      	b.ne	0x924 <generic_retkprobe_filter_arg+0x924>
     8e4:      	lsl	x10, x17, x8
     8e8:      	tst	x10, #0x180000000
     8ec:      	b.ne	0xb7c <generic_retkprobe_filter_arg+0xb7c>
     8f0:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     8f4:      	cmp	w8, #0x1
     8f8:      	b.eq	0xd88 <generic_retkprobe_filter_arg+0xd88>
     8fc:      	cmp	w8, #0x2
     900:      	b.ne	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     904:      	cmp	w9, #0xc
     908:      	b.eq	0x914 <generic_retkprobe_filter_arg+0x914>
     90c:      	cmp	w9, #0xa
     910:      	b.ne	0x17ac <generic_retkprobe_filter_arg+0x17ac>
     914:      	ldr	x11, [x25]
     918:      	cmp	x11, x10
     91c:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
     920:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     924:      	ldrb	w8, [x21, #0x10]
     928:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     92c:      	add	x9, sp, #0x88
     930:      	add	x1, sp, #0x88
     934:      	str	w8, [sp, #0x88]
     938:      	mov	w8, #0x1                // =1
     93c:      	ldr	x0, [x0]
     940:      	blr	x8
     944:      	cbz	x0, 0xefc <generic_retkprobe_filter_arg+0xefc>
     948:      	ldr	x8, [x25]
     94c:      	add	x9, sp, #0x60
     950:      	add	x1, sp, #0x60
     954:      	str	x8, [sp, #0x60]
     958:      	mov	w8, #0x1                // =1
     95c:      	blr	x8
     960:      	ldr	w8, [x21, #0x4]
     964:      	cmp	w8, #0xb
     968:      	b.eq	0x1324 <generic_retkprobe_filter_arg+0x1324>
     96c:      	ldp	x12, x16, [sp, #0x48]
     970:      	cmp	w8, #0xa
     974:      	mov	w17, #0x1               // =1
     978:      	b.eq	0x13c8 <generic_retkprobe_filter_arg+0x13c8>
     97c:      	ldr	x0, [sp, #0x38]
     980:      	mov	w22, wzr
     984:      	mov	w8, wzr
     988:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
     98c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     990:      	ldrb	w8, [x21, #0x10]
     994:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     998:      	add	x9, sp, #0x88
     99c:      	add	x1, sp, #0x88
     9a0:      	str	w8, [sp, #0x88]
     9a4:      	mov	w8, #0x1                // =1
     9a8:      	ldr	x0, [x0]
     9ac:      	blr	x8
     9b0:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
     9b4:      	ldr	w8, [x25]
     9b8:      	add	x9, sp, #0x60
     9bc:      	str	x8, [sp, #0x60]
     9c0:      	mov	w8, #0x1                // =1
     9c4:      	b	0x12dc <generic_retkprobe_filter_arg+0x12dc>
     9c8:      	mov	x10, xzr
     9cc:      	b	0x9f8 <generic_retkprobe_filter_arg+0x9f8>
     9d0:      	ldrh	w11, [x25]
     9d4:      	mov	x10, xzr
     9d8:      	strh	w11, [sp, #0x86]
     9dc:      	ldrh	w11, [x25, #0x2]
     9e0:      	strh	w11, [sp, #0x80]
     9e4:      	ldr	x11, [x25, #0x8]
     9e8:      	str	x11, [sp, #0x60]
     9ec:      	ldr	x11, [x25, #0x10]
     9f0:      	add	x25, sp, #0x60
     9f4:      	str	x11, [sp, #0x68]
     9f8:      	mov	x22, xzr
     9fc:      	cmp	w8, #0x13
     a00:      	b.le	0xa28 <generic_retkprobe_filter_arg+0xa28>
     a04:      	cmp	w8, #0x17
     a08:      	b.gt	0xa50 <generic_retkprobe_filter_arg+0xa50>
     a0c:      	sub	w9, w8, #0x14
     a10:      	cmp	w9, #0x2
     a14:      	b.lo	0xf80 <generic_retkprobe_filter_arg+0xf80>
     a18:      	sub	w9, w8, #0x16
     a1c:      	cmp	w9, #0x2
     a20:      	b.lo	0xf6c <generic_retkprobe_filter_arg+0xf6c>
     a24:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     a28:      	cmp	w8, #0xf
     a2c:      	b.le	0xc5c <generic_retkprobe_filter_arg+0xc5c>
     a30:      	cmp	w8, #0x11
     a34:      	b.gt	0xf5c <generic_retkprobe_filter_arg+0xf5c>
     a38:      	cmp	w8, #0x10
     a3c:      	b.eq	0xf6c <generic_retkprobe_filter_arg+0xf6c>
     a40:      	cmp	w8, #0x11
     a44:      	b.ne	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     a48:      	ldrh	w22, [x25, #0x24]
     a4c:      	b	0x16fc <generic_retkprobe_filter_arg+0x16fc>
     a50:      	cmp	w8, #0x1b
     a54:      	b.gt	0xf94 <generic_retkprobe_filter_arg+0xf94>
     a58:      	cmp	w8, #0x18
     a5c:      	b.eq	0xfc4 <generic_retkprobe_filter_arg+0xfc4>
     a60:      	cmp	w8, #0x19
     a64:      	b.eq	0xfb8 <generic_retkprobe_filter_arg+0xfb8>
     a68:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     a6c:      	cmp	w8, #0x21
     a70:      	b.eq	0x10a8 <generic_retkprobe_filter_arg+0x10a8>
     a74:      	cmp	w8, #0x22
     a78:      	b.ne	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     a7c:      	str	x23, [sp, #0x28]
     a80:      	mov	x22, xzr
     a84:      	mov	w23, wzr
     a88:      	add	x19, x21, #0x10
     a8c:      	ldr	w8, [x19, x22, lsl #2]
     a90:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     a94:      	add	x9, sp, #0x60
     a98:      	add	x1, sp, #0x60
     a9c:      	str	w8, [sp, #0x60]
     aa0:      	mov	w8, #0x1                // =1
     aa4:      	ldr	x0, [x0]
     aa8:      	blr	x8
     aac:      	cbz	x0, 0x1d00 <generic_retkprobe_filter_arg+0x1d00>
     ab0:      	ldr	x16, [sp, #0x50]
     ab4:      	mov	w17, #0x1               // =1
     ab8:      	cbz	w29, 0xb34 <generic_retkprobe_filter_arg+0xb34>
     abc:      	mov	x8, xzr
     ac0:      	mov	x9, x25
     ac4:      	mov	x10, x29
     ac8:      	b	0xae0 <generic_retkprobe_filter_arg+0xae0>
     acc:      	add	x8, x8, #0x1
     ad0:      	sub	x10, x10, #0x1
     ad4:      	add	x9, x9, #0x1
     ad8:      	cmp	x8, x29
     adc:      	b.eq	0xb34 <generic_retkprobe_filter_arg+0xb34>
     ae0:      	mov	x11, xzr
     ae4:      	cmp	x10, x11
     ae8:      	b.eq	0xacc <generic_retkprobe_filter_arg+0xacc>
     aec:      	ldrb	w12, [x0, x11]
     af0:      	cbz	w12, 0xb30 <generic_retkprobe_filter_arg+0xb30>
     af4:      	ldrb	w13, [x9, x11]
     af8:      	sub	w14, w13, #0x41
     afc:      	orr	w15, w13, #0x20
     b00:      	cmp	w14, #0x1a
     b04:      	sub	w14, w12, #0x41
     b08:      	csel	w13, w15, w13, lo
     b0c:      	orr	w15, w12, #0x20
     b10:      	cmp	w14, #0x1a
     b14:      	csel	w12, w15, w12, lo
     b18:      	cmp	x11, #0x62
     b1c:      	b.hi	0xacc <generic_retkprobe_filter_arg+0xacc>
     b20:      	add	x11, x11, #0x1
     b24:      	cmp	w13, w12
     b28:      	b.eq	0xae4 <generic_retkprobe_filter_arg+0xae4>
     b2c:      	b	0xacc <generic_retkprobe_filter_arg+0xacc>
     b30:      	tbz	w8, #0x1f, 0x19bc <generic_retkprobe_filter_arg+0x19bc>
     b34:      	ldr	w9, [x21, #0x8]
     b38:      	add	w8, w23, #0xc
     b3c:      	cmp	w8, w9
     b40:      	b.hs	0x1170 <generic_retkprobe_filter_arg+0x1170>
     b44:      	add	x22, x22, #0x1
     b48:      	add	w23, w23, #0x4
     b4c:      	cmp	x22, #0x64
     b50:      	b.ne	0xa8c <generic_retkprobe_filter_arg+0xa8c>
     b54:      	b	0x1170 <generic_retkprobe_filter_arg+0x1170>
     b58:      	cmp	w8, #0xc
     b5c:      	b.ne	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     b60:      	ldr	x11, [x25]
     b64:      	tst	x11, x10
     b68:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     b6c:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     b70:      	sub	w10, w8, #0x1f
     b74:      	cmp	w10, #0x2
     b78:      	b.hs	0x13f4 <generic_retkprobe_filter_arg+0x13f4>
     b7c:      	cmp	w8, #0x1f
     b80:      	b.ne	0xc78 <generic_retkprobe_filter_arg+0xc78>
     b84:      	ldp	x11, x10, [x21, #0x10]
     b88:      	cmp	w9, #0xa
     b8c:      	b.eq	0xb98 <generic_retkprobe_filter_arg+0xb98>
     b90:      	cmp	w9, #0xc
     b94:      	b.ne	0x166c <generic_retkprobe_filter_arg+0x166c>
     b98:      	ldr	x8, [x25]
     b9c:      	cmp	x11, x8
     ba0:      	b.gt	0x1680 <generic_retkprobe_filter_arg+0x1680>
     ba4:      	cmp	x8, x10
     ba8:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
     bac:      	b	0x1680 <generic_retkprobe_filter_arg+0x1680>
     bb0:      	ldr	w8, [x21, #0x10]
     bb4:      	str	wzr, [sp, #0x88]
     bb8:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     bbc:      	add	x9, sp, #0x60
     bc0:      	add	x1, sp, #0x60
     bc4:      	str	w8, [sp, #0x60]
     bc8:      	mov	w8, #0x1                // =1
     bcc:      	ldr	x0, [x0]
     bd0:      	blr	x8
     bd4:      	mov	x22, xzr
     bd8:      	cbz	w29, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     bdc:      	cbz	x0, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     be0:      	mov	x19, x0
     be4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     be8:      	mov	w8, #0x1                // =1
     bec:      	ldr	x0, [x0]
     bf0:      	add	x9, sp, #0x88
     bf4:      	add	x1, sp, #0x88
     bf8:      	blr	x8
     bfc:      	cbz	x0, 0x130c <generic_retkprobe_filter_arg+0x130c>
     c00:      	cmp	w29, #0xff
     c04:      	mov	w8, #0xff               // =255
     c08:      	mov	x22, x0
     c0c:      	mov	x2, x25
     c10:      	csel	w1, w29, w8, lo
     c14:      	mov	x8, x0
     c18:      	lsl	w9, w1, #3
     c1c:      	str	w9, [x8], #0x4
     c20:      	mov	w9, #0x4                // =4
     c24:      	mov	x0, x8
     c28:      	blr	x9
     c2c:      	mov	w8, #0x1                // =1
     c30:      	mov	x0, x19
     c34:      	mov	x1, x22
     c38:      	blr	x8
     c3c:      	cmp	x0, #0x0
     c40:      	cset	w22, ne
     c44:      	b	0x1310 <generic_retkprobe_filter_arg+0x1310>
     c48:      	cmp	w29, #0x1, lsl #12      // =0x1000
     c4c:      	str	wzr, [sp, #0x88]
     c50:      	b.ls	0x1178 <generic_retkprobe_filter_arg+0x1178>
     c54:      	mov	x22, xzr
     c58:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     c5c:      	cmp	w8, #0xd
     c60:      	b.eq	0xfc4 <generic_retkprobe_filter_arg+0xfc4>
     c64:      	cmp	w8, #0xe
     c68:      	b.eq	0xfb8 <generic_retkprobe_filter_arg+0xfb8>
     c6c:      	cmp	w8, #0xf
     c70:      	b.eq	0xf80 <generic_retkprobe_filter_arg+0xf80>
     c74:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     c78:      	ldp	x11, x8, [x21, #0x10]
     c7c:      	cmp	w9, #0xc
     c80:      	b.eq	0xc8c <generic_retkprobe_filter_arg+0xc8c>
     c84:      	cmp	w9, #0xa
     c88:      	b.ne	0x16b8 <generic_retkprobe_filter_arg+0x16b8>
     c8c:      	ldr	x10, [x25]
     c90:      	cmp	x11, x10
     c94:      	ccmp	x10, x8, #0x0, le
     c98:      	cset	w8, le
     c9c:      	b	0x16c8 <generic_retkprobe_filter_arg+0x16c8>
     ca0:      	cmp	w8, #0xc
     ca4:      	b.ne	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     ca8:      	ldr	w11, [x25]
     cac:      	tst	w11, w10
     cb0:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     cb4:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     cb8:      	lsl	x9, x17, x8
     cbc:      	tst	x9, #0xc00
     cc0:      	b.ne	0x1270 <generic_retkprobe_filter_arg+0x1270>
     cc4:      	lsl	x9, x17, x8
     cc8:      	tst	x9, #0x180000000
     ccc:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     cd0:      	cmp	w8, #0x1f
     cd4:      	b.ne	0x18f4 <generic_retkprobe_filter_arg+0x18f4>
     cd8:      	ldr	w9, [x21, #0x10]
     cdc:      	ldrb	w8, [x25]
     ce0:      	b	0xd0c <generic_retkprobe_filter_arg+0xd0c>
     ce4:      	lsl	x9, x17, x8
     ce8:      	tst	x9, #0xc00
     cec:      	b.ne	0x12a8 <generic_retkprobe_filter_arg+0x12a8>
     cf0:      	lsl	x9, x17, x8
     cf4:      	tst	x9, #0x180000000
     cf8:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     cfc:      	cmp	w8, #0x1f
     d00:      	b.ne	0x1918 <generic_retkprobe_filter_arg+0x1918>
     d04:      	ldr	w9, [x21, #0x10]
     d08:      	ldrh	w8, [x25]
     d0c:      	cmp	w9, w8
     d10:      	b.hi	0xd20 <generic_retkprobe_filter_arg+0xd20>
     d14:      	ldr	w9, [x21, #0x14]
     d18:      	cmp	w9, w8
     d1c:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d20:      	ldr	w9, [x21, #0x8]
     d24:      	cmp	w9, #0x11
     d28:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d2c:      	ldr	w10, [x21, #0x18]
     d30:      	cmp	w10, w8
     d34:      	b.hi	0xd44 <generic_retkprobe_filter_arg+0xd44>
     d38:      	ldr	w10, [x21, #0x1c]
     d3c:      	cmp	w10, w8
     d40:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d44:      	cmp	w9, #0x19
     d48:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d4c:      	ldr	w10, [x21, #0x20]
     d50:      	cmp	w10, w8
     d54:      	b.hi	0xd64 <generic_retkprobe_filter_arg+0xd64>
     d58:      	ldr	w10, [x21, #0x24]
     d5c:      	cmp	w10, w8
     d60:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d64:      	cmp	w9, #0x21
     d68:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d6c:      	ldr	w9, [x21, #0x28]
     d70:      	cmp	w9, w8
     d74:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d78:      	ldr	w9, [x21, #0x2c]
     d7c:      	cmp	w9, w8
     d80:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d84:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d88:      	cmp	w9, #0xc
     d8c:      	b.eq	0xd98 <generic_retkprobe_filter_arg+0xd98>
     d90:      	cmp	w9, #0xa
     d94:      	b.ne	0x179c <generic_retkprobe_filter_arg+0x179c>
     d98:      	ldr	x11, [x25]
     d9c:      	cmp	x11, x10
     da0:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
     da4:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     da8:      	and	w8, w29, #0xffff
     dac:      	cmp	w8, #0x90
     db0:      	b.hi	0x1344 <generic_retkprobe_filter_arg+0x1344>
     db4:      	and	w8, w29, #0xff
     db8:      	mov	w9, #0xab               // =171
     dbc:      	tst	w29, #0xffff
     dc0:      	mul	w8, w8, w9
     dc4:      	mov	w9, #0x18               // =24
     dc8:      	lsr	w8, w8, #12
     dcc:      	msub	w8, w8, w9, w29
     dd0:      	b.eq	0xde4 <generic_retkprobe_filter_arg+0xde4>
     dd4:      	tst	w8, #0xff
     dd8:      	mov	w9, w29
     ddc:      	mov	w11, w29
     de0:      	b.eq	0xe00 <generic_retkprobe_filter_arg+0xe00>
     de4:      	sub	w8, w29, w8, uxtb
     de8:      	and	w9, w8, #0xffff
     dec:      	add	w8, w8, #0x18
     df0:      	and	w11, w8, #0xffff
     df4:      	cmp	w9, #0x78
     df8:      	b.hi	0x2390 <generic_retkprobe_filter_arg+0x2390>
     dfc:      	mov	w9, w11
     e00:      	and	w8, w9, #0xff
     e04:      	mov	w9, #0xab               // =171
     e08:      	mul	w8, w8, w9
     e0c:      	lsr	w8, w8, #12
     e10:      	sub	w10, w8, #0x1
     e14:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
     e18:      	cmp	w8, #0x20
     e1c:      	b.gt	0x143c <generic_retkprobe_filter_arg+0x143c>
     e20:      	cmp	w8, #0x1a
     e24:      	b.eq	0x15cc <generic_retkprobe_filter_arg+0x15cc>
     e28:      	cmp	w8, #0x1b
     e2c:      	b.ne	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
     e30:      	ldr	w8, [x21, #0x10]
     e34:      	str	wzr, [sp, #0x88]
     e38:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     e3c:      	add	x9, sp, #0x60
     e40:      	add	x1, sp, #0x60
     e44:      	mov	w19, #0x1               // =1
     e48:      	str	w8, [sp, #0x60]
     e4c:      	mov	w8, #0x1                // =1
     e50:      	ldr	x0, [x0]
     e54:      	blr	x8
     e58:      	mov	x22, xzr
     e5c:      	cbz	w25, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
     e60:      	cbz	x0, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
     e64:      	mov	x22, x0
     e68:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     e6c:      	mov	w8, #0x1                // =1
     e70:      	ldr	x0, [x0]
     e74:      	add	x9, sp, #0x88
     e78:      	add	x1, sp, #0x88
     e7c:      	blr	x8
     e80:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
     e84:      	cmp	w25, #0x7f
     e88:      	mov	w9, #0x7f               // =127
     e8c:      	mov	x1, x0
     e90:      	mov	x8, xzr
     e94:      	sub	x11, x19, x25
     e98:      	sub	w12, w25, #0x2
     e9c:      	sub	w13, w25, #0x1
     ea0:      	csel	w9, w25, w9, lo
     ea4:      	lsl	w10, w9, #3
     ea8:      	mov	x9, x0
     eac:      	str	w10, [x9], #0x5
     eb0:      	neg	x10, x25
     eb4:      	add	w14, w13, w8
     eb8:      	cmp	x11, x8
     ebc:      	and	x14, x14, #0xfff
     ec0:      	ldrb	w14, [x29, x14]
     ec4:      	sturb	w14, [x9, #-0x1]
     ec8:      	b.eq	0xef0 <generic_retkprobe_filter_arg+0xef0>
     ecc:      	cmn	x8, #0x7e
     ed0:      	b.eq	0xef0 <generic_retkprobe_filter_arg+0xef0>
     ed4:      	add	w14, w12, w8
     ed8:      	sub	x8, x8, #0x2
     edc:      	and	x14, x14, #0xfff
     ee0:      	cmp	x10, x8
     ee4:      	ldrb	w14, [x29, x14]
     ee8:      	strb	w14, [x9], #0x2
     eec:      	b.ne	0xeb4 <generic_retkprobe_filter_arg+0xeb4>
     ef0:      	mov	w8, #0x1                // =1
     ef4:      	mov	x0, x22
     ef8:      	b	0x32a8 <generic_retkprobe_filter_arg+0x32a8>
     efc:      	mov	x22, xzr
     f00:      	ldr	x0, [sp, #0x38]
     f04:      	ldp	x12, x16, [sp, #0x48]
     f08:      	mov	w17, #0x1               // =1
     f0c:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
     f10:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     f14:      	ldp	w11, w8, [x21, #0x10]
     f18:      	cmp	w9, #0xc
     f1c:      	b.hi	0x1a98 <generic_retkprobe_filter_arg+0x1a98>
     f20:      	lsl	w10, w17, w9
     f24:      	mov	w12, #0x1402            // =5122
     f28:      	tst	w10, w12
     f2c:      	b.eq	0x1a98 <generic_retkprobe_filter_arg+0x1a98>
     f30:      	ldr	w10, [x25]
     f34:      	cmp	w11, w10
     f38:      	ccmp	w10, w8, #0x0, le
     f3c:      	cset	w8, le
     f40:      	b	0x1aa8 <generic_retkprobe_filter_arg+0x1aa8>
     f44:      	cmp	w8, #0x1c
     f48:      	b.eq	0x1578 <generic_retkprobe_filter_arg+0x1578>
     f4c:      	mov	x25, x10
     f50:      	cmp	w8, #0x1a
     f54:      	b.eq	0x14c0 <generic_retkprobe_filter_arg+0x14c0>
     f58:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     f5c:      	cmp	w8, #0x12
     f60:      	b.eq	0xf80 <generic_retkprobe_filter_arg+0xf80>
     f64:      	cmp	w8, #0x13
     f68:      	b.ne	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     f6c:      	ldrh	w29, [x25, #0x22]
     f70:      	mov	w11, wzr
     f74:      	mov	w13, wzr
     f78:      	mov	x19, xzr
     f7c:      	b	0xfd0 <generic_retkprobe_filter_arg+0xfd0>
     f80:      	ldrh	w29, [x25, #0x20]
     f84:      	mov	w11, wzr
     f88:      	mov	w13, wzr
     f8c:      	mov	x19, xzr
     f90:      	b	0xfd0 <generic_retkprobe_filter_arg+0xfd0>
     f94:      	cmp	w8, #0x1c
     f98:      	b.eq	0x16f8 <generic_retkprobe_filter_arg+0x16f8>
     f9c:      	cmp	w8, #0x1d
     fa0:      	b.ne	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     fa4:      	cmp	w9, #0x7
     fa8:      	b.ne	0x1c54 <generic_retkprobe_filter_arg+0x1c54>
     fac:      	cbnz	x10, 0x1c64 <generic_retkprobe_filter_arg+0x1c64>
     fb0:      	mov	x19, xzr
     fb4:      	b	0x1c78 <generic_retkprobe_filter_arg+0x1c78>
     fb8:      	ldp	w11, w13, [x25, #0x10]
     fbc:      	ldr	x19, [x25, #0x18]
     fc0:      	b	0xfcc <generic_retkprobe_filter_arg+0xfcc>
     fc4:      	ldp	w11, w13, [x25]
     fc8:      	ldr	x19, [x25, #0x8]
     fcc:      	mov	x29, xzr
     fd0:      	mov	x22, xzr
     fd4:      	cmp	w8, #0x11
     fd8:      	b.gt	0x1004 <generic_retkprobe_filter_arg+0x1004>
     fdc:      	sub	w9, w8, #0xd
     fe0:      	cmp	w9, #0x2
     fe4:      	b.lo	0x1030 <generic_retkprobe_filter_arg+0x1030>
     fe8:      	ldr	x19, [sp, #0x30]
     fec:      	sub	w9, w8, #0xf
     ff0:      	cmp	w9, #0x2
     ff4:      	b.lo	0x11f8 <generic_retkprobe_filter_arg+0x11f8>
     ff8:      	cmp	w8, #0x11
     ffc:      	b.eq	0x16fc <generic_retkprobe_filter_arg+0x16fc>
    1000:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1004:      	cmp	w8, #0x19
    1008:      	b.hi	0x11e8 <generic_retkprobe_filter_arg+0x11e8>
    100c:      	lsl	w9, w17, w8
    1010:      	mov	w10, #0x500000          // =5242880
    1014:      	tst	w9, w10
    1018:      	b.ne	0x12e4 <generic_retkprobe_filter_arg+0x12e4>
    101c:      	mov	w10, #0xa00000          // =10485760
    1020:      	tst	w9, w10
    1024:      	b.ne	0x12f8 <generic_retkprobe_filter_arg+0x12f8>
    1028:      	tst	w9, #0x3000000
    102c:      	b.eq	0x11e8 <generic_retkprobe_filter_arg+0x11e8>
    1030:      	ldrh	w8, [x25, #0x26]
    1034:      	cmp	w8, #0xa
    1038:      	b.eq	0x1354 <generic_retkprobe_filter_arg+0x1354>
    103c:      	cmp	w8, #0x2
    1040:      	b.ne	0x13e0 <generic_retkprobe_filter_arg+0x13e0>
    1044:      	ldr	w8, [x21, #0x10]
    1048:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    104c:      	add	x9, sp, #0xac
    1050:      	add	x1, sp, #0xac
    1054:      	str	w8, [sp, #0xac]
    1058:      	mov	w8, #0x1                // =1
    105c:      	mov	w22, w11
    1060:      	ldr	x0, [x0]
    1064:      	blr	x8
    1068:      	ldr	x19, [sp, #0x30]
    106c:      	cbz	x0, 0x1d88 <generic_retkprobe_filter_arg+0x1d88>
    1070:      	mov	w8, #0x20               // =32
    1074:      	add	x1, sp, #0x88
    1078:      	stp	w8, w22, [sp, #0x88]
    107c:      	b	0x139c <generic_retkprobe_filter_arg+0x139c>
    1080:      	cmp	w9, #0xc
    1084:      	b.hi	0x1dd8 <generic_retkprobe_filter_arg+0x1dd8>
    1088:      	lsl	w11, w17, w9
    108c:      	mov	w13, #0x1402            // =5122
    1090:      	tst	w11, w13
    1094:      	b.eq	0x1dd8 <generic_retkprobe_filter_arg+0x1dd8>
    1098:      	ldr	w11, [x25]
    109c:      	cmp	w11, w10
    10a0:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    10a4:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
    10a8:      	str	x23, [sp, #0x28]
    10ac:      	mov	x19, xzr
    10b0:      	mov	w22, wzr
    10b4:      	add	x23, x21, #0x10
    10b8:      	ldr	w8, [x23, x19, lsl #2]
    10bc:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    10c0:      	add	x9, sp, #0x60
    10c4:      	add	x1, sp, #0x60
    10c8:      	str	w8, [sp, #0x60]
    10cc:      	mov	w8, #0x1                // =1
    10d0:      	ldr	x0, [x0]
    10d4:      	blr	x8
    10d8:      	cbz	x0, 0x1cec <generic_retkprobe_filter_arg+0x1cec>
    10dc:      	ldr	x16, [sp, #0x50]
    10e0:      	mov	w17, #0x1               // =1
    10e4:      	cbz	w29, 0x1150 <generic_retkprobe_filter_arg+0x1150>
    10e8:      	mov	x8, xzr
    10ec:      	mov	x9, x25
    10f0:      	mov	x10, x29
    10f4:      	b	0x110c <generic_retkprobe_filter_arg+0x110c>
    10f8:      	add	x8, x8, #0x1
    10fc:      	sub	x10, x10, #0x1
    1100:      	add	x9, x9, #0x1
    1104:      	cmp	x8, x29
    1108:      	b.eq	0x1150 <generic_retkprobe_filter_arg+0x1150>
    110c:      	mov	x11, xzr
    1110:      	nop
    1114:      	nop
    1118:      	nop
    111c:      	nop
    1120:      	cmp	x10, x11
    1124:      	b.eq	0x10f8 <generic_retkprobe_filter_arg+0x10f8>
    1128:      	ldrb	w12, [x0, x11]
    112c:      	cbz	w12, 0x114c <generic_retkprobe_filter_arg+0x114c>
    1130:      	cmp	x11, #0x62
    1134:      	b.hi	0x10f8 <generic_retkprobe_filter_arg+0x10f8>
    1138:      	ldrb	w13, [x9, x11]
    113c:      	add	x11, x11, #0x1
    1140:      	cmp	w13, w12
    1144:      	b.eq	0x1120 <generic_retkprobe_filter_arg+0x1120>
    1148:      	b	0x10f8 <generic_retkprobe_filter_arg+0x10f8>
    114c:      	tbz	w8, #0x1f, 0x19bc <generic_retkprobe_filter_arg+0x19bc>
    1150:      	ldr	w9, [x21, #0x8]
    1154:      	add	w8, w22, #0xc
    1158:      	cmp	w8, w9
    115c:      	b.hs	0x1170 <generic_retkprobe_filter_arg+0x1170>
    1160:      	add	x19, x19, #0x1
    1164:      	add	w22, w22, #0x4
    1168:      	cmp	x19, #0x64
    116c:      	b.ne	0x10b8 <generic_retkprobe_filter_arg+0x10b8>
    1170:      	mov	x22, xzr
    1174:      	b	0x1d0c <generic_retkprobe_filter_arg+0x1d0c>
    1178:      	and	w8, w29, #0xffff
    117c:      	cmp	w8, #0x90
    1180:      	b.hi	0x178c <generic_retkprobe_filter_arg+0x178c>
    1184:      	and	w8, w29, #0xff
    1188:      	mov	w9, #0xab               // =171
    118c:      	tst	w29, #0xffff
    1190:      	mul	w8, w8, w9
    1194:      	mov	w9, #0x18               // =24
    1198:      	lsr	w8, w8, #12
    119c:      	msub	w8, w8, w9, w29
    11a0:      	b.eq	0x11b4 <generic_retkprobe_filter_arg+0x11b4>
    11a4:      	tst	w8, #0xff
    11a8:      	mov	w9, w29
    11ac:      	mov	w11, w29
    11b0:      	b.eq	0x11d0 <generic_retkprobe_filter_arg+0x11d0>
    11b4:      	sub	w8, w29, w8, uxtb
    11b8:      	and	w9, w8, #0xffff
    11bc:      	add	w8, w8, #0x18
    11c0:      	and	w11, w8, #0xffff
    11c4:      	cmp	w9, #0x78
    11c8:      	b.hi	0x2850 <generic_retkprobe_filter_arg+0x2850>
    11cc:      	mov	w9, w11
    11d0:      	and	w8, w9, #0xff
    11d4:      	mov	w9, #0xab               // =171
    11d8:      	mul	w8, w8, w9
    11dc:      	lsr	w8, w8, #12
    11e0:      	sub	w10, w8, #0x1
    11e4:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    11e8:      	ldr	x19, [sp, #0x30]
    11ec:      	sub	w8, w8, #0x12
    11f0:      	cmp	w8, #0x2
    11f4:      	b.hs	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    11f8:      	ldrb	w8, [x21, #0x10]
    11fc:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1200:      	add	x9, sp, #0xac
    1204:      	add	x1, sp, #0xac
    1208:      	str	w8, [sp, #0xac]
    120c:      	mov	w8, #0x1                // =1
    1210:      	ldr	x0, [x0]
    1214:      	blr	x8
    1218:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    121c:      	str	x29, [sp, #0x88]
    1220:      	mov	w8, #0x1                // =1
    1224:      	add	x9, sp, #0x88
    1228:      	add	x1, sp, #0x88
    122c:      	b	0x1730 <generic_retkprobe_filter_arg+0x1730>
    1230:      	cmp	w8, #0x1
    1234:      	b.eq	0x19c4 <generic_retkprobe_filter_arg+0x19c4>
    1238:      	cmp	w8, #0x2
    123c:      	b.ne	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    1240:      	ldrb	w10, [x25]
    1244:      	cmp	w9, w10
    1248:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    124c:      	b	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    1250:      	cmp	w8, #0x1
    1254:      	b.eq	0x1a04 <generic_retkprobe_filter_arg+0x1a04>
    1258:      	cmp	w8, #0x2
    125c:      	b.ne	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1260:      	ldrh	w10, [x25]
    1264:      	cmp	w9, w10
    1268:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    126c:      	b	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1270:      	ldrb	w8, [x21, #0x10]
    1274:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1278:      	add	x9, sp, #0x88
    127c:      	add	x1, sp, #0x88
    1280:      	str	w8, [sp, #0x88]
    1284:      	mov	w8, #0x1                // =1
    1288:      	ldr	x0, [x0]
    128c:      	blr	x8
    1290:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    1294:      	ldrb	w8, [x25]
    1298:      	add	x9, sp, #0x60
    129c:      	str	x8, [sp, #0x60]
    12a0:      	mov	w8, #0x1                // =1
    12a4:      	b	0x12dc <generic_retkprobe_filter_arg+0x12dc>
    12a8:      	ldrb	w8, [x21, #0x10]
    12ac:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    12b0:      	add	x9, sp, #0x88
    12b4:      	add	x1, sp, #0x88
    12b8:      	str	w8, [sp, #0x88]
    12bc:      	mov	w8, #0x1                // =1
    12c0:      	ldr	x0, [x0]
    12c4:      	blr	x8
    12c8:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    12cc:      	ldrh	w8, [x25]
    12d0:      	add	x9, sp, #0x60
    12d4:      	str	x8, [sp, #0x60]
    12d8:      	mov	w8, #0x1                // =1
    12dc:      	add	x1, sp, #0x60
    12e0:      	b	0x1730 <generic_retkprobe_filter_arg+0x1730>
    12e4:      	ldr	x19, [sp, #0x30]
    12e8:      	cmp	x29, #0x400
    12ec:      	cset	w22, lo
    12f0:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    12f4:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    12f8:      	ldr	x19, [sp, #0x30]
    12fc:      	cmp	x29, #0x3ff
    1300:      	cset	w22, hi
    1304:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1308:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    130c:      	mov	x22, xzr
    1310:      	ldr	x19, [sp, #0x30]
    1314:      	ldr	x0, [sp, #0x38]
    1318:      	ldp	x12, x16, [sp, #0x48]
    131c:      	mov	w17, #0x1               // =1
    1320:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    1324:      	cmp	x0, #0x0
    1328:      	ldr	x0, [sp, #0x38]
    132c:      	ldp	x12, x16, [sp, #0x48]
    1330:      	mov	w17, #0x1               // =1
    1334:      	cset	w8, eq
    1338:      	mov	w22, w8
    133c:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1340:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1344:      	cmp	w8, #0x101
    1348:      	b.hs	0x19a0 <generic_retkprobe_filter_arg+0x19a0>
    134c:      	mov	w11, #0x100             // =256
    1350:      	b	0x2390 <generic_retkprobe_filter_arg+0x2390>
    1354:      	ldr	w8, [x21, #0x14]
    1358:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    135c:      	add	x9, sp, #0xac
    1360:      	add	x1, sp, #0xac
    1364:      	str	w8, [sp, #0xac]
    1368:      	mov	w8, #0x1                // =1
    136c:      	mov	w25, w13
    1370:      	mov	w22, w11
    1374:      	ldr	x0, [x0]
    1378:      	blr	x8
    137c:      	cbz	x0, 0x1db0 <generic_retkprobe_filter_arg+0x1db0>
    1380:      	mov	w8, #0x80               // =128
    1384:      	stp	w25, w19, [sp, #0x90]
    1388:      	add	x1, sp, #0x88
    138c:      	stp	w8, w22, [sp, #0x88]
    1390:      	lsr	x8, x19, #32
    1394:      	ldr	x19, [sp, #0x30]
    1398:      	str	w8, [sp, #0x98]
    139c:      	mov	w8, #0x1                // =1
    13a0:      	blr	x8
    13a4:      	ldr	w8, [x21, #0x4]
    13a8:      	sub	w9, w8, #0x18
    13ac:      	cmp	w9, #0x2
    13b0:      	b.lo	0x19b4 <generic_retkprobe_filter_arg+0x19b4>
    13b4:      	ldp	x12, x16, [sp, #0x48]
    13b8:      	sub	w8, w8, #0xd
    13bc:      	mov	w17, #0x1               // =1
    13c0:      	cmp	w8, #0x1
    13c4:      	b.hi	0x1f54 <generic_retkprobe_filter_arg+0x1f54>
    13c8:      	cmp	x0, #0x0
    13cc:      	ldr	x0, [sp, #0x38]
    13d0:      	cset	w8, ne
    13d4:      	mov	w22, w8
    13d8:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    13dc:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    13e0:      	ldr	x19, [sp, #0x30]
    13e4:      	mov	w8, wzr
    13e8:      	mov	w22, wzr
    13ec:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    13f0:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    13f4:      	cmp	w8, #0x1e
    13f8:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    13fc:      	ldr	w8, [x21, #0x10]
    1400:      	mov	w10, #0x5ea0            // =24224
    1404:      	and	x8, x8, #0x7
    1408:      	add	x9, x20, x8, lsl #2
    140c:      	ldr	w9, [x9, x10]
    1410:      	cbnz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
    1414:      	add	x8, x20, x8, lsl #3
    1418:      	ldr	x9, [x25]
    141c:      	ldr	x8, [x8, #0x5e78]
    1420:      	and	x8, x8, #0x7ff
    1424:      	add	x8, x20, x8
    1428:      	ldr	x8, [x8, #0x90]
    142c:      	bics	xzr, x8, x9
    1430:      	cset	w22, ne
    1434:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1438:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    143c:      	cmp	w8, #0x21
    1440:      	b.eq	0x1ae0 <generic_retkprobe_filter_arg+0x1ae0>
    1444:      	cmp	w8, #0x22
    1448:      	b.ne	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    144c:      	mov	w19, #0x10              // =16
    1450:      	ldr	w8, [x21, x19]
    1454:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1458:      	add	x9, sp, #0x60
    145c:      	add	x1, sp, #0x60
    1460:      	str	w8, [sp, #0x60]
    1464:      	mov	w8, #0x1                // =1
    1468:      	ldr	x0, [x0]
    146c:      	blr	x8
    1470:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    1474:      	mov	x1, x0
    1478:      	mov	x0, x29
    147c:      	mov	x2, x25
    1480:      	bl	0x1480 <generic_retkprobe_filter_arg+0x1480>
    1484:      	tbz	w0, #0x1f, 0x2674 <generic_retkprobe_filter_arg+0x2674>
    1488:      	ldr	w8, [x21, #0x8]
    148c:      	ldp	x12, x16, [sp, #0x48]
    1490:      	add	x19, x19, #0x4
    1494:      	mov	w17, #0x1               // =1
    1498:      	mov	x22, xzr
    149c:      	sub	w9, w19, #0x8
    14a0:      	cmp	w9, w8
    14a4:      	b.hs	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    14a8:      	cmp	x19, #0x1a0
    14ac:      	b.ne	0x1450 <generic_retkprobe_filter_arg+0x1450>
    14b0:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    14b4:      	mov	x25, x10
    14b8:      	cmp	w8, #0x8
    14bc:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    14c0:      	ldr	w8, [x21, #0x10]
    14c4:      	str	wzr, [sp, #0x88]
    14c8:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    14cc:      	add	x9, sp, #0x60
    14d0:      	add	x1, sp, #0x60
    14d4:      	str	w8, [sp, #0x60]
    14d8:      	mov	w8, #0x1                // =1
    14dc:      	ldr	x0, [x0]
    14e0:      	blr	x8
    14e4:      	mov	x22, xzr
    14e8:      	cbz	w29, 0x1ed0 <generic_retkprobe_filter_arg+0x1ed0>
    14ec:      	cbz	x0, 0x1ed0 <generic_retkprobe_filter_arg+0x1ed0>
    14f0:      	mov	x19, x0
    14f4:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    14f8:      	mov	w8, #0x1                // =1
    14fc:      	ldr	x0, [x0]
    1500:      	add	x9, sp, #0x88
    1504:      	add	x1, sp, #0x88
    1508:      	blr	x8
    150c:      	cbz	x0, 0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
    1510:      	lsl	w9, w29, #3
    1514:      	mov	x8, x0
    1518:      	mov	x2, x25
    151c:      	mov	w1, w29
    1520:      	str	w9, [x8], #0x4
    1524:      	mov	w9, #0x4                // =4
    1528:      	mov	x25, x0
    152c:      	mov	x0, x8
    1530:      	blr	x9
    1534:      	mov	w8, #0x1                // =1
    1538:      	mov	x0, x19
    153c:      	mov	x1, x25
    1540:      	blr	x8
    1544:      	cmp	x0, #0x0
    1548:      	cset	w22, ne
    154c:      	b	0x1ecc <generic_retkprobe_filter_arg+0x1ecc>
    1550:      	mov	w13, #0x100             // =256
    1554:      	sub	w8, w13, #0x100
    1558:      	ror	w8, w8, #0x8
    155c:      	cmp	w8, #0x2
    1560:      	b.gt	0x1988 <generic_retkprobe_filter_arg+0x1988>
    1564:      	cbz	w8, 0x1fc4 <generic_retkprobe_filter_arg+0x1fc4>
    1568:      	cmp	w8, #0x1
    156c:      	b.ne	0x1fbc <generic_retkprobe_filter_arg+0x1fbc>
    1570:      	mov	w11, #0x7               // =7
    1574:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    1578:      	ldrb	w8, [x21, #0x10]
    157c:      	ldrh	w19, [x25]
    1580:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1584:      	add	x9, sp, #0x88
    1588:      	add	x1, sp, #0x88
    158c:      	str	w8, [sp, #0x88]
    1590:      	mov	w8, #0x1                // =1
    1594:      	ldr	x0, [x0]
    1598:      	blr	x8
    159c:      	cbz	x0, 0x1cd0 <generic_retkprobe_filter_arg+0x1cd0>
    15a0:      	str	x19, [sp, #0x60]
    15a4:      	mov	w8, #0x1                // =1
    15a8:      	add	x9, sp, #0x60
    15ac:      	add	x1, sp, #0x60
    15b0:      	blr	x8
    15b4:      	ldr	w9, [x21, #0x4]
    15b8:      	mov	w8, wzr
    15bc:      	cmp	w9, #0x1d
    15c0:      	b.hi	0x1cc0 <generic_retkprobe_filter_arg+0x1cc0>
    15c4:      	ldr	x19, [sp, #0x30]
    15c8:      	b	0x1744 <generic_retkprobe_filter_arg+0x1744>
    15cc:      	ldr	w8, [x21, #0x10]
    15d0:      	str	wzr, [sp, #0x88]
    15d4:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    15d8:      	add	x9, sp, #0x60
    15dc:      	add	x1, sp, #0x60
    15e0:      	str	w8, [sp, #0x60]
    15e4:      	mov	w8, #0x1                // =1
    15e8:      	ldr	x0, [x0]
    15ec:      	blr	x8
    15f0:      	mov	x22, xzr
    15f4:      	cbz	w25, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
    15f8:      	cbz	x0, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
    15fc:      	mov	x19, x0
    1600:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1604:      	mov	w8, #0x1                // =1
    1608:      	ldr	x0, [x0]
    160c:      	add	x9, sp, #0x88
    1610:      	add	x1, sp, #0x88
    1614:      	blr	x8
    1618:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    161c:      	cmp	w25, #0xff
    1620:      	mov	w8, #0xff               // =255
    1624:      	mov	x22, x0
    1628:      	mov	x2, x29
    162c:      	csel	w1, w25, w8, lo
    1630:      	mov	x8, x0
    1634:      	lsl	w9, w1, #3
    1638:      	str	w9, [x8], #0x4
    163c:      	mov	w9, #0x4                // =4
    1640:      	mov	x0, x8
    1644:      	blr	x9
    1648:      	mov	w8, #0x1                // =1
    164c:      	mov	x0, x19
    1650:      	mov	x1, x22
    1654:      	b	0x32a8 <generic_retkprobe_filter_arg+0x32a8>
    1658:      	cmp	w25, #0x1, lsl #12      // =0x1000
    165c:      	str	wzr, [sp, #0x88]
    1660:      	b.ls	0x1ba8 <generic_retkprobe_filter_arg+0x1ba8>
    1664:      	mov	x22, xzr
    1668:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    166c:      	ldr	x8, [x25]
    1670:      	cmp	x11, x8
    1674:      	b.hi	0x1680 <generic_retkprobe_filter_arg+0x1680>
    1678:      	cmp	x8, x10
    167c:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    1680:      	ldr	w10, [x21, #0x8]
    1684:      	cmp	w10, #0x19
    1688:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    168c:      	ldp	x12, x11, [x21, #0x20]
    1690:      	cmp	w9, #0xc
    1694:      	b.eq	0x16a0 <generic_retkprobe_filter_arg+0x16a0>
    1698:      	cmp	w9, #0xa
    169c:      	b.ne	0x1d40 <generic_retkprobe_filter_arg+0x1d40>
    16a0:      	cmp	x12, x8
    16a4:      	ldr	x12, [sp, #0x48]
    16a8:      	b.gt	0x1d54 <generic_retkprobe_filter_arg+0x1d54>
    16ac:      	cmp	x8, x11
    16b0:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    16b4:      	b	0x1d54 <generic_retkprobe_filter_arg+0x1d54>
    16b8:      	ldr	x10, [x25]
    16bc:      	cmp	x11, x10
    16c0:      	ccmp	x10, x8, #0x2, ls
    16c4:      	cset	w8, ls
    16c8:      	ldr	w11, [x21, #0x8]
    16cc:      	cmp	w11, #0x19
    16d0:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    16d4:      	ldp	x13, x12, [x21, #0x20]
    16d8:      	cmp	w9, #0xc
    16dc:      	b.eq	0x16e8 <generic_retkprobe_filter_arg+0x16e8>
    16e0:      	cmp	w9, #0xa
    16e4:      	b.ne	0x1c18 <generic_retkprobe_filter_arg+0x1c18>
    16e8:      	cmp	x13, x10
    16ec:      	ccmp	x10, x12, #0x0, le
    16f0:      	cset	w12, le
    16f4:      	b	0x1c24 <generic_retkprobe_filter_arg+0x1c24>
    16f8:      	ldrh	w22, [x25, #0x26]
    16fc:      	ldrb	w8, [x21, #0x10]
    1700:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1704:      	add	x9, sp, #0xac
    1708:      	add	x1, sp, #0xac
    170c:      	str	w8, [sp, #0xac]
    1710:      	mov	w8, #0x1                // =1
    1714:      	ldr	x0, [x0]
    1718:      	blr	x8
    171c:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    1720:      	str	x22, [sp, #0x88]
    1724:      	mov	w8, #0x1                // =1
    1728:      	add	x9, sp, #0x88
    172c:      	add	x1, sp, #0x88
    1730:      	blr	x8
    1734:      	ldr	w9, [x21, #0x4]
    1738:      	mov	w8, wzr
    173c:      	cmp	w9, #0x1d
    1740:      	b.hi	0x1cc4 <generic_retkprobe_filter_arg+0x1cc4>
    1744:      	mov	w17, #0x1               // =1
    1748:      	mov	w10, #0x8400            // =33792
    174c:      	lsl	w9, w17, w9
    1750:      	movk	w10, #0x3003, lsl #16
    1754:      	tst	w9, w10
    1758:      	ldp	x12, x16, [sp, #0x48]
    175c:      	b.eq	0x176c <generic_retkprobe_filter_arg+0x176c>
    1760:      	cmp	x0, #0x0
    1764:      	cset	w8, ne
    1768:      	b	0x1784 <generic_retkprobe_filter_arg+0x1784>
    176c:      	mov	w10, #0x800             // =2048
    1770:      	movk	w10, #0xc, lsl #16
    1774:      	tst	w9, w10
    1778:      	b.eq	0x1784 <generic_retkprobe_filter_arg+0x1784>
    177c:      	cmp	x0, #0x0
    1780:      	cset	w8, eq
    1784:      	mov	w22, w8
    1788:      	b	0x1ce0 <generic_retkprobe_filter_arg+0x1ce0>
    178c:      	cmp	w8, #0x101
    1790:      	b.hs	0x1eb4 <generic_retkprobe_filter_arg+0x1eb4>
    1794:      	mov	w11, #0x100             // =256
    1798:      	b	0x2850 <generic_retkprobe_filter_arg+0x2850>
    179c:      	ldr	x11, [x25]
    17a0:      	cmp	x11, x10
    17a4:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    17a8:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
    17ac:      	ldr	x11, [x25]
    17b0:      	cmp	x11, x10
    17b4:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    17b8:      	ldr	w10, [x21, #0x8]
    17bc:      	cmp	w10, #0x11
    17c0:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    17c4:      	ldr	x11, [x21, #0x18]
    17c8:      	cmp	w8, #0x2
    17cc:      	b.le	0x17f0 <generic_retkprobe_filter_arg+0x17f0>
    17d0:      	sub	w12, w8, #0x3
    17d4:      	cmp	w12, #0x2
    17d8:      	b.hs	0x1824 <generic_retkprobe_filter_arg+0x1824>
    17dc:      	ldr	x12, [x25]
    17e0:      	cmp	x12, x11
    17e4:      	ldr	x12, [sp, #0x48]
    17e8:      	b.ne	0x2264 <generic_retkprobe_filter_arg+0x2264>
    17ec:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    17f0:      	cmp	w8, #0x1
    17f4:      	b.eq	0x18d0 <generic_retkprobe_filter_arg+0x18d0>
    17f8:      	cmp	w8, #0x2
    17fc:      	b.ne	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1800:      	cmp	w9, #0xc
    1804:      	b.eq	0x1810 <generic_retkprobe_filter_arg+0x1810>
    1808:      	cmp	w9, #0xa
    180c:      	b.ne	0x2254 <generic_retkprobe_filter_arg+0x2254>
    1810:      	ldr	x12, [x25]
    1814:      	cmp	x12, x11
    1818:      	ldr	x12, [sp, #0x48]
    181c:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    1820:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1824:      	ldr	x12, [sp, #0x48]
    1828:      	cmp	w8, #0xc
    182c:      	b.ne	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1830:      	ldr	x12, [x25]
    1834:      	tst	x12, x11
    1838:      	ldr	x12, [sp, #0x48]
    183c:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1840:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1844:      	cmp	w8, #0xc
    1848:      	b.ne	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    184c:      	ldrb	w10, [x25]
    1850:      	tst	w9, w10
    1854:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1858:      	b	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    185c:      	cmp	w8, #0xc
    1860:      	b.ne	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1864:      	ldrh	w10, [x25]
    1868:      	tst	w9, w10
    186c:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1870:      	b	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1874:      	ldr	w9, [x21, #0x8]
    1878:      	cmp	w9, #0xd
    187c:      	b.lo	0x664 <generic_retkprobe_filter_arg+0x664>
    1880:      	ldr	w10, [x21, #0x14]
    1884:      	cbz	w10, 0x664 <generic_retkprobe_filter_arg+0x664>
    1888:      	cmp	w10, w8
    188c:      	b.eq	0x4a8 <generic_retkprobe_filter_arg+0x4a8>
    1890:      	cmp	w9, #0x11
    1894:      	b.lo	0x664 <generic_retkprobe_filter_arg+0x664>
    1898:      	ldr	w10, [x21, #0x18]
    189c:      	cbz	w10, 0x664 <generic_retkprobe_filter_arg+0x664>
    18a0:      	cmp	w10, w8
    18a4:      	b.eq	0x4a8 <generic_retkprobe_filter_arg+0x4a8>
    18a8:      	cmp	w9, #0x15
    18ac:      	b.lo	0x18c4 <generic_retkprobe_filter_arg+0x18c4>
    18b0:      	ldr	w9, [x21, #0x1c]
    18b4:      	cbz	w9, 0x18c4 <generic_retkprobe_filter_arg+0x18c4>
    18b8:      	cmp	w9, w8
    18bc:      	cset	w22, eq
    18c0:      	b	0x18c8 <generic_retkprobe_filter_arg+0x18c8>
    18c4:      	mov	x22, xzr
    18c8:      	ldr	x19, [sp, #0x30]
    18cc:      	b	0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    18d0:      	cmp	w9, #0xc
    18d4:      	b.eq	0x18e0 <generic_retkprobe_filter_arg+0x18e0>
    18d8:      	cmp	w9, #0xa
    18dc:      	b.ne	0x2240 <generic_retkprobe_filter_arg+0x2240>
    18e0:      	ldr	x12, [x25]
    18e4:      	cmp	x12, x11
    18e8:      	ldr	x12, [sp, #0x48]
    18ec:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    18f0:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    18f4:      	ldp	w8, w11, [x21, #0x10]
    18f8:      	ldrb	w9, [x25]
    18fc:      	cmp	w8, w9
    1900:      	ldr	w10, [x21, #0x8]
    1904:      	ccmp	w11, w9, #0x0, ls
    1908:      	cset	w8, hs
    190c:      	cmp	w10, #0x11
    1910:      	b.hs	0x1938 <generic_retkprobe_filter_arg+0x1938>
    1914:      	b	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1918:      	ldp	w8, w11, [x21, #0x10]
    191c:      	ldrh	w9, [x25]
    1920:      	cmp	w8, w9
    1924:      	ldr	w10, [x21, #0x8]
    1928:      	ccmp	w11, w9, #0x0, ls
    192c:      	cset	w8, hs
    1930:      	cmp	w10, #0x11
    1934:      	b.lo	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1938:      	ldp	w11, w12, [x21, #0x18]
    193c:      	cmp	w11, w9
    1940:      	ccmp	w12, w9, #0x0, ls
    1944:      	ldr	x12, [sp, #0x48]
    1948:      	csinc	w8, w8, wzr, lo
    194c:      	cmp	w10, #0x19
    1950:      	b.lo	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1954:      	ldp	w11, w12, [x21, #0x20]
    1958:      	cmp	w11, w9
    195c:      	ccmp	w12, w9, #0x0, ls
    1960:      	ldr	x12, [sp, #0x48]
    1964:      	csinc	w8, w8, wzr, lo
    1968:      	cmp	w10, #0x21
    196c:      	b.lo	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1970:      	ldp	w10, w11, [x21, #0x28]
    1974:      	cmp	w10, w9
    1978:      	ccmp	w11, w9, #0x0, ls
    197c:      	csinc	w8, w8, wzr, lo
    1980:      	tbz	w8, #0x0, 0x140 <generic_retkprobe_filter_arg+0x140>
    1984:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1988:      	cmp	w8, #0x3
    198c:      	b.eq	0x1fcc <generic_retkprobe_filter_arg+0x1fcc>
    1990:      	cmp	w8, #0x7
    1994:      	b.ne	0x1fbc <generic_retkprobe_filter_arg+0x1fbc>
    1998:      	mov	w11, #0x9               // =9
    199c:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    19a0:      	and	w8, w29, #0xffff
    19a4:      	cmp	w8, #0x201
    19a8:      	b.hs	0x1f44 <generic_retkprobe_filter_arg+0x1f44>
    19ac:      	mov	w11, #0x200             // =512
    19b0:      	b	0x2390 <generic_retkprobe_filter_arg+0x2390>
    19b4:      	cmp	x0, #0x0
    19b8:      	b	0x1d94 <generic_retkprobe_filter_arg+0x1d94>
    19bc:      	mov	w22, #0x1               // =1
    19c0:      	b	0x1d0c <generic_retkprobe_filter_arg+0x1d0c>
    19c4:      	ldrb	w10, [x25]
    19c8:      	cmp	w9, w10
    19cc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    19d0:      	ldr	w9, [x21, #0x8]
    19d4:      	cmp	w9, #0xd
    19d8:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    19dc:      	ldr	w10, [x21, #0x14]
    19e0:      	cmp	w8, #0x2
    19e4:      	b.le	0x1f04 <generic_retkprobe_filter_arg+0x1f04>
    19e8:      	sub	w11, w8, #0x3
    19ec:      	cmp	w11, #0x2
    19f0:      	b.hs	0x22ec <generic_retkprobe_filter_arg+0x22ec>
    19f4:      	ldrb	w11, [x25]
    19f8:      	cmp	w10, w11
    19fc:      	b.ne	0x2594 <generic_retkprobe_filter_arg+0x2594>
    1a00:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    1a04:      	ldrh	w10, [x25]
    1a08:      	cmp	w9, w10
    1a0c:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    1a10:      	ldr	w9, [x21, #0x8]
    1a14:      	cmp	w9, #0xd
    1a18:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    1a1c:      	ldr	w10, [x21, #0x14]
    1a20:      	cmp	w8, #0x2
    1a24:      	b.le	0x1f24 <generic_retkprobe_filter_arg+0x1f24>
    1a28:      	sub	w11, w8, #0x3
    1a2c:      	cmp	w11, #0x2
    1a30:      	b.hs	0x2304 <generic_retkprobe_filter_arg+0x2304>
    1a34:      	ldrh	w11, [x25]
    1a38:      	cmp	w10, w11
    1a3c:      	b.ne	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    1a40:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    1a44:      	ldr	w8, [x25]
    1a48:      	cmp	w11, w8
    1a4c:      	b.hi	0x1a58 <generic_retkprobe_filter_arg+0x1a58>
    1a50:      	cmp	w8, w10
    1a54:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    1a58:      	ldr	w10, [x21, #0x8]
    1a5c:      	cmp	w10, #0x11
    1a60:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1a64:      	ldp	w12, w11, [x21, #0x18]
    1a68:      	cmp	w9, #0xc
    1a6c:      	b.hi	0x2160 <generic_retkprobe_filter_arg+0x2160>
    1a70:      	lsl	w13, w17, w9
    1a74:      	mov	w14, #0x1402            // =5122
    1a78:      	tst	w13, w14
    1a7c:      	b.eq	0x2160 <generic_retkprobe_filter_arg+0x2160>
    1a80:      	cmp	w12, w8
    1a84:      	ldr	x12, [sp, #0x48]
    1a88:      	b.gt	0x2174 <generic_retkprobe_filter_arg+0x2174>
    1a8c:      	cmp	w8, w11
    1a90:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    1a94:      	b	0x2174 <generic_retkprobe_filter_arg+0x2174>
    1a98:      	ldr	w10, [x25]
    1a9c:      	cmp	w11, w10
    1aa0:      	ccmp	w10, w8, #0x2, ls
    1aa4:      	cset	w8, ls
    1aa8:      	ldr	w11, [x21, #0x8]
    1aac:      	cmp	w11, #0x11
    1ab0:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    1ab4:      	ldp	w13, w12, [x21, #0x18]
    1ab8:      	cmp	w9, #0xc
    1abc:      	b.hi	0x1f68 <generic_retkprobe_filter_arg+0x1f68>
    1ac0:      	lsl	w14, w17, w9
    1ac4:      	mov	w15, #0x1402            // =5122
    1ac8:      	tst	w14, w15
    1acc:      	b.eq	0x1f68 <generic_retkprobe_filter_arg+0x1f68>
    1ad0:      	cmp	w13, w10
    1ad4:      	ccmp	w10, w12, #0x0, le
    1ad8:      	cset	w12, le
    1adc:      	b	0x1f74 <generic_retkprobe_filter_arg+0x1f74>
    1ae0:      	str	x23, [sp, #0x28]
    1ae4:      	mov	x19, xzr
    1ae8:      	mov	w22, wzr
    1aec:      	add	x23, x21, #0x10
    1af0:      	ldr	w8, [x23, x19, lsl #2]
    1af4:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1af8:      	add	x9, sp, #0x60
    1afc:      	add	x1, sp, #0x60
    1b00:      	str	w8, [sp, #0x60]
    1b04:      	mov	w8, #0x1                // =1
    1b08:      	ldr	x0, [x0]
    1b0c:      	blr	x8
    1b10:      	cbz	x0, 0x2600 <generic_retkprobe_filter_arg+0x2600>
    1b14:      	ldr	x16, [sp, #0x50]
    1b18:      	mov	w17, #0x1               // =1
    1b1c:      	cbz	w25, 0x1b78 <generic_retkprobe_filter_arg+0x1b78>
    1b20:      	mov	x8, xzr
    1b24:      	mov	x9, x29
    1b28:      	mov	x10, x25
    1b2c:      	b	0x1b44 <generic_retkprobe_filter_arg+0x1b44>
    1b30:      	add	x8, x8, #0x1
    1b34:      	sub	x10, x10, #0x1
    1b38:      	add	x9, x9, #0x1
    1b3c:      	cmp	x8, x25
    1b40:      	b.eq	0x1b78 <generic_retkprobe_filter_arg+0x1b78>
    1b44:      	mov	x11, xzr
    1b48:      	cmp	x10, x11
    1b4c:      	b.eq	0x1b30 <generic_retkprobe_filter_arg+0x1b30>
    1b50:      	ldrb	w12, [x0, x11]
    1b54:      	cbz	w12, 0x1b74 <generic_retkprobe_filter_arg+0x1b74>
    1b58:      	cmp	x11, #0x62
    1b5c:      	b.hi	0x1b30 <generic_retkprobe_filter_arg+0x1b30>
    1b60:      	ldrb	w13, [x9, x11]
    1b64:      	add	x11, x11, #0x1
    1b68:      	cmp	w13, w12
    1b6c:      	b.eq	0x1b48 <generic_retkprobe_filter_arg+0x1b48>
    1b70:      	b	0x1b30 <generic_retkprobe_filter_arg+0x1b30>
    1b74:      	tbz	w8, #0x1f, 0x2a80 <generic_retkprobe_filter_arg+0x2a80>
    1b78:      	ldr	w9, [x21, #0x8]
    1b7c:      	add	w8, w22, #0xc
    1b80:      	cmp	w8, w9
    1b84:      	b.hs	0x1b98 <generic_retkprobe_filter_arg+0x1b98>
    1b88:      	add	x19, x19, #0x1
    1b8c:      	add	w22, w22, #0x4
    1b90:      	cmp	x19, #0x64
    1b94:      	b.ne	0x1af0 <generic_retkprobe_filter_arg+0x1af0>
    1b98:      	ldr	x23, [sp, #0x28]
    1b9c:      	ldr	x12, [sp, #0x48]
    1ba0:      	mov	x22, xzr
    1ba4:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    1ba8:      	and	w8, w25, #0xffff
    1bac:      	cmp	w8, #0x90
    1bb0:      	b.hi	0x21b0 <generic_retkprobe_filter_arg+0x21b0>
    1bb4:      	and	w8, w25, #0xff
    1bb8:      	mov	w9, #0xab               // =171
    1bbc:      	tst	w25, #0xffff
    1bc0:      	mul	w8, w8, w9
    1bc4:      	mov	w9, #0x18               // =24
    1bc8:      	lsr	w8, w8, #12
    1bcc:      	msub	w8, w8, w9, w25
    1bd0:      	b.eq	0x1be4 <generic_retkprobe_filter_arg+0x1be4>
    1bd4:      	tst	w8, #0xff
    1bd8:      	mov	w9, w25
    1bdc:      	mov	w11, w25
    1be0:      	b.eq	0x1c00 <generic_retkprobe_filter_arg+0x1c00>
    1be4:      	sub	w8, w25, w8, uxtb
    1be8:      	and	w9, w8, #0xffff
    1bec:      	add	w8, w8, #0x18
    1bf0:      	and	w11, w8, #0xffff
    1bf4:      	cmp	w9, #0x78
    1bf8:      	b.hi	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    1bfc:      	mov	w9, w11
    1c00:      	and	w8, w9, #0xff
    1c04:      	mov	w9, #0xab               // =171
    1c08:      	mul	w8, w8, w9
    1c0c:      	lsr	w8, w8, #12
    1c10:      	sub	w10, w8, #0x1
    1c14:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    1c18:      	cmp	x13, x10
    1c1c:      	ccmp	x10, x12, #0x2, ls
    1c20:      	cset	w12, ls
    1c24:      	orr	w8, w8, w12
    1c28:      	cmp	w11, #0x29
    1c2c:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    1c30:      	ldp	x13, x12, [x21, #0x30]
    1c34:      	cmp	w9, #0xc
    1c38:      	b.eq	0x1c44 <generic_retkprobe_filter_arg+0x1c44>
    1c3c:      	cmp	w9, #0xa
    1c40:      	b.ne	0x21c0 <generic_retkprobe_filter_arg+0x21c0>
    1c44:      	cmp	x13, x10
    1c48:      	ccmp	x10, x12, #0x0, le
    1c4c:      	cset	w12, le
    1c50:      	b	0x21cc <generic_retkprobe_filter_arg+0x21cc>
    1c54:      	mov	x19, xzr
    1c58:      	cmp	w9, #0x29
    1c5c:      	b.ne	0x1c68 <generic_retkprobe_filter_arg+0x1c68>
    1c60:      	cbz	x10, 0x1c68 <generic_retkprobe_filter_arg+0x1c68>
    1c64:      	ldrb	w19, [x10, #0x3a]
    1c68:      	cmp	w9, #0x29
    1c6c:      	b.eq	0x1c78 <generic_retkprobe_filter_arg+0x1c78>
    1c70:      	cmp	w9, #0x7
    1c74:      	b.ne	0x1fac <generic_retkprobe_filter_arg+0x1fac>
    1c78:      	ldrb	w8, [x21, #0x10]
    1c7c:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1c80:      	add	x9, sp, #0xac
    1c84:      	add	x1, sp, #0xac
    1c88:      	str	w8, [sp, #0xac]
    1c8c:      	mov	w8, #0x1                // =1
    1c90:      	ldr	x0, [x0]
    1c94:      	blr	x8
    1c98:      	cbz	x0, 0x1cd0 <generic_retkprobe_filter_arg+0x1cd0>
    1c9c:      	str	x19, [sp, #0x88]
    1ca0:      	mov	w8, #0x1                // =1
    1ca4:      	add	x9, sp, #0x88
    1ca8:      	add	x1, sp, #0x88
    1cac:      	blr	x8
    1cb0:      	ldr	w9, [x21, #0x4]
    1cb4:      	mov	w8, wzr
    1cb8:      	cmp	w9, #0x1d
    1cbc:      	b.ls	0x15c4 <generic_retkprobe_filter_arg+0x15c4>
    1cc0:      	ldr	x19, [sp, #0x30]
    1cc4:      	ldp	x12, x16, [sp, #0x48]
    1cc8:      	mov	w17, #0x1               // =1
    1ccc:      	b	0x1784 <generic_retkprobe_filter_arg+0x1784>
    1cd0:      	ldr	x19, [sp, #0x30]
    1cd4:      	mov	x22, xzr
    1cd8:      	ldp	x12, x16, [sp, #0x48]
    1cdc:      	mov	w17, #0x1               // =1
    1ce0:      	ldr	x0, [sp, #0x38]
    1ce4:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1ce8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1cec:      	ldp	x23, x19, [sp, #0x28]
    1cf0:      	mov	x22, xzr
    1cf4:      	mov	w17, #0x1               // =1
    1cf8:      	ldr	x16, [sp, #0x50]
    1cfc:      	b	0x1d10 <generic_retkprobe_filter_arg+0x1d10>
    1d00:      	ldr	x16, [sp, #0x50]
    1d04:      	mov	x22, xzr
    1d08:      	mov	w17, #0x1               // =1
    1d0c:      	ldp	x23, x19, [sp, #0x28]
    1d10:      	ldr	x0, [sp, #0x38]
    1d14:      	ldr	x12, [sp, #0x48]
    1d18:      	ldr	w8, [x21, #0x4]
    1d1c:      	cmp	w8, #0x25
    1d20:      	b.hi	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1d24:      	mov	x9, #0x50               // =80
    1d28:      	lsl	x8, x17, x8
    1d2c:      	movk	x9, #0xc00, lsl #16
    1d30:      	movk	x9, #0x20, lsl #32
    1d34:      	tst	x8, x9
    1d38:      	b.ne	0x32f0 <generic_retkprobe_filter_arg+0x32f0>
    1d3c:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1d40:      	cmp	x12, x8
    1d44:      	ldr	x12, [sp, #0x48]
    1d48:      	b.hi	0x1d54 <generic_retkprobe_filter_arg+0x1d54>
    1d4c:      	cmp	x8, x11
    1d50:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    1d54:      	cmp	w10, #0x29
    1d58:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1d5c:      	ldp	x12, x11, [x21, #0x30]
    1d60:      	cmp	w9, #0xc
    1d64:      	b.eq	0x1d70 <generic_retkprobe_filter_arg+0x1d70>
    1d68:      	cmp	w9, #0xa
    1d6c:      	b.ne	0x21fc <generic_retkprobe_filter_arg+0x21fc>
    1d70:      	cmp	x12, x8
    1d74:      	ldr	x12, [sp, #0x48]
    1d78:      	b.gt	0x2210 <generic_retkprobe_filter_arg+0x2210>
    1d7c:      	cmp	x8, x11
    1d80:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    1d84:      	b	0x2210 <generic_retkprobe_filter_arg+0x2210>
    1d88:      	ldr	w8, [x21, #0x4]
    1d8c:      	and	w8, w8, #0xfffffffe
    1d90:      	cmp	w8, #0x18
    1d94:      	cset	w8, eq
    1d98:      	ldr	x0, [sp, #0x38]
    1d9c:      	ldp	x12, x16, [sp, #0x48]
    1da0:      	mov	w17, #0x1               // =1
    1da4:      	mov	w22, w8
    1da8:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1dac:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1db0:      	ldr	w8, [x21, #0x4]
    1db4:      	ldp	x19, x0, [sp, #0x30]
    1db8:      	and	w8, w8, #0xfffffffe
    1dbc:      	cmp	w8, #0x18
    1dc0:      	cset	w8, eq
    1dc4:      	ldp	x12, x16, [sp, #0x48]
    1dc8:      	mov	w17, #0x1               // =1
    1dcc:      	mov	w22, w8
    1dd0:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1dd4:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1dd8:      	ldr	w11, [x25]
    1ddc:      	cmp	w11, w10
    1de0:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    1de4:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
    1de8:      	ldr	w11, [x25]
    1dec:      	cmp	w11, w10
    1df0:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    1df4:      	ldr	w10, [x21, #0x8]
    1df8:      	cmp	w10, #0xd
    1dfc:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    1e00:      	ldr	w11, [x21, #0x14]
    1e04:      	cmp	w8, #0x2
    1e08:      	b.le	0x1e2c <generic_retkprobe_filter_arg+0x1e2c>
    1e0c:      	sub	w12, w8, #0x3
    1e10:      	cmp	w12, #0x2
    1e14:      	b.hs	0x1e68 <generic_retkprobe_filter_arg+0x1e68>
    1e18:      	ldr	w12, [x25]
    1e1c:      	cmp	w12, w11
    1e20:      	ldr	x12, [sp, #0x48]
    1e24:      	b.ne	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e28:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    1e2c:      	cmp	w8, #0x1
    1e30:      	b.eq	0x1e88 <generic_retkprobe_filter_arg+0x1e88>
    1e34:      	cmp	w8, #0x2
    1e38:      	b.ne	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e3c:      	cmp	w9, #0xc
    1e40:      	b.hi	0x26f0 <generic_retkprobe_filter_arg+0x26f0>
    1e44:      	lsl	w12, w17, w9
    1e48:      	mov	w13, #0x1402            // =5122
    1e4c:      	tst	w12, w13
    1e50:      	b.eq	0x26f0 <generic_retkprobe_filter_arg+0x26f0>
    1e54:      	ldr	w12, [x25]
    1e58:      	cmp	w12, w11
    1e5c:      	ldr	x12, [sp, #0x48]
    1e60:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    1e64:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e68:      	ldr	x12, [sp, #0x48]
    1e6c:      	cmp	w8, #0xc
    1e70:      	b.ne	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e74:      	ldr	w12, [x25]
    1e78:      	tst	w12, w11
    1e7c:      	ldr	x12, [sp, #0x48]
    1e80:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1e84:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e88:      	cmp	w9, #0xc
    1e8c:      	b.hi	0x26dc <generic_retkprobe_filter_arg+0x26dc>
    1e90:      	lsl	w12, w17, w9
    1e94:      	mov	w13, #0x1402            // =5122
    1e98:      	tst	w12, w13
    1e9c:      	b.eq	0x26dc <generic_retkprobe_filter_arg+0x26dc>
    1ea0:      	ldr	w12, [x25]
    1ea4:      	cmp	w12, w11
    1ea8:      	ldr	x12, [sp, #0x48]
    1eac:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    1eb0:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1eb4:      	and	w8, w29, #0xffff
    1eb8:      	cmp	w8, #0x201
    1ebc:      	b.hs	0x231c <generic_retkprobe_filter_arg+0x231c>
    1ec0:      	mov	w11, #0x200             // =512
    1ec4:      	b	0x2850 <generic_retkprobe_filter_arg+0x2850>
    1ec8:      	mov	x22, xzr
    1ecc:      	ldr	x19, [sp, #0x30]
    1ed0:      	ldr	w8, [x21, #0x4]
    1ed4:      	cmp	w8, #0x25
    1ed8:      	b.hi	0xf00 <generic_retkprobe_filter_arg+0xf00>
    1edc:      	mov	x9, #0x50               // =80
    1ee0:      	ldr	x0, [sp, #0x38]
    1ee4:      	ldp	x12, x16, [sp, #0x48]
    1ee8:      	mov	w17, #0x1               // =1
    1eec:      	movk	x9, #0xc00, lsl #16
    1ef0:      	lsl	x8, x17, x8
    1ef4:      	movk	x9, #0x20, lsl #32
    1ef8:      	tst	x8, x9
    1efc:      	b.ne	0x2d50 <generic_retkprobe_filter_arg+0x2d50>
    1f00:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1f04:      	cmp	w8, #0x1
    1f08:      	b.eq	0x2588 <generic_retkprobe_filter_arg+0x2588>
    1f0c:      	cmp	w8, #0x2
    1f10:      	b.ne	0x2594 <generic_retkprobe_filter_arg+0x2594>
    1f14:      	ldrb	w11, [x25]
    1f18:      	cmp	w10, w11
    1f1c:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    1f20:      	b	0x2594 <generic_retkprobe_filter_arg+0x2594>
    1f24:      	cmp	w8, #0x1
    1f28:      	b.eq	0x25c4 <generic_retkprobe_filter_arg+0x25c4>
    1f2c:      	cmp	w8, #0x2
    1f30:      	b.ne	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    1f34:      	ldrh	w11, [x25]
    1f38:      	cmp	w10, w11
    1f3c:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    1f40:      	b	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    1f44:      	cmp	w8, #0x401
    1f48:      	b.hs	0x237c <generic_retkprobe_filter_arg+0x237c>
    1f4c:      	mov	w11, #0x400             // =1024
    1f50:      	b	0x2390 <generic_retkprobe_filter_arg+0x2390>
    1f54:      	ldr	x0, [sp, #0x38]
    1f58:      	mov	w8, wzr
    1f5c:      	mov	w22, wzr
    1f60:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1f64:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1f68:      	cmp	w13, w10
    1f6c:      	ccmp	w10, w12, #0x2, ls
    1f70:      	cset	w12, ls
    1f74:      	orr	w8, w8, w12
    1f78:      	cmp	w11, #0x19
    1f7c:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    1f80:      	ldp	w13, w12, [x21, #0x20]
    1f84:      	cmp	w9, #0xc
    1f88:      	b.hi	0x2630 <generic_retkprobe_filter_arg+0x2630>
    1f8c:      	lsl	w14, w17, w9
    1f90:      	mov	w15, #0x1402            // =5122
    1f94:      	tst	w14, w15
    1f98:      	b.eq	0x2630 <generic_retkprobe_filter_arg+0x2630>
    1f9c:      	cmp	w13, w10
    1fa0:      	ccmp	w10, w12, #0x0, le
    1fa4:      	cset	w12, le
    1fa8:      	b	0x263c <generic_retkprobe_filter_arg+0x263c>
    1fac:      	ldr	x19, [sp, #0x30]
    1fb0:      	mov	x22, xzr
    1fb4:      	cbnz	xzr, 0x140 <generic_retkprobe_filter_arg+0x140>
    1fb8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1fbc:      	mov	w11, #0xa               // =10
    1fc0:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    1fc4:      	mov	w11, #0x6               // =6
    1fc8:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    1fcc:      	mov	w11, #0x8               // =8
    1fd0:      	add	x8, x21, #0x10
    1fd4:      	and	w9, w11, #0xf
    1fd8:      	ldr	w8, [x8, w9, uxtw #2]
    1fdc:      	cmn	w8, #0x1
    1fe0:      	b.eq	0x2090 <generic_retkprobe_filter_arg+0x2090>
    1fe4:      	str	w8, [sp, #0x10]
    1fe8:      	stp	w13, w11, [sp, #0x1c]
    1fec:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1ff0:      	mov	w8, #0x1                // =1
    1ff4:      	add	x22, sp, #0x88
    1ff8:      	add	x1, sp, #0x88
    1ffc:      	str	x10, [sp, #0x28]
    2000:      	ldr	x0, [x0]
    2004:      	blr	x8
    2008:      	mov	x25, x0
    200c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2010:      	mov	w8, #0x1                // =1
    2014:      	ldr	x0, [x0]
    2018:      	add	x1, sp, #0x88
    201c:      	blr	x8
    2020:      	mov	x22, xzr
    2024:      	cbz	x25, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    2028:      	mov	x9, x0
    202c:      	ldr	x0, [sp, #0x38]
    2030:      	ldp	x12, x16, [sp, #0x48]
    2034:      	mov	w17, #0x1               // =1
    2038:      	cbz	x9, 0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
    203c:      	mov	x8, x25
    2040:      	ldr	w25, [sp, #0x20]
    2044:      	mov	x22, x9
    2048:      	mov	x0, x8
    204c:      	str	x8, [sp, #0x8]
    2050:      	cmp	w25, #0x5
    2054:      	b.gt	0x20a4 <generic_retkprobe_filter_arg+0x20a4>
    2058:      	strb	w29, [x0], #0x1
    205c:      	ldr	x2, [sp, #0x28]
    2060:      	mov	w8, #0x4                // =4
    2064:      	mov	w1, w29
    2068:      	blr	x8
    206c:      	ldr	w8, [sp, #0x1c]
    2070:      	subs	w8, w8, w29
    2074:      	b.ls	0x20e0 <generic_retkprobe_filter_arg+0x20e0>
    2078:      	ldr	x9, [sp, #0x8]
    207c:      	and	w1, w8, #0xfff
    2080:      	mov	w8, #0x4                // =4
    2084:      	add	x9, x9, x29
    2088:      	add	x0, x9, #0x1
    208c:      	b	0x20d8 <generic_retkprobe_filter_arg+0x20d8>
    2090:      	mov	x22, xzr
    2094:      	ldr	w8, [x21, #0x4]
    2098:      	cmp	w8, #0x25
    209c:      	b.ls	0x2d38 <generic_retkprobe_filter_arg+0x2d38>
    20a0:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    20a4:      	strh	w29, [x0], #0x2
    20a8:      	ldr	x2, [sp, #0x28]
    20ac:      	mov	w8, #0x4                // =4
    20b0:      	mov	w1, w29
    20b4:      	blr	x8
    20b8:      	ldr	w8, [sp, #0x1c]
    20bc:      	subs	w8, w8, w29
    20c0:      	b.ls	0x20e0 <generic_retkprobe_filter_arg+0x20e0>
    20c4:      	ldr	x9, [sp, #0x8]
    20c8:      	and	w1, w8, #0xfff
    20cc:      	mov	w8, #0x4                // =4
    20d0:      	add	x9, x9, x29
    20d4:      	add	x0, x9, #0x2
    20d8:      	mov	x2, x22
    20dc:      	blr	x8
    20e0:      	ldr	w8, [sp, #0x10]
    20e4:      	ldp	x12, x16, [sp, #0x48]
    20e8:      	cmp	w25, #0x4
    20ec:      	mov	w17, #0x1               // =1
    20f0:      	str	w8, [sp, #0x60]
    20f4:      	b.le	0x212c <generic_retkprobe_filter_arg+0x212c>
    20f8:      	cmp	w25, #0x7
    20fc:      	b.gt	0x2350 <generic_retkprobe_filter_arg+0x2350>
    2100:      	cmp	w25, #0x5
    2104:      	b.eq	0x2cd4 <generic_retkprobe_filter_arg+0x2cd4>
    2108:      	cmp	w25, #0x6
    210c:      	b.eq	0x2c98 <generic_retkprobe_filter_arg+0x2c98>
    2110:      	cmp	w25, #0x7
    2114:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    2118:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    211c:      	mov	w8, #0x1                // =1
    2120:      	add	x9, sp, #0x60
    2124:      	ldr	x0, [x0]
    2128:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    212c:      	cmp	w25, #0x1
    2130:      	b.le	0x27c8 <generic_retkprobe_filter_arg+0x27c8>
    2134:      	cmp	w25, #0x2
    2138:      	b.eq	0x2cc0 <generic_retkprobe_filter_arg+0x2cc0>
    213c:      	cmp	w25, #0x3
    2140:      	b.eq	0x2c84 <generic_retkprobe_filter_arg+0x2c84>
    2144:      	cmp	w25, #0x4
    2148:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    214c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2150:      	mov	w8, #0x1                // =1
    2154:      	add	x9, sp, #0x60
    2158:      	ldr	x0, [x0]
    215c:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2160:      	cmp	w12, w8
    2164:      	ldr	x12, [sp, #0x48]
    2168:      	b.hi	0x2174 <generic_retkprobe_filter_arg+0x2174>
    216c:      	cmp	w8, w11
    2170:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    2174:      	cmp	w10, #0x19
    2178:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    217c:      	ldp	w12, w11, [x21, #0x20]
    2180:      	cmp	w9, #0xc
    2184:      	b.hi	0x2690 <generic_retkprobe_filter_arg+0x2690>
    2188:      	lsl	w13, w17, w9
    218c:      	mov	w14, #0x1402            // =5122
    2190:      	tst	w13, w14
    2194:      	b.eq	0x2690 <generic_retkprobe_filter_arg+0x2690>
    2198:      	cmp	w12, w8
    219c:      	ldr	x12, [sp, #0x48]
    21a0:      	b.gt	0x26a4 <generic_retkprobe_filter_arg+0x26a4>
    21a4:      	cmp	w8, w11
    21a8:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    21ac:      	b	0x26a4 <generic_retkprobe_filter_arg+0x26a4>
    21b0:      	cmp	w8, #0x101
    21b4:      	b.hs	0x267c <generic_retkprobe_filter_arg+0x267c>
    21b8:      	mov	w11, #0x100             // =256
    21bc:      	b	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    21c0:      	cmp	x13, x10
    21c4:      	ccmp	x10, x12, #0x2, ls
    21c8:      	cset	w12, ls
    21cc:      	orr	w8, w8, w12
    21d0:      	cmp	w11, #0x39
    21d4:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    21d8:      	ldp	x12, x11, [x21, #0x40]
    21dc:      	cmp	w9, #0xc
    21e0:      	b.eq	0x21ec <generic_retkprobe_filter_arg+0x21ec>
    21e4:      	cmp	w9, #0xa
    21e8:      	b.ne	0x27bc <generic_retkprobe_filter_arg+0x27bc>
    21ec:      	cmp	x12, x10
    21f0:      	ccmp	x10, x11, #0x0, le
    21f4:      	cset	w9, le
    21f8:      	b	0x2a9c <generic_retkprobe_filter_arg+0x2a9c>
    21fc:      	cmp	x12, x8
    2200:      	ldr	x12, [sp, #0x48]
    2204:      	b.hi	0x2210 <generic_retkprobe_filter_arg+0x2210>
    2208:      	cmp	x8, x11
    220c:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    2210:      	cmp	w10, #0x39
    2214:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2218:      	ldp	x11, x10, [x21, #0x40]
    221c:      	cmp	w9, #0xc
    2220:      	b.eq	0x222c <generic_retkprobe_filter_arg+0x222c>
    2224:      	cmp	w9, #0xa
    2228:      	b.ne	0x27e8 <generic_retkprobe_filter_arg+0x27e8>
    222c:      	cmp	x11, x8
    2230:      	b.gt	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2234:      	cmp	x8, x10
    2238:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    223c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2240:      	ldr	x12, [x25]
    2244:      	cmp	x12, x11
    2248:      	ldr	x12, [sp, #0x48]
    224c:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2250:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    2254:      	ldr	x12, [x25]
    2258:      	cmp	x12, x11
    225c:      	ldr	x12, [sp, #0x48]
    2260:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2264:      	cmp	w10, #0x19
    2268:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    226c:      	ldr	x11, [x21, #0x20]
    2270:      	cmp	w8, #0x2
    2274:      	b.le	0x2298 <generic_retkprobe_filter_arg+0x2298>
    2278:      	sub	w12, w8, #0x3
    227c:      	cmp	w12, #0x2
    2280:      	b.hs	0x22cc <generic_retkprobe_filter_arg+0x22cc>
    2284:      	ldr	x12, [x25]
    2288:      	cmp	x12, x11
    228c:      	ldr	x12, [sp, #0x48]
    2290:      	b.ne	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    2294:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2298:      	cmp	w8, #0x1
    229c:      	b.eq	0x232c <generic_retkprobe_filter_arg+0x232c>
    22a0:      	cmp	w8, #0x2
    22a4:      	b.ne	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22a8:      	cmp	w9, #0xc
    22ac:      	b.eq	0x22b8 <generic_retkprobe_filter_arg+0x22b8>
    22b0:      	cmp	w9, #0xa
    22b4:      	b.ne	0x2ac0 <generic_retkprobe_filter_arg+0x2ac0>
    22b8:      	ldr	x12, [x25]
    22bc:      	cmp	x12, x11
    22c0:      	ldr	x12, [sp, #0x48]
    22c4:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    22c8:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22cc:      	ldr	x12, [sp, #0x48]
    22d0:      	cmp	w8, #0xc
    22d4:      	b.ne	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22d8:      	ldr	x12, [x25]
    22dc:      	tst	x12, x11
    22e0:      	ldr	x12, [sp, #0x48]
    22e4:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    22e8:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22ec:      	cmp	w8, #0xc
    22f0:      	b.ne	0x2594 <generic_retkprobe_filter_arg+0x2594>
    22f4:      	ldrb	w11, [x25]
    22f8:      	tst	w10, w11
    22fc:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2300:      	b	0x2594 <generic_retkprobe_filter_arg+0x2594>
    2304:      	cmp	w8, #0xc
    2308:      	b.ne	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    230c:      	ldrh	w11, [x25]
    2310:      	tst	w10, w11
    2314:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2318:      	b	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    231c:      	cmp	w8, #0x401
    2320:      	b.hs	0x283c <generic_retkprobe_filter_arg+0x283c>
    2324:      	mov	w11, #0x400             // =1024
    2328:      	b	0x2850 <generic_retkprobe_filter_arg+0x2850>
    232c:      	cmp	w9, #0xc
    2330:      	b.eq	0x233c <generic_retkprobe_filter_arg+0x233c>
    2334:      	cmp	w9, #0xa
    2338:      	b.ne	0x2aac <generic_retkprobe_filter_arg+0x2aac>
    233c:      	ldr	x12, [x25]
    2340:      	cmp	x12, x11
    2344:      	ldr	x12, [sp, #0x48]
    2348:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    234c:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    2350:      	cmp	w25, #0x8
    2354:      	b.eq	0x2ce8 <generic_retkprobe_filter_arg+0x2ce8>
    2358:      	cmp	w25, #0x9
    235c:      	b.eq	0x2cac <generic_retkprobe_filter_arg+0x2cac>
    2360:      	cmp	w25, #0xa
    2364:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    2368:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    236c:      	mov	w8, #0x1                // =1
    2370:      	add	x9, sp, #0x60
    2374:      	ldr	x0, [x0]
    2378:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    237c:      	and	w8, w29, #0xffff
    2380:      	mov	w9, #0x1000             // =4096
    2384:      	cmp	w8, #0x800
    2388:      	mov	w8, #0x800              // =2048
    238c:      	csel	w11, w9, w8, hi
    2390:      	sub	w8, w11, #0x100
    2394:      	ror	w8, w8, #0x8
    2398:      	cmp	w8, #0x2
    239c:      	b.gt	0x23b4 <generic_retkprobe_filter_arg+0x23b4>
    23a0:      	cbz	w8, 0x23d4 <generic_retkprobe_filter_arg+0x23d4>
    23a4:      	cmp	w8, #0x1
    23a8:      	b.ne	0x23cc <generic_retkprobe_filter_arg+0x23cc>
    23ac:      	mov	w10, #0x7               // =7
    23b0:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23b4:      	cmp	w8, #0x3
    23b8:      	b.eq	0x23dc <generic_retkprobe_filter_arg+0x23dc>
    23bc:      	cmp	w8, #0x7
    23c0:      	b.ne	0x23cc <generic_retkprobe_filter_arg+0x23cc>
    23c4:      	mov	w10, #0x9               // =9
    23c8:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23cc:      	mov	w10, #0xa               // =10
    23d0:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23d4:      	mov	w10, #0x6               // =6
    23d8:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23dc:      	mov	w10, #0x8               // =8
    23e0:      	add	x8, x21, #0x10
    23e4:      	and	w9, w10, #0xf
    23e8:      	ldr	w8, [x8, w9, uxtw #2]
    23ec:      	cmn	w8, #0x1
    23f0:      	b.eq	0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
    23f4:      	str	w8, [sp, #0x10]
    23f8:      	str	w11, [sp, #0x1c]
    23fc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2400:      	mov	w8, #0x1                // =1
    2404:      	add	x22, sp, #0x88
    2408:      	add	x1, sp, #0x88
    240c:      	str	w10, [sp, #0x28]
    2410:      	ldr	x0, [x0]
    2414:      	blr	x8
    2418:      	str	x0, [sp, #0x20]
    241c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2420:      	mov	w8, #0x1                // =1
    2424:      	add	x1, sp, #0x88
    2428:      	ldr	x0, [x0]
    242c:      	blr	x8
    2430:      	ldr	x10, [sp, #0x20]
    2434:      	mov	x22, xzr
    2438:      	cbz	x10, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    243c:      	mov	x9, x0
    2440:      	ldr	x0, [sp, #0x38]
    2444:      	ldp	x12, x16, [sp, #0x48]
    2448:      	mov	w17, #0x1               // =1
    244c:      	cbz	x9, 0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
    2450:      	mov	x22, x9
    2454:      	ldr	w9, [sp, #0x28]
    2458:      	mov	x8, x10
    245c:      	add	x2, x25, #0x4
    2460:      	mov	x25, x10
    2464:      	mov	x0, x8
    2468:      	cmp	w9, #0x5
    246c:      	b.gt	0x24a0 <generic_retkprobe_filter_arg+0x24a0>
    2470:      	strb	w29, [x0], #0x1
    2474:      	mov	w8, #0x4                // =4
    2478:      	mov	w1, w29
    247c:      	blr	x8
    2480:      	ldr	w8, [sp, #0x1c]
    2484:      	subs	w8, w8, w29
    2488:      	b.ls	0x24d4 <generic_retkprobe_filter_arg+0x24d4>
    248c:      	add	x9, x25, x29
    2490:      	and	w1, w8, #0xfff
    2494:      	mov	w8, #0x4                // =4
    2498:      	add	x0, x9, #0x1
    249c:      	b	0x24cc <generic_retkprobe_filter_arg+0x24cc>
    24a0:      	strh	w29, [x0], #0x2
    24a4:      	mov	w8, #0x4                // =4
    24a8:      	mov	w1, w29
    24ac:      	blr	x8
    24b0:      	ldr	w8, [sp, #0x1c]
    24b4:      	subs	w8, w8, w29
    24b8:      	b.ls	0x24d4 <generic_retkprobe_filter_arg+0x24d4>
    24bc:      	add	x9, x25, x29
    24c0:      	and	w1, w8, #0xfff
    24c4:      	mov	w8, #0x4                // =4
    24c8:      	add	x0, x9, #0x2
    24cc:      	mov	x2, x22
    24d0:      	blr	x8
    24d4:      	ldr	w8, [sp, #0x10]
    24d8:      	ldr	x0, [sp, #0x38]
    24dc:      	mov	w17, #0x1               // =1
    24e0:      	str	w8, [sp, #0x60]
    24e4:      	ldr	w8, [sp, #0x28]
    24e8:      	ldp	x12, x16, [sp, #0x48]
    24ec:      	cmp	w8, #0x4
    24f0:      	b.le	0x2528 <generic_retkprobe_filter_arg+0x2528>
    24f4:      	cmp	w8, #0x7
    24f8:      	b.gt	0x255c <generic_retkprobe_filter_arg+0x255c>
    24fc:      	cmp	w8, #0x5
    2500:      	b.eq	0x2be4 <generic_retkprobe_filter_arg+0x2be4>
    2504:      	cmp	w8, #0x6
    2508:      	b.eq	0x2ba8 <generic_retkprobe_filter_arg+0x2ba8>
    250c:      	cmp	w8, #0x7
    2510:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    2514:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2518:      	mov	w8, #0x1                // =1
    251c:      	add	x9, sp, #0x60
    2520:      	ldr	x0, [x0]
    2524:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2528:      	cmp	w8, #0x1
    252c:      	b.le	0x2610 <generic_retkprobe_filter_arg+0x2610>
    2530:      	cmp	w8, #0x2
    2534:      	b.eq	0x2bd0 <generic_retkprobe_filter_arg+0x2bd0>
    2538:      	cmp	w8, #0x3
    253c:      	b.eq	0x2b94 <generic_retkprobe_filter_arg+0x2b94>
    2540:      	cmp	w8, #0x4
    2544:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    2548:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    254c:      	mov	w8, #0x1                // =1
    2550:      	add	x9, sp, #0x60
    2554:      	ldr	x0, [x0]
    2558:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    255c:      	cmp	w8, #0x8
    2560:      	b.eq	0x2bf8 <generic_retkprobe_filter_arg+0x2bf8>
    2564:      	cmp	w8, #0x9
    2568:      	b.eq	0x2bbc <generic_retkprobe_filter_arg+0x2bbc>
    256c:      	cmp	w8, #0xa
    2570:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    2574:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2578:      	mov	w8, #0x1                // =1
    257c:      	add	x9, sp, #0x60
    2580:      	ldr	x0, [x0]
    2584:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2588:      	ldrb	w11, [x25]
    258c:      	cmp	w10, w11
    2590:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2594:      	cmp	w9, #0x11
    2598:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    259c:      	ldr	w10, [x21, #0x18]
    25a0:      	cmp	w8, #0x2
    25a4:      	b.le	0x27fc <generic_retkprobe_filter_arg+0x27fc>
    25a8:      	sub	w11, w8, #0x3
    25ac:      	cmp	w11, #0x2
    25b0:      	b.hs	0x2b50 <generic_retkprobe_filter_arg+0x2b50>
    25b4:      	ldrb	w11, [x25]
    25b8:      	cmp	w10, w11
    25bc:      	b.ne	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    25c0:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    25c4:      	ldrh	w11, [x25]
    25c8:      	cmp	w10, w11
    25cc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    25d0:      	cmp	w9, #0x11
    25d4:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    25d8:      	ldr	w10, [x21, #0x18]
    25dc:      	cmp	w8, #0x2
    25e0:      	b.le	0x281c <generic_retkprobe_filter_arg+0x281c>
    25e4:      	sub	w11, w8, #0x3
    25e8:      	cmp	w11, #0x2
    25ec:      	b.hs	0x2b68 <generic_retkprobe_filter_arg+0x2b68>
    25f0:      	ldrh	w11, [x25]
    25f4:      	cmp	w10, w11
    25f8:      	b.ne	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    25fc:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2600:      	ldr	x23, [sp, #0x28]
    2604:      	ldp	x12, x16, [sp, #0x48]
    2608:      	mov	x22, xzr
    260c:      	b	0x32c0 <generic_retkprobe_filter_arg+0x32c0>
    2610:      	cbz	w8, 0x2b80 <generic_retkprobe_filter_arg+0x2b80>
    2614:      	cmp	w8, #0x1
    2618:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    261c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2620:      	mov	w8, #0x1                // =1
    2624:      	add	x9, sp, #0x60
    2628:      	ldr	x0, [x0]
    262c:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2630:      	cmp	w13, w10
    2634:      	ccmp	w10, w12, #0x2, ls
    2638:      	cset	w12, ls
    263c:      	orr	w8, w8, w12
    2640:      	cmp	w11, #0x21
    2644:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    2648:      	ldp	w12, w11, [x21, #0x28]
    264c:      	cmp	w9, #0xc
    2650:      	b.hi	0x2a90 <generic_retkprobe_filter_arg+0x2a90>
    2654:      	lsl	w9, w17, w9
    2658:      	mov	w13, #0x1402            // =5122
    265c:      	tst	w9, w13
    2660:      	b.eq	0x2a90 <generic_retkprobe_filter_arg+0x2a90>
    2664:      	cmp	w12, w10
    2668:      	ccmp	w10, w11, #0x0, le
    266c:      	cset	w9, le
    2670:      	b	0x2a9c <generic_retkprobe_filter_arg+0x2a9c>
    2674:      	mov	w22, #0x1               // =1
    2678:      	b	0x32bc <generic_retkprobe_filter_arg+0x32bc>
    267c:      	and	w8, w25, #0xffff
    2680:      	cmp	w8, #0x201
    2684:      	b.hs	0x2c2c <generic_retkprobe_filter_arg+0x2c2c>
    2688:      	mov	w11, #0x200             // =512
    268c:      	b	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    2690:      	cmp	w12, w8
    2694:      	ldr	x12, [sp, #0x48]
    2698:      	b.hi	0x26a4 <generic_retkprobe_filter_arg+0x26a4>
    269c:      	cmp	w8, w11
    26a0:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    26a4:      	cmp	w10, #0x21
    26a8:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    26ac:      	ldp	w11, w10, [x21, #0x28]
    26b0:      	cmp	w9, #0xc
    26b4:      	b.hi	0x2c3c <generic_retkprobe_filter_arg+0x2c3c>
    26b8:      	lsl	w9, w17, w9
    26bc:      	mov	w13, #0x1402            // =5122
    26c0:      	tst	w9, w13
    26c4:      	b.eq	0x2c3c <generic_retkprobe_filter_arg+0x2c3c>
    26c8:      	cmp	w11, w8
    26cc:      	b.gt	0xc4 <generic_retkprobe_filter_arg+0xc4>
    26d0:      	cmp	w8, w10
    26d4:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    26d8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    26dc:      	ldr	w12, [x25]
    26e0:      	cmp	w12, w11
    26e4:      	ldr	x12, [sp, #0x48]
    26e8:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    26ec:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    26f0:      	ldr	w12, [x25]
    26f4:      	cmp	w12, w11
    26f8:      	ldr	x12, [sp, #0x48]
    26fc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2700:      	cmp	w10, #0x11
    2704:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2708:      	ldr	w11, [x21, #0x18]
    270c:      	cmp	w8, #0x2
    2710:      	b.le	0x2734 <generic_retkprobe_filter_arg+0x2734>
    2714:      	sub	w12, w8, #0x3
    2718:      	cmp	w12, #0x2
    271c:      	b.hs	0x2770 <generic_retkprobe_filter_arg+0x2770>
    2720:      	ldr	w12, [x25]
    2724:      	cmp	w12, w11
    2728:      	ldr	x12, [sp, #0x48]
    272c:      	b.ne	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2730:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2734:      	cmp	w8, #0x1
    2738:      	b.eq	0x2790 <generic_retkprobe_filter_arg+0x2790>
    273c:      	cmp	w8, #0x2
    2740:      	b.ne	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2744:      	cmp	w9, #0xc
    2748:      	b.hi	0x2ed0 <generic_retkprobe_filter_arg+0x2ed0>
    274c:      	lsl	w12, w17, w9
    2750:      	mov	w13, #0x1402            // =5122
    2754:      	tst	w12, w13
    2758:      	b.eq	0x2ed0 <generic_retkprobe_filter_arg+0x2ed0>
    275c:      	ldr	w12, [x25]
    2760:      	cmp	w12, w11
    2764:      	ldr	x12, [sp, #0x48]
    2768:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    276c:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2770:      	ldr	x12, [sp, #0x48]
    2774:      	cmp	w8, #0xc
    2778:      	b.ne	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    277c:      	ldr	w12, [x25]
    2780:      	tst	w12, w11
    2784:      	ldr	x12, [sp, #0x48]
    2788:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    278c:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2790:      	cmp	w9, #0xc
    2794:      	b.hi	0x2ebc <generic_retkprobe_filter_arg+0x2ebc>
    2798:      	lsl	w12, w17, w9
    279c:      	mov	w13, #0x1402            // =5122
    27a0:      	tst	w12, w13
    27a4:      	b.eq	0x2ebc <generic_retkprobe_filter_arg+0x2ebc>
    27a8:      	ldr	w12, [x25]
    27ac:      	cmp	w12, w11
    27b0:      	ldr	x12, [sp, #0x48]
    27b4:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    27b8:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    27bc:      	cmp	x12, x10
    27c0:      	ccmp	x10, x11, #0x2, ls
    27c4:      	b	0x2a98 <generic_retkprobe_filter_arg+0x2a98>
    27c8:      	cbz	w25, 0x2c70 <generic_retkprobe_filter_arg+0x2c70>
    27cc:      	cmp	w25, #0x1
    27d0:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    27d4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    27d8:      	mov	w8, #0x1                // =1
    27dc:      	add	x9, sp, #0x60
    27e0:      	ldr	x0, [x0]
    27e4:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    27e8:      	cmp	x11, x8
    27ec:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
    27f0:      	cmp	x8, x10
    27f4:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    27f8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    27fc:      	cmp	w8, #0x1
    2800:      	b.eq	0x2e34 <generic_retkprobe_filter_arg+0x2e34>
    2804:      	cmp	w8, #0x2
    2808:      	b.ne	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    280c:      	ldrb	w11, [x25]
    2810:      	cmp	w10, w11
    2814:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2818:      	b	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    281c:      	cmp	w8, #0x1
    2820:      	b.eq	0x2e78 <generic_retkprobe_filter_arg+0x2e78>
    2824:      	cmp	w8, #0x2
    2828:      	b.ne	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    282c:      	ldrh	w11, [x25]
    2830:      	cmp	w10, w11
    2834:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2838:      	b	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    283c:      	and	w8, w29, #0xffff
    2840:      	mov	w9, #0x1000             // =4096
    2844:      	cmp	w8, #0x800
    2848:      	mov	w8, #0x800              // =2048
    284c:      	csel	w11, w9, w8, hi
    2850:      	sub	w8, w11, #0x100
    2854:      	ror	w8, w8, #0x8
    2858:      	cmp	w8, #0x2
    285c:      	b.gt	0x2874 <generic_retkprobe_filter_arg+0x2874>
    2860:      	cbz	w8, 0x2894 <generic_retkprobe_filter_arg+0x2894>
    2864:      	cmp	w8, #0x1
    2868:      	b.ne	0x288c <generic_retkprobe_filter_arg+0x288c>
    286c:      	mov	w10, #0x7               // =7
    2870:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    2874:      	cmp	w8, #0x3
    2878:      	b.eq	0x289c <generic_retkprobe_filter_arg+0x289c>
    287c:      	cmp	w8, #0x7
    2880:      	b.ne	0x288c <generic_retkprobe_filter_arg+0x288c>
    2884:      	mov	w10, #0x9               // =9
    2888:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    288c:      	mov	w10, #0xa               // =10
    2890:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    2894:      	mov	w10, #0x6               // =6
    2898:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    289c:      	mov	w10, #0x8               // =8
    28a0:      	add	x8, x21, #0x10
    28a4:      	and	w9, w10, #0xf
    28a8:      	ldr	w8, [x8, w9, uxtw #2]
    28ac:      	cmn	w8, #0x1
    28b0:      	b.eq	0x2964 <generic_retkprobe_filter_arg+0x2964>
    28b4:      	str	w8, [sp, #0x1c]
    28b8:      	str	w11, [sp, #0x10]
    28bc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    28c0:      	mov	w8, #0x1                // =1
    28c4:      	add	x22, sp, #0x88
    28c8:      	add	x1, sp, #0x88
    28cc:      	str	w10, [sp, #0x28]
    28d0:      	ldr	x0, [x0]
    28d4:      	blr	x8
    28d8:      	str	x0, [sp, #0x20]
    28dc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    28e0:      	mov	w8, #0x1                // =1
    28e4:      	add	x1, sp, #0x88
    28e8:      	ldr	x0, [x0]
    28ec:      	blr	x8
    28f0:      	ldr	x10, [sp, #0x20]
    28f4:      	mov	x22, xzr
    28f8:      	cbz	x10, 0x1314 <generic_retkprobe_filter_arg+0x1314>
    28fc:      	mov	x9, x0
    2900:      	ldr	x0, [sp, #0x38]
    2904:      	ldp	x12, x16, [sp, #0x48]
    2908:      	mov	w17, #0x1               // =1
    290c:      	cbz	x9, 0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    2910:      	mov	x22, x9
    2914:      	ldr	w9, [sp, #0x28]
    2918:      	mov	x8, x10
    291c:      	cmp	w9, #0x5
    2920:      	b.gt	0x296c <generic_retkprobe_filter_arg+0x296c>
    2924:      	mov	x0, x8
    2928:      	mov	x9, x8
    292c:      	mov	w8, #0x4                // =4
    2930:      	mov	w1, w29
    2934:      	mov	x2, x25
    2938:      	strb	w29, [x0], #0x1
    293c:      	mov	x25, x9
    2940:      	blr	x8
    2944:      	ldr	w8, [sp, #0x10]
    2948:      	subs	w8, w8, w29
    294c:      	b.ls	0x29b0 <generic_retkprobe_filter_arg+0x29b0>
    2950:      	add	x9, x25, x29
    2954:      	and	w1, w8, #0xfff
    2958:      	mov	w8, #0x4                // =4
    295c:      	add	x0, x9, #0x1
    2960:      	b	0x29a8 <generic_retkprobe_filter_arg+0x29a8>
    2964:      	mov	x22, xzr
    2968:      	b	0x131c <generic_retkprobe_filter_arg+0x131c>
    296c:      	mov	x0, x8
    2970:      	mov	x9, x8
    2974:      	mov	w8, #0x4                // =4
    2978:      	mov	w1, w29
    297c:      	mov	x2, x25
    2980:      	strh	w29, [x0], #0x2
    2984:      	mov	x25, x9
    2988:      	blr	x8
    298c:      	ldr	w8, [sp, #0x10]
    2990:      	subs	w8, w8, w29
    2994:      	b.ls	0x29b0 <generic_retkprobe_filter_arg+0x29b0>
    2998:      	add	x9, x25, x29
    299c:      	and	w1, w8, #0xfff
    29a0:      	mov	w8, #0x4                // =4
    29a4:      	add	x0, x9, #0x2
    29a8:      	mov	x2, x22
    29ac:      	blr	x8
    29b0:      	ldr	w8, [sp, #0x1c]
    29b4:      	ldp	x12, x16, [sp, #0x48]
    29b8:      	mov	w17, #0x1               // =1
    29bc:      	str	w8, [sp, #0x60]
    29c0:      	ldr	w8, [sp, #0x28]
    29c4:      	cmp	w8, #0x4
    29c8:      	b.le	0x2a00 <generic_retkprobe_filter_arg+0x2a00>
    29cc:      	cmp	w8, #0x7
    29d0:      	b.gt	0x2a34 <generic_retkprobe_filter_arg+0x2a34>
    29d4:      	cmp	w8, #0x5
    29d8:      	b.eq	0x2dd8 <generic_retkprobe_filter_arg+0x2dd8>
    29dc:      	cmp	w8, #0x6
    29e0:      	b.eq	0x2d9c <generic_retkprobe_filter_arg+0x2d9c>
    29e4:      	cmp	w8, #0x7
    29e8:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    29ec:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    29f0:      	mov	w8, #0x1                // =1
    29f4:      	add	x9, sp, #0x60
    29f8:      	ldr	x0, [x0]
    29fc:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a00:      	cmp	w8, #0x1
    2a04:      	b.le	0x2a60 <generic_retkprobe_filter_arg+0x2a60>
    2a08:      	cmp	w8, #0x2
    2a0c:      	b.eq	0x2dc4 <generic_retkprobe_filter_arg+0x2dc4>
    2a10:      	cmp	w8, #0x3
    2a14:      	b.eq	0x2d88 <generic_retkprobe_filter_arg+0x2d88>
    2a18:      	cmp	w8, #0x4
    2a1c:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    2a20:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2a24:      	mov	w8, #0x1                // =1
    2a28:      	add	x9, sp, #0x60
    2a2c:      	ldr	x0, [x0]
    2a30:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a34:      	cmp	w8, #0x8
    2a38:      	b.eq	0x2dec <generic_retkprobe_filter_arg+0x2dec>
    2a3c:      	cmp	w8, #0x9
    2a40:      	b.eq	0x2db0 <generic_retkprobe_filter_arg+0x2db0>
    2a44:      	cmp	w8, #0xa
    2a48:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    2a4c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2a50:      	mov	w8, #0x1                // =1
    2a54:      	add	x9, sp, #0x60
    2a58:      	ldr	x0, [x0]
    2a5c:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a60:      	cbz	w8, 0x2d74 <generic_retkprobe_filter_arg+0x2d74>
    2a64:      	cmp	w8, #0x1
    2a68:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    2a6c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2a70:      	mov	w8, #0x1                // =1
    2a74:      	add	x9, sp, #0x60
    2a78:      	ldr	x0, [x0]
    2a7c:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a80:      	ldr	x23, [sp, #0x28]
    2a84:      	ldr	x12, [sp, #0x48]
    2a88:      	mov	w22, #0x1               // =1
    2a8c:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    2a90:      	cmp	w12, w10
    2a94:      	ccmp	w10, w11, #0x2, ls
    2a98:      	cset	w9, ls
    2a9c:      	orr	w8, w8, w9
    2aa0:      	ldr	x12, [sp, #0x48]
    2aa4:      	tbz	w8, #0x0, 0x140 <generic_retkprobe_filter_arg+0x140>
    2aa8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2aac:      	ldr	x12, [x25]
    2ab0:      	cmp	x12, x11
    2ab4:      	ldr	x12, [sp, #0x48]
    2ab8:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2abc:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    2ac0:      	ldr	x12, [x25]
    2ac4:      	cmp	x12, x11
    2ac8:      	ldr	x12, [sp, #0x48]
    2acc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2ad0:      	cmp	w10, #0x21
    2ad4:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2ad8:      	ldr	x10, [x21, #0x28]
    2adc:      	cmp	w8, #0x2
    2ae0:      	b.le	0x2b10 <generic_retkprobe_filter_arg+0x2b10>
    2ae4:      	sub	w9, w8, #0x3
    2ae8:      	cmp	w9, #0x2
    2aec:      	b.lo	0x2b40 <generic_retkprobe_filter_arg+0x2b40>
    2af0:      	cmp	w8, #0x6
    2af4:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2af8:      	cmp	w8, #0xc
    2afc:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2b00:      	ldr	x9, [x25]
    2b04:      	tst	x9, x10
    2b08:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2b0c:      	b	0x124 <generic_retkprobe_filter_arg+0x124>
    2b10:      	cmp	w8, #0x1
    2b14:      	b.eq	0x2c50 <generic_retkprobe_filter_arg+0x2c50>
    2b18:      	cmp	w8, #0x2
    2b1c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2b20:      	cmp	w9, #0xc
    2b24:      	b.eq	0x2b30 <generic_retkprobe_filter_arg+0x2b30>
    2b28:      	cmp	w9, #0xa
    2b2c:      	b.ne	0x31ec <generic_retkprobe_filter_arg+0x31ec>
    2b30:      	ldr	x9, [x25]
    2b34:      	cmp	x9, x10
    2b38:      	b.ge	0x124 <generic_retkprobe_filter_arg+0x124>
    2b3c:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2b40:      	ldr	x9, [x25]
    2b44:      	cmp	x9, x10
    2b48:      	b.eq	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2b4c:      	b	0x124 <generic_retkprobe_filter_arg+0x124>
    2b50:      	cmp	w8, #0xc
    2b54:      	b.ne	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    2b58:      	ldrb	w11, [x25]
    2b5c:      	tst	w10, w11
    2b60:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2b64:      	b	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    2b68:      	cmp	w8, #0xc
    2b6c:      	b.ne	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    2b70:      	ldrh	w11, [x25]
    2b74:      	tst	w10, w11
    2b78:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2b7c:      	b	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    2b80:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2b84:      	mov	w8, #0x1                // =1
    2b88:      	add	x9, sp, #0x60
    2b8c:      	ldr	x0, [x0]
    2b90:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2b94:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2b98:      	mov	w8, #0x1                // =1
    2b9c:      	add	x9, sp, #0x60
    2ba0:      	ldr	x0, [x0]
    2ba4:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2ba8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bac:      	mov	w8, #0x1                // =1
    2bb0:      	add	x9, sp, #0x60
    2bb4:      	ldr	x0, [x0]
    2bb8:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2bbc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bc0:      	mov	w8, #0x1                // =1
    2bc4:      	add	x9, sp, #0x60
    2bc8:      	ldr	x0, [x0]
    2bcc:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2bd0:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bd4:      	mov	w8, #0x1                // =1
    2bd8:      	add	x9, sp, #0x60
    2bdc:      	ldr	x0, [x0]
    2be0:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2be4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2be8:      	mov	w8, #0x1                // =1
    2bec:      	add	x9, sp, #0x60
    2bf0:      	ldr	x0, [x0]
    2bf4:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2bf8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bfc:      	mov	w8, #0x1                // =1
    2c00:      	add	x9, sp, #0x60
    2c04:      	ldr	x0, [x0]
    2c08:      	add	x1, sp, #0x60
    2c0c:      	blr	x8
    2c10:      	cbz	x0, 0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
    2c14:      	mov	w8, #0x1                // =1
    2c18:      	mov	x1, x25
    2c1c:      	blr	x8
    2c20:      	cmp	x0, #0x0
    2c24:      	cset	w22, ne
    2c28:      	b	0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    2c2c:      	cmp	w8, #0x401
    2c30:      	b.hs	0x2f88 <generic_retkprobe_filter_arg+0x2f88>
    2c34:      	mov	w11, #0x400             // =1024
    2c38:      	b	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    2c3c:      	cmp	w11, w8
    2c40:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2c44:      	cmp	w8, w10
    2c48:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    2c4c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2c50:      	cmp	w9, #0xc
    2c54:      	b.eq	0x2c60 <generic_retkprobe_filter_arg+0x2c60>
    2c58:      	cmp	w9, #0xa
    2c5c:      	b.ne	0x31fc <generic_retkprobe_filter_arg+0x31fc>
    2c60:      	ldr	x9, [x25]
    2c64:      	cmp	x9, x10
    2c68:      	b.le	0x124 <generic_retkprobe_filter_arg+0x124>
    2c6c:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2c70:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2c74:      	mov	w8, #0x1                // =1
    2c78:      	add	x9, sp, #0x60
    2c7c:      	ldr	x0, [x0]
    2c80:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2c84:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2c88:      	mov	w8, #0x1                // =1
    2c8c:      	add	x9, sp, #0x60
    2c90:      	ldr	x0, [x0]
    2c94:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2c98:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2c9c:      	mov	w8, #0x1                // =1
    2ca0:      	add	x9, sp, #0x60
    2ca4:      	ldr	x0, [x0]
    2ca8:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2cac:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cb0:      	mov	w8, #0x1                // =1
    2cb4:      	add	x9, sp, #0x60
    2cb8:      	ldr	x0, [x0]
    2cbc:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2cc0:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cc4:      	mov	w8, #0x1                // =1
    2cc8:      	add	x9, sp, #0x60
    2ccc:      	ldr	x0, [x0]
    2cd0:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2cd4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cd8:      	mov	w8, #0x1                // =1
    2cdc:      	add	x9, sp, #0x60
    2ce0:      	ldr	x0, [x0]
    2ce4:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2ce8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cec:      	mov	w8, #0x1                // =1
    2cf0:      	add	x9, sp, #0x60
    2cf4:      	ldr	x0, [x0]
    2cf8:      	add	x1, sp, #0x60
    2cfc:      	blr	x8
    2d00:      	cbz	x0, 0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
    2d04:      	ldr	x1, [sp, #0x8]
    2d08:      	mov	w8, #0x1                // =1
    2d0c:      	blr	x8
    2d10:      	cmp	x0, #0x0
    2d14:      	cset	w22, ne
    2d18:      	b	0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    2d1c:      	mov	x22, xzr
    2d20:      	ldr	x0, [sp, #0x38]
    2d24:      	ldp	x12, x16, [sp, #0x48]
    2d28:      	mov	w17, #0x1               // =1
    2d2c:      	ldr	w8, [x21, #0x4]
    2d30:      	cmp	w8, #0x25
    2d34:      	b.hi	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    2d38:      	mov	x9, #0x50               // =80
    2d3c:      	lsl	x8, x17, x8
    2d40:      	movk	x9, #0xc00, lsl #16
    2d44:      	movk	x9, #0x20, lsl #32
    2d48:      	tst	x8, x9
    2d4c:      	b.eq	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    2d50:      	eor	x22, x22, #0x1
    2d54:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    2d58:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2d5c:      	ldr	x0, [sp, #0x38]
    2d60:      	mov	x22, xzr
    2d64:      	ldr	w8, [x21, #0x4]
    2d68:      	cmp	w8, #0x25
    2d6c:      	b.ls	0x2d38 <generic_retkprobe_filter_arg+0x2d38>
    2d70:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    2d74:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2d78:      	mov	w8, #0x1                // =1
    2d7c:      	add	x9, sp, #0x60
    2d80:      	ldr	x0, [x0]
    2d84:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2d88:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2d8c:      	mov	w8, #0x1                // =1
    2d90:      	add	x9, sp, #0x60
    2d94:      	ldr	x0, [x0]
    2d98:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2d9c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2da0:      	mov	w8, #0x1                // =1
    2da4:      	add	x9, sp, #0x60
    2da8:      	ldr	x0, [x0]
    2dac:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2db0:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2db4:      	mov	w8, #0x1                // =1
    2db8:      	add	x9, sp, #0x60
    2dbc:      	ldr	x0, [x0]
    2dc0:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2dc4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2dc8:      	mov	w8, #0x1                // =1
    2dcc:      	add	x9, sp, #0x60
    2dd0:      	ldr	x0, [x0]
    2dd4:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2dd8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2ddc:      	mov	w8, #0x1                // =1
    2de0:      	add	x9, sp, #0x60
    2de4:      	ldr	x0, [x0]
    2de8:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2dec:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2df0:      	mov	w8, #0x1                // =1
    2df4:      	add	x9, sp, #0x60
    2df8:      	ldr	x0, [x0]
    2dfc:      	add	x1, sp, #0x60
    2e00:      	blr	x8
    2e04:      	cbz	x0, 0x2e20 <generic_retkprobe_filter_arg+0x2e20>
    2e08:      	mov	w8, #0x1                // =1
    2e0c:      	mov	x1, x25
    2e10:      	blr	x8
    2e14:      	cmp	x0, #0x0
    2e18:      	cset	w22, ne
    2e1c:      	b	0x1314 <generic_retkprobe_filter_arg+0x1314>
    2e20:      	mov	x22, xzr
    2e24:      	b	0x1314 <generic_retkprobe_filter_arg+0x1314>
    2e28:      	ldr	x0, [sp, #0x38]
    2e2c:      	mov	x22, xzr
    2e30:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    2e34:      	ldrb	w11, [x25]
    2e38:      	cmp	w10, w11
    2e3c:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2e40:      	cmp	w9, #0x15
    2e44:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2e48:      	ldr	w9, [x21, #0x1c]
    2e4c:      	cmp	w8, #0x2
    2e50:      	b.le	0x3198 <generic_retkprobe_filter_arg+0x3198>
    2e54:      	sub	w10, w8, #0x3
    2e58:      	cmp	w10, #0x2
    2e5c:      	b.lo	0x31c8 <generic_retkprobe_filter_arg+0x31c8>
    2e60:      	cmp	w8, #0x6
    2e64:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2e68:      	cmp	w8, #0xc
    2e6c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2e70:      	ldrb	w10, [x25]
    2e74:      	b	0x2f14 <generic_retkprobe_filter_arg+0x2f14>
    2e78:      	ldrh	w11, [x25]
    2e7c:      	cmp	w10, w11
    2e80:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2e84:      	cmp	w9, #0x15
    2e88:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2e8c:      	ldr	w9, [x21, #0x1c]
    2e90:      	cmp	w8, #0x2
    2e94:      	b.le	0x31b0 <generic_retkprobe_filter_arg+0x31b0>
    2e98:      	sub	w10, w8, #0x3
    2e9c:      	cmp	w10, #0x2
    2ea0:      	b.lo	0x31d0 <generic_retkprobe_filter_arg+0x31d0>
    2ea4:      	cmp	w8, #0x6
    2ea8:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2eac:      	cmp	w8, #0xc
    2eb0:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2eb4:      	ldrh	w10, [x25]
    2eb8:      	b	0x2f14 <generic_retkprobe_filter_arg+0x2f14>
    2ebc:      	ldr	w12, [x25]
    2ec0:      	cmp	w12, w11
    2ec4:      	ldr	x12, [sp, #0x48]
    2ec8:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2ecc:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2ed0:      	ldr	w12, [x25]
    2ed4:      	cmp	w12, w11
    2ed8:      	ldr	x12, [sp, #0x48]
    2edc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2ee0:      	cmp	w10, #0x15
    2ee4:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2ee8:      	ldr	w10, [x21, #0x1c]
    2eec:      	cmp	w8, #0x2
    2ef0:      	b.le	0x2f20 <generic_retkprobe_filter_arg+0x2f20>
    2ef4:      	sub	w9, w8, #0x3
    2ef8:      	cmp	w9, #0x2
    2efc:      	b.lo	0x2f58 <generic_retkprobe_filter_arg+0x2f58>
    2f00:      	cmp	w8, #0x6
    2f04:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2f08:      	cmp	w8, #0xc
    2f0c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2f10:      	ldr	w9, [x25]
    2f14:      	tst	w9, w10
    2f18:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2f1c:      	b	0x124 <generic_retkprobe_filter_arg+0x124>
    2f20:      	cmp	w8, #0x1
    2f24:      	b.eq	0x2f60 <generic_retkprobe_filter_arg+0x2f60>
    2f28:      	cmp	w8, #0x2
    2f2c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2f30:      	cmp	w9, #0xc
    2f34:      	b.hi	0x331c <generic_retkprobe_filter_arg+0x331c>
    2f38:      	lsl	w9, w17, w9
    2f3c:      	mov	w11, #0x1402            // =5122
    2f40:      	tst	w9, w11
    2f44:      	b.eq	0x331c <generic_retkprobe_filter_arg+0x331c>
    2f48:      	ldr	w9, [x25]
    2f4c:      	cmp	w9, w10
    2f50:      	b.ge	0x124 <generic_retkprobe_filter_arg+0x124>
    2f54:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2f58:      	ldr	w9, [x25]
    2f5c:      	b	0x31d4 <generic_retkprobe_filter_arg+0x31d4>
    2f60:      	cmp	w9, #0xc
    2f64:      	b.hi	0x332c <generic_retkprobe_filter_arg+0x332c>
    2f68:      	lsl	w9, w17, w9
    2f6c:      	mov	w11, #0x1402            // =5122
    2f70:      	tst	w9, w11
    2f74:      	b.eq	0x332c <generic_retkprobe_filter_arg+0x332c>
    2f78:      	ldr	w9, [x25]
    2f7c:      	cmp	w9, w10
    2f80:      	b.le	0x124 <generic_retkprobe_filter_arg+0x124>
    2f84:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2f88:      	and	w8, w25, #0xffff
    2f8c:      	mov	w9, #0x1000             // =4096
    2f90:      	cmp	w8, #0x800
    2f94:      	mov	w8, #0x800              // =2048
    2f98:      	csel	w11, w9, w8, hi
    2f9c:      	sub	w8, w11, #0x100
    2fa0:      	ror	w8, w8, #0x8
    2fa4:      	cmp	w8, #0x2
    2fa8:      	b.gt	0x2fc0 <generic_retkprobe_filter_arg+0x2fc0>
    2fac:      	cbz	w8, 0x2fe0 <generic_retkprobe_filter_arg+0x2fe0>
    2fb0:      	cmp	w8, #0x1
    2fb4:      	b.ne	0x2fd8 <generic_retkprobe_filter_arg+0x2fd8>
    2fb8:      	mov	w10, #0x7               // =7
    2fbc:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fc0:      	cmp	w8, #0x3
    2fc4:      	b.eq	0x2fe8 <generic_retkprobe_filter_arg+0x2fe8>
    2fc8:      	cmp	w8, #0x7
    2fcc:      	b.ne	0x2fd8 <generic_retkprobe_filter_arg+0x2fd8>
    2fd0:      	mov	w10, #0x9               // =9
    2fd4:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fd8:      	mov	w10, #0xa               // =10
    2fdc:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fe0:      	mov	w10, #0x6               // =6
    2fe4:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fe8:      	mov	w10, #0x8               // =8
    2fec:      	add	x8, x21, #0x10
    2ff0:      	and	w9, w10, #0xf
    2ff4:      	ldr	w8, [x8, w9, uxtw #2]
    2ff8:      	cmn	w8, #0x1
    2ffc:      	b.eq	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3000:      	stp	w8, w11, [sp, #0x1c]
    3004:      	str	w10, [sp, #0x28]
    3008:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    300c:      	mov	w8, #0x1                // =1
    3010:      	add	x19, sp, #0x88
    3014:      	add	x1, sp, #0x88
    3018:      	ldr	x0, [x0]
    301c:      	blr	x8
    3020:      	mov	x9, x0
    3024:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3028:      	mov	w8, #0x1                // =1
    302c:      	ldr	x0, [x0]
    3030:      	add	x1, sp, #0x88
    3034:      	mov	x19, x9
    3038:      	blr	x8
    303c:      	mov	x22, xzr
    3040:      	cbz	x19, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
    3044:      	ldp	x12, x16, [sp, #0x48]
    3048:      	mov	w17, #0x1               // =1
    304c:      	cbz	x0, 0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    3050:      	ldr	w22, [sp, #0x28]
    3054:      	str	x0, [sp, #0x10]
    3058:      	mov	x0, x19
    305c:      	cmp	w22, #0x5
    3060:      	b.gt	0x309c <generic_retkprobe_filter_arg+0x309c>
    3064:      	strb	w25, [x0], #0x1
    3068:      	mov	w8, #0x4                // =4
    306c:      	mov	w1, w25
    3070:      	mov	x2, x29
    3074:      	blr	x8
    3078:      	ldr	w8, [sp, #0x20]
    307c:      	subs	w8, w8, w25
    3080:      	b.ls	0x30d4 <generic_retkprobe_filter_arg+0x30d4>
    3084:      	add	x9, x19, x25
    3088:      	and	w1, w8, #0xfff
    308c:      	mov	w8, #0x4                // =4
    3090:      	ldr	x2, [sp, #0x10]
    3094:      	add	x0, x9, #0x1
    3098:      	b	0x30d0 <generic_retkprobe_filter_arg+0x30d0>
    309c:      	strh	w25, [x0], #0x2
    30a0:      	mov	w8, #0x4                // =4
    30a4:      	mov	w1, w25
    30a8:      	mov	x2, x29
    30ac:      	blr	x8
    30b0:      	ldr	w8, [sp, #0x20]
    30b4:      	subs	w8, w8, w25
    30b8:      	b.ls	0x30d4 <generic_retkprobe_filter_arg+0x30d4>
    30bc:      	add	x9, x19, x25
    30c0:      	ldr	x2, [sp, #0x10]
    30c4:      	and	w1, w8, #0xfff
    30c8:      	mov	w8, #0x4                // =4
    30cc:      	add	x0, x9, #0x2
    30d0:      	blr	x8
    30d4:      	ldr	w8, [sp, #0x1c]
    30d8:      	cmp	w22, #0x4
    30dc:      	str	w8, [sp, #0x60]
    30e0:      	b.le	0x3118 <generic_retkprobe_filter_arg+0x3118>
    30e4:      	cmp	w22, #0x7
    30e8:      	b.gt	0x314c <generic_retkprobe_filter_arg+0x314c>
    30ec:      	cmp	w22, #0x5
    30f0:      	b.eq	0x3270 <generic_retkprobe_filter_arg+0x3270>
    30f4:      	cmp	w22, #0x6
    30f8:      	b.eq	0x3234 <generic_retkprobe_filter_arg+0x3234>
    30fc:      	cmp	w22, #0x7
    3100:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3104:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3108:      	mov	w8, #0x1                // =1
    310c:      	add	x9, sp, #0x60
    3110:      	ldr	x0, [x0]
    3114:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3118:      	cmp	w22, #0x1
    311c:      	b.le	0x3178 <generic_retkprobe_filter_arg+0x3178>
    3120:      	cmp	w22, #0x2
    3124:      	b.eq	0x325c <generic_retkprobe_filter_arg+0x325c>
    3128:      	cmp	w22, #0x3
    312c:      	b.eq	0x3220 <generic_retkprobe_filter_arg+0x3220>
    3130:      	cmp	w22, #0x4
    3134:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3138:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    313c:      	mov	w8, #0x1                // =1
    3140:      	add	x9, sp, #0x60
    3144:      	ldr	x0, [x0]
    3148:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    314c:      	cmp	w22, #0x8
    3150:      	b.eq	0x3284 <generic_retkprobe_filter_arg+0x3284>
    3154:      	cmp	w22, #0x9
    3158:      	b.eq	0x3248 <generic_retkprobe_filter_arg+0x3248>
    315c:      	cmp	w22, #0xa
    3160:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3164:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3168:      	mov	w8, #0x1                // =1
    316c:      	add	x9, sp, #0x60
    3170:      	ldr	x0, [x0]
    3174:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3178:      	cbz	w22, 0x320c <generic_retkprobe_filter_arg+0x320c>
    317c:      	cmp	w22, #0x1
    3180:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3184:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3188:      	mov	w8, #0x1                // =1
    318c:      	add	x9, sp, #0x60
    3190:      	ldr	x0, [x0]
    3194:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3198:      	cmp	w8, #0x1
    319c:      	b.eq	0x330c <generic_retkprobe_filter_arg+0x330c>
    31a0:      	cmp	w8, #0x2
    31a4:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    31a8:      	ldrb	w10, [x25]
    31ac:      	b	0x3330 <generic_retkprobe_filter_arg+0x3330>
    31b0:      	cmp	w8, #0x1
    31b4:      	b.eq	0x3314 <generic_retkprobe_filter_arg+0x3314>
    31b8:      	cmp	w8, #0x2
    31bc:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    31c0:      	ldrh	w10, [x25]
    31c4:      	b	0x3330 <generic_retkprobe_filter_arg+0x3330>
    31c8:      	ldrb	w10, [x25]
    31cc:      	b	0x31d4 <generic_retkprobe_filter_arg+0x31d4>
    31d0:      	ldrh	w10, [x25]
    31d4:      	cmp	w9, w10
    31d8:      	b.ne	0x124 <generic_retkprobe_filter_arg+0x124>
    31dc:      	cmp	w8, #0x3
    31e0:      	cset	w22, eq
    31e4:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    31e8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    31ec:      	ldr	x9, [x25]
    31f0:      	cmp	x9, x10
    31f4:      	b.hs	0x124 <generic_retkprobe_filter_arg+0x124>
    31f8:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    31fc:      	ldr	x9, [x25]
    3200:      	cmp	x9, x10
    3204:      	b.ls	0x124 <generic_retkprobe_filter_arg+0x124>
    3208:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    320c:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3210:      	mov	w8, #0x1                // =1
    3214:      	add	x9, sp, #0x60
    3218:      	ldr	x0, [x0]
    321c:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3220:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3224:      	mov	w8, #0x1                // =1
    3228:      	add	x9, sp, #0x60
    322c:      	ldr	x0, [x0]
    3230:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3234:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3238:      	mov	w8, #0x1                // =1
    323c:      	add	x9, sp, #0x60
    3240:      	ldr	x0, [x0]
    3244:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3248:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    324c:      	mov	w8, #0x1                // =1
    3250:      	add	x9, sp, #0x60
    3254:      	ldr	x0, [x0]
    3258:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    325c:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3260:      	mov	w8, #0x1                // =1
    3264:      	add	x9, sp, #0x60
    3268:      	ldr	x0, [x0]
    326c:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3270:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3274:      	mov	w8, #0x1                // =1
    3278:      	add	x9, sp, #0x60
    327c:      	ldr	x0, [x0]
    3280:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3284:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3288:      	mov	w8, #0x1                // =1
    328c:      	add	x9, sp, #0x60
    3290:      	ldr	x0, [x0]
    3294:      	add	x1, sp, #0x60
    3298:      	blr	x8
    329c:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    32a0:      	mov	w8, #0x1                // =1
    32a4:      	mov	x1, x19
    32a8:      	blr	x8
    32ac:      	cmp	x0, #0x0
    32b0:      	cset	w22, ne
    32b4:      	b	0x32bc <generic_retkprobe_filter_arg+0x32bc>
    32b8:      	mov	x22, xzr
    32bc:      	ldp	x12, x16, [sp, #0x48]
    32c0:      	mov	w17, #0x1               // =1
    32c4:      	ldr	w8, [x21, #0x4]
    32c8:      	ldr	x0, [sp, #0x38]
    32cc:      	cmp	w8, #0x25
    32d0:      	b.hi	0x3300 <generic_retkprobe_filter_arg+0x3300>
    32d4:      	mov	x9, #0x50               // =80
    32d8:      	ldr	x19, [sp, #0x30]
    32dc:      	lsl	x8, x17, x8
    32e0:      	movk	x9, #0xc00, lsl #16
    32e4:      	movk	x9, #0x20, lsl #32
    32e8:      	tst	x8, x9
    32ec:      	b.eq	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    32f0:      	cmp	x22, #0x0
    32f4:      	cset	w22, eq
    32f8:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    32fc:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    3300:      	ldr	x19, [sp, #0x30]
    3304:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    3308:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    330c:      	ldrb	w10, [x25]
    3310:      	b	0x3320 <generic_retkprobe_filter_arg+0x3320>
    3314:      	ldrh	w10, [x25]
    3318:      	b	0x3320 <generic_retkprobe_filter_arg+0x3320>
    331c:      	ldr	w9, [x25]
    3320:      	cmp	w9, w10
    3324:      	b.hs	0x124 <generic_retkprobe_filter_arg+0x124>
    3328:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    332c:      	ldr	w9, [x25]
    3330:      	cmp	w9, w10
    3334:      	b.ls	0x124 <generic_retkprobe_filter_arg+0x124>
    3338:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    333c:      	ldr	x8, [sp, #0x40]
    3340:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3344:      	mov	w9, #0xc                // =12
    3348:      	mov	x0, x23
    334c:      	stur	w8, [x19, #0x43]
    3350:      	mov	w8, #0x4                // =4
    3354:      	mov	w2, #0x4                // =4
    3358:      	ldr	x1, [x1]
    335c:      	blr	x9
    3360:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3364:      	mov	w8, #0x5                // =5
    3368:      	mov	w9, #0xc                // =12
    336c:      	ldr	x1, [x1]
    3370:      	mov	x0, x23
    3374:      	mov	w2, #0x5                // =5
    3378:      	blr	x9
    337c:      	ldp	x20, x19, [sp, #0xe0]
    3380:      	mov	w0, wzr
    3384:      	ldr	x29, [sp, #0xa0]
    3388:      	ldp	x22, x21, [sp, #0xd0]
    338c:      	ldp	x24, x23, [sp, #0xc0]
    3390:      	ldp	x30, x25, [sp, #0xb0]
    3394:      	add	sp, sp, #0xf0
    3398:      	ret
    339c:      	ldrb	w8, [x19]
    33a0:      	cbz	w8, 0x33ac <generic_retkprobe_filter_arg+0x33ac>
    33a4:      	mov	w8, wzr
    33a8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33ac:      	ldrb	w8, [x19, #0x1]
    33b0:      	cbz	w8, 0x33bc <generic_retkprobe_filter_arg+0x33bc>
    33b4:      	mov	w8, #0x1                // =1
    33b8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33bc:      	ldrb	w8, [x19, #0x2]
    33c0:      	cbz	w8, 0x33cc <generic_retkprobe_filter_arg+0x33cc>
    33c4:      	mov	w8, #0x2                // =2
    33c8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33cc:      	ldrb	w8, [x19, #0x3]
    33d0:      	cbz	w8, 0x33dc <generic_retkprobe_filter_arg+0x33dc>
    33d4:      	mov	w8, #0x3                // =3
    33d8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33dc:      	ldrb	w8, [x19, #0x4]
    33e0:      	cbz	w8, 0x33ec <generic_retkprobe_filter_arg+0x33ec>
    33e4:      	mov	w8, #0x4                // =4
    33e8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33ec:      	ldrb	w8, [x19, #0x5]
    33f0:      	cbz	w8, 0x3418 <generic_retkprobe_filter_arg+0x3418>
    33f4:      	mov	w8, #0x5                // =5
    33f8:      	stur	w8, [x19, #0x3f]
    33fc:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3400:      	mov	w8, #0x3                // =3
    3404:      	mov	w9, #0xc                // =12
    3408:      	ldr	x1, [x1]
    340c:      	mov	x0, x23
    3410:      	mov	w2, #0x3                // =3
    3414:      	blr	x9
    3418:      	ldr	x19, [x20, #0x60]
    341c:      	mov	w8, #0xe                // =14
    3420:      	blr	x8
    3424:      	stp	x19, x0, [sp, #0x60]
    3428:      	adrp	x19, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    342c:      	mov	w8, #0x1                // =1
    3430:      	add	x9, sp, #0x60
    3434:      	add	x1, sp, #0x60
    3438:      	ldr	x19, [x19]
    343c:      	mov	x0, x19
    3440:      	blr	x8
    3444:      	cbz	x0, 0x337c <generic_retkprobe_filter_arg+0x337c>
    3448:      	mov	w8, #0x3                // =3
    344c:      	add	x9, sp, #0x60
    3450:      	add	x1, sp, #0x60
    3454:      	mov	x0, x19
    3458:      	blr	x8
    345c:      	b	0x337c <generic_retkprobe_filter_arg+0x337c>

0000000000003460 <generic_retkprobe_actions>:
    3460:      	sub	sp, sp, #0xe0
    3464:      	str	x29, [sp, #0x90]
    3468:      	stp	x30, x25, [sp, #0xa0]
    346c:      	stp	x24, x23, [sp, #0xb0]
    3470:      	stp	x22, x21, [sp, #0xc0]
    3474:      	stp	x20, x19, [sp, #0xd0]
    3478:      	str	x0, [sp, #0x50]
    347c:      	str	wzr, [sp, #0x5c]
    3480:      	adrp	x29, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3484:      	mov	w8, #0x1                // =1
    3488:      	add	x9, sp, #0x5c
    348c:      	add	x1, sp, #0x5c
    3490:      	ldr	x29, [x29]
    3494:      	mov	x0, x29
    3498:      	blr	x8
    349c:      	cbz	x0, 0x3f24 <generic_retkprobe_actions+0xac4>
    34a0:      	mov	w8, #0x5f04             // =24324
    34a4:      	ldr	w19, [x0, x8]
    34a8:      	cmp	w19, #0x2
    34ac:      	b.lt	0x3f24 <generic_retkprobe_actions+0xac4>
    34b0:      	mov	w8, #0x5ef8             // =24312
    34b4:      	add	x1, x0, x8
    34b8:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    34bc:      	mov	w8, #0x1                // =1
    34c0:      	ldr	x0, [x0]
    34c4:      	blr	x8
    34c8:      	cbz	x0, 0x3f24 <generic_retkprobe_actions+0xac4>
    34cc:      	and	x8, x19, #0x7ff
    34d0:      	add	x9, sp, #0x60
    34d4:      	add	x1, sp, #0x60
    34d8:      	ldr	w8, [x0, x8]
    34dc:      	str	wzr, [sp, #0x60]
    34e0:      	add	w8, w8, w19
    34e4:      	and	w8, w8, #0x7ff
    34e8:      	add	x21, x0, x8
    34ec:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    34f0:      	mov	w8, #0x1                // =1
    34f4:      	ldr	x0, [x0]
    34f8:      	blr	x8
    34fc:      	cbz	x0, 0x3544 <generic_retkprobe_actions+0xe4>
    3500:      	ldrb	w8, [x0]
    3504:      	mov	w11, #0x6               // =6
    3508:      	mov	w14, #0x7               // =7
    350c:      	mov	w10, #0x8               // =8
    3510:      	mov	w12, #0x5               // =5
    3514:      	mov	w13, #0x9               // =9
    3518:      	ands	w8, w8, #0xff
    351c:      	cset	w9, eq
    3520:      	cmp	w8, #0x0
    3524:      	str	w9, [sp, #0x48]
    3528:      	mov	w9, #0x4                // =4
    352c:      	csel	x8, x11, x14, eq
    3530:      	csel	x11, x10, x13, eq
    3534:      	str	x8, [sp, #0x30]
    3538:      	csel	x8, x9, x12, eq
    353c:      	stp	x11, x8, [sp, #0x38]
    3540:      	b	0x3564 <generic_retkprobe_actions+0x104>
    3544:      	mov	w8, #0x1                // =1
    3548:      	str	w8, [sp, #0x48]
    354c:      	mov	w8, #0x4                // =4
    3550:      	str	x8, [sp, #0x40]
    3554:      	mov	w8, #0x8                // =8
    3558:      	str	x8, [sp, #0x38]
    355c:      	mov	w8, #0x6                // =6
    3560:      	str	x8, [sp, #0x30]
    3564:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3568:      	mov	w23, wzr
    356c:      	mov	w19, wzr
    3570:      	ldr	x25, [x25]
    3574:      	add	x20, sp, #0x64
    3578:      	mov	w8, #0x1                // =1
    357c:      	str	w8, [sp, #0x4c]
    3580:      	b	0x3594 <generic_retkprobe_actions+0x134>
    3584:      	mov	w19, wzr
    3588:      	add	w23, w23, #0x1
    358c:      	cmp	w23, #0x3
    3590:      	b.eq	0x3f00 <generic_retkprobe_actions+0xaa0>
    3594:      	ldr	w9, [x21]
    3598:      	lsl	w8, w19, #2
    359c:      	add	w8, w8, #0x4
    35a0:      	cmp	w8, w9
    35a4:      	b.hs	0x3f00 <generic_retkprobe_actions+0xaa0>
    35a8:      	add	x8, x21, w19, uxtw #2
    35ac:      	add	x1, sp, #0x64
    35b0:      	mov	x0, x29
    35b4:      	ldrsw	x24, [x8, #0x4]
    35b8:      	str	wzr, [sp, #0x64]
    35bc:      	mov	w8, #0x1                // =1
    35c0:      	blr	x8
    35c4:      	cbz	x0, 0x3584 <generic_retkprobe_actions+0x124>
    35c8:      	mov	x22, x0
    35cc:      	cmp	w24, #0x7
    35d0:      	b.gt	0x3600 <generic_retkprobe_actions+0x1a0>
    35d4:      	cmp	w24, #0x3
    35d8:      	b.gt	0x3650 <generic_retkprobe_actions+0x1f0>
    35dc:      	cmp	w24, #0x1
    35e0:      	b.gt	0x36d0 <generic_retkprobe_actions+0x270>
    35e4:      	cbz	w24, 0x3834 <generic_retkprobe_actions+0x3d4>
    35e8:      	cmp	w24, #0x1
    35ec:      	b.eq	0x36e0 <generic_retkprobe_actions+0x280>
    35f0:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    35f4:      	b	0x3938 <generic_retkprobe_actions+0x4d8>
    35f8:      	nop
    35fc:      	nop
    3600:      	cmp	w24, #0xb
    3604:      	b.gt	0x36a8 <generic_retkprobe_actions+0x248>
    3608:      	sub	w8, w24, #0xa
    360c:      	cmp	w8, #0x2
    3610:      	b.lo	0x3744 <generic_retkprobe_actions+0x2e4>
    3614:      	cmp	w24, #0x8
    3618:      	b.eq	0x378c <generic_retkprobe_actions+0x32c>
    361c:      	cmp	w24, #0x9
    3620:      	b.ne	0x393c <generic_retkprobe_actions+0x4dc>
    3624:      	add	w19, w19, #0x1
    3628:      	add	x8, x21, w19, uxtw #2
    362c:      	ldr	w0, [x8, #0x4]
    3630:      	ldr	w8, [sp, #0x48]
    3634:      	add	x25, sp, #0x68
    3638:      	cbz	w8, 0x38dc <generic_retkprobe_actions+0x47c>
    363c:      	sxtw	x8, w0
    3640:      	mov	w9, #0x6d               // =109
    3644:      	blr	x9
    3648:      	mov	w20, #0x2               // =2
    364c:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    3650:      	sub	w8, w24, #0x6
    3654:      	cmp	w8, #0x2
    3658:      	b.lo	0x3778 <generic_retkprobe_actions+0x318>
    365c:      	cmp	w24, #0x4
    3660:      	b.eq	0x3794 <generic_retkprobe_actions+0x334>
    3664:      	cmp	w24, #0x5
    3668:      	b.ne	0x393c <generic_retkprobe_actions+0x4dc>
    366c:      	add	w8, w19, #0x1
    3670:      	add	x9, x21, #0x4
    3674:      	add	w19, w19, #0x2
    3678:      	ldr	w8, [x9, w8, uxtw #2]
    367c:      	ldr	w20, [x9, w19, uxtw #2]
    3680:      	stp	xzr, xzr, [sp, #0x68]
    3684:      	and	x8, x8, #0x7
    3688:      	cmp	w8, #0x4
    368c:      	b.hi	0x36a0 <generic_retkprobe_actions+0x240>
    3690:      	add	x9, x22, x8, lsl #2
    3694:      	mov	w10, #0x5ea0            // =24224
    3698:      	ldr	w9, [x9, x10]
    369c:      	cbz	w9, 0x3b18 <generic_retkprobe_actions+0x6b8>
    36a0:      	add	x20, sp, #0x64
    36a4:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    36a8:      	cmp	w24, #0xc
    36ac:      	b.eq	0x38e4 <generic_retkprobe_actions+0x484>
    36b0:      	cmp	w24, #0xd
    36b4:      	b.eq	0x37a4 <generic_retkprobe_actions+0x344>
    36b8:      	cmp	w24, #0xe
    36bc:      	b.ne	0x393c <generic_retkprobe_actions+0x4dc>
    36c0:      	ldr	x20, [sp, #0x38]
    36c4:      	add	x25, sp, #0x68
    36c8:      	add	w19, w19, #0x2
    36cc:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    36d0:      	cmp	w24, #0x2
    36d4:      	b.eq	0x38cc <generic_retkprobe_actions+0x46c>
    36d8:      	cmp	w24, #0x3
    36dc:      	b.ne	0x35f0 <generic_retkprobe_actions+0x190>
    36e0:      	add	w8, w19, #0x1
    36e4:      	add	x9, x21, #0x4
    36e8:      	add	w19, w19, #0x2
    36ec:      	ldr	w20, [x9, w19, uxtw #2]
    36f0:      	mov	x25, x21
    36f4:      	ldr	w21, [x9, w8, uxtw #2]
    36f8:      	str	wzr, [sp, #0x78]
    36fc:      	stp	xzr, xzr, [sp, #0x68]
    3700:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3704:      	mov	w8, #0x1                // =1
    3708:      	add	x9, sp, #0x78
    370c:      	add	x1, sp, #0x78
    3710:      	ldr	x0, [x0]
    3714:      	blr	x8
    3718:      	cbz	x0, 0x372c <generic_retkprobe_actions+0x2cc>
    371c:      	and	x8, x21, #0x7
    3720:      	cmp	w8, #0x4
    3724:      	b.ls	0x3954 <generic_retkprobe_actions+0x4f4>
    3728:      	mov	w0, wzr
    372c:      	mov	x21, x25
    3730:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3734:      	add	x20, sp, #0x64
    3738:      	ldr	x25, [x25]
    373c:      	cbnz	w0, 0x3584 <generic_retkprobe_actions+0x124>
    3740:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3744:      	add	w19, w19, #0x1
    3748:      	add	x8, x21, w19, uxtw #2
    374c:      	ldr	w8, [x8, #0x4]
    3750:      	and	x8, x8, #0x7
    3754:      	cmp	w8, #0x4
    3758:      	b.hi	0x376c <generic_retkprobe_actions+0x30c>
    375c:      	add	x9, x22, x8, lsl #2
    3760:      	mov	w10, #0x5ea0            // =24224
    3764:      	ldr	w9, [x9, x10]
    3768:      	cbz	w9, 0x3970 <generic_retkprobe_actions+0x510>
    376c:      	mov	w0, wzr
    3770:      	cbnz	w0, 0x3584 <generic_retkprobe_actions+0x124>
    3774:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3778:      	add	w19, w19, #0x1
    377c:      	add	x8, x21, w19, uxtw #2
    3780:      	ldr	w8, [x8, #0x4]
    3784:      	str	w8, [x22, #0x78]
    3788:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    378c:      	str	wzr, [sp, #0x4c]
    3790:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3794:      	ldr	x20, [sp, #0x40]
    3798:      	add	x25, sp, #0x68
    379c:      	add	w19, w19, #0x1
    37a0:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    37a4:      	mov	w8, #0xe                // =14
    37a8:      	blr	x8
    37ac:      	str	x0, [sp, #0x88]
    37b0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    37b4:      	mov	w8, #0x1                // =1
    37b8:      	add	x9, sp, #0x88
    37bc:      	ldr	x0, [x0]
    37c0:      	add	x1, sp, #0x88
    37c4:      	blr	x8
    37c8:      	cbz	x0, 0x393c <generic_retkprobe_actions+0x4dc>
    37cc:      	ldur	x8, [x0, #0x4]
    37d0:      	mov	x20, x21
    37d4:      	add	x21, sp, #0x78
    37d8:      	add	x1, sp, #0x78
    37dc:      	str	x8, [sp, #0x78]
    37e0:      	mov	w8, #0x2                // =2
    37e4:      	mov	x0, x25
    37e8:      	str	w8, [sp, #0x80]
    37ec:      	mov	w8, #0x1                // =1
    37f0:      	blr	x8
    37f4:      	mov	w9, #0x1                // =1
    37f8:      	str	w9, [sp, #0x98]
    37fc:      	cbz	x0, 0x3aa8 <generic_retkprobe_actions+0x648>
    3800:      	ldaxr	w8, [x0]
    3804:      	add	w8, w8, #0x1
    3808:      	stlxr	w9, w8, [x0]
    380c:      	cbnz	w9, 0x3800 <generic_retkprobe_actions+0x3a0>
    3810:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3814:      	mov	w8, #0x3                // =3
    3818:      	add	x9, sp, #0x88
    381c:      	ldr	x0, [x0]
    3820:      	add	x1, sp, #0x88
    3824:      	blr	x8
    3828:      	mov	x21, x20
    382c:      	add	x20, sp, #0x64
    3830:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3834:      	add	w8, w19, #0x1
    3838:      	add	x9, x21, #0x4
    383c:      	ldr	w25, [x9, w8, uxtw #2]
    3840:      	add	w8, w19, #0x2
    3844:      	ldr	w20, [x9, w8, uxtw #2]
    3848:      	mov	w8, #0x7d               // =125
    384c:      	blr	x8
    3850:      	str	x0, [sp, #0x68]
    3854:      	str	wzr, [sp, #0x88]
    3858:      	str	x25, [sp, #0x18]
    385c:      	cbz	w25, 0x3dfc <generic_retkprobe_actions+0x99c>
    3860:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3864:      	mov	w8, #0x1                // =1
    3868:      	add	x9, sp, #0x88
    386c:      	ldr	x0, [x0]
    3870:      	add	x1, sp, #0x88
    3874:      	blr	x8
    3878:      	cbz	x0, 0x3dfc <generic_retkprobe_actions+0x99c>
    387c:      	mov	x25, x0
    3880:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3884:      	mov	w8, #0x1                // =1
    3888:      	ldr	x0, [x0]
    388c:      	add	x9, sp, #0x88
    3890:      	add	x1, sp, #0x88
    3894:      	blr	x8
    3898:      	ldr	x8, [x22, #0x60]
    389c:      	mov	x2, x0
    38a0:      	cmp	w20, #0x2
    38a4:      	str	x8, [x25]
    38a8:      	ldr	x8, [x22, #0x70]
    38ac:      	str	x8, [x25, #0x8]
    38b0:      	b.eq	0x3c1c <generic_retkprobe_actions+0x7bc>
    38b4:      	cmp	w20, #0x1
    38b8:      	b.eq	0x3c10 <generic_retkprobe_actions+0x7b0>
    38bc:      	cbnz	w20, 0x3dfc <generic_retkprobe_actions+0x99c>
    38c0:      	ldr	w8, [x22, #0x7c]
    38c4:      	str	x21, [sp, #0x8]
    38c8:      	b	0x3c24 <generic_retkprobe_actions+0x7c4>
    38cc:      	mov	w0, #0x9                // =9
    38d0:      	ldr	w8, [sp, #0x48]
    38d4:      	add	x25, sp, #0x68
    38d8:      	cbnz	w8, 0x363c <generic_retkprobe_actions+0x1dc>
    38dc:      	mov	w20, #0x3               // =3
    38e0:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    38e4:      	ldr	x20, [sp, #0x30]
    38e8:      	add	x25, sp, #0x68
    38ec:      	add	w19, w19, #0x3
    38f0:      	str	wzr, [sp, #0x68]
    38f4:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    38f8:      	mov	w8, #0x1                // =1
    38fc:      	add	x1, sp, #0x68
    3900:      	ldr	x0, [x0]
    3904:      	blr	x8
    3908:      	cbz	x0, 0x3930 <generic_retkprobe_actions+0x4d0>
    390c:      	add	x8, x0, x20, lsl #3
    3910:      	nop
    3914:      	nop
    3918:      	nop
    391c:      	nop
    3920:      	ldaxr	x9, [x8]
    3924:      	add	x9, x9, #0x1
    3928:      	stlxr	w10, x9, [x8]
    392c:      	cbnz	w10, 0x3920 <generic_retkprobe_actions+0x4c0>
    3930:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3934:      	add	x20, sp, #0x64
    3938:      	ldr	x25, [x25]
    393c:      	add	w19, w19, #0x1
    3940:      	str	x24, [x22, #0x70]
    3944:      	add	w23, w23, #0x1
    3948:      	cmp	w23, #0x3
    394c:      	b.ne	0x3594 <generic_retkprobe_actions+0x134>
    3950:      	b	0x3f00 <generic_retkprobe_actions+0xaa0>
    3954:      	add	x9, x22, x8, lsl #2
    3958:      	mov	w10, #0x5ea0            // =24224
    395c:      	ldr	w9, [x9, x10]
    3960:      	cbz	w9, 0x3a08 <generic_retkprobe_actions+0x5a8>
    3964:      	mov	x21, x25
    3968:      	mov	w0, wzr
    396c:      	b	0x3730 <generic_retkprobe_actions+0x2d0>
    3970:      	add	x8, x22, x8, lsl #3
    3974:      	ldr	x8, [x8, #0x5e78]
    3978:      	and	x8, x8, #0x7ff
    397c:      	add	x8, x22, x8
    3980:      	ldr	x8, [x8, #0xb8]
    3984:      	str	x8, [sp, #0x78]
    3988:      	cbz	x8, 0x376c <generic_retkprobe_actions+0x30c>
    398c:      	cmp	w24, #0xa
    3990:      	b.ne	0x3bf0 <generic_retkprobe_actions+0x790>
    3994:      	mov	w8, #0xe                // =14
    3998:      	add	x25, sp, #0x68
    399c:      	mov	x20, x21
    39a0:      	blr	x8
    39a4:      	lsr	x8, x0, #32
    39a8:      	mov	x21, x0
    39ac:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    39b0:      	str	w8, [sp, #0x68]
    39b4:      	mov	w8, #0x1                // =1
    39b8:      	add	x1, sp, #0x68
    39bc:      	ldr	x0, [x0]
    39c0:      	blr	x8
    39c4:      	cbz	x0, 0x39fc <generic_retkprobe_actions+0x59c>
    39c8:      	ldr	w8, [x0]
    39cc:      	mov	x3, xzr
    39d0:      	add	x9, sp, #0x78
    39d4:      	add	x1, sp, #0x78
    39d8:      	stp	w8, w21, [sp, #0x68]
    39dc:      	ldr	x8, [x0, #0x8]
    39e0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    39e4:      	add	x2, sp, #0x68
    39e8:      	str	x8, [sp, #0x70]
    39ec:      	mov	w8, #0x2                // =2
    39f0:      	ldr	x0, [x0]
    39f4:      	blr	x8
    39f8:      	mov	w0, wzr
    39fc:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3a00:      	mov	x21, x20
    3a04:      	b	0x3734 <generic_retkprobe_actions+0x2d4>
    3a08:      	add	x8, x22, x8, lsl #3
    3a0c:      	mov	x21, x0
    3a10:      	ldr	x8, [x8, #0x5e78]
    3a14:      	str	wzr, [sp, #0x74]
    3a18:      	and	x8, x8, #0x7ff
    3a1c:      	add	x8, x22, x8
    3a20:      	ldr	w8, [x8, #0x90]
    3a24:      	str	w8, [sp, #0x70]
    3a28:      	mov	w8, #0xe                // =14
    3a2c:      	blr	x8
    3a30:      	lsr	x8, x0, #32
    3a34:      	cmp	w24, #0x1
    3a38:      	str	x8, [sp, #0x68]
    3a3c:      	b.ne	0x3bd4 <generic_retkprobe_actions+0x774>
    3a40:      	and	x8, x20, #0x7
    3a44:      	cmp	w8, #0x4
    3a48:      	b.hi	0x3728 <generic_retkprobe_actions+0x2c8>
    3a4c:      	add	x9, x22, x8, lsl #2
    3a50:      	mov	w10, #0x5ea0            // =24224
    3a54:      	add	x20, sp, #0x68
    3a58:      	ldr	w9, [x9, x10]
    3a5c:      	cbnz	w9, 0x3728 <generic_retkprobe_actions+0x2c8>
    3a60:      	add	x8, x22, x8, lsl #3
    3a64:      	mov	x0, x21
    3a68:      	ldr	x8, [x8, #0x5e78]
    3a6c:      	and	x8, x8, #0x7ff
    3a70:      	add	x2, x22, x8
    3a74:      	ldr	w8, [x2, #0x90]!
    3a78:      	and	x8, x8, #0xfff
    3a7c:      	add	x1, x8, #0x8
    3a80:      	mov	w8, #0x4                // =4
    3a84:      	blr	x8
    3a88:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3a8c:      	mov	x3, xzr
    3a90:      	mov	w8, #0x2                // =2
    3a94:      	ldr	x0, [x0]
    3a98:      	add	x1, sp, #0x68
    3a9c:      	mov	x2, x21
    3aa0:      	blr	x8
    3aa4:      	b	0x3728 <generic_retkprobe_actions+0x2c8>
    3aa8:      	mov	w8, #0x2                // =2
    3aac:      	add	x10, sp, #0x98
    3ab0:      	add	x1, sp, #0x78
    3ab4:      	add	x2, sp, #0x98
    3ab8:      	mov	x0, x25
    3abc:      	mov	w3, #0x1                // =1
    3ac0:      	blr	x8
    3ac4:      	cbz	x0, 0x3810 <generic_retkprobe_actions+0x3b0>
    3ac8:      	mov	x21, x0
    3acc:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3ad0:      	add	x9, sp, #0x68
    3ad4:      	add	x1, sp, #0x68
    3ad8:      	neg	w8, w21
    3adc:      	strh	w8, [sp, #0x68]
    3ae0:      	mov	w8, #0x3                // =3
    3ae4:      	strh	w8, [sp, #0x6a]
    3ae8:      	mov	x8, #0x3b               // =59
    3aec:      	movk	x8, #0x2, lsl #32
    3af0:      	stur	x8, [sp, #0x6c]
    3af4:      	mov	w8, #0x1                // =1
    3af8:      	ldr	x25, [x25]
    3afc:      	mov	x0, x25
    3b00:      	blr	x8
    3b04:      	cbz	x0, 0x3e9c <generic_retkprobe_actions+0xa3c>
    3b08:      	ldr	w8, [x0]
    3b0c:      	add	w8, w8, #0x1
    3b10:      	str	w8, [x0]
    3b14:      	b	0x3ec4 <generic_retkprobe_actions+0xa64>
    3b18:      	add	x8, x22, x8, lsl #3
    3b1c:      	ldr	x8, [x8, #0x5e78]
    3b20:      	and	x8, x8, #0x7ff
    3b24:      	add	x8, x22, x8
    3b28:      	ldr	w8, [x8, #0x90]
    3b2c:      	str	w8, [sp, #0x70]
    3b30:      	mov	w8, #0xe                // =14
    3b34:      	blr	x8
    3b38:      	lsr	x8, x0, #32
    3b3c:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3b40:      	add	x9, sp, #0x68
    3b44:      	str	x8, [sp, #0x68]
    3b48:      	mov	w8, #0x1                // =1
    3b4c:      	add	x1, sp, #0x68
    3b50:      	ldr	x0, [x0]
    3b54:      	blr	x8
    3b58:      	cbz	x0, 0x36a0 <generic_retkprobe_actions+0x240>
    3b5c:      	and	x8, x20, #0x7
    3b60:      	cmp	w8, #0x4
    3b64:      	b.hi	0x36a0 <generic_retkprobe_actions+0x240>
    3b68:      	add	x9, x22, x8, lsl #2
    3b6c:      	mov	w10, #0x5ea0            // =24224
    3b70:      	ldr	w9, [x9, x10]
    3b74:      	cbnz	w9, 0x36a0 <generic_retkprobe_actions+0x240>
    3b78:      	add	x8, x22, x8, lsl #3
    3b7c:      	mov	x20, x21
    3b80:      	mov	x21, x0
    3b84:      	ldr	x8, [x8, #0x5e78]
    3b88:      	str	wzr, [sp, #0x74]
    3b8c:      	and	x8, x8, #0x7ff
    3b90:      	add	x8, x22, x8
    3b94:      	ldr	w8, [x8, #0x90]
    3b98:      	str	w8, [sp, #0x70]
    3b9c:      	mov	w8, #0xe                // =14
    3ba0:      	blr	x8
    3ba4:      	lsr	x8, x0, #32
    3ba8:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3bac:      	mov	x3, xzr
    3bb0:      	str	x8, [sp, #0x68]
    3bb4:      	mov	w8, #0x2                // =2
    3bb8:      	add	x9, sp, #0x68
    3bbc:      	add	x1, sp, #0x68
    3bc0:      	ldr	x0, [x0]
    3bc4:      	mov	x2, x21
    3bc8:      	mov	x21, x20
    3bcc:      	blr	x8
    3bd0:      	b	0x36a0 <generic_retkprobe_actions+0x240>
    3bd4:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3bd8:      	mov	w8, #0x3                // =3
    3bdc:      	add	x9, sp, #0x68
    3be0:      	ldr	x0, [x0]
    3be4:      	add	x1, sp, #0x68
    3be8:      	blr	x8
    3bec:      	b	0x372c <generic_retkprobe_actions+0x2cc>
    3bf0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3bf4:      	mov	w8, #0x3                // =3
    3bf8:      	add	x9, sp, #0x78
    3bfc:      	ldr	x0, [x0]
    3c00:      	add	x1, sp, #0x78
    3c04:      	blr	x8
    3c08:      	cbnz	w0, 0x3584 <generic_retkprobe_actions+0x124>
    3c0c:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3c10:      	ldr	w8, [x22, #0x10]
    3c14:      	str	x21, [sp, #0x8]
    3c18:      	b	0x3c24 <generic_retkprobe_actions+0x7c4>
    3c1c:      	str	x21, [sp, #0x8]
    3c20:      	mov	x8, xzr
    3c24:      	str	x8, [x25, #0x10]
    3c28:      	str	x25, [sp, #0x10]
    3c2c:      	add	x0, x25, #0x18
    3c30:      	mov	w8, #0x4                // =4
    3c34:      	mov	w9, #0xc8               // =200
    3c38:      	mov	w1, #0xc8               // =200
    3c3c:      	str	x0, [sp, #0x20]
    3c40:      	blr	x8
    3c44:      	str	wzr, [sp, #0x2c]
    3c48:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3c4c:      	mov	w8, #0x5e78             // =24184
    3c50:      	mov	x21, xzr
    3c54:      	ldr	x25, [x25]
    3c58:      	add	x20, x22, x8
    3c5c:      	b	0x3c70 <generic_retkprobe_actions+0x810>
    3c60:      	add	x21, x21, #0x4
    3c64:      	add	x20, x20, #0x8
    3c68:      	cmp	x21, #0x14
    3c6c:      	b.eq	0x3d98 <generic_retkprobe_actions+0x938>
    3c70:      	str	wzr, [sp, #0x78]
    3c74:      	mov	w8, #0x1                // =1
    3c78:      	add	x9, sp, #0x78
    3c7c:      	add	x1, sp, #0x78
    3c80:      	mov	x0, x29
    3c84:      	blr	x8
    3c88:      	cbz	x0, 0x3d98 <generic_retkprobe_actions+0x938>
    3c8c:      	mov	w8, #0x5ef8             // =24312
    3c90:      	add	x1, x0, x8
    3c94:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3c98:      	mov	w8, #0x1                // =1
    3c9c:      	ldr	x0, [x0]
    3ca0:      	blr	x8
    3ca4:      	cbz	x0, 0x3d98 <generic_retkprobe_actions+0x938>
    3ca8:      	add	x8, x0, x21
    3cac:      	ldr	w8, [x8, #0x40]
    3cb0:      	cmn	w8, #0x1
    3cb4:      	b.eq	0x3d98 <generic_retkprobe_actions+0x938>
    3cb8:      	ldr	x8, [x20]
    3cbc:      	ldr	w9, [x22, #0x4]
    3cc0:      	cmp	x8, x9
    3cc4:      	b.ge	0x3d98 <generic_retkprobe_actions+0x938>
    3cc8:      	cmp	x21, #0x10
    3ccc:      	b.eq	0x3d2c <generic_retkprobe_actions+0x8cc>
    3cd0:      	str	wzr, [sp, #0x78]
    3cd4:      	mov	w8, #0x1                // =1
    3cd8:      	add	x9, sp, #0x78
    3cdc:      	add	x1, sp, #0x78
    3ce0:      	mov	x0, x29
    3ce4:      	blr	x8
    3ce8:      	cbz	x0, 0x3d28 <generic_retkprobe_actions+0x8c8>
    3cec:      	mov	w8, #0x5ef8             // =24312
    3cf0:      	add	x1, x0, x8
    3cf4:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3cf8:      	mov	w8, #0x1                // =1
    3cfc:      	ldr	x0, [x0]
    3d00:      	blr	x8
    3d04:      	cbz	x0, 0x3d28 <generic_retkprobe_actions+0x8c8>
    3d08:      	add	x8, x0, x21
    3d0c:      	ldr	w9, [x8, #0x44]
    3d10:      	ldr	x8, [x20]
    3d14:      	cmn	w9, #0x1
    3d18:      	b.eq	0x3d2c <generic_retkprobe_actions+0x8cc>
    3d1c:      	ldr	w9, [x20, #0x8]
    3d20:      	sub	w9, w9, w8
    3d24:      	b	0x3d38 <generic_retkprobe_actions+0x8d8>
    3d28:      	ldr	x8, [x20]
    3d2c:      	ldr	w9, [x22, #0x4]
    3d30:      	sub	w9, w9, w8
    3d34:      	add	w9, w9, #0x4
    3d38:      	cmp	w9, #0x1
    3d3c:      	b.lt	0x3c60 <generic_retkprobe_actions+0x800>
    3d40:      	mov	w10, #0x3ffc            // =16380
    3d44:      	cmp	w9, #0x28
    3d48:      	add	w8, w8, w10
    3d4c:      	mov	w10, #0x28              // =40
    3d50:      	csel	w29, w9, w10, lt
    3d54:      	ldr	w9, [sp, #0x2c]
    3d58:      	and	x8, x8, #0x3fff
    3d5c:      	add	x8, x22, x8
    3d60:      	mov	w1, w29
    3d64:      	add	x2, x8, #0x90
    3d68:      	mov	w8, #0x4                // =4
    3d6c:      	and	w25, w9, #0xff
    3d70:      	ldr	x9, [sp, #0x20]
    3d74:      	add	x0, x9, x25
    3d78:      	blr	x8
    3d7c:      	add	w8, w29, w25
    3d80:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3d84:      	adrp	x29, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3d88:      	str	w8, [sp, #0x2c]
    3d8c:      	ldr	x25, [x25]
    3d90:      	ldr	x29, [x29]
    3d94:      	b	0x3c60 <generic_retkprobe_actions+0x800>
    3d98:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3d9c:      	mov	w8, #0x1                // =1
    3da0:      	ldr	x0, [x0]
    3da4:      	ldr	x1, [sp, #0x10]
    3da8:      	blr	x8
    3dac:      	ldr	x21, [sp, #0x8]
    3db0:      	cbz	x0, 0x3ddc <generic_retkprobe_actions+0x97c>
    3db4:      	ldr	x9, [sp, #0x68]
    3db8:      	ldr	x11, [sp, #0x18]
    3dbc:      	mov	x10, #-0x4240           // =-16960
    3dc0:      	movk	x10, #0xfff0, lsl #16
    3dc4:      	ldr	x8, [x0]
    3dc8:      	madd	x9, x11, x10, x9
    3dcc:      	cmp	x8, x9
    3dd0:      	b.ls	0x3ddc <generic_retkprobe_actions+0x97c>
    3dd4:      	str	wzr, [sp, #0x4c]
    3dd8:      	b	0x3e04 <generic_retkprobe_actions+0x9a4>
    3ddc:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3de0:      	mov	x3, xzr
    3de4:      	mov	w8, #0x2                // =2
    3de8:      	ldr	x0, [x0]
    3dec:      	ldr	x1, [sp, #0x10]
    3df0:      	add	x9, sp, #0x68
    3df4:      	add	x2, sp, #0x68
    3df8:      	blr	x8
    3dfc:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3e00:      	ldr	x25, [x25]
    3e04:      	add	w8, w19, #0x3
    3e08:      	add	x20, sp, #0x64
    3e0c:      	add	x8, x21, w8, uxtw #2
    3e10:      	ldr	w8, [x8, #0x4]
    3e14:      	cbz	w8, 0x3e40 <generic_retkprobe_actions+0x9e0>
    3e18:      	ldrb	w8, [x22, #0x1]
    3e1c:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3e20:      	ldr	x0, [sp, #0x50]
    3e24:      	mov	x2, xzr
    3e28:      	orr	w8, w8, #0x2
    3e2c:      	strb	w8, [x22, #0x1]
    3e30:      	mov	w8, #0x1b               // =27
    3e34:      	ldr	x1, [x1]
    3e38:      	blr	x8
    3e3c:      	str	x0, [x22, #0x80]
    3e40:      	add	w8, w19, #0x4
    3e44:      	add	x8, x21, w8, uxtw #2
    3e48:      	ldr	w8, [x8, #0x4]
    3e4c:      	cbz	w8, 0x3e7c <generic_retkprobe_actions+0xa1c>
    3e50:      	ldrb	w8, [x22, #0x1]
    3e54:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3e58:      	ldr	x0, [sp, #0x50]
    3e5c:      	mov	w9, #0x100              // =256
    3e60:      	mov	w2, #0x100              // =256
    3e64:      	orr	w8, w8, #0x4
    3e68:      	strb	w8, [x22, #0x1]
    3e6c:      	mov	w8, #0x1b               // =27
    3e70:      	ldr	x1, [x1]
    3e74:      	blr	x8
    3e78:      	str	x0, [x22, #0x88]
    3e7c:      	add	w19, w19, #0x5
    3e80:      	add	x8, x21, w19, uxtw #2
    3e84:      	ldr	w8, [x8, #0x4]
    3e88:      	cbz	w8, 0x393c <generic_retkprobe_actions+0x4dc>
    3e8c:      	ldrb	w8, [x22, #0x1]
    3e90:      	orr	w8, w8, #0x8
    3e94:      	strb	w8, [x22, #0x1]
    3e98:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3e9c:      	mov	w8, #0x1                // =1
    3ea0:      	mov	x3, xzr
    3ea4:      	add	x9, sp, #0x9c
    3ea8:      	str	w8, [sp, #0x9c]
    3eac:      	mov	w8, #0x2                // =2
    3eb0:      	add	x10, sp, #0x68
    3eb4:      	add	x1, sp, #0x68
    3eb8:      	add	x2, sp, #0x9c
    3ebc:      	mov	x0, x25
    3ec0:      	blr	x8
    3ec4:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3ec8:      	ldr	x25, [x25]
    3ecc:      	cbz	w21, 0x3810 <generic_retkprobe_actions+0x3b0>
    3ed0:      	mov	w8, #0x1                // =1
    3ed4:      	add	x9, sp, #0x78
    3ed8:      	add	x1, sp, #0x78
    3edc:      	mov	x0, x25
    3ee0:      	blr	x8
    3ee4:      	cbz	x0, 0x3810 <generic_retkprobe_actions+0x3b0>
    3ee8:      	ldr	w8, [sp, #0x98]
    3eec:      	ldaxr	w9, [x0]
    3ef0:      	add	w9, w9, w8
    3ef4:      	stlxr	w10, w9, [x0]
    3ef8:      	cbnz	w10, 0x3eec <generic_retkprobe_actions+0xa8c>
    3efc:      	b	0x3810 <generic_retkprobe_actions+0x3b0>
    3f00:      	ldr	w8, [sp, #0x4c]
    3f04:      	cbz	w8, 0x3f24 <generic_retkprobe_actions+0xac4>
    3f08:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3f0c:      	mov	w8, #0x5                // =5
    3f10:      	mov	w9, #0xc                // =12
    3f14:      	ldr	x1, [x1]
    3f18:      	ldr	x0, [sp, #0x50]
    3f1c:      	mov	w2, #0x5                // =5
    3f20:      	blr	x9
    3f24:      	ldp	x20, x19, [sp, #0xd0]
    3f28:      	mov	w0, wzr
    3f2c:      	ldr	x29, [sp, #0x90]
    3f30:      	ldp	x22, x21, [sp, #0xc0]
    3f34:      	ldp	x24, x23, [sp, #0xb0]
    3f38:      	ldp	x30, x25, [sp, #0xa0]
    3f3c:      	add	sp, sp, #0xe0
    3f40:      	ret
    3f44:      	nop
    3f48:      	nop
    3f4c:      	nop

0000000000003f50 <generic_retkprobe_output>:
    3f50:      	sub	sp, sp, #0x30
    3f54:      	stp	x30, x21, [sp, #0x10]
    3f58:      	stp	x20, x19, [sp, #0x20]
    3f5c:      	mov	x20, x0
    3f60:      	str	wzr, [sp, #0x4]
    3f64:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3f68:      	mov	w8, #0x1                // =1
    3f6c:      	ldr	x0, [x0]
    3f70:      	add	x9, sp, #0x4
    3f74:      	add	x1, sp, #0x4
    3f78:      	blr	x8
    3f7c:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    3f80:      	ldr	w8, [x0, #0x4]
    3f84:      	mov	x19, x0
    3f88:      	mov	w9, #0x2328             // =9000
    3f8c:      	str	wzr, [sp, #0x8]
    3f90:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3f94:      	add	x1, sp, #0x8
    3f98:      	ldr	x0, [x0]
    3f9c:      	add	w8, w8, #0x90
    3fa0:      	and	w8, w8, #0x7fff
    3fa4:      	cmp	w8, w9
    3fa8:      	csel	w21, w8, w9, lo
    3fac:      	mov	w8, #0x1                // =1
    3fb0:      	add	x9, sp, #0x8
    3fb4:      	blr	x8
    3fb8:      	cbz	x0, 0x4034 <generic_retkprobe_output+0xe4>
    3fbc:      	ldrb	w8, [x0, #0x28]
    3fc0:      	cbz	w8, 0x4034 <generic_retkprobe_output+0xe4>
    3fc4:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3fc8:      	mov	w8, #-0x1               // =-1
    3fcc:      	mov	w9, #0x19               // =25
    3fd0:      	ldr	x1, [x1]
    3fd4:      	mov	x0, x20
    3fd8:      	mov	w2, #-0x1               // =-1
    3fdc:      	mov	x3, x19
    3fe0:      	mov	x4, x21
    3fe4:      	blr	x9
    3fe8:      	tbnz	x0, #0x3f, 0x40e4 <generic_retkprobe_output+0x194>
    3fec:      	str	wzr, [sp, #0xc]
    3ff0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3ff4:      	mov	w8, #0x1                // =1
    3ff8:      	add	x9, sp, #0xc
    3ffc:      	ldr	x0, [x0]
    4000:      	add	x1, sp, #0xc
    4004:      	blr	x8
    4008:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    400c:      	add	x8, x0, #0x8
    4010:      	nop
    4014:      	nop
    4018:      	nop
    401c:      	nop
    4020:      	ldaxr	x9, [x8]
    4024:      	add	x9, x9, #0x1
    4028:      	stlxr	w10, x9, [x8]
    402c:      	cbnz	w10, 0x4020 <generic_retkprobe_output+0xd0>
    4030:      	b	0x41f0 <generic_retkprobe_output+0x2a0>
    4034:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    4038:      	mov	x3, xzr
    403c:      	mov	w8, #0x82               // =130
    4040:      	ldr	x0, [x0]
    4044:      	mov	x1, x19
    4048:      	mov	x2, x21
    404c:      	blr	x8
    4050:      	tbnz	x0, #0x3f, 0x4094 <generic_retkprobe_output+0x144>
    4054:      	str	wzr, [sp, #0xc]
    4058:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    405c:      	mov	w8, #0x1                // =1
    4060:      	add	x9, sp, #0xc
    4064:      	ldr	x0, [x0]
    4068:      	add	x1, sp, #0xc
    406c:      	blr	x8
    4070:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    4074:      	add	x8, x0, #0x8
    4078:      	nop
    407c:      	nop
    4080:      	ldaxr	x9, [x8]
    4084:      	add	x9, x9, #0x1
    4088:      	stlxr	w10, x9, [x8]
    408c:      	cbnz	w10, 0x4080 <generic_retkprobe_output+0x130>
    4090:      	b	0x41f0 <generic_retkprobe_output+0x2a0>
    4094:      	mov	x19, x0
    4098:      	str	wzr, [sp, #0xc]
    409c:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    40a0:      	mov	w8, #0x1                // =1
    40a4:      	ldr	x0, [x0]
    40a8:      	add	x9, sp, #0xc
    40ac:      	add	x1, sp, #0xc
    40b0:      	blr	x8
    40b4:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    40b8:      	mov	x8, x19
    40bc:      	cmn	x19, #0xc
    40c0:      	b.gt	0x4134 <generic_retkprobe_output+0x1e4>
    40c4:      	cmn	x8, #0x1c
    40c8:      	b.eq	0x4174 <generic_retkprobe_output+0x224>
    40cc:      	cmn	x8, #0x16
    40d0:      	b.eq	0x418c <generic_retkprobe_output+0x23c>
    40d4:      	cmn	x8, #0x10
    40d8:      	b.ne	0x4184 <generic_retkprobe_output+0x234>
    40dc:      	add	x8, x0, #0x2f0
    40e0:      	b	0x41a0 <generic_retkprobe_output+0x250>
    40e4:      	mov	x19, x0
    40e8:      	str	wzr, [sp, #0xc]
    40ec:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    40f0:      	mov	w8, #0x1                // =1
    40f4:      	ldr	x0, [x0]
    40f8:      	add	x9, sp, #0xc
    40fc:      	add	x1, sp, #0xc
    4100:      	blr	x8
    4104:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    4108:      	mov	x8, x19
    410c:      	cmn	x19, #0xc
    4110:      	b.gt	0x4154 <generic_retkprobe_output+0x204>
    4114:      	cmn	x8, #0x1c
    4118:      	b.eq	0x41b4 <generic_retkprobe_output+0x264>
    411c:      	cmn	x8, #0x16
    4120:      	b.eq	0x41cc <generic_retkprobe_output+0x27c>
    4124:      	cmn	x8, #0x10
    4128:      	b.ne	0x41c4 <generic_retkprobe_output+0x274>
    412c:      	add	x8, x0, #0x2f0
    4130:      	b	0x41e0 <generic_retkprobe_output+0x290>
    4134:      	cmn	x8, #0xb
    4138:      	b.eq	0x417c <generic_retkprobe_output+0x22c>
    413c:      	cmn	x8, #0x7
    4140:      	b.eq	0x4194 <generic_retkprobe_output+0x244>
    4144:      	cmn	x8, #0x2
    4148:      	b.ne	0x4184 <generic_retkprobe_output+0x234>
    414c:      	add	x8, x0, #0x2e0
    4150:      	b	0x41a0 <generic_retkprobe_output+0x250>
    4154:      	cmn	x8, #0xb
    4158:      	b.eq	0x41bc <generic_retkprobe_output+0x26c>
    415c:      	cmn	x8, #0x7
    4160:      	b.eq	0x41d4 <generic_retkprobe_output+0x284>
    4164:      	cmn	x8, #0x2
    4168:      	b.ne	0x41c4 <generic_retkprobe_output+0x274>
    416c:      	add	x8, x0, #0x2e0
    4170:      	b	0x41e0 <generic_retkprobe_output+0x290>
    4174:      	add	x8, x0, #0x300
    4178:      	b	0x41a0 <generic_retkprobe_output+0x250>
    417c:      	add	x8, x0, #0x308
    4180:      	b	0x41a0 <generic_retkprobe_output+0x250>
    4184:      	add	x8, x0, #0x2d8
    4188:      	b	0x41a0 <generic_retkprobe_output+0x250>
    418c:      	add	x8, x0, #0x2f8
    4190:      	b	0x41a0 <generic_retkprobe_output+0x250>
    4194:      	add	x8, x0, #0x2e8
    4198:      	nop
    419c:      	nop
    41a0:      	ldaxr	x9, [x8]
    41a4:      	add	x9, x9, #0x1
    41a8:      	stlxr	w10, x9, [x8]
    41ac:      	cbnz	w10, 0x41a0 <generic_retkprobe_output+0x250>
    41b0:      	b	0x41f0 <generic_retkprobe_output+0x2a0>
    41b4:      	add	x8, x0, #0x300
    41b8:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41bc:      	add	x8, x0, #0x308
    41c0:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41c4:      	add	x8, x0, #0x2d8
    41c8:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41cc:      	add	x8, x0, #0x2f8
    41d0:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41d4:      	add	x8, x0, #0x2e8
    41d8:      	nop
    41dc:      	nop
    41e0:      	ldaxr	x9, [x8]
    41e4:      	add	x9, x9, #0x1
    41e8:      	stlxr	w10, x9, [x8]
    41ec:      	cbnz	w10, 0x41e0 <generic_retkprobe_output+0x290>
    41f0:      	ldp	x20, x19, [sp, #0x20]
    41f4:      	mov	w0, wzr
    41f8:      	ldp	x30, x21, [sp, #0x10]
    41fc:      	add	sp, sp, #0x30
    4200:      	ret

Disassembly of section kprobe.multi/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	sub	sp, sp, #0x150
       4:      	str	x29, [sp, #0x100]
       8:      	stp	x30, x25, [sp, #0x110]
       c:      	stp	x24, x23, [sp, #0x120]
      10:      	stp	x22, x21, [sp, #0x130]
      14:      	stp	x20, x19, [sp, #0x140]
      18:      	ldr	x8, [x0]
      1c:      	str	wzr, [sp, #0x5c]
      20:      	adrp	x24, 0x0 <generic_retkprobe_event>
      24:      	add	x9, sp, #0x5c
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x5c
      30:      	str	x8, [sp, #0x60]
      34:      	mov	w8, #0x1                // =1
      38:      	ldr	x24, [x24]
      3c:      	mov	x0, x24
      40:      	blr	x8
      44:      	cbz	x0, 0x5b0 <generic_retkprobe_event+0x5b0>
      48:      	mov	w8, #0x5ea0             // =24224
      4c:      	mov	x20, x0
      50:      	add	x25, x0, x8
      54:      	mov	w8, #0xae               // =174
      58:      	mov	x0, x19
      5c:      	blr	x8
      60:      	mov	x1, x25
      64:      	mov	w8, #0x1                // =1
      68:      	str	w0, [x1, #0x58]!
      6c:      	adrp	x0, 0x0 <generic_retkprobe_event>
      70:      	ldr	x0, [x0]
      74:      	blr	x8
      78:      	cbz	x0, 0x5b0 <generic_retkprobe_event+0x5b0>
      7c:      	ldr	w8, [x0]
      80:      	mov	x29, x0
      84:      	str	x8, [x20, #0x60]
      88:      	mov	w8, #0xe                // =14
      8c:      	blr	x8
      90:      	cmn	x0, #0x16
      94:      	b.ne	0xb8 <generic_retkprobe_event+0xb8>
      98:      	add	x2, x19, #0xe8
      9c:      	mov	w8, #0x8                // =8
      a0:      	mov	w9, #0x4                // =4
      a4:      	add	x10, sp, #0x98
      a8:      	add	x0, sp, #0x98
      ac:      	mov	w1, #0x8                // =8
      b0:      	blr	x9
      b4:      	ldr	x0, [sp, #0x98]
      b8:      	str	x0, [x20, #0x68]
      bc:      	mov	w8, #0xe                // =14
      c0:      	blr	x8
      c4:      	ldp	x8, x9, [x20, #0x60]
      c8:      	adrp	x22, 0x0 <generic_retkprobe_event>
      cc:      	add	x1, sp, #0x98
      d0:      	str	w0, [x20, #0x7c]
      d4:      	stp	x8, x9, [sp, #0x98]
      d8:      	mov	w8, #0x1                // =1
      dc:      	add	x9, sp, #0x98
      e0:      	ldr	x22, [x22]
      e4:      	mov	x0, x22
      e8:      	blr	x8
      ec:      	cbz	x0, 0x5b0 <generic_retkprobe_event+0x5b0>
      f0:      	ldp	x21, x8, [x0]
      f4:      	add	x9, sp, #0x98
      f8:      	add	x1, sp, #0x98
      fc:      	str	x8, [sp, #0x108]
     100:      	ldr	x8, [x0, #0x10]
     104:      	mov	x0, x22
     108:      	str	x8, [sp, #0x50]
     10c:      	mov	w8, #0x3                // =3
     110:      	blr	x8
     114:      	mov	x22, x20
     118:      	str	x21, [x22, #0x90]!
     11c:      	ldp	w8, w23, [x29, #0x58]
     120:      	cbz	w23, 0x214 <generic_retkprobe_event+0x214>
     124:      	str	w8, [sp, #0x48]
     128:      	str	wzr, [x25]
     12c:      	mov	w8, #0x1                // =1
     130:      	add	x9, sp, #0x6c
     134:      	add	x1, sp, #0x6c
     138:      	mov	x0, x24
     13c:      	str	wzr, [sp, #0x6c]
     140:      	ldr	x25, [sp, #0x60]
     144:      	blr	x8
     148:      	cbz	x0, 0x280 <generic_retkprobe_event+0x280>
     14c:      	mov	w8, #0x5ea0             // =24224
     150:      	mov	w9, #0xc                // =12
     154:      	ldr	w8, [x0, x8]
     158:      	str	x9, [x0, #0x5e78]
     15c:      	str	w8, [x0, #0x98]
     160:      	cbz	w8, 0x2d0 <generic_retkprobe_event+0x2d0>
     164:      	mov	w8, #0x4                // =4
     168:      	add	x21, x8, #0x8
     16c:      	ldr	w8, [x29, #0x60]
     170:      	cmp	w8, #0xb
     174:      	b.eq	0x294 <generic_retkprobe_event+0x294>
     178:      	cmp	w8, #0xa
     17c:      	b.ne	0x1b8 <generic_retkprobe_event+0x1b8>
     180:      	ldr	w8, [x20, #0x10]
     184:      	ldr	w9, [x20, #0x7c]
     188:      	adrp	x0, 0x0 <generic_retkprobe_event>
     18c:      	mov	x3, xzr
     190:      	add	x10, sp, #0x98
     194:      	add	x1, sp, #0x60
     198:      	stp	w8, w9, [sp, #0x98]
     19c:      	ldr	x8, [x20, #0x18]
     1a0:      	add	x9, sp, #0x60
     1a4:      	add	x2, sp, #0x98
     1a8:      	str	x8, [sp, #0xa0]
     1ac:      	mov	w8, #0x2                // =2
     1b0:      	ldr	x0, [x0]
     1b4:      	blr	x8
     1b8:      	ldr	w8, [sp, #0x48]
     1bc:      	and	x24, x21, #0x1fff
     1c0:      	cmp	w8, #0x3
     1c4:      	b.eq	0x220 <generic_retkprobe_event+0x220>
     1c8:      	cmp	w8, #0x2
     1cc:      	b.ne	0x348 <generic_retkprobe_event+0x348>
     1d0:      	str	wzr, [x22, x24]
     1d4:      	add	x21, x24, #0x4
     1d8:      	mov	w8, #0xfff              // =4095
     1dc:      	ldr	x2, [sp, #0x108]
     1e0:      	mov	w25, #0x4               // =4
     1e4:      	add	x23, x22, x21
     1e8:      	ldr	x24, [sp, #0x60]
     1ec:      	add	x0, x23, #0x8
     1f0:      	cmp	x24, #0xfff
     1f4:      	csel	x22, x24, x8, lo
     1f8:      	mov	w8, #0x4                // =4
     1fc:      	mov	w1, w22
     200:      	blr	x8
     204:      	tbnz	w0, #0x1f, 0x2c0 <generic_retkprobe_event+0x2c0>
     208:      	add	x25, x22, #0x8
     20c:      	str	w22, [x23, #0x4]
     210:      	b	0x2c4 <generic_retkprobe_event+0x2c4>
     214:      	mov	w24, #0x8               // =8
     218:      	cmp	w8, #0x3
     21c:      	b.ne	0x1c8 <generic_retkprobe_event+0x1c8>
     220:      	ldr	x8, [sp, #0x50]
     224:      	add	x25, x24, #0x4
     228:      	str	wzr, [x22, x24]
     22c:      	cbz	x8, 0x318 <generic_retkprobe_event+0x318>
     230:      	ldr	x2, [sp, #0x108]
     234:      	ldr	x21, [sp, #0x60]
     238:      	mov	w8, #0x10               // =16
     23c:      	mov	w9, #0x4                // =4
     240:      	add	x10, sp, #0x98
     244:      	add	x0, sp, #0x98
     248:      	mov	w1, #0x10               // =16
     24c:      	blr	x9
     250:      	tbnz	w0, #0x1f, 0x338 <generic_retkprobe_event+0x338>
     254:      	ldr	x8, [sp, #0xa0]
     258:      	str	x29, [sp, #0x40]
     25c:      	cmp	x8, x21
     260:      	csel	x23, x8, x21, lo
     264:      	cmp	x21, #0x0
     268:      	csel	x29, x8, x23, eq
     26c:      	cmp	x29, #0xffe
     270:      	b.ls	0x5e8 <generic_retkprobe_event+0x5e8>
     274:      	ldr	x29, [sp, #0x40]
     278:      	mov	w8, #-0x3               // =-3
     27c:      	b	0x33c <generic_retkprobe_event+0x33c>
     280:      	mov	x8, xzr
     284:      	add	x21, x8, #0x8
     288:      	ldr	w8, [x29, #0x60]
     28c:      	cmp	w8, #0xb
     290:      	b.ne	0x178 <generic_retkprobe_event+0x178>
     294:      	adrp	x0, 0x0 <generic_retkprobe_event>
     298:      	mov	w8, #0x3                // =3
     29c:      	add	x9, sp, #0x60
     2a0:      	ldr	x0, [x0]
     2a4:      	add	x1, sp, #0x60
     2a8:      	blr	x8
     2ac:      	ldr	w8, [sp, #0x48]
     2b0:      	and	x24, x21, #0x1fff
     2b4:      	cmp	w8, #0x3
     2b8:      	b.ne	0x1c8 <generic_retkprobe_event+0x1c8>
     2bc:      	b	0x220 <generic_retkprobe_event+0x220>
     2c0:      	mov	w24, #-0x2              // =-2
     2c4:      	str	w24, [x23]
     2c8:      	add	x24, x25, x21
     2cc:      	b	0x348 <generic_retkprobe_event+0x348>
     2d0:      	add	x9, sp, #0xe0
     2d4:      	add	x8, x0, #0x9c
     2d8:      	add	x21, sp, #0xe0
     2dc:      	str	x25, [sp, #0x98]
     2e0:      	str	x29, [sp, #0x40]
     2e4:      	cmp	w23, #0x17
     2e8:      	stp	x8, x0, [sp, #0x20]
     2ec:      	str	xzr, [x9, #0x8]
     2f0:      	b.le	0x5cc <generic_retkprobe_event+0x5cc>
     2f4:      	cmp	w23, #0x18
     2f8:      	b.eq	0x680 <generic_retkprobe_event+0x680>
     2fc:      	cmp	w23, #0x25
     300:      	b.eq	0x6d0 <generic_retkprobe_event+0x6d0>
     304:      	cmp	w23, #0x2a
     308:      	b.ne	0xbdc <generic_retkprobe_event+0xbdc>
     30c:      	stp	xzr, x25, [sp, #0x70]
     310:      	add	x21, sp, #0x70
     314:      	b	0x728 <generic_retkprobe_event+0x728>
     318:      	mov	x24, x22
     31c:      	str	x29, [sp, #0x40]
     320:      	mov	x29, xzr
     324:      	add	x8, x24, x25
     328:      	stp	w29, w29, [x8]
     32c:      	add	x8, x29, #0x8
     330:      	ldr	x29, [sp, #0x40]
     334:      	b	0x344 <generic_retkprobe_event+0x344>
     338:      	mov	w8, #-0x2               // =-2
     33c:      	str	w8, [x22, x25]
     340:      	mov	w8, #0x4                // =4
     344:      	add	x24, x8, x25
     348:      	mov	w8, #0x23               // =35
     34c:      	blr	x8
     350:      	str	x0, [sp, #0x98]
     354:      	add	x8, x0, #0x8d4
     358:      	mov	w9, #0x4                // =4
     35c:      	mov	w10, #0x71              // =113
     360:      	add	x11, sp, #0x70
     364:      	add	x0, sp, #0x70
     368:      	mov	w1, #0x4                // =4
     36c:      	ldr	x8, [sp, #0x98]
     370:      	add	x2, x8, #0x8d4
     374:      	blr	x10
     378:      	ldr	w8, [sp, #0x70]
     37c:      	adrp	x22, 0x0 <generic_retkprobe_event>
     380:      	add	x9, sp, #0xe8
     384:      	add	x1, sp, #0xe8
     388:      	str	w8, [sp, #0xe8]
     38c:      	mov	w8, #0x1                // =1
     390:      	ldr	x22, [x22]
     394:      	mov	x0, x22
     398:      	blr	x8
     39c:      	cbz	x0, 0x3ac <generic_retkprobe_event+0x3ac>
     3a0:      	ldr	x8, [x0, #0x8]
     3a4:      	mov	x23, x0
     3a8:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     3ac:      	ldr	x8, [sp, #0x98]
     3b0:      	mov	w9, #0x8                // =8
     3b4:      	mov	w10, #0x71              // =113
     3b8:      	add	x11, sp, #0x98
     3bc:      	add	x0, sp, #0x98
     3c0:      	mov	w1, #0x8                // =8
     3c4:      	add	x8, x8, #0x8e0
     3c8:      	ldr	x8, [sp, #0x98]
     3cc:      	add	x2, x8, #0x8e0
     3d0:      	blr	x10
     3d4:      	ldr	x8, [sp, #0x98]
     3d8:      	cbz	x8, 0x554 <generic_retkprobe_event+0x554>
     3dc:      	add	x8, x8, #0x8d4
     3e0:      	mov	w9, #0x4                // =4
     3e4:      	mov	w10, #0x71              // =113
     3e8:      	add	x11, sp, #0x70
     3ec:      	ldr	x8, [sp, #0x98]
     3f0:      	add	x0, sp, #0x70
     3f4:      	mov	w1, #0x4                // =4
     3f8:      	add	x2, x8, #0x8d4
     3fc:      	blr	x10
     400:      	ldr	w8, [sp, #0x70]
     404:      	add	x9, sp, #0xe8
     408:      	add	x1, sp, #0xe8
     40c:      	mov	x0, x22
     410:      	str	w8, [sp, #0xe8]
     414:      	mov	w8, #0x1                // =1
     418:      	blr	x8
     41c:      	cbz	x0, 0x42c <generic_retkprobe_event+0x42c>
     420:      	ldr	x8, [x0, #0x8]
     424:      	mov	x23, x0
     428:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     42c:      	ldr	x8, [sp, #0x98]
     430:      	mov	w9, #0x8                // =8
     434:      	mov	w10, #0x71              // =113
     438:      	add	x11, sp, #0x98
     43c:      	add	x0, sp, #0x98
     440:      	mov	w1, #0x8                // =8
     444:      	add	x8, x8, #0x8e0
     448:      	ldr	x8, [sp, #0x98]
     44c:      	add	x2, x8, #0x8e0
     450:      	blr	x10
     454:      	ldr	x8, [sp, #0x98]
     458:      	cbz	x8, 0x554 <generic_retkprobe_event+0x554>
     45c:      	add	x8, x8, #0x8d4
     460:      	mov	w9, #0x4                // =4
     464:      	mov	w10, #0x71              // =113
     468:      	add	x11, sp, #0x70
     46c:      	ldr	x8, [sp, #0x98]
     470:      	add	x0, sp, #0x70
     474:      	mov	w1, #0x4                // =4
     478:      	add	x2, x8, #0x8d4
     47c:      	blr	x10
     480:      	ldr	w8, [sp, #0x70]
     484:      	add	x9, sp, #0xe8
     488:      	add	x1, sp, #0xe8
     48c:      	mov	x0, x22
     490:      	str	w8, [sp, #0xe8]
     494:      	mov	w8, #0x1                // =1
     498:      	blr	x8
     49c:      	cbz	x0, 0x4ac <generic_retkprobe_event+0x4ac>
     4a0:      	ldr	x8, [x0, #0x8]
     4a4:      	mov	x23, x0
     4a8:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     4ac:      	ldr	x8, [sp, #0x98]
     4b0:      	mov	w9, #0x8                // =8
     4b4:      	mov	w10, #0x71              // =113
     4b8:      	add	x11, sp, #0x98
     4bc:      	add	x0, sp, #0x98
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	add	x8, x8, #0x8e0
     4c8:      	ldr	x8, [sp, #0x98]
     4cc:      	add	x2, x8, #0x8e0
     4d0:      	blr	x10
     4d4:      	ldr	x8, [sp, #0x98]
     4d8:      	cbz	x8, 0x554 <generic_retkprobe_event+0x554>
     4dc:      	add	x8, x8, #0x8d4
     4e0:      	mov	w9, #0x4                // =4
     4e4:      	mov	w10, #0x71              // =113
     4e8:      	add	x11, sp, #0x70
     4ec:      	ldr	x8, [sp, #0x98]
     4f0:      	add	x0, sp, #0x70
     4f4:      	mov	w1, #0x4                // =4
     4f8:      	add	x2, x8, #0x8d4
     4fc:      	blr	x10
     500:      	ldr	w8, [sp, #0x70]
     504:      	add	x9, sp, #0xe8
     508:      	add	x1, sp, #0xe8
     50c:      	mov	x0, x22
     510:      	str	w8, [sp, #0xe8]
     514:      	mov	w8, #0x1                // =1
     518:      	blr	x8
     51c:      	cbz	x0, 0x52c <generic_retkprobe_event+0x52c>
     520:      	ldr	x8, [x0, #0x8]
     524:      	mov	x23, x0
     528:      	cbnz	x8, 0x558 <generic_retkprobe_event+0x558>
     52c:      	ldr	x8, [sp, #0x98]
     530:      	mov	w9, #0x8                // =8
     534:      	mov	w10, #0x71              // =113
     538:      	add	x11, sp, #0x98
     53c:      	add	x0, sp, #0x98
     540:      	mov	w1, #0x8                // =8
     544:      	add	x8, x8, #0x8e0
     548:      	ldr	x8, [sp, #0x98]
     54c:      	add	x2, x8, #0x8e0
     550:      	blr	x10
     554:      	mov	x23, xzr
     558:      	mov	w8, #0x10d              // =269
     55c:      	stp	w8, w24, [x20]
     560:      	mov	w8, #0x7d               // =125
     564:      	blr	x8
     568:      	str	x0, [x20, #0x8]
     56c:      	cbz	x23, 0x580 <generic_retkprobe_event+0x580>
     570:      	ldr	w8, [x23]
     574:      	str	w8, [x20, #0x10]
     578:      	ldr	x8, [x23, #0x8]
     57c:      	str	x8, [x20, #0x18]
     580:      	str	wzr, [x20, #0x14]
     584:      	adrp	x1, 0x0 <generic_retkprobe_event>
     588:      	mov	w9, #0xc                // =12
     58c:      	mov	x0, x19
     590:      	ldr	w8, [x29]
     594:      	str	w24, [x20, #0x4]
     598:      	mov	w2, #0x3                // =3
     59c:      	str	x8, [x20, #0x60]
     5a0:      	mov	w8, #0x3                // =3
     5a4:      	ldr	x1, [x1]
     5a8:      	blr	x9
     5ac:      	mov	w0, #0x1                // =1
     5b0:      	ldp	x20, x19, [sp, #0x140]
     5b4:      	ldr	x29, [sp, #0x100]
     5b8:      	ldp	x22, x21, [sp, #0x130]
     5bc:      	ldp	x24, x23, [sp, #0x120]
     5c0:      	ldp	x30, x25, [sp, #0x110]
     5c4:      	add	sp, sp, #0x150
     5c8:      	ret
     5cc:      	cmp	w23, #0xf
     5d0:      	b.eq	0x700 <generic_retkprobe_event+0x700>
     5d4:      	cmp	w23, #0x10
     5d8:      	b.ne	0xbdc <generic_retkprobe_event+0xbdc>
     5dc:      	add	x21, sp, #0xf8
     5e0:      	add	x23, sp, #0xe0
     5e4:      	b	0x6a8 <generic_retkprobe_event+0x6a8>
     5e8:      	mov	x8, x22
     5ec:      	add	x22, x24, #0xc
     5f0:      	mov	w9, #0x4                // =4
     5f4:      	mov	w1, w29
     5f8:      	mov	x24, x8
     5fc:      	add	x0, x8, x22
     600:      	ldr	x8, [sp, #0x98]
     604:      	ldr	x2, [sp, #0x98]
     608:      	blr	x9
     60c:      	tbnz	w0, #0x1f, 0x670 <generic_retkprobe_event+0x670>
     610:      	cbz	x21, 0x61c <generic_retkprobe_event+0x61c>
     614:      	subs	x21, x21, x23
     618:      	b.eq	0xf28 <generic_retkprobe_event+0xf28>
     61c:      	ldr	x8, [sp, #0x50]
     620:      	cmp	x8, #0x1
     624:      	b.eq	0x324 <generic_retkprobe_event+0x324>
     628:      	ldr	x8, [sp, #0x108]
     62c:      	mov	w9, #0x4                // =4
     630:      	add	x10, sp, #0x98
     634:      	add	x0, sp, #0x98
     638:      	mov	w1, #0x10               // =16
     63c:      	add	x2, x8, #0x10
     640:      	mov	w8, #0x10               // =16
     644:      	blr	x9
     648:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
     64c:      	ldr	x8, [sp, #0xa0]
     650:      	cmp	x8, x21
     654:      	csel	x23, x8, x21, lo
     658:      	cmp	x21, #0x0
     65c:      	csel	x10, x8, x23, eq
     660:      	cmp	x10, #0xffe
     664:      	b.ls	0x1004 <generic_retkprobe_event+0x1004>
     668:      	mov	w8, #-0x3               // =-3
     66c:      	b	0x12ec <generic_retkprobe_event+0x12ec>
     670:      	ldr	x29, [sp, #0x40]
     674:      	mov	w8, #-0x2               // =-2
     678:      	mov	x22, x24
     67c:      	b	0x33c <generic_retkprobe_event+0x33c>
     680:      	add	x21, sp, #0xf8
     684:      	mov	w8, #0x8                // =8
     688:      	mov	w9, #0x4                // =4
     68c:      	ldr	x2, [sp, #0x98]
     690:      	add	x0, sp, #0xf8
     694:      	mov	w1, #0x8                // =8
     698:      	blr	x9
     69c:      	add	x23, sp, #0xe0
     6a0:      	ldr	x8, [x23, #0x18]
     6a4:      	str	x8, [sp, #0x98]
     6a8:      	mov	w8, #0x8                // =8
     6ac:      	mov	w9, #0x4                // =4
     6b0:      	add	x10, sp, #0x98
     6b4:      	add	x0, sp, #0xf8
     6b8:      	add	x2, sp, #0x98
     6bc:      	mov	w1, #0x8                // =8
     6c0:      	blr	x9
     6c4:      	ldr	x8, [x23, #0x18]
     6c8:      	add	x21, x8, #0x40
     6cc:      	b	0x728 <generic_retkprobe_event+0x728>
     6d0:      	add	x8, x25, #0x40
     6d4:      	mov	w9, #0x8                // =8
     6d8:      	mov	w10, #0x4               // =4
     6dc:      	str	x8, [sp, #0x98]
     6e0:      	add	x11, sp, #0xf8
     6e4:      	add	x0, sp, #0xf8
     6e8:      	mov	w1, #0x8                // =8
     6ec:      	ldr	x2, [sp, #0x98]
     6f0:      	blr	x10
     6f4:      	ldr	x8, [x21, #0x18]
     6f8:      	add	x21, x8, #0x40
     6fc:      	b	0x728 <generic_retkprobe_event+0x728>
     700:      	mov	w8, #0x8                // =8
     704:      	mov	w9, #0x4                // =4
     708:      	add	x10, sp, #0xe8
     70c:      	add	x11, sp, #0x98
     710:      	add	x0, sp, #0xe8
     714:      	add	x2, sp, #0x98
     718:      	mov	w1, #0x8                // =8
     71c:      	blr	x9
     720:      	ldr	x21, [x21, #0x8]
     724:      	cbz	x21, 0xdb0 <generic_retkprobe_event+0xdb0>
     728:      	str	wzr, [sp, #0x84]
     72c:      	adrp	x0, 0x0 <generic_retkprobe_event>
     730:      	mov	w8, #0x1                // =1
     734:      	add	x9, sp, #0x84
     738:      	ldr	x0, [x0]
     73c:      	add	x1, sp, #0x84
     740:      	blr	x8
     744:      	cbz	x0, 0xd8c <generic_retkprobe_event+0xd8c>
     748:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     74c:      	str	x22, [sp, #0x10]
     750:      	mov	x23, x0
     754:      	str	x8, [sp, #0x30]
     758:      	mov	w8, #0x23               // =35
     75c:      	blr	x8
     760:      	add	x2, x0, #0xb30
     764:      	mov	w24, #0x8               // =8
     768:      	add	x8, sp, #0x88
     76c:      	mov	w9, #0x4                // =4
     770:      	add	x0, sp, #0x88
     774:      	mov	w1, #0x8                // =8
     778:      	mov	w25, #0x4               // =4
     77c:      	blr	x9
     780:      	ldr	x29, [sp, #0x88]
     784:      	str	x21, [sp, #0x8]
     788:      	add	x2, x21, #0x8
     78c:      	mov	w9, #0x4                // =4
     790:      	add	x0, sp, #0x90
     794:      	mov	w1, #0x8                // =8
     798:      	add	x8, x29, #0x18
     79c:      	str	x8, [sp, #0x38]
     7a0:      	add	x8, sp, #0x90
     7a4:      	str	x2, [sp, #0x18]
     7a8:      	blr	x9
     7ac:      	ldr	x21, [sp, #0x90]
     7b0:      	add	x22, sp, #0x98
     7b4:      	add	x0, sp, #0x98
     7b8:      	mov	w1, #0x8                // =8
     7bc:      	add	x2, x21, #0x10
     7c0:      	blr	x25
     7c4:      	ldr	x8, [sp, #0x98]
     7c8:      	cbz	x8, 0x7d8 <generic_retkprobe_event+0x7d8>
     7cc:      	ldr	x9, [sp, #0x30]
     7d0:      	mov	w8, #0x1000             // =4096
     7d4:      	b	0x820 <generic_retkprobe_event+0x820>
     7d8:      	add	x2, x21, #0x18
     7dc:      	mov	w8, #0x8                // =8
     7e0:      	mov	w9, #0x4                // =4
     7e4:      	add	x10, sp, #0x98
     7e8:      	add	x0, sp, #0x98
     7ec:      	mov	w1, #0x8                // =8
     7f0:      	blr	x9
     7f4:      	ldr	x8, [sp, #0x98]
     7f8:      	cmp	x8, x21
     7fc:      	b.eq	0x7cc <generic_retkprobe_event+0x7cc>
     800:      	mov	w8, #0x2964             // =10596
     804:      	add	x9, x23, #0xff6
     808:      	strh	w8, [x23, #0xffe]
     80c:      	adrp	x8, 0x0 <generic_retkprobe_event>
     810:      	add	x8, x8, #0x0
     814:      	ldr	x8, [x8]
     818:      	str	x8, [x9]
     81c:      	mov	w8, #0xff6              // =4086
     820:      	stp	xzr, xzr, [sp, #0x98]
     824:      	add	x2, x29, #0x20
     828:      	mov	w21, #0x8               // =8
     82c:      	add	x0, sp, #0x98
     830:      	mov	w1, #0x8                // =8
     834:      	add	x25, x22, #0x8
     838:      	stp	x23, xzr, [sp, #0xa8]
     83c:      	add	x24, x22, #0x18
     840:      	add	x23, x22, #0x20
     844:      	stp	xzr, xzr, [sp, #0xb8]
     848:      	mov	w29, #0x4               // =4
     84c:      	str	x9, [sp, #0x30]
     850:      	str	x9, [sp, #0xc8]
     854:      	str	w8, [sp, #0xd0]
     858:      	mov	w8, #0x4                // =4
     85c:      	strb	wzr, [sp, #0xd4]
     860:      	blr	x8
     864:      	ldr	x2, [sp, #0x38]
     868:      	mov	w8, #0x4                // =4
     86c:      	mov	x0, x25
     870:      	mov	w1, #0x8                // =8
     874:      	blr	x8
     878:      	ldr	x2, [sp, #0x18]
     87c:      	mov	w8, #0x4                // =4
     880:      	mov	x0, x24
     884:      	mov	w1, #0x8                // =8
     888:      	str	x24, [sp, #0x38]
     88c:      	blr	x8
     890:      	ldr	x2, [sp, #0x8]
     894:      	mov	x0, x23
     898:      	mov	w1, #0x8                // =8
     89c:      	blr	x29
     8a0:      	ldr	x8, [sp, #0xb8]
     8a4:      	sub	x8, x8, #0x20
     8a8:      	str	x8, [sp, #0xc0]
     8ac:      	adrp	x8, 0x0 <generic_retkprobe_event>
     8b0:      	ldr	x8, [x8]
     8b4:      	ldrb	w8, [x8]
     8b8:      	cbz	w8, 0xa4c <generic_retkprobe_event+0xa4c>
     8bc:      	mov	w23, #0x80              // =128
     8c0:      	mov	w25, #0x8               // =8
     8c4:      	ldp	x29, x2, [sp, #0xb0]
     8c8:      	ldp	x8, x9, [sp, #0x98]
     8cc:      	cmp	x29, x8
     8d0:      	ccmp	x2, x9, #0x0, eq
     8d4:      	b.eq	0xc74 <generic_retkprobe_event+0xc74>
     8d8:      	ldr	x21, [sp, #0xc0]
     8dc:      	mov	w8, #0x4                // =4
     8e0:      	add	x9, sp, #0xd8
     8e4:      	add	x0, sp, #0xd8
     8e8:      	mov	w1, #0x8                // =8
     8ec:      	blr	x8
     8f0:      	ldr	x8, [sp, #0xd8]
     8f4:      	add	x24, sp, #0xe0
     8f8:      	cmp	x29, x8
     8fc:      	b.eq	0x9f4 <generic_retkprobe_event+0x9f4>
     900:      	add	x22, x29, #0x18
     904:      	mov	w8, #0x4                // =4
     908:      	add	x9, sp, #0xf8
     90c:      	add	x0, sp, #0xf8
     910:      	mov	w1, #0x8                // =8
     914:      	mov	x2, x22
     918:      	blr	x8
     91c:      	ldr	x8, [x24, #0x18]
     920:      	cmp	x8, x29
     924:      	b.eq	0x9f4 <generic_retkprobe_event+0x9f4>
     928:      	mov	w8, #0x4                // =4
     92c:      	add	x9, sp, #0xe0
     930:      	add	x0, sp, #0xe0
     934:      	mov	w1, #0x8                // =8
     938:      	mov	x2, x22
     93c:      	blr	x8
     940:      	add	x2, x29, #0x20
     944:      	mov	w8, #0x4                // =4
     948:      	mov	w9, #0x10               // =16
     94c:      	add	x10, sp, #0xe8
     950:      	add	x0, sp, #0xe8
     954:      	mov	w1, #0x10               // =16
     958:      	blr	x8
     95c:      	ldr	w21, [sp, #0xec]
     960:      	ldr	x8, [sp, #0xa8]
     964:      	add	x29, sp, #0xe0
     968:      	ldr	x10, [sp, #0xc8]
     96c:      	sub	x12, x10, x8
     970:      	ldr	w22, [sp, #0xd0]
     974:      	subs	w10, w21, w22
     978:      	ldr	x9, [x24, #0x10]
     97c:      	csel	w10, wzr, w10, lo
     980:      	cmp	w22, w21
     984:      	csel	w11, w22, w21, lo
     988:      	cinc	w13, w11, hi
     98c:      	sub	w14, w22, w13
     990:      	subs	x12, x12, x13
     994:      	str	w14, [sp, #0xd0]
     998:      	b.lo	0xc88 <generic_retkprobe_event+0xc88>
     99c:      	cmp	x12, #0xfff
     9a0:      	b.hi	0xc88 <generic_retkprobe_event+0xc88>
     9a4:      	cmp	w22, w21
     9a8:      	b.ls	0x9b4 <generic_retkprobe_event+0x9b4>
     9ac:      	mov	w13, #0x2f              // =47
     9b0:      	strb	w13, [x8, x12]
     9b4:      	add	x29, x8, x12
     9b8:      	cmp	w22, w21
     9bc:      	add	x2, x9, x10
     9c0:      	and	w1, w11, #0xff
     9c4:      	mov	w8, #0x4                // =4
     9c8:      	cinc	x0, x29, hi
     9cc:      	blr	x8
     9d0:      	cmp	w22, w21
     9d4:      	str	x29, [sp, #0xc8]
     9d8:      	add	x29, sp, #0xe0
     9dc:      	b.ls	0xc88 <generic_retkprobe_event+0xc88>
     9e0:      	ldr	x8, [x29]
     9e4:      	str	x8, [sp, #0xb0]
     9e8:      	subs	w23, w23, #0x1
     9ec:      	b.ne	0x8c4 <generic_retkprobe_event+0x8c4>
     9f0:      	b	0xc88 <generic_retkprobe_event+0xc88>
     9f4:      	add	x2, x21, #0x10
     9f8:      	mov	w8, #0x4                // =4
     9fc:      	add	x9, sp, #0xf8
     a00:      	add	x0, sp, #0xf8
     a04:      	mov	w1, #0x8                // =8
     a08:      	blr	x8
     a0c:      	ldr	x8, [sp, #0xc0]
     a10:      	ldr	x9, [x24, #0x18]
     a14:      	add	x29, sp, #0xe0
     a18:      	cmp	x8, x9
     a1c:      	b.eq	0xc80 <generic_retkprobe_event+0xc80>
     a20:      	ldr	x0, [sp, #0x38]
     a24:      	add	x2, x21, #0x18
     a28:      	mov	w8, #0x4                // =4
     a2c:      	mov	w1, #0x8                // =8
     a30:      	blr	x8
     a34:      	ldr	x8, [x29, #0x18]
     a38:      	add	x9, x8, #0x20
     a3c:      	stp	x9, x8, [sp, #0xb8]
     a40:      	subs	w23, w23, #0x1
     a44:      	b.ne	0x8c4 <generic_retkprobe_event+0x8c4>
     a48:      	b	0xc88 <generic_retkprobe_event+0xc88>
     a4c:      	mov	w23, #0x80              // =128
     a50:      	mov	w25, #0x8               // =8
     a54:      	ldp	x29, x2, [sp, #0xb0]
     a58:      	ldp	x8, x9, [sp, #0x98]
     a5c:      	cmp	x29, x8
     a60:      	ccmp	x2, x9, #0x0, eq
     a64:      	b.eq	0xc74 <generic_retkprobe_event+0xc74>
     a68:      	ldr	x21, [sp, #0xc0]
     a6c:      	mov	w8, #0x4                // =4
     a70:      	add	x9, sp, #0xd8
     a74:      	add	x0, sp, #0xd8
     a78:      	mov	w1, #0x8                // =8
     a7c:      	blr	x8
     a80:      	ldr	x8, [sp, #0xd8]
     a84:      	add	x24, sp, #0xe0
     a88:      	cmp	x29, x8
     a8c:      	b.eq	0xb84 <generic_retkprobe_event+0xb84>
     a90:      	add	x22, x29, #0x18
     a94:      	mov	w8, #0x4                // =4
     a98:      	add	x9, sp, #0xf8
     a9c:      	add	x0, sp, #0xf8
     aa0:      	mov	w1, #0x8                // =8
     aa4:      	mov	x2, x22
     aa8:      	blr	x8
     aac:      	ldr	x8, [x24, #0x18]
     ab0:      	cmp	x8, x29
     ab4:      	b.eq	0xb84 <generic_retkprobe_event+0xb84>
     ab8:      	mov	w8, #0x4                // =4
     abc:      	add	x9, sp, #0xe0
     ac0:      	add	x0, sp, #0xe0
     ac4:      	mov	w1, #0x8                // =8
     ac8:      	mov	x2, x22
     acc:      	blr	x8
     ad0:      	add	x2, x29, #0x20
     ad4:      	mov	w8, #0x4                // =4
     ad8:      	mov	w9, #0x10               // =16
     adc:      	add	x10, sp, #0xe8
     ae0:      	add	x0, sp, #0xe8
     ae4:      	mov	w1, #0x10               // =16
     ae8:      	blr	x8
     aec:      	ldr	w21, [sp, #0xec]
     af0:      	ldr	x8, [sp, #0xa8]
     af4:      	add	x29, sp, #0xe0
     af8:      	ldr	x10, [sp, #0xc8]
     afc:      	sub	x12, x10, x8
     b00:      	ldr	w22, [sp, #0xd0]
     b04:      	subs	w10, w21, w22
     b08:      	ldr	x9, [x24, #0x10]
     b0c:      	csel	w10, wzr, w10, lo
     b10:      	cmp	w22, w21
     b14:      	csel	w11, w22, w21, lo
     b18:      	cinc	w13, w11, hi
     b1c:      	sub	w14, w22, w13
     b20:      	subs	x12, x12, x13
     b24:      	str	w14, [sp, #0xd0]
     b28:      	b.lo	0xc88 <generic_retkprobe_event+0xc88>
     b2c:      	cmp	x12, #0xfff
     b30:      	b.hi	0xc88 <generic_retkprobe_event+0xc88>
     b34:      	cmp	w22, w21
     b38:      	b.ls	0xb44 <generic_retkprobe_event+0xb44>
     b3c:      	mov	w13, #0x2f              // =47
     b40:      	strb	w13, [x8, x12]
     b44:      	add	x29, x8, x12
     b48:      	cmp	w22, w21
     b4c:      	add	x2, x9, x10
     b50:      	and	w1, w11, #0xff
     b54:      	mov	w8, #0x4                // =4
     b58:      	cinc	x0, x29, hi
     b5c:      	blr	x8
     b60:      	cmp	w22, w21
     b64:      	str	x29, [sp, #0xc8]
     b68:      	add	x29, sp, #0xe0
     b6c:      	b.ls	0xc88 <generic_retkprobe_event+0xc88>
     b70:      	ldr	x8, [x29]
     b74:      	str	x8, [sp, #0xb0]
     b78:      	subs	w23, w23, #0x1
     b7c:      	b.ne	0xa54 <generic_retkprobe_event+0xa54>
     b80:      	b	0xc88 <generic_retkprobe_event+0xc88>
     b84:      	add	x2, x21, #0x10
     b88:      	mov	w8, #0x4                // =4
     b8c:      	add	x9, sp, #0xf8
     b90:      	add	x0, sp, #0xf8
     b94:      	mov	w1, #0x8                // =8
     b98:      	blr	x8
     b9c:      	ldr	x8, [sp, #0xc0]
     ba0:      	ldr	x9, [x24, #0x18]
     ba4:      	add	x29, sp, #0xe0
     ba8:      	cmp	x8, x9
     bac:      	b.eq	0xc80 <generic_retkprobe_event+0xc80>
     bb0:      	ldr	x0, [sp, #0x38]
     bb4:      	add	x2, x21, #0x18
     bb8:      	mov	w8, #0x4                // =4
     bbc:      	mov	w1, #0x8                // =8
     bc0:      	blr	x8
     bc4:      	ldr	x8, [x29, #0x18]
     bc8:      	add	x9, x8, #0x20
     bcc:      	stp	x9, x8, [sp, #0xb8]
     bd0:      	subs	w23, w23, #0x1
     bd4:      	b.ne	0xa54 <generic_retkprobe_event+0xa54>
     bd8:      	b	0xc88 <generic_retkprobe_event+0xc88>
     bdc:      	cmp	w23, #0x2c
     be0:      	b.hi	0xdb0 <generic_retkprobe_event+0xdb0>
     be4:      	mov	x9, #0x7cf2             // =31986
     be8:      	mov	w8, #0x1                // =1
     bec:      	movk	x9, #0xf202, lsl #16
     bf0:      	lsl	x8, x8, x23
     bf4:      	movk	x9, #0x11c1, lsl #32
     bf8:      	tst	x8, x9
     bfc:      	b.eq	0xdb0 <generic_retkprobe_event+0xdb0>
     c00:      	add	x8, sp, #0xe0
     c04:      	str	wzr, [sp, #0xe0]
     c08:      	add	x9, sp, #0xe0
     c0c:      	add	x1, sp, #0xe0
     c10:      	str	x25, [x8, #0x18]
     c14:      	mov	w8, #0x1                // =1
     c18:      	mov	x0, x24
     c1c:      	blr	x8
     c20:      	cbz	x0, 0x15d0 <generic_retkprobe_event+0x15d0>
     c24:      	add	x25, sp, #0xe0
     c28:      	mov	x29, xzr
     c2c:      	cmp	w23, #0x10
     c30:      	b.le	0xe14 <generic_retkprobe_event+0xe14>
     c34:      	cmp	w23, #0x1e
     c38:      	b.le	0xf30 <generic_retkprobe_event+0xf30>
     c3c:      	cmp	w23, #0x26
     c40:      	b.gt	0x12f8 <generic_retkprobe_event+0x12f8>
     c44:      	ldr	x0, [sp, #0x20]
     c48:      	sub	w8, w23, #0x1f
     c4c:      	cmp	w8, #0x2
     c50:      	b.hs	0x16b0 <generic_retkprobe_event+0x16b0>
     c54:      	mov	w8, #0x1                // =1
     c58:      	add	x9, sp, #0xf8
     c5c:      	mov	w10, #0x4               // =4
     c60:      	add	x2, sp, #0xf8
     c64:      	mov	w1, #0x1                // =1
     c68:      	mov	w29, #0x4               // =4
     c6c:      	blr	x10
     c70:      	b	0xd68 <generic_retkprobe_event+0xd68>
     c74:      	mov	w8, #0x1                // =1
     c78:      	add	x29, sp, #0xe0
     c7c:      	b	0xc84 <generic_retkprobe_event+0xc84>
     c80:      	mov	w8, #0x1                // =1
     c84:      	strb	w8, [sp, #0xd4]
     c88:      	ldr	x8, [sp, #0xc8]
     c8c:      	ldr	x2, [sp, #0x30]
     c90:      	cmp	x8, x2
     c94:      	b.eq	0xcc8 <generic_retkprobe_event+0xcc8>
     c98:      	ldrb	w9, [sp, #0xd4]
     c9c:      	mov	w11, #0x1000            // =4096
     ca0:      	cmp	w9, #0x0
     ca4:      	ldr	w9, [sp, #0xd0]
     ca8:      	cset	w10, eq
     cac:      	sub	w11, w11, w9
     cb0:      	cmp	w9, #0x0
     cb4:      	csel	w9, w11, w9, gt
     cb8:      	cbz	x8, 0xd88 <generic_retkprobe_event+0xd88>
     cbc:      	lsl	w23, w10, #1
     cc0:      	mov	x2, x8
     cc4:      	b	0xcd0 <generic_retkprobe_event+0xcd0>
     cc8:      	mov	w23, wzr
     ccc:      	mov	w9, wzr
     cd0:      	ldr	x21, [sp, #0x28]
     cd4:      	and	w22, w9, #0xfff
     cd8:      	mov	w8, #0x4                // =4
     cdc:      	mov	w24, #0x4               // =4
     ce0:      	mov	w1, w22
     ce4:      	add	x0, x21, #0xa0
     ce8:      	blr	x8
     cec:      	str	w22, [x21, #0x9c]
     cf0:      	ldr	x2, [sp, #0x18]
     cf4:      	mov	w21, #0x8               // =8
     cf8:      	add	x8, sp, #0x98
     cfc:      	mov	w9, #0x4                // =4
     d00:      	add	x0, sp, #0x98
     d04:      	mov	w1, #0x8                // =8
     d08:      	blr	x9
     d0c:      	ldr	x8, [sp, #0x98]
     d10:      	add	x9, sp, #0xe8
     d14:      	mov	w10, #0x4               // =4
     d18:      	add	x0, sp, #0xe8
     d1c:      	mov	w1, #0x8                // =8
     d20:      	add	x8, x8, #0x30
     d24:      	ldr	x8, [sp, #0x98]
     d28:      	add	x2, x8, #0x30
     d2c:      	blr	x10
     d30:      	ldr	x8, [x29, #0x8]
     d34:      	mov	w9, #0x2                // =2
     d38:      	add	x10, sp, #0xf8
     d3c:      	add	x0, sp, #0xf8
     d40:      	ldr	x2, [x29, #0x8]
     d44:      	mov	w1, #0x2                // =2
     d48:      	blr	x24
     d4c:      	ldr	x8, [sp, #0x20]
     d50:      	add	w29, w22, #0xa
     d54:      	add	x8, x8, x22
     d58:      	ldr	x22, [sp, #0x10]
     d5c:      	str	w23, [x8, #0x4]
     d60:      	ldrh	w9, [sp, #0xf8]
     d64:      	strh	w9, [x8, #0x8]
     d68:      	mov	w10, #0x5ea0            // =24224
     d6c:      	tbz	w29, #0x1f, 0xd90 <generic_retkprobe_event+0xd90>
     d70:      	ldr	x9, [sp, #0x28]
     d74:      	mov	w8, #-0x1               // =-1
     d78:      	str	w8, [x9, x10]
     d7c:      	str	w8, [x9, #0x98]
     d80:      	mov	w8, #0x4                // =4
     d84:      	b	0xd98 <generic_retkprobe_event+0xd98>
     d88:      	ldr	x22, [sp, #0x10]
     d8c:      	mov	x29, xzr
     d90:      	and	x8, x29, #0x7fffffff
     d94:      	add	x8, x8, #0x4
     d98:      	ldr	x29, [sp, #0x40]
     d9c:      	add	x21, x8, #0x8
     da0:      	ldr	w8, [x29, #0x60]
     da4:      	cmp	w8, #0xb
     da8:      	b.ne	0x178 <generic_retkprobe_event+0x178>
     dac:      	b	0x294 <generic_retkprobe_event+0x294>
     db0:      	str	wzr, [sp, #0x70]
     db4:      	mov	w8, #0x1                // =1
     db8:      	add	x9, sp, #0x70
     dbc:      	add	x1, sp, #0x70
     dc0:      	mov	x0, x24
     dc4:      	blr	x8
     dc8:      	cbz	x0, 0x15d0 <generic_retkprobe_event+0x15d0>
     dcc:      	mov	x29, xzr
     dd0:      	cmp	w23, #0x19
     dd4:      	b.gt	0xfdc <generic_retkprobe_event+0xfdc>
     dd8:      	cmp	w23, #0x12
     ddc:      	b.le	0x13b8 <generic_retkprobe_event+0x13b8>
     de0:      	cmp	w23, #0x14
     de4:      	b.le	0x1608 <generic_retkprobe_event+0x1608>
     de8:      	cmp	w23, #0x15
     dec:      	b.eq	0x1cbc <generic_retkprobe_event+0x1cbc>
     df0:      	cmp	w23, #0x16
     df4:      	b.eq	0x1c5c <generic_retkprobe_event+0x1c5c>
     df8:      	cmp	w23, #0x17
     dfc:      	mov	w10, #0x5ea0            // =24224
     e00:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
     e04:      	ldr	x8, [sp, #0x28]
     e08:      	mov	w29, #0x8               // =8
     e0c:      	stp	w25, wzr, [x8, #0x9c]
     e10:      	b	0xd6c <generic_retkprobe_event+0xd6c>
     e14:      	cmp	w23, #0x9
     e18:      	mov	w10, #0x5ea0            // =24224
     e1c:      	b.gt	0xf5c <generic_retkprobe_event+0xf5c>
     e20:      	cmp	w23, #0x4
     e24:      	b.le	0x1404 <generic_retkprobe_event+0x1404>
     e28:      	cmp	w23, #0x5
     e2c:      	b.eq	0x1860 <generic_retkprobe_event+0x1860>
     e30:      	cmp	w23, #0x6
     e34:      	b.eq	0xfc0 <generic_retkprobe_event+0xfc0>
     e38:      	cmp	w23, #0x7
     e3c:      	mov	w10, #0x5ea0            // =24224
     e40:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
     e44:      	add	x29, sp, #0xe0
     e48:      	str	x22, [sp, #0x10]
     e4c:      	ldr	x25, [sp, #0x28]
     e50:      	mov	x24, x0
     e54:      	mov	w21, #0x2               // =2
     e58:      	mov	w8, #0x4                // =4
     e5c:      	ldr	x22, [x29, #0x18]
     e60:      	mov	w1, #0x2                // =2
     e64:      	mov	w23, #0x4               // =4
     e68:      	stur	x22, [x25, #0xc4]
     e6c:      	add	x0, x25, #0xc2
     e70:      	add	x2, x22, #0x10
     e74:      	blr	x8
     e78:      	add	x0, x25, #0xd6
     e7c:      	add	x2, x22, #0x12
     e80:      	mov	w8, #0x1                // =1
     e84:      	mov	w9, #0x4                // =4
     e88:      	mov	w1, #0x1                // =1
     e8c:      	blr	x9
     e90:      	add	x0, x25, #0xd4
     e94:      	add	x2, x22, #0x21e
     e98:      	mov	w8, #0x4                // =4
     e9c:      	mov	w1, #0x2                // =2
     ea0:      	blr	x8
     ea4:      	add	x0, x25, #0xc0
     ea8:      	add	x2, x22, #0x21c
     eac:      	mov	w8, #0x4                // =4
     eb0:      	mov	w1, #0x2                // =2
     eb4:      	blr	x8
     eb8:      	add	x0, x25, #0xcc
     ebc:      	add	x2, x22, #0x214
     ec0:      	mov	w8, #0x4                // =4
     ec4:      	mov	w1, #0x4                // =4
     ec8:      	blr	x8
     ecc:      	add	x0, x25, #0xd0
     ed0:      	add	x2, x22, #0x210
     ed4:      	mov	w1, #0x4                // =4
     ed8:      	blr	x23
     edc:      	ldrh	w8, [x25, #0xc2]
     ee0:      	ldr	x0, [sp, #0x20]
     ee4:      	add	x23, x25, #0xac
     ee8:      	cmp	w8, #0xa
     eec:      	stp	xzr, xzr, [x0]
     ef0:      	stp	xzr, xzr, [x0, #0x10]
     ef4:      	b.eq	0x1f94 <generic_retkprobe_event+0x1f94>
     ef8:      	cmp	w8, #0x2
     efc:      	b.ne	0x1fbc <generic_retkprobe_event+0x1fbc>
     f00:      	add	x2, x22, #0x4
     f04:      	mov	w8, #0x4                // =4
     f08:      	mov	w1, #0x4                // =4
     f0c:      	mov	w21, #0x4               // =4
     f10:      	blr	x8
     f14:      	mov	x0, x23
     f18:      	mov	w1, #0x4                // =4
     f1c:      	mov	x2, x22
     f20:      	blr	x21
     f24:      	b	0x1fbc <generic_retkprobe_event+0x1fbc>
     f28:      	mov	x29, x23
     f2c:      	b	0x324 <generic_retkprobe_event+0x324>
     f30:      	cmp	w23, #0x1c
     f34:      	b.gt	0x13e0 <generic_retkprobe_event+0x13e0>
     f38:      	cmp	w23, #0x11
     f3c:      	b.eq	0x16e0 <generic_retkprobe_event+0x16e0>
     f40:      	cmp	w23, #0x19
     f44:      	b.eq	0x17a0 <generic_retkprobe_event+0x17a0>
     f48:      	ldr	x0, [sp, #0x20]
     f4c:      	cmp	w23, #0x1c
     f50:      	mov	w10, #0x5ea0            // =24224
     f54:      	b.eq	0x1418 <generic_retkprobe_event+0x1418>
     f58:      	b	0xd6c <generic_retkprobe_event+0xd6c>
     f5c:      	ldr	x0, [sp, #0x20]
     f60:      	sub	w8, w23, #0xa
     f64:      	cmp	w8, #0x2
     f68:      	b.lo	0x1418 <generic_retkprobe_event+0x1418>
     f6c:      	sub	w8, w23, #0xc
     f70:      	cmp	w8, #0x2
     f74:      	b.lo	0x1430 <generic_retkprobe_event+0x1430>
     f78:      	cmp	w23, #0xe
     f7c:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
     f80:      	mov	w21, #0x8               // =8
     f84:      	add	x8, sp, #0x98
     f88:      	add	x23, sp, #0xf8
     f8c:      	mov	w9, #0x4                // =4
     f90:      	add	x0, sp, #0x98
     f94:      	add	x2, sp, #0xf8
     f98:      	mov	w1, #0x8                // =8
     f9c:      	mov	x24, x22
     fa0:      	mov	w22, #0x4               // =4
     fa4:      	blr	x9
     fa8:      	ldr	x8, [sp, #0x98]
     fac:      	add	x0, sp, #0xf8
     fb0:      	mov	w1, #0x8                // =8
     fb4:      	ldr	x2, [sp, #0x98]
     fb8:      	blr	x22
     fbc:      	mov	x22, x24
     fc0:      	ldr	x8, [sp, #0x28]
     fc4:      	ldr	x2, [x25, #0x18]
     fc8:      	mov	w9, #0x2d               // =45
     fcc:      	mov	w1, #0x1001             // =4097
     fd0:      	add	x0, x8, #0xa0
     fd4:      	mov	w8, #0x1001             // =4097
     fd8:      	b	0x19d4 <generic_retkprobe_event+0x19d4>
     fdc:      	cmp	w23, #0x20
     fe0:      	b.le	0x1564 <generic_retkprobe_event+0x1564>
     fe4:      	sub	w8, w23, #0x21
     fe8:      	cmp	w8, #0x4
     fec:      	b.hs	0x144c <generic_retkprobe_event+0x144c>
     ff0:      	ldr	x0, [sp, #0x20]
     ff4:      	mov	w29, #0x8               // =8
     ff8:      	mov	w8, #0x4                // =4
     ffc:      	mov	w1, #0x8                // =8
    1000:      	b	0x15fc <generic_retkprobe_event+0x15fc>
    1004:      	add	x8, x29, x22
    1008:      	mov	w9, #0x4                // =4
    100c:      	mov	x22, x10
    1010:      	str	x8, [sp, #0x48]
    1014:      	add	x0, x24, x8
    1018:      	ldr	x8, [sp, #0x98]
    101c:      	mov	w1, w22
    1020:      	ldr	x2, [sp, #0x98]
    1024:      	blr	x9
    1028:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    102c:      	add	x29, x22, x29
    1030:      	cbz	x21, 0x103c <generic_retkprobe_event+0x103c>
    1034:      	subs	x21, x21, x23
    1038:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    103c:      	ldr	x8, [sp, #0x50]
    1040:      	cmp	x8, #0x3
    1044:      	b.lo	0x324 <generic_retkprobe_event+0x324>
    1048:      	ldr	x8, [sp, #0x108]
    104c:      	mov	w9, #0x4                // =4
    1050:      	add	x10, sp, #0x98
    1054:      	add	x0, sp, #0x98
    1058:      	mov	w1, #0x10               // =16
    105c:      	add	x2, x8, #0x20
    1060:      	mov	w8, #0x10               // =16
    1064:      	blr	x9
    1068:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    106c:      	ldr	x8, [sp, #0xa0]
    1070:      	cmp	x8, x21
    1074:      	csel	x23, x8, x21, lo
    1078:      	cmp	x21, #0x0
    107c:      	csel	x8, x8, x23, eq
    1080:      	cmp	x8, #0xffe
    1084:      	str	x8, [sp, #0x38]
    1088:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    108c:      	ldr	x8, [sp, #0x48]
    1090:      	mov	w9, #0x4                // =4
    1094:      	ldr	x1, [sp, #0x38]
    1098:      	add	x22, x22, x8
    109c:      	and	x8, x22, #0x3fff
    10a0:      	add	x0, x24, x8
    10a4:      	ldr	x8, [sp, #0x98]
    10a8:      	ldr	x2, [sp, #0x98]
    10ac:      	blr	x9
    10b0:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    10b4:      	ldr	x8, [sp, #0x38]
    10b8:      	add	x29, x8, x29
    10bc:      	cbz	x21, 0x10c8 <generic_retkprobe_event+0x10c8>
    10c0:      	subs	x21, x21, x23
    10c4:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    10c8:      	ldr	x8, [sp, #0x50]
    10cc:      	cmp	x8, #0x3
    10d0:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    10d4:      	ldr	x8, [sp, #0x108]
    10d8:      	mov	w9, #0x4                // =4
    10dc:      	add	x10, sp, #0x98
    10e0:      	add	x0, sp, #0x98
    10e4:      	mov	w1, #0x10               // =16
    10e8:      	add	x2, x8, #0x30
    10ec:      	mov	w8, #0x10               // =16
    10f0:      	blr	x9
    10f4:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    10f8:      	ldr	x8, [sp, #0xa0]
    10fc:      	cmp	x8, x21
    1100:      	csel	x23, x8, x21, lo
    1104:      	cmp	x21, #0x0
    1108:      	csel	x8, x8, x23, eq
    110c:      	cmp	x8, #0xffe
    1110:      	str	x8, [sp, #0x48]
    1114:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    1118:      	ldr	x8, [sp, #0x38]
    111c:      	mov	w9, #0x4                // =4
    1120:      	ldr	x1, [sp, #0x48]
    1124:      	add	x22, x8, x22
    1128:      	and	x8, x22, #0x3fff
    112c:      	add	x0, x24, x8
    1130:      	ldr	x8, [sp, #0x98]
    1134:      	ldr	x2, [sp, #0x98]
    1138:      	blr	x9
    113c:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1140:      	ldr	x8, [sp, #0x48]
    1144:      	add	x29, x8, x29
    1148:      	cbz	x21, 0x1154 <generic_retkprobe_event+0x1154>
    114c:      	subs	x21, x21, x23
    1150:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    1154:      	ldr	x8, [sp, #0x50]
    1158:      	cmp	x8, #0x5
    115c:      	b.lo	0x324 <generic_retkprobe_event+0x324>
    1160:      	ldr	x8, [sp, #0x108]
    1164:      	mov	w9, #0x4                // =4
    1168:      	add	x10, sp, #0x98
    116c:      	add	x0, sp, #0x98
    1170:      	mov	w1, #0x10               // =16
    1174:      	add	x2, x8, #0x40
    1178:      	mov	w8, #0x10               // =16
    117c:      	blr	x9
    1180:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1184:      	ldr	x8, [sp, #0xa0]
    1188:      	cmp	x8, x21
    118c:      	csel	x23, x8, x21, lo
    1190:      	cmp	x21, #0x0
    1194:      	csel	x8, x8, x23, eq
    1198:      	cmp	x8, #0xffe
    119c:      	str	x8, [sp, #0x38]
    11a0:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    11a4:      	ldr	x8, [sp, #0x48]
    11a8:      	mov	w9, #0x4                // =4
    11ac:      	ldr	x1, [sp, #0x38]
    11b0:      	add	x22, x8, x22
    11b4:      	and	x8, x22, #0x3fff
    11b8:      	add	x0, x24, x8
    11bc:      	ldr	x8, [sp, #0x98]
    11c0:      	ldr	x2, [sp, #0x98]
    11c4:      	blr	x9
    11c8:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    11cc:      	ldr	x8, [sp, #0x38]
    11d0:      	add	x29, x8, x29
    11d4:      	cbz	x21, 0x11e0 <generic_retkprobe_event+0x11e0>
    11d8:      	subs	x21, x21, x23
    11dc:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    11e0:      	ldr	x8, [sp, #0x50]
    11e4:      	cmp	x8, #0x5
    11e8:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    11ec:      	ldr	x8, [sp, #0x108]
    11f0:      	mov	w9, #0x4                // =4
    11f4:      	add	x10, sp, #0x98
    11f8:      	add	x0, sp, #0x98
    11fc:      	mov	w1, #0x10               // =16
    1200:      	add	x2, x8, #0x50
    1204:      	mov	w8, #0x10               // =16
    1208:      	blr	x9
    120c:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1210:      	ldr	x8, [sp, #0xa0]
    1214:      	cmp	x8, x21
    1218:      	csel	x23, x8, x21, lo
    121c:      	cmp	x21, #0x0
    1220:      	csel	x8, x8, x23, eq
    1224:      	cmp	x8, #0xffe
    1228:      	str	x8, [sp, #0x48]
    122c:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    1230:      	ldr	x8, [sp, #0x38]
    1234:      	mov	w9, #0x4                // =4
    1238:      	ldr	x1, [sp, #0x48]
    123c:      	add	x22, x8, x22
    1240:      	and	x8, x22, #0x3fff
    1244:      	add	x0, x24, x8
    1248:      	ldr	x8, [sp, #0x98]
    124c:      	ldr	x2, [sp, #0x98]
    1250:      	blr	x9
    1254:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    1258:      	ldr	x8, [sp, #0x48]
    125c:      	add	x29, x8, x29
    1260:      	cbz	x21, 0x126c <generic_retkprobe_event+0x126c>
    1264:      	subs	x21, x21, x23
    1268:      	b.eq	0x324 <generic_retkprobe_event+0x324>
    126c:      	ldr	x8, [sp, #0x50]
    1270:      	cmp	x8, #0x7
    1274:      	b.lo	0x324 <generic_retkprobe_event+0x324>
    1278:      	ldr	x8, [sp, #0x108]
    127c:      	mov	w9, #0x4                // =4
    1280:      	add	x10, sp, #0x98
    1284:      	add	x0, sp, #0x98
    1288:      	mov	w1, #0x10               // =16
    128c:      	add	x2, x8, #0x60
    1290:      	mov	w8, #0x10               // =16
    1294:      	blr	x9
    1298:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    129c:      	ldr	x8, [sp, #0xa0]
    12a0:      	cmp	x8, x21
    12a4:      	csel	x9, x8, x21, lo
    12a8:      	cmp	x21, #0x0
    12ac:      	csel	x21, x8, x9, eq
    12b0:      	cmp	x21, #0xffe
    12b4:      	b.hi	0x668 <generic_retkprobe_event+0x668>
    12b8:      	ldr	x8, [sp, #0x48]
    12bc:      	mov	w9, #0x4                // =4
    12c0:      	mov	w1, w21
    12c4:      	add	x8, x8, x22
    12c8:      	and	x8, x8, #0x3fff
    12cc:      	add	x0, x24, x8
    12d0:      	ldr	x8, [sp, #0x98]
    12d4:      	ldr	x2, [sp, #0x98]
    12d8:      	blr	x9
    12dc:      	tbnz	w0, #0x1f, 0x12e8 <generic_retkprobe_event+0x12e8>
    12e0:      	add	x29, x21, x29
    12e4:      	b	0x324 <generic_retkprobe_event+0x324>
    12e8:      	mov	w8, #-0x2               // =-2
    12ec:      	str	w8, [x24, x25]
    12f0:      	mov	w8, #0x4                // =4
    12f4:      	b	0x330 <generic_retkprobe_event+0x330>
    12f8:      	ldr	x0, [sp, #0x20]
    12fc:      	cmp	w23, #0x27
    1300:      	b.eq	0x19b8 <generic_retkprobe_event+0x19b8>
    1304:      	cmp	w23, #0x28
    1308:      	b.eq	0x19f4 <generic_retkprobe_event+0x19f4>
    130c:      	cmp	w23, #0x2c
    1310:      	mov	w10, #0x5ea0            // =24224
    1314:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1318:      	mov	x24, x22
    131c:      	ldr	x22, [x25, #0x18]
    1320:      	strb	wzr, [sp, #0x98]
    1324:      	mov	w8, #0x2                // =2
    1328:      	mov	w9, #0x4                // =4
    132c:      	mov	w1, #0x2                // =2
    1330:      	mov	x2, x22
    1334:      	stp	xzr, xzr, [x0]
    1338:      	stp	xzr, xzr, [x0, #0x10]
    133c:      	stp	xzr, xzr, [x0, #0x20]
    1340:      	stp	xzr, xzr, [x0, #0x30]
    1344:      	stp	xzr, xzr, [x0, #0x40]
    1348:      	stp	xzr, xzr, [x0, #0x50]
    134c:      	stp	xzr, xzr, [x0, #0x60]
    1350:      	blr	x9
    1354:      	tbnz	x0, #0x3f, 0x20c0 <generic_retkprobe_event+0x20c0>
    1358:      	add	x23, x22, #0x2
    135c:      	mov	w8, #0x1                // =1
    1360:      	mov	w9, #0x4                // =4
    1364:      	add	x10, sp, #0x98
    1368:      	add	x0, sp, #0x98
    136c:      	mov	w1, #0x1                // =1
    1370:      	mov	x2, x23
    1374:      	blr	x9
    1378:      	tbnz	x0, #0x3f, 0x20c0 <generic_retkprobe_event+0x20c0>
    137c:      	ldrb	w8, [sp, #0x98]
    1380:      	ldr	x10, [sp, #0x28]
    1384:      	cmp	w8, #0x0
    1388:      	add	x0, x10, #0xa0
    138c:      	cset	w9, eq
    1390:      	strb	w9, [x10, #0x9e]
    1394:      	cbz	w8, 0x20a0 <generic_retkprobe_event+0x20a0>
    1398:      	mov	w8, #0x6c               // =108
    139c:      	mov	w9, #0x2d               // =45
    13a0:      	mov	w1, #0x6c               // =108
    13a4:      	mov	x2, x23
    13a8:      	blr	x9
    13ac:      	tbnz	w0, #0x1f, 0x20c0 <generic_retkprobe_event+0x20c0>
    13b0:      	sub	w21, w0, #0x1
    13b4:      	b	0x20b8 <generic_retkprobe_event+0x20b8>
    13b8:      	cmp	w23, #0x7
    13bc:      	b.gt	0x15d8 <generic_retkprobe_event+0x15d8>
    13c0:      	cmp	w23, #0x2
    13c4:      	b.eq	0x1a6c <generic_retkprobe_event+0x1a6c>
    13c8:      	cmp	w23, #0x3
    13cc:      	mov	w10, #0x5ea0            // =24224
    13d0:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    13d4:      	stur	xzr, [x0, #0x9c]
    13d8:      	mov	w29, #0x8               // =8
    13dc:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    13e0:      	ldr	x0, [sp, #0x20]
    13e4:      	mov	w8, #0x2                // =2
    13e8:      	add	x9, sp, #0xf8
    13ec:      	mov	w10, #0x4               // =4
    13f0:      	add	x2, sp, #0xf8
    13f4:      	mov	w1, #0x2                // =2
    13f8:      	mov	w29, #0x4               // =4
    13fc:      	blr	x10
    1400:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1404:      	ldr	x0, [sp, #0x20]
    1408:      	cmp	w23, #0x1
    140c:      	b.eq	0x1430 <generic_retkprobe_event+0x1430>
    1410:      	cmp	w23, #0x4
    1414:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1418:      	mov	w29, #0x8               // =8
    141c:      	mov	w8, #0x4                // =4
    1420:      	add	x9, sp, #0xf8
    1424:      	add	x2, sp, #0xf8
    1428:      	mov	w1, #0x8                // =8
    142c:      	b	0x1600 <generic_retkprobe_event+0x1600>
    1430:      	add	x8, sp, #0xf8
    1434:      	mov	w9, #0x4                // =4
    1438:      	add	x2, sp, #0xf8
    143c:      	mov	w1, #0x4                // =4
    1440:      	mov	w29, #0x4               // =4
    1444:      	blr	x9
    1448:      	b	0xd68 <generic_retkprobe_event+0xd68>
    144c:      	cmp	w23, #0x2b
    1450:      	b.eq	0x1d7c <generic_retkprobe_event+0x1d7c>
    1454:      	cmp	w23, #0x29
    1458:      	mov	w10, #0x5ea0            // =24224
    145c:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1460:      	str	x22, [sp, #0x10]
    1464:      	add	x2, x25, #0x18
    1468:      	mov	w8, #0x8                // =8
    146c:      	mov	w9, #0x4                // =4
    1470:      	add	x10, sp, #0x98
    1474:      	mov	x24, x0
    1478:      	add	x0, sp, #0x98
    147c:      	mov	w1, #0x8                // =8
    1480:      	blr	x9
    1484:      	ldr	x22, [sp, #0x98]
    1488:      	cbz	x22, 0x213c <generic_retkprobe_event+0x213c>
    148c:      	ldr	x25, [sp, #0x28]
    1490:      	add	x2, x22, #0x10
    1494:      	mov	w21, #0x2               // =2
    1498:      	mov	w8, #0x4                // =4
    149c:      	stur	x22, [x25, #0xc4]
    14a0:      	add	x0, x25, #0xc2
    14a4:      	mov	w1, #0x2                // =2
    14a8:      	mov	w23, #0x4               // =4
    14ac:      	blr	x8
    14b0:      	add	x0, x25, #0xd6
    14b4:      	add	x2, x22, #0x12
    14b8:      	mov	w8, #0x1                // =1
    14bc:      	mov	w9, #0x4                // =4
    14c0:      	mov	w1, #0x1                // =1
    14c4:      	blr	x9
    14c8:      	add	x0, x25, #0xd4
    14cc:      	add	x2, x22, #0x21e
    14d0:      	mov	w8, #0x4                // =4
    14d4:      	mov	w1, #0x2                // =2
    14d8:      	blr	x8
    14dc:      	add	x0, x25, #0xc0
    14e0:      	add	x2, x22, #0x21c
    14e4:      	mov	w8, #0x4                // =4
    14e8:      	mov	w1, #0x2                // =2
    14ec:      	blr	x8
    14f0:      	add	x0, x25, #0xcc
    14f4:      	add	x2, x22, #0x214
    14f8:      	mov	w8, #0x4                // =4
    14fc:      	mov	w1, #0x4                // =4
    1500:      	blr	x8
    1504:      	add	x0, x25, #0xd0
    1508:      	add	x2, x22, #0x210
    150c:      	mov	w1, #0x4                // =4
    1510:      	blr	x23
    1514:      	ldr	x8, [sp, #0x20]
    1518:      	add	x23, x25, #0xac
    151c:      	stp	xzr, xzr, [x8]
    1520:      	stp	xzr, xzr, [x8, #0x10]
    1524:      	ldrh	w8, [x25, #0xc2]
    1528:      	cmp	w8, #0xa
    152c:      	b.eq	0x20cc <generic_retkprobe_event+0x20cc>
    1530:      	cmp	w8, #0x2
    1534:      	b.ne	0x20f8 <generic_retkprobe_event+0x20f8>
    1538:      	ldr	x0, [sp, #0x20]
    153c:      	add	x2, x22, #0x4
    1540:      	mov	w8, #0x4                // =4
    1544:      	mov	w1, #0x4                // =4
    1548:      	mov	w21, #0x4               // =4
    154c:      	blr	x8
    1550:      	mov	x0, x23
    1554:      	mov	w1, #0x4                // =4
    1558:      	mov	x2, x22
    155c:      	blr	x21
    1560:      	b	0x20f8 <generic_retkprobe_event+0x20f8>
    1564:      	cmp	w23, #0x1a
    1568:      	b.eq	0x1e0c <generic_retkprobe_event+0x1e0c>
    156c:      	cmp	w23, #0x1b
    1570:      	mov	w10, #0x5ea0            // =24224
    1574:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    1578:      	ldp	x9, x8, [sp, #0x20]
    157c:      	add	x2, x25, #0x18
    1580:      	mov	w1, #0x3f               // =63
    1584:      	add	x0, x8, #0xac
    1588:      	stp	xzr, xzr, [x9, #0x40]
    158c:      	stp	xzr, xzr, [x9, #0x30]
    1590:      	stp	xzr, xzr, [x9, #0x20]
    1594:      	mov	w8, #0x3f               // =63
    1598:      	stp	xzr, xzr, [x9, #0x10]
    159c:      	stp	xzr, xzr, [x9]
    15a0:      	mov	w9, #0x2d               // =45
    15a4:      	blr	x9
    15a8:      	tbnz	x0, #0x3f, 0x15d0 <generic_retkprobe_event+0x15d0>
    15ac:      	ldr	x8, [sp, #0x28]
    15b0:      	add	x2, x25, #0x360
    15b4:      	mov	w9, #0x4                // =4
    15b8:      	mov	w1, #0x8                // =8
    15bc:      	add	x0, x8, #0xa4
    15c0:      	mov	w8, #0x8                // =8
    15c4:      	blr	x9
    15c8:      	mov	w29, #0x50              // =80
    15cc:      	b	0xd68 <generic_retkprobe_event+0xd68>
    15d0:      	mov	x29, xzr
    15d4:      	b	0xd68 <generic_retkprobe_event+0xd68>
    15d8:      	cmp	w23, #0x8
    15dc:      	b.eq	0x1adc <generic_retkprobe_event+0x1adc>
    15e0:      	cmp	w23, #0x12
    15e4:      	mov	w10, #0x5ea0            // =24224
    15e8:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    15ec:      	mov	x29, xzr
    15f0:      	mov	w8, #0x4                // =4
    15f4:      	ldr	x0, [sp, #0x20]
    15f8:      	mov	w1, wzr
    15fc:      	mov	x2, x25
    1600:      	blr	x8
    1604:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1608:      	cmp	w23, #0x13
    160c:      	b.eq	0x1d3c <generic_retkprobe_event+0x1d3c>
    1610:      	cmp	w23, #0x14
    1614:      	mov	w10, #0x5ea0            // =24224
    1618:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    161c:      	str	xzr, [sp, #0x98]
    1620:      	add	x2, x25, #0x110
    1624:      	mov	w24, #0x8               // =8
    1628:      	add	x8, sp, #0x98
    162c:      	mov	w9, #0x4                // =4
    1630:      	add	x0, sp, #0x98
    1634:      	mov	w1, #0x8                // =8
    1638:      	mov	x21, x22
    163c:      	add	x22, x25, #0xd8
    1640:      	mov	w23, #0x4               // =4
    1644:      	blr	x9
    1648:      	ldr	x8, [sp, #0x98]
    164c:      	mov	w9, #0x80               // =128
    1650:      	mov	w10, #0x2d              // =45
    1654:      	ldr	x0, [sp, #0x20]
    1658:      	mov	w1, #0x80               // =128
    165c:      	ldr	x2, [sp, #0x98]
    1660:      	blr	x10
    1664:      	ldr	x29, [sp, #0x28]
    1668:      	mov	w8, #0x4                // =4
    166c:      	mov	w1, #0x4                // =4
    1670:      	mov	x2, x22
    1674:      	add	x0, x29, #0x12c
    1678:      	mov	x22, x21
    167c:      	blr	x8
    1680:      	add	x0, x29, #0x11c
    1684:      	add	x2, x25, #0xe0
    1688:      	mov	w8, #0x4                // =4
    168c:      	mov	w1, #0x8                // =8
    1690:      	blr	x8
    1694:      	add	x0, x29, #0x124
    1698:      	add	x2, x25, #0x118
    169c:      	mov	w1, #0x8                // =8
    16a0:      	blr	x23
    16a4:      	mov	w10, #0x5ea0            // =24224
    16a8:      	mov	w29, #0x98              // =152
    16ac:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    16b0:      	cmp	w23, #0x26
    16b4:      	mov	w10, #0x5ea0            // =24224
    16b8:      	b.ne	0xd6c <generic_retkprobe_event+0xd6c>
    16bc:      	ldr	x8, [x25, #0x18]
    16c0:      	ldr	x9, [sp, #0x28]
    16c4:      	add	x2, x19, w8, uxth
    16c8:      	ubfx	w8, w8, #16, #12
    16cc:      	add	x0, x9, #0xa0
    16d0:      	add	w1, w8, #0x1
    16d4:      	mov	w8, #0x2d               // =45
    16d8:      	blr	x8
    16dc:      	b	0x19d8 <generic_retkprobe_event+0x19d8>
    16e0:      	stp	xzr, xzr, [sp, #0x98]
    16e4:      	mov	w8, #0xe                // =14
    16e8:      	mov	x24, x22
    16ec:      	blr	x8
    16f0:      	lsr	x8, x0, #32
    16f4:      	add	x9, sp, #0xe8
    16f8:      	add	x10, sp, #0xf8
    16fc:      	str	x8, [sp, #0x98]
    1700:      	mov	w8, #0x4                // =4
    1704:      	add	x0, sp, #0xe8
    1708:      	add	x2, sp, #0xf8
    170c:      	mov	w1, #0x4                // =4
    1710:      	blr	x8
    1714:      	ldr	w8, [sp, #0xe8]
    1718:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    171c:      	add	x9, sp, #0x98
    1720:      	add	x1, sp, #0x98
    1724:      	str	w8, [sp, #0xa0]
    1728:      	mov	w8, #0x1                // =1
    172c:      	ldr	x0, [x0]
    1730:      	blr	x8
    1734:      	cbz	x0, 0x1f00 <generic_retkprobe_event+0x1f00>
    1738:      	ldr	x25, [sp, #0x20]
    173c:      	ldr	w21, [x0]
    1740:      	add	x8, sp, #0xe8
    1744:      	mov	w9, #0x4                // =4
    1748:      	add	x2, sp, #0xe8
    174c:      	mov	x22, x0
    1750:      	mov	w1, #0x4                // =4
    1754:      	mov	w23, #0x4               // =4
    1758:      	mov	x0, x25
    175c:      	blr	x9
    1760:      	ldr	x8, [sp, #0x28]
    1764:      	and	x21, x21, #0xfff
    1768:      	mov	x2, x22
    176c:      	add	x1, x21, #0x4
    1770:      	add	x0, x8, #0xa0
    1774:      	mov	w8, #0x4                // =4
    1778:      	blr	x8
    177c:      	add	w21, w21, #0x8
    1780:      	mov	w1, #0x4                // =4
    1784:      	add	x8, x21, x22
    1788:      	add	x0, x25, x21
    178c:      	sub	x2, x8, #0x4
    1790:      	blr	x23
    1794:      	add	x29, x21, #0x4
    1798:      	mov	x22, x24
    179c:      	b	0xd68 <generic_retkprobe_event+0xd68>
    17a0:      	add	x29, sp, #0xe0
    17a4:      	mov	x25, x22
    17a8:      	mov	w8, #0x1                // =1
    17ac:      	ldr	x22, [x29, #0x18]
    17b0:      	mov	w9, #0x4                // =4
    17b4:      	add	x10, sp, #0xd8
    17b8:      	mov	x23, x0
    17bc:      	add	x0, sp, #0xd8
    17c0:      	mov	w1, #0x1                // =1
    17c4:      	mov	x2, x22
    17c8:      	blr	x9
    17cc:      	ldrb	w8, [sp, #0xd8]
    17d0:      	cmp	w8, #0x1
    17d4:      	b.ne	0x1ef0 <generic_retkprobe_event+0x1ef0>
    17d8:      	add	x2, x22, #0x10
    17dc:      	mov	w21, #0x8               // =8
    17e0:      	add	x8, sp, #0x98
    17e4:      	mov	w9, #0x4                // =4
    17e8:      	add	x0, sp, #0x98
    17ec:      	mov	w1, #0x8                // =8
    17f0:      	mov	w24, #0x4               // =4
    17f4:      	blr	x9
    17f8:      	ldr	x2, [sp, #0x98]
    17fc:      	add	x8, sp, #0xe8
    1800:      	mov	w9, #0x4                // =4
    1804:      	add	x0, sp, #0xe8
    1808:      	mov	w1, #0x8                // =8
    180c:      	blr	x9
    1810:      	ldr	x8, [sp, #0x98]
    1814:      	mov	w9, #0x4                // =4
    1818:      	add	x0, sp, #0x70
    181c:      	mov	w1, #0x8                // =8
    1820:      	add	x2, x8, #0x8
    1824:      	add	x8, sp, #0x70
    1828:      	blr	x9
    182c:      	ldr	x21, [sp, #0x70]
    1830:      	ldr	x2, [x29, #0x8]
    1834:      	mov	w8, #0xfff              // =4095
    1838:      	add	x0, x23, #0xa4
    183c:      	cmp	x21, #0xfff
    1840:      	csel	x22, x21, x8, lo
    1844:      	mov	w1, w22
    1848:      	blr	x24
    184c:      	tbnz	w0, #0x1f, 0x2038 <generic_retkprobe_event+0x2038>
    1850:      	stp	w21, w22, [x23, #0x9c]
    1854:      	add	x29, x22, #0x8
    1858:      	mov	x22, x25
    185c:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1860:      	add	x8, sp, #0xe0
    1864:      	ldr	x21, [sp, #0x28]
    1868:      	str	x22, [sp, #0x10]
    186c:      	mov	w1, #0x4                // =4
    1870:      	mov	w23, #0x4               // =4
    1874:      	add	x0, x21, #0xc4
    1878:      	ldr	x24, [x8, #0x18]
    187c:      	mov	w8, #0x4                // =4
    1880:      	add	x2, x24, #0x98
    1884:      	blr	x8
    1888:      	add	x0, x21, #0xc8
    188c:      	add	x2, x24, #0x70
    1890:      	mov	w8, #0x4                // =4
    1894:      	mov	w1, #0x4                // =4
    1898:      	blr	x8
    189c:      	add	x0, x21, #0xcc
    18a0:      	add	x2, x24, #0x90
    18a4:      	mov	w8, #0x4                // =4
    18a8:      	mov	w1, #0x4                // =4
    18ac:      	blr	x8
    18b0:      	add	x0, x21, #0xd0
    18b4:      	add	x2, x24, #0xa8
    18b8:      	mov	w8, #0x4                // =4
    18bc:      	mov	w1, #0x4                // =4
    18c0:      	blr	x8
    18c4:      	str	xzr, [sp, #0x98]
    18c8:      	add	x2, x24, #0xc8
    18cc:      	mov	w8, #0x8                // =8
    18d0:      	add	x9, sp, #0x98
    18d4:      	mov	w10, #0x4               // =4
    18d8:      	add	x0, sp, #0x98
    18dc:      	mov	w1, #0x8                // =8
    18e0:      	blr	x10
    18e4:      	add	x2, x24, #0xb8
    18e8:      	mov	w8, #0x2                // =2
    18ec:      	add	x9, sp, #0xd8
    18f0:      	mov	w10, #0x4               // =4
    18f4:      	add	x0, sp, #0xd8
    18f8:      	mov	w1, #0x2                // =2
    18fc:      	blr	x10
    1900:      	ldr	x8, [sp, #0x98]
    1904:      	ldrh	w9, [sp, #0xd8]
    1908:      	add	x0, sp, #0x84
    190c:      	mov	w1, #0x1                // =1
    1910:      	add	x22, x8, x9
    1914:      	mov	w8, #0x1                // =1
    1918:      	add	x9, sp, #0x84
    191c:      	mov	x2, x22
    1920:      	blr	x23
    1924:      	ldrb	w8, [sp, #0x84]
    1928:      	lsr	w8, w8, #4
    192c:      	cmp	w8, #0x6
    1930:      	b.eq	0x1f0c <generic_retkprobe_event+0x1f0c>
    1934:      	cmp	w8, #0x4
    1938:      	b.ne	0x2894 <generic_retkprobe_event+0x2894>
    193c:      	add	x2, x22, #0x9
    1940:      	mov	w8, #0x1                // =1
    1944:      	add	x9, sp, #0x88
    1948:      	mov	w10, #0x4               // =4
    194c:      	add	x0, sp, #0x88
    1950:      	mov	w1, #0x1                // =1
    1954:      	mov	w25, #0x4               // =4
    1958:      	blr	x10
    195c:      	ldrb	w8, [sp, #0x88]
    1960:      	ldp	x0, x9, [sp, #0x20]
    1964:      	mov	w21, #0x2               // =2
    1968:      	add	x2, x22, #0xc
    196c:      	mov	w1, #0x4                // =4
    1970:      	add	x23, x9, #0xac
    1974:      	strh	w8, [x9, #0xc0]
    1978:      	strh	w21, [x9, #0xc2]
    197c:      	stp	xzr, xzr, [x0]
    1980:      	mov	w8, #0x4                // =4
    1984:      	stp	xzr, xzr, [x0, #0x10]
    1988:      	blr	x8
    198c:      	add	x2, x22, #0x10
    1990:      	mov	w8, #0x4                // =4
    1994:      	mov	x0, x23
    1998:      	mov	w1, #0x4                // =4
    199c:      	blr	x8
    19a0:      	add	x2, x24, #0xb6
    19a4:      	add	x8, sp, #0x90
    19a8:      	add	x0, sp, #0x90
    19ac:      	mov	w1, #0x2                // =2
    19b0:      	blr	x25
    19b4:      	b	0x275c <generic_retkprobe_event+0x275c>
    19b8:      	ldr	x8, [x25, #0x18]
    19bc:      	mov	w9, #0x2d               // =45
    19c0:      	mov	w1, #0x11               // =17
    19c4:      	add	x2, x8, #0x118
    19c8:      	ldr	x8, [sp, #0x28]
    19cc:      	add	x0, x8, #0xa0
    19d0:      	mov	w8, #0x11               // =17
    19d4:      	blr	x9
    19d8:      	mov	x29, x0
    19dc:      	tbnz	x0, #0x3f, 0xd68 <generic_retkprobe_event+0xd68>
    19e0:      	ldr	x9, [sp, #0x20]
    19e4:      	sub	w8, w29, #0x1
    19e8:      	add	x29, x29, #0x3
    19ec:      	str	w8, [x9]
    19f0:      	b	0xd68 <generic_retkprobe_event+0xd68>
    19f4:      	mov	x23, x22
    19f8:      	ldr	x22, [x25, #0x18]
    19fc:      	stp	xzr, xzr, [x0, #0x8]
    1a00:      	mov	w8, #0x2                // =2
    1a04:      	mov	w9, #0x4                // =4
    1a08:      	mov	w1, #0x2                // =2
    1a0c:      	str	xzr, [x0]
    1a10:      	mov	x24, x0
    1a14:      	mov	x2, x22
    1a18:      	blr	x9
    1a1c:      	tbnz	x0, #0x3f, 0x2094 <generic_retkprobe_event+0x2094>
    1a20:      	ldrh	w8, [x24]
    1a24:      	cmp	w8, #0xa
    1a28:      	b.eq	0x204c <generic_retkprobe_event+0x204c>
    1a2c:      	cmp	w8, #0x2
    1a30:      	b.ne	0x2080 <generic_retkprobe_event+0x2080>
    1a34:      	add	x2, x22, #0x4
    1a38:      	add	x8, sp, #0x98
    1a3c:      	mov	w9, #0x4                // =4
    1a40:      	add	x0, sp, #0x98
    1a44:      	mov	w1, #0x4                // =4
    1a48:      	mov	w21, #0x4               // =4
    1a4c:      	blr	x9
    1a50:      	ldr	w8, [sp, #0x98]
    1a54:      	ldr	x9, [sp, #0x28]
    1a58:      	add	x2, x22, #0x2
    1a5c:      	add	x0, x9, #0x9e
    1a60:      	stur	x8, [x9, #0xa4]
    1a64:      	mov	w8, #0x2                // =2
    1a68:      	b	0x2078 <generic_retkprobe_event+0x2078>
    1a6c:      	add	x21, sp, #0xe0
    1a70:      	str	x22, [sp, #0x10]
    1a74:      	str	xzr, [sp, #0x98]
    1a78:      	mov	w8, #0x8                // =8
    1a7c:      	add	x9, sp, #0xe8
    1a80:      	add	x10, sp, #0x98
    1a84:      	str	xzr, [x21, #0x8]
    1a88:      	mov	w11, #0x4               // =4
    1a8c:      	mov	x24, x0
    1a90:      	add	x0, sp, #0xe8
    1a94:      	add	x2, sp, #0x98
    1a98:      	mov	w1, #0x8                // =8
    1a9c:      	mov	w29, #0x4               // =4
    1aa0:      	blr	x11
    1aa4:      	ldr	x21, [x21, #0x8]
    1aa8:      	mov	w8, #0xfff              // =4095
    1aac:      	add	x0, x24, #0xa4
    1ab0:      	mov	x2, x25
    1ab4:      	mov	x23, x24
    1ab8:      	cmp	x21, #0xfff
    1abc:      	csel	x22, x21, x8, lo
    1ac0:      	mov	w8, #0x4                // =4
    1ac4:      	mov	w1, w22
    1ac8:      	blr	x8
    1acc:      	tbnz	w0, #0x1f, 0x2028 <generic_retkprobe_event+0x2028>
    1ad0:      	add	x29, x22, #0x8
    1ad4:      	str	w22, [x23, #0xa0]
    1ad8:      	b	0x202c <generic_retkprobe_event+0x202c>
    1adc:      	ldp	x0, x29, [sp, #0x20]
    1ae0:      	add	x2, x25, #0x8
    1ae4:      	mov	w8, #0x4                // =4
    1ae8:      	mov	w1, #0x4                // =4
    1aec:      	mov	w23, #0x4               // =4
    1af0:      	str	x22, [sp, #0x10]
    1af4:      	add	x24, x29, #0xc4
    1af8:      	add	x22, x29, #0xdc
    1afc:      	blr	x8
    1b00:      	add	x0, x29, #0xa0
    1b04:      	add	x2, x25, #0xc
    1b08:      	mov	w8, #0x4                // =4
    1b0c:      	mov	w1, #0x4                // =4
    1b10:      	blr	x8
    1b14:      	add	x0, x29, #0xac
    1b18:      	add	x2, x25, #0x18
    1b1c:      	mov	w8, #0x4                // =4
    1b20:      	mov	w1, #0x4                // =4
    1b24:      	blr	x8
    1b28:      	add	x0, x29, #0xb0
    1b2c:      	add	x2, x25, #0x1c
    1b30:      	mov	w8, #0x4                // =4
    1b34:      	mov	w1, #0x4                // =4
    1b38:      	blr	x8
    1b3c:      	add	x0, x29, #0xa4
    1b40:      	add	x2, x25, #0x10
    1b44:      	mov	w8, #0x4                // =4
    1b48:      	mov	w1, #0x4                // =4
    1b4c:      	blr	x8
    1b50:      	add	x0, x29, #0xa8
    1b54:      	add	x2, x25, #0x14
    1b58:      	mov	w8, #0x4                // =4
    1b5c:      	mov	w1, #0x4                // =4
    1b60:      	blr	x8
    1b64:      	add	x0, x29, #0xb4
    1b68:      	add	x2, x25, #0x20
    1b6c:      	mov	w8, #0x4                // =4
    1b70:      	mov	w1, #0x4                // =4
    1b74:      	blr	x8
    1b78:      	add	x0, x29, #0xb8
    1b7c:      	add	x2, x25, #0x24
    1b80:      	mov	w8, #0x4                // =4
    1b84:      	mov	w1, #0x4                // =4
    1b88:      	blr	x8
    1b8c:      	str	wzr, [x29, #0xc0]
    1b90:      	add	x0, x29, #0xbc
    1b94:      	add	x2, x25, #0x28
    1b98:      	mov	w8, #0x4                // =4
    1b9c:      	mov	w1, #0x4                // =4
    1ba0:      	blr	x8
    1ba4:      	add	x0, x29, #0xcc
    1ba8:      	add	x2, x25, #0x40
    1bac:      	mov	w21, #0x8               // =8
    1bb0:      	mov	w8, #0x4                // =4
    1bb4:      	mov	w1, #0x8                // =8
    1bb8:      	blr	x8
    1bbc:      	add	x0, x29, #0xd4
    1bc0:      	add	x2, x25, #0x30
    1bc4:      	mov	w8, #0x4                // =4
    1bc8:      	mov	w1, #0x8                // =8
    1bcc:      	blr	x8
    1bd0:      	add	x2, x25, #0x38
    1bd4:      	mov	w8, #0x4                // =4
    1bd8:      	mov	x0, x24
    1bdc:      	mov	w1, #0x8                // =8
    1be0:      	blr	x8
    1be4:      	add	x2, x25, #0x90
    1be8:      	add	x8, sp, #0x98
    1bec:      	mov	w9, #0x4                // =4
    1bf0:      	add	x0, sp, #0x98
    1bf4:      	mov	w1, #0x8                // =8
    1bf8:      	blr	x9
    1bfc:      	ldr	x21, [sp, #0x98]
    1c00:      	mov	w8, #0x4                // =4
    1c04:      	mov	x0, x22
    1c08:      	mov	w1, #0x4                // =4
    1c0c:      	add	x2, x21, #0xc8
    1c10:      	ldr	x22, [sp, #0x10]
    1c14:      	blr	x8
    1c18:      	add	x0, x29, #0xe0
    1c1c:      	add	x2, x21, #0xcc
    1c20:      	mov	w8, #0x4                // =4
    1c24:      	mov	w1, #0x4                // =4
    1c28:      	blr	x8
    1c2c:      	add	x0, x29, #0xe4
    1c30:      	add	x2, x21, #0xd0
    1c34:      	mov	w8, #0x4                // =4
    1c38:      	mov	w1, #0x4                // =4
    1c3c:      	blr	x8
    1c40:      	add	x0, x29, #0xe8
    1c44:      	add	x2, x21, #0x158
    1c48:      	mov	w1, #0x4                // =4
    1c4c:      	blr	x23
    1c50:      	mov	w10, #0x5ea0            // =24224
    1c54:      	mov	w29, #0x50              // =80
    1c58:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1c5c:      	ldr	x0, [sp, #0x20]
    1c60:      	add	x2, x25, #0xc8
    1c64:      	mov	w8, #0x4                // =4
    1c68:      	mov	w1, #0x4                // =4
    1c6c:      	mov	w21, #0x4               // =4
    1c70:      	blr	x8
    1c74:      	ldr	x23, [sp, #0x28]
    1c78:      	add	x2, x25, #0xcc
    1c7c:      	mov	w8, #0x4                // =4
    1c80:      	mov	w1, #0x4                // =4
    1c84:      	add	x0, x23, #0xa0
    1c88:      	blr	x8
    1c8c:      	add	x0, x23, #0xa4
    1c90:      	add	x2, x25, #0xd0
    1c94:      	mov	w8, #0x4                // =4
    1c98:      	mov	w1, #0x4                // =4
    1c9c:      	blr	x8
    1ca0:      	add	x0, x23, #0xa8
    1ca4:      	add	x2, x25, #0x158
    1ca8:      	mov	w1, #0x4                // =4
    1cac:      	blr	x21
    1cb0:      	mov	w10, #0x5ea0            // =24224
    1cb4:      	mov	w29, #0x10              // =16
    1cb8:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1cbc:      	ldr	x0, [sp, #0x20]
    1cc0:      	add	x2, x25, #0x38
    1cc4:      	mov	w8, #0x4                // =4
    1cc8:      	mov	w1, #0x4                // =4
    1ccc:      	mov	x21, x22
    1cd0:      	mov	w22, #0x4               // =4
    1cd4:      	blr	x8
    1cd8:      	ldr	x23, [sp, #0x28]
    1cdc:      	add	x2, x25, #0x3c
    1ce0:      	mov	w8, #0x4                // =4
    1ce4:      	mov	w1, #0x4                // =4
    1ce8:      	add	x0, x23, #0xa0
    1cec:      	blr	x8
    1cf0:      	add	x0, x23, #0xa4
    1cf4:      	add	x2, x25, #0x40
    1cf8:      	mov	w8, #0x4                // =4
    1cfc:      	mov	w1, #0x4                // =4
    1d00:      	blr	x8
    1d04:      	add	x0, x23, #0xa8
    1d08:      	add	x2, x25, #0x44
    1d0c:      	mov	w8, #0x4                // =4
    1d10:      	mov	w1, #0x4                // =4
    1d14:      	blr	x8
    1d18:      	add	x0, x23, #0xac
    1d1c:      	add	x2, x25, #0x80
    1d20:      	mov	w8, #0x10               // =16
    1d24:      	mov	w1, #0x10               // =16
    1d28:      	blr	x22
    1d2c:      	mov	x22, x21
    1d30:      	mov	w10, #0x5ea0            // =24224
    1d34:      	mov	w29, #0x20              // =32
    1d38:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1d3c:      	ldr	x0, [sp, #0x20]
    1d40:      	mov	w8, #0x4                // =4
    1d44:      	mov	w1, #0x4                // =4
    1d48:      	mov	x2, x25
    1d4c:      	mov	w21, #0x4               // =4
    1d50:      	blr	x8
    1d54:      	ldr	x23, [sp, #0x28]
    1d58:      	add	x2, x25, #0x4
    1d5c:      	mov	w8, #0x4                // =4
    1d60:      	mov	w1, #0x4                // =4
    1d64:      	add	x0, x23, #0xa0
    1d68:      	blr	x8
    1d6c:      	add	x0, x23, #0xa4
    1d70:      	add	x2, x25, #0x30
    1d74:      	mov	w8, #0x10               // =16
    1d78:      	b	0x1df8 <generic_retkprobe_event+0x1df8>
    1d7c:      	add	x2, x25, #0x4
    1d80:      	add	x8, sp, #0x98
    1d84:      	mov	w9, #0x4                // =4
    1d88:      	add	x0, sp, #0x98
    1d8c:      	mov	w1, #0x4                // =4
    1d90:      	mov	w21, #0x4               // =4
    1d94:      	blr	x9
    1d98:      	ldr	w8, [sp, #0x98]
    1d9c:      	ldr	x23, [sp, #0x28]
    1da0:      	add	x2, x25, #0xc
    1da4:      	add	x0, sp, #0x98
    1da8:      	mov	w1, #0x4                // =4
    1dac:      	str	w8, [x23, #0x9c]
    1db0:      	add	x8, sp, #0x98
    1db4:      	blr	x21
    1db8:      	ldr	w8, [sp, #0x98]
    1dbc:      	add	x2, x25, #0x50
    1dc0:      	add	x9, sp, #0x98
    1dc4:      	mov	w10, #0x2d              // =45
    1dc8:      	str	w8, [x23, #0xa0]
    1dcc:      	mov	w8, #0x8                // =8
    1dd0:      	add	x0, sp, #0x98
    1dd4:      	mov	w1, #0x8                // =8
    1dd8:      	mov	w21, #0x2d              // =45
    1ddc:      	blr	x10
    1de0:      	ldr	x8, [sp, #0x98]
    1de4:      	add	x0, x23, #0xa4
    1de8:      	mov	w9, #0x10               // =16
    1dec:      	add	x8, x8, #0x3f8
    1df0:      	ldr	x8, [sp, #0x98]
    1df4:      	add	x2, x8, #0x3f8
    1df8:      	mov	w1, #0x10               // =16
    1dfc:      	blr	x21
    1e00:      	mov	w10, #0x5ea0            // =24224
    1e04:      	mov	w29, #0x18              // =24
    1e08:      	b	0xd6c <generic_retkprobe_event+0xd6c>
    1e0c:      	ldr	x11, [sp, #0x20]
    1e10:      	mov	w8, #0x8                // =8
    1e14:      	mov	w9, #0x4                // =4
    1e18:      	add	x10, sp, #0x98
    1e1c:      	stp	xzr, xzr, [x11, #0x40]
    1e20:      	add	x0, sp, #0x98
    1e24:      	stp	xzr, xzr, [x11, #0x30]
    1e28:      	stp	xzr, xzr, [x11, #0x20]
    1e2c:      	mov	w1, #0x8                // =8
    1e30:      	mov	x2, x25
    1e34:      	stp	xzr, xzr, [x11, #0x10]
    1e38:      	stp	xzr, xzr, [x11]
    1e3c:      	blr	x9
    1e40:      	mov	x29, xzr
    1e44:      	cbnz	x0, 0xd68 <generic_retkprobe_event+0xd68>
    1e48:      	ldr	x8, [sp, #0x28]
    1e4c:      	mov	w9, #0x3f               // =63
    1e50:      	mov	w10, #0x2d              // =45
    1e54:      	mov	w1, #0x3f               // =63
    1e58:      	mov	x23, x22
    1e5c:      	add	x0, x8, #0xac
    1e60:      	ldr	x8, [sp, #0x98]
    1e64:      	ldr	x2, [sp, #0x98]
    1e68:      	blr	x10
    1e6c:      	tbnz	x0, #0x3f, 0x2180 <generic_retkprobe_event+0x2180>
    1e70:      	add	x2, x25, #0x8
    1e74:      	mov	w21, #0x8               // =8
    1e78:      	add	x8, sp, #0xe8
    1e7c:      	mov	w9, #0x4                // =4
    1e80:      	add	x0, sp, #0xe8
    1e84:      	mov	w1, #0x8                // =8
    1e88:      	mov	w22, #0x4               // =4
    1e8c:      	blr	x9
    1e90:      	ldr	x8, [sp, #0x28]
    1e94:      	add	x10, sp, #0xe0
    1e98:      	mov	w9, #0x4                // =4
    1e9c:      	mov	w1, #0x8                // =8
    1ea0:      	add	x0, x8, #0xa4
    1ea4:      	ldr	x8, [x10, #0x8]
    1ea8:      	add	x8, x8, #0x360
    1eac:      	ldr	x8, [x10, #0x8]
    1eb0:      	add	x2, x8, #0x360
    1eb4:      	blr	x9
    1eb8:      	add	x2, x25, #0x58
    1ebc:      	add	x8, sp, #0xe8
    1ec0:      	add	x0, sp, #0xe8
    1ec4:      	mov	w1, #0x4                // =4
    1ec8:      	blr	x22
    1ecc:      	cbnz	x0, 0x1ee4 <generic_retkprobe_event+0x1ee4>
    1ed0:      	ldr	w8, [sp, #0xe8]
    1ed4:      	ldr	x9, [sp, #0x20]
    1ed8:      	cmp	w8, #0x0
    1edc:      	cset	w8, ne
    1ee0:      	str	w8, [x9]
    1ee4:      	mov	w29, #0x50              // =80
    1ee8:      	mov	x22, x23
    1eec:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1ef0:      	stur	xzr, [x23, #0x9c]
    1ef4:      	mov	w29, #0x8               // =8
    1ef8:      	mov	x22, x25
    1efc:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1f00:      	mov	x29, #-0x1              // =-1
    1f04:      	mov	x22, x24
    1f08:      	b	0xd68 <generic_retkprobe_event+0xd68>
    1f0c:      	str	wzr, [sp, #0xe8]
    1f10:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1f14:      	ldr	x23, [sp, #0x98]
    1f18:      	mov	w8, #0x1                // =1
    1f1c:      	add	x9, sp, #0xe8
    1f20:      	add	x1, sp, #0xe8
    1f24:      	ldrh	w21, [sp, #0xd8]
    1f28:      	ldr	x0, [x0]
    1f2c:      	add	x22, x23, x21
    1f30:      	blr	x8
    1f34:      	cbz	x0, 0x271c <generic_retkprobe_event+0x271c>
    1f38:      	mov	w8, #0xff               // =255
    1f3c:      	strh	w21, [x0]
    1f40:      	strb	wzr, [x0, #0x7]
    1f44:      	add	x29, x0, #0x6
    1f48:      	add	x2, x22, #0x6
    1f4c:      	mov	w9, #0x4                // =4
    1f50:      	strb	w8, [x0, #0x5]
    1f54:      	mov	w8, #0x1                // =1
    1f58:      	mov	x25, x0
    1f5c:      	mov	x0, x29
    1f60:      	mov	w1, #0x1                // =1
    1f64:      	blr	x9
    1f68:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    1f6c:      	ldrb	w8, [x25, #0x5]
    1f70:      	cmp	w8, #0x32
    1f74:      	b.gt	0x218c <generic_retkprobe_event+0x218c>
    1f78:      	cbz	w8, 0x21ac <generic_retkprobe_event+0x21ac>
    1f7c:      	cmp	w8, #0x2b
    1f80:      	b.eq	0x21ac <generic_retkprobe_event+0x21ac>
    1f84:      	cmp	w8, #0x2c
    1f88:      	b.ne	0x2278 <generic_retkprobe_event+0x2278>
    1f8c:      	mov	w8, #0x8                // =8
    1f90:      	b	0x21c4 <generic_retkprobe_event+0x21c4>
    1f94:      	add	x2, x22, #0x48
    1f98:      	mov	w21, #0x10              // =16
    1f9c:      	mov	w8, #0x4                // =4
    1fa0:      	mov	w1, #0x10               // =16
    1fa4:      	mov	w25, #0x4               // =4
    1fa8:      	blr	x8
    1fac:      	add	x2, x22, #0x38
    1fb0:      	mov	x0, x23
    1fb4:      	mov	w1, #0x10               // =16
    1fb8:      	blr	x25
    1fbc:      	ldr	x25, [sp, #0x28]
    1fc0:      	add	x2, x22, #0xe
    1fc4:      	mov	w21, #0x2               // =2
    1fc8:      	mov	w8, #0x4                // =4
    1fcc:      	mov	w1, #0x2                // =2
    1fd0:      	add	x23, x22, #0xc
    1fd4:      	mov	w22, #0x4               // =4
    1fd8:      	add	x0, x25, #0xbc
    1fdc:      	blr	x8
    1fe0:      	add	x0, x25, #0xbe
    1fe4:      	mov	w1, #0x2                // =2
    1fe8:      	mov	x2, x23
    1fec:      	blr	x22
    1ff0:      	ldrh	w8, [x25, #0xbe]
    1ff4:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1ff8:      	add	x9, sp, #0x98
    1ffc:      	add	x1, sp, #0x98
    2000:      	rev	w8, w8
    2004:      	lsr	w8, w8, #16
    2008:      	strh	w8, [x25, #0xbe]
    200c:      	ldr	x8, [x29, #0x18]
    2010:      	str	x8, [sp, #0x98]
    2014:      	mov	w8, #0x1                // =1
    2018:      	ldr	x0, [x0]
    201c:      	blr	x8
    2020:      	cbnz	x0, 0x2164 <generic_retkprobe_event+0x2164>
    2024:      	b	0x2894 <generic_retkprobe_event+0x2894>
    2028:      	mov	w21, #-0x2              // =-2
    202c:      	ldr	x22, [sp, #0x10]
    2030:      	str	w21, [x23, #0x9c]
    2034:      	b	0xd68 <generic_retkprobe_event+0xd68>
    2038:      	mov	w8, #-0x2               // =-2
    203c:      	mov	w29, #0x4               // =4
    2040:      	mov	x22, x25
    2044:      	str	w8, [x23, #0x9c]
    2048:      	b	0xd68 <generic_retkprobe_event+0xd68>
    204c:      	ldr	x24, [sp, #0x28]
    2050:      	add	x2, x22, #0x8
    2054:      	mov	w8, #0x10               // =16
    2058:      	mov	w9, #0x4                // =4
    205c:      	mov	w1, #0x10               // =16
    2060:      	mov	w21, #0x4               // =4
    2064:      	add	x0, x24, #0xa4
    2068:      	blr	x9
    206c:      	add	x0, x24, #0x9e
    2070:      	add	x2, x22, #0x2
    2074:      	mov	w8, #0x2                // =2
    2078:      	mov	w1, #0x2                // =2
    207c:      	blr	x21
    2080:      	ldr	x9, [sp, #0x28]
    2084:      	ldrh	w8, [x9, #0x9e]
    2088:      	rev	w8, w8
    208c:      	lsr	w8, w8, #16
    2090:      	strh	w8, [x9, #0x9e]
    2094:      	mov	w29, #0x18              // =24
    2098:      	mov	x22, x23
    209c:      	b	0xd68 <generic_retkprobe_event+0xd68>
    20a0:      	add	x2, x22, #0x3
    20a4:      	mov	w21, #0x6b              // =107
    20a8:      	mov	w8, #0x71               // =113
    20ac:      	mov	w1, #0x6b               // =107
    20b0:      	blr	x8
    20b4:      	tbnz	w0, #0x1f, 0x20c0 <generic_retkprobe_event+0x20c0>
    20b8:      	ldr	x8, [sp, #0x28]
    20bc:      	strb	w21, [x8, #0x9f]
    20c0:      	mov	w29, #0x70              // =112
    20c4:      	mov	x22, x24
    20c8:      	b	0xd68 <generic_retkprobe_event+0xd68>
    20cc:      	ldr	x0, [sp, #0x20]
    20d0:      	add	x2, x22, #0x48
    20d4:      	mov	w21, #0x10              // =16
    20d8:      	mov	w8, #0x4                // =4
    20dc:      	mov	w1, #0x10               // =16
    20e0:      	mov	w25, #0x4               // =4
    20e4:      	blr	x8
    20e8:      	add	x2, x22, #0x38
    20ec:      	mov	x0, x23
    20f0:      	mov	w1, #0x10               // =16
    20f4:      	blr	x25
    20f8:      	ldr	x25, [sp, #0x28]
    20fc:      	add	x2, x22, #0xe
    2100:      	mov	w21, #0x2               // =2
    2104:      	mov	w8, #0x4                // =4
    2108:      	mov	w1, #0x2                // =2
    210c:      	add	x23, x22, #0xc
    2110:      	mov	w22, #0x4               // =4
    2114:      	add	x0, x25, #0xbc
    2118:      	blr	x8
    211c:      	add	x0, x25, #0xbe
    2120:      	mov	w1, #0x2                // =2
    2124:      	mov	x2, x23
    2128:      	blr	x22
    212c:      	ldrh	w8, [x25, #0xbe]
    2130:      	rev	w8, w8
    2134:      	lsr	w8, w8, #16
    2138:      	strh	w8, [x25, #0xbe]
    213c:      	ldr	x8, [sp, #0x28]
    2140:      	adrp	x0, 0x2000 <generic_retkprobe_event+0x2000>
    2144:      	add	x9, sp, #0x98
    2148:      	add	x1, sp, #0x98
    214c:      	ldur	x8, [x8, #0xc4]
    2150:      	str	x8, [sp, #0x98]
    2154:      	mov	w8, #0x1                // =1
    2158:      	ldr	x0, [x0]
    215c:      	blr	x8
    2160:      	cbz	x0, 0x2894 <generic_retkprobe_event+0x2894>
    2164:      	ldr	w8, [x0]
    2168:      	str	w8, [x24, #0x10]
    216c:      	ldr	x8, [x0, #0x8]
    2170:      	str	x8, [x24, #0x18]
    2174:      	ldr	w8, [x0, #0x4]
    2178:      	str	w8, [x24, #0x7c]
    217c:      	b	0x2894 <generic_retkprobe_event+0x2894>
    2180:      	mov	x29, xzr
    2184:      	mov	x22, x23
    2188:      	b	0xd68 <generic_retkprobe_event+0xd68>
    218c:      	cmp	w8, #0x33
    2190:      	b.eq	0x21b8 <generic_retkprobe_event+0x21b8>
    2194:      	cmp	w8, #0x3c
    2198:      	b.eq	0x21ac <generic_retkprobe_event+0x21ac>
    219c:      	cmp	w8, #0xff
    21a0:      	b.ne	0x2278 <generic_retkprobe_event+0x2278>
    21a4:      	mov	w8, #0x28               // =40
    21a8:      	b	0x21c4 <generic_retkprobe_event+0x21c4>
    21ac:      	ldrb	w8, [x25, #0x7]
    21b0:      	lsl	w8, w8, #3
    21b4:      	b	0x21c0 <generic_retkprobe_event+0x21c0>
    21b8:      	ldrb	w8, [x25, #0x7]
    21bc:      	lsl	w8, w8, #2
    21c0:      	add	w8, w8, #0x8
    21c4:      	strh	w8, [x25, #0x2]
    21c8:      	ldrh	w9, [x25]
    21cc:      	add	w9, w9, w8
    21d0:      	ldrb	w8, [x25, #0x6]
    21d4:      	strh	w9, [x25]
    21d8:      	cmp	w8, #0x3c
    21dc:      	b.hi	0x2294 <generic_retkprobe_event+0x2294>
    21e0:      	mov	x21, #0x1               // =1
    21e4:      	mov	w10, #0x1               // =1
    21e8:      	movk	x21, #0x1800, lsl #32
    21ec:      	lsl	x10, x10, x8
    21f0:      	movk	x21, #0x1008, lsl #48
    21f4:      	tst	x10, x21
    21f8:      	b.eq	0x2294 <generic_retkprobe_event+0x2294>
    21fc:      	strb	w8, [x25, #0x5]
    2200:      	add	x8, x23, w9, uxth
    2204:      	mov	w9, #0x2                // =2
    2208:      	mov	w10, #0x4               // =4
    220c:      	mov	x0, x29
    2210:      	mov	w1, #0x2                // =2
    2214:      	ldrh	w8, [x25]
    2218:      	add	x2, x23, x8
    221c:      	blr	x10
    2220:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    2224:      	ldrb	w8, [x25, #0x5]
    2228:      	cmp	w8, #0x32
    222c:      	b.gt	0x224c <generic_retkprobe_event+0x224c>
    2230:      	cbz	w8, 0x226c <generic_retkprobe_event+0x226c>
    2234:      	cmp	w8, #0x2b
    2238:      	b.eq	0x226c <generic_retkprobe_event+0x226c>
    223c:      	cmp	w8, #0x2c
    2240:      	b.ne	0x2350 <generic_retkprobe_event+0x2350>
    2244:      	mov	w8, #0x8                // =8
    2248:      	b	0x22a8 <generic_retkprobe_event+0x22a8>
    224c:      	cmp	w8, #0x33
    2250:      	b.eq	0x229c <generic_retkprobe_event+0x229c>
    2254:      	cmp	w8, #0x3c
    2258:      	b.eq	0x226c <generic_retkprobe_event+0x226c>
    225c:      	cmp	w8, #0xff
    2260:      	b.ne	0x2350 <generic_retkprobe_event+0x2350>
    2264:      	mov	w8, #0x28               // =40
    2268:      	b	0x22a8 <generic_retkprobe_event+0x22a8>
    226c:      	ldrb	w8, [x25, #0x7]
    2270:      	lsl	w8, w8, #3
    2274:      	b	0x22a4 <generic_retkprobe_event+0x22a4>
    2278:      	ldrh	w8, [x25, #0x2]
    227c:      	ldrh	w9, [x25]
    2280:      	add	w9, w9, w8
    2284:      	ldrb	w8, [x25, #0x6]
    2288:      	strh	w9, [x25]
    228c:      	cmp	w8, #0x3c
    2290:      	b.ls	0x21e0 <generic_retkprobe_event+0x21e0>
    2294:      	strh	w9, [sp, #0x90]
    2298:      	b	0x2720 <generic_retkprobe_event+0x2720>
    229c:      	ldrb	w8, [x25, #0x7]
    22a0:      	lsl	w8, w8, #2
    22a4:      	add	w8, w8, #0x8
    22a8:      	strh	w8, [x25, #0x2]
    22ac:      	ldrh	w9, [x25]
    22b0:      	add	w9, w9, w8
    22b4:      	ldrb	w8, [x25, #0x6]
    22b8:      	strh	w9, [x25]
    22bc:      	cmp	w8, #0x3c
    22c0:      	b.hi	0x28bc <generic_retkprobe_event+0x28bc>
    22c4:      	mov	w10, #0x1               // =1
    22c8:      	lsl	x10, x10, x8
    22cc:      	tst	x10, x21
    22d0:      	b.eq	0x28bc <generic_retkprobe_event+0x28bc>
    22d4:      	strb	w8, [x25, #0x5]
    22d8:      	add	x8, x23, w9, uxth
    22dc:      	mov	w9, #0x2                // =2
    22e0:      	mov	w10, #0x4               // =4
    22e4:      	mov	x0, x29
    22e8:      	mov	w1, #0x2                // =2
    22ec:      	ldrh	w8, [x25]
    22f0:      	add	x2, x23, x8
    22f4:      	blr	x10
    22f8:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    22fc:      	ldrb	w8, [x25, #0x5]
    2300:      	cmp	w8, #0x32
    2304:      	b.gt	0x2324 <generic_retkprobe_event+0x2324>
    2308:      	cbz	w8, 0x2344 <generic_retkprobe_event+0x2344>
    230c:      	cmp	w8, #0x2b
    2310:      	b.eq	0x2344 <generic_retkprobe_event+0x2344>
    2314:      	cmp	w8, #0x2c
    2318:      	b.ne	0x2424 <generic_retkprobe_event+0x2424>
    231c:      	mov	w8, #0x8                // =8
    2320:      	b	0x237c <generic_retkprobe_event+0x237c>
    2324:      	cmp	w8, #0x33
    2328:      	b.eq	0x2370 <generic_retkprobe_event+0x2370>
    232c:      	cmp	w8, #0x3c
    2330:      	b.eq	0x2344 <generic_retkprobe_event+0x2344>
    2334:      	cmp	w8, #0xff
    2338:      	b.ne	0x2424 <generic_retkprobe_event+0x2424>
    233c:      	mov	w8, #0x28               // =40
    2340:      	b	0x237c <generic_retkprobe_event+0x237c>
    2344:      	ldrb	w8, [x25, #0x7]
    2348:      	lsl	w8, w8, #3
    234c:      	b	0x2378 <generic_retkprobe_event+0x2378>
    2350:      	ldrh	w8, [x25, #0x2]
    2354:      	ldrh	w9, [x25]
    2358:      	add	w9, w9, w8
    235c:      	ldrb	w8, [x25, #0x6]
    2360:      	strh	w9, [x25]
    2364:      	cmp	w8, #0x3c
    2368:      	b.ls	0x22c4 <generic_retkprobe_event+0x22c4>
    236c:      	b	0x28bc <generic_retkprobe_event+0x28bc>
    2370:      	ldrb	w8, [x25, #0x7]
    2374:      	lsl	w8, w8, #2
    2378:      	add	w8, w8, #0x8
    237c:      	strh	w8, [x25, #0x2]
    2380:      	ldrh	w9, [x25]
    2384:      	add	w9, w9, w8
    2388:      	ldrb	w8, [x25, #0x6]
    238c:      	strh	w9, [x25]
    2390:      	cmp	w8, #0x3c
    2394:      	b.hi	0x28bc <generic_retkprobe_event+0x28bc>
    2398:      	mov	w10, #0x1               // =1
    239c:      	lsl	x10, x10, x8
    23a0:      	tst	x10, x21
    23a4:      	b.eq	0x28bc <generic_retkprobe_event+0x28bc>
    23a8:      	strb	w8, [x25, #0x5]
    23ac:      	add	x8, x23, w9, uxth
    23b0:      	mov	w9, #0x2                // =2
    23b4:      	mov	w10, #0x4               // =4
    23b8:      	mov	x0, x29
    23bc:      	mov	w1, #0x2                // =2
    23c0:      	ldrh	w8, [x25]
    23c4:      	add	x2, x23, x8
    23c8:      	blr	x10
    23cc:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    23d0:      	ldrb	w8, [x25, #0x5]
    23d4:      	cmp	w8, #0x32
    23d8:      	b.gt	0x23f8 <generic_retkprobe_event+0x23f8>
    23dc:      	cbz	w8, 0x2418 <generic_retkprobe_event+0x2418>
    23e0:      	cmp	w8, #0x2b
    23e4:      	b.eq	0x2418 <generic_retkprobe_event+0x2418>
    23e8:      	cmp	w8, #0x2c
    23ec:      	b.ne	0x24f8 <generic_retkprobe_event+0x24f8>
    23f0:      	mov	w8, #0x8                // =8
    23f4:      	b	0x2450 <generic_retkprobe_event+0x2450>
    23f8:      	cmp	w8, #0x33
    23fc:      	b.eq	0x2444 <generic_retkprobe_event+0x2444>
    2400:      	cmp	w8, #0x3c
    2404:      	b.eq	0x2418 <generic_retkprobe_event+0x2418>
    2408:      	cmp	w8, #0xff
    240c:      	b.ne	0x24f8 <generic_retkprobe_event+0x24f8>
    2410:      	mov	w8, #0x28               // =40
    2414:      	b	0x2450 <generic_retkprobe_event+0x2450>
    2418:      	ldrb	w8, [x25, #0x7]
    241c:      	lsl	w8, w8, #3
    2420:      	b	0x244c <generic_retkprobe_event+0x244c>
    2424:      	ldrh	w8, [x25, #0x2]
    2428:      	ldrh	w9, [x25]
    242c:      	add	w9, w9, w8
    2430:      	ldrb	w8, [x25, #0x6]
    2434:      	strh	w9, [x25]
    2438:      	cmp	w8, #0x3c
    243c:      	b.ls	0x2398 <generic_retkprobe_event+0x2398>
    2440:      	b	0x28bc <generic_retkprobe_event+0x28bc>
    2444:      	ldrb	w8, [x25, #0x7]
    2448:      	lsl	w8, w8, #2
    244c:      	add	w8, w8, #0x8
    2450:      	strh	w8, [x25, #0x2]
    2454:      	ldrh	w9, [x25]
    2458:      	add	w9, w9, w8
    245c:      	ldrb	w8, [x25, #0x6]
    2460:      	strh	w9, [x25]
    2464:      	cmp	w8, #0x3c
    2468:      	b.hi	0x28bc <generic_retkprobe_event+0x28bc>
    246c:      	mov	w10, #0x1               // =1
    2470:      	lsl	x10, x10, x8
    2474:      	tst	x10, x21
    2478:      	b.eq	0x28bc <generic_retkprobe_event+0x28bc>
    247c:      	strb	w8, [x25, #0x5]
    2480:      	add	x8, x23, w9, uxth
    2484:      	mov	w9, #0x2                // =2
    2488:      	mov	w10, #0x4               // =4
    248c:      	mov	x0, x29
    2490:      	mov	w1, #0x2                // =2
    2494:      	ldrh	w8, [x25]
    2498:      	add	x2, x23, x8
    249c:      	blr	x10
    24a0:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    24a4:      	ldrb	w8, [x25, #0x5]
    24a8:      	cmp	w8, #0x32
    24ac:      	b.gt	0x24cc <generic_retkprobe_event+0x24cc>
    24b0:      	cbz	w8, 0x24ec <generic_retkprobe_event+0x24ec>
    24b4:      	cmp	w8, #0x2b
    24b8:      	b.eq	0x24ec <generic_retkprobe_event+0x24ec>
    24bc:      	cmp	w8, #0x2c
    24c0:      	b.ne	0x25cc <generic_retkprobe_event+0x25cc>
    24c4:      	mov	w8, #0x8                // =8
    24c8:      	b	0x2524 <generic_retkprobe_event+0x2524>
    24cc:      	cmp	w8, #0x33
    24d0:      	b.eq	0x2518 <generic_retkprobe_event+0x2518>
    24d4:      	cmp	w8, #0x3c
    24d8:      	b.eq	0x24ec <generic_retkprobe_event+0x24ec>
    24dc:      	cmp	w8, #0xff
    24e0:      	b.ne	0x25cc <generic_retkprobe_event+0x25cc>
    24e4:      	mov	w8, #0x28               // =40
    24e8:      	b	0x2524 <generic_retkprobe_event+0x2524>
    24ec:      	ldrb	w8, [x25, #0x7]
    24f0:      	lsl	w8, w8, #3
    24f4:      	b	0x2520 <generic_retkprobe_event+0x2520>
    24f8:      	ldrh	w8, [x25, #0x2]
    24fc:      	ldrh	w9, [x25]
    2500:      	add	w9, w9, w8
    2504:      	ldrb	w8, [x25, #0x6]
    2508:      	strh	w9, [x25]
    250c:      	cmp	w8, #0x3c
    2510:      	b.ls	0x246c <generic_retkprobe_event+0x246c>
    2514:      	b	0x28bc <generic_retkprobe_event+0x28bc>
    2518:      	ldrb	w8, [x25, #0x7]
    251c:      	lsl	w8, w8, #2
    2520:      	add	w8, w8, #0x8
    2524:      	strh	w8, [x25, #0x2]
    2528:      	ldrh	w9, [x25]
    252c:      	add	w9, w9, w8
    2530:      	ldrb	w8, [x25, #0x6]
    2534:      	strh	w9, [x25]
    2538:      	cmp	w8, #0x3c
    253c:      	b.hi	0x28bc <generic_retkprobe_event+0x28bc>
    2540:      	mov	w10, #0x1               // =1
    2544:      	lsl	x10, x10, x8
    2548:      	tst	x10, x21
    254c:      	b.eq	0x28bc <generic_retkprobe_event+0x28bc>
    2550:      	strb	w8, [x25, #0x5]
    2554:      	add	x8, x23, w9, uxth
    2558:      	mov	w9, #0x2                // =2
    255c:      	mov	w10, #0x4               // =4
    2560:      	mov	x0, x29
    2564:      	mov	w1, #0x2                // =2
    2568:      	ldrh	w8, [x25]
    256c:      	add	x2, x23, x8
    2570:      	blr	x10
    2574:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    2578:      	ldrb	w8, [x25, #0x5]
    257c:      	cmp	w8, #0x32
    2580:      	b.gt	0x25a0 <generic_retkprobe_event+0x25a0>
    2584:      	cbz	w8, 0x25c0 <generic_retkprobe_event+0x25c0>
    2588:      	cmp	w8, #0x2b
    258c:      	b.eq	0x25c0 <generic_retkprobe_event+0x25c0>
    2590:      	cmp	w8, #0x2c
    2594:      	b.ne	0x26a0 <generic_retkprobe_event+0x26a0>
    2598:      	mov	w8, #0x8                // =8
    259c:      	b	0x25f8 <generic_retkprobe_event+0x25f8>
    25a0:      	cmp	w8, #0x33
    25a4:      	b.eq	0x25ec <generic_retkprobe_event+0x25ec>
    25a8:      	cmp	w8, #0x3c
    25ac:      	b.eq	0x25c0 <generic_retkprobe_event+0x25c0>
    25b0:      	cmp	w8, #0xff
    25b4:      	b.ne	0x26a0 <generic_retkprobe_event+0x26a0>
    25b8:      	mov	w8, #0x28               // =40
    25bc:      	b	0x25f8 <generic_retkprobe_event+0x25f8>
    25c0:      	ldrb	w8, [x25, #0x7]
    25c4:      	lsl	w8, w8, #3
    25c8:      	b	0x25f4 <generic_retkprobe_event+0x25f4>
    25cc:      	ldrh	w8, [x25, #0x2]
    25d0:      	ldrh	w9, [x25]
    25d4:      	add	w9, w9, w8
    25d8:      	ldrb	w8, [x25, #0x6]
    25dc:      	strh	w9, [x25]
    25e0:      	cmp	w8, #0x3c
    25e4:      	b.ls	0x2540 <generic_retkprobe_event+0x2540>
    25e8:      	b	0x28bc <generic_retkprobe_event+0x28bc>
    25ec:      	ldrb	w8, [x25, #0x7]
    25f0:      	lsl	w8, w8, #2
    25f4:      	add	w8, w8, #0x8
    25f8:      	strh	w8, [x25, #0x2]
    25fc:      	ldrh	w9, [x25]
    2600:      	add	w9, w9, w8
    2604:      	ldrb	w8, [x25, #0x6]
    2608:      	strh	w9, [x25]
    260c:      	cmp	w8, #0x3c
    2610:      	b.hi	0x28bc <generic_retkprobe_event+0x28bc>
    2614:      	mov	w10, #0x1               // =1
    2618:      	lsl	x10, x10, x8
    261c:      	tst	x10, x21
    2620:      	b.eq	0x28bc <generic_retkprobe_event+0x28bc>
    2624:      	strb	w8, [x25, #0x5]
    2628:      	add	x8, x23, w9, uxth
    262c:      	mov	w9, #0x2                // =2
    2630:      	mov	w10, #0x4               // =4
    2634:      	mov	x0, x29
    2638:      	mov	w1, #0x2                // =2
    263c:      	ldrh	w8, [x25]
    2640:      	add	x2, x23, x8
    2644:      	blr	x10
    2648:      	tbnz	x0, #0x3f, 0x271c <generic_retkprobe_event+0x271c>
    264c:      	ldrb	w8, [x25, #0x5]
    2650:      	cmp	w8, #0x32
    2654:      	b.gt	0x2674 <generic_retkprobe_event+0x2674>
    2658:      	cbz	w8, 0x2694 <generic_retkprobe_event+0x2694>
    265c:      	cmp	w8, #0x2b
    2660:      	b.eq	0x2694 <generic_retkprobe_event+0x2694>
    2664:      	cmp	w8, #0x2c
    2668:      	b.ne	0x28a0 <generic_retkprobe_event+0x28a0>
    266c:      	mov	w8, #0x8                // =8
    2670:      	b	0x26cc <generic_retkprobe_event+0x26cc>
    2674:      	cmp	w8, #0x33
    2678:      	b.eq	0x26c0 <generic_retkprobe_event+0x26c0>
    267c:      	cmp	w8, #0x3c
    2680:      	b.eq	0x2694 <generic_retkprobe_event+0x2694>
    2684:      	cmp	w8, #0xff
    2688:      	b.ne	0x28a0 <generic_retkprobe_event+0x28a0>
    268c:      	mov	w8, #0x28               // =40
    2690:      	b	0x26cc <generic_retkprobe_event+0x26cc>
    2694:      	ldrb	w8, [x25, #0x7]
    2698:      	lsl	w8, w8, #3
    269c:      	b	0x26c8 <generic_retkprobe_event+0x26c8>
    26a0:      	ldrh	w8, [x25, #0x2]
    26a4:      	ldrh	w9, [x25]
    26a8:      	add	w9, w9, w8
    26ac:      	ldrb	w8, [x25, #0x6]
    26b0:      	strh	w9, [x25]
    26b4:      	cmp	w8, #0x3c
    26b8:      	b.ls	0x2614 <generic_retkprobe_event+0x2614>
    26bc:      	b	0x28bc <generic_retkprobe_event+0x28bc>
    26c0:      	ldrb	w8, [x25, #0x7]
    26c4:      	lsl	w8, w8, #2
    26c8:      	add	w8, w8, #0x8
    26cc:      	strh	w8, [x25, #0x2]
    26d0:      	ldrh	w9, [x25]
    26d4:      	add	w9, w9, w8
    26d8:      	ldrb	w8, [x25, #0x6]
    26dc:      	strh	w9, [x25]
    26e0:      	cmp	w8, #0x3c
    26e4:      	b.hi	0x28bc <generic_retkprobe_event+0x28bc>
    26e8:      	mov	w10, #0x1               // =1
    26ec:      	lsl	x10, x10, x8
    26f0:      	tst	x10, x21
    26f4:      	b.eq	0x28bc <generic_retkprobe_event+0x28bc>
    26f8:      	strb	w8, [x25, #0x5]
    26fc:      	add	x8, x23, w9, uxth
    2700:      	mov	w9, #0x2                // =2
    2704:      	mov	w10, #0x4               // =4
    2708:      	mov	x0, x29
    270c:      	mov	w1, #0x2                // =2
    2710:      	ldrh	w8, [x25]
    2714:      	add	x2, x23, x8
    2718:      	blr	x10
    271c:      	mov	w8, wzr
    2720:      	ldp	x0, x25, [sp, #0x20]
    2724:      	add	x2, x22, #0x8
    2728:      	mov	w21, #0x10              // =16
    272c:      	mov	w1, #0x10               // =16
    2730:      	mov	w23, #0x4               // =4
    2734:      	strb	w8, [sp, #0x88]
    2738:      	strh	w8, [x25, #0xc0]
    273c:      	mov	w8, #0xa                // =10
    2740:      	strh	w8, [x25, #0xc2]
    2744:      	mov	w8, #0x4                // =4
    2748:      	blr	x8
    274c:      	add	x0, x25, #0xac
    2750:      	add	x2, x22, #0x18
    2754:      	mov	w1, #0x10               // =16
    2758:      	blr	x23
    275c:      	ldrb	w8, [sp, #0x88]
    2760:      	cmp	w8, #0x11
    2764:      	b.eq	0x27a8 <generic_retkprobe_event+0x27a8>
    2768:      	cmp	w8, #0x6
    276c:      	b.ne	0x27e8 <generic_retkprobe_event+0x27e8>
    2770:      	ldr	x8, [sp, #0x98]
    2774:      	ldrh	w9, [sp, #0x90]
    2778:      	mov	w21, #0x2               // =2
    277c:      	mov	w1, #0x2                // =2
    2780:      	mov	w23, #0x4               // =4
    2784:      	add	x22, x8, x9
    2788:      	ldr	x25, [sp, #0x28]
    278c:      	add	x0, x25, #0xbc
    2790:      	mov	w8, #0x4                // =4
    2794:      	mov	x2, x22
    2798:      	blr	x8
    279c:      	add	x0, x25, #0xbe
    27a0:      	add	x2, x22, #0x2
    27a4:      	b	0x27dc <generic_retkprobe_event+0x27dc>
    27a8:      	ldr	x8, [sp, #0x98]
    27ac:      	ldrh	w9, [sp, #0x90]
    27b0:      	mov	w21, #0x2               // =2
    27b4:      	mov	w1, #0x2                // =2
    27b8:      	mov	w23, #0x4               // =4
    27bc:      	add	x22, x8, x9
    27c0:      	ldr	x25, [sp, #0x28]
    27c4:      	add	x0, x25, #0xbc
    27c8:      	mov	w8, #0x4                // =4
    27cc:      	mov	x2, x22
    27d0:      	blr	x8
    27d4:      	add	x0, x25, #0xbe
    27d8:      	add	x2, x22, #0x2
    27dc:      	mov	w1, #0x2                // =2
    27e0:      	blr	x23
    27e4:      	b	0x27f0 <generic_retkprobe_event+0x27f0>
    27e8:      	ldr	x25, [sp, #0x28]
    27ec:      	str	wzr, [x25, #0xbc]
    27f0:      	ldrh	w8, [x25, #0xbc]
    27f4:      	add	x2, x24, #0xe0
    27f8:      	mov	w9, #0x4                // =4
    27fc:      	add	x10, sp, #0xe8
    2800:      	add	x0, sp, #0xe8
    2804:      	mov	w1, #0x8                // =8
    2808:      	rev	w8, w8
    280c:      	lsr	w8, w8, #16
    2810:      	strh	w8, [x25, #0xbc]
    2814:      	ldrh	w8, [x25, #0xbe]
    2818:      	rev	w8, w8
    281c:      	lsr	w8, w8, #16
    2820:      	strh	w8, [x25, #0xbe]
    2824:      	mov	w8, #0x8                // =8
    2828:      	blr	x9
    282c:      	add	x22, sp, #0xe0
    2830:      	ldr	x8, [x22, #0x8]
    2834:      	cbz	x8, 0x2894 <generic_retkprobe_event+0x2894>
    2838:      	add	x8, x8, #0x5
    283c:      	mov	w9, #0x8                // =8
    2840:      	add	x10, sp, #0x70
    2844:      	mov	w11, #0x4               // =4
    2848:      	ldr	x8, [x22, #0x8]
    284c:      	add	x0, sp, #0x70
    2850:      	mov	w1, #0x8                // =8
    2854:      	mov	w21, #0x4               // =4
    2858:      	add	x2, x8, #0x5
    285c:      	blr	x11
    2860:      	ldr	x8, [x22, #0x8]
    2864:      	ldr	x9, [sp, #0x70]
    2868:      	mov	w1, #0x4                // =4
    286c:      	add	x22, x8, x9, lsl #3
    2870:      	ldr	x23, [sp, #0x28]
    2874:      	add	x0, x23, #0xd4
    2878:      	mov	w8, #0x4                // =4
    287c:      	add	x2, x22, #0x44
    2880:      	blr	x8
    2884:      	add	x0, x23, #0xd8
    2888:      	add	x2, x22, #0x45
    288c:      	mov	w1, #0x4                // =4
    2890:      	blr	x21
    2894:      	ldr	x22, [sp, #0x10]
    2898:      	mov	w29, #0x40              // =64
    289c:      	b	0xd68 <generic_retkprobe_event+0xd68>
    28a0:      	ldrh	w8, [x25, #0x2]
    28a4:      	ldrh	w9, [x25]
    28a8:      	add	w9, w9, w8
    28ac:      	ldrb	w8, [x25, #0x6]
    28b0:      	strh	w9, [x25]
    28b4:      	cmp	w8, #0x3c
    28b8:      	b.ls	0x26e8 <generic_retkprobe_event+0x26e8>
    28bc:      	strh	w9, [sp, #0x90]
    28c0:      	b	0x2720 <generic_retkprobe_event+0x2720>
