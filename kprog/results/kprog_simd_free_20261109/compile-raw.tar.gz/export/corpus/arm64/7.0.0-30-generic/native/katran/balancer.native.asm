
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/katran/balancer.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <jhash_2words>:
       0:      	mov	w8, #0xc0f7             // =49399
       4:      	movk	w8, #0xe0ad, lsl #16
       8:      	add	w10, w1, w8
       c:      	add	w9, w0, w8
      10:      	eor	w8, w10, w8
      14:      	ror	w11, w10, #0x12
      18:      	sub	w8, w8, w11
      1c:      	eor	w9, w8, w9
      20:      	ror	w11, w8, #0x15
      24:      	sub	w9, w9, w11
      28:      	eor	w10, w9, w10
      2c:      	ror	w11, w9, #0x7
      30:      	sub	w10, w10, w11
      34:      	eor	w8, w10, w8
      38:      	ror	w11, w10, #0x10
      3c:      	sub	w8, w8, w11
      40:      	eor	w9, w8, w9
      44:      	ror	w11, w8, #0x1c
      48:      	sub	w9, w9, w11
      4c:      	eor	w10, w9, w10
      50:      	ror	w9, w9, #0x12
      54:      	sub	w9, w10, w9
      58:      	eor	w8, w9, w8
      5c:      	ror	w9, w9, #0x8
      60:      	sub	w0, w8, w9
      64:      	ret
      68:      	nop
      6c:      	nop

0000000000000070 <jhash>:
      70:      	ldp	w10, w9, [x0]
      74:      	ldr	w11, [x0, #0x8]
      78:      	mov	w8, #0xc0ff             // =49407
      7c:      	movk	w8, #0xdead, lsl #16
      80:      	add	w9, w9, w8
      84:      	sub	w10, w10, w11
      88:      	add	w8, w11, w8
      8c:      	eor	w10, w10, w8, ror #28
      90:      	add	w8, w8, w9
      94:      	sub	w11, w9, w10
      98:      	add	w9, w10, w8
      9c:      	eor	w11, w11, w10, ror #26
      a0:      	sub	w8, w8, w11
      a4:      	add	w10, w11, w9
      a8:      	eor	w8, w8, w11, ror #24
      ac:      	sub	w9, w9, w8
      b0:      	eor	w9, w9, w8, ror #16
      b4:      	add	w8, w8, w10
      b8:      	sub	w11, w10, w9
      bc:      	eor	w11, w11, w9, ror #13
      c0:      	add	w9, w9, w8
      c4:      	sub	w8, w8, w11
      c8:      	add	w10, w11, w9
      cc:      	eor	w8, w8, w11, ror #28
      d0:      	ldrb	w11, [x0, #0xf]
      d4:      	eor	w8, w8, w10
      d8:      	add	w9, w9, w11, lsl #24
      dc:      	ldrb	w11, [x0, #0xe]
      e0:      	add	w9, w9, w11, lsl #16
      e4:      	ldrb	w11, [x0, #0xd]
      e8:      	add	w9, w9, w11, lsl #8
      ec:      	ldrb	w11, [x0, #0xc]
      f0:      	add	w9, w9, w11
      f4:      	ror	w11, w10, #0x12
      f8:      	sub	w8, w8, w11
      fc:      	eor	w9, w9, w8
     100:      	ror	w11, w8, #0x15
     104:      	sub	w9, w9, w11
     108:      	eor	w10, w9, w10
     10c:      	ror	w11, w9, #0x7
     110:      	sub	w10, w10, w11
     114:      	eor	w8, w10, w8
     118:      	ror	w11, w10, #0x10
     11c:      	sub	w8, w8, w11
     120:      	eor	w9, w8, w9
     124:      	ror	w11, w8, #0x1c
     128:      	sub	w9, w9, w11
     12c:      	eor	w10, w9, w10
     130:      	ror	w9, w9, #0x12
     134:      	sub	w9, w10, w9
     138:      	ror	w10, w9, #0x8
     13c:      	eor	w8, w9, w8
     140:      	sub	w0, w8, w10
     144:      	ret

Disassembly of section xdp:

0000000000000000 <balancer_ingress>:
       0:      	sub	sp, sp, #0xf0
       4:      	str	x29, [sp, #0xa0]
       8:      	stp	x30, x25, [sp, #0xb0]
       c:      	stp	x24, x23, [sp, #0xc0]
      10:      	stp	x22, x21, [sp, #0xd0]
      14:      	stp	x20, x19, [sp, #0xe0]
      18:      	ldp	x21, x22, [x0]
      1c:      	add	x8, x21, #0xe
      20:      	cmp	x8, x22
      24:      	b.ls	0x30 <balancer_ingress+0x30>
      28:      	mov	w20, #0x1               // =1
      2c:      	b	0x18b8 <balancer_ingress+0x18b8>
      30:      	mov	w8, #0x210              // =528
      34:      	mov	x19, x0
      38:      	adrp	x0, 0x0 <balancer_ingress>
      3c:      	str	w8, [sp, #0x14]
      40:      	mov	w20, #0x1               // =1
      44:      	add	x1, sp, #0x14
      48:      	ldr	x0, [x0]
      4c:      	blr	x20
      50:      	cbz	x0, 0x18b8 <balancer_ingress+0x18b8>
      54:      	ldp	x8, x9, [x0]
      58:      	sub	x24, x22, x21
      5c:      	add	x8, x8, #0x1
      60:      	add	x9, x9, x24
      64:      	stp	x8, x9, [x0]
      68:      	mov	w9, #0xdd86             // =56710
      6c:      	ldrh	w8, [x21, #0xc]
      70:      	cmp	w8, w9
      74:      	b.eq	0x154 <balancer_ingress+0x154>
      78:      	cmp	w8, #0x8
      7c:      	b.ne	0x1870 <balancer_ingress+0x1870>
      80:      	ldp	x22, x29, [x19]
      84:      	add	x10, x22, #0x22
      88:      	stp	xzr, xzr, [sp, #0x60]
      8c:      	str	wzr, [sp, #0x38]
      90:      	stp	xzr, xzr, [sp, #0x50]
      94:      	stp	xzr, xzr, [sp, #0x40]
      98:      	str	wzr, [sp, #0x20]
      9c:      	cmp	x10, x29
      a0:      	stp	xzr, xzr, [sp, #0x28]
      a4:      	b.hi	0x1850 <balancer_ingress+0x1850>
      a8:      	ldrb	w8, [x22, #0xe]
      ac:      	and	w8, w8, #0xf
      b0:      	cmp	w8, #0x5
      b4:      	b.ne	0x1850 <balancer_ingress+0x1850>
      b8:      	ldrb	w8, [x22, #0xf]
      bc:      	strb	w8, [sp, #0x6d]
      c0:      	ldrb	w8, [x22, #0x17]
      c4:      	strb	w8, [sp, #0x64]
      c8:      	ldrh	w9, [x22, #0x14]
      cc:      	tst	w9, #0xffffff3f
      d0:      	b.ne	0x1850 <balancer_ingress+0x1850>
      d4:      	ldrh	w25, [x22, #0x10]
      d8:      	cmp	w8, #0x1
      dc:      	b.ne	0x3a4 <balancer_ingress+0x3a4>
      e0:      	add	x20, x22, #0x2a
      e4:      	cmp	x20, x29
      e8:      	b.hi	0x1850 <balancer_ingress+0x1850>
      ec:      	ldrb	w8, [x10]
      f0:      	cmp	w8, #0x3
      f4:      	b.eq	0x920 <balancer_ingress+0x920>
      f8:      	cmp	w8, #0x8
      fc:      	b.ne	0x9ec <balancer_ingress+0x9ec>
     100:      	mov	w8, #0x40               // =64
     104:      	ldrh	w11, [x22, #0xe]
     108:      	ldur	w10, [x22, #0x1e]
     10c:      	add	x11, x11, x25
     110:      	strb	w8, [x22, #0x16]
     114:      	ldrh	w8, [x22, #0x12]
     118:      	ldrh	w12, [x22, #0x16]
     11c:      	strb	wzr, [x22, #0x22]
     120:      	add	x8, x11, x8
     124:      	ldur	w11, [x22, #0x1a]
     128:      	stur	w10, [x22, #0x1a]
     12c:      	add	x9, x9, x12
     130:      	ldrh	w12, [x22, #0x1c]
     134:      	add	x8, x8, x9
     138:      	add	x8, x8, w10, uxth
     13c:      	ldrh	w10, [x22, #0x24]
     140:      	stur	w11, [x22, #0x1e]
     144:      	ldrh	w9, [x22, #0x20]
     148:      	add	x8, x8, x12
     14c:      	add	x8, x8, w11, uxth
     150:      	b	0x2dc <balancer_ingress+0x2dc>
     154:      	ldp	x22, x23, [x19]
     158:      	add	x9, x22, #0x36
     15c:      	stp	xzr, xzr, [sp, #0x60]
     160:      	str	wzr, [sp, #0x38]
     164:      	stp	xzr, xzr, [sp, #0x50]
     168:      	stp	xzr, xzr, [sp, #0x40]
     16c:      	str	wzr, [sp, #0x20]
     170:      	cmp	x9, x23
     174:      	stp	xzr, xzr, [sp, #0x28]
     178:      	b.hi	0x1850 <balancer_ingress+0x1850>
     17c:      	ldrb	w8, [x22, #0x14]
     180:      	strb	w8, [sp, #0x64]
     184:      	cmp	w8, #0x2c
     188:      	ldrb	w10, [x22, #0xe]
     18c:      	lsl	w11, w10, #4
     190:      	strb	w11, [sp, #0x6d]
     194:      	ldrb	w11, [x22, #0xf]
     198:      	lsr	w11, w11, #4
     19c:      	bfi	w11, w10, #4, #28
     1a0:      	strb	w11, [sp, #0x6d]
     1a4:      	b.eq	0x1850 <balancer_ingress+0x1850>
     1a8:      	ldrh	w25, [x22, #0x12]
     1ac:      	cmp	w8, #0x3a
     1b0:      	b.ne	0x244 <balancer_ingress+0x244>
     1b4:      	add	x8, x22, #0x3e
     1b8:      	cmp	x8, x23
     1bc:      	b.hi	0x1850 <balancer_ingress+0x1850>
     1c0:      	ldrb	w8, [x9]
     1c4:      	cmp	w8, #0x1
     1c8:      	b.eq	0x648 <balancer_ingress+0x648>
     1cc:      	cmp	w8, #0x2
     1d0:      	b.eq	0x600 <balancer_ingress+0x600>
     1d4:      	cmp	w8, #0x80
     1d8:      	b.ne	0x9ec <balancer_ingress+0x9ec>
     1dc:      	mov	w10, #0x40              // =64
     1e0:      	ldur	x9, [x22, #0x16]
     1e4:      	mov	w8, #0x81               // =129
     1e8:      	mov	w20, #0x3               // =3
     1ec:      	strb	w10, [x22, #0x15]
     1f0:      	ldur	x10, [x22, #0x26]
     1f4:      	strb	w8, [x22, #0x36]
     1f8:      	ldur	x8, [x22, #0x1e]
     1fc:      	stur	x9, [x22, #0x26]
     200:      	stur	x10, [x22, #0x16]
     204:      	ldur	x10, [x22, #0x2e]
     208:      	stp	x9, x8, [sp, #0x70]
     20c:      	stur	x8, [x22, #0x2e]
     210:      	ldur	w9, [x22, #0x6]
     214:      	stur	x10, [x22, #0x1e]
     218:      	ldrh	w10, [x22, #0x38]
     21c:      	sub	w8, w10, #0x1
     220:      	ldr	w10, [x22]
     224:      	str	w9, [x22]
     228:      	strh	w8, [x22, #0x38]
     22c:      	ldrh	w8, [x22, #0xa]
     230:      	stur	w10, [x22, #0x6]
     234:      	ldrh	w10, [x22, #0x4]
     238:      	strh	w8, [x22, #0x4]
     23c:      	strh	w10, [x22, #0xa]
     240:      	b	0x1854 <balancer_ingress+0x1854>
     244:      	ldur	x10, [x22, #0x16]
     248:      	ldur	x11, [x22, #0x1e]
     24c:      	cmp	w8, #0x1
     250:      	stp	x10, x11, [sp, #0x40]
     254:      	ldur	x10, [x22, #0x26]
     258:      	ldur	x11, [x22, #0x2e]
     25c:      	stp	x10, x11, [sp, #0x50]
     260:      	b.ne	0x34c <balancer_ingress+0x34c>
     264:      	add	x20, x22, #0x3e
     268:      	cmp	x20, x23
     26c:      	b.hi	0x1850 <balancer_ingress+0x1850>
     270:      	ldrb	w8, [x9]
     274:      	cmp	w8, #0x3
     278:      	b.eq	0x684 <balancer_ingress+0x684>
     27c:      	cmp	w8, #0x8
     280:      	b.ne	0x9ec <balancer_ingress+0x9ec>
     284:      	mov	w8, #0x40               // =64
     288:      	ldrh	w10, [x22, #0xe]
     28c:      	ldrh	w11, [x22, #0x10]
     290:      	add	x10, x10, x11
     294:      	ldrh	w12, [x22, #0x12]
     298:      	strb	w8, [x22, #0x16]
     29c:      	ldrh	w8, [x22, #0x14]
     2a0:      	ldur	w9, [x22, #0x1e]
     2a4:      	ldrh	w11, [x22, #0x16]
     2a8:      	strb	wzr, [x22, #0x22]
     2ac:      	add	x8, x12, x8
     2b0:      	ldur	w12, [x22, #0x1a]
     2b4:      	stur	w9, [x22, #0x1a]
     2b8:      	add	x8, x10, x8
     2bc:      	ldrh	w10, [x22, #0x1c]
     2c0:      	add	x8, x8, x11
     2c4:      	stur	w12, [x22, #0x1e]
     2c8:      	add	x8, x8, w9, uxth
     2cc:      	ldrh	w9, [x22, #0x20]
     2d0:      	add	x8, x8, x10
     2d4:      	ldrh	w10, [x22, #0x24]
     2d8:      	add	x8, x8, w12, uxth
     2dc:      	add	x8, x8, x9
     2e0:      	lsr	x9, x8, #16
     2e4:      	cmp	x8, #0x10, lsl #12      // =0x10000
     2e8:      	add	x9, x9, w8, uxth
     2ec:      	csel	x8, x8, x9, lo
     2f0:      	lsr	x9, x8, #16
     2f4:      	cmp	x8, #0x10, lsl #12      // =0x10000
     2f8:      	add	x9, x9, w8, uxth
     2fc:      	csel	x8, x8, x9, lo
     300:      	lsr	x9, x8, #16
     304:      	cmp	x8, #0x10, lsl #12      // =0x10000
     308:      	add	w9, w9, w8, uxth
     30c:      	ldr	w12, [x22]
     310:      	csel	x8, x8, x9, lo
     314:      	ldur	w11, [x22, #0x6]
     318:      	add	w10, w10, #0x8
     31c:      	mov	w20, #0x3               // =3
     320:      	add	w8, w8, w8, lsr #16
     324:      	strh	w10, [x22, #0x24]
     328:      	mvn	w8, w8
     32c:      	stur	w12, [x22, #0x6]
     330:      	ldrh	w12, [x22, #0xa]
     334:      	strh	w8, [x22, #0x18]
     338:      	ldrh	w8, [x22, #0x4]
     33c:      	str	w11, [x22]
     340:      	strh	w8, [x22, #0xa]
     344:      	strh	w12, [x22, #0x4]
     348:      	b	0x1854 <balancer_ingress+0x1854>
     34c:      	mov	w9, wzr
     350:      	cmp	w8, #0x11
     354:      	b.eq	0x3f4 <balancer_ingress+0x3f4>
     358:      	cmp	w8, #0x6
     35c:      	b.ne	0x9ec <balancer_ingress+0x9ec>
     360:      	tst	w9, #0x1
     364:      	mov	w10, #0x66              // =102
     368:      	mov	w11, #0x36              // =54
     36c:      	csel	x10, x11, x10, eq
     370:      	add	x10, x22, x10
     374:      	add	x11, x10, #0x14
     378:      	cmp	x11, x23
     37c:      	b.hi	0x1850 <balancer_ingress+0x1850>
     380:      	ldrh	w12, [x10, #0xc]
     384:      	mov	w11, w9
     388:      	tbnz	w12, #0x9, 0x900 <balancer_ingress+0x900>
     38c:      	tbnz	w12, #0xa, 0x910 <balancer_ingress+0x910>
     390:      	tbnz	w9, #0x0, 0x418 <balancer_ingress+0x418>
     394:      	ldrh	w9, [x10]
     398:      	strh	w9, [sp, #0x60]
     39c:      	ldrh	w9, [x10, #0x2]
     3a0:      	b	0x424 <balancer_ingress+0x424>
     3a4:      	ldur	w9, [x22, #0x1a]
     3a8:      	ldur	w11, [x22, #0x1e]
     3ac:      	cmp	w8, #0x3a
     3b0:      	str	w9, [sp, #0x40]
     3b4:      	str	w11, [sp, #0x50]
     3b8:      	b.ne	0x5a8 <balancer_ingress+0x5a8>
     3bc:      	add	x8, x22, #0x2a
     3c0:      	cmp	x8, x29
     3c4:      	b.hi	0x1850 <balancer_ingress+0x1850>
     3c8:      	ldrb	w8, [x10]
     3cc:      	cmp	w8, #0x1
     3d0:      	b.eq	0xa3c <balancer_ingress+0xa3c>
     3d4:      	cmp	w8, #0x2
     3d8:      	b.eq	0x9f4 <balancer_ingress+0x9f4>
     3dc:      	cmp	w8, #0x80
     3e0:      	b.ne	0x9ec <balancer_ingress+0x9ec>
     3e4:      	add	x8, x22, #0x3e
     3e8:      	cmp	x8, x29
     3ec:      	b.ls	0x1dc <balancer_ingress+0x1dc>
     3f0:      	b	0x1850 <balancer_ingress+0x1850>
     3f4:      	tst	w9, #0x1
     3f8:      	mov	w10, #0x66              // =102
     3fc:      	mov	w11, #0x36              // =54
     400:      	csel	x10, x11, x10, eq
     404:      	add	x10, x22, x10
     408:      	add	x11, x10, #0x8
     40c:      	cmp	x11, x23
     410:      	b.hi	0x1850 <balancer_ingress+0x1850>
     414:      	tbz	w9, #0x0, 0x394 <balancer_ingress+0x394>
     418:      	ldrh	w9, [x10, #0x2]
     41c:      	strh	w9, [sp, #0x60]
     420:      	ldrh	w9, [x10]
     424:      	ldp	x10, x11, [sp, #0x50]
     428:      	adrp	x0, 0x0 <balancer_ingress>
     42c:      	add	x1, sp, #0x28
     430:      	strh	w9, [sp, #0x62]
     434:      	strh	w9, [sp, #0x38]
     438:      	strb	w8, [sp, #0x3a]
     43c:      	mov	w8, #0x1                // =1
     440:      	stp	x10, x11, [sp, #0x28]
     444:      	ldr	x0, [x0]
     448:      	blr	x8
     44c:      	mov	x21, x0
     450:      	cbz	x0, 0x71c <balancer_ingress+0x71c>
     454:      	sub	x8, x23, x22
     458:      	cmp	x8, #0x5ea
     45c:      	b.gt	0x1850 <balancer_ingress+0x1850>
     460:      	mov	w8, #0x200              // =512
     464:      	adrp	x0, 0x0 <balancer_ingress>
     468:      	mov	w20, #0x1               // =1
     46c:      	str	w8, [sp, #0x1c]
     470:      	add	x1, sp, #0x1c
     474:      	ldr	x0, [x0]
     478:      	blr	x20
     47c:      	cbz	x0, 0xef0 <balancer_ingress+0xef0>
     480:      	ldr	x8, [x0]
     484:      	str	x0, [sp, #0x8]
     488:      	add	x8, x8, #0x1
     48c:      	str	x8, [x0]
     490:      	ldrb	w8, [x21]
     494:      	tbz	w8, #0x0, 0x49c <balancer_ingress+0x49c>
     498:      	strh	wzr, [sp, #0x60]
     49c:      	ldr	w29, [x21, #0x4]
     4a0:      	mov	w8, #0x8                // =8
     4a4:      	str	w29, [sp, #0x24]
     4a8:      	blr	x8
     4ac:      	str	w0, [sp, #0x18]
     4b0:      	adrp	x0, 0x0 <balancer_ingress>
     4b4:      	mov	w8, #0x1                // =1
     4b8:      	add	x1, sp, #0x18
     4bc:      	ldr	x0, [x0]
     4c0:      	blr	x8
     4c4:      	mov	x20, x0
     4c8:      	cbnz	x0, 0x500 <balancer_ingress+0x500>
     4cc:      	mov	w8, #0x203              // =515
     4d0:      	adrp	x0, 0x0 <balancer_ingress>
     4d4:      	add	x1, sp, #0x70
     4d8:      	str	w8, [sp, #0x70]
     4dc:      	mov	w8, #0x1                // =1
     4e0:      	ldr	x0, [x0]
     4e4:      	blr	x8
     4e8:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     4ec:      	ldr	x8, [x0]
     4f0:      	adrp	x20, 0x0 <balancer_ingress>
     4f4:      	add	x8, x8, #0x1
     4f8:      	str	x8, [x0]
     4fc:      	ldr	x20, [x20]
     500:      	ldrb	w8, [x21]
     504:      	tbz	w8, #0x2, 0xc64 <balancer_ingress+0xc64>
     508:      	ldrb	w8, [sp, #0x6c]
     50c:      	tbnz	w8, #0x0, 0xa9c <balancer_ingress+0xa9c>
     510:      	str	wzr, [sp, #0xac]
     514:      	adrp	x0, 0x0 <balancer_ingress>
     518:      	mov	w8, #0x1                // =1
     51c:      	add	x1, sp, #0xac
     520:      	ldr	x0, [x0]
     524:      	blr	x8
     528:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     52c:      	ldrb	w8, [sp, #0x6c]
     530:      	mov	w9, #0x36               // =54
     534:      	tst	w8, #0x1
     538:      	mov	w8, #0x66               // =102
     53c:      	csel	x8, x9, x8, eq
     540:      	add	x8, x22, x8
     544:      	add	x9, x8, #0x9
     548:      	cmp	x9, x23
     54c:      	b.hi	0xc58 <balancer_ingress+0xc58>
     550:      	ldrsb	w10, [x8, #0x8]
     554:      	tbnz	w10, #0x1f, 0xb40 <balancer_ingress+0xb40>
     558:      	add	x8, x8, #0x11
     55c:      	cmp	x8, x23
     560:      	b.hi	0xc58 <balancer_ingress+0xc58>
     564:      	ldrb	w10, [x9]
     568:      	mov	x23, x0
     56c:      	lsr	x8, x10, #6
     570:      	cmp	w8, #0x3
     574:      	b.eq	0xbf4 <balancer_ingress+0xbf4>
     578:      	cmp	w8, #0x2
     57c:      	b.eq	0xc10 <balancer_ingress+0xc10>
     580:      	cmp	w8, #0x1
     584:      	mov	x0, x23
     588:      	b.ne	0xc58 <balancer_ingress+0xc58>
     58c:      	ldrb	w11, [x9, #0x1]
     590:      	ldrb	w9, [x9, #0x2]
     594:      	and	x10, x10, #0x3f
     598:      	lsl	x10, x10, #10
     59c:      	orr	x10, x10, x11, lsl #2
     5a0:      	lsr	w9, w9, #6
     5a4:      	b	0xc24 <balancer_ingress+0xc24>
     5a8:      	mov	w9, wzr
     5ac:      	cmp	w8, #0x11
     5b0:      	b.eq	0x750 <balancer_ingress+0x750>
     5b4:      	cmp	w8, #0x6
     5b8:      	b.ne	0x9ec <balancer_ingress+0x9ec>
     5bc:      	tst	w9, #0x1
     5c0:      	mov	w10, #0x3e              // =62
     5c4:      	mov	w11, #0x22              // =34
     5c8:      	csel	x10, x11, x10, eq
     5cc:      	add	x10, x22, x10
     5d0:      	add	x11, x10, #0x14
     5d4:      	cmp	x11, x29
     5d8:      	b.hi	0x1850 <balancer_ingress+0x1850>
     5dc:      	ldrh	w12, [x10, #0xc]
     5e0:      	mov	w11, w9
     5e4:      	tbnz	w12, #0x9, 0xa7c <balancer_ingress+0xa7c>
     5e8:      	tbnz	w12, #0xa, 0xa8c <balancer_ingress+0xa8c>
     5ec:      	tbnz	w9, #0x0, 0x774 <balancer_ingress+0x774>
     5f0:      	ldrh	w9, [x10]
     5f4:      	strh	w9, [sp, #0x60]
     5f8:      	ldrh	w9, [x10, #0x2]
     5fc:      	b	0x780 <balancer_ingress+0x780>
     600:      	mov	w8, #0x20c              // =524
     604:      	adrp	x0, 0x0 <balancer_ingress>
     608:      	add	x1, sp, #0x70
     60c:      	str	w8, [sp, #0x70]
     610:      	mov	w8, #0x1                // =1
     614:      	ldr	x0, [x0]
     618:      	blr	x8
     61c:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     620:      	ldr	x8, [x0]
     624:      	add	x8, x8, #0x1
     628:      	str	x8, [x0]
     62c:      	ldur	w8, [x22, #0x3a]
     630:      	rev	w8, w8
     634:      	cmp	w8, #0x4ff
     638:      	b.hi	0x648 <balancer_ingress+0x648>
     63c:      	ldr	x8, [x0, #0x8]
     640:      	add	x8, x8, #0x1
     644:      	str	x8, [x0, #0x8]
     648:      	add	x8, x22, #0x66
     64c:      	cmp	x8, x23
     650:      	b.hi	0x1850 <balancer_ingress+0x1850>
     654:      	ldrb	w9, [sp, #0x6c]
     658:      	ldrb	w8, [x22, #0x44]
     65c:      	orr	w9, w9, #0x1
     660:      	strb	w8, [sp, #0x64]
     664:      	strb	w9, [sp, #0x6c]
     668:      	ldur	x10, [x22, #0x56]
     66c:      	ldur	x11, [x22, #0x5e]
     670:      	stp	x10, x11, [sp, #0x40]
     674:      	ldur	x10, [x22, #0x46]
     678:      	ldur	x11, [x22, #0x4e]
     67c:      	stp	x10, x11, [sp, #0x50]
     680:      	b	0x350 <balancer_ingress+0x350>
     684:      	ldrb	w8, [x22, #0x37]
     688:      	cmp	w8, #0x4
     68c:      	b.ne	0x6d8 <balancer_ingress+0x6d8>
     690:      	mov	w8, #0x20d              // =525
     694:      	adrp	x0, 0x0 <balancer_ingress>
     698:      	add	x1, sp, #0x70
     69c:      	str	w8, [sp, #0x70]
     6a0:      	mov	w8, #0x1                // =1
     6a4:      	ldr	x0, [x0]
     6a8:      	blr	x8
     6ac:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     6b0:      	ldr	x8, [x0]
     6b4:      	add	x8, x8, #0x1
     6b8:      	str	x8, [x0]
     6bc:      	ldrh	w8, [x22, #0x3c]
     6c0:      	ubfiz	w8, w8, #8, #8
     6c4:      	cmp	w8, #0x4ff
     6c8:      	b.hi	0x6d8 <balancer_ingress+0x6d8>
     6cc:      	ldr	x8, [x0, #0x8]
     6d0:      	add	x8, x8, #0x1
     6d4:      	str	x8, [x0, #0x8]
     6d8:      	add	x8, x22, #0x52
     6dc:      	cmp	x8, x23
     6e0:      	b.hi	0x1850 <balancer_ingress+0x1850>
     6e4:      	ldrb	w8, [x20]
     6e8:      	and	w8, w8, #0xf
     6ec:      	cmp	w8, #0x5
     6f0:      	b.ne	0x1850 <balancer_ingress+0x1850>
     6f4:      	ldrb	w9, [sp, #0x6c]
     6f8:      	ldrb	w8, [x22, #0x47]
     6fc:      	orr	w9, w9, #0x1
     700:      	strb	w8, [sp, #0x64]
     704:      	strb	w9, [sp, #0x6c]
     708:      	ldur	w10, [x22, #0x4e]
     70c:      	str	w10, [sp, #0x40]
     710:      	ldur	w10, [x22, #0x4a]
     714:      	str	w10, [sp, #0x50]
     718:      	b	0x350 <balancer_ingress+0x350>
     71c:      	strh	wzr, [sp, #0x38]
     720:      	adrp	x0, 0x0 <balancer_ingress>
     724:      	mov	w8, #0x1                // =1
     728:      	add	x1, sp, #0x28
     72c:      	ldr	x0, [x0]
     730:      	blr	x8
     734:      	cbz	x0, 0x9ec <balancer_ingress+0x9ec>
     738:      	ldrb	w8, [x0]
     73c:      	mov	x21, x0
     740:      	tst	w8, #0x88888888
     744:      	b.ne	0x454 <balancer_ingress+0x454>
     748:      	strh	wzr, [sp, #0x62]
     74c:      	b	0x454 <balancer_ingress+0x454>
     750:      	tst	w9, #0x1
     754:      	mov	w10, #0x3e              // =62
     758:      	mov	w11, #0x22              // =34
     75c:      	csel	x10, x11, x10, eq
     760:      	add	x10, x22, x10
     764:      	add	x11, x10, #0x8
     768:      	cmp	x11, x29
     76c:      	b.hi	0x1850 <balancer_ingress+0x1850>
     770:      	tbz	w9, #0x0, 0x5f0 <balancer_ingress+0x5f0>
     774:      	ldrh	w9, [x10, #0x2]
     778:      	strh	w9, [sp, #0x60]
     77c:      	ldrh	w9, [x10]
     780:      	ldr	w10, [sp, #0x50]
     784:      	strh	w9, [sp, #0x62]
     788:      	adrp	x0, 0x0 <balancer_ingress>
     78c:      	add	x1, sp, #0x28
     790:      	strh	w9, [sp, #0x38]
     794:      	strb	w8, [sp, #0x3a]
     798:      	mov	w8, #0x1                // =1
     79c:      	str	w10, [sp, #0x28]
     7a0:      	ldr	x0, [x0]
     7a4:      	blr	x8
     7a8:      	mov	x21, x0
     7ac:      	cbz	x0, 0x9b8 <balancer_ingress+0x9b8>
     7b0:      	sub	x8, x29, x22
     7b4:      	cmp	x8, #0x5ea
     7b8:      	b.gt	0x1850 <balancer_ingress+0x1850>
     7bc:      	mov	w8, #0x200              // =512
     7c0:      	adrp	x0, 0x0 <balancer_ingress>
     7c4:      	mov	w20, #0x1               // =1
     7c8:      	str	w8, [sp, #0x1c]
     7cc:      	add	x1, sp, #0x1c
     7d0:      	ldr	x0, [x0]
     7d4:      	blr	x20
     7d8:      	cbz	x0, 0x1854 <balancer_ingress+0x1854>
     7dc:      	ldr	x8, [x0]
     7e0:      	str	x0, [sp, #0x8]
     7e4:      	add	x8, x8, #0x1
     7e8:      	str	x8, [x0]
     7ec:      	ldrb	w8, [x21]
     7f0:      	tbz	w8, #0x0, 0x7f8 <balancer_ingress+0x7f8>
     7f4:      	strh	wzr, [sp, #0x60]
     7f8:      	ldr	w23, [x21, #0x4]
     7fc:      	mov	w8, #0x8                // =8
     800:      	str	w23, [sp, #0x24]
     804:      	blr	x8
     808:      	str	w0, [sp, #0x18]
     80c:      	adrp	x0, 0x0 <balancer_ingress>
     810:      	mov	w8, #0x1                // =1
     814:      	add	x1, sp, #0x18
     818:      	ldr	x0, [x0]
     81c:      	blr	x8
     820:      	mov	x20, x0
     824:      	cbnz	x0, 0x85c <balancer_ingress+0x85c>
     828:      	mov	w8, #0x203              // =515
     82c:      	adrp	x0, 0x0 <balancer_ingress>
     830:      	add	x1, sp, #0x70
     834:      	str	w8, [sp, #0x70]
     838:      	mov	w8, #0x1                // =1
     83c:      	ldr	x0, [x0]
     840:      	blr	x8
     844:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     848:      	ldr	x8, [x0]
     84c:      	adrp	x20, 0x0 <balancer_ingress>
     850:      	add	x8, x8, #0x1
     854:      	str	x8, [x0]
     858:      	ldr	x20, [x20]
     85c:      	ldrb	w8, [x21]
     860:      	tbz	w8, #0x2, 0x1368 <balancer_ingress+0x1368>
     864:      	ldrb	w8, [sp, #0x6c]
     868:      	tbnz	w8, #0x0, 0xaf4 <balancer_ingress+0xaf4>
     86c:      	str	wzr, [sp, #0xac]
     870:      	adrp	x0, 0x0 <balancer_ingress>
     874:      	mov	w8, #0x1                // =1
     878:      	add	x1, sp, #0xac
     87c:      	ldr	x0, [x0]
     880:      	blr	x8
     884:      	str	x0, [sp]
     888:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     88c:      	ldrb	w8, [sp, #0x6c]
     890:      	mov	w9, #0x22               // =34
     894:      	tst	w8, #0x1
     898:      	mov	w8, #0x3e               // =62
     89c:      	csel	x8, x9, x8, eq
     8a0:      	add	x8, x22, x8
     8a4:      	add	x9, x8, #0x9
     8a8:      	cmp	x9, x29
     8ac:      	b.hi	0x1358 <balancer_ingress+0x1358>
     8b0:      	ldrsb	w10, [x8, #0x8]
     8b4:      	tbnz	w10, #0x1f, 0xb80 <balancer_ingress+0xb80>
     8b8:      	add	x8, x8, #0x11
     8bc:      	cmp	x8, x29
     8c0:      	b.hi	0x1358 <balancer_ingress+0x1358>
     8c4:      	ldrb	w10, [x9]
     8c8:      	lsr	x8, x10, #6
     8cc:      	cmp	w8, #0x3
     8d0:      	b.eq	0x12e4 <balancer_ingress+0x12e4>
     8d4:      	cmp	w8, #0x2
     8d8:      	b.eq	0x1310 <balancer_ingress+0x1310>
     8dc:      	cmp	w8, #0x1
     8e0:      	b.ne	0x1358 <balancer_ingress+0x1358>
     8e4:      	ldrb	w11, [x9, #0x1]
     8e8:      	ldrb	w9, [x9, #0x2]
     8ec:      	and	x10, x10, #0x3f
     8f0:      	lsl	x10, x10, #10
     8f4:      	orr	x10, x10, x11, lsl #2
     8f8:      	lsr	w9, w9, #6
     8fc:      	b	0x1324 <balancer_ingress+0x1324>
     900:      	orr	w11, w9, #0x2
     904:      	strb	w11, [sp, #0x6c]
     908:      	ldrh	w12, [x10, #0xc]
     90c:      	tbz	w12, #0xa, 0x390 <balancer_ingress+0x390>
     910:      	orr	w11, w11, #0x4
     914:      	strb	w11, [sp, #0x6c]
     918:      	tbz	w9, #0x0, 0x394 <balancer_ingress+0x394>
     91c:      	b	0x418 <balancer_ingress+0x418>
     920:      	ldrb	w8, [x22, #0x23]
     924:      	cmp	w8, #0x4
     928:      	b.ne	0x974 <balancer_ingress+0x974>
     92c:      	mov	w8, #0x20d              // =525
     930:      	adrp	x0, 0x0 <balancer_ingress>
     934:      	add	x1, sp, #0x70
     938:      	str	w8, [sp, #0x70]
     93c:      	mov	w8, #0x1                // =1
     940:      	ldr	x0, [x0]
     944:      	blr	x8
     948:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     94c:      	ldr	x8, [x0]
     950:      	add	x8, x8, #0x1
     954:      	str	x8, [x0]
     958:      	ldrh	w8, [x22, #0x28]
     95c:      	ubfiz	w8, w8, #8, #8
     960:      	cmp	w8, #0x4ff
     964:      	b.hi	0x974 <balancer_ingress+0x974>
     968:      	ldr	x8, [x0, #0x8]
     96c:      	add	x8, x8, #0x1
     970:      	str	x8, [x0, #0x8]
     974:      	add	x8, x22, #0x3e
     978:      	cmp	x8, x29
     97c:      	b.hi	0x1850 <balancer_ingress+0x1850>
     980:      	ldrb	w8, [x20]
     984:      	and	w8, w8, #0xf
     988:      	cmp	w8, #0x5
     98c:      	b.ne	0x1850 <balancer_ingress+0x1850>
     990:      	ldrb	w9, [sp, #0x6c]
     994:      	ldrb	w8, [x22, #0x33]
     998:      	orr	w9, w9, #0x1
     99c:      	strb	w8, [sp, #0x64]
     9a0:      	strb	w9, [sp, #0x6c]
     9a4:      	ldur	w10, [x22, #0x3a]
     9a8:      	str	w10, [sp, #0x40]
     9ac:      	ldur	w10, [x22, #0x36]
     9b0:      	str	w10, [sp, #0x50]
     9b4:      	b	0x5ac <balancer_ingress+0x5ac>
     9b8:      	strh	wzr, [sp, #0x38]
     9bc:      	adrp	x0, 0x0 <balancer_ingress>
     9c0:      	mov	w8, #0x1                // =1
     9c4:      	add	x1, sp, #0x28
     9c8:      	ldr	x0, [x0]
     9cc:      	blr	x8
     9d0:      	cbz	x0, 0x9ec <balancer_ingress+0x9ec>
     9d4:      	ldrb	w8, [x0]
     9d8:      	mov	x21, x0
     9dc:      	tst	w8, #0x88888888
     9e0:      	b.ne	0x7b0 <balancer_ingress+0x7b0>
     9e4:      	strh	wzr, [sp, #0x62]
     9e8:      	b	0x7b0 <balancer_ingress+0x7b0>
     9ec:      	mov	w20, #0x2               // =2
     9f0:      	b	0x1854 <balancer_ingress+0x1854>
     9f4:      	mov	w8, #0x20c              // =524
     9f8:      	adrp	x0, 0x0 <balancer_ingress>
     9fc:      	add	x1, sp, #0x70
     a00:      	str	w8, [sp, #0x70]
     a04:      	mov	w8, #0x1                // =1
     a08:      	ldr	x0, [x0]
     a0c:      	blr	x8
     a10:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     a14:      	ldr	x8, [x0]
     a18:      	add	x8, x8, #0x1
     a1c:      	str	x8, [x0]
     a20:      	ldur	w8, [x22, #0x26]
     a24:      	rev	w8, w8
     a28:      	cmp	w8, #0x4ff
     a2c:      	b.hi	0xa3c <balancer_ingress+0xa3c>
     a30:      	ldr	x8, [x0, #0x8]
     a34:      	add	x8, x8, #0x1
     a38:      	str	x8, [x0, #0x8]
     a3c:      	add	x8, x22, #0x52
     a40:      	cmp	x8, x29
     a44:      	b.hi	0x1850 <balancer_ingress+0x1850>
     a48:      	ldrb	w9, [sp, #0x6c]
     a4c:      	ldrb	w8, [x22, #0x30]
     a50:      	add	x10, sp, #0x40
     a54:      	orr	w9, w9, #0x1
     a58:      	strb	w8, [sp, #0x64]
     a5c:      	strb	w9, [sp, #0x6c]
     a60:      	ldur	x11, [x22, #0x42]
     a64:      	ldur	x12, [x22, #0x4a]
     a68:      	stp	x11, x12, [sp, #0x40]
     a6c:      	ldur	x11, [x22, #0x32]
     a70:      	ldur	x12, [x22, #0x3a]
     a74:      	stp	x11, x12, [x10, #0x10]
     a78:      	b	0x5ac <balancer_ingress+0x5ac>
     a7c:      	orr	w11, w9, #0x2
     a80:      	strb	w11, [sp, #0x6c]
     a84:      	ldrh	w12, [x10, #0xc]
     a88:      	tbz	w12, #0xa, 0x5ec <balancer_ingress+0x5ec>
     a8c:      	orr	w11, w11, #0x4
     a90:      	strb	w11, [sp, #0x6c]
     a94:      	tbz	w9, #0x0, 0x5f0 <balancer_ingress+0x5f0>
     a98:      	b	0x774 <balancer_ingress+0x774>
     a9c:      	mov	w8, #0x20b              // =523
     aa0:      	adrp	x0, 0x0 <balancer_ingress>
     aa4:      	add	x1, sp, #0x70
     aa8:      	str	w8, [sp, #0x70]
     aac:      	mov	w8, #0x1                // =1
     ab0:      	ldr	x0, [x0]
     ab4:      	blr	x8
     ab8:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     abc:      	ldr	x8, [x0]
     ac0:      	add	x8, x8, #0x1
     ac4:      	str	x8, [x0]
     ac8:      	ldrb	w8, [x22, #0x37]
     acc:      	sub	w8, w8, #0x3
     ad0:      	cmp	w8, #0x1
     ad4:      	b.hi	0xc64 <balancer_ingress+0xc64>
     ad8:      	ldr	x8, [x0, #0x8]
     adc:      	add	x8, x8, #0x1
     ae0:      	str	x8, [x0, #0x8]
     ae4:      	ldrh	w29, [sp, #0x60]
     ae8:      	ldrb	w8, [sp, #0x6c]
     aec:      	tbz	w8, #0x1, 0xc70 <balancer_ingress+0xc70>
     af0:      	b	0xcc0 <balancer_ingress+0xcc0>
     af4:      	mov	w8, #0x20b              // =523
     af8:      	adrp	x0, 0x0 <balancer_ingress>
     afc:      	add	x1, sp, #0x70
     b00:      	str	w8, [sp, #0x70]
     b04:      	mov	w8, #0x1                // =1
     b08:      	ldr	x0, [x0]
     b0c:      	blr	x8
     b10:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     b14:      	ldr	x8, [x0]
     b18:      	add	x8, x8, #0x1
     b1c:      	str	x8, [x0]
     b20:      	ldrb	w8, [x22, #0x23]
     b24:      	orr	w8, w8, #0x2
     b28:      	cmp	w8, #0x3
     b2c:      	b.ne	0x1368 <balancer_ingress+0x1368>
     b30:      	ldr	x8, [x0, #0x8]
     b34:      	add	x8, x8, #0x1
     b38:      	str	x8, [x0, #0x8]
     b3c:      	b	0x1368 <balancer_ingress+0x1368>
     b40:      	add	x9, x8, #0x16
     b44:      	cmp	x9, x23
     b48:      	b.hi	0xc58 <balancer_ingress+0xc58>
     b4c:      	and	w9, w10, #0xff
     b50:      	tbnz	w9, #0x5, 0xbd0 <balancer_ingress+0xbd0>
     b54:      	ldr	x8, [x0, #0x8]
     b58:      	str	w29, [sp, #0x70]
     b5c:      	add	x1, sp, #0x70
     b60:      	add	x8, x8, #0x1
     b64:      	str	x8, [x0, #0x8]
     b68:      	adrp	x0, 0x0 <balancer_ingress>
     b6c:      	mov	w8, #0x1                // =1
     b70:      	ldr	x0, [x0]
     b74:      	blr	x8
     b78:      	cbnz	x0, 0xc58 <balancer_ingress+0xc58>
     b7c:      	b	0xc64 <balancer_ingress+0xc64>
     b80:      	add	x9, x8, #0x16
     b84:      	cmp	x9, x29
     b88:      	b.hi	0x1358 <balancer_ingress+0x1358>
     b8c:      	and	w9, w10, #0xff
     b90:      	tbnz	w9, #0x5, 0x12c4 <balancer_ingress+0x12c4>
     b94:      	ldr	x9, [sp]
     b98:      	str	w23, [sp, #0x70]
     b9c:      	adrp	x0, 0x0 <balancer_ingress>
     ba0:      	add	x1, sp, #0x70
     ba4:      	ldr	x8, [x9, #0x8]
     ba8:      	add	x8, x8, #0x1
     bac:      	str	x8, [x9, #0x8]
     bb0:      	mov	w8, #0x1                // =1
     bb4:      	ldr	x0, [x0]
     bb8:      	blr	x8
     bbc:      	cbz	x0, 0x1368 <balancer_ingress+0x1368>
     bc0:      	ldr	x8, [x0]
     bc4:      	add	x8, x8, #0x1
     bc8:      	str	x8, [x0]
     bcc:      	b	0x1368 <balancer_ingress+0x1368>
     bd0:      	ldrb	w9, [x8, #0xd]
     bd4:      	cmp	w9, #0x7
     bd8:      	b.ls	0xc58 <balancer_ingress+0xc58>
     bdc:      	add	x9, x8, #0xe
     be0:      	ldrb	w10, [x9]
     be4:      	mov	x23, x0
     be8:      	lsr	x8, x10, #6
     bec:      	cmp	w8, #0x3
     bf0:      	b.ne	0x578 <balancer_ingress+0x578>
     bf4:      	ldrb	w10, [x9, #0x1]
     bf8:      	ldrb	w11, [x9, #0x2]
     bfc:      	lsl	x10, x10, #24
     c00:      	orr	x10, x10, x11, lsl #16
     c04:      	ldrb	w11, [x9, #0x3]
     c08:      	ldrb	w9, [x9, #0x4]
     c0c:      	b	0xc20 <balancer_ingress+0xc20>
     c10:      	ldrb	w10, [x9, #0x1]
     c14:      	ldrb	w11, [x9, #0x2]
     c18:      	lsl	x10, x10, #16
     c1c:      	ldrb	w9, [x9, #0x3]
     c20:      	orr	x10, x10, x11, lsl #8
     c24:      	mov	w9, w9
     c28:      	mov	x0, x23
     c2c:      	orr	x22, x10, x9
     c30:      	cmp	w22, #0x1
     c34:      	b.lt	0xc58 <balancer_ingress+0xc58>
     c38:      	cmp	w8, #0x3
     c3c:      	b.eq	0x1204 <balancer_ingress+0x1204>
     c40:      	cmp	w8, #0x2
     c44:      	b.eq	0x11fc <balancer_ingress+0x11fc>
     c48:      	cmp	w8, #0x1
     c4c:      	b.ne	0x120c <balancer_ingress+0x120c>
     c50:      	add	x8, x23, #0x38
     c54:      	b	0x1210 <balancer_ingress+0x1210>
     c58:      	ldr	x8, [x0]
     c5c:      	add	x8, x8, #0x1
     c60:      	str	x8, [x0]
     c64:      	ldrh	w29, [sp, #0x60]
     c68:      	ldrb	w8, [sp, #0x6c]
     c6c:      	tbnz	w8, #0x1, 0xcc0 <balancer_ingress+0xcc0>
     c70:      	ldrb	w8, [x21]
     c74:      	tbnz	w8, #0x1, 0xcc0 <balancer_ingress+0xcc0>
     c78:      	mov	w8, #0x1                // =1
     c7c:      	add	x1, sp, #0x40
     c80:      	mov	x0, x20
     c84:      	blr	x8
     c88:      	mov	x22, x0
     c8c:      	cbz	x0, 0xcc4 <balancer_ingress+0xcc4>
     c90:      	ldrb	w8, [sp, #0x64]
     c94:      	cmp	w8, #0x11
     c98:      	b.ne	0xda4 <balancer_ingress+0xda4>
     c9c:      	mov	w8, #0x5                // =5
     ca0:      	blr	x8
     ca4:      	ldr	x8, [x22, #0x8]
     ca8:      	mov	x9, #0xac00             // =44032
     cac:      	movk	x9, #0xfc23, lsl #16
     cb0:      	movk	x9, #0x6, lsl #32
     cb4:      	sub	x8, x0, x8
     cb8:      	cmp	x8, x9
     cbc:      	b.ls	0xda0 <balancer_ingress+0xda0>
     cc0:      	mov	x22, xzr
     cc4:      	ldrb	w8, [sp, #0x64]
     cc8:      	cmp	w8, #0x11
     ccc:      	b.ne	0xdd4 <balancer_ingress+0xdd4>
     cd0:      	ldrb	w8, [x21, #0x1]
     cd4:      	tbz	w8, #0x1, 0xdd4 <balancer_ingress+0xdd4>
     cd8:      	mov	w8, #0x202              // =514
     cdc:      	adrp	x0, 0x0 <balancer_ingress>
     ce0:      	add	x1, sp, #0x70
     ce4:      	str	w8, [sp, #0x70]
     ce8:      	mov	w8, #0x1                // =1
     cec:      	ldr	x0, [x0]
     cf0:      	blr	x8
     cf4:      	cbz	x0, 0xdd4 <balancer_ingress+0xdd4>
     cf8:      	mov	w8, #0x5                // =5
     cfc:      	mov	x23, x0
     d00:      	blr	x8
     d04:      	ldr	x8, [x23, #0x8]
     d08:      	mov	w9, #0xca00             // =51712
     d0c:      	movk	w9, #0x3b9a, lsl #16
     d10:      	sub	x8, x0, x8
     d14:      	cmp	x8, x9
     d18:      	b.ls	0xd28 <balancer_ingress+0xd28>
     d1c:      	mov	w8, #0x1                // =1
     d20:      	stp	x8, x0, [x23]
     d24:      	b	0xd44 <balancer_ingress+0xd44>
     d28:      	ldr	x8, [x23]
     d2c:      	mov	w9, #0xe848             // =59464
     d30:      	movk	w9, #0x1, lsl #16
     d34:      	add	x8, x8, #0x1
     d38:      	cmp	x8, x9
     d3c:      	str	x8, [x23]
     d40:      	b.hi	0xdd4 <balancer_ingress+0xdd4>
     d44:      	adrp	x0, 0x0 <balancer_ingress>
     d48:      	mov	w8, #0x1                // =1
     d4c:      	add	x1, sp, #0x28
     d50:      	ldr	x0, [x0]
     d54:      	blr	x8
     d58:      	cbz	x0, 0xdd4 <balancer_ingress+0xdd4>
     d5c:      	add	x8, sp, #0x40
     d60:      	mov	w9, #0x1                // =1
     d64:      	add	x1, x8, #0x28
     d68:      	blr	x9
     d6c:      	cbz	x0, 0xdd4 <balancer_ingress+0xdd4>
     d70:      	mov	w8, #0x20f              // =527
     d74:      	adrp	x0, 0x0 <balancer_ingress>
     d78:      	add	x1, sp, #0x70
     d7c:      	str	w8, [sp, #0x70]
     d80:      	mov	w8, #0x1                // =1
     d84:      	ldr	x0, [x0]
     d88:      	blr	x8
     d8c:      	cbz	x0, 0xef4 <balancer_ingress+0xef4>
     d90:      	ldr	x8, [x0]
     d94:      	add	x8, x8, #0x1
     d98:      	str	x8, [x0]
     d9c:      	b	0xef4 <balancer_ingress+0xef4>
     da0:      	str	x0, [x22, #0x8]
     da4:      	ldr	w8, [x22]
     da8:      	adrp	x0, 0x0 <balancer_ingress>
     dac:      	add	x1, sp, #0x70
     db0:      	str	w8, [sp, #0x70]
     db4:      	str	w8, [sp, #0x68]
     db8:      	mov	w8, #0x1                // =1
     dbc:      	ldr	x0, [x0]
     dc0:      	blr	x8
     dc4:      	mov	x22, x0
     dc8:      	ldrb	w8, [sp, #0x64]
     dcc:      	cmp	w8, #0x11
     dd0:      	b.eq	0xcd0 <balancer_ingress+0xcd0>
     dd4:      	cbz	x22, 0xef4 <balancer_ingress+0xef4>
     dd8:      	adrp	x0, 0x0 <balancer_ingress>
     ddc:      	mov	w20, #0x1               // =1
     de0:      	add	x1, sp, #0x20
     de4:      	ldr	x0, [x0]
     de8:      	blr	x20
     dec:      	cbz	x0, 0xef0 <balancer_ingress+0xef0>
     df0:      	mov	x21, x0
     df4:      	adrp	x0, 0x0 <balancer_ingress>
     df8:      	mov	w20, #0x1               // =1
     dfc:      	ldr	x0, [x0]
     e00:      	add	x1, sp, #0x24
     e04:      	blr	x20
     e08:      	cbz	x0, 0xef0 <balancer_ingress+0xef0>
     e0c:      	rev	w8, w25
     e10:      	mov	w23, #0x1               // =1
     e14:      	lsr	w20, w8, #16
     e18:      	ldp	x8, x9, [x0]
     e1c:      	add	x8, x8, #0x1
     e20:      	add	x9, x9, x20
     e24:      	stp	x8, x9, [x0]
     e28:      	adrp	x0, 0x0 <balancer_ingress>
     e2c:      	add	x8, sp, #0x40
     e30:      	ldr	x0, [x0]
     e34:      	add	x1, x8, #0x28
     e38:      	blr	x23
     e3c:      	cbz	x0, 0x1590 <balancer_ingress+0x1590>
     e40:      	ldp	x8, x9, [x0]
     e44:      	add	x8, x8, #0x1
     e48:      	add	x9, x9, x20
     e4c:      	stp	x8, x9, [x0]
     e50:      	strh	w29, [sp, #0x60]
     e54:      	ldrb	w8, [x22, #0x10]
     e58:      	tbnz	w8, #0x0, 0x10f8 <balancer_ingress+0x10f8>
     e5c:      	ldrh	w23, [sp, #0x42]
     e60:      	mov	w8, #0x2c               // =44
     e64:      	mov	x0, x19
     e68:      	mov	w1, #-0x14              // =-20
     e6c:      	mov	w25, w29
     e70:      	blr	x8
     e74:      	cbnz	w0, 0x157c <balancer_ingress+0x157c>
     e78:      	ldp	x8, x9, [x19]
     e7c:      	add	x10, x8, #0xe
     e80:      	cmp	x10, x9
     e84:      	b.hi	0x157c <balancer_ingress+0x157c>
     e88:      	add	x10, x8, #0x22
     e8c:      	cmp	x10, x9
     e90:      	b.hi	0x157c <balancer_ingress+0x157c>
     e94:      	ldr	w11, [x21]
     e98:      	ldrh	w12, [x21, #0x4]
     e9c:      	rev	w9, w25
     ea0:      	mov	w10, #0x10ac            // =4268
     ea4:      	mov	w13, #0x45              // =69
     ea8:      	eor	w9, w9, w23, lsl #16
     eac:      	orr	w10, w9, w10
     eb0:      	str	w11, [x8]
     eb4:      	ldrh	w11, [x8, #0x18]
     eb8:      	strh	w12, [x8, #0x4]
     ebc:      	strh	w11, [x8, #0xa]
     ec0:      	ldr	w11, [x8, #0x14]
     ec4:      	stur	w11, [x8, #0x6]
     ec8:      	mov	w11, #0x8               // =8
     ecc:      	strh	w11, [x8, #0xc]
     ed0:      	ldrb	w11, [sp, #0x6d]
     ed4:      	ldr	w12, [x22]
     ed8:      	strb	w13, [x8, #0xe]
     edc:      	mov	w13, #0x4               // =4
     ee0:      	strb	w13, [x8, #0x17]
     ee4:      	strb	w11, [x8, #0xf]
     ee8:      	add	w11, w20, #0x14
     eec:      	b	0x1950 <balancer_ingress+0x1950>
     ef0:      	b	0x1854 <balancer_ingress+0x1854>
     ef4:      	ldrb	w8, [sp, #0x64]
     ef8:      	cmp	w8, #0x6
     efc:      	b.ne	0xf38 <balancer_ingress+0xf38>
     f00:      	mov	w8, #0x201              // =513
     f04:      	adrp	x0, 0x0 <balancer_ingress>
     f08:      	add	x1, sp, #0x70
     f0c:      	str	w8, [sp, #0x70]
     f10:      	mov	w8, #0x1                // =1
     f14:      	ldr	x0, [x0]
     f18:      	blr	x8
     f1c:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
     f20:      	ldrb	w8, [sp, #0x6c]
     f24:      	tst	w8, #0x2
     f28:      	cset	w8, eq
     f2c:      	ldr	x9, [x0, w8, uxtw #3]
     f30:      	add	x9, x9, #0x1
     f34:      	str	x9, [x0, w8, uxtw #3]
     f38:      	mov	w8, #0x202              // =514
     f3c:      	str	w29, [sp]
     f40:      	stp	xzr, xzr, [sp, #0x70]
     f44:      	adrp	x0, 0x0 <balancer_ingress>
     f48:      	mov	w29, #0x1               // =1
     f4c:      	str	w8, [sp, #0xac]
     f50:      	add	x1, sp, #0xac
     f54:      	ldr	x0, [x0]
     f58:      	blr	x29
     f5c:      	cbz	x0, 0xf94 <balancer_ingress+0xf94>
     f60:      	mov	w8, #0x5                // =5
     f64:      	mov	x22, x0
     f68:      	blr	x8
     f6c:      	ldr	x8, [x22, #0x8]
     f70:      	mov	w9, #0xca00             // =51712
     f74:      	mov	x23, x0
     f78:      	movk	w9, #0x3b9a, lsl #16
     f7c:      	sub	x8, x0, x8
     f80:      	cmp	x8, x9
     f84:      	b.ls	0xf9c <balancer_ingress+0xf9c>
     f88:      	mov	w8, #0x1                // =1
     f8c:      	stp	x8, x23, [x22]
     f90:      	b	0xfc0 <balancer_ingress+0xfc0>
     f94:      	mov	x23, xzr
     f98:      	b	0xfc4 <balancer_ingress+0xfc4>
     f9c:      	ldr	x8, [x22]
     fa0:      	mov	w9, #0xe848             // =59464
     fa4:      	movk	w9, #0x1, lsl #16
     fa8:      	add	x8, x8, #0x1
     fac:      	cmp	x8, x9
     fb0:      	str	x8, [x22]
     fb4:      	b.ls	0xfc0 <balancer_ingress+0xfc0>
     fb8:      	mov	w29, #0x1               // =1
     fbc:      	b	0xfc4 <balancer_ingress+0xfc4>
     fc0:      	mov	w29, wzr
     fc4:      	ldrb	w8, [x21]
     fc8:      	tbz	w8, #0x3, 0xfd8 <balancer_ingress+0xfd8>
     fcc:      	ldrh	w8, [sp, #0x62]
     fd0:      	stp	xzr, xzr, [sp, #0x40]
     fd4:      	strh	w8, [sp, #0x60]
     fd8:      	add	x0, sp, #0x40
     fdc:      	bl	0xfdc <balancer_ingress+0xfdc>
     fe0:      	ldr	w1, [sp, #0x60]
     fe4:      	bl	0xfe4 <balancer_ingress+0xfe4>
     fe8:      	mov	w8, #-0xffff            // =-65535
     fec:      	ldr	w9, [x21, #0x4]
     ff0:      	add	x1, sp, #0xa8
     ff4:      	umull	x8, w0, w8
     ff8:      	lsr	x8, x8, #48
     ffc:      	orr	w8, w8, w8, lsl #16
    1000:      	add	w9, w9, w9, lsl #16
    1004:      	sub	w8, w0, w8
    1008:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    100c:      	add	w8, w9, w8
    1010:      	str	w8, [sp, #0xa8]
    1014:      	mov	w8, #0x1                // =1
    1018:      	ldr	x0, [x0]
    101c:      	blr	x8
    1020:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    1024:      	ldr	w8, [x0]
    1028:      	str	w8, [sp, #0xa8]
    102c:      	cbz	w8, 0x17cc <balancer_ingress+0x17cc>
    1030:      	str	w8, [sp, #0x68]
    1034:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1038:      	mov	w8, #0x1                // =1
    103c:      	add	x1, sp, #0xa8
    1040:      	ldr	x0, [x0]
    1044:      	blr	x8
    1048:      	cbz	x0, 0x17e0 <balancer_ingress+0x17e0>
    104c:      	ldrb	w8, [x21]
    1050:      	mov	x22, x0
    1054:      	and	w8, w8, #0x2
    1058:      	orr	w8, w29, w8, lsr #1
    105c:      	tbnz	w8, #0x0, 0x1098 <balancer_ingress+0x1098>
    1060:      	ldrb	w8, [sp, #0x6c]
    1064:      	tbnz	w8, #0x2, 0x1098 <balancer_ingress+0x1098>
    1068:      	ldrb	w8, [sp, #0x64]
    106c:      	cmp	w8, #0x11
    1070:      	b.ne	0x1078 <balancer_ingress+0x1078>
    1074:      	str	x23, [sp, #0x78]
    1078:      	ldr	w8, [sp, #0xa8]
    107c:      	add	x1, sp, #0x40
    1080:      	add	x2, sp, #0x70
    1084:      	mov	x0, x20
    1088:      	str	w8, [sp, #0x70]
    108c:      	mov	w8, #0x2                // =2
    1090:      	mov	x3, xzr
    1094:      	blr	x8
    1098:      	str	wzr, [sp, #0x70]
    109c:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    10a0:      	mov	w8, #0x1                // =1
    10a4:      	add	x1, sp, #0x70
    10a8:      	ldr	x0, [x0]
    10ac:      	blr	x8
    10b0:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    10b4:      	ldr	w8, [x0]
    10b8:      	ldr	w9, [sp, #0x28]
    10bc:      	cmp	w8, w9
    10c0:      	b.ne	0x1194 <balancer_ingress+0x1194>
    10c4:      	ldr	w8, [x0, #0x4]
    10c8:      	ldr	w9, [sp, #0x2c]
    10cc:      	cmp	w8, w9
    10d0:      	b.ne	0x1194 <balancer_ingress+0x1194>
    10d4:      	ldr	w8, [x0, #0x8]
    10d8:      	ldr	w9, [sp, #0x30]
    10dc:      	cmp	w8, w9
    10e0:      	b.ne	0x1194 <balancer_ingress+0x1194>
    10e4:      	ldr	w8, [x0, #0xc]
    10e8:      	ldr	w9, [sp, #0x34]
    10ec:      	cmp	w8, w9
    10f0:      	cset	w8, eq
    10f4:      	b	0x1198 <balancer_ingress+0x1198>
    10f8:      	mov	w8, #0x2c               // =44
    10fc:      	mov	x0, x19
    1100:      	mov	w1, #-0x28              // =-40
    1104:      	blr	x8
    1108:      	cbnz	w0, 0x1824 <balancer_ingress+0x1824>
    110c:      	ldp	x8, x9, [x19]
    1110:      	add	x10, x8, #0xe
    1114:      	cmp	x10, x9
    1118:      	b.hi	0x1824 <balancer_ingress+0x1824>
    111c:      	add	x10, x8, #0x36
    1120:      	cmp	x10, x9
    1124:      	b.hi	0x1824 <balancer_ingress+0x1824>
    1128:      	ldr	w9, [x21]
    112c:      	ldrh	w10, [x21, #0x4]
    1130:      	str	w9, [x8]
    1134:      	ldrh	w9, [x8, #0x2c]
    1138:      	strh	w10, [x8, #0x4]
    113c:      	strh	w9, [x8, #0xa]
    1140:      	ldr	w9, [x8, #0x28]
    1144:      	stur	w9, [x8, #0x6]
    1148:      	mov	w9, #0xdd86             // =56710
    114c:      	strh	w9, [x8, #0xc]
    1150:      	ldrb	w11, [sp, #0x6d]
    1154:      	ldrh	w9, [sp, #0x60]
    1158:      	ldr	w10, [sp, #0x4c]
    115c:      	strh	wzr, [x8, #0x10]
    1160:      	lsr	w12, w11, #4
    1164:      	lsl	w11, w11, #4
    1168:      	eor	w9, w10, w9
    116c:      	strb	w11, [x8, #0xf]
    1170:      	add	w11, w20, #0x28
    1174:      	orr	w12, w12, #0x60
    1178:      	rev	w11, w11
    117c:      	strb	w12, [x8, #0xe]
    1180:      	mov	w12, #0x4029            // =16425
    1184:      	lsr	w11, w11, #16
    1188:      	strh	w12, [x8, #0x14]
    118c:      	strh	w11, [x8, #0x12]
    1190:      	b	0x1a58 <balancer_ingress+0x1a58>
    1194:      	mov	w8, wzr
    1198:      	ldrh	w10, [x0, #0x10]
    119c:      	ldrh	w11, [sp, #0x38]
    11a0:      	ldrb	w9, [sp, #0x3a]
    11a4:      	strb	w9, [x0, #0x12]
    11a8:      	cbz	w8, 0x11e4 <balancer_ingress+0x11e4>
    11ac:      	cmp	w10, w11
    11b0:      	b.ne	0x11e4 <balancer_ingress+0x11e4>
    11b4:      	cbz	w9, 0x11e4 <balancer_ingress+0x11e4>
    11b8:      	ldr	w8, [sp, #0x68]
    11bc:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    11c0:      	add	x1, sp, #0xac
    11c4:      	str	w8, [sp, #0xac]
    11c8:      	mov	w8, #0x1                // =1
    11cc:      	ldr	x0, [x0]
    11d0:      	blr	x8
    11d4:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    11d8:      	ldr	w8, [x0]
    11dc:      	add	w8, w8, #0x1
    11e0:      	str	w8, [x0]
    11e4:      	ldr	x8, [sp, #0x8]
    11e8:      	ldr	w29, [sp]
    11ec:      	ldr	x9, [x8, #0x8]
    11f0:      	add	x9, x9, #0x1
    11f4:      	str	x9, [x8, #0x8]
    11f8:      	b	0xdd8 <balancer_ingress+0xdd8>
    11fc:      	add	x8, x23, #0x40
    1200:      	b	0x1210 <balancer_ingress+0x1210>
    1204:      	add	x8, x23, #0x48
    1208:      	b	0x1210 <balancer_ingress+0x1210>
    120c:      	add	x8, x23, #0x30
    1210:      	ldr	x9, [x8]
    1214:      	str	w22, [sp, #0xa8]
    1218:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    121c:      	add	x1, sp, #0xa8
    1220:      	add	x9, x9, #0x1
    1224:      	str	x9, [x8]
    1228:      	mov	w8, #0x1                // =1
    122c:      	ldr	x0, [x0]
    1230:      	blr	x8
    1234:      	cbz	x0, 0x129c <balancer_ingress+0x129c>
    1238:      	ldr	w8, [x0]
    123c:      	str	w8, [sp, #0xa8]
    1240:      	cbz	w8, 0x129c <balancer_ingress+0x129c>
    1244:      	str	w8, [sp, #0x68]
    1248:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    124c:      	mov	w8, #0x1                // =1
    1250:      	add	x1, sp, #0xa8
    1254:      	ldr	x0, [x0]
    1258:      	blr	x8
    125c:      	cbz	x0, 0x1300 <balancer_ingress+0x1300>
    1260:      	mov	x22, x0
    1264:      	mov	w8, #0x1                // =1
    1268:      	add	x1, sp, #0x40
    126c:      	mov	x0, x20
    1270:      	blr	x8
    1274:      	cbz	x0, 0x1a7c <balancer_ingress+0x1a7c>
    1278:      	ldr	w9, [x0]
    127c:      	ldr	w8, [sp, #0x68]
    1280:      	cmp	w9, w8
    1284:      	b.ne	0x1acc <balancer_ingress+0x1acc>
    1288:      	ldr	x9, [x23, #0x50]
    128c:      	mov	x8, x23
    1290:      	add	x9, x9, #0x1
    1294:      	str	x9, [x23, #0x50]
    1298:      	b	0x1c2c <balancer_ingress+0x1c2c>
    129c:      	ldr	x8, [x23, #0x10]
    12a0:      	add	x8, x8, #0x1
    12a4:      	stp	x8, x22, [x23, #0x10]
    12a8:      	ldr	x8, [x23]
    12ac:      	add	x8, x8, #0x1
    12b0:      	str	x8, [x23]
    12b4:      	ldrh	w29, [sp, #0x60]
    12b8:      	ldrb	w8, [sp, #0x6c]
    12bc:      	tbz	w8, #0x1, 0xc70 <balancer_ingress+0xc70>
    12c0:      	b	0xcc0 <balancer_ingress+0xcc0>
    12c4:      	ldrb	w9, [x8, #0xd]
    12c8:      	cmp	w9, #0x7
    12cc:      	b.ls	0x1358 <balancer_ingress+0x1358>
    12d0:      	add	x9, x8, #0xe
    12d4:      	ldrb	w10, [x9]
    12d8:      	lsr	x8, x10, #6
    12dc:      	cmp	w8, #0x3
    12e0:      	b.ne	0x8d4 <balancer_ingress+0x8d4>
    12e4:      	ldrb	w10, [x9, #0x1]
    12e8:      	ldrb	w11, [x9, #0x2]
    12ec:      	lsl	x10, x10, #24
    12f0:      	orr	x10, x10, x11, lsl #16
    12f4:      	ldrb	w11, [x9, #0x3]
    12f8:      	ldrb	w9, [x9, #0x4]
    12fc:      	b	0x1320 <balancer_ingress+0x1320>
    1300:      	ldr	x8, [x23, #0x28]
    1304:      	add	x8, x8, #0x1
    1308:      	str	x8, [x23, #0x28]
    130c:      	b	0x1850 <balancer_ingress+0x1850>
    1310:      	ldrb	w10, [x9, #0x1]
    1314:      	ldrb	w11, [x9, #0x2]
    1318:      	lsl	x10, x10, #16
    131c:      	ldrb	w9, [x9, #0x3]
    1320:      	orr	x10, x10, x11, lsl #8
    1324:      	mov	w9, w9
    1328:      	orr	x22, x10, x9
    132c:      	cmp	w22, #0x1
    1330:      	b.lt	0x1358 <balancer_ingress+0x1358>
    1334:      	cmp	w8, #0x3
    1338:      	b.eq	0x1b14 <balancer_ingress+0x1b14>
    133c:      	cmp	w8, #0x2
    1340:      	b.eq	0x1b08 <balancer_ingress+0x1b08>
    1344:      	cmp	w8, #0x1
    1348:      	b.ne	0x1b20 <balancer_ingress+0x1b20>
    134c:      	ldr	x8, [sp]
    1350:      	add	x8, x8, #0x38
    1354:      	b	0x1b28 <balancer_ingress+0x1b28>
    1358:      	ldr	x9, [sp]
    135c:      	ldr	x8, [x9]
    1360:      	add	x8, x8, #0x1
    1364:      	str	x8, [x9]
    1368:      	ldrh	w8, [sp, #0x60]
    136c:      	str	w8, [sp]
    1370:      	ldrb	w8, [sp, #0x6c]
    1374:      	tbnz	w8, #0x1, 0x13c8 <balancer_ingress+0x13c8>
    1378:      	ldrb	w8, [x21]
    137c:      	tbnz	w8, #0x1, 0x13c8 <balancer_ingress+0x13c8>
    1380:      	mov	w8, #0x1                // =1
    1384:      	add	x1, sp, #0x40
    1388:      	mov	x0, x20
    138c:      	blr	x8
    1390:      	mov	x22, x0
    1394:      	cbz	x0, 0x13cc <balancer_ingress+0x13cc>
    1398:      	ldrb	w8, [sp, #0x64]
    139c:      	cmp	w8, #0x11
    13a0:      	b.ne	0x14ac <balancer_ingress+0x14ac>
    13a4:      	mov	w8, #0x5                // =5
    13a8:      	blr	x8
    13ac:      	ldr	x8, [x22, #0x8]
    13b0:      	mov	x9, #0xac00             // =44032
    13b4:      	movk	x9, #0xfc23, lsl #16
    13b8:      	movk	x9, #0x6, lsl #32
    13bc:      	sub	x8, x0, x8
    13c0:      	cmp	x8, x9
    13c4:      	b.ls	0x14a8 <balancer_ingress+0x14a8>
    13c8:      	mov	x22, xzr
    13cc:      	ldrb	w8, [sp, #0x64]
    13d0:      	cmp	w8, #0x11
    13d4:      	b.ne	0x14dc <balancer_ingress+0x14dc>
    13d8:      	ldrb	w8, [x21, #0x1]
    13dc:      	tbz	w8, #0x1, 0x14dc <balancer_ingress+0x14dc>
    13e0:      	mov	w8, #0x202              // =514
    13e4:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    13e8:      	add	x1, sp, #0x70
    13ec:      	str	w8, [sp, #0x70]
    13f0:      	mov	w8, #0x1                // =1
    13f4:      	ldr	x0, [x0]
    13f8:      	blr	x8
    13fc:      	cbz	x0, 0x14dc <balancer_ingress+0x14dc>
    1400:      	mov	w8, #0x5                // =5
    1404:      	mov	x23, x0
    1408:      	blr	x8
    140c:      	ldr	x8, [x23, #0x8]
    1410:      	mov	w9, #0xca00             // =51712
    1414:      	movk	w9, #0x3b9a, lsl #16
    1418:      	sub	x8, x0, x8
    141c:      	cmp	x8, x9
    1420:      	b.ls	0x1430 <balancer_ingress+0x1430>
    1424:      	mov	w8, #0x1                // =1
    1428:      	stp	x8, x0, [x23]
    142c:      	b	0x144c <balancer_ingress+0x144c>
    1430:      	ldr	x8, [x23]
    1434:      	mov	w9, #0xe848             // =59464
    1438:      	movk	w9, #0x1, lsl #16
    143c:      	add	x8, x8, #0x1
    1440:      	cmp	x8, x9
    1444:      	str	x8, [x23]
    1448:      	b.hi	0x14dc <balancer_ingress+0x14dc>
    144c:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1450:      	mov	w8, #0x1                // =1
    1454:      	add	x1, sp, #0x28
    1458:      	ldr	x0, [x0]
    145c:      	blr	x8
    1460:      	cbz	x0, 0x14dc <balancer_ingress+0x14dc>
    1464:      	add	x8, sp, #0x40
    1468:      	mov	w9, #0x1                // =1
    146c:      	add	x1, x8, #0x28
    1470:      	blr	x9
    1474:      	cbz	x0, 0x14dc <balancer_ingress+0x14dc>
    1478:      	mov	w8, #0x20f              // =527
    147c:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1480:      	add	x1, sp, #0x70
    1484:      	str	w8, [sp, #0x70]
    1488:      	mov	w8, #0x1                // =1
    148c:      	ldr	x0, [x0]
    1490:      	blr	x8
    1494:      	cbz	x0, 0x1598 <balancer_ingress+0x1598>
    1498:      	ldr	x8, [x0]
    149c:      	add	x8, x8, #0x1
    14a0:      	str	x8, [x0]
    14a4:      	b	0x1598 <balancer_ingress+0x1598>
    14a8:      	str	x0, [x22, #0x8]
    14ac:      	ldr	w8, [x22]
    14b0:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    14b4:      	add	x1, sp, #0x70
    14b8:      	str	w8, [sp, #0x70]
    14bc:      	str	w8, [sp, #0x68]
    14c0:      	mov	w8, #0x1                // =1
    14c4:      	ldr	x0, [x0]
    14c8:      	blr	x8
    14cc:      	mov	x22, x0
    14d0:      	ldrb	w8, [sp, #0x64]
    14d4:      	cmp	w8, #0x11
    14d8:      	b.eq	0x13d8 <balancer_ingress+0x13d8>
    14dc:      	cbz	x22, 0x1598 <balancer_ingress+0x1598>
    14e0:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    14e4:      	mov	w21, #0x1               // =1
    14e8:      	add	x1, sp, #0x20
    14ec:      	ldr	x0, [x0]
    14f0:      	blr	x21
    14f4:      	cbz	x0, 0x1634 <balancer_ingress+0x1634>
    14f8:      	mov	x20, x0
    14fc:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1500:      	mov	w21, #0x1               // =1
    1504:      	ldr	x0, [x0]
    1508:      	add	x1, sp, #0x24
    150c:      	blr	x21
    1510:      	cbz	x0, 0x1634 <balancer_ingress+0x1634>
    1514:      	ldp	x8, x9, [x0]
    1518:      	rev16	w21, w25
    151c:      	mov	w23, #0x1               // =1
    1520:      	add	x8, x8, #0x1
    1524:      	add	x9, x9, x21
    1528:      	stp	x8, x9, [x0]
    152c:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1530:      	add	x8, sp, #0x40
    1534:      	ldr	x0, [x0]
    1538:      	add	x1, x8, #0x28
    153c:      	blr	x23
    1540:      	cbz	x0, 0x1590 <balancer_ingress+0x1590>
    1544:      	ldp	x8, x9, [x0]
    1548:      	add	x8, x8, #0x1
    154c:      	add	x9, x9, x21
    1550:      	stp	x8, x9, [x0]
    1554:      	ldr	w8, [sp]
    1558:      	strh	w8, [sp, #0x60]
    155c:      	ldrb	w8, [x22, #0x10]
    1560:      	tbnz	w8, #0x0, 0x1810 <balancer_ingress+0x1810>
    1564:      	ldrh	w23, [sp, #0x42]
    1568:      	mov	w8, #0x2c               // =44
    156c:      	mov	x0, x19
    1570:      	mov	w1, #-0x14              // =-20
    1574:      	blr	x8
    1578:      	cbz	w0, 0x18d8 <balancer_ingress+0x18d8>
    157c:      	mov	w8, #0x207              // =519
    1580:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1584:      	add	x1, sp, #0x70
    1588:      	str	w8, [sp, #0x70]
    158c:      	b	0x17f0 <balancer_ingress+0x17f0>
    1590:      	mov	w20, w23
    1594:      	b	0x1854 <balancer_ingress+0x1854>
    1598:      	ldrb	w8, [sp, #0x64]
    159c:      	cmp	w8, #0x6
    15a0:      	b.ne	0x15dc <balancer_ingress+0x15dc>
    15a4:      	mov	w8, #0x201              // =513
    15a8:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    15ac:      	add	x1, sp, #0x70
    15b0:      	str	w8, [sp, #0x70]
    15b4:      	mov	w8, #0x1                // =1
    15b8:      	ldr	x0, [x0]
    15bc:      	blr	x8
    15c0:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    15c4:      	ldrb	w8, [sp, #0x6c]
    15c8:      	tst	w8, #0x2
    15cc:      	cset	w8, eq
    15d0:      	ldr	x9, [x0, w8, uxtw #3]
    15d4:      	add	x9, x9, #0x1
    15d8:      	str	x9, [x0, w8, uxtw #3]
    15dc:      	mov	w8, #0x202              // =514
    15e0:      	stp	xzr, xzr, [sp, #0x70]
    15e4:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    15e8:      	mov	w29, #0x1               // =1
    15ec:      	add	x1, sp, #0xac
    15f0:      	str	w8, [sp, #0xac]
    15f4:      	ldr	x0, [x0]
    15f8:      	blr	x29
    15fc:      	cbz	x0, 0x163c <balancer_ingress+0x163c>
    1600:      	mov	w8, #0x5                // =5
    1604:      	mov	x22, x0
    1608:      	blr	x8
    160c:      	ldr	x8, [x22, #0x8]
    1610:      	mov	w9, #0xca00             // =51712
    1614:      	mov	x23, x0
    1618:      	movk	w9, #0x3b9a, lsl #16
    161c:      	sub	x8, x0, x8
    1620:      	cmp	x8, x9
    1624:      	b.ls	0x1644 <balancer_ingress+0x1644>
    1628:      	mov	w8, #0x1                // =1
    162c:      	stp	x8, x23, [x22]
    1630:      	b	0x1668 <balancer_ingress+0x1668>
    1634:      	mov	w20, w21
    1638:      	b	0x1854 <balancer_ingress+0x1854>
    163c:      	mov	x23, xzr
    1640:      	b	0x166c <balancer_ingress+0x166c>
    1644:      	ldr	x8, [x22]
    1648:      	mov	w9, #0xe848             // =59464
    164c:      	movk	w9, #0x1, lsl #16
    1650:      	add	x8, x8, #0x1
    1654:      	cmp	x8, x9
    1658:      	str	x8, [x22]
    165c:      	b.ls	0x1668 <balancer_ingress+0x1668>
    1660:      	mov	w29, #0x1               // =1
    1664:      	b	0x166c <balancer_ingress+0x166c>
    1668:      	mov	w29, wzr
    166c:      	ldrb	w8, [x21]
    1670:      	tbnz	w8, #0x3, 0x167c <balancer_ingress+0x167c>
    1674:      	ldr	w0, [sp, #0x40]
    1678:      	b	0x168c <balancer_ingress+0x168c>
    167c:      	ldrh	w8, [sp, #0x62]
    1680:      	mov	w0, wzr
    1684:      	stp	xzr, xzr, [sp, #0x40]
    1688:      	strh	w8, [sp, #0x60]
    168c:      	ldr	w1, [sp, #0x60]
    1690:      	bl	0x1690 <balancer_ingress+0x1690>
    1694:      	mov	w8, #-0xffff            // =-65535
    1698:      	ldr	w9, [x21, #0x4]
    169c:      	add	x1, sp, #0xa8
    16a0:      	umull	x8, w0, w8
    16a4:      	lsr	x8, x8, #48
    16a8:      	orr	w8, w8, w8, lsl #16
    16ac:      	add	w9, w9, w9, lsl #16
    16b0:      	sub	w8, w0, w8
    16b4:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    16b8:      	add	w8, w9, w8
    16bc:      	str	w8, [sp, #0xa8]
    16c0:      	mov	w8, #0x1                // =1
    16c4:      	ldr	x0, [x0]
    16c8:      	blr	x8
    16cc:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    16d0:      	ldr	w8, [x0]
    16d4:      	str	w8, [sp, #0xa8]
    16d8:      	cbz	w8, 0x17cc <balancer_ingress+0x17cc>
    16dc:      	str	w8, [sp, #0x68]
    16e0:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    16e4:      	mov	w8, #0x1                // =1
    16e8:      	add	x1, sp, #0xa8
    16ec:      	ldr	x0, [x0]
    16f0:      	blr	x8
    16f4:      	cbz	x0, 0x17e0 <balancer_ingress+0x17e0>
    16f8:      	ldrb	w8, [x21]
    16fc:      	mov	x22, x0
    1700:      	and	w8, w8, #0x2
    1704:      	orr	w8, w29, w8, lsr #1
    1708:      	tbnz	w8, #0x0, 0x1744 <balancer_ingress+0x1744>
    170c:      	ldrb	w8, [sp, #0x6c]
    1710:      	tbnz	w8, #0x2, 0x1744 <balancer_ingress+0x1744>
    1714:      	ldrb	w8, [sp, #0x64]
    1718:      	cmp	w8, #0x11
    171c:      	b.ne	0x1724 <balancer_ingress+0x1724>
    1720:      	str	x23, [sp, #0x78]
    1724:      	ldr	w8, [sp, #0xa8]
    1728:      	add	x1, sp, #0x40
    172c:      	add	x2, sp, #0x70
    1730:      	mov	x0, x20
    1734:      	str	w8, [sp, #0x70]
    1738:      	mov	w8, #0x2                // =2
    173c:      	mov	x3, xzr
    1740:      	blr	x8
    1744:      	str	wzr, [sp, #0x70]
    1748:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    174c:      	mov	w8, #0x1                // =1
    1750:      	add	x1, sp, #0x70
    1754:      	ldr	x0, [x0]
    1758:      	blr	x8
    175c:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    1760:      	ldr	w11, [x0]
    1764:      	ldr	w12, [sp, #0x28]
    1768:      	cmp	w11, w12
    176c:      	ldrh	w9, [x0, #0x10]
    1770:      	ldrh	w10, [sp, #0x38]
    1774:      	ldrb	w8, [sp, #0x3a]
    1778:      	strb	w8, [x0, #0x12]
    177c:      	b.ne	0x17b8 <balancer_ingress+0x17b8>
    1780:      	cmp	w9, w10
    1784:      	b.ne	0x17b8 <balancer_ingress+0x17b8>
    1788:      	cbz	w8, 0x17b8 <balancer_ingress+0x17b8>
    178c:      	ldr	w8, [sp, #0x68]
    1790:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1794:      	add	x1, sp, #0xac
    1798:      	str	w8, [sp, #0xac]
    179c:      	mov	w8, #0x1                // =1
    17a0:      	ldr	x0, [x0]
    17a4:      	blr	x8
    17a8:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    17ac:      	ldr	w8, [x0]
    17b0:      	add	w8, w8, #0x1
    17b4:      	str	w8, [x0]
    17b8:      	ldr	x8, [sp, #0x8]
    17bc:      	ldr	x9, [x8, #0x8]
    17c0:      	add	x9, x9, #0x1
    17c4:      	str	x9, [x8, #0x8]
    17c8:      	b	0x14e0 <balancer_ingress+0x14e0>
    17cc:      	mov	w8, #0x209              // =521
    17d0:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    17d4:      	add	x1, sp, #0xac
    17d8:      	str	w8, [sp, #0xac]
    17dc:      	b	0x1834 <balancer_ingress+0x1834>
    17e0:      	mov	w8, #0x209              // =521
    17e4:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    17e8:      	add	x1, sp, #0xac
    17ec:      	str	w8, [sp, #0xac]
    17f0:      	mov	w8, #0x1                // =1
    17f4:      	ldr	x0, [x0]
    17f8:      	blr	x8
    17fc:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    1800:      	ldr	x8, [x0]
    1804:      	add	x8, x8, #0x1
    1808:      	str	x8, [x0]
    180c:      	b	0x1850 <balancer_ingress+0x1850>
    1810:      	mov	w8, #0x2c               // =44
    1814:      	mov	x0, x19
    1818:      	mov	w1, #-0x28              // =-40
    181c:      	blr	x8
    1820:      	cbz	w0, 0x19e0 <balancer_ingress+0x19e0>
    1824:      	mov	w8, #0x207              // =519
    1828:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    182c:      	add	x1, sp, #0x70
    1830:      	str	w8, [sp, #0x70]
    1834:      	mov	w8, #0x1                // =1
    1838:      	ldr	x0, [x0]
    183c:      	blr	x8
    1840:      	cbz	x0, 0x1850 <balancer_ingress+0x1850>
    1844:      	ldr	x8, [x0, #0x8]
    1848:      	add	x8, x8, #0x1
    184c:      	str	x8, [x0, #0x8]
    1850:      	mov	w20, #0x1               // =1
    1854:      	cmp	w20, #0x1
    1858:      	b.eq	0x187c <balancer_ingress+0x187c>
    185c:      	cmp	w20, #0x3
    1860:      	b.ne	0x1870 <balancer_ingress+0x1870>
    1864:      	mov	w8, #0x211              // =529
    1868:      	mov	w20, #0x3               // =3
    186c:      	b	0x1884 <balancer_ingress+0x1884>
    1870:      	mov	w8, #0x213              // =531
    1874:      	mov	w20, #0x2               // =2
    1878:      	b	0x1884 <balancer_ingress+0x1884>
    187c:      	mov	w8, #0x212              // =530
    1880:      	mov	w20, #0x1               // =1
    1884:      	str	w8, [sp, #0x14]
    1888:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    188c:      	mov	w19, #0x1               // =1
    1890:      	add	x1, sp, #0x14
    1894:      	ldr	x0, [x0]
    1898:      	blr	x19
    189c:      	cbz	x0, 0x18b4 <balancer_ingress+0x18b4>
    18a0:      	ldp	x8, x9, [x0]
    18a4:      	add	x8, x8, #0x1
    18a8:      	add	x9, x9, x24
    18ac:      	stp	x8, x9, [x0]
    18b0:      	b	0x18b8 <balancer_ingress+0x18b8>
    18b4:      	mov	w20, w19
    18b8:      	mov	w0, w20
    18bc:      	ldp	x20, x19, [sp, #0xe0]
    18c0:      	ldr	x29, [sp, #0xa0]
    18c4:      	ldp	x22, x21, [sp, #0xd0]
    18c8:      	ldp	x24, x23, [sp, #0xc0]
    18cc:      	ldp	x30, x25, [sp, #0xb0]
    18d0:      	add	sp, sp, #0xf0
    18d4:      	ret
    18d8:      	ldp	x8, x9, [x19]
    18dc:      	add	x10, x8, #0xe
    18e0:      	cmp	x10, x9
    18e4:      	b.hi	0x157c <balancer_ingress+0x157c>
    18e8:      	add	x10, x8, #0x22
    18ec:      	cmp	x10, x9
    18f0:      	b.hi	0x157c <balancer_ingress+0x157c>
    18f4:      	ldr	w11, [x20]
    18f8:      	ldrh	w12, [x20, #0x4]
    18fc:      	mov	w13, #0x45              // =69
    1900:      	mov	w10, #0x10ac            // =4268
    1904:      	ldr	w9, [sp]
    1908:      	rev	w9, w9
    190c:      	str	w11, [x8]
    1910:      	ldrh	w11, [x8, #0x18]
    1914:      	strh	w12, [x8, #0x4]
    1918:      	eor	w9, w9, w23, lsl #16
    191c:      	orr	w10, w9, w10
    1920:      	strh	w11, [x8, #0xa]
    1924:      	ldr	w11, [x8, #0x14]
    1928:      	stur	w11, [x8, #0x6]
    192c:      	mov	w11, #0x8               // =8
    1930:      	strh	w11, [x8, #0xc]
    1934:      	ldrb	w11, [sp, #0x6d]
    1938:      	ldr	w12, [x22]
    193c:      	strb	w13, [x8, #0xe]
    1940:      	mov	w13, #0x4               // =4
    1944:      	strb	w13, [x8, #0x17]
    1948:      	strb	w11, [x8, #0xf]
    194c:      	add	w11, w21, #0x14
    1950:      	stur	w10, [x8, #0x1a]
    1954:      	mov	w10, #0x40              // =64
    1958:      	stur	w12, [x8, #0x1e]
    195c:      	lsr	w9, w9, #16
    1960:      	rev	w11, w11
    1964:      	mov	w20, #0x3               // =3
    1968:      	strb	w10, [x8, #0x16]
    196c:      	ldrh	w10, [x8, #0xe]
    1970:      	lsr	w11, w11, #16
    1974:      	stur	wzr, [x8, #0x12]
    1978:      	ldrh	w13, [x8, #0x16]
    197c:      	add	x10, x10, x13
    1980:      	strh	w11, [x8, #0x10]
    1984:      	add	x9, x10, x9
    1988:      	ldrh	w10, [x8, #0x20]
    198c:      	add	x9, x9, x11
    1990:      	mov	w11, #0x10ac            // =4268
    1994:      	add	x9, x9, w12, uxth
    1998:      	add	x10, x10, x11
    199c:      	add	x9, x9, x10
    19a0:      	lsr	x10, x9, #16
    19a4:      	cmp	x9, #0x10, lsl #12      // =0x10000
    19a8:      	add	x10, x10, w9, uxth
    19ac:      	csel	x9, x9, x10, lo
    19b0:      	lsr	x10, x9, #16
    19b4:      	cmp	x9, #0x10, lsl #12      // =0x10000
    19b8:      	add	x10, x10, w9, uxth
    19bc:      	csel	x9, x9, x10, lo
    19c0:      	lsr	x10, x9, #16
    19c4:      	cmp	x9, #0x10, lsl #12      // =0x10000
    19c8:      	add	w10, w10, w9, uxth
    19cc:      	csel	x9, x9, x10, lo
    19d0:      	add	w9, w9, w9, lsr #16
    19d4:      	mvn	w9, w9
    19d8:      	strh	w9, [x8, #0x18]
    19dc:      	b	0x1854 <balancer_ingress+0x1854>
    19e0:      	ldp	x8, x9, [x19]
    19e4:      	add	x10, x8, #0xe
    19e8:      	cmp	x10, x9
    19ec:      	b.hi	0x1824 <balancer_ingress+0x1824>
    19f0:      	add	x10, x8, #0x36
    19f4:      	cmp	x10, x9
    19f8:      	b.hi	0x1824 <balancer_ingress+0x1824>
    19fc:      	ldr	w9, [x20]
    1a00:      	ldrh	w10, [x20, #0x4]
    1a04:      	str	w9, [x8]
    1a08:      	ldrh	w9, [x8, #0x2c]
    1a0c:      	strh	w10, [x8, #0x4]
    1a10:      	strh	w9, [x8, #0xa]
    1a14:      	ldr	w9, [x8, #0x28]
    1a18:      	stur	w9, [x8, #0x6]
    1a1c:      	mov	w9, #0xdd86             // =56710
    1a20:      	strh	w9, [x8, #0xc]
    1a24:      	ldrb	w10, [sp, #0x6d]
    1a28:      	ldrh	w9, [sp, #0x60]
    1a2c:      	strh	wzr, [x8, #0x10]
    1a30:      	strh	w25, [x8, #0x12]
    1a34:      	lsr	w11, w10, #4
    1a38:      	lsl	w10, w10, #4
    1a3c:      	orr	w11, w11, #0x60
    1a40:      	strb	w10, [x8, #0xf]
    1a44:      	mov	w10, #0x4004            // =16388
    1a48:      	strb	w11, [x8, #0xe]
    1a4c:      	ldr	w11, [sp, #0x40]
    1a50:      	eor	w9, w11, w9
    1a54:      	strh	w10, [x8, #0x14]
    1a58:      	mov	w10, #0x1               // =1
    1a5c:      	stur	wzr, [x8, #0x1e]
    1a60:      	stur	w9, [x8, #0x22]
    1a64:      	mov	w20, #0x3               // =3
    1a68:      	stur	x10, [x8, #0x16]
    1a6c:      	ldp	x9, x10, [x22]
    1a70:      	stur	x10, [x8, #0x2e]
    1a74:      	stur	x9, [x8, #0x26]
    1a78:      	b	0x1854 <balancer_ingress+0x1854>
    1a7c:      	mov	w8, #0x202              // =514
    1a80:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1a84:      	add	x1, sp, #0x70
    1a88:      	str	w8, [sp, #0x70]
    1a8c:      	mov	w8, #0x1                // =1
    1a90:      	ldr	x0, [x0]
    1a94:      	blr	x8
    1a98:      	cbz	x0, 0x1c1c <balancer_ingress+0x1c1c>
    1a9c:      	mov	w8, #0x5                // =5
    1aa0:      	mov	x21, x0
    1aa4:      	blr	x8
    1aa8:      	ldr	x8, [x21, #0x8]
    1aac:      	mov	w9, #0xca00             // =51712
    1ab0:      	movk	w9, #0x3b9a, lsl #16
    1ab4:      	sub	x8, x0, x8
    1ab8:      	cmp	x8, x9
    1abc:      	b.ls	0x1bdc <balancer_ingress+0x1bdc>
    1ac0:      	mov	w8, #0x1                // =1
    1ac4:      	stp	x8, x0, [x21]
    1ac8:      	b	0x1bf8 <balancer_ingress+0x1bf8>
    1acc:      	str	w8, [x0]
    1ad0:      	str	w29, [sp, #0x70]
    1ad4:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1ad8:      	mov	w8, #0x1                // =1
    1adc:      	add	x1, sp, #0x70
    1ae0:      	ldr	x9, [x23, #0x58]
    1ae4:      	add	x9, x9, #0x1
    1ae8:      	str	x9, [x23, #0x58]
    1aec:      	ldr	x0, [x0]
    1af0:      	blr	x8
    1af4:      	cbz	x0, 0x1c2c <balancer_ingress+0x1c2c>
    1af8:      	ldr	x8, [x0, #0x8]
    1afc:      	add	x8, x8, #0x1
    1b00:      	str	x8, [x0, #0x8]
    1b04:      	b	0x1c2c <balancer_ingress+0x1c2c>
    1b08:      	ldr	x8, [sp]
    1b0c:      	add	x8, x8, #0x40
    1b10:      	b	0x1b28 <balancer_ingress+0x1b28>
    1b14:      	ldr	x8, [sp]
    1b18:      	add	x8, x8, #0x48
    1b1c:      	b	0x1b28 <balancer_ingress+0x1b28>
    1b20:      	ldr	x8, [sp]
    1b24:      	add	x8, x8, #0x30
    1b28:      	ldr	x9, [x8]
    1b2c:      	str	w22, [sp, #0xa8]
    1b30:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1b34:      	add	x1, sp, #0xa8
    1b38:      	add	x9, x9, #0x1
    1b3c:      	str	x9, [x8]
    1b40:      	mov	w8, #0x1                // =1
    1b44:      	ldr	x0, [x0]
    1b48:      	blr	x8
    1b4c:      	cbz	x0, 0x1bb4 <balancer_ingress+0x1bb4>
    1b50:      	ldr	w8, [x0]
    1b54:      	str	w8, [sp, #0xa8]
    1b58:      	cbz	w8, 0x1bb4 <balancer_ingress+0x1bb4>
    1b5c:      	str	w8, [sp, #0x68]
    1b60:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1b64:      	mov	w8, #0x1                // =1
    1b68:      	add	x1, sp, #0xa8
    1b6c:      	ldr	x0, [x0]
    1b70:      	blr	x8
    1b74:      	cbz	x0, 0x1bc8 <balancer_ingress+0x1bc8>
    1b78:      	mov	x22, x0
    1b7c:      	mov	w8, #0x1                // =1
    1b80:      	add	x1, sp, #0x40
    1b84:      	mov	x0, x20
    1b88:      	blr	x8
    1b8c:      	cbz	x0, 0x1c40 <balancer_ingress+0x1c40>
    1b90:      	ldr	w9, [x0]
    1b94:      	ldr	w8, [sp, #0x68]
    1b98:      	cmp	w9, w8
    1b9c:      	b.ne	0x1c90 <balancer_ingress+0x1c90>
    1ba0:      	ldr	x9, [sp]
    1ba4:      	ldr	x8, [x9, #0x50]
    1ba8:      	add	x8, x8, #0x1
    1bac:      	str	x8, [x9, #0x50]
    1bb0:      	b	0x1d20 <balancer_ingress+0x1d20>
    1bb4:      	ldr	x9, [sp]
    1bb8:      	ldr	x8, [x9, #0x10]
    1bbc:      	add	x8, x8, #0x1
    1bc0:      	stp	x8, x22, [x9, #0x10]
    1bc4:      	b	0x135c <balancer_ingress+0x135c>
    1bc8:      	ldr	x9, [sp]
    1bcc:      	ldr	x8, [x9, #0x28]
    1bd0:      	add	x8, x8, #0x1
    1bd4:      	str	x8, [x9, #0x28]
    1bd8:      	b	0x1850 <balancer_ingress+0x1850>
    1bdc:      	ldr	x8, [x21]
    1be0:      	mov	w9, #0xe848             // =59464
    1be4:      	movk	w9, #0x1, lsl #16
    1be8:      	add	x8, x8, #0x1
    1bec:      	cmp	x8, x9
    1bf0:      	str	x8, [x21]
    1bf4:      	b.hi	0x1c1c <balancer_ingress+0x1c1c>
    1bf8:      	ldr	w8, [sp, #0x68]
    1bfc:      	stp	xzr, xzr, [sp, #0x70]
    1c00:      	add	x1, sp, #0x40
    1c04:      	add	x2, sp, #0x70
    1c08:      	mov	x0, x20
    1c0c:      	mov	x3, xzr
    1c10:      	str	w8, [sp, #0x70]
    1c14:      	mov	w8, #0x2                // =2
    1c18:      	blr	x8
    1c1c:      	ldr	x9, [x23, #0x60]
    1c20:      	mov	x8, x23
    1c24:      	add	x9, x9, #0x1
    1c28:      	str	x9, [x23, #0x60]
    1c2c:      	ldr	x8, [x23, #0x20]
    1c30:      	add	x8, x8, #0x1
    1c34:      	str	x8, [x23, #0x20]
    1c38:      	ldrh	w29, [sp, #0x60]
    1c3c:      	b	0xdd8 <balancer_ingress+0xdd8>
    1c40:      	mov	w8, #0x202              // =514
    1c44:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1c48:      	add	x1, sp, #0x70
    1c4c:      	str	w8, [sp, #0x70]
    1c50:      	mov	w8, #0x1                // =1
    1c54:      	ldr	x0, [x0]
    1c58:      	blr	x8
    1c5c:      	cbz	x0, 0x1d10 <balancer_ingress+0x1d10>
    1c60:      	mov	w8, #0x5                // =5
    1c64:      	mov	x21, x0
    1c68:      	blr	x8
    1c6c:      	ldr	x8, [x21, #0x8]
    1c70:      	mov	w9, #0xca00             // =51712
    1c74:      	movk	w9, #0x3b9a, lsl #16
    1c78:      	sub	x8, x0, x8
    1c7c:      	cmp	x8, x9
    1c80:      	b.ls	0x1cd0 <balancer_ingress+0x1cd0>
    1c84:      	mov	w8, #0x1                // =1
    1c88:      	stp	x8, x0, [x21]
    1c8c:      	b	0x1cec <balancer_ingress+0x1cec>
    1c90:      	ldr	x9, [sp]
    1c94:      	str	w8, [x0]
    1c98:      	adrp	x0, 0x1000 <balancer_ingress+0x1000>
    1c9c:      	add	x1, sp, #0x70
    1ca0:      	str	w23, [sp, #0x70]
    1ca4:      	ldr	x8, [x9, #0x58]
    1ca8:      	add	x8, x8, #0x1
    1cac:      	str	x8, [x9, #0x58]
    1cb0:      	mov	w8, #0x1                // =1
    1cb4:      	ldr	x0, [x0]
    1cb8:      	blr	x8
    1cbc:      	cbz	x0, 0x1d20 <balancer_ingress+0x1d20>
    1cc0:      	ldr	x8, [x0, #0x8]
    1cc4:      	add	x8, x8, #0x1
    1cc8:      	str	x8, [x0, #0x8]
    1ccc:      	b	0x1d20 <balancer_ingress+0x1d20>
    1cd0:      	ldr	x8, [x21]
    1cd4:      	mov	w9, #0xe848             // =59464
    1cd8:      	movk	w9, #0x1, lsl #16
    1cdc:      	add	x8, x8, #0x1
    1ce0:      	cmp	x8, x9
    1ce4:      	str	x8, [x21]
    1ce8:      	b.hi	0x1d10 <balancer_ingress+0x1d10>
    1cec:      	ldr	w8, [sp, #0x68]
    1cf0:      	stp	xzr, xzr, [sp, #0x70]
    1cf4:      	add	x1, sp, #0x40
    1cf8:      	add	x2, sp, #0x70
    1cfc:      	mov	x0, x20
    1d00:      	mov	x3, xzr
    1d04:      	str	w8, [sp, #0x70]
    1d08:      	mov	w8, #0x2                // =2
    1d0c:      	blr	x8
    1d10:      	ldr	x9, [sp]
    1d14:      	ldr	x8, [x9, #0x60]
    1d18:      	add	x8, x8, #0x1
    1d1c:      	str	x8, [x9, #0x60]
    1d20:      	ldr	x9, [sp]
    1d24:      	ldr	x8, [x9, #0x20]
    1d28:      	add	x8, x8, #0x1
    1d2c:      	str	x8, [x9, #0x20]
    1d30:      	ldrh	w8, [sp, #0x60]
    1d34:      	str	w8, [sp]
    1d38:      	b	0x14e0 <balancer_ingress+0x14e0>
