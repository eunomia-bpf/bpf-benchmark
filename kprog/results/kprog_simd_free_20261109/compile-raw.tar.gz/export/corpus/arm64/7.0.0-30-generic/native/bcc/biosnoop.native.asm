
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/biosnoop.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/blk_account_io_merge_bio:

0000000000000000 <blk_account_io_merge_bio>:
       0:      	sub	sp, sp, #0x30
       4:      	stp	x30, x19, [sp, #0x20]
       8:      	adrp	x8, 0x0 <blk_account_io_merge_bio>
       c:      	ldr	x19, [x0]
      10:      	ldr	x8, [x8]
      14:      	ldrb	w8, [x8]
      18:      	cbz	w8, 0x30 <blk_account_io_merge_bio+0x30>
      1c:      	adrp	x0, 0x0 <blk_account_io_merge_bio>
      20:      	mov	w1, wzr
      24:      	ldr	x0, [x0]
      28:      	bl	0x28 <blk_account_io_merge_bio+0x28>
      2c:      	cbz	x0, 0x68 <blk_account_io_merge_bio+0x68>
      30:      	str	x19, [sp, #0x18]
      34:      	bl	0x34 <blk_account_io_merge_bio+0x34>
      38:      	lsr	x8, x0, #32
      3c:      	mov	x0, sp
      40:      	mov	w1, #0x8                // =8
      44:      	stp	xzr, xzr, [sp]
      48:      	str	w8, [sp, #0x10]
      4c:      	bl	0x4c <blk_account_io_merge_bio+0x4c>
      50:      	adrp	x0, 0x0 <blk_account_io_merge_bio>
      54:      	add	x1, sp, #0x18
      58:      	mov	x2, sp
      5c:      	ldr	x0, [x0]
      60:      	mov	x3, xzr
      64:      	bl	0x64 <blk_account_io_merge_bio+0x64>
      68:      	ldp	x30, x19, [sp, #0x20]
      6c:      	mov	w0, wzr
      70:      	add	sp, sp, #0x30
      74:      	ret

Disassembly of section tp_btf/block_rq_insert:

0000000000000000 <block_rq_insert>:
       0:      	sub	sp, sp, #0x50
       4:      	stp	x30, x21, [sp, #0x30]
       8:      	stp	x20, x19, [sp, #0x40]
       c:      	adrp	x8, 0x0 <block_rq_insert>
      10:      	mov	x19, x0
      14:      	ldr	x8, [x8]
      18:      	ldrb	w8, [x8]
      1c:      	cbz	w8, 0x34 <block_rq_insert+0x34>
      20:      	adrp	x0, 0x0 <block_rq_insert>
      24:      	mov	w1, wzr
      28:      	ldr	x0, [x0]
      2c:      	bl	0x2c <block_rq_insert+0x2c>
      30:      	cbz	x0, 0x14c <block_rq_insert+0x14c>
      34:      	adrp	x8, 0x0 <block_rq_insert>
      38:      	ldr	x8, [x8]
      3c:      	ldr	w8, [x8]
      40:      	lsr	w8, w8, #8
      44:      	cmp	w8, #0x50b
      48:      	b.lo	0x54 <block_rq_insert+0x54>
      4c:      	ldr	x8, [x19]
      50:      	b	0x58 <block_rq_insert+0x58>
      54:      	ldr	x8, [x19, #0x8]
      58:      	stp	xzr, xzr, [sp, #0x8]
      5c:      	stp	xzr, x8, [sp, #0x18]
      60:      	bl	0x60 <block_rq_insert+0x60>
      64:      	mov	x19, x0
      68:      	adrp	x0, 0x0 <block_rq_insert>
      6c:      	add	x1, sp, #0x20
      70:      	ldr	x0, [x0]
      74:      	bl	0x74 <block_rq_insert+0x74>
      78:      	cbz	x0, 0x90 <block_rq_insert+0x90>
      7c:      	add	x8, sp, #0x8
      80:      	str	x19, [x0]
      84:      	cmp	x0, x8
      88:      	b.ne	0x14c <block_rq_insert+0x14c>
      8c:      	b	0x120 <block_rq_insert+0x120>
      90:      	ldr	x8, [sp, #0x20]
      94:      	add	x0, sp, #0x28
      98:      	mov	w1, #0x8                // =8
      9c:      	add	x2, x8, #0x8
      a0:      	bl	0xa0 <block_rq_insert+0xa0>
      a4:      	ldr	x20, [sp, #0x28]
      a8:      	cbz	x20, 0xf0 <block_rq_insert+0xf0>
      ac:      	add	x0, sp, #0x28
      b0:      	mov	w1, #0x4                // =4
      b4:      	mov	x2, x20
      b8:      	bl	0xb8 <block_rq_insert+0xb8>
      bc:      	ldr	w21, [sp, #0x28]
      c0:      	add	x0, sp, #0x28
      c4:      	add	x2, x20, #0x4
      c8:      	mov	w1, #0x4                // =4
      cc:      	bl	0xcc <block_rq_insert+0xcc>
      d0:      	ldr	w8, [sp, #0x28]
      d4:      	orr	w8, w8, w21, lsl #20
      d8:      	str	w8, [sp, #0x18]
      dc:      	adrp	x9, 0x0 <block_rq_insert>
      e0:      	ldr	x9, [x9]
      e4:      	ldrb	w9, [x9]
      e8:      	cbnz	w9, 0x108 <block_rq_insert+0x108>
      ec:      	b	0x11c <block_rq_insert+0x11c>
      f0:      	mov	w8, wzr
      f4:      	str	wzr, [sp, #0x18]
      f8:      	adrp	x9, 0x0 <block_rq_insert>
      fc:      	ldr	x9, [x9]
     100:      	ldrb	w9, [x9]
     104:      	cbz	w9, 0x11c <block_rq_insert+0x11c>
     108:      	adrp	x9, 0x0 <block_rq_insert>
     10c:      	ldr	x9, [x9]
     110:      	ldr	w9, [x9]
     114:      	cmp	w9, w8
     118:      	b.ne	0x14c <block_rq_insert+0x14c>
     11c:      	str	x19, [sp, #0x8]
     120:      	adrp	x0, 0x0 <block_rq_insert>
     124:      	add	x1, sp, #0x20
     128:      	add	x2, sp, #0x8
     12c:      	ldr	x0, [x0]
     130:      	mov	x3, xzr
     134:      	bl	0x134 <block_rq_insert+0x134>
     138:      	ldp	x20, x19, [sp, #0x40]
     13c:      	mov	w0, wzr
     140:      	ldp	x30, x21, [sp, #0x30]
     144:      	add	sp, sp, #0x50
     148:      	ret
     14c:      	ldp	x20, x19, [sp, #0x40]
     150:      	mov	w0, wzr
     154:      	ldp	x30, x21, [sp, #0x30]
     158:      	add	sp, sp, #0x50
     15c:      	ret

Disassembly of section tp_btf/block_rq_issue:

0000000000000000 <block_rq_issue>:
       0:      	sub	sp, sp, #0x50
       4:      	stp	x30, x21, [sp, #0x30]
       8:      	stp	x20, x19, [sp, #0x40]
       c:      	adrp	x8, 0x0 <block_rq_issue>
      10:      	mov	x19, x0
      14:      	ldr	x8, [x8]
      18:      	ldrb	w8, [x8]
      1c:      	cbz	w8, 0x34 <block_rq_issue+0x34>
      20:      	adrp	x0, 0x0 <block_rq_issue>
      24:      	mov	w1, wzr
      28:      	ldr	x0, [x0]
      2c:      	bl	0x2c <block_rq_issue+0x2c>
      30:      	cbz	x0, 0xbc <block_rq_issue+0xbc>
      34:      	adrp	x8, 0x0 <block_rq_issue>
      38:      	ldr	x8, [x8]
      3c:      	ldr	w8, [x8]
      40:      	lsr	w8, w8, #8
      44:      	cmp	w8, #0x50b
      48:      	cset	w8, lo
      4c:      	ldr	x19, [x19, w8, uxtw #3]
      50:      	str	x19, [sp, #0x28]
      54:      	bl	0x54 <block_rq_issue+0x54>
      58:      	lsr	x8, x0, #32
      5c:      	add	x0, sp, #0x8
      60:      	mov	w1, #0x8                // =8
      64:      	stp	xzr, xzr, [sp, #0x8]
      68:      	str	w8, [sp, #0x18]
      6c:      	add	x20, sp, #0x8
      70:      	bl	0x70 <block_rq_issue+0x70>
      74:      	adrp	x0, 0x0 <block_rq_issue>
      78:      	add	x1, sp, #0x28
      7c:      	add	x2, sp, #0x8
      80:      	ldr	x0, [x0]
      84:      	mov	x3, xzr
      88:      	bl	0x88 <block_rq_issue+0x88>
      8c:      	stp	xzr, x19, [sp, #0x18]
      90:      	stp	xzr, xzr, [sp, #0x8]
      94:      	bl	0x94 <block_rq_issue+0x94>
      98:      	mov	x19, x0
      9c:      	adrp	x0, 0x0 <block_rq_issue>
      a0:      	add	x1, sp, #0x20
      a4:      	ldr	x0, [x0]
      a8:      	bl	0xa8 <block_rq_issue+0xa8>
      ac:      	cbz	x0, 0xd0 <block_rq_issue+0xd0>
      b0:      	cmp	x0, x20
      b4:      	str	x19, [x0, #0x8]
      b8:      	b.eq	0x160 <block_rq_issue+0x160>
      bc:      	ldp	x20, x19, [sp, #0x40]
      c0:      	mov	w0, wzr
      c4:      	ldp	x30, x21, [sp, #0x30]
      c8:      	add	sp, sp, #0x50
      cc:      	ret
      d0:      	ldr	x8, [sp, #0x20]
      d4:      	add	x0, sp, #0x28
      d8:      	mov	w1, #0x8                // =8
      dc:      	add	x2, x8, #0x8
      e0:      	bl	0xe0 <block_rq_issue+0xe0>
      e4:      	ldr	x20, [sp, #0x28]
      e8:      	cbz	x20, 0x130 <block_rq_issue+0x130>
      ec:      	add	x0, sp, #0x28
      f0:      	mov	w1, #0x4                // =4
      f4:      	mov	x2, x20
      f8:      	bl	0xf8 <block_rq_issue+0xf8>
      fc:      	ldr	w21, [sp, #0x28]
     100:      	add	x0, sp, #0x28
     104:      	add	x2, x20, #0x4
     108:      	mov	w1, #0x4                // =4
     10c:      	bl	0x10c <block_rq_issue+0x10c>
     110:      	ldr	w8, [sp, #0x28]
     114:      	orr	w8, w8, w21, lsl #20
     118:      	str	w8, [sp, #0x18]
     11c:      	adrp	x9, 0x0 <block_rq_issue>
     120:      	ldr	x9, [x9]
     124:      	ldrb	w9, [x9]
     128:      	cbnz	w9, 0x148 <block_rq_issue+0x148>
     12c:      	b	0x15c <block_rq_issue+0x15c>
     130:      	mov	w8, wzr
     134:      	str	wzr, [sp, #0x18]
     138:      	adrp	x9, 0x0 <block_rq_issue>
     13c:      	ldr	x9, [x9]
     140:      	ldrb	w9, [x9]
     144:      	cbz	w9, 0x15c <block_rq_issue+0x15c>
     148:      	adrp	x9, 0x0 <block_rq_issue>
     14c:      	ldr	x9, [x9]
     150:      	ldr	w9, [x9]
     154:      	cmp	w9, w8
     158:      	b.ne	0xbc <block_rq_issue+0xbc>
     15c:      	str	x19, [sp, #0x10]
     160:      	adrp	x0, 0x0 <block_rq_issue>
     164:      	add	x1, sp, #0x20
     168:      	add	x2, sp, #0x8
     16c:      	ldr	x0, [x0]
     170:      	mov	x3, xzr
     174:      	bl	0x174 <block_rq_issue+0x174>
     178:      	ldp	x20, x19, [sp, #0x40]
     17c:      	mov	w0, wzr
     180:      	ldp	x30, x21, [sp, #0x30]
     184:      	add	sp, sp, #0x50
     188:      	ret

Disassembly of section tp_btf/block_rq_complete:

0000000000000000 <block_rq_complete>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	x22, x21, [sp, #0x60]
       8:      	stp	x20, x19, [sp, #0x70]
       c:      	ldr	x8, [x0]
      10:      	mov	x19, x0
      14:      	stp	x30, x8, [sp, #0x50]
      18:      	adrp	x8, 0x0 <block_rq_complete>
      1c:      	ldr	x8, [x8]
      20:      	ldrb	w8, [x8]
      24:      	cbz	w8, 0x3c <block_rq_complete+0x3c>
      28:      	adrp	x0, 0x0 <block_rq_complete>
      2c:      	mov	w1, wzr
      30:      	ldr	x0, [x0]
      34:      	bl	0x34 <block_rq_complete+0x34>
      38:      	cbz	x0, 0x178 <block_rq_complete+0x178>
      3c:      	bl	0x3c <block_rq_complete+0x3c>
      40:      	mov	x20, x0
      44:      	stp	xzr, xzr, [sp, #0x40]
      48:      	adrp	x0, 0x0 <block_rq_complete>
      4c:      	add	x1, sp, #0x58
      50:      	stp	xzr, xzr, [sp, #0x30]
      54:      	stp	xzr, xzr, [sp, #0x20]
      58:      	stp	xzr, xzr, [sp, #0x10]
      5c:      	ldr	x0, [x0]
      60:      	bl	0x60 <block_rq_complete+0x60>
      64:      	cbz	x0, 0x178 <block_rq_complete+0x178>
      68:      	ldr	x8, [x0, #0x8]
      6c:      	mov	x21, x0
      70:      	subs	x22, x20, x8
      74:      	b.mi	0x158 <block_rq_complete+0x158>
      78:      	adrp	x0, 0x0 <block_rq_complete>
      7c:      	add	x1, sp, #0x58
      80:      	ldr	x0, [x0]
      84:      	bl	0x84 <block_rq_complete+0x84>
      88:      	cbz	x0, 0xb4 <block_rq_complete+0xb4>
      8c:      	ldp	x8, x9, [x0]
      90:      	stp	x8, x9, [sp, #0x10]
      94:      	ldr	w8, [x0, #0x10]
      98:      	str	w8, [sp, #0x44]
      9c:      	str	x22, [sp, #0x20]
      a0:      	adrp	x8, 0x0 <block_rq_complete>
      a4:      	ldr	x8, [x8]
      a8:      	ldrb	w8, [x8]
      ac:      	cbnz	w8, 0xd0 <block_rq_complete+0xd0>
      b0:      	b	0x118 <block_rq_complete+0x118>
      b4:      	mov	w8, #0x3f               // =63
      b8:      	strb	w8, [sp, #0x10]
      bc:      	str	x22, [sp, #0x20]
      c0:      	adrp	x8, 0x0 <block_rq_complete>
      c4:      	ldr	x8, [x8]
      c8:      	ldrb	w8, [x8]
      cc:      	cbz	w8, 0x118 <block_rq_complete+0x118>
      d0:      	ldr	x2, [sp, #0x58]
      d4:      	mov	x0, sp
      d8:      	mov	w1, #0x8                // =8
      dc:      	bl	0xdc <block_rq_complete+0xdc>
      e0:      	ldr	x8, [sp]
      e4:      	add	x0, sp, #0x8
      e8:      	mov	w1, #0x8                // =8
      ec:      	add	x2, x8, #0x8
      f0:      	bl	0xf0 <block_rq_complete+0xf0>
      f4:      	ldr	x8, [sp, #0x8]
      f8:      	cbz	x8, 0x118 <block_rq_complete+0x118>
      fc:      	ldr	x8, [x21]
     100:      	cbz	x8, 0x110 <block_rq_complete+0x110>
     104:      	ldr	x9, [x21, #0x8]
     108:      	sub	x8, x9, x8
     10c:      	b	0x114 <block_rq_complete+0x114>
     110:      	mov	x8, #-0x1               // =-1
     114:      	str	x8, [sp, #0x28]
     118:      	ldr	x8, [sp, #0x58]
     11c:      	adrp	x1, 0x0 <block_rq_complete>
     120:      	add	x3, sp, #0x10
     124:      	mov	x0, x19
     128:      	ldr	x9, [x8, #0x30]
     12c:      	ldr	w10, [x8, #0x2c]
     130:      	ldr	w8, [x8, #0x18]
     134:      	mov	w2, #-0x1               // =-1
     138:      	mov	w4, #0x40               // =64
     13c:      	str	w8, [sp, #0x48]
     140:      	ldr	w8, [x21, #0x10]
     144:      	stp	x20, x9, [sp, #0x30]
     148:      	str	w10, [sp, #0x40]
     14c:      	str	w8, [sp, #0x4c]
     150:      	ldr	x1, [x1]
     154:      	bl	0x154 <block_rq_complete+0x154>
     158:      	adrp	x0, 0x0 <block_rq_complete>
     15c:      	add	x1, sp, #0x58
     160:      	ldr	x0, [x0]
     164:      	bl	0x164 <block_rq_complete+0x164>
     168:      	adrp	x0, 0x0 <block_rq_complete>
     16c:      	add	x1, sp, #0x58
     170:      	ldr	x0, [x0]
     174:      	bl	0x174 <block_rq_complete+0x174>
     178:      	ldp	x20, x19, [sp, #0x70]
     17c:      	mov	w0, wzr
     180:      	ldr	x30, [sp, #0x50]
     184:      	ldp	x22, x21, [sp, #0x60]
     188:      	add	sp, sp, #0x80
     18c:      	ret
