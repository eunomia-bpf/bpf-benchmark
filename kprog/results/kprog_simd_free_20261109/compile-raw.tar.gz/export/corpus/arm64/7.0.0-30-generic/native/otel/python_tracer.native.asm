
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/python_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_python:

0000000000000000 <perf_unwind_python>:
       0:      	sub	sp, sp, #0xe0
       4:      	str	x29, [sp, #0x90]
       8:      	stp	x30, x25, [sp, #0xa0]
       c:      	stp	x24, x23, [sp, #0xb0]
      10:      	stp	x22, x21, [sp, #0xc0]
      14:      	stp	x20, x19, [sp, #0xd0]
      18:      	str	wzr, [sp, #0x40]
      1c:      	adrp	x20, 0x0 <perf_unwind_python>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x40
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x40
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x788 <perf_unwind_python+0x788>
      40:      	ldr	w8, [x0]
      44:      	adrp	x25, 0x0 <perf_unwind_python>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0x3c]
      50:      	ldr	x25, [x25]
      54:      	ldr	w8, [x25]
      58:      	cbnz	w8, 0x448 <perf_unwind_python+0x448>
      5c:      	adrp	x0, 0x0 <perf_unwind_python>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x3c
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x3c
      70:      	blr	x8
      74:      	ldr	w8, [x25]
      78:      	cbz	x0, 0x118 <perf_unwind_python+0x118>
      7c:      	cbnz	w8, 0x4cc <perf_unwind_python+0x4cc>
      80:      	ldr	x29, [x21, #0xf48]
      84:      	add	x22, x21, #0xf48
      88:      	cbz	x29, 0x514 <perf_unwind_python+0x514>
      8c:      	ldrb	w8, [x0, #0x19]
      90:      	cmp	w8, #0x78
      94:      	b.hi	0x154 <perf_unwind_python+0x154>
      98:      	ldrb	w8, [x0, #0x18]
      9c:      	cmp	w8, #0x78
      a0:      	b.hi	0x154 <perf_unwind_python+0x154>
      a4:      	ldrb	w8, [x0, #0x1a]
      a8:      	cmp	w8, #0x78
      ac:      	b.hi	0x154 <perf_unwind_python+0x154>
      b0:      	ldrsb	w8, [x0, #0x1b]
      b4:      	tbnz	w8, #0x1f, 0x154 <perf_unwind_python+0x154>
      b8:      	str	x0, [sp, #0x28]
      bc:      	add	x23, x21, #0xf70
      c0:      	mov	w8, #0x80               // =128
      c4:      	mov	w9, #0x70               // =112
      c8:      	mov	x0, x23
      cc:      	mov	w1, #0x80               // =128
      d0:      	mov	x2, x29
      d4:      	blr	x9
      d8:      	cbz	x0, 0x188 <perf_unwind_python+0x188>
      dc:      	ldr	w8, [x25]
      e0:      	cbnz	w8, 0xc48 <perf_unwind_python+0xc48>
      e4:      	mov	w8, #0x1b               // =27
      e8:      	adrp	x0, 0x0 <perf_unwind_python>
      ec:      	add	x9, sp, #0x88
      f0:      	str	w8, [sp, #0x88]
      f4:      	mov	w8, #0x1                // =1
      f8:      	add	x1, sp, #0x88
      fc:      	ldr	x0, [x0]
     100:      	blr	x8
     104:      	cbz	x0, 0x1c4 <perf_unwind_python+0x1c4>
     108:      	ldr	x8, [x0]
     10c:      	add	x8, x8, #0x1
     110:      	str	x8, [x0]
     114:      	b	0x1cc <perf_unwind_python+0x1cc>
     118:      	cbnz	w8, 0xad0 <perf_unwind_python+0xad0>
     11c:      	mov	w8, #0x45               // =69
     120:      	adrp	x0, 0x0 <perf_unwind_python>
     124:      	add	x9, sp, #0x88
     128:      	str	w8, [sp, #0x88]
     12c:      	mov	w8, #0x1                // =1
     130:      	add	x1, sp, #0x88
     134:      	ldr	x0, [x0]
     138:      	blr	x8
     13c:      	cbz	x0, 0x178 <perf_unwind_python+0x178>
     140:      	ldr	x8, [x0]
     144:      	add	x8, x8, #0x1
     148:      	str	x8, [x0]
     14c:      	mov	w0, #0x7d1              // =2001
     150:      	b	0x78c <perf_unwind_python+0x78c>
     154:      	mov	w8, wzr
     158:      	mov	w9, #0x1                // =1
     15c:      	ldr	w10, [x21, #0x1370]
     160:      	mov	w23, w8
     164:      	orr	w10, w10, #0x10
     168:      	str	w10, [x21, #0x1370]
     16c:      	mov	w8, w9
     170:      	str	x29, [x22]
     174:      	b	0x6c4 <perf_unwind_python+0x6c4>
     178:      	ldr	w8, [x25]
     17c:      	cbnz	w8, 0xbb4 <perf_unwind_python+0xbb4>
     180:      	mov	w0, #0x7d1              // =2001
     184:      	b	0x78c <perf_unwind_python+0x78c>
     188:      	ldr	x8, [sp, #0x28]
     18c:      	ldrb	w9, [x8, #0x19]
     190:      	ldr	x2, [x23, x9]
     194:      	ldrb	w9, [x8, #0x18]
     198:      	ldr	x12, [x23, x9]
     19c:      	ldr	x9, [x8, #0x8]
     1a0:      	cbz	x9, 0x1d8 <perf_unwind_python+0x1d8>
     1a4:      	cmp	x2, x9
     1a8:      	b.ne	0x1d8 <perf_unwind_python+0x1d8>
     1ac:      	mov	w9, wzr
     1b0:      	mov	w8, #0x1                // =1
     1b4:      	cbz	x12, 0x22c <perf_unwind_python+0x22c>
     1b8:      	mov	w23, #0x1               // =1
     1bc:      	mov	x29, x12
     1c0:      	b	0x16c <perf_unwind_python+0x16c>
     1c4:      	ldr	w8, [x25]
     1c8:      	cbnz	w8, 0x1054 <perf_unwind_python+0x1054>
     1cc:      	mov	w8, wzr
     1d0:      	mov	w9, #0x7d2              // =2002
     1d4:      	b	0x15c <perf_unwind_python+0x15c>
     1d8:      	ldrb	w10, [x8, #0x22]
     1dc:      	ldrb	w9, [x8, #0x1a]
     1e0:      	str	x22, [sp, #0x20]
     1e4:      	cbz	w10, 0x234 <perf_unwind_python+0x234>
     1e8:      	ldrb	w10, [x8, #0x21]
     1ec:      	ldr	x9, [x23, x9]
     1f0:      	mov	x11, #-0x3              // =-3
     1f4:      	movk	x11, #0xefff, lsl #16
     1f8:      	add	x10, x2, x10
     1fc:      	sub	x9, x9, x10
     200:      	mov	x10, #-0x10000001       // =-268435457
     204:      	add	x10, x9, x10
     208:      	asr	w9, w9, #1
     20c:      	cmp	x10, x11
     210:      	ldrb	w10, [x8, #0x1c]
     214:      	csinv	w24, w9, wzr, hs
     218:      	ldrb	w9, [x8, #0x1b]
     21c:      	ldrb	w9, [x23, x9]
     220:      	cmp	w9, w10
     224:      	cset	w10, eq
     228:      	b	0x238 <perf_unwind_python+0x238>
     22c:      	mov	x29, xzr
     230:      	b	0x15c <perf_unwind_python+0x15c>
     234:      	ldr	w24, [x23, x9]
     238:      	add	x22, x21, #0xff0
     23c:      	cbz	x2, 0x284 <perf_unwind_python+0x284>
     240:      	ldrb	w9, [x8, #0x1d]
     244:      	cmp	w9, #0xbc
     248:      	b.hi	0x270 <perf_unwind_python+0x270>
     24c:      	ldrb	w9, [x8, #0x1e]
     250:      	cmp	w9, #0xbc
     254:      	b.hi	0x270 <perf_unwind_python+0x270>
     258:      	ldrb	w9, [x8, #0x1f]
     25c:      	cmp	w9, #0xbc
     260:      	b.hi	0x270 <perf_unwind_python+0x270>
     264:      	ldrb	w8, [x8, #0x20]
     268:      	cmp	w8, #0xbc
     26c:      	b.ls	0xa64 <perf_unwind_python+0xa64>
     270:      	ldr	x22, [sp, #0x20]
     274:      	mov	w8, wzr
     278:      	mov	w9, #0x1                // =1
     27c:      	mov	x29, x12
     280:      	b	0x15c <perf_unwind_python+0x15c>
     284:      	ldr	w8, [x25]
     288:      	mov	x24, x12
     28c:      	str	w10, [sp, #0x30]
     290:      	str	x22, [sp, #0x18]
     294:      	cbnz	w8, 0x1208 <perf_unwind_python+0x1208>
     298:      	mov	w8, #0x1c               // =28
     29c:      	adrp	x0, 0x0 <perf_unwind_python>
     2a0:      	add	x9, sp, #0x88
     2a4:      	str	w8, [sp, #0x88]
     2a8:      	mov	w8, #0x1                // =1
     2ac:      	add	x1, sp, #0x88
     2b0:      	ldr	x0, [x0]
     2b4:      	blr	x8
     2b8:      	ldr	x22, [sp, #0x20]
     2bc:      	cbz	x0, 0x398 <perf_unwind_python+0x398>
     2c0:      	ldr	x8, [x0]
     2c4:      	add	x8, x8, #0x1
     2c8:      	str	x8, [x0]
     2cc:      	mov	x11, x24
     2d0:      	mov	x12, xzr
     2d4:      	mov	x29, #-0x2              // =-2
     2d8:      	ldr	w8, [x25]
     2dc:      	cbz	w8, 0x3b4 <perf_unwind_python+0x3b4>
     2e0:      	adrp	x8, 0x0 <perf_unwind_python>
     2e4:      	add	x8, x8, #0x0
     2e8:      	add	x0, sp, #0x40
     2ec:      	ldp	x9, x10, [x8]
     2f0:      	ldr	x8, [x8, #0x10]
     2f4:      	mov	w1, #0x18               // =24
     2f8:      	mov	x2, x12
     2fc:      	mov	x3, x29
     300:      	stp	x9, x10, [sp, #0x40]
     304:      	str	x8, [sp, #0x50]
     308:      	mov	w8, #0x18               // =24
     30c:      	mov	w9, #0x6                // =6
     310:      	add	x10, sp, #0x40
     314:      	mov	x24, x12
     318:      	str	x11, [sp, #0x10]
     31c:      	blr	x9
     320:      	ldr	x11, [sp, #0x10]
     324:      	mov	x12, x24
     328:      	ldr	w8, [x21, #0x2c0]
     32c:      	cmp	w8, #0x7f
     330:      	b.hs	0x3c0 <perf_unwind_python+0x3c0>
     334:      	add	w9, w8, #0x1
     338:      	mov	w10, #0x1               // =1
     33c:      	adrp	x0, 0x0 <perf_unwind_python>
     340:      	str	w9, [x21, #0x2c0]
     344:      	mov	w9, #0x18               // =24
     348:      	add	x1, sp, #0x88
     34c:      	mov	x24, x11
     350:      	umaddl	x8, w8, w9, x21
     354:      	str	x12, [x8, #0x2d0]
     358:      	str	x29, [x8, #0x2d8]
     35c:      	add	x9, x8, #0x2d0
     360:      	strb	w10, [x8, #0x2e0]
     364:      	str	wzr, [x8, #0x2e4]
     368:      	mov	w8, #0x16               // =22
     36c:      	stur	wzr, [x9, #0x11]
     370:      	str	w8, [sp, #0x88]
     374:      	add	x8, sp, #0x88
     378:      	ldr	x0, [x0]
     37c:      	blr	x10
     380:      	cbz	x0, 0x488 <perf_unwind_python+0x488>
     384:      	ldr	x8, [x0]
     388:      	add	x8, x8, #0x1
     38c:      	str	x8, [x0]
     390:      	ldr	x8, [sp, #0x28]
     394:      	b	0x494 <perf_unwind_python+0x494>
     398:      	ldr	w8, [x25]
     39c:      	mov	x11, x24
     3a0:      	cbnz	w8, 0x135c <perf_unwind_python+0x135c>
     3a4:      	mov	x12, xzr
     3a8:      	mov	x29, #-0x2              // =-2
     3ac:      	ldr	w8, [x25]
     3b0:      	cbnz	w8, 0x2e0 <perf_unwind_python+0x2e0>
     3b4:      	ldr	w8, [x21, #0x2c0]
     3b8:      	cmp	w8, #0x7f
     3bc:      	b.lo	0x334 <perf_unwind_python+0x334>
     3c0:      	mov	x29, x11
     3c4:      	ldr	w8, [x25]
     3c8:      	cbnz	w8, 0x12d8 <perf_unwind_python+0x12d8>
     3cc:      	mov	w8, #0x2                // =2
     3d0:      	adrp	x0, 0x0 <perf_unwind_python>
     3d4:      	add	x9, sp, #0x88
     3d8:      	str	w8, [sp, #0x88]
     3dc:      	mov	w8, #0x1                // =1
     3e0:      	add	x1, sp, #0x88
     3e4:      	ldr	x0, [x0]
     3e8:      	blr	x8
     3ec:      	cbz	x0, 0x478 <perf_unwind_python+0x478>
     3f0:      	ldr	x8, [x0]
     3f4:      	add	x8, x8, #0x1
     3f8:      	str	x8, [x0]
     3fc:      	ldr	w8, [x25]
     400:      	cbz	w8, 0x480 <perf_unwind_python+0x480>
     404:      	adrp	x8, 0x0 <perf_unwind_python>
     408:      	add	x8, x8, #0x0
     40c:      	add	x0, sp, #0x40
     410:      	ldp	x9, x10, [x8]
     414:      	mov	w1, #0x1d               // =29
     418:      	stp	x9, x10, [sp, #0x40]
     41c:      	ldr	x9, [x8, #0x10]
     420:      	ldur	x8, [x8, #0x15]
     424:      	add	x10, sp, #0x40
     428:      	str	x9, [sp, #0x50]
     42c:      	stur	x8, [sp, #0x55]
     430:      	mov	w8, #0x1d               // =29
     434:      	mov	w9, #0x6                // =6
     438:      	blr	x9
     43c:      	mov	w8, wzr
     440:      	mov	w9, #0x2                // =2
     444:      	b	0x15c <perf_unwind_python+0x15c>
     448:      	adrp	x8, 0x0 <perf_unwind_python>
     44c:      	add	x8, x8, #0x0
     450:      	strb	wzr, [sp, #0x50]
     454:      	add	x10, sp, #0x40
     458:      	ldp	x9, x8, [x8]
     45c:      	add	x0, sp, #0x40
     460:      	mov	w1, #0x11               // =17
     464:      	stp	x9, x8, [sp, #0x40]
     468:      	mov	w8, #0x11               // =17
     46c:      	mov	w9, #0x6                // =6
     470:      	blr	x9
     474:      	b	0x5c <perf_unwind_python+0x5c>
     478:      	ldr	w8, [x25]
     47c:      	cbnz	w8, 0x1404 <perf_unwind_python+0x1404>
     480:      	mov	w9, #0x2                // =2
     484:      	b	0x15c <perf_unwind_python+0x15c>
     488:      	ldr	w9, [x25]
     48c:      	ldr	x8, [sp, #0x28]
     490:      	cbnz	w9, 0x1454 <perf_unwind_python+0x1454>
     494:      	ldr	w9, [sp, #0x30]
     498:      	mov	x12, x24
     49c:      	cbnz	w9, 0x1ac <perf_unwind_python+0x1ac>
     4a0:      	cbz	x12, 0xb18 <perf_unwind_python+0xb18>
     4a4:      	ldrb	w9, [x8, #0x19]
     4a8:      	cmp	w9, #0x78
     4ac:      	b.hi	0x4bc <perf_unwind_python+0x4bc>
     4b0:      	ldrb	w9, [x8, #0x18]
     4b4:      	cmp	w9, #0x78
     4b8:      	b.ls	0xbfc <perf_unwind_python+0xbfc>
     4bc:      	mov	w8, wzr
     4c0:      	mov	w9, #0x1                // =1
     4c4:      	mov	x29, x12
     4c8:      	b	0x15c <perf_unwind_python+0x15c>
     4cc:      	adrp	x8, 0x0 <perf_unwind_python>
     4d0:      	add	x8, x8, #0x0
     4d4:      	mov	x22, x0
     4d8:      	ldp	x9, x10, [x8]
     4dc:      	mov	w1, #0x20               // =32
     4e0:      	stp	x9, x10, [sp, #0x40]
     4e4:      	ldp	x9, x8, [x8, #0x10]
     4e8:      	add	x10, sp, #0x40
     4ec:      	stp	x9, x8, [sp, #0x50]
     4f0:      	mov	w8, #0x20               // =32
     4f4:      	mov	w9, #0x6                // =6
     4f8:      	ldrh	w2, [x0, #0x10]
     4fc:      	add	x0, sp, #0x40
     500:      	blr	x9
     504:      	mov	x0, x22
     508:      	ldr	x29, [x21, #0xf48]
     50c:      	add	x22, x21, #0xf48
     510:      	cbnz	x29, 0x8c <perf_unwind_python+0x8c>
     514:      	mov	w8, #0x15               // =21
     518:      	adrp	x23, 0x0 <perf_unwind_python>
     51c:      	add	x9, sp, #0x88
     520:      	str	w8, [sp, #0x88]
     524:      	mov	w8, #0x1                // =1
     528:      	mov	x29, x0
     52c:      	add	x1, sp, #0x88
     530:      	ldr	x23, [x23]
     534:      	mov	x0, x23
     538:      	blr	x8
     53c:      	cbz	x0, 0x550 <perf_unwind_python+0x550>
     540:      	ldr	x8, [x0]
     544:      	add	x8, x8, #0x1
     548:      	str	x8, [x0]
     54c:      	b	0x558 <perf_unwind_python+0x558>
     550:      	ldr	w8, [x25]
     554:      	cbnz	w8, 0xcac <perf_unwind_python+0xcac>
     558:      	mov	w8, #0x23               // =35
     55c:      	blr	x8
     560:      	adrp	x8, 0x0 <perf_unwind_python>
     564:      	mov	w9, #0x71               // =113
     568:      	add	x10, sp, #0x80
     56c:      	ldr	x8, [x8]
     570:      	mov	w1, #0x8                // =8
     574:      	ldr	x8, [x8]
     578:      	add	x2, x0, x8
     57c:      	mov	w8, #0x8                // =8
     580:      	add	x0, sp, #0x80
     584:      	blr	x9
     588:      	ldr	w8, [x25]
     58c:      	cbz	x0, 0x5fc <perf_unwind_python+0x5fc>
     590:      	cbnz	w8, 0xb78 <perf_unwind_python+0xb78>
     594:      	mov	w8, #0x4                // =4
     598:      	add	x9, sp, #0x88
     59c:      	add	x1, sp, #0x88
     5a0:      	str	w8, [sp, #0x88]
     5a4:      	mov	w8, #0x1                // =1
     5a8:      	mov	x0, x23
     5ac:      	blr	x8
     5b0:      	cbz	x0, 0x67c <perf_unwind_python+0x67c>
     5b4:      	ldr	x8, [x0]
     5b8:      	add	x8, x8, #0x1
     5bc:      	str	x8, [x0]
     5c0:      	ldr	w8, [x25]
     5c4:      	cbz	w8, 0x684 <perf_unwind_python+0x684>
     5c8:      	adrp	x8, 0x0 <perf_unwind_python>
     5cc:      	add	x8, x8, #0x0
     5d0:      	add	x0, sp, #0x40
     5d4:      	ldp	x9, x10, [x8]
     5d8:      	mov	w1, #0x20               // =32
     5dc:      	stp	x9, x10, [sp, #0x40]
     5e0:      	ldp	x9, x8, [x8, #0x10]
     5e4:      	add	x10, sp, #0x40
     5e8:      	stp	x9, x8, [sp, #0x50]
     5ec:      	mov	w8, #0x20               // =32
     5f0:      	mov	w9, #0x6                // =6
     5f4:      	blr	x9
     5f8:      	b	0x684 <perf_unwind_python+0x684>
     5fc:      	str	x19, [sp, #0x30]
     600:      	mov	x19, x25
     604:      	mov	x25, x22
     608:      	cbnz	w8, 0xcf4 <perf_unwind_python+0xcf4>
     60c:      	ldr	x24, [x29]
     610:      	ldr	x22, [sp, #0x80]
     614:      	mov	w8, #0x4                // =4
     618:      	mov	w9, #0x70               // =112
     61c:      	add	x10, sp, #0x98
     620:      	add	x0, sp, #0x98
     624:      	mov	w1, #0x4                // =4
     628:      	mov	x2, x24
     62c:      	blr	x9
     630:      	cbz	x0, 0x7a8 <perf_unwind_python+0x7a8>
     634:      	ldr	w8, [x19]
     638:      	mov	x25, x19
     63c:      	cbnz	w8, 0xd80 <perf_unwind_python+0xd80>
     640:      	mov	w8, #0x46               // =70
     644:      	add	x9, sp, #0x88
     648:      	add	x1, sp, #0x88
     64c:      	str	w8, [sp, #0x88]
     650:      	mov	w8, #0x1                // =1
     654:      	mov	x0, x23
     658:      	blr	x8
     65c:      	ldr	x19, [sp, #0x30]
     660:      	cbz	x0, 0x85c <perf_unwind_python+0x85c>
     664:      	ldr	x8, [x0]
     668:      	mov	w23, #0x1               // =1
     66c:      	add	x8, x8, #0x1
     670:      	str	x8, [x0]
     674:      	mov	w8, #0x7d7              // =2007
     678:      	b	0x6c4 <perf_unwind_python+0x6c4>
     67c:      	ldr	w8, [x25]
     680:      	cbnz	w8, 0xdc0 <perf_unwind_python+0xdc0>
     684:      	mov	w8, #0x48               // =72
     688:      	add	x9, sp, #0x88
     68c:      	add	x1, sp, #0x88
     690:      	str	w8, [sp, #0x88]
     694:      	mov	w8, #0x1                // =1
     698:      	mov	x0, x23
     69c:      	blr	x8
     6a0:      	cbz	x0, 0x6b4 <perf_unwind_python+0x6b4>
     6a4:      	ldr	x8, [x0]
     6a8:      	add	x8, x8, #0x1
     6ac:      	str	x8, [x0]
     6b0:      	b	0x6bc <perf_unwind_python+0x6bc>
     6b4:      	ldr	w8, [x25]
     6b8:      	cbnz	w8, 0xe10 <perf_unwind_python+0xe10>
     6bc:      	mov	w8, #0x7d8              // =2008
     6c0:      	mov	w23, #0x1               // =1
     6c4:      	str	w8, [x21, #0xf1c]
     6c8:      	str	wzr, [sp, #0x40]
     6cc:      	mov	w8, #0x1                // =1
     6d0:      	add	x9, sp, #0x40
     6d4:      	add	x1, sp, #0x40
     6d8:      	mov	x0, x20
     6dc:      	blr	x8
     6e0:      	cbz	x0, 0x734 <perf_unwind_python+0x734>
     6e4:      	mov	w20, #0x1374            // =4980
     6e8:      	ldrb	w8, [x0, x20]
     6ec:      	cmp	w8, #0x1d
     6f0:      	b.lo	0x764 <perf_unwind_python+0x764>
     6f4:      	mov	w8, #0x5                // =5
     6f8:      	mov	x21, x0
     6fc:      	add	x9, sp, #0x88
     700:      	str	w8, [x0, #0xf1c]
     704:      	mov	w8, #0x44               // =68
     708:      	adrp	x0, 0x0 <perf_unwind_python>
     70c:      	add	x1, sp, #0x88
     710:      	str	w8, [sp, #0x88]
     714:      	mov	w8, #0x1                // =1
     718:      	ldr	x0, [x0]
     71c:      	blr	x8
     720:      	cbz	x0, 0x750 <perf_unwind_python+0x750>
     724:      	ldr	x8, [x0]
     728:      	add	x8, x8, #0x1
     72c:      	str	x8, [x0]
     730:      	b	0x758 <perf_unwind_python+0x758>
     734:      	adrp	x1, 0x0 <perf_unwind_python>
     738:      	mov	x8, xzr
     73c:      	mov	w9, #0xc                // =12
     740:      	ldr	x1, [x1]
     744:      	mov	x0, x19
     748:      	mov	w2, wzr
     74c:      	b	0x784 <perf_unwind_python+0x784>
     750:      	ldr	w8, [x25]
     754:      	cbnz	w8, 0xd38 <perf_unwind_python+0xd38>
     758:      	ldrb	w8, [x21, x20]
     75c:      	mov	w23, wzr
     760:      	mov	x0, x21
     764:      	add	w8, w8, #0x1
     768:      	adrp	x1, 0x0 <perf_unwind_python>
     76c:      	mov	w9, #0xc                // =12
     770:      	strb	w8, [x0, x20]
     774:      	mov	w8, w23
     778:      	mov	x0, x19
     77c:      	mov	w2, w23
     780:      	ldr	x1, [x1]
     784:      	blr	x9
     788:      	mov	w0, #-0x1               // =-1
     78c:      	ldp	x20, x19, [sp, #0xd0]
     790:      	ldr	x29, [sp, #0x90]
     794:      	ldp	x22, x21, [sp, #0xc0]
     798:      	ldp	x24, x23, [sp, #0xb0]
     79c:      	ldp	x30, x25, [sp, #0xa0]
     7a0:      	add	sp, sp, #0xe0
     7a4:      	ret
     7a8:      	ldrsh	x8, [x29, #0x12]
     7ac:      	ldrsw	x24, [sp, #0x98]
     7b0:      	add	x8, x22, x8
     7b4:      	ldrb	w10, [x29, #0x15]
     7b8:      	str	x8, [sp, #0x88]
     7bc:      	cbz	w10, 0x7e4 <perf_unwind_python+0x7e4>
     7c0:      	mov	w9, #0x8                // =8
     7c4:      	mov	w10, #0x70              // =112
     7c8:      	add	x11, sp, #0x88
     7cc:      	ldr	x2, [sp, #0x88]
     7d0:      	add	x0, sp, #0x88
     7d4:      	mov	w1, #0x8                // =8
     7d8:      	blr	x10
     7dc:      	cbnz	x0, 0x81c <perf_unwind_python+0x81c>
     7e0:      	ldr	x8, [sp, #0x88]
     7e4:      	mov	x9, x29
     7e8:      	ldrb	w9, [x29, #0x14]
     7ec:      	smaddl	x8, w24, w9, x8
     7f0:      	ldr	w9, [x19]
     7f4:      	str	x8, [sp, #0x88]
     7f8:      	cbnz	w9, 0xee0 <perf_unwind_python+0xee0>
     7fc:      	mov	w9, #0x8                // =8
     800:      	mov	w10, #0x70              // =112
     804:      	add	x11, sp, #0x78
     808:      	ldr	x2, [sp, #0x88]
     80c:      	add	x0, sp, #0x78
     810:      	mov	w1, #0x8                // =8
     814:      	blr	x10
     818:      	cbz	x0, 0x8bc <perf_unwind_python+0x8bc>
     81c:      	ldr	w8, [x19]
     820:      	mov	x25, x19
     824:      	cbnz	w8, 0xe58 <perf_unwind_python+0xe58>
     828:      	mov	w8, #0x3                // =3
     82c:      	add	x9, sp, #0x9c
     830:      	add	x1, sp, #0x9c
     834:      	str	w8, [sp, #0x9c]
     838:      	mov	w8, #0x1                // =1
     83c:      	mov	x0, x23
     840:      	blr	x8
     844:      	ldr	x19, [sp, #0x30]
     848:      	cbz	x0, 0x86c <perf_unwind_python+0x86c>
     84c:      	ldr	x8, [x0]
     850:      	add	x8, x8, #0x1
     854:      	str	x8, [x0]
     858:      	b	0x874 <perf_unwind_python+0x874>
     85c:      	ldr	w8, [x25]
     860:      	cbnz	w8, 0xe98 <perf_unwind_python+0xe98>
     864:      	mov	w8, #0x7d7              // =2007
     868:      	b	0x6c0 <perf_unwind_python+0x6c0>
     86c:      	ldr	w8, [x25]
     870:      	cbnz	w8, 0xf68 <perf_unwind_python+0xf68>
     874:      	mov	w8, #0x47               // =71
     878:      	add	x9, sp, #0x88
     87c:      	add	x1, sp, #0x88
     880:      	str	w8, [sp, #0x88]
     884:      	mov	w8, #0x1                // =1
     888:      	mov	x0, x23
     88c:      	blr	x8
     890:      	cbz	x0, 0x8ac <perf_unwind_python+0x8ac>
     894:      	ldr	x8, [x0]
     898:      	mov	w23, #0x1               // =1
     89c:      	add	x8, x8, #0x1
     8a0:      	str	x8, [x0]
     8a4:      	mov	w8, #0x7d4              // =2004
     8a8:      	b	0x6c4 <perf_unwind_python+0x6c4>
     8ac:      	ldr	w8, [x25]
     8b0:      	cbnz	w8, 0xfb0 <perf_unwind_python+0xfb0>
     8b4:      	mov	w8, #0x7d4              // =2004
     8b8:      	b	0x6c0 <perf_unwind_python+0x6c0>
     8bc:      	ldr	x8, [sp, #0x78]
     8c0:      	cbz	x8, 0x93c <perf_unwind_python+0x93c>
     8c4:      	ldrb	w10, [x29, #0x16]
     8c8:      	mov	w11, #0x70              // =112
     8cc:      	mov	x0, x25
     8d0:      	mov	w1, #0x8                // =8
     8d4:      	mov	x22, x25
     8d8:      	add	x8, x8, x10
     8dc:      	mov	w10, #0x8               // =8
     8e0:      	ldr	x8, [sp, #0x78]
     8e4:      	ldrb	w9, [x29, #0x16]
     8e8:      	add	x2, x8, x9
     8ec:      	blr	x11
     8f0:      	cbz	x0, 0x984 <perf_unwind_python+0x984>
     8f4:      	ldr	w8, [x19]
     8f8:      	mov	x25, x19
     8fc:      	cbnz	w8, 0x109c <perf_unwind_python+0x109c>
     900:      	mov	w8, #0x19               // =25
     904:      	add	x9, sp, #0x88
     908:      	add	x1, sp, #0x88
     90c:      	str	w8, [sp, #0x88]
     910:      	mov	w8, #0x1                // =1
     914:      	mov	x0, x23
     918:      	blr	x8
     91c:      	ldr	x19, [sp, #0x30]
     920:      	cbz	x0, 0xa08 <perf_unwind_python+0xa08>
     924:      	ldr	x8, [x0]
     928:      	mov	w23, #0x1               // =1
     92c:      	add	x8, x8, #0x1
     930:      	str	x8, [x0]
     934:      	mov	w8, #0x7d6              // =2006
     938:      	b	0x6c4 <perf_unwind_python+0x6c4>
     93c:      	ldr	w8, [x19]
     940:      	mov	x25, x19
     944:      	cbnz	w8, 0x11d4 <perf_unwind_python+0x11d4>
     948:      	mov	w8, #0x18               // =24
     94c:      	add	x9, sp, #0x88
     950:      	add	x1, sp, #0x88
     954:      	str	w8, [sp, #0x88]
     958:      	mov	w8, #0x1                // =1
     95c:      	mov	x0, x23
     960:      	blr	x8
     964:      	ldr	x19, [sp, #0x30]
     968:      	cbz	x0, 0xa44 <perf_unwind_python+0xa44>
     96c:      	ldr	x8, [x0]
     970:      	mov	w23, #0x1               // =1
     974:      	add	x8, x8, #0x1
     978:      	str	x8, [x0]
     97c:      	mov	w8, #0x7d5              // =2005
     980:      	b	0x6c4 <perf_unwind_python+0x6c4>
     984:      	ldrb	w8, [x29, #0x23]
     988:      	mov	x0, x29
     98c:      	mov	x25, x19
     990:      	cbz	w8, 0xa18 <perf_unwind_python+0xa18>
     994:      	ldr	x8, [x22]
     998:      	ldrb	w9, [x0, #0x17]
     99c:      	mov	w10, #0x70              // =112
     9a0:      	mov	w1, #0x8                // =8
     9a4:      	add	x8, x8, x9
     9a8:      	mov	w9, #0x8                // =8
     9ac:      	ldr	x8, [x22]
     9b0:      	ldrb	w9, [x0, #0x17]
     9b4:      	mov	x0, x22
     9b8:      	add	x2, x8, x9
     9bc:      	blr	x10
     9c0:      	mov	x8, x0
     9c4:      	mov	x0, x29
     9c8:      	cbz	x8, 0xa18 <perf_unwind_python+0xa18>
     9cc:      	ldr	w8, [x25]
     9d0:      	ldr	x19, [sp, #0x30]
     9d4:      	cbnz	w8, 0x13b8 <perf_unwind_python+0x13b8>
     9d8:      	mov	w8, #0x43               // =67
     9dc:      	add	x9, sp, #0x88
     9e0:      	add	x1, sp, #0x88
     9e4:      	str	w8, [sp, #0x88]
     9e8:      	mov	w8, #0x1                // =1
     9ec:      	mov	x0, x23
     9f0:      	blr	x8
     9f4:      	cbz	x0, 0xa54 <perf_unwind_python+0xa54>
     9f8:      	ldr	x8, [x0]
     9fc:      	add	x8, x8, #0x1
     a00:      	str	x8, [x0]
     a04:      	b	0xa5c <perf_unwind_python+0xa5c>
     a08:      	ldr	w8, [x25]
     a0c:      	cbnz	w8, 0x125c <perf_unwind_python+0x125c>
     a10:      	mov	w8, #0x7d6              // =2006
     a14:      	b	0x6c0 <perf_unwind_python+0x6c0>
     a18:      	ldr	x29, [x22]
     a1c:      	ldr	x19, [sp, #0x30]
     a20:      	cbnz	x29, 0x8c <perf_unwind_python+0x8c>
     a24:      	ldr	w8, [x25]
     a28:      	cbnz	w8, 0x149c <perf_unwind_python+0x149c>
     a2c:      	ldr	w9, [x21, #0x1370]
     a30:      	mov	w8, wzr
     a34:      	mov	w23, #0x1               // =1
     a38:      	orr	w9, w9, #0x10
     a3c:      	str	w9, [x21, #0x1370]
     a40:      	b	0x6c4 <perf_unwind_python+0x6c4>
     a44:      	ldr	w8, [x25]
     a48:      	cbnz	w8, 0x1314 <perf_unwind_python+0x1314>
     a4c:      	mov	w8, #0x7d5              // =2005
     a50:      	b	0x6c0 <perf_unwind_python+0x6c0>
     a54:      	ldr	w8, [x25]
     a58:      	cbnz	w8, 0x14d0 <perf_unwind_python+0x14d0>
     a5c:      	mov	w8, #0x7d3              // =2003
     a60:      	b	0x6c0 <perf_unwind_python+0x6c0>
     a64:      	str	w10, [sp, #0x30]
     a68:      	str	x12, [sp, #0x10]
     a6c:      	mov	w8, #0xc0               // =192
     a70:      	mov	w9, #0x70               // =112
     a74:      	mov	x0, x22
     a78:      	mov	w1, #0xc0               // =192
     a7c:      	str	x2, [sp, #0x8]
     a80:      	blr	x9
     a84:      	cbz	x0, 0xb28 <perf_unwind_python+0xb28>
     a88:      	str	x19, [sp, #0x30]
     a8c:      	ldr	x29, [sp, #0x10]
     a90:      	ldr	w8, [x25]
     a94:      	mov	x19, x25
     a98:      	cbnz	w8, 0x1518 <perf_unwind_python+0x1518>
     a9c:      	mov	w8, #0x1e               // =30
     aa0:      	adrp	x0, 0x0 <perf_unwind_python>
     aa4:      	add	x9, sp, #0x88
     aa8:      	str	w8, [sp, #0x88]
     aac:      	mov	w8, #0x1                // =1
     ab0:      	add	x1, sp, #0x88
     ab4:      	ldr	x0, [x0]
     ab8:      	blr	x8
     abc:      	cbz	x0, 0xc8c <perf_unwind_python+0xc8c>
     ac0:      	ldr	x8, [x0]
     ac4:      	add	x8, x8, #0x1
     ac8:      	str	x8, [x0]
     acc:      	b	0xc94 <perf_unwind_python+0xc94>
     ad0:      	mov	w8, #0x6f66             // =28518
     ad4:      	add	x0, sp, #0x40
     ad8:      	mov	w1, #0x2b               // =43
     adc:      	movk	w8, #0xa, lsl #16
     ae0:      	stur	w8, [sp, #0x67]
     ae4:      	adrp	x8, 0x0 <perf_unwind_python>
     ae8:      	add	x8, x8, #0x0
     aec:      	ldp	x9, x10, [x8, #0x10]
     af0:      	stp	x9, x10, [sp, #0x50]
     af4:      	ldr	x9, [x8, #0x20]
     af8:      	add	x10, sp, #0x40
     afc:      	str	x9, [sp, #0x60]
     b00:      	ldp	x8, x9, [x8]
     b04:      	stp	x8, x9, [sp, #0x40]
     b08:      	mov	w8, #0x2b               // =43
     b0c:      	mov	w9, #0x6                // =6
     b10:      	blr	x9
     b14:      	b	0x11c <perf_unwind_python+0x11c>
     b18:      	mov	w8, wzr
     b1c:      	mov	x29, xzr
     b20:      	mov	w9, wzr
     b24:      	b	0x15c <perf_unwind_python+0x15c>
     b28:      	ldr	x8, [sp, #0x28]
     b2c:      	str	x22, [sp, #0x18]
     b30:      	ldrb	w10, [x8, #0x1e]
     b34:      	ldrb	w9, [x8, #0x1d]
     b38:      	ldrb	w11, [x8, #0x1f]
     b3c:      	ldrb	w8, [x8, #0x20]
     b40:      	ldr	w10, [x22, x10]
     b44:      	ldr	w9, [x22, x9]
     b48:      	ldr	w11, [x22, x11]
     b4c:      	ldr	w8, [x22, x8]
     b50:      	ldr	x22, [sp, #0x20]
     b54:      	lsl	w10, w10, #18
     b58:      	add	w9, w10, w9, lsl #25
     b5c:      	add	w9, w9, w11, lsl #10
     b60:      	add	w8, w9, w8
     b64:      	ldp	x12, x11, [sp, #0x8]
     b68:      	orr	x29, x8, x24, lsl #32
     b6c:      	ldr	w8, [x25]
     b70:      	cbz	w8, 0x3b4 <perf_unwind_python+0x3b4>
     b74:      	b	0x2e0 <perf_unwind_python+0x2e0>
     b78:      	adrp	x8, 0x0 <perf_unwind_python>
     b7c:      	add	x8, x8, #0x0
     b80:      	add	x0, sp, #0x40
     b84:      	ldp	x9, x10, [x8]
     b88:      	mov	w1, #0x1d               // =29
     b8c:      	stp	x9, x10, [sp, #0x40]
     b90:      	ldr	x9, [x8, #0x10]
     b94:      	ldur	x8, [x8, #0x15]
     b98:      	add	x10, sp, #0x40
     b9c:      	str	x9, [sp, #0x50]
     ba0:      	stur	x8, [sp, #0x55]
     ba4:      	mov	w8, #0x1d               // =29
     ba8:      	mov	w9, #0x6                // =6
     bac:      	blr	x9
     bb0:      	b	0x594 <perf_unwind_python+0x594>
     bb4:      	adrp	x8, 0x0 <perf_unwind_python>
     bb8:      	add	x8, x8, #0x0
     bbc:      	add	x0, sp, #0x40
     bc0:      	ldp	x9, x10, [x8, #0x10]
     bc4:      	mov	w1, #0x2e               // =46
     bc8:      	stp	x9, x10, [sp, #0x50]
     bcc:      	ldr	x9, [x8, #0x20]
     bd0:      	add	x10, sp, #0x40
     bd4:      	str	x9, [sp, #0x60]
     bd8:      	ldur	x9, [x8, #0x26]
     bdc:      	stur	x9, [sp, #0x66]
     be0:      	ldp	x9, x8, [x8]
     be4:      	stp	x9, x8, [sp, #0x40]
     be8:      	mov	w8, #0x2e               // =46
     bec:      	mov	w9, #0x6                // =6
     bf0:      	ldr	w2, [sp, #0x88]
     bf4:      	blr	x9
     bf8:      	b	0x180 <perf_unwind_python+0x180>
     bfc:      	ldrb	w8, [x8, #0x1a]
     c00:      	str	x19, [sp, #0x30]
     c04:      	cmp	w8, #0x78
     c08:      	b.hi	0x3798 <perf_unwind_python+0x3798>
     c0c:      	ldr	x8, [sp, #0x28]
     c10:      	ldrsb	w8, [x8, #0x1b]
     c14:      	tbnz	w8, #0x1f, 0x3798 <perf_unwind_python+0x3798>
     c18:      	mov	w8, #0x80               // =128
     c1c:      	mov	w9, #0x70               // =112
     c20:      	mov	x2, x24
     c24:      	mov	x0, x23
     c28:      	mov	w1, #0x80               // =128
     c2c:      	blr	x9
     c30:      	cbz	x0, 0xf2c <perf_unwind_python+0xf2c>
     c34:      	mov	x29, x24
     c38:      	ldr	x22, [sp, #0x20]
     c3c:      	ldr	x19, [sp, #0x30]
     c40:      	ldr	w8, [x25]
     c44:      	cbz	w8, 0xe4 <perf_unwind_python+0xe4>
     c48:      	mov	w8, #0x786c             // =30828
     c4c:      	add	x0, sp, #0x40
     c50:      	mov	w1, #0x24               // =36
     c54:      	mov	x2, x29
     c58:      	movk	w8, #0xa, lsl #16
     c5c:      	str	w8, [sp, #0x60]
     c60:      	adrp	x8, 0x0 <perf_unwind_python>
     c64:      	add	x8, x8, #0x0
     c68:      	ldp	x9, x10, [x8]
     c6c:      	stp	x9, x10, [sp, #0x40]
     c70:      	ldp	x9, x8, [x8, #0x10]
     c74:      	add	x10, sp, #0x40
     c78:      	stp	x9, x8, [sp, #0x50]
     c7c:      	mov	w8, #0x24               // =36
     c80:      	mov	w9, #0x6                // =6
     c84:      	blr	x9
     c88:      	b	0xe4 <perf_unwind_python+0xe4>
     c8c:      	ldr	w8, [x19]
     c90:      	cbnz	w8, 0x1558 <perf_unwind_python+0x1558>
     c94:      	ldr	x22, [sp, #0x20]
     c98:      	mov	x25, x19
     c9c:      	ldr	x19, [sp, #0x30]
     ca0:      	mov	w8, wzr
     ca4:      	mov	w9, #0x7d0              // =2000
     ca8:      	b	0x15c <perf_unwind_python+0x15c>
     cac:      	adrp	x8, 0x0 <perf_unwind_python>
     cb0:      	add	x8, x8, #0x0
     cb4:      	add	x0, sp, #0x40
     cb8:      	ldp	x9, x10, [x8, #0x10]
     cbc:      	mov	w1, #0x2e               // =46
     cc0:      	stp	x9, x10, [sp, #0x50]
     cc4:      	ldr	x9, [x8, #0x20]
     cc8:      	add	x10, sp, #0x40
     ccc:      	str	x9, [sp, #0x60]
     cd0:      	ldur	x9, [x8, #0x26]
     cd4:      	stur	x9, [sp, #0x66]
     cd8:      	ldp	x9, x8, [x8]
     cdc:      	stp	x9, x8, [sp, #0x40]
     ce0:      	mov	w8, #0x2e               // =46
     ce4:      	mov	w9, #0x6                // =6
     ce8:      	ldr	w2, [sp, #0x88]
     cec:      	blr	x9
     cf0:      	b	0x558 <perf_unwind_python+0x558>
     cf4:      	adrp	x8, 0x0 <perf_unwind_python>
     cf8:      	add	x8, x8, #0x0
     cfc:      	add	x0, sp, #0x40
     d00:      	ldp	x9, x10, [x8, #0x10]
     d04:      	mov	w1, #0x26               // =38
     d08:      	stp	x9, x10, [sp, #0x50]
     d0c:      	ldur	x9, [x8, #0x1e]
     d10:      	add	x10, sp, #0x40
     d14:      	stur	x9, [sp, #0x5e]
     d18:      	ldp	x8, x9, [x8]
     d1c:      	stp	x8, x9, [sp, #0x40]
     d20:      	mov	w8, #0x26               // =38
     d24:      	mov	w9, #0x6                // =6
     d28:      	ldr	x2, [sp, #0x80]
     d2c:      	ldr	x3, [x29]
     d30:      	blr	x9
     d34:      	b	0x60c <perf_unwind_python+0x60c>
     d38:      	adrp	x8, 0x0 <perf_unwind_python>
     d3c:      	add	x8, x8, #0x0
     d40:      	add	x0, sp, #0x40
     d44:      	ldp	x9, x10, [x8, #0x10]
     d48:      	mov	w1, #0x2e               // =46
     d4c:      	stp	x9, x10, [sp, #0x50]
     d50:      	ldr	x9, [x8, #0x20]
     d54:      	add	x10, sp, #0x40
     d58:      	str	x9, [sp, #0x60]
     d5c:      	ldur	x9, [x8, #0x26]
     d60:      	stur	x9, [sp, #0x66]
     d64:      	ldp	x9, x8, [x8]
     d68:      	stp	x9, x8, [sp, #0x40]
     d6c:      	mov	w8, #0x2e               // =46
     d70:      	mov	w9, #0x6                // =6
     d74:      	ldr	w2, [sp, #0x88]
     d78:      	blr	x9
     d7c:      	b	0x758 <perf_unwind_python+0x758>
     d80:      	adrp	x8, 0x0 <perf_unwind_python>
     d84:      	add	x8, x8, #0x0
     d88:      	add	x0, sp, #0x40
     d8c:      	ldp	x9, x10, [x8, #0x10]
     d90:      	mov	w1, #0x26               // =38
     d94:      	mov	x2, x24
     d98:      	stp	x9, x10, [sp, #0x50]
     d9c:      	ldur	x9, [x8, #0x1e]
     da0:      	add	x10, sp, #0x40
     da4:      	stur	x9, [sp, #0x5e]
     da8:      	ldp	x8, x9, [x8]
     dac:      	stp	x8, x9, [sp, #0x40]
     db0:      	mov	w8, #0x26               // =38
     db4:      	mov	w9, #0x6                // =6
     db8:      	blr	x9
     dbc:      	b	0x640 <perf_unwind_python+0x640>
     dc0:      	adrp	x8, 0x0 <perf_unwind_python>
     dc4:      	add	x8, x8, #0x0
     dc8:      	add	x0, sp, #0x40
     dcc:      	ldp	x9, x10, [x8, #0x10]
     dd0:      	mov	w1, #0x2e               // =46
     dd4:      	stp	x9, x10, [sp, #0x50]
     dd8:      	ldr	x9, [x8, #0x20]
     ddc:      	add	x10, sp, #0x40
     de0:      	str	x9, [sp, #0x60]
     de4:      	ldur	x9, [x8, #0x26]
     de8:      	stur	x9, [sp, #0x66]
     dec:      	ldp	x9, x8, [x8]
     df0:      	stp	x9, x8, [sp, #0x40]
     df4:      	mov	w8, #0x2e               // =46
     df8:      	mov	w9, #0x6                // =6
     dfc:      	ldr	w2, [sp, #0x88]
     e00:      	blr	x9
     e04:      	ldr	w8, [x25]
     e08:      	cbz	w8, 0x684 <perf_unwind_python+0x684>
     e0c:      	b	0x5c8 <perf_unwind_python+0x5c8>
     e10:      	adrp	x8, 0x0 <perf_unwind_python>
     e14:      	add	x8, x8, #0x0
     e18:      	add	x0, sp, #0x40
     e1c:      	ldp	x9, x10, [x8, #0x10]
     e20:      	mov	w1, #0x2e               // =46
     e24:      	stp	x9, x10, [sp, #0x50]
     e28:      	ldr	x9, [x8, #0x20]
     e2c:      	add	x10, sp, #0x40
     e30:      	str	x9, [sp, #0x60]
     e34:      	ldur	x9, [x8, #0x26]
     e38:      	stur	x9, [sp, #0x66]
     e3c:      	ldp	x9, x8, [x8]
     e40:      	stp	x9, x8, [sp, #0x40]
     e44:      	mov	w8, #0x2e               // =46
     e48:      	mov	w9, #0x6                // =6
     e4c:      	ldr	w2, [sp, #0x88]
     e50:      	blr	x9
     e54:      	b	0x6bc <perf_unwind_python+0x6bc>
     e58:      	adrp	x8, 0x0 <perf_unwind_python>
     e5c:      	add	x8, x8, #0x0
     e60:      	add	x0, sp, #0x40
     e64:      	ldp	x9, x10, [x8]
     e68:      	mov	w1, #0x1f               // =31
     e6c:      	stp	x9, x10, [sp, #0x40]
     e70:      	ldr	x9, [x8, #0x10]
     e74:      	ldur	x8, [x8, #0x17]
     e78:      	add	x10, sp, #0x40
     e7c:      	str	x9, [sp, #0x50]
     e80:      	stur	x8, [sp, #0x57]
     e84:      	mov	w8, #0x1f               // =31
     e88:      	mov	w9, #0x6                // =6
     e8c:      	ldr	x2, [sp, #0x88]
     e90:      	blr	x9
     e94:      	b	0x828 <perf_unwind_python+0x828>
     e98:      	adrp	x8, 0x0 <perf_unwind_python>
     e9c:      	add	x8, x8, #0x0
     ea0:      	add	x0, sp, #0x40
     ea4:      	ldp	x9, x10, [x8, #0x10]
     ea8:      	mov	w1, #0x2e               // =46
     eac:      	stp	x9, x10, [sp, #0x50]
     eb0:      	ldr	x9, [x8, #0x20]
     eb4:      	add	x10, sp, #0x40
     eb8:      	str	x9, [sp, #0x60]
     ebc:      	ldur	x9, [x8, #0x26]
     ec0:      	stur	x9, [sp, #0x66]
     ec4:      	ldp	x9, x8, [x8]
     ec8:      	stp	x9, x8, [sp, #0x40]
     ecc:      	mov	w8, #0x2e               // =46
     ed0:      	mov	w9, #0x6                // =6
     ed4:      	ldr	w2, [sp, #0x88]
     ed8:      	blr	x9
     edc:      	b	0x864 <perf_unwind_python+0x864>
     ee0:      	mov	w8, #0x786c             // =30828
     ee4:      	add	x0, sp, #0x40
     ee8:      	mov	w1, #0x23               // =35
     eec:      	mov	w2, w24
     ef0:      	movk	w8, #0xa, lsl #16
     ef4:      	stur	w8, [sp, #0x5f]
     ef8:      	adrp	x8, 0x0 <perf_unwind_python>
     efc:      	add	x8, x8, #0x0
     f00:      	ldp	x9, x10, [x8]
     f04:      	stp	x9, x10, [sp, #0x40]
     f08:      	ldp	x9, x8, [x8, #0x10]
     f0c:      	add	x10, sp, #0x40
     f10:      	stp	x9, x8, [sp, #0x50]
     f14:      	mov	w8, #0x23               // =35
     f18:      	mov	w9, #0x6                // =6
     f1c:      	ldr	x3, [sp, #0x88]
     f20:      	blr	x9
     f24:      	ldr	x8, [sp, #0x88]
     f28:      	b	0x7fc <perf_unwind_python+0x7fc>
     f2c:      	ldr	x8, [sp, #0x28]
     f30:      	ldrb	w9, [x8, #0x19]
     f34:      	ldr	x9, [x23, x9]
     f38:      	str	x9, [sp, #0x8]
     f3c:      	ldrb	w9, [x8, #0x18]
     f40:      	ldr	x8, [x8, #0x8]
     f44:      	ldr	x29, [x23, x9]
     f48:      	cbz	x8, 0xff8 <perf_unwind_python+0xff8>
     f4c:      	ldr	x9, [sp, #0x8]
     f50:      	cmp	x9, x8
     f54:      	b.ne	0xff8 <perf_unwind_python+0xff8>
     f58:      	ldr	x22, [sp, #0x20]
     f5c:      	ldr	x19, [sp, #0x30]
     f60:      	mov	x12, x29
     f64:      	b	0x1ac <perf_unwind_python+0x1ac>
     f68:      	adrp	x8, 0x0 <perf_unwind_python>
     f6c:      	add	x8, x8, #0x0
     f70:      	add	x0, sp, #0x40
     f74:      	ldp	x9, x10, [x8, #0x10]
     f78:      	mov	w1, #0x2e               // =46
     f7c:      	stp	x9, x10, [sp, #0x50]
     f80:      	ldr	x9, [x8, #0x20]
     f84:      	add	x10, sp, #0x40
     f88:      	str	x9, [sp, #0x60]
     f8c:      	ldur	x9, [x8, #0x26]
     f90:      	stur	x9, [sp, #0x66]
     f94:      	ldp	x9, x8, [x8]
     f98:      	stp	x9, x8, [sp, #0x40]
     f9c:      	mov	w8, #0x2e               // =46
     fa0:      	mov	w9, #0x6                // =6
     fa4:      	ldr	w2, [sp, #0x9c]
     fa8:      	blr	x9
     fac:      	b	0x874 <perf_unwind_python+0x874>
     fb0:      	adrp	x8, 0x0 <perf_unwind_python>
     fb4:      	add	x8, x8, #0x0
     fb8:      	add	x0, sp, #0x40
     fbc:      	ldp	x9, x10, [x8, #0x10]
     fc0:      	mov	w1, #0x2e               // =46
     fc4:      	stp	x9, x10, [sp, #0x50]
     fc8:      	ldr	x9, [x8, #0x20]
     fcc:      	add	x10, sp, #0x40
     fd0:      	str	x9, [sp, #0x60]
     fd4:      	ldur	x9, [x8, #0x26]
     fd8:      	stur	x9, [sp, #0x66]
     fdc:      	ldp	x9, x8, [x8]
     fe0:      	stp	x9, x8, [sp, #0x40]
     fe4:      	mov	w8, #0x2e               // =46
     fe8:      	mov	w9, #0x6                // =6
     fec:      	ldr	w2, [sp, #0x88]
     ff0:      	blr	x9
     ff4:      	b	0x8b4 <perf_unwind_python+0x8b4>
     ff8:      	ldr	x8, [sp, #0x28]
     ffc:      	ldrb	w9, [x8, #0x22]
    1000:      	ldrb	w8, [x8, #0x1a]
    1004:      	cbz	w9, 0x10ec <perf_unwind_python+0x10ec>
    1008:      	ldr	x9, [sp, #0x28]
    100c:      	ldr	x11, [sp, #0x8]
    1010:      	ldr	x8, [x23, x8]
    1014:      	ldrb	w10, [x9, #0x21]
    1018:      	add	x10, x11, x10
    101c:      	mov	x11, #-0x3              // =-3
    1020:      	sub	x8, x8, x10
    1024:      	mov	x10, #-0x10000001       // =-268435457
    1028:      	movk	x11, #0xefff, lsl #16
    102c:      	add	x10, x8, x10
    1030:      	asr	w8, w8, #1
    1034:      	cmp	x10, x11
    1038:      	csinv	w19, w8, wzr, hs
    103c:      	ldrb	w8, [x9, #0x1b]
    1040:      	ldrb	w9, [x9, #0x1c]
    1044:      	ldrb	w8, [x23, x8]
    1048:      	cmp	w8, w9
    104c:      	cset	w22, eq
    1050:      	b	0x10f4 <perf_unwind_python+0x10f4>
    1054:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1058:      	add	x8, x8, #0x0
    105c:      	add	x0, sp, #0x40
    1060:      	ldp	x9, x10, [x8, #0x10]
    1064:      	mov	w1, #0x2e               // =46
    1068:      	stp	x9, x10, [sp, #0x50]
    106c:      	ldr	x9, [x8, #0x20]
    1070:      	add	x10, sp, #0x40
    1074:      	str	x9, [sp, #0x60]
    1078:      	ldur	x9, [x8, #0x26]
    107c:      	stur	x9, [sp, #0x66]
    1080:      	ldp	x9, x8, [x8]
    1084:      	stp	x9, x8, [sp, #0x40]
    1088:      	mov	w8, #0x2e               // =46
    108c:      	mov	w9, #0x6                // =6
    1090:      	ldr	w2, [sp, #0x88]
    1094:      	blr	x9
    1098:      	b	0x1cc <perf_unwind_python+0x1cc>
    109c:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    10a0:      	add	x8, x8, #0x0
    10a4:      	add	x0, sp, #0x40
    10a8:      	ldp	x9, x10, [x8, #0x10]
    10ac:      	mov	w1, #0x2d               // =45
    10b0:      	stp	x9, x10, [sp, #0x50]
    10b4:      	ldr	x9, [x8, #0x20]
    10b8:      	add	x10, sp, #0x40
    10bc:      	str	x9, [sp, #0x60]
    10c0:      	ldur	x9, [x8, #0x25]
    10c4:      	stur	x9, [sp, #0x65]
    10c8:      	ldp	x9, x8, [x8]
    10cc:      	stp	x9, x8, [sp, #0x40]
    10d0:      	mov	w8, #0x2d               // =45
    10d4:      	mov	w9, #0x6                // =6
    10d8:      	ldr	x8, [sp, #0x78]
    10dc:      	ldrb	w10, [x29, #0x16]
    10e0:      	add	x2, x8, x10
    10e4:      	blr	x9
    10e8:      	b	0x900 <perf_unwind_python+0x900>
    10ec:      	ldr	w19, [x23, x8]
    10f0:      	mov	w22, wzr
    10f4:      	ldr	x8, [sp, #0x8]
    10f8:      	cbz	x8, 0x1198 <perf_unwind_python+0x1198>
    10fc:      	ldr	x8, [sp, #0x28]
    1100:      	ldrb	w8, [x8, #0x1d]
    1104:      	cmp	w8, #0xbc
    1108:      	b.hi	0x380c <perf_unwind_python+0x380c>
    110c:      	ldr	x8, [sp, #0x28]
    1110:      	ldrb	w8, [x8, #0x1e]
    1114:      	cmp	w8, #0xbc
    1118:      	b.hi	0x380c <perf_unwind_python+0x380c>
    111c:      	ldr	x8, [sp, #0x28]
    1120:      	ldrb	w8, [x8, #0x1f]
    1124:      	cmp	w8, #0xbc
    1128:      	b.hi	0x380c <perf_unwind_python+0x380c>
    112c:      	ldr	x8, [sp, #0x28]
    1130:      	ldrb	w8, [x8, #0x20]
    1134:      	cmp	w8, #0xbc
    1138:      	b.hi	0x380c <perf_unwind_python+0x380c>
    113c:      	ldr	x0, [sp, #0x18]
    1140:      	ldr	x2, [sp, #0x8]
    1144:      	mov	w8, #0xc0               // =192
    1148:      	mov	w9, #0x70               // =112
    114c:      	mov	w1, #0xc0               // =192
    1150:      	blr	x9
    1154:      	cbnz	x0, 0xa90 <perf_unwind_python+0xa90>
    1158:      	ldr	x8, [sp, #0x28]
    115c:      	ldr	x12, [sp, #0x18]
    1160:      	ldrb	w10, [x8, #0x1e]
    1164:      	ldrb	w9, [x8, #0x1d]
    1168:      	ldrb	w11, [x8, #0x1f]
    116c:      	ldrb	w8, [x8, #0x20]
    1170:      	ldr	w10, [x12, x10]
    1174:      	ldr	w9, [x12, x9]
    1178:      	ldr	w11, [x12, x11]
    117c:      	ldr	w8, [x12, x8]
    1180:      	lsl	w10, w10, #18
    1184:      	add	w9, w10, w9, lsl #25
    1188:      	add	w9, w9, w11, lsl #10
    118c:      	add	w8, w9, w8
    1190:      	orr	x19, x8, x19, lsl #32
    1194:      	b	0x12b4 <perf_unwind_python+0x12b4>
    1198:      	ldr	w8, [x25]
    119c:      	cbnz	w8, 0x1830 <perf_unwind_python+0x1830>
    11a0:      	mov	w8, #0x1c               // =28
    11a4:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    11a8:      	add	x9, sp, #0x88
    11ac:      	str	w8, [sp, #0x88]
    11b0:      	mov	w8, #0x1                // =1
    11b4:      	add	x1, sp, #0x88
    11b8:      	ldr	x0, [x0]
    11bc:      	blr	x8
    11c0:      	cbz	x0, 0x12a4 <perf_unwind_python+0x12a4>
    11c4:      	ldr	x8, [x0]
    11c8:      	add	x8, x8, #0x1
    11cc:      	str	x8, [x0]
    11d0:      	b	0x12ac <perf_unwind_python+0x12ac>
    11d4:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    11d8:      	add	x8, x8, #0x0
    11dc:      	add	x0, sp, #0x40
    11e0:      	ldp	x9, x10, [x8]
    11e4:      	ldur	x8, [x8, #0xe]
    11e8:      	mov	w1, #0x16               // =22
    11ec:      	stp	x9, x10, [sp, #0x40]
    11f0:      	stur	x8, [sp, #0x4e]
    11f4:      	mov	w8, #0x16               // =22
    11f8:      	mov	w9, #0x6                // =6
    11fc:      	add	x10, sp, #0x40
    1200:      	blr	x9
    1204:      	b	0x948 <perf_unwind_python+0x948>
    1208:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    120c:      	add	x8, x8, #0x0
    1210:      	add	x0, sp, #0x40
    1214:      	ldp	x9, x10, [x8, #0x10]
    1218:      	mov	w1, #0x2f               // =47
    121c:      	mov	x2, x29
    1220:      	stp	x9, x10, [sp, #0x50]
    1224:      	ldr	x9, [x8, #0x20]
    1228:      	add	x10, sp, #0x40
    122c:      	str	x9, [sp, #0x60]
    1230:      	ldur	x9, [x8, #0x27]
    1234:      	stur	x9, [sp, #0x67]
    1238:      	ldp	x9, x8, [x8]
    123c:      	stp	x9, x8, [sp, #0x40]
    1240:      	mov	w8, #0x2f               // =47
    1244:      	mov	w9, #0x6                // =6
    1248:      	ldr	x8, [sp, #0x28]
    124c:      	ldrb	w8, [x8, #0x19]
    1250:      	add	x3, x29, x8
    1254:      	blr	x9
    1258:      	b	0x298 <perf_unwind_python+0x298>
    125c:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1260:      	add	x8, x8, #0x0
    1264:      	add	x0, sp, #0x40
    1268:      	ldp	x9, x10, [x8, #0x10]
    126c:      	mov	w1, #0x2e               // =46
    1270:      	stp	x9, x10, [sp, #0x50]
    1274:      	ldr	x9, [x8, #0x20]
    1278:      	add	x10, sp, #0x40
    127c:      	str	x9, [sp, #0x60]
    1280:      	ldur	x9, [x8, #0x26]
    1284:      	stur	x9, [sp, #0x66]
    1288:      	ldp	x9, x8, [x8]
    128c:      	stp	x9, x8, [sp, #0x40]
    1290:      	mov	w8, #0x2e               // =46
    1294:      	mov	w9, #0x6                // =6
    1298:      	ldr	w2, [sp, #0x88]
    129c:      	blr	x9
    12a0:      	b	0xa10 <perf_unwind_python+0xa10>
    12a4:      	ldr	w8, [x25]
    12a8:      	cbnz	w8, 0x18b0 <perf_unwind_python+0x18b0>
    12ac:      	mov	x19, #-0x2              // =-2
    12b0:      	str	xzr, [sp, #0x8]
    12b4:      	ldr	w8, [x25]
    12b8:      	cbnz	w8, 0x15a0 <perf_unwind_python+0x15a0>
    12bc:      	ldr	w8, [x21, #0x2c0]
    12c0:      	cmp	w8, #0x7e
    12c4:      	b.ls	0x15e4 <perf_unwind_python+0x15e4>
    12c8:      	ldr	x22, [sp, #0x20]
    12cc:      	ldr	x19, [sp, #0x30]
    12d0:      	ldr	w8, [x25]
    12d4:      	cbz	w8, 0x3cc <perf_unwind_python+0x3cc>
    12d8:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    12dc:      	add	x8, x8, #0x0
    12e0:      	add	x0, sp, #0x40
    12e4:      	ldp	x9, x10, [x8, #0x10]
    12e8:      	mov	w1, #0x25               // =37
    12ec:      	stp	x9, x10, [sp, #0x50]
    12f0:      	ldur	x9, [x8, #0x1d]
    12f4:      	add	x10, sp, #0x40
    12f8:      	stur	x9, [sp, #0x5d]
    12fc:      	ldp	x8, x9, [x8]
    1300:      	stp	x8, x9, [sp, #0x40]
    1304:      	mov	w8, #0x25               // =37
    1308:      	mov	w9, #0x6                // =6
    130c:      	blr	x9
    1310:      	b	0x3cc <perf_unwind_python+0x3cc>
    1314:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1318:      	add	x8, x8, #0x0
    131c:      	add	x0, sp, #0x40
    1320:      	ldp	x9, x10, [x8, #0x10]
    1324:      	mov	w1, #0x2e               // =46
    1328:      	stp	x9, x10, [sp, #0x50]
    132c:      	ldr	x9, [x8, #0x20]
    1330:      	add	x10, sp, #0x40
    1334:      	str	x9, [sp, #0x60]
    1338:      	ldur	x9, [x8, #0x26]
    133c:      	stur	x9, [sp, #0x66]
    1340:      	ldp	x9, x8, [x8]
    1344:      	stp	x9, x8, [sp, #0x40]
    1348:      	mov	w8, #0x2e               // =46
    134c:      	mov	w9, #0x6                // =6
    1350:      	ldr	w2, [sp, #0x88]
    1354:      	blr	x9
    1358:      	b	0xa4c <perf_unwind_python+0xa4c>
    135c:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1360:      	add	x8, x8, #0x0
    1364:      	add	x0, sp, #0x40
    1368:      	ldp	x9, x10, [x8, #0x10]
    136c:      	mov	w1, #0x2e               // =46
    1370:      	stp	x9, x10, [sp, #0x50]
    1374:      	ldr	x9, [x8, #0x20]
    1378:      	add	x10, sp, #0x40
    137c:      	str	x9, [sp, #0x60]
    1380:      	ldur	x9, [x8, #0x26]
    1384:      	stur	x9, [sp, #0x66]
    1388:      	ldp	x9, x8, [x8]
    138c:      	stp	x9, x8, [sp, #0x40]
    1390:      	mov	w8, #0x2e               // =46
    1394:      	mov	w9, #0x6                // =6
    1398:      	ldr	w2, [sp, #0x88]
    139c:      	blr	x9
    13a0:      	mov	x11, x24
    13a4:      	mov	x12, xzr
    13a8:      	mov	x29, #-0x2              // =-2
    13ac:      	ldr	w8, [x25]
    13b0:      	cbz	w8, 0x3b4 <perf_unwind_python+0x3b4>
    13b4:      	b	0x2e0 <perf_unwind_python+0x2e0>
    13b8:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    13bc:      	add	x8, x8, #0x0
    13c0:      	strb	wzr, [sp, #0x70]
    13c4:      	mov	w1, #0x31               // =49
    13c8:      	ldp	x9, x10, [x8, #0x10]
    13cc:      	stp	x9, x10, [sp, #0x50]
    13d0:      	ldp	x9, x10, [x8, #0x20]
    13d4:      	stp	x9, x10, [sp, #0x60]
    13d8:      	ldp	x9, x8, [x8]
    13dc:      	add	x10, sp, #0x40
    13e0:      	stp	x9, x8, [sp, #0x40]
    13e4:      	mov	w8, #0x31               // =49
    13e8:      	mov	w9, #0x6                // =6
    13ec:      	ldr	x8, [x22]
    13f0:      	ldrb	w10, [x0, #0x17]
    13f4:      	add	x0, sp, #0x40
    13f8:      	add	x2, x8, x10
    13fc:      	blr	x9
    1400:      	b	0x9d8 <perf_unwind_python+0x9d8>
    1404:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1408:      	add	x8, x8, #0x0
    140c:      	add	x0, sp, #0x40
    1410:      	ldp	x9, x10, [x8, #0x10]
    1414:      	mov	w1, #0x2e               // =46
    1418:      	stp	x9, x10, [sp, #0x50]
    141c:      	ldr	x9, [x8, #0x20]
    1420:      	add	x10, sp, #0x40
    1424:      	str	x9, [sp, #0x60]
    1428:      	ldur	x9, [x8, #0x26]
    142c:      	stur	x9, [sp, #0x66]
    1430:      	ldp	x9, x8, [x8]
    1434:      	stp	x9, x8, [sp, #0x40]
    1438:      	mov	w8, #0x2e               // =46
    143c:      	mov	w9, #0x6                // =6
    1440:      	ldr	w2, [sp, #0x88]
    1444:      	blr	x9
    1448:      	ldr	w8, [x25]
    144c:      	cbz	w8, 0x480 <perf_unwind_python+0x480>
    1450:      	b	0x404 <perf_unwind_python+0x404>
    1454:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1458:      	add	x8, x8, #0x0
    145c:      	add	x0, sp, #0x40
    1460:      	ldp	x9, x10, [x8, #0x10]
    1464:      	mov	w1, #0x2e               // =46
    1468:      	stp	x9, x10, [sp, #0x50]
    146c:      	ldr	x9, [x8, #0x20]
    1470:      	add	x10, sp, #0x40
    1474:      	str	x9, [sp, #0x60]
    1478:      	ldur	x9, [x8, #0x26]
    147c:      	stur	x9, [sp, #0x66]
    1480:      	ldp	x9, x8, [x8]
    1484:      	stp	x9, x8, [sp, #0x40]
    1488:      	mov	w8, #0x2e               // =46
    148c:      	mov	w9, #0x6                // =6
    1490:      	ldr	w2, [sp, #0x88]
    1494:      	blr	x9
    1498:      	b	0x390 <perf_unwind_python+0x390>
    149c:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    14a0:      	add	x8, x8, #0x0
    14a4:      	add	x0, sp, #0x40
    14a8:      	ldp	x9, x10, [x8]
    14ac:      	mov	w1, #0x20               // =32
    14b0:      	stp	x9, x10, [sp, #0x40]
    14b4:      	ldp	x9, x8, [x8, #0x10]
    14b8:      	add	x10, sp, #0x40
    14bc:      	stp	x9, x8, [sp, #0x50]
    14c0:      	mov	w8, #0x20               // =32
    14c4:      	mov	w9, #0x6                // =6
    14c8:      	blr	x9
    14cc:      	b	0xa2c <perf_unwind_python+0xa2c>
    14d0:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    14d4:      	add	x8, x8, #0x0
    14d8:      	add	x0, sp, #0x40
    14dc:      	ldp	x9, x10, [x8, #0x10]
    14e0:      	mov	w1, #0x2e               // =46
    14e4:      	stp	x9, x10, [sp, #0x50]
    14e8:      	ldr	x9, [x8, #0x20]
    14ec:      	add	x10, sp, #0x40
    14f0:      	str	x9, [sp, #0x60]
    14f4:      	ldur	x9, [x8, #0x26]
    14f8:      	stur	x9, [sp, #0x66]
    14fc:      	ldp	x9, x8, [x8]
    1500:      	stp	x9, x8, [sp, #0x40]
    1504:      	mov	w8, #0x2e               // =46
    1508:      	mov	w9, #0x6                // =6
    150c:      	ldr	w2, [sp, #0x88]
    1510:      	blr	x9
    1514:      	b	0xa5c <perf_unwind_python+0xa5c>
    1518:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    151c:      	add	x8, x8, #0x0
    1520:      	add	x0, sp, #0x40
    1524:      	ldp	x9, x10, [x8, #0x10]
    1528:      	mov	w1, #0x26               // =38
    152c:      	stp	x9, x10, [sp, #0x50]
    1530:      	ldur	x9, [x8, #0x1e]
    1534:      	add	x10, sp, #0x40
    1538:      	stur	x9, [sp, #0x5e]
    153c:      	ldp	x8, x9, [x8]
    1540:      	stp	x8, x9, [sp, #0x40]
    1544:      	mov	w8, #0x26               // =38
    1548:      	mov	w9, #0x6                // =6
    154c:      	ldr	x2, [sp, #0x8]
    1550:      	blr	x9
    1554:      	b	0xa9c <perf_unwind_python+0xa9c>
    1558:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    155c:      	add	x8, x8, #0x0
    1560:      	add	x0, sp, #0x40
    1564:      	ldp	x9, x10, [x8, #0x10]
    1568:      	mov	w1, #0x2e               // =46
    156c:      	stp	x9, x10, [sp, #0x50]
    1570:      	ldr	x9, [x8, #0x20]
    1574:      	add	x10, sp, #0x40
    1578:      	str	x9, [sp, #0x60]
    157c:      	ldur	x9, [x8, #0x26]
    1580:      	stur	x9, [sp, #0x66]
    1584:      	ldp	x9, x8, [x8]
    1588:      	stp	x9, x8, [sp, #0x40]
    158c:      	mov	w8, #0x2e               // =46
    1590:      	mov	w9, #0x6                // =6
    1594:      	ldr	w2, [sp, #0x88]
    1598:      	blr	x9
    159c:      	b	0xc94 <perf_unwind_python+0xc94>
    15a0:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    15a4:      	add	x8, x8, #0x0
    15a8:      	add	x0, sp, #0x40
    15ac:      	ldp	x9, x10, [x8]
    15b0:      	ldr	x8, [x8, #0x10]
    15b4:      	mov	w1, #0x18               // =24
    15b8:      	mov	x3, x19
    15bc:      	stp	x9, x10, [sp, #0x40]
    15c0:      	str	x8, [sp, #0x50]
    15c4:      	mov	w8, #0x18               // =24
    15c8:      	mov	w9, #0x6                // =6
    15cc:      	add	x10, sp, #0x40
    15d0:      	ldr	x2, [sp, #0x8]
    15d4:      	blr	x9
    15d8:      	ldr	w8, [x21, #0x2c0]
    15dc:      	cmp	w8, #0x7e
    15e0:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    15e4:      	add	w9, w8, #0x1
    15e8:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    15ec:      	add	x1, sp, #0x88
    15f0:      	str	w9, [x21, #0x2c0]
    15f4:      	mov	w9, #0x18               // =24
    15f8:      	umaddl	x8, w8, w9, x21
    15fc:      	ldr	x9, [sp, #0x8]
    1600:      	str	x19, [x8, #0x2d8]
    1604:      	str	wzr, [x8, #0x2e4]
    1608:      	str	x9, [x8, #0x2d0]
    160c:      	mov	w9, #0x1                // =1
    1610:      	strb	w9, [x8, #0x2e0]
    1614:      	add	x8, x8, #0x2d0
    1618:      	stur	wzr, [x8, #0x11]
    161c:      	mov	w8, #0x16               // =22
    1620:      	str	w8, [sp, #0x88]
    1624:      	add	x8, sp, #0x88
    1628:      	ldr	x0, [x0]
    162c:      	blr	x9
    1630:      	cbz	x0, 0x1648 <perf_unwind_python+0x1648>
    1634:      	ldr	x8, [x0]
    1638:      	add	x8, x8, #0x1
    163c:      	str	x8, [x0]
    1640:      	cbnz	w22, 0xf58 <perf_unwind_python+0xf58>
    1644:      	b	0x1654 <perf_unwind_python+0x1654>
    1648:      	ldr	w8, [x25]
    164c:      	cbnz	w8, 0x18f8 <perf_unwind_python+0x18f8>
    1650:      	cbnz	w22, 0xf58 <perf_unwind_python+0xf58>
    1654:      	cbz	x29, 0x3400 <perf_unwind_python+0x3400>
    1658:      	ldr	x8, [sp, #0x28]
    165c:      	ldrb	w8, [x8, #0x19]
    1660:      	cmp	w8, #0x78
    1664:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1668:      	ldr	x8, [sp, #0x28]
    166c:      	ldrb	w8, [x8, #0x18]
    1670:      	cmp	w8, #0x78
    1674:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1678:      	ldr	x8, [sp, #0x28]
    167c:      	ldrb	w8, [x8, #0x1a]
    1680:      	cmp	w8, #0x78
    1684:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1688:      	ldr	x8, [sp, #0x28]
    168c:      	ldrsb	w8, [x8, #0x1b]
    1690:      	tbnz	w8, #0x1f, 0x380c <perf_unwind_python+0x380c>
    1694:      	mov	w8, #0x80               // =128
    1698:      	mov	w9, #0x70               // =112
    169c:      	mov	x2, x29
    16a0:      	mov	x0, x23
    16a4:      	mov	w1, #0x80               // =128
    16a8:      	blr	x9
    16ac:      	cbnz	x0, 0xc38 <perf_unwind_python+0xc38>
    16b0:      	ldr	x8, [sp, #0x28]
    16b4:      	ldrb	w9, [x8, #0x19]
    16b8:      	ldr	x10, [x23, x9]
    16bc:      	ldrb	w9, [x8, #0x18]
    16c0:      	ldr	x8, [x8, #0x8]
    16c4:      	ldr	x9, [x23, x9]
    16c8:      	stp	x10, x9, [sp, #0x8]
    16cc:      	cbz	x8, 0x16ec <perf_unwind_python+0x16ec>
    16d0:      	ldr	x9, [sp, #0x8]
    16d4:      	cmp	x9, x8
    16d8:      	b.ne	0x16ec <perf_unwind_python+0x16ec>
    16dc:      	ldr	x22, [sp, #0x20]
    16e0:      	ldr	x19, [sp, #0x30]
    16e4:      	ldr	x12, [sp, #0x10]
    16e8:      	b	0x1ac <perf_unwind_python+0x1ac>
    16ec:      	ldr	x8, [sp, #0x28]
    16f0:      	ldrb	w9, [x8, #0x22]
    16f4:      	ldrb	w8, [x8, #0x1a]
    16f8:      	cbz	w9, 0x1748 <perf_unwind_python+0x1748>
    16fc:      	ldr	x9, [sp, #0x28]
    1700:      	ldr	x11, [sp, #0x8]
    1704:      	ldr	x8, [x23, x8]
    1708:      	ldrb	w10, [x9, #0x21]
    170c:      	add	x10, x11, x10
    1710:      	mov	x11, #-0x3              // =-3
    1714:      	sub	x8, x8, x10
    1718:      	mov	x10, #-0x10000001       // =-268435457
    171c:      	movk	x11, #0xefff, lsl #16
    1720:      	add	x10, x8, x10
    1724:      	asr	w8, w8, #1
    1728:      	cmp	x10, x11
    172c:      	csinv	w24, w8, wzr, hs
    1730:      	ldrb	w8, [x9, #0x1b]
    1734:      	ldrb	w9, [x9, #0x1c]
    1738:      	ldrb	w8, [x23, x8]
    173c:      	cmp	w8, w9
    1740:      	cset	w19, eq
    1744:      	b	0x1750 <perf_unwind_python+0x1750>
    1748:      	ldr	w24, [x23, x8]
    174c:      	mov	w19, wzr
    1750:      	ldr	x8, [sp, #0x8]
    1754:      	cbz	x8, 0x17f4 <perf_unwind_python+0x17f4>
    1758:      	ldr	x8, [sp, #0x28]
    175c:      	ldrb	w8, [x8, #0x1d]
    1760:      	cmp	w8, #0xbc
    1764:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1768:      	ldr	x8, [sp, #0x28]
    176c:      	ldrb	w8, [x8, #0x1e]
    1770:      	cmp	w8, #0xbc
    1774:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1778:      	ldr	x8, [sp, #0x28]
    177c:      	ldrb	w8, [x8, #0x1f]
    1780:      	cmp	w8, #0xbc
    1784:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1788:      	ldr	x8, [sp, #0x28]
    178c:      	ldrb	w8, [x8, #0x20]
    1790:      	cmp	w8, #0xbc
    1794:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1798:      	ldr	x0, [sp, #0x18]
    179c:      	ldr	x2, [sp, #0x8]
    17a0:      	mov	w8, #0xc0               // =192
    17a4:      	mov	w9, #0x70               // =112
    17a8:      	mov	w1, #0xc0               // =192
    17ac:      	blr	x9
    17b0:      	cbnz	x0, 0xa8c <perf_unwind_python+0xa8c>
    17b4:      	ldr	x8, [sp, #0x28]
    17b8:      	ldr	x12, [sp, #0x18]
    17bc:      	ldrb	w10, [x8, #0x1e]
    17c0:      	ldrb	w9, [x8, #0x1d]
    17c4:      	ldrb	w11, [x8, #0x1f]
    17c8:      	ldrb	w8, [x8, #0x20]
    17cc:      	ldr	w10, [x12, x10]
    17d0:      	ldr	w9, [x12, x9]
    17d4:      	ldr	w11, [x12, x11]
    17d8:      	ldr	w8, [x12, x8]
    17dc:      	lsl	w10, w10, #18
    17e0:      	add	w9, w10, w9, lsl #25
    17e4:      	add	w9, w9, w11, lsl #10
    17e8:      	add	w8, w9, w8
    17ec:      	orr	x29, x8, x24, lsl #32
    17f0:      	b	0x1894 <perf_unwind_python+0x1894>
    17f4:      	ldr	w8, [x25]
    17f8:      	cbnz	w8, 0x1bd0 <perf_unwind_python+0x1bd0>
    17fc:      	mov	w8, #0x1c               // =28
    1800:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    1804:      	add	x9, sp, #0x88
    1808:      	str	w8, [sp, #0x88]
    180c:      	mov	w8, #0x1                // =1
    1810:      	add	x1, sp, #0x88
    1814:      	ldr	x0, [x0]
    1818:      	blr	x8
    181c:      	cbz	x0, 0x1884 <perf_unwind_python+0x1884>
    1820:      	ldr	x8, [x0]
    1824:      	add	x8, x8, #0x1
    1828:      	str	x8, [x0]
    182c:      	b	0x188c <perf_unwind_python+0x188c>
    1830:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1834:      	add	x8, x8, #0x0
    1838:      	add	x0, sp, #0x40
    183c:      	ldp	x9, x10, [x8, #0x10]
    1840:      	mov	w1, #0x2f               // =47
    1844:      	mov	x2, x24
    1848:      	stp	x9, x10, [sp, #0x50]
    184c:      	ldr	x9, [x8, #0x20]
    1850:      	add	x10, sp, #0x40
    1854:      	str	x9, [sp, #0x60]
    1858:      	ldur	x9, [x8, #0x27]
    185c:      	stur	x9, [sp, #0x67]
    1860:      	ldp	x9, x8, [x8]
    1864:      	stp	x9, x8, [sp, #0x40]
    1868:      	mov	w8, #0x2f               // =47
    186c:      	mov	w9, #0x6                // =6
    1870:      	ldr	x8, [sp, #0x28]
    1874:      	ldrb	w8, [x8, #0x19]
    1878:      	add	x3, x24, x8
    187c:      	blr	x9
    1880:      	b	0x11a0 <perf_unwind_python+0x11a0>
    1884:      	ldr	w8, [x25]
    1888:      	cbnz	w8, 0x1cac <perf_unwind_python+0x1cac>
    188c:      	mov	x29, #-0x2              // =-2
    1890:      	str	xzr, [sp, #0x8]
    1894:      	ldr	w8, [x25]
    1898:      	cbnz	w8, 0x1944 <perf_unwind_python+0x1944>
    189c:      	ldr	w8, [x21, #0x2c0]
    18a0:      	cmp	w8, #0x7e
    18a4:      	b.ls	0x1988 <perf_unwind_python+0x1988>
    18a8:      	ldr	x29, [sp, #0x10]
    18ac:      	b	0x12c8 <perf_unwind_python+0x12c8>
    18b0:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    18b4:      	add	x8, x8, #0x0
    18b8:      	add	x0, sp, #0x40
    18bc:      	ldp	x9, x10, [x8, #0x10]
    18c0:      	mov	w1, #0x2e               // =46
    18c4:      	stp	x9, x10, [sp, #0x50]
    18c8:      	ldr	x9, [x8, #0x20]
    18cc:      	add	x10, sp, #0x40
    18d0:      	str	x9, [sp, #0x60]
    18d4:      	ldur	x9, [x8, #0x26]
    18d8:      	stur	x9, [sp, #0x66]
    18dc:      	ldp	x9, x8, [x8]
    18e0:      	stp	x9, x8, [sp, #0x40]
    18e4:      	mov	w8, #0x2e               // =46
    18e8:      	mov	w9, #0x6                // =6
    18ec:      	ldr	w2, [sp, #0x88]
    18f0:      	blr	x9
    18f4:      	b	0x12ac <perf_unwind_python+0x12ac>
    18f8:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    18fc:      	add	x8, x8, #0x0
    1900:      	add	x0, sp, #0x40
    1904:      	ldp	x9, x10, [x8, #0x10]
    1908:      	mov	w1, #0x2e               // =46
    190c:      	stp	x9, x10, [sp, #0x50]
    1910:      	ldr	x9, [x8, #0x20]
    1914:      	add	x10, sp, #0x40
    1918:      	str	x9, [sp, #0x60]
    191c:      	ldur	x9, [x8, #0x26]
    1920:      	stur	x9, [sp, #0x66]
    1924:      	ldp	x9, x8, [x8]
    1928:      	stp	x9, x8, [sp, #0x40]
    192c:      	mov	w8, #0x2e               // =46
    1930:      	mov	w9, #0x6                // =6
    1934:      	ldr	w2, [sp, #0x88]
    1938:      	blr	x9
    193c:      	cbnz	w22, 0xf58 <perf_unwind_python+0xf58>
    1940:      	b	0x1654 <perf_unwind_python+0x1654>
    1944:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1948:      	add	x8, x8, #0x0
    194c:      	add	x0, sp, #0x40
    1950:      	ldp	x9, x10, [x8]
    1954:      	ldr	x8, [x8, #0x10]
    1958:      	mov	w1, #0x18               // =24
    195c:      	mov	x3, x29
    1960:      	stp	x9, x10, [sp, #0x40]
    1964:      	str	x8, [sp, #0x50]
    1968:      	mov	w8, #0x18               // =24
    196c:      	mov	w9, #0x6                // =6
    1970:      	add	x10, sp, #0x40
    1974:      	ldr	x2, [sp, #0x8]
    1978:      	blr	x9
    197c:      	ldr	w8, [x21, #0x2c0]
    1980:      	cmp	w8, #0x7e
    1984:      	b.hi	0x18a8 <perf_unwind_python+0x18a8>
    1988:      	add	w9, w8, #0x1
    198c:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    1990:      	add	x1, sp, #0x88
    1994:      	str	w9, [x21, #0x2c0]
    1998:      	mov	w9, #0x18               // =24
    199c:      	umaddl	x8, w8, w9, x21
    19a0:      	ldr	x9, [sp, #0x8]
    19a4:      	str	x29, [x8, #0x2d8]
    19a8:      	str	wzr, [x8, #0x2e4]
    19ac:      	str	x9, [x8, #0x2d0]
    19b0:      	mov	w9, #0x1                // =1
    19b4:      	strb	w9, [x8, #0x2e0]
    19b8:      	add	x8, x8, #0x2d0
    19bc:      	stur	wzr, [x8, #0x11]
    19c0:      	mov	w8, #0x16               // =22
    19c4:      	str	w8, [sp, #0x88]
    19c8:      	add	x8, sp, #0x88
    19cc:      	ldr	x0, [x0]
    19d0:      	blr	x9
    19d4:      	cbz	x0, 0x19ec <perf_unwind_python+0x19ec>
    19d8:      	ldr	x8, [x0]
    19dc:      	add	x8, x8, #0x1
    19e0:      	str	x8, [x0]
    19e4:      	cbnz	w19, 0x16dc <perf_unwind_python+0x16dc>
    19e8:      	b	0x19f8 <perf_unwind_python+0x19f8>
    19ec:      	ldr	w8, [x25]
    19f0:      	cbnz	w8, 0x1de4 <perf_unwind_python+0x1de4>
    19f4:      	cbnz	w19, 0x16dc <perf_unwind_python+0x16dc>
    19f8:      	ldr	x8, [sp, #0x10]
    19fc:      	cbz	x8, 0x22e0 <perf_unwind_python+0x22e0>
    1a00:      	ldr	x8, [sp, #0x28]
    1a04:      	ldrb	w8, [x8, #0x19]
    1a08:      	cmp	w8, #0x78
    1a0c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1a10:      	ldr	x8, [sp, #0x28]
    1a14:      	ldrb	w8, [x8, #0x18]
    1a18:      	cmp	w8, #0x78
    1a1c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1a20:      	ldr	x8, [sp, #0x28]
    1a24:      	ldrb	w8, [x8, #0x1a]
    1a28:      	cmp	w8, #0x78
    1a2c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1a30:      	ldr	x8, [sp, #0x28]
    1a34:      	ldrsb	w8, [x8, #0x1b]
    1a38:      	tbnz	w8, #0x1f, 0x22d0 <perf_unwind_python+0x22d0>
    1a3c:      	ldr	x2, [sp, #0x10]
    1a40:      	mov	w8, #0x80               // =128
    1a44:      	mov	w9, #0x70               // =112
    1a48:      	mov	x0, x23
    1a4c:      	mov	w1, #0x80               // =128
    1a50:      	blr	x9
    1a54:      	cbz	x0, 0x1a60 <perf_unwind_python+0x1a60>
    1a58:      	ldr	x29, [sp, #0x10]
    1a5c:      	b	0xc38 <perf_unwind_python+0xc38>
    1a60:      	ldr	x8, [sp, #0x28]
    1a64:      	ldrb	w9, [x8, #0x19]
    1a68:      	ldr	x9, [x23, x9]
    1a6c:      	str	x9, [sp, #0x8]
    1a70:      	ldrb	w9, [x8, #0x18]
    1a74:      	ldr	x8, [x8, #0x8]
    1a78:      	ldr	x29, [x23, x9]
    1a7c:      	cbz	x8, 0x1a8c <perf_unwind_python+0x1a8c>
    1a80:      	ldr	x9, [sp, #0x8]
    1a84:      	cmp	x9, x8
    1a88:      	b.eq	0xf58 <perf_unwind_python+0xf58>
    1a8c:      	ldr	x8, [sp, #0x28]
    1a90:      	ldrb	w9, [x8, #0x22]
    1a94:      	ldrb	w8, [x8, #0x1a]
    1a98:      	cbz	w9, 0x1ae8 <perf_unwind_python+0x1ae8>
    1a9c:      	ldr	x9, [sp, #0x28]
    1aa0:      	ldr	x11, [sp, #0x8]
    1aa4:      	ldr	x8, [x23, x8]
    1aa8:      	ldrb	w10, [x9, #0x21]
    1aac:      	add	x10, x11, x10
    1ab0:      	mov	x11, #-0x3              // =-3
    1ab4:      	sub	x8, x8, x10
    1ab8:      	mov	x10, #-0x10000001       // =-268435457
    1abc:      	movk	x11, #0xefff, lsl #16
    1ac0:      	add	x10, x8, x10
    1ac4:      	asr	w8, w8, #1
    1ac8:      	cmp	x10, x11
    1acc:      	csinv	w24, w8, wzr, hs
    1ad0:      	ldrb	w8, [x9, #0x1b]
    1ad4:      	ldrb	w9, [x9, #0x1c]
    1ad8:      	ldrb	w8, [x23, x8]
    1adc:      	cmp	w8, w9
    1ae0:      	cset	w19, eq
    1ae4:      	b	0x1af0 <perf_unwind_python+0x1af0>
    1ae8:      	ldr	w24, [x23, x8]
    1aec:      	mov	w19, wzr
    1af0:      	ldr	x8, [sp, #0x8]
    1af4:      	cbz	x8, 0x1b94 <perf_unwind_python+0x1b94>
    1af8:      	ldr	x8, [sp, #0x28]
    1afc:      	ldrb	w8, [x8, #0x1d]
    1b00:      	cmp	w8, #0xbc
    1b04:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1b08:      	ldr	x8, [sp, #0x28]
    1b0c:      	ldrb	w8, [x8, #0x1e]
    1b10:      	cmp	w8, #0xbc
    1b14:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1b18:      	ldr	x8, [sp, #0x28]
    1b1c:      	ldrb	w8, [x8, #0x1f]
    1b20:      	cmp	w8, #0xbc
    1b24:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1b28:      	ldr	x8, [sp, #0x28]
    1b2c:      	ldrb	w8, [x8, #0x20]
    1b30:      	cmp	w8, #0xbc
    1b34:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1b38:      	ldr	x0, [sp, #0x18]
    1b3c:      	ldr	x2, [sp, #0x8]
    1b40:      	mov	w8, #0xc0               // =192
    1b44:      	mov	w9, #0x70               // =112
    1b48:      	mov	w1, #0xc0               // =192
    1b4c:      	blr	x9
    1b50:      	cbnz	x0, 0xa90 <perf_unwind_python+0xa90>
    1b54:      	ldr	x8, [sp, #0x28]
    1b58:      	ldr	x12, [sp, #0x18]
    1b5c:      	ldrb	w10, [x8, #0x1e]
    1b60:      	ldrb	w9, [x8, #0x1d]
    1b64:      	ldrb	w11, [x8, #0x1f]
    1b68:      	ldrb	w8, [x8, #0x20]
    1b6c:      	ldr	w10, [x12, x10]
    1b70:      	ldr	w9, [x12, x9]
    1b74:      	ldr	w11, [x12, x11]
    1b78:      	ldr	w8, [x12, x8]
    1b7c:      	lsl	w10, w10, #18
    1b80:      	add	w9, w10, w9, lsl #25
    1b84:      	add	w9, w9, w11, lsl #10
    1b88:      	add	w8, w9, w8
    1b8c:      	orr	x22, x8, x24, lsl #32
    1b90:      	b	0x1c34 <perf_unwind_python+0x1c34>
    1b94:      	ldr	w8, [x25]
    1b98:      	cbnz	w8, 0x1f68 <perf_unwind_python+0x1f68>
    1b9c:      	mov	w8, #0x1c               // =28
    1ba0:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    1ba4:      	add	x9, sp, #0x88
    1ba8:      	str	w8, [sp, #0x88]
    1bac:      	mov	w8, #0x1                // =1
    1bb0:      	add	x1, sp, #0x88
    1bb4:      	ldr	x0, [x0]
    1bb8:      	blr	x8
    1bbc:      	cbz	x0, 0x1c24 <perf_unwind_python+0x1c24>
    1bc0:      	ldr	x8, [x0]
    1bc4:      	add	x8, x8, #0x1
    1bc8:      	str	x8, [x0]
    1bcc:      	b	0x1c2c <perf_unwind_python+0x1c2c>
    1bd0:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1bd4:      	add	x8, x8, #0x0
    1bd8:      	add	x0, sp, #0x40
    1bdc:      	ldp	x9, x10, [x8, #0x10]
    1be0:      	mov	w1, #0x2f               // =47
    1be4:      	mov	x2, x29
    1be8:      	stp	x9, x10, [sp, #0x50]
    1bec:      	ldr	x9, [x8, #0x20]
    1bf0:      	add	x10, sp, #0x40
    1bf4:      	str	x9, [sp, #0x60]
    1bf8:      	ldur	x9, [x8, #0x27]
    1bfc:      	stur	x9, [sp, #0x67]
    1c00:      	ldp	x9, x8, [x8]
    1c04:      	stp	x9, x8, [sp, #0x40]
    1c08:      	mov	w8, #0x2f               // =47
    1c0c:      	mov	w9, #0x6                // =6
    1c10:      	ldr	x8, [sp, #0x28]
    1c14:      	ldrb	w8, [x8, #0x19]
    1c18:      	add	x3, x29, x8
    1c1c:      	blr	x9
    1c20:      	b	0x17fc <perf_unwind_python+0x17fc>
    1c24:      	ldr	w8, [x25]
    1c28:      	cbnz	w8, 0x2004 <perf_unwind_python+0x2004>
    1c2c:      	mov	x22, #-0x2              // =-2
    1c30:      	str	xzr, [sp, #0x8]
    1c34:      	ldr	w8, [x25]
    1c38:      	cbnz	w8, 0x1fbc <perf_unwind_python+0x1fbc>
    1c3c:      	ldr	w8, [x21, #0x2c0]
    1c40:      	cmp	w8, #0x7e
    1c44:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    1c48:      	add	w9, w8, #0x1
    1c4c:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    1c50:      	add	x1, sp, #0x88
    1c54:      	str	w9, [x21, #0x2c0]
    1c58:      	mov	w9, #0x18               // =24
    1c5c:      	umaddl	x8, w8, w9, x21
    1c60:      	ldr	x9, [sp, #0x8]
    1c64:      	str	x22, [x8, #0x2d8]
    1c68:      	str	wzr, [x8, #0x2e4]
    1c6c:      	str	x9, [x8, #0x2d0]
    1c70:      	mov	w9, #0x1                // =1
    1c74:      	strb	w9, [x8, #0x2e0]
    1c78:      	add	x8, x8, #0x2d0
    1c7c:      	stur	wzr, [x8, #0x11]
    1c80:      	mov	w8, #0x16               // =22
    1c84:      	str	w8, [sp, #0x88]
    1c88:      	add	x8, sp, #0x88
    1c8c:      	ldr	x0, [x0]
    1c90:      	blr	x9
    1c94:      	cbz	x0, 0x1cf4 <perf_unwind_python+0x1cf4>
    1c98:      	ldr	x8, [x0]
    1c9c:      	add	x8, x8, #0x1
    1ca0:      	str	x8, [x0]
    1ca4:      	cbnz	w19, 0xf58 <perf_unwind_python+0xf58>
    1ca8:      	b	0x1d00 <perf_unwind_python+0x1d00>
    1cac:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1cb0:      	add	x8, x8, #0x0
    1cb4:      	add	x0, sp, #0x40
    1cb8:      	ldp	x9, x10, [x8, #0x10]
    1cbc:      	mov	w1, #0x2e               // =46
    1cc0:      	stp	x9, x10, [sp, #0x50]
    1cc4:      	ldr	x9, [x8, #0x20]
    1cc8:      	add	x10, sp, #0x40
    1ccc:      	str	x9, [sp, #0x60]
    1cd0:      	ldur	x9, [x8, #0x26]
    1cd4:      	stur	x9, [sp, #0x66]
    1cd8:      	ldp	x9, x8, [x8]
    1cdc:      	stp	x9, x8, [sp, #0x40]
    1ce0:      	mov	w8, #0x2e               // =46
    1ce4:      	mov	w9, #0x6                // =6
    1ce8:      	ldr	w2, [sp, #0x88]
    1cec:      	blr	x9
    1cf0:      	b	0x188c <perf_unwind_python+0x188c>
    1cf4:      	ldr	w8, [x25]
    1cf8:      	cbnz	w8, 0x204c <perf_unwind_python+0x204c>
    1cfc:      	cbnz	w19, 0xf58 <perf_unwind_python+0xf58>
    1d00:      	cbz	x29, 0x3400 <perf_unwind_python+0x3400>
    1d04:      	ldr	x8, [sp, #0x28]
    1d08:      	ldrb	w8, [x8, #0x19]
    1d0c:      	cmp	w8, #0x78
    1d10:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1d14:      	ldr	x8, [sp, #0x28]
    1d18:      	ldrb	w8, [x8, #0x18]
    1d1c:      	cmp	w8, #0x78
    1d20:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1d24:      	ldr	x8, [sp, #0x28]
    1d28:      	ldrb	w8, [x8, #0x1a]
    1d2c:      	cmp	w8, #0x78
    1d30:      	b.hi	0x380c <perf_unwind_python+0x380c>
    1d34:      	ldr	x8, [sp, #0x28]
    1d38:      	ldrsb	w8, [x8, #0x1b]
    1d3c:      	tbnz	w8, #0x1f, 0x380c <perf_unwind_python+0x380c>
    1d40:      	mov	w8, #0x80               // =128
    1d44:      	mov	w9, #0x70               // =112
    1d48:      	mov	x2, x29
    1d4c:      	mov	x0, x23
    1d50:      	mov	w1, #0x80               // =128
    1d54:      	blr	x9
    1d58:      	cbnz	x0, 0xc38 <perf_unwind_python+0xc38>
    1d5c:      	ldr	x8, [sp, #0x28]
    1d60:      	ldrb	w9, [x8, #0x19]
    1d64:      	ldr	x10, [x23, x9]
    1d68:      	ldrb	w9, [x8, #0x18]
    1d6c:      	ldr	x8, [x8, #0x8]
    1d70:      	ldr	x9, [x23, x9]
    1d74:      	stp	x10, x9, [sp, #0x8]
    1d78:      	cbz	x8, 0x1d88 <perf_unwind_python+0x1d88>
    1d7c:      	ldr	x9, [sp, #0x8]
    1d80:      	cmp	x9, x8
    1d84:      	b.eq	0x16dc <perf_unwind_python+0x16dc>
    1d88:      	ldr	x8, [sp, #0x28]
    1d8c:      	ldrb	w9, [x8, #0x22]
    1d90:      	ldrb	w8, [x8, #0x1a]
    1d94:      	cbz	w9, 0x1e30 <perf_unwind_python+0x1e30>
    1d98:      	ldr	x9, [sp, #0x28]
    1d9c:      	ldr	x11, [sp, #0x8]
    1da0:      	ldr	x8, [x23, x8]
    1da4:      	ldrb	w10, [x9, #0x21]
    1da8:      	add	x10, x11, x10
    1dac:      	mov	x11, #-0x3              // =-3
    1db0:      	sub	x8, x8, x10
    1db4:      	mov	x10, #-0x10000001       // =-268435457
    1db8:      	movk	x11, #0xefff, lsl #16
    1dbc:      	add	x10, x8, x10
    1dc0:      	asr	w8, w8, #1
    1dc4:      	cmp	x10, x11
    1dc8:      	csinv	w24, w8, wzr, hs
    1dcc:      	ldrb	w8, [x9, #0x1b]
    1dd0:      	ldrb	w9, [x9, #0x1c]
    1dd4:      	ldrb	w8, [x23, x8]
    1dd8:      	cmp	w8, w9
    1ddc:      	cset	w19, eq
    1de0:      	b	0x1e38 <perf_unwind_python+0x1e38>
    1de4:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1de8:      	add	x8, x8, #0x0
    1dec:      	add	x0, sp, #0x40
    1df0:      	ldp	x9, x10, [x8, #0x10]
    1df4:      	mov	w1, #0x2e               // =46
    1df8:      	stp	x9, x10, [sp, #0x50]
    1dfc:      	ldr	x9, [x8, #0x20]
    1e00:      	add	x10, sp, #0x40
    1e04:      	str	x9, [sp, #0x60]
    1e08:      	ldur	x9, [x8, #0x26]
    1e0c:      	stur	x9, [sp, #0x66]
    1e10:      	ldp	x9, x8, [x8]
    1e14:      	stp	x9, x8, [sp, #0x40]
    1e18:      	mov	w8, #0x2e               // =46
    1e1c:      	mov	w9, #0x6                // =6
    1e20:      	ldr	w2, [sp, #0x88]
    1e24:      	blr	x9
    1e28:      	cbnz	w19, 0x16dc <perf_unwind_python+0x16dc>
    1e2c:      	b	0x19f8 <perf_unwind_python+0x19f8>
    1e30:      	ldr	w24, [x23, x8]
    1e34:      	mov	w19, wzr
    1e38:      	ldr	x8, [sp, #0x8]
    1e3c:      	cbz	x8, 0x1edc <perf_unwind_python+0x1edc>
    1e40:      	ldr	x8, [sp, #0x28]
    1e44:      	ldrb	w8, [x8, #0x1d]
    1e48:      	cmp	w8, #0xbc
    1e4c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1e50:      	ldr	x8, [sp, #0x28]
    1e54:      	ldrb	w8, [x8, #0x1e]
    1e58:      	cmp	w8, #0xbc
    1e5c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1e60:      	ldr	x8, [sp, #0x28]
    1e64:      	ldrb	w8, [x8, #0x1f]
    1e68:      	cmp	w8, #0xbc
    1e6c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1e70:      	ldr	x8, [sp, #0x28]
    1e74:      	ldrb	w8, [x8, #0x20]
    1e78:      	cmp	w8, #0xbc
    1e7c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    1e80:      	ldr	x0, [sp, #0x18]
    1e84:      	ldr	x2, [sp, #0x8]
    1e88:      	mov	w8, #0xc0               // =192
    1e8c:      	mov	w9, #0x70               // =112
    1e90:      	mov	w1, #0xc0               // =192
    1e94:      	blr	x9
    1e98:      	cbnz	x0, 0xa8c <perf_unwind_python+0xa8c>
    1e9c:      	ldr	x8, [sp, #0x28]
    1ea0:      	ldr	x12, [sp, #0x18]
    1ea4:      	ldrb	w10, [x8, #0x1e]
    1ea8:      	ldrb	w9, [x8, #0x1d]
    1eac:      	ldrb	w11, [x8, #0x1f]
    1eb0:      	ldrb	w8, [x8, #0x20]
    1eb4:      	ldr	w10, [x12, x10]
    1eb8:      	ldr	w9, [x12, x9]
    1ebc:      	ldr	w11, [x12, x11]
    1ec0:      	ldr	w8, [x12, x8]
    1ec4:      	lsl	w10, w10, #18
    1ec8:      	add	w9, w10, w9, lsl #25
    1ecc:      	add	w9, w9, w11, lsl #10
    1ed0:      	add	w8, w9, w8
    1ed4:      	orr	x29, x8, x24, lsl #32
    1ed8:      	b	0x20ec <perf_unwind_python+0x20ec>
    1edc:      	ldr	w8, [x25]
    1ee0:      	cbz	w8, 0x1f34 <perf_unwind_python+0x1f34>
    1ee4:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1ee8:      	add	x8, x8, #0x0
    1eec:      	add	x0, sp, #0x40
    1ef0:      	ldp	x9, x10, [x8, #0x10]
    1ef4:      	mov	w1, #0x2f               // =47
    1ef8:      	mov	x2, x29
    1efc:      	stp	x9, x10, [sp, #0x50]
    1f00:      	ldr	x9, [x8, #0x20]
    1f04:      	add	x10, sp, #0x40
    1f08:      	str	x9, [sp, #0x60]
    1f0c:      	ldur	x9, [x8, #0x27]
    1f10:      	stur	x9, [sp, #0x67]
    1f14:      	ldp	x9, x8, [x8]
    1f18:      	stp	x9, x8, [sp, #0x40]
    1f1c:      	mov	w8, #0x2f               // =47
    1f20:      	mov	w9, #0x6                // =6
    1f24:      	ldr	x8, [sp, #0x28]
    1f28:      	ldrb	w8, [x8, #0x19]
    1f2c:      	add	x3, x29, x8
    1f30:      	blr	x9
    1f34:      	mov	w8, #0x1c               // =28
    1f38:      	adrp	x0, 0x1000 <perf_unwind_python+0x1000>
    1f3c:      	add	x9, sp, #0x88
    1f40:      	str	w8, [sp, #0x88]
    1f44:      	mov	w8, #0x1                // =1
    1f48:      	add	x1, sp, #0x88
    1f4c:      	ldr	x0, [x0]
    1f50:      	blr	x8
    1f54:      	cbz	x0, 0x2098 <perf_unwind_python+0x2098>
    1f58:      	ldr	x8, [x0]
    1f5c:      	add	x8, x8, #0x1
    1f60:      	str	x8, [x0]
    1f64:      	b	0x20e4 <perf_unwind_python+0x20e4>
    1f68:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1f6c:      	add	x8, x8, #0x0
    1f70:      	add	x0, sp, #0x40
    1f74:      	ldp	x9, x10, [x8, #0x10]
    1f78:      	mov	w1, #0x2f               // =47
    1f7c:      	stp	x9, x10, [sp, #0x50]
    1f80:      	ldr	x9, [x8, #0x20]
    1f84:      	add	x10, sp, #0x40
    1f88:      	str	x9, [sp, #0x60]
    1f8c:      	ldur	x9, [x8, #0x27]
    1f90:      	stur	x9, [sp, #0x67]
    1f94:      	ldp	x9, x8, [x8]
    1f98:      	stp	x9, x8, [sp, #0x40]
    1f9c:      	mov	w8, #0x2f               // =47
    1fa0:      	mov	w9, #0x6                // =6
    1fa4:      	ldr	x8, [sp, #0x28]
    1fa8:      	ldr	x2, [sp, #0x10]
    1fac:      	ldrb	w8, [x8, #0x19]
    1fb0:      	add	x3, x2, x8
    1fb4:      	blr	x9
    1fb8:      	b	0x1b9c <perf_unwind_python+0x1b9c>
    1fbc:      	adrp	x8, 0x1000 <perf_unwind_python+0x1000>
    1fc0:      	add	x8, x8, #0x0
    1fc4:      	add	x0, sp, #0x40
    1fc8:      	ldp	x9, x10, [x8]
    1fcc:      	ldr	x8, [x8, #0x10]
    1fd0:      	mov	w1, #0x18               // =24
    1fd4:      	mov	x3, x22
    1fd8:      	stp	x9, x10, [sp, #0x40]
    1fdc:      	str	x8, [sp, #0x50]
    1fe0:      	mov	w8, #0x18               // =24
    1fe4:      	mov	w9, #0x6                // =6
    1fe8:      	add	x10, sp, #0x40
    1fec:      	ldr	x2, [sp, #0x8]
    1ff0:      	blr	x9
    1ff4:      	ldr	w8, [x21, #0x2c0]
    1ff8:      	cmp	w8, #0x7e
    1ffc:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    2000:      	b	0x1c48 <perf_unwind_python+0x1c48>
    2004:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2008:      	add	x8, x8, #0x0
    200c:      	add	x0, sp, #0x40
    2010:      	ldp	x9, x10, [x8, #0x10]
    2014:      	mov	w1, #0x2e               // =46
    2018:      	stp	x9, x10, [sp, #0x50]
    201c:      	ldr	x9, [x8, #0x20]
    2020:      	add	x10, sp, #0x40
    2024:      	str	x9, [sp, #0x60]
    2028:      	ldur	x9, [x8, #0x26]
    202c:      	stur	x9, [sp, #0x66]
    2030:      	ldp	x9, x8, [x8]
    2034:      	stp	x9, x8, [sp, #0x40]
    2038:      	mov	w8, #0x2e               // =46
    203c:      	mov	w9, #0x6                // =6
    2040:      	ldr	w2, [sp, #0x88]
    2044:      	blr	x9
    2048:      	b	0x1c2c <perf_unwind_python+0x1c2c>
    204c:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2050:      	add	x8, x8, #0x0
    2054:      	add	x0, sp, #0x40
    2058:      	ldp	x9, x10, [x8, #0x10]
    205c:      	mov	w1, #0x2e               // =46
    2060:      	stp	x9, x10, [sp, #0x50]
    2064:      	ldr	x9, [x8, #0x20]
    2068:      	add	x10, sp, #0x40
    206c:      	str	x9, [sp, #0x60]
    2070:      	ldur	x9, [x8, #0x26]
    2074:      	stur	x9, [sp, #0x66]
    2078:      	ldp	x9, x8, [x8]
    207c:      	stp	x9, x8, [sp, #0x40]
    2080:      	mov	w8, #0x2e               // =46
    2084:      	mov	w9, #0x6                // =6
    2088:      	ldr	w2, [sp, #0x88]
    208c:      	blr	x9
    2090:      	cbnz	w19, 0xf58 <perf_unwind_python+0xf58>
    2094:      	b	0x1d00 <perf_unwind_python+0x1d00>
    2098:      	ldr	w8, [x25]
    209c:      	cbz	w8, 0x20e4 <perf_unwind_python+0x20e4>
    20a0:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    20a4:      	add	x8, x8, #0x0
    20a8:      	add	x0, sp, #0x40
    20ac:      	ldp	x9, x10, [x8, #0x10]
    20b0:      	mov	w1, #0x2e               // =46
    20b4:      	stp	x9, x10, [sp, #0x50]
    20b8:      	ldr	x9, [x8, #0x20]
    20bc:      	add	x10, sp, #0x40
    20c0:      	str	x9, [sp, #0x60]
    20c4:      	ldur	x9, [x8, #0x26]
    20c8:      	stur	x9, [sp, #0x66]
    20cc:      	ldp	x9, x8, [x8]
    20d0:      	stp	x9, x8, [sp, #0x40]
    20d4:      	mov	w8, #0x2e               // =46
    20d8:      	mov	w9, #0x6                // =6
    20dc:      	ldr	w2, [sp, #0x88]
    20e0:      	blr	x9
    20e4:      	mov	x29, #-0x2              // =-2
    20e8:      	str	xzr, [sp, #0x8]
    20ec:      	ldr	w8, [x25]
    20f0:      	cbz	w8, 0x212c <perf_unwind_python+0x212c>
    20f4:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    20f8:      	add	x8, x8, #0x0
    20fc:      	add	x0, sp, #0x40
    2100:      	ldp	x9, x10, [x8]
    2104:      	ldr	x8, [x8, #0x10]
    2108:      	mov	w1, #0x18               // =24
    210c:      	mov	x3, x29
    2110:      	stp	x9, x10, [sp, #0x40]
    2114:      	str	x8, [sp, #0x50]
    2118:      	mov	w8, #0x18               // =24
    211c:      	mov	w9, #0x6                // =6
    2120:      	add	x10, sp, #0x40
    2124:      	ldr	x2, [sp, #0x8]
    2128:      	blr	x9
    212c:      	ldr	w8, [x21, #0x2c0]
    2130:      	cmp	w8, #0x7e
    2134:      	b.hi	0x18a8 <perf_unwind_python+0x18a8>
    2138:      	add	w9, w8, #0x1
    213c:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    2140:      	add	x1, sp, #0x88
    2144:      	str	w9, [x21, #0x2c0]
    2148:      	mov	w9, #0x18               // =24
    214c:      	umaddl	x8, w8, w9, x21
    2150:      	ldr	x9, [sp, #0x8]
    2154:      	str	x29, [x8, #0x2d8]
    2158:      	str	wzr, [x8, #0x2e4]
    215c:      	str	x9, [x8, #0x2d0]
    2160:      	mov	w9, #0x1                // =1
    2164:      	strb	w9, [x8, #0x2e0]
    2168:      	add	x8, x8, #0x2d0
    216c:      	stur	wzr, [x8, #0x11]
    2170:      	mov	w8, #0x16               // =22
    2174:      	str	w8, [sp, #0x88]
    2178:      	add	x8, sp, #0x88
    217c:      	ldr	x0, [x0]
    2180:      	blr	x9
    2184:      	cbz	x0, 0x2198 <perf_unwind_python+0x2198>
    2188:      	ldr	x8, [x0]
    218c:      	add	x8, x8, #0x1
    2190:      	str	x8, [x0]
    2194:      	b	0x21e4 <perf_unwind_python+0x21e4>
    2198:      	ldr	w8, [x25]
    219c:      	cbz	w8, 0x21e4 <perf_unwind_python+0x21e4>
    21a0:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    21a4:      	add	x8, x8, #0x0
    21a8:      	add	x0, sp, #0x40
    21ac:      	ldp	x9, x10, [x8, #0x10]
    21b0:      	mov	w1, #0x2e               // =46
    21b4:      	stp	x9, x10, [sp, #0x50]
    21b8:      	ldr	x9, [x8, #0x20]
    21bc:      	add	x10, sp, #0x40
    21c0:      	str	x9, [sp, #0x60]
    21c4:      	ldur	x9, [x8, #0x26]
    21c8:      	stur	x9, [sp, #0x66]
    21cc:      	ldp	x9, x8, [x8]
    21d0:      	stp	x9, x8, [sp, #0x40]
    21d4:      	mov	w8, #0x2e               // =46
    21d8:      	mov	w9, #0x6                // =6
    21dc:      	ldr	w2, [sp, #0x88]
    21e0:      	blr	x9
    21e4:      	cbnz	w19, 0x16dc <perf_unwind_python+0x16dc>
    21e8:      	ldr	x8, [sp, #0x10]
    21ec:      	cbz	x8, 0x22e0 <perf_unwind_python+0x22e0>
    21f0:      	ldr	x8, [sp, #0x28]
    21f4:      	ldrb	w8, [x8, #0x19]
    21f8:      	cmp	w8, #0x78
    21fc:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    2200:      	ldr	x8, [sp, #0x28]
    2204:      	ldrb	w8, [x8, #0x18]
    2208:      	cmp	w8, #0x78
    220c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    2210:      	ldr	x8, [sp, #0x28]
    2214:      	ldrb	w8, [x8, #0x1a]
    2218:      	cmp	w8, #0x78
    221c:      	b.hi	0x22d0 <perf_unwind_python+0x22d0>
    2220:      	ldr	x8, [sp, #0x28]
    2224:      	ldrsb	w8, [x8, #0x1b]
    2228:      	tbnz	w8, #0x1f, 0x22d0 <perf_unwind_python+0x22d0>
    222c:      	ldr	x2, [sp, #0x10]
    2230:      	mov	w8, #0x80               // =128
    2234:      	mov	w9, #0x70               // =112
    2238:      	mov	x0, x23
    223c:      	mov	w1, #0x80               // =128
    2240:      	blr	x9
    2244:      	cbnz	x0, 0x1a58 <perf_unwind_python+0x1a58>
    2248:      	ldr	x8, [sp, #0x28]
    224c:      	ldrb	w9, [x8, #0x19]
    2250:      	ldr	x9, [x23, x9]
    2254:      	str	x9, [sp, #0x8]
    2258:      	ldrb	w9, [x8, #0x18]
    225c:      	ldr	x8, [x8, #0x8]
    2260:      	ldr	x29, [x23, x9]
    2264:      	cbz	x8, 0x2274 <perf_unwind_python+0x2274>
    2268:      	ldr	x9, [sp, #0x8]
    226c:      	cmp	x9, x8
    2270:      	b.eq	0xf58 <perf_unwind_python+0xf58>
    2274:      	ldr	x8, [sp, #0x28]
    2278:      	mov	x22, #-0x3              // =-3
    227c:      	movk	x22, #0xefff, lsl #16
    2280:      	ldrb	w9, [x8, #0x22]
    2284:      	ldrb	w8, [x8, #0x1a]
    2288:      	cbz	w9, 0x22e8 <perf_unwind_python+0x22e8>
    228c:      	ldr	x9, [sp, #0x28]
    2290:      	ldr	x11, [sp, #0x8]
    2294:      	ldr	x8, [x23, x8]
    2298:      	ldrb	w10, [x9, #0x21]
    229c:      	add	x10, x11, x10
    22a0:      	sub	x8, x8, x10
    22a4:      	mov	x10, #-0x10000001       // =-268435457
    22a8:      	add	x10, x8, x10
    22ac:      	asr	w8, w8, #1
    22b0:      	cmp	x10, x22
    22b4:      	csinv	w24, w8, wzr, hs
    22b8:      	ldrb	w8, [x9, #0x1b]
    22bc:      	ldrb	w9, [x9, #0x1c]
    22c0:      	ldrb	w8, [x23, x8]
    22c4:      	cmp	w8, w9
    22c8:      	cset	w19, eq
    22cc:      	b	0x22f0 <perf_unwind_python+0x22f0>
    22d0:      	ldr	x29, [sp, #0x10]
    22d4:      	mov	w8, wzr
    22d8:      	mov	w9, #0x1                // =1
    22dc:      	b	0x37a4 <perf_unwind_python+0x37a4>
    22e0:      	mov	x29, xzr
    22e4:      	b	0x3404 <perf_unwind_python+0x3404>
    22e8:      	ldr	w24, [x23, x8]
    22ec:      	mov	w19, wzr
    22f0:      	ldr	x8, [sp, #0x8]
    22f4:      	cbz	x8, 0x2394 <perf_unwind_python+0x2394>
    22f8:      	ldr	x8, [sp, #0x28]
    22fc:      	ldrb	w8, [x8, #0x1d]
    2300:      	cmp	w8, #0xbc
    2304:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2308:      	ldr	x8, [sp, #0x28]
    230c:      	ldrb	w8, [x8, #0x1e]
    2310:      	cmp	w8, #0xbc
    2314:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2318:      	ldr	x8, [sp, #0x28]
    231c:      	ldrb	w8, [x8, #0x1f]
    2320:      	cmp	w8, #0xbc
    2324:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2328:      	ldr	x8, [sp, #0x28]
    232c:      	ldrb	w8, [x8, #0x20]
    2330:      	cmp	w8, #0xbc
    2334:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2338:      	ldr	x0, [sp, #0x18]
    233c:      	ldr	x2, [sp, #0x8]
    2340:      	mov	w8, #0xc0               // =192
    2344:      	mov	w9, #0x70               // =112
    2348:      	mov	w1, #0xc0               // =192
    234c:      	blr	x9
    2350:      	cbnz	x0, 0xa90 <perf_unwind_python+0xa90>
    2354:      	ldr	x8, [sp, #0x28]
    2358:      	ldr	x12, [sp, #0x18]
    235c:      	ldrb	w10, [x8, #0x1e]
    2360:      	ldrb	w9, [x8, #0x1d]
    2364:      	ldrb	w11, [x8, #0x1f]
    2368:      	ldrb	w8, [x8, #0x20]
    236c:      	ldr	w10, [x12, x10]
    2370:      	ldr	w9, [x12, x9]
    2374:      	ldr	w11, [x12, x11]
    2378:      	ldr	w8, [x12, x8]
    237c:      	lsl	w10, w10, #18
    2380:      	add	w9, w10, w9, lsl #25
    2384:      	add	w9, w9, w11, lsl #10
    2388:      	add	w8, w9, w8
    238c:      	orr	x24, x8, x24, lsl #32
    2390:      	b	0x2474 <perf_unwind_python+0x2474>
    2394:      	ldr	w8, [x25]
    2398:      	cbz	w8, 0x23ec <perf_unwind_python+0x23ec>
    239c:      	adrp	x10, 0x2000 <perf_unwind_python+0x2000>
    23a0:      	add	x10, x10, #0x0
    23a4:      	add	x0, sp, #0x40
    23a8:      	ldp	x8, x9, [x10, #0x10]
    23ac:      	mov	w1, #0x2f               // =47
    23b0:      	stp	x8, x9, [sp, #0x50]
    23b4:      	ldr	x8, [x10, #0x20]
    23b8:      	str	x8, [sp, #0x60]
    23bc:      	ldur	x8, [x10, #0x27]
    23c0:      	stur	x8, [sp, #0x67]
    23c4:      	ldp	x8, x9, [x10]
    23c8:      	add	x10, sp, #0x40
    23cc:      	stp	x8, x9, [sp, #0x40]
    23d0:      	mov	w8, #0x2f               // =47
    23d4:      	mov	w9, #0x6                // =6
    23d8:      	ldr	x8, [sp, #0x28]
    23dc:      	ldr	x2, [sp, #0x10]
    23e0:      	ldrb	w8, [x8, #0x19]
    23e4:      	add	x3, x2, x8
    23e8:      	blr	x9
    23ec:      	mov	w8, #0x1c               // =28
    23f0:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    23f4:      	add	x9, sp, #0x88
    23f8:      	str	w8, [sp, #0x88]
    23fc:      	mov	w8, #0x1                // =1
    2400:      	add	x1, sp, #0x88
    2404:      	ldr	x0, [x0]
    2408:      	blr	x8
    240c:      	cbz	x0, 0x2420 <perf_unwind_python+0x2420>
    2410:      	ldr	x8, [x0]
    2414:      	add	x8, x8, #0x1
    2418:      	str	x8, [x0]
    241c:      	b	0x246c <perf_unwind_python+0x246c>
    2420:      	ldr	w8, [x25]
    2424:      	cbz	w8, 0x246c <perf_unwind_python+0x246c>
    2428:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    242c:      	add	x8, x8, #0x0
    2430:      	add	x0, sp, #0x40
    2434:      	ldp	x9, x10, [x8, #0x10]
    2438:      	mov	w1, #0x2e               // =46
    243c:      	stp	x9, x10, [sp, #0x50]
    2440:      	ldr	x9, [x8, #0x20]
    2444:      	add	x10, sp, #0x40
    2448:      	str	x9, [sp, #0x60]
    244c:      	ldur	x9, [x8, #0x26]
    2450:      	stur	x9, [sp, #0x66]
    2454:      	ldp	x9, x8, [x8]
    2458:      	stp	x9, x8, [sp, #0x40]
    245c:      	mov	w8, #0x2e               // =46
    2460:      	mov	w9, #0x6                // =6
    2464:      	ldr	w2, [sp, #0x88]
    2468:      	blr	x9
    246c:      	mov	x24, #-0x2              // =-2
    2470:      	str	xzr, [sp, #0x8]
    2474:      	ldr	w8, [x25]
    2478:      	cbz	w8, 0x24b4 <perf_unwind_python+0x24b4>
    247c:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2480:      	add	x8, x8, #0x0
    2484:      	add	x0, sp, #0x40
    2488:      	ldp	x9, x10, [x8]
    248c:      	ldr	x8, [x8, #0x10]
    2490:      	mov	w1, #0x18               // =24
    2494:      	mov	x3, x24
    2498:      	stp	x9, x10, [sp, #0x40]
    249c:      	str	x8, [sp, #0x50]
    24a0:      	mov	w8, #0x18               // =24
    24a4:      	mov	w9, #0x6                // =6
    24a8:      	add	x10, sp, #0x40
    24ac:      	ldr	x2, [sp, #0x8]
    24b0:      	blr	x9
    24b4:      	ldr	w8, [x21, #0x2c0]
    24b8:      	cmp	w8, #0x7e
    24bc:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    24c0:      	add	w9, w8, #0x1
    24c4:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    24c8:      	add	x1, sp, #0x88
    24cc:      	str	w9, [x21, #0x2c0]
    24d0:      	mov	w9, #0x18               // =24
    24d4:      	umaddl	x8, w8, w9, x21
    24d8:      	ldr	x9, [sp, #0x8]
    24dc:      	str	x24, [x8, #0x2d8]
    24e0:      	str	wzr, [x8, #0x2e4]
    24e4:      	str	x9, [x8, #0x2d0]
    24e8:      	mov	w9, #0x1                // =1
    24ec:      	strb	w9, [x8, #0x2e0]
    24f0:      	add	x8, x8, #0x2d0
    24f4:      	stur	wzr, [x8, #0x11]
    24f8:      	mov	w8, #0x16               // =22
    24fc:      	str	w8, [sp, #0x88]
    2500:      	add	x8, sp, #0x88
    2504:      	ldr	x0, [x0]
    2508:      	blr	x9
    250c:      	cbz	x0, 0x2520 <perf_unwind_python+0x2520>
    2510:      	ldr	x8, [x0]
    2514:      	add	x8, x8, #0x1
    2518:      	str	x8, [x0]
    251c:      	b	0x256c <perf_unwind_python+0x256c>
    2520:      	ldr	w8, [x25]
    2524:      	cbz	w8, 0x256c <perf_unwind_python+0x256c>
    2528:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    252c:      	add	x8, x8, #0x0
    2530:      	add	x0, sp, #0x40
    2534:      	ldp	x9, x10, [x8, #0x10]
    2538:      	mov	w1, #0x2e               // =46
    253c:      	stp	x9, x10, [sp, #0x50]
    2540:      	ldr	x9, [x8, #0x20]
    2544:      	add	x10, sp, #0x40
    2548:      	str	x9, [sp, #0x60]
    254c:      	ldur	x9, [x8, #0x26]
    2550:      	stur	x9, [sp, #0x66]
    2554:      	ldp	x9, x8, [x8]
    2558:      	stp	x9, x8, [sp, #0x40]
    255c:      	mov	w8, #0x2e               // =46
    2560:      	mov	w9, #0x6                // =6
    2564:      	ldr	w2, [sp, #0x88]
    2568:      	blr	x9
    256c:      	cbnz	w19, 0xf58 <perf_unwind_python+0xf58>
    2570:      	cbz	x29, 0x3400 <perf_unwind_python+0x3400>
    2574:      	ldr	x8, [sp, #0x28]
    2578:      	ldrb	w8, [x8, #0x19]
    257c:      	cmp	w8, #0x78
    2580:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2584:      	ldr	x8, [sp, #0x28]
    2588:      	ldrb	w8, [x8, #0x18]
    258c:      	cmp	w8, #0x78
    2590:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2594:      	ldr	x8, [sp, #0x28]
    2598:      	ldrb	w8, [x8, #0x1a]
    259c:      	cmp	w8, #0x78
    25a0:      	b.hi	0x380c <perf_unwind_python+0x380c>
    25a4:      	ldr	x8, [sp, #0x28]
    25a8:      	ldrsb	w8, [x8, #0x1b]
    25ac:      	tbnz	w8, #0x1f, 0x380c <perf_unwind_python+0x380c>
    25b0:      	mov	w8, #0x80               // =128
    25b4:      	mov	w9, #0x70               // =112
    25b8:      	mov	x2, x29
    25bc:      	mov	x0, x23
    25c0:      	mov	w1, #0x80               // =128
    25c4:      	blr	x9
    25c8:      	cbnz	x0, 0xc38 <perf_unwind_python+0xc38>
    25cc:      	ldr	x8, [sp, #0x28]
    25d0:      	ldrb	w9, [x8, #0x19]
    25d4:      	ldr	x9, [x23, x9]
    25d8:      	str	x9, [sp, #0x8]
    25dc:      	ldrb	w9, [x8, #0x18]
    25e0:      	ldr	x8, [x8, #0x8]
    25e4:      	ldr	x24, [x23, x9]
    25e8:      	cbz	x8, 0x25f8 <perf_unwind_python+0x25f8>
    25ec:      	ldr	x9, [sp, #0x8]
    25f0:      	cmp	x9, x8
    25f4:      	b.eq	0x36a8 <perf_unwind_python+0x36a8>
    25f8:      	ldr	x8, [sp, #0x28]
    25fc:      	ldrb	w9, [x8, #0x22]
    2600:      	ldrb	w8, [x8, #0x1a]
    2604:      	cbz	w9, 0x2650 <perf_unwind_python+0x2650>
    2608:      	ldr	x9, [sp, #0x28]
    260c:      	ldr	x11, [sp, #0x8]
    2610:      	ldr	x8, [x23, x8]
    2614:      	ldrb	w10, [x9, #0x21]
    2618:      	add	x10, x11, x10
    261c:      	sub	x8, x8, x10
    2620:      	mov	x10, #-0x10000001       // =-268435457
    2624:      	add	x10, x8, x10
    2628:      	asr	w8, w8, #1
    262c:      	cmp	x10, x22
    2630:      	csinv	w19, w8, wzr, hs
    2634:      	ldrb	w8, [x9, #0x1b]
    2638:      	ldrb	w9, [x9, #0x1c]
    263c:      	ldrb	w8, [x23, x8]
    2640:      	cmp	w8, w9
    2644:      	cset	w8, eq
    2648:      	str	w8, [sp, #0x10]
    264c:      	b	0x2658 <perf_unwind_python+0x2658>
    2650:      	ldr	w19, [x23, x8]
    2654:      	str	wzr, [sp, #0x10]
    2658:      	ldr	x8, [sp, #0x8]
    265c:      	cbz	x8, 0x26fc <perf_unwind_python+0x26fc>
    2660:      	ldr	x8, [sp, #0x28]
    2664:      	ldrb	w8, [x8, #0x1d]
    2668:      	cmp	w8, #0xbc
    266c:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2670:      	ldr	x8, [sp, #0x28]
    2674:      	ldrb	w8, [x8, #0x1e]
    2678:      	cmp	w8, #0xbc
    267c:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2680:      	ldr	x8, [sp, #0x28]
    2684:      	ldrb	w8, [x8, #0x1f]
    2688:      	cmp	w8, #0xbc
    268c:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2690:      	ldr	x8, [sp, #0x28]
    2694:      	ldrb	w8, [x8, #0x20]
    2698:      	cmp	w8, #0xbc
    269c:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    26a0:      	ldr	x0, [sp, #0x18]
    26a4:      	ldr	x2, [sp, #0x8]
    26a8:      	mov	w8, #0xc0               // =192
    26ac:      	mov	w9, #0x70               // =112
    26b0:      	mov	w1, #0xc0               // =192
    26b4:      	blr	x9
    26b8:      	cbnz	x0, 0x3478 <perf_unwind_python+0x3478>
    26bc:      	ldr	x8, [sp, #0x28]
    26c0:      	ldr	x12, [sp, #0x18]
    26c4:      	ldrb	w10, [x8, #0x1e]
    26c8:      	ldrb	w9, [x8, #0x1d]
    26cc:      	ldrb	w11, [x8, #0x1f]
    26d0:      	ldrb	w8, [x8, #0x20]
    26d4:      	ldr	w10, [x12, x10]
    26d8:      	ldr	w9, [x12, x9]
    26dc:      	ldr	w11, [x12, x11]
    26e0:      	ldr	w8, [x12, x8]
    26e4:      	lsl	w10, w10, #18
    26e8:      	add	w9, w10, w9, lsl #25
    26ec:      	add	w9, w9, w11, lsl #10
    26f0:      	add	w8, w9, w8
    26f4:      	orr	x29, x8, x19, lsl #32
    26f8:      	b	0x27dc <perf_unwind_python+0x27dc>
    26fc:      	ldr	w8, [x25]
    2700:      	cbz	w8, 0x2754 <perf_unwind_python+0x2754>
    2704:      	adrp	x10, 0x2000 <perf_unwind_python+0x2000>
    2708:      	add	x10, x10, #0x0
    270c:      	add	x0, sp, #0x40
    2710:      	ldp	x8, x9, [x10, #0x10]
    2714:      	mov	w1, #0x2f               // =47
    2718:      	mov	x2, x29
    271c:      	stp	x8, x9, [sp, #0x50]
    2720:      	ldr	x8, [x10, #0x20]
    2724:      	str	x8, [sp, #0x60]
    2728:      	ldur	x8, [x10, #0x27]
    272c:      	stur	x8, [sp, #0x67]
    2730:      	ldp	x8, x9, [x10]
    2734:      	add	x10, sp, #0x40
    2738:      	stp	x8, x9, [sp, #0x40]
    273c:      	mov	w8, #0x2f               // =47
    2740:      	mov	w9, #0x6                // =6
    2744:      	ldr	x8, [sp, #0x28]
    2748:      	ldrb	w8, [x8, #0x19]
    274c:      	add	x3, x29, x8
    2750:      	blr	x9
    2754:      	mov	w8, #0x1c               // =28
    2758:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    275c:      	add	x9, sp, #0x88
    2760:      	str	w8, [sp, #0x88]
    2764:      	mov	w8, #0x1                // =1
    2768:      	add	x1, sp, #0x88
    276c:      	ldr	x0, [x0]
    2770:      	blr	x8
    2774:      	cbz	x0, 0x2788 <perf_unwind_python+0x2788>
    2778:      	ldr	x8, [x0]
    277c:      	add	x8, x8, #0x1
    2780:      	str	x8, [x0]
    2784:      	b	0x27d4 <perf_unwind_python+0x27d4>
    2788:      	ldr	w8, [x25]
    278c:      	cbz	w8, 0x27d4 <perf_unwind_python+0x27d4>
    2790:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2794:      	add	x8, x8, #0x0
    2798:      	add	x0, sp, #0x40
    279c:      	ldp	x9, x10, [x8, #0x10]
    27a0:      	mov	w1, #0x2e               // =46
    27a4:      	stp	x9, x10, [sp, #0x50]
    27a8:      	ldr	x9, [x8, #0x20]
    27ac:      	add	x10, sp, #0x40
    27b0:      	str	x9, [sp, #0x60]
    27b4:      	ldur	x9, [x8, #0x26]
    27b8:      	stur	x9, [sp, #0x66]
    27bc:      	ldp	x9, x8, [x8]
    27c0:      	stp	x9, x8, [sp, #0x40]
    27c4:      	mov	w8, #0x2e               // =46
    27c8:      	mov	w9, #0x6                // =6
    27cc:      	ldr	w2, [sp, #0x88]
    27d0:      	blr	x9
    27d4:      	mov	x29, #-0x2              // =-2
    27d8:      	str	xzr, [sp, #0x8]
    27dc:      	ldr	w8, [x25]
    27e0:      	cbz	w8, 0x281c <perf_unwind_python+0x281c>
    27e4:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    27e8:      	add	x8, x8, #0x0
    27ec:      	add	x0, sp, #0x40
    27f0:      	ldp	x9, x10, [x8]
    27f4:      	ldr	x8, [x8, #0x10]
    27f8:      	mov	w1, #0x18               // =24
    27fc:      	mov	x3, x29
    2800:      	stp	x9, x10, [sp, #0x40]
    2804:      	str	x8, [sp, #0x50]
    2808:      	mov	w8, #0x18               // =24
    280c:      	mov	w9, #0x6                // =6
    2810:      	add	x10, sp, #0x40
    2814:      	ldr	x2, [sp, #0x8]
    2818:      	blr	x9
    281c:      	ldr	w8, [x21, #0x2c0]
    2820:      	cmp	w8, #0x7e
    2824:      	b.hi	0x35ec <perf_unwind_python+0x35ec>
    2828:      	add	w9, w8, #0x1
    282c:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    2830:      	add	x1, sp, #0x88
    2834:      	str	w9, [x21, #0x2c0]
    2838:      	mov	w9, #0x18               // =24
    283c:      	umaddl	x8, w8, w9, x21
    2840:      	ldr	x9, [sp, #0x8]
    2844:      	str	x29, [x8, #0x2d8]
    2848:      	str	wzr, [x8, #0x2e4]
    284c:      	str	x9, [x8, #0x2d0]
    2850:      	mov	w9, #0x1                // =1
    2854:      	strb	w9, [x8, #0x2e0]
    2858:      	add	x8, x8, #0x2d0
    285c:      	stur	wzr, [x8, #0x11]
    2860:      	mov	w8, #0x16               // =22
    2864:      	str	w8, [sp, #0x88]
    2868:      	add	x8, sp, #0x88
    286c:      	ldr	x0, [x0]
    2870:      	blr	x9
    2874:      	cbz	x0, 0x2888 <perf_unwind_python+0x2888>
    2878:      	ldr	x8, [x0]
    287c:      	add	x8, x8, #0x1
    2880:      	str	x8, [x0]
    2884:      	b	0x28d4 <perf_unwind_python+0x28d4>
    2888:      	ldr	w8, [x25]
    288c:      	cbz	w8, 0x28d4 <perf_unwind_python+0x28d4>
    2890:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2894:      	add	x8, x8, #0x0
    2898:      	add	x0, sp, #0x40
    289c:      	ldp	x9, x10, [x8, #0x10]
    28a0:      	mov	w1, #0x2e               // =46
    28a4:      	stp	x9, x10, [sp, #0x50]
    28a8:      	ldr	x9, [x8, #0x20]
    28ac:      	add	x10, sp, #0x40
    28b0:      	str	x9, [sp, #0x60]
    28b4:      	ldur	x9, [x8, #0x26]
    28b8:      	stur	x9, [sp, #0x66]
    28bc:      	ldp	x9, x8, [x8]
    28c0:      	stp	x9, x8, [sp, #0x40]
    28c4:      	mov	w8, #0x2e               // =46
    28c8:      	mov	w9, #0x6                // =6
    28cc:      	ldr	w2, [sp, #0x88]
    28d0:      	blr	x9
    28d4:      	ldr	w8, [sp, #0x10]
    28d8:      	cbnz	w8, 0x36a8 <perf_unwind_python+0x36a8>
    28dc:      	cbz	x24, 0x37b0 <perf_unwind_python+0x37b0>
    28e0:      	ldr	x8, [sp, #0x28]
    28e4:      	ldrb	w8, [x8, #0x19]
    28e8:      	cmp	w8, #0x78
    28ec:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    28f0:      	ldr	x8, [sp, #0x28]
    28f4:      	ldrb	w8, [x8, #0x18]
    28f8:      	cmp	w8, #0x78
    28fc:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2900:      	ldr	x8, [sp, #0x28]
    2904:      	ldrb	w8, [x8, #0x1a]
    2908:      	cmp	w8, #0x78
    290c:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2910:      	ldr	x8, [sp, #0x28]
    2914:      	ldrsb	w8, [x8, #0x1b]
    2918:      	tbnz	w8, #0x1f, 0x3798 <perf_unwind_python+0x3798>
    291c:      	mov	w8, #0x80               // =128
    2920:      	mov	w9, #0x70               // =112
    2924:      	mov	x2, x24
    2928:      	mov	x0, x23
    292c:      	mov	w1, #0x80               // =128
    2930:      	blr	x9
    2934:      	cbnz	x0, 0xc34 <perf_unwind_python+0xc34>
    2938:      	ldr	x8, [sp, #0x28]
    293c:      	ldrb	w9, [x8, #0x19]
    2940:      	ldr	x9, [x23, x9]
    2944:      	str	x9, [sp, #0x8]
    2948:      	ldrb	w9, [x8, #0x18]
    294c:      	ldr	x8, [x8, #0x8]
    2950:      	ldr	x29, [x23, x9]
    2954:      	cbz	x8, 0x2964 <perf_unwind_python+0x2964>
    2958:      	ldr	x9, [sp, #0x8]
    295c:      	cmp	x9, x8
    2960:      	b.eq	0xf58 <perf_unwind_python+0xf58>
    2964:      	ldr	x8, [sp, #0x28]
    2968:      	ldrb	w9, [x8, #0x22]
    296c:      	ldrb	w8, [x8, #0x1a]
    2970:      	cbz	w9, 0x29bc <perf_unwind_python+0x29bc>
    2974:      	ldr	x9, [sp, #0x28]
    2978:      	ldr	x11, [sp, #0x8]
    297c:      	ldr	x8, [x23, x8]
    2980:      	ldrb	w10, [x9, #0x21]
    2984:      	add	x10, x11, x10
    2988:      	sub	x8, x8, x10
    298c:      	mov	x10, #-0x10000001       // =-268435457
    2990:      	add	x10, x8, x10
    2994:      	asr	w8, w8, #1
    2998:      	cmp	x10, x22
    299c:      	csinv	w19, w8, wzr, hs
    29a0:      	ldrb	w8, [x9, #0x1b]
    29a4:      	ldrb	w9, [x9, #0x1c]
    29a8:      	ldrb	w8, [x23, x8]
    29ac:      	cmp	w8, w9
    29b0:      	cset	w8, eq
    29b4:      	str	w8, [sp, #0x10]
    29b8:      	b	0x29c4 <perf_unwind_python+0x29c4>
    29bc:      	ldr	w19, [x23, x8]
    29c0:      	str	wzr, [sp, #0x10]
    29c4:      	ldr	x8, [sp, #0x8]
    29c8:      	cbz	x8, 0x2a68 <perf_unwind_python+0x2a68>
    29cc:      	ldr	x8, [sp, #0x28]
    29d0:      	ldrb	w8, [x8, #0x1d]
    29d4:      	cmp	w8, #0xbc
    29d8:      	b.hi	0x380c <perf_unwind_python+0x380c>
    29dc:      	ldr	x8, [sp, #0x28]
    29e0:      	ldrb	w8, [x8, #0x1e]
    29e4:      	cmp	w8, #0xbc
    29e8:      	b.hi	0x380c <perf_unwind_python+0x380c>
    29ec:      	ldr	x8, [sp, #0x28]
    29f0:      	ldrb	w8, [x8, #0x1f]
    29f4:      	cmp	w8, #0xbc
    29f8:      	b.hi	0x380c <perf_unwind_python+0x380c>
    29fc:      	ldr	x8, [sp, #0x28]
    2a00:      	ldrb	w8, [x8, #0x20]
    2a04:      	cmp	w8, #0xbc
    2a08:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2a0c:      	ldr	x0, [sp, #0x18]
    2a10:      	ldr	x2, [sp, #0x8]
    2a14:      	mov	w8, #0xc0               // =192
    2a18:      	mov	w9, #0x70               // =112
    2a1c:      	mov	w1, #0xc0               // =192
    2a20:      	blr	x9
    2a24:      	cbnz	x0, 0xa90 <perf_unwind_python+0xa90>
    2a28:      	ldr	x8, [sp, #0x28]
    2a2c:      	ldr	x12, [sp, #0x18]
    2a30:      	ldrb	w10, [x8, #0x1e]
    2a34:      	ldrb	w9, [x8, #0x1d]
    2a38:      	ldrb	w11, [x8, #0x1f]
    2a3c:      	ldrb	w8, [x8, #0x20]
    2a40:      	ldr	w10, [x12, x10]
    2a44:      	ldr	w9, [x12, x9]
    2a48:      	ldr	w11, [x12, x11]
    2a4c:      	ldr	w8, [x12, x8]
    2a50:      	lsl	w10, w10, #18
    2a54:      	add	w9, w10, w9, lsl #25
    2a58:      	add	w9, w9, w11, lsl #10
    2a5c:      	add	w8, w9, w8
    2a60:      	orr	x19, x8, x19, lsl #32
    2a64:      	b	0x2b48 <perf_unwind_python+0x2b48>
    2a68:      	ldr	w8, [x25]
    2a6c:      	cbz	w8, 0x2ac0 <perf_unwind_python+0x2ac0>
    2a70:      	adrp	x10, 0x2000 <perf_unwind_python+0x2000>
    2a74:      	add	x10, x10, #0x0
    2a78:      	add	x0, sp, #0x40
    2a7c:      	ldp	x8, x9, [x10, #0x10]
    2a80:      	mov	w1, #0x2f               // =47
    2a84:      	mov	x2, x24
    2a88:      	stp	x8, x9, [sp, #0x50]
    2a8c:      	ldr	x8, [x10, #0x20]
    2a90:      	str	x8, [sp, #0x60]
    2a94:      	ldur	x8, [x10, #0x27]
    2a98:      	stur	x8, [sp, #0x67]
    2a9c:      	ldp	x8, x9, [x10]
    2aa0:      	add	x10, sp, #0x40
    2aa4:      	stp	x8, x9, [sp, #0x40]
    2aa8:      	mov	w8, #0x2f               // =47
    2aac:      	mov	w9, #0x6                // =6
    2ab0:      	ldr	x8, [sp, #0x28]
    2ab4:      	ldrb	w8, [x8, #0x19]
    2ab8:      	add	x3, x24, x8
    2abc:      	blr	x9
    2ac0:      	mov	w8, #0x1c               // =28
    2ac4:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    2ac8:      	add	x9, sp, #0x88
    2acc:      	str	w8, [sp, #0x88]
    2ad0:      	mov	w8, #0x1                // =1
    2ad4:      	add	x1, sp, #0x88
    2ad8:      	ldr	x0, [x0]
    2adc:      	blr	x8
    2ae0:      	cbz	x0, 0x2af4 <perf_unwind_python+0x2af4>
    2ae4:      	ldr	x8, [x0]
    2ae8:      	add	x8, x8, #0x1
    2aec:      	str	x8, [x0]
    2af0:      	b	0x2b40 <perf_unwind_python+0x2b40>
    2af4:      	ldr	w8, [x25]
    2af8:      	cbz	w8, 0x2b40 <perf_unwind_python+0x2b40>
    2afc:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2b00:      	add	x8, x8, #0x0
    2b04:      	add	x0, sp, #0x40
    2b08:      	ldp	x9, x10, [x8, #0x10]
    2b0c:      	mov	w1, #0x2e               // =46
    2b10:      	stp	x9, x10, [sp, #0x50]
    2b14:      	ldr	x9, [x8, #0x20]
    2b18:      	add	x10, sp, #0x40
    2b1c:      	str	x9, [sp, #0x60]
    2b20:      	ldur	x9, [x8, #0x26]
    2b24:      	stur	x9, [sp, #0x66]
    2b28:      	ldp	x9, x8, [x8]
    2b2c:      	stp	x9, x8, [sp, #0x40]
    2b30:      	mov	w8, #0x2e               // =46
    2b34:      	mov	w9, #0x6                // =6
    2b38:      	ldr	w2, [sp, #0x88]
    2b3c:      	blr	x9
    2b40:      	mov	x19, #-0x2              // =-2
    2b44:      	str	xzr, [sp, #0x8]
    2b48:      	ldr	w8, [x25]
    2b4c:      	cbz	w8, 0x2b88 <perf_unwind_python+0x2b88>
    2b50:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2b54:      	add	x8, x8, #0x0
    2b58:      	add	x0, sp, #0x40
    2b5c:      	ldp	x9, x10, [x8]
    2b60:      	ldr	x8, [x8, #0x10]
    2b64:      	mov	w1, #0x18               // =24
    2b68:      	mov	x3, x19
    2b6c:      	stp	x9, x10, [sp, #0x40]
    2b70:      	str	x8, [sp, #0x50]
    2b74:      	mov	w8, #0x18               // =24
    2b78:      	mov	w9, #0x6                // =6
    2b7c:      	add	x10, sp, #0x40
    2b80:      	ldr	x2, [sp, #0x8]
    2b84:      	blr	x9
    2b88:      	ldr	w8, [x21, #0x2c0]
    2b8c:      	cmp	w8, #0x7e
    2b90:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    2b94:      	add	w9, w8, #0x1
    2b98:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    2b9c:      	add	x1, sp, #0x88
    2ba0:      	str	w9, [x21, #0x2c0]
    2ba4:      	mov	w9, #0x18               // =24
    2ba8:      	umaddl	x8, w8, w9, x21
    2bac:      	ldr	x9, [sp, #0x8]
    2bb0:      	str	x19, [x8, #0x2d8]
    2bb4:      	str	wzr, [x8, #0x2e4]
    2bb8:      	str	x9, [x8, #0x2d0]
    2bbc:      	mov	w9, #0x1                // =1
    2bc0:      	strb	w9, [x8, #0x2e0]
    2bc4:      	add	x8, x8, #0x2d0
    2bc8:      	stur	wzr, [x8, #0x11]
    2bcc:      	mov	w8, #0x16               // =22
    2bd0:      	str	w8, [sp, #0x88]
    2bd4:      	add	x8, sp, #0x88
    2bd8:      	ldr	x0, [x0]
    2bdc:      	blr	x9
    2be0:      	cbz	x0, 0x2bf4 <perf_unwind_python+0x2bf4>
    2be4:      	ldr	x8, [x0]
    2be8:      	add	x8, x8, #0x1
    2bec:      	str	x8, [x0]
    2bf0:      	b	0x2c40 <perf_unwind_python+0x2c40>
    2bf4:      	ldr	w8, [x25]
    2bf8:      	cbz	w8, 0x2c40 <perf_unwind_python+0x2c40>
    2bfc:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2c00:      	add	x8, x8, #0x0
    2c04:      	add	x0, sp, #0x40
    2c08:      	ldp	x9, x10, [x8, #0x10]
    2c0c:      	mov	w1, #0x2e               // =46
    2c10:      	stp	x9, x10, [sp, #0x50]
    2c14:      	ldr	x9, [x8, #0x20]
    2c18:      	add	x10, sp, #0x40
    2c1c:      	str	x9, [sp, #0x60]
    2c20:      	ldur	x9, [x8, #0x26]
    2c24:      	stur	x9, [sp, #0x66]
    2c28:      	ldp	x9, x8, [x8]
    2c2c:      	stp	x9, x8, [sp, #0x40]
    2c30:      	mov	w8, #0x2e               // =46
    2c34:      	mov	w9, #0x6                // =6
    2c38:      	ldr	w2, [sp, #0x88]
    2c3c:      	blr	x9
    2c40:      	ldr	w8, [sp, #0x10]
    2c44:      	cbnz	w8, 0xf58 <perf_unwind_python+0xf58>
    2c48:      	cbz	x29, 0x3400 <perf_unwind_python+0x3400>
    2c4c:      	ldr	x8, [sp, #0x28]
    2c50:      	ldrb	w8, [x8, #0x19]
    2c54:      	cmp	w8, #0x78
    2c58:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2c5c:      	ldr	x8, [sp, #0x28]
    2c60:      	ldrb	w8, [x8, #0x18]
    2c64:      	cmp	w8, #0x78
    2c68:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2c6c:      	ldr	x8, [sp, #0x28]
    2c70:      	ldrb	w8, [x8, #0x1a]
    2c74:      	cmp	w8, #0x78
    2c78:      	b.hi	0x380c <perf_unwind_python+0x380c>
    2c7c:      	ldr	x8, [sp, #0x28]
    2c80:      	ldrsb	w8, [x8, #0x1b]
    2c84:      	tbnz	w8, #0x1f, 0x380c <perf_unwind_python+0x380c>
    2c88:      	mov	w8, #0x80               // =128
    2c8c:      	mov	w9, #0x70               // =112
    2c90:      	mov	x2, x29
    2c94:      	mov	x0, x23
    2c98:      	mov	w1, #0x80               // =128
    2c9c:      	blr	x9
    2ca0:      	cbnz	x0, 0xc38 <perf_unwind_python+0xc38>
    2ca4:      	ldr	x8, [sp, #0x28]
    2ca8:      	ldrb	w9, [x8, #0x19]
    2cac:      	ldr	x9, [x23, x9]
    2cb0:      	str	x9, [sp, #0x8]
    2cb4:      	ldrb	w9, [x8, #0x18]
    2cb8:      	ldr	x8, [x8, #0x8]
    2cbc:      	ldr	x24, [x23, x9]
    2cc0:      	cbz	x8, 0x2cd0 <perf_unwind_python+0x2cd0>
    2cc4:      	ldr	x9, [sp, #0x8]
    2cc8:      	cmp	x9, x8
    2ccc:      	b.eq	0x36a8 <perf_unwind_python+0x36a8>
    2cd0:      	ldr	x8, [sp, #0x28]
    2cd4:      	ldrb	w9, [x8, #0x22]
    2cd8:      	ldrb	w8, [x8, #0x1a]
    2cdc:      	cbz	w9, 0x2d28 <perf_unwind_python+0x2d28>
    2ce0:      	ldr	x9, [sp, #0x28]
    2ce4:      	ldr	x11, [sp, #0x8]
    2ce8:      	ldr	x8, [x23, x8]
    2cec:      	ldrb	w10, [x9, #0x21]
    2cf0:      	add	x10, x11, x10
    2cf4:      	sub	x8, x8, x10
    2cf8:      	mov	x10, #-0x10000001       // =-268435457
    2cfc:      	add	x10, x8, x10
    2d00:      	asr	w8, w8, #1
    2d04:      	cmp	x10, x22
    2d08:      	csinv	w19, w8, wzr, hs
    2d0c:      	ldrb	w8, [x9, #0x1b]
    2d10:      	ldrb	w9, [x9, #0x1c]
    2d14:      	ldrb	w8, [x23, x8]
    2d18:      	cmp	w8, w9
    2d1c:      	cset	w8, eq
    2d20:      	str	w8, [sp, #0x10]
    2d24:      	b	0x2d30 <perf_unwind_python+0x2d30>
    2d28:      	ldr	w19, [x23, x8]
    2d2c:      	str	wzr, [sp, #0x10]
    2d30:      	ldr	x8, [sp, #0x8]
    2d34:      	cbz	x8, 0x2dd4 <perf_unwind_python+0x2dd4>
    2d38:      	ldr	x8, [sp, #0x28]
    2d3c:      	ldrb	w8, [x8, #0x1d]
    2d40:      	cmp	w8, #0xbc
    2d44:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2d48:      	ldr	x8, [sp, #0x28]
    2d4c:      	ldrb	w8, [x8, #0x1e]
    2d50:      	cmp	w8, #0xbc
    2d54:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2d58:      	ldr	x8, [sp, #0x28]
    2d5c:      	ldrb	w8, [x8, #0x1f]
    2d60:      	cmp	w8, #0xbc
    2d64:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2d68:      	ldr	x8, [sp, #0x28]
    2d6c:      	ldrb	w8, [x8, #0x20]
    2d70:      	cmp	w8, #0xbc
    2d74:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2d78:      	ldr	x0, [sp, #0x18]
    2d7c:      	ldr	x2, [sp, #0x8]
    2d80:      	mov	w8, #0xc0               // =192
    2d84:      	mov	w9, #0x70               // =112
    2d88:      	mov	w1, #0xc0               // =192
    2d8c:      	blr	x9
    2d90:      	cbnz	x0, 0x3478 <perf_unwind_python+0x3478>
    2d94:      	ldr	x8, [sp, #0x28]
    2d98:      	ldr	x12, [sp, #0x18]
    2d9c:      	ldrb	w10, [x8, #0x1e]
    2da0:      	ldrb	w9, [x8, #0x1d]
    2da4:      	ldrb	w11, [x8, #0x1f]
    2da8:      	ldrb	w8, [x8, #0x20]
    2dac:      	ldr	w10, [x12, x10]
    2db0:      	ldr	w9, [x12, x9]
    2db4:      	ldr	w11, [x12, x11]
    2db8:      	ldr	w8, [x12, x8]
    2dbc:      	lsl	w10, w10, #18
    2dc0:      	add	w9, w10, w9, lsl #25
    2dc4:      	add	w9, w9, w11, lsl #10
    2dc8:      	add	w8, w9, w8
    2dcc:      	orr	x29, x8, x19, lsl #32
    2dd0:      	b	0x2eb4 <perf_unwind_python+0x2eb4>
    2dd4:      	ldr	w8, [x25]
    2dd8:      	cbz	w8, 0x2e2c <perf_unwind_python+0x2e2c>
    2ddc:      	adrp	x10, 0x2000 <perf_unwind_python+0x2000>
    2de0:      	add	x10, x10, #0x0
    2de4:      	add	x0, sp, #0x40
    2de8:      	ldp	x8, x9, [x10, #0x10]
    2dec:      	mov	w1, #0x2f               // =47
    2df0:      	mov	x2, x29
    2df4:      	stp	x8, x9, [sp, #0x50]
    2df8:      	ldr	x8, [x10, #0x20]
    2dfc:      	str	x8, [sp, #0x60]
    2e00:      	ldur	x8, [x10, #0x27]
    2e04:      	stur	x8, [sp, #0x67]
    2e08:      	ldp	x8, x9, [x10]
    2e0c:      	add	x10, sp, #0x40
    2e10:      	stp	x8, x9, [sp, #0x40]
    2e14:      	mov	w8, #0x2f               // =47
    2e18:      	mov	w9, #0x6                // =6
    2e1c:      	ldr	x8, [sp, #0x28]
    2e20:      	ldrb	w8, [x8, #0x19]
    2e24:      	add	x3, x29, x8
    2e28:      	blr	x9
    2e2c:      	mov	w8, #0x1c               // =28
    2e30:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    2e34:      	add	x9, sp, #0x88
    2e38:      	str	w8, [sp, #0x88]
    2e3c:      	mov	w8, #0x1                // =1
    2e40:      	add	x1, sp, #0x88
    2e44:      	ldr	x0, [x0]
    2e48:      	blr	x8
    2e4c:      	cbz	x0, 0x2e60 <perf_unwind_python+0x2e60>
    2e50:      	ldr	x8, [x0]
    2e54:      	add	x8, x8, #0x1
    2e58:      	str	x8, [x0]
    2e5c:      	b	0x2eac <perf_unwind_python+0x2eac>
    2e60:      	ldr	w8, [x25]
    2e64:      	cbz	w8, 0x2eac <perf_unwind_python+0x2eac>
    2e68:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2e6c:      	add	x8, x8, #0x0
    2e70:      	add	x0, sp, #0x40
    2e74:      	ldp	x9, x10, [x8, #0x10]
    2e78:      	mov	w1, #0x2e               // =46
    2e7c:      	stp	x9, x10, [sp, #0x50]
    2e80:      	ldr	x9, [x8, #0x20]
    2e84:      	add	x10, sp, #0x40
    2e88:      	str	x9, [sp, #0x60]
    2e8c:      	ldur	x9, [x8, #0x26]
    2e90:      	stur	x9, [sp, #0x66]
    2e94:      	ldp	x9, x8, [x8]
    2e98:      	stp	x9, x8, [sp, #0x40]
    2e9c:      	mov	w8, #0x2e               // =46
    2ea0:      	mov	w9, #0x6                // =6
    2ea4:      	ldr	w2, [sp, #0x88]
    2ea8:      	blr	x9
    2eac:      	mov	x29, #-0x2              // =-2
    2eb0:      	str	xzr, [sp, #0x8]
    2eb4:      	ldr	w8, [x25]
    2eb8:      	cbz	w8, 0x2ef4 <perf_unwind_python+0x2ef4>
    2ebc:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2ec0:      	add	x8, x8, #0x0
    2ec4:      	add	x0, sp, #0x40
    2ec8:      	ldp	x9, x10, [x8]
    2ecc:      	ldr	x8, [x8, #0x10]
    2ed0:      	mov	w1, #0x18               // =24
    2ed4:      	mov	x3, x29
    2ed8:      	stp	x9, x10, [sp, #0x40]
    2edc:      	str	x8, [sp, #0x50]
    2ee0:      	mov	w8, #0x18               // =24
    2ee4:      	mov	w9, #0x6                // =6
    2ee8:      	add	x10, sp, #0x40
    2eec:      	ldr	x2, [sp, #0x8]
    2ef0:      	blr	x9
    2ef4:      	ldr	w8, [x21, #0x2c0]
    2ef8:      	cmp	w8, #0x7e
    2efc:      	b.hi	0x35ec <perf_unwind_python+0x35ec>
    2f00:      	add	w9, w8, #0x1
    2f04:      	adrp	x0, 0x2000 <perf_unwind_python+0x2000>
    2f08:      	add	x1, sp, #0x88
    2f0c:      	str	w9, [x21, #0x2c0]
    2f10:      	mov	w9, #0x18               // =24
    2f14:      	umaddl	x8, w8, w9, x21
    2f18:      	ldr	x9, [sp, #0x8]
    2f1c:      	str	x29, [x8, #0x2d8]
    2f20:      	str	wzr, [x8, #0x2e4]
    2f24:      	str	x9, [x8, #0x2d0]
    2f28:      	mov	w9, #0x1                // =1
    2f2c:      	strb	w9, [x8, #0x2e0]
    2f30:      	add	x8, x8, #0x2d0
    2f34:      	stur	wzr, [x8, #0x11]
    2f38:      	mov	w8, #0x16               // =22
    2f3c:      	str	w8, [sp, #0x88]
    2f40:      	add	x8, sp, #0x88
    2f44:      	ldr	x0, [x0]
    2f48:      	blr	x9
    2f4c:      	cbz	x0, 0x2f60 <perf_unwind_python+0x2f60>
    2f50:      	ldr	x8, [x0]
    2f54:      	add	x8, x8, #0x1
    2f58:      	str	x8, [x0]
    2f5c:      	b	0x2fac <perf_unwind_python+0x2fac>
    2f60:      	ldr	w8, [x25]
    2f64:      	cbz	w8, 0x2fac <perf_unwind_python+0x2fac>
    2f68:      	adrp	x8, 0x2000 <perf_unwind_python+0x2000>
    2f6c:      	add	x8, x8, #0x0
    2f70:      	add	x0, sp, #0x40
    2f74:      	ldp	x9, x10, [x8, #0x10]
    2f78:      	mov	w1, #0x2e               // =46
    2f7c:      	stp	x9, x10, [sp, #0x50]
    2f80:      	ldr	x9, [x8, #0x20]
    2f84:      	add	x10, sp, #0x40
    2f88:      	str	x9, [sp, #0x60]
    2f8c:      	ldur	x9, [x8, #0x26]
    2f90:      	stur	x9, [sp, #0x66]
    2f94:      	ldp	x9, x8, [x8]
    2f98:      	stp	x9, x8, [sp, #0x40]
    2f9c:      	mov	w8, #0x2e               // =46
    2fa0:      	mov	w9, #0x6                // =6
    2fa4:      	ldr	w2, [sp, #0x88]
    2fa8:      	blr	x9
    2fac:      	ldr	w8, [sp, #0x10]
    2fb0:      	cbnz	w8, 0x36a8 <perf_unwind_python+0x36a8>
    2fb4:      	cbz	x24, 0x37b0 <perf_unwind_python+0x37b0>
    2fb8:      	ldr	x8, [sp, #0x28]
    2fbc:      	ldrb	w8, [x8, #0x19]
    2fc0:      	cmp	w8, #0x78
    2fc4:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2fc8:      	ldr	x8, [sp, #0x28]
    2fcc:      	ldrb	w8, [x8, #0x18]
    2fd0:      	cmp	w8, #0x78
    2fd4:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2fd8:      	ldr	x8, [sp, #0x28]
    2fdc:      	ldrb	w8, [x8, #0x1a]
    2fe0:      	cmp	w8, #0x78
    2fe4:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    2fe8:      	ldr	x8, [sp, #0x28]
    2fec:      	ldrsb	w8, [x8, #0x1b]
    2ff0:      	tbnz	w8, #0x1f, 0x3798 <perf_unwind_python+0x3798>
    2ff4:      	mov	w8, #0x80               // =128
    2ff8:      	mov	w9, #0x70               // =112
    2ffc:      	mov	x2, x24
    3000:      	mov	x0, x23
    3004:      	mov	w1, #0x80               // =128
    3008:      	blr	x9
    300c:      	cbnz	x0, 0xc34 <perf_unwind_python+0xc34>
    3010:      	ldr	x8, [sp, #0x28]
    3014:      	ldrb	w9, [x8, #0x19]
    3018:      	ldr	x9, [x23, x9]
    301c:      	str	x9, [sp, #0x8]
    3020:      	ldrb	w9, [x8, #0x18]
    3024:      	ldr	x8, [x8, #0x8]
    3028:      	ldr	x29, [x23, x9]
    302c:      	cbz	x8, 0x303c <perf_unwind_python+0x303c>
    3030:      	ldr	x9, [sp, #0x8]
    3034:      	cmp	x9, x8
    3038:      	b.eq	0xf58 <perf_unwind_python+0xf58>
    303c:      	ldr	x8, [sp, #0x28]
    3040:      	ldrb	w9, [x8, #0x22]
    3044:      	ldrb	w8, [x8, #0x1a]
    3048:      	cbz	w9, 0x3094 <perf_unwind_python+0x3094>
    304c:      	ldr	x9, [sp, #0x28]
    3050:      	ldr	x11, [sp, #0x8]
    3054:      	ldr	x8, [x23, x8]
    3058:      	ldrb	w10, [x9, #0x21]
    305c:      	add	x10, x11, x10
    3060:      	sub	x8, x8, x10
    3064:      	mov	x10, #-0x10000001       // =-268435457
    3068:      	add	x10, x8, x10
    306c:      	asr	w8, w8, #1
    3070:      	cmp	x10, x22
    3074:      	csinv	w19, w8, wzr, hs
    3078:      	ldrb	w8, [x9, #0x1b]
    307c:      	ldrb	w9, [x9, #0x1c]
    3080:      	ldrb	w8, [x23, x8]
    3084:      	cmp	w8, w9
    3088:      	cset	w8, eq
    308c:      	str	w8, [sp, #0x10]
    3090:      	b	0x309c <perf_unwind_python+0x309c>
    3094:      	ldr	w19, [x23, x8]
    3098:      	str	wzr, [sp, #0x10]
    309c:      	ldr	x8, [sp, #0x8]
    30a0:      	cbz	x8, 0x3140 <perf_unwind_python+0x3140>
    30a4:      	ldr	x8, [sp, #0x28]
    30a8:      	ldrb	w8, [x8, #0x1d]
    30ac:      	cmp	w8, #0xbc
    30b0:      	b.hi	0x380c <perf_unwind_python+0x380c>
    30b4:      	ldr	x8, [sp, #0x28]
    30b8:      	ldrb	w8, [x8, #0x1e]
    30bc:      	cmp	w8, #0xbc
    30c0:      	b.hi	0x380c <perf_unwind_python+0x380c>
    30c4:      	ldr	x8, [sp, #0x28]
    30c8:      	ldrb	w8, [x8, #0x1f]
    30cc:      	cmp	w8, #0xbc
    30d0:      	b.hi	0x380c <perf_unwind_python+0x380c>
    30d4:      	ldr	x8, [sp, #0x28]
    30d8:      	ldrb	w8, [x8, #0x20]
    30dc:      	cmp	w8, #0xbc
    30e0:      	b.hi	0x380c <perf_unwind_python+0x380c>
    30e4:      	ldr	x0, [sp, #0x18]
    30e8:      	ldr	x2, [sp, #0x8]
    30ec:      	mov	w8, #0xc0               // =192
    30f0:      	mov	w9, #0x70               // =112
    30f4:      	mov	w1, #0xc0               // =192
    30f8:      	blr	x9
    30fc:      	cbnz	x0, 0xa90 <perf_unwind_python+0xa90>
    3100:      	ldr	x8, [sp, #0x28]
    3104:      	ldr	x12, [sp, #0x18]
    3108:      	ldrb	w10, [x8, #0x1e]
    310c:      	ldrb	w9, [x8, #0x1d]
    3110:      	ldrb	w11, [x8, #0x1f]
    3114:      	ldrb	w8, [x8, #0x20]
    3118:      	ldr	w10, [x12, x10]
    311c:      	ldr	w9, [x12, x9]
    3120:      	ldr	w11, [x12, x11]
    3124:      	ldr	w8, [x12, x8]
    3128:      	lsl	w10, w10, #18
    312c:      	add	w9, w10, w9, lsl #25
    3130:      	add	w9, w9, w11, lsl #10
    3134:      	add	w8, w9, w8
    3138:      	orr	x19, x8, x19, lsl #32
    313c:      	b	0x3220 <perf_unwind_python+0x3220>
    3140:      	ldr	w8, [x25]
    3144:      	cbz	w8, 0x3198 <perf_unwind_python+0x3198>
    3148:      	adrp	x10, 0x3000 <perf_unwind_python+0x3000>
    314c:      	add	x10, x10, #0x0
    3150:      	add	x0, sp, #0x40
    3154:      	ldp	x8, x9, [x10, #0x10]
    3158:      	mov	w1, #0x2f               // =47
    315c:      	mov	x2, x24
    3160:      	stp	x8, x9, [sp, #0x50]
    3164:      	ldr	x8, [x10, #0x20]
    3168:      	str	x8, [sp, #0x60]
    316c:      	ldur	x8, [x10, #0x27]
    3170:      	stur	x8, [sp, #0x67]
    3174:      	ldp	x8, x9, [x10]
    3178:      	add	x10, sp, #0x40
    317c:      	stp	x8, x9, [sp, #0x40]
    3180:      	mov	w8, #0x2f               // =47
    3184:      	mov	w9, #0x6                // =6
    3188:      	ldr	x8, [sp, #0x28]
    318c:      	ldrb	w8, [x8, #0x19]
    3190:      	add	x3, x24, x8
    3194:      	blr	x9
    3198:      	mov	w8, #0x1c               // =28
    319c:      	adrp	x0, 0x3000 <perf_unwind_python+0x3000>
    31a0:      	add	x9, sp, #0x88
    31a4:      	str	w8, [sp, #0x88]
    31a8:      	mov	w8, #0x1                // =1
    31ac:      	add	x1, sp, #0x88
    31b0:      	ldr	x0, [x0]
    31b4:      	blr	x8
    31b8:      	cbz	x0, 0x31cc <perf_unwind_python+0x31cc>
    31bc:      	ldr	x8, [x0]
    31c0:      	add	x8, x8, #0x1
    31c4:      	str	x8, [x0]
    31c8:      	b	0x3218 <perf_unwind_python+0x3218>
    31cc:      	ldr	w8, [x25]
    31d0:      	cbz	w8, 0x3218 <perf_unwind_python+0x3218>
    31d4:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    31d8:      	add	x8, x8, #0x0
    31dc:      	add	x0, sp, #0x40
    31e0:      	ldp	x9, x10, [x8, #0x10]
    31e4:      	mov	w1, #0x2e               // =46
    31e8:      	stp	x9, x10, [sp, #0x50]
    31ec:      	ldr	x9, [x8, #0x20]
    31f0:      	add	x10, sp, #0x40
    31f4:      	str	x9, [sp, #0x60]
    31f8:      	ldur	x9, [x8, #0x26]
    31fc:      	stur	x9, [sp, #0x66]
    3200:      	ldp	x9, x8, [x8]
    3204:      	stp	x9, x8, [sp, #0x40]
    3208:      	mov	w8, #0x2e               // =46
    320c:      	mov	w9, #0x6                // =6
    3210:      	ldr	w2, [sp, #0x88]
    3214:      	blr	x9
    3218:      	mov	x19, #-0x2              // =-2
    321c:      	str	xzr, [sp, #0x8]
    3220:      	ldr	w8, [x25]
    3224:      	cbz	w8, 0x3260 <perf_unwind_python+0x3260>
    3228:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    322c:      	add	x8, x8, #0x0
    3230:      	add	x0, sp, #0x40
    3234:      	ldp	x9, x10, [x8]
    3238:      	ldr	x8, [x8, #0x10]
    323c:      	mov	w1, #0x18               // =24
    3240:      	mov	x3, x19
    3244:      	stp	x9, x10, [sp, #0x40]
    3248:      	str	x8, [sp, #0x50]
    324c:      	mov	w8, #0x18               // =24
    3250:      	mov	w9, #0x6                // =6
    3254:      	add	x10, sp, #0x40
    3258:      	ldr	x2, [sp, #0x8]
    325c:      	blr	x9
    3260:      	ldr	w8, [x21, #0x2c0]
    3264:      	cmp	w8, #0x7e
    3268:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    326c:      	add	w9, w8, #0x1
    3270:      	adrp	x0, 0x3000 <perf_unwind_python+0x3000>
    3274:      	add	x1, sp, #0x88
    3278:      	str	w9, [x21, #0x2c0]
    327c:      	mov	w9, #0x18               // =24
    3280:      	umaddl	x8, w8, w9, x21
    3284:      	ldr	x9, [sp, #0x8]
    3288:      	str	x19, [x8, #0x2d8]
    328c:      	str	wzr, [x8, #0x2e4]
    3290:      	str	x9, [x8, #0x2d0]
    3294:      	mov	w9, #0x1                // =1
    3298:      	strb	w9, [x8, #0x2e0]
    329c:      	add	x8, x8, #0x2d0
    32a0:      	stur	wzr, [x8, #0x11]
    32a4:      	mov	w8, #0x16               // =22
    32a8:      	str	w8, [sp, #0x88]
    32ac:      	add	x8, sp, #0x88
    32b0:      	ldr	x0, [x0]
    32b4:      	blr	x9
    32b8:      	cbz	x0, 0x32cc <perf_unwind_python+0x32cc>
    32bc:      	ldr	x8, [x0]
    32c0:      	add	x8, x8, #0x1
    32c4:      	str	x8, [x0]
    32c8:      	b	0x3318 <perf_unwind_python+0x3318>
    32cc:      	ldr	w8, [x25]
    32d0:      	cbz	w8, 0x3318 <perf_unwind_python+0x3318>
    32d4:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    32d8:      	add	x8, x8, #0x0
    32dc:      	add	x0, sp, #0x40
    32e0:      	ldp	x9, x10, [x8, #0x10]
    32e4:      	mov	w1, #0x2e               // =46
    32e8:      	stp	x9, x10, [sp, #0x50]
    32ec:      	ldr	x9, [x8, #0x20]
    32f0:      	add	x10, sp, #0x40
    32f4:      	str	x9, [sp, #0x60]
    32f8:      	ldur	x9, [x8, #0x26]
    32fc:      	stur	x9, [sp, #0x66]
    3300:      	ldp	x9, x8, [x8]
    3304:      	stp	x9, x8, [sp, #0x40]
    3308:      	mov	w8, #0x2e               // =46
    330c:      	mov	w9, #0x6                // =6
    3310:      	ldr	w2, [sp, #0x88]
    3314:      	blr	x9
    3318:      	ldr	w8, [sp, #0x10]
    331c:      	cbnz	w8, 0xf58 <perf_unwind_python+0xf58>
    3320:      	cbz	x29, 0x3400 <perf_unwind_python+0x3400>
    3324:      	ldr	x8, [sp, #0x28]
    3328:      	ldrb	w8, [x8, #0x19]
    332c:      	cmp	w8, #0x78
    3330:      	b.hi	0x380c <perf_unwind_python+0x380c>
    3334:      	ldr	x8, [sp, #0x28]
    3338:      	ldrb	w8, [x8, #0x18]
    333c:      	cmp	w8, #0x78
    3340:      	b.hi	0x380c <perf_unwind_python+0x380c>
    3344:      	ldr	x8, [sp, #0x28]
    3348:      	ldrb	w8, [x8, #0x1a]
    334c:      	cmp	w8, #0x78
    3350:      	b.hi	0x380c <perf_unwind_python+0x380c>
    3354:      	ldr	x8, [sp, #0x28]
    3358:      	ldrsb	w8, [x8, #0x1b]
    335c:      	tbnz	w8, #0x1f, 0x380c <perf_unwind_python+0x380c>
    3360:      	mov	w8, #0x80               // =128
    3364:      	mov	w9, #0x70               // =112
    3368:      	mov	x2, x29
    336c:      	mov	x0, x23
    3370:      	mov	w1, #0x80               // =128
    3374:      	blr	x9
    3378:      	cbnz	x0, 0xc38 <perf_unwind_python+0xc38>
    337c:      	ldr	x8, [sp, #0x28]
    3380:      	ldrb	w9, [x8, #0x19]
    3384:      	ldr	x9, [x23, x9]
    3388:      	str	x9, [sp, #0x8]
    338c:      	ldrb	w9, [x8, #0x18]
    3390:      	ldr	x8, [x8, #0x8]
    3394:      	ldr	x24, [x23, x9]
    3398:      	cbz	x8, 0x33a8 <perf_unwind_python+0x33a8>
    339c:      	ldr	x9, [sp, #0x8]
    33a0:      	cmp	x9, x8
    33a4:      	b.eq	0x36a8 <perf_unwind_python+0x36a8>
    33a8:      	ldr	x8, [sp, #0x28]
    33ac:      	ldrb	w9, [x8, #0x22]
    33b0:      	ldrb	w8, [x8, #0x1a]
    33b4:      	cbz	w9, 0x340c <perf_unwind_python+0x340c>
    33b8:      	ldr	x9, [sp, #0x28]
    33bc:      	ldr	x11, [sp, #0x8]
    33c0:      	ldr	x8, [x23, x8]
    33c4:      	ldrb	w10, [x9, #0x21]
    33c8:      	add	x10, x11, x10
    33cc:      	sub	x8, x8, x10
    33d0:      	mov	x10, #-0x10000001       // =-268435457
    33d4:      	add	x10, x8, x10
    33d8:      	asr	w8, w8, #1
    33dc:      	cmp	x10, x22
    33e0:      	csinv	w19, w8, wzr, hs
    33e4:      	ldrb	w8, [x9, #0x1b]
    33e8:      	ldrb	w9, [x9, #0x1c]
    33ec:      	ldrb	w8, [x23, x8]
    33f0:      	cmp	w8, w9
    33f4:      	cset	w8, eq
    33f8:      	str	w8, [sp, #0x10]
    33fc:      	b	0x3414 <perf_unwind_python+0x3414>
    3400:      	mov	w8, wzr
    3404:      	mov	w9, wzr
    3408:      	b	0x37a4 <perf_unwind_python+0x37a4>
    340c:      	ldr	w19, [x23, x8]
    3410:      	str	wzr, [sp, #0x10]
    3414:      	ldr	x8, [sp, #0x8]
    3418:      	cbz	x8, 0x3480 <perf_unwind_python+0x3480>
    341c:      	ldr	x8, [sp, #0x28]
    3420:      	ldrb	w8, [x8, #0x1d]
    3424:      	cmp	w8, #0xbc
    3428:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    342c:      	ldr	x8, [sp, #0x28]
    3430:      	ldrb	w8, [x8, #0x1e]
    3434:      	cmp	w8, #0xbc
    3438:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    343c:      	ldr	x8, [sp, #0x28]
    3440:      	ldrb	w8, [x8, #0x1f]
    3444:      	cmp	w8, #0xbc
    3448:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    344c:      	ldr	x8, [sp, #0x28]
    3450:      	ldrb	w8, [x8, #0x20]
    3454:      	cmp	w8, #0xbc
    3458:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    345c:      	ldr	x0, [sp, #0x18]
    3460:      	ldr	x2, [sp, #0x8]
    3464:      	mov	w8, #0xc0               // =192
    3468:      	mov	w9, #0x70               // =112
    346c:      	mov	w1, #0xc0               // =192
    3470:      	blr	x9
    3474:      	cbz	x0, 0x350c <perf_unwind_python+0x350c>
    3478:      	mov	x29, x24
    347c:      	b	0xa90 <perf_unwind_python+0xa90>
    3480:      	ldr	w8, [x25]
    3484:      	cbz	w8, 0x34d8 <perf_unwind_python+0x34d8>
    3488:      	adrp	x10, 0x3000 <perf_unwind_python+0x3000>
    348c:      	add	x10, x10, #0x0
    3490:      	add	x0, sp, #0x40
    3494:      	ldp	x8, x9, [x10, #0x10]
    3498:      	mov	w1, #0x2f               // =47
    349c:      	mov	x2, x29
    34a0:      	stp	x8, x9, [sp, #0x50]
    34a4:      	ldr	x8, [x10, #0x20]
    34a8:      	str	x8, [sp, #0x60]
    34ac:      	ldur	x8, [x10, #0x27]
    34b0:      	stur	x8, [sp, #0x67]
    34b4:      	ldp	x8, x9, [x10]
    34b8:      	add	x10, sp, #0x40
    34bc:      	stp	x8, x9, [sp, #0x40]
    34c0:      	mov	w8, #0x2f               // =47
    34c4:      	mov	w9, #0x6                // =6
    34c8:      	ldr	x8, [sp, #0x28]
    34cc:      	ldrb	w8, [x8, #0x19]
    34d0:      	add	x3, x29, x8
    34d4:      	blr	x9
    34d8:      	mov	w8, #0x1c               // =28
    34dc:      	adrp	x0, 0x3000 <perf_unwind_python+0x3000>
    34e0:      	add	x9, sp, #0x88
    34e4:      	str	w8, [sp, #0x88]
    34e8:      	mov	w8, #0x1                // =1
    34ec:      	add	x1, sp, #0x88
    34f0:      	ldr	x0, [x0]
    34f4:      	blr	x8
    34f8:      	cbz	x0, 0x354c <perf_unwind_python+0x354c>
    34fc:      	ldr	x8, [x0]
    3500:      	add	x8, x8, #0x1
    3504:      	str	x8, [x0]
    3508:      	b	0x3598 <perf_unwind_python+0x3598>
    350c:      	ldr	x8, [sp, #0x28]
    3510:      	ldr	x12, [sp, #0x18]
    3514:      	ldrb	w10, [x8, #0x1e]
    3518:      	ldrb	w9, [x8, #0x1d]
    351c:      	ldrb	w11, [x8, #0x1f]
    3520:      	ldrb	w8, [x8, #0x20]
    3524:      	ldr	w10, [x12, x10]
    3528:      	ldr	w9, [x12, x9]
    352c:      	ldr	w11, [x12, x11]
    3530:      	ldr	w8, [x12, x8]
    3534:      	lsl	w10, w10, #18
    3538:      	add	w9, w10, w9, lsl #25
    353c:      	add	w9, w9, w11, lsl #10
    3540:      	add	w8, w9, w8
    3544:      	orr	x29, x8, x19, lsl #32
    3548:      	b	0x35a0 <perf_unwind_python+0x35a0>
    354c:      	ldr	w8, [x25]
    3550:      	cbz	w8, 0x3598 <perf_unwind_python+0x3598>
    3554:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    3558:      	add	x8, x8, #0x0
    355c:      	add	x0, sp, #0x40
    3560:      	ldp	x9, x10, [x8, #0x10]
    3564:      	mov	w1, #0x2e               // =46
    3568:      	stp	x9, x10, [sp, #0x50]
    356c:      	ldr	x9, [x8, #0x20]
    3570:      	add	x10, sp, #0x40
    3574:      	str	x9, [sp, #0x60]
    3578:      	ldur	x9, [x8, #0x26]
    357c:      	stur	x9, [sp, #0x66]
    3580:      	ldp	x9, x8, [x8]
    3584:      	stp	x9, x8, [sp, #0x40]
    3588:      	mov	w8, #0x2e               // =46
    358c:      	mov	w9, #0x6                // =6
    3590:      	ldr	w2, [sp, #0x88]
    3594:      	blr	x9
    3598:      	mov	x29, #-0x2              // =-2
    359c:      	str	xzr, [sp, #0x8]
    35a0:      	ldr	w8, [x25]
    35a4:      	cbz	w8, 0x35e0 <perf_unwind_python+0x35e0>
    35a8:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    35ac:      	add	x8, x8, #0x0
    35b0:      	add	x0, sp, #0x40
    35b4:      	ldp	x9, x10, [x8]
    35b8:      	ldr	x8, [x8, #0x10]
    35bc:      	mov	w1, #0x18               // =24
    35c0:      	mov	x3, x29
    35c4:      	stp	x9, x10, [sp, #0x40]
    35c8:      	str	x8, [sp, #0x50]
    35cc:      	mov	w8, #0x18               // =24
    35d0:      	mov	w9, #0x6                // =6
    35d4:      	add	x10, sp, #0x40
    35d8:      	ldr	x2, [sp, #0x8]
    35dc:      	blr	x9
    35e0:      	ldr	w8, [x21, #0x2c0]
    35e4:      	cmp	w8, #0x7e
    35e8:      	b.ls	0x35f4 <perf_unwind_python+0x35f4>
    35ec:      	mov	x29, x24
    35f0:      	b	0x12c8 <perf_unwind_python+0x12c8>
    35f4:      	add	w9, w8, #0x1
    35f8:      	adrp	x0, 0x3000 <perf_unwind_python+0x3000>
    35fc:      	add	x1, sp, #0x88
    3600:      	str	w9, [x21, #0x2c0]
    3604:      	mov	w9, #0x18               // =24
    3608:      	umaddl	x8, w8, w9, x21
    360c:      	ldr	x9, [sp, #0x8]
    3610:      	str	x29, [x8, #0x2d8]
    3614:      	str	wzr, [x8, #0x2e4]
    3618:      	str	x9, [x8, #0x2d0]
    361c:      	mov	w9, #0x1                // =1
    3620:      	strb	w9, [x8, #0x2e0]
    3624:      	add	x8, x8, #0x2d0
    3628:      	stur	wzr, [x8, #0x11]
    362c:      	mov	w8, #0x16               // =22
    3630:      	str	w8, [sp, #0x88]
    3634:      	add	x8, sp, #0x88
    3638:      	ldr	x0, [x0]
    363c:      	blr	x9
    3640:      	cbz	x0, 0x3654 <perf_unwind_python+0x3654>
    3644:      	ldr	x8, [x0]
    3648:      	add	x8, x8, #0x1
    364c:      	str	x8, [x0]
    3650:      	b	0x36a0 <perf_unwind_python+0x36a0>
    3654:      	ldr	w8, [x25]
    3658:      	cbz	w8, 0x36a0 <perf_unwind_python+0x36a0>
    365c:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    3660:      	add	x8, x8, #0x0
    3664:      	add	x0, sp, #0x40
    3668:      	ldp	x9, x10, [x8, #0x10]
    366c:      	mov	w1, #0x2e               // =46
    3670:      	stp	x9, x10, [sp, #0x50]
    3674:      	ldr	x9, [x8, #0x20]
    3678:      	add	x10, sp, #0x40
    367c:      	str	x9, [sp, #0x60]
    3680:      	ldur	x9, [x8, #0x26]
    3684:      	stur	x9, [sp, #0x66]
    3688:      	ldp	x9, x8, [x8]
    368c:      	stp	x9, x8, [sp, #0x40]
    3690:      	mov	w8, #0x2e               // =46
    3694:      	mov	w9, #0x6                // =6
    3698:      	ldr	w2, [sp, #0x88]
    369c:      	blr	x9
    36a0:      	ldr	w8, [sp, #0x10]
    36a4:      	cbz	w8, 0x36b8 <perf_unwind_python+0x36b8>
    36a8:      	ldr	x22, [sp, #0x20]
    36ac:      	ldr	x19, [sp, #0x30]
    36b0:      	mov	x12, x24
    36b4:      	b	0x1ac <perf_unwind_python+0x1ac>
    36b8:      	cbz	x24, 0x37b0 <perf_unwind_python+0x37b0>
    36bc:      	ldr	x8, [sp, #0x28]
    36c0:      	ldrb	w8, [x8, #0x19]
    36c4:      	cmp	w8, #0x78
    36c8:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    36cc:      	ldr	x8, [sp, #0x28]
    36d0:      	ldrb	w8, [x8, #0x18]
    36d4:      	cmp	w8, #0x78
    36d8:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    36dc:      	ldr	x8, [sp, #0x28]
    36e0:      	ldrb	w8, [x8, #0x1a]
    36e4:      	cmp	w8, #0x78
    36e8:      	b.hi	0x3798 <perf_unwind_python+0x3798>
    36ec:      	ldr	x8, [sp, #0x28]
    36f0:      	ldrsb	w8, [x8, #0x1b]
    36f4:      	tbnz	w8, #0x1f, 0x3798 <perf_unwind_python+0x3798>
    36f8:      	mov	w8, #0x80               // =128
    36fc:      	mov	w9, #0x70               // =112
    3700:      	mov	x2, x24
    3704:      	mov	x0, x23
    3708:      	mov	w1, #0x80               // =128
    370c:      	blr	x9
    3710:      	cbnz	x0, 0xc34 <perf_unwind_python+0xc34>
    3714:      	ldr	x8, [sp, #0x28]
    3718:      	ldrb	w9, [x8, #0x19]
    371c:      	ldr	x9, [x23, x9]
    3720:      	str	x9, [sp, #0x8]
    3724:      	ldrb	w9, [x8, #0x18]
    3728:      	ldr	x8, [x8, #0x8]
    372c:      	ldr	x29, [x23, x9]
    3730:      	cbz	x8, 0x3740 <perf_unwind_python+0x3740>
    3734:      	ldr	x9, [sp, #0x8]
    3738:      	cmp	x9, x8
    373c:      	b.eq	0xf58 <perf_unwind_python+0xf58>
    3740:      	ldr	x8, [sp, #0x28]
    3744:      	ldrb	w9, [x8, #0x22]
    3748:      	ldrb	w8, [x8, #0x1a]
    374c:      	cbz	w9, 0x37bc <perf_unwind_python+0x37bc>
    3750:      	ldr	x9, [sp, #0x28]
    3754:      	ldr	x11, [sp, #0x8]
    3758:      	ldr	x8, [x23, x8]
    375c:      	ldrb	w10, [x9, #0x21]
    3760:      	add	x10, x11, x10
    3764:      	sub	x8, x8, x10
    3768:      	mov	x10, #-0x10000001       // =-268435457
    376c:      	add	x10, x8, x10
    3770:      	asr	w8, w8, #1
    3774:      	cmp	x10, x22
    3778:      	csinv	w22, w8, wzr, hs
    377c:      	ldrb	w8, [x9, #0x1b]
    3780:      	ldrb	w9, [x9, #0x1c]
    3784:      	ldrb	w8, [x23, x8]
    3788:      	cmp	w8, w9
    378c:      	cset	w8, eq
    3790:      	str	w8, [sp, #0x10]
    3794:      	b	0x37c4 <perf_unwind_python+0x37c4>
    3798:      	mov	w8, wzr
    379c:      	mov	w9, #0x1                // =1
    37a0:      	mov	x29, x24
    37a4:      	ldr	x22, [sp, #0x20]
    37a8:      	ldr	x19, [sp, #0x30]
    37ac:      	b	0x15c <perf_unwind_python+0x15c>
    37b0:      	mov	w8, wzr
    37b4:      	mov	x29, xzr
    37b8:      	b	0x3404 <perf_unwind_python+0x3404>
    37bc:      	ldr	w22, [x23, x8]
    37c0:      	str	wzr, [sp, #0x10]
    37c4:      	ldr	x8, [sp, #0x8]
    37c8:      	cbz	x8, 0x3818 <perf_unwind_python+0x3818>
    37cc:      	ldr	x8, [sp, #0x28]
    37d0:      	ldrb	w8, [x8, #0x1d]
    37d4:      	cmp	w8, #0xbc
    37d8:      	b.hi	0x380c <perf_unwind_python+0x380c>
    37dc:      	ldr	x8, [sp, #0x28]
    37e0:      	ldrb	w8, [x8, #0x1e]
    37e4:      	cmp	w8, #0xbc
    37e8:      	b.hi	0x380c <perf_unwind_python+0x380c>
    37ec:      	ldr	x8, [sp, #0x28]
    37f0:      	ldrb	w8, [x8, #0x1f]
    37f4:      	cmp	w8, #0xbc
    37f8:      	b.hi	0x380c <perf_unwind_python+0x380c>
    37fc:      	ldr	x8, [sp, #0x28]
    3800:      	ldrb	w8, [x8, #0x20]
    3804:      	cmp	w8, #0xbc
    3808:      	b.ls	0x38a4 <perf_unwind_python+0x38a4>
    380c:      	mov	w8, wzr
    3810:      	mov	w9, #0x1                // =1
    3814:      	b	0x37a4 <perf_unwind_python+0x37a4>
    3818:      	ldr	w8, [x25]
    381c:      	cbz	w8, 0x3870 <perf_unwind_python+0x3870>
    3820:      	adrp	x10, 0x3000 <perf_unwind_python+0x3000>
    3824:      	add	x10, x10, #0x0
    3828:      	add	x0, sp, #0x40
    382c:      	ldp	x8, x9, [x10, #0x10]
    3830:      	mov	w1, #0x2f               // =47
    3834:      	mov	x2, x24
    3838:      	stp	x8, x9, [sp, #0x50]
    383c:      	ldr	x8, [x10, #0x20]
    3840:      	str	x8, [sp, #0x60]
    3844:      	ldur	x8, [x10, #0x27]
    3848:      	stur	x8, [sp, #0x67]
    384c:      	ldp	x8, x9, [x10]
    3850:      	add	x10, sp, #0x40
    3854:      	stp	x8, x9, [sp, #0x40]
    3858:      	mov	w8, #0x2f               // =47
    385c:      	mov	w9, #0x6                // =6
    3860:      	ldr	x8, [sp, #0x28]
    3864:      	ldrb	w8, [x8, #0x19]
    3868:      	add	x3, x24, x8
    386c:      	blr	x9
    3870:      	mov	w8, #0x1c               // =28
    3874:      	adrp	x0, 0x3000 <perf_unwind_python+0x3000>
    3878:      	add	x9, sp, #0x88
    387c:      	str	w8, [sp, #0x88]
    3880:      	mov	w8, #0x1                // =1
    3884:      	add	x1, sp, #0x88
    3888:      	ldr	x0, [x0]
    388c:      	blr	x8
    3890:      	cbz	x0, 0x3900 <perf_unwind_python+0x3900>
    3894:      	ldr	x8, [x0]
    3898:      	add	x8, x8, #0x1
    389c:      	str	x8, [x0]
    38a0:      	b	0x394c <perf_unwind_python+0x394c>
    38a4:      	ldr	x0, [sp, #0x18]
    38a8:      	ldr	x2, [sp, #0x8]
    38ac:      	mov	w8, #0xc0               // =192
    38b0:      	mov	w9, #0x70               // =112
    38b4:      	mov	w1, #0xc0               // =192
    38b8:      	mov	x19, x0
    38bc:      	blr	x9
    38c0:      	cbnz	x0, 0xa90 <perf_unwind_python+0xa90>
    38c4:      	ldr	x8, [sp, #0x28]
    38c8:      	ldrb	w10, [x8, #0x1e]
    38cc:      	ldrb	w9, [x8, #0x1d]
    38d0:      	ldrb	w11, [x8, #0x1f]
    38d4:      	ldrb	w8, [x8, #0x20]
    38d8:      	ldr	w10, [x19, x10]
    38dc:      	ldr	w9, [x19, x9]
    38e0:      	ldr	w11, [x19, x11]
    38e4:      	ldr	w8, [x19, x8]
    38e8:      	lsl	w10, w10, #18
    38ec:      	add	w9, w10, w9, lsl #25
    38f0:      	add	w9, w9, w11, lsl #10
    38f4:      	add	w8, w9, w8
    38f8:      	orr	x23, x8, x22, lsl #32
    38fc:      	b	0x3954 <perf_unwind_python+0x3954>
    3900:      	ldr	w8, [x25]
    3904:      	cbz	w8, 0x394c <perf_unwind_python+0x394c>
    3908:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    390c:      	add	x8, x8, #0x0
    3910:      	add	x0, sp, #0x40
    3914:      	ldp	x9, x10, [x8, #0x10]
    3918:      	mov	w1, #0x2e               // =46
    391c:      	stp	x9, x10, [sp, #0x50]
    3920:      	ldr	x9, [x8, #0x20]
    3924:      	add	x10, sp, #0x40
    3928:      	str	x9, [sp, #0x60]
    392c:      	ldur	x9, [x8, #0x26]
    3930:      	stur	x9, [sp, #0x66]
    3934:      	ldp	x9, x8, [x8]
    3938:      	stp	x9, x8, [sp, #0x40]
    393c:      	mov	w8, #0x2e               // =46
    3940:      	mov	w9, #0x6                // =6
    3944:      	ldr	w2, [sp, #0x88]
    3948:      	blr	x9
    394c:      	mov	x23, #-0x2              // =-2
    3950:      	str	xzr, [sp, #0x8]
    3954:      	ldr	w8, [x25]
    3958:      	cbz	w8, 0x3994 <perf_unwind_python+0x3994>
    395c:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    3960:      	add	x8, x8, #0x0
    3964:      	add	x0, sp, #0x40
    3968:      	ldp	x9, x10, [x8]
    396c:      	ldr	x8, [x8, #0x10]
    3970:      	mov	w1, #0x18               // =24
    3974:      	mov	x3, x23
    3978:      	stp	x9, x10, [sp, #0x40]
    397c:      	str	x8, [sp, #0x50]
    3980:      	mov	w8, #0x18               // =24
    3984:      	mov	w9, #0x6                // =6
    3988:      	add	x10, sp, #0x40
    398c:      	ldr	x2, [sp, #0x8]
    3990:      	blr	x9
    3994:      	ldr	w8, [x21, #0x2c0]
    3998:      	cmp	w8, #0x7e
    399c:      	b.hi	0x12c8 <perf_unwind_python+0x12c8>
    39a0:      	add	w9, w8, #0x1
    39a4:      	adrp	x0, 0x3000 <perf_unwind_python+0x3000>
    39a8:      	add	x1, sp, #0x88
    39ac:      	str	w9, [x21, #0x2c0]
    39b0:      	mov	w9, #0x18               // =24
    39b4:      	umaddl	x8, w8, w9, x21
    39b8:      	ldr	x9, [sp, #0x8]
    39bc:      	str	x23, [x8, #0x2d8]
    39c0:      	str	wzr, [x8, #0x2e4]
    39c4:      	str	x9, [x8, #0x2d0]
    39c8:      	mov	w9, #0x1                // =1
    39cc:      	strb	w9, [x8, #0x2e0]
    39d0:      	add	x8, x8, #0x2d0
    39d4:      	stur	wzr, [x8, #0x11]
    39d8:      	mov	w8, #0x16               // =22
    39dc:      	str	w8, [sp, #0x88]
    39e0:      	add	x8, sp, #0x88
    39e4:      	ldr	x0, [x0]
    39e8:      	blr	x9
    39ec:      	cbz	x0, 0x3a00 <perf_unwind_python+0x3a00>
    39f0:      	ldr	x8, [x0]
    39f4:      	add	x8, x8, #0x1
    39f8:      	str	x8, [x0]
    39fc:      	b	0x3a4c <perf_unwind_python+0x3a4c>
    3a00:      	ldr	w8, [x25]
    3a04:      	cbz	w8, 0x3a4c <perf_unwind_python+0x3a4c>
    3a08:      	adrp	x8, 0x3000 <perf_unwind_python+0x3000>
    3a0c:      	add	x8, x8, #0x0
    3a10:      	add	x0, sp, #0x40
    3a14:      	ldp	x9, x10, [x8, #0x10]
    3a18:      	mov	w1, #0x2e               // =46
    3a1c:      	stp	x9, x10, [sp, #0x50]
    3a20:      	ldr	x9, [x8, #0x20]
    3a24:      	add	x10, sp, #0x40
    3a28:      	str	x9, [sp, #0x60]
    3a2c:      	ldur	x9, [x8, #0x26]
    3a30:      	stur	x9, [sp, #0x66]
    3a34:      	ldp	x9, x8, [x8]
    3a38:      	stp	x9, x8, [sp, #0x40]
    3a3c:      	mov	w8, #0x2e               // =46
    3a40:      	mov	w9, #0x6                // =6
    3a44:      	ldr	w2, [sp, #0x88]
    3a48:      	blr	x9
    3a4c:      	ldr	w8, [sp, #0x10]
    3a50:      	cbnz	w8, 0xf58 <perf_unwind_python+0xf58>
    3a54:      	cbz	x29, 0x3a68 <perf_unwind_python+0x3a68>
    3a58:      	ldr	x22, [sp, #0x20]
    3a5c:      	ldr	x19, [sp, #0x30]
    3a60:      	mov	w23, #0x4               // =4
    3a64:      	b	0x170 <perf_unwind_python+0x170>
    3a68:      	mov	w9, w8
    3a6c:      	b	0x37a4 <perf_unwind_python+0x37a4>

Disassembly of section kprobe/unwind_python:

0000000000000000 <kprobe_unwind_python>:
       0:      	sub	sp, sp, #0xe0
       4:      	str	x29, [sp, #0x90]
       8:      	stp	x30, x25, [sp, #0xa0]
       c:      	stp	x24, x23, [sp, #0xb0]
      10:      	stp	x22, x21, [sp, #0xc0]
      14:      	stp	x20, x19, [sp, #0xd0]
      18:      	str	wzr, [sp, #0x40]
      1c:      	adrp	x20, 0x0 <kprobe_unwind_python>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x40
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x40
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x788 <kprobe_unwind_python+0x788>
      40:      	ldr	w8, [x0]
      44:      	adrp	x25, 0x0 <kprobe_unwind_python>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0x3c]
      50:      	ldr	x25, [x25]
      54:      	ldr	w8, [x25]
      58:      	cbnz	w8, 0x448 <kprobe_unwind_python+0x448>
      5c:      	adrp	x0, 0x0 <kprobe_unwind_python>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x3c
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x3c
      70:      	blr	x8
      74:      	ldr	w8, [x25]
      78:      	cbz	x0, 0x118 <kprobe_unwind_python+0x118>
      7c:      	cbnz	w8, 0x4cc <kprobe_unwind_python+0x4cc>
      80:      	ldr	x29, [x21, #0xf48]
      84:      	add	x22, x21, #0xf48
      88:      	cbz	x29, 0x514 <kprobe_unwind_python+0x514>
      8c:      	ldrb	w8, [x0, #0x19]
      90:      	cmp	w8, #0x78
      94:      	b.hi	0x154 <kprobe_unwind_python+0x154>
      98:      	ldrb	w8, [x0, #0x18]
      9c:      	cmp	w8, #0x78
      a0:      	b.hi	0x154 <kprobe_unwind_python+0x154>
      a4:      	ldrb	w8, [x0, #0x1a]
      a8:      	cmp	w8, #0x78
      ac:      	b.hi	0x154 <kprobe_unwind_python+0x154>
      b0:      	ldrsb	w8, [x0, #0x1b]
      b4:      	tbnz	w8, #0x1f, 0x154 <kprobe_unwind_python+0x154>
      b8:      	str	x0, [sp, #0x28]
      bc:      	add	x23, x21, #0xf70
      c0:      	mov	w8, #0x80               // =128
      c4:      	mov	w9, #0x70               // =112
      c8:      	mov	x0, x23
      cc:      	mov	w1, #0x80               // =128
      d0:      	mov	x2, x29
      d4:      	blr	x9
      d8:      	cbz	x0, 0x188 <kprobe_unwind_python+0x188>
      dc:      	ldr	w8, [x25]
      e0:      	cbnz	w8, 0xc48 <kprobe_unwind_python+0xc48>
      e4:      	mov	w8, #0x1b               // =27
      e8:      	adrp	x0, 0x0 <kprobe_unwind_python>
      ec:      	add	x9, sp, #0x88
      f0:      	str	w8, [sp, #0x88]
      f4:      	mov	w8, #0x1                // =1
      f8:      	add	x1, sp, #0x88
      fc:      	ldr	x0, [x0]
     100:      	blr	x8
     104:      	cbz	x0, 0x1c4 <kprobe_unwind_python+0x1c4>
     108:      	ldr	x8, [x0]
     10c:      	add	x8, x8, #0x1
     110:      	str	x8, [x0]
     114:      	b	0x1cc <kprobe_unwind_python+0x1cc>
     118:      	cbnz	w8, 0xad0 <kprobe_unwind_python+0xad0>
     11c:      	mov	w8, #0x45               // =69
     120:      	adrp	x0, 0x0 <kprobe_unwind_python>
     124:      	add	x9, sp, #0x88
     128:      	str	w8, [sp, #0x88]
     12c:      	mov	w8, #0x1                // =1
     130:      	add	x1, sp, #0x88
     134:      	ldr	x0, [x0]
     138:      	blr	x8
     13c:      	cbz	x0, 0x178 <kprobe_unwind_python+0x178>
     140:      	ldr	x8, [x0]
     144:      	add	x8, x8, #0x1
     148:      	str	x8, [x0]
     14c:      	mov	w0, #0x7d1              // =2001
     150:      	b	0x78c <kprobe_unwind_python+0x78c>
     154:      	mov	w8, wzr
     158:      	mov	w9, #0x1                // =1
     15c:      	ldr	w10, [x21, #0x1370]
     160:      	mov	w23, w8
     164:      	orr	w10, w10, #0x10
     168:      	str	w10, [x21, #0x1370]
     16c:      	mov	w8, w9
     170:      	str	x29, [x22]
     174:      	b	0x6c4 <kprobe_unwind_python+0x6c4>
     178:      	ldr	w8, [x25]
     17c:      	cbnz	w8, 0xbb4 <kprobe_unwind_python+0xbb4>
     180:      	mov	w0, #0x7d1              // =2001
     184:      	b	0x78c <kprobe_unwind_python+0x78c>
     188:      	ldr	x8, [sp, #0x28]
     18c:      	ldrb	w9, [x8, #0x19]
     190:      	ldr	x2, [x23, x9]
     194:      	ldrb	w9, [x8, #0x18]
     198:      	ldr	x12, [x23, x9]
     19c:      	ldr	x9, [x8, #0x8]
     1a0:      	cbz	x9, 0x1d8 <kprobe_unwind_python+0x1d8>
     1a4:      	cmp	x2, x9
     1a8:      	b.ne	0x1d8 <kprobe_unwind_python+0x1d8>
     1ac:      	mov	w9, wzr
     1b0:      	mov	w8, #0x1                // =1
     1b4:      	cbz	x12, 0x22c <kprobe_unwind_python+0x22c>
     1b8:      	mov	w23, #0x1               // =1
     1bc:      	mov	x29, x12
     1c0:      	b	0x16c <kprobe_unwind_python+0x16c>
     1c4:      	ldr	w8, [x25]
     1c8:      	cbnz	w8, 0x1054 <kprobe_unwind_python+0x1054>
     1cc:      	mov	w8, wzr
     1d0:      	mov	w9, #0x7d2              // =2002
     1d4:      	b	0x15c <kprobe_unwind_python+0x15c>
     1d8:      	ldrb	w10, [x8, #0x22]
     1dc:      	ldrb	w9, [x8, #0x1a]
     1e0:      	str	x22, [sp, #0x20]
     1e4:      	cbz	w10, 0x234 <kprobe_unwind_python+0x234>
     1e8:      	ldrb	w10, [x8, #0x21]
     1ec:      	ldr	x9, [x23, x9]
     1f0:      	mov	x11, #-0x3              // =-3
     1f4:      	movk	x11, #0xefff, lsl #16
     1f8:      	add	x10, x2, x10
     1fc:      	sub	x9, x9, x10
     200:      	mov	x10, #-0x10000001       // =-268435457
     204:      	add	x10, x9, x10
     208:      	asr	w9, w9, #1
     20c:      	cmp	x10, x11
     210:      	ldrb	w10, [x8, #0x1c]
     214:      	csinv	w24, w9, wzr, hs
     218:      	ldrb	w9, [x8, #0x1b]
     21c:      	ldrb	w9, [x23, x9]
     220:      	cmp	w9, w10
     224:      	cset	w10, eq
     228:      	b	0x238 <kprobe_unwind_python+0x238>
     22c:      	mov	x29, xzr
     230:      	b	0x15c <kprobe_unwind_python+0x15c>
     234:      	ldr	w24, [x23, x9]
     238:      	add	x22, x21, #0xff0
     23c:      	cbz	x2, 0x284 <kprobe_unwind_python+0x284>
     240:      	ldrb	w9, [x8, #0x1d]
     244:      	cmp	w9, #0xbc
     248:      	b.hi	0x270 <kprobe_unwind_python+0x270>
     24c:      	ldrb	w9, [x8, #0x1e]
     250:      	cmp	w9, #0xbc
     254:      	b.hi	0x270 <kprobe_unwind_python+0x270>
     258:      	ldrb	w9, [x8, #0x1f]
     25c:      	cmp	w9, #0xbc
     260:      	b.hi	0x270 <kprobe_unwind_python+0x270>
     264:      	ldrb	w8, [x8, #0x20]
     268:      	cmp	w8, #0xbc
     26c:      	b.ls	0xa64 <kprobe_unwind_python+0xa64>
     270:      	ldr	x22, [sp, #0x20]
     274:      	mov	w8, wzr
     278:      	mov	w9, #0x1                // =1
     27c:      	mov	x29, x12
     280:      	b	0x15c <kprobe_unwind_python+0x15c>
     284:      	ldr	w8, [x25]
     288:      	mov	x24, x12
     28c:      	str	w10, [sp, #0x30]
     290:      	str	x22, [sp, #0x18]
     294:      	cbnz	w8, 0x1208 <kprobe_unwind_python+0x1208>
     298:      	mov	w8, #0x1c               // =28
     29c:      	adrp	x0, 0x0 <kprobe_unwind_python>
     2a0:      	add	x9, sp, #0x88
     2a4:      	str	w8, [sp, #0x88]
     2a8:      	mov	w8, #0x1                // =1
     2ac:      	add	x1, sp, #0x88
     2b0:      	ldr	x0, [x0]
     2b4:      	blr	x8
     2b8:      	ldr	x22, [sp, #0x20]
     2bc:      	cbz	x0, 0x398 <kprobe_unwind_python+0x398>
     2c0:      	ldr	x8, [x0]
     2c4:      	add	x8, x8, #0x1
     2c8:      	str	x8, [x0]
     2cc:      	mov	x11, x24
     2d0:      	mov	x12, xzr
     2d4:      	mov	x29, #-0x2              // =-2
     2d8:      	ldr	w8, [x25]
     2dc:      	cbz	w8, 0x3b4 <kprobe_unwind_python+0x3b4>
     2e0:      	adrp	x8, 0x0 <kprobe_unwind_python>
     2e4:      	add	x8, x8, #0x0
     2e8:      	add	x0, sp, #0x40
     2ec:      	ldp	x9, x10, [x8]
     2f0:      	ldr	x8, [x8, #0x10]
     2f4:      	mov	w1, #0x18               // =24
     2f8:      	mov	x2, x12
     2fc:      	mov	x3, x29
     300:      	stp	x9, x10, [sp, #0x40]
     304:      	str	x8, [sp, #0x50]
     308:      	mov	w8, #0x18               // =24
     30c:      	mov	w9, #0x6                // =6
     310:      	add	x10, sp, #0x40
     314:      	mov	x24, x12
     318:      	str	x11, [sp, #0x10]
     31c:      	blr	x9
     320:      	ldr	x11, [sp, #0x10]
     324:      	mov	x12, x24
     328:      	ldr	w8, [x21, #0x2c0]
     32c:      	cmp	w8, #0x7f
     330:      	b.hs	0x3c0 <kprobe_unwind_python+0x3c0>
     334:      	add	w9, w8, #0x1
     338:      	mov	w10, #0x1               // =1
     33c:      	adrp	x0, 0x0 <kprobe_unwind_python>
     340:      	str	w9, [x21, #0x2c0]
     344:      	mov	w9, #0x18               // =24
     348:      	add	x1, sp, #0x88
     34c:      	mov	x24, x11
     350:      	umaddl	x8, w8, w9, x21
     354:      	str	x12, [x8, #0x2d0]
     358:      	str	x29, [x8, #0x2d8]
     35c:      	add	x9, x8, #0x2d0
     360:      	strb	w10, [x8, #0x2e0]
     364:      	str	wzr, [x8, #0x2e4]
     368:      	mov	w8, #0x16               // =22
     36c:      	stur	wzr, [x9, #0x11]
     370:      	str	w8, [sp, #0x88]
     374:      	add	x8, sp, #0x88
     378:      	ldr	x0, [x0]
     37c:      	blr	x10
     380:      	cbz	x0, 0x488 <kprobe_unwind_python+0x488>
     384:      	ldr	x8, [x0]
     388:      	add	x8, x8, #0x1
     38c:      	str	x8, [x0]
     390:      	ldr	x8, [sp, #0x28]
     394:      	b	0x494 <kprobe_unwind_python+0x494>
     398:      	ldr	w8, [x25]
     39c:      	mov	x11, x24
     3a0:      	cbnz	w8, 0x135c <kprobe_unwind_python+0x135c>
     3a4:      	mov	x12, xzr
     3a8:      	mov	x29, #-0x2              // =-2
     3ac:      	ldr	w8, [x25]
     3b0:      	cbnz	w8, 0x2e0 <kprobe_unwind_python+0x2e0>
     3b4:      	ldr	w8, [x21, #0x2c0]
     3b8:      	cmp	w8, #0x7f
     3bc:      	b.lo	0x334 <kprobe_unwind_python+0x334>
     3c0:      	mov	x29, x11
     3c4:      	ldr	w8, [x25]
     3c8:      	cbnz	w8, 0x12d8 <kprobe_unwind_python+0x12d8>
     3cc:      	mov	w8, #0x2                // =2
     3d0:      	adrp	x0, 0x0 <kprobe_unwind_python>
     3d4:      	add	x9, sp, #0x88
     3d8:      	str	w8, [sp, #0x88]
     3dc:      	mov	w8, #0x1                // =1
     3e0:      	add	x1, sp, #0x88
     3e4:      	ldr	x0, [x0]
     3e8:      	blr	x8
     3ec:      	cbz	x0, 0x478 <kprobe_unwind_python+0x478>
     3f0:      	ldr	x8, [x0]
     3f4:      	add	x8, x8, #0x1
     3f8:      	str	x8, [x0]
     3fc:      	ldr	w8, [x25]
     400:      	cbz	w8, 0x480 <kprobe_unwind_python+0x480>
     404:      	adrp	x8, 0x0 <kprobe_unwind_python>
     408:      	add	x8, x8, #0x0
     40c:      	add	x0, sp, #0x40
     410:      	ldp	x9, x10, [x8]
     414:      	mov	w1, #0x1d               // =29
     418:      	stp	x9, x10, [sp, #0x40]
     41c:      	ldr	x9, [x8, #0x10]
     420:      	ldur	x8, [x8, #0x15]
     424:      	add	x10, sp, #0x40
     428:      	str	x9, [sp, #0x50]
     42c:      	stur	x8, [sp, #0x55]
     430:      	mov	w8, #0x1d               // =29
     434:      	mov	w9, #0x6                // =6
     438:      	blr	x9
     43c:      	mov	w8, wzr
     440:      	mov	w9, #0x2                // =2
     444:      	b	0x15c <kprobe_unwind_python+0x15c>
     448:      	adrp	x8, 0x0 <kprobe_unwind_python>
     44c:      	add	x8, x8, #0x0
     450:      	strb	wzr, [sp, #0x50]
     454:      	add	x10, sp, #0x40
     458:      	ldp	x9, x8, [x8]
     45c:      	add	x0, sp, #0x40
     460:      	mov	w1, #0x11               // =17
     464:      	stp	x9, x8, [sp, #0x40]
     468:      	mov	w8, #0x11               // =17
     46c:      	mov	w9, #0x6                // =6
     470:      	blr	x9
     474:      	b	0x5c <kprobe_unwind_python+0x5c>
     478:      	ldr	w8, [x25]
     47c:      	cbnz	w8, 0x1404 <kprobe_unwind_python+0x1404>
     480:      	mov	w9, #0x2                // =2
     484:      	b	0x15c <kprobe_unwind_python+0x15c>
     488:      	ldr	w9, [x25]
     48c:      	ldr	x8, [sp, #0x28]
     490:      	cbnz	w9, 0x1454 <kprobe_unwind_python+0x1454>
     494:      	ldr	w9, [sp, #0x30]
     498:      	mov	x12, x24
     49c:      	cbnz	w9, 0x1ac <kprobe_unwind_python+0x1ac>
     4a0:      	cbz	x12, 0xb18 <kprobe_unwind_python+0xb18>
     4a4:      	ldrb	w9, [x8, #0x19]
     4a8:      	cmp	w9, #0x78
     4ac:      	b.hi	0x4bc <kprobe_unwind_python+0x4bc>
     4b0:      	ldrb	w9, [x8, #0x18]
     4b4:      	cmp	w9, #0x78
     4b8:      	b.ls	0xbfc <kprobe_unwind_python+0xbfc>
     4bc:      	mov	w8, wzr
     4c0:      	mov	w9, #0x1                // =1
     4c4:      	mov	x29, x12
     4c8:      	b	0x15c <kprobe_unwind_python+0x15c>
     4cc:      	adrp	x8, 0x0 <kprobe_unwind_python>
     4d0:      	add	x8, x8, #0x0
     4d4:      	mov	x22, x0
     4d8:      	ldp	x9, x10, [x8]
     4dc:      	mov	w1, #0x20               // =32
     4e0:      	stp	x9, x10, [sp, #0x40]
     4e4:      	ldp	x9, x8, [x8, #0x10]
     4e8:      	add	x10, sp, #0x40
     4ec:      	stp	x9, x8, [sp, #0x50]
     4f0:      	mov	w8, #0x20               // =32
     4f4:      	mov	w9, #0x6                // =6
     4f8:      	ldrh	w2, [x0, #0x10]
     4fc:      	add	x0, sp, #0x40
     500:      	blr	x9
     504:      	mov	x0, x22
     508:      	ldr	x29, [x21, #0xf48]
     50c:      	add	x22, x21, #0xf48
     510:      	cbnz	x29, 0x8c <kprobe_unwind_python+0x8c>
     514:      	mov	w8, #0x15               // =21
     518:      	adrp	x23, 0x0 <kprobe_unwind_python>
     51c:      	add	x9, sp, #0x88
     520:      	str	w8, [sp, #0x88]
     524:      	mov	w8, #0x1                // =1
     528:      	mov	x29, x0
     52c:      	add	x1, sp, #0x88
     530:      	ldr	x23, [x23]
     534:      	mov	x0, x23
     538:      	blr	x8
     53c:      	cbz	x0, 0x550 <kprobe_unwind_python+0x550>
     540:      	ldr	x8, [x0]
     544:      	add	x8, x8, #0x1
     548:      	str	x8, [x0]
     54c:      	b	0x558 <kprobe_unwind_python+0x558>
     550:      	ldr	w8, [x25]
     554:      	cbnz	w8, 0xcac <kprobe_unwind_python+0xcac>
     558:      	mov	w8, #0x23               // =35
     55c:      	blr	x8
     560:      	adrp	x8, 0x0 <kprobe_unwind_python>
     564:      	mov	w9, #0x71               // =113
     568:      	add	x10, sp, #0x80
     56c:      	ldr	x8, [x8]
     570:      	mov	w1, #0x8                // =8
     574:      	ldr	x8, [x8]
     578:      	add	x2, x0, x8
     57c:      	mov	w8, #0x8                // =8
     580:      	add	x0, sp, #0x80
     584:      	blr	x9
     588:      	ldr	w8, [x25]
     58c:      	cbz	x0, 0x5fc <kprobe_unwind_python+0x5fc>
     590:      	cbnz	w8, 0xb78 <kprobe_unwind_python+0xb78>
     594:      	mov	w8, #0x4                // =4
     598:      	add	x9, sp, #0x88
     59c:      	add	x1, sp, #0x88
     5a0:      	str	w8, [sp, #0x88]
     5a4:      	mov	w8, #0x1                // =1
     5a8:      	mov	x0, x23
     5ac:      	blr	x8
     5b0:      	cbz	x0, 0x67c <kprobe_unwind_python+0x67c>
     5b4:      	ldr	x8, [x0]
     5b8:      	add	x8, x8, #0x1
     5bc:      	str	x8, [x0]
     5c0:      	ldr	w8, [x25]
     5c4:      	cbz	w8, 0x684 <kprobe_unwind_python+0x684>
     5c8:      	adrp	x8, 0x0 <kprobe_unwind_python>
     5cc:      	add	x8, x8, #0x0
     5d0:      	add	x0, sp, #0x40
     5d4:      	ldp	x9, x10, [x8]
     5d8:      	mov	w1, #0x20               // =32
     5dc:      	stp	x9, x10, [sp, #0x40]
     5e0:      	ldp	x9, x8, [x8, #0x10]
     5e4:      	add	x10, sp, #0x40
     5e8:      	stp	x9, x8, [sp, #0x50]
     5ec:      	mov	w8, #0x20               // =32
     5f0:      	mov	w9, #0x6                // =6
     5f4:      	blr	x9
     5f8:      	b	0x684 <kprobe_unwind_python+0x684>
     5fc:      	str	x19, [sp, #0x30]
     600:      	mov	x19, x25
     604:      	mov	x25, x22
     608:      	cbnz	w8, 0xcf4 <kprobe_unwind_python+0xcf4>
     60c:      	ldr	x24, [x29]
     610:      	ldr	x22, [sp, #0x80]
     614:      	mov	w8, #0x4                // =4
     618:      	mov	w9, #0x70               // =112
     61c:      	add	x10, sp, #0x98
     620:      	add	x0, sp, #0x98
     624:      	mov	w1, #0x4                // =4
     628:      	mov	x2, x24
     62c:      	blr	x9
     630:      	cbz	x0, 0x7a8 <kprobe_unwind_python+0x7a8>
     634:      	ldr	w8, [x19]
     638:      	mov	x25, x19
     63c:      	cbnz	w8, 0xd80 <kprobe_unwind_python+0xd80>
     640:      	mov	w8, #0x46               // =70
     644:      	add	x9, sp, #0x88
     648:      	add	x1, sp, #0x88
     64c:      	str	w8, [sp, #0x88]
     650:      	mov	w8, #0x1                // =1
     654:      	mov	x0, x23
     658:      	blr	x8
     65c:      	ldr	x19, [sp, #0x30]
     660:      	cbz	x0, 0x85c <kprobe_unwind_python+0x85c>
     664:      	ldr	x8, [x0]
     668:      	mov	w23, #0x1               // =1
     66c:      	add	x8, x8, #0x1
     670:      	str	x8, [x0]
     674:      	mov	w8, #0x7d7              // =2007
     678:      	b	0x6c4 <kprobe_unwind_python+0x6c4>
     67c:      	ldr	w8, [x25]
     680:      	cbnz	w8, 0xdc0 <kprobe_unwind_python+0xdc0>
     684:      	mov	w8, #0x48               // =72
     688:      	add	x9, sp, #0x88
     68c:      	add	x1, sp, #0x88
     690:      	str	w8, [sp, #0x88]
     694:      	mov	w8, #0x1                // =1
     698:      	mov	x0, x23
     69c:      	blr	x8
     6a0:      	cbz	x0, 0x6b4 <kprobe_unwind_python+0x6b4>
     6a4:      	ldr	x8, [x0]
     6a8:      	add	x8, x8, #0x1
     6ac:      	str	x8, [x0]
     6b0:      	b	0x6bc <kprobe_unwind_python+0x6bc>
     6b4:      	ldr	w8, [x25]
     6b8:      	cbnz	w8, 0xe10 <kprobe_unwind_python+0xe10>
     6bc:      	mov	w8, #0x7d8              // =2008
     6c0:      	mov	w23, #0x1               // =1
     6c4:      	str	w8, [x21, #0xf1c]
     6c8:      	str	wzr, [sp, #0x40]
     6cc:      	mov	w8, #0x1                // =1
     6d0:      	add	x9, sp, #0x40
     6d4:      	add	x1, sp, #0x40
     6d8:      	mov	x0, x20
     6dc:      	blr	x8
     6e0:      	cbz	x0, 0x734 <kprobe_unwind_python+0x734>
     6e4:      	mov	w20, #0x1374            // =4980
     6e8:      	ldrb	w8, [x0, x20]
     6ec:      	cmp	w8, #0x1d
     6f0:      	b.lo	0x764 <kprobe_unwind_python+0x764>
     6f4:      	mov	w8, #0x5                // =5
     6f8:      	mov	x21, x0
     6fc:      	add	x9, sp, #0x88
     700:      	str	w8, [x0, #0xf1c]
     704:      	mov	w8, #0x44               // =68
     708:      	adrp	x0, 0x0 <kprobe_unwind_python>
     70c:      	add	x1, sp, #0x88
     710:      	str	w8, [sp, #0x88]
     714:      	mov	w8, #0x1                // =1
     718:      	ldr	x0, [x0]
     71c:      	blr	x8
     720:      	cbz	x0, 0x750 <kprobe_unwind_python+0x750>
     724:      	ldr	x8, [x0]
     728:      	add	x8, x8, #0x1
     72c:      	str	x8, [x0]
     730:      	b	0x758 <kprobe_unwind_python+0x758>
     734:      	adrp	x1, 0x0 <kprobe_unwind_python>
     738:      	mov	x8, xzr
     73c:      	mov	w9, #0xc                // =12
     740:      	ldr	x1, [x1]
     744:      	mov	x0, x19
     748:      	mov	w2, wzr
     74c:      	b	0x784 <kprobe_unwind_python+0x784>
     750:      	ldr	w8, [x25]
     754:      	cbnz	w8, 0xd38 <kprobe_unwind_python+0xd38>
     758:      	ldrb	w8, [x21, x20]
     75c:      	mov	w23, wzr
     760:      	mov	x0, x21
     764:      	add	w8, w8, #0x1
     768:      	adrp	x1, 0x0 <kprobe_unwind_python>
     76c:      	mov	w9, #0xc                // =12
     770:      	strb	w8, [x0, x20]
     774:      	mov	w8, w23
     778:      	mov	x0, x19
     77c:      	mov	w2, w23
     780:      	ldr	x1, [x1]
     784:      	blr	x9
     788:      	mov	w0, #-0x1               // =-1
     78c:      	ldp	x20, x19, [sp, #0xd0]
     790:      	ldr	x29, [sp, #0x90]
     794:      	ldp	x22, x21, [sp, #0xc0]
     798:      	ldp	x24, x23, [sp, #0xb0]
     79c:      	ldp	x30, x25, [sp, #0xa0]
     7a0:      	add	sp, sp, #0xe0
     7a4:      	ret
     7a8:      	ldrsh	x8, [x29, #0x12]
     7ac:      	ldrsw	x24, [sp, #0x98]
     7b0:      	add	x8, x22, x8
     7b4:      	ldrb	w10, [x29, #0x15]
     7b8:      	str	x8, [sp, #0x88]
     7bc:      	cbz	w10, 0x7e4 <kprobe_unwind_python+0x7e4>
     7c0:      	mov	w9, #0x8                // =8
     7c4:      	mov	w10, #0x70              // =112
     7c8:      	add	x11, sp, #0x88
     7cc:      	ldr	x2, [sp, #0x88]
     7d0:      	add	x0, sp, #0x88
     7d4:      	mov	w1, #0x8                // =8
     7d8:      	blr	x10
     7dc:      	cbnz	x0, 0x81c <kprobe_unwind_python+0x81c>
     7e0:      	ldr	x8, [sp, #0x88]
     7e4:      	mov	x9, x29
     7e8:      	ldrb	w9, [x29, #0x14]
     7ec:      	smaddl	x8, w24, w9, x8
     7f0:      	ldr	w9, [x19]
     7f4:      	str	x8, [sp, #0x88]
     7f8:      	cbnz	w9, 0xee0 <kprobe_unwind_python+0xee0>
     7fc:      	mov	w9, #0x8                // =8
     800:      	mov	w10, #0x70              // =112
     804:      	add	x11, sp, #0x78
     808:      	ldr	x2, [sp, #0x88]
     80c:      	add	x0, sp, #0x78
     810:      	mov	w1, #0x8                // =8
     814:      	blr	x10
     818:      	cbz	x0, 0x8bc <kprobe_unwind_python+0x8bc>
     81c:      	ldr	w8, [x19]
     820:      	mov	x25, x19
     824:      	cbnz	w8, 0xe58 <kprobe_unwind_python+0xe58>
     828:      	mov	w8, #0x3                // =3
     82c:      	add	x9, sp, #0x9c
     830:      	add	x1, sp, #0x9c
     834:      	str	w8, [sp, #0x9c]
     838:      	mov	w8, #0x1                // =1
     83c:      	mov	x0, x23
     840:      	blr	x8
     844:      	ldr	x19, [sp, #0x30]
     848:      	cbz	x0, 0x86c <kprobe_unwind_python+0x86c>
     84c:      	ldr	x8, [x0]
     850:      	add	x8, x8, #0x1
     854:      	str	x8, [x0]
     858:      	b	0x874 <kprobe_unwind_python+0x874>
     85c:      	ldr	w8, [x25]
     860:      	cbnz	w8, 0xe98 <kprobe_unwind_python+0xe98>
     864:      	mov	w8, #0x7d7              // =2007
     868:      	b	0x6c0 <kprobe_unwind_python+0x6c0>
     86c:      	ldr	w8, [x25]
     870:      	cbnz	w8, 0xf68 <kprobe_unwind_python+0xf68>
     874:      	mov	w8, #0x47               // =71
     878:      	add	x9, sp, #0x88
     87c:      	add	x1, sp, #0x88
     880:      	str	w8, [sp, #0x88]
     884:      	mov	w8, #0x1                // =1
     888:      	mov	x0, x23
     88c:      	blr	x8
     890:      	cbz	x0, 0x8ac <kprobe_unwind_python+0x8ac>
     894:      	ldr	x8, [x0]
     898:      	mov	w23, #0x1               // =1
     89c:      	add	x8, x8, #0x1
     8a0:      	str	x8, [x0]
     8a4:      	mov	w8, #0x7d4              // =2004
     8a8:      	b	0x6c4 <kprobe_unwind_python+0x6c4>
     8ac:      	ldr	w8, [x25]
     8b0:      	cbnz	w8, 0xfb0 <kprobe_unwind_python+0xfb0>
     8b4:      	mov	w8, #0x7d4              // =2004
     8b8:      	b	0x6c0 <kprobe_unwind_python+0x6c0>
     8bc:      	ldr	x8, [sp, #0x78]
     8c0:      	cbz	x8, 0x93c <kprobe_unwind_python+0x93c>
     8c4:      	ldrb	w10, [x29, #0x16]
     8c8:      	mov	w11, #0x70              // =112
     8cc:      	mov	x0, x25
     8d0:      	mov	w1, #0x8                // =8
     8d4:      	mov	x22, x25
     8d8:      	add	x8, x8, x10
     8dc:      	mov	w10, #0x8               // =8
     8e0:      	ldr	x8, [sp, #0x78]
     8e4:      	ldrb	w9, [x29, #0x16]
     8e8:      	add	x2, x8, x9
     8ec:      	blr	x11
     8f0:      	cbz	x0, 0x984 <kprobe_unwind_python+0x984>
     8f4:      	ldr	w8, [x19]
     8f8:      	mov	x25, x19
     8fc:      	cbnz	w8, 0x109c <kprobe_unwind_python+0x109c>
     900:      	mov	w8, #0x19               // =25
     904:      	add	x9, sp, #0x88
     908:      	add	x1, sp, #0x88
     90c:      	str	w8, [sp, #0x88]
     910:      	mov	w8, #0x1                // =1
     914:      	mov	x0, x23
     918:      	blr	x8
     91c:      	ldr	x19, [sp, #0x30]
     920:      	cbz	x0, 0xa08 <kprobe_unwind_python+0xa08>
     924:      	ldr	x8, [x0]
     928:      	mov	w23, #0x1               // =1
     92c:      	add	x8, x8, #0x1
     930:      	str	x8, [x0]
     934:      	mov	w8, #0x7d6              // =2006
     938:      	b	0x6c4 <kprobe_unwind_python+0x6c4>
     93c:      	ldr	w8, [x19]
     940:      	mov	x25, x19
     944:      	cbnz	w8, 0x11d4 <kprobe_unwind_python+0x11d4>
     948:      	mov	w8, #0x18               // =24
     94c:      	add	x9, sp, #0x88
     950:      	add	x1, sp, #0x88
     954:      	str	w8, [sp, #0x88]
     958:      	mov	w8, #0x1                // =1
     95c:      	mov	x0, x23
     960:      	blr	x8
     964:      	ldr	x19, [sp, #0x30]
     968:      	cbz	x0, 0xa44 <kprobe_unwind_python+0xa44>
     96c:      	ldr	x8, [x0]
     970:      	mov	w23, #0x1               // =1
     974:      	add	x8, x8, #0x1
     978:      	str	x8, [x0]
     97c:      	mov	w8, #0x7d5              // =2005
     980:      	b	0x6c4 <kprobe_unwind_python+0x6c4>
     984:      	ldrb	w8, [x29, #0x23]
     988:      	mov	x0, x29
     98c:      	mov	x25, x19
     990:      	cbz	w8, 0xa18 <kprobe_unwind_python+0xa18>
     994:      	ldr	x8, [x22]
     998:      	ldrb	w9, [x0, #0x17]
     99c:      	mov	w10, #0x70              // =112
     9a0:      	mov	w1, #0x8                // =8
     9a4:      	add	x8, x8, x9
     9a8:      	mov	w9, #0x8                // =8
     9ac:      	ldr	x8, [x22]
     9b0:      	ldrb	w9, [x0, #0x17]
     9b4:      	mov	x0, x22
     9b8:      	add	x2, x8, x9
     9bc:      	blr	x10
     9c0:      	mov	x8, x0
     9c4:      	mov	x0, x29
     9c8:      	cbz	x8, 0xa18 <kprobe_unwind_python+0xa18>
     9cc:      	ldr	w8, [x25]
     9d0:      	ldr	x19, [sp, #0x30]
     9d4:      	cbnz	w8, 0x13b8 <kprobe_unwind_python+0x13b8>
     9d8:      	mov	w8, #0x43               // =67
     9dc:      	add	x9, sp, #0x88
     9e0:      	add	x1, sp, #0x88
     9e4:      	str	w8, [sp, #0x88]
     9e8:      	mov	w8, #0x1                // =1
     9ec:      	mov	x0, x23
     9f0:      	blr	x8
     9f4:      	cbz	x0, 0xa54 <kprobe_unwind_python+0xa54>
     9f8:      	ldr	x8, [x0]
     9fc:      	add	x8, x8, #0x1
     a00:      	str	x8, [x0]
     a04:      	b	0xa5c <kprobe_unwind_python+0xa5c>
     a08:      	ldr	w8, [x25]
     a0c:      	cbnz	w8, 0x125c <kprobe_unwind_python+0x125c>
     a10:      	mov	w8, #0x7d6              // =2006
     a14:      	b	0x6c0 <kprobe_unwind_python+0x6c0>
     a18:      	ldr	x29, [x22]
     a1c:      	ldr	x19, [sp, #0x30]
     a20:      	cbnz	x29, 0x8c <kprobe_unwind_python+0x8c>
     a24:      	ldr	w8, [x25]
     a28:      	cbnz	w8, 0x149c <kprobe_unwind_python+0x149c>
     a2c:      	ldr	w9, [x21, #0x1370]
     a30:      	mov	w8, wzr
     a34:      	mov	w23, #0x1               // =1
     a38:      	orr	w9, w9, #0x10
     a3c:      	str	w9, [x21, #0x1370]
     a40:      	b	0x6c4 <kprobe_unwind_python+0x6c4>
     a44:      	ldr	w8, [x25]
     a48:      	cbnz	w8, 0x1314 <kprobe_unwind_python+0x1314>
     a4c:      	mov	w8, #0x7d5              // =2005
     a50:      	b	0x6c0 <kprobe_unwind_python+0x6c0>
     a54:      	ldr	w8, [x25]
     a58:      	cbnz	w8, 0x14d0 <kprobe_unwind_python+0x14d0>
     a5c:      	mov	w8, #0x7d3              // =2003
     a60:      	b	0x6c0 <kprobe_unwind_python+0x6c0>
     a64:      	str	w10, [sp, #0x30]
     a68:      	str	x12, [sp, #0x10]
     a6c:      	mov	w8, #0xc0               // =192
     a70:      	mov	w9, #0x70               // =112
     a74:      	mov	x0, x22
     a78:      	mov	w1, #0xc0               // =192
     a7c:      	str	x2, [sp, #0x8]
     a80:      	blr	x9
     a84:      	cbz	x0, 0xb28 <kprobe_unwind_python+0xb28>
     a88:      	str	x19, [sp, #0x30]
     a8c:      	ldr	x29, [sp, #0x10]
     a90:      	ldr	w8, [x25]
     a94:      	mov	x19, x25
     a98:      	cbnz	w8, 0x1518 <kprobe_unwind_python+0x1518>
     a9c:      	mov	w8, #0x1e               // =30
     aa0:      	adrp	x0, 0x0 <kprobe_unwind_python>
     aa4:      	add	x9, sp, #0x88
     aa8:      	str	w8, [sp, #0x88]
     aac:      	mov	w8, #0x1                // =1
     ab0:      	add	x1, sp, #0x88
     ab4:      	ldr	x0, [x0]
     ab8:      	blr	x8
     abc:      	cbz	x0, 0xc8c <kprobe_unwind_python+0xc8c>
     ac0:      	ldr	x8, [x0]
     ac4:      	add	x8, x8, #0x1
     ac8:      	str	x8, [x0]
     acc:      	b	0xc94 <kprobe_unwind_python+0xc94>
     ad0:      	mov	w8, #0x6f66             // =28518
     ad4:      	add	x0, sp, #0x40
     ad8:      	mov	w1, #0x2b               // =43
     adc:      	movk	w8, #0xa, lsl #16
     ae0:      	stur	w8, [sp, #0x67]
     ae4:      	adrp	x8, 0x0 <kprobe_unwind_python>
     ae8:      	add	x8, x8, #0x0
     aec:      	ldp	x9, x10, [x8, #0x10]
     af0:      	stp	x9, x10, [sp, #0x50]
     af4:      	ldr	x9, [x8, #0x20]
     af8:      	add	x10, sp, #0x40
     afc:      	str	x9, [sp, #0x60]
     b00:      	ldp	x8, x9, [x8]
     b04:      	stp	x8, x9, [sp, #0x40]
     b08:      	mov	w8, #0x2b               // =43
     b0c:      	mov	w9, #0x6                // =6
     b10:      	blr	x9
     b14:      	b	0x11c <kprobe_unwind_python+0x11c>
     b18:      	mov	w8, wzr
     b1c:      	mov	x29, xzr
     b20:      	mov	w9, wzr
     b24:      	b	0x15c <kprobe_unwind_python+0x15c>
     b28:      	ldr	x8, [sp, #0x28]
     b2c:      	str	x22, [sp, #0x18]
     b30:      	ldrb	w10, [x8, #0x1e]
     b34:      	ldrb	w9, [x8, #0x1d]
     b38:      	ldrb	w11, [x8, #0x1f]
     b3c:      	ldrb	w8, [x8, #0x20]
     b40:      	ldr	w10, [x22, x10]
     b44:      	ldr	w9, [x22, x9]
     b48:      	ldr	w11, [x22, x11]
     b4c:      	ldr	w8, [x22, x8]
     b50:      	ldr	x22, [sp, #0x20]
     b54:      	lsl	w10, w10, #18
     b58:      	add	w9, w10, w9, lsl #25
     b5c:      	add	w9, w9, w11, lsl #10
     b60:      	add	w8, w9, w8
     b64:      	ldp	x12, x11, [sp, #0x8]
     b68:      	orr	x29, x8, x24, lsl #32
     b6c:      	ldr	w8, [x25]
     b70:      	cbz	w8, 0x3b4 <kprobe_unwind_python+0x3b4>
     b74:      	b	0x2e0 <kprobe_unwind_python+0x2e0>
     b78:      	adrp	x8, 0x0 <kprobe_unwind_python>
     b7c:      	add	x8, x8, #0x0
     b80:      	add	x0, sp, #0x40
     b84:      	ldp	x9, x10, [x8]
     b88:      	mov	w1, #0x1d               // =29
     b8c:      	stp	x9, x10, [sp, #0x40]
     b90:      	ldr	x9, [x8, #0x10]
     b94:      	ldur	x8, [x8, #0x15]
     b98:      	add	x10, sp, #0x40
     b9c:      	str	x9, [sp, #0x50]
     ba0:      	stur	x8, [sp, #0x55]
     ba4:      	mov	w8, #0x1d               // =29
     ba8:      	mov	w9, #0x6                // =6
     bac:      	blr	x9
     bb0:      	b	0x594 <kprobe_unwind_python+0x594>
     bb4:      	adrp	x8, 0x0 <kprobe_unwind_python>
     bb8:      	add	x8, x8, #0x0
     bbc:      	add	x0, sp, #0x40
     bc0:      	ldp	x9, x10, [x8, #0x10]
     bc4:      	mov	w1, #0x2e               // =46
     bc8:      	stp	x9, x10, [sp, #0x50]
     bcc:      	ldr	x9, [x8, #0x20]
     bd0:      	add	x10, sp, #0x40
     bd4:      	str	x9, [sp, #0x60]
     bd8:      	ldur	x9, [x8, #0x26]
     bdc:      	stur	x9, [sp, #0x66]
     be0:      	ldp	x9, x8, [x8]
     be4:      	stp	x9, x8, [sp, #0x40]
     be8:      	mov	w8, #0x2e               // =46
     bec:      	mov	w9, #0x6                // =6
     bf0:      	ldr	w2, [sp, #0x88]
     bf4:      	blr	x9
     bf8:      	b	0x180 <kprobe_unwind_python+0x180>
     bfc:      	ldrb	w8, [x8, #0x1a]
     c00:      	str	x19, [sp, #0x30]
     c04:      	cmp	w8, #0x78
     c08:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
     c0c:      	ldr	x8, [sp, #0x28]
     c10:      	ldrsb	w8, [x8, #0x1b]
     c14:      	tbnz	w8, #0x1f, 0x3798 <kprobe_unwind_python+0x3798>
     c18:      	mov	w8, #0x80               // =128
     c1c:      	mov	w9, #0x70               // =112
     c20:      	mov	x2, x24
     c24:      	mov	x0, x23
     c28:      	mov	w1, #0x80               // =128
     c2c:      	blr	x9
     c30:      	cbz	x0, 0xf2c <kprobe_unwind_python+0xf2c>
     c34:      	mov	x29, x24
     c38:      	ldr	x22, [sp, #0x20]
     c3c:      	ldr	x19, [sp, #0x30]
     c40:      	ldr	w8, [x25]
     c44:      	cbz	w8, 0xe4 <kprobe_unwind_python+0xe4>
     c48:      	mov	w8, #0x786c             // =30828
     c4c:      	add	x0, sp, #0x40
     c50:      	mov	w1, #0x24               // =36
     c54:      	mov	x2, x29
     c58:      	movk	w8, #0xa, lsl #16
     c5c:      	str	w8, [sp, #0x60]
     c60:      	adrp	x8, 0x0 <kprobe_unwind_python>
     c64:      	add	x8, x8, #0x0
     c68:      	ldp	x9, x10, [x8]
     c6c:      	stp	x9, x10, [sp, #0x40]
     c70:      	ldp	x9, x8, [x8, #0x10]
     c74:      	add	x10, sp, #0x40
     c78:      	stp	x9, x8, [sp, #0x50]
     c7c:      	mov	w8, #0x24               // =36
     c80:      	mov	w9, #0x6                // =6
     c84:      	blr	x9
     c88:      	b	0xe4 <kprobe_unwind_python+0xe4>
     c8c:      	ldr	w8, [x19]
     c90:      	cbnz	w8, 0x1558 <kprobe_unwind_python+0x1558>
     c94:      	ldr	x22, [sp, #0x20]
     c98:      	mov	x25, x19
     c9c:      	ldr	x19, [sp, #0x30]
     ca0:      	mov	w8, wzr
     ca4:      	mov	w9, #0x7d0              // =2000
     ca8:      	b	0x15c <kprobe_unwind_python+0x15c>
     cac:      	adrp	x8, 0x0 <kprobe_unwind_python>
     cb0:      	add	x8, x8, #0x0
     cb4:      	add	x0, sp, #0x40
     cb8:      	ldp	x9, x10, [x8, #0x10]
     cbc:      	mov	w1, #0x2e               // =46
     cc0:      	stp	x9, x10, [sp, #0x50]
     cc4:      	ldr	x9, [x8, #0x20]
     cc8:      	add	x10, sp, #0x40
     ccc:      	str	x9, [sp, #0x60]
     cd0:      	ldur	x9, [x8, #0x26]
     cd4:      	stur	x9, [sp, #0x66]
     cd8:      	ldp	x9, x8, [x8]
     cdc:      	stp	x9, x8, [sp, #0x40]
     ce0:      	mov	w8, #0x2e               // =46
     ce4:      	mov	w9, #0x6                // =6
     ce8:      	ldr	w2, [sp, #0x88]
     cec:      	blr	x9
     cf0:      	b	0x558 <kprobe_unwind_python+0x558>
     cf4:      	adrp	x8, 0x0 <kprobe_unwind_python>
     cf8:      	add	x8, x8, #0x0
     cfc:      	add	x0, sp, #0x40
     d00:      	ldp	x9, x10, [x8, #0x10]
     d04:      	mov	w1, #0x26               // =38
     d08:      	stp	x9, x10, [sp, #0x50]
     d0c:      	ldur	x9, [x8, #0x1e]
     d10:      	add	x10, sp, #0x40
     d14:      	stur	x9, [sp, #0x5e]
     d18:      	ldp	x8, x9, [x8]
     d1c:      	stp	x8, x9, [sp, #0x40]
     d20:      	mov	w8, #0x26               // =38
     d24:      	mov	w9, #0x6                // =6
     d28:      	ldr	x2, [sp, #0x80]
     d2c:      	ldr	x3, [x29]
     d30:      	blr	x9
     d34:      	b	0x60c <kprobe_unwind_python+0x60c>
     d38:      	adrp	x8, 0x0 <kprobe_unwind_python>
     d3c:      	add	x8, x8, #0x0
     d40:      	add	x0, sp, #0x40
     d44:      	ldp	x9, x10, [x8, #0x10]
     d48:      	mov	w1, #0x2e               // =46
     d4c:      	stp	x9, x10, [sp, #0x50]
     d50:      	ldr	x9, [x8, #0x20]
     d54:      	add	x10, sp, #0x40
     d58:      	str	x9, [sp, #0x60]
     d5c:      	ldur	x9, [x8, #0x26]
     d60:      	stur	x9, [sp, #0x66]
     d64:      	ldp	x9, x8, [x8]
     d68:      	stp	x9, x8, [sp, #0x40]
     d6c:      	mov	w8, #0x2e               // =46
     d70:      	mov	w9, #0x6                // =6
     d74:      	ldr	w2, [sp, #0x88]
     d78:      	blr	x9
     d7c:      	b	0x758 <kprobe_unwind_python+0x758>
     d80:      	adrp	x8, 0x0 <kprobe_unwind_python>
     d84:      	add	x8, x8, #0x0
     d88:      	add	x0, sp, #0x40
     d8c:      	ldp	x9, x10, [x8, #0x10]
     d90:      	mov	w1, #0x26               // =38
     d94:      	mov	x2, x24
     d98:      	stp	x9, x10, [sp, #0x50]
     d9c:      	ldur	x9, [x8, #0x1e]
     da0:      	add	x10, sp, #0x40
     da4:      	stur	x9, [sp, #0x5e]
     da8:      	ldp	x8, x9, [x8]
     dac:      	stp	x8, x9, [sp, #0x40]
     db0:      	mov	w8, #0x26               // =38
     db4:      	mov	w9, #0x6                // =6
     db8:      	blr	x9
     dbc:      	b	0x640 <kprobe_unwind_python+0x640>
     dc0:      	adrp	x8, 0x0 <kprobe_unwind_python>
     dc4:      	add	x8, x8, #0x0
     dc8:      	add	x0, sp, #0x40
     dcc:      	ldp	x9, x10, [x8, #0x10]
     dd0:      	mov	w1, #0x2e               // =46
     dd4:      	stp	x9, x10, [sp, #0x50]
     dd8:      	ldr	x9, [x8, #0x20]
     ddc:      	add	x10, sp, #0x40
     de0:      	str	x9, [sp, #0x60]
     de4:      	ldur	x9, [x8, #0x26]
     de8:      	stur	x9, [sp, #0x66]
     dec:      	ldp	x9, x8, [x8]
     df0:      	stp	x9, x8, [sp, #0x40]
     df4:      	mov	w8, #0x2e               // =46
     df8:      	mov	w9, #0x6                // =6
     dfc:      	ldr	w2, [sp, #0x88]
     e00:      	blr	x9
     e04:      	ldr	w8, [x25]
     e08:      	cbz	w8, 0x684 <kprobe_unwind_python+0x684>
     e0c:      	b	0x5c8 <kprobe_unwind_python+0x5c8>
     e10:      	adrp	x8, 0x0 <kprobe_unwind_python>
     e14:      	add	x8, x8, #0x0
     e18:      	add	x0, sp, #0x40
     e1c:      	ldp	x9, x10, [x8, #0x10]
     e20:      	mov	w1, #0x2e               // =46
     e24:      	stp	x9, x10, [sp, #0x50]
     e28:      	ldr	x9, [x8, #0x20]
     e2c:      	add	x10, sp, #0x40
     e30:      	str	x9, [sp, #0x60]
     e34:      	ldur	x9, [x8, #0x26]
     e38:      	stur	x9, [sp, #0x66]
     e3c:      	ldp	x9, x8, [x8]
     e40:      	stp	x9, x8, [sp, #0x40]
     e44:      	mov	w8, #0x2e               // =46
     e48:      	mov	w9, #0x6                // =6
     e4c:      	ldr	w2, [sp, #0x88]
     e50:      	blr	x9
     e54:      	b	0x6bc <kprobe_unwind_python+0x6bc>
     e58:      	adrp	x8, 0x0 <kprobe_unwind_python>
     e5c:      	add	x8, x8, #0x0
     e60:      	add	x0, sp, #0x40
     e64:      	ldp	x9, x10, [x8]
     e68:      	mov	w1, #0x1f               // =31
     e6c:      	stp	x9, x10, [sp, #0x40]
     e70:      	ldr	x9, [x8, #0x10]
     e74:      	ldur	x8, [x8, #0x17]
     e78:      	add	x10, sp, #0x40
     e7c:      	str	x9, [sp, #0x50]
     e80:      	stur	x8, [sp, #0x57]
     e84:      	mov	w8, #0x1f               // =31
     e88:      	mov	w9, #0x6                // =6
     e8c:      	ldr	x2, [sp, #0x88]
     e90:      	blr	x9
     e94:      	b	0x828 <kprobe_unwind_python+0x828>
     e98:      	adrp	x8, 0x0 <kprobe_unwind_python>
     e9c:      	add	x8, x8, #0x0
     ea0:      	add	x0, sp, #0x40
     ea4:      	ldp	x9, x10, [x8, #0x10]
     ea8:      	mov	w1, #0x2e               // =46
     eac:      	stp	x9, x10, [sp, #0x50]
     eb0:      	ldr	x9, [x8, #0x20]
     eb4:      	add	x10, sp, #0x40
     eb8:      	str	x9, [sp, #0x60]
     ebc:      	ldur	x9, [x8, #0x26]
     ec0:      	stur	x9, [sp, #0x66]
     ec4:      	ldp	x9, x8, [x8]
     ec8:      	stp	x9, x8, [sp, #0x40]
     ecc:      	mov	w8, #0x2e               // =46
     ed0:      	mov	w9, #0x6                // =6
     ed4:      	ldr	w2, [sp, #0x88]
     ed8:      	blr	x9
     edc:      	b	0x864 <kprobe_unwind_python+0x864>
     ee0:      	mov	w8, #0x786c             // =30828
     ee4:      	add	x0, sp, #0x40
     ee8:      	mov	w1, #0x23               // =35
     eec:      	mov	w2, w24
     ef0:      	movk	w8, #0xa, lsl #16
     ef4:      	stur	w8, [sp, #0x5f]
     ef8:      	adrp	x8, 0x0 <kprobe_unwind_python>
     efc:      	add	x8, x8, #0x0
     f00:      	ldp	x9, x10, [x8]
     f04:      	stp	x9, x10, [sp, #0x40]
     f08:      	ldp	x9, x8, [x8, #0x10]
     f0c:      	add	x10, sp, #0x40
     f10:      	stp	x9, x8, [sp, #0x50]
     f14:      	mov	w8, #0x23               // =35
     f18:      	mov	w9, #0x6                // =6
     f1c:      	ldr	x3, [sp, #0x88]
     f20:      	blr	x9
     f24:      	ldr	x8, [sp, #0x88]
     f28:      	b	0x7fc <kprobe_unwind_python+0x7fc>
     f2c:      	ldr	x8, [sp, #0x28]
     f30:      	ldrb	w9, [x8, #0x19]
     f34:      	ldr	x9, [x23, x9]
     f38:      	str	x9, [sp, #0x8]
     f3c:      	ldrb	w9, [x8, #0x18]
     f40:      	ldr	x8, [x8, #0x8]
     f44:      	ldr	x29, [x23, x9]
     f48:      	cbz	x8, 0xff8 <kprobe_unwind_python+0xff8>
     f4c:      	ldr	x9, [sp, #0x8]
     f50:      	cmp	x9, x8
     f54:      	b.ne	0xff8 <kprobe_unwind_python+0xff8>
     f58:      	ldr	x22, [sp, #0x20]
     f5c:      	ldr	x19, [sp, #0x30]
     f60:      	mov	x12, x29
     f64:      	b	0x1ac <kprobe_unwind_python+0x1ac>
     f68:      	adrp	x8, 0x0 <kprobe_unwind_python>
     f6c:      	add	x8, x8, #0x0
     f70:      	add	x0, sp, #0x40
     f74:      	ldp	x9, x10, [x8, #0x10]
     f78:      	mov	w1, #0x2e               // =46
     f7c:      	stp	x9, x10, [sp, #0x50]
     f80:      	ldr	x9, [x8, #0x20]
     f84:      	add	x10, sp, #0x40
     f88:      	str	x9, [sp, #0x60]
     f8c:      	ldur	x9, [x8, #0x26]
     f90:      	stur	x9, [sp, #0x66]
     f94:      	ldp	x9, x8, [x8]
     f98:      	stp	x9, x8, [sp, #0x40]
     f9c:      	mov	w8, #0x2e               // =46
     fa0:      	mov	w9, #0x6                // =6
     fa4:      	ldr	w2, [sp, #0x9c]
     fa8:      	blr	x9
     fac:      	b	0x874 <kprobe_unwind_python+0x874>
     fb0:      	adrp	x8, 0x0 <kprobe_unwind_python>
     fb4:      	add	x8, x8, #0x0
     fb8:      	add	x0, sp, #0x40
     fbc:      	ldp	x9, x10, [x8, #0x10]
     fc0:      	mov	w1, #0x2e               // =46
     fc4:      	stp	x9, x10, [sp, #0x50]
     fc8:      	ldr	x9, [x8, #0x20]
     fcc:      	add	x10, sp, #0x40
     fd0:      	str	x9, [sp, #0x60]
     fd4:      	ldur	x9, [x8, #0x26]
     fd8:      	stur	x9, [sp, #0x66]
     fdc:      	ldp	x9, x8, [x8]
     fe0:      	stp	x9, x8, [sp, #0x40]
     fe4:      	mov	w8, #0x2e               // =46
     fe8:      	mov	w9, #0x6                // =6
     fec:      	ldr	w2, [sp, #0x88]
     ff0:      	blr	x9
     ff4:      	b	0x8b4 <kprobe_unwind_python+0x8b4>
     ff8:      	ldr	x8, [sp, #0x28]
     ffc:      	ldrb	w9, [x8, #0x22]
    1000:      	ldrb	w8, [x8, #0x1a]
    1004:      	cbz	w9, 0x10ec <kprobe_unwind_python+0x10ec>
    1008:      	ldr	x9, [sp, #0x28]
    100c:      	ldr	x11, [sp, #0x8]
    1010:      	ldr	x8, [x23, x8]
    1014:      	ldrb	w10, [x9, #0x21]
    1018:      	add	x10, x11, x10
    101c:      	mov	x11, #-0x3              // =-3
    1020:      	sub	x8, x8, x10
    1024:      	mov	x10, #-0x10000001       // =-268435457
    1028:      	movk	x11, #0xefff, lsl #16
    102c:      	add	x10, x8, x10
    1030:      	asr	w8, w8, #1
    1034:      	cmp	x10, x11
    1038:      	csinv	w19, w8, wzr, hs
    103c:      	ldrb	w8, [x9, #0x1b]
    1040:      	ldrb	w9, [x9, #0x1c]
    1044:      	ldrb	w8, [x23, x8]
    1048:      	cmp	w8, w9
    104c:      	cset	w22, eq
    1050:      	b	0x10f4 <kprobe_unwind_python+0x10f4>
    1054:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1058:      	add	x8, x8, #0x0
    105c:      	add	x0, sp, #0x40
    1060:      	ldp	x9, x10, [x8, #0x10]
    1064:      	mov	w1, #0x2e               // =46
    1068:      	stp	x9, x10, [sp, #0x50]
    106c:      	ldr	x9, [x8, #0x20]
    1070:      	add	x10, sp, #0x40
    1074:      	str	x9, [sp, #0x60]
    1078:      	ldur	x9, [x8, #0x26]
    107c:      	stur	x9, [sp, #0x66]
    1080:      	ldp	x9, x8, [x8]
    1084:      	stp	x9, x8, [sp, #0x40]
    1088:      	mov	w8, #0x2e               // =46
    108c:      	mov	w9, #0x6                // =6
    1090:      	ldr	w2, [sp, #0x88]
    1094:      	blr	x9
    1098:      	b	0x1cc <kprobe_unwind_python+0x1cc>
    109c:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    10a0:      	add	x8, x8, #0x0
    10a4:      	add	x0, sp, #0x40
    10a8:      	ldp	x9, x10, [x8, #0x10]
    10ac:      	mov	w1, #0x2d               // =45
    10b0:      	stp	x9, x10, [sp, #0x50]
    10b4:      	ldr	x9, [x8, #0x20]
    10b8:      	add	x10, sp, #0x40
    10bc:      	str	x9, [sp, #0x60]
    10c0:      	ldur	x9, [x8, #0x25]
    10c4:      	stur	x9, [sp, #0x65]
    10c8:      	ldp	x9, x8, [x8]
    10cc:      	stp	x9, x8, [sp, #0x40]
    10d0:      	mov	w8, #0x2d               // =45
    10d4:      	mov	w9, #0x6                // =6
    10d8:      	ldr	x8, [sp, #0x78]
    10dc:      	ldrb	w10, [x29, #0x16]
    10e0:      	add	x2, x8, x10
    10e4:      	blr	x9
    10e8:      	b	0x900 <kprobe_unwind_python+0x900>
    10ec:      	ldr	w19, [x23, x8]
    10f0:      	mov	w22, wzr
    10f4:      	ldr	x8, [sp, #0x8]
    10f8:      	cbz	x8, 0x1198 <kprobe_unwind_python+0x1198>
    10fc:      	ldr	x8, [sp, #0x28]
    1100:      	ldrb	w8, [x8, #0x1d]
    1104:      	cmp	w8, #0xbc
    1108:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    110c:      	ldr	x8, [sp, #0x28]
    1110:      	ldrb	w8, [x8, #0x1e]
    1114:      	cmp	w8, #0xbc
    1118:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    111c:      	ldr	x8, [sp, #0x28]
    1120:      	ldrb	w8, [x8, #0x1f]
    1124:      	cmp	w8, #0xbc
    1128:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    112c:      	ldr	x8, [sp, #0x28]
    1130:      	ldrb	w8, [x8, #0x20]
    1134:      	cmp	w8, #0xbc
    1138:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    113c:      	ldr	x0, [sp, #0x18]
    1140:      	ldr	x2, [sp, #0x8]
    1144:      	mov	w8, #0xc0               // =192
    1148:      	mov	w9, #0x70               // =112
    114c:      	mov	w1, #0xc0               // =192
    1150:      	blr	x9
    1154:      	cbnz	x0, 0xa90 <kprobe_unwind_python+0xa90>
    1158:      	ldr	x8, [sp, #0x28]
    115c:      	ldr	x12, [sp, #0x18]
    1160:      	ldrb	w10, [x8, #0x1e]
    1164:      	ldrb	w9, [x8, #0x1d]
    1168:      	ldrb	w11, [x8, #0x1f]
    116c:      	ldrb	w8, [x8, #0x20]
    1170:      	ldr	w10, [x12, x10]
    1174:      	ldr	w9, [x12, x9]
    1178:      	ldr	w11, [x12, x11]
    117c:      	ldr	w8, [x12, x8]
    1180:      	lsl	w10, w10, #18
    1184:      	add	w9, w10, w9, lsl #25
    1188:      	add	w9, w9, w11, lsl #10
    118c:      	add	w8, w9, w8
    1190:      	orr	x19, x8, x19, lsl #32
    1194:      	b	0x12b4 <kprobe_unwind_python+0x12b4>
    1198:      	ldr	w8, [x25]
    119c:      	cbnz	w8, 0x1830 <kprobe_unwind_python+0x1830>
    11a0:      	mov	w8, #0x1c               // =28
    11a4:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    11a8:      	add	x9, sp, #0x88
    11ac:      	str	w8, [sp, #0x88]
    11b0:      	mov	w8, #0x1                // =1
    11b4:      	add	x1, sp, #0x88
    11b8:      	ldr	x0, [x0]
    11bc:      	blr	x8
    11c0:      	cbz	x0, 0x12a4 <kprobe_unwind_python+0x12a4>
    11c4:      	ldr	x8, [x0]
    11c8:      	add	x8, x8, #0x1
    11cc:      	str	x8, [x0]
    11d0:      	b	0x12ac <kprobe_unwind_python+0x12ac>
    11d4:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    11d8:      	add	x8, x8, #0x0
    11dc:      	add	x0, sp, #0x40
    11e0:      	ldp	x9, x10, [x8]
    11e4:      	ldur	x8, [x8, #0xe]
    11e8:      	mov	w1, #0x16               // =22
    11ec:      	stp	x9, x10, [sp, #0x40]
    11f0:      	stur	x8, [sp, #0x4e]
    11f4:      	mov	w8, #0x16               // =22
    11f8:      	mov	w9, #0x6                // =6
    11fc:      	add	x10, sp, #0x40
    1200:      	blr	x9
    1204:      	b	0x948 <kprobe_unwind_python+0x948>
    1208:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    120c:      	add	x8, x8, #0x0
    1210:      	add	x0, sp, #0x40
    1214:      	ldp	x9, x10, [x8, #0x10]
    1218:      	mov	w1, #0x2f               // =47
    121c:      	mov	x2, x29
    1220:      	stp	x9, x10, [sp, #0x50]
    1224:      	ldr	x9, [x8, #0x20]
    1228:      	add	x10, sp, #0x40
    122c:      	str	x9, [sp, #0x60]
    1230:      	ldur	x9, [x8, #0x27]
    1234:      	stur	x9, [sp, #0x67]
    1238:      	ldp	x9, x8, [x8]
    123c:      	stp	x9, x8, [sp, #0x40]
    1240:      	mov	w8, #0x2f               // =47
    1244:      	mov	w9, #0x6                // =6
    1248:      	ldr	x8, [sp, #0x28]
    124c:      	ldrb	w8, [x8, #0x19]
    1250:      	add	x3, x29, x8
    1254:      	blr	x9
    1258:      	b	0x298 <kprobe_unwind_python+0x298>
    125c:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1260:      	add	x8, x8, #0x0
    1264:      	add	x0, sp, #0x40
    1268:      	ldp	x9, x10, [x8, #0x10]
    126c:      	mov	w1, #0x2e               // =46
    1270:      	stp	x9, x10, [sp, #0x50]
    1274:      	ldr	x9, [x8, #0x20]
    1278:      	add	x10, sp, #0x40
    127c:      	str	x9, [sp, #0x60]
    1280:      	ldur	x9, [x8, #0x26]
    1284:      	stur	x9, [sp, #0x66]
    1288:      	ldp	x9, x8, [x8]
    128c:      	stp	x9, x8, [sp, #0x40]
    1290:      	mov	w8, #0x2e               // =46
    1294:      	mov	w9, #0x6                // =6
    1298:      	ldr	w2, [sp, #0x88]
    129c:      	blr	x9
    12a0:      	b	0xa10 <kprobe_unwind_python+0xa10>
    12a4:      	ldr	w8, [x25]
    12a8:      	cbnz	w8, 0x18b0 <kprobe_unwind_python+0x18b0>
    12ac:      	mov	x19, #-0x2              // =-2
    12b0:      	str	xzr, [sp, #0x8]
    12b4:      	ldr	w8, [x25]
    12b8:      	cbnz	w8, 0x15a0 <kprobe_unwind_python+0x15a0>
    12bc:      	ldr	w8, [x21, #0x2c0]
    12c0:      	cmp	w8, #0x7e
    12c4:      	b.ls	0x15e4 <kprobe_unwind_python+0x15e4>
    12c8:      	ldr	x22, [sp, #0x20]
    12cc:      	ldr	x19, [sp, #0x30]
    12d0:      	ldr	w8, [x25]
    12d4:      	cbz	w8, 0x3cc <kprobe_unwind_python+0x3cc>
    12d8:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    12dc:      	add	x8, x8, #0x0
    12e0:      	add	x0, sp, #0x40
    12e4:      	ldp	x9, x10, [x8, #0x10]
    12e8:      	mov	w1, #0x25               // =37
    12ec:      	stp	x9, x10, [sp, #0x50]
    12f0:      	ldur	x9, [x8, #0x1d]
    12f4:      	add	x10, sp, #0x40
    12f8:      	stur	x9, [sp, #0x5d]
    12fc:      	ldp	x8, x9, [x8]
    1300:      	stp	x8, x9, [sp, #0x40]
    1304:      	mov	w8, #0x25               // =37
    1308:      	mov	w9, #0x6                // =6
    130c:      	blr	x9
    1310:      	b	0x3cc <kprobe_unwind_python+0x3cc>
    1314:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1318:      	add	x8, x8, #0x0
    131c:      	add	x0, sp, #0x40
    1320:      	ldp	x9, x10, [x8, #0x10]
    1324:      	mov	w1, #0x2e               // =46
    1328:      	stp	x9, x10, [sp, #0x50]
    132c:      	ldr	x9, [x8, #0x20]
    1330:      	add	x10, sp, #0x40
    1334:      	str	x9, [sp, #0x60]
    1338:      	ldur	x9, [x8, #0x26]
    133c:      	stur	x9, [sp, #0x66]
    1340:      	ldp	x9, x8, [x8]
    1344:      	stp	x9, x8, [sp, #0x40]
    1348:      	mov	w8, #0x2e               // =46
    134c:      	mov	w9, #0x6                // =6
    1350:      	ldr	w2, [sp, #0x88]
    1354:      	blr	x9
    1358:      	b	0xa4c <kprobe_unwind_python+0xa4c>
    135c:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1360:      	add	x8, x8, #0x0
    1364:      	add	x0, sp, #0x40
    1368:      	ldp	x9, x10, [x8, #0x10]
    136c:      	mov	w1, #0x2e               // =46
    1370:      	stp	x9, x10, [sp, #0x50]
    1374:      	ldr	x9, [x8, #0x20]
    1378:      	add	x10, sp, #0x40
    137c:      	str	x9, [sp, #0x60]
    1380:      	ldur	x9, [x8, #0x26]
    1384:      	stur	x9, [sp, #0x66]
    1388:      	ldp	x9, x8, [x8]
    138c:      	stp	x9, x8, [sp, #0x40]
    1390:      	mov	w8, #0x2e               // =46
    1394:      	mov	w9, #0x6                // =6
    1398:      	ldr	w2, [sp, #0x88]
    139c:      	blr	x9
    13a0:      	mov	x11, x24
    13a4:      	mov	x12, xzr
    13a8:      	mov	x29, #-0x2              // =-2
    13ac:      	ldr	w8, [x25]
    13b0:      	cbz	w8, 0x3b4 <kprobe_unwind_python+0x3b4>
    13b4:      	b	0x2e0 <kprobe_unwind_python+0x2e0>
    13b8:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    13bc:      	add	x8, x8, #0x0
    13c0:      	strb	wzr, [sp, #0x70]
    13c4:      	mov	w1, #0x31               // =49
    13c8:      	ldp	x9, x10, [x8, #0x10]
    13cc:      	stp	x9, x10, [sp, #0x50]
    13d0:      	ldp	x9, x10, [x8, #0x20]
    13d4:      	stp	x9, x10, [sp, #0x60]
    13d8:      	ldp	x9, x8, [x8]
    13dc:      	add	x10, sp, #0x40
    13e0:      	stp	x9, x8, [sp, #0x40]
    13e4:      	mov	w8, #0x31               // =49
    13e8:      	mov	w9, #0x6                // =6
    13ec:      	ldr	x8, [x22]
    13f0:      	ldrb	w10, [x0, #0x17]
    13f4:      	add	x0, sp, #0x40
    13f8:      	add	x2, x8, x10
    13fc:      	blr	x9
    1400:      	b	0x9d8 <kprobe_unwind_python+0x9d8>
    1404:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1408:      	add	x8, x8, #0x0
    140c:      	add	x0, sp, #0x40
    1410:      	ldp	x9, x10, [x8, #0x10]
    1414:      	mov	w1, #0x2e               // =46
    1418:      	stp	x9, x10, [sp, #0x50]
    141c:      	ldr	x9, [x8, #0x20]
    1420:      	add	x10, sp, #0x40
    1424:      	str	x9, [sp, #0x60]
    1428:      	ldur	x9, [x8, #0x26]
    142c:      	stur	x9, [sp, #0x66]
    1430:      	ldp	x9, x8, [x8]
    1434:      	stp	x9, x8, [sp, #0x40]
    1438:      	mov	w8, #0x2e               // =46
    143c:      	mov	w9, #0x6                // =6
    1440:      	ldr	w2, [sp, #0x88]
    1444:      	blr	x9
    1448:      	ldr	w8, [x25]
    144c:      	cbz	w8, 0x480 <kprobe_unwind_python+0x480>
    1450:      	b	0x404 <kprobe_unwind_python+0x404>
    1454:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1458:      	add	x8, x8, #0x0
    145c:      	add	x0, sp, #0x40
    1460:      	ldp	x9, x10, [x8, #0x10]
    1464:      	mov	w1, #0x2e               // =46
    1468:      	stp	x9, x10, [sp, #0x50]
    146c:      	ldr	x9, [x8, #0x20]
    1470:      	add	x10, sp, #0x40
    1474:      	str	x9, [sp, #0x60]
    1478:      	ldur	x9, [x8, #0x26]
    147c:      	stur	x9, [sp, #0x66]
    1480:      	ldp	x9, x8, [x8]
    1484:      	stp	x9, x8, [sp, #0x40]
    1488:      	mov	w8, #0x2e               // =46
    148c:      	mov	w9, #0x6                // =6
    1490:      	ldr	w2, [sp, #0x88]
    1494:      	blr	x9
    1498:      	b	0x390 <kprobe_unwind_python+0x390>
    149c:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    14a0:      	add	x8, x8, #0x0
    14a4:      	add	x0, sp, #0x40
    14a8:      	ldp	x9, x10, [x8]
    14ac:      	mov	w1, #0x20               // =32
    14b0:      	stp	x9, x10, [sp, #0x40]
    14b4:      	ldp	x9, x8, [x8, #0x10]
    14b8:      	add	x10, sp, #0x40
    14bc:      	stp	x9, x8, [sp, #0x50]
    14c0:      	mov	w8, #0x20               // =32
    14c4:      	mov	w9, #0x6                // =6
    14c8:      	blr	x9
    14cc:      	b	0xa2c <kprobe_unwind_python+0xa2c>
    14d0:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    14d4:      	add	x8, x8, #0x0
    14d8:      	add	x0, sp, #0x40
    14dc:      	ldp	x9, x10, [x8, #0x10]
    14e0:      	mov	w1, #0x2e               // =46
    14e4:      	stp	x9, x10, [sp, #0x50]
    14e8:      	ldr	x9, [x8, #0x20]
    14ec:      	add	x10, sp, #0x40
    14f0:      	str	x9, [sp, #0x60]
    14f4:      	ldur	x9, [x8, #0x26]
    14f8:      	stur	x9, [sp, #0x66]
    14fc:      	ldp	x9, x8, [x8]
    1500:      	stp	x9, x8, [sp, #0x40]
    1504:      	mov	w8, #0x2e               // =46
    1508:      	mov	w9, #0x6                // =6
    150c:      	ldr	w2, [sp, #0x88]
    1510:      	blr	x9
    1514:      	b	0xa5c <kprobe_unwind_python+0xa5c>
    1518:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    151c:      	add	x8, x8, #0x0
    1520:      	add	x0, sp, #0x40
    1524:      	ldp	x9, x10, [x8, #0x10]
    1528:      	mov	w1, #0x26               // =38
    152c:      	stp	x9, x10, [sp, #0x50]
    1530:      	ldur	x9, [x8, #0x1e]
    1534:      	add	x10, sp, #0x40
    1538:      	stur	x9, [sp, #0x5e]
    153c:      	ldp	x8, x9, [x8]
    1540:      	stp	x8, x9, [sp, #0x40]
    1544:      	mov	w8, #0x26               // =38
    1548:      	mov	w9, #0x6                // =6
    154c:      	ldr	x2, [sp, #0x8]
    1550:      	blr	x9
    1554:      	b	0xa9c <kprobe_unwind_python+0xa9c>
    1558:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    155c:      	add	x8, x8, #0x0
    1560:      	add	x0, sp, #0x40
    1564:      	ldp	x9, x10, [x8, #0x10]
    1568:      	mov	w1, #0x2e               // =46
    156c:      	stp	x9, x10, [sp, #0x50]
    1570:      	ldr	x9, [x8, #0x20]
    1574:      	add	x10, sp, #0x40
    1578:      	str	x9, [sp, #0x60]
    157c:      	ldur	x9, [x8, #0x26]
    1580:      	stur	x9, [sp, #0x66]
    1584:      	ldp	x9, x8, [x8]
    1588:      	stp	x9, x8, [sp, #0x40]
    158c:      	mov	w8, #0x2e               // =46
    1590:      	mov	w9, #0x6                // =6
    1594:      	ldr	w2, [sp, #0x88]
    1598:      	blr	x9
    159c:      	b	0xc94 <kprobe_unwind_python+0xc94>
    15a0:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    15a4:      	add	x8, x8, #0x0
    15a8:      	add	x0, sp, #0x40
    15ac:      	ldp	x9, x10, [x8]
    15b0:      	ldr	x8, [x8, #0x10]
    15b4:      	mov	w1, #0x18               // =24
    15b8:      	mov	x3, x19
    15bc:      	stp	x9, x10, [sp, #0x40]
    15c0:      	str	x8, [sp, #0x50]
    15c4:      	mov	w8, #0x18               // =24
    15c8:      	mov	w9, #0x6                // =6
    15cc:      	add	x10, sp, #0x40
    15d0:      	ldr	x2, [sp, #0x8]
    15d4:      	blr	x9
    15d8:      	ldr	w8, [x21, #0x2c0]
    15dc:      	cmp	w8, #0x7e
    15e0:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    15e4:      	add	w9, w8, #0x1
    15e8:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    15ec:      	add	x1, sp, #0x88
    15f0:      	str	w9, [x21, #0x2c0]
    15f4:      	mov	w9, #0x18               // =24
    15f8:      	umaddl	x8, w8, w9, x21
    15fc:      	ldr	x9, [sp, #0x8]
    1600:      	str	x19, [x8, #0x2d8]
    1604:      	str	wzr, [x8, #0x2e4]
    1608:      	str	x9, [x8, #0x2d0]
    160c:      	mov	w9, #0x1                // =1
    1610:      	strb	w9, [x8, #0x2e0]
    1614:      	add	x8, x8, #0x2d0
    1618:      	stur	wzr, [x8, #0x11]
    161c:      	mov	w8, #0x16               // =22
    1620:      	str	w8, [sp, #0x88]
    1624:      	add	x8, sp, #0x88
    1628:      	ldr	x0, [x0]
    162c:      	blr	x9
    1630:      	cbz	x0, 0x1648 <kprobe_unwind_python+0x1648>
    1634:      	ldr	x8, [x0]
    1638:      	add	x8, x8, #0x1
    163c:      	str	x8, [x0]
    1640:      	cbnz	w22, 0xf58 <kprobe_unwind_python+0xf58>
    1644:      	b	0x1654 <kprobe_unwind_python+0x1654>
    1648:      	ldr	w8, [x25]
    164c:      	cbnz	w8, 0x18f8 <kprobe_unwind_python+0x18f8>
    1650:      	cbnz	w22, 0xf58 <kprobe_unwind_python+0xf58>
    1654:      	cbz	x29, 0x3400 <kprobe_unwind_python+0x3400>
    1658:      	ldr	x8, [sp, #0x28]
    165c:      	ldrb	w8, [x8, #0x19]
    1660:      	cmp	w8, #0x78
    1664:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1668:      	ldr	x8, [sp, #0x28]
    166c:      	ldrb	w8, [x8, #0x18]
    1670:      	cmp	w8, #0x78
    1674:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1678:      	ldr	x8, [sp, #0x28]
    167c:      	ldrb	w8, [x8, #0x1a]
    1680:      	cmp	w8, #0x78
    1684:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1688:      	ldr	x8, [sp, #0x28]
    168c:      	ldrsb	w8, [x8, #0x1b]
    1690:      	tbnz	w8, #0x1f, 0x380c <kprobe_unwind_python+0x380c>
    1694:      	mov	w8, #0x80               // =128
    1698:      	mov	w9, #0x70               // =112
    169c:      	mov	x2, x29
    16a0:      	mov	x0, x23
    16a4:      	mov	w1, #0x80               // =128
    16a8:      	blr	x9
    16ac:      	cbnz	x0, 0xc38 <kprobe_unwind_python+0xc38>
    16b0:      	ldr	x8, [sp, #0x28]
    16b4:      	ldrb	w9, [x8, #0x19]
    16b8:      	ldr	x10, [x23, x9]
    16bc:      	ldrb	w9, [x8, #0x18]
    16c0:      	ldr	x8, [x8, #0x8]
    16c4:      	ldr	x9, [x23, x9]
    16c8:      	stp	x10, x9, [sp, #0x8]
    16cc:      	cbz	x8, 0x16ec <kprobe_unwind_python+0x16ec>
    16d0:      	ldr	x9, [sp, #0x8]
    16d4:      	cmp	x9, x8
    16d8:      	b.ne	0x16ec <kprobe_unwind_python+0x16ec>
    16dc:      	ldr	x22, [sp, #0x20]
    16e0:      	ldr	x19, [sp, #0x30]
    16e4:      	ldr	x12, [sp, #0x10]
    16e8:      	b	0x1ac <kprobe_unwind_python+0x1ac>
    16ec:      	ldr	x8, [sp, #0x28]
    16f0:      	ldrb	w9, [x8, #0x22]
    16f4:      	ldrb	w8, [x8, #0x1a]
    16f8:      	cbz	w9, 0x1748 <kprobe_unwind_python+0x1748>
    16fc:      	ldr	x9, [sp, #0x28]
    1700:      	ldr	x11, [sp, #0x8]
    1704:      	ldr	x8, [x23, x8]
    1708:      	ldrb	w10, [x9, #0x21]
    170c:      	add	x10, x11, x10
    1710:      	mov	x11, #-0x3              // =-3
    1714:      	sub	x8, x8, x10
    1718:      	mov	x10, #-0x10000001       // =-268435457
    171c:      	movk	x11, #0xefff, lsl #16
    1720:      	add	x10, x8, x10
    1724:      	asr	w8, w8, #1
    1728:      	cmp	x10, x11
    172c:      	csinv	w24, w8, wzr, hs
    1730:      	ldrb	w8, [x9, #0x1b]
    1734:      	ldrb	w9, [x9, #0x1c]
    1738:      	ldrb	w8, [x23, x8]
    173c:      	cmp	w8, w9
    1740:      	cset	w19, eq
    1744:      	b	0x1750 <kprobe_unwind_python+0x1750>
    1748:      	ldr	w24, [x23, x8]
    174c:      	mov	w19, wzr
    1750:      	ldr	x8, [sp, #0x8]
    1754:      	cbz	x8, 0x17f4 <kprobe_unwind_python+0x17f4>
    1758:      	ldr	x8, [sp, #0x28]
    175c:      	ldrb	w8, [x8, #0x1d]
    1760:      	cmp	w8, #0xbc
    1764:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1768:      	ldr	x8, [sp, #0x28]
    176c:      	ldrb	w8, [x8, #0x1e]
    1770:      	cmp	w8, #0xbc
    1774:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1778:      	ldr	x8, [sp, #0x28]
    177c:      	ldrb	w8, [x8, #0x1f]
    1780:      	cmp	w8, #0xbc
    1784:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1788:      	ldr	x8, [sp, #0x28]
    178c:      	ldrb	w8, [x8, #0x20]
    1790:      	cmp	w8, #0xbc
    1794:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1798:      	ldr	x0, [sp, #0x18]
    179c:      	ldr	x2, [sp, #0x8]
    17a0:      	mov	w8, #0xc0               // =192
    17a4:      	mov	w9, #0x70               // =112
    17a8:      	mov	w1, #0xc0               // =192
    17ac:      	blr	x9
    17b0:      	cbnz	x0, 0xa8c <kprobe_unwind_python+0xa8c>
    17b4:      	ldr	x8, [sp, #0x28]
    17b8:      	ldr	x12, [sp, #0x18]
    17bc:      	ldrb	w10, [x8, #0x1e]
    17c0:      	ldrb	w9, [x8, #0x1d]
    17c4:      	ldrb	w11, [x8, #0x1f]
    17c8:      	ldrb	w8, [x8, #0x20]
    17cc:      	ldr	w10, [x12, x10]
    17d0:      	ldr	w9, [x12, x9]
    17d4:      	ldr	w11, [x12, x11]
    17d8:      	ldr	w8, [x12, x8]
    17dc:      	lsl	w10, w10, #18
    17e0:      	add	w9, w10, w9, lsl #25
    17e4:      	add	w9, w9, w11, lsl #10
    17e8:      	add	w8, w9, w8
    17ec:      	orr	x29, x8, x24, lsl #32
    17f0:      	b	0x1894 <kprobe_unwind_python+0x1894>
    17f4:      	ldr	w8, [x25]
    17f8:      	cbnz	w8, 0x1bd0 <kprobe_unwind_python+0x1bd0>
    17fc:      	mov	w8, #0x1c               // =28
    1800:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    1804:      	add	x9, sp, #0x88
    1808:      	str	w8, [sp, #0x88]
    180c:      	mov	w8, #0x1                // =1
    1810:      	add	x1, sp, #0x88
    1814:      	ldr	x0, [x0]
    1818:      	blr	x8
    181c:      	cbz	x0, 0x1884 <kprobe_unwind_python+0x1884>
    1820:      	ldr	x8, [x0]
    1824:      	add	x8, x8, #0x1
    1828:      	str	x8, [x0]
    182c:      	b	0x188c <kprobe_unwind_python+0x188c>
    1830:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1834:      	add	x8, x8, #0x0
    1838:      	add	x0, sp, #0x40
    183c:      	ldp	x9, x10, [x8, #0x10]
    1840:      	mov	w1, #0x2f               // =47
    1844:      	mov	x2, x24
    1848:      	stp	x9, x10, [sp, #0x50]
    184c:      	ldr	x9, [x8, #0x20]
    1850:      	add	x10, sp, #0x40
    1854:      	str	x9, [sp, #0x60]
    1858:      	ldur	x9, [x8, #0x27]
    185c:      	stur	x9, [sp, #0x67]
    1860:      	ldp	x9, x8, [x8]
    1864:      	stp	x9, x8, [sp, #0x40]
    1868:      	mov	w8, #0x2f               // =47
    186c:      	mov	w9, #0x6                // =6
    1870:      	ldr	x8, [sp, #0x28]
    1874:      	ldrb	w8, [x8, #0x19]
    1878:      	add	x3, x24, x8
    187c:      	blr	x9
    1880:      	b	0x11a0 <kprobe_unwind_python+0x11a0>
    1884:      	ldr	w8, [x25]
    1888:      	cbnz	w8, 0x1cac <kprobe_unwind_python+0x1cac>
    188c:      	mov	x29, #-0x2              // =-2
    1890:      	str	xzr, [sp, #0x8]
    1894:      	ldr	w8, [x25]
    1898:      	cbnz	w8, 0x1944 <kprobe_unwind_python+0x1944>
    189c:      	ldr	w8, [x21, #0x2c0]
    18a0:      	cmp	w8, #0x7e
    18a4:      	b.ls	0x1988 <kprobe_unwind_python+0x1988>
    18a8:      	ldr	x29, [sp, #0x10]
    18ac:      	b	0x12c8 <kprobe_unwind_python+0x12c8>
    18b0:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    18b4:      	add	x8, x8, #0x0
    18b8:      	add	x0, sp, #0x40
    18bc:      	ldp	x9, x10, [x8, #0x10]
    18c0:      	mov	w1, #0x2e               // =46
    18c4:      	stp	x9, x10, [sp, #0x50]
    18c8:      	ldr	x9, [x8, #0x20]
    18cc:      	add	x10, sp, #0x40
    18d0:      	str	x9, [sp, #0x60]
    18d4:      	ldur	x9, [x8, #0x26]
    18d8:      	stur	x9, [sp, #0x66]
    18dc:      	ldp	x9, x8, [x8]
    18e0:      	stp	x9, x8, [sp, #0x40]
    18e4:      	mov	w8, #0x2e               // =46
    18e8:      	mov	w9, #0x6                // =6
    18ec:      	ldr	w2, [sp, #0x88]
    18f0:      	blr	x9
    18f4:      	b	0x12ac <kprobe_unwind_python+0x12ac>
    18f8:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    18fc:      	add	x8, x8, #0x0
    1900:      	add	x0, sp, #0x40
    1904:      	ldp	x9, x10, [x8, #0x10]
    1908:      	mov	w1, #0x2e               // =46
    190c:      	stp	x9, x10, [sp, #0x50]
    1910:      	ldr	x9, [x8, #0x20]
    1914:      	add	x10, sp, #0x40
    1918:      	str	x9, [sp, #0x60]
    191c:      	ldur	x9, [x8, #0x26]
    1920:      	stur	x9, [sp, #0x66]
    1924:      	ldp	x9, x8, [x8]
    1928:      	stp	x9, x8, [sp, #0x40]
    192c:      	mov	w8, #0x2e               // =46
    1930:      	mov	w9, #0x6                // =6
    1934:      	ldr	w2, [sp, #0x88]
    1938:      	blr	x9
    193c:      	cbnz	w22, 0xf58 <kprobe_unwind_python+0xf58>
    1940:      	b	0x1654 <kprobe_unwind_python+0x1654>
    1944:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1948:      	add	x8, x8, #0x0
    194c:      	add	x0, sp, #0x40
    1950:      	ldp	x9, x10, [x8]
    1954:      	ldr	x8, [x8, #0x10]
    1958:      	mov	w1, #0x18               // =24
    195c:      	mov	x3, x29
    1960:      	stp	x9, x10, [sp, #0x40]
    1964:      	str	x8, [sp, #0x50]
    1968:      	mov	w8, #0x18               // =24
    196c:      	mov	w9, #0x6                // =6
    1970:      	add	x10, sp, #0x40
    1974:      	ldr	x2, [sp, #0x8]
    1978:      	blr	x9
    197c:      	ldr	w8, [x21, #0x2c0]
    1980:      	cmp	w8, #0x7e
    1984:      	b.hi	0x18a8 <kprobe_unwind_python+0x18a8>
    1988:      	add	w9, w8, #0x1
    198c:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    1990:      	add	x1, sp, #0x88
    1994:      	str	w9, [x21, #0x2c0]
    1998:      	mov	w9, #0x18               // =24
    199c:      	umaddl	x8, w8, w9, x21
    19a0:      	ldr	x9, [sp, #0x8]
    19a4:      	str	x29, [x8, #0x2d8]
    19a8:      	str	wzr, [x8, #0x2e4]
    19ac:      	str	x9, [x8, #0x2d0]
    19b0:      	mov	w9, #0x1                // =1
    19b4:      	strb	w9, [x8, #0x2e0]
    19b8:      	add	x8, x8, #0x2d0
    19bc:      	stur	wzr, [x8, #0x11]
    19c0:      	mov	w8, #0x16               // =22
    19c4:      	str	w8, [sp, #0x88]
    19c8:      	add	x8, sp, #0x88
    19cc:      	ldr	x0, [x0]
    19d0:      	blr	x9
    19d4:      	cbz	x0, 0x19ec <kprobe_unwind_python+0x19ec>
    19d8:      	ldr	x8, [x0]
    19dc:      	add	x8, x8, #0x1
    19e0:      	str	x8, [x0]
    19e4:      	cbnz	w19, 0x16dc <kprobe_unwind_python+0x16dc>
    19e8:      	b	0x19f8 <kprobe_unwind_python+0x19f8>
    19ec:      	ldr	w8, [x25]
    19f0:      	cbnz	w8, 0x1de4 <kprobe_unwind_python+0x1de4>
    19f4:      	cbnz	w19, 0x16dc <kprobe_unwind_python+0x16dc>
    19f8:      	ldr	x8, [sp, #0x10]
    19fc:      	cbz	x8, 0x22e0 <kprobe_unwind_python+0x22e0>
    1a00:      	ldr	x8, [sp, #0x28]
    1a04:      	ldrb	w8, [x8, #0x19]
    1a08:      	cmp	w8, #0x78
    1a0c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1a10:      	ldr	x8, [sp, #0x28]
    1a14:      	ldrb	w8, [x8, #0x18]
    1a18:      	cmp	w8, #0x78
    1a1c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1a20:      	ldr	x8, [sp, #0x28]
    1a24:      	ldrb	w8, [x8, #0x1a]
    1a28:      	cmp	w8, #0x78
    1a2c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1a30:      	ldr	x8, [sp, #0x28]
    1a34:      	ldrsb	w8, [x8, #0x1b]
    1a38:      	tbnz	w8, #0x1f, 0x22d0 <kprobe_unwind_python+0x22d0>
    1a3c:      	ldr	x2, [sp, #0x10]
    1a40:      	mov	w8, #0x80               // =128
    1a44:      	mov	w9, #0x70               // =112
    1a48:      	mov	x0, x23
    1a4c:      	mov	w1, #0x80               // =128
    1a50:      	blr	x9
    1a54:      	cbz	x0, 0x1a60 <kprobe_unwind_python+0x1a60>
    1a58:      	ldr	x29, [sp, #0x10]
    1a5c:      	b	0xc38 <kprobe_unwind_python+0xc38>
    1a60:      	ldr	x8, [sp, #0x28]
    1a64:      	ldrb	w9, [x8, #0x19]
    1a68:      	ldr	x9, [x23, x9]
    1a6c:      	str	x9, [sp, #0x8]
    1a70:      	ldrb	w9, [x8, #0x18]
    1a74:      	ldr	x8, [x8, #0x8]
    1a78:      	ldr	x29, [x23, x9]
    1a7c:      	cbz	x8, 0x1a8c <kprobe_unwind_python+0x1a8c>
    1a80:      	ldr	x9, [sp, #0x8]
    1a84:      	cmp	x9, x8
    1a88:      	b.eq	0xf58 <kprobe_unwind_python+0xf58>
    1a8c:      	ldr	x8, [sp, #0x28]
    1a90:      	ldrb	w9, [x8, #0x22]
    1a94:      	ldrb	w8, [x8, #0x1a]
    1a98:      	cbz	w9, 0x1ae8 <kprobe_unwind_python+0x1ae8>
    1a9c:      	ldr	x9, [sp, #0x28]
    1aa0:      	ldr	x11, [sp, #0x8]
    1aa4:      	ldr	x8, [x23, x8]
    1aa8:      	ldrb	w10, [x9, #0x21]
    1aac:      	add	x10, x11, x10
    1ab0:      	mov	x11, #-0x3              // =-3
    1ab4:      	sub	x8, x8, x10
    1ab8:      	mov	x10, #-0x10000001       // =-268435457
    1abc:      	movk	x11, #0xefff, lsl #16
    1ac0:      	add	x10, x8, x10
    1ac4:      	asr	w8, w8, #1
    1ac8:      	cmp	x10, x11
    1acc:      	csinv	w24, w8, wzr, hs
    1ad0:      	ldrb	w8, [x9, #0x1b]
    1ad4:      	ldrb	w9, [x9, #0x1c]
    1ad8:      	ldrb	w8, [x23, x8]
    1adc:      	cmp	w8, w9
    1ae0:      	cset	w19, eq
    1ae4:      	b	0x1af0 <kprobe_unwind_python+0x1af0>
    1ae8:      	ldr	w24, [x23, x8]
    1aec:      	mov	w19, wzr
    1af0:      	ldr	x8, [sp, #0x8]
    1af4:      	cbz	x8, 0x1b94 <kprobe_unwind_python+0x1b94>
    1af8:      	ldr	x8, [sp, #0x28]
    1afc:      	ldrb	w8, [x8, #0x1d]
    1b00:      	cmp	w8, #0xbc
    1b04:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1b08:      	ldr	x8, [sp, #0x28]
    1b0c:      	ldrb	w8, [x8, #0x1e]
    1b10:      	cmp	w8, #0xbc
    1b14:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1b18:      	ldr	x8, [sp, #0x28]
    1b1c:      	ldrb	w8, [x8, #0x1f]
    1b20:      	cmp	w8, #0xbc
    1b24:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1b28:      	ldr	x8, [sp, #0x28]
    1b2c:      	ldrb	w8, [x8, #0x20]
    1b30:      	cmp	w8, #0xbc
    1b34:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1b38:      	ldr	x0, [sp, #0x18]
    1b3c:      	ldr	x2, [sp, #0x8]
    1b40:      	mov	w8, #0xc0               // =192
    1b44:      	mov	w9, #0x70               // =112
    1b48:      	mov	w1, #0xc0               // =192
    1b4c:      	blr	x9
    1b50:      	cbnz	x0, 0xa90 <kprobe_unwind_python+0xa90>
    1b54:      	ldr	x8, [sp, #0x28]
    1b58:      	ldr	x12, [sp, #0x18]
    1b5c:      	ldrb	w10, [x8, #0x1e]
    1b60:      	ldrb	w9, [x8, #0x1d]
    1b64:      	ldrb	w11, [x8, #0x1f]
    1b68:      	ldrb	w8, [x8, #0x20]
    1b6c:      	ldr	w10, [x12, x10]
    1b70:      	ldr	w9, [x12, x9]
    1b74:      	ldr	w11, [x12, x11]
    1b78:      	ldr	w8, [x12, x8]
    1b7c:      	lsl	w10, w10, #18
    1b80:      	add	w9, w10, w9, lsl #25
    1b84:      	add	w9, w9, w11, lsl #10
    1b88:      	add	w8, w9, w8
    1b8c:      	orr	x22, x8, x24, lsl #32
    1b90:      	b	0x1c34 <kprobe_unwind_python+0x1c34>
    1b94:      	ldr	w8, [x25]
    1b98:      	cbnz	w8, 0x1f68 <kprobe_unwind_python+0x1f68>
    1b9c:      	mov	w8, #0x1c               // =28
    1ba0:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    1ba4:      	add	x9, sp, #0x88
    1ba8:      	str	w8, [sp, #0x88]
    1bac:      	mov	w8, #0x1                // =1
    1bb0:      	add	x1, sp, #0x88
    1bb4:      	ldr	x0, [x0]
    1bb8:      	blr	x8
    1bbc:      	cbz	x0, 0x1c24 <kprobe_unwind_python+0x1c24>
    1bc0:      	ldr	x8, [x0]
    1bc4:      	add	x8, x8, #0x1
    1bc8:      	str	x8, [x0]
    1bcc:      	b	0x1c2c <kprobe_unwind_python+0x1c2c>
    1bd0:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1bd4:      	add	x8, x8, #0x0
    1bd8:      	add	x0, sp, #0x40
    1bdc:      	ldp	x9, x10, [x8, #0x10]
    1be0:      	mov	w1, #0x2f               // =47
    1be4:      	mov	x2, x29
    1be8:      	stp	x9, x10, [sp, #0x50]
    1bec:      	ldr	x9, [x8, #0x20]
    1bf0:      	add	x10, sp, #0x40
    1bf4:      	str	x9, [sp, #0x60]
    1bf8:      	ldur	x9, [x8, #0x27]
    1bfc:      	stur	x9, [sp, #0x67]
    1c00:      	ldp	x9, x8, [x8]
    1c04:      	stp	x9, x8, [sp, #0x40]
    1c08:      	mov	w8, #0x2f               // =47
    1c0c:      	mov	w9, #0x6                // =6
    1c10:      	ldr	x8, [sp, #0x28]
    1c14:      	ldrb	w8, [x8, #0x19]
    1c18:      	add	x3, x29, x8
    1c1c:      	blr	x9
    1c20:      	b	0x17fc <kprobe_unwind_python+0x17fc>
    1c24:      	ldr	w8, [x25]
    1c28:      	cbnz	w8, 0x2004 <kprobe_unwind_python+0x2004>
    1c2c:      	mov	x22, #-0x2              // =-2
    1c30:      	str	xzr, [sp, #0x8]
    1c34:      	ldr	w8, [x25]
    1c38:      	cbnz	w8, 0x1fbc <kprobe_unwind_python+0x1fbc>
    1c3c:      	ldr	w8, [x21, #0x2c0]
    1c40:      	cmp	w8, #0x7e
    1c44:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    1c48:      	add	w9, w8, #0x1
    1c4c:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    1c50:      	add	x1, sp, #0x88
    1c54:      	str	w9, [x21, #0x2c0]
    1c58:      	mov	w9, #0x18               // =24
    1c5c:      	umaddl	x8, w8, w9, x21
    1c60:      	ldr	x9, [sp, #0x8]
    1c64:      	str	x22, [x8, #0x2d8]
    1c68:      	str	wzr, [x8, #0x2e4]
    1c6c:      	str	x9, [x8, #0x2d0]
    1c70:      	mov	w9, #0x1                // =1
    1c74:      	strb	w9, [x8, #0x2e0]
    1c78:      	add	x8, x8, #0x2d0
    1c7c:      	stur	wzr, [x8, #0x11]
    1c80:      	mov	w8, #0x16               // =22
    1c84:      	str	w8, [sp, #0x88]
    1c88:      	add	x8, sp, #0x88
    1c8c:      	ldr	x0, [x0]
    1c90:      	blr	x9
    1c94:      	cbz	x0, 0x1cf4 <kprobe_unwind_python+0x1cf4>
    1c98:      	ldr	x8, [x0]
    1c9c:      	add	x8, x8, #0x1
    1ca0:      	str	x8, [x0]
    1ca4:      	cbnz	w19, 0xf58 <kprobe_unwind_python+0xf58>
    1ca8:      	b	0x1d00 <kprobe_unwind_python+0x1d00>
    1cac:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1cb0:      	add	x8, x8, #0x0
    1cb4:      	add	x0, sp, #0x40
    1cb8:      	ldp	x9, x10, [x8, #0x10]
    1cbc:      	mov	w1, #0x2e               // =46
    1cc0:      	stp	x9, x10, [sp, #0x50]
    1cc4:      	ldr	x9, [x8, #0x20]
    1cc8:      	add	x10, sp, #0x40
    1ccc:      	str	x9, [sp, #0x60]
    1cd0:      	ldur	x9, [x8, #0x26]
    1cd4:      	stur	x9, [sp, #0x66]
    1cd8:      	ldp	x9, x8, [x8]
    1cdc:      	stp	x9, x8, [sp, #0x40]
    1ce0:      	mov	w8, #0x2e               // =46
    1ce4:      	mov	w9, #0x6                // =6
    1ce8:      	ldr	w2, [sp, #0x88]
    1cec:      	blr	x9
    1cf0:      	b	0x188c <kprobe_unwind_python+0x188c>
    1cf4:      	ldr	w8, [x25]
    1cf8:      	cbnz	w8, 0x204c <kprobe_unwind_python+0x204c>
    1cfc:      	cbnz	w19, 0xf58 <kprobe_unwind_python+0xf58>
    1d00:      	cbz	x29, 0x3400 <kprobe_unwind_python+0x3400>
    1d04:      	ldr	x8, [sp, #0x28]
    1d08:      	ldrb	w8, [x8, #0x19]
    1d0c:      	cmp	w8, #0x78
    1d10:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1d14:      	ldr	x8, [sp, #0x28]
    1d18:      	ldrb	w8, [x8, #0x18]
    1d1c:      	cmp	w8, #0x78
    1d20:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1d24:      	ldr	x8, [sp, #0x28]
    1d28:      	ldrb	w8, [x8, #0x1a]
    1d2c:      	cmp	w8, #0x78
    1d30:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    1d34:      	ldr	x8, [sp, #0x28]
    1d38:      	ldrsb	w8, [x8, #0x1b]
    1d3c:      	tbnz	w8, #0x1f, 0x380c <kprobe_unwind_python+0x380c>
    1d40:      	mov	w8, #0x80               // =128
    1d44:      	mov	w9, #0x70               // =112
    1d48:      	mov	x2, x29
    1d4c:      	mov	x0, x23
    1d50:      	mov	w1, #0x80               // =128
    1d54:      	blr	x9
    1d58:      	cbnz	x0, 0xc38 <kprobe_unwind_python+0xc38>
    1d5c:      	ldr	x8, [sp, #0x28]
    1d60:      	ldrb	w9, [x8, #0x19]
    1d64:      	ldr	x10, [x23, x9]
    1d68:      	ldrb	w9, [x8, #0x18]
    1d6c:      	ldr	x8, [x8, #0x8]
    1d70:      	ldr	x9, [x23, x9]
    1d74:      	stp	x10, x9, [sp, #0x8]
    1d78:      	cbz	x8, 0x1d88 <kprobe_unwind_python+0x1d88>
    1d7c:      	ldr	x9, [sp, #0x8]
    1d80:      	cmp	x9, x8
    1d84:      	b.eq	0x16dc <kprobe_unwind_python+0x16dc>
    1d88:      	ldr	x8, [sp, #0x28]
    1d8c:      	ldrb	w9, [x8, #0x22]
    1d90:      	ldrb	w8, [x8, #0x1a]
    1d94:      	cbz	w9, 0x1e30 <kprobe_unwind_python+0x1e30>
    1d98:      	ldr	x9, [sp, #0x28]
    1d9c:      	ldr	x11, [sp, #0x8]
    1da0:      	ldr	x8, [x23, x8]
    1da4:      	ldrb	w10, [x9, #0x21]
    1da8:      	add	x10, x11, x10
    1dac:      	mov	x11, #-0x3              // =-3
    1db0:      	sub	x8, x8, x10
    1db4:      	mov	x10, #-0x10000001       // =-268435457
    1db8:      	movk	x11, #0xefff, lsl #16
    1dbc:      	add	x10, x8, x10
    1dc0:      	asr	w8, w8, #1
    1dc4:      	cmp	x10, x11
    1dc8:      	csinv	w24, w8, wzr, hs
    1dcc:      	ldrb	w8, [x9, #0x1b]
    1dd0:      	ldrb	w9, [x9, #0x1c]
    1dd4:      	ldrb	w8, [x23, x8]
    1dd8:      	cmp	w8, w9
    1ddc:      	cset	w19, eq
    1de0:      	b	0x1e38 <kprobe_unwind_python+0x1e38>
    1de4:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1de8:      	add	x8, x8, #0x0
    1dec:      	add	x0, sp, #0x40
    1df0:      	ldp	x9, x10, [x8, #0x10]
    1df4:      	mov	w1, #0x2e               // =46
    1df8:      	stp	x9, x10, [sp, #0x50]
    1dfc:      	ldr	x9, [x8, #0x20]
    1e00:      	add	x10, sp, #0x40
    1e04:      	str	x9, [sp, #0x60]
    1e08:      	ldur	x9, [x8, #0x26]
    1e0c:      	stur	x9, [sp, #0x66]
    1e10:      	ldp	x9, x8, [x8]
    1e14:      	stp	x9, x8, [sp, #0x40]
    1e18:      	mov	w8, #0x2e               // =46
    1e1c:      	mov	w9, #0x6                // =6
    1e20:      	ldr	w2, [sp, #0x88]
    1e24:      	blr	x9
    1e28:      	cbnz	w19, 0x16dc <kprobe_unwind_python+0x16dc>
    1e2c:      	b	0x19f8 <kprobe_unwind_python+0x19f8>
    1e30:      	ldr	w24, [x23, x8]
    1e34:      	mov	w19, wzr
    1e38:      	ldr	x8, [sp, #0x8]
    1e3c:      	cbz	x8, 0x1edc <kprobe_unwind_python+0x1edc>
    1e40:      	ldr	x8, [sp, #0x28]
    1e44:      	ldrb	w8, [x8, #0x1d]
    1e48:      	cmp	w8, #0xbc
    1e4c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1e50:      	ldr	x8, [sp, #0x28]
    1e54:      	ldrb	w8, [x8, #0x1e]
    1e58:      	cmp	w8, #0xbc
    1e5c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1e60:      	ldr	x8, [sp, #0x28]
    1e64:      	ldrb	w8, [x8, #0x1f]
    1e68:      	cmp	w8, #0xbc
    1e6c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1e70:      	ldr	x8, [sp, #0x28]
    1e74:      	ldrb	w8, [x8, #0x20]
    1e78:      	cmp	w8, #0xbc
    1e7c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    1e80:      	ldr	x0, [sp, #0x18]
    1e84:      	ldr	x2, [sp, #0x8]
    1e88:      	mov	w8, #0xc0               // =192
    1e8c:      	mov	w9, #0x70               // =112
    1e90:      	mov	w1, #0xc0               // =192
    1e94:      	blr	x9
    1e98:      	cbnz	x0, 0xa8c <kprobe_unwind_python+0xa8c>
    1e9c:      	ldr	x8, [sp, #0x28]
    1ea0:      	ldr	x12, [sp, #0x18]
    1ea4:      	ldrb	w10, [x8, #0x1e]
    1ea8:      	ldrb	w9, [x8, #0x1d]
    1eac:      	ldrb	w11, [x8, #0x1f]
    1eb0:      	ldrb	w8, [x8, #0x20]
    1eb4:      	ldr	w10, [x12, x10]
    1eb8:      	ldr	w9, [x12, x9]
    1ebc:      	ldr	w11, [x12, x11]
    1ec0:      	ldr	w8, [x12, x8]
    1ec4:      	lsl	w10, w10, #18
    1ec8:      	add	w9, w10, w9, lsl #25
    1ecc:      	add	w9, w9, w11, lsl #10
    1ed0:      	add	w8, w9, w8
    1ed4:      	orr	x29, x8, x24, lsl #32
    1ed8:      	b	0x20ec <kprobe_unwind_python+0x20ec>
    1edc:      	ldr	w8, [x25]
    1ee0:      	cbz	w8, 0x1f34 <kprobe_unwind_python+0x1f34>
    1ee4:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1ee8:      	add	x8, x8, #0x0
    1eec:      	add	x0, sp, #0x40
    1ef0:      	ldp	x9, x10, [x8, #0x10]
    1ef4:      	mov	w1, #0x2f               // =47
    1ef8:      	mov	x2, x29
    1efc:      	stp	x9, x10, [sp, #0x50]
    1f00:      	ldr	x9, [x8, #0x20]
    1f04:      	add	x10, sp, #0x40
    1f08:      	str	x9, [sp, #0x60]
    1f0c:      	ldur	x9, [x8, #0x27]
    1f10:      	stur	x9, [sp, #0x67]
    1f14:      	ldp	x9, x8, [x8]
    1f18:      	stp	x9, x8, [sp, #0x40]
    1f1c:      	mov	w8, #0x2f               // =47
    1f20:      	mov	w9, #0x6                // =6
    1f24:      	ldr	x8, [sp, #0x28]
    1f28:      	ldrb	w8, [x8, #0x19]
    1f2c:      	add	x3, x29, x8
    1f30:      	blr	x9
    1f34:      	mov	w8, #0x1c               // =28
    1f38:      	adrp	x0, 0x1000 <kprobe_unwind_python+0x1000>
    1f3c:      	add	x9, sp, #0x88
    1f40:      	str	w8, [sp, #0x88]
    1f44:      	mov	w8, #0x1                // =1
    1f48:      	add	x1, sp, #0x88
    1f4c:      	ldr	x0, [x0]
    1f50:      	blr	x8
    1f54:      	cbz	x0, 0x2098 <kprobe_unwind_python+0x2098>
    1f58:      	ldr	x8, [x0]
    1f5c:      	add	x8, x8, #0x1
    1f60:      	str	x8, [x0]
    1f64:      	b	0x20e4 <kprobe_unwind_python+0x20e4>
    1f68:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1f6c:      	add	x8, x8, #0x0
    1f70:      	add	x0, sp, #0x40
    1f74:      	ldp	x9, x10, [x8, #0x10]
    1f78:      	mov	w1, #0x2f               // =47
    1f7c:      	stp	x9, x10, [sp, #0x50]
    1f80:      	ldr	x9, [x8, #0x20]
    1f84:      	add	x10, sp, #0x40
    1f88:      	str	x9, [sp, #0x60]
    1f8c:      	ldur	x9, [x8, #0x27]
    1f90:      	stur	x9, [sp, #0x67]
    1f94:      	ldp	x9, x8, [x8]
    1f98:      	stp	x9, x8, [sp, #0x40]
    1f9c:      	mov	w8, #0x2f               // =47
    1fa0:      	mov	w9, #0x6                // =6
    1fa4:      	ldr	x8, [sp, #0x28]
    1fa8:      	ldr	x2, [sp, #0x10]
    1fac:      	ldrb	w8, [x8, #0x19]
    1fb0:      	add	x3, x2, x8
    1fb4:      	blr	x9
    1fb8:      	b	0x1b9c <kprobe_unwind_python+0x1b9c>
    1fbc:      	adrp	x8, 0x1000 <kprobe_unwind_python+0x1000>
    1fc0:      	add	x8, x8, #0x0
    1fc4:      	add	x0, sp, #0x40
    1fc8:      	ldp	x9, x10, [x8]
    1fcc:      	ldr	x8, [x8, #0x10]
    1fd0:      	mov	w1, #0x18               // =24
    1fd4:      	mov	x3, x22
    1fd8:      	stp	x9, x10, [sp, #0x40]
    1fdc:      	str	x8, [sp, #0x50]
    1fe0:      	mov	w8, #0x18               // =24
    1fe4:      	mov	w9, #0x6                // =6
    1fe8:      	add	x10, sp, #0x40
    1fec:      	ldr	x2, [sp, #0x8]
    1ff0:      	blr	x9
    1ff4:      	ldr	w8, [x21, #0x2c0]
    1ff8:      	cmp	w8, #0x7e
    1ffc:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    2000:      	b	0x1c48 <kprobe_unwind_python+0x1c48>
    2004:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2008:      	add	x8, x8, #0x0
    200c:      	add	x0, sp, #0x40
    2010:      	ldp	x9, x10, [x8, #0x10]
    2014:      	mov	w1, #0x2e               // =46
    2018:      	stp	x9, x10, [sp, #0x50]
    201c:      	ldr	x9, [x8, #0x20]
    2020:      	add	x10, sp, #0x40
    2024:      	str	x9, [sp, #0x60]
    2028:      	ldur	x9, [x8, #0x26]
    202c:      	stur	x9, [sp, #0x66]
    2030:      	ldp	x9, x8, [x8]
    2034:      	stp	x9, x8, [sp, #0x40]
    2038:      	mov	w8, #0x2e               // =46
    203c:      	mov	w9, #0x6                // =6
    2040:      	ldr	w2, [sp, #0x88]
    2044:      	blr	x9
    2048:      	b	0x1c2c <kprobe_unwind_python+0x1c2c>
    204c:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2050:      	add	x8, x8, #0x0
    2054:      	add	x0, sp, #0x40
    2058:      	ldp	x9, x10, [x8, #0x10]
    205c:      	mov	w1, #0x2e               // =46
    2060:      	stp	x9, x10, [sp, #0x50]
    2064:      	ldr	x9, [x8, #0x20]
    2068:      	add	x10, sp, #0x40
    206c:      	str	x9, [sp, #0x60]
    2070:      	ldur	x9, [x8, #0x26]
    2074:      	stur	x9, [sp, #0x66]
    2078:      	ldp	x9, x8, [x8]
    207c:      	stp	x9, x8, [sp, #0x40]
    2080:      	mov	w8, #0x2e               // =46
    2084:      	mov	w9, #0x6                // =6
    2088:      	ldr	w2, [sp, #0x88]
    208c:      	blr	x9
    2090:      	cbnz	w19, 0xf58 <kprobe_unwind_python+0xf58>
    2094:      	b	0x1d00 <kprobe_unwind_python+0x1d00>
    2098:      	ldr	w8, [x25]
    209c:      	cbz	w8, 0x20e4 <kprobe_unwind_python+0x20e4>
    20a0:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    20a4:      	add	x8, x8, #0x0
    20a8:      	add	x0, sp, #0x40
    20ac:      	ldp	x9, x10, [x8, #0x10]
    20b0:      	mov	w1, #0x2e               // =46
    20b4:      	stp	x9, x10, [sp, #0x50]
    20b8:      	ldr	x9, [x8, #0x20]
    20bc:      	add	x10, sp, #0x40
    20c0:      	str	x9, [sp, #0x60]
    20c4:      	ldur	x9, [x8, #0x26]
    20c8:      	stur	x9, [sp, #0x66]
    20cc:      	ldp	x9, x8, [x8]
    20d0:      	stp	x9, x8, [sp, #0x40]
    20d4:      	mov	w8, #0x2e               // =46
    20d8:      	mov	w9, #0x6                // =6
    20dc:      	ldr	w2, [sp, #0x88]
    20e0:      	blr	x9
    20e4:      	mov	x29, #-0x2              // =-2
    20e8:      	str	xzr, [sp, #0x8]
    20ec:      	ldr	w8, [x25]
    20f0:      	cbz	w8, 0x212c <kprobe_unwind_python+0x212c>
    20f4:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    20f8:      	add	x8, x8, #0x0
    20fc:      	add	x0, sp, #0x40
    2100:      	ldp	x9, x10, [x8]
    2104:      	ldr	x8, [x8, #0x10]
    2108:      	mov	w1, #0x18               // =24
    210c:      	mov	x3, x29
    2110:      	stp	x9, x10, [sp, #0x40]
    2114:      	str	x8, [sp, #0x50]
    2118:      	mov	w8, #0x18               // =24
    211c:      	mov	w9, #0x6                // =6
    2120:      	add	x10, sp, #0x40
    2124:      	ldr	x2, [sp, #0x8]
    2128:      	blr	x9
    212c:      	ldr	w8, [x21, #0x2c0]
    2130:      	cmp	w8, #0x7e
    2134:      	b.hi	0x18a8 <kprobe_unwind_python+0x18a8>
    2138:      	add	w9, w8, #0x1
    213c:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    2140:      	add	x1, sp, #0x88
    2144:      	str	w9, [x21, #0x2c0]
    2148:      	mov	w9, #0x18               // =24
    214c:      	umaddl	x8, w8, w9, x21
    2150:      	ldr	x9, [sp, #0x8]
    2154:      	str	x29, [x8, #0x2d8]
    2158:      	str	wzr, [x8, #0x2e4]
    215c:      	str	x9, [x8, #0x2d0]
    2160:      	mov	w9, #0x1                // =1
    2164:      	strb	w9, [x8, #0x2e0]
    2168:      	add	x8, x8, #0x2d0
    216c:      	stur	wzr, [x8, #0x11]
    2170:      	mov	w8, #0x16               // =22
    2174:      	str	w8, [sp, #0x88]
    2178:      	add	x8, sp, #0x88
    217c:      	ldr	x0, [x0]
    2180:      	blr	x9
    2184:      	cbz	x0, 0x2198 <kprobe_unwind_python+0x2198>
    2188:      	ldr	x8, [x0]
    218c:      	add	x8, x8, #0x1
    2190:      	str	x8, [x0]
    2194:      	b	0x21e4 <kprobe_unwind_python+0x21e4>
    2198:      	ldr	w8, [x25]
    219c:      	cbz	w8, 0x21e4 <kprobe_unwind_python+0x21e4>
    21a0:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    21a4:      	add	x8, x8, #0x0
    21a8:      	add	x0, sp, #0x40
    21ac:      	ldp	x9, x10, [x8, #0x10]
    21b0:      	mov	w1, #0x2e               // =46
    21b4:      	stp	x9, x10, [sp, #0x50]
    21b8:      	ldr	x9, [x8, #0x20]
    21bc:      	add	x10, sp, #0x40
    21c0:      	str	x9, [sp, #0x60]
    21c4:      	ldur	x9, [x8, #0x26]
    21c8:      	stur	x9, [sp, #0x66]
    21cc:      	ldp	x9, x8, [x8]
    21d0:      	stp	x9, x8, [sp, #0x40]
    21d4:      	mov	w8, #0x2e               // =46
    21d8:      	mov	w9, #0x6                // =6
    21dc:      	ldr	w2, [sp, #0x88]
    21e0:      	blr	x9
    21e4:      	cbnz	w19, 0x16dc <kprobe_unwind_python+0x16dc>
    21e8:      	ldr	x8, [sp, #0x10]
    21ec:      	cbz	x8, 0x22e0 <kprobe_unwind_python+0x22e0>
    21f0:      	ldr	x8, [sp, #0x28]
    21f4:      	ldrb	w8, [x8, #0x19]
    21f8:      	cmp	w8, #0x78
    21fc:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    2200:      	ldr	x8, [sp, #0x28]
    2204:      	ldrb	w8, [x8, #0x18]
    2208:      	cmp	w8, #0x78
    220c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    2210:      	ldr	x8, [sp, #0x28]
    2214:      	ldrb	w8, [x8, #0x1a]
    2218:      	cmp	w8, #0x78
    221c:      	b.hi	0x22d0 <kprobe_unwind_python+0x22d0>
    2220:      	ldr	x8, [sp, #0x28]
    2224:      	ldrsb	w8, [x8, #0x1b]
    2228:      	tbnz	w8, #0x1f, 0x22d0 <kprobe_unwind_python+0x22d0>
    222c:      	ldr	x2, [sp, #0x10]
    2230:      	mov	w8, #0x80               // =128
    2234:      	mov	w9, #0x70               // =112
    2238:      	mov	x0, x23
    223c:      	mov	w1, #0x80               // =128
    2240:      	blr	x9
    2244:      	cbnz	x0, 0x1a58 <kprobe_unwind_python+0x1a58>
    2248:      	ldr	x8, [sp, #0x28]
    224c:      	ldrb	w9, [x8, #0x19]
    2250:      	ldr	x9, [x23, x9]
    2254:      	str	x9, [sp, #0x8]
    2258:      	ldrb	w9, [x8, #0x18]
    225c:      	ldr	x8, [x8, #0x8]
    2260:      	ldr	x29, [x23, x9]
    2264:      	cbz	x8, 0x2274 <kprobe_unwind_python+0x2274>
    2268:      	ldr	x9, [sp, #0x8]
    226c:      	cmp	x9, x8
    2270:      	b.eq	0xf58 <kprobe_unwind_python+0xf58>
    2274:      	ldr	x8, [sp, #0x28]
    2278:      	mov	x22, #-0x3              // =-3
    227c:      	movk	x22, #0xefff, lsl #16
    2280:      	ldrb	w9, [x8, #0x22]
    2284:      	ldrb	w8, [x8, #0x1a]
    2288:      	cbz	w9, 0x22e8 <kprobe_unwind_python+0x22e8>
    228c:      	ldr	x9, [sp, #0x28]
    2290:      	ldr	x11, [sp, #0x8]
    2294:      	ldr	x8, [x23, x8]
    2298:      	ldrb	w10, [x9, #0x21]
    229c:      	add	x10, x11, x10
    22a0:      	sub	x8, x8, x10
    22a4:      	mov	x10, #-0x10000001       // =-268435457
    22a8:      	add	x10, x8, x10
    22ac:      	asr	w8, w8, #1
    22b0:      	cmp	x10, x22
    22b4:      	csinv	w24, w8, wzr, hs
    22b8:      	ldrb	w8, [x9, #0x1b]
    22bc:      	ldrb	w9, [x9, #0x1c]
    22c0:      	ldrb	w8, [x23, x8]
    22c4:      	cmp	w8, w9
    22c8:      	cset	w19, eq
    22cc:      	b	0x22f0 <kprobe_unwind_python+0x22f0>
    22d0:      	ldr	x29, [sp, #0x10]
    22d4:      	mov	w8, wzr
    22d8:      	mov	w9, #0x1                // =1
    22dc:      	b	0x37a4 <kprobe_unwind_python+0x37a4>
    22e0:      	mov	x29, xzr
    22e4:      	b	0x3404 <kprobe_unwind_python+0x3404>
    22e8:      	ldr	w24, [x23, x8]
    22ec:      	mov	w19, wzr
    22f0:      	ldr	x8, [sp, #0x8]
    22f4:      	cbz	x8, 0x2394 <kprobe_unwind_python+0x2394>
    22f8:      	ldr	x8, [sp, #0x28]
    22fc:      	ldrb	w8, [x8, #0x1d]
    2300:      	cmp	w8, #0xbc
    2304:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2308:      	ldr	x8, [sp, #0x28]
    230c:      	ldrb	w8, [x8, #0x1e]
    2310:      	cmp	w8, #0xbc
    2314:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2318:      	ldr	x8, [sp, #0x28]
    231c:      	ldrb	w8, [x8, #0x1f]
    2320:      	cmp	w8, #0xbc
    2324:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2328:      	ldr	x8, [sp, #0x28]
    232c:      	ldrb	w8, [x8, #0x20]
    2330:      	cmp	w8, #0xbc
    2334:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2338:      	ldr	x0, [sp, #0x18]
    233c:      	ldr	x2, [sp, #0x8]
    2340:      	mov	w8, #0xc0               // =192
    2344:      	mov	w9, #0x70               // =112
    2348:      	mov	w1, #0xc0               // =192
    234c:      	blr	x9
    2350:      	cbnz	x0, 0xa90 <kprobe_unwind_python+0xa90>
    2354:      	ldr	x8, [sp, #0x28]
    2358:      	ldr	x12, [sp, #0x18]
    235c:      	ldrb	w10, [x8, #0x1e]
    2360:      	ldrb	w9, [x8, #0x1d]
    2364:      	ldrb	w11, [x8, #0x1f]
    2368:      	ldrb	w8, [x8, #0x20]
    236c:      	ldr	w10, [x12, x10]
    2370:      	ldr	w9, [x12, x9]
    2374:      	ldr	w11, [x12, x11]
    2378:      	ldr	w8, [x12, x8]
    237c:      	lsl	w10, w10, #18
    2380:      	add	w9, w10, w9, lsl #25
    2384:      	add	w9, w9, w11, lsl #10
    2388:      	add	w8, w9, w8
    238c:      	orr	x24, x8, x24, lsl #32
    2390:      	b	0x2474 <kprobe_unwind_python+0x2474>
    2394:      	ldr	w8, [x25]
    2398:      	cbz	w8, 0x23ec <kprobe_unwind_python+0x23ec>
    239c:      	adrp	x10, 0x2000 <kprobe_unwind_python+0x2000>
    23a0:      	add	x10, x10, #0x0
    23a4:      	add	x0, sp, #0x40
    23a8:      	ldp	x8, x9, [x10, #0x10]
    23ac:      	mov	w1, #0x2f               // =47
    23b0:      	stp	x8, x9, [sp, #0x50]
    23b4:      	ldr	x8, [x10, #0x20]
    23b8:      	str	x8, [sp, #0x60]
    23bc:      	ldur	x8, [x10, #0x27]
    23c0:      	stur	x8, [sp, #0x67]
    23c4:      	ldp	x8, x9, [x10]
    23c8:      	add	x10, sp, #0x40
    23cc:      	stp	x8, x9, [sp, #0x40]
    23d0:      	mov	w8, #0x2f               // =47
    23d4:      	mov	w9, #0x6                // =6
    23d8:      	ldr	x8, [sp, #0x28]
    23dc:      	ldr	x2, [sp, #0x10]
    23e0:      	ldrb	w8, [x8, #0x19]
    23e4:      	add	x3, x2, x8
    23e8:      	blr	x9
    23ec:      	mov	w8, #0x1c               // =28
    23f0:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    23f4:      	add	x9, sp, #0x88
    23f8:      	str	w8, [sp, #0x88]
    23fc:      	mov	w8, #0x1                // =1
    2400:      	add	x1, sp, #0x88
    2404:      	ldr	x0, [x0]
    2408:      	blr	x8
    240c:      	cbz	x0, 0x2420 <kprobe_unwind_python+0x2420>
    2410:      	ldr	x8, [x0]
    2414:      	add	x8, x8, #0x1
    2418:      	str	x8, [x0]
    241c:      	b	0x246c <kprobe_unwind_python+0x246c>
    2420:      	ldr	w8, [x25]
    2424:      	cbz	w8, 0x246c <kprobe_unwind_python+0x246c>
    2428:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    242c:      	add	x8, x8, #0x0
    2430:      	add	x0, sp, #0x40
    2434:      	ldp	x9, x10, [x8, #0x10]
    2438:      	mov	w1, #0x2e               // =46
    243c:      	stp	x9, x10, [sp, #0x50]
    2440:      	ldr	x9, [x8, #0x20]
    2444:      	add	x10, sp, #0x40
    2448:      	str	x9, [sp, #0x60]
    244c:      	ldur	x9, [x8, #0x26]
    2450:      	stur	x9, [sp, #0x66]
    2454:      	ldp	x9, x8, [x8]
    2458:      	stp	x9, x8, [sp, #0x40]
    245c:      	mov	w8, #0x2e               // =46
    2460:      	mov	w9, #0x6                // =6
    2464:      	ldr	w2, [sp, #0x88]
    2468:      	blr	x9
    246c:      	mov	x24, #-0x2              // =-2
    2470:      	str	xzr, [sp, #0x8]
    2474:      	ldr	w8, [x25]
    2478:      	cbz	w8, 0x24b4 <kprobe_unwind_python+0x24b4>
    247c:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2480:      	add	x8, x8, #0x0
    2484:      	add	x0, sp, #0x40
    2488:      	ldp	x9, x10, [x8]
    248c:      	ldr	x8, [x8, #0x10]
    2490:      	mov	w1, #0x18               // =24
    2494:      	mov	x3, x24
    2498:      	stp	x9, x10, [sp, #0x40]
    249c:      	str	x8, [sp, #0x50]
    24a0:      	mov	w8, #0x18               // =24
    24a4:      	mov	w9, #0x6                // =6
    24a8:      	add	x10, sp, #0x40
    24ac:      	ldr	x2, [sp, #0x8]
    24b0:      	blr	x9
    24b4:      	ldr	w8, [x21, #0x2c0]
    24b8:      	cmp	w8, #0x7e
    24bc:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    24c0:      	add	w9, w8, #0x1
    24c4:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    24c8:      	add	x1, sp, #0x88
    24cc:      	str	w9, [x21, #0x2c0]
    24d0:      	mov	w9, #0x18               // =24
    24d4:      	umaddl	x8, w8, w9, x21
    24d8:      	ldr	x9, [sp, #0x8]
    24dc:      	str	x24, [x8, #0x2d8]
    24e0:      	str	wzr, [x8, #0x2e4]
    24e4:      	str	x9, [x8, #0x2d0]
    24e8:      	mov	w9, #0x1                // =1
    24ec:      	strb	w9, [x8, #0x2e0]
    24f0:      	add	x8, x8, #0x2d0
    24f4:      	stur	wzr, [x8, #0x11]
    24f8:      	mov	w8, #0x16               // =22
    24fc:      	str	w8, [sp, #0x88]
    2500:      	add	x8, sp, #0x88
    2504:      	ldr	x0, [x0]
    2508:      	blr	x9
    250c:      	cbz	x0, 0x2520 <kprobe_unwind_python+0x2520>
    2510:      	ldr	x8, [x0]
    2514:      	add	x8, x8, #0x1
    2518:      	str	x8, [x0]
    251c:      	b	0x256c <kprobe_unwind_python+0x256c>
    2520:      	ldr	w8, [x25]
    2524:      	cbz	w8, 0x256c <kprobe_unwind_python+0x256c>
    2528:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    252c:      	add	x8, x8, #0x0
    2530:      	add	x0, sp, #0x40
    2534:      	ldp	x9, x10, [x8, #0x10]
    2538:      	mov	w1, #0x2e               // =46
    253c:      	stp	x9, x10, [sp, #0x50]
    2540:      	ldr	x9, [x8, #0x20]
    2544:      	add	x10, sp, #0x40
    2548:      	str	x9, [sp, #0x60]
    254c:      	ldur	x9, [x8, #0x26]
    2550:      	stur	x9, [sp, #0x66]
    2554:      	ldp	x9, x8, [x8]
    2558:      	stp	x9, x8, [sp, #0x40]
    255c:      	mov	w8, #0x2e               // =46
    2560:      	mov	w9, #0x6                // =6
    2564:      	ldr	w2, [sp, #0x88]
    2568:      	blr	x9
    256c:      	cbnz	w19, 0xf58 <kprobe_unwind_python+0xf58>
    2570:      	cbz	x29, 0x3400 <kprobe_unwind_python+0x3400>
    2574:      	ldr	x8, [sp, #0x28]
    2578:      	ldrb	w8, [x8, #0x19]
    257c:      	cmp	w8, #0x78
    2580:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2584:      	ldr	x8, [sp, #0x28]
    2588:      	ldrb	w8, [x8, #0x18]
    258c:      	cmp	w8, #0x78
    2590:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2594:      	ldr	x8, [sp, #0x28]
    2598:      	ldrb	w8, [x8, #0x1a]
    259c:      	cmp	w8, #0x78
    25a0:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    25a4:      	ldr	x8, [sp, #0x28]
    25a8:      	ldrsb	w8, [x8, #0x1b]
    25ac:      	tbnz	w8, #0x1f, 0x380c <kprobe_unwind_python+0x380c>
    25b0:      	mov	w8, #0x80               // =128
    25b4:      	mov	w9, #0x70               // =112
    25b8:      	mov	x2, x29
    25bc:      	mov	x0, x23
    25c0:      	mov	w1, #0x80               // =128
    25c4:      	blr	x9
    25c8:      	cbnz	x0, 0xc38 <kprobe_unwind_python+0xc38>
    25cc:      	ldr	x8, [sp, #0x28]
    25d0:      	ldrb	w9, [x8, #0x19]
    25d4:      	ldr	x9, [x23, x9]
    25d8:      	str	x9, [sp, #0x8]
    25dc:      	ldrb	w9, [x8, #0x18]
    25e0:      	ldr	x8, [x8, #0x8]
    25e4:      	ldr	x24, [x23, x9]
    25e8:      	cbz	x8, 0x25f8 <kprobe_unwind_python+0x25f8>
    25ec:      	ldr	x9, [sp, #0x8]
    25f0:      	cmp	x9, x8
    25f4:      	b.eq	0x36a8 <kprobe_unwind_python+0x36a8>
    25f8:      	ldr	x8, [sp, #0x28]
    25fc:      	ldrb	w9, [x8, #0x22]
    2600:      	ldrb	w8, [x8, #0x1a]
    2604:      	cbz	w9, 0x2650 <kprobe_unwind_python+0x2650>
    2608:      	ldr	x9, [sp, #0x28]
    260c:      	ldr	x11, [sp, #0x8]
    2610:      	ldr	x8, [x23, x8]
    2614:      	ldrb	w10, [x9, #0x21]
    2618:      	add	x10, x11, x10
    261c:      	sub	x8, x8, x10
    2620:      	mov	x10, #-0x10000001       // =-268435457
    2624:      	add	x10, x8, x10
    2628:      	asr	w8, w8, #1
    262c:      	cmp	x10, x22
    2630:      	csinv	w19, w8, wzr, hs
    2634:      	ldrb	w8, [x9, #0x1b]
    2638:      	ldrb	w9, [x9, #0x1c]
    263c:      	ldrb	w8, [x23, x8]
    2640:      	cmp	w8, w9
    2644:      	cset	w8, eq
    2648:      	str	w8, [sp, #0x10]
    264c:      	b	0x2658 <kprobe_unwind_python+0x2658>
    2650:      	ldr	w19, [x23, x8]
    2654:      	str	wzr, [sp, #0x10]
    2658:      	ldr	x8, [sp, #0x8]
    265c:      	cbz	x8, 0x26fc <kprobe_unwind_python+0x26fc>
    2660:      	ldr	x8, [sp, #0x28]
    2664:      	ldrb	w8, [x8, #0x1d]
    2668:      	cmp	w8, #0xbc
    266c:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2670:      	ldr	x8, [sp, #0x28]
    2674:      	ldrb	w8, [x8, #0x1e]
    2678:      	cmp	w8, #0xbc
    267c:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2680:      	ldr	x8, [sp, #0x28]
    2684:      	ldrb	w8, [x8, #0x1f]
    2688:      	cmp	w8, #0xbc
    268c:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2690:      	ldr	x8, [sp, #0x28]
    2694:      	ldrb	w8, [x8, #0x20]
    2698:      	cmp	w8, #0xbc
    269c:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    26a0:      	ldr	x0, [sp, #0x18]
    26a4:      	ldr	x2, [sp, #0x8]
    26a8:      	mov	w8, #0xc0               // =192
    26ac:      	mov	w9, #0x70               // =112
    26b0:      	mov	w1, #0xc0               // =192
    26b4:      	blr	x9
    26b8:      	cbnz	x0, 0x3478 <kprobe_unwind_python+0x3478>
    26bc:      	ldr	x8, [sp, #0x28]
    26c0:      	ldr	x12, [sp, #0x18]
    26c4:      	ldrb	w10, [x8, #0x1e]
    26c8:      	ldrb	w9, [x8, #0x1d]
    26cc:      	ldrb	w11, [x8, #0x1f]
    26d0:      	ldrb	w8, [x8, #0x20]
    26d4:      	ldr	w10, [x12, x10]
    26d8:      	ldr	w9, [x12, x9]
    26dc:      	ldr	w11, [x12, x11]
    26e0:      	ldr	w8, [x12, x8]
    26e4:      	lsl	w10, w10, #18
    26e8:      	add	w9, w10, w9, lsl #25
    26ec:      	add	w9, w9, w11, lsl #10
    26f0:      	add	w8, w9, w8
    26f4:      	orr	x29, x8, x19, lsl #32
    26f8:      	b	0x27dc <kprobe_unwind_python+0x27dc>
    26fc:      	ldr	w8, [x25]
    2700:      	cbz	w8, 0x2754 <kprobe_unwind_python+0x2754>
    2704:      	adrp	x10, 0x2000 <kprobe_unwind_python+0x2000>
    2708:      	add	x10, x10, #0x0
    270c:      	add	x0, sp, #0x40
    2710:      	ldp	x8, x9, [x10, #0x10]
    2714:      	mov	w1, #0x2f               // =47
    2718:      	mov	x2, x29
    271c:      	stp	x8, x9, [sp, #0x50]
    2720:      	ldr	x8, [x10, #0x20]
    2724:      	str	x8, [sp, #0x60]
    2728:      	ldur	x8, [x10, #0x27]
    272c:      	stur	x8, [sp, #0x67]
    2730:      	ldp	x8, x9, [x10]
    2734:      	add	x10, sp, #0x40
    2738:      	stp	x8, x9, [sp, #0x40]
    273c:      	mov	w8, #0x2f               // =47
    2740:      	mov	w9, #0x6                // =6
    2744:      	ldr	x8, [sp, #0x28]
    2748:      	ldrb	w8, [x8, #0x19]
    274c:      	add	x3, x29, x8
    2750:      	blr	x9
    2754:      	mov	w8, #0x1c               // =28
    2758:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    275c:      	add	x9, sp, #0x88
    2760:      	str	w8, [sp, #0x88]
    2764:      	mov	w8, #0x1                // =1
    2768:      	add	x1, sp, #0x88
    276c:      	ldr	x0, [x0]
    2770:      	blr	x8
    2774:      	cbz	x0, 0x2788 <kprobe_unwind_python+0x2788>
    2778:      	ldr	x8, [x0]
    277c:      	add	x8, x8, #0x1
    2780:      	str	x8, [x0]
    2784:      	b	0x27d4 <kprobe_unwind_python+0x27d4>
    2788:      	ldr	w8, [x25]
    278c:      	cbz	w8, 0x27d4 <kprobe_unwind_python+0x27d4>
    2790:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2794:      	add	x8, x8, #0x0
    2798:      	add	x0, sp, #0x40
    279c:      	ldp	x9, x10, [x8, #0x10]
    27a0:      	mov	w1, #0x2e               // =46
    27a4:      	stp	x9, x10, [sp, #0x50]
    27a8:      	ldr	x9, [x8, #0x20]
    27ac:      	add	x10, sp, #0x40
    27b0:      	str	x9, [sp, #0x60]
    27b4:      	ldur	x9, [x8, #0x26]
    27b8:      	stur	x9, [sp, #0x66]
    27bc:      	ldp	x9, x8, [x8]
    27c0:      	stp	x9, x8, [sp, #0x40]
    27c4:      	mov	w8, #0x2e               // =46
    27c8:      	mov	w9, #0x6                // =6
    27cc:      	ldr	w2, [sp, #0x88]
    27d0:      	blr	x9
    27d4:      	mov	x29, #-0x2              // =-2
    27d8:      	str	xzr, [sp, #0x8]
    27dc:      	ldr	w8, [x25]
    27e0:      	cbz	w8, 0x281c <kprobe_unwind_python+0x281c>
    27e4:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    27e8:      	add	x8, x8, #0x0
    27ec:      	add	x0, sp, #0x40
    27f0:      	ldp	x9, x10, [x8]
    27f4:      	ldr	x8, [x8, #0x10]
    27f8:      	mov	w1, #0x18               // =24
    27fc:      	mov	x3, x29
    2800:      	stp	x9, x10, [sp, #0x40]
    2804:      	str	x8, [sp, #0x50]
    2808:      	mov	w8, #0x18               // =24
    280c:      	mov	w9, #0x6                // =6
    2810:      	add	x10, sp, #0x40
    2814:      	ldr	x2, [sp, #0x8]
    2818:      	blr	x9
    281c:      	ldr	w8, [x21, #0x2c0]
    2820:      	cmp	w8, #0x7e
    2824:      	b.hi	0x35ec <kprobe_unwind_python+0x35ec>
    2828:      	add	w9, w8, #0x1
    282c:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    2830:      	add	x1, sp, #0x88
    2834:      	str	w9, [x21, #0x2c0]
    2838:      	mov	w9, #0x18               // =24
    283c:      	umaddl	x8, w8, w9, x21
    2840:      	ldr	x9, [sp, #0x8]
    2844:      	str	x29, [x8, #0x2d8]
    2848:      	str	wzr, [x8, #0x2e4]
    284c:      	str	x9, [x8, #0x2d0]
    2850:      	mov	w9, #0x1                // =1
    2854:      	strb	w9, [x8, #0x2e0]
    2858:      	add	x8, x8, #0x2d0
    285c:      	stur	wzr, [x8, #0x11]
    2860:      	mov	w8, #0x16               // =22
    2864:      	str	w8, [sp, #0x88]
    2868:      	add	x8, sp, #0x88
    286c:      	ldr	x0, [x0]
    2870:      	blr	x9
    2874:      	cbz	x0, 0x2888 <kprobe_unwind_python+0x2888>
    2878:      	ldr	x8, [x0]
    287c:      	add	x8, x8, #0x1
    2880:      	str	x8, [x0]
    2884:      	b	0x28d4 <kprobe_unwind_python+0x28d4>
    2888:      	ldr	w8, [x25]
    288c:      	cbz	w8, 0x28d4 <kprobe_unwind_python+0x28d4>
    2890:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2894:      	add	x8, x8, #0x0
    2898:      	add	x0, sp, #0x40
    289c:      	ldp	x9, x10, [x8, #0x10]
    28a0:      	mov	w1, #0x2e               // =46
    28a4:      	stp	x9, x10, [sp, #0x50]
    28a8:      	ldr	x9, [x8, #0x20]
    28ac:      	add	x10, sp, #0x40
    28b0:      	str	x9, [sp, #0x60]
    28b4:      	ldur	x9, [x8, #0x26]
    28b8:      	stur	x9, [sp, #0x66]
    28bc:      	ldp	x9, x8, [x8]
    28c0:      	stp	x9, x8, [sp, #0x40]
    28c4:      	mov	w8, #0x2e               // =46
    28c8:      	mov	w9, #0x6                // =6
    28cc:      	ldr	w2, [sp, #0x88]
    28d0:      	blr	x9
    28d4:      	ldr	w8, [sp, #0x10]
    28d8:      	cbnz	w8, 0x36a8 <kprobe_unwind_python+0x36a8>
    28dc:      	cbz	x24, 0x37b0 <kprobe_unwind_python+0x37b0>
    28e0:      	ldr	x8, [sp, #0x28]
    28e4:      	ldrb	w8, [x8, #0x19]
    28e8:      	cmp	w8, #0x78
    28ec:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    28f0:      	ldr	x8, [sp, #0x28]
    28f4:      	ldrb	w8, [x8, #0x18]
    28f8:      	cmp	w8, #0x78
    28fc:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2900:      	ldr	x8, [sp, #0x28]
    2904:      	ldrb	w8, [x8, #0x1a]
    2908:      	cmp	w8, #0x78
    290c:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2910:      	ldr	x8, [sp, #0x28]
    2914:      	ldrsb	w8, [x8, #0x1b]
    2918:      	tbnz	w8, #0x1f, 0x3798 <kprobe_unwind_python+0x3798>
    291c:      	mov	w8, #0x80               // =128
    2920:      	mov	w9, #0x70               // =112
    2924:      	mov	x2, x24
    2928:      	mov	x0, x23
    292c:      	mov	w1, #0x80               // =128
    2930:      	blr	x9
    2934:      	cbnz	x0, 0xc34 <kprobe_unwind_python+0xc34>
    2938:      	ldr	x8, [sp, #0x28]
    293c:      	ldrb	w9, [x8, #0x19]
    2940:      	ldr	x9, [x23, x9]
    2944:      	str	x9, [sp, #0x8]
    2948:      	ldrb	w9, [x8, #0x18]
    294c:      	ldr	x8, [x8, #0x8]
    2950:      	ldr	x29, [x23, x9]
    2954:      	cbz	x8, 0x2964 <kprobe_unwind_python+0x2964>
    2958:      	ldr	x9, [sp, #0x8]
    295c:      	cmp	x9, x8
    2960:      	b.eq	0xf58 <kprobe_unwind_python+0xf58>
    2964:      	ldr	x8, [sp, #0x28]
    2968:      	ldrb	w9, [x8, #0x22]
    296c:      	ldrb	w8, [x8, #0x1a]
    2970:      	cbz	w9, 0x29bc <kprobe_unwind_python+0x29bc>
    2974:      	ldr	x9, [sp, #0x28]
    2978:      	ldr	x11, [sp, #0x8]
    297c:      	ldr	x8, [x23, x8]
    2980:      	ldrb	w10, [x9, #0x21]
    2984:      	add	x10, x11, x10
    2988:      	sub	x8, x8, x10
    298c:      	mov	x10, #-0x10000001       // =-268435457
    2990:      	add	x10, x8, x10
    2994:      	asr	w8, w8, #1
    2998:      	cmp	x10, x22
    299c:      	csinv	w19, w8, wzr, hs
    29a0:      	ldrb	w8, [x9, #0x1b]
    29a4:      	ldrb	w9, [x9, #0x1c]
    29a8:      	ldrb	w8, [x23, x8]
    29ac:      	cmp	w8, w9
    29b0:      	cset	w8, eq
    29b4:      	str	w8, [sp, #0x10]
    29b8:      	b	0x29c4 <kprobe_unwind_python+0x29c4>
    29bc:      	ldr	w19, [x23, x8]
    29c0:      	str	wzr, [sp, #0x10]
    29c4:      	ldr	x8, [sp, #0x8]
    29c8:      	cbz	x8, 0x2a68 <kprobe_unwind_python+0x2a68>
    29cc:      	ldr	x8, [sp, #0x28]
    29d0:      	ldrb	w8, [x8, #0x1d]
    29d4:      	cmp	w8, #0xbc
    29d8:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    29dc:      	ldr	x8, [sp, #0x28]
    29e0:      	ldrb	w8, [x8, #0x1e]
    29e4:      	cmp	w8, #0xbc
    29e8:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    29ec:      	ldr	x8, [sp, #0x28]
    29f0:      	ldrb	w8, [x8, #0x1f]
    29f4:      	cmp	w8, #0xbc
    29f8:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    29fc:      	ldr	x8, [sp, #0x28]
    2a00:      	ldrb	w8, [x8, #0x20]
    2a04:      	cmp	w8, #0xbc
    2a08:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2a0c:      	ldr	x0, [sp, #0x18]
    2a10:      	ldr	x2, [sp, #0x8]
    2a14:      	mov	w8, #0xc0               // =192
    2a18:      	mov	w9, #0x70               // =112
    2a1c:      	mov	w1, #0xc0               // =192
    2a20:      	blr	x9
    2a24:      	cbnz	x0, 0xa90 <kprobe_unwind_python+0xa90>
    2a28:      	ldr	x8, [sp, #0x28]
    2a2c:      	ldr	x12, [sp, #0x18]
    2a30:      	ldrb	w10, [x8, #0x1e]
    2a34:      	ldrb	w9, [x8, #0x1d]
    2a38:      	ldrb	w11, [x8, #0x1f]
    2a3c:      	ldrb	w8, [x8, #0x20]
    2a40:      	ldr	w10, [x12, x10]
    2a44:      	ldr	w9, [x12, x9]
    2a48:      	ldr	w11, [x12, x11]
    2a4c:      	ldr	w8, [x12, x8]
    2a50:      	lsl	w10, w10, #18
    2a54:      	add	w9, w10, w9, lsl #25
    2a58:      	add	w9, w9, w11, lsl #10
    2a5c:      	add	w8, w9, w8
    2a60:      	orr	x19, x8, x19, lsl #32
    2a64:      	b	0x2b48 <kprobe_unwind_python+0x2b48>
    2a68:      	ldr	w8, [x25]
    2a6c:      	cbz	w8, 0x2ac0 <kprobe_unwind_python+0x2ac0>
    2a70:      	adrp	x10, 0x2000 <kprobe_unwind_python+0x2000>
    2a74:      	add	x10, x10, #0x0
    2a78:      	add	x0, sp, #0x40
    2a7c:      	ldp	x8, x9, [x10, #0x10]
    2a80:      	mov	w1, #0x2f               // =47
    2a84:      	mov	x2, x24
    2a88:      	stp	x8, x9, [sp, #0x50]
    2a8c:      	ldr	x8, [x10, #0x20]
    2a90:      	str	x8, [sp, #0x60]
    2a94:      	ldur	x8, [x10, #0x27]
    2a98:      	stur	x8, [sp, #0x67]
    2a9c:      	ldp	x8, x9, [x10]
    2aa0:      	add	x10, sp, #0x40
    2aa4:      	stp	x8, x9, [sp, #0x40]
    2aa8:      	mov	w8, #0x2f               // =47
    2aac:      	mov	w9, #0x6                // =6
    2ab0:      	ldr	x8, [sp, #0x28]
    2ab4:      	ldrb	w8, [x8, #0x19]
    2ab8:      	add	x3, x24, x8
    2abc:      	blr	x9
    2ac0:      	mov	w8, #0x1c               // =28
    2ac4:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    2ac8:      	add	x9, sp, #0x88
    2acc:      	str	w8, [sp, #0x88]
    2ad0:      	mov	w8, #0x1                // =1
    2ad4:      	add	x1, sp, #0x88
    2ad8:      	ldr	x0, [x0]
    2adc:      	blr	x8
    2ae0:      	cbz	x0, 0x2af4 <kprobe_unwind_python+0x2af4>
    2ae4:      	ldr	x8, [x0]
    2ae8:      	add	x8, x8, #0x1
    2aec:      	str	x8, [x0]
    2af0:      	b	0x2b40 <kprobe_unwind_python+0x2b40>
    2af4:      	ldr	w8, [x25]
    2af8:      	cbz	w8, 0x2b40 <kprobe_unwind_python+0x2b40>
    2afc:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2b00:      	add	x8, x8, #0x0
    2b04:      	add	x0, sp, #0x40
    2b08:      	ldp	x9, x10, [x8, #0x10]
    2b0c:      	mov	w1, #0x2e               // =46
    2b10:      	stp	x9, x10, [sp, #0x50]
    2b14:      	ldr	x9, [x8, #0x20]
    2b18:      	add	x10, sp, #0x40
    2b1c:      	str	x9, [sp, #0x60]
    2b20:      	ldur	x9, [x8, #0x26]
    2b24:      	stur	x9, [sp, #0x66]
    2b28:      	ldp	x9, x8, [x8]
    2b2c:      	stp	x9, x8, [sp, #0x40]
    2b30:      	mov	w8, #0x2e               // =46
    2b34:      	mov	w9, #0x6                // =6
    2b38:      	ldr	w2, [sp, #0x88]
    2b3c:      	blr	x9
    2b40:      	mov	x19, #-0x2              // =-2
    2b44:      	str	xzr, [sp, #0x8]
    2b48:      	ldr	w8, [x25]
    2b4c:      	cbz	w8, 0x2b88 <kprobe_unwind_python+0x2b88>
    2b50:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2b54:      	add	x8, x8, #0x0
    2b58:      	add	x0, sp, #0x40
    2b5c:      	ldp	x9, x10, [x8]
    2b60:      	ldr	x8, [x8, #0x10]
    2b64:      	mov	w1, #0x18               // =24
    2b68:      	mov	x3, x19
    2b6c:      	stp	x9, x10, [sp, #0x40]
    2b70:      	str	x8, [sp, #0x50]
    2b74:      	mov	w8, #0x18               // =24
    2b78:      	mov	w9, #0x6                // =6
    2b7c:      	add	x10, sp, #0x40
    2b80:      	ldr	x2, [sp, #0x8]
    2b84:      	blr	x9
    2b88:      	ldr	w8, [x21, #0x2c0]
    2b8c:      	cmp	w8, #0x7e
    2b90:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    2b94:      	add	w9, w8, #0x1
    2b98:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    2b9c:      	add	x1, sp, #0x88
    2ba0:      	str	w9, [x21, #0x2c0]
    2ba4:      	mov	w9, #0x18               // =24
    2ba8:      	umaddl	x8, w8, w9, x21
    2bac:      	ldr	x9, [sp, #0x8]
    2bb0:      	str	x19, [x8, #0x2d8]
    2bb4:      	str	wzr, [x8, #0x2e4]
    2bb8:      	str	x9, [x8, #0x2d0]
    2bbc:      	mov	w9, #0x1                // =1
    2bc0:      	strb	w9, [x8, #0x2e0]
    2bc4:      	add	x8, x8, #0x2d0
    2bc8:      	stur	wzr, [x8, #0x11]
    2bcc:      	mov	w8, #0x16               // =22
    2bd0:      	str	w8, [sp, #0x88]
    2bd4:      	add	x8, sp, #0x88
    2bd8:      	ldr	x0, [x0]
    2bdc:      	blr	x9
    2be0:      	cbz	x0, 0x2bf4 <kprobe_unwind_python+0x2bf4>
    2be4:      	ldr	x8, [x0]
    2be8:      	add	x8, x8, #0x1
    2bec:      	str	x8, [x0]
    2bf0:      	b	0x2c40 <kprobe_unwind_python+0x2c40>
    2bf4:      	ldr	w8, [x25]
    2bf8:      	cbz	w8, 0x2c40 <kprobe_unwind_python+0x2c40>
    2bfc:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2c00:      	add	x8, x8, #0x0
    2c04:      	add	x0, sp, #0x40
    2c08:      	ldp	x9, x10, [x8, #0x10]
    2c0c:      	mov	w1, #0x2e               // =46
    2c10:      	stp	x9, x10, [sp, #0x50]
    2c14:      	ldr	x9, [x8, #0x20]
    2c18:      	add	x10, sp, #0x40
    2c1c:      	str	x9, [sp, #0x60]
    2c20:      	ldur	x9, [x8, #0x26]
    2c24:      	stur	x9, [sp, #0x66]
    2c28:      	ldp	x9, x8, [x8]
    2c2c:      	stp	x9, x8, [sp, #0x40]
    2c30:      	mov	w8, #0x2e               // =46
    2c34:      	mov	w9, #0x6                // =6
    2c38:      	ldr	w2, [sp, #0x88]
    2c3c:      	blr	x9
    2c40:      	ldr	w8, [sp, #0x10]
    2c44:      	cbnz	w8, 0xf58 <kprobe_unwind_python+0xf58>
    2c48:      	cbz	x29, 0x3400 <kprobe_unwind_python+0x3400>
    2c4c:      	ldr	x8, [sp, #0x28]
    2c50:      	ldrb	w8, [x8, #0x19]
    2c54:      	cmp	w8, #0x78
    2c58:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2c5c:      	ldr	x8, [sp, #0x28]
    2c60:      	ldrb	w8, [x8, #0x18]
    2c64:      	cmp	w8, #0x78
    2c68:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2c6c:      	ldr	x8, [sp, #0x28]
    2c70:      	ldrb	w8, [x8, #0x1a]
    2c74:      	cmp	w8, #0x78
    2c78:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    2c7c:      	ldr	x8, [sp, #0x28]
    2c80:      	ldrsb	w8, [x8, #0x1b]
    2c84:      	tbnz	w8, #0x1f, 0x380c <kprobe_unwind_python+0x380c>
    2c88:      	mov	w8, #0x80               // =128
    2c8c:      	mov	w9, #0x70               // =112
    2c90:      	mov	x2, x29
    2c94:      	mov	x0, x23
    2c98:      	mov	w1, #0x80               // =128
    2c9c:      	blr	x9
    2ca0:      	cbnz	x0, 0xc38 <kprobe_unwind_python+0xc38>
    2ca4:      	ldr	x8, [sp, #0x28]
    2ca8:      	ldrb	w9, [x8, #0x19]
    2cac:      	ldr	x9, [x23, x9]
    2cb0:      	str	x9, [sp, #0x8]
    2cb4:      	ldrb	w9, [x8, #0x18]
    2cb8:      	ldr	x8, [x8, #0x8]
    2cbc:      	ldr	x24, [x23, x9]
    2cc0:      	cbz	x8, 0x2cd0 <kprobe_unwind_python+0x2cd0>
    2cc4:      	ldr	x9, [sp, #0x8]
    2cc8:      	cmp	x9, x8
    2ccc:      	b.eq	0x36a8 <kprobe_unwind_python+0x36a8>
    2cd0:      	ldr	x8, [sp, #0x28]
    2cd4:      	ldrb	w9, [x8, #0x22]
    2cd8:      	ldrb	w8, [x8, #0x1a]
    2cdc:      	cbz	w9, 0x2d28 <kprobe_unwind_python+0x2d28>
    2ce0:      	ldr	x9, [sp, #0x28]
    2ce4:      	ldr	x11, [sp, #0x8]
    2ce8:      	ldr	x8, [x23, x8]
    2cec:      	ldrb	w10, [x9, #0x21]
    2cf0:      	add	x10, x11, x10
    2cf4:      	sub	x8, x8, x10
    2cf8:      	mov	x10, #-0x10000001       // =-268435457
    2cfc:      	add	x10, x8, x10
    2d00:      	asr	w8, w8, #1
    2d04:      	cmp	x10, x22
    2d08:      	csinv	w19, w8, wzr, hs
    2d0c:      	ldrb	w8, [x9, #0x1b]
    2d10:      	ldrb	w9, [x9, #0x1c]
    2d14:      	ldrb	w8, [x23, x8]
    2d18:      	cmp	w8, w9
    2d1c:      	cset	w8, eq
    2d20:      	str	w8, [sp, #0x10]
    2d24:      	b	0x2d30 <kprobe_unwind_python+0x2d30>
    2d28:      	ldr	w19, [x23, x8]
    2d2c:      	str	wzr, [sp, #0x10]
    2d30:      	ldr	x8, [sp, #0x8]
    2d34:      	cbz	x8, 0x2dd4 <kprobe_unwind_python+0x2dd4>
    2d38:      	ldr	x8, [sp, #0x28]
    2d3c:      	ldrb	w8, [x8, #0x1d]
    2d40:      	cmp	w8, #0xbc
    2d44:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2d48:      	ldr	x8, [sp, #0x28]
    2d4c:      	ldrb	w8, [x8, #0x1e]
    2d50:      	cmp	w8, #0xbc
    2d54:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2d58:      	ldr	x8, [sp, #0x28]
    2d5c:      	ldrb	w8, [x8, #0x1f]
    2d60:      	cmp	w8, #0xbc
    2d64:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2d68:      	ldr	x8, [sp, #0x28]
    2d6c:      	ldrb	w8, [x8, #0x20]
    2d70:      	cmp	w8, #0xbc
    2d74:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2d78:      	ldr	x0, [sp, #0x18]
    2d7c:      	ldr	x2, [sp, #0x8]
    2d80:      	mov	w8, #0xc0               // =192
    2d84:      	mov	w9, #0x70               // =112
    2d88:      	mov	w1, #0xc0               // =192
    2d8c:      	blr	x9
    2d90:      	cbnz	x0, 0x3478 <kprobe_unwind_python+0x3478>
    2d94:      	ldr	x8, [sp, #0x28]
    2d98:      	ldr	x12, [sp, #0x18]
    2d9c:      	ldrb	w10, [x8, #0x1e]
    2da0:      	ldrb	w9, [x8, #0x1d]
    2da4:      	ldrb	w11, [x8, #0x1f]
    2da8:      	ldrb	w8, [x8, #0x20]
    2dac:      	ldr	w10, [x12, x10]
    2db0:      	ldr	w9, [x12, x9]
    2db4:      	ldr	w11, [x12, x11]
    2db8:      	ldr	w8, [x12, x8]
    2dbc:      	lsl	w10, w10, #18
    2dc0:      	add	w9, w10, w9, lsl #25
    2dc4:      	add	w9, w9, w11, lsl #10
    2dc8:      	add	w8, w9, w8
    2dcc:      	orr	x29, x8, x19, lsl #32
    2dd0:      	b	0x2eb4 <kprobe_unwind_python+0x2eb4>
    2dd4:      	ldr	w8, [x25]
    2dd8:      	cbz	w8, 0x2e2c <kprobe_unwind_python+0x2e2c>
    2ddc:      	adrp	x10, 0x2000 <kprobe_unwind_python+0x2000>
    2de0:      	add	x10, x10, #0x0
    2de4:      	add	x0, sp, #0x40
    2de8:      	ldp	x8, x9, [x10, #0x10]
    2dec:      	mov	w1, #0x2f               // =47
    2df0:      	mov	x2, x29
    2df4:      	stp	x8, x9, [sp, #0x50]
    2df8:      	ldr	x8, [x10, #0x20]
    2dfc:      	str	x8, [sp, #0x60]
    2e00:      	ldur	x8, [x10, #0x27]
    2e04:      	stur	x8, [sp, #0x67]
    2e08:      	ldp	x8, x9, [x10]
    2e0c:      	add	x10, sp, #0x40
    2e10:      	stp	x8, x9, [sp, #0x40]
    2e14:      	mov	w8, #0x2f               // =47
    2e18:      	mov	w9, #0x6                // =6
    2e1c:      	ldr	x8, [sp, #0x28]
    2e20:      	ldrb	w8, [x8, #0x19]
    2e24:      	add	x3, x29, x8
    2e28:      	blr	x9
    2e2c:      	mov	w8, #0x1c               // =28
    2e30:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    2e34:      	add	x9, sp, #0x88
    2e38:      	str	w8, [sp, #0x88]
    2e3c:      	mov	w8, #0x1                // =1
    2e40:      	add	x1, sp, #0x88
    2e44:      	ldr	x0, [x0]
    2e48:      	blr	x8
    2e4c:      	cbz	x0, 0x2e60 <kprobe_unwind_python+0x2e60>
    2e50:      	ldr	x8, [x0]
    2e54:      	add	x8, x8, #0x1
    2e58:      	str	x8, [x0]
    2e5c:      	b	0x2eac <kprobe_unwind_python+0x2eac>
    2e60:      	ldr	w8, [x25]
    2e64:      	cbz	w8, 0x2eac <kprobe_unwind_python+0x2eac>
    2e68:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2e6c:      	add	x8, x8, #0x0
    2e70:      	add	x0, sp, #0x40
    2e74:      	ldp	x9, x10, [x8, #0x10]
    2e78:      	mov	w1, #0x2e               // =46
    2e7c:      	stp	x9, x10, [sp, #0x50]
    2e80:      	ldr	x9, [x8, #0x20]
    2e84:      	add	x10, sp, #0x40
    2e88:      	str	x9, [sp, #0x60]
    2e8c:      	ldur	x9, [x8, #0x26]
    2e90:      	stur	x9, [sp, #0x66]
    2e94:      	ldp	x9, x8, [x8]
    2e98:      	stp	x9, x8, [sp, #0x40]
    2e9c:      	mov	w8, #0x2e               // =46
    2ea0:      	mov	w9, #0x6                // =6
    2ea4:      	ldr	w2, [sp, #0x88]
    2ea8:      	blr	x9
    2eac:      	mov	x29, #-0x2              // =-2
    2eb0:      	str	xzr, [sp, #0x8]
    2eb4:      	ldr	w8, [x25]
    2eb8:      	cbz	w8, 0x2ef4 <kprobe_unwind_python+0x2ef4>
    2ebc:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2ec0:      	add	x8, x8, #0x0
    2ec4:      	add	x0, sp, #0x40
    2ec8:      	ldp	x9, x10, [x8]
    2ecc:      	ldr	x8, [x8, #0x10]
    2ed0:      	mov	w1, #0x18               // =24
    2ed4:      	mov	x3, x29
    2ed8:      	stp	x9, x10, [sp, #0x40]
    2edc:      	str	x8, [sp, #0x50]
    2ee0:      	mov	w8, #0x18               // =24
    2ee4:      	mov	w9, #0x6                // =6
    2ee8:      	add	x10, sp, #0x40
    2eec:      	ldr	x2, [sp, #0x8]
    2ef0:      	blr	x9
    2ef4:      	ldr	w8, [x21, #0x2c0]
    2ef8:      	cmp	w8, #0x7e
    2efc:      	b.hi	0x35ec <kprobe_unwind_python+0x35ec>
    2f00:      	add	w9, w8, #0x1
    2f04:      	adrp	x0, 0x2000 <kprobe_unwind_python+0x2000>
    2f08:      	add	x1, sp, #0x88
    2f0c:      	str	w9, [x21, #0x2c0]
    2f10:      	mov	w9, #0x18               // =24
    2f14:      	umaddl	x8, w8, w9, x21
    2f18:      	ldr	x9, [sp, #0x8]
    2f1c:      	str	x29, [x8, #0x2d8]
    2f20:      	str	wzr, [x8, #0x2e4]
    2f24:      	str	x9, [x8, #0x2d0]
    2f28:      	mov	w9, #0x1                // =1
    2f2c:      	strb	w9, [x8, #0x2e0]
    2f30:      	add	x8, x8, #0x2d0
    2f34:      	stur	wzr, [x8, #0x11]
    2f38:      	mov	w8, #0x16               // =22
    2f3c:      	str	w8, [sp, #0x88]
    2f40:      	add	x8, sp, #0x88
    2f44:      	ldr	x0, [x0]
    2f48:      	blr	x9
    2f4c:      	cbz	x0, 0x2f60 <kprobe_unwind_python+0x2f60>
    2f50:      	ldr	x8, [x0]
    2f54:      	add	x8, x8, #0x1
    2f58:      	str	x8, [x0]
    2f5c:      	b	0x2fac <kprobe_unwind_python+0x2fac>
    2f60:      	ldr	w8, [x25]
    2f64:      	cbz	w8, 0x2fac <kprobe_unwind_python+0x2fac>
    2f68:      	adrp	x8, 0x2000 <kprobe_unwind_python+0x2000>
    2f6c:      	add	x8, x8, #0x0
    2f70:      	add	x0, sp, #0x40
    2f74:      	ldp	x9, x10, [x8, #0x10]
    2f78:      	mov	w1, #0x2e               // =46
    2f7c:      	stp	x9, x10, [sp, #0x50]
    2f80:      	ldr	x9, [x8, #0x20]
    2f84:      	add	x10, sp, #0x40
    2f88:      	str	x9, [sp, #0x60]
    2f8c:      	ldur	x9, [x8, #0x26]
    2f90:      	stur	x9, [sp, #0x66]
    2f94:      	ldp	x9, x8, [x8]
    2f98:      	stp	x9, x8, [sp, #0x40]
    2f9c:      	mov	w8, #0x2e               // =46
    2fa0:      	mov	w9, #0x6                // =6
    2fa4:      	ldr	w2, [sp, #0x88]
    2fa8:      	blr	x9
    2fac:      	ldr	w8, [sp, #0x10]
    2fb0:      	cbnz	w8, 0x36a8 <kprobe_unwind_python+0x36a8>
    2fb4:      	cbz	x24, 0x37b0 <kprobe_unwind_python+0x37b0>
    2fb8:      	ldr	x8, [sp, #0x28]
    2fbc:      	ldrb	w8, [x8, #0x19]
    2fc0:      	cmp	w8, #0x78
    2fc4:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2fc8:      	ldr	x8, [sp, #0x28]
    2fcc:      	ldrb	w8, [x8, #0x18]
    2fd0:      	cmp	w8, #0x78
    2fd4:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2fd8:      	ldr	x8, [sp, #0x28]
    2fdc:      	ldrb	w8, [x8, #0x1a]
    2fe0:      	cmp	w8, #0x78
    2fe4:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    2fe8:      	ldr	x8, [sp, #0x28]
    2fec:      	ldrsb	w8, [x8, #0x1b]
    2ff0:      	tbnz	w8, #0x1f, 0x3798 <kprobe_unwind_python+0x3798>
    2ff4:      	mov	w8, #0x80               // =128
    2ff8:      	mov	w9, #0x70               // =112
    2ffc:      	mov	x2, x24
    3000:      	mov	x0, x23
    3004:      	mov	w1, #0x80               // =128
    3008:      	blr	x9
    300c:      	cbnz	x0, 0xc34 <kprobe_unwind_python+0xc34>
    3010:      	ldr	x8, [sp, #0x28]
    3014:      	ldrb	w9, [x8, #0x19]
    3018:      	ldr	x9, [x23, x9]
    301c:      	str	x9, [sp, #0x8]
    3020:      	ldrb	w9, [x8, #0x18]
    3024:      	ldr	x8, [x8, #0x8]
    3028:      	ldr	x29, [x23, x9]
    302c:      	cbz	x8, 0x303c <kprobe_unwind_python+0x303c>
    3030:      	ldr	x9, [sp, #0x8]
    3034:      	cmp	x9, x8
    3038:      	b.eq	0xf58 <kprobe_unwind_python+0xf58>
    303c:      	ldr	x8, [sp, #0x28]
    3040:      	ldrb	w9, [x8, #0x22]
    3044:      	ldrb	w8, [x8, #0x1a]
    3048:      	cbz	w9, 0x3094 <kprobe_unwind_python+0x3094>
    304c:      	ldr	x9, [sp, #0x28]
    3050:      	ldr	x11, [sp, #0x8]
    3054:      	ldr	x8, [x23, x8]
    3058:      	ldrb	w10, [x9, #0x21]
    305c:      	add	x10, x11, x10
    3060:      	sub	x8, x8, x10
    3064:      	mov	x10, #-0x10000001       // =-268435457
    3068:      	add	x10, x8, x10
    306c:      	asr	w8, w8, #1
    3070:      	cmp	x10, x22
    3074:      	csinv	w19, w8, wzr, hs
    3078:      	ldrb	w8, [x9, #0x1b]
    307c:      	ldrb	w9, [x9, #0x1c]
    3080:      	ldrb	w8, [x23, x8]
    3084:      	cmp	w8, w9
    3088:      	cset	w8, eq
    308c:      	str	w8, [sp, #0x10]
    3090:      	b	0x309c <kprobe_unwind_python+0x309c>
    3094:      	ldr	w19, [x23, x8]
    3098:      	str	wzr, [sp, #0x10]
    309c:      	ldr	x8, [sp, #0x8]
    30a0:      	cbz	x8, 0x3140 <kprobe_unwind_python+0x3140>
    30a4:      	ldr	x8, [sp, #0x28]
    30a8:      	ldrb	w8, [x8, #0x1d]
    30ac:      	cmp	w8, #0xbc
    30b0:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    30b4:      	ldr	x8, [sp, #0x28]
    30b8:      	ldrb	w8, [x8, #0x1e]
    30bc:      	cmp	w8, #0xbc
    30c0:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    30c4:      	ldr	x8, [sp, #0x28]
    30c8:      	ldrb	w8, [x8, #0x1f]
    30cc:      	cmp	w8, #0xbc
    30d0:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    30d4:      	ldr	x8, [sp, #0x28]
    30d8:      	ldrb	w8, [x8, #0x20]
    30dc:      	cmp	w8, #0xbc
    30e0:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    30e4:      	ldr	x0, [sp, #0x18]
    30e8:      	ldr	x2, [sp, #0x8]
    30ec:      	mov	w8, #0xc0               // =192
    30f0:      	mov	w9, #0x70               // =112
    30f4:      	mov	w1, #0xc0               // =192
    30f8:      	blr	x9
    30fc:      	cbnz	x0, 0xa90 <kprobe_unwind_python+0xa90>
    3100:      	ldr	x8, [sp, #0x28]
    3104:      	ldr	x12, [sp, #0x18]
    3108:      	ldrb	w10, [x8, #0x1e]
    310c:      	ldrb	w9, [x8, #0x1d]
    3110:      	ldrb	w11, [x8, #0x1f]
    3114:      	ldrb	w8, [x8, #0x20]
    3118:      	ldr	w10, [x12, x10]
    311c:      	ldr	w9, [x12, x9]
    3120:      	ldr	w11, [x12, x11]
    3124:      	ldr	w8, [x12, x8]
    3128:      	lsl	w10, w10, #18
    312c:      	add	w9, w10, w9, lsl #25
    3130:      	add	w9, w9, w11, lsl #10
    3134:      	add	w8, w9, w8
    3138:      	orr	x19, x8, x19, lsl #32
    313c:      	b	0x3220 <kprobe_unwind_python+0x3220>
    3140:      	ldr	w8, [x25]
    3144:      	cbz	w8, 0x3198 <kprobe_unwind_python+0x3198>
    3148:      	adrp	x10, 0x3000 <kprobe_unwind_python+0x3000>
    314c:      	add	x10, x10, #0x0
    3150:      	add	x0, sp, #0x40
    3154:      	ldp	x8, x9, [x10, #0x10]
    3158:      	mov	w1, #0x2f               // =47
    315c:      	mov	x2, x24
    3160:      	stp	x8, x9, [sp, #0x50]
    3164:      	ldr	x8, [x10, #0x20]
    3168:      	str	x8, [sp, #0x60]
    316c:      	ldur	x8, [x10, #0x27]
    3170:      	stur	x8, [sp, #0x67]
    3174:      	ldp	x8, x9, [x10]
    3178:      	add	x10, sp, #0x40
    317c:      	stp	x8, x9, [sp, #0x40]
    3180:      	mov	w8, #0x2f               // =47
    3184:      	mov	w9, #0x6                // =6
    3188:      	ldr	x8, [sp, #0x28]
    318c:      	ldrb	w8, [x8, #0x19]
    3190:      	add	x3, x24, x8
    3194:      	blr	x9
    3198:      	mov	w8, #0x1c               // =28
    319c:      	adrp	x0, 0x3000 <kprobe_unwind_python+0x3000>
    31a0:      	add	x9, sp, #0x88
    31a4:      	str	w8, [sp, #0x88]
    31a8:      	mov	w8, #0x1                // =1
    31ac:      	add	x1, sp, #0x88
    31b0:      	ldr	x0, [x0]
    31b4:      	blr	x8
    31b8:      	cbz	x0, 0x31cc <kprobe_unwind_python+0x31cc>
    31bc:      	ldr	x8, [x0]
    31c0:      	add	x8, x8, #0x1
    31c4:      	str	x8, [x0]
    31c8:      	b	0x3218 <kprobe_unwind_python+0x3218>
    31cc:      	ldr	w8, [x25]
    31d0:      	cbz	w8, 0x3218 <kprobe_unwind_python+0x3218>
    31d4:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    31d8:      	add	x8, x8, #0x0
    31dc:      	add	x0, sp, #0x40
    31e0:      	ldp	x9, x10, [x8, #0x10]
    31e4:      	mov	w1, #0x2e               // =46
    31e8:      	stp	x9, x10, [sp, #0x50]
    31ec:      	ldr	x9, [x8, #0x20]
    31f0:      	add	x10, sp, #0x40
    31f4:      	str	x9, [sp, #0x60]
    31f8:      	ldur	x9, [x8, #0x26]
    31fc:      	stur	x9, [sp, #0x66]
    3200:      	ldp	x9, x8, [x8]
    3204:      	stp	x9, x8, [sp, #0x40]
    3208:      	mov	w8, #0x2e               // =46
    320c:      	mov	w9, #0x6                // =6
    3210:      	ldr	w2, [sp, #0x88]
    3214:      	blr	x9
    3218:      	mov	x19, #-0x2              // =-2
    321c:      	str	xzr, [sp, #0x8]
    3220:      	ldr	w8, [x25]
    3224:      	cbz	w8, 0x3260 <kprobe_unwind_python+0x3260>
    3228:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    322c:      	add	x8, x8, #0x0
    3230:      	add	x0, sp, #0x40
    3234:      	ldp	x9, x10, [x8]
    3238:      	ldr	x8, [x8, #0x10]
    323c:      	mov	w1, #0x18               // =24
    3240:      	mov	x3, x19
    3244:      	stp	x9, x10, [sp, #0x40]
    3248:      	str	x8, [sp, #0x50]
    324c:      	mov	w8, #0x18               // =24
    3250:      	mov	w9, #0x6                // =6
    3254:      	add	x10, sp, #0x40
    3258:      	ldr	x2, [sp, #0x8]
    325c:      	blr	x9
    3260:      	ldr	w8, [x21, #0x2c0]
    3264:      	cmp	w8, #0x7e
    3268:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    326c:      	add	w9, w8, #0x1
    3270:      	adrp	x0, 0x3000 <kprobe_unwind_python+0x3000>
    3274:      	add	x1, sp, #0x88
    3278:      	str	w9, [x21, #0x2c0]
    327c:      	mov	w9, #0x18               // =24
    3280:      	umaddl	x8, w8, w9, x21
    3284:      	ldr	x9, [sp, #0x8]
    3288:      	str	x19, [x8, #0x2d8]
    328c:      	str	wzr, [x8, #0x2e4]
    3290:      	str	x9, [x8, #0x2d0]
    3294:      	mov	w9, #0x1                // =1
    3298:      	strb	w9, [x8, #0x2e0]
    329c:      	add	x8, x8, #0x2d0
    32a0:      	stur	wzr, [x8, #0x11]
    32a4:      	mov	w8, #0x16               // =22
    32a8:      	str	w8, [sp, #0x88]
    32ac:      	add	x8, sp, #0x88
    32b0:      	ldr	x0, [x0]
    32b4:      	blr	x9
    32b8:      	cbz	x0, 0x32cc <kprobe_unwind_python+0x32cc>
    32bc:      	ldr	x8, [x0]
    32c0:      	add	x8, x8, #0x1
    32c4:      	str	x8, [x0]
    32c8:      	b	0x3318 <kprobe_unwind_python+0x3318>
    32cc:      	ldr	w8, [x25]
    32d0:      	cbz	w8, 0x3318 <kprobe_unwind_python+0x3318>
    32d4:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    32d8:      	add	x8, x8, #0x0
    32dc:      	add	x0, sp, #0x40
    32e0:      	ldp	x9, x10, [x8, #0x10]
    32e4:      	mov	w1, #0x2e               // =46
    32e8:      	stp	x9, x10, [sp, #0x50]
    32ec:      	ldr	x9, [x8, #0x20]
    32f0:      	add	x10, sp, #0x40
    32f4:      	str	x9, [sp, #0x60]
    32f8:      	ldur	x9, [x8, #0x26]
    32fc:      	stur	x9, [sp, #0x66]
    3300:      	ldp	x9, x8, [x8]
    3304:      	stp	x9, x8, [sp, #0x40]
    3308:      	mov	w8, #0x2e               // =46
    330c:      	mov	w9, #0x6                // =6
    3310:      	ldr	w2, [sp, #0x88]
    3314:      	blr	x9
    3318:      	ldr	w8, [sp, #0x10]
    331c:      	cbnz	w8, 0xf58 <kprobe_unwind_python+0xf58>
    3320:      	cbz	x29, 0x3400 <kprobe_unwind_python+0x3400>
    3324:      	ldr	x8, [sp, #0x28]
    3328:      	ldrb	w8, [x8, #0x19]
    332c:      	cmp	w8, #0x78
    3330:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    3334:      	ldr	x8, [sp, #0x28]
    3338:      	ldrb	w8, [x8, #0x18]
    333c:      	cmp	w8, #0x78
    3340:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    3344:      	ldr	x8, [sp, #0x28]
    3348:      	ldrb	w8, [x8, #0x1a]
    334c:      	cmp	w8, #0x78
    3350:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    3354:      	ldr	x8, [sp, #0x28]
    3358:      	ldrsb	w8, [x8, #0x1b]
    335c:      	tbnz	w8, #0x1f, 0x380c <kprobe_unwind_python+0x380c>
    3360:      	mov	w8, #0x80               // =128
    3364:      	mov	w9, #0x70               // =112
    3368:      	mov	x2, x29
    336c:      	mov	x0, x23
    3370:      	mov	w1, #0x80               // =128
    3374:      	blr	x9
    3378:      	cbnz	x0, 0xc38 <kprobe_unwind_python+0xc38>
    337c:      	ldr	x8, [sp, #0x28]
    3380:      	ldrb	w9, [x8, #0x19]
    3384:      	ldr	x9, [x23, x9]
    3388:      	str	x9, [sp, #0x8]
    338c:      	ldrb	w9, [x8, #0x18]
    3390:      	ldr	x8, [x8, #0x8]
    3394:      	ldr	x24, [x23, x9]
    3398:      	cbz	x8, 0x33a8 <kprobe_unwind_python+0x33a8>
    339c:      	ldr	x9, [sp, #0x8]
    33a0:      	cmp	x9, x8
    33a4:      	b.eq	0x36a8 <kprobe_unwind_python+0x36a8>
    33a8:      	ldr	x8, [sp, #0x28]
    33ac:      	ldrb	w9, [x8, #0x22]
    33b0:      	ldrb	w8, [x8, #0x1a]
    33b4:      	cbz	w9, 0x340c <kprobe_unwind_python+0x340c>
    33b8:      	ldr	x9, [sp, #0x28]
    33bc:      	ldr	x11, [sp, #0x8]
    33c0:      	ldr	x8, [x23, x8]
    33c4:      	ldrb	w10, [x9, #0x21]
    33c8:      	add	x10, x11, x10
    33cc:      	sub	x8, x8, x10
    33d0:      	mov	x10, #-0x10000001       // =-268435457
    33d4:      	add	x10, x8, x10
    33d8:      	asr	w8, w8, #1
    33dc:      	cmp	x10, x22
    33e0:      	csinv	w19, w8, wzr, hs
    33e4:      	ldrb	w8, [x9, #0x1b]
    33e8:      	ldrb	w9, [x9, #0x1c]
    33ec:      	ldrb	w8, [x23, x8]
    33f0:      	cmp	w8, w9
    33f4:      	cset	w8, eq
    33f8:      	str	w8, [sp, #0x10]
    33fc:      	b	0x3414 <kprobe_unwind_python+0x3414>
    3400:      	mov	w8, wzr
    3404:      	mov	w9, wzr
    3408:      	b	0x37a4 <kprobe_unwind_python+0x37a4>
    340c:      	ldr	w19, [x23, x8]
    3410:      	str	wzr, [sp, #0x10]
    3414:      	ldr	x8, [sp, #0x8]
    3418:      	cbz	x8, 0x3480 <kprobe_unwind_python+0x3480>
    341c:      	ldr	x8, [sp, #0x28]
    3420:      	ldrb	w8, [x8, #0x1d]
    3424:      	cmp	w8, #0xbc
    3428:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    342c:      	ldr	x8, [sp, #0x28]
    3430:      	ldrb	w8, [x8, #0x1e]
    3434:      	cmp	w8, #0xbc
    3438:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    343c:      	ldr	x8, [sp, #0x28]
    3440:      	ldrb	w8, [x8, #0x1f]
    3444:      	cmp	w8, #0xbc
    3448:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    344c:      	ldr	x8, [sp, #0x28]
    3450:      	ldrb	w8, [x8, #0x20]
    3454:      	cmp	w8, #0xbc
    3458:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    345c:      	ldr	x0, [sp, #0x18]
    3460:      	ldr	x2, [sp, #0x8]
    3464:      	mov	w8, #0xc0               // =192
    3468:      	mov	w9, #0x70               // =112
    346c:      	mov	w1, #0xc0               // =192
    3470:      	blr	x9
    3474:      	cbz	x0, 0x350c <kprobe_unwind_python+0x350c>
    3478:      	mov	x29, x24
    347c:      	b	0xa90 <kprobe_unwind_python+0xa90>
    3480:      	ldr	w8, [x25]
    3484:      	cbz	w8, 0x34d8 <kprobe_unwind_python+0x34d8>
    3488:      	adrp	x10, 0x3000 <kprobe_unwind_python+0x3000>
    348c:      	add	x10, x10, #0x0
    3490:      	add	x0, sp, #0x40
    3494:      	ldp	x8, x9, [x10, #0x10]
    3498:      	mov	w1, #0x2f               // =47
    349c:      	mov	x2, x29
    34a0:      	stp	x8, x9, [sp, #0x50]
    34a4:      	ldr	x8, [x10, #0x20]
    34a8:      	str	x8, [sp, #0x60]
    34ac:      	ldur	x8, [x10, #0x27]
    34b0:      	stur	x8, [sp, #0x67]
    34b4:      	ldp	x8, x9, [x10]
    34b8:      	add	x10, sp, #0x40
    34bc:      	stp	x8, x9, [sp, #0x40]
    34c0:      	mov	w8, #0x2f               // =47
    34c4:      	mov	w9, #0x6                // =6
    34c8:      	ldr	x8, [sp, #0x28]
    34cc:      	ldrb	w8, [x8, #0x19]
    34d0:      	add	x3, x29, x8
    34d4:      	blr	x9
    34d8:      	mov	w8, #0x1c               // =28
    34dc:      	adrp	x0, 0x3000 <kprobe_unwind_python+0x3000>
    34e0:      	add	x9, sp, #0x88
    34e4:      	str	w8, [sp, #0x88]
    34e8:      	mov	w8, #0x1                // =1
    34ec:      	add	x1, sp, #0x88
    34f0:      	ldr	x0, [x0]
    34f4:      	blr	x8
    34f8:      	cbz	x0, 0x354c <kprobe_unwind_python+0x354c>
    34fc:      	ldr	x8, [x0]
    3500:      	add	x8, x8, #0x1
    3504:      	str	x8, [x0]
    3508:      	b	0x3598 <kprobe_unwind_python+0x3598>
    350c:      	ldr	x8, [sp, #0x28]
    3510:      	ldr	x12, [sp, #0x18]
    3514:      	ldrb	w10, [x8, #0x1e]
    3518:      	ldrb	w9, [x8, #0x1d]
    351c:      	ldrb	w11, [x8, #0x1f]
    3520:      	ldrb	w8, [x8, #0x20]
    3524:      	ldr	w10, [x12, x10]
    3528:      	ldr	w9, [x12, x9]
    352c:      	ldr	w11, [x12, x11]
    3530:      	ldr	w8, [x12, x8]
    3534:      	lsl	w10, w10, #18
    3538:      	add	w9, w10, w9, lsl #25
    353c:      	add	w9, w9, w11, lsl #10
    3540:      	add	w8, w9, w8
    3544:      	orr	x29, x8, x19, lsl #32
    3548:      	b	0x35a0 <kprobe_unwind_python+0x35a0>
    354c:      	ldr	w8, [x25]
    3550:      	cbz	w8, 0x3598 <kprobe_unwind_python+0x3598>
    3554:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    3558:      	add	x8, x8, #0x0
    355c:      	add	x0, sp, #0x40
    3560:      	ldp	x9, x10, [x8, #0x10]
    3564:      	mov	w1, #0x2e               // =46
    3568:      	stp	x9, x10, [sp, #0x50]
    356c:      	ldr	x9, [x8, #0x20]
    3570:      	add	x10, sp, #0x40
    3574:      	str	x9, [sp, #0x60]
    3578:      	ldur	x9, [x8, #0x26]
    357c:      	stur	x9, [sp, #0x66]
    3580:      	ldp	x9, x8, [x8]
    3584:      	stp	x9, x8, [sp, #0x40]
    3588:      	mov	w8, #0x2e               // =46
    358c:      	mov	w9, #0x6                // =6
    3590:      	ldr	w2, [sp, #0x88]
    3594:      	blr	x9
    3598:      	mov	x29, #-0x2              // =-2
    359c:      	str	xzr, [sp, #0x8]
    35a0:      	ldr	w8, [x25]
    35a4:      	cbz	w8, 0x35e0 <kprobe_unwind_python+0x35e0>
    35a8:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    35ac:      	add	x8, x8, #0x0
    35b0:      	add	x0, sp, #0x40
    35b4:      	ldp	x9, x10, [x8]
    35b8:      	ldr	x8, [x8, #0x10]
    35bc:      	mov	w1, #0x18               // =24
    35c0:      	mov	x3, x29
    35c4:      	stp	x9, x10, [sp, #0x40]
    35c8:      	str	x8, [sp, #0x50]
    35cc:      	mov	w8, #0x18               // =24
    35d0:      	mov	w9, #0x6                // =6
    35d4:      	add	x10, sp, #0x40
    35d8:      	ldr	x2, [sp, #0x8]
    35dc:      	blr	x9
    35e0:      	ldr	w8, [x21, #0x2c0]
    35e4:      	cmp	w8, #0x7e
    35e8:      	b.ls	0x35f4 <kprobe_unwind_python+0x35f4>
    35ec:      	mov	x29, x24
    35f0:      	b	0x12c8 <kprobe_unwind_python+0x12c8>
    35f4:      	add	w9, w8, #0x1
    35f8:      	adrp	x0, 0x3000 <kprobe_unwind_python+0x3000>
    35fc:      	add	x1, sp, #0x88
    3600:      	str	w9, [x21, #0x2c0]
    3604:      	mov	w9, #0x18               // =24
    3608:      	umaddl	x8, w8, w9, x21
    360c:      	ldr	x9, [sp, #0x8]
    3610:      	str	x29, [x8, #0x2d8]
    3614:      	str	wzr, [x8, #0x2e4]
    3618:      	str	x9, [x8, #0x2d0]
    361c:      	mov	w9, #0x1                // =1
    3620:      	strb	w9, [x8, #0x2e0]
    3624:      	add	x8, x8, #0x2d0
    3628:      	stur	wzr, [x8, #0x11]
    362c:      	mov	w8, #0x16               // =22
    3630:      	str	w8, [sp, #0x88]
    3634:      	add	x8, sp, #0x88
    3638:      	ldr	x0, [x0]
    363c:      	blr	x9
    3640:      	cbz	x0, 0x3654 <kprobe_unwind_python+0x3654>
    3644:      	ldr	x8, [x0]
    3648:      	add	x8, x8, #0x1
    364c:      	str	x8, [x0]
    3650:      	b	0x36a0 <kprobe_unwind_python+0x36a0>
    3654:      	ldr	w8, [x25]
    3658:      	cbz	w8, 0x36a0 <kprobe_unwind_python+0x36a0>
    365c:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    3660:      	add	x8, x8, #0x0
    3664:      	add	x0, sp, #0x40
    3668:      	ldp	x9, x10, [x8, #0x10]
    366c:      	mov	w1, #0x2e               // =46
    3670:      	stp	x9, x10, [sp, #0x50]
    3674:      	ldr	x9, [x8, #0x20]
    3678:      	add	x10, sp, #0x40
    367c:      	str	x9, [sp, #0x60]
    3680:      	ldur	x9, [x8, #0x26]
    3684:      	stur	x9, [sp, #0x66]
    3688:      	ldp	x9, x8, [x8]
    368c:      	stp	x9, x8, [sp, #0x40]
    3690:      	mov	w8, #0x2e               // =46
    3694:      	mov	w9, #0x6                // =6
    3698:      	ldr	w2, [sp, #0x88]
    369c:      	blr	x9
    36a0:      	ldr	w8, [sp, #0x10]
    36a4:      	cbz	w8, 0x36b8 <kprobe_unwind_python+0x36b8>
    36a8:      	ldr	x22, [sp, #0x20]
    36ac:      	ldr	x19, [sp, #0x30]
    36b0:      	mov	x12, x24
    36b4:      	b	0x1ac <kprobe_unwind_python+0x1ac>
    36b8:      	cbz	x24, 0x37b0 <kprobe_unwind_python+0x37b0>
    36bc:      	ldr	x8, [sp, #0x28]
    36c0:      	ldrb	w8, [x8, #0x19]
    36c4:      	cmp	w8, #0x78
    36c8:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    36cc:      	ldr	x8, [sp, #0x28]
    36d0:      	ldrb	w8, [x8, #0x18]
    36d4:      	cmp	w8, #0x78
    36d8:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    36dc:      	ldr	x8, [sp, #0x28]
    36e0:      	ldrb	w8, [x8, #0x1a]
    36e4:      	cmp	w8, #0x78
    36e8:      	b.hi	0x3798 <kprobe_unwind_python+0x3798>
    36ec:      	ldr	x8, [sp, #0x28]
    36f0:      	ldrsb	w8, [x8, #0x1b]
    36f4:      	tbnz	w8, #0x1f, 0x3798 <kprobe_unwind_python+0x3798>
    36f8:      	mov	w8, #0x80               // =128
    36fc:      	mov	w9, #0x70               // =112
    3700:      	mov	x2, x24
    3704:      	mov	x0, x23
    3708:      	mov	w1, #0x80               // =128
    370c:      	blr	x9
    3710:      	cbnz	x0, 0xc34 <kprobe_unwind_python+0xc34>
    3714:      	ldr	x8, [sp, #0x28]
    3718:      	ldrb	w9, [x8, #0x19]
    371c:      	ldr	x9, [x23, x9]
    3720:      	str	x9, [sp, #0x8]
    3724:      	ldrb	w9, [x8, #0x18]
    3728:      	ldr	x8, [x8, #0x8]
    372c:      	ldr	x29, [x23, x9]
    3730:      	cbz	x8, 0x3740 <kprobe_unwind_python+0x3740>
    3734:      	ldr	x9, [sp, #0x8]
    3738:      	cmp	x9, x8
    373c:      	b.eq	0xf58 <kprobe_unwind_python+0xf58>
    3740:      	ldr	x8, [sp, #0x28]
    3744:      	ldrb	w9, [x8, #0x22]
    3748:      	ldrb	w8, [x8, #0x1a]
    374c:      	cbz	w9, 0x37bc <kprobe_unwind_python+0x37bc>
    3750:      	ldr	x9, [sp, #0x28]
    3754:      	ldr	x11, [sp, #0x8]
    3758:      	ldr	x8, [x23, x8]
    375c:      	ldrb	w10, [x9, #0x21]
    3760:      	add	x10, x11, x10
    3764:      	sub	x8, x8, x10
    3768:      	mov	x10, #-0x10000001       // =-268435457
    376c:      	add	x10, x8, x10
    3770:      	asr	w8, w8, #1
    3774:      	cmp	x10, x22
    3778:      	csinv	w22, w8, wzr, hs
    377c:      	ldrb	w8, [x9, #0x1b]
    3780:      	ldrb	w9, [x9, #0x1c]
    3784:      	ldrb	w8, [x23, x8]
    3788:      	cmp	w8, w9
    378c:      	cset	w8, eq
    3790:      	str	w8, [sp, #0x10]
    3794:      	b	0x37c4 <kprobe_unwind_python+0x37c4>
    3798:      	mov	w8, wzr
    379c:      	mov	w9, #0x1                // =1
    37a0:      	mov	x29, x24
    37a4:      	ldr	x22, [sp, #0x20]
    37a8:      	ldr	x19, [sp, #0x30]
    37ac:      	b	0x15c <kprobe_unwind_python+0x15c>
    37b0:      	mov	w8, wzr
    37b4:      	mov	x29, xzr
    37b8:      	b	0x3404 <kprobe_unwind_python+0x3404>
    37bc:      	ldr	w22, [x23, x8]
    37c0:      	str	wzr, [sp, #0x10]
    37c4:      	ldr	x8, [sp, #0x8]
    37c8:      	cbz	x8, 0x3818 <kprobe_unwind_python+0x3818>
    37cc:      	ldr	x8, [sp, #0x28]
    37d0:      	ldrb	w8, [x8, #0x1d]
    37d4:      	cmp	w8, #0xbc
    37d8:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    37dc:      	ldr	x8, [sp, #0x28]
    37e0:      	ldrb	w8, [x8, #0x1e]
    37e4:      	cmp	w8, #0xbc
    37e8:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    37ec:      	ldr	x8, [sp, #0x28]
    37f0:      	ldrb	w8, [x8, #0x1f]
    37f4:      	cmp	w8, #0xbc
    37f8:      	b.hi	0x380c <kprobe_unwind_python+0x380c>
    37fc:      	ldr	x8, [sp, #0x28]
    3800:      	ldrb	w8, [x8, #0x20]
    3804:      	cmp	w8, #0xbc
    3808:      	b.ls	0x38a4 <kprobe_unwind_python+0x38a4>
    380c:      	mov	w8, wzr
    3810:      	mov	w9, #0x1                // =1
    3814:      	b	0x37a4 <kprobe_unwind_python+0x37a4>
    3818:      	ldr	w8, [x25]
    381c:      	cbz	w8, 0x3870 <kprobe_unwind_python+0x3870>
    3820:      	adrp	x10, 0x3000 <kprobe_unwind_python+0x3000>
    3824:      	add	x10, x10, #0x0
    3828:      	add	x0, sp, #0x40
    382c:      	ldp	x8, x9, [x10, #0x10]
    3830:      	mov	w1, #0x2f               // =47
    3834:      	mov	x2, x24
    3838:      	stp	x8, x9, [sp, #0x50]
    383c:      	ldr	x8, [x10, #0x20]
    3840:      	str	x8, [sp, #0x60]
    3844:      	ldur	x8, [x10, #0x27]
    3848:      	stur	x8, [sp, #0x67]
    384c:      	ldp	x8, x9, [x10]
    3850:      	add	x10, sp, #0x40
    3854:      	stp	x8, x9, [sp, #0x40]
    3858:      	mov	w8, #0x2f               // =47
    385c:      	mov	w9, #0x6                // =6
    3860:      	ldr	x8, [sp, #0x28]
    3864:      	ldrb	w8, [x8, #0x19]
    3868:      	add	x3, x24, x8
    386c:      	blr	x9
    3870:      	mov	w8, #0x1c               // =28
    3874:      	adrp	x0, 0x3000 <kprobe_unwind_python+0x3000>
    3878:      	add	x9, sp, #0x88
    387c:      	str	w8, [sp, #0x88]
    3880:      	mov	w8, #0x1                // =1
    3884:      	add	x1, sp, #0x88
    3888:      	ldr	x0, [x0]
    388c:      	blr	x8
    3890:      	cbz	x0, 0x3900 <kprobe_unwind_python+0x3900>
    3894:      	ldr	x8, [x0]
    3898:      	add	x8, x8, #0x1
    389c:      	str	x8, [x0]
    38a0:      	b	0x394c <kprobe_unwind_python+0x394c>
    38a4:      	ldr	x0, [sp, #0x18]
    38a8:      	ldr	x2, [sp, #0x8]
    38ac:      	mov	w8, #0xc0               // =192
    38b0:      	mov	w9, #0x70               // =112
    38b4:      	mov	w1, #0xc0               // =192
    38b8:      	mov	x19, x0
    38bc:      	blr	x9
    38c0:      	cbnz	x0, 0xa90 <kprobe_unwind_python+0xa90>
    38c4:      	ldr	x8, [sp, #0x28]
    38c8:      	ldrb	w10, [x8, #0x1e]
    38cc:      	ldrb	w9, [x8, #0x1d]
    38d0:      	ldrb	w11, [x8, #0x1f]
    38d4:      	ldrb	w8, [x8, #0x20]
    38d8:      	ldr	w10, [x19, x10]
    38dc:      	ldr	w9, [x19, x9]
    38e0:      	ldr	w11, [x19, x11]
    38e4:      	ldr	w8, [x19, x8]
    38e8:      	lsl	w10, w10, #18
    38ec:      	add	w9, w10, w9, lsl #25
    38f0:      	add	w9, w9, w11, lsl #10
    38f4:      	add	w8, w9, w8
    38f8:      	orr	x23, x8, x22, lsl #32
    38fc:      	b	0x3954 <kprobe_unwind_python+0x3954>
    3900:      	ldr	w8, [x25]
    3904:      	cbz	w8, 0x394c <kprobe_unwind_python+0x394c>
    3908:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    390c:      	add	x8, x8, #0x0
    3910:      	add	x0, sp, #0x40
    3914:      	ldp	x9, x10, [x8, #0x10]
    3918:      	mov	w1, #0x2e               // =46
    391c:      	stp	x9, x10, [sp, #0x50]
    3920:      	ldr	x9, [x8, #0x20]
    3924:      	add	x10, sp, #0x40
    3928:      	str	x9, [sp, #0x60]
    392c:      	ldur	x9, [x8, #0x26]
    3930:      	stur	x9, [sp, #0x66]
    3934:      	ldp	x9, x8, [x8]
    3938:      	stp	x9, x8, [sp, #0x40]
    393c:      	mov	w8, #0x2e               // =46
    3940:      	mov	w9, #0x6                // =6
    3944:      	ldr	w2, [sp, #0x88]
    3948:      	blr	x9
    394c:      	mov	x23, #-0x2              // =-2
    3950:      	str	xzr, [sp, #0x8]
    3954:      	ldr	w8, [x25]
    3958:      	cbz	w8, 0x3994 <kprobe_unwind_python+0x3994>
    395c:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    3960:      	add	x8, x8, #0x0
    3964:      	add	x0, sp, #0x40
    3968:      	ldp	x9, x10, [x8]
    396c:      	ldr	x8, [x8, #0x10]
    3970:      	mov	w1, #0x18               // =24
    3974:      	mov	x3, x23
    3978:      	stp	x9, x10, [sp, #0x40]
    397c:      	str	x8, [sp, #0x50]
    3980:      	mov	w8, #0x18               // =24
    3984:      	mov	w9, #0x6                // =6
    3988:      	add	x10, sp, #0x40
    398c:      	ldr	x2, [sp, #0x8]
    3990:      	blr	x9
    3994:      	ldr	w8, [x21, #0x2c0]
    3998:      	cmp	w8, #0x7e
    399c:      	b.hi	0x12c8 <kprobe_unwind_python+0x12c8>
    39a0:      	add	w9, w8, #0x1
    39a4:      	adrp	x0, 0x3000 <kprobe_unwind_python+0x3000>
    39a8:      	add	x1, sp, #0x88
    39ac:      	str	w9, [x21, #0x2c0]
    39b0:      	mov	w9, #0x18               // =24
    39b4:      	umaddl	x8, w8, w9, x21
    39b8:      	ldr	x9, [sp, #0x8]
    39bc:      	str	x23, [x8, #0x2d8]
    39c0:      	str	wzr, [x8, #0x2e4]
    39c4:      	str	x9, [x8, #0x2d0]
    39c8:      	mov	w9, #0x1                // =1
    39cc:      	strb	w9, [x8, #0x2e0]
    39d0:      	add	x8, x8, #0x2d0
    39d4:      	stur	wzr, [x8, #0x11]
    39d8:      	mov	w8, #0x16               // =22
    39dc:      	str	w8, [sp, #0x88]
    39e0:      	add	x8, sp, #0x88
    39e4:      	ldr	x0, [x0]
    39e8:      	blr	x9
    39ec:      	cbz	x0, 0x3a00 <kprobe_unwind_python+0x3a00>
    39f0:      	ldr	x8, [x0]
    39f4:      	add	x8, x8, #0x1
    39f8:      	str	x8, [x0]
    39fc:      	b	0x3a4c <kprobe_unwind_python+0x3a4c>
    3a00:      	ldr	w8, [x25]
    3a04:      	cbz	w8, 0x3a4c <kprobe_unwind_python+0x3a4c>
    3a08:      	adrp	x8, 0x3000 <kprobe_unwind_python+0x3000>
    3a0c:      	add	x8, x8, #0x0
    3a10:      	add	x0, sp, #0x40
    3a14:      	ldp	x9, x10, [x8, #0x10]
    3a18:      	mov	w1, #0x2e               // =46
    3a1c:      	stp	x9, x10, [sp, #0x50]
    3a20:      	ldr	x9, [x8, #0x20]
    3a24:      	add	x10, sp, #0x40
    3a28:      	str	x9, [sp, #0x60]
    3a2c:      	ldur	x9, [x8, #0x26]
    3a30:      	stur	x9, [sp, #0x66]
    3a34:      	ldp	x9, x8, [x8]
    3a38:      	stp	x9, x8, [sp, #0x40]
    3a3c:      	mov	w8, #0x2e               // =46
    3a40:      	mov	w9, #0x6                // =6
    3a44:      	ldr	w2, [sp, #0x88]
    3a48:      	blr	x9
    3a4c:      	ldr	w8, [sp, #0x10]
    3a50:      	cbnz	w8, 0xf58 <kprobe_unwind_python+0xf58>
    3a54:      	cbz	x29, 0x3a68 <kprobe_unwind_python+0x3a68>
    3a58:      	ldr	x22, [sp, #0x20]
    3a5c:      	ldr	x19, [sp, #0x30]
    3a60:      	mov	w23, #0x4               // =4
    3a64:      	b	0x170 <kprobe_unwind_python+0x170>
    3a68:      	mov	w9, w8
    3a6c:      	b	0x37a4 <kprobe_unwind_python+0x37a4>
