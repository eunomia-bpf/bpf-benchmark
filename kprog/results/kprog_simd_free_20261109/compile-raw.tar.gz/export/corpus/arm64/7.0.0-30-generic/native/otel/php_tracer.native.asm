
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/php_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_php:

0000000000000000 <perf_unwind_php>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	str	wzr, [sp, #0x18]
      1c:      	adrp	x20, 0x0 <perf_unwind_php>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x18
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x18
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0xc5c <perf_unwind_php+0xc5c>
      40:      	ldr	w8, [x0]
      44:      	mov	x21, x0
      48:      	adrp	x0, 0x0 <perf_unwind_php>
      4c:      	add	x9, sp, #0x14
      50:      	str	w8, [sp, #0x14]
      54:      	mov	w8, #0x1                // =1
      58:      	add	x1, sp, #0x14
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	adrp	x29, 0x0 <perf_unwind_php>
      68:      	ldr	x29, [x29]
      6c:      	cbz	x0, 0x84 <perf_unwind_php+0x84>
      70:      	ldr	x8, [x21, #0xf00]
      74:      	mov	x24, x0
      78:      	cbz	x8, 0xd0 <perf_unwind_php+0xd0>
      7c:      	mov	w25, wzr
      80:      	b	0xdc <perf_unwind_php+0xdc>
      84:      	ldr	w8, [x29]
      88:      	cbz	w8, 0xb94 <perf_unwind_php+0xb94>
      8c:      	mov	w8, #0x6174             // =24948
      90:      	add	x0, sp, #0x18
      94:      	mov	w1, #0x1b               // =27
      98:      	movk	w8, #0xa, lsl #16
      9c:      	stur	w8, [sp, #0x2f]
      a0:      	adrp	x8, 0x0 <perf_unwind_php>
      a4:      	add	x8, x8, #0x0
      a8:      	ldp	x9, x10, [x8]
      ac:      	ldr	x8, [x8, #0x10]
      b0:      	stp	x9, x10, [sp, #0x18]
      b4:      	str	x8, [sp, #0x28]
      b8:      	mov	w8, #0x1b               // =27
      bc:      	mov	w9, #0x6                // =6
      c0:      	add	x10, sp, #0x18
      c4:      	blr	x9
      c8:      	mov	w23, #0x1               // =1
      cc:      	b	0xb98 <perf_unwind_php+0xb98>
      d0:      	ldr	x8, [x21, #0xf10]
      d4:      	cmp	x8, #0x0
      d8:      	cset	w25, eq
      dc:      	mov	w8, #0x22               // =34
      e0:      	adrp	x23, 0x0 <perf_unwind_php>
      e4:      	add	x9, sp, #0x70
      e8:      	str	w8, [sp, #0x70]
      ec:      	mov	w8, #0x1                // =1
      f0:      	add	x1, sp, #0x70
      f4:      	ldr	x23, [x23]
      f8:      	mov	x0, x23
      fc:      	blr	x8
     100:      	cbz	x0, 0x120 <perf_unwind_php+0x120>
     104:      	ldr	x8, [x0]
     108:      	add	x8, x8, #0x1
     10c:      	str	x8, [x0]
     110:      	ldr	x8, [x21, #0xf50]
     114:      	add	x22, x21, #0xf50
     118:      	cbnz	x8, 0x134 <perf_unwind_php+0x134>
     11c:      	b	0xb30 <perf_unwind_php+0xb30>
     120:      	ldr	w8, [x29]
     124:      	cbnz	w8, 0xae0 <perf_unwind_php+0xae0>
     128:      	ldr	x8, [x21, #0xf50]
     12c:      	add	x22, x21, #0xf50
     130:      	cbz	x8, 0xb30 <perf_unwind_php+0xb30>
     134:      	cbz	w25, 0x1a4 <perf_unwind_php+0x1a4>
     138:      	ldr	x8, [x21, #0xee0]
     13c:      	str	x8, [x21, #0xed8]
     140:      	ldr	w8, [x29]
     144:      	str	w25, [sp, #0x10]
     148:      	cbz	w8, 0x1b0 <perf_unwind_php+0x1b0>
     14c:      	mov	w8, #0x2978             // =10616
     150:      	add	x0, sp, #0x18
     154:      	mov	w1, #0x2b               // =43
     158:      	movk	w8, #0xa, lsl #16
     15c:      	stur	w8, [sp, #0x3f]
     160:      	adrp	x8, 0x0 <perf_unwind_php>
     164:      	add	x8, x8, #0x0
     168:      	ldp	x9, x10, [x8, #0x10]
     16c:      	stp	x9, x10, [sp, #0x28]
     170:      	ldr	x9, [x8, #0x20]
     174:      	add	x10, sp, #0x18
     178:      	str	x9, [sp, #0x38]
     17c:      	ldp	x8, x9, [x8]
     180:      	stp	x8, x9, [sp, #0x18]
     184:      	mov	w8, #0x2b               // =43
     188:      	mov	w9, #0x6                // =6
     18c:      	ldr	x2, [x22]
     190:      	blr	x9
     194:      	ldr	x25, [x22]
     198:      	str	x25, [sp, #0x60]
     19c:      	cbnz	x25, 0x1bc <perf_unwind_php+0x1bc>
     1a0:      	b	0xb94 <perf_unwind_php+0xb94>
     1a4:      	ldr	w8, [x29]
     1a8:      	str	w25, [sp, #0x10]
     1ac:      	cbnz	w8, 0x14c <perf_unwind_php+0x14c>
     1b0:      	ldr	x25, [x22]
     1b4:      	str	x25, [sp, #0x60]
     1b8:      	cbz	x25, 0xb94 <perf_unwind_php+0xb94>
     1bc:      	ldr	w8, [sp, #0x10]
     1c0:      	mov	w9, #0x9                // =9
     1c4:      	str	wzr, [sp, #0x5c]
     1c8:      	mov	w10, #0x70              // =112
     1cc:      	add	x11, sp, #0x70
     1d0:      	add	x0, sp, #0x70
     1d4:      	mov	w1, #0x8                // =8
     1d8:      	cmp	w8, #0x0
     1dc:      	mov	w8, #0x2                // =2
     1e0:      	csel	w8, w9, w8, ne
     1e4:      	mov	w9, #0x8                // =8
     1e8:      	str	w8, [sp, #0xc]
     1ec:      	ldrb	w8, [x24, #0x10]
     1f0:      	add	x8, x25, x8
     1f4:      	ldrb	w8, [x24, #0x10]
     1f8:      	add	x2, x25, x8
     1fc:      	blr	x10
     200:      	cbz	x0, 0x244 <perf_unwind_php+0x244>
     204:      	ldr	w8, [x29]
     208:      	cbnz	w8, 0xc7c <perf_unwind_php+0xc7c>
     20c:      	mov	w25, #0x25              // =37
     210:      	str	w25, [sp, #0x70]
     214:      	mov	w8, #0x1                // =1
     218:      	add	x9, sp, #0x70
     21c:      	add	x1, sp, #0x70
     220:      	mov	x0, x23
     224:      	blr	x8
     228:      	cbz	x0, 0x28c <perf_unwind_php+0x28c>
     22c:      	ldr	x8, [x0]
     230:      	add	x8, x8, #0x1
     234:      	str	x8, [x0]
     238:      	cmp	w25, #0x23
     23c:      	b.eq	0x29c <perf_unwind_php+0x29c>
     240:      	b	0x414 <perf_unwind_php+0x414>
     244:      	ldr	x8, [sp, #0x70]
     248:      	cbz	x8, 0x388 <perf_unwind_php+0x388>
     24c:      	ldrb	w9, [x24, #0x14]
     250:      	mov	w10, #0x70              // =112
     254:      	add	x11, sp, #0x8c
     258:      	add	x0, sp, #0x8c
     25c:      	mov	w1, #0x1                // =1
     260:      	add	x8, x8, x9
     264:      	mov	w9, #0x1                // =1
     268:      	ldr	x8, [sp, #0x70]
     26c:      	ldrb	w9, [x24, #0x14]
     270:      	add	x2, x8, x9
     274:      	blr	x10
     278:      	cbz	x0, 0x430 <perf_unwind_php+0x430>
     27c:      	ldr	w8, [x29]
     280:      	cbnz	w8, 0xf10 <perf_unwind_php+0xf10>
     284:      	mov	w25, #0x26              // =38
     288:      	b	0x210 <perf_unwind_php+0x210>
     28c:      	ldr	w8, [x29]
     290:      	cbnz	w8, 0xdcc <perf_unwind_php+0xdcc>
     294:      	cmp	w25, #0x23
     298:      	b.ne	0x414 <perf_unwind_php+0x414>
     29c:      	ldr	x8, [sp, #0x60]
     2a0:      	ldrb	w9, [x24, #0x12]
     2a4:      	mov	w10, #0x70              // =112
     2a8:      	add	x11, sp, #0x60
     2ac:      	add	x0, sp, #0x60
     2b0:      	mov	w1, #0x8                // =8
     2b4:      	add	x8, x8, x9
     2b8:      	mov	w9, #0x8                // =8
     2bc:      	ldr	x8, [sp, #0x60]
     2c0:      	ldrb	w9, [x24, #0x12]
     2c4:      	add	x2, x8, x9
     2c8:      	blr	x10
     2cc:      	cbz	x0, 0x30c <perf_unwind_php+0x30c>
     2d0:      	ldr	w8, [x29]
     2d4:      	cbnz	w8, 0xe80 <perf_unwind_php+0xe80>
     2d8:      	mov	w8, #0x25               // =37
     2dc:      	add	x9, sp, #0x70
     2e0:      	add	x1, sp, #0x70
     2e4:      	str	w8, [sp, #0x70]
     2e8:      	mov	w8, #0x1                // =1
     2ec:      	mov	x0, x23
     2f0:      	blr	x8
     2f4:      	cbz	x0, 0x40c <perf_unwind_php+0x40c>
     2f8:      	ldr	x8, [x0]
     2fc:      	mov	w23, #0x5               // =5
     300:      	add	x8, x8, #0x1
     304:      	str	x8, [x0]
     308:      	b	0x418 <perf_unwind_php+0x418>
     30c:      	ldr	x25, [sp, #0x60]
     310:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
     314:      	ldrb	w8, [sp, #0x5e]
     318:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
     31c:      	ldrb	w8, [x24, #0x10]
     320:      	mov	w9, #0x8                // =8
     324:      	mov	w10, #0x70              // =112
     328:      	add	x11, sp, #0x70
     32c:      	add	x0, sp, #0x70
     330:      	mov	w1, #0x8                // =8
     334:      	add	x8, x25, x8
     338:      	ldrb	w8, [x24, #0x10]
     33c:      	add	x2, x25, x8
     340:      	blr	x10
     344:      	cbz	x0, 0x5b0 <perf_unwind_php+0x5b0>
     348:      	ldr	w8, [x29]
     34c:      	cbnz	w8, 0x1220 <perf_unwind_php+0x1220>
     350:      	mov	w25, #0x25              // =37
     354:      	str	w25, [sp, #0x70]
     358:      	mov	w8, #0x1                // =1
     35c:      	add	x9, sp, #0x70
     360:      	add	x1, sp, #0x70
     364:      	mov	x0, x23
     368:      	blr	x8
     36c:      	cbz	x0, 0x5f8 <perf_unwind_php+0x5f8>
     370:      	ldr	x8, [x0]
     374:      	add	x8, x8, #0x1
     378:      	str	x8, [x0]
     37c:      	cmp	w25, #0x23
     380:      	b.eq	0x608 <perf_unwind_php+0x608>
     384:      	b	0x414 <perf_unwind_php+0x414>
     388:      	ldr	w8, [x21, #0x2c0]
     38c:      	cmp	w8, #0x7f
     390:      	b.lo	0x4d4 <perf_unwind_php+0x4d4>
     394:      	ldr	w8, [x29]
     398:      	cbnz	w8, 0x1118 <perf_unwind_php+0x1118>
     39c:      	mov	w8, #0x2                // =2
     3a0:      	add	x9, sp, #0x68
     3a4:      	add	x1, sp, #0x68
     3a8:      	str	w8, [sp, #0x68]
     3ac:      	mov	w8, #0x1                // =1
     3b0:      	mov	x0, x23
     3b4:      	blr	x8
     3b8:      	cbz	x0, 0x50c <perf_unwind_php+0x50c>
     3bc:      	ldr	x8, [x0]
     3c0:      	add	x8, x8, #0x1
     3c4:      	str	x8, [x0]
     3c8:      	ldr	w8, [x29]
     3cc:      	cbz	w8, 0x414 <perf_unwind_php+0x414>
     3d0:      	mov	w8, #0xa                // =10
     3d4:      	add	x0, sp, #0x18
     3d8:      	mov	w1, #0x22               // =34
     3dc:      	strh	w8, [sp, #0x38]
     3e0:      	adrp	x8, 0x0 <perf_unwind_php>
     3e4:      	add	x8, x8, #0x0
     3e8:      	ldp	x9, x10, [x8]
     3ec:      	stp	x9, x10, [sp, #0x18]
     3f0:      	ldp	x9, x8, [x8, #0x10]
     3f4:      	add	x10, sp, #0x18
     3f8:      	stp	x9, x8, [sp, #0x28]
     3fc:      	mov	w8, #0x22               // =34
     400:      	mov	w9, #0x6                // =6
     404:      	blr	x9
     408:      	b	0x414 <perf_unwind_php+0x414>
     40c:      	ldr	w8, [x29]
     410:      	cbnz	w8, 0xff8 <perf_unwind_php+0xff8>
     414:      	mov	w23, #0x5               // =5
     418:      	ldr	w8, [x21, #0x1370]
     41c:      	orr	w8, w8, #0x20
     420:      	str	w8, [x21, #0x1370]
     424:      	ldr	x8, [sp, #0x60]
     428:      	str	x8, [x22]
     42c:      	b	0xb98 <perf_unwind_php+0xb98>
     430:      	ldrb	w8, [sp, #0x8c]
     434:      	str	wzr, [sp, #0x88]
     438:      	cmp	w8, #0x4
     43c:      	b.eq	0x44c <perf_unwind_php+0x44c>
     440:      	mov	w29, wzr
     444:      	cmp	w8, #0x2
     448:      	b.ne	0x80c <perf_unwind_php+0x80c>
     44c:      	ldrb	w8, [x24, #0x11]
     450:      	mov	w9, #0x8                // =8
     454:      	mov	w10, #0x70              // =112
     458:      	add	x11, sp, #0x68
     45c:      	add	x0, sp, #0x68
     460:      	mov	w1, #0x8                // =8
     464:      	add	x8, x25, x8
     468:      	ldrb	w8, [x24, #0x11]
     46c:      	add	x2, x25, x8
     470:      	blr	x10
     474:      	cbz	x0, 0x564 <perf_unwind_php+0x564>
     478:      	adrp	x29, 0x0 <perf_unwind_php>
     47c:      	ldr	x29, [x29]
     480:      	ldr	w8, [x29]
     484:      	cbz	w8, 0x20c <perf_unwind_php+0x20c>
     488:      	adrp	x8, 0x0 <perf_unwind_php>
     48c:      	add	x8, x8, #0x0
     490:      	add	x0, sp, #0x18
     494:      	ldp	x9, x10, [x8, #0x10]
     498:      	mov	w1, #0x2d               // =45
     49c:      	stp	x9, x10, [sp, #0x28]
     4a0:      	ldr	x9, [x8, #0x20]
     4a4:      	add	x10, sp, #0x18
     4a8:      	str	x9, [sp, #0x38]
     4ac:      	ldur	x9, [x8, #0x25]
     4b0:      	stur	x9, [sp, #0x3d]
     4b4:      	ldp	x9, x8, [x8]
     4b8:      	stp	x9, x8, [sp, #0x18]
     4bc:      	mov	w8, #0x2d               // =45
     4c0:      	mov	w9, #0x6                // =6
     4c4:      	ldrb	w8, [x24, #0x11]
     4c8:      	add	x2, x25, x8
     4cc:      	blr	x9
     4d0:      	b	0x20c <perf_unwind_php+0x20c>
     4d4:      	add	w9, w8, #0x1
     4d8:      	mov	x10, #-0x2              // =-2
     4dc:      	mov	w25, #0x23              // =35
     4e0:      	str	w9, [x21, #0x2c0]
     4e4:      	mov	w9, #0x18               // =24
     4e8:      	umaddl	x8, w8, w9, x21
     4ec:      	add	x9, x8, #0x2d0
     4f0:      	str	x10, [x8, #0x2d8]
     4f4:      	mov	w10, #0x2               // =2
     4f8:      	str	xzr, [x8, #0x2d0]
     4fc:      	str	wzr, [x8, #0x2e4]
     500:      	strb	w10, [x8, #0x2e0]
     504:      	stur	wzr, [x9, #0x11]
     508:      	b	0x210 <perf_unwind_php+0x210>
     50c:      	ldr	w8, [x29]
     510:      	cbz	w8, 0x414 <perf_unwind_php+0x414>
     514:      	adrp	x8, 0x0 <perf_unwind_php>
     518:      	add	x8, x8, #0x0
     51c:      	add	x0, sp, #0x18
     520:      	ldp	x9, x10, [x8, #0x10]
     524:      	mov	w1, #0x2e               // =46
     528:      	stp	x9, x10, [sp, #0x28]
     52c:      	ldr	x9, [x8, #0x20]
     530:      	add	x10, sp, #0x18
     534:      	str	x9, [sp, #0x38]
     538:      	ldur	x9, [x8, #0x26]
     53c:      	stur	x9, [sp, #0x3e]
     540:      	ldp	x9, x8, [x8]
     544:      	stp	x9, x8, [sp, #0x18]
     548:      	mov	w8, #0x2e               // =46
     54c:      	mov	w9, #0x6                // =6
     550:      	ldr	w2, [sp, #0x68]
     554:      	blr	x9
     558:      	ldr	w8, [x29]
     55c:      	cbz	w8, 0x414 <perf_unwind_php+0x414>
     560:      	b	0x3d0 <perf_unwind_php+0x3d0>
     564:      	ldr	x8, [sp, #0x68]
     568:      	ldrb	w9, [x24, #0x15]
     56c:      	mov	w10, #0x70              // =112
     570:      	add	x11, sp, #0x88
     574:      	add	x0, sp, #0x88
     578:      	mov	w1, #0x4                // =4
     57c:      	add	x8, x8, x9
     580:      	mov	w9, #0x4                // =4
     584:      	ldr	x8, [sp, #0x68]
     588:      	ldrb	w9, [x24, #0x15]
     58c:      	add	x2, x8, x9
     590:      	blr	x10
     594:      	adrp	x29, 0x0 <perf_unwind_php>
     598:      	ldr	x29, [x29]
     59c:      	cbz	x0, 0x6b8 <perf_unwind_php+0x6b8>
     5a0:      	ldr	w8, [x29]
     5a4:      	cbnz	w8, 0x1498 <perf_unwind_php+0x1498>
     5a8:      	mov	w25, #0x27              // =39
     5ac:      	b	0x210 <perf_unwind_php+0x210>
     5b0:      	ldr	x8, [sp, #0x70]
     5b4:      	cbz	x8, 0x730 <perf_unwind_php+0x730>
     5b8:      	ldrb	w9, [x24, #0x14]
     5bc:      	mov	w10, #0x70              // =112
     5c0:      	add	x11, sp, #0x8c
     5c4:      	add	x0, sp, #0x8c
     5c8:      	mov	w1, #0x1                // =1
     5cc:      	add	x8, x8, x9
     5d0:      	mov	w9, #0x1                // =1
     5d4:      	ldr	x8, [sp, #0x70]
     5d8:      	ldrb	w9, [x24, #0x14]
     5dc:      	add	x2, x8, x9
     5e0:      	blr	x10
     5e4:      	cbz	x0, 0x774 <perf_unwind_php+0x774>
     5e8:      	ldr	w8, [x29]
     5ec:      	cbnz	w8, 0x14f0 <perf_unwind_php+0x14f0>
     5f0:      	mov	w25, #0x26              // =38
     5f4:      	b	0x354 <perf_unwind_php+0x354>
     5f8:      	ldr	w8, [x29]
     5fc:      	cbnz	w8, 0x13a0 <perf_unwind_php+0x13a0>
     600:      	cmp	w25, #0x23
     604:      	b.ne	0x414 <perf_unwind_php+0x414>
     608:      	ldr	x8, [sp, #0x60]
     60c:      	ldrb	w9, [x24, #0x12]
     610:      	mov	w10, #0x70              // =112
     614:      	add	x11, sp, #0x60
     618:      	add	x0, sp, #0x60
     61c:      	mov	w1, #0x8                // =8
     620:      	add	x8, x8, x9
     624:      	mov	w9, #0x8                // =8
     628:      	ldr	x8, [sp, #0x60]
     62c:      	ldrb	w9, [x24, #0x12]
     630:      	add	x2, x8, x9
     634:      	blr	x10
     638:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
     63c:      	ldr	x25, [sp, #0x60]
     640:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
     644:      	ldrb	w8, [sp, #0x5e]
     648:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
     64c:      	ldrb	w8, [x24, #0x10]
     650:      	mov	w9, #0x8                // =8
     654:      	mov	w10, #0x70              // =112
     658:      	add	x11, sp, #0x70
     65c:      	add	x0, sp, #0x70
     660:      	mov	w1, #0x8                // =8
     664:      	add	x8, x25, x8
     668:      	ldrb	w8, [x24, #0x10]
     66c:      	add	x2, x25, x8
     670:      	blr	x10
     674:      	cbz	x0, 0x948 <perf_unwind_php+0x948>
     678:      	ldr	w8, [x29]
     67c:      	cbnz	w8, 0x1774 <perf_unwind_php+0x1774>
     680:      	mov	w25, #0x25              // =37
     684:      	str	w25, [sp, #0x70]
     688:      	mov	w8, #0x1                // =1
     68c:      	add	x9, sp, #0x70
     690:      	add	x1, sp, #0x70
     694:      	mov	x0, x23
     698:      	blr	x8
     69c:      	cbz	x0, 0x990 <perf_unwind_php+0x990>
     6a0:      	ldr	x8, [x0]
     6a4:      	add	x8, x8, #0x1
     6a8:      	str	x8, [x0]
     6ac:      	cmp	w25, #0x23
     6b0:      	b.eq	0x9a0 <perf_unwind_php+0x9a0>
     6b4:      	b	0x414 <perf_unwind_php+0x414>
     6b8:      	ldrb	w8, [x24, #0x13]
     6bc:      	mov	w9, #0x4                // =4
     6c0:      	mov	w10, #0x70              // =112
     6c4:      	add	x11, sp, #0x5c
     6c8:      	add	x0, sp, #0x5c
     6cc:      	mov	w1, #0x4                // =4
     6d0:      	add	x8, x25, x8
     6d4:      	ldrb	w8, [x24, #0x13]
     6d8:      	add	x2, x25, x8
     6dc:      	blr	x10
     6e0:      	cbz	x0, 0x808 <perf_unwind_php+0x808>
     6e4:      	ldr	w8, [x29]
     6e8:      	cbz	w8, 0x20c <perf_unwind_php+0x20c>
     6ec:      	adrp	x8, 0x0 <perf_unwind_php>
     6f0:      	add	x8, x8, #0x0
     6f4:      	add	x0, sp, #0x18
     6f8:      	ldp	x9, x10, [x8, #0x20]
     6fc:      	mov	w1, #0x35               // =53
     700:      	mov	x2, x25
     704:      	stp	x9, x10, [sp, #0x38]
     708:      	ldur	x9, [x8, #0x2d]
     70c:      	stur	x9, [sp, #0x45]
     710:      	ldp	x9, x10, [x8]
     714:      	stp	x9, x10, [sp, #0x18]
     718:      	ldp	x8, x9, [x8, #0x10]
     71c:      	add	x10, sp, #0x18
     720:      	stp	x8, x9, [sp, #0x28]
     724:      	mov	w8, #0x35               // =53
     728:      	mov	w9, #0x6                // =6
     72c:      	b	0x4cc <perf_unwind_php+0x4cc>
     730:      	ldr	w8, [x21, #0x2c0]
     734:      	cmp	w8, #0x7e
     738:      	b.hi	0x394 <perf_unwind_php+0x394>
     73c:      	add	w9, w8, #0x1
     740:      	mov	x10, #-0x2              // =-2
     744:      	mov	w25, #0x23              // =35
     748:      	str	w9, [x21, #0x2c0]
     74c:      	mov	w9, #0x18               // =24
     750:      	umaddl	x8, w8, w9, x21
     754:      	add	x9, x8, #0x2d0
     758:      	str	x10, [x8, #0x2d8]
     75c:      	mov	w10, #0x2               // =2
     760:      	str	xzr, [x8, #0x2d0]
     764:      	str	wzr, [x8, #0x2e4]
     768:      	strb	w10, [x8, #0x2e0]
     76c:      	stur	wzr, [x9, #0x11]
     770:      	b	0x354 <perf_unwind_php+0x354>
     774:      	ldrb	w8, [sp, #0x8c]
     778:      	str	wzr, [sp, #0x88]
     77c:      	cmp	w8, #0x4
     780:      	b.eq	0x790 <perf_unwind_php+0x790>
     784:      	mov	w10, wzr
     788:      	cmp	w8, #0x2
     78c:      	b.ne	0xe20 <perf_unwind_php+0xe20>
     790:      	ldrb	w8, [x24, #0x11]
     794:      	mov	w9, #0x8                // =8
     798:      	mov	w10, #0x70              // =112
     79c:      	add	x11, sp, #0x68
     7a0:      	add	x0, sp, #0x68
     7a4:      	mov	w1, #0x8                // =8
     7a8:      	add	x8, x25, x8
     7ac:      	ldrb	w8, [x24, #0x11]
     7b0:      	add	x2, x25, x8
     7b4:      	blr	x10
     7b8:      	cbz	x0, 0x904 <perf_unwind_php+0x904>
     7bc:      	ldr	w8, [x29]
     7c0:      	cbz	w8, 0x350 <perf_unwind_php+0x350>
     7c4:      	adrp	x8, 0x0 <perf_unwind_php>
     7c8:      	add	x8, x8, #0x0
     7cc:      	add	x0, sp, #0x18
     7d0:      	ldp	x9, x10, [x8, #0x10]
     7d4:      	mov	w1, #0x2d               // =45
     7d8:      	stp	x9, x10, [sp, #0x28]
     7dc:      	ldr	x9, [x8, #0x20]
     7e0:      	add	x10, sp, #0x18
     7e4:      	str	x9, [sp, #0x38]
     7e8:      	ldur	x9, [x8, #0x25]
     7ec:      	stur	x9, [sp, #0x3d]
     7f0:      	ldp	x9, x8, [x8]
     7f4:      	stp	x9, x8, [sp, #0x18]
     7f8:      	mov	w8, #0x2d               // =45
     7fc:      	mov	w9, #0x6                // =6
     800:      	ldrb	w8, [x24, #0x11]
     804:      	b	0x1264 <perf_unwind_php+0x1264>
     808:      	ldr	w29, [sp, #0x88]
     80c:      	adrp	x8, 0x0 <perf_unwind_php>
     810:      	ldr	w25, [sp, #0x5c]
     814:      	ldr	x8, [x8]
     818:      	ldr	w8, [x8]
     81c:      	cbnz	w8, 0x1270 <perf_unwind_php+0x1270>
     820:      	ldr	w8, [x21, #0x2c0]
     824:      	cmp	w8, #0x7f
     828:      	b.lo	0x12b4 <perf_unwind_php+0x12b4>
     82c:      	adrp	x29, 0x0 <perf_unwind_php>
     830:      	ldr	x29, [x29]
     834:      	ldr	w8, [x29]
     838:      	cbnz	w8, 0x145c <perf_unwind_php+0x145c>
     83c:      	mov	w8, #0x2                // =2
     840:      	add	x9, sp, #0x68
     844:      	add	x1, sp, #0x68
     848:      	str	w8, [sp, #0x68]
     84c:      	mov	w8, #0x1                // =1
     850:      	mov	x0, x23
     854:      	blr	x8
     858:      	cbz	x0, 0x8ac <perf_unwind_php+0x8ac>
     85c:      	ldr	x8, [x0]
     860:      	add	x8, x8, #0x1
     864:      	str	x8, [x0]
     868:      	ldr	w8, [x29]
     86c:      	cbz	w8, 0x414 <perf_unwind_php+0x414>
     870:      	mov	w8, #0xa                // =10
     874:      	add	x0, sp, #0x18
     878:      	mov	w1, #0x1a               // =26
     87c:      	strh	w8, [sp, #0x30]
     880:      	adrp	x8, 0x0 <perf_unwind_php>
     884:      	add	x8, x8, #0x0
     888:      	ldp	x9, x10, [x8]
     88c:      	ldr	x8, [x8, #0x10]
     890:      	stp	x9, x10, [sp, #0x18]
     894:      	str	x8, [sp, #0x28]
     898:      	mov	w8, #0x1a               // =26
     89c:      	mov	w9, #0x6                // =6
     8a0:      	add	x10, sp, #0x18
     8a4:      	blr	x9
     8a8:      	b	0x414 <perf_unwind_php+0x414>
     8ac:      	ldr	w8, [x29]
     8b0:      	cbz	w8, 0x414 <perf_unwind_php+0x414>
     8b4:      	adrp	x8, 0x0 <perf_unwind_php>
     8b8:      	add	x8, x8, #0x0
     8bc:      	add	x0, sp, #0x18
     8c0:      	ldp	x9, x10, [x8, #0x10]
     8c4:      	mov	w1, #0x2e               // =46
     8c8:      	stp	x9, x10, [sp, #0x28]
     8cc:      	ldr	x9, [x8, #0x20]
     8d0:      	add	x10, sp, #0x18
     8d4:      	str	x9, [sp, #0x38]
     8d8:      	ldur	x9, [x8, #0x26]
     8dc:      	stur	x9, [sp, #0x3e]
     8e0:      	ldp	x9, x8, [x8]
     8e4:      	stp	x9, x8, [sp, #0x18]
     8e8:      	mov	w8, #0x2e               // =46
     8ec:      	mov	w9, #0x6                // =6
     8f0:      	ldr	w2, [sp, #0x68]
     8f4:      	blr	x9
     8f8:      	ldr	w8, [x29]
     8fc:      	cbz	w8, 0x414 <perf_unwind_php+0x414>
     900:      	b	0x870 <perf_unwind_php+0x870>
     904:      	ldr	x8, [sp, #0x68]
     908:      	ldrb	w9, [x24, #0x15]
     90c:      	mov	w10, #0x70              // =112
     910:      	add	x11, sp, #0x88
     914:      	add	x0, sp, #0x88
     918:      	mov	w1, #0x4                // =4
     91c:      	add	x8, x8, x9
     920:      	mov	w9, #0x4                // =4
     924:      	ldr	x8, [sp, #0x68]
     928:      	ldrb	w9, [x24, #0x15]
     92c:      	add	x2, x8, x9
     930:      	blr	x10
     934:      	cbz	x0, 0xa58 <perf_unwind_php+0xa58>
     938:      	ldr	w8, [x29]
     93c:      	cbnz	w8, 0x1960 <perf_unwind_php+0x1960>
     940:      	mov	w25, #0x27              // =39
     944:      	b	0x354 <perf_unwind_php+0x354>
     948:      	ldr	x8, [sp, #0x70]
     94c:      	cbz	x8, 0xa9c <perf_unwind_php+0xa9c>
     950:      	ldrb	w9, [x24, #0x14]
     954:      	mov	w10, #0x70              // =112
     958:      	add	x11, sp, #0x8c
     95c:      	add	x0, sp, #0x8c
     960:      	mov	w1, #0x1                // =1
     964:      	add	x8, x8, x9
     968:      	mov	w9, #0x1                // =1
     96c:      	ldr	x8, [sp, #0x70]
     970:      	ldrb	w9, [x24, #0x14]
     974:      	add	x2, x8, x9
     978:      	blr	x10
     97c:      	cbz	x0, 0xccc <perf_unwind_php+0xccc>
     980:      	ldr	w8, [x29]
     984:      	cbnz	w8, 0x19b8 <perf_unwind_php+0x19b8>
     988:      	mov	w25, #0x26              // =38
     98c:      	b	0x684 <perf_unwind_php+0x684>
     990:      	ldr	w8, [x29]
     994:      	cbnz	w8, 0x18b8 <perf_unwind_php+0x18b8>
     998:      	cmp	w25, #0x23
     99c:      	b.ne	0x414 <perf_unwind_php+0x414>
     9a0:      	ldr	x8, [sp, #0x60]
     9a4:      	ldrb	w9, [x24, #0x12]
     9a8:      	mov	w10, #0x70              // =112
     9ac:      	add	x11, sp, #0x60
     9b0:      	add	x0, sp, #0x60
     9b4:      	mov	w1, #0x8                // =8
     9b8:      	add	x8, x8, x9
     9bc:      	mov	w9, #0x8                // =8
     9c0:      	ldr	x8, [sp, #0x60]
     9c4:      	ldrb	w9, [x24, #0x12]
     9c8:      	add	x2, x8, x9
     9cc:      	blr	x10
     9d0:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
     9d4:      	ldr	x25, [sp, #0x60]
     9d8:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
     9dc:      	ldrb	w8, [sp, #0x5e]
     9e0:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
     9e4:      	ldrb	w8, [x24, #0x10]
     9e8:      	mov	w9, #0x8                // =8
     9ec:      	mov	w10, #0x70              // =112
     9f0:      	add	x11, sp, #0x70
     9f4:      	add	x0, sp, #0x70
     9f8:      	mov	w1, #0x8                // =8
     9fc:      	add	x8, x25, x8
     a00:      	ldrb	w8, [x24, #0x10]
     a04:      	add	x2, x25, x8
     a08:      	blr	x10
     a0c:      	cbz	x0, 0xfa8 <perf_unwind_php+0xfa8>
     a10:      	adrp	x8, 0x0 <perf_unwind_php>
     a14:      	ldr	x8, [x8]
     a18:      	ldr	w8, [x8]
     a1c:      	cbnz	w8, 0x1cd0 <perf_unwind_php+0x1cd0>
     a20:      	mov	w25, #0x25              // =37
     a24:      	str	w25, [sp, #0x70]
     a28:      	mov	w8, #0x1                // =1
     a2c:      	add	x9, sp, #0x70
     a30:      	add	x1, sp, #0x70
     a34:      	mov	x0, x23
     a38:      	blr	x8
     a3c:      	cbz	x0, 0x1040 <perf_unwind_php+0x1040>
     a40:      	ldr	x8, [x0]
     a44:      	add	x8, x8, #0x1
     a48:      	str	x8, [x0]
     a4c:      	cmp	w25, #0x23
     a50:      	b.eq	0x1058 <perf_unwind_php+0x1058>
     a54:      	b	0x61f4 <perf_unwind_php+0x61f4>
     a58:      	ldrb	w8, [x24, #0x13]
     a5c:      	mov	w9, #0x4                // =4
     a60:      	mov	w10, #0x70              // =112
     a64:      	add	x11, sp, #0x5c
     a68:      	add	x0, sp, #0x5c
     a6c:      	mov	w1, #0x4                // =4
     a70:      	add	x8, x25, x8
     a74:      	ldrb	w8, [x24, #0x13]
     a78:      	add	x2, x25, x8
     a7c:      	blr	x10
     a80:      	cbz	x0, 0xe1c <perf_unwind_php+0xe1c>
     a84:      	ldr	w8, [x29]
     a88:      	cbnz	w8, 0x1b70 <perf_unwind_php+0x1b70>
     a8c:      	adrp	x29, 0x0 <perf_unwind_php>
     a90:      	mov	w25, #0x25              // =37
     a94:      	ldr	x29, [x29]
     a98:      	b	0x354 <perf_unwind_php+0x354>
     a9c:      	ldr	w8, [x21, #0x2c0]
     aa0:      	cmp	w8, #0x7e
     aa4:      	b.hi	0x394 <perf_unwind_php+0x394>
     aa8:      	add	w9, w8, #0x1
     aac:      	mov	x10, #-0x2              // =-2
     ab0:      	mov	w25, #0x23              // =35
     ab4:      	str	w9, [x21, #0x2c0]
     ab8:      	mov	w9, #0x18               // =24
     abc:      	umaddl	x8, w8, w9, x21
     ac0:      	add	x9, x8, #0x2d0
     ac4:      	str	x10, [x8, #0x2d8]
     ac8:      	mov	w10, #0x2               // =2
     acc:      	str	xzr, [x8, #0x2d0]
     ad0:      	str	wzr, [x8, #0x2e4]
     ad4:      	strb	w10, [x8, #0x2e0]
     ad8:      	stur	wzr, [x9, #0x11]
     adc:      	b	0x684 <perf_unwind_php+0x684>
     ae0:      	adrp	x8, 0x0 <perf_unwind_php>
     ae4:      	add	x8, x8, #0x0
     ae8:      	add	x0, sp, #0x18
     aec:      	ldp	x9, x10, [x8, #0x10]
     af0:      	mov	w1, #0x2e               // =46
     af4:      	stp	x9, x10, [sp, #0x28]
     af8:      	ldr	x9, [x8, #0x20]
     afc:      	add	x10, sp, #0x18
     b00:      	str	x9, [sp, #0x38]
     b04:      	ldur	x9, [x8, #0x26]
     b08:      	stur	x9, [sp, #0x3e]
     b0c:      	ldp	x9, x8, [x8]
     b10:      	stp	x9, x8, [sp, #0x18]
     b14:      	mov	w8, #0x2e               // =46
     b18:      	mov	w9, #0x6                // =6
     b1c:      	ldr	w2, [sp, #0x70]
     b20:      	blr	x9
     b24:      	ldr	x8, [x21, #0xf50]
     b28:      	add	x22, x21, #0xf50
     b2c:      	cbnz	x8, 0x134 <perf_unwind_php+0x134>
     b30:      	ldr	x8, [x24]
     b34:      	mov	w9, #0x8                // =8
     b38:      	mov	w10, #0x70              // =112
     b3c:      	mov	x0, x22
     b40:      	ldr	x2, [x24]
     b44:      	mov	w1, #0x8                // =8
     b48:      	blr	x10
     b4c:      	cbz	x0, 0x134 <perf_unwind_php+0x134>
     b50:      	ldr	w8, [x29]
     b54:      	cbnz	w8, 0xd34 <perf_unwind_php+0xd34>
     b58:      	mov	w8, #0x24               // =36
     b5c:      	add	x9, sp, #0x70
     b60:      	add	x1, sp, #0x70
     b64:      	str	w8, [sp, #0x70]
     b68:      	mov	w8, #0x1                // =1
     b6c:      	mov	x0, x23
     b70:      	blr	x8
     b74:      	cbz	x0, 0xb8c <perf_unwind_php+0xb8c>
     b78:      	ldr	x8, [x0]
     b7c:      	mov	w23, #0x1               // =1
     b80:      	add	x8, x8, #0x1
     b84:      	str	x8, [x0]
     b88:      	b	0xb98 <perf_unwind_php+0xb98>
     b8c:      	ldr	w8, [x29]
     b90:      	cbnz	w8, 0xec8 <perf_unwind_php+0xec8>
     b94:      	mov	w23, #0x1               // =1
     b98:      	str	wzr, [sp, #0x18]
     b9c:      	mov	w8, #0x1                // =1
     ba0:      	add	x9, sp, #0x18
     ba4:      	add	x1, sp, #0x18
     ba8:      	mov	x0, x20
     bac:      	blr	x8
     bb0:      	cbz	x0, 0xc04 <perf_unwind_php+0xc04>
     bb4:      	mov	w20, #0x1374            // =4980
     bb8:      	ldrb	w8, [x0, x20]
     bbc:      	cmp	w8, #0x1d
     bc0:      	b.lo	0xc30 <perf_unwind_php+0xc30>
     bc4:      	mov	w8, #0x5                // =5
     bc8:      	mov	x21, x0
     bcc:      	add	x9, sp, #0x70
     bd0:      	str	w8, [x0, #0xf1c]
     bd4:      	mov	w8, #0x44               // =68
     bd8:      	adrp	x0, 0x0 <perf_unwind_php>
     bdc:      	add	x1, sp, #0x70
     be0:      	str	w8, [sp, #0x70]
     be4:      	mov	w8, #0x1                // =1
     be8:      	ldr	x0, [x0]
     bec:      	blr	x8
     bf0:      	cbz	x0, 0xc1c <perf_unwind_php+0xc1c>
     bf4:      	ldr	x8, [x0]
     bf8:      	add	x8, x8, #0x1
     bfc:      	str	x8, [x0]
     c00:      	b	0xc24 <perf_unwind_php+0xc24>
     c04:      	adrp	x10, 0x0 <perf_unwind_php>
     c08:      	mov	x9, xzr
     c0c:      	mov	w8, #0xc                // =12
     c10:      	ldr	x10, [x10]
     c14:      	mov	w23, wzr
     c18:      	b	0xc48 <perf_unwind_php+0xc48>
     c1c:      	ldr	w8, [x29]
     c20:      	cbnz	w8, 0xd84 <perf_unwind_php+0xd84>
     c24:      	ldrb	w8, [x21, x20]
     c28:      	mov	w23, wzr
     c2c:      	mov	x0, x21
     c30:      	add	w8, w8, #0x1
     c34:      	adrp	x10, 0x0 <perf_unwind_php>
     c38:      	mov	w9, w23
     c3c:      	strb	w8, [x0, x20]
     c40:      	mov	w8, #0xc                // =12
     c44:      	ldr	x10, [x10]
     c48:      	adrp	x1, 0x0 <perf_unwind_php>
     c4c:      	mov	x0, x19
     c50:      	mov	w2, w23
     c54:      	ldr	x1, [x1]
     c58:      	blr	x8
     c5c:      	ldp	x20, x19, [sp, #0xc0]
     c60:      	mov	w0, #-0x1               // =-1
     c64:      	ldr	x29, [sp, #0x80]
     c68:      	ldp	x22, x21, [sp, #0xb0]
     c6c:      	ldp	x24, x23, [sp, #0xa0]
     c70:      	ldp	x30, x25, [sp, #0x90]
     c74:      	add	sp, sp, #0xd0
     c78:      	ret
     c7c:      	mov	w8, #0x2978             // =10616
     c80:      	add	x0, sp, #0x18
     c84:      	mov	w1, #0x33               // =51
     c88:      	movk	w8, #0xa, lsl #16
     c8c:      	stur	w8, [sp, #0x47]
     c90:      	adrp	x8, 0x0 <perf_unwind_php>
     c94:      	add	x8, x8, #0x0
     c98:      	ldp	x9, x10, [x8, #0x10]
     c9c:      	stp	x9, x10, [sp, #0x28]
     ca0:      	ldp	x9, x10, [x8, #0x20]
     ca4:      	stp	x9, x10, [sp, #0x38]
     ca8:      	ldp	x9, x8, [x8]
     cac:      	add	x10, sp, #0x18
     cb0:      	stp	x9, x8, [sp, #0x18]
     cb4:      	mov	w8, #0x33               // =51
     cb8:      	mov	w9, #0x6                // =6
     cbc:      	ldrb	w8, [x24, #0x10]
     cc0:      	add	x2, x25, x8
     cc4:      	blr	x9
     cc8:      	b	0x20c <perf_unwind_php+0x20c>
     ccc:      	ldrb	w8, [sp, #0x8c]
     cd0:      	str	wzr, [sp, #0x88]
     cd4:      	cmp	w8, #0x4
     cd8:      	b.eq	0xce8 <perf_unwind_php+0xce8>
     cdc:      	mov	w29, wzr
     ce0:      	cmp	w8, #0x2
     ce4:      	b.ne	0x13f4 <perf_unwind_php+0x13f4>
     ce8:      	ldrb	w8, [x24, #0x11]
     cec:      	mov	w9, #0x8                // =8
     cf0:      	mov	w10, #0x70              // =112
     cf4:      	add	x11, sp, #0x68
     cf8:      	add	x0, sp, #0x68
     cfc:      	mov	w1, #0x8                // =8
     d00:      	add	x8, x25, x8
     d04:      	ldrb	w8, [x24, #0x11]
     d08:      	add	x2, x25, x8
     d0c:      	blr	x10
     d10:      	cbz	x0, 0xf54 <perf_unwind_php+0xf54>
     d14:      	adrp	x8, 0x0 <perf_unwind_php>
     d18:      	ldr	x8, [x8]
     d1c:      	ldr	w8, [x8]
     d20:      	cbnz	w8, 0x1c84 <perf_unwind_php+0x1c84>
     d24:      	adrp	x29, 0x0 <perf_unwind_php>
     d28:      	mov	w25, #0x25              // =37
     d2c:      	ldr	x29, [x29]
     d30:      	b	0x684 <perf_unwind_php+0x684>
     d34:      	adrp	x8, 0x0 <perf_unwind_php>
     d38:      	add	x8, x8, #0x0
     d3c:      	add	x0, sp, #0x18
     d40:      	ldp	x9, x10, [x8, #0x20]
     d44:      	mov	w1, #0x3e               // =62
     d48:      	stp	x9, x10, [sp, #0x38]
     d4c:      	ldr	x9, [x8, #0x30]
     d50:      	str	x9, [sp, #0x48]
     d54:      	ldur	x9, [x8, #0x36]
     d58:      	stur	x9, [sp, #0x4e]
     d5c:      	ldp	x9, x10, [x8]
     d60:      	stp	x9, x10, [sp, #0x18]
     d64:      	add	x10, sp, #0x18
     d68:      	ldp	x9, x8, [x8, #0x10]
     d6c:      	stp	x9, x8, [sp, #0x28]
     d70:      	mov	w8, #0x3e               // =62
     d74:      	mov	w9, #0x6                // =6
     d78:      	ldr	x2, [x24]
     d7c:      	blr	x9
     d80:      	b	0xb58 <perf_unwind_php+0xb58>
     d84:      	adrp	x8, 0x0 <perf_unwind_php>
     d88:      	add	x8, x8, #0x0
     d8c:      	add	x0, sp, #0x18
     d90:      	ldp	x9, x10, [x8, #0x10]
     d94:      	mov	w1, #0x2e               // =46
     d98:      	stp	x9, x10, [sp, #0x28]
     d9c:      	ldr	x9, [x8, #0x20]
     da0:      	add	x10, sp, #0x18
     da4:      	str	x9, [sp, #0x38]
     da8:      	ldur	x9, [x8, #0x26]
     dac:      	stur	x9, [sp, #0x3e]
     db0:      	ldp	x9, x8, [x8]
     db4:      	stp	x9, x8, [sp, #0x18]
     db8:      	mov	w8, #0x2e               // =46
     dbc:      	mov	w9, #0x6                // =6
     dc0:      	ldr	w2, [sp, #0x70]
     dc4:      	blr	x9
     dc8:      	b	0xc24 <perf_unwind_php+0xc24>
     dcc:      	adrp	x8, 0x0 <perf_unwind_php>
     dd0:      	add	x8, x8, #0x0
     dd4:      	add	x0, sp, #0x18
     dd8:      	ldp	x9, x10, [x8, #0x10]
     ddc:      	mov	w1, #0x2e               // =46
     de0:      	stp	x9, x10, [sp, #0x28]
     de4:      	ldr	x9, [x8, #0x20]
     de8:      	add	x10, sp, #0x18
     dec:      	str	x9, [sp, #0x38]
     df0:      	ldur	x9, [x8, #0x26]
     df4:      	stur	x9, [sp, #0x3e]
     df8:      	ldp	x9, x8, [x8]
     dfc:      	stp	x9, x8, [sp, #0x18]
     e00:      	mov	w8, #0x2e               // =46
     e04:      	mov	w9, #0x6                // =6
     e08:      	ldr	w2, [sp, #0x70]
     e0c:      	blr	x9
     e10:      	cmp	w25, #0x23
     e14:      	b.eq	0x29c <perf_unwind_php+0x29c>
     e18:      	b	0x414 <perf_unwind_php+0x414>
     e1c:      	ldr	w10, [sp, #0x88]
     e20:      	ldr	w25, [sp, #0x5c]
     e24:      	ldr	w8, [x29]
     e28:      	cbnz	w8, 0x17c4 <perf_unwind_php+0x17c4>
     e2c:      	ldr	w8, [x21, #0x2c0]
     e30:      	cmp	w8, #0x7e
     e34:      	b.hi	0x82c <perf_unwind_php+0x82c>
     e38:      	add	w9, w8, #0x1
     e3c:      	mov	w10, w10
     e40:      	adrp	x29, 0x0 <perf_unwind_php>
     e44:      	str	w9, [x21, #0x2c0]
     e48:      	mov	w9, #0x18               // =24
     e4c:      	orr	x10, x10, x25, lsl #32
     e50:      	mov	w25, #0x23              // =35
     e54:      	umaddl	x8, w8, w9, x21
     e58:      	ldr	x9, [sp, #0x70]
     e5c:      	str	x10, [x8, #0x2d8]
     e60:      	str	wzr, [x8, #0x2e4]
     e64:      	str	x9, [x8, #0x2d0]
     e68:      	ldr	w9, [sp, #0xc]
     e6c:      	strb	w9, [x8, #0x2e0]
     e70:      	add	x9, x8, #0x2d0
     e74:      	stur	wzr, [x9, #0x11]
     e78:      	ldr	x29, [x29]
     e7c:      	b	0x354 <perf_unwind_php+0x354>
     e80:      	adrp	x8, 0x0 <perf_unwind_php>
     e84:      	add	x8, x8, #0x0
     e88:      	add	x0, sp, #0x18
     e8c:      	ldp	x9, x10, [x8, #0x20]
     e90:      	mov	w1, #0x40               // =64
     e94:      	stp	x9, x10, [sp, #0x38]
     e98:      	ldp	x9, x10, [x8, #0x30]
     e9c:      	stp	x9, x10, [sp, #0x48]
     ea0:      	ldp	x9, x10, [x8]
     ea4:      	stp	x9, x10, [sp, #0x18]
     ea8:      	ldp	x9, x8, [x8, #0x10]
     eac:      	add	x10, sp, #0x18
     eb0:      	stp	x9, x8, [sp, #0x28]
     eb4:      	mov	w8, #0x40               // =64
     eb8:      	mov	w9, #0x6                // =6
     ebc:      	ldr	x2, [sp, #0x60]
     ec0:      	blr	x9
     ec4:      	b	0x2d8 <perf_unwind_php+0x2d8>
     ec8:      	adrp	x8, 0x0 <perf_unwind_php>
     ecc:      	add	x8, x8, #0x0
     ed0:      	add	x0, sp, #0x18
     ed4:      	ldp	x9, x10, [x8, #0x10]
     ed8:      	mov	w1, #0x2e               // =46
     edc:      	stp	x9, x10, [sp, #0x28]
     ee0:      	ldr	x9, [x8, #0x20]
     ee4:      	add	x10, sp, #0x18
     ee8:      	str	x9, [sp, #0x38]
     eec:      	ldur	x9, [x8, #0x26]
     ef0:      	stur	x9, [sp, #0x3e]
     ef4:      	ldp	x9, x8, [x8]
     ef8:      	stp	x9, x8, [sp, #0x18]
     efc:      	mov	w8, #0x2e               // =46
     f00:      	mov	w9, #0x6                // =6
     f04:      	ldr	w2, [sp, #0x70]
     f08:      	blr	x9
     f0c:      	b	0xb94 <perf_unwind_php+0xb94>
     f10:      	adrp	x8, 0x0 <perf_unwind_php>
     f14:      	add	x8, x8, #0x0
     f18:      	strb	wzr, [sp, #0x48]
     f1c:      	add	x0, sp, #0x18
     f20:      	ldp	x9, x10, [x8, #0x10]
     f24:      	mov	w1, #0x31               // =49
     f28:      	stp	x9, x10, [sp, #0x28]
     f2c:      	ldp	x9, x10, [x8, #0x20]
     f30:      	stp	x9, x10, [sp, #0x38]
     f34:      	ldp	x9, x8, [x8]
     f38:      	add	x10, sp, #0x18
     f3c:      	stp	x9, x8, [sp, #0x18]
     f40:      	mov	w8, #0x31               // =49
     f44:      	mov	w9, #0x6                // =6
     f48:      	ldr	x2, [sp, #0x70]
     f4c:      	blr	x9
     f50:      	b	0x284 <perf_unwind_php+0x284>
     f54:      	ldr	x8, [sp, #0x68]
     f58:      	ldrb	w9, [x24, #0x15]
     f5c:      	mov	w10, #0x70              // =112
     f60:      	add	x11, sp, #0x88
     f64:      	add	x0, sp, #0x88
     f68:      	mov	w1, #0x4                // =4
     f6c:      	add	x8, x8, x9
     f70:      	mov	w9, #0x4                // =4
     f74:      	ldr	x8, [sp, #0x68]
     f78:      	ldrb	w9, [x24, #0x15]
     f7c:      	add	x2, x8, x9
     f80:      	blr	x10
     f84:      	cbz	x0, 0x1154 <perf_unwind_php+0x1154>
     f88:      	adrp	x8, 0x0 <perf_unwind_php>
     f8c:      	ldr	x8, [x8]
     f90:      	ldr	w8, [x8]
     f94:      	cbnz	w8, 0x1eb4 <perf_unwind_php+0x1eb4>
     f98:      	adrp	x29, 0x0 <perf_unwind_php>
     f9c:      	mov	w25, #0x27              // =39
     fa0:      	ldr	x29, [x29]
     fa4:      	b	0x684 <perf_unwind_php+0x684>
     fa8:      	ldr	x8, [sp, #0x70]
     fac:      	cbz	x8, 0x11d4 <perf_unwind_php+0x11d4>
     fb0:      	ldrb	w9, [x24, #0x14]
     fb4:      	mov	w10, #0x70              // =112
     fb8:      	add	x11, sp, #0x8c
     fbc:      	add	x0, sp, #0x8c
     fc0:      	mov	w1, #0x1                // =1
     fc4:      	add	x8, x8, x9
     fc8:      	mov	w9, #0x1                // =1
     fcc:      	ldr	x8, [sp, #0x70]
     fd0:      	ldrb	w9, [x24, #0x14]
     fd4:      	add	x2, x8, x9
     fd8:      	blr	x10
     fdc:      	cbz	x0, 0x12fc <perf_unwind_php+0x12fc>
     fe0:      	adrp	x8, 0x0 <perf_unwind_php>
     fe4:      	ldr	x8, [x8]
     fe8:      	ldr	w8, [x8]
     fec:      	cbnz	w8, 0x1f14 <perf_unwind_php+0x1f14>
     ff0:      	mov	w25, #0x26              // =38
     ff4:      	b	0xa24 <perf_unwind_php+0xa24>
     ff8:      	adrp	x8, 0x0 <perf_unwind_php>
     ffc:      	add	x8, x8, #0x0
    1000:      	add	x0, sp, #0x18
    1004:      	ldp	x9, x10, [x8, #0x10]
    1008:      	mov	w1, #0x2e               // =46
    100c:      	stp	x9, x10, [sp, #0x28]
    1010:      	ldr	x9, [x8, #0x20]
    1014:      	add	x10, sp, #0x18
    1018:      	str	x9, [sp, #0x38]
    101c:      	ldur	x9, [x8, #0x26]
    1020:      	stur	x9, [sp, #0x3e]
    1024:      	ldp	x9, x8, [x8]
    1028:      	stp	x9, x8, [sp, #0x18]
    102c:      	mov	w8, #0x2e               // =46
    1030:      	mov	w9, #0x6                // =6
    1034:      	ldr	w2, [sp, #0x70]
    1038:      	blr	x9
    103c:      	b	0x414 <perf_unwind_php+0x414>
    1040:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1044:      	ldr	x8, [x8]
    1048:      	ldr	w8, [x8]
    104c:      	cbnz	w8, 0x1e0c <perf_unwind_php+0x1e0c>
    1050:      	cmp	w25, #0x23
    1054:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    1058:      	ldr	x8, [sp, #0x60]
    105c:      	ldrb	w9, [x24, #0x12]
    1060:      	mov	w10, #0x70              // =112
    1064:      	add	x11, sp, #0x60
    1068:      	add	x0, sp, #0x60
    106c:      	mov	w1, #0x8                // =8
    1070:      	add	x8, x8, x9
    1074:      	mov	w9, #0x8                // =8
    1078:      	ldr	x8, [sp, #0x60]
    107c:      	ldrb	w9, [x24, #0x12]
    1080:      	add	x2, x8, x9
    1084:      	blr	x10
    1088:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    108c:      	ldr	x29, [x29]
    1090:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    1094:      	ldr	x25, [sp, #0x60]
    1098:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    109c:      	ldrb	w8, [sp, #0x5e]
    10a0:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    10a4:      	ldrb	w8, [x24, #0x10]
    10a8:      	mov	w9, #0x8                // =8
    10ac:      	mov	w10, #0x70              // =112
    10b0:      	add	x11, sp, #0x70
    10b4:      	add	x0, sp, #0x70
    10b8:      	mov	w1, #0x8                // =8
    10bc:      	add	x8, x25, x8
    10c0:      	ldrb	w8, [x24, #0x10]
    10c4:      	add	x2, x25, x8
    10c8:      	blr	x10
    10cc:      	cbz	x0, 0x1580 <perf_unwind_php+0x1580>
    10d0:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    10d4:      	ldr	x8, [x8]
    10d8:      	ldr	w8, [x8]
    10dc:      	cbnz	w8, 0x2198 <perf_unwind_php+0x2198>
    10e0:      	mov	w25, #0x25              // =37
    10e4:      	str	w25, [sp, #0x70]
    10e8:      	mov	w8, #0x1                // =1
    10ec:      	add	x9, sp, #0x70
    10f0:      	add	x1, sp, #0x70
    10f4:      	mov	x0, x23
    10f8:      	blr	x8
    10fc:      	cbz	x0, 0x15d0 <perf_unwind_php+0x15d0>
    1100:      	ldr	x8, [x0]
    1104:      	add	x8, x8, #0x1
    1108:      	str	x8, [x0]
    110c:      	cmp	w25, #0x23
    1110:      	b.eq	0x15e8 <perf_unwind_php+0x15e8>
    1114:      	b	0x61f4 <perf_unwind_php+0x61f4>
    1118:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    111c:      	add	x8, x8, #0x0
    1120:      	add	x0, sp, #0x18
    1124:      	ldp	x9, x10, [x8, #0x10]
    1128:      	mov	w1, #0x25               // =37
    112c:      	stp	x9, x10, [sp, #0x28]
    1130:      	ldur	x9, [x8, #0x1d]
    1134:      	add	x10, sp, #0x18
    1138:      	stur	x9, [sp, #0x35]
    113c:      	ldp	x8, x9, [x8]
    1140:      	stp	x8, x9, [sp, #0x18]
    1144:      	mov	w8, #0x25               // =37
    1148:      	mov	w9, #0x6                // =6
    114c:      	blr	x9
    1150:      	b	0x39c <perf_unwind_php+0x39c>
    1154:      	ldrb	w8, [x24, #0x13]
    1158:      	mov	w9, #0x4                // =4
    115c:      	mov	w10, #0x70              // =112
    1160:      	add	x11, sp, #0x5c
    1164:      	add	x0, sp, #0x5c
    1168:      	mov	w1, #0x4                // =4
    116c:      	add	x8, x25, x8
    1170:      	ldrb	w8, [x24, #0x13]
    1174:      	add	x2, x25, x8
    1178:      	blr	x10
    117c:      	cbz	x0, 0x13f0 <perf_unwind_php+0x13f0>
    1180:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1184:      	ldr	x8, [x8]
    1188:      	ldr	w8, [x8]
    118c:      	cbz	w8, 0xd24 <perf_unwind_php+0xd24>
    1190:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1194:      	add	x8, x8, #0x0
    1198:      	add	x0, sp, #0x18
    119c:      	ldp	x9, x10, [x8, #0x20]
    11a0:      	mov	w1, #0x35               // =53
    11a4:      	mov	x2, x25
    11a8:      	stp	x9, x10, [sp, #0x38]
    11ac:      	ldur	x9, [x8, #0x2d]
    11b0:      	stur	x9, [sp, #0x45]
    11b4:      	ldp	x9, x10, [x8]
    11b8:      	stp	x9, x10, [sp, #0x18]
    11bc:      	ldp	x8, x9, [x8, #0x10]
    11c0:      	add	x10, sp, #0x18
    11c4:      	stp	x8, x9, [sp, #0x28]
    11c8:      	mov	w8, #0x35               // =53
    11cc:      	mov	w9, #0x6                // =6
    11d0:      	b	0x1cc8 <perf_unwind_php+0x1cc8>
    11d4:      	ldr	w8, [x21, #0x2c0]
    11d8:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    11dc:      	ldr	x29, [x29]
    11e0:      	cmp	w8, #0x7e
    11e4:      	b.hi	0x394 <perf_unwind_php+0x394>
    11e8:      	add	w9, w8, #0x1
    11ec:      	mov	x10, #-0x2              // =-2
    11f0:      	str	w9, [x21, #0x2c0]
    11f4:      	mov	w9, #0x18               // =24
    11f8:      	umaddl	x8, w8, w9, x21
    11fc:      	add	x9, x8, #0x2d0
    1200:      	str	x10, [x8, #0x2d8]
    1204:      	mov	w10, #0x2               // =2
    1208:      	str	xzr, [x8, #0x2d0]
    120c:      	strb	w10, [x8, #0x2e0]
    1210:      	mov	w25, #0x23              // =35
    1214:      	str	wzr, [x8, #0x2e4]
    1218:      	stur	wzr, [x9, #0x11]
    121c:      	b	0xa24 <perf_unwind_php+0xa24>
    1220:      	mov	w8, #0x2978             // =10616
    1224:      	add	x0, sp, #0x18
    1228:      	mov	w1, #0x33               // =51
    122c:      	movk	w8, #0xa, lsl #16
    1230:      	stur	w8, [sp, #0x47]
    1234:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1238:      	add	x8, x8, #0x0
    123c:      	ldp	x9, x10, [x8, #0x10]
    1240:      	stp	x9, x10, [sp, #0x28]
    1244:      	ldp	x9, x10, [x8, #0x20]
    1248:      	stp	x9, x10, [sp, #0x38]
    124c:      	ldp	x9, x8, [x8]
    1250:      	add	x10, sp, #0x18
    1254:      	stp	x9, x8, [sp, #0x18]
    1258:      	mov	w8, #0x33               // =51
    125c:      	mov	w9, #0x6                // =6
    1260:      	ldrb	w8, [x24, #0x10]
    1264:      	add	x2, x25, x8
    1268:      	blr	x9
    126c:      	b	0x350 <perf_unwind_php+0x350>
    1270:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1274:      	add	x8, x8, #0x0
    1278:      	add	x0, sp, #0x18
    127c:      	ldp	x9, x10, [x8]
    1280:      	ldur	x8, [x8, #0xe]
    1284:      	mov	w1, #0x16               // =22
    1288:      	stp	x9, x10, [sp, #0x18]
    128c:      	stur	x8, [sp, #0x26]
    1290:      	mov	w8, #0x16               // =22
    1294:      	mov	w9, #0x6                // =6
    1298:      	add	x10, sp, #0x18
    129c:      	ldr	x2, [sp, #0x70]
    12a0:      	ldr	w3, [sp, #0x88]
    12a4:      	blr	x9
    12a8:      	ldr	w8, [x21, #0x2c0]
    12ac:      	cmp	w8, #0x7f
    12b0:      	b.hs	0x82c <perf_unwind_php+0x82c>
    12b4:      	add	w9, w8, #0x1
    12b8:      	mov	w10, w29
    12bc:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    12c0:      	str	w9, [x21, #0x2c0]
    12c4:      	mov	w9, #0x18               // =24
    12c8:      	orr	x10, x10, x25, lsl #32
    12cc:      	mov	w25, #0x23              // =35
    12d0:      	umaddl	x8, w8, w9, x21
    12d4:      	ldr	x9, [sp, #0x70]
    12d8:      	str	x10, [x8, #0x2d8]
    12dc:      	str	wzr, [x8, #0x2e4]
    12e0:      	str	x9, [x8, #0x2d0]
    12e4:      	ldr	w9, [sp, #0xc]
    12e8:      	strb	w9, [x8, #0x2e0]
    12ec:      	add	x9, x8, #0x2d0
    12f0:      	stur	wzr, [x9, #0x11]
    12f4:      	ldr	x29, [x29]
    12f8:      	b	0x210 <perf_unwind_php+0x210>
    12fc:      	ldrb	w8, [sp, #0x8c]
    1300:      	str	wzr, [sp, #0x88]
    1304:      	cmp	w8, #0x4
    1308:      	b.eq	0x1318 <perf_unwind_php+0x1318>
    130c:      	mov	w29, wzr
    1310:      	cmp	w8, #0x2
    1314:      	b.ne	0x190c <perf_unwind_php+0x190c>
    1318:      	ldrb	w8, [x24, #0x11]
    131c:      	mov	w9, #0x8                // =8
    1320:      	mov	w10, #0x70              // =112
    1324:      	add	x11, sp, #0x68
    1328:      	add	x0, sp, #0x68
    132c:      	mov	w1, #0x8                // =8
    1330:      	add	x8, x25, x8
    1334:      	ldrb	w8, [x24, #0x11]
    1338:      	add	x2, x25, x8
    133c:      	blr	x10
    1340:      	cbz	x0, 0x1534 <perf_unwind_php+0x1534>
    1344:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1348:      	ldr	x8, [x8]
    134c:      	ldr	w8, [x8]
    1350:      	cbz	w8, 0xa20 <perf_unwind_php+0xa20>
    1354:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1358:      	add	x8, x8, #0x0
    135c:      	add	x0, sp, #0x18
    1360:      	ldp	x9, x10, [x8, #0x10]
    1364:      	mov	w1, #0x2d               // =45
    1368:      	stp	x9, x10, [sp, #0x28]
    136c:      	ldr	x9, [x8, #0x20]
    1370:      	add	x10, sp, #0x18
    1374:      	str	x9, [sp, #0x38]
    1378:      	ldur	x9, [x8, #0x25]
    137c:      	stur	x9, [sp, #0x3d]
    1380:      	ldp	x9, x8, [x8]
    1384:      	stp	x9, x8, [sp, #0x18]
    1388:      	mov	w8, #0x2d               // =45
    138c:      	mov	w9, #0x6                // =6
    1390:      	ldrb	w8, [x24, #0x11]
    1394:      	add	x2, x25, x8
    1398:      	blr	x9
    139c:      	b	0xa20 <perf_unwind_php+0xa20>
    13a0:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    13a4:      	add	x8, x8, #0x0
    13a8:      	add	x0, sp, #0x18
    13ac:      	ldp	x9, x10, [x8, #0x10]
    13b0:      	mov	w1, #0x2e               // =46
    13b4:      	stp	x9, x10, [sp, #0x28]
    13b8:      	ldr	x9, [x8, #0x20]
    13bc:      	add	x10, sp, #0x18
    13c0:      	str	x9, [sp, #0x38]
    13c4:      	ldur	x9, [x8, #0x26]
    13c8:      	stur	x9, [sp, #0x3e]
    13cc:      	ldp	x9, x8, [x8]
    13d0:      	stp	x9, x8, [sp, #0x18]
    13d4:      	mov	w8, #0x2e               // =46
    13d8:      	mov	w9, #0x6                // =6
    13dc:      	ldr	w2, [sp, #0x70]
    13e0:      	blr	x9
    13e4:      	cmp	w25, #0x23
    13e8:      	b.eq	0x608 <perf_unwind_php+0x608>
    13ec:      	b	0x414 <perf_unwind_php+0x414>
    13f0:      	ldr	w29, [sp, #0x88]
    13f4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    13f8:      	ldr	w25, [sp, #0x5c]
    13fc:      	ldr	x8, [x8]
    1400:      	ldr	w8, [x8]
    1404:      	cbnz	w8, 0x1d20 <perf_unwind_php+0x1d20>
    1408:      	ldr	w8, [x21, #0x2c0]
    140c:      	cmp	w8, #0x7e
    1410:      	b.hi	0x82c <perf_unwind_php+0x82c>
    1414:      	add	w9, w8, #0x1
    1418:      	mov	w10, w29
    141c:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    1420:      	str	w9, [x21, #0x2c0]
    1424:      	mov	w9, #0x18               // =24
    1428:      	orr	x10, x10, x25, lsl #32
    142c:      	mov	w25, #0x23              // =35
    1430:      	umaddl	x8, w8, w9, x21
    1434:      	ldr	x9, [sp, #0x70]
    1438:      	str	x10, [x8, #0x2d8]
    143c:      	str	wzr, [x8, #0x2e4]
    1440:      	str	x9, [x8, #0x2d0]
    1444:      	ldr	w9, [sp, #0xc]
    1448:      	strb	w9, [x8, #0x2e0]
    144c:      	add	x9, x8, #0x2d0
    1450:      	stur	wzr, [x9, #0x11]
    1454:      	ldr	x29, [x29]
    1458:      	b	0x684 <perf_unwind_php+0x684>
    145c:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1460:      	add	x8, x8, #0x0
    1464:      	add	x0, sp, #0x18
    1468:      	ldp	x9, x10, [x8, #0x10]
    146c:      	mov	w1, #0x25               // =37
    1470:      	stp	x9, x10, [sp, #0x28]
    1474:      	ldur	x9, [x8, #0x1d]
    1478:      	add	x10, sp, #0x18
    147c:      	stur	x9, [sp, #0x35]
    1480:      	ldp	x8, x9, [x8]
    1484:      	stp	x8, x9, [sp, #0x18]
    1488:      	mov	w8, #0x25               // =37
    148c:      	mov	w9, #0x6                // =6
    1490:      	blr	x9
    1494:      	b	0x83c <perf_unwind_php+0x83c>
    1498:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    149c:      	add	x8, x8, #0x0
    14a0:      	strb	wzr, [sp, #0x50]
    14a4:      	add	x0, sp, #0x18
    14a8:      	ldp	x9, x10, [x8, #0x20]
    14ac:      	mov	w1, #0x39               // =57
    14b0:      	stp	x9, x10, [sp, #0x38]
    14b4:      	ldr	x9, [x8, #0x30]
    14b8:      	str	x9, [sp, #0x48]
    14bc:      	ldp	x9, x10, [x8]
    14c0:      	stp	x9, x10, [sp, #0x18]
    14c4:      	ldp	x8, x9, [x8, #0x10]
    14c8:      	add	x10, sp, #0x18
    14cc:      	stp	x8, x9, [sp, #0x28]
    14d0:      	mov	w8, #0x39               // =57
    14d4:      	mov	w9, #0x6                // =6
    14d8:      	ldr	x8, [sp, #0x68]
    14dc:      	ldrb	w10, [x24, #0x15]
    14e0:      	add	x2, x8, x10
    14e4:      	blr	x9
    14e8:      	mov	w25, #0x27              // =39
    14ec:      	b	0x210 <perf_unwind_php+0x210>
    14f0:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    14f4:      	add	x8, x8, #0x0
    14f8:      	strb	wzr, [sp, #0x48]
    14fc:      	add	x0, sp, #0x18
    1500:      	ldp	x9, x10, [x8, #0x10]
    1504:      	mov	w1, #0x31               // =49
    1508:      	stp	x9, x10, [sp, #0x28]
    150c:      	ldp	x9, x10, [x8, #0x20]
    1510:      	stp	x9, x10, [sp, #0x38]
    1514:      	ldp	x9, x8, [x8]
    1518:      	add	x10, sp, #0x18
    151c:      	stp	x9, x8, [sp, #0x18]
    1520:      	mov	w8, #0x31               // =49
    1524:      	mov	w9, #0x6                // =6
    1528:      	ldr	x2, [sp, #0x70]
    152c:      	blr	x9
    1530:      	b	0x5f0 <perf_unwind_php+0x5f0>
    1534:      	ldr	x8, [sp, #0x68]
    1538:      	ldrb	w9, [x24, #0x15]
    153c:      	mov	w10, #0x70              // =112
    1540:      	add	x11, sp, #0x88
    1544:      	add	x0, sp, #0x88
    1548:      	mov	w1, #0x4                // =4
    154c:      	add	x8, x8, x9
    1550:      	mov	w9, #0x4                // =4
    1554:      	ldr	x8, [sp, #0x68]
    1558:      	ldrb	w9, [x24, #0x15]
    155c:      	add	x2, x8, x9
    1560:      	blr	x10
    1564:      	cbz	x0, 0x16a8 <perf_unwind_php+0x16a8>
    1568:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    156c:      	ldr	x8, [x8]
    1570:      	ldr	w8, [x8]
    1574:      	cbnz	w8, 0x237c <perf_unwind_php+0x237c>
    1578:      	mov	w25, #0x27              // =39
    157c:      	b	0xa24 <perf_unwind_php+0xa24>
    1580:      	ldr	x8, [sp, #0x70]
    1584:      	cbz	x8, 0x1728 <perf_unwind_php+0x1728>
    1588:      	ldrb	w9, [x24, #0x14]
    158c:      	mov	w10, #0x70              // =112
    1590:      	add	x11, sp, #0x8c
    1594:      	add	x0, sp, #0x8c
    1598:      	mov	w1, #0x1                // =1
    159c:      	add	x8, x8, x9
    15a0:      	mov	w9, #0x1                // =1
    15a4:      	ldr	x8, [sp, #0x70]
    15a8:      	ldrb	w9, [x24, #0x14]
    15ac:      	add	x2, x8, x9
    15b0:      	blr	x10
    15b4:      	cbz	x0, 0x1814 <perf_unwind_php+0x1814>
    15b8:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    15bc:      	ldr	x8, [x8]
    15c0:      	ldr	w8, [x8]
    15c4:      	cbnz	w8, 0x23d4 <perf_unwind_php+0x23d4>
    15c8:      	mov	w25, #0x26              // =38
    15cc:      	b	0x10e4 <perf_unwind_php+0x10e4>
    15d0:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    15d4:      	ldr	x8, [x8]
    15d8:      	ldr	w8, [x8]
    15dc:      	cbnz	w8, 0x22d4 <perf_unwind_php+0x22d4>
    15e0:      	cmp	w25, #0x23
    15e4:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    15e8:      	ldr	x8, [sp, #0x60]
    15ec:      	ldrb	w9, [x24, #0x12]
    15f0:      	mov	w10, #0x70              // =112
    15f4:      	add	x11, sp, #0x60
    15f8:      	add	x0, sp, #0x60
    15fc:      	mov	w1, #0x8                // =8
    1600:      	add	x8, x8, x9
    1604:      	mov	w9, #0x8                // =8
    1608:      	ldr	x8, [sp, #0x60]
    160c:      	ldrb	w9, [x24, #0x12]
    1610:      	add	x2, x8, x9
    1614:      	blr	x10
    1618:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    161c:      	ldr	x29, [x29]
    1620:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    1624:      	ldr	x25, [sp, #0x60]
    1628:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    162c:      	ldrb	w8, [sp, #0x5e]
    1630:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    1634:      	ldrb	w8, [x24, #0x10]
    1638:      	mov	w9, #0x8                // =8
    163c:      	mov	w10, #0x70              // =112
    1640:      	add	x11, sp, #0x70
    1644:      	add	x0, sp, #0x70
    1648:      	mov	w1, #0x8                // =8
    164c:      	add	x8, x25, x8
    1650:      	ldrb	w8, [x24, #0x10]
    1654:      	add	x2, x25, x8
    1658:      	blr	x10
    165c:      	cbz	x0, 0x1a48 <perf_unwind_php+0x1a48>
    1660:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1664:      	ldr	x8, [x8]
    1668:      	ldr	w8, [x8]
    166c:      	cbnz	w8, 0x2658 <perf_unwind_php+0x2658>
    1670:      	mov	w25, #0x25              // =37
    1674:      	str	w25, [sp, #0x70]
    1678:      	mov	w8, #0x1                // =1
    167c:      	add	x9, sp, #0x70
    1680:      	add	x1, sp, #0x70
    1684:      	mov	x0, x23
    1688:      	blr	x8
    168c:      	cbz	x0, 0x1a98 <perf_unwind_php+0x1a98>
    1690:      	ldr	x8, [x0]
    1694:      	add	x8, x8, #0x1
    1698:      	str	x8, [x0]
    169c:      	cmp	w25, #0x23
    16a0:      	b.eq	0x1ab0 <perf_unwind_php+0x1ab0>
    16a4:      	b	0x61f4 <perf_unwind_php+0x61f4>
    16a8:      	ldrb	w8, [x24, #0x13]
    16ac:      	mov	w9, #0x4                // =4
    16b0:      	mov	w10, #0x70              // =112
    16b4:      	add	x11, sp, #0x5c
    16b8:      	add	x0, sp, #0x5c
    16bc:      	mov	w1, #0x4                // =4
    16c0:      	add	x8, x25, x8
    16c4:      	ldrb	w8, [x24, #0x13]
    16c8:      	add	x2, x25, x8
    16cc:      	blr	x10
    16d0:      	cbz	x0, 0x1908 <perf_unwind_php+0x1908>
    16d4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    16d8:      	ldr	x8, [x8]
    16dc:      	ldr	w8, [x8]
    16e0:      	cbz	w8, 0xa20 <perf_unwind_php+0xa20>
    16e4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    16e8:      	add	x8, x8, #0x0
    16ec:      	add	x0, sp, #0x18
    16f0:      	ldp	x9, x10, [x8, #0x20]
    16f4:      	mov	w1, #0x35               // =53
    16f8:      	mov	x2, x25
    16fc:      	stp	x9, x10, [sp, #0x38]
    1700:      	ldur	x9, [x8, #0x2d]
    1704:      	stur	x9, [sp, #0x45]
    1708:      	ldp	x9, x10, [x8]
    170c:      	stp	x9, x10, [sp, #0x18]
    1710:      	ldp	x8, x9, [x8, #0x10]
    1714:      	add	x10, sp, #0x18
    1718:      	stp	x8, x9, [sp, #0x28]
    171c:      	mov	w8, #0x35               // =53
    1720:      	mov	w9, #0x6                // =6
    1724:      	b	0x1398 <perf_unwind_php+0x1398>
    1728:      	ldr	w8, [x21, #0x2c0]
    172c:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    1730:      	ldr	x29, [x29]
    1734:      	cmp	w8, #0x7e
    1738:      	b.hi	0x394 <perf_unwind_php+0x394>
    173c:      	add	w9, w8, #0x1
    1740:      	mov	x10, #-0x2              // =-2
    1744:      	str	w9, [x21, #0x2c0]
    1748:      	mov	w9, #0x18               // =24
    174c:      	umaddl	x8, w8, w9, x21
    1750:      	add	x9, x8, #0x2d0
    1754:      	str	x10, [x8, #0x2d8]
    1758:      	mov	w10, #0x2               // =2
    175c:      	str	xzr, [x8, #0x2d0]
    1760:      	strb	w10, [x8, #0x2e0]
    1764:      	mov	w25, #0x23              // =35
    1768:      	str	wzr, [x8, #0x2e4]
    176c:      	stur	wzr, [x9, #0x11]
    1770:      	b	0x10e4 <perf_unwind_php+0x10e4>
    1774:      	mov	w8, #0x2978             // =10616
    1778:      	add	x0, sp, #0x18
    177c:      	mov	w1, #0x33               // =51
    1780:      	movk	w8, #0xa, lsl #16
    1784:      	stur	w8, [sp, #0x47]
    1788:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    178c:      	add	x8, x8, #0x0
    1790:      	ldp	x9, x10, [x8, #0x10]
    1794:      	stp	x9, x10, [sp, #0x28]
    1798:      	ldp	x9, x10, [x8, #0x20]
    179c:      	stp	x9, x10, [sp, #0x38]
    17a0:      	ldp	x9, x8, [x8]
    17a4:      	add	x10, sp, #0x18
    17a8:      	stp	x9, x8, [sp, #0x18]
    17ac:      	mov	w8, #0x33               // =51
    17b0:      	mov	w9, #0x6                // =6
    17b4:      	ldrb	w8, [x24, #0x10]
    17b8:      	add	x2, x25, x8
    17bc:      	blr	x9
    17c0:      	b	0x680 <perf_unwind_php+0x680>
    17c4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    17c8:      	add	x8, x8, #0x0
    17cc:      	mov	w29, w10
    17d0:      	ldp	x9, x10, [x8]
    17d4:      	ldur	x8, [x8, #0xe]
    17d8:      	add	x0, sp, #0x18
    17dc:      	mov	w1, #0x16               // =22
    17e0:      	stp	x9, x10, [sp, #0x18]
    17e4:      	stur	x8, [sp, #0x26]
    17e8:      	mov	w8, #0x16               // =22
    17ec:      	mov	w9, #0x6                // =6
    17f0:      	add	x10, sp, #0x18
    17f4:      	ldr	x2, [sp, #0x70]
    17f8:      	ldr	w3, [sp, #0x88]
    17fc:      	blr	x9
    1800:      	mov	w10, w29
    1804:      	ldr	w8, [x21, #0x2c0]
    1808:      	cmp	w8, #0x7e
    180c:      	b.hi	0x82c <perf_unwind_php+0x82c>
    1810:      	b	0xe38 <perf_unwind_php+0xe38>
    1814:      	ldrb	w8, [sp, #0x8c]
    1818:      	str	wzr, [sp, #0x88]
    181c:      	cmp	w8, #0x4
    1820:      	b.eq	0x1830 <perf_unwind_php+0x1830>
    1824:      	mov	w29, wzr
    1828:      	cmp	w8, #0x2
    182c:      	b.ne	0x1e60 <perf_unwind_php+0x1e60>
    1830:      	ldrb	w8, [x24, #0x11]
    1834:      	mov	w9, #0x8                // =8
    1838:      	mov	w10, #0x70              // =112
    183c:      	add	x11, sp, #0x68
    1840:      	add	x0, sp, #0x68
    1844:      	mov	w1, #0x8                // =8
    1848:      	add	x8, x25, x8
    184c:      	ldrb	w8, [x24, #0x11]
    1850:      	add	x2, x25, x8
    1854:      	blr	x10
    1858:      	cbz	x0, 0x19fc <perf_unwind_php+0x19fc>
    185c:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1860:      	ldr	x8, [x8]
    1864:      	ldr	w8, [x8]
    1868:      	cbz	w8, 0x10e0 <perf_unwind_php+0x10e0>
    186c:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1870:      	add	x8, x8, #0x0
    1874:      	add	x0, sp, #0x18
    1878:      	ldp	x9, x10, [x8, #0x10]
    187c:      	mov	w1, #0x2d               // =45
    1880:      	stp	x9, x10, [sp, #0x28]
    1884:      	ldr	x9, [x8, #0x20]
    1888:      	add	x10, sp, #0x18
    188c:      	str	x9, [sp, #0x38]
    1890:      	ldur	x9, [x8, #0x25]
    1894:      	stur	x9, [sp, #0x3d]
    1898:      	ldp	x9, x8, [x8]
    189c:      	stp	x9, x8, [sp, #0x18]
    18a0:      	mov	w8, #0x2d               // =45
    18a4:      	mov	w9, #0x6                // =6
    18a8:      	ldrb	w8, [x24, #0x11]
    18ac:      	add	x2, x25, x8
    18b0:      	blr	x9
    18b4:      	b	0x10e0 <perf_unwind_php+0x10e0>
    18b8:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    18bc:      	add	x8, x8, #0x0
    18c0:      	add	x0, sp, #0x18
    18c4:      	ldp	x9, x10, [x8, #0x10]
    18c8:      	mov	w1, #0x2e               // =46
    18cc:      	stp	x9, x10, [sp, #0x28]
    18d0:      	ldr	x9, [x8, #0x20]
    18d4:      	add	x10, sp, #0x18
    18d8:      	str	x9, [sp, #0x38]
    18dc:      	ldur	x9, [x8, #0x26]
    18e0:      	stur	x9, [sp, #0x3e]
    18e4:      	ldp	x9, x8, [x8]
    18e8:      	stp	x9, x8, [sp, #0x18]
    18ec:      	mov	w8, #0x2e               // =46
    18f0:      	mov	w9, #0x6                // =6
    18f4:      	ldr	w2, [sp, #0x70]
    18f8:      	blr	x9
    18fc:      	cmp	w25, #0x23
    1900:      	b.eq	0x9a0 <perf_unwind_php+0x9a0>
    1904:      	b	0x414 <perf_unwind_php+0x414>
    1908:      	ldr	w29, [sp, #0x88]
    190c:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1910:      	ldr	w25, [sp, #0x5c]
    1914:      	ldr	x8, [x8]
    1918:      	ldr	w8, [x8]
    191c:      	cbnz	w8, 0x21e8 <perf_unwind_php+0x21e8>
    1920:      	ldr	w8, [x21, #0x2c0]
    1924:      	cmp	w8, #0x7e
    1928:      	b.hi	0x82c <perf_unwind_php+0x82c>
    192c:      	add	w9, w8, #0x1
    1930:      	mov	w10, w29
    1934:      	str	w9, [x21, #0x2c0]
    1938:      	mov	w9, #0x18               // =24
    193c:      	orr	x10, x10, x25, lsl #32
    1940:      	umaddl	x8, w8, w9, x21
    1944:      	ldr	x9, [sp, #0x70]
    1948:      	str	x10, [x8, #0x2d8]
    194c:      	str	x9, [x8, #0x2d0]
    1950:      	ldr	w9, [sp, #0xc]
    1954:      	strb	w9, [x8, #0x2e0]
    1958:      	add	x9, x8, #0x2d0
    195c:      	b	0x1210 <perf_unwind_php+0x1210>
    1960:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1964:      	add	x8, x8, #0x0
    1968:      	strb	wzr, [sp, #0x50]
    196c:      	add	x0, sp, #0x18
    1970:      	ldp	x9, x10, [x8, #0x20]
    1974:      	mov	w1, #0x39               // =57
    1978:      	stp	x9, x10, [sp, #0x38]
    197c:      	ldr	x9, [x8, #0x30]
    1980:      	str	x9, [sp, #0x48]
    1984:      	ldp	x9, x10, [x8]
    1988:      	stp	x9, x10, [sp, #0x18]
    198c:      	ldp	x8, x9, [x8, #0x10]
    1990:      	add	x10, sp, #0x18
    1994:      	stp	x8, x9, [sp, #0x28]
    1998:      	mov	w8, #0x39               // =57
    199c:      	mov	w9, #0x6                // =6
    19a0:      	ldr	x8, [sp, #0x68]
    19a4:      	ldrb	w10, [x24, #0x15]
    19a8:      	add	x2, x8, x10
    19ac:      	blr	x9
    19b0:      	mov	w25, #0x27              // =39
    19b4:      	b	0x354 <perf_unwind_php+0x354>
    19b8:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    19bc:      	add	x8, x8, #0x0
    19c0:      	strb	wzr, [sp, #0x48]
    19c4:      	add	x0, sp, #0x18
    19c8:      	ldp	x9, x10, [x8, #0x10]
    19cc:      	mov	w1, #0x31               // =49
    19d0:      	stp	x9, x10, [sp, #0x28]
    19d4:      	ldp	x9, x10, [x8, #0x20]
    19d8:      	stp	x9, x10, [sp, #0x38]
    19dc:      	ldp	x9, x8, [x8]
    19e0:      	add	x10, sp, #0x18
    19e4:      	stp	x9, x8, [sp, #0x18]
    19e8:      	mov	w8, #0x31               // =49
    19ec:      	mov	w9, #0x6                // =6
    19f0:      	ldr	x2, [sp, #0x70]
    19f4:      	blr	x9
    19f8:      	b	0x988 <perf_unwind_php+0x988>
    19fc:      	ldr	x8, [sp, #0x68]
    1a00:      	ldrb	w9, [x24, #0x15]
    1a04:      	mov	w10, #0x70              // =112
    1a08:      	add	x11, sp, #0x88
    1a0c:      	add	x0, sp, #0x88
    1a10:      	mov	w1, #0x4                // =4
    1a14:      	add	x8, x8, x9
    1a18:      	mov	w9, #0x4                // =4
    1a1c:      	ldr	x8, [sp, #0x68]
    1a20:      	ldrb	w9, [x24, #0x15]
    1a24:      	add	x2, x8, x9
    1a28:      	blr	x10
    1a2c:      	cbz	x0, 0x1bb8 <perf_unwind_php+0x1bb8>
    1a30:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1a34:      	ldr	x8, [x8]
    1a38:      	ldr	w8, [x8]
    1a3c:      	cbnz	w8, 0x283c <perf_unwind_php+0x283c>
    1a40:      	mov	w25, #0x27              // =39
    1a44:      	b	0x10e4 <perf_unwind_php+0x10e4>
    1a48:      	ldr	x8, [sp, #0x70]
    1a4c:      	cbz	x8, 0x1c38 <perf_unwind_php+0x1c38>
    1a50:      	ldrb	w9, [x24, #0x14]
    1a54:      	mov	w10, #0x70              // =112
    1a58:      	add	x11, sp, #0x8c
    1a5c:      	add	x0, sp, #0x8c
    1a60:      	mov	w1, #0x1                // =1
    1a64:      	add	x8, x8, x9
    1a68:      	mov	w9, #0x1                // =1
    1a6c:      	ldr	x8, [sp, #0x70]
    1a70:      	ldrb	w9, [x24, #0x14]
    1a74:      	add	x2, x8, x9
    1a78:      	blr	x10
    1a7c:      	cbz	x0, 0x1d68 <perf_unwind_php+0x1d68>
    1a80:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1a84:      	ldr	x8, [x8]
    1a88:      	ldr	w8, [x8]
    1a8c:      	cbnz	w8, 0x2894 <perf_unwind_php+0x2894>
    1a90:      	mov	w25, #0x26              // =38
    1a94:      	b	0x1674 <perf_unwind_php+0x1674>
    1a98:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1a9c:      	ldr	x8, [x8]
    1aa0:      	ldr	w8, [x8]
    1aa4:      	cbnz	w8, 0x2794 <perf_unwind_php+0x2794>
    1aa8:      	cmp	w25, #0x23
    1aac:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    1ab0:      	ldr	x8, [sp, #0x60]
    1ab4:      	ldrb	w9, [x24, #0x12]
    1ab8:      	mov	w10, #0x70              // =112
    1abc:      	add	x11, sp, #0x60
    1ac0:      	add	x0, sp, #0x60
    1ac4:      	mov	w1, #0x8                // =8
    1ac8:      	add	x8, x8, x9
    1acc:      	mov	w9, #0x8                // =8
    1ad0:      	ldr	x8, [sp, #0x60]
    1ad4:      	ldrb	w9, [x24, #0x12]
    1ad8:      	add	x2, x8, x9
    1adc:      	blr	x10
    1ae0:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    1ae4:      	ldr	x29, [x29]
    1ae8:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    1aec:      	ldr	x25, [sp, #0x60]
    1af0:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    1af4:      	ldrb	w8, [sp, #0x5e]
    1af8:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    1afc:      	ldrb	w8, [x24, #0x10]
    1b00:      	mov	w9, #0x8                // =8
    1b04:      	mov	w10, #0x70              // =112
    1b08:      	add	x11, sp, #0x70
    1b0c:      	add	x0, sp, #0x70
    1b10:      	mov	w1, #0x8                // =8
    1b14:      	add	x8, x25, x8
    1b18:      	ldrb	w8, [x24, #0x10]
    1b1c:      	add	x2, x25, x8
    1b20:      	blr	x10
    1b24:      	cbz	x0, 0x1fa4 <perf_unwind_php+0x1fa4>
    1b28:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1b2c:      	ldr	x8, [x8]
    1b30:      	ldr	w8, [x8]
    1b34:      	cbnz	w8, 0x2b18 <perf_unwind_php+0x2b18>
    1b38:      	mov	w25, #0x25              // =37
    1b3c:      	str	w25, [sp, #0x70]
    1b40:      	mov	w8, #0x1                // =1
    1b44:      	add	x9, sp, #0x70
    1b48:      	add	x1, sp, #0x70
    1b4c:      	mov	x0, x23
    1b50:      	blr	x8
    1b54:      	cbz	x0, 0x1ff4 <perf_unwind_php+0x1ff4>
    1b58:      	ldr	x8, [x0]
    1b5c:      	add	x8, x8, #0x1
    1b60:      	str	x8, [x0]
    1b64:      	cmp	w25, #0x23
    1b68:      	b.eq	0x200c <perf_unwind_php+0x200c>
    1b6c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    1b70:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1b74:      	add	x8, x8, #0x0
    1b78:      	add	x0, sp, #0x18
    1b7c:      	ldp	x9, x10, [x8, #0x20]
    1b80:      	mov	w1, #0x35               // =53
    1b84:      	mov	x2, x25
    1b88:      	stp	x9, x10, [sp, #0x38]
    1b8c:      	ldur	x9, [x8, #0x2d]
    1b90:      	stur	x9, [sp, #0x45]
    1b94:      	ldp	x9, x10, [x8]
    1b98:      	stp	x9, x10, [sp, #0x18]
    1b9c:      	ldp	x8, x9, [x8, #0x10]
    1ba0:      	add	x10, sp, #0x18
    1ba4:      	stp	x8, x9, [sp, #0x28]
    1ba8:      	mov	w8, #0x35               // =53
    1bac:      	mov	w9, #0x6                // =6
    1bb0:      	blr	x9
    1bb4:      	b	0xa8c <perf_unwind_php+0xa8c>
    1bb8:      	ldrb	w8, [x24, #0x13]
    1bbc:      	mov	w9, #0x4                // =4
    1bc0:      	mov	w10, #0x70              // =112
    1bc4:      	add	x11, sp, #0x5c
    1bc8:      	add	x0, sp, #0x5c
    1bcc:      	mov	w1, #0x4                // =4
    1bd0:      	add	x8, x25, x8
    1bd4:      	ldrb	w8, [x24, #0x13]
    1bd8:      	add	x2, x25, x8
    1bdc:      	blr	x10
    1be0:      	cbz	x0, 0x1e5c <perf_unwind_php+0x1e5c>
    1be4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1be8:      	ldr	x8, [x8]
    1bec:      	ldr	w8, [x8]
    1bf0:      	cbz	w8, 0x10e0 <perf_unwind_php+0x10e0>
    1bf4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1bf8:      	add	x8, x8, #0x0
    1bfc:      	add	x0, sp, #0x18
    1c00:      	ldp	x9, x10, [x8, #0x20]
    1c04:      	mov	w1, #0x35               // =53
    1c08:      	mov	x2, x25
    1c0c:      	stp	x9, x10, [sp, #0x38]
    1c10:      	ldur	x9, [x8, #0x2d]
    1c14:      	stur	x9, [sp, #0x45]
    1c18:      	ldp	x9, x10, [x8]
    1c1c:      	stp	x9, x10, [sp, #0x18]
    1c20:      	ldp	x8, x9, [x8, #0x10]
    1c24:      	add	x10, sp, #0x18
    1c28:      	stp	x8, x9, [sp, #0x28]
    1c2c:      	mov	w8, #0x35               // =53
    1c30:      	mov	w9, #0x6                // =6
    1c34:      	b	0x18b0 <perf_unwind_php+0x18b0>
    1c38:      	ldr	w8, [x21, #0x2c0]
    1c3c:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    1c40:      	ldr	x29, [x29]
    1c44:      	cmp	w8, #0x7e
    1c48:      	b.hi	0x394 <perf_unwind_php+0x394>
    1c4c:      	add	w9, w8, #0x1
    1c50:      	mov	x10, #-0x2              // =-2
    1c54:      	str	w9, [x21, #0x2c0]
    1c58:      	mov	w9, #0x18               // =24
    1c5c:      	umaddl	x8, w8, w9, x21
    1c60:      	add	x9, x8, #0x2d0
    1c64:      	str	x10, [x8, #0x2d8]
    1c68:      	mov	w10, #0x2               // =2
    1c6c:      	str	xzr, [x8, #0x2d0]
    1c70:      	strb	w10, [x8, #0x2e0]
    1c74:      	mov	w25, #0x23              // =35
    1c78:      	str	wzr, [x8, #0x2e4]
    1c7c:      	stur	wzr, [x9, #0x11]
    1c80:      	b	0x1674 <perf_unwind_php+0x1674>
    1c84:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1c88:      	add	x8, x8, #0x0
    1c8c:      	add	x0, sp, #0x18
    1c90:      	ldp	x9, x10, [x8, #0x10]
    1c94:      	mov	w1, #0x2d               // =45
    1c98:      	stp	x9, x10, [sp, #0x28]
    1c9c:      	ldr	x9, [x8, #0x20]
    1ca0:      	add	x10, sp, #0x18
    1ca4:      	str	x9, [sp, #0x38]
    1ca8:      	ldur	x9, [x8, #0x25]
    1cac:      	stur	x9, [sp, #0x3d]
    1cb0:      	ldp	x9, x8, [x8]
    1cb4:      	stp	x9, x8, [sp, #0x18]
    1cb8:      	mov	w8, #0x2d               // =45
    1cbc:      	mov	w9, #0x6                // =6
    1cc0:      	ldrb	w8, [x24, #0x11]
    1cc4:      	add	x2, x25, x8
    1cc8:      	blr	x9
    1ccc:      	b	0xd24 <perf_unwind_php+0xd24>
    1cd0:      	mov	w8, #0x2978             // =10616
    1cd4:      	add	x0, sp, #0x18
    1cd8:      	mov	w1, #0x33               // =51
    1cdc:      	movk	w8, #0xa, lsl #16
    1ce0:      	stur	w8, [sp, #0x47]
    1ce4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1ce8:      	add	x8, x8, #0x0
    1cec:      	ldp	x9, x10, [x8, #0x10]
    1cf0:      	stp	x9, x10, [sp, #0x28]
    1cf4:      	ldp	x9, x10, [x8, #0x20]
    1cf8:      	stp	x9, x10, [sp, #0x38]
    1cfc:      	ldp	x9, x8, [x8]
    1d00:      	add	x10, sp, #0x18
    1d04:      	stp	x9, x8, [sp, #0x18]
    1d08:      	mov	w8, #0x33               // =51
    1d0c:      	mov	w9, #0x6                // =6
    1d10:      	ldrb	w8, [x24, #0x10]
    1d14:      	add	x2, x25, x8
    1d18:      	blr	x9
    1d1c:      	b	0xa20 <perf_unwind_php+0xa20>
    1d20:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1d24:      	add	x8, x8, #0x0
    1d28:      	add	x0, sp, #0x18
    1d2c:      	ldp	x9, x10, [x8]
    1d30:      	ldur	x8, [x8, #0xe]
    1d34:      	mov	w1, #0x16               // =22
    1d38:      	stp	x9, x10, [sp, #0x18]
    1d3c:      	stur	x8, [sp, #0x26]
    1d40:      	mov	w8, #0x16               // =22
    1d44:      	mov	w9, #0x6                // =6
    1d48:      	add	x10, sp, #0x18
    1d4c:      	ldr	x2, [sp, #0x70]
    1d50:      	ldr	w3, [sp, #0x88]
    1d54:      	blr	x9
    1d58:      	ldr	w8, [x21, #0x2c0]
    1d5c:      	cmp	w8, #0x7e
    1d60:      	b.hi	0x82c <perf_unwind_php+0x82c>
    1d64:      	b	0x1414 <perf_unwind_php+0x1414>
    1d68:      	ldrb	w8, [sp, #0x8c]
    1d6c:      	str	wzr, [sp, #0x88]
    1d70:      	cmp	w8, #0x4
    1d74:      	b.eq	0x1d84 <perf_unwind_php+0x1d84>
    1d78:      	mov	w29, wzr
    1d7c:      	cmp	w8, #0x2
    1d80:      	b.ne	0x2328 <perf_unwind_php+0x2328>
    1d84:      	ldrb	w8, [x24, #0x11]
    1d88:      	mov	w9, #0x8                // =8
    1d8c:      	mov	w10, #0x70              // =112
    1d90:      	add	x11, sp, #0x68
    1d94:      	add	x0, sp, #0x68
    1d98:      	mov	w1, #0x8                // =8
    1d9c:      	add	x8, x25, x8
    1da0:      	ldrb	w8, [x24, #0x11]
    1da4:      	add	x2, x25, x8
    1da8:      	blr	x10
    1dac:      	cbz	x0, 0x1f58 <perf_unwind_php+0x1f58>
    1db0:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1db4:      	ldr	x8, [x8]
    1db8:      	ldr	w8, [x8]
    1dbc:      	cbz	w8, 0x1670 <perf_unwind_php+0x1670>
    1dc0:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1dc4:      	add	x8, x8, #0x0
    1dc8:      	add	x0, sp, #0x18
    1dcc:      	ldp	x9, x10, [x8, #0x10]
    1dd0:      	mov	w1, #0x2d               // =45
    1dd4:      	stp	x9, x10, [sp, #0x28]
    1dd8:      	ldr	x9, [x8, #0x20]
    1ddc:      	add	x10, sp, #0x18
    1de0:      	str	x9, [sp, #0x38]
    1de4:      	ldur	x9, [x8, #0x25]
    1de8:      	stur	x9, [sp, #0x3d]
    1dec:      	ldp	x9, x8, [x8]
    1df0:      	stp	x9, x8, [sp, #0x18]
    1df4:      	mov	w8, #0x2d               // =45
    1df8:      	mov	w9, #0x6                // =6
    1dfc:      	ldrb	w8, [x24, #0x11]
    1e00:      	add	x2, x25, x8
    1e04:      	blr	x9
    1e08:      	b	0x1670 <perf_unwind_php+0x1670>
    1e0c:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1e10:      	add	x8, x8, #0x0
    1e14:      	add	x0, sp, #0x18
    1e18:      	ldp	x9, x10, [x8, #0x10]
    1e1c:      	mov	w1, #0x2e               // =46
    1e20:      	stp	x9, x10, [sp, #0x28]
    1e24:      	ldr	x9, [x8, #0x20]
    1e28:      	add	x10, sp, #0x18
    1e2c:      	str	x9, [sp, #0x38]
    1e30:      	ldur	x9, [x8, #0x26]
    1e34:      	stur	x9, [sp, #0x3e]
    1e38:      	ldp	x9, x8, [x8]
    1e3c:      	stp	x9, x8, [sp, #0x18]
    1e40:      	mov	w8, #0x2e               // =46
    1e44:      	mov	w9, #0x6                // =6
    1e48:      	ldr	w2, [sp, #0x70]
    1e4c:      	blr	x9
    1e50:      	cmp	w25, #0x23
    1e54:      	b.eq	0x1058 <perf_unwind_php+0x1058>
    1e58:      	b	0x61f4 <perf_unwind_php+0x61f4>
    1e5c:      	ldr	w29, [sp, #0x88]
    1e60:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1e64:      	ldr	w25, [sp, #0x5c]
    1e68:      	ldr	x8, [x8]
    1e6c:      	ldr	w8, [x8]
    1e70:      	cbnz	w8, 0x26a8 <perf_unwind_php+0x26a8>
    1e74:      	ldr	w8, [x21, #0x2c0]
    1e78:      	cmp	w8, #0x7e
    1e7c:      	b.hi	0x82c <perf_unwind_php+0x82c>
    1e80:      	add	w9, w8, #0x1
    1e84:      	mov	w10, w29
    1e88:      	str	w9, [x21, #0x2c0]
    1e8c:      	mov	w9, #0x18               // =24
    1e90:      	orr	x10, x10, x25, lsl #32
    1e94:      	umaddl	x8, w8, w9, x21
    1e98:      	ldr	x9, [sp, #0x70]
    1e9c:      	str	x10, [x8, #0x2d8]
    1ea0:      	str	x9, [x8, #0x2d0]
    1ea4:      	ldr	w9, [sp, #0xc]
    1ea8:      	strb	w9, [x8, #0x2e0]
    1eac:      	add	x9, x8, #0x2d0
    1eb0:      	b	0x1764 <perf_unwind_php+0x1764>
    1eb4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1eb8:      	add	x8, x8, #0x0
    1ebc:      	strb	wzr, [sp, #0x50]
    1ec0:      	add	x0, sp, #0x18
    1ec4:      	ldp	x9, x10, [x8, #0x20]
    1ec8:      	mov	w1, #0x39               // =57
    1ecc:      	stp	x9, x10, [sp, #0x38]
    1ed0:      	ldr	x9, [x8, #0x30]
    1ed4:      	str	x9, [sp, #0x48]
    1ed8:      	ldp	x9, x10, [x8]
    1edc:      	stp	x9, x10, [sp, #0x18]
    1ee0:      	ldp	x8, x9, [x8, #0x10]
    1ee4:      	add	x10, sp, #0x18
    1ee8:      	stp	x8, x9, [sp, #0x28]
    1eec:      	mov	w8, #0x39               // =57
    1ef0:      	mov	w9, #0x6                // =6
    1ef4:      	ldr	x8, [sp, #0x68]
    1ef8:      	ldrb	w10, [x24, #0x15]
    1efc:      	add	x2, x8, x10
    1f00:      	blr	x9
    1f04:      	adrp	x29, 0x1000 <perf_unwind_php+0x1000>
    1f08:      	mov	w25, #0x27              // =39
    1f0c:      	ldr	x29, [x29]
    1f10:      	b	0x684 <perf_unwind_php+0x684>
    1f14:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1f18:      	add	x8, x8, #0x0
    1f1c:      	strb	wzr, [sp, #0x48]
    1f20:      	add	x0, sp, #0x18
    1f24:      	ldp	x9, x10, [x8, #0x10]
    1f28:      	mov	w1, #0x31               // =49
    1f2c:      	stp	x9, x10, [sp, #0x28]
    1f30:      	ldp	x9, x10, [x8, #0x20]
    1f34:      	stp	x9, x10, [sp, #0x38]
    1f38:      	ldp	x9, x8, [x8]
    1f3c:      	add	x10, sp, #0x18
    1f40:      	stp	x9, x8, [sp, #0x18]
    1f44:      	mov	w8, #0x31               // =49
    1f48:      	mov	w9, #0x6                // =6
    1f4c:      	ldr	x2, [sp, #0x70]
    1f50:      	blr	x9
    1f54:      	b	0xff0 <perf_unwind_php+0xff0>
    1f58:      	ldr	x8, [sp, #0x68]
    1f5c:      	ldrb	w9, [x24, #0x15]
    1f60:      	mov	w10, #0x70              // =112
    1f64:      	add	x11, sp, #0x88
    1f68:      	add	x0, sp, #0x88
    1f6c:      	mov	w1, #0x4                // =4
    1f70:      	add	x8, x8, x9
    1f74:      	mov	w9, #0x4                // =4
    1f78:      	ldr	x8, [sp, #0x68]
    1f7c:      	ldrb	w9, [x24, #0x15]
    1f80:      	add	x2, x8, x9
    1f84:      	blr	x10
    1f88:      	cbz	x0, 0x20cc <perf_unwind_php+0x20cc>
    1f8c:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1f90:      	ldr	x8, [x8]
    1f94:      	ldr	w8, [x8]
    1f98:      	cbnz	w8, 0x2cf8 <perf_unwind_php+0x2cf8>
    1f9c:      	mov	w25, #0x27              // =39
    1fa0:      	b	0x1674 <perf_unwind_php+0x1674>
    1fa4:      	ldr	x8, [sp, #0x70]
    1fa8:      	cbz	x8, 0x214c <perf_unwind_php+0x214c>
    1fac:      	ldrb	w9, [x24, #0x14]
    1fb0:      	mov	w10, #0x70              // =112
    1fb4:      	add	x11, sp, #0x8c
    1fb8:      	add	x0, sp, #0x8c
    1fbc:      	mov	w1, #0x1                // =1
    1fc0:      	add	x8, x8, x9
    1fc4:      	mov	w9, #0x1                // =1
    1fc8:      	ldr	x8, [sp, #0x70]
    1fcc:      	ldrb	w9, [x24, #0x14]
    1fd0:      	add	x2, x8, x9
    1fd4:      	blr	x10
    1fd8:      	cbz	x0, 0x2230 <perf_unwind_php+0x2230>
    1fdc:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1fe0:      	ldr	x8, [x8]
    1fe4:      	ldr	w8, [x8]
    1fe8:      	cbnz	w8, 0x2d50 <perf_unwind_php+0x2d50>
    1fec:      	mov	w25, #0x26              // =38
    1ff0:      	b	0x1b3c <perf_unwind_php+0x1b3c>
    1ff4:      	adrp	x8, 0x1000 <perf_unwind_php+0x1000>
    1ff8:      	ldr	x8, [x8]
    1ffc:      	ldr	w8, [x8]
    2000:      	cbnz	w8, 0x2c50 <perf_unwind_php+0x2c50>
    2004:      	cmp	w25, #0x23
    2008:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    200c:      	ldr	x8, [sp, #0x60]
    2010:      	ldrb	w9, [x24, #0x12]
    2014:      	mov	w10, #0x70              // =112
    2018:      	add	x11, sp, #0x60
    201c:      	add	x0, sp, #0x60
    2020:      	mov	w1, #0x8                // =8
    2024:      	add	x8, x8, x9
    2028:      	mov	w9, #0x8                // =8
    202c:      	ldr	x8, [sp, #0x60]
    2030:      	ldrb	w9, [x24, #0x12]
    2034:      	add	x2, x8, x9
    2038:      	blr	x10
    203c:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2040:      	ldr	x29, [x29]
    2044:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    2048:      	ldr	x25, [sp, #0x60]
    204c:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    2050:      	ldrb	w8, [sp, #0x5e]
    2054:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    2058:      	ldrb	w8, [x24, #0x10]
    205c:      	mov	w9, #0x8                // =8
    2060:      	mov	w10, #0x70              // =112
    2064:      	add	x11, sp, #0x70
    2068:      	add	x0, sp, #0x70
    206c:      	mov	w1, #0x8                // =8
    2070:      	add	x8, x25, x8
    2074:      	ldrb	w8, [x24, #0x10]
    2078:      	add	x2, x25, x8
    207c:      	blr	x10
    2080:      	cbz	x0, 0x2464 <perf_unwind_php+0x2464>
    2084:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2088:      	ldr	x8, [x8]
    208c:      	ldr	w8, [x8]
    2090:      	cbnz	w8, 0x2fd8 <perf_unwind_php+0x2fd8>
    2094:      	mov	w25, #0x25              // =37
    2098:      	str	w25, [sp, #0x70]
    209c:      	mov	w8, #0x1                // =1
    20a0:      	add	x9, sp, #0x70
    20a4:      	add	x1, sp, #0x70
    20a8:      	mov	x0, x23
    20ac:      	blr	x8
    20b0:      	cbz	x0, 0x24b4 <perf_unwind_php+0x24b4>
    20b4:      	ldr	x8, [x0]
    20b8:      	add	x8, x8, #0x1
    20bc:      	str	x8, [x0]
    20c0:      	cmp	w25, #0x23
    20c4:      	b.eq	0x24cc <perf_unwind_php+0x24cc>
    20c8:      	b	0x61f4 <perf_unwind_php+0x61f4>
    20cc:      	ldrb	w8, [x24, #0x13]
    20d0:      	mov	w9, #0x4                // =4
    20d4:      	mov	w10, #0x70              // =112
    20d8:      	add	x11, sp, #0x5c
    20dc:      	add	x0, sp, #0x5c
    20e0:      	mov	w1, #0x4                // =4
    20e4:      	add	x8, x25, x8
    20e8:      	ldrb	w8, [x24, #0x13]
    20ec:      	add	x2, x25, x8
    20f0:      	blr	x10
    20f4:      	cbz	x0, 0x2324 <perf_unwind_php+0x2324>
    20f8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    20fc:      	ldr	x8, [x8]
    2100:      	ldr	w8, [x8]
    2104:      	cbz	w8, 0x1670 <perf_unwind_php+0x1670>
    2108:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    210c:      	add	x8, x8, #0x0
    2110:      	add	x0, sp, #0x18
    2114:      	ldp	x9, x10, [x8, #0x20]
    2118:      	mov	w1, #0x35               // =53
    211c:      	mov	x2, x25
    2120:      	stp	x9, x10, [sp, #0x38]
    2124:      	ldur	x9, [x8, #0x2d]
    2128:      	stur	x9, [sp, #0x45]
    212c:      	ldp	x9, x10, [x8]
    2130:      	stp	x9, x10, [sp, #0x18]
    2134:      	ldp	x8, x9, [x8, #0x10]
    2138:      	add	x10, sp, #0x18
    213c:      	stp	x8, x9, [sp, #0x28]
    2140:      	mov	w8, #0x35               // =53
    2144:      	mov	w9, #0x6                // =6
    2148:      	b	0x1e04 <perf_unwind_php+0x1e04>
    214c:      	ldr	w8, [x21, #0x2c0]
    2150:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2154:      	ldr	x29, [x29]
    2158:      	cmp	w8, #0x7e
    215c:      	b.hi	0x394 <perf_unwind_php+0x394>
    2160:      	add	w9, w8, #0x1
    2164:      	mov	x10, #-0x2              // =-2
    2168:      	str	w9, [x21, #0x2c0]
    216c:      	mov	w9, #0x18               // =24
    2170:      	umaddl	x8, w8, w9, x21
    2174:      	add	x9, x8, #0x2d0
    2178:      	str	x10, [x8, #0x2d8]
    217c:      	mov	w10, #0x2               // =2
    2180:      	str	xzr, [x8, #0x2d0]
    2184:      	strb	w10, [x8, #0x2e0]
    2188:      	mov	w25, #0x23              // =35
    218c:      	str	wzr, [x8, #0x2e4]
    2190:      	stur	wzr, [x9, #0x11]
    2194:      	b	0x1b3c <perf_unwind_php+0x1b3c>
    2198:      	mov	w8, #0x2978             // =10616
    219c:      	add	x0, sp, #0x18
    21a0:      	mov	w1, #0x33               // =51
    21a4:      	movk	w8, #0xa, lsl #16
    21a8:      	stur	w8, [sp, #0x47]
    21ac:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    21b0:      	add	x8, x8, #0x0
    21b4:      	ldp	x9, x10, [x8, #0x10]
    21b8:      	stp	x9, x10, [sp, #0x28]
    21bc:      	ldp	x9, x10, [x8, #0x20]
    21c0:      	stp	x9, x10, [sp, #0x38]
    21c4:      	ldp	x9, x8, [x8]
    21c8:      	add	x10, sp, #0x18
    21cc:      	stp	x9, x8, [sp, #0x18]
    21d0:      	mov	w8, #0x33               // =51
    21d4:      	mov	w9, #0x6                // =6
    21d8:      	ldrb	w8, [x24, #0x10]
    21dc:      	add	x2, x25, x8
    21e0:      	blr	x9
    21e4:      	b	0x10e0 <perf_unwind_php+0x10e0>
    21e8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    21ec:      	add	x8, x8, #0x0
    21f0:      	add	x0, sp, #0x18
    21f4:      	ldp	x9, x10, [x8]
    21f8:      	ldur	x8, [x8, #0xe]
    21fc:      	mov	w1, #0x16               // =22
    2200:      	stp	x9, x10, [sp, #0x18]
    2204:      	stur	x8, [sp, #0x26]
    2208:      	mov	w8, #0x16               // =22
    220c:      	mov	w9, #0x6                // =6
    2210:      	add	x10, sp, #0x18
    2214:      	ldr	x2, [sp, #0x70]
    2218:      	ldr	w3, [sp, #0x88]
    221c:      	blr	x9
    2220:      	ldr	w8, [x21, #0x2c0]
    2224:      	cmp	w8, #0x7e
    2228:      	b.hi	0x82c <perf_unwind_php+0x82c>
    222c:      	b	0x192c <perf_unwind_php+0x192c>
    2230:      	ldrb	w8, [sp, #0x8c]
    2234:      	str	wzr, [sp, #0x88]
    2238:      	cmp	w8, #0x4
    223c:      	b.eq	0x224c <perf_unwind_php+0x224c>
    2240:      	mov	w29, wzr
    2244:      	cmp	w8, #0x2
    2248:      	b.ne	0x27e8 <perf_unwind_php+0x27e8>
    224c:      	ldrb	w8, [x24, #0x11]
    2250:      	mov	w9, #0x8                // =8
    2254:      	mov	w10, #0x70              // =112
    2258:      	add	x11, sp, #0x68
    225c:      	add	x0, sp, #0x68
    2260:      	mov	w1, #0x8                // =8
    2264:      	add	x8, x25, x8
    2268:      	ldrb	w8, [x24, #0x11]
    226c:      	add	x2, x25, x8
    2270:      	blr	x10
    2274:      	cbz	x0, 0x2418 <perf_unwind_php+0x2418>
    2278:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    227c:      	ldr	x8, [x8]
    2280:      	ldr	w8, [x8]
    2284:      	cbz	w8, 0x1b38 <perf_unwind_php+0x1b38>
    2288:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    228c:      	add	x8, x8, #0x0
    2290:      	add	x0, sp, #0x18
    2294:      	ldp	x9, x10, [x8, #0x10]
    2298:      	mov	w1, #0x2d               // =45
    229c:      	stp	x9, x10, [sp, #0x28]
    22a0:      	ldr	x9, [x8, #0x20]
    22a4:      	add	x10, sp, #0x18
    22a8:      	str	x9, [sp, #0x38]
    22ac:      	ldur	x9, [x8, #0x25]
    22b0:      	stur	x9, [sp, #0x3d]
    22b4:      	ldp	x9, x8, [x8]
    22b8:      	stp	x9, x8, [sp, #0x18]
    22bc:      	mov	w8, #0x2d               // =45
    22c0:      	mov	w9, #0x6                // =6
    22c4:      	ldrb	w8, [x24, #0x11]
    22c8:      	add	x2, x25, x8
    22cc:      	blr	x9
    22d0:      	b	0x1b38 <perf_unwind_php+0x1b38>
    22d4:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    22d8:      	add	x8, x8, #0x0
    22dc:      	add	x0, sp, #0x18
    22e0:      	ldp	x9, x10, [x8, #0x10]
    22e4:      	mov	w1, #0x2e               // =46
    22e8:      	stp	x9, x10, [sp, #0x28]
    22ec:      	ldr	x9, [x8, #0x20]
    22f0:      	add	x10, sp, #0x18
    22f4:      	str	x9, [sp, #0x38]
    22f8:      	ldur	x9, [x8, #0x26]
    22fc:      	stur	x9, [sp, #0x3e]
    2300:      	ldp	x9, x8, [x8]
    2304:      	stp	x9, x8, [sp, #0x18]
    2308:      	mov	w8, #0x2e               // =46
    230c:      	mov	w9, #0x6                // =6
    2310:      	ldr	w2, [sp, #0x70]
    2314:      	blr	x9
    2318:      	cmp	w25, #0x23
    231c:      	b.eq	0x15e8 <perf_unwind_php+0x15e8>
    2320:      	b	0x61f4 <perf_unwind_php+0x61f4>
    2324:      	ldr	w29, [sp, #0x88]
    2328:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    232c:      	ldr	w25, [sp, #0x5c]
    2330:      	ldr	x8, [x8]
    2334:      	ldr	w8, [x8]
    2338:      	cbnz	w8, 0x2b68 <perf_unwind_php+0x2b68>
    233c:      	ldr	w8, [x21, #0x2c0]
    2340:      	cmp	w8, #0x7e
    2344:      	b.hi	0x82c <perf_unwind_php+0x82c>
    2348:      	add	w9, w8, #0x1
    234c:      	mov	w10, w29
    2350:      	str	w9, [x21, #0x2c0]
    2354:      	mov	w9, #0x18               // =24
    2358:      	orr	x10, x10, x25, lsl #32
    235c:      	umaddl	x8, w8, w9, x21
    2360:      	ldr	x9, [sp, #0x70]
    2364:      	str	x10, [x8, #0x2d8]
    2368:      	str	x9, [x8, #0x2d0]
    236c:      	ldr	w9, [sp, #0xc]
    2370:      	strb	w9, [x8, #0x2e0]
    2374:      	add	x9, x8, #0x2d0
    2378:      	b	0x1c74 <perf_unwind_php+0x1c74>
    237c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2380:      	add	x8, x8, #0x0
    2384:      	strb	wzr, [sp, #0x50]
    2388:      	add	x0, sp, #0x18
    238c:      	ldp	x9, x10, [x8, #0x20]
    2390:      	mov	w1, #0x39               // =57
    2394:      	stp	x9, x10, [sp, #0x38]
    2398:      	ldr	x9, [x8, #0x30]
    239c:      	str	x9, [sp, #0x48]
    23a0:      	ldp	x9, x10, [x8]
    23a4:      	stp	x9, x10, [sp, #0x18]
    23a8:      	ldp	x8, x9, [x8, #0x10]
    23ac:      	add	x10, sp, #0x18
    23b0:      	stp	x8, x9, [sp, #0x28]
    23b4:      	mov	w8, #0x39               // =57
    23b8:      	mov	w9, #0x6                // =6
    23bc:      	ldr	x8, [sp, #0x68]
    23c0:      	ldrb	w10, [x24, #0x15]
    23c4:      	add	x2, x8, x10
    23c8:      	blr	x9
    23cc:      	mov	w25, #0x27              // =39
    23d0:      	b	0xa24 <perf_unwind_php+0xa24>
    23d4:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    23d8:      	add	x8, x8, #0x0
    23dc:      	strb	wzr, [sp, #0x48]
    23e0:      	add	x0, sp, #0x18
    23e4:      	ldp	x9, x10, [x8, #0x10]
    23e8:      	mov	w1, #0x31               // =49
    23ec:      	stp	x9, x10, [sp, #0x28]
    23f0:      	ldp	x9, x10, [x8, #0x20]
    23f4:      	stp	x9, x10, [sp, #0x38]
    23f8:      	ldp	x9, x8, [x8]
    23fc:      	add	x10, sp, #0x18
    2400:      	stp	x9, x8, [sp, #0x18]
    2404:      	mov	w8, #0x31               // =49
    2408:      	mov	w9, #0x6                // =6
    240c:      	ldr	x2, [sp, #0x70]
    2410:      	blr	x9
    2414:      	b	0x15c8 <perf_unwind_php+0x15c8>
    2418:      	ldr	x8, [sp, #0x68]
    241c:      	ldrb	w9, [x24, #0x15]
    2420:      	mov	w10, #0x70              // =112
    2424:      	add	x11, sp, #0x88
    2428:      	add	x0, sp, #0x88
    242c:      	mov	w1, #0x4                // =4
    2430:      	add	x8, x8, x9
    2434:      	mov	w9, #0x4                // =4
    2438:      	ldr	x8, [sp, #0x68]
    243c:      	ldrb	w9, [x24, #0x15]
    2440:      	add	x2, x8, x9
    2444:      	blr	x10
    2448:      	cbz	x0, 0x258c <perf_unwind_php+0x258c>
    244c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2450:      	ldr	x8, [x8]
    2454:      	ldr	w8, [x8]
    2458:      	cbnz	w8, 0x31b8 <perf_unwind_php+0x31b8>
    245c:      	mov	w25, #0x27              // =39
    2460:      	b	0x1b3c <perf_unwind_php+0x1b3c>
    2464:      	ldr	x8, [sp, #0x70]
    2468:      	cbz	x8, 0x260c <perf_unwind_php+0x260c>
    246c:      	ldrb	w9, [x24, #0x14]
    2470:      	mov	w10, #0x70              // =112
    2474:      	add	x11, sp, #0x8c
    2478:      	add	x0, sp, #0x8c
    247c:      	mov	w1, #0x1                // =1
    2480:      	add	x8, x8, x9
    2484:      	mov	w9, #0x1                // =1
    2488:      	ldr	x8, [sp, #0x70]
    248c:      	ldrb	w9, [x24, #0x14]
    2490:      	add	x2, x8, x9
    2494:      	blr	x10
    2498:      	cbz	x0, 0x26f0 <perf_unwind_php+0x26f0>
    249c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    24a0:      	ldr	x8, [x8]
    24a4:      	ldr	w8, [x8]
    24a8:      	cbnz	w8, 0x3210 <perf_unwind_php+0x3210>
    24ac:      	mov	w25, #0x26              // =38
    24b0:      	b	0x2098 <perf_unwind_php+0x2098>
    24b4:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    24b8:      	ldr	x8, [x8]
    24bc:      	ldr	w8, [x8]
    24c0:      	cbnz	w8, 0x3110 <perf_unwind_php+0x3110>
    24c4:      	cmp	w25, #0x23
    24c8:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    24cc:      	ldr	x8, [sp, #0x60]
    24d0:      	ldrb	w9, [x24, #0x12]
    24d4:      	mov	w10, #0x70              // =112
    24d8:      	add	x11, sp, #0x60
    24dc:      	add	x0, sp, #0x60
    24e0:      	mov	w1, #0x8                // =8
    24e4:      	add	x8, x8, x9
    24e8:      	mov	w9, #0x8                // =8
    24ec:      	ldr	x8, [sp, #0x60]
    24f0:      	ldrb	w9, [x24, #0x12]
    24f4:      	add	x2, x8, x9
    24f8:      	blr	x10
    24fc:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2500:      	ldr	x29, [x29]
    2504:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    2508:      	ldr	x25, [sp, #0x60]
    250c:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    2510:      	ldrb	w8, [sp, #0x5e]
    2514:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    2518:      	ldrb	w8, [x24, #0x10]
    251c:      	mov	w9, #0x8                // =8
    2520:      	mov	w10, #0x70              // =112
    2524:      	add	x11, sp, #0x70
    2528:      	add	x0, sp, #0x70
    252c:      	mov	w1, #0x8                // =8
    2530:      	add	x8, x25, x8
    2534:      	ldrb	w8, [x24, #0x10]
    2538:      	add	x2, x25, x8
    253c:      	blr	x10
    2540:      	cbz	x0, 0x2924 <perf_unwind_php+0x2924>
    2544:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2548:      	ldr	x8, [x8]
    254c:      	ldr	w8, [x8]
    2550:      	cbnz	w8, 0x3498 <perf_unwind_php+0x3498>
    2554:      	mov	w25, #0x25              // =37
    2558:      	str	w25, [sp, #0x70]
    255c:      	mov	w8, #0x1                // =1
    2560:      	add	x9, sp, #0x70
    2564:      	add	x1, sp, #0x70
    2568:      	mov	x0, x23
    256c:      	blr	x8
    2570:      	cbz	x0, 0x2974 <perf_unwind_php+0x2974>
    2574:      	ldr	x8, [x0]
    2578:      	add	x8, x8, #0x1
    257c:      	str	x8, [x0]
    2580:      	cmp	w25, #0x23
    2584:      	b.eq	0x298c <perf_unwind_php+0x298c>
    2588:      	b	0x61f4 <perf_unwind_php+0x61f4>
    258c:      	ldrb	w8, [x24, #0x13]
    2590:      	mov	w9, #0x4                // =4
    2594:      	mov	w10, #0x70              // =112
    2598:      	add	x11, sp, #0x5c
    259c:      	add	x0, sp, #0x5c
    25a0:      	mov	w1, #0x4                // =4
    25a4:      	add	x8, x25, x8
    25a8:      	ldrb	w8, [x24, #0x13]
    25ac:      	add	x2, x25, x8
    25b0:      	blr	x10
    25b4:      	cbz	x0, 0x27e4 <perf_unwind_php+0x27e4>
    25b8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    25bc:      	ldr	x8, [x8]
    25c0:      	ldr	w8, [x8]
    25c4:      	cbz	w8, 0x1b38 <perf_unwind_php+0x1b38>
    25c8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    25cc:      	add	x8, x8, #0x0
    25d0:      	add	x0, sp, #0x18
    25d4:      	ldp	x9, x10, [x8, #0x20]
    25d8:      	mov	w1, #0x35               // =53
    25dc:      	mov	x2, x25
    25e0:      	stp	x9, x10, [sp, #0x38]
    25e4:      	ldur	x9, [x8, #0x2d]
    25e8:      	stur	x9, [sp, #0x45]
    25ec:      	ldp	x9, x10, [x8]
    25f0:      	stp	x9, x10, [sp, #0x18]
    25f4:      	ldp	x8, x9, [x8, #0x10]
    25f8:      	add	x10, sp, #0x18
    25fc:      	stp	x8, x9, [sp, #0x28]
    2600:      	mov	w8, #0x35               // =53
    2604:      	mov	w9, #0x6                // =6
    2608:      	b	0x22cc <perf_unwind_php+0x22cc>
    260c:      	ldr	w8, [x21, #0x2c0]
    2610:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2614:      	ldr	x29, [x29]
    2618:      	cmp	w8, #0x7e
    261c:      	b.hi	0x394 <perf_unwind_php+0x394>
    2620:      	add	w9, w8, #0x1
    2624:      	mov	x10, #-0x2              // =-2
    2628:      	str	w9, [x21, #0x2c0]
    262c:      	mov	w9, #0x18               // =24
    2630:      	umaddl	x8, w8, w9, x21
    2634:      	add	x9, x8, #0x2d0
    2638:      	str	x10, [x8, #0x2d8]
    263c:      	mov	w10, #0x2               // =2
    2640:      	str	xzr, [x8, #0x2d0]
    2644:      	strb	w10, [x8, #0x2e0]
    2648:      	mov	w25, #0x23              // =35
    264c:      	str	wzr, [x8, #0x2e4]
    2650:      	stur	wzr, [x9, #0x11]
    2654:      	b	0x2098 <perf_unwind_php+0x2098>
    2658:      	mov	w8, #0x2978             // =10616
    265c:      	add	x0, sp, #0x18
    2660:      	mov	w1, #0x33               // =51
    2664:      	movk	w8, #0xa, lsl #16
    2668:      	stur	w8, [sp, #0x47]
    266c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2670:      	add	x8, x8, #0x0
    2674:      	ldp	x9, x10, [x8, #0x10]
    2678:      	stp	x9, x10, [sp, #0x28]
    267c:      	ldp	x9, x10, [x8, #0x20]
    2680:      	stp	x9, x10, [sp, #0x38]
    2684:      	ldp	x9, x8, [x8]
    2688:      	add	x10, sp, #0x18
    268c:      	stp	x9, x8, [sp, #0x18]
    2690:      	mov	w8, #0x33               // =51
    2694:      	mov	w9, #0x6                // =6
    2698:      	ldrb	w8, [x24, #0x10]
    269c:      	add	x2, x25, x8
    26a0:      	blr	x9
    26a4:      	b	0x1670 <perf_unwind_php+0x1670>
    26a8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    26ac:      	add	x8, x8, #0x0
    26b0:      	add	x0, sp, #0x18
    26b4:      	ldp	x9, x10, [x8]
    26b8:      	ldur	x8, [x8, #0xe]
    26bc:      	mov	w1, #0x16               // =22
    26c0:      	stp	x9, x10, [sp, #0x18]
    26c4:      	stur	x8, [sp, #0x26]
    26c8:      	mov	w8, #0x16               // =22
    26cc:      	mov	w9, #0x6                // =6
    26d0:      	add	x10, sp, #0x18
    26d4:      	ldr	x2, [sp, #0x70]
    26d8:      	ldr	w3, [sp, #0x88]
    26dc:      	blr	x9
    26e0:      	ldr	w8, [x21, #0x2c0]
    26e4:      	cmp	w8, #0x7e
    26e8:      	b.hi	0x82c <perf_unwind_php+0x82c>
    26ec:      	b	0x1e80 <perf_unwind_php+0x1e80>
    26f0:      	ldrb	w8, [sp, #0x8c]
    26f4:      	str	wzr, [sp, #0x88]
    26f8:      	cmp	w8, #0x4
    26fc:      	b.eq	0x270c <perf_unwind_php+0x270c>
    2700:      	mov	w29, wzr
    2704:      	cmp	w8, #0x2
    2708:      	b.ne	0x2ca4 <perf_unwind_php+0x2ca4>
    270c:      	ldrb	w8, [x24, #0x11]
    2710:      	mov	w9, #0x8                // =8
    2714:      	mov	w10, #0x70              // =112
    2718:      	add	x11, sp, #0x68
    271c:      	add	x0, sp, #0x68
    2720:      	mov	w1, #0x8                // =8
    2724:      	add	x8, x25, x8
    2728:      	ldrb	w8, [x24, #0x11]
    272c:      	add	x2, x25, x8
    2730:      	blr	x10
    2734:      	cbz	x0, 0x28d8 <perf_unwind_php+0x28d8>
    2738:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    273c:      	ldr	x8, [x8]
    2740:      	ldr	w8, [x8]
    2744:      	cbz	w8, 0x2094 <perf_unwind_php+0x2094>
    2748:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    274c:      	add	x8, x8, #0x0
    2750:      	add	x0, sp, #0x18
    2754:      	ldp	x9, x10, [x8, #0x10]
    2758:      	mov	w1, #0x2d               // =45
    275c:      	stp	x9, x10, [sp, #0x28]
    2760:      	ldr	x9, [x8, #0x20]
    2764:      	add	x10, sp, #0x18
    2768:      	str	x9, [sp, #0x38]
    276c:      	ldur	x9, [x8, #0x25]
    2770:      	stur	x9, [sp, #0x3d]
    2774:      	ldp	x9, x8, [x8]
    2778:      	stp	x9, x8, [sp, #0x18]
    277c:      	mov	w8, #0x2d               // =45
    2780:      	mov	w9, #0x6                // =6
    2784:      	ldrb	w8, [x24, #0x11]
    2788:      	add	x2, x25, x8
    278c:      	blr	x9
    2790:      	b	0x2094 <perf_unwind_php+0x2094>
    2794:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2798:      	add	x8, x8, #0x0
    279c:      	add	x0, sp, #0x18
    27a0:      	ldp	x9, x10, [x8, #0x10]
    27a4:      	mov	w1, #0x2e               // =46
    27a8:      	stp	x9, x10, [sp, #0x28]
    27ac:      	ldr	x9, [x8, #0x20]
    27b0:      	add	x10, sp, #0x18
    27b4:      	str	x9, [sp, #0x38]
    27b8:      	ldur	x9, [x8, #0x26]
    27bc:      	stur	x9, [sp, #0x3e]
    27c0:      	ldp	x9, x8, [x8]
    27c4:      	stp	x9, x8, [sp, #0x18]
    27c8:      	mov	w8, #0x2e               // =46
    27cc:      	mov	w9, #0x6                // =6
    27d0:      	ldr	w2, [sp, #0x70]
    27d4:      	blr	x9
    27d8:      	cmp	w25, #0x23
    27dc:      	b.eq	0x1ab0 <perf_unwind_php+0x1ab0>
    27e0:      	b	0x61f4 <perf_unwind_php+0x61f4>
    27e4:      	ldr	w29, [sp, #0x88]
    27e8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    27ec:      	ldr	w25, [sp, #0x5c]
    27f0:      	ldr	x8, [x8]
    27f4:      	ldr	w8, [x8]
    27f8:      	cbnz	w8, 0x3028 <perf_unwind_php+0x3028>
    27fc:      	ldr	w8, [x21, #0x2c0]
    2800:      	cmp	w8, #0x7e
    2804:      	b.hi	0x82c <perf_unwind_php+0x82c>
    2808:      	add	w9, w8, #0x1
    280c:      	mov	w10, w29
    2810:      	str	w9, [x21, #0x2c0]
    2814:      	mov	w9, #0x18               // =24
    2818:      	orr	x10, x10, x25, lsl #32
    281c:      	umaddl	x8, w8, w9, x21
    2820:      	ldr	x9, [sp, #0x70]
    2824:      	str	x10, [x8, #0x2d8]
    2828:      	str	x9, [x8, #0x2d0]
    282c:      	ldr	w9, [sp, #0xc]
    2830:      	strb	w9, [x8, #0x2e0]
    2834:      	add	x9, x8, #0x2d0
    2838:      	b	0x2188 <perf_unwind_php+0x2188>
    283c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2840:      	add	x8, x8, #0x0
    2844:      	strb	wzr, [sp, #0x50]
    2848:      	add	x0, sp, #0x18
    284c:      	ldp	x9, x10, [x8, #0x20]
    2850:      	mov	w1, #0x39               // =57
    2854:      	stp	x9, x10, [sp, #0x38]
    2858:      	ldr	x9, [x8, #0x30]
    285c:      	str	x9, [sp, #0x48]
    2860:      	ldp	x9, x10, [x8]
    2864:      	stp	x9, x10, [sp, #0x18]
    2868:      	ldp	x8, x9, [x8, #0x10]
    286c:      	add	x10, sp, #0x18
    2870:      	stp	x8, x9, [sp, #0x28]
    2874:      	mov	w8, #0x39               // =57
    2878:      	mov	w9, #0x6                // =6
    287c:      	ldr	x8, [sp, #0x68]
    2880:      	ldrb	w10, [x24, #0x15]
    2884:      	add	x2, x8, x10
    2888:      	blr	x9
    288c:      	mov	w25, #0x27              // =39
    2890:      	b	0x10e4 <perf_unwind_php+0x10e4>
    2894:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2898:      	add	x8, x8, #0x0
    289c:      	strb	wzr, [sp, #0x48]
    28a0:      	add	x0, sp, #0x18
    28a4:      	ldp	x9, x10, [x8, #0x10]
    28a8:      	mov	w1, #0x31               // =49
    28ac:      	stp	x9, x10, [sp, #0x28]
    28b0:      	ldp	x9, x10, [x8, #0x20]
    28b4:      	stp	x9, x10, [sp, #0x38]
    28b8:      	ldp	x9, x8, [x8]
    28bc:      	add	x10, sp, #0x18
    28c0:      	stp	x9, x8, [sp, #0x18]
    28c4:      	mov	w8, #0x31               // =49
    28c8:      	mov	w9, #0x6                // =6
    28cc:      	ldr	x2, [sp, #0x70]
    28d0:      	blr	x9
    28d4:      	b	0x1a90 <perf_unwind_php+0x1a90>
    28d8:      	ldr	x8, [sp, #0x68]
    28dc:      	ldrb	w9, [x24, #0x15]
    28e0:      	mov	w10, #0x70              // =112
    28e4:      	add	x11, sp, #0x88
    28e8:      	add	x0, sp, #0x88
    28ec:      	mov	w1, #0x4                // =4
    28f0:      	add	x8, x8, x9
    28f4:      	mov	w9, #0x4                // =4
    28f8:      	ldr	x8, [sp, #0x68]
    28fc:      	ldrb	w9, [x24, #0x15]
    2900:      	add	x2, x8, x9
    2904:      	blr	x10
    2908:      	cbz	x0, 0x2a4c <perf_unwind_php+0x2a4c>
    290c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2910:      	ldr	x8, [x8]
    2914:      	ldr	w8, [x8]
    2918:      	cbnz	w8, 0x3678 <perf_unwind_php+0x3678>
    291c:      	mov	w25, #0x27              // =39
    2920:      	b	0x2098 <perf_unwind_php+0x2098>
    2924:      	ldr	x8, [sp, #0x70]
    2928:      	cbz	x8, 0x2acc <perf_unwind_php+0x2acc>
    292c:      	ldrb	w9, [x24, #0x14]
    2930:      	mov	w10, #0x70              // =112
    2934:      	add	x11, sp, #0x8c
    2938:      	add	x0, sp, #0x8c
    293c:      	mov	w1, #0x1                // =1
    2940:      	add	x8, x8, x9
    2944:      	mov	w9, #0x1                // =1
    2948:      	ldr	x8, [sp, #0x70]
    294c:      	ldrb	w9, [x24, #0x14]
    2950:      	add	x2, x8, x9
    2954:      	blr	x10
    2958:      	cbz	x0, 0x2bb0 <perf_unwind_php+0x2bb0>
    295c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2960:      	ldr	x8, [x8]
    2964:      	ldr	w8, [x8]
    2968:      	cbnz	w8, 0x36d0 <perf_unwind_php+0x36d0>
    296c:      	mov	w25, #0x26              // =38
    2970:      	b	0x2558 <perf_unwind_php+0x2558>
    2974:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2978:      	ldr	x8, [x8]
    297c:      	ldr	w8, [x8]
    2980:      	cbnz	w8, 0x35d0 <perf_unwind_php+0x35d0>
    2984:      	cmp	w25, #0x23
    2988:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    298c:      	ldr	x8, [sp, #0x60]
    2990:      	ldrb	w9, [x24, #0x12]
    2994:      	mov	w10, #0x70              // =112
    2998:      	add	x11, sp, #0x60
    299c:      	add	x0, sp, #0x60
    29a0:      	mov	w1, #0x8                // =8
    29a4:      	add	x8, x8, x9
    29a8:      	mov	w9, #0x8                // =8
    29ac:      	ldr	x8, [sp, #0x60]
    29b0:      	ldrb	w9, [x24, #0x12]
    29b4:      	add	x2, x8, x9
    29b8:      	blr	x10
    29bc:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    29c0:      	ldr	x29, [x29]
    29c4:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    29c8:      	ldr	x25, [sp, #0x60]
    29cc:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    29d0:      	ldrb	w8, [sp, #0x5e]
    29d4:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    29d8:      	ldrb	w8, [x24, #0x10]
    29dc:      	mov	w9, #0x8                // =8
    29e0:      	mov	w10, #0x70              // =112
    29e4:      	add	x11, sp, #0x70
    29e8:      	add	x0, sp, #0x70
    29ec:      	mov	w1, #0x8                // =8
    29f0:      	add	x8, x25, x8
    29f4:      	ldrb	w8, [x24, #0x10]
    29f8:      	add	x2, x25, x8
    29fc:      	blr	x10
    2a00:      	cbz	x0, 0x2de0 <perf_unwind_php+0x2de0>
    2a04:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2a08:      	ldr	x8, [x8]
    2a0c:      	ldr	w8, [x8]
    2a10:      	cbnz	w8, 0x39a8 <perf_unwind_php+0x39a8>
    2a14:      	mov	w25, #0x25              // =37
    2a18:      	str	w25, [sp, #0x70]
    2a1c:      	mov	w8, #0x1                // =1
    2a20:      	add	x9, sp, #0x70
    2a24:      	add	x1, sp, #0x70
    2a28:      	mov	x0, x23
    2a2c:      	blr	x8
    2a30:      	cbz	x0, 0x2e30 <perf_unwind_php+0x2e30>
    2a34:      	ldr	x8, [x0]
    2a38:      	add	x8, x8, #0x1
    2a3c:      	str	x8, [x0]
    2a40:      	cmp	w25, #0x23
    2a44:      	b.eq	0x2e48 <perf_unwind_php+0x2e48>
    2a48:      	b	0x61f4 <perf_unwind_php+0x61f4>
    2a4c:      	ldrb	w8, [x24, #0x13]
    2a50:      	mov	w9, #0x4                // =4
    2a54:      	mov	w10, #0x70              // =112
    2a58:      	add	x11, sp, #0x5c
    2a5c:      	add	x0, sp, #0x5c
    2a60:      	mov	w1, #0x4                // =4
    2a64:      	add	x8, x25, x8
    2a68:      	ldrb	w8, [x24, #0x13]
    2a6c:      	add	x2, x25, x8
    2a70:      	blr	x10
    2a74:      	cbz	x0, 0x2ca0 <perf_unwind_php+0x2ca0>
    2a78:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2a7c:      	ldr	x8, [x8]
    2a80:      	ldr	w8, [x8]
    2a84:      	cbz	w8, 0x2094 <perf_unwind_php+0x2094>
    2a88:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2a8c:      	add	x8, x8, #0x0
    2a90:      	add	x0, sp, #0x18
    2a94:      	ldp	x9, x10, [x8, #0x20]
    2a98:      	mov	w1, #0x35               // =53
    2a9c:      	mov	x2, x25
    2aa0:      	stp	x9, x10, [sp, #0x38]
    2aa4:      	ldur	x9, [x8, #0x2d]
    2aa8:      	stur	x9, [sp, #0x45]
    2aac:      	ldp	x9, x10, [x8]
    2ab0:      	stp	x9, x10, [sp, #0x18]
    2ab4:      	ldp	x8, x9, [x8, #0x10]
    2ab8:      	add	x10, sp, #0x18
    2abc:      	stp	x8, x9, [sp, #0x28]
    2ac0:      	mov	w8, #0x35               // =53
    2ac4:      	mov	w9, #0x6                // =6
    2ac8:      	b	0x278c <perf_unwind_php+0x278c>
    2acc:      	ldr	w8, [x21, #0x2c0]
    2ad0:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2ad4:      	ldr	x29, [x29]
    2ad8:      	cmp	w8, #0x7e
    2adc:      	b.hi	0x394 <perf_unwind_php+0x394>
    2ae0:      	add	w9, w8, #0x1
    2ae4:      	mov	x10, #-0x2              // =-2
    2ae8:      	str	w9, [x21, #0x2c0]
    2aec:      	mov	w9, #0x18               // =24
    2af0:      	umaddl	x8, w8, w9, x21
    2af4:      	add	x9, x8, #0x2d0
    2af8:      	str	x10, [x8, #0x2d8]
    2afc:      	mov	w10, #0x2               // =2
    2b00:      	str	xzr, [x8, #0x2d0]
    2b04:      	strb	w10, [x8, #0x2e0]
    2b08:      	mov	w25, #0x23              // =35
    2b0c:      	str	wzr, [x8, #0x2e4]
    2b10:      	stur	wzr, [x9, #0x11]
    2b14:      	b	0x2558 <perf_unwind_php+0x2558>
    2b18:      	mov	w8, #0x2978             // =10616
    2b1c:      	add	x0, sp, #0x18
    2b20:      	mov	w1, #0x33               // =51
    2b24:      	movk	w8, #0xa, lsl #16
    2b28:      	stur	w8, [sp, #0x47]
    2b2c:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2b30:      	add	x8, x8, #0x0
    2b34:      	ldp	x9, x10, [x8, #0x10]
    2b38:      	stp	x9, x10, [sp, #0x28]
    2b3c:      	ldp	x9, x10, [x8, #0x20]
    2b40:      	stp	x9, x10, [sp, #0x38]
    2b44:      	ldp	x9, x8, [x8]
    2b48:      	add	x10, sp, #0x18
    2b4c:      	stp	x9, x8, [sp, #0x18]
    2b50:      	mov	w8, #0x33               // =51
    2b54:      	mov	w9, #0x6                // =6
    2b58:      	ldrb	w8, [x24, #0x10]
    2b5c:      	add	x2, x25, x8
    2b60:      	blr	x9
    2b64:      	b	0x1b38 <perf_unwind_php+0x1b38>
    2b68:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2b6c:      	add	x8, x8, #0x0
    2b70:      	add	x0, sp, #0x18
    2b74:      	ldp	x9, x10, [x8]
    2b78:      	ldur	x8, [x8, #0xe]
    2b7c:      	mov	w1, #0x16               // =22
    2b80:      	stp	x9, x10, [sp, #0x18]
    2b84:      	stur	x8, [sp, #0x26]
    2b88:      	mov	w8, #0x16               // =22
    2b8c:      	mov	w9, #0x6                // =6
    2b90:      	add	x10, sp, #0x18
    2b94:      	ldr	x2, [sp, #0x70]
    2b98:      	ldr	w3, [sp, #0x88]
    2b9c:      	blr	x9
    2ba0:      	ldr	w8, [x21, #0x2c0]
    2ba4:      	cmp	w8, #0x7e
    2ba8:      	b.hi	0x82c <perf_unwind_php+0x82c>
    2bac:      	b	0x2348 <perf_unwind_php+0x2348>
    2bb0:      	ldrb	w8, [sp, #0x8c]
    2bb4:      	str	wzr, [sp, #0x88]
    2bb8:      	cmp	w8, #0x4
    2bbc:      	b.eq	0x2bcc <perf_unwind_php+0x2bcc>
    2bc0:      	mov	w29, wzr
    2bc4:      	cmp	w8, #0x2
    2bc8:      	b.ne	0x3164 <perf_unwind_php+0x3164>
    2bcc:      	ldrb	w8, [x24, #0x11]
    2bd0:      	mov	w9, #0x8                // =8
    2bd4:      	mov	w10, #0x70              // =112
    2bd8:      	add	x11, sp, #0x68
    2bdc:      	add	x0, sp, #0x68
    2be0:      	mov	w1, #0x8                // =8
    2be4:      	add	x8, x25, x8
    2be8:      	ldrb	w8, [x24, #0x11]
    2bec:      	add	x2, x25, x8
    2bf0:      	blr	x10
    2bf4:      	cbz	x0, 0x2d94 <perf_unwind_php+0x2d94>
    2bf8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2bfc:      	ldr	x8, [x8]
    2c00:      	ldr	w8, [x8]
    2c04:      	cbz	w8, 0x2554 <perf_unwind_php+0x2554>
    2c08:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2c0c:      	add	x8, x8, #0x0
    2c10:      	add	x0, sp, #0x18
    2c14:      	ldp	x9, x10, [x8, #0x10]
    2c18:      	mov	w1, #0x2d               // =45
    2c1c:      	stp	x9, x10, [sp, #0x28]
    2c20:      	ldr	x9, [x8, #0x20]
    2c24:      	add	x10, sp, #0x18
    2c28:      	str	x9, [sp, #0x38]
    2c2c:      	ldur	x9, [x8, #0x25]
    2c30:      	stur	x9, [sp, #0x3d]
    2c34:      	ldp	x9, x8, [x8]
    2c38:      	stp	x9, x8, [sp, #0x18]
    2c3c:      	mov	w8, #0x2d               // =45
    2c40:      	mov	w9, #0x6                // =6
    2c44:      	ldrb	w8, [x24, #0x11]
    2c48:      	add	x2, x25, x8
    2c4c:      	b	0x2f84 <perf_unwind_php+0x2f84>
    2c50:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2c54:      	add	x8, x8, #0x0
    2c58:      	add	x0, sp, #0x18
    2c5c:      	ldp	x9, x10, [x8, #0x10]
    2c60:      	mov	w1, #0x2e               // =46
    2c64:      	stp	x9, x10, [sp, #0x28]
    2c68:      	ldr	x9, [x8, #0x20]
    2c6c:      	add	x10, sp, #0x18
    2c70:      	str	x9, [sp, #0x38]
    2c74:      	ldur	x9, [x8, #0x26]
    2c78:      	stur	x9, [sp, #0x3e]
    2c7c:      	ldp	x9, x8, [x8]
    2c80:      	stp	x9, x8, [sp, #0x18]
    2c84:      	mov	w8, #0x2e               // =46
    2c88:      	mov	w9, #0x6                // =6
    2c8c:      	ldr	w2, [sp, #0x70]
    2c90:      	blr	x9
    2c94:      	cmp	w25, #0x23
    2c98:      	b.eq	0x200c <perf_unwind_php+0x200c>
    2c9c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    2ca0:      	ldr	w29, [sp, #0x88]
    2ca4:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2ca8:      	ldr	w25, [sp, #0x5c]
    2cac:      	ldr	x8, [x8]
    2cb0:      	ldr	w8, [x8]
    2cb4:      	cbnz	w8, 0x34e8 <perf_unwind_php+0x34e8>
    2cb8:      	ldr	w8, [x21, #0x2c0]
    2cbc:      	cmp	w8, #0x7e
    2cc0:      	b.hi	0x82c <perf_unwind_php+0x82c>
    2cc4:      	add	w9, w8, #0x1
    2cc8:      	mov	w10, w29
    2ccc:      	str	w9, [x21, #0x2c0]
    2cd0:      	mov	w9, #0x18               // =24
    2cd4:      	orr	x10, x10, x25, lsl #32
    2cd8:      	umaddl	x8, w8, w9, x21
    2cdc:      	ldr	x9, [sp, #0x70]
    2ce0:      	str	x10, [x8, #0x2d8]
    2ce4:      	str	x9, [x8, #0x2d0]
    2ce8:      	ldr	w9, [sp, #0xc]
    2cec:      	strb	w9, [x8, #0x2e0]
    2cf0:      	add	x9, x8, #0x2d0
    2cf4:      	b	0x2648 <perf_unwind_php+0x2648>
    2cf8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2cfc:      	add	x8, x8, #0x0
    2d00:      	strb	wzr, [sp, #0x50]
    2d04:      	add	x0, sp, #0x18
    2d08:      	ldp	x9, x10, [x8, #0x20]
    2d0c:      	mov	w1, #0x39               // =57
    2d10:      	stp	x9, x10, [sp, #0x38]
    2d14:      	ldr	x9, [x8, #0x30]
    2d18:      	str	x9, [sp, #0x48]
    2d1c:      	ldp	x9, x10, [x8]
    2d20:      	stp	x9, x10, [sp, #0x18]
    2d24:      	ldp	x8, x9, [x8, #0x10]
    2d28:      	add	x10, sp, #0x18
    2d2c:      	stp	x8, x9, [sp, #0x28]
    2d30:      	mov	w8, #0x39               // =57
    2d34:      	mov	w9, #0x6                // =6
    2d38:      	ldr	x8, [sp, #0x68]
    2d3c:      	ldrb	w10, [x24, #0x15]
    2d40:      	add	x2, x8, x10
    2d44:      	blr	x9
    2d48:      	mov	w25, #0x27              // =39
    2d4c:      	b	0x1674 <perf_unwind_php+0x1674>
    2d50:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2d54:      	add	x8, x8, #0x0
    2d58:      	strb	wzr, [sp, #0x48]
    2d5c:      	add	x0, sp, #0x18
    2d60:      	ldp	x9, x10, [x8, #0x10]
    2d64:      	mov	w1, #0x31               // =49
    2d68:      	stp	x9, x10, [sp, #0x28]
    2d6c:      	ldp	x9, x10, [x8, #0x20]
    2d70:      	stp	x9, x10, [sp, #0x38]
    2d74:      	ldp	x9, x8, [x8]
    2d78:      	add	x10, sp, #0x18
    2d7c:      	stp	x9, x8, [sp, #0x18]
    2d80:      	mov	w8, #0x31               // =49
    2d84:      	mov	w9, #0x6                // =6
    2d88:      	ldr	x2, [sp, #0x70]
    2d8c:      	blr	x9
    2d90:      	b	0x1fec <perf_unwind_php+0x1fec>
    2d94:      	ldr	x8, [sp, #0x68]
    2d98:      	ldrb	w9, [x24, #0x15]
    2d9c:      	mov	w10, #0x70              // =112
    2da0:      	add	x11, sp, #0x88
    2da4:      	add	x0, sp, #0x88
    2da8:      	mov	w1, #0x4                // =4
    2dac:      	add	x8, x8, x9
    2db0:      	mov	w9, #0x4                // =4
    2db4:      	ldr	x8, [sp, #0x68]
    2db8:      	ldrb	w9, [x24, #0x15]
    2dbc:      	add	x2, x8, x9
    2dc0:      	blr	x10
    2dc4:      	cbz	x0, 0x2f08 <perf_unwind_php+0x2f08>
    2dc8:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2dcc:      	ldr	x8, [x8]
    2dd0:      	ldr	w8, [x8]
    2dd4:      	cbnz	w8, 0x3b88 <perf_unwind_php+0x3b88>
    2dd8:      	mov	w25, #0x27              // =39
    2ddc:      	b	0x2558 <perf_unwind_php+0x2558>
    2de0:      	ldr	x8, [sp, #0x70]
    2de4:      	cbz	x8, 0x2f8c <perf_unwind_php+0x2f8c>
    2de8:      	ldrb	w9, [x24, #0x14]
    2dec:      	mov	w10, #0x70              // =112
    2df0:      	add	x11, sp, #0x8c
    2df4:      	add	x0, sp, #0x8c
    2df8:      	mov	w1, #0x1                // =1
    2dfc:      	add	x8, x8, x9
    2e00:      	mov	w9, #0x1                // =1
    2e04:      	ldr	x8, [sp, #0x70]
    2e08:      	ldrb	w9, [x24, #0x14]
    2e0c:      	add	x2, x8, x9
    2e10:      	blr	x10
    2e14:      	cbz	x0, 0x3070 <perf_unwind_php+0x3070>
    2e18:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2e1c:      	ldr	x8, [x8]
    2e20:      	ldr	w8, [x8]
    2e24:      	cbnz	w8, 0x3be0 <perf_unwind_php+0x3be0>
    2e28:      	mov	w25, #0x26              // =38
    2e2c:      	b	0x2a18 <perf_unwind_php+0x2a18>
    2e30:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2e34:      	ldr	x8, [x8]
    2e38:      	ldr	w8, [x8]
    2e3c:      	cbnz	w8, 0x3ae0 <perf_unwind_php+0x3ae0>
    2e40:      	cmp	w25, #0x23
    2e44:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    2e48:      	ldr	x8, [sp, #0x60]
    2e4c:      	ldrb	w9, [x24, #0x12]
    2e50:      	mov	w10, #0x70              // =112
    2e54:      	add	x11, sp, #0x60
    2e58:      	add	x0, sp, #0x60
    2e5c:      	mov	w1, #0x8                // =8
    2e60:      	add	x8, x8, x9
    2e64:      	mov	w9, #0x8                // =8
    2e68:      	ldr	x8, [sp, #0x60]
    2e6c:      	ldrb	w9, [x24, #0x12]
    2e70:      	add	x2, x8, x9
    2e74:      	blr	x10
    2e78:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2e7c:      	ldr	x29, [x29]
    2e80:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    2e84:      	ldr	x25, [sp, #0x60]
    2e88:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    2e8c:      	ldrb	w8, [sp, #0x5e]
    2e90:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    2e94:      	ldrb	w8, [x24, #0x10]
    2e98:      	mov	w9, #0x8                // =8
    2e9c:      	mov	w10, #0x70              // =112
    2ea0:      	add	x11, sp, #0x70
    2ea4:      	add	x0, sp, #0x70
    2ea8:      	mov	w1, #0x8                // =8
    2eac:      	add	x8, x25, x8
    2eb0:      	ldrb	w8, [x24, #0x10]
    2eb4:      	add	x2, x25, x8
    2eb8:      	blr	x10
    2ebc:      	cbz	x0, 0x32a0 <perf_unwind_php+0x32a0>
    2ec0:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2ec4:      	ldr	x8, [x8]
    2ec8:      	ldr	w8, [x8]
    2ecc:      	cbnz	w8, 0x3c24 <perf_unwind_php+0x3c24>
    2ed0:      	mov	w25, #0x25              // =37
    2ed4:      	str	w25, [sp, #0x70]
    2ed8:      	mov	w8, #0x1                // =1
    2edc:      	add	x9, sp, #0x70
    2ee0:      	add	x1, sp, #0x70
    2ee4:      	mov	x0, x23
    2ee8:      	blr	x8
    2eec:      	cbz	x0, 0x32f0 <perf_unwind_php+0x32f0>
    2ef0:      	ldr	x8, [x0]
    2ef4:      	add	x8, x8, #0x1
    2ef8:      	str	x8, [x0]
    2efc:      	cmp	w25, #0x23
    2f00:      	b.eq	0x3308 <perf_unwind_php+0x3308>
    2f04:      	b	0x61f4 <perf_unwind_php+0x61f4>
    2f08:      	ldrb	w8, [x24, #0x13]
    2f0c:      	mov	w9, #0x4                // =4
    2f10:      	mov	w10, #0x70              // =112
    2f14:      	add	x11, sp, #0x5c
    2f18:      	add	x0, sp, #0x5c
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x25, x8
    2f24:      	ldrb	w8, [x24, #0x13]
    2f28:      	add	x2, x25, x8
    2f2c:      	blr	x10
    2f30:      	cbz	x0, 0x3160 <perf_unwind_php+0x3160>
    2f34:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2f38:      	ldr	x8, [x8]
    2f3c:      	ldr	w8, [x8]
    2f40:      	cbz	w8, 0x2554 <perf_unwind_php+0x2554>
    2f44:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2f48:      	add	x8, x8, #0x0
    2f4c:      	add	x0, sp, #0x18
    2f50:      	ldp	x9, x10, [x8, #0x20]
    2f54:      	mov	w1, #0x35               // =53
    2f58:      	mov	x2, x25
    2f5c:      	stp	x9, x10, [sp, #0x38]
    2f60:      	ldur	x9, [x8, #0x2d]
    2f64:      	stur	x9, [sp, #0x45]
    2f68:      	ldp	x9, x10, [x8]
    2f6c:      	stp	x9, x10, [sp, #0x18]
    2f70:      	ldp	x8, x9, [x8, #0x10]
    2f74:      	add	x10, sp, #0x18
    2f78:      	stp	x8, x9, [sp, #0x28]
    2f7c:      	mov	w8, #0x35               // =53
    2f80:      	mov	w9, #0x6                // =6
    2f84:      	blr	x9
    2f88:      	b	0x2554 <perf_unwind_php+0x2554>
    2f8c:      	ldr	w8, [x21, #0x2c0]
    2f90:      	adrp	x29, 0x2000 <perf_unwind_php+0x2000>
    2f94:      	ldr	x29, [x29]
    2f98:      	cmp	w8, #0x7e
    2f9c:      	b.hi	0x394 <perf_unwind_php+0x394>
    2fa0:      	add	w9, w8, #0x1
    2fa4:      	mov	x10, #-0x2              // =-2
    2fa8:      	str	w9, [x21, #0x2c0]
    2fac:      	mov	w9, #0x18               // =24
    2fb0:      	umaddl	x8, w8, w9, x21
    2fb4:      	add	x9, x8, #0x2d0
    2fb8:      	str	x10, [x8, #0x2d8]
    2fbc:      	mov	w10, #0x2               // =2
    2fc0:      	str	xzr, [x8, #0x2d0]
    2fc4:      	strb	w10, [x8, #0x2e0]
    2fc8:      	mov	w25, #0x23              // =35
    2fcc:      	str	wzr, [x8, #0x2e4]
    2fd0:      	stur	wzr, [x9, #0x11]
    2fd4:      	b	0x2a18 <perf_unwind_php+0x2a18>
    2fd8:      	mov	w8, #0x2978             // =10616
    2fdc:      	add	x0, sp, #0x18
    2fe0:      	mov	w1, #0x33               // =51
    2fe4:      	movk	w8, #0xa, lsl #16
    2fe8:      	stur	w8, [sp, #0x47]
    2fec:      	adrp	x8, 0x2000 <perf_unwind_php+0x2000>
    2ff0:      	add	x8, x8, #0x0
    2ff4:      	ldp	x9, x10, [x8, #0x10]
    2ff8:      	stp	x9, x10, [sp, #0x28]
    2ffc:      	ldp	x9, x10, [x8, #0x20]
    3000:      	stp	x9, x10, [sp, #0x38]
    3004:      	ldp	x9, x8, [x8]
    3008:      	add	x10, sp, #0x18
    300c:      	stp	x9, x8, [sp, #0x18]
    3010:      	mov	w8, #0x33               // =51
    3014:      	mov	w9, #0x6                // =6
    3018:      	ldrb	w8, [x24, #0x10]
    301c:      	add	x2, x25, x8
    3020:      	blr	x9
    3024:      	b	0x2094 <perf_unwind_php+0x2094>
    3028:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    302c:      	add	x8, x8, #0x0
    3030:      	add	x0, sp, #0x18
    3034:      	ldp	x9, x10, [x8]
    3038:      	ldur	x8, [x8, #0xe]
    303c:      	mov	w1, #0x16               // =22
    3040:      	stp	x9, x10, [sp, #0x18]
    3044:      	stur	x8, [sp, #0x26]
    3048:      	mov	w8, #0x16               // =22
    304c:      	mov	w9, #0x6                // =6
    3050:      	add	x10, sp, #0x18
    3054:      	ldr	x2, [sp, #0x70]
    3058:      	ldr	w3, [sp, #0x88]
    305c:      	blr	x9
    3060:      	ldr	w8, [x21, #0x2c0]
    3064:      	cmp	w8, #0x7e
    3068:      	b.hi	0x82c <perf_unwind_php+0x82c>
    306c:      	b	0x2808 <perf_unwind_php+0x2808>
    3070:      	ldrb	w8, [sp, #0x8c]
    3074:      	str	wzr, [sp, #0x88]
    3078:      	cmp	w8, #0x4
    307c:      	b.eq	0x308c <perf_unwind_php+0x308c>
    3080:      	mov	w29, wzr
    3084:      	cmp	w8, #0x2
    3088:      	b.ne	0x3624 <perf_unwind_php+0x3624>
    308c:      	ldrb	w8, [x24, #0x11]
    3090:      	mov	w9, #0x8                // =8
    3094:      	mov	w10, #0x70              // =112
    3098:      	add	x11, sp, #0x68
    309c:      	add	x0, sp, #0x68
    30a0:      	mov	w1, #0x8                // =8
    30a4:      	add	x8, x25, x8
    30a8:      	ldrb	w8, [x24, #0x11]
    30ac:      	add	x2, x25, x8
    30b0:      	blr	x10
    30b4:      	cbz	x0, 0x3254 <perf_unwind_php+0x3254>
    30b8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    30bc:      	ldr	x8, [x8]
    30c0:      	ldr	w8, [x8]
    30c4:      	cbz	w8, 0x2a14 <perf_unwind_php+0x2a14>
    30c8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    30cc:      	add	x8, x8, #0x0
    30d0:      	add	x0, sp, #0x18
    30d4:      	ldp	x9, x10, [x8, #0x10]
    30d8:      	mov	w1, #0x2d               // =45
    30dc:      	stp	x9, x10, [sp, #0x28]
    30e0:      	ldr	x9, [x8, #0x20]
    30e4:      	add	x10, sp, #0x18
    30e8:      	str	x9, [sp, #0x38]
    30ec:      	ldur	x9, [x8, #0x25]
    30f0:      	stur	x9, [sp, #0x3d]
    30f4:      	ldp	x9, x8, [x8]
    30f8:      	stp	x9, x8, [sp, #0x18]
    30fc:      	mov	w8, #0x2d               // =45
    3100:      	mov	w9, #0x6                // =6
    3104:      	ldrb	w8, [x24, #0x11]
    3108:      	add	x2, x25, x8
    310c:      	b	0x3444 <perf_unwind_php+0x3444>
    3110:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3114:      	add	x8, x8, #0x0
    3118:      	add	x0, sp, #0x18
    311c:      	ldp	x9, x10, [x8, #0x10]
    3120:      	mov	w1, #0x2e               // =46
    3124:      	stp	x9, x10, [sp, #0x28]
    3128:      	ldr	x9, [x8, #0x20]
    312c:      	add	x10, sp, #0x18
    3130:      	str	x9, [sp, #0x38]
    3134:      	ldur	x9, [x8, #0x26]
    3138:      	stur	x9, [sp, #0x3e]
    313c:      	ldp	x9, x8, [x8]
    3140:      	stp	x9, x8, [sp, #0x18]
    3144:      	mov	w8, #0x2e               // =46
    3148:      	mov	w9, #0x6                // =6
    314c:      	ldr	w2, [sp, #0x70]
    3150:      	blr	x9
    3154:      	cmp	w25, #0x23
    3158:      	b.eq	0x24cc <perf_unwind_php+0x24cc>
    315c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    3160:      	ldr	w29, [sp, #0x88]
    3164:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3168:      	ldr	w25, [sp, #0x5c]
    316c:      	ldr	x8, [x8]
    3170:      	ldr	w8, [x8]
    3174:      	cbnz	w8, 0x39f8 <perf_unwind_php+0x39f8>
    3178:      	ldr	w8, [x21, #0x2c0]
    317c:      	cmp	w8, #0x7e
    3180:      	b.hi	0x82c <perf_unwind_php+0x82c>
    3184:      	add	w9, w8, #0x1
    3188:      	mov	w10, w29
    318c:      	str	w9, [x21, #0x2c0]
    3190:      	mov	w9, #0x18               // =24
    3194:      	orr	x10, x10, x25, lsl #32
    3198:      	umaddl	x8, w8, w9, x21
    319c:      	ldr	x9, [sp, #0x70]
    31a0:      	str	x10, [x8, #0x2d8]
    31a4:      	str	x9, [x8, #0x2d0]
    31a8:      	ldr	w9, [sp, #0xc]
    31ac:      	strb	w9, [x8, #0x2e0]
    31b0:      	add	x9, x8, #0x2d0
    31b4:      	b	0x2b08 <perf_unwind_php+0x2b08>
    31b8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    31bc:      	add	x8, x8, #0x0
    31c0:      	strb	wzr, [sp, #0x50]
    31c4:      	add	x0, sp, #0x18
    31c8:      	ldp	x9, x10, [x8, #0x20]
    31cc:      	mov	w1, #0x39               // =57
    31d0:      	stp	x9, x10, [sp, #0x38]
    31d4:      	ldr	x9, [x8, #0x30]
    31d8:      	str	x9, [sp, #0x48]
    31dc:      	ldp	x9, x10, [x8]
    31e0:      	stp	x9, x10, [sp, #0x18]
    31e4:      	ldp	x8, x9, [x8, #0x10]
    31e8:      	add	x10, sp, #0x18
    31ec:      	stp	x8, x9, [sp, #0x28]
    31f0:      	mov	w8, #0x39               // =57
    31f4:      	mov	w9, #0x6                // =6
    31f8:      	ldr	x8, [sp, #0x68]
    31fc:      	ldrb	w10, [x24, #0x15]
    3200:      	add	x2, x8, x10
    3204:      	blr	x9
    3208:      	mov	w25, #0x27              // =39
    320c:      	b	0x1b3c <perf_unwind_php+0x1b3c>
    3210:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3214:      	add	x8, x8, #0x0
    3218:      	strb	wzr, [sp, #0x48]
    321c:      	add	x0, sp, #0x18
    3220:      	ldp	x9, x10, [x8, #0x10]
    3224:      	mov	w1, #0x31               // =49
    3228:      	stp	x9, x10, [sp, #0x28]
    322c:      	ldp	x9, x10, [x8, #0x20]
    3230:      	stp	x9, x10, [sp, #0x38]
    3234:      	ldp	x9, x8, [x8]
    3238:      	add	x10, sp, #0x18
    323c:      	stp	x9, x8, [sp, #0x18]
    3240:      	mov	w8, #0x31               // =49
    3244:      	mov	w9, #0x6                // =6
    3248:      	ldr	x2, [sp, #0x70]
    324c:      	blr	x9
    3250:      	b	0x24ac <perf_unwind_php+0x24ac>
    3254:      	ldr	x8, [sp, #0x68]
    3258:      	ldrb	w9, [x24, #0x15]
    325c:      	mov	w10, #0x70              // =112
    3260:      	add	x11, sp, #0x88
    3264:      	add	x0, sp, #0x88
    3268:      	mov	w1, #0x4                // =4
    326c:      	add	x8, x8, x9
    3270:      	mov	w9, #0x4                // =4
    3274:      	ldr	x8, [sp, #0x68]
    3278:      	ldrb	w9, [x24, #0x15]
    327c:      	add	x2, x8, x9
    3280:      	blr	x10
    3284:      	cbz	x0, 0x33c8 <perf_unwind_php+0x33c8>
    3288:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    328c:      	ldr	x8, [x8]
    3290:      	ldr	w8, [x8]
    3294:      	cbnz	w8, 0x3c74 <perf_unwind_php+0x3c74>
    3298:      	mov	w25, #0x27              // =39
    329c:      	b	0x2a18 <perf_unwind_php+0x2a18>
    32a0:      	ldr	x8, [sp, #0x70]
    32a4:      	cbz	x8, 0x344c <perf_unwind_php+0x344c>
    32a8:      	ldrb	w9, [x24, #0x14]
    32ac:      	mov	w10, #0x70              // =112
    32b0:      	add	x11, sp, #0x8c
    32b4:      	add	x0, sp, #0x8c
    32b8:      	mov	w1, #0x1                // =1
    32bc:      	add	x8, x8, x9
    32c0:      	mov	w9, #0x1                // =1
    32c4:      	ldr	x8, [sp, #0x70]
    32c8:      	ldrb	w9, [x24, #0x14]
    32cc:      	add	x2, x8, x9
    32d0:      	blr	x10
    32d4:      	cbz	x0, 0x3530 <perf_unwind_php+0x3530>
    32d8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    32dc:      	ldr	x8, [x8]
    32e0:      	ldr	w8, [x8]
    32e4:      	cbnz	w8, 0x3ccc <perf_unwind_php+0x3ccc>
    32e8:      	mov	w25, #0x26              // =38
    32ec:      	b	0x2ed4 <perf_unwind_php+0x2ed4>
    32f0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    32f4:      	ldr	x8, [x8]
    32f8:      	ldr	w8, [x8]
    32fc:      	cbnz	w8, 0x3d10 <perf_unwind_php+0x3d10>
    3300:      	cmp	w25, #0x23
    3304:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    3308:      	ldr	x8, [sp, #0x60]
    330c:      	ldrb	w9, [x24, #0x12]
    3310:      	mov	w10, #0x70              // =112
    3314:      	add	x11, sp, #0x60
    3318:      	add	x0, sp, #0x60
    331c:      	mov	w1, #0x8                // =8
    3320:      	add	x8, x8, x9
    3324:      	mov	w9, #0x8                // =8
    3328:      	ldr	x8, [sp, #0x60]
    332c:      	ldrb	w9, [x24, #0x12]
    3330:      	add	x2, x8, x9
    3334:      	blr	x10
    3338:      	adrp	x29, 0x3000 <perf_unwind_php+0x3000>
    333c:      	ldr	x29, [x29]
    3340:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    3344:      	ldr	x25, [sp, #0x60]
    3348:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    334c:      	ldrb	w8, [sp, #0x5e]
    3350:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    3354:      	ldrb	w8, [x24, #0x10]
    3358:      	mov	w9, #0x8                // =8
    335c:      	mov	w10, #0x70              // =112
    3360:      	add	x11, sp, #0x70
    3364:      	add	x0, sp, #0x70
    3368:      	mov	w1, #0x8                // =8
    336c:      	add	x8, x25, x8
    3370:      	ldrb	w8, [x24, #0x10]
    3374:      	add	x2, x25, x8
    3378:      	blr	x10
    337c:      	cbz	x0, 0x3760 <perf_unwind_php+0x3760>
    3380:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3384:      	ldr	x8, [x8]
    3388:      	ldr	w8, [x8]
    338c:      	cbnz	w8, 0x3d60 <perf_unwind_php+0x3d60>
    3390:      	mov	w25, #0x25              // =37
    3394:      	str	w25, [sp, #0x70]
    3398:      	mov	w8, #0x1                // =1
    339c:      	add	x9, sp, #0x70
    33a0:      	add	x1, sp, #0x70
    33a4:      	mov	x0, x23
    33a8:      	blr	x8
    33ac:      	cbz	x0, 0x37f0 <perf_unwind_php+0x37f0>
    33b0:      	ldr	x8, [x0]
    33b4:      	add	x8, x8, #0x1
    33b8:      	str	x8, [x0]
    33bc:      	cmp	w25, #0x23
    33c0:      	b.eq	0x3808 <perf_unwind_php+0x3808>
    33c4:      	b	0x61f4 <perf_unwind_php+0x61f4>
    33c8:      	ldrb	w8, [x24, #0x13]
    33cc:      	mov	w9, #0x4                // =4
    33d0:      	mov	w10, #0x70              // =112
    33d4:      	add	x11, sp, #0x5c
    33d8:      	add	x0, sp, #0x5c
    33dc:      	mov	w1, #0x4                // =4
    33e0:      	add	x8, x25, x8
    33e4:      	ldrb	w8, [x24, #0x13]
    33e8:      	add	x2, x25, x8
    33ec:      	blr	x10
    33f0:      	cbz	x0, 0x3620 <perf_unwind_php+0x3620>
    33f4:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    33f8:      	ldr	x8, [x8]
    33fc:      	ldr	w8, [x8]
    3400:      	cbz	w8, 0x2a14 <perf_unwind_php+0x2a14>
    3404:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3408:      	add	x8, x8, #0x0
    340c:      	add	x0, sp, #0x18
    3410:      	ldp	x9, x10, [x8, #0x20]
    3414:      	mov	w1, #0x35               // =53
    3418:      	mov	x2, x25
    341c:      	stp	x9, x10, [sp, #0x38]
    3420:      	ldur	x9, [x8, #0x2d]
    3424:      	stur	x9, [sp, #0x45]
    3428:      	ldp	x9, x10, [x8]
    342c:      	stp	x9, x10, [sp, #0x18]
    3430:      	ldp	x8, x9, [x8, #0x10]
    3434:      	add	x10, sp, #0x18
    3438:      	stp	x8, x9, [sp, #0x28]
    343c:      	mov	w8, #0x35               // =53
    3440:      	mov	w9, #0x6                // =6
    3444:      	blr	x9
    3448:      	b	0x2a14 <perf_unwind_php+0x2a14>
    344c:      	ldr	w8, [x21, #0x2c0]
    3450:      	adrp	x29, 0x3000 <perf_unwind_php+0x3000>
    3454:      	ldr	x29, [x29]
    3458:      	cmp	w8, #0x7e
    345c:      	b.hi	0x394 <perf_unwind_php+0x394>
    3460:      	add	w9, w8, #0x1
    3464:      	mov	x10, #-0x2              // =-2
    3468:      	str	w9, [x21, #0x2c0]
    346c:      	mov	w9, #0x18               // =24
    3470:      	umaddl	x8, w8, w9, x21
    3474:      	add	x9, x8, #0x2d0
    3478:      	str	x10, [x8, #0x2d8]
    347c:      	mov	w10, #0x2               // =2
    3480:      	str	xzr, [x8, #0x2d0]
    3484:      	strb	w10, [x8, #0x2e0]
    3488:      	mov	w25, #0x23              // =35
    348c:      	str	wzr, [x8, #0x2e4]
    3490:      	stur	wzr, [x9, #0x11]
    3494:      	b	0x2ed4 <perf_unwind_php+0x2ed4>
    3498:      	mov	w8, #0x2978             // =10616
    349c:      	add	x0, sp, #0x18
    34a0:      	mov	w1, #0x33               // =51
    34a4:      	movk	w8, #0xa, lsl #16
    34a8:      	stur	w8, [sp, #0x47]
    34ac:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    34b0:      	add	x8, x8, #0x0
    34b4:      	ldp	x9, x10, [x8, #0x10]
    34b8:      	stp	x9, x10, [sp, #0x28]
    34bc:      	ldp	x9, x10, [x8, #0x20]
    34c0:      	stp	x9, x10, [sp, #0x38]
    34c4:      	ldp	x9, x8, [x8]
    34c8:      	add	x10, sp, #0x18
    34cc:      	stp	x9, x8, [sp, #0x18]
    34d0:      	mov	w8, #0x33               // =51
    34d4:      	mov	w9, #0x6                // =6
    34d8:      	ldrb	w8, [x24, #0x10]
    34dc:      	add	x2, x25, x8
    34e0:      	blr	x9
    34e4:      	b	0x2554 <perf_unwind_php+0x2554>
    34e8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    34ec:      	add	x8, x8, #0x0
    34f0:      	add	x0, sp, #0x18
    34f4:      	ldp	x9, x10, [x8]
    34f8:      	ldur	x8, [x8, #0xe]
    34fc:      	mov	w1, #0x16               // =22
    3500:      	stp	x9, x10, [sp, #0x18]
    3504:      	stur	x8, [sp, #0x26]
    3508:      	mov	w8, #0x16               // =22
    350c:      	mov	w9, #0x6                // =6
    3510:      	add	x10, sp, #0x18
    3514:      	ldr	x2, [sp, #0x70]
    3518:      	ldr	w3, [sp, #0x88]
    351c:      	blr	x9
    3520:      	ldr	w8, [x21, #0x2c0]
    3524:      	cmp	w8, #0x7e
    3528:      	b.hi	0x82c <perf_unwind_php+0x82c>
    352c:      	b	0x2cc4 <perf_unwind_php+0x2cc4>
    3530:      	ldrb	w8, [sp, #0x8c]
    3534:      	str	wzr, [sp, #0x88]
    3538:      	cmp	w8, #0x4
    353c:      	b.eq	0x354c <perf_unwind_php+0x354c>
    3540:      	mov	w29, wzr
    3544:      	cmp	w8, #0x2
    3548:      	b.ne	0x3b34 <perf_unwind_php+0x3b34>
    354c:      	ldrb	w8, [x24, #0x11]
    3550:      	mov	w9, #0x8                // =8
    3554:      	mov	w10, #0x70              // =112
    3558:      	add	x11, sp, #0x68
    355c:      	add	x0, sp, #0x68
    3560:      	mov	w1, #0x8                // =8
    3564:      	add	x8, x25, x8
    3568:      	ldrb	w8, [x24, #0x11]
    356c:      	add	x2, x25, x8
    3570:      	blr	x10
    3574:      	cbz	x0, 0x3714 <perf_unwind_php+0x3714>
    3578:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    357c:      	ldr	x8, [x8]
    3580:      	ldr	w8, [x8]
    3584:      	cbz	w8, 0x2ed0 <perf_unwind_php+0x2ed0>
    3588:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    358c:      	add	x8, x8, #0x0
    3590:      	add	x0, sp, #0x18
    3594:      	ldp	x9, x10, [x8, #0x10]
    3598:      	mov	w1, #0x2d               // =45
    359c:      	stp	x9, x10, [sp, #0x28]
    35a0:      	ldr	x9, [x8, #0x20]
    35a4:      	add	x10, sp, #0x18
    35a8:      	str	x9, [sp, #0x38]
    35ac:      	ldur	x9, [x8, #0x25]
    35b0:      	stur	x9, [sp, #0x3d]
    35b4:      	ldp	x9, x8, [x8]
    35b8:      	stp	x9, x8, [sp, #0x18]
    35bc:      	mov	w8, #0x2d               // =45
    35c0:      	mov	w9, #0x6                // =6
    35c4:      	ldrb	w8, [x24, #0x11]
    35c8:      	add	x2, x25, x8
    35cc:      	b	0x3960 <perf_unwind_php+0x3960>
    35d0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    35d4:      	add	x8, x8, #0x0
    35d8:      	add	x0, sp, #0x18
    35dc:      	ldp	x9, x10, [x8, #0x10]
    35e0:      	mov	w1, #0x2e               // =46
    35e4:      	stp	x9, x10, [sp, #0x28]
    35e8:      	ldr	x9, [x8, #0x20]
    35ec:      	add	x10, sp, #0x18
    35f0:      	str	x9, [sp, #0x38]
    35f4:      	ldur	x9, [x8, #0x26]
    35f8:      	stur	x9, [sp, #0x3e]
    35fc:      	ldp	x9, x8, [x8]
    3600:      	stp	x9, x8, [sp, #0x18]
    3604:      	mov	w8, #0x2e               // =46
    3608:      	mov	w9, #0x6                // =6
    360c:      	ldr	w2, [sp, #0x70]
    3610:      	blr	x9
    3614:      	cmp	w25, #0x23
    3618:      	b.eq	0x298c <perf_unwind_php+0x298c>
    361c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    3620:      	ldr	w29, [sp, #0x88]
    3624:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3628:      	ldr	w25, [sp, #0x5c]
    362c:      	ldr	x8, [x8]
    3630:      	ldr	w8, [x8]
    3634:      	cbnz	w8, 0x3db0 <perf_unwind_php+0x3db0>
    3638:      	ldr	w8, [x21, #0x2c0]
    363c:      	cmp	w8, #0x7e
    3640:      	b.hi	0x82c <perf_unwind_php+0x82c>
    3644:      	add	w9, w8, #0x1
    3648:      	mov	w10, w29
    364c:      	str	w9, [x21, #0x2c0]
    3650:      	mov	w9, #0x18               // =24
    3654:      	orr	x10, x10, x25, lsl #32
    3658:      	umaddl	x8, w8, w9, x21
    365c:      	ldr	x9, [sp, #0x70]
    3660:      	str	x10, [x8, #0x2d8]
    3664:      	str	x9, [x8, #0x2d0]
    3668:      	ldr	w9, [sp, #0xc]
    366c:      	strb	w9, [x8, #0x2e0]
    3670:      	add	x9, x8, #0x2d0
    3674:      	b	0x2fc8 <perf_unwind_php+0x2fc8>
    3678:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    367c:      	add	x8, x8, #0x0
    3680:      	strb	wzr, [sp, #0x50]
    3684:      	add	x0, sp, #0x18
    3688:      	ldp	x9, x10, [x8, #0x20]
    368c:      	mov	w1, #0x39               // =57
    3690:      	stp	x9, x10, [sp, #0x38]
    3694:      	ldr	x9, [x8, #0x30]
    3698:      	str	x9, [sp, #0x48]
    369c:      	ldp	x9, x10, [x8]
    36a0:      	stp	x9, x10, [sp, #0x18]
    36a4:      	ldp	x8, x9, [x8, #0x10]
    36a8:      	add	x10, sp, #0x18
    36ac:      	stp	x8, x9, [sp, #0x28]
    36b0:      	mov	w8, #0x39               // =57
    36b4:      	mov	w9, #0x6                // =6
    36b8:      	ldr	x8, [sp, #0x68]
    36bc:      	ldrb	w10, [x24, #0x15]
    36c0:      	add	x2, x8, x10
    36c4:      	blr	x9
    36c8:      	mov	w25, #0x27              // =39
    36cc:      	b	0x2098 <perf_unwind_php+0x2098>
    36d0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    36d4:      	add	x8, x8, #0x0
    36d8:      	strb	wzr, [sp, #0x48]
    36dc:      	add	x0, sp, #0x18
    36e0:      	ldp	x9, x10, [x8, #0x10]
    36e4:      	mov	w1, #0x31               // =49
    36e8:      	stp	x9, x10, [sp, #0x28]
    36ec:      	ldp	x9, x10, [x8, #0x20]
    36f0:      	stp	x9, x10, [sp, #0x38]
    36f4:      	ldp	x9, x8, [x8]
    36f8:      	add	x10, sp, #0x18
    36fc:      	stp	x9, x8, [sp, #0x18]
    3700:      	mov	w8, #0x31               // =49
    3704:      	mov	w9, #0x6                // =6
    3708:      	ldr	x2, [sp, #0x70]
    370c:      	blr	x9
    3710:      	b	0x296c <perf_unwind_php+0x296c>
    3714:      	ldr	x8, [sp, #0x68]
    3718:      	ldrb	w9, [x24, #0x15]
    371c:      	mov	w10, #0x70              // =112
    3720:      	add	x11, sp, #0x88
    3724:      	add	x0, sp, #0x88
    3728:      	mov	w1, #0x4                // =4
    372c:      	add	x8, x8, x9
    3730:      	mov	w9, #0x4                // =4
    3734:      	ldr	x8, [sp, #0x68]
    3738:      	ldrb	w9, [x24, #0x15]
    373c:      	add	x2, x8, x9
    3740:      	blr	x10
    3744:      	cbz	x0, 0x38e4 <perf_unwind_php+0x38e4>
    3748:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    374c:      	ldr	x8, [x8]
    3750:      	ldr	w8, [x8]
    3754:      	cbnz	w8, 0x3df8 <perf_unwind_php+0x3df8>
    3758:      	mov	w25, #0x27              // =39
    375c:      	b	0x2ed4 <perf_unwind_php+0x2ed4>
    3760:      	ldr	x8, [sp, #0x70]
    3764:      	cbz	x8, 0x3968 <perf_unwind_php+0x3968>
    3768:      	ldrb	w9, [x24, #0x14]
    376c:      	mov	w10, #0x70              // =112
    3770:      	add	x11, sp, #0x8c
    3774:      	add	x0, sp, #0x8c
    3778:      	mov	w1, #0x1                // =1
    377c:      	add	x8, x8, x9
    3780:      	mov	w9, #0x1                // =1
    3784:      	ldr	x8, [sp, #0x70]
    3788:      	ldrb	w9, [x24, #0x14]
    378c:      	add	x2, x8, x9
    3790:      	blr	x10
    3794:      	cbz	x0, 0x3a40 <perf_unwind_php+0x3a40>
    3798:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    379c:      	ldr	x8, [x8]
    37a0:      	ldr	w8, [x8]
    37a4:      	cbz	w8, 0x37e8 <perf_unwind_php+0x37e8>
    37a8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    37ac:      	add	x8, x8, #0x0
    37b0:      	strb	wzr, [sp, #0x48]
    37b4:      	add	x0, sp, #0x18
    37b8:      	ldp	x9, x10, [x8, #0x10]
    37bc:      	mov	w1, #0x31               // =49
    37c0:      	stp	x9, x10, [sp, #0x28]
    37c4:      	ldp	x9, x10, [x8, #0x20]
    37c8:      	stp	x9, x10, [sp, #0x38]
    37cc:      	ldp	x9, x8, [x8]
    37d0:      	add	x10, sp, #0x18
    37d4:      	stp	x9, x8, [sp, #0x18]
    37d8:      	mov	w8, #0x31               // =49
    37dc:      	mov	w9, #0x6                // =6
    37e0:      	ldr	x2, [sp, #0x70]
    37e4:      	blr	x9
    37e8:      	mov	w25, #0x26              // =38
    37ec:      	b	0x3394 <perf_unwind_php+0x3394>
    37f0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    37f4:      	ldr	x8, [x8]
    37f8:      	ldr	w8, [x8]
    37fc:      	cbnz	w8, 0x3e50 <perf_unwind_php+0x3e50>
    3800:      	cmp	w25, #0x23
    3804:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    3808:      	ldr	x8, [sp, #0x60]
    380c:      	ldrb	w9, [x24, #0x12]
    3810:      	mov	w10, #0x70              // =112
    3814:      	add	x11, sp, #0x60
    3818:      	add	x0, sp, #0x60
    381c:      	mov	w1, #0x8                // =8
    3820:      	add	x8, x8, x9
    3824:      	mov	w9, #0x8                // =8
    3828:      	ldr	x8, [sp, #0x60]
    382c:      	ldrb	w9, [x24, #0x12]
    3830:      	add	x2, x8, x9
    3834:      	blr	x10
    3838:      	adrp	x29, 0x3000 <perf_unwind_php+0x3000>
    383c:      	ldr	x29, [x29]
    3840:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    3844:      	ldr	x25, [sp, #0x60]
    3848:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    384c:      	ldrb	w8, [sp, #0x5e]
    3850:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    3854:      	ldrb	w8, [x24, #0x10]
    3858:      	mov	w9, #0x8                // =8
    385c:      	mov	w10, #0x70              // =112
    3860:      	add	x11, sp, #0x70
    3864:      	add	x0, sp, #0x70
    3868:      	mov	w1, #0x8                // =8
    386c:      	add	x8, x25, x8
    3870:      	ldrb	w8, [x24, #0x10]
    3874:      	add	x2, x25, x8
    3878:      	blr	x10
    387c:      	cbz	x0, 0x3ea0 <perf_unwind_php+0x3ea0>
    3880:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3884:      	ldr	x8, [x8]
    3888:      	ldr	w8, [x8]
    388c:      	cbz	w8, 0x42f0 <perf_unwind_php+0x42f0>
    3890:      	mov	w8, #0x2978             // =10616
    3894:      	add	x0, sp, #0x18
    3898:      	mov	w1, #0x33               // =51
    389c:      	movk	w8, #0xa, lsl #16
    38a0:      	stur	w8, [sp, #0x47]
    38a4:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    38a8:      	add	x8, x8, #0x0
    38ac:      	ldp	x9, x10, [x8, #0x10]
    38b0:      	stp	x9, x10, [sp, #0x28]
    38b4:      	ldp	x9, x10, [x8, #0x20]
    38b8:      	stp	x9, x10, [sp, #0x38]
    38bc:      	ldp	x9, x8, [x8]
    38c0:      	add	x10, sp, #0x18
    38c4:      	stp	x9, x8, [sp, #0x18]
    38c8:      	mov	w8, #0x33               // =51
    38cc:      	mov	w9, #0x6                // =6
    38d0:      	ldrb	w8, [x24, #0x10]
    38d4:      	add	x2, x25, x8
    38d8:      	blr	x9
    38dc:      	mov	w25, #0x25              // =37
    38e0:      	b	0x43e8 <perf_unwind_php+0x43e8>
    38e4:      	ldrb	w8, [x24, #0x13]
    38e8:      	mov	w9, #0x4                // =4
    38ec:      	mov	w10, #0x70              // =112
    38f0:      	add	x11, sp, #0x5c
    38f4:      	add	x0, sp, #0x5c
    38f8:      	mov	w1, #0x4                // =4
    38fc:      	add	x8, x25, x8
    3900:      	ldrb	w8, [x24, #0x13]
    3904:      	add	x2, x25, x8
    3908:      	blr	x10
    390c:      	cbz	x0, 0x3b30 <perf_unwind_php+0x3b30>
    3910:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3914:      	ldr	x8, [x8]
    3918:      	ldr	w8, [x8]
    391c:      	cbz	w8, 0x2ed0 <perf_unwind_php+0x2ed0>
    3920:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3924:      	add	x8, x8, #0x0
    3928:      	add	x0, sp, #0x18
    392c:      	ldp	x9, x10, [x8, #0x20]
    3930:      	mov	w1, #0x35               // =53
    3934:      	mov	x2, x25
    3938:      	stp	x9, x10, [sp, #0x38]
    393c:      	ldur	x9, [x8, #0x2d]
    3940:      	stur	x9, [sp, #0x45]
    3944:      	ldp	x9, x10, [x8]
    3948:      	stp	x9, x10, [sp, #0x18]
    394c:      	ldp	x8, x9, [x8, #0x10]
    3950:      	add	x10, sp, #0x18
    3954:      	stp	x8, x9, [sp, #0x28]
    3958:      	mov	w8, #0x35               // =53
    395c:      	mov	w9, #0x6                // =6
    3960:      	blr	x9
    3964:      	b	0x2ed0 <perf_unwind_php+0x2ed0>
    3968:      	ldr	w8, [x21, #0x2c0]
    396c:      	adrp	x29, 0x3000 <perf_unwind_php+0x3000>
    3970:      	ldr	x29, [x29]
    3974:      	cmp	w8, #0x7e
    3978:      	b.hi	0x394 <perf_unwind_php+0x394>
    397c:      	add	w9, w8, #0x1
    3980:      	mov	x10, #-0x2              // =-2
    3984:      	str	w9, [x21, #0x2c0]
    3988:      	mov	w9, #0x18               // =24
    398c:      	umaddl	x8, w8, w9, x21
    3990:      	add	x9, x8, #0x2d0
    3994:      	str	x10, [x8, #0x2d8]
    3998:      	mov	w10, #0x2               // =2
    399c:      	str	xzr, [x8, #0x2d0]
    39a0:      	strb	w10, [x8, #0x2e0]
    39a4:      	b	0x4260 <perf_unwind_php+0x4260>
    39a8:      	mov	w8, #0x2978             // =10616
    39ac:      	add	x0, sp, #0x18
    39b0:      	mov	w1, #0x33               // =51
    39b4:      	movk	w8, #0xa, lsl #16
    39b8:      	stur	w8, [sp, #0x47]
    39bc:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    39c0:      	add	x8, x8, #0x0
    39c4:      	ldp	x9, x10, [x8, #0x10]
    39c8:      	stp	x9, x10, [sp, #0x28]
    39cc:      	ldp	x9, x10, [x8, #0x20]
    39d0:      	stp	x9, x10, [sp, #0x38]
    39d4:      	ldp	x9, x8, [x8]
    39d8:      	add	x10, sp, #0x18
    39dc:      	stp	x9, x8, [sp, #0x18]
    39e0:      	mov	w8, #0x33               // =51
    39e4:      	mov	w9, #0x6                // =6
    39e8:      	ldrb	w8, [x24, #0x10]
    39ec:      	add	x2, x25, x8
    39f0:      	blr	x9
    39f4:      	b	0x2a14 <perf_unwind_php+0x2a14>
    39f8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    39fc:      	add	x8, x8, #0x0
    3a00:      	add	x0, sp, #0x18
    3a04:      	ldp	x9, x10, [x8]
    3a08:      	ldur	x8, [x8, #0xe]
    3a0c:      	mov	w1, #0x16               // =22
    3a10:      	stp	x9, x10, [sp, #0x18]
    3a14:      	stur	x8, [sp, #0x26]
    3a18:      	mov	w8, #0x16               // =22
    3a1c:      	mov	w9, #0x6                // =6
    3a20:      	add	x10, sp, #0x18
    3a24:      	ldr	x2, [sp, #0x70]
    3a28:      	ldr	w3, [sp, #0x88]
    3a2c:      	blr	x9
    3a30:      	ldr	w8, [x21, #0x2c0]
    3a34:      	cmp	w8, #0x7e
    3a38:      	b.hi	0x82c <perf_unwind_php+0x82c>
    3a3c:      	b	0x3184 <perf_unwind_php+0x3184>
    3a40:      	ldrb	w8, [sp, #0x8c]
    3a44:      	str	wzr, [sp, #0x88]
    3a48:      	cmp	w8, #0x4
    3a4c:      	b.eq	0x3a5c <perf_unwind_php+0x3a5c>
    3a50:      	mov	w29, wzr
    3a54:      	cmp	w8, #0x2
    3a58:      	b.ne	0x41d8 <perf_unwind_php+0x41d8>
    3a5c:      	ldrb	w8, [x24, #0x11]
    3a60:      	mov	w9, #0x8                // =8
    3a64:      	mov	w10, #0x70              // =112
    3a68:      	add	x11, sp, #0x68
    3a6c:      	add	x0, sp, #0x68
    3a70:      	mov	w1, #0x8                // =8
    3a74:      	add	x8, x25, x8
    3a78:      	ldrb	w8, [x24, #0x11]
    3a7c:      	add	x2, x25, x8
    3a80:      	blr	x10
    3a84:      	cbz	x0, 0x3f30 <perf_unwind_php+0x3f30>
    3a88:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3a8c:      	ldr	x8, [x8]
    3a90:      	ldr	w8, [x8]
    3a94:      	cbz	w8, 0x3390 <perf_unwind_php+0x3390>
    3a98:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3a9c:      	add	x8, x8, #0x0
    3aa0:      	add	x0, sp, #0x18
    3aa4:      	ldp	x9, x10, [x8, #0x10]
    3aa8:      	mov	w1, #0x2d               // =45
    3aac:      	stp	x9, x10, [sp, #0x28]
    3ab0:      	ldr	x9, [x8, #0x20]
    3ab4:      	add	x10, sp, #0x18
    3ab8:      	str	x9, [sp, #0x38]
    3abc:      	ldur	x9, [x8, #0x25]
    3ac0:      	stur	x9, [sp, #0x3d]
    3ac4:      	ldp	x9, x8, [x8]
    3ac8:      	stp	x9, x8, [sp, #0x18]
    3acc:      	mov	w8, #0x2d               // =45
    3ad0:      	mov	w9, #0x6                // =6
    3ad4:      	ldrb	w8, [x24, #0x11]
    3ad8:      	add	x2, x25, x8
    3adc:      	b	0x4128 <perf_unwind_php+0x4128>
    3ae0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3ae4:      	add	x8, x8, #0x0
    3ae8:      	add	x0, sp, #0x18
    3aec:      	ldp	x9, x10, [x8, #0x10]
    3af0:      	mov	w1, #0x2e               // =46
    3af4:      	stp	x9, x10, [sp, #0x28]
    3af8:      	ldr	x9, [x8, #0x20]
    3afc:      	add	x10, sp, #0x18
    3b00:      	str	x9, [sp, #0x38]
    3b04:      	ldur	x9, [x8, #0x26]
    3b08:      	stur	x9, [sp, #0x3e]
    3b0c:      	ldp	x9, x8, [x8]
    3b10:      	stp	x9, x8, [sp, #0x18]
    3b14:      	mov	w8, #0x2e               // =46
    3b18:      	mov	w9, #0x6                // =6
    3b1c:      	ldr	w2, [sp, #0x70]
    3b20:      	blr	x9
    3b24:      	cmp	w25, #0x23
    3b28:      	b.eq	0x2e48 <perf_unwind_php+0x2e48>
    3b2c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    3b30:      	ldr	w29, [sp, #0x88]
    3b34:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3b38:      	ldr	w25, [sp, #0x5c]
    3b3c:      	ldr	x8, [x8]
    3b40:      	ldr	w8, [x8]
    3b44:      	cbnz	w8, 0x3f7c <perf_unwind_php+0x3f7c>
    3b48:      	ldr	w8, [x21, #0x2c0]
    3b4c:      	cmp	w8, #0x7e
    3b50:      	b.hi	0x82c <perf_unwind_php+0x82c>
    3b54:      	add	w9, w8, #0x1
    3b58:      	mov	w10, w29
    3b5c:      	str	w9, [x21, #0x2c0]
    3b60:      	mov	w9, #0x18               // =24
    3b64:      	orr	x10, x10, x25, lsl #32
    3b68:      	umaddl	x8, w8, w9, x21
    3b6c:      	ldr	x9, [sp, #0x70]
    3b70:      	str	x10, [x8, #0x2d8]
    3b74:      	str	x9, [x8, #0x2d0]
    3b78:      	ldr	w9, [sp, #0xc]
    3b7c:      	strb	w9, [x8, #0x2e0]
    3b80:      	add	x9, x8, #0x2d0
    3b84:      	b	0x3488 <perf_unwind_php+0x3488>
    3b88:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3b8c:      	add	x8, x8, #0x0
    3b90:      	strb	wzr, [sp, #0x50]
    3b94:      	add	x0, sp, #0x18
    3b98:      	ldp	x9, x10, [x8, #0x20]
    3b9c:      	mov	w1, #0x39               // =57
    3ba0:      	stp	x9, x10, [sp, #0x38]
    3ba4:      	ldr	x9, [x8, #0x30]
    3ba8:      	str	x9, [sp, #0x48]
    3bac:      	ldp	x9, x10, [x8]
    3bb0:      	stp	x9, x10, [sp, #0x18]
    3bb4:      	ldp	x8, x9, [x8, #0x10]
    3bb8:      	add	x10, sp, #0x18
    3bbc:      	stp	x8, x9, [sp, #0x28]
    3bc0:      	mov	w8, #0x39               // =57
    3bc4:      	mov	w9, #0x6                // =6
    3bc8:      	ldr	x8, [sp, #0x68]
    3bcc:      	ldrb	w10, [x24, #0x15]
    3bd0:      	add	x2, x8, x10
    3bd4:      	blr	x9
    3bd8:      	mov	w25, #0x27              // =39
    3bdc:      	b	0x2558 <perf_unwind_php+0x2558>
    3be0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3be4:      	add	x8, x8, #0x0
    3be8:      	strb	wzr, [sp, #0x48]
    3bec:      	add	x0, sp, #0x18
    3bf0:      	ldp	x9, x10, [x8, #0x10]
    3bf4:      	mov	w1, #0x31               // =49
    3bf8:      	stp	x9, x10, [sp, #0x28]
    3bfc:      	ldp	x9, x10, [x8, #0x20]
    3c00:      	stp	x9, x10, [sp, #0x38]
    3c04:      	ldp	x9, x8, [x8]
    3c08:      	add	x10, sp, #0x18
    3c0c:      	stp	x9, x8, [sp, #0x18]
    3c10:      	mov	w8, #0x31               // =49
    3c14:      	mov	w9, #0x6                // =6
    3c18:      	ldr	x2, [sp, #0x70]
    3c1c:      	blr	x9
    3c20:      	b	0x2e28 <perf_unwind_php+0x2e28>
    3c24:      	mov	w8, #0x2978             // =10616
    3c28:      	add	x0, sp, #0x18
    3c2c:      	mov	w1, #0x33               // =51
    3c30:      	movk	w8, #0xa, lsl #16
    3c34:      	stur	w8, [sp, #0x47]
    3c38:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3c3c:      	add	x8, x8, #0x0
    3c40:      	ldp	x9, x10, [x8, #0x10]
    3c44:      	stp	x9, x10, [sp, #0x28]
    3c48:      	ldp	x9, x10, [x8, #0x20]
    3c4c:      	stp	x9, x10, [sp, #0x38]
    3c50:      	ldp	x9, x8, [x8]
    3c54:      	add	x10, sp, #0x18
    3c58:      	stp	x9, x8, [sp, #0x18]
    3c5c:      	mov	w8, #0x33               // =51
    3c60:      	mov	w9, #0x6                // =6
    3c64:      	ldrb	w8, [x24, #0x10]
    3c68:      	add	x2, x25, x8
    3c6c:      	blr	x9
    3c70:      	b	0x2ed0 <perf_unwind_php+0x2ed0>
    3c74:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3c78:      	add	x8, x8, #0x0
    3c7c:      	strb	wzr, [sp, #0x50]
    3c80:      	add	x0, sp, #0x18
    3c84:      	ldp	x9, x10, [x8, #0x20]
    3c88:      	mov	w1, #0x39               // =57
    3c8c:      	stp	x9, x10, [sp, #0x38]
    3c90:      	ldr	x9, [x8, #0x30]
    3c94:      	str	x9, [sp, #0x48]
    3c98:      	ldp	x9, x10, [x8]
    3c9c:      	stp	x9, x10, [sp, #0x18]
    3ca0:      	ldp	x8, x9, [x8, #0x10]
    3ca4:      	add	x10, sp, #0x18
    3ca8:      	stp	x8, x9, [sp, #0x28]
    3cac:      	mov	w8, #0x39               // =57
    3cb0:      	mov	w9, #0x6                // =6
    3cb4:      	ldr	x8, [sp, #0x68]
    3cb8:      	ldrb	w10, [x24, #0x15]
    3cbc:      	add	x2, x8, x10
    3cc0:      	blr	x9
    3cc4:      	mov	w25, #0x27              // =39
    3cc8:      	b	0x2a18 <perf_unwind_php+0x2a18>
    3ccc:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3cd0:      	add	x8, x8, #0x0
    3cd4:      	strb	wzr, [sp, #0x48]
    3cd8:      	add	x0, sp, #0x18
    3cdc:      	ldp	x9, x10, [x8, #0x10]
    3ce0:      	mov	w1, #0x31               // =49
    3ce4:      	stp	x9, x10, [sp, #0x28]
    3ce8:      	ldp	x9, x10, [x8, #0x20]
    3cec:      	stp	x9, x10, [sp, #0x38]
    3cf0:      	ldp	x9, x8, [x8]
    3cf4:      	add	x10, sp, #0x18
    3cf8:      	stp	x9, x8, [sp, #0x18]
    3cfc:      	mov	w8, #0x31               // =49
    3d00:      	mov	w9, #0x6                // =6
    3d04:      	ldr	x2, [sp, #0x70]
    3d08:      	blr	x9
    3d0c:      	b	0x32e8 <perf_unwind_php+0x32e8>
    3d10:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3d14:      	add	x8, x8, #0x0
    3d18:      	add	x0, sp, #0x18
    3d1c:      	ldp	x9, x10, [x8, #0x10]
    3d20:      	mov	w1, #0x2e               // =46
    3d24:      	stp	x9, x10, [sp, #0x28]
    3d28:      	ldr	x9, [x8, #0x20]
    3d2c:      	add	x10, sp, #0x18
    3d30:      	str	x9, [sp, #0x38]
    3d34:      	ldur	x9, [x8, #0x26]
    3d38:      	stur	x9, [sp, #0x3e]
    3d3c:      	ldp	x9, x8, [x8]
    3d40:      	stp	x9, x8, [sp, #0x18]
    3d44:      	mov	w8, #0x2e               // =46
    3d48:      	mov	w9, #0x6                // =6
    3d4c:      	ldr	w2, [sp, #0x70]
    3d50:      	blr	x9
    3d54:      	cmp	w25, #0x23
    3d58:      	b.eq	0x3308 <perf_unwind_php+0x3308>
    3d5c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    3d60:      	mov	w8, #0x2978             // =10616
    3d64:      	add	x0, sp, #0x18
    3d68:      	mov	w1, #0x33               // =51
    3d6c:      	movk	w8, #0xa, lsl #16
    3d70:      	stur	w8, [sp, #0x47]
    3d74:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3d78:      	add	x8, x8, #0x0
    3d7c:      	ldp	x9, x10, [x8, #0x10]
    3d80:      	stp	x9, x10, [sp, #0x28]
    3d84:      	ldp	x9, x10, [x8, #0x20]
    3d88:      	stp	x9, x10, [sp, #0x38]
    3d8c:      	ldp	x9, x8, [x8]
    3d90:      	add	x10, sp, #0x18
    3d94:      	stp	x9, x8, [sp, #0x18]
    3d98:      	mov	w8, #0x33               // =51
    3d9c:      	mov	w9, #0x6                // =6
    3da0:      	ldrb	w8, [x24, #0x10]
    3da4:      	add	x2, x25, x8
    3da8:      	blr	x9
    3dac:      	b	0x3390 <perf_unwind_php+0x3390>
    3db0:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3db4:      	add	x8, x8, #0x0
    3db8:      	add	x0, sp, #0x18
    3dbc:      	ldp	x9, x10, [x8]
    3dc0:      	ldur	x8, [x8, #0xe]
    3dc4:      	mov	w1, #0x16               // =22
    3dc8:      	stp	x9, x10, [sp, #0x18]
    3dcc:      	stur	x8, [sp, #0x26]
    3dd0:      	mov	w8, #0x16               // =22
    3dd4:      	mov	w9, #0x6                // =6
    3dd8:      	add	x10, sp, #0x18
    3ddc:      	ldr	x2, [sp, #0x70]
    3de0:      	ldr	w3, [sp, #0x88]
    3de4:      	blr	x9
    3de8:      	ldr	w8, [x21, #0x2c0]
    3dec:      	cmp	w8, #0x7e
    3df0:      	b.hi	0x82c <perf_unwind_php+0x82c>
    3df4:      	b	0x3644 <perf_unwind_php+0x3644>
    3df8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3dfc:      	add	x8, x8, #0x0
    3e00:      	strb	wzr, [sp, #0x50]
    3e04:      	add	x0, sp, #0x18
    3e08:      	ldp	x9, x10, [x8, #0x20]
    3e0c:      	mov	w1, #0x39               // =57
    3e10:      	stp	x9, x10, [sp, #0x38]
    3e14:      	ldr	x9, [x8, #0x30]
    3e18:      	str	x9, [sp, #0x48]
    3e1c:      	ldp	x9, x10, [x8]
    3e20:      	stp	x9, x10, [sp, #0x18]
    3e24:      	ldp	x8, x9, [x8, #0x10]
    3e28:      	add	x10, sp, #0x18
    3e2c:      	stp	x8, x9, [sp, #0x28]
    3e30:      	mov	w8, #0x39               // =57
    3e34:      	mov	w9, #0x6                // =6
    3e38:      	ldr	x8, [sp, #0x68]
    3e3c:      	ldrb	w10, [x24, #0x15]
    3e40:      	add	x2, x8, x10
    3e44:      	blr	x9
    3e48:      	mov	w25, #0x27              // =39
    3e4c:      	b	0x2ed4 <perf_unwind_php+0x2ed4>
    3e50:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3e54:      	add	x8, x8, #0x0
    3e58:      	add	x0, sp, #0x18
    3e5c:      	ldp	x9, x10, [x8, #0x10]
    3e60:      	mov	w1, #0x2e               // =46
    3e64:      	stp	x9, x10, [sp, #0x28]
    3e68:      	ldr	x9, [x8, #0x20]
    3e6c:      	add	x10, sp, #0x18
    3e70:      	str	x9, [sp, #0x38]
    3e74:      	ldur	x9, [x8, #0x26]
    3e78:      	stur	x9, [sp, #0x3e]
    3e7c:      	ldp	x9, x8, [x8]
    3e80:      	stp	x9, x8, [sp, #0x18]
    3e84:      	mov	w8, #0x2e               // =46
    3e88:      	mov	w9, #0x6                // =6
    3e8c:      	ldr	w2, [sp, #0x70]
    3e90:      	blr	x9
    3e94:      	cmp	w25, #0x23
    3e98:      	b.eq	0x3808 <perf_unwind_php+0x3808>
    3e9c:      	b	0x61f4 <perf_unwind_php+0x61f4>
    3ea0:      	ldr	x8, [sp, #0x70]
    3ea4:      	cbz	x8, 0x3fc4 <perf_unwind_php+0x3fc4>
    3ea8:      	ldrb	w9, [x24, #0x14]
    3eac:      	mov	w10, #0x70              // =112
    3eb0:      	add	x11, sp, #0x8c
    3eb4:      	add	x0, sp, #0x8c
    3eb8:      	mov	w1, #0x1                // =1
    3ebc:      	add	x8, x8, x9
    3ec0:      	mov	w9, #0x1                // =1
    3ec4:      	ldr	x8, [sp, #0x70]
    3ec8:      	ldrb	w9, [x24, #0x14]
    3ecc:      	add	x2, x8, x9
    3ed0:      	blr	x10
    3ed4:      	cbz	x0, 0x4004 <perf_unwind_php+0x4004>
    3ed8:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3edc:      	ldr	x8, [x8]
    3ee0:      	ldr	w8, [x8]
    3ee4:      	cbz	w8, 0x3f28 <perf_unwind_php+0x3f28>
    3ee8:      	adrp	x10, 0x3000 <perf_unwind_php+0x3000>
    3eec:      	add	x10, x10, #0x0
    3ef0:      	strb	wzr, [sp, #0x48]
    3ef4:      	add	x0, sp, #0x18
    3ef8:      	ldp	x8, x9, [x10, #0x10]
    3efc:      	mov	w1, #0x31               // =49
    3f00:      	stp	x8, x9, [sp, #0x28]
    3f04:      	ldp	x8, x9, [x10, #0x20]
    3f08:      	stp	x8, x9, [sp, #0x38]
    3f0c:      	ldp	x8, x9, [x10]
    3f10:      	add	x10, sp, #0x18
    3f14:      	stp	x8, x9, [sp, #0x18]
    3f18:      	mov	w8, #0x31               // =49
    3f1c:      	mov	w9, #0x6                // =6
    3f20:      	ldr	x2, [sp, #0x70]
    3f24:      	blr	x9
    3f28:      	mov	w25, #0x26              // =38
    3f2c:      	b	0x43e8 <perf_unwind_php+0x43e8>
    3f30:      	ldr	x8, [sp, #0x68]
    3f34:      	ldrb	w9, [x24, #0x15]
    3f38:      	mov	w10, #0x70              // =112
    3f3c:      	add	x11, sp, #0x88
    3f40:      	add	x0, sp, #0x88
    3f44:      	mov	w1, #0x4                // =4
    3f48:      	add	x8, x8, x9
    3f4c:      	mov	w9, #0x4                // =4
    3f50:      	ldr	x8, [sp, #0x68]
    3f54:      	ldrb	w9, [x24, #0x15]
    3f58:      	add	x2, x8, x9
    3f5c:      	blr	x10
    3f60:      	cbz	x0, 0x40ac <perf_unwind_php+0x40ac>
    3f64:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3f68:      	ldr	x8, [x8]
    3f6c:      	ldr	w8, [x8]
    3f70:      	cbnz	w8, 0x4130 <perf_unwind_php+0x4130>
    3f74:      	mov	w25, #0x27              // =39
    3f78:      	b	0x3394 <perf_unwind_php+0x3394>
    3f7c:      	adrp	x8, 0x3000 <perf_unwind_php+0x3000>
    3f80:      	add	x8, x8, #0x0
    3f84:      	add	x0, sp, #0x18
    3f88:      	ldp	x9, x10, [x8]
    3f8c:      	ldur	x8, [x8, #0xe]
    3f90:      	mov	w1, #0x16               // =22
    3f94:      	stp	x9, x10, [sp, #0x18]
    3f98:      	stur	x8, [sp, #0x26]
    3f9c:      	mov	w8, #0x16               // =22
    3fa0:      	mov	w9, #0x6                // =6
    3fa4:      	add	x10, sp, #0x18
    3fa8:      	ldr	x2, [sp, #0x70]
    3fac:      	ldr	w3, [sp, #0x88]
    3fb0:      	blr	x9
    3fb4:      	ldr	w8, [x21, #0x2c0]
    3fb8:      	cmp	w8, #0x7e
    3fbc:      	b.hi	0x82c <perf_unwind_php+0x82c>
    3fc0:      	b	0x3b54 <perf_unwind_php+0x3b54>
    3fc4:      	ldr	w8, [x21, #0x2c0]
    3fc8:      	adrp	x29, 0x3000 <perf_unwind_php+0x3000>
    3fcc:      	ldr	x29, [x29]
    3fd0:      	cmp	w8, #0x7e
    3fd4:      	b.hi	0x394 <perf_unwind_php+0x394>
    3fd8:      	add	w9, w8, #0x1
    3fdc:      	mov	x10, #-0x2              // =-2
    3fe0:      	str	w9, [x21, #0x2c0]
    3fe4:      	mov	w9, #0x18               // =24
    3fe8:      	umaddl	x8, w8, w9, x21
    3fec:      	add	x9, x8, #0x2d0
    3ff0:      	str	x10, [x8, #0x2d8]
    3ff4:      	mov	w10, #0x2               // =2
    3ff8:      	str	xzr, [x8, #0x2d0]
    3ffc:      	strb	w10, [x8, #0x2e0]
    4000:      	b	0x43dc <perf_unwind_php+0x43dc>
    4004:      	ldrb	w8, [sp, #0x8c]
    4008:      	str	wzr, [sp, #0x88]
    400c:      	cmp	w8, #0x4
    4010:      	b.eq	0x4020 <perf_unwind_php+0x4020>
    4014:      	mov	w29, wzr
    4018:      	cmp	w8, #0x2
    401c:      	b.ne	0x4354 <perf_unwind_php+0x4354>
    4020:      	ldrb	w8, [x24, #0x11]
    4024:      	mov	w9, #0x8                // =8
    4028:      	mov	w10, #0x70              // =112
    402c:      	add	x11, sp, #0x68
    4030:      	add	x0, sp, #0x68
    4034:      	mov	w1, #0x8                // =8
    4038:      	add	x8, x25, x8
    403c:      	ldrb	w8, [x24, #0x11]
    4040:      	add	x2, x25, x8
    4044:      	blr	x10
    4048:      	cbz	x0, 0x4188 <perf_unwind_php+0x4188>
    404c:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4050:      	ldr	x8, [x8]
    4054:      	ldr	w8, [x8]
    4058:      	cbz	w8, 0x42f0 <perf_unwind_php+0x42f0>
    405c:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4060:      	add	x10, x10, #0x0
    4064:      	add	x0, sp, #0x18
    4068:      	ldp	x8, x9, [x10, #0x10]
    406c:      	mov	w1, #0x2d               // =45
    4070:      	stp	x8, x9, [sp, #0x28]
    4074:      	ldr	x8, [x10, #0x20]
    4078:      	str	x8, [sp, #0x38]
    407c:      	ldur	x8, [x10, #0x25]
    4080:      	stur	x8, [sp, #0x3d]
    4084:      	ldp	x8, x9, [x10]
    4088:      	add	x10, sp, #0x18
    408c:      	stp	x8, x9, [sp, #0x18]
    4090:      	mov	w8, #0x2d               // =45
    4094:      	mov	w9, #0x6                // =6
    4098:      	ldrb	w8, [x24, #0x11]
    409c:      	add	x2, x25, x8
    40a0:      	blr	x9
    40a4:      	mov	w25, #0x25              // =37
    40a8:      	b	0x43e8 <perf_unwind_php+0x43e8>
    40ac:      	ldrb	w8, [x24, #0x13]
    40b0:      	mov	w9, #0x4                // =4
    40b4:      	mov	w10, #0x70              // =112
    40b8:      	add	x11, sp, #0x5c
    40bc:      	add	x0, sp, #0x5c
    40c0:      	mov	w1, #0x4                // =4
    40c4:      	add	x8, x25, x8
    40c8:      	ldrb	w8, [x24, #0x13]
    40cc:      	add	x2, x25, x8
    40d0:      	blr	x10
    40d4:      	cbz	x0, 0x41d4 <perf_unwind_php+0x41d4>
    40d8:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    40dc:      	ldr	x8, [x8]
    40e0:      	ldr	w8, [x8]
    40e4:      	cbz	w8, 0x3390 <perf_unwind_php+0x3390>
    40e8:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    40ec:      	add	x8, x8, #0x0
    40f0:      	add	x0, sp, #0x18
    40f4:      	ldp	x9, x10, [x8, #0x20]
    40f8:      	mov	w1, #0x35               // =53
    40fc:      	mov	x2, x25
    4100:      	stp	x9, x10, [sp, #0x38]
    4104:      	ldur	x9, [x8, #0x2d]
    4108:      	stur	x9, [sp, #0x45]
    410c:      	ldp	x9, x10, [x8]
    4110:      	stp	x9, x10, [sp, #0x18]
    4114:      	ldp	x8, x9, [x8, #0x10]
    4118:      	add	x10, sp, #0x18
    411c:      	stp	x8, x9, [sp, #0x28]
    4120:      	mov	w8, #0x35               // =53
    4124:      	mov	w9, #0x6                // =6
    4128:      	blr	x9
    412c:      	b	0x3390 <perf_unwind_php+0x3390>
    4130:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4134:      	add	x8, x8, #0x0
    4138:      	strb	wzr, [sp, #0x50]
    413c:      	add	x0, sp, #0x18
    4140:      	ldp	x9, x10, [x8, #0x20]
    4144:      	mov	w1, #0x39               // =57
    4148:      	stp	x9, x10, [sp, #0x38]
    414c:      	ldr	x9, [x8, #0x30]
    4150:      	str	x9, [sp, #0x48]
    4154:      	ldp	x9, x10, [x8]
    4158:      	stp	x9, x10, [sp, #0x18]
    415c:      	ldp	x8, x9, [x8, #0x10]
    4160:      	add	x10, sp, #0x18
    4164:      	stp	x8, x9, [sp, #0x28]
    4168:      	mov	w8, #0x39               // =57
    416c:      	mov	w9, #0x6                // =6
    4170:      	ldr	x8, [sp, #0x68]
    4174:      	ldrb	w10, [x24, #0x15]
    4178:      	add	x2, x8, x10
    417c:      	blr	x9
    4180:      	mov	w25, #0x27              // =39
    4184:      	b	0x3394 <perf_unwind_php+0x3394>
    4188:      	ldr	x8, [sp, #0x68]
    418c:      	ldrb	w9, [x24, #0x15]
    4190:      	mov	w10, #0x70              // =112
    4194:      	add	x11, sp, #0x88
    4198:      	add	x0, sp, #0x88
    419c:      	mov	w1, #0x4                // =4
    41a0:      	add	x8, x8, x9
    41a4:      	mov	w9, #0x4                // =4
    41a8:      	ldr	x8, [sp, #0x68]
    41ac:      	ldrb	w9, [x24, #0x15]
    41b0:      	add	x2, x8, x9
    41b4:      	blr	x10
    41b8:      	cbz	x0, 0x4270 <perf_unwind_php+0x4270>
    41bc:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    41c0:      	ldr	x8, [x8]
    41c4:      	ldr	w8, [x8]
    41c8:      	cbnz	w8, 0x42f8 <perf_unwind_php+0x42f8>
    41cc:      	mov	w25, #0x27              // =39
    41d0:      	b	0x43e8 <perf_unwind_php+0x43e8>
    41d4:      	ldr	w29, [sp, #0x88]
    41d8:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    41dc:      	ldr	w25, [sp, #0x5c]
    41e0:      	ldr	x8, [x8]
    41e4:      	ldr	w8, [x8]
    41e8:      	cbz	w8, 0x4224 <perf_unwind_php+0x4224>
    41ec:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    41f0:      	add	x8, x8, #0x0
    41f4:      	add	x0, sp, #0x18
    41f8:      	ldp	x9, x10, [x8]
    41fc:      	ldur	x8, [x8, #0xe]
    4200:      	mov	w1, #0x16               // =22
    4204:      	stp	x9, x10, [sp, #0x18]
    4208:      	stur	x8, [sp, #0x26]
    420c:      	mov	w8, #0x16               // =22
    4210:      	mov	w9, #0x6                // =6
    4214:      	add	x10, sp, #0x18
    4218:      	ldr	x2, [sp, #0x70]
    421c:      	ldr	w3, [sp, #0x88]
    4220:      	blr	x9
    4224:      	ldr	w8, [x21, #0x2c0]
    4228:      	cmp	w8, #0x7e
    422c:      	b.hi	0x82c <perf_unwind_php+0x82c>
    4230:      	add	w9, w8, #0x1
    4234:      	mov	w10, w29
    4238:      	str	w9, [x21, #0x2c0]
    423c:      	mov	w9, #0x18               // =24
    4240:      	orr	x10, x10, x25, lsl #32
    4244:      	umaddl	x8, w8, w9, x21
    4248:      	ldr	x9, [sp, #0x70]
    424c:      	str	x10, [x8, #0x2d8]
    4250:      	str	x9, [x8, #0x2d0]
    4254:      	ldr	w9, [sp, #0xc]
    4258:      	strb	w9, [x8, #0x2e0]
    425c:      	add	x9, x8, #0x2d0
    4260:      	mov	w25, #0x23              // =35
    4264:      	str	wzr, [x8, #0x2e4]
    4268:      	stur	wzr, [x9, #0x11]
    426c:      	b	0x3394 <perf_unwind_php+0x3394>
    4270:      	ldrb	w8, [x24, #0x13]
    4274:      	mov	w9, #0x4                // =4
    4278:      	mov	w10, #0x70              // =112
    427c:      	add	x11, sp, #0x5c
    4280:      	add	x0, sp, #0x5c
    4284:      	mov	w1, #0x4                // =4
    4288:      	add	x8, x25, x8
    428c:      	ldrb	w8, [x24, #0x13]
    4290:      	add	x2, x25, x8
    4294:      	blr	x10
    4298:      	cbz	x0, 0x4350 <perf_unwind_php+0x4350>
    429c:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    42a0:      	ldr	x8, [x8]
    42a4:      	ldr	w8, [x8]
    42a8:      	cbz	w8, 0x42f0 <perf_unwind_php+0x42f0>
    42ac:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    42b0:      	add	x10, x10, #0x0
    42b4:      	mov	w11, #0x6               // =6
    42b8:      	ldp	x8, x9, [x10, #0x20]
    42bc:      	add	x0, sp, #0x18
    42c0:      	mov	w1, #0x35               // =53
    42c4:      	mov	x2, x25
    42c8:      	stp	x8, x9, [sp, #0x38]
    42cc:      	ldur	x8, [x10, #0x2d]
    42d0:      	stur	x8, [sp, #0x45]
    42d4:      	ldp	x8, x9, [x10]
    42d8:      	stp	x8, x9, [sp, #0x18]
    42dc:      	ldp	x9, x8, [x10, #0x10]
    42e0:      	mov	w10, #0x35              // =53
    42e4:      	stp	x9, x8, [sp, #0x28]
    42e8:      	add	x8, sp, #0x18
    42ec:      	blr	x11
    42f0:      	mov	w25, #0x25              // =37
    42f4:      	b	0x43e8 <perf_unwind_php+0x43e8>
    42f8:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    42fc:      	add	x10, x10, #0x0
    4300:      	strb	wzr, [sp, #0x50]
    4304:      	add	x0, sp, #0x18
    4308:      	ldp	x8, x9, [x10, #0x20]
    430c:      	mov	w1, #0x39               // =57
    4310:      	stp	x8, x9, [sp, #0x38]
    4314:      	ldr	x8, [x10, #0x30]
    4318:      	str	x8, [sp, #0x48]
    431c:      	ldp	x8, x9, [x10]
    4320:      	stp	x8, x9, [sp, #0x18]
    4324:      	ldp	x9, x8, [x10, #0x10]
    4328:      	add	x10, sp, #0x18
    432c:      	stp	x9, x8, [sp, #0x28]
    4330:      	mov	w8, #0x39               // =57
    4334:      	mov	w9, #0x6                // =6
    4338:      	ldr	x8, [sp, #0x68]
    433c:      	ldrb	w10, [x24, #0x15]
    4340:      	add	x2, x8, x10
    4344:      	blr	x9
    4348:      	mov	w25, #0x27              // =39
    434c:      	b	0x43e8 <perf_unwind_php+0x43e8>
    4350:      	ldr	w29, [sp, #0x88]
    4354:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4358:      	ldr	w25, [sp, #0x5c]
    435c:      	ldr	x8, [x8]
    4360:      	ldr	w8, [x8]
    4364:      	cbz	w8, 0x43a0 <perf_unwind_php+0x43a0>
    4368:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    436c:      	add	x10, x10, #0x0
    4370:      	add	x0, sp, #0x18
    4374:      	ldp	x8, x9, [x10]
    4378:      	mov	w1, #0x16               // =22
    437c:      	stp	x8, x9, [sp, #0x18]
    4380:      	ldur	x8, [x10, #0xe]
    4384:      	mov	w9, #0x6                // =6
    4388:      	add	x10, sp, #0x18
    438c:      	stur	x8, [sp, #0x26]
    4390:      	mov	w8, #0x16               // =22
    4394:      	ldr	x2, [sp, #0x70]
    4398:      	ldr	w3, [sp, #0x88]
    439c:      	blr	x9
    43a0:      	ldr	w8, [x21, #0x2c0]
    43a4:      	cmp	w8, #0x7e
    43a8:      	b.hi	0x82c <perf_unwind_php+0x82c>
    43ac:      	add	w9, w8, #0x1
    43b0:      	mov	w10, w29
    43b4:      	str	w9, [x21, #0x2c0]
    43b8:      	mov	w9, #0x18               // =24
    43bc:      	orr	x10, x10, x25, lsl #32
    43c0:      	umaddl	x8, w8, w9, x21
    43c4:      	ldr	x9, [sp, #0x70]
    43c8:      	str	x10, [x8, #0x2d8]
    43cc:      	str	x9, [x8, #0x2d0]
    43d0:      	ldr	w9, [sp, #0xc]
    43d4:      	strb	w9, [x8, #0x2e0]
    43d8:      	add	x9, x8, #0x2d0
    43dc:      	mov	w25, #0x23              // =35
    43e0:      	str	wzr, [x8, #0x2e4]
    43e4:      	stur	wzr, [x9, #0x11]
    43e8:      	str	w25, [sp, #0x70]
    43ec:      	mov	w8, #0x1                // =1
    43f0:      	add	x9, sp, #0x70
    43f4:      	add	x1, sp, #0x70
    43f8:      	mov	x0, x23
    43fc:      	blr	x8
    4400:      	cbz	x0, 0x4414 <perf_unwind_php+0x4414>
    4404:      	ldr	x8, [x0]
    4408:      	add	x8, x8, #0x1
    440c:      	str	x8, [x0]
    4410:      	b	0x4468 <perf_unwind_php+0x4468>
    4414:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4418:      	ldr	x8, [x8]
    441c:      	ldr	w8, [x8]
    4420:      	cbz	w8, 0x4468 <perf_unwind_php+0x4468>
    4424:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4428:      	add	x8, x8, #0x0
    442c:      	add	x0, sp, #0x18
    4430:      	ldp	x9, x10, [x8, #0x10]
    4434:      	mov	w1, #0x2e               // =46
    4438:      	stp	x9, x10, [sp, #0x28]
    443c:      	ldr	x9, [x8, #0x20]
    4440:      	add	x10, sp, #0x18
    4444:      	str	x9, [sp, #0x38]
    4448:      	ldur	x9, [x8, #0x26]
    444c:      	stur	x9, [sp, #0x3e]
    4450:      	ldp	x9, x8, [x8]
    4454:      	stp	x9, x8, [sp, #0x18]
    4458:      	mov	w8, #0x2e               // =46
    445c:      	mov	w9, #0x6                // =6
    4460:      	ldr	w2, [sp, #0x70]
    4464:      	blr	x9
    4468:      	cmp	w25, #0x23
    446c:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    4470:      	ldr	x8, [sp, #0x60]
    4474:      	ldrb	w9, [x24, #0x12]
    4478:      	mov	w10, #0x70              // =112
    447c:      	add	x11, sp, #0x60
    4480:      	add	x0, sp, #0x60
    4484:      	mov	w1, #0x8                // =8
    4488:      	add	x8, x8, x9
    448c:      	mov	w9, #0x8                // =8
    4490:      	ldr	x8, [sp, #0x60]
    4494:      	ldrb	w9, [x24, #0x12]
    4498:      	add	x2, x8, x9
    449c:      	blr	x10
    44a0:      	adrp	x29, 0x4000 <perf_unwind_php+0x4000>
    44a4:      	ldr	x29, [x29]
    44a8:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    44ac:      	ldr	x25, [sp, #0x60]
    44b0:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    44b4:      	ldrb	w8, [sp, #0x5e]
    44b8:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    44bc:      	ldrb	w8, [x24, #0x10]
    44c0:      	mov	w9, #0x8                // =8
    44c4:      	mov	w10, #0x70              // =112
    44c8:      	add	x11, sp, #0x70
    44cc:      	add	x0, sp, #0x70
    44d0:      	mov	w1, #0x8                // =8
    44d4:      	add	x8, x25, x8
    44d8:      	ldrb	w8, [x24, #0x10]
    44dc:      	add	x2, x25, x8
    44e0:      	blr	x10
    44e4:      	cbz	x0, 0x454c <perf_unwind_php+0x454c>
    44e8:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    44ec:      	ldr	x8, [x8]
    44f0:      	ldr	w8, [x8]
    44f4:      	cbz	w8, 0x4790 <perf_unwind_php+0x4790>
    44f8:      	mov	w8, #0x2978             // =10616
    44fc:      	add	x0, sp, #0x18
    4500:      	mov	w1, #0x33               // =51
    4504:      	movk	w8, #0xa, lsl #16
    4508:      	stur	w8, [sp, #0x47]
    450c:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4510:      	add	x8, x8, #0x0
    4514:      	ldp	x9, x10, [x8, #0x10]
    4518:      	stp	x9, x10, [sp, #0x28]
    451c:      	ldp	x9, x10, [x8, #0x20]
    4520:      	stp	x9, x10, [sp, #0x38]
    4524:      	ldp	x9, x8, [x8]
    4528:      	add	x10, sp, #0x18
    452c:      	stp	x9, x8, [sp, #0x18]
    4530:      	mov	w8, #0x33               // =51
    4534:      	mov	w9, #0x6                // =6
    4538:      	ldrb	w8, [x24, #0x10]
    453c:      	add	x2, x25, x8
    4540:      	blr	x9
    4544:      	mov	w25, #0x25              // =37
    4548:      	b	0x4888 <perf_unwind_php+0x4888>
    454c:      	ldr	x8, [sp, #0x70]
    4550:      	cbz	x8, 0x45dc <perf_unwind_php+0x45dc>
    4554:      	ldrb	w9, [x24, #0x14]
    4558:      	mov	w10, #0x70              // =112
    455c:      	add	x11, sp, #0x8c
    4560:      	add	x0, sp, #0x8c
    4564:      	mov	w1, #0x1                // =1
    4568:      	add	x8, x8, x9
    456c:      	mov	w9, #0x1                // =1
    4570:      	ldr	x8, [sp, #0x70]
    4574:      	ldrb	w9, [x24, #0x14]
    4578:      	add	x2, x8, x9
    457c:      	blr	x10
    4580:      	cbz	x0, 0x461c <perf_unwind_php+0x461c>
    4584:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4588:      	ldr	x8, [x8]
    458c:      	ldr	w8, [x8]
    4590:      	cbz	w8, 0x45d4 <perf_unwind_php+0x45d4>
    4594:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4598:      	add	x10, x10, #0x0
    459c:      	strb	wzr, [sp, #0x48]
    45a0:      	add	x0, sp, #0x18
    45a4:      	ldp	x8, x9, [x10, #0x10]
    45a8:      	mov	w1, #0x31               // =49
    45ac:      	stp	x8, x9, [sp, #0x28]
    45b0:      	ldp	x8, x9, [x10, #0x20]
    45b4:      	stp	x8, x9, [sp, #0x38]
    45b8:      	ldp	x8, x9, [x10]
    45bc:      	add	x10, sp, #0x18
    45c0:      	stp	x8, x9, [sp, #0x18]
    45c4:      	mov	w8, #0x31               // =49
    45c8:      	mov	w9, #0x6                // =6
    45cc:      	ldr	x2, [sp, #0x70]
    45d0:      	blr	x9
    45d4:      	mov	w25, #0x26              // =38
    45d8:      	b	0x4888 <perf_unwind_php+0x4888>
    45dc:      	ldr	w8, [x21, #0x2c0]
    45e0:      	adrp	x29, 0x4000 <perf_unwind_php+0x4000>
    45e4:      	ldr	x29, [x29]
    45e8:      	cmp	w8, #0x7e
    45ec:      	b.hi	0x394 <perf_unwind_php+0x394>
    45f0:      	add	w9, w8, #0x1
    45f4:      	mov	x10, #-0x2              // =-2
    45f8:      	str	w9, [x21, #0x2c0]
    45fc:      	mov	w9, #0x18               // =24
    4600:      	umaddl	x8, w8, w9, x21
    4604:      	add	x9, x8, #0x2d0
    4608:      	str	x10, [x8, #0x2d8]
    460c:      	mov	w10, #0x2               // =2
    4610:      	str	xzr, [x8, #0x2d0]
    4614:      	strb	w10, [x8, #0x2e0]
    4618:      	b	0x487c <perf_unwind_php+0x487c>
    461c:      	ldrb	w8, [sp, #0x8c]
    4620:      	str	wzr, [sp, #0x88]
    4624:      	cmp	w8, #0x4
    4628:      	b.eq	0x4638 <perf_unwind_php+0x4638>
    462c:      	mov	w29, wzr
    4630:      	cmp	w8, #0x2
    4634:      	b.ne	0x47f4 <perf_unwind_php+0x47f4>
    4638:      	ldrb	w8, [x24, #0x11]
    463c:      	mov	w9, #0x8                // =8
    4640:      	mov	w10, #0x70              // =112
    4644:      	add	x11, sp, #0x68
    4648:      	add	x0, sp, #0x68
    464c:      	mov	w1, #0x8                // =8
    4650:      	add	x8, x25, x8
    4654:      	ldrb	w8, [x24, #0x11]
    4658:      	add	x2, x25, x8
    465c:      	blr	x10
    4660:      	cbz	x0, 0x46c4 <perf_unwind_php+0x46c4>
    4664:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4668:      	ldr	x8, [x8]
    466c:      	ldr	w8, [x8]
    4670:      	cbz	w8, 0x4790 <perf_unwind_php+0x4790>
    4674:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4678:      	add	x10, x10, #0x0
    467c:      	add	x0, sp, #0x18
    4680:      	ldp	x8, x9, [x10, #0x10]
    4684:      	mov	w1, #0x2d               // =45
    4688:      	stp	x8, x9, [sp, #0x28]
    468c:      	ldr	x8, [x10, #0x20]
    4690:      	str	x8, [sp, #0x38]
    4694:      	ldur	x8, [x10, #0x25]
    4698:      	stur	x8, [sp, #0x3d]
    469c:      	ldp	x8, x9, [x10]
    46a0:      	add	x10, sp, #0x18
    46a4:      	stp	x8, x9, [sp, #0x18]
    46a8:      	mov	w8, #0x2d               // =45
    46ac:      	mov	w9, #0x6                // =6
    46b0:      	ldrb	w8, [x24, #0x11]
    46b4:      	add	x2, x25, x8
    46b8:      	blr	x9
    46bc:      	mov	w25, #0x25              // =37
    46c0:      	b	0x4888 <perf_unwind_php+0x4888>
    46c4:      	ldr	x8, [sp, #0x68]
    46c8:      	ldrb	w9, [x24, #0x15]
    46cc:      	mov	w10, #0x70              // =112
    46d0:      	add	x11, sp, #0x88
    46d4:      	add	x0, sp, #0x88
    46d8:      	mov	w1, #0x4                // =4
    46dc:      	add	x8, x8, x9
    46e0:      	mov	w9, #0x4                // =4
    46e4:      	ldr	x8, [sp, #0x68]
    46e8:      	ldrb	w9, [x24, #0x15]
    46ec:      	add	x2, x8, x9
    46f0:      	blr	x10
    46f4:      	cbz	x0, 0x4710 <perf_unwind_php+0x4710>
    46f8:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    46fc:      	ldr	x8, [x8]
    4700:      	ldr	w8, [x8]
    4704:      	cbnz	w8, 0x4798 <perf_unwind_php+0x4798>
    4708:      	mov	w25, #0x27              // =39
    470c:      	b	0x4888 <perf_unwind_php+0x4888>
    4710:      	ldrb	w8, [x24, #0x13]
    4714:      	mov	w9, #0x4                // =4
    4718:      	mov	w10, #0x70              // =112
    471c:      	add	x11, sp, #0x5c
    4720:      	add	x0, sp, #0x5c
    4724:      	mov	w1, #0x4                // =4
    4728:      	add	x8, x25, x8
    472c:      	ldrb	w8, [x24, #0x13]
    4730:      	add	x2, x25, x8
    4734:      	blr	x10
    4738:      	cbz	x0, 0x47f0 <perf_unwind_php+0x47f0>
    473c:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4740:      	ldr	x8, [x8]
    4744:      	ldr	w8, [x8]
    4748:      	cbz	w8, 0x4790 <perf_unwind_php+0x4790>
    474c:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4750:      	add	x10, x10, #0x0
    4754:      	mov	w11, #0x6               // =6
    4758:      	ldp	x8, x9, [x10, #0x20]
    475c:      	add	x0, sp, #0x18
    4760:      	mov	w1, #0x35               // =53
    4764:      	mov	x2, x25
    4768:      	stp	x8, x9, [sp, #0x38]
    476c:      	ldur	x8, [x10, #0x2d]
    4770:      	stur	x8, [sp, #0x45]
    4774:      	ldp	x8, x9, [x10]
    4778:      	stp	x8, x9, [sp, #0x18]
    477c:      	ldp	x9, x8, [x10, #0x10]
    4780:      	mov	w10, #0x35              // =53
    4784:      	stp	x9, x8, [sp, #0x28]
    4788:      	add	x8, sp, #0x18
    478c:      	blr	x11
    4790:      	mov	w25, #0x25              // =37
    4794:      	b	0x4888 <perf_unwind_php+0x4888>
    4798:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    479c:      	add	x10, x10, #0x0
    47a0:      	strb	wzr, [sp, #0x50]
    47a4:      	add	x0, sp, #0x18
    47a8:      	ldp	x8, x9, [x10, #0x20]
    47ac:      	mov	w1, #0x39               // =57
    47b0:      	stp	x8, x9, [sp, #0x38]
    47b4:      	ldr	x8, [x10, #0x30]
    47b8:      	str	x8, [sp, #0x48]
    47bc:      	ldp	x8, x9, [x10]
    47c0:      	stp	x8, x9, [sp, #0x18]
    47c4:      	ldp	x9, x8, [x10, #0x10]
    47c8:      	add	x10, sp, #0x18
    47cc:      	stp	x9, x8, [sp, #0x28]
    47d0:      	mov	w8, #0x39               // =57
    47d4:      	mov	w9, #0x6                // =6
    47d8:      	ldr	x8, [sp, #0x68]
    47dc:      	ldrb	w10, [x24, #0x15]
    47e0:      	add	x2, x8, x10
    47e4:      	blr	x9
    47e8:      	mov	w25, #0x27              // =39
    47ec:      	b	0x4888 <perf_unwind_php+0x4888>
    47f0:      	ldr	w29, [sp, #0x88]
    47f4:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    47f8:      	ldr	w25, [sp, #0x5c]
    47fc:      	ldr	x8, [x8]
    4800:      	ldr	w8, [x8]
    4804:      	cbz	w8, 0x4840 <perf_unwind_php+0x4840>
    4808:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    480c:      	add	x10, x10, #0x0
    4810:      	add	x0, sp, #0x18
    4814:      	ldp	x8, x9, [x10]
    4818:      	mov	w1, #0x16               // =22
    481c:      	stp	x8, x9, [sp, #0x18]
    4820:      	ldur	x8, [x10, #0xe]
    4824:      	mov	w9, #0x6                // =6
    4828:      	add	x10, sp, #0x18
    482c:      	stur	x8, [sp, #0x26]
    4830:      	mov	w8, #0x16               // =22
    4834:      	ldr	x2, [sp, #0x70]
    4838:      	ldr	w3, [sp, #0x88]
    483c:      	blr	x9
    4840:      	ldr	w8, [x21, #0x2c0]
    4844:      	cmp	w8, #0x7e
    4848:      	b.hi	0x82c <perf_unwind_php+0x82c>
    484c:      	add	w9, w8, #0x1
    4850:      	mov	w10, w29
    4854:      	str	w9, [x21, #0x2c0]
    4858:      	mov	w9, #0x18               // =24
    485c:      	orr	x10, x10, x25, lsl #32
    4860:      	umaddl	x8, w8, w9, x21
    4864:      	ldr	x9, [sp, #0x70]
    4868:      	str	x10, [x8, #0x2d8]
    486c:      	str	x9, [x8, #0x2d0]
    4870:      	ldr	w9, [sp, #0xc]
    4874:      	strb	w9, [x8, #0x2e0]
    4878:      	add	x9, x8, #0x2d0
    487c:      	mov	w25, #0x23              // =35
    4880:      	str	wzr, [x8, #0x2e4]
    4884:      	stur	wzr, [x9, #0x11]
    4888:      	str	w25, [sp, #0x70]
    488c:      	mov	w8, #0x1                // =1
    4890:      	add	x9, sp, #0x70
    4894:      	add	x1, sp, #0x70
    4898:      	mov	x0, x23
    489c:      	blr	x8
    48a0:      	cbz	x0, 0x48b4 <perf_unwind_php+0x48b4>
    48a4:      	ldr	x8, [x0]
    48a8:      	add	x8, x8, #0x1
    48ac:      	str	x8, [x0]
    48b0:      	b	0x4908 <perf_unwind_php+0x4908>
    48b4:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    48b8:      	ldr	x8, [x8]
    48bc:      	ldr	w8, [x8]
    48c0:      	cbz	w8, 0x4908 <perf_unwind_php+0x4908>
    48c4:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    48c8:      	add	x8, x8, #0x0
    48cc:      	add	x0, sp, #0x18
    48d0:      	ldp	x9, x10, [x8, #0x10]
    48d4:      	mov	w1, #0x2e               // =46
    48d8:      	stp	x9, x10, [sp, #0x28]
    48dc:      	ldr	x9, [x8, #0x20]
    48e0:      	add	x10, sp, #0x18
    48e4:      	str	x9, [sp, #0x38]
    48e8:      	ldur	x9, [x8, #0x26]
    48ec:      	stur	x9, [sp, #0x3e]
    48f0:      	ldp	x9, x8, [x8]
    48f4:      	stp	x9, x8, [sp, #0x18]
    48f8:      	mov	w8, #0x2e               // =46
    48fc:      	mov	w9, #0x6                // =6
    4900:      	ldr	w2, [sp, #0x70]
    4904:      	blr	x9
    4908:      	cmp	w25, #0x23
    490c:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    4910:      	ldr	x8, [sp, #0x60]
    4914:      	ldrb	w9, [x24, #0x12]
    4918:      	mov	w10, #0x70              // =112
    491c:      	add	x11, sp, #0x60
    4920:      	add	x0, sp, #0x60
    4924:      	mov	w1, #0x8                // =8
    4928:      	add	x8, x8, x9
    492c:      	mov	w9, #0x8                // =8
    4930:      	ldr	x8, [sp, #0x60]
    4934:      	ldrb	w9, [x24, #0x12]
    4938:      	add	x2, x8, x9
    493c:      	blr	x10
    4940:      	adrp	x29, 0x4000 <perf_unwind_php+0x4000>
    4944:      	ldr	x29, [x29]
    4948:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    494c:      	ldr	x25, [sp, #0x60]
    4950:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    4954:      	ldrb	w8, [sp, #0x5e]
    4958:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    495c:      	ldrb	w8, [x24, #0x10]
    4960:      	mov	w9, #0x8                // =8
    4964:      	mov	w10, #0x70              // =112
    4968:      	add	x11, sp, #0x70
    496c:      	add	x0, sp, #0x70
    4970:      	mov	w1, #0x8                // =8
    4974:      	add	x8, x25, x8
    4978:      	ldrb	w8, [x24, #0x10]
    497c:      	add	x2, x25, x8
    4980:      	blr	x10
    4984:      	cbz	x0, 0x49ec <perf_unwind_php+0x49ec>
    4988:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    498c:      	ldr	x8, [x8]
    4990:      	ldr	w8, [x8]
    4994:      	cbz	w8, 0x4c30 <perf_unwind_php+0x4c30>
    4998:      	mov	w8, #0x2978             // =10616
    499c:      	add	x0, sp, #0x18
    49a0:      	mov	w1, #0x33               // =51
    49a4:      	movk	w8, #0xa, lsl #16
    49a8:      	stur	w8, [sp, #0x47]
    49ac:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    49b0:      	add	x8, x8, #0x0
    49b4:      	ldp	x9, x10, [x8, #0x10]
    49b8:      	stp	x9, x10, [sp, #0x28]
    49bc:      	ldp	x9, x10, [x8, #0x20]
    49c0:      	stp	x9, x10, [sp, #0x38]
    49c4:      	ldp	x9, x8, [x8]
    49c8:      	add	x10, sp, #0x18
    49cc:      	stp	x9, x8, [sp, #0x18]
    49d0:      	mov	w8, #0x33               // =51
    49d4:      	mov	w9, #0x6                // =6
    49d8:      	ldrb	w8, [x24, #0x10]
    49dc:      	add	x2, x25, x8
    49e0:      	blr	x9
    49e4:      	mov	w25, #0x25              // =37
    49e8:      	b	0x4d28 <perf_unwind_php+0x4d28>
    49ec:      	ldr	x8, [sp, #0x70]
    49f0:      	cbz	x8, 0x4a7c <perf_unwind_php+0x4a7c>
    49f4:      	ldrb	w9, [x24, #0x14]
    49f8:      	mov	w10, #0x70              // =112
    49fc:      	add	x11, sp, #0x8c
    4a00:      	add	x0, sp, #0x8c
    4a04:      	mov	w1, #0x1                // =1
    4a08:      	add	x8, x8, x9
    4a0c:      	mov	w9, #0x1                // =1
    4a10:      	ldr	x8, [sp, #0x70]
    4a14:      	ldrb	w9, [x24, #0x14]
    4a18:      	add	x2, x8, x9
    4a1c:      	blr	x10
    4a20:      	cbz	x0, 0x4abc <perf_unwind_php+0x4abc>
    4a24:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4a28:      	ldr	x8, [x8]
    4a2c:      	ldr	w8, [x8]
    4a30:      	cbz	w8, 0x4a74 <perf_unwind_php+0x4a74>
    4a34:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4a38:      	add	x10, x10, #0x0
    4a3c:      	strb	wzr, [sp, #0x48]
    4a40:      	add	x0, sp, #0x18
    4a44:      	ldp	x8, x9, [x10, #0x10]
    4a48:      	mov	w1, #0x31               // =49
    4a4c:      	stp	x8, x9, [sp, #0x28]
    4a50:      	ldp	x8, x9, [x10, #0x20]
    4a54:      	stp	x8, x9, [sp, #0x38]
    4a58:      	ldp	x8, x9, [x10]
    4a5c:      	add	x10, sp, #0x18
    4a60:      	stp	x8, x9, [sp, #0x18]
    4a64:      	mov	w8, #0x31               // =49
    4a68:      	mov	w9, #0x6                // =6
    4a6c:      	ldr	x2, [sp, #0x70]
    4a70:      	blr	x9
    4a74:      	mov	w25, #0x26              // =38
    4a78:      	b	0x4d28 <perf_unwind_php+0x4d28>
    4a7c:      	ldr	w8, [x21, #0x2c0]
    4a80:      	adrp	x29, 0x4000 <perf_unwind_php+0x4000>
    4a84:      	ldr	x29, [x29]
    4a88:      	cmp	w8, #0x7e
    4a8c:      	b.hi	0x394 <perf_unwind_php+0x394>
    4a90:      	add	w9, w8, #0x1
    4a94:      	mov	x10, #-0x2              // =-2
    4a98:      	str	w9, [x21, #0x2c0]
    4a9c:      	mov	w9, #0x18               // =24
    4aa0:      	umaddl	x8, w8, w9, x21
    4aa4:      	add	x9, x8, #0x2d0
    4aa8:      	str	x10, [x8, #0x2d8]
    4aac:      	mov	w10, #0x2               // =2
    4ab0:      	str	xzr, [x8, #0x2d0]
    4ab4:      	strb	w10, [x8, #0x2e0]
    4ab8:      	b	0x4d1c <perf_unwind_php+0x4d1c>
    4abc:      	ldrb	w8, [sp, #0x8c]
    4ac0:      	str	wzr, [sp, #0x88]
    4ac4:      	cmp	w8, #0x4
    4ac8:      	b.eq	0x4ad8 <perf_unwind_php+0x4ad8>
    4acc:      	mov	w29, wzr
    4ad0:      	cmp	w8, #0x2
    4ad4:      	b.ne	0x4c94 <perf_unwind_php+0x4c94>
    4ad8:      	ldrb	w8, [x24, #0x11]
    4adc:      	mov	w9, #0x8                // =8
    4ae0:      	mov	w10, #0x70              // =112
    4ae4:      	add	x11, sp, #0x68
    4ae8:      	add	x0, sp, #0x68
    4aec:      	mov	w1, #0x8                // =8
    4af0:      	add	x8, x25, x8
    4af4:      	ldrb	w8, [x24, #0x11]
    4af8:      	add	x2, x25, x8
    4afc:      	blr	x10
    4b00:      	cbz	x0, 0x4b64 <perf_unwind_php+0x4b64>
    4b04:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4b08:      	ldr	x8, [x8]
    4b0c:      	ldr	w8, [x8]
    4b10:      	cbz	w8, 0x4c30 <perf_unwind_php+0x4c30>
    4b14:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4b18:      	add	x10, x10, #0x0
    4b1c:      	add	x0, sp, #0x18
    4b20:      	ldp	x8, x9, [x10, #0x10]
    4b24:      	mov	w1, #0x2d               // =45
    4b28:      	stp	x8, x9, [sp, #0x28]
    4b2c:      	ldr	x8, [x10, #0x20]
    4b30:      	str	x8, [sp, #0x38]
    4b34:      	ldur	x8, [x10, #0x25]
    4b38:      	stur	x8, [sp, #0x3d]
    4b3c:      	ldp	x8, x9, [x10]
    4b40:      	add	x10, sp, #0x18
    4b44:      	stp	x8, x9, [sp, #0x18]
    4b48:      	mov	w8, #0x2d               // =45
    4b4c:      	mov	w9, #0x6                // =6
    4b50:      	ldrb	w8, [x24, #0x11]
    4b54:      	add	x2, x25, x8
    4b58:      	blr	x9
    4b5c:      	mov	w25, #0x25              // =37
    4b60:      	b	0x4d28 <perf_unwind_php+0x4d28>
    4b64:      	ldr	x8, [sp, #0x68]
    4b68:      	ldrb	w9, [x24, #0x15]
    4b6c:      	mov	w10, #0x70              // =112
    4b70:      	add	x11, sp, #0x88
    4b74:      	add	x0, sp, #0x88
    4b78:      	mov	w1, #0x4                // =4
    4b7c:      	add	x8, x8, x9
    4b80:      	mov	w9, #0x4                // =4
    4b84:      	ldr	x8, [sp, #0x68]
    4b88:      	ldrb	w9, [x24, #0x15]
    4b8c:      	add	x2, x8, x9
    4b90:      	blr	x10
    4b94:      	cbz	x0, 0x4bb0 <perf_unwind_php+0x4bb0>
    4b98:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4b9c:      	ldr	x8, [x8]
    4ba0:      	ldr	w8, [x8]
    4ba4:      	cbnz	w8, 0x4c38 <perf_unwind_php+0x4c38>
    4ba8:      	mov	w25, #0x27              // =39
    4bac:      	b	0x4d28 <perf_unwind_php+0x4d28>
    4bb0:      	ldrb	w8, [x24, #0x13]
    4bb4:      	mov	w9, #0x4                // =4
    4bb8:      	mov	w10, #0x70              // =112
    4bbc:      	add	x11, sp, #0x5c
    4bc0:      	add	x0, sp, #0x5c
    4bc4:      	mov	w1, #0x4                // =4
    4bc8:      	add	x8, x25, x8
    4bcc:      	ldrb	w8, [x24, #0x13]
    4bd0:      	add	x2, x25, x8
    4bd4:      	blr	x10
    4bd8:      	cbz	x0, 0x4c90 <perf_unwind_php+0x4c90>
    4bdc:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4be0:      	ldr	x8, [x8]
    4be4:      	ldr	w8, [x8]
    4be8:      	cbz	w8, 0x4c30 <perf_unwind_php+0x4c30>
    4bec:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4bf0:      	add	x10, x10, #0x0
    4bf4:      	mov	w11, #0x6               // =6
    4bf8:      	ldp	x8, x9, [x10, #0x20]
    4bfc:      	add	x0, sp, #0x18
    4c00:      	mov	w1, #0x35               // =53
    4c04:      	mov	x2, x25
    4c08:      	stp	x8, x9, [sp, #0x38]
    4c0c:      	ldur	x8, [x10, #0x2d]
    4c10:      	stur	x8, [sp, #0x45]
    4c14:      	ldp	x8, x9, [x10]
    4c18:      	stp	x8, x9, [sp, #0x18]
    4c1c:      	ldp	x9, x8, [x10, #0x10]
    4c20:      	mov	w10, #0x35              // =53
    4c24:      	stp	x9, x8, [sp, #0x28]
    4c28:      	add	x8, sp, #0x18
    4c2c:      	blr	x11
    4c30:      	mov	w25, #0x25              // =37
    4c34:      	b	0x4d28 <perf_unwind_php+0x4d28>
    4c38:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4c3c:      	add	x10, x10, #0x0
    4c40:      	strb	wzr, [sp, #0x50]
    4c44:      	add	x0, sp, #0x18
    4c48:      	ldp	x8, x9, [x10, #0x20]
    4c4c:      	mov	w1, #0x39               // =57
    4c50:      	stp	x8, x9, [sp, #0x38]
    4c54:      	ldr	x8, [x10, #0x30]
    4c58:      	str	x8, [sp, #0x48]
    4c5c:      	ldp	x8, x9, [x10]
    4c60:      	stp	x8, x9, [sp, #0x18]
    4c64:      	ldp	x9, x8, [x10, #0x10]
    4c68:      	add	x10, sp, #0x18
    4c6c:      	stp	x9, x8, [sp, #0x28]
    4c70:      	mov	w8, #0x39               // =57
    4c74:      	mov	w9, #0x6                // =6
    4c78:      	ldr	x8, [sp, #0x68]
    4c7c:      	ldrb	w10, [x24, #0x15]
    4c80:      	add	x2, x8, x10
    4c84:      	blr	x9
    4c88:      	mov	w25, #0x27              // =39
    4c8c:      	b	0x4d28 <perf_unwind_php+0x4d28>
    4c90:      	ldr	w29, [sp, #0x88]
    4c94:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4c98:      	ldr	w25, [sp, #0x5c]
    4c9c:      	ldr	x8, [x8]
    4ca0:      	ldr	w8, [x8]
    4ca4:      	cbz	w8, 0x4ce0 <perf_unwind_php+0x4ce0>
    4ca8:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4cac:      	add	x10, x10, #0x0
    4cb0:      	add	x0, sp, #0x18
    4cb4:      	ldp	x8, x9, [x10]
    4cb8:      	mov	w1, #0x16               // =22
    4cbc:      	stp	x8, x9, [sp, #0x18]
    4cc0:      	ldur	x8, [x10, #0xe]
    4cc4:      	mov	w9, #0x6                // =6
    4cc8:      	add	x10, sp, #0x18
    4ccc:      	stur	x8, [sp, #0x26]
    4cd0:      	mov	w8, #0x16               // =22
    4cd4:      	ldr	x2, [sp, #0x70]
    4cd8:      	ldr	w3, [sp, #0x88]
    4cdc:      	blr	x9
    4ce0:      	ldr	w8, [x21, #0x2c0]
    4ce4:      	cmp	w8, #0x7e
    4ce8:      	b.hi	0x82c <perf_unwind_php+0x82c>
    4cec:      	add	w9, w8, #0x1
    4cf0:      	mov	w10, w29
    4cf4:      	str	w9, [x21, #0x2c0]
    4cf8:      	mov	w9, #0x18               // =24
    4cfc:      	orr	x10, x10, x25, lsl #32
    4d00:      	umaddl	x8, w8, w9, x21
    4d04:      	ldr	x9, [sp, #0x70]
    4d08:      	str	x10, [x8, #0x2d8]
    4d0c:      	str	x9, [x8, #0x2d0]
    4d10:      	ldr	w9, [sp, #0xc]
    4d14:      	strb	w9, [x8, #0x2e0]
    4d18:      	add	x9, x8, #0x2d0
    4d1c:      	mov	w25, #0x23              // =35
    4d20:      	str	wzr, [x8, #0x2e4]
    4d24:      	stur	wzr, [x9, #0x11]
    4d28:      	str	w25, [sp, #0x70]
    4d2c:      	mov	w8, #0x1                // =1
    4d30:      	add	x9, sp, #0x70
    4d34:      	add	x1, sp, #0x70
    4d38:      	mov	x0, x23
    4d3c:      	blr	x8
    4d40:      	cbz	x0, 0x4d54 <perf_unwind_php+0x4d54>
    4d44:      	ldr	x8, [x0]
    4d48:      	add	x8, x8, #0x1
    4d4c:      	str	x8, [x0]
    4d50:      	b	0x4da8 <perf_unwind_php+0x4da8>
    4d54:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4d58:      	ldr	x8, [x8]
    4d5c:      	ldr	w8, [x8]
    4d60:      	cbz	w8, 0x4da8 <perf_unwind_php+0x4da8>
    4d64:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4d68:      	add	x8, x8, #0x0
    4d6c:      	add	x0, sp, #0x18
    4d70:      	ldp	x9, x10, [x8, #0x10]
    4d74:      	mov	w1, #0x2e               // =46
    4d78:      	stp	x9, x10, [sp, #0x28]
    4d7c:      	ldr	x9, [x8, #0x20]
    4d80:      	add	x10, sp, #0x18
    4d84:      	str	x9, [sp, #0x38]
    4d88:      	ldur	x9, [x8, #0x26]
    4d8c:      	stur	x9, [sp, #0x3e]
    4d90:      	ldp	x9, x8, [x8]
    4d94:      	stp	x9, x8, [sp, #0x18]
    4d98:      	mov	w8, #0x2e               // =46
    4d9c:      	mov	w9, #0x6                // =6
    4da0:      	ldr	w2, [sp, #0x70]
    4da4:      	blr	x9
    4da8:      	cmp	w25, #0x23
    4dac:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    4db0:      	ldr	x8, [sp, #0x60]
    4db4:      	ldrb	w9, [x24, #0x12]
    4db8:      	mov	w10, #0x70              // =112
    4dbc:      	add	x11, sp, #0x60
    4dc0:      	add	x0, sp, #0x60
    4dc4:      	mov	w1, #0x8                // =8
    4dc8:      	add	x8, x8, x9
    4dcc:      	mov	w9, #0x8                // =8
    4dd0:      	ldr	x8, [sp, #0x60]
    4dd4:      	ldrb	w9, [x24, #0x12]
    4dd8:      	add	x2, x8, x9
    4ddc:      	blr	x10
    4de0:      	adrp	x29, 0x4000 <perf_unwind_php+0x4000>
    4de4:      	ldr	x29, [x29]
    4de8:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    4dec:      	ldr	x25, [sp, #0x60]
    4df0:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    4df4:      	ldrb	w8, [sp, #0x5e]
    4df8:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    4dfc:      	ldrb	w8, [x24, #0x10]
    4e00:      	mov	w9, #0x8                // =8
    4e04:      	mov	w10, #0x70              // =112
    4e08:      	add	x11, sp, #0x70
    4e0c:      	add	x0, sp, #0x70
    4e10:      	mov	w1, #0x8                // =8
    4e14:      	add	x8, x25, x8
    4e18:      	ldrb	w8, [x24, #0x10]
    4e1c:      	add	x2, x25, x8
    4e20:      	blr	x10
    4e24:      	cbz	x0, 0x4e8c <perf_unwind_php+0x4e8c>
    4e28:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4e2c:      	ldr	x8, [x8]
    4e30:      	ldr	w8, [x8]
    4e34:      	cbz	w8, 0x50d0 <perf_unwind_php+0x50d0>
    4e38:      	mov	w8, #0x2978             // =10616
    4e3c:      	add	x0, sp, #0x18
    4e40:      	mov	w1, #0x33               // =51
    4e44:      	movk	w8, #0xa, lsl #16
    4e48:      	stur	w8, [sp, #0x47]
    4e4c:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4e50:      	add	x8, x8, #0x0
    4e54:      	ldp	x9, x10, [x8, #0x10]
    4e58:      	stp	x9, x10, [sp, #0x28]
    4e5c:      	ldp	x9, x10, [x8, #0x20]
    4e60:      	stp	x9, x10, [sp, #0x38]
    4e64:      	ldp	x9, x8, [x8]
    4e68:      	add	x10, sp, #0x18
    4e6c:      	stp	x9, x8, [sp, #0x18]
    4e70:      	mov	w8, #0x33               // =51
    4e74:      	mov	w9, #0x6                // =6
    4e78:      	ldrb	w8, [x24, #0x10]
    4e7c:      	add	x2, x25, x8
    4e80:      	blr	x9
    4e84:      	mov	w25, #0x25              // =37
    4e88:      	b	0x51c8 <perf_unwind_php+0x51c8>
    4e8c:      	ldr	x8, [sp, #0x70]
    4e90:      	cbz	x8, 0x4f1c <perf_unwind_php+0x4f1c>
    4e94:      	ldrb	w9, [x24, #0x14]
    4e98:      	mov	w10, #0x70              // =112
    4e9c:      	add	x11, sp, #0x8c
    4ea0:      	add	x0, sp, #0x8c
    4ea4:      	mov	w1, #0x1                // =1
    4ea8:      	add	x8, x8, x9
    4eac:      	mov	w9, #0x1                // =1
    4eb0:      	ldr	x8, [sp, #0x70]
    4eb4:      	ldrb	w9, [x24, #0x14]
    4eb8:      	add	x2, x8, x9
    4ebc:      	blr	x10
    4ec0:      	cbz	x0, 0x4f5c <perf_unwind_php+0x4f5c>
    4ec4:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4ec8:      	ldr	x8, [x8]
    4ecc:      	ldr	w8, [x8]
    4ed0:      	cbz	w8, 0x4f14 <perf_unwind_php+0x4f14>
    4ed4:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4ed8:      	add	x10, x10, #0x0
    4edc:      	strb	wzr, [sp, #0x48]
    4ee0:      	add	x0, sp, #0x18
    4ee4:      	ldp	x8, x9, [x10, #0x10]
    4ee8:      	mov	w1, #0x31               // =49
    4eec:      	stp	x8, x9, [sp, #0x28]
    4ef0:      	ldp	x8, x9, [x10, #0x20]
    4ef4:      	stp	x8, x9, [sp, #0x38]
    4ef8:      	ldp	x8, x9, [x10]
    4efc:      	add	x10, sp, #0x18
    4f00:      	stp	x8, x9, [sp, #0x18]
    4f04:      	mov	w8, #0x31               // =49
    4f08:      	mov	w9, #0x6                // =6
    4f0c:      	ldr	x2, [sp, #0x70]
    4f10:      	blr	x9
    4f14:      	mov	w25, #0x26              // =38
    4f18:      	b	0x51c8 <perf_unwind_php+0x51c8>
    4f1c:      	ldr	w8, [x21, #0x2c0]
    4f20:      	adrp	x29, 0x4000 <perf_unwind_php+0x4000>
    4f24:      	ldr	x29, [x29]
    4f28:      	cmp	w8, #0x7e
    4f2c:      	b.hi	0x394 <perf_unwind_php+0x394>
    4f30:      	add	w9, w8, #0x1
    4f34:      	mov	x10, #-0x2              // =-2
    4f38:      	str	w9, [x21, #0x2c0]
    4f3c:      	mov	w9, #0x18               // =24
    4f40:      	umaddl	x8, w8, w9, x21
    4f44:      	add	x9, x8, #0x2d0
    4f48:      	str	x10, [x8, #0x2d8]
    4f4c:      	mov	w10, #0x2               // =2
    4f50:      	str	xzr, [x8, #0x2d0]
    4f54:      	strb	w10, [x8, #0x2e0]
    4f58:      	b	0x51bc <perf_unwind_php+0x51bc>
    4f5c:      	ldrb	w8, [sp, #0x8c]
    4f60:      	str	wzr, [sp, #0x88]
    4f64:      	cmp	w8, #0x4
    4f68:      	b.eq	0x4f78 <perf_unwind_php+0x4f78>
    4f6c:      	mov	w29, wzr
    4f70:      	cmp	w8, #0x2
    4f74:      	b.ne	0x5134 <perf_unwind_php+0x5134>
    4f78:      	ldrb	w8, [x24, #0x11]
    4f7c:      	mov	w9, #0x8                // =8
    4f80:      	mov	w10, #0x70              // =112
    4f84:      	add	x11, sp, #0x68
    4f88:      	add	x0, sp, #0x68
    4f8c:      	mov	w1, #0x8                // =8
    4f90:      	add	x8, x25, x8
    4f94:      	ldrb	w8, [x24, #0x11]
    4f98:      	add	x2, x25, x8
    4f9c:      	blr	x10
    4fa0:      	cbz	x0, 0x5004 <perf_unwind_php+0x5004>
    4fa4:      	adrp	x8, 0x4000 <perf_unwind_php+0x4000>
    4fa8:      	ldr	x8, [x8]
    4fac:      	ldr	w8, [x8]
    4fb0:      	cbz	w8, 0x50d0 <perf_unwind_php+0x50d0>
    4fb4:      	adrp	x10, 0x4000 <perf_unwind_php+0x4000>
    4fb8:      	add	x10, x10, #0x0
    4fbc:      	add	x0, sp, #0x18
    4fc0:      	ldp	x8, x9, [x10, #0x10]
    4fc4:      	mov	w1, #0x2d               // =45
    4fc8:      	stp	x8, x9, [sp, #0x28]
    4fcc:      	ldr	x8, [x10, #0x20]
    4fd0:      	str	x8, [sp, #0x38]
    4fd4:      	ldur	x8, [x10, #0x25]
    4fd8:      	stur	x8, [sp, #0x3d]
    4fdc:      	ldp	x8, x9, [x10]
    4fe0:      	add	x10, sp, #0x18
    4fe4:      	stp	x8, x9, [sp, #0x18]
    4fe8:      	mov	w8, #0x2d               // =45
    4fec:      	mov	w9, #0x6                // =6
    4ff0:      	ldrb	w8, [x24, #0x11]
    4ff4:      	add	x2, x25, x8
    4ff8:      	blr	x9
    4ffc:      	mov	w25, #0x25              // =37
    5000:      	b	0x51c8 <perf_unwind_php+0x51c8>
    5004:      	ldr	x8, [sp, #0x68]
    5008:      	ldrb	w9, [x24, #0x15]
    500c:      	mov	w10, #0x70              // =112
    5010:      	add	x11, sp, #0x88
    5014:      	add	x0, sp, #0x88
    5018:      	mov	w1, #0x4                // =4
    501c:      	add	x8, x8, x9
    5020:      	mov	w9, #0x4                // =4
    5024:      	ldr	x8, [sp, #0x68]
    5028:      	ldrb	w9, [x24, #0x15]
    502c:      	add	x2, x8, x9
    5030:      	blr	x10
    5034:      	cbz	x0, 0x5050 <perf_unwind_php+0x5050>
    5038:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    503c:      	ldr	x8, [x8]
    5040:      	ldr	w8, [x8]
    5044:      	cbnz	w8, 0x50d8 <perf_unwind_php+0x50d8>
    5048:      	mov	w25, #0x27              // =39
    504c:      	b	0x51c8 <perf_unwind_php+0x51c8>
    5050:      	ldrb	w8, [x24, #0x13]
    5054:      	mov	w9, #0x4                // =4
    5058:      	mov	w10, #0x70              // =112
    505c:      	add	x11, sp, #0x5c
    5060:      	add	x0, sp, #0x5c
    5064:      	mov	w1, #0x4                // =4
    5068:      	add	x8, x25, x8
    506c:      	ldrb	w8, [x24, #0x13]
    5070:      	add	x2, x25, x8
    5074:      	blr	x10
    5078:      	cbz	x0, 0x5130 <perf_unwind_php+0x5130>
    507c:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5080:      	ldr	x8, [x8]
    5084:      	ldr	w8, [x8]
    5088:      	cbz	w8, 0x50d0 <perf_unwind_php+0x50d0>
    508c:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5090:      	add	x10, x10, #0x0
    5094:      	mov	w11, #0x6               // =6
    5098:      	ldp	x8, x9, [x10, #0x20]
    509c:      	add	x0, sp, #0x18
    50a0:      	mov	w1, #0x35               // =53
    50a4:      	mov	x2, x25
    50a8:      	stp	x8, x9, [sp, #0x38]
    50ac:      	ldur	x8, [x10, #0x2d]
    50b0:      	stur	x8, [sp, #0x45]
    50b4:      	ldp	x8, x9, [x10]
    50b8:      	stp	x8, x9, [sp, #0x18]
    50bc:      	ldp	x9, x8, [x10, #0x10]
    50c0:      	mov	w10, #0x35              // =53
    50c4:      	stp	x9, x8, [sp, #0x28]
    50c8:      	add	x8, sp, #0x18
    50cc:      	blr	x11
    50d0:      	mov	w25, #0x25              // =37
    50d4:      	b	0x51c8 <perf_unwind_php+0x51c8>
    50d8:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    50dc:      	add	x10, x10, #0x0
    50e0:      	strb	wzr, [sp, #0x50]
    50e4:      	add	x0, sp, #0x18
    50e8:      	ldp	x8, x9, [x10, #0x20]
    50ec:      	mov	w1, #0x39               // =57
    50f0:      	stp	x8, x9, [sp, #0x38]
    50f4:      	ldr	x8, [x10, #0x30]
    50f8:      	str	x8, [sp, #0x48]
    50fc:      	ldp	x8, x9, [x10]
    5100:      	stp	x8, x9, [sp, #0x18]
    5104:      	ldp	x9, x8, [x10, #0x10]
    5108:      	add	x10, sp, #0x18
    510c:      	stp	x9, x8, [sp, #0x28]
    5110:      	mov	w8, #0x39               // =57
    5114:      	mov	w9, #0x6                // =6
    5118:      	ldr	x8, [sp, #0x68]
    511c:      	ldrb	w10, [x24, #0x15]
    5120:      	add	x2, x8, x10
    5124:      	blr	x9
    5128:      	mov	w25, #0x27              // =39
    512c:      	b	0x51c8 <perf_unwind_php+0x51c8>
    5130:      	ldr	w29, [sp, #0x88]
    5134:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5138:      	ldr	w25, [sp, #0x5c]
    513c:      	ldr	x8, [x8]
    5140:      	ldr	w8, [x8]
    5144:      	cbz	w8, 0x5180 <perf_unwind_php+0x5180>
    5148:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    514c:      	add	x10, x10, #0x0
    5150:      	add	x0, sp, #0x18
    5154:      	ldp	x8, x9, [x10]
    5158:      	mov	w1, #0x16               // =22
    515c:      	stp	x8, x9, [sp, #0x18]
    5160:      	ldur	x8, [x10, #0xe]
    5164:      	mov	w9, #0x6                // =6
    5168:      	add	x10, sp, #0x18
    516c:      	stur	x8, [sp, #0x26]
    5170:      	mov	w8, #0x16               // =22
    5174:      	ldr	x2, [sp, #0x70]
    5178:      	ldr	w3, [sp, #0x88]
    517c:      	blr	x9
    5180:      	ldr	w8, [x21, #0x2c0]
    5184:      	cmp	w8, #0x7e
    5188:      	b.hi	0x82c <perf_unwind_php+0x82c>
    518c:      	add	w9, w8, #0x1
    5190:      	mov	w10, w29
    5194:      	str	w9, [x21, #0x2c0]
    5198:      	mov	w9, #0x18               // =24
    519c:      	orr	x10, x10, x25, lsl #32
    51a0:      	umaddl	x8, w8, w9, x21
    51a4:      	ldr	x9, [sp, #0x70]
    51a8:      	str	x10, [x8, #0x2d8]
    51ac:      	str	x9, [x8, #0x2d0]
    51b0:      	ldr	w9, [sp, #0xc]
    51b4:      	strb	w9, [x8, #0x2e0]
    51b8:      	add	x9, x8, #0x2d0
    51bc:      	mov	w25, #0x23              // =35
    51c0:      	str	wzr, [x8, #0x2e4]
    51c4:      	stur	wzr, [x9, #0x11]
    51c8:      	str	w25, [sp, #0x70]
    51cc:      	mov	w8, #0x1                // =1
    51d0:      	add	x9, sp, #0x70
    51d4:      	add	x1, sp, #0x70
    51d8:      	mov	x0, x23
    51dc:      	blr	x8
    51e0:      	cbz	x0, 0x51f4 <perf_unwind_php+0x51f4>
    51e4:      	ldr	x8, [x0]
    51e8:      	add	x8, x8, #0x1
    51ec:      	str	x8, [x0]
    51f0:      	b	0x5248 <perf_unwind_php+0x5248>
    51f4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    51f8:      	ldr	x8, [x8]
    51fc:      	ldr	w8, [x8]
    5200:      	cbz	w8, 0x5248 <perf_unwind_php+0x5248>
    5204:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5208:      	add	x8, x8, #0x0
    520c:      	add	x0, sp, #0x18
    5210:      	ldp	x9, x10, [x8, #0x10]
    5214:      	mov	w1, #0x2e               // =46
    5218:      	stp	x9, x10, [sp, #0x28]
    521c:      	ldr	x9, [x8, #0x20]
    5220:      	add	x10, sp, #0x18
    5224:      	str	x9, [sp, #0x38]
    5228:      	ldur	x9, [x8, #0x26]
    522c:      	stur	x9, [sp, #0x3e]
    5230:      	ldp	x9, x8, [x8]
    5234:      	stp	x9, x8, [sp, #0x18]
    5238:      	mov	w8, #0x2e               // =46
    523c:      	mov	w9, #0x6                // =6
    5240:      	ldr	w2, [sp, #0x70]
    5244:      	blr	x9
    5248:      	cmp	w25, #0x23
    524c:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    5250:      	ldr	x8, [sp, #0x60]
    5254:      	ldrb	w9, [x24, #0x12]
    5258:      	mov	w10, #0x70              // =112
    525c:      	add	x11, sp, #0x60
    5260:      	add	x0, sp, #0x60
    5264:      	mov	w1, #0x8                // =8
    5268:      	add	x8, x8, x9
    526c:      	mov	w9, #0x8                // =8
    5270:      	ldr	x8, [sp, #0x60]
    5274:      	ldrb	w9, [x24, #0x12]
    5278:      	add	x2, x8, x9
    527c:      	blr	x10
    5280:      	adrp	x29, 0x5000 <perf_unwind_php+0x5000>
    5284:      	ldr	x29, [x29]
    5288:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    528c:      	ldr	x25, [sp, #0x60]
    5290:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    5294:      	ldrb	w8, [sp, #0x5e]
    5298:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    529c:      	ldrb	w8, [x24, #0x10]
    52a0:      	mov	w9, #0x8                // =8
    52a4:      	mov	w10, #0x70              // =112
    52a8:      	add	x11, sp, #0x70
    52ac:      	add	x0, sp, #0x70
    52b0:      	mov	w1, #0x8                // =8
    52b4:      	add	x8, x25, x8
    52b8:      	ldrb	w8, [x24, #0x10]
    52bc:      	add	x2, x25, x8
    52c0:      	blr	x10
    52c4:      	cbz	x0, 0x532c <perf_unwind_php+0x532c>
    52c8:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    52cc:      	ldr	x8, [x8]
    52d0:      	ldr	w8, [x8]
    52d4:      	cbz	w8, 0x5570 <perf_unwind_php+0x5570>
    52d8:      	mov	w8, #0x2978             // =10616
    52dc:      	add	x0, sp, #0x18
    52e0:      	mov	w1, #0x33               // =51
    52e4:      	movk	w8, #0xa, lsl #16
    52e8:      	stur	w8, [sp, #0x47]
    52ec:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    52f0:      	add	x8, x8, #0x0
    52f4:      	ldp	x9, x10, [x8, #0x10]
    52f8:      	stp	x9, x10, [sp, #0x28]
    52fc:      	ldp	x9, x10, [x8, #0x20]
    5300:      	stp	x9, x10, [sp, #0x38]
    5304:      	ldp	x9, x8, [x8]
    5308:      	add	x10, sp, #0x18
    530c:      	stp	x9, x8, [sp, #0x18]
    5310:      	mov	w8, #0x33               // =51
    5314:      	mov	w9, #0x6                // =6
    5318:      	ldrb	w8, [x24, #0x10]
    531c:      	add	x2, x25, x8
    5320:      	blr	x9
    5324:      	mov	w25, #0x25              // =37
    5328:      	b	0x5668 <perf_unwind_php+0x5668>
    532c:      	ldr	x8, [sp, #0x70]
    5330:      	cbz	x8, 0x53bc <perf_unwind_php+0x53bc>
    5334:      	ldrb	w9, [x24, #0x14]
    5338:      	mov	w10, #0x70              // =112
    533c:      	add	x11, sp, #0x8c
    5340:      	add	x0, sp, #0x8c
    5344:      	mov	w1, #0x1                // =1
    5348:      	add	x8, x8, x9
    534c:      	mov	w9, #0x1                // =1
    5350:      	ldr	x8, [sp, #0x70]
    5354:      	ldrb	w9, [x24, #0x14]
    5358:      	add	x2, x8, x9
    535c:      	blr	x10
    5360:      	cbz	x0, 0x53fc <perf_unwind_php+0x53fc>
    5364:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5368:      	ldr	x8, [x8]
    536c:      	ldr	w8, [x8]
    5370:      	cbz	w8, 0x53b4 <perf_unwind_php+0x53b4>
    5374:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5378:      	add	x10, x10, #0x0
    537c:      	strb	wzr, [sp, #0x48]
    5380:      	add	x0, sp, #0x18
    5384:      	ldp	x8, x9, [x10, #0x10]
    5388:      	mov	w1, #0x31               // =49
    538c:      	stp	x8, x9, [sp, #0x28]
    5390:      	ldp	x8, x9, [x10, #0x20]
    5394:      	stp	x8, x9, [sp, #0x38]
    5398:      	ldp	x8, x9, [x10]
    539c:      	add	x10, sp, #0x18
    53a0:      	stp	x8, x9, [sp, #0x18]
    53a4:      	mov	w8, #0x31               // =49
    53a8:      	mov	w9, #0x6                // =6
    53ac:      	ldr	x2, [sp, #0x70]
    53b0:      	blr	x9
    53b4:      	mov	w25, #0x26              // =38
    53b8:      	b	0x5668 <perf_unwind_php+0x5668>
    53bc:      	ldr	w8, [x21, #0x2c0]
    53c0:      	adrp	x29, 0x5000 <perf_unwind_php+0x5000>
    53c4:      	ldr	x29, [x29]
    53c8:      	cmp	w8, #0x7e
    53cc:      	b.hi	0x394 <perf_unwind_php+0x394>
    53d0:      	add	w9, w8, #0x1
    53d4:      	mov	x10, #-0x2              // =-2
    53d8:      	str	w9, [x21, #0x2c0]
    53dc:      	mov	w9, #0x18               // =24
    53e0:      	umaddl	x8, w8, w9, x21
    53e4:      	add	x9, x8, #0x2d0
    53e8:      	str	x10, [x8, #0x2d8]
    53ec:      	mov	w10, #0x2               // =2
    53f0:      	str	xzr, [x8, #0x2d0]
    53f4:      	strb	w10, [x8, #0x2e0]
    53f8:      	b	0x565c <perf_unwind_php+0x565c>
    53fc:      	ldrb	w8, [sp, #0x8c]
    5400:      	str	wzr, [sp, #0x88]
    5404:      	cmp	w8, #0x4
    5408:      	b.eq	0x5418 <perf_unwind_php+0x5418>
    540c:      	mov	w29, wzr
    5410:      	cmp	w8, #0x2
    5414:      	b.ne	0x55d4 <perf_unwind_php+0x55d4>
    5418:      	ldrb	w8, [x24, #0x11]
    541c:      	mov	w9, #0x8                // =8
    5420:      	mov	w10, #0x70              // =112
    5424:      	add	x11, sp, #0x68
    5428:      	add	x0, sp, #0x68
    542c:      	mov	w1, #0x8                // =8
    5430:      	add	x8, x25, x8
    5434:      	ldrb	w8, [x24, #0x11]
    5438:      	add	x2, x25, x8
    543c:      	blr	x10
    5440:      	cbz	x0, 0x54a4 <perf_unwind_php+0x54a4>
    5444:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5448:      	ldr	x8, [x8]
    544c:      	ldr	w8, [x8]
    5450:      	cbz	w8, 0x5570 <perf_unwind_php+0x5570>
    5454:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5458:      	add	x10, x10, #0x0
    545c:      	add	x0, sp, #0x18
    5460:      	ldp	x8, x9, [x10, #0x10]
    5464:      	mov	w1, #0x2d               // =45
    5468:      	stp	x8, x9, [sp, #0x28]
    546c:      	ldr	x8, [x10, #0x20]
    5470:      	str	x8, [sp, #0x38]
    5474:      	ldur	x8, [x10, #0x25]
    5478:      	stur	x8, [sp, #0x3d]
    547c:      	ldp	x8, x9, [x10]
    5480:      	add	x10, sp, #0x18
    5484:      	stp	x8, x9, [sp, #0x18]
    5488:      	mov	w8, #0x2d               // =45
    548c:      	mov	w9, #0x6                // =6
    5490:      	ldrb	w8, [x24, #0x11]
    5494:      	add	x2, x25, x8
    5498:      	blr	x9
    549c:      	mov	w25, #0x25              // =37
    54a0:      	b	0x5668 <perf_unwind_php+0x5668>
    54a4:      	ldr	x8, [sp, #0x68]
    54a8:      	ldrb	w9, [x24, #0x15]
    54ac:      	mov	w10, #0x70              // =112
    54b0:      	add	x11, sp, #0x88
    54b4:      	add	x0, sp, #0x88
    54b8:      	mov	w1, #0x4                // =4
    54bc:      	add	x8, x8, x9
    54c0:      	mov	w9, #0x4                // =4
    54c4:      	ldr	x8, [sp, #0x68]
    54c8:      	ldrb	w9, [x24, #0x15]
    54cc:      	add	x2, x8, x9
    54d0:      	blr	x10
    54d4:      	cbz	x0, 0x54f0 <perf_unwind_php+0x54f0>
    54d8:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    54dc:      	ldr	x8, [x8]
    54e0:      	ldr	w8, [x8]
    54e4:      	cbnz	w8, 0x5578 <perf_unwind_php+0x5578>
    54e8:      	mov	w25, #0x27              // =39
    54ec:      	b	0x5668 <perf_unwind_php+0x5668>
    54f0:      	ldrb	w8, [x24, #0x13]
    54f4:      	mov	w9, #0x4                // =4
    54f8:      	mov	w10, #0x70              // =112
    54fc:      	add	x11, sp, #0x5c
    5500:      	add	x0, sp, #0x5c
    5504:      	mov	w1, #0x4                // =4
    5508:      	add	x8, x25, x8
    550c:      	ldrb	w8, [x24, #0x13]
    5510:      	add	x2, x25, x8
    5514:      	blr	x10
    5518:      	cbz	x0, 0x55d0 <perf_unwind_php+0x55d0>
    551c:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5520:      	ldr	x8, [x8]
    5524:      	ldr	w8, [x8]
    5528:      	cbz	w8, 0x5570 <perf_unwind_php+0x5570>
    552c:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5530:      	add	x10, x10, #0x0
    5534:      	mov	w11, #0x6               // =6
    5538:      	ldp	x8, x9, [x10, #0x20]
    553c:      	add	x0, sp, #0x18
    5540:      	mov	w1, #0x35               // =53
    5544:      	mov	x2, x25
    5548:      	stp	x8, x9, [sp, #0x38]
    554c:      	ldur	x8, [x10, #0x2d]
    5550:      	stur	x8, [sp, #0x45]
    5554:      	ldp	x8, x9, [x10]
    5558:      	stp	x8, x9, [sp, #0x18]
    555c:      	ldp	x9, x8, [x10, #0x10]
    5560:      	mov	w10, #0x35              // =53
    5564:      	stp	x9, x8, [sp, #0x28]
    5568:      	add	x8, sp, #0x18
    556c:      	blr	x11
    5570:      	mov	w25, #0x25              // =37
    5574:      	b	0x5668 <perf_unwind_php+0x5668>
    5578:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    557c:      	add	x10, x10, #0x0
    5580:      	strb	wzr, [sp, #0x50]
    5584:      	add	x0, sp, #0x18
    5588:      	ldp	x8, x9, [x10, #0x20]
    558c:      	mov	w1, #0x39               // =57
    5590:      	stp	x8, x9, [sp, #0x38]
    5594:      	ldr	x8, [x10, #0x30]
    5598:      	str	x8, [sp, #0x48]
    559c:      	ldp	x8, x9, [x10]
    55a0:      	stp	x8, x9, [sp, #0x18]
    55a4:      	ldp	x9, x8, [x10, #0x10]
    55a8:      	add	x10, sp, #0x18
    55ac:      	stp	x9, x8, [sp, #0x28]
    55b0:      	mov	w8, #0x39               // =57
    55b4:      	mov	w9, #0x6                // =6
    55b8:      	ldr	x8, [sp, #0x68]
    55bc:      	ldrb	w10, [x24, #0x15]
    55c0:      	add	x2, x8, x10
    55c4:      	blr	x9
    55c8:      	mov	w25, #0x27              // =39
    55cc:      	b	0x5668 <perf_unwind_php+0x5668>
    55d0:      	ldr	w29, [sp, #0x88]
    55d4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    55d8:      	ldr	w25, [sp, #0x5c]
    55dc:      	ldr	x8, [x8]
    55e0:      	ldr	w8, [x8]
    55e4:      	cbz	w8, 0x5620 <perf_unwind_php+0x5620>
    55e8:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    55ec:      	add	x10, x10, #0x0
    55f0:      	add	x0, sp, #0x18
    55f4:      	ldp	x8, x9, [x10]
    55f8:      	mov	w1, #0x16               // =22
    55fc:      	stp	x8, x9, [sp, #0x18]
    5600:      	ldur	x8, [x10, #0xe]
    5604:      	mov	w9, #0x6                // =6
    5608:      	add	x10, sp, #0x18
    560c:      	stur	x8, [sp, #0x26]
    5610:      	mov	w8, #0x16               // =22
    5614:      	ldr	x2, [sp, #0x70]
    5618:      	ldr	w3, [sp, #0x88]
    561c:      	blr	x9
    5620:      	ldr	w8, [x21, #0x2c0]
    5624:      	cmp	w8, #0x7e
    5628:      	b.hi	0x82c <perf_unwind_php+0x82c>
    562c:      	add	w9, w8, #0x1
    5630:      	mov	w10, w29
    5634:      	str	w9, [x21, #0x2c0]
    5638:      	mov	w9, #0x18               // =24
    563c:      	orr	x10, x10, x25, lsl #32
    5640:      	umaddl	x8, w8, w9, x21
    5644:      	ldr	x9, [sp, #0x70]
    5648:      	str	x10, [x8, #0x2d8]
    564c:      	str	x9, [x8, #0x2d0]
    5650:      	ldr	w9, [sp, #0xc]
    5654:      	strb	w9, [x8, #0x2e0]
    5658:      	add	x9, x8, #0x2d0
    565c:      	mov	w25, #0x23              // =35
    5660:      	str	wzr, [x8, #0x2e4]
    5664:      	stur	wzr, [x9, #0x11]
    5668:      	str	w25, [sp, #0x70]
    566c:      	mov	w8, #0x1                // =1
    5670:      	add	x9, sp, #0x70
    5674:      	add	x1, sp, #0x70
    5678:      	mov	x0, x23
    567c:      	blr	x8
    5680:      	cbz	x0, 0x5694 <perf_unwind_php+0x5694>
    5684:      	ldr	x8, [x0]
    5688:      	add	x8, x8, #0x1
    568c:      	str	x8, [x0]
    5690:      	b	0x56e8 <perf_unwind_php+0x56e8>
    5694:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5698:      	ldr	x8, [x8]
    569c:      	ldr	w8, [x8]
    56a0:      	cbz	w8, 0x56e8 <perf_unwind_php+0x56e8>
    56a4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    56a8:      	add	x8, x8, #0x0
    56ac:      	add	x0, sp, #0x18
    56b0:      	ldp	x9, x10, [x8, #0x10]
    56b4:      	mov	w1, #0x2e               // =46
    56b8:      	stp	x9, x10, [sp, #0x28]
    56bc:      	ldr	x9, [x8, #0x20]
    56c0:      	add	x10, sp, #0x18
    56c4:      	str	x9, [sp, #0x38]
    56c8:      	ldur	x9, [x8, #0x26]
    56cc:      	stur	x9, [sp, #0x3e]
    56d0:      	ldp	x9, x8, [x8]
    56d4:      	stp	x9, x8, [sp, #0x18]
    56d8:      	mov	w8, #0x2e               // =46
    56dc:      	mov	w9, #0x6                // =6
    56e0:      	ldr	w2, [sp, #0x70]
    56e4:      	blr	x9
    56e8:      	cmp	w25, #0x23
    56ec:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    56f0:      	ldr	x8, [sp, #0x60]
    56f4:      	ldrb	w9, [x24, #0x12]
    56f8:      	mov	w10, #0x70              // =112
    56fc:      	add	x11, sp, #0x60
    5700:      	add	x0, sp, #0x60
    5704:      	mov	w1, #0x8                // =8
    5708:      	add	x8, x8, x9
    570c:      	mov	w9, #0x8                // =8
    5710:      	ldr	x8, [sp, #0x60]
    5714:      	ldrb	w9, [x24, #0x12]
    5718:      	add	x2, x8, x9
    571c:      	blr	x10
    5720:      	adrp	x29, 0x5000 <perf_unwind_php+0x5000>
    5724:      	ldr	x29, [x29]
    5728:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    572c:      	ldr	x25, [sp, #0x60]
    5730:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    5734:      	ldrb	w8, [sp, #0x5e]
    5738:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    573c:      	ldrb	w8, [x24, #0x10]
    5740:      	mov	w9, #0x8                // =8
    5744:      	mov	w10, #0x70              // =112
    5748:      	add	x11, sp, #0x70
    574c:      	add	x0, sp, #0x70
    5750:      	mov	w1, #0x8                // =8
    5754:      	add	x8, x25, x8
    5758:      	ldrb	w8, [x24, #0x10]
    575c:      	add	x2, x25, x8
    5760:      	blr	x10
    5764:      	cbz	x0, 0x57cc <perf_unwind_php+0x57cc>
    5768:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    576c:      	ldr	x8, [x8]
    5770:      	ldr	w8, [x8]
    5774:      	cbz	w8, 0x5a10 <perf_unwind_php+0x5a10>
    5778:      	mov	w8, #0x2978             // =10616
    577c:      	add	x0, sp, #0x18
    5780:      	mov	w1, #0x33               // =51
    5784:      	movk	w8, #0xa, lsl #16
    5788:      	stur	w8, [sp, #0x47]
    578c:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5790:      	add	x8, x8, #0x0
    5794:      	ldp	x9, x10, [x8, #0x10]
    5798:      	stp	x9, x10, [sp, #0x28]
    579c:      	ldp	x9, x10, [x8, #0x20]
    57a0:      	stp	x9, x10, [sp, #0x38]
    57a4:      	ldp	x9, x8, [x8]
    57a8:      	add	x10, sp, #0x18
    57ac:      	stp	x9, x8, [sp, #0x18]
    57b0:      	mov	w8, #0x33               // =51
    57b4:      	mov	w9, #0x6                // =6
    57b8:      	ldrb	w8, [x24, #0x10]
    57bc:      	add	x2, x25, x8
    57c0:      	blr	x9
    57c4:      	mov	w25, #0x25              // =37
    57c8:      	b	0x5b08 <perf_unwind_php+0x5b08>
    57cc:      	ldr	x8, [sp, #0x70]
    57d0:      	cbz	x8, 0x585c <perf_unwind_php+0x585c>
    57d4:      	ldrb	w9, [x24, #0x14]
    57d8:      	mov	w10, #0x70              // =112
    57dc:      	add	x11, sp, #0x8c
    57e0:      	add	x0, sp, #0x8c
    57e4:      	mov	w1, #0x1                // =1
    57e8:      	add	x8, x8, x9
    57ec:      	mov	w9, #0x1                // =1
    57f0:      	ldr	x8, [sp, #0x70]
    57f4:      	ldrb	w9, [x24, #0x14]
    57f8:      	add	x2, x8, x9
    57fc:      	blr	x10
    5800:      	cbz	x0, 0x589c <perf_unwind_php+0x589c>
    5804:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5808:      	ldr	x8, [x8]
    580c:      	ldr	w8, [x8]
    5810:      	cbz	w8, 0x5854 <perf_unwind_php+0x5854>
    5814:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5818:      	add	x10, x10, #0x0
    581c:      	strb	wzr, [sp, #0x48]
    5820:      	add	x0, sp, #0x18
    5824:      	ldp	x8, x9, [x10, #0x10]
    5828:      	mov	w1, #0x31               // =49
    582c:      	stp	x8, x9, [sp, #0x28]
    5830:      	ldp	x8, x9, [x10, #0x20]
    5834:      	stp	x8, x9, [sp, #0x38]
    5838:      	ldp	x8, x9, [x10]
    583c:      	add	x10, sp, #0x18
    5840:      	stp	x8, x9, [sp, #0x18]
    5844:      	mov	w8, #0x31               // =49
    5848:      	mov	w9, #0x6                // =6
    584c:      	ldr	x2, [sp, #0x70]
    5850:      	blr	x9
    5854:      	mov	w25, #0x26              // =38
    5858:      	b	0x5b08 <perf_unwind_php+0x5b08>
    585c:      	ldr	w8, [x21, #0x2c0]
    5860:      	adrp	x29, 0x5000 <perf_unwind_php+0x5000>
    5864:      	ldr	x29, [x29]
    5868:      	cmp	w8, #0x7e
    586c:      	b.hi	0x394 <perf_unwind_php+0x394>
    5870:      	add	w9, w8, #0x1
    5874:      	mov	x10, #-0x2              // =-2
    5878:      	str	w9, [x21, #0x2c0]
    587c:      	mov	w9, #0x18               // =24
    5880:      	umaddl	x8, w8, w9, x21
    5884:      	add	x9, x8, #0x2d0
    5888:      	str	x10, [x8, #0x2d8]
    588c:      	mov	w10, #0x2               // =2
    5890:      	str	xzr, [x8, #0x2d0]
    5894:      	strb	w10, [x8, #0x2e0]
    5898:      	b	0x5afc <perf_unwind_php+0x5afc>
    589c:      	ldrb	w8, [sp, #0x8c]
    58a0:      	str	wzr, [sp, #0x88]
    58a4:      	cmp	w8, #0x4
    58a8:      	b.eq	0x58b8 <perf_unwind_php+0x58b8>
    58ac:      	mov	w29, wzr
    58b0:      	cmp	w8, #0x2
    58b4:      	b.ne	0x5a74 <perf_unwind_php+0x5a74>
    58b8:      	ldrb	w8, [x24, #0x11]
    58bc:      	mov	w9, #0x8                // =8
    58c0:      	mov	w10, #0x70              // =112
    58c4:      	add	x11, sp, #0x68
    58c8:      	add	x0, sp, #0x68
    58cc:      	mov	w1, #0x8                // =8
    58d0:      	add	x8, x25, x8
    58d4:      	ldrb	w8, [x24, #0x11]
    58d8:      	add	x2, x25, x8
    58dc:      	blr	x10
    58e0:      	cbz	x0, 0x5944 <perf_unwind_php+0x5944>
    58e4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    58e8:      	ldr	x8, [x8]
    58ec:      	ldr	w8, [x8]
    58f0:      	cbz	w8, 0x5a10 <perf_unwind_php+0x5a10>
    58f4:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    58f8:      	add	x10, x10, #0x0
    58fc:      	add	x0, sp, #0x18
    5900:      	ldp	x8, x9, [x10, #0x10]
    5904:      	mov	w1, #0x2d               // =45
    5908:      	stp	x8, x9, [sp, #0x28]
    590c:      	ldr	x8, [x10, #0x20]
    5910:      	str	x8, [sp, #0x38]
    5914:      	ldur	x8, [x10, #0x25]
    5918:      	stur	x8, [sp, #0x3d]
    591c:      	ldp	x8, x9, [x10]
    5920:      	add	x10, sp, #0x18
    5924:      	stp	x8, x9, [sp, #0x18]
    5928:      	mov	w8, #0x2d               // =45
    592c:      	mov	w9, #0x6                // =6
    5930:      	ldrb	w8, [x24, #0x11]
    5934:      	add	x2, x25, x8
    5938:      	blr	x9
    593c:      	mov	w25, #0x25              // =37
    5940:      	b	0x5b08 <perf_unwind_php+0x5b08>
    5944:      	ldr	x8, [sp, #0x68]
    5948:      	ldrb	w9, [x24, #0x15]
    594c:      	mov	w10, #0x70              // =112
    5950:      	add	x11, sp, #0x88
    5954:      	add	x0, sp, #0x88
    5958:      	mov	w1, #0x4                // =4
    595c:      	add	x8, x8, x9
    5960:      	mov	w9, #0x4                // =4
    5964:      	ldr	x8, [sp, #0x68]
    5968:      	ldrb	w9, [x24, #0x15]
    596c:      	add	x2, x8, x9
    5970:      	blr	x10
    5974:      	cbz	x0, 0x5990 <perf_unwind_php+0x5990>
    5978:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    597c:      	ldr	x8, [x8]
    5980:      	ldr	w8, [x8]
    5984:      	cbnz	w8, 0x5a18 <perf_unwind_php+0x5a18>
    5988:      	mov	w25, #0x27              // =39
    598c:      	b	0x5b08 <perf_unwind_php+0x5b08>
    5990:      	ldrb	w8, [x24, #0x13]
    5994:      	mov	w9, #0x4                // =4
    5998:      	mov	w10, #0x70              // =112
    599c:      	add	x11, sp, #0x5c
    59a0:      	add	x0, sp, #0x5c
    59a4:      	mov	w1, #0x4                // =4
    59a8:      	add	x8, x25, x8
    59ac:      	ldrb	w8, [x24, #0x13]
    59b0:      	add	x2, x25, x8
    59b4:      	blr	x10
    59b8:      	cbz	x0, 0x5a70 <perf_unwind_php+0x5a70>
    59bc:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    59c0:      	ldr	x8, [x8]
    59c4:      	ldr	w8, [x8]
    59c8:      	cbz	w8, 0x5a10 <perf_unwind_php+0x5a10>
    59cc:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    59d0:      	add	x10, x10, #0x0
    59d4:      	mov	w11, #0x6               // =6
    59d8:      	ldp	x8, x9, [x10, #0x20]
    59dc:      	add	x0, sp, #0x18
    59e0:      	mov	w1, #0x35               // =53
    59e4:      	mov	x2, x25
    59e8:      	stp	x8, x9, [sp, #0x38]
    59ec:      	ldur	x8, [x10, #0x2d]
    59f0:      	stur	x8, [sp, #0x45]
    59f4:      	ldp	x8, x9, [x10]
    59f8:      	stp	x8, x9, [sp, #0x18]
    59fc:      	ldp	x9, x8, [x10, #0x10]
    5a00:      	mov	w10, #0x35              // =53
    5a04:      	stp	x9, x8, [sp, #0x28]
    5a08:      	add	x8, sp, #0x18
    5a0c:      	blr	x11
    5a10:      	mov	w25, #0x25              // =37
    5a14:      	b	0x5b08 <perf_unwind_php+0x5b08>
    5a18:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5a1c:      	add	x10, x10, #0x0
    5a20:      	strb	wzr, [sp, #0x50]
    5a24:      	add	x0, sp, #0x18
    5a28:      	ldp	x8, x9, [x10, #0x20]
    5a2c:      	mov	w1, #0x39               // =57
    5a30:      	stp	x8, x9, [sp, #0x38]
    5a34:      	ldr	x8, [x10, #0x30]
    5a38:      	str	x8, [sp, #0x48]
    5a3c:      	ldp	x8, x9, [x10]
    5a40:      	stp	x8, x9, [sp, #0x18]
    5a44:      	ldp	x9, x8, [x10, #0x10]
    5a48:      	add	x10, sp, #0x18
    5a4c:      	stp	x9, x8, [sp, #0x28]
    5a50:      	mov	w8, #0x39               // =57
    5a54:      	mov	w9, #0x6                // =6
    5a58:      	ldr	x8, [sp, #0x68]
    5a5c:      	ldrb	w10, [x24, #0x15]
    5a60:      	add	x2, x8, x10
    5a64:      	blr	x9
    5a68:      	mov	w25, #0x27              // =39
    5a6c:      	b	0x5b08 <perf_unwind_php+0x5b08>
    5a70:      	ldr	w29, [sp, #0x88]
    5a74:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5a78:      	ldr	w25, [sp, #0x5c]
    5a7c:      	ldr	x8, [x8]
    5a80:      	ldr	w8, [x8]
    5a84:      	cbz	w8, 0x5ac0 <perf_unwind_php+0x5ac0>
    5a88:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5a8c:      	add	x10, x10, #0x0
    5a90:      	add	x0, sp, #0x18
    5a94:      	ldp	x8, x9, [x10]
    5a98:      	mov	w1, #0x16               // =22
    5a9c:      	stp	x8, x9, [sp, #0x18]
    5aa0:      	ldur	x8, [x10, #0xe]
    5aa4:      	mov	w9, #0x6                // =6
    5aa8:      	add	x10, sp, #0x18
    5aac:      	stur	x8, [sp, #0x26]
    5ab0:      	mov	w8, #0x16               // =22
    5ab4:      	ldr	x2, [sp, #0x70]
    5ab8:      	ldr	w3, [sp, #0x88]
    5abc:      	blr	x9
    5ac0:      	ldr	w8, [x21, #0x2c0]
    5ac4:      	cmp	w8, #0x7e
    5ac8:      	b.hi	0x82c <perf_unwind_php+0x82c>
    5acc:      	add	w9, w8, #0x1
    5ad0:      	mov	w10, w29
    5ad4:      	str	w9, [x21, #0x2c0]
    5ad8:      	mov	w9, #0x18               // =24
    5adc:      	orr	x10, x10, x25, lsl #32
    5ae0:      	umaddl	x8, w8, w9, x21
    5ae4:      	ldr	x9, [sp, #0x70]
    5ae8:      	str	x10, [x8, #0x2d8]
    5aec:      	str	x9, [x8, #0x2d0]
    5af0:      	ldr	w9, [sp, #0xc]
    5af4:      	strb	w9, [x8, #0x2e0]
    5af8:      	add	x9, x8, #0x2d0
    5afc:      	mov	w25, #0x23              // =35
    5b00:      	str	wzr, [x8, #0x2e4]
    5b04:      	stur	wzr, [x9, #0x11]
    5b08:      	str	w25, [sp, #0x70]
    5b0c:      	mov	w8, #0x1                // =1
    5b10:      	add	x9, sp, #0x70
    5b14:      	add	x1, sp, #0x70
    5b18:      	mov	x0, x23
    5b1c:      	blr	x8
    5b20:      	cbz	x0, 0x5b34 <perf_unwind_php+0x5b34>
    5b24:      	ldr	x8, [x0]
    5b28:      	add	x8, x8, #0x1
    5b2c:      	str	x8, [x0]
    5b30:      	b	0x5b88 <perf_unwind_php+0x5b88>
    5b34:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5b38:      	ldr	x8, [x8]
    5b3c:      	ldr	w8, [x8]
    5b40:      	cbz	w8, 0x5b88 <perf_unwind_php+0x5b88>
    5b44:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5b48:      	add	x8, x8, #0x0
    5b4c:      	add	x0, sp, #0x18
    5b50:      	ldp	x9, x10, [x8, #0x10]
    5b54:      	mov	w1, #0x2e               // =46
    5b58:      	stp	x9, x10, [sp, #0x28]
    5b5c:      	ldr	x9, [x8, #0x20]
    5b60:      	add	x10, sp, #0x18
    5b64:      	str	x9, [sp, #0x38]
    5b68:      	ldur	x9, [x8, #0x26]
    5b6c:      	stur	x9, [sp, #0x3e]
    5b70:      	ldp	x9, x8, [x8]
    5b74:      	stp	x9, x8, [sp, #0x18]
    5b78:      	mov	w8, #0x2e               // =46
    5b7c:      	mov	w9, #0x6                // =6
    5b80:      	ldr	w2, [sp, #0x70]
    5b84:      	blr	x9
    5b88:      	cmp	w25, #0x23
    5b8c:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    5b90:      	ldr	x8, [sp, #0x60]
    5b94:      	ldrb	w9, [x24, #0x12]
    5b98:      	mov	w10, #0x70              // =112
    5b9c:      	add	x11, sp, #0x60
    5ba0:      	add	x0, sp, #0x60
    5ba4:      	mov	w1, #0x8                // =8
    5ba8:      	add	x8, x8, x9
    5bac:      	mov	w9, #0x8                // =8
    5bb0:      	ldr	x8, [sp, #0x60]
    5bb4:      	ldrb	w9, [x24, #0x12]
    5bb8:      	add	x2, x8, x9
    5bbc:      	blr	x10
    5bc0:      	adrp	x29, 0x5000 <perf_unwind_php+0x5000>
    5bc4:      	ldr	x29, [x29]
    5bc8:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    5bcc:      	ldr	x25, [sp, #0x60]
    5bd0:      	cbz	x25, 0x6084 <perf_unwind_php+0x6084>
    5bd4:      	ldrb	w8, [sp, #0x5e]
    5bd8:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    5bdc:      	ldrb	w8, [x24, #0x10]
    5be0:      	mov	w9, #0x8                // =8
    5be4:      	mov	w10, #0x70              // =112
    5be8:      	add	x11, sp, #0x70
    5bec:      	add	x0, sp, #0x70
    5bf0:      	mov	w1, #0x8                // =8
    5bf4:      	add	x8, x25, x8
    5bf8:      	ldrb	w8, [x24, #0x10]
    5bfc:      	add	x2, x25, x8
    5c00:      	blr	x10
    5c04:      	cbz	x0, 0x5c6c <perf_unwind_php+0x5c6c>
    5c08:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5c0c:      	ldr	x8, [x8]
    5c10:      	ldr	w8, [x8]
    5c14:      	cbz	w8, 0x5eb0 <perf_unwind_php+0x5eb0>
    5c18:      	mov	w8, #0x2978             // =10616
    5c1c:      	add	x0, sp, #0x18
    5c20:      	mov	w1, #0x33               // =51
    5c24:      	movk	w8, #0xa, lsl #16
    5c28:      	stur	w8, [sp, #0x47]
    5c2c:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5c30:      	add	x8, x8, #0x0
    5c34:      	ldp	x9, x10, [x8, #0x10]
    5c38:      	stp	x9, x10, [sp, #0x28]
    5c3c:      	ldp	x9, x10, [x8, #0x20]
    5c40:      	stp	x9, x10, [sp, #0x38]
    5c44:      	ldp	x9, x8, [x8]
    5c48:      	add	x10, sp, #0x18
    5c4c:      	stp	x9, x8, [sp, #0x18]
    5c50:      	mov	w8, #0x33               // =51
    5c54:      	mov	w9, #0x6                // =6
    5c58:      	ldrb	w8, [x24, #0x10]
    5c5c:      	add	x2, x25, x8
    5c60:      	blr	x9
    5c64:      	mov	w25, #0x25              // =37
    5c68:      	b	0x5fa8 <perf_unwind_php+0x5fa8>
    5c6c:      	ldr	x8, [sp, #0x70]
    5c70:      	cbz	x8, 0x5cfc <perf_unwind_php+0x5cfc>
    5c74:      	ldrb	w9, [x24, #0x14]
    5c78:      	mov	w10, #0x70              // =112
    5c7c:      	add	x11, sp, #0x8c
    5c80:      	add	x0, sp, #0x8c
    5c84:      	mov	w1, #0x1                // =1
    5c88:      	add	x8, x8, x9
    5c8c:      	mov	w9, #0x1                // =1
    5c90:      	ldr	x8, [sp, #0x70]
    5c94:      	ldrb	w9, [x24, #0x14]
    5c98:      	add	x2, x8, x9
    5c9c:      	blr	x10
    5ca0:      	cbz	x0, 0x5d3c <perf_unwind_php+0x5d3c>
    5ca4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5ca8:      	ldr	x8, [x8]
    5cac:      	ldr	w8, [x8]
    5cb0:      	cbz	w8, 0x5cf4 <perf_unwind_php+0x5cf4>
    5cb4:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5cb8:      	add	x10, x10, #0x0
    5cbc:      	strb	wzr, [sp, #0x48]
    5cc0:      	add	x0, sp, #0x18
    5cc4:      	ldp	x8, x9, [x10, #0x10]
    5cc8:      	mov	w1, #0x31               // =49
    5ccc:      	stp	x8, x9, [sp, #0x28]
    5cd0:      	ldp	x8, x9, [x10, #0x20]
    5cd4:      	stp	x8, x9, [sp, #0x38]
    5cd8:      	ldp	x8, x9, [x10]
    5cdc:      	add	x10, sp, #0x18
    5ce0:      	stp	x8, x9, [sp, #0x18]
    5ce4:      	mov	w8, #0x31               // =49
    5ce8:      	mov	w9, #0x6                // =6
    5cec:      	ldr	x2, [sp, #0x70]
    5cf0:      	blr	x9
    5cf4:      	mov	w25, #0x26              // =38
    5cf8:      	b	0x5fa8 <perf_unwind_php+0x5fa8>
    5cfc:      	ldr	w8, [x21, #0x2c0]
    5d00:      	adrp	x29, 0x5000 <perf_unwind_php+0x5000>
    5d04:      	ldr	x29, [x29]
    5d08:      	cmp	w8, #0x7e
    5d0c:      	b.hi	0x394 <perf_unwind_php+0x394>
    5d10:      	add	w9, w8, #0x1
    5d14:      	mov	x10, #-0x2              // =-2
    5d18:      	str	w9, [x21, #0x2c0]
    5d1c:      	mov	w9, #0x18               // =24
    5d20:      	umaddl	x8, w8, w9, x21
    5d24:      	add	x9, x8, #0x2d0
    5d28:      	str	x10, [x8, #0x2d8]
    5d2c:      	mov	w10, #0x2               // =2
    5d30:      	str	xzr, [x8, #0x2d0]
    5d34:      	strb	w10, [x8, #0x2e0]
    5d38:      	b	0x5f9c <perf_unwind_php+0x5f9c>
    5d3c:      	ldrb	w8, [sp, #0x8c]
    5d40:      	str	wzr, [sp, #0x88]
    5d44:      	cmp	w8, #0x4
    5d48:      	b.eq	0x5d58 <perf_unwind_php+0x5d58>
    5d4c:      	mov	w29, wzr
    5d50:      	cmp	w8, #0x2
    5d54:      	b.ne	0x5f14 <perf_unwind_php+0x5f14>
    5d58:      	ldrb	w8, [x24, #0x11]
    5d5c:      	mov	w9, #0x8                // =8
    5d60:      	mov	w10, #0x70              // =112
    5d64:      	add	x11, sp, #0x68
    5d68:      	add	x0, sp, #0x68
    5d6c:      	mov	w1, #0x8                // =8
    5d70:      	add	x8, x25, x8
    5d74:      	ldrb	w8, [x24, #0x11]
    5d78:      	add	x2, x25, x8
    5d7c:      	blr	x10
    5d80:      	cbz	x0, 0x5de4 <perf_unwind_php+0x5de4>
    5d84:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5d88:      	ldr	x8, [x8]
    5d8c:      	ldr	w8, [x8]
    5d90:      	cbz	w8, 0x5eb0 <perf_unwind_php+0x5eb0>
    5d94:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5d98:      	add	x10, x10, #0x0
    5d9c:      	add	x0, sp, #0x18
    5da0:      	ldp	x8, x9, [x10, #0x10]
    5da4:      	mov	w1, #0x2d               // =45
    5da8:      	stp	x8, x9, [sp, #0x28]
    5dac:      	ldr	x8, [x10, #0x20]
    5db0:      	str	x8, [sp, #0x38]
    5db4:      	ldur	x8, [x10, #0x25]
    5db8:      	stur	x8, [sp, #0x3d]
    5dbc:      	ldp	x8, x9, [x10]
    5dc0:      	add	x10, sp, #0x18
    5dc4:      	stp	x8, x9, [sp, #0x18]
    5dc8:      	mov	w8, #0x2d               // =45
    5dcc:      	mov	w9, #0x6                // =6
    5dd0:      	ldrb	w8, [x24, #0x11]
    5dd4:      	add	x2, x25, x8
    5dd8:      	blr	x9
    5ddc:      	mov	w25, #0x25              // =37
    5de0:      	b	0x5fa8 <perf_unwind_php+0x5fa8>
    5de4:      	ldr	x8, [sp, #0x68]
    5de8:      	ldrb	w9, [x24, #0x15]
    5dec:      	mov	w10, #0x70              // =112
    5df0:      	add	x11, sp, #0x88
    5df4:      	add	x0, sp, #0x88
    5df8:      	mov	w1, #0x4                // =4
    5dfc:      	add	x8, x8, x9
    5e00:      	mov	w9, #0x4                // =4
    5e04:      	ldr	x8, [sp, #0x68]
    5e08:      	ldrb	w9, [x24, #0x15]
    5e0c:      	add	x2, x8, x9
    5e10:      	blr	x10
    5e14:      	cbz	x0, 0x5e30 <perf_unwind_php+0x5e30>
    5e18:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5e1c:      	ldr	x8, [x8]
    5e20:      	ldr	w8, [x8]
    5e24:      	cbnz	w8, 0x5eb8 <perf_unwind_php+0x5eb8>
    5e28:      	mov	w25, #0x27              // =39
    5e2c:      	b	0x5fa8 <perf_unwind_php+0x5fa8>
    5e30:      	ldrb	w8, [x24, #0x13]
    5e34:      	mov	w9, #0x4                // =4
    5e38:      	mov	w10, #0x70              // =112
    5e3c:      	add	x11, sp, #0x5c
    5e40:      	add	x0, sp, #0x5c
    5e44:      	mov	w1, #0x4                // =4
    5e48:      	add	x8, x25, x8
    5e4c:      	ldrb	w8, [x24, #0x13]
    5e50:      	add	x2, x25, x8
    5e54:      	blr	x10
    5e58:      	cbz	x0, 0x5f10 <perf_unwind_php+0x5f10>
    5e5c:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5e60:      	ldr	x8, [x8]
    5e64:      	ldr	w8, [x8]
    5e68:      	cbz	w8, 0x5eb0 <perf_unwind_php+0x5eb0>
    5e6c:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5e70:      	add	x10, x10, #0x0
    5e74:      	mov	w11, #0x6               // =6
    5e78:      	ldp	x8, x9, [x10, #0x20]
    5e7c:      	add	x0, sp, #0x18
    5e80:      	mov	w1, #0x35               // =53
    5e84:      	mov	x2, x25
    5e88:      	stp	x8, x9, [sp, #0x38]
    5e8c:      	ldur	x8, [x10, #0x2d]
    5e90:      	stur	x8, [sp, #0x45]
    5e94:      	ldp	x8, x9, [x10]
    5e98:      	stp	x8, x9, [sp, #0x18]
    5e9c:      	ldp	x9, x8, [x10, #0x10]
    5ea0:      	mov	w10, #0x35              // =53
    5ea4:      	stp	x9, x8, [sp, #0x28]
    5ea8:      	add	x8, sp, #0x18
    5eac:      	blr	x11
    5eb0:      	mov	w25, #0x25              // =37
    5eb4:      	b	0x5fa8 <perf_unwind_php+0x5fa8>
    5eb8:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5ebc:      	add	x10, x10, #0x0
    5ec0:      	strb	wzr, [sp, #0x50]
    5ec4:      	add	x0, sp, #0x18
    5ec8:      	ldp	x8, x9, [x10, #0x20]
    5ecc:      	mov	w1, #0x39               // =57
    5ed0:      	stp	x8, x9, [sp, #0x38]
    5ed4:      	ldr	x8, [x10, #0x30]
    5ed8:      	str	x8, [sp, #0x48]
    5edc:      	ldp	x8, x9, [x10]
    5ee0:      	stp	x8, x9, [sp, #0x18]
    5ee4:      	ldp	x9, x8, [x10, #0x10]
    5ee8:      	add	x10, sp, #0x18
    5eec:      	stp	x9, x8, [sp, #0x28]
    5ef0:      	mov	w8, #0x39               // =57
    5ef4:      	mov	w9, #0x6                // =6
    5ef8:      	ldr	x8, [sp, #0x68]
    5efc:      	ldrb	w10, [x24, #0x15]
    5f00:      	add	x2, x8, x10
    5f04:      	blr	x9
    5f08:      	mov	w25, #0x27              // =39
    5f0c:      	b	0x5fa8 <perf_unwind_php+0x5fa8>
    5f10:      	ldr	w29, [sp, #0x88]
    5f14:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5f18:      	ldr	w25, [sp, #0x5c]
    5f1c:      	ldr	x8, [x8]
    5f20:      	ldr	w8, [x8]
    5f24:      	cbz	w8, 0x5f60 <perf_unwind_php+0x5f60>
    5f28:      	adrp	x10, 0x5000 <perf_unwind_php+0x5000>
    5f2c:      	add	x10, x10, #0x0
    5f30:      	add	x0, sp, #0x18
    5f34:      	ldp	x8, x9, [x10]
    5f38:      	mov	w1, #0x16               // =22
    5f3c:      	stp	x8, x9, [sp, #0x18]
    5f40:      	ldur	x8, [x10, #0xe]
    5f44:      	mov	w9, #0x6                // =6
    5f48:      	add	x10, sp, #0x18
    5f4c:      	stur	x8, [sp, #0x26]
    5f50:      	mov	w8, #0x16               // =22
    5f54:      	ldr	x2, [sp, #0x70]
    5f58:      	ldr	w3, [sp, #0x88]
    5f5c:      	blr	x9
    5f60:      	ldr	w8, [x21, #0x2c0]
    5f64:      	cmp	w8, #0x7e
    5f68:      	b.hi	0x82c <perf_unwind_php+0x82c>
    5f6c:      	add	w9, w8, #0x1
    5f70:      	mov	w10, w29
    5f74:      	str	w9, [x21, #0x2c0]
    5f78:      	mov	w9, #0x18               // =24
    5f7c:      	orr	x10, x10, x25, lsl #32
    5f80:      	umaddl	x8, w8, w9, x21
    5f84:      	ldr	x9, [sp, #0x70]
    5f88:      	str	x10, [x8, #0x2d8]
    5f8c:      	str	x9, [x8, #0x2d0]
    5f90:      	ldr	w9, [sp, #0xc]
    5f94:      	strb	w9, [x8, #0x2e0]
    5f98:      	add	x9, x8, #0x2d0
    5f9c:      	mov	w25, #0x23              // =35
    5fa0:      	str	wzr, [x8, #0x2e4]
    5fa4:      	stur	wzr, [x9, #0x11]
    5fa8:      	str	w25, [sp, #0x70]
    5fac:      	mov	w8, #0x1                // =1
    5fb0:      	add	x9, sp, #0x70
    5fb4:      	add	x1, sp, #0x70
    5fb8:      	mov	x0, x23
    5fbc:      	blr	x8
    5fc0:      	cbz	x0, 0x5fd4 <perf_unwind_php+0x5fd4>
    5fc4:      	ldr	x8, [x0]
    5fc8:      	add	x8, x8, #0x1
    5fcc:      	str	x8, [x0]
    5fd0:      	b	0x6028 <perf_unwind_php+0x6028>
    5fd4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5fd8:      	ldr	x8, [x8]
    5fdc:      	ldr	w8, [x8]
    5fe0:      	cbz	w8, 0x6028 <perf_unwind_php+0x6028>
    5fe4:      	adrp	x8, 0x5000 <perf_unwind_php+0x5000>
    5fe8:      	add	x8, x8, #0x0
    5fec:      	add	x0, sp, #0x18
    5ff0:      	ldp	x9, x10, [x8, #0x10]
    5ff4:      	mov	w1, #0x2e               // =46
    5ff8:      	stp	x9, x10, [sp, #0x28]
    5ffc:      	ldr	x9, [x8, #0x20]
    6000:      	add	x10, sp, #0x18
    6004:      	str	x9, [sp, #0x38]
    6008:      	ldur	x9, [x8, #0x26]
    600c:      	stur	x9, [sp, #0x3e]
    6010:      	ldp	x9, x8, [x8]
    6014:      	stp	x9, x8, [sp, #0x18]
    6018:      	mov	w8, #0x2e               // =46
    601c:      	mov	w9, #0x6                // =6
    6020:      	ldr	w2, [sp, #0x70]
    6024:      	blr	x9
    6028:      	cmp	w25, #0x23
    602c:      	b.ne	0x61f4 <perf_unwind_php+0x61f4>
    6030:      	ldr	x8, [sp, #0x60]
    6034:      	ldrb	w9, [x24, #0x12]
    6038:      	mov	w10, #0x70              // =112
    603c:      	add	x11, sp, #0x60
    6040:      	add	x0, sp, #0x60
    6044:      	mov	w1, #0x8                // =8
    6048:      	add	x8, x8, x9
    604c:      	mov	w9, #0x8                // =8
    6050:      	ldr	x8, [sp, #0x60]
    6054:      	ldrb	w9, [x24, #0x12]
    6058:      	add	x2, x8, x9
    605c:      	blr	x10
    6060:      	adrp	x29, 0x6000 <perf_unwind_php+0x6000>
    6064:      	ldr	x29, [x29]
    6068:      	cbnz	x0, 0x2d0 <perf_unwind_php+0x2d0>
    606c:      	ldr	x8, [sp, #0x60]
    6070:      	cbz	x8, 0x6084 <perf_unwind_php+0x6084>
    6074:      	ldrb	w8, [sp, #0x5e]
    6078:      	tbnz	w8, #0x1, 0x6084 <perf_unwind_php+0x6084>
    607c:      	mov	w23, #0x5               // =5
    6080:      	b	0x6258 <perf_unwind_php+0x6258>
    6084:      	ldr	w8, [x29]
    6088:      	cbnz	w8, 0x6204 <perf_unwind_php+0x6204>
    608c:      	ldr	w8, [sp, #0x10]
    6090:      	cbz	w8, 0x6254 <perf_unwind_php+0x6254>
    6094:      	ldr	x24, [x24, #0x8]
    6098:      	strb	wzr, [x21, #0xf20]
    609c:      	lsr	x8, x24, #56
    60a0:      	str	x24, [x21, #0xed0]
    60a4:      	cbz	x8, 0x60c0 <perf_unwind_php+0x60c0>
    60a8:      	ldr	w8, [x29]
    60ac:      	cbnz	w8, 0x6264 <perf_unwind_php+0x6264>
    60b0:      	mov	w8, #0xb                // =11
    60b4:      	mov	w23, wzr
    60b8:      	str	w8, [x21, #0xf18]
    60bc:      	b	0x6258 <perf_unwind_php+0x6258>
    60c0:      	cmp	x24, #0xfff
    60c4:      	b.hi	0x60e0 <perf_unwind_php+0x60e0>
    60c8:      	ldr	w8, [x29]
    60cc:      	cbnz	w8, 0x62a4 <perf_unwind_php+0x62a4>
    60d0:      	mov	w8, #0x31               // =49
    60d4:      	mov	w23, wzr
    60d8:      	str	w8, [x21, #0xf18]
    60dc:      	b	0x6258 <perf_unwind_php+0x6258>
    60e0:      	ldr	w8, [x21]
    60e4:      	mov	w9, #0x60               // =96
    60e8:      	adrp	x0, 0x6000 <perf_unwind_php+0x6000>
    60ec:      	add	x1, sp, #0x70
    60f0:      	rev	w8, w8
    60f4:      	stp	w9, w8, [sp, #0x70]
    60f8:      	rev	x8, x24
    60fc:      	add	x9, sp, #0x70
    6100:      	str	x8, [sp, #0x78]
    6104:      	mov	w8, #0x1                // =1
    6108:      	ldr	x0, [x0]
    610c:      	blr	x8
    6110:      	cbz	x0, 0x61dc <perf_unwind_php+0x61dc>
    6114:      	ldr	x8, [x0, #0x8]
    6118:      	and	x9, x8, #0xffffffffffffff
    611c:      	lsr	x23, x8, #56
    6120:      	str	x9, [x21, #0xf10]
    6124:      	ldr	x8, [x0]
    6128:      	str	x8, [x21, #0xf00]
    612c:      	sub	x8, x24, x9
    6130:      	str	x8, [x21, #0xf08]
    6134:      	ldr	w8, [x29]
    6138:      	cbz	w8, 0x6258 <perf_unwind_php+0x6258>
    613c:      	mov	w8, #0xa                // =10
    6140:      	add	x0, sp, #0x18
    6144:      	mov	w1, #0x32               // =50
    6148:      	strh	w8, [sp, #0x48]
    614c:      	adrp	x8, 0x6000 <perf_unwind_php+0x6000>
    6150:      	add	x8, x8, #0x0
    6154:      	mov	x2, x24
    6158:      	ldp	x9, x10, [x8, #0x10]
    615c:      	mov	w4, w23
    6160:      	stp	x9, x10, [sp, #0x28]
    6164:      	ldp	x9, x10, [x8, #0x20]
    6168:      	stp	x9, x10, [sp, #0x38]
    616c:      	ldp	x9, x8, [x8]
    6170:      	add	x10, sp, #0x18
    6174:      	stp	x9, x8, [sp, #0x18]
    6178:      	mov	w8, #0x32               // =50
    617c:      	mov	w9, #0x6                // =6
    6180:      	ldr	x3, [x21, #0xf00]
    6184:      	blr	x9
    6188:      	ldr	w8, [x29]
    618c:      	cbz	w8, 0x6258 <perf_unwind_php+0x6258>
    6190:      	adrp	x8, 0x6000 <perf_unwind_php+0x6000>
    6194:      	add	x8, x8, #0x0
    6198:      	add	x0, sp, #0x18
    619c:      	ldp	x9, x10, [x8, #0x10]
    61a0:      	mov	w1, #0x2f               // =47
    61a4:      	stp	x9, x10, [sp, #0x28]
    61a8:      	ldr	x9, [x8, #0x20]
    61ac:      	add	x10, sp, #0x18
    61b0:      	str	x9, [sp, #0x38]
    61b4:      	ldur	x9, [x8, #0x27]
    61b8:      	stur	x9, [sp, #0x3f]
    61bc:      	ldp	x9, x8, [x8]
    61c0:      	stp	x9, x8, [sp, #0x18]
    61c4:      	mov	w8, #0x2f               // =47
    61c8:      	mov	w9, #0x6                // =6
    61cc:      	ldr	x2, [x21, #0xf10]
    61d0:      	ldr	x3, [x21, #0xf08]
    61d4:      	blr	x9
    61d8:      	b	0x6258 <perf_unwind_php+0x6258>
    61dc:      	ldr	w8, [x29]
    61e0:      	cbnz	w8, 0x62e4 <perf_unwind_php+0x62e4>
    61e4:      	mov	w8, #0xc                // =12
    61e8:      	mov	w23, wzr
    61ec:      	str	w8, [x21, #0xf18]
    61f0:      	b	0x6258 <perf_unwind_php+0x6258>
    61f4:      	adrp	x29, 0x6000 <perf_unwind_php+0x6000>
    61f8:      	mov	w23, #0x5               // =5
    61fc:      	ldr	x29, [x29]
    6200:      	b	0x418 <perf_unwind_php+0x418>
    6204:      	mov	w8, #0x786c             // =30828
    6208:      	add	x0, sp, #0x18
    620c:      	mov	w1, #0x2c               // =44
    6210:      	movk	w8, #0xa, lsl #16
    6214:      	str	w8, [sp, #0x40]
    6218:      	adrp	x8, 0x6000 <perf_unwind_php+0x6000>
    621c:      	add	x8, x8, #0x0
    6220:      	ldp	x9, x10, [x8, #0x10]
    6224:      	stp	x9, x10, [sp, #0x28]
    6228:      	ldr	x9, [x8, #0x20]
    622c:      	add	x10, sp, #0x18
    6230:      	str	x9, [sp, #0x38]
    6234:      	ldp	x8, x9, [x8]
    6238:      	stp	x8, x9, [sp, #0x18]
    623c:      	mov	w8, #0x2c               // =44
    6240:      	mov	w9, #0x6                // =6
    6244:      	ldr	x2, [sp, #0x60]
    6248:      	blr	x9
    624c:      	ldr	w8, [sp, #0x10]
    6250:      	cbnz	w8, 0x6094 <perf_unwind_php+0x6094>
    6254:      	mov	w23, #0x1               // =1
    6258:      	ldr	x8, [sp, #0x60]
    625c:      	cbnz	x8, 0x428 <perf_unwind_php+0x428>
    6260:      	b	0x418 <perf_unwind_php+0x418>
    6264:      	mov	w8, #0xa                // =10
    6268:      	add	x0, sp, #0x18
    626c:      	mov	w1, #0x22               // =34
    6270:      	strh	w8, [sp, #0x38]
    6274:      	adrp	x8, 0x6000 <perf_unwind_php+0x6000>
    6278:      	add	x8, x8, #0x0
    627c:      	mov	x2, x24
    6280:      	ldp	x9, x10, [x8]
    6284:      	stp	x9, x10, [sp, #0x18]
    6288:      	ldp	x9, x8, [x8, #0x10]
    628c:      	add	x10, sp, #0x18
    6290:      	stp	x9, x8, [sp, #0x28]
    6294:      	mov	w8, #0x22               // =34
    6298:      	mov	w9, #0x6                // =6
    629c:      	blr	x9
    62a0:      	b	0x60b0 <perf_unwind_php+0x60b0>
    62a4:      	adrp	x8, 0x6000 <perf_unwind_php+0x6000>
    62a8:      	add	x8, x8, #0x0
    62ac:      	add	x0, sp, #0x18
    62b0:      	ldp	x9, x10, [x8]
    62b4:      	mov	w1, #0x1e               // =30
    62b8:      	mov	x2, x24
    62bc:      	stp	x9, x10, [sp, #0x18]
    62c0:      	ldr	x9, [x8, #0x10]
    62c4:      	ldur	x8, [x8, #0x16]
    62c8:      	add	x10, sp, #0x18
    62cc:      	str	x9, [sp, #0x28]
    62d0:      	stur	x8, [sp, #0x2e]
    62d4:      	mov	w8, #0x1e               // =30
    62d8:      	mov	w9, #0x6                // =6
    62dc:      	blr	x9
    62e0:      	b	0x60d0 <perf_unwind_php+0x60d0>
    62e4:      	adrp	x8, 0x6000 <perf_unwind_php+0x6000>
    62e8:      	add	x8, x8, #0x0
    62ec:      	strb	wzr, [sp, #0x50]
    62f0:      	add	x0, sp, #0x18
    62f4:      	ldp	x9, x10, [x8, #0x20]
    62f8:      	mov	w1, #0x39               // =57
    62fc:      	mov	x2, x24
    6300:      	stp	x9, x10, [sp, #0x38]
    6304:      	ldr	x9, [x8, #0x30]
    6308:      	str	x9, [sp, #0x48]
    630c:      	ldp	x9, x10, [x8]
    6310:      	stp	x9, x10, [sp, #0x18]
    6314:      	ldp	x8, x9, [x8, #0x10]
    6318:      	add	x10, sp, #0x18
    631c:      	stp	x8, x9, [sp, #0x28]
    6320:      	mov	w8, #0x39               // =57
    6324:      	mov	w9, #0x6                // =6
    6328:      	blr	x9
    632c:      	b	0x61e4 <perf_unwind_php+0x61e4>

Disassembly of section kprobe/unwind_php:

0000000000000000 <kprobe_unwind_php>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	str	wzr, [sp, #0x18]
      1c:      	adrp	x20, 0x0 <kprobe_unwind_php>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x18
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x18
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0xc5c <kprobe_unwind_php+0xc5c>
      40:      	ldr	w8, [x0]
      44:      	mov	x21, x0
      48:      	adrp	x0, 0x0 <kprobe_unwind_php>
      4c:      	add	x9, sp, #0x14
      50:      	str	w8, [sp, #0x14]
      54:      	mov	w8, #0x1                // =1
      58:      	add	x1, sp, #0x14
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	adrp	x29, 0x0 <kprobe_unwind_php>
      68:      	ldr	x29, [x29]
      6c:      	cbz	x0, 0x84 <kprobe_unwind_php+0x84>
      70:      	ldr	x8, [x21, #0xf00]
      74:      	mov	x24, x0
      78:      	cbz	x8, 0xd0 <kprobe_unwind_php+0xd0>
      7c:      	mov	w25, wzr
      80:      	b	0xdc <kprobe_unwind_php+0xdc>
      84:      	ldr	w8, [x29]
      88:      	cbz	w8, 0xb94 <kprobe_unwind_php+0xb94>
      8c:      	mov	w8, #0x6174             // =24948
      90:      	add	x0, sp, #0x18
      94:      	mov	w1, #0x1b               // =27
      98:      	movk	w8, #0xa, lsl #16
      9c:      	stur	w8, [sp, #0x2f]
      a0:      	adrp	x8, 0x0 <kprobe_unwind_php>
      a4:      	add	x8, x8, #0x0
      a8:      	ldp	x9, x10, [x8]
      ac:      	ldr	x8, [x8, #0x10]
      b0:      	stp	x9, x10, [sp, #0x18]
      b4:      	str	x8, [sp, #0x28]
      b8:      	mov	w8, #0x1b               // =27
      bc:      	mov	w9, #0x6                // =6
      c0:      	add	x10, sp, #0x18
      c4:      	blr	x9
      c8:      	mov	w23, #0x1               // =1
      cc:      	b	0xb98 <kprobe_unwind_php+0xb98>
      d0:      	ldr	x8, [x21, #0xf10]
      d4:      	cmp	x8, #0x0
      d8:      	cset	w25, eq
      dc:      	mov	w8, #0x22               // =34
      e0:      	adrp	x23, 0x0 <kprobe_unwind_php>
      e4:      	add	x9, sp, #0x70
      e8:      	str	w8, [sp, #0x70]
      ec:      	mov	w8, #0x1                // =1
      f0:      	add	x1, sp, #0x70
      f4:      	ldr	x23, [x23]
      f8:      	mov	x0, x23
      fc:      	blr	x8
     100:      	cbz	x0, 0x120 <kprobe_unwind_php+0x120>
     104:      	ldr	x8, [x0]
     108:      	add	x8, x8, #0x1
     10c:      	str	x8, [x0]
     110:      	ldr	x8, [x21, #0xf50]
     114:      	add	x22, x21, #0xf50
     118:      	cbnz	x8, 0x134 <kprobe_unwind_php+0x134>
     11c:      	b	0xb30 <kprobe_unwind_php+0xb30>
     120:      	ldr	w8, [x29]
     124:      	cbnz	w8, 0xae0 <kprobe_unwind_php+0xae0>
     128:      	ldr	x8, [x21, #0xf50]
     12c:      	add	x22, x21, #0xf50
     130:      	cbz	x8, 0xb30 <kprobe_unwind_php+0xb30>
     134:      	cbz	w25, 0x1a4 <kprobe_unwind_php+0x1a4>
     138:      	ldr	x8, [x21, #0xee0]
     13c:      	str	x8, [x21, #0xed8]
     140:      	ldr	w8, [x29]
     144:      	str	w25, [sp, #0x10]
     148:      	cbz	w8, 0x1b0 <kprobe_unwind_php+0x1b0>
     14c:      	mov	w8, #0x2978             // =10616
     150:      	add	x0, sp, #0x18
     154:      	mov	w1, #0x2b               // =43
     158:      	movk	w8, #0xa, lsl #16
     15c:      	stur	w8, [sp, #0x3f]
     160:      	adrp	x8, 0x0 <kprobe_unwind_php>
     164:      	add	x8, x8, #0x0
     168:      	ldp	x9, x10, [x8, #0x10]
     16c:      	stp	x9, x10, [sp, #0x28]
     170:      	ldr	x9, [x8, #0x20]
     174:      	add	x10, sp, #0x18
     178:      	str	x9, [sp, #0x38]
     17c:      	ldp	x8, x9, [x8]
     180:      	stp	x8, x9, [sp, #0x18]
     184:      	mov	w8, #0x2b               // =43
     188:      	mov	w9, #0x6                // =6
     18c:      	ldr	x2, [x22]
     190:      	blr	x9
     194:      	ldr	x25, [x22]
     198:      	str	x25, [sp, #0x60]
     19c:      	cbnz	x25, 0x1bc <kprobe_unwind_php+0x1bc>
     1a0:      	b	0xb94 <kprobe_unwind_php+0xb94>
     1a4:      	ldr	w8, [x29]
     1a8:      	str	w25, [sp, #0x10]
     1ac:      	cbnz	w8, 0x14c <kprobe_unwind_php+0x14c>
     1b0:      	ldr	x25, [x22]
     1b4:      	str	x25, [sp, #0x60]
     1b8:      	cbz	x25, 0xb94 <kprobe_unwind_php+0xb94>
     1bc:      	ldr	w8, [sp, #0x10]
     1c0:      	mov	w9, #0x9                // =9
     1c4:      	str	wzr, [sp, #0x5c]
     1c8:      	mov	w10, #0x70              // =112
     1cc:      	add	x11, sp, #0x70
     1d0:      	add	x0, sp, #0x70
     1d4:      	mov	w1, #0x8                // =8
     1d8:      	cmp	w8, #0x0
     1dc:      	mov	w8, #0x2                // =2
     1e0:      	csel	w8, w9, w8, ne
     1e4:      	mov	w9, #0x8                // =8
     1e8:      	str	w8, [sp, #0xc]
     1ec:      	ldrb	w8, [x24, #0x10]
     1f0:      	add	x8, x25, x8
     1f4:      	ldrb	w8, [x24, #0x10]
     1f8:      	add	x2, x25, x8
     1fc:      	blr	x10
     200:      	cbz	x0, 0x244 <kprobe_unwind_php+0x244>
     204:      	ldr	w8, [x29]
     208:      	cbnz	w8, 0xc7c <kprobe_unwind_php+0xc7c>
     20c:      	mov	w25, #0x25              // =37
     210:      	str	w25, [sp, #0x70]
     214:      	mov	w8, #0x1                // =1
     218:      	add	x9, sp, #0x70
     21c:      	add	x1, sp, #0x70
     220:      	mov	x0, x23
     224:      	blr	x8
     228:      	cbz	x0, 0x28c <kprobe_unwind_php+0x28c>
     22c:      	ldr	x8, [x0]
     230:      	add	x8, x8, #0x1
     234:      	str	x8, [x0]
     238:      	cmp	w25, #0x23
     23c:      	b.eq	0x29c <kprobe_unwind_php+0x29c>
     240:      	b	0x414 <kprobe_unwind_php+0x414>
     244:      	ldr	x8, [sp, #0x70]
     248:      	cbz	x8, 0x388 <kprobe_unwind_php+0x388>
     24c:      	ldrb	w9, [x24, #0x14]
     250:      	mov	w10, #0x70              // =112
     254:      	add	x11, sp, #0x8c
     258:      	add	x0, sp, #0x8c
     25c:      	mov	w1, #0x1                // =1
     260:      	add	x8, x8, x9
     264:      	mov	w9, #0x1                // =1
     268:      	ldr	x8, [sp, #0x70]
     26c:      	ldrb	w9, [x24, #0x14]
     270:      	add	x2, x8, x9
     274:      	blr	x10
     278:      	cbz	x0, 0x430 <kprobe_unwind_php+0x430>
     27c:      	ldr	w8, [x29]
     280:      	cbnz	w8, 0xf10 <kprobe_unwind_php+0xf10>
     284:      	mov	w25, #0x26              // =38
     288:      	b	0x210 <kprobe_unwind_php+0x210>
     28c:      	ldr	w8, [x29]
     290:      	cbnz	w8, 0xdcc <kprobe_unwind_php+0xdcc>
     294:      	cmp	w25, #0x23
     298:      	b.ne	0x414 <kprobe_unwind_php+0x414>
     29c:      	ldr	x8, [sp, #0x60]
     2a0:      	ldrb	w9, [x24, #0x12]
     2a4:      	mov	w10, #0x70              // =112
     2a8:      	add	x11, sp, #0x60
     2ac:      	add	x0, sp, #0x60
     2b0:      	mov	w1, #0x8                // =8
     2b4:      	add	x8, x8, x9
     2b8:      	mov	w9, #0x8                // =8
     2bc:      	ldr	x8, [sp, #0x60]
     2c0:      	ldrb	w9, [x24, #0x12]
     2c4:      	add	x2, x8, x9
     2c8:      	blr	x10
     2cc:      	cbz	x0, 0x30c <kprobe_unwind_php+0x30c>
     2d0:      	ldr	w8, [x29]
     2d4:      	cbnz	w8, 0xe80 <kprobe_unwind_php+0xe80>
     2d8:      	mov	w8, #0x25               // =37
     2dc:      	add	x9, sp, #0x70
     2e0:      	add	x1, sp, #0x70
     2e4:      	str	w8, [sp, #0x70]
     2e8:      	mov	w8, #0x1                // =1
     2ec:      	mov	x0, x23
     2f0:      	blr	x8
     2f4:      	cbz	x0, 0x40c <kprobe_unwind_php+0x40c>
     2f8:      	ldr	x8, [x0]
     2fc:      	mov	w23, #0x5               // =5
     300:      	add	x8, x8, #0x1
     304:      	str	x8, [x0]
     308:      	b	0x418 <kprobe_unwind_php+0x418>
     30c:      	ldr	x25, [sp, #0x60]
     310:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
     314:      	ldrb	w8, [sp, #0x5e]
     318:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
     31c:      	ldrb	w8, [x24, #0x10]
     320:      	mov	w9, #0x8                // =8
     324:      	mov	w10, #0x70              // =112
     328:      	add	x11, sp, #0x70
     32c:      	add	x0, sp, #0x70
     330:      	mov	w1, #0x8                // =8
     334:      	add	x8, x25, x8
     338:      	ldrb	w8, [x24, #0x10]
     33c:      	add	x2, x25, x8
     340:      	blr	x10
     344:      	cbz	x0, 0x5b0 <kprobe_unwind_php+0x5b0>
     348:      	ldr	w8, [x29]
     34c:      	cbnz	w8, 0x1220 <kprobe_unwind_php+0x1220>
     350:      	mov	w25, #0x25              // =37
     354:      	str	w25, [sp, #0x70]
     358:      	mov	w8, #0x1                // =1
     35c:      	add	x9, sp, #0x70
     360:      	add	x1, sp, #0x70
     364:      	mov	x0, x23
     368:      	blr	x8
     36c:      	cbz	x0, 0x5f8 <kprobe_unwind_php+0x5f8>
     370:      	ldr	x8, [x0]
     374:      	add	x8, x8, #0x1
     378:      	str	x8, [x0]
     37c:      	cmp	w25, #0x23
     380:      	b.eq	0x608 <kprobe_unwind_php+0x608>
     384:      	b	0x414 <kprobe_unwind_php+0x414>
     388:      	ldr	w8, [x21, #0x2c0]
     38c:      	cmp	w8, #0x7f
     390:      	b.lo	0x4d4 <kprobe_unwind_php+0x4d4>
     394:      	ldr	w8, [x29]
     398:      	cbnz	w8, 0x1118 <kprobe_unwind_php+0x1118>
     39c:      	mov	w8, #0x2                // =2
     3a0:      	add	x9, sp, #0x68
     3a4:      	add	x1, sp, #0x68
     3a8:      	str	w8, [sp, #0x68]
     3ac:      	mov	w8, #0x1                // =1
     3b0:      	mov	x0, x23
     3b4:      	blr	x8
     3b8:      	cbz	x0, 0x50c <kprobe_unwind_php+0x50c>
     3bc:      	ldr	x8, [x0]
     3c0:      	add	x8, x8, #0x1
     3c4:      	str	x8, [x0]
     3c8:      	ldr	w8, [x29]
     3cc:      	cbz	w8, 0x414 <kprobe_unwind_php+0x414>
     3d0:      	mov	w8, #0xa                // =10
     3d4:      	add	x0, sp, #0x18
     3d8:      	mov	w1, #0x22               // =34
     3dc:      	strh	w8, [sp, #0x38]
     3e0:      	adrp	x8, 0x0 <kprobe_unwind_php>
     3e4:      	add	x8, x8, #0x0
     3e8:      	ldp	x9, x10, [x8]
     3ec:      	stp	x9, x10, [sp, #0x18]
     3f0:      	ldp	x9, x8, [x8, #0x10]
     3f4:      	add	x10, sp, #0x18
     3f8:      	stp	x9, x8, [sp, #0x28]
     3fc:      	mov	w8, #0x22               // =34
     400:      	mov	w9, #0x6                // =6
     404:      	blr	x9
     408:      	b	0x414 <kprobe_unwind_php+0x414>
     40c:      	ldr	w8, [x29]
     410:      	cbnz	w8, 0xff8 <kprobe_unwind_php+0xff8>
     414:      	mov	w23, #0x5               // =5
     418:      	ldr	w8, [x21, #0x1370]
     41c:      	orr	w8, w8, #0x20
     420:      	str	w8, [x21, #0x1370]
     424:      	ldr	x8, [sp, #0x60]
     428:      	str	x8, [x22]
     42c:      	b	0xb98 <kprobe_unwind_php+0xb98>
     430:      	ldrb	w8, [sp, #0x8c]
     434:      	str	wzr, [sp, #0x88]
     438:      	cmp	w8, #0x4
     43c:      	b.eq	0x44c <kprobe_unwind_php+0x44c>
     440:      	mov	w29, wzr
     444:      	cmp	w8, #0x2
     448:      	b.ne	0x80c <kprobe_unwind_php+0x80c>
     44c:      	ldrb	w8, [x24, #0x11]
     450:      	mov	w9, #0x8                // =8
     454:      	mov	w10, #0x70              // =112
     458:      	add	x11, sp, #0x68
     45c:      	add	x0, sp, #0x68
     460:      	mov	w1, #0x8                // =8
     464:      	add	x8, x25, x8
     468:      	ldrb	w8, [x24, #0x11]
     46c:      	add	x2, x25, x8
     470:      	blr	x10
     474:      	cbz	x0, 0x564 <kprobe_unwind_php+0x564>
     478:      	adrp	x29, 0x0 <kprobe_unwind_php>
     47c:      	ldr	x29, [x29]
     480:      	ldr	w8, [x29]
     484:      	cbz	w8, 0x20c <kprobe_unwind_php+0x20c>
     488:      	adrp	x8, 0x0 <kprobe_unwind_php>
     48c:      	add	x8, x8, #0x0
     490:      	add	x0, sp, #0x18
     494:      	ldp	x9, x10, [x8, #0x10]
     498:      	mov	w1, #0x2d               // =45
     49c:      	stp	x9, x10, [sp, #0x28]
     4a0:      	ldr	x9, [x8, #0x20]
     4a4:      	add	x10, sp, #0x18
     4a8:      	str	x9, [sp, #0x38]
     4ac:      	ldur	x9, [x8, #0x25]
     4b0:      	stur	x9, [sp, #0x3d]
     4b4:      	ldp	x9, x8, [x8]
     4b8:      	stp	x9, x8, [sp, #0x18]
     4bc:      	mov	w8, #0x2d               // =45
     4c0:      	mov	w9, #0x6                // =6
     4c4:      	ldrb	w8, [x24, #0x11]
     4c8:      	add	x2, x25, x8
     4cc:      	blr	x9
     4d0:      	b	0x20c <kprobe_unwind_php+0x20c>
     4d4:      	add	w9, w8, #0x1
     4d8:      	mov	x10, #-0x2              // =-2
     4dc:      	mov	w25, #0x23              // =35
     4e0:      	str	w9, [x21, #0x2c0]
     4e4:      	mov	w9, #0x18               // =24
     4e8:      	umaddl	x8, w8, w9, x21
     4ec:      	add	x9, x8, #0x2d0
     4f0:      	str	x10, [x8, #0x2d8]
     4f4:      	mov	w10, #0x2               // =2
     4f8:      	str	xzr, [x8, #0x2d0]
     4fc:      	str	wzr, [x8, #0x2e4]
     500:      	strb	w10, [x8, #0x2e0]
     504:      	stur	wzr, [x9, #0x11]
     508:      	b	0x210 <kprobe_unwind_php+0x210>
     50c:      	ldr	w8, [x29]
     510:      	cbz	w8, 0x414 <kprobe_unwind_php+0x414>
     514:      	adrp	x8, 0x0 <kprobe_unwind_php>
     518:      	add	x8, x8, #0x0
     51c:      	add	x0, sp, #0x18
     520:      	ldp	x9, x10, [x8, #0x10]
     524:      	mov	w1, #0x2e               // =46
     528:      	stp	x9, x10, [sp, #0x28]
     52c:      	ldr	x9, [x8, #0x20]
     530:      	add	x10, sp, #0x18
     534:      	str	x9, [sp, #0x38]
     538:      	ldur	x9, [x8, #0x26]
     53c:      	stur	x9, [sp, #0x3e]
     540:      	ldp	x9, x8, [x8]
     544:      	stp	x9, x8, [sp, #0x18]
     548:      	mov	w8, #0x2e               // =46
     54c:      	mov	w9, #0x6                // =6
     550:      	ldr	w2, [sp, #0x68]
     554:      	blr	x9
     558:      	ldr	w8, [x29]
     55c:      	cbz	w8, 0x414 <kprobe_unwind_php+0x414>
     560:      	b	0x3d0 <kprobe_unwind_php+0x3d0>
     564:      	ldr	x8, [sp, #0x68]
     568:      	ldrb	w9, [x24, #0x15]
     56c:      	mov	w10, #0x70              // =112
     570:      	add	x11, sp, #0x88
     574:      	add	x0, sp, #0x88
     578:      	mov	w1, #0x4                // =4
     57c:      	add	x8, x8, x9
     580:      	mov	w9, #0x4                // =4
     584:      	ldr	x8, [sp, #0x68]
     588:      	ldrb	w9, [x24, #0x15]
     58c:      	add	x2, x8, x9
     590:      	blr	x10
     594:      	adrp	x29, 0x0 <kprobe_unwind_php>
     598:      	ldr	x29, [x29]
     59c:      	cbz	x0, 0x6b8 <kprobe_unwind_php+0x6b8>
     5a0:      	ldr	w8, [x29]
     5a4:      	cbnz	w8, 0x1498 <kprobe_unwind_php+0x1498>
     5a8:      	mov	w25, #0x27              // =39
     5ac:      	b	0x210 <kprobe_unwind_php+0x210>
     5b0:      	ldr	x8, [sp, #0x70]
     5b4:      	cbz	x8, 0x730 <kprobe_unwind_php+0x730>
     5b8:      	ldrb	w9, [x24, #0x14]
     5bc:      	mov	w10, #0x70              // =112
     5c0:      	add	x11, sp, #0x8c
     5c4:      	add	x0, sp, #0x8c
     5c8:      	mov	w1, #0x1                // =1
     5cc:      	add	x8, x8, x9
     5d0:      	mov	w9, #0x1                // =1
     5d4:      	ldr	x8, [sp, #0x70]
     5d8:      	ldrb	w9, [x24, #0x14]
     5dc:      	add	x2, x8, x9
     5e0:      	blr	x10
     5e4:      	cbz	x0, 0x774 <kprobe_unwind_php+0x774>
     5e8:      	ldr	w8, [x29]
     5ec:      	cbnz	w8, 0x14f0 <kprobe_unwind_php+0x14f0>
     5f0:      	mov	w25, #0x26              // =38
     5f4:      	b	0x354 <kprobe_unwind_php+0x354>
     5f8:      	ldr	w8, [x29]
     5fc:      	cbnz	w8, 0x13a0 <kprobe_unwind_php+0x13a0>
     600:      	cmp	w25, #0x23
     604:      	b.ne	0x414 <kprobe_unwind_php+0x414>
     608:      	ldr	x8, [sp, #0x60]
     60c:      	ldrb	w9, [x24, #0x12]
     610:      	mov	w10, #0x70              // =112
     614:      	add	x11, sp, #0x60
     618:      	add	x0, sp, #0x60
     61c:      	mov	w1, #0x8                // =8
     620:      	add	x8, x8, x9
     624:      	mov	w9, #0x8                // =8
     628:      	ldr	x8, [sp, #0x60]
     62c:      	ldrb	w9, [x24, #0x12]
     630:      	add	x2, x8, x9
     634:      	blr	x10
     638:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
     63c:      	ldr	x25, [sp, #0x60]
     640:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
     644:      	ldrb	w8, [sp, #0x5e]
     648:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
     64c:      	ldrb	w8, [x24, #0x10]
     650:      	mov	w9, #0x8                // =8
     654:      	mov	w10, #0x70              // =112
     658:      	add	x11, sp, #0x70
     65c:      	add	x0, sp, #0x70
     660:      	mov	w1, #0x8                // =8
     664:      	add	x8, x25, x8
     668:      	ldrb	w8, [x24, #0x10]
     66c:      	add	x2, x25, x8
     670:      	blr	x10
     674:      	cbz	x0, 0x948 <kprobe_unwind_php+0x948>
     678:      	ldr	w8, [x29]
     67c:      	cbnz	w8, 0x1774 <kprobe_unwind_php+0x1774>
     680:      	mov	w25, #0x25              // =37
     684:      	str	w25, [sp, #0x70]
     688:      	mov	w8, #0x1                // =1
     68c:      	add	x9, sp, #0x70
     690:      	add	x1, sp, #0x70
     694:      	mov	x0, x23
     698:      	blr	x8
     69c:      	cbz	x0, 0x990 <kprobe_unwind_php+0x990>
     6a0:      	ldr	x8, [x0]
     6a4:      	add	x8, x8, #0x1
     6a8:      	str	x8, [x0]
     6ac:      	cmp	w25, #0x23
     6b0:      	b.eq	0x9a0 <kprobe_unwind_php+0x9a0>
     6b4:      	b	0x414 <kprobe_unwind_php+0x414>
     6b8:      	ldrb	w8, [x24, #0x13]
     6bc:      	mov	w9, #0x4                // =4
     6c0:      	mov	w10, #0x70              // =112
     6c4:      	add	x11, sp, #0x5c
     6c8:      	add	x0, sp, #0x5c
     6cc:      	mov	w1, #0x4                // =4
     6d0:      	add	x8, x25, x8
     6d4:      	ldrb	w8, [x24, #0x13]
     6d8:      	add	x2, x25, x8
     6dc:      	blr	x10
     6e0:      	cbz	x0, 0x808 <kprobe_unwind_php+0x808>
     6e4:      	ldr	w8, [x29]
     6e8:      	cbz	w8, 0x20c <kprobe_unwind_php+0x20c>
     6ec:      	adrp	x8, 0x0 <kprobe_unwind_php>
     6f0:      	add	x8, x8, #0x0
     6f4:      	add	x0, sp, #0x18
     6f8:      	ldp	x9, x10, [x8, #0x20]
     6fc:      	mov	w1, #0x35               // =53
     700:      	mov	x2, x25
     704:      	stp	x9, x10, [sp, #0x38]
     708:      	ldur	x9, [x8, #0x2d]
     70c:      	stur	x9, [sp, #0x45]
     710:      	ldp	x9, x10, [x8]
     714:      	stp	x9, x10, [sp, #0x18]
     718:      	ldp	x8, x9, [x8, #0x10]
     71c:      	add	x10, sp, #0x18
     720:      	stp	x8, x9, [sp, #0x28]
     724:      	mov	w8, #0x35               // =53
     728:      	mov	w9, #0x6                // =6
     72c:      	b	0x4cc <kprobe_unwind_php+0x4cc>
     730:      	ldr	w8, [x21, #0x2c0]
     734:      	cmp	w8, #0x7e
     738:      	b.hi	0x394 <kprobe_unwind_php+0x394>
     73c:      	add	w9, w8, #0x1
     740:      	mov	x10, #-0x2              // =-2
     744:      	mov	w25, #0x23              // =35
     748:      	str	w9, [x21, #0x2c0]
     74c:      	mov	w9, #0x18               // =24
     750:      	umaddl	x8, w8, w9, x21
     754:      	add	x9, x8, #0x2d0
     758:      	str	x10, [x8, #0x2d8]
     75c:      	mov	w10, #0x2               // =2
     760:      	str	xzr, [x8, #0x2d0]
     764:      	str	wzr, [x8, #0x2e4]
     768:      	strb	w10, [x8, #0x2e0]
     76c:      	stur	wzr, [x9, #0x11]
     770:      	b	0x354 <kprobe_unwind_php+0x354>
     774:      	ldrb	w8, [sp, #0x8c]
     778:      	str	wzr, [sp, #0x88]
     77c:      	cmp	w8, #0x4
     780:      	b.eq	0x790 <kprobe_unwind_php+0x790>
     784:      	mov	w10, wzr
     788:      	cmp	w8, #0x2
     78c:      	b.ne	0xe20 <kprobe_unwind_php+0xe20>
     790:      	ldrb	w8, [x24, #0x11]
     794:      	mov	w9, #0x8                // =8
     798:      	mov	w10, #0x70              // =112
     79c:      	add	x11, sp, #0x68
     7a0:      	add	x0, sp, #0x68
     7a4:      	mov	w1, #0x8                // =8
     7a8:      	add	x8, x25, x8
     7ac:      	ldrb	w8, [x24, #0x11]
     7b0:      	add	x2, x25, x8
     7b4:      	blr	x10
     7b8:      	cbz	x0, 0x904 <kprobe_unwind_php+0x904>
     7bc:      	ldr	w8, [x29]
     7c0:      	cbz	w8, 0x350 <kprobe_unwind_php+0x350>
     7c4:      	adrp	x8, 0x0 <kprobe_unwind_php>
     7c8:      	add	x8, x8, #0x0
     7cc:      	add	x0, sp, #0x18
     7d0:      	ldp	x9, x10, [x8, #0x10]
     7d4:      	mov	w1, #0x2d               // =45
     7d8:      	stp	x9, x10, [sp, #0x28]
     7dc:      	ldr	x9, [x8, #0x20]
     7e0:      	add	x10, sp, #0x18
     7e4:      	str	x9, [sp, #0x38]
     7e8:      	ldur	x9, [x8, #0x25]
     7ec:      	stur	x9, [sp, #0x3d]
     7f0:      	ldp	x9, x8, [x8]
     7f4:      	stp	x9, x8, [sp, #0x18]
     7f8:      	mov	w8, #0x2d               // =45
     7fc:      	mov	w9, #0x6                // =6
     800:      	ldrb	w8, [x24, #0x11]
     804:      	b	0x1264 <kprobe_unwind_php+0x1264>
     808:      	ldr	w29, [sp, #0x88]
     80c:      	adrp	x8, 0x0 <kprobe_unwind_php>
     810:      	ldr	w25, [sp, #0x5c]
     814:      	ldr	x8, [x8]
     818:      	ldr	w8, [x8]
     81c:      	cbnz	w8, 0x1270 <kprobe_unwind_php+0x1270>
     820:      	ldr	w8, [x21, #0x2c0]
     824:      	cmp	w8, #0x7f
     828:      	b.lo	0x12b4 <kprobe_unwind_php+0x12b4>
     82c:      	adrp	x29, 0x0 <kprobe_unwind_php>
     830:      	ldr	x29, [x29]
     834:      	ldr	w8, [x29]
     838:      	cbnz	w8, 0x145c <kprobe_unwind_php+0x145c>
     83c:      	mov	w8, #0x2                // =2
     840:      	add	x9, sp, #0x68
     844:      	add	x1, sp, #0x68
     848:      	str	w8, [sp, #0x68]
     84c:      	mov	w8, #0x1                // =1
     850:      	mov	x0, x23
     854:      	blr	x8
     858:      	cbz	x0, 0x8ac <kprobe_unwind_php+0x8ac>
     85c:      	ldr	x8, [x0]
     860:      	add	x8, x8, #0x1
     864:      	str	x8, [x0]
     868:      	ldr	w8, [x29]
     86c:      	cbz	w8, 0x414 <kprobe_unwind_php+0x414>
     870:      	mov	w8, #0xa                // =10
     874:      	add	x0, sp, #0x18
     878:      	mov	w1, #0x1a               // =26
     87c:      	strh	w8, [sp, #0x30]
     880:      	adrp	x8, 0x0 <kprobe_unwind_php>
     884:      	add	x8, x8, #0x0
     888:      	ldp	x9, x10, [x8]
     88c:      	ldr	x8, [x8, #0x10]
     890:      	stp	x9, x10, [sp, #0x18]
     894:      	str	x8, [sp, #0x28]
     898:      	mov	w8, #0x1a               // =26
     89c:      	mov	w9, #0x6                // =6
     8a0:      	add	x10, sp, #0x18
     8a4:      	blr	x9
     8a8:      	b	0x414 <kprobe_unwind_php+0x414>
     8ac:      	ldr	w8, [x29]
     8b0:      	cbz	w8, 0x414 <kprobe_unwind_php+0x414>
     8b4:      	adrp	x8, 0x0 <kprobe_unwind_php>
     8b8:      	add	x8, x8, #0x0
     8bc:      	add	x0, sp, #0x18
     8c0:      	ldp	x9, x10, [x8, #0x10]
     8c4:      	mov	w1, #0x2e               // =46
     8c8:      	stp	x9, x10, [sp, #0x28]
     8cc:      	ldr	x9, [x8, #0x20]
     8d0:      	add	x10, sp, #0x18
     8d4:      	str	x9, [sp, #0x38]
     8d8:      	ldur	x9, [x8, #0x26]
     8dc:      	stur	x9, [sp, #0x3e]
     8e0:      	ldp	x9, x8, [x8]
     8e4:      	stp	x9, x8, [sp, #0x18]
     8e8:      	mov	w8, #0x2e               // =46
     8ec:      	mov	w9, #0x6                // =6
     8f0:      	ldr	w2, [sp, #0x68]
     8f4:      	blr	x9
     8f8:      	ldr	w8, [x29]
     8fc:      	cbz	w8, 0x414 <kprobe_unwind_php+0x414>
     900:      	b	0x870 <kprobe_unwind_php+0x870>
     904:      	ldr	x8, [sp, #0x68]
     908:      	ldrb	w9, [x24, #0x15]
     90c:      	mov	w10, #0x70              // =112
     910:      	add	x11, sp, #0x88
     914:      	add	x0, sp, #0x88
     918:      	mov	w1, #0x4                // =4
     91c:      	add	x8, x8, x9
     920:      	mov	w9, #0x4                // =4
     924:      	ldr	x8, [sp, #0x68]
     928:      	ldrb	w9, [x24, #0x15]
     92c:      	add	x2, x8, x9
     930:      	blr	x10
     934:      	cbz	x0, 0xa58 <kprobe_unwind_php+0xa58>
     938:      	ldr	w8, [x29]
     93c:      	cbnz	w8, 0x1960 <kprobe_unwind_php+0x1960>
     940:      	mov	w25, #0x27              // =39
     944:      	b	0x354 <kprobe_unwind_php+0x354>
     948:      	ldr	x8, [sp, #0x70]
     94c:      	cbz	x8, 0xa9c <kprobe_unwind_php+0xa9c>
     950:      	ldrb	w9, [x24, #0x14]
     954:      	mov	w10, #0x70              // =112
     958:      	add	x11, sp, #0x8c
     95c:      	add	x0, sp, #0x8c
     960:      	mov	w1, #0x1                // =1
     964:      	add	x8, x8, x9
     968:      	mov	w9, #0x1                // =1
     96c:      	ldr	x8, [sp, #0x70]
     970:      	ldrb	w9, [x24, #0x14]
     974:      	add	x2, x8, x9
     978:      	blr	x10
     97c:      	cbz	x0, 0xccc <kprobe_unwind_php+0xccc>
     980:      	ldr	w8, [x29]
     984:      	cbnz	w8, 0x19b8 <kprobe_unwind_php+0x19b8>
     988:      	mov	w25, #0x26              // =38
     98c:      	b	0x684 <kprobe_unwind_php+0x684>
     990:      	ldr	w8, [x29]
     994:      	cbnz	w8, 0x18b8 <kprobe_unwind_php+0x18b8>
     998:      	cmp	w25, #0x23
     99c:      	b.ne	0x414 <kprobe_unwind_php+0x414>
     9a0:      	ldr	x8, [sp, #0x60]
     9a4:      	ldrb	w9, [x24, #0x12]
     9a8:      	mov	w10, #0x70              // =112
     9ac:      	add	x11, sp, #0x60
     9b0:      	add	x0, sp, #0x60
     9b4:      	mov	w1, #0x8                // =8
     9b8:      	add	x8, x8, x9
     9bc:      	mov	w9, #0x8                // =8
     9c0:      	ldr	x8, [sp, #0x60]
     9c4:      	ldrb	w9, [x24, #0x12]
     9c8:      	add	x2, x8, x9
     9cc:      	blr	x10
     9d0:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
     9d4:      	ldr	x25, [sp, #0x60]
     9d8:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
     9dc:      	ldrb	w8, [sp, #0x5e]
     9e0:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
     9e4:      	ldrb	w8, [x24, #0x10]
     9e8:      	mov	w9, #0x8                // =8
     9ec:      	mov	w10, #0x70              // =112
     9f0:      	add	x11, sp, #0x70
     9f4:      	add	x0, sp, #0x70
     9f8:      	mov	w1, #0x8                // =8
     9fc:      	add	x8, x25, x8
     a00:      	ldrb	w8, [x24, #0x10]
     a04:      	add	x2, x25, x8
     a08:      	blr	x10
     a0c:      	cbz	x0, 0xfa8 <kprobe_unwind_php+0xfa8>
     a10:      	adrp	x8, 0x0 <kprobe_unwind_php>
     a14:      	ldr	x8, [x8]
     a18:      	ldr	w8, [x8]
     a1c:      	cbnz	w8, 0x1cd0 <kprobe_unwind_php+0x1cd0>
     a20:      	mov	w25, #0x25              // =37
     a24:      	str	w25, [sp, #0x70]
     a28:      	mov	w8, #0x1                // =1
     a2c:      	add	x9, sp, #0x70
     a30:      	add	x1, sp, #0x70
     a34:      	mov	x0, x23
     a38:      	blr	x8
     a3c:      	cbz	x0, 0x1040 <kprobe_unwind_php+0x1040>
     a40:      	ldr	x8, [x0]
     a44:      	add	x8, x8, #0x1
     a48:      	str	x8, [x0]
     a4c:      	cmp	w25, #0x23
     a50:      	b.eq	0x1058 <kprobe_unwind_php+0x1058>
     a54:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
     a58:      	ldrb	w8, [x24, #0x13]
     a5c:      	mov	w9, #0x4                // =4
     a60:      	mov	w10, #0x70              // =112
     a64:      	add	x11, sp, #0x5c
     a68:      	add	x0, sp, #0x5c
     a6c:      	mov	w1, #0x4                // =4
     a70:      	add	x8, x25, x8
     a74:      	ldrb	w8, [x24, #0x13]
     a78:      	add	x2, x25, x8
     a7c:      	blr	x10
     a80:      	cbz	x0, 0xe1c <kprobe_unwind_php+0xe1c>
     a84:      	ldr	w8, [x29]
     a88:      	cbnz	w8, 0x1b70 <kprobe_unwind_php+0x1b70>
     a8c:      	adrp	x29, 0x0 <kprobe_unwind_php>
     a90:      	mov	w25, #0x25              // =37
     a94:      	ldr	x29, [x29]
     a98:      	b	0x354 <kprobe_unwind_php+0x354>
     a9c:      	ldr	w8, [x21, #0x2c0]
     aa0:      	cmp	w8, #0x7e
     aa4:      	b.hi	0x394 <kprobe_unwind_php+0x394>
     aa8:      	add	w9, w8, #0x1
     aac:      	mov	x10, #-0x2              // =-2
     ab0:      	mov	w25, #0x23              // =35
     ab4:      	str	w9, [x21, #0x2c0]
     ab8:      	mov	w9, #0x18               // =24
     abc:      	umaddl	x8, w8, w9, x21
     ac0:      	add	x9, x8, #0x2d0
     ac4:      	str	x10, [x8, #0x2d8]
     ac8:      	mov	w10, #0x2               // =2
     acc:      	str	xzr, [x8, #0x2d0]
     ad0:      	str	wzr, [x8, #0x2e4]
     ad4:      	strb	w10, [x8, #0x2e0]
     ad8:      	stur	wzr, [x9, #0x11]
     adc:      	b	0x684 <kprobe_unwind_php+0x684>
     ae0:      	adrp	x8, 0x0 <kprobe_unwind_php>
     ae4:      	add	x8, x8, #0x0
     ae8:      	add	x0, sp, #0x18
     aec:      	ldp	x9, x10, [x8, #0x10]
     af0:      	mov	w1, #0x2e               // =46
     af4:      	stp	x9, x10, [sp, #0x28]
     af8:      	ldr	x9, [x8, #0x20]
     afc:      	add	x10, sp, #0x18
     b00:      	str	x9, [sp, #0x38]
     b04:      	ldur	x9, [x8, #0x26]
     b08:      	stur	x9, [sp, #0x3e]
     b0c:      	ldp	x9, x8, [x8]
     b10:      	stp	x9, x8, [sp, #0x18]
     b14:      	mov	w8, #0x2e               // =46
     b18:      	mov	w9, #0x6                // =6
     b1c:      	ldr	w2, [sp, #0x70]
     b20:      	blr	x9
     b24:      	ldr	x8, [x21, #0xf50]
     b28:      	add	x22, x21, #0xf50
     b2c:      	cbnz	x8, 0x134 <kprobe_unwind_php+0x134>
     b30:      	ldr	x8, [x24]
     b34:      	mov	w9, #0x8                // =8
     b38:      	mov	w10, #0x70              // =112
     b3c:      	mov	x0, x22
     b40:      	ldr	x2, [x24]
     b44:      	mov	w1, #0x8                // =8
     b48:      	blr	x10
     b4c:      	cbz	x0, 0x134 <kprobe_unwind_php+0x134>
     b50:      	ldr	w8, [x29]
     b54:      	cbnz	w8, 0xd34 <kprobe_unwind_php+0xd34>
     b58:      	mov	w8, #0x24               // =36
     b5c:      	add	x9, sp, #0x70
     b60:      	add	x1, sp, #0x70
     b64:      	str	w8, [sp, #0x70]
     b68:      	mov	w8, #0x1                // =1
     b6c:      	mov	x0, x23
     b70:      	blr	x8
     b74:      	cbz	x0, 0xb8c <kprobe_unwind_php+0xb8c>
     b78:      	ldr	x8, [x0]
     b7c:      	mov	w23, #0x1               // =1
     b80:      	add	x8, x8, #0x1
     b84:      	str	x8, [x0]
     b88:      	b	0xb98 <kprobe_unwind_php+0xb98>
     b8c:      	ldr	w8, [x29]
     b90:      	cbnz	w8, 0xec8 <kprobe_unwind_php+0xec8>
     b94:      	mov	w23, #0x1               // =1
     b98:      	str	wzr, [sp, #0x18]
     b9c:      	mov	w8, #0x1                // =1
     ba0:      	add	x9, sp, #0x18
     ba4:      	add	x1, sp, #0x18
     ba8:      	mov	x0, x20
     bac:      	blr	x8
     bb0:      	cbz	x0, 0xc04 <kprobe_unwind_php+0xc04>
     bb4:      	mov	w20, #0x1374            // =4980
     bb8:      	ldrb	w8, [x0, x20]
     bbc:      	cmp	w8, #0x1d
     bc0:      	b.lo	0xc30 <kprobe_unwind_php+0xc30>
     bc4:      	mov	w8, #0x5                // =5
     bc8:      	mov	x21, x0
     bcc:      	add	x9, sp, #0x70
     bd0:      	str	w8, [x0, #0xf1c]
     bd4:      	mov	w8, #0x44               // =68
     bd8:      	adrp	x0, 0x0 <kprobe_unwind_php>
     bdc:      	add	x1, sp, #0x70
     be0:      	str	w8, [sp, #0x70]
     be4:      	mov	w8, #0x1                // =1
     be8:      	ldr	x0, [x0]
     bec:      	blr	x8
     bf0:      	cbz	x0, 0xc1c <kprobe_unwind_php+0xc1c>
     bf4:      	ldr	x8, [x0]
     bf8:      	add	x8, x8, #0x1
     bfc:      	str	x8, [x0]
     c00:      	b	0xc24 <kprobe_unwind_php+0xc24>
     c04:      	adrp	x10, 0x0 <kprobe_unwind_php>
     c08:      	mov	x9, xzr
     c0c:      	mov	w8, #0xc                // =12
     c10:      	ldr	x10, [x10]
     c14:      	mov	w23, wzr
     c18:      	b	0xc48 <kprobe_unwind_php+0xc48>
     c1c:      	ldr	w8, [x29]
     c20:      	cbnz	w8, 0xd84 <kprobe_unwind_php+0xd84>
     c24:      	ldrb	w8, [x21, x20]
     c28:      	mov	w23, wzr
     c2c:      	mov	x0, x21
     c30:      	add	w8, w8, #0x1
     c34:      	adrp	x10, 0x0 <kprobe_unwind_php>
     c38:      	mov	w9, w23
     c3c:      	strb	w8, [x0, x20]
     c40:      	mov	w8, #0xc                // =12
     c44:      	ldr	x10, [x10]
     c48:      	adrp	x1, 0x0 <kprobe_unwind_php>
     c4c:      	mov	x0, x19
     c50:      	mov	w2, w23
     c54:      	ldr	x1, [x1]
     c58:      	blr	x8
     c5c:      	ldp	x20, x19, [sp, #0xc0]
     c60:      	mov	w0, #-0x1               // =-1
     c64:      	ldr	x29, [sp, #0x80]
     c68:      	ldp	x22, x21, [sp, #0xb0]
     c6c:      	ldp	x24, x23, [sp, #0xa0]
     c70:      	ldp	x30, x25, [sp, #0x90]
     c74:      	add	sp, sp, #0xd0
     c78:      	ret
     c7c:      	mov	w8, #0x2978             // =10616
     c80:      	add	x0, sp, #0x18
     c84:      	mov	w1, #0x33               // =51
     c88:      	movk	w8, #0xa, lsl #16
     c8c:      	stur	w8, [sp, #0x47]
     c90:      	adrp	x8, 0x0 <kprobe_unwind_php>
     c94:      	add	x8, x8, #0x0
     c98:      	ldp	x9, x10, [x8, #0x10]
     c9c:      	stp	x9, x10, [sp, #0x28]
     ca0:      	ldp	x9, x10, [x8, #0x20]
     ca4:      	stp	x9, x10, [sp, #0x38]
     ca8:      	ldp	x9, x8, [x8]
     cac:      	add	x10, sp, #0x18
     cb0:      	stp	x9, x8, [sp, #0x18]
     cb4:      	mov	w8, #0x33               // =51
     cb8:      	mov	w9, #0x6                // =6
     cbc:      	ldrb	w8, [x24, #0x10]
     cc0:      	add	x2, x25, x8
     cc4:      	blr	x9
     cc8:      	b	0x20c <kprobe_unwind_php+0x20c>
     ccc:      	ldrb	w8, [sp, #0x8c]
     cd0:      	str	wzr, [sp, #0x88]
     cd4:      	cmp	w8, #0x4
     cd8:      	b.eq	0xce8 <kprobe_unwind_php+0xce8>
     cdc:      	mov	w29, wzr
     ce0:      	cmp	w8, #0x2
     ce4:      	b.ne	0x13f4 <kprobe_unwind_php+0x13f4>
     ce8:      	ldrb	w8, [x24, #0x11]
     cec:      	mov	w9, #0x8                // =8
     cf0:      	mov	w10, #0x70              // =112
     cf4:      	add	x11, sp, #0x68
     cf8:      	add	x0, sp, #0x68
     cfc:      	mov	w1, #0x8                // =8
     d00:      	add	x8, x25, x8
     d04:      	ldrb	w8, [x24, #0x11]
     d08:      	add	x2, x25, x8
     d0c:      	blr	x10
     d10:      	cbz	x0, 0xf54 <kprobe_unwind_php+0xf54>
     d14:      	adrp	x8, 0x0 <kprobe_unwind_php>
     d18:      	ldr	x8, [x8]
     d1c:      	ldr	w8, [x8]
     d20:      	cbnz	w8, 0x1c84 <kprobe_unwind_php+0x1c84>
     d24:      	adrp	x29, 0x0 <kprobe_unwind_php>
     d28:      	mov	w25, #0x25              // =37
     d2c:      	ldr	x29, [x29]
     d30:      	b	0x684 <kprobe_unwind_php+0x684>
     d34:      	adrp	x8, 0x0 <kprobe_unwind_php>
     d38:      	add	x8, x8, #0x0
     d3c:      	add	x0, sp, #0x18
     d40:      	ldp	x9, x10, [x8, #0x20]
     d44:      	mov	w1, #0x3e               // =62
     d48:      	stp	x9, x10, [sp, #0x38]
     d4c:      	ldr	x9, [x8, #0x30]
     d50:      	str	x9, [sp, #0x48]
     d54:      	ldur	x9, [x8, #0x36]
     d58:      	stur	x9, [sp, #0x4e]
     d5c:      	ldp	x9, x10, [x8]
     d60:      	stp	x9, x10, [sp, #0x18]
     d64:      	add	x10, sp, #0x18
     d68:      	ldp	x9, x8, [x8, #0x10]
     d6c:      	stp	x9, x8, [sp, #0x28]
     d70:      	mov	w8, #0x3e               // =62
     d74:      	mov	w9, #0x6                // =6
     d78:      	ldr	x2, [x24]
     d7c:      	blr	x9
     d80:      	b	0xb58 <kprobe_unwind_php+0xb58>
     d84:      	adrp	x8, 0x0 <kprobe_unwind_php>
     d88:      	add	x8, x8, #0x0
     d8c:      	add	x0, sp, #0x18
     d90:      	ldp	x9, x10, [x8, #0x10]
     d94:      	mov	w1, #0x2e               // =46
     d98:      	stp	x9, x10, [sp, #0x28]
     d9c:      	ldr	x9, [x8, #0x20]
     da0:      	add	x10, sp, #0x18
     da4:      	str	x9, [sp, #0x38]
     da8:      	ldur	x9, [x8, #0x26]
     dac:      	stur	x9, [sp, #0x3e]
     db0:      	ldp	x9, x8, [x8]
     db4:      	stp	x9, x8, [sp, #0x18]
     db8:      	mov	w8, #0x2e               // =46
     dbc:      	mov	w9, #0x6                // =6
     dc0:      	ldr	w2, [sp, #0x70]
     dc4:      	blr	x9
     dc8:      	b	0xc24 <kprobe_unwind_php+0xc24>
     dcc:      	adrp	x8, 0x0 <kprobe_unwind_php>
     dd0:      	add	x8, x8, #0x0
     dd4:      	add	x0, sp, #0x18
     dd8:      	ldp	x9, x10, [x8, #0x10]
     ddc:      	mov	w1, #0x2e               // =46
     de0:      	stp	x9, x10, [sp, #0x28]
     de4:      	ldr	x9, [x8, #0x20]
     de8:      	add	x10, sp, #0x18
     dec:      	str	x9, [sp, #0x38]
     df0:      	ldur	x9, [x8, #0x26]
     df4:      	stur	x9, [sp, #0x3e]
     df8:      	ldp	x9, x8, [x8]
     dfc:      	stp	x9, x8, [sp, #0x18]
     e00:      	mov	w8, #0x2e               // =46
     e04:      	mov	w9, #0x6                // =6
     e08:      	ldr	w2, [sp, #0x70]
     e0c:      	blr	x9
     e10:      	cmp	w25, #0x23
     e14:      	b.eq	0x29c <kprobe_unwind_php+0x29c>
     e18:      	b	0x414 <kprobe_unwind_php+0x414>
     e1c:      	ldr	w10, [sp, #0x88]
     e20:      	ldr	w25, [sp, #0x5c]
     e24:      	ldr	w8, [x29]
     e28:      	cbnz	w8, 0x17c4 <kprobe_unwind_php+0x17c4>
     e2c:      	ldr	w8, [x21, #0x2c0]
     e30:      	cmp	w8, #0x7e
     e34:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
     e38:      	add	w9, w8, #0x1
     e3c:      	mov	w10, w10
     e40:      	adrp	x29, 0x0 <kprobe_unwind_php>
     e44:      	str	w9, [x21, #0x2c0]
     e48:      	mov	w9, #0x18               // =24
     e4c:      	orr	x10, x10, x25, lsl #32
     e50:      	mov	w25, #0x23              // =35
     e54:      	umaddl	x8, w8, w9, x21
     e58:      	ldr	x9, [sp, #0x70]
     e5c:      	str	x10, [x8, #0x2d8]
     e60:      	str	wzr, [x8, #0x2e4]
     e64:      	str	x9, [x8, #0x2d0]
     e68:      	ldr	w9, [sp, #0xc]
     e6c:      	strb	w9, [x8, #0x2e0]
     e70:      	add	x9, x8, #0x2d0
     e74:      	stur	wzr, [x9, #0x11]
     e78:      	ldr	x29, [x29]
     e7c:      	b	0x354 <kprobe_unwind_php+0x354>
     e80:      	adrp	x8, 0x0 <kprobe_unwind_php>
     e84:      	add	x8, x8, #0x0
     e88:      	add	x0, sp, #0x18
     e8c:      	ldp	x9, x10, [x8, #0x20]
     e90:      	mov	w1, #0x40               // =64
     e94:      	stp	x9, x10, [sp, #0x38]
     e98:      	ldp	x9, x10, [x8, #0x30]
     e9c:      	stp	x9, x10, [sp, #0x48]
     ea0:      	ldp	x9, x10, [x8]
     ea4:      	stp	x9, x10, [sp, #0x18]
     ea8:      	ldp	x9, x8, [x8, #0x10]
     eac:      	add	x10, sp, #0x18
     eb0:      	stp	x9, x8, [sp, #0x28]
     eb4:      	mov	w8, #0x40               // =64
     eb8:      	mov	w9, #0x6                // =6
     ebc:      	ldr	x2, [sp, #0x60]
     ec0:      	blr	x9
     ec4:      	b	0x2d8 <kprobe_unwind_php+0x2d8>
     ec8:      	adrp	x8, 0x0 <kprobe_unwind_php>
     ecc:      	add	x8, x8, #0x0
     ed0:      	add	x0, sp, #0x18
     ed4:      	ldp	x9, x10, [x8, #0x10]
     ed8:      	mov	w1, #0x2e               // =46
     edc:      	stp	x9, x10, [sp, #0x28]
     ee0:      	ldr	x9, [x8, #0x20]
     ee4:      	add	x10, sp, #0x18
     ee8:      	str	x9, [sp, #0x38]
     eec:      	ldur	x9, [x8, #0x26]
     ef0:      	stur	x9, [sp, #0x3e]
     ef4:      	ldp	x9, x8, [x8]
     ef8:      	stp	x9, x8, [sp, #0x18]
     efc:      	mov	w8, #0x2e               // =46
     f00:      	mov	w9, #0x6                // =6
     f04:      	ldr	w2, [sp, #0x70]
     f08:      	blr	x9
     f0c:      	b	0xb94 <kprobe_unwind_php+0xb94>
     f10:      	adrp	x8, 0x0 <kprobe_unwind_php>
     f14:      	add	x8, x8, #0x0
     f18:      	strb	wzr, [sp, #0x48]
     f1c:      	add	x0, sp, #0x18
     f20:      	ldp	x9, x10, [x8, #0x10]
     f24:      	mov	w1, #0x31               // =49
     f28:      	stp	x9, x10, [sp, #0x28]
     f2c:      	ldp	x9, x10, [x8, #0x20]
     f30:      	stp	x9, x10, [sp, #0x38]
     f34:      	ldp	x9, x8, [x8]
     f38:      	add	x10, sp, #0x18
     f3c:      	stp	x9, x8, [sp, #0x18]
     f40:      	mov	w8, #0x31               // =49
     f44:      	mov	w9, #0x6                // =6
     f48:      	ldr	x2, [sp, #0x70]
     f4c:      	blr	x9
     f50:      	b	0x284 <kprobe_unwind_php+0x284>
     f54:      	ldr	x8, [sp, #0x68]
     f58:      	ldrb	w9, [x24, #0x15]
     f5c:      	mov	w10, #0x70              // =112
     f60:      	add	x11, sp, #0x88
     f64:      	add	x0, sp, #0x88
     f68:      	mov	w1, #0x4                // =4
     f6c:      	add	x8, x8, x9
     f70:      	mov	w9, #0x4                // =4
     f74:      	ldr	x8, [sp, #0x68]
     f78:      	ldrb	w9, [x24, #0x15]
     f7c:      	add	x2, x8, x9
     f80:      	blr	x10
     f84:      	cbz	x0, 0x1154 <kprobe_unwind_php+0x1154>
     f88:      	adrp	x8, 0x0 <kprobe_unwind_php>
     f8c:      	ldr	x8, [x8]
     f90:      	ldr	w8, [x8]
     f94:      	cbnz	w8, 0x1eb4 <kprobe_unwind_php+0x1eb4>
     f98:      	adrp	x29, 0x0 <kprobe_unwind_php>
     f9c:      	mov	w25, #0x27              // =39
     fa0:      	ldr	x29, [x29]
     fa4:      	b	0x684 <kprobe_unwind_php+0x684>
     fa8:      	ldr	x8, [sp, #0x70]
     fac:      	cbz	x8, 0x11d4 <kprobe_unwind_php+0x11d4>
     fb0:      	ldrb	w9, [x24, #0x14]
     fb4:      	mov	w10, #0x70              // =112
     fb8:      	add	x11, sp, #0x8c
     fbc:      	add	x0, sp, #0x8c
     fc0:      	mov	w1, #0x1                // =1
     fc4:      	add	x8, x8, x9
     fc8:      	mov	w9, #0x1                // =1
     fcc:      	ldr	x8, [sp, #0x70]
     fd0:      	ldrb	w9, [x24, #0x14]
     fd4:      	add	x2, x8, x9
     fd8:      	blr	x10
     fdc:      	cbz	x0, 0x12fc <kprobe_unwind_php+0x12fc>
     fe0:      	adrp	x8, 0x0 <kprobe_unwind_php>
     fe4:      	ldr	x8, [x8]
     fe8:      	ldr	w8, [x8]
     fec:      	cbnz	w8, 0x1f14 <kprobe_unwind_php+0x1f14>
     ff0:      	mov	w25, #0x26              // =38
     ff4:      	b	0xa24 <kprobe_unwind_php+0xa24>
     ff8:      	adrp	x8, 0x0 <kprobe_unwind_php>
     ffc:      	add	x8, x8, #0x0
    1000:      	add	x0, sp, #0x18
    1004:      	ldp	x9, x10, [x8, #0x10]
    1008:      	mov	w1, #0x2e               // =46
    100c:      	stp	x9, x10, [sp, #0x28]
    1010:      	ldr	x9, [x8, #0x20]
    1014:      	add	x10, sp, #0x18
    1018:      	str	x9, [sp, #0x38]
    101c:      	ldur	x9, [x8, #0x26]
    1020:      	stur	x9, [sp, #0x3e]
    1024:      	ldp	x9, x8, [x8]
    1028:      	stp	x9, x8, [sp, #0x18]
    102c:      	mov	w8, #0x2e               // =46
    1030:      	mov	w9, #0x6                // =6
    1034:      	ldr	w2, [sp, #0x70]
    1038:      	blr	x9
    103c:      	b	0x414 <kprobe_unwind_php+0x414>
    1040:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1044:      	ldr	x8, [x8]
    1048:      	ldr	w8, [x8]
    104c:      	cbnz	w8, 0x1e0c <kprobe_unwind_php+0x1e0c>
    1050:      	cmp	w25, #0x23
    1054:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    1058:      	ldr	x8, [sp, #0x60]
    105c:      	ldrb	w9, [x24, #0x12]
    1060:      	mov	w10, #0x70              // =112
    1064:      	add	x11, sp, #0x60
    1068:      	add	x0, sp, #0x60
    106c:      	mov	w1, #0x8                // =8
    1070:      	add	x8, x8, x9
    1074:      	mov	w9, #0x8                // =8
    1078:      	ldr	x8, [sp, #0x60]
    107c:      	ldrb	w9, [x24, #0x12]
    1080:      	add	x2, x8, x9
    1084:      	blr	x10
    1088:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    108c:      	ldr	x29, [x29]
    1090:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    1094:      	ldr	x25, [sp, #0x60]
    1098:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    109c:      	ldrb	w8, [sp, #0x5e]
    10a0:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    10a4:      	ldrb	w8, [x24, #0x10]
    10a8:      	mov	w9, #0x8                // =8
    10ac:      	mov	w10, #0x70              // =112
    10b0:      	add	x11, sp, #0x70
    10b4:      	add	x0, sp, #0x70
    10b8:      	mov	w1, #0x8                // =8
    10bc:      	add	x8, x25, x8
    10c0:      	ldrb	w8, [x24, #0x10]
    10c4:      	add	x2, x25, x8
    10c8:      	blr	x10
    10cc:      	cbz	x0, 0x1580 <kprobe_unwind_php+0x1580>
    10d0:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    10d4:      	ldr	x8, [x8]
    10d8:      	ldr	w8, [x8]
    10dc:      	cbnz	w8, 0x2198 <kprobe_unwind_php+0x2198>
    10e0:      	mov	w25, #0x25              // =37
    10e4:      	str	w25, [sp, #0x70]
    10e8:      	mov	w8, #0x1                // =1
    10ec:      	add	x9, sp, #0x70
    10f0:      	add	x1, sp, #0x70
    10f4:      	mov	x0, x23
    10f8:      	blr	x8
    10fc:      	cbz	x0, 0x15d0 <kprobe_unwind_php+0x15d0>
    1100:      	ldr	x8, [x0]
    1104:      	add	x8, x8, #0x1
    1108:      	str	x8, [x0]
    110c:      	cmp	w25, #0x23
    1110:      	b.eq	0x15e8 <kprobe_unwind_php+0x15e8>
    1114:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    1118:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    111c:      	add	x8, x8, #0x0
    1120:      	add	x0, sp, #0x18
    1124:      	ldp	x9, x10, [x8, #0x10]
    1128:      	mov	w1, #0x25               // =37
    112c:      	stp	x9, x10, [sp, #0x28]
    1130:      	ldur	x9, [x8, #0x1d]
    1134:      	add	x10, sp, #0x18
    1138:      	stur	x9, [sp, #0x35]
    113c:      	ldp	x8, x9, [x8]
    1140:      	stp	x8, x9, [sp, #0x18]
    1144:      	mov	w8, #0x25               // =37
    1148:      	mov	w9, #0x6                // =6
    114c:      	blr	x9
    1150:      	b	0x39c <kprobe_unwind_php+0x39c>
    1154:      	ldrb	w8, [x24, #0x13]
    1158:      	mov	w9, #0x4                // =4
    115c:      	mov	w10, #0x70              // =112
    1160:      	add	x11, sp, #0x5c
    1164:      	add	x0, sp, #0x5c
    1168:      	mov	w1, #0x4                // =4
    116c:      	add	x8, x25, x8
    1170:      	ldrb	w8, [x24, #0x13]
    1174:      	add	x2, x25, x8
    1178:      	blr	x10
    117c:      	cbz	x0, 0x13f0 <kprobe_unwind_php+0x13f0>
    1180:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1184:      	ldr	x8, [x8]
    1188:      	ldr	w8, [x8]
    118c:      	cbz	w8, 0xd24 <kprobe_unwind_php+0xd24>
    1190:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1194:      	add	x8, x8, #0x0
    1198:      	add	x0, sp, #0x18
    119c:      	ldp	x9, x10, [x8, #0x20]
    11a0:      	mov	w1, #0x35               // =53
    11a4:      	mov	x2, x25
    11a8:      	stp	x9, x10, [sp, #0x38]
    11ac:      	ldur	x9, [x8, #0x2d]
    11b0:      	stur	x9, [sp, #0x45]
    11b4:      	ldp	x9, x10, [x8]
    11b8:      	stp	x9, x10, [sp, #0x18]
    11bc:      	ldp	x8, x9, [x8, #0x10]
    11c0:      	add	x10, sp, #0x18
    11c4:      	stp	x8, x9, [sp, #0x28]
    11c8:      	mov	w8, #0x35               // =53
    11cc:      	mov	w9, #0x6                // =6
    11d0:      	b	0x1cc8 <kprobe_unwind_php+0x1cc8>
    11d4:      	ldr	w8, [x21, #0x2c0]
    11d8:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    11dc:      	ldr	x29, [x29]
    11e0:      	cmp	w8, #0x7e
    11e4:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    11e8:      	add	w9, w8, #0x1
    11ec:      	mov	x10, #-0x2              // =-2
    11f0:      	str	w9, [x21, #0x2c0]
    11f4:      	mov	w9, #0x18               // =24
    11f8:      	umaddl	x8, w8, w9, x21
    11fc:      	add	x9, x8, #0x2d0
    1200:      	str	x10, [x8, #0x2d8]
    1204:      	mov	w10, #0x2               // =2
    1208:      	str	xzr, [x8, #0x2d0]
    120c:      	strb	w10, [x8, #0x2e0]
    1210:      	mov	w25, #0x23              // =35
    1214:      	str	wzr, [x8, #0x2e4]
    1218:      	stur	wzr, [x9, #0x11]
    121c:      	b	0xa24 <kprobe_unwind_php+0xa24>
    1220:      	mov	w8, #0x2978             // =10616
    1224:      	add	x0, sp, #0x18
    1228:      	mov	w1, #0x33               // =51
    122c:      	movk	w8, #0xa, lsl #16
    1230:      	stur	w8, [sp, #0x47]
    1234:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1238:      	add	x8, x8, #0x0
    123c:      	ldp	x9, x10, [x8, #0x10]
    1240:      	stp	x9, x10, [sp, #0x28]
    1244:      	ldp	x9, x10, [x8, #0x20]
    1248:      	stp	x9, x10, [sp, #0x38]
    124c:      	ldp	x9, x8, [x8]
    1250:      	add	x10, sp, #0x18
    1254:      	stp	x9, x8, [sp, #0x18]
    1258:      	mov	w8, #0x33               // =51
    125c:      	mov	w9, #0x6                // =6
    1260:      	ldrb	w8, [x24, #0x10]
    1264:      	add	x2, x25, x8
    1268:      	blr	x9
    126c:      	b	0x350 <kprobe_unwind_php+0x350>
    1270:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1274:      	add	x8, x8, #0x0
    1278:      	add	x0, sp, #0x18
    127c:      	ldp	x9, x10, [x8]
    1280:      	ldur	x8, [x8, #0xe]
    1284:      	mov	w1, #0x16               // =22
    1288:      	stp	x9, x10, [sp, #0x18]
    128c:      	stur	x8, [sp, #0x26]
    1290:      	mov	w8, #0x16               // =22
    1294:      	mov	w9, #0x6                // =6
    1298:      	add	x10, sp, #0x18
    129c:      	ldr	x2, [sp, #0x70]
    12a0:      	ldr	w3, [sp, #0x88]
    12a4:      	blr	x9
    12a8:      	ldr	w8, [x21, #0x2c0]
    12ac:      	cmp	w8, #0x7f
    12b0:      	b.hs	0x82c <kprobe_unwind_php+0x82c>
    12b4:      	add	w9, w8, #0x1
    12b8:      	mov	w10, w29
    12bc:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    12c0:      	str	w9, [x21, #0x2c0]
    12c4:      	mov	w9, #0x18               // =24
    12c8:      	orr	x10, x10, x25, lsl #32
    12cc:      	mov	w25, #0x23              // =35
    12d0:      	umaddl	x8, w8, w9, x21
    12d4:      	ldr	x9, [sp, #0x70]
    12d8:      	str	x10, [x8, #0x2d8]
    12dc:      	str	wzr, [x8, #0x2e4]
    12e0:      	str	x9, [x8, #0x2d0]
    12e4:      	ldr	w9, [sp, #0xc]
    12e8:      	strb	w9, [x8, #0x2e0]
    12ec:      	add	x9, x8, #0x2d0
    12f0:      	stur	wzr, [x9, #0x11]
    12f4:      	ldr	x29, [x29]
    12f8:      	b	0x210 <kprobe_unwind_php+0x210>
    12fc:      	ldrb	w8, [sp, #0x8c]
    1300:      	str	wzr, [sp, #0x88]
    1304:      	cmp	w8, #0x4
    1308:      	b.eq	0x1318 <kprobe_unwind_php+0x1318>
    130c:      	mov	w29, wzr
    1310:      	cmp	w8, #0x2
    1314:      	b.ne	0x190c <kprobe_unwind_php+0x190c>
    1318:      	ldrb	w8, [x24, #0x11]
    131c:      	mov	w9, #0x8                // =8
    1320:      	mov	w10, #0x70              // =112
    1324:      	add	x11, sp, #0x68
    1328:      	add	x0, sp, #0x68
    132c:      	mov	w1, #0x8                // =8
    1330:      	add	x8, x25, x8
    1334:      	ldrb	w8, [x24, #0x11]
    1338:      	add	x2, x25, x8
    133c:      	blr	x10
    1340:      	cbz	x0, 0x1534 <kprobe_unwind_php+0x1534>
    1344:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1348:      	ldr	x8, [x8]
    134c:      	ldr	w8, [x8]
    1350:      	cbz	w8, 0xa20 <kprobe_unwind_php+0xa20>
    1354:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1358:      	add	x8, x8, #0x0
    135c:      	add	x0, sp, #0x18
    1360:      	ldp	x9, x10, [x8, #0x10]
    1364:      	mov	w1, #0x2d               // =45
    1368:      	stp	x9, x10, [sp, #0x28]
    136c:      	ldr	x9, [x8, #0x20]
    1370:      	add	x10, sp, #0x18
    1374:      	str	x9, [sp, #0x38]
    1378:      	ldur	x9, [x8, #0x25]
    137c:      	stur	x9, [sp, #0x3d]
    1380:      	ldp	x9, x8, [x8]
    1384:      	stp	x9, x8, [sp, #0x18]
    1388:      	mov	w8, #0x2d               // =45
    138c:      	mov	w9, #0x6                // =6
    1390:      	ldrb	w8, [x24, #0x11]
    1394:      	add	x2, x25, x8
    1398:      	blr	x9
    139c:      	b	0xa20 <kprobe_unwind_php+0xa20>
    13a0:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    13a4:      	add	x8, x8, #0x0
    13a8:      	add	x0, sp, #0x18
    13ac:      	ldp	x9, x10, [x8, #0x10]
    13b0:      	mov	w1, #0x2e               // =46
    13b4:      	stp	x9, x10, [sp, #0x28]
    13b8:      	ldr	x9, [x8, #0x20]
    13bc:      	add	x10, sp, #0x18
    13c0:      	str	x9, [sp, #0x38]
    13c4:      	ldur	x9, [x8, #0x26]
    13c8:      	stur	x9, [sp, #0x3e]
    13cc:      	ldp	x9, x8, [x8]
    13d0:      	stp	x9, x8, [sp, #0x18]
    13d4:      	mov	w8, #0x2e               // =46
    13d8:      	mov	w9, #0x6                // =6
    13dc:      	ldr	w2, [sp, #0x70]
    13e0:      	blr	x9
    13e4:      	cmp	w25, #0x23
    13e8:      	b.eq	0x608 <kprobe_unwind_php+0x608>
    13ec:      	b	0x414 <kprobe_unwind_php+0x414>
    13f0:      	ldr	w29, [sp, #0x88]
    13f4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    13f8:      	ldr	w25, [sp, #0x5c]
    13fc:      	ldr	x8, [x8]
    1400:      	ldr	w8, [x8]
    1404:      	cbnz	w8, 0x1d20 <kprobe_unwind_php+0x1d20>
    1408:      	ldr	w8, [x21, #0x2c0]
    140c:      	cmp	w8, #0x7e
    1410:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    1414:      	add	w9, w8, #0x1
    1418:      	mov	w10, w29
    141c:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    1420:      	str	w9, [x21, #0x2c0]
    1424:      	mov	w9, #0x18               // =24
    1428:      	orr	x10, x10, x25, lsl #32
    142c:      	mov	w25, #0x23              // =35
    1430:      	umaddl	x8, w8, w9, x21
    1434:      	ldr	x9, [sp, #0x70]
    1438:      	str	x10, [x8, #0x2d8]
    143c:      	str	wzr, [x8, #0x2e4]
    1440:      	str	x9, [x8, #0x2d0]
    1444:      	ldr	w9, [sp, #0xc]
    1448:      	strb	w9, [x8, #0x2e0]
    144c:      	add	x9, x8, #0x2d0
    1450:      	stur	wzr, [x9, #0x11]
    1454:      	ldr	x29, [x29]
    1458:      	b	0x684 <kprobe_unwind_php+0x684>
    145c:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1460:      	add	x8, x8, #0x0
    1464:      	add	x0, sp, #0x18
    1468:      	ldp	x9, x10, [x8, #0x10]
    146c:      	mov	w1, #0x25               // =37
    1470:      	stp	x9, x10, [sp, #0x28]
    1474:      	ldur	x9, [x8, #0x1d]
    1478:      	add	x10, sp, #0x18
    147c:      	stur	x9, [sp, #0x35]
    1480:      	ldp	x8, x9, [x8]
    1484:      	stp	x8, x9, [sp, #0x18]
    1488:      	mov	w8, #0x25               // =37
    148c:      	mov	w9, #0x6                // =6
    1490:      	blr	x9
    1494:      	b	0x83c <kprobe_unwind_php+0x83c>
    1498:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    149c:      	add	x8, x8, #0x0
    14a0:      	strb	wzr, [sp, #0x50]
    14a4:      	add	x0, sp, #0x18
    14a8:      	ldp	x9, x10, [x8, #0x20]
    14ac:      	mov	w1, #0x39               // =57
    14b0:      	stp	x9, x10, [sp, #0x38]
    14b4:      	ldr	x9, [x8, #0x30]
    14b8:      	str	x9, [sp, #0x48]
    14bc:      	ldp	x9, x10, [x8]
    14c0:      	stp	x9, x10, [sp, #0x18]
    14c4:      	ldp	x8, x9, [x8, #0x10]
    14c8:      	add	x10, sp, #0x18
    14cc:      	stp	x8, x9, [sp, #0x28]
    14d0:      	mov	w8, #0x39               // =57
    14d4:      	mov	w9, #0x6                // =6
    14d8:      	ldr	x8, [sp, #0x68]
    14dc:      	ldrb	w10, [x24, #0x15]
    14e0:      	add	x2, x8, x10
    14e4:      	blr	x9
    14e8:      	mov	w25, #0x27              // =39
    14ec:      	b	0x210 <kprobe_unwind_php+0x210>
    14f0:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    14f4:      	add	x8, x8, #0x0
    14f8:      	strb	wzr, [sp, #0x48]
    14fc:      	add	x0, sp, #0x18
    1500:      	ldp	x9, x10, [x8, #0x10]
    1504:      	mov	w1, #0x31               // =49
    1508:      	stp	x9, x10, [sp, #0x28]
    150c:      	ldp	x9, x10, [x8, #0x20]
    1510:      	stp	x9, x10, [sp, #0x38]
    1514:      	ldp	x9, x8, [x8]
    1518:      	add	x10, sp, #0x18
    151c:      	stp	x9, x8, [sp, #0x18]
    1520:      	mov	w8, #0x31               // =49
    1524:      	mov	w9, #0x6                // =6
    1528:      	ldr	x2, [sp, #0x70]
    152c:      	blr	x9
    1530:      	b	0x5f0 <kprobe_unwind_php+0x5f0>
    1534:      	ldr	x8, [sp, #0x68]
    1538:      	ldrb	w9, [x24, #0x15]
    153c:      	mov	w10, #0x70              // =112
    1540:      	add	x11, sp, #0x88
    1544:      	add	x0, sp, #0x88
    1548:      	mov	w1, #0x4                // =4
    154c:      	add	x8, x8, x9
    1550:      	mov	w9, #0x4                // =4
    1554:      	ldr	x8, [sp, #0x68]
    1558:      	ldrb	w9, [x24, #0x15]
    155c:      	add	x2, x8, x9
    1560:      	blr	x10
    1564:      	cbz	x0, 0x16a8 <kprobe_unwind_php+0x16a8>
    1568:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    156c:      	ldr	x8, [x8]
    1570:      	ldr	w8, [x8]
    1574:      	cbnz	w8, 0x237c <kprobe_unwind_php+0x237c>
    1578:      	mov	w25, #0x27              // =39
    157c:      	b	0xa24 <kprobe_unwind_php+0xa24>
    1580:      	ldr	x8, [sp, #0x70]
    1584:      	cbz	x8, 0x1728 <kprobe_unwind_php+0x1728>
    1588:      	ldrb	w9, [x24, #0x14]
    158c:      	mov	w10, #0x70              // =112
    1590:      	add	x11, sp, #0x8c
    1594:      	add	x0, sp, #0x8c
    1598:      	mov	w1, #0x1                // =1
    159c:      	add	x8, x8, x9
    15a0:      	mov	w9, #0x1                // =1
    15a4:      	ldr	x8, [sp, #0x70]
    15a8:      	ldrb	w9, [x24, #0x14]
    15ac:      	add	x2, x8, x9
    15b0:      	blr	x10
    15b4:      	cbz	x0, 0x1814 <kprobe_unwind_php+0x1814>
    15b8:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    15bc:      	ldr	x8, [x8]
    15c0:      	ldr	w8, [x8]
    15c4:      	cbnz	w8, 0x23d4 <kprobe_unwind_php+0x23d4>
    15c8:      	mov	w25, #0x26              // =38
    15cc:      	b	0x10e4 <kprobe_unwind_php+0x10e4>
    15d0:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    15d4:      	ldr	x8, [x8]
    15d8:      	ldr	w8, [x8]
    15dc:      	cbnz	w8, 0x22d4 <kprobe_unwind_php+0x22d4>
    15e0:      	cmp	w25, #0x23
    15e4:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    15e8:      	ldr	x8, [sp, #0x60]
    15ec:      	ldrb	w9, [x24, #0x12]
    15f0:      	mov	w10, #0x70              // =112
    15f4:      	add	x11, sp, #0x60
    15f8:      	add	x0, sp, #0x60
    15fc:      	mov	w1, #0x8                // =8
    1600:      	add	x8, x8, x9
    1604:      	mov	w9, #0x8                // =8
    1608:      	ldr	x8, [sp, #0x60]
    160c:      	ldrb	w9, [x24, #0x12]
    1610:      	add	x2, x8, x9
    1614:      	blr	x10
    1618:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    161c:      	ldr	x29, [x29]
    1620:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    1624:      	ldr	x25, [sp, #0x60]
    1628:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    162c:      	ldrb	w8, [sp, #0x5e]
    1630:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    1634:      	ldrb	w8, [x24, #0x10]
    1638:      	mov	w9, #0x8                // =8
    163c:      	mov	w10, #0x70              // =112
    1640:      	add	x11, sp, #0x70
    1644:      	add	x0, sp, #0x70
    1648:      	mov	w1, #0x8                // =8
    164c:      	add	x8, x25, x8
    1650:      	ldrb	w8, [x24, #0x10]
    1654:      	add	x2, x25, x8
    1658:      	blr	x10
    165c:      	cbz	x0, 0x1a48 <kprobe_unwind_php+0x1a48>
    1660:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1664:      	ldr	x8, [x8]
    1668:      	ldr	w8, [x8]
    166c:      	cbnz	w8, 0x2658 <kprobe_unwind_php+0x2658>
    1670:      	mov	w25, #0x25              // =37
    1674:      	str	w25, [sp, #0x70]
    1678:      	mov	w8, #0x1                // =1
    167c:      	add	x9, sp, #0x70
    1680:      	add	x1, sp, #0x70
    1684:      	mov	x0, x23
    1688:      	blr	x8
    168c:      	cbz	x0, 0x1a98 <kprobe_unwind_php+0x1a98>
    1690:      	ldr	x8, [x0]
    1694:      	add	x8, x8, #0x1
    1698:      	str	x8, [x0]
    169c:      	cmp	w25, #0x23
    16a0:      	b.eq	0x1ab0 <kprobe_unwind_php+0x1ab0>
    16a4:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    16a8:      	ldrb	w8, [x24, #0x13]
    16ac:      	mov	w9, #0x4                // =4
    16b0:      	mov	w10, #0x70              // =112
    16b4:      	add	x11, sp, #0x5c
    16b8:      	add	x0, sp, #0x5c
    16bc:      	mov	w1, #0x4                // =4
    16c0:      	add	x8, x25, x8
    16c4:      	ldrb	w8, [x24, #0x13]
    16c8:      	add	x2, x25, x8
    16cc:      	blr	x10
    16d0:      	cbz	x0, 0x1908 <kprobe_unwind_php+0x1908>
    16d4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    16d8:      	ldr	x8, [x8]
    16dc:      	ldr	w8, [x8]
    16e0:      	cbz	w8, 0xa20 <kprobe_unwind_php+0xa20>
    16e4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    16e8:      	add	x8, x8, #0x0
    16ec:      	add	x0, sp, #0x18
    16f0:      	ldp	x9, x10, [x8, #0x20]
    16f4:      	mov	w1, #0x35               // =53
    16f8:      	mov	x2, x25
    16fc:      	stp	x9, x10, [sp, #0x38]
    1700:      	ldur	x9, [x8, #0x2d]
    1704:      	stur	x9, [sp, #0x45]
    1708:      	ldp	x9, x10, [x8]
    170c:      	stp	x9, x10, [sp, #0x18]
    1710:      	ldp	x8, x9, [x8, #0x10]
    1714:      	add	x10, sp, #0x18
    1718:      	stp	x8, x9, [sp, #0x28]
    171c:      	mov	w8, #0x35               // =53
    1720:      	mov	w9, #0x6                // =6
    1724:      	b	0x1398 <kprobe_unwind_php+0x1398>
    1728:      	ldr	w8, [x21, #0x2c0]
    172c:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    1730:      	ldr	x29, [x29]
    1734:      	cmp	w8, #0x7e
    1738:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    173c:      	add	w9, w8, #0x1
    1740:      	mov	x10, #-0x2              // =-2
    1744:      	str	w9, [x21, #0x2c0]
    1748:      	mov	w9, #0x18               // =24
    174c:      	umaddl	x8, w8, w9, x21
    1750:      	add	x9, x8, #0x2d0
    1754:      	str	x10, [x8, #0x2d8]
    1758:      	mov	w10, #0x2               // =2
    175c:      	str	xzr, [x8, #0x2d0]
    1760:      	strb	w10, [x8, #0x2e0]
    1764:      	mov	w25, #0x23              // =35
    1768:      	str	wzr, [x8, #0x2e4]
    176c:      	stur	wzr, [x9, #0x11]
    1770:      	b	0x10e4 <kprobe_unwind_php+0x10e4>
    1774:      	mov	w8, #0x2978             // =10616
    1778:      	add	x0, sp, #0x18
    177c:      	mov	w1, #0x33               // =51
    1780:      	movk	w8, #0xa, lsl #16
    1784:      	stur	w8, [sp, #0x47]
    1788:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    178c:      	add	x8, x8, #0x0
    1790:      	ldp	x9, x10, [x8, #0x10]
    1794:      	stp	x9, x10, [sp, #0x28]
    1798:      	ldp	x9, x10, [x8, #0x20]
    179c:      	stp	x9, x10, [sp, #0x38]
    17a0:      	ldp	x9, x8, [x8]
    17a4:      	add	x10, sp, #0x18
    17a8:      	stp	x9, x8, [sp, #0x18]
    17ac:      	mov	w8, #0x33               // =51
    17b0:      	mov	w9, #0x6                // =6
    17b4:      	ldrb	w8, [x24, #0x10]
    17b8:      	add	x2, x25, x8
    17bc:      	blr	x9
    17c0:      	b	0x680 <kprobe_unwind_php+0x680>
    17c4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    17c8:      	add	x8, x8, #0x0
    17cc:      	mov	w29, w10
    17d0:      	ldp	x9, x10, [x8]
    17d4:      	ldur	x8, [x8, #0xe]
    17d8:      	add	x0, sp, #0x18
    17dc:      	mov	w1, #0x16               // =22
    17e0:      	stp	x9, x10, [sp, #0x18]
    17e4:      	stur	x8, [sp, #0x26]
    17e8:      	mov	w8, #0x16               // =22
    17ec:      	mov	w9, #0x6                // =6
    17f0:      	add	x10, sp, #0x18
    17f4:      	ldr	x2, [sp, #0x70]
    17f8:      	ldr	w3, [sp, #0x88]
    17fc:      	blr	x9
    1800:      	mov	w10, w29
    1804:      	ldr	w8, [x21, #0x2c0]
    1808:      	cmp	w8, #0x7e
    180c:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    1810:      	b	0xe38 <kprobe_unwind_php+0xe38>
    1814:      	ldrb	w8, [sp, #0x8c]
    1818:      	str	wzr, [sp, #0x88]
    181c:      	cmp	w8, #0x4
    1820:      	b.eq	0x1830 <kprobe_unwind_php+0x1830>
    1824:      	mov	w29, wzr
    1828:      	cmp	w8, #0x2
    182c:      	b.ne	0x1e60 <kprobe_unwind_php+0x1e60>
    1830:      	ldrb	w8, [x24, #0x11]
    1834:      	mov	w9, #0x8                // =8
    1838:      	mov	w10, #0x70              // =112
    183c:      	add	x11, sp, #0x68
    1840:      	add	x0, sp, #0x68
    1844:      	mov	w1, #0x8                // =8
    1848:      	add	x8, x25, x8
    184c:      	ldrb	w8, [x24, #0x11]
    1850:      	add	x2, x25, x8
    1854:      	blr	x10
    1858:      	cbz	x0, 0x19fc <kprobe_unwind_php+0x19fc>
    185c:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1860:      	ldr	x8, [x8]
    1864:      	ldr	w8, [x8]
    1868:      	cbz	w8, 0x10e0 <kprobe_unwind_php+0x10e0>
    186c:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1870:      	add	x8, x8, #0x0
    1874:      	add	x0, sp, #0x18
    1878:      	ldp	x9, x10, [x8, #0x10]
    187c:      	mov	w1, #0x2d               // =45
    1880:      	stp	x9, x10, [sp, #0x28]
    1884:      	ldr	x9, [x8, #0x20]
    1888:      	add	x10, sp, #0x18
    188c:      	str	x9, [sp, #0x38]
    1890:      	ldur	x9, [x8, #0x25]
    1894:      	stur	x9, [sp, #0x3d]
    1898:      	ldp	x9, x8, [x8]
    189c:      	stp	x9, x8, [sp, #0x18]
    18a0:      	mov	w8, #0x2d               // =45
    18a4:      	mov	w9, #0x6                // =6
    18a8:      	ldrb	w8, [x24, #0x11]
    18ac:      	add	x2, x25, x8
    18b0:      	blr	x9
    18b4:      	b	0x10e0 <kprobe_unwind_php+0x10e0>
    18b8:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    18bc:      	add	x8, x8, #0x0
    18c0:      	add	x0, sp, #0x18
    18c4:      	ldp	x9, x10, [x8, #0x10]
    18c8:      	mov	w1, #0x2e               // =46
    18cc:      	stp	x9, x10, [sp, #0x28]
    18d0:      	ldr	x9, [x8, #0x20]
    18d4:      	add	x10, sp, #0x18
    18d8:      	str	x9, [sp, #0x38]
    18dc:      	ldur	x9, [x8, #0x26]
    18e0:      	stur	x9, [sp, #0x3e]
    18e4:      	ldp	x9, x8, [x8]
    18e8:      	stp	x9, x8, [sp, #0x18]
    18ec:      	mov	w8, #0x2e               // =46
    18f0:      	mov	w9, #0x6                // =6
    18f4:      	ldr	w2, [sp, #0x70]
    18f8:      	blr	x9
    18fc:      	cmp	w25, #0x23
    1900:      	b.eq	0x9a0 <kprobe_unwind_php+0x9a0>
    1904:      	b	0x414 <kprobe_unwind_php+0x414>
    1908:      	ldr	w29, [sp, #0x88]
    190c:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1910:      	ldr	w25, [sp, #0x5c]
    1914:      	ldr	x8, [x8]
    1918:      	ldr	w8, [x8]
    191c:      	cbnz	w8, 0x21e8 <kprobe_unwind_php+0x21e8>
    1920:      	ldr	w8, [x21, #0x2c0]
    1924:      	cmp	w8, #0x7e
    1928:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    192c:      	add	w9, w8, #0x1
    1930:      	mov	w10, w29
    1934:      	str	w9, [x21, #0x2c0]
    1938:      	mov	w9, #0x18               // =24
    193c:      	orr	x10, x10, x25, lsl #32
    1940:      	umaddl	x8, w8, w9, x21
    1944:      	ldr	x9, [sp, #0x70]
    1948:      	str	x10, [x8, #0x2d8]
    194c:      	str	x9, [x8, #0x2d0]
    1950:      	ldr	w9, [sp, #0xc]
    1954:      	strb	w9, [x8, #0x2e0]
    1958:      	add	x9, x8, #0x2d0
    195c:      	b	0x1210 <kprobe_unwind_php+0x1210>
    1960:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1964:      	add	x8, x8, #0x0
    1968:      	strb	wzr, [sp, #0x50]
    196c:      	add	x0, sp, #0x18
    1970:      	ldp	x9, x10, [x8, #0x20]
    1974:      	mov	w1, #0x39               // =57
    1978:      	stp	x9, x10, [sp, #0x38]
    197c:      	ldr	x9, [x8, #0x30]
    1980:      	str	x9, [sp, #0x48]
    1984:      	ldp	x9, x10, [x8]
    1988:      	stp	x9, x10, [sp, #0x18]
    198c:      	ldp	x8, x9, [x8, #0x10]
    1990:      	add	x10, sp, #0x18
    1994:      	stp	x8, x9, [sp, #0x28]
    1998:      	mov	w8, #0x39               // =57
    199c:      	mov	w9, #0x6                // =6
    19a0:      	ldr	x8, [sp, #0x68]
    19a4:      	ldrb	w10, [x24, #0x15]
    19a8:      	add	x2, x8, x10
    19ac:      	blr	x9
    19b0:      	mov	w25, #0x27              // =39
    19b4:      	b	0x354 <kprobe_unwind_php+0x354>
    19b8:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    19bc:      	add	x8, x8, #0x0
    19c0:      	strb	wzr, [sp, #0x48]
    19c4:      	add	x0, sp, #0x18
    19c8:      	ldp	x9, x10, [x8, #0x10]
    19cc:      	mov	w1, #0x31               // =49
    19d0:      	stp	x9, x10, [sp, #0x28]
    19d4:      	ldp	x9, x10, [x8, #0x20]
    19d8:      	stp	x9, x10, [sp, #0x38]
    19dc:      	ldp	x9, x8, [x8]
    19e0:      	add	x10, sp, #0x18
    19e4:      	stp	x9, x8, [sp, #0x18]
    19e8:      	mov	w8, #0x31               // =49
    19ec:      	mov	w9, #0x6                // =6
    19f0:      	ldr	x2, [sp, #0x70]
    19f4:      	blr	x9
    19f8:      	b	0x988 <kprobe_unwind_php+0x988>
    19fc:      	ldr	x8, [sp, #0x68]
    1a00:      	ldrb	w9, [x24, #0x15]
    1a04:      	mov	w10, #0x70              // =112
    1a08:      	add	x11, sp, #0x88
    1a0c:      	add	x0, sp, #0x88
    1a10:      	mov	w1, #0x4                // =4
    1a14:      	add	x8, x8, x9
    1a18:      	mov	w9, #0x4                // =4
    1a1c:      	ldr	x8, [sp, #0x68]
    1a20:      	ldrb	w9, [x24, #0x15]
    1a24:      	add	x2, x8, x9
    1a28:      	blr	x10
    1a2c:      	cbz	x0, 0x1bb8 <kprobe_unwind_php+0x1bb8>
    1a30:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1a34:      	ldr	x8, [x8]
    1a38:      	ldr	w8, [x8]
    1a3c:      	cbnz	w8, 0x283c <kprobe_unwind_php+0x283c>
    1a40:      	mov	w25, #0x27              // =39
    1a44:      	b	0x10e4 <kprobe_unwind_php+0x10e4>
    1a48:      	ldr	x8, [sp, #0x70]
    1a4c:      	cbz	x8, 0x1c38 <kprobe_unwind_php+0x1c38>
    1a50:      	ldrb	w9, [x24, #0x14]
    1a54:      	mov	w10, #0x70              // =112
    1a58:      	add	x11, sp, #0x8c
    1a5c:      	add	x0, sp, #0x8c
    1a60:      	mov	w1, #0x1                // =1
    1a64:      	add	x8, x8, x9
    1a68:      	mov	w9, #0x1                // =1
    1a6c:      	ldr	x8, [sp, #0x70]
    1a70:      	ldrb	w9, [x24, #0x14]
    1a74:      	add	x2, x8, x9
    1a78:      	blr	x10
    1a7c:      	cbz	x0, 0x1d68 <kprobe_unwind_php+0x1d68>
    1a80:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1a84:      	ldr	x8, [x8]
    1a88:      	ldr	w8, [x8]
    1a8c:      	cbnz	w8, 0x2894 <kprobe_unwind_php+0x2894>
    1a90:      	mov	w25, #0x26              // =38
    1a94:      	b	0x1674 <kprobe_unwind_php+0x1674>
    1a98:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1a9c:      	ldr	x8, [x8]
    1aa0:      	ldr	w8, [x8]
    1aa4:      	cbnz	w8, 0x2794 <kprobe_unwind_php+0x2794>
    1aa8:      	cmp	w25, #0x23
    1aac:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    1ab0:      	ldr	x8, [sp, #0x60]
    1ab4:      	ldrb	w9, [x24, #0x12]
    1ab8:      	mov	w10, #0x70              // =112
    1abc:      	add	x11, sp, #0x60
    1ac0:      	add	x0, sp, #0x60
    1ac4:      	mov	w1, #0x8                // =8
    1ac8:      	add	x8, x8, x9
    1acc:      	mov	w9, #0x8                // =8
    1ad0:      	ldr	x8, [sp, #0x60]
    1ad4:      	ldrb	w9, [x24, #0x12]
    1ad8:      	add	x2, x8, x9
    1adc:      	blr	x10
    1ae0:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    1ae4:      	ldr	x29, [x29]
    1ae8:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    1aec:      	ldr	x25, [sp, #0x60]
    1af0:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    1af4:      	ldrb	w8, [sp, #0x5e]
    1af8:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    1afc:      	ldrb	w8, [x24, #0x10]
    1b00:      	mov	w9, #0x8                // =8
    1b04:      	mov	w10, #0x70              // =112
    1b08:      	add	x11, sp, #0x70
    1b0c:      	add	x0, sp, #0x70
    1b10:      	mov	w1, #0x8                // =8
    1b14:      	add	x8, x25, x8
    1b18:      	ldrb	w8, [x24, #0x10]
    1b1c:      	add	x2, x25, x8
    1b20:      	blr	x10
    1b24:      	cbz	x0, 0x1fa4 <kprobe_unwind_php+0x1fa4>
    1b28:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1b2c:      	ldr	x8, [x8]
    1b30:      	ldr	w8, [x8]
    1b34:      	cbnz	w8, 0x2b18 <kprobe_unwind_php+0x2b18>
    1b38:      	mov	w25, #0x25              // =37
    1b3c:      	str	w25, [sp, #0x70]
    1b40:      	mov	w8, #0x1                // =1
    1b44:      	add	x9, sp, #0x70
    1b48:      	add	x1, sp, #0x70
    1b4c:      	mov	x0, x23
    1b50:      	blr	x8
    1b54:      	cbz	x0, 0x1ff4 <kprobe_unwind_php+0x1ff4>
    1b58:      	ldr	x8, [x0]
    1b5c:      	add	x8, x8, #0x1
    1b60:      	str	x8, [x0]
    1b64:      	cmp	w25, #0x23
    1b68:      	b.eq	0x200c <kprobe_unwind_php+0x200c>
    1b6c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    1b70:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1b74:      	add	x8, x8, #0x0
    1b78:      	add	x0, sp, #0x18
    1b7c:      	ldp	x9, x10, [x8, #0x20]
    1b80:      	mov	w1, #0x35               // =53
    1b84:      	mov	x2, x25
    1b88:      	stp	x9, x10, [sp, #0x38]
    1b8c:      	ldur	x9, [x8, #0x2d]
    1b90:      	stur	x9, [sp, #0x45]
    1b94:      	ldp	x9, x10, [x8]
    1b98:      	stp	x9, x10, [sp, #0x18]
    1b9c:      	ldp	x8, x9, [x8, #0x10]
    1ba0:      	add	x10, sp, #0x18
    1ba4:      	stp	x8, x9, [sp, #0x28]
    1ba8:      	mov	w8, #0x35               // =53
    1bac:      	mov	w9, #0x6                // =6
    1bb0:      	blr	x9
    1bb4:      	b	0xa8c <kprobe_unwind_php+0xa8c>
    1bb8:      	ldrb	w8, [x24, #0x13]
    1bbc:      	mov	w9, #0x4                // =4
    1bc0:      	mov	w10, #0x70              // =112
    1bc4:      	add	x11, sp, #0x5c
    1bc8:      	add	x0, sp, #0x5c
    1bcc:      	mov	w1, #0x4                // =4
    1bd0:      	add	x8, x25, x8
    1bd4:      	ldrb	w8, [x24, #0x13]
    1bd8:      	add	x2, x25, x8
    1bdc:      	blr	x10
    1be0:      	cbz	x0, 0x1e5c <kprobe_unwind_php+0x1e5c>
    1be4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1be8:      	ldr	x8, [x8]
    1bec:      	ldr	w8, [x8]
    1bf0:      	cbz	w8, 0x10e0 <kprobe_unwind_php+0x10e0>
    1bf4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1bf8:      	add	x8, x8, #0x0
    1bfc:      	add	x0, sp, #0x18
    1c00:      	ldp	x9, x10, [x8, #0x20]
    1c04:      	mov	w1, #0x35               // =53
    1c08:      	mov	x2, x25
    1c0c:      	stp	x9, x10, [sp, #0x38]
    1c10:      	ldur	x9, [x8, #0x2d]
    1c14:      	stur	x9, [sp, #0x45]
    1c18:      	ldp	x9, x10, [x8]
    1c1c:      	stp	x9, x10, [sp, #0x18]
    1c20:      	ldp	x8, x9, [x8, #0x10]
    1c24:      	add	x10, sp, #0x18
    1c28:      	stp	x8, x9, [sp, #0x28]
    1c2c:      	mov	w8, #0x35               // =53
    1c30:      	mov	w9, #0x6                // =6
    1c34:      	b	0x18b0 <kprobe_unwind_php+0x18b0>
    1c38:      	ldr	w8, [x21, #0x2c0]
    1c3c:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    1c40:      	ldr	x29, [x29]
    1c44:      	cmp	w8, #0x7e
    1c48:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    1c4c:      	add	w9, w8, #0x1
    1c50:      	mov	x10, #-0x2              // =-2
    1c54:      	str	w9, [x21, #0x2c0]
    1c58:      	mov	w9, #0x18               // =24
    1c5c:      	umaddl	x8, w8, w9, x21
    1c60:      	add	x9, x8, #0x2d0
    1c64:      	str	x10, [x8, #0x2d8]
    1c68:      	mov	w10, #0x2               // =2
    1c6c:      	str	xzr, [x8, #0x2d0]
    1c70:      	strb	w10, [x8, #0x2e0]
    1c74:      	mov	w25, #0x23              // =35
    1c78:      	str	wzr, [x8, #0x2e4]
    1c7c:      	stur	wzr, [x9, #0x11]
    1c80:      	b	0x1674 <kprobe_unwind_php+0x1674>
    1c84:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1c88:      	add	x8, x8, #0x0
    1c8c:      	add	x0, sp, #0x18
    1c90:      	ldp	x9, x10, [x8, #0x10]
    1c94:      	mov	w1, #0x2d               // =45
    1c98:      	stp	x9, x10, [sp, #0x28]
    1c9c:      	ldr	x9, [x8, #0x20]
    1ca0:      	add	x10, sp, #0x18
    1ca4:      	str	x9, [sp, #0x38]
    1ca8:      	ldur	x9, [x8, #0x25]
    1cac:      	stur	x9, [sp, #0x3d]
    1cb0:      	ldp	x9, x8, [x8]
    1cb4:      	stp	x9, x8, [sp, #0x18]
    1cb8:      	mov	w8, #0x2d               // =45
    1cbc:      	mov	w9, #0x6                // =6
    1cc0:      	ldrb	w8, [x24, #0x11]
    1cc4:      	add	x2, x25, x8
    1cc8:      	blr	x9
    1ccc:      	b	0xd24 <kprobe_unwind_php+0xd24>
    1cd0:      	mov	w8, #0x2978             // =10616
    1cd4:      	add	x0, sp, #0x18
    1cd8:      	mov	w1, #0x33               // =51
    1cdc:      	movk	w8, #0xa, lsl #16
    1ce0:      	stur	w8, [sp, #0x47]
    1ce4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1ce8:      	add	x8, x8, #0x0
    1cec:      	ldp	x9, x10, [x8, #0x10]
    1cf0:      	stp	x9, x10, [sp, #0x28]
    1cf4:      	ldp	x9, x10, [x8, #0x20]
    1cf8:      	stp	x9, x10, [sp, #0x38]
    1cfc:      	ldp	x9, x8, [x8]
    1d00:      	add	x10, sp, #0x18
    1d04:      	stp	x9, x8, [sp, #0x18]
    1d08:      	mov	w8, #0x33               // =51
    1d0c:      	mov	w9, #0x6                // =6
    1d10:      	ldrb	w8, [x24, #0x10]
    1d14:      	add	x2, x25, x8
    1d18:      	blr	x9
    1d1c:      	b	0xa20 <kprobe_unwind_php+0xa20>
    1d20:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1d24:      	add	x8, x8, #0x0
    1d28:      	add	x0, sp, #0x18
    1d2c:      	ldp	x9, x10, [x8]
    1d30:      	ldur	x8, [x8, #0xe]
    1d34:      	mov	w1, #0x16               // =22
    1d38:      	stp	x9, x10, [sp, #0x18]
    1d3c:      	stur	x8, [sp, #0x26]
    1d40:      	mov	w8, #0x16               // =22
    1d44:      	mov	w9, #0x6                // =6
    1d48:      	add	x10, sp, #0x18
    1d4c:      	ldr	x2, [sp, #0x70]
    1d50:      	ldr	w3, [sp, #0x88]
    1d54:      	blr	x9
    1d58:      	ldr	w8, [x21, #0x2c0]
    1d5c:      	cmp	w8, #0x7e
    1d60:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    1d64:      	b	0x1414 <kprobe_unwind_php+0x1414>
    1d68:      	ldrb	w8, [sp, #0x8c]
    1d6c:      	str	wzr, [sp, #0x88]
    1d70:      	cmp	w8, #0x4
    1d74:      	b.eq	0x1d84 <kprobe_unwind_php+0x1d84>
    1d78:      	mov	w29, wzr
    1d7c:      	cmp	w8, #0x2
    1d80:      	b.ne	0x2328 <kprobe_unwind_php+0x2328>
    1d84:      	ldrb	w8, [x24, #0x11]
    1d88:      	mov	w9, #0x8                // =8
    1d8c:      	mov	w10, #0x70              // =112
    1d90:      	add	x11, sp, #0x68
    1d94:      	add	x0, sp, #0x68
    1d98:      	mov	w1, #0x8                // =8
    1d9c:      	add	x8, x25, x8
    1da0:      	ldrb	w8, [x24, #0x11]
    1da4:      	add	x2, x25, x8
    1da8:      	blr	x10
    1dac:      	cbz	x0, 0x1f58 <kprobe_unwind_php+0x1f58>
    1db0:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1db4:      	ldr	x8, [x8]
    1db8:      	ldr	w8, [x8]
    1dbc:      	cbz	w8, 0x1670 <kprobe_unwind_php+0x1670>
    1dc0:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1dc4:      	add	x8, x8, #0x0
    1dc8:      	add	x0, sp, #0x18
    1dcc:      	ldp	x9, x10, [x8, #0x10]
    1dd0:      	mov	w1, #0x2d               // =45
    1dd4:      	stp	x9, x10, [sp, #0x28]
    1dd8:      	ldr	x9, [x8, #0x20]
    1ddc:      	add	x10, sp, #0x18
    1de0:      	str	x9, [sp, #0x38]
    1de4:      	ldur	x9, [x8, #0x25]
    1de8:      	stur	x9, [sp, #0x3d]
    1dec:      	ldp	x9, x8, [x8]
    1df0:      	stp	x9, x8, [sp, #0x18]
    1df4:      	mov	w8, #0x2d               // =45
    1df8:      	mov	w9, #0x6                // =6
    1dfc:      	ldrb	w8, [x24, #0x11]
    1e00:      	add	x2, x25, x8
    1e04:      	blr	x9
    1e08:      	b	0x1670 <kprobe_unwind_php+0x1670>
    1e0c:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1e10:      	add	x8, x8, #0x0
    1e14:      	add	x0, sp, #0x18
    1e18:      	ldp	x9, x10, [x8, #0x10]
    1e1c:      	mov	w1, #0x2e               // =46
    1e20:      	stp	x9, x10, [sp, #0x28]
    1e24:      	ldr	x9, [x8, #0x20]
    1e28:      	add	x10, sp, #0x18
    1e2c:      	str	x9, [sp, #0x38]
    1e30:      	ldur	x9, [x8, #0x26]
    1e34:      	stur	x9, [sp, #0x3e]
    1e38:      	ldp	x9, x8, [x8]
    1e3c:      	stp	x9, x8, [sp, #0x18]
    1e40:      	mov	w8, #0x2e               // =46
    1e44:      	mov	w9, #0x6                // =6
    1e48:      	ldr	w2, [sp, #0x70]
    1e4c:      	blr	x9
    1e50:      	cmp	w25, #0x23
    1e54:      	b.eq	0x1058 <kprobe_unwind_php+0x1058>
    1e58:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    1e5c:      	ldr	w29, [sp, #0x88]
    1e60:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1e64:      	ldr	w25, [sp, #0x5c]
    1e68:      	ldr	x8, [x8]
    1e6c:      	ldr	w8, [x8]
    1e70:      	cbnz	w8, 0x26a8 <kprobe_unwind_php+0x26a8>
    1e74:      	ldr	w8, [x21, #0x2c0]
    1e78:      	cmp	w8, #0x7e
    1e7c:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    1e80:      	add	w9, w8, #0x1
    1e84:      	mov	w10, w29
    1e88:      	str	w9, [x21, #0x2c0]
    1e8c:      	mov	w9, #0x18               // =24
    1e90:      	orr	x10, x10, x25, lsl #32
    1e94:      	umaddl	x8, w8, w9, x21
    1e98:      	ldr	x9, [sp, #0x70]
    1e9c:      	str	x10, [x8, #0x2d8]
    1ea0:      	str	x9, [x8, #0x2d0]
    1ea4:      	ldr	w9, [sp, #0xc]
    1ea8:      	strb	w9, [x8, #0x2e0]
    1eac:      	add	x9, x8, #0x2d0
    1eb0:      	b	0x1764 <kprobe_unwind_php+0x1764>
    1eb4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1eb8:      	add	x8, x8, #0x0
    1ebc:      	strb	wzr, [sp, #0x50]
    1ec0:      	add	x0, sp, #0x18
    1ec4:      	ldp	x9, x10, [x8, #0x20]
    1ec8:      	mov	w1, #0x39               // =57
    1ecc:      	stp	x9, x10, [sp, #0x38]
    1ed0:      	ldr	x9, [x8, #0x30]
    1ed4:      	str	x9, [sp, #0x48]
    1ed8:      	ldp	x9, x10, [x8]
    1edc:      	stp	x9, x10, [sp, #0x18]
    1ee0:      	ldp	x8, x9, [x8, #0x10]
    1ee4:      	add	x10, sp, #0x18
    1ee8:      	stp	x8, x9, [sp, #0x28]
    1eec:      	mov	w8, #0x39               // =57
    1ef0:      	mov	w9, #0x6                // =6
    1ef4:      	ldr	x8, [sp, #0x68]
    1ef8:      	ldrb	w10, [x24, #0x15]
    1efc:      	add	x2, x8, x10
    1f00:      	blr	x9
    1f04:      	adrp	x29, 0x1000 <kprobe_unwind_php+0x1000>
    1f08:      	mov	w25, #0x27              // =39
    1f0c:      	ldr	x29, [x29]
    1f10:      	b	0x684 <kprobe_unwind_php+0x684>
    1f14:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1f18:      	add	x8, x8, #0x0
    1f1c:      	strb	wzr, [sp, #0x48]
    1f20:      	add	x0, sp, #0x18
    1f24:      	ldp	x9, x10, [x8, #0x10]
    1f28:      	mov	w1, #0x31               // =49
    1f2c:      	stp	x9, x10, [sp, #0x28]
    1f30:      	ldp	x9, x10, [x8, #0x20]
    1f34:      	stp	x9, x10, [sp, #0x38]
    1f38:      	ldp	x9, x8, [x8]
    1f3c:      	add	x10, sp, #0x18
    1f40:      	stp	x9, x8, [sp, #0x18]
    1f44:      	mov	w8, #0x31               // =49
    1f48:      	mov	w9, #0x6                // =6
    1f4c:      	ldr	x2, [sp, #0x70]
    1f50:      	blr	x9
    1f54:      	b	0xff0 <kprobe_unwind_php+0xff0>
    1f58:      	ldr	x8, [sp, #0x68]
    1f5c:      	ldrb	w9, [x24, #0x15]
    1f60:      	mov	w10, #0x70              // =112
    1f64:      	add	x11, sp, #0x88
    1f68:      	add	x0, sp, #0x88
    1f6c:      	mov	w1, #0x4                // =4
    1f70:      	add	x8, x8, x9
    1f74:      	mov	w9, #0x4                // =4
    1f78:      	ldr	x8, [sp, #0x68]
    1f7c:      	ldrb	w9, [x24, #0x15]
    1f80:      	add	x2, x8, x9
    1f84:      	blr	x10
    1f88:      	cbz	x0, 0x20cc <kprobe_unwind_php+0x20cc>
    1f8c:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1f90:      	ldr	x8, [x8]
    1f94:      	ldr	w8, [x8]
    1f98:      	cbnz	w8, 0x2cf8 <kprobe_unwind_php+0x2cf8>
    1f9c:      	mov	w25, #0x27              // =39
    1fa0:      	b	0x1674 <kprobe_unwind_php+0x1674>
    1fa4:      	ldr	x8, [sp, #0x70]
    1fa8:      	cbz	x8, 0x214c <kprobe_unwind_php+0x214c>
    1fac:      	ldrb	w9, [x24, #0x14]
    1fb0:      	mov	w10, #0x70              // =112
    1fb4:      	add	x11, sp, #0x8c
    1fb8:      	add	x0, sp, #0x8c
    1fbc:      	mov	w1, #0x1                // =1
    1fc0:      	add	x8, x8, x9
    1fc4:      	mov	w9, #0x1                // =1
    1fc8:      	ldr	x8, [sp, #0x70]
    1fcc:      	ldrb	w9, [x24, #0x14]
    1fd0:      	add	x2, x8, x9
    1fd4:      	blr	x10
    1fd8:      	cbz	x0, 0x2230 <kprobe_unwind_php+0x2230>
    1fdc:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1fe0:      	ldr	x8, [x8]
    1fe4:      	ldr	w8, [x8]
    1fe8:      	cbnz	w8, 0x2d50 <kprobe_unwind_php+0x2d50>
    1fec:      	mov	w25, #0x26              // =38
    1ff0:      	b	0x1b3c <kprobe_unwind_php+0x1b3c>
    1ff4:      	adrp	x8, 0x1000 <kprobe_unwind_php+0x1000>
    1ff8:      	ldr	x8, [x8]
    1ffc:      	ldr	w8, [x8]
    2000:      	cbnz	w8, 0x2c50 <kprobe_unwind_php+0x2c50>
    2004:      	cmp	w25, #0x23
    2008:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    200c:      	ldr	x8, [sp, #0x60]
    2010:      	ldrb	w9, [x24, #0x12]
    2014:      	mov	w10, #0x70              // =112
    2018:      	add	x11, sp, #0x60
    201c:      	add	x0, sp, #0x60
    2020:      	mov	w1, #0x8                // =8
    2024:      	add	x8, x8, x9
    2028:      	mov	w9, #0x8                // =8
    202c:      	ldr	x8, [sp, #0x60]
    2030:      	ldrb	w9, [x24, #0x12]
    2034:      	add	x2, x8, x9
    2038:      	blr	x10
    203c:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2040:      	ldr	x29, [x29]
    2044:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    2048:      	ldr	x25, [sp, #0x60]
    204c:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    2050:      	ldrb	w8, [sp, #0x5e]
    2054:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    2058:      	ldrb	w8, [x24, #0x10]
    205c:      	mov	w9, #0x8                // =8
    2060:      	mov	w10, #0x70              // =112
    2064:      	add	x11, sp, #0x70
    2068:      	add	x0, sp, #0x70
    206c:      	mov	w1, #0x8                // =8
    2070:      	add	x8, x25, x8
    2074:      	ldrb	w8, [x24, #0x10]
    2078:      	add	x2, x25, x8
    207c:      	blr	x10
    2080:      	cbz	x0, 0x2464 <kprobe_unwind_php+0x2464>
    2084:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2088:      	ldr	x8, [x8]
    208c:      	ldr	w8, [x8]
    2090:      	cbnz	w8, 0x2fd8 <kprobe_unwind_php+0x2fd8>
    2094:      	mov	w25, #0x25              // =37
    2098:      	str	w25, [sp, #0x70]
    209c:      	mov	w8, #0x1                // =1
    20a0:      	add	x9, sp, #0x70
    20a4:      	add	x1, sp, #0x70
    20a8:      	mov	x0, x23
    20ac:      	blr	x8
    20b0:      	cbz	x0, 0x24b4 <kprobe_unwind_php+0x24b4>
    20b4:      	ldr	x8, [x0]
    20b8:      	add	x8, x8, #0x1
    20bc:      	str	x8, [x0]
    20c0:      	cmp	w25, #0x23
    20c4:      	b.eq	0x24cc <kprobe_unwind_php+0x24cc>
    20c8:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    20cc:      	ldrb	w8, [x24, #0x13]
    20d0:      	mov	w9, #0x4                // =4
    20d4:      	mov	w10, #0x70              // =112
    20d8:      	add	x11, sp, #0x5c
    20dc:      	add	x0, sp, #0x5c
    20e0:      	mov	w1, #0x4                // =4
    20e4:      	add	x8, x25, x8
    20e8:      	ldrb	w8, [x24, #0x13]
    20ec:      	add	x2, x25, x8
    20f0:      	blr	x10
    20f4:      	cbz	x0, 0x2324 <kprobe_unwind_php+0x2324>
    20f8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    20fc:      	ldr	x8, [x8]
    2100:      	ldr	w8, [x8]
    2104:      	cbz	w8, 0x1670 <kprobe_unwind_php+0x1670>
    2108:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    210c:      	add	x8, x8, #0x0
    2110:      	add	x0, sp, #0x18
    2114:      	ldp	x9, x10, [x8, #0x20]
    2118:      	mov	w1, #0x35               // =53
    211c:      	mov	x2, x25
    2120:      	stp	x9, x10, [sp, #0x38]
    2124:      	ldur	x9, [x8, #0x2d]
    2128:      	stur	x9, [sp, #0x45]
    212c:      	ldp	x9, x10, [x8]
    2130:      	stp	x9, x10, [sp, #0x18]
    2134:      	ldp	x8, x9, [x8, #0x10]
    2138:      	add	x10, sp, #0x18
    213c:      	stp	x8, x9, [sp, #0x28]
    2140:      	mov	w8, #0x35               // =53
    2144:      	mov	w9, #0x6                // =6
    2148:      	b	0x1e04 <kprobe_unwind_php+0x1e04>
    214c:      	ldr	w8, [x21, #0x2c0]
    2150:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2154:      	ldr	x29, [x29]
    2158:      	cmp	w8, #0x7e
    215c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    2160:      	add	w9, w8, #0x1
    2164:      	mov	x10, #-0x2              // =-2
    2168:      	str	w9, [x21, #0x2c0]
    216c:      	mov	w9, #0x18               // =24
    2170:      	umaddl	x8, w8, w9, x21
    2174:      	add	x9, x8, #0x2d0
    2178:      	str	x10, [x8, #0x2d8]
    217c:      	mov	w10, #0x2               // =2
    2180:      	str	xzr, [x8, #0x2d0]
    2184:      	strb	w10, [x8, #0x2e0]
    2188:      	mov	w25, #0x23              // =35
    218c:      	str	wzr, [x8, #0x2e4]
    2190:      	stur	wzr, [x9, #0x11]
    2194:      	b	0x1b3c <kprobe_unwind_php+0x1b3c>
    2198:      	mov	w8, #0x2978             // =10616
    219c:      	add	x0, sp, #0x18
    21a0:      	mov	w1, #0x33               // =51
    21a4:      	movk	w8, #0xa, lsl #16
    21a8:      	stur	w8, [sp, #0x47]
    21ac:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    21b0:      	add	x8, x8, #0x0
    21b4:      	ldp	x9, x10, [x8, #0x10]
    21b8:      	stp	x9, x10, [sp, #0x28]
    21bc:      	ldp	x9, x10, [x8, #0x20]
    21c0:      	stp	x9, x10, [sp, #0x38]
    21c4:      	ldp	x9, x8, [x8]
    21c8:      	add	x10, sp, #0x18
    21cc:      	stp	x9, x8, [sp, #0x18]
    21d0:      	mov	w8, #0x33               // =51
    21d4:      	mov	w9, #0x6                // =6
    21d8:      	ldrb	w8, [x24, #0x10]
    21dc:      	add	x2, x25, x8
    21e0:      	blr	x9
    21e4:      	b	0x10e0 <kprobe_unwind_php+0x10e0>
    21e8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    21ec:      	add	x8, x8, #0x0
    21f0:      	add	x0, sp, #0x18
    21f4:      	ldp	x9, x10, [x8]
    21f8:      	ldur	x8, [x8, #0xe]
    21fc:      	mov	w1, #0x16               // =22
    2200:      	stp	x9, x10, [sp, #0x18]
    2204:      	stur	x8, [sp, #0x26]
    2208:      	mov	w8, #0x16               // =22
    220c:      	mov	w9, #0x6                // =6
    2210:      	add	x10, sp, #0x18
    2214:      	ldr	x2, [sp, #0x70]
    2218:      	ldr	w3, [sp, #0x88]
    221c:      	blr	x9
    2220:      	ldr	w8, [x21, #0x2c0]
    2224:      	cmp	w8, #0x7e
    2228:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    222c:      	b	0x192c <kprobe_unwind_php+0x192c>
    2230:      	ldrb	w8, [sp, #0x8c]
    2234:      	str	wzr, [sp, #0x88]
    2238:      	cmp	w8, #0x4
    223c:      	b.eq	0x224c <kprobe_unwind_php+0x224c>
    2240:      	mov	w29, wzr
    2244:      	cmp	w8, #0x2
    2248:      	b.ne	0x27e8 <kprobe_unwind_php+0x27e8>
    224c:      	ldrb	w8, [x24, #0x11]
    2250:      	mov	w9, #0x8                // =8
    2254:      	mov	w10, #0x70              // =112
    2258:      	add	x11, sp, #0x68
    225c:      	add	x0, sp, #0x68
    2260:      	mov	w1, #0x8                // =8
    2264:      	add	x8, x25, x8
    2268:      	ldrb	w8, [x24, #0x11]
    226c:      	add	x2, x25, x8
    2270:      	blr	x10
    2274:      	cbz	x0, 0x2418 <kprobe_unwind_php+0x2418>
    2278:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    227c:      	ldr	x8, [x8]
    2280:      	ldr	w8, [x8]
    2284:      	cbz	w8, 0x1b38 <kprobe_unwind_php+0x1b38>
    2288:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    228c:      	add	x8, x8, #0x0
    2290:      	add	x0, sp, #0x18
    2294:      	ldp	x9, x10, [x8, #0x10]
    2298:      	mov	w1, #0x2d               // =45
    229c:      	stp	x9, x10, [sp, #0x28]
    22a0:      	ldr	x9, [x8, #0x20]
    22a4:      	add	x10, sp, #0x18
    22a8:      	str	x9, [sp, #0x38]
    22ac:      	ldur	x9, [x8, #0x25]
    22b0:      	stur	x9, [sp, #0x3d]
    22b4:      	ldp	x9, x8, [x8]
    22b8:      	stp	x9, x8, [sp, #0x18]
    22bc:      	mov	w8, #0x2d               // =45
    22c0:      	mov	w9, #0x6                // =6
    22c4:      	ldrb	w8, [x24, #0x11]
    22c8:      	add	x2, x25, x8
    22cc:      	blr	x9
    22d0:      	b	0x1b38 <kprobe_unwind_php+0x1b38>
    22d4:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    22d8:      	add	x8, x8, #0x0
    22dc:      	add	x0, sp, #0x18
    22e0:      	ldp	x9, x10, [x8, #0x10]
    22e4:      	mov	w1, #0x2e               // =46
    22e8:      	stp	x9, x10, [sp, #0x28]
    22ec:      	ldr	x9, [x8, #0x20]
    22f0:      	add	x10, sp, #0x18
    22f4:      	str	x9, [sp, #0x38]
    22f8:      	ldur	x9, [x8, #0x26]
    22fc:      	stur	x9, [sp, #0x3e]
    2300:      	ldp	x9, x8, [x8]
    2304:      	stp	x9, x8, [sp, #0x18]
    2308:      	mov	w8, #0x2e               // =46
    230c:      	mov	w9, #0x6                // =6
    2310:      	ldr	w2, [sp, #0x70]
    2314:      	blr	x9
    2318:      	cmp	w25, #0x23
    231c:      	b.eq	0x15e8 <kprobe_unwind_php+0x15e8>
    2320:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    2324:      	ldr	w29, [sp, #0x88]
    2328:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    232c:      	ldr	w25, [sp, #0x5c]
    2330:      	ldr	x8, [x8]
    2334:      	ldr	w8, [x8]
    2338:      	cbnz	w8, 0x2b68 <kprobe_unwind_php+0x2b68>
    233c:      	ldr	w8, [x21, #0x2c0]
    2340:      	cmp	w8, #0x7e
    2344:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    2348:      	add	w9, w8, #0x1
    234c:      	mov	w10, w29
    2350:      	str	w9, [x21, #0x2c0]
    2354:      	mov	w9, #0x18               // =24
    2358:      	orr	x10, x10, x25, lsl #32
    235c:      	umaddl	x8, w8, w9, x21
    2360:      	ldr	x9, [sp, #0x70]
    2364:      	str	x10, [x8, #0x2d8]
    2368:      	str	x9, [x8, #0x2d0]
    236c:      	ldr	w9, [sp, #0xc]
    2370:      	strb	w9, [x8, #0x2e0]
    2374:      	add	x9, x8, #0x2d0
    2378:      	b	0x1c74 <kprobe_unwind_php+0x1c74>
    237c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2380:      	add	x8, x8, #0x0
    2384:      	strb	wzr, [sp, #0x50]
    2388:      	add	x0, sp, #0x18
    238c:      	ldp	x9, x10, [x8, #0x20]
    2390:      	mov	w1, #0x39               // =57
    2394:      	stp	x9, x10, [sp, #0x38]
    2398:      	ldr	x9, [x8, #0x30]
    239c:      	str	x9, [sp, #0x48]
    23a0:      	ldp	x9, x10, [x8]
    23a4:      	stp	x9, x10, [sp, #0x18]
    23a8:      	ldp	x8, x9, [x8, #0x10]
    23ac:      	add	x10, sp, #0x18
    23b0:      	stp	x8, x9, [sp, #0x28]
    23b4:      	mov	w8, #0x39               // =57
    23b8:      	mov	w9, #0x6                // =6
    23bc:      	ldr	x8, [sp, #0x68]
    23c0:      	ldrb	w10, [x24, #0x15]
    23c4:      	add	x2, x8, x10
    23c8:      	blr	x9
    23cc:      	mov	w25, #0x27              // =39
    23d0:      	b	0xa24 <kprobe_unwind_php+0xa24>
    23d4:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    23d8:      	add	x8, x8, #0x0
    23dc:      	strb	wzr, [sp, #0x48]
    23e0:      	add	x0, sp, #0x18
    23e4:      	ldp	x9, x10, [x8, #0x10]
    23e8:      	mov	w1, #0x31               // =49
    23ec:      	stp	x9, x10, [sp, #0x28]
    23f0:      	ldp	x9, x10, [x8, #0x20]
    23f4:      	stp	x9, x10, [sp, #0x38]
    23f8:      	ldp	x9, x8, [x8]
    23fc:      	add	x10, sp, #0x18
    2400:      	stp	x9, x8, [sp, #0x18]
    2404:      	mov	w8, #0x31               // =49
    2408:      	mov	w9, #0x6                // =6
    240c:      	ldr	x2, [sp, #0x70]
    2410:      	blr	x9
    2414:      	b	0x15c8 <kprobe_unwind_php+0x15c8>
    2418:      	ldr	x8, [sp, #0x68]
    241c:      	ldrb	w9, [x24, #0x15]
    2420:      	mov	w10, #0x70              // =112
    2424:      	add	x11, sp, #0x88
    2428:      	add	x0, sp, #0x88
    242c:      	mov	w1, #0x4                // =4
    2430:      	add	x8, x8, x9
    2434:      	mov	w9, #0x4                // =4
    2438:      	ldr	x8, [sp, #0x68]
    243c:      	ldrb	w9, [x24, #0x15]
    2440:      	add	x2, x8, x9
    2444:      	blr	x10
    2448:      	cbz	x0, 0x258c <kprobe_unwind_php+0x258c>
    244c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2450:      	ldr	x8, [x8]
    2454:      	ldr	w8, [x8]
    2458:      	cbnz	w8, 0x31b8 <kprobe_unwind_php+0x31b8>
    245c:      	mov	w25, #0x27              // =39
    2460:      	b	0x1b3c <kprobe_unwind_php+0x1b3c>
    2464:      	ldr	x8, [sp, #0x70]
    2468:      	cbz	x8, 0x260c <kprobe_unwind_php+0x260c>
    246c:      	ldrb	w9, [x24, #0x14]
    2470:      	mov	w10, #0x70              // =112
    2474:      	add	x11, sp, #0x8c
    2478:      	add	x0, sp, #0x8c
    247c:      	mov	w1, #0x1                // =1
    2480:      	add	x8, x8, x9
    2484:      	mov	w9, #0x1                // =1
    2488:      	ldr	x8, [sp, #0x70]
    248c:      	ldrb	w9, [x24, #0x14]
    2490:      	add	x2, x8, x9
    2494:      	blr	x10
    2498:      	cbz	x0, 0x26f0 <kprobe_unwind_php+0x26f0>
    249c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    24a0:      	ldr	x8, [x8]
    24a4:      	ldr	w8, [x8]
    24a8:      	cbnz	w8, 0x3210 <kprobe_unwind_php+0x3210>
    24ac:      	mov	w25, #0x26              // =38
    24b0:      	b	0x2098 <kprobe_unwind_php+0x2098>
    24b4:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    24b8:      	ldr	x8, [x8]
    24bc:      	ldr	w8, [x8]
    24c0:      	cbnz	w8, 0x3110 <kprobe_unwind_php+0x3110>
    24c4:      	cmp	w25, #0x23
    24c8:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    24cc:      	ldr	x8, [sp, #0x60]
    24d0:      	ldrb	w9, [x24, #0x12]
    24d4:      	mov	w10, #0x70              // =112
    24d8:      	add	x11, sp, #0x60
    24dc:      	add	x0, sp, #0x60
    24e0:      	mov	w1, #0x8                // =8
    24e4:      	add	x8, x8, x9
    24e8:      	mov	w9, #0x8                // =8
    24ec:      	ldr	x8, [sp, #0x60]
    24f0:      	ldrb	w9, [x24, #0x12]
    24f4:      	add	x2, x8, x9
    24f8:      	blr	x10
    24fc:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2500:      	ldr	x29, [x29]
    2504:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    2508:      	ldr	x25, [sp, #0x60]
    250c:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    2510:      	ldrb	w8, [sp, #0x5e]
    2514:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    2518:      	ldrb	w8, [x24, #0x10]
    251c:      	mov	w9, #0x8                // =8
    2520:      	mov	w10, #0x70              // =112
    2524:      	add	x11, sp, #0x70
    2528:      	add	x0, sp, #0x70
    252c:      	mov	w1, #0x8                // =8
    2530:      	add	x8, x25, x8
    2534:      	ldrb	w8, [x24, #0x10]
    2538:      	add	x2, x25, x8
    253c:      	blr	x10
    2540:      	cbz	x0, 0x2924 <kprobe_unwind_php+0x2924>
    2544:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2548:      	ldr	x8, [x8]
    254c:      	ldr	w8, [x8]
    2550:      	cbnz	w8, 0x3498 <kprobe_unwind_php+0x3498>
    2554:      	mov	w25, #0x25              // =37
    2558:      	str	w25, [sp, #0x70]
    255c:      	mov	w8, #0x1                // =1
    2560:      	add	x9, sp, #0x70
    2564:      	add	x1, sp, #0x70
    2568:      	mov	x0, x23
    256c:      	blr	x8
    2570:      	cbz	x0, 0x2974 <kprobe_unwind_php+0x2974>
    2574:      	ldr	x8, [x0]
    2578:      	add	x8, x8, #0x1
    257c:      	str	x8, [x0]
    2580:      	cmp	w25, #0x23
    2584:      	b.eq	0x298c <kprobe_unwind_php+0x298c>
    2588:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    258c:      	ldrb	w8, [x24, #0x13]
    2590:      	mov	w9, #0x4                // =4
    2594:      	mov	w10, #0x70              // =112
    2598:      	add	x11, sp, #0x5c
    259c:      	add	x0, sp, #0x5c
    25a0:      	mov	w1, #0x4                // =4
    25a4:      	add	x8, x25, x8
    25a8:      	ldrb	w8, [x24, #0x13]
    25ac:      	add	x2, x25, x8
    25b0:      	blr	x10
    25b4:      	cbz	x0, 0x27e4 <kprobe_unwind_php+0x27e4>
    25b8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    25bc:      	ldr	x8, [x8]
    25c0:      	ldr	w8, [x8]
    25c4:      	cbz	w8, 0x1b38 <kprobe_unwind_php+0x1b38>
    25c8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    25cc:      	add	x8, x8, #0x0
    25d0:      	add	x0, sp, #0x18
    25d4:      	ldp	x9, x10, [x8, #0x20]
    25d8:      	mov	w1, #0x35               // =53
    25dc:      	mov	x2, x25
    25e0:      	stp	x9, x10, [sp, #0x38]
    25e4:      	ldur	x9, [x8, #0x2d]
    25e8:      	stur	x9, [sp, #0x45]
    25ec:      	ldp	x9, x10, [x8]
    25f0:      	stp	x9, x10, [sp, #0x18]
    25f4:      	ldp	x8, x9, [x8, #0x10]
    25f8:      	add	x10, sp, #0x18
    25fc:      	stp	x8, x9, [sp, #0x28]
    2600:      	mov	w8, #0x35               // =53
    2604:      	mov	w9, #0x6                // =6
    2608:      	b	0x22cc <kprobe_unwind_php+0x22cc>
    260c:      	ldr	w8, [x21, #0x2c0]
    2610:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2614:      	ldr	x29, [x29]
    2618:      	cmp	w8, #0x7e
    261c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    2620:      	add	w9, w8, #0x1
    2624:      	mov	x10, #-0x2              // =-2
    2628:      	str	w9, [x21, #0x2c0]
    262c:      	mov	w9, #0x18               // =24
    2630:      	umaddl	x8, w8, w9, x21
    2634:      	add	x9, x8, #0x2d0
    2638:      	str	x10, [x8, #0x2d8]
    263c:      	mov	w10, #0x2               // =2
    2640:      	str	xzr, [x8, #0x2d0]
    2644:      	strb	w10, [x8, #0x2e0]
    2648:      	mov	w25, #0x23              // =35
    264c:      	str	wzr, [x8, #0x2e4]
    2650:      	stur	wzr, [x9, #0x11]
    2654:      	b	0x2098 <kprobe_unwind_php+0x2098>
    2658:      	mov	w8, #0x2978             // =10616
    265c:      	add	x0, sp, #0x18
    2660:      	mov	w1, #0x33               // =51
    2664:      	movk	w8, #0xa, lsl #16
    2668:      	stur	w8, [sp, #0x47]
    266c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2670:      	add	x8, x8, #0x0
    2674:      	ldp	x9, x10, [x8, #0x10]
    2678:      	stp	x9, x10, [sp, #0x28]
    267c:      	ldp	x9, x10, [x8, #0x20]
    2680:      	stp	x9, x10, [sp, #0x38]
    2684:      	ldp	x9, x8, [x8]
    2688:      	add	x10, sp, #0x18
    268c:      	stp	x9, x8, [sp, #0x18]
    2690:      	mov	w8, #0x33               // =51
    2694:      	mov	w9, #0x6                // =6
    2698:      	ldrb	w8, [x24, #0x10]
    269c:      	add	x2, x25, x8
    26a0:      	blr	x9
    26a4:      	b	0x1670 <kprobe_unwind_php+0x1670>
    26a8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    26ac:      	add	x8, x8, #0x0
    26b0:      	add	x0, sp, #0x18
    26b4:      	ldp	x9, x10, [x8]
    26b8:      	ldur	x8, [x8, #0xe]
    26bc:      	mov	w1, #0x16               // =22
    26c0:      	stp	x9, x10, [sp, #0x18]
    26c4:      	stur	x8, [sp, #0x26]
    26c8:      	mov	w8, #0x16               // =22
    26cc:      	mov	w9, #0x6                // =6
    26d0:      	add	x10, sp, #0x18
    26d4:      	ldr	x2, [sp, #0x70]
    26d8:      	ldr	w3, [sp, #0x88]
    26dc:      	blr	x9
    26e0:      	ldr	w8, [x21, #0x2c0]
    26e4:      	cmp	w8, #0x7e
    26e8:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    26ec:      	b	0x1e80 <kprobe_unwind_php+0x1e80>
    26f0:      	ldrb	w8, [sp, #0x8c]
    26f4:      	str	wzr, [sp, #0x88]
    26f8:      	cmp	w8, #0x4
    26fc:      	b.eq	0x270c <kprobe_unwind_php+0x270c>
    2700:      	mov	w29, wzr
    2704:      	cmp	w8, #0x2
    2708:      	b.ne	0x2ca4 <kprobe_unwind_php+0x2ca4>
    270c:      	ldrb	w8, [x24, #0x11]
    2710:      	mov	w9, #0x8                // =8
    2714:      	mov	w10, #0x70              // =112
    2718:      	add	x11, sp, #0x68
    271c:      	add	x0, sp, #0x68
    2720:      	mov	w1, #0x8                // =8
    2724:      	add	x8, x25, x8
    2728:      	ldrb	w8, [x24, #0x11]
    272c:      	add	x2, x25, x8
    2730:      	blr	x10
    2734:      	cbz	x0, 0x28d8 <kprobe_unwind_php+0x28d8>
    2738:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    273c:      	ldr	x8, [x8]
    2740:      	ldr	w8, [x8]
    2744:      	cbz	w8, 0x2094 <kprobe_unwind_php+0x2094>
    2748:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    274c:      	add	x8, x8, #0x0
    2750:      	add	x0, sp, #0x18
    2754:      	ldp	x9, x10, [x8, #0x10]
    2758:      	mov	w1, #0x2d               // =45
    275c:      	stp	x9, x10, [sp, #0x28]
    2760:      	ldr	x9, [x8, #0x20]
    2764:      	add	x10, sp, #0x18
    2768:      	str	x9, [sp, #0x38]
    276c:      	ldur	x9, [x8, #0x25]
    2770:      	stur	x9, [sp, #0x3d]
    2774:      	ldp	x9, x8, [x8]
    2778:      	stp	x9, x8, [sp, #0x18]
    277c:      	mov	w8, #0x2d               // =45
    2780:      	mov	w9, #0x6                // =6
    2784:      	ldrb	w8, [x24, #0x11]
    2788:      	add	x2, x25, x8
    278c:      	blr	x9
    2790:      	b	0x2094 <kprobe_unwind_php+0x2094>
    2794:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2798:      	add	x8, x8, #0x0
    279c:      	add	x0, sp, #0x18
    27a0:      	ldp	x9, x10, [x8, #0x10]
    27a4:      	mov	w1, #0x2e               // =46
    27a8:      	stp	x9, x10, [sp, #0x28]
    27ac:      	ldr	x9, [x8, #0x20]
    27b0:      	add	x10, sp, #0x18
    27b4:      	str	x9, [sp, #0x38]
    27b8:      	ldur	x9, [x8, #0x26]
    27bc:      	stur	x9, [sp, #0x3e]
    27c0:      	ldp	x9, x8, [x8]
    27c4:      	stp	x9, x8, [sp, #0x18]
    27c8:      	mov	w8, #0x2e               // =46
    27cc:      	mov	w9, #0x6                // =6
    27d0:      	ldr	w2, [sp, #0x70]
    27d4:      	blr	x9
    27d8:      	cmp	w25, #0x23
    27dc:      	b.eq	0x1ab0 <kprobe_unwind_php+0x1ab0>
    27e0:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    27e4:      	ldr	w29, [sp, #0x88]
    27e8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    27ec:      	ldr	w25, [sp, #0x5c]
    27f0:      	ldr	x8, [x8]
    27f4:      	ldr	w8, [x8]
    27f8:      	cbnz	w8, 0x3028 <kprobe_unwind_php+0x3028>
    27fc:      	ldr	w8, [x21, #0x2c0]
    2800:      	cmp	w8, #0x7e
    2804:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    2808:      	add	w9, w8, #0x1
    280c:      	mov	w10, w29
    2810:      	str	w9, [x21, #0x2c0]
    2814:      	mov	w9, #0x18               // =24
    2818:      	orr	x10, x10, x25, lsl #32
    281c:      	umaddl	x8, w8, w9, x21
    2820:      	ldr	x9, [sp, #0x70]
    2824:      	str	x10, [x8, #0x2d8]
    2828:      	str	x9, [x8, #0x2d0]
    282c:      	ldr	w9, [sp, #0xc]
    2830:      	strb	w9, [x8, #0x2e0]
    2834:      	add	x9, x8, #0x2d0
    2838:      	b	0x2188 <kprobe_unwind_php+0x2188>
    283c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2840:      	add	x8, x8, #0x0
    2844:      	strb	wzr, [sp, #0x50]
    2848:      	add	x0, sp, #0x18
    284c:      	ldp	x9, x10, [x8, #0x20]
    2850:      	mov	w1, #0x39               // =57
    2854:      	stp	x9, x10, [sp, #0x38]
    2858:      	ldr	x9, [x8, #0x30]
    285c:      	str	x9, [sp, #0x48]
    2860:      	ldp	x9, x10, [x8]
    2864:      	stp	x9, x10, [sp, #0x18]
    2868:      	ldp	x8, x9, [x8, #0x10]
    286c:      	add	x10, sp, #0x18
    2870:      	stp	x8, x9, [sp, #0x28]
    2874:      	mov	w8, #0x39               // =57
    2878:      	mov	w9, #0x6                // =6
    287c:      	ldr	x8, [sp, #0x68]
    2880:      	ldrb	w10, [x24, #0x15]
    2884:      	add	x2, x8, x10
    2888:      	blr	x9
    288c:      	mov	w25, #0x27              // =39
    2890:      	b	0x10e4 <kprobe_unwind_php+0x10e4>
    2894:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2898:      	add	x8, x8, #0x0
    289c:      	strb	wzr, [sp, #0x48]
    28a0:      	add	x0, sp, #0x18
    28a4:      	ldp	x9, x10, [x8, #0x10]
    28a8:      	mov	w1, #0x31               // =49
    28ac:      	stp	x9, x10, [sp, #0x28]
    28b0:      	ldp	x9, x10, [x8, #0x20]
    28b4:      	stp	x9, x10, [sp, #0x38]
    28b8:      	ldp	x9, x8, [x8]
    28bc:      	add	x10, sp, #0x18
    28c0:      	stp	x9, x8, [sp, #0x18]
    28c4:      	mov	w8, #0x31               // =49
    28c8:      	mov	w9, #0x6                // =6
    28cc:      	ldr	x2, [sp, #0x70]
    28d0:      	blr	x9
    28d4:      	b	0x1a90 <kprobe_unwind_php+0x1a90>
    28d8:      	ldr	x8, [sp, #0x68]
    28dc:      	ldrb	w9, [x24, #0x15]
    28e0:      	mov	w10, #0x70              // =112
    28e4:      	add	x11, sp, #0x88
    28e8:      	add	x0, sp, #0x88
    28ec:      	mov	w1, #0x4                // =4
    28f0:      	add	x8, x8, x9
    28f4:      	mov	w9, #0x4                // =4
    28f8:      	ldr	x8, [sp, #0x68]
    28fc:      	ldrb	w9, [x24, #0x15]
    2900:      	add	x2, x8, x9
    2904:      	blr	x10
    2908:      	cbz	x0, 0x2a4c <kprobe_unwind_php+0x2a4c>
    290c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2910:      	ldr	x8, [x8]
    2914:      	ldr	w8, [x8]
    2918:      	cbnz	w8, 0x3678 <kprobe_unwind_php+0x3678>
    291c:      	mov	w25, #0x27              // =39
    2920:      	b	0x2098 <kprobe_unwind_php+0x2098>
    2924:      	ldr	x8, [sp, #0x70]
    2928:      	cbz	x8, 0x2acc <kprobe_unwind_php+0x2acc>
    292c:      	ldrb	w9, [x24, #0x14]
    2930:      	mov	w10, #0x70              // =112
    2934:      	add	x11, sp, #0x8c
    2938:      	add	x0, sp, #0x8c
    293c:      	mov	w1, #0x1                // =1
    2940:      	add	x8, x8, x9
    2944:      	mov	w9, #0x1                // =1
    2948:      	ldr	x8, [sp, #0x70]
    294c:      	ldrb	w9, [x24, #0x14]
    2950:      	add	x2, x8, x9
    2954:      	blr	x10
    2958:      	cbz	x0, 0x2bb0 <kprobe_unwind_php+0x2bb0>
    295c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2960:      	ldr	x8, [x8]
    2964:      	ldr	w8, [x8]
    2968:      	cbnz	w8, 0x36d0 <kprobe_unwind_php+0x36d0>
    296c:      	mov	w25, #0x26              // =38
    2970:      	b	0x2558 <kprobe_unwind_php+0x2558>
    2974:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2978:      	ldr	x8, [x8]
    297c:      	ldr	w8, [x8]
    2980:      	cbnz	w8, 0x35d0 <kprobe_unwind_php+0x35d0>
    2984:      	cmp	w25, #0x23
    2988:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    298c:      	ldr	x8, [sp, #0x60]
    2990:      	ldrb	w9, [x24, #0x12]
    2994:      	mov	w10, #0x70              // =112
    2998:      	add	x11, sp, #0x60
    299c:      	add	x0, sp, #0x60
    29a0:      	mov	w1, #0x8                // =8
    29a4:      	add	x8, x8, x9
    29a8:      	mov	w9, #0x8                // =8
    29ac:      	ldr	x8, [sp, #0x60]
    29b0:      	ldrb	w9, [x24, #0x12]
    29b4:      	add	x2, x8, x9
    29b8:      	blr	x10
    29bc:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    29c0:      	ldr	x29, [x29]
    29c4:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    29c8:      	ldr	x25, [sp, #0x60]
    29cc:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    29d0:      	ldrb	w8, [sp, #0x5e]
    29d4:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    29d8:      	ldrb	w8, [x24, #0x10]
    29dc:      	mov	w9, #0x8                // =8
    29e0:      	mov	w10, #0x70              // =112
    29e4:      	add	x11, sp, #0x70
    29e8:      	add	x0, sp, #0x70
    29ec:      	mov	w1, #0x8                // =8
    29f0:      	add	x8, x25, x8
    29f4:      	ldrb	w8, [x24, #0x10]
    29f8:      	add	x2, x25, x8
    29fc:      	blr	x10
    2a00:      	cbz	x0, 0x2de0 <kprobe_unwind_php+0x2de0>
    2a04:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2a08:      	ldr	x8, [x8]
    2a0c:      	ldr	w8, [x8]
    2a10:      	cbnz	w8, 0x39a8 <kprobe_unwind_php+0x39a8>
    2a14:      	mov	w25, #0x25              // =37
    2a18:      	str	w25, [sp, #0x70]
    2a1c:      	mov	w8, #0x1                // =1
    2a20:      	add	x9, sp, #0x70
    2a24:      	add	x1, sp, #0x70
    2a28:      	mov	x0, x23
    2a2c:      	blr	x8
    2a30:      	cbz	x0, 0x2e30 <kprobe_unwind_php+0x2e30>
    2a34:      	ldr	x8, [x0]
    2a38:      	add	x8, x8, #0x1
    2a3c:      	str	x8, [x0]
    2a40:      	cmp	w25, #0x23
    2a44:      	b.eq	0x2e48 <kprobe_unwind_php+0x2e48>
    2a48:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    2a4c:      	ldrb	w8, [x24, #0x13]
    2a50:      	mov	w9, #0x4                // =4
    2a54:      	mov	w10, #0x70              // =112
    2a58:      	add	x11, sp, #0x5c
    2a5c:      	add	x0, sp, #0x5c
    2a60:      	mov	w1, #0x4                // =4
    2a64:      	add	x8, x25, x8
    2a68:      	ldrb	w8, [x24, #0x13]
    2a6c:      	add	x2, x25, x8
    2a70:      	blr	x10
    2a74:      	cbz	x0, 0x2ca0 <kprobe_unwind_php+0x2ca0>
    2a78:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2a7c:      	ldr	x8, [x8]
    2a80:      	ldr	w8, [x8]
    2a84:      	cbz	w8, 0x2094 <kprobe_unwind_php+0x2094>
    2a88:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2a8c:      	add	x8, x8, #0x0
    2a90:      	add	x0, sp, #0x18
    2a94:      	ldp	x9, x10, [x8, #0x20]
    2a98:      	mov	w1, #0x35               // =53
    2a9c:      	mov	x2, x25
    2aa0:      	stp	x9, x10, [sp, #0x38]
    2aa4:      	ldur	x9, [x8, #0x2d]
    2aa8:      	stur	x9, [sp, #0x45]
    2aac:      	ldp	x9, x10, [x8]
    2ab0:      	stp	x9, x10, [sp, #0x18]
    2ab4:      	ldp	x8, x9, [x8, #0x10]
    2ab8:      	add	x10, sp, #0x18
    2abc:      	stp	x8, x9, [sp, #0x28]
    2ac0:      	mov	w8, #0x35               // =53
    2ac4:      	mov	w9, #0x6                // =6
    2ac8:      	b	0x278c <kprobe_unwind_php+0x278c>
    2acc:      	ldr	w8, [x21, #0x2c0]
    2ad0:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2ad4:      	ldr	x29, [x29]
    2ad8:      	cmp	w8, #0x7e
    2adc:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    2ae0:      	add	w9, w8, #0x1
    2ae4:      	mov	x10, #-0x2              // =-2
    2ae8:      	str	w9, [x21, #0x2c0]
    2aec:      	mov	w9, #0x18               // =24
    2af0:      	umaddl	x8, w8, w9, x21
    2af4:      	add	x9, x8, #0x2d0
    2af8:      	str	x10, [x8, #0x2d8]
    2afc:      	mov	w10, #0x2               // =2
    2b00:      	str	xzr, [x8, #0x2d0]
    2b04:      	strb	w10, [x8, #0x2e0]
    2b08:      	mov	w25, #0x23              // =35
    2b0c:      	str	wzr, [x8, #0x2e4]
    2b10:      	stur	wzr, [x9, #0x11]
    2b14:      	b	0x2558 <kprobe_unwind_php+0x2558>
    2b18:      	mov	w8, #0x2978             // =10616
    2b1c:      	add	x0, sp, #0x18
    2b20:      	mov	w1, #0x33               // =51
    2b24:      	movk	w8, #0xa, lsl #16
    2b28:      	stur	w8, [sp, #0x47]
    2b2c:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2b30:      	add	x8, x8, #0x0
    2b34:      	ldp	x9, x10, [x8, #0x10]
    2b38:      	stp	x9, x10, [sp, #0x28]
    2b3c:      	ldp	x9, x10, [x8, #0x20]
    2b40:      	stp	x9, x10, [sp, #0x38]
    2b44:      	ldp	x9, x8, [x8]
    2b48:      	add	x10, sp, #0x18
    2b4c:      	stp	x9, x8, [sp, #0x18]
    2b50:      	mov	w8, #0x33               // =51
    2b54:      	mov	w9, #0x6                // =6
    2b58:      	ldrb	w8, [x24, #0x10]
    2b5c:      	add	x2, x25, x8
    2b60:      	blr	x9
    2b64:      	b	0x1b38 <kprobe_unwind_php+0x1b38>
    2b68:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2b6c:      	add	x8, x8, #0x0
    2b70:      	add	x0, sp, #0x18
    2b74:      	ldp	x9, x10, [x8]
    2b78:      	ldur	x8, [x8, #0xe]
    2b7c:      	mov	w1, #0x16               // =22
    2b80:      	stp	x9, x10, [sp, #0x18]
    2b84:      	stur	x8, [sp, #0x26]
    2b88:      	mov	w8, #0x16               // =22
    2b8c:      	mov	w9, #0x6                // =6
    2b90:      	add	x10, sp, #0x18
    2b94:      	ldr	x2, [sp, #0x70]
    2b98:      	ldr	w3, [sp, #0x88]
    2b9c:      	blr	x9
    2ba0:      	ldr	w8, [x21, #0x2c0]
    2ba4:      	cmp	w8, #0x7e
    2ba8:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    2bac:      	b	0x2348 <kprobe_unwind_php+0x2348>
    2bb0:      	ldrb	w8, [sp, #0x8c]
    2bb4:      	str	wzr, [sp, #0x88]
    2bb8:      	cmp	w8, #0x4
    2bbc:      	b.eq	0x2bcc <kprobe_unwind_php+0x2bcc>
    2bc0:      	mov	w29, wzr
    2bc4:      	cmp	w8, #0x2
    2bc8:      	b.ne	0x3164 <kprobe_unwind_php+0x3164>
    2bcc:      	ldrb	w8, [x24, #0x11]
    2bd0:      	mov	w9, #0x8                // =8
    2bd4:      	mov	w10, #0x70              // =112
    2bd8:      	add	x11, sp, #0x68
    2bdc:      	add	x0, sp, #0x68
    2be0:      	mov	w1, #0x8                // =8
    2be4:      	add	x8, x25, x8
    2be8:      	ldrb	w8, [x24, #0x11]
    2bec:      	add	x2, x25, x8
    2bf0:      	blr	x10
    2bf4:      	cbz	x0, 0x2d94 <kprobe_unwind_php+0x2d94>
    2bf8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2bfc:      	ldr	x8, [x8]
    2c00:      	ldr	w8, [x8]
    2c04:      	cbz	w8, 0x2554 <kprobe_unwind_php+0x2554>
    2c08:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2c0c:      	add	x8, x8, #0x0
    2c10:      	add	x0, sp, #0x18
    2c14:      	ldp	x9, x10, [x8, #0x10]
    2c18:      	mov	w1, #0x2d               // =45
    2c1c:      	stp	x9, x10, [sp, #0x28]
    2c20:      	ldr	x9, [x8, #0x20]
    2c24:      	add	x10, sp, #0x18
    2c28:      	str	x9, [sp, #0x38]
    2c2c:      	ldur	x9, [x8, #0x25]
    2c30:      	stur	x9, [sp, #0x3d]
    2c34:      	ldp	x9, x8, [x8]
    2c38:      	stp	x9, x8, [sp, #0x18]
    2c3c:      	mov	w8, #0x2d               // =45
    2c40:      	mov	w9, #0x6                // =6
    2c44:      	ldrb	w8, [x24, #0x11]
    2c48:      	add	x2, x25, x8
    2c4c:      	b	0x2f84 <kprobe_unwind_php+0x2f84>
    2c50:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2c54:      	add	x8, x8, #0x0
    2c58:      	add	x0, sp, #0x18
    2c5c:      	ldp	x9, x10, [x8, #0x10]
    2c60:      	mov	w1, #0x2e               // =46
    2c64:      	stp	x9, x10, [sp, #0x28]
    2c68:      	ldr	x9, [x8, #0x20]
    2c6c:      	add	x10, sp, #0x18
    2c70:      	str	x9, [sp, #0x38]
    2c74:      	ldur	x9, [x8, #0x26]
    2c78:      	stur	x9, [sp, #0x3e]
    2c7c:      	ldp	x9, x8, [x8]
    2c80:      	stp	x9, x8, [sp, #0x18]
    2c84:      	mov	w8, #0x2e               // =46
    2c88:      	mov	w9, #0x6                // =6
    2c8c:      	ldr	w2, [sp, #0x70]
    2c90:      	blr	x9
    2c94:      	cmp	w25, #0x23
    2c98:      	b.eq	0x200c <kprobe_unwind_php+0x200c>
    2c9c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    2ca0:      	ldr	w29, [sp, #0x88]
    2ca4:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2ca8:      	ldr	w25, [sp, #0x5c]
    2cac:      	ldr	x8, [x8]
    2cb0:      	ldr	w8, [x8]
    2cb4:      	cbnz	w8, 0x34e8 <kprobe_unwind_php+0x34e8>
    2cb8:      	ldr	w8, [x21, #0x2c0]
    2cbc:      	cmp	w8, #0x7e
    2cc0:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    2cc4:      	add	w9, w8, #0x1
    2cc8:      	mov	w10, w29
    2ccc:      	str	w9, [x21, #0x2c0]
    2cd0:      	mov	w9, #0x18               // =24
    2cd4:      	orr	x10, x10, x25, lsl #32
    2cd8:      	umaddl	x8, w8, w9, x21
    2cdc:      	ldr	x9, [sp, #0x70]
    2ce0:      	str	x10, [x8, #0x2d8]
    2ce4:      	str	x9, [x8, #0x2d0]
    2ce8:      	ldr	w9, [sp, #0xc]
    2cec:      	strb	w9, [x8, #0x2e0]
    2cf0:      	add	x9, x8, #0x2d0
    2cf4:      	b	0x2648 <kprobe_unwind_php+0x2648>
    2cf8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2cfc:      	add	x8, x8, #0x0
    2d00:      	strb	wzr, [sp, #0x50]
    2d04:      	add	x0, sp, #0x18
    2d08:      	ldp	x9, x10, [x8, #0x20]
    2d0c:      	mov	w1, #0x39               // =57
    2d10:      	stp	x9, x10, [sp, #0x38]
    2d14:      	ldr	x9, [x8, #0x30]
    2d18:      	str	x9, [sp, #0x48]
    2d1c:      	ldp	x9, x10, [x8]
    2d20:      	stp	x9, x10, [sp, #0x18]
    2d24:      	ldp	x8, x9, [x8, #0x10]
    2d28:      	add	x10, sp, #0x18
    2d2c:      	stp	x8, x9, [sp, #0x28]
    2d30:      	mov	w8, #0x39               // =57
    2d34:      	mov	w9, #0x6                // =6
    2d38:      	ldr	x8, [sp, #0x68]
    2d3c:      	ldrb	w10, [x24, #0x15]
    2d40:      	add	x2, x8, x10
    2d44:      	blr	x9
    2d48:      	mov	w25, #0x27              // =39
    2d4c:      	b	0x1674 <kprobe_unwind_php+0x1674>
    2d50:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2d54:      	add	x8, x8, #0x0
    2d58:      	strb	wzr, [sp, #0x48]
    2d5c:      	add	x0, sp, #0x18
    2d60:      	ldp	x9, x10, [x8, #0x10]
    2d64:      	mov	w1, #0x31               // =49
    2d68:      	stp	x9, x10, [sp, #0x28]
    2d6c:      	ldp	x9, x10, [x8, #0x20]
    2d70:      	stp	x9, x10, [sp, #0x38]
    2d74:      	ldp	x9, x8, [x8]
    2d78:      	add	x10, sp, #0x18
    2d7c:      	stp	x9, x8, [sp, #0x18]
    2d80:      	mov	w8, #0x31               // =49
    2d84:      	mov	w9, #0x6                // =6
    2d88:      	ldr	x2, [sp, #0x70]
    2d8c:      	blr	x9
    2d90:      	b	0x1fec <kprobe_unwind_php+0x1fec>
    2d94:      	ldr	x8, [sp, #0x68]
    2d98:      	ldrb	w9, [x24, #0x15]
    2d9c:      	mov	w10, #0x70              // =112
    2da0:      	add	x11, sp, #0x88
    2da4:      	add	x0, sp, #0x88
    2da8:      	mov	w1, #0x4                // =4
    2dac:      	add	x8, x8, x9
    2db0:      	mov	w9, #0x4                // =4
    2db4:      	ldr	x8, [sp, #0x68]
    2db8:      	ldrb	w9, [x24, #0x15]
    2dbc:      	add	x2, x8, x9
    2dc0:      	blr	x10
    2dc4:      	cbz	x0, 0x2f08 <kprobe_unwind_php+0x2f08>
    2dc8:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2dcc:      	ldr	x8, [x8]
    2dd0:      	ldr	w8, [x8]
    2dd4:      	cbnz	w8, 0x3b88 <kprobe_unwind_php+0x3b88>
    2dd8:      	mov	w25, #0x27              // =39
    2ddc:      	b	0x2558 <kprobe_unwind_php+0x2558>
    2de0:      	ldr	x8, [sp, #0x70]
    2de4:      	cbz	x8, 0x2f8c <kprobe_unwind_php+0x2f8c>
    2de8:      	ldrb	w9, [x24, #0x14]
    2dec:      	mov	w10, #0x70              // =112
    2df0:      	add	x11, sp, #0x8c
    2df4:      	add	x0, sp, #0x8c
    2df8:      	mov	w1, #0x1                // =1
    2dfc:      	add	x8, x8, x9
    2e00:      	mov	w9, #0x1                // =1
    2e04:      	ldr	x8, [sp, #0x70]
    2e08:      	ldrb	w9, [x24, #0x14]
    2e0c:      	add	x2, x8, x9
    2e10:      	blr	x10
    2e14:      	cbz	x0, 0x3070 <kprobe_unwind_php+0x3070>
    2e18:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2e1c:      	ldr	x8, [x8]
    2e20:      	ldr	w8, [x8]
    2e24:      	cbnz	w8, 0x3be0 <kprobe_unwind_php+0x3be0>
    2e28:      	mov	w25, #0x26              // =38
    2e2c:      	b	0x2a18 <kprobe_unwind_php+0x2a18>
    2e30:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2e34:      	ldr	x8, [x8]
    2e38:      	ldr	w8, [x8]
    2e3c:      	cbnz	w8, 0x3ae0 <kprobe_unwind_php+0x3ae0>
    2e40:      	cmp	w25, #0x23
    2e44:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    2e48:      	ldr	x8, [sp, #0x60]
    2e4c:      	ldrb	w9, [x24, #0x12]
    2e50:      	mov	w10, #0x70              // =112
    2e54:      	add	x11, sp, #0x60
    2e58:      	add	x0, sp, #0x60
    2e5c:      	mov	w1, #0x8                // =8
    2e60:      	add	x8, x8, x9
    2e64:      	mov	w9, #0x8                // =8
    2e68:      	ldr	x8, [sp, #0x60]
    2e6c:      	ldrb	w9, [x24, #0x12]
    2e70:      	add	x2, x8, x9
    2e74:      	blr	x10
    2e78:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2e7c:      	ldr	x29, [x29]
    2e80:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    2e84:      	ldr	x25, [sp, #0x60]
    2e88:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    2e8c:      	ldrb	w8, [sp, #0x5e]
    2e90:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    2e94:      	ldrb	w8, [x24, #0x10]
    2e98:      	mov	w9, #0x8                // =8
    2e9c:      	mov	w10, #0x70              // =112
    2ea0:      	add	x11, sp, #0x70
    2ea4:      	add	x0, sp, #0x70
    2ea8:      	mov	w1, #0x8                // =8
    2eac:      	add	x8, x25, x8
    2eb0:      	ldrb	w8, [x24, #0x10]
    2eb4:      	add	x2, x25, x8
    2eb8:      	blr	x10
    2ebc:      	cbz	x0, 0x32a0 <kprobe_unwind_php+0x32a0>
    2ec0:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2ec4:      	ldr	x8, [x8]
    2ec8:      	ldr	w8, [x8]
    2ecc:      	cbnz	w8, 0x3c24 <kprobe_unwind_php+0x3c24>
    2ed0:      	mov	w25, #0x25              // =37
    2ed4:      	str	w25, [sp, #0x70]
    2ed8:      	mov	w8, #0x1                // =1
    2edc:      	add	x9, sp, #0x70
    2ee0:      	add	x1, sp, #0x70
    2ee4:      	mov	x0, x23
    2ee8:      	blr	x8
    2eec:      	cbz	x0, 0x32f0 <kprobe_unwind_php+0x32f0>
    2ef0:      	ldr	x8, [x0]
    2ef4:      	add	x8, x8, #0x1
    2ef8:      	str	x8, [x0]
    2efc:      	cmp	w25, #0x23
    2f00:      	b.eq	0x3308 <kprobe_unwind_php+0x3308>
    2f04:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    2f08:      	ldrb	w8, [x24, #0x13]
    2f0c:      	mov	w9, #0x4                // =4
    2f10:      	mov	w10, #0x70              // =112
    2f14:      	add	x11, sp, #0x5c
    2f18:      	add	x0, sp, #0x5c
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x25, x8
    2f24:      	ldrb	w8, [x24, #0x13]
    2f28:      	add	x2, x25, x8
    2f2c:      	blr	x10
    2f30:      	cbz	x0, 0x3160 <kprobe_unwind_php+0x3160>
    2f34:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2f38:      	ldr	x8, [x8]
    2f3c:      	ldr	w8, [x8]
    2f40:      	cbz	w8, 0x2554 <kprobe_unwind_php+0x2554>
    2f44:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2f48:      	add	x8, x8, #0x0
    2f4c:      	add	x0, sp, #0x18
    2f50:      	ldp	x9, x10, [x8, #0x20]
    2f54:      	mov	w1, #0x35               // =53
    2f58:      	mov	x2, x25
    2f5c:      	stp	x9, x10, [sp, #0x38]
    2f60:      	ldur	x9, [x8, #0x2d]
    2f64:      	stur	x9, [sp, #0x45]
    2f68:      	ldp	x9, x10, [x8]
    2f6c:      	stp	x9, x10, [sp, #0x18]
    2f70:      	ldp	x8, x9, [x8, #0x10]
    2f74:      	add	x10, sp, #0x18
    2f78:      	stp	x8, x9, [sp, #0x28]
    2f7c:      	mov	w8, #0x35               // =53
    2f80:      	mov	w9, #0x6                // =6
    2f84:      	blr	x9
    2f88:      	b	0x2554 <kprobe_unwind_php+0x2554>
    2f8c:      	ldr	w8, [x21, #0x2c0]
    2f90:      	adrp	x29, 0x2000 <kprobe_unwind_php+0x2000>
    2f94:      	ldr	x29, [x29]
    2f98:      	cmp	w8, #0x7e
    2f9c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    2fa0:      	add	w9, w8, #0x1
    2fa4:      	mov	x10, #-0x2              // =-2
    2fa8:      	str	w9, [x21, #0x2c0]
    2fac:      	mov	w9, #0x18               // =24
    2fb0:      	umaddl	x8, w8, w9, x21
    2fb4:      	add	x9, x8, #0x2d0
    2fb8:      	str	x10, [x8, #0x2d8]
    2fbc:      	mov	w10, #0x2               // =2
    2fc0:      	str	xzr, [x8, #0x2d0]
    2fc4:      	strb	w10, [x8, #0x2e0]
    2fc8:      	mov	w25, #0x23              // =35
    2fcc:      	str	wzr, [x8, #0x2e4]
    2fd0:      	stur	wzr, [x9, #0x11]
    2fd4:      	b	0x2a18 <kprobe_unwind_php+0x2a18>
    2fd8:      	mov	w8, #0x2978             // =10616
    2fdc:      	add	x0, sp, #0x18
    2fe0:      	mov	w1, #0x33               // =51
    2fe4:      	movk	w8, #0xa, lsl #16
    2fe8:      	stur	w8, [sp, #0x47]
    2fec:      	adrp	x8, 0x2000 <kprobe_unwind_php+0x2000>
    2ff0:      	add	x8, x8, #0x0
    2ff4:      	ldp	x9, x10, [x8, #0x10]
    2ff8:      	stp	x9, x10, [sp, #0x28]
    2ffc:      	ldp	x9, x10, [x8, #0x20]
    3000:      	stp	x9, x10, [sp, #0x38]
    3004:      	ldp	x9, x8, [x8]
    3008:      	add	x10, sp, #0x18
    300c:      	stp	x9, x8, [sp, #0x18]
    3010:      	mov	w8, #0x33               // =51
    3014:      	mov	w9, #0x6                // =6
    3018:      	ldrb	w8, [x24, #0x10]
    301c:      	add	x2, x25, x8
    3020:      	blr	x9
    3024:      	b	0x2094 <kprobe_unwind_php+0x2094>
    3028:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    302c:      	add	x8, x8, #0x0
    3030:      	add	x0, sp, #0x18
    3034:      	ldp	x9, x10, [x8]
    3038:      	ldur	x8, [x8, #0xe]
    303c:      	mov	w1, #0x16               // =22
    3040:      	stp	x9, x10, [sp, #0x18]
    3044:      	stur	x8, [sp, #0x26]
    3048:      	mov	w8, #0x16               // =22
    304c:      	mov	w9, #0x6                // =6
    3050:      	add	x10, sp, #0x18
    3054:      	ldr	x2, [sp, #0x70]
    3058:      	ldr	w3, [sp, #0x88]
    305c:      	blr	x9
    3060:      	ldr	w8, [x21, #0x2c0]
    3064:      	cmp	w8, #0x7e
    3068:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    306c:      	b	0x2808 <kprobe_unwind_php+0x2808>
    3070:      	ldrb	w8, [sp, #0x8c]
    3074:      	str	wzr, [sp, #0x88]
    3078:      	cmp	w8, #0x4
    307c:      	b.eq	0x308c <kprobe_unwind_php+0x308c>
    3080:      	mov	w29, wzr
    3084:      	cmp	w8, #0x2
    3088:      	b.ne	0x3624 <kprobe_unwind_php+0x3624>
    308c:      	ldrb	w8, [x24, #0x11]
    3090:      	mov	w9, #0x8                // =8
    3094:      	mov	w10, #0x70              // =112
    3098:      	add	x11, sp, #0x68
    309c:      	add	x0, sp, #0x68
    30a0:      	mov	w1, #0x8                // =8
    30a4:      	add	x8, x25, x8
    30a8:      	ldrb	w8, [x24, #0x11]
    30ac:      	add	x2, x25, x8
    30b0:      	blr	x10
    30b4:      	cbz	x0, 0x3254 <kprobe_unwind_php+0x3254>
    30b8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    30bc:      	ldr	x8, [x8]
    30c0:      	ldr	w8, [x8]
    30c4:      	cbz	w8, 0x2a14 <kprobe_unwind_php+0x2a14>
    30c8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    30cc:      	add	x8, x8, #0x0
    30d0:      	add	x0, sp, #0x18
    30d4:      	ldp	x9, x10, [x8, #0x10]
    30d8:      	mov	w1, #0x2d               // =45
    30dc:      	stp	x9, x10, [sp, #0x28]
    30e0:      	ldr	x9, [x8, #0x20]
    30e4:      	add	x10, sp, #0x18
    30e8:      	str	x9, [sp, #0x38]
    30ec:      	ldur	x9, [x8, #0x25]
    30f0:      	stur	x9, [sp, #0x3d]
    30f4:      	ldp	x9, x8, [x8]
    30f8:      	stp	x9, x8, [sp, #0x18]
    30fc:      	mov	w8, #0x2d               // =45
    3100:      	mov	w9, #0x6                // =6
    3104:      	ldrb	w8, [x24, #0x11]
    3108:      	add	x2, x25, x8
    310c:      	b	0x3444 <kprobe_unwind_php+0x3444>
    3110:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3114:      	add	x8, x8, #0x0
    3118:      	add	x0, sp, #0x18
    311c:      	ldp	x9, x10, [x8, #0x10]
    3120:      	mov	w1, #0x2e               // =46
    3124:      	stp	x9, x10, [sp, #0x28]
    3128:      	ldr	x9, [x8, #0x20]
    312c:      	add	x10, sp, #0x18
    3130:      	str	x9, [sp, #0x38]
    3134:      	ldur	x9, [x8, #0x26]
    3138:      	stur	x9, [sp, #0x3e]
    313c:      	ldp	x9, x8, [x8]
    3140:      	stp	x9, x8, [sp, #0x18]
    3144:      	mov	w8, #0x2e               // =46
    3148:      	mov	w9, #0x6                // =6
    314c:      	ldr	w2, [sp, #0x70]
    3150:      	blr	x9
    3154:      	cmp	w25, #0x23
    3158:      	b.eq	0x24cc <kprobe_unwind_php+0x24cc>
    315c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    3160:      	ldr	w29, [sp, #0x88]
    3164:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3168:      	ldr	w25, [sp, #0x5c]
    316c:      	ldr	x8, [x8]
    3170:      	ldr	w8, [x8]
    3174:      	cbnz	w8, 0x39f8 <kprobe_unwind_php+0x39f8>
    3178:      	ldr	w8, [x21, #0x2c0]
    317c:      	cmp	w8, #0x7e
    3180:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    3184:      	add	w9, w8, #0x1
    3188:      	mov	w10, w29
    318c:      	str	w9, [x21, #0x2c0]
    3190:      	mov	w9, #0x18               // =24
    3194:      	orr	x10, x10, x25, lsl #32
    3198:      	umaddl	x8, w8, w9, x21
    319c:      	ldr	x9, [sp, #0x70]
    31a0:      	str	x10, [x8, #0x2d8]
    31a4:      	str	x9, [x8, #0x2d0]
    31a8:      	ldr	w9, [sp, #0xc]
    31ac:      	strb	w9, [x8, #0x2e0]
    31b0:      	add	x9, x8, #0x2d0
    31b4:      	b	0x2b08 <kprobe_unwind_php+0x2b08>
    31b8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    31bc:      	add	x8, x8, #0x0
    31c0:      	strb	wzr, [sp, #0x50]
    31c4:      	add	x0, sp, #0x18
    31c8:      	ldp	x9, x10, [x8, #0x20]
    31cc:      	mov	w1, #0x39               // =57
    31d0:      	stp	x9, x10, [sp, #0x38]
    31d4:      	ldr	x9, [x8, #0x30]
    31d8:      	str	x9, [sp, #0x48]
    31dc:      	ldp	x9, x10, [x8]
    31e0:      	stp	x9, x10, [sp, #0x18]
    31e4:      	ldp	x8, x9, [x8, #0x10]
    31e8:      	add	x10, sp, #0x18
    31ec:      	stp	x8, x9, [sp, #0x28]
    31f0:      	mov	w8, #0x39               // =57
    31f4:      	mov	w9, #0x6                // =6
    31f8:      	ldr	x8, [sp, #0x68]
    31fc:      	ldrb	w10, [x24, #0x15]
    3200:      	add	x2, x8, x10
    3204:      	blr	x9
    3208:      	mov	w25, #0x27              // =39
    320c:      	b	0x1b3c <kprobe_unwind_php+0x1b3c>
    3210:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3214:      	add	x8, x8, #0x0
    3218:      	strb	wzr, [sp, #0x48]
    321c:      	add	x0, sp, #0x18
    3220:      	ldp	x9, x10, [x8, #0x10]
    3224:      	mov	w1, #0x31               // =49
    3228:      	stp	x9, x10, [sp, #0x28]
    322c:      	ldp	x9, x10, [x8, #0x20]
    3230:      	stp	x9, x10, [sp, #0x38]
    3234:      	ldp	x9, x8, [x8]
    3238:      	add	x10, sp, #0x18
    323c:      	stp	x9, x8, [sp, #0x18]
    3240:      	mov	w8, #0x31               // =49
    3244:      	mov	w9, #0x6                // =6
    3248:      	ldr	x2, [sp, #0x70]
    324c:      	blr	x9
    3250:      	b	0x24ac <kprobe_unwind_php+0x24ac>
    3254:      	ldr	x8, [sp, #0x68]
    3258:      	ldrb	w9, [x24, #0x15]
    325c:      	mov	w10, #0x70              // =112
    3260:      	add	x11, sp, #0x88
    3264:      	add	x0, sp, #0x88
    3268:      	mov	w1, #0x4                // =4
    326c:      	add	x8, x8, x9
    3270:      	mov	w9, #0x4                // =4
    3274:      	ldr	x8, [sp, #0x68]
    3278:      	ldrb	w9, [x24, #0x15]
    327c:      	add	x2, x8, x9
    3280:      	blr	x10
    3284:      	cbz	x0, 0x33c8 <kprobe_unwind_php+0x33c8>
    3288:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    328c:      	ldr	x8, [x8]
    3290:      	ldr	w8, [x8]
    3294:      	cbnz	w8, 0x3c74 <kprobe_unwind_php+0x3c74>
    3298:      	mov	w25, #0x27              // =39
    329c:      	b	0x2a18 <kprobe_unwind_php+0x2a18>
    32a0:      	ldr	x8, [sp, #0x70]
    32a4:      	cbz	x8, 0x344c <kprobe_unwind_php+0x344c>
    32a8:      	ldrb	w9, [x24, #0x14]
    32ac:      	mov	w10, #0x70              // =112
    32b0:      	add	x11, sp, #0x8c
    32b4:      	add	x0, sp, #0x8c
    32b8:      	mov	w1, #0x1                // =1
    32bc:      	add	x8, x8, x9
    32c0:      	mov	w9, #0x1                // =1
    32c4:      	ldr	x8, [sp, #0x70]
    32c8:      	ldrb	w9, [x24, #0x14]
    32cc:      	add	x2, x8, x9
    32d0:      	blr	x10
    32d4:      	cbz	x0, 0x3530 <kprobe_unwind_php+0x3530>
    32d8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    32dc:      	ldr	x8, [x8]
    32e0:      	ldr	w8, [x8]
    32e4:      	cbnz	w8, 0x3ccc <kprobe_unwind_php+0x3ccc>
    32e8:      	mov	w25, #0x26              // =38
    32ec:      	b	0x2ed4 <kprobe_unwind_php+0x2ed4>
    32f0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    32f4:      	ldr	x8, [x8]
    32f8:      	ldr	w8, [x8]
    32fc:      	cbnz	w8, 0x3d10 <kprobe_unwind_php+0x3d10>
    3300:      	cmp	w25, #0x23
    3304:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    3308:      	ldr	x8, [sp, #0x60]
    330c:      	ldrb	w9, [x24, #0x12]
    3310:      	mov	w10, #0x70              // =112
    3314:      	add	x11, sp, #0x60
    3318:      	add	x0, sp, #0x60
    331c:      	mov	w1, #0x8                // =8
    3320:      	add	x8, x8, x9
    3324:      	mov	w9, #0x8                // =8
    3328:      	ldr	x8, [sp, #0x60]
    332c:      	ldrb	w9, [x24, #0x12]
    3330:      	add	x2, x8, x9
    3334:      	blr	x10
    3338:      	adrp	x29, 0x3000 <kprobe_unwind_php+0x3000>
    333c:      	ldr	x29, [x29]
    3340:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    3344:      	ldr	x25, [sp, #0x60]
    3348:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    334c:      	ldrb	w8, [sp, #0x5e]
    3350:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    3354:      	ldrb	w8, [x24, #0x10]
    3358:      	mov	w9, #0x8                // =8
    335c:      	mov	w10, #0x70              // =112
    3360:      	add	x11, sp, #0x70
    3364:      	add	x0, sp, #0x70
    3368:      	mov	w1, #0x8                // =8
    336c:      	add	x8, x25, x8
    3370:      	ldrb	w8, [x24, #0x10]
    3374:      	add	x2, x25, x8
    3378:      	blr	x10
    337c:      	cbz	x0, 0x3760 <kprobe_unwind_php+0x3760>
    3380:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3384:      	ldr	x8, [x8]
    3388:      	ldr	w8, [x8]
    338c:      	cbnz	w8, 0x3d60 <kprobe_unwind_php+0x3d60>
    3390:      	mov	w25, #0x25              // =37
    3394:      	str	w25, [sp, #0x70]
    3398:      	mov	w8, #0x1                // =1
    339c:      	add	x9, sp, #0x70
    33a0:      	add	x1, sp, #0x70
    33a4:      	mov	x0, x23
    33a8:      	blr	x8
    33ac:      	cbz	x0, 0x37f0 <kprobe_unwind_php+0x37f0>
    33b0:      	ldr	x8, [x0]
    33b4:      	add	x8, x8, #0x1
    33b8:      	str	x8, [x0]
    33bc:      	cmp	w25, #0x23
    33c0:      	b.eq	0x3808 <kprobe_unwind_php+0x3808>
    33c4:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    33c8:      	ldrb	w8, [x24, #0x13]
    33cc:      	mov	w9, #0x4                // =4
    33d0:      	mov	w10, #0x70              // =112
    33d4:      	add	x11, sp, #0x5c
    33d8:      	add	x0, sp, #0x5c
    33dc:      	mov	w1, #0x4                // =4
    33e0:      	add	x8, x25, x8
    33e4:      	ldrb	w8, [x24, #0x13]
    33e8:      	add	x2, x25, x8
    33ec:      	blr	x10
    33f0:      	cbz	x0, 0x3620 <kprobe_unwind_php+0x3620>
    33f4:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    33f8:      	ldr	x8, [x8]
    33fc:      	ldr	w8, [x8]
    3400:      	cbz	w8, 0x2a14 <kprobe_unwind_php+0x2a14>
    3404:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3408:      	add	x8, x8, #0x0
    340c:      	add	x0, sp, #0x18
    3410:      	ldp	x9, x10, [x8, #0x20]
    3414:      	mov	w1, #0x35               // =53
    3418:      	mov	x2, x25
    341c:      	stp	x9, x10, [sp, #0x38]
    3420:      	ldur	x9, [x8, #0x2d]
    3424:      	stur	x9, [sp, #0x45]
    3428:      	ldp	x9, x10, [x8]
    342c:      	stp	x9, x10, [sp, #0x18]
    3430:      	ldp	x8, x9, [x8, #0x10]
    3434:      	add	x10, sp, #0x18
    3438:      	stp	x8, x9, [sp, #0x28]
    343c:      	mov	w8, #0x35               // =53
    3440:      	mov	w9, #0x6                // =6
    3444:      	blr	x9
    3448:      	b	0x2a14 <kprobe_unwind_php+0x2a14>
    344c:      	ldr	w8, [x21, #0x2c0]
    3450:      	adrp	x29, 0x3000 <kprobe_unwind_php+0x3000>
    3454:      	ldr	x29, [x29]
    3458:      	cmp	w8, #0x7e
    345c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    3460:      	add	w9, w8, #0x1
    3464:      	mov	x10, #-0x2              // =-2
    3468:      	str	w9, [x21, #0x2c0]
    346c:      	mov	w9, #0x18               // =24
    3470:      	umaddl	x8, w8, w9, x21
    3474:      	add	x9, x8, #0x2d0
    3478:      	str	x10, [x8, #0x2d8]
    347c:      	mov	w10, #0x2               // =2
    3480:      	str	xzr, [x8, #0x2d0]
    3484:      	strb	w10, [x8, #0x2e0]
    3488:      	mov	w25, #0x23              // =35
    348c:      	str	wzr, [x8, #0x2e4]
    3490:      	stur	wzr, [x9, #0x11]
    3494:      	b	0x2ed4 <kprobe_unwind_php+0x2ed4>
    3498:      	mov	w8, #0x2978             // =10616
    349c:      	add	x0, sp, #0x18
    34a0:      	mov	w1, #0x33               // =51
    34a4:      	movk	w8, #0xa, lsl #16
    34a8:      	stur	w8, [sp, #0x47]
    34ac:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    34b0:      	add	x8, x8, #0x0
    34b4:      	ldp	x9, x10, [x8, #0x10]
    34b8:      	stp	x9, x10, [sp, #0x28]
    34bc:      	ldp	x9, x10, [x8, #0x20]
    34c0:      	stp	x9, x10, [sp, #0x38]
    34c4:      	ldp	x9, x8, [x8]
    34c8:      	add	x10, sp, #0x18
    34cc:      	stp	x9, x8, [sp, #0x18]
    34d0:      	mov	w8, #0x33               // =51
    34d4:      	mov	w9, #0x6                // =6
    34d8:      	ldrb	w8, [x24, #0x10]
    34dc:      	add	x2, x25, x8
    34e0:      	blr	x9
    34e4:      	b	0x2554 <kprobe_unwind_php+0x2554>
    34e8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    34ec:      	add	x8, x8, #0x0
    34f0:      	add	x0, sp, #0x18
    34f4:      	ldp	x9, x10, [x8]
    34f8:      	ldur	x8, [x8, #0xe]
    34fc:      	mov	w1, #0x16               // =22
    3500:      	stp	x9, x10, [sp, #0x18]
    3504:      	stur	x8, [sp, #0x26]
    3508:      	mov	w8, #0x16               // =22
    350c:      	mov	w9, #0x6                // =6
    3510:      	add	x10, sp, #0x18
    3514:      	ldr	x2, [sp, #0x70]
    3518:      	ldr	w3, [sp, #0x88]
    351c:      	blr	x9
    3520:      	ldr	w8, [x21, #0x2c0]
    3524:      	cmp	w8, #0x7e
    3528:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    352c:      	b	0x2cc4 <kprobe_unwind_php+0x2cc4>
    3530:      	ldrb	w8, [sp, #0x8c]
    3534:      	str	wzr, [sp, #0x88]
    3538:      	cmp	w8, #0x4
    353c:      	b.eq	0x354c <kprobe_unwind_php+0x354c>
    3540:      	mov	w29, wzr
    3544:      	cmp	w8, #0x2
    3548:      	b.ne	0x3b34 <kprobe_unwind_php+0x3b34>
    354c:      	ldrb	w8, [x24, #0x11]
    3550:      	mov	w9, #0x8                // =8
    3554:      	mov	w10, #0x70              // =112
    3558:      	add	x11, sp, #0x68
    355c:      	add	x0, sp, #0x68
    3560:      	mov	w1, #0x8                // =8
    3564:      	add	x8, x25, x8
    3568:      	ldrb	w8, [x24, #0x11]
    356c:      	add	x2, x25, x8
    3570:      	blr	x10
    3574:      	cbz	x0, 0x3714 <kprobe_unwind_php+0x3714>
    3578:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    357c:      	ldr	x8, [x8]
    3580:      	ldr	w8, [x8]
    3584:      	cbz	w8, 0x2ed0 <kprobe_unwind_php+0x2ed0>
    3588:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    358c:      	add	x8, x8, #0x0
    3590:      	add	x0, sp, #0x18
    3594:      	ldp	x9, x10, [x8, #0x10]
    3598:      	mov	w1, #0x2d               // =45
    359c:      	stp	x9, x10, [sp, #0x28]
    35a0:      	ldr	x9, [x8, #0x20]
    35a4:      	add	x10, sp, #0x18
    35a8:      	str	x9, [sp, #0x38]
    35ac:      	ldur	x9, [x8, #0x25]
    35b0:      	stur	x9, [sp, #0x3d]
    35b4:      	ldp	x9, x8, [x8]
    35b8:      	stp	x9, x8, [sp, #0x18]
    35bc:      	mov	w8, #0x2d               // =45
    35c0:      	mov	w9, #0x6                // =6
    35c4:      	ldrb	w8, [x24, #0x11]
    35c8:      	add	x2, x25, x8
    35cc:      	b	0x3960 <kprobe_unwind_php+0x3960>
    35d0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    35d4:      	add	x8, x8, #0x0
    35d8:      	add	x0, sp, #0x18
    35dc:      	ldp	x9, x10, [x8, #0x10]
    35e0:      	mov	w1, #0x2e               // =46
    35e4:      	stp	x9, x10, [sp, #0x28]
    35e8:      	ldr	x9, [x8, #0x20]
    35ec:      	add	x10, sp, #0x18
    35f0:      	str	x9, [sp, #0x38]
    35f4:      	ldur	x9, [x8, #0x26]
    35f8:      	stur	x9, [sp, #0x3e]
    35fc:      	ldp	x9, x8, [x8]
    3600:      	stp	x9, x8, [sp, #0x18]
    3604:      	mov	w8, #0x2e               // =46
    3608:      	mov	w9, #0x6                // =6
    360c:      	ldr	w2, [sp, #0x70]
    3610:      	blr	x9
    3614:      	cmp	w25, #0x23
    3618:      	b.eq	0x298c <kprobe_unwind_php+0x298c>
    361c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    3620:      	ldr	w29, [sp, #0x88]
    3624:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3628:      	ldr	w25, [sp, #0x5c]
    362c:      	ldr	x8, [x8]
    3630:      	ldr	w8, [x8]
    3634:      	cbnz	w8, 0x3db0 <kprobe_unwind_php+0x3db0>
    3638:      	ldr	w8, [x21, #0x2c0]
    363c:      	cmp	w8, #0x7e
    3640:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    3644:      	add	w9, w8, #0x1
    3648:      	mov	w10, w29
    364c:      	str	w9, [x21, #0x2c0]
    3650:      	mov	w9, #0x18               // =24
    3654:      	orr	x10, x10, x25, lsl #32
    3658:      	umaddl	x8, w8, w9, x21
    365c:      	ldr	x9, [sp, #0x70]
    3660:      	str	x10, [x8, #0x2d8]
    3664:      	str	x9, [x8, #0x2d0]
    3668:      	ldr	w9, [sp, #0xc]
    366c:      	strb	w9, [x8, #0x2e0]
    3670:      	add	x9, x8, #0x2d0
    3674:      	b	0x2fc8 <kprobe_unwind_php+0x2fc8>
    3678:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    367c:      	add	x8, x8, #0x0
    3680:      	strb	wzr, [sp, #0x50]
    3684:      	add	x0, sp, #0x18
    3688:      	ldp	x9, x10, [x8, #0x20]
    368c:      	mov	w1, #0x39               // =57
    3690:      	stp	x9, x10, [sp, #0x38]
    3694:      	ldr	x9, [x8, #0x30]
    3698:      	str	x9, [sp, #0x48]
    369c:      	ldp	x9, x10, [x8]
    36a0:      	stp	x9, x10, [sp, #0x18]
    36a4:      	ldp	x8, x9, [x8, #0x10]
    36a8:      	add	x10, sp, #0x18
    36ac:      	stp	x8, x9, [sp, #0x28]
    36b0:      	mov	w8, #0x39               // =57
    36b4:      	mov	w9, #0x6                // =6
    36b8:      	ldr	x8, [sp, #0x68]
    36bc:      	ldrb	w10, [x24, #0x15]
    36c0:      	add	x2, x8, x10
    36c4:      	blr	x9
    36c8:      	mov	w25, #0x27              // =39
    36cc:      	b	0x2098 <kprobe_unwind_php+0x2098>
    36d0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    36d4:      	add	x8, x8, #0x0
    36d8:      	strb	wzr, [sp, #0x48]
    36dc:      	add	x0, sp, #0x18
    36e0:      	ldp	x9, x10, [x8, #0x10]
    36e4:      	mov	w1, #0x31               // =49
    36e8:      	stp	x9, x10, [sp, #0x28]
    36ec:      	ldp	x9, x10, [x8, #0x20]
    36f0:      	stp	x9, x10, [sp, #0x38]
    36f4:      	ldp	x9, x8, [x8]
    36f8:      	add	x10, sp, #0x18
    36fc:      	stp	x9, x8, [sp, #0x18]
    3700:      	mov	w8, #0x31               // =49
    3704:      	mov	w9, #0x6                // =6
    3708:      	ldr	x2, [sp, #0x70]
    370c:      	blr	x9
    3710:      	b	0x296c <kprobe_unwind_php+0x296c>
    3714:      	ldr	x8, [sp, #0x68]
    3718:      	ldrb	w9, [x24, #0x15]
    371c:      	mov	w10, #0x70              // =112
    3720:      	add	x11, sp, #0x88
    3724:      	add	x0, sp, #0x88
    3728:      	mov	w1, #0x4                // =4
    372c:      	add	x8, x8, x9
    3730:      	mov	w9, #0x4                // =4
    3734:      	ldr	x8, [sp, #0x68]
    3738:      	ldrb	w9, [x24, #0x15]
    373c:      	add	x2, x8, x9
    3740:      	blr	x10
    3744:      	cbz	x0, 0x38e4 <kprobe_unwind_php+0x38e4>
    3748:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    374c:      	ldr	x8, [x8]
    3750:      	ldr	w8, [x8]
    3754:      	cbnz	w8, 0x3df8 <kprobe_unwind_php+0x3df8>
    3758:      	mov	w25, #0x27              // =39
    375c:      	b	0x2ed4 <kprobe_unwind_php+0x2ed4>
    3760:      	ldr	x8, [sp, #0x70]
    3764:      	cbz	x8, 0x3968 <kprobe_unwind_php+0x3968>
    3768:      	ldrb	w9, [x24, #0x14]
    376c:      	mov	w10, #0x70              // =112
    3770:      	add	x11, sp, #0x8c
    3774:      	add	x0, sp, #0x8c
    3778:      	mov	w1, #0x1                // =1
    377c:      	add	x8, x8, x9
    3780:      	mov	w9, #0x1                // =1
    3784:      	ldr	x8, [sp, #0x70]
    3788:      	ldrb	w9, [x24, #0x14]
    378c:      	add	x2, x8, x9
    3790:      	blr	x10
    3794:      	cbz	x0, 0x3a40 <kprobe_unwind_php+0x3a40>
    3798:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    379c:      	ldr	x8, [x8]
    37a0:      	ldr	w8, [x8]
    37a4:      	cbz	w8, 0x37e8 <kprobe_unwind_php+0x37e8>
    37a8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    37ac:      	add	x8, x8, #0x0
    37b0:      	strb	wzr, [sp, #0x48]
    37b4:      	add	x0, sp, #0x18
    37b8:      	ldp	x9, x10, [x8, #0x10]
    37bc:      	mov	w1, #0x31               // =49
    37c0:      	stp	x9, x10, [sp, #0x28]
    37c4:      	ldp	x9, x10, [x8, #0x20]
    37c8:      	stp	x9, x10, [sp, #0x38]
    37cc:      	ldp	x9, x8, [x8]
    37d0:      	add	x10, sp, #0x18
    37d4:      	stp	x9, x8, [sp, #0x18]
    37d8:      	mov	w8, #0x31               // =49
    37dc:      	mov	w9, #0x6                // =6
    37e0:      	ldr	x2, [sp, #0x70]
    37e4:      	blr	x9
    37e8:      	mov	w25, #0x26              // =38
    37ec:      	b	0x3394 <kprobe_unwind_php+0x3394>
    37f0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    37f4:      	ldr	x8, [x8]
    37f8:      	ldr	w8, [x8]
    37fc:      	cbnz	w8, 0x3e50 <kprobe_unwind_php+0x3e50>
    3800:      	cmp	w25, #0x23
    3804:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    3808:      	ldr	x8, [sp, #0x60]
    380c:      	ldrb	w9, [x24, #0x12]
    3810:      	mov	w10, #0x70              // =112
    3814:      	add	x11, sp, #0x60
    3818:      	add	x0, sp, #0x60
    381c:      	mov	w1, #0x8                // =8
    3820:      	add	x8, x8, x9
    3824:      	mov	w9, #0x8                // =8
    3828:      	ldr	x8, [sp, #0x60]
    382c:      	ldrb	w9, [x24, #0x12]
    3830:      	add	x2, x8, x9
    3834:      	blr	x10
    3838:      	adrp	x29, 0x3000 <kprobe_unwind_php+0x3000>
    383c:      	ldr	x29, [x29]
    3840:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    3844:      	ldr	x25, [sp, #0x60]
    3848:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    384c:      	ldrb	w8, [sp, #0x5e]
    3850:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    3854:      	ldrb	w8, [x24, #0x10]
    3858:      	mov	w9, #0x8                // =8
    385c:      	mov	w10, #0x70              // =112
    3860:      	add	x11, sp, #0x70
    3864:      	add	x0, sp, #0x70
    3868:      	mov	w1, #0x8                // =8
    386c:      	add	x8, x25, x8
    3870:      	ldrb	w8, [x24, #0x10]
    3874:      	add	x2, x25, x8
    3878:      	blr	x10
    387c:      	cbz	x0, 0x3ea0 <kprobe_unwind_php+0x3ea0>
    3880:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3884:      	ldr	x8, [x8]
    3888:      	ldr	w8, [x8]
    388c:      	cbz	w8, 0x42f0 <kprobe_unwind_php+0x42f0>
    3890:      	mov	w8, #0x2978             // =10616
    3894:      	add	x0, sp, #0x18
    3898:      	mov	w1, #0x33               // =51
    389c:      	movk	w8, #0xa, lsl #16
    38a0:      	stur	w8, [sp, #0x47]
    38a4:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    38a8:      	add	x8, x8, #0x0
    38ac:      	ldp	x9, x10, [x8, #0x10]
    38b0:      	stp	x9, x10, [sp, #0x28]
    38b4:      	ldp	x9, x10, [x8, #0x20]
    38b8:      	stp	x9, x10, [sp, #0x38]
    38bc:      	ldp	x9, x8, [x8]
    38c0:      	add	x10, sp, #0x18
    38c4:      	stp	x9, x8, [sp, #0x18]
    38c8:      	mov	w8, #0x33               // =51
    38cc:      	mov	w9, #0x6                // =6
    38d0:      	ldrb	w8, [x24, #0x10]
    38d4:      	add	x2, x25, x8
    38d8:      	blr	x9
    38dc:      	mov	w25, #0x25              // =37
    38e0:      	b	0x43e8 <kprobe_unwind_php+0x43e8>
    38e4:      	ldrb	w8, [x24, #0x13]
    38e8:      	mov	w9, #0x4                // =4
    38ec:      	mov	w10, #0x70              // =112
    38f0:      	add	x11, sp, #0x5c
    38f4:      	add	x0, sp, #0x5c
    38f8:      	mov	w1, #0x4                // =4
    38fc:      	add	x8, x25, x8
    3900:      	ldrb	w8, [x24, #0x13]
    3904:      	add	x2, x25, x8
    3908:      	blr	x10
    390c:      	cbz	x0, 0x3b30 <kprobe_unwind_php+0x3b30>
    3910:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3914:      	ldr	x8, [x8]
    3918:      	ldr	w8, [x8]
    391c:      	cbz	w8, 0x2ed0 <kprobe_unwind_php+0x2ed0>
    3920:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3924:      	add	x8, x8, #0x0
    3928:      	add	x0, sp, #0x18
    392c:      	ldp	x9, x10, [x8, #0x20]
    3930:      	mov	w1, #0x35               // =53
    3934:      	mov	x2, x25
    3938:      	stp	x9, x10, [sp, #0x38]
    393c:      	ldur	x9, [x8, #0x2d]
    3940:      	stur	x9, [sp, #0x45]
    3944:      	ldp	x9, x10, [x8]
    3948:      	stp	x9, x10, [sp, #0x18]
    394c:      	ldp	x8, x9, [x8, #0x10]
    3950:      	add	x10, sp, #0x18
    3954:      	stp	x8, x9, [sp, #0x28]
    3958:      	mov	w8, #0x35               // =53
    395c:      	mov	w9, #0x6                // =6
    3960:      	blr	x9
    3964:      	b	0x2ed0 <kprobe_unwind_php+0x2ed0>
    3968:      	ldr	w8, [x21, #0x2c0]
    396c:      	adrp	x29, 0x3000 <kprobe_unwind_php+0x3000>
    3970:      	ldr	x29, [x29]
    3974:      	cmp	w8, #0x7e
    3978:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    397c:      	add	w9, w8, #0x1
    3980:      	mov	x10, #-0x2              // =-2
    3984:      	str	w9, [x21, #0x2c0]
    3988:      	mov	w9, #0x18               // =24
    398c:      	umaddl	x8, w8, w9, x21
    3990:      	add	x9, x8, #0x2d0
    3994:      	str	x10, [x8, #0x2d8]
    3998:      	mov	w10, #0x2               // =2
    399c:      	str	xzr, [x8, #0x2d0]
    39a0:      	strb	w10, [x8, #0x2e0]
    39a4:      	b	0x4260 <kprobe_unwind_php+0x4260>
    39a8:      	mov	w8, #0x2978             // =10616
    39ac:      	add	x0, sp, #0x18
    39b0:      	mov	w1, #0x33               // =51
    39b4:      	movk	w8, #0xa, lsl #16
    39b8:      	stur	w8, [sp, #0x47]
    39bc:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    39c0:      	add	x8, x8, #0x0
    39c4:      	ldp	x9, x10, [x8, #0x10]
    39c8:      	stp	x9, x10, [sp, #0x28]
    39cc:      	ldp	x9, x10, [x8, #0x20]
    39d0:      	stp	x9, x10, [sp, #0x38]
    39d4:      	ldp	x9, x8, [x8]
    39d8:      	add	x10, sp, #0x18
    39dc:      	stp	x9, x8, [sp, #0x18]
    39e0:      	mov	w8, #0x33               // =51
    39e4:      	mov	w9, #0x6                // =6
    39e8:      	ldrb	w8, [x24, #0x10]
    39ec:      	add	x2, x25, x8
    39f0:      	blr	x9
    39f4:      	b	0x2a14 <kprobe_unwind_php+0x2a14>
    39f8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    39fc:      	add	x8, x8, #0x0
    3a00:      	add	x0, sp, #0x18
    3a04:      	ldp	x9, x10, [x8]
    3a08:      	ldur	x8, [x8, #0xe]
    3a0c:      	mov	w1, #0x16               // =22
    3a10:      	stp	x9, x10, [sp, #0x18]
    3a14:      	stur	x8, [sp, #0x26]
    3a18:      	mov	w8, #0x16               // =22
    3a1c:      	mov	w9, #0x6                // =6
    3a20:      	add	x10, sp, #0x18
    3a24:      	ldr	x2, [sp, #0x70]
    3a28:      	ldr	w3, [sp, #0x88]
    3a2c:      	blr	x9
    3a30:      	ldr	w8, [x21, #0x2c0]
    3a34:      	cmp	w8, #0x7e
    3a38:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    3a3c:      	b	0x3184 <kprobe_unwind_php+0x3184>
    3a40:      	ldrb	w8, [sp, #0x8c]
    3a44:      	str	wzr, [sp, #0x88]
    3a48:      	cmp	w8, #0x4
    3a4c:      	b.eq	0x3a5c <kprobe_unwind_php+0x3a5c>
    3a50:      	mov	w29, wzr
    3a54:      	cmp	w8, #0x2
    3a58:      	b.ne	0x41d8 <kprobe_unwind_php+0x41d8>
    3a5c:      	ldrb	w8, [x24, #0x11]
    3a60:      	mov	w9, #0x8                // =8
    3a64:      	mov	w10, #0x70              // =112
    3a68:      	add	x11, sp, #0x68
    3a6c:      	add	x0, sp, #0x68
    3a70:      	mov	w1, #0x8                // =8
    3a74:      	add	x8, x25, x8
    3a78:      	ldrb	w8, [x24, #0x11]
    3a7c:      	add	x2, x25, x8
    3a80:      	blr	x10
    3a84:      	cbz	x0, 0x3f30 <kprobe_unwind_php+0x3f30>
    3a88:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3a8c:      	ldr	x8, [x8]
    3a90:      	ldr	w8, [x8]
    3a94:      	cbz	w8, 0x3390 <kprobe_unwind_php+0x3390>
    3a98:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3a9c:      	add	x8, x8, #0x0
    3aa0:      	add	x0, sp, #0x18
    3aa4:      	ldp	x9, x10, [x8, #0x10]
    3aa8:      	mov	w1, #0x2d               // =45
    3aac:      	stp	x9, x10, [sp, #0x28]
    3ab0:      	ldr	x9, [x8, #0x20]
    3ab4:      	add	x10, sp, #0x18
    3ab8:      	str	x9, [sp, #0x38]
    3abc:      	ldur	x9, [x8, #0x25]
    3ac0:      	stur	x9, [sp, #0x3d]
    3ac4:      	ldp	x9, x8, [x8]
    3ac8:      	stp	x9, x8, [sp, #0x18]
    3acc:      	mov	w8, #0x2d               // =45
    3ad0:      	mov	w9, #0x6                // =6
    3ad4:      	ldrb	w8, [x24, #0x11]
    3ad8:      	add	x2, x25, x8
    3adc:      	b	0x4128 <kprobe_unwind_php+0x4128>
    3ae0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3ae4:      	add	x8, x8, #0x0
    3ae8:      	add	x0, sp, #0x18
    3aec:      	ldp	x9, x10, [x8, #0x10]
    3af0:      	mov	w1, #0x2e               // =46
    3af4:      	stp	x9, x10, [sp, #0x28]
    3af8:      	ldr	x9, [x8, #0x20]
    3afc:      	add	x10, sp, #0x18
    3b00:      	str	x9, [sp, #0x38]
    3b04:      	ldur	x9, [x8, #0x26]
    3b08:      	stur	x9, [sp, #0x3e]
    3b0c:      	ldp	x9, x8, [x8]
    3b10:      	stp	x9, x8, [sp, #0x18]
    3b14:      	mov	w8, #0x2e               // =46
    3b18:      	mov	w9, #0x6                // =6
    3b1c:      	ldr	w2, [sp, #0x70]
    3b20:      	blr	x9
    3b24:      	cmp	w25, #0x23
    3b28:      	b.eq	0x2e48 <kprobe_unwind_php+0x2e48>
    3b2c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    3b30:      	ldr	w29, [sp, #0x88]
    3b34:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3b38:      	ldr	w25, [sp, #0x5c]
    3b3c:      	ldr	x8, [x8]
    3b40:      	ldr	w8, [x8]
    3b44:      	cbnz	w8, 0x3f7c <kprobe_unwind_php+0x3f7c>
    3b48:      	ldr	w8, [x21, #0x2c0]
    3b4c:      	cmp	w8, #0x7e
    3b50:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    3b54:      	add	w9, w8, #0x1
    3b58:      	mov	w10, w29
    3b5c:      	str	w9, [x21, #0x2c0]
    3b60:      	mov	w9, #0x18               // =24
    3b64:      	orr	x10, x10, x25, lsl #32
    3b68:      	umaddl	x8, w8, w9, x21
    3b6c:      	ldr	x9, [sp, #0x70]
    3b70:      	str	x10, [x8, #0x2d8]
    3b74:      	str	x9, [x8, #0x2d0]
    3b78:      	ldr	w9, [sp, #0xc]
    3b7c:      	strb	w9, [x8, #0x2e0]
    3b80:      	add	x9, x8, #0x2d0
    3b84:      	b	0x3488 <kprobe_unwind_php+0x3488>
    3b88:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3b8c:      	add	x8, x8, #0x0
    3b90:      	strb	wzr, [sp, #0x50]
    3b94:      	add	x0, sp, #0x18
    3b98:      	ldp	x9, x10, [x8, #0x20]
    3b9c:      	mov	w1, #0x39               // =57
    3ba0:      	stp	x9, x10, [sp, #0x38]
    3ba4:      	ldr	x9, [x8, #0x30]
    3ba8:      	str	x9, [sp, #0x48]
    3bac:      	ldp	x9, x10, [x8]
    3bb0:      	stp	x9, x10, [sp, #0x18]
    3bb4:      	ldp	x8, x9, [x8, #0x10]
    3bb8:      	add	x10, sp, #0x18
    3bbc:      	stp	x8, x9, [sp, #0x28]
    3bc0:      	mov	w8, #0x39               // =57
    3bc4:      	mov	w9, #0x6                // =6
    3bc8:      	ldr	x8, [sp, #0x68]
    3bcc:      	ldrb	w10, [x24, #0x15]
    3bd0:      	add	x2, x8, x10
    3bd4:      	blr	x9
    3bd8:      	mov	w25, #0x27              // =39
    3bdc:      	b	0x2558 <kprobe_unwind_php+0x2558>
    3be0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3be4:      	add	x8, x8, #0x0
    3be8:      	strb	wzr, [sp, #0x48]
    3bec:      	add	x0, sp, #0x18
    3bf0:      	ldp	x9, x10, [x8, #0x10]
    3bf4:      	mov	w1, #0x31               // =49
    3bf8:      	stp	x9, x10, [sp, #0x28]
    3bfc:      	ldp	x9, x10, [x8, #0x20]
    3c00:      	stp	x9, x10, [sp, #0x38]
    3c04:      	ldp	x9, x8, [x8]
    3c08:      	add	x10, sp, #0x18
    3c0c:      	stp	x9, x8, [sp, #0x18]
    3c10:      	mov	w8, #0x31               // =49
    3c14:      	mov	w9, #0x6                // =6
    3c18:      	ldr	x2, [sp, #0x70]
    3c1c:      	blr	x9
    3c20:      	b	0x2e28 <kprobe_unwind_php+0x2e28>
    3c24:      	mov	w8, #0x2978             // =10616
    3c28:      	add	x0, sp, #0x18
    3c2c:      	mov	w1, #0x33               // =51
    3c30:      	movk	w8, #0xa, lsl #16
    3c34:      	stur	w8, [sp, #0x47]
    3c38:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3c3c:      	add	x8, x8, #0x0
    3c40:      	ldp	x9, x10, [x8, #0x10]
    3c44:      	stp	x9, x10, [sp, #0x28]
    3c48:      	ldp	x9, x10, [x8, #0x20]
    3c4c:      	stp	x9, x10, [sp, #0x38]
    3c50:      	ldp	x9, x8, [x8]
    3c54:      	add	x10, sp, #0x18
    3c58:      	stp	x9, x8, [sp, #0x18]
    3c5c:      	mov	w8, #0x33               // =51
    3c60:      	mov	w9, #0x6                // =6
    3c64:      	ldrb	w8, [x24, #0x10]
    3c68:      	add	x2, x25, x8
    3c6c:      	blr	x9
    3c70:      	b	0x2ed0 <kprobe_unwind_php+0x2ed0>
    3c74:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3c78:      	add	x8, x8, #0x0
    3c7c:      	strb	wzr, [sp, #0x50]
    3c80:      	add	x0, sp, #0x18
    3c84:      	ldp	x9, x10, [x8, #0x20]
    3c88:      	mov	w1, #0x39               // =57
    3c8c:      	stp	x9, x10, [sp, #0x38]
    3c90:      	ldr	x9, [x8, #0x30]
    3c94:      	str	x9, [sp, #0x48]
    3c98:      	ldp	x9, x10, [x8]
    3c9c:      	stp	x9, x10, [sp, #0x18]
    3ca0:      	ldp	x8, x9, [x8, #0x10]
    3ca4:      	add	x10, sp, #0x18
    3ca8:      	stp	x8, x9, [sp, #0x28]
    3cac:      	mov	w8, #0x39               // =57
    3cb0:      	mov	w9, #0x6                // =6
    3cb4:      	ldr	x8, [sp, #0x68]
    3cb8:      	ldrb	w10, [x24, #0x15]
    3cbc:      	add	x2, x8, x10
    3cc0:      	blr	x9
    3cc4:      	mov	w25, #0x27              // =39
    3cc8:      	b	0x2a18 <kprobe_unwind_php+0x2a18>
    3ccc:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3cd0:      	add	x8, x8, #0x0
    3cd4:      	strb	wzr, [sp, #0x48]
    3cd8:      	add	x0, sp, #0x18
    3cdc:      	ldp	x9, x10, [x8, #0x10]
    3ce0:      	mov	w1, #0x31               // =49
    3ce4:      	stp	x9, x10, [sp, #0x28]
    3ce8:      	ldp	x9, x10, [x8, #0x20]
    3cec:      	stp	x9, x10, [sp, #0x38]
    3cf0:      	ldp	x9, x8, [x8]
    3cf4:      	add	x10, sp, #0x18
    3cf8:      	stp	x9, x8, [sp, #0x18]
    3cfc:      	mov	w8, #0x31               // =49
    3d00:      	mov	w9, #0x6                // =6
    3d04:      	ldr	x2, [sp, #0x70]
    3d08:      	blr	x9
    3d0c:      	b	0x32e8 <kprobe_unwind_php+0x32e8>
    3d10:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3d14:      	add	x8, x8, #0x0
    3d18:      	add	x0, sp, #0x18
    3d1c:      	ldp	x9, x10, [x8, #0x10]
    3d20:      	mov	w1, #0x2e               // =46
    3d24:      	stp	x9, x10, [sp, #0x28]
    3d28:      	ldr	x9, [x8, #0x20]
    3d2c:      	add	x10, sp, #0x18
    3d30:      	str	x9, [sp, #0x38]
    3d34:      	ldur	x9, [x8, #0x26]
    3d38:      	stur	x9, [sp, #0x3e]
    3d3c:      	ldp	x9, x8, [x8]
    3d40:      	stp	x9, x8, [sp, #0x18]
    3d44:      	mov	w8, #0x2e               // =46
    3d48:      	mov	w9, #0x6                // =6
    3d4c:      	ldr	w2, [sp, #0x70]
    3d50:      	blr	x9
    3d54:      	cmp	w25, #0x23
    3d58:      	b.eq	0x3308 <kprobe_unwind_php+0x3308>
    3d5c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    3d60:      	mov	w8, #0x2978             // =10616
    3d64:      	add	x0, sp, #0x18
    3d68:      	mov	w1, #0x33               // =51
    3d6c:      	movk	w8, #0xa, lsl #16
    3d70:      	stur	w8, [sp, #0x47]
    3d74:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3d78:      	add	x8, x8, #0x0
    3d7c:      	ldp	x9, x10, [x8, #0x10]
    3d80:      	stp	x9, x10, [sp, #0x28]
    3d84:      	ldp	x9, x10, [x8, #0x20]
    3d88:      	stp	x9, x10, [sp, #0x38]
    3d8c:      	ldp	x9, x8, [x8]
    3d90:      	add	x10, sp, #0x18
    3d94:      	stp	x9, x8, [sp, #0x18]
    3d98:      	mov	w8, #0x33               // =51
    3d9c:      	mov	w9, #0x6                // =6
    3da0:      	ldrb	w8, [x24, #0x10]
    3da4:      	add	x2, x25, x8
    3da8:      	blr	x9
    3dac:      	b	0x3390 <kprobe_unwind_php+0x3390>
    3db0:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3db4:      	add	x8, x8, #0x0
    3db8:      	add	x0, sp, #0x18
    3dbc:      	ldp	x9, x10, [x8]
    3dc0:      	ldur	x8, [x8, #0xe]
    3dc4:      	mov	w1, #0x16               // =22
    3dc8:      	stp	x9, x10, [sp, #0x18]
    3dcc:      	stur	x8, [sp, #0x26]
    3dd0:      	mov	w8, #0x16               // =22
    3dd4:      	mov	w9, #0x6                // =6
    3dd8:      	add	x10, sp, #0x18
    3ddc:      	ldr	x2, [sp, #0x70]
    3de0:      	ldr	w3, [sp, #0x88]
    3de4:      	blr	x9
    3de8:      	ldr	w8, [x21, #0x2c0]
    3dec:      	cmp	w8, #0x7e
    3df0:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    3df4:      	b	0x3644 <kprobe_unwind_php+0x3644>
    3df8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3dfc:      	add	x8, x8, #0x0
    3e00:      	strb	wzr, [sp, #0x50]
    3e04:      	add	x0, sp, #0x18
    3e08:      	ldp	x9, x10, [x8, #0x20]
    3e0c:      	mov	w1, #0x39               // =57
    3e10:      	stp	x9, x10, [sp, #0x38]
    3e14:      	ldr	x9, [x8, #0x30]
    3e18:      	str	x9, [sp, #0x48]
    3e1c:      	ldp	x9, x10, [x8]
    3e20:      	stp	x9, x10, [sp, #0x18]
    3e24:      	ldp	x8, x9, [x8, #0x10]
    3e28:      	add	x10, sp, #0x18
    3e2c:      	stp	x8, x9, [sp, #0x28]
    3e30:      	mov	w8, #0x39               // =57
    3e34:      	mov	w9, #0x6                // =6
    3e38:      	ldr	x8, [sp, #0x68]
    3e3c:      	ldrb	w10, [x24, #0x15]
    3e40:      	add	x2, x8, x10
    3e44:      	blr	x9
    3e48:      	mov	w25, #0x27              // =39
    3e4c:      	b	0x2ed4 <kprobe_unwind_php+0x2ed4>
    3e50:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3e54:      	add	x8, x8, #0x0
    3e58:      	add	x0, sp, #0x18
    3e5c:      	ldp	x9, x10, [x8, #0x10]
    3e60:      	mov	w1, #0x2e               // =46
    3e64:      	stp	x9, x10, [sp, #0x28]
    3e68:      	ldr	x9, [x8, #0x20]
    3e6c:      	add	x10, sp, #0x18
    3e70:      	str	x9, [sp, #0x38]
    3e74:      	ldur	x9, [x8, #0x26]
    3e78:      	stur	x9, [sp, #0x3e]
    3e7c:      	ldp	x9, x8, [x8]
    3e80:      	stp	x9, x8, [sp, #0x18]
    3e84:      	mov	w8, #0x2e               // =46
    3e88:      	mov	w9, #0x6                // =6
    3e8c:      	ldr	w2, [sp, #0x70]
    3e90:      	blr	x9
    3e94:      	cmp	w25, #0x23
    3e98:      	b.eq	0x3808 <kprobe_unwind_php+0x3808>
    3e9c:      	b	0x61f4 <kprobe_unwind_php+0x61f4>
    3ea0:      	ldr	x8, [sp, #0x70]
    3ea4:      	cbz	x8, 0x3fc4 <kprobe_unwind_php+0x3fc4>
    3ea8:      	ldrb	w9, [x24, #0x14]
    3eac:      	mov	w10, #0x70              // =112
    3eb0:      	add	x11, sp, #0x8c
    3eb4:      	add	x0, sp, #0x8c
    3eb8:      	mov	w1, #0x1                // =1
    3ebc:      	add	x8, x8, x9
    3ec0:      	mov	w9, #0x1                // =1
    3ec4:      	ldr	x8, [sp, #0x70]
    3ec8:      	ldrb	w9, [x24, #0x14]
    3ecc:      	add	x2, x8, x9
    3ed0:      	blr	x10
    3ed4:      	cbz	x0, 0x4004 <kprobe_unwind_php+0x4004>
    3ed8:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3edc:      	ldr	x8, [x8]
    3ee0:      	ldr	w8, [x8]
    3ee4:      	cbz	w8, 0x3f28 <kprobe_unwind_php+0x3f28>
    3ee8:      	adrp	x10, 0x3000 <kprobe_unwind_php+0x3000>
    3eec:      	add	x10, x10, #0x0
    3ef0:      	strb	wzr, [sp, #0x48]
    3ef4:      	add	x0, sp, #0x18
    3ef8:      	ldp	x8, x9, [x10, #0x10]
    3efc:      	mov	w1, #0x31               // =49
    3f00:      	stp	x8, x9, [sp, #0x28]
    3f04:      	ldp	x8, x9, [x10, #0x20]
    3f08:      	stp	x8, x9, [sp, #0x38]
    3f0c:      	ldp	x8, x9, [x10]
    3f10:      	add	x10, sp, #0x18
    3f14:      	stp	x8, x9, [sp, #0x18]
    3f18:      	mov	w8, #0x31               // =49
    3f1c:      	mov	w9, #0x6                // =6
    3f20:      	ldr	x2, [sp, #0x70]
    3f24:      	blr	x9
    3f28:      	mov	w25, #0x26              // =38
    3f2c:      	b	0x43e8 <kprobe_unwind_php+0x43e8>
    3f30:      	ldr	x8, [sp, #0x68]
    3f34:      	ldrb	w9, [x24, #0x15]
    3f38:      	mov	w10, #0x70              // =112
    3f3c:      	add	x11, sp, #0x88
    3f40:      	add	x0, sp, #0x88
    3f44:      	mov	w1, #0x4                // =4
    3f48:      	add	x8, x8, x9
    3f4c:      	mov	w9, #0x4                // =4
    3f50:      	ldr	x8, [sp, #0x68]
    3f54:      	ldrb	w9, [x24, #0x15]
    3f58:      	add	x2, x8, x9
    3f5c:      	blr	x10
    3f60:      	cbz	x0, 0x40ac <kprobe_unwind_php+0x40ac>
    3f64:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3f68:      	ldr	x8, [x8]
    3f6c:      	ldr	w8, [x8]
    3f70:      	cbnz	w8, 0x4130 <kprobe_unwind_php+0x4130>
    3f74:      	mov	w25, #0x27              // =39
    3f78:      	b	0x3394 <kprobe_unwind_php+0x3394>
    3f7c:      	adrp	x8, 0x3000 <kprobe_unwind_php+0x3000>
    3f80:      	add	x8, x8, #0x0
    3f84:      	add	x0, sp, #0x18
    3f88:      	ldp	x9, x10, [x8]
    3f8c:      	ldur	x8, [x8, #0xe]
    3f90:      	mov	w1, #0x16               // =22
    3f94:      	stp	x9, x10, [sp, #0x18]
    3f98:      	stur	x8, [sp, #0x26]
    3f9c:      	mov	w8, #0x16               // =22
    3fa0:      	mov	w9, #0x6                // =6
    3fa4:      	add	x10, sp, #0x18
    3fa8:      	ldr	x2, [sp, #0x70]
    3fac:      	ldr	w3, [sp, #0x88]
    3fb0:      	blr	x9
    3fb4:      	ldr	w8, [x21, #0x2c0]
    3fb8:      	cmp	w8, #0x7e
    3fbc:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    3fc0:      	b	0x3b54 <kprobe_unwind_php+0x3b54>
    3fc4:      	ldr	w8, [x21, #0x2c0]
    3fc8:      	adrp	x29, 0x3000 <kprobe_unwind_php+0x3000>
    3fcc:      	ldr	x29, [x29]
    3fd0:      	cmp	w8, #0x7e
    3fd4:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    3fd8:      	add	w9, w8, #0x1
    3fdc:      	mov	x10, #-0x2              // =-2
    3fe0:      	str	w9, [x21, #0x2c0]
    3fe4:      	mov	w9, #0x18               // =24
    3fe8:      	umaddl	x8, w8, w9, x21
    3fec:      	add	x9, x8, #0x2d0
    3ff0:      	str	x10, [x8, #0x2d8]
    3ff4:      	mov	w10, #0x2               // =2
    3ff8:      	str	xzr, [x8, #0x2d0]
    3ffc:      	strb	w10, [x8, #0x2e0]
    4000:      	b	0x43dc <kprobe_unwind_php+0x43dc>
    4004:      	ldrb	w8, [sp, #0x8c]
    4008:      	str	wzr, [sp, #0x88]
    400c:      	cmp	w8, #0x4
    4010:      	b.eq	0x4020 <kprobe_unwind_php+0x4020>
    4014:      	mov	w29, wzr
    4018:      	cmp	w8, #0x2
    401c:      	b.ne	0x4354 <kprobe_unwind_php+0x4354>
    4020:      	ldrb	w8, [x24, #0x11]
    4024:      	mov	w9, #0x8                // =8
    4028:      	mov	w10, #0x70              // =112
    402c:      	add	x11, sp, #0x68
    4030:      	add	x0, sp, #0x68
    4034:      	mov	w1, #0x8                // =8
    4038:      	add	x8, x25, x8
    403c:      	ldrb	w8, [x24, #0x11]
    4040:      	add	x2, x25, x8
    4044:      	blr	x10
    4048:      	cbz	x0, 0x4188 <kprobe_unwind_php+0x4188>
    404c:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4050:      	ldr	x8, [x8]
    4054:      	ldr	w8, [x8]
    4058:      	cbz	w8, 0x42f0 <kprobe_unwind_php+0x42f0>
    405c:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4060:      	add	x10, x10, #0x0
    4064:      	add	x0, sp, #0x18
    4068:      	ldp	x8, x9, [x10, #0x10]
    406c:      	mov	w1, #0x2d               // =45
    4070:      	stp	x8, x9, [sp, #0x28]
    4074:      	ldr	x8, [x10, #0x20]
    4078:      	str	x8, [sp, #0x38]
    407c:      	ldur	x8, [x10, #0x25]
    4080:      	stur	x8, [sp, #0x3d]
    4084:      	ldp	x8, x9, [x10]
    4088:      	add	x10, sp, #0x18
    408c:      	stp	x8, x9, [sp, #0x18]
    4090:      	mov	w8, #0x2d               // =45
    4094:      	mov	w9, #0x6                // =6
    4098:      	ldrb	w8, [x24, #0x11]
    409c:      	add	x2, x25, x8
    40a0:      	blr	x9
    40a4:      	mov	w25, #0x25              // =37
    40a8:      	b	0x43e8 <kprobe_unwind_php+0x43e8>
    40ac:      	ldrb	w8, [x24, #0x13]
    40b0:      	mov	w9, #0x4                // =4
    40b4:      	mov	w10, #0x70              // =112
    40b8:      	add	x11, sp, #0x5c
    40bc:      	add	x0, sp, #0x5c
    40c0:      	mov	w1, #0x4                // =4
    40c4:      	add	x8, x25, x8
    40c8:      	ldrb	w8, [x24, #0x13]
    40cc:      	add	x2, x25, x8
    40d0:      	blr	x10
    40d4:      	cbz	x0, 0x41d4 <kprobe_unwind_php+0x41d4>
    40d8:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    40dc:      	ldr	x8, [x8]
    40e0:      	ldr	w8, [x8]
    40e4:      	cbz	w8, 0x3390 <kprobe_unwind_php+0x3390>
    40e8:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    40ec:      	add	x8, x8, #0x0
    40f0:      	add	x0, sp, #0x18
    40f4:      	ldp	x9, x10, [x8, #0x20]
    40f8:      	mov	w1, #0x35               // =53
    40fc:      	mov	x2, x25
    4100:      	stp	x9, x10, [sp, #0x38]
    4104:      	ldur	x9, [x8, #0x2d]
    4108:      	stur	x9, [sp, #0x45]
    410c:      	ldp	x9, x10, [x8]
    4110:      	stp	x9, x10, [sp, #0x18]
    4114:      	ldp	x8, x9, [x8, #0x10]
    4118:      	add	x10, sp, #0x18
    411c:      	stp	x8, x9, [sp, #0x28]
    4120:      	mov	w8, #0x35               // =53
    4124:      	mov	w9, #0x6                // =6
    4128:      	blr	x9
    412c:      	b	0x3390 <kprobe_unwind_php+0x3390>
    4130:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4134:      	add	x8, x8, #0x0
    4138:      	strb	wzr, [sp, #0x50]
    413c:      	add	x0, sp, #0x18
    4140:      	ldp	x9, x10, [x8, #0x20]
    4144:      	mov	w1, #0x39               // =57
    4148:      	stp	x9, x10, [sp, #0x38]
    414c:      	ldr	x9, [x8, #0x30]
    4150:      	str	x9, [sp, #0x48]
    4154:      	ldp	x9, x10, [x8]
    4158:      	stp	x9, x10, [sp, #0x18]
    415c:      	ldp	x8, x9, [x8, #0x10]
    4160:      	add	x10, sp, #0x18
    4164:      	stp	x8, x9, [sp, #0x28]
    4168:      	mov	w8, #0x39               // =57
    416c:      	mov	w9, #0x6                // =6
    4170:      	ldr	x8, [sp, #0x68]
    4174:      	ldrb	w10, [x24, #0x15]
    4178:      	add	x2, x8, x10
    417c:      	blr	x9
    4180:      	mov	w25, #0x27              // =39
    4184:      	b	0x3394 <kprobe_unwind_php+0x3394>
    4188:      	ldr	x8, [sp, #0x68]
    418c:      	ldrb	w9, [x24, #0x15]
    4190:      	mov	w10, #0x70              // =112
    4194:      	add	x11, sp, #0x88
    4198:      	add	x0, sp, #0x88
    419c:      	mov	w1, #0x4                // =4
    41a0:      	add	x8, x8, x9
    41a4:      	mov	w9, #0x4                // =4
    41a8:      	ldr	x8, [sp, #0x68]
    41ac:      	ldrb	w9, [x24, #0x15]
    41b0:      	add	x2, x8, x9
    41b4:      	blr	x10
    41b8:      	cbz	x0, 0x4270 <kprobe_unwind_php+0x4270>
    41bc:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    41c0:      	ldr	x8, [x8]
    41c4:      	ldr	w8, [x8]
    41c8:      	cbnz	w8, 0x42f8 <kprobe_unwind_php+0x42f8>
    41cc:      	mov	w25, #0x27              // =39
    41d0:      	b	0x43e8 <kprobe_unwind_php+0x43e8>
    41d4:      	ldr	w29, [sp, #0x88]
    41d8:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    41dc:      	ldr	w25, [sp, #0x5c]
    41e0:      	ldr	x8, [x8]
    41e4:      	ldr	w8, [x8]
    41e8:      	cbz	w8, 0x4224 <kprobe_unwind_php+0x4224>
    41ec:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    41f0:      	add	x8, x8, #0x0
    41f4:      	add	x0, sp, #0x18
    41f8:      	ldp	x9, x10, [x8]
    41fc:      	ldur	x8, [x8, #0xe]
    4200:      	mov	w1, #0x16               // =22
    4204:      	stp	x9, x10, [sp, #0x18]
    4208:      	stur	x8, [sp, #0x26]
    420c:      	mov	w8, #0x16               // =22
    4210:      	mov	w9, #0x6                // =6
    4214:      	add	x10, sp, #0x18
    4218:      	ldr	x2, [sp, #0x70]
    421c:      	ldr	w3, [sp, #0x88]
    4220:      	blr	x9
    4224:      	ldr	w8, [x21, #0x2c0]
    4228:      	cmp	w8, #0x7e
    422c:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    4230:      	add	w9, w8, #0x1
    4234:      	mov	w10, w29
    4238:      	str	w9, [x21, #0x2c0]
    423c:      	mov	w9, #0x18               // =24
    4240:      	orr	x10, x10, x25, lsl #32
    4244:      	umaddl	x8, w8, w9, x21
    4248:      	ldr	x9, [sp, #0x70]
    424c:      	str	x10, [x8, #0x2d8]
    4250:      	str	x9, [x8, #0x2d0]
    4254:      	ldr	w9, [sp, #0xc]
    4258:      	strb	w9, [x8, #0x2e0]
    425c:      	add	x9, x8, #0x2d0
    4260:      	mov	w25, #0x23              // =35
    4264:      	str	wzr, [x8, #0x2e4]
    4268:      	stur	wzr, [x9, #0x11]
    426c:      	b	0x3394 <kprobe_unwind_php+0x3394>
    4270:      	ldrb	w8, [x24, #0x13]
    4274:      	mov	w9, #0x4                // =4
    4278:      	mov	w10, #0x70              // =112
    427c:      	add	x11, sp, #0x5c
    4280:      	add	x0, sp, #0x5c
    4284:      	mov	w1, #0x4                // =4
    4288:      	add	x8, x25, x8
    428c:      	ldrb	w8, [x24, #0x13]
    4290:      	add	x2, x25, x8
    4294:      	blr	x10
    4298:      	cbz	x0, 0x4350 <kprobe_unwind_php+0x4350>
    429c:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    42a0:      	ldr	x8, [x8]
    42a4:      	ldr	w8, [x8]
    42a8:      	cbz	w8, 0x42f0 <kprobe_unwind_php+0x42f0>
    42ac:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    42b0:      	add	x10, x10, #0x0
    42b4:      	mov	w11, #0x6               // =6
    42b8:      	ldp	x8, x9, [x10, #0x20]
    42bc:      	add	x0, sp, #0x18
    42c0:      	mov	w1, #0x35               // =53
    42c4:      	mov	x2, x25
    42c8:      	stp	x8, x9, [sp, #0x38]
    42cc:      	ldur	x8, [x10, #0x2d]
    42d0:      	stur	x8, [sp, #0x45]
    42d4:      	ldp	x8, x9, [x10]
    42d8:      	stp	x8, x9, [sp, #0x18]
    42dc:      	ldp	x9, x8, [x10, #0x10]
    42e0:      	mov	w10, #0x35              // =53
    42e4:      	stp	x9, x8, [sp, #0x28]
    42e8:      	add	x8, sp, #0x18
    42ec:      	blr	x11
    42f0:      	mov	w25, #0x25              // =37
    42f4:      	b	0x43e8 <kprobe_unwind_php+0x43e8>
    42f8:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    42fc:      	add	x10, x10, #0x0
    4300:      	strb	wzr, [sp, #0x50]
    4304:      	add	x0, sp, #0x18
    4308:      	ldp	x8, x9, [x10, #0x20]
    430c:      	mov	w1, #0x39               // =57
    4310:      	stp	x8, x9, [sp, #0x38]
    4314:      	ldr	x8, [x10, #0x30]
    4318:      	str	x8, [sp, #0x48]
    431c:      	ldp	x8, x9, [x10]
    4320:      	stp	x8, x9, [sp, #0x18]
    4324:      	ldp	x9, x8, [x10, #0x10]
    4328:      	add	x10, sp, #0x18
    432c:      	stp	x9, x8, [sp, #0x28]
    4330:      	mov	w8, #0x39               // =57
    4334:      	mov	w9, #0x6                // =6
    4338:      	ldr	x8, [sp, #0x68]
    433c:      	ldrb	w10, [x24, #0x15]
    4340:      	add	x2, x8, x10
    4344:      	blr	x9
    4348:      	mov	w25, #0x27              // =39
    434c:      	b	0x43e8 <kprobe_unwind_php+0x43e8>
    4350:      	ldr	w29, [sp, #0x88]
    4354:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4358:      	ldr	w25, [sp, #0x5c]
    435c:      	ldr	x8, [x8]
    4360:      	ldr	w8, [x8]
    4364:      	cbz	w8, 0x43a0 <kprobe_unwind_php+0x43a0>
    4368:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    436c:      	add	x10, x10, #0x0
    4370:      	add	x0, sp, #0x18
    4374:      	ldp	x8, x9, [x10]
    4378:      	mov	w1, #0x16               // =22
    437c:      	stp	x8, x9, [sp, #0x18]
    4380:      	ldur	x8, [x10, #0xe]
    4384:      	mov	w9, #0x6                // =6
    4388:      	add	x10, sp, #0x18
    438c:      	stur	x8, [sp, #0x26]
    4390:      	mov	w8, #0x16               // =22
    4394:      	ldr	x2, [sp, #0x70]
    4398:      	ldr	w3, [sp, #0x88]
    439c:      	blr	x9
    43a0:      	ldr	w8, [x21, #0x2c0]
    43a4:      	cmp	w8, #0x7e
    43a8:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    43ac:      	add	w9, w8, #0x1
    43b0:      	mov	w10, w29
    43b4:      	str	w9, [x21, #0x2c0]
    43b8:      	mov	w9, #0x18               // =24
    43bc:      	orr	x10, x10, x25, lsl #32
    43c0:      	umaddl	x8, w8, w9, x21
    43c4:      	ldr	x9, [sp, #0x70]
    43c8:      	str	x10, [x8, #0x2d8]
    43cc:      	str	x9, [x8, #0x2d0]
    43d0:      	ldr	w9, [sp, #0xc]
    43d4:      	strb	w9, [x8, #0x2e0]
    43d8:      	add	x9, x8, #0x2d0
    43dc:      	mov	w25, #0x23              // =35
    43e0:      	str	wzr, [x8, #0x2e4]
    43e4:      	stur	wzr, [x9, #0x11]
    43e8:      	str	w25, [sp, #0x70]
    43ec:      	mov	w8, #0x1                // =1
    43f0:      	add	x9, sp, #0x70
    43f4:      	add	x1, sp, #0x70
    43f8:      	mov	x0, x23
    43fc:      	blr	x8
    4400:      	cbz	x0, 0x4414 <kprobe_unwind_php+0x4414>
    4404:      	ldr	x8, [x0]
    4408:      	add	x8, x8, #0x1
    440c:      	str	x8, [x0]
    4410:      	b	0x4468 <kprobe_unwind_php+0x4468>
    4414:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4418:      	ldr	x8, [x8]
    441c:      	ldr	w8, [x8]
    4420:      	cbz	w8, 0x4468 <kprobe_unwind_php+0x4468>
    4424:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4428:      	add	x8, x8, #0x0
    442c:      	add	x0, sp, #0x18
    4430:      	ldp	x9, x10, [x8, #0x10]
    4434:      	mov	w1, #0x2e               // =46
    4438:      	stp	x9, x10, [sp, #0x28]
    443c:      	ldr	x9, [x8, #0x20]
    4440:      	add	x10, sp, #0x18
    4444:      	str	x9, [sp, #0x38]
    4448:      	ldur	x9, [x8, #0x26]
    444c:      	stur	x9, [sp, #0x3e]
    4450:      	ldp	x9, x8, [x8]
    4454:      	stp	x9, x8, [sp, #0x18]
    4458:      	mov	w8, #0x2e               // =46
    445c:      	mov	w9, #0x6                // =6
    4460:      	ldr	w2, [sp, #0x70]
    4464:      	blr	x9
    4468:      	cmp	w25, #0x23
    446c:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    4470:      	ldr	x8, [sp, #0x60]
    4474:      	ldrb	w9, [x24, #0x12]
    4478:      	mov	w10, #0x70              // =112
    447c:      	add	x11, sp, #0x60
    4480:      	add	x0, sp, #0x60
    4484:      	mov	w1, #0x8                // =8
    4488:      	add	x8, x8, x9
    448c:      	mov	w9, #0x8                // =8
    4490:      	ldr	x8, [sp, #0x60]
    4494:      	ldrb	w9, [x24, #0x12]
    4498:      	add	x2, x8, x9
    449c:      	blr	x10
    44a0:      	adrp	x29, 0x4000 <kprobe_unwind_php+0x4000>
    44a4:      	ldr	x29, [x29]
    44a8:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    44ac:      	ldr	x25, [sp, #0x60]
    44b0:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    44b4:      	ldrb	w8, [sp, #0x5e]
    44b8:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    44bc:      	ldrb	w8, [x24, #0x10]
    44c0:      	mov	w9, #0x8                // =8
    44c4:      	mov	w10, #0x70              // =112
    44c8:      	add	x11, sp, #0x70
    44cc:      	add	x0, sp, #0x70
    44d0:      	mov	w1, #0x8                // =8
    44d4:      	add	x8, x25, x8
    44d8:      	ldrb	w8, [x24, #0x10]
    44dc:      	add	x2, x25, x8
    44e0:      	blr	x10
    44e4:      	cbz	x0, 0x454c <kprobe_unwind_php+0x454c>
    44e8:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    44ec:      	ldr	x8, [x8]
    44f0:      	ldr	w8, [x8]
    44f4:      	cbz	w8, 0x4790 <kprobe_unwind_php+0x4790>
    44f8:      	mov	w8, #0x2978             // =10616
    44fc:      	add	x0, sp, #0x18
    4500:      	mov	w1, #0x33               // =51
    4504:      	movk	w8, #0xa, lsl #16
    4508:      	stur	w8, [sp, #0x47]
    450c:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4510:      	add	x8, x8, #0x0
    4514:      	ldp	x9, x10, [x8, #0x10]
    4518:      	stp	x9, x10, [sp, #0x28]
    451c:      	ldp	x9, x10, [x8, #0x20]
    4520:      	stp	x9, x10, [sp, #0x38]
    4524:      	ldp	x9, x8, [x8]
    4528:      	add	x10, sp, #0x18
    452c:      	stp	x9, x8, [sp, #0x18]
    4530:      	mov	w8, #0x33               // =51
    4534:      	mov	w9, #0x6                // =6
    4538:      	ldrb	w8, [x24, #0x10]
    453c:      	add	x2, x25, x8
    4540:      	blr	x9
    4544:      	mov	w25, #0x25              // =37
    4548:      	b	0x4888 <kprobe_unwind_php+0x4888>
    454c:      	ldr	x8, [sp, #0x70]
    4550:      	cbz	x8, 0x45dc <kprobe_unwind_php+0x45dc>
    4554:      	ldrb	w9, [x24, #0x14]
    4558:      	mov	w10, #0x70              // =112
    455c:      	add	x11, sp, #0x8c
    4560:      	add	x0, sp, #0x8c
    4564:      	mov	w1, #0x1                // =1
    4568:      	add	x8, x8, x9
    456c:      	mov	w9, #0x1                // =1
    4570:      	ldr	x8, [sp, #0x70]
    4574:      	ldrb	w9, [x24, #0x14]
    4578:      	add	x2, x8, x9
    457c:      	blr	x10
    4580:      	cbz	x0, 0x461c <kprobe_unwind_php+0x461c>
    4584:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4588:      	ldr	x8, [x8]
    458c:      	ldr	w8, [x8]
    4590:      	cbz	w8, 0x45d4 <kprobe_unwind_php+0x45d4>
    4594:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4598:      	add	x10, x10, #0x0
    459c:      	strb	wzr, [sp, #0x48]
    45a0:      	add	x0, sp, #0x18
    45a4:      	ldp	x8, x9, [x10, #0x10]
    45a8:      	mov	w1, #0x31               // =49
    45ac:      	stp	x8, x9, [sp, #0x28]
    45b0:      	ldp	x8, x9, [x10, #0x20]
    45b4:      	stp	x8, x9, [sp, #0x38]
    45b8:      	ldp	x8, x9, [x10]
    45bc:      	add	x10, sp, #0x18
    45c0:      	stp	x8, x9, [sp, #0x18]
    45c4:      	mov	w8, #0x31               // =49
    45c8:      	mov	w9, #0x6                // =6
    45cc:      	ldr	x2, [sp, #0x70]
    45d0:      	blr	x9
    45d4:      	mov	w25, #0x26              // =38
    45d8:      	b	0x4888 <kprobe_unwind_php+0x4888>
    45dc:      	ldr	w8, [x21, #0x2c0]
    45e0:      	adrp	x29, 0x4000 <kprobe_unwind_php+0x4000>
    45e4:      	ldr	x29, [x29]
    45e8:      	cmp	w8, #0x7e
    45ec:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    45f0:      	add	w9, w8, #0x1
    45f4:      	mov	x10, #-0x2              // =-2
    45f8:      	str	w9, [x21, #0x2c0]
    45fc:      	mov	w9, #0x18               // =24
    4600:      	umaddl	x8, w8, w9, x21
    4604:      	add	x9, x8, #0x2d0
    4608:      	str	x10, [x8, #0x2d8]
    460c:      	mov	w10, #0x2               // =2
    4610:      	str	xzr, [x8, #0x2d0]
    4614:      	strb	w10, [x8, #0x2e0]
    4618:      	b	0x487c <kprobe_unwind_php+0x487c>
    461c:      	ldrb	w8, [sp, #0x8c]
    4620:      	str	wzr, [sp, #0x88]
    4624:      	cmp	w8, #0x4
    4628:      	b.eq	0x4638 <kprobe_unwind_php+0x4638>
    462c:      	mov	w29, wzr
    4630:      	cmp	w8, #0x2
    4634:      	b.ne	0x47f4 <kprobe_unwind_php+0x47f4>
    4638:      	ldrb	w8, [x24, #0x11]
    463c:      	mov	w9, #0x8                // =8
    4640:      	mov	w10, #0x70              // =112
    4644:      	add	x11, sp, #0x68
    4648:      	add	x0, sp, #0x68
    464c:      	mov	w1, #0x8                // =8
    4650:      	add	x8, x25, x8
    4654:      	ldrb	w8, [x24, #0x11]
    4658:      	add	x2, x25, x8
    465c:      	blr	x10
    4660:      	cbz	x0, 0x46c4 <kprobe_unwind_php+0x46c4>
    4664:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4668:      	ldr	x8, [x8]
    466c:      	ldr	w8, [x8]
    4670:      	cbz	w8, 0x4790 <kprobe_unwind_php+0x4790>
    4674:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4678:      	add	x10, x10, #0x0
    467c:      	add	x0, sp, #0x18
    4680:      	ldp	x8, x9, [x10, #0x10]
    4684:      	mov	w1, #0x2d               // =45
    4688:      	stp	x8, x9, [sp, #0x28]
    468c:      	ldr	x8, [x10, #0x20]
    4690:      	str	x8, [sp, #0x38]
    4694:      	ldur	x8, [x10, #0x25]
    4698:      	stur	x8, [sp, #0x3d]
    469c:      	ldp	x8, x9, [x10]
    46a0:      	add	x10, sp, #0x18
    46a4:      	stp	x8, x9, [sp, #0x18]
    46a8:      	mov	w8, #0x2d               // =45
    46ac:      	mov	w9, #0x6                // =6
    46b0:      	ldrb	w8, [x24, #0x11]
    46b4:      	add	x2, x25, x8
    46b8:      	blr	x9
    46bc:      	mov	w25, #0x25              // =37
    46c0:      	b	0x4888 <kprobe_unwind_php+0x4888>
    46c4:      	ldr	x8, [sp, #0x68]
    46c8:      	ldrb	w9, [x24, #0x15]
    46cc:      	mov	w10, #0x70              // =112
    46d0:      	add	x11, sp, #0x88
    46d4:      	add	x0, sp, #0x88
    46d8:      	mov	w1, #0x4                // =4
    46dc:      	add	x8, x8, x9
    46e0:      	mov	w9, #0x4                // =4
    46e4:      	ldr	x8, [sp, #0x68]
    46e8:      	ldrb	w9, [x24, #0x15]
    46ec:      	add	x2, x8, x9
    46f0:      	blr	x10
    46f4:      	cbz	x0, 0x4710 <kprobe_unwind_php+0x4710>
    46f8:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    46fc:      	ldr	x8, [x8]
    4700:      	ldr	w8, [x8]
    4704:      	cbnz	w8, 0x4798 <kprobe_unwind_php+0x4798>
    4708:      	mov	w25, #0x27              // =39
    470c:      	b	0x4888 <kprobe_unwind_php+0x4888>
    4710:      	ldrb	w8, [x24, #0x13]
    4714:      	mov	w9, #0x4                // =4
    4718:      	mov	w10, #0x70              // =112
    471c:      	add	x11, sp, #0x5c
    4720:      	add	x0, sp, #0x5c
    4724:      	mov	w1, #0x4                // =4
    4728:      	add	x8, x25, x8
    472c:      	ldrb	w8, [x24, #0x13]
    4730:      	add	x2, x25, x8
    4734:      	blr	x10
    4738:      	cbz	x0, 0x47f0 <kprobe_unwind_php+0x47f0>
    473c:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4740:      	ldr	x8, [x8]
    4744:      	ldr	w8, [x8]
    4748:      	cbz	w8, 0x4790 <kprobe_unwind_php+0x4790>
    474c:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4750:      	add	x10, x10, #0x0
    4754:      	mov	w11, #0x6               // =6
    4758:      	ldp	x8, x9, [x10, #0x20]
    475c:      	add	x0, sp, #0x18
    4760:      	mov	w1, #0x35               // =53
    4764:      	mov	x2, x25
    4768:      	stp	x8, x9, [sp, #0x38]
    476c:      	ldur	x8, [x10, #0x2d]
    4770:      	stur	x8, [sp, #0x45]
    4774:      	ldp	x8, x9, [x10]
    4778:      	stp	x8, x9, [sp, #0x18]
    477c:      	ldp	x9, x8, [x10, #0x10]
    4780:      	mov	w10, #0x35              // =53
    4784:      	stp	x9, x8, [sp, #0x28]
    4788:      	add	x8, sp, #0x18
    478c:      	blr	x11
    4790:      	mov	w25, #0x25              // =37
    4794:      	b	0x4888 <kprobe_unwind_php+0x4888>
    4798:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    479c:      	add	x10, x10, #0x0
    47a0:      	strb	wzr, [sp, #0x50]
    47a4:      	add	x0, sp, #0x18
    47a8:      	ldp	x8, x9, [x10, #0x20]
    47ac:      	mov	w1, #0x39               // =57
    47b0:      	stp	x8, x9, [sp, #0x38]
    47b4:      	ldr	x8, [x10, #0x30]
    47b8:      	str	x8, [sp, #0x48]
    47bc:      	ldp	x8, x9, [x10]
    47c0:      	stp	x8, x9, [sp, #0x18]
    47c4:      	ldp	x9, x8, [x10, #0x10]
    47c8:      	add	x10, sp, #0x18
    47cc:      	stp	x9, x8, [sp, #0x28]
    47d0:      	mov	w8, #0x39               // =57
    47d4:      	mov	w9, #0x6                // =6
    47d8:      	ldr	x8, [sp, #0x68]
    47dc:      	ldrb	w10, [x24, #0x15]
    47e0:      	add	x2, x8, x10
    47e4:      	blr	x9
    47e8:      	mov	w25, #0x27              // =39
    47ec:      	b	0x4888 <kprobe_unwind_php+0x4888>
    47f0:      	ldr	w29, [sp, #0x88]
    47f4:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    47f8:      	ldr	w25, [sp, #0x5c]
    47fc:      	ldr	x8, [x8]
    4800:      	ldr	w8, [x8]
    4804:      	cbz	w8, 0x4840 <kprobe_unwind_php+0x4840>
    4808:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    480c:      	add	x10, x10, #0x0
    4810:      	add	x0, sp, #0x18
    4814:      	ldp	x8, x9, [x10]
    4818:      	mov	w1, #0x16               // =22
    481c:      	stp	x8, x9, [sp, #0x18]
    4820:      	ldur	x8, [x10, #0xe]
    4824:      	mov	w9, #0x6                // =6
    4828:      	add	x10, sp, #0x18
    482c:      	stur	x8, [sp, #0x26]
    4830:      	mov	w8, #0x16               // =22
    4834:      	ldr	x2, [sp, #0x70]
    4838:      	ldr	w3, [sp, #0x88]
    483c:      	blr	x9
    4840:      	ldr	w8, [x21, #0x2c0]
    4844:      	cmp	w8, #0x7e
    4848:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    484c:      	add	w9, w8, #0x1
    4850:      	mov	w10, w29
    4854:      	str	w9, [x21, #0x2c0]
    4858:      	mov	w9, #0x18               // =24
    485c:      	orr	x10, x10, x25, lsl #32
    4860:      	umaddl	x8, w8, w9, x21
    4864:      	ldr	x9, [sp, #0x70]
    4868:      	str	x10, [x8, #0x2d8]
    486c:      	str	x9, [x8, #0x2d0]
    4870:      	ldr	w9, [sp, #0xc]
    4874:      	strb	w9, [x8, #0x2e0]
    4878:      	add	x9, x8, #0x2d0
    487c:      	mov	w25, #0x23              // =35
    4880:      	str	wzr, [x8, #0x2e4]
    4884:      	stur	wzr, [x9, #0x11]
    4888:      	str	w25, [sp, #0x70]
    488c:      	mov	w8, #0x1                // =1
    4890:      	add	x9, sp, #0x70
    4894:      	add	x1, sp, #0x70
    4898:      	mov	x0, x23
    489c:      	blr	x8
    48a0:      	cbz	x0, 0x48b4 <kprobe_unwind_php+0x48b4>
    48a4:      	ldr	x8, [x0]
    48a8:      	add	x8, x8, #0x1
    48ac:      	str	x8, [x0]
    48b0:      	b	0x4908 <kprobe_unwind_php+0x4908>
    48b4:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    48b8:      	ldr	x8, [x8]
    48bc:      	ldr	w8, [x8]
    48c0:      	cbz	w8, 0x4908 <kprobe_unwind_php+0x4908>
    48c4:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    48c8:      	add	x8, x8, #0x0
    48cc:      	add	x0, sp, #0x18
    48d0:      	ldp	x9, x10, [x8, #0x10]
    48d4:      	mov	w1, #0x2e               // =46
    48d8:      	stp	x9, x10, [sp, #0x28]
    48dc:      	ldr	x9, [x8, #0x20]
    48e0:      	add	x10, sp, #0x18
    48e4:      	str	x9, [sp, #0x38]
    48e8:      	ldur	x9, [x8, #0x26]
    48ec:      	stur	x9, [sp, #0x3e]
    48f0:      	ldp	x9, x8, [x8]
    48f4:      	stp	x9, x8, [sp, #0x18]
    48f8:      	mov	w8, #0x2e               // =46
    48fc:      	mov	w9, #0x6                // =6
    4900:      	ldr	w2, [sp, #0x70]
    4904:      	blr	x9
    4908:      	cmp	w25, #0x23
    490c:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    4910:      	ldr	x8, [sp, #0x60]
    4914:      	ldrb	w9, [x24, #0x12]
    4918:      	mov	w10, #0x70              // =112
    491c:      	add	x11, sp, #0x60
    4920:      	add	x0, sp, #0x60
    4924:      	mov	w1, #0x8                // =8
    4928:      	add	x8, x8, x9
    492c:      	mov	w9, #0x8                // =8
    4930:      	ldr	x8, [sp, #0x60]
    4934:      	ldrb	w9, [x24, #0x12]
    4938:      	add	x2, x8, x9
    493c:      	blr	x10
    4940:      	adrp	x29, 0x4000 <kprobe_unwind_php+0x4000>
    4944:      	ldr	x29, [x29]
    4948:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    494c:      	ldr	x25, [sp, #0x60]
    4950:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    4954:      	ldrb	w8, [sp, #0x5e]
    4958:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    495c:      	ldrb	w8, [x24, #0x10]
    4960:      	mov	w9, #0x8                // =8
    4964:      	mov	w10, #0x70              // =112
    4968:      	add	x11, sp, #0x70
    496c:      	add	x0, sp, #0x70
    4970:      	mov	w1, #0x8                // =8
    4974:      	add	x8, x25, x8
    4978:      	ldrb	w8, [x24, #0x10]
    497c:      	add	x2, x25, x8
    4980:      	blr	x10
    4984:      	cbz	x0, 0x49ec <kprobe_unwind_php+0x49ec>
    4988:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    498c:      	ldr	x8, [x8]
    4990:      	ldr	w8, [x8]
    4994:      	cbz	w8, 0x4c30 <kprobe_unwind_php+0x4c30>
    4998:      	mov	w8, #0x2978             // =10616
    499c:      	add	x0, sp, #0x18
    49a0:      	mov	w1, #0x33               // =51
    49a4:      	movk	w8, #0xa, lsl #16
    49a8:      	stur	w8, [sp, #0x47]
    49ac:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    49b0:      	add	x8, x8, #0x0
    49b4:      	ldp	x9, x10, [x8, #0x10]
    49b8:      	stp	x9, x10, [sp, #0x28]
    49bc:      	ldp	x9, x10, [x8, #0x20]
    49c0:      	stp	x9, x10, [sp, #0x38]
    49c4:      	ldp	x9, x8, [x8]
    49c8:      	add	x10, sp, #0x18
    49cc:      	stp	x9, x8, [sp, #0x18]
    49d0:      	mov	w8, #0x33               // =51
    49d4:      	mov	w9, #0x6                // =6
    49d8:      	ldrb	w8, [x24, #0x10]
    49dc:      	add	x2, x25, x8
    49e0:      	blr	x9
    49e4:      	mov	w25, #0x25              // =37
    49e8:      	b	0x4d28 <kprobe_unwind_php+0x4d28>
    49ec:      	ldr	x8, [sp, #0x70]
    49f0:      	cbz	x8, 0x4a7c <kprobe_unwind_php+0x4a7c>
    49f4:      	ldrb	w9, [x24, #0x14]
    49f8:      	mov	w10, #0x70              // =112
    49fc:      	add	x11, sp, #0x8c
    4a00:      	add	x0, sp, #0x8c
    4a04:      	mov	w1, #0x1                // =1
    4a08:      	add	x8, x8, x9
    4a0c:      	mov	w9, #0x1                // =1
    4a10:      	ldr	x8, [sp, #0x70]
    4a14:      	ldrb	w9, [x24, #0x14]
    4a18:      	add	x2, x8, x9
    4a1c:      	blr	x10
    4a20:      	cbz	x0, 0x4abc <kprobe_unwind_php+0x4abc>
    4a24:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4a28:      	ldr	x8, [x8]
    4a2c:      	ldr	w8, [x8]
    4a30:      	cbz	w8, 0x4a74 <kprobe_unwind_php+0x4a74>
    4a34:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4a38:      	add	x10, x10, #0x0
    4a3c:      	strb	wzr, [sp, #0x48]
    4a40:      	add	x0, sp, #0x18
    4a44:      	ldp	x8, x9, [x10, #0x10]
    4a48:      	mov	w1, #0x31               // =49
    4a4c:      	stp	x8, x9, [sp, #0x28]
    4a50:      	ldp	x8, x9, [x10, #0x20]
    4a54:      	stp	x8, x9, [sp, #0x38]
    4a58:      	ldp	x8, x9, [x10]
    4a5c:      	add	x10, sp, #0x18
    4a60:      	stp	x8, x9, [sp, #0x18]
    4a64:      	mov	w8, #0x31               // =49
    4a68:      	mov	w9, #0x6                // =6
    4a6c:      	ldr	x2, [sp, #0x70]
    4a70:      	blr	x9
    4a74:      	mov	w25, #0x26              // =38
    4a78:      	b	0x4d28 <kprobe_unwind_php+0x4d28>
    4a7c:      	ldr	w8, [x21, #0x2c0]
    4a80:      	adrp	x29, 0x4000 <kprobe_unwind_php+0x4000>
    4a84:      	ldr	x29, [x29]
    4a88:      	cmp	w8, #0x7e
    4a8c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    4a90:      	add	w9, w8, #0x1
    4a94:      	mov	x10, #-0x2              // =-2
    4a98:      	str	w9, [x21, #0x2c0]
    4a9c:      	mov	w9, #0x18               // =24
    4aa0:      	umaddl	x8, w8, w9, x21
    4aa4:      	add	x9, x8, #0x2d0
    4aa8:      	str	x10, [x8, #0x2d8]
    4aac:      	mov	w10, #0x2               // =2
    4ab0:      	str	xzr, [x8, #0x2d0]
    4ab4:      	strb	w10, [x8, #0x2e0]
    4ab8:      	b	0x4d1c <kprobe_unwind_php+0x4d1c>
    4abc:      	ldrb	w8, [sp, #0x8c]
    4ac0:      	str	wzr, [sp, #0x88]
    4ac4:      	cmp	w8, #0x4
    4ac8:      	b.eq	0x4ad8 <kprobe_unwind_php+0x4ad8>
    4acc:      	mov	w29, wzr
    4ad0:      	cmp	w8, #0x2
    4ad4:      	b.ne	0x4c94 <kprobe_unwind_php+0x4c94>
    4ad8:      	ldrb	w8, [x24, #0x11]
    4adc:      	mov	w9, #0x8                // =8
    4ae0:      	mov	w10, #0x70              // =112
    4ae4:      	add	x11, sp, #0x68
    4ae8:      	add	x0, sp, #0x68
    4aec:      	mov	w1, #0x8                // =8
    4af0:      	add	x8, x25, x8
    4af4:      	ldrb	w8, [x24, #0x11]
    4af8:      	add	x2, x25, x8
    4afc:      	blr	x10
    4b00:      	cbz	x0, 0x4b64 <kprobe_unwind_php+0x4b64>
    4b04:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4b08:      	ldr	x8, [x8]
    4b0c:      	ldr	w8, [x8]
    4b10:      	cbz	w8, 0x4c30 <kprobe_unwind_php+0x4c30>
    4b14:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4b18:      	add	x10, x10, #0x0
    4b1c:      	add	x0, sp, #0x18
    4b20:      	ldp	x8, x9, [x10, #0x10]
    4b24:      	mov	w1, #0x2d               // =45
    4b28:      	stp	x8, x9, [sp, #0x28]
    4b2c:      	ldr	x8, [x10, #0x20]
    4b30:      	str	x8, [sp, #0x38]
    4b34:      	ldur	x8, [x10, #0x25]
    4b38:      	stur	x8, [sp, #0x3d]
    4b3c:      	ldp	x8, x9, [x10]
    4b40:      	add	x10, sp, #0x18
    4b44:      	stp	x8, x9, [sp, #0x18]
    4b48:      	mov	w8, #0x2d               // =45
    4b4c:      	mov	w9, #0x6                // =6
    4b50:      	ldrb	w8, [x24, #0x11]
    4b54:      	add	x2, x25, x8
    4b58:      	blr	x9
    4b5c:      	mov	w25, #0x25              // =37
    4b60:      	b	0x4d28 <kprobe_unwind_php+0x4d28>
    4b64:      	ldr	x8, [sp, #0x68]
    4b68:      	ldrb	w9, [x24, #0x15]
    4b6c:      	mov	w10, #0x70              // =112
    4b70:      	add	x11, sp, #0x88
    4b74:      	add	x0, sp, #0x88
    4b78:      	mov	w1, #0x4                // =4
    4b7c:      	add	x8, x8, x9
    4b80:      	mov	w9, #0x4                // =4
    4b84:      	ldr	x8, [sp, #0x68]
    4b88:      	ldrb	w9, [x24, #0x15]
    4b8c:      	add	x2, x8, x9
    4b90:      	blr	x10
    4b94:      	cbz	x0, 0x4bb0 <kprobe_unwind_php+0x4bb0>
    4b98:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4b9c:      	ldr	x8, [x8]
    4ba0:      	ldr	w8, [x8]
    4ba4:      	cbnz	w8, 0x4c38 <kprobe_unwind_php+0x4c38>
    4ba8:      	mov	w25, #0x27              // =39
    4bac:      	b	0x4d28 <kprobe_unwind_php+0x4d28>
    4bb0:      	ldrb	w8, [x24, #0x13]
    4bb4:      	mov	w9, #0x4                // =4
    4bb8:      	mov	w10, #0x70              // =112
    4bbc:      	add	x11, sp, #0x5c
    4bc0:      	add	x0, sp, #0x5c
    4bc4:      	mov	w1, #0x4                // =4
    4bc8:      	add	x8, x25, x8
    4bcc:      	ldrb	w8, [x24, #0x13]
    4bd0:      	add	x2, x25, x8
    4bd4:      	blr	x10
    4bd8:      	cbz	x0, 0x4c90 <kprobe_unwind_php+0x4c90>
    4bdc:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4be0:      	ldr	x8, [x8]
    4be4:      	ldr	w8, [x8]
    4be8:      	cbz	w8, 0x4c30 <kprobe_unwind_php+0x4c30>
    4bec:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4bf0:      	add	x10, x10, #0x0
    4bf4:      	mov	w11, #0x6               // =6
    4bf8:      	ldp	x8, x9, [x10, #0x20]
    4bfc:      	add	x0, sp, #0x18
    4c00:      	mov	w1, #0x35               // =53
    4c04:      	mov	x2, x25
    4c08:      	stp	x8, x9, [sp, #0x38]
    4c0c:      	ldur	x8, [x10, #0x2d]
    4c10:      	stur	x8, [sp, #0x45]
    4c14:      	ldp	x8, x9, [x10]
    4c18:      	stp	x8, x9, [sp, #0x18]
    4c1c:      	ldp	x9, x8, [x10, #0x10]
    4c20:      	mov	w10, #0x35              // =53
    4c24:      	stp	x9, x8, [sp, #0x28]
    4c28:      	add	x8, sp, #0x18
    4c2c:      	blr	x11
    4c30:      	mov	w25, #0x25              // =37
    4c34:      	b	0x4d28 <kprobe_unwind_php+0x4d28>
    4c38:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4c3c:      	add	x10, x10, #0x0
    4c40:      	strb	wzr, [sp, #0x50]
    4c44:      	add	x0, sp, #0x18
    4c48:      	ldp	x8, x9, [x10, #0x20]
    4c4c:      	mov	w1, #0x39               // =57
    4c50:      	stp	x8, x9, [sp, #0x38]
    4c54:      	ldr	x8, [x10, #0x30]
    4c58:      	str	x8, [sp, #0x48]
    4c5c:      	ldp	x8, x9, [x10]
    4c60:      	stp	x8, x9, [sp, #0x18]
    4c64:      	ldp	x9, x8, [x10, #0x10]
    4c68:      	add	x10, sp, #0x18
    4c6c:      	stp	x9, x8, [sp, #0x28]
    4c70:      	mov	w8, #0x39               // =57
    4c74:      	mov	w9, #0x6                // =6
    4c78:      	ldr	x8, [sp, #0x68]
    4c7c:      	ldrb	w10, [x24, #0x15]
    4c80:      	add	x2, x8, x10
    4c84:      	blr	x9
    4c88:      	mov	w25, #0x27              // =39
    4c8c:      	b	0x4d28 <kprobe_unwind_php+0x4d28>
    4c90:      	ldr	w29, [sp, #0x88]
    4c94:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4c98:      	ldr	w25, [sp, #0x5c]
    4c9c:      	ldr	x8, [x8]
    4ca0:      	ldr	w8, [x8]
    4ca4:      	cbz	w8, 0x4ce0 <kprobe_unwind_php+0x4ce0>
    4ca8:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4cac:      	add	x10, x10, #0x0
    4cb0:      	add	x0, sp, #0x18
    4cb4:      	ldp	x8, x9, [x10]
    4cb8:      	mov	w1, #0x16               // =22
    4cbc:      	stp	x8, x9, [sp, #0x18]
    4cc0:      	ldur	x8, [x10, #0xe]
    4cc4:      	mov	w9, #0x6                // =6
    4cc8:      	add	x10, sp, #0x18
    4ccc:      	stur	x8, [sp, #0x26]
    4cd0:      	mov	w8, #0x16               // =22
    4cd4:      	ldr	x2, [sp, #0x70]
    4cd8:      	ldr	w3, [sp, #0x88]
    4cdc:      	blr	x9
    4ce0:      	ldr	w8, [x21, #0x2c0]
    4ce4:      	cmp	w8, #0x7e
    4ce8:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    4cec:      	add	w9, w8, #0x1
    4cf0:      	mov	w10, w29
    4cf4:      	str	w9, [x21, #0x2c0]
    4cf8:      	mov	w9, #0x18               // =24
    4cfc:      	orr	x10, x10, x25, lsl #32
    4d00:      	umaddl	x8, w8, w9, x21
    4d04:      	ldr	x9, [sp, #0x70]
    4d08:      	str	x10, [x8, #0x2d8]
    4d0c:      	str	x9, [x8, #0x2d0]
    4d10:      	ldr	w9, [sp, #0xc]
    4d14:      	strb	w9, [x8, #0x2e0]
    4d18:      	add	x9, x8, #0x2d0
    4d1c:      	mov	w25, #0x23              // =35
    4d20:      	str	wzr, [x8, #0x2e4]
    4d24:      	stur	wzr, [x9, #0x11]
    4d28:      	str	w25, [sp, #0x70]
    4d2c:      	mov	w8, #0x1                // =1
    4d30:      	add	x9, sp, #0x70
    4d34:      	add	x1, sp, #0x70
    4d38:      	mov	x0, x23
    4d3c:      	blr	x8
    4d40:      	cbz	x0, 0x4d54 <kprobe_unwind_php+0x4d54>
    4d44:      	ldr	x8, [x0]
    4d48:      	add	x8, x8, #0x1
    4d4c:      	str	x8, [x0]
    4d50:      	b	0x4da8 <kprobe_unwind_php+0x4da8>
    4d54:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4d58:      	ldr	x8, [x8]
    4d5c:      	ldr	w8, [x8]
    4d60:      	cbz	w8, 0x4da8 <kprobe_unwind_php+0x4da8>
    4d64:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4d68:      	add	x8, x8, #0x0
    4d6c:      	add	x0, sp, #0x18
    4d70:      	ldp	x9, x10, [x8, #0x10]
    4d74:      	mov	w1, #0x2e               // =46
    4d78:      	stp	x9, x10, [sp, #0x28]
    4d7c:      	ldr	x9, [x8, #0x20]
    4d80:      	add	x10, sp, #0x18
    4d84:      	str	x9, [sp, #0x38]
    4d88:      	ldur	x9, [x8, #0x26]
    4d8c:      	stur	x9, [sp, #0x3e]
    4d90:      	ldp	x9, x8, [x8]
    4d94:      	stp	x9, x8, [sp, #0x18]
    4d98:      	mov	w8, #0x2e               // =46
    4d9c:      	mov	w9, #0x6                // =6
    4da0:      	ldr	w2, [sp, #0x70]
    4da4:      	blr	x9
    4da8:      	cmp	w25, #0x23
    4dac:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    4db0:      	ldr	x8, [sp, #0x60]
    4db4:      	ldrb	w9, [x24, #0x12]
    4db8:      	mov	w10, #0x70              // =112
    4dbc:      	add	x11, sp, #0x60
    4dc0:      	add	x0, sp, #0x60
    4dc4:      	mov	w1, #0x8                // =8
    4dc8:      	add	x8, x8, x9
    4dcc:      	mov	w9, #0x8                // =8
    4dd0:      	ldr	x8, [sp, #0x60]
    4dd4:      	ldrb	w9, [x24, #0x12]
    4dd8:      	add	x2, x8, x9
    4ddc:      	blr	x10
    4de0:      	adrp	x29, 0x4000 <kprobe_unwind_php+0x4000>
    4de4:      	ldr	x29, [x29]
    4de8:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    4dec:      	ldr	x25, [sp, #0x60]
    4df0:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    4df4:      	ldrb	w8, [sp, #0x5e]
    4df8:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    4dfc:      	ldrb	w8, [x24, #0x10]
    4e00:      	mov	w9, #0x8                // =8
    4e04:      	mov	w10, #0x70              // =112
    4e08:      	add	x11, sp, #0x70
    4e0c:      	add	x0, sp, #0x70
    4e10:      	mov	w1, #0x8                // =8
    4e14:      	add	x8, x25, x8
    4e18:      	ldrb	w8, [x24, #0x10]
    4e1c:      	add	x2, x25, x8
    4e20:      	blr	x10
    4e24:      	cbz	x0, 0x4e8c <kprobe_unwind_php+0x4e8c>
    4e28:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4e2c:      	ldr	x8, [x8]
    4e30:      	ldr	w8, [x8]
    4e34:      	cbz	w8, 0x50d0 <kprobe_unwind_php+0x50d0>
    4e38:      	mov	w8, #0x2978             // =10616
    4e3c:      	add	x0, sp, #0x18
    4e40:      	mov	w1, #0x33               // =51
    4e44:      	movk	w8, #0xa, lsl #16
    4e48:      	stur	w8, [sp, #0x47]
    4e4c:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4e50:      	add	x8, x8, #0x0
    4e54:      	ldp	x9, x10, [x8, #0x10]
    4e58:      	stp	x9, x10, [sp, #0x28]
    4e5c:      	ldp	x9, x10, [x8, #0x20]
    4e60:      	stp	x9, x10, [sp, #0x38]
    4e64:      	ldp	x9, x8, [x8]
    4e68:      	add	x10, sp, #0x18
    4e6c:      	stp	x9, x8, [sp, #0x18]
    4e70:      	mov	w8, #0x33               // =51
    4e74:      	mov	w9, #0x6                // =6
    4e78:      	ldrb	w8, [x24, #0x10]
    4e7c:      	add	x2, x25, x8
    4e80:      	blr	x9
    4e84:      	mov	w25, #0x25              // =37
    4e88:      	b	0x51c8 <kprobe_unwind_php+0x51c8>
    4e8c:      	ldr	x8, [sp, #0x70]
    4e90:      	cbz	x8, 0x4f1c <kprobe_unwind_php+0x4f1c>
    4e94:      	ldrb	w9, [x24, #0x14]
    4e98:      	mov	w10, #0x70              // =112
    4e9c:      	add	x11, sp, #0x8c
    4ea0:      	add	x0, sp, #0x8c
    4ea4:      	mov	w1, #0x1                // =1
    4ea8:      	add	x8, x8, x9
    4eac:      	mov	w9, #0x1                // =1
    4eb0:      	ldr	x8, [sp, #0x70]
    4eb4:      	ldrb	w9, [x24, #0x14]
    4eb8:      	add	x2, x8, x9
    4ebc:      	blr	x10
    4ec0:      	cbz	x0, 0x4f5c <kprobe_unwind_php+0x4f5c>
    4ec4:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4ec8:      	ldr	x8, [x8]
    4ecc:      	ldr	w8, [x8]
    4ed0:      	cbz	w8, 0x4f14 <kprobe_unwind_php+0x4f14>
    4ed4:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4ed8:      	add	x10, x10, #0x0
    4edc:      	strb	wzr, [sp, #0x48]
    4ee0:      	add	x0, sp, #0x18
    4ee4:      	ldp	x8, x9, [x10, #0x10]
    4ee8:      	mov	w1, #0x31               // =49
    4eec:      	stp	x8, x9, [sp, #0x28]
    4ef0:      	ldp	x8, x9, [x10, #0x20]
    4ef4:      	stp	x8, x9, [sp, #0x38]
    4ef8:      	ldp	x8, x9, [x10]
    4efc:      	add	x10, sp, #0x18
    4f00:      	stp	x8, x9, [sp, #0x18]
    4f04:      	mov	w8, #0x31               // =49
    4f08:      	mov	w9, #0x6                // =6
    4f0c:      	ldr	x2, [sp, #0x70]
    4f10:      	blr	x9
    4f14:      	mov	w25, #0x26              // =38
    4f18:      	b	0x51c8 <kprobe_unwind_php+0x51c8>
    4f1c:      	ldr	w8, [x21, #0x2c0]
    4f20:      	adrp	x29, 0x4000 <kprobe_unwind_php+0x4000>
    4f24:      	ldr	x29, [x29]
    4f28:      	cmp	w8, #0x7e
    4f2c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    4f30:      	add	w9, w8, #0x1
    4f34:      	mov	x10, #-0x2              // =-2
    4f38:      	str	w9, [x21, #0x2c0]
    4f3c:      	mov	w9, #0x18               // =24
    4f40:      	umaddl	x8, w8, w9, x21
    4f44:      	add	x9, x8, #0x2d0
    4f48:      	str	x10, [x8, #0x2d8]
    4f4c:      	mov	w10, #0x2               // =2
    4f50:      	str	xzr, [x8, #0x2d0]
    4f54:      	strb	w10, [x8, #0x2e0]
    4f58:      	b	0x51bc <kprobe_unwind_php+0x51bc>
    4f5c:      	ldrb	w8, [sp, #0x8c]
    4f60:      	str	wzr, [sp, #0x88]
    4f64:      	cmp	w8, #0x4
    4f68:      	b.eq	0x4f78 <kprobe_unwind_php+0x4f78>
    4f6c:      	mov	w29, wzr
    4f70:      	cmp	w8, #0x2
    4f74:      	b.ne	0x5134 <kprobe_unwind_php+0x5134>
    4f78:      	ldrb	w8, [x24, #0x11]
    4f7c:      	mov	w9, #0x8                // =8
    4f80:      	mov	w10, #0x70              // =112
    4f84:      	add	x11, sp, #0x68
    4f88:      	add	x0, sp, #0x68
    4f8c:      	mov	w1, #0x8                // =8
    4f90:      	add	x8, x25, x8
    4f94:      	ldrb	w8, [x24, #0x11]
    4f98:      	add	x2, x25, x8
    4f9c:      	blr	x10
    4fa0:      	cbz	x0, 0x5004 <kprobe_unwind_php+0x5004>
    4fa4:      	adrp	x8, 0x4000 <kprobe_unwind_php+0x4000>
    4fa8:      	ldr	x8, [x8]
    4fac:      	ldr	w8, [x8]
    4fb0:      	cbz	w8, 0x50d0 <kprobe_unwind_php+0x50d0>
    4fb4:      	adrp	x10, 0x4000 <kprobe_unwind_php+0x4000>
    4fb8:      	add	x10, x10, #0x0
    4fbc:      	add	x0, sp, #0x18
    4fc0:      	ldp	x8, x9, [x10, #0x10]
    4fc4:      	mov	w1, #0x2d               // =45
    4fc8:      	stp	x8, x9, [sp, #0x28]
    4fcc:      	ldr	x8, [x10, #0x20]
    4fd0:      	str	x8, [sp, #0x38]
    4fd4:      	ldur	x8, [x10, #0x25]
    4fd8:      	stur	x8, [sp, #0x3d]
    4fdc:      	ldp	x8, x9, [x10]
    4fe0:      	add	x10, sp, #0x18
    4fe4:      	stp	x8, x9, [sp, #0x18]
    4fe8:      	mov	w8, #0x2d               // =45
    4fec:      	mov	w9, #0x6                // =6
    4ff0:      	ldrb	w8, [x24, #0x11]
    4ff4:      	add	x2, x25, x8
    4ff8:      	blr	x9
    4ffc:      	mov	w25, #0x25              // =37
    5000:      	b	0x51c8 <kprobe_unwind_php+0x51c8>
    5004:      	ldr	x8, [sp, #0x68]
    5008:      	ldrb	w9, [x24, #0x15]
    500c:      	mov	w10, #0x70              // =112
    5010:      	add	x11, sp, #0x88
    5014:      	add	x0, sp, #0x88
    5018:      	mov	w1, #0x4                // =4
    501c:      	add	x8, x8, x9
    5020:      	mov	w9, #0x4                // =4
    5024:      	ldr	x8, [sp, #0x68]
    5028:      	ldrb	w9, [x24, #0x15]
    502c:      	add	x2, x8, x9
    5030:      	blr	x10
    5034:      	cbz	x0, 0x5050 <kprobe_unwind_php+0x5050>
    5038:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    503c:      	ldr	x8, [x8]
    5040:      	ldr	w8, [x8]
    5044:      	cbnz	w8, 0x50d8 <kprobe_unwind_php+0x50d8>
    5048:      	mov	w25, #0x27              // =39
    504c:      	b	0x51c8 <kprobe_unwind_php+0x51c8>
    5050:      	ldrb	w8, [x24, #0x13]
    5054:      	mov	w9, #0x4                // =4
    5058:      	mov	w10, #0x70              // =112
    505c:      	add	x11, sp, #0x5c
    5060:      	add	x0, sp, #0x5c
    5064:      	mov	w1, #0x4                // =4
    5068:      	add	x8, x25, x8
    506c:      	ldrb	w8, [x24, #0x13]
    5070:      	add	x2, x25, x8
    5074:      	blr	x10
    5078:      	cbz	x0, 0x5130 <kprobe_unwind_php+0x5130>
    507c:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5080:      	ldr	x8, [x8]
    5084:      	ldr	w8, [x8]
    5088:      	cbz	w8, 0x50d0 <kprobe_unwind_php+0x50d0>
    508c:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5090:      	add	x10, x10, #0x0
    5094:      	mov	w11, #0x6               // =6
    5098:      	ldp	x8, x9, [x10, #0x20]
    509c:      	add	x0, sp, #0x18
    50a0:      	mov	w1, #0x35               // =53
    50a4:      	mov	x2, x25
    50a8:      	stp	x8, x9, [sp, #0x38]
    50ac:      	ldur	x8, [x10, #0x2d]
    50b0:      	stur	x8, [sp, #0x45]
    50b4:      	ldp	x8, x9, [x10]
    50b8:      	stp	x8, x9, [sp, #0x18]
    50bc:      	ldp	x9, x8, [x10, #0x10]
    50c0:      	mov	w10, #0x35              // =53
    50c4:      	stp	x9, x8, [sp, #0x28]
    50c8:      	add	x8, sp, #0x18
    50cc:      	blr	x11
    50d0:      	mov	w25, #0x25              // =37
    50d4:      	b	0x51c8 <kprobe_unwind_php+0x51c8>
    50d8:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    50dc:      	add	x10, x10, #0x0
    50e0:      	strb	wzr, [sp, #0x50]
    50e4:      	add	x0, sp, #0x18
    50e8:      	ldp	x8, x9, [x10, #0x20]
    50ec:      	mov	w1, #0x39               // =57
    50f0:      	stp	x8, x9, [sp, #0x38]
    50f4:      	ldr	x8, [x10, #0x30]
    50f8:      	str	x8, [sp, #0x48]
    50fc:      	ldp	x8, x9, [x10]
    5100:      	stp	x8, x9, [sp, #0x18]
    5104:      	ldp	x9, x8, [x10, #0x10]
    5108:      	add	x10, sp, #0x18
    510c:      	stp	x9, x8, [sp, #0x28]
    5110:      	mov	w8, #0x39               // =57
    5114:      	mov	w9, #0x6                // =6
    5118:      	ldr	x8, [sp, #0x68]
    511c:      	ldrb	w10, [x24, #0x15]
    5120:      	add	x2, x8, x10
    5124:      	blr	x9
    5128:      	mov	w25, #0x27              // =39
    512c:      	b	0x51c8 <kprobe_unwind_php+0x51c8>
    5130:      	ldr	w29, [sp, #0x88]
    5134:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5138:      	ldr	w25, [sp, #0x5c]
    513c:      	ldr	x8, [x8]
    5140:      	ldr	w8, [x8]
    5144:      	cbz	w8, 0x5180 <kprobe_unwind_php+0x5180>
    5148:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    514c:      	add	x10, x10, #0x0
    5150:      	add	x0, sp, #0x18
    5154:      	ldp	x8, x9, [x10]
    5158:      	mov	w1, #0x16               // =22
    515c:      	stp	x8, x9, [sp, #0x18]
    5160:      	ldur	x8, [x10, #0xe]
    5164:      	mov	w9, #0x6                // =6
    5168:      	add	x10, sp, #0x18
    516c:      	stur	x8, [sp, #0x26]
    5170:      	mov	w8, #0x16               // =22
    5174:      	ldr	x2, [sp, #0x70]
    5178:      	ldr	w3, [sp, #0x88]
    517c:      	blr	x9
    5180:      	ldr	w8, [x21, #0x2c0]
    5184:      	cmp	w8, #0x7e
    5188:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    518c:      	add	w9, w8, #0x1
    5190:      	mov	w10, w29
    5194:      	str	w9, [x21, #0x2c0]
    5198:      	mov	w9, #0x18               // =24
    519c:      	orr	x10, x10, x25, lsl #32
    51a0:      	umaddl	x8, w8, w9, x21
    51a4:      	ldr	x9, [sp, #0x70]
    51a8:      	str	x10, [x8, #0x2d8]
    51ac:      	str	x9, [x8, #0x2d0]
    51b0:      	ldr	w9, [sp, #0xc]
    51b4:      	strb	w9, [x8, #0x2e0]
    51b8:      	add	x9, x8, #0x2d0
    51bc:      	mov	w25, #0x23              // =35
    51c0:      	str	wzr, [x8, #0x2e4]
    51c4:      	stur	wzr, [x9, #0x11]
    51c8:      	str	w25, [sp, #0x70]
    51cc:      	mov	w8, #0x1                // =1
    51d0:      	add	x9, sp, #0x70
    51d4:      	add	x1, sp, #0x70
    51d8:      	mov	x0, x23
    51dc:      	blr	x8
    51e0:      	cbz	x0, 0x51f4 <kprobe_unwind_php+0x51f4>
    51e4:      	ldr	x8, [x0]
    51e8:      	add	x8, x8, #0x1
    51ec:      	str	x8, [x0]
    51f0:      	b	0x5248 <kprobe_unwind_php+0x5248>
    51f4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    51f8:      	ldr	x8, [x8]
    51fc:      	ldr	w8, [x8]
    5200:      	cbz	w8, 0x5248 <kprobe_unwind_php+0x5248>
    5204:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5208:      	add	x8, x8, #0x0
    520c:      	add	x0, sp, #0x18
    5210:      	ldp	x9, x10, [x8, #0x10]
    5214:      	mov	w1, #0x2e               // =46
    5218:      	stp	x9, x10, [sp, #0x28]
    521c:      	ldr	x9, [x8, #0x20]
    5220:      	add	x10, sp, #0x18
    5224:      	str	x9, [sp, #0x38]
    5228:      	ldur	x9, [x8, #0x26]
    522c:      	stur	x9, [sp, #0x3e]
    5230:      	ldp	x9, x8, [x8]
    5234:      	stp	x9, x8, [sp, #0x18]
    5238:      	mov	w8, #0x2e               // =46
    523c:      	mov	w9, #0x6                // =6
    5240:      	ldr	w2, [sp, #0x70]
    5244:      	blr	x9
    5248:      	cmp	w25, #0x23
    524c:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    5250:      	ldr	x8, [sp, #0x60]
    5254:      	ldrb	w9, [x24, #0x12]
    5258:      	mov	w10, #0x70              // =112
    525c:      	add	x11, sp, #0x60
    5260:      	add	x0, sp, #0x60
    5264:      	mov	w1, #0x8                // =8
    5268:      	add	x8, x8, x9
    526c:      	mov	w9, #0x8                // =8
    5270:      	ldr	x8, [sp, #0x60]
    5274:      	ldrb	w9, [x24, #0x12]
    5278:      	add	x2, x8, x9
    527c:      	blr	x10
    5280:      	adrp	x29, 0x5000 <kprobe_unwind_php+0x5000>
    5284:      	ldr	x29, [x29]
    5288:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    528c:      	ldr	x25, [sp, #0x60]
    5290:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    5294:      	ldrb	w8, [sp, #0x5e]
    5298:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    529c:      	ldrb	w8, [x24, #0x10]
    52a0:      	mov	w9, #0x8                // =8
    52a4:      	mov	w10, #0x70              // =112
    52a8:      	add	x11, sp, #0x70
    52ac:      	add	x0, sp, #0x70
    52b0:      	mov	w1, #0x8                // =8
    52b4:      	add	x8, x25, x8
    52b8:      	ldrb	w8, [x24, #0x10]
    52bc:      	add	x2, x25, x8
    52c0:      	blr	x10
    52c4:      	cbz	x0, 0x532c <kprobe_unwind_php+0x532c>
    52c8:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    52cc:      	ldr	x8, [x8]
    52d0:      	ldr	w8, [x8]
    52d4:      	cbz	w8, 0x5570 <kprobe_unwind_php+0x5570>
    52d8:      	mov	w8, #0x2978             // =10616
    52dc:      	add	x0, sp, #0x18
    52e0:      	mov	w1, #0x33               // =51
    52e4:      	movk	w8, #0xa, lsl #16
    52e8:      	stur	w8, [sp, #0x47]
    52ec:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    52f0:      	add	x8, x8, #0x0
    52f4:      	ldp	x9, x10, [x8, #0x10]
    52f8:      	stp	x9, x10, [sp, #0x28]
    52fc:      	ldp	x9, x10, [x8, #0x20]
    5300:      	stp	x9, x10, [sp, #0x38]
    5304:      	ldp	x9, x8, [x8]
    5308:      	add	x10, sp, #0x18
    530c:      	stp	x9, x8, [sp, #0x18]
    5310:      	mov	w8, #0x33               // =51
    5314:      	mov	w9, #0x6                // =6
    5318:      	ldrb	w8, [x24, #0x10]
    531c:      	add	x2, x25, x8
    5320:      	blr	x9
    5324:      	mov	w25, #0x25              // =37
    5328:      	b	0x5668 <kprobe_unwind_php+0x5668>
    532c:      	ldr	x8, [sp, #0x70]
    5330:      	cbz	x8, 0x53bc <kprobe_unwind_php+0x53bc>
    5334:      	ldrb	w9, [x24, #0x14]
    5338:      	mov	w10, #0x70              // =112
    533c:      	add	x11, sp, #0x8c
    5340:      	add	x0, sp, #0x8c
    5344:      	mov	w1, #0x1                // =1
    5348:      	add	x8, x8, x9
    534c:      	mov	w9, #0x1                // =1
    5350:      	ldr	x8, [sp, #0x70]
    5354:      	ldrb	w9, [x24, #0x14]
    5358:      	add	x2, x8, x9
    535c:      	blr	x10
    5360:      	cbz	x0, 0x53fc <kprobe_unwind_php+0x53fc>
    5364:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5368:      	ldr	x8, [x8]
    536c:      	ldr	w8, [x8]
    5370:      	cbz	w8, 0x53b4 <kprobe_unwind_php+0x53b4>
    5374:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5378:      	add	x10, x10, #0x0
    537c:      	strb	wzr, [sp, #0x48]
    5380:      	add	x0, sp, #0x18
    5384:      	ldp	x8, x9, [x10, #0x10]
    5388:      	mov	w1, #0x31               // =49
    538c:      	stp	x8, x9, [sp, #0x28]
    5390:      	ldp	x8, x9, [x10, #0x20]
    5394:      	stp	x8, x9, [sp, #0x38]
    5398:      	ldp	x8, x9, [x10]
    539c:      	add	x10, sp, #0x18
    53a0:      	stp	x8, x9, [sp, #0x18]
    53a4:      	mov	w8, #0x31               // =49
    53a8:      	mov	w9, #0x6                // =6
    53ac:      	ldr	x2, [sp, #0x70]
    53b0:      	blr	x9
    53b4:      	mov	w25, #0x26              // =38
    53b8:      	b	0x5668 <kprobe_unwind_php+0x5668>
    53bc:      	ldr	w8, [x21, #0x2c0]
    53c0:      	adrp	x29, 0x5000 <kprobe_unwind_php+0x5000>
    53c4:      	ldr	x29, [x29]
    53c8:      	cmp	w8, #0x7e
    53cc:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    53d0:      	add	w9, w8, #0x1
    53d4:      	mov	x10, #-0x2              // =-2
    53d8:      	str	w9, [x21, #0x2c0]
    53dc:      	mov	w9, #0x18               // =24
    53e0:      	umaddl	x8, w8, w9, x21
    53e4:      	add	x9, x8, #0x2d0
    53e8:      	str	x10, [x8, #0x2d8]
    53ec:      	mov	w10, #0x2               // =2
    53f0:      	str	xzr, [x8, #0x2d0]
    53f4:      	strb	w10, [x8, #0x2e0]
    53f8:      	b	0x565c <kprobe_unwind_php+0x565c>
    53fc:      	ldrb	w8, [sp, #0x8c]
    5400:      	str	wzr, [sp, #0x88]
    5404:      	cmp	w8, #0x4
    5408:      	b.eq	0x5418 <kprobe_unwind_php+0x5418>
    540c:      	mov	w29, wzr
    5410:      	cmp	w8, #0x2
    5414:      	b.ne	0x55d4 <kprobe_unwind_php+0x55d4>
    5418:      	ldrb	w8, [x24, #0x11]
    541c:      	mov	w9, #0x8                // =8
    5420:      	mov	w10, #0x70              // =112
    5424:      	add	x11, sp, #0x68
    5428:      	add	x0, sp, #0x68
    542c:      	mov	w1, #0x8                // =8
    5430:      	add	x8, x25, x8
    5434:      	ldrb	w8, [x24, #0x11]
    5438:      	add	x2, x25, x8
    543c:      	blr	x10
    5440:      	cbz	x0, 0x54a4 <kprobe_unwind_php+0x54a4>
    5444:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5448:      	ldr	x8, [x8]
    544c:      	ldr	w8, [x8]
    5450:      	cbz	w8, 0x5570 <kprobe_unwind_php+0x5570>
    5454:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5458:      	add	x10, x10, #0x0
    545c:      	add	x0, sp, #0x18
    5460:      	ldp	x8, x9, [x10, #0x10]
    5464:      	mov	w1, #0x2d               // =45
    5468:      	stp	x8, x9, [sp, #0x28]
    546c:      	ldr	x8, [x10, #0x20]
    5470:      	str	x8, [sp, #0x38]
    5474:      	ldur	x8, [x10, #0x25]
    5478:      	stur	x8, [sp, #0x3d]
    547c:      	ldp	x8, x9, [x10]
    5480:      	add	x10, sp, #0x18
    5484:      	stp	x8, x9, [sp, #0x18]
    5488:      	mov	w8, #0x2d               // =45
    548c:      	mov	w9, #0x6                // =6
    5490:      	ldrb	w8, [x24, #0x11]
    5494:      	add	x2, x25, x8
    5498:      	blr	x9
    549c:      	mov	w25, #0x25              // =37
    54a0:      	b	0x5668 <kprobe_unwind_php+0x5668>
    54a4:      	ldr	x8, [sp, #0x68]
    54a8:      	ldrb	w9, [x24, #0x15]
    54ac:      	mov	w10, #0x70              // =112
    54b0:      	add	x11, sp, #0x88
    54b4:      	add	x0, sp, #0x88
    54b8:      	mov	w1, #0x4                // =4
    54bc:      	add	x8, x8, x9
    54c0:      	mov	w9, #0x4                // =4
    54c4:      	ldr	x8, [sp, #0x68]
    54c8:      	ldrb	w9, [x24, #0x15]
    54cc:      	add	x2, x8, x9
    54d0:      	blr	x10
    54d4:      	cbz	x0, 0x54f0 <kprobe_unwind_php+0x54f0>
    54d8:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    54dc:      	ldr	x8, [x8]
    54e0:      	ldr	w8, [x8]
    54e4:      	cbnz	w8, 0x5578 <kprobe_unwind_php+0x5578>
    54e8:      	mov	w25, #0x27              // =39
    54ec:      	b	0x5668 <kprobe_unwind_php+0x5668>
    54f0:      	ldrb	w8, [x24, #0x13]
    54f4:      	mov	w9, #0x4                // =4
    54f8:      	mov	w10, #0x70              // =112
    54fc:      	add	x11, sp, #0x5c
    5500:      	add	x0, sp, #0x5c
    5504:      	mov	w1, #0x4                // =4
    5508:      	add	x8, x25, x8
    550c:      	ldrb	w8, [x24, #0x13]
    5510:      	add	x2, x25, x8
    5514:      	blr	x10
    5518:      	cbz	x0, 0x55d0 <kprobe_unwind_php+0x55d0>
    551c:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5520:      	ldr	x8, [x8]
    5524:      	ldr	w8, [x8]
    5528:      	cbz	w8, 0x5570 <kprobe_unwind_php+0x5570>
    552c:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5530:      	add	x10, x10, #0x0
    5534:      	mov	w11, #0x6               // =6
    5538:      	ldp	x8, x9, [x10, #0x20]
    553c:      	add	x0, sp, #0x18
    5540:      	mov	w1, #0x35               // =53
    5544:      	mov	x2, x25
    5548:      	stp	x8, x9, [sp, #0x38]
    554c:      	ldur	x8, [x10, #0x2d]
    5550:      	stur	x8, [sp, #0x45]
    5554:      	ldp	x8, x9, [x10]
    5558:      	stp	x8, x9, [sp, #0x18]
    555c:      	ldp	x9, x8, [x10, #0x10]
    5560:      	mov	w10, #0x35              // =53
    5564:      	stp	x9, x8, [sp, #0x28]
    5568:      	add	x8, sp, #0x18
    556c:      	blr	x11
    5570:      	mov	w25, #0x25              // =37
    5574:      	b	0x5668 <kprobe_unwind_php+0x5668>
    5578:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    557c:      	add	x10, x10, #0x0
    5580:      	strb	wzr, [sp, #0x50]
    5584:      	add	x0, sp, #0x18
    5588:      	ldp	x8, x9, [x10, #0x20]
    558c:      	mov	w1, #0x39               // =57
    5590:      	stp	x8, x9, [sp, #0x38]
    5594:      	ldr	x8, [x10, #0x30]
    5598:      	str	x8, [sp, #0x48]
    559c:      	ldp	x8, x9, [x10]
    55a0:      	stp	x8, x9, [sp, #0x18]
    55a4:      	ldp	x9, x8, [x10, #0x10]
    55a8:      	add	x10, sp, #0x18
    55ac:      	stp	x9, x8, [sp, #0x28]
    55b0:      	mov	w8, #0x39               // =57
    55b4:      	mov	w9, #0x6                // =6
    55b8:      	ldr	x8, [sp, #0x68]
    55bc:      	ldrb	w10, [x24, #0x15]
    55c0:      	add	x2, x8, x10
    55c4:      	blr	x9
    55c8:      	mov	w25, #0x27              // =39
    55cc:      	b	0x5668 <kprobe_unwind_php+0x5668>
    55d0:      	ldr	w29, [sp, #0x88]
    55d4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    55d8:      	ldr	w25, [sp, #0x5c]
    55dc:      	ldr	x8, [x8]
    55e0:      	ldr	w8, [x8]
    55e4:      	cbz	w8, 0x5620 <kprobe_unwind_php+0x5620>
    55e8:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    55ec:      	add	x10, x10, #0x0
    55f0:      	add	x0, sp, #0x18
    55f4:      	ldp	x8, x9, [x10]
    55f8:      	mov	w1, #0x16               // =22
    55fc:      	stp	x8, x9, [sp, #0x18]
    5600:      	ldur	x8, [x10, #0xe]
    5604:      	mov	w9, #0x6                // =6
    5608:      	add	x10, sp, #0x18
    560c:      	stur	x8, [sp, #0x26]
    5610:      	mov	w8, #0x16               // =22
    5614:      	ldr	x2, [sp, #0x70]
    5618:      	ldr	w3, [sp, #0x88]
    561c:      	blr	x9
    5620:      	ldr	w8, [x21, #0x2c0]
    5624:      	cmp	w8, #0x7e
    5628:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    562c:      	add	w9, w8, #0x1
    5630:      	mov	w10, w29
    5634:      	str	w9, [x21, #0x2c0]
    5638:      	mov	w9, #0x18               // =24
    563c:      	orr	x10, x10, x25, lsl #32
    5640:      	umaddl	x8, w8, w9, x21
    5644:      	ldr	x9, [sp, #0x70]
    5648:      	str	x10, [x8, #0x2d8]
    564c:      	str	x9, [x8, #0x2d0]
    5650:      	ldr	w9, [sp, #0xc]
    5654:      	strb	w9, [x8, #0x2e0]
    5658:      	add	x9, x8, #0x2d0
    565c:      	mov	w25, #0x23              // =35
    5660:      	str	wzr, [x8, #0x2e4]
    5664:      	stur	wzr, [x9, #0x11]
    5668:      	str	w25, [sp, #0x70]
    566c:      	mov	w8, #0x1                // =1
    5670:      	add	x9, sp, #0x70
    5674:      	add	x1, sp, #0x70
    5678:      	mov	x0, x23
    567c:      	blr	x8
    5680:      	cbz	x0, 0x5694 <kprobe_unwind_php+0x5694>
    5684:      	ldr	x8, [x0]
    5688:      	add	x8, x8, #0x1
    568c:      	str	x8, [x0]
    5690:      	b	0x56e8 <kprobe_unwind_php+0x56e8>
    5694:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5698:      	ldr	x8, [x8]
    569c:      	ldr	w8, [x8]
    56a0:      	cbz	w8, 0x56e8 <kprobe_unwind_php+0x56e8>
    56a4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    56a8:      	add	x8, x8, #0x0
    56ac:      	add	x0, sp, #0x18
    56b0:      	ldp	x9, x10, [x8, #0x10]
    56b4:      	mov	w1, #0x2e               // =46
    56b8:      	stp	x9, x10, [sp, #0x28]
    56bc:      	ldr	x9, [x8, #0x20]
    56c0:      	add	x10, sp, #0x18
    56c4:      	str	x9, [sp, #0x38]
    56c8:      	ldur	x9, [x8, #0x26]
    56cc:      	stur	x9, [sp, #0x3e]
    56d0:      	ldp	x9, x8, [x8]
    56d4:      	stp	x9, x8, [sp, #0x18]
    56d8:      	mov	w8, #0x2e               // =46
    56dc:      	mov	w9, #0x6                // =6
    56e0:      	ldr	w2, [sp, #0x70]
    56e4:      	blr	x9
    56e8:      	cmp	w25, #0x23
    56ec:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    56f0:      	ldr	x8, [sp, #0x60]
    56f4:      	ldrb	w9, [x24, #0x12]
    56f8:      	mov	w10, #0x70              // =112
    56fc:      	add	x11, sp, #0x60
    5700:      	add	x0, sp, #0x60
    5704:      	mov	w1, #0x8                // =8
    5708:      	add	x8, x8, x9
    570c:      	mov	w9, #0x8                // =8
    5710:      	ldr	x8, [sp, #0x60]
    5714:      	ldrb	w9, [x24, #0x12]
    5718:      	add	x2, x8, x9
    571c:      	blr	x10
    5720:      	adrp	x29, 0x5000 <kprobe_unwind_php+0x5000>
    5724:      	ldr	x29, [x29]
    5728:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    572c:      	ldr	x25, [sp, #0x60]
    5730:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    5734:      	ldrb	w8, [sp, #0x5e]
    5738:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    573c:      	ldrb	w8, [x24, #0x10]
    5740:      	mov	w9, #0x8                // =8
    5744:      	mov	w10, #0x70              // =112
    5748:      	add	x11, sp, #0x70
    574c:      	add	x0, sp, #0x70
    5750:      	mov	w1, #0x8                // =8
    5754:      	add	x8, x25, x8
    5758:      	ldrb	w8, [x24, #0x10]
    575c:      	add	x2, x25, x8
    5760:      	blr	x10
    5764:      	cbz	x0, 0x57cc <kprobe_unwind_php+0x57cc>
    5768:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    576c:      	ldr	x8, [x8]
    5770:      	ldr	w8, [x8]
    5774:      	cbz	w8, 0x5a10 <kprobe_unwind_php+0x5a10>
    5778:      	mov	w8, #0x2978             // =10616
    577c:      	add	x0, sp, #0x18
    5780:      	mov	w1, #0x33               // =51
    5784:      	movk	w8, #0xa, lsl #16
    5788:      	stur	w8, [sp, #0x47]
    578c:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5790:      	add	x8, x8, #0x0
    5794:      	ldp	x9, x10, [x8, #0x10]
    5798:      	stp	x9, x10, [sp, #0x28]
    579c:      	ldp	x9, x10, [x8, #0x20]
    57a0:      	stp	x9, x10, [sp, #0x38]
    57a4:      	ldp	x9, x8, [x8]
    57a8:      	add	x10, sp, #0x18
    57ac:      	stp	x9, x8, [sp, #0x18]
    57b0:      	mov	w8, #0x33               // =51
    57b4:      	mov	w9, #0x6                // =6
    57b8:      	ldrb	w8, [x24, #0x10]
    57bc:      	add	x2, x25, x8
    57c0:      	blr	x9
    57c4:      	mov	w25, #0x25              // =37
    57c8:      	b	0x5b08 <kprobe_unwind_php+0x5b08>
    57cc:      	ldr	x8, [sp, #0x70]
    57d0:      	cbz	x8, 0x585c <kprobe_unwind_php+0x585c>
    57d4:      	ldrb	w9, [x24, #0x14]
    57d8:      	mov	w10, #0x70              // =112
    57dc:      	add	x11, sp, #0x8c
    57e0:      	add	x0, sp, #0x8c
    57e4:      	mov	w1, #0x1                // =1
    57e8:      	add	x8, x8, x9
    57ec:      	mov	w9, #0x1                // =1
    57f0:      	ldr	x8, [sp, #0x70]
    57f4:      	ldrb	w9, [x24, #0x14]
    57f8:      	add	x2, x8, x9
    57fc:      	blr	x10
    5800:      	cbz	x0, 0x589c <kprobe_unwind_php+0x589c>
    5804:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5808:      	ldr	x8, [x8]
    580c:      	ldr	w8, [x8]
    5810:      	cbz	w8, 0x5854 <kprobe_unwind_php+0x5854>
    5814:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5818:      	add	x10, x10, #0x0
    581c:      	strb	wzr, [sp, #0x48]
    5820:      	add	x0, sp, #0x18
    5824:      	ldp	x8, x9, [x10, #0x10]
    5828:      	mov	w1, #0x31               // =49
    582c:      	stp	x8, x9, [sp, #0x28]
    5830:      	ldp	x8, x9, [x10, #0x20]
    5834:      	stp	x8, x9, [sp, #0x38]
    5838:      	ldp	x8, x9, [x10]
    583c:      	add	x10, sp, #0x18
    5840:      	stp	x8, x9, [sp, #0x18]
    5844:      	mov	w8, #0x31               // =49
    5848:      	mov	w9, #0x6                // =6
    584c:      	ldr	x2, [sp, #0x70]
    5850:      	blr	x9
    5854:      	mov	w25, #0x26              // =38
    5858:      	b	0x5b08 <kprobe_unwind_php+0x5b08>
    585c:      	ldr	w8, [x21, #0x2c0]
    5860:      	adrp	x29, 0x5000 <kprobe_unwind_php+0x5000>
    5864:      	ldr	x29, [x29]
    5868:      	cmp	w8, #0x7e
    586c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    5870:      	add	w9, w8, #0x1
    5874:      	mov	x10, #-0x2              // =-2
    5878:      	str	w9, [x21, #0x2c0]
    587c:      	mov	w9, #0x18               // =24
    5880:      	umaddl	x8, w8, w9, x21
    5884:      	add	x9, x8, #0x2d0
    5888:      	str	x10, [x8, #0x2d8]
    588c:      	mov	w10, #0x2               // =2
    5890:      	str	xzr, [x8, #0x2d0]
    5894:      	strb	w10, [x8, #0x2e0]
    5898:      	b	0x5afc <kprobe_unwind_php+0x5afc>
    589c:      	ldrb	w8, [sp, #0x8c]
    58a0:      	str	wzr, [sp, #0x88]
    58a4:      	cmp	w8, #0x4
    58a8:      	b.eq	0x58b8 <kprobe_unwind_php+0x58b8>
    58ac:      	mov	w29, wzr
    58b0:      	cmp	w8, #0x2
    58b4:      	b.ne	0x5a74 <kprobe_unwind_php+0x5a74>
    58b8:      	ldrb	w8, [x24, #0x11]
    58bc:      	mov	w9, #0x8                // =8
    58c0:      	mov	w10, #0x70              // =112
    58c4:      	add	x11, sp, #0x68
    58c8:      	add	x0, sp, #0x68
    58cc:      	mov	w1, #0x8                // =8
    58d0:      	add	x8, x25, x8
    58d4:      	ldrb	w8, [x24, #0x11]
    58d8:      	add	x2, x25, x8
    58dc:      	blr	x10
    58e0:      	cbz	x0, 0x5944 <kprobe_unwind_php+0x5944>
    58e4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    58e8:      	ldr	x8, [x8]
    58ec:      	ldr	w8, [x8]
    58f0:      	cbz	w8, 0x5a10 <kprobe_unwind_php+0x5a10>
    58f4:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    58f8:      	add	x10, x10, #0x0
    58fc:      	add	x0, sp, #0x18
    5900:      	ldp	x8, x9, [x10, #0x10]
    5904:      	mov	w1, #0x2d               // =45
    5908:      	stp	x8, x9, [sp, #0x28]
    590c:      	ldr	x8, [x10, #0x20]
    5910:      	str	x8, [sp, #0x38]
    5914:      	ldur	x8, [x10, #0x25]
    5918:      	stur	x8, [sp, #0x3d]
    591c:      	ldp	x8, x9, [x10]
    5920:      	add	x10, sp, #0x18
    5924:      	stp	x8, x9, [sp, #0x18]
    5928:      	mov	w8, #0x2d               // =45
    592c:      	mov	w9, #0x6                // =6
    5930:      	ldrb	w8, [x24, #0x11]
    5934:      	add	x2, x25, x8
    5938:      	blr	x9
    593c:      	mov	w25, #0x25              // =37
    5940:      	b	0x5b08 <kprobe_unwind_php+0x5b08>
    5944:      	ldr	x8, [sp, #0x68]
    5948:      	ldrb	w9, [x24, #0x15]
    594c:      	mov	w10, #0x70              // =112
    5950:      	add	x11, sp, #0x88
    5954:      	add	x0, sp, #0x88
    5958:      	mov	w1, #0x4                // =4
    595c:      	add	x8, x8, x9
    5960:      	mov	w9, #0x4                // =4
    5964:      	ldr	x8, [sp, #0x68]
    5968:      	ldrb	w9, [x24, #0x15]
    596c:      	add	x2, x8, x9
    5970:      	blr	x10
    5974:      	cbz	x0, 0x5990 <kprobe_unwind_php+0x5990>
    5978:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    597c:      	ldr	x8, [x8]
    5980:      	ldr	w8, [x8]
    5984:      	cbnz	w8, 0x5a18 <kprobe_unwind_php+0x5a18>
    5988:      	mov	w25, #0x27              // =39
    598c:      	b	0x5b08 <kprobe_unwind_php+0x5b08>
    5990:      	ldrb	w8, [x24, #0x13]
    5994:      	mov	w9, #0x4                // =4
    5998:      	mov	w10, #0x70              // =112
    599c:      	add	x11, sp, #0x5c
    59a0:      	add	x0, sp, #0x5c
    59a4:      	mov	w1, #0x4                // =4
    59a8:      	add	x8, x25, x8
    59ac:      	ldrb	w8, [x24, #0x13]
    59b0:      	add	x2, x25, x8
    59b4:      	blr	x10
    59b8:      	cbz	x0, 0x5a70 <kprobe_unwind_php+0x5a70>
    59bc:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    59c0:      	ldr	x8, [x8]
    59c4:      	ldr	w8, [x8]
    59c8:      	cbz	w8, 0x5a10 <kprobe_unwind_php+0x5a10>
    59cc:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    59d0:      	add	x10, x10, #0x0
    59d4:      	mov	w11, #0x6               // =6
    59d8:      	ldp	x8, x9, [x10, #0x20]
    59dc:      	add	x0, sp, #0x18
    59e0:      	mov	w1, #0x35               // =53
    59e4:      	mov	x2, x25
    59e8:      	stp	x8, x9, [sp, #0x38]
    59ec:      	ldur	x8, [x10, #0x2d]
    59f0:      	stur	x8, [sp, #0x45]
    59f4:      	ldp	x8, x9, [x10]
    59f8:      	stp	x8, x9, [sp, #0x18]
    59fc:      	ldp	x9, x8, [x10, #0x10]
    5a00:      	mov	w10, #0x35              // =53
    5a04:      	stp	x9, x8, [sp, #0x28]
    5a08:      	add	x8, sp, #0x18
    5a0c:      	blr	x11
    5a10:      	mov	w25, #0x25              // =37
    5a14:      	b	0x5b08 <kprobe_unwind_php+0x5b08>
    5a18:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5a1c:      	add	x10, x10, #0x0
    5a20:      	strb	wzr, [sp, #0x50]
    5a24:      	add	x0, sp, #0x18
    5a28:      	ldp	x8, x9, [x10, #0x20]
    5a2c:      	mov	w1, #0x39               // =57
    5a30:      	stp	x8, x9, [sp, #0x38]
    5a34:      	ldr	x8, [x10, #0x30]
    5a38:      	str	x8, [sp, #0x48]
    5a3c:      	ldp	x8, x9, [x10]
    5a40:      	stp	x8, x9, [sp, #0x18]
    5a44:      	ldp	x9, x8, [x10, #0x10]
    5a48:      	add	x10, sp, #0x18
    5a4c:      	stp	x9, x8, [sp, #0x28]
    5a50:      	mov	w8, #0x39               // =57
    5a54:      	mov	w9, #0x6                // =6
    5a58:      	ldr	x8, [sp, #0x68]
    5a5c:      	ldrb	w10, [x24, #0x15]
    5a60:      	add	x2, x8, x10
    5a64:      	blr	x9
    5a68:      	mov	w25, #0x27              // =39
    5a6c:      	b	0x5b08 <kprobe_unwind_php+0x5b08>
    5a70:      	ldr	w29, [sp, #0x88]
    5a74:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5a78:      	ldr	w25, [sp, #0x5c]
    5a7c:      	ldr	x8, [x8]
    5a80:      	ldr	w8, [x8]
    5a84:      	cbz	w8, 0x5ac0 <kprobe_unwind_php+0x5ac0>
    5a88:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5a8c:      	add	x10, x10, #0x0
    5a90:      	add	x0, sp, #0x18
    5a94:      	ldp	x8, x9, [x10]
    5a98:      	mov	w1, #0x16               // =22
    5a9c:      	stp	x8, x9, [sp, #0x18]
    5aa0:      	ldur	x8, [x10, #0xe]
    5aa4:      	mov	w9, #0x6                // =6
    5aa8:      	add	x10, sp, #0x18
    5aac:      	stur	x8, [sp, #0x26]
    5ab0:      	mov	w8, #0x16               // =22
    5ab4:      	ldr	x2, [sp, #0x70]
    5ab8:      	ldr	w3, [sp, #0x88]
    5abc:      	blr	x9
    5ac0:      	ldr	w8, [x21, #0x2c0]
    5ac4:      	cmp	w8, #0x7e
    5ac8:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    5acc:      	add	w9, w8, #0x1
    5ad0:      	mov	w10, w29
    5ad4:      	str	w9, [x21, #0x2c0]
    5ad8:      	mov	w9, #0x18               // =24
    5adc:      	orr	x10, x10, x25, lsl #32
    5ae0:      	umaddl	x8, w8, w9, x21
    5ae4:      	ldr	x9, [sp, #0x70]
    5ae8:      	str	x10, [x8, #0x2d8]
    5aec:      	str	x9, [x8, #0x2d0]
    5af0:      	ldr	w9, [sp, #0xc]
    5af4:      	strb	w9, [x8, #0x2e0]
    5af8:      	add	x9, x8, #0x2d0
    5afc:      	mov	w25, #0x23              // =35
    5b00:      	str	wzr, [x8, #0x2e4]
    5b04:      	stur	wzr, [x9, #0x11]
    5b08:      	str	w25, [sp, #0x70]
    5b0c:      	mov	w8, #0x1                // =1
    5b10:      	add	x9, sp, #0x70
    5b14:      	add	x1, sp, #0x70
    5b18:      	mov	x0, x23
    5b1c:      	blr	x8
    5b20:      	cbz	x0, 0x5b34 <kprobe_unwind_php+0x5b34>
    5b24:      	ldr	x8, [x0]
    5b28:      	add	x8, x8, #0x1
    5b2c:      	str	x8, [x0]
    5b30:      	b	0x5b88 <kprobe_unwind_php+0x5b88>
    5b34:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5b38:      	ldr	x8, [x8]
    5b3c:      	ldr	w8, [x8]
    5b40:      	cbz	w8, 0x5b88 <kprobe_unwind_php+0x5b88>
    5b44:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5b48:      	add	x8, x8, #0x0
    5b4c:      	add	x0, sp, #0x18
    5b50:      	ldp	x9, x10, [x8, #0x10]
    5b54:      	mov	w1, #0x2e               // =46
    5b58:      	stp	x9, x10, [sp, #0x28]
    5b5c:      	ldr	x9, [x8, #0x20]
    5b60:      	add	x10, sp, #0x18
    5b64:      	str	x9, [sp, #0x38]
    5b68:      	ldur	x9, [x8, #0x26]
    5b6c:      	stur	x9, [sp, #0x3e]
    5b70:      	ldp	x9, x8, [x8]
    5b74:      	stp	x9, x8, [sp, #0x18]
    5b78:      	mov	w8, #0x2e               // =46
    5b7c:      	mov	w9, #0x6                // =6
    5b80:      	ldr	w2, [sp, #0x70]
    5b84:      	blr	x9
    5b88:      	cmp	w25, #0x23
    5b8c:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    5b90:      	ldr	x8, [sp, #0x60]
    5b94:      	ldrb	w9, [x24, #0x12]
    5b98:      	mov	w10, #0x70              // =112
    5b9c:      	add	x11, sp, #0x60
    5ba0:      	add	x0, sp, #0x60
    5ba4:      	mov	w1, #0x8                // =8
    5ba8:      	add	x8, x8, x9
    5bac:      	mov	w9, #0x8                // =8
    5bb0:      	ldr	x8, [sp, #0x60]
    5bb4:      	ldrb	w9, [x24, #0x12]
    5bb8:      	add	x2, x8, x9
    5bbc:      	blr	x10
    5bc0:      	adrp	x29, 0x5000 <kprobe_unwind_php+0x5000>
    5bc4:      	ldr	x29, [x29]
    5bc8:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    5bcc:      	ldr	x25, [sp, #0x60]
    5bd0:      	cbz	x25, 0x6084 <kprobe_unwind_php+0x6084>
    5bd4:      	ldrb	w8, [sp, #0x5e]
    5bd8:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    5bdc:      	ldrb	w8, [x24, #0x10]
    5be0:      	mov	w9, #0x8                // =8
    5be4:      	mov	w10, #0x70              // =112
    5be8:      	add	x11, sp, #0x70
    5bec:      	add	x0, sp, #0x70
    5bf0:      	mov	w1, #0x8                // =8
    5bf4:      	add	x8, x25, x8
    5bf8:      	ldrb	w8, [x24, #0x10]
    5bfc:      	add	x2, x25, x8
    5c00:      	blr	x10
    5c04:      	cbz	x0, 0x5c6c <kprobe_unwind_php+0x5c6c>
    5c08:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5c0c:      	ldr	x8, [x8]
    5c10:      	ldr	w8, [x8]
    5c14:      	cbz	w8, 0x5eb0 <kprobe_unwind_php+0x5eb0>
    5c18:      	mov	w8, #0x2978             // =10616
    5c1c:      	add	x0, sp, #0x18
    5c20:      	mov	w1, #0x33               // =51
    5c24:      	movk	w8, #0xa, lsl #16
    5c28:      	stur	w8, [sp, #0x47]
    5c2c:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5c30:      	add	x8, x8, #0x0
    5c34:      	ldp	x9, x10, [x8, #0x10]
    5c38:      	stp	x9, x10, [sp, #0x28]
    5c3c:      	ldp	x9, x10, [x8, #0x20]
    5c40:      	stp	x9, x10, [sp, #0x38]
    5c44:      	ldp	x9, x8, [x8]
    5c48:      	add	x10, sp, #0x18
    5c4c:      	stp	x9, x8, [sp, #0x18]
    5c50:      	mov	w8, #0x33               // =51
    5c54:      	mov	w9, #0x6                // =6
    5c58:      	ldrb	w8, [x24, #0x10]
    5c5c:      	add	x2, x25, x8
    5c60:      	blr	x9
    5c64:      	mov	w25, #0x25              // =37
    5c68:      	b	0x5fa8 <kprobe_unwind_php+0x5fa8>
    5c6c:      	ldr	x8, [sp, #0x70]
    5c70:      	cbz	x8, 0x5cfc <kprobe_unwind_php+0x5cfc>
    5c74:      	ldrb	w9, [x24, #0x14]
    5c78:      	mov	w10, #0x70              // =112
    5c7c:      	add	x11, sp, #0x8c
    5c80:      	add	x0, sp, #0x8c
    5c84:      	mov	w1, #0x1                // =1
    5c88:      	add	x8, x8, x9
    5c8c:      	mov	w9, #0x1                // =1
    5c90:      	ldr	x8, [sp, #0x70]
    5c94:      	ldrb	w9, [x24, #0x14]
    5c98:      	add	x2, x8, x9
    5c9c:      	blr	x10
    5ca0:      	cbz	x0, 0x5d3c <kprobe_unwind_php+0x5d3c>
    5ca4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5ca8:      	ldr	x8, [x8]
    5cac:      	ldr	w8, [x8]
    5cb0:      	cbz	w8, 0x5cf4 <kprobe_unwind_php+0x5cf4>
    5cb4:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5cb8:      	add	x10, x10, #0x0
    5cbc:      	strb	wzr, [sp, #0x48]
    5cc0:      	add	x0, sp, #0x18
    5cc4:      	ldp	x8, x9, [x10, #0x10]
    5cc8:      	mov	w1, #0x31               // =49
    5ccc:      	stp	x8, x9, [sp, #0x28]
    5cd0:      	ldp	x8, x9, [x10, #0x20]
    5cd4:      	stp	x8, x9, [sp, #0x38]
    5cd8:      	ldp	x8, x9, [x10]
    5cdc:      	add	x10, sp, #0x18
    5ce0:      	stp	x8, x9, [sp, #0x18]
    5ce4:      	mov	w8, #0x31               // =49
    5ce8:      	mov	w9, #0x6                // =6
    5cec:      	ldr	x2, [sp, #0x70]
    5cf0:      	blr	x9
    5cf4:      	mov	w25, #0x26              // =38
    5cf8:      	b	0x5fa8 <kprobe_unwind_php+0x5fa8>
    5cfc:      	ldr	w8, [x21, #0x2c0]
    5d00:      	adrp	x29, 0x5000 <kprobe_unwind_php+0x5000>
    5d04:      	ldr	x29, [x29]
    5d08:      	cmp	w8, #0x7e
    5d0c:      	b.hi	0x394 <kprobe_unwind_php+0x394>
    5d10:      	add	w9, w8, #0x1
    5d14:      	mov	x10, #-0x2              // =-2
    5d18:      	str	w9, [x21, #0x2c0]
    5d1c:      	mov	w9, #0x18               // =24
    5d20:      	umaddl	x8, w8, w9, x21
    5d24:      	add	x9, x8, #0x2d0
    5d28:      	str	x10, [x8, #0x2d8]
    5d2c:      	mov	w10, #0x2               // =2
    5d30:      	str	xzr, [x8, #0x2d0]
    5d34:      	strb	w10, [x8, #0x2e0]
    5d38:      	b	0x5f9c <kprobe_unwind_php+0x5f9c>
    5d3c:      	ldrb	w8, [sp, #0x8c]
    5d40:      	str	wzr, [sp, #0x88]
    5d44:      	cmp	w8, #0x4
    5d48:      	b.eq	0x5d58 <kprobe_unwind_php+0x5d58>
    5d4c:      	mov	w29, wzr
    5d50:      	cmp	w8, #0x2
    5d54:      	b.ne	0x5f14 <kprobe_unwind_php+0x5f14>
    5d58:      	ldrb	w8, [x24, #0x11]
    5d5c:      	mov	w9, #0x8                // =8
    5d60:      	mov	w10, #0x70              // =112
    5d64:      	add	x11, sp, #0x68
    5d68:      	add	x0, sp, #0x68
    5d6c:      	mov	w1, #0x8                // =8
    5d70:      	add	x8, x25, x8
    5d74:      	ldrb	w8, [x24, #0x11]
    5d78:      	add	x2, x25, x8
    5d7c:      	blr	x10
    5d80:      	cbz	x0, 0x5de4 <kprobe_unwind_php+0x5de4>
    5d84:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5d88:      	ldr	x8, [x8]
    5d8c:      	ldr	w8, [x8]
    5d90:      	cbz	w8, 0x5eb0 <kprobe_unwind_php+0x5eb0>
    5d94:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5d98:      	add	x10, x10, #0x0
    5d9c:      	add	x0, sp, #0x18
    5da0:      	ldp	x8, x9, [x10, #0x10]
    5da4:      	mov	w1, #0x2d               // =45
    5da8:      	stp	x8, x9, [sp, #0x28]
    5dac:      	ldr	x8, [x10, #0x20]
    5db0:      	str	x8, [sp, #0x38]
    5db4:      	ldur	x8, [x10, #0x25]
    5db8:      	stur	x8, [sp, #0x3d]
    5dbc:      	ldp	x8, x9, [x10]
    5dc0:      	add	x10, sp, #0x18
    5dc4:      	stp	x8, x9, [sp, #0x18]
    5dc8:      	mov	w8, #0x2d               // =45
    5dcc:      	mov	w9, #0x6                // =6
    5dd0:      	ldrb	w8, [x24, #0x11]
    5dd4:      	add	x2, x25, x8
    5dd8:      	blr	x9
    5ddc:      	mov	w25, #0x25              // =37
    5de0:      	b	0x5fa8 <kprobe_unwind_php+0x5fa8>
    5de4:      	ldr	x8, [sp, #0x68]
    5de8:      	ldrb	w9, [x24, #0x15]
    5dec:      	mov	w10, #0x70              // =112
    5df0:      	add	x11, sp, #0x88
    5df4:      	add	x0, sp, #0x88
    5df8:      	mov	w1, #0x4                // =4
    5dfc:      	add	x8, x8, x9
    5e00:      	mov	w9, #0x4                // =4
    5e04:      	ldr	x8, [sp, #0x68]
    5e08:      	ldrb	w9, [x24, #0x15]
    5e0c:      	add	x2, x8, x9
    5e10:      	blr	x10
    5e14:      	cbz	x0, 0x5e30 <kprobe_unwind_php+0x5e30>
    5e18:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5e1c:      	ldr	x8, [x8]
    5e20:      	ldr	w8, [x8]
    5e24:      	cbnz	w8, 0x5eb8 <kprobe_unwind_php+0x5eb8>
    5e28:      	mov	w25, #0x27              // =39
    5e2c:      	b	0x5fa8 <kprobe_unwind_php+0x5fa8>
    5e30:      	ldrb	w8, [x24, #0x13]
    5e34:      	mov	w9, #0x4                // =4
    5e38:      	mov	w10, #0x70              // =112
    5e3c:      	add	x11, sp, #0x5c
    5e40:      	add	x0, sp, #0x5c
    5e44:      	mov	w1, #0x4                // =4
    5e48:      	add	x8, x25, x8
    5e4c:      	ldrb	w8, [x24, #0x13]
    5e50:      	add	x2, x25, x8
    5e54:      	blr	x10
    5e58:      	cbz	x0, 0x5f10 <kprobe_unwind_php+0x5f10>
    5e5c:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5e60:      	ldr	x8, [x8]
    5e64:      	ldr	w8, [x8]
    5e68:      	cbz	w8, 0x5eb0 <kprobe_unwind_php+0x5eb0>
    5e6c:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5e70:      	add	x10, x10, #0x0
    5e74:      	mov	w11, #0x6               // =6
    5e78:      	ldp	x8, x9, [x10, #0x20]
    5e7c:      	add	x0, sp, #0x18
    5e80:      	mov	w1, #0x35               // =53
    5e84:      	mov	x2, x25
    5e88:      	stp	x8, x9, [sp, #0x38]
    5e8c:      	ldur	x8, [x10, #0x2d]
    5e90:      	stur	x8, [sp, #0x45]
    5e94:      	ldp	x8, x9, [x10]
    5e98:      	stp	x8, x9, [sp, #0x18]
    5e9c:      	ldp	x9, x8, [x10, #0x10]
    5ea0:      	mov	w10, #0x35              // =53
    5ea4:      	stp	x9, x8, [sp, #0x28]
    5ea8:      	add	x8, sp, #0x18
    5eac:      	blr	x11
    5eb0:      	mov	w25, #0x25              // =37
    5eb4:      	b	0x5fa8 <kprobe_unwind_php+0x5fa8>
    5eb8:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5ebc:      	add	x10, x10, #0x0
    5ec0:      	strb	wzr, [sp, #0x50]
    5ec4:      	add	x0, sp, #0x18
    5ec8:      	ldp	x8, x9, [x10, #0x20]
    5ecc:      	mov	w1, #0x39               // =57
    5ed0:      	stp	x8, x9, [sp, #0x38]
    5ed4:      	ldr	x8, [x10, #0x30]
    5ed8:      	str	x8, [sp, #0x48]
    5edc:      	ldp	x8, x9, [x10]
    5ee0:      	stp	x8, x9, [sp, #0x18]
    5ee4:      	ldp	x9, x8, [x10, #0x10]
    5ee8:      	add	x10, sp, #0x18
    5eec:      	stp	x9, x8, [sp, #0x28]
    5ef0:      	mov	w8, #0x39               // =57
    5ef4:      	mov	w9, #0x6                // =6
    5ef8:      	ldr	x8, [sp, #0x68]
    5efc:      	ldrb	w10, [x24, #0x15]
    5f00:      	add	x2, x8, x10
    5f04:      	blr	x9
    5f08:      	mov	w25, #0x27              // =39
    5f0c:      	b	0x5fa8 <kprobe_unwind_php+0x5fa8>
    5f10:      	ldr	w29, [sp, #0x88]
    5f14:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5f18:      	ldr	w25, [sp, #0x5c]
    5f1c:      	ldr	x8, [x8]
    5f20:      	ldr	w8, [x8]
    5f24:      	cbz	w8, 0x5f60 <kprobe_unwind_php+0x5f60>
    5f28:      	adrp	x10, 0x5000 <kprobe_unwind_php+0x5000>
    5f2c:      	add	x10, x10, #0x0
    5f30:      	add	x0, sp, #0x18
    5f34:      	ldp	x8, x9, [x10]
    5f38:      	mov	w1, #0x16               // =22
    5f3c:      	stp	x8, x9, [sp, #0x18]
    5f40:      	ldur	x8, [x10, #0xe]
    5f44:      	mov	w9, #0x6                // =6
    5f48:      	add	x10, sp, #0x18
    5f4c:      	stur	x8, [sp, #0x26]
    5f50:      	mov	w8, #0x16               // =22
    5f54:      	ldr	x2, [sp, #0x70]
    5f58:      	ldr	w3, [sp, #0x88]
    5f5c:      	blr	x9
    5f60:      	ldr	w8, [x21, #0x2c0]
    5f64:      	cmp	w8, #0x7e
    5f68:      	b.hi	0x82c <kprobe_unwind_php+0x82c>
    5f6c:      	add	w9, w8, #0x1
    5f70:      	mov	w10, w29
    5f74:      	str	w9, [x21, #0x2c0]
    5f78:      	mov	w9, #0x18               // =24
    5f7c:      	orr	x10, x10, x25, lsl #32
    5f80:      	umaddl	x8, w8, w9, x21
    5f84:      	ldr	x9, [sp, #0x70]
    5f88:      	str	x10, [x8, #0x2d8]
    5f8c:      	str	x9, [x8, #0x2d0]
    5f90:      	ldr	w9, [sp, #0xc]
    5f94:      	strb	w9, [x8, #0x2e0]
    5f98:      	add	x9, x8, #0x2d0
    5f9c:      	mov	w25, #0x23              // =35
    5fa0:      	str	wzr, [x8, #0x2e4]
    5fa4:      	stur	wzr, [x9, #0x11]
    5fa8:      	str	w25, [sp, #0x70]
    5fac:      	mov	w8, #0x1                // =1
    5fb0:      	add	x9, sp, #0x70
    5fb4:      	add	x1, sp, #0x70
    5fb8:      	mov	x0, x23
    5fbc:      	blr	x8
    5fc0:      	cbz	x0, 0x5fd4 <kprobe_unwind_php+0x5fd4>
    5fc4:      	ldr	x8, [x0]
    5fc8:      	add	x8, x8, #0x1
    5fcc:      	str	x8, [x0]
    5fd0:      	b	0x6028 <kprobe_unwind_php+0x6028>
    5fd4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5fd8:      	ldr	x8, [x8]
    5fdc:      	ldr	w8, [x8]
    5fe0:      	cbz	w8, 0x6028 <kprobe_unwind_php+0x6028>
    5fe4:      	adrp	x8, 0x5000 <kprobe_unwind_php+0x5000>
    5fe8:      	add	x8, x8, #0x0
    5fec:      	add	x0, sp, #0x18
    5ff0:      	ldp	x9, x10, [x8, #0x10]
    5ff4:      	mov	w1, #0x2e               // =46
    5ff8:      	stp	x9, x10, [sp, #0x28]
    5ffc:      	ldr	x9, [x8, #0x20]
    6000:      	add	x10, sp, #0x18
    6004:      	str	x9, [sp, #0x38]
    6008:      	ldur	x9, [x8, #0x26]
    600c:      	stur	x9, [sp, #0x3e]
    6010:      	ldp	x9, x8, [x8]
    6014:      	stp	x9, x8, [sp, #0x18]
    6018:      	mov	w8, #0x2e               // =46
    601c:      	mov	w9, #0x6                // =6
    6020:      	ldr	w2, [sp, #0x70]
    6024:      	blr	x9
    6028:      	cmp	w25, #0x23
    602c:      	b.ne	0x61f4 <kprobe_unwind_php+0x61f4>
    6030:      	ldr	x8, [sp, #0x60]
    6034:      	ldrb	w9, [x24, #0x12]
    6038:      	mov	w10, #0x70              // =112
    603c:      	add	x11, sp, #0x60
    6040:      	add	x0, sp, #0x60
    6044:      	mov	w1, #0x8                // =8
    6048:      	add	x8, x8, x9
    604c:      	mov	w9, #0x8                // =8
    6050:      	ldr	x8, [sp, #0x60]
    6054:      	ldrb	w9, [x24, #0x12]
    6058:      	add	x2, x8, x9
    605c:      	blr	x10
    6060:      	adrp	x29, 0x6000 <kprobe_unwind_php+0x6000>
    6064:      	ldr	x29, [x29]
    6068:      	cbnz	x0, 0x2d0 <kprobe_unwind_php+0x2d0>
    606c:      	ldr	x8, [sp, #0x60]
    6070:      	cbz	x8, 0x6084 <kprobe_unwind_php+0x6084>
    6074:      	ldrb	w8, [sp, #0x5e]
    6078:      	tbnz	w8, #0x1, 0x6084 <kprobe_unwind_php+0x6084>
    607c:      	mov	w23, #0x5               // =5
    6080:      	b	0x6258 <kprobe_unwind_php+0x6258>
    6084:      	ldr	w8, [x29]
    6088:      	cbnz	w8, 0x6204 <kprobe_unwind_php+0x6204>
    608c:      	ldr	w8, [sp, #0x10]
    6090:      	cbz	w8, 0x6254 <kprobe_unwind_php+0x6254>
    6094:      	ldr	x24, [x24, #0x8]
    6098:      	strb	wzr, [x21, #0xf20]
    609c:      	lsr	x8, x24, #56
    60a0:      	str	x24, [x21, #0xed0]
    60a4:      	cbz	x8, 0x60c0 <kprobe_unwind_php+0x60c0>
    60a8:      	ldr	w8, [x29]
    60ac:      	cbnz	w8, 0x6264 <kprobe_unwind_php+0x6264>
    60b0:      	mov	w8, #0xb                // =11
    60b4:      	mov	w23, wzr
    60b8:      	str	w8, [x21, #0xf18]
    60bc:      	b	0x6258 <kprobe_unwind_php+0x6258>
    60c0:      	cmp	x24, #0xfff
    60c4:      	b.hi	0x60e0 <kprobe_unwind_php+0x60e0>
    60c8:      	ldr	w8, [x29]
    60cc:      	cbnz	w8, 0x62a4 <kprobe_unwind_php+0x62a4>
    60d0:      	mov	w8, #0x31               // =49
    60d4:      	mov	w23, wzr
    60d8:      	str	w8, [x21, #0xf18]
    60dc:      	b	0x6258 <kprobe_unwind_php+0x6258>
    60e0:      	ldr	w8, [x21]
    60e4:      	mov	w9, #0x60               // =96
    60e8:      	adrp	x0, 0x6000 <kprobe_unwind_php+0x6000>
    60ec:      	add	x1, sp, #0x70
    60f0:      	rev	w8, w8
    60f4:      	stp	w9, w8, [sp, #0x70]
    60f8:      	rev	x8, x24
    60fc:      	add	x9, sp, #0x70
    6100:      	str	x8, [sp, #0x78]
    6104:      	mov	w8, #0x1                // =1
    6108:      	ldr	x0, [x0]
    610c:      	blr	x8
    6110:      	cbz	x0, 0x61dc <kprobe_unwind_php+0x61dc>
    6114:      	ldr	x8, [x0, #0x8]
    6118:      	and	x9, x8, #0xffffffffffffff
    611c:      	lsr	x23, x8, #56
    6120:      	str	x9, [x21, #0xf10]
    6124:      	ldr	x8, [x0]
    6128:      	str	x8, [x21, #0xf00]
    612c:      	sub	x8, x24, x9
    6130:      	str	x8, [x21, #0xf08]
    6134:      	ldr	w8, [x29]
    6138:      	cbz	w8, 0x6258 <kprobe_unwind_php+0x6258>
    613c:      	mov	w8, #0xa                // =10
    6140:      	add	x0, sp, #0x18
    6144:      	mov	w1, #0x32               // =50
    6148:      	strh	w8, [sp, #0x48]
    614c:      	adrp	x8, 0x6000 <kprobe_unwind_php+0x6000>
    6150:      	add	x8, x8, #0x0
    6154:      	mov	x2, x24
    6158:      	ldp	x9, x10, [x8, #0x10]
    615c:      	mov	w4, w23
    6160:      	stp	x9, x10, [sp, #0x28]
    6164:      	ldp	x9, x10, [x8, #0x20]
    6168:      	stp	x9, x10, [sp, #0x38]
    616c:      	ldp	x9, x8, [x8]
    6170:      	add	x10, sp, #0x18
    6174:      	stp	x9, x8, [sp, #0x18]
    6178:      	mov	w8, #0x32               // =50
    617c:      	mov	w9, #0x6                // =6
    6180:      	ldr	x3, [x21, #0xf00]
    6184:      	blr	x9
    6188:      	ldr	w8, [x29]
    618c:      	cbz	w8, 0x6258 <kprobe_unwind_php+0x6258>
    6190:      	adrp	x8, 0x6000 <kprobe_unwind_php+0x6000>
    6194:      	add	x8, x8, #0x0
    6198:      	add	x0, sp, #0x18
    619c:      	ldp	x9, x10, [x8, #0x10]
    61a0:      	mov	w1, #0x2f               // =47
    61a4:      	stp	x9, x10, [sp, #0x28]
    61a8:      	ldr	x9, [x8, #0x20]
    61ac:      	add	x10, sp, #0x18
    61b0:      	str	x9, [sp, #0x38]
    61b4:      	ldur	x9, [x8, #0x27]
    61b8:      	stur	x9, [sp, #0x3f]
    61bc:      	ldp	x9, x8, [x8]
    61c0:      	stp	x9, x8, [sp, #0x18]
    61c4:      	mov	w8, #0x2f               // =47
    61c8:      	mov	w9, #0x6                // =6
    61cc:      	ldr	x2, [x21, #0xf10]
    61d0:      	ldr	x3, [x21, #0xf08]
    61d4:      	blr	x9
    61d8:      	b	0x6258 <kprobe_unwind_php+0x6258>
    61dc:      	ldr	w8, [x29]
    61e0:      	cbnz	w8, 0x62e4 <kprobe_unwind_php+0x62e4>
    61e4:      	mov	w8, #0xc                // =12
    61e8:      	mov	w23, wzr
    61ec:      	str	w8, [x21, #0xf18]
    61f0:      	b	0x6258 <kprobe_unwind_php+0x6258>
    61f4:      	adrp	x29, 0x6000 <kprobe_unwind_php+0x6000>
    61f8:      	mov	w23, #0x5               // =5
    61fc:      	ldr	x29, [x29]
    6200:      	b	0x418 <kprobe_unwind_php+0x418>
    6204:      	mov	w8, #0x786c             // =30828
    6208:      	add	x0, sp, #0x18
    620c:      	mov	w1, #0x2c               // =44
    6210:      	movk	w8, #0xa, lsl #16
    6214:      	str	w8, [sp, #0x40]
    6218:      	adrp	x8, 0x6000 <kprobe_unwind_php+0x6000>
    621c:      	add	x8, x8, #0x0
    6220:      	ldp	x9, x10, [x8, #0x10]
    6224:      	stp	x9, x10, [sp, #0x28]
    6228:      	ldr	x9, [x8, #0x20]
    622c:      	add	x10, sp, #0x18
    6230:      	str	x9, [sp, #0x38]
    6234:      	ldp	x8, x9, [x8]
    6238:      	stp	x8, x9, [sp, #0x18]
    623c:      	mov	w8, #0x2c               // =44
    6240:      	mov	w9, #0x6                // =6
    6244:      	ldr	x2, [sp, #0x60]
    6248:      	blr	x9
    624c:      	ldr	w8, [sp, #0x10]
    6250:      	cbnz	w8, 0x6094 <kprobe_unwind_php+0x6094>
    6254:      	mov	w23, #0x1               // =1
    6258:      	ldr	x8, [sp, #0x60]
    625c:      	cbnz	x8, 0x428 <kprobe_unwind_php+0x428>
    6260:      	b	0x418 <kprobe_unwind_php+0x418>
    6264:      	mov	w8, #0xa                // =10
    6268:      	add	x0, sp, #0x18
    626c:      	mov	w1, #0x22               // =34
    6270:      	strh	w8, [sp, #0x38]
    6274:      	adrp	x8, 0x6000 <kprobe_unwind_php+0x6000>
    6278:      	add	x8, x8, #0x0
    627c:      	mov	x2, x24
    6280:      	ldp	x9, x10, [x8]
    6284:      	stp	x9, x10, [sp, #0x18]
    6288:      	ldp	x9, x8, [x8, #0x10]
    628c:      	add	x10, sp, #0x18
    6290:      	stp	x9, x8, [sp, #0x28]
    6294:      	mov	w8, #0x22               // =34
    6298:      	mov	w9, #0x6                // =6
    629c:      	blr	x9
    62a0:      	b	0x60b0 <kprobe_unwind_php+0x60b0>
    62a4:      	adrp	x8, 0x6000 <kprobe_unwind_php+0x6000>
    62a8:      	add	x8, x8, #0x0
    62ac:      	add	x0, sp, #0x18
    62b0:      	ldp	x9, x10, [x8]
    62b4:      	mov	w1, #0x1e               // =30
    62b8:      	mov	x2, x24
    62bc:      	stp	x9, x10, [sp, #0x18]
    62c0:      	ldr	x9, [x8, #0x10]
    62c4:      	ldur	x8, [x8, #0x16]
    62c8:      	add	x10, sp, #0x18
    62cc:      	str	x9, [sp, #0x28]
    62d0:      	stur	x8, [sp, #0x2e]
    62d4:      	mov	w8, #0x1e               // =30
    62d8:      	mov	w9, #0x6                // =6
    62dc:      	blr	x9
    62e0:      	b	0x60d0 <kprobe_unwind_php+0x60d0>
    62e4:      	adrp	x8, 0x6000 <kprobe_unwind_php+0x6000>
    62e8:      	add	x8, x8, #0x0
    62ec:      	strb	wzr, [sp, #0x50]
    62f0:      	add	x0, sp, #0x18
    62f4:      	ldp	x9, x10, [x8, #0x20]
    62f8:      	mov	w1, #0x39               // =57
    62fc:      	mov	x2, x24
    6300:      	stp	x9, x10, [sp, #0x38]
    6304:      	ldr	x9, [x8, #0x30]
    6308:      	str	x9, [sp, #0x48]
    630c:      	ldp	x9, x10, [x8]
    6310:      	stp	x9, x10, [sp, #0x18]
    6314:      	ldp	x8, x9, [x8, #0x10]
    6318:      	add	x10, sp, #0x18
    631c:      	stp	x8, x9, [sp, #0x28]
    6320:      	mov	w8, #0x39               // =57
    6324:      	mov	w9, #0x6                // =6
    6328:      	blr	x9
    632c:      	b	0x61e4 <kprobe_unwind_php+0x61e4>
