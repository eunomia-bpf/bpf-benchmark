
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_output_v61.native.o:	file format elf64-littleaarch64

Disassembly of section lsm/generic_lsm_output:

0000000000000000 <generic_lsm_output>:
       0:      	sub	sp, sp, #0xc0
       4:      	str	x29, [sp, #0x70]
       8:      	stp	x30, x25, [sp, #0x80]
       c:      	stp	x24, x23, [sp, #0x90]
      10:      	stp	x22, x21, [sp, #0xa0]
      14:      	stp	x20, x19, [sp, #0xb0]
      18:      	str	wzr, [sp]
      1c:      	adrp	x20, 0x0 <generic_lsm_output>
      20:      	mov	w8, #0x1                // =1
      24:      	mov	x9, sp
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	mov	x1, sp
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x6e4 <generic_lsm_output+0x6e4>
      40:      	ldrb	w8, [x0, #0x1]
      44:      	mov	x21, x0
      48:      	tbz	w8, #0x3, 0xdc <generic_lsm_output+0xdc>
      4c:      	mov	w8, #0xe                // =14
      50:      	blr	x8
      54:      	str	x0, [sp, #0x28]
      58:      	adrp	x22, 0x0 <generic_lsm_output>
      5c:      	mov	w8, #0x1                // =1
      60:      	add	x9, sp, #0x28
      64:      	ldr	x22, [x22]
      68:      	add	x1, sp, #0x28
      6c:      	mov	x0, x22
      70:      	blr	x8
      74:      	cbz	x0, 0xdc <generic_lsm_output+0xdc>
      78:      	ldrb	w8, [x0]
      7c:      	mov	x2, x0
      80:      	cmp	w8, #0x2
      84:      	b.ne	0xdc <generic_lsm_output+0xdc>
      88:      	ldr	w8, [x21, #0x4]
      8c:      	mov	w9, #0x3fbd             // =16317
      90:      	cmp	w8, w9
      94:      	b.hi	0xc8 <generic_lsm_output+0xc8>
      98:      	add	x9, x21, #0x90
      9c:      	mov	w10, #0x42              // =66
      a0:      	mov	w11, #0x4               // =4
      a4:      	mov	w1, #0x42               // =66
      a8:      	add	x8, x9, x8
      ac:      	ldr	w8, [x21, #0x4]
      b0:      	and	x8, x8, #0x3fff
      b4:      	add	x0, x9, x8
      b8:      	blr	x11
      bc:      	ldr	w8, [x21, #0x4]
      c0:      	add	w8, w8, #0x42
      c4:      	str	w8, [x21, #0x4]
      c8:      	mov	w8, #0x3                // =3
      cc:      	add	x9, sp, #0x28
      d0:      	add	x1, sp, #0x28
      d4:      	mov	x0, x22
      d8:      	blr	x8
      dc:      	mov	w8, #0x5f08             // =24328
      e0:      	ldrb	w8, [x21, x8]
      e4:      	cbz	w8, 0x690 <generic_lsm_output+0x690>
      e8:      	str	wzr, [sp, #0x4]
      ec:      	mov	w8, #0x1                // =1
      f0:      	add	x9, sp, #0x4
      f4:      	add	x1, sp, #0x4
      f8:      	mov	x0, x20
      fc:      	blr	x8
     100:      	cbz	x0, 0x690 <generic_lsm_output+0x690>
     104:      	adrp	x21, 0x0 <generic_lsm_output>
     108:      	ldr	x8, [x0, #0x5ee8]
     10c:      	mov	x20, x0
     110:      	ldr	x21, [x21]
     114:      	cbz	x8, 0x3a0 <generic_lsm_output+0x3a0>
     118:      	mov	w8, #0xe                // =14
     11c:      	blr	x8
     120:      	mov	w8, #0x23               // =35
     124:      	lsr	x22, x0, #32
     128:      	blr	x8
     12c:      	str	w22, [sp, #0x28]
     130:      	mov	w8, #0x1                // =1
     134:      	add	x9, sp, #0x28
     138:      	mov	x23, x0
     13c:      	add	x1, sp, #0x28
     140:      	mov	x0, x21
     144:      	blr	x8
     148:      	cbz	x0, 0x3a0 <generic_lsm_output+0x3a0>
     14c:      	add	x2, x23, #0xb50
     150:      	mov	w29, #0x8               // =8
     154:      	add	x8, sp, #0x78
     158:      	mov	w9, #0x4                // =4
     15c:      	mov	x22, x0
     160:      	add	x24, x0, #0x28
     164:      	add	x0, sp, #0x78
     168:      	mov	w1, #0x8                // =8
     16c:      	mov	w25, #0x4               // =4
     170:      	blr	x9
     174:      	ldr	x8, [sp, #0x78]
     178:      	mov	w9, #0x48               // =72
     17c:      	add	x10, sp, #0x28
     180:      	mov	w11, #0x4               // =4
     184:      	ldr	x2, [sp, #0x78]
     188:      	add	x0, sp, #0x28
     18c:      	mov	w1, #0x48               // =72
     190:      	blr	x11
     194:      	ldr	x8, [sp, #0x30]
     198:      	mov	w9, #0x4                // =4
     19c:      	mov	x0, x24
     1a0:      	mov	w1, #0x4                // =4
     1a4:      	add	x8, x8, #0x218
     1a8:      	ldr	x8, [sp, #0x30]
     1ac:      	add	x2, x8, #0x218
     1b0:      	blr	x9
     1b4:      	ldr	x8, [sp, #0x38]
     1b8:      	add	x0, x22, #0x2c
     1bc:      	mov	w9, #0x4                // =4
     1c0:      	mov	w1, #0x4                // =4
     1c4:      	add	x8, x8, #0x4d8
     1c8:      	ldr	x8, [sp, #0x38]
     1cc:      	add	x2, x8, #0x4d8
     1d0:      	blr	x9
     1d4:      	ldr	x8, [sp, #0x40]
     1d8:      	add	x0, x22, #0x30
     1dc:      	mov	w9, #0x4                // =4
     1e0:      	mov	w1, #0x4                // =4
     1e4:      	add	x8, x8, #0x58
     1e8:      	ldr	x8, [sp, #0x40]
     1ec:      	add	x2, x8, #0x58
     1f0:      	blr	x9
     1f4:      	str	xzr, [sp, #0x20]
     1f8:      	add	x2, x23, #0x938
     1fc:      	add	x8, sp, #0x20
     200:      	add	x0, sp, #0x20
     204:      	mov	w1, #0x8                // =8
     208:      	blr	x25
     20c:      	ldr	x8, [sp, #0x20]
     210:      	cbz	x8, 0x294 <generic_lsm_output+0x294>
     214:      	str	wzr, [sp, #0x1c]
     218:      	add	x8, x8, #0x4
     21c:      	add	x9, sp, #0x1c
     220:      	mov	w10, #0x4               // =4
     224:      	add	x0, sp, #0x1c
     228:      	mov	w1, #0x4                // =4
     22c:      	mov	w24, #0x4               // =4
     230:      	ldr	x8, [sp, #0x20]
     234:      	add	x2, x8, #0x4
     238:      	blr	x10
     23c:      	ldr	x8, [sp, #0x20]
     240:      	ldrsw	x9, [sp, #0x1c]
     244:      	add	x10, sp, #0x8
     248:      	mov	w11, #0x4               // =4
     24c:      	add	x0, sp, #0x8
     250:      	mov	w1, #0x10               // =16
     254:      	add	x8, x8, x9, lsl #4
     258:      	mov	w9, #0x10               // =16
     25c:      	add	x8, x8, #0x80
     260:      	ldr	x8, [sp, #0x20]
     264:      	ldrsw	x9, [sp, #0x1c]
     268:      	add	x8, x8, x9, lsl #4
     26c:      	add	x2, x8, #0x80
     270:      	blr	x11
     274:      	ldr	x8, [sp, #0x10]
     278:      	add	x0, x22, #0x34
     27c:      	mov	w1, #0x4                // =4
     280:      	add	x8, x8, #0x158
     284:      	ldr	x8, [sp, #0x10]
     288:      	add	x2, x8, #0x158
     28c:      	blr	x24
     290:      	b	0x298 <generic_lsm_output+0x298>
     294:      	str	wzr, [x22, #0x34]
     298:      	ldr	x8, [sp, #0x48]
     29c:      	add	x0, x22, #0x38
     2a0:      	mov	w9, #0x4                // =4
     2a4:      	mov	w1, #0x4                // =4
     2a8:      	mov	w24, #0x4               // =4
     2ac:      	add	x8, x8, #0x158
     2b0:      	ldr	x8, [sp, #0x48]
     2b4:      	add	x2, x8, #0x158
     2b8:      	blr	x9
     2bc:      	ldr	x8, [sp, #0x50]
     2c0:      	add	x0, x22, #0x3c
     2c4:      	mov	w9, #0x4                // =4
     2c8:      	mov	w1, #0x4                // =4
     2cc:      	add	x8, x8, #0x118
     2d0:      	ldr	x8, [sp, #0x50]
     2d4:      	add	x2, x8, #0x118
     2d8:      	blr	x9
     2dc:      	ldr	x8, [sp, #0x58]
     2e0:      	add	x0, x22, #0x40
     2e4:      	mov	w9, #0x4                // =4
     2e8:      	mov	w1, #0x4                // =4
     2ec:      	add	x8, x8, #0x98
     2f0:      	ldr	x8, [sp, #0x58]
     2f4:      	add	x2, x8, #0x98
     2f8:      	blr	x9
     2fc:      	ldr	x8, [sp, #0x60]
     300:      	add	x0, x22, #0x44
     304:      	mov	w9, #0x4                // =4
     308:      	mov	w1, #0x4                // =4
     30c:      	add	x8, x8, #0x98
     310:      	ldr	x8, [sp, #0x60]
     314:      	add	x2, x8, #0x98
     318:      	blr	x9
     31c:      	ldr	x8, [sp, #0x68]
     320:      	add	x0, x22, #0x48
     324:      	mov	w9, #0x4                // =4
     328:      	mov	w1, #0x4                // =4
     32c:      	add	x8, x8, #0x58
     330:      	ldr	x8, [sp, #0x68]
     334:      	add	x2, x8, #0x58
     338:      	blr	x9
     33c:      	str	xzr, [sp, #0x8]
     340:      	str	xzr, [sp, #0x20]
     344:      	add	x2, x23, #0xae0
     348:      	mov	w23, #0x8               // =8
     34c:      	add	x8, sp, #0x8
     350:      	mov	w9, #0x4                // =4
     354:      	add	x0, sp, #0x8
     358:      	mov	w1, #0x8                // =8
     35c:      	blr	x9
     360:      	ldr	x8, [sp, #0x8]
     364:      	add	x9, sp, #0x20
     368:      	mov	w10, #0x4               // =4
     36c:      	add	x0, sp, #0x20
     370:      	mov	w1, #0x8                // =8
     374:      	add	x8, x8, #0x90
     378:      	ldr	x8, [sp, #0x8]
     37c:      	add	x2, x8, #0x90
     380:      	blr	x10
     384:      	ldr	x8, [sp, #0x20]
     388:      	add	x0, x22, #0x4c
     38c:      	mov	w1, #0x4                // =4
     390:      	add	x8, x8, #0x158
     394:      	ldr	x8, [sp, #0x20]
     398:      	add	x2, x8, #0x158
     39c:      	blr	x24
     3a0:      	ldr	x8, [x20, #0x5ef0]
     3a4:      	cbz	x8, 0x440 <generic_lsm_output+0x440>
     3a8:      	mov	w8, #0xe                // =14
     3ac:      	blr	x8
     3b0:      	mov	w8, #0x23               // =35
     3b4:      	lsr	x23, x0, #32
     3b8:      	blr	x8
     3bc:      	str	w23, [sp, #0x28]
     3c0:      	mov	w8, #0x1                // =1
     3c4:      	add	x9, sp, #0x28
     3c8:      	mov	x22, x0
     3cc:      	add	x1, sp, #0x28
     3d0:      	mov	x0, x21
     3d4:      	blr	x8
     3d8:      	cbz	x0, 0x440 <generic_lsm_output+0x440>
     3dc:      	add	x2, x22, #0xae0
     3e0:      	mov	w22, #0x8               // =8
     3e4:      	add	x8, sp, #0x28
     3e8:      	mov	w9, #0x4                // =4
     3ec:      	add	x21, x0, #0x50
     3f0:      	mov	x24, x0
     3f4:      	add	x0, sp, #0x28
     3f8:      	mov	w1, #0x8                // =8
     3fc:      	mov	w23, #0x4               // =4
     400:      	blr	x9
     404:      	ldr	x25, [sp, #0x28]
     408:      	add	x0, x24, #0x58
     40c:      	mov	w8, #0x4                // =4
     410:      	mov	w1, #0x8                // =8
     414:      	add	x2, x25, #0x40
     418:      	blr	x8
     41c:      	add	x0, x24, #0x60
     420:      	add	x2, x25, #0x30
     424:      	mov	w8, #0x4                // =4
     428:      	mov	w1, #0x8                // =8
     42c:      	blr	x8
     430:      	add	x2, x25, #0x38
     434:      	mov	x0, x21
     438:      	mov	w1, #0x8                // =8
     43c:      	blr	x23
     440:      	ldr	w8, [x20, #0x4]
     444:      	mov	w9, #0x2328             // =9000
     448:      	str	wzr, [sp, #0x8]
     44c:      	adrp	x0, 0x0 <generic_lsm_output>
     450:      	add	x1, sp, #0x8
     454:      	add	w8, w8, #0x90
     458:      	ldr	x0, [x0]
     45c:      	and	w8, w8, #0x7fff
     460:      	cmp	w8, w9
     464:      	csel	w21, w8, w9, lo
     468:      	mov	w8, #0x1                // =1
     46c:      	add	x9, sp, #0x8
     470:      	blr	x8
     474:      	cbz	x0, 0x4e0 <generic_lsm_output+0x4e0>
     478:      	ldrb	w8, [x0, #0x28]
     47c:      	cbz	w8, 0x4e0 <generic_lsm_output+0x4e0>
     480:      	adrp	x1, 0x0 <generic_lsm_output>
     484:      	mov	w8, #-0x1               // =-1
     488:      	mov	w9, #0x19               // =25
     48c:      	ldr	x1, [x1]
     490:      	mov	x0, x19
     494:      	mov	w2, #-0x1               // =-1
     498:      	mov	x3, x20
     49c:      	mov	x4, x21
     4a0:      	blr	x9
     4a4:      	tbnz	x0, #0x3f, 0x588 <generic_lsm_output+0x588>
     4a8:      	str	wzr, [sp, #0x28]
     4ac:      	adrp	x0, 0x0 <generic_lsm_output>
     4b0:      	mov	w8, #0x1                // =1
     4b4:      	add	x9, sp, #0x28
     4b8:      	ldr	x0, [x0]
     4bc:      	add	x1, sp, #0x28
     4c0:      	blr	x8
     4c4:      	cbz	x0, 0x690 <generic_lsm_output+0x690>
     4c8:      	add	x8, x0, #0x8
     4cc:      	ldaxr	x9, [x8]
     4d0:      	add	x9, x9, #0x1
     4d4:      	stlxr	w10, x9, [x8]
     4d8:      	cbnz	w10, 0x4cc <generic_lsm_output+0x4cc>
     4dc:      	b	0x690 <generic_lsm_output+0x690>
     4e0:      	adrp	x0, 0x0 <generic_lsm_output>
     4e4:      	mov	x3, xzr
     4e8:      	mov	w8, #0x82               // =130
     4ec:      	ldr	x0, [x0]
     4f0:      	mov	x1, x20
     4f4:      	mov	x2, x21
     4f8:      	blr	x8
     4fc:      	tbnz	x0, #0x3f, 0x538 <generic_lsm_output+0x538>
     500:      	str	wzr, [sp, #0x28]
     504:      	adrp	x0, 0x0 <generic_lsm_output>
     508:      	mov	w8, #0x1                // =1
     50c:      	add	x9, sp, #0x28
     510:      	ldr	x0, [x0]
     514:      	add	x1, sp, #0x28
     518:      	blr	x8
     51c:      	cbz	x0, 0x690 <generic_lsm_output+0x690>
     520:      	add	x8, x0, #0x8
     524:      	ldaxr	x9, [x8]
     528:      	add	x9, x9, #0x1
     52c:      	stlxr	w10, x9, [x8]
     530:      	cbnz	w10, 0x524 <generic_lsm_output+0x524>
     534:      	b	0x690 <generic_lsm_output+0x690>
     538:      	mov	x19, x0
     53c:      	str	wzr, [sp, #0x28]
     540:      	adrp	x0, 0x0 <generic_lsm_output>
     544:      	mov	w8, #0x1                // =1
     548:      	ldr	x0, [x0]
     54c:      	add	x9, sp, #0x28
     550:      	add	x1, sp, #0x28
     554:      	blr	x8
     558:      	cbz	x0, 0x690 <generic_lsm_output+0x690>
     55c:      	mov	x8, x19
     560:      	cmn	x19, #0xc
     564:      	b.gt	0x5d8 <generic_lsm_output+0x5d8>
     568:      	cmn	x8, #0x1c
     56c:      	b.eq	0x618 <generic_lsm_output+0x618>
     570:      	cmn	x8, #0x16
     574:      	b.eq	0x630 <generic_lsm_output+0x630>
     578:      	cmn	x8, #0x10
     57c:      	b.ne	0x628 <generic_lsm_output+0x628>
     580:      	add	x8, x0, #0x398
     584:      	b	0x640 <generic_lsm_output+0x640>
     588:      	mov	x19, x0
     58c:      	str	wzr, [sp, #0x28]
     590:      	adrp	x0, 0x0 <generic_lsm_output>
     594:      	mov	w8, #0x1                // =1
     598:      	ldr	x0, [x0]
     59c:      	add	x9, sp, #0x28
     5a0:      	add	x1, sp, #0x28
     5a4:      	blr	x8
     5a8:      	cbz	x0, 0x690 <generic_lsm_output+0x690>
     5ac:      	mov	x8, x19
     5b0:      	cmn	x19, #0xc
     5b4:      	b.gt	0x5f8 <generic_lsm_output+0x5f8>
     5b8:      	cmn	x8, #0x1c
     5bc:      	b.eq	0x654 <generic_lsm_output+0x654>
     5c0:      	cmn	x8, #0x16
     5c4:      	b.eq	0x66c <generic_lsm_output+0x66c>
     5c8:      	cmn	x8, #0x10
     5cc:      	b.ne	0x664 <generic_lsm_output+0x664>
     5d0:      	add	x8, x0, #0x398
     5d4:      	b	0x680 <generic_lsm_output+0x680>
     5d8:      	cmn	x8, #0xb
     5dc:      	b.eq	0x620 <generic_lsm_output+0x620>
     5e0:      	cmn	x8, #0x7
     5e4:      	b.eq	0x638 <generic_lsm_output+0x638>
     5e8:      	cmn	x8, #0x2
     5ec:      	b.ne	0x628 <generic_lsm_output+0x628>
     5f0:      	add	x8, x0, #0x388
     5f4:      	b	0x640 <generic_lsm_output+0x640>
     5f8:      	cmn	x8, #0xb
     5fc:      	b.eq	0x65c <generic_lsm_output+0x65c>
     600:      	cmn	x8, #0x7
     604:      	b.eq	0x674 <generic_lsm_output+0x674>
     608:      	cmn	x8, #0x2
     60c:      	b.ne	0x664 <generic_lsm_output+0x664>
     610:      	add	x8, x0, #0x388
     614:      	b	0x680 <generic_lsm_output+0x680>
     618:      	add	x8, x0, #0x3a8
     61c:      	b	0x640 <generic_lsm_output+0x640>
     620:      	add	x8, x0, #0x3b0
     624:      	b	0x640 <generic_lsm_output+0x640>
     628:      	add	x8, x0, #0x380
     62c:      	b	0x640 <generic_lsm_output+0x640>
     630:      	add	x8, x0, #0x3a0
     634:      	b	0x640 <generic_lsm_output+0x640>
     638:      	add	x8, x0, #0x390
     63c:      	nop
     640:      	ldaxr	x9, [x8]
     644:      	add	x9, x9, #0x1
     648:      	stlxr	w10, x9, [x8]
     64c:      	cbnz	w10, 0x640 <generic_lsm_output+0x640>
     650:      	b	0x690 <generic_lsm_output+0x690>
     654:      	add	x8, x0, #0x3a8
     658:      	b	0x680 <generic_lsm_output+0x680>
     65c:      	add	x8, x0, #0x3b0
     660:      	b	0x680 <generic_lsm_output+0x680>
     664:      	add	x8, x0, #0x380
     668:      	b	0x680 <generic_lsm_output+0x680>
     66c:      	add	x8, x0, #0x3a0
     670:      	b	0x680 <generic_lsm_output+0x680>
     674:      	add	x8, x0, #0x390
     678:      	nop
     67c:      	nop
     680:      	ldaxr	x9, [x8]
     684:      	add	x9, x9, #0x1
     688:      	stlxr	w10, x9, [x8]
     68c:      	cbnz	w10, 0x680 <generic_lsm_output+0x680>
     690:      	mov	w8, #0xe                // =14
     694:      	blr	x8
     698:      	str	x0, [sp, #0x28]
     69c:      	adrp	x19, 0x0 <generic_lsm_output>
     6a0:      	mov	w8, #0x1                // =1
     6a4:      	add	x9, sp, #0x28
     6a8:      	ldr	x19, [x19]
     6ac:      	add	x1, sp, #0x28
     6b0:      	mov	x0, x19
     6b4:      	blr	x8
     6b8:      	cbz	x0, 0x6e4 <generic_lsm_output+0x6e4>
     6bc:      	mov	w8, #0x3                // =3
     6c0:      	add	x9, sp, #0x28
     6c4:      	mov	x20, x0
     6c8:      	add	x1, sp, #0x28
     6cc:      	mov	x0, x19
     6d0:      	blr	x8
     6d4:      	ldr	w8, [x20]
     6d8:      	sub	w9, w8, #0x1
     6dc:      	cmn	w9, #0x1, lsl #12       // =0x1000
     6e0:      	csinv	w0, w8, wzr, hs
     6e4:      	ldp	x20, x19, [sp, #0xb0]
     6e8:      	ldr	x29, [sp, #0x70]
     6ec:      	ldp	x22, x21, [sp, #0xa0]
     6f0:      	ldp	x24, x23, [sp, #0x90]
     6f4:      	ldp	x30, x25, [sp, #0x80]
     6f8:      	add	sp, sp, #0xc0
     6fc:      	ret
