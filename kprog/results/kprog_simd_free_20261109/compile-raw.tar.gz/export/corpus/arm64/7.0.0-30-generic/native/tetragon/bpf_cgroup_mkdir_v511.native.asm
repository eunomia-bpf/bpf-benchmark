
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_cgroup_mkdir_v511.native.o:	file format elf64-littleaarch64

Disassembly of section raw_tracepoint/cgroup_mkdir:

0000000000000000 <tg_tp_cgrp_mkdir>:
       0:      	sub	sp, sp, #0x80
       4:      	str	x29, [sp, #0x30]
       8:      	stp	x30, x25, [sp, #0x40]
       c:      	stp	x24, x23, [sp, #0x50]
      10:      	stp	x22, x21, [sp, #0x60]
      14:      	stp	x20, x19, [sp, #0x70]
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x20, 0x0 <tg_tp_cgrp_mkdir>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0xc
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0xc
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x31c <tg_tp_cgrp_mkdir+0x31c>
      40:      	ldr	w8, [x0, #0x14]
      44:      	mov	x22, x0
      48:      	cbz	w8, 0x31c <tg_tp_cgrp_mkdir+0x31c>
      4c:      	ldr	x23, [x19]
      50:      	mov	w8, #0x8                // =8
      54:      	add	x9, sp, #0x20
      58:      	mov	w10, #0x4               // =4
      5c:      	add	x0, sp, #0x20
      60:      	mov	w1, #0x8                // =8
      64:      	mov	w24, #0x4               // =4
      68:      	add	x21, x23, #0x2d0
      6c:      	mov	x2, x21
      70:      	blr	x10
      74:      	ldr	x8, [sp, #0x20]
      78:      	add	x9, sp, #0x18
      7c:      	add	x0, sp, #0x18
      80:      	mov	w1, #0x4                // =4
      84:      	add	x8, x8, #0xc
      88:      	ldr	x8, [sp, #0x20]
      8c:      	add	x2, x8, #0xc
      90:      	blr	x24
      94:      	ldr	w8, [sp, #0x18]
      98:      	ldr	w9, [x22, #0xc]
      9c:      	cmp	w9, w8
      a0:      	b.ne	0x31c <tg_tp_cgrp_mkdir+0x31c>
      a4:      	str	wzr, [sp, #0x20]
      a8:      	add	x24, x23, #0xd8
      ac:      	mov	w8, #0x4                // =4
      b0:      	mov	w9, #0x71               // =113
      b4:      	add	x10, sp, #0x20
      b8:      	add	x0, sp, #0x20
      bc:      	mov	w1, #0x4                // =4
      c0:      	mov	x2, x24
      c4:      	blr	x9
      c8:      	ldr	w25, [sp, #0x20]
      cc:      	cbz	w25, 0x31c <tg_tp_cgrp_mkdir+0x31c>
      d0:      	str	xzr, [sp, #0x20]
      d4:      	cbz	x23, 0x31c <tg_tp_cgrp_mkdir+0x31c>
      d8:      	add	x23, x23, #0x100
      dc:      	mov	w8, #0x8                // =8
      e0:      	mov	w9, #0x71               // =113
      e4:      	add	x10, sp, #0x20
      e8:      	add	x0, sp, #0x20
      ec:      	mov	w1, #0x8                // =8
      f0:      	mov	x2, x23
      f4:      	blr	x9
      f8:      	ldr	x8, [sp, #0x20]
      fc:      	str	xzr, [sp, #0x20]
     100:      	cbz	x8, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     104:      	add	x2, x8, #0x60
     108:      	mov	w8, #0x8                // =8
     10c:      	mov	w9, #0x71               // =113
     110:      	add	x10, sp, #0x20
     114:      	add	x0, sp, #0x20
     118:      	mov	w1, #0x8                // =8
     11c:      	blr	x9
     120:      	ldr	x8, [sp, #0x20]
     124:      	str	x8, [sp, #0x10]
     128:      	cbz	x8, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     12c:      	ldr	w8, [x22, #0x14]
     130:      	cmp	w25, w8
     134:      	b.hi	0x31c <tg_tp_cgrp_mkdir+0x31c>
     138:      	mov	w8, #0x8                // =8
     13c:      	add	x9, sp, #0x20
     140:      	mov	w10, #0x4               // =4
     144:      	add	x0, sp, #0x20
     148:      	mov	w1, #0x8                // =8
     14c:      	mov	x2, x21
     150:      	mov	w29, #0x4               // =4
     154:      	blr	x10
     158:      	ldr	x8, [sp, #0x20]
     15c:      	add	x9, sp, #0x18
     160:      	mov	w10, #0x4               // =4
     164:      	add	x0, sp, #0x18
     168:      	mov	w1, #0x4                // =4
     16c:      	add	x8, x8, #0xc
     170:      	ldr	x8, [sp, #0x20]
     174:      	add	x2, x8, #0xc
     178:      	blr	x10
     17c:      	str	wzr, [sp, #0x20]
     180:      	ldr	w25, [sp, #0x18]
     184:      	mov	w8, #0x71               // =113
     188:      	add	x9, sp, #0x20
     18c:      	add	x0, sp, #0x20
     190:      	mov	w1, #0x4                // =4
     194:      	mov	x2, x24
     198:      	blr	x8
     19c:      	ldr	w24, [sp, #0x20]
     1a0:      	str	wzr, [sp, #0x20]
     1a4:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     1a8:      	add	x8, sp, #0x20
     1ac:      	mov	w9, #0x1                // =1
     1b0:      	add	x1, sp, #0x20
     1b4:      	ldr	x0, [x0]
     1b8:      	mov	w29, #0x1               // =1
     1bc:      	blr	x9
     1c0:      	cbz	x0, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     1c4:      	str	wzr, [x0, #0x8c]
     1c8:      	stur	xzr, [x0, #0x84]
     1cc:      	mov	w8, #0x8                // =8
     1d0:      	mov	w9, #0x71               // =113
     1d4:      	add	x10, sp, #0x20
     1d8:      	mov	x21, x0
     1dc:      	stur	xzr, [x0, #0x7c]
     1e0:      	stur	xzr, [x0, #0x74]
     1e4:      	mov	w1, #0x8                // =8
     1e8:      	mov	x2, x23
     1ec:      	stur	xzr, [x0, #0x6c]
     1f0:      	stur	xzr, [x0, #0x64]
     1f4:      	stur	xzr, [x0, #0x5c]
     1f8:      	stur	xzr, [x0, #0x54]
     1fc:      	stur	xzr, [x0, #0x4c]
     200:      	stur	xzr, [x0, #0x44]
     204:      	stur	xzr, [x0, #0x3c]
     208:      	stur	xzr, [x0, #0x34]
     20c:      	stur	xzr, [x0, #0x2c]
     210:      	stur	xzr, [x0, #0x24]
     214:      	stur	xzr, [x0, #0x1c]
     218:      	stur	xzr, [x0, #0x14]
     21c:      	stur	xzr, [x0, #0xc]
     220:      	stp	w29, w25, [x0]
     224:      	str	w24, [x0, #0x8]
     228:      	add	x0, sp, #0x20
     22c:      	str	xzr, [sp, #0x20]
     230:      	blr	x9
     234:      	ldr	x8, [sp, #0x20]
     238:      	str	xzr, [sp, #0x20]
     23c:      	cbz	x8, 0x278 <tg_tp_cgrp_mkdir+0x278>
     240:      	add	x2, x8, #0x10
     244:      	mov	w8, #0x8                // =8
     248:      	mov	w9, #0x71               // =113
     24c:      	add	x10, sp, #0x20
     250:      	add	x0, sp, #0x20
     254:      	mov	w1, #0x8                // =8
     258:      	blr	x9
     25c:      	ldr	x2, [sp, #0x20]
     260:      	cbz	x2, 0x278 <tg_tp_cgrp_mkdir+0x278>
     264:      	add	x0, x21, #0x10
     268:      	mov	w8, #0x7f               // =127
     26c:      	mov	w9, #0x2d               // =45
     270:      	mov	w1, #0x7f               // =127
     274:      	blr	x9
     278:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     27c:      	mov	x3, xzr
     280:      	add	x8, sp, #0x10
     284:      	ldr	x0, [x0]
     288:      	mov	w9, #0x2                // =2
     28c:      	add	x1, sp, #0x10
     290:      	mov	x2, x21
     294:      	mov	w23, #0x2               // =2
     298:      	blr	x9
     29c:      	cbz	x0, 0x310 <tg_tp_cgrp_mkdir+0x310>
     2a0:      	neg	w8, w0
     2a4:      	strh	w23, [sp, #0x22]
     2a8:      	adrp	x23, 0x0 <tg_tp_cgrp_mkdir>
     2ac:      	mov	w9, #0x1                // =1
     2b0:      	strh	w8, [sp, #0x20]
     2b4:      	mov	x8, #0x47               // =71
     2b8:      	add	x1, sp, #0x20
     2bc:      	mov	w24, #0x1               // =1
     2c0:      	movk	x8, #0x2, lsl #32
     2c4:      	stur	x8, [sp, #0x24]
     2c8:      	add	x8, sp, #0x20
     2cc:      	ldr	x23, [x23]
     2d0:      	mov	x0, x23
     2d4:      	blr	x9
     2d8:      	cbz	x0, 0x2ec <tg_tp_cgrp_mkdir+0x2ec>
     2dc:      	ldr	w8, [x0]
     2e0:      	add	w8, w8, #0x1
     2e4:      	str	w8, [x0]
     2e8:      	b	0x310 <tg_tp_cgrp_mkdir+0x310>
     2ec:      	str	w24, [sp, #0x18]
     2f0:      	mov	x3, xzr
     2f4:      	mov	w8, #0x2                // =2
     2f8:      	add	x9, sp, #0x20
     2fc:      	add	x10, sp, #0x18
     300:      	add	x1, sp, #0x20
     304:      	add	x2, sp, #0x18
     308:      	mov	x0, x23
     30c:      	blr	x8
     310:      	ldr	w8, [x22]
     314:      	cmp	w8, #0x6
     318:      	b.eq	0x33c <tg_tp_cgrp_mkdir+0x33c>
     31c:      	ldp	x20, x19, [sp, #0x70]
     320:      	mov	w0, wzr
     324:      	ldr	x29, [sp, #0x30]
     328:      	ldp	x22, x21, [sp, #0x60]
     32c:      	ldp	x24, x23, [sp, #0x50]
     330:      	ldp	x30, x25, [sp, #0x40]
     334:      	add	sp, sp, #0x80
     338:      	ret
     33c:      	str	wzr, [sp, #0x38]
     340:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     344:      	ldr	x24, [sp, #0x10]
     348:      	mov	w8, #0x1                // =1
     34c:      	add	x9, sp, #0x38
     350:      	add	x1, sp, #0x38
     354:      	ldr	x0, [x0]
     358:      	blr	x8
     35c:      	cbz	x0, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     360:      	mov	w8, #0x19               // =25
     364:      	mov	x22, x0
     368:      	strb	w8, [x0]
     36c:      	mov	w8, #0x10d8             // =4312
     370:      	str	w8, [x0, #0x4]
     374:      	mov	w8, #0xe                // =14
     378:      	ldr	x23, [x19, #0x8]
     37c:      	blr	x8
     380:      	lsr	x25, x0, #32
     384:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     388:      	add	x8, sp, #0x20
     38c:      	str	w25, [sp, #0x20]
     390:      	mov	w9, #0x1                // =1
     394:      	add	x1, sp, #0x20
     398:      	mov	w29, #0x1               // =1
     39c:      	ldr	x0, [x0]
     3a0:      	blr	x9
     3a4:      	cbz	x0, 0x3c8 <tg_tp_cgrp_mkdir+0x3c8>
     3a8:      	ldr	x8, [x0, #0x8]
     3ac:      	str	x8, [x22, #0x8]
     3b0:      	ldp	x8, x9, [x0, #0x10]
     3b4:      	stp	x8, x9, [x22, #0x10]
     3b8:      	ldr	w8, [x0, #0x20]
     3bc:      	str	w8, [x22, #0x2c]
     3c0:      	ldr	x8, [x0, #0x8]
     3c4:      	str	x8, [x22, #0x30]
     3c8:      	stp	w29, w25, [x22, #0x20]
     3cc:      	mov	w8, #0x23               // =35
     3d0:      	blr	x8
     3d4:      	add	x2, x0, #0x60
     3d8:      	mov	w8, #0x8                // =8
     3dc:      	mov	w9, #0x71               // =113
     3e0:      	add	x10, sp, #0x18
     3e4:      	add	x0, sp, #0x18
     3e8:      	mov	w1, #0x8                // =8
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x18]
     3f4:      	cbz	x8, 0x464 <tg_tp_cgrp_mkdir+0x464>
     3f8:      	add	x8, x8, #0x4
     3fc:      	mov	w9, #0x4                // =4
     400:      	mov	w10, #0x71              // =113
     404:      	add	x11, sp, #0x3c
     408:      	ldr	x8, [sp, #0x18]
     40c:      	add	x0, sp, #0x3c
     410:      	mov	w1, #0x4                // =4
     414:      	add	x2, x8, #0x4
     418:      	blr	x10
     41c:      	ldr	w8, [sp, #0x3c]
     420:      	cbz	w8, 0x464 <tg_tp_cgrp_mkdir+0x464>
     424:      	ldr	x9, [sp, #0x18]
     428:      	lsl	w8, w8, #4
     42c:      	mov	w10, #0x71              // =113
     430:      	add	x11, sp, #0x20
     434:      	add	x0, sp, #0x20
     438:      	mov	w1, #0x10               // =16
     43c:      	add	x8, x9, x8
     440:      	mov	w9, #0x10               // =16
     444:      	add	x8, x8, #0x80
     448:      	ldr	w9, [sp, #0x3c]
     44c:      	ldr	x8, [sp, #0x18]
     450:      	lsl	w9, w9, #4
     454:      	add	x8, x8, x9
     458:      	add	x2, x8, #0x80
     45c:      	blr	x10
     460:      	ldr	w8, [sp, #0x20]
     464:      	str	w8, [x22, #0x28]
     468:      	stp	x24, x24, [x22, #0x38]
     46c:      	add	x0, x22, #0xd8
     470:      	mov	w1, #0xfff              // =4095
     474:      	mov	x2, x23
     478:      	ldr	x8, [x21]
     47c:      	str	x8, [x22, #0x48]
     480:      	ldr	w8, [x21, #0x8]
     484:      	str	w8, [x22, #0x50]
     488:      	ldp	x8, x9, [x21, #0x10]
     48c:      	ldp	x10, x11, [x21, #0x20]
     490:      	stp	x10, x11, [x22, #0x68]
     494:      	stp	x8, x9, [x22, #0x58]
     498:      	ldp	x8, x9, [x21, #0x30]
     49c:      	ldp	x10, x11, [x21, #0x40]
     4a0:      	stp	x10, x11, [x22, #0x88]
     4a4:      	stp	x8, x9, [x22, #0x78]
     4a8:      	ldp	x8, x9, [x21, #0x50]
     4ac:      	ldp	x10, x11, [x21, #0x60]
     4b0:      	stp	x10, x11, [x22, #0xa8]
     4b4:      	stp	x8, x9, [x22, #0x98]
     4b8:      	ldp	x8, x9, [x21, #0x70]
     4bc:      	ldp	x10, x11, [x21, #0x80]
     4c0:      	stp	x10, x11, [x22, #0xc8]
     4c4:      	stp	x8, x9, [x22, #0xb8]
     4c8:      	mov	w8, #0xfff              // =4095
     4cc:      	mov	w9, #0x2d               // =45
     4d0:      	blr	x9
     4d4:      	str	wzr, [sp, #0x18]
     4d8:      	mov	w8, #0x1                // =1
     4dc:      	add	x9, sp, #0x18
     4e0:      	add	x1, sp, #0x18
     4e4:      	mov	x0, x20
     4e8:      	blr	x8
     4ec:      	cbz	x0, 0x570 <tg_tp_cgrp_mkdir+0x570>
     4f0:      	ldrb	w8, [x0, #0x28]
     4f4:      	cbz	w8, 0x570 <tg_tp_cgrp_mkdir+0x570>
     4f8:      	adrp	x1, 0x0 <tg_tp_cgrp_mkdir>
     4fc:      	mov	w8, #-0x1               // =-1
     500:      	mov	w9, #0x10d8             // =4312
     504:      	ldr	x1, [x1]
     508:      	mov	w10, #0x19              // =25
     50c:      	mov	x0, x19
     510:      	mov	w2, #-0x1               // =-1
     514:      	mov	x3, x22
     518:      	mov	w4, #0x10d8             // =4312
     51c:      	blr	x10
     520:      	tbz	x0, #0x3f, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     524:      	mov	x19, x0
     528:      	str	wzr, [sp, #0x20]
     52c:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     530:      	mov	w8, #0x1                // =1
     534:      	ldr	x0, [x0]
     538:      	add	x9, sp, #0x20
     53c:      	add	x1, sp, #0x20
     540:      	blr	x8
     544:      	cbz	x0, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     548:      	cmn	x19, #0xc
     54c:      	b.gt	0x600 <tg_tp_cgrp_mkdir+0x600>
     550:      	cmn	x19, #0x1c
     554:      	b.eq	0x658 <tg_tp_cgrp_mkdir+0x658>
     558:      	cmn	x19, #0x16
     55c:      	b.eq	0x668 <tg_tp_cgrp_mkdir+0x668>
     560:      	cmn	x19, #0x10
     564:      	b.ne	0x678 <tg_tp_cgrp_mkdir+0x678>
     568:      	add	x8, x0, #0x590
     56c:      	b	0x67c <tg_tp_cgrp_mkdir+0x67c>
     570:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     574:      	mov	x3, xzr
     578:      	mov	w8, #0x10d8             // =4312
     57c:      	ldr	x0, [x0]
     580:      	mov	w9, #0x82               // =130
     584:      	mov	x1, x22
     588:      	mov	w2, #0x10d8             // =4312
     58c:      	blr	x9
     590:      	tbz	x0, #0x3f, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     594:      	mov	x19, x0
     598:      	str	wzr, [sp, #0x20]
     59c:      	adrp	x0, 0x0 <tg_tp_cgrp_mkdir>
     5a0:      	mov	w8, #0x1                // =1
     5a4:      	ldr	x0, [x0]
     5a8:      	add	x9, sp, #0x20
     5ac:      	add	x1, sp, #0x20
     5b0:      	blr	x8
     5b4:      	cbz	x0, 0x31c <tg_tp_cgrp_mkdir+0x31c>
     5b8:      	cmn	x19, #0xc
     5bc:      	b.gt	0x5e0 <tg_tp_cgrp_mkdir+0x5e0>
     5c0:      	cmn	x19, #0x1c
     5c4:      	b.eq	0x620 <tg_tp_cgrp_mkdir+0x620>
     5c8:      	cmn	x19, #0x16
     5cc:      	b.eq	0x638 <tg_tp_cgrp_mkdir+0x638>
     5d0:      	cmn	x19, #0x10
     5d4:      	b.ne	0x630 <tg_tp_cgrp_mkdir+0x630>
     5d8:      	add	x8, x0, #0x590
     5dc:      	b	0x644 <tg_tp_cgrp_mkdir+0x644>
     5e0:      	cmn	x19, #0xb
     5e4:      	b.eq	0x628 <tg_tp_cgrp_mkdir+0x628>
     5e8:      	cmn	x19, #0x7
     5ec:      	b.eq	0x640 <tg_tp_cgrp_mkdir+0x640>
     5f0:      	cmn	x19, #0x2
     5f4:      	b.ne	0x630 <tg_tp_cgrp_mkdir+0x630>
     5f8:      	add	x8, x0, #0x580
     5fc:      	b	0x644 <tg_tp_cgrp_mkdir+0x644>
     600:      	cmn	x19, #0xb
     604:      	b.eq	0x660 <tg_tp_cgrp_mkdir+0x660>
     608:      	cmn	x19, #0x7
     60c:      	b.eq	0x670 <tg_tp_cgrp_mkdir+0x670>
     610:      	cmn	x19, #0x2
     614:      	b.ne	0x678 <tg_tp_cgrp_mkdir+0x678>
     618:      	add	x8, x0, #0x580
     61c:      	b	0x67c <tg_tp_cgrp_mkdir+0x67c>
     620:      	add	x8, x0, #0x5a0
     624:      	b	0x644 <tg_tp_cgrp_mkdir+0x644>
     628:      	add	x8, x0, #0x5a8
     62c:      	b	0x644 <tg_tp_cgrp_mkdir+0x644>
     630:      	add	x8, x0, #0x578
     634:      	b	0x644 <tg_tp_cgrp_mkdir+0x644>
     638:      	add	x8, x0, #0x598
     63c:      	b	0x644 <tg_tp_cgrp_mkdir+0x644>
     640:      	add	x8, x0, #0x588
     644:      	ldaxr	x9, [x8]
     648:      	add	x9, x9, #0x1
     64c:      	stlxr	w10, x9, [x8]
     650:      	cbnz	w10, 0x644 <tg_tp_cgrp_mkdir+0x644>
     654:      	b	0x31c <tg_tp_cgrp_mkdir+0x31c>
     658:      	add	x8, x0, #0x5a0
     65c:      	b	0x67c <tg_tp_cgrp_mkdir+0x67c>
     660:      	add	x8, x0, #0x5a8
     664:      	b	0x67c <tg_tp_cgrp_mkdir+0x67c>
     668:      	add	x8, x0, #0x598
     66c:      	b	0x67c <tg_tp_cgrp_mkdir+0x67c>
     670:      	add	x8, x0, #0x588
     674:      	b	0x67c <tg_tp_cgrp_mkdir+0x67c>
     678:      	add	x8, x0, #0x578
     67c:      	ldaxr	x9, [x8]
     680:      	add	x9, x9, #0x1
     684:      	stlxr	w10, x9, [x8]
     688:      	cbnz	w10, 0x67c <tg_tp_cgrp_mkdir+0x67c>
     68c:      	b	0x31c <tg_tp_cgrp_mkdir+0x31c>
