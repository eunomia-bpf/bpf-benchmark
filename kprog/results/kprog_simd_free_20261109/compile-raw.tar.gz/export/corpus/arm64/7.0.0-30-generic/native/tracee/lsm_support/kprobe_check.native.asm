
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tracee/lsm_support/kprobe_check.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/security_bpf:

0000000000000000 <security_bpf_kprobe>:
       0:      	str	x30, [sp, #-0x10]!
       4:      	mov	w8, #0x1                // =1
       8:      	str	wzr, [sp, #0xc]
       c:      	adrp	x0, 0x0 <security_bpf_kprobe>
      10:      	mov	x3, xzr
      14:      	strb	w8, [sp, #0x8]
      18:      	mov	w8, #0x2                // =2
      1c:      	add	x9, sp, #0xc
      20:      	add	x10, sp, #0x8
      24:      	ldr	x0, [x0]
      28:      	add	x1, sp, #0xc
      2c:      	add	x2, sp, #0x8
      30:      	blr	x8
      34:      	mov	w0, wzr
      38:      	ldr	x30, [sp], #0x10
      3c:      	ret
