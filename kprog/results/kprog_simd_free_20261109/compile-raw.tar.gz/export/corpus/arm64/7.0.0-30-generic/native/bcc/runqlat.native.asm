
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/runqlat.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <handle_switch>:
       0:      	sub	sp, sp, #0x40
       4:      	stp	x30, x21, [sp, #0x20]
       8:      	stp	x20, x19, [sp, #0x30]
       c:      	adrp	x8, 0x0 <handle_switch>
      10:      	mov	x19, x1
      14:      	mov	x20, x0
      18:      	ldr	x8, [x8]
      1c:      	ldrb	w8, [x8]
      20:      	cbz	w8, 0x38 <handle_switch+0x38>
      24:      	adrp	x0, 0x0 <handle_switch>
      28:      	mov	w1, wzr
      2c:      	ldr	x0, [x0]
      30:      	bl	0x30 <handle_switch+0x30>
      34:      	cbz	x0, 0x2c0 <handle_switch+0x2c0>
      38:      	add	x0, sp, #0x10
      3c:      	mov	w1, #0x4                // =4
      40:      	mov	x2, x20
      44:      	bl	0x44 <handle_switch+0x44>
      48:      	ldr	w8, [sp, #0x10]
      4c:      	cbnz	w8, 0xbc <handle_switch+0xbc>
      50:      	add	x0, sp, #0x10
      54:      	add	x2, x20, #0x8d4
      58:      	mov	w1, #0x4                // =4
      5c:      	bl	0x5c <handle_switch+0x5c>
      60:      	ldr	w21, [sp, #0x10]
      64:      	add	x0, sp, #0x10
      68:      	add	x2, x20, #0x8d0
      6c:      	mov	w1, #0x4                // =4
      70:      	bl	0x70 <handle_switch+0x70>
      74:      	ldr	w8, [sp, #0x10]
      78:      	str	w8, [sp, #0xc]
      7c:      	cbz	w8, 0xbc <handle_switch+0xbc>
      80:      	adrp	x8, 0x0 <handle_switch>
      84:      	ldr	x8, [x8]
      88:      	ldr	w9, [x8]
      8c:      	cbz	w9, 0x9c <handle_switch+0x9c>
      90:      	ldr	w8, [x8]
      94:      	cmp	w8, w21
      98:      	b.ne	0xbc <handle_switch+0xbc>
      9c:      	bl	0x9c <handle_switch+0x9c>
      a0:      	str	x0, [sp, #0x10]
      a4:      	adrp	x0, 0x0 <handle_switch>
      a8:      	add	x1, sp, #0xc
      ac:      	add	x2, sp, #0x10
      b0:      	ldr	x0, [x0]
      b4:      	mov	x3, xzr
      b8:      	bl	0xb8 <handle_switch+0xb8>
      bc:      	add	x0, sp, #0xc
      c0:      	add	x2, x19, #0x8d0
      c4:      	mov	w1, #0x4                // =4
      c8:      	bl	0xc8 <handle_switch+0xc8>
      cc:      	adrp	x0, 0x0 <handle_switch>
      d0:      	add	x1, sp, #0xc
      d4:      	ldr	x0, [x0]
      d8:      	bl	0xd8 <handle_switch+0xd8>
      dc:      	cbz	x0, 0x2c0 <handle_switch+0x2c0>
      e0:      	mov	x20, x0
      e4:      	bl	0xe4 <handle_switch+0xe4>
      e8:      	ldr	x8, [x20]
      ec:      	subs	x20, x0, x8
      f0:      	b.mi	0x2b0 <handle_switch+0x2b0>
      f4:      	adrp	x8, 0x0 <handle_switch>
      f8:      	ldr	x8, [x8]
      fc:      	ldrb	w8, [x8]
     100:      	cbz	w8, 0x12c <handle_switch+0x12c>
     104:      	add	x0, sp, #0x8
     108:      	add	x2, x19, #0x8d4
     10c:      	mov	w1, #0x4                // =4
     110:      	bl	0x110 <handle_switch+0x110>
     114:      	adrp	x0, 0x0 <handle_switch>
     118:      	add	x1, sp, #0x8
     11c:      	ldr	x0, [x0]
     120:      	bl	0x120 <handle_switch+0x120>
     124:      	cbnz	x0, 0x194 <handle_switch+0x194>
     128:      	b	0x158 <handle_switch+0x158>
     12c:      	adrp	x8, 0x0 <handle_switch>
     130:      	ldr	x8, [x8]
     134:      	ldrb	w8, [x8]
     138:      	cbz	w8, 0x2d0 <handle_switch+0x2d0>
     13c:      	ldr	w8, [sp, #0xc]
     140:      	str	w8, [sp, #0x8]
     144:      	adrp	x0, 0x0 <handle_switch>
     148:      	add	x1, sp, #0x8
     14c:      	ldr	x0, [x0]
     150:      	bl	0x150 <handle_switch+0x150>
     154:      	cbnz	x0, 0x194 <handle_switch+0x194>
     158:      	adrp	x0, 0x0 <handle_switch>
     15c:      	adrp	x2, 0x0 <handle_switch>
     160:      	add	x2, x2, #0x0
     164:      	ldr	x0, [x0]
     168:      	add	x1, sp, #0x8
     16c:      	mov	w3, #0x1                // =1
     170:      	bl	0x170 <handle_switch+0x170>
     174:      	cbz	x0, 0x180 <handle_switch+0x180>
     178:      	cmn	x0, #0x11
     17c:      	b.ne	0x2b0 <handle_switch+0x2b0>
     180:      	adrp	x0, 0x0 <handle_switch>
     184:      	add	x1, sp, #0x8
     188:      	ldr	x0, [x0]
     18c:      	bl	0x18c <handle_switch+0x18c>
     190:      	cbz	x0, 0x2b0 <handle_switch+0x2b0>
     194:      	mov	x8, x0
     198:      	ldrb	w9, [x8, #0x68]!
     19c:      	cbnz	w9, 0x1b8 <handle_switch+0x1b8>
     1a0:      	add	x2, x19, #0xaf0
     1a4:      	mov	x19, x0
     1a8:      	mov	x0, x8
     1ac:      	mov	w1, #0x10               // =16
     1b0:      	bl	0x1b0 <handle_switch+0x1b0>
     1b4:      	mov	x0, x19
     1b8:      	adrp	x8, 0x0 <handle_switch>
     1bc:      	mov	w9, #0x3e8              // =1000
     1c0:      	ldr	x8, [x8]
     1c4:      	ldrb	w8, [x8]
     1c8:      	cmp	w8, #0x0
     1cc:      	mov	w8, #0x4240             // =16960
     1d0:      	movk	w8, #0xf, lsl #16
     1d4:      	csel	x8, x9, x8, eq
     1d8:      	udiv	x8, x20, x8
     1dc:      	tst	w8, #0xffff0000
     1e0:      	lsr	x9, x8, #32
     1e4:      	cset	w10, ne
     1e8:      	lsl	w10, w10, #4
     1ec:      	lsr	w8, w8, w10
     1f0:      	cmp	w8, #0xff
     1f4:      	cset	w11, hi
     1f8:      	lsl	w12, w11, #3
     1fc:      	lsr	w8, w8, w12
     200:      	cmp	w8, #0xf
     204:      	cset	w12, hi
     208:      	lsl	w13, w12, #2
     20c:      	lsr	w8, w8, w13
     210:      	cmp	w8, #0x3
     214:      	cset	w13, hi
     218:      	tst	w9, #0x7f0000
     21c:      	lsl	w14, w13, #1
     220:      	lsr	w8, w8, w14
     224:      	orr	w8, w10, w8, lsr #1
     228:      	cset	w10, ne
     22c:      	lsl	w10, w10, #4
     230:      	orr	w8, w8, w11, lsl #3
     234:      	lsr	w11, w9, w10
     238:      	orr	w8, w8, w12, lsl #2
     23c:      	cmp	w11, #0xff
     240:      	orr	w8, w8, w13, lsl #1
     244:      	cset	w12, hi
     248:      	lsl	w13, w12, #3
     24c:      	lsr	w11, w11, w13
     250:      	cmp	w11, #0xf
     254:      	cset	w13, hi
     258:      	lsl	w14, w13, #2
     25c:      	lsr	w11, w11, w14
     260:      	cmp	w11, #0x3
     264:      	cset	w14, hi
     268:      	cmp	w9, #0x0
     26c:      	mov	w9, #0x19               // =25
     270:      	lsl	w15, w14, #1
     274:      	lsr	w11, w11, w15
     278:      	orr	w10, w10, w11, lsr #1
     27c:      	orr	w10, w10, w12, lsl #3
     280:      	orr	w10, w10, w13, lsl #2
     284:      	orr	w10, w10, w14, lsl #1
     288:      	add	w10, w10, #0x20
     28c:      	csel	w8, w8, w10, eq
     290:      	cmp	w8, #0x19
     294:      	csel	w8, w8, w9, lo
     298:      	add	x8, x0, w8, uxtw #2
     29c:      	nop
     2a0:      	ldaxr	w9, [x8]
     2a4:      	add	w9, w9, #0x1
     2a8:      	stlxr	w10, w9, [x8]
     2ac:      	cbnz	w10, 0x2a0 <handle_switch+0x2a0>
     2b0:      	adrp	x0, 0x0 <handle_switch>
     2b4:      	add	x1, sp, #0xc
     2b8:      	ldr	x0, [x0]
     2bc:      	bl	0x2bc <handle_switch+0x2bc>
     2c0:      	ldp	x20, x19, [sp, #0x30]
     2c4:      	ldp	x30, x21, [sp, #0x20]
     2c8:      	add	sp, sp, #0x40
     2cc:      	ret
     2d0:      	adrp	x8, 0x0 <handle_switch>
     2d4:      	ldr	x8, [x8]
     2d8:      	ldrb	w8, [x8]
     2dc:      	cbz	w8, 0x32c <handle_switch+0x32c>
     2e0:      	add	x0, sp, #0x10
     2e4:      	add	x2, x19, #0x938
     2e8:      	mov	w1, #0x8                // =8
     2ec:      	bl	0x2ec <handle_switch+0x2ec>
     2f0:      	ldr	x21, [sp, #0x10]
     2f4:      	add	x0, sp, #0x10
     2f8:      	mov	w1, #0x4                // =4
     2fc:      	add	x2, x21, #0x4
     300:      	bl	0x300 <handle_switch+0x300>
     304:      	ldr	w8, [sp, #0x10]
     308:      	add	x0, sp, #0x10
     30c:      	mov	w1, #0x10               // =16
     310:      	add	x8, x21, x8, lsl #4
     314:      	add	x2, x8, #0x80
     318:      	bl	0x318 <handle_switch+0x318>
     31c:      	ldr	x8, [sp, #0x18]
     320:      	add	x0, sp, #0x8
     324:      	add	x2, x8, #0x158
     328:      	b	0x10c <handle_switch+0x10c>
     32c:      	mov	w8, #-0x1               // =-1
     330:      	b	0x140 <handle_switch+0x140>

Disassembly of section tp_btf/sched_wakeup:

0000000000000000 <sched_wakeup>:
       0:      	sub	sp, sp, #0x20
       4:      	stp	x30, x19, [sp, #0x10]
       8:      	adrp	x8, 0x0 <sched_wakeup>
       c:      	ldr	x19, [x0]
      10:      	ldr	x8, [x8]
      14:      	ldrb	w8, [x8]
      18:      	cbz	w8, 0x30 <sched_wakeup+0x30>
      1c:      	adrp	x0, 0x0 <sched_wakeup>
      20:      	mov	w1, wzr
      24:      	ldr	x0, [x0]
      28:      	bl	0x28 <sched_wakeup+0x28>
      2c:      	cbz	x0, 0x7c <sched_wakeup+0x7c>
      30:      	ldr	w8, [x19, #0x8d4]
      34:      	ldr	w9, [x19, #0x8d0]
      38:      	str	w9, [sp, #0xc]
      3c:      	cbz	w9, 0x7c <sched_wakeup+0x7c>
      40:      	adrp	x9, 0x0 <sched_wakeup>
      44:      	ldr	x9, [x9]
      48:      	ldr	w10, [x9]
      4c:      	cbz	w10, 0x5c <sched_wakeup+0x5c>
      50:      	ldr	w9, [x9]
      54:      	cmp	w9, w8
      58:      	b.ne	0x7c <sched_wakeup+0x7c>
      5c:      	bl	0x5c <sched_wakeup+0x5c>
      60:      	str	x0, [sp]
      64:      	adrp	x0, 0x0 <sched_wakeup>
      68:      	add	x1, sp, #0xc
      6c:      	mov	x2, sp
      70:      	ldr	x0, [x0]
      74:      	mov	x3, xzr
      78:      	bl	0x78 <sched_wakeup+0x78>
      7c:      	ldp	x30, x19, [sp, #0x10]
      80:      	mov	w0, wzr
      84:      	add	sp, sp, #0x20
      88:      	ret

Disassembly of section tp_btf/sched_wakeup_new:

0000000000000000 <sched_wakeup_new>:
       0:      	sub	sp, sp, #0x20
       4:      	stp	x30, x19, [sp, #0x10]
       8:      	adrp	x8, 0x0 <sched_wakeup_new>
       c:      	ldr	x19, [x0]
      10:      	ldr	x8, [x8]
      14:      	ldrb	w8, [x8]
      18:      	cbz	w8, 0x30 <sched_wakeup_new+0x30>
      1c:      	adrp	x0, 0x0 <sched_wakeup_new>
      20:      	mov	w1, wzr
      24:      	ldr	x0, [x0]
      28:      	bl	0x28 <sched_wakeup_new+0x28>
      2c:      	cbz	x0, 0x7c <sched_wakeup_new+0x7c>
      30:      	ldr	w8, [x19, #0x8d4]
      34:      	ldr	w9, [x19, #0x8d0]
      38:      	str	w9, [sp, #0xc]
      3c:      	cbz	w9, 0x7c <sched_wakeup_new+0x7c>
      40:      	adrp	x9, 0x0 <sched_wakeup_new>
      44:      	ldr	x9, [x9]
      48:      	ldr	w10, [x9]
      4c:      	cbz	w10, 0x5c <sched_wakeup_new+0x5c>
      50:      	ldr	w9, [x9]
      54:      	cmp	w9, w8
      58:      	b.ne	0x7c <sched_wakeup_new+0x7c>
      5c:      	bl	0x5c <sched_wakeup_new+0x5c>
      60:      	str	x0, [sp]
      64:      	adrp	x0, 0x0 <sched_wakeup_new>
      68:      	add	x1, sp, #0xc
      6c:      	mov	x2, sp
      70:      	ldr	x0, [x0]
      74:      	mov	x3, xzr
      78:      	bl	0x78 <sched_wakeup_new+0x78>
      7c:      	ldp	x30, x19, [sp, #0x10]
      80:      	mov	w0, wzr
      84:      	add	sp, sp, #0x20
      88:      	ret

Disassembly of section tp_btf/sched_switch:

0000000000000000 <sched_switch>:
       0:      	str	x30, [sp, #-0x10]!
       4:      	ldp	x8, x1, [x0, #0x8]
       8:      	mov	x0, x8
       c:      	bl	0xc <sched_switch+0xc>
      10:      	mov	w0, wzr
      14:      	ldr	x30, [sp], #0x10
      18:      	ret

Disassembly of section raw_tp/sched_wakeup:

0000000000000000 <handle_sched_wakeup>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	adrp	x8, 0x0 <handle_sched_wakeup>
      10:      	ldr	x19, [x0]
      14:      	ldr	x8, [x8]
      18:      	ldrb	w8, [x8]
      1c:      	cbz	w8, 0x34 <handle_sched_wakeup+0x34>
      20:      	adrp	x0, 0x0 <handle_sched_wakeup>
      24:      	mov	w1, wzr
      28:      	ldr	x0, [x0]
      2c:      	bl	0x2c <handle_sched_wakeup+0x2c>
      30:      	cbz	x0, 0xa0 <handle_sched_wakeup+0xa0>
      34:      	add	x0, sp, #0x8
      38:      	add	x2, x19, #0x8d4
      3c:      	mov	w1, #0x4                // =4
      40:      	bl	0x40 <handle_sched_wakeup+0x40>
      44:      	ldr	w20, [sp, #0x8]
      48:      	add	x0, sp, #0x8
      4c:      	add	x2, x19, #0x8d0
      50:      	mov	w1, #0x4                // =4
      54:      	bl	0x54 <handle_sched_wakeup+0x54>
      58:      	ldr	w8, [sp, #0x8]
      5c:      	str	w8, [sp, #0x1c]
      60:      	cbz	w8, 0xa0 <handle_sched_wakeup+0xa0>
      64:      	adrp	x8, 0x0 <handle_sched_wakeup>
      68:      	ldr	x8, [x8]
      6c:      	ldr	w9, [x8]
      70:      	cbz	w9, 0x80 <handle_sched_wakeup+0x80>
      74:      	ldr	w8, [x8]
      78:      	cmp	w8, w20
      7c:      	b.ne	0xa0 <handle_sched_wakeup+0xa0>
      80:      	bl	0x80 <handle_sched_wakeup+0x80>
      84:      	str	x0, [sp, #0x8]
      88:      	adrp	x0, 0x0 <handle_sched_wakeup>
      8c:      	add	x1, sp, #0x1c
      90:      	add	x2, sp, #0x8
      94:      	ldr	x0, [x0]
      98:      	mov	x3, xzr
      9c:      	bl	0x9c <handle_sched_wakeup+0x9c>
      a0:      	ldp	x20, x19, [sp, #0x20]
      a4:      	mov	w0, wzr
      a8:      	ldr	x30, [sp, #0x10]
      ac:      	add	sp, sp, #0x30
      b0:      	ret

Disassembly of section raw_tp/sched_wakeup_new:

0000000000000000 <handle_sched_wakeup_new>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	adrp	x8, 0x0 <handle_sched_wakeup_new>
      10:      	ldr	x19, [x0]
      14:      	ldr	x8, [x8]
      18:      	ldrb	w8, [x8]
      1c:      	cbz	w8, 0x34 <handle_sched_wakeup_new+0x34>
      20:      	adrp	x0, 0x0 <handle_sched_wakeup_new>
      24:      	mov	w1, wzr
      28:      	ldr	x0, [x0]
      2c:      	bl	0x2c <handle_sched_wakeup_new+0x2c>
      30:      	cbz	x0, 0xa0 <handle_sched_wakeup_new+0xa0>
      34:      	add	x0, sp, #0x8
      38:      	add	x2, x19, #0x8d4
      3c:      	mov	w1, #0x4                // =4
      40:      	bl	0x40 <handle_sched_wakeup_new+0x40>
      44:      	ldr	w20, [sp, #0x8]
      48:      	add	x0, sp, #0x8
      4c:      	add	x2, x19, #0x8d0
      50:      	mov	w1, #0x4                // =4
      54:      	bl	0x54 <handle_sched_wakeup_new+0x54>
      58:      	ldr	w8, [sp, #0x8]
      5c:      	str	w8, [sp, #0x1c]
      60:      	cbz	w8, 0xa0 <handle_sched_wakeup_new+0xa0>
      64:      	adrp	x8, 0x0 <handle_sched_wakeup_new>
      68:      	ldr	x8, [x8]
      6c:      	ldr	w9, [x8]
      70:      	cbz	w9, 0x80 <handle_sched_wakeup_new+0x80>
      74:      	ldr	w8, [x8]
      78:      	cmp	w8, w20
      7c:      	b.ne	0xa0 <handle_sched_wakeup_new+0xa0>
      80:      	bl	0x80 <handle_sched_wakeup_new+0x80>
      84:      	str	x0, [sp, #0x8]
      88:      	adrp	x0, 0x0 <handle_sched_wakeup_new>
      8c:      	add	x1, sp, #0x1c
      90:      	add	x2, sp, #0x8
      94:      	ldr	x0, [x0]
      98:      	mov	x3, xzr
      9c:      	bl	0x9c <handle_sched_wakeup_new+0x9c>
      a0:      	ldp	x20, x19, [sp, #0x20]
      a4:      	mov	w0, wzr
      a8:      	ldr	x30, [sp, #0x10]
      ac:      	add	sp, sp, #0x30
      b0:      	ret

Disassembly of section raw_tp/sched_switch:

0000000000000000 <handle_sched_switch>:
       0:      	str	x30, [sp, #-0x10]!
       4:      	ldp	x8, x1, [x0, #0x8]
       8:      	mov	x0, x8
       c:      	bl	0xc <handle_sched_switch+0xc>
      10:      	mov	w0, wzr
      14:      	ldr	x30, [sp], #0x10
      18:      	ret
