
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_ima_file_v511.native.o:	file format elf64-littleaarch64

Disassembly of section lsm.s/generic_lsm_ima_file:

0000000000000000 <ima_file>:
       0:      	sub	sp, sp, #0x70
       4:      	stp	x30, x21, [sp, #0x50]
       8:      	stp	x20, x19, [sp, #0x60]
       c:      	ldr	x20, [x0]
      10:      	mov	w8, #0xe                // =14
      14:      	blr	x8
      18:      	str	x0, [sp]
      1c:      	adrp	x19, 0x0 <ima_file>
      20:      	mov	w8, #0x1                // =1
      24:      	mov	x9, sp
      28:      	ldr	x19, [x19]
      2c:      	mov	x1, sp
      30:      	mov	x0, x19
      34:      	blr	x8
      38:      	cbz	x0, 0x88 <ima_file+0x88>
      3c:      	ldrb	w8, [x0]
      40:      	cmp	w8, #0x1
      44:      	b.ne	0x88 <ima_file+0x88>
      48:      	add	x21, sp, #0xc
      4c:      	mov	w8, #0x40               // =64
      50:      	mov	w9, #0xc1               // =193
      54:      	mov	x0, x20
      58:      	mov	w2, #0x40               // =64
      5c:      	orr	x1, x21, #0x2
      60:      	blr	x9
      64:      	mov	w8, #0x2                // =2
      68:      	strb	w0, [sp, #0xd]
      6c:      	mov	x3, xzr
      70:      	mov	x9, sp
      74:      	strb	w8, [sp, #0xc]
      78:      	mov	x1, sp
      7c:      	add	x2, sp, #0xc
      80:      	mov	x0, x19
      84:      	blr	x8
      88:      	ldp	x20, x19, [sp, #0x60]
      8c:      	mov	w0, wzr
      90:      	ldp	x30, x21, [sp, #0x50]
      94:      	add	sp, sp, #0x70
      98:      	ret
