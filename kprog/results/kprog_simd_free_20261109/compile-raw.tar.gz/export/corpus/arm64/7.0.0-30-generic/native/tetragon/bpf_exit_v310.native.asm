
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_exit_v310.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/acct_process:

0000000000000000 <event_exit_acct_process>:
       0:      	str	x30, [sp, #-0x40]!
       4:      	stp	x24, x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	mov	w8, #0xe                // =14
      14:      	mov	x21, x0
      18:      	blr	x8
      1c:      	lsr	x24, x0, #32
      20:      	adrp	x20, 0x0 <event_exit_acct_process>
      24:      	mov	w8, #0x1                // =1
      28:      	str	w24, [sp, #0xc]
      2c:      	add	x9, sp, #0xc
      30:      	add	x1, sp, #0xc
      34:      	ldr	x20, [x20]
      38:      	mov	x0, x20
      3c:      	blr	x8
      40:      	cbz	x0, 0x21c <event_exit_acct_process+0x21c>
      44:      	ldr	x8, [x0, #0x8]
      48:      	mov	x19, x0
      4c:      	cbz	x8, 0x190 <event_exit_acct_process+0x190>
      50:      	mov	w8, #0x23               // =35
      54:      	blr	x8
      58:      	mov	x22, x0
      5c:      	str	wzr, [sp, #0x8]
      60:      	adrp	x0, 0x0 <event_exit_acct_process>
      64:      	mov	w8, #0x1                // =1
      68:      	ldr	x0, [x0]
      6c:      	add	x9, sp, #0x8
      70:      	add	x1, sp, #0x8
      74:      	blr	x8
      78:      	cbz	x0, 0x21c <event_exit_acct_process+0x21c>
      7c:      	mov	x8, #0x7                // =7
      80:      	mov	x23, x0
      84:      	movk	x8, #0x28, lsl #32
      88:      	str	x8, [x0]
      8c:      	mov	w8, #0x5                // =5
      90:      	blr	x8
      94:      	str	x0, [x23, #0x8]
      98:      	stp	w24, wzr, [x23, #0x10]
      9c:      	add	x0, x23, #0x20
      a0:      	add	x2, x22, #0x86c
      a4:      	mov	w1, #0x4                // =4
      a8:      	ldr	x8, [x19, #0x8]
      ac:      	str	w24, [x23, #0x24]
      b0:      	str	x8, [x23, #0x18]
      b4:      	mov	w8, #0x4                // =4
      b8:      	blr	x8
      bc:      	adrp	x1, 0x0 <event_exit_acct_process>
      c0:      	mov	w8, #-0x1               // =-1
      c4:      	mov	w9, #0x28               // =40
      c8:      	ldr	x1, [x1]
      cc:      	mov	w10, #0x19              // =25
      d0:      	mov	x0, x21
      d4:      	mov	w2, #-0x1               // =-1
      d8:      	mov	x3, x23
      dc:      	mov	w4, #0x28               // =40
      e0:      	blr	x10
      e4:      	tbz	x0, #0x3f, 0x190 <event_exit_acct_process+0x190>
      e8:      	mov	x21, x0
      ec:      	str	wzr, [sp, #0xc]
      f0:      	adrp	x0, 0x0 <event_exit_acct_process>
      f4:      	mov	w8, #0x1                // =1
      f8:      	ldr	x0, [x0]
      fc:      	add	x9, sp, #0xc
     100:      	add	x1, sp, #0xc
     104:      	blr	x8
     108:      	cbz	x0, 0x190 <event_exit_acct_process+0x190>
     10c:      	mov	x8, x21
     110:      	cmn	x21, #0xc
     114:      	b.gt	0x138 <event_exit_acct_process+0x138>
     118:      	cmn	x8, #0x1c
     11c:      	b.eq	0x158 <event_exit_acct_process+0x158>
     120:      	cmn	x8, #0x16
     124:      	b.eq	0x170 <event_exit_acct_process+0x170>
     128:      	cmn	x8, #0x10
     12c:      	b.ne	0x168 <event_exit_acct_process+0x168>
     130:      	add	x8, x0, #0x1a0
     134:      	b	0x180 <event_exit_acct_process+0x180>
     138:      	cmn	x8, #0xb
     13c:      	b.eq	0x160 <event_exit_acct_process+0x160>
     140:      	cmn	x8, #0x7
     144:      	b.eq	0x178 <event_exit_acct_process+0x178>
     148:      	cmn	x8, #0x2
     14c:      	b.ne	0x168 <event_exit_acct_process+0x168>
     150:      	add	x8, x0, #0x190
     154:      	b	0x180 <event_exit_acct_process+0x180>
     158:      	add	x8, x0, #0x1b0
     15c:      	b	0x180 <event_exit_acct_process+0x180>
     160:      	add	x8, x0, #0x1b8
     164:      	b	0x180 <event_exit_acct_process+0x180>
     168:      	add	x8, x0, #0x188
     16c:      	b	0x180 <event_exit_acct_process+0x180>
     170:      	add	x8, x0, #0x1a8
     174:      	b	0x180 <event_exit_acct_process+0x180>
     178:      	add	x8, x0, #0x198
     17c:      	nop
     180:      	ldaxr	x9, [x8]
     184:      	add	x9, x9, #0x1
     188:      	stlxr	w10, x9, [x8]
     18c:      	cbnz	w10, 0x180 <event_exit_acct_process+0x180>
     190:      	str	w24, [sp, #0x8]
     194:      	mov	w8, #0x3                // =3
     198:      	add	x9, sp, #0x8
     19c:      	add	x1, sp, #0x8
     1a0:      	mov	x0, x20
     1a4:      	blr	x8
     1a8:      	cbz	w0, 0x1dc <event_exit_acct_process+0x1dc>
     1ac:      	mov	w8, #0x2                // =2
     1b0:      	adrp	x0, 0x0 <event_exit_acct_process>
     1b4:      	add	x9, sp, #0xc
     1b8:      	str	w8, [sp, #0xc]
     1bc:      	mov	w8, #0x1                // =1
     1c0:      	add	x1, sp, #0xc
     1c4:      	ldr	x0, [x0]
     1c8:      	blr	x8
     1cc:      	cbz	x0, 0x208 <event_exit_acct_process+0x208>
     1d0:      	ldr	x8, [x0]
     1d4:      	add	x8, x8, #0x1
     1d8:      	b	0x204 <event_exit_acct_process+0x204>
     1dc:      	str	wzr, [sp, #0xc]
     1e0:      	adrp	x0, 0x0 <event_exit_acct_process>
     1e4:      	mov	w8, #0x1                // =1
     1e8:      	add	x9, sp, #0xc
     1ec:      	ldr	x0, [x0]
     1f0:      	add	x1, sp, #0xc
     1f4:      	blr	x8
     1f8:      	cbz	x0, 0x208 <event_exit_acct_process+0x208>
     1fc:      	ldr	x8, [x0]
     200:      	sub	x8, x8, #0x1
     204:      	str	x8, [x0]
     208:      	adrp	x0, 0x0 <event_exit_acct_process>
     20c:      	mov	w8, #0x3                // =3
     210:      	mov	x1, x19
     214:      	ldr	x0, [x0]
     218:      	blr	x8
     21c:      	ldp	x20, x19, [sp, #0x30]
     220:      	mov	w0, wzr
     224:      	ldp	x22, x21, [sp, #0x20]
     228:      	ldp	x24, x23, [sp, #0x10]
     22c:      	ldr	x30, [sp], #0x40
     230:      	ret

Disassembly of section kprobe/disassociate_ctty:

0000000000000000 <event_exit_disassociate_ctty>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	mov	w8, #0x8                // =8
      18:      	mov	w9, #0x4                // =4
      1c:      	add	x10, sp, #0x8
      20:      	mov	x21, x0
      24:      	add	x0, sp, #0x8
      28:      	mov	w1, #0x8                // =8
      2c:      	mov	x2, x21
      30:      	blr	x9
      34:      	ldr	w8, [sp, #0x8]
      38:      	cbz	w8, 0x240 <event_exit_disassociate_ctty+0x240>
      3c:      	mov	w8, #0xe                // =14
      40:      	blr	x8
      44:      	lsr	x24, x0, #32
      48:      	adrp	x20, 0x0 <event_exit_disassociate_ctty>
      4c:      	mov	w8, #0x1                // =1
      50:      	str	w24, [sp, #0x8]
      54:      	add	x9, sp, #0x8
      58:      	add	x1, sp, #0x8
      5c:      	ldr	x20, [x20]
      60:      	mov	x0, x20
      64:      	blr	x8
      68:      	cbz	x0, 0x240 <event_exit_disassociate_ctty+0x240>
      6c:      	ldr	x8, [x0, #0x8]
      70:      	mov	x19, x0
      74:      	cbz	x8, 0x1b4 <event_exit_disassociate_ctty+0x1b4>
      78:      	mov	w8, #0x23               // =35
      7c:      	blr	x8
      80:      	mov	x22, x0
      84:      	str	wzr, [sp, #0x1c]
      88:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
      8c:      	mov	w8, #0x1                // =1
      90:      	ldr	x0, [x0]
      94:      	add	x9, sp, #0x1c
      98:      	add	x1, sp, #0x1c
      9c:      	blr	x8
      a0:      	cbz	x0, 0x240 <event_exit_disassociate_ctty+0x240>
      a4:      	mov	x8, #0x7                // =7
      a8:      	mov	x23, x0
      ac:      	movk	x8, #0x28, lsl #32
      b0:      	str	x8, [x0]
      b4:      	mov	w8, #0x5                // =5
      b8:      	blr	x8
      bc:      	str	x0, [x23, #0x8]
      c0:      	stp	w24, wzr, [x23, #0x10]
      c4:      	add	x0, x23, #0x20
      c8:      	add	x2, x22, #0x86c
      cc:      	mov	w1, #0x4                // =4
      d0:      	ldr	x8, [x19, #0x8]
      d4:      	str	w24, [x23, #0x24]
      d8:      	str	x8, [x23, #0x18]
      dc:      	mov	w8, #0x4                // =4
      e0:      	blr	x8
      e4:      	adrp	x1, 0x0 <event_exit_disassociate_ctty>
      e8:      	mov	w8, #-0x1               // =-1
      ec:      	mov	w9, #0x28               // =40
      f0:      	ldr	x1, [x1]
      f4:      	mov	w10, #0x19              // =25
      f8:      	mov	x0, x21
      fc:      	mov	w2, #-0x1               // =-1
     100:      	mov	x3, x23
     104:      	mov	w4, #0x28               // =40
     108:      	blr	x10
     10c:      	tbz	x0, #0x3f, 0x1b4 <event_exit_disassociate_ctty+0x1b4>
     110:      	mov	x21, x0
     114:      	str	wzr, [sp, #0x8]
     118:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     11c:      	mov	w8, #0x1                // =1
     120:      	ldr	x0, [x0]
     124:      	add	x9, sp, #0x8
     128:      	add	x1, sp, #0x8
     12c:      	blr	x8
     130:      	cbz	x0, 0x1b4 <event_exit_disassociate_ctty+0x1b4>
     134:      	mov	x8, x21
     138:      	cmn	x21, #0xc
     13c:      	b.gt	0x160 <event_exit_disassociate_ctty+0x160>
     140:      	cmn	x8, #0x1c
     144:      	b.eq	0x180 <event_exit_disassociate_ctty+0x180>
     148:      	cmn	x8, #0x16
     14c:      	b.eq	0x198 <event_exit_disassociate_ctty+0x198>
     150:      	cmn	x8, #0x10
     154:      	b.ne	0x190 <event_exit_disassociate_ctty+0x190>
     158:      	add	x8, x0, #0x1a0
     15c:      	b	0x1a4 <event_exit_disassociate_ctty+0x1a4>
     160:      	cmn	x8, #0xb
     164:      	b.eq	0x188 <event_exit_disassociate_ctty+0x188>
     168:      	cmn	x8, #0x7
     16c:      	b.eq	0x1a0 <event_exit_disassociate_ctty+0x1a0>
     170:      	cmn	x8, #0x2
     174:      	b.ne	0x190 <event_exit_disassociate_ctty+0x190>
     178:      	add	x8, x0, #0x190
     17c:      	b	0x1a4 <event_exit_disassociate_ctty+0x1a4>
     180:      	add	x8, x0, #0x1b0
     184:      	b	0x1a4 <event_exit_disassociate_ctty+0x1a4>
     188:      	add	x8, x0, #0x1b8
     18c:      	b	0x1a4 <event_exit_disassociate_ctty+0x1a4>
     190:      	add	x8, x0, #0x188
     194:      	b	0x1a4 <event_exit_disassociate_ctty+0x1a4>
     198:      	add	x8, x0, #0x1a8
     19c:      	b	0x1a4 <event_exit_disassociate_ctty+0x1a4>
     1a0:      	add	x8, x0, #0x198
     1a4:      	ldaxr	x9, [x8]
     1a8:      	add	x9, x9, #0x1
     1ac:      	stlxr	w10, x9, [x8]
     1b0:      	cbnz	w10, 0x1a4 <event_exit_disassociate_ctty+0x1a4>
     1b4:      	str	w24, [sp, #0x1c]
     1b8:      	mov	w8, #0x3                // =3
     1bc:      	add	x9, sp, #0x1c
     1c0:      	add	x1, sp, #0x1c
     1c4:      	mov	x0, x20
     1c8:      	blr	x8
     1cc:      	cbz	w0, 0x200 <event_exit_disassociate_ctty+0x200>
     1d0:      	mov	w8, #0x2                // =2
     1d4:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     1d8:      	add	x9, sp, #0x8
     1dc:      	str	w8, [sp, #0x8]
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x1, sp, #0x8
     1e8:      	ldr	x0, [x0]
     1ec:      	blr	x8
     1f0:      	cbz	x0, 0x22c <event_exit_disassociate_ctty+0x22c>
     1f4:      	ldr	x8, [x0]
     1f8:      	add	x8, x8, #0x1
     1fc:      	b	0x228 <event_exit_disassociate_ctty+0x228>
     200:      	str	wzr, [sp, #0x8]
     204:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     208:      	mov	w8, #0x1                // =1
     20c:      	add	x9, sp, #0x8
     210:      	ldr	x0, [x0]
     214:      	add	x1, sp, #0x8
     218:      	blr	x8
     21c:      	cbz	x0, 0x22c <event_exit_disassociate_ctty+0x22c>
     220:      	ldr	x8, [x0]
     224:      	sub	x8, x8, #0x1
     228:      	str	x8, [x0]
     22c:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     230:      	mov	w8, #0x3                // =3
     234:      	mov	x1, x19
     238:      	ldr	x0, [x0]
     23c:      	blr	x8
     240:      	ldp	x20, x19, [sp, #0x40]
     244:      	mov	w0, wzr
     248:      	ldr	x30, [sp, #0x10]
     24c:      	ldp	x22, x21, [sp, #0x30]
     250:      	ldp	x24, x23, [sp, #0x20]
     254:      	add	sp, sp, #0x50
     258:      	ret
