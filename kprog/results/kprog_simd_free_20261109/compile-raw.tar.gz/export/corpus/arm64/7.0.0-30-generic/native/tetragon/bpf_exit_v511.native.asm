
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_exit_v511.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/acct_process:

0000000000000000 <event_exit_acct_process>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	mov	w8, #0xe                // =14
      18:      	mov	x21, x0
      1c:      	blr	x8
      20:      	lsr	x24, x0, #32
      24:      	adrp	x20, 0x0 <event_exit_acct_process>
      28:      	mov	w8, #0x1                // =1
      2c:      	str	w24, [sp, #0x1c]
      30:      	add	x9, sp, #0x1c
      34:      	add	x1, sp, #0x1c
      38:      	ldr	x20, [x20]
      3c:      	mov	x0, x20
      40:      	blr	x8
      44:      	cbz	x0, 0x31c <event_exit_acct_process+0x31c>
      48:      	ldr	x8, [x0, #0x8]
      4c:      	mov	x19, x0
      50:      	cbz	x8, 0x290 <event_exit_acct_process+0x290>
      54:      	mov	w8, #0x23               // =35
      58:      	blr	x8
      5c:      	mov	x23, x0
      60:      	str	wzr, [sp, #0xc]
      64:      	adrp	x0, 0x0 <event_exit_acct_process>
      68:      	mov	w8, #0x1                // =1
      6c:      	ldr	x0, [x0]
      70:      	add	x9, sp, #0xc
      74:      	add	x1, sp, #0xc
      78:      	blr	x8
      7c:      	cbz	x0, 0x31c <event_exit_acct_process+0x31c>
      80:      	mov	x8, #0x7                // =7
      84:      	mov	x22, x0
      88:      	movk	x8, #0x28, lsl #32
      8c:      	str	x8, [x0]
      90:      	mov	w8, #0x7d               // =125
      94:      	blr	x8
      98:      	str	x0, [x22, #0x8]
      9c:      	stp	w24, wzr, [x22, #0x10]
      a0:      	add	x0, x22, #0x20
      a4:      	add	x2, x23, #0x86c
      a8:      	mov	w1, #0x4                // =4
      ac:      	ldr	x8, [x19, #0x8]
      b0:      	str	w24, [x22, #0x24]
      b4:      	str	x8, [x22, #0x18]
      b8:      	mov	w8, #0x4                // =4
      bc:      	blr	x8
      c0:      	str	wzr, [sp, #0x18]
      c4:      	adrp	x0, 0x0 <event_exit_acct_process>
      c8:      	mov	w8, #0x1                // =1
      cc:      	add	x9, sp, #0x18
      d0:      	ldr	x0, [x0]
      d4:      	add	x1, sp, #0x18
      d8:      	blr	x8
      dc:      	cbz	x0, 0x164 <event_exit_acct_process+0x164>
      e0:      	ldrb	w8, [x0, #0x28]
      e4:      	cbz	w8, 0x164 <event_exit_acct_process+0x164>
      e8:      	adrp	x1, 0x0 <event_exit_acct_process>
      ec:      	mov	w8, #-0x1               // =-1
      f0:      	mov	w9, #0x28               // =40
      f4:      	ldr	x1, [x1]
      f8:      	mov	w10, #0x19              // =25
      fc:      	mov	x0, x21
     100:      	mov	w2, #-0x1               // =-1
     104:      	mov	x3, x22
     108:      	mov	w4, #0x28               // =40
     10c:      	blr	x10
     110:      	tbz	x0, #0x3f, 0x290 <event_exit_acct_process+0x290>
     114:      	mov	x21, x0
     118:      	str	wzr, [sp, #0x1c]
     11c:      	adrp	x0, 0x0 <event_exit_acct_process>
     120:      	mov	w8, #0x1                // =1
     124:      	ldr	x0, [x0]
     128:      	add	x9, sp, #0x1c
     12c:      	add	x1, sp, #0x1c
     130:      	blr	x8
     134:      	cbz	x0, 0x290 <event_exit_acct_process+0x290>
     138:      	mov	x8, x21
     13c:      	cmn	x21, #0xc
     140:      	b.gt	0x1f8 <event_exit_acct_process+0x1f8>
     144:      	cmn	x8, #0x1c
     148:      	b.eq	0x254 <event_exit_acct_process+0x254>
     14c:      	cmn	x8, #0x16
     150:      	b.eq	0x26c <event_exit_acct_process+0x26c>
     154:      	cmn	x8, #0x10
     158:      	b.ne	0x264 <event_exit_acct_process+0x264>
     15c:      	add	x8, x0, #0x1a0
     160:      	b	0x280 <event_exit_acct_process+0x280>
     164:      	adrp	x0, 0x0 <event_exit_acct_process>
     168:      	mov	x3, xzr
     16c:      	mov	w8, #0x28               // =40
     170:      	ldr	x0, [x0]
     174:      	mov	w9, #0x82               // =130
     178:      	mov	x1, x22
     17c:      	mov	w2, #0x28               // =40
     180:      	blr	x9
     184:      	tbz	x0, #0x3f, 0x290 <event_exit_acct_process+0x290>
     188:      	mov	x21, x0
     18c:      	str	wzr, [sp, #0x1c]
     190:      	adrp	x0, 0x0 <event_exit_acct_process>
     194:      	mov	w8, #0x1                // =1
     198:      	ldr	x0, [x0]
     19c:      	add	x9, sp, #0x1c
     1a0:      	add	x1, sp, #0x1c
     1a4:      	blr	x8
     1a8:      	cbz	x0, 0x290 <event_exit_acct_process+0x290>
     1ac:      	mov	x8, x21
     1b0:      	cmn	x21, #0xc
     1b4:      	b.gt	0x1d8 <event_exit_acct_process+0x1d8>
     1b8:      	cmn	x8, #0x1c
     1bc:      	b.eq	0x218 <event_exit_acct_process+0x218>
     1c0:      	cmn	x8, #0x16
     1c4:      	b.eq	0x230 <event_exit_acct_process+0x230>
     1c8:      	cmn	x8, #0x10
     1cc:      	b.ne	0x228 <event_exit_acct_process+0x228>
     1d0:      	add	x8, x0, #0x1a0
     1d4:      	b	0x240 <event_exit_acct_process+0x240>
     1d8:      	cmn	x8, #0xb
     1dc:      	b.eq	0x220 <event_exit_acct_process+0x220>
     1e0:      	cmn	x8, #0x7
     1e4:      	b.eq	0x238 <event_exit_acct_process+0x238>
     1e8:      	cmn	x8, #0x2
     1ec:      	b.ne	0x228 <event_exit_acct_process+0x228>
     1f0:      	add	x8, x0, #0x190
     1f4:      	b	0x240 <event_exit_acct_process+0x240>
     1f8:      	cmn	x8, #0xb
     1fc:      	b.eq	0x25c <event_exit_acct_process+0x25c>
     200:      	cmn	x8, #0x7
     204:      	b.eq	0x274 <event_exit_acct_process+0x274>
     208:      	cmn	x8, #0x2
     20c:      	b.ne	0x264 <event_exit_acct_process+0x264>
     210:      	add	x8, x0, #0x190
     214:      	b	0x280 <event_exit_acct_process+0x280>
     218:      	add	x8, x0, #0x1b0
     21c:      	b	0x240 <event_exit_acct_process+0x240>
     220:      	add	x8, x0, #0x1b8
     224:      	b	0x240 <event_exit_acct_process+0x240>
     228:      	add	x8, x0, #0x188
     22c:      	b	0x240 <event_exit_acct_process+0x240>
     230:      	add	x8, x0, #0x1a8
     234:      	b	0x240 <event_exit_acct_process+0x240>
     238:      	add	x8, x0, #0x198
     23c:      	nop
     240:      	ldaxr	x9, [x8]
     244:      	add	x9, x9, #0x1
     248:      	stlxr	w10, x9, [x8]
     24c:      	cbnz	w10, 0x240 <event_exit_acct_process+0x240>
     250:      	b	0x290 <event_exit_acct_process+0x290>
     254:      	add	x8, x0, #0x1b0
     258:      	b	0x280 <event_exit_acct_process+0x280>
     25c:      	add	x8, x0, #0x1b8
     260:      	b	0x280 <event_exit_acct_process+0x280>
     264:      	add	x8, x0, #0x188
     268:      	b	0x280 <event_exit_acct_process+0x280>
     26c:      	add	x8, x0, #0x1a8
     270:      	b	0x280 <event_exit_acct_process+0x280>
     274:      	add	x8, x0, #0x198
     278:      	nop
     27c:      	nop
     280:      	ldaxr	x9, [x8]
     284:      	add	x9, x9, #0x1
     288:      	stlxr	w10, x9, [x8]
     28c:      	cbnz	w10, 0x280 <event_exit_acct_process+0x280>
     290:      	str	w24, [sp, #0x18]
     294:      	mov	w8, #0x3                // =3
     298:      	add	x9, sp, #0x18
     29c:      	add	x1, sp, #0x18
     2a0:      	mov	x0, x20
     2a4:      	blr	x8
     2a8:      	cbz	w0, 0x2dc <event_exit_acct_process+0x2dc>
     2ac:      	mov	w8, #0x2                // =2
     2b0:      	adrp	x0, 0x0 <event_exit_acct_process>
     2b4:      	add	x9, sp, #0x1c
     2b8:      	str	w8, [sp, #0x1c]
     2bc:      	mov	w8, #0x1                // =1
     2c0:      	add	x1, sp, #0x1c
     2c4:      	ldr	x0, [x0]
     2c8:      	blr	x8
     2cc:      	cbz	x0, 0x308 <event_exit_acct_process+0x308>
     2d0:      	ldr	x8, [x0]
     2d4:      	add	x8, x8, #0x1
     2d8:      	b	0x304 <event_exit_acct_process+0x304>
     2dc:      	str	wzr, [sp, #0x1c]
     2e0:      	adrp	x0, 0x0 <event_exit_acct_process>
     2e4:      	mov	w8, #0x1                // =1
     2e8:      	add	x9, sp, #0x1c
     2ec:      	ldr	x0, [x0]
     2f0:      	add	x1, sp, #0x1c
     2f4:      	blr	x8
     2f8:      	cbz	x0, 0x308 <event_exit_acct_process+0x308>
     2fc:      	ldr	x8, [x0]
     300:      	sub	x8, x8, #0x1
     304:      	str	x8, [x0]
     308:      	adrp	x0, 0x0 <event_exit_acct_process>
     30c:      	mov	w8, #0x3                // =3
     310:      	mov	x1, x19
     314:      	ldr	x0, [x0]
     318:      	blr	x8
     31c:      	ldp	x20, x19, [sp, #0x40]
     320:      	mov	w0, wzr
     324:      	ldr	x30, [sp, #0x10]
     328:      	ldp	x22, x21, [sp, #0x30]
     32c:      	ldp	x24, x23, [sp, #0x20]
     330:      	add	sp, sp, #0x50
     334:      	ret

Disassembly of section kprobe/disassociate_ctty:

0000000000000000 <event_exit_disassociate_ctty>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	mov	w8, #0x8                // =8
      18:      	mov	w9, #0x4                // =4
      1c:      	add	x10, sp, #0x8
      20:      	mov	x21, x0
      24:      	add	x0, sp, #0x8
      28:      	mov	w1, #0x8                // =8
      2c:      	mov	x2, x21
      30:      	blr	x9
      34:      	ldr	w8, [sp, #0x8]
      38:      	cbz	w8, 0x33c <event_exit_disassociate_ctty+0x33c>
      3c:      	mov	w8, #0xe                // =14
      40:      	blr	x8
      44:      	lsr	x24, x0, #32
      48:      	adrp	x20, 0x0 <event_exit_disassociate_ctty>
      4c:      	mov	w8, #0x1                // =1
      50:      	str	w24, [sp, #0x8]
      54:      	add	x9, sp, #0x8
      58:      	add	x1, sp, #0x8
      5c:      	ldr	x20, [x20]
      60:      	mov	x0, x20
      64:      	blr	x8
      68:      	cbz	x0, 0x33c <event_exit_disassociate_ctty+0x33c>
      6c:      	ldr	x8, [x0, #0x8]
      70:      	mov	x19, x0
      74:      	cbz	x8, 0x2b0 <event_exit_disassociate_ctty+0x2b0>
      78:      	mov	w8, #0x23               // =35
      7c:      	blr	x8
      80:      	mov	x23, x0
      84:      	str	wzr, [sp, #0x18]
      88:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
      8c:      	mov	w8, #0x1                // =1
      90:      	ldr	x0, [x0]
      94:      	add	x9, sp, #0x18
      98:      	add	x1, sp, #0x18
      9c:      	blr	x8
      a0:      	cbz	x0, 0x33c <event_exit_disassociate_ctty+0x33c>
      a4:      	mov	x8, #0x7                // =7
      a8:      	mov	x22, x0
      ac:      	movk	x8, #0x28, lsl #32
      b0:      	str	x8, [x0]
      b4:      	mov	w8, #0x7d               // =125
      b8:      	blr	x8
      bc:      	str	x0, [x22, #0x8]
      c0:      	stp	w24, wzr, [x22, #0x10]
      c4:      	add	x0, x22, #0x20
      c8:      	add	x2, x23, #0x86c
      cc:      	mov	w1, #0x4                // =4
      d0:      	ldr	x8, [x19, #0x8]
      d4:      	str	w24, [x22, #0x24]
      d8:      	str	x8, [x22, #0x18]
      dc:      	mov	w8, #0x4                // =4
      e0:      	blr	x8
      e4:      	str	wzr, [sp, #0x1c]
      e8:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
      ec:      	mov	w8, #0x1                // =1
      f0:      	add	x9, sp, #0x1c
      f4:      	ldr	x0, [x0]
      f8:      	add	x1, sp, #0x1c
      fc:      	blr	x8
     100:      	cbz	x0, 0x188 <event_exit_disassociate_ctty+0x188>
     104:      	ldrb	w8, [x0, #0x28]
     108:      	cbz	w8, 0x188 <event_exit_disassociate_ctty+0x188>
     10c:      	adrp	x1, 0x0 <event_exit_disassociate_ctty>
     110:      	mov	w8, #-0x1               // =-1
     114:      	mov	w9, #0x28               // =40
     118:      	ldr	x1, [x1]
     11c:      	mov	w10, #0x19              // =25
     120:      	mov	x0, x21
     124:      	mov	w2, #-0x1               // =-1
     128:      	mov	x3, x22
     12c:      	mov	w4, #0x28               // =40
     130:      	blr	x10
     134:      	tbz	x0, #0x3f, 0x2b0 <event_exit_disassociate_ctty+0x2b0>
     138:      	mov	x21, x0
     13c:      	str	wzr, [sp, #0x8]
     140:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     144:      	mov	w8, #0x1                // =1
     148:      	ldr	x0, [x0]
     14c:      	add	x9, sp, #0x8
     150:      	add	x1, sp, #0x8
     154:      	blr	x8
     158:      	cbz	x0, 0x2b0 <event_exit_disassociate_ctty+0x2b0>
     15c:      	mov	x8, x21
     160:      	cmn	x21, #0xc
     164:      	b.gt	0x21c <event_exit_disassociate_ctty+0x21c>
     168:      	cmn	x8, #0x1c
     16c:      	b.eq	0x274 <event_exit_disassociate_ctty+0x274>
     170:      	cmn	x8, #0x16
     174:      	b.eq	0x28c <event_exit_disassociate_ctty+0x28c>
     178:      	cmn	x8, #0x10
     17c:      	b.ne	0x284 <event_exit_disassociate_ctty+0x284>
     180:      	add	x8, x0, #0x1a0
     184:      	b	0x2a0 <event_exit_disassociate_ctty+0x2a0>
     188:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     18c:      	mov	x3, xzr
     190:      	mov	w8, #0x28               // =40
     194:      	ldr	x0, [x0]
     198:      	mov	w9, #0x82               // =130
     19c:      	mov	x1, x22
     1a0:      	mov	w2, #0x28               // =40
     1a4:      	blr	x9
     1a8:      	tbz	x0, #0x3f, 0x2b0 <event_exit_disassociate_ctty+0x2b0>
     1ac:      	mov	x21, x0
     1b0:      	str	wzr, [sp, #0x8]
     1b4:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     1b8:      	mov	w8, #0x1                // =1
     1bc:      	ldr	x0, [x0]
     1c0:      	add	x9, sp, #0x8
     1c4:      	add	x1, sp, #0x8
     1c8:      	blr	x8
     1cc:      	cbz	x0, 0x2b0 <event_exit_disassociate_ctty+0x2b0>
     1d0:      	mov	x8, x21
     1d4:      	cmn	x21, #0xc
     1d8:      	b.gt	0x1fc <event_exit_disassociate_ctty+0x1fc>
     1dc:      	cmn	x8, #0x1c
     1e0:      	b.eq	0x23c <event_exit_disassociate_ctty+0x23c>
     1e4:      	cmn	x8, #0x16
     1e8:      	b.eq	0x254 <event_exit_disassociate_ctty+0x254>
     1ec:      	cmn	x8, #0x10
     1f0:      	b.ne	0x24c <event_exit_disassociate_ctty+0x24c>
     1f4:      	add	x8, x0, #0x1a0
     1f8:      	b	0x260 <event_exit_disassociate_ctty+0x260>
     1fc:      	cmn	x8, #0xb
     200:      	b.eq	0x244 <event_exit_disassociate_ctty+0x244>
     204:      	cmn	x8, #0x7
     208:      	b.eq	0x25c <event_exit_disassociate_ctty+0x25c>
     20c:      	cmn	x8, #0x2
     210:      	b.ne	0x24c <event_exit_disassociate_ctty+0x24c>
     214:      	add	x8, x0, #0x190
     218:      	b	0x260 <event_exit_disassociate_ctty+0x260>
     21c:      	cmn	x8, #0xb
     220:      	b.eq	0x27c <event_exit_disassociate_ctty+0x27c>
     224:      	cmn	x8, #0x7
     228:      	b.eq	0x294 <event_exit_disassociate_ctty+0x294>
     22c:      	cmn	x8, #0x2
     230:      	b.ne	0x284 <event_exit_disassociate_ctty+0x284>
     234:      	add	x8, x0, #0x190
     238:      	b	0x2a0 <event_exit_disassociate_ctty+0x2a0>
     23c:      	add	x8, x0, #0x1b0
     240:      	b	0x260 <event_exit_disassociate_ctty+0x260>
     244:      	add	x8, x0, #0x1b8
     248:      	b	0x260 <event_exit_disassociate_ctty+0x260>
     24c:      	add	x8, x0, #0x188
     250:      	b	0x260 <event_exit_disassociate_ctty+0x260>
     254:      	add	x8, x0, #0x1a8
     258:      	b	0x260 <event_exit_disassociate_ctty+0x260>
     25c:      	add	x8, x0, #0x198
     260:      	ldaxr	x9, [x8]
     264:      	add	x9, x9, #0x1
     268:      	stlxr	w10, x9, [x8]
     26c:      	cbnz	w10, 0x260 <event_exit_disassociate_ctty+0x260>
     270:      	b	0x2b0 <event_exit_disassociate_ctty+0x2b0>
     274:      	add	x8, x0, #0x1b0
     278:      	b	0x2a0 <event_exit_disassociate_ctty+0x2a0>
     27c:      	add	x8, x0, #0x1b8
     280:      	b	0x2a0 <event_exit_disassociate_ctty+0x2a0>
     284:      	add	x8, x0, #0x188
     288:      	b	0x2a0 <event_exit_disassociate_ctty+0x2a0>
     28c:      	add	x8, x0, #0x1a8
     290:      	b	0x2a0 <event_exit_disassociate_ctty+0x2a0>
     294:      	add	x8, x0, #0x198
     298:      	nop
     29c:      	nop
     2a0:      	ldaxr	x9, [x8]
     2a4:      	add	x9, x9, #0x1
     2a8:      	stlxr	w10, x9, [x8]
     2ac:      	cbnz	w10, 0x2a0 <event_exit_disassociate_ctty+0x2a0>
     2b0:      	str	w24, [sp, #0x1c]
     2b4:      	mov	w8, #0x3                // =3
     2b8:      	add	x9, sp, #0x1c
     2bc:      	add	x1, sp, #0x1c
     2c0:      	mov	x0, x20
     2c4:      	blr	x8
     2c8:      	cbz	w0, 0x2fc <event_exit_disassociate_ctty+0x2fc>
     2cc:      	mov	w8, #0x2                // =2
     2d0:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     2d4:      	add	x9, sp, #0x8
     2d8:      	str	w8, [sp, #0x8]
     2dc:      	mov	w8, #0x1                // =1
     2e0:      	add	x1, sp, #0x8
     2e4:      	ldr	x0, [x0]
     2e8:      	blr	x8
     2ec:      	cbz	x0, 0x328 <event_exit_disassociate_ctty+0x328>
     2f0:      	ldr	x8, [x0]
     2f4:      	add	x8, x8, #0x1
     2f8:      	b	0x324 <event_exit_disassociate_ctty+0x324>
     2fc:      	str	wzr, [sp, #0x8]
     300:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     304:      	mov	w8, #0x1                // =1
     308:      	add	x9, sp, #0x8
     30c:      	ldr	x0, [x0]
     310:      	add	x1, sp, #0x8
     314:      	blr	x8
     318:      	cbz	x0, 0x328 <event_exit_disassociate_ctty+0x328>
     31c:      	ldr	x8, [x0]
     320:      	sub	x8, x8, #0x1
     324:      	str	x8, [x0]
     328:      	adrp	x0, 0x0 <event_exit_disassociate_ctty>
     32c:      	mov	w8, #0x3                // =3
     330:      	mov	x1, x19
     334:      	ldr	x0, [x0]
     338:      	blr	x8
     33c:      	ldp	x20, x19, [sp, #0x40]
     340:      	mov	w0, wzr
     344:      	ldr	x30, [sp, #0x10]
     348:      	ldp	x22, x21, [sp, #0x30]
     34c:      	ldp	x24, x23, [sp, #0x20]
     350:      	add	sp, sp, #0x50
     354:      	ret
