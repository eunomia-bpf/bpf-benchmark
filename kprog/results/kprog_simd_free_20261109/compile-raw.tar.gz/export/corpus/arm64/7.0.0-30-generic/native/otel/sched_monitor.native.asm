
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/sched_monitor.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint/sched/sched_process_free/v2:

0000000000000000 <tracepoint__sched_process_free>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x30, [sp, #0x60]
       8:      	stp	x22, x21, [sp, #0x70]
       c:      	stp	x20, x19, [sp, #0x80]
      10:      	ldr	w8, [x0, #0xc]
      14:      	adrp	x20, 0x0 <tracepoint__sched_process_free>
      18:      	mov	w9, #0x1                // =1
      1c:      	mov	x19, x0
      20:      	str	w8, [sp, #0xc]
      24:      	add	x8, sp, #0xc
      28:      	add	x1, sp, #0xc
      2c:      	mov	w22, #0x1               // =1
      30:      	ldr	x20, [x20]
      34:      	mov	x0, x20
      38:      	blr	x9
      3c:      	cbnz	x0, 0x70 <tracepoint__sched_process_free+0x70>
      40:      	ldr	w8, [sp, #0xc]
      44:      	mov	w9, #0x60               // =96
      48:      	str	xzr, [sp, #0x28]
      4c:      	adrp	x0, 0x0 <tracepoint__sched_process_free>
      50:      	add	x1, sp, #0x20
      54:      	rev	w8, w8
      58:      	stp	w9, w8, [sp, #0x20]
      5c:      	mov	w8, #0x1                // =1
      60:      	add	x9, sp, #0x20
      64:      	ldr	x0, [x0]
      68:      	blr	x8
      6c:      	cbz	x0, 0x108 <tracepoint__sched_process_free+0x108>
      70:      	ldr	w21, [sp, #0xc]
      74:      	mov	w9, #0x1                // =1
      78:      	add	x1, sp, #0x20
      7c:      	mov	x0, x20
      80:      	str	w21, [sp, #0x14]
      84:      	orr	x8, x21, x21, lsl #32
      88:      	str	w21, [sp, #0x20]
      8c:      	str	x8, [sp, #0x18]
      90:      	add	x8, sp, #0x20
      94:      	blr	x9
      98:      	mov	w8, #0x5                // =5
      9c:      	blr	x8
      a0:      	strb	w22, [sp, #0x10]
      a4:      	adrp	x0, 0x0 <tracepoint__sched_process_free>
      a8:      	mov	x3, xzr
      ac:      	mov	w8, #0x2                // =2
      b0:      	ldr	x0, [x0]
      b4:      	add	x9, sp, #0x18
      b8:      	add	x10, sp, #0x10
      bc:      	add	x1, sp, #0x18
      c0:      	add	x2, sp, #0x10
      c4:      	blr	x8
      c8:      	cbz	w0, 0x120 <tracepoint__sched_process_free+0x120>
      cc:      	adrp	x19, 0x0 <tracepoint__sched_process_free>
      d0:      	ldr	x19, [x19]
      d4:      	ldr	w8, [x19]
      d8:      	cbnz	w8, 0x2d4 <tracepoint__sched_process_free+0x2d4>
      dc:      	mov	w8, #0x3e               // =62
      e0:      	adrp	x0, 0x0 <tracepoint__sched_process_free>
      e4:      	add	x9, sp, #0x6c
      e8:      	str	w8, [sp, #0x6c]
      ec:      	mov	w8, #0x1                // =1
      f0:      	add	x1, sp, #0x6c
      f4:      	ldr	x0, [x0]
      f8:      	blr	x8
      fc:      	cbnz	x0, 0x264 <tracepoint__sched_process_free+0x264>
     100:      	ldr	w8, [x19]
     104:      	cbnz	w8, 0x324 <tracepoint__sched_process_free+0x324>
     108:      	ldp	x20, x19, [sp, #0x80]
     10c:      	mov	w0, wzr
     110:      	ldr	x30, [sp, #0x60]
     114:      	ldp	x22, x21, [sp, #0x70]
     118:      	add	sp, sp, #0x90
     11c:      	ret
     120:      	mov	w8, #0x3                // =3
     124:      	add	x9, sp, #0x14
     128:      	add	x1, sp, #0x14
     12c:      	mov	x0, x20
     130:      	blr	x8
     134:      	mov	w8, #0x1                // =1
     138:      	adrp	x0, 0x0 <tracepoint__sched_process_free>
     13c:      	mov	w9, #0x2                // =2
     140:      	str	w8, [sp, #0x68]
     144:      	strb	w8, [sp, #0x5c]
     148:      	add	x10, sp, #0x68
     14c:      	add	x11, sp, #0x5c
     150:      	add	x1, sp, #0x68
     154:      	ldr	x0, [x0]
     158:      	add	x2, sp, #0x5c
     15c:      	mov	w3, #0x1                // =1
     160:      	blr	x9
     164:      	tbnz	w0, #0x1f, 0x19c <tracepoint__sched_process_free+0x19c>
     168:      	mov	w8, #0x42               // =66
     16c:      	adrp	x0, 0x0 <tracepoint__sched_process_free>
     170:      	add	x9, sp, #0x6c
     174:      	str	w8, [sp, #0x6c]
     178:      	mov	w8, #0x1                // =1
     17c:      	add	x1, sp, #0x6c
     180:      	ldr	x0, [x0]
     184:      	blr	x8
     188:      	cbz	x0, 0x1e8 <tracepoint__sched_process_free+0x1e8>
     18c:      	ldr	x8, [x0]
     190:      	add	x8, x8, #0x1
     194:      	str	x8, [x0]
     198:      	b	0x1f8 <tracepoint__sched_process_free+0x1f8>
     19c:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     1a0:      	ldr	x8, [x8]
     1a4:      	ldr	w8, [x8]
     1a8:      	cbz	w8, 0x240 <tracepoint__sched_process_free+0x240>
     1ac:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     1b0:      	add	x8, x8, #0x0
     1b4:      	strb	wzr, [sp, #0x38]
     1b8:      	add	x0, sp, #0x20
     1bc:      	ldp	x9, x10, [x8]
     1c0:      	ldr	x8, [x8, #0x10]
     1c4:      	mov	w1, #0x19               // =25
     1c8:      	mov	w2, #0x1                // =1
     1cc:      	str	x8, [sp, #0x30]
     1d0:      	stp	x9, x10, [sp, #0x20]
     1d4:      	mov	w8, #0x19               // =25
     1d8:      	mov	w9, #0x6                // =6
     1dc:      	add	x10, sp, #0x20
     1e0:      	blr	x9
     1e4:      	b	0x240 <tracepoint__sched_process_free+0x240>
     1e8:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     1ec:      	ldr	x8, [x8]
     1f0:      	ldr	w8, [x8]
     1f4:      	cbnz	w8, 0x3cc <tracepoint__sched_process_free+0x3cc>
     1f8:      	mov	w8, #0x1                // =1
     1fc:      	adrp	x1, 0x0 <tracepoint__sched_process_free>
     200:      	mov	w9, #0x4                // =4
     204:      	str	w8, [sp, #0x6c]
     208:      	mov	w8, #-0x1               // =-1
     20c:      	mov	w10, #0x19              // =25
     210:      	add	x11, sp, #0x6c
     214:      	ldr	x1, [x1]
     218:      	add	x3, sp, #0x6c
     21c:      	mov	x0, x19
     220:      	mov	w2, #-0x1               // =-1
     224:      	mov	w4, #0x4                // =4
     228:      	blr	x10
     22c:      	tbz	w0, #0x1f, 0x240 <tracepoint__sched_process_free+0x240>
     230:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     234:      	ldr	x8, [x8]
     238:      	ldr	w8, [x8]
     23c:      	cbnz	w8, 0x380 <tracepoint__sched_process_free+0x380>
     240:      	mov	w8, #0x40               // =64
     244:      	adrp	x0, 0x0 <tracepoint__sched_process_free>
     248:      	add	x9, sp, #0x18
     24c:      	str	w8, [sp, #0x18]
     250:      	mov	w8, #0x1                // =1
     254:      	add	x1, sp, #0x18
     258:      	ldr	x0, [x0]
     25c:      	blr	x8
     260:      	cbz	x0, 0x288 <tracepoint__sched_process_free+0x288>
     264:      	ldr	x8, [x0]
     268:      	add	x8, x8, #0x1
     26c:      	str	x8, [x0]
     270:      	ldp	x20, x19, [sp, #0x80]
     274:      	mov	w0, wzr
     278:      	ldr	x30, [sp, #0x60]
     27c:      	ldp	x22, x21, [sp, #0x70]
     280:      	add	sp, sp, #0x90
     284:      	ret
     288:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     28c:      	ldr	x8, [x8]
     290:      	ldr	w8, [x8]
     294:      	cbz	w8, 0x108 <tracepoint__sched_process_free+0x108>
     298:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     29c:      	add	x8, x8, #0x0
     2a0:      	ldp	x9, x10, [x8, #0x10]
     2a4:      	stp	x9, x10, [sp, #0x30]
     2a8:      	ldr	x9, [x8, #0x20]
     2ac:      	add	x10, sp, #0x20
     2b0:      	str	x9, [sp, #0x40]
     2b4:      	ldur	x9, [x8, #0x26]
     2b8:      	stur	x9, [sp, #0x46]
     2bc:      	ldp	x9, x8, [x8]
     2c0:      	stp	x9, x8, [sp, #0x20]
     2c4:      	mov	w8, #0x2e               // =46
     2c8:      	mov	w9, #0x6                // =6
     2cc:      	ldr	w2, [sp, #0x18]
     2d0:      	b	0x35c <tracepoint__sched_process_free+0x35c>
     2d4:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     2d8:      	add	x8, x8, #0x0
     2dc:      	ldr	w3, [sp, #0x18]
     2e0:      	mov	w4, w0
     2e4:      	ldp	x9, x10, [x8, #0x20]
     2e8:      	add	x0, sp, #0x20
     2ec:      	mov	w1, #0x35               // =53
     2f0:      	mov	w2, w21
     2f4:      	stp	x9, x10, [sp, #0x40]
     2f8:      	ldur	x9, [x8, #0x2d]
     2fc:      	stur	x9, [sp, #0x4d]
     300:      	ldp	x9, x10, [x8]
     304:      	stp	x9, x10, [sp, #0x20]
     308:      	ldp	x8, x9, [x8, #0x10]
     30c:      	add	x10, sp, #0x20
     310:      	stp	x8, x9, [sp, #0x30]
     314:      	mov	w8, #0x35               // =53
     318:      	mov	w9, #0x6                // =6
     31c:      	blr	x9
     320:      	b	0xdc <tracepoint__sched_process_free+0xdc>
     324:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     328:      	add	x8, x8, #0x0
     32c:      	ldp	x9, x10, [x8, #0x10]
     330:      	stp	x9, x10, [sp, #0x30]
     334:      	ldr	x9, [x8, #0x20]
     338:      	add	x10, sp, #0x20
     33c:      	str	x9, [sp, #0x40]
     340:      	ldur	x9, [x8, #0x26]
     344:      	stur	x9, [sp, #0x46]
     348:      	ldp	x9, x8, [x8]
     34c:      	stp	x9, x8, [sp, #0x20]
     350:      	mov	w8, #0x2e               // =46
     354:      	mov	w9, #0x6                // =6
     358:      	ldr	w2, [sp, #0x6c]
     35c:      	add	x0, sp, #0x20
     360:      	mov	w1, #0x2e               // =46
     364:      	blr	x9
     368:      	ldp	x20, x19, [sp, #0x80]
     36c:      	mov	w0, wzr
     370:      	ldr	x30, [sp, #0x60]
     374:      	ldp	x22, x21, [sp, #0x70]
     378:      	add	sp, sp, #0x90
     37c:      	ret
     380:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     384:      	add	x8, x8, #0x0
     388:      	mov	w3, w0
     38c:      	ldp	x9, x10, [x8, #0x20]
     390:      	add	x0, sp, #0x20
     394:      	mov	w1, #0x36               // =54
     398:      	mov	w2, #0x1                // =1
     39c:      	stp	x9, x10, [sp, #0x40]
     3a0:      	ldur	x9, [x8, #0x2e]
     3a4:      	stur	x9, [sp, #0x4e]
     3a8:      	ldp	x9, x10, [x8]
     3ac:      	stp	x9, x10, [sp, #0x20]
     3b0:      	ldp	x8, x9, [x8, #0x10]
     3b4:      	add	x10, sp, #0x20
     3b8:      	stp	x8, x9, [sp, #0x30]
     3bc:      	mov	w8, #0x36               // =54
     3c0:      	mov	w9, #0x6                // =6
     3c4:      	blr	x9
     3c8:      	b	0x240 <tracepoint__sched_process_free+0x240>
     3cc:      	adrp	x8, 0x0 <tracepoint__sched_process_free>
     3d0:      	add	x8, x8, #0x0
     3d4:      	add	x0, sp, #0x20
     3d8:      	ldp	x9, x10, [x8, #0x10]
     3dc:      	mov	w1, #0x2e               // =46
     3e0:      	stp	x9, x10, [sp, #0x30]
     3e4:      	ldr	x9, [x8, #0x20]
     3e8:      	add	x10, sp, #0x20
     3ec:      	str	x9, [sp, #0x40]
     3f0:      	ldur	x9, [x8, #0x26]
     3f4:      	stur	x9, [sp, #0x46]
     3f8:      	ldp	x9, x8, [x8]
     3fc:      	stp	x9, x8, [sp, #0x20]
     400:      	mov	w8, #0x2e               // =46
     404:      	mov	w9, #0x6                // =6
     408:      	ldr	w2, [sp, #0x6c]
     40c:      	blr	x9
     410:      	b	0x1f8 <tracepoint__sched_process_free+0x1f8>

Disassembly of section tracepoint/sched/sched_process_free/v1:

0000000000000000 <tracepoint__sched_process_free_pre616>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x30, [sp, #0x60]
       8:      	stp	x22, x21, [sp, #0x70]
       c:      	stp	x20, x19, [sp, #0x80]
      10:      	ldr	w8, [x0, #0x18]
      14:      	adrp	x20, 0x0 <tracepoint__sched_process_free_pre616>
      18:      	mov	w9, #0x1                // =1
      1c:      	mov	x19, x0
      20:      	str	w8, [sp, #0xc]
      24:      	add	x8, sp, #0xc
      28:      	add	x1, sp, #0xc
      2c:      	mov	w22, #0x1               // =1
      30:      	ldr	x20, [x20]
      34:      	mov	x0, x20
      38:      	blr	x9
      3c:      	cbnz	x0, 0x70 <tracepoint__sched_process_free_pre616+0x70>
      40:      	ldr	w8, [sp, #0xc]
      44:      	mov	w9, #0x60               // =96
      48:      	str	xzr, [sp, #0x28]
      4c:      	adrp	x0, 0x0 <tracepoint__sched_process_free_pre616>
      50:      	add	x1, sp, #0x20
      54:      	rev	w8, w8
      58:      	stp	w9, w8, [sp, #0x20]
      5c:      	mov	w8, #0x1                // =1
      60:      	add	x9, sp, #0x20
      64:      	ldr	x0, [x0]
      68:      	blr	x8
      6c:      	cbz	x0, 0x108 <tracepoint__sched_process_free_pre616+0x108>
      70:      	ldr	w21, [sp, #0xc]
      74:      	mov	w9, #0x1                // =1
      78:      	add	x1, sp, #0x20
      7c:      	mov	x0, x20
      80:      	str	w21, [sp, #0x14]
      84:      	orr	x8, x21, x21, lsl #32
      88:      	str	w21, [sp, #0x20]
      8c:      	str	x8, [sp, #0x18]
      90:      	add	x8, sp, #0x20
      94:      	blr	x9
      98:      	mov	w8, #0x5                // =5
      9c:      	blr	x8
      a0:      	strb	w22, [sp, #0x10]
      a4:      	adrp	x0, 0x0 <tracepoint__sched_process_free_pre616>
      a8:      	mov	x3, xzr
      ac:      	mov	w8, #0x2                // =2
      b0:      	ldr	x0, [x0]
      b4:      	add	x9, sp, #0x18
      b8:      	add	x10, sp, #0x10
      bc:      	add	x1, sp, #0x18
      c0:      	add	x2, sp, #0x10
      c4:      	blr	x8
      c8:      	cbz	w0, 0x120 <tracepoint__sched_process_free_pre616+0x120>
      cc:      	adrp	x19, 0x0 <tracepoint__sched_process_free_pre616>
      d0:      	ldr	x19, [x19]
      d4:      	ldr	w8, [x19]
      d8:      	cbnz	w8, 0x2d4 <tracepoint__sched_process_free_pre616+0x2d4>
      dc:      	mov	w8, #0x3e               // =62
      e0:      	adrp	x0, 0x0 <tracepoint__sched_process_free_pre616>
      e4:      	add	x9, sp, #0x6c
      e8:      	str	w8, [sp, #0x6c]
      ec:      	mov	w8, #0x1                // =1
      f0:      	add	x1, sp, #0x6c
      f4:      	ldr	x0, [x0]
      f8:      	blr	x8
      fc:      	cbnz	x0, 0x264 <tracepoint__sched_process_free_pre616+0x264>
     100:      	ldr	w8, [x19]
     104:      	cbnz	w8, 0x324 <tracepoint__sched_process_free_pre616+0x324>
     108:      	ldp	x20, x19, [sp, #0x80]
     10c:      	mov	w0, wzr
     110:      	ldr	x30, [sp, #0x60]
     114:      	ldp	x22, x21, [sp, #0x70]
     118:      	add	sp, sp, #0x90
     11c:      	ret
     120:      	mov	w8, #0x3                // =3
     124:      	add	x9, sp, #0x14
     128:      	add	x1, sp, #0x14
     12c:      	mov	x0, x20
     130:      	blr	x8
     134:      	mov	w8, #0x1                // =1
     138:      	adrp	x0, 0x0 <tracepoint__sched_process_free_pre616>
     13c:      	mov	w9, #0x2                // =2
     140:      	str	w8, [sp, #0x68]
     144:      	strb	w8, [sp, #0x5c]
     148:      	add	x10, sp, #0x68
     14c:      	add	x11, sp, #0x5c
     150:      	add	x1, sp, #0x68
     154:      	ldr	x0, [x0]
     158:      	add	x2, sp, #0x5c
     15c:      	mov	w3, #0x1                // =1
     160:      	blr	x9
     164:      	tbnz	w0, #0x1f, 0x19c <tracepoint__sched_process_free_pre616+0x19c>
     168:      	mov	w8, #0x42               // =66
     16c:      	adrp	x0, 0x0 <tracepoint__sched_process_free_pre616>
     170:      	add	x9, sp, #0x6c
     174:      	str	w8, [sp, #0x6c]
     178:      	mov	w8, #0x1                // =1
     17c:      	add	x1, sp, #0x6c
     180:      	ldr	x0, [x0]
     184:      	blr	x8
     188:      	cbz	x0, 0x1e8 <tracepoint__sched_process_free_pre616+0x1e8>
     18c:      	ldr	x8, [x0]
     190:      	add	x8, x8, #0x1
     194:      	str	x8, [x0]
     198:      	b	0x1f8 <tracepoint__sched_process_free_pre616+0x1f8>
     19c:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     1a0:      	ldr	x8, [x8]
     1a4:      	ldr	w8, [x8]
     1a8:      	cbz	w8, 0x240 <tracepoint__sched_process_free_pre616+0x240>
     1ac:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     1b0:      	add	x8, x8, #0x0
     1b4:      	strb	wzr, [sp, #0x38]
     1b8:      	add	x0, sp, #0x20
     1bc:      	ldp	x9, x10, [x8]
     1c0:      	ldr	x8, [x8, #0x10]
     1c4:      	mov	w1, #0x19               // =25
     1c8:      	mov	w2, #0x1                // =1
     1cc:      	str	x8, [sp, #0x30]
     1d0:      	stp	x9, x10, [sp, #0x20]
     1d4:      	mov	w8, #0x19               // =25
     1d8:      	mov	w9, #0x6                // =6
     1dc:      	add	x10, sp, #0x20
     1e0:      	blr	x9
     1e4:      	b	0x240 <tracepoint__sched_process_free_pre616+0x240>
     1e8:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     1ec:      	ldr	x8, [x8]
     1f0:      	ldr	w8, [x8]
     1f4:      	cbnz	w8, 0x3cc <tracepoint__sched_process_free_pre616+0x3cc>
     1f8:      	mov	w8, #0x1                // =1
     1fc:      	adrp	x1, 0x0 <tracepoint__sched_process_free_pre616>
     200:      	mov	w9, #0x4                // =4
     204:      	str	w8, [sp, #0x6c]
     208:      	mov	w8, #-0x1               // =-1
     20c:      	mov	w10, #0x19              // =25
     210:      	add	x11, sp, #0x6c
     214:      	ldr	x1, [x1]
     218:      	add	x3, sp, #0x6c
     21c:      	mov	x0, x19
     220:      	mov	w2, #-0x1               // =-1
     224:      	mov	w4, #0x4                // =4
     228:      	blr	x10
     22c:      	tbz	w0, #0x1f, 0x240 <tracepoint__sched_process_free_pre616+0x240>
     230:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     234:      	ldr	x8, [x8]
     238:      	ldr	w8, [x8]
     23c:      	cbnz	w8, 0x380 <tracepoint__sched_process_free_pre616+0x380>
     240:      	mov	w8, #0x40               // =64
     244:      	adrp	x0, 0x0 <tracepoint__sched_process_free_pre616>
     248:      	add	x9, sp, #0x18
     24c:      	str	w8, [sp, #0x18]
     250:      	mov	w8, #0x1                // =1
     254:      	add	x1, sp, #0x18
     258:      	ldr	x0, [x0]
     25c:      	blr	x8
     260:      	cbz	x0, 0x288 <tracepoint__sched_process_free_pre616+0x288>
     264:      	ldr	x8, [x0]
     268:      	add	x8, x8, #0x1
     26c:      	str	x8, [x0]
     270:      	ldp	x20, x19, [sp, #0x80]
     274:      	mov	w0, wzr
     278:      	ldr	x30, [sp, #0x60]
     27c:      	ldp	x22, x21, [sp, #0x70]
     280:      	add	sp, sp, #0x90
     284:      	ret
     288:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     28c:      	ldr	x8, [x8]
     290:      	ldr	w8, [x8]
     294:      	cbz	w8, 0x108 <tracepoint__sched_process_free_pre616+0x108>
     298:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     29c:      	add	x8, x8, #0x0
     2a0:      	ldp	x9, x10, [x8, #0x10]
     2a4:      	stp	x9, x10, [sp, #0x30]
     2a8:      	ldr	x9, [x8, #0x20]
     2ac:      	add	x10, sp, #0x20
     2b0:      	str	x9, [sp, #0x40]
     2b4:      	ldur	x9, [x8, #0x26]
     2b8:      	stur	x9, [sp, #0x46]
     2bc:      	ldp	x9, x8, [x8]
     2c0:      	stp	x9, x8, [sp, #0x20]
     2c4:      	mov	w8, #0x2e               // =46
     2c8:      	mov	w9, #0x6                // =6
     2cc:      	ldr	w2, [sp, #0x18]
     2d0:      	b	0x35c <tracepoint__sched_process_free_pre616+0x35c>
     2d4:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     2d8:      	add	x8, x8, #0x0
     2dc:      	ldr	w3, [sp, #0x18]
     2e0:      	mov	w4, w0
     2e4:      	ldp	x9, x10, [x8, #0x20]
     2e8:      	add	x0, sp, #0x20
     2ec:      	mov	w1, #0x35               // =53
     2f0:      	mov	w2, w21
     2f4:      	stp	x9, x10, [sp, #0x40]
     2f8:      	ldur	x9, [x8, #0x2d]
     2fc:      	stur	x9, [sp, #0x4d]
     300:      	ldp	x9, x10, [x8]
     304:      	stp	x9, x10, [sp, #0x20]
     308:      	ldp	x8, x9, [x8, #0x10]
     30c:      	add	x10, sp, #0x20
     310:      	stp	x8, x9, [sp, #0x30]
     314:      	mov	w8, #0x35               // =53
     318:      	mov	w9, #0x6                // =6
     31c:      	blr	x9
     320:      	b	0xdc <tracepoint__sched_process_free_pre616+0xdc>
     324:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     328:      	add	x8, x8, #0x0
     32c:      	ldp	x9, x10, [x8, #0x10]
     330:      	stp	x9, x10, [sp, #0x30]
     334:      	ldr	x9, [x8, #0x20]
     338:      	add	x10, sp, #0x20
     33c:      	str	x9, [sp, #0x40]
     340:      	ldur	x9, [x8, #0x26]
     344:      	stur	x9, [sp, #0x46]
     348:      	ldp	x9, x8, [x8]
     34c:      	stp	x9, x8, [sp, #0x20]
     350:      	mov	w8, #0x2e               // =46
     354:      	mov	w9, #0x6                // =6
     358:      	ldr	w2, [sp, #0x6c]
     35c:      	add	x0, sp, #0x20
     360:      	mov	w1, #0x2e               // =46
     364:      	blr	x9
     368:      	ldp	x20, x19, [sp, #0x80]
     36c:      	mov	w0, wzr
     370:      	ldr	x30, [sp, #0x60]
     374:      	ldp	x22, x21, [sp, #0x70]
     378:      	add	sp, sp, #0x90
     37c:      	ret
     380:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     384:      	add	x8, x8, #0x0
     388:      	mov	w3, w0
     38c:      	ldp	x9, x10, [x8, #0x20]
     390:      	add	x0, sp, #0x20
     394:      	mov	w1, #0x36               // =54
     398:      	mov	w2, #0x1                // =1
     39c:      	stp	x9, x10, [sp, #0x40]
     3a0:      	ldur	x9, [x8, #0x2e]
     3a4:      	stur	x9, [sp, #0x4e]
     3a8:      	ldp	x9, x10, [x8]
     3ac:      	stp	x9, x10, [sp, #0x20]
     3b0:      	ldp	x8, x9, [x8, #0x10]
     3b4:      	add	x10, sp, #0x20
     3b8:      	stp	x8, x9, [sp, #0x30]
     3bc:      	mov	w8, #0x36               // =54
     3c0:      	mov	w9, #0x6                // =6
     3c4:      	blr	x9
     3c8:      	b	0x240 <tracepoint__sched_process_free_pre616+0x240>
     3cc:      	adrp	x8, 0x0 <tracepoint__sched_process_free_pre616>
     3d0:      	add	x8, x8, #0x0
     3d4:      	add	x0, sp, #0x20
     3d8:      	ldp	x9, x10, [x8, #0x10]
     3dc:      	mov	w1, #0x2e               // =46
     3e0:      	stp	x9, x10, [sp, #0x30]
     3e4:      	ldr	x9, [x8, #0x20]
     3e8:      	add	x10, sp, #0x20
     3ec:      	str	x9, [sp, #0x40]
     3f0:      	ldur	x9, [x8, #0x26]
     3f4:      	stur	x9, [sp, #0x46]
     3f8:      	ldp	x9, x8, [x8]
     3fc:      	stp	x9, x8, [sp, #0x20]
     400:      	mov	w8, #0x2e               // =46
     404:      	mov	w9, #0x6                // =6
     408:      	ldr	w2, [sp, #0x6c]
     40c:      	blr	x9
     410:      	b	0x1f8 <tracepoint__sched_process_free_pre616+0x1f8>
