
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_kprobe_v53.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section kprobe:

0000000000000000 <generic_kprobe_setup_event>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	x30, x25, [sp, #0x40]
       8:      	stp	x24, x23, [sp, #0x50]
       c:      	stp	x22, x21, [sp, #0x60]
      10:      	stp	x20, x19, [sp, #0x70]
      14:      	str	wzr, [sp, #0x4]
      18:      	adrp	x20, 0x0 <generic_kprobe_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x4
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x4
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x344 <generic_kprobe_setup_event+0x344>
      3c:      	adrp	x21, 0x0 <generic_kprobe_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x344 <generic_kprobe_setup_event+0x344>
      60:      	ldr	w8, [x0, #0x54]
      64:      	mov	x23, x0
      68:      	cbz	w8, 0x104 <generic_kprobe_setup_event+0x104>
      6c:      	cbz	x19, 0x344 <generic_kprobe_setup_event+0x344>
      70:      	add	x2, x19, #0x110
      74:      	mov	w25, #0x8               // =8
      78:      	add	x8, sp, #0x18
      7c:      	mov	w9, #0x4                // =4
      80:      	add	x0, sp, #0x18
      84:      	mov	w1, #0x8                // =8
      88:      	mov	w24, #0x4               // =4
      8c:      	blr	x9
      90:      	ldr	x8, [sp, #0x18]
      94:      	add	x2, x19, #0x8
      98:      	mov	w9, #0x4                // =4
      9c:      	add	x0, sp, #0x18
      a0:      	str	x8, [x22, #0x5e50]
      a4:      	add	x8, sp, #0x18
      a8:      	mov	w1, #0x8                // =8
      ac:      	blr	x9
      b0:      	ldr	x8, [sp, #0x18]
      b4:      	add	x2, x19, #0x10
      b8:      	mov	w9, #0x4                // =4
      bc:      	add	x0, sp, #0x18
      c0:      	str	x8, [x22, #0x5e58]
      c4:      	add	x8, sp, #0x18
      c8:      	mov	w1, #0x8                // =8
      cc:      	blr	x9
      d0:      	ldr	x8, [sp, #0x18]
      d4:      	add	x2, x19, #0x18
      d8:      	mov	w9, #0x4                // =4
      dc:      	add	x0, sp, #0x18
      e0:      	str	x8, [x22, #0x5e60]
      e4:      	add	x8, sp, #0x18
      e8:      	mov	w1, #0x8                // =8
      ec:      	blr	x9
      f0:      	ldr	x8, [sp, #0x18]
      f4:      	add	x2, x19, #0x20
      f8:      	str	x8, [x22, #0x5e68]
      fc:      	add	x8, sp, #0x18
     100:      	b	0x194 <generic_kprobe_setup_event+0x194>
     104:      	mov	w25, #0x8               // =8
     108:      	add	x8, sp, #0x18
     10c:      	mov	w9, #0x4                // =4
     110:      	add	x0, sp, #0x18
     114:      	mov	w1, #0x8                // =8
     118:      	mov	x2, x19
     11c:      	mov	w24, #0x4               // =4
     120:      	blr	x9
     124:      	ldr	x8, [sp, #0x18]
     128:      	add	x2, x19, #0x8
     12c:      	mov	w9, #0x4                // =4
     130:      	add	x0, sp, #0x18
     134:      	str	x8, [x22, #0x5e50]
     138:      	add	x8, sp, #0x18
     13c:      	mov	w1, #0x8                // =8
     140:      	blr	x9
     144:      	ldr	x8, [sp, #0x18]
     148:      	add	x2, x19, #0x10
     14c:      	mov	w9, #0x4                // =4
     150:      	add	x0, sp, #0x18
     154:      	str	x8, [x22, #0x5e58]
     158:      	add	x8, sp, #0x18
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x9
     164:      	ldr	x8, [sp, #0x18]
     168:      	add	x2, x19, #0x18
     16c:      	mov	w9, #0x4                // =4
     170:      	add	x0, sp, #0x18
     174:      	str	x8, [x22, #0x5e60]
     178:      	add	x8, sp, #0x18
     17c:      	mov	w1, #0x8                // =8
     180:      	blr	x9
     184:      	ldr	x8, [sp, #0x18]
     188:      	add	x2, x19, #0x20
     18c:      	str	x8, [x22, #0x5e68]
     190:      	add	x8, sp, #0x18
     194:      	add	x0, sp, #0x18
     198:      	mov	w1, #0x8                // =8
     19c:      	blr	x24
     1a0:      	ldr	x8, [sp, #0x18]
     1a4:      	strh	wzr, [x22, #0x2]
     1a8:      	str	wzr, [x22, #0x4]
     1ac:      	str	x8, [x22, #0x5e70]
     1b0:      	mov	w8, #0xd                // =13
     1b4:      	strb	w8, [x22]
     1b8:      	mov	w8, #0x7d               // =125
     1bc:      	blr	x8
     1c0:      	str	x0, [x22, #0x8]
     1c4:      	str	xzr, [x22, #0x70]
     1c8:      	mov	w8, #0xe                // =14
     1cc:      	mov	w24, #0xe               // =14
     1d0:      	str	wzr, [x22, #0x14]
     1d4:      	blr	x8
     1d8:      	str	w0, [x22, #0x7c]
     1dc:      	blr	x24
     1e0:      	cmn	x0, #0x16
     1e4:      	b.ne	0x208 <generic_kprobe_setup_event+0x208>
     1e8:      	add	x2, x19, #0xe8
     1ec:      	mov	w8, #0x8                // =8
     1f0:      	mov	w9, #0x4                // =4
     1f4:      	add	x10, sp, #0x18
     1f8:      	add	x0, sp, #0x18
     1fc:      	mov	w1, #0x8                // =8
     200:      	blr	x9
     204:      	ldr	x0, [sp, #0x18]
     208:      	str	x0, [x22, #0x68]
     20c:      	ldr	w8, [x23, #0x5c]
     210:      	cmp	w8, #0x1
     214:      	b.lt	0x2cc <generic_kprobe_setup_event+0x2cc>
     218:      	ldr	x8, [x22, #0x60]
     21c:      	ldr	x9, [x22, #0x8]
     220:      	mov	w10, #0x1               // =1
     224:      	mov	x3, xzr
     228:      	add	x1, sp, #0x8
     22c:      	add	x2, sp, #0x18
     230:      	str	xzr, [sp, #0x28]
     234:      	stp	x9, x10, [sp, #0x18]
     238:      	stp	x8, x0, [sp, #0x8]
     23c:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     240:      	mov	w8, #0x2                // =2
     244:      	add	x9, sp, #0x8
     248:      	add	x10, sp, #0x18
     24c:      	ldr	x0, [x0]
     250:      	blr	x8
     254:      	cbz	x0, 0x2cc <generic_kprobe_setup_event+0x2cc>
     258:      	neg	w8, w0
     25c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     260:      	mov	w9, #0x1                // =1
     264:      	strh	w8, [sp, #0x34]
     268:      	mov	w8, #0x5                // =5
     26c:      	add	x1, sp, #0x34
     270:      	mov	w23, #0x1               // =1
     274:      	strh	w8, [sp, #0x36]
     278:      	mov	x8, #0x46               // =70
     27c:      	movk	x8, #0x2, lsl #32
     280:      	stur	x8, [sp, #0x38]
     284:      	add	x8, sp, #0x34
     288:      	ldr	x22, [x22]
     28c:      	mov	x0, x22
     290:      	blr	x9
     294:      	cbz	x0, 0x2a8 <generic_kprobe_setup_event+0x2a8>
     298:      	ldr	w8, [x0]
     29c:      	add	w8, w8, #0x1
     2a0:      	str	w8, [x0]
     2a4:      	b	0x2cc <generic_kprobe_setup_event+0x2cc>
     2a8:      	str	w23, [sp, #0x30]
     2ac:      	mov	x3, xzr
     2b0:      	mov	w8, #0x2                // =2
     2b4:      	add	x9, sp, #0x34
     2b8:      	add	x10, sp, #0x30
     2bc:      	add	x1, sp, #0x34
     2c0:      	add	x2, sp, #0x30
     2c4:      	mov	x0, x22
     2c8:      	blr	x8
     2cc:      	str	wzr, [sp, #0x18]
     2d0:      	mov	w8, #0x1                // =1
     2d4:      	add	x9, sp, #0x18
     2d8:      	add	x1, sp, #0x18
     2dc:      	mov	x0, x20
     2e0:      	blr	x8
     2e4:      	adrp	x20, 0x0 <generic_kprobe_setup_event>
     2e8:      	ldr	x20, [x20]
     2ec:      	cbz	x0, 0x314 <generic_kprobe_setup_event+0x314>
     2f0:      	mov	w8, #0x5ef8             // =24312
     2f4:      	add	x1, x0, x8
     2f8:      	mov	w8, #0x1                // =1
     2fc:      	mov	x0, x21
     300:      	blr	x8
     304:      	cbz	x0, 0x314 <generic_kprobe_setup_event+0x314>
     308:      	ldr	w8, [x0, #0x40]
     30c:      	cmn	w8, #0x1
     310:      	b.ne	0x32c <generic_kprobe_setup_event+0x32c>
     314:      	mov	w8, #0x3                // =3
     318:      	mov	w9, #0xc                // =12
     31c:      	mov	x0, x19
     320:      	mov	x1, x20
     324:      	mov	w2, #0x3                // =3
     328:      	blr	x9
     32c:      	mov	w8, #0x1                // =1
     330:      	mov	w9, #0xc                // =12
     334:      	mov	x0, x19
     338:      	mov	x1, x20
     33c:      	mov	w2, #0x1                // =1
     340:      	blr	x9
     344:      	ldp	x20, x19, [sp, #0x70]
     348:      	mov	w0, wzr
     34c:      	ldp	x22, x21, [sp, #0x60]
     350:      	ldp	x24, x23, [sp, #0x50]
     354:      	ldp	x30, x25, [sp, #0x40]
     358:      	add	sp, sp, #0x80
     35c:      	ret

0000000000000360 <generic_kprobe_process_event>:
     360:      	sub	sp, sp, #0x160
     364:      	str	x29, [sp, #0x110]
     368:      	stp	x30, x25, [sp, #0x120]
     36c:      	stp	x24, x23, [sp, #0x130]
     370:      	stp	x22, x21, [sp, #0x140]
     374:      	stp	x20, x19, [sp, #0x150]
     378:      	str	wzr, [sp, #0x6c]
     37c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     380:      	mov	w8, #0x1                // =1
     384:      	add	x9, sp, #0x6c
     388:      	ldr	x22, [x22]
     38c:      	mov	x19, x0
     390:      	add	x1, sp, #0x6c
     394:      	mov	x0, x22
     398:      	blr	x8
     39c:      	cbz	x0, 0x18c8 <generic_kprobe_process_event+0x1568>
     3a0:      	ldr	w21, [x0, #0x4]
     3a4:      	mov	w25, #0x5efc            // =24316
     3a8:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     3ac:      	mov	x20, x0
     3b0:      	ldr	w29, [x0, x25]
     3b4:      	ldr	x24, [x24]
     3b8:      	lsr	w8, w21, #3
     3bc:      	cmp	w8, #0x464
     3c0:      	b.hi	0x1834 <generic_kprobe_process_event+0x14d4>
     3c4:      	str	wzr, [sp, #0x78]
     3c8:      	mov	w8, #0x1                // =1
     3cc:      	add	x9, sp, #0x78
     3d0:      	add	x1, sp, #0x78
     3d4:      	mov	x0, x22
     3d8:      	blr	x8
     3dc:      	cbz	x0, 0x1834 <generic_kprobe_process_event+0x14d4>
     3e0:      	mov	w8, #0x5ef8             // =24312
     3e4:      	mov	x23, x0
     3e8:      	add	x1, x0, x8
     3ec:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     3f0:      	mov	w8, #0x1                // =1
     3f4:      	ldr	x0, [x0]
     3f8:      	blr	x8
     3fc:      	cmp	w29, #0x4
     400:      	ccmp	x0, #0x0, #0x4, le
     404:      	b.eq	0x1834 <generic_kprobe_process_event+0x14d4>
     408:      	and	x13, x29, #0x7
     40c:      	str	x21, [sp, #0x118]
     410:      	mov	w9, #0x5ea0             // =24224
     414:      	add	x8, x0, x13, lsl #2
     418:      	str	x13, [sp, #0x50]
     41c:      	ldrsw	x12, [x8, #0x18]
     420:      	ldr	w11, [x8, #0x4]
     424:      	add	x8, x23, x13, lsl #2
     428:      	str	wzr, [x8, x9]
     42c:      	and	x21, x12, #0xffffffff
     430:      	stp	x11, x29, [sp, #0x58]
     434:      	tbnz	w12, #0x8, 0x45c <generic_kprobe_process_event+0xfc>
     438:      	str	x8, [sp, #0x48]
     43c:      	tbnz	w12, #0x7, 0x464 <generic_kprobe_process_event+0x104>
     440:      	tbnz	w21, #0x6, 0x4d8 <generic_kprobe_process_event+0x178>
     444:      	add	x8, x0, x13, lsl #2
     448:      	ldr	w8, [x8, #0x40]
     44c:      	and	x8, x8, #0x7
     450:      	add	x8, x23, x8, lsl #3
     454:      	ldr	x8, [x8, #0x5e50]
     458:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     45c:      	str	xzr, [sp, #0x70]
     460:      	b	0xb84 <generic_kprobe_process_event+0x824>
     464:      	add	x8, x0, x13, lsl #2
     468:      	mov	w10, #0x40              // =64
     46c:      	ldrb	w9, [x8, #0x2c2]
     470:      	sub	w23, w10, w9, lsl #3
     474:      	ldr	w10, [x0, #0x54]
     478:      	ldrh	w9, [x8, #0x2c0]
     47c:      	cbz	w10, 0x504 <generic_kprobe_process_event+0x1a4>
     480:      	cbz	x19, 0x54c <generic_kprobe_process_event+0x1ec>
     484:      	add	x2, x19, x9
     488:      	mov	w8, #0x8                // =8
     48c:      	mov	w9, #0x4                // =4
     490:      	add	x10, sp, #0xa8
     494:      	mov	x24, x0
     498:      	add	x0, sp, #0xa8
     49c:      	mov	w1, #0x8                // =8
     4a0:      	mov	x25, x22
     4a4:      	mov	x22, x12
     4a8:      	blr	x9
     4ac:      	mov	x0, x24
     4b0:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     4b4:      	ldp	x13, x11, [sp, #0x50]
     4b8:      	mov	x12, x22
     4bc:      	mov	x22, x25
     4c0:      	ldr	x24, [x24]
     4c4:      	ldr	x8, [sp, #0xa8]
     4c8:      	mov	w25, #0x5efc            // =24316
     4cc:      	lsl	x8, x8, x23
     4d0:      	asr	x8, x8, x23
     4d4:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     4d8:      	mov	w8, #0x23               // =35
     4dc:      	mov	x23, x0
     4e0:      	mov	x22, x12
     4e4:      	blr	x8
     4e8:      	mov	x12, x22
     4ec:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     4f0:      	ldp	x13, x11, [sp, #0x50]
     4f4:      	mov	x8, x0
     4f8:      	mov	x0, x23
     4fc:      	ldr	x22, [x22]
     500:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     504:      	ror	w9, w9, #0x3
     508:      	mov	x8, xzr
     50c:      	cmp	w9, #0xf
     510:      	b.le	0x554 <generic_kprobe_process_event+0x1f4>
     514:      	cmp	w9, #0x17
     518:      	b.le	0x5a8 <generic_kprobe_process_event+0x248>
     51c:      	cmp	w9, #0x1b
     520:      	b.le	0x5d0 <generic_kprobe_process_event+0x270>
     524:      	cmp	w9, #0x1d
     528:      	b.le	0x668 <generic_kprobe_process_event+0x308>
     52c:      	cmp	w9, #0x1e
     530:      	b.eq	0x790 <generic_kprobe_process_event+0x430>
     534:      	cmp	w9, #0x20
     538:      	b.eq	0x728 <generic_kprobe_process_event+0x3c8>
     53c:      	cmp	w9, #0x1f
     540:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     544:      	ldr	x8, [x19, #0xf8]
     548:      	b	0x794 <generic_kprobe_process_event+0x434>
     54c:      	mov	x8, xzr
     550:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     554:      	cmp	w9, #0x7
     558:      	b.gt	0x580 <generic_kprobe_process_event+0x220>
     55c:      	cmp	w9, #0x3
     560:      	b.gt	0x5f0 <generic_kprobe_process_event+0x290>
     564:      	cmp	w9, #0x1
     568:      	b.gt	0x680 <generic_kprobe_process_event+0x320>
     56c:      	cbz	w9, 0x730 <generic_kprobe_process_event+0x3d0>
     570:      	cmp	w9, #0x1
     574:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     578:      	ldr	x8, [x19, #0x8]
     57c:      	b	0x794 <generic_kprobe_process_event+0x434>
     580:      	cmp	w9, #0xb
     584:      	b.gt	0x610 <generic_kprobe_process_event+0x2b0>
     588:      	cmp	w9, #0x9
     58c:      	b.gt	0x698 <generic_kprobe_process_event+0x338>
     590:      	cmp	w9, #0x8
     594:      	b.eq	0x738 <generic_kprobe_process_event+0x3d8>
     598:      	cmp	w9, #0x9
     59c:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     5a0:      	ldr	x8, [x19, #0x48]
     5a4:      	b	0x794 <generic_kprobe_process_event+0x434>
     5a8:      	cmp	w9, #0x13
     5ac:      	b.gt	0x630 <generic_kprobe_process_event+0x2d0>
     5b0:      	cmp	w9, #0x11
     5b4:      	b.gt	0x6e0 <generic_kprobe_process_event+0x380>
     5b8:      	cmp	w9, #0x10
     5bc:      	b.eq	0x770 <generic_kprobe_process_event+0x410>
     5c0:      	cmp	w9, #0x11
     5c4:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     5c8:      	ldr	x8, [x19, #0x88]
     5cc:      	b	0x794 <generic_kprobe_process_event+0x434>
     5d0:      	cmp	w9, #0x19
     5d4:      	b.gt	0x650 <generic_kprobe_process_event+0x2f0>
     5d8:      	cmp	w9, #0x18
     5dc:      	b.eq	0x710 <generic_kprobe_process_event+0x3b0>
     5e0:      	cmp	w9, #0x19
     5e4:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     5e8:      	ldr	x8, [x19, #0xc8]
     5ec:      	b	0x794 <generic_kprobe_process_event+0x434>
     5f0:      	cmp	w9, #0x5
     5f4:      	b.gt	0x6b0 <generic_kprobe_process_event+0x350>
     5f8:      	cmp	w9, #0x4
     5fc:      	b.eq	0x740 <generic_kprobe_process_event+0x3e0>
     600:      	cmp	w9, #0x5
     604:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     608:      	ldr	x8, [x19, #0x28]
     60c:      	b	0x794 <generic_kprobe_process_event+0x434>
     610:      	cmp	w9, #0xd
     614:      	b.gt	0x6c8 <generic_kprobe_process_event+0x368>
     618:      	cmp	w9, #0xc
     61c:      	b.eq	0x748 <generic_kprobe_process_event+0x3e8>
     620:      	cmp	w9, #0xd
     624:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     628:      	ldr	x8, [x19, #0x68]
     62c:      	b	0x794 <generic_kprobe_process_event+0x434>
     630:      	cmp	w9, #0x15
     634:      	b.gt	0x6f8 <generic_kprobe_process_event+0x398>
     638:      	cmp	w9, #0x14
     63c:      	b.eq	0x778 <generic_kprobe_process_event+0x418>
     640:      	cmp	w9, #0x15
     644:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     648:      	ldr	x8, [x19, #0xa8]
     64c:      	b	0x794 <generic_kprobe_process_event+0x434>
     650:      	cmp	w9, #0x1a
     654:      	b.eq	0x718 <generic_kprobe_process_event+0x3b8>
     658:      	cmp	w9, #0x1b
     65c:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     660:      	ldr	x8, [x19, #0xd8]
     664:      	b	0x794 <generic_kprobe_process_event+0x434>
     668:      	cmp	w9, #0x1c
     66c:      	b.eq	0x720 <generic_kprobe_process_event+0x3c0>
     670:      	cmp	w9, #0x1d
     674:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     678:      	ldr	x8, [x19, #0xe8]
     67c:      	b	0x794 <generic_kprobe_process_event+0x434>
     680:      	cmp	w9, #0x2
     684:      	b.eq	0x750 <generic_kprobe_process_event+0x3f0>
     688:      	cmp	w9, #0x3
     68c:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     690:      	ldr	x8, [x19, #0x18]
     694:      	b	0x794 <generic_kprobe_process_event+0x434>
     698:      	cmp	w9, #0xa
     69c:      	b.eq	0x758 <generic_kprobe_process_event+0x3f8>
     6a0:      	cmp	w9, #0xb
     6a4:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     6a8:      	ldr	x8, [x19, #0x58]
     6ac:      	b	0x794 <generic_kprobe_process_event+0x434>
     6b0:      	cmp	w9, #0x6
     6b4:      	b.eq	0x760 <generic_kprobe_process_event+0x400>
     6b8:      	cmp	w9, #0x7
     6bc:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     6c0:      	ldr	x8, [x19, #0x38]
     6c4:      	b	0x794 <generic_kprobe_process_event+0x434>
     6c8:      	cmp	w9, #0xe
     6cc:      	b.eq	0x768 <generic_kprobe_process_event+0x408>
     6d0:      	cmp	w9, #0xf
     6d4:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     6d8:      	ldr	x8, [x19, #0x78]
     6dc:      	b	0x794 <generic_kprobe_process_event+0x434>
     6e0:      	cmp	w9, #0x12
     6e4:      	b.eq	0x780 <generic_kprobe_process_event+0x420>
     6e8:      	cmp	w9, #0x13
     6ec:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     6f0:      	ldr	x8, [x19, #0x98]
     6f4:      	b	0x794 <generic_kprobe_process_event+0x434>
     6f8:      	cmp	w9, #0x16
     6fc:      	b.eq	0x788 <generic_kprobe_process_event+0x428>
     700:      	cmp	w9, #0x17
     704:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     708:      	ldr	x8, [x19, #0xb8]
     70c:      	b	0x794 <generic_kprobe_process_event+0x434>
     710:      	ldr	x8, [x19, #0xc0]
     714:      	b	0x794 <generic_kprobe_process_event+0x434>
     718:      	ldr	x8, [x19, #0xd0]
     71c:      	b	0x794 <generic_kprobe_process_event+0x434>
     720:      	ldr	x8, [x19, #0xe0]
     724:      	b	0x794 <generic_kprobe_process_event+0x434>
     728:      	ldr	x8, [x19, #0x100]
     72c:      	b	0x794 <generic_kprobe_process_event+0x434>
     730:      	ldr	x8, [x19]
     734:      	b	0x794 <generic_kprobe_process_event+0x434>
     738:      	ldr	x8, [x19, #0x40]
     73c:      	b	0x794 <generic_kprobe_process_event+0x434>
     740:      	ldr	x8, [x19, #0x20]
     744:      	b	0x794 <generic_kprobe_process_event+0x434>
     748:      	ldr	x8, [x19, #0x60]
     74c:      	b	0x794 <generic_kprobe_process_event+0x434>
     750:      	ldr	x8, [x19, #0x10]
     754:      	b	0x794 <generic_kprobe_process_event+0x434>
     758:      	ldr	x8, [x19, #0x50]
     75c:      	b	0x794 <generic_kprobe_process_event+0x434>
     760:      	ldr	x8, [x19, #0x30]
     764:      	b	0x794 <generic_kprobe_process_event+0x434>
     768:      	ldr	x8, [x19, #0x70]
     76c:      	b	0x794 <generic_kprobe_process_event+0x434>
     770:      	ldr	x8, [x19, #0x80]
     774:      	b	0x794 <generic_kprobe_process_event+0x434>
     778:      	ldr	x8, [x19, #0xa0]
     77c:      	b	0x794 <generic_kprobe_process_event+0x434>
     780:      	ldr	x8, [x19, #0x90]
     784:      	b	0x794 <generic_kprobe_process_event+0x434>
     788:      	ldr	x8, [x19, #0xb0]
     78c:      	b	0x794 <generic_kprobe_process_event+0x434>
     790:      	ldr	x8, [x19, #0xf0]
     794:      	mov	x9, #-0x1               // =-1
     798:      	lsr	x9, x9, x23
     79c:      	and	x8, x8, x9
     7a0:      	cmp	w13, #0x4
     7a4:      	str	x8, [sp, #0x70]
     7a8:      	b.hi	0xb84 <generic_kprobe_process_event+0x824>
     7ac:      	mov	w9, #0x50               // =80
     7b0:      	umaddl	x10, w13, w9, x0
     7b4:      	ldrh	w9, [x10, #0x76]
     7b8:      	cbz	w9, 0xb84 <generic_kprobe_process_event+0x824>
     7bc:      	ldur	w9, [x10, #0x70]
     7c0:      	str	x10, [sp, #0x40]
     7c4:      	add	x8, x8, x9
     7c8:      	str	x8, [sp, #0x70]
     7cc:      	ldurh	w9, [x10, #0x74]
     7d0:      	cbz	w9, 0x81c <generic_kprobe_process_event+0x4bc>
     7d4:      	mov	w9, #0x8                // =8
     7d8:      	mov	w10, #0x4               // =4
     7dc:      	add	x11, sp, #0x70
     7e0:      	ldr	x2, [sp, #0x70]
     7e4:      	add	x0, sp, #0x70
     7e8:      	mov	w1, #0x8                // =8
     7ec:      	mov	x23, x21
     7f0:      	mov	x21, x19
     7f4:      	mov	x19, x22
     7f8:      	mov	x22, x12
     7fc:      	blr	x10
     800:      	ldr	x10, [sp, #0x40]
     804:      	ldr	x11, [sp, #0x58]
     808:      	mov	x12, x22
     80c:      	mov	x22, x19
     810:      	mov	x19, x21
     814:      	mov	x21, x23
     818:      	tbnz	w0, #0x1f, 0xb60 <generic_kprobe_process_event+0x800>
     81c:      	ldurh	w8, [x10, #0x7e]
     820:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     824:      	ldr	x8, [sp, #0x70]
     828:      	ldur	w9, [x10, #0x78]
     82c:      	add	x8, x8, x9
     830:      	str	x8, [sp, #0x70]
     834:      	ldurh	w9, [x10, #0x7c]
     838:      	cbz	w9, 0x884 <generic_kprobe_process_event+0x524>
     83c:      	mov	w9, #0x8                // =8
     840:      	mov	w10, #0x4               // =4
     844:      	add	x11, sp, #0x70
     848:      	ldr	x2, [sp, #0x70]
     84c:      	add	x0, sp, #0x70
     850:      	mov	w1, #0x8                // =8
     854:      	mov	x23, x21
     858:      	mov	x21, x19
     85c:      	mov	x19, x22
     860:      	mov	x22, x12
     864:      	blr	x10
     868:      	ldr	x10, [sp, #0x40]
     86c:      	ldr	x11, [sp, #0x58]
     870:      	mov	x12, x22
     874:      	mov	x22, x19
     878:      	mov	x19, x21
     87c:      	mov	x21, x23
     880:      	tbnz	w0, #0x1f, 0xb68 <generic_kprobe_process_event+0x808>
     884:      	ldurh	w8, [x10, #0x86]
     888:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     88c:      	ldr	x8, [sp, #0x70]
     890:      	ldur	w9, [x10, #0x80]
     894:      	add	x8, x8, x9
     898:      	str	x8, [sp, #0x70]
     89c:      	ldurh	w9, [x10, #0x84]
     8a0:      	cbz	w9, 0x8ec <generic_kprobe_process_event+0x58c>
     8a4:      	mov	w9, #0x8                // =8
     8a8:      	mov	w10, #0x4               // =4
     8ac:      	add	x11, sp, #0x70
     8b0:      	ldr	x2, [sp, #0x70]
     8b4:      	add	x0, sp, #0x70
     8b8:      	mov	w1, #0x8                // =8
     8bc:      	mov	x23, x21
     8c0:      	mov	x21, x19
     8c4:      	mov	x19, x22
     8c8:      	mov	x22, x12
     8cc:      	blr	x10
     8d0:      	ldr	x10, [sp, #0x40]
     8d4:      	ldr	x11, [sp, #0x58]
     8d8:      	mov	x12, x22
     8dc:      	mov	x22, x19
     8e0:      	mov	x19, x21
     8e4:      	mov	x21, x23
     8e8:      	tbnz	w0, #0x1f, 0xb70 <generic_kprobe_process_event+0x810>
     8ec:      	ldurh	w8, [x10, #0x8e]
     8f0:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     8f4:      	ldr	x8, [sp, #0x70]
     8f8:      	ldur	w9, [x10, #0x88]
     8fc:      	add	x8, x8, x9
     900:      	str	x8, [sp, #0x70]
     904:      	ldurh	w9, [x10, #0x8c]
     908:      	cbz	w9, 0x958 <generic_kprobe_process_event+0x5f8>
     90c:      	mov	w9, #0x8                // =8
     910:      	add	x10, sp, #0x70
     914:      	mov	w11, #0x4               // =4
     918:      	ldr	x2, [sp, #0x70]
     91c:      	add	x0, sp, #0x70
     920:      	mov	w1, #0x8                // =8
     924:      	mov	w29, #0x4               // =4
     928:      	mov	x23, x21
     92c:      	mov	x21, x19
     930:      	mov	x19, x22
     934:      	mov	x22, x12
     938:      	blr	x11
     93c:      	ldr	x10, [sp, #0x40]
     940:      	ldr	x11, [sp, #0x58]
     944:      	mov	x12, x22
     948:      	mov	x22, x19
     94c:      	mov	x19, x21
     950:      	mov	x21, x23
     954:      	tbnz	w0, #0x1f, 0xb74 <generic_kprobe_process_event+0x814>
     958:      	ldurh	w8, [x10, #0x96]
     95c:      	ldr	x29, [sp, #0x60]
     960:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     964:      	ldr	x8, [sp, #0x70]
     968:      	ldur	w9, [x10, #0x90]
     96c:      	add	x8, x8, x9
     970:      	str	x8, [sp, #0x70]
     974:      	ldurh	w9, [x10, #0x94]
     978:      	cbz	w9, 0x9c4 <generic_kprobe_process_event+0x664>
     97c:      	mov	w9, #0x8                // =8
     980:      	mov	w10, #0x4               // =4
     984:      	add	x11, sp, #0x70
     988:      	ldr	x2, [sp, #0x70]
     98c:      	add	x0, sp, #0x70
     990:      	mov	w1, #0x8                // =8
     994:      	mov	x23, x21
     998:      	mov	x21, x19
     99c:      	mov	x19, x22
     9a0:      	mov	x22, x12
     9a4:      	blr	x10
     9a8:      	ldr	x10, [sp, #0x40]
     9ac:      	ldr	x11, [sp, #0x58]
     9b0:      	mov	x12, x22
     9b4:      	mov	x22, x19
     9b8:      	mov	x19, x21
     9bc:      	mov	x21, x23
     9c0:      	tbnz	w0, #0x1f, 0x18e8 <generic_kprobe_process_event+0x1588>
     9c4:      	ldurh	w8, [x10, #0x9e]
     9c8:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     9cc:      	ldr	x8, [sp, #0x70]
     9d0:      	ldur	w9, [x10, #0x98]
     9d4:      	add	x8, x8, x9
     9d8:      	str	x8, [sp, #0x70]
     9dc:      	ldurh	w9, [x10, #0x9c]
     9e0:      	cbz	w9, 0xa28 <generic_kprobe_process_event+0x6c8>
     9e4:      	mov	w9, #0x8                // =8
     9e8:      	mov	w10, #0x4               // =4
     9ec:      	add	x11, sp, #0x70
     9f0:      	ldr	x2, [sp, #0x70]
     9f4:      	add	x0, sp, #0x70
     9f8:      	mov	w1, #0x8                // =8
     9fc:      	mov	x23, x21
     a00:      	mov	x21, x19
     a04:      	mov	x19, x22
     a08:      	mov	x22, x12
     a0c:      	blr	x10
     a10:      	ldr	x11, [sp, #0x58]
     a14:      	mov	x12, x22
     a18:      	mov	x22, x19
     a1c:      	mov	x19, x21
     a20:      	mov	x21, x23
     a24:      	tbnz	w0, #0x1f, 0x1a18 <generic_kprobe_process_event+0x16b8>
     a28:      	ldr	x23, [sp, #0x40]
     a2c:      	ldurh	w8, [x23, #0xa6]
     a30:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     a34:      	ldr	x8, [sp, #0x70]
     a38:      	ldur	w9, [x23, #0xa0]
     a3c:      	add	x8, x8, x9
     a40:      	str	x12, [sp, #0x38]
     a44:      	str	x8, [sp, #0x70]
     a48:      	ldurh	w9, [x23, #0xa4]
     a4c:      	cbz	w9, 0xa70 <generic_kprobe_process_event+0x710>
     a50:      	mov	w9, #0x8                // =8
     a54:      	mov	w10, #0x4               // =4
     a58:      	add	x11, sp, #0x70
     a5c:      	ldr	x2, [sp, #0x70]
     a60:      	add	x0, sp, #0x70
     a64:      	mov	w1, #0x8                // =8
     a68:      	blr	x10
     a6c:      	tbnz	w0, #0x1f, 0x1c1c <generic_kprobe_process_event+0x18bc>
     a70:      	ldurh	w8, [x23, #0xae]
     a74:      	ldr	x11, [sp, #0x58]
     a78:      	ldr	x12, [sp, #0x38]
     a7c:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     a80:      	ldr	x8, [sp, #0x70]
     a84:      	ldur	w9, [x23, #0xa8]
     a88:      	add	x8, x8, x9
     a8c:      	str	x8, [sp, #0x70]
     a90:      	ldurh	w9, [x23, #0xac]
     a94:      	cbz	w9, 0xac0 <generic_kprobe_process_event+0x760>
     a98:      	mov	w29, #0x8               // =8
     a9c:      	mov	w9, #0x4                // =4
     aa0:      	add	x10, sp, #0x70
     aa4:      	ldr	x2, [sp, #0x70]
     aa8:      	add	x0, sp, #0x70
     aac:      	mov	w1, #0x8                // =8
     ab0:      	blr	x9
     ab4:      	ldr	x12, [sp, #0x38]
     ab8:      	ldr	x11, [sp, #0x58]
     abc:      	tbnz	w0, #0x1f, 0xb74 <generic_kprobe_process_event+0x814>
     ac0:      	ldurh	w8, [x23, #0xb6]
     ac4:      	ldr	x29, [sp, #0x60]
     ac8:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     acc:      	ldr	x8, [sp, #0x70]
     ad0:      	ldur	w9, [x23, #0xb0]
     ad4:      	add	x8, x8, x9
     ad8:      	str	x8, [sp, #0x70]
     adc:      	ldurh	w9, [x23, #0xb4]
     ae0:      	cbz	w9, 0xb04 <generic_kprobe_process_event+0x7a4>
     ae4:      	mov	w9, #0x8                // =8
     ae8:      	mov	w10, #0x4               // =4
     aec:      	add	x11, sp, #0x70
     af0:      	ldr	x2, [sp, #0x70]
     af4:      	add	x0, sp, #0x70
     af8:      	mov	w1, #0x8                // =8
     afc:      	blr	x10
     b00:      	tbnz	w0, #0x1f, 0x2810 <generic_kprobe_process_event+0x24b0>
     b04:      	ldp	x12, x10, [sp, #0x38]
     b08:      	mov	w25, #0x5efc            // =24316
     b0c:      	ldurh	w8, [x10, #0xbe]
     b10:      	ldp	x11, x29, [sp, #0x58]
     b14:      	cbz	w8, 0xb84 <generic_kprobe_process_event+0x824>
     b18:      	ldr	x8, [sp, #0x70]
     b1c:      	ldur	w9, [x10, #0xb8]
     b20:      	add	x8, x8, x9
     b24:      	str	x8, [sp, #0x70]
     b28:      	ldurh	w9, [x10, #0xbc]
     b2c:      	cbz	w9, 0xb84 <generic_kprobe_process_event+0x824>
     b30:      	mov	w9, #0x8                // =8
     b34:      	mov	w10, #0x4               // =4
     b38:      	add	x11, sp, #0x70
     b3c:      	ldr	x2, [sp, #0x70]
     b40:      	add	x0, sp, #0x70
     b44:      	mov	w1, #0x8                // =8
     b48:      	blr	x10
     b4c:      	ldr	x12, [sp, #0x38]
     b50:      	ldr	x11, [sp, #0x58]
     b54:      	tbz	w0, #0x1f, 0xb84 <generic_kprobe_process_event+0x824>
     b58:      	mov	w29, #0xa               // =10
     b5c:      	b	0xb74 <generic_kprobe_process_event+0x814>
     b60:      	mov	w29, #0x1               // =1
     b64:      	b	0xb74 <generic_kprobe_process_event+0x814>
     b68:      	mov	w29, #0x2               // =2
     b6c:      	b	0xb74 <generic_kprobe_process_event+0x814>
     b70:      	mov	w29, #0x3               // =3
     b74:      	ldr	x8, [sp, #0x48]
     b78:      	mov	w9, #0x5ea0             // =24224
     b7c:      	str	w29, [x8, x9]
     b80:      	ldr	x29, [sp, #0x60]
     b84:      	mov	x9, #0x8000             // =32768
     b88:      	mov	w8, #0x1                // =1
     b8c:      	cmp	w11, #0x2a
     b90:      	movk	x9, #0x101, lsl #16
     b94:      	lsl	x8, x8, x11
     b98:      	movk	x9, #0x420, lsl #32
     b9c:      	and	x8, x8, x9
     ba0:      	ccmp	x8, #0x0, #0x4, ls
     ba4:      	b.eq	0xc94 <generic_kprobe_process_event+0x934>
     ba8:      	str	wzr, [sp, #0xf8]
     bac:      	ldr	x29, [sp, #0x70]
     bb0:      	mov	w8, #0x1                // =1
     bb4:      	add	x9, sp, #0xf8
     bb8:      	add	x1, sp, #0xf8
     bbc:      	mov	x0, x22
     bc0:      	blr	x8
     bc4:      	cbz	x0, 0xc38 <generic_kprobe_process_event+0x8d8>
     bc8:      	mov	w8, #0x6420             // =25632
     bcc:      	mov	x25, x24
     bd0:      	mov	x23, x0
     bd4:      	add	x24, x0, x8
     bd8:      	ldr	w8, [x24]
     bdc:      	cbz	w8, 0xc44 <generic_kprobe_process_event+0x8e4>
     be0:      	str	wzr, [x24]
     be4:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     be8:      	mov	w8, #0x1                // =1
     bec:      	add	x9, sp, #0xf8
     bf0:      	ldr	x0, [x0]
     bf4:      	add	x1, sp, #0xf8
     bf8:      	blr	x8
     bfc:      	cbz	x0, 0xce0 <generic_kprobe_process_event+0x980>
     c00:      	ldr	x11, [sp, #0x50]
     c04:      	mov	w9, #0x5ea0             // =24224
     c08:      	ldr	x29, [sp, #0x60]
     c0c:      	add	x8, x23, x11, lsl #2
     c10:      	add	x11, x23, x11, lsl #3
     c14:      	ldr	w10, [x8, x9]
     c18:      	ldr	x9, [sp, #0x118]
     c1c:      	add	x8, x23, #0x90
     c20:      	str	w10, [x8, x9]
     c24:      	add	x9, x9, #0x4
     c28:      	str	x9, [x11, #0x5e78]
     c2c:      	cbz	w10, 0xd44 <generic_kprobe_process_event+0x9e4>
     c30:      	mov	w8, #0x4                // =4
     c34:      	b	0xdf4 <generic_kprobe_process_event+0xa94>
     c38:      	ldr	x29, [sp, #0x60]
     c3c:      	mov	x8, xzr
     c40:      	b	0x182c <generic_kprobe_process_event+0x14cc>
     c44:      	add	x8, sp, #0xf0
     c48:      	str	x29, [sp, #0xa8]
     c4c:      	str	xzr, [x8, #0x10]
     c50:      	ldr	x8, [sp, #0x58]
     c54:      	cmp	w8, #0x17
     c58:      	b.le	0xcf4 <generic_kprobe_process_event+0x994>
     c5c:      	ldr	x21, [sp, #0x118]
     c60:      	cmp	w8, #0x18
     c64:      	mov	x24, x25
     c68:      	b.eq	0xe40 <generic_kprobe_process_event+0xae0>
     c6c:      	cmp	w8, #0x25
     c70:      	mov	w25, #0x5efc            // =24316
     c74:      	b.eq	0xe98 <generic_kprobe_process_event+0xb38>
     c78:      	cmp	w8, #0x2a
     c7c:      	b.ne	0xf24 <generic_kprobe_process_event+0xbc4>
     c80:      	mov	w8, #0x6430             // =25648
     c84:      	str	xzr, [x23, #0x6430]
     c88:      	str	x29, [x23, #0x6438]
     c8c:      	add	x8, x23, x8
     c90:      	b	0xec4 <generic_kprobe_process_event+0xb64>
     c94:      	ldr	x8, [sp, #0x70]
     c98:      	cmp	w11, #0x15
     c9c:      	str	x8, [sp, #0x48]
     ca0:      	b.gt	0xd18 <generic_kprobe_process_event+0x9b8>
     ca4:      	mov	w23, #0x1fe             // =510
     ca8:      	cmp	w11, #0x9
     cac:      	b.le	0xe18 <generic_kprobe_process_event+0xab8>
     cb0:      	cmp	w11, #0x10
     cb4:      	b.le	0xf30 <generic_kprobe_process_event+0xbd0>
     cb8:      	cmp	w11, #0x12
     cbc:      	b.le	0xfa8 <generic_kprobe_process_event+0xc48>
     cc0:      	cmp	w11, #0x13
     cc4:      	b.eq	0xfd0 <generic_kprobe_process_event+0xc70>
     cc8:      	cmp	w11, #0x14
     ccc:      	b.eq	0xff8 <generic_kprobe_process_event+0xc98>
     cd0:      	cmp	w11, #0x15
     cd4:      	b.ne	0x1008 <generic_kprobe_process_event+0xca8>
     cd8:      	mov	w23, #0x20              // =32
     cdc:      	b	0x100c <generic_kprobe_process_event+0xcac>
     ce0:      	ldr	x29, [sp, #0x60]
     ce4:      	mov	x8, xzr
     ce8:      	mov	x24, x25
     cec:      	mov	w25, #0x5efc            // =24316
     cf0:      	b	0x182c <generic_kprobe_process_event+0x14cc>
     cf4:      	ldr	x21, [sp, #0x118]
     cf8:      	cmp	w8, #0xf
     cfc:      	mov	x24, x25
     d00:      	b.eq	0xecc <generic_kprobe_process_event+0xb6c>
     d04:      	cmp	w8, #0x10
     d08:      	mov	w25, #0x5efc            // =24316
     d0c:      	b.ne	0xf24 <generic_kprobe_process_event+0xbc4>
     d10:      	add	x21, sp, #0x80
     d14:      	b	0xe68 <generic_kprobe_process_event+0xb08>
     d18:      	cmp	w11, #0x20
     d1c:      	b.gt	0xe00 <generic_kprobe_process_event+0xaa0>
     d20:      	cmp	w11, #0x1a
     d24:      	b.gt	0xf54 <generic_kprobe_process_event+0xbf4>
     d28:      	cmp	w11, #0x16
     d2c:      	b.eq	0xfa0 <generic_kprobe_process_event+0xc40>
     d30:      	cmp	w11, #0x17
     d34:      	b.eq	0xf4c <generic_kprobe_process_event+0xbec>
     d38:      	cmp	w11, #0x1a
     d3c:      	b.eq	0xfe8 <generic_kprobe_process_event+0xc88>
     d40:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     d44:      	add	x21, x8, x9
     d48:      	ldr	w8, [x24, #0x4]
     d4c:      	ldr	x29, [x23, #0x6440]
     d50:      	mov	w24, #0x4               // =4
     d54:      	and	x9, x8, #0xfff
     d58:      	add	x2, x0, x9
     d5c:      	mov	w9, #0xfff              // =4095
     d60:      	add	x0, x21, #0x4
     d64:      	sub	w8, w9, w8
     d68:      	and	w23, w8, #0xfff
     d6c:      	mov	w8, #0x4                // =4
     d70:      	mov	w1, w23
     d74:      	blr	x8
     d78:      	str	w23, [x21]
     d7c:      	add	x2, x29, #0x8
     d80:      	mov	w29, #0x8               // =8
     d84:      	add	x8, sp, #0xa8
     d88:      	mov	w9, #0x4                // =4
     d8c:      	add	x0, sp, #0xa8
     d90:      	mov	w1, #0x8                // =8
     d94:      	blr	x9
     d98:      	ldr	x8, [sp, #0xa8]
     d9c:      	add	x9, sp, #0x100
     da0:      	mov	w10, #0x4               // =4
     da4:      	add	x0, sp, #0x100
     da8:      	mov	w1, #0x8                // =8
     dac:      	add	x8, x8, #0x30
     db0:      	ldr	x8, [sp, #0xa8]
     db4:      	ldr	x29, [sp, #0x60]
     db8:      	add	x2, x8, #0x30
     dbc:      	blr	x10
     dc0:      	add	x11, sp, #0xf0
     dc4:      	mov	w9, #0x2                // =2
     dc8:      	add	x10, sp, #0x80
     dcc:      	ldr	x8, [x11, #0x10]
     dd0:      	add	x0, sp, #0x80
     dd4:      	mov	w1, #0x2                // =2
     dd8:      	ldr	x2, [x11, #0x10]
     ddc:      	blr	x24
     de0:      	add	x8, x21, x23
     de4:      	str	wzr, [x8, #0x4]
     de8:      	ldrh	w9, [sp, #0x80]
     dec:      	strh	w9, [x8, #0x8]
     df0:      	add	w8, w23, #0xe
     df4:      	mov	x24, x25
     df8:      	mov	w25, #0x5efc            // =24316
     dfc:      	b	0x182c <generic_kprobe_process_event+0x14cc>
     e00:      	cmp	w11, #0x26
     e04:      	b.gt	0xf68 <generic_kprobe_process_event+0xc08>
     e08:      	sub	w8, w11, #0x21
     e0c:      	cmp	w8, #0x4
     e10:      	b.lo	0xf4c <generic_kprobe_process_event+0xbec>
     e14:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     e18:      	cmp	w11, #0x4
     e1c:      	b.gt	0xf84 <generic_kprobe_process_event+0xc24>
     e20:      	sub	w8, w11, #0x2
     e24:      	cmp	w8, #0x2
     e28:      	b.lo	0xf60 <generic_kprobe_process_event+0xc00>
     e2c:      	cmp	w11, #0x1
     e30:      	b.eq	0xf60 <generic_kprobe_process_event+0xc00>
     e34:      	cmp	w11, #0x4
     e38:      	b.eq	0xf4c <generic_kprobe_process_event+0xbec>
     e3c:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     e40:      	add	x21, sp, #0x80
     e44:      	mov	w8, #0x8                // =8
     e48:      	mov	w9, #0x4                // =4
     e4c:      	ldr	x2, [sp, #0xa8]
     e50:      	add	x0, sp, #0x80
     e54:      	mov	w1, #0x8                // =8
     e58:      	blr	x9
     e5c:      	ldr	x8, [sp, #0x80]
     e60:      	mov	w25, #0x5efc            // =24316
     e64:      	str	x8, [sp, #0xa8]
     e68:      	mov	w8, #0x8                // =8
     e6c:      	mov	w9, #0x4                // =4
     e70:      	add	x10, sp, #0xa8
     e74:      	add	x0, sp, #0x80
     e78:      	add	x2, sp, #0xa8
     e7c:      	mov	w1, #0x8                // =8
     e80:      	blr	x9
     e84:      	ldr	x8, [sp, #0x80]
     e88:      	ldr	x29, [sp, #0x60]
     e8c:      	add	x8, x8, #0x40
     e90:      	ldr	x21, [sp, #0x118]
     e94:      	b	0xf00 <generic_kprobe_process_event+0xba0>
     e98:      	add	x8, x29, #0x40
     e9c:      	mov	w9, #0x8                // =8
     ea0:      	mov	w10, #0x4               // =4
     ea4:      	str	x8, [sp, #0xa8]
     ea8:      	add	x11, sp, #0x80
     eac:      	add	x0, sp, #0x80
     eb0:      	mov	w1, #0x8                // =8
     eb4:      	ldr	x2, [sp, #0xa8]
     eb8:      	blr	x10
     ebc:      	ldr	x8, [sp, #0x80]
     ec0:      	add	x8, x8, #0x40
     ec4:      	ldr	x29, [sp, #0x60]
     ec8:      	b	0xf00 <generic_kprobe_process_event+0xba0>
     ecc:      	mov	w8, #0x8                // =8
     ed0:      	mov	w9, #0x4                // =4
     ed4:      	add	x10, sp, #0x100
     ed8:      	add	x11, sp, #0xa8
     edc:      	add	x0, sp, #0x100
     ee0:      	add	x2, sp, #0xa8
     ee4:      	mov	w1, #0x8                // =8
     ee8:      	add	x25, sp, #0xf0
     eec:      	blr	x9
     ef0:      	ldr	x8, [x25, #0x10]
     ef4:      	ldr	x29, [sp, #0x60]
     ef8:      	mov	w25, #0x5efc            // =24316
     efc:      	cbz	x8, 0x1830 <generic_kprobe_process_event+0x14d0>
     f00:      	str	x8, [x23, #0x6440]
     f04:      	mov	w8, #0x6                // =6
     f08:      	mov	w9, #0xc                // =12
     f0c:      	mov	x0, x19
     f10:      	mov	x1, x24
     f14:      	mov	w2, #0x6                // =6
     f18:      	blr	x9
     f1c:      	mov	x8, xzr
     f20:      	b	0x1830 <generic_kprobe_process_event+0x14d0>
     f24:      	ldr	x29, [sp, #0x60]
     f28:      	mov	x8, xzr
     f2c:      	b	0x1830 <generic_kprobe_process_event+0x14d0>
     f30:      	sub	w8, w11, #0xa
     f34:      	cmp	w8, #0x2
     f38:      	b.lo	0xf4c <generic_kprobe_process_event+0xbec>
     f3c:      	sub	w8, w11, #0xc
     f40:      	cmp	w8, #0x2
     f44:      	b.lo	0xf60 <generic_kprobe_process_event+0xc00>
     f48:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     f4c:      	mov	w23, #0x8               // =8
     f50:      	b	0x100c <generic_kprobe_process_event+0xcac>
     f54:      	sub	w8, w11, #0x1d
     f58:      	cmp	w8, #0x4
     f5c:      	b.hs	0x1000 <generic_kprobe_process_event+0xca0>
     f60:      	mov	w23, #0x4               // =4
     f64:      	b	0x100c <generic_kprobe_process_event+0xcac>
     f68:      	cmp	w11, #0x28
     f6c:      	b.gt	0xfc0 <generic_kprobe_process_event+0xc60>
     f70:      	cmp	w11, #0x27
     f74:      	b.eq	0xfa0 <generic_kprobe_process_event+0xc40>
     f78:      	cmp	w11, #0x28
     f7c:      	b.eq	0xfd0 <generic_kprobe_process_event+0xc70>
     f80:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     f84:      	cmp	w11, #0x6
     f88:      	b.gt	0xfd8 <generic_kprobe_process_event+0xc78>
     f8c:      	cmp	w11, #0x5
     f90:      	b.eq	0xff0 <generic_kprobe_process_event+0xc90>
     f94:      	cmp	w11, #0x6
     f98:      	b.eq	0x100c <generic_kprobe_process_event+0xcac>
     f9c:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     fa0:      	mov	w23, #0x10              // =16
     fa4:      	b	0x100c <generic_kprobe_process_event+0xcac>
     fa8:      	cmp	w11, #0x11
     fac:      	b.eq	0x100c <generic_kprobe_process_event+0xcac>
     fb0:      	cmp	w11, #0x12
     fb4:      	mov	x23, x12
     fb8:      	b.eq	0x100c <generic_kprobe_process_event+0xcac>
     fbc:      	b	0x1008 <generic_kprobe_process_event+0xca8>
     fc0:      	cmp	w11, #0x29
     fc4:      	b.eq	0xff0 <generic_kprobe_process_event+0xc90>
     fc8:      	cmp	w11, #0x2b
     fcc:      	b.ne	0x1008 <generic_kprobe_process_event+0xca8>
     fd0:      	mov	w23, #0x18              // =24
     fd4:      	b	0x100c <generic_kprobe_process_event+0xcac>
     fd8:      	cmp	w11, #0x7
     fdc:      	b.eq	0xff0 <generic_kprobe_process_event+0xc90>
     fe0:      	cmp	w11, #0x8
     fe4:      	b.ne	0x1008 <generic_kprobe_process_event+0xca8>
     fe8:      	mov	w23, #0x50              // =80
     fec:      	b	0x100c <generic_kprobe_process_event+0xcac>
     ff0:      	mov	w23, #0x40              // =64
     ff4:      	b	0x100c <generic_kprobe_process_event+0xcac>
     ff8:      	mov	w23, #0x98              // =152
     ffc:      	b	0x100c <generic_kprobe_process_event+0xcac>
    1000:      	cmp	w11, #0x1b
    1004:      	b.eq	0xfe8 <generic_kprobe_process_event+0xc88>
    1008:      	mov	x23, xzr
    100c:      	str	x12, [sp, #0x38]
    1010:      	str	wzr, [sp, #0x7c]
    1014:      	mov	w8, #0x1                // =1
    1018:      	add	x9, sp, #0x7c
    101c:      	add	x1, sp, #0x7c
    1020:      	mov	x0, x22
    1024:      	blr	x8
    1028:      	mov	x8, xzr
    102c:      	cbz	x0, 0x182c <generic_kprobe_process_event+0x14cc>
    1030:      	ldr	x10, [sp, #0x118]
    1034:      	mov	w9, #0x3ffb             // =16379
    1038:      	sub	x9, x9, x23
    103c:      	cmp	x9, x10
    1040:      	b.ls	0x182c <generic_kprobe_process_event+0x14cc>
    1044:      	ldr	x12, [sp, #0x50]
    1048:      	mov	w8, #0x5ea0             // =24224
    104c:      	ldr	x9, [sp, #0x118]
    1050:      	add	x11, x0, #0x90
    1054:      	add	x10, x0, x12, lsl #2
    1058:      	add	x23, x9, #0x4
    105c:      	ldr	w8, [x10, x8]
    1060:      	str	w8, [x11, x9]
    1064:      	add	x9, x0, x12, lsl #3
    1068:      	str	x23, [x9, #0x5e78]
    106c:      	cbz	w8, 0x1078 <generic_kprobe_process_event+0xd18>
    1070:      	mov	w8, #0x4                // =4
    1074:      	b	0x182c <generic_kprobe_process_event+0x14cc>
    1078:      	ldr	x9, [sp, #0x58]
    107c:      	ldr	x12, [sp, #0x48]
    1080:      	add	x8, x11, x23
    1084:      	cmp	w9, #0x17
    1088:      	stp	x8, x11, [sp, #0x20]
    108c:      	add	x8, sp, #0xf0
    1090:      	str	x12, [sp, #0xa8]
    1094:      	str	xzr, [x8, #0x10]
    1098:      	str	x10, [sp, #0x30]
    109c:      	b.le	0x10c4 <generic_kprobe_process_event+0xd64>
    10a0:      	cmp	w9, #0x18
    10a4:      	b.eq	0x10e0 <generic_kprobe_process_event+0xd80>
    10a8:      	cmp	w9, #0x25
    10ac:      	b.eq	0x112c <generic_kprobe_process_event+0xdcc>
    10b0:      	cmp	w9, #0x2a
    10b4:      	b.ne	0x1680 <generic_kprobe_process_event+0x1320>
    10b8:      	add	x8, sp, #0x80
    10bc:      	stp	xzr, x12, [sp, #0x80]
    10c0:      	b	0x115c <generic_kprobe_process_event+0xdfc>
    10c4:      	cmp	w9, #0xf
    10c8:      	b.eq	0x15b8 <generic_kprobe_process_event+0x1258>
    10cc:      	cmp	w9, #0x10
    10d0:      	b.ne	0x1680 <generic_kprobe_process_event+0x1320>
    10d4:      	add	x21, sp, #0xf8
    10d8:      	add	x23, sp, #0xf0
    10dc:      	b	0x1108 <generic_kprobe_process_event+0xda8>
    10e0:      	add	x21, sp, #0xf8
    10e4:      	mov	w8, #0x8                // =8
    10e8:      	mov	w9, #0x4                // =4
    10ec:      	ldr	x2, [sp, #0xa8]
    10f0:      	add	x0, sp, #0xf8
    10f4:      	mov	w1, #0x8                // =8
    10f8:      	add	x23, sp, #0xf0
    10fc:      	blr	x9
    1100:      	ldr	x8, [x23, #0x8]
    1104:      	str	x8, [sp, #0xa8]
    1108:      	mov	w8, #0x8                // =8
    110c:      	mov	w9, #0x4                // =4
    1110:      	add	x10, sp, #0xa8
    1114:      	add	x0, sp, #0xf8
    1118:      	add	x2, sp, #0xa8
    111c:      	mov	w1, #0x8                // =8
    1120:      	blr	x9
    1124:      	ldr	x8, [x23, #0x8]
    1128:      	b	0x1158 <generic_kprobe_process_event+0xdf8>
    112c:      	add	x8, x12, #0x40
    1130:      	mov	w9, #0x8                // =8
    1134:      	mov	w10, #0x4               // =4
    1138:      	str	x8, [sp, #0xa8]
    113c:      	add	x11, sp, #0xf8
    1140:      	add	x0, sp, #0xf8
    1144:      	mov	w1, #0x8                // =8
    1148:      	add	x21, sp, #0xf0
    114c:      	ldr	x2, [sp, #0xa8]
    1150:      	blr	x10
    1154:      	ldr	x8, [x21, #0x8]
    1158:      	add	x8, x8, #0x40
    115c:      	str	x8, [sp, #0x40]
    1160:      	str	wzr, [sp, #0x94]
    1164:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    1168:      	mov	w8, #0x1                // =1
    116c:      	add	x9, sp, #0x94
    1170:      	ldr	x0, [x0]
    1174:      	add	x1, sp, #0x94
    1178:      	blr	x8
    117c:      	cbz	x0, 0x1214 <generic_kprobe_process_event+0xeb4>
    1180:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    1184:      	str	x0, [sp, #0x38]
    1188:      	str	x8, [sp, #0x50]
    118c:      	mov	w8, #0x23               // =35
    1190:      	blr	x8
    1194:      	add	x2, x0, #0xb30
    1198:      	mov	w29, #0x8               // =8
    119c:      	add	x8, sp, #0x98
    11a0:      	mov	w9, #0x4                // =4
    11a4:      	add	x0, sp, #0x98
    11a8:      	mov	w1, #0x8                // =8
    11ac:      	mov	w21, #0x4               // =4
    11b0:      	blr	x9
    11b4:      	ldr	x8, [sp, #0x98]
    11b8:      	mov	w9, #0x4                // =4
    11bc:      	add	x0, sp, #0xa0
    11c0:      	mov	w1, #0x8                // =8
    11c4:      	str	x8, [sp, #0x18]
    11c8:      	add	x24, x8, #0x18
    11cc:      	ldr	x8, [sp, #0x40]
    11d0:      	add	x2, x8, #0x8
    11d4:      	add	x8, sp, #0xa0
    11d8:      	str	x2, [sp, #0x48]
    11dc:      	blr	x9
    11e0:      	ldr	x23, [sp, #0xa0]
    11e4:      	add	x8, sp, #0xa8
    11e8:      	add	x0, sp, #0xa8
    11ec:      	mov	w1, #0x8                // =8
    11f0:      	add	x2, x23, #0x10
    11f4:      	blr	x21
    11f8:      	ldr	x8, [sp, #0xa8]
    11fc:      	str	x24, [sp, #0x58]
    1200:      	cbz	x8, 0x121c <generic_kprobe_process_event+0xebc>
    1204:      	ldr	x9, [sp, #0x50]
    1208:      	ldr	x10, [sp, #0x38]
    120c:      	mov	w8, #0x1000             // =4096
    1210:      	b	0x1268 <generic_kprobe_process_event+0xf08>
    1214:      	mov	x21, xzr
    1218:      	b	0x1824 <generic_kprobe_process_event+0x14c4>
    121c:      	add	x2, x23, #0x18
    1220:      	mov	w8, #0x8                // =8
    1224:      	mov	w9, #0x4                // =4
    1228:      	add	x10, sp, #0xa8
    122c:      	add	x0, sp, #0xa8
    1230:      	mov	w1, #0x8                // =8
    1234:      	blr	x9
    1238:      	ldr	x8, [sp, #0xa8]
    123c:      	cmp	x8, x23
    1240:      	b.eq	0x1204 <generic_kprobe_process_event+0xea4>
    1244:      	ldr	x10, [sp, #0x38]
    1248:      	mov	w8, #0x2964             // =10596
    124c:      	strh	w8, [x10, #0xffe]
    1250:      	adrp	x8, 0x1000 <generic_kprobe_process_event+0xca0>
    1254:      	add	x8, x8, #0x0
    1258:      	add	x9, x10, #0xff6
    125c:      	ldr	x8, [x8]
    1260:      	str	x8, [x9]
    1264:      	mov	w8, #0xff6              // =4086
    1268:      	ldr	x11, [sp, #0x18]
    126c:      	add	x12, sp, #0xa8
    1270:      	stp	x10, xzr, [sp, #0xb8]
    1274:      	mov	w24, #0x8               // =8
    1278:      	add	x0, sp, #0xa8
    127c:      	mov	w1, #0x8                // =8
    1280:      	add	x10, x12, #0x20
    1284:      	stp	xzr, xzr, [sp, #0xa8]
    1288:      	add	x23, x12, #0x8
    128c:      	add	x29, x12, #0x18
    1290:      	mov	w21, #0x4               // =4
    1294:      	add	x2, x11, #0x20
    1298:      	str	x10, [sp, #0x38]
    129c:      	stp	xzr, xzr, [sp, #0xc8]
    12a0:      	str	x9, [sp, #0x50]
    12a4:      	str	x9, [sp, #0xd8]
    12a8:      	str	w8, [sp, #0xe0]
    12ac:      	mov	w8, #0x4                // =4
    12b0:      	strb	wzr, [sp, #0xe4]
    12b4:      	blr	x8
    12b8:      	ldr	x2, [sp, #0x58]
    12bc:      	mov	w8, #0x4                // =4
    12c0:      	mov	x0, x23
    12c4:      	mov	w1, #0x8                // =8
    12c8:      	mov	w23, #0x8               // =8
    12cc:      	blr	x8
    12d0:      	ldr	x2, [sp, #0x48]
    12d4:      	mov	w8, #0x4                // =4
    12d8:      	mov	x0, x29
    12dc:      	mov	w1, #0x8                // =8
    12e0:      	str	x29, [sp, #0x58]
    12e4:      	blr	x8
    12e8:      	ldp	x0, x2, [sp, #0x38]
    12ec:      	mov	w1, #0x8                // =8
    12f0:      	blr	x21
    12f4:      	ldr	x8, [sp, #0xc8]
    12f8:      	mov	w24, #0x80              // =128
    12fc:      	sub	x8, x8, #0x20
    1300:      	str	x8, [sp, #0xd0]
    1304:      	b	0x1310 <generic_kprobe_process_event+0xfb0>
    1308:      	subs	w24, w24, #0x1
    130c:      	b.eq	0x14a4 <generic_kprobe_process_event+0x1144>
    1310:      	ldp	x29, x2, [sp, #0xc0]
    1314:      	ldp	x8, x9, [sp, #0xa8]
    1318:      	cmp	x29, x8
    131c:      	ccmp	x2, x9, #0x0, eq
    1320:      	b.eq	0x149c <generic_kprobe_process_event+0x113c>
    1324:      	ldr	x21, [sp, #0xd0]
    1328:      	mov	w8, #0x4                // =4
    132c:      	add	x9, sp, #0xe8
    1330:      	add	x0, sp, #0xe8
    1334:      	mov	w1, #0x8                // =8
    1338:      	blr	x8
    133c:      	ldr	x8, [sp, #0xe8]
    1340:      	mov	w10, #0x8               // =8
    1344:      	cmp	x29, x8
    1348:      	b.eq	0x1444 <generic_kprobe_process_event+0x10e4>
    134c:      	add	x23, x29, #0x18
    1350:      	mov	w8, #0x4                // =4
    1354:      	add	x9, sp, #0xf8
    1358:      	add	x0, sp, #0xf8
    135c:      	mov	w1, #0x8                // =8
    1360:      	mov	x2, x23
    1364:      	blr	x8
    1368:      	add	x8, sp, #0xf0
    136c:      	mov	w10, #0x8               // =8
    1370:      	ldr	x8, [x8, #0x8]
    1374:      	cmp	x8, x29
    1378:      	b.eq	0x1444 <generic_kprobe_process_event+0x10e4>
    137c:      	mov	w8, #0x4                // =4
    1380:      	add	x9, sp, #0xf0
    1384:      	add	x0, sp, #0xf0
    1388:      	mov	w1, #0x8                // =8
    138c:      	mov	x2, x23
    1390:      	blr	x8
    1394:      	add	x2, x29, #0x20
    1398:      	mov	w8, #0x4                // =4
    139c:      	mov	w9, #0x10               // =16
    13a0:      	add	x10, sp, #0x100
    13a4:      	add	x0, sp, #0x100
    13a8:      	mov	w1, #0x10               // =16
    13ac:      	blr	x8
    13b0:      	add	x8, sp, #0xf0
    13b4:      	ldr	w21, [sp, #0x104]
    13b8:      	ldr	x10, [sp, #0xd8]
    13bc:      	ldr	w23, [sp, #0xe0]
    13c0:      	ldr	x9, [x8, #0x18]
    13c4:      	ldr	x8, [sp, #0xb8]
    13c8:      	sub	x12, x10, x8
    13cc:      	subs	w10, w21, w23
    13d0:      	csel	w10, wzr, w10, lo
    13d4:      	cmp	w23, w21
    13d8:      	csel	w11, w23, w21, lo
    13dc:      	cinc	w13, w11, hi
    13e0:      	sub	w14, w23, w13
    13e4:      	subs	x12, x12, x13
    13e8:      	str	w14, [sp, #0xe0]
    13ec:      	b.lo	0x14a4 <generic_kprobe_process_event+0x1144>
    13f0:      	cmp	x12, #0xfff
    13f4:      	b.hi	0x14a4 <generic_kprobe_process_event+0x1144>
    13f8:      	cmp	w23, w21
    13fc:      	b.ls	0x1408 <generic_kprobe_process_event+0x10a8>
    1400:      	mov	w13, #0x2f              // =47
    1404:      	strb	w13, [x8, x12]
    1408:      	add	x29, x8, x12
    140c:      	cmp	w23, w21
    1410:      	add	x2, x9, x10
    1414:      	and	w1, w11, #0xff
    1418:      	mov	w8, #0x4                // =4
    141c:      	cinc	x0, x29, hi
    1420:      	blr	x8
    1424:      	cmp	w23, w21
    1428:      	str	x29, [sp, #0xd8]
    142c:      	b.ls	0x14a4 <generic_kprobe_process_event+0x1144>
    1430:      	add	x8, sp, #0xf0
    1434:      	mov	w23, #0x8               // =8
    1438:      	ldr	x8, [x8]
    143c:      	str	x8, [sp, #0xc0]
    1440:      	b	0x1308 <generic_kprobe_process_event+0xfa8>
    1444:      	add	x2, x21, #0x10
    1448:      	mov	w8, #0x4                // =4
    144c:      	add	x9, sp, #0xf8
    1450:      	add	x0, sp, #0xf8
    1454:      	mov	w1, #0x8                // =8
    1458:      	blr	x8
    145c:      	add	x9, sp, #0xf0
    1460:      	ldr	x8, [sp, #0xd0]
    1464:      	mov	w23, #0x8               // =8
    1468:      	ldr	x9, [x9, #0x8]
    146c:      	cmp	x8, x9
    1470:      	b.eq	0x149c <generic_kprobe_process_event+0x113c>
    1474:      	ldr	x0, [sp, #0x58]
    1478:      	add	x2, x21, #0x18
    147c:      	mov	w8, #0x4                // =4
    1480:      	mov	w1, #0x8                // =8
    1484:      	blr	x8
    1488:      	add	x8, sp, #0xf0
    148c:      	ldr	x8, [x8, #0x8]
    1490:      	add	x9, x8, #0x20
    1494:      	stp	x9, x8, [sp, #0xc8]
    1498:      	b	0x1308 <generic_kprobe_process_event+0xfa8>
    149c:      	mov	w8, #0x1                // =1
    14a0:      	strb	w8, [sp, #0xe4]
    14a4:      	ldr	x8, [sp, #0xd8]
    14a8:      	ldr	x2, [sp, #0x50]
    14ac:      	cmp	x8, x2
    14b0:      	b.eq	0x14e8 <generic_kprobe_process_event+0x1188>
    14b4:      	ldrb	w9, [sp, #0xe4]
    14b8:      	mov	w11, #0x1000            // =4096
    14bc:      	cmp	w9, #0x0
    14c0:      	ldr	w9, [sp, #0xe0]
    14c4:      	cset	w10, eq
    14c8:      	sub	w11, w11, w9
    14cc:      	cmp	w9, #0x0
    14d0:      	csel	w9, w11, w9, gt
    14d4:      	cbz	x8, 0x1814 <generic_kprobe_process_event+0x14b4>
    14d8:      	lsl	w10, w10, #1
    14dc:      	mov	x2, x8
    14e0:      	str	w10, [sp, #0x58]
    14e4:      	b	0x14f0 <generic_kprobe_process_event+0x1190>
    14e8:      	mov	w9, wzr
    14ec:      	str	wzr, [sp, #0x58]
    14f0:      	ldr	x21, [sp, #0x20]
    14f4:      	and	w23, w9, #0xfff
    14f8:      	mov	w8, #0x4                // =4
    14fc:      	mov	w24, #0x4               // =4
    1500:      	mov	w1, w23
    1504:      	add	x0, x21, #0x4
    1508:      	blr	x8
    150c:      	str	w23, [x21]
    1510:      	ldr	x2, [sp, #0x48]
    1514:      	mov	w29, #0x8               // =8
    1518:      	add	x8, sp, #0xa8
    151c:      	mov	w9, #0x4                // =4
    1520:      	add	x0, sp, #0xa8
    1524:      	mov	w1, #0x8                // =8
    1528:      	blr	x9
    152c:      	ldr	x8, [sp, #0xa8]
    1530:      	add	x9, sp, #0x100
    1534:      	mov	w10, #0x4               // =4
    1538:      	add	x0, sp, #0x100
    153c:      	mov	w1, #0x8                // =8
    1540:      	add	x8, x8, #0x30
    1544:      	ldr	x8, [sp, #0xa8]
    1548:      	add	x2, x8, #0x30
    154c:      	blr	x10
    1550:      	add	x11, sp, #0xf0
    1554:      	mov	w9, #0x2                // =2
    1558:      	add	x10, sp, #0xf8
    155c:      	ldr	x8, [x11, #0x10]
    1560:      	add	x0, sp, #0xf8
    1564:      	mov	w1, #0x2                // =2
    1568:      	ldr	x2, [x11, #0x10]
    156c:      	blr	x24
    1570:      	ldr	w9, [sp, #0x58]
    1574:      	add	x8, x21, x23
    1578:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    157c:      	add	w21, w23, #0xa
    1580:      	str	w9, [x8, #0x4]
    1584:      	ldrh	w9, [sp, #0xf8]
    1588:      	strh	w9, [x8, #0x8]
    158c:      	ldr	x24, [x24]
    1590:      	ldp	x11, x9, [sp, #0x28]
    1594:      	mov	w10, #0x5ea0            // =24224
    1598:      	ldr	x29, [sp, #0x60]
    159c:      	tbz	w21, #0x1f, 0x1824 <generic_kprobe_process_event+0x14c4>
    15a0:      	mov	w8, #-0x1               // =-1
    15a4:      	str	w8, [x9, x10]
    15a8:      	ldr	x9, [sp, #0x118]
    15ac:      	str	w8, [x11, x9]
    15b0:      	mov	w8, #0x4                // =4
    15b4:      	b	0x182c <generic_kprobe_process_event+0x14cc>
    15b8:      	str	x21, [sp, #0x50]
    15bc:      	mov	w8, #0x8                // =8
    15c0:      	mov	w9, #0x4                // =4
    15c4:      	add	x10, sp, #0x100
    15c8:      	add	x11, sp, #0xa8
    15cc:      	add	x0, sp, #0x100
    15d0:      	add	x2, sp, #0xa8
    15d4:      	mov	w1, #0x8                // =8
    15d8:      	add	x21, sp, #0xf0
    15dc:      	blr	x9
    15e0:      	ldr	x8, [x21, #0x10]
    15e4:      	str	x8, [sp, #0x40]
    15e8:      	cbnz	x8, 0x1160 <generic_kprobe_process_event+0xe00>
    15ec:      	str	wzr, [sp, #0xa0]
    15f0:      	mov	w8, #0x1                // =1
    15f4:      	add	x9, sp, #0xa0
    15f8:      	add	x1, sp, #0xa0
    15fc:      	mov	x0, x22
    1600:      	blr	x8
    1604:      	mov	x21, xzr
    1608:      	cbz	x0, 0x1590 <generic_kprobe_process_event+0x1230>
    160c:      	ldr	x8, [sp, #0x58]
    1610:      	str	x0, [sp, #0x40]
    1614:      	cmp	w8, #0x19
    1618:      	str	x19, [sp, #0x10]
    161c:      	b.gt	0x1a20 <generic_kprobe_process_event+0x16c0>
    1620:      	cmp	w8, #0x12
    1624:      	b.le	0x1a68 <generic_kprobe_process_event+0x1708>
    1628:      	cmp	w8, #0x14
    162c:      	b.le	0x1e80 <generic_kprobe_process_event+0x1b20>
    1630:      	ldr	x8, [sp, #0x58]
    1634:      	cmp	w8, #0x15
    1638:      	b.eq	0x25b4 <generic_kprobe_process_event+0x2254>
    163c:      	ldr	x8, [sp, #0x58]
    1640:      	cmp	w8, #0x16
    1644:      	b.eq	0x254c <generic_kprobe_process_event+0x21ec>
    1648:      	ldr	x8, [sp, #0x58]
    164c:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1650:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1654:      	mov	w25, #0x5efc            // =24316
    1658:      	ldr	x24, [x24]
    165c:      	ldr	x22, [x22]
    1660:      	ldr	x19, [sp, #0x10]
    1664:      	cmp	w8, #0x17
    1668:      	b.ne	0x1590 <generic_kprobe_process_event+0x1230>
    166c:      	ldr	x8, [sp, #0x20]
    1670:      	ldr	x9, [sp, #0x48]
    1674:      	mov	w21, #0x8               // =8
    1678:      	stp	w9, wzr, [x8]
    167c:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    1680:      	cmp	w9, #0x28
    1684:      	str	x21, [sp, #0x50]
    1688:      	b.hi	0x15ec <generic_kprobe_process_event+0x128c>
    168c:      	mov	w8, #0x1                // =1
    1690:      	lsl	x8, x8, x9
    1694:      	mov	x9, #0x7cf2             // =31986
    1698:      	movk	x9, #0xf202, lsl #16
    169c:      	movk	x9, #0x1c1, lsl #32
    16a0:      	tst	x8, x9
    16a4:      	b.eq	0x15ec <generic_kprobe_process_event+0x128c>
    16a8:      	add	x8, sp, #0xf0
    16ac:      	str	wzr, [sp, #0xa0]
    16b0:      	add	x9, sp, #0xa0
    16b4:      	add	x1, sp, #0xa0
    16b8:      	str	x12, [x8]
    16bc:      	mov	w8, #0x1                // =1
    16c0:      	mov	x0, x22
    16c4:      	blr	x8
    16c8:      	mov	x21, xzr
    16cc:      	cbz	x0, 0x1590 <generic_kprobe_process_event+0x1230>
    16d0:      	ldr	x9, [sp, #0x58]
    16d4:      	cmp	w9, #0x10
    16d8:      	b.gt	0x18f0 <generic_kprobe_process_event+0x1590>
    16dc:      	cmp	w9, #0x9
    16e0:      	b.gt	0x1934 <generic_kprobe_process_event+0x15d4>
    16e4:      	cmp	w9, #0x4
    16e8:      	str	x19, [sp, #0x10]
    16ec:      	str	x0, [sp, #0x50]
    16f0:      	b.le	0x1ad8 <generic_kprobe_process_event+0x1778>
    16f4:      	cmp	w9, #0x5
    16f8:      	b.eq	0x2120 <generic_kprobe_process_event+0x1dc0>
    16fc:      	ldr	x8, [sp, #0x58]
    1700:      	cmp	w8, #0x6
    1704:      	b.eq	0x199c <generic_kprobe_process_event+0x163c>
    1708:      	ldr	x8, [sp, #0x58]
    170c:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1710:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1714:      	mov	w25, #0x5efc            // =24316
    1718:      	ldr	x24, [x24]
    171c:      	ldp	x11, x9, [sp, #0x28]
    1720:      	mov	w10, #0x5ea0            // =24224
    1724:      	cmp	w8, #0x7
    1728:      	ldr	x22, [x22]
    172c:      	ldr	x19, [sp, #0x10]
    1730:      	b.ne	0x1598 <generic_kprobe_process_event+0x1238>
    1734:      	add	x8, sp, #0xf0
    1738:      	ldr	x25, [sp, #0x20]
    173c:      	mov	w24, #0x2               // =2
    1740:      	mov	w1, #0x2                // =2
    1744:      	ldr	x23, [x8]
    1748:      	mov	w8, #0x4                // =4
    174c:      	mov	w21, #0x4               // =4
    1750:      	add	x0, x25, #0x26
    1754:      	str	x23, [x25, #0x28]
    1758:      	add	x2, x23, #0x10
    175c:      	blr	x8
    1760:      	add	x0, x25, #0x3a
    1764:      	add	x2, x23, #0x12
    1768:      	mov	w8, #0x1                // =1
    176c:      	mov	w9, #0x4                // =4
    1770:      	mov	w1, #0x1                // =1
    1774:      	blr	x9
    1778:      	add	x0, x25, #0x38
    177c:      	add	x2, x23, #0x21e
    1780:      	mov	w8, #0x4                // =4
    1784:      	mov	w1, #0x2                // =2
    1788:      	blr	x8
    178c:      	add	x0, x25, #0x24
    1790:      	add	x2, x23, #0x21c
    1794:      	mov	w8, #0x4                // =4
    1798:      	mov	w1, #0x2                // =2
    179c:      	blr	x8
    17a0:      	add	x0, x25, #0x30
    17a4:      	add	x2, x23, #0x214
    17a8:      	mov	w8, #0x4                // =4
    17ac:      	mov	w1, #0x4                // =4
    17b0:      	blr	x8
    17b4:      	add	x0, x25, #0x34
    17b8:      	add	x2, x23, #0x210
    17bc:      	mov	w1, #0x4                // =4
    17c0:      	blr	x21
    17c4:      	ldrh	w8, [x25, #0x26]
    17c8:      	mov	x24, x25
    17cc:      	stp	xzr, xzr, [x25]
    17d0:      	cmp	w8, #0xa
    17d4:      	str	xzr, [x25, #0x18]
    17d8:      	str	xzr, [x24, #0x10]!
    17dc:      	b.eq	0x28ac <generic_kprobe_process_event+0x254c>
    17e0:      	cmp	w8, #0x2
    17e4:      	b.ne	0x28d8 <generic_kprobe_process_event+0x2578>
    17e8:      	ldr	x0, [sp, #0x20]
    17ec:      	add	x2, x23, #0x4
    17f0:      	mov	w8, #0x4                // =4
    17f4:      	mov	w1, #0x4                // =4
    17f8:      	mov	w21, #0x4               // =4
    17fc:      	blr	x8
    1800:      	mov	x0, x24
    1804:      	mov	w1, #0x4                // =4
    1808:      	mov	x2, x23
    180c:      	blr	x21
    1810:      	b	0x28d8 <generic_kprobe_process_event+0x2578>
    1814:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1818:      	mov	x21, xzr
    181c:      	ldr	x24, [x24]
    1820:      	ldr	x29, [sp, #0x60]
    1824:      	and	x8, x21, #0x7fffffff
    1828:      	add	x8, x8, #0x4
    182c:      	ldr	x21, [sp, #0x118]
    1830:      	add	w21, w21, w8
    1834:      	cmp	w29, #0x3
    1838:      	str	w21, [x20, #0x4]
    183c:      	b.gt	0x18ac <generic_kprobe_process_event+0x154c>
    1840:      	str	wzr, [sp, #0xa8]
    1844:      	mov	w8, #0x1                // =1
    1848:      	add	x9, sp, #0xa8
    184c:      	add	x1, sp, #0xa8
    1850:      	mov	x0, x22
    1854:      	blr	x8
    1858:      	cbz	x0, 0x18ac <generic_kprobe_process_event+0x154c>
    185c:      	mov	w8, #0x5ef8             // =24312
    1860:      	add	x1, x0, x8
    1864:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    1868:      	mov	w8, #0x1                // =1
    186c:      	ldr	x0, [x0]
    1870:      	blr	x8
    1874:      	cbz	x0, 0x18ac <generic_kprobe_process_event+0x154c>
    1878:      	add	w8, w29, #0x1
    187c:      	and	w9, w8, #0x7
    1880:      	add	x9, x0, w9, uxtw #2
    1884:      	ldr	w9, [x9, #0x40]
    1888:      	cmn	w9, #0x1
    188c:      	b.eq	0x18ac <generic_kprobe_process_event+0x154c>
    1890:      	str	w8, [x20, x25]
    1894:      	mov	w8, #0x1                // =1
    1898:      	mov	w9, #0xc                // =12
    189c:      	mov	x0, x19
    18a0:      	mov	x1, x24
    18a4:      	mov	w2, #0x1                // =1
    18a8:      	blr	x9
    18ac:      	str	wzr, [x20, x25]
    18b0:      	mov	w8, #0x3                // =3
    18b4:      	mov	w9, #0xc                // =12
    18b8:      	mov	x0, x19
    18bc:      	mov	x1, x24
    18c0:      	mov	w2, #0x3                // =3
    18c4:      	blr	x9
    18c8:      	ldp	x20, x19, [sp, #0x150]
    18cc:      	mov	w0, wzr
    18d0:      	ldr	x29, [sp, #0x110]
    18d4:      	ldp	x22, x21, [sp, #0x140]
    18d8:      	ldp	x24, x23, [sp, #0x130]
    18dc:      	ldp	x30, x25, [sp, #0x120]
    18e0:      	add	sp, sp, #0x160
    18e4:      	ret
    18e8:      	mov	w29, #0x5               // =5
    18ec:      	b	0xb74 <generic_kprobe_process_event+0x814>
    18f0:      	cmp	w9, #0x1e
    18f4:      	b.gt	0x19d8 <generic_kprobe_process_event+0x1678>
    18f8:      	mov	x29, x24
    18fc:      	cmp	w9, #0x1c
    1900:      	str	x0, [sp, #0x50]
    1904:      	b.gt	0x1b4c <generic_kprobe_process_event+0x17ec>
    1908:      	ldr	x8, [sp, #0x58]
    190c:      	cmp	w8, #0x11
    1910:      	b.eq	0x227c <generic_kprobe_process_event+0x1f1c>
    1914:      	ldr	x8, [sp, #0x58]
    1918:      	cmp	w8, #0x19
    191c:      	b.eq	0x1f48 <generic_kprobe_process_event+0x1be8>
    1920:      	ldr	x8, [sp, #0x58]
    1924:      	mov	x24, x29
    1928:      	mov	w25, #0x5efc            // =24316
    192c:      	cmp	w8, #0x1c
    1930:      	b	0x1b00 <generic_kprobe_process_event+0x17a0>
    1934:      	sub	w8, w9, #0xa
    1938:      	cmp	w8, #0x2
    193c:      	b.lo	0x1b0c <generic_kprobe_process_event+0x17ac>
    1940:      	sub	w8, w9, #0xc
    1944:      	cmp	w8, #0x2
    1948:      	b.lo	0x1b2c <generic_kprobe_process_event+0x17cc>
    194c:      	ldr	x8, [sp, #0x58]
    1950:      	ldp	x11, x9, [sp, #0x28]
    1954:      	mov	w10, #0x5ea0            // =24224
    1958:      	cmp	w8, #0xe
    195c:      	b.ne	0x1598 <generic_kprobe_process_event+0x1238>
    1960:      	str	x19, [sp, #0x10]
    1964:      	mov	w21, #0x8               // =8
    1968:      	add	x8, sp, #0xa8
    196c:      	add	x24, sp, #0xf0
    1970:      	mov	w9, #0x4                // =4
    1974:      	add	x0, sp, #0xa8
    1978:      	add	x2, sp, #0xf0
    197c:      	mov	w1, #0x8                // =8
    1980:      	mov	w23, #0x4               // =4
    1984:      	blr	x9
    1988:      	ldr	x8, [sp, #0xa8]
    198c:      	add	x0, sp, #0xf0
    1990:      	mov	w1, #0x8                // =8
    1994:      	ldr	x2, [sp, #0xa8]
    1998:      	blr	x23
    199c:      	add	x8, sp, #0xf0
    19a0:      	mov	w9, #0x2d               // =45
    19a4:      	mov	w1, #0x1ff              // =511
    19a8:      	ldr	x2, [x8]
    19ac:      	ldr	x8, [sp, #0x20]
    19b0:      	add	x0, x8, #0x4
    19b4:      	mov	w8, #0x1ff              // =511
    19b8:      	blr	x9
    19bc:      	mov	x21, x0
    19c0:      	tbnz	x0, #0x3f, 0x3ad0 <generic_kprobe_process_event+0x3770>
    19c4:      	ldr	x9, [sp, #0x20]
    19c8:      	sub	w8, w21, #0x1
    19cc:      	add	x21, x21, #0x3
    19d0:      	str	w8, [x9]
    19d4:      	b	0x3ad0 <generic_kprobe_process_event+0x3770>
    19d8:      	mov	x23, x19
    19dc:      	mov	x29, x24
    19e0:      	cmp	w9, #0x26
    19e4:      	b.gt	0x1b70 <generic_kprobe_process_event+0x1810>
    19e8:      	sub	w8, w9, #0x1f
    19ec:      	cmp	w8, #0x2
    19f0:      	b.hs	0x1de4 <generic_kprobe_process_event+0x1a84>
    19f4:      	ldr	x0, [sp, #0x20]
    19f8:      	mov	w8, #0x1                // =1
    19fc:      	add	x9, sp, #0xf0
    1a00:      	mov	w10, #0x4               // =4
    1a04:      	add	x2, sp, #0xf0
    1a08:      	mov	w1, #0x1                // =1
    1a0c:      	mov	w21, #0x4               // =4
    1a10:      	blr	x10
    1a14:      	b	0x2aac <generic_kprobe_process_event+0x274c>
    1a18:      	mov	w29, #0x6               // =6
    1a1c:      	b	0xb74 <generic_kprobe_process_event+0x814>
    1a20:      	mov	x29, x24
    1a24:      	cmp	w8, #0x20
    1a28:      	b.le	0x1d58 <generic_kprobe_process_event+0x19f8>
    1a2c:      	sub	w8, w8, #0x21
    1a30:      	cmp	w8, #0x4
    1a34:      	b.hs	0x1c2c <generic_kprobe_process_event+0x18cc>
    1a38:      	ldr	x0, [sp, #0x20]
    1a3c:      	ldr	x2, [sp, #0x48]
    1a40:      	mov	w21, #0x8               // =8
    1a44:      	mov	w8, #0x4                // =4
    1a48:      	mov	w1, #0x8                // =8
    1a4c:      	blr	x8
    1a50:      	mov	x24, x29
    1a54:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1a58:      	mov	w25, #0x5efc            // =24316
    1a5c:      	ldr	x22, [x22]
    1a60:      	ldr	x19, [sp, #0x10]
    1a64:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    1a68:      	cmp	w8, #0x7
    1a6c:      	b.gt	0x1e34 <generic_kprobe_process_event+0x1ad4>
    1a70:      	ldr	x8, [sp, #0x58]
    1a74:      	cmp	w8, #0x2
    1a78:      	b.eq	0x2370 <generic_kprobe_process_event+0x2010>
    1a7c:      	ldr	x8, [sp, #0x58]
    1a80:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1a84:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1a88:      	mov	w25, #0x5efc            // =24316
    1a8c:      	ldr	x24, [x24]
    1a90:      	ldr	x22, [x22]
    1a94:      	ldr	x19, [sp, #0x10]
    1a98:      	cmp	w8, #0x3
    1a9c:      	b.ne	0x1590 <generic_kprobe_process_event+0x1230>
    1aa0:      	ldp	x8, x9, [sp, #0x38]
    1aa4:      	add	x24, x9, #0x90
    1aa8:      	and	w8, w8, #0xf
    1aac:      	add	x19, x24, x23
    1ab0:      	cmp	w8, #0x2
    1ab4:      	b.le	0x2a48 <generic_kprobe_process_event+0x26e8>
    1ab8:      	cmp	w8, #0x3
    1abc:      	b.eq	0x2c08 <generic_kprobe_process_event+0x28a8>
    1ac0:      	cmp	w8, #0x4
    1ac4:      	b.eq	0x2c10 <generic_kprobe_process_event+0x28b0>
    1ac8:      	cmp	w8, #0x5
    1acc:      	b.ne	0x2c68 <generic_kprobe_process_event+0x2908>
    1ad0:      	mov	w9, #0x5e70             // =24176
    1ad4:      	b	0x2c1c <generic_kprobe_process_event+0x28bc>
    1ad8:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1adc:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1ae0:      	cmp	w9, #0x1
    1ae4:      	ldr	x24, [x24]
    1ae8:      	ldr	x22, [x22]
    1aec:      	ldr	x19, [sp, #0x10]
    1af0:      	mov	w25, #0x5efc            // =24316
    1af4:      	b.eq	0x1b2c <generic_kprobe_process_event+0x17cc>
    1af8:      	ldr	x8, [sp, #0x58]
    1afc:      	cmp	w8, #0x4
    1b00:      	ldp	x11, x9, [sp, #0x28]
    1b04:      	mov	w10, #0x5ea0            // =24224
    1b08:      	b.ne	0x1598 <generic_kprobe_process_event+0x1238>
    1b0c:      	ldr	x0, [sp, #0x20]
    1b10:      	mov	w21, #0x8               // =8
    1b14:      	mov	w8, #0x4                // =4
    1b18:      	add	x9, sp, #0xf0
    1b1c:      	add	x2, sp, #0xf0
    1b20:      	mov	w1, #0x8                // =8
    1b24:      	blr	x8
    1b28:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    1b2c:      	ldr	x0, [sp, #0x20]
    1b30:      	add	x8, sp, #0xf0
    1b34:      	mov	w9, #0x4                // =4
    1b38:      	add	x2, sp, #0xf0
    1b3c:      	mov	w1, #0x4                // =4
    1b40:      	mov	w21, #0x4               // =4
    1b44:      	blr	x9
    1b48:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    1b4c:      	ldr	x0, [sp, #0x20]
    1b50:      	mov	w8, #0x2                // =2
    1b54:      	add	x9, sp, #0xf0
    1b58:      	mov	w10, #0x4               // =4
    1b5c:      	add	x2, sp, #0xf0
    1b60:      	mov	w1, #0x2                // =2
    1b64:      	mov	w21, #0x4               // =4
    1b68:      	blr	x10
    1b6c:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    1b70:      	cmp	w9, #0x27
    1b74:      	b.eq	0x2330 <generic_kprobe_process_event+0x1fd0>
    1b78:      	ldr	x8, [sp, #0x58]
    1b7c:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1b80:      	ldp	x11, x9, [sp, #0x28]
    1b84:      	mov	x24, x29
    1b88:      	mov	w25, #0x5efc            // =24316
    1b8c:      	mov	w10, #0x5ea0            // =24224
    1b90:      	mov	x19, x23
    1b94:      	ldr	x22, [x22]
    1b98:      	cmp	w8, #0x28
    1b9c:      	b.ne	0x1598 <generic_kprobe_process_event+0x1238>
    1ba0:      	ldr	x0, [sp, #0x20]
    1ba4:      	add	x8, sp, #0xf0
    1ba8:      	mov	w9, #0x4                // =4
    1bac:      	mov	w1, #0x2                // =2
    1bb0:      	ldr	x22, [x8]
    1bb4:      	mov	w8, #0x2                // =2
    1bb8:      	str	xzr, [x0]
    1bbc:      	stp	xzr, xzr, [x0, #0x8]
    1bc0:      	mov	x2, x22
    1bc4:      	blr	x9
    1bc8:      	tbnz	x0, #0x3f, 0x2aa8 <generic_kprobe_process_event+0x2748>
    1bcc:      	ldr	x8, [sp, #0x20]
    1bd0:      	ldrh	w8, [x8]
    1bd4:      	cmp	w8, #0xa
    1bd8:      	b.eq	0x2a60 <generic_kprobe_process_event+0x2700>
    1bdc:      	cmp	w8, #0x2
    1be0:      	b.ne	0x2a94 <generic_kprobe_process_event+0x2734>
    1be4:      	add	x2, x22, #0x4
    1be8:      	add	x8, sp, #0xa8
    1bec:      	mov	w9, #0x4                // =4
    1bf0:      	add	x0, sp, #0xa8
    1bf4:      	mov	w1, #0x4                // =4
    1bf8:      	mov	w21, #0x4               // =4
    1bfc:      	blr	x9
    1c00:      	ldr	w8, [sp, #0xa8]
    1c04:      	ldr	x9, [sp, #0x20]
    1c08:      	add	x2, x22, #0x2
    1c0c:      	add	x0, x9, #0x2
    1c10:      	str	x8, [x9, #0x8]
    1c14:      	mov	w8, #0x2                // =2
    1c18:      	b	0x2a8c <generic_kprobe_process_event+0x272c>
    1c1c:      	mov	w29, #0x7               // =7
    1c20:      	ldr	x11, [sp, #0x58]
    1c24:      	ldr	x12, [sp, #0x38]
    1c28:      	b	0xb74 <generic_kprobe_process_event+0x814>
    1c2c:      	ldr	x8, [sp, #0x58]
    1c30:      	cmp	w8, #0x2b
    1c34:      	b.eq	0x268c <generic_kprobe_process_event+0x232c>
    1c38:      	ldr	x8, [sp, #0x58]
    1c3c:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1c40:      	mov	x24, x29
    1c44:      	mov	w25, #0x5efc            // =24316
    1c48:      	ldr	x22, [x22]
    1c4c:      	ldr	x19, [sp, #0x10]
    1c50:      	cmp	w8, #0x29
    1c54:      	b.ne	0x1590 <generic_kprobe_process_event+0x1230>
    1c58:      	ldr	x8, [sp, #0x48]
    1c5c:      	mov	w9, #0x4                // =4
    1c60:      	add	x10, sp, #0xa8
    1c64:      	add	x0, sp, #0xa8
    1c68:      	mov	w1, #0x8                // =8
    1c6c:      	add	x2, x8, #0x18
    1c70:      	mov	w8, #0x8                // =8
    1c74:      	blr	x9
    1c78:      	ldr	x23, [sp, #0xa8]
    1c7c:      	cbz	x23, 0x2bbc <generic_kprobe_process_event+0x285c>
    1c80:      	ldr	x25, [sp, #0x20]
    1c84:      	add	x2, x23, #0x10
    1c88:      	mov	w24, #0x2               // =2
    1c8c:      	mov	w8, #0x4                // =4
    1c90:      	str	x23, [x25, #0x28]
    1c94:      	add	x0, x25, #0x26
    1c98:      	mov	w1, #0x2                // =2
    1c9c:      	mov	w21, #0x4               // =4
    1ca0:      	blr	x8
    1ca4:      	add	x0, x25, #0x3a
    1ca8:      	add	x2, x23, #0x12
    1cac:      	mov	w8, #0x1                // =1
    1cb0:      	mov	w9, #0x4                // =4
    1cb4:      	mov	w1, #0x1                // =1
    1cb8:      	blr	x9
    1cbc:      	add	x0, x25, #0x38
    1cc0:      	add	x2, x23, #0x21e
    1cc4:      	mov	w8, #0x4                // =4
    1cc8:      	mov	w1, #0x2                // =2
    1ccc:      	blr	x8
    1cd0:      	add	x0, x25, #0x24
    1cd4:      	add	x2, x23, #0x21c
    1cd8:      	mov	w8, #0x4                // =4
    1cdc:      	mov	w1, #0x2                // =2
    1ce0:      	blr	x8
    1ce4:      	add	x0, x25, #0x30
    1ce8:      	add	x2, x23, #0x214
    1cec:      	mov	w8, #0x4                // =4
    1cf0:      	mov	w1, #0x4                // =4
    1cf4:      	blr	x8
    1cf8:      	add	x0, x25, #0x34
    1cfc:      	add	x2, x23, #0x210
    1d00:      	mov	w1, #0x4                // =4
    1d04:      	blr	x21
    1d08:      	ldrh	w8, [x25, #0x26]
    1d0c:      	mov	x24, x25
    1d10:      	stp	xzr, xzr, [x25]
    1d14:      	cmp	w8, #0xa
    1d18:      	str	xzr, [x25, #0x18]
    1d1c:      	str	xzr, [x24, #0x10]!
    1d20:      	b.eq	0x2b4c <generic_kprobe_process_event+0x27ec>
    1d24:      	cmp	w8, #0x2
    1d28:      	b.ne	0x2b78 <generic_kprobe_process_event+0x2818>
    1d2c:      	ldr	x0, [sp, #0x20]
    1d30:      	add	x2, x23, #0x4
    1d34:      	mov	w8, #0x4                // =4
    1d38:      	mov	w1, #0x4                // =4
    1d3c:      	mov	w21, #0x4               // =4
    1d40:      	blr	x8
    1d44:      	mov	x0, x24
    1d48:      	mov	w1, #0x4                // =4
    1d4c:      	mov	x2, x23
    1d50:      	blr	x21
    1d54:      	b	0x2b78 <generic_kprobe_process_event+0x2818>
    1d58:      	cmp	w8, #0x1a
    1d5c:      	b.eq	0x271c <generic_kprobe_process_event+0x23bc>
    1d60:      	ldr	x8, [sp, #0x58]
    1d64:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1d68:      	mov	x24, x29
    1d6c:      	mov	w25, #0x5efc            // =24316
    1d70:      	ldr	x22, [x22]
    1d74:      	ldr	x19, [sp, #0x10]
    1d78:      	cmp	w8, #0x1b
    1d7c:      	b.ne	0x1590 <generic_kprobe_process_event+0x1230>
    1d80:      	ldr	x10, [sp, #0x20]
    1d84:      	ldr	x8, [sp, #0x48]
    1d88:      	mov	w9, #0x2d               // =45
    1d8c:      	mov	w1, #0x3f               // =63
    1d90:      	mov	x0, x10
    1d94:      	stp	xzr, xzr, [x10, #0x40]
    1d98:      	stp	xzr, xzr, [x10, #0x30]
    1d9c:      	stp	xzr, xzr, [x10, #0x20]
    1da0:      	str	xzr, [x10, #0x18]
    1da4:      	stp	xzr, xzr, [x10]
    1da8:      	add	x2, x8, #0x18
    1dac:      	mov	w8, #0x3f               // =63
    1db0:      	str	xzr, [x0, #0x10]!
    1db4:      	blr	x9
    1db8:      	tbnz	x0, #0x3f, 0x2968 <generic_kprobe_process_event+0x2608>
    1dbc:      	ldr	x8, [sp, #0x20]
    1dc0:      	mov	w9, #0x4                // =4
    1dc4:      	mov	w1, #0x8                // =8
    1dc8:      	add	x0, x8, #0x8
    1dcc:      	ldr	x8, [sp, #0x48]
    1dd0:      	add	x2, x8, #0x360
    1dd4:      	mov	w8, #0x8                // =8
    1dd8:      	blr	x9
    1ddc:      	mov	w21, #0x50              // =80
    1de0:      	b	0x1a50 <generic_kprobe_process_event+0x16f0>
    1de4:      	ldr	x8, [sp, #0x58]
    1de8:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1dec:      	ldp	x11, x9, [sp, #0x28]
    1df0:      	mov	x24, x29
    1df4:      	mov	w25, #0x5efc            // =24316
    1df8:      	mov	w10, #0x5ea0            // =24224
    1dfc:      	mov	x19, x23
    1e00:      	ldr	x22, [x22]
    1e04:      	cmp	w8, #0x26
    1e08:      	b.ne	0x1598 <generic_kprobe_process_event+0x1238>
    1e0c:      	add	x8, sp, #0xf0
    1e10:      	ldr	x9, [sp, #0x20]
    1e14:      	ldr	x8, [x8]
    1e18:      	add	x0, x9, #0x4
    1e1c:      	add	x2, x19, w8, uxth
    1e20:      	ubfx	w8, w8, #16, #12
    1e24:      	add	w1, w8, #0x1
    1e28:      	mov	w8, #0x2d               // =45
    1e2c:      	blr	x8
    1e30:      	b	0x2354 <generic_kprobe_process_event+0x1ff4>
    1e34:      	ldr	x8, [sp, #0x58]
    1e38:      	cmp	w8, #0x8
    1e3c:      	b.eq	0x23c8 <generic_kprobe_process_event+0x2068>
    1e40:      	ldr	x8, [sp, #0x58]
    1e44:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1e48:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1e4c:      	mov	w25, #0x5efc            // =24316
    1e50:      	ldr	x24, [x24]
    1e54:      	ldr	x22, [x22]
    1e58:      	ldr	x19, [sp, #0x10]
    1e5c:      	cmp	w8, #0x12
    1e60:      	b.ne	0x1590 <generic_kprobe_process_event+0x1230>
    1e64:      	ldp	x2, x8, [sp, #0x48]
    1e68:      	and	x21, x8, #0x3ff
    1e6c:      	ldr	x0, [sp, #0x20]
    1e70:      	mov	w8, #0x4                // =4
    1e74:      	mov	w1, w21
    1e78:      	blr	x8
    1e7c:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    1e80:      	ldr	x8, [sp, #0x58]
    1e84:      	cmp	w8, #0x13
    1e88:      	b.eq	0x2634 <generic_kprobe_process_event+0x22d4>
    1e8c:      	ldr	x8, [sp, #0x58]
    1e90:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1e94:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1e98:      	mov	w25, #0x5efc            // =24316
    1e9c:      	ldr	x24, [x24]
    1ea0:      	ldr	x22, [x22]
    1ea4:      	ldr	x19, [sp, #0x10]
    1ea8:      	cmp	w8, #0x14
    1eac:      	b.ne	0x1590 <generic_kprobe_process_event+0x1230>
    1eb0:      	ldr	x24, [sp, #0x48]
    1eb4:      	str	xzr, [sp, #0xa8]
    1eb8:      	mov	w10, #0x8               // =8
    1ebc:      	add	x8, sp, #0xa8
    1ec0:      	mov	w9, #0x4                // =4
    1ec4:      	add	x0, sp, #0xa8
    1ec8:      	mov	w1, #0x8                // =8
    1ecc:      	mov	w21, #0x4               // =4
    1ed0:      	add	x2, x24, #0x110
    1ed4:      	add	x23, x24, #0xd8
    1ed8:      	blr	x9
    1edc:      	ldr	x8, [sp, #0xa8]
    1ee0:      	mov	w9, #0x80               // =128
    1ee4:      	mov	w10, #0x2d              // =45
    1ee8:      	ldr	x29, [sp, #0x20]
    1eec:      	mov	w1, #0x80               // =128
    1ef0:      	mov	x0, x29
    1ef4:      	ldr	x2, [sp, #0xa8]
    1ef8:      	blr	x10
    1efc:      	add	x0, x29, #0x90
    1f00:      	mov	w8, #0x4                // =4
    1f04:      	mov	w1, #0x4                // =4
    1f08:      	mov	x2, x23
    1f0c:      	blr	x8
    1f10:      	add	x0, x29, #0x80
    1f14:      	add	x2, x24, #0xe0
    1f18:      	mov	w8, #0x4                // =4
    1f1c:      	mov	w23, #0x8               // =8
    1f20:      	mov	w1, #0x8                // =8
    1f24:      	blr	x8
    1f28:      	add	x0, x29, #0x88
    1f2c:      	add	x2, x24, #0x118
    1f30:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1f34:      	ldr	x24, [x24]
    1f38:      	mov	w1, #0x8                // =8
    1f3c:      	blr	x21
    1f40:      	mov	w21, #0x98              // =152
    1f44:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    1f48:      	add	x8, sp, #0xf0
    1f4c:      	mov	w9, #0x4                // =4
    1f50:      	add	x10, sp, #0x98
    1f54:      	ldr	x21, [x8]
    1f58:      	mov	w8, #0x1                // =1
    1f5c:      	add	x0, sp, #0x98
    1f60:      	mov	w1, #0x1                // =1
    1f64:      	mov	x2, x21
    1f68:      	blr	x9
    1f6c:      	ldrb	w8, [sp, #0x98]
    1f70:      	cmp	w8, #0x1
    1f74:      	b.ne	0x27fc <generic_kprobe_process_event+0x249c>
    1f78:      	add	x2, x21, #0x10
    1f7c:      	mov	w21, #0x8               // =8
    1f80:      	add	x8, sp, #0x100
    1f84:      	mov	w9, #0x4                // =4
    1f88:      	add	x0, sp, #0x100
    1f8c:      	mov	w1, #0x8                // =8
    1f90:      	mov	w24, #0x4               // =4
    1f94:      	blr	x9
    1f98:      	add	x25, sp, #0xf0
    1f9c:      	add	x8, sp, #0x80
    1fa0:      	mov	w9, #0x4                // =4
    1fa4:      	ldr	x2, [x25, #0x10]
    1fa8:      	add	x0, sp, #0x80
    1fac:      	mov	w1, #0x8                // =8
    1fb0:      	blr	x9
    1fb4:      	ldr	x8, [x25, #0x10]
    1fb8:      	add	x0, sp, #0xf8
    1fbc:      	mov	w1, #0x8                // =8
    1fc0:      	add	x2, x8, #0x8
    1fc4:      	add	x8, sp, #0xf8
    1fc8:      	blr	x24
    1fcc:      	ldr	x8, [sp, #0x80]
    1fd0:      	ldr	x25, [x25, #0x8]
    1fd4:      	str	x8, [sp, #0x48]
    1fd8:      	ldr	x8, [sp, #0x50]
    1fdc:      	add	x8, x8, #0x90
    1fe0:      	add	x9, x8, x23
    1fe4:      	str	x9, [sp, #0x58]
    1fe8:      	ldr	x9, [sp, #0x38]
    1fec:      	tbz	w9, #0x5, 0x2ae8 <generic_kprobe_process_event+0x2788>
    1ff0:      	cmp	x25, #0x1, lsl #12      // =0x1000
    1ff4:      	b.lo	0x2acc <generic_kprobe_process_event+0x276c>
    1ff8:      	ldr	x9, [sp, #0x58]
    1ffc:      	mov	w8, #0x1                // =1
    2000:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2004:      	add	x1, sp, #0xe8
    2008:      	str	w8, [x9]
    200c:      	str	wzr, [sp, #0xe8]
    2010:      	add	x9, sp, #0xe8
    2014:      	ldr	x0, [x0]
    2018:      	blr	x8
    201c:      	str	x0, [sp, #0x40]
    2020:      	cbz	x0, 0x2db4 <generic_kprobe_process_event+0x2a54>
    2024:      	ldr	x23, [sp, #0x40]
    2028:      	mov	w8, #0x18               // =24
    202c:      	str	w8, [x23]
    2030:      	mov	w8, #0xe                // =14
    2034:      	blr	x8
    2038:      	str	x0, [x23, #0x10]!
    203c:      	cmn	x0, #0x16
    2040:      	b.ne	0x2068 <generic_kprobe_process_event+0x1d08>
    2044:      	add	x2, x19, #0xe8
    2048:      	mov	w8, #0x8                // =8
    204c:      	mov	w9, #0x4                // =4
    2050:      	add	x10, sp, #0xa8
    2054:      	add	x0, sp, #0xa8
    2058:      	mov	w1, #0x8                // =8
    205c:      	blr	x9
    2060:      	ldr	x8, [sp, #0xa8]
    2064:      	str	x8, [x23]
    2068:      	mov	w8, #0x7d               // =125
    206c:      	blr	x8
    2070:      	ldr	x11, [sp, #0x40]
    2074:      	ldr	x10, [sp, #0x58]
    2078:      	mov	x21, xzr
    207c:      	str	x0, [x11, #0x18]
    2080:      	ldp	x8, x9, [x23]
    2084:      	mov	w23, #0xa               // =10
    2088:      	stur	x8, [x10, #0x14]
    208c:      	add	x8, x11, #0x20
    2090:      	stur	x9, [x10, #0x1c]
    2094:      	str	x8, [sp, #0x50]
    2098:      	subs	x8, x25, x21
    209c:      	b.mi	0x320c <generic_kprobe_process_event+0x2eac>
    20a0:      	ldp	x9, x0, [sp, #0x48]
    20a4:      	add	x2, x21, x9
    20a8:      	mov	w9, #0x7fe0             // =32736
    20ac:      	cmp	x8, x9
    20b0:      	csel	x24, x8, x9, lo
    20b4:      	mov	w8, #0x4                // =4
    20b8:      	mov	w1, w24
    20bc:      	blr	x8
    20c0:      	tbnz	w0, #0x1f, 0x20fc <generic_kprobe_process_event+0x1d9c>
    20c4:      	ldr	x3, [sp, #0x40]
    20c8:      	add	w4, w24, #0x20
    20cc:      	adrp	x1, 0x2000 <generic_kprobe_process_event+0x1ca0>
    20d0:      	mov	w8, #0x19               // =25
    20d4:      	str	w4, [x3, #0x4]
    20d8:      	mov	w9, #-0x1               // =-1
    20dc:      	mov	x0, x19
    20e0:      	mov	w2, #-0x1               // =-1
    20e4:      	ldr	x1, [x1]
    20e8:      	blr	x8
    20ec:      	sxtw	x8, w0
    20f0:      	tst	w0, #0x80000000
    20f4:      	csel	x8, x24, x8, eq
    20f8:      	b	0x2100 <generic_kprobe_process_event+0x1da0>
    20fc:      	sxtw	x8, w0
    2100:      	tbnz	w8, #0x1f, 0x3214 <generic_kprobe_process_event+0x2eb4>
    2104:      	and	x8, x8, #0x7fffffff
    2108:      	add	x21, x8, x21
    210c:      	cmp	x21, x25
    2110:      	b.eq	0x3260 <generic_kprobe_process_event+0x2f00>
    2114:      	subs	w23, w23, #0x1
    2118:      	b.ne	0x2098 <generic_kprobe_process_event+0x1d38>
    211c:      	b	0x35c4 <generic_kprobe_process_event+0x3264>
    2120:      	add	x8, sp, #0xf0
    2124:      	ldr	x21, [sp, #0x20]
    2128:      	mov	w1, #0x4                // =4
    212c:      	mov	w24, #0x4               // =4
    2130:      	ldr	x19, [x8]
    2134:      	mov	w8, #0x4                // =4
    2138:      	add	x0, x21, #0x28
    213c:      	add	x2, x19, #0x98
    2140:      	blr	x8
    2144:      	add	x0, x21, #0x2c
    2148:      	add	x2, x19, #0x70
    214c:      	mov	w8, #0x4                // =4
    2150:      	mov	w1, #0x4                // =4
    2154:      	blr	x8
    2158:      	add	x0, x21, #0x30
    215c:      	add	x2, x19, #0x90
    2160:      	mov	w8, #0x4                // =4
    2164:      	mov	w1, #0x4                // =4
    2168:      	blr	x8
    216c:      	add	x0, x21, #0x34
    2170:      	add	x2, x19, #0xa8
    2174:      	mov	w8, #0x4                // =4
    2178:      	mov	w1, #0x4                // =4
    217c:      	blr	x8
    2180:      	str	xzr, [sp, #0xa8]
    2184:      	add	x2, x19, #0xc8
    2188:      	mov	w8, #0x8                // =8
    218c:      	add	x9, sp, #0xa8
    2190:      	mov	w10, #0x4               // =4
    2194:      	add	x0, sp, #0xa8
    2198:      	mov	w1, #0x8                // =8
    219c:      	blr	x10
    21a0:      	add	x2, x19, #0xb8
    21a4:      	mov	w8, #0x2                // =2
    21a8:      	add	x9, sp, #0xf8
    21ac:      	mov	w10, #0x4               // =4
    21b0:      	add	x0, sp, #0xf8
    21b4:      	mov	w1, #0x2                // =2
    21b8:      	blr	x10
    21bc:      	ldr	x8, [sp, #0xa8]
    21c0:      	ldrh	w9, [sp, #0xf8]
    21c4:      	add	x0, sp, #0x94
    21c8:      	mov	w1, #0x1                // =1
    21cc:      	add	x23, x8, x9
    21d0:      	mov	w8, #0x1                // =1
    21d4:      	add	x9, sp, #0x94
    21d8:      	mov	x2, x23
    21dc:      	blr	x24
    21e0:      	ldrb	w8, [sp, #0x94]
    21e4:      	lsr	w8, w8, #4
    21e8:      	cmp	w8, #0x6
    21ec:      	b.eq	0x2824 <generic_kprobe_process_event+0x24c4>
    21f0:      	cmp	w8, #0x4
    21f4:      	b.ne	0x3acc <generic_kprobe_process_event+0x376c>
    21f8:      	add	x2, x23, #0x9
    21fc:      	mov	w8, #0x1                // =1
    2200:      	add	x9, sp, #0x98
    2204:      	mov	w10, #0x4               // =4
    2208:      	add	x0, sp, #0x98
    220c:      	mov	w1, #0x1                // =1
    2210:      	mov	w29, #0x4               // =4
    2214:      	blr	x10
    2218:      	ldr	x0, [sp, #0x20]
    221c:      	ldrb	w8, [sp, #0x98]
    2220:      	mov	w21, #0x2               // =2
    2224:      	add	x2, x23, #0xc
    2228:      	mov	w1, #0x4                // =4
    222c:      	mov	x24, x0
    2230:      	strh	w8, [x0, #0x24]
    2234:      	strh	w21, [x0, #0x26]
    2238:      	stp	xzr, xzr, [x0]
    223c:      	str	xzr, [x0, #0x18]
    2240:      	mov	w8, #0x4                // =4
    2244:      	str	xzr, [x24, #0x10]!
    2248:      	blr	x8
    224c:      	add	x2, x23, #0x10
    2250:      	mov	w8, #0x4                // =4
    2254:      	mov	x0, x24
    2258:      	mov	w1, #0x4                // =4
    225c:      	blr	x8
    2260:      	add	x2, x19, #0xb6
    2264:      	add	x8, sp, #0xe8
    2268:      	add	x0, sp, #0xe8
    226c:      	mov	w1, #0x2                // =2
    2270:      	blr	x29
    2274:      	ldrb	w23, [sp, #0x98]
    2278:      	b	0x3990 <generic_kprobe_process_event+0x3630>
    227c:      	str	xzr, [sp, #0xb0]
    2280:      	mov	w8, #0xe                // =14
    2284:      	blr	x8
    2288:      	lsr	x8, x0, #32
    228c:      	add	x9, sp, #0x100
    2290:      	add	x10, sp, #0xf0
    2294:      	str	x8, [sp, #0xa8]
    2298:      	mov	w8, #0x4                // =4
    229c:      	add	x0, sp, #0x100
    22a0:      	add	x2, sp, #0xf0
    22a4:      	mov	w1, #0x4                // =4
    22a8:      	blr	x8
    22ac:      	ldr	w8, [sp, #0x100]
    22b0:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    22b4:      	add	x9, sp, #0xa8
    22b8:      	add	x1, sp, #0xa8
    22bc:      	str	w8, [sp, #0xb0]
    22c0:      	mov	w8, #0x1                // =1
    22c4:      	ldr	x0, [x0]
    22c8:      	blr	x8
    22cc:      	cbz	x0, 0x281c <generic_kprobe_process_event+0x24bc>
    22d0:      	ldr	x25, [sp, #0x20]
    22d4:      	ldr	w21, [x0]
    22d8:      	add	x8, sp, #0x100
    22dc:      	mov	w9, #0x4                // =4
    22e0:      	mov	x23, x0
    22e4:      	add	x2, sp, #0x100
    22e8:      	mov	w1, #0x4                // =4
    22ec:      	mov	w24, #0x4               // =4
    22f0:      	mov	x0, x25
    22f4:      	blr	x9
    22f8:      	and	x21, x21, #0xfff
    22fc:      	add	x0, x25, #0x4
    2300:      	mov	w8, #0x4                // =4
    2304:      	mov	x2, x23
    2308:      	add	x1, x21, #0x4
    230c:      	blr	x8
    2310:      	add	w21, w21, #0x8
    2314:      	mov	w1, #0x4                // =4
    2318:      	add	x8, x21, x23
    231c:      	add	x0, x25, x21
    2320:      	sub	x2, x8, #0x4
    2324:      	blr	x24
    2328:      	add	x21, x21, #0x4
    232c:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    2330:      	add	x8, sp, #0xf0
    2334:      	mov	w9, #0x2d               // =45
    2338:      	mov	w1, #0x11               // =17
    233c:      	ldr	x8, [x8]
    2340:      	add	x2, x8, #0x118
    2344:      	ldr	x8, [sp, #0x20]
    2348:      	add	x0, x8, #0x4
    234c:      	mov	w8, #0x11               // =17
    2350:      	blr	x9
    2354:      	mov	x21, x0
    2358:      	tbnz	x0, #0x3f, 0x2aac <generic_kprobe_process_event+0x274c>
    235c:      	ldr	x9, [sp, #0x20]
    2360:      	sub	w8, w21, #0x1
    2364:      	add	x21, x21, #0x3
    2368:      	str	w8, [x9]
    236c:      	b	0x2aac <generic_kprobe_process_event+0x274c>
    2370:      	ldr	x8, [sp, #0x40]
    2374:      	add	x21, x8, #0x90
    2378:      	add	x8, sp, #0xf0
    237c:      	str	xzr, [x8]
    2380:      	ldr	x8, [sp, #0x38]
    2384:      	add	x19, x21, x23
    2388:      	tbnz	w8, #0x4, 0x2970 <generic_kprobe_process_event+0x2610>
    238c:      	ldr	x9, [sp, #0x38]
    2390:      	mov	x8, xzr
    2394:      	and	x23, x9, #0xffffffff
    2398:      	ldr	x9, [sp, #0x50]
    239c:      	and	w9, w9, #0xf
    23a0:      	cmp	w9, #0x2
    23a4:      	b.le	0x2b34 <generic_kprobe_process_event+0x27d4>
    23a8:      	cmp	w9, #0x3
    23ac:      	b.eq	0x2dbc <generic_kprobe_process_event+0x2a5c>
    23b0:      	cmp	w9, #0x4
    23b4:      	b.eq	0x2dc4 <generic_kprobe_process_event+0x2a64>
    23b8:      	cmp	w9, #0x5
    23bc:      	b.ne	0x2ddc <generic_kprobe_process_event+0x2a7c>
    23c0:      	mov	w9, #0x5e70             // =24176
    23c4:      	b	0x2dd0 <generic_kprobe_process_event+0x2a70>
    23c8:      	ldr	x29, [sp, #0x48]
    23cc:      	ldr	x25, [sp, #0x20]
    23d0:      	mov	w8, #0x4                // =4
    23d4:      	mov	w1, #0x4                // =4
    23d8:      	mov	w21, #0x4               // =4
    23dc:      	add	x2, x29, #0x8
    23e0:      	mov	x0, x25
    23e4:      	add	x23, x25, #0x28
    23e8:      	add	x19, x25, #0x40
    23ec:      	blr	x8
    23f0:      	add	x0, x25, #0x4
    23f4:      	add	x2, x29, #0xc
    23f8:      	mov	w8, #0x4                // =4
    23fc:      	mov	w1, #0x4                // =4
    2400:      	blr	x8
    2404:      	add	x0, x25, #0x10
    2408:      	add	x2, x29, #0x18
    240c:      	mov	w8, #0x4                // =4
    2410:      	mov	w1, #0x4                // =4
    2414:      	blr	x8
    2418:      	add	x0, x25, #0x14
    241c:      	add	x2, x29, #0x1c
    2420:      	mov	w8, #0x4                // =4
    2424:      	mov	w1, #0x4                // =4
    2428:      	blr	x8
    242c:      	add	x0, x25, #0x8
    2430:      	add	x2, x29, #0x10
    2434:      	mov	w8, #0x4                // =4
    2438:      	mov	w1, #0x4                // =4
    243c:      	blr	x8
    2440:      	add	x0, x25, #0xc
    2444:      	add	x2, x29, #0x14
    2448:      	mov	w8, #0x4                // =4
    244c:      	mov	w1, #0x4                // =4
    2450:      	blr	x8
    2454:      	add	x0, x25, #0x18
    2458:      	add	x2, x29, #0x20
    245c:      	mov	w8, #0x4                // =4
    2460:      	mov	w1, #0x4                // =4
    2464:      	blr	x8
    2468:      	add	x0, x25, #0x1c
    246c:      	add	x2, x29, #0x24
    2470:      	mov	w8, #0x4                // =4
    2474:      	mov	w1, #0x4                // =4
    2478:      	blr	x8
    247c:      	str	wzr, [x25, #0x24]
    2480:      	add	x0, x25, #0x20
    2484:      	add	x2, x29, #0x28
    2488:      	mov	w8, #0x4                // =4
    248c:      	mov	w1, #0x4                // =4
    2490:      	blr	x8
    2494:      	add	x0, x25, #0x30
    2498:      	add	x2, x29, #0x40
    249c:      	mov	w24, #0x8               // =8
    24a0:      	mov	w8, #0x4                // =4
    24a4:      	mov	w1, #0x8                // =8
    24a8:      	blr	x8
    24ac:      	add	x0, x25, #0x38
    24b0:      	add	x2, x29, #0x30
    24b4:      	mov	w8, #0x4                // =4
    24b8:      	mov	w1, #0x8                // =8
    24bc:      	blr	x8
    24c0:      	add	x2, x29, #0x38
    24c4:      	mov	w8, #0x4                // =4
    24c8:      	mov	x0, x23
    24cc:      	mov	w1, #0x8                // =8
    24d0:      	blr	x8
    24d4:      	add	x2, x29, #0x90
    24d8:      	add	x8, sp, #0xa8
    24dc:      	mov	w9, #0x4                // =4
    24e0:      	add	x0, sp, #0xa8
    24e4:      	mov	w1, #0x8                // =8
    24e8:      	blr	x9
    24ec:      	ldr	x23, [sp, #0xa8]
    24f0:      	mov	w8, #0x4                // =4
    24f4:      	mov	x0, x19
    24f8:      	mov	w1, #0x4                // =4
    24fc:      	add	x2, x23, #0xc8
    2500:      	blr	x8
    2504:      	add	x0, x25, #0x44
    2508:      	add	x2, x23, #0xcc
    250c:      	mov	w8, #0x4                // =4
    2510:      	mov	w1, #0x4                // =4
    2514:      	blr	x8
    2518:      	add	x0, x25, #0x48
    251c:      	add	x2, x23, #0xd0
    2520:      	mov	w8, #0x4                // =4
    2524:      	mov	w1, #0x4                // =4
    2528:      	blr	x8
    252c:      	add	x0, x25, #0x4c
    2530:      	add	x2, x23, #0x158
    2534:      	mov	w1, #0x4                // =4
    2538:      	blr	x21
    253c:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2540:      	mov	w21, #0x50              // =80
    2544:      	ldr	x24, [x24]
    2548:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    254c:      	ldr	x24, [sp, #0x48]
    2550:      	ldr	x23, [sp, #0x20]
    2554:      	mov	w8, #0x4                // =4
    2558:      	mov	w1, #0x4                // =4
    255c:      	mov	w21, #0x4               // =4
    2560:      	add	x2, x24, #0xc8
    2564:      	mov	x0, x23
    2568:      	blr	x8
    256c:      	add	x0, x23, #0x4
    2570:      	add	x2, x24, #0xcc
    2574:      	mov	w8, #0x4                // =4
    2578:      	mov	w1, #0x4                // =4
    257c:      	blr	x8
    2580:      	add	x0, x23, #0x8
    2584:      	add	x2, x24, #0xd0
    2588:      	mov	w8, #0x4                // =4
    258c:      	mov	w1, #0x4                // =4
    2590:      	blr	x8
    2594:      	add	x0, x23, #0xc
    2598:      	add	x2, x24, #0x158
    259c:      	mov	w1, #0x4                // =4
    25a0:      	blr	x21
    25a4:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    25a8:      	mov	w21, #0x10              // =16
    25ac:      	ldr	x24, [x24]
    25b0:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    25b4:      	ldr	x24, [sp, #0x48]
    25b8:      	ldr	x23, [sp, #0x20]
    25bc:      	mov	w8, #0x4                // =4
    25c0:      	mov	w1, #0x4                // =4
    25c4:      	mov	w21, #0x4               // =4
    25c8:      	add	x2, x24, #0x38
    25cc:      	mov	x0, x23
    25d0:      	blr	x8
    25d4:      	add	x0, x23, #0x4
    25d8:      	add	x2, x24, #0x3c
    25dc:      	mov	w8, #0x4                // =4
    25e0:      	mov	w1, #0x4                // =4
    25e4:      	blr	x8
    25e8:      	add	x0, x23, #0x8
    25ec:      	add	x2, x24, #0x40
    25f0:      	mov	w8, #0x4                // =4
    25f4:      	mov	w1, #0x4                // =4
    25f8:      	blr	x8
    25fc:      	add	x0, x23, #0xc
    2600:      	add	x2, x24, #0x44
    2604:      	mov	w8, #0x4                // =4
    2608:      	mov	w1, #0x4                // =4
    260c:      	blr	x8
    2610:      	add	x0, x23, #0x10
    2614:      	add	x2, x24, #0x80
    2618:      	mov	w8, #0x10               // =16
    261c:      	mov	w1, #0x10               // =16
    2620:      	blr	x21
    2624:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2628:      	mov	w21, #0x20              // =32
    262c:      	ldr	x24, [x24]
    2630:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    2634:      	ldr	x23, [sp, #0x20]
    2638:      	ldr	x24, [sp, #0x48]
    263c:      	mov	w8, #0x4                // =4
    2640:      	mov	w1, #0x4                // =4
    2644:      	mov	w21, #0x4               // =4
    2648:      	mov	x0, x23
    264c:      	mov	x2, x24
    2650:      	blr	x8
    2654:      	add	x0, x23, #0x4
    2658:      	add	x2, x24, #0x4
    265c:      	mov	w8, #0x4                // =4
    2660:      	mov	w1, #0x4                // =4
    2664:      	blr	x8
    2668:      	add	x0, x23, #0x8
    266c:      	add	x2, x24, #0x30
    2670:      	mov	w8, #0x10               // =16
    2674:      	mov	w1, #0x10               // =16
    2678:      	blr	x21
    267c:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2680:      	mov	w21, #0x18              // =24
    2684:      	ldr	x24, [x24]
    2688:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    268c:      	ldr	x24, [sp, #0x48]
    2690:      	add	x8, sp, #0xa8
    2694:      	mov	w9, #0x4                // =4
    2698:      	add	x0, sp, #0xa8
    269c:      	mov	w1, #0x4                // =4
    26a0:      	mov	w21, #0x4               // =4
    26a4:      	add	x2, x24, #0x4
    26a8:      	blr	x9
    26ac:      	ldr	w8, [sp, #0xa8]
    26b0:      	ldr	x23, [sp, #0x20]
    26b4:      	add	x2, x24, #0xc
    26b8:      	add	x0, sp, #0xa8
    26bc:      	mov	w1, #0x4                // =4
    26c0:      	str	w8, [x23]
    26c4:      	add	x8, sp, #0xa8
    26c8:      	blr	x21
    26cc:      	ldr	w8, [sp, #0xa8]
    26d0:      	add	x2, x24, #0x50
    26d4:      	add	x9, sp, #0xa8
    26d8:      	mov	w10, #0x2d              // =45
    26dc:      	str	w8, [x23, #0x4]
    26e0:      	mov	w8, #0x8                // =8
    26e4:      	add	x0, sp, #0xa8
    26e8:      	mov	w1, #0x8                // =8
    26ec:      	mov	w21, #0x2d              // =45
    26f0:      	blr	x10
    26f4:      	ldr	x8, [sp, #0xa8]
    26f8:      	add	x0, x23, #0x8
    26fc:      	mov	w9, #0x10               // =16
    2700:      	mov	w1, #0x10               // =16
    2704:      	add	x8, x8, #0x3f8
    2708:      	ldr	x8, [sp, #0xa8]
    270c:      	add	x2, x8, #0x3f8
    2710:      	blr	x21
    2714:      	mov	w21, #0x18              // =24
    2718:      	b	0x1a50 <generic_kprobe_process_event+0x16f0>
    271c:      	ldr	x11, [sp, #0x20]
    2720:      	ldr	x2, [sp, #0x48]
    2724:      	mov	w8, #0x8                // =8
    2728:      	mov	w9, #0x4                // =4
    272c:      	add	x10, sp, #0xa8
    2730:      	add	x0, sp, #0xa8
    2734:      	mov	w1, #0x8                // =8
    2738:      	stp	xzr, xzr, [x11, #0x40]
    273c:      	stp	xzr, xzr, [x11, #0x30]
    2740:      	stp	xzr, xzr, [x11, #0x20]
    2744:      	stp	xzr, xzr, [x11, #0x10]
    2748:      	stp	xzr, xzr, [x11]
    274c:      	blr	x9
    2750:      	mov	x21, xzr
    2754:      	cbnz	x0, 0x1a50 <generic_kprobe_process_event+0x16f0>
    2758:      	ldr	x8, [sp, #0x20]
    275c:      	mov	w9, #0x3f               // =63
    2760:      	mov	w10, #0x2d              // =45
    2764:      	mov	w1, #0x3f               // =63
    2768:      	add	x0, x8, #0x10
    276c:      	ldr	x8, [sp, #0xa8]
    2770:      	ldr	x2, [sp, #0xa8]
    2774:      	blr	x10
    2778:      	tbnz	x0, #0x3f, 0x2968 <generic_kprobe_process_event+0x2608>
    277c:      	ldr	x24, [sp, #0x48]
    2780:      	mov	w21, #0x8               // =8
    2784:      	add	x8, sp, #0x100
    2788:      	mov	w9, #0x4                // =4
    278c:      	add	x0, sp, #0x100
    2790:      	mov	w1, #0x8                // =8
    2794:      	mov	w23, #0x4               // =4
    2798:      	add	x2, x24, #0x8
    279c:      	blr	x9
    27a0:      	ldr	x8, [sp, #0x20]
    27a4:      	add	x10, sp, #0xf0
    27a8:      	mov	w9, #0x4                // =4
    27ac:      	mov	w1, #0x8                // =8
    27b0:      	add	x0, x8, #0x8
    27b4:      	ldr	x8, [x10, #0x10]
    27b8:      	add	x8, x8, #0x360
    27bc:      	ldr	x8, [x10, #0x10]
    27c0:      	add	x2, x8, #0x360
    27c4:      	blr	x9
    27c8:      	add	x2, x24, #0x58
    27cc:      	add	x8, sp, #0x100
    27d0:      	add	x0, sp, #0x100
    27d4:      	mov	w1, #0x4                // =4
    27d8:      	blr	x23
    27dc:      	cbnz	x0, 0x27f4 <generic_kprobe_process_event+0x2494>
    27e0:      	ldr	w8, [sp, #0x100]
    27e4:      	ldr	x9, [sp, #0x20]
    27e8:      	cmp	w8, #0x0
    27ec:      	cset	w8, ne
    27f0:      	str	w8, [x9]
    27f4:      	mov	w21, #0x50              // =80
    27f8:      	b	0x1a50 <generic_kprobe_process_event+0x16f0>
    27fc:      	ldr	x8, [sp, #0x50]
    2800:      	mov	w21, #0x8               // =8
    2804:      	add	x8, x8, x23
    2808:      	str	xzr, [x8, #0x90]
    280c:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    2810:      	mov	w29, #0x9               // =9
    2814:      	mov	w25, #0x5efc            // =24316
    2818:      	b	0x1c20 <generic_kprobe_process_event+0x18c0>
    281c:      	mov	x21, #-0x1              // =-1
    2820:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    2824:      	str	wzr, [sp, #0x100]
    2828:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    282c:      	ldr	x21, [sp, #0xa8]
    2830:      	mov	w8, #0x1                // =1
    2834:      	add	x9, sp, #0x100
    2838:      	add	x1, sp, #0x100
    283c:      	ldrh	w23, [sp, #0xf8]
    2840:      	ldr	x0, [x0]
    2844:      	add	x22, x21, x23
    2848:      	blr	x8
    284c:      	cbz	x0, 0x394c <generic_kprobe_process_event+0x35ec>
    2850:      	mov	w8, #0xff               // =255
    2854:      	strh	w23, [x0]
    2858:      	strb	wzr, [x0, #0x7]
    285c:      	add	x25, x0, #0x6
    2860:      	add	x2, x22, #0x6
    2864:      	mov	w9, #0x4                // =4
    2868:      	strb	w8, [x0, #0x5]
    286c:      	mov	w8, #0x1                // =1
    2870:      	mov	x24, x0
    2874:      	mov	x0, x25
    2878:      	mov	w1, #0x1                // =1
    287c:      	blr	x9
    2880:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    2884:      	ldrb	w8, [x24, #0x5]
    2888:      	cmp	w8, #0x32
    288c:      	b.gt	0x2d5c <generic_kprobe_process_event+0x29fc>
    2890:      	cbz	w8, 0x2da8 <generic_kprobe_process_event+0x2a48>
    2894:      	cmp	w8, #0x2b
    2898:      	b.eq	0x2da8 <generic_kprobe_process_event+0x2a48>
    289c:      	cmp	w8, #0x2c
    28a0:      	b.ne	0x3328 <generic_kprobe_process_event+0x2fc8>
    28a4:      	mov	w8, #0x8                // =8
    28a8:      	b	0x3274 <generic_kprobe_process_event+0x2f14>
    28ac:      	ldr	x0, [sp, #0x20]
    28b0:      	add	x2, x23, #0x48
    28b4:      	mov	w21, #0x10              // =16
    28b8:      	mov	w8, #0x4                // =4
    28bc:      	mov	w1, #0x10               // =16
    28c0:      	mov	w29, #0x4               // =4
    28c4:      	blr	x8
    28c8:      	add	x2, x23, #0x38
    28cc:      	mov	x0, x24
    28d0:      	mov	w1, #0x10               // =16
    28d4:      	blr	x29
    28d8:      	ldr	x25, [sp, #0x20]
    28dc:      	add	x2, x23, #0xe
    28e0:      	mov	w21, #0x2               // =2
    28e4:      	mov	w8, #0x4                // =4
    28e8:      	mov	w1, #0x2                // =2
    28ec:      	add	x24, x23, #0xc
    28f0:      	mov	w23, #0x4               // =4
    28f4:      	add	x0, x25, #0x20
    28f8:      	blr	x8
    28fc:      	add	x0, x25, #0x22
    2900:      	mov	w1, #0x2                // =2
    2904:      	mov	x2, x24
    2908:      	blr	x23
    290c:      	ldrh	w8, [x25, #0x22]
    2910:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2914:      	add	x9, sp, #0xa8
    2918:      	add	x1, sp, #0xa8
    291c:      	rev	w8, w8
    2920:      	lsr	w8, w8, #16
    2924:      	strh	w8, [x25, #0x22]
    2928:      	add	x8, sp, #0xf0
    292c:      	ldr	x8, [x8]
    2930:      	str	x8, [sp, #0xa8]
    2934:      	mov	w8, #0x1                // =1
    2938:      	ldr	x0, [x0]
    293c:      	blr	x8
    2940:      	cbz	x0, 0x3acc <generic_kprobe_process_event+0x376c>
    2944:      	ldr	w8, [x0]
    2948:      	ldr	x9, [sp, #0x50]
    294c:      	mov	w21, #0x40              // =64
    2950:      	str	w8, [x9, #0x10]
    2954:      	ldr	x8, [x0, #0x8]
    2958:      	str	x8, [x9, #0x18]
    295c:      	ldr	w8, [x0, #0x4]
    2960:      	str	w8, [x9, #0x7c]
    2964:      	b	0x3ad0 <generic_kprobe_process_event+0x3770>
    2968:      	mov	x21, xzr
    296c:      	b	0x1a50 <generic_kprobe_process_event+0x16f0>
    2970:      	mov	w8, #0xe                // =14
    2974:      	blr	x8
    2978:      	cmn	x0, #0x16
    297c:      	b.ne	0x29a4 <generic_kprobe_process_event+0x2644>
    2980:      	ldr	x8, [sp, #0x10]
    2984:      	mov	w9, #0x4                // =4
    2988:      	add	x10, sp, #0xa8
    298c:      	add	x0, sp, #0xa8
    2990:      	mov	w1, #0x8                // =8
    2994:      	add	x2, x8, #0xe8
    2998:      	mov	w8, #0x8                // =8
    299c:      	blr	x9
    29a0:      	ldr	x0, [sp, #0xa8]
    29a4:      	ldp	x11, x8, [sp, #0x40]
    29a8:      	mov	x3, xzr
    29ac:      	add	x1, sp, #0x100
    29b0:      	add	x2, sp, #0xa8
    29b4:      	ldr	x9, [x11, #0x60]
    29b8:      	ldr	x10, [x11, #0x8]
    29bc:      	str	xzr, [sp, #0xb8]
    29c0:      	stp	x10, x8, [sp, #0xa8]
    29c4:      	add	x8, sp, #0xf0
    29c8:      	add	x10, sp, #0xa8
    29cc:      	stp	x9, x0, [x8, #0x10]
    29d0:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    29d4:      	mov	w8, #0x2                // =2
    29d8:      	add	x9, sp, #0x100
    29dc:      	ldr	x0, [x0]
    29e0:      	blr	x8
    29e4:      	cbz	x0, 0x2da0 <generic_kprobe_process_event+0x2a40>
    29e8:      	neg	w8, w0
    29ec:      	adrp	x23, 0x2000 <generic_kprobe_process_event+0x1ca0>
    29f0:      	mov	w9, #0x1                // =1
    29f4:      	strh	w8, [sp, #0x80]
    29f8:      	mov	w8, #0x5                // =5
    29fc:      	add	x1, sp, #0x80
    2a00:      	mov	w21, #0x1               // =1
    2a04:      	strh	w8, [sp, #0x82]
    2a08:      	mov	x8, #0x46               // =70
    2a0c:      	movk	x8, #0x2, lsl #32
    2a10:      	stur	x8, [sp, #0x84]
    2a14:      	add	x8, sp, #0x80
    2a18:      	ldr	x23, [x23]
    2a1c:      	mov	x0, x23
    2a20:      	blr	x9
    2a24:      	cbnz	x0, 0x2d30 <generic_kprobe_process_event+0x29d0>
    2a28:      	str	w21, [sp, #0xe8]
    2a2c:      	mov	x3, xzr
    2a30:      	mov	w8, #0x2                // =2
    2a34:      	add	x9, sp, #0x80
    2a38:      	add	x10, sp, #0xe8
    2a3c:      	add	x1, sp, #0x80
    2a40:      	add	x2, sp, #0xe8
    2a44:      	b	0x2d98 <generic_kprobe_process_event+0x2a38>
    2a48:      	cmp	w8, #0x1
    2a4c:      	b.eq	0x2c18 <generic_kprobe_process_event+0x28b8>
    2a50:      	cmp	w8, #0x2
    2a54:      	b.ne	0x2c68 <generic_kprobe_process_event+0x2908>
    2a58:      	mov	w9, #0x5e58             // =24152
    2a5c:      	b	0x2c1c <generic_kprobe_process_event+0x28bc>
    2a60:      	ldr	x24, [sp, #0x20]
    2a64:      	add	x2, x22, #0x8
    2a68:      	mov	w8, #0x10               // =16
    2a6c:      	mov	w9, #0x4                // =4
    2a70:      	mov	w1, #0x10               // =16
    2a74:      	mov	w21, #0x4               // =4
    2a78:      	add	x0, x24, #0x8
    2a7c:      	blr	x9
    2a80:      	add	x0, x24, #0x2
    2a84:      	add	x2, x22, #0x2
    2a88:      	mov	w8, #0x2                // =2
    2a8c:      	mov	w1, #0x2                // =2
    2a90:      	blr	x21
    2a94:      	ldr	x9, [sp, #0x20]
    2a98:      	ldrh	w8, [x9, #0x2]
    2a9c:      	rev	w8, w8
    2aa0:      	lsr	w8, w8, #16
    2aa4:      	strh	w8, [x9, #0x2]
    2aa8:      	mov	w21, #0x18              // =24
    2aac:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2ab0:      	ldp	x11, x9, [sp, #0x28]
    2ab4:      	mov	x24, x29
    2ab8:      	mov	w25, #0x5efc            // =24316
    2abc:      	mov	w10, #0x5ea0            // =24224
    2ac0:      	ldr	x22, [x22]
    2ac4:      	mov	x19, x23
    2ac8:      	b	0x1598 <generic_kprobe_process_event+0x1238>
    2acc:      	ldr	x9, [sp, #0x58]
    2ad0:      	mov	w21, #0xc               // =12
    2ad4:      	str	wzr, [x9]
    2ad8:      	ldr	x9, [sp, #0x118]
    2adc:      	add	x8, x8, x9
    2ae0:      	add	x8, x8, #0x8
    2ae4:      	str	x8, [sp, #0x58]
    2ae8:      	cmp	x25, #0xfff
    2aec:      	mov	w8, #0xfff              // =4095
    2af0:      	ldr	x2, [sp, #0x48]
    2af4:      	csel	x24, x25, x8, lo
    2af8:      	ldr	x8, [sp, #0x58]
    2afc:      	mov	w1, w24
    2b00:      	add	x0, x8, #0x8
    2b04:      	mov	w8, #0x4                // =4
    2b08:      	blr	x8
    2b0c:      	tbnz	w0, #0x1f, 0x2b20 <generic_kprobe_process_event+0x27c0>
    2b10:      	ldr	x8, [sp, #0x58]
    2b14:      	add	x21, x21, x24
    2b18:      	stp	w25, w24, [x8]
    2b1c:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    2b20:      	ldr	x9, [sp, #0x58]
    2b24:      	mov	w8, #-0x2               // =-2
    2b28:      	mov	w21, #0x4               // =4
    2b2c:      	str	w8, [x9]
    2b30:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    2b34:      	cmp	w9, #0x1
    2b38:      	b.eq	0x2dcc <generic_kprobe_process_event+0x2a6c>
    2b3c:      	cmp	w9, #0x2
    2b40:      	b.ne	0x2ddc <generic_kprobe_process_event+0x2a7c>
    2b44:      	mov	w9, #0x5e58             // =24152
    2b48:      	b	0x2dd0 <generic_kprobe_process_event+0x2a70>
    2b4c:      	ldr	x0, [sp, #0x20]
    2b50:      	add	x2, x23, #0x48
    2b54:      	mov	w21, #0x10              // =16
    2b58:      	mov	w8, #0x4                // =4
    2b5c:      	mov	w1, #0x10               // =16
    2b60:      	mov	w25, #0x4               // =4
    2b64:      	blr	x8
    2b68:      	add	x2, x23, #0x38
    2b6c:      	mov	x0, x24
    2b70:      	mov	w1, #0x10               // =16
    2b74:      	blr	x25
    2b78:      	ldr	x25, [sp, #0x20]
    2b7c:      	add	x2, x23, #0xe
    2b80:      	mov	w21, #0x2               // =2
    2b84:      	mov	w8, #0x4                // =4
    2b88:      	mov	w1, #0x2                // =2
    2b8c:      	add	x24, x23, #0xc
    2b90:      	mov	w23, #0x4               // =4
    2b94:      	add	x0, x25, #0x20
    2b98:      	blr	x8
    2b9c:      	add	x0, x25, #0x22
    2ba0:      	mov	w1, #0x2                // =2
    2ba4:      	mov	x2, x24
    2ba8:      	blr	x23
    2bac:      	ldrh	w8, [x25, #0x22]
    2bb0:      	rev	w8, w8
    2bb4:      	lsr	w8, w8, #16
    2bb8:      	strh	w8, [x25, #0x22]
    2bbc:      	ldr	x8, [sp, #0x20]
    2bc0:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2bc4:      	add	x9, sp, #0xa8
    2bc8:      	add	x1, sp, #0xa8
    2bcc:      	ldr	x8, [x8, #0x28]
    2bd0:      	str	x8, [sp, #0xa8]
    2bd4:      	mov	w8, #0x1                // =1
    2bd8:      	ldr	x0, [x0]
    2bdc:      	blr	x8
    2be0:      	cbz	x0, 0x2c00 <generic_kprobe_process_event+0x28a0>
    2be4:      	ldr	w8, [x0]
    2be8:      	ldr	x9, [sp, #0x40]
    2bec:      	str	w8, [x9, #0x10]
    2bf0:      	ldr	x8, [x0, #0x8]
    2bf4:      	str	x8, [x9, #0x18]
    2bf8:      	ldr	w8, [x0, #0x4]
    2bfc:      	str	w8, [x9, #0x7c]
    2c00:      	mov	w21, #0x40              // =64
    2c04:      	b	0x1a50 <generic_kprobe_process_event+0x16f0>
    2c08:      	mov	w9, #0x5e60             // =24160
    2c0c:      	b	0x2c1c <generic_kprobe_process_event+0x28bc>
    2c10:      	mov	w9, #0x5e68             // =24168
    2c14:      	b	0x2c1c <generic_kprobe_process_event+0x28bc>
    2c18:      	mov	w9, #0x5e50             // =24144
    2c1c:      	ldr	x8, [sp, #0x40]
    2c20:      	add	x8, x8, x9
    2c24:      	ldr	x23, [x8]
    2c28:      	ldr	x8, [sp, #0x50]
    2c2c:      	tbnz	w8, #0x4, 0x2c78 <generic_kprobe_process_event+0x2918>
    2c30:      	cbz	x23, 0x2d44 <generic_kprobe_process_event+0x29e4>
    2c34:      	ldr	x2, [sp, #0x48]
    2c38:      	mov	w8, #0x10               // =16
    2c3c:      	mov	w9, #0x4                // =4
    2c40:      	add	x10, sp, #0xa8
    2c44:      	add	x0, sp, #0xa8
    2c48:      	mov	w1, #0x10               // =16
    2c4c:      	blr	x9
    2c50:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    2c54:      	ldr	x22, [sp, #0xb0]
    2c58:      	cmp	x22, #0xffe
    2c5c:      	b.ls	0x2f80 <generic_kprobe_process_event+0x2c20>
    2c60:      	mov	w8, #-0x3               // =-3
    2c64:      	b	0x31e8 <generic_kprobe_process_event+0x2e88>
    2c68:      	ldr	x8, [sp, #0x50]
    2c6c:      	mov	x23, xzr
    2c70:      	mov	x22, xzr
    2c74:      	tbz	w8, #0x4, 0x2d48 <generic_kprobe_process_event+0x29e8>
    2c78:      	mov	w8, #0xe                // =14
    2c7c:      	blr	x8
    2c80:      	cmn	x0, #0x16
    2c84:      	b.ne	0x2cac <generic_kprobe_process_event+0x294c>
    2c88:      	ldr	x8, [sp, #0x10]
    2c8c:      	mov	w9, #0x4                // =4
    2c90:      	add	x10, sp, #0xa8
    2c94:      	add	x0, sp, #0xa8
    2c98:      	mov	w1, #0x8                // =8
    2c9c:      	add	x2, x8, #0xe8
    2ca0:      	mov	w8, #0x8                // =8
    2ca4:      	blr	x9
    2ca8:      	ldr	x0, [sp, #0xa8]
    2cac:      	ldp	x11, x8, [sp, #0x40]
    2cb0:      	mov	x3, xzr
    2cb4:      	add	x1, sp, #0x100
    2cb8:      	add	x2, sp, #0xa8
    2cbc:      	ldr	x9, [x11, #0x60]
    2cc0:      	ldr	x10, [x11, #0x8]
    2cc4:      	str	x23, [sp, #0xb8]
    2cc8:      	stp	x10, x8, [sp, #0xa8]
    2ccc:      	add	x8, sp, #0xf0
    2cd0:      	add	x10, sp, #0xa8
    2cd4:      	stp	x9, x0, [x8, #0x10]
    2cd8:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2cdc:      	mov	w8, #0x2                // =2
    2ce0:      	add	x9, sp, #0x100
    2ce4:      	ldr	x0, [x0]
    2ce8:      	blr	x8
    2cec:      	cbz	x0, 0x2da0 <generic_kprobe_process_event+0x2a40>
    2cf0:      	neg	w8, w0
    2cf4:      	adrp	x23, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2cf8:      	mov	w9, #0x1                // =1
    2cfc:      	strh	w8, [sp, #0x80]
    2d00:      	mov	w8, #0x5                // =5
    2d04:      	add	x1, sp, #0x80
    2d08:      	mov	w21, #0x1               // =1
    2d0c:      	strh	w8, [sp, #0x82]
    2d10:      	mov	x8, #0x57               // =87
    2d14:      	movk	x8, #0x2, lsl #32
    2d18:      	stur	x8, [sp, #0x84]
    2d1c:      	add	x8, sp, #0x80
    2d20:      	ldr	x23, [x23]
    2d24:      	mov	x0, x23
    2d28:      	blr	x9
    2d2c:      	cbz	x0, 0x2d7c <generic_kprobe_process_event+0x2a1c>
    2d30:      	ldr	w8, [x0]
    2d34:      	add	w8, w8, #0x1
    2d38:      	str	w8, [x0]
    2d3c:      	mov	w8, #-0x4               // =-4
    2d40:      	b	0x31e8 <generic_kprobe_process_event+0x2e88>
    2d44:      	mov	x22, xzr
    2d48:      	stp	w22, w22, [x19]
    2d4c:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2d50:      	add	x21, x22, #0x8
    2d54:      	ldr	x24, [x24]
    2d58:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    2d5c:      	cmp	w8, #0x33
    2d60:      	b.eq	0x3268 <generic_kprobe_process_event+0x2f08>
    2d64:      	cmp	w8, #0x3c
    2d68:      	b.eq	0x2da8 <generic_kprobe_process_event+0x2a48>
    2d6c:      	cmp	w8, #0xff
    2d70:      	b.ne	0x3328 <generic_kprobe_process_event+0x2fc8>
    2d74:      	mov	w8, #0x28               // =40
    2d78:      	b	0x3274 <generic_kprobe_process_event+0x2f14>
    2d7c:      	str	w21, [sp, #0xf8]
    2d80:      	mov	x3, xzr
    2d84:      	mov	w8, #0x2                // =2
    2d88:      	add	x9, sp, #0x80
    2d8c:      	add	x10, sp, #0xf8
    2d90:      	add	x1, sp, #0x80
    2d94:      	add	x2, sp, #0xf8
    2d98:      	mov	x0, x23
    2d9c:      	blr	x8
    2da0:      	mov	w8, #-0x4               // =-4
    2da4:      	b	0x31e8 <generic_kprobe_process_event+0x2e88>
    2da8:      	ldrb	w8, [x24, #0x7]
    2dac:      	lsl	w8, w8, #3
    2db0:      	b	0x3270 <generic_kprobe_process_event+0x2f10>
    2db4:      	mov	w21, #0x4               // =4
    2db8:      	b	0x35fc <generic_kprobe_process_event+0x329c>
    2dbc:      	mov	w9, #0x5e60             // =24160
    2dc0:      	b	0x2dd0 <generic_kprobe_process_event+0x2a70>
    2dc4:      	mov	w9, #0x5e68             // =24168
    2dc8:      	b	0x2dd0 <generic_kprobe_process_event+0x2a70>
    2dcc:      	mov	w9, #0x5e50             // =24144
    2dd0:      	ldr	x8, [sp, #0x40]
    2dd4:      	add	x8, x8, x9
    2dd8:      	ldr	x8, [x8]
    2ddc:      	add	x25, sp, #0xf0
    2de0:      	mov	w24, #0x8               // =8
    2de4:      	add	x9, sp, #0xf0
    2de8:      	str	x8, [x25, #0x8]
    2dec:      	mov	w8, #0x4                // =4
    2df0:      	add	x10, sp, #0xf8
    2df4:      	add	x0, sp, #0xf0
    2df8:      	add	x2, sp, #0xf8
    2dfc:      	mov	w1, #0x8                // =8
    2e00:      	blr	x8
    2e04:      	ldr	x22, [x25]
    2e08:      	tbz	w23, #0x5, 0x2f48 <generic_kprobe_process_event+0x2be8>
    2e0c:      	cmp	x22, #0x1, lsl #12      // =0x1000
    2e10:      	b.lo	0x2f34 <generic_kprobe_process_event+0x2bd4>
    2e14:      	mov	w8, #0x1                // =1
    2e18:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2e1c:      	add	x9, sp, #0x100
    2e20:      	str	w8, [x19]
    2e24:      	str	wzr, [sp, #0x100]
    2e28:      	add	x1, sp, #0x100
    2e2c:      	ldr	x0, [x0]
    2e30:      	blr	x8
    2e34:      	cbz	x0, 0x31fc <generic_kprobe_process_event+0x2e9c>
    2e38:      	mov	w8, #0x18               // =24
    2e3c:      	mov	x25, x0
    2e40:      	str	w8, [x0]
    2e44:      	mov	w8, #0xe                // =14
    2e48:      	blr	x8
    2e4c:      	mov	x23, x25
    2e50:      	cmn	x0, #0x16
    2e54:      	str	x0, [x23, #0x10]!
    2e58:      	b.ne	0x2e84 <generic_kprobe_process_event+0x2b24>
    2e5c:      	ldr	x8, [sp, #0x10]
    2e60:      	mov	w9, #0x4                // =4
    2e64:      	add	x10, sp, #0xa8
    2e68:      	add	x0, sp, #0xa8
    2e6c:      	mov	w1, #0x8                // =8
    2e70:      	add	x2, x8, #0xe8
    2e74:      	mov	w8, #0x8                // =8
    2e78:      	blr	x9
    2e7c:      	ldr	x8, [sp, #0xa8]
    2e80:      	str	x8, [x23]
    2e84:      	mov	w8, #0x7d               // =125
    2e88:      	blr	x8
    2e8c:      	str	x0, [x25, #0x18]
    2e90:      	mov	x21, xzr
    2e94:      	add	x29, x25, #0x20
    2e98:      	mov	w24, #0xa               // =10
    2e9c:      	ldp	x8, x9, [x23]
    2ea0:      	stur	x9, [x19, #0x1c]
    2ea4:      	stur	x8, [x19, #0x14]
    2ea8:      	subs	x8, x22, x21
    2eac:      	b.mi	0x336c <generic_kprobe_process_event+0x300c>
    2eb0:      	ldr	x9, [sp, #0x48]
    2eb4:      	mov	x0, x29
    2eb8:      	add	x2, x21, x9
    2ebc:      	mov	w9, #0x7fe0             // =32736
    2ec0:      	cmp	x8, x9
    2ec4:      	csel	x23, x8, x9, lo
    2ec8:      	mov	w8, #0x4                // =4
    2ecc:      	mov	w1, w23
    2ed0:      	blr	x8
    2ed4:      	tbnz	w0, #0x1f, 0x2f10 <generic_kprobe_process_event+0x2bb0>
    2ed8:      	add	w4, w23, #0x20
    2edc:      	adrp	x1, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2ee0:      	ldr	x0, [sp, #0x10]
    2ee4:      	mov	w8, #0x19               // =25
    2ee8:      	str	w4, [x25, #0x4]
    2eec:      	mov	w9, #-0x1               // =-1
    2ef0:      	mov	w2, #-0x1               // =-1
    2ef4:      	mov	x3, x25
    2ef8:      	ldr	x1, [x1]
    2efc:      	blr	x8
    2f00:      	sxtw	x8, w0
    2f04:      	tst	w0, #0x80000000
    2f08:      	csel	x8, x23, x8, eq
    2f0c:      	b	0x2f14 <generic_kprobe_process_event+0x2bb4>
    2f10:      	sxtw	x8, w0
    2f14:      	tbnz	w8, #0x1f, 0x3374 <generic_kprobe_process_event+0x3014>
    2f18:      	and	x8, x8, #0x7fffffff
    2f1c:      	add	x21, x8, x21
    2f20:      	cmp	x21, x22
    2f24:      	b.eq	0x33c0 <generic_kprobe_process_event+0x3060>
    2f28:      	subs	w24, w24, #0x1
    2f2c:      	b.ne	0x2ea8 <generic_kprobe_process_event+0x2b48>
    2f30:      	b	0x3710 <generic_kprobe_process_event+0x33b0>
    2f34:      	ldr	x8, [sp, #0x118]
    2f38:      	str	wzr, [x19]
    2f3c:      	mov	w24, #0xc               // =12
    2f40:      	add	x8, x21, x8
    2f44:      	add	x19, x8, #0x8
    2f48:      	cmp	x22, #0xfff
    2f4c:      	mov	w8, #0xfff              // =4095
    2f50:      	ldr	x2, [sp, #0x48]
    2f54:      	add	x0, x19, #0x8
    2f58:      	csel	x23, x22, x8, lo
    2f5c:      	mov	w8, #0x4                // =4
    2f60:      	mov	w1, w23
    2f64:      	blr	x8
    2f68:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    2f6c:      	stp	w22, w23, [x19]
    2f70:      	add	x21, x24, x23
    2f74:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2f78:      	ldr	x24, [x24]
    2f7c:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    2f80:      	ldr	x8, [sp, #0x118]
    2f84:      	mov	w9, #0x4                // =4
    2f88:      	mov	w1, w22
    2f8c:      	add	x21, x8, #0xc
    2f90:      	ldr	x8, [sp, #0xa8]
    2f94:      	add	x0, x24, x21
    2f98:      	ldr	x2, [sp, #0xa8]
    2f9c:      	blr	x9
    2fa0:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    2fa4:      	cmp	x23, #0x1
    2fa8:      	b.eq	0x2d48 <generic_kprobe_process_event+0x29e8>
    2fac:      	ldr	x8, [sp, #0x48]
    2fb0:      	mov	w9, #0x4                // =4
    2fb4:      	add	x10, sp, #0xa8
    2fb8:      	add	x0, sp, #0xa8
    2fbc:      	mov	w1, #0x10               // =16
    2fc0:      	add	x2, x8, #0x10
    2fc4:      	mov	w8, #0x10               // =16
    2fc8:      	blr	x9
    2fcc:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    2fd0:      	ldr	x29, [sp, #0xb0]
    2fd4:      	cmp	x29, #0xffe
    2fd8:      	b.hi	0x2c60 <generic_kprobe_process_event+0x2900>
    2fdc:      	add	x21, x22, x21
    2fe0:      	ldr	x8, [sp, #0xa8]
    2fe4:      	mov	w9, #0x4                // =4
    2fe8:      	mov	w1, w29
    2fec:      	add	x0, x24, x21
    2ff0:      	ldr	x2, [sp, #0xa8]
    2ff4:      	blr	x9
    2ff8:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    2ffc:      	add	x22, x29, x22
    3000:      	cmp	x23, #0x3
    3004:      	b.lo	0x2d48 <generic_kprobe_process_event+0x29e8>
    3008:      	ldr	x8, [sp, #0x48]
    300c:      	mov	w9, #0x4                // =4
    3010:      	add	x10, sp, #0xa8
    3014:      	add	x0, sp, #0xa8
    3018:      	mov	w1, #0x10               // =16
    301c:      	add	x2, x8, #0x20
    3020:      	mov	w8, #0x10               // =16
    3024:      	blr	x9
    3028:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    302c:      	ldr	x25, [sp, #0xb0]
    3030:      	cmp	x25, #0xffe
    3034:      	b.hi	0x2c60 <generic_kprobe_process_event+0x2900>
    3038:      	add	x21, x29, x21
    303c:      	mov	w9, #0x4                // =4
    3040:      	mov	w1, w25
    3044:      	and	x8, x21, #0x3fff
    3048:      	add	x0, x24, x8
    304c:      	ldr	x8, [sp, #0xa8]
    3050:      	ldr	x2, [sp, #0xa8]
    3054:      	blr	x9
    3058:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    305c:      	add	x22, x25, x22
    3060:      	cmp	x23, #0x3
    3064:      	b.eq	0x2d48 <generic_kprobe_process_event+0x29e8>
    3068:      	ldr	x8, [sp, #0x48]
    306c:      	mov	w9, #0x4                // =4
    3070:      	add	x10, sp, #0xa8
    3074:      	add	x0, sp, #0xa8
    3078:      	mov	w1, #0x10               // =16
    307c:      	add	x2, x8, #0x30
    3080:      	mov	w8, #0x10               // =16
    3084:      	blr	x9
    3088:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    308c:      	ldr	x29, [sp, #0xb0]
    3090:      	cmp	x29, #0xffe
    3094:      	b.hi	0x2c60 <generic_kprobe_process_event+0x2900>
    3098:      	add	x21, x25, x21
    309c:      	mov	w9, #0x4                // =4
    30a0:      	mov	w1, w29
    30a4:      	and	x8, x21, #0x3fff
    30a8:      	add	x0, x24, x8
    30ac:      	ldr	x8, [sp, #0xa8]
    30b0:      	ldr	x2, [sp, #0xa8]
    30b4:      	blr	x9
    30b8:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    30bc:      	add	x22, x29, x22
    30c0:      	cmp	x23, #0x5
    30c4:      	b.lo	0x2d48 <generic_kprobe_process_event+0x29e8>
    30c8:      	ldr	x8, [sp, #0x48]
    30cc:      	mov	w9, #0x4                // =4
    30d0:      	add	x10, sp, #0xa8
    30d4:      	add	x0, sp, #0xa8
    30d8:      	mov	w1, #0x10               // =16
    30dc:      	add	x2, x8, #0x40
    30e0:      	mov	w8, #0x10               // =16
    30e4:      	blr	x9
    30e8:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    30ec:      	ldr	x25, [sp, #0xb0]
    30f0:      	cmp	x25, #0xffe
    30f4:      	b.hi	0x2c60 <generic_kprobe_process_event+0x2900>
    30f8:      	add	x21, x29, x21
    30fc:      	mov	w9, #0x4                // =4
    3100:      	mov	w1, w25
    3104:      	and	x8, x21, #0x3fff
    3108:      	add	x0, x24, x8
    310c:      	ldr	x8, [sp, #0xa8]
    3110:      	ldr	x2, [sp, #0xa8]
    3114:      	blr	x9
    3118:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    311c:      	add	x22, x25, x22
    3120:      	cmp	x23, #0x5
    3124:      	b.eq	0x2d48 <generic_kprobe_process_event+0x29e8>
    3128:      	ldr	x8, [sp, #0x48]
    312c:      	mov	w9, #0x4                // =4
    3130:      	add	x10, sp, #0xa8
    3134:      	add	x0, sp, #0xa8
    3138:      	mov	w1, #0x10               // =16
    313c:      	add	x2, x8, #0x50
    3140:      	mov	w8, #0x10               // =16
    3144:      	blr	x9
    3148:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    314c:      	ldr	x29, [sp, #0xb0]
    3150:      	cmp	x29, #0xffe
    3154:      	b.hi	0x2c60 <generic_kprobe_process_event+0x2900>
    3158:      	add	x21, x25, x21
    315c:      	mov	w9, #0x4                // =4
    3160:      	mov	w1, w29
    3164:      	and	x8, x21, #0x3fff
    3168:      	add	x0, x24, x8
    316c:      	ldr	x8, [sp, #0xa8]
    3170:      	ldr	x2, [sp, #0xa8]
    3174:      	blr	x9
    3178:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    317c:      	add	x22, x29, x22
    3180:      	cmp	x23, #0x7
    3184:      	b.lo	0x2d48 <generic_kprobe_process_event+0x29e8>
    3188:      	ldr	x8, [sp, #0x48]
    318c:      	mov	w9, #0x4                // =4
    3190:      	add	x10, sp, #0xa8
    3194:      	add	x0, sp, #0xa8
    3198:      	mov	w1, #0x10               // =16
    319c:      	add	x2, x8, #0x60
    31a0:      	mov	w8, #0x10               // =16
    31a4:      	blr	x9
    31a8:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    31ac:      	ldr	x23, [sp, #0xb0]
    31b0:      	cmp	x23, #0xffe
    31b4:      	b.hi	0x2c60 <generic_kprobe_process_event+0x2900>
    31b8:      	add	x8, x29, x21
    31bc:      	mov	w9, #0x4                // =4
    31c0:      	mov	w1, w23
    31c4:      	and	x8, x8, #0x3fff
    31c8:      	add	x0, x24, x8
    31cc:      	ldr	x8, [sp, #0xa8]
    31d0:      	ldr	x2, [sp, #0xa8]
    31d4:      	blr	x9
    31d8:      	tbnz	w0, #0x1f, 0x31e4 <generic_kprobe_process_event+0x2e84>
    31dc:      	add	x22, x23, x22
    31e0:      	b	0x2d48 <generic_kprobe_process_event+0x29e8>
    31e4:      	mov	w8, #-0x2               // =-2
    31e8:      	str	w8, [x19]
    31ec:      	adrp	x24, 0x3000 <generic_kprobe_process_event+0x2ca0>
    31f0:      	mov	w21, #0x4               // =4
    31f4:      	ldr	x24, [x24]
    31f8:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    31fc:      	adrp	x24, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3200:      	mov	w21, #0x4               // =4
    3204:      	ldr	x24, [x24]
    3208:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    320c:      	mov	x21, #-0x1              // =-1
    3210:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    3214:      	mov	x21, x8
    3218:      	str	wzr, [sp, #0xa8]
    321c:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3220:      	mov	w8, #0x1                // =1
    3224:      	add	x9, sp, #0xa8
    3228:      	ldr	x0, [x0]
    322c:      	add	x1, sp, #0xa8
    3230:      	blr	x8
    3234:      	cbz	x0, 0x35c4 <generic_kprobe_process_event+0x3264>
    3238:      	cmn	x21, #0xc
    323c:      	b.gt	0x334c <generic_kprobe_process_event+0x2fec>
    3240:      	cmn	x21, #0x1c
    3244:      	b.eq	0x3590 <generic_kprobe_process_event+0x3230>
    3248:      	cmn	x21, #0x16
    324c:      	b.eq	0x35a8 <generic_kprobe_process_event+0x3248>
    3250:      	cmn	x21, #0x10
    3254:      	b.ne	0x35a0 <generic_kprobe_process_event+0x3240>
    3258:      	add	x8, x0, #0x558
    325c:      	b	0x35b4 <generic_kprobe_process_event+0x3254>
    3260:      	mov	x21, x25
    3264:      	b	0x35c4 <generic_kprobe_process_event+0x3264>
    3268:      	ldrb	w8, [x24, #0x7]
    326c:      	lsl	w8, w8, #2
    3270:      	add	w8, w8, #0x8
    3274:      	strh	w8, [x24, #0x2]
    3278:      	ldrh	w9, [x24]
    327c:      	ldrb	w23, [x24, #0x6]
    3280:      	add	w8, w9, w8
    3284:      	cmp	w23, #0x3c
    3288:      	strh	w8, [x24]
    328c:      	b.hi	0x3344 <generic_kprobe_process_event+0x2fe4>
    3290:      	mov	x29, #0x1               // =1
    3294:      	mov	w9, #0x1                // =1
    3298:      	movk	x29, #0x1800, lsl #32
    329c:      	lsl	x9, x9, x23
    32a0:      	movk	x29, #0x1008, lsl #48
    32a4:      	tst	x9, x29
    32a8:      	b.eq	0x3344 <generic_kprobe_process_event+0x2fe4>
    32ac:      	strb	w23, [x24, #0x5]
    32b0:      	add	x8, x21, w8, uxth
    32b4:      	mov	w9, #0x2                // =2
    32b8:      	mov	w10, #0x4               // =4
    32bc:      	mov	x0, x25
    32c0:      	mov	w1, #0x2                // =2
    32c4:      	ldrh	w8, [x24]
    32c8:      	add	x2, x21, x8
    32cc:      	blr	x10
    32d0:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    32d4:      	ldrb	w8, [x24, #0x5]
    32d8:      	cmp	w8, #0x32
    32dc:      	b.gt	0x32fc <generic_kprobe_process_event+0x2f9c>
    32e0:      	cbz	w8, 0x331c <generic_kprobe_process_event+0x2fbc>
    32e4:      	cmp	w8, #0x2b
    32e8:      	b.eq	0x331c <generic_kprobe_process_event+0x2fbc>
    32ec:      	cmp	w8, #0x2c
    32f0:      	b.ne	0x347c <generic_kprobe_process_event+0x311c>
    32f4:      	mov	w8, #0x8                // =8
    32f8:      	b	0x33d4 <generic_kprobe_process_event+0x3074>
    32fc:      	cmp	w8, #0x33
    3300:      	b.eq	0x33c8 <generic_kprobe_process_event+0x3068>
    3304:      	cmp	w8, #0x3c
    3308:      	b.eq	0x331c <generic_kprobe_process_event+0x2fbc>
    330c:      	cmp	w8, #0xff
    3310:      	b.ne	0x347c <generic_kprobe_process_event+0x311c>
    3314:      	mov	w8, #0x28               // =40
    3318:      	b	0x33d4 <generic_kprobe_process_event+0x3074>
    331c:      	ldrb	w8, [x24, #0x7]
    3320:      	lsl	w8, w8, #3
    3324:      	b	0x33d0 <generic_kprobe_process_event+0x3070>
    3328:      	ldrh	w8, [x24, #0x2]
    332c:      	ldrh	w9, [x24]
    3330:      	ldrb	w23, [x24, #0x6]
    3334:      	add	w8, w9, w8
    3338:      	cmp	w23, #0x3c
    333c:      	strh	w8, [x24]
    3340:      	b.ls	0x3290 <generic_kprobe_process_event+0x2f30>
    3344:      	strh	w8, [sp, #0xe8]
    3348:      	b	0x3950 <generic_kprobe_process_event+0x35f0>
    334c:      	cmn	x21, #0xb
    3350:      	b.eq	0x3598 <generic_kprobe_process_event+0x3238>
    3354:      	cmn	x21, #0x7
    3358:      	b.eq	0x35b0 <generic_kprobe_process_event+0x3250>
    335c:      	cmn	x21, #0x2
    3360:      	b.ne	0x35a0 <generic_kprobe_process_event+0x3240>
    3364:      	add	x8, x0, #0x548
    3368:      	b	0x35b4 <generic_kprobe_process_event+0x3254>
    336c:      	mov	x21, #-0x1              // =-1
    3370:      	b	0x3378 <generic_kprobe_process_event+0x3018>
    3374:      	mov	x21, x8
    3378:      	str	wzr, [sp, #0xa8]
    337c:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3380:      	mov	w8, #0x1                // =1
    3384:      	add	x9, sp, #0xa8
    3388:      	ldr	x0, [x0]
    338c:      	add	x1, sp, #0xa8
    3390:      	blr	x8
    3394:      	cbz	x0, 0x3710 <generic_kprobe_process_event+0x33b0>
    3398:      	cmn	x21, #0xc
    339c:      	b.gt	0x349c <generic_kprobe_process_event+0x313c>
    33a0:      	cmn	x21, #0x1c
    33a4:      	b.eq	0x36dc <generic_kprobe_process_event+0x337c>
    33a8:      	cmn	x21, #0x16
    33ac:      	b.eq	0x36e4 <generic_kprobe_process_event+0x3384>
    33b0:      	cmn	x21, #0x10
    33b4:      	b.ne	0x36fc <generic_kprobe_process_event+0x339c>
    33b8:      	add	x8, x0, #0x558
    33bc:      	b	0x3700 <generic_kprobe_process_event+0x33a0>
    33c0:      	mov	x21, x22
    33c4:      	b	0x3710 <generic_kprobe_process_event+0x33b0>
    33c8:      	ldrb	w8, [x24, #0x7]
    33cc:      	lsl	w8, w8, #2
    33d0:      	add	w8, w8, #0x8
    33d4:      	strh	w8, [x24, #0x2]
    33d8:      	ldrh	w9, [x24]
    33dc:      	ldrb	w23, [x24, #0x6]
    33e0:      	add	w8, w9, w8
    33e4:      	cmp	w23, #0x3c
    33e8:      	strh	w8, [x24]
    33ec:      	b.hi	0x3b10 <generic_kprobe_process_event+0x37b0>
    33f0:      	mov	w9, #0x1                // =1
    33f4:      	lsl	x9, x9, x23
    33f8:      	tst	x9, x29
    33fc:      	b.eq	0x3b10 <generic_kprobe_process_event+0x37b0>
    3400:      	strb	w23, [x24, #0x5]
    3404:      	add	x8, x21, w8, uxth
    3408:      	mov	w9, #0x2                // =2
    340c:      	mov	w10, #0x4               // =4
    3410:      	mov	x0, x25
    3414:      	mov	w1, #0x2                // =2
    3418:      	ldrh	w8, [x24]
    341c:      	add	x2, x21, x8
    3420:      	blr	x10
    3424:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    3428:      	ldrb	w8, [x24, #0x5]
    342c:      	cmp	w8, #0x32
    3430:      	b.gt	0x3450 <generic_kprobe_process_event+0x30f0>
    3434:      	cbz	w8, 0x3470 <generic_kprobe_process_event+0x3110>
    3438:      	cmp	w8, #0x2b
    343c:      	b.eq	0x3470 <generic_kprobe_process_event+0x3110>
    3440:      	cmp	w8, #0x2c
    3444:      	b.ne	0x3570 <generic_kprobe_process_event+0x3210>
    3448:      	mov	w8, #0x8                // =8
    344c:      	b	0x34c8 <generic_kprobe_process_event+0x3168>
    3450:      	cmp	w8, #0x33
    3454:      	b.eq	0x34bc <generic_kprobe_process_event+0x315c>
    3458:      	cmp	w8, #0x3c
    345c:      	b.eq	0x3470 <generic_kprobe_process_event+0x3110>
    3460:      	cmp	w8, #0xff
    3464:      	b.ne	0x3570 <generic_kprobe_process_event+0x3210>
    3468:      	mov	w8, #0x28               // =40
    346c:      	b	0x34c8 <generic_kprobe_process_event+0x3168>
    3470:      	ldrb	w8, [x24, #0x7]
    3474:      	lsl	w8, w8, #3
    3478:      	b	0x34c4 <generic_kprobe_process_event+0x3164>
    347c:      	ldrh	w8, [x24, #0x2]
    3480:      	ldrh	w9, [x24]
    3484:      	ldrb	w23, [x24, #0x6]
    3488:      	add	w8, w9, w8
    348c:      	cmp	w23, #0x3c
    3490:      	strh	w8, [x24]
    3494:      	b.ls	0x33f0 <generic_kprobe_process_event+0x3090>
    3498:      	b	0x3b10 <generic_kprobe_process_event+0x37b0>
    349c:      	cmn	x21, #0xb
    34a0:      	b.eq	0x36ec <generic_kprobe_process_event+0x338c>
    34a4:      	cmn	x21, #0x7
    34a8:      	b.eq	0x36f4 <generic_kprobe_process_event+0x3394>
    34ac:      	cmn	x21, #0x2
    34b0:      	b.ne	0x36fc <generic_kprobe_process_event+0x339c>
    34b4:      	add	x8, x0, #0x548
    34b8:      	b	0x3700 <generic_kprobe_process_event+0x33a0>
    34bc:      	ldrb	w8, [x24, #0x7]
    34c0:      	lsl	w8, w8, #2
    34c4:      	add	w8, w8, #0x8
    34c8:      	strh	w8, [x24, #0x2]
    34cc:      	ldrh	w9, [x24]
    34d0:      	ldrb	w23, [x24, #0x6]
    34d4:      	add	w8, w9, w8
    34d8:      	cmp	w23, #0x3c
    34dc:      	strh	w8, [x24]
    34e0:      	b.hi	0x3b10 <generic_kprobe_process_event+0x37b0>
    34e4:      	mov	w9, #0x1                // =1
    34e8:      	lsl	x9, x9, x23
    34ec:      	tst	x9, x29
    34f0:      	b.eq	0x3b10 <generic_kprobe_process_event+0x37b0>
    34f4:      	strb	w23, [x24, #0x5]
    34f8:      	add	x8, x21, w8, uxth
    34fc:      	mov	w9, #0x2                // =2
    3500:      	mov	w10, #0x4               // =4
    3504:      	mov	x0, x25
    3508:      	mov	w1, #0x2                // =2
    350c:      	ldrh	w8, [x24]
    3510:      	add	x2, x21, x8
    3514:      	blr	x10
    3518:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    351c:      	ldrb	w8, [x24, #0x5]
    3520:      	cmp	w8, #0x32
    3524:      	b.gt	0x3544 <generic_kprobe_process_event+0x31e4>
    3528:      	cbz	w8, 0x3564 <generic_kprobe_process_event+0x3204>
    352c:      	cmp	w8, #0x2b
    3530:      	b.eq	0x3564 <generic_kprobe_process_event+0x3204>
    3534:      	cmp	w8, #0x2c
    3538:      	b.ne	0x36bc <generic_kprobe_process_event+0x335c>
    353c:      	mov	w8, #0x8                // =8
    3540:      	b	0x3614 <generic_kprobe_process_event+0x32b4>
    3544:      	cmp	w8, #0x33
    3548:      	b.eq	0x3608 <generic_kprobe_process_event+0x32a8>
    354c:      	cmp	w8, #0x3c
    3550:      	b.eq	0x3564 <generic_kprobe_process_event+0x3204>
    3554:      	cmp	w8, #0xff
    3558:      	b.ne	0x36bc <generic_kprobe_process_event+0x335c>
    355c:      	mov	w8, #0x28               // =40
    3560:      	b	0x3614 <generic_kprobe_process_event+0x32b4>
    3564:      	ldrb	w8, [x24, #0x7]
    3568:      	lsl	w8, w8, #3
    356c:      	b	0x3610 <generic_kprobe_process_event+0x32b0>
    3570:      	ldrh	w8, [x24, #0x2]
    3574:      	ldrh	w9, [x24]
    3578:      	ldrb	w23, [x24, #0x6]
    357c:      	add	w8, w9, w8
    3580:      	cmp	w23, #0x3c
    3584:      	strh	w8, [x24]
    3588:      	b.ls	0x34e4 <generic_kprobe_process_event+0x3184>
    358c:      	b	0x3b10 <generic_kprobe_process_event+0x37b0>
    3590:      	add	x8, x0, #0x568
    3594:      	b	0x35b4 <generic_kprobe_process_event+0x3254>
    3598:      	add	x8, x0, #0x570
    359c:      	b	0x35b4 <generic_kprobe_process_event+0x3254>
    35a0:      	add	x8, x0, #0x540
    35a4:      	b	0x35b4 <generic_kprobe_process_event+0x3254>
    35a8:      	add	x8, x0, #0x560
    35ac:      	b	0x35b4 <generic_kprobe_process_event+0x3254>
    35b0:      	add	x8, x0, #0x550
    35b4:      	ldaxr	x9, [x8]
    35b8:      	add	x9, x9, #0x1
    35bc:      	stlxr	w10, x9, [x8]
    35c0:      	cbnz	w10, 0x35b4 <generic_kprobe_process_event+0x3254>
    35c4:      	tbnz	w21, #0x1f, 0x35e0 <generic_kprobe_process_event+0x3280>
    35c8:      	ldr	x8, [sp, #0x58]
    35cc:      	cmn	x25, #0x1
    35d0:      	stur	xzr, [x8, #0x4]
    35d4:      	sub	w8, w25, w21
    35d8:      	csel	w8, wzr, w8, eq
    35dc:      	b	0x35f0 <generic_kprobe_process_event+0x3290>
    35e0:      	ldr	x9, [sp, #0x58]
    35e4:      	mov	w8, wzr
    35e8:      	stp	w21, wzr, [x9, #0x4]
    35ec:      	mov	w21, wzr
    35f0:      	ldr	x9, [sp, #0x58]
    35f4:      	stp	w8, w21, [x9, #0xc]
    35f8:      	mov	w21, #0x24              // =36
    35fc:      	mov	x24, x29
    3600:      	mov	w25, #0x5efc            // =24316
    3604:      	b	0x1590 <generic_kprobe_process_event+0x1230>
    3608:      	ldrb	w8, [x24, #0x7]
    360c:      	lsl	w8, w8, #2
    3610:      	add	w8, w8, #0x8
    3614:      	strh	w8, [x24, #0x2]
    3618:      	ldrh	w9, [x24]
    361c:      	ldrb	w23, [x24, #0x6]
    3620:      	add	w8, w9, w8
    3624:      	cmp	w23, #0x3c
    3628:      	strh	w8, [x24]
    362c:      	b.hi	0x3b10 <generic_kprobe_process_event+0x37b0>
    3630:      	mov	w9, #0x1                // =1
    3634:      	lsl	x9, x9, x23
    3638:      	tst	x9, x29
    363c:      	b.eq	0x3b10 <generic_kprobe_process_event+0x37b0>
    3640:      	strb	w23, [x24, #0x5]
    3644:      	add	x8, x21, w8, uxth
    3648:      	mov	w9, #0x2                // =2
    364c:      	mov	w10, #0x4               // =4
    3650:      	mov	x0, x25
    3654:      	mov	w1, #0x2                // =2
    3658:      	ldrh	w8, [x24]
    365c:      	add	x2, x21, x8
    3660:      	blr	x10
    3664:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    3668:      	ldrb	w8, [x24, #0x5]
    366c:      	cmp	w8, #0x32
    3670:      	b.gt	0x3690 <generic_kprobe_process_event+0x3330>
    3674:      	cbz	w8, 0x36b0 <generic_kprobe_process_event+0x3350>
    3678:      	cmp	w8, #0x2b
    367c:      	b.eq	0x36b0 <generic_kprobe_process_event+0x3350>
    3680:      	cmp	w8, #0x2c
    3684:      	b.ne	0x37fc <generic_kprobe_process_event+0x349c>
    3688:      	mov	w8, #0x8                // =8
    368c:      	b	0x3754 <generic_kprobe_process_event+0x33f4>
    3690:      	cmp	w8, #0x33
    3694:      	b.eq	0x3748 <generic_kprobe_process_event+0x33e8>
    3698:      	cmp	w8, #0x3c
    369c:      	b.eq	0x36b0 <generic_kprobe_process_event+0x3350>
    36a0:      	cmp	w8, #0xff
    36a4:      	b.ne	0x37fc <generic_kprobe_process_event+0x349c>
    36a8:      	mov	w8, #0x28               // =40
    36ac:      	b	0x3754 <generic_kprobe_process_event+0x33f4>
    36b0:      	ldrb	w8, [x24, #0x7]
    36b4:      	lsl	w8, w8, #3
    36b8:      	b	0x3750 <generic_kprobe_process_event+0x33f0>
    36bc:      	ldrh	w8, [x24, #0x2]
    36c0:      	ldrh	w9, [x24]
    36c4:      	ldrb	w23, [x24, #0x6]
    36c8:      	add	w8, w9, w8
    36cc:      	cmp	w23, #0x3c
    36d0:      	strh	w8, [x24]
    36d4:      	b.ls	0x3630 <generic_kprobe_process_event+0x32d0>
    36d8:      	b	0x3b10 <generic_kprobe_process_event+0x37b0>
    36dc:      	add	x8, x0, #0x568
    36e0:      	b	0x3700 <generic_kprobe_process_event+0x33a0>
    36e4:      	add	x8, x0, #0x560
    36e8:      	b	0x3700 <generic_kprobe_process_event+0x33a0>
    36ec:      	add	x8, x0, #0x570
    36f0:      	b	0x3700 <generic_kprobe_process_event+0x33a0>
    36f4:      	add	x8, x0, #0x550
    36f8:      	b	0x3700 <generic_kprobe_process_event+0x33a0>
    36fc:      	add	x8, x0, #0x540
    3700:      	ldaxr	x9, [x8]
    3704:      	add	x9, x9, #0x1
    3708:      	stlxr	w10, x9, [x8]
    370c:      	cbnz	w10, 0x3700 <generic_kprobe_process_event+0x33a0>
    3710:      	tbnz	w21, #0x1f, 0x3728 <generic_kprobe_process_event+0x33c8>
    3714:      	sub	w8, w22, w21
    3718:      	cmn	x22, #0x1
    371c:      	stur	xzr, [x19, #0x4]
    3720:      	csel	w8, wzr, w8, eq
    3724:      	b	0x3734 <generic_kprobe_process_event+0x33d4>
    3728:      	mov	w8, wzr
    372c:      	stp	w21, wzr, [x19, #0x4]
    3730:      	mov	w21, wzr
    3734:      	stp	w8, w21, [x19, #0xc]
    3738:      	adrp	x24, 0x3000 <generic_kprobe_process_event+0x2ca0>
    373c:      	mov	w21, #0x24              // =36
    3740:      	ldr	x24, [x24]
    3744:      	b	0x1a54 <generic_kprobe_process_event+0x16f4>
    3748:      	ldrb	w8, [x24, #0x7]
    374c:      	lsl	w8, w8, #2
    3750:      	add	w8, w8, #0x8
    3754:      	strh	w8, [x24, #0x2]
    3758:      	ldrh	w9, [x24]
    375c:      	ldrb	w23, [x24, #0x6]
    3760:      	add	w8, w9, w8
    3764:      	cmp	w23, #0x3c
    3768:      	strh	w8, [x24]
    376c:      	b.hi	0x3b10 <generic_kprobe_process_event+0x37b0>
    3770:      	mov	w9, #0x1                // =1
    3774:      	lsl	x9, x9, x23
    3778:      	tst	x9, x29
    377c:      	b.eq	0x3b10 <generic_kprobe_process_event+0x37b0>
    3780:      	strb	w23, [x24, #0x5]
    3784:      	add	x8, x21, w8, uxth
    3788:      	mov	w9, #0x2                // =2
    378c:      	mov	w10, #0x4               // =4
    3790:      	mov	x0, x25
    3794:      	mov	w1, #0x2                // =2
    3798:      	ldrh	w8, [x24]
    379c:      	add	x2, x21, x8
    37a0:      	blr	x10
    37a4:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    37a8:      	ldrb	w8, [x24, #0x5]
    37ac:      	cmp	w8, #0x32
    37b0:      	b.gt	0x37d0 <generic_kprobe_process_event+0x3470>
    37b4:      	cbz	w8, 0x37f0 <generic_kprobe_process_event+0x3490>
    37b8:      	cmp	w8, #0x2b
    37bc:      	b.eq	0x37f0 <generic_kprobe_process_event+0x3490>
    37c0:      	cmp	w8, #0x2c
    37c4:      	b.ne	0x38d0 <generic_kprobe_process_event+0x3570>
    37c8:      	mov	w8, #0x8                // =8
    37cc:      	b	0x3828 <generic_kprobe_process_event+0x34c8>
    37d0:      	cmp	w8, #0x33
    37d4:      	b.eq	0x381c <generic_kprobe_process_event+0x34bc>
    37d8:      	cmp	w8, #0x3c
    37dc:      	b.eq	0x37f0 <generic_kprobe_process_event+0x3490>
    37e0:      	cmp	w8, #0xff
    37e4:      	b.ne	0x38d0 <generic_kprobe_process_event+0x3570>
    37e8:      	mov	w8, #0x28               // =40
    37ec:      	b	0x3828 <generic_kprobe_process_event+0x34c8>
    37f0:      	ldrb	w8, [x24, #0x7]
    37f4:      	lsl	w8, w8, #3
    37f8:      	b	0x3824 <generic_kprobe_process_event+0x34c4>
    37fc:      	ldrh	w8, [x24, #0x2]
    3800:      	ldrh	w9, [x24]
    3804:      	ldrb	w23, [x24, #0x6]
    3808:      	add	w8, w9, w8
    380c:      	cmp	w23, #0x3c
    3810:      	strh	w8, [x24]
    3814:      	b.ls	0x3770 <generic_kprobe_process_event+0x3410>
    3818:      	b	0x3b10 <generic_kprobe_process_event+0x37b0>
    381c:      	ldrb	w8, [x24, #0x7]
    3820:      	lsl	w8, w8, #2
    3824:      	add	w8, w8, #0x8
    3828:      	strh	w8, [x24, #0x2]
    382c:      	ldrh	w9, [x24]
    3830:      	ldrb	w23, [x24, #0x6]
    3834:      	add	w8, w9, w8
    3838:      	cmp	w23, #0x3c
    383c:      	strh	w8, [x24]
    3840:      	b.hi	0x3b10 <generic_kprobe_process_event+0x37b0>
    3844:      	mov	w9, #0x1                // =1
    3848:      	lsl	x9, x9, x23
    384c:      	tst	x9, x29
    3850:      	b.eq	0x3b10 <generic_kprobe_process_event+0x37b0>
    3854:      	strb	w23, [x24, #0x5]
    3858:      	add	x8, x21, w8, uxth
    385c:      	mov	w9, #0x2                // =2
    3860:      	mov	w10, #0x4               // =4
    3864:      	mov	x0, x25
    3868:      	mov	w1, #0x2                // =2
    386c:      	ldrh	w8, [x24]
    3870:      	add	x2, x21, x8
    3874:      	blr	x10
    3878:      	tbnz	x0, #0x3f, 0x394c <generic_kprobe_process_event+0x35ec>
    387c:      	ldrb	w8, [x24, #0x5]
    3880:      	cmp	w8, #0x32
    3884:      	b.gt	0x38a4 <generic_kprobe_process_event+0x3544>
    3888:      	cbz	w8, 0x38c4 <generic_kprobe_process_event+0x3564>
    388c:      	cmp	w8, #0x2b
    3890:      	b.eq	0x38c4 <generic_kprobe_process_event+0x3564>
    3894:      	cmp	w8, #0x2c
    3898:      	b.ne	0x3af4 <generic_kprobe_process_event+0x3794>
    389c:      	mov	w8, #0x8                // =8
    38a0:      	b	0x38fc <generic_kprobe_process_event+0x359c>
    38a4:      	cmp	w8, #0x33
    38a8:      	b.eq	0x38f0 <generic_kprobe_process_event+0x3590>
    38ac:      	cmp	w8, #0x3c
    38b0:      	b.eq	0x38c4 <generic_kprobe_process_event+0x3564>
    38b4:      	cmp	w8, #0xff
    38b8:      	b.ne	0x3af4 <generic_kprobe_process_event+0x3794>
    38bc:      	mov	w8, #0x28               // =40
    38c0:      	b	0x38fc <generic_kprobe_process_event+0x359c>
    38c4:      	ldrb	w8, [x24, #0x7]
    38c8:      	lsl	w8, w8, #3
    38cc:      	b	0x38f8 <generic_kprobe_process_event+0x3598>
    38d0:      	ldrh	w8, [x24, #0x2]
    38d4:      	ldrh	w9, [x24]
    38d8:      	ldrb	w23, [x24, #0x6]
    38dc:      	add	w8, w9, w8
    38e0:      	cmp	w23, #0x3c
    38e4:      	strh	w8, [x24]
    38e8:      	b.ls	0x3844 <generic_kprobe_process_event+0x34e4>
    38ec:      	b	0x3b10 <generic_kprobe_process_event+0x37b0>
    38f0:      	ldrb	w8, [x24, #0x7]
    38f4:      	lsl	w8, w8, #2
    38f8:      	add	w8, w8, #0x8
    38fc:      	strh	w8, [x24, #0x2]
    3900:      	ldrh	w9, [x24]
    3904:      	ldrb	w23, [x24, #0x6]
    3908:      	add	w8, w9, w8
    390c:      	cmp	w23, #0x3c
    3910:      	strh	w8, [x24]
    3914:      	b.hi	0x3b10 <generic_kprobe_process_event+0x37b0>
    3918:      	mov	w9, #0x1                // =1
    391c:      	lsl	x9, x9, x23
    3920:      	tst	x9, x29
    3924:      	b.eq	0x3b10 <generic_kprobe_process_event+0x37b0>
    3928:      	strb	w23, [x24, #0x5]
    392c:      	add	x8, x21, w8, uxth
    3930:      	mov	w9, #0x2                // =2
    3934:      	mov	w10, #0x4               // =4
    3938:      	mov	x0, x25
    393c:      	mov	w1, #0x2                // =2
    3940:      	ldrh	w8, [x24]
    3944:      	add	x2, x21, x8
    3948:      	blr	x10
    394c:      	mov	w23, wzr
    3950:      	ldr	x25, [sp, #0x20]
    3954:      	mov	w8, #0xa                // =10
    3958:      	strb	w23, [sp, #0x98]
    395c:      	add	x2, x22, #0x8
    3960:      	mov	w21, #0x10              // =16
    3964:      	mov	w1, #0x10               // =16
    3968:      	mov	w24, #0x4               // =4
    396c:      	strh	w23, [x25, #0x24]
    3970:      	strh	w8, [x25, #0x26]
    3974:      	mov	w8, #0x4                // =4
    3978:      	mov	x0, x25
    397c:      	blr	x8
    3980:      	add	x0, x25, #0x10
    3984:      	add	x2, x22, #0x18
    3988:      	mov	w1, #0x10               // =16
    398c:      	blr	x24
    3990:      	cmp	w23, #0x11
    3994:      	b.eq	0x39d8 <generic_kprobe_process_event+0x3678>
    3998:      	cmp	w23, #0x6
    399c:      	b.ne	0x3a18 <generic_kprobe_process_event+0x36b8>
    39a0:      	ldr	x8, [sp, #0xa8]
    39a4:      	ldrh	w9, [sp, #0xe8]
    39a8:      	mov	w21, #0x2               // =2
    39ac:      	mov	w1, #0x2                // =2
    39b0:      	mov	w24, #0x4               // =4
    39b4:      	add	x23, x8, x9
    39b8:      	ldr	x25, [sp, #0x20]
    39bc:      	add	x0, x25, #0x20
    39c0:      	mov	w8, #0x4                // =4
    39c4:      	mov	x2, x23
    39c8:      	blr	x8
    39cc:      	add	x0, x25, #0x22
    39d0:      	add	x2, x23, #0x2
    39d4:      	b	0x3a0c <generic_kprobe_process_event+0x36ac>
    39d8:      	ldr	x8, [sp, #0xa8]
    39dc:      	ldrh	w9, [sp, #0xe8]
    39e0:      	mov	w21, #0x2               // =2
    39e4:      	mov	w1, #0x2                // =2
    39e8:      	mov	w24, #0x4               // =4
    39ec:      	add	x23, x8, x9
    39f0:      	ldr	x25, [sp, #0x20]
    39f4:      	add	x0, x25, #0x20
    39f8:      	mov	w8, #0x4                // =4
    39fc:      	mov	x2, x23
    3a00:      	blr	x8
    3a04:      	add	x0, x25, #0x22
    3a08:      	add	x2, x23, #0x2
    3a0c:      	mov	w1, #0x2                // =2
    3a10:      	blr	x24
    3a14:      	b	0x3a20 <generic_kprobe_process_event+0x36c0>
    3a18:      	ldr	x8, [sp, #0x20]
    3a1c:      	str	wzr, [x8, #0x20]
    3a20:      	ldr	x9, [sp, #0x20]
    3a24:      	add	x2, x19, #0xe0
    3a28:      	add	x10, sp, #0x100
    3a2c:      	add	x0, sp, #0x100
    3a30:      	ldrh	w8, [x9, #0x20]
    3a34:      	mov	w1, #0x8                // =8
    3a38:      	rev	w8, w8
    3a3c:      	lsr	w8, w8, #16
    3a40:      	strh	w8, [x9, #0x20]
    3a44:      	ldrh	w8, [x9, #0x22]
    3a48:      	rev	w8, w8
    3a4c:      	lsr	w8, w8, #16
    3a50:      	strh	w8, [x9, #0x22]
    3a54:      	mov	w8, #0x8                // =8
    3a58:      	mov	w9, #0x4                // =4
    3a5c:      	blr	x9
    3a60:      	add	x8, sp, #0xf0
    3a64:      	ldr	x8, [x8, #0x10]
    3a68:      	cbz	x8, 0x3acc <generic_kprobe_process_event+0x376c>
    3a6c:      	add	x8, x8, #0x5
    3a70:      	mov	w9, #0x8                // =8
    3a74:      	add	x10, sp, #0x80
    3a78:      	mov	w11, #0x4               // =4
    3a7c:      	add	x23, sp, #0xf0
    3a80:      	ldr	x8, [x23, #0x10]
    3a84:      	add	x0, sp, #0x80
    3a88:      	mov	w1, #0x8                // =8
    3a8c:      	mov	w21, #0x4               // =4
    3a90:      	add	x2, x8, #0x5
    3a94:      	blr	x11
    3a98:      	ldr	x8, [x23, #0x10]
    3a9c:      	ldr	x9, [sp, #0x80]
    3aa0:      	mov	w1, #0x4                // =4
    3aa4:      	add	x23, x8, x9, lsl #3
    3aa8:      	ldr	x24, [sp, #0x20]
    3aac:      	add	x0, x24, #0x38
    3ab0:      	mov	w8, #0x4                // =4
    3ab4:      	add	x2, x23, #0x44
    3ab8:      	blr	x8
    3abc:      	add	x0, x24, #0x3c
    3ac0:      	add	x2, x23, #0x45
    3ac4:      	mov	w1, #0x4                // =4
    3ac8:      	blr	x21
    3acc:      	mov	w21, #0x40              // =64
    3ad0:      	adrp	x24, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3ad4:      	adrp	x22, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3ad8:      	mov	w25, #0x5efc            // =24316
    3adc:      	ldr	x24, [x24]
    3ae0:      	ldp	x11, x9, [sp, #0x28]
    3ae4:      	ldr	x22, [x22]
    3ae8:      	mov	w10, #0x5ea0            // =24224
    3aec:      	ldr	x19, [sp, #0x10]
    3af0:      	b	0x1598 <generic_kprobe_process_event+0x1238>
    3af4:      	ldrh	w8, [x24, #0x2]
    3af8:      	ldrh	w9, [x24]
    3afc:      	ldrb	w23, [x24, #0x6]
    3b00:      	add	w8, w9, w8
    3b04:      	cmp	w23, #0x3c
    3b08:      	strh	w8, [x24]
    3b0c:      	b.ls	0x3918 <generic_kprobe_process_event+0x35b8>
    3b10:      	strh	w8, [sp, #0xe8]
    3b14:      	b	0x3950 <generic_kprobe_process_event+0x35f0>
    3b18:      	nop
    3b1c:      	nop

0000000000003b20 <generic_kprobe_process_filter>:
    3b20:      	sub	sp, sp, #0x130
    3b24:      	str	x29, [sp, #0xe0]
    3b28:      	stp	x30, x25, [sp, #0xf0]
    3b2c:      	stp	x24, x23, [sp, #0x100]
    3b30:      	stp	x22, x21, [sp, #0x110]
    3b34:      	stp	x20, x19, [sp, #0x120]
    3b38:      	mov	x22, x0
    3b3c:      	str	wzr, [sp, #0x54]
    3b40:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3b44:      	mov	w8, #0x1                // =1
    3b48:      	ldr	x0, [x0]
    3b4c:      	add	x9, sp, #0x54
    3b50:      	add	x1, sp, #0x54
    3b54:      	blr	x8
    3b58:      	cbz	x0, 0x59f4 <generic_kprobe_process_filter+0x1ed4>
    3b5c:      	mov	w8, #0x5ec0             // =24256
    3b60:      	mov	x20, x0
    3b64:      	add	x29, x0, x8
    3b68:      	mov	w8, #0x23               // =35
    3b6c:      	blr	x8
    3b70:      	str	x0, [sp, #0x58]
    3b74:      	add	x8, x0, #0x8d4
    3b78:      	mov	w9, #0x4                // =4
    3b7c:      	mov	w10, #0x71              // =113
    3b80:      	add	x11, sp, #0xd8
    3b84:      	add	x0, sp, #0xd8
    3b88:      	mov	w1, #0x4                // =4
    3b8c:      	ldr	x8, [sp, #0x58]
    3b90:      	add	x2, x8, #0x8d4
    3b94:      	blr	x10
    3b98:      	ldr	w8, [sp, #0xd8]
    3b9c:      	adrp	x19, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3ba0:      	add	x9, sp, #0xc8
    3ba4:      	add	x1, sp, #0xc8
    3ba8:      	str	w8, [sp, #0xc8]
    3bac:      	mov	w8, #0x1                // =1
    3bb0:      	ldr	x19, [x19]
    3bb4:      	mov	x0, x19
    3bb8:      	blr	x8
    3bbc:      	cbz	x0, 0x3bcc <generic_kprobe_process_filter+0xac>
    3bc0:      	ldr	x8, [x0, #0x8]
    3bc4:      	mov	x24, x0
    3bc8:      	cbnz	x8, 0x47fc <generic_kprobe_process_filter+0xcdc>
    3bcc:      	ldr	x8, [sp, #0x58]
    3bd0:      	mov	w9, #0x8                // =8
    3bd4:      	mov	w10, #0x71              // =113
    3bd8:      	add	x11, sp, #0x58
    3bdc:      	add	x0, sp, #0x58
    3be0:      	mov	w1, #0x8                // =8
    3be4:      	add	x8, x8, #0x8e0
    3be8:      	ldr	x8, [sp, #0x58]
    3bec:      	add	x2, x8, #0x8e0
    3bf0:      	blr	x10
    3bf4:      	ldr	x8, [sp, #0x58]
    3bf8:      	cbz	x8, 0x3d74 <generic_kprobe_process_filter+0x254>
    3bfc:      	add	x8, x8, #0x8d4
    3c00:      	mov	w9, #0x4                // =4
    3c04:      	mov	w10, #0x71              // =113
    3c08:      	add	x11, sp, #0xd8
    3c0c:      	ldr	x8, [sp, #0x58]
    3c10:      	add	x0, sp, #0xd8
    3c14:      	mov	w1, #0x4                // =4
    3c18:      	add	x2, x8, #0x8d4
    3c1c:      	blr	x10
    3c20:      	ldr	w8, [sp, #0xd8]
    3c24:      	add	x9, sp, #0xc8
    3c28:      	add	x1, sp, #0xc8
    3c2c:      	mov	x0, x19
    3c30:      	str	w8, [sp, #0xc8]
    3c34:      	mov	w8, #0x1                // =1
    3c38:      	blr	x8
    3c3c:      	cbz	x0, 0x3c4c <generic_kprobe_process_filter+0x12c>
    3c40:      	ldr	x8, [x0, #0x8]
    3c44:      	mov	x24, x0
    3c48:      	cbnz	x8, 0x47fc <generic_kprobe_process_filter+0xcdc>
    3c4c:      	ldr	x8, [sp, #0x58]
    3c50:      	mov	w9, #0x8                // =8
    3c54:      	mov	w10, #0x71              // =113
    3c58:      	add	x11, sp, #0x58
    3c5c:      	add	x0, sp, #0x58
    3c60:      	mov	w1, #0x8                // =8
    3c64:      	add	x8, x8, #0x8e0
    3c68:      	ldr	x8, [sp, #0x58]
    3c6c:      	add	x2, x8, #0x8e0
    3c70:      	blr	x10
    3c74:      	ldr	x8, [sp, #0x58]
    3c78:      	cbz	x8, 0x3d74 <generic_kprobe_process_filter+0x254>
    3c7c:      	add	x8, x8, #0x8d4
    3c80:      	mov	w9, #0x4                // =4
    3c84:      	mov	w10, #0x71              // =113
    3c88:      	add	x11, sp, #0xd8
    3c8c:      	ldr	x8, [sp, #0x58]
    3c90:      	add	x0, sp, #0xd8
    3c94:      	mov	w1, #0x4                // =4
    3c98:      	add	x2, x8, #0x8d4
    3c9c:      	blr	x10
    3ca0:      	ldr	w8, [sp, #0xd8]
    3ca4:      	add	x9, sp, #0xc8
    3ca8:      	add	x1, sp, #0xc8
    3cac:      	mov	x0, x19
    3cb0:      	str	w8, [sp, #0xc8]
    3cb4:      	mov	w8, #0x1                // =1
    3cb8:      	blr	x8
    3cbc:      	cbz	x0, 0x3ccc <generic_kprobe_process_filter+0x1ac>
    3cc0:      	ldr	x8, [x0, #0x8]
    3cc4:      	mov	x24, x0
    3cc8:      	cbnz	x8, 0x47fc <generic_kprobe_process_filter+0xcdc>
    3ccc:      	ldr	x8, [sp, #0x58]
    3cd0:      	mov	w9, #0x8                // =8
    3cd4:      	mov	w10, #0x71              // =113
    3cd8:      	add	x11, sp, #0x58
    3cdc:      	add	x0, sp, #0x58
    3ce0:      	mov	w1, #0x8                // =8
    3ce4:      	add	x8, x8, #0x8e0
    3ce8:      	ldr	x8, [sp, #0x58]
    3cec:      	add	x2, x8, #0x8e0
    3cf0:      	blr	x10
    3cf4:      	ldr	x8, [sp, #0x58]
    3cf8:      	cbz	x8, 0x3d74 <generic_kprobe_process_filter+0x254>
    3cfc:      	add	x8, x8, #0x8d4
    3d00:      	mov	w9, #0x4                // =4
    3d04:      	mov	w10, #0x71              // =113
    3d08:      	add	x11, sp, #0xd8
    3d0c:      	ldr	x8, [sp, #0x58]
    3d10:      	add	x0, sp, #0xd8
    3d14:      	mov	w1, #0x4                // =4
    3d18:      	add	x2, x8, #0x8d4
    3d1c:      	blr	x10
    3d20:      	ldr	w8, [sp, #0xd8]
    3d24:      	add	x9, sp, #0xc8
    3d28:      	add	x1, sp, #0xc8
    3d2c:      	mov	x0, x19
    3d30:      	str	w8, [sp, #0xc8]
    3d34:      	mov	w8, #0x1                // =1
    3d38:      	blr	x8
    3d3c:      	cbz	x0, 0x3d4c <generic_kprobe_process_filter+0x22c>
    3d40:      	ldr	x8, [x0, #0x8]
    3d44:      	mov	x24, x0
    3d48:      	cbnz	x8, 0x47fc <generic_kprobe_process_filter+0xcdc>
    3d4c:      	ldr	x8, [sp, #0x58]
    3d50:      	mov	w9, #0x8                // =8
    3d54:      	mov	w10, #0x71              // =113
    3d58:      	add	x11, sp, #0x58
    3d5c:      	add	x0, sp, #0x58
    3d60:      	mov	w1, #0x8                // =8
    3d64:      	add	x8, x8, #0x8e0
    3d68:      	ldr	x8, [sp, #0x58]
    3d6c:      	add	x2, x8, #0x8e0
    3d70:      	blr	x10
    3d74:      	mov	w8, #0x23               // =35
    3d78:      	blr	x8
    3d7c:      	add	x2, x0, #0x8d4
    3d80:      	mov	w8, #0x4                // =4
    3d84:      	add	x9, sp, #0x58
    3d88:      	mov	x24, x0
    3d8c:      	add	x0, sp, #0x58
    3d90:      	mov	w1, #0x4                // =4
    3d94:      	blr	x8
    3d98:      	ldr	w8, [sp, #0x58]
    3d9c:      	mov	x19, x29
    3da0:      	str	w8, [x19, #0x50]!
    3da4:      	mov	w8, #0x7d               // =125
    3da8:      	blr	x8
    3dac:      	str	x0, [x20, #0x5f18]
    3db0:      	str	wzr, [x19, #0x10]
    3db4:      	add	x2, x24, #0x60
    3db8:      	mov	w8, #0x8                // =8
    3dbc:      	mov	w9, #0x71               // =113
    3dc0:      	add	x10, sp, #0xc8
    3dc4:      	str	xzr, [x20, #0x5f28]
    3dc8:      	str	x19, [sp, #0x48]
    3dcc:      	add	x0, sp, #0xc8
    3dd0:      	mov	w1, #0x8                // =8
    3dd4:      	str	wzr, [x19, #0x20]
    3dd8:      	blr	x9
    3ddc:      	ldr	x8, [sp, #0xc8]
    3de0:      	cbz	x8, 0x3e50 <generic_kprobe_process_filter+0x330>
    3de4:      	add	x8, x8, #0x4
    3de8:      	mov	w9, #0x4                // =4
    3dec:      	mov	w10, #0x71              // =113
    3df0:      	add	x11, sp, #0xd8
    3df4:      	ldr	x8, [sp, #0xc8]
    3df8:      	add	x0, sp, #0xd8
    3dfc:      	mov	w1, #0x4                // =4
    3e00:      	add	x2, x8, #0x4
    3e04:      	blr	x10
    3e08:      	ldr	w8, [sp, #0xd8]
    3e0c:      	cbz	w8, 0x3e50 <generic_kprobe_process_filter+0x330>
    3e10:      	ldr	x9, [sp, #0xc8]
    3e14:      	lsl	w8, w8, #4
    3e18:      	mov	w10, #0x71              // =113
    3e1c:      	add	x11, sp, #0x58
    3e20:      	add	x0, sp, #0x58
    3e24:      	mov	w1, #0x10               // =16
    3e28:      	add	x8, x9, x8
    3e2c:      	mov	w9, #0x10               // =16
    3e30:      	add	x8, x8, #0x80
    3e34:      	ldr	w9, [sp, #0xd8]
    3e38:      	ldr	x8, [sp, #0xc8]
    3e3c:      	lsl	w9, w9, #4
    3e40:      	add	x8, x8, x9
    3e44:      	add	x2, x8, #0x80
    3e48:      	blr	x10
    3e4c:      	ldr	w8, [sp, #0x58]
    3e50:      	str	w8, [x29, #0x74]
    3e54:      	mov	w8, #0x5f60             // =24416
    3e58:      	str	x20, [sp, #0xe8]
    3e5c:      	add	x23, x24, #0xae0
    3e60:      	mov	w19, #0x8               // =8
    3e64:      	add	x25, x20, x8
    3e68:      	add	x8, sp, #0x58
    3e6c:      	mov	w9, #0x4                // =4
    3e70:      	add	x0, sp, #0x58
    3e74:      	mov	w1, #0x8                // =8
    3e78:      	mov	x2, x23
    3e7c:      	mov	w21, #0x4               // =4
    3e80:      	blr	x9
    3e84:      	ldr	x20, [sp, #0x58]
    3e88:      	ldr	x9, [sp, #0xe8]
    3e8c:      	mov	w8, #0x5f68             // =24424
    3e90:      	mov	w1, #0x8                // =8
    3e94:      	add	x0, x9, x8
    3e98:      	add	x2, x20, #0x40
    3e9c:      	mov	w8, #0x4                // =4
    3ea0:      	blr	x8
    3ea4:      	ldr	x9, [sp, #0xe8]
    3ea8:      	mov	w8, #0x5f70             // =24432
    3eac:      	add	x2, x20, #0x30
    3eb0:      	mov	w1, #0x8                // =8
    3eb4:      	add	x0, x9, x8
    3eb8:      	mov	w8, #0x4                // =4
    3ebc:      	blr	x8
    3ec0:      	add	x2, x20, #0x38
    3ec4:      	mov	w8, #0x4                // =4
    3ec8:      	mov	x0, x25
    3ecc:      	mov	w1, #0x8                // =8
    3ed0:      	blr	x8
    3ed4:      	ldr	x9, [sp, #0xe8]
    3ed8:      	mov	w8, #0x5f38             // =24376
    3edc:      	add	x2, x24, #0xb50
    3ee0:      	add	x0, sp, #0xd8
    3ee4:      	mov	w1, #0x8                // =8
    3ee8:      	add	x25, x9, x8
    3eec:      	add	x8, sp, #0xd8
    3ef0:      	mov	w9, #0x4                // =4
    3ef4:      	blr	x9
    3ef8:      	add	x12, sp, #0xd8
    3efc:      	mov	w9, #0x48               // =72
    3f00:      	add	x10, sp, #0x58
    3f04:      	ldr	x8, [x12]
    3f08:      	mov	w11, #0x4               // =4
    3f0c:      	add	x0, sp, #0x58
    3f10:      	mov	w1, #0x48               // =72
    3f14:      	ldr	x2, [x12]
    3f18:      	blr	x11
    3f1c:      	ldr	x8, [sp, #0x60]
    3f20:      	mov	w9, #0x4                // =4
    3f24:      	mov	x0, x25
    3f28:      	mov	w1, #0x4                // =4
    3f2c:      	add	x8, x8, #0x218
    3f30:      	ldr	x8, [sp, #0x60]
    3f34:      	ldr	x25, [sp, #0xe8]
    3f38:      	add	x2, x8, #0x218
    3f3c:      	blr	x9
    3f40:      	mov	w8, #0x5f3c             // =24380
    3f44:      	mov	w9, #0x4                // =4
    3f48:      	mov	w1, #0x4                // =4
    3f4c:      	add	x0, x25, x8
    3f50:      	ldr	x8, [sp, #0x68]
    3f54:      	add	x8, x8, #0x4d8
    3f58:      	ldr	x8, [sp, #0x68]
    3f5c:      	add	x2, x8, #0x4d8
    3f60:      	blr	x9
    3f64:      	mov	w8, #0x5f40             // =24384
    3f68:      	mov	w9, #0x4                // =4
    3f6c:      	mov	w1, #0x4                // =4
    3f70:      	add	x0, x25, x8
    3f74:      	ldr	x8, [sp, #0x70]
    3f78:      	add	x8, x8, #0x58
    3f7c:      	ldr	x8, [sp, #0x70]
    3f80:      	add	x2, x8, #0x58
    3f84:      	blr	x9
    3f88:      	str	xzr, [sp, #0xc0]
    3f8c:      	add	x2, x24, #0x938
    3f90:      	add	x8, sp, #0xc0
    3f94:      	add	x0, sp, #0xc0
    3f98:      	mov	w1, #0x8                // =8
    3f9c:      	blr	x21
    3fa0:      	ldr	x8, [sp, #0xc0]
    3fa4:      	cbz	x8, 0x402c <generic_kprobe_process_filter+0x50c>
    3fa8:      	str	wzr, [sp, #0xb8]
    3fac:      	add	x8, x8, #0x4
    3fb0:      	add	x9, sp, #0xb8
    3fb4:      	mov	w10, #0x4               // =4
    3fb8:      	add	x0, sp, #0xb8
    3fbc:      	mov	w1, #0x4                // =4
    3fc0:      	mov	w19, #0x4               // =4
    3fc4:      	ldr	x8, [sp, #0xc0]
    3fc8:      	add	x2, x8, #0x4
    3fcc:      	blr	x10
    3fd0:      	ldr	x8, [sp, #0xc0]
    3fd4:      	ldrsw	x9, [sp, #0xb8]
    3fd8:      	add	x10, sp, #0xc8
    3fdc:      	mov	w11, #0x4               // =4
    3fe0:      	add	x0, sp, #0xc8
    3fe4:      	mov	w1, #0x10               // =16
    3fe8:      	add	x8, x8, x9, lsl #4
    3fec:      	mov	w9, #0x10               // =16
    3ff0:      	add	x8, x8, #0x80
    3ff4:      	ldr	x8, [sp, #0xc0]
    3ff8:      	ldrsw	x9, [sp, #0xb8]
    3ffc:      	add	x8, x8, x9, lsl #4
    4000:      	add	x2, x8, #0x80
    4004:      	blr	x11
    4008:      	mov	w8, #0x5f44             // =24388
    400c:      	mov	w1, #0x4                // =4
    4010:      	add	x0, x25, x8
    4014:      	ldr	x8, [sp, #0xd0]
    4018:      	add	x8, x8, #0x158
    401c:      	ldr	x8, [sp, #0xd0]
    4020:      	add	x2, x8, #0x158
    4024:      	blr	x19
    4028:      	b	0x4030 <generic_kprobe_process_filter+0x510>
    402c:      	str	wzr, [x29, #0x84]
    4030:      	mov	w8, #0x5f48             // =24392
    4034:      	mov	w9, #0x4                // =4
    4038:      	mov	w1, #0x4                // =4
    403c:      	mov	w19, #0x4               // =4
    4040:      	add	x0, x25, x8
    4044:      	ldr	x8, [sp, #0x78]
    4048:      	add	x8, x8, #0x158
    404c:      	ldr	x8, [sp, #0x78]
    4050:      	add	x2, x8, #0x158
    4054:      	blr	x9
    4058:      	mov	w8, #0x5f4c             // =24396
    405c:      	mov	w9, #0x4                // =4
    4060:      	mov	w1, #0x4                // =4
    4064:      	add	x0, x25, x8
    4068:      	ldr	x8, [sp, #0x80]
    406c:      	add	x8, x8, #0x118
    4070:      	ldr	x8, [sp, #0x80]
    4074:      	add	x2, x8, #0x118
    4078:      	blr	x9
    407c:      	mov	w8, #0x5f50             // =24400
    4080:      	mov	w9, #0x4                // =4
    4084:      	mov	w1, #0x4                // =4
    4088:      	add	x0, x25, x8
    408c:      	ldr	x8, [sp, #0x88]
    4090:      	add	x8, x8, #0x98
    4094:      	ldr	x8, [sp, #0x88]
    4098:      	add	x2, x8, #0x98
    409c:      	blr	x9
    40a0:      	mov	w8, #0x5f54             // =24404
    40a4:      	mov	w9, #0x4                // =4
    40a8:      	mov	w1, #0x4                // =4
    40ac:      	add	x0, x25, x8
    40b0:      	ldr	x8, [sp, #0x90]
    40b4:      	add	x8, x8, #0x98
    40b8:      	ldr	x8, [sp, #0x90]
    40bc:      	add	x2, x8, #0x98
    40c0:      	blr	x9
    40c4:      	mov	w8, #0x5f58             // =24408
    40c8:      	mov	w9, #0x4                // =4
    40cc:      	mov	w1, #0x4                // =4
    40d0:      	add	x0, x25, x8
    40d4:      	ldr	x8, [sp, #0x98]
    40d8:      	add	x8, x8, #0x58
    40dc:      	ldr	x8, [sp, #0x98]
    40e0:      	add	x2, x8, #0x58
    40e4:      	blr	x9
    40e8:      	stp	xzr, xzr, [sp, #0xc0]
    40ec:      	mov	w20, #0x8               // =8
    40f0:      	add	x8, sp, #0xc8
    40f4:      	mov	w9, #0x4                // =4
    40f8:      	add	x0, sp, #0xc8
    40fc:      	mov	w1, #0x8                // =8
    4100:      	mov	x2, x23
    4104:      	blr	x9
    4108:      	ldr	x8, [sp, #0xc8]
    410c:      	add	x9, sp, #0xc0
    4110:      	mov	w10, #0x4               // =4
    4114:      	add	x0, sp, #0xc0
    4118:      	mov	w1, #0x8                // =8
    411c:      	add	x8, x8, #0x90
    4120:      	ldr	x8, [sp, #0xc8]
    4124:      	add	x2, x8, #0x90
    4128:      	blr	x10
    412c:      	mov	w8, #0x5f5c             // =24412
    4130:      	mov	w1, #0x4                // =4
    4134:      	add	x0, x25, x8
    4138:      	ldr	x8, [sp, #0xc0]
    413c:      	add	x8, x8, #0x158
    4140:      	ldr	x8, [sp, #0xc0]
    4144:      	add	x2, x8, #0x158
    4148:      	blr	x19
    414c:      	ldr	w8, [x29, #0x74]
    4150:      	cmp	w8, #0x1
    4154:      	b.ne	0x4164 <generic_kprobe_process_filter+0x644>
    4158:      	ldr	w8, [x29, #0x70]
    415c:      	orr	w8, w8, #0x2000000
    4160:      	str	w8, [x29, #0x70]
    4164:      	add	x0, x29, #0xb8
    4168:      	mov	w1, wzr
    416c:      	mov	w2, #0x308              // =776
    4170:      	bl	0x4170 <generic_kprobe_process_filter+0x650>
    4174:      	mov	w8, #0x6290             // =25232
    4178:      	add	x2, x24, #0x858
    417c:      	mov	w19, #0x8               // =8
    4180:      	mov	w9, #0x4                // =4
    4184:      	add	x0, sp, #0xc8
    4188:      	mov	w1, #0x8                // =8
    418c:      	mov	w20, #0x4               // =4
    4190:      	add	x21, x25, x8
    4194:      	add	x8, sp, #0xc8
    4198:      	blr	x9
    419c:      	ldr	x8, [sp, #0xc8]
    41a0:      	add	x9, sp, #0x58
    41a4:      	add	x0, sp, #0x58
    41a8:      	mov	w1, #0x8                // =8
    41ac:      	add	x8, x8, #0x528
    41b0:      	ldr	x8, [sp, #0xc8]
    41b4:      	add	x2, x8, #0x528
    41b8:      	blr	x20
    41bc:      	str	wzr, [sp, #0xa4]
    41c0:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    41c4:      	ldr	x19, [sp, #0x58]
    41c8:      	mov	w8, #0x1                // =1
    41cc:      	add	x9, sp, #0xa4
    41d0:      	add	x1, sp, #0xa4
    41d4:      	ldr	x0, [x0]
    41d8:      	blr	x8
    41dc:      	cbz	x0, 0x464c <generic_kprobe_process_filter+0xb2c>
    41e0:      	mov	w8, #0x1000             // =4096
    41e4:      	stp	x21, x22, [sp, #0x30]
    41e8:      	mov	x24, x0
    41ec:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    41f0:      	str	x29, [sp, #0x40]
    41f4:      	str	w8, [x29, #0x550]
    41f8:      	mov	w8, #0x23               // =35
    41fc:      	blr	x8
    4200:      	add	x2, x0, #0xb30
    4204:      	mov	w23, #0x8               // =8
    4208:      	add	x8, sp, #0xa8
    420c:      	mov	w9, #0x4                // =4
    4210:      	add	x0, sp, #0xa8
    4214:      	mov	w1, #0x8                // =8
    4218:      	mov	w29, #0x4               // =4
    421c:      	blr	x9
    4220:      	ldr	x22, [sp, #0xa8]
    4224:      	add	x25, x19, #0x48
    4228:      	add	x8, sp, #0xb0
    422c:      	mov	w9, #0x4                // =4
    4230:      	add	x0, sp, #0xb0
    4234:      	mov	w1, #0x8                // =8
    4238:      	mov	x2, x25
    423c:      	blr	x9
    4240:      	ldr	x21, [sp, #0xb0]
    4244:      	add	x8, sp, #0x58
    4248:      	add	x0, sp, #0x58
    424c:      	mov	w1, #0x8                // =8
    4250:      	add	x2, x21, #0x10
    4254:      	blr	x29
    4258:      	ldr	x8, [sp, #0x58]
    425c:      	cbz	x8, 0x44d0 <generic_kprobe_process_filter+0x9b0>
    4260:      	ldr	x8, [sp, #0x40]
    4264:      	stp	xzr, xzr, [sp, #0x58]
    4268:      	add	x21, x22, #0x18
    426c:      	add	x9, sp, #0x58
    4270:      	add	x2, x22, #0x20
    4274:      	mov	w22, #0x8               // =8
    4278:      	stp	x24, xzr, [sp, #0x68]
    427c:      	add	x0, sp, #0x58
    4280:      	mov	w1, #0x8                // =8
    4284:      	add	x29, x19, #0x40
    4288:      	add	x19, x9, #0x8
    428c:      	add	x24, x9, #0x18
    4290:      	stp	xzr, xzr, [sp, #0x78]
    4294:      	add	x23, x9, #0x20
    4298:      	str	x20, [sp, #0x88]
    429c:      	str	x20, [sp, #0x28]
    42a0:      	mov	w20, #0x4               // =4
    42a4:      	ldr	w8, [x8, #0x550]
    42a8:      	strb	wzr, [sp, #0x94]
    42ac:      	str	w8, [sp, #0x90]
    42b0:      	mov	w8, #0x4                // =4
    42b4:      	blr	x8
    42b8:      	mov	w8, #0x4                // =4
    42bc:      	mov	x0, x19
    42c0:      	mov	w1, #0x8                // =8
    42c4:      	mov	x2, x21
    42c8:      	blr	x8
    42cc:      	mov	w8, #0x4                // =4
    42d0:      	mov	x0, x24
    42d4:      	mov	w1, #0x8                // =8
    42d8:      	mov	x2, x25
    42dc:      	blr	x8
    42e0:      	mov	x0, x23
    42e4:      	mov	w1, #0x8                // =8
    42e8:      	mov	x2, x29
    42ec:      	blr	x20
    42f0:      	ldr	x8, [sp, #0x78]
    42f4:      	mov	w19, #0x80              // =128
    42f8:      	add	x21, sp, #0xb8
    42fc:      	add	x23, sp, #0xd8
    4300:      	sub	x8, x8, #0x20
    4304:      	str	x8, [sp, #0x80]
    4308:      	b	0x4314 <generic_kprobe_process_filter+0x7f4>
    430c:      	subs	w19, w19, #0x1
    4310:      	b.eq	0x4480 <generic_kprobe_process_filter+0x960>
    4314:      	ldp	x20, x2, [sp, #0x70]
    4318:      	ldp	x8, x9, [sp, #0x58]
    431c:      	cmp	x20, x8
    4320:      	ccmp	x2, x9, #0x0, eq
    4324:      	b.eq	0x4478 <generic_kprobe_process_filter+0x958>
    4328:      	ldr	x29, [sp, #0x80]
    432c:      	mov	w8, #0x4                // =4
    4330:      	add	x0, sp, #0xb8
    4334:      	mov	w1, #0x8                // =8
    4338:      	blr	x8
    433c:      	ldr	x8, [sp, #0xb8]
    4340:      	cmp	x20, x8
    4344:      	b.eq	0x442c <generic_kprobe_process_filter+0x90c>
    4348:      	add	x25, x20, #0x18
    434c:      	mov	w8, #0x4                // =4
    4350:      	add	x0, sp, #0xd8
    4354:      	mov	w1, #0x8                // =8
    4358:      	mov	x2, x25
    435c:      	blr	x8
    4360:      	add	x8, sp, #0xd8
    4364:      	ldr	x8, [x8]
    4368:      	cmp	x8, x20
    436c:      	b.eq	0x442c <generic_kprobe_process_filter+0x90c>
    4370:      	mov	w8, #0x4                // =4
    4374:      	add	x9, sp, #0xc0
    4378:      	add	x0, sp, #0xc0
    437c:      	mov	w1, #0x8                // =8
    4380:      	mov	x2, x25
    4384:      	blr	x8
    4388:      	add	x2, x20, #0x20
    438c:      	mov	w8, #0x4                // =4
    4390:      	mov	w9, #0x10               // =16
    4394:      	add	x10, sp, #0xc8
    4398:      	add	x0, sp, #0xc8
    439c:      	mov	w1, #0x10               // =16
    43a0:      	blr	x8
    43a4:      	ldr	w20, [sp, #0xcc]
    43a8:      	ldr	x8, [sp, #0x68]
    43ac:      	ldr	x10, [sp, #0x88]
    43b0:      	sub	x12, x10, x8
    43b4:      	ldr	w25, [sp, #0x90]
    43b8:      	subs	w10, w20, w25
    43bc:      	ldr	x9, [sp, #0xd0]
    43c0:      	csel	w10, wzr, w10, lo
    43c4:      	cmp	w25, w20
    43c8:      	csel	w11, w25, w20, lo
    43cc:      	cinc	w13, w11, hi
    43d0:      	sub	w14, w25, w13
    43d4:      	subs	x12, x12, x13
    43d8:      	str	w14, [sp, #0x90]
    43dc:      	b.lo	0x4480 <generic_kprobe_process_filter+0x960>
    43e0:      	cmp	x12, #0xfff
    43e4:      	b.hi	0x4480 <generic_kprobe_process_filter+0x960>
    43e8:      	cmp	w25, w20
    43ec:      	b.ls	0x43f8 <generic_kprobe_process_filter+0x8d8>
    43f0:      	mov	w13, #0x2f              // =47
    43f4:      	strb	w13, [x8, x12]
    43f8:      	add	x29, x8, x12
    43fc:      	cmp	w25, w20
    4400:      	add	x2, x9, x10
    4404:      	and	w1, w11, #0xff
    4408:      	mov	w8, #0x4                // =4
    440c:      	cinc	x0, x29, hi
    4410:      	blr	x8
    4414:      	cmp	w25, w20
    4418:      	str	x29, [sp, #0x88]
    441c:      	b.ls	0x4480 <generic_kprobe_process_filter+0x960>
    4420:      	ldr	x8, [sp, #0xc0]
    4424:      	str	x8, [sp, #0x70]
    4428:      	b	0x430c <generic_kprobe_process_filter+0x7ec>
    442c:      	add	x2, x29, #0x10
    4430:      	mov	w8, #0x4                // =4
    4434:      	add	x0, sp, #0xd8
    4438:      	mov	w1, #0x8                // =8
    443c:      	blr	x8
    4440:      	add	x20, sp, #0xd8
    4444:      	ldr	x8, [sp, #0x80]
    4448:      	ldr	x9, [x20]
    444c:      	cmp	x8, x9
    4450:      	b.eq	0x4478 <generic_kprobe_process_filter+0x958>
    4454:      	add	x2, x29, #0x18
    4458:      	mov	w8, #0x4                // =4
    445c:      	mov	x0, x24
    4460:      	mov	w1, #0x8                // =8
    4464:      	blr	x8
    4468:      	ldr	x8, [x20]
    446c:      	add	x9, x8, #0x20
    4470:      	stp	x9, x8, [sp, #0x78]
    4474:      	b	0x430c <generic_kprobe_process_filter+0x7ec>
    4478:      	mov	w8, #0x1                // =1
    447c:      	strb	w8, [sp, #0x94]
    4480:      	ldr	x24, [sp, #0x88]
    4484:      	ldr	x9, [sp, #0x28]
    4488:      	cmp	x24, x9
    448c:      	b.eq	0x4520 <generic_kprobe_process_filter+0xa00>
    4490:      	ldrb	w8, [sp, #0x94]
    4494:      	ldp	x22, x29, [sp, #0x38]
    4498:      	cmp	w8, #0x0
    449c:      	ldr	x21, [sp, #0x30]
    44a0:      	cset	w8, eq
    44a4:      	lsl	w9, w8, #1
    44a8:      	ldr	w8, [sp, #0x90]
    44ac:      	str	w9, [x29, #0x554]
    44b0:      	cmp	w8, #0x1
    44b4:      	str	w8, [x29, #0x550]
    44b8:      	b.lt	0x44c8 <generic_kprobe_process_filter+0x9a8>
    44bc:      	mov	w9, #0x1000             // =4096
    44c0:      	sub	w8, w9, w8
    44c4:      	str	w8, [x29, #0x550]
    44c8:      	cbnz	x24, 0x4534 <generic_kprobe_process_filter+0xa14>
    44cc:      	b	0x464c <generic_kprobe_process_filter+0xb2c>
    44d0:      	add	x2, x21, #0x18
    44d4:      	mov	w8, #0x8                // =8
    44d8:      	mov	w9, #0x4                // =4
    44dc:      	add	x10, sp, #0x58
    44e0:      	add	x0, sp, #0x58
    44e4:      	mov	w1, #0x8                // =8
    44e8:      	blr	x9
    44ec:      	ldr	x8, [sp, #0x58]
    44f0:      	cmp	x8, x21
    44f4:      	b.eq	0x4260 <generic_kprobe_process_filter+0x740>
    44f8:      	ldr	x29, [sp, #0x40]
    44fc:      	ldr	w9, [x29, #0x550]
    4500:      	sub	w8, w9, #0xa
    4504:      	cmp	w9, #0x9
    4508:      	str	w8, [x29, #0x550]
    450c:      	b.gt	0x49f0 <generic_kprobe_process_filter+0xed0>
    4510:      	mov	w9, #-0x24              // =-36
    4514:      	mov	x24, x20
    4518:      	str	w9, [x29, #0x554]
    451c:      	b	0x4530 <generic_kprobe_process_filter+0xa10>
    4520:      	ldr	x29, [sp, #0x40]
    4524:      	mov	w8, wzr
    4528:      	mov	x24, x9
    452c:      	str	xzr, [x29, #0x550]
    4530:      	ldp	x21, x22, [sp, #0x30]
    4534:      	subs	w9, w8, #0x7f
    4538:      	mov	w10, #0x7f              // =127
    453c:      	mov	x11, x29
    4540:      	mov	x0, x21
    4544:      	mov	x2, x24
    4548:      	csel	w29, w8, w10, lo
    454c:      	csel	w19, wzr, w9, lo
    4550:      	cmp	w8, #0xff
    4554:      	mov	w9, #0xff               // =255
    4558:      	csel	w8, w8, w9, lo
    455c:      	and	w1, w8, #0xff
    4560:      	str	w1, [x11, #0x550]
    4564:      	mov	w8, #0x4                // =4
    4568:      	blr	x8
    456c:      	adrp	x25, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4570:      	ldr	x25, [x25]
    4574:      	cbz	x0, 0x45e4 <generic_kprobe_process_filter+0xac4>
    4578:      	neg	w8, w0
    457c:      	mov	w9, #0x1                // =1
    4580:      	add	x1, sp, #0x58
    4584:      	strh	w8, [sp, #0x58]
    4588:      	mov	w8, #0x8                // =8
    458c:      	mov	x0, x25
    4590:      	mov	w20, #0x1               // =1
    4594:      	strh	w8, [sp, #0x5a]
    4598:      	mov	x8, #0x2de              // =734
    459c:      	movk	x8, #0x4, lsl #32
    45a0:      	stur	x8, [sp, #0x5c]
    45a4:      	add	x8, sp, #0x58
    45a8:      	blr	x9
    45ac:      	cbz	x0, 0x45c0 <generic_kprobe_process_filter+0xaa0>
    45b0:      	ldr	w8, [x0]
    45b4:      	add	w8, w8, #0x1
    45b8:      	str	w8, [x0]
    45bc:      	b	0x45e4 <generic_kprobe_process_filter+0xac4>
    45c0:      	str	w20, [sp, #0xc8]
    45c4:      	mov	x3, xzr
    45c8:      	mov	w8, #0x2                // =2
    45cc:      	add	x9, sp, #0x58
    45d0:      	add	x10, sp, #0xc8
    45d4:      	add	x1, sp, #0x58
    45d8:      	add	x2, sp, #0xc8
    45dc:      	mov	x0, x25
    45e0:      	blr	x8
    45e4:      	ldr	x9, [sp, #0xe8]
    45e8:      	mov	w8, #0x6390             // =25488
    45ec:      	add	x2, x24, x19
    45f0:      	mov	w1, w29
    45f4:      	add	x0, x9, x8
    45f8:      	mov	w8, #0x4                // =4
    45fc:      	blr	x8
    4600:      	ldr	x29, [sp, #0x40]
    4604:      	cbz	x0, 0x464c <generic_kprobe_process_filter+0xb2c>
    4608:      	neg	w8, w0
    460c:      	mov	w9, #0x1                // =1
    4610:      	add	x1, sp, #0x58
    4614:      	strh	w8, [sp, #0x58]
    4618:      	mov	w8, #0x8                // =8
    461c:      	mov	x0, x25
    4620:      	mov	w19, #0x1               // =1
    4624:      	strh	w8, [sp, #0x5a]
    4628:      	mov	x8, #0x2e0              // =736
    462c:      	movk	x8, #0x4, lsl #32
    4630:      	stur	x8, [sp, #0x5c]
    4634:      	add	x8, sp, #0x58
    4638:      	blr	x9
    463c:      	cbz	x0, 0x4670 <generic_kprobe_process_filter+0xb50>
    4640:      	ldr	w8, [x0]
    4644:      	add	w8, w8, #0x1
    4648:      	str	w8, [x0]
    464c:      	ldr	w8, [x29, #0x550]
    4650:      	sub	w9, w8, #0x101
    4654:      	cmn	w9, #0x101
    4658:      	b.hi	0x46a4 <generic_kprobe_process_filter+0xb84>
    465c:      	ldr	x20, [sp, #0xe8]
    4660:      	ldr	x24, [sp, #0x48]
    4664:      	mov	w8, #-0x1               // =-1
    4668:      	stur	w8, [x29, #0xb8]
    466c:      	b	0x47f0 <generic_kprobe_process_filter+0xcd0>
    4670:      	str	w19, [sp, #0xc8]
    4674:      	mov	x3, xzr
    4678:      	mov	w8, #0x2                // =2
    467c:      	add	x9, sp, #0x58
    4680:      	add	x10, sp, #0xc8
    4684:      	add	x1, sp, #0x58
    4688:      	add	x2, sp, #0xc8
    468c:      	mov	x0, x25
    4690:      	blr	x8
    4694:      	ldr	w8, [x29, #0x550]
    4698:      	sub	w9, w8, #0x101
    469c:      	cmn	w9, #0x101
    46a0:      	b.ls	0x465c <generic_kprobe_process_filter+0xb3c>
    46a4:      	ldr	x20, [sp, #0xe8]
    46a8:      	and	x24, x8, #0xff
    46ac:      	mov	w8, #0x5f80             // =24448
    46b0:      	mov	x2, x21
    46b4:      	mov	w1, w24
    46b8:      	add	x0, x20, x8
    46bc:      	mov	w8, #0x4                // =4
    46c0:      	blr	x8
    46c4:      	mov	x23, x0
    46c8:      	cbz	x0, 0x4744 <generic_kprobe_process_filter+0xc24>
    46cc:      	neg	w8, w23
    46d0:      	adrp	x25, 0x4000 <generic_kprobe_process_filter+0x4e0>
    46d4:      	mov	w9, #0x1                // =1
    46d8:      	strh	w8, [sp, #0x58]
    46dc:      	mov	w8, #0xf                // =15
    46e0:      	add	x1, sp, #0x58
    46e4:      	mov	w19, #0x1               // =1
    46e8:      	strh	w8, [sp, #0x5a]
    46ec:      	mov	x8, #0x164              // =356
    46f0:      	movk	x8, #0x4, lsl #32
    46f4:      	stur	x8, [sp, #0x5c]
    46f8:      	add	x8, sp, #0x58
    46fc:      	ldr	x25, [x25]
    4700:      	mov	x0, x25
    4704:      	blr	x9
    4708:      	cbz	x0, 0x471c <generic_kprobe_process_filter+0xbfc>
    470c:      	ldr	w8, [x0]
    4710:      	add	w8, w8, #0x1
    4714:      	str	w8, [x0]
    4718:      	b	0x4740 <generic_kprobe_process_filter+0xc20>
    471c:      	str	w19, [sp, #0xc8]
    4720:      	mov	x3, xzr
    4724:      	mov	w8, #0x2                // =2
    4728:      	add	x9, sp, #0x58
    472c:      	add	x10, sp, #0xc8
    4730:      	add	x1, sp, #0x58
    4734:      	add	x2, sp, #0xc8
    4738:      	mov	x0, x25
    473c:      	blr	x8
    4740:      	ldr	x20, [sp, #0xe8]
    4744:      	cmp	w23, #0x0
    4748:      	csel	w8, w24, w23, eq
    474c:      	cmp	w24, #0x7f
    4750:      	stur	w8, [x29, #0xb8]
    4754:      	mov	w8, #0x7f               // =127
    4758:      	csel	w1, w24, w8, lo
    475c:      	mov	w8, #0x6080             // =24704
    4760:      	add	x0, x20, x8
    4764:      	mov	w8, #0x6390             // =25488
    4768:      	add	x2, x20, x8
    476c:      	mov	w8, #0x4                // =4
    4770:      	blr	x8
    4774:      	ldr	x24, [sp, #0x48]
    4778:      	cbz	x0, 0x47f0 <generic_kprobe_process_filter+0xcd0>
    477c:      	neg	w8, w0
    4780:      	adrp	x23, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4784:      	mov	w9, #0x1                // =1
    4788:      	strh	w8, [sp, #0x58]
    478c:      	mov	w8, #0xf                // =15
    4790:      	add	x1, sp, #0x58
    4794:      	mov	w19, #0x1               // =1
    4798:      	strh	w8, [sp, #0x5a]
    479c:      	mov	x8, #0x16a              // =362
    47a0:      	movk	x8, #0x4, lsl #32
    47a4:      	stur	x8, [sp, #0x5c]
    47a8:      	add	x8, sp, #0x58
    47ac:      	ldr	x23, [x23]
    47b0:      	mov	x0, x23
    47b4:      	blr	x9
    47b8:      	cbz	x0, 0x47cc <generic_kprobe_process_filter+0xcac>
    47bc:      	ldr	w8, [x0]
    47c0:      	add	w8, w8, #0x1
    47c4:      	str	w8, [x0]
    47c8:      	b	0x47f0 <generic_kprobe_process_filter+0xcd0>
    47cc:      	str	w19, [sp, #0xc8]
    47d0:      	mov	x3, xzr
    47d4:      	mov	w8, #0x2                // =2
    47d8:      	add	x9, sp, #0x58
    47dc:      	add	x10, sp, #0xc8
    47e0:      	add	x1, sp, #0x58
    47e4:      	add	x2, sp, #0xc8
    47e8:      	mov	x0, x23
    47ec:      	blr	x8
    47f0:      	ldrb	w8, [x20, #0x1]
    47f4:      	orr	w8, w8, #0x10
    47f8:      	strb	w8, [x20, #0x1]
    47fc:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4800:      	mov	w8, #0x5ef8             // =24312
    4804:      	ldr	x0, [x0]
    4808:      	add	x1, x20, x8
    480c:      	mov	w8, #0x1                // =1
    4810:      	blr	x8
    4814:      	cbz	x0, 0x59f4 <generic_kprobe_process_filter+0x1ed4>
    4818:      	ldr	x21, [x20, #0x5eb8]
    481c:      	cmp	x21, #0x6
    4820:      	b.hs	0x49b8 <generic_kprobe_process_filter+0xe98>
    4824:      	ldrsw	x8, [x0]
    4828:      	mov	x23, x0
    482c:      	cbz	w8, 0x49d4 <generic_kprobe_process_filter+0xeb4>
    4830:      	cmp	x21, x8
    4834:      	b.hs	0x49b8 <generic_kprobe_process_filter+0xe98>
    4838:      	str	x8, [sp, #0x28]
    483c:      	stp	x29, x24, [sp, #0x40]
    4840:      	adrp	x24, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4844:      	mov	w8, #0x1                // =1
    4848:      	add	x9, sp, #0x58
    484c:      	str	x20, [sp, #0xe8]
    4850:      	add	x1, sp, #0x58
    4854:      	str	x22, [sp, #0x38]
    4858:      	str	w21, [sp, #0x58]
    485c:      	str	wzr, [sp, #0xc8]
    4860:      	ldr	x24, [x24]
    4864:      	mov	x0, x24
    4868:      	blr	x8
    486c:      	cbz	x0, 0x4b20 <generic_kprobe_process_filter+0x1000>
    4870:      	ldr	w8, [x0]
    4874:      	mov	x25, x0
    4878:      	cbz	w8, 0x4b20 <generic_kprobe_process_filter+0x1000>
    487c:      	ldr	x9, [sp, #0x48]
    4880:      	ldr	w9, [x9, #0x68]
    4884:      	tbnz	w9, #0x1f, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4888:      	cmp	w8, #0x1b
    488c:      	b.hi	0x599c <generic_kprobe_process_filter+0x1e7c>
    4890:      	mov	w9, #0x1                // =1
    4894:      	lsl	w9, w9, w8
    4898:      	tst	w9, #0x60
    489c:      	b.ne	0x4a94 <generic_kprobe_process_filter+0xf74>
    48a0:      	mov	w10, #0x100             // =256
    48a4:      	movk	w10, #0x400, lsl #16
    48a8:      	tst	w9, w10
    48ac:      	b.ne	0x4a10 <generic_kprobe_process_filter+0xef0>
    48b0:      	mov	w9, #0x1                // =1
    48b4:      	lsl	w8, w9, w8
    48b8:      	mov	w9, #0x200              // =512
    48bc:      	movk	w9, #0x800, lsl #16
    48c0:      	tst	w8, w9
    48c4:      	b.eq	0x599c <generic_kprobe_process_filter+0x1e7c>
    48c8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    48cc:      	add	x1, x25, #0x4
    48d0:      	mov	w8, #0x1                // =1
    48d4:      	ldr	x0, [x0]
    48d8:      	blr	x8
    48dc:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    48e0:      	ldr	x8, [sp, #0x48]
    48e4:      	mov	x20, x0
    48e8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    48ec:      	mov	w9, #0x7f               // =127
    48f0:      	ldr	w8, [x8, #0x68]
    48f4:      	ldr	x0, [x0]
    48f8:      	add	x1, sp, #0xc8
    48fc:      	cmp	w8, #0x7f
    4900:      	csel	w19, w8, w9, lt
    4904:      	mov	w8, #0x1                // =1
    4908:      	add	x9, sp, #0xc8
    490c:      	blr	x8
    4910:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4914:      	sxtw	x1, w19
    4918:      	mov	x29, x0
    491c:      	lsl	w8, w1, #3
    4920:      	str	w8, [x0]
    4924:      	ldr	x8, [sp, #0x48]
    4928:      	ldr	w8, [x8, #0x6c]
    492c:      	cbnz	w8, 0x498c <generic_kprobe_process_filter+0xe6c>
    4930:      	ldr	x11, [sp, #0x48]
    4934:      	and	w13, w1, #0x7f
    4938:      	mov	x8, xzr
    493c:      	ldr	w12, [x11, #0x68]
    4940:      	add	x9, x11, #0x1f0
    4944:      	add	x10, x11, #0x170
    4948:      	sub	w11, w12, w1
    494c:      	add	w12, w12, w13
    4950:      	add	w11, w11, w13
    4954:      	mvn	w13, w1
    4958:      	add	w12, w13, w12
    495c:      	cmp	x8, #0x7f
    4960:      	b.eq	0x4980 <generic_kprobe_process_filter+0xe60>
    4964:      	and	x13, x12, #0x7f
    4968:      	sub	w12, w12, #0x1
    496c:      	ldrb	w13, [x10, x13]
    4970:      	strb	w13, [x9, x8]
    4974:      	add	x8, x8, #0x1
    4978:      	cmp	x11, x8
    497c:      	b.ne	0x495c <generic_kprobe_process_filter+0xe3c>
    4980:      	ldr	x9, [sp, #0x48]
    4984:      	mov	w8, #0x1                // =1
    4988:      	str	w8, [x9, #0x6c]
    498c:      	cmp	w1, #0x7f
    4990:      	b.hi	0x49ac <generic_kprobe_process_filter+0xe8c>
    4994:      	ldr	x8, [sp, #0x48]
    4998:      	add	x0, x29, #0x4
    499c:      	add	x2, x8, #0x1f0
    49a0:      	mov	w8, #0x4                // =4
    49a4:      	blr	x8
    49a8:      	tbnz	x0, #0x3f, 0x599c <generic_kprobe_process_filter+0x1e7c>
    49ac:      	mov	w8, #0x1                // =1
    49b0:      	mov	x0, x20
    49b4:      	b	0x4a8c <generic_kprobe_process_filter+0xf6c>
    49b8:      	ldr	w8, [x24]
    49bc:      	str	w8, [x20, #0x10]
    49c0:      	ldr	x8, [x24, #0x8]
    49c4:      	str	x8, [x20, #0x18]
    49c8:      	ldrb	w8, [x29]
    49cc:      	cbnz	w8, 0x59d8 <generic_kprobe_process_filter+0x1eb8>
    49d0:      	b	0x59f4 <generic_kprobe_process_filter+0x1ed4>
    49d4:      	mov	w8, #0x1                // =1
    49d8:      	strb	w8, [x29]
    49dc:      	ldr	w8, [x24]
    49e0:      	str	w8, [x20, #0x10]
    49e4:      	ldr	x8, [x24, #0x8]
    49e8:      	str	x8, [x20, #0x18]
    49ec:      	b	0x59d8 <generic_kprobe_process_filter+0x1eb8>
    49f0:      	mov	w8, #0x2964             // =10596
    49f4:      	add	x20, x24, #0xff6
    49f8:      	strh	w8, [x24, #0xffe]
    49fc:      	adrp	x8, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4a00:      	add	x8, x8, #0x0
    4a04:      	ldr	x8, [x8]
    4a08:      	str	x8, [x20]
    4a0c:      	b	0x4260 <generic_kprobe_process_filter+0x740>
    4a10:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4a14:      	add	x1, x25, #0x4
    4a18:      	mov	w8, #0x1                // =1
    4a1c:      	ldr	x0, [x0]
    4a20:      	blr	x8
    4a24:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4a28:      	mov	x19, x0
    4a2c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4a30:      	mov	w8, #0x1                // =1
    4a34:      	ldr	x0, [x0]
    4a38:      	add	x9, sp, #0xc8
    4a3c:      	add	x1, sp, #0xc8
    4a40:      	blr	x8
    4a44:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4a48:      	mov	w1, wzr
    4a4c:      	mov	w2, #0x104              // =260
    4a50:      	mov	x29, x0
    4a54:      	bl	0x4a54 <generic_kprobe_process_filter+0xf34>
    4a58:      	ldr	x10, [sp, #0x48]
    4a5c:      	mov	x0, x29
    4a60:      	ldr	w8, [x10, #0x68]
    4a64:      	add	x2, x10, #0x70
    4a68:      	lsl	w9, w8, #3
    4a6c:      	and	x8, x8, #0xff
    4a70:      	str	w9, [x0], #0x4
    4a74:      	mov	w9, #0x4                // =4
    4a78:      	ldrb	w1, [x10, #0x68]
    4a7c:      	blr	x9
    4a80:      	tbnz	x0, #0x3f, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4a84:      	mov	w8, #0x1                // =1
    4a88:      	mov	x0, x19
    4a8c:      	mov	x1, x29
    4a90:      	b	0x4ae8 <generic_kprobe_process_filter+0xfc8>
    4a94:      	ldr	w8, [x25, #0x8]
    4a98:      	cmn	w8, #0x1
    4a9c:      	b.eq	0x4ac0 <generic_kprobe_process_filter+0xfa0>
    4aa0:      	ldr	x9, [sp, #0x48]
    4aa4:      	ldr	x9, [x9, #0x370]
    4aa8:      	lsr	x8, x9, x8
    4aac:      	tbz	w8, #0x0, 0x4ac0 <generic_kprobe_process_filter+0xfa0>
    4ab0:      	mov	x0, #0xffee             // =65518
    4ab4:      	movk	x0, #0xadc0, lsl #16
    4ab8:      	movk	x0, #0xb, lsl #32
    4abc:      	b	0x4aec <generic_kprobe_process_filter+0xfcc>
    4ac0:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4ac4:      	mov	w8, #0x1                // =1
    4ac8:      	add	x9, sp, #0x58
    4acc:      	ldr	x0, [x0]
    4ad0:      	add	x1, sp, #0x58
    4ad4:      	blr	x8
    4ad8:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4adc:      	ldr	x8, [sp, #0x48]
    4ae0:      	add	x1, x8, #0x70
    4ae4:      	mov	w8, #0x1                // =1
    4ae8:      	blr	x8
    4aec:      	ldr	w8, [x25]
    4af0:      	cmp	w8, #0x25
    4af4:      	b.hi	0x4b1c <generic_kprobe_process_filter+0xffc>
    4af8:      	mov	w9, #0x1                // =1
    4afc:      	lsl	x8, x9, x8
    4b00:      	mov	x9, #0x50               // =80
    4b04:      	movk	x9, #0xc00, lsl #16
    4b08:      	movk	x9, #0x20, lsl #32
    4b0c:      	tst	x8, x9
    4b10:      	b.eq	0x4b1c <generic_kprobe_process_filter+0xffc>
    4b14:      	cbnz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4b18:      	b	0x4b20 <generic_kprobe_process_filter+0x1000>
    4b1c:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4b20:      	adrp	x8, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4b24:      	ldr	x8, [x8]
    4b28:      	ldrb	w8, [x8]
    4b2c:      	cbz	w8, 0x4da4 <generic_kprobe_process_filter+0x1284>
    4b30:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4b34:      	mov	w8, #0x1                // =1
    4b38:      	ldr	x0, [x0]
    4b3c:      	ldr	x1, [sp, #0x48]
    4b40:      	blr	x8
    4b44:      	cbz	x0, 0x4da4 <generic_kprobe_process_filter+0x1284>
    4b48:      	add	w8, w21, #0x5
    4b4c:      	str	wzr, [sp, #0xc8]
    4b50:      	add	x9, sp, #0x58
    4b54:      	mov	x25, x0
    4b58:      	str	w8, [sp, #0x58]
    4b5c:      	mov	w8, #0x1                // =1
    4b60:      	add	x1, sp, #0x58
    4b64:      	mov	x0, x24
    4b68:      	blr	x8
    4b6c:      	cbz	x0, 0x4da4 <generic_kprobe_process_filter+0x1284>
    4b70:      	ldr	w8, [x0]
    4b74:      	mov	x24, x0
    4b78:      	cbz	w8, 0x4da4 <generic_kprobe_process_filter+0x1284>
    4b7c:      	ldr	w9, [x25]
    4b80:      	tbnz	w9, #0x1f, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4b84:      	cmp	w8, #0x1b
    4b88:      	b.hi	0x599c <generic_kprobe_process_filter+0x1e7c>
    4b8c:      	mov	w9, #0x1                // =1
    4b90:      	lsl	w9, w9, w8
    4b94:      	tst	w9, #0x60
    4b98:      	b.ne	0x4d20 <generic_kprobe_process_filter+0x1200>
    4b9c:      	mov	w10, #0x100             // =256
    4ba0:      	movk	w10, #0x400, lsl #16
    4ba4:      	tst	w9, w10
    4ba8:      	b.ne	0x4ca0 <generic_kprobe_process_filter+0x1180>
    4bac:      	mov	w9, #0x1                // =1
    4bb0:      	lsl	w8, w9, w8
    4bb4:      	mov	w9, #0x200              // =512
    4bb8:      	movk	w9, #0x800, lsl #16
    4bbc:      	tst	w8, w9
    4bc0:      	b.eq	0x599c <generic_kprobe_process_filter+0x1e7c>
    4bc4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4bc8:      	add	x1, x24, #0x4
    4bcc:      	mov	w8, #0x1                // =1
    4bd0:      	ldr	x0, [x0]
    4bd4:      	blr	x8
    4bd8:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4bdc:      	ldr	w8, [x25]
    4be0:      	mov	x20, x0
    4be4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4be8:      	mov	w9, #0x7f               // =127
    4bec:      	ldr	x0, [x0]
    4bf0:      	add	x1, sp, #0xc8
    4bf4:      	cmp	w8, #0x7f
    4bf8:      	csel	w19, w8, w9, lt
    4bfc:      	mov	w8, #0x1                // =1
    4c00:      	add	x9, sp, #0xc8
    4c04:      	blr	x8
    4c08:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4c0c:      	sxtw	x1, w19
    4c10:      	mov	x29, x0
    4c14:      	lsl	w8, w1, #3
    4c18:      	str	w8, [x0]
    4c1c:      	ldr	w8, [x25, #0x4]
    4c20:      	cbnz	w8, 0x4c78 <generic_kprobe_process_filter+0x1158>
    4c24:      	ldr	w12, [x25]
    4c28:      	and	w13, w1, #0x7f
    4c2c:      	mov	x8, xzr
    4c30:      	add	x9, x25, #0x188
    4c34:      	add	x10, x25, #0x108
    4c38:      	sub	w11, w12, w1
    4c3c:      	add	w12, w12, w13
    4c40:      	add	w11, w11, w13
    4c44:      	mvn	w13, w1
    4c48:      	add	w12, w13, w12
    4c4c:      	cmp	x8, #0x7f
    4c50:      	b.eq	0x4c70 <generic_kprobe_process_filter+0x1150>
    4c54:      	and	x13, x12, #0x7f
    4c58:      	sub	w12, w12, #0x1
    4c5c:      	ldrb	w13, [x10, x13]
    4c60:      	strb	w13, [x9, x8]
    4c64:      	add	x8, x8, #0x1
    4c68:      	cmp	x11, x8
    4c6c:      	b.ne	0x4c4c <generic_kprobe_process_filter+0x112c>
    4c70:      	mov	w8, #0x1                // =1
    4c74:      	str	w8, [x25, #0x4]
    4c78:      	cmp	w1, #0x7f
    4c7c:      	b.hi	0x4c94 <generic_kprobe_process_filter+0x1174>
    4c80:      	add	x0, x29, #0x4
    4c84:      	add	x2, x25, #0x188
    4c88:      	mov	w8, #0x4                // =4
    4c8c:      	blr	x8
    4c90:      	tbnz	x0, #0x3f, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4c94:      	mov	w8, #0x1                // =1
    4c98:      	mov	x0, x20
    4c9c:      	b	0x4d18 <generic_kprobe_process_filter+0x11f8>
    4ca0:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4ca4:      	add	x1, x24, #0x4
    4ca8:      	mov	w8, #0x1                // =1
    4cac:      	ldr	x0, [x0]
    4cb0:      	blr	x8
    4cb4:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4cb8:      	mov	x19, x0
    4cbc:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4cc0:      	mov	w8, #0x1                // =1
    4cc4:      	ldr	x0, [x0]
    4cc8:      	add	x9, sp, #0xc8
    4ccc:      	add	x1, sp, #0xc8
    4cd0:      	blr	x8
    4cd4:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4cd8:      	mov	w1, wzr
    4cdc:      	mov	w2, #0x104              // =260
    4ce0:      	mov	x29, x0
    4ce4:      	bl	0x4ce4 <generic_kprobe_process_filter+0x11c4>
    4ce8:      	ldr	w8, [x25]
    4cec:      	mov	x0, x29
    4cf0:      	add	x2, x25, #0x8
    4cf4:      	lsl	w9, w8, #3
    4cf8:      	and	x8, x8, #0xff
    4cfc:      	str	w9, [x0], #0x4
    4d00:      	mov	w9, #0x4                // =4
    4d04:      	ldrb	w1, [x25]
    4d08:      	blr	x9
    4d0c:      	tbnz	x0, #0x3f, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4d10:      	mov	w8, #0x1                // =1
    4d14:      	mov	x0, x19
    4d18:      	mov	x1, x29
    4d1c:      	b	0x4d6c <generic_kprobe_process_filter+0x124c>
    4d20:      	ldr	w8, [x24, #0x8]
    4d24:      	cmn	w8, #0x1
    4d28:      	b.eq	0x4d48 <generic_kprobe_process_filter+0x1228>
    4d2c:      	ldr	x9, [x25, #0x308]
    4d30:      	lsr	x8, x9, x8
    4d34:      	tbz	w8, #0x0, 0x4d48 <generic_kprobe_process_filter+0x1228>
    4d38:      	mov	x0, #0xffee             // =65518
    4d3c:      	movk	x0, #0xadc0, lsl #16
    4d40:      	movk	x0, #0xb, lsl #32
    4d44:      	b	0x4d70 <generic_kprobe_process_filter+0x1250>
    4d48:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4d4c:      	mov	w8, #0x1                // =1
    4d50:      	add	x9, sp, #0x58
    4d54:      	ldr	x0, [x0]
    4d58:      	add	x1, sp, #0x58
    4d5c:      	blr	x8
    4d60:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4d64:      	add	x1, x25, #0x8
    4d68:      	mov	w8, #0x1                // =1
    4d6c:      	blr	x8
    4d70:      	ldr	w8, [x24]
    4d74:      	cmp	w8, #0x25
    4d78:      	b.hi	0x4da0 <generic_kprobe_process_filter+0x1280>
    4d7c:      	mov	w9, #0x1                // =1
    4d80:      	lsl	x8, x9, x8
    4d84:      	mov	x9, #0x50               // =80
    4d88:      	movk	x9, #0xc00, lsl #16
    4d8c:      	movk	x9, #0x20, lsl #32
    4d90:      	tst	x8, x9
    4d94:      	b.eq	0x4da0 <generic_kprobe_process_filter+0x1280>
    4d98:      	cbnz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4d9c:      	b	0x4da4 <generic_kprobe_process_filter+0x1284>
    4da0:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    4da4:      	lsl	w8, w21, #2
    4da8:      	add	x9, x8, #0x4
    4dac:      	ldr	w8, [x9, x23]
    4db0:      	add	w9, w8, w9
    4db4:      	and	w11, w9, #0x3ff
    4db8:      	add	w9, w9, #0x4
    4dbc:      	and	x9, x9, #0x3ff
    4dc0:      	add	x10, x11, #0x8
    4dc4:      	ldr	w9, [x9, x23]
    4dc8:      	cmp	w9, #0x5
    4dcc:      	b.lo	0x4e5c <generic_kprobe_process_filter+0x133c>
    4dd0:      	add	x9, x10, x23
    4dd4:      	ldr	w10, [x9, #0x8]
    4dd8:      	ldp	w12, w22, [x9]
    4ddc:      	stp	x9, x11, [sp, #0x8]
    4de0:      	mov	w9, #0x4                // =4
    4de4:      	cmp	w10, #0x4
    4de8:      	stp	xzr, xzr, [sp, #0x58]
    4dec:      	csel	w9, w10, w9, lo
    4df0:      	cmp	w12, #0x6
    4df4:      	b.ne	0x4e00 <generic_kprobe_process_filter+0x12e0>
    4df8:      	mov	x11, #0x100000001       // =4294967297
    4dfc:      	stp	x11, x11, [sp, #0x58]
    4e00:      	cbz	w10, 0x5264 <generic_kprobe_process_filter+0x1744>
    4e04:      	ldr	x10, [sp, #0x48]
    4e08:      	add	w8, w8, w21, lsl #2
    4e0c:      	tst	x22, #0x1
    4e10:      	add	x25, sp, #0x58
    4e14:      	str	w12, [sp, #0x30]
    4e18:      	add	w8, w8, #0x4
    4e1c:      	and	x8, x8, #0x3ff
    4e20:      	add	x21, x8, #0x14
    4e24:      	sub	x8, x9, #0x1
    4e28:      	mov	w9, #0x3                // =3
    4e2c:      	add	x11, x10, #0x24
    4e30:      	str	x11, [sp, #0x20]
    4e34:      	csel	x11, x10, x11, eq
    4e38:      	cmp	x8, #0x3
    4e3c:      	add	x10, x10, #0x10
    4e40:      	csel	x8, x8, x9, lo
    4e44:      	and	x9, x21, #0x7fc
    4e48:      	mov	x20, x11
    4e4c:      	str	x10, [sp, #0x18]
    4e50:      	add	x24, x23, x9
    4e54:      	add	x19, x8, #0x1
    4e58:      	b	0x4e94 <generic_kprobe_process_filter+0x1374>
    4e5c:      	mov	w9, #0x1                // =1
    4e60:      	mov	w8, w10
    4e64:      	b	0x52ac <generic_kprobe_process_filter+0x178c>
    4e68:      	mov	w8, #0x1                // =1
    4e6c:      	ldr	w12, [sp, #0x30]
    4e70:      	mov	x11, x20
    4e74:      	cmp	w12, #0x6
    4e78:      	eor	w8, w8, #0x1
    4e7c:      	csinc	w9, w8, wzr, eq
    4e80:      	str	w9, [x25], #0x4
    4e84:      	add	x21, x21, #0x4
    4e88:      	add	x24, x24, #0x4
    4e8c:      	subs	x19, x19, #0x1
    4e90:      	b.eq	0x5264 <generic_kprobe_process_filter+0x1744>
    4e94:      	cmp	x21, #0x3e8
    4e98:      	b.ls	0x50bc <generic_kprobe_process_filter+0x159c>
    4e9c:      	mov	x29, xzr
    4ea0:      	tbz	w22, #0x1, 0x50c4 <generic_kprobe_process_filter+0x15a4>
    4ea4:      	tbnz	w22, #0x0, 0x50f0 <generic_kprobe_process_filter+0x15d0>
    4ea8:      	ldr	x10, [sp, #0x48]
    4eac:      	mov	w8, #0x1                // =1
    4eb0:      	ldr	w9, [x10]
    4eb4:      	cmp	x29, x9
    4eb8:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4ebc:      	ldr	w9, [x10, #0x10]
    4ec0:      	cmp	x29, x9
    4ec4:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4ec8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4ecc:      	mov	w8, #0x1                // =1
    4ed0:      	ldr	x0, [x0]
    4ed4:      	ldr	x1, [sp, #0x18]
    4ed8:      	blr	x8
    4edc:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    4ee0:      	ldr	w9, [x0]
    4ee4:      	mov	x1, x0
    4ee8:      	mov	w8, #0x1                // =1
    4eec:      	cmp	x29, x9
    4ef0:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    4ef4:      	ldr	w9, [x1, #0x10]!
    4ef8:      	ldr	w12, [sp, #0x30]
    4efc:      	mov	x11, x20
    4f00:      	cmp	x29, x9
    4f04:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4f08:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4f0c:      	mov	w8, #0x1                // =1
    4f10:      	ldr	x0, [x0]
    4f14:      	blr	x8
    4f18:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    4f1c:      	ldr	w9, [x0]
    4f20:      	mov	x1, x0
    4f24:      	mov	w8, #0x1                // =1
    4f28:      	cmp	x29, x9
    4f2c:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    4f30:      	ldr	w9, [x1, #0x10]!
    4f34:      	ldr	w12, [sp, #0x30]
    4f38:      	mov	x11, x20
    4f3c:      	cmp	x29, x9
    4f40:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4f44:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4f48:      	mov	w8, #0x1                // =1
    4f4c:      	ldr	x0, [x0]
    4f50:      	blr	x8
    4f54:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    4f58:      	ldr	w9, [x0]
    4f5c:      	mov	x1, x0
    4f60:      	mov	w8, #0x1                // =1
    4f64:      	cmp	x29, x9
    4f68:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    4f6c:      	ldr	w9, [x1, #0x10]!
    4f70:      	ldr	w12, [sp, #0x30]
    4f74:      	mov	x11, x20
    4f78:      	cmp	x29, x9
    4f7c:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4f80:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4f84:      	mov	w8, #0x1                // =1
    4f88:      	ldr	x0, [x0]
    4f8c:      	blr	x8
    4f90:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    4f94:      	ldr	w9, [x0]
    4f98:      	mov	x1, x0
    4f9c:      	mov	w8, #0x1                // =1
    4fa0:      	cmp	x29, x9
    4fa4:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    4fa8:      	ldr	w9, [x1, #0x10]!
    4fac:      	ldr	w12, [sp, #0x30]
    4fb0:      	mov	x11, x20
    4fb4:      	cmp	x29, x9
    4fb8:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4fbc:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4fc0:      	mov	w8, #0x1                // =1
    4fc4:      	ldr	x0, [x0]
    4fc8:      	blr	x8
    4fcc:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    4fd0:      	ldr	w9, [x0]
    4fd4:      	mov	x1, x0
    4fd8:      	mov	w8, #0x1                // =1
    4fdc:      	cmp	x29, x9
    4fe0:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    4fe4:      	ldr	w9, [x1, #0x10]!
    4fe8:      	ldr	w12, [sp, #0x30]
    4fec:      	mov	x11, x20
    4ff0:      	cmp	x29, x9
    4ff4:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    4ff8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0x4e0>
    4ffc:      	mov	w8, #0x1                // =1
    5000:      	ldr	x0, [x0]
    5004:      	blr	x8
    5008:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    500c:      	ldr	w9, [x0]
    5010:      	mov	x1, x0
    5014:      	mov	w8, #0x1                // =1
    5018:      	cmp	x29, x9
    501c:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    5020:      	ldr	w9, [x1, #0x10]!
    5024:      	ldr	w12, [sp, #0x30]
    5028:      	mov	x11, x20
    502c:      	cmp	x29, x9
    5030:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    5034:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5038:      	mov	w8, #0x1                // =1
    503c:      	ldr	x0, [x0]
    5040:      	blr	x8
    5044:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    5048:      	ldr	w9, [x0]
    504c:      	mov	x1, x0
    5050:      	mov	w8, #0x1                // =1
    5054:      	cmp	x29, x9
    5058:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    505c:      	ldr	w9, [x1, #0x10]!
    5060:      	ldr	w12, [sp, #0x30]
    5064:      	mov	x11, x20
    5068:      	cmp	x29, x9
    506c:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    5070:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5074:      	mov	w8, #0x1                // =1
    5078:      	ldr	x0, [x0]
    507c:      	blr	x8
    5080:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    5084:      	ldr	w9, [x0]
    5088:      	mov	x1, x0
    508c:      	mov	w8, #0x1                // =1
    5090:      	cmp	x29, x9
    5094:      	b.eq	0x4e6c <generic_kprobe_process_filter+0x134c>
    5098:      	ldr	w9, [x1, #0x10]!
    509c:      	ldr	w12, [sp, #0x30]
    50a0:      	mov	x11, x20
    50a4:      	cmp	x29, x9
    50a8:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    50ac:      	adrp	x9, 0x5000 <generic_kprobe_process_filter+0x14e0>
    50b0:      	mov	w8, #0x1                // =1
    50b4:      	ldr	x9, [x9]
    50b8:      	b	0x523c <generic_kprobe_process_filter+0x171c>
    50bc:      	ldr	w29, [x24]
    50c0:      	tbnz	w22, #0x1, 0x4ea4 <generic_kprobe_process_filter+0x1384>
    50c4:      	ldr	w8, [x11]
    50c8:      	cmp	w12, #0x5
    50cc:      	b.ne	0x50e0 <generic_kprobe_process_filter+0x15c0>
    50d0:      	cmp	x29, x8
    50d4:      	b.eq	0x50e0 <generic_kprobe_process_filter+0x15c0>
    50d8:      	mov	w9, wzr
    50dc:      	b	0x4e80 <generic_kprobe_process_filter+0x1360>
    50e0:      	cmp	w12, #0x6
    50e4:      	ccmp	x29, x8, #0x0, eq
    50e8:      	cset	w9, ne
    50ec:      	b	0x4e80 <generic_kprobe_process_filter+0x1360>
    50f0:      	ldr	x8, [sp, #0x20]
    50f4:      	ldr	w9, [x8]
    50f8:      	cbz	w9, 0x4e80 <generic_kprobe_process_filter+0x1360>
    50fc:      	mov	w8, #0x1                // =1
    5100:      	cbz	x29, 0x4e74 <generic_kprobe_process_filter+0x1354>
    5104:      	cmp	x29, x9
    5108:      	b.eq	0x4e74 <generic_kprobe_process_filter+0x1354>
    510c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5110:      	mov	w8, #0x1                // =1
    5114:      	ldr	x0, [x0]
    5118:      	ldr	x1, [sp, #0x18]
    511c:      	blr	x8
    5120:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    5124:      	ldr	w8, [x0, #0x24]
    5128:      	cmp	x29, x8
    512c:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    5130:      	add	x1, x0, #0x10
    5134:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5138:      	mov	w8, #0x1                // =1
    513c:      	ldr	x0, [x0]
    5140:      	blr	x8
    5144:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    5148:      	ldr	w8, [x0, #0x24]
    514c:      	cmp	x29, x8
    5150:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    5154:      	add	x1, x0, #0x10
    5158:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    515c:      	mov	w8, #0x1                // =1
    5160:      	ldr	x0, [x0]
    5164:      	blr	x8
    5168:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    516c:      	ldr	w8, [x0, #0x24]
    5170:      	cmp	x29, x8
    5174:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    5178:      	add	x1, x0, #0x10
    517c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5180:      	mov	w8, #0x1                // =1
    5184:      	ldr	x0, [x0]
    5188:      	blr	x8
    518c:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    5190:      	ldr	w8, [x0, #0x24]
    5194:      	cmp	x29, x8
    5198:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    519c:      	add	x1, x0, #0x10
    51a0:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    51a4:      	mov	w8, #0x1                // =1
    51a8:      	ldr	x0, [x0]
    51ac:      	blr	x8
    51b0:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    51b4:      	ldr	w8, [x0, #0x24]
    51b8:      	cmp	x29, x8
    51bc:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    51c0:      	add	x1, x0, #0x10
    51c4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    51c8:      	mov	w8, #0x1                // =1
    51cc:      	ldr	x0, [x0]
    51d0:      	blr	x8
    51d4:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    51d8:      	ldr	w8, [x0, #0x24]
    51dc:      	cmp	x29, x8
    51e0:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    51e4:      	add	x1, x0, #0x10
    51e8:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    51ec:      	mov	w8, #0x1                // =1
    51f0:      	ldr	x0, [x0]
    51f4:      	blr	x8
    51f8:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    51fc:      	ldr	w8, [x0, #0x24]
    5200:      	cmp	x29, x8
    5204:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    5208:      	add	x1, x0, #0x10
    520c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5210:      	mov	w8, #0x1                // =1
    5214:      	ldr	x0, [x0]
    5218:      	blr	x8
    521c:      	cbz	x0, 0x5248 <generic_kprobe_process_filter+0x1728>
    5220:      	ldr	w8, [x0, #0x24]
    5224:      	cmp	x29, x8
    5228:      	b.eq	0x4e68 <generic_kprobe_process_filter+0x1348>
    522c:      	adrp	x9, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5230:      	add	x1, x0, #0x10
    5234:      	mov	w8, #0x1                // =1
    5238:      	ldr	x9, [x9]
    523c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5240:      	ldr	x0, [x0]
    5244:      	blr	x8
    5248:      	ldr	w12, [sp, #0x30]
    524c:      	mov	w8, wzr
    5250:      	mov	w9, wzr
    5254:      	mov	x11, x20
    5258:      	cmp	w12, #0x5
    525c:      	b.ne	0x4e74 <generic_kprobe_process_filter+0x1354>
    5260:      	b	0x4e80 <generic_kprobe_process_filter+0x1360>
    5264:      	ldp	w8, w9, [sp, #0x58]
    5268:      	ldp	w10, w11, [sp, #0x60]
    526c:      	cmp	w12, #0x6
    5270:      	b.ne	0x5284 <generic_kprobe_process_filter+0x1764>
    5274:      	and	w8, w9, w8
    5278:      	and	w9, w10, w11
    527c:      	and	w9, w8, w9
    5280:      	b	0x5290 <generic_kprobe_process_filter+0x1770>
    5284:      	orr	w8, w9, w8
    5288:      	orr	w9, w10, w11
    528c:      	orr	w9, w8, w9
    5290:      	ldr	x8, [sp, #0x10]
    5294:      	cbz	w9, 0x599c <generic_kprobe_process_filter+0x1e7c>
    5298:      	ldr	x10, [sp, #0x8]
    529c:      	add	w8, w8, #0x14
    52a0:      	ldr	w10, [x10, #0x8]
    52a4:      	ubfiz	w10, w10, #2, #3
    52a8:      	add	w8, w10, w8
    52ac:      	and	x10, x8, #0x3ff
    52b0:      	add	w8, w8, #0x4
    52b4:      	mov	w19, #0xa               // =10
    52b8:      	ldr	w10, [x10, x23]
    52bc:      	mov	w20, #0x4               // =4
    52c0:      	mov	x25, #0x100000001       // =4294967297
    52c4:      	sub	w22, w10, #0x4
    52c8:      	ldr	x10, [sp, #0xe8]
    52cc:      	add	x10, x10, #0x20
    52d0:      	str	x10, [sp, #0x30]
    52d4:      	b	0x52ec <generic_kprobe_process_filter+0x17cc>
    52d8:      	orr	w8, w9, w8
    52dc:      	orr	w9, w10, w11
    52e0:      	orr	w9, w8, w9
    52e4:      	cbnz	w9, 0x54a0 <generic_kprobe_process_filter+0x1980>
    52e8:      	b	0x599c <generic_kprobe_process_filter+0x1e7c>
    52ec:      	cbz	w22, 0x54b4 <generic_kprobe_process_filter+0x1994>
    52f0:      	and	x9, x8, #0x3ff
    52f4:      	add	x10, x9, x23
    52f8:      	ldr	w29, [x10, #0x8]
    52fc:      	ldp	w9, w24, [x10]
    5300:      	stp	xzr, xzr, [sp, #0x58]
    5304:      	cmp	w29, #0x4
    5308:      	csel	w10, w29, w20, lo
    530c:      	cmp	w24, #0x6
    5310:      	b.ne	0x5318 <generic_kprobe_process_filter+0x17f8>
    5314:      	stp	x25, x25, [sp, #0x58]
    5318:      	add	w21, w8, #0xc
    531c:      	cbz	w29, 0x5480 <generic_kprobe_process_filter+0x1960>
    5320:      	and	x9, x9, #0xf
    5324:      	cmp	w9, #0xa
    5328:      	b.lo	0x5354 <generic_kprobe_process_filter+0x1834>
    532c:      	sub	x8, x10, #0x1
    5330:      	mov	w9, #0x3                // =3
    5334:      	add	x0, sp, #0x58
    5338:      	mov	w1, wzr
    533c:      	cmp	x8, #0x3
    5340:      	csel	x8, x8, x9, lo
    5344:      	lsl	x8, x8, #2
    5348:      	add	x2, x8, #0x4
    534c:      	bl	0x534c <generic_kprobe_process_filter+0x182c>
    5350:      	b	0x5480 <generic_kprobe_process_filter+0x1960>
    5354:      	cmp	w21, #0x3e8
    5358:      	b.ls	0x5364 <generic_kprobe_process_filter+0x1844>
    535c:      	mov	w11, wzr
    5360:      	b	0x536c <generic_kprobe_process_filter+0x184c>
    5364:      	and	w11, w21, #0xfffffffc
    5368:      	ldr	w11, [x23, w11, uxtw]
    536c:      	ldr	x12, [sp, #0x30]
    5370:      	cmp	w24, #0x5
    5374:      	sub	x10, x10, #0x1
    5378:      	ldr	w9, [x12, x9, lsl #2]
    537c:      	cset	w12, ne
    5380:      	cmp	w24, #0x6
    5384:      	cset	w13, ne
    5388:      	cmp	w11, w9
    538c:      	csinc	w11, w12, wzr, ne
    5390:      	csinc	w12, w13, wzr, eq
    5394:      	and	w11, w11, w12
    5398:      	str	w11, [sp, #0x58]
    539c:      	cbz	x10, 0x5480 <generic_kprobe_process_filter+0x1960>
    53a0:      	add	w11, w8, #0x10
    53a4:      	cmp	w11, #0x3e8
    53a8:      	b.ls	0x53b4 <generic_kprobe_process_filter+0x1894>
    53ac:      	mov	w11, wzr
    53b0:      	b	0x53bc <generic_kprobe_process_filter+0x189c>
    53b4:      	and	w11, w11, #0xfffffffc
    53b8:      	ldr	w11, [x23, w11, uxtw]
    53bc:      	cmp	w24, #0x5
    53c0:      	cset	w12, ne
    53c4:      	cmp	w24, #0x6
    53c8:      	cset	w13, ne
    53cc:      	cmp	w11, w9
    53d0:      	csinc	w11, w12, wzr, ne
    53d4:      	csinc	w12, w13, wzr, eq
    53d8:      	cmp	x10, #0x1
    53dc:      	and	w11, w11, w12
    53e0:      	str	w11, [sp, #0x5c]
    53e4:      	b.eq	0x5480 <generic_kprobe_process_filter+0x1960>
    53e8:      	add	w11, w8, #0x14
    53ec:      	cmp	w11, #0x3e8
    53f0:      	b.ls	0x53fc <generic_kprobe_process_filter+0x18dc>
    53f4:      	mov	w11, wzr
    53f8:      	b	0x5404 <generic_kprobe_process_filter+0x18e4>
    53fc:      	and	w11, w11, #0xfffffffc
    5400:      	ldr	w11, [x23, w11, uxtw]
    5404:      	cmp	w24, #0x5
    5408:      	cset	w12, ne
    540c:      	cmp	w24, #0x6
    5410:      	cset	w13, ne
    5414:      	cmp	w11, w9
    5418:      	csinc	w11, w12, wzr, ne
    541c:      	csinc	w12, w13, wzr, eq
    5420:      	cmp	x10, #0x2
    5424:      	and	w11, w11, w12
    5428:      	str	w11, [sp, #0x60]
    542c:      	b.eq	0x5480 <generic_kprobe_process_filter+0x1960>
    5430:      	add	w8, w8, #0x18
    5434:      	cmp	w8, #0x3e8
    5438:      	b.ls	0x5444 <generic_kprobe_process_filter+0x1924>
    543c:      	mov	w8, wzr
    5440:      	b	0x544c <generic_kprobe_process_filter+0x192c>
    5444:      	and	w8, w8, #0xfffffffc
    5448:      	ldr	w8, [x23, w8, uxtw]
    544c:      	cmp	w24, #0x5
    5450:      	cset	w10, ne
    5454:      	cmp	w24, #0x6
    5458:      	cset	w11, ne
    545c:      	cmp	w8, w9
    5460:      	csinc	w8, w10, wzr, ne
    5464:      	csinc	w9, w11, wzr, eq
    5468:      	and	w8, w8, w9
    546c:      	str	w8, [sp, #0x64]
    5470:      	nop
    5474:      	nop
    5478:      	nop
    547c:      	nop
    5480:      	ldp	w8, w9, [sp, #0x58]
    5484:      	ldp	w10, w11, [sp, #0x60]
    5488:      	cmp	w24, #0x6
    548c:      	b.ne	0x52d8 <generic_kprobe_process_filter+0x17b8>
    5490:      	and	w8, w9, w8
    5494:      	and	w9, w10, w11
    5498:      	and	w9, w8, w9
    549c:      	cbz	w9, 0x599c <generic_kprobe_process_filter+0x1e7c>
    54a0:      	lsl	w8, w29, #2
    54a4:      	sub	w10, w22, w29, lsl #2
    54a8:      	and	w8, w8, #0x1c
    54ac:      	sub	w22, w10, #0xc
    54b0:      	add	w8, w8, w21
    54b4:      	subs	x19, x19, #0x1
    54b8:      	b.ne	0x52ec <generic_kprobe_process_filter+0x17cc>
    54bc:      	mov	w10, w8
    54c0:      	add	w19, w8, #0x4
    54c4:      	and	x10, x10, #0x3ff
    54c8:      	ldr	w10, [x10, x23]
    54cc:      	cmp	w10, #0x4
    54d0:      	b.ne	0x5568 <generic_kprobe_process_filter+0x1a48>
    54d4:      	cbz	w9, 0x599c <generic_kprobe_process_filter+0x1e7c>
    54d8:      	mov	w8, w19
    54dc:      	and	x8, x8, #0x3ff
    54e0:      	ldr	w9, [x8, x23]
    54e4:      	add	w8, w19, #0x4
    54e8:      	cmp	w9, #0x4
    54ec:      	mov	w9, w8
    54f0:      	b.eq	0x5898 <generic_kprobe_process_filter+0x1d78>
    54f4:      	and	x8, x8, #0x3ff
    54f8:      	add	x8, x8, x23
    54fc:      	ldp	w20, w22, [x8]
    5500:      	mov	w8, #0xe                // =14
    5504:      	blr	x8
    5508:      	lsr	x8, x0, #32
    550c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5510:      	add	x9, sp, #0x58
    5514:      	str	w8, [sp, #0x58]
    5518:      	mov	w8, #0x1                // =1
    551c:      	add	x1, sp, #0x58
    5520:      	ldr	x0, [x0]
    5524:      	blr	x8
    5528:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    552c:      	cmp	w20, #0x5
    5530:      	b.eq	0x55e4 <generic_kprobe_process_filter+0x1ac4>
    5534:      	cmp	w20, #0x6
    5538:      	b.ne	0x599c <generic_kprobe_process_filter+0x1e7c>
    553c:      	ldr	x11, [sp, #0xe8]
    5540:      	mov	w8, #0x5ee8             // =24296
    5544:      	add	x8, x11, x8
    5548:      	tbnz	w22, #0x0, 0x5618 <generic_kprobe_process_filter+0x1af8>
    554c:      	ldr	w9, [x0, #0x28]
    5550:      	cbz	w9, 0x5610 <generic_kprobe_process_filter+0x1af0>
    5554:      	ldr	x10, [sp, #0x30]
    5558:      	ldr	w10, [x10]
    555c:      	cmp	w9, w10
    5560:      	b.eq	0x5618 <generic_kprobe_process_filter+0x1af8>
    5564:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5568:      	and	x9, x19, #0x3ff
    556c:      	add	w19, w8, #0x18
    5570:      	add	x9, x9, x23
    5574:      	ldp	w8, w10, [x9]
    5578:      	ldr	w12, [x9, #0x8]
    557c:      	ldur	x11, [x9, #0xc]
    5580:      	cbz	w12, 0x55a4 <generic_kprobe_process_filter+0x1a84>
    5584:      	ldr	x14, [sp, #0xe8]
    5588:      	mov	w9, wzr
    558c:      	cmp	w8, #0x2
    5590:      	b.hi	0x54d4 <generic_kprobe_process_filter+0x19b4>
    5594:      	ldr	w13, [x14, #0x44]
    5598:      	cmp	w13, w12
    559c:      	b.ne	0x55b8 <generic_kprobe_process_filter+0x1a98>
    55a0:      	b	0x54d4 <generic_kprobe_process_filter+0x19b4>
    55a4:      	ldr	x14, [sp, #0xe8]
    55a8:      	cmp	w8, #0x2
    55ac:      	b.ls	0x55b8 <generic_kprobe_process_filter+0x1a98>
    55b0:      	mov	w9, wzr
    55b4:      	b	0x54d4 <generic_kprobe_process_filter+0x19b4>
    55b8:      	add	x9, x14, #0x48
    55bc:      	cmp	w10, #0x5
    55c0:      	ldr	x8, [x9, x8, lsl #3]
    55c4:      	and	x8, x8, x11
    55c8:      	b.ne	0x55d8 <generic_kprobe_process_filter+0x1ab8>
    55cc:      	cmp	x8, #0x0
    55d0:      	cset	w9, ne
    55d4:      	b	0x54d4 <generic_kprobe_process_filter+0x19b4>
    55d8:      	cmp	x8, #0x0
    55dc:      	cset	w9, eq
    55e0:      	b	0x54d4 <generic_kprobe_process_filter+0x19b4>
    55e4:      	ldr	x11, [sp, #0xe8]
    55e8:      	mov	w8, #0x5ee8             // =24296
    55ec:      	add	x8, x11, x8
    55f0:      	tbz	w22, #0x0, 0x563c <generic_kprobe_process_filter+0x1b1c>
    55f4:      	ldr	w9, [x0, #0x28]
    55f8:      	cbz	w9, 0x5634 <generic_kprobe_process_filter+0x1b14>
    55fc:      	ldr	x10, [sp, #0x30]
    5600:      	ldr	w10, [x10]
    5604:      	cmp	w9, w10
    5608:      	b.eq	0x563c <generic_kprobe_process_filter+0x1b1c>
    560c:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5610:      	mov	w9, #0x1                // =1
    5614:      	str	x9, [x8]
    5618:      	tbnz	w22, #0x1, 0x5660 <generic_kprobe_process_filter+0x1b40>
    561c:      	ldr	w9, [x0, #0x2c]
    5620:      	cbz	w9, 0x5658 <generic_kprobe_process_filter+0x1b38>
    5624:      	ldr	w10, [x11, #0x24]
    5628:      	cmp	w9, w10
    562c:      	b.eq	0x5660 <generic_kprobe_process_filter+0x1b40>
    5630:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5634:      	mov	w9, #0x1                // =1
    5638:      	str	x9, [x8]
    563c:      	tbz	w22, #0x1, 0x5684 <generic_kprobe_process_filter+0x1b64>
    5640:      	ldr	w9, [x0, #0x2c]
    5644:      	cbz	w9, 0x567c <generic_kprobe_process_filter+0x1b5c>
    5648:      	ldr	w10, [x11, #0x24]
    564c:      	cmp	w9, w10
    5650:      	b.eq	0x5684 <generic_kprobe_process_filter+0x1b64>
    5654:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5658:      	mov	w9, #0x1                // =1
    565c:      	str	x9, [x8]
    5660:      	tbnz	w22, #0x2, 0x56a8 <generic_kprobe_process_filter+0x1b88>
    5664:      	ldr	w9, [x0, #0x30]
    5668:      	cbz	w9, 0x56a0 <generic_kprobe_process_filter+0x1b80>
    566c:      	ldr	w10, [x11, #0x28]
    5670:      	cmp	w9, w10
    5674:      	b.eq	0x56a8 <generic_kprobe_process_filter+0x1b88>
    5678:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    567c:      	mov	w9, #0x1                // =1
    5680:      	str	x9, [x8]
    5684:      	tbz	w22, #0x2, 0x56cc <generic_kprobe_process_filter+0x1bac>
    5688:      	ldr	w9, [x0, #0x30]
    568c:      	cbz	w9, 0x56c4 <generic_kprobe_process_filter+0x1ba4>
    5690:      	ldr	w10, [x11, #0x28]
    5694:      	cmp	w9, w10
    5698:      	b.eq	0x56cc <generic_kprobe_process_filter+0x1bac>
    569c:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    56a0:      	mov	w9, #0x1                // =1
    56a4:      	str	x9, [x8]
    56a8:      	tbnz	w22, #0x3, 0x56f0 <generic_kprobe_process_filter+0x1bd0>
    56ac:      	ldr	w9, [x0, #0x34]
    56b0:      	cbz	w9, 0x56e8 <generic_kprobe_process_filter+0x1bc8>
    56b4:      	ldr	w10, [x11, #0x2c]
    56b8:      	cmp	w9, w10
    56bc:      	b.eq	0x56f0 <generic_kprobe_process_filter+0x1bd0>
    56c0:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    56c4:      	mov	w9, #0x1                // =1
    56c8:      	str	x9, [x8]
    56cc:      	tbz	w22, #0x3, 0x5714 <generic_kprobe_process_filter+0x1bf4>
    56d0:      	ldr	w9, [x0, #0x34]
    56d4:      	cbz	w9, 0x570c <generic_kprobe_process_filter+0x1bec>
    56d8:      	ldr	w10, [x11, #0x2c]
    56dc:      	cmp	w9, w10
    56e0:      	b.eq	0x5714 <generic_kprobe_process_filter+0x1bf4>
    56e4:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    56e8:      	mov	w9, #0x1                // =1
    56ec:      	str	x9, [x8]
    56f0:      	tbnz	w22, #0x4, 0x5738 <generic_kprobe_process_filter+0x1c18>
    56f4:      	ldr	w9, [x0, #0x38]
    56f8:      	cbz	w9, 0x5730 <generic_kprobe_process_filter+0x1c10>
    56fc:      	ldr	w10, [x11, #0x30]
    5700:      	cmp	w9, w10
    5704:      	b.eq	0x5738 <generic_kprobe_process_filter+0x1c18>
    5708:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    570c:      	mov	w9, #0x1                // =1
    5710:      	str	x9, [x8]
    5714:      	tbz	w22, #0x4, 0x575c <generic_kprobe_process_filter+0x1c3c>
    5718:      	ldr	w9, [x0, #0x38]
    571c:      	cbz	w9, 0x5754 <generic_kprobe_process_filter+0x1c34>
    5720:      	ldr	w10, [x11, #0x30]
    5724:      	cmp	w9, w10
    5728:      	b.eq	0x575c <generic_kprobe_process_filter+0x1c3c>
    572c:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5730:      	mov	w9, #0x1                // =1
    5734:      	str	x9, [x8]
    5738:      	tbnz	w22, #0x5, 0x5780 <generic_kprobe_process_filter+0x1c60>
    573c:      	ldr	w9, [x0, #0x3c]
    5740:      	cbz	w9, 0x5778 <generic_kprobe_process_filter+0x1c58>
    5744:      	ldr	w10, [x11, #0x34]
    5748:      	cmp	w9, w10
    574c:      	b.eq	0x5780 <generic_kprobe_process_filter+0x1c60>
    5750:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5754:      	mov	w9, #0x1                // =1
    5758:      	str	x9, [x8]
    575c:      	tbz	w22, #0x5, 0x57a4 <generic_kprobe_process_filter+0x1c84>
    5760:      	ldr	w9, [x0, #0x3c]
    5764:      	cbz	w9, 0x579c <generic_kprobe_process_filter+0x1c7c>
    5768:      	ldr	w10, [x11, #0x34]
    576c:      	cmp	w9, w10
    5770:      	b.eq	0x57a4 <generic_kprobe_process_filter+0x1c84>
    5774:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5778:      	mov	w9, #0x1                // =1
    577c:      	str	x9, [x8]
    5780:      	tbnz	w22, #0x6, 0x57c8 <generic_kprobe_process_filter+0x1ca8>
    5784:      	ldr	w9, [x0, #0x40]
    5788:      	cbz	w9, 0x57c0 <generic_kprobe_process_filter+0x1ca0>
    578c:      	ldr	w10, [x11, #0x38]
    5790:      	cmp	w9, w10
    5794:      	b.eq	0x57c8 <generic_kprobe_process_filter+0x1ca8>
    5798:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    579c:      	mov	w9, #0x1                // =1
    57a0:      	str	x9, [x8]
    57a4:      	tbz	w22, #0x6, 0x57ec <generic_kprobe_process_filter+0x1ccc>
    57a8:      	ldr	w9, [x0, #0x40]
    57ac:      	cbz	w9, 0x57e4 <generic_kprobe_process_filter+0x1cc4>
    57b0:      	ldr	w10, [x11, #0x38]
    57b4:      	cmp	w9, w10
    57b8:      	b.eq	0x57ec <generic_kprobe_process_filter+0x1ccc>
    57bc:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    57c0:      	mov	w9, #0x1                // =1
    57c4:      	str	x9, [x8]
    57c8:      	tbnz	w22, #0x7, 0x5810 <generic_kprobe_process_filter+0x1cf0>
    57cc:      	ldr	w9, [x0, #0x44]
    57d0:      	cbz	w9, 0x5808 <generic_kprobe_process_filter+0x1ce8>
    57d4:      	ldr	w10, [x11, #0x3c]
    57d8:      	cmp	w9, w10
    57dc:      	b.eq	0x5810 <generic_kprobe_process_filter+0x1cf0>
    57e0:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    57e4:      	mov	w9, #0x1                // =1
    57e8:      	str	x9, [x8]
    57ec:      	tbz	w22, #0x7, 0x5838 <generic_kprobe_process_filter+0x1d18>
    57f0:      	ldr	w9, [x0, #0x44]
    57f4:      	cbz	w9, 0x5830 <generic_kprobe_process_filter+0x1d10>
    57f8:      	ldr	w10, [x11, #0x3c]
    57fc:      	cmp	w9, w10
    5800:      	b.eq	0x5838 <generic_kprobe_process_filter+0x1d18>
    5804:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5808:      	mov	w9, #0x1                // =1
    580c:      	str	x9, [x8]
    5810:      	tbnz	w22, #0x8, 0x5860 <generic_kprobe_process_filter+0x1d40>
    5814:      	ldr	w9, [x0, #0x48]
    5818:      	cbz	w9, 0x5858 <generic_kprobe_process_filter+0x1d38>
    581c:      	ldr	x10, [sp, #0xe8]
    5820:      	ldr	w10, [x10, #0x40]
    5824:      	cmp	w9, w10
    5828:      	b.eq	0x5860 <generic_kprobe_process_filter+0x1d40>
    582c:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5830:      	mov	w9, #0x1                // =1
    5834:      	str	x9, [x8]
    5838:      	tbz	w22, #0x8, 0x5870 <generic_kprobe_process_filter+0x1d50>
    583c:      	ldr	w9, [x0, #0x48]
    5840:      	cbz	w9, 0x5868 <generic_kprobe_process_filter+0x1d48>
    5844:      	ldr	x10, [sp, #0xe8]
    5848:      	ldr	w10, [x10, #0x40]
    584c:      	cmp	w9, w10
    5850:      	b.eq	0x5870 <generic_kprobe_process_filter+0x1d50>
    5854:      	b	0x588c <generic_kprobe_process_filter+0x1d6c>
    5858:      	mov	w9, #0x1                // =1
    585c:      	str	x9, [x8]
    5860:      	tbz	w22, #0x9, 0x5874 <generic_kprobe_process_filter+0x1d54>
    5864:      	b	0x599c <generic_kprobe_process_filter+0x1e7c>
    5868:      	mov	w9, #0x1                // =1
    586c:      	str	x9, [x8]
    5870:      	tbz	w22, #0x9, 0x599c <generic_kprobe_process_filter+0x1e7c>
    5874:      	ldr	w9, [x0, #0x4c]
    5878:      	cbz	w9, 0x5994 <generic_kprobe_process_filter+0x1e74>
    587c:      	ldr	x10, [sp, #0xe8]
    5880:      	ldr	w10, [x10, #0x44]
    5884:      	cmp	w9, w10
    5888:      	b.eq	0x599c <generic_kprobe_process_filter+0x1e7c>
    588c:      	add	w9, w19, #0xc
    5890:      	mov	w10, #0x1               // =1
    5894:      	str	x10, [x8]
    5898:      	and	x8, x9, #0x3ff
    589c:      	adrp	x24, 0x5000 <generic_kprobe_process_filter+0x14e0>
    58a0:      	ldr	w8, [x8, x23]
    58a4:      	ldr	x24, [x24]
    58a8:      	cmp	w8, #0x4
    58ac:      	b.ne	0x58e0 <generic_kprobe_process_filter+0x1dc0>
    58b0:      	ldr	x9, [sp, #0xe8]
    58b4:      	mov	w8, #0x5eb8             // =24248
    58b8:      	add	x8, x9, x8
    58bc:      	ldr	x9, [x9, #0x5eb8]
    58c0:      	and	x9, x9, #0x1f
    58c4:      	add	x8, x8, x9
    58c8:      	mov	w9, #0x1                // =1
    58cc:      	strb	w9, [x8, #0x9]
    58d0:      	ldr	x8, [sp, #0x40]
    58d4:      	strb	w9, [x8, #0x20]
    58d8:      	strb	w9, [x8]
    58dc:      	b	0x599c <generic_kprobe_process_filter+0x1e7c>
    58e0:      	add	w8, w9, #0x4
    58e4:      	and	x8, x8, #0x3ff
    58e8:      	add	x8, x8, x23
    58ec:      	ldp	w21, w19, [x8]
    58f0:      	ldr	w22, [x8, #0x8]
    58f4:      	ldur	x20, [x8, #0xc]
    58f8:      	mov	w8, #0xe                // =14
    58fc:      	blr	x8
    5900:      	lsr	x8, x0, #32
    5904:      	add	x9, sp, #0x58
    5908:      	add	x1, sp, #0x58
    590c:      	str	w8, [sp, #0x58]
    5910:      	mov	w8, #0x1                // =1
    5914:      	mov	x0, x24
    5918:      	blr	x8
    591c:      	cbz	x0, 0x599c <generic_kprobe_process_filter+0x1e7c>
    5920:      	cmp	w21, #0x2
    5924:      	cbz	w22, 0x5940 <generic_kprobe_process_filter+0x1e20>
    5928:      	b.hi	0x599c <generic_kprobe_process_filter+0x1e7c>
    592c:      	ldr	x8, [sp, #0xe8]
    5930:      	ldr	w8, [x8, #0x44]
    5934:      	cmp	w8, w22
    5938:      	b.ne	0x5944 <generic_kprobe_process_filter+0x1e24>
    593c:      	b	0x599c <generic_kprobe_process_filter+0x1e7c>
    5940:      	b.hi	0x599c <generic_kprobe_process_filter+0x1e7c>
    5944:      	ldr	x8, [sp, #0xe8]
    5948:      	lsl	x10, x21, #3
    594c:      	add	x9, x8, #0x48
    5950:      	add	x8, x0, x21, lsl #3
    5954:      	ldr	x8, [x8, #0x50]
    5958:      	ldr	x9, [x9, x10]
    595c:      	eor	x10, x9, x8
    5960:      	tst	x10, x20
    5964:      	b.eq	0x5974 <generic_kprobe_process_filter+0x1e54>
    5968:      	cmp	w19, #0x5
    596c:      	b.eq	0x5984 <generic_kprobe_process_filter+0x1e64>
    5970:      	b	0x599c <generic_kprobe_process_filter+0x1e7c>
    5974:      	cmp	x8, x9
    5978:      	b.eq	0x599c <generic_kprobe_process_filter+0x1e7c>
    597c:      	cmp	w19, #0x6
    5980:      	b.ne	0x599c <generic_kprobe_process_filter+0x1e7c>
    5984:      	ldr	x9, [sp, #0xe8]
    5988:      	mov	w8, #0x1                // =1
    598c:      	str	x8, [x9, #0x5ef0]
    5990:      	b	0x58b0 <generic_kprobe_process_filter+0x1d90>
    5994:      	mov	w9, #0x1                // =1
    5998:      	str	x9, [x8]
    599c:      	ldr	x9, [sp, #0xe8]
    59a0:      	ldr	x10, [sp, #0x28]
    59a4:      	ldr	x8, [x9, #0x5eb8]
    59a8:      	add	x8, x8, #0x1
    59ac:      	cmp	x8, x10
    59b0:      	str	x8, [x9, #0x5eb8]
    59b4:      	b.ls	0x5a14 <generic_kprobe_process_filter+0x1ef4>
    59b8:      	ldr	x10, [sp, #0x48]
    59bc:      	ldr	w8, [x10]
    59c0:      	str	w8, [x9, #0x10]
    59c4:      	ldr	x8, [x10, #0x8]
    59c8:      	str	x8, [x9, #0x18]
    59cc:      	ldp	x22, x8, [sp, #0x38]
    59d0:      	ldrb	w8, [x8]
    59d4:      	cbz	w8, 0x59f4 <generic_kprobe_process_filter+0x1ed4>
    59d8:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x14e0>
    59dc:      	mov	x8, xzr
    59e0:      	mov	w9, #0xc                // =12
    59e4:      	ldr	x1, [x1]
    59e8:      	mov	x0, x22
    59ec:      	mov	w2, wzr
    59f0:      	blr	x9
    59f4:      	ldp	x20, x19, [sp, #0x120]
    59f8:      	mov	w0, wzr
    59fc:      	ldr	x29, [sp, #0xe0]
    5a00:      	ldp	x22, x21, [sp, #0x110]
    5a04:      	ldp	x24, x23, [sp, #0x100]
    5a08:      	ldp	x30, x25, [sp, #0xf0]
    5a0c:      	add	sp, sp, #0x130
    5a10:      	ret
    5a14:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5a18:      	mov	w8, #0x2                // =2
    5a1c:      	mov	w9, #0xc                // =12
    5a20:      	ldr	x1, [x1]
    5a24:      	ldr	x0, [sp, #0x38]
    5a28:      	mov	w2, #0x2                // =2
    5a2c:      	b	0x59f0 <generic_kprobe_process_filter+0x1ed0>

0000000000005a30 <generic_kprobe_filter_arg>:
    5a30:      	sub	sp, sp, #0xf0
    5a34:      	str	x29, [sp, #0xa0]
    5a38:      	stp	x30, x25, [sp, #0xb0]
    5a3c:      	stp	x24, x23, [sp, #0xc0]
    5a40:      	stp	x22, x21, [sp, #0xd0]
    5a44:      	stp	x20, x19, [sp, #0xe0]
    5a48:      	mov	x19, x0
    5a4c:      	str	wzr, [sp, #0xa8]
    5a50:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5a54:      	mov	w8, #0x1                // =1
    5a58:      	ldr	x0, [x0]
    5a5c:      	add	x9, sp, #0xa8
    5a60:      	add	x1, sp, #0xa8
    5a64:      	blr	x8
    5a68:      	cbz	x0, 0x5bd8 <generic_kprobe_filter_arg+0x1a8>
    5a6c:      	mov	w8, #0x5ec1             // =24257
    5a70:      	mov	x20, x0
    5a74:      	add	x22, x0, x8
    5a78:      	mov	w8, #0x5ef8             // =24312
    5a7c:      	add	x1, x0, x8
    5a80:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5a84:      	ldur	w23, [x22, #0x3f]
    5a88:      	mov	w8, #0x1                // =1
    5a8c:      	ldr	x0, [x0]
    5a90:      	blr	x8
    5a94:      	cbz	x0, 0x5bbc <generic_kprobe_filter_arg+0x18c>
    5a98:      	ldrb	w8, [x22, #0x1f]
    5a9c:      	cbz	w8, 0x5bbc <generic_kprobe_filter_arg+0x18c>
    5aa0:      	and	x8, x23, #0x7
    5aa4:      	mov	w10, #0x5ec1            // =24257
    5aa8:      	stp	x23, x22, [sp, #0x50]
    5aac:      	add	x9, x20, x8
    5ab0:      	ldrb	w9, [x9, x10]
    5ab4:      	cbz	w9, 0x5b2c <generic_kprobe_filter_arg+0xfc>
    5ab8:      	lsl	w8, w8, #2
    5abc:      	mov	x21, x0
    5ac0:      	add	x8, x8, #0x4
    5ac4:      	ldr	w9, [x8, x0]
    5ac8:      	add	x8, x8, x9
    5acc:      	add	x8, x8, #0x4
    5ad0:      	and	x9, x8, #0x3ff
    5ad4:      	ldr	w9, [x9, x0]
    5ad8:      	add	x8, x8, x9
    5adc:      	and	x9, x8, #0x3ff
    5ae0:      	ldr	w9, [x9, x0]
    5ae4:      	add	x8, x8, x9
    5ae8:      	and	x9, x8, #0x3ff
    5aec:      	ldr	w9, [x9, x0]
    5af0:      	add	x8, x8, x9
    5af4:      	and	x9, x8, #0x3ff
    5af8:      	ldr	w9, [x9, x0]
    5afc:      	add	x8, x8, x9
    5b00:      	and	x9, x8, #0x3ff
    5b04:      	ldr	w9, [x9, x0]
    5b08:      	add	x16, x8, x9
    5b0c:      	and	x15, x16, #0x3ff
    5b10:      	add	x17, x0, x15
    5b14:      	ldr	w8, [x17]
    5b18:      	cmp	w8, #0x19
    5b1c:      	b.hs	0x5b80 <generic_kprobe_filter_arg+0x150>
    5b20:      	cmp	w15, #0x1
    5b24:      	b.eq	0x5bbc <generic_kprobe_filter_arg+0x18c>
    5b28:      	cbnz	w15, 0x5b98 <generic_kprobe_filter_arg+0x168>
    5b2c:      	ldr	x8, [sp, #0x50]
    5b30:      	cmp	w8, #0x1
    5b34:      	b.gt	0x5b54 <generic_kprobe_filter_arg+0x124>
    5b38:      	ldr	x9, [sp, #0x58]
    5b3c:      	cmn	w8, #0x1
    5b40:      	b.eq	0x5bf8 <generic_kprobe_filter_arg+0x1c8>
    5b44:      	cbz	w8, 0x5c08 <generic_kprobe_filter_arg+0x1d8>
    5b48:      	cmp	w8, #0x1
    5b4c:      	b.eq	0x5c18 <generic_kprobe_filter_arg+0x1e8>
    5b50:      	b	0x5b70 <generic_kprobe_filter_arg+0x140>
    5b54:      	ldr	x9, [sp, #0x58]
    5b58:      	cmp	w8, #0x2
    5b5c:      	b.eq	0x5c28 <generic_kprobe_filter_arg+0x1f8>
    5b60:      	cmp	w8, #0x3
    5b64:      	b.eq	0x5c38 <generic_kprobe_filter_arg+0x208>
    5b68:      	cmp	w8, #0x4
    5b6c:      	b.eq	0x5c48 <generic_kprobe_filter_arg+0x218>
    5b70:      	cmp	w8, #0x4
    5b74:      	b.gt	0x5c74 <generic_kprobe_filter_arg+0x244>
    5b78:      	add	w8, w8, #0x1
    5b7c:      	b	0x5c54 <generic_kprobe_filter_arg+0x224>
    5b80:      	mov	x25, xzr
    5b84:      	mov	w2, #0x5ea0             // =24224
    5b88:      	mov	w12, #0x1               // =1
    5b8c:      	stp	x19, x17, [sp, #0x30]
    5b90:      	stp	x16, x15, [sp, #0x40]
    5b94:      	b	0x5cd4 <generic_kprobe_filter_arg+0x2a4>
    5b98:      	ldr	x8, [sp, #0x58]
    5b9c:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5ba0:      	mov	w9, #0xc                // =12
    5ba4:      	mov	x0, x19
    5ba8:      	stur	w15, [x8, #0x43]
    5bac:      	mov	w8, #0x4                // =4
    5bb0:      	mov	w2, #0x4                // =4
    5bb4:      	ldr	x1, [x1]
    5bb8:      	blr	x9
    5bbc:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5bc0:      	mov	w8, #0x5                // =5
    5bc4:      	mov	w9, #0xc                // =12
    5bc8:      	ldr	x1, [x1]
    5bcc:      	mov	x0, x19
    5bd0:      	mov	w2, #0x5                // =5
    5bd4:      	blr	x9
    5bd8:      	ldp	x20, x19, [sp, #0xe0]
    5bdc:      	mov	w0, wzr
    5be0:      	ldr	x29, [sp, #0xa0]
    5be4:      	ldp	x22, x21, [sp, #0xd0]
    5be8:      	ldp	x24, x23, [sp, #0xc0]
    5bec:      	ldp	x30, x25, [sp, #0xb0]
    5bf0:      	add	sp, sp, #0xf0
    5bf4:      	ret
    5bf8:      	ldrb	w8, [x9]
    5bfc:      	cbz	w8, 0x5c08 <generic_kprobe_filter_arg+0x1d8>
    5c00:      	mov	w8, wzr
    5c04:      	b	0x5c54 <generic_kprobe_filter_arg+0x224>
    5c08:      	ldrb	w8, [x9, #0x1]
    5c0c:      	cbz	w8, 0x5c18 <generic_kprobe_filter_arg+0x1e8>
    5c10:      	mov	w8, #0x1                // =1
    5c14:      	b	0x5c54 <generic_kprobe_filter_arg+0x224>
    5c18:      	ldrb	w8, [x9, #0x2]
    5c1c:      	cbz	w8, 0x5c28 <generic_kprobe_filter_arg+0x1f8>
    5c20:      	mov	w8, #0x2                // =2
    5c24:      	b	0x5c54 <generic_kprobe_filter_arg+0x224>
    5c28:      	ldrb	w8, [x9, #0x3]
    5c2c:      	cbz	w8, 0x5c38 <generic_kprobe_filter_arg+0x208>
    5c30:      	mov	w8, #0x3                // =3
    5c34:      	b	0x5c54 <generic_kprobe_filter_arg+0x224>
    5c38:      	ldrb	w8, [x9, #0x4]
    5c3c:      	cbz	w8, 0x5c48 <generic_kprobe_filter_arg+0x218>
    5c40:      	mov	w8, #0x4                // =4
    5c44:      	b	0x5c54 <generic_kprobe_filter_arg+0x224>
    5c48:      	ldrb	w8, [x9, #0x5]
    5c4c:      	cbz	w8, 0x5c74 <generic_kprobe_filter_arg+0x244>
    5c50:      	mov	w8, #0x5                // =5
    5c54:      	stur	w8, [x9, #0x3f]
    5c58:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5c5c:      	mov	w8, #0x3                // =3
    5c60:      	mov	w9, #0xc                // =12
    5c64:      	ldr	x1, [x1]
    5c68:      	mov	x0, x19
    5c6c:      	mov	w2, #0x3                // =3
    5c70:      	blr	x9
    5c74:      	ldr	x19, [x20, #0x60]
    5c78:      	mov	w8, #0xe                // =14
    5c7c:      	blr	x8
    5c80:      	stp	x19, x0, [sp, #0x60]
    5c84:      	adrp	x19, 0x5000 <generic_kprobe_process_filter+0x14e0>
    5c88:      	mov	w8, #0x1                // =1
    5c8c:      	add	x9, sp, #0x60
    5c90:      	add	x1, sp, #0x60
    5c94:      	ldr	x19, [x19]
    5c98:      	mov	x0, x19
    5c9c:      	blr	x8
    5ca0:      	cbz	x0, 0x5bd8 <generic_kprobe_filter_arg+0x1a8>
    5ca4:      	mov	w8, #0x3                // =3
    5ca8:      	add	x9, sp, #0x60
    5cac:      	add	x1, sp, #0x60
    5cb0:      	mov	x0, x19
    5cb4:      	blr	x8
    5cb8:      	b	0x5bd8 <generic_kprobe_filter_arg+0x1a8>
    5cbc:      	cmp	w8, #0x3
    5cc0:      	cset	w23, eq
    5cc4:      	cbz	x23, 0x5b2c <generic_kprobe_filter_arg+0xfc>
    5cc8:      	add	x25, x25, #0x1
    5ccc:      	cmp	x25, #0x5
    5cd0:      	b.eq	0x5b20 <generic_kprobe_filter_arg+0xf0>
    5cd4:      	add	x8, x17, x25, lsl #2
    5cd8:      	ldr	w8, [x8, #0x4]
    5cdc:      	tst	w8, #0x3ff
    5ce0:      	b.eq	0x5b20 <generic_kprobe_filter_arg+0xf0>
    5ce4:      	add	w8, w16, w8
    5ce8:      	and	x8, x8, #0x3ff
    5cec:      	add	x29, x21, x8
    5cf0:      	ldr	w8, [x29, #0x4]
    5cf4:      	cmp	w8, #0x23
    5cf8:      	b.eq	0x5b2c <generic_kprobe_filter_arg+0xfc>
    5cfc:      	ldr	w9, [x29]
    5d00:      	cmp	w9, #0x4
    5d04:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    5d08:      	add	x10, x20, x9, lsl #2
    5d0c:      	ldr	w10, [x10, x2]
    5d10:      	cbnz	w10, 0x5b2c <generic_kprobe_filter_arg+0xfc>
    5d14:      	add	x9, x20, x9, lsl #3
    5d18:      	ldr	x9, [x9, #0x5e78]
    5d1c:      	and	x9, x9, #0x7ff
    5d20:      	add	x9, x20, x9
    5d24:      	add	x22, x9, #0x90
    5d28:      	ldr	w9, [x29, #0xc]
    5d2c:      	cmp	w9, #0x10
    5d30:      	b.le	0x5d80 <generic_kprobe_filter_arg+0x350>
    5d34:      	sub	w10, w9, #0x1c
    5d38:      	cmp	w10, #0x9
    5d3c:      	b.lo	0x5ef0 <generic_kprobe_filter_arg+0x4c0>
    5d40:      	cmp	w9, #0x2a
    5d44:      	b.hi	0x5d70 <generic_kprobe_filter_arg+0x340>
    5d48:      	lsl	x10, x12, x9
    5d4c:      	tst	x10, #0xc000000000
    5d50:      	b.ne	0x5da8 <generic_kprobe_filter_arg+0x378>
    5d54:      	lsl	x10, x12, x9
    5d58:      	tst	x10, #0x30000000000
    5d5c:      	b.ne	0x6198 <generic_kprobe_filter_arg+0x768>
    5d60:      	lsl	x10, x12, x9
    5d64:      	mov	x11, #0x42000000000     // =4535485464576
    5d68:      	tst	x10, x11
    5d6c:      	b.ne	0x5df0 <generic_kprobe_filter_arg+0x3c0>
    5d70:      	cmp	w9, #0x11
    5d74:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    5d78:      	add	x22, x22, #0x4
    5d7c:      	b	0x5df0 <generic_kprobe_filter_arg+0x3c0>
    5d80:      	cmp	w9, #0x6
    5d84:      	b.gt	0x5dd8 <generic_kprobe_filter_arg+0x3a8>
    5d88:      	cmp	w9, #0x3
    5d8c:      	b.le	0x5eac <generic_kprobe_filter_arg+0x47c>
    5d90:      	cmp	w9, #0x4
    5d94:      	b.eq	0x5ef0 <generic_kprobe_filter_arg+0x4c0>
    5d98:      	cmp	w9, #0x5
    5d9c:      	b.eq	0x6198 <generic_kprobe_filter_arg+0x768>
    5da0:      	cmp	w9, #0x6
    5da4:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    5da8:      	ldr	w24, [x22], #0x4
    5dac:      	mov	x23, xzr
    5db0:      	cmp	w8, #0x19
    5db4:      	b.gt	0x604c <generic_kprobe_filter_arg+0x61c>
    5db8:      	sub	w9, w8, #0x3
    5dbc:      	cmp	w9, #0x2
    5dc0:      	b.lo	0x674c <generic_kprobe_filter_arg+0xd1c>
    5dc4:      	cmp	w8, #0x8
    5dc8:      	b.eq	0x66b4 <generic_kprobe_filter_arg+0xc84>
    5dcc:      	cmp	w8, #0x9
    5dd0:      	b.eq	0x6064 <generic_kprobe_filter_arg+0x634>
    5dd4:      	b	0x6c68 <generic_kprobe_filter_arg+0x1238>
    5dd8:      	sub	w10, w9, #0xa
    5ddc:      	cmp	w10, #0x4
    5de0:      	b.lo	0x5ef0 <generic_kprobe_filter_arg+0x4c0>
    5de4:      	sub	w10, w9, #0xf
    5de8:      	cmp	w10, #0x2
    5dec:      	b.hs	0x6190 <generic_kprobe_filter_arg+0x760>
    5df0:      	ldr	w24, [x22]
    5df4:      	and	w9, w8, #0xfffffffe
    5df8:      	cmp	w9, #0x24
    5dfc:      	b.eq	0x5e04 <generic_kprobe_filter_arg+0x3d4>
    5e00:      	cbz	w24, 0x5b2c <generic_kprobe_filter_arg+0xfc>
    5e04:      	cmp	w8, #0x25
    5e08:      	b.hi	0x6130 <generic_kprobe_filter_arg+0x700>
    5e0c:      	mov	w10, #0x100             // =256
    5e10:      	lsl	x9, x12, x8
    5e14:      	movk	w10, #0x400, lsl #16
    5e18:      	tst	x9, x10
    5e1c:      	b.ne	0x63f0 <generic_kprobe_filter_arg+0x9c0>
    5e20:      	mov	w10, #0x200             // =512
    5e24:      	lsl	x9, x12, x8
    5e28:      	movk	w10, #0x800, lsl #16
    5e2c:      	tst	x9, x10
    5e30:      	b.ne	0x6310 <generic_kprobe_filter_arg+0x8e0>
    5e34:      	lsl	x9, x12, x8
    5e38:      	tst	x9, #0x3000000000
    5e3c:      	b.eq	0x6130 <generic_kprobe_filter_arg+0x700>
    5e40:      	cmp	w24, #0x1fe
    5e44:      	strh	wzr, [sp, #0x60]
    5e48:      	b.hi	0x6148 <generic_kprobe_filter_arg+0x718>
    5e4c:      	add	x8, x22, #0x4
    5e50:      	mov	w10, #0x4               // =4
    5e54:      	add	x11, sp, #0x60
    5e58:      	mov	w12, #0x2               // =2
    5e5c:      	add	x0, sp, #0x60
    5e60:      	mov	w1, #0x2                // =2
    5e64:      	add	x9, x8, x24
    5e68:      	add	x9, x9, #0x4
    5e6c:      	ldr	w9, [x22]
    5e70:      	add	x8, x8, x9
    5e74:      	add	x2, x8, #0x4
    5e78:      	blr	x10
    5e7c:      	ldr	w9, [x29, #0x10]
    5e80:      	cbz	w9, 0x82e8 <generic_kprobe_filter_arg+0x28b8>
    5e84:      	ldrh	w8, [sp, #0x60]
    5e88:      	ldp	x16, x15, [sp, #0x40]
    5e8c:      	mov	w2, #0x5ea0             // =24224
    5e90:      	mov	w12, #0x1               // =1
    5e94:      	and	w8, w8, #0xf000
    5e98:      	ldr	x17, [sp, #0x38]
    5e9c:      	cmp	w9, w8
    5ea0:      	b.ne	0x7424 <generic_kprobe_filter_arg+0x19f4>
    5ea4:      	mov	w23, #0x1               // =1
    5ea8:      	b	0x82fc <generic_kprobe_filter_arg+0x28cc>
    5eac:      	cmp	w9, #0x1
    5eb0:      	b.eq	0x5ef0 <generic_kprobe_filter_arg+0x4c0>
    5eb4:      	cmp	w9, #0x2
    5eb8:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    5ebc:      	add	x24, x22, #0x8
    5ec0:      	ldr	w22, [x22, #0x4]
    5ec4:      	mov	x23, xzr
    5ec8:      	cmp	w8, #0x19
    5ecc:      	b.gt	0x67b0 <generic_kprobe_filter_arg+0xd80>
    5ed0:      	sub	w9, w8, #0x3
    5ed4:      	cmp	w9, #0x2
    5ed8:      	b.lo	0x6f1c <generic_kprobe_filter_arg+0x14ec>
    5edc:      	cmp	w8, #0x8
    5ee0:      	b.eq	0x6e90 <generic_kprobe_filter_arg+0x1460>
    5ee4:      	cmp	w8, #0x9
    5ee8:      	b.eq	0x67c8 <generic_kprobe_filter_arg+0xd98>
    5eec:      	b	0x872c <generic_kprobe_filter_arg+0x2cfc>
    5ef0:      	cmp	w9, #0xb
    5ef4:      	b.le	0x5f64 <generic_kprobe_filter_arg+0x534>
    5ef8:      	cmp	w9, #0x24
    5efc:      	b.hi	0x5fac <generic_kprobe_filter_arg+0x57c>
    5f00:      	lsl	x10, x12, x9
    5f04:      	tst	x10, #0x1e00000000
    5f08:      	b.ne	0x5f84 <generic_kprobe_filter_arg+0x554>
    5f0c:      	lsl	x10, x12, x9
    5f10:      	tst	x10, #0x60000000
    5f14:      	b.ne	0x6150 <generic_kprobe_filter_arg+0x720>
    5f18:      	lsl	x10, x12, x9
    5f1c:      	tst	x10, #0x180000000
    5f20:      	b.eq	0x5fac <generic_kprobe_filter_arg+0x57c>
    5f24:      	cmp	w8, #0x20
    5f28:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    5f2c:      	lsl	x9, x12, x8
    5f30:      	mov	w10, #0x101e            // =4126
    5f34:      	tst	x9, x10
    5f38:      	b.eq	0x68ac <generic_kprobe_filter_arg+0xe7c>
    5f3c:      	ldr	w9, [x29, #0x10]
    5f40:      	cmp	w8, #0x2
    5f44:      	b.le	0x6db8 <generic_kprobe_filter_arg+0x1388>
    5f48:      	sub	w10, w8, #0x3
    5f4c:      	cmp	w10, #0x2
    5f50:      	b.hs	0x72e0 <generic_kprobe_filter_arg+0x18b0>
    5f54:      	ldrb	w10, [x22]
    5f58:      	cmp	w9, w10
    5f5c:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    5f60:      	b	0x7644 <generic_kprobe_filter_arg+0x1c14>
    5f64:      	sub	w10, w9, #0xa
    5f68:      	cmp	w10, #0x2
    5f6c:      	b.lo	0x6228 <generic_kprobe_filter_arg+0x7f8>
    5f70:      	cmp	w9, #0x1
    5f74:      	b.eq	0x5fb8 <generic_kprobe_filter_arg+0x588>
    5f78:      	cmp	w9, #0x4
    5f7c:      	b.eq	0x5fb8 <generic_kprobe_filter_arg+0x588>
    5f80:      	b	0x5cc8 <generic_kprobe_filter_arg+0x298>
    5f84:      	cmp	w8, #0x9
    5f88:      	b.le	0x61d8 <generic_kprobe_filter_arg+0x7a8>
    5f8c:      	cmp	w8, #0x1d
    5f90:      	b.gt	0x6580 <generic_kprobe_filter_arg+0xb50>
    5f94:      	sub	w10, w8, #0xa
    5f98:      	cmp	w10, #0x2
    5f9c:      	b.lo	0x62b4 <generic_kprobe_filter_arg+0x884>
    5fa0:      	cmp	w8, #0xc
    5fa4:      	b.eq	0x6240 <generic_kprobe_filter_arg+0x810>
    5fa8:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    5fac:      	sub	w10, w9, #0xc
    5fb0:      	cmp	w10, #0x2
    5fb4:      	b.hs	0x6220 <generic_kprobe_filter_arg+0x7f0>
    5fb8:      	cmp	w8, #0x20
    5fbc:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    5fc0:      	lsl	x10, x12, x8
    5fc4:      	mov	w11, #0x101e            // =4126
    5fc8:      	tst	x10, x11
    5fcc:      	b.eq	0x5ff8 <generic_kprobe_filter_arg+0x5c8>
    5fd0:      	ldr	w10, [x29, #0x10]
    5fd4:      	cmp	w8, #0x2
    5fd8:      	b.le	0x61e8 <generic_kprobe_filter_arg+0x7b8>
    5fdc:      	sub	w11, w8, #0x3
    5fe0:      	cmp	w11, #0x2
    5fe4:      	b.hs	0x6894 <generic_kprobe_filter_arg+0xe64>
    5fe8:      	ldr	w11, [x22]
    5fec:      	cmp	w11, w10
    5ff0:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    5ff4:      	b	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    5ff8:      	lsl	x10, x12, x8
    5ffc:      	tst	x10, #0xc00
    6000:      	b.ne	0x6488 <generic_kprobe_filter_arg+0xa58>
    6004:      	lsl	x10, x12, x8
    6008:      	tst	x10, #0x180000000
    600c:      	b.eq	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6010:      	cmp	w8, #0x1f
    6014:      	b.ne	0x6a18 <generic_kprobe_filter_arg+0xfe8>
    6018:      	ldp	w11, w10, [x29, #0x10]
    601c:      	cmp	w9, #0xc
    6020:      	b.hi	0x76c0 <generic_kprobe_filter_arg+0x1c90>
    6024:      	lsl	w8, w12, w9
    6028:      	mov	w13, #0x1402            // =5122
    602c:      	tst	w8, w13
    6030:      	b.eq	0x76c0 <generic_kprobe_filter_arg+0x1c90>
    6034:      	ldr	w8, [x22]
    6038:      	cmp	w11, w8
    603c:      	b.gt	0x76d4 <generic_kprobe_filter_arg+0x1ca4>
    6040:      	cmp	w8, w10
    6044:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6048:      	b	0x76d4 <generic_kprobe_filter_arg+0x1ca4>
    604c:      	cmp	w8, #0x20
    6050:      	b.gt	0x65c0 <generic_kprobe_filter_arg+0xb90>
    6054:      	cmp	w8, #0x1a
    6058:      	b.eq	0x66b4 <generic_kprobe_filter_arg+0xc84>
    605c:      	cmp	w8, #0x1b
    6060:      	b.ne	0x6c68 <generic_kprobe_filter_arg+0x1238>
    6064:      	ldr	w8, [x29, #0x10]
    6068:      	str	wzr, [sp, #0x88]
    606c:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6070:      	add	x9, sp, #0x60
    6074:      	add	x1, sp, #0x60
    6078:      	str	w8, [sp, #0x60]
    607c:      	mov	w8, #0x1                // =1
    6080:      	ldr	x0, [x0]
    6084:      	blr	x8
    6088:      	mov	x23, xzr
    608c:      	cbz	w24, 0x6c58 <generic_kprobe_filter_arg+0x1228>
    6090:      	cbz	x0, 0x6c58 <generic_kprobe_filter_arg+0x1228>
    6094:      	mov	x19, x0
    6098:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    609c:      	mov	w8, #0x1                // =1
    60a0:      	ldr	x0, [x0]
    60a4:      	add	x9, sp, #0x88
    60a8:      	add	x1, sp, #0x88
    60ac:      	blr	x8
    60b0:      	cbz	x0, 0x6c50 <generic_kprobe_filter_arg+0x1220>
    60b4:      	cmp	w24, #0x7f
    60b8:      	mov	w9, #0x7f               // =127
    60bc:      	mov	w11, #0x1               // =1
    60c0:      	mov	x1, x0
    60c4:      	mov	x8, xzr
    60c8:      	sub	w12, w24, #0x2
    60cc:      	sub	w13, w24, #0x1
    60d0:      	csel	w9, w24, w9, lo
    60d4:      	sub	x11, x11, x24
    60d8:      	lsl	w10, w9, #3
    60dc:      	mov	x9, x0
    60e0:      	str	w10, [x9], #0x5
    60e4:      	neg	x10, x24
    60e8:      	add	w14, w13, w8
    60ec:      	cmp	x11, x8
    60f0:      	and	x14, x14, #0xfff
    60f4:      	ldrb	w14, [x22, x14]
    60f8:      	sturb	w14, [x9, #-0x1]
    60fc:      	b.eq	0x6124 <generic_kprobe_filter_arg+0x6f4>
    6100:      	cmn	x8, #0x7e
    6104:      	b.eq	0x6124 <generic_kprobe_filter_arg+0x6f4>
    6108:      	add	w14, w12, w8
    610c:      	sub	x8, x8, #0x2
    6110:      	and	x14, x14, #0xfff
    6114:      	cmp	x10, x8
    6118:      	ldrb	w14, [x22, x14]
    611c:      	strb	w14, [x9], #0x2
    6120:      	b.ne	0x60e8 <generic_kprobe_filter_arg+0x6b8>
    6124:      	mov	w8, #0x1                // =1
    6128:      	mov	x0, x19
    612c:      	b	0x673c <generic_kprobe_filter_arg+0xd0c>
    6130:      	sub	w8, w8, #0x3
    6134:      	cmp	w8, #0x2
    6138:      	b.hs	0x6148 <generic_kprobe_filter_arg+0x718>
    613c:      	cmp	w24, #0x1fe
    6140:      	str	wzr, [sp, #0x88]
    6144:      	b.ls	0x69b4 <generic_kprobe_filter_arg+0xf84>
    6148:      	mov	x23, xzr
    614c:      	b	0x82fc <generic_kprobe_filter_arg+0x28cc>
    6150:      	cmp	w8, #0x20
    6154:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6158:      	lsl	x9, x12, x8
    615c:      	mov	w10, #0x101e            // =4126
    6160:      	tst	x9, x10
    6164:      	b.eq	0x68d8 <generic_kprobe_filter_arg+0xea8>
    6168:      	ldr	w9, [x29, #0x10]
    616c:      	cmp	w8, #0x2
    6170:      	b.le	0x6dd8 <generic_kprobe_filter_arg+0x13a8>
    6174:      	sub	w10, w8, #0x3
    6178:      	cmp	w10, #0x2
    617c:      	b.hs	0x72f8 <generic_kprobe_filter_arg+0x18c8>
    6180:      	ldrh	w10, [x22]
    6184:      	cmp	w9, w10
    6188:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    618c:      	b	0x7684 <generic_kprobe_filter_arg+0x1c54>
    6190:      	cmp	w9, #0x7
    6194:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6198:      	mov	x23, xzr
    619c:      	cmp	w9, #0x27
    61a0:      	stp	xzr, xzr, [sp, #0x78]
    61a4:      	str	xzr, [sp, #0x60]
    61a8:      	stp	xzr, xzr, [sp, #0x68]
    61ac:      	b.gt	0x61c0 <generic_kprobe_filter_arg+0x790>
    61b0:      	cmp	w9, #0x5
    61b4:      	b.eq	0x64dc <generic_kprobe_filter_arg+0xaac>
    61b8:      	cmp	w9, #0x7
    61bc:      	b	0x61cc <generic_kprobe_filter_arg+0x79c>
    61c0:      	cmp	w9, #0x28
    61c4:      	b.eq	0x64e4 <generic_kprobe_filter_arg+0xab4>
    61c8:      	cmp	w9, #0x29
    61cc:      	mov	x10, x22
    61d0:      	b.eq	0x650c <generic_kprobe_filter_arg+0xadc>
    61d4:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    61d8:      	sub	w10, w8, #0x1
    61dc:      	cmp	w10, #0x4
    61e0:      	b.lo	0x6240 <generic_kprobe_filter_arg+0x810>
    61e4:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    61e8:      	cmp	w8, #0x1
    61ec:      	b.eq	0x6b6c <generic_kprobe_filter_arg+0x113c>
    61f0:      	cmp	w8, #0x2
    61f4:      	b.ne	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    61f8:      	cmp	w9, #0xc
    61fc:      	b.hi	0x78b4 <generic_kprobe_filter_arg+0x1e84>
    6200:      	lsl	w11, w12, w9
    6204:      	mov	w13, #0x1402            // =5122
    6208:      	tst	w11, w13
    620c:      	b.eq	0x78b4 <generic_kprobe_filter_arg+0x1e84>
    6210:      	ldr	w11, [x22]
    6214:      	cmp	w11, w10
    6218:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    621c:      	b	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    6220:      	cmp	w9, #0x1c
    6224:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6228:      	cmp	w8, #0x20
    622c:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6230:      	lsl	x10, x12, x8
    6234:      	mov	w11, #0x101e            // =4126
    6238:      	tst	x10, x11
    623c:      	b.eq	0x6268 <generic_kprobe_filter_arg+0x838>
    6240:      	ldr	x10, [x29, #0x10]
    6244:      	cmp	w8, #0x2
    6248:      	b.le	0x6284 <generic_kprobe_filter_arg+0x854>
    624c:      	sub	w11, w8, #0x3
    6250:      	cmp	w11, #0x2
    6254:      	b.hs	0x64c4 <generic_kprobe_filter_arg+0xa94>
    6258:      	ldr	x11, [x22]
    625c:      	cmp	x11, x10
    6260:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    6264:      	b	0x723c <generic_kprobe_filter_arg+0x180c>
    6268:      	lsl	x10, x12, x8
    626c:      	tst	x10, #0xc00
    6270:      	b.ne	0x62b4 <generic_kprobe_filter_arg+0x884>
    6274:      	lsl	x10, x12, x8
    6278:      	tst	x10, #0x180000000
    627c:      	b.ne	0x658c <generic_kprobe_filter_arg+0xb5c>
    6280:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6284:      	cmp	w8, #0x1
    6288:      	b.eq	0x697c <generic_kprobe_filter_arg+0xf4c>
    628c:      	cmp	w8, #0x2
    6290:      	b.ne	0x723c <generic_kprobe_filter_arg+0x180c>
    6294:      	cmp	w9, #0xc
    6298:      	b.eq	0x62a4 <generic_kprobe_filter_arg+0x874>
    629c:      	cmp	w9, #0xa
    62a0:      	b.ne	0x7230 <generic_kprobe_filter_arg+0x1800>
    62a4:      	ldr	x11, [x22]
    62a8:      	cmp	x11, x10
    62ac:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    62b0:      	b	0x723c <generic_kprobe_filter_arg+0x180c>
    62b4:      	ldrb	w8, [x29, #0x10]
    62b8:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    62bc:      	add	x9, sp, #0x88
    62c0:      	add	x1, sp, #0x88
    62c4:      	str	w8, [sp, #0x88]
    62c8:      	mov	w8, #0x1                // =1
    62cc:      	ldr	x0, [x0]
    62d0:      	blr	x8
    62d4:      	cbz	x0, 0x699c <generic_kprobe_filter_arg+0xf6c>
    62d8:      	ldr	x8, [x22]
    62dc:      	add	x9, sp, #0x60
    62e0:      	add	x1, sp, #0x60
    62e4:      	str	x8, [sp, #0x60]
    62e8:      	mov	w8, #0x1                // =1
    62ec:      	blr	x8
    62f0:      	ldr	w8, [x29, #0x4]
    62f4:      	cmp	w8, #0xb
    62f8:      	b.eq	0x6e70 <generic_kprobe_filter_arg+0x1440>
    62fc:      	cmp	w8, #0xa
    6300:      	mov	w12, #0x1               // =1
    6304:      	b.eq	0x70ec <generic_kprobe_filter_arg+0x16bc>
    6308:      	mov	w8, wzr
    630c:      	b	0x70f4 <generic_kprobe_filter_arg+0x16c4>
    6310:      	ldr	w8, [x29, #0x10]
    6314:      	str	wzr, [sp, #0x88]
    6318:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    631c:      	add	x9, sp, #0x60
    6320:      	add	x1, sp, #0x60
    6324:      	str	w8, [sp, #0x60]
    6328:      	mov	w8, #0x1                // =1
    632c:      	ldr	x0, [x0]
    6330:      	blr	x8
    6334:      	mov	x23, xzr
    6338:      	cbz	w24, 0x72d0 <generic_kprobe_filter_arg+0x18a0>
    633c:      	mov	w12, #0x1               // =1
    6340:      	cbz	x0, 0x72d4 <generic_kprobe_filter_arg+0x18a4>
    6344:      	mov	x19, x0
    6348:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    634c:      	mov	w8, #0x1                // =1
    6350:      	ldr	x0, [x0]
    6354:      	add	x9, sp, #0x88
    6358:      	add	x1, sp, #0x88
    635c:      	mov	w23, #0x1               // =1
    6360:      	blr	x8
    6364:      	cbz	x0, 0x72c8 <generic_kprobe_filter_arg+0x1898>
    6368:      	cmp	w24, #0x7f
    636c:      	mov	w10, #0x7f              // =127
    6370:      	mov	x1, x0
    6374:      	mov	x8, xzr
    6378:      	add	x9, x22, #0x4
    637c:      	sub	x12, x23, x24
    6380:      	sub	w13, w24, #0x2
    6384:      	sub	w14, w24, #0x1
    6388:      	csel	w10, w24, w10, lo
    638c:      	lsl	w11, w10, #3
    6390:      	mov	x10, x0
    6394:      	str	w11, [x10], #0x5
    6398:      	neg	x11, x24
    639c:      	add	w15, w14, w8
    63a0:      	cmp	x12, x8
    63a4:      	and	x15, x15, #0xfff
    63a8:      	ldrb	w15, [x9, x15]
    63ac:      	sturb	w15, [x10, #-0x1]
    63b0:      	b.eq	0x63d8 <generic_kprobe_filter_arg+0x9a8>
    63b4:      	cmn	x8, #0x7e
    63b8:      	b.eq	0x63d8 <generic_kprobe_filter_arg+0x9a8>
    63bc:      	add	w15, w13, w8
    63c0:      	sub	x8, x8, #0x2
    63c4:      	and	x15, x15, #0xfff
    63c8:      	cmp	x11, x8
    63cc:      	ldrb	w15, [x9, x15]
    63d0:      	strb	w15, [x10], #0x2
    63d4:      	b.ne	0x639c <generic_kprobe_filter_arg+0x96c>
    63d8:      	mov	w8, #0x1                // =1
    63dc:      	mov	x0, x19
    63e0:      	blr	x8
    63e4:      	cmp	x0, #0x0
    63e8:      	cset	w23, ne
    63ec:      	b	0x72cc <generic_kprobe_filter_arg+0x189c>
    63f0:      	ldr	w8, [x29, #0x10]
    63f4:      	str	wzr, [sp, #0x88]
    63f8:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    63fc:      	add	x9, sp, #0x60
    6400:      	add	x1, sp, #0x60
    6404:      	str	w8, [sp, #0x60]
    6408:      	mov	w8, #0x1                // =1
    640c:      	ldr	x0, [x0]
    6410:      	blr	x8
    6414:      	mov	x23, xzr
    6418:      	cbz	w24, 0x82ec <generic_kprobe_filter_arg+0x28bc>
    641c:      	cbz	x0, 0x82ec <generic_kprobe_filter_arg+0x28bc>
    6420:      	mov	x19, x0
    6424:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6428:      	mov	w8, #0x1                // =1
    642c:      	ldr	x0, [x0]
    6430:      	add	x9, sp, #0x88
    6434:      	add	x1, sp, #0x88
    6438:      	blr	x8
    643c:      	cbz	x0, 0x7474 <generic_kprobe_filter_arg+0x1a44>
    6440:      	cmp	w24, #0xff
    6444:      	mov	w8, #0xff               // =255
    6448:      	add	x2, x22, #0x4
    644c:      	mov	x22, x0
    6450:      	csel	w1, w24, w8, lo
    6454:      	mov	x8, x0
    6458:      	lsl	w9, w1, #3
    645c:      	str	w9, [x8], #0x4
    6460:      	mov	w9, #0x4                // =4
    6464:      	mov	x0, x8
    6468:      	blr	x9
    646c:      	mov	w8, #0x1                // =1
    6470:      	mov	x0, x19
    6474:      	mov	x1, x22
    6478:      	blr	x8
    647c:      	cmp	x0, #0x0
    6480:      	cset	w23, ne
    6484:      	b	0x7478 <generic_kprobe_filter_arg+0x1a48>
    6488:      	ldrb	w8, [x29, #0x10]
    648c:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6490:      	add	x9, sp, #0x88
    6494:      	add	x1, sp, #0x88
    6498:      	str	w8, [sp, #0x88]
    649c:      	mov	w8, #0x1                // =1
    64a0:      	ldr	x0, [x0]
    64a4:      	blr	x8
    64a8:      	cbz	x0, 0x7214 <generic_kprobe_filter_arg+0x17e4>
    64ac:      	ldr	w8, [x22]
    64b0:      	add	x9, sp, #0x60
    64b4:      	add	x1, sp, #0x60
    64b8:      	str	x8, [sp, #0x60]
    64bc:      	mov	w8, #0x1                // =1
    64c0:      	b	0x71dc <generic_kprobe_filter_arg+0x17ac>
    64c4:      	cmp	w8, #0xc
    64c8:      	b.ne	0x723c <generic_kprobe_filter_arg+0x180c>
    64cc:      	ldr	x11, [x22]
    64d0:      	tst	x11, x10
    64d4:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    64d8:      	b	0x723c <generic_kprobe_filter_arg+0x180c>
    64dc:      	mov	x10, xzr
    64e0:      	b	0x650c <generic_kprobe_filter_arg+0xadc>
    64e4:      	ldrh	w11, [x22]
    64e8:      	mov	x10, xzr
    64ec:      	strh	w11, [sp, #0x86]
    64f0:      	ldrh	w11, [x22, #0x2]
    64f4:      	strh	w11, [sp, #0x80]
    64f8:      	ldr	x11, [x22, #0x8]
    64fc:      	str	x11, [sp, #0x60]
    6500:      	ldr	x11, [x22, #0x10]
    6504:      	add	x22, sp, #0x60
    6508:      	str	x11, [sp, #0x68]
    650c:      	mov	x23, xzr
    6510:      	cmp	w8, #0x13
    6514:      	b.le	0x653c <generic_kprobe_filter_arg+0xb0c>
    6518:      	cmp	w8, #0x17
    651c:      	b.gt	0x6564 <generic_kprobe_filter_arg+0xb34>
    6520:      	sub	w9, w8, #0x14
    6524:      	cmp	w9, #0x2
    6528:      	b.lo	0x6a6c <generic_kprobe_filter_arg+0x103c>
    652c:      	sub	w9, w8, #0x16
    6530:      	cmp	w9, #0x2
    6534:      	b.lo	0x6a58 <generic_kprobe_filter_arg+0x1028>
    6538:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    653c:      	cmp	w8, #0xf
    6540:      	b.le	0x6794 <generic_kprobe_filter_arg+0xd64>
    6544:      	cmp	w8, #0x11
    6548:      	b.gt	0x6a48 <generic_kprobe_filter_arg+0x1018>
    654c:      	cmp	w8, #0x10
    6550:      	b.eq	0x6a58 <generic_kprobe_filter_arg+0x1028>
    6554:      	cmp	w8, #0x11
    6558:      	b.ne	0x5cc4 <generic_kprobe_filter_arg+0x294>
    655c:      	ldrh	w23, [x22, #0x24]
    6560:      	b	0x71a8 <generic_kprobe_filter_arg+0x1778>
    6564:      	cmp	w8, #0x1b
    6568:      	b.gt	0x6a80 <generic_kprobe_filter_arg+0x1050>
    656c:      	cmp	w8, #0x18
    6570:      	b.eq	0x6ab0 <generic_kprobe_filter_arg+0x1080>
    6574:      	cmp	w8, #0x19
    6578:      	b.eq	0x6aa4 <generic_kprobe_filter_arg+0x1074>
    657c:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6580:      	sub	w10, w8, #0x1f
    6584:      	cmp	w10, #0x2
    6588:      	b.hs	0x6f30 <generic_kprobe_filter_arg+0x1500>
    658c:      	cmp	w8, #0x1f
    6590:      	b.ne	0x676c <generic_kprobe_filter_arg+0xd3c>
    6594:      	ldp	x11, x10, [x29, #0x10]
    6598:      	cmp	w9, #0xa
    659c:      	b.eq	0x65a8 <generic_kprobe_filter_arg+0xb78>
    65a0:      	cmp	w9, #0xc
    65a4:      	b.ne	0x7118 <generic_kprobe_filter_arg+0x16e8>
    65a8:      	ldr	x8, [x22]
    65ac:      	cmp	x11, x8
    65b0:      	b.gt	0x712c <generic_kprobe_filter_arg+0x16fc>
    65b4:      	cmp	x8, x10
    65b8:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    65bc:      	b	0x712c <generic_kprobe_filter_arg+0x16fc>
    65c0:      	cmp	w8, #0x21
    65c4:      	b.eq	0x6b94 <generic_kprobe_filter_arg+0x1164>
    65c8:      	cmp	w8, #0x22
    65cc:      	b.ne	0x6c68 <generic_kprobe_filter_arg+0x1238>
    65d0:      	mov	x23, xzr
    65d4:      	mov	w19, wzr
    65d8:      	add	x8, x29, #0x10
    65dc:      	str	x8, [sp, #0x28]
    65e0:      	ldr	x8, [sp, #0x28]
    65e4:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    65e8:      	add	x9, sp, #0x60
    65ec:      	add	x1, sp, #0x60
    65f0:      	ldr	w8, [x8, x23, lsl #2]
    65f4:      	str	w8, [sp, #0x60]
    65f8:      	mov	w8, #0x1                // =1
    65fc:      	ldr	x0, [x0]
    6600:      	blr	x8
    6604:      	cbz	x0, 0x6c50 <generic_kprobe_filter_arg+0x1220>
    6608:      	cbz	w24, 0x6690 <generic_kprobe_filter_arg+0xc60>
    660c:      	mov	x8, xzr
    6610:      	mov	x9, x22
    6614:      	mov	x10, x24
    6618:      	b	0x6630 <generic_kprobe_filter_arg+0xc00>
    661c:      	add	x8, x8, #0x1
    6620:      	sub	x10, x10, #0x1
    6624:      	add	x9, x9, #0x1
    6628:      	cmp	x8, x24
    662c:      	b.eq	0x6690 <generic_kprobe_filter_arg+0xc60>
    6630:      	mov	x11, xzr
    6634:      	nop
    6638:      	nop
    663c:      	nop
    6640:      	cmp	x10, x11
    6644:      	b.eq	0x661c <generic_kprobe_filter_arg+0xbec>
    6648:      	ldrb	w12, [x0, x11]
    664c:      	cbz	w12, 0x668c <generic_kprobe_filter_arg+0xc5c>
    6650:      	ldrb	w13, [x9, x11]
    6654:      	sub	w14, w13, #0x41
    6658:      	orr	w15, w13, #0x20
    665c:      	cmp	w14, #0x1a
    6660:      	sub	w14, w12, #0x41
    6664:      	csel	w13, w15, w13, lo
    6668:      	orr	w15, w12, #0x20
    666c:      	cmp	w14, #0x1a
    6670:      	csel	w12, w15, w12, lo
    6674:      	cmp	x11, #0x62
    6678:      	b.hi	0x661c <generic_kprobe_filter_arg+0xbec>
    667c:      	add	x11, x11, #0x1
    6680:      	cmp	w13, w12
    6684:      	b.eq	0x6640 <generic_kprobe_filter_arg+0xc10>
    6688:      	b	0x661c <generic_kprobe_filter_arg+0xbec>
    668c:      	tbz	w8, #0x1f, 0x7764 <generic_kprobe_filter_arg+0x1d34>
    6690:      	ldr	w9, [x29, #0x8]
    6694:      	add	w8, w19, #0xc
    6698:      	cmp	w8, w9
    669c:      	b.hs	0x6c50 <generic_kprobe_filter_arg+0x1220>
    66a0:      	add	x23, x23, #0x1
    66a4:      	add	w19, w19, #0x4
    66a8:      	cmp	x23, #0x64
    66ac:      	b.ne	0x65e0 <generic_kprobe_filter_arg+0xbb0>
    66b0:      	b	0x6c50 <generic_kprobe_filter_arg+0x1220>
    66b4:      	ldr	w8, [x29, #0x10]
    66b8:      	str	wzr, [sp, #0x88]
    66bc:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    66c0:      	add	x9, sp, #0x60
    66c4:      	add	x1, sp, #0x60
    66c8:      	str	w8, [sp, #0x60]
    66cc:      	mov	w8, #0x1                // =1
    66d0:      	ldr	x0, [x0]
    66d4:      	blr	x8
    66d8:      	mov	x23, xzr
    66dc:      	cbz	w24, 0x6c58 <generic_kprobe_filter_arg+0x1228>
    66e0:      	cbz	x0, 0x6c58 <generic_kprobe_filter_arg+0x1228>
    66e4:      	mov	x19, x0
    66e8:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    66ec:      	mov	w8, #0x1                // =1
    66f0:      	ldr	x0, [x0]
    66f4:      	add	x9, sp, #0x88
    66f8:      	add	x1, sp, #0x88
    66fc:      	blr	x8
    6700:      	cbz	x0, 0x6c50 <generic_kprobe_filter_arg+0x1220>
    6704:      	cmp	w24, #0xff
    6708:      	mov	w8, #0xff               // =255
    670c:      	mov	x2, x22
    6710:      	csel	w1, w24, w8, lo
    6714:      	mov	x8, x0
    6718:      	mov	x24, x0
    671c:      	lsl	w9, w1, #3
    6720:      	str	w9, [x8], #0x4
    6724:      	mov	w9, #0x4                // =4
    6728:      	mov	x0, x8
    672c:      	blr	x9
    6730:      	mov	w8, #0x1                // =1
    6734:      	mov	x0, x19
    6738:      	mov	x1, x24
    673c:      	blr	x8
    6740:      	cmp	x0, #0x0
    6744:      	cset	w23, ne
    6748:      	b	0x6c54 <generic_kprobe_filter_arg+0x1224>
    674c:      	cmp	w24, #0x1fe
    6750:      	str	wzr, [sp, #0x88]
    6754:      	b.ls	0x6c90 <generic_kprobe_filter_arg+0x1260>
    6758:      	mov	x23, xzr
    675c:      	ldr	w8, [x29, #0x4]
    6760:      	cmp	w8, #0x25
    6764:      	b.ls	0x6c74 <generic_kprobe_filter_arg+0x1244>
    6768:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    676c:      	ldp	x11, x8, [x29, #0x10]
    6770:      	cmp	w9, #0xc
    6774:      	b.eq	0x6780 <generic_kprobe_filter_arg+0xd50>
    6778:      	cmp	w9, #0xa
    677c:      	b.ne	0x7164 <generic_kprobe_filter_arg+0x1734>
    6780:      	ldr	x10, [x22]
    6784:      	cmp	x11, x10
    6788:      	ccmp	x10, x8, #0x0, le
    678c:      	cset	w8, le
    6790:      	b	0x7174 <generic_kprobe_filter_arg+0x1744>
    6794:      	cmp	w8, #0xd
    6798:      	b.eq	0x6ab0 <generic_kprobe_filter_arg+0x1080>
    679c:      	cmp	w8, #0xe
    67a0:      	b.eq	0x6aa4 <generic_kprobe_filter_arg+0x1074>
    67a4:      	cmp	w8, #0xf
    67a8:      	b.eq	0x6a6c <generic_kprobe_filter_arg+0x103c>
    67ac:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    67b0:      	cmp	w8, #0x20
    67b4:      	b.gt	0x6d38 <generic_kprobe_filter_arg+0x1308>
    67b8:      	cmp	w8, #0x1a
    67bc:      	b.eq	0x6e90 <generic_kprobe_filter_arg+0x1460>
    67c0:      	cmp	w8, #0x1b
    67c4:      	b.ne	0x872c <generic_kprobe_filter_arg+0x2cfc>
    67c8:      	ldr	w8, [x29, #0x10]
    67cc:      	str	wzr, [sp, #0x88]
    67d0:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    67d4:      	add	x9, sp, #0x60
    67d8:      	add	x1, sp, #0x60
    67dc:      	mov	w19, #0x1               // =1
    67e0:      	str	w8, [sp, #0x60]
    67e4:      	mov	w8, #0x1                // =1
    67e8:      	ldr	x0, [x0]
    67ec:      	blr	x8
    67f0:      	mov	x23, xzr
    67f4:      	cbz	w22, 0x871c <generic_kprobe_filter_arg+0x2cec>
    67f8:      	cbz	x0, 0x871c <generic_kprobe_filter_arg+0x2cec>
    67fc:      	mov	x23, x0
    6800:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6804:      	mov	w8, #0x1                // =1
    6808:      	ldr	x0, [x0]
    680c:      	add	x9, sp, #0x88
    6810:      	add	x1, sp, #0x88
    6814:      	blr	x8
    6818:      	cbz	x0, 0x8718 <generic_kprobe_filter_arg+0x2ce8>
    681c:      	cmp	w22, #0x7f
    6820:      	mov	w9, #0x7f               // =127
    6824:      	mov	x1, x0
    6828:      	mov	x8, xzr
    682c:      	sub	x11, x19, x22
    6830:      	sub	w12, w22, #0x2
    6834:      	sub	w13, w22, #0x1
    6838:      	csel	w9, w22, w9, lo
    683c:      	lsl	w10, w9, #3
    6840:      	mov	x9, x0
    6844:      	str	w10, [x9], #0x5
    6848:      	neg	x10, x22
    684c:      	add	w14, w13, w8
    6850:      	cmp	x11, x8
    6854:      	and	x14, x14, #0xfff
    6858:      	ldrb	w14, [x24, x14]
    685c:      	sturb	w14, [x9, #-0x1]
    6860:      	b.eq	0x6888 <generic_kprobe_filter_arg+0xe58>
    6864:      	cmn	x8, #0x7e
    6868:      	b.eq	0x6888 <generic_kprobe_filter_arg+0xe58>
    686c:      	add	w14, w12, w8
    6870:      	sub	x8, x8, #0x2
    6874:      	and	x14, x14, #0xfff
    6878:      	cmp	x10, x8
    687c:      	ldrb	w14, [x24, x14]
    6880:      	strb	w14, [x9], #0x2
    6884:      	b.ne	0x684c <generic_kprobe_filter_arg+0xe1c>
    6888:      	mov	w8, #0x1                // =1
    688c:      	mov	x0, x23
    6890:      	b	0x8708 <generic_kprobe_filter_arg+0x2cd8>
    6894:      	cmp	w8, #0xc
    6898:      	b.ne	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    689c:      	ldr	w11, [x22]
    68a0:      	tst	w11, w10
    68a4:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    68a8:      	b	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    68ac:      	lsl	x9, x12, x8
    68b0:      	tst	x9, #0xc00
    68b4:      	b.ne	0x6df8 <generic_kprobe_filter_arg+0x13c8>
    68b8:      	lsl	x9, x12, x8
    68bc:      	tst	x9, #0x180000000
    68c0:      	b.eq	0x5b2c <generic_kprobe_filter_arg+0xfc>
    68c4:      	cmp	w8, #0x1f
    68c8:      	b.ne	0x7480 <generic_kprobe_filter_arg+0x1a50>
    68cc:      	ldr	w9, [x29, #0x10]
    68d0:      	ldrb	w8, [x22]
    68d4:      	b	0x6900 <generic_kprobe_filter_arg+0xed0>
    68d8:      	lsl	x9, x12, x8
    68dc:      	tst	x9, #0xc00
    68e0:      	b.ne	0x6e34 <generic_kprobe_filter_arg+0x1404>
    68e4:      	lsl	x9, x12, x8
    68e8:      	tst	x9, #0x180000000
    68ec:      	b.eq	0x5b2c <generic_kprobe_filter_arg+0xfc>
    68f0:      	cmp	w8, #0x1f
    68f4:      	b.ne	0x74a4 <generic_kprobe_filter_arg+0x1a74>
    68f8:      	ldr	w9, [x29, #0x10]
    68fc:      	ldrh	w8, [x22]
    6900:      	cmp	w9, w8
    6904:      	b.hi	0x6914 <generic_kprobe_filter_arg+0xee4>
    6908:      	ldr	w9, [x29, #0x14]
    690c:      	cmp	w9, w8
    6910:      	b.hs	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6914:      	ldr	w9, [x29, #0x8]
    6918:      	cmp	w9, #0x11
    691c:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6920:      	ldr	w10, [x29, #0x18]
    6924:      	cmp	w10, w8
    6928:      	b.hi	0x6938 <generic_kprobe_filter_arg+0xf08>
    692c:      	ldr	w10, [x29, #0x1c]
    6930:      	cmp	w10, w8
    6934:      	b.hs	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6938:      	cmp	w9, #0x19
    693c:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6940:      	ldr	w10, [x29, #0x20]
    6944:      	cmp	w10, w8
    6948:      	b.hi	0x6958 <generic_kprobe_filter_arg+0xf28>
    694c:      	ldr	w10, [x29, #0x24]
    6950:      	cmp	w10, w8
    6954:      	b.hs	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6958:      	cmp	w9, #0x21
    695c:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6960:      	ldr	w9, [x29, #0x28]
    6964:      	cmp	w9, w8
    6968:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    696c:      	ldr	w9, [x29, #0x2c]
    6970:      	cmp	w9, w8
    6974:      	b.hs	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6978:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    697c:      	cmp	w9, #0xc
    6980:      	b.eq	0x698c <generic_kprobe_filter_arg+0xf5c>
    6984:      	cmp	w9, #0xa
    6988:      	b.ne	0x7220 <generic_kprobe_filter_arg+0x17f0>
    698c:      	ldr	x11, [x22]
    6990:      	cmp	x11, x10
    6994:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6998:      	b	0x723c <generic_kprobe_filter_arg+0x180c>
    699c:      	ldp	x16, x15, [sp, #0x40]
    69a0:      	mov	x23, xzr
    69a4:      	mov	w2, #0x5ea0             // =24224
    69a8:      	mov	w12, #0x1               // =1
    69ac:      	ldr	x17, [sp, #0x38]
    69b0:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    69b4:      	and	w8, w24, #0xffff
    69b8:      	cmp	w8, #0x90
    69bc:      	b.hi	0x6f90 <generic_kprobe_filter_arg+0x1560>
    69c0:      	and	w8, w24, #0xff
    69c4:      	mov	w9, #0xab               // =171
    69c8:      	tst	w24, #0xffff
    69cc:      	mul	w8, w8, w9
    69d0:      	mov	w9, #0x18               // =24
    69d4:      	lsr	w8, w8, #12
    69d8:      	msub	w8, w8, w9, w24
    69dc:      	b.eq	0x69ec <generic_kprobe_filter_arg+0xfbc>
    69e0:      	tst	w8, #0xff
    69e4:      	mov	w11, w24
    69e8:      	b.eq	0x6a00 <generic_kprobe_filter_arg+0xfd0>
    69ec:      	sub	w8, w24, w8, uxtb
    69f0:      	and	w9, w8, #0xffff
    69f4:      	add	w11, w8, #0x18
    69f8:      	cmp	w9, #0x78
    69fc:      	b.hi	0x6fa4 <generic_kprobe_filter_arg+0x1574>
    6a00:      	and	w8, w11, #0xff
    6a04:      	mov	w9, #0xab               // =171
    6a08:      	mul	w8, w8, w9
    6a0c:      	lsr	w8, w8, #12
    6a10:      	sub	w10, w8, #0x1
    6a14:      	b	0x6fb4 <generic_kprobe_filter_arg+0x1584>
    6a18:      	ldp	w11, w8, [x29, #0x10]
    6a1c:      	cmp	w9, #0xc
    6a20:      	b.hi	0x7718 <generic_kprobe_filter_arg+0x1ce8>
    6a24:      	lsl	w10, w12, w9
    6a28:      	mov	w13, #0x1402            // =5122
    6a2c:      	tst	w10, w13
    6a30:      	b.eq	0x7718 <generic_kprobe_filter_arg+0x1ce8>
    6a34:      	ldr	w10, [x22]
    6a38:      	cmp	w11, w10
    6a3c:      	ccmp	w10, w8, #0x0, le
    6a40:      	cset	w8, le
    6a44:      	b	0x7728 <generic_kprobe_filter_arg+0x1cf8>
    6a48:      	cmp	w8, #0x12
    6a4c:      	b.eq	0x6a6c <generic_kprobe_filter_arg+0x103c>
    6a50:      	cmp	w8, #0x13
    6a54:      	b.ne	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6a58:      	ldrh	w24, [x22, #0x22]
    6a5c:      	mov	w11, wzr
    6a60:      	mov	w13, wzr
    6a64:      	mov	x19, xzr
    6a68:      	b	0x6abc <generic_kprobe_filter_arg+0x108c>
    6a6c:      	ldrh	w24, [x22, #0x20]
    6a70:      	mov	w11, wzr
    6a74:      	mov	w13, wzr
    6a78:      	mov	x19, xzr
    6a7c:      	b	0x6abc <generic_kprobe_filter_arg+0x108c>
    6a80:      	cmp	w8, #0x1c
    6a84:      	b.eq	0x71a4 <generic_kprobe_filter_arg+0x1774>
    6a88:      	cmp	w8, #0x1d
    6a8c:      	b.ne	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6a90:      	cmp	w9, #0x7
    6a94:      	b.ne	0x77f0 <generic_kprobe_filter_arg+0x1dc0>
    6a98:      	cbnz	x10, 0x7800 <generic_kprobe_filter_arg+0x1dd0>
    6a9c:      	mov	x19, xzr
    6aa0:      	b	0x7814 <generic_kprobe_filter_arg+0x1de4>
    6aa4:      	ldp	w11, w13, [x22, #0x10]
    6aa8:      	ldr	x19, [x22, #0x18]
    6aac:      	b	0x6ab8 <generic_kprobe_filter_arg+0x1088>
    6ab0:      	ldp	w11, w13, [x22]
    6ab4:      	ldr	x19, [x22, #0x8]
    6ab8:      	mov	x24, xzr
    6abc:      	mov	x23, xzr
    6ac0:      	cmp	w8, #0x11
    6ac4:      	b.gt	0x6af0 <generic_kprobe_filter_arg+0x10c0>
    6ac8:      	sub	w9, w8, #0xd
    6acc:      	cmp	w9, #0x2
    6ad0:      	b.lo	0x6b1c <generic_kprobe_filter_arg+0x10ec>
    6ad4:      	ldr	x19, [sp, #0x30]
    6ad8:      	sub	w9, w8, #0xf
    6adc:      	cmp	w9, #0x2
    6ae0:      	b.lo	0x6d04 <generic_kprobe_filter_arg+0x12d4>
    6ae4:      	cmp	w8, #0x11
    6ae8:      	b.eq	0x71a8 <generic_kprobe_filter_arg+0x1778>
    6aec:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6af0:      	cmp	w8, #0x19
    6af4:      	b.hi	0x6cf4 <generic_kprobe_filter_arg+0x12c4>
    6af8:      	lsl	w9, w12, w8
    6afc:      	mov	w10, #0x500000          // =5242880
    6b00:      	tst	w9, w10
    6b04:      	b.ne	0x6f70 <generic_kprobe_filter_arg+0x1540>
    6b08:      	mov	w10, #0xa00000          // =10485760
    6b0c:      	tst	w9, w10
    6b10:      	b.ne	0x6f80 <generic_kprobe_filter_arg+0x1550>
    6b14:      	tst	w9, #0x3000000
    6b18:      	b.eq	0x6cf4 <generic_kprobe_filter_arg+0x12c4>
    6b1c:      	ldrh	w8, [x22, #0x26]
    6b20:      	cmp	w8, #0xa
    6b24:      	b.eq	0x707c <generic_kprobe_filter_arg+0x164c>
    6b28:      	cmp	w8, #0x2
    6b2c:      	b.ne	0x7108 <generic_kprobe_filter_arg+0x16d8>
    6b30:      	ldr	w8, [x29, #0x10]
    6b34:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6b38:      	add	x9, sp, #0xac
    6b3c:      	add	x1, sp, #0xac
    6b40:      	str	w8, [sp, #0xac]
    6b44:      	mov	w8, #0x1                // =1
    6b48:      	mov	w22, w11
    6b4c:      	ldr	x0, [x0]
    6b50:      	blr	x8
    6b54:      	ldr	x19, [sp, #0x30]
    6b58:      	cbz	x0, 0x7988 <generic_kprobe_filter_arg+0x1f58>
    6b5c:      	mov	w8, #0x20               // =32
    6b60:      	add	x1, sp, #0x88
    6b64:      	stp	w8, w22, [sp, #0x88]
    6b68:      	b	0x70c4 <generic_kprobe_filter_arg+0x1694>
    6b6c:      	cmp	w9, #0xc
    6b70:      	b.hi	0x78a4 <generic_kprobe_filter_arg+0x1e74>
    6b74:      	lsl	w11, w12, w9
    6b78:      	mov	w13, #0x1402            // =5122
    6b7c:      	tst	w11, w13
    6b80:      	b.eq	0x78a4 <generic_kprobe_filter_arg+0x1e74>
    6b84:      	ldr	w11, [x22]
    6b88:      	cmp	w11, w10
    6b8c:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6b90:      	b	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    6b94:      	mov	x19, xzr
    6b98:      	mov	w23, wzr
    6b9c:      	add	x8, x29, #0x10
    6ba0:      	str	x8, [sp, #0x28]
    6ba4:      	ldr	x8, [sp, #0x28]
    6ba8:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6bac:      	add	x9, sp, #0x60
    6bb0:      	add	x1, sp, #0x60
    6bb4:      	ldr	w8, [x8, x19, lsl #2]
    6bb8:      	str	w8, [sp, #0x60]
    6bbc:      	mov	w8, #0x1                // =1
    6bc0:      	ldr	x0, [x0]
    6bc4:      	blr	x8
    6bc8:      	cbz	x0, 0x6c50 <generic_kprobe_filter_arg+0x1220>
    6bcc:      	cbz	w24, 0x6c30 <generic_kprobe_filter_arg+0x1200>
    6bd0:      	mov	x8, xzr
    6bd4:      	mov	x9, x22
    6bd8:      	mov	x10, x24
    6bdc:      	b	0x6bf4 <generic_kprobe_filter_arg+0x11c4>
    6be0:      	add	x8, x8, #0x1
    6be4:      	sub	x10, x10, #0x1
    6be8:      	add	x9, x9, #0x1
    6bec:      	cmp	x8, x24
    6bf0:      	b.eq	0x6c30 <generic_kprobe_filter_arg+0x1200>
    6bf4:      	mov	x11, xzr
    6bf8:      	nop
    6bfc:      	nop
    6c00:      	cmp	x10, x11
    6c04:      	b.eq	0x6be0 <generic_kprobe_filter_arg+0x11b0>
    6c08:      	ldrb	w12, [x0, x11]
    6c0c:      	cbz	w12, 0x6c2c <generic_kprobe_filter_arg+0x11fc>
    6c10:      	cmp	x11, #0x62
    6c14:      	b.hi	0x6be0 <generic_kprobe_filter_arg+0x11b0>
    6c18:      	ldrb	w13, [x9, x11]
    6c1c:      	add	x11, x11, #0x1
    6c20:      	cmp	w13, w12
    6c24:      	b.eq	0x6c00 <generic_kprobe_filter_arg+0x11d0>
    6c28:      	b	0x6be0 <generic_kprobe_filter_arg+0x11b0>
    6c2c:      	tbz	w8, #0x1f, 0x7764 <generic_kprobe_filter_arg+0x1d34>
    6c30:      	ldr	w9, [x29, #0x8]
    6c34:      	add	w8, w23, #0xc
    6c38:      	cmp	w8, w9
    6c3c:      	b.hs	0x6c50 <generic_kprobe_filter_arg+0x1220>
    6c40:      	add	x19, x19, #0x1
    6c44:      	add	w23, w23, #0x4
    6c48:      	cmp	x19, #0x64
    6c4c:      	b.ne	0x6ba4 <generic_kprobe_filter_arg+0x1174>
    6c50:      	mov	x23, xzr
    6c54:      	ldr	x19, [sp, #0x30]
    6c58:      	ldp	x16, x15, [sp, #0x40]
    6c5c:      	mov	w2, #0x5ea0             // =24224
    6c60:      	mov	w12, #0x1               // =1
    6c64:      	ldr	x17, [sp, #0x38]
    6c68:      	ldr	w8, [x29, #0x4]
    6c6c:      	cmp	w8, #0x25
    6c70:      	b.hi	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6c74:      	mov	x9, #0x50               // =80
    6c78:      	lsl	x8, x12, x8
    6c7c:      	movk	x9, #0xc00, lsl #16
    6c80:      	movk	x9, #0x20, lsl #32
    6c84:      	tst	x8, x9
    6c88:      	b.ne	0x8754 <generic_kprobe_filter_arg+0x2d24>
    6c8c:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6c90:      	and	w8, w24, #0xffff
    6c94:      	cmp	w8, #0x90
    6c98:      	b.hi	0x7310 <generic_kprobe_filter_arg+0x18e0>
    6c9c:      	and	w8, w24, #0xff
    6ca0:      	mov	w9, #0xab               // =171
    6ca4:      	tst	w24, #0xffff
    6ca8:      	mul	w8, w8, w9
    6cac:      	mov	w9, #0x18               // =24
    6cb0:      	lsr	w8, w8, #12
    6cb4:      	msub	w8, w8, w9, w24
    6cb8:      	b.eq	0x6cc8 <generic_kprobe_filter_arg+0x1298>
    6cbc:      	tst	w8, #0xff
    6cc0:      	mov	w11, w24
    6cc4:      	b.eq	0x6cdc <generic_kprobe_filter_arg+0x12ac>
    6cc8:      	sub	w8, w24, w8, uxtb
    6ccc:      	and	w9, w8, #0xffff
    6cd0:      	add	w11, w8, #0x18
    6cd4:      	cmp	w9, #0x78
    6cd8:      	b.hi	0x7324 <generic_kprobe_filter_arg+0x18f4>
    6cdc:      	and	w8, w11, #0xff
    6ce0:      	mov	w9, #0xab               // =171
    6ce4:      	mul	w8, w8, w9
    6ce8:      	lsr	w8, w8, #12
    6cec:      	sub	w10, w8, #0x1
    6cf0:      	b	0x7334 <generic_kprobe_filter_arg+0x1904>
    6cf4:      	ldr	x19, [sp, #0x30]
    6cf8:      	sub	w8, w8, #0x12
    6cfc:      	cmp	w8, #0x2
    6d00:      	b.hs	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6d04:      	ldrb	w8, [x29, #0x10]
    6d08:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6d0c:      	add	x9, sp, #0xac
    6d10:      	add	x1, sp, #0xac
    6d14:      	str	w8, [sp, #0xac]
    6d18:      	mov	w8, #0x1                // =1
    6d1c:      	ldr	x0, [x0]
    6d20:      	blr	x8
    6d24:      	cbz	x0, 0x7214 <generic_kprobe_filter_arg+0x17e4>
    6d28:      	str	x24, [sp, #0x88]
    6d2c:      	mov	w8, #0x1                // =1
    6d30:      	add	x9, sp, #0x88
    6d34:      	b	0x71d8 <generic_kprobe_filter_arg+0x17a8>
    6d38:      	cmp	w8, #0x21
    6d3c:      	b.eq	0x7510 <generic_kprobe_filter_arg+0x1ae0>
    6d40:      	cmp	w8, #0x22
    6d44:      	b.ne	0x872c <generic_kprobe_filter_arg+0x2cfc>
    6d48:      	mov	w19, #0x10              // =16
    6d4c:      	ldr	w8, [x29, x19]
    6d50:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6d54:      	add	x9, sp, #0x60
    6d58:      	add	x1, sp, #0x60
    6d5c:      	str	w8, [sp, #0x60]
    6d60:      	mov	w8, #0x1                // =1
    6d64:      	ldr	x0, [x0]
    6d68:      	blr	x8
    6d6c:      	cbz	x0, 0x7ee0 <generic_kprobe_filter_arg+0x24b0>
    6d70:      	mov	x1, x0
    6d74:      	mov	x0, x24
    6d78:      	mov	x2, x22
    6d7c:      	bl	0x6d7c <generic_kprobe_filter_arg+0x134c>
    6d80:      	tbz	w0, #0x1f, 0x7ee8 <generic_kprobe_filter_arg+0x24b8>
    6d84:      	ldr	w8, [x29, #0x8]
    6d88:      	add	x19, x19, #0x4
    6d8c:      	mov	w12, #0x1               // =1
    6d90:      	mov	x23, xzr
    6d94:      	sub	w9, w19, #0x8
    6d98:      	cmp	w9, w8
    6d9c:      	b.hs	0x7ef0 <generic_kprobe_filter_arg+0x24c0>
    6da0:      	ldp	x16, x15, [sp, #0x40]
    6da4:      	cmp	x19, #0x1a0
    6da8:      	mov	w2, #0x5ea0             // =24224
    6dac:      	ldr	x17, [sp, #0x38]
    6db0:      	b.ne	0x6d4c <generic_kprobe_filter_arg+0x131c>
    6db4:      	b	0x872c <generic_kprobe_filter_arg+0x2cfc>
    6db8:      	cmp	w8, #0x1
    6dbc:      	b.eq	0x7638 <generic_kprobe_filter_arg+0x1c08>
    6dc0:      	cmp	w8, #0x2
    6dc4:      	b.ne	0x7644 <generic_kprobe_filter_arg+0x1c14>
    6dc8:      	ldrb	w10, [x22]
    6dcc:      	cmp	w9, w10
    6dd0:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6dd4:      	b	0x7644 <generic_kprobe_filter_arg+0x1c14>
    6dd8:      	cmp	w8, #0x1
    6ddc:      	b.eq	0x7678 <generic_kprobe_filter_arg+0x1c48>
    6de0:      	cmp	w8, #0x2
    6de4:      	b.ne	0x7684 <generic_kprobe_filter_arg+0x1c54>
    6de8:      	ldrh	w10, [x22]
    6dec:      	cmp	w9, w10
    6df0:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    6df4:      	b	0x7684 <generic_kprobe_filter_arg+0x1c54>
    6df8:      	ldrb	w8, [x29, #0x10]
    6dfc:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6e00:      	add	x9, sp, #0x88
    6e04:      	add	x1, sp, #0x88
    6e08:      	str	w8, [sp, #0x88]
    6e0c:      	mov	w8, #0x1                // =1
    6e10:      	ldr	x0, [x0]
    6e14:      	blr	x8
    6e18:      	cbz	x0, 0x7214 <generic_kprobe_filter_arg+0x17e4>
    6e1c:      	ldrb	w8, [x22]
    6e20:      	add	x9, sp, #0x60
    6e24:      	add	x1, sp, #0x60
    6e28:      	str	x8, [sp, #0x60]
    6e2c:      	mov	w8, #0x1                // =1
    6e30:      	b	0x71dc <generic_kprobe_filter_arg+0x17ac>
    6e34:      	ldrb	w8, [x29, #0x10]
    6e38:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6e3c:      	add	x9, sp, #0x88
    6e40:      	add	x1, sp, #0x88
    6e44:      	str	w8, [sp, #0x88]
    6e48:      	mov	w8, #0x1                // =1
    6e4c:      	ldr	x0, [x0]
    6e50:      	blr	x8
    6e54:      	cbz	x0, 0x7214 <generic_kprobe_filter_arg+0x17e4>
    6e58:      	ldrh	w8, [x22]
    6e5c:      	add	x9, sp, #0x60
    6e60:      	add	x1, sp, #0x60
    6e64:      	str	x8, [sp, #0x60]
    6e68:      	mov	w8, #0x1                // =1
    6e6c:      	b	0x71dc <generic_kprobe_filter_arg+0x17ac>
    6e70:      	ldp	x16, x15, [sp, #0x40]
    6e74:      	cmp	x0, #0x0
    6e78:      	mov	w2, #0x5ea0             // =24224
    6e7c:      	mov	w12, #0x1               // =1
    6e80:      	cset	w8, eq
    6e84:      	ldr	x17, [sp, #0x38]
    6e88:      	mov	w23, w8
    6e8c:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6e90:      	ldr	w8, [x29, #0x10]
    6e94:      	str	wzr, [sp, #0x88]
    6e98:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6e9c:      	add	x9, sp, #0x60
    6ea0:      	add	x1, sp, #0x60
    6ea4:      	str	w8, [sp, #0x60]
    6ea8:      	mov	w8, #0x1                // =1
    6eac:      	ldr	x0, [x0]
    6eb0:      	blr	x8
    6eb4:      	mov	x23, xzr
    6eb8:      	cbz	w22, 0x871c <generic_kprobe_filter_arg+0x2cec>
    6ebc:      	cbz	x0, 0x871c <generic_kprobe_filter_arg+0x2cec>
    6ec0:      	mov	x19, x0
    6ec4:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6ec8:      	mov	w8, #0x1                // =1
    6ecc:      	ldr	x0, [x0]
    6ed0:      	add	x9, sp, #0x88
    6ed4:      	add	x1, sp, #0x88
    6ed8:      	blr	x8
    6edc:      	cbz	x0, 0x8718 <generic_kprobe_filter_arg+0x2ce8>
    6ee0:      	cmp	w22, #0xff
    6ee4:      	mov	w8, #0xff               // =255
    6ee8:      	mov	x2, x24
    6eec:      	csel	w1, w22, w8, lo
    6ef0:      	mov	x8, x0
    6ef4:      	mov	x22, x0
    6ef8:      	lsl	w9, w1, #3
    6efc:      	str	w9, [x8], #0x4
    6f00:      	mov	w9, #0x4                // =4
    6f04:      	mov	x0, x8
    6f08:      	blr	x9
    6f0c:      	mov	w8, #0x1                // =1
    6f10:      	mov	x0, x19
    6f14:      	mov	x1, x22
    6f18:      	b	0x8708 <generic_kprobe_filter_arg+0x2cd8>
    6f1c:      	cmp	w22, #0x1fe
    6f20:      	str	wzr, [sp, #0x88]
    6f24:      	b.ls	0x75d4 <generic_kprobe_filter_arg+0x1ba4>
    6f28:      	mov	x23, xzr
    6f2c:      	b	0x872c <generic_kprobe_filter_arg+0x2cfc>
    6f30:      	cmp	w8, #0x1e
    6f34:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    6f38:      	ldr	w8, [x29, #0x10]
    6f3c:      	and	x8, x8, #0x7
    6f40:      	add	x9, x20, x8, lsl #2
    6f44:      	ldr	w9, [x9, x2]
    6f48:      	cbnz	w9, 0x5b2c <generic_kprobe_filter_arg+0xfc>
    6f4c:      	add	x8, x20, x8, lsl #3
    6f50:      	ldr	x9, [x22]
    6f54:      	ldr	x8, [x8, #0x5e78]
    6f58:      	and	x8, x8, #0x7ff
    6f5c:      	add	x8, x20, x8
    6f60:      	ldr	x8, [x8, #0x90]
    6f64:      	bics	xzr, x8, x9
    6f68:      	cset	w23, ne
    6f6c:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6f70:      	ldr	x19, [sp, #0x30]
    6f74:      	cmp	x24, #0x400
    6f78:      	cset	w23, lo
    6f7c:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6f80:      	ldr	x19, [sp, #0x30]
    6f84:      	cmp	x24, #0x3ff
    6f88:      	cset	w23, hi
    6f8c:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    6f90:      	and	w8, w24, #0xffff
    6f94:      	mov	w9, #0x1fe              // =510
    6f98:      	cmp	w8, #0x100
    6f9c:      	mov	w8, #0x100              // =256
    6fa0:      	csel	w11, w9, w8, hi
    6fa4:      	and	w8, w11, #0xffff
    6fa8:      	cmp	w8, #0x100
    6fac:      	mov	w8, #0x6                // =6
    6fb0:      	cinc	w10, w8, ne
    6fb4:      	add	x8, x29, #0x10
    6fb8:      	and	w9, w10, #0xf
    6fbc:      	ldr	w8, [x8, w9, uxtw #2]
    6fc0:      	cmn	w8, #0x1
    6fc4:      	b.eq	0x82e8 <generic_kprobe_filter_arg+0x28b8>
    6fc8:      	str	w11, [sp, #0x10]
    6fcc:      	stp	w8, w10, [sp, #0x1c]
    6fd0:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6fd4:      	mov	w8, #0x1                // =1
    6fd8:      	add	x23, sp, #0x88
    6fdc:      	add	x1, sp, #0x88
    6fe0:      	ldr	x0, [x0]
    6fe4:      	blr	x8
    6fe8:      	str	x0, [sp, #0x28]
    6fec:      	adrp	x0, 0x6000 <generic_kprobe_filter_arg+0x5d0>
    6ff0:      	mov	w8, #0x1                // =1
    6ff4:      	add	x1, sp, #0x88
    6ff8:      	ldr	x0, [x0]
    6ffc:      	blr	x8
    7000:      	ldr	x9, [sp, #0x28]
    7004:      	mov	x23, xzr
    7008:      	cbz	x9, 0x82ec <generic_kprobe_filter_arg+0x28bc>
    700c:      	ldp	x16, x15, [sp, #0x40]
    7010:      	mov	w2, #0x5ea0             // =24224
    7014:      	mov	w12, #0x1               // =1
    7018:      	ldr	x17, [sp, #0x38]
    701c:      	cbz	x0, 0x82fc <generic_kprobe_filter_arg+0x28cc>
    7020:      	ldr	w23, [sp, #0x20]
    7024:      	mov	x8, x9
    7028:      	str	x0, [sp, #0x8]
    702c:      	add	x2, x22, #0x4
    7030:      	mov	x22, x9
    7034:      	mov	x0, x8
    7038:      	cmp	w23, #0x5
    703c:      	b.gt	0x79fc <generic_kprobe_filter_arg+0x1fcc>
    7040:      	strb	w24, [x0], #0x1
    7044:      	mov	w8, #0x4                // =4
    7048:      	mov	w1, w24
    704c:      	blr	x8
    7050:      	ldr	w8, [sp, #0x10]
    7054:      	and	w8, w8, #0xffff
    7058:      	cmp	w8, w24
    705c:      	b.ls	0x7a38 <generic_kprobe_filter_arg+0x2008>
    7060:      	add	x9, x22, x24
    7064:      	sub	w8, w8, w24
    7068:      	ldr	x2, [sp, #0x8]
    706c:      	add	x0, x9, #0x1
    7070:      	and	w1, w8, #0xfff
    7074:      	mov	w8, #0x4                // =4
    7078:      	b	0x7a34 <generic_kprobe_filter_arg+0x2004>
    707c:      	ldr	w8, [x29, #0x14]
    7080:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7084:      	add	x9, sp, #0xac
    7088:      	add	x1, sp, #0xac
    708c:      	str	w8, [sp, #0xac]
    7090:      	mov	w8, #0x1                // =1
    7094:      	mov	w23, w13
    7098:      	mov	w22, w11
    709c:      	ldr	x0, [x0]
    70a0:      	blr	x8
    70a4:      	cbz	x0, 0x7990 <generic_kprobe_filter_arg+0x1f60>
    70a8:      	mov	w8, #0x80               // =128
    70ac:      	stp	w23, w19, [sp, #0x90]
    70b0:      	add	x1, sp, #0x88
    70b4:      	stp	w8, w22, [sp, #0x88]
    70b8:      	lsr	x8, x19, #32
    70bc:      	ldr	x19, [sp, #0x30]
    70c0:      	str	w8, [sp, #0x98]
    70c4:      	mov	w8, #0x1                // =1
    70c8:      	blr	x8
    70cc:      	ldr	w8, [x29, #0x4]
    70d0:      	sub	w9, w8, #0x18
    70d4:      	cmp	w9, #0x2
    70d8:      	b.lo	0x76b8 <generic_kprobe_filter_arg+0x1c88>
    70dc:      	sub	w8, w8, #0xd
    70e0:      	mov	w12, #0x1               // =1
    70e4:      	cmp	w8, #0x1
    70e8:      	b.hi	0x6308 <generic_kprobe_filter_arg+0x8d8>
    70ec:      	cmp	x0, #0x0
    70f0:      	cset	w8, ne
    70f4:      	ldp	x16, x15, [sp, #0x40]
    70f8:      	mov	w2, #0x5ea0             // =24224
    70fc:      	mov	w23, w8
    7100:      	ldr	x17, [sp, #0x38]
    7104:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    7108:      	ldr	x19, [sp, #0x30]
    710c:      	mov	w8, wzr
    7110:      	mov	w23, wzr
    7114:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    7118:      	ldr	x8, [x22]
    711c:      	cmp	x11, x8
    7120:      	b.hi	0x712c <generic_kprobe_filter_arg+0x16fc>
    7124:      	cmp	x8, x10
    7128:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    712c:      	ldr	w10, [x29, #0x8]
    7130:      	cmp	w10, #0x19
    7134:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    7138:      	ldp	x12, x11, [x29, #0x20]
    713c:      	cmp	w9, #0xc
    7140:      	b.eq	0x714c <generic_kprobe_filter_arg+0x171c>
    7144:      	cmp	w9, #0xa
    7148:      	b.ne	0x77a8 <generic_kprobe_filter_arg+0x1d78>
    714c:      	cmp	x12, x8
    7150:      	mov	w12, #0x1               // =1
    7154:      	b.gt	0x77bc <generic_kprobe_filter_arg+0x1d8c>
    7158:      	cmp	x8, x11
    715c:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7160:      	b	0x77bc <generic_kprobe_filter_arg+0x1d8c>
    7164:      	ldr	x10, [x22]
    7168:      	cmp	x11, x10
    716c:      	ccmp	x10, x8, #0x2, ls
    7170:      	cset	w8, ls
    7174:      	ldr	w11, [x29, #0x8]
    7178:      	cmp	w11, #0x19
    717c:      	b.lo	0x8104 <generic_kprobe_filter_arg+0x26d4>
    7180:      	ldp	x13, x12, [x29, #0x20]
    7184:      	cmp	w9, #0xc
    7188:      	b.eq	0x7194 <generic_kprobe_filter_arg+0x1764>
    718c:      	cmp	w9, #0xa
    7190:      	b.ne	0x776c <generic_kprobe_filter_arg+0x1d3c>
    7194:      	cmp	x13, x10
    7198:      	ccmp	x10, x12, #0x0, le
    719c:      	cset	w12, le
    71a0:      	b	0x7778 <generic_kprobe_filter_arg+0x1d48>
    71a4:      	ldrh	w23, [x22, #0x26]
    71a8:      	ldrb	w8, [x29, #0x10]
    71ac:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    71b0:      	add	x9, sp, #0xac
    71b4:      	add	x1, sp, #0xac
    71b8:      	str	w8, [sp, #0xac]
    71bc:      	mov	w8, #0x1                // =1
    71c0:      	ldr	x0, [x0]
    71c4:      	blr	x8
    71c8:      	cbz	x0, 0x7214 <generic_kprobe_filter_arg+0x17e4>
    71cc:      	str	x23, [sp, #0x88]
    71d0:      	mov	w8, #0x1                // =1
    71d4:      	add	x9, sp, #0x88
    71d8:      	add	x1, sp, #0x88
    71dc:      	blr	x8
    71e0:      	ldr	w9, [x29, #0x4]
    71e4:      	mov	w8, wzr
    71e8:      	mov	w12, #0x1               // =1
    71ec:      	cmp	w9, #0x1d
    71f0:      	b.hi	0x7890 <generic_kprobe_filter_arg+0x1e60>
    71f4:      	mov	w10, #0x8400            // =33792
    71f8:      	lsl	w9, w12, w9
    71fc:      	movk	w10, #0x3003, lsl #16
    7200:      	tst	w9, w10
    7204:      	b.eq	0x7878 <generic_kprobe_filter_arg+0x1e48>
    7208:      	cmp	x0, #0x0
    720c:      	cset	w8, ne
    7210:      	b	0x7890 <generic_kprobe_filter_arg+0x1e60>
    7214:      	mov	x23, xzr
    7218:      	mov	w12, #0x1               // =1
    721c:      	b	0x7894 <generic_kprobe_filter_arg+0x1e64>
    7220:      	ldr	x11, [x22]
    7224:      	cmp	x11, x10
    7228:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    722c:      	b	0x723c <generic_kprobe_filter_arg+0x180c>
    7230:      	ldr	x11, [x22]
    7234:      	cmp	x11, x10
    7238:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    723c:      	ldr	w10, [x29, #0x8]
    7240:      	cmp	w10, #0x11
    7244:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    7248:      	ldr	x11, [x29, #0x18]
    724c:      	cmp	w8, #0x2
    7250:      	b.le	0x7274 <generic_kprobe_filter_arg+0x1844>
    7254:      	sub	w12, w8, #0x3
    7258:      	cmp	w12, #0x2
    725c:      	b.hs	0x72a8 <generic_kprobe_filter_arg+0x1878>
    7260:      	ldr	x12, [x22]
    7264:      	cmp	x12, x11
    7268:      	mov	w12, #0x1               // =1
    726c:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    7270:      	b	0x7dbc <generic_kprobe_filter_arg+0x238c>
    7274:      	cmp	w8, #0x1
    7278:      	b.eq	0x7400 <generic_kprobe_filter_arg+0x19d0>
    727c:      	cmp	w8, #0x2
    7280:      	b.ne	0x7dbc <generic_kprobe_filter_arg+0x238c>
    7284:      	cmp	w9, #0xc
    7288:      	b.eq	0x7294 <generic_kprobe_filter_arg+0x1864>
    728c:      	cmp	w9, #0xa
    7290:      	b.ne	0x7dac <generic_kprobe_filter_arg+0x237c>
    7294:      	ldr	x12, [x22]
    7298:      	cmp	x12, x11
    729c:      	mov	w12, #0x1               // =1
    72a0:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    72a4:      	b	0x7dbc <generic_kprobe_filter_arg+0x238c>
    72a8:      	cmp	w8, #0xc
    72ac:      	mov	w12, #0x1               // =1
    72b0:      	b.ne	0x7dbc <generic_kprobe_filter_arg+0x238c>
    72b4:      	ldr	x12, [x22]
    72b8:      	tst	x12, x11
    72bc:      	mov	w12, #0x1               // =1
    72c0:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    72c4:      	b	0x7dbc <generic_kprobe_filter_arg+0x238c>
    72c8:      	mov	x23, xzr
    72cc:      	ldr	x19, [sp, #0x30]
    72d0:      	mov	w12, #0x1               // =1
    72d4:      	ldp	x16, x15, [sp, #0x40]
    72d8:      	mov	w2, #0x5ea0             // =24224
    72dc:      	b	0x82f8 <generic_kprobe_filter_arg+0x28c8>
    72e0:      	cmp	w8, #0xc
    72e4:      	b.ne	0x7644 <generic_kprobe_filter_arg+0x1c14>
    72e8:      	ldrb	w10, [x22]
    72ec:      	tst	w9, w10
    72f0:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    72f4:      	b	0x7644 <generic_kprobe_filter_arg+0x1c14>
    72f8:      	cmp	w8, #0xc
    72fc:      	b.ne	0x7684 <generic_kprobe_filter_arg+0x1c54>
    7300:      	ldrh	w10, [x22]
    7304:      	tst	w9, w10
    7308:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    730c:      	b	0x7684 <generic_kprobe_filter_arg+0x1c54>
    7310:      	and	w8, w24, #0xffff
    7314:      	mov	w9, #0x1fe              // =510
    7318:      	cmp	w8, #0x100
    731c:      	mov	w8, #0x100              // =256
    7320:      	csel	w11, w9, w8, hi
    7324:      	and	w8, w11, #0xffff
    7328:      	cmp	w8, #0x100
    732c:      	mov	w8, #0x6                // =6
    7330:      	cinc	w10, w8, ne
    7334:      	add	x8, x29, #0x10
    7338:      	and	w9, w10, #0xf
    733c:      	ldr	w8, [x8, w9, uxtw #2]
    7340:      	cmn	w8, #0x1
    7344:      	b.eq	0x8158 <generic_kprobe_filter_arg+0x2728>
    7348:      	str	w11, [sp, #0x10]
    734c:      	str	w8, [sp, #0x1c]
    7350:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7354:      	mov	w8, #0x1                // =1
    7358:      	add	x23, sp, #0x88
    735c:      	add	x1, sp, #0x88
    7360:      	str	w10, [sp, #0x28]
    7364:      	ldr	x0, [x0]
    7368:      	blr	x8
    736c:      	str	x0, [sp, #0x20]
    7370:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7374:      	mov	w8, #0x1                // =1
    7378:      	add	x1, sp, #0x88
    737c:      	ldr	x0, [x0]
    7380:      	blr	x8
    7384:      	ldr	x9, [sp, #0x20]
    7388:      	mov	x23, xzr
    738c:      	cbz	x9, 0x6c58 <generic_kprobe_filter_arg+0x1228>
    7390:      	ldp	x16, x15, [sp, #0x40]
    7394:      	mov	w2, #0x5ea0             // =24224
    7398:      	mov	w12, #0x1               // =1
    739c:      	ldr	x17, [sp, #0x38]
    73a0:      	cbz	x0, 0x6c68 <generic_kprobe_filter_arg+0x1238>
    73a4:      	mov	x8, x9
    73a8:      	ldr	w9, [sp, #0x28]
    73ac:      	mov	x23, x0
    73b0:      	cmp	w9, #0x5
    73b4:      	b.gt	0x7c98 <generic_kprobe_filter_arg+0x2268>
    73b8:      	mov	x0, x8
    73bc:      	mov	x9, x8
    73c0:      	mov	w8, #0x4                // =4
    73c4:      	mov	w1, w24
    73c8:      	mov	x2, x22
    73cc:      	strb	w24, [x0], #0x1
    73d0:      	mov	x22, x9
    73d4:      	blr	x8
    73d8:      	ldr	w8, [sp, #0x10]
    73dc:      	and	w8, w8, #0xffff
    73e0:      	cmp	w8, w24
    73e4:      	b.ls	0x7ce4 <generic_kprobe_filter_arg+0x22b4>
    73e8:      	add	x9, x22, x24
    73ec:      	sub	w8, w8, w24
    73f0:      	add	x0, x9, #0x1
    73f4:      	and	w1, w8, #0xfff
    73f8:      	mov	w8, #0x4                // =4
    73fc:      	b	0x7cdc <generic_kprobe_filter_arg+0x22ac>
    7400:      	cmp	w9, #0xc
    7404:      	b.eq	0x7410 <generic_kprobe_filter_arg+0x19e0>
    7408:      	cmp	w9, #0xa
    740c:      	b.ne	0x7d98 <generic_kprobe_filter_arg+0x2368>
    7410:      	ldr	x12, [x22]
    7414:      	cmp	x12, x11
    7418:      	mov	w12, #0x1               // =1
    741c:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7420:      	b	0x7dbc <generic_kprobe_filter_arg+0x238c>
    7424:      	ldr	w9, [x29, #0x8]
    7428:      	cmp	w9, #0xd
    742c:      	b.lo	0x6148 <generic_kprobe_filter_arg+0x718>
    7430:      	ldr	w10, [x29, #0x14]
    7434:      	cbz	w10, 0x6148 <generic_kprobe_filter_arg+0x718>
    7438:      	cmp	w10, w8
    743c:      	b.eq	0x5ea4 <generic_kprobe_filter_arg+0x474>
    7440:      	cmp	w9, #0x11
    7444:      	b.lo	0x6148 <generic_kprobe_filter_arg+0x718>
    7448:      	ldr	w10, [x29, #0x18]
    744c:      	cbz	w10, 0x6148 <generic_kprobe_filter_arg+0x718>
    7450:      	cmp	w10, w8
    7454:      	b.eq	0x5ea4 <generic_kprobe_filter_arg+0x474>
    7458:      	cmp	w9, #0x15
    745c:      	b.lo	0x7474 <generic_kprobe_filter_arg+0x1a44>
    7460:      	ldr	w9, [x29, #0x1c]
    7464:      	cbz	w9, 0x7474 <generic_kprobe_filter_arg+0x1a44>
    7468:      	cmp	w9, w8
    746c:      	cset	w23, eq
    7470:      	b	0x7478 <generic_kprobe_filter_arg+0x1a48>
    7474:      	mov	x23, xzr
    7478:      	ldr	x19, [sp, #0x30]
    747c:      	b	0x82ec <generic_kprobe_filter_arg+0x28bc>
    7480:      	ldp	w8, w11, [x29, #0x10]
    7484:      	ldrb	w9, [x22]
    7488:      	cmp	w8, w9
    748c:      	ldr	w10, [x29, #0x8]
    7490:      	ccmp	w11, w9, #0x0, ls
    7494:      	cset	w8, hs
    7498:      	cmp	w10, #0x11
    749c:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    74a0:      	b	0x74c4 <generic_kprobe_filter_arg+0x1a94>
    74a4:      	ldp	w8, w11, [x29, #0x10]
    74a8:      	ldrh	w9, [x22]
    74ac:      	cmp	w8, w9
    74b0:      	ldr	w10, [x29, #0x8]
    74b4:      	ccmp	w11, w9, #0x0, ls
    74b8:      	cset	w8, hs
    74bc:      	cmp	w10, #0x11
    74c0:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    74c4:      	ldp	w11, w12, [x29, #0x18]
    74c8:      	cmp	w11, w9
    74cc:      	ccmp	w12, w9, #0x0, ls
    74d0:      	mov	w12, #0x1               // =1
    74d4:      	csinc	w8, w8, wzr, lo
    74d8:      	cmp	w10, #0x19
    74dc:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    74e0:      	ldp	w11, w12, [x29, #0x20]
    74e4:      	cmp	w11, w9
    74e8:      	ccmp	w12, w9, #0x0, ls
    74ec:      	mov	w12, #0x1               // =1
    74f0:      	csinc	w8, w8, wzr, lo
    74f4:      	cmp	w10, #0x21
    74f8:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    74fc:      	ldp	w10, w11, [x29, #0x28]
    7500:      	cmp	w10, w9
    7504:      	ccmp	w11, w9, #0x0, ls
    7508:      	csinc	w8, w8, wzr, lo
    750c:      	b	0x833c <generic_kprobe_filter_arg+0x290c>
    7510:      	mov	x19, xzr
    7514:      	mov	w23, wzr
    7518:      	add	x8, x29, #0x10
    751c:      	str	x8, [sp, #0x28]
    7520:      	ldr	x8, [sp, #0x28]
    7524:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7528:      	add	x9, sp, #0x60
    752c:      	add	x1, sp, #0x60
    7530:      	ldr	w8, [x8, x19, lsl #2]
    7534:      	str	w8, [sp, #0x60]
    7538:      	mov	w8, #0x1                // =1
    753c:      	ldr	x0, [x0]
    7540:      	blr	x8
    7544:      	cbz	x0, 0x8718 <generic_kprobe_filter_arg+0x2ce8>
    7548:      	cbz	w22, 0x75b0 <generic_kprobe_filter_arg+0x1b80>
    754c:      	mov	x8, xzr
    7550:      	mov	x9, x24
    7554:      	mov	x10, x22
    7558:      	b	0x7570 <generic_kprobe_filter_arg+0x1b40>
    755c:      	add	x8, x8, #0x1
    7560:      	sub	x10, x10, #0x1
    7564:      	add	x9, x9, #0x1
    7568:      	cmp	x8, x22
    756c:      	b.eq	0x75b0 <generic_kprobe_filter_arg+0x1b80>
    7570:      	mov	x11, xzr
    7574:      	nop
    7578:      	nop
    757c:      	nop
    7580:      	cmp	x10, x11
    7584:      	b.eq	0x755c <generic_kprobe_filter_arg+0x1b2c>
    7588:      	ldrb	w12, [x0, x11]
    758c:      	cbz	w12, 0x75ac <generic_kprobe_filter_arg+0x1b7c>
    7590:      	cmp	x11, #0x62
    7594:      	b.hi	0x755c <generic_kprobe_filter_arg+0x1b2c>
    7598:      	ldrb	w13, [x9, x11]
    759c:      	add	x11, x11, #0x1
    75a0:      	cmp	w13, w12
    75a4:      	b.eq	0x7580 <generic_kprobe_filter_arg+0x1b50>
    75a8:      	b	0x755c <generic_kprobe_filter_arg+0x1b2c>
    75ac:      	tbz	w8, #0x1f, 0x81cc <generic_kprobe_filter_arg+0x279c>
    75b0:      	ldr	w9, [x29, #0x8]
    75b4:      	add	w8, w23, #0xc
    75b8:      	cmp	w8, w9
    75bc:      	b.hs	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    75c0:      	add	x19, x19, #0x1
    75c4:      	add	w23, w23, #0x4
    75c8:      	cmp	x19, #0x64
    75cc:      	b.ne	0x7520 <generic_kprobe_filter_arg+0x1af0>
    75d0:      	b	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    75d4:      	and	w8, w22, #0xffff
    75d8:      	cmp	w8, #0x90
    75dc:      	b.hi	0x7abc <generic_kprobe_filter_arg+0x208c>
    75e0:      	and	w8, w22, #0xff
    75e4:      	mov	w9, #0xab               // =171
    75e8:      	tst	w22, #0xffff
    75ec:      	mul	w8, w8, w9
    75f0:      	mov	w9, #0x18               // =24
    75f4:      	lsr	w8, w8, #12
    75f8:      	msub	w8, w8, w9, w22
    75fc:      	b.eq	0x760c <generic_kprobe_filter_arg+0x1bdc>
    7600:      	tst	w8, #0xff
    7604:      	mov	w11, w22
    7608:      	b.eq	0x7620 <generic_kprobe_filter_arg+0x1bf0>
    760c:      	sub	w8, w22, w8, uxtb
    7610:      	and	w9, w8, #0xffff
    7614:      	add	w11, w8, #0x18
    7618:      	cmp	w9, #0x78
    761c:      	b.hi	0x7ad0 <generic_kprobe_filter_arg+0x20a0>
    7620:      	and	w8, w11, #0xff
    7624:      	mov	w9, #0xab               // =171
    7628:      	mul	w8, w8, w9
    762c:      	lsr	w8, w8, #12
    7630:      	sub	w10, w8, #0x1
    7634:      	b	0x7ae0 <generic_kprobe_filter_arg+0x20b0>
    7638:      	ldrb	w10, [x22]
    763c:      	cmp	w9, w10
    7640:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7644:      	ldr	w9, [x29, #0x8]
    7648:      	cmp	w9, #0xd
    764c:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    7650:      	ldr	w10, [x29, #0x14]
    7654:      	cmp	w8, #0x2
    7658:      	b.le	0x79bc <generic_kprobe_filter_arg+0x1f8c>
    765c:      	sub	w11, w8, #0x3
    7660:      	cmp	w11, #0x2
    7664:      	b.hs	0x7e44 <generic_kprobe_filter_arg+0x2414>
    7668:      	ldrb	w11, [x22]
    766c:      	cmp	w10, w11
    7670:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    7674:      	b	0x7f08 <generic_kprobe_filter_arg+0x24d8>
    7678:      	ldrh	w10, [x22]
    767c:      	cmp	w9, w10
    7680:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7684:      	ldr	w9, [x29, #0x8]
    7688:      	cmp	w9, #0xd
    768c:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    7690:      	ldr	w10, [x29, #0x14]
    7694:      	cmp	w8, #0x2
    7698:      	b.le	0x79dc <generic_kprobe_filter_arg+0x1fac>
    769c:      	sub	w11, w8, #0x3
    76a0:      	cmp	w11, #0x2
    76a4:      	b.hs	0x7e5c <generic_kprobe_filter_arg+0x242c>
    76a8:      	ldrh	w11, [x22]
    76ac:      	cmp	w10, w11
    76b0:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    76b4:      	b	0x7f44 <generic_kprobe_filter_arg+0x2514>
    76b8:      	cmp	x0, #0x0
    76bc:      	b	0x79a0 <generic_kprobe_filter_arg+0x1f70>
    76c0:      	ldr	w8, [x22]
    76c4:      	cmp	w11, w8
    76c8:      	b.hi	0x76d4 <generic_kprobe_filter_arg+0x1ca4>
    76cc:      	cmp	w8, w10
    76d0:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    76d4:      	ldr	w10, [x29, #0x8]
    76d8:      	cmp	w10, #0x11
    76dc:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    76e0:      	ldp	w12, w11, [x29, #0x18]
    76e4:      	mov	w13, #0x1               // =1
    76e8:      	cmp	w9, #0xc
    76ec:      	b.hi	0x7bec <generic_kprobe_filter_arg+0x21bc>
    76f0:      	lsl	w13, w13, w9
    76f4:      	mov	w14, #0x1402            // =5122
    76f8:      	tst	w13, w14
    76fc:      	b.eq	0x7bec <generic_kprobe_filter_arg+0x21bc>
    7700:      	cmp	w12, w8
    7704:      	mov	w12, #0x1               // =1
    7708:      	b.gt	0x7c00 <generic_kprobe_filter_arg+0x21d0>
    770c:      	cmp	w8, w11
    7710:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7714:      	b	0x7c00 <generic_kprobe_filter_arg+0x21d0>
    7718:      	ldr	w10, [x22]
    771c:      	cmp	w11, w10
    7720:      	ccmp	w10, w8, #0x2, ls
    7724:      	cset	w8, ls
    7728:      	ldr	w11, [x29, #0x8]
    772c:      	cmp	w11, #0x11
    7730:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    7734:      	ldp	w13, w12, [x29, #0x18]
    7738:      	mov	w14, #0x1               // =1
    773c:      	cmp	w9, #0xc
    7740:      	b.hi	0x7ba0 <generic_kprobe_filter_arg+0x2170>
    7744:      	lsl	w14, w14, w9
    7748:      	mov	w1, #0x1402             // =5122
    774c:      	tst	w14, w1
    7750:      	b.eq	0x7ba0 <generic_kprobe_filter_arg+0x2170>
    7754:      	cmp	w13, w10
    7758:      	ccmp	w10, w12, #0x0, le
    775c:      	cset	w12, le
    7760:      	b	0x7bac <generic_kprobe_filter_arg+0x217c>
    7764:      	mov	w23, #0x1               // =1
    7768:      	b	0x6c54 <generic_kprobe_filter_arg+0x1224>
    776c:      	cmp	x13, x10
    7770:      	ccmp	x10, x12, #0x2, ls
    7774:      	cset	w12, ls
    7778:      	orr	w8, w8, w12
    777c:      	cmp	w11, #0x29
    7780:      	b.lo	0x8104 <generic_kprobe_filter_arg+0x26d4>
    7784:      	ldp	x13, x12, [x29, #0x30]
    7788:      	cmp	w9, #0xc
    778c:      	b.eq	0x7798 <generic_kprobe_filter_arg+0x1d68>
    7790:      	cmp	w9, #0xa
    7794:      	b.ne	0x7c40 <generic_kprobe_filter_arg+0x2210>
    7798:      	cmp	x13, x10
    779c:      	ccmp	x10, x12, #0x0, le
    77a0:      	cset	w12, le
    77a4:      	b	0x7c4c <generic_kprobe_filter_arg+0x221c>
    77a8:      	cmp	x12, x8
    77ac:      	mov	w12, #0x1               // =1
    77b0:      	b.hi	0x77bc <generic_kprobe_filter_arg+0x1d8c>
    77b4:      	cmp	x8, x11
    77b8:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    77bc:      	cmp	w10, #0x29
    77c0:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    77c4:      	ldp	x12, x11, [x29, #0x30]
    77c8:      	cmp	w9, #0xc
    77cc:      	b.eq	0x77d8 <generic_kprobe_filter_arg+0x1da8>
    77d0:      	cmp	w9, #0xa
    77d4:      	b.ne	0x7d54 <generic_kprobe_filter_arg+0x2324>
    77d8:      	cmp	x12, x8
    77dc:      	mov	w12, #0x1               // =1
    77e0:      	b.gt	0x7d68 <generic_kprobe_filter_arg+0x2338>
    77e4:      	cmp	x8, x11
    77e8:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    77ec:      	b	0x7d68 <generic_kprobe_filter_arg+0x2338>
    77f0:      	mov	x19, xzr
    77f4:      	cmp	w9, #0x29
    77f8:      	b.ne	0x7804 <generic_kprobe_filter_arg+0x1dd4>
    77fc:      	cbz	x10, 0x7804 <generic_kprobe_filter_arg+0x1dd4>
    7800:      	ldrb	w19, [x10, #0x3a]
    7804:      	cmp	w9, #0x29
    7808:      	b.eq	0x7814 <generic_kprobe_filter_arg+0x1de4>
    780c:      	cmp	w9, #0x7
    7810:      	b.ne	0x7c8c <generic_kprobe_filter_arg+0x225c>
    7814:      	ldrb	w8, [x29, #0x10]
    7818:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    781c:      	add	x9, sp, #0xac
    7820:      	add	x1, sp, #0xac
    7824:      	str	w8, [sp, #0xac]
    7828:      	mov	w8, #0x1                // =1
    782c:      	ldr	x0, [x0]
    7830:      	blr	x8
    7834:      	cbz	x0, 0x7c7c <generic_kprobe_filter_arg+0x224c>
    7838:      	str	x19, [sp, #0x88]
    783c:      	mov	w8, #0x1                // =1
    7840:      	add	x9, sp, #0x88
    7844:      	add	x1, sp, #0x88
    7848:      	blr	x8
    784c:      	ldr	w9, [x29, #0x4]
    7850:      	mov	w8, wzr
    7854:      	cmp	w9, #0x1d
    7858:      	b.hi	0x8764 <generic_kprobe_filter_arg+0x2d34>
    785c:      	ldr	x19, [sp, #0x30]
    7860:      	mov	w12, #0x1               // =1
    7864:      	mov	w10, #0x8400            // =33792
    7868:      	lsl	w9, w12, w9
    786c:      	movk	w10, #0x3003, lsl #16
    7870:      	tst	w9, w10
    7874:      	b.ne	0x7208 <generic_kprobe_filter_arg+0x17d8>
    7878:      	mov	w10, #0x800             // =2048
    787c:      	movk	w10, #0xc, lsl #16
    7880:      	tst	w9, w10
    7884:      	b.eq	0x7890 <generic_kprobe_filter_arg+0x1e60>
    7888:      	cmp	x0, #0x0
    788c:      	cset	w8, eq
    7890:      	mov	w23, w8
    7894:      	ldp	x16, x15, [sp, #0x40]
    7898:      	mov	w2, #0x5ea0             // =24224
    789c:      	ldr	x17, [sp, #0x38]
    78a0:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    78a4:      	ldr	w11, [x22]
    78a8:      	cmp	w11, w10
    78ac:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    78b0:      	b	0x78c0 <generic_kprobe_filter_arg+0x1e90>
    78b4:      	ldr	w11, [x22]
    78b8:      	cmp	w11, w10
    78bc:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    78c0:      	ldr	w10, [x29, #0x8]
    78c4:      	cmp	w10, #0xd
    78c8:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    78cc:      	ldr	w11, [x29, #0x14]
    78d0:      	cmp	w8, #0x2
    78d4:      	b.le	0x78f8 <generic_kprobe_filter_arg+0x1ec8>
    78d8:      	sub	w12, w8, #0x3
    78dc:      	cmp	w12, #0x2
    78e0:      	b.hs	0x7938 <generic_kprobe_filter_arg+0x1f08>
    78e4:      	ldr	w12, [x22]
    78e8:      	cmp	w12, w11
    78ec:      	mov	w12, #0x1               // =1
    78f0:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    78f4:      	b	0x8030 <generic_kprobe_filter_arg+0x2600>
    78f8:      	cmp	w8, #0x1
    78fc:      	b.eq	0x7958 <generic_kprobe_filter_arg+0x1f28>
    7900:      	cmp	w8, #0x2
    7904:      	b.ne	0x8030 <generic_kprobe_filter_arg+0x2600>
    7908:      	mov	w12, #0x1               // =1
    790c:      	cmp	w9, #0xc
    7910:      	b.hi	0x8020 <generic_kprobe_filter_arg+0x25f0>
    7914:      	lsl	w12, w12, w9
    7918:      	mov	w13, #0x1402            // =5122
    791c:      	tst	w12, w13
    7920:      	b.eq	0x8020 <generic_kprobe_filter_arg+0x25f0>
    7924:      	ldr	w12, [x22]
    7928:      	cmp	w12, w11
    792c:      	mov	w12, #0x1               // =1
    7930:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7934:      	b	0x8030 <generic_kprobe_filter_arg+0x2600>
    7938:      	cmp	w8, #0xc
    793c:      	mov	w12, #0x1               // =1
    7940:      	b.ne	0x8030 <generic_kprobe_filter_arg+0x2600>
    7944:      	ldr	w12, [x22]
    7948:      	tst	w12, w11
    794c:      	mov	w12, #0x1               // =1
    7950:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7954:      	b	0x8030 <generic_kprobe_filter_arg+0x2600>
    7958:      	mov	w12, #0x1               // =1
    795c:      	cmp	w9, #0xc
    7960:      	b.hi	0x800c <generic_kprobe_filter_arg+0x25dc>
    7964:      	lsl	w12, w12, w9
    7968:      	mov	w13, #0x1402            // =5122
    796c:      	tst	w12, w13
    7970:      	b.eq	0x800c <generic_kprobe_filter_arg+0x25dc>
    7974:      	ldr	w12, [x22]
    7978:      	cmp	w12, w11
    797c:      	mov	w12, #0x1               // =1
    7980:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7984:      	b	0x8030 <generic_kprobe_filter_arg+0x2600>
    7988:      	ldr	w8, [x29, #0x4]
    798c:      	b	0x7998 <generic_kprobe_filter_arg+0x1f68>
    7990:      	ldr	w8, [x29, #0x4]
    7994:      	ldr	x19, [sp, #0x30]
    7998:      	and	w8, w8, #0xfffffffe
    799c:      	cmp	w8, #0x18
    79a0:      	cset	w8, eq
    79a4:      	ldp	x16, x15, [sp, #0x40]
    79a8:      	mov	w2, #0x5ea0             // =24224
    79ac:      	mov	w12, #0x1               // =1
    79b0:      	mov	w23, w8
    79b4:      	ldr	x17, [sp, #0x38]
    79b8:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    79bc:      	cmp	w8, #0x1
    79c0:      	b.eq	0x7efc <generic_kprobe_filter_arg+0x24cc>
    79c4:      	cmp	w8, #0x2
    79c8:      	b.ne	0x7f08 <generic_kprobe_filter_arg+0x24d8>
    79cc:      	ldrb	w11, [x22]
    79d0:      	cmp	w10, w11
    79d4:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    79d8:      	b	0x7f08 <generic_kprobe_filter_arg+0x24d8>
    79dc:      	cmp	w8, #0x1
    79e0:      	b.eq	0x7f38 <generic_kprobe_filter_arg+0x2508>
    79e4:      	cmp	w8, #0x2
    79e8:      	b.ne	0x7f44 <generic_kprobe_filter_arg+0x2514>
    79ec:      	ldrh	w11, [x22]
    79f0:      	cmp	w10, w11
    79f4:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    79f8:      	b	0x7f44 <generic_kprobe_filter_arg+0x2514>
    79fc:      	strh	w24, [x0], #0x2
    7a00:      	mov	w8, #0x4                // =4
    7a04:      	mov	w1, w24
    7a08:      	blr	x8
    7a0c:      	ldr	w8, [sp, #0x10]
    7a10:      	and	w8, w8, #0xffff
    7a14:      	cmp	w8, w24
    7a18:      	b.ls	0x7a38 <generic_kprobe_filter_arg+0x2008>
    7a1c:      	add	x9, x22, x24
    7a20:      	sub	w8, w8, w24
    7a24:      	ldr	x2, [sp, #0x8]
    7a28:      	add	x0, x9, #0x2
    7a2c:      	and	w1, w8, #0xfff
    7a30:      	mov	w8, #0x4                // =4
    7a34:      	blr	x8
    7a38:      	ldr	w8, [sp, #0x1c]
    7a3c:      	cmp	w23, #0x3
    7a40:      	str	w8, [sp, #0x60]
    7a44:      	b.gt	0x7a80 <generic_kprobe_filter_arg+0x2050>
    7a48:      	ldp	x16, x15, [sp, #0x40]
    7a4c:      	cmp	w23, #0x1
    7a50:      	mov	w2, #0x5ea0             // =24224
    7a54:      	mov	w12, #0x1               // =1
    7a58:      	ldr	x17, [sp, #0x38]
    7a5c:      	b.gt	0x7e98 <generic_kprobe_filter_arg+0x2468>
    7a60:      	cbz	w23, 0x8278 <generic_kprobe_filter_arg+0x2848>
    7a64:      	cmp	w23, #0x1
    7a68:      	b.ne	0x6148 <generic_kprobe_filter_arg+0x718>
    7a6c:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7a70:      	mov	w8, #0x1                // =1
    7a74:      	add	x9, sp, #0x60
    7a78:      	ldr	x0, [x0]
    7a7c:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    7a80:      	ldp	x16, x15, [sp, #0x40]
    7a84:      	cmp	w23, #0x5
    7a88:      	mov	w2, #0x5ea0             // =24224
    7a8c:      	mov	w12, #0x1               // =1
    7a90:      	ldr	x17, [sp, #0x38]
    7a94:      	b.gt	0x7ebc <generic_kprobe_filter_arg+0x248c>
    7a98:      	cmp	w23, #0x4
    7a9c:      	b.eq	0x828c <generic_kprobe_filter_arg+0x285c>
    7aa0:      	cmp	w23, #0x5
    7aa4:      	b.ne	0x6148 <generic_kprobe_filter_arg+0x718>
    7aa8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7aac:      	mov	w8, #0x1                // =1
    7ab0:      	add	x9, sp, #0x60
    7ab4:      	ldr	x0, [x0]
    7ab8:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    7abc:      	and	w8, w22, #0xffff
    7ac0:      	mov	w9, #0x1fe              // =510
    7ac4:      	cmp	w8, #0x100
    7ac8:      	mov	w8, #0x100              // =256
    7acc:      	csel	w11, w9, w8, hi
    7ad0:      	and	w8, w11, #0xffff
    7ad4:      	cmp	w8, #0x100
    7ad8:      	mov	w8, #0x6                // =6
    7adc:      	cinc	w10, w8, ne
    7ae0:      	add	x8, x29, #0x10
    7ae4:      	and	w9, w10, #0xf
    7ae8:      	ldr	w8, [x8, w9, uxtw #2]
    7aec:      	cmn	w8, #0x1
    7af0:      	b.eq	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    7af4:      	stp	w11, w8, [sp, #0x1c]
    7af8:      	str	w10, [sp, #0x28]
    7afc:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7b00:      	mov	w8, #0x1                // =1
    7b04:      	add	x19, sp, #0x88
    7b08:      	add	x1, sp, #0x88
    7b0c:      	ldr	x0, [x0]
    7b10:      	blr	x8
    7b14:      	mov	x9, x0
    7b18:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7b1c:      	mov	w8, #0x1                // =1
    7b20:      	ldr	x0, [x0]
    7b24:      	add	x1, sp, #0x88
    7b28:      	mov	x19, x9
    7b2c:      	blr	x8
    7b30:      	mov	x23, xzr
    7b34:      	cbz	x19, 0x871c <generic_kprobe_filter_arg+0x2cec>
    7b38:      	ldp	x16, x15, [sp, #0x40]
    7b3c:      	mov	w2, #0x5ea0             // =24224
    7b40:      	mov	w12, #0x1               // =1
    7b44:      	ldr	x17, [sp, #0x38]
    7b48:      	cbz	x0, 0x872c <generic_kprobe_filter_arg+0x2cfc>
    7b4c:      	ldr	w23, [sp, #0x28]
    7b50:      	str	x0, [sp, #0x10]
    7b54:      	mov	x0, x19
    7b58:      	cmp	w23, #0x5
    7b5c:      	b.gt	0x81d4 <generic_kprobe_filter_arg+0x27a4>
    7b60:      	strb	w22, [x0], #0x1
    7b64:      	mov	w8, #0x4                // =4
    7b68:      	mov	w1, w22
    7b6c:      	mov	x2, x24
    7b70:      	blr	x8
    7b74:      	ldr	w8, [sp, #0x1c]
    7b78:      	and	w8, w8, #0xffff
    7b7c:      	cmp	w8, w22
    7b80:      	b.ls	0x8214 <generic_kprobe_filter_arg+0x27e4>
    7b84:      	add	x9, x19, x22
    7b88:      	sub	w8, w8, w22
    7b8c:      	ldr	x2, [sp, #0x10]
    7b90:      	add	x0, x9, #0x1
    7b94:      	and	w1, w8, #0xfff
    7b98:      	mov	w8, #0x4                // =4
    7b9c:      	b	0x8210 <generic_kprobe_filter_arg+0x27e0>
    7ba0:      	cmp	w13, w10
    7ba4:      	ccmp	w10, w12, #0x2, ls
    7ba8:      	cset	w12, ls
    7bac:      	orr	w8, w8, w12
    7bb0:      	cmp	w11, #0x19
    7bb4:      	mov	w12, #0x1               // =1
    7bb8:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    7bbc:      	ldp	w13, w12, [x29, #0x20]
    7bc0:      	mov	w14, #0x1               // =1
    7bc4:      	cmp	w9, #0xc
    7bc8:      	b.hi	0x7f74 <generic_kprobe_filter_arg+0x2544>
    7bcc:      	lsl	w14, w14, w9
    7bd0:      	mov	w1, #0x1402             // =5122
    7bd4:      	tst	w14, w1
    7bd8:      	b.eq	0x7f74 <generic_kprobe_filter_arg+0x2544>
    7bdc:      	cmp	w13, w10
    7be0:      	ccmp	w10, w12, #0x0, le
    7be4:      	cset	w12, le
    7be8:      	b	0x7f80 <generic_kprobe_filter_arg+0x2550>
    7bec:      	cmp	w12, w8
    7bf0:      	mov	w12, #0x1               // =1
    7bf4:      	b.hi	0x7c00 <generic_kprobe_filter_arg+0x21d0>
    7bf8:      	cmp	w8, w11
    7bfc:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7c00:      	cmp	w10, #0x19
    7c04:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    7c08:      	ldp	w12, w11, [x29, #0x20]
    7c0c:      	mov	w13, #0x1               // =1
    7c10:      	cmp	w9, #0xc
    7c14:      	b.hi	0x7fc0 <generic_kprobe_filter_arg+0x2590>
    7c18:      	lsl	w13, w13, w9
    7c1c:      	mov	w14, #0x1402            // =5122
    7c20:      	tst	w13, w14
    7c24:      	b.eq	0x7fc0 <generic_kprobe_filter_arg+0x2590>
    7c28:      	cmp	w12, w8
    7c2c:      	mov	w12, #0x1               // =1
    7c30:      	b.gt	0x7fd4 <generic_kprobe_filter_arg+0x25a4>
    7c34:      	cmp	w8, w11
    7c38:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7c3c:      	b	0x7fd4 <generic_kprobe_filter_arg+0x25a4>
    7c40:      	cmp	x13, x10
    7c44:      	ccmp	x10, x12, #0x2, ls
    7c48:      	cset	w12, ls
    7c4c:      	orr	w8, w8, w12
    7c50:      	cmp	w11, #0x39
    7c54:      	b.lo	0x8104 <generic_kprobe_filter_arg+0x26d4>
    7c58:      	ldp	x12, x11, [x29, #0x40]
    7c5c:      	cmp	w9, #0xc
    7c60:      	b.eq	0x7c6c <generic_kprobe_filter_arg+0x223c>
    7c64:      	cmp	w9, #0xa
    7c68:      	b.ne	0x80f4 <generic_kprobe_filter_arg+0x26c4>
    7c6c:      	cmp	x12, x10
    7c70:      	ccmp	x10, x11, #0x0, le
    7c74:      	cset	w9, le
    7c78:      	b	0x8100 <generic_kprobe_filter_arg+0x26d0>
    7c7c:      	ldr	x19, [sp, #0x30]
    7c80:      	mov	x23, xzr
    7c84:      	mov	w12, #0x1               // =1
    7c88:      	b	0x7894 <generic_kprobe_filter_arg+0x1e64>
    7c8c:      	ldr	x19, [sp, #0x30]
    7c90:      	mov	x23, xzr
    7c94:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    7c98:      	mov	x0, x8
    7c9c:      	mov	x9, x8
    7ca0:      	mov	w8, #0x4                // =4
    7ca4:      	mov	w1, w24
    7ca8:      	mov	x2, x22
    7cac:      	strh	w24, [x0], #0x2
    7cb0:      	mov	x22, x9
    7cb4:      	blr	x8
    7cb8:      	ldr	w8, [sp, #0x10]
    7cbc:      	and	w8, w8, #0xffff
    7cc0:      	cmp	w8, w24
    7cc4:      	b.ls	0x7ce4 <generic_kprobe_filter_arg+0x22b4>
    7cc8:      	add	x9, x22, x24
    7ccc:      	sub	w8, w8, w24
    7cd0:      	add	x0, x9, #0x2
    7cd4:      	and	w1, w8, #0xfff
    7cd8:      	mov	w8, #0x4                // =4
    7cdc:      	mov	x2, x23
    7ce0:      	blr	x8
    7ce4:      	ldr	w8, [sp, #0x1c]
    7ce8:      	str	w8, [sp, #0x60]
    7cec:      	ldr	w8, [sp, #0x28]
    7cf0:      	cmp	w8, #0x3
    7cf4:      	b.gt	0x7d24 <generic_kprobe_filter_arg+0x22f4>
    7cf8:      	cmp	w8, #0x1
    7cfc:      	mov	w12, #0x1               // =1
    7d00:      	b.gt	0x8110 <generic_kprobe_filter_arg+0x26e0>
    7d04:      	cbz	w8, 0x844c <generic_kprobe_filter_arg+0x2a1c>
    7d08:      	cmp	w8, #0x1
    7d0c:      	b.ne	0x8158 <generic_kprobe_filter_arg+0x2728>
    7d10:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7d14:      	mov	w8, #0x1                // =1
    7d18:      	add	x9, sp, #0x60
    7d1c:      	ldr	x0, [x0]
    7d20:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    7d24:      	cmp	w8, #0x5
    7d28:      	mov	w12, #0x1               // =1
    7d2c:      	b.gt	0x8134 <generic_kprobe_filter_arg+0x2704>
    7d30:      	cmp	w8, #0x4
    7d34:      	b.eq	0x8460 <generic_kprobe_filter_arg+0x2a30>
    7d38:      	cmp	w8, #0x5
    7d3c:      	b.ne	0x8158 <generic_kprobe_filter_arg+0x2728>
    7d40:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7d44:      	mov	w8, #0x1                // =1
    7d48:      	add	x9, sp, #0x60
    7d4c:      	ldr	x0, [x0]
    7d50:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    7d54:      	cmp	x12, x8
    7d58:      	mov	w12, #0x1               // =1
    7d5c:      	b.hi	0x7d68 <generic_kprobe_filter_arg+0x2338>
    7d60:      	cmp	x8, x11
    7d64:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7d68:      	cmp	w10, #0x39
    7d6c:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    7d70:      	ldp	x11, x10, [x29, #0x40]
    7d74:      	cmp	w9, #0xc
    7d78:      	b.eq	0x7d84 <generic_kprobe_filter_arg+0x2354>
    7d7c:      	cmp	w9, #0xa
    7d80:      	b.ne	0x8178 <generic_kprobe_filter_arg+0x2748>
    7d84:      	cmp	x11, x8
    7d88:      	b.gt	0x5b2c <generic_kprobe_filter_arg+0xfc>
    7d8c:      	cmp	x8, x10
    7d90:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7d94:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    7d98:      	ldr	x12, [x22]
    7d9c:      	cmp	x12, x11
    7da0:      	mov	w12, #0x1               // =1
    7da4:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7da8:      	b	0x7dbc <generic_kprobe_filter_arg+0x238c>
    7dac:      	ldr	x12, [x22]
    7db0:      	cmp	x12, x11
    7db4:      	mov	w12, #0x1               // =1
    7db8:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7dbc:      	cmp	w10, #0x19
    7dc0:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    7dc4:      	ldr	x11, [x29, #0x20]
    7dc8:      	cmp	w8, #0x2
    7dcc:      	b.le	0x7df0 <generic_kprobe_filter_arg+0x23c0>
    7dd0:      	sub	w12, w8, #0x3
    7dd4:      	cmp	w12, #0x2
    7dd8:      	b.hs	0x7e24 <generic_kprobe_filter_arg+0x23f4>
    7ddc:      	ldr	x12, [x22]
    7de0:      	cmp	x12, x11
    7de4:      	mov	w12, #0x1               // =1
    7de8:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    7dec:      	b	0x8368 <generic_kprobe_filter_arg+0x2938>
    7df0:      	cmp	w8, #0x1
    7df4:      	b.eq	0x7e74 <generic_kprobe_filter_arg+0x2444>
    7df8:      	cmp	w8, #0x2
    7dfc:      	b.ne	0x8368 <generic_kprobe_filter_arg+0x2938>
    7e00:      	cmp	w9, #0xc
    7e04:      	b.eq	0x7e10 <generic_kprobe_filter_arg+0x23e0>
    7e08:      	cmp	w9, #0xa
    7e0c:      	b.ne	0x8358 <generic_kprobe_filter_arg+0x2928>
    7e10:      	ldr	x12, [x22]
    7e14:      	cmp	x12, x11
    7e18:      	mov	w12, #0x1               // =1
    7e1c:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7e20:      	b	0x8368 <generic_kprobe_filter_arg+0x2938>
    7e24:      	cmp	w8, #0xc
    7e28:      	mov	w12, #0x1               // =1
    7e2c:      	b.ne	0x8368 <generic_kprobe_filter_arg+0x2938>
    7e30:      	ldr	x12, [x22]
    7e34:      	tst	x12, x11
    7e38:      	mov	w12, #0x1               // =1
    7e3c:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7e40:      	b	0x8368 <generic_kprobe_filter_arg+0x2938>
    7e44:      	cmp	w8, #0xc
    7e48:      	b.ne	0x7f08 <generic_kprobe_filter_arg+0x24d8>
    7e4c:      	ldrb	w11, [x22]
    7e50:      	tst	w10, w11
    7e54:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7e58:      	b	0x7f08 <generic_kprobe_filter_arg+0x24d8>
    7e5c:      	cmp	w8, #0xc
    7e60:      	b.ne	0x7f44 <generic_kprobe_filter_arg+0x2514>
    7e64:      	ldrh	w11, [x22]
    7e68:      	tst	w10, w11
    7e6c:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7e70:      	b	0x7f44 <generic_kprobe_filter_arg+0x2514>
    7e74:      	cmp	w9, #0xc
    7e78:      	b.eq	0x7e84 <generic_kprobe_filter_arg+0x2454>
    7e7c:      	cmp	w9, #0xa
    7e80:      	b.ne	0x8344 <generic_kprobe_filter_arg+0x2914>
    7e84:      	ldr	x12, [x22]
    7e88:      	cmp	x12, x11
    7e8c:      	mov	w12, #0x1               // =1
    7e90:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7e94:      	b	0x8368 <generic_kprobe_filter_arg+0x2938>
    7e98:      	cmp	w23, #0x2
    7e9c:      	b.eq	0x82a0 <generic_kprobe_filter_arg+0x2870>
    7ea0:      	cmp	w23, #0x3
    7ea4:      	b.ne	0x6148 <generic_kprobe_filter_arg+0x718>
    7ea8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7eac:      	mov	w8, #0x1                // =1
    7eb0:      	add	x9, sp, #0x60
    7eb4:      	ldr	x0, [x0]
    7eb8:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    7ebc:      	cmp	w23, #0x6
    7ec0:      	b.eq	0x82b4 <generic_kprobe_filter_arg+0x2884>
    7ec4:      	cmp	w23, #0x7
    7ec8:      	b.ne	0x6148 <generic_kprobe_filter_arg+0x718>
    7ecc:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0x15d0>
    7ed0:      	mov	w8, #0x1                // =1
    7ed4:      	add	x9, sp, #0x60
    7ed8:      	ldr	x0, [x0]
    7edc:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    7ee0:      	mov	x23, xzr
    7ee4:      	b	0x7eec <generic_kprobe_filter_arg+0x24bc>
    7ee8:      	mov	w23, #0x1               // =1
    7eec:      	mov	w12, #0x1               // =1
    7ef0:      	ldp	x16, x15, [sp, #0x40]
    7ef4:      	mov	w2, #0x5ea0             // =24224
    7ef8:      	b	0x8728 <generic_kprobe_filter_arg+0x2cf8>
    7efc:      	ldrb	w11, [x22]
    7f00:      	cmp	w10, w11
    7f04:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7f08:      	cmp	w9, #0x11
    7f0c:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    7f10:      	ldr	w10, [x29, #0x18]
    7f14:      	cmp	w8, #0x2
    7f18:      	b.le	0x818c <generic_kprobe_filter_arg+0x275c>
    7f1c:      	sub	w11, w8, #0x3
    7f20:      	cmp	w11, #0x2
    7f24:      	b.hs	0x83e8 <generic_kprobe_filter_arg+0x29b8>
    7f28:      	ldrb	w11, [x22]
    7f2c:      	cmp	w10, w11
    7f30:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    7f34:      	b	0x8518 <generic_kprobe_filter_arg+0x2ae8>
    7f38:      	ldrh	w11, [x22]
    7f3c:      	cmp	w10, w11
    7f40:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7f44:      	cmp	w9, #0x11
    7f48:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    7f4c:      	ldr	w10, [x29, #0x18]
    7f50:      	cmp	w8, #0x2
    7f54:      	b.le	0x81ac <generic_kprobe_filter_arg+0x277c>
    7f58:      	sub	w11, w8, #0x3
    7f5c:      	cmp	w11, #0x2
    7f60:      	b.hs	0x8400 <generic_kprobe_filter_arg+0x29d0>
    7f64:      	ldrh	w11, [x22]
    7f68:      	cmp	w10, w11
    7f6c:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    7f70:      	b	0x855c <generic_kprobe_filter_arg+0x2b2c>
    7f74:      	cmp	w13, w10
    7f78:      	ccmp	w10, w12, #0x2, ls
    7f7c:      	cset	w12, ls
    7f80:      	orr	w8, w8, w12
    7f84:      	cmp	w11, #0x21
    7f88:      	mov	w12, #0x1               // =1
    7f8c:      	b.lo	0x833c <generic_kprobe_filter_arg+0x290c>
    7f90:      	ldp	w12, w11, [x29, #0x28]
    7f94:      	mov	w13, #0x1               // =1
    7f98:      	cmp	w9, #0xc
    7f9c:      	b.hi	0x8328 <generic_kprobe_filter_arg+0x28f8>
    7fa0:      	lsl	w9, w13, w9
    7fa4:      	mov	w13, #0x1402            // =5122
    7fa8:      	tst	w9, w13
    7fac:      	b.eq	0x8328 <generic_kprobe_filter_arg+0x28f8>
    7fb0:      	cmp	w12, w10
    7fb4:      	ccmp	w10, w11, #0x0, le
    7fb8:      	cset	w9, le
    7fbc:      	b	0x8334 <generic_kprobe_filter_arg+0x2904>
    7fc0:      	cmp	w12, w8
    7fc4:      	mov	w12, #0x1               // =1
    7fc8:      	b.hi	0x7fd4 <generic_kprobe_filter_arg+0x25a4>
    7fcc:      	cmp	w8, w11
    7fd0:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    7fd4:      	cmp	w10, #0x21
    7fd8:      	b.lo	0x5b2c <generic_kprobe_filter_arg+0xfc>
    7fdc:      	ldp	w11, w10, [x29, #0x28]
    7fe0:      	cmp	w9, #0xc
    7fe4:      	b.hi	0x8418 <generic_kprobe_filter_arg+0x29e8>
    7fe8:      	lsl	w9, w12, w9
    7fec:      	mov	w13, #0x1402            // =5122
    7ff0:      	tst	w9, w13
    7ff4:      	b.eq	0x8418 <generic_kprobe_filter_arg+0x29e8>
    7ff8:      	cmp	w11, w8
    7ffc:      	b.gt	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8000:      	cmp	w8, w10
    8004:      	b.le	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8008:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    800c:      	ldr	w12, [x22]
    8010:      	cmp	w12, w11
    8014:      	mov	w12, #0x1               // =1
    8018:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    801c:      	b	0x8030 <generic_kprobe_filter_arg+0x2600>
    8020:      	ldr	w12, [x22]
    8024:      	cmp	w12, w11
    8028:      	mov	w12, #0x1               // =1
    802c:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8030:      	cmp	w10, #0x11
    8034:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8038:      	ldr	w11, [x29, #0x18]
    803c:      	cmp	w8, #0x2
    8040:      	b.le	0x8064 <generic_kprobe_filter_arg+0x2634>
    8044:      	sub	w12, w8, #0x3
    8048:      	cmp	w12, #0x2
    804c:      	b.hs	0x80a4 <generic_kprobe_filter_arg+0x2674>
    8050:      	ldr	w12, [x22]
    8054:      	cmp	w12, w11
    8058:      	mov	w12, #0x1               // =1
    805c:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    8060:      	b	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    8064:      	cmp	w8, #0x1
    8068:      	b.eq	0x80c4 <generic_kprobe_filter_arg+0x2694>
    806c:      	cmp	w8, #0x2
    8070:      	b.ne	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    8074:      	mov	w12, #0x1               // =1
    8078:      	cmp	w9, #0xc
    807c:      	b.hi	0x85a8 <generic_kprobe_filter_arg+0x2b78>
    8080:      	lsl	w12, w12, w9
    8084:      	mov	w13, #0x1402            // =5122
    8088:      	tst	w12, w13
    808c:      	b.eq	0x85a8 <generic_kprobe_filter_arg+0x2b78>
    8090:      	ldr	w12, [x22]
    8094:      	cmp	w12, w11
    8098:      	mov	w12, #0x1               // =1
    809c:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    80a0:      	b	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    80a4:      	cmp	w8, #0xc
    80a8:      	mov	w12, #0x1               // =1
    80ac:      	b.ne	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    80b0:      	ldr	w12, [x22]
    80b4:      	tst	w12, w11
    80b8:      	mov	w12, #0x1               // =1
    80bc:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    80c0:      	b	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    80c4:      	mov	w12, #0x1               // =1
    80c8:      	cmp	w9, #0xc
    80cc:      	b.hi	0x8594 <generic_kprobe_filter_arg+0x2b64>
    80d0:      	lsl	w12, w12, w9
    80d4:      	mov	w13, #0x1402            // =5122
    80d8:      	tst	w12, w13
    80dc:      	b.eq	0x8594 <generic_kprobe_filter_arg+0x2b64>
    80e0:      	ldr	w12, [x22]
    80e4:      	cmp	w12, w11
    80e8:      	mov	w12, #0x1               // =1
    80ec:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    80f0:      	b	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    80f4:      	cmp	x12, x10
    80f8:      	ccmp	x10, x11, #0x2, ls
    80fc:      	cset	w9, ls
    8100:      	orr	w8, w8, w9
    8104:      	mov	w12, #0x1               // =1
    8108:      	tbz	w8, #0x0, 0x5cc8 <generic_kprobe_filter_arg+0x298>
    810c:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8110:      	cmp	w8, #0x2
    8114:      	b.eq	0x8474 <generic_kprobe_filter_arg+0x2a44>
    8118:      	cmp	w8, #0x3
    811c:      	b.ne	0x8158 <generic_kprobe_filter_arg+0x2728>
    8120:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8124:      	mov	w8, #0x1                // =1
    8128:      	add	x9, sp, #0x60
    812c:      	ldr	x0, [x0]
    8130:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    8134:      	cmp	w8, #0x6
    8138:      	b.eq	0x8488 <generic_kprobe_filter_arg+0x2a58>
    813c:      	cmp	w8, #0x7
    8140:      	b.ne	0x8158 <generic_kprobe_filter_arg+0x2728>
    8144:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8148:      	mov	w8, #0x1                // =1
    814c:      	add	x9, sp, #0x60
    8150:      	ldr	x0, [x0]
    8154:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    8158:      	ldp	x16, x15, [sp, #0x40]
    815c:      	mov	x23, xzr
    8160:      	mov	w2, #0x5ea0             // =24224
    8164:      	ldr	x17, [sp, #0x38]
    8168:      	ldr	w8, [x29, #0x4]
    816c:      	cmp	w8, #0x25
    8170:      	b.ls	0x6c74 <generic_kprobe_filter_arg+0x1244>
    8174:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    8178:      	cmp	x11, x8
    817c:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8180:      	cmp	x8, x10
    8184:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8188:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    818c:      	cmp	w8, #0x1
    8190:      	b.eq	0x850c <generic_kprobe_filter_arg+0x2adc>
    8194:      	cmp	w8, #0x2
    8198:      	b.ne	0x8518 <generic_kprobe_filter_arg+0x2ae8>
    819c:      	ldrb	w11, [x22]
    81a0:      	cmp	w10, w11
    81a4:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    81a8:      	b	0x8518 <generic_kprobe_filter_arg+0x2ae8>
    81ac:      	cmp	w8, #0x1
    81b0:      	b.eq	0x8550 <generic_kprobe_filter_arg+0x2b20>
    81b4:      	cmp	w8, #0x2
    81b8:      	b.ne	0x855c <generic_kprobe_filter_arg+0x2b2c>
    81bc:      	ldrh	w11, [x22]
    81c0:      	cmp	w10, w11
    81c4:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    81c8:      	b	0x855c <generic_kprobe_filter_arg+0x2b2c>
    81cc:      	mov	w23, #0x1               // =1
    81d0:      	b	0x871c <generic_kprobe_filter_arg+0x2cec>
    81d4:      	strh	w22, [x0], #0x2
    81d8:      	mov	w8, #0x4                // =4
    81dc:      	mov	w1, w22
    81e0:      	mov	x2, x24
    81e4:      	blr	x8
    81e8:      	ldr	w8, [sp, #0x1c]
    81ec:      	and	w8, w8, #0xffff
    81f0:      	cmp	w8, w22
    81f4:      	b.ls	0x8214 <generic_kprobe_filter_arg+0x27e4>
    81f8:      	add	x9, x19, x22
    81fc:      	sub	w8, w8, w22
    8200:      	ldr	x2, [sp, #0x10]
    8204:      	add	x0, x9, #0x2
    8208:      	and	w1, w8, #0xfff
    820c:      	mov	w8, #0x4                // =4
    8210:      	blr	x8
    8214:      	ldr	w8, [sp, #0x20]
    8218:      	cmp	w23, #0x3
    821c:      	str	w8, [sp, #0x60]
    8220:      	b.gt	0x824c <generic_kprobe_filter_arg+0x281c>
    8224:      	cmp	w23, #0x1
    8228:      	b.gt	0x84c4 <generic_kprobe_filter_arg+0x2a94>
    822c:      	cbz	w23, 0x86a8 <generic_kprobe_filter_arg+0x2c78>
    8230:      	cmp	w23, #0x1
    8234:      	b.ne	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    8238:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    823c:      	mov	w8, #0x1                // =1
    8240:      	add	x9, sp, #0x60
    8244:      	ldr	x0, [x0]
    8248:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    824c:      	cmp	w23, #0x5
    8250:      	b.gt	0x84e8 <generic_kprobe_filter_arg+0x2ab8>
    8254:      	cmp	w23, #0x4
    8258:      	b.eq	0x86bc <generic_kprobe_filter_arg+0x2c8c>
    825c:      	cmp	w23, #0x5
    8260:      	b.ne	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    8264:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8268:      	mov	w8, #0x1                // =1
    826c:      	add	x9, sp, #0x60
    8270:      	ldr	x0, [x0]
    8274:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    8278:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    827c:      	mov	w8, #0x1                // =1
    8280:      	add	x9, sp, #0x60
    8284:      	ldr	x0, [x0]
    8288:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    828c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8290:      	mov	w8, #0x1                // =1
    8294:      	add	x9, sp, #0x60
    8298:      	ldr	x0, [x0]
    829c:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    82a0:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    82a4:      	mov	w8, #0x1                // =1
    82a8:      	add	x9, sp, #0x60
    82ac:      	ldr	x0, [x0]
    82b0:      	b	0x82c4 <generic_kprobe_filter_arg+0x2894>
    82b4:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    82b8:      	mov	w8, #0x1                // =1
    82bc:      	add	x9, sp, #0x60
    82c0:      	ldr	x0, [x0]
    82c4:      	add	x1, sp, #0x60
    82c8:      	blr	x8
    82cc:      	cbz	x0, 0x82e8 <generic_kprobe_filter_arg+0x28b8>
    82d0:      	mov	w8, #0x1                // =1
    82d4:      	mov	x1, x22
    82d8:      	blr	x8
    82dc:      	cmp	x0, #0x0
    82e0:      	cset	w23, ne
    82e4:      	b	0x82ec <generic_kprobe_filter_arg+0x28bc>
    82e8:      	mov	x23, xzr
    82ec:      	ldp	x16, x15, [sp, #0x40]
    82f0:      	mov	w2, #0x5ea0             // =24224
    82f4:      	mov	w12, #0x1               // =1
    82f8:      	ldr	x17, [sp, #0x38]
    82fc:      	ldr	w8, [x29, #0x4]
    8300:      	cmp	w8, #0x25
    8304:      	b.hi	0x5cc4 <generic_kprobe_filter_arg+0x294>
    8308:      	mov	x9, #0x50               // =80
    830c:      	lsl	x8, x12, x8
    8310:      	movk	x9, #0xc00, lsl #16
    8314:      	movk	x9, #0x20, lsl #32
    8318:      	tst	x8, x9
    831c:      	b.eq	0x5cc4 <generic_kprobe_filter_arg+0x294>
    8320:      	eor	x23, x23, #0x1
    8324:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    8328:      	cmp	w12, w10
    832c:      	ccmp	w10, w11, #0x2, ls
    8330:      	cset	w9, ls
    8334:      	orr	w8, w8, w9
    8338:      	mov	w12, #0x1               // =1
    833c:      	tbz	w8, #0x0, 0x5cc8 <generic_kprobe_filter_arg+0x298>
    8340:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8344:      	ldr	x12, [x22]
    8348:      	cmp	x12, x11
    834c:      	mov	w12, #0x1               // =1
    8350:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8354:      	b	0x8368 <generic_kprobe_filter_arg+0x2938>
    8358:      	ldr	x12, [x22]
    835c:      	cmp	x12, x11
    8360:      	mov	w12, #0x1               // =1
    8364:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8368:      	cmp	w10, #0x21
    836c:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8370:      	ldr	x10, [x29, #0x28]
    8374:      	cmp	w8, #0x2
    8378:      	b.le	0x83a8 <generic_kprobe_filter_arg+0x2978>
    837c:      	sub	w9, w8, #0x3
    8380:      	cmp	w9, #0x2
    8384:      	b.lo	0x83d8 <generic_kprobe_filter_arg+0x29a8>
    8388:      	cmp	w8, #0x6
    838c:      	b.eq	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8390:      	cmp	w8, #0xc
    8394:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8398:      	ldr	x9, [x22]
    839c:      	tst	x9, x10
    83a0:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    83a4:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    83a8:      	cmp	w8, #0x1
    83ac:      	b.eq	0x842c <generic_kprobe_filter_arg+0x29fc>
    83b0:      	cmp	w8, #0x2
    83b4:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    83b8:      	cmp	w9, #0xc
    83bc:      	b.eq	0x83c8 <generic_kprobe_filter_arg+0x2998>
    83c0:      	cmp	w9, #0xa
    83c4:      	b.ne	0x8770 <generic_kprobe_filter_arg+0x2d40>
    83c8:      	ldr	x9, [x22]
    83cc:      	cmp	x9, x10
    83d0:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    83d4:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    83d8:      	ldr	x9, [x22]
    83dc:      	cmp	x9, x10
    83e0:      	b.ne	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    83e4:      	b	0x5cbc <generic_kprobe_filter_arg+0x28c>
    83e8:      	cmp	w8, #0xc
    83ec:      	b.ne	0x8518 <generic_kprobe_filter_arg+0x2ae8>
    83f0:      	ldrb	w11, [x22]
    83f4:      	tst	w10, w11
    83f8:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    83fc:      	b	0x8518 <generic_kprobe_filter_arg+0x2ae8>
    8400:      	cmp	w8, #0xc
    8404:      	b.ne	0x855c <generic_kprobe_filter_arg+0x2b2c>
    8408:      	ldrh	w11, [x22]
    840c:      	tst	w10, w11
    8410:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8414:      	b	0x855c <generic_kprobe_filter_arg+0x2b2c>
    8418:      	cmp	w11, w8
    841c:      	b.hi	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8420:      	cmp	w8, w10
    8424:      	b.ls	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8428:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    842c:      	cmp	w9, #0xc
    8430:      	b.eq	0x843c <generic_kprobe_filter_arg+0x2a0c>
    8434:      	cmp	w9, #0xa
    8438:      	b.ne	0x8780 <generic_kprobe_filter_arg+0x2d50>
    843c:      	ldr	x9, [x22]
    8440:      	cmp	x9, x10
    8444:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8448:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    844c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8450:      	mov	w8, #0x1                // =1
    8454:      	add	x9, sp, #0x60
    8458:      	ldr	x0, [x0]
    845c:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    8460:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8464:      	mov	w8, #0x1                // =1
    8468:      	add	x9, sp, #0x60
    846c:      	ldr	x0, [x0]
    8470:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    8474:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8478:      	mov	w8, #0x1                // =1
    847c:      	add	x9, sp, #0x60
    8480:      	ldr	x0, [x0]
    8484:      	b	0x8498 <generic_kprobe_filter_arg+0x2a68>
    8488:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    848c:      	mov	w8, #0x1                // =1
    8490:      	add	x9, sp, #0x60
    8494:      	ldr	x0, [x0]
    8498:      	add	x1, sp, #0x60
    849c:      	blr	x8
    84a0:      	cbz	x0, 0x84bc <generic_kprobe_filter_arg+0x2a8c>
    84a4:      	mov	w8, #0x1                // =1
    84a8:      	mov	x1, x22
    84ac:      	blr	x8
    84b0:      	cmp	x0, #0x0
    84b4:      	cset	w23, ne
    84b8:      	b	0x6c58 <generic_kprobe_filter_arg+0x1228>
    84bc:      	mov	x23, xzr
    84c0:      	b	0x6c58 <generic_kprobe_filter_arg+0x1228>
    84c4:      	cmp	w23, #0x2
    84c8:      	b.eq	0x86d0 <generic_kprobe_filter_arg+0x2ca0>
    84cc:      	cmp	w23, #0x3
    84d0:      	b.ne	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    84d4:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    84d8:      	mov	w8, #0x1                // =1
    84dc:      	add	x9, sp, #0x60
    84e0:      	ldr	x0, [x0]
    84e4:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    84e8:      	cmp	w23, #0x6
    84ec:      	b.eq	0x86e4 <generic_kprobe_filter_arg+0x2cb4>
    84f0:      	cmp	w23, #0x7
    84f4:      	b.ne	0x8718 <generic_kprobe_filter_arg+0x2ce8>
    84f8:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    84fc:      	mov	w8, #0x1                // =1
    8500:      	add	x9, sp, #0x60
    8504:      	ldr	x0, [x0]
    8508:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    850c:      	ldrb	w11, [x22]
    8510:      	cmp	w10, w11
    8514:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8518:      	cmp	w9, #0x15
    851c:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8520:      	ldr	w9, [x29, #0x1c]
    8524:      	cmp	w8, #0x2
    8528:      	b.le	0x8660 <generic_kprobe_filter_arg+0x2c30>
    852c:      	sub	w10, w8, #0x3
    8530:      	cmp	w10, #0x2
    8534:      	b.lo	0x8690 <generic_kprobe_filter_arg+0x2c60>
    8538:      	cmp	w8, #0x6
    853c:      	b.eq	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8540:      	cmp	w8, #0xc
    8544:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8548:      	ldrb	w10, [x22]
    854c:      	b	0x85ec <generic_kprobe_filter_arg+0x2bbc>
    8550:      	ldrh	w11, [x22]
    8554:      	cmp	w10, w11
    8558:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    855c:      	cmp	w9, #0x15
    8560:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8564:      	ldr	w9, [x29, #0x1c]
    8568:      	cmp	w8, #0x2
    856c:      	b.le	0x8678 <generic_kprobe_filter_arg+0x2c48>
    8570:      	sub	w10, w8, #0x3
    8574:      	cmp	w10, #0x2
    8578:      	b.lo	0x8698 <generic_kprobe_filter_arg+0x2c68>
    857c:      	cmp	w8, #0x6
    8580:      	b.eq	0x5cc8 <generic_kprobe_filter_arg+0x298>
    8584:      	cmp	w8, #0xc
    8588:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    858c:      	ldrh	w10, [x22]
    8590:      	b	0x85ec <generic_kprobe_filter_arg+0x2bbc>
    8594:      	ldr	w12, [x22]
    8598:      	cmp	w12, w11
    859c:      	mov	w12, #0x1               // =1
    85a0:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    85a4:      	b	0x85b8 <generic_kprobe_filter_arg+0x2b88>
    85a8:      	ldr	w12, [x22]
    85ac:      	cmp	w12, w11
    85b0:      	mov	w12, #0x1               // =1
    85b4:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    85b8:      	cmp	w10, #0x15
    85bc:      	b.lo	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    85c0:      	ldr	w10, [x29, #0x1c]
    85c4:      	cmp	w8, #0x2
    85c8:      	b.le	0x85f8 <generic_kprobe_filter_arg+0x2bc8>
    85cc:      	sub	w9, w8, #0x3
    85d0:      	cmp	w9, #0x2
    85d4:      	b.lo	0x8630 <generic_kprobe_filter_arg+0x2c00>
    85d8:      	cmp	w8, #0x6
    85dc:      	b.eq	0x5cc8 <generic_kprobe_filter_arg+0x298>
    85e0:      	cmp	w8, #0xc
    85e4:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    85e8:      	ldr	w9, [x22]
    85ec:      	tst	w9, w10
    85f0:      	b.ne	0x5cc8 <generic_kprobe_filter_arg+0x298>
    85f4:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    85f8:      	cmp	w8, #0x1
    85fc:      	b.eq	0x8638 <generic_kprobe_filter_arg+0x2c08>
    8600:      	cmp	w8, #0x2
    8604:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8608:      	cmp	w9, #0xc
    860c:      	b.hi	0x87a0 <generic_kprobe_filter_arg+0x2d70>
    8610:      	lsl	w9, w12, w9
    8614:      	mov	w11, #0x1402            // =5122
    8618:      	tst	w9, w11
    861c:      	b.eq	0x87a0 <generic_kprobe_filter_arg+0x2d70>
    8620:      	ldr	w9, [x22]
    8624:      	cmp	w9, w10
    8628:      	b.lt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    862c:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8630:      	ldr	w9, [x22]
    8634:      	b	0x869c <generic_kprobe_filter_arg+0x2c6c>
    8638:      	cmp	w9, #0xc
    863c:      	b.hi	0x87b0 <generic_kprobe_filter_arg+0x2d80>
    8640:      	lsl	w9, w12, w9
    8644:      	mov	w11, #0x1402            // =5122
    8648:      	tst	w9, w11
    864c:      	b.eq	0x87b0 <generic_kprobe_filter_arg+0x2d80>
    8650:      	ldr	w9, [x22]
    8654:      	cmp	w9, w10
    8658:      	b.gt	0x5cc8 <generic_kprobe_filter_arg+0x298>
    865c:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8660:      	cmp	w8, #0x1
    8664:      	b.eq	0x8790 <generic_kprobe_filter_arg+0x2d60>
    8668:      	cmp	w8, #0x2
    866c:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8670:      	ldrb	w10, [x22]
    8674:      	b	0x87b4 <generic_kprobe_filter_arg+0x2d84>
    8678:      	cmp	w8, #0x1
    867c:      	b.eq	0x8798 <generic_kprobe_filter_arg+0x2d68>
    8680:      	cmp	w8, #0x2
    8684:      	b.ne	0x5b2c <generic_kprobe_filter_arg+0xfc>
    8688:      	ldrh	w10, [x22]
    868c:      	b	0x87b4 <generic_kprobe_filter_arg+0x2d84>
    8690:      	ldrb	w10, [x22]
    8694:      	b	0x869c <generic_kprobe_filter_arg+0x2c6c>
    8698:      	ldrh	w10, [x22]
    869c:      	cmp	w9, w10
    86a0:      	b.eq	0x5cbc <generic_kprobe_filter_arg+0x28c>
    86a4:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    86a8:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    86ac:      	mov	w8, #0x1                // =1
    86b0:      	add	x9, sp, #0x60
    86b4:      	ldr	x0, [x0]
    86b8:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    86bc:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    86c0:      	mov	w8, #0x1                // =1
    86c4:      	add	x9, sp, #0x60
    86c8:      	ldr	x0, [x0]
    86cc:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    86d0:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    86d4:      	mov	w8, #0x1                // =1
    86d8:      	add	x9, sp, #0x60
    86dc:      	ldr	x0, [x0]
    86e0:      	b	0x86f4 <generic_kprobe_filter_arg+0x2cc4>
    86e4:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    86e8:      	mov	w8, #0x1                // =1
    86ec:      	add	x9, sp, #0x60
    86f0:      	ldr	x0, [x0]
    86f4:      	add	x1, sp, #0x60
    86f8:      	blr	x8
    86fc:      	cbz	x0, 0x8718 <generic_kprobe_filter_arg+0x2ce8>
    8700:      	mov	w8, #0x1                // =1
    8704:      	mov	x1, x19
    8708:      	blr	x8
    870c:      	cmp	x0, #0x0
    8710:      	cset	w23, ne
    8714:      	b	0x871c <generic_kprobe_filter_arg+0x2cec>
    8718:      	mov	x23, xzr
    871c:      	ldp	x16, x15, [sp, #0x40]
    8720:      	mov	w2, #0x5ea0             // =24224
    8724:      	mov	w12, #0x1               // =1
    8728:      	ldr	x17, [sp, #0x38]
    872c:      	ldr	w8, [x29, #0x4]
    8730:      	cmp	w8, #0x25
    8734:      	b.hi	0x875c <generic_kprobe_filter_arg+0x2d2c>
    8738:      	mov	x9, #0x50               // =80
    873c:      	ldr	x19, [sp, #0x30]
    8740:      	lsl	x8, x12, x8
    8744:      	movk	x9, #0xc00, lsl #16
    8748:      	movk	x9, #0x20, lsl #32
    874c:      	tst	x8, x9
    8750:      	b.eq	0x5cc4 <generic_kprobe_filter_arg+0x294>
    8754:      	cmp	x23, #0x0
    8758:      	b	0x5cc0 <generic_kprobe_filter_arg+0x290>
    875c:      	ldr	x19, [sp, #0x30]
    8760:      	b	0x5cc4 <generic_kprobe_filter_arg+0x294>
    8764:      	ldr	x19, [sp, #0x30]
    8768:      	mov	w12, #0x1               // =1
    876c:      	b	0x7890 <generic_kprobe_filter_arg+0x1e60>
    8770:      	ldr	x9, [x22]
    8774:      	cmp	x9, x10
    8778:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    877c:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8780:      	ldr	x9, [x22]
    8784:      	cmp	x9, x10
    8788:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    878c:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    8790:      	ldrb	w10, [x22]
    8794:      	b	0x87a4 <generic_kprobe_filter_arg+0x2d74>
    8798:      	ldrh	w10, [x22]
    879c:      	b	0x87a4 <generic_kprobe_filter_arg+0x2d74>
    87a0:      	ldr	w9, [x22]
    87a4:      	cmp	w9, w10
    87a8:      	b.lo	0x5cc8 <generic_kprobe_filter_arg+0x298>
    87ac:      	b	0x87bc <generic_kprobe_filter_arg+0x2d8c>
    87b0:      	ldr	w9, [x22]
    87b4:      	cmp	w9, w10
    87b8:      	b.hi	0x5cc8 <generic_kprobe_filter_arg+0x298>
    87bc:      	orr	w8, w8, #0x2
    87c0:      	cmp	w8, #0x6
    87c4:      	b.eq	0x5cc8 <generic_kprobe_filter_arg+0x298>
    87c8:      	b	0x5b2c <generic_kprobe_filter_arg+0xfc>
    87cc:      	nop

00000000000087d0 <generic_kprobe_actions>:
    87d0:      	sub	sp, sp, #0xe0
    87d4:      	str	x29, [sp, #0x90]
    87d8:      	stp	x30, x25, [sp, #0xa0]
    87dc:      	stp	x24, x23, [sp, #0xb0]
    87e0:      	stp	x22, x21, [sp, #0xc0]
    87e4:      	stp	x20, x19, [sp, #0xd0]
    87e8:      	str	wzr, [sp, #0x4c]
    87ec:      	adrp	x24, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    87f0:      	mov	w8, #0x1                // =1
    87f4:      	add	x9, sp, #0x4c
    87f8:      	ldr	x24, [x24]
    87fc:      	mov	x25, x0
    8800:      	add	x1, sp, #0x4c
    8804:      	mov	x0, x24
    8808:      	blr	x8
    880c:      	cbz	x0, 0x9600 <generic_kprobe_actions+0xe30>
    8810:      	mov	w8, #0x5f04             // =24324
    8814:      	ldr	w19, [x0, x8]
    8818:      	cmp	w19, #0x2
    881c:      	b.lt	0x9600 <generic_kprobe_actions+0xe30>
    8820:      	mov	w8, #0x5ef8             // =24312
    8824:      	add	x1, x0, x8
    8828:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    882c:      	mov	w8, #0x1                // =1
    8830:      	ldr	x0, [x0]
    8834:      	blr	x8
    8838:      	cbz	x0, 0x9600 <generic_kprobe_actions+0xe30>
    883c:      	and	x8, x19, #0x7ff
    8840:      	mov	w9, #0x1                // =1
    8844:      	add	x1, sp, #0x50
    8848:      	ldr	w8, [x0, x8]
    884c:      	str	wzr, [sp, #0x50]
    8850:      	add	w8, w8, w19
    8854:      	and	w8, w8, #0x7ff
    8858:      	add	x20, x0, x8
    885c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8860:      	add	x8, sp, #0x50
    8864:      	ldr	x0, [x0]
    8868:      	blr	x9
    886c:      	cbz	x0, 0x8890 <generic_kprobe_actions+0xc0>
    8870:      	ldrb	w8, [x0]
    8874:      	tst	w8, #0xff
    8878:      	cset	w8, eq
    887c:      	str	w8, [sp, #0x3c]
    8880:      	mov	w8, #0x8                // =8
    8884:      	cinc	x8, x8, ne
    8888:      	str	x8, [sp, #0x20]
    888c:      	b	0x88a0 <generic_kprobe_actions+0xd0>
    8890:      	mov	w8, #0x8                // =8
    8894:      	str	x8, [sp, #0x20]
    8898:      	mov	w8, #0x1                // =1
    889c:      	str	w8, [sp, #0x3c]
    88a0:      	mov	w22, wzr
    88a4:      	mov	w29, wzr
    88a8:      	add	x23, sp, #0x54
    88ac:      	str	x20, [sp, #0x40]
    88b0:      	str	x25, [sp, #0x30]
    88b4:      	mov	w8, #0x1                // =1
    88b8:      	str	w8, [sp, #0x2c]
    88bc:      	b	0x8940 <generic_kprobe_actions+0x170>
    88c0:      	mov	w0, wzr
    88c4:      	cbz	w0, 0x917c <generic_kprobe_actions+0x9ac>
    88c8:      	mov	w29, wzr
    88cc:      	add	w22, w22, #0x1
    88d0:      	cmp	w22, #0x3
    88d4:      	b.ne	0x8940 <generic_kprobe_actions+0x170>
    88d8:      	b	0x95dc <generic_kprobe_actions+0xe0c>
    88dc:      	add	x8, x21, x8, lsl #3
    88e0:      	mov	x0, x23
    88e4:      	ldr	x8, [x8, #0x5e78]
    88e8:      	and	x8, x8, #0x7ff
    88ec:      	add	x2, x21, x8
    88f0:      	ldr	w8, [x2, #0x90]!
    88f4:      	and	x8, x8, #0xfff
    88f8:      	add	x1, x8, #0x8
    88fc:      	mov	w8, #0x4                // =4
    8900:      	blr	x8
    8904:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8908:      	mov	x3, xzr
    890c:      	mov	w8, #0x2                // =2
    8910:      	ldr	x0, [x0]
    8914:      	add	x9, sp, #0x58
    8918:      	add	x1, sp, #0x58
    891c:      	mov	x2, x23
    8920:      	blr	x8
    8924:      	mov	w0, wzr
    8928:      	add	x23, sp, #0x54
    892c:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    8930:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8934:      	nop
    8938:      	nop
    893c:      	nop
    8940:      	ldr	w9, [x20]
    8944:      	lsl	w8, w29, #2
    8948:      	add	w8, w8, #0x4
    894c:      	cmp	w8, w9
    8950:      	b.hs	0x95dc <generic_kprobe_actions+0xe0c>
    8954:      	add	x8, x20, w29, uxtw #2
    8958:      	add	x1, sp, #0x54
    895c:      	mov	x0, x24
    8960:      	ldrsw	x19, [x8, #0x4]
    8964:      	str	wzr, [sp, #0x54]
    8968:      	mov	w8, #0x1                // =1
    896c:      	blr	x8
    8970:      	cbz	x0, 0x88c8 <generic_kprobe_actions+0xf8>
    8974:      	mov	x21, x0
    8978:      	cmp	w19, #0x7
    897c:      	b.gt	0x89a0 <generic_kprobe_actions+0x1d0>
    8980:      	cmp	w19, #0x3
    8984:      	b.gt	0x89f4 <generic_kprobe_actions+0x224>
    8988:      	cmp	w19, #0x1
    898c:      	b.gt	0x8a74 <generic_kprobe_actions+0x2a4>
    8990:      	cbz	w19, 0x8cf4 <generic_kprobe_actions+0x524>
    8994:      	cmp	w19, #0x1
    8998:      	b.eq	0x8a84 <generic_kprobe_actions+0x2b4>
    899c:      	b	0x917c <generic_kprobe_actions+0x9ac>
    89a0:      	cmp	w19, #0xb
    89a4:      	b.gt	0x8a4c <generic_kprobe_actions+0x27c>
    89a8:      	sub	w8, w19, #0xa
    89ac:      	cmp	w8, #0x2
    89b0:      	b.lo	0x8adc <generic_kprobe_actions+0x30c>
    89b4:      	cmp	w19, #0x8
    89b8:      	b.eq	0x8bb4 <generic_kprobe_actions+0x3e4>
    89bc:      	cmp	w19, #0x9
    89c0:      	b.ne	0x917c <generic_kprobe_actions+0x9ac>
    89c4:      	add	w29, w29, #0x1
    89c8:      	add	x8, x20, w29, uxtw #2
    89cc:      	ldr	w0, [x8, #0x4]
    89d0:      	ldr	w8, [sp, #0x3c]
    89d4:      	cbz	w8, 0x8d98 <generic_kprobe_actions+0x5c8>
    89d8:      	sxtw	x8, w0
    89dc:      	mov	w9, #0x6d               // =109
    89e0:      	blr	x9
    89e4:      	mov	w20, #0x2               // =2
    89e8:      	mov	w23, w29
    89ec:      	add	x29, sp, #0x58
    89f0:      	b	0x9140 <generic_kprobe_actions+0x970>
    89f4:      	sub	w8, w19, #0x6
    89f8:      	cmp	w8, #0x2
    89fc:      	b.lo	0x8ba0 <generic_kprobe_actions+0x3d0>
    8a00:      	cmp	w19, #0x4
    8a04:      	b.eq	0x8bbc <generic_kprobe_actions+0x3ec>
    8a08:      	cmp	w19, #0x5
    8a0c:      	b.ne	0x917c <generic_kprobe_actions+0x9ac>
    8a10:      	add	w8, w29, #0x1
    8a14:      	add	x9, x20, #0x4
    8a18:      	add	w29, w29, #0x2
    8a1c:      	ldr	w8, [x9, w8, uxtw #2]
    8a20:      	ldr	w20, [x9, w29, uxtw #2]
    8a24:      	stp	xzr, xzr, [sp, #0x58]
    8a28:      	and	x8, x8, #0x7
    8a2c:      	cmp	w8, #0x4
    8a30:      	b.hi	0x8a44 <generic_kprobe_actions+0x274>
    8a34:      	add	x9, x21, x8, lsl #2
    8a38:      	mov	w10, #0x5ea0            // =24224
    8a3c:      	ldr	w9, [x9, x10]
    8a40:      	cbz	w9, 0x8fd4 <generic_kprobe_actions+0x804>
    8a44:      	ldr	x20, [sp, #0x40]
    8a48:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8a4c:      	cmp	w19, #0xc
    8a50:      	b.eq	0x8da8 <generic_kprobe_actions+0x5d8>
    8a54:      	cmp	w19, #0xd
    8a58:      	b.eq	0x8c48 <generic_kprobe_actions+0x478>
    8a5c:      	cmp	w19, #0xe
    8a60:      	b.ne	0x917c <generic_kprobe_actions+0x9ac>
    8a64:      	ldr	x20, [sp, #0x20]
    8a68:      	add	w23, w29, #0x2
    8a6c:      	add	x29, sp, #0x58
    8a70:      	b	0x9140 <generic_kprobe_actions+0x970>
    8a74:      	cmp	w19, #0x2
    8a78:      	b.eq	0x8d8c <generic_kprobe_actions+0x5bc>
    8a7c:      	cmp	w19, #0x3
    8a80:      	b.ne	0x917c <generic_kprobe_actions+0x9ac>
    8a84:      	add	w8, w29, #0x1
    8a88:      	add	x9, x20, #0x4
    8a8c:      	add	w29, w29, #0x2
    8a90:      	ldr	w23, [x9, w8, uxtw #2]
    8a94:      	ldr	w20, [x9, w29, uxtw #2]
    8a98:      	stp	xzr, xzr, [sp, #0x58]
    8a9c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8aa0:      	mov	w8, #0x1                // =1
    8aa4:      	add	x9, sp, #0x78
    8aa8:      	add	x1, sp, #0x78
    8aac:      	str	wzr, [sp, #0x78]
    8ab0:      	ldr	x0, [x0]
    8ab4:      	blr	x8
    8ab8:      	cbz	x0, 0x8acc <generic_kprobe_actions+0x2fc>
    8abc:      	and	x8, x23, #0x7
    8ac0:      	cmp	w8, #0x4
    8ac4:      	b.ls	0x8e98 <generic_kprobe_actions+0x6c8>
    8ac8:      	mov	w0, wzr
    8acc:      	ldr	x20, [sp, #0x40]
    8ad0:      	add	x23, sp, #0x54
    8ad4:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    8ad8:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8adc:      	add	w29, w29, #0x1
    8ae0:      	add	x8, x20, w29, uxtw #2
    8ae4:      	ldr	w8, [x8, #0x4]
    8ae8:      	and	x8, x8, #0x7
    8aec:      	cmp	w8, #0x4
    8af0:      	b.hi	0x88c0 <generic_kprobe_actions+0xf0>
    8af4:      	add	x9, x21, x8, lsl #2
    8af8:      	mov	w10, #0x5ea0            // =24224
    8afc:      	ldr	w9, [x9, x10]
    8b00:      	cbnz	w9, 0x88c0 <generic_kprobe_actions+0xf0>
    8b04:      	add	x8, x21, x8, lsl #3
    8b08:      	ldr	x8, [x8, #0x5e78]
    8b0c:      	and	x8, x8, #0x7ff
    8b10:      	add	x8, x21, x8
    8b14:      	ldr	x8, [x8, #0xb8]
    8b18:      	str	x8, [sp, #0x78]
    8b1c:      	cbz	x8, 0x88c0 <generic_kprobe_actions+0xf0>
    8b20:      	cmp	w19, #0xa
    8b24:      	b.ne	0x91bc <generic_kprobe_actions+0x9ec>
    8b28:      	mov	w8, #0xe                // =14
    8b2c:      	blr	x8
    8b30:      	lsr	x8, x0, #32
    8b34:      	mov	x24, x0
    8b38:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8b3c:      	str	w8, [sp, #0x58]
    8b40:      	mov	w8, #0x1                // =1
    8b44:      	add	x9, sp, #0x58
    8b48:      	add	x1, sp, #0x58
    8b4c:      	ldr	x0, [x0]
    8b50:      	blr	x8
    8b54:      	cbz	x0, 0x8b90 <generic_kprobe_actions+0x3c0>
    8b58:      	ldr	w8, [x0]
    8b5c:      	mov	x3, xzr
    8b60:      	add	x9, sp, #0x78
    8b64:      	add	x10, sp, #0x58
    8b68:      	stp	w8, w24, [sp, #0x58]
    8b6c:      	ldr	x8, [x0, #0x8]
    8b70:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8b74:      	add	x1, sp, #0x78
    8b78:      	add	x2, sp, #0x58
    8b7c:      	str	x8, [sp, #0x60]
    8b80:      	mov	w8, #0x2                // =2
    8b84:      	ldr	x0, [x0]
    8b88:      	blr	x8
    8b8c:      	mov	w0, wzr
    8b90:      	adrp	x24, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8b94:      	ldr	x24, [x24]
    8b98:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    8b9c:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8ba0:      	add	w29, w29, #0x1
    8ba4:      	add	x8, x20, w29, uxtw #2
    8ba8:      	ldr	w8, [x8, #0x4]
    8bac:      	str	w8, [x21, #0x78]
    8bb0:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8bb4:      	str	wzr, [sp, #0x2c]
    8bb8:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8bbc:      	ldr	w8, [sp, #0x3c]
    8bc0:      	add	w23, w29, #0x1
    8bc4:      	cbz	w8, 0x8ebc <generic_kprobe_actions+0x6ec>
    8bc8:      	add	x8, x20, w23, uxtw #2
    8bcc:      	ldr	w8, [x8, #0x4]
    8bd0:      	str	w8, [sp, #0x88]
    8bd4:      	mov	w8, #0xe                // =14
    8bd8:      	blr	x8
    8bdc:      	str	x0, [sp, #0x78]
    8be0:      	adrp	x25, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8be4:      	mov	w8, #0x1                // =1
    8be8:      	add	x20, sp, #0x78
    8bec:      	ldr	x25, [x25]
    8bf0:      	add	x1, sp, #0x78
    8bf4:      	mov	x0, x25
    8bf8:      	blr	x8
    8bfc:      	add	x29, sp, #0x58
    8c00:      	cbz	x0, 0x8fb0 <generic_kprobe_actions+0x7e0>
    8c04:      	mov	w8, #0x11               // =17
    8c08:      	adrp	x20, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8c0c:      	mov	x24, x0
    8c10:      	add	x1, sp, #0x58
    8c14:      	movk	w8, #0xe, lsl #16
    8c18:      	str	w8, [sp, #0x58]
    8c1c:      	mov	w8, #0x35c              // =860
    8c20:      	stur	x8, [sp, #0x5c]
    8c24:      	mov	w8, #0x1                // =1
    8c28:      	ldr	x20, [x20]
    8c2c:      	mov	x0, x20
    8c30:      	blr	x8
    8c34:      	cbz	x0, 0x9104 <generic_kprobe_actions+0x934>
    8c38:      	ldr	w8, [x0]
    8c3c:      	add	w8, w8, #0x1
    8c40:      	str	w8, [x0]
    8c44:      	b	0x9128 <generic_kprobe_actions+0x958>
    8c48:      	mov	w8, #0xe                // =14
    8c4c:      	blr	x8
    8c50:      	str	x0, [sp, #0x68]
    8c54:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8c58:      	mov	w8, #0x1                // =1
    8c5c:      	add	x9, sp, #0x68
    8c60:      	ldr	x0, [x0]
    8c64:      	add	x1, sp, #0x68
    8c68:      	blr	x8
    8c6c:      	cbz	x0, 0x917c <generic_kprobe_actions+0x9ac>
    8c70:      	ldur	x8, [x0, #0x4]
    8c74:      	mov	x24, x25
    8c78:      	adrp	x25, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8c7c:      	add	x9, sp, #0x78
    8c80:      	str	x8, [sp, #0x78]
    8c84:      	mov	w8, #0x2                // =2
    8c88:      	add	x1, sp, #0x78
    8c8c:      	str	w8, [sp, #0x80]
    8c90:      	mov	w8, #0x1                // =1
    8c94:      	ldr	x25, [x25]
    8c98:      	mov	x0, x25
    8c9c:      	blr	x8
    8ca0:      	mov	w9, #0x1                // =1
    8ca4:      	str	w9, [sp, #0x9c]
    8ca8:      	cbz	x0, 0x8f3c <generic_kprobe_actions+0x76c>
    8cac:      	mov	x25, x24
    8cb0:      	nop
    8cb4:      	nop
    8cb8:      	nop
    8cbc:      	nop
    8cc0:      	ldaxr	w8, [x0]
    8cc4:      	add	w8, w8, #0x1
    8cc8:      	stlxr	w9, w8, [x0]
    8ccc:      	cbnz	w9, 0x8cc0 <generic_kprobe_actions+0x4f0>
    8cd0:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8cd4:      	mov	w8, #0x3                // =3
    8cd8:      	add	x9, sp, #0x68
    8cdc:      	ldr	x0, [x0]
    8ce0:      	add	x1, sp, #0x68
    8ce4:      	blr	x8
    8ce8:      	adrp	x24, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8cec:      	ldr	x24, [x24]
    8cf0:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8cf4:      	add	w8, w29, #0x1
    8cf8:      	add	x9, x20, #0x4
    8cfc:      	ldr	w25, [x9, w8, uxtw #2]
    8d00:      	add	w8, w29, #0x2
    8d04:      	ldr	w20, [x9, w8, uxtw #2]
    8d08:      	mov	w8, #0x7d               // =125
    8d0c:      	blr	x8
    8d10:      	str	x0, [sp, #0x58]
    8d14:      	str	wzr, [sp, #0x68]
    8d18:      	str	x25, [sp, #0x8]
    8d1c:      	cbz	w25, 0x9448 <generic_kprobe_actions+0xc78>
    8d20:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8d24:      	mov	w8, #0x1                // =1
    8d28:      	add	x9, sp, #0x68
    8d2c:      	ldr	x0, [x0]
    8d30:      	add	x1, sp, #0x68
    8d34:      	blr	x8
    8d38:      	cbz	x0, 0x9448 <generic_kprobe_actions+0xc78>
    8d3c:      	mov	x25, x0
    8d40:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8d44:      	mov	w8, #0x1                // =1
    8d48:      	ldr	x0, [x0]
    8d4c:      	add	x9, sp, #0x68
    8d50:      	add	x1, sp, #0x68
    8d54:      	blr	x8
    8d58:      	ldr	x8, [x21, #0x60]
    8d5c:      	mov	x2, x0
    8d60:      	cmp	w20, #0x2
    8d64:      	str	x25, [sp]
    8d68:      	str	x8, [x25]
    8d6c:      	ldr	x8, [x21, #0x70]
    8d70:      	str	x8, [x25, #0x8]
    8d74:      	b.eq	0x9258 <generic_kprobe_actions+0xa88>
    8d78:      	cmp	w20, #0x1
    8d7c:      	b.eq	0x9250 <generic_kprobe_actions+0xa80>
    8d80:      	cbnz	w20, 0x9448 <generic_kprobe_actions+0xc78>
    8d84:      	ldr	w8, [x21, #0x7c]
    8d88:      	b	0x925c <generic_kprobe_actions+0xa8c>
    8d8c:      	mov	w0, #0x9                // =9
    8d90:      	ldr	w8, [sp, #0x3c]
    8d94:      	cbnz	w8, 0x89d8 <generic_kprobe_actions+0x208>
    8d98:      	mov	w20, #0x3               // =3
    8d9c:      	mov	w23, w29
    8da0:      	add	x29, sp, #0x58
    8da4:      	b	0x9140 <generic_kprobe_actions+0x970>
    8da8:      	ldr	w8, [sp, #0x3c]
    8dac:      	add	w23, w29, #0x3
    8db0:      	cbz	w8, 0x8ec8 <generic_kprobe_actions+0x6f8>
    8db4:      	add	x8, x20, #0x4
    8db8:      	ldr	w9, [x8, w23, uxtw #2]
    8dbc:      	cmp	w9, #0x4
    8dc0:      	b.hi	0x8dd4 <generic_kprobe_actions+0x604>
    8dc4:      	add	x10, x21, x9, lsl #2
    8dc8:      	mov	w11, #0x5ea0            // =24224
    8dcc:      	ldr	w10, [x10, x11]
    8dd0:      	cbz	w10, 0x94c8 <generic_kprobe_actions+0xcf8>
    8dd4:      	mov	x9, xzr
    8dd8:      	add	w10, w29, #0x2
    8ddc:      	ldr	w20, [x8, w10, uxtw #2]
    8de0:      	add	w10, w29, #0x1
    8de4:      	ldr	w24, [x8, w10, uxtw #2]
    8de8:      	ldr	w8, [x21, #0x60]
    8dec:      	orr	x25, x8, x9, lsl #32
    8df0:      	mov	w8, #0xe                // =14
    8df4:      	blr	x8
    8df8:      	str	x0, [sp, #0x88]
    8dfc:      	strh	w24, [sp, #0x78]
    8e00:      	mov	w8, #0x1                // =1
    8e04:      	add	x1, sp, #0x88
    8e08:      	strh	w20, [sp, #0x7a]
    8e0c:      	stur	x25, [sp, #0x7c]
    8e10:      	adrp	x25, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8e14:      	ldr	x25, [x25]
    8e18:      	add	x20, sp, #0x88
    8e1c:      	mov	x0, x25
    8e20:      	blr	x8
    8e24:      	cbz	x0, 0x908c <generic_kprobe_actions+0x8bc>
    8e28:      	ldur	x8, [x0, #0x4]
    8e2c:      	mov	w20, #0x1               // =1
    8e30:      	adrp	x29, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8e34:      	add	x9, sp, #0x68
    8e38:      	str	w20, [sp, #0x70]
    8e3c:      	mov	x24, x0
    8e40:      	add	x1, sp, #0x68
    8e44:      	str	x8, [sp, #0x68]
    8e48:      	mov	w8, #0x1                // =1
    8e4c:      	ldr	x29, [x29]
    8e50:      	mov	x0, x29
    8e54:      	blr	x8
    8e58:      	ldr	x25, [sp, #0x30]
    8e5c:      	str	w20, [sp, #0x98]
    8e60:      	cbz	x0, 0x91dc <generic_kprobe_actions+0xa0c>
    8e64:      	ldaxr	w8, [x0]
    8e68:      	add	w8, w8, #0x1
    8e6c:      	stlxr	w9, w8, [x0]
    8e70:      	cbnz	w9, 0x8e64 <generic_kprobe_actions+0x694>
    8e74:      	ldr	x8, [sp, #0x78]
    8e78:      	ldr	w9, [sp, #0x80]
    8e7c:      	add	x29, sp, #0x58
    8e80:      	str	w9, [x24, #0x8]
    8e84:      	str	x8, [x24]
    8e88:      	adrp	x24, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8e8c:      	ldr	x24, [x24]
    8e90:      	mov	w20, #0x6               // =6
    8e94:      	b	0x9140 <generic_kprobe_actions+0x970>
    8e98:      	add	x9, x21, x8, lsl #2
    8e9c:      	mov	w10, #0x5ea0            // =24224
    8ea0:      	add	x23, sp, #0x54
    8ea4:      	ldr	w9, [x9, x10]
    8ea8:      	cbz	w9, 0x8ed4 <generic_kprobe_actions+0x704>
    8eac:      	ldr	x20, [sp, #0x40]
    8eb0:      	mov	w0, wzr
    8eb4:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    8eb8:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8ebc:      	mov	w20, #0x5               // =5
    8ec0:      	add	x29, sp, #0x58
    8ec4:      	b	0x9140 <generic_kprobe_actions+0x970>
    8ec8:      	mov	w20, #0x7               // =7
    8ecc:      	add	x29, sp, #0x58
    8ed0:      	b	0x9140 <generic_kprobe_actions+0x970>
    8ed4:      	add	x8, x21, x8, lsl #3
    8ed8:      	mov	x23, x0
    8edc:      	ldr	x8, [x8, #0x5e78]
    8ee0:      	str	wzr, [sp, #0x64]
    8ee4:      	and	x8, x8, #0x7ff
    8ee8:      	add	x8, x21, x8
    8eec:      	ldr	w8, [x8, #0x90]
    8ef0:      	str	w8, [sp, #0x60]
    8ef4:      	mov	w8, #0xe                // =14
    8ef8:      	blr	x8
    8efc:      	lsr	x8, x0, #32
    8f00:      	cmp	w19, #0x1
    8f04:      	str	x8, [sp, #0x58]
    8f08:      	b.ne	0x9194 <generic_kprobe_actions+0x9c4>
    8f0c:      	and	x8, x20, #0x7
    8f10:      	cmp	w8, #0x4
    8f14:      	b.hi	0x8ac8 <generic_kprobe_actions+0x2f8>
    8f18:      	add	x9, x21, x8, lsl #2
    8f1c:      	mov	w10, #0x5ea0            // =24224
    8f20:      	ldr	x20, [sp, #0x40]
    8f24:      	ldr	w9, [x9, x10]
    8f28:      	cbz	w9, 0x88dc <generic_kprobe_actions+0x10c>
    8f2c:      	mov	w0, wzr
    8f30:      	add	x23, sp, #0x54
    8f34:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    8f38:      	b	0x917c <generic_kprobe_actions+0x9ac>
    8f3c:      	mov	w8, #0x2                // =2
    8f40:      	add	x10, sp, #0x9c
    8f44:      	add	x11, sp, #0x78
    8f48:      	add	x1, sp, #0x78
    8f4c:      	add	x2, sp, #0x9c
    8f50:      	mov	x0, x25
    8f54:      	mov	w3, #0x1                // =1
    8f58:      	blr	x8
    8f5c:      	mov	x25, x24
    8f60:      	cbz	x0, 0x8cd0 <generic_kprobe_actions+0x500>
    8f64:      	mov	x24, x0
    8f68:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8f6c:      	add	x10, sp, #0x58
    8f70:      	add	x1, sp, #0x58
    8f74:      	neg	w8, w24
    8f78:      	strh	w8, [sp, #0x58]
    8f7c:      	mov	w8, #0x3                // =3
    8f80:      	strh	w8, [sp, #0x5a]
    8f84:      	mov	x8, #0x3b               // =59
    8f88:      	movk	x8, #0x2, lsl #32
    8f8c:      	stur	x8, [sp, #0x5c]
    8f90:      	mov	w8, #0x1                // =1
    8f94:      	ldr	x0, [x0]
    8f98:      	blr	x8
    8f9c:      	cbz	x0, 0x94e0 <generic_kprobe_actions+0xd10>
    8fa0:      	ldr	w8, [x0]
    8fa4:      	add	w8, w8, #0x1
    8fa8:      	str	w8, [x0]
    8fac:      	b	0x950c <generic_kprobe_actions+0xd3c>
    8fb0:      	mov	x3, xzr
    8fb4:      	mov	w8, #0x2                // =2
    8fb8:      	add	x9, sp, #0x88
    8fbc:      	add	x1, sp, #0x78
    8fc0:      	add	x2, sp, #0x88
    8fc4:      	mov	x0, x25
    8fc8:      	blr	x8
    8fcc:      	ldr	x25, [sp, #0x30]
    8fd0:      	b	0x9134 <generic_kprobe_actions+0x964>
    8fd4:      	add	x8, x21, x8, lsl #3
    8fd8:      	ldr	x8, [x8, #0x5e78]
    8fdc:      	and	x8, x8, #0x7ff
    8fe0:      	add	x8, x21, x8
    8fe4:      	ldr	w8, [x8, #0x90]
    8fe8:      	str	w8, [sp, #0x60]
    8fec:      	mov	w8, #0xe                // =14
    8ff0:      	blr	x8
    8ff4:      	lsr	x8, x0, #32
    8ff8:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x25d0>
    8ffc:      	add	x9, sp, #0x58
    9000:      	str	x8, [sp, #0x58]
    9004:      	mov	w8, #0x1                // =1
    9008:      	add	x1, sp, #0x58
    900c:      	ldr	x0, [x0]
    9010:      	blr	x8
    9014:      	cbz	x0, 0x8a44 <generic_kprobe_actions+0x274>
    9018:      	and	x8, x20, #0x7
    901c:      	cmp	w8, #0x4
    9020:      	b.hi	0x8a44 <generic_kprobe_actions+0x274>
    9024:      	add	x9, x21, x8, lsl #2
    9028:      	mov	w10, #0x5ea0            // =24224
    902c:      	ldr	w9, [x9, x10]
    9030:      	cbnz	w9, 0x8a44 <generic_kprobe_actions+0x274>
    9034:      	add	x8, x21, x8, lsl #3
    9038:      	mov	x23, x0
    903c:      	ldr	x8, [x8, #0x5e78]
    9040:      	str	wzr, [sp, #0x64]
    9044:      	and	x8, x8, #0x7ff
    9048:      	add	x8, x21, x8
    904c:      	ldr	w8, [x8, #0x90]
    9050:      	str	w8, [sp, #0x60]
    9054:      	mov	w8, #0xe                // =14
    9058:      	blr	x8
    905c:      	lsr	x8, x0, #32
    9060:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9064:      	mov	x3, xzr
    9068:      	str	x8, [sp, #0x58]
    906c:      	mov	w8, #0x2                // =2
    9070:      	add	x9, sp, #0x58
    9074:      	add	x1, sp, #0x58
    9078:      	ldr	x0, [x0]
    907c:      	mov	x2, x23
    9080:      	add	x23, sp, #0x54
    9084:      	blr	x8
    9088:      	b	0x8a44 <generic_kprobe_actions+0x274>
    908c:      	mov	x3, xzr
    9090:      	mov	w8, #0x2                // =2
    9094:      	add	x9, sp, #0x78
    9098:      	add	x1, sp, #0x88
    909c:      	add	x2, sp, #0x78
    90a0:      	mov	x0, x25
    90a4:      	blr	x8
    90a8:      	adrp	x24, 0x9000 <generic_kprobe_actions+0x830>
    90ac:      	ldr	x25, [sp, #0x30]
    90b0:      	add	x29, sp, #0x58
    90b4:      	ldr	x24, [x24]
    90b8:      	cbz	x0, 0x8e90 <generic_kprobe_actions+0x6c0>
    90bc:      	neg	w8, w0
    90c0:      	adrp	x20, 0x9000 <generic_kprobe_actions+0x830>
    90c4:      	add	x1, sp, #0x58
    90c8:      	strh	w8, [sp, #0x58]
    90cc:      	mov	w8, #0x3                // =3
    90d0:      	strh	w8, [sp, #0x5a]
    90d4:      	mov	x8, #0x6b               // =107
    90d8:      	movk	x8, #0x2, lsl #32
    90dc:      	stur	x8, [sp, #0x5c]
    90e0:      	mov	w8, #0x1                // =1
    90e4:      	ldr	x20, [x20]
    90e8:      	mov	x0, x20
    90ec:      	blr	x8
    90f0:      	cbz	x0, 0x9554 <generic_kprobe_actions+0xd84>
    90f4:      	ldr	w8, [x0]
    90f8:      	add	w8, w8, #0x1
    90fc:      	str	w8, [x0]
    9100:      	b	0x8e90 <generic_kprobe_actions+0x6c0>
    9104:      	mov	w8, #0x1                // =1
    9108:      	mov	x3, xzr
    910c:      	add	x9, sp, #0x68
    9110:      	str	w8, [sp, #0x68]
    9114:      	mov	w8, #0x2                // =2
    9118:      	add	x1, sp, #0x58
    911c:      	add	x2, sp, #0x68
    9120:      	mov	x0, x20
    9124:      	blr	x8
    9128:      	ldr	w8, [sp, #0x88]
    912c:      	ldr	x25, [sp, #0x30]
    9130:      	str	w8, [x24]
    9134:      	adrp	x24, 0x9000 <generic_kprobe_actions+0x830>
    9138:      	mov	w20, #0x4               // =4
    913c:      	ldr	x24, [x24]
    9140:      	str	wzr, [sp, #0x58]
    9144:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9148:      	mov	w8, #0x1                // =1
    914c:      	add	x1, sp, #0x58
    9150:      	ldr	x0, [x0]
    9154:      	blr	x8
    9158:      	cbz	x0, 0x9170 <generic_kprobe_actions+0x9a0>
    915c:      	add	x8, x0, x20, lsl #3
    9160:      	ldaxr	x9, [x8]
    9164:      	add	x9, x9, #0x1
    9168:      	stlxr	w10, x9, [x8]
    916c:      	cbnz	w10, 0x9160 <generic_kprobe_actions+0x990>
    9170:      	ldr	x20, [sp, #0x40]
    9174:      	mov	w29, w23
    9178:      	add	x23, sp, #0x54
    917c:      	add	w29, w29, #0x1
    9180:      	str	x19, [x21, #0x70]
    9184:      	add	w22, w22, #0x1
    9188:      	cmp	w22, #0x3
    918c:      	b.ne	0x8940 <generic_kprobe_actions+0x170>
    9190:      	b	0x95dc <generic_kprobe_actions+0xe0c>
    9194:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9198:      	mov	w8, #0x3                // =3
    919c:      	add	x9, sp, #0x58
    91a0:      	ldr	x0, [x0]
    91a4:      	add	x1, sp, #0x58
    91a8:      	blr	x8
    91ac:      	ldr	x20, [sp, #0x40]
    91b0:      	add	x23, sp, #0x54
    91b4:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    91b8:      	b	0x917c <generic_kprobe_actions+0x9ac>
    91bc:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    91c0:      	mov	w8, #0x3                // =3
    91c4:      	add	x9, sp, #0x78
    91c8:      	ldr	x0, [x0]
    91cc:      	add	x1, sp, #0x78
    91d0:      	blr	x8
    91d4:      	cbnz	w0, 0x88c8 <generic_kprobe_actions+0xf8>
    91d8:      	b	0x917c <generic_kprobe_actions+0x9ac>
    91dc:      	mov	w8, #0x2                // =2
    91e0:      	add	x9, sp, #0x98
    91e4:      	add	x10, sp, #0x68
    91e8:      	add	x1, sp, #0x68
    91ec:      	add	x2, sp, #0x98
    91f0:      	mov	x0, x29
    91f4:      	mov	w3, #0x1                // =1
    91f8:      	blr	x8
    91fc:      	cbz	x0, 0x8e74 <generic_kprobe_actions+0x6a4>
    9200:      	mov	x29, x0
    9204:      	adrp	x20, 0x9000 <generic_kprobe_actions+0x830>
    9208:      	add	x9, sp, #0x58
    920c:      	add	x1, sp, #0x58
    9210:      	neg	w8, w29
    9214:      	strh	w8, [sp, #0x58]
    9218:      	mov	w8, #0x3                // =3
    921c:      	strh	w8, [sp, #0x5a]
    9220:      	mov	x8, #0x3b               // =59
    9224:      	movk	x8, #0x2, lsl #32
    9228:      	stur	x8, [sp, #0x5c]
    922c:      	mov	w8, #0x1                // =1
    9230:      	ldr	x20, [x20]
    9234:      	mov	x0, x20
    9238:      	blr	x8
    923c:      	cbz	x0, 0x957c <generic_kprobe_actions+0xdac>
    9240:      	ldr	w8, [x0]
    9244:      	add	w8, w8, #0x1
    9248:      	str	w8, [x0]
    924c:      	b	0x95a4 <generic_kprobe_actions+0xdd4>
    9250:      	ldr	w8, [x21, #0x10]
    9254:      	b	0x925c <generic_kprobe_actions+0xa8c>
    9258:      	mov	x8, xzr
    925c:      	ldr	x9, [sp]
    9260:      	ldr	x25, [sp, #0x30]
    9264:      	mov	w1, #0xc8               // =200
    9268:      	add	x0, x9, #0x18
    926c:      	str	x8, [x9, #0x10]
    9270:      	mov	w8, #0x4                // =4
    9274:      	mov	w9, #0xc8               // =200
    9278:      	str	x0, [sp, #0x10]
    927c:      	blr	x8
    9280:      	mov	w8, #0x5e78             // =24184
    9284:      	mov	x24, xzr
    9288:      	str	wzr, [sp, #0x1c]
    928c:      	add	x20, x21, x8
    9290:      	b	0x92b0 <generic_kprobe_actions+0xae0>
    9294:      	nop
    9298:      	nop
    929c:      	nop
    92a0:      	add	x24, x24, #0x4
    92a4:      	add	x20, x20, #0x8
    92a8:      	cmp	x24, #0x14
    92ac:      	b.eq	0x93d8 <generic_kprobe_actions+0xc08>
    92b0:      	str	wzr, [sp, #0x78]
    92b4:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    92b8:      	mov	w8, #0x1                // =1
    92bc:      	add	x9, sp, #0x78
    92c0:      	ldr	x0, [x0]
    92c4:      	add	x1, sp, #0x78
    92c8:      	blr	x8
    92cc:      	cbz	x0, 0x93d8 <generic_kprobe_actions+0xc08>
    92d0:      	mov	w8, #0x5ef8             // =24312
    92d4:      	add	x1, x0, x8
    92d8:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    92dc:      	mov	w8, #0x1                // =1
    92e0:      	ldr	x0, [x0]
    92e4:      	blr	x8
    92e8:      	cbz	x0, 0x93d8 <generic_kprobe_actions+0xc08>
    92ec:      	add	x8, x0, x24
    92f0:      	ldr	w8, [x8, #0x40]
    92f4:      	cmn	w8, #0x1
    92f8:      	b.eq	0x93d8 <generic_kprobe_actions+0xc08>
    92fc:      	ldr	x8, [x20]
    9300:      	ldr	w9, [x21, #0x4]
    9304:      	cmp	x8, x9
    9308:      	b.ge	0x93d8 <generic_kprobe_actions+0xc08>
    930c:      	cmp	x24, #0x10
    9310:      	b.eq	0x9374 <generic_kprobe_actions+0xba4>
    9314:      	str	wzr, [sp, #0x78]
    9318:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    931c:      	mov	w8, #0x1                // =1
    9320:      	add	x9, sp, #0x78
    9324:      	ldr	x0, [x0]
    9328:      	add	x1, sp, #0x78
    932c:      	blr	x8
    9330:      	cbz	x0, 0x9370 <generic_kprobe_actions+0xba0>
    9334:      	mov	w8, #0x5ef8             // =24312
    9338:      	add	x1, x0, x8
    933c:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9340:      	mov	w8, #0x1                // =1
    9344:      	ldr	x0, [x0]
    9348:      	blr	x8
    934c:      	cbz	x0, 0x9370 <generic_kprobe_actions+0xba0>
    9350:      	add	x8, x0, x24
    9354:      	ldr	w9, [x8, #0x44]
    9358:      	ldr	x8, [x20]
    935c:      	cmn	w9, #0x1
    9360:      	b.eq	0x9374 <generic_kprobe_actions+0xba4>
    9364:      	ldr	w9, [x20, #0x8]
    9368:      	sub	w9, w9, w8
    936c:      	b	0x9380 <generic_kprobe_actions+0xbb0>
    9370:      	ldr	x8, [x20]
    9374:      	ldr	w9, [x21, #0x4]
    9378:      	sub	w9, w9, w8
    937c:      	add	w9, w9, #0x4
    9380:      	cmp	w9, #0x1
    9384:      	b.lt	0x92a0 <generic_kprobe_actions+0xad0>
    9388:      	mov	w10, #0x3ffc            // =16380
    938c:      	cmp	w9, #0x28
    9390:      	add	w8, w8, w10
    9394:      	mov	w10, #0x28              // =40
    9398:      	csel	w23, w9, w10, lt
    939c:      	ldr	w9, [sp, #0x1c]
    93a0:      	and	x8, x8, #0x3fff
    93a4:      	add	x8, x21, x8
    93a8:      	mov	w1, w23
    93ac:      	add	x2, x8, #0x90
    93b0:      	mov	w8, #0x4                // =4
    93b4:      	and	w25, w9, #0xff
    93b8:      	ldr	x9, [sp, #0x10]
    93bc:      	add	x0, x9, x25
    93c0:      	blr	x8
    93c4:      	add	w8, w23, w25
    93c8:      	ldr	x25, [sp, #0x30]
    93cc:      	add	x23, sp, #0x54
    93d0:      	str	w8, [sp, #0x1c]
    93d4:      	b	0x92a0 <generic_kprobe_actions+0xad0>
    93d8:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    93dc:      	mov	w8, #0x1                // =1
    93e0:      	ldr	x0, [x0]
    93e4:      	ldr	x1, [sp]
    93e8:      	blr	x8
    93ec:      	cbz	x0, 0x9420 <generic_kprobe_actions+0xc50>
    93f0:      	ldr	x9, [sp, #0x58]
    93f4:      	ldr	x11, [sp, #0x8]
    93f8:      	mov	x10, #-0x4240           // =-16960
    93fc:      	movk	x10, #0xfff0, lsl #16
    9400:      	ldr	x8, [x0]
    9404:      	madd	x9, x11, x10, x9
    9408:      	cmp	x8, x9
    940c:      	b.ls	0x9420 <generic_kprobe_actions+0xc50>
    9410:      	str	wzr, [sp, #0x2c]
    9414:      	adrp	x24, 0x9000 <generic_kprobe_actions+0x830>
    9418:      	ldr	x24, [x24]
    941c:      	b	0x944c <generic_kprobe_actions+0xc7c>
    9420:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9424:      	mov	x3, xzr
    9428:      	mov	w8, #0x2                // =2
    942c:      	ldr	x0, [x0]
    9430:      	ldr	x1, [sp]
    9434:      	add	x9, sp, #0x58
    9438:      	add	x2, sp, #0x58
    943c:      	blr	x8
    9440:      	adrp	x24, 0x9000 <generic_kprobe_actions+0x830>
    9444:      	ldr	x24, [x24]
    9448:      	ldr	x25, [sp, #0x30]
    944c:      	ldr	x20, [sp, #0x40]
    9450:      	add	w8, w29, #0x3
    9454:      	add	x8, x20, w8, uxtw #2
    9458:      	ldr	w8, [x8, #0x4]
    945c:      	cbz	w8, 0x9488 <generic_kprobe_actions+0xcb8>
    9460:      	ldrb	w8, [x21, #0x1]
    9464:      	adrp	x1, 0x9000 <generic_kprobe_actions+0x830>
    9468:      	mov	x2, xzr
    946c:      	mov	x0, x25
    9470:      	orr	w8, w8, #0x2
    9474:      	strb	w8, [x21, #0x1]
    9478:      	mov	w8, #0x1b               // =27
    947c:      	ldr	x1, [x1]
    9480:      	blr	x8
    9484:      	str	x0, [x21, #0x80]
    9488:      	add	w29, w29, #0x4
    948c:      	add	x8, x20, w29, uxtw #2
    9490:      	ldr	w8, [x8, #0x4]
    9494:      	cbz	w8, 0x917c <generic_kprobe_actions+0x9ac>
    9498:      	ldrb	w8, [x21, #0x1]
    949c:      	adrp	x1, 0x9000 <generic_kprobe_actions+0x830>
    94a0:      	mov	w9, #0x100              // =256
    94a4:      	mov	x0, x25
    94a8:      	mov	w2, #0x100              // =256
    94ac:      	orr	w8, w8, #0x4
    94b0:      	strb	w8, [x21, #0x1]
    94b4:      	mov	w8, #0x1b               // =27
    94b8:      	ldr	x1, [x1]
    94bc:      	blr	x8
    94c0:      	str	x0, [x21, #0x88]
    94c4:      	b	0x917c <generic_kprobe_actions+0x9ac>
    94c8:      	add	x9, x21, x9, lsl #3
    94cc:      	ldr	x9, [x9, #0x5e78]
    94d0:      	and	x9, x9, #0x7ff
    94d4:      	add	x9, x21, x9
    94d8:      	ldr	x9, [x9, #0x90]
    94dc:      	b	0x8dd8 <generic_kprobe_actions+0x608>
    94e0:      	mov	w8, #0x1                // =1
    94e4:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    94e8:      	mov	x3, xzr
    94ec:      	str	w8, [sp, #0x88]
    94f0:      	mov	w8, #0x2                // =2
    94f4:      	add	x9, sp, #0x88
    94f8:      	add	x10, sp, #0x58
    94fc:      	ldr	x0, [x0]
    9500:      	add	x1, sp, #0x58
    9504:      	add	x2, sp, #0x88
    9508:      	blr	x8
    950c:      	cbz	w24, 0x8cd0 <generic_kprobe_actions+0x500>
    9510:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9514:      	mov	w8, #0x1                // =1
    9518:      	add	x9, sp, #0x78
    951c:      	ldr	x0, [x0]
    9520:      	add	x1, sp, #0x78
    9524:      	blr	x8
    9528:      	cbz	x0, 0x8cd0 <generic_kprobe_actions+0x500>
    952c:      	ldr	w8, [sp, #0x9c]
    9530:      	nop
    9534:      	nop
    9538:      	nop
    953c:      	nop
    9540:      	ldaxr	w9, [x0]
    9544:      	add	w9, w9, w8
    9548:      	stlxr	w10, w9, [x0]
    954c:      	cbnz	w10, 0x9540 <generic_kprobe_actions+0xd70>
    9550:      	b	0x8cd0 <generic_kprobe_actions+0x500>
    9554:      	mov	w8, #0x1                // =1
    9558:      	mov	x3, xzr
    955c:      	add	x9, sp, #0x68
    9560:      	str	w8, [sp, #0x68]
    9564:      	mov	w8, #0x2                // =2
    9568:      	add	x1, sp, #0x58
    956c:      	add	x2, sp, #0x68
    9570:      	mov	x0, x20
    9574:      	blr	x8
    9578:      	b	0x8e90 <generic_kprobe_actions+0x6c0>
    957c:      	mov	w8, #0x1                // =1
    9580:      	mov	x3, xzr
    9584:      	add	x9, sp, #0x9c
    9588:      	str	w8, [sp, #0x9c]
    958c:      	mov	w8, #0x2                // =2
    9590:      	add	x10, sp, #0x58
    9594:      	add	x1, sp, #0x58
    9598:      	add	x2, sp, #0x9c
    959c:      	mov	x0, x20
    95a0:      	blr	x8
    95a4:      	cbz	w29, 0x8e74 <generic_kprobe_actions+0x6a4>
    95a8:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    95ac:      	mov	w8, #0x1                // =1
    95b0:      	add	x9, sp, #0x68
    95b4:      	ldr	x0, [x0]
    95b8:      	add	x1, sp, #0x68
    95bc:      	blr	x8
    95c0:      	cbz	x0, 0x8e74 <generic_kprobe_actions+0x6a4>
    95c4:      	ldr	w8, [sp, #0x98]
    95c8:      	ldaxr	w9, [x0]
    95cc:      	add	w9, w9, w8
    95d0:      	stlxr	w10, w9, [x0]
    95d4:      	cbnz	w10, 0x95c8 <generic_kprobe_actions+0xdf8>
    95d8:      	b	0x8e74 <generic_kprobe_actions+0x6a4>
    95dc:      	ldr	w8, [sp, #0x2c]
    95e0:      	cbz	w8, 0x9600 <generic_kprobe_actions+0xe30>
    95e4:      	adrp	x1, 0x9000 <generic_kprobe_actions+0x830>
    95e8:      	mov	w8, #0x5                // =5
    95ec:      	mov	w9, #0xc                // =12
    95f0:      	ldr	x1, [x1]
    95f4:      	mov	x0, x25
    95f8:      	mov	w2, #0x5                // =5
    95fc:      	blr	x9
    9600:      	ldp	x20, x19, [sp, #0xd0]
    9604:      	mov	w0, wzr
    9608:      	ldr	x29, [sp, #0x90]
    960c:      	ldp	x22, x21, [sp, #0xc0]
    9610:      	ldp	x24, x23, [sp, #0xb0]
    9614:      	ldp	x30, x25, [sp, #0xa0]
    9618:      	add	sp, sp, #0xe0
    961c:      	ret

0000000000009620 <generic_kprobe_output>:
    9620:      	sub	sp, sp, #0xc0
    9624:      	str	x29, [sp, #0x70]
    9628:      	stp	x30, x25, [sp, #0x80]
    962c:      	stp	x24, x23, [sp, #0x90]
    9630:      	stp	x22, x21, [sp, #0xa0]
    9634:      	stp	x20, x19, [sp, #0xb0]
    9638:      	mov	x19, x0
    963c:      	str	wzr, [sp, #0x4]
    9640:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9644:      	mov	w8, #0x1                // =1
    9648:      	ldr	x0, [x0]
    964c:      	add	x9, sp, #0x4
    9650:      	add	x1, sp, #0x4
    9654:      	blr	x8
    9658:      	cbz	x0, 0x9ab8 <generic_kprobe_output+0x498>
    965c:      	adrp	x21, 0x9000 <generic_kprobe_actions+0x830>
    9660:      	ldr	x8, [x0, #0x5ee8]
    9664:      	mov	x20, x0
    9668:      	ldr	x21, [x21]
    966c:      	cbz	x8, 0x98f8 <generic_kprobe_output+0x2d8>
    9670:      	mov	w8, #0xe                // =14
    9674:      	blr	x8
    9678:      	mov	w8, #0x23               // =35
    967c:      	lsr	x22, x0, #32
    9680:      	blr	x8
    9684:      	str	w22, [sp, #0x28]
    9688:      	mov	w8, #0x1                // =1
    968c:      	add	x9, sp, #0x28
    9690:      	mov	x23, x0
    9694:      	add	x1, sp, #0x28
    9698:      	mov	x0, x21
    969c:      	blr	x8
    96a0:      	cbz	x0, 0x98f8 <generic_kprobe_output+0x2d8>
    96a4:      	add	x2, x23, #0xb50
    96a8:      	mov	w29, #0x8               // =8
    96ac:      	add	x8, sp, #0x78
    96b0:      	mov	w9, #0x4                // =4
    96b4:      	mov	x22, x0
    96b8:      	add	x24, x0, #0x28
    96bc:      	add	x0, sp, #0x78
    96c0:      	mov	w1, #0x8                // =8
    96c4:      	mov	w25, #0x4               // =4
    96c8:      	blr	x9
    96cc:      	ldr	x8, [sp, #0x78]
    96d0:      	mov	w9, #0x48               // =72
    96d4:      	add	x10, sp, #0x28
    96d8:      	mov	w11, #0x4               // =4
    96dc:      	ldr	x2, [sp, #0x78]
    96e0:      	add	x0, sp, #0x28
    96e4:      	mov	w1, #0x48               // =72
    96e8:      	blr	x11
    96ec:      	ldr	x8, [sp, #0x30]
    96f0:      	mov	w9, #0x4                // =4
    96f4:      	mov	x0, x24
    96f8:      	mov	w1, #0x4                // =4
    96fc:      	add	x8, x8, #0x218
    9700:      	ldr	x8, [sp, #0x30]
    9704:      	add	x2, x8, #0x218
    9708:      	blr	x9
    970c:      	ldr	x8, [sp, #0x38]
    9710:      	add	x0, x22, #0x2c
    9714:      	mov	w9, #0x4                // =4
    9718:      	mov	w1, #0x4                // =4
    971c:      	add	x8, x8, #0x4d8
    9720:      	ldr	x8, [sp, #0x38]
    9724:      	add	x2, x8, #0x4d8
    9728:      	blr	x9
    972c:      	ldr	x8, [sp, #0x40]
    9730:      	add	x0, x22, #0x30
    9734:      	mov	w9, #0x4                // =4
    9738:      	mov	w1, #0x4                // =4
    973c:      	add	x8, x8, #0x58
    9740:      	ldr	x8, [sp, #0x40]
    9744:      	add	x2, x8, #0x58
    9748:      	blr	x9
    974c:      	str	xzr, [sp, #0x20]
    9750:      	add	x2, x23, #0x938
    9754:      	add	x8, sp, #0x20
    9758:      	add	x0, sp, #0x20
    975c:      	mov	w1, #0x8                // =8
    9760:      	blr	x25
    9764:      	ldr	x8, [sp, #0x20]
    9768:      	cbz	x8, 0x97ec <generic_kprobe_output+0x1cc>
    976c:      	str	wzr, [sp, #0x1c]
    9770:      	add	x8, x8, #0x4
    9774:      	add	x9, sp, #0x1c
    9778:      	mov	w10, #0x4               // =4
    977c:      	add	x0, sp, #0x1c
    9780:      	mov	w1, #0x4                // =4
    9784:      	mov	w24, #0x4               // =4
    9788:      	ldr	x8, [sp, #0x20]
    978c:      	add	x2, x8, #0x4
    9790:      	blr	x10
    9794:      	ldr	x8, [sp, #0x20]
    9798:      	ldrsw	x9, [sp, #0x1c]
    979c:      	add	x10, sp, #0x8
    97a0:      	mov	w11, #0x4               // =4
    97a4:      	add	x0, sp, #0x8
    97a8:      	mov	w1, #0x10               // =16
    97ac:      	add	x8, x8, x9, lsl #4
    97b0:      	mov	w9, #0x10               // =16
    97b4:      	add	x8, x8, #0x80
    97b8:      	ldr	x8, [sp, #0x20]
    97bc:      	ldrsw	x9, [sp, #0x1c]
    97c0:      	add	x8, x8, x9, lsl #4
    97c4:      	add	x2, x8, #0x80
    97c8:      	blr	x11
    97cc:      	ldr	x8, [sp, #0x10]
    97d0:      	add	x0, x22, #0x34
    97d4:      	mov	w1, #0x4                // =4
    97d8:      	add	x8, x8, #0x158
    97dc:      	ldr	x8, [sp, #0x10]
    97e0:      	add	x2, x8, #0x158
    97e4:      	blr	x24
    97e8:      	b	0x97f0 <generic_kprobe_output+0x1d0>
    97ec:      	str	wzr, [x22, #0x34]
    97f0:      	ldr	x8, [sp, #0x48]
    97f4:      	add	x0, x22, #0x38
    97f8:      	mov	w9, #0x4                // =4
    97fc:      	mov	w1, #0x4                // =4
    9800:      	mov	w24, #0x4               // =4
    9804:      	add	x8, x8, #0x158
    9808:      	ldr	x8, [sp, #0x48]
    980c:      	add	x2, x8, #0x158
    9810:      	blr	x9
    9814:      	ldr	x8, [sp, #0x50]
    9818:      	add	x0, x22, #0x3c
    981c:      	mov	w9, #0x4                // =4
    9820:      	mov	w1, #0x4                // =4
    9824:      	add	x8, x8, #0x118
    9828:      	ldr	x8, [sp, #0x50]
    982c:      	add	x2, x8, #0x118
    9830:      	blr	x9
    9834:      	ldr	x8, [sp, #0x58]
    9838:      	add	x0, x22, #0x40
    983c:      	mov	w9, #0x4                // =4
    9840:      	mov	w1, #0x4                // =4
    9844:      	add	x8, x8, #0x98
    9848:      	ldr	x8, [sp, #0x58]
    984c:      	add	x2, x8, #0x98
    9850:      	blr	x9
    9854:      	ldr	x8, [sp, #0x60]
    9858:      	add	x0, x22, #0x44
    985c:      	mov	w9, #0x4                // =4
    9860:      	mov	w1, #0x4                // =4
    9864:      	add	x8, x8, #0x98
    9868:      	ldr	x8, [sp, #0x60]
    986c:      	add	x2, x8, #0x98
    9870:      	blr	x9
    9874:      	ldr	x8, [sp, #0x68]
    9878:      	add	x0, x22, #0x48
    987c:      	mov	w9, #0x4                // =4
    9880:      	mov	w1, #0x4                // =4
    9884:      	add	x8, x8, #0x58
    9888:      	ldr	x8, [sp, #0x68]
    988c:      	add	x2, x8, #0x58
    9890:      	blr	x9
    9894:      	str	xzr, [sp, #0x8]
    9898:      	str	xzr, [sp, #0x20]
    989c:      	add	x2, x23, #0xae0
    98a0:      	mov	w23, #0x8               // =8
    98a4:      	add	x8, sp, #0x8
    98a8:      	mov	w9, #0x4                // =4
    98ac:      	add	x0, sp, #0x8
    98b0:      	mov	w1, #0x8                // =8
    98b4:      	blr	x9
    98b8:      	ldr	x8, [sp, #0x8]
    98bc:      	add	x9, sp, #0x20
    98c0:      	mov	w10, #0x4               // =4
    98c4:      	add	x0, sp, #0x20
    98c8:      	mov	w1, #0x8                // =8
    98cc:      	add	x8, x8, #0x90
    98d0:      	ldr	x8, [sp, #0x8]
    98d4:      	add	x2, x8, #0x90
    98d8:      	blr	x10
    98dc:      	ldr	x8, [sp, #0x20]
    98e0:      	add	x0, x22, #0x4c
    98e4:      	mov	w1, #0x4                // =4
    98e8:      	add	x8, x8, #0x158
    98ec:      	ldr	x8, [sp, #0x20]
    98f0:      	add	x2, x8, #0x158
    98f4:      	blr	x24
    98f8:      	ldr	x8, [x20, #0x5ef0]
    98fc:      	cbz	x8, 0x9998 <generic_kprobe_output+0x378>
    9900:      	mov	w8, #0xe                // =14
    9904:      	blr	x8
    9908:      	mov	w8, #0x23               // =35
    990c:      	lsr	x23, x0, #32
    9910:      	blr	x8
    9914:      	str	w23, [sp, #0x28]
    9918:      	mov	w8, #0x1                // =1
    991c:      	add	x9, sp, #0x28
    9920:      	mov	x22, x0
    9924:      	add	x1, sp, #0x28
    9928:      	mov	x0, x21
    992c:      	blr	x8
    9930:      	cbz	x0, 0x9998 <generic_kprobe_output+0x378>
    9934:      	add	x2, x22, #0xae0
    9938:      	mov	w22, #0x8               // =8
    993c:      	add	x8, sp, #0x28
    9940:      	mov	w9, #0x4                // =4
    9944:      	add	x21, x0, #0x50
    9948:      	mov	x24, x0
    994c:      	add	x0, sp, #0x28
    9950:      	mov	w1, #0x8                // =8
    9954:      	mov	w23, #0x4               // =4
    9958:      	blr	x9
    995c:      	ldr	x25, [sp, #0x28]
    9960:      	add	x0, x24, #0x58
    9964:      	mov	w8, #0x4                // =4
    9968:      	mov	w1, #0x8                // =8
    996c:      	add	x2, x25, #0x40
    9970:      	blr	x8
    9974:      	add	x0, x24, #0x60
    9978:      	add	x2, x25, #0x30
    997c:      	mov	w8, #0x4                // =4
    9980:      	mov	w1, #0x8                // =8
    9984:      	blr	x8
    9988:      	add	x2, x25, #0x38
    998c:      	mov	x0, x21
    9990:      	mov	w1, #0x8                // =8
    9994:      	blr	x23
    9998:      	ldr	w8, [x20, #0x4]
    999c:      	mov	w9, #0x2328             // =9000
    99a0:      	adrp	x1, 0x9000 <generic_kprobe_actions+0x830>
    99a4:      	mov	x0, x19
    99a8:      	ldr	x1, [x1]
    99ac:      	mov	w2, #-0x1               // =-1
    99b0:      	mov	x3, x20
    99b4:      	add	w8, w8, #0x90
    99b8:      	and	w8, w8, #0x7fff
    99bc:      	cmp	w8, w9
    99c0:      	csel	w4, w8, w9, lo
    99c4:      	mov	w8, #-0x1               // =-1
    99c8:      	mov	w9, #0x19               // =25
    99cc:      	blr	x9
    99d0:      	tbnz	x0, #0x3f, 0x9a14 <generic_kprobe_output+0x3f4>
    99d4:      	str	wzr, [sp, #0x28]
    99d8:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    99dc:      	mov	w8, #0x1                // =1
    99e0:      	add	x9, sp, #0x28
    99e4:      	ldr	x0, [x0]
    99e8:      	add	x1, sp, #0x28
    99ec:      	blr	x8
    99f0:      	cbz	x0, 0x9ab8 <generic_kprobe_output+0x498>
    99f4:      	add	x8, x0, #0x8
    99f8:      	nop
    99fc:      	nop
    9a00:      	ldaxr	x9, [x8]
    9a04:      	add	x9, x9, #0x1
    9a08:      	stlxr	w10, x9, [x8]
    9a0c:      	cbnz	w10, 0x9a00 <generic_kprobe_output+0x3e0>
    9a10:      	b	0x9ab8 <generic_kprobe_output+0x498>
    9a14:      	mov	x19, x0
    9a18:      	str	wzr, [sp, #0x28]
    9a1c:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9a20:      	mov	w8, #0x1                // =1
    9a24:      	ldr	x0, [x0]
    9a28:      	add	x9, sp, #0x28
    9a2c:      	add	x1, sp, #0x28
    9a30:      	blr	x8
    9a34:      	cbz	x0, 0x9ab8 <generic_kprobe_output+0x498>
    9a38:      	mov	x8, x19
    9a3c:      	cmn	x19, #0xc
    9a40:      	b.gt	0x9a64 <generic_kprobe_output+0x444>
    9a44:      	cmn	x8, #0x1c
    9a48:      	b.eq	0x9a84 <generic_kprobe_output+0x464>
    9a4c:      	cmn	x8, #0x16
    9a50:      	b.eq	0x9a9c <generic_kprobe_output+0x47c>
    9a54:      	cmn	x8, #0x10
    9a58:      	b.ne	0x9a94 <generic_kprobe_output+0x474>
    9a5c:      	add	x8, x0, #0x2f0
    9a60:      	b	0x9aa8 <generic_kprobe_output+0x488>
    9a64:      	cmn	x8, #0xb
    9a68:      	b.eq	0x9a8c <generic_kprobe_output+0x46c>
    9a6c:      	cmn	x8, #0x7
    9a70:      	b.eq	0x9aa4 <generic_kprobe_output+0x484>
    9a74:      	cmn	x8, #0x2
    9a78:      	b.ne	0x9a94 <generic_kprobe_output+0x474>
    9a7c:      	add	x8, x0, #0x2e0
    9a80:      	b	0x9aa8 <generic_kprobe_output+0x488>
    9a84:      	add	x8, x0, #0x300
    9a88:      	b	0x9aa8 <generic_kprobe_output+0x488>
    9a8c:      	add	x8, x0, #0x308
    9a90:      	b	0x9aa8 <generic_kprobe_output+0x488>
    9a94:      	add	x8, x0, #0x2d8
    9a98:      	b	0x9aa8 <generic_kprobe_output+0x488>
    9a9c:      	add	x8, x0, #0x2f8
    9aa0:      	b	0x9aa8 <generic_kprobe_output+0x488>
    9aa4:      	add	x8, x0, #0x2e8
    9aa8:      	ldaxr	x9, [x8]
    9aac:      	add	x9, x9, #0x1
    9ab0:      	stlxr	w10, x9, [x8]
    9ab4:      	cbnz	w10, 0x9aa8 <generic_kprobe_output+0x488>
    9ab8:      	ldp	x20, x19, [sp, #0xb0]
    9abc:      	mov	w0, wzr
    9ac0:      	ldr	x29, [sp, #0x70]
    9ac4:      	ldp	x22, x21, [sp, #0xa0]
    9ac8:      	ldp	x24, x23, [sp, #0x90]
    9acc:      	ldp	x30, x25, [sp, #0x80]
    9ad0:      	add	sp, sp, #0xc0
    9ad4:      	ret
    9ad8:      	nop
    9adc:      	nop

0000000000009ae0 <generic_kprobe_path>:
    9ae0:      	sub	sp, sp, #0xe0
    9ae4:      	str	x29, [sp, #0x90]
    9ae8:      	stp	x30, x25, [sp, #0xa0]
    9aec:      	stp	x24, x23, [sp, #0xb0]
    9af0:      	stp	x22, x21, [sp, #0xc0]
    9af4:      	stp	x20, x19, [sp, #0xd0]
    9af8:      	mov	x19, x0
    9afc:      	str	wzr, [sp, #0x28]
    9b00:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9b04:      	mov	w8, #0x1                // =1
    9b08:      	ldr	x0, [x0]
    9b0c:      	add	x9, sp, #0x28
    9b10:      	add	x1, sp, #0x28
    9b14:      	blr	x8
    9b18:      	cbz	x0, 0x1597c <generic_kprobe_path+0xbe9c>
    9b1c:      	mov	w8, #0x6420             // =25632
    9b20:      	add	x25, x0, x8
    9b24:      	ldr	w8, [x25]
    9b28:      	cmp	w8, #0x1
    9b2c:      	b.eq	0x9bd8 <generic_kprobe_path+0xf8>
    9b30:      	cbnz	w8, 0x1597c <generic_kprobe_path+0xbe9c>
    9b34:      	mov	x20, x0
    9b38:      	ldr	x22, [x0, #0x6440]
    9b3c:      	str	wzr, [sp, #0x70]
    9b40:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9b44:      	mov	w8, #0x1                // =1
    9b48:      	add	x9, sp, #0x70
    9b4c:      	ldr	x0, [x0]
    9b50:      	add	x1, sp, #0x70
    9b54:      	blr	x8
    9b58:      	cbz	x0, 0x1597c <generic_kprobe_path+0xbe9c>
    9b5c:      	str	x19, [sp, #0x20]
    9b60:      	add	x2, x22, #0x8
    9b64:      	mov	w8, #0x8                // =8
    9b68:      	mov	w9, #0x4                // =4
    9b6c:      	add	x10, sp, #0x80
    9b70:      	mov	x21, x0
    9b74:      	add	x29, x0, #0xfff
    9b78:      	add	x0, sp, #0x80
    9b7c:      	mov	w1, #0x8                // =8
    9b80:      	blr	x9
    9b84:      	adrp	x22, 0x9000 <generic_kprobe_actions+0x830>
    9b88:      	ldr	x22, [x22]
    9b8c:      	cbz	x0, 0x15608 <generic_kprobe_path+0xbb28>
    9b90:      	neg	w8, w0
    9b94:      	mov	w9, #0x1                // =1
    9b98:      	add	x1, sp, #0x30
    9b9c:      	strh	w8, [sp, #0x30]
    9ba0:      	mov	w8, #0x6                // =6
    9ba4:      	mov	x0, x22
    9ba8:      	mov	w23, #0x1               // =1
    9bac:      	strh	w8, [sp, #0x32]
    9bb0:      	mov	x8, #0x2c               // =44
    9bb4:      	movk	x8, #0x4, lsl #32
    9bb8:      	stur	x8, [sp, #0x34]
    9bbc:      	add	x8, sp, #0x30
    9bc0:      	blr	x9
    9bc4:      	cbz	x0, 0x155e4 <generic_kprobe_path+0xbb04>
    9bc8:      	ldr	w8, [x0]
    9bcc:      	add	w8, w8, #0x1
    9bd0:      	str	w8, [x0]
    9bd4:      	b	0x15608 <generic_kprobe_path+0xbb28>
    9bd8:      	ldr	x8, [x0, #0x6448]
    9bdc:      	ldr	x9, [x0, #0x6450]
    9be0:      	mov	x20, x0
    9be4:      	add	x1, sp, #0x2c
    9be8:      	str	xzr, [sp, #0x60]
    9bec:      	str	wzr, [sp, #0x68]
    9bf0:      	strb	wzr, [sp, #0x6c]
    9bf4:      	str	wzr, [sp, #0x2c]
    9bf8:      	stp	x8, x9, [sp, #0x30]
    9bfc:      	ldr	x8, [x0, #0x6458]
    9c00:      	ldr	x9, [x0, #0x6468]
    9c04:      	stp	xzr, x8, [sp, #0x40]
    9c08:      	ldr	x8, [x0, #0x6460]
    9c0c:      	adrp	x0, 0x9000 <generic_kprobe_actions+0x830>
    9c10:      	stp	x8, x9, [sp, #0x50]
    9c14:      	mov	w8, #0x1                // =1
    9c18:      	add	x9, sp, #0x2c
    9c1c:      	ldr	x0, [x0]
    9c20:      	blr	x8
    9c24:      	cbz	x0, 0x1597c <generic_kprobe_path+0xbe9c>
    9c28:      	str	x0, [sp, #0x40]
    9c2c:      	add	x10, sp, #0x30
    9c30:      	stp	x20, x19, [sp, #0x18]
    9c34:      	mov	w20, #0x200             // =512
    9c38:      	mov	w29, #0x8               // =8
    9c3c:      	ldr	w8, [x25, #0x4]
    9c40:      	add	x22, x10, #0x18
    9c44:      	add	x19, sp, #0x70
    9c48:      	and	x9, x8, #0xfff
    9c4c:      	str	x0, [sp, #0x10]
    9c50:      	str	w8, [sp, #0x68]
    9c54:      	add	x9, x0, x9
    9c58:      	str	x9, [sp, #0x60]
    9c5c:      	ldp	x21, x2, [sp, #0x48]
    9c60:      	ldp	x8, x9, [sp, #0x30]
    9c64:      	cmp	x21, x8
    9c68:      	ccmp	x2, x9, #0x0, eq
    9c6c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    9c70:      	ldr	x24, [sp, #0x58]
    9c74:      	mov	w8, #0x4                // =4
    9c78:      	add	x0, sp, #0x70
    9c7c:      	mov	w1, #0x8                // =8
    9c80:      	blr	x8
    9c84:      	ldr	x8, [sp, #0x70]
    9c88:      	cmp	x21, x8
    9c8c:      	b.eq	0x9d88 <generic_kprobe_path+0x2a8>
    9c90:      	add	x23, x21, #0x18
    9c94:      	mov	w8, #0x4                // =4
    9c98:      	add	x9, sp, #0x98
    9c9c:      	add	x0, sp, #0x98
    9ca0:      	mov	w1, #0x8                // =8
    9ca4:      	mov	x2, x23
    9ca8:      	blr	x8
    9cac:      	ldr	x8, [sp, #0x98]
    9cb0:      	cmp	x8, x21
    9cb4:      	b.eq	0x9d88 <generic_kprobe_path+0x2a8>
    9cb8:      	mov	w8, #0x4                // =4
    9cbc:      	add	x9, sp, #0x78
    9cc0:      	add	x0, sp, #0x78
    9cc4:      	mov	w1, #0x8                // =8
    9cc8:      	mov	x2, x23
    9ccc:      	blr	x8
    9cd0:      	add	x2, x21, #0x20
    9cd4:      	mov	w8, #0x4                // =4
    9cd8:      	mov	w9, #0x10               // =16
    9cdc:      	add	x10, sp, #0x80
    9ce0:      	add	x0, sp, #0x80
    9ce4:      	mov	w1, #0x10               // =16
    9ce8:      	blr	x8
    9cec:      	ldr	w21, [sp, #0x84]
    9cf0:      	ldr	x8, [sp, #0x40]
    9cf4:      	ldr	x10, [sp, #0x60]
    9cf8:      	sub	x12, x10, x8
    9cfc:      	ldr	w23, [sp, #0x68]
    9d00:      	subs	w10, w21, w23
    9d04:      	ldr	x9, [sp, #0x88]
    9d08:      	csel	w10, wzr, w10, lo
    9d0c:      	cmp	w23, w21
    9d10:      	csel	w11, w23, w21, lo
    9d14:      	cinc	w13, w11, hi
    9d18:      	sub	w14, w23, w13
    9d1c:      	subs	x12, x12, x13
    9d20:      	str	w14, [sp, #0x68]
    9d24:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    9d28:      	cmp	x12, #0xfff
    9d2c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    9d30:      	cmp	w23, w21
    9d34:      	b.ls	0x9d40 <generic_kprobe_path+0x260>
    9d38:      	mov	w13, #0x2f              // =47
    9d3c:      	strb	w13, [x8, x12]
    9d40:      	add	x19, x8, x12
    9d44:      	cmp	w23, w21
    9d48:      	add	x2, x9, x10
    9d4c:      	and	w1, w11, #0xff
    9d50:      	mov	w8, #0x4                // =4
    9d54:      	cinc	x0, x19, hi
    9d58:      	blr	x8
    9d5c:      	cmp	w23, w21
    9d60:      	str	x19, [sp, #0x60]
    9d64:      	add	x19, sp, #0x70
    9d68:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    9d6c:      	ldr	x21, [sp, #0x78]
    9d70:      	ldp	x2, x24, [sp, #0x50]
    9d74:      	str	x21, [sp, #0x48]
    9d78:      	ldr	x8, [sp, #0x30]
    9d7c:      	cmp	x21, x8
    9d80:      	b.eq	0x9de0 <generic_kprobe_path+0x300>
    9d84:      	b	0x9dec <generic_kprobe_path+0x30c>
    9d88:      	add	x2, x24, #0x10
    9d8c:      	mov	w8, #0x4                // =4
    9d90:      	add	x9, sp, #0x98
    9d94:      	add	x0, sp, #0x98
    9d98:      	mov	w1, #0x8                // =8
    9d9c:      	blr	x8
    9da0:      	ldr	x8, [sp, #0x58]
    9da4:      	ldr	x9, [sp, #0x98]
    9da8:      	cmp	x8, x9
    9dac:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    9db0:      	add	x2, x24, #0x18
    9db4:      	mov	w8, #0x4                // =4
    9db8:      	mov	x0, x22
    9dbc:      	mov	w1, #0x8                // =8
    9dc0:      	blr	x8
    9dc4:      	ldr	x24, [sp, #0x98]
    9dc8:      	ldr	x21, [sp, #0x48]
    9dcc:      	add	x2, x24, #0x20
    9dd0:      	stp	x2, x24, [sp, #0x50]
    9dd4:      	ldr	x8, [sp, #0x30]
    9dd8:      	cmp	x21, x8
    9ddc:      	b.ne	0x9dec <generic_kprobe_path+0x30c>
    9de0:      	ldr	x8, [sp, #0x38]
    9de4:      	cmp	x2, x8
    9de8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    9dec:      	mov	w8, #0x4                // =4
    9df0:      	add	x0, sp, #0x70
    9df4:      	mov	w1, #0x8                // =8
    9df8:      	blr	x8
    9dfc:      	ldr	x8, [sp, #0x70]
    9e00:      	cmp	x21, x8
    9e04:      	b.eq	0x9f00 <generic_kprobe_path+0x420>
    9e08:      	add	x23, x21, #0x18
    9e0c:      	mov	w8, #0x4                // =4
    9e10:      	add	x9, sp, #0x98
    9e14:      	add	x0, sp, #0x98
    9e18:      	mov	w1, #0x8                // =8
    9e1c:      	mov	x2, x23
    9e20:      	blr	x8
    9e24:      	ldr	x8, [sp, #0x98]
    9e28:      	cmp	x8, x21
    9e2c:      	b.eq	0x9f00 <generic_kprobe_path+0x420>
    9e30:      	mov	w8, #0x4                // =4
    9e34:      	add	x9, sp, #0x78
    9e38:      	add	x0, sp, #0x78
    9e3c:      	mov	w1, #0x8                // =8
    9e40:      	mov	x2, x23
    9e44:      	blr	x8
    9e48:      	add	x2, x21, #0x20
    9e4c:      	mov	w8, #0x4                // =4
    9e50:      	mov	w9, #0x10               // =16
    9e54:      	add	x10, sp, #0x80
    9e58:      	add	x0, sp, #0x80
    9e5c:      	mov	w1, #0x10               // =16
    9e60:      	blr	x8
    9e64:      	ldr	w21, [sp, #0x84]
    9e68:      	ldr	x8, [sp, #0x40]
    9e6c:      	ldr	x10, [sp, #0x60]
    9e70:      	sub	x12, x10, x8
    9e74:      	ldr	w23, [sp, #0x68]
    9e78:      	subs	w10, w21, w23
    9e7c:      	ldr	x9, [sp, #0x88]
    9e80:      	csel	w10, wzr, w10, lo
    9e84:      	cmp	w23, w21
    9e88:      	csel	w11, w23, w21, lo
    9e8c:      	cinc	w13, w11, hi
    9e90:      	sub	w14, w23, w13
    9e94:      	subs	x12, x12, x13
    9e98:      	str	w14, [sp, #0x68]
    9e9c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    9ea0:      	cmp	x12, #0xfff
    9ea4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    9ea8:      	cmp	w23, w21
    9eac:      	b.ls	0x9eb8 <generic_kprobe_path+0x3d8>
    9eb0:      	mov	w13, #0x2f              // =47
    9eb4:      	strb	w13, [x8, x12]
    9eb8:      	add	x19, x8, x12
    9ebc:      	cmp	w23, w21
    9ec0:      	add	x2, x9, x10
    9ec4:      	and	w1, w11, #0xff
    9ec8:      	mov	w8, #0x4                // =4
    9ecc:      	cinc	x0, x19, hi
    9ed0:      	blr	x8
    9ed4:      	cmp	w23, w21
    9ed8:      	str	x19, [sp, #0x60]
    9edc:      	add	x19, sp, #0x70
    9ee0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    9ee4:      	ldr	x21, [sp, #0x78]
    9ee8:      	ldp	x2, x24, [sp, #0x50]
    9eec:      	str	x21, [sp, #0x48]
    9ef0:      	ldr	x8, [sp, #0x30]
    9ef4:      	cmp	x21, x8
    9ef8:      	b.eq	0x9f58 <generic_kprobe_path+0x478>
    9efc:      	b	0x9f64 <generic_kprobe_path+0x484>
    9f00:      	add	x2, x24, #0x10
    9f04:      	mov	w8, #0x4                // =4
    9f08:      	add	x9, sp, #0x98
    9f0c:      	add	x0, sp, #0x98
    9f10:      	mov	w1, #0x8                // =8
    9f14:      	blr	x8
    9f18:      	ldr	x8, [sp, #0x58]
    9f1c:      	ldr	x9, [sp, #0x98]
    9f20:      	cmp	x8, x9
    9f24:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    9f28:      	add	x2, x24, #0x18
    9f2c:      	mov	w8, #0x4                // =4
    9f30:      	mov	x0, x22
    9f34:      	mov	w1, #0x8                // =8
    9f38:      	blr	x8
    9f3c:      	ldr	x24, [sp, #0x98]
    9f40:      	ldr	x21, [sp, #0x48]
    9f44:      	add	x2, x24, #0x20
    9f48:      	stp	x2, x24, [sp, #0x50]
    9f4c:      	ldr	x8, [sp, #0x30]
    9f50:      	cmp	x21, x8
    9f54:      	b.ne	0x9f64 <generic_kprobe_path+0x484>
    9f58:      	ldr	x8, [sp, #0x38]
    9f5c:      	cmp	x2, x8
    9f60:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    9f64:      	mov	w8, #0x4                // =4
    9f68:      	add	x0, sp, #0x70
    9f6c:      	mov	w1, #0x8                // =8
    9f70:      	blr	x8
    9f74:      	ldr	x8, [sp, #0x70]
    9f78:      	cmp	x21, x8
    9f7c:      	b.eq	0xa078 <generic_kprobe_path+0x598>
    9f80:      	add	x23, x21, #0x18
    9f84:      	mov	w8, #0x4                // =4
    9f88:      	add	x9, sp, #0x98
    9f8c:      	add	x0, sp, #0x98
    9f90:      	mov	w1, #0x8                // =8
    9f94:      	mov	x2, x23
    9f98:      	blr	x8
    9f9c:      	ldr	x8, [sp, #0x98]
    9fa0:      	cmp	x8, x21
    9fa4:      	b.eq	0xa078 <generic_kprobe_path+0x598>
    9fa8:      	mov	w8, #0x4                // =4
    9fac:      	add	x9, sp, #0x78
    9fb0:      	add	x0, sp, #0x78
    9fb4:      	mov	w1, #0x8                // =8
    9fb8:      	mov	x2, x23
    9fbc:      	blr	x8
    9fc0:      	add	x2, x21, #0x20
    9fc4:      	mov	w8, #0x4                // =4
    9fc8:      	mov	w9, #0x10               // =16
    9fcc:      	add	x10, sp, #0x80
    9fd0:      	add	x0, sp, #0x80
    9fd4:      	mov	w1, #0x10               // =16
    9fd8:      	blr	x8
    9fdc:      	ldr	w21, [sp, #0x84]
    9fe0:      	ldr	x8, [sp, #0x40]
    9fe4:      	ldr	x10, [sp, #0x60]
    9fe8:      	sub	x12, x10, x8
    9fec:      	ldr	w23, [sp, #0x68]
    9ff0:      	subs	w10, w21, w23
    9ff4:      	ldr	x9, [sp, #0x88]
    9ff8:      	csel	w10, wzr, w10, lo
    9ffc:      	cmp	w23, w21
    a000:      	csel	w11, w23, w21, lo
    a004:      	cinc	w13, w11, hi
    a008:      	sub	w14, w23, w13
    a00c:      	subs	x12, x12, x13
    a010:      	str	w14, [sp, #0x68]
    a014:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a018:      	cmp	x12, #0xfff
    a01c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a020:      	cmp	w23, w21
    a024:      	b.ls	0xa030 <generic_kprobe_path+0x550>
    a028:      	mov	w13, #0x2f              // =47
    a02c:      	strb	w13, [x8, x12]
    a030:      	add	x19, x8, x12
    a034:      	cmp	w23, w21
    a038:      	add	x2, x9, x10
    a03c:      	and	w1, w11, #0xff
    a040:      	mov	w8, #0x4                // =4
    a044:      	cinc	x0, x19, hi
    a048:      	blr	x8
    a04c:      	cmp	w23, w21
    a050:      	str	x19, [sp, #0x60]
    a054:      	add	x19, sp, #0x70
    a058:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a05c:      	ldr	x21, [sp, #0x78]
    a060:      	ldp	x2, x24, [sp, #0x50]
    a064:      	str	x21, [sp, #0x48]
    a068:      	ldr	x8, [sp, #0x30]
    a06c:      	cmp	x21, x8
    a070:      	b.eq	0xa0d0 <generic_kprobe_path+0x5f0>
    a074:      	b	0xa0dc <generic_kprobe_path+0x5fc>
    a078:      	add	x2, x24, #0x10
    a07c:      	mov	w8, #0x4                // =4
    a080:      	add	x9, sp, #0x98
    a084:      	add	x0, sp, #0x98
    a088:      	mov	w1, #0x8                // =8
    a08c:      	blr	x8
    a090:      	ldr	x8, [sp, #0x58]
    a094:      	ldr	x9, [sp, #0x98]
    a098:      	cmp	x8, x9
    a09c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a0a0:      	add	x2, x24, #0x18
    a0a4:      	mov	w8, #0x4                // =4
    a0a8:      	mov	x0, x22
    a0ac:      	mov	w1, #0x8                // =8
    a0b0:      	blr	x8
    a0b4:      	ldr	x24, [sp, #0x98]
    a0b8:      	ldr	x21, [sp, #0x48]
    a0bc:      	add	x2, x24, #0x20
    a0c0:      	stp	x2, x24, [sp, #0x50]
    a0c4:      	ldr	x8, [sp, #0x30]
    a0c8:      	cmp	x21, x8
    a0cc:      	b.ne	0xa0dc <generic_kprobe_path+0x5fc>
    a0d0:      	ldr	x8, [sp, #0x38]
    a0d4:      	cmp	x2, x8
    a0d8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a0dc:      	mov	w8, #0x4                // =4
    a0e0:      	add	x0, sp, #0x70
    a0e4:      	mov	w1, #0x8                // =8
    a0e8:      	blr	x8
    a0ec:      	ldr	x8, [sp, #0x70]
    a0f0:      	cmp	x21, x8
    a0f4:      	b.eq	0xa1f0 <generic_kprobe_path+0x710>
    a0f8:      	add	x23, x21, #0x18
    a0fc:      	mov	w8, #0x4                // =4
    a100:      	add	x9, sp, #0x98
    a104:      	add	x0, sp, #0x98
    a108:      	mov	w1, #0x8                // =8
    a10c:      	mov	x2, x23
    a110:      	blr	x8
    a114:      	ldr	x8, [sp, #0x98]
    a118:      	cmp	x8, x21
    a11c:      	b.eq	0xa1f0 <generic_kprobe_path+0x710>
    a120:      	mov	w8, #0x4                // =4
    a124:      	add	x9, sp, #0x78
    a128:      	add	x0, sp, #0x78
    a12c:      	mov	w1, #0x8                // =8
    a130:      	mov	x2, x23
    a134:      	blr	x8
    a138:      	add	x2, x21, #0x20
    a13c:      	mov	w8, #0x4                // =4
    a140:      	mov	w9, #0x10               // =16
    a144:      	add	x10, sp, #0x80
    a148:      	add	x0, sp, #0x80
    a14c:      	mov	w1, #0x10               // =16
    a150:      	blr	x8
    a154:      	ldr	w21, [sp, #0x84]
    a158:      	ldr	x8, [sp, #0x40]
    a15c:      	ldr	x10, [sp, #0x60]
    a160:      	sub	x12, x10, x8
    a164:      	ldr	w23, [sp, #0x68]
    a168:      	subs	w10, w21, w23
    a16c:      	ldr	x9, [sp, #0x88]
    a170:      	csel	w10, wzr, w10, lo
    a174:      	cmp	w23, w21
    a178:      	csel	w11, w23, w21, lo
    a17c:      	cinc	w13, w11, hi
    a180:      	sub	w14, w23, w13
    a184:      	subs	x12, x12, x13
    a188:      	str	w14, [sp, #0x68]
    a18c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a190:      	cmp	x12, #0xfff
    a194:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a198:      	cmp	w23, w21
    a19c:      	b.ls	0xa1a8 <generic_kprobe_path+0x6c8>
    a1a0:      	mov	w13, #0x2f              // =47
    a1a4:      	strb	w13, [x8, x12]
    a1a8:      	add	x19, x8, x12
    a1ac:      	cmp	w23, w21
    a1b0:      	add	x2, x9, x10
    a1b4:      	and	w1, w11, #0xff
    a1b8:      	mov	w8, #0x4                // =4
    a1bc:      	cinc	x0, x19, hi
    a1c0:      	blr	x8
    a1c4:      	cmp	w23, w21
    a1c8:      	str	x19, [sp, #0x60]
    a1cc:      	add	x19, sp, #0x70
    a1d0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a1d4:      	ldr	x21, [sp, #0x78]
    a1d8:      	ldp	x2, x24, [sp, #0x50]
    a1dc:      	str	x21, [sp, #0x48]
    a1e0:      	ldr	x8, [sp, #0x30]
    a1e4:      	cmp	x21, x8
    a1e8:      	b.eq	0xa248 <generic_kprobe_path+0x768>
    a1ec:      	b	0xa254 <generic_kprobe_path+0x774>
    a1f0:      	add	x2, x24, #0x10
    a1f4:      	mov	w8, #0x4                // =4
    a1f8:      	add	x9, sp, #0x98
    a1fc:      	add	x0, sp, #0x98
    a200:      	mov	w1, #0x8                // =8
    a204:      	blr	x8
    a208:      	ldr	x8, [sp, #0x58]
    a20c:      	ldr	x9, [sp, #0x98]
    a210:      	cmp	x8, x9
    a214:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a218:      	add	x2, x24, #0x18
    a21c:      	mov	w8, #0x4                // =4
    a220:      	mov	x0, x22
    a224:      	mov	w1, #0x8                // =8
    a228:      	blr	x8
    a22c:      	ldr	x24, [sp, #0x98]
    a230:      	ldr	x21, [sp, #0x48]
    a234:      	add	x2, x24, #0x20
    a238:      	stp	x2, x24, [sp, #0x50]
    a23c:      	ldr	x8, [sp, #0x30]
    a240:      	cmp	x21, x8
    a244:      	b.ne	0xa254 <generic_kprobe_path+0x774>
    a248:      	ldr	x8, [sp, #0x38]
    a24c:      	cmp	x2, x8
    a250:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a254:      	mov	w8, #0x4                // =4
    a258:      	add	x0, sp, #0x70
    a25c:      	mov	w1, #0x8                // =8
    a260:      	blr	x8
    a264:      	ldr	x8, [sp, #0x70]
    a268:      	cmp	x21, x8
    a26c:      	b.eq	0xa368 <generic_kprobe_path+0x888>
    a270:      	add	x23, x21, #0x18
    a274:      	mov	w8, #0x4                // =4
    a278:      	add	x9, sp, #0x98
    a27c:      	add	x0, sp, #0x98
    a280:      	mov	w1, #0x8                // =8
    a284:      	mov	x2, x23
    a288:      	blr	x8
    a28c:      	ldr	x8, [sp, #0x98]
    a290:      	cmp	x8, x21
    a294:      	b.eq	0xa368 <generic_kprobe_path+0x888>
    a298:      	mov	w8, #0x4                // =4
    a29c:      	add	x9, sp, #0x78
    a2a0:      	add	x0, sp, #0x78
    a2a4:      	mov	w1, #0x8                // =8
    a2a8:      	mov	x2, x23
    a2ac:      	blr	x8
    a2b0:      	add	x2, x21, #0x20
    a2b4:      	mov	w8, #0x4                // =4
    a2b8:      	mov	w9, #0x10               // =16
    a2bc:      	add	x10, sp, #0x80
    a2c0:      	add	x0, sp, #0x80
    a2c4:      	mov	w1, #0x10               // =16
    a2c8:      	blr	x8
    a2cc:      	ldr	w21, [sp, #0x84]
    a2d0:      	ldr	x8, [sp, #0x40]
    a2d4:      	ldr	x10, [sp, #0x60]
    a2d8:      	sub	x12, x10, x8
    a2dc:      	ldr	w23, [sp, #0x68]
    a2e0:      	subs	w10, w21, w23
    a2e4:      	ldr	x9, [sp, #0x88]
    a2e8:      	csel	w10, wzr, w10, lo
    a2ec:      	cmp	w23, w21
    a2f0:      	csel	w11, w23, w21, lo
    a2f4:      	cinc	w13, w11, hi
    a2f8:      	sub	w14, w23, w13
    a2fc:      	subs	x12, x12, x13
    a300:      	str	w14, [sp, #0x68]
    a304:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a308:      	cmp	x12, #0xfff
    a30c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a310:      	cmp	w23, w21
    a314:      	b.ls	0xa320 <generic_kprobe_path+0x840>
    a318:      	mov	w13, #0x2f              // =47
    a31c:      	strb	w13, [x8, x12]
    a320:      	add	x19, x8, x12
    a324:      	cmp	w23, w21
    a328:      	add	x2, x9, x10
    a32c:      	and	w1, w11, #0xff
    a330:      	mov	w8, #0x4                // =4
    a334:      	cinc	x0, x19, hi
    a338:      	blr	x8
    a33c:      	cmp	w23, w21
    a340:      	str	x19, [sp, #0x60]
    a344:      	add	x19, sp, #0x70
    a348:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a34c:      	ldr	x21, [sp, #0x78]
    a350:      	ldp	x2, x24, [sp, #0x50]
    a354:      	str	x21, [sp, #0x48]
    a358:      	ldr	x8, [sp, #0x30]
    a35c:      	cmp	x21, x8
    a360:      	b.eq	0xa3c0 <generic_kprobe_path+0x8e0>
    a364:      	b	0xa3cc <generic_kprobe_path+0x8ec>
    a368:      	add	x2, x24, #0x10
    a36c:      	mov	w8, #0x4                // =4
    a370:      	add	x9, sp, #0x98
    a374:      	add	x0, sp, #0x98
    a378:      	mov	w1, #0x8                // =8
    a37c:      	blr	x8
    a380:      	ldr	x8, [sp, #0x58]
    a384:      	ldr	x9, [sp, #0x98]
    a388:      	cmp	x8, x9
    a38c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a390:      	add	x2, x24, #0x18
    a394:      	mov	w8, #0x4                // =4
    a398:      	mov	x0, x22
    a39c:      	mov	w1, #0x8                // =8
    a3a0:      	blr	x8
    a3a4:      	ldr	x24, [sp, #0x98]
    a3a8:      	ldr	x21, [sp, #0x48]
    a3ac:      	add	x2, x24, #0x20
    a3b0:      	stp	x2, x24, [sp, #0x50]
    a3b4:      	ldr	x8, [sp, #0x30]
    a3b8:      	cmp	x21, x8
    a3bc:      	b.ne	0xa3cc <generic_kprobe_path+0x8ec>
    a3c0:      	ldr	x8, [sp, #0x38]
    a3c4:      	cmp	x2, x8
    a3c8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a3cc:      	mov	w8, #0x4                // =4
    a3d0:      	add	x0, sp, #0x70
    a3d4:      	mov	w1, #0x8                // =8
    a3d8:      	blr	x8
    a3dc:      	ldr	x8, [sp, #0x70]
    a3e0:      	cmp	x21, x8
    a3e4:      	b.eq	0xa4e0 <generic_kprobe_path+0xa00>
    a3e8:      	add	x23, x21, #0x18
    a3ec:      	mov	w8, #0x4                // =4
    a3f0:      	add	x9, sp, #0x98
    a3f4:      	add	x0, sp, #0x98
    a3f8:      	mov	w1, #0x8                // =8
    a3fc:      	mov	x2, x23
    a400:      	blr	x8
    a404:      	ldr	x8, [sp, #0x98]
    a408:      	cmp	x8, x21
    a40c:      	b.eq	0xa4e0 <generic_kprobe_path+0xa00>
    a410:      	mov	w8, #0x4                // =4
    a414:      	add	x9, sp, #0x78
    a418:      	add	x0, sp, #0x78
    a41c:      	mov	w1, #0x8                // =8
    a420:      	mov	x2, x23
    a424:      	blr	x8
    a428:      	add	x2, x21, #0x20
    a42c:      	mov	w8, #0x4                // =4
    a430:      	mov	w9, #0x10               // =16
    a434:      	add	x10, sp, #0x80
    a438:      	add	x0, sp, #0x80
    a43c:      	mov	w1, #0x10               // =16
    a440:      	blr	x8
    a444:      	ldr	w21, [sp, #0x84]
    a448:      	ldr	x8, [sp, #0x40]
    a44c:      	ldr	x10, [sp, #0x60]
    a450:      	sub	x12, x10, x8
    a454:      	ldr	w23, [sp, #0x68]
    a458:      	subs	w10, w21, w23
    a45c:      	ldr	x9, [sp, #0x88]
    a460:      	csel	w10, wzr, w10, lo
    a464:      	cmp	w23, w21
    a468:      	csel	w11, w23, w21, lo
    a46c:      	cinc	w13, w11, hi
    a470:      	sub	w14, w23, w13
    a474:      	subs	x12, x12, x13
    a478:      	str	w14, [sp, #0x68]
    a47c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a480:      	cmp	x12, #0xfff
    a484:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a488:      	cmp	w23, w21
    a48c:      	b.ls	0xa498 <generic_kprobe_path+0x9b8>
    a490:      	mov	w13, #0x2f              // =47
    a494:      	strb	w13, [x8, x12]
    a498:      	add	x19, x8, x12
    a49c:      	cmp	w23, w21
    a4a0:      	add	x2, x9, x10
    a4a4:      	and	w1, w11, #0xff
    a4a8:      	mov	w8, #0x4                // =4
    a4ac:      	cinc	x0, x19, hi
    a4b0:      	blr	x8
    a4b4:      	cmp	w23, w21
    a4b8:      	str	x19, [sp, #0x60]
    a4bc:      	add	x19, sp, #0x70
    a4c0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a4c4:      	ldr	x21, [sp, #0x78]
    a4c8:      	ldp	x2, x24, [sp, #0x50]
    a4cc:      	str	x21, [sp, #0x48]
    a4d0:      	ldr	x8, [sp, #0x30]
    a4d4:      	cmp	x21, x8
    a4d8:      	b.eq	0xa538 <generic_kprobe_path+0xa58>
    a4dc:      	b	0xa544 <generic_kprobe_path+0xa64>
    a4e0:      	add	x2, x24, #0x10
    a4e4:      	mov	w8, #0x4                // =4
    a4e8:      	add	x9, sp, #0x98
    a4ec:      	add	x0, sp, #0x98
    a4f0:      	mov	w1, #0x8                // =8
    a4f4:      	blr	x8
    a4f8:      	ldr	x8, [sp, #0x58]
    a4fc:      	ldr	x9, [sp, #0x98]
    a500:      	cmp	x8, x9
    a504:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a508:      	add	x2, x24, #0x18
    a50c:      	mov	w8, #0x4                // =4
    a510:      	mov	x0, x22
    a514:      	mov	w1, #0x8                // =8
    a518:      	blr	x8
    a51c:      	ldr	x24, [sp, #0x98]
    a520:      	ldr	x21, [sp, #0x48]
    a524:      	add	x2, x24, #0x20
    a528:      	stp	x2, x24, [sp, #0x50]
    a52c:      	ldr	x8, [sp, #0x30]
    a530:      	cmp	x21, x8
    a534:      	b.ne	0xa544 <generic_kprobe_path+0xa64>
    a538:      	ldr	x8, [sp, #0x38]
    a53c:      	cmp	x2, x8
    a540:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a544:      	mov	w8, #0x4                // =4
    a548:      	add	x0, sp, #0x70
    a54c:      	mov	w1, #0x8                // =8
    a550:      	blr	x8
    a554:      	ldr	x8, [sp, #0x70]
    a558:      	cmp	x21, x8
    a55c:      	b.eq	0xa658 <generic_kprobe_path+0xb78>
    a560:      	add	x23, x21, #0x18
    a564:      	mov	w8, #0x4                // =4
    a568:      	add	x9, sp, #0x98
    a56c:      	add	x0, sp, #0x98
    a570:      	mov	w1, #0x8                // =8
    a574:      	mov	x2, x23
    a578:      	blr	x8
    a57c:      	ldr	x8, [sp, #0x98]
    a580:      	cmp	x8, x21
    a584:      	b.eq	0xa658 <generic_kprobe_path+0xb78>
    a588:      	mov	w8, #0x4                // =4
    a58c:      	add	x9, sp, #0x78
    a590:      	add	x0, sp, #0x78
    a594:      	mov	w1, #0x8                // =8
    a598:      	mov	x2, x23
    a59c:      	blr	x8
    a5a0:      	add	x2, x21, #0x20
    a5a4:      	mov	w8, #0x4                // =4
    a5a8:      	mov	w9, #0x10               // =16
    a5ac:      	add	x10, sp, #0x80
    a5b0:      	add	x0, sp, #0x80
    a5b4:      	mov	w1, #0x10               // =16
    a5b8:      	blr	x8
    a5bc:      	ldr	w21, [sp, #0x84]
    a5c0:      	ldr	x8, [sp, #0x40]
    a5c4:      	ldr	x10, [sp, #0x60]
    a5c8:      	sub	x12, x10, x8
    a5cc:      	ldr	w23, [sp, #0x68]
    a5d0:      	subs	w10, w21, w23
    a5d4:      	ldr	x9, [sp, #0x88]
    a5d8:      	csel	w10, wzr, w10, lo
    a5dc:      	cmp	w23, w21
    a5e0:      	csel	w11, w23, w21, lo
    a5e4:      	cinc	w13, w11, hi
    a5e8:      	sub	w14, w23, w13
    a5ec:      	subs	x12, x12, x13
    a5f0:      	str	w14, [sp, #0x68]
    a5f4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a5f8:      	cmp	x12, #0xfff
    a5fc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a600:      	cmp	w23, w21
    a604:      	b.ls	0xa610 <generic_kprobe_path+0xb30>
    a608:      	mov	w13, #0x2f              // =47
    a60c:      	strb	w13, [x8, x12]
    a610:      	add	x19, x8, x12
    a614:      	cmp	w23, w21
    a618:      	add	x2, x9, x10
    a61c:      	and	w1, w11, #0xff
    a620:      	mov	w8, #0x4                // =4
    a624:      	cinc	x0, x19, hi
    a628:      	blr	x8
    a62c:      	cmp	w23, w21
    a630:      	str	x19, [sp, #0x60]
    a634:      	add	x19, sp, #0x70
    a638:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a63c:      	ldr	x21, [sp, #0x78]
    a640:      	ldp	x2, x24, [sp, #0x50]
    a644:      	str	x21, [sp, #0x48]
    a648:      	ldr	x8, [sp, #0x30]
    a64c:      	cmp	x21, x8
    a650:      	b.eq	0xa6b0 <generic_kprobe_path+0xbd0>
    a654:      	b	0xa6bc <generic_kprobe_path+0xbdc>
    a658:      	add	x2, x24, #0x10
    a65c:      	mov	w8, #0x4                // =4
    a660:      	add	x9, sp, #0x98
    a664:      	add	x0, sp, #0x98
    a668:      	mov	w1, #0x8                // =8
    a66c:      	blr	x8
    a670:      	ldr	x8, [sp, #0x58]
    a674:      	ldr	x9, [sp, #0x98]
    a678:      	cmp	x8, x9
    a67c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a680:      	add	x2, x24, #0x18
    a684:      	mov	w8, #0x4                // =4
    a688:      	mov	x0, x22
    a68c:      	mov	w1, #0x8                // =8
    a690:      	blr	x8
    a694:      	ldr	x24, [sp, #0x98]
    a698:      	ldr	x21, [sp, #0x48]
    a69c:      	add	x2, x24, #0x20
    a6a0:      	stp	x2, x24, [sp, #0x50]
    a6a4:      	ldr	x8, [sp, #0x30]
    a6a8:      	cmp	x21, x8
    a6ac:      	b.ne	0xa6bc <generic_kprobe_path+0xbdc>
    a6b0:      	ldr	x8, [sp, #0x38]
    a6b4:      	cmp	x2, x8
    a6b8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a6bc:      	mov	w8, #0x4                // =4
    a6c0:      	add	x0, sp, #0x70
    a6c4:      	mov	w1, #0x8                // =8
    a6c8:      	blr	x8
    a6cc:      	ldr	x8, [sp, #0x70]
    a6d0:      	cmp	x21, x8
    a6d4:      	b.eq	0xa7d0 <generic_kprobe_path+0xcf0>
    a6d8:      	add	x23, x21, #0x18
    a6dc:      	mov	w8, #0x4                // =4
    a6e0:      	add	x9, sp, #0x98
    a6e4:      	add	x0, sp, #0x98
    a6e8:      	mov	w1, #0x8                // =8
    a6ec:      	mov	x2, x23
    a6f0:      	blr	x8
    a6f4:      	ldr	x8, [sp, #0x98]
    a6f8:      	cmp	x8, x21
    a6fc:      	b.eq	0xa7d0 <generic_kprobe_path+0xcf0>
    a700:      	mov	w8, #0x4                // =4
    a704:      	add	x9, sp, #0x78
    a708:      	add	x0, sp, #0x78
    a70c:      	mov	w1, #0x8                // =8
    a710:      	mov	x2, x23
    a714:      	blr	x8
    a718:      	add	x2, x21, #0x20
    a71c:      	mov	w8, #0x4                // =4
    a720:      	mov	w9, #0x10               // =16
    a724:      	add	x10, sp, #0x80
    a728:      	add	x0, sp, #0x80
    a72c:      	mov	w1, #0x10               // =16
    a730:      	blr	x8
    a734:      	ldr	w21, [sp, #0x84]
    a738:      	ldr	x8, [sp, #0x40]
    a73c:      	ldr	x10, [sp, #0x60]
    a740:      	sub	x12, x10, x8
    a744:      	ldr	w23, [sp, #0x68]
    a748:      	subs	w10, w21, w23
    a74c:      	ldr	x9, [sp, #0x88]
    a750:      	csel	w10, wzr, w10, lo
    a754:      	cmp	w23, w21
    a758:      	csel	w11, w23, w21, lo
    a75c:      	cinc	w13, w11, hi
    a760:      	sub	w14, w23, w13
    a764:      	subs	x12, x12, x13
    a768:      	str	w14, [sp, #0x68]
    a76c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a770:      	cmp	x12, #0xfff
    a774:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a778:      	cmp	w23, w21
    a77c:      	b.ls	0xa788 <generic_kprobe_path+0xca8>
    a780:      	mov	w13, #0x2f              // =47
    a784:      	strb	w13, [x8, x12]
    a788:      	add	x19, x8, x12
    a78c:      	cmp	w23, w21
    a790:      	add	x2, x9, x10
    a794:      	and	w1, w11, #0xff
    a798:      	mov	w8, #0x4                // =4
    a79c:      	cinc	x0, x19, hi
    a7a0:      	blr	x8
    a7a4:      	cmp	w23, w21
    a7a8:      	str	x19, [sp, #0x60]
    a7ac:      	add	x19, sp, #0x70
    a7b0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a7b4:      	ldr	x21, [sp, #0x78]
    a7b8:      	ldp	x2, x24, [sp, #0x50]
    a7bc:      	str	x21, [sp, #0x48]
    a7c0:      	ldr	x8, [sp, #0x30]
    a7c4:      	cmp	x21, x8
    a7c8:      	b.eq	0xa828 <generic_kprobe_path+0xd48>
    a7cc:      	b	0xa834 <generic_kprobe_path+0xd54>
    a7d0:      	add	x2, x24, #0x10
    a7d4:      	mov	w8, #0x4                // =4
    a7d8:      	add	x9, sp, #0x98
    a7dc:      	add	x0, sp, #0x98
    a7e0:      	mov	w1, #0x8                // =8
    a7e4:      	blr	x8
    a7e8:      	ldr	x8, [sp, #0x58]
    a7ec:      	ldr	x9, [sp, #0x98]
    a7f0:      	cmp	x8, x9
    a7f4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a7f8:      	add	x2, x24, #0x18
    a7fc:      	mov	w8, #0x4                // =4
    a800:      	mov	x0, x22
    a804:      	mov	w1, #0x8                // =8
    a808:      	blr	x8
    a80c:      	ldr	x24, [sp, #0x98]
    a810:      	ldr	x21, [sp, #0x48]
    a814:      	add	x2, x24, #0x20
    a818:      	stp	x2, x24, [sp, #0x50]
    a81c:      	ldr	x8, [sp, #0x30]
    a820:      	cmp	x21, x8
    a824:      	b.ne	0xa834 <generic_kprobe_path+0xd54>
    a828:      	ldr	x8, [sp, #0x38]
    a82c:      	cmp	x2, x8
    a830:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a834:      	mov	w8, #0x4                // =4
    a838:      	add	x0, sp, #0x70
    a83c:      	mov	w1, #0x8                // =8
    a840:      	blr	x8
    a844:      	ldr	x8, [sp, #0x70]
    a848:      	cmp	x21, x8
    a84c:      	b.eq	0xa948 <generic_kprobe_path+0xe68>
    a850:      	add	x23, x21, #0x18
    a854:      	mov	w8, #0x4                // =4
    a858:      	add	x9, sp, #0x98
    a85c:      	add	x0, sp, #0x98
    a860:      	mov	w1, #0x8                // =8
    a864:      	mov	x2, x23
    a868:      	blr	x8
    a86c:      	ldr	x8, [sp, #0x98]
    a870:      	cmp	x8, x21
    a874:      	b.eq	0xa948 <generic_kprobe_path+0xe68>
    a878:      	mov	w8, #0x4                // =4
    a87c:      	add	x9, sp, #0x78
    a880:      	add	x0, sp, #0x78
    a884:      	mov	w1, #0x8                // =8
    a888:      	mov	x2, x23
    a88c:      	blr	x8
    a890:      	add	x2, x21, #0x20
    a894:      	mov	w8, #0x4                // =4
    a898:      	mov	w9, #0x10               // =16
    a89c:      	add	x10, sp, #0x80
    a8a0:      	add	x0, sp, #0x80
    a8a4:      	mov	w1, #0x10               // =16
    a8a8:      	blr	x8
    a8ac:      	ldr	w21, [sp, #0x84]
    a8b0:      	ldr	x8, [sp, #0x40]
    a8b4:      	ldr	x10, [sp, #0x60]
    a8b8:      	sub	x12, x10, x8
    a8bc:      	ldr	w23, [sp, #0x68]
    a8c0:      	subs	w10, w21, w23
    a8c4:      	ldr	x9, [sp, #0x88]
    a8c8:      	csel	w10, wzr, w10, lo
    a8cc:      	cmp	w23, w21
    a8d0:      	csel	w11, w23, w21, lo
    a8d4:      	cinc	w13, w11, hi
    a8d8:      	sub	w14, w23, w13
    a8dc:      	subs	x12, x12, x13
    a8e0:      	str	w14, [sp, #0x68]
    a8e4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    a8e8:      	cmp	x12, #0xfff
    a8ec:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    a8f0:      	cmp	w23, w21
    a8f4:      	b.ls	0xa900 <generic_kprobe_path+0xe20>
    a8f8:      	mov	w13, #0x2f              // =47
    a8fc:      	strb	w13, [x8, x12]
    a900:      	add	x19, x8, x12
    a904:      	cmp	w23, w21
    a908:      	add	x2, x9, x10
    a90c:      	and	w1, w11, #0xff
    a910:      	mov	w8, #0x4                // =4
    a914:      	cinc	x0, x19, hi
    a918:      	blr	x8
    a91c:      	cmp	w23, w21
    a920:      	str	x19, [sp, #0x60]
    a924:      	add	x19, sp, #0x70
    a928:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    a92c:      	ldr	x21, [sp, #0x78]
    a930:      	ldp	x2, x24, [sp, #0x50]
    a934:      	str	x21, [sp, #0x48]
    a938:      	ldr	x8, [sp, #0x30]
    a93c:      	cmp	x21, x8
    a940:      	b.eq	0xa9a0 <generic_kprobe_path+0xec0>
    a944:      	b	0xa9ac <generic_kprobe_path+0xecc>
    a948:      	add	x2, x24, #0x10
    a94c:      	mov	w8, #0x4                // =4
    a950:      	add	x9, sp, #0x98
    a954:      	add	x0, sp, #0x98
    a958:      	mov	w1, #0x8                // =8
    a95c:      	blr	x8
    a960:      	ldr	x8, [sp, #0x58]
    a964:      	ldr	x9, [sp, #0x98]
    a968:      	cmp	x8, x9
    a96c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a970:      	add	x2, x24, #0x18
    a974:      	mov	w8, #0x4                // =4
    a978:      	mov	x0, x22
    a97c:      	mov	w1, #0x8                // =8
    a980:      	blr	x8
    a984:      	ldr	x24, [sp, #0x98]
    a988:      	ldr	x21, [sp, #0x48]
    a98c:      	add	x2, x24, #0x20
    a990:      	stp	x2, x24, [sp, #0x50]
    a994:      	ldr	x8, [sp, #0x30]
    a998:      	cmp	x21, x8
    a99c:      	b.ne	0xa9ac <generic_kprobe_path+0xecc>
    a9a0:      	ldr	x8, [sp, #0x38]
    a9a4:      	cmp	x2, x8
    a9a8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    a9ac:      	mov	w8, #0x4                // =4
    a9b0:      	add	x0, sp, #0x70
    a9b4:      	mov	w1, #0x8                // =8
    a9b8:      	blr	x8
    a9bc:      	ldr	x8, [sp, #0x70]
    a9c0:      	cmp	x21, x8
    a9c4:      	b.eq	0xaab4 <generic_kprobe_path+0xfd4>
    a9c8:      	add	x23, x21, #0x18
    a9cc:      	mov	w8, #0x4                // =4
    a9d0:      	add	x9, sp, #0x98
    a9d4:      	add	x0, sp, #0x98
    a9d8:      	mov	w1, #0x8                // =8
    a9dc:      	mov	x2, x23
    a9e0:      	blr	x8
    a9e4:      	ldr	x8, [sp, #0x98]
    a9e8:      	cmp	x8, x21
    a9ec:      	b.eq	0xaab4 <generic_kprobe_path+0xfd4>
    a9f0:      	mov	w8, #0x4                // =4
    a9f4:      	add	x9, sp, #0x78
    a9f8:      	add	x0, sp, #0x78
    a9fc:      	mov	w1, #0x8                // =8
    aa00:      	mov	x2, x23
    aa04:      	blr	x8
    aa08:      	add	x2, x21, #0x20
    aa0c:      	mov	w8, #0x4                // =4
    aa10:      	mov	w9, #0x10               // =16
    aa14:      	add	x10, sp, #0x80
    aa18:      	add	x0, sp, #0x80
    aa1c:      	mov	w1, #0x10               // =16
    aa20:      	blr	x8
    aa24:      	ldr	w21, [sp, #0x84]
    aa28:      	ldr	x8, [sp, #0x40]
    aa2c:      	ldr	x10, [sp, #0x60]
    aa30:      	sub	x12, x10, x8
    aa34:      	ldr	w23, [sp, #0x68]
    aa38:      	subs	w10, w21, w23
    aa3c:      	ldr	x9, [sp, #0x88]
    aa40:      	csel	w10, wzr, w10, lo
    aa44:      	cmp	w23, w21
    aa48:      	csel	w11, w23, w21, lo
    aa4c:      	cinc	w13, w11, hi
    aa50:      	sub	w14, w23, w13
    aa54:      	subs	x12, x12, x13
    aa58:      	str	w14, [sp, #0x68]
    aa5c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    aa60:      	cmp	x12, #0xfff
    aa64:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    aa68:      	cmp	w23, w21
    aa6c:      	b.ls	0xaa78 <generic_kprobe_path+0xf98>
    aa70:      	mov	w13, #0x2f              // =47
    aa74:      	strb	w13, [x8, x12]
    aa78:      	add	x19, x8, x12
    aa7c:      	cmp	w23, w21
    aa80:      	add	x2, x9, x10
    aa84:      	and	w1, w11, #0xff
    aa88:      	mov	w8, #0x4                // =4
    aa8c:      	cinc	x0, x19, hi
    aa90:      	blr	x8
    aa94:      	cmp	w23, w21
    aa98:      	str	x19, [sp, #0x60]
    aa9c:      	add	x19, sp, #0x70
    aaa0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    aaa4:      	ldr	x21, [sp, #0x78]
    aaa8:      	ldp	x2, x24, [sp, #0x50]
    aaac:      	str	x21, [sp, #0x48]
    aab0:      	b	0xab00 <generic_kprobe_path+0x1020>
    aab4:      	add	x2, x24, #0x10
    aab8:      	mov	w8, #0x4                // =4
    aabc:      	add	x9, sp, #0x98
    aac0:      	add	x0, sp, #0x98
    aac4:      	mov	w1, #0x8                // =8
    aac8:      	blr	x8
    aacc:      	ldr	x8, [sp, #0x58]
    aad0:      	ldr	x9, [sp, #0x98]
    aad4:      	cmp	x8, x9
    aad8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    aadc:      	add	x2, x24, #0x18
    aae0:      	mov	w8, #0x4                // =4
    aae4:      	mov	x0, x22
    aae8:      	mov	w1, #0x8                // =8
    aaec:      	blr	x8
    aaf0:      	ldr	x24, [sp, #0x98]
    aaf4:      	ldr	x21, [sp, #0x48]
    aaf8:      	add	x2, x24, #0x20
    aafc:      	stp	x2, x24, [sp, #0x50]
    ab00:      	ldr	x8, [sp, #0x30]
    ab04:      	cmp	x21, x8
    ab08:      	b.ne	0xab18 <generic_kprobe_path+0x1038>
    ab0c:      	ldr	x8, [sp, #0x38]
    ab10:      	cmp	x2, x8
    ab14:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ab18:      	mov	w8, #0x4                // =4
    ab1c:      	add	x0, sp, #0x70
    ab20:      	mov	w1, #0x8                // =8
    ab24:      	blr	x8
    ab28:      	ldr	x8, [sp, #0x70]
    ab2c:      	cmp	x21, x8
    ab30:      	b.eq	0xac20 <generic_kprobe_path+0x1140>
    ab34:      	add	x23, x21, #0x18
    ab38:      	mov	w8, #0x4                // =4
    ab3c:      	add	x9, sp, #0x98
    ab40:      	add	x0, sp, #0x98
    ab44:      	mov	w1, #0x8                // =8
    ab48:      	mov	x2, x23
    ab4c:      	blr	x8
    ab50:      	ldr	x8, [sp, #0x98]
    ab54:      	cmp	x8, x21
    ab58:      	b.eq	0xac20 <generic_kprobe_path+0x1140>
    ab5c:      	mov	w8, #0x4                // =4
    ab60:      	add	x9, sp, #0x78
    ab64:      	add	x0, sp, #0x78
    ab68:      	mov	w1, #0x8                // =8
    ab6c:      	mov	x2, x23
    ab70:      	blr	x8
    ab74:      	add	x2, x21, #0x20
    ab78:      	mov	w8, #0x4                // =4
    ab7c:      	mov	w9, #0x10               // =16
    ab80:      	add	x10, sp, #0x80
    ab84:      	add	x0, sp, #0x80
    ab88:      	mov	w1, #0x10               // =16
    ab8c:      	blr	x8
    ab90:      	ldr	w21, [sp, #0x84]
    ab94:      	ldr	x8, [sp, #0x40]
    ab98:      	ldr	x10, [sp, #0x60]
    ab9c:      	sub	x12, x10, x8
    aba0:      	ldr	w23, [sp, #0x68]
    aba4:      	subs	w10, w21, w23
    aba8:      	ldr	x9, [sp, #0x88]
    abac:      	csel	w10, wzr, w10, lo
    abb0:      	cmp	w23, w21
    abb4:      	csel	w11, w23, w21, lo
    abb8:      	cinc	w13, w11, hi
    abbc:      	sub	w14, w23, w13
    abc0:      	subs	x12, x12, x13
    abc4:      	str	w14, [sp, #0x68]
    abc8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    abcc:      	cmp	x12, #0xfff
    abd0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    abd4:      	cmp	w23, w21
    abd8:      	b.ls	0xabe4 <generic_kprobe_path+0x1104>
    abdc:      	mov	w13, #0x2f              // =47
    abe0:      	strb	w13, [x8, x12]
    abe4:      	add	x19, x8, x12
    abe8:      	cmp	w23, w21
    abec:      	add	x2, x9, x10
    abf0:      	and	w1, w11, #0xff
    abf4:      	mov	w8, #0x4                // =4
    abf8:      	cinc	x0, x19, hi
    abfc:      	blr	x8
    ac00:      	cmp	w23, w21
    ac04:      	str	x19, [sp, #0x60]
    ac08:      	add	x19, sp, #0x70
    ac0c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ac10:      	ldr	x21, [sp, #0x78]
    ac14:      	ldp	x2, x24, [sp, #0x50]
    ac18:      	str	x21, [sp, #0x48]
    ac1c:      	b	0xac6c <generic_kprobe_path+0x118c>
    ac20:      	add	x2, x24, #0x10
    ac24:      	mov	w8, #0x4                // =4
    ac28:      	add	x9, sp, #0x98
    ac2c:      	add	x0, sp, #0x98
    ac30:      	mov	w1, #0x8                // =8
    ac34:      	blr	x8
    ac38:      	ldr	x8, [sp, #0x58]
    ac3c:      	ldr	x9, [sp, #0x98]
    ac40:      	cmp	x8, x9
    ac44:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ac48:      	add	x2, x24, #0x18
    ac4c:      	mov	w8, #0x4                // =4
    ac50:      	mov	x0, x22
    ac54:      	mov	w1, #0x8                // =8
    ac58:      	blr	x8
    ac5c:      	ldr	x24, [sp, #0x98]
    ac60:      	ldr	x21, [sp, #0x48]
    ac64:      	add	x2, x24, #0x20
    ac68:      	stp	x2, x24, [sp, #0x50]
    ac6c:      	ldr	x8, [sp, #0x30]
    ac70:      	cmp	x21, x8
    ac74:      	b.ne	0xac84 <generic_kprobe_path+0x11a4>
    ac78:      	ldr	x8, [sp, #0x38]
    ac7c:      	cmp	x2, x8
    ac80:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ac84:      	mov	w8, #0x4                // =4
    ac88:      	add	x0, sp, #0x70
    ac8c:      	mov	w1, #0x8                // =8
    ac90:      	blr	x8
    ac94:      	ldr	x8, [sp, #0x70]
    ac98:      	cmp	x21, x8
    ac9c:      	b.eq	0xad8c <generic_kprobe_path+0x12ac>
    aca0:      	add	x23, x21, #0x18
    aca4:      	mov	w8, #0x4                // =4
    aca8:      	add	x9, sp, #0x98
    acac:      	add	x0, sp, #0x98
    acb0:      	mov	w1, #0x8                // =8
    acb4:      	mov	x2, x23
    acb8:      	blr	x8
    acbc:      	ldr	x8, [sp, #0x98]
    acc0:      	cmp	x8, x21
    acc4:      	b.eq	0xad8c <generic_kprobe_path+0x12ac>
    acc8:      	mov	w8, #0x4                // =4
    accc:      	add	x9, sp, #0x78
    acd0:      	add	x0, sp, #0x78
    acd4:      	mov	w1, #0x8                // =8
    acd8:      	mov	x2, x23
    acdc:      	blr	x8
    ace0:      	add	x2, x21, #0x20
    ace4:      	mov	w8, #0x4                // =4
    ace8:      	mov	w9, #0x10               // =16
    acec:      	add	x10, sp, #0x80
    acf0:      	add	x0, sp, #0x80
    acf4:      	mov	w1, #0x10               // =16
    acf8:      	blr	x8
    acfc:      	ldr	w21, [sp, #0x84]
    ad00:      	ldr	x8, [sp, #0x40]
    ad04:      	ldr	x10, [sp, #0x60]
    ad08:      	sub	x12, x10, x8
    ad0c:      	ldr	w23, [sp, #0x68]
    ad10:      	subs	w10, w21, w23
    ad14:      	ldr	x9, [sp, #0x88]
    ad18:      	csel	w10, wzr, w10, lo
    ad1c:      	cmp	w23, w21
    ad20:      	csel	w11, w23, w21, lo
    ad24:      	cinc	w13, w11, hi
    ad28:      	sub	w14, w23, w13
    ad2c:      	subs	x12, x12, x13
    ad30:      	str	w14, [sp, #0x68]
    ad34:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    ad38:      	cmp	x12, #0xfff
    ad3c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    ad40:      	cmp	w23, w21
    ad44:      	b.ls	0xad50 <generic_kprobe_path+0x1270>
    ad48:      	mov	w13, #0x2f              // =47
    ad4c:      	strb	w13, [x8, x12]
    ad50:      	add	x19, x8, x12
    ad54:      	cmp	w23, w21
    ad58:      	add	x2, x9, x10
    ad5c:      	and	w1, w11, #0xff
    ad60:      	mov	w8, #0x4                // =4
    ad64:      	cinc	x0, x19, hi
    ad68:      	blr	x8
    ad6c:      	cmp	w23, w21
    ad70:      	str	x19, [sp, #0x60]
    ad74:      	add	x19, sp, #0x70
    ad78:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ad7c:      	ldr	x21, [sp, #0x78]
    ad80:      	ldp	x2, x24, [sp, #0x50]
    ad84:      	str	x21, [sp, #0x48]
    ad88:      	b	0xadd8 <generic_kprobe_path+0x12f8>
    ad8c:      	add	x2, x24, #0x10
    ad90:      	mov	w8, #0x4                // =4
    ad94:      	add	x9, sp, #0x98
    ad98:      	add	x0, sp, #0x98
    ad9c:      	mov	w1, #0x8                // =8
    ada0:      	blr	x8
    ada4:      	ldr	x8, [sp, #0x58]
    ada8:      	ldr	x9, [sp, #0x98]
    adac:      	cmp	x8, x9
    adb0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    adb4:      	add	x2, x24, #0x18
    adb8:      	mov	w8, #0x4                // =4
    adbc:      	mov	x0, x22
    adc0:      	mov	w1, #0x8                // =8
    adc4:      	blr	x8
    adc8:      	ldr	x24, [sp, #0x98]
    adcc:      	ldr	x21, [sp, #0x48]
    add0:      	add	x2, x24, #0x20
    add4:      	stp	x2, x24, [sp, #0x50]
    add8:      	ldr	x8, [sp, #0x30]
    addc:      	cmp	x21, x8
    ade0:      	b.ne	0xadf0 <generic_kprobe_path+0x1310>
    ade4:      	ldr	x8, [sp, #0x38]
    ade8:      	cmp	x2, x8
    adec:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    adf0:      	mov	w8, #0x4                // =4
    adf4:      	add	x0, sp, #0x70
    adf8:      	mov	w1, #0x8                // =8
    adfc:      	blr	x8
    ae00:      	ldr	x8, [sp, #0x70]
    ae04:      	cmp	x21, x8
    ae08:      	b.eq	0xaef8 <generic_kprobe_path+0x1418>
    ae0c:      	add	x23, x21, #0x18
    ae10:      	mov	w8, #0x4                // =4
    ae14:      	add	x9, sp, #0x98
    ae18:      	add	x0, sp, #0x98
    ae1c:      	mov	w1, #0x8                // =8
    ae20:      	mov	x2, x23
    ae24:      	blr	x8
    ae28:      	ldr	x8, [sp, #0x98]
    ae2c:      	cmp	x8, x21
    ae30:      	b.eq	0xaef8 <generic_kprobe_path+0x1418>
    ae34:      	mov	w8, #0x4                // =4
    ae38:      	add	x9, sp, #0x78
    ae3c:      	add	x0, sp, #0x78
    ae40:      	mov	w1, #0x8                // =8
    ae44:      	mov	x2, x23
    ae48:      	blr	x8
    ae4c:      	add	x2, x21, #0x20
    ae50:      	mov	w8, #0x4                // =4
    ae54:      	mov	w9, #0x10               // =16
    ae58:      	add	x10, sp, #0x80
    ae5c:      	add	x0, sp, #0x80
    ae60:      	mov	w1, #0x10               // =16
    ae64:      	blr	x8
    ae68:      	ldr	w21, [sp, #0x84]
    ae6c:      	ldr	x8, [sp, #0x40]
    ae70:      	ldr	x10, [sp, #0x60]
    ae74:      	sub	x12, x10, x8
    ae78:      	ldr	w23, [sp, #0x68]
    ae7c:      	subs	w10, w21, w23
    ae80:      	ldr	x9, [sp, #0x88]
    ae84:      	csel	w10, wzr, w10, lo
    ae88:      	cmp	w23, w21
    ae8c:      	csel	w11, w23, w21, lo
    ae90:      	cinc	w13, w11, hi
    ae94:      	sub	w14, w23, w13
    ae98:      	subs	x12, x12, x13
    ae9c:      	str	w14, [sp, #0x68]
    aea0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    aea4:      	cmp	x12, #0xfff
    aea8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    aeac:      	cmp	w23, w21
    aeb0:      	b.ls	0xaebc <generic_kprobe_path+0x13dc>
    aeb4:      	mov	w13, #0x2f              // =47
    aeb8:      	strb	w13, [x8, x12]
    aebc:      	add	x19, x8, x12
    aec0:      	cmp	w23, w21
    aec4:      	add	x2, x9, x10
    aec8:      	and	w1, w11, #0xff
    aecc:      	mov	w8, #0x4                // =4
    aed0:      	cinc	x0, x19, hi
    aed4:      	blr	x8
    aed8:      	cmp	w23, w21
    aedc:      	str	x19, [sp, #0x60]
    aee0:      	add	x19, sp, #0x70
    aee4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    aee8:      	ldr	x21, [sp, #0x78]
    aeec:      	ldp	x2, x24, [sp, #0x50]
    aef0:      	str	x21, [sp, #0x48]
    aef4:      	b	0xaf44 <generic_kprobe_path+0x1464>
    aef8:      	add	x2, x24, #0x10
    aefc:      	mov	w8, #0x4                // =4
    af00:      	add	x9, sp, #0x98
    af04:      	add	x0, sp, #0x98
    af08:      	mov	w1, #0x8                // =8
    af0c:      	blr	x8
    af10:      	ldr	x8, [sp, #0x58]
    af14:      	ldr	x9, [sp, #0x98]
    af18:      	cmp	x8, x9
    af1c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    af20:      	add	x2, x24, #0x18
    af24:      	mov	w8, #0x4                // =4
    af28:      	mov	x0, x22
    af2c:      	mov	w1, #0x8                // =8
    af30:      	blr	x8
    af34:      	ldr	x24, [sp, #0x98]
    af38:      	ldr	x21, [sp, #0x48]
    af3c:      	add	x2, x24, #0x20
    af40:      	stp	x2, x24, [sp, #0x50]
    af44:      	ldr	x8, [sp, #0x30]
    af48:      	cmp	x21, x8
    af4c:      	b.ne	0xaf5c <generic_kprobe_path+0x147c>
    af50:      	ldr	x8, [sp, #0x38]
    af54:      	cmp	x2, x8
    af58:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    af5c:      	mov	w8, #0x4                // =4
    af60:      	add	x0, sp, #0x70
    af64:      	mov	w1, #0x8                // =8
    af68:      	blr	x8
    af6c:      	ldr	x8, [sp, #0x70]
    af70:      	cmp	x21, x8
    af74:      	b.eq	0xb064 <generic_kprobe_path+0x1584>
    af78:      	add	x23, x21, #0x18
    af7c:      	mov	w8, #0x4                // =4
    af80:      	add	x9, sp, #0x98
    af84:      	add	x0, sp, #0x98
    af88:      	mov	w1, #0x8                // =8
    af8c:      	mov	x2, x23
    af90:      	blr	x8
    af94:      	ldr	x8, [sp, #0x98]
    af98:      	cmp	x8, x21
    af9c:      	b.eq	0xb064 <generic_kprobe_path+0x1584>
    afa0:      	mov	w8, #0x4                // =4
    afa4:      	add	x9, sp, #0x78
    afa8:      	add	x0, sp, #0x78
    afac:      	mov	w1, #0x8                // =8
    afb0:      	mov	x2, x23
    afb4:      	blr	x8
    afb8:      	add	x2, x21, #0x20
    afbc:      	mov	w8, #0x4                // =4
    afc0:      	mov	w9, #0x10               // =16
    afc4:      	add	x10, sp, #0x80
    afc8:      	add	x0, sp, #0x80
    afcc:      	mov	w1, #0x10               // =16
    afd0:      	blr	x8
    afd4:      	ldr	w21, [sp, #0x84]
    afd8:      	ldr	x8, [sp, #0x40]
    afdc:      	ldr	x10, [sp, #0x60]
    afe0:      	sub	x12, x10, x8
    afe4:      	ldr	w23, [sp, #0x68]
    afe8:      	subs	w10, w21, w23
    afec:      	ldr	x9, [sp, #0x88]
    aff0:      	csel	w10, wzr, w10, lo
    aff4:      	cmp	w23, w21
    aff8:      	csel	w11, w23, w21, lo
    affc:      	cinc	w13, w11, hi
    b000:      	sub	w14, w23, w13
    b004:      	subs	x12, x12, x13
    b008:      	str	w14, [sp, #0x68]
    b00c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b010:      	cmp	x12, #0xfff
    b014:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b018:      	cmp	w23, w21
    b01c:      	b.ls	0xb028 <generic_kprobe_path+0x1548>
    b020:      	mov	w13, #0x2f              // =47
    b024:      	strb	w13, [x8, x12]
    b028:      	add	x19, x8, x12
    b02c:      	cmp	w23, w21
    b030:      	add	x2, x9, x10
    b034:      	and	w1, w11, #0xff
    b038:      	mov	w8, #0x4                // =4
    b03c:      	cinc	x0, x19, hi
    b040:      	blr	x8
    b044:      	cmp	w23, w21
    b048:      	str	x19, [sp, #0x60]
    b04c:      	add	x19, sp, #0x70
    b050:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b054:      	ldr	x21, [sp, #0x78]
    b058:      	ldp	x2, x24, [sp, #0x50]
    b05c:      	str	x21, [sp, #0x48]
    b060:      	b	0xb0b0 <generic_kprobe_path+0x15d0>
    b064:      	add	x2, x24, #0x10
    b068:      	mov	w8, #0x4                // =4
    b06c:      	add	x9, sp, #0x98
    b070:      	add	x0, sp, #0x98
    b074:      	mov	w1, #0x8                // =8
    b078:      	blr	x8
    b07c:      	ldr	x8, [sp, #0x58]
    b080:      	ldr	x9, [sp, #0x98]
    b084:      	cmp	x8, x9
    b088:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b08c:      	add	x2, x24, #0x18
    b090:      	mov	w8, #0x4                // =4
    b094:      	mov	x0, x22
    b098:      	mov	w1, #0x8                // =8
    b09c:      	blr	x8
    b0a0:      	ldr	x24, [sp, #0x98]
    b0a4:      	ldr	x21, [sp, #0x48]
    b0a8:      	add	x2, x24, #0x20
    b0ac:      	stp	x2, x24, [sp, #0x50]
    b0b0:      	ldr	x8, [sp, #0x30]
    b0b4:      	cmp	x21, x8
    b0b8:      	b.ne	0xb0c8 <generic_kprobe_path+0x15e8>
    b0bc:      	ldr	x8, [sp, #0x38]
    b0c0:      	cmp	x2, x8
    b0c4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b0c8:      	mov	w8, #0x4                // =4
    b0cc:      	add	x0, sp, #0x70
    b0d0:      	mov	w1, #0x8                // =8
    b0d4:      	blr	x8
    b0d8:      	ldr	x8, [sp, #0x70]
    b0dc:      	cmp	x21, x8
    b0e0:      	b.eq	0xb1d0 <generic_kprobe_path+0x16f0>
    b0e4:      	add	x23, x21, #0x18
    b0e8:      	mov	w8, #0x4                // =4
    b0ec:      	add	x9, sp, #0x98
    b0f0:      	add	x0, sp, #0x98
    b0f4:      	mov	w1, #0x8                // =8
    b0f8:      	mov	x2, x23
    b0fc:      	blr	x8
    b100:      	ldr	x8, [sp, #0x98]
    b104:      	cmp	x8, x21
    b108:      	b.eq	0xb1d0 <generic_kprobe_path+0x16f0>
    b10c:      	mov	w8, #0x4                // =4
    b110:      	add	x9, sp, #0x78
    b114:      	add	x0, sp, #0x78
    b118:      	mov	w1, #0x8                // =8
    b11c:      	mov	x2, x23
    b120:      	blr	x8
    b124:      	add	x2, x21, #0x20
    b128:      	mov	w8, #0x4                // =4
    b12c:      	mov	w9, #0x10               // =16
    b130:      	add	x10, sp, #0x80
    b134:      	add	x0, sp, #0x80
    b138:      	mov	w1, #0x10               // =16
    b13c:      	blr	x8
    b140:      	ldr	w21, [sp, #0x84]
    b144:      	ldr	x8, [sp, #0x40]
    b148:      	ldr	x10, [sp, #0x60]
    b14c:      	sub	x12, x10, x8
    b150:      	ldr	w23, [sp, #0x68]
    b154:      	subs	w10, w21, w23
    b158:      	ldr	x9, [sp, #0x88]
    b15c:      	csel	w10, wzr, w10, lo
    b160:      	cmp	w23, w21
    b164:      	csel	w11, w23, w21, lo
    b168:      	cinc	w13, w11, hi
    b16c:      	sub	w14, w23, w13
    b170:      	subs	x12, x12, x13
    b174:      	str	w14, [sp, #0x68]
    b178:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b17c:      	cmp	x12, #0xfff
    b180:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b184:      	cmp	w23, w21
    b188:      	b.ls	0xb194 <generic_kprobe_path+0x16b4>
    b18c:      	mov	w13, #0x2f              // =47
    b190:      	strb	w13, [x8, x12]
    b194:      	add	x19, x8, x12
    b198:      	cmp	w23, w21
    b19c:      	add	x2, x9, x10
    b1a0:      	and	w1, w11, #0xff
    b1a4:      	mov	w8, #0x4                // =4
    b1a8:      	cinc	x0, x19, hi
    b1ac:      	blr	x8
    b1b0:      	cmp	w23, w21
    b1b4:      	str	x19, [sp, #0x60]
    b1b8:      	add	x19, sp, #0x70
    b1bc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b1c0:      	ldr	x21, [sp, #0x78]
    b1c4:      	ldp	x2, x24, [sp, #0x50]
    b1c8:      	str	x21, [sp, #0x48]
    b1cc:      	b	0xb21c <generic_kprobe_path+0x173c>
    b1d0:      	add	x2, x24, #0x10
    b1d4:      	mov	w8, #0x4                // =4
    b1d8:      	add	x9, sp, #0x98
    b1dc:      	add	x0, sp, #0x98
    b1e0:      	mov	w1, #0x8                // =8
    b1e4:      	blr	x8
    b1e8:      	ldr	x8, [sp, #0x58]
    b1ec:      	ldr	x9, [sp, #0x98]
    b1f0:      	cmp	x8, x9
    b1f4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b1f8:      	add	x2, x24, #0x18
    b1fc:      	mov	w8, #0x4                // =4
    b200:      	mov	x0, x22
    b204:      	mov	w1, #0x8                // =8
    b208:      	blr	x8
    b20c:      	ldr	x24, [sp, #0x98]
    b210:      	ldr	x21, [sp, #0x48]
    b214:      	add	x2, x24, #0x20
    b218:      	stp	x2, x24, [sp, #0x50]
    b21c:      	ldr	x8, [sp, #0x30]
    b220:      	cmp	x21, x8
    b224:      	b.ne	0xb234 <generic_kprobe_path+0x1754>
    b228:      	ldr	x8, [sp, #0x38]
    b22c:      	cmp	x2, x8
    b230:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b234:      	mov	w8, #0x4                // =4
    b238:      	add	x0, sp, #0x70
    b23c:      	mov	w1, #0x8                // =8
    b240:      	blr	x8
    b244:      	ldr	x8, [sp, #0x70]
    b248:      	cmp	x21, x8
    b24c:      	b.eq	0xb33c <generic_kprobe_path+0x185c>
    b250:      	add	x23, x21, #0x18
    b254:      	mov	w8, #0x4                // =4
    b258:      	add	x9, sp, #0x98
    b25c:      	add	x0, sp, #0x98
    b260:      	mov	w1, #0x8                // =8
    b264:      	mov	x2, x23
    b268:      	blr	x8
    b26c:      	ldr	x8, [sp, #0x98]
    b270:      	cmp	x8, x21
    b274:      	b.eq	0xb33c <generic_kprobe_path+0x185c>
    b278:      	mov	w8, #0x4                // =4
    b27c:      	add	x9, sp, #0x78
    b280:      	add	x0, sp, #0x78
    b284:      	mov	w1, #0x8                // =8
    b288:      	mov	x2, x23
    b28c:      	blr	x8
    b290:      	add	x2, x21, #0x20
    b294:      	mov	w8, #0x4                // =4
    b298:      	mov	w9, #0x10               // =16
    b29c:      	add	x10, sp, #0x80
    b2a0:      	add	x0, sp, #0x80
    b2a4:      	mov	w1, #0x10               // =16
    b2a8:      	blr	x8
    b2ac:      	ldr	w21, [sp, #0x84]
    b2b0:      	ldr	x8, [sp, #0x40]
    b2b4:      	ldr	x10, [sp, #0x60]
    b2b8:      	sub	x12, x10, x8
    b2bc:      	ldr	w23, [sp, #0x68]
    b2c0:      	subs	w10, w21, w23
    b2c4:      	ldr	x9, [sp, #0x88]
    b2c8:      	csel	w10, wzr, w10, lo
    b2cc:      	cmp	w23, w21
    b2d0:      	csel	w11, w23, w21, lo
    b2d4:      	cinc	w13, w11, hi
    b2d8:      	sub	w14, w23, w13
    b2dc:      	subs	x12, x12, x13
    b2e0:      	str	w14, [sp, #0x68]
    b2e4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b2e8:      	cmp	x12, #0xfff
    b2ec:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b2f0:      	cmp	w23, w21
    b2f4:      	b.ls	0xb300 <generic_kprobe_path+0x1820>
    b2f8:      	mov	w13, #0x2f              // =47
    b2fc:      	strb	w13, [x8, x12]
    b300:      	add	x19, x8, x12
    b304:      	cmp	w23, w21
    b308:      	add	x2, x9, x10
    b30c:      	and	w1, w11, #0xff
    b310:      	mov	w8, #0x4                // =4
    b314:      	cinc	x0, x19, hi
    b318:      	blr	x8
    b31c:      	cmp	w23, w21
    b320:      	str	x19, [sp, #0x60]
    b324:      	add	x19, sp, #0x70
    b328:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b32c:      	ldr	x21, [sp, #0x78]
    b330:      	ldp	x2, x24, [sp, #0x50]
    b334:      	str	x21, [sp, #0x48]
    b338:      	b	0xb388 <generic_kprobe_path+0x18a8>
    b33c:      	add	x2, x24, #0x10
    b340:      	mov	w8, #0x4                // =4
    b344:      	add	x9, sp, #0x98
    b348:      	add	x0, sp, #0x98
    b34c:      	mov	w1, #0x8                // =8
    b350:      	blr	x8
    b354:      	ldr	x8, [sp, #0x58]
    b358:      	ldr	x9, [sp, #0x98]
    b35c:      	cmp	x8, x9
    b360:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b364:      	add	x2, x24, #0x18
    b368:      	mov	w8, #0x4                // =4
    b36c:      	mov	x0, x22
    b370:      	mov	w1, #0x8                // =8
    b374:      	blr	x8
    b378:      	ldr	x24, [sp, #0x98]
    b37c:      	ldr	x21, [sp, #0x48]
    b380:      	add	x2, x24, #0x20
    b384:      	stp	x2, x24, [sp, #0x50]
    b388:      	ldr	x8, [sp, #0x30]
    b38c:      	cmp	x21, x8
    b390:      	b.ne	0xb3a0 <generic_kprobe_path+0x18c0>
    b394:      	ldr	x8, [sp, #0x38]
    b398:      	cmp	x2, x8
    b39c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b3a0:      	mov	w8, #0x4                // =4
    b3a4:      	add	x0, sp, #0x70
    b3a8:      	mov	w1, #0x8                // =8
    b3ac:      	blr	x8
    b3b0:      	ldr	x8, [sp, #0x70]
    b3b4:      	cmp	x21, x8
    b3b8:      	b.eq	0xb4a8 <generic_kprobe_path+0x19c8>
    b3bc:      	add	x23, x21, #0x18
    b3c0:      	mov	w8, #0x4                // =4
    b3c4:      	add	x9, sp, #0x98
    b3c8:      	add	x0, sp, #0x98
    b3cc:      	mov	w1, #0x8                // =8
    b3d0:      	mov	x2, x23
    b3d4:      	blr	x8
    b3d8:      	ldr	x8, [sp, #0x98]
    b3dc:      	cmp	x8, x21
    b3e0:      	b.eq	0xb4a8 <generic_kprobe_path+0x19c8>
    b3e4:      	mov	w8, #0x4                // =4
    b3e8:      	add	x9, sp, #0x78
    b3ec:      	add	x0, sp, #0x78
    b3f0:      	mov	w1, #0x8                // =8
    b3f4:      	mov	x2, x23
    b3f8:      	blr	x8
    b3fc:      	add	x2, x21, #0x20
    b400:      	mov	w8, #0x4                // =4
    b404:      	mov	w9, #0x10               // =16
    b408:      	add	x10, sp, #0x80
    b40c:      	add	x0, sp, #0x80
    b410:      	mov	w1, #0x10               // =16
    b414:      	blr	x8
    b418:      	ldr	w21, [sp, #0x84]
    b41c:      	ldr	x8, [sp, #0x40]
    b420:      	ldr	x10, [sp, #0x60]
    b424:      	sub	x12, x10, x8
    b428:      	ldr	w23, [sp, #0x68]
    b42c:      	subs	w10, w21, w23
    b430:      	ldr	x9, [sp, #0x88]
    b434:      	csel	w10, wzr, w10, lo
    b438:      	cmp	w23, w21
    b43c:      	csel	w11, w23, w21, lo
    b440:      	cinc	w13, w11, hi
    b444:      	sub	w14, w23, w13
    b448:      	subs	x12, x12, x13
    b44c:      	str	w14, [sp, #0x68]
    b450:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b454:      	cmp	x12, #0xfff
    b458:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b45c:      	cmp	w23, w21
    b460:      	b.ls	0xb46c <generic_kprobe_path+0x198c>
    b464:      	mov	w13, #0x2f              // =47
    b468:      	strb	w13, [x8, x12]
    b46c:      	add	x19, x8, x12
    b470:      	cmp	w23, w21
    b474:      	add	x2, x9, x10
    b478:      	and	w1, w11, #0xff
    b47c:      	mov	w8, #0x4                // =4
    b480:      	cinc	x0, x19, hi
    b484:      	blr	x8
    b488:      	cmp	w23, w21
    b48c:      	str	x19, [sp, #0x60]
    b490:      	add	x19, sp, #0x70
    b494:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b498:      	ldr	x21, [sp, #0x78]
    b49c:      	ldp	x2, x24, [sp, #0x50]
    b4a0:      	str	x21, [sp, #0x48]
    b4a4:      	b	0xb4f4 <generic_kprobe_path+0x1a14>
    b4a8:      	add	x2, x24, #0x10
    b4ac:      	mov	w8, #0x4                // =4
    b4b0:      	add	x9, sp, #0x98
    b4b4:      	add	x0, sp, #0x98
    b4b8:      	mov	w1, #0x8                // =8
    b4bc:      	blr	x8
    b4c0:      	ldr	x8, [sp, #0x58]
    b4c4:      	ldr	x9, [sp, #0x98]
    b4c8:      	cmp	x8, x9
    b4cc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b4d0:      	add	x2, x24, #0x18
    b4d4:      	mov	w8, #0x4                // =4
    b4d8:      	mov	x0, x22
    b4dc:      	mov	w1, #0x8                // =8
    b4e0:      	blr	x8
    b4e4:      	ldr	x24, [sp, #0x98]
    b4e8:      	ldr	x21, [sp, #0x48]
    b4ec:      	add	x2, x24, #0x20
    b4f0:      	stp	x2, x24, [sp, #0x50]
    b4f4:      	ldr	x8, [sp, #0x30]
    b4f8:      	cmp	x21, x8
    b4fc:      	b.ne	0xb50c <generic_kprobe_path+0x1a2c>
    b500:      	ldr	x8, [sp, #0x38]
    b504:      	cmp	x2, x8
    b508:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b50c:      	mov	w8, #0x4                // =4
    b510:      	add	x0, sp, #0x70
    b514:      	mov	w1, #0x8                // =8
    b518:      	blr	x8
    b51c:      	ldr	x8, [sp, #0x70]
    b520:      	cmp	x21, x8
    b524:      	b.eq	0xb614 <generic_kprobe_path+0x1b34>
    b528:      	add	x23, x21, #0x18
    b52c:      	mov	w8, #0x4                // =4
    b530:      	add	x9, sp, #0x98
    b534:      	add	x0, sp, #0x98
    b538:      	mov	w1, #0x8                // =8
    b53c:      	mov	x2, x23
    b540:      	blr	x8
    b544:      	ldr	x8, [sp, #0x98]
    b548:      	cmp	x8, x21
    b54c:      	b.eq	0xb614 <generic_kprobe_path+0x1b34>
    b550:      	mov	w8, #0x4                // =4
    b554:      	add	x9, sp, #0x78
    b558:      	add	x0, sp, #0x78
    b55c:      	mov	w1, #0x8                // =8
    b560:      	mov	x2, x23
    b564:      	blr	x8
    b568:      	add	x2, x21, #0x20
    b56c:      	mov	w8, #0x4                // =4
    b570:      	mov	w9, #0x10               // =16
    b574:      	add	x10, sp, #0x80
    b578:      	add	x0, sp, #0x80
    b57c:      	mov	w1, #0x10               // =16
    b580:      	blr	x8
    b584:      	ldr	w21, [sp, #0x84]
    b588:      	ldr	x8, [sp, #0x40]
    b58c:      	ldr	x10, [sp, #0x60]
    b590:      	sub	x12, x10, x8
    b594:      	ldr	w23, [sp, #0x68]
    b598:      	subs	w10, w21, w23
    b59c:      	ldr	x9, [sp, #0x88]
    b5a0:      	csel	w10, wzr, w10, lo
    b5a4:      	cmp	w23, w21
    b5a8:      	csel	w11, w23, w21, lo
    b5ac:      	cinc	w13, w11, hi
    b5b0:      	sub	w14, w23, w13
    b5b4:      	subs	x12, x12, x13
    b5b8:      	str	w14, [sp, #0x68]
    b5bc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b5c0:      	cmp	x12, #0xfff
    b5c4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b5c8:      	cmp	w23, w21
    b5cc:      	b.ls	0xb5d8 <generic_kprobe_path+0x1af8>
    b5d0:      	mov	w13, #0x2f              // =47
    b5d4:      	strb	w13, [x8, x12]
    b5d8:      	add	x19, x8, x12
    b5dc:      	cmp	w23, w21
    b5e0:      	add	x2, x9, x10
    b5e4:      	and	w1, w11, #0xff
    b5e8:      	mov	w8, #0x4                // =4
    b5ec:      	cinc	x0, x19, hi
    b5f0:      	blr	x8
    b5f4:      	cmp	w23, w21
    b5f8:      	str	x19, [sp, #0x60]
    b5fc:      	add	x19, sp, #0x70
    b600:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b604:      	ldr	x21, [sp, #0x78]
    b608:      	ldp	x2, x24, [sp, #0x50]
    b60c:      	str	x21, [sp, #0x48]
    b610:      	b	0xb660 <generic_kprobe_path+0x1b80>
    b614:      	add	x2, x24, #0x10
    b618:      	mov	w8, #0x4                // =4
    b61c:      	add	x9, sp, #0x98
    b620:      	add	x0, sp, #0x98
    b624:      	mov	w1, #0x8                // =8
    b628:      	blr	x8
    b62c:      	ldr	x8, [sp, #0x58]
    b630:      	ldr	x9, [sp, #0x98]
    b634:      	cmp	x8, x9
    b638:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b63c:      	add	x2, x24, #0x18
    b640:      	mov	w8, #0x4                // =4
    b644:      	mov	x0, x22
    b648:      	mov	w1, #0x8                // =8
    b64c:      	blr	x8
    b650:      	ldr	x24, [sp, #0x98]
    b654:      	ldr	x21, [sp, #0x48]
    b658:      	add	x2, x24, #0x20
    b65c:      	stp	x2, x24, [sp, #0x50]
    b660:      	ldr	x8, [sp, #0x30]
    b664:      	cmp	x21, x8
    b668:      	b.ne	0xb678 <generic_kprobe_path+0x1b98>
    b66c:      	ldr	x8, [sp, #0x38]
    b670:      	cmp	x2, x8
    b674:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b678:      	mov	w8, #0x4                // =4
    b67c:      	add	x0, sp, #0x70
    b680:      	mov	w1, #0x8                // =8
    b684:      	blr	x8
    b688:      	ldr	x8, [sp, #0x70]
    b68c:      	cmp	x21, x8
    b690:      	b.eq	0xb780 <generic_kprobe_path+0x1ca0>
    b694:      	add	x23, x21, #0x18
    b698:      	mov	w8, #0x4                // =4
    b69c:      	add	x9, sp, #0x98
    b6a0:      	add	x0, sp, #0x98
    b6a4:      	mov	w1, #0x8                // =8
    b6a8:      	mov	x2, x23
    b6ac:      	blr	x8
    b6b0:      	ldr	x8, [sp, #0x98]
    b6b4:      	cmp	x8, x21
    b6b8:      	b.eq	0xb780 <generic_kprobe_path+0x1ca0>
    b6bc:      	mov	w8, #0x4                // =4
    b6c0:      	add	x9, sp, #0x78
    b6c4:      	add	x0, sp, #0x78
    b6c8:      	mov	w1, #0x8                // =8
    b6cc:      	mov	x2, x23
    b6d0:      	blr	x8
    b6d4:      	add	x2, x21, #0x20
    b6d8:      	mov	w8, #0x4                // =4
    b6dc:      	mov	w9, #0x10               // =16
    b6e0:      	add	x10, sp, #0x80
    b6e4:      	add	x0, sp, #0x80
    b6e8:      	mov	w1, #0x10               // =16
    b6ec:      	blr	x8
    b6f0:      	ldr	w21, [sp, #0x84]
    b6f4:      	ldr	x8, [sp, #0x40]
    b6f8:      	ldr	x10, [sp, #0x60]
    b6fc:      	sub	x12, x10, x8
    b700:      	ldr	w23, [sp, #0x68]
    b704:      	subs	w10, w21, w23
    b708:      	ldr	x9, [sp, #0x88]
    b70c:      	csel	w10, wzr, w10, lo
    b710:      	cmp	w23, w21
    b714:      	csel	w11, w23, w21, lo
    b718:      	cinc	w13, w11, hi
    b71c:      	sub	w14, w23, w13
    b720:      	subs	x12, x12, x13
    b724:      	str	w14, [sp, #0x68]
    b728:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b72c:      	cmp	x12, #0xfff
    b730:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b734:      	cmp	w23, w21
    b738:      	b.ls	0xb744 <generic_kprobe_path+0x1c64>
    b73c:      	mov	w13, #0x2f              // =47
    b740:      	strb	w13, [x8, x12]
    b744:      	add	x19, x8, x12
    b748:      	cmp	w23, w21
    b74c:      	add	x2, x9, x10
    b750:      	and	w1, w11, #0xff
    b754:      	mov	w8, #0x4                // =4
    b758:      	cinc	x0, x19, hi
    b75c:      	blr	x8
    b760:      	cmp	w23, w21
    b764:      	str	x19, [sp, #0x60]
    b768:      	add	x19, sp, #0x70
    b76c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b770:      	ldr	x21, [sp, #0x78]
    b774:      	ldp	x2, x24, [sp, #0x50]
    b778:      	str	x21, [sp, #0x48]
    b77c:      	b	0xb7cc <generic_kprobe_path+0x1cec>
    b780:      	add	x2, x24, #0x10
    b784:      	mov	w8, #0x4                // =4
    b788:      	add	x9, sp, #0x98
    b78c:      	add	x0, sp, #0x98
    b790:      	mov	w1, #0x8                // =8
    b794:      	blr	x8
    b798:      	ldr	x8, [sp, #0x58]
    b79c:      	ldr	x9, [sp, #0x98]
    b7a0:      	cmp	x8, x9
    b7a4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b7a8:      	add	x2, x24, #0x18
    b7ac:      	mov	w8, #0x4                // =4
    b7b0:      	mov	x0, x22
    b7b4:      	mov	w1, #0x8                // =8
    b7b8:      	blr	x8
    b7bc:      	ldr	x24, [sp, #0x98]
    b7c0:      	ldr	x21, [sp, #0x48]
    b7c4:      	add	x2, x24, #0x20
    b7c8:      	stp	x2, x24, [sp, #0x50]
    b7cc:      	ldr	x8, [sp, #0x30]
    b7d0:      	cmp	x21, x8
    b7d4:      	b.ne	0xb7e4 <generic_kprobe_path+0x1d04>
    b7d8:      	ldr	x8, [sp, #0x38]
    b7dc:      	cmp	x2, x8
    b7e0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b7e4:      	mov	w8, #0x4                // =4
    b7e8:      	add	x0, sp, #0x70
    b7ec:      	mov	w1, #0x8                // =8
    b7f0:      	blr	x8
    b7f4:      	ldr	x8, [sp, #0x70]
    b7f8:      	cmp	x21, x8
    b7fc:      	b.eq	0xb8ec <generic_kprobe_path+0x1e0c>
    b800:      	add	x23, x21, #0x18
    b804:      	mov	w8, #0x4                // =4
    b808:      	add	x9, sp, #0x98
    b80c:      	add	x0, sp, #0x98
    b810:      	mov	w1, #0x8                // =8
    b814:      	mov	x2, x23
    b818:      	blr	x8
    b81c:      	ldr	x8, [sp, #0x98]
    b820:      	cmp	x8, x21
    b824:      	b.eq	0xb8ec <generic_kprobe_path+0x1e0c>
    b828:      	mov	w8, #0x4                // =4
    b82c:      	add	x9, sp, #0x78
    b830:      	add	x0, sp, #0x78
    b834:      	mov	w1, #0x8                // =8
    b838:      	mov	x2, x23
    b83c:      	blr	x8
    b840:      	add	x2, x21, #0x20
    b844:      	mov	w8, #0x4                // =4
    b848:      	mov	w9, #0x10               // =16
    b84c:      	add	x10, sp, #0x80
    b850:      	add	x0, sp, #0x80
    b854:      	mov	w1, #0x10               // =16
    b858:      	blr	x8
    b85c:      	ldr	w21, [sp, #0x84]
    b860:      	ldr	x8, [sp, #0x40]
    b864:      	ldr	x10, [sp, #0x60]
    b868:      	sub	x12, x10, x8
    b86c:      	ldr	w23, [sp, #0x68]
    b870:      	subs	w10, w21, w23
    b874:      	ldr	x9, [sp, #0x88]
    b878:      	csel	w10, wzr, w10, lo
    b87c:      	cmp	w23, w21
    b880:      	csel	w11, w23, w21, lo
    b884:      	cinc	w13, w11, hi
    b888:      	sub	w14, w23, w13
    b88c:      	subs	x12, x12, x13
    b890:      	str	w14, [sp, #0x68]
    b894:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    b898:      	cmp	x12, #0xfff
    b89c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    b8a0:      	cmp	w23, w21
    b8a4:      	b.ls	0xb8b0 <generic_kprobe_path+0x1dd0>
    b8a8:      	mov	w13, #0x2f              // =47
    b8ac:      	strb	w13, [x8, x12]
    b8b0:      	add	x19, x8, x12
    b8b4:      	cmp	w23, w21
    b8b8:      	add	x2, x9, x10
    b8bc:      	and	w1, w11, #0xff
    b8c0:      	mov	w8, #0x4                // =4
    b8c4:      	cinc	x0, x19, hi
    b8c8:      	blr	x8
    b8cc:      	cmp	w23, w21
    b8d0:      	str	x19, [sp, #0x60]
    b8d4:      	add	x19, sp, #0x70
    b8d8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    b8dc:      	ldr	x21, [sp, #0x78]
    b8e0:      	ldp	x2, x24, [sp, #0x50]
    b8e4:      	str	x21, [sp, #0x48]
    b8e8:      	b	0xb938 <generic_kprobe_path+0x1e58>
    b8ec:      	add	x2, x24, #0x10
    b8f0:      	mov	w8, #0x4                // =4
    b8f4:      	add	x9, sp, #0x98
    b8f8:      	add	x0, sp, #0x98
    b8fc:      	mov	w1, #0x8                // =8
    b900:      	blr	x8
    b904:      	ldr	x8, [sp, #0x58]
    b908:      	ldr	x9, [sp, #0x98]
    b90c:      	cmp	x8, x9
    b910:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b914:      	add	x2, x24, #0x18
    b918:      	mov	w8, #0x4                // =4
    b91c:      	mov	x0, x22
    b920:      	mov	w1, #0x8                // =8
    b924:      	blr	x8
    b928:      	ldr	x24, [sp, #0x98]
    b92c:      	ldr	x21, [sp, #0x48]
    b930:      	add	x2, x24, #0x20
    b934:      	stp	x2, x24, [sp, #0x50]
    b938:      	ldr	x8, [sp, #0x30]
    b93c:      	cmp	x21, x8
    b940:      	b.ne	0xb950 <generic_kprobe_path+0x1e70>
    b944:      	ldr	x8, [sp, #0x38]
    b948:      	cmp	x2, x8
    b94c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    b950:      	mov	w8, #0x4                // =4
    b954:      	add	x0, sp, #0x70
    b958:      	mov	w1, #0x8                // =8
    b95c:      	blr	x8
    b960:      	ldr	x8, [sp, #0x70]
    b964:      	cmp	x21, x8
    b968:      	b.eq	0xba58 <generic_kprobe_path+0x1f78>
    b96c:      	add	x23, x21, #0x18
    b970:      	mov	w8, #0x4                // =4
    b974:      	add	x9, sp, #0x98
    b978:      	add	x0, sp, #0x98
    b97c:      	mov	w1, #0x8                // =8
    b980:      	mov	x2, x23
    b984:      	blr	x8
    b988:      	ldr	x8, [sp, #0x98]
    b98c:      	cmp	x8, x21
    b990:      	b.eq	0xba58 <generic_kprobe_path+0x1f78>
    b994:      	mov	w8, #0x4                // =4
    b998:      	add	x9, sp, #0x78
    b99c:      	add	x0, sp, #0x78
    b9a0:      	mov	w1, #0x8                // =8
    b9a4:      	mov	x2, x23
    b9a8:      	blr	x8
    b9ac:      	add	x2, x21, #0x20
    b9b0:      	mov	w8, #0x4                // =4
    b9b4:      	mov	w9, #0x10               // =16
    b9b8:      	add	x10, sp, #0x80
    b9bc:      	add	x0, sp, #0x80
    b9c0:      	mov	w1, #0x10               // =16
    b9c4:      	blr	x8
    b9c8:      	ldr	w21, [sp, #0x84]
    b9cc:      	ldr	x8, [sp, #0x40]
    b9d0:      	ldr	x10, [sp, #0x60]
    b9d4:      	sub	x12, x10, x8
    b9d8:      	ldr	w23, [sp, #0x68]
    b9dc:      	subs	w10, w21, w23
    b9e0:      	ldr	x9, [sp, #0x88]
    b9e4:      	csel	w10, wzr, w10, lo
    b9e8:      	cmp	w23, w21
    b9ec:      	csel	w11, w23, w21, lo
    b9f0:      	cinc	w13, w11, hi
    b9f4:      	sub	w14, w23, w13
    b9f8:      	subs	x12, x12, x13
    b9fc:      	str	w14, [sp, #0x68]
    ba00:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    ba04:      	cmp	x12, #0xfff
    ba08:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    ba0c:      	cmp	w23, w21
    ba10:      	b.ls	0xba1c <generic_kprobe_path+0x1f3c>
    ba14:      	mov	w13, #0x2f              // =47
    ba18:      	strb	w13, [x8, x12]
    ba1c:      	add	x19, x8, x12
    ba20:      	cmp	w23, w21
    ba24:      	add	x2, x9, x10
    ba28:      	and	w1, w11, #0xff
    ba2c:      	mov	w8, #0x4                // =4
    ba30:      	cinc	x0, x19, hi
    ba34:      	blr	x8
    ba38:      	cmp	w23, w21
    ba3c:      	str	x19, [sp, #0x60]
    ba40:      	add	x19, sp, #0x70
    ba44:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ba48:      	ldr	x21, [sp, #0x78]
    ba4c:      	ldp	x2, x24, [sp, #0x50]
    ba50:      	str	x21, [sp, #0x48]
    ba54:      	b	0xbaa4 <generic_kprobe_path+0x1fc4>
    ba58:      	add	x2, x24, #0x10
    ba5c:      	mov	w8, #0x4                // =4
    ba60:      	add	x9, sp, #0x98
    ba64:      	add	x0, sp, #0x98
    ba68:      	mov	w1, #0x8                // =8
    ba6c:      	blr	x8
    ba70:      	ldr	x8, [sp, #0x58]
    ba74:      	ldr	x9, [sp, #0x98]
    ba78:      	cmp	x8, x9
    ba7c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ba80:      	add	x2, x24, #0x18
    ba84:      	mov	w8, #0x4                // =4
    ba88:      	mov	x0, x22
    ba8c:      	mov	w1, #0x8                // =8
    ba90:      	blr	x8
    ba94:      	ldr	x24, [sp, #0x98]
    ba98:      	ldr	x21, [sp, #0x48]
    ba9c:      	add	x2, x24, #0x20
    baa0:      	stp	x2, x24, [sp, #0x50]
    baa4:      	ldr	x8, [sp, #0x30]
    baa8:      	cmp	x21, x8
    baac:      	b.ne	0xbabc <generic_kprobe_path+0x1fdc>
    bab0:      	ldr	x8, [sp, #0x38]
    bab4:      	cmp	x2, x8
    bab8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    babc:      	mov	w8, #0x4                // =4
    bac0:      	add	x0, sp, #0x70
    bac4:      	mov	w1, #0x8                // =8
    bac8:      	blr	x8
    bacc:      	ldr	x8, [sp, #0x70]
    bad0:      	cmp	x21, x8
    bad4:      	b.eq	0xbbc4 <generic_kprobe_path+0x20e4>
    bad8:      	add	x23, x21, #0x18
    badc:      	mov	w8, #0x4                // =4
    bae0:      	add	x9, sp, #0x98
    bae4:      	add	x0, sp, #0x98
    bae8:      	mov	w1, #0x8                // =8
    baec:      	mov	x2, x23
    baf0:      	blr	x8
    baf4:      	ldr	x8, [sp, #0x98]
    baf8:      	cmp	x8, x21
    bafc:      	b.eq	0xbbc4 <generic_kprobe_path+0x20e4>
    bb00:      	mov	w8, #0x4                // =4
    bb04:      	add	x9, sp, #0x78
    bb08:      	add	x0, sp, #0x78
    bb0c:      	mov	w1, #0x8                // =8
    bb10:      	mov	x2, x23
    bb14:      	blr	x8
    bb18:      	add	x2, x21, #0x20
    bb1c:      	mov	w8, #0x4                // =4
    bb20:      	mov	w9, #0x10               // =16
    bb24:      	add	x10, sp, #0x80
    bb28:      	add	x0, sp, #0x80
    bb2c:      	mov	w1, #0x10               // =16
    bb30:      	blr	x8
    bb34:      	ldr	w21, [sp, #0x84]
    bb38:      	ldr	x8, [sp, #0x40]
    bb3c:      	ldr	x10, [sp, #0x60]
    bb40:      	sub	x12, x10, x8
    bb44:      	ldr	w23, [sp, #0x68]
    bb48:      	subs	w10, w21, w23
    bb4c:      	ldr	x9, [sp, #0x88]
    bb50:      	csel	w10, wzr, w10, lo
    bb54:      	cmp	w23, w21
    bb58:      	csel	w11, w23, w21, lo
    bb5c:      	cinc	w13, w11, hi
    bb60:      	sub	w14, w23, w13
    bb64:      	subs	x12, x12, x13
    bb68:      	str	w14, [sp, #0x68]
    bb6c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    bb70:      	cmp	x12, #0xfff
    bb74:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    bb78:      	cmp	w23, w21
    bb7c:      	b.ls	0xbb88 <generic_kprobe_path+0x20a8>
    bb80:      	mov	w13, #0x2f              // =47
    bb84:      	strb	w13, [x8, x12]
    bb88:      	add	x19, x8, x12
    bb8c:      	cmp	w23, w21
    bb90:      	add	x2, x9, x10
    bb94:      	and	w1, w11, #0xff
    bb98:      	mov	w8, #0x4                // =4
    bb9c:      	cinc	x0, x19, hi
    bba0:      	blr	x8
    bba4:      	cmp	w23, w21
    bba8:      	str	x19, [sp, #0x60]
    bbac:      	add	x19, sp, #0x70
    bbb0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    bbb4:      	ldr	x21, [sp, #0x78]
    bbb8:      	ldp	x2, x24, [sp, #0x50]
    bbbc:      	str	x21, [sp, #0x48]
    bbc0:      	b	0xbc10 <generic_kprobe_path+0x2130>
    bbc4:      	add	x2, x24, #0x10
    bbc8:      	mov	w8, #0x4                // =4
    bbcc:      	add	x9, sp, #0x98
    bbd0:      	add	x0, sp, #0x98
    bbd4:      	mov	w1, #0x8                // =8
    bbd8:      	blr	x8
    bbdc:      	ldr	x8, [sp, #0x58]
    bbe0:      	ldr	x9, [sp, #0x98]
    bbe4:      	cmp	x8, x9
    bbe8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    bbec:      	add	x2, x24, #0x18
    bbf0:      	mov	w8, #0x4                // =4
    bbf4:      	mov	x0, x22
    bbf8:      	mov	w1, #0x8                // =8
    bbfc:      	blr	x8
    bc00:      	ldr	x24, [sp, #0x98]
    bc04:      	ldr	x21, [sp, #0x48]
    bc08:      	add	x2, x24, #0x20
    bc0c:      	stp	x2, x24, [sp, #0x50]
    bc10:      	ldr	x8, [sp, #0x30]
    bc14:      	cmp	x21, x8
    bc18:      	b.ne	0xbc28 <generic_kprobe_path+0x2148>
    bc1c:      	ldr	x8, [sp, #0x38]
    bc20:      	cmp	x2, x8
    bc24:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    bc28:      	mov	w8, #0x4                // =4
    bc2c:      	add	x0, sp, #0x70
    bc30:      	mov	w1, #0x8                // =8
    bc34:      	blr	x8
    bc38:      	ldr	x8, [sp, #0x70]
    bc3c:      	cmp	x21, x8
    bc40:      	b.eq	0xbd30 <generic_kprobe_path+0x2250>
    bc44:      	add	x23, x21, #0x18
    bc48:      	mov	w8, #0x4                // =4
    bc4c:      	add	x9, sp, #0x98
    bc50:      	add	x0, sp, #0x98
    bc54:      	mov	w1, #0x8                // =8
    bc58:      	mov	x2, x23
    bc5c:      	blr	x8
    bc60:      	ldr	x8, [sp, #0x98]
    bc64:      	cmp	x8, x21
    bc68:      	b.eq	0xbd30 <generic_kprobe_path+0x2250>
    bc6c:      	mov	w8, #0x4                // =4
    bc70:      	add	x9, sp, #0x78
    bc74:      	add	x0, sp, #0x78
    bc78:      	mov	w1, #0x8                // =8
    bc7c:      	mov	x2, x23
    bc80:      	blr	x8
    bc84:      	add	x2, x21, #0x20
    bc88:      	mov	w8, #0x4                // =4
    bc8c:      	mov	w9, #0x10               // =16
    bc90:      	add	x10, sp, #0x80
    bc94:      	add	x0, sp, #0x80
    bc98:      	mov	w1, #0x10               // =16
    bc9c:      	blr	x8
    bca0:      	ldr	w21, [sp, #0x84]
    bca4:      	ldr	x8, [sp, #0x40]
    bca8:      	ldr	x10, [sp, #0x60]
    bcac:      	sub	x12, x10, x8
    bcb0:      	ldr	w23, [sp, #0x68]
    bcb4:      	subs	w10, w21, w23
    bcb8:      	ldr	x9, [sp, #0x88]
    bcbc:      	csel	w10, wzr, w10, lo
    bcc0:      	cmp	w23, w21
    bcc4:      	csel	w11, w23, w21, lo
    bcc8:      	cinc	w13, w11, hi
    bccc:      	sub	w14, w23, w13
    bcd0:      	subs	x12, x12, x13
    bcd4:      	str	w14, [sp, #0x68]
    bcd8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    bcdc:      	cmp	x12, #0xfff
    bce0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    bce4:      	cmp	w23, w21
    bce8:      	b.ls	0xbcf4 <generic_kprobe_path+0x2214>
    bcec:      	mov	w13, #0x2f              // =47
    bcf0:      	strb	w13, [x8, x12]
    bcf4:      	add	x19, x8, x12
    bcf8:      	cmp	w23, w21
    bcfc:      	add	x2, x9, x10
    bd00:      	and	w1, w11, #0xff
    bd04:      	mov	w8, #0x4                // =4
    bd08:      	cinc	x0, x19, hi
    bd0c:      	blr	x8
    bd10:      	cmp	w23, w21
    bd14:      	str	x19, [sp, #0x60]
    bd18:      	add	x19, sp, #0x70
    bd1c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    bd20:      	ldr	x21, [sp, #0x78]
    bd24:      	ldp	x2, x24, [sp, #0x50]
    bd28:      	str	x21, [sp, #0x48]
    bd2c:      	b	0xbd7c <generic_kprobe_path+0x229c>
    bd30:      	add	x2, x24, #0x10
    bd34:      	mov	w8, #0x4                // =4
    bd38:      	add	x9, sp, #0x98
    bd3c:      	add	x0, sp, #0x98
    bd40:      	mov	w1, #0x8                // =8
    bd44:      	blr	x8
    bd48:      	ldr	x8, [sp, #0x58]
    bd4c:      	ldr	x9, [sp, #0x98]
    bd50:      	cmp	x8, x9
    bd54:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    bd58:      	add	x2, x24, #0x18
    bd5c:      	mov	w8, #0x4                // =4
    bd60:      	mov	x0, x22
    bd64:      	mov	w1, #0x8                // =8
    bd68:      	blr	x8
    bd6c:      	ldr	x24, [sp, #0x98]
    bd70:      	ldr	x21, [sp, #0x48]
    bd74:      	add	x2, x24, #0x20
    bd78:      	stp	x2, x24, [sp, #0x50]
    bd7c:      	ldr	x8, [sp, #0x30]
    bd80:      	cmp	x21, x8
    bd84:      	b.ne	0xbd94 <generic_kprobe_path+0x22b4>
    bd88:      	ldr	x8, [sp, #0x38]
    bd8c:      	cmp	x2, x8
    bd90:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    bd94:      	mov	w8, #0x4                // =4
    bd98:      	add	x0, sp, #0x70
    bd9c:      	mov	w1, #0x8                // =8
    bda0:      	blr	x8
    bda4:      	ldr	x8, [sp, #0x70]
    bda8:      	cmp	x21, x8
    bdac:      	b.eq	0xbe9c <generic_kprobe_path+0x23bc>
    bdb0:      	add	x23, x21, #0x18
    bdb4:      	mov	w8, #0x4                // =4
    bdb8:      	add	x9, sp, #0x98
    bdbc:      	add	x0, sp, #0x98
    bdc0:      	mov	w1, #0x8                // =8
    bdc4:      	mov	x2, x23
    bdc8:      	blr	x8
    bdcc:      	ldr	x8, [sp, #0x98]
    bdd0:      	cmp	x8, x21
    bdd4:      	b.eq	0xbe9c <generic_kprobe_path+0x23bc>
    bdd8:      	mov	w8, #0x4                // =4
    bddc:      	add	x9, sp, #0x78
    bde0:      	add	x0, sp, #0x78
    bde4:      	mov	w1, #0x8                // =8
    bde8:      	mov	x2, x23
    bdec:      	blr	x8
    bdf0:      	add	x2, x21, #0x20
    bdf4:      	mov	w8, #0x4                // =4
    bdf8:      	mov	w9, #0x10               // =16
    bdfc:      	add	x10, sp, #0x80
    be00:      	add	x0, sp, #0x80
    be04:      	mov	w1, #0x10               // =16
    be08:      	blr	x8
    be0c:      	ldr	w21, [sp, #0x84]
    be10:      	ldr	x8, [sp, #0x40]
    be14:      	ldr	x10, [sp, #0x60]
    be18:      	sub	x12, x10, x8
    be1c:      	ldr	w23, [sp, #0x68]
    be20:      	subs	w10, w21, w23
    be24:      	ldr	x9, [sp, #0x88]
    be28:      	csel	w10, wzr, w10, lo
    be2c:      	cmp	w23, w21
    be30:      	csel	w11, w23, w21, lo
    be34:      	cinc	w13, w11, hi
    be38:      	sub	w14, w23, w13
    be3c:      	subs	x12, x12, x13
    be40:      	str	w14, [sp, #0x68]
    be44:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    be48:      	cmp	x12, #0xfff
    be4c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    be50:      	cmp	w23, w21
    be54:      	b.ls	0xbe60 <generic_kprobe_path+0x2380>
    be58:      	mov	w13, #0x2f              // =47
    be5c:      	strb	w13, [x8, x12]
    be60:      	add	x19, x8, x12
    be64:      	cmp	w23, w21
    be68:      	add	x2, x9, x10
    be6c:      	and	w1, w11, #0xff
    be70:      	mov	w8, #0x4                // =4
    be74:      	cinc	x0, x19, hi
    be78:      	blr	x8
    be7c:      	cmp	w23, w21
    be80:      	str	x19, [sp, #0x60]
    be84:      	add	x19, sp, #0x70
    be88:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    be8c:      	ldr	x21, [sp, #0x78]
    be90:      	ldp	x2, x24, [sp, #0x50]
    be94:      	str	x21, [sp, #0x48]
    be98:      	b	0xbee8 <generic_kprobe_path+0x2408>
    be9c:      	add	x2, x24, #0x10
    bea0:      	mov	w8, #0x4                // =4
    bea4:      	add	x9, sp, #0x98
    bea8:      	add	x0, sp, #0x98
    beac:      	mov	w1, #0x8                // =8
    beb0:      	blr	x8
    beb4:      	ldr	x8, [sp, #0x58]
    beb8:      	ldr	x9, [sp, #0x98]
    bebc:      	cmp	x8, x9
    bec0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    bec4:      	add	x2, x24, #0x18
    bec8:      	mov	w8, #0x4                // =4
    becc:      	mov	x0, x22
    bed0:      	mov	w1, #0x8                // =8
    bed4:      	blr	x8
    bed8:      	ldr	x24, [sp, #0x98]
    bedc:      	ldr	x21, [sp, #0x48]
    bee0:      	add	x2, x24, #0x20
    bee4:      	stp	x2, x24, [sp, #0x50]
    bee8:      	ldr	x8, [sp, #0x30]
    beec:      	cmp	x21, x8
    bef0:      	b.ne	0xbf00 <generic_kprobe_path+0x2420>
    bef4:      	ldr	x8, [sp, #0x38]
    bef8:      	cmp	x2, x8
    befc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    bf00:      	mov	w8, #0x4                // =4
    bf04:      	add	x0, sp, #0x70
    bf08:      	mov	w1, #0x8                // =8
    bf0c:      	blr	x8
    bf10:      	ldr	x8, [sp, #0x70]
    bf14:      	cmp	x21, x8
    bf18:      	b.eq	0xc008 <generic_kprobe_path+0x2528>
    bf1c:      	add	x23, x21, #0x18
    bf20:      	mov	w8, #0x4                // =4
    bf24:      	add	x9, sp, #0x98
    bf28:      	add	x0, sp, #0x98
    bf2c:      	mov	w1, #0x8                // =8
    bf30:      	mov	x2, x23
    bf34:      	blr	x8
    bf38:      	ldr	x8, [sp, #0x98]
    bf3c:      	cmp	x8, x21
    bf40:      	b.eq	0xc008 <generic_kprobe_path+0x2528>
    bf44:      	mov	w8, #0x4                // =4
    bf48:      	add	x9, sp, #0x78
    bf4c:      	add	x0, sp, #0x78
    bf50:      	mov	w1, #0x8                // =8
    bf54:      	mov	x2, x23
    bf58:      	blr	x8
    bf5c:      	add	x2, x21, #0x20
    bf60:      	mov	w8, #0x4                // =4
    bf64:      	mov	w9, #0x10               // =16
    bf68:      	add	x10, sp, #0x80
    bf6c:      	add	x0, sp, #0x80
    bf70:      	mov	w1, #0x10               // =16
    bf74:      	blr	x8
    bf78:      	ldr	w21, [sp, #0x84]
    bf7c:      	ldr	x8, [sp, #0x40]
    bf80:      	ldr	x10, [sp, #0x60]
    bf84:      	sub	x12, x10, x8
    bf88:      	ldr	w23, [sp, #0x68]
    bf8c:      	subs	w10, w21, w23
    bf90:      	ldr	x9, [sp, #0x88]
    bf94:      	csel	w10, wzr, w10, lo
    bf98:      	cmp	w23, w21
    bf9c:      	csel	w11, w23, w21, lo
    bfa0:      	cinc	w13, w11, hi
    bfa4:      	sub	w14, w23, w13
    bfa8:      	subs	x12, x12, x13
    bfac:      	str	w14, [sp, #0x68]
    bfb0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    bfb4:      	cmp	x12, #0xfff
    bfb8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    bfbc:      	cmp	w23, w21
    bfc0:      	b.ls	0xbfcc <generic_kprobe_path+0x24ec>
    bfc4:      	mov	w13, #0x2f              // =47
    bfc8:      	strb	w13, [x8, x12]
    bfcc:      	add	x19, x8, x12
    bfd0:      	cmp	w23, w21
    bfd4:      	add	x2, x9, x10
    bfd8:      	and	w1, w11, #0xff
    bfdc:      	mov	w8, #0x4                // =4
    bfe0:      	cinc	x0, x19, hi
    bfe4:      	blr	x8
    bfe8:      	cmp	w23, w21
    bfec:      	str	x19, [sp, #0x60]
    bff0:      	add	x19, sp, #0x70
    bff4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    bff8:      	ldr	x21, [sp, #0x78]
    bffc:      	ldp	x2, x24, [sp, #0x50]
    c000:      	str	x21, [sp, #0x48]
    c004:      	b	0xc054 <generic_kprobe_path+0x2574>
    c008:      	add	x2, x24, #0x10
    c00c:      	mov	w8, #0x4                // =4
    c010:      	add	x9, sp, #0x98
    c014:      	add	x0, sp, #0x98
    c018:      	mov	w1, #0x8                // =8
    c01c:      	blr	x8
    c020:      	ldr	x8, [sp, #0x58]
    c024:      	ldr	x9, [sp, #0x98]
    c028:      	cmp	x8, x9
    c02c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c030:      	add	x2, x24, #0x18
    c034:      	mov	w8, #0x4                // =4
    c038:      	mov	x0, x22
    c03c:      	mov	w1, #0x8                // =8
    c040:      	blr	x8
    c044:      	ldr	x24, [sp, #0x98]
    c048:      	ldr	x21, [sp, #0x48]
    c04c:      	add	x2, x24, #0x20
    c050:      	stp	x2, x24, [sp, #0x50]
    c054:      	ldr	x8, [sp, #0x30]
    c058:      	cmp	x21, x8
    c05c:      	b.ne	0xc06c <generic_kprobe_path+0x258c>
    c060:      	ldr	x8, [sp, #0x38]
    c064:      	cmp	x2, x8
    c068:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c06c:      	mov	w8, #0x4                // =4
    c070:      	add	x0, sp, #0x70
    c074:      	mov	w1, #0x8                // =8
    c078:      	blr	x8
    c07c:      	ldr	x8, [sp, #0x70]
    c080:      	cmp	x21, x8
    c084:      	b.eq	0xc174 <generic_kprobe_path+0x2694>
    c088:      	add	x23, x21, #0x18
    c08c:      	mov	w8, #0x4                // =4
    c090:      	add	x9, sp, #0x98
    c094:      	add	x0, sp, #0x98
    c098:      	mov	w1, #0x8                // =8
    c09c:      	mov	x2, x23
    c0a0:      	blr	x8
    c0a4:      	ldr	x8, [sp, #0x98]
    c0a8:      	cmp	x8, x21
    c0ac:      	b.eq	0xc174 <generic_kprobe_path+0x2694>
    c0b0:      	mov	w8, #0x4                // =4
    c0b4:      	add	x9, sp, #0x78
    c0b8:      	add	x0, sp, #0x78
    c0bc:      	mov	w1, #0x8                // =8
    c0c0:      	mov	x2, x23
    c0c4:      	blr	x8
    c0c8:      	add	x2, x21, #0x20
    c0cc:      	mov	w8, #0x4                // =4
    c0d0:      	mov	w9, #0x10               // =16
    c0d4:      	add	x10, sp, #0x80
    c0d8:      	add	x0, sp, #0x80
    c0dc:      	mov	w1, #0x10               // =16
    c0e0:      	blr	x8
    c0e4:      	ldr	w21, [sp, #0x84]
    c0e8:      	ldr	x8, [sp, #0x40]
    c0ec:      	ldr	x10, [sp, #0x60]
    c0f0:      	sub	x12, x10, x8
    c0f4:      	ldr	w23, [sp, #0x68]
    c0f8:      	subs	w10, w21, w23
    c0fc:      	ldr	x9, [sp, #0x88]
    c100:      	csel	w10, wzr, w10, lo
    c104:      	cmp	w23, w21
    c108:      	csel	w11, w23, w21, lo
    c10c:      	cinc	w13, w11, hi
    c110:      	sub	w14, w23, w13
    c114:      	subs	x12, x12, x13
    c118:      	str	w14, [sp, #0x68]
    c11c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c120:      	cmp	x12, #0xfff
    c124:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c128:      	cmp	w23, w21
    c12c:      	b.ls	0xc138 <generic_kprobe_path+0x2658>
    c130:      	mov	w13, #0x2f              // =47
    c134:      	strb	w13, [x8, x12]
    c138:      	add	x19, x8, x12
    c13c:      	cmp	w23, w21
    c140:      	add	x2, x9, x10
    c144:      	and	w1, w11, #0xff
    c148:      	mov	w8, #0x4                // =4
    c14c:      	cinc	x0, x19, hi
    c150:      	blr	x8
    c154:      	cmp	w23, w21
    c158:      	str	x19, [sp, #0x60]
    c15c:      	add	x19, sp, #0x70
    c160:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c164:      	ldr	x21, [sp, #0x78]
    c168:      	ldp	x2, x24, [sp, #0x50]
    c16c:      	str	x21, [sp, #0x48]
    c170:      	b	0xc1c0 <generic_kprobe_path+0x26e0>
    c174:      	add	x2, x24, #0x10
    c178:      	mov	w8, #0x4                // =4
    c17c:      	add	x9, sp, #0x98
    c180:      	add	x0, sp, #0x98
    c184:      	mov	w1, #0x8                // =8
    c188:      	blr	x8
    c18c:      	ldr	x8, [sp, #0x58]
    c190:      	ldr	x9, [sp, #0x98]
    c194:      	cmp	x8, x9
    c198:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c19c:      	add	x2, x24, #0x18
    c1a0:      	mov	w8, #0x4                // =4
    c1a4:      	mov	x0, x22
    c1a8:      	mov	w1, #0x8                // =8
    c1ac:      	blr	x8
    c1b0:      	ldr	x24, [sp, #0x98]
    c1b4:      	ldr	x21, [sp, #0x48]
    c1b8:      	add	x2, x24, #0x20
    c1bc:      	stp	x2, x24, [sp, #0x50]
    c1c0:      	ldr	x8, [sp, #0x30]
    c1c4:      	cmp	x21, x8
    c1c8:      	b.ne	0xc1d8 <generic_kprobe_path+0x26f8>
    c1cc:      	ldr	x8, [sp, #0x38]
    c1d0:      	cmp	x2, x8
    c1d4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c1d8:      	mov	w8, #0x4                // =4
    c1dc:      	add	x0, sp, #0x70
    c1e0:      	mov	w1, #0x8                // =8
    c1e4:      	blr	x8
    c1e8:      	ldr	x8, [sp, #0x70]
    c1ec:      	cmp	x21, x8
    c1f0:      	b.eq	0xc2e0 <generic_kprobe_path+0x2800>
    c1f4:      	add	x23, x21, #0x18
    c1f8:      	mov	w8, #0x4                // =4
    c1fc:      	add	x9, sp, #0x98
    c200:      	add	x0, sp, #0x98
    c204:      	mov	w1, #0x8                // =8
    c208:      	mov	x2, x23
    c20c:      	blr	x8
    c210:      	ldr	x8, [sp, #0x98]
    c214:      	cmp	x8, x21
    c218:      	b.eq	0xc2e0 <generic_kprobe_path+0x2800>
    c21c:      	mov	w8, #0x4                // =4
    c220:      	add	x9, sp, #0x78
    c224:      	add	x0, sp, #0x78
    c228:      	mov	w1, #0x8                // =8
    c22c:      	mov	x2, x23
    c230:      	blr	x8
    c234:      	add	x2, x21, #0x20
    c238:      	mov	w8, #0x4                // =4
    c23c:      	mov	w9, #0x10               // =16
    c240:      	add	x10, sp, #0x80
    c244:      	add	x0, sp, #0x80
    c248:      	mov	w1, #0x10               // =16
    c24c:      	blr	x8
    c250:      	ldr	w21, [sp, #0x84]
    c254:      	ldr	x8, [sp, #0x40]
    c258:      	ldr	x10, [sp, #0x60]
    c25c:      	sub	x12, x10, x8
    c260:      	ldr	w23, [sp, #0x68]
    c264:      	subs	w10, w21, w23
    c268:      	ldr	x9, [sp, #0x88]
    c26c:      	csel	w10, wzr, w10, lo
    c270:      	cmp	w23, w21
    c274:      	csel	w11, w23, w21, lo
    c278:      	cinc	w13, w11, hi
    c27c:      	sub	w14, w23, w13
    c280:      	subs	x12, x12, x13
    c284:      	str	w14, [sp, #0x68]
    c288:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c28c:      	cmp	x12, #0xfff
    c290:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c294:      	cmp	w23, w21
    c298:      	b.ls	0xc2a4 <generic_kprobe_path+0x27c4>
    c29c:      	mov	w13, #0x2f              // =47
    c2a0:      	strb	w13, [x8, x12]
    c2a4:      	add	x19, x8, x12
    c2a8:      	cmp	w23, w21
    c2ac:      	add	x2, x9, x10
    c2b0:      	and	w1, w11, #0xff
    c2b4:      	mov	w8, #0x4                // =4
    c2b8:      	cinc	x0, x19, hi
    c2bc:      	blr	x8
    c2c0:      	cmp	w23, w21
    c2c4:      	str	x19, [sp, #0x60]
    c2c8:      	add	x19, sp, #0x70
    c2cc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c2d0:      	ldr	x21, [sp, #0x78]
    c2d4:      	ldp	x2, x24, [sp, #0x50]
    c2d8:      	str	x21, [sp, #0x48]
    c2dc:      	b	0xc32c <generic_kprobe_path+0x284c>
    c2e0:      	add	x2, x24, #0x10
    c2e4:      	mov	w8, #0x4                // =4
    c2e8:      	add	x9, sp, #0x98
    c2ec:      	add	x0, sp, #0x98
    c2f0:      	mov	w1, #0x8                // =8
    c2f4:      	blr	x8
    c2f8:      	ldr	x8, [sp, #0x58]
    c2fc:      	ldr	x9, [sp, #0x98]
    c300:      	cmp	x8, x9
    c304:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c308:      	add	x2, x24, #0x18
    c30c:      	mov	w8, #0x4                // =4
    c310:      	mov	x0, x22
    c314:      	mov	w1, #0x8                // =8
    c318:      	blr	x8
    c31c:      	ldr	x24, [sp, #0x98]
    c320:      	ldr	x21, [sp, #0x48]
    c324:      	add	x2, x24, #0x20
    c328:      	stp	x2, x24, [sp, #0x50]
    c32c:      	ldr	x8, [sp, #0x30]
    c330:      	cmp	x21, x8
    c334:      	b.ne	0xc344 <generic_kprobe_path+0x2864>
    c338:      	ldr	x8, [sp, #0x38]
    c33c:      	cmp	x2, x8
    c340:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c344:      	mov	w8, #0x4                // =4
    c348:      	add	x0, sp, #0x70
    c34c:      	mov	w1, #0x8                // =8
    c350:      	blr	x8
    c354:      	ldr	x8, [sp, #0x70]
    c358:      	cmp	x21, x8
    c35c:      	b.eq	0xc44c <generic_kprobe_path+0x296c>
    c360:      	add	x23, x21, #0x18
    c364:      	mov	w8, #0x4                // =4
    c368:      	add	x9, sp, #0x98
    c36c:      	add	x0, sp, #0x98
    c370:      	mov	w1, #0x8                // =8
    c374:      	mov	x2, x23
    c378:      	blr	x8
    c37c:      	ldr	x8, [sp, #0x98]
    c380:      	cmp	x8, x21
    c384:      	b.eq	0xc44c <generic_kprobe_path+0x296c>
    c388:      	mov	w8, #0x4                // =4
    c38c:      	add	x9, sp, #0x78
    c390:      	add	x0, sp, #0x78
    c394:      	mov	w1, #0x8                // =8
    c398:      	mov	x2, x23
    c39c:      	blr	x8
    c3a0:      	add	x2, x21, #0x20
    c3a4:      	mov	w8, #0x4                // =4
    c3a8:      	mov	w9, #0x10               // =16
    c3ac:      	add	x10, sp, #0x80
    c3b0:      	add	x0, sp, #0x80
    c3b4:      	mov	w1, #0x10               // =16
    c3b8:      	blr	x8
    c3bc:      	ldr	w21, [sp, #0x84]
    c3c0:      	ldr	x8, [sp, #0x40]
    c3c4:      	ldr	x10, [sp, #0x60]
    c3c8:      	sub	x12, x10, x8
    c3cc:      	ldr	w23, [sp, #0x68]
    c3d0:      	subs	w10, w21, w23
    c3d4:      	ldr	x9, [sp, #0x88]
    c3d8:      	csel	w10, wzr, w10, lo
    c3dc:      	cmp	w23, w21
    c3e0:      	csel	w11, w23, w21, lo
    c3e4:      	cinc	w13, w11, hi
    c3e8:      	sub	w14, w23, w13
    c3ec:      	subs	x12, x12, x13
    c3f0:      	str	w14, [sp, #0x68]
    c3f4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c3f8:      	cmp	x12, #0xfff
    c3fc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c400:      	cmp	w23, w21
    c404:      	b.ls	0xc410 <generic_kprobe_path+0x2930>
    c408:      	mov	w13, #0x2f              // =47
    c40c:      	strb	w13, [x8, x12]
    c410:      	add	x19, x8, x12
    c414:      	cmp	w23, w21
    c418:      	add	x2, x9, x10
    c41c:      	and	w1, w11, #0xff
    c420:      	mov	w8, #0x4                // =4
    c424:      	cinc	x0, x19, hi
    c428:      	blr	x8
    c42c:      	cmp	w23, w21
    c430:      	str	x19, [sp, #0x60]
    c434:      	add	x19, sp, #0x70
    c438:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c43c:      	ldr	x21, [sp, #0x78]
    c440:      	ldp	x2, x24, [sp, #0x50]
    c444:      	str	x21, [sp, #0x48]
    c448:      	b	0xc498 <generic_kprobe_path+0x29b8>
    c44c:      	add	x2, x24, #0x10
    c450:      	mov	w8, #0x4                // =4
    c454:      	add	x9, sp, #0x98
    c458:      	add	x0, sp, #0x98
    c45c:      	mov	w1, #0x8                // =8
    c460:      	blr	x8
    c464:      	ldr	x8, [sp, #0x58]
    c468:      	ldr	x9, [sp, #0x98]
    c46c:      	cmp	x8, x9
    c470:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c474:      	add	x2, x24, #0x18
    c478:      	mov	w8, #0x4                // =4
    c47c:      	mov	x0, x22
    c480:      	mov	w1, #0x8                // =8
    c484:      	blr	x8
    c488:      	ldr	x24, [sp, #0x98]
    c48c:      	ldr	x21, [sp, #0x48]
    c490:      	add	x2, x24, #0x20
    c494:      	stp	x2, x24, [sp, #0x50]
    c498:      	ldr	x8, [sp, #0x30]
    c49c:      	cmp	x21, x8
    c4a0:      	b.ne	0xc4b0 <generic_kprobe_path+0x29d0>
    c4a4:      	ldr	x8, [sp, #0x38]
    c4a8:      	cmp	x2, x8
    c4ac:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c4b0:      	mov	w8, #0x4                // =4
    c4b4:      	add	x0, sp, #0x70
    c4b8:      	mov	w1, #0x8                // =8
    c4bc:      	blr	x8
    c4c0:      	ldr	x8, [sp, #0x70]
    c4c4:      	cmp	x21, x8
    c4c8:      	b.eq	0xc5b8 <generic_kprobe_path+0x2ad8>
    c4cc:      	add	x23, x21, #0x18
    c4d0:      	mov	w8, #0x4                // =4
    c4d4:      	add	x9, sp, #0x98
    c4d8:      	add	x0, sp, #0x98
    c4dc:      	mov	w1, #0x8                // =8
    c4e0:      	mov	x2, x23
    c4e4:      	blr	x8
    c4e8:      	ldr	x8, [sp, #0x98]
    c4ec:      	cmp	x8, x21
    c4f0:      	b.eq	0xc5b8 <generic_kprobe_path+0x2ad8>
    c4f4:      	mov	w8, #0x4                // =4
    c4f8:      	add	x9, sp, #0x78
    c4fc:      	add	x0, sp, #0x78
    c500:      	mov	w1, #0x8                // =8
    c504:      	mov	x2, x23
    c508:      	blr	x8
    c50c:      	add	x2, x21, #0x20
    c510:      	mov	w8, #0x4                // =4
    c514:      	mov	w9, #0x10               // =16
    c518:      	add	x10, sp, #0x80
    c51c:      	add	x0, sp, #0x80
    c520:      	mov	w1, #0x10               // =16
    c524:      	blr	x8
    c528:      	ldr	w21, [sp, #0x84]
    c52c:      	ldr	x8, [sp, #0x40]
    c530:      	ldr	x10, [sp, #0x60]
    c534:      	sub	x12, x10, x8
    c538:      	ldr	w23, [sp, #0x68]
    c53c:      	subs	w10, w21, w23
    c540:      	ldr	x9, [sp, #0x88]
    c544:      	csel	w10, wzr, w10, lo
    c548:      	cmp	w23, w21
    c54c:      	csel	w11, w23, w21, lo
    c550:      	cinc	w13, w11, hi
    c554:      	sub	w14, w23, w13
    c558:      	subs	x12, x12, x13
    c55c:      	str	w14, [sp, #0x68]
    c560:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c564:      	cmp	x12, #0xfff
    c568:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c56c:      	cmp	w23, w21
    c570:      	b.ls	0xc57c <generic_kprobe_path+0x2a9c>
    c574:      	mov	w13, #0x2f              // =47
    c578:      	strb	w13, [x8, x12]
    c57c:      	add	x19, x8, x12
    c580:      	cmp	w23, w21
    c584:      	add	x2, x9, x10
    c588:      	and	w1, w11, #0xff
    c58c:      	mov	w8, #0x4                // =4
    c590:      	cinc	x0, x19, hi
    c594:      	blr	x8
    c598:      	cmp	w23, w21
    c59c:      	str	x19, [sp, #0x60]
    c5a0:      	add	x19, sp, #0x70
    c5a4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c5a8:      	ldr	x21, [sp, #0x78]
    c5ac:      	ldp	x2, x24, [sp, #0x50]
    c5b0:      	str	x21, [sp, #0x48]
    c5b4:      	b	0xc604 <generic_kprobe_path+0x2b24>
    c5b8:      	add	x2, x24, #0x10
    c5bc:      	mov	w8, #0x4                // =4
    c5c0:      	add	x9, sp, #0x98
    c5c4:      	add	x0, sp, #0x98
    c5c8:      	mov	w1, #0x8                // =8
    c5cc:      	blr	x8
    c5d0:      	ldr	x8, [sp, #0x58]
    c5d4:      	ldr	x9, [sp, #0x98]
    c5d8:      	cmp	x8, x9
    c5dc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c5e0:      	add	x2, x24, #0x18
    c5e4:      	mov	w8, #0x4                // =4
    c5e8:      	mov	x0, x22
    c5ec:      	mov	w1, #0x8                // =8
    c5f0:      	blr	x8
    c5f4:      	ldr	x24, [sp, #0x98]
    c5f8:      	ldr	x21, [sp, #0x48]
    c5fc:      	add	x2, x24, #0x20
    c600:      	stp	x2, x24, [sp, #0x50]
    c604:      	ldr	x8, [sp, #0x30]
    c608:      	cmp	x21, x8
    c60c:      	b.ne	0xc61c <generic_kprobe_path+0x2b3c>
    c610:      	ldr	x8, [sp, #0x38]
    c614:      	cmp	x2, x8
    c618:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c61c:      	mov	w8, #0x4                // =4
    c620:      	add	x0, sp, #0x70
    c624:      	mov	w1, #0x8                // =8
    c628:      	blr	x8
    c62c:      	ldr	x8, [sp, #0x70]
    c630:      	cmp	x21, x8
    c634:      	b.eq	0xc724 <generic_kprobe_path+0x2c44>
    c638:      	add	x23, x21, #0x18
    c63c:      	mov	w8, #0x4                // =4
    c640:      	add	x9, sp, #0x98
    c644:      	add	x0, sp, #0x98
    c648:      	mov	w1, #0x8                // =8
    c64c:      	mov	x2, x23
    c650:      	blr	x8
    c654:      	ldr	x8, [sp, #0x98]
    c658:      	cmp	x8, x21
    c65c:      	b.eq	0xc724 <generic_kprobe_path+0x2c44>
    c660:      	mov	w8, #0x4                // =4
    c664:      	add	x9, sp, #0x78
    c668:      	add	x0, sp, #0x78
    c66c:      	mov	w1, #0x8                // =8
    c670:      	mov	x2, x23
    c674:      	blr	x8
    c678:      	add	x2, x21, #0x20
    c67c:      	mov	w8, #0x4                // =4
    c680:      	mov	w9, #0x10               // =16
    c684:      	add	x10, sp, #0x80
    c688:      	add	x0, sp, #0x80
    c68c:      	mov	w1, #0x10               // =16
    c690:      	blr	x8
    c694:      	ldr	w21, [sp, #0x84]
    c698:      	ldr	x8, [sp, #0x40]
    c69c:      	ldr	x10, [sp, #0x60]
    c6a0:      	sub	x12, x10, x8
    c6a4:      	ldr	w23, [sp, #0x68]
    c6a8:      	subs	w10, w21, w23
    c6ac:      	ldr	x9, [sp, #0x88]
    c6b0:      	csel	w10, wzr, w10, lo
    c6b4:      	cmp	w23, w21
    c6b8:      	csel	w11, w23, w21, lo
    c6bc:      	cinc	w13, w11, hi
    c6c0:      	sub	w14, w23, w13
    c6c4:      	subs	x12, x12, x13
    c6c8:      	str	w14, [sp, #0x68]
    c6cc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c6d0:      	cmp	x12, #0xfff
    c6d4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c6d8:      	cmp	w23, w21
    c6dc:      	b.ls	0xc6e8 <generic_kprobe_path+0x2c08>
    c6e0:      	mov	w13, #0x2f              // =47
    c6e4:      	strb	w13, [x8, x12]
    c6e8:      	add	x19, x8, x12
    c6ec:      	cmp	w23, w21
    c6f0:      	add	x2, x9, x10
    c6f4:      	and	w1, w11, #0xff
    c6f8:      	mov	w8, #0x4                // =4
    c6fc:      	cinc	x0, x19, hi
    c700:      	blr	x8
    c704:      	cmp	w23, w21
    c708:      	str	x19, [sp, #0x60]
    c70c:      	add	x19, sp, #0x70
    c710:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c714:      	ldr	x21, [sp, #0x78]
    c718:      	ldp	x2, x24, [sp, #0x50]
    c71c:      	str	x21, [sp, #0x48]
    c720:      	b	0xc770 <generic_kprobe_path+0x2c90>
    c724:      	add	x2, x24, #0x10
    c728:      	mov	w8, #0x4                // =4
    c72c:      	add	x9, sp, #0x98
    c730:      	add	x0, sp, #0x98
    c734:      	mov	w1, #0x8                // =8
    c738:      	blr	x8
    c73c:      	ldr	x8, [sp, #0x58]
    c740:      	ldr	x9, [sp, #0x98]
    c744:      	cmp	x8, x9
    c748:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c74c:      	add	x2, x24, #0x18
    c750:      	mov	w8, #0x4                // =4
    c754:      	mov	x0, x22
    c758:      	mov	w1, #0x8                // =8
    c75c:      	blr	x8
    c760:      	ldr	x24, [sp, #0x98]
    c764:      	ldr	x21, [sp, #0x48]
    c768:      	add	x2, x24, #0x20
    c76c:      	stp	x2, x24, [sp, #0x50]
    c770:      	ldr	x8, [sp, #0x30]
    c774:      	cmp	x21, x8
    c778:      	b.ne	0xc788 <generic_kprobe_path+0x2ca8>
    c77c:      	ldr	x8, [sp, #0x38]
    c780:      	cmp	x2, x8
    c784:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c788:      	mov	w8, #0x4                // =4
    c78c:      	add	x0, sp, #0x70
    c790:      	mov	w1, #0x8                // =8
    c794:      	blr	x8
    c798:      	ldr	x8, [sp, #0x70]
    c79c:      	cmp	x21, x8
    c7a0:      	b.eq	0xc890 <generic_kprobe_path+0x2db0>
    c7a4:      	add	x23, x21, #0x18
    c7a8:      	mov	w8, #0x4                // =4
    c7ac:      	add	x9, sp, #0x98
    c7b0:      	add	x0, sp, #0x98
    c7b4:      	mov	w1, #0x8                // =8
    c7b8:      	mov	x2, x23
    c7bc:      	blr	x8
    c7c0:      	ldr	x8, [sp, #0x98]
    c7c4:      	cmp	x8, x21
    c7c8:      	b.eq	0xc890 <generic_kprobe_path+0x2db0>
    c7cc:      	mov	w8, #0x4                // =4
    c7d0:      	add	x9, sp, #0x78
    c7d4:      	add	x0, sp, #0x78
    c7d8:      	mov	w1, #0x8                // =8
    c7dc:      	mov	x2, x23
    c7e0:      	blr	x8
    c7e4:      	add	x2, x21, #0x20
    c7e8:      	mov	w8, #0x4                // =4
    c7ec:      	mov	w9, #0x10               // =16
    c7f0:      	add	x10, sp, #0x80
    c7f4:      	add	x0, sp, #0x80
    c7f8:      	mov	w1, #0x10               // =16
    c7fc:      	blr	x8
    c800:      	ldr	w21, [sp, #0x84]
    c804:      	ldr	x8, [sp, #0x40]
    c808:      	ldr	x10, [sp, #0x60]
    c80c:      	sub	x12, x10, x8
    c810:      	ldr	w23, [sp, #0x68]
    c814:      	subs	w10, w21, w23
    c818:      	ldr	x9, [sp, #0x88]
    c81c:      	csel	w10, wzr, w10, lo
    c820:      	cmp	w23, w21
    c824:      	csel	w11, w23, w21, lo
    c828:      	cinc	w13, w11, hi
    c82c:      	sub	w14, w23, w13
    c830:      	subs	x12, x12, x13
    c834:      	str	w14, [sp, #0x68]
    c838:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c83c:      	cmp	x12, #0xfff
    c840:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c844:      	cmp	w23, w21
    c848:      	b.ls	0xc854 <generic_kprobe_path+0x2d74>
    c84c:      	mov	w13, #0x2f              // =47
    c850:      	strb	w13, [x8, x12]
    c854:      	add	x19, x8, x12
    c858:      	cmp	w23, w21
    c85c:      	add	x2, x9, x10
    c860:      	and	w1, w11, #0xff
    c864:      	mov	w8, #0x4                // =4
    c868:      	cinc	x0, x19, hi
    c86c:      	blr	x8
    c870:      	cmp	w23, w21
    c874:      	str	x19, [sp, #0x60]
    c878:      	add	x19, sp, #0x70
    c87c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c880:      	ldr	x21, [sp, #0x78]
    c884:      	ldp	x2, x24, [sp, #0x50]
    c888:      	str	x21, [sp, #0x48]
    c88c:      	b	0xc8dc <generic_kprobe_path+0x2dfc>
    c890:      	add	x2, x24, #0x10
    c894:      	mov	w8, #0x4                // =4
    c898:      	add	x9, sp, #0x98
    c89c:      	add	x0, sp, #0x98
    c8a0:      	mov	w1, #0x8                // =8
    c8a4:      	blr	x8
    c8a8:      	ldr	x8, [sp, #0x58]
    c8ac:      	ldr	x9, [sp, #0x98]
    c8b0:      	cmp	x8, x9
    c8b4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c8b8:      	add	x2, x24, #0x18
    c8bc:      	mov	w8, #0x4                // =4
    c8c0:      	mov	x0, x22
    c8c4:      	mov	w1, #0x8                // =8
    c8c8:      	blr	x8
    c8cc:      	ldr	x24, [sp, #0x98]
    c8d0:      	ldr	x21, [sp, #0x48]
    c8d4:      	add	x2, x24, #0x20
    c8d8:      	stp	x2, x24, [sp, #0x50]
    c8dc:      	ldr	x8, [sp, #0x30]
    c8e0:      	cmp	x21, x8
    c8e4:      	b.ne	0xc8f4 <generic_kprobe_path+0x2e14>
    c8e8:      	ldr	x8, [sp, #0x38]
    c8ec:      	cmp	x2, x8
    c8f0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    c8f4:      	mov	w8, #0x4                // =4
    c8f8:      	add	x0, sp, #0x70
    c8fc:      	mov	w1, #0x8                // =8
    c900:      	blr	x8
    c904:      	ldr	x8, [sp, #0x70]
    c908:      	cmp	x21, x8
    c90c:      	b.eq	0xc9fc <generic_kprobe_path+0x2f1c>
    c910:      	add	x23, x21, #0x18
    c914:      	mov	w8, #0x4                // =4
    c918:      	add	x9, sp, #0x98
    c91c:      	add	x0, sp, #0x98
    c920:      	mov	w1, #0x8                // =8
    c924:      	mov	x2, x23
    c928:      	blr	x8
    c92c:      	ldr	x8, [sp, #0x98]
    c930:      	cmp	x8, x21
    c934:      	b.eq	0xc9fc <generic_kprobe_path+0x2f1c>
    c938:      	mov	w8, #0x4                // =4
    c93c:      	add	x9, sp, #0x78
    c940:      	add	x0, sp, #0x78
    c944:      	mov	w1, #0x8                // =8
    c948:      	mov	x2, x23
    c94c:      	blr	x8
    c950:      	add	x2, x21, #0x20
    c954:      	mov	w8, #0x4                // =4
    c958:      	mov	w9, #0x10               // =16
    c95c:      	add	x10, sp, #0x80
    c960:      	add	x0, sp, #0x80
    c964:      	mov	w1, #0x10               // =16
    c968:      	blr	x8
    c96c:      	ldr	w21, [sp, #0x84]
    c970:      	ldr	x8, [sp, #0x40]
    c974:      	ldr	x10, [sp, #0x60]
    c978:      	sub	x12, x10, x8
    c97c:      	ldr	w23, [sp, #0x68]
    c980:      	subs	w10, w21, w23
    c984:      	ldr	x9, [sp, #0x88]
    c988:      	csel	w10, wzr, w10, lo
    c98c:      	cmp	w23, w21
    c990:      	csel	w11, w23, w21, lo
    c994:      	cinc	w13, w11, hi
    c998:      	sub	w14, w23, w13
    c99c:      	subs	x12, x12, x13
    c9a0:      	str	w14, [sp, #0x68]
    c9a4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    c9a8:      	cmp	x12, #0xfff
    c9ac:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    c9b0:      	cmp	w23, w21
    c9b4:      	b.ls	0xc9c0 <generic_kprobe_path+0x2ee0>
    c9b8:      	mov	w13, #0x2f              // =47
    c9bc:      	strb	w13, [x8, x12]
    c9c0:      	add	x19, x8, x12
    c9c4:      	cmp	w23, w21
    c9c8:      	add	x2, x9, x10
    c9cc:      	and	w1, w11, #0xff
    c9d0:      	mov	w8, #0x4                // =4
    c9d4:      	cinc	x0, x19, hi
    c9d8:      	blr	x8
    c9dc:      	cmp	w23, w21
    c9e0:      	str	x19, [sp, #0x60]
    c9e4:      	add	x19, sp, #0x70
    c9e8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    c9ec:      	ldr	x21, [sp, #0x78]
    c9f0:      	ldp	x2, x24, [sp, #0x50]
    c9f4:      	str	x21, [sp, #0x48]
    c9f8:      	b	0xca48 <generic_kprobe_path+0x2f68>
    c9fc:      	add	x2, x24, #0x10
    ca00:      	mov	w8, #0x4                // =4
    ca04:      	add	x9, sp, #0x98
    ca08:      	add	x0, sp, #0x98
    ca0c:      	mov	w1, #0x8                // =8
    ca10:      	blr	x8
    ca14:      	ldr	x8, [sp, #0x58]
    ca18:      	ldr	x9, [sp, #0x98]
    ca1c:      	cmp	x8, x9
    ca20:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ca24:      	add	x2, x24, #0x18
    ca28:      	mov	w8, #0x4                // =4
    ca2c:      	mov	x0, x22
    ca30:      	mov	w1, #0x8                // =8
    ca34:      	blr	x8
    ca38:      	ldr	x24, [sp, #0x98]
    ca3c:      	ldr	x21, [sp, #0x48]
    ca40:      	add	x2, x24, #0x20
    ca44:      	stp	x2, x24, [sp, #0x50]
    ca48:      	ldr	x8, [sp, #0x30]
    ca4c:      	cmp	x21, x8
    ca50:      	b.ne	0xca60 <generic_kprobe_path+0x2f80>
    ca54:      	ldr	x8, [sp, #0x38]
    ca58:      	cmp	x2, x8
    ca5c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ca60:      	mov	w8, #0x4                // =4
    ca64:      	add	x0, sp, #0x70
    ca68:      	mov	w1, #0x8                // =8
    ca6c:      	blr	x8
    ca70:      	ldr	x8, [sp, #0x70]
    ca74:      	cmp	x21, x8
    ca78:      	b.eq	0xcb68 <generic_kprobe_path+0x3088>
    ca7c:      	add	x23, x21, #0x18
    ca80:      	mov	w8, #0x4                // =4
    ca84:      	add	x9, sp, #0x98
    ca88:      	add	x0, sp, #0x98
    ca8c:      	mov	w1, #0x8                // =8
    ca90:      	mov	x2, x23
    ca94:      	blr	x8
    ca98:      	ldr	x8, [sp, #0x98]
    ca9c:      	cmp	x8, x21
    caa0:      	b.eq	0xcb68 <generic_kprobe_path+0x3088>
    caa4:      	mov	w8, #0x4                // =4
    caa8:      	add	x9, sp, #0x78
    caac:      	add	x0, sp, #0x78
    cab0:      	mov	w1, #0x8                // =8
    cab4:      	mov	x2, x23
    cab8:      	blr	x8
    cabc:      	add	x2, x21, #0x20
    cac0:      	mov	w8, #0x4                // =4
    cac4:      	mov	w9, #0x10               // =16
    cac8:      	add	x10, sp, #0x80
    cacc:      	add	x0, sp, #0x80
    cad0:      	mov	w1, #0x10               // =16
    cad4:      	blr	x8
    cad8:      	ldr	w21, [sp, #0x84]
    cadc:      	ldr	x8, [sp, #0x40]
    cae0:      	ldr	x10, [sp, #0x60]
    cae4:      	sub	x12, x10, x8
    cae8:      	ldr	w23, [sp, #0x68]
    caec:      	subs	w10, w21, w23
    caf0:      	ldr	x9, [sp, #0x88]
    caf4:      	csel	w10, wzr, w10, lo
    caf8:      	cmp	w23, w21
    cafc:      	csel	w11, w23, w21, lo
    cb00:      	cinc	w13, w11, hi
    cb04:      	sub	w14, w23, w13
    cb08:      	subs	x12, x12, x13
    cb0c:      	str	w14, [sp, #0x68]
    cb10:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    cb14:      	cmp	x12, #0xfff
    cb18:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    cb1c:      	cmp	w23, w21
    cb20:      	b.ls	0xcb2c <generic_kprobe_path+0x304c>
    cb24:      	mov	w13, #0x2f              // =47
    cb28:      	strb	w13, [x8, x12]
    cb2c:      	add	x19, x8, x12
    cb30:      	cmp	w23, w21
    cb34:      	add	x2, x9, x10
    cb38:      	and	w1, w11, #0xff
    cb3c:      	mov	w8, #0x4                // =4
    cb40:      	cinc	x0, x19, hi
    cb44:      	blr	x8
    cb48:      	cmp	w23, w21
    cb4c:      	str	x19, [sp, #0x60]
    cb50:      	add	x19, sp, #0x70
    cb54:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    cb58:      	ldr	x21, [sp, #0x78]
    cb5c:      	ldp	x2, x24, [sp, #0x50]
    cb60:      	str	x21, [sp, #0x48]
    cb64:      	b	0xcbb4 <generic_kprobe_path+0x30d4>
    cb68:      	add	x2, x24, #0x10
    cb6c:      	mov	w8, #0x4                // =4
    cb70:      	add	x9, sp, #0x98
    cb74:      	add	x0, sp, #0x98
    cb78:      	mov	w1, #0x8                // =8
    cb7c:      	blr	x8
    cb80:      	ldr	x8, [sp, #0x58]
    cb84:      	ldr	x9, [sp, #0x98]
    cb88:      	cmp	x8, x9
    cb8c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    cb90:      	add	x2, x24, #0x18
    cb94:      	mov	w8, #0x4                // =4
    cb98:      	mov	x0, x22
    cb9c:      	mov	w1, #0x8                // =8
    cba0:      	blr	x8
    cba4:      	ldr	x24, [sp, #0x98]
    cba8:      	ldr	x21, [sp, #0x48]
    cbac:      	add	x2, x24, #0x20
    cbb0:      	stp	x2, x24, [sp, #0x50]
    cbb4:      	ldr	x8, [sp, #0x30]
    cbb8:      	cmp	x21, x8
    cbbc:      	b.ne	0xcbcc <generic_kprobe_path+0x30ec>
    cbc0:      	ldr	x8, [sp, #0x38]
    cbc4:      	cmp	x2, x8
    cbc8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    cbcc:      	mov	w8, #0x4                // =4
    cbd0:      	add	x0, sp, #0x70
    cbd4:      	mov	w1, #0x8                // =8
    cbd8:      	blr	x8
    cbdc:      	ldr	x8, [sp, #0x70]
    cbe0:      	cmp	x21, x8
    cbe4:      	b.eq	0xccd4 <generic_kprobe_path+0x31f4>
    cbe8:      	add	x23, x21, #0x18
    cbec:      	mov	w8, #0x4                // =4
    cbf0:      	add	x9, sp, #0x98
    cbf4:      	add	x0, sp, #0x98
    cbf8:      	mov	w1, #0x8                // =8
    cbfc:      	mov	x2, x23
    cc00:      	blr	x8
    cc04:      	ldr	x8, [sp, #0x98]
    cc08:      	cmp	x8, x21
    cc0c:      	b.eq	0xccd4 <generic_kprobe_path+0x31f4>
    cc10:      	mov	w8, #0x4                // =4
    cc14:      	add	x9, sp, #0x78
    cc18:      	add	x0, sp, #0x78
    cc1c:      	mov	w1, #0x8                // =8
    cc20:      	mov	x2, x23
    cc24:      	blr	x8
    cc28:      	add	x2, x21, #0x20
    cc2c:      	mov	w8, #0x4                // =4
    cc30:      	mov	w9, #0x10               // =16
    cc34:      	add	x10, sp, #0x80
    cc38:      	add	x0, sp, #0x80
    cc3c:      	mov	w1, #0x10               // =16
    cc40:      	blr	x8
    cc44:      	ldr	w21, [sp, #0x84]
    cc48:      	ldr	x8, [sp, #0x40]
    cc4c:      	ldr	x10, [sp, #0x60]
    cc50:      	sub	x12, x10, x8
    cc54:      	ldr	w23, [sp, #0x68]
    cc58:      	subs	w10, w21, w23
    cc5c:      	ldr	x9, [sp, #0x88]
    cc60:      	csel	w10, wzr, w10, lo
    cc64:      	cmp	w23, w21
    cc68:      	csel	w11, w23, w21, lo
    cc6c:      	cinc	w13, w11, hi
    cc70:      	sub	w14, w23, w13
    cc74:      	subs	x12, x12, x13
    cc78:      	str	w14, [sp, #0x68]
    cc7c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    cc80:      	cmp	x12, #0xfff
    cc84:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    cc88:      	cmp	w23, w21
    cc8c:      	b.ls	0xcc98 <generic_kprobe_path+0x31b8>
    cc90:      	mov	w13, #0x2f              // =47
    cc94:      	strb	w13, [x8, x12]
    cc98:      	add	x19, x8, x12
    cc9c:      	cmp	w23, w21
    cca0:      	add	x2, x9, x10
    cca4:      	and	w1, w11, #0xff
    cca8:      	mov	w8, #0x4                // =4
    ccac:      	cinc	x0, x19, hi
    ccb0:      	blr	x8
    ccb4:      	cmp	w23, w21
    ccb8:      	str	x19, [sp, #0x60]
    ccbc:      	add	x19, sp, #0x70
    ccc0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ccc4:      	ldr	x21, [sp, #0x78]
    ccc8:      	ldp	x2, x24, [sp, #0x50]
    cccc:      	str	x21, [sp, #0x48]
    ccd0:      	b	0xcd20 <generic_kprobe_path+0x3240>
    ccd4:      	add	x2, x24, #0x10
    ccd8:      	mov	w8, #0x4                // =4
    ccdc:      	add	x9, sp, #0x98
    cce0:      	add	x0, sp, #0x98
    cce4:      	mov	w1, #0x8                // =8
    cce8:      	blr	x8
    ccec:      	ldr	x8, [sp, #0x58]
    ccf0:      	ldr	x9, [sp, #0x98]
    ccf4:      	cmp	x8, x9
    ccf8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ccfc:      	add	x2, x24, #0x18
    cd00:      	mov	w8, #0x4                // =4
    cd04:      	mov	x0, x22
    cd08:      	mov	w1, #0x8                // =8
    cd0c:      	blr	x8
    cd10:      	ldr	x24, [sp, #0x98]
    cd14:      	ldr	x21, [sp, #0x48]
    cd18:      	add	x2, x24, #0x20
    cd1c:      	stp	x2, x24, [sp, #0x50]
    cd20:      	ldr	x8, [sp, #0x30]
    cd24:      	cmp	x21, x8
    cd28:      	b.ne	0xcd38 <generic_kprobe_path+0x3258>
    cd2c:      	ldr	x8, [sp, #0x38]
    cd30:      	cmp	x2, x8
    cd34:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    cd38:      	mov	w8, #0x4                // =4
    cd3c:      	add	x0, sp, #0x70
    cd40:      	mov	w1, #0x8                // =8
    cd44:      	blr	x8
    cd48:      	ldr	x8, [sp, #0x70]
    cd4c:      	cmp	x21, x8
    cd50:      	b.eq	0xce40 <generic_kprobe_path+0x3360>
    cd54:      	add	x23, x21, #0x18
    cd58:      	mov	w8, #0x4                // =4
    cd5c:      	add	x9, sp, #0x98
    cd60:      	add	x0, sp, #0x98
    cd64:      	mov	w1, #0x8                // =8
    cd68:      	mov	x2, x23
    cd6c:      	blr	x8
    cd70:      	ldr	x8, [sp, #0x98]
    cd74:      	cmp	x8, x21
    cd78:      	b.eq	0xce40 <generic_kprobe_path+0x3360>
    cd7c:      	mov	w8, #0x4                // =4
    cd80:      	add	x9, sp, #0x78
    cd84:      	add	x0, sp, #0x78
    cd88:      	mov	w1, #0x8                // =8
    cd8c:      	mov	x2, x23
    cd90:      	blr	x8
    cd94:      	add	x2, x21, #0x20
    cd98:      	mov	w8, #0x4                // =4
    cd9c:      	mov	w9, #0x10               // =16
    cda0:      	add	x10, sp, #0x80
    cda4:      	add	x0, sp, #0x80
    cda8:      	mov	w1, #0x10               // =16
    cdac:      	blr	x8
    cdb0:      	ldr	w21, [sp, #0x84]
    cdb4:      	ldr	x8, [sp, #0x40]
    cdb8:      	ldr	x10, [sp, #0x60]
    cdbc:      	sub	x12, x10, x8
    cdc0:      	ldr	w23, [sp, #0x68]
    cdc4:      	subs	w10, w21, w23
    cdc8:      	ldr	x9, [sp, #0x88]
    cdcc:      	csel	w10, wzr, w10, lo
    cdd0:      	cmp	w23, w21
    cdd4:      	csel	w11, w23, w21, lo
    cdd8:      	cinc	w13, w11, hi
    cddc:      	sub	w14, w23, w13
    cde0:      	subs	x12, x12, x13
    cde4:      	str	w14, [sp, #0x68]
    cde8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    cdec:      	cmp	x12, #0xfff
    cdf0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    cdf4:      	cmp	w23, w21
    cdf8:      	b.ls	0xce04 <generic_kprobe_path+0x3324>
    cdfc:      	mov	w13, #0x2f              // =47
    ce00:      	strb	w13, [x8, x12]
    ce04:      	add	x19, x8, x12
    ce08:      	cmp	w23, w21
    ce0c:      	add	x2, x9, x10
    ce10:      	and	w1, w11, #0xff
    ce14:      	mov	w8, #0x4                // =4
    ce18:      	cinc	x0, x19, hi
    ce1c:      	blr	x8
    ce20:      	cmp	w23, w21
    ce24:      	str	x19, [sp, #0x60]
    ce28:      	add	x19, sp, #0x70
    ce2c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ce30:      	ldr	x21, [sp, #0x78]
    ce34:      	ldp	x2, x24, [sp, #0x50]
    ce38:      	str	x21, [sp, #0x48]
    ce3c:      	b	0xce8c <generic_kprobe_path+0x33ac>
    ce40:      	add	x2, x24, #0x10
    ce44:      	mov	w8, #0x4                // =4
    ce48:      	add	x9, sp, #0x98
    ce4c:      	add	x0, sp, #0x98
    ce50:      	mov	w1, #0x8                // =8
    ce54:      	blr	x8
    ce58:      	ldr	x8, [sp, #0x58]
    ce5c:      	ldr	x9, [sp, #0x98]
    ce60:      	cmp	x8, x9
    ce64:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ce68:      	add	x2, x24, #0x18
    ce6c:      	mov	w8, #0x4                // =4
    ce70:      	mov	x0, x22
    ce74:      	mov	w1, #0x8                // =8
    ce78:      	blr	x8
    ce7c:      	ldr	x24, [sp, #0x98]
    ce80:      	ldr	x21, [sp, #0x48]
    ce84:      	add	x2, x24, #0x20
    ce88:      	stp	x2, x24, [sp, #0x50]
    ce8c:      	ldr	x8, [sp, #0x30]
    ce90:      	cmp	x21, x8
    ce94:      	b.ne	0xcea4 <generic_kprobe_path+0x33c4>
    ce98:      	ldr	x8, [sp, #0x38]
    ce9c:      	cmp	x2, x8
    cea0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    cea4:      	mov	w8, #0x4                // =4
    cea8:      	add	x0, sp, #0x70
    ceac:      	mov	w1, #0x8                // =8
    ceb0:      	blr	x8
    ceb4:      	ldr	x8, [sp, #0x70]
    ceb8:      	cmp	x21, x8
    cebc:      	b.eq	0xcfac <generic_kprobe_path+0x34cc>
    cec0:      	add	x23, x21, #0x18
    cec4:      	mov	w8, #0x4                // =4
    cec8:      	add	x9, sp, #0x98
    cecc:      	add	x0, sp, #0x98
    ced0:      	mov	w1, #0x8                // =8
    ced4:      	mov	x2, x23
    ced8:      	blr	x8
    cedc:      	ldr	x8, [sp, #0x98]
    cee0:      	cmp	x8, x21
    cee4:      	b.eq	0xcfac <generic_kprobe_path+0x34cc>
    cee8:      	mov	w8, #0x4                // =4
    ceec:      	add	x9, sp, #0x78
    cef0:      	add	x0, sp, #0x78
    cef4:      	mov	w1, #0x8                // =8
    cef8:      	mov	x2, x23
    cefc:      	blr	x8
    cf00:      	add	x2, x21, #0x20
    cf04:      	mov	w8, #0x4                // =4
    cf08:      	mov	w9, #0x10               // =16
    cf0c:      	add	x10, sp, #0x80
    cf10:      	add	x0, sp, #0x80
    cf14:      	mov	w1, #0x10               // =16
    cf18:      	blr	x8
    cf1c:      	ldr	w21, [sp, #0x84]
    cf20:      	ldr	x8, [sp, #0x40]
    cf24:      	ldr	x10, [sp, #0x60]
    cf28:      	sub	x12, x10, x8
    cf2c:      	ldr	w23, [sp, #0x68]
    cf30:      	subs	w10, w21, w23
    cf34:      	ldr	x9, [sp, #0x88]
    cf38:      	csel	w10, wzr, w10, lo
    cf3c:      	cmp	w23, w21
    cf40:      	csel	w11, w23, w21, lo
    cf44:      	cinc	w13, w11, hi
    cf48:      	sub	w14, w23, w13
    cf4c:      	subs	x12, x12, x13
    cf50:      	str	w14, [sp, #0x68]
    cf54:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    cf58:      	cmp	x12, #0xfff
    cf5c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    cf60:      	cmp	w23, w21
    cf64:      	b.ls	0xcf70 <generic_kprobe_path+0x3490>
    cf68:      	mov	w13, #0x2f              // =47
    cf6c:      	strb	w13, [x8, x12]
    cf70:      	add	x19, x8, x12
    cf74:      	cmp	w23, w21
    cf78:      	add	x2, x9, x10
    cf7c:      	and	w1, w11, #0xff
    cf80:      	mov	w8, #0x4                // =4
    cf84:      	cinc	x0, x19, hi
    cf88:      	blr	x8
    cf8c:      	cmp	w23, w21
    cf90:      	str	x19, [sp, #0x60]
    cf94:      	add	x19, sp, #0x70
    cf98:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    cf9c:      	ldr	x21, [sp, #0x78]
    cfa0:      	ldp	x2, x24, [sp, #0x50]
    cfa4:      	str	x21, [sp, #0x48]
    cfa8:      	b	0xcff8 <generic_kprobe_path+0x3518>
    cfac:      	add	x2, x24, #0x10
    cfb0:      	mov	w8, #0x4                // =4
    cfb4:      	add	x9, sp, #0x98
    cfb8:      	add	x0, sp, #0x98
    cfbc:      	mov	w1, #0x8                // =8
    cfc0:      	blr	x8
    cfc4:      	ldr	x8, [sp, #0x58]
    cfc8:      	ldr	x9, [sp, #0x98]
    cfcc:      	cmp	x8, x9
    cfd0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    cfd4:      	add	x2, x24, #0x18
    cfd8:      	mov	w8, #0x4                // =4
    cfdc:      	mov	x0, x22
    cfe0:      	mov	w1, #0x8                // =8
    cfe4:      	blr	x8
    cfe8:      	ldr	x24, [sp, #0x98]
    cfec:      	ldr	x21, [sp, #0x48]
    cff0:      	add	x2, x24, #0x20
    cff4:      	stp	x2, x24, [sp, #0x50]
    cff8:      	ldr	x8, [sp, #0x30]
    cffc:      	cmp	x21, x8
    d000:      	b.ne	0xd010 <generic_kprobe_path+0x3530>
    d004:      	ldr	x8, [sp, #0x38]
    d008:      	cmp	x2, x8
    d00c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d010:      	mov	w8, #0x4                // =4
    d014:      	add	x0, sp, #0x70
    d018:      	mov	w1, #0x8                // =8
    d01c:      	blr	x8
    d020:      	ldr	x8, [sp, #0x70]
    d024:      	cmp	x21, x8
    d028:      	b.eq	0xd118 <generic_kprobe_path+0x3638>
    d02c:      	add	x23, x21, #0x18
    d030:      	mov	w8, #0x4                // =4
    d034:      	add	x9, sp, #0x98
    d038:      	add	x0, sp, #0x98
    d03c:      	mov	w1, #0x8                // =8
    d040:      	mov	x2, x23
    d044:      	blr	x8
    d048:      	ldr	x8, [sp, #0x98]
    d04c:      	cmp	x8, x21
    d050:      	b.eq	0xd118 <generic_kprobe_path+0x3638>
    d054:      	mov	w8, #0x4                // =4
    d058:      	add	x9, sp, #0x78
    d05c:      	add	x0, sp, #0x78
    d060:      	mov	w1, #0x8                // =8
    d064:      	mov	x2, x23
    d068:      	blr	x8
    d06c:      	add	x2, x21, #0x20
    d070:      	mov	w8, #0x4                // =4
    d074:      	mov	w9, #0x10               // =16
    d078:      	add	x10, sp, #0x80
    d07c:      	add	x0, sp, #0x80
    d080:      	mov	w1, #0x10               // =16
    d084:      	blr	x8
    d088:      	ldr	w21, [sp, #0x84]
    d08c:      	ldr	x8, [sp, #0x40]
    d090:      	ldr	x10, [sp, #0x60]
    d094:      	sub	x12, x10, x8
    d098:      	ldr	w23, [sp, #0x68]
    d09c:      	subs	w10, w21, w23
    d0a0:      	ldr	x9, [sp, #0x88]
    d0a4:      	csel	w10, wzr, w10, lo
    d0a8:      	cmp	w23, w21
    d0ac:      	csel	w11, w23, w21, lo
    d0b0:      	cinc	w13, w11, hi
    d0b4:      	sub	w14, w23, w13
    d0b8:      	subs	x12, x12, x13
    d0bc:      	str	w14, [sp, #0x68]
    d0c0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d0c4:      	cmp	x12, #0xfff
    d0c8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d0cc:      	cmp	w23, w21
    d0d0:      	b.ls	0xd0dc <generic_kprobe_path+0x35fc>
    d0d4:      	mov	w13, #0x2f              // =47
    d0d8:      	strb	w13, [x8, x12]
    d0dc:      	add	x19, x8, x12
    d0e0:      	cmp	w23, w21
    d0e4:      	add	x2, x9, x10
    d0e8:      	and	w1, w11, #0xff
    d0ec:      	mov	w8, #0x4                // =4
    d0f0:      	cinc	x0, x19, hi
    d0f4:      	blr	x8
    d0f8:      	cmp	w23, w21
    d0fc:      	str	x19, [sp, #0x60]
    d100:      	add	x19, sp, #0x70
    d104:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d108:      	ldr	x21, [sp, #0x78]
    d10c:      	ldp	x2, x24, [sp, #0x50]
    d110:      	str	x21, [sp, #0x48]
    d114:      	b	0xd164 <generic_kprobe_path+0x3684>
    d118:      	add	x2, x24, #0x10
    d11c:      	mov	w8, #0x4                // =4
    d120:      	add	x9, sp, #0x98
    d124:      	add	x0, sp, #0x98
    d128:      	mov	w1, #0x8                // =8
    d12c:      	blr	x8
    d130:      	ldr	x8, [sp, #0x58]
    d134:      	ldr	x9, [sp, #0x98]
    d138:      	cmp	x8, x9
    d13c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d140:      	add	x2, x24, #0x18
    d144:      	mov	w8, #0x4                // =4
    d148:      	mov	x0, x22
    d14c:      	mov	w1, #0x8                // =8
    d150:      	blr	x8
    d154:      	ldr	x24, [sp, #0x98]
    d158:      	ldr	x21, [sp, #0x48]
    d15c:      	add	x2, x24, #0x20
    d160:      	stp	x2, x24, [sp, #0x50]
    d164:      	ldr	x8, [sp, #0x30]
    d168:      	cmp	x21, x8
    d16c:      	b.ne	0xd17c <generic_kprobe_path+0x369c>
    d170:      	ldr	x8, [sp, #0x38]
    d174:      	cmp	x2, x8
    d178:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d17c:      	mov	w8, #0x4                // =4
    d180:      	add	x0, sp, #0x70
    d184:      	mov	w1, #0x8                // =8
    d188:      	blr	x8
    d18c:      	ldr	x8, [sp, #0x70]
    d190:      	cmp	x21, x8
    d194:      	b.eq	0xd284 <generic_kprobe_path+0x37a4>
    d198:      	add	x23, x21, #0x18
    d19c:      	mov	w8, #0x4                // =4
    d1a0:      	add	x9, sp, #0x98
    d1a4:      	add	x0, sp, #0x98
    d1a8:      	mov	w1, #0x8                // =8
    d1ac:      	mov	x2, x23
    d1b0:      	blr	x8
    d1b4:      	ldr	x8, [sp, #0x98]
    d1b8:      	cmp	x8, x21
    d1bc:      	b.eq	0xd284 <generic_kprobe_path+0x37a4>
    d1c0:      	mov	w8, #0x4                // =4
    d1c4:      	add	x9, sp, #0x78
    d1c8:      	add	x0, sp, #0x78
    d1cc:      	mov	w1, #0x8                // =8
    d1d0:      	mov	x2, x23
    d1d4:      	blr	x8
    d1d8:      	add	x2, x21, #0x20
    d1dc:      	mov	w8, #0x4                // =4
    d1e0:      	mov	w9, #0x10               // =16
    d1e4:      	add	x10, sp, #0x80
    d1e8:      	add	x0, sp, #0x80
    d1ec:      	mov	w1, #0x10               // =16
    d1f0:      	blr	x8
    d1f4:      	ldr	w21, [sp, #0x84]
    d1f8:      	ldr	x8, [sp, #0x40]
    d1fc:      	ldr	x10, [sp, #0x60]
    d200:      	sub	x12, x10, x8
    d204:      	ldr	w23, [sp, #0x68]
    d208:      	subs	w10, w21, w23
    d20c:      	ldr	x9, [sp, #0x88]
    d210:      	csel	w10, wzr, w10, lo
    d214:      	cmp	w23, w21
    d218:      	csel	w11, w23, w21, lo
    d21c:      	cinc	w13, w11, hi
    d220:      	sub	w14, w23, w13
    d224:      	subs	x12, x12, x13
    d228:      	str	w14, [sp, #0x68]
    d22c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d230:      	cmp	x12, #0xfff
    d234:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d238:      	cmp	w23, w21
    d23c:      	b.ls	0xd248 <generic_kprobe_path+0x3768>
    d240:      	mov	w13, #0x2f              // =47
    d244:      	strb	w13, [x8, x12]
    d248:      	add	x19, x8, x12
    d24c:      	cmp	w23, w21
    d250:      	add	x2, x9, x10
    d254:      	and	w1, w11, #0xff
    d258:      	mov	w8, #0x4                // =4
    d25c:      	cinc	x0, x19, hi
    d260:      	blr	x8
    d264:      	cmp	w23, w21
    d268:      	str	x19, [sp, #0x60]
    d26c:      	add	x19, sp, #0x70
    d270:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d274:      	ldr	x21, [sp, #0x78]
    d278:      	ldp	x2, x24, [sp, #0x50]
    d27c:      	str	x21, [sp, #0x48]
    d280:      	b	0xd2d0 <generic_kprobe_path+0x37f0>
    d284:      	add	x2, x24, #0x10
    d288:      	mov	w8, #0x4                // =4
    d28c:      	add	x9, sp, #0x98
    d290:      	add	x0, sp, #0x98
    d294:      	mov	w1, #0x8                // =8
    d298:      	blr	x8
    d29c:      	ldr	x8, [sp, #0x58]
    d2a0:      	ldr	x9, [sp, #0x98]
    d2a4:      	cmp	x8, x9
    d2a8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d2ac:      	add	x2, x24, #0x18
    d2b0:      	mov	w8, #0x4                // =4
    d2b4:      	mov	x0, x22
    d2b8:      	mov	w1, #0x8                // =8
    d2bc:      	blr	x8
    d2c0:      	ldr	x24, [sp, #0x98]
    d2c4:      	ldr	x21, [sp, #0x48]
    d2c8:      	add	x2, x24, #0x20
    d2cc:      	stp	x2, x24, [sp, #0x50]
    d2d0:      	ldr	x8, [sp, #0x30]
    d2d4:      	cmp	x21, x8
    d2d8:      	b.ne	0xd2e8 <generic_kprobe_path+0x3808>
    d2dc:      	ldr	x8, [sp, #0x38]
    d2e0:      	cmp	x2, x8
    d2e4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d2e8:      	mov	w8, #0x4                // =4
    d2ec:      	add	x0, sp, #0x70
    d2f0:      	mov	w1, #0x8                // =8
    d2f4:      	blr	x8
    d2f8:      	ldr	x8, [sp, #0x70]
    d2fc:      	cmp	x21, x8
    d300:      	b.eq	0xd3f0 <generic_kprobe_path+0x3910>
    d304:      	add	x23, x21, #0x18
    d308:      	mov	w8, #0x4                // =4
    d30c:      	add	x9, sp, #0x98
    d310:      	add	x0, sp, #0x98
    d314:      	mov	w1, #0x8                // =8
    d318:      	mov	x2, x23
    d31c:      	blr	x8
    d320:      	ldr	x8, [sp, #0x98]
    d324:      	cmp	x8, x21
    d328:      	b.eq	0xd3f0 <generic_kprobe_path+0x3910>
    d32c:      	mov	w8, #0x4                // =4
    d330:      	add	x9, sp, #0x78
    d334:      	add	x0, sp, #0x78
    d338:      	mov	w1, #0x8                // =8
    d33c:      	mov	x2, x23
    d340:      	blr	x8
    d344:      	add	x2, x21, #0x20
    d348:      	mov	w8, #0x4                // =4
    d34c:      	mov	w9, #0x10               // =16
    d350:      	add	x10, sp, #0x80
    d354:      	add	x0, sp, #0x80
    d358:      	mov	w1, #0x10               // =16
    d35c:      	blr	x8
    d360:      	ldr	w21, [sp, #0x84]
    d364:      	ldr	x8, [sp, #0x40]
    d368:      	ldr	x10, [sp, #0x60]
    d36c:      	sub	x12, x10, x8
    d370:      	ldr	w23, [sp, #0x68]
    d374:      	subs	w10, w21, w23
    d378:      	ldr	x9, [sp, #0x88]
    d37c:      	csel	w10, wzr, w10, lo
    d380:      	cmp	w23, w21
    d384:      	csel	w11, w23, w21, lo
    d388:      	cinc	w13, w11, hi
    d38c:      	sub	w14, w23, w13
    d390:      	subs	x12, x12, x13
    d394:      	str	w14, [sp, #0x68]
    d398:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d39c:      	cmp	x12, #0xfff
    d3a0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d3a4:      	cmp	w23, w21
    d3a8:      	b.ls	0xd3b4 <generic_kprobe_path+0x38d4>
    d3ac:      	mov	w13, #0x2f              // =47
    d3b0:      	strb	w13, [x8, x12]
    d3b4:      	add	x19, x8, x12
    d3b8:      	cmp	w23, w21
    d3bc:      	add	x2, x9, x10
    d3c0:      	and	w1, w11, #0xff
    d3c4:      	mov	w8, #0x4                // =4
    d3c8:      	cinc	x0, x19, hi
    d3cc:      	blr	x8
    d3d0:      	cmp	w23, w21
    d3d4:      	str	x19, [sp, #0x60]
    d3d8:      	add	x19, sp, #0x70
    d3dc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d3e0:      	ldr	x21, [sp, #0x78]
    d3e4:      	ldp	x2, x24, [sp, #0x50]
    d3e8:      	str	x21, [sp, #0x48]
    d3ec:      	b	0xd43c <generic_kprobe_path+0x395c>
    d3f0:      	add	x2, x24, #0x10
    d3f4:      	mov	w8, #0x4                // =4
    d3f8:      	add	x9, sp, #0x98
    d3fc:      	add	x0, sp, #0x98
    d400:      	mov	w1, #0x8                // =8
    d404:      	blr	x8
    d408:      	ldr	x8, [sp, #0x58]
    d40c:      	ldr	x9, [sp, #0x98]
    d410:      	cmp	x8, x9
    d414:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d418:      	add	x2, x24, #0x18
    d41c:      	mov	w8, #0x4                // =4
    d420:      	mov	x0, x22
    d424:      	mov	w1, #0x8                // =8
    d428:      	blr	x8
    d42c:      	ldr	x24, [sp, #0x98]
    d430:      	ldr	x21, [sp, #0x48]
    d434:      	add	x2, x24, #0x20
    d438:      	stp	x2, x24, [sp, #0x50]
    d43c:      	ldr	x8, [sp, #0x30]
    d440:      	cmp	x21, x8
    d444:      	b.ne	0xd454 <generic_kprobe_path+0x3974>
    d448:      	ldr	x8, [sp, #0x38]
    d44c:      	cmp	x2, x8
    d450:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d454:      	mov	w8, #0x4                // =4
    d458:      	add	x0, sp, #0x70
    d45c:      	mov	w1, #0x8                // =8
    d460:      	blr	x8
    d464:      	ldr	x8, [sp, #0x70]
    d468:      	cmp	x21, x8
    d46c:      	b.eq	0xd55c <generic_kprobe_path+0x3a7c>
    d470:      	add	x23, x21, #0x18
    d474:      	mov	w8, #0x4                // =4
    d478:      	add	x9, sp, #0x98
    d47c:      	add	x0, sp, #0x98
    d480:      	mov	w1, #0x8                // =8
    d484:      	mov	x2, x23
    d488:      	blr	x8
    d48c:      	ldr	x8, [sp, #0x98]
    d490:      	cmp	x8, x21
    d494:      	b.eq	0xd55c <generic_kprobe_path+0x3a7c>
    d498:      	mov	w8, #0x4                // =4
    d49c:      	add	x9, sp, #0x78
    d4a0:      	add	x0, sp, #0x78
    d4a4:      	mov	w1, #0x8                // =8
    d4a8:      	mov	x2, x23
    d4ac:      	blr	x8
    d4b0:      	add	x2, x21, #0x20
    d4b4:      	mov	w8, #0x4                // =4
    d4b8:      	mov	w9, #0x10               // =16
    d4bc:      	add	x10, sp, #0x80
    d4c0:      	add	x0, sp, #0x80
    d4c4:      	mov	w1, #0x10               // =16
    d4c8:      	blr	x8
    d4cc:      	ldr	w21, [sp, #0x84]
    d4d0:      	ldr	x8, [sp, #0x40]
    d4d4:      	ldr	x10, [sp, #0x60]
    d4d8:      	sub	x12, x10, x8
    d4dc:      	ldr	w23, [sp, #0x68]
    d4e0:      	subs	w10, w21, w23
    d4e4:      	ldr	x9, [sp, #0x88]
    d4e8:      	csel	w10, wzr, w10, lo
    d4ec:      	cmp	w23, w21
    d4f0:      	csel	w11, w23, w21, lo
    d4f4:      	cinc	w13, w11, hi
    d4f8:      	sub	w14, w23, w13
    d4fc:      	subs	x12, x12, x13
    d500:      	str	w14, [sp, #0x68]
    d504:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d508:      	cmp	x12, #0xfff
    d50c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d510:      	cmp	w23, w21
    d514:      	b.ls	0xd520 <generic_kprobe_path+0x3a40>
    d518:      	mov	w13, #0x2f              // =47
    d51c:      	strb	w13, [x8, x12]
    d520:      	add	x19, x8, x12
    d524:      	cmp	w23, w21
    d528:      	add	x2, x9, x10
    d52c:      	and	w1, w11, #0xff
    d530:      	mov	w8, #0x4                // =4
    d534:      	cinc	x0, x19, hi
    d538:      	blr	x8
    d53c:      	cmp	w23, w21
    d540:      	str	x19, [sp, #0x60]
    d544:      	add	x19, sp, #0x70
    d548:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d54c:      	ldr	x21, [sp, #0x78]
    d550:      	ldp	x2, x24, [sp, #0x50]
    d554:      	str	x21, [sp, #0x48]
    d558:      	b	0xd5a8 <generic_kprobe_path+0x3ac8>
    d55c:      	add	x2, x24, #0x10
    d560:      	mov	w8, #0x4                // =4
    d564:      	add	x9, sp, #0x98
    d568:      	add	x0, sp, #0x98
    d56c:      	mov	w1, #0x8                // =8
    d570:      	blr	x8
    d574:      	ldr	x8, [sp, #0x58]
    d578:      	ldr	x9, [sp, #0x98]
    d57c:      	cmp	x8, x9
    d580:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d584:      	add	x2, x24, #0x18
    d588:      	mov	w8, #0x4                // =4
    d58c:      	mov	x0, x22
    d590:      	mov	w1, #0x8                // =8
    d594:      	blr	x8
    d598:      	ldr	x24, [sp, #0x98]
    d59c:      	ldr	x21, [sp, #0x48]
    d5a0:      	add	x2, x24, #0x20
    d5a4:      	stp	x2, x24, [sp, #0x50]
    d5a8:      	ldr	x8, [sp, #0x30]
    d5ac:      	cmp	x21, x8
    d5b0:      	b.ne	0xd5c0 <generic_kprobe_path+0x3ae0>
    d5b4:      	ldr	x8, [sp, #0x38]
    d5b8:      	cmp	x2, x8
    d5bc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d5c0:      	mov	w8, #0x4                // =4
    d5c4:      	add	x0, sp, #0x70
    d5c8:      	mov	w1, #0x8                // =8
    d5cc:      	blr	x8
    d5d0:      	ldr	x8, [sp, #0x70]
    d5d4:      	cmp	x21, x8
    d5d8:      	b.eq	0xd6c8 <generic_kprobe_path+0x3be8>
    d5dc:      	add	x23, x21, #0x18
    d5e0:      	mov	w8, #0x4                // =4
    d5e4:      	add	x9, sp, #0x98
    d5e8:      	add	x0, sp, #0x98
    d5ec:      	mov	w1, #0x8                // =8
    d5f0:      	mov	x2, x23
    d5f4:      	blr	x8
    d5f8:      	ldr	x8, [sp, #0x98]
    d5fc:      	cmp	x8, x21
    d600:      	b.eq	0xd6c8 <generic_kprobe_path+0x3be8>
    d604:      	mov	w8, #0x4                // =4
    d608:      	add	x9, sp, #0x78
    d60c:      	add	x0, sp, #0x78
    d610:      	mov	w1, #0x8                // =8
    d614:      	mov	x2, x23
    d618:      	blr	x8
    d61c:      	add	x2, x21, #0x20
    d620:      	mov	w8, #0x4                // =4
    d624:      	mov	w9, #0x10               // =16
    d628:      	add	x10, sp, #0x80
    d62c:      	add	x0, sp, #0x80
    d630:      	mov	w1, #0x10               // =16
    d634:      	blr	x8
    d638:      	ldr	w21, [sp, #0x84]
    d63c:      	ldr	x8, [sp, #0x40]
    d640:      	ldr	x10, [sp, #0x60]
    d644:      	sub	x12, x10, x8
    d648:      	ldr	w23, [sp, #0x68]
    d64c:      	subs	w10, w21, w23
    d650:      	ldr	x9, [sp, #0x88]
    d654:      	csel	w10, wzr, w10, lo
    d658:      	cmp	w23, w21
    d65c:      	csel	w11, w23, w21, lo
    d660:      	cinc	w13, w11, hi
    d664:      	sub	w14, w23, w13
    d668:      	subs	x12, x12, x13
    d66c:      	str	w14, [sp, #0x68]
    d670:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d674:      	cmp	x12, #0xfff
    d678:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d67c:      	cmp	w23, w21
    d680:      	b.ls	0xd68c <generic_kprobe_path+0x3bac>
    d684:      	mov	w13, #0x2f              // =47
    d688:      	strb	w13, [x8, x12]
    d68c:      	add	x19, x8, x12
    d690:      	cmp	w23, w21
    d694:      	add	x2, x9, x10
    d698:      	and	w1, w11, #0xff
    d69c:      	mov	w8, #0x4                // =4
    d6a0:      	cinc	x0, x19, hi
    d6a4:      	blr	x8
    d6a8:      	cmp	w23, w21
    d6ac:      	str	x19, [sp, #0x60]
    d6b0:      	add	x19, sp, #0x70
    d6b4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d6b8:      	ldr	x21, [sp, #0x78]
    d6bc:      	ldp	x2, x24, [sp, #0x50]
    d6c0:      	str	x21, [sp, #0x48]
    d6c4:      	b	0xd714 <generic_kprobe_path+0x3c34>
    d6c8:      	add	x2, x24, #0x10
    d6cc:      	mov	w8, #0x4                // =4
    d6d0:      	add	x9, sp, #0x98
    d6d4:      	add	x0, sp, #0x98
    d6d8:      	mov	w1, #0x8                // =8
    d6dc:      	blr	x8
    d6e0:      	ldr	x8, [sp, #0x58]
    d6e4:      	ldr	x9, [sp, #0x98]
    d6e8:      	cmp	x8, x9
    d6ec:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d6f0:      	add	x2, x24, #0x18
    d6f4:      	mov	w8, #0x4                // =4
    d6f8:      	mov	x0, x22
    d6fc:      	mov	w1, #0x8                // =8
    d700:      	blr	x8
    d704:      	ldr	x24, [sp, #0x98]
    d708:      	ldr	x21, [sp, #0x48]
    d70c:      	add	x2, x24, #0x20
    d710:      	stp	x2, x24, [sp, #0x50]
    d714:      	ldr	x8, [sp, #0x30]
    d718:      	cmp	x21, x8
    d71c:      	b.ne	0xd72c <generic_kprobe_path+0x3c4c>
    d720:      	ldr	x8, [sp, #0x38]
    d724:      	cmp	x2, x8
    d728:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d72c:      	mov	w8, #0x4                // =4
    d730:      	add	x0, sp, #0x70
    d734:      	mov	w1, #0x8                // =8
    d738:      	blr	x8
    d73c:      	ldr	x8, [sp, #0x70]
    d740:      	cmp	x21, x8
    d744:      	b.eq	0xd834 <generic_kprobe_path+0x3d54>
    d748:      	add	x23, x21, #0x18
    d74c:      	mov	w8, #0x4                // =4
    d750:      	add	x9, sp, #0x98
    d754:      	add	x0, sp, #0x98
    d758:      	mov	w1, #0x8                // =8
    d75c:      	mov	x2, x23
    d760:      	blr	x8
    d764:      	ldr	x8, [sp, #0x98]
    d768:      	cmp	x8, x21
    d76c:      	b.eq	0xd834 <generic_kprobe_path+0x3d54>
    d770:      	mov	w8, #0x4                // =4
    d774:      	add	x9, sp, #0x78
    d778:      	add	x0, sp, #0x78
    d77c:      	mov	w1, #0x8                // =8
    d780:      	mov	x2, x23
    d784:      	blr	x8
    d788:      	add	x2, x21, #0x20
    d78c:      	mov	w8, #0x4                // =4
    d790:      	mov	w9, #0x10               // =16
    d794:      	add	x10, sp, #0x80
    d798:      	add	x0, sp, #0x80
    d79c:      	mov	w1, #0x10               // =16
    d7a0:      	blr	x8
    d7a4:      	ldr	w21, [sp, #0x84]
    d7a8:      	ldr	x8, [sp, #0x40]
    d7ac:      	ldr	x10, [sp, #0x60]
    d7b0:      	sub	x12, x10, x8
    d7b4:      	ldr	w23, [sp, #0x68]
    d7b8:      	subs	w10, w21, w23
    d7bc:      	ldr	x9, [sp, #0x88]
    d7c0:      	csel	w10, wzr, w10, lo
    d7c4:      	cmp	w23, w21
    d7c8:      	csel	w11, w23, w21, lo
    d7cc:      	cinc	w13, w11, hi
    d7d0:      	sub	w14, w23, w13
    d7d4:      	subs	x12, x12, x13
    d7d8:      	str	w14, [sp, #0x68]
    d7dc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d7e0:      	cmp	x12, #0xfff
    d7e4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d7e8:      	cmp	w23, w21
    d7ec:      	b.ls	0xd7f8 <generic_kprobe_path+0x3d18>
    d7f0:      	mov	w13, #0x2f              // =47
    d7f4:      	strb	w13, [x8, x12]
    d7f8:      	add	x19, x8, x12
    d7fc:      	cmp	w23, w21
    d800:      	add	x2, x9, x10
    d804:      	and	w1, w11, #0xff
    d808:      	mov	w8, #0x4                // =4
    d80c:      	cinc	x0, x19, hi
    d810:      	blr	x8
    d814:      	cmp	w23, w21
    d818:      	str	x19, [sp, #0x60]
    d81c:      	add	x19, sp, #0x70
    d820:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d824:      	ldr	x21, [sp, #0x78]
    d828:      	ldp	x2, x24, [sp, #0x50]
    d82c:      	str	x21, [sp, #0x48]
    d830:      	b	0xd880 <generic_kprobe_path+0x3da0>
    d834:      	add	x2, x24, #0x10
    d838:      	mov	w8, #0x4                // =4
    d83c:      	add	x9, sp, #0x98
    d840:      	add	x0, sp, #0x98
    d844:      	mov	w1, #0x8                // =8
    d848:      	blr	x8
    d84c:      	ldr	x8, [sp, #0x58]
    d850:      	ldr	x9, [sp, #0x98]
    d854:      	cmp	x8, x9
    d858:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d85c:      	add	x2, x24, #0x18
    d860:      	mov	w8, #0x4                // =4
    d864:      	mov	x0, x22
    d868:      	mov	w1, #0x8                // =8
    d86c:      	blr	x8
    d870:      	ldr	x24, [sp, #0x98]
    d874:      	ldr	x21, [sp, #0x48]
    d878:      	add	x2, x24, #0x20
    d87c:      	stp	x2, x24, [sp, #0x50]
    d880:      	ldr	x8, [sp, #0x30]
    d884:      	cmp	x21, x8
    d888:      	b.ne	0xd898 <generic_kprobe_path+0x3db8>
    d88c:      	ldr	x8, [sp, #0x38]
    d890:      	cmp	x2, x8
    d894:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d898:      	mov	w8, #0x4                // =4
    d89c:      	add	x0, sp, #0x70
    d8a0:      	mov	w1, #0x8                // =8
    d8a4:      	blr	x8
    d8a8:      	ldr	x8, [sp, #0x70]
    d8ac:      	cmp	x21, x8
    d8b0:      	b.eq	0xd9a0 <generic_kprobe_path+0x3ec0>
    d8b4:      	add	x23, x21, #0x18
    d8b8:      	mov	w8, #0x4                // =4
    d8bc:      	add	x9, sp, #0x98
    d8c0:      	add	x0, sp, #0x98
    d8c4:      	mov	w1, #0x8                // =8
    d8c8:      	mov	x2, x23
    d8cc:      	blr	x8
    d8d0:      	ldr	x8, [sp, #0x98]
    d8d4:      	cmp	x8, x21
    d8d8:      	b.eq	0xd9a0 <generic_kprobe_path+0x3ec0>
    d8dc:      	mov	w8, #0x4                // =4
    d8e0:      	add	x9, sp, #0x78
    d8e4:      	add	x0, sp, #0x78
    d8e8:      	mov	w1, #0x8                // =8
    d8ec:      	mov	x2, x23
    d8f0:      	blr	x8
    d8f4:      	add	x2, x21, #0x20
    d8f8:      	mov	w8, #0x4                // =4
    d8fc:      	mov	w9, #0x10               // =16
    d900:      	add	x10, sp, #0x80
    d904:      	add	x0, sp, #0x80
    d908:      	mov	w1, #0x10               // =16
    d90c:      	blr	x8
    d910:      	ldr	w21, [sp, #0x84]
    d914:      	ldr	x8, [sp, #0x40]
    d918:      	ldr	x10, [sp, #0x60]
    d91c:      	sub	x12, x10, x8
    d920:      	ldr	w23, [sp, #0x68]
    d924:      	subs	w10, w21, w23
    d928:      	ldr	x9, [sp, #0x88]
    d92c:      	csel	w10, wzr, w10, lo
    d930:      	cmp	w23, w21
    d934:      	csel	w11, w23, w21, lo
    d938:      	cinc	w13, w11, hi
    d93c:      	sub	w14, w23, w13
    d940:      	subs	x12, x12, x13
    d944:      	str	w14, [sp, #0x68]
    d948:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    d94c:      	cmp	x12, #0xfff
    d950:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    d954:      	cmp	w23, w21
    d958:      	b.ls	0xd964 <generic_kprobe_path+0x3e84>
    d95c:      	mov	w13, #0x2f              // =47
    d960:      	strb	w13, [x8, x12]
    d964:      	add	x19, x8, x12
    d968:      	cmp	w23, w21
    d96c:      	add	x2, x9, x10
    d970:      	and	w1, w11, #0xff
    d974:      	mov	w8, #0x4                // =4
    d978:      	cinc	x0, x19, hi
    d97c:      	blr	x8
    d980:      	cmp	w23, w21
    d984:      	str	x19, [sp, #0x60]
    d988:      	add	x19, sp, #0x70
    d98c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    d990:      	ldr	x21, [sp, #0x78]
    d994:      	ldp	x2, x24, [sp, #0x50]
    d998:      	str	x21, [sp, #0x48]
    d99c:      	b	0xd9ec <generic_kprobe_path+0x3f0c>
    d9a0:      	add	x2, x24, #0x10
    d9a4:      	mov	w8, #0x4                // =4
    d9a8:      	add	x9, sp, #0x98
    d9ac:      	add	x0, sp, #0x98
    d9b0:      	mov	w1, #0x8                // =8
    d9b4:      	blr	x8
    d9b8:      	ldr	x8, [sp, #0x58]
    d9bc:      	ldr	x9, [sp, #0x98]
    d9c0:      	cmp	x8, x9
    d9c4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    d9c8:      	add	x2, x24, #0x18
    d9cc:      	mov	w8, #0x4                // =4
    d9d0:      	mov	x0, x22
    d9d4:      	mov	w1, #0x8                // =8
    d9d8:      	blr	x8
    d9dc:      	ldr	x24, [sp, #0x98]
    d9e0:      	ldr	x21, [sp, #0x48]
    d9e4:      	add	x2, x24, #0x20
    d9e8:      	stp	x2, x24, [sp, #0x50]
    d9ec:      	ldr	x8, [sp, #0x30]
    d9f0:      	cmp	x21, x8
    d9f4:      	b.ne	0xda04 <generic_kprobe_path+0x3f24>
    d9f8:      	ldr	x8, [sp, #0x38]
    d9fc:      	cmp	x2, x8
    da00:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    da04:      	mov	w8, #0x4                // =4
    da08:      	add	x0, sp, #0x70
    da0c:      	mov	w1, #0x8                // =8
    da10:      	blr	x8
    da14:      	ldr	x8, [sp, #0x70]
    da18:      	cmp	x21, x8
    da1c:      	b.eq	0xdb0c <generic_kprobe_path+0x402c>
    da20:      	add	x23, x21, #0x18
    da24:      	mov	w8, #0x4                // =4
    da28:      	add	x9, sp, #0x98
    da2c:      	add	x0, sp, #0x98
    da30:      	mov	w1, #0x8                // =8
    da34:      	mov	x2, x23
    da38:      	blr	x8
    da3c:      	ldr	x8, [sp, #0x98]
    da40:      	cmp	x8, x21
    da44:      	b.eq	0xdb0c <generic_kprobe_path+0x402c>
    da48:      	mov	w8, #0x4                // =4
    da4c:      	add	x9, sp, #0x78
    da50:      	add	x0, sp, #0x78
    da54:      	mov	w1, #0x8                // =8
    da58:      	mov	x2, x23
    da5c:      	blr	x8
    da60:      	add	x2, x21, #0x20
    da64:      	mov	w8, #0x4                // =4
    da68:      	mov	w9, #0x10               // =16
    da6c:      	add	x10, sp, #0x80
    da70:      	add	x0, sp, #0x80
    da74:      	mov	w1, #0x10               // =16
    da78:      	blr	x8
    da7c:      	ldr	w21, [sp, #0x84]
    da80:      	ldr	x8, [sp, #0x40]
    da84:      	ldr	x10, [sp, #0x60]
    da88:      	sub	x12, x10, x8
    da8c:      	ldr	w23, [sp, #0x68]
    da90:      	subs	w10, w21, w23
    da94:      	ldr	x9, [sp, #0x88]
    da98:      	csel	w10, wzr, w10, lo
    da9c:      	cmp	w23, w21
    daa0:      	csel	w11, w23, w21, lo
    daa4:      	cinc	w13, w11, hi
    daa8:      	sub	w14, w23, w13
    daac:      	subs	x12, x12, x13
    dab0:      	str	w14, [sp, #0x68]
    dab4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    dab8:      	cmp	x12, #0xfff
    dabc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    dac0:      	cmp	w23, w21
    dac4:      	b.ls	0xdad0 <generic_kprobe_path+0x3ff0>
    dac8:      	mov	w13, #0x2f              // =47
    dacc:      	strb	w13, [x8, x12]
    dad0:      	add	x19, x8, x12
    dad4:      	cmp	w23, w21
    dad8:      	add	x2, x9, x10
    dadc:      	and	w1, w11, #0xff
    dae0:      	mov	w8, #0x4                // =4
    dae4:      	cinc	x0, x19, hi
    dae8:      	blr	x8
    daec:      	cmp	w23, w21
    daf0:      	str	x19, [sp, #0x60]
    daf4:      	add	x19, sp, #0x70
    daf8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    dafc:      	ldr	x21, [sp, #0x78]
    db00:      	ldp	x2, x24, [sp, #0x50]
    db04:      	str	x21, [sp, #0x48]
    db08:      	b	0xdb58 <generic_kprobe_path+0x4078>
    db0c:      	add	x2, x24, #0x10
    db10:      	mov	w8, #0x4                // =4
    db14:      	add	x9, sp, #0x98
    db18:      	add	x0, sp, #0x98
    db1c:      	mov	w1, #0x8                // =8
    db20:      	blr	x8
    db24:      	ldr	x8, [sp, #0x58]
    db28:      	ldr	x9, [sp, #0x98]
    db2c:      	cmp	x8, x9
    db30:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    db34:      	add	x2, x24, #0x18
    db38:      	mov	w8, #0x4                // =4
    db3c:      	mov	x0, x22
    db40:      	mov	w1, #0x8                // =8
    db44:      	blr	x8
    db48:      	ldr	x24, [sp, #0x98]
    db4c:      	ldr	x21, [sp, #0x48]
    db50:      	add	x2, x24, #0x20
    db54:      	stp	x2, x24, [sp, #0x50]
    db58:      	ldr	x8, [sp, #0x30]
    db5c:      	cmp	x21, x8
    db60:      	b.ne	0xdb70 <generic_kprobe_path+0x4090>
    db64:      	ldr	x8, [sp, #0x38]
    db68:      	cmp	x2, x8
    db6c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    db70:      	mov	w8, #0x4                // =4
    db74:      	add	x0, sp, #0x70
    db78:      	mov	w1, #0x8                // =8
    db7c:      	blr	x8
    db80:      	ldr	x8, [sp, #0x70]
    db84:      	cmp	x21, x8
    db88:      	b.eq	0xdc78 <generic_kprobe_path+0x4198>
    db8c:      	add	x23, x21, #0x18
    db90:      	mov	w8, #0x4                // =4
    db94:      	add	x9, sp, #0x98
    db98:      	add	x0, sp, #0x98
    db9c:      	mov	w1, #0x8                // =8
    dba0:      	mov	x2, x23
    dba4:      	blr	x8
    dba8:      	ldr	x8, [sp, #0x98]
    dbac:      	cmp	x8, x21
    dbb0:      	b.eq	0xdc78 <generic_kprobe_path+0x4198>
    dbb4:      	mov	w8, #0x4                // =4
    dbb8:      	add	x9, sp, #0x78
    dbbc:      	add	x0, sp, #0x78
    dbc0:      	mov	w1, #0x8                // =8
    dbc4:      	mov	x2, x23
    dbc8:      	blr	x8
    dbcc:      	add	x2, x21, #0x20
    dbd0:      	mov	w8, #0x4                // =4
    dbd4:      	mov	w9, #0x10               // =16
    dbd8:      	add	x10, sp, #0x80
    dbdc:      	add	x0, sp, #0x80
    dbe0:      	mov	w1, #0x10               // =16
    dbe4:      	blr	x8
    dbe8:      	ldr	w21, [sp, #0x84]
    dbec:      	ldr	x8, [sp, #0x40]
    dbf0:      	ldr	x10, [sp, #0x60]
    dbf4:      	sub	x12, x10, x8
    dbf8:      	ldr	w23, [sp, #0x68]
    dbfc:      	subs	w10, w21, w23
    dc00:      	ldr	x9, [sp, #0x88]
    dc04:      	csel	w10, wzr, w10, lo
    dc08:      	cmp	w23, w21
    dc0c:      	csel	w11, w23, w21, lo
    dc10:      	cinc	w13, w11, hi
    dc14:      	sub	w14, w23, w13
    dc18:      	subs	x12, x12, x13
    dc1c:      	str	w14, [sp, #0x68]
    dc20:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    dc24:      	cmp	x12, #0xfff
    dc28:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    dc2c:      	cmp	w23, w21
    dc30:      	b.ls	0xdc3c <generic_kprobe_path+0x415c>
    dc34:      	mov	w13, #0x2f              // =47
    dc38:      	strb	w13, [x8, x12]
    dc3c:      	add	x19, x8, x12
    dc40:      	cmp	w23, w21
    dc44:      	add	x2, x9, x10
    dc48:      	and	w1, w11, #0xff
    dc4c:      	mov	w8, #0x4                // =4
    dc50:      	cinc	x0, x19, hi
    dc54:      	blr	x8
    dc58:      	cmp	w23, w21
    dc5c:      	str	x19, [sp, #0x60]
    dc60:      	add	x19, sp, #0x70
    dc64:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    dc68:      	ldr	x21, [sp, #0x78]
    dc6c:      	ldp	x2, x24, [sp, #0x50]
    dc70:      	str	x21, [sp, #0x48]
    dc74:      	b	0xdcc4 <generic_kprobe_path+0x41e4>
    dc78:      	add	x2, x24, #0x10
    dc7c:      	mov	w8, #0x4                // =4
    dc80:      	add	x9, sp, #0x98
    dc84:      	add	x0, sp, #0x98
    dc88:      	mov	w1, #0x8                // =8
    dc8c:      	blr	x8
    dc90:      	ldr	x8, [sp, #0x58]
    dc94:      	ldr	x9, [sp, #0x98]
    dc98:      	cmp	x8, x9
    dc9c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    dca0:      	add	x2, x24, #0x18
    dca4:      	mov	w8, #0x4                // =4
    dca8:      	mov	x0, x22
    dcac:      	mov	w1, #0x8                // =8
    dcb0:      	blr	x8
    dcb4:      	ldr	x24, [sp, #0x98]
    dcb8:      	ldr	x21, [sp, #0x48]
    dcbc:      	add	x2, x24, #0x20
    dcc0:      	stp	x2, x24, [sp, #0x50]
    dcc4:      	ldr	x8, [sp, #0x30]
    dcc8:      	cmp	x21, x8
    dccc:      	b.ne	0xdcdc <generic_kprobe_path+0x41fc>
    dcd0:      	ldr	x8, [sp, #0x38]
    dcd4:      	cmp	x2, x8
    dcd8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    dcdc:      	mov	w8, #0x4                // =4
    dce0:      	add	x0, sp, #0x70
    dce4:      	mov	w1, #0x8                // =8
    dce8:      	blr	x8
    dcec:      	ldr	x8, [sp, #0x70]
    dcf0:      	cmp	x21, x8
    dcf4:      	b.eq	0xdde4 <generic_kprobe_path+0x4304>
    dcf8:      	add	x23, x21, #0x18
    dcfc:      	mov	w8, #0x4                // =4
    dd00:      	add	x9, sp, #0x98
    dd04:      	add	x0, sp, #0x98
    dd08:      	mov	w1, #0x8                // =8
    dd0c:      	mov	x2, x23
    dd10:      	blr	x8
    dd14:      	ldr	x8, [sp, #0x98]
    dd18:      	cmp	x8, x21
    dd1c:      	b.eq	0xdde4 <generic_kprobe_path+0x4304>
    dd20:      	mov	w8, #0x4                // =4
    dd24:      	add	x9, sp, #0x78
    dd28:      	add	x0, sp, #0x78
    dd2c:      	mov	w1, #0x8                // =8
    dd30:      	mov	x2, x23
    dd34:      	blr	x8
    dd38:      	add	x2, x21, #0x20
    dd3c:      	mov	w8, #0x4                // =4
    dd40:      	mov	w9, #0x10               // =16
    dd44:      	add	x10, sp, #0x80
    dd48:      	add	x0, sp, #0x80
    dd4c:      	mov	w1, #0x10               // =16
    dd50:      	blr	x8
    dd54:      	ldr	w21, [sp, #0x84]
    dd58:      	ldr	x8, [sp, #0x40]
    dd5c:      	ldr	x10, [sp, #0x60]
    dd60:      	sub	x12, x10, x8
    dd64:      	ldr	w23, [sp, #0x68]
    dd68:      	subs	w10, w21, w23
    dd6c:      	ldr	x9, [sp, #0x88]
    dd70:      	csel	w10, wzr, w10, lo
    dd74:      	cmp	w23, w21
    dd78:      	csel	w11, w23, w21, lo
    dd7c:      	cinc	w13, w11, hi
    dd80:      	sub	w14, w23, w13
    dd84:      	subs	x12, x12, x13
    dd88:      	str	w14, [sp, #0x68]
    dd8c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    dd90:      	cmp	x12, #0xfff
    dd94:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    dd98:      	cmp	w23, w21
    dd9c:      	b.ls	0xdda8 <generic_kprobe_path+0x42c8>
    dda0:      	mov	w13, #0x2f              // =47
    dda4:      	strb	w13, [x8, x12]
    dda8:      	add	x19, x8, x12
    ddac:      	cmp	w23, w21
    ddb0:      	add	x2, x9, x10
    ddb4:      	and	w1, w11, #0xff
    ddb8:      	mov	w8, #0x4                // =4
    ddbc:      	cinc	x0, x19, hi
    ddc0:      	blr	x8
    ddc4:      	cmp	w23, w21
    ddc8:      	str	x19, [sp, #0x60]
    ddcc:      	add	x19, sp, #0x70
    ddd0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ddd4:      	ldr	x21, [sp, #0x78]
    ddd8:      	ldp	x2, x24, [sp, #0x50]
    dddc:      	str	x21, [sp, #0x48]
    dde0:      	b	0xde30 <generic_kprobe_path+0x4350>
    dde4:      	add	x2, x24, #0x10
    dde8:      	mov	w8, #0x4                // =4
    ddec:      	add	x9, sp, #0x98
    ddf0:      	add	x0, sp, #0x98
    ddf4:      	mov	w1, #0x8                // =8
    ddf8:      	blr	x8
    ddfc:      	ldr	x8, [sp, #0x58]
    de00:      	ldr	x9, [sp, #0x98]
    de04:      	cmp	x8, x9
    de08:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    de0c:      	add	x2, x24, #0x18
    de10:      	mov	w8, #0x4                // =4
    de14:      	mov	x0, x22
    de18:      	mov	w1, #0x8                // =8
    de1c:      	blr	x8
    de20:      	ldr	x24, [sp, #0x98]
    de24:      	ldr	x21, [sp, #0x48]
    de28:      	add	x2, x24, #0x20
    de2c:      	stp	x2, x24, [sp, #0x50]
    de30:      	ldr	x8, [sp, #0x30]
    de34:      	cmp	x21, x8
    de38:      	b.ne	0xde48 <generic_kprobe_path+0x4368>
    de3c:      	ldr	x8, [sp, #0x38]
    de40:      	cmp	x2, x8
    de44:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    de48:      	mov	w8, #0x4                // =4
    de4c:      	add	x0, sp, #0x70
    de50:      	mov	w1, #0x8                // =8
    de54:      	blr	x8
    de58:      	ldr	x8, [sp, #0x70]
    de5c:      	cmp	x21, x8
    de60:      	b.eq	0xdf50 <generic_kprobe_path+0x4470>
    de64:      	add	x23, x21, #0x18
    de68:      	mov	w8, #0x4                // =4
    de6c:      	add	x9, sp, #0x98
    de70:      	add	x0, sp, #0x98
    de74:      	mov	w1, #0x8                // =8
    de78:      	mov	x2, x23
    de7c:      	blr	x8
    de80:      	ldr	x8, [sp, #0x98]
    de84:      	cmp	x8, x21
    de88:      	b.eq	0xdf50 <generic_kprobe_path+0x4470>
    de8c:      	mov	w8, #0x4                // =4
    de90:      	add	x9, sp, #0x78
    de94:      	add	x0, sp, #0x78
    de98:      	mov	w1, #0x8                // =8
    de9c:      	mov	x2, x23
    dea0:      	blr	x8
    dea4:      	add	x2, x21, #0x20
    dea8:      	mov	w8, #0x4                // =4
    deac:      	mov	w9, #0x10               // =16
    deb0:      	add	x10, sp, #0x80
    deb4:      	add	x0, sp, #0x80
    deb8:      	mov	w1, #0x10               // =16
    debc:      	blr	x8
    dec0:      	ldr	w21, [sp, #0x84]
    dec4:      	ldr	x8, [sp, #0x40]
    dec8:      	ldr	x10, [sp, #0x60]
    decc:      	sub	x12, x10, x8
    ded0:      	ldr	w23, [sp, #0x68]
    ded4:      	subs	w10, w21, w23
    ded8:      	ldr	x9, [sp, #0x88]
    dedc:      	csel	w10, wzr, w10, lo
    dee0:      	cmp	w23, w21
    dee4:      	csel	w11, w23, w21, lo
    dee8:      	cinc	w13, w11, hi
    deec:      	sub	w14, w23, w13
    def0:      	subs	x12, x12, x13
    def4:      	str	w14, [sp, #0x68]
    def8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    defc:      	cmp	x12, #0xfff
    df00:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    df04:      	cmp	w23, w21
    df08:      	b.ls	0xdf14 <generic_kprobe_path+0x4434>
    df0c:      	mov	w13, #0x2f              // =47
    df10:      	strb	w13, [x8, x12]
    df14:      	add	x19, x8, x12
    df18:      	cmp	w23, w21
    df1c:      	add	x2, x9, x10
    df20:      	and	w1, w11, #0xff
    df24:      	mov	w8, #0x4                // =4
    df28:      	cinc	x0, x19, hi
    df2c:      	blr	x8
    df30:      	cmp	w23, w21
    df34:      	str	x19, [sp, #0x60]
    df38:      	add	x19, sp, #0x70
    df3c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    df40:      	ldr	x21, [sp, #0x78]
    df44:      	ldp	x2, x24, [sp, #0x50]
    df48:      	str	x21, [sp, #0x48]
    df4c:      	b	0xdf9c <generic_kprobe_path+0x44bc>
    df50:      	add	x2, x24, #0x10
    df54:      	mov	w8, #0x4                // =4
    df58:      	add	x9, sp, #0x98
    df5c:      	add	x0, sp, #0x98
    df60:      	mov	w1, #0x8                // =8
    df64:      	blr	x8
    df68:      	ldr	x8, [sp, #0x58]
    df6c:      	ldr	x9, [sp, #0x98]
    df70:      	cmp	x8, x9
    df74:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    df78:      	add	x2, x24, #0x18
    df7c:      	mov	w8, #0x4                // =4
    df80:      	mov	x0, x22
    df84:      	mov	w1, #0x8                // =8
    df88:      	blr	x8
    df8c:      	ldr	x24, [sp, #0x98]
    df90:      	ldr	x21, [sp, #0x48]
    df94:      	add	x2, x24, #0x20
    df98:      	stp	x2, x24, [sp, #0x50]
    df9c:      	ldr	x8, [sp, #0x30]
    dfa0:      	cmp	x21, x8
    dfa4:      	b.ne	0xdfb4 <generic_kprobe_path+0x44d4>
    dfa8:      	ldr	x8, [sp, #0x38]
    dfac:      	cmp	x2, x8
    dfb0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    dfb4:      	mov	w8, #0x4                // =4
    dfb8:      	add	x0, sp, #0x70
    dfbc:      	mov	w1, #0x8                // =8
    dfc0:      	blr	x8
    dfc4:      	ldr	x8, [sp, #0x70]
    dfc8:      	cmp	x21, x8
    dfcc:      	b.eq	0xe0bc <generic_kprobe_path+0x45dc>
    dfd0:      	add	x23, x21, #0x18
    dfd4:      	mov	w8, #0x4                // =4
    dfd8:      	add	x9, sp, #0x98
    dfdc:      	add	x0, sp, #0x98
    dfe0:      	mov	w1, #0x8                // =8
    dfe4:      	mov	x2, x23
    dfe8:      	blr	x8
    dfec:      	ldr	x8, [sp, #0x98]
    dff0:      	cmp	x8, x21
    dff4:      	b.eq	0xe0bc <generic_kprobe_path+0x45dc>
    dff8:      	mov	w8, #0x4                // =4
    dffc:      	add	x9, sp, #0x78
    e000:      	add	x0, sp, #0x78
    e004:      	mov	w1, #0x8                // =8
    e008:      	mov	x2, x23
    e00c:      	blr	x8
    e010:      	add	x2, x21, #0x20
    e014:      	mov	w8, #0x4                // =4
    e018:      	mov	w9, #0x10               // =16
    e01c:      	add	x10, sp, #0x80
    e020:      	add	x0, sp, #0x80
    e024:      	mov	w1, #0x10               // =16
    e028:      	blr	x8
    e02c:      	ldr	w21, [sp, #0x84]
    e030:      	ldr	x8, [sp, #0x40]
    e034:      	ldr	x10, [sp, #0x60]
    e038:      	sub	x12, x10, x8
    e03c:      	ldr	w23, [sp, #0x68]
    e040:      	subs	w10, w21, w23
    e044:      	ldr	x9, [sp, #0x88]
    e048:      	csel	w10, wzr, w10, lo
    e04c:      	cmp	w23, w21
    e050:      	csel	w11, w23, w21, lo
    e054:      	cinc	w13, w11, hi
    e058:      	sub	w14, w23, w13
    e05c:      	subs	x12, x12, x13
    e060:      	str	w14, [sp, #0x68]
    e064:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e068:      	cmp	x12, #0xfff
    e06c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e070:      	cmp	w23, w21
    e074:      	b.ls	0xe080 <generic_kprobe_path+0x45a0>
    e078:      	mov	w13, #0x2f              // =47
    e07c:      	strb	w13, [x8, x12]
    e080:      	add	x19, x8, x12
    e084:      	cmp	w23, w21
    e088:      	add	x2, x9, x10
    e08c:      	and	w1, w11, #0xff
    e090:      	mov	w8, #0x4                // =4
    e094:      	cinc	x0, x19, hi
    e098:      	blr	x8
    e09c:      	cmp	w23, w21
    e0a0:      	str	x19, [sp, #0x60]
    e0a4:      	add	x19, sp, #0x70
    e0a8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e0ac:      	ldr	x21, [sp, #0x78]
    e0b0:      	ldp	x2, x24, [sp, #0x50]
    e0b4:      	str	x21, [sp, #0x48]
    e0b8:      	b	0xe108 <generic_kprobe_path+0x4628>
    e0bc:      	add	x2, x24, #0x10
    e0c0:      	mov	w8, #0x4                // =4
    e0c4:      	add	x9, sp, #0x98
    e0c8:      	add	x0, sp, #0x98
    e0cc:      	mov	w1, #0x8                // =8
    e0d0:      	blr	x8
    e0d4:      	ldr	x8, [sp, #0x58]
    e0d8:      	ldr	x9, [sp, #0x98]
    e0dc:      	cmp	x8, x9
    e0e0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e0e4:      	add	x2, x24, #0x18
    e0e8:      	mov	w8, #0x4                // =4
    e0ec:      	mov	x0, x22
    e0f0:      	mov	w1, #0x8                // =8
    e0f4:      	blr	x8
    e0f8:      	ldr	x24, [sp, #0x98]
    e0fc:      	ldr	x21, [sp, #0x48]
    e100:      	add	x2, x24, #0x20
    e104:      	stp	x2, x24, [sp, #0x50]
    e108:      	ldr	x8, [sp, #0x30]
    e10c:      	cmp	x21, x8
    e110:      	b.ne	0xe120 <generic_kprobe_path+0x4640>
    e114:      	ldr	x8, [sp, #0x38]
    e118:      	cmp	x2, x8
    e11c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e120:      	mov	w8, #0x4                // =4
    e124:      	add	x0, sp, #0x70
    e128:      	mov	w1, #0x8                // =8
    e12c:      	blr	x8
    e130:      	ldr	x8, [sp, #0x70]
    e134:      	cmp	x21, x8
    e138:      	b.eq	0xe228 <generic_kprobe_path+0x4748>
    e13c:      	add	x23, x21, #0x18
    e140:      	mov	w8, #0x4                // =4
    e144:      	add	x9, sp, #0x98
    e148:      	add	x0, sp, #0x98
    e14c:      	mov	w1, #0x8                // =8
    e150:      	mov	x2, x23
    e154:      	blr	x8
    e158:      	ldr	x8, [sp, #0x98]
    e15c:      	cmp	x8, x21
    e160:      	b.eq	0xe228 <generic_kprobe_path+0x4748>
    e164:      	mov	w8, #0x4                // =4
    e168:      	add	x9, sp, #0x78
    e16c:      	add	x0, sp, #0x78
    e170:      	mov	w1, #0x8                // =8
    e174:      	mov	x2, x23
    e178:      	blr	x8
    e17c:      	add	x2, x21, #0x20
    e180:      	mov	w8, #0x4                // =4
    e184:      	mov	w9, #0x10               // =16
    e188:      	add	x10, sp, #0x80
    e18c:      	add	x0, sp, #0x80
    e190:      	mov	w1, #0x10               // =16
    e194:      	blr	x8
    e198:      	ldr	w21, [sp, #0x84]
    e19c:      	ldr	x8, [sp, #0x40]
    e1a0:      	ldr	x10, [sp, #0x60]
    e1a4:      	sub	x12, x10, x8
    e1a8:      	ldr	w23, [sp, #0x68]
    e1ac:      	subs	w10, w21, w23
    e1b0:      	ldr	x9, [sp, #0x88]
    e1b4:      	csel	w10, wzr, w10, lo
    e1b8:      	cmp	w23, w21
    e1bc:      	csel	w11, w23, w21, lo
    e1c0:      	cinc	w13, w11, hi
    e1c4:      	sub	w14, w23, w13
    e1c8:      	subs	x12, x12, x13
    e1cc:      	str	w14, [sp, #0x68]
    e1d0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e1d4:      	cmp	x12, #0xfff
    e1d8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e1dc:      	cmp	w23, w21
    e1e0:      	b.ls	0xe1ec <generic_kprobe_path+0x470c>
    e1e4:      	mov	w13, #0x2f              // =47
    e1e8:      	strb	w13, [x8, x12]
    e1ec:      	add	x19, x8, x12
    e1f0:      	cmp	w23, w21
    e1f4:      	add	x2, x9, x10
    e1f8:      	and	w1, w11, #0xff
    e1fc:      	mov	w8, #0x4                // =4
    e200:      	cinc	x0, x19, hi
    e204:      	blr	x8
    e208:      	cmp	w23, w21
    e20c:      	str	x19, [sp, #0x60]
    e210:      	add	x19, sp, #0x70
    e214:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e218:      	ldr	x21, [sp, #0x78]
    e21c:      	ldp	x2, x24, [sp, #0x50]
    e220:      	str	x21, [sp, #0x48]
    e224:      	b	0xe274 <generic_kprobe_path+0x4794>
    e228:      	add	x2, x24, #0x10
    e22c:      	mov	w8, #0x4                // =4
    e230:      	add	x9, sp, #0x98
    e234:      	add	x0, sp, #0x98
    e238:      	mov	w1, #0x8                // =8
    e23c:      	blr	x8
    e240:      	ldr	x8, [sp, #0x58]
    e244:      	ldr	x9, [sp, #0x98]
    e248:      	cmp	x8, x9
    e24c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e250:      	add	x2, x24, #0x18
    e254:      	mov	w8, #0x4                // =4
    e258:      	mov	x0, x22
    e25c:      	mov	w1, #0x8                // =8
    e260:      	blr	x8
    e264:      	ldr	x24, [sp, #0x98]
    e268:      	ldr	x21, [sp, #0x48]
    e26c:      	add	x2, x24, #0x20
    e270:      	stp	x2, x24, [sp, #0x50]
    e274:      	ldr	x8, [sp, #0x30]
    e278:      	cmp	x21, x8
    e27c:      	b.ne	0xe28c <generic_kprobe_path+0x47ac>
    e280:      	ldr	x8, [sp, #0x38]
    e284:      	cmp	x2, x8
    e288:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e28c:      	mov	w8, #0x4                // =4
    e290:      	add	x0, sp, #0x70
    e294:      	mov	w1, #0x8                // =8
    e298:      	blr	x8
    e29c:      	ldr	x8, [sp, #0x70]
    e2a0:      	cmp	x21, x8
    e2a4:      	b.eq	0xe394 <generic_kprobe_path+0x48b4>
    e2a8:      	add	x23, x21, #0x18
    e2ac:      	mov	w8, #0x4                // =4
    e2b0:      	add	x9, sp, #0x98
    e2b4:      	add	x0, sp, #0x98
    e2b8:      	mov	w1, #0x8                // =8
    e2bc:      	mov	x2, x23
    e2c0:      	blr	x8
    e2c4:      	ldr	x8, [sp, #0x98]
    e2c8:      	cmp	x8, x21
    e2cc:      	b.eq	0xe394 <generic_kprobe_path+0x48b4>
    e2d0:      	mov	w8, #0x4                // =4
    e2d4:      	add	x9, sp, #0x78
    e2d8:      	add	x0, sp, #0x78
    e2dc:      	mov	w1, #0x8                // =8
    e2e0:      	mov	x2, x23
    e2e4:      	blr	x8
    e2e8:      	add	x2, x21, #0x20
    e2ec:      	mov	w8, #0x4                // =4
    e2f0:      	mov	w9, #0x10               // =16
    e2f4:      	add	x10, sp, #0x80
    e2f8:      	add	x0, sp, #0x80
    e2fc:      	mov	w1, #0x10               // =16
    e300:      	blr	x8
    e304:      	ldr	w21, [sp, #0x84]
    e308:      	ldr	x8, [sp, #0x40]
    e30c:      	ldr	x10, [sp, #0x60]
    e310:      	sub	x12, x10, x8
    e314:      	ldr	w23, [sp, #0x68]
    e318:      	subs	w10, w21, w23
    e31c:      	ldr	x9, [sp, #0x88]
    e320:      	csel	w10, wzr, w10, lo
    e324:      	cmp	w23, w21
    e328:      	csel	w11, w23, w21, lo
    e32c:      	cinc	w13, w11, hi
    e330:      	sub	w14, w23, w13
    e334:      	subs	x12, x12, x13
    e338:      	str	w14, [sp, #0x68]
    e33c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e340:      	cmp	x12, #0xfff
    e344:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e348:      	cmp	w23, w21
    e34c:      	b.ls	0xe358 <generic_kprobe_path+0x4878>
    e350:      	mov	w13, #0x2f              // =47
    e354:      	strb	w13, [x8, x12]
    e358:      	add	x19, x8, x12
    e35c:      	cmp	w23, w21
    e360:      	add	x2, x9, x10
    e364:      	and	w1, w11, #0xff
    e368:      	mov	w8, #0x4                // =4
    e36c:      	cinc	x0, x19, hi
    e370:      	blr	x8
    e374:      	cmp	w23, w21
    e378:      	str	x19, [sp, #0x60]
    e37c:      	add	x19, sp, #0x70
    e380:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e384:      	ldr	x21, [sp, #0x78]
    e388:      	ldp	x2, x24, [sp, #0x50]
    e38c:      	str	x21, [sp, #0x48]
    e390:      	b	0xe3e0 <generic_kprobe_path+0x4900>
    e394:      	add	x2, x24, #0x10
    e398:      	mov	w8, #0x4                // =4
    e39c:      	add	x9, sp, #0x98
    e3a0:      	add	x0, sp, #0x98
    e3a4:      	mov	w1, #0x8                // =8
    e3a8:      	blr	x8
    e3ac:      	ldr	x8, [sp, #0x58]
    e3b0:      	ldr	x9, [sp, #0x98]
    e3b4:      	cmp	x8, x9
    e3b8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e3bc:      	add	x2, x24, #0x18
    e3c0:      	mov	w8, #0x4                // =4
    e3c4:      	mov	x0, x22
    e3c8:      	mov	w1, #0x8                // =8
    e3cc:      	blr	x8
    e3d0:      	ldr	x24, [sp, #0x98]
    e3d4:      	ldr	x21, [sp, #0x48]
    e3d8:      	add	x2, x24, #0x20
    e3dc:      	stp	x2, x24, [sp, #0x50]
    e3e0:      	ldr	x8, [sp, #0x30]
    e3e4:      	cmp	x21, x8
    e3e8:      	b.ne	0xe3f8 <generic_kprobe_path+0x4918>
    e3ec:      	ldr	x8, [sp, #0x38]
    e3f0:      	cmp	x2, x8
    e3f4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e3f8:      	mov	w8, #0x4                // =4
    e3fc:      	add	x0, sp, #0x70
    e400:      	mov	w1, #0x8                // =8
    e404:      	blr	x8
    e408:      	ldr	x8, [sp, #0x70]
    e40c:      	cmp	x21, x8
    e410:      	b.eq	0xe500 <generic_kprobe_path+0x4a20>
    e414:      	add	x23, x21, #0x18
    e418:      	mov	w8, #0x4                // =4
    e41c:      	add	x9, sp, #0x98
    e420:      	add	x0, sp, #0x98
    e424:      	mov	w1, #0x8                // =8
    e428:      	mov	x2, x23
    e42c:      	blr	x8
    e430:      	ldr	x8, [sp, #0x98]
    e434:      	cmp	x8, x21
    e438:      	b.eq	0xe500 <generic_kprobe_path+0x4a20>
    e43c:      	mov	w8, #0x4                // =4
    e440:      	add	x9, sp, #0x78
    e444:      	add	x0, sp, #0x78
    e448:      	mov	w1, #0x8                // =8
    e44c:      	mov	x2, x23
    e450:      	blr	x8
    e454:      	add	x2, x21, #0x20
    e458:      	mov	w8, #0x4                // =4
    e45c:      	mov	w9, #0x10               // =16
    e460:      	add	x10, sp, #0x80
    e464:      	add	x0, sp, #0x80
    e468:      	mov	w1, #0x10               // =16
    e46c:      	blr	x8
    e470:      	ldr	w21, [sp, #0x84]
    e474:      	ldr	x8, [sp, #0x40]
    e478:      	ldr	x10, [sp, #0x60]
    e47c:      	sub	x12, x10, x8
    e480:      	ldr	w23, [sp, #0x68]
    e484:      	subs	w10, w21, w23
    e488:      	ldr	x9, [sp, #0x88]
    e48c:      	csel	w10, wzr, w10, lo
    e490:      	cmp	w23, w21
    e494:      	csel	w11, w23, w21, lo
    e498:      	cinc	w13, w11, hi
    e49c:      	sub	w14, w23, w13
    e4a0:      	subs	x12, x12, x13
    e4a4:      	str	w14, [sp, #0x68]
    e4a8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e4ac:      	cmp	x12, #0xfff
    e4b0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e4b4:      	cmp	w23, w21
    e4b8:      	b.ls	0xe4c4 <generic_kprobe_path+0x49e4>
    e4bc:      	mov	w13, #0x2f              // =47
    e4c0:      	strb	w13, [x8, x12]
    e4c4:      	add	x19, x8, x12
    e4c8:      	cmp	w23, w21
    e4cc:      	add	x2, x9, x10
    e4d0:      	and	w1, w11, #0xff
    e4d4:      	mov	w8, #0x4                // =4
    e4d8:      	cinc	x0, x19, hi
    e4dc:      	blr	x8
    e4e0:      	cmp	w23, w21
    e4e4:      	str	x19, [sp, #0x60]
    e4e8:      	add	x19, sp, #0x70
    e4ec:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e4f0:      	ldr	x21, [sp, #0x78]
    e4f4:      	ldp	x2, x24, [sp, #0x50]
    e4f8:      	str	x21, [sp, #0x48]
    e4fc:      	b	0xe54c <generic_kprobe_path+0x4a6c>
    e500:      	add	x2, x24, #0x10
    e504:      	mov	w8, #0x4                // =4
    e508:      	add	x9, sp, #0x98
    e50c:      	add	x0, sp, #0x98
    e510:      	mov	w1, #0x8                // =8
    e514:      	blr	x8
    e518:      	ldr	x8, [sp, #0x58]
    e51c:      	ldr	x9, [sp, #0x98]
    e520:      	cmp	x8, x9
    e524:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e528:      	add	x2, x24, #0x18
    e52c:      	mov	w8, #0x4                // =4
    e530:      	mov	x0, x22
    e534:      	mov	w1, #0x8                // =8
    e538:      	blr	x8
    e53c:      	ldr	x24, [sp, #0x98]
    e540:      	ldr	x21, [sp, #0x48]
    e544:      	add	x2, x24, #0x20
    e548:      	stp	x2, x24, [sp, #0x50]
    e54c:      	ldr	x8, [sp, #0x30]
    e550:      	cmp	x21, x8
    e554:      	b.ne	0xe564 <generic_kprobe_path+0x4a84>
    e558:      	ldr	x8, [sp, #0x38]
    e55c:      	cmp	x2, x8
    e560:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e564:      	mov	w8, #0x4                // =4
    e568:      	add	x0, sp, #0x70
    e56c:      	mov	w1, #0x8                // =8
    e570:      	blr	x8
    e574:      	ldr	x8, [sp, #0x70]
    e578:      	cmp	x21, x8
    e57c:      	b.eq	0xe66c <generic_kprobe_path+0x4b8c>
    e580:      	add	x23, x21, #0x18
    e584:      	mov	w8, #0x4                // =4
    e588:      	add	x9, sp, #0x98
    e58c:      	add	x0, sp, #0x98
    e590:      	mov	w1, #0x8                // =8
    e594:      	mov	x2, x23
    e598:      	blr	x8
    e59c:      	ldr	x8, [sp, #0x98]
    e5a0:      	cmp	x8, x21
    e5a4:      	b.eq	0xe66c <generic_kprobe_path+0x4b8c>
    e5a8:      	mov	w8, #0x4                // =4
    e5ac:      	add	x9, sp, #0x78
    e5b0:      	add	x0, sp, #0x78
    e5b4:      	mov	w1, #0x8                // =8
    e5b8:      	mov	x2, x23
    e5bc:      	blr	x8
    e5c0:      	add	x2, x21, #0x20
    e5c4:      	mov	w8, #0x4                // =4
    e5c8:      	mov	w9, #0x10               // =16
    e5cc:      	add	x10, sp, #0x80
    e5d0:      	add	x0, sp, #0x80
    e5d4:      	mov	w1, #0x10               // =16
    e5d8:      	blr	x8
    e5dc:      	ldr	w21, [sp, #0x84]
    e5e0:      	ldr	x8, [sp, #0x40]
    e5e4:      	ldr	x10, [sp, #0x60]
    e5e8:      	sub	x12, x10, x8
    e5ec:      	ldr	w23, [sp, #0x68]
    e5f0:      	subs	w10, w21, w23
    e5f4:      	ldr	x9, [sp, #0x88]
    e5f8:      	csel	w10, wzr, w10, lo
    e5fc:      	cmp	w23, w21
    e600:      	csel	w11, w23, w21, lo
    e604:      	cinc	w13, w11, hi
    e608:      	sub	w14, w23, w13
    e60c:      	subs	x12, x12, x13
    e610:      	str	w14, [sp, #0x68]
    e614:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e618:      	cmp	x12, #0xfff
    e61c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e620:      	cmp	w23, w21
    e624:      	b.ls	0xe630 <generic_kprobe_path+0x4b50>
    e628:      	mov	w13, #0x2f              // =47
    e62c:      	strb	w13, [x8, x12]
    e630:      	add	x19, x8, x12
    e634:      	cmp	w23, w21
    e638:      	add	x2, x9, x10
    e63c:      	and	w1, w11, #0xff
    e640:      	mov	w8, #0x4                // =4
    e644:      	cinc	x0, x19, hi
    e648:      	blr	x8
    e64c:      	cmp	w23, w21
    e650:      	str	x19, [sp, #0x60]
    e654:      	add	x19, sp, #0x70
    e658:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e65c:      	ldr	x21, [sp, #0x78]
    e660:      	ldp	x2, x24, [sp, #0x50]
    e664:      	str	x21, [sp, #0x48]
    e668:      	b	0xe6b8 <generic_kprobe_path+0x4bd8>
    e66c:      	add	x2, x24, #0x10
    e670:      	mov	w8, #0x4                // =4
    e674:      	add	x9, sp, #0x98
    e678:      	add	x0, sp, #0x98
    e67c:      	mov	w1, #0x8                // =8
    e680:      	blr	x8
    e684:      	ldr	x8, [sp, #0x58]
    e688:      	ldr	x9, [sp, #0x98]
    e68c:      	cmp	x8, x9
    e690:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e694:      	add	x2, x24, #0x18
    e698:      	mov	w8, #0x4                // =4
    e69c:      	mov	x0, x22
    e6a0:      	mov	w1, #0x8                // =8
    e6a4:      	blr	x8
    e6a8:      	ldr	x24, [sp, #0x98]
    e6ac:      	ldr	x21, [sp, #0x48]
    e6b0:      	add	x2, x24, #0x20
    e6b4:      	stp	x2, x24, [sp, #0x50]
    e6b8:      	ldr	x8, [sp, #0x30]
    e6bc:      	cmp	x21, x8
    e6c0:      	b.ne	0xe6d0 <generic_kprobe_path+0x4bf0>
    e6c4:      	ldr	x8, [sp, #0x38]
    e6c8:      	cmp	x2, x8
    e6cc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e6d0:      	mov	w8, #0x4                // =4
    e6d4:      	add	x0, sp, #0x70
    e6d8:      	mov	w1, #0x8                // =8
    e6dc:      	blr	x8
    e6e0:      	ldr	x8, [sp, #0x70]
    e6e4:      	cmp	x21, x8
    e6e8:      	b.eq	0xe7d8 <generic_kprobe_path+0x4cf8>
    e6ec:      	add	x23, x21, #0x18
    e6f0:      	mov	w8, #0x4                // =4
    e6f4:      	add	x9, sp, #0x98
    e6f8:      	add	x0, sp, #0x98
    e6fc:      	mov	w1, #0x8                // =8
    e700:      	mov	x2, x23
    e704:      	blr	x8
    e708:      	ldr	x8, [sp, #0x98]
    e70c:      	cmp	x8, x21
    e710:      	b.eq	0xe7d8 <generic_kprobe_path+0x4cf8>
    e714:      	mov	w8, #0x4                // =4
    e718:      	add	x9, sp, #0x78
    e71c:      	add	x0, sp, #0x78
    e720:      	mov	w1, #0x8                // =8
    e724:      	mov	x2, x23
    e728:      	blr	x8
    e72c:      	add	x2, x21, #0x20
    e730:      	mov	w8, #0x4                // =4
    e734:      	mov	w9, #0x10               // =16
    e738:      	add	x10, sp, #0x80
    e73c:      	add	x0, sp, #0x80
    e740:      	mov	w1, #0x10               // =16
    e744:      	blr	x8
    e748:      	ldr	w21, [sp, #0x84]
    e74c:      	ldr	x8, [sp, #0x40]
    e750:      	ldr	x10, [sp, #0x60]
    e754:      	sub	x12, x10, x8
    e758:      	ldr	w23, [sp, #0x68]
    e75c:      	subs	w10, w21, w23
    e760:      	ldr	x9, [sp, #0x88]
    e764:      	csel	w10, wzr, w10, lo
    e768:      	cmp	w23, w21
    e76c:      	csel	w11, w23, w21, lo
    e770:      	cinc	w13, w11, hi
    e774:      	sub	w14, w23, w13
    e778:      	subs	x12, x12, x13
    e77c:      	str	w14, [sp, #0x68]
    e780:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e784:      	cmp	x12, #0xfff
    e788:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e78c:      	cmp	w23, w21
    e790:      	b.ls	0xe79c <generic_kprobe_path+0x4cbc>
    e794:      	mov	w13, #0x2f              // =47
    e798:      	strb	w13, [x8, x12]
    e79c:      	add	x19, x8, x12
    e7a0:      	cmp	w23, w21
    e7a4:      	add	x2, x9, x10
    e7a8:      	and	w1, w11, #0xff
    e7ac:      	mov	w8, #0x4                // =4
    e7b0:      	cinc	x0, x19, hi
    e7b4:      	blr	x8
    e7b8:      	cmp	w23, w21
    e7bc:      	str	x19, [sp, #0x60]
    e7c0:      	add	x19, sp, #0x70
    e7c4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e7c8:      	ldr	x21, [sp, #0x78]
    e7cc:      	ldp	x2, x24, [sp, #0x50]
    e7d0:      	str	x21, [sp, #0x48]
    e7d4:      	b	0xe824 <generic_kprobe_path+0x4d44>
    e7d8:      	add	x2, x24, #0x10
    e7dc:      	mov	w8, #0x4                // =4
    e7e0:      	add	x9, sp, #0x98
    e7e4:      	add	x0, sp, #0x98
    e7e8:      	mov	w1, #0x8                // =8
    e7ec:      	blr	x8
    e7f0:      	ldr	x8, [sp, #0x58]
    e7f4:      	ldr	x9, [sp, #0x98]
    e7f8:      	cmp	x8, x9
    e7fc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e800:      	add	x2, x24, #0x18
    e804:      	mov	w8, #0x4                // =4
    e808:      	mov	x0, x22
    e80c:      	mov	w1, #0x8                // =8
    e810:      	blr	x8
    e814:      	ldr	x24, [sp, #0x98]
    e818:      	ldr	x21, [sp, #0x48]
    e81c:      	add	x2, x24, #0x20
    e820:      	stp	x2, x24, [sp, #0x50]
    e824:      	ldr	x8, [sp, #0x30]
    e828:      	cmp	x21, x8
    e82c:      	b.ne	0xe83c <generic_kprobe_path+0x4d5c>
    e830:      	ldr	x8, [sp, #0x38]
    e834:      	cmp	x2, x8
    e838:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e83c:      	mov	w8, #0x4                // =4
    e840:      	add	x0, sp, #0x70
    e844:      	mov	w1, #0x8                // =8
    e848:      	blr	x8
    e84c:      	ldr	x8, [sp, #0x70]
    e850:      	cmp	x21, x8
    e854:      	b.eq	0xe944 <generic_kprobe_path+0x4e64>
    e858:      	add	x23, x21, #0x18
    e85c:      	mov	w8, #0x4                // =4
    e860:      	add	x9, sp, #0x98
    e864:      	add	x0, sp, #0x98
    e868:      	mov	w1, #0x8                // =8
    e86c:      	mov	x2, x23
    e870:      	blr	x8
    e874:      	ldr	x8, [sp, #0x98]
    e878:      	cmp	x8, x21
    e87c:      	b.eq	0xe944 <generic_kprobe_path+0x4e64>
    e880:      	mov	w8, #0x4                // =4
    e884:      	add	x9, sp, #0x78
    e888:      	add	x0, sp, #0x78
    e88c:      	mov	w1, #0x8                // =8
    e890:      	mov	x2, x23
    e894:      	blr	x8
    e898:      	add	x2, x21, #0x20
    e89c:      	mov	w8, #0x4                // =4
    e8a0:      	mov	w9, #0x10               // =16
    e8a4:      	add	x10, sp, #0x80
    e8a8:      	add	x0, sp, #0x80
    e8ac:      	mov	w1, #0x10               // =16
    e8b0:      	blr	x8
    e8b4:      	ldr	w21, [sp, #0x84]
    e8b8:      	ldr	x8, [sp, #0x40]
    e8bc:      	ldr	x10, [sp, #0x60]
    e8c0:      	sub	x12, x10, x8
    e8c4:      	ldr	w23, [sp, #0x68]
    e8c8:      	subs	w10, w21, w23
    e8cc:      	ldr	x9, [sp, #0x88]
    e8d0:      	csel	w10, wzr, w10, lo
    e8d4:      	cmp	w23, w21
    e8d8:      	csel	w11, w23, w21, lo
    e8dc:      	cinc	w13, w11, hi
    e8e0:      	sub	w14, w23, w13
    e8e4:      	subs	x12, x12, x13
    e8e8:      	str	w14, [sp, #0x68]
    e8ec:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    e8f0:      	cmp	x12, #0xfff
    e8f4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    e8f8:      	cmp	w23, w21
    e8fc:      	b.ls	0xe908 <generic_kprobe_path+0x4e28>
    e900:      	mov	w13, #0x2f              // =47
    e904:      	strb	w13, [x8, x12]
    e908:      	add	x19, x8, x12
    e90c:      	cmp	w23, w21
    e910:      	add	x2, x9, x10
    e914:      	and	w1, w11, #0xff
    e918:      	mov	w8, #0x4                // =4
    e91c:      	cinc	x0, x19, hi
    e920:      	blr	x8
    e924:      	cmp	w23, w21
    e928:      	str	x19, [sp, #0x60]
    e92c:      	add	x19, sp, #0x70
    e930:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    e934:      	ldr	x21, [sp, #0x78]
    e938:      	ldp	x2, x24, [sp, #0x50]
    e93c:      	str	x21, [sp, #0x48]
    e940:      	b	0xe990 <generic_kprobe_path+0x4eb0>
    e944:      	add	x2, x24, #0x10
    e948:      	mov	w8, #0x4                // =4
    e94c:      	add	x9, sp, #0x98
    e950:      	add	x0, sp, #0x98
    e954:      	mov	w1, #0x8                // =8
    e958:      	blr	x8
    e95c:      	ldr	x8, [sp, #0x58]
    e960:      	ldr	x9, [sp, #0x98]
    e964:      	cmp	x8, x9
    e968:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e96c:      	add	x2, x24, #0x18
    e970:      	mov	w8, #0x4                // =4
    e974:      	mov	x0, x22
    e978:      	mov	w1, #0x8                // =8
    e97c:      	blr	x8
    e980:      	ldr	x24, [sp, #0x98]
    e984:      	ldr	x21, [sp, #0x48]
    e988:      	add	x2, x24, #0x20
    e98c:      	stp	x2, x24, [sp, #0x50]
    e990:      	ldr	x8, [sp, #0x30]
    e994:      	cmp	x21, x8
    e998:      	b.ne	0xe9a8 <generic_kprobe_path+0x4ec8>
    e99c:      	ldr	x8, [sp, #0x38]
    e9a0:      	cmp	x2, x8
    e9a4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    e9a8:      	mov	w8, #0x4                // =4
    e9ac:      	add	x0, sp, #0x70
    e9b0:      	mov	w1, #0x8                // =8
    e9b4:      	blr	x8
    e9b8:      	ldr	x8, [sp, #0x70]
    e9bc:      	cmp	x21, x8
    e9c0:      	b.eq	0xeab0 <generic_kprobe_path+0x4fd0>
    e9c4:      	add	x23, x21, #0x18
    e9c8:      	mov	w8, #0x4                // =4
    e9cc:      	add	x9, sp, #0x98
    e9d0:      	add	x0, sp, #0x98
    e9d4:      	mov	w1, #0x8                // =8
    e9d8:      	mov	x2, x23
    e9dc:      	blr	x8
    e9e0:      	ldr	x8, [sp, #0x98]
    e9e4:      	cmp	x8, x21
    e9e8:      	b.eq	0xeab0 <generic_kprobe_path+0x4fd0>
    e9ec:      	mov	w8, #0x4                // =4
    e9f0:      	add	x9, sp, #0x78
    e9f4:      	add	x0, sp, #0x78
    e9f8:      	mov	w1, #0x8                // =8
    e9fc:      	mov	x2, x23
    ea00:      	blr	x8
    ea04:      	add	x2, x21, #0x20
    ea08:      	mov	w8, #0x4                // =4
    ea0c:      	mov	w9, #0x10               // =16
    ea10:      	add	x10, sp, #0x80
    ea14:      	add	x0, sp, #0x80
    ea18:      	mov	w1, #0x10               // =16
    ea1c:      	blr	x8
    ea20:      	ldr	w21, [sp, #0x84]
    ea24:      	ldr	x8, [sp, #0x40]
    ea28:      	ldr	x10, [sp, #0x60]
    ea2c:      	sub	x12, x10, x8
    ea30:      	ldr	w23, [sp, #0x68]
    ea34:      	subs	w10, w21, w23
    ea38:      	ldr	x9, [sp, #0x88]
    ea3c:      	csel	w10, wzr, w10, lo
    ea40:      	cmp	w23, w21
    ea44:      	csel	w11, w23, w21, lo
    ea48:      	cinc	w13, w11, hi
    ea4c:      	sub	w14, w23, w13
    ea50:      	subs	x12, x12, x13
    ea54:      	str	w14, [sp, #0x68]
    ea58:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    ea5c:      	cmp	x12, #0xfff
    ea60:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    ea64:      	cmp	w23, w21
    ea68:      	b.ls	0xea74 <generic_kprobe_path+0x4f94>
    ea6c:      	mov	w13, #0x2f              // =47
    ea70:      	strb	w13, [x8, x12]
    ea74:      	add	x19, x8, x12
    ea78:      	cmp	w23, w21
    ea7c:      	add	x2, x9, x10
    ea80:      	and	w1, w11, #0xff
    ea84:      	mov	w8, #0x4                // =4
    ea88:      	cinc	x0, x19, hi
    ea8c:      	blr	x8
    ea90:      	cmp	w23, w21
    ea94:      	str	x19, [sp, #0x60]
    ea98:      	add	x19, sp, #0x70
    ea9c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    eaa0:      	ldr	x21, [sp, #0x78]
    eaa4:      	ldp	x2, x24, [sp, #0x50]
    eaa8:      	str	x21, [sp, #0x48]
    eaac:      	b	0xeafc <generic_kprobe_path+0x501c>
    eab0:      	add	x2, x24, #0x10
    eab4:      	mov	w8, #0x4                // =4
    eab8:      	add	x9, sp, #0x98
    eabc:      	add	x0, sp, #0x98
    eac0:      	mov	w1, #0x8                // =8
    eac4:      	blr	x8
    eac8:      	ldr	x8, [sp, #0x58]
    eacc:      	ldr	x9, [sp, #0x98]
    ead0:      	cmp	x8, x9
    ead4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ead8:      	add	x2, x24, #0x18
    eadc:      	mov	w8, #0x4                // =4
    eae0:      	mov	x0, x22
    eae4:      	mov	w1, #0x8                // =8
    eae8:      	blr	x8
    eaec:      	ldr	x24, [sp, #0x98]
    eaf0:      	ldr	x21, [sp, #0x48]
    eaf4:      	add	x2, x24, #0x20
    eaf8:      	stp	x2, x24, [sp, #0x50]
    eafc:      	ldr	x8, [sp, #0x30]
    eb00:      	cmp	x21, x8
    eb04:      	b.ne	0xeb14 <generic_kprobe_path+0x5034>
    eb08:      	ldr	x8, [sp, #0x38]
    eb0c:      	cmp	x2, x8
    eb10:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    eb14:      	mov	w8, #0x4                // =4
    eb18:      	add	x0, sp, #0x70
    eb1c:      	mov	w1, #0x8                // =8
    eb20:      	blr	x8
    eb24:      	ldr	x8, [sp, #0x70]
    eb28:      	cmp	x21, x8
    eb2c:      	b.eq	0xec1c <generic_kprobe_path+0x513c>
    eb30:      	add	x23, x21, #0x18
    eb34:      	mov	w8, #0x4                // =4
    eb38:      	add	x9, sp, #0x98
    eb3c:      	add	x0, sp, #0x98
    eb40:      	mov	w1, #0x8                // =8
    eb44:      	mov	x2, x23
    eb48:      	blr	x8
    eb4c:      	ldr	x8, [sp, #0x98]
    eb50:      	cmp	x8, x21
    eb54:      	b.eq	0xec1c <generic_kprobe_path+0x513c>
    eb58:      	mov	w8, #0x4                // =4
    eb5c:      	add	x9, sp, #0x78
    eb60:      	add	x0, sp, #0x78
    eb64:      	mov	w1, #0x8                // =8
    eb68:      	mov	x2, x23
    eb6c:      	blr	x8
    eb70:      	add	x2, x21, #0x20
    eb74:      	mov	w8, #0x4                // =4
    eb78:      	mov	w9, #0x10               // =16
    eb7c:      	add	x10, sp, #0x80
    eb80:      	add	x0, sp, #0x80
    eb84:      	mov	w1, #0x10               // =16
    eb88:      	blr	x8
    eb8c:      	ldr	w21, [sp, #0x84]
    eb90:      	ldr	x8, [sp, #0x40]
    eb94:      	ldr	x10, [sp, #0x60]
    eb98:      	sub	x12, x10, x8
    eb9c:      	ldr	w23, [sp, #0x68]
    eba0:      	subs	w10, w21, w23
    eba4:      	ldr	x9, [sp, #0x88]
    eba8:      	csel	w10, wzr, w10, lo
    ebac:      	cmp	w23, w21
    ebb0:      	csel	w11, w23, w21, lo
    ebb4:      	cinc	w13, w11, hi
    ebb8:      	sub	w14, w23, w13
    ebbc:      	subs	x12, x12, x13
    ebc0:      	str	w14, [sp, #0x68]
    ebc4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    ebc8:      	cmp	x12, #0xfff
    ebcc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    ebd0:      	cmp	w23, w21
    ebd4:      	b.ls	0xebe0 <generic_kprobe_path+0x5100>
    ebd8:      	mov	w13, #0x2f              // =47
    ebdc:      	strb	w13, [x8, x12]
    ebe0:      	add	x19, x8, x12
    ebe4:      	cmp	w23, w21
    ebe8:      	add	x2, x9, x10
    ebec:      	and	w1, w11, #0xff
    ebf0:      	mov	w8, #0x4                // =4
    ebf4:      	cinc	x0, x19, hi
    ebf8:      	blr	x8
    ebfc:      	cmp	w23, w21
    ec00:      	str	x19, [sp, #0x60]
    ec04:      	add	x19, sp, #0x70
    ec08:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ec0c:      	ldr	x21, [sp, #0x78]
    ec10:      	ldp	x2, x24, [sp, #0x50]
    ec14:      	str	x21, [sp, #0x48]
    ec18:      	b	0xec68 <generic_kprobe_path+0x5188>
    ec1c:      	add	x2, x24, #0x10
    ec20:      	mov	w8, #0x4                // =4
    ec24:      	add	x9, sp, #0x98
    ec28:      	add	x0, sp, #0x98
    ec2c:      	mov	w1, #0x8                // =8
    ec30:      	blr	x8
    ec34:      	ldr	x8, [sp, #0x58]
    ec38:      	ldr	x9, [sp, #0x98]
    ec3c:      	cmp	x8, x9
    ec40:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ec44:      	add	x2, x24, #0x18
    ec48:      	mov	w8, #0x4                // =4
    ec4c:      	mov	x0, x22
    ec50:      	mov	w1, #0x8                // =8
    ec54:      	blr	x8
    ec58:      	ldr	x24, [sp, #0x98]
    ec5c:      	ldr	x21, [sp, #0x48]
    ec60:      	add	x2, x24, #0x20
    ec64:      	stp	x2, x24, [sp, #0x50]
    ec68:      	ldr	x8, [sp, #0x30]
    ec6c:      	cmp	x21, x8
    ec70:      	b.ne	0xec80 <generic_kprobe_path+0x51a0>
    ec74:      	ldr	x8, [sp, #0x38]
    ec78:      	cmp	x2, x8
    ec7c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ec80:      	mov	w8, #0x4                // =4
    ec84:      	add	x0, sp, #0x70
    ec88:      	mov	w1, #0x8                // =8
    ec8c:      	blr	x8
    ec90:      	ldr	x8, [sp, #0x70]
    ec94:      	cmp	x21, x8
    ec98:      	b.eq	0xed88 <generic_kprobe_path+0x52a8>
    ec9c:      	add	x23, x21, #0x18
    eca0:      	mov	w8, #0x4                // =4
    eca4:      	add	x9, sp, #0x98
    eca8:      	add	x0, sp, #0x98
    ecac:      	mov	w1, #0x8                // =8
    ecb0:      	mov	x2, x23
    ecb4:      	blr	x8
    ecb8:      	ldr	x8, [sp, #0x98]
    ecbc:      	cmp	x8, x21
    ecc0:      	b.eq	0xed88 <generic_kprobe_path+0x52a8>
    ecc4:      	mov	w8, #0x4                // =4
    ecc8:      	add	x9, sp, #0x78
    eccc:      	add	x0, sp, #0x78
    ecd0:      	mov	w1, #0x8                // =8
    ecd4:      	mov	x2, x23
    ecd8:      	blr	x8
    ecdc:      	add	x2, x21, #0x20
    ece0:      	mov	w8, #0x4                // =4
    ece4:      	mov	w9, #0x10               // =16
    ece8:      	add	x10, sp, #0x80
    ecec:      	add	x0, sp, #0x80
    ecf0:      	mov	w1, #0x10               // =16
    ecf4:      	blr	x8
    ecf8:      	ldr	w21, [sp, #0x84]
    ecfc:      	ldr	x8, [sp, #0x40]
    ed00:      	ldr	x10, [sp, #0x60]
    ed04:      	sub	x12, x10, x8
    ed08:      	ldr	w23, [sp, #0x68]
    ed0c:      	subs	w10, w21, w23
    ed10:      	ldr	x9, [sp, #0x88]
    ed14:      	csel	w10, wzr, w10, lo
    ed18:      	cmp	w23, w21
    ed1c:      	csel	w11, w23, w21, lo
    ed20:      	cinc	w13, w11, hi
    ed24:      	sub	w14, w23, w13
    ed28:      	subs	x12, x12, x13
    ed2c:      	str	w14, [sp, #0x68]
    ed30:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    ed34:      	cmp	x12, #0xfff
    ed38:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    ed3c:      	cmp	w23, w21
    ed40:      	b.ls	0xed4c <generic_kprobe_path+0x526c>
    ed44:      	mov	w13, #0x2f              // =47
    ed48:      	strb	w13, [x8, x12]
    ed4c:      	add	x19, x8, x12
    ed50:      	cmp	w23, w21
    ed54:      	add	x2, x9, x10
    ed58:      	and	w1, w11, #0xff
    ed5c:      	mov	w8, #0x4                // =4
    ed60:      	cinc	x0, x19, hi
    ed64:      	blr	x8
    ed68:      	cmp	w23, w21
    ed6c:      	str	x19, [sp, #0x60]
    ed70:      	add	x19, sp, #0x70
    ed74:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    ed78:      	ldr	x21, [sp, #0x78]
    ed7c:      	ldp	x2, x24, [sp, #0x50]
    ed80:      	str	x21, [sp, #0x48]
    ed84:      	b	0xedd4 <generic_kprobe_path+0x52f4>
    ed88:      	add	x2, x24, #0x10
    ed8c:      	mov	w8, #0x4                // =4
    ed90:      	add	x9, sp, #0x98
    ed94:      	add	x0, sp, #0x98
    ed98:      	mov	w1, #0x8                // =8
    ed9c:      	blr	x8
    eda0:      	ldr	x8, [sp, #0x58]
    eda4:      	ldr	x9, [sp, #0x98]
    eda8:      	cmp	x8, x9
    edac:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    edb0:      	add	x2, x24, #0x18
    edb4:      	mov	w8, #0x4                // =4
    edb8:      	mov	x0, x22
    edbc:      	mov	w1, #0x8                // =8
    edc0:      	blr	x8
    edc4:      	ldr	x24, [sp, #0x98]
    edc8:      	ldr	x21, [sp, #0x48]
    edcc:      	add	x2, x24, #0x20
    edd0:      	stp	x2, x24, [sp, #0x50]
    edd4:      	ldr	x8, [sp, #0x30]
    edd8:      	cmp	x21, x8
    eddc:      	b.ne	0xedec <generic_kprobe_path+0x530c>
    ede0:      	ldr	x8, [sp, #0x38]
    ede4:      	cmp	x2, x8
    ede8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    edec:      	mov	w8, #0x4                // =4
    edf0:      	add	x0, sp, #0x70
    edf4:      	mov	w1, #0x8                // =8
    edf8:      	blr	x8
    edfc:      	ldr	x8, [sp, #0x70]
    ee00:      	cmp	x21, x8
    ee04:      	b.eq	0xeef4 <generic_kprobe_path+0x5414>
    ee08:      	add	x23, x21, #0x18
    ee0c:      	mov	w8, #0x4                // =4
    ee10:      	add	x9, sp, #0x98
    ee14:      	add	x0, sp, #0x98
    ee18:      	mov	w1, #0x8                // =8
    ee1c:      	mov	x2, x23
    ee20:      	blr	x8
    ee24:      	ldr	x8, [sp, #0x98]
    ee28:      	cmp	x8, x21
    ee2c:      	b.eq	0xeef4 <generic_kprobe_path+0x5414>
    ee30:      	mov	w8, #0x4                // =4
    ee34:      	add	x9, sp, #0x78
    ee38:      	add	x0, sp, #0x78
    ee3c:      	mov	w1, #0x8                // =8
    ee40:      	mov	x2, x23
    ee44:      	blr	x8
    ee48:      	add	x2, x21, #0x20
    ee4c:      	mov	w8, #0x4                // =4
    ee50:      	mov	w9, #0x10               // =16
    ee54:      	add	x10, sp, #0x80
    ee58:      	add	x0, sp, #0x80
    ee5c:      	mov	w1, #0x10               // =16
    ee60:      	blr	x8
    ee64:      	ldr	w21, [sp, #0x84]
    ee68:      	ldr	x8, [sp, #0x40]
    ee6c:      	ldr	x10, [sp, #0x60]
    ee70:      	sub	x12, x10, x8
    ee74:      	ldr	w23, [sp, #0x68]
    ee78:      	subs	w10, w21, w23
    ee7c:      	ldr	x9, [sp, #0x88]
    ee80:      	csel	w10, wzr, w10, lo
    ee84:      	cmp	w23, w21
    ee88:      	csel	w11, w23, w21, lo
    ee8c:      	cinc	w13, w11, hi
    ee90:      	sub	w14, w23, w13
    ee94:      	subs	x12, x12, x13
    ee98:      	str	w14, [sp, #0x68]
    ee9c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    eea0:      	cmp	x12, #0xfff
    eea4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    eea8:      	cmp	w23, w21
    eeac:      	b.ls	0xeeb8 <generic_kprobe_path+0x53d8>
    eeb0:      	mov	w13, #0x2f              // =47
    eeb4:      	strb	w13, [x8, x12]
    eeb8:      	add	x19, x8, x12
    eebc:      	cmp	w23, w21
    eec0:      	add	x2, x9, x10
    eec4:      	and	w1, w11, #0xff
    eec8:      	mov	w8, #0x4                // =4
    eecc:      	cinc	x0, x19, hi
    eed0:      	blr	x8
    eed4:      	cmp	w23, w21
    eed8:      	str	x19, [sp, #0x60]
    eedc:      	add	x19, sp, #0x70
    eee0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    eee4:      	ldr	x21, [sp, #0x78]
    eee8:      	ldp	x2, x24, [sp, #0x50]
    eeec:      	str	x21, [sp, #0x48]
    eef0:      	b	0xef40 <generic_kprobe_path+0x5460>
    eef4:      	add	x2, x24, #0x10
    eef8:      	mov	w8, #0x4                // =4
    eefc:      	add	x9, sp, #0x98
    ef00:      	add	x0, sp, #0x98
    ef04:      	mov	w1, #0x8                // =8
    ef08:      	blr	x8
    ef0c:      	ldr	x8, [sp, #0x58]
    ef10:      	ldr	x9, [sp, #0x98]
    ef14:      	cmp	x8, x9
    ef18:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ef1c:      	add	x2, x24, #0x18
    ef20:      	mov	w8, #0x4                // =4
    ef24:      	mov	x0, x22
    ef28:      	mov	w1, #0x8                // =8
    ef2c:      	blr	x8
    ef30:      	ldr	x24, [sp, #0x98]
    ef34:      	ldr	x21, [sp, #0x48]
    ef38:      	add	x2, x24, #0x20
    ef3c:      	stp	x2, x24, [sp, #0x50]
    ef40:      	ldr	x8, [sp, #0x30]
    ef44:      	cmp	x21, x8
    ef48:      	b.ne	0xef58 <generic_kprobe_path+0x5478>
    ef4c:      	ldr	x8, [sp, #0x38]
    ef50:      	cmp	x2, x8
    ef54:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    ef58:      	mov	w8, #0x4                // =4
    ef5c:      	add	x0, sp, #0x70
    ef60:      	mov	w1, #0x8                // =8
    ef64:      	blr	x8
    ef68:      	ldr	x8, [sp, #0x70]
    ef6c:      	cmp	x21, x8
    ef70:      	b.eq	0xf060 <generic_kprobe_path+0x5580>
    ef74:      	add	x23, x21, #0x18
    ef78:      	mov	w8, #0x4                // =4
    ef7c:      	add	x9, sp, #0x98
    ef80:      	add	x0, sp, #0x98
    ef84:      	mov	w1, #0x8                // =8
    ef88:      	mov	x2, x23
    ef8c:      	blr	x8
    ef90:      	ldr	x8, [sp, #0x98]
    ef94:      	cmp	x8, x21
    ef98:      	b.eq	0xf060 <generic_kprobe_path+0x5580>
    ef9c:      	mov	w8, #0x4                // =4
    efa0:      	add	x9, sp, #0x78
    efa4:      	add	x0, sp, #0x78
    efa8:      	mov	w1, #0x8                // =8
    efac:      	mov	x2, x23
    efb0:      	blr	x8
    efb4:      	add	x2, x21, #0x20
    efb8:      	mov	w8, #0x4                // =4
    efbc:      	mov	w9, #0x10               // =16
    efc0:      	add	x10, sp, #0x80
    efc4:      	add	x0, sp, #0x80
    efc8:      	mov	w1, #0x10               // =16
    efcc:      	blr	x8
    efd0:      	ldr	w21, [sp, #0x84]
    efd4:      	ldr	x8, [sp, #0x40]
    efd8:      	ldr	x10, [sp, #0x60]
    efdc:      	sub	x12, x10, x8
    efe0:      	ldr	w23, [sp, #0x68]
    efe4:      	subs	w10, w21, w23
    efe8:      	ldr	x9, [sp, #0x88]
    efec:      	csel	w10, wzr, w10, lo
    eff0:      	cmp	w23, w21
    eff4:      	csel	w11, w23, w21, lo
    eff8:      	cinc	w13, w11, hi
    effc:      	sub	w14, w23, w13
    f000:      	subs	x12, x12, x13
    f004:      	str	w14, [sp, #0x68]
    f008:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f00c:      	cmp	x12, #0xfff
    f010:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f014:      	cmp	w23, w21
    f018:      	b.ls	0xf024 <generic_kprobe_path+0x5544>
    f01c:      	mov	w13, #0x2f              // =47
    f020:      	strb	w13, [x8, x12]
    f024:      	add	x19, x8, x12
    f028:      	cmp	w23, w21
    f02c:      	add	x2, x9, x10
    f030:      	and	w1, w11, #0xff
    f034:      	mov	w8, #0x4                // =4
    f038:      	cinc	x0, x19, hi
    f03c:      	blr	x8
    f040:      	cmp	w23, w21
    f044:      	str	x19, [sp, #0x60]
    f048:      	add	x19, sp, #0x70
    f04c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f050:      	ldr	x21, [sp, #0x78]
    f054:      	ldp	x2, x24, [sp, #0x50]
    f058:      	str	x21, [sp, #0x48]
    f05c:      	b	0xf0ac <generic_kprobe_path+0x55cc>
    f060:      	add	x2, x24, #0x10
    f064:      	mov	w8, #0x4                // =4
    f068:      	add	x9, sp, #0x98
    f06c:      	add	x0, sp, #0x98
    f070:      	mov	w1, #0x8                // =8
    f074:      	blr	x8
    f078:      	ldr	x8, [sp, #0x58]
    f07c:      	ldr	x9, [sp, #0x98]
    f080:      	cmp	x8, x9
    f084:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f088:      	add	x2, x24, #0x18
    f08c:      	mov	w8, #0x4                // =4
    f090:      	mov	x0, x22
    f094:      	mov	w1, #0x8                // =8
    f098:      	blr	x8
    f09c:      	ldr	x24, [sp, #0x98]
    f0a0:      	ldr	x21, [sp, #0x48]
    f0a4:      	add	x2, x24, #0x20
    f0a8:      	stp	x2, x24, [sp, #0x50]
    f0ac:      	ldr	x8, [sp, #0x30]
    f0b0:      	cmp	x21, x8
    f0b4:      	b.ne	0xf0c4 <generic_kprobe_path+0x55e4>
    f0b8:      	ldr	x8, [sp, #0x38]
    f0bc:      	cmp	x2, x8
    f0c0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f0c4:      	mov	w8, #0x4                // =4
    f0c8:      	add	x0, sp, #0x70
    f0cc:      	mov	w1, #0x8                // =8
    f0d0:      	blr	x8
    f0d4:      	ldr	x8, [sp, #0x70]
    f0d8:      	cmp	x21, x8
    f0dc:      	b.eq	0xf1cc <generic_kprobe_path+0x56ec>
    f0e0:      	add	x23, x21, #0x18
    f0e4:      	mov	w8, #0x4                // =4
    f0e8:      	add	x9, sp, #0x98
    f0ec:      	add	x0, sp, #0x98
    f0f0:      	mov	w1, #0x8                // =8
    f0f4:      	mov	x2, x23
    f0f8:      	blr	x8
    f0fc:      	ldr	x8, [sp, #0x98]
    f100:      	cmp	x8, x21
    f104:      	b.eq	0xf1cc <generic_kprobe_path+0x56ec>
    f108:      	mov	w8, #0x4                // =4
    f10c:      	add	x9, sp, #0x78
    f110:      	add	x0, sp, #0x78
    f114:      	mov	w1, #0x8                // =8
    f118:      	mov	x2, x23
    f11c:      	blr	x8
    f120:      	add	x2, x21, #0x20
    f124:      	mov	w8, #0x4                // =4
    f128:      	mov	w9, #0x10               // =16
    f12c:      	add	x10, sp, #0x80
    f130:      	add	x0, sp, #0x80
    f134:      	mov	w1, #0x10               // =16
    f138:      	blr	x8
    f13c:      	ldr	w21, [sp, #0x84]
    f140:      	ldr	x8, [sp, #0x40]
    f144:      	ldr	x10, [sp, #0x60]
    f148:      	sub	x12, x10, x8
    f14c:      	ldr	w23, [sp, #0x68]
    f150:      	subs	w10, w21, w23
    f154:      	ldr	x9, [sp, #0x88]
    f158:      	csel	w10, wzr, w10, lo
    f15c:      	cmp	w23, w21
    f160:      	csel	w11, w23, w21, lo
    f164:      	cinc	w13, w11, hi
    f168:      	sub	w14, w23, w13
    f16c:      	subs	x12, x12, x13
    f170:      	str	w14, [sp, #0x68]
    f174:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f178:      	cmp	x12, #0xfff
    f17c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f180:      	cmp	w23, w21
    f184:      	b.ls	0xf190 <generic_kprobe_path+0x56b0>
    f188:      	mov	w13, #0x2f              // =47
    f18c:      	strb	w13, [x8, x12]
    f190:      	add	x19, x8, x12
    f194:      	cmp	w23, w21
    f198:      	add	x2, x9, x10
    f19c:      	and	w1, w11, #0xff
    f1a0:      	mov	w8, #0x4                // =4
    f1a4:      	cinc	x0, x19, hi
    f1a8:      	blr	x8
    f1ac:      	cmp	w23, w21
    f1b0:      	str	x19, [sp, #0x60]
    f1b4:      	add	x19, sp, #0x70
    f1b8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f1bc:      	ldr	x21, [sp, #0x78]
    f1c0:      	ldp	x2, x24, [sp, #0x50]
    f1c4:      	str	x21, [sp, #0x48]
    f1c8:      	b	0xf218 <generic_kprobe_path+0x5738>
    f1cc:      	add	x2, x24, #0x10
    f1d0:      	mov	w8, #0x4                // =4
    f1d4:      	add	x9, sp, #0x98
    f1d8:      	add	x0, sp, #0x98
    f1dc:      	mov	w1, #0x8                // =8
    f1e0:      	blr	x8
    f1e4:      	ldr	x8, [sp, #0x58]
    f1e8:      	ldr	x9, [sp, #0x98]
    f1ec:      	cmp	x8, x9
    f1f0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f1f4:      	add	x2, x24, #0x18
    f1f8:      	mov	w8, #0x4                // =4
    f1fc:      	mov	x0, x22
    f200:      	mov	w1, #0x8                // =8
    f204:      	blr	x8
    f208:      	ldr	x24, [sp, #0x98]
    f20c:      	ldr	x21, [sp, #0x48]
    f210:      	add	x2, x24, #0x20
    f214:      	stp	x2, x24, [sp, #0x50]
    f218:      	ldr	x8, [sp, #0x30]
    f21c:      	cmp	x21, x8
    f220:      	b.ne	0xf230 <generic_kprobe_path+0x5750>
    f224:      	ldr	x8, [sp, #0x38]
    f228:      	cmp	x2, x8
    f22c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f230:      	mov	w8, #0x4                // =4
    f234:      	add	x0, sp, #0x70
    f238:      	mov	w1, #0x8                // =8
    f23c:      	blr	x8
    f240:      	ldr	x8, [sp, #0x70]
    f244:      	cmp	x21, x8
    f248:      	b.eq	0xf338 <generic_kprobe_path+0x5858>
    f24c:      	add	x23, x21, #0x18
    f250:      	mov	w8, #0x4                // =4
    f254:      	add	x9, sp, #0x98
    f258:      	add	x0, sp, #0x98
    f25c:      	mov	w1, #0x8                // =8
    f260:      	mov	x2, x23
    f264:      	blr	x8
    f268:      	ldr	x8, [sp, #0x98]
    f26c:      	cmp	x8, x21
    f270:      	b.eq	0xf338 <generic_kprobe_path+0x5858>
    f274:      	mov	w8, #0x4                // =4
    f278:      	add	x9, sp, #0x78
    f27c:      	add	x0, sp, #0x78
    f280:      	mov	w1, #0x8                // =8
    f284:      	mov	x2, x23
    f288:      	blr	x8
    f28c:      	add	x2, x21, #0x20
    f290:      	mov	w8, #0x4                // =4
    f294:      	mov	w9, #0x10               // =16
    f298:      	add	x10, sp, #0x80
    f29c:      	add	x0, sp, #0x80
    f2a0:      	mov	w1, #0x10               // =16
    f2a4:      	blr	x8
    f2a8:      	ldr	w21, [sp, #0x84]
    f2ac:      	ldr	x8, [sp, #0x40]
    f2b0:      	ldr	x10, [sp, #0x60]
    f2b4:      	sub	x12, x10, x8
    f2b8:      	ldr	w23, [sp, #0x68]
    f2bc:      	subs	w10, w21, w23
    f2c0:      	ldr	x9, [sp, #0x88]
    f2c4:      	csel	w10, wzr, w10, lo
    f2c8:      	cmp	w23, w21
    f2cc:      	csel	w11, w23, w21, lo
    f2d0:      	cinc	w13, w11, hi
    f2d4:      	sub	w14, w23, w13
    f2d8:      	subs	x12, x12, x13
    f2dc:      	str	w14, [sp, #0x68]
    f2e0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f2e4:      	cmp	x12, #0xfff
    f2e8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f2ec:      	cmp	w23, w21
    f2f0:      	b.ls	0xf2fc <generic_kprobe_path+0x581c>
    f2f4:      	mov	w13, #0x2f              // =47
    f2f8:      	strb	w13, [x8, x12]
    f2fc:      	add	x19, x8, x12
    f300:      	cmp	w23, w21
    f304:      	add	x2, x9, x10
    f308:      	and	w1, w11, #0xff
    f30c:      	mov	w8, #0x4                // =4
    f310:      	cinc	x0, x19, hi
    f314:      	blr	x8
    f318:      	cmp	w23, w21
    f31c:      	str	x19, [sp, #0x60]
    f320:      	add	x19, sp, #0x70
    f324:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f328:      	ldr	x21, [sp, #0x78]
    f32c:      	ldp	x2, x24, [sp, #0x50]
    f330:      	str	x21, [sp, #0x48]
    f334:      	b	0xf384 <generic_kprobe_path+0x58a4>
    f338:      	add	x2, x24, #0x10
    f33c:      	mov	w8, #0x4                // =4
    f340:      	add	x9, sp, #0x98
    f344:      	add	x0, sp, #0x98
    f348:      	mov	w1, #0x8                // =8
    f34c:      	blr	x8
    f350:      	ldr	x8, [sp, #0x58]
    f354:      	ldr	x9, [sp, #0x98]
    f358:      	cmp	x8, x9
    f35c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f360:      	add	x2, x24, #0x18
    f364:      	mov	w8, #0x4                // =4
    f368:      	mov	x0, x22
    f36c:      	mov	w1, #0x8                // =8
    f370:      	blr	x8
    f374:      	ldr	x24, [sp, #0x98]
    f378:      	ldr	x21, [sp, #0x48]
    f37c:      	add	x2, x24, #0x20
    f380:      	stp	x2, x24, [sp, #0x50]
    f384:      	ldr	x8, [sp, #0x30]
    f388:      	cmp	x21, x8
    f38c:      	b.ne	0xf39c <generic_kprobe_path+0x58bc>
    f390:      	ldr	x8, [sp, #0x38]
    f394:      	cmp	x2, x8
    f398:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f39c:      	mov	w8, #0x4                // =4
    f3a0:      	add	x0, sp, #0x70
    f3a4:      	mov	w1, #0x8                // =8
    f3a8:      	blr	x8
    f3ac:      	ldr	x8, [sp, #0x70]
    f3b0:      	cmp	x21, x8
    f3b4:      	b.eq	0xf4a4 <generic_kprobe_path+0x59c4>
    f3b8:      	add	x23, x21, #0x18
    f3bc:      	mov	w8, #0x4                // =4
    f3c0:      	add	x9, sp, #0x98
    f3c4:      	add	x0, sp, #0x98
    f3c8:      	mov	w1, #0x8                // =8
    f3cc:      	mov	x2, x23
    f3d0:      	blr	x8
    f3d4:      	ldr	x8, [sp, #0x98]
    f3d8:      	cmp	x8, x21
    f3dc:      	b.eq	0xf4a4 <generic_kprobe_path+0x59c4>
    f3e0:      	mov	w8, #0x4                // =4
    f3e4:      	add	x9, sp, #0x78
    f3e8:      	add	x0, sp, #0x78
    f3ec:      	mov	w1, #0x8                // =8
    f3f0:      	mov	x2, x23
    f3f4:      	blr	x8
    f3f8:      	add	x2, x21, #0x20
    f3fc:      	mov	w8, #0x4                // =4
    f400:      	mov	w9, #0x10               // =16
    f404:      	add	x10, sp, #0x80
    f408:      	add	x0, sp, #0x80
    f40c:      	mov	w1, #0x10               // =16
    f410:      	blr	x8
    f414:      	ldr	w21, [sp, #0x84]
    f418:      	ldr	x8, [sp, #0x40]
    f41c:      	ldr	x10, [sp, #0x60]
    f420:      	sub	x12, x10, x8
    f424:      	ldr	w23, [sp, #0x68]
    f428:      	subs	w10, w21, w23
    f42c:      	ldr	x9, [sp, #0x88]
    f430:      	csel	w10, wzr, w10, lo
    f434:      	cmp	w23, w21
    f438:      	csel	w11, w23, w21, lo
    f43c:      	cinc	w13, w11, hi
    f440:      	sub	w14, w23, w13
    f444:      	subs	x12, x12, x13
    f448:      	str	w14, [sp, #0x68]
    f44c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f450:      	cmp	x12, #0xfff
    f454:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f458:      	cmp	w23, w21
    f45c:      	b.ls	0xf468 <generic_kprobe_path+0x5988>
    f460:      	mov	w13, #0x2f              // =47
    f464:      	strb	w13, [x8, x12]
    f468:      	add	x19, x8, x12
    f46c:      	cmp	w23, w21
    f470:      	add	x2, x9, x10
    f474:      	and	w1, w11, #0xff
    f478:      	mov	w8, #0x4                // =4
    f47c:      	cinc	x0, x19, hi
    f480:      	blr	x8
    f484:      	cmp	w23, w21
    f488:      	str	x19, [sp, #0x60]
    f48c:      	add	x19, sp, #0x70
    f490:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f494:      	ldr	x21, [sp, #0x78]
    f498:      	ldp	x2, x24, [sp, #0x50]
    f49c:      	str	x21, [sp, #0x48]
    f4a0:      	b	0xf4f0 <generic_kprobe_path+0x5a10>
    f4a4:      	add	x2, x24, #0x10
    f4a8:      	mov	w8, #0x4                // =4
    f4ac:      	add	x9, sp, #0x98
    f4b0:      	add	x0, sp, #0x98
    f4b4:      	mov	w1, #0x8                // =8
    f4b8:      	blr	x8
    f4bc:      	ldr	x8, [sp, #0x58]
    f4c0:      	ldr	x9, [sp, #0x98]
    f4c4:      	cmp	x8, x9
    f4c8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f4cc:      	add	x2, x24, #0x18
    f4d0:      	mov	w8, #0x4                // =4
    f4d4:      	mov	x0, x22
    f4d8:      	mov	w1, #0x8                // =8
    f4dc:      	blr	x8
    f4e0:      	ldr	x24, [sp, #0x98]
    f4e4:      	ldr	x21, [sp, #0x48]
    f4e8:      	add	x2, x24, #0x20
    f4ec:      	stp	x2, x24, [sp, #0x50]
    f4f0:      	ldr	x8, [sp, #0x30]
    f4f4:      	cmp	x21, x8
    f4f8:      	b.ne	0xf508 <generic_kprobe_path+0x5a28>
    f4fc:      	ldr	x8, [sp, #0x38]
    f500:      	cmp	x2, x8
    f504:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f508:      	mov	w8, #0x4                // =4
    f50c:      	add	x0, sp, #0x70
    f510:      	mov	w1, #0x8                // =8
    f514:      	blr	x8
    f518:      	ldr	x8, [sp, #0x70]
    f51c:      	cmp	x21, x8
    f520:      	b.eq	0xf610 <generic_kprobe_path+0x5b30>
    f524:      	add	x23, x21, #0x18
    f528:      	mov	w8, #0x4                // =4
    f52c:      	add	x9, sp, #0x98
    f530:      	add	x0, sp, #0x98
    f534:      	mov	w1, #0x8                // =8
    f538:      	mov	x2, x23
    f53c:      	blr	x8
    f540:      	ldr	x8, [sp, #0x98]
    f544:      	cmp	x8, x21
    f548:      	b.eq	0xf610 <generic_kprobe_path+0x5b30>
    f54c:      	mov	w8, #0x4                // =4
    f550:      	add	x9, sp, #0x78
    f554:      	add	x0, sp, #0x78
    f558:      	mov	w1, #0x8                // =8
    f55c:      	mov	x2, x23
    f560:      	blr	x8
    f564:      	add	x2, x21, #0x20
    f568:      	mov	w8, #0x4                // =4
    f56c:      	mov	w9, #0x10               // =16
    f570:      	add	x10, sp, #0x80
    f574:      	add	x0, sp, #0x80
    f578:      	mov	w1, #0x10               // =16
    f57c:      	blr	x8
    f580:      	ldr	w21, [sp, #0x84]
    f584:      	ldr	x8, [sp, #0x40]
    f588:      	ldr	x10, [sp, #0x60]
    f58c:      	sub	x12, x10, x8
    f590:      	ldr	w23, [sp, #0x68]
    f594:      	subs	w10, w21, w23
    f598:      	ldr	x9, [sp, #0x88]
    f59c:      	csel	w10, wzr, w10, lo
    f5a0:      	cmp	w23, w21
    f5a4:      	csel	w11, w23, w21, lo
    f5a8:      	cinc	w13, w11, hi
    f5ac:      	sub	w14, w23, w13
    f5b0:      	subs	x12, x12, x13
    f5b4:      	str	w14, [sp, #0x68]
    f5b8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f5bc:      	cmp	x12, #0xfff
    f5c0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f5c4:      	cmp	w23, w21
    f5c8:      	b.ls	0xf5d4 <generic_kprobe_path+0x5af4>
    f5cc:      	mov	w13, #0x2f              // =47
    f5d0:      	strb	w13, [x8, x12]
    f5d4:      	add	x19, x8, x12
    f5d8:      	cmp	w23, w21
    f5dc:      	add	x2, x9, x10
    f5e0:      	and	w1, w11, #0xff
    f5e4:      	mov	w8, #0x4                // =4
    f5e8:      	cinc	x0, x19, hi
    f5ec:      	blr	x8
    f5f0:      	cmp	w23, w21
    f5f4:      	str	x19, [sp, #0x60]
    f5f8:      	add	x19, sp, #0x70
    f5fc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f600:      	ldr	x21, [sp, #0x78]
    f604:      	ldp	x2, x24, [sp, #0x50]
    f608:      	str	x21, [sp, #0x48]
    f60c:      	b	0xf65c <generic_kprobe_path+0x5b7c>
    f610:      	add	x2, x24, #0x10
    f614:      	mov	w8, #0x4                // =4
    f618:      	add	x9, sp, #0x98
    f61c:      	add	x0, sp, #0x98
    f620:      	mov	w1, #0x8                // =8
    f624:      	blr	x8
    f628:      	ldr	x8, [sp, #0x58]
    f62c:      	ldr	x9, [sp, #0x98]
    f630:      	cmp	x8, x9
    f634:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f638:      	add	x2, x24, #0x18
    f63c:      	mov	w8, #0x4                // =4
    f640:      	mov	x0, x22
    f644:      	mov	w1, #0x8                // =8
    f648:      	blr	x8
    f64c:      	ldr	x24, [sp, #0x98]
    f650:      	ldr	x21, [sp, #0x48]
    f654:      	add	x2, x24, #0x20
    f658:      	stp	x2, x24, [sp, #0x50]
    f65c:      	ldr	x8, [sp, #0x30]
    f660:      	cmp	x21, x8
    f664:      	b.ne	0xf674 <generic_kprobe_path+0x5b94>
    f668:      	ldr	x8, [sp, #0x38]
    f66c:      	cmp	x2, x8
    f670:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f674:      	mov	w8, #0x4                // =4
    f678:      	add	x0, sp, #0x70
    f67c:      	mov	w1, #0x8                // =8
    f680:      	blr	x8
    f684:      	ldr	x8, [sp, #0x70]
    f688:      	cmp	x21, x8
    f68c:      	b.eq	0xf77c <generic_kprobe_path+0x5c9c>
    f690:      	add	x23, x21, #0x18
    f694:      	mov	w8, #0x4                // =4
    f698:      	add	x9, sp, #0x98
    f69c:      	add	x0, sp, #0x98
    f6a0:      	mov	w1, #0x8                // =8
    f6a4:      	mov	x2, x23
    f6a8:      	blr	x8
    f6ac:      	ldr	x8, [sp, #0x98]
    f6b0:      	cmp	x8, x21
    f6b4:      	b.eq	0xf77c <generic_kprobe_path+0x5c9c>
    f6b8:      	mov	w8, #0x4                // =4
    f6bc:      	add	x9, sp, #0x78
    f6c0:      	add	x0, sp, #0x78
    f6c4:      	mov	w1, #0x8                // =8
    f6c8:      	mov	x2, x23
    f6cc:      	blr	x8
    f6d0:      	add	x2, x21, #0x20
    f6d4:      	mov	w8, #0x4                // =4
    f6d8:      	mov	w9, #0x10               // =16
    f6dc:      	add	x10, sp, #0x80
    f6e0:      	add	x0, sp, #0x80
    f6e4:      	mov	w1, #0x10               // =16
    f6e8:      	blr	x8
    f6ec:      	ldr	w21, [sp, #0x84]
    f6f0:      	ldr	x8, [sp, #0x40]
    f6f4:      	ldr	x10, [sp, #0x60]
    f6f8:      	sub	x12, x10, x8
    f6fc:      	ldr	w23, [sp, #0x68]
    f700:      	subs	w10, w21, w23
    f704:      	ldr	x9, [sp, #0x88]
    f708:      	csel	w10, wzr, w10, lo
    f70c:      	cmp	w23, w21
    f710:      	csel	w11, w23, w21, lo
    f714:      	cinc	w13, w11, hi
    f718:      	sub	w14, w23, w13
    f71c:      	subs	x12, x12, x13
    f720:      	str	w14, [sp, #0x68]
    f724:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f728:      	cmp	x12, #0xfff
    f72c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f730:      	cmp	w23, w21
    f734:      	b.ls	0xf740 <generic_kprobe_path+0x5c60>
    f738:      	mov	w13, #0x2f              // =47
    f73c:      	strb	w13, [x8, x12]
    f740:      	add	x19, x8, x12
    f744:      	cmp	w23, w21
    f748:      	add	x2, x9, x10
    f74c:      	and	w1, w11, #0xff
    f750:      	mov	w8, #0x4                // =4
    f754:      	cinc	x0, x19, hi
    f758:      	blr	x8
    f75c:      	cmp	w23, w21
    f760:      	str	x19, [sp, #0x60]
    f764:      	add	x19, sp, #0x70
    f768:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f76c:      	ldr	x21, [sp, #0x78]
    f770:      	ldp	x2, x24, [sp, #0x50]
    f774:      	str	x21, [sp, #0x48]
    f778:      	b	0xf7c8 <generic_kprobe_path+0x5ce8>
    f77c:      	add	x2, x24, #0x10
    f780:      	mov	w8, #0x4                // =4
    f784:      	add	x9, sp, #0x98
    f788:      	add	x0, sp, #0x98
    f78c:      	mov	w1, #0x8                // =8
    f790:      	blr	x8
    f794:      	ldr	x8, [sp, #0x58]
    f798:      	ldr	x9, [sp, #0x98]
    f79c:      	cmp	x8, x9
    f7a0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f7a4:      	add	x2, x24, #0x18
    f7a8:      	mov	w8, #0x4                // =4
    f7ac:      	mov	x0, x22
    f7b0:      	mov	w1, #0x8                // =8
    f7b4:      	blr	x8
    f7b8:      	ldr	x24, [sp, #0x98]
    f7bc:      	ldr	x21, [sp, #0x48]
    f7c0:      	add	x2, x24, #0x20
    f7c4:      	stp	x2, x24, [sp, #0x50]
    f7c8:      	ldr	x8, [sp, #0x30]
    f7cc:      	cmp	x21, x8
    f7d0:      	b.ne	0xf7e0 <generic_kprobe_path+0x5d00>
    f7d4:      	ldr	x8, [sp, #0x38]
    f7d8:      	cmp	x2, x8
    f7dc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f7e0:      	mov	w8, #0x4                // =4
    f7e4:      	add	x0, sp, #0x70
    f7e8:      	mov	w1, #0x8                // =8
    f7ec:      	blr	x8
    f7f0:      	ldr	x8, [sp, #0x70]
    f7f4:      	cmp	x21, x8
    f7f8:      	b.eq	0xf8e8 <generic_kprobe_path+0x5e08>
    f7fc:      	add	x23, x21, #0x18
    f800:      	mov	w8, #0x4                // =4
    f804:      	add	x9, sp, #0x98
    f808:      	add	x0, sp, #0x98
    f80c:      	mov	w1, #0x8                // =8
    f810:      	mov	x2, x23
    f814:      	blr	x8
    f818:      	ldr	x8, [sp, #0x98]
    f81c:      	cmp	x8, x21
    f820:      	b.eq	0xf8e8 <generic_kprobe_path+0x5e08>
    f824:      	mov	w8, #0x4                // =4
    f828:      	add	x9, sp, #0x78
    f82c:      	add	x0, sp, #0x78
    f830:      	mov	w1, #0x8                // =8
    f834:      	mov	x2, x23
    f838:      	blr	x8
    f83c:      	add	x2, x21, #0x20
    f840:      	mov	w8, #0x4                // =4
    f844:      	mov	w9, #0x10               // =16
    f848:      	add	x10, sp, #0x80
    f84c:      	add	x0, sp, #0x80
    f850:      	mov	w1, #0x10               // =16
    f854:      	blr	x8
    f858:      	ldr	w21, [sp, #0x84]
    f85c:      	ldr	x8, [sp, #0x40]
    f860:      	ldr	x10, [sp, #0x60]
    f864:      	sub	x12, x10, x8
    f868:      	ldr	w23, [sp, #0x68]
    f86c:      	subs	w10, w21, w23
    f870:      	ldr	x9, [sp, #0x88]
    f874:      	csel	w10, wzr, w10, lo
    f878:      	cmp	w23, w21
    f87c:      	csel	w11, w23, w21, lo
    f880:      	cinc	w13, w11, hi
    f884:      	sub	w14, w23, w13
    f888:      	subs	x12, x12, x13
    f88c:      	str	w14, [sp, #0x68]
    f890:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    f894:      	cmp	x12, #0xfff
    f898:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    f89c:      	cmp	w23, w21
    f8a0:      	b.ls	0xf8ac <generic_kprobe_path+0x5dcc>
    f8a4:      	mov	w13, #0x2f              // =47
    f8a8:      	strb	w13, [x8, x12]
    f8ac:      	add	x19, x8, x12
    f8b0:      	cmp	w23, w21
    f8b4:      	add	x2, x9, x10
    f8b8:      	and	w1, w11, #0xff
    f8bc:      	mov	w8, #0x4                // =4
    f8c0:      	cinc	x0, x19, hi
    f8c4:      	blr	x8
    f8c8:      	cmp	w23, w21
    f8cc:      	str	x19, [sp, #0x60]
    f8d0:      	add	x19, sp, #0x70
    f8d4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    f8d8:      	ldr	x21, [sp, #0x78]
    f8dc:      	ldp	x2, x24, [sp, #0x50]
    f8e0:      	str	x21, [sp, #0x48]
    f8e4:      	b	0xf934 <generic_kprobe_path+0x5e54>
    f8e8:      	add	x2, x24, #0x10
    f8ec:      	mov	w8, #0x4                // =4
    f8f0:      	add	x9, sp, #0x98
    f8f4:      	add	x0, sp, #0x98
    f8f8:      	mov	w1, #0x8                // =8
    f8fc:      	blr	x8
    f900:      	ldr	x8, [sp, #0x58]
    f904:      	ldr	x9, [sp, #0x98]
    f908:      	cmp	x8, x9
    f90c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f910:      	add	x2, x24, #0x18
    f914:      	mov	w8, #0x4                // =4
    f918:      	mov	x0, x22
    f91c:      	mov	w1, #0x8                // =8
    f920:      	blr	x8
    f924:      	ldr	x24, [sp, #0x98]
    f928:      	ldr	x21, [sp, #0x48]
    f92c:      	add	x2, x24, #0x20
    f930:      	stp	x2, x24, [sp, #0x50]
    f934:      	ldr	x8, [sp, #0x30]
    f938:      	cmp	x21, x8
    f93c:      	b.ne	0xf94c <generic_kprobe_path+0x5e6c>
    f940:      	ldr	x8, [sp, #0x38]
    f944:      	cmp	x2, x8
    f948:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    f94c:      	mov	w8, #0x4                // =4
    f950:      	add	x0, sp, #0x70
    f954:      	mov	w1, #0x8                // =8
    f958:      	blr	x8
    f95c:      	ldr	x8, [sp, #0x70]
    f960:      	cmp	x21, x8
    f964:      	b.eq	0xfa54 <generic_kprobe_path+0x5f74>
    f968:      	add	x23, x21, #0x18
    f96c:      	mov	w8, #0x4                // =4
    f970:      	add	x9, sp, #0x98
    f974:      	add	x0, sp, #0x98
    f978:      	mov	w1, #0x8                // =8
    f97c:      	mov	x2, x23
    f980:      	blr	x8
    f984:      	ldr	x8, [sp, #0x98]
    f988:      	cmp	x8, x21
    f98c:      	b.eq	0xfa54 <generic_kprobe_path+0x5f74>
    f990:      	mov	w8, #0x4                // =4
    f994:      	add	x9, sp, #0x78
    f998:      	add	x0, sp, #0x78
    f99c:      	mov	w1, #0x8                // =8
    f9a0:      	mov	x2, x23
    f9a4:      	blr	x8
    f9a8:      	add	x2, x21, #0x20
    f9ac:      	mov	w8, #0x4                // =4
    f9b0:      	mov	w9, #0x10               // =16
    f9b4:      	add	x10, sp, #0x80
    f9b8:      	add	x0, sp, #0x80
    f9bc:      	mov	w1, #0x10               // =16
    f9c0:      	blr	x8
    f9c4:      	ldr	w21, [sp, #0x84]
    f9c8:      	ldr	x8, [sp, #0x40]
    f9cc:      	ldr	x10, [sp, #0x60]
    f9d0:      	sub	x12, x10, x8
    f9d4:      	ldr	w23, [sp, #0x68]
    f9d8:      	subs	w10, w21, w23
    f9dc:      	ldr	x9, [sp, #0x88]
    f9e0:      	csel	w10, wzr, w10, lo
    f9e4:      	cmp	w23, w21
    f9e8:      	csel	w11, w23, w21, lo
    f9ec:      	cinc	w13, w11, hi
    f9f0:      	sub	w14, w23, w13
    f9f4:      	subs	x12, x12, x13
    f9f8:      	str	w14, [sp, #0x68]
    f9fc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    fa00:      	cmp	x12, #0xfff
    fa04:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    fa08:      	cmp	w23, w21
    fa0c:      	b.ls	0xfa18 <generic_kprobe_path+0x5f38>
    fa10:      	mov	w13, #0x2f              // =47
    fa14:      	strb	w13, [x8, x12]
    fa18:      	add	x19, x8, x12
    fa1c:      	cmp	w23, w21
    fa20:      	add	x2, x9, x10
    fa24:      	and	w1, w11, #0xff
    fa28:      	mov	w8, #0x4                // =4
    fa2c:      	cinc	x0, x19, hi
    fa30:      	blr	x8
    fa34:      	cmp	w23, w21
    fa38:      	str	x19, [sp, #0x60]
    fa3c:      	add	x19, sp, #0x70
    fa40:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    fa44:      	ldr	x21, [sp, #0x78]
    fa48:      	ldp	x2, x24, [sp, #0x50]
    fa4c:      	str	x21, [sp, #0x48]
    fa50:      	b	0xfaa0 <generic_kprobe_path+0x5fc0>
    fa54:      	add	x2, x24, #0x10
    fa58:      	mov	w8, #0x4                // =4
    fa5c:      	add	x9, sp, #0x98
    fa60:      	add	x0, sp, #0x98
    fa64:      	mov	w1, #0x8                // =8
    fa68:      	blr	x8
    fa6c:      	ldr	x8, [sp, #0x58]
    fa70:      	ldr	x9, [sp, #0x98]
    fa74:      	cmp	x8, x9
    fa78:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fa7c:      	add	x2, x24, #0x18
    fa80:      	mov	w8, #0x4                // =4
    fa84:      	mov	x0, x22
    fa88:      	mov	w1, #0x8                // =8
    fa8c:      	blr	x8
    fa90:      	ldr	x24, [sp, #0x98]
    fa94:      	ldr	x21, [sp, #0x48]
    fa98:      	add	x2, x24, #0x20
    fa9c:      	stp	x2, x24, [sp, #0x50]
    faa0:      	ldr	x8, [sp, #0x30]
    faa4:      	cmp	x21, x8
    faa8:      	b.ne	0xfab8 <generic_kprobe_path+0x5fd8>
    faac:      	ldr	x8, [sp, #0x38]
    fab0:      	cmp	x2, x8
    fab4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fab8:      	mov	w8, #0x4                // =4
    fabc:      	add	x0, sp, #0x70
    fac0:      	mov	w1, #0x8                // =8
    fac4:      	blr	x8
    fac8:      	ldr	x8, [sp, #0x70]
    facc:      	cmp	x21, x8
    fad0:      	b.eq	0xfbc0 <generic_kprobe_path+0x60e0>
    fad4:      	add	x23, x21, #0x18
    fad8:      	mov	w8, #0x4                // =4
    fadc:      	add	x9, sp, #0x98
    fae0:      	add	x0, sp, #0x98
    fae4:      	mov	w1, #0x8                // =8
    fae8:      	mov	x2, x23
    faec:      	blr	x8
    faf0:      	ldr	x8, [sp, #0x98]
    faf4:      	cmp	x8, x21
    faf8:      	b.eq	0xfbc0 <generic_kprobe_path+0x60e0>
    fafc:      	mov	w8, #0x4                // =4
    fb00:      	add	x9, sp, #0x78
    fb04:      	add	x0, sp, #0x78
    fb08:      	mov	w1, #0x8                // =8
    fb0c:      	mov	x2, x23
    fb10:      	blr	x8
    fb14:      	add	x2, x21, #0x20
    fb18:      	mov	w8, #0x4                // =4
    fb1c:      	mov	w9, #0x10               // =16
    fb20:      	add	x10, sp, #0x80
    fb24:      	add	x0, sp, #0x80
    fb28:      	mov	w1, #0x10               // =16
    fb2c:      	blr	x8
    fb30:      	ldr	w21, [sp, #0x84]
    fb34:      	ldr	x8, [sp, #0x40]
    fb38:      	ldr	x10, [sp, #0x60]
    fb3c:      	sub	x12, x10, x8
    fb40:      	ldr	w23, [sp, #0x68]
    fb44:      	subs	w10, w21, w23
    fb48:      	ldr	x9, [sp, #0x88]
    fb4c:      	csel	w10, wzr, w10, lo
    fb50:      	cmp	w23, w21
    fb54:      	csel	w11, w23, w21, lo
    fb58:      	cinc	w13, w11, hi
    fb5c:      	sub	w14, w23, w13
    fb60:      	subs	x12, x12, x13
    fb64:      	str	w14, [sp, #0x68]
    fb68:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    fb6c:      	cmp	x12, #0xfff
    fb70:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    fb74:      	cmp	w23, w21
    fb78:      	b.ls	0xfb84 <generic_kprobe_path+0x60a4>
    fb7c:      	mov	w13, #0x2f              // =47
    fb80:      	strb	w13, [x8, x12]
    fb84:      	add	x19, x8, x12
    fb88:      	cmp	w23, w21
    fb8c:      	add	x2, x9, x10
    fb90:      	and	w1, w11, #0xff
    fb94:      	mov	w8, #0x4                // =4
    fb98:      	cinc	x0, x19, hi
    fb9c:      	blr	x8
    fba0:      	cmp	w23, w21
    fba4:      	str	x19, [sp, #0x60]
    fba8:      	add	x19, sp, #0x70
    fbac:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    fbb0:      	ldr	x21, [sp, #0x78]
    fbb4:      	ldp	x2, x24, [sp, #0x50]
    fbb8:      	str	x21, [sp, #0x48]
    fbbc:      	b	0xfc0c <generic_kprobe_path+0x612c>
    fbc0:      	add	x2, x24, #0x10
    fbc4:      	mov	w8, #0x4                // =4
    fbc8:      	add	x9, sp, #0x98
    fbcc:      	add	x0, sp, #0x98
    fbd0:      	mov	w1, #0x8                // =8
    fbd4:      	blr	x8
    fbd8:      	ldr	x8, [sp, #0x58]
    fbdc:      	ldr	x9, [sp, #0x98]
    fbe0:      	cmp	x8, x9
    fbe4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fbe8:      	add	x2, x24, #0x18
    fbec:      	mov	w8, #0x4                // =4
    fbf0:      	mov	x0, x22
    fbf4:      	mov	w1, #0x8                // =8
    fbf8:      	blr	x8
    fbfc:      	ldr	x24, [sp, #0x98]
    fc00:      	ldr	x21, [sp, #0x48]
    fc04:      	add	x2, x24, #0x20
    fc08:      	stp	x2, x24, [sp, #0x50]
    fc0c:      	ldr	x8, [sp, #0x30]
    fc10:      	cmp	x21, x8
    fc14:      	b.ne	0xfc24 <generic_kprobe_path+0x6144>
    fc18:      	ldr	x8, [sp, #0x38]
    fc1c:      	cmp	x2, x8
    fc20:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fc24:      	mov	w8, #0x4                // =4
    fc28:      	add	x0, sp, #0x70
    fc2c:      	mov	w1, #0x8                // =8
    fc30:      	blr	x8
    fc34:      	ldr	x8, [sp, #0x70]
    fc38:      	cmp	x21, x8
    fc3c:      	b.eq	0xfd2c <generic_kprobe_path+0x624c>
    fc40:      	add	x23, x21, #0x18
    fc44:      	mov	w8, #0x4                // =4
    fc48:      	add	x9, sp, #0x98
    fc4c:      	add	x0, sp, #0x98
    fc50:      	mov	w1, #0x8                // =8
    fc54:      	mov	x2, x23
    fc58:      	blr	x8
    fc5c:      	ldr	x8, [sp, #0x98]
    fc60:      	cmp	x8, x21
    fc64:      	b.eq	0xfd2c <generic_kprobe_path+0x624c>
    fc68:      	mov	w8, #0x4                // =4
    fc6c:      	add	x9, sp, #0x78
    fc70:      	add	x0, sp, #0x78
    fc74:      	mov	w1, #0x8                // =8
    fc78:      	mov	x2, x23
    fc7c:      	blr	x8
    fc80:      	add	x2, x21, #0x20
    fc84:      	mov	w8, #0x4                // =4
    fc88:      	mov	w9, #0x10               // =16
    fc8c:      	add	x10, sp, #0x80
    fc90:      	add	x0, sp, #0x80
    fc94:      	mov	w1, #0x10               // =16
    fc98:      	blr	x8
    fc9c:      	ldr	w21, [sp, #0x84]
    fca0:      	ldr	x8, [sp, #0x40]
    fca4:      	ldr	x10, [sp, #0x60]
    fca8:      	sub	x12, x10, x8
    fcac:      	ldr	w23, [sp, #0x68]
    fcb0:      	subs	w10, w21, w23
    fcb4:      	ldr	x9, [sp, #0x88]
    fcb8:      	csel	w10, wzr, w10, lo
    fcbc:      	cmp	w23, w21
    fcc0:      	csel	w11, w23, w21, lo
    fcc4:      	cinc	w13, w11, hi
    fcc8:      	sub	w14, w23, w13
    fccc:      	subs	x12, x12, x13
    fcd0:      	str	w14, [sp, #0x68]
    fcd4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    fcd8:      	cmp	x12, #0xfff
    fcdc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    fce0:      	cmp	w23, w21
    fce4:      	b.ls	0xfcf0 <generic_kprobe_path+0x6210>
    fce8:      	mov	w13, #0x2f              // =47
    fcec:      	strb	w13, [x8, x12]
    fcf0:      	add	x19, x8, x12
    fcf4:      	cmp	w23, w21
    fcf8:      	add	x2, x9, x10
    fcfc:      	and	w1, w11, #0xff
    fd00:      	mov	w8, #0x4                // =4
    fd04:      	cinc	x0, x19, hi
    fd08:      	blr	x8
    fd0c:      	cmp	w23, w21
    fd10:      	str	x19, [sp, #0x60]
    fd14:      	add	x19, sp, #0x70
    fd18:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    fd1c:      	ldr	x21, [sp, #0x78]
    fd20:      	ldp	x2, x24, [sp, #0x50]
    fd24:      	str	x21, [sp, #0x48]
    fd28:      	b	0xfd78 <generic_kprobe_path+0x6298>
    fd2c:      	add	x2, x24, #0x10
    fd30:      	mov	w8, #0x4                // =4
    fd34:      	add	x9, sp, #0x98
    fd38:      	add	x0, sp, #0x98
    fd3c:      	mov	w1, #0x8                // =8
    fd40:      	blr	x8
    fd44:      	ldr	x8, [sp, #0x58]
    fd48:      	ldr	x9, [sp, #0x98]
    fd4c:      	cmp	x8, x9
    fd50:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fd54:      	add	x2, x24, #0x18
    fd58:      	mov	w8, #0x4                // =4
    fd5c:      	mov	x0, x22
    fd60:      	mov	w1, #0x8                // =8
    fd64:      	blr	x8
    fd68:      	ldr	x24, [sp, #0x98]
    fd6c:      	ldr	x21, [sp, #0x48]
    fd70:      	add	x2, x24, #0x20
    fd74:      	stp	x2, x24, [sp, #0x50]
    fd78:      	ldr	x8, [sp, #0x30]
    fd7c:      	cmp	x21, x8
    fd80:      	b.ne	0xfd90 <generic_kprobe_path+0x62b0>
    fd84:      	ldr	x8, [sp, #0x38]
    fd88:      	cmp	x2, x8
    fd8c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fd90:      	mov	w8, #0x4                // =4
    fd94:      	add	x0, sp, #0x70
    fd98:      	mov	w1, #0x8                // =8
    fd9c:      	blr	x8
    fda0:      	ldr	x8, [sp, #0x70]
    fda4:      	cmp	x21, x8
    fda8:      	b.eq	0xfe98 <generic_kprobe_path+0x63b8>
    fdac:      	add	x23, x21, #0x18
    fdb0:      	mov	w8, #0x4                // =4
    fdb4:      	add	x9, sp, #0x98
    fdb8:      	add	x0, sp, #0x98
    fdbc:      	mov	w1, #0x8                // =8
    fdc0:      	mov	x2, x23
    fdc4:      	blr	x8
    fdc8:      	ldr	x8, [sp, #0x98]
    fdcc:      	cmp	x8, x21
    fdd0:      	b.eq	0xfe98 <generic_kprobe_path+0x63b8>
    fdd4:      	mov	w8, #0x4                // =4
    fdd8:      	add	x9, sp, #0x78
    fddc:      	add	x0, sp, #0x78
    fde0:      	mov	w1, #0x8                // =8
    fde4:      	mov	x2, x23
    fde8:      	blr	x8
    fdec:      	add	x2, x21, #0x20
    fdf0:      	mov	w8, #0x4                // =4
    fdf4:      	mov	w9, #0x10               // =16
    fdf8:      	add	x10, sp, #0x80
    fdfc:      	add	x0, sp, #0x80
    fe00:      	mov	w1, #0x10               // =16
    fe04:      	blr	x8
    fe08:      	ldr	w21, [sp, #0x84]
    fe0c:      	ldr	x8, [sp, #0x40]
    fe10:      	ldr	x10, [sp, #0x60]
    fe14:      	sub	x12, x10, x8
    fe18:      	ldr	w23, [sp, #0x68]
    fe1c:      	subs	w10, w21, w23
    fe20:      	ldr	x9, [sp, #0x88]
    fe24:      	csel	w10, wzr, w10, lo
    fe28:      	cmp	w23, w21
    fe2c:      	csel	w11, w23, w21, lo
    fe30:      	cinc	w13, w11, hi
    fe34:      	sub	w14, w23, w13
    fe38:      	subs	x12, x12, x13
    fe3c:      	str	w14, [sp, #0x68]
    fe40:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    fe44:      	cmp	x12, #0xfff
    fe48:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    fe4c:      	cmp	w23, w21
    fe50:      	b.ls	0xfe5c <generic_kprobe_path+0x637c>
    fe54:      	mov	w13, #0x2f              // =47
    fe58:      	strb	w13, [x8, x12]
    fe5c:      	add	x19, x8, x12
    fe60:      	cmp	w23, w21
    fe64:      	add	x2, x9, x10
    fe68:      	and	w1, w11, #0xff
    fe6c:      	mov	w8, #0x4                // =4
    fe70:      	cinc	x0, x19, hi
    fe74:      	blr	x8
    fe78:      	cmp	w23, w21
    fe7c:      	str	x19, [sp, #0x60]
    fe80:      	add	x19, sp, #0x70
    fe84:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    fe88:      	ldr	x21, [sp, #0x78]
    fe8c:      	ldp	x2, x24, [sp, #0x50]
    fe90:      	str	x21, [sp, #0x48]
    fe94:      	b	0xfee4 <generic_kprobe_path+0x6404>
    fe98:      	add	x2, x24, #0x10
    fe9c:      	mov	w8, #0x4                // =4
    fea0:      	add	x9, sp, #0x98
    fea4:      	add	x0, sp, #0x98
    fea8:      	mov	w1, #0x8                // =8
    feac:      	blr	x8
    feb0:      	ldr	x8, [sp, #0x58]
    feb4:      	ldr	x9, [sp, #0x98]
    feb8:      	cmp	x8, x9
    febc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fec0:      	add	x2, x24, #0x18
    fec4:      	mov	w8, #0x4                // =4
    fec8:      	mov	x0, x22
    fecc:      	mov	w1, #0x8                // =8
    fed0:      	blr	x8
    fed4:      	ldr	x24, [sp, #0x98]
    fed8:      	ldr	x21, [sp, #0x48]
    fedc:      	add	x2, x24, #0x20
    fee0:      	stp	x2, x24, [sp, #0x50]
    fee4:      	ldr	x8, [sp, #0x30]
    fee8:      	cmp	x21, x8
    feec:      	b.ne	0xfefc <generic_kprobe_path+0x641c>
    fef0:      	ldr	x8, [sp, #0x38]
    fef4:      	cmp	x2, x8
    fef8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
    fefc:      	mov	w8, #0x4                // =4
    ff00:      	add	x0, sp, #0x70
    ff04:      	mov	w1, #0x8                // =8
    ff08:      	blr	x8
    ff0c:      	ldr	x8, [sp, #0x70]
    ff10:      	cmp	x21, x8
    ff14:      	b.eq	0x10004 <generic_kprobe_path+0x6524>
    ff18:      	add	x23, x21, #0x18
    ff1c:      	mov	w8, #0x4                // =4
    ff20:      	add	x9, sp, #0x98
    ff24:      	add	x0, sp, #0x98
    ff28:      	mov	w1, #0x8                // =8
    ff2c:      	mov	x2, x23
    ff30:      	blr	x8
    ff34:      	ldr	x8, [sp, #0x98]
    ff38:      	cmp	x8, x21
    ff3c:      	b.eq	0x10004 <generic_kprobe_path+0x6524>
    ff40:      	mov	w8, #0x4                // =4
    ff44:      	add	x9, sp, #0x78
    ff48:      	add	x0, sp, #0x78
    ff4c:      	mov	w1, #0x8                // =8
    ff50:      	mov	x2, x23
    ff54:      	blr	x8
    ff58:      	add	x2, x21, #0x20
    ff5c:      	mov	w8, #0x4                // =4
    ff60:      	mov	w9, #0x10               // =16
    ff64:      	add	x10, sp, #0x80
    ff68:      	add	x0, sp, #0x80
    ff6c:      	mov	w1, #0x10               // =16
    ff70:      	blr	x8
    ff74:      	ldr	w21, [sp, #0x84]
    ff78:      	ldr	x8, [sp, #0x40]
    ff7c:      	ldr	x10, [sp, #0x60]
    ff80:      	sub	x12, x10, x8
    ff84:      	ldr	w23, [sp, #0x68]
    ff88:      	subs	w10, w21, w23
    ff8c:      	ldr	x9, [sp, #0x88]
    ff90:      	csel	w10, wzr, w10, lo
    ff94:      	cmp	w23, w21
    ff98:      	csel	w11, w23, w21, lo
    ff9c:      	cinc	w13, w11, hi
    ffa0:      	sub	w14, w23, w13
    ffa4:      	subs	x12, x12, x13
    ffa8:      	str	w14, [sp, #0x68]
    ffac:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
    ffb0:      	cmp	x12, #0xfff
    ffb4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
    ffb8:      	cmp	w23, w21
    ffbc:      	b.ls	0xffc8 <generic_kprobe_path+0x64e8>
    ffc0:      	mov	w13, #0x2f              // =47
    ffc4:      	strb	w13, [x8, x12]
    ffc8:      	add	x19, x8, x12
    ffcc:      	cmp	w23, w21
    ffd0:      	add	x2, x9, x10
    ffd4:      	and	w1, w11, #0xff
    ffd8:      	mov	w8, #0x4                // =4
    ffdc:      	cinc	x0, x19, hi
    ffe0:      	blr	x8
    ffe4:      	cmp	w23, w21
    ffe8:      	str	x19, [sp, #0x60]
    ffec:      	add	x19, sp, #0x70
    fff0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
    fff4:      	ldr	x21, [sp, #0x78]
    fff8:      	ldp	x2, x24, [sp, #0x50]
    fffc:      	str	x21, [sp, #0x48]
   10000:      	b	0x10050 <generic_kprobe_path+0x6570>
   10004:      	add	x2, x24, #0x10
   10008:      	mov	w8, #0x4                // =4
   1000c:      	add	x9, sp, #0x98
   10010:      	add	x0, sp, #0x98
   10014:      	mov	w1, #0x8                // =8
   10018:      	blr	x8
   1001c:      	ldr	x8, [sp, #0x58]
   10020:      	ldr	x9, [sp, #0x98]
   10024:      	cmp	x8, x9
   10028:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1002c:      	add	x2, x24, #0x18
   10030:      	mov	w8, #0x4                // =4
   10034:      	mov	x0, x22
   10038:      	mov	w1, #0x8                // =8
   1003c:      	blr	x8
   10040:      	ldr	x24, [sp, #0x98]
   10044:      	ldr	x21, [sp, #0x48]
   10048:      	add	x2, x24, #0x20
   1004c:      	stp	x2, x24, [sp, #0x50]
   10050:      	ldr	x8, [sp, #0x30]
   10054:      	cmp	x21, x8
   10058:      	b.ne	0x10068 <generic_kprobe_path+0x6588>
   1005c:      	ldr	x8, [sp, #0x38]
   10060:      	cmp	x2, x8
   10064:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10068:      	mov	w8, #0x4                // =4
   1006c:      	add	x0, sp, #0x70
   10070:      	mov	w1, #0x8                // =8
   10074:      	blr	x8
   10078:      	ldr	x8, [sp, #0x70]
   1007c:      	cmp	x21, x8
   10080:      	b.eq	0x10170 <generic_kprobe_path+0x6690>
   10084:      	add	x23, x21, #0x18
   10088:      	mov	w8, #0x4                // =4
   1008c:      	add	x9, sp, #0x98
   10090:      	add	x0, sp, #0x98
   10094:      	mov	w1, #0x8                // =8
   10098:      	mov	x2, x23
   1009c:      	blr	x8
   100a0:      	ldr	x8, [sp, #0x98]
   100a4:      	cmp	x8, x21
   100a8:      	b.eq	0x10170 <generic_kprobe_path+0x6690>
   100ac:      	mov	w8, #0x4                // =4
   100b0:      	add	x9, sp, #0x78
   100b4:      	add	x0, sp, #0x78
   100b8:      	mov	w1, #0x8                // =8
   100bc:      	mov	x2, x23
   100c0:      	blr	x8
   100c4:      	add	x2, x21, #0x20
   100c8:      	mov	w8, #0x4                // =4
   100cc:      	mov	w9, #0x10               // =16
   100d0:      	add	x10, sp, #0x80
   100d4:      	add	x0, sp, #0x80
   100d8:      	mov	w1, #0x10               // =16
   100dc:      	blr	x8
   100e0:      	ldr	w21, [sp, #0x84]
   100e4:      	ldr	x8, [sp, #0x40]
   100e8:      	ldr	x10, [sp, #0x60]
   100ec:      	sub	x12, x10, x8
   100f0:      	ldr	w23, [sp, #0x68]
   100f4:      	subs	w10, w21, w23
   100f8:      	ldr	x9, [sp, #0x88]
   100fc:      	csel	w10, wzr, w10, lo
   10100:      	cmp	w23, w21
   10104:      	csel	w11, w23, w21, lo
   10108:      	cinc	w13, w11, hi
   1010c:      	sub	w14, w23, w13
   10110:      	subs	x12, x12, x13
   10114:      	str	w14, [sp, #0x68]
   10118:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   1011c:      	cmp	x12, #0xfff
   10120:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10124:      	cmp	w23, w21
   10128:      	b.ls	0x10134 <generic_kprobe_path+0x6654>
   1012c:      	mov	w13, #0x2f              // =47
   10130:      	strb	w13, [x8, x12]
   10134:      	add	x19, x8, x12
   10138:      	cmp	w23, w21
   1013c:      	add	x2, x9, x10
   10140:      	and	w1, w11, #0xff
   10144:      	mov	w8, #0x4                // =4
   10148:      	cinc	x0, x19, hi
   1014c:      	blr	x8
   10150:      	cmp	w23, w21
   10154:      	str	x19, [sp, #0x60]
   10158:      	add	x19, sp, #0x70
   1015c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10160:      	ldr	x21, [sp, #0x78]
   10164:      	ldp	x2, x24, [sp, #0x50]
   10168:      	str	x21, [sp, #0x48]
   1016c:      	b	0x101bc <generic_kprobe_path+0x66dc>
   10170:      	add	x2, x24, #0x10
   10174:      	mov	w8, #0x4                // =4
   10178:      	add	x9, sp, #0x98
   1017c:      	add	x0, sp, #0x98
   10180:      	mov	w1, #0x8                // =8
   10184:      	blr	x8
   10188:      	ldr	x8, [sp, #0x58]
   1018c:      	ldr	x9, [sp, #0x98]
   10190:      	cmp	x8, x9
   10194:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10198:      	add	x2, x24, #0x18
   1019c:      	mov	w8, #0x4                // =4
   101a0:      	mov	x0, x22
   101a4:      	mov	w1, #0x8                // =8
   101a8:      	blr	x8
   101ac:      	ldr	x24, [sp, #0x98]
   101b0:      	ldr	x21, [sp, #0x48]
   101b4:      	add	x2, x24, #0x20
   101b8:      	stp	x2, x24, [sp, #0x50]
   101bc:      	ldr	x8, [sp, #0x30]
   101c0:      	cmp	x21, x8
   101c4:      	b.ne	0x101d4 <generic_kprobe_path+0x66f4>
   101c8:      	ldr	x8, [sp, #0x38]
   101cc:      	cmp	x2, x8
   101d0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   101d4:      	mov	w8, #0x4                // =4
   101d8:      	add	x0, sp, #0x70
   101dc:      	mov	w1, #0x8                // =8
   101e0:      	blr	x8
   101e4:      	ldr	x8, [sp, #0x70]
   101e8:      	cmp	x21, x8
   101ec:      	b.eq	0x102dc <generic_kprobe_path+0x67fc>
   101f0:      	add	x23, x21, #0x18
   101f4:      	mov	w8, #0x4                // =4
   101f8:      	add	x9, sp, #0x98
   101fc:      	add	x0, sp, #0x98
   10200:      	mov	w1, #0x8                // =8
   10204:      	mov	x2, x23
   10208:      	blr	x8
   1020c:      	ldr	x8, [sp, #0x98]
   10210:      	cmp	x8, x21
   10214:      	b.eq	0x102dc <generic_kprobe_path+0x67fc>
   10218:      	mov	w8, #0x4                // =4
   1021c:      	add	x9, sp, #0x78
   10220:      	add	x0, sp, #0x78
   10224:      	mov	w1, #0x8                // =8
   10228:      	mov	x2, x23
   1022c:      	blr	x8
   10230:      	add	x2, x21, #0x20
   10234:      	mov	w8, #0x4                // =4
   10238:      	mov	w9, #0x10               // =16
   1023c:      	add	x10, sp, #0x80
   10240:      	add	x0, sp, #0x80
   10244:      	mov	w1, #0x10               // =16
   10248:      	blr	x8
   1024c:      	ldr	w21, [sp, #0x84]
   10250:      	ldr	x8, [sp, #0x40]
   10254:      	ldr	x10, [sp, #0x60]
   10258:      	sub	x12, x10, x8
   1025c:      	ldr	w23, [sp, #0x68]
   10260:      	subs	w10, w21, w23
   10264:      	ldr	x9, [sp, #0x88]
   10268:      	csel	w10, wzr, w10, lo
   1026c:      	cmp	w23, w21
   10270:      	csel	w11, w23, w21, lo
   10274:      	cinc	w13, w11, hi
   10278:      	sub	w14, w23, w13
   1027c:      	subs	x12, x12, x13
   10280:      	str	w14, [sp, #0x68]
   10284:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10288:      	cmp	x12, #0xfff
   1028c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10290:      	cmp	w23, w21
   10294:      	b.ls	0x102a0 <generic_kprobe_path+0x67c0>
   10298:      	mov	w13, #0x2f              // =47
   1029c:      	strb	w13, [x8, x12]
   102a0:      	add	x19, x8, x12
   102a4:      	cmp	w23, w21
   102a8:      	add	x2, x9, x10
   102ac:      	and	w1, w11, #0xff
   102b0:      	mov	w8, #0x4                // =4
   102b4:      	cinc	x0, x19, hi
   102b8:      	blr	x8
   102bc:      	cmp	w23, w21
   102c0:      	str	x19, [sp, #0x60]
   102c4:      	add	x19, sp, #0x70
   102c8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   102cc:      	ldr	x21, [sp, #0x78]
   102d0:      	ldp	x2, x24, [sp, #0x50]
   102d4:      	str	x21, [sp, #0x48]
   102d8:      	b	0x10328 <generic_kprobe_path+0x6848>
   102dc:      	add	x2, x24, #0x10
   102e0:      	mov	w8, #0x4                // =4
   102e4:      	add	x9, sp, #0x98
   102e8:      	add	x0, sp, #0x98
   102ec:      	mov	w1, #0x8                // =8
   102f0:      	blr	x8
   102f4:      	ldr	x8, [sp, #0x58]
   102f8:      	ldr	x9, [sp, #0x98]
   102fc:      	cmp	x8, x9
   10300:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10304:      	add	x2, x24, #0x18
   10308:      	mov	w8, #0x4                // =4
   1030c:      	mov	x0, x22
   10310:      	mov	w1, #0x8                // =8
   10314:      	blr	x8
   10318:      	ldr	x24, [sp, #0x98]
   1031c:      	ldr	x21, [sp, #0x48]
   10320:      	add	x2, x24, #0x20
   10324:      	stp	x2, x24, [sp, #0x50]
   10328:      	ldr	x8, [sp, #0x30]
   1032c:      	cmp	x21, x8
   10330:      	b.ne	0x10340 <generic_kprobe_path+0x6860>
   10334:      	ldr	x8, [sp, #0x38]
   10338:      	cmp	x2, x8
   1033c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10340:      	mov	w8, #0x4                // =4
   10344:      	add	x0, sp, #0x70
   10348:      	mov	w1, #0x8                // =8
   1034c:      	blr	x8
   10350:      	ldr	x8, [sp, #0x70]
   10354:      	cmp	x21, x8
   10358:      	b.eq	0x10448 <generic_kprobe_path+0x6968>
   1035c:      	add	x23, x21, #0x18
   10360:      	mov	w8, #0x4                // =4
   10364:      	add	x9, sp, #0x98
   10368:      	add	x0, sp, #0x98
   1036c:      	mov	w1, #0x8                // =8
   10370:      	mov	x2, x23
   10374:      	blr	x8
   10378:      	ldr	x8, [sp, #0x98]
   1037c:      	cmp	x8, x21
   10380:      	b.eq	0x10448 <generic_kprobe_path+0x6968>
   10384:      	mov	w8, #0x4                // =4
   10388:      	add	x9, sp, #0x78
   1038c:      	add	x0, sp, #0x78
   10390:      	mov	w1, #0x8                // =8
   10394:      	mov	x2, x23
   10398:      	blr	x8
   1039c:      	add	x2, x21, #0x20
   103a0:      	mov	w8, #0x4                // =4
   103a4:      	mov	w9, #0x10               // =16
   103a8:      	add	x10, sp, #0x80
   103ac:      	add	x0, sp, #0x80
   103b0:      	mov	w1, #0x10               // =16
   103b4:      	blr	x8
   103b8:      	ldr	w21, [sp, #0x84]
   103bc:      	ldr	x8, [sp, #0x40]
   103c0:      	ldr	x10, [sp, #0x60]
   103c4:      	sub	x12, x10, x8
   103c8:      	ldr	w23, [sp, #0x68]
   103cc:      	subs	w10, w21, w23
   103d0:      	ldr	x9, [sp, #0x88]
   103d4:      	csel	w10, wzr, w10, lo
   103d8:      	cmp	w23, w21
   103dc:      	csel	w11, w23, w21, lo
   103e0:      	cinc	w13, w11, hi
   103e4:      	sub	w14, w23, w13
   103e8:      	subs	x12, x12, x13
   103ec:      	str	w14, [sp, #0x68]
   103f0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   103f4:      	cmp	x12, #0xfff
   103f8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   103fc:      	cmp	w23, w21
   10400:      	b.ls	0x1040c <generic_kprobe_path+0x692c>
   10404:      	mov	w13, #0x2f              // =47
   10408:      	strb	w13, [x8, x12]
   1040c:      	add	x19, x8, x12
   10410:      	cmp	w23, w21
   10414:      	add	x2, x9, x10
   10418:      	and	w1, w11, #0xff
   1041c:      	mov	w8, #0x4                // =4
   10420:      	cinc	x0, x19, hi
   10424:      	blr	x8
   10428:      	cmp	w23, w21
   1042c:      	str	x19, [sp, #0x60]
   10430:      	add	x19, sp, #0x70
   10434:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10438:      	ldr	x21, [sp, #0x78]
   1043c:      	ldp	x2, x24, [sp, #0x50]
   10440:      	str	x21, [sp, #0x48]
   10444:      	b	0x10494 <generic_kprobe_path+0x69b4>
   10448:      	add	x2, x24, #0x10
   1044c:      	mov	w8, #0x4                // =4
   10450:      	add	x9, sp, #0x98
   10454:      	add	x0, sp, #0x98
   10458:      	mov	w1, #0x8                // =8
   1045c:      	blr	x8
   10460:      	ldr	x8, [sp, #0x58]
   10464:      	ldr	x9, [sp, #0x98]
   10468:      	cmp	x8, x9
   1046c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10470:      	add	x2, x24, #0x18
   10474:      	mov	w8, #0x4                // =4
   10478:      	mov	x0, x22
   1047c:      	mov	w1, #0x8                // =8
   10480:      	blr	x8
   10484:      	ldr	x24, [sp, #0x98]
   10488:      	ldr	x21, [sp, #0x48]
   1048c:      	add	x2, x24, #0x20
   10490:      	stp	x2, x24, [sp, #0x50]
   10494:      	ldr	x8, [sp, #0x30]
   10498:      	cmp	x21, x8
   1049c:      	b.ne	0x104ac <generic_kprobe_path+0x69cc>
   104a0:      	ldr	x8, [sp, #0x38]
   104a4:      	cmp	x2, x8
   104a8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   104ac:      	mov	w8, #0x4                // =4
   104b0:      	add	x0, sp, #0x70
   104b4:      	mov	w1, #0x8                // =8
   104b8:      	blr	x8
   104bc:      	ldr	x8, [sp, #0x70]
   104c0:      	cmp	x21, x8
   104c4:      	b.eq	0x105b4 <generic_kprobe_path+0x6ad4>
   104c8:      	add	x23, x21, #0x18
   104cc:      	mov	w8, #0x4                // =4
   104d0:      	add	x9, sp, #0x98
   104d4:      	add	x0, sp, #0x98
   104d8:      	mov	w1, #0x8                // =8
   104dc:      	mov	x2, x23
   104e0:      	blr	x8
   104e4:      	ldr	x8, [sp, #0x98]
   104e8:      	cmp	x8, x21
   104ec:      	b.eq	0x105b4 <generic_kprobe_path+0x6ad4>
   104f0:      	mov	w8, #0x4                // =4
   104f4:      	add	x9, sp, #0x78
   104f8:      	add	x0, sp, #0x78
   104fc:      	mov	w1, #0x8                // =8
   10500:      	mov	x2, x23
   10504:      	blr	x8
   10508:      	add	x2, x21, #0x20
   1050c:      	mov	w8, #0x4                // =4
   10510:      	mov	w9, #0x10               // =16
   10514:      	add	x10, sp, #0x80
   10518:      	add	x0, sp, #0x80
   1051c:      	mov	w1, #0x10               // =16
   10520:      	blr	x8
   10524:      	ldr	w21, [sp, #0x84]
   10528:      	ldr	x8, [sp, #0x40]
   1052c:      	ldr	x10, [sp, #0x60]
   10530:      	sub	x12, x10, x8
   10534:      	ldr	w23, [sp, #0x68]
   10538:      	subs	w10, w21, w23
   1053c:      	ldr	x9, [sp, #0x88]
   10540:      	csel	w10, wzr, w10, lo
   10544:      	cmp	w23, w21
   10548:      	csel	w11, w23, w21, lo
   1054c:      	cinc	w13, w11, hi
   10550:      	sub	w14, w23, w13
   10554:      	subs	x12, x12, x13
   10558:      	str	w14, [sp, #0x68]
   1055c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10560:      	cmp	x12, #0xfff
   10564:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10568:      	cmp	w23, w21
   1056c:      	b.ls	0x10578 <generic_kprobe_path+0x6a98>
   10570:      	mov	w13, #0x2f              // =47
   10574:      	strb	w13, [x8, x12]
   10578:      	add	x19, x8, x12
   1057c:      	cmp	w23, w21
   10580:      	add	x2, x9, x10
   10584:      	and	w1, w11, #0xff
   10588:      	mov	w8, #0x4                // =4
   1058c:      	cinc	x0, x19, hi
   10590:      	blr	x8
   10594:      	cmp	w23, w21
   10598:      	str	x19, [sp, #0x60]
   1059c:      	add	x19, sp, #0x70
   105a0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   105a4:      	ldr	x21, [sp, #0x78]
   105a8:      	ldp	x2, x24, [sp, #0x50]
   105ac:      	str	x21, [sp, #0x48]
   105b0:      	b	0x10600 <generic_kprobe_path+0x6b20>
   105b4:      	add	x2, x24, #0x10
   105b8:      	mov	w8, #0x4                // =4
   105bc:      	add	x9, sp, #0x98
   105c0:      	add	x0, sp, #0x98
   105c4:      	mov	w1, #0x8                // =8
   105c8:      	blr	x8
   105cc:      	ldr	x8, [sp, #0x58]
   105d0:      	ldr	x9, [sp, #0x98]
   105d4:      	cmp	x8, x9
   105d8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   105dc:      	add	x2, x24, #0x18
   105e0:      	mov	w8, #0x4                // =4
   105e4:      	mov	x0, x22
   105e8:      	mov	w1, #0x8                // =8
   105ec:      	blr	x8
   105f0:      	ldr	x24, [sp, #0x98]
   105f4:      	ldr	x21, [sp, #0x48]
   105f8:      	add	x2, x24, #0x20
   105fc:      	stp	x2, x24, [sp, #0x50]
   10600:      	ldr	x8, [sp, #0x30]
   10604:      	cmp	x21, x8
   10608:      	b.ne	0x10618 <generic_kprobe_path+0x6b38>
   1060c:      	ldr	x8, [sp, #0x38]
   10610:      	cmp	x2, x8
   10614:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10618:      	mov	w8, #0x4                // =4
   1061c:      	add	x0, sp, #0x70
   10620:      	mov	w1, #0x8                // =8
   10624:      	blr	x8
   10628:      	ldr	x8, [sp, #0x70]
   1062c:      	cmp	x21, x8
   10630:      	b.eq	0x10720 <generic_kprobe_path+0x6c40>
   10634:      	add	x23, x21, #0x18
   10638:      	mov	w8, #0x4                // =4
   1063c:      	add	x9, sp, #0x98
   10640:      	add	x0, sp, #0x98
   10644:      	mov	w1, #0x8                // =8
   10648:      	mov	x2, x23
   1064c:      	blr	x8
   10650:      	ldr	x8, [sp, #0x98]
   10654:      	cmp	x8, x21
   10658:      	b.eq	0x10720 <generic_kprobe_path+0x6c40>
   1065c:      	mov	w8, #0x4                // =4
   10660:      	add	x9, sp, #0x78
   10664:      	add	x0, sp, #0x78
   10668:      	mov	w1, #0x8                // =8
   1066c:      	mov	x2, x23
   10670:      	blr	x8
   10674:      	add	x2, x21, #0x20
   10678:      	mov	w8, #0x4                // =4
   1067c:      	mov	w9, #0x10               // =16
   10680:      	add	x10, sp, #0x80
   10684:      	add	x0, sp, #0x80
   10688:      	mov	w1, #0x10               // =16
   1068c:      	blr	x8
   10690:      	ldr	w21, [sp, #0x84]
   10694:      	ldr	x8, [sp, #0x40]
   10698:      	ldr	x10, [sp, #0x60]
   1069c:      	sub	x12, x10, x8
   106a0:      	ldr	w23, [sp, #0x68]
   106a4:      	subs	w10, w21, w23
   106a8:      	ldr	x9, [sp, #0x88]
   106ac:      	csel	w10, wzr, w10, lo
   106b0:      	cmp	w23, w21
   106b4:      	csel	w11, w23, w21, lo
   106b8:      	cinc	w13, w11, hi
   106bc:      	sub	w14, w23, w13
   106c0:      	subs	x12, x12, x13
   106c4:      	str	w14, [sp, #0x68]
   106c8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   106cc:      	cmp	x12, #0xfff
   106d0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   106d4:      	cmp	w23, w21
   106d8:      	b.ls	0x106e4 <generic_kprobe_path+0x6c04>
   106dc:      	mov	w13, #0x2f              // =47
   106e0:      	strb	w13, [x8, x12]
   106e4:      	add	x19, x8, x12
   106e8:      	cmp	w23, w21
   106ec:      	add	x2, x9, x10
   106f0:      	and	w1, w11, #0xff
   106f4:      	mov	w8, #0x4                // =4
   106f8:      	cinc	x0, x19, hi
   106fc:      	blr	x8
   10700:      	cmp	w23, w21
   10704:      	str	x19, [sp, #0x60]
   10708:      	add	x19, sp, #0x70
   1070c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10710:      	ldr	x21, [sp, #0x78]
   10714:      	ldp	x2, x24, [sp, #0x50]
   10718:      	str	x21, [sp, #0x48]
   1071c:      	b	0x1076c <generic_kprobe_path+0x6c8c>
   10720:      	add	x2, x24, #0x10
   10724:      	mov	w8, #0x4                // =4
   10728:      	add	x9, sp, #0x98
   1072c:      	add	x0, sp, #0x98
   10730:      	mov	w1, #0x8                // =8
   10734:      	blr	x8
   10738:      	ldr	x8, [sp, #0x58]
   1073c:      	ldr	x9, [sp, #0x98]
   10740:      	cmp	x8, x9
   10744:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10748:      	add	x2, x24, #0x18
   1074c:      	mov	w8, #0x4                // =4
   10750:      	mov	x0, x22
   10754:      	mov	w1, #0x8                // =8
   10758:      	blr	x8
   1075c:      	ldr	x24, [sp, #0x98]
   10760:      	ldr	x21, [sp, #0x48]
   10764:      	add	x2, x24, #0x20
   10768:      	stp	x2, x24, [sp, #0x50]
   1076c:      	ldr	x8, [sp, #0x30]
   10770:      	cmp	x21, x8
   10774:      	b.ne	0x10784 <generic_kprobe_path+0x6ca4>
   10778:      	ldr	x8, [sp, #0x38]
   1077c:      	cmp	x2, x8
   10780:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10784:      	mov	w8, #0x4                // =4
   10788:      	add	x0, sp, #0x70
   1078c:      	mov	w1, #0x8                // =8
   10790:      	blr	x8
   10794:      	ldr	x8, [sp, #0x70]
   10798:      	cmp	x21, x8
   1079c:      	b.eq	0x1088c <generic_kprobe_path+0x6dac>
   107a0:      	add	x23, x21, #0x18
   107a4:      	mov	w8, #0x4                // =4
   107a8:      	add	x9, sp, #0x98
   107ac:      	add	x0, sp, #0x98
   107b0:      	mov	w1, #0x8                // =8
   107b4:      	mov	x2, x23
   107b8:      	blr	x8
   107bc:      	ldr	x8, [sp, #0x98]
   107c0:      	cmp	x8, x21
   107c4:      	b.eq	0x1088c <generic_kprobe_path+0x6dac>
   107c8:      	mov	w8, #0x4                // =4
   107cc:      	add	x9, sp, #0x78
   107d0:      	add	x0, sp, #0x78
   107d4:      	mov	w1, #0x8                // =8
   107d8:      	mov	x2, x23
   107dc:      	blr	x8
   107e0:      	add	x2, x21, #0x20
   107e4:      	mov	w8, #0x4                // =4
   107e8:      	mov	w9, #0x10               // =16
   107ec:      	add	x10, sp, #0x80
   107f0:      	add	x0, sp, #0x80
   107f4:      	mov	w1, #0x10               // =16
   107f8:      	blr	x8
   107fc:      	ldr	w21, [sp, #0x84]
   10800:      	ldr	x8, [sp, #0x40]
   10804:      	ldr	x10, [sp, #0x60]
   10808:      	sub	x12, x10, x8
   1080c:      	ldr	w23, [sp, #0x68]
   10810:      	subs	w10, w21, w23
   10814:      	ldr	x9, [sp, #0x88]
   10818:      	csel	w10, wzr, w10, lo
   1081c:      	cmp	w23, w21
   10820:      	csel	w11, w23, w21, lo
   10824:      	cinc	w13, w11, hi
   10828:      	sub	w14, w23, w13
   1082c:      	subs	x12, x12, x13
   10830:      	str	w14, [sp, #0x68]
   10834:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10838:      	cmp	x12, #0xfff
   1083c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10840:      	cmp	w23, w21
   10844:      	b.ls	0x10850 <generic_kprobe_path+0x6d70>
   10848:      	mov	w13, #0x2f              // =47
   1084c:      	strb	w13, [x8, x12]
   10850:      	add	x19, x8, x12
   10854:      	cmp	w23, w21
   10858:      	add	x2, x9, x10
   1085c:      	and	w1, w11, #0xff
   10860:      	mov	w8, #0x4                // =4
   10864:      	cinc	x0, x19, hi
   10868:      	blr	x8
   1086c:      	cmp	w23, w21
   10870:      	str	x19, [sp, #0x60]
   10874:      	add	x19, sp, #0x70
   10878:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   1087c:      	ldr	x21, [sp, #0x78]
   10880:      	ldp	x2, x24, [sp, #0x50]
   10884:      	str	x21, [sp, #0x48]
   10888:      	b	0x108d8 <generic_kprobe_path+0x6df8>
   1088c:      	add	x2, x24, #0x10
   10890:      	mov	w8, #0x4                // =4
   10894:      	add	x9, sp, #0x98
   10898:      	add	x0, sp, #0x98
   1089c:      	mov	w1, #0x8                // =8
   108a0:      	blr	x8
   108a4:      	ldr	x8, [sp, #0x58]
   108a8:      	ldr	x9, [sp, #0x98]
   108ac:      	cmp	x8, x9
   108b0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   108b4:      	add	x2, x24, #0x18
   108b8:      	mov	w8, #0x4                // =4
   108bc:      	mov	x0, x22
   108c0:      	mov	w1, #0x8                // =8
   108c4:      	blr	x8
   108c8:      	ldr	x24, [sp, #0x98]
   108cc:      	ldr	x21, [sp, #0x48]
   108d0:      	add	x2, x24, #0x20
   108d4:      	stp	x2, x24, [sp, #0x50]
   108d8:      	ldr	x8, [sp, #0x30]
   108dc:      	cmp	x21, x8
   108e0:      	b.ne	0x108f0 <generic_kprobe_path+0x6e10>
   108e4:      	ldr	x8, [sp, #0x38]
   108e8:      	cmp	x2, x8
   108ec:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   108f0:      	mov	w8, #0x4                // =4
   108f4:      	add	x0, sp, #0x70
   108f8:      	mov	w1, #0x8                // =8
   108fc:      	blr	x8
   10900:      	ldr	x8, [sp, #0x70]
   10904:      	cmp	x21, x8
   10908:      	b.eq	0x109f8 <generic_kprobe_path+0x6f18>
   1090c:      	add	x23, x21, #0x18
   10910:      	mov	w8, #0x4                // =4
   10914:      	add	x9, sp, #0x98
   10918:      	add	x0, sp, #0x98
   1091c:      	mov	w1, #0x8                // =8
   10920:      	mov	x2, x23
   10924:      	blr	x8
   10928:      	ldr	x8, [sp, #0x98]
   1092c:      	cmp	x8, x21
   10930:      	b.eq	0x109f8 <generic_kprobe_path+0x6f18>
   10934:      	mov	w8, #0x4                // =4
   10938:      	add	x9, sp, #0x78
   1093c:      	add	x0, sp, #0x78
   10940:      	mov	w1, #0x8                // =8
   10944:      	mov	x2, x23
   10948:      	blr	x8
   1094c:      	add	x2, x21, #0x20
   10950:      	mov	w8, #0x4                // =4
   10954:      	mov	w9, #0x10               // =16
   10958:      	add	x10, sp, #0x80
   1095c:      	add	x0, sp, #0x80
   10960:      	mov	w1, #0x10               // =16
   10964:      	blr	x8
   10968:      	ldr	w21, [sp, #0x84]
   1096c:      	ldr	x8, [sp, #0x40]
   10970:      	ldr	x10, [sp, #0x60]
   10974:      	sub	x12, x10, x8
   10978:      	ldr	w23, [sp, #0x68]
   1097c:      	subs	w10, w21, w23
   10980:      	ldr	x9, [sp, #0x88]
   10984:      	csel	w10, wzr, w10, lo
   10988:      	cmp	w23, w21
   1098c:      	csel	w11, w23, w21, lo
   10990:      	cinc	w13, w11, hi
   10994:      	sub	w14, w23, w13
   10998:      	subs	x12, x12, x13
   1099c:      	str	w14, [sp, #0x68]
   109a0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   109a4:      	cmp	x12, #0xfff
   109a8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   109ac:      	cmp	w23, w21
   109b0:      	b.ls	0x109bc <generic_kprobe_path+0x6edc>
   109b4:      	mov	w13, #0x2f              // =47
   109b8:      	strb	w13, [x8, x12]
   109bc:      	add	x19, x8, x12
   109c0:      	cmp	w23, w21
   109c4:      	add	x2, x9, x10
   109c8:      	and	w1, w11, #0xff
   109cc:      	mov	w8, #0x4                // =4
   109d0:      	cinc	x0, x19, hi
   109d4:      	blr	x8
   109d8:      	cmp	w23, w21
   109dc:      	str	x19, [sp, #0x60]
   109e0:      	add	x19, sp, #0x70
   109e4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   109e8:      	ldr	x21, [sp, #0x78]
   109ec:      	ldp	x2, x24, [sp, #0x50]
   109f0:      	str	x21, [sp, #0x48]
   109f4:      	b	0x10a44 <generic_kprobe_path+0x6f64>
   109f8:      	add	x2, x24, #0x10
   109fc:      	mov	w8, #0x4                // =4
   10a00:      	add	x9, sp, #0x98
   10a04:      	add	x0, sp, #0x98
   10a08:      	mov	w1, #0x8                // =8
   10a0c:      	blr	x8
   10a10:      	ldr	x8, [sp, #0x58]
   10a14:      	ldr	x9, [sp, #0x98]
   10a18:      	cmp	x8, x9
   10a1c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10a20:      	add	x2, x24, #0x18
   10a24:      	mov	w8, #0x4                // =4
   10a28:      	mov	x0, x22
   10a2c:      	mov	w1, #0x8                // =8
   10a30:      	blr	x8
   10a34:      	ldr	x24, [sp, #0x98]
   10a38:      	ldr	x21, [sp, #0x48]
   10a3c:      	add	x2, x24, #0x20
   10a40:      	stp	x2, x24, [sp, #0x50]
   10a44:      	ldr	x8, [sp, #0x30]
   10a48:      	cmp	x21, x8
   10a4c:      	b.ne	0x10a5c <generic_kprobe_path+0x6f7c>
   10a50:      	ldr	x8, [sp, #0x38]
   10a54:      	cmp	x2, x8
   10a58:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10a5c:      	mov	w8, #0x4                // =4
   10a60:      	add	x0, sp, #0x70
   10a64:      	mov	w1, #0x8                // =8
   10a68:      	blr	x8
   10a6c:      	ldr	x8, [sp, #0x70]
   10a70:      	cmp	x21, x8
   10a74:      	b.eq	0x10b64 <generic_kprobe_path+0x7084>
   10a78:      	add	x23, x21, #0x18
   10a7c:      	mov	w8, #0x4                // =4
   10a80:      	add	x9, sp, #0x98
   10a84:      	add	x0, sp, #0x98
   10a88:      	mov	w1, #0x8                // =8
   10a8c:      	mov	x2, x23
   10a90:      	blr	x8
   10a94:      	ldr	x8, [sp, #0x98]
   10a98:      	cmp	x8, x21
   10a9c:      	b.eq	0x10b64 <generic_kprobe_path+0x7084>
   10aa0:      	mov	w8, #0x4                // =4
   10aa4:      	add	x9, sp, #0x78
   10aa8:      	add	x0, sp, #0x78
   10aac:      	mov	w1, #0x8                // =8
   10ab0:      	mov	x2, x23
   10ab4:      	blr	x8
   10ab8:      	add	x2, x21, #0x20
   10abc:      	mov	w8, #0x4                // =4
   10ac0:      	mov	w9, #0x10               // =16
   10ac4:      	add	x10, sp, #0x80
   10ac8:      	add	x0, sp, #0x80
   10acc:      	mov	w1, #0x10               // =16
   10ad0:      	blr	x8
   10ad4:      	ldr	w21, [sp, #0x84]
   10ad8:      	ldr	x8, [sp, #0x40]
   10adc:      	ldr	x10, [sp, #0x60]
   10ae0:      	sub	x12, x10, x8
   10ae4:      	ldr	w23, [sp, #0x68]
   10ae8:      	subs	w10, w21, w23
   10aec:      	ldr	x9, [sp, #0x88]
   10af0:      	csel	w10, wzr, w10, lo
   10af4:      	cmp	w23, w21
   10af8:      	csel	w11, w23, w21, lo
   10afc:      	cinc	w13, w11, hi
   10b00:      	sub	w14, w23, w13
   10b04:      	subs	x12, x12, x13
   10b08:      	str	w14, [sp, #0x68]
   10b0c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10b10:      	cmp	x12, #0xfff
   10b14:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10b18:      	cmp	w23, w21
   10b1c:      	b.ls	0x10b28 <generic_kprobe_path+0x7048>
   10b20:      	mov	w13, #0x2f              // =47
   10b24:      	strb	w13, [x8, x12]
   10b28:      	add	x19, x8, x12
   10b2c:      	cmp	w23, w21
   10b30:      	add	x2, x9, x10
   10b34:      	and	w1, w11, #0xff
   10b38:      	mov	w8, #0x4                // =4
   10b3c:      	cinc	x0, x19, hi
   10b40:      	blr	x8
   10b44:      	cmp	w23, w21
   10b48:      	str	x19, [sp, #0x60]
   10b4c:      	add	x19, sp, #0x70
   10b50:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10b54:      	ldr	x21, [sp, #0x78]
   10b58:      	ldp	x2, x24, [sp, #0x50]
   10b5c:      	str	x21, [sp, #0x48]
   10b60:      	b	0x10bb0 <generic_kprobe_path+0x70d0>
   10b64:      	add	x2, x24, #0x10
   10b68:      	mov	w8, #0x4                // =4
   10b6c:      	add	x9, sp, #0x98
   10b70:      	add	x0, sp, #0x98
   10b74:      	mov	w1, #0x8                // =8
   10b78:      	blr	x8
   10b7c:      	ldr	x8, [sp, #0x58]
   10b80:      	ldr	x9, [sp, #0x98]
   10b84:      	cmp	x8, x9
   10b88:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10b8c:      	add	x2, x24, #0x18
   10b90:      	mov	w8, #0x4                // =4
   10b94:      	mov	x0, x22
   10b98:      	mov	w1, #0x8                // =8
   10b9c:      	blr	x8
   10ba0:      	ldr	x24, [sp, #0x98]
   10ba4:      	ldr	x21, [sp, #0x48]
   10ba8:      	add	x2, x24, #0x20
   10bac:      	stp	x2, x24, [sp, #0x50]
   10bb0:      	ldr	x8, [sp, #0x30]
   10bb4:      	cmp	x21, x8
   10bb8:      	b.ne	0x10bc8 <generic_kprobe_path+0x70e8>
   10bbc:      	ldr	x8, [sp, #0x38]
   10bc0:      	cmp	x2, x8
   10bc4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10bc8:      	mov	w8, #0x4                // =4
   10bcc:      	add	x0, sp, #0x70
   10bd0:      	mov	w1, #0x8                // =8
   10bd4:      	blr	x8
   10bd8:      	ldr	x8, [sp, #0x70]
   10bdc:      	cmp	x21, x8
   10be0:      	b.eq	0x10cd0 <generic_kprobe_path+0x71f0>
   10be4:      	add	x23, x21, #0x18
   10be8:      	mov	w8, #0x4                // =4
   10bec:      	add	x9, sp, #0x98
   10bf0:      	add	x0, sp, #0x98
   10bf4:      	mov	w1, #0x8                // =8
   10bf8:      	mov	x2, x23
   10bfc:      	blr	x8
   10c00:      	ldr	x8, [sp, #0x98]
   10c04:      	cmp	x8, x21
   10c08:      	b.eq	0x10cd0 <generic_kprobe_path+0x71f0>
   10c0c:      	mov	w8, #0x4                // =4
   10c10:      	add	x9, sp, #0x78
   10c14:      	add	x0, sp, #0x78
   10c18:      	mov	w1, #0x8                // =8
   10c1c:      	mov	x2, x23
   10c20:      	blr	x8
   10c24:      	add	x2, x21, #0x20
   10c28:      	mov	w8, #0x4                // =4
   10c2c:      	mov	w9, #0x10               // =16
   10c30:      	add	x10, sp, #0x80
   10c34:      	add	x0, sp, #0x80
   10c38:      	mov	w1, #0x10               // =16
   10c3c:      	blr	x8
   10c40:      	ldr	w21, [sp, #0x84]
   10c44:      	ldr	x8, [sp, #0x40]
   10c48:      	ldr	x10, [sp, #0x60]
   10c4c:      	sub	x12, x10, x8
   10c50:      	ldr	w23, [sp, #0x68]
   10c54:      	subs	w10, w21, w23
   10c58:      	ldr	x9, [sp, #0x88]
   10c5c:      	csel	w10, wzr, w10, lo
   10c60:      	cmp	w23, w21
   10c64:      	csel	w11, w23, w21, lo
   10c68:      	cinc	w13, w11, hi
   10c6c:      	sub	w14, w23, w13
   10c70:      	subs	x12, x12, x13
   10c74:      	str	w14, [sp, #0x68]
   10c78:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10c7c:      	cmp	x12, #0xfff
   10c80:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10c84:      	cmp	w23, w21
   10c88:      	b.ls	0x10c94 <generic_kprobe_path+0x71b4>
   10c8c:      	mov	w13, #0x2f              // =47
   10c90:      	strb	w13, [x8, x12]
   10c94:      	add	x19, x8, x12
   10c98:      	cmp	w23, w21
   10c9c:      	add	x2, x9, x10
   10ca0:      	and	w1, w11, #0xff
   10ca4:      	mov	w8, #0x4                // =4
   10ca8:      	cinc	x0, x19, hi
   10cac:      	blr	x8
   10cb0:      	cmp	w23, w21
   10cb4:      	str	x19, [sp, #0x60]
   10cb8:      	add	x19, sp, #0x70
   10cbc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10cc0:      	ldr	x21, [sp, #0x78]
   10cc4:      	ldp	x2, x24, [sp, #0x50]
   10cc8:      	str	x21, [sp, #0x48]
   10ccc:      	b	0x10d1c <generic_kprobe_path+0x723c>
   10cd0:      	add	x2, x24, #0x10
   10cd4:      	mov	w8, #0x4                // =4
   10cd8:      	add	x9, sp, #0x98
   10cdc:      	add	x0, sp, #0x98
   10ce0:      	mov	w1, #0x8                // =8
   10ce4:      	blr	x8
   10ce8:      	ldr	x8, [sp, #0x58]
   10cec:      	ldr	x9, [sp, #0x98]
   10cf0:      	cmp	x8, x9
   10cf4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10cf8:      	add	x2, x24, #0x18
   10cfc:      	mov	w8, #0x4                // =4
   10d00:      	mov	x0, x22
   10d04:      	mov	w1, #0x8                // =8
   10d08:      	blr	x8
   10d0c:      	ldr	x24, [sp, #0x98]
   10d10:      	ldr	x21, [sp, #0x48]
   10d14:      	add	x2, x24, #0x20
   10d18:      	stp	x2, x24, [sp, #0x50]
   10d1c:      	ldr	x8, [sp, #0x30]
   10d20:      	cmp	x21, x8
   10d24:      	b.ne	0x10d34 <generic_kprobe_path+0x7254>
   10d28:      	ldr	x8, [sp, #0x38]
   10d2c:      	cmp	x2, x8
   10d30:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10d34:      	mov	w8, #0x4                // =4
   10d38:      	add	x0, sp, #0x70
   10d3c:      	mov	w1, #0x8                // =8
   10d40:      	blr	x8
   10d44:      	ldr	x8, [sp, #0x70]
   10d48:      	cmp	x21, x8
   10d4c:      	b.eq	0x10e3c <generic_kprobe_path+0x735c>
   10d50:      	add	x23, x21, #0x18
   10d54:      	mov	w8, #0x4                // =4
   10d58:      	add	x9, sp, #0x98
   10d5c:      	add	x0, sp, #0x98
   10d60:      	mov	w1, #0x8                // =8
   10d64:      	mov	x2, x23
   10d68:      	blr	x8
   10d6c:      	ldr	x8, [sp, #0x98]
   10d70:      	cmp	x8, x21
   10d74:      	b.eq	0x10e3c <generic_kprobe_path+0x735c>
   10d78:      	mov	w8, #0x4                // =4
   10d7c:      	add	x9, sp, #0x78
   10d80:      	add	x0, sp, #0x78
   10d84:      	mov	w1, #0x8                // =8
   10d88:      	mov	x2, x23
   10d8c:      	blr	x8
   10d90:      	add	x2, x21, #0x20
   10d94:      	mov	w8, #0x4                // =4
   10d98:      	mov	w9, #0x10               // =16
   10d9c:      	add	x10, sp, #0x80
   10da0:      	add	x0, sp, #0x80
   10da4:      	mov	w1, #0x10               // =16
   10da8:      	blr	x8
   10dac:      	ldr	w21, [sp, #0x84]
   10db0:      	ldr	x8, [sp, #0x40]
   10db4:      	ldr	x10, [sp, #0x60]
   10db8:      	sub	x12, x10, x8
   10dbc:      	ldr	w23, [sp, #0x68]
   10dc0:      	subs	w10, w21, w23
   10dc4:      	ldr	x9, [sp, #0x88]
   10dc8:      	csel	w10, wzr, w10, lo
   10dcc:      	cmp	w23, w21
   10dd0:      	csel	w11, w23, w21, lo
   10dd4:      	cinc	w13, w11, hi
   10dd8:      	sub	w14, w23, w13
   10ddc:      	subs	x12, x12, x13
   10de0:      	str	w14, [sp, #0x68]
   10de4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10de8:      	cmp	x12, #0xfff
   10dec:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10df0:      	cmp	w23, w21
   10df4:      	b.ls	0x10e00 <generic_kprobe_path+0x7320>
   10df8:      	mov	w13, #0x2f              // =47
   10dfc:      	strb	w13, [x8, x12]
   10e00:      	add	x19, x8, x12
   10e04:      	cmp	w23, w21
   10e08:      	add	x2, x9, x10
   10e0c:      	and	w1, w11, #0xff
   10e10:      	mov	w8, #0x4                // =4
   10e14:      	cinc	x0, x19, hi
   10e18:      	blr	x8
   10e1c:      	cmp	w23, w21
   10e20:      	str	x19, [sp, #0x60]
   10e24:      	add	x19, sp, #0x70
   10e28:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10e2c:      	ldr	x21, [sp, #0x78]
   10e30:      	ldp	x2, x24, [sp, #0x50]
   10e34:      	str	x21, [sp, #0x48]
   10e38:      	b	0x10e88 <generic_kprobe_path+0x73a8>
   10e3c:      	add	x2, x24, #0x10
   10e40:      	mov	w8, #0x4                // =4
   10e44:      	add	x9, sp, #0x98
   10e48:      	add	x0, sp, #0x98
   10e4c:      	mov	w1, #0x8                // =8
   10e50:      	blr	x8
   10e54:      	ldr	x8, [sp, #0x58]
   10e58:      	ldr	x9, [sp, #0x98]
   10e5c:      	cmp	x8, x9
   10e60:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10e64:      	add	x2, x24, #0x18
   10e68:      	mov	w8, #0x4                // =4
   10e6c:      	mov	x0, x22
   10e70:      	mov	w1, #0x8                // =8
   10e74:      	blr	x8
   10e78:      	ldr	x24, [sp, #0x98]
   10e7c:      	ldr	x21, [sp, #0x48]
   10e80:      	add	x2, x24, #0x20
   10e84:      	stp	x2, x24, [sp, #0x50]
   10e88:      	ldr	x8, [sp, #0x30]
   10e8c:      	cmp	x21, x8
   10e90:      	b.ne	0x10ea0 <generic_kprobe_path+0x73c0>
   10e94:      	ldr	x8, [sp, #0x38]
   10e98:      	cmp	x2, x8
   10e9c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10ea0:      	mov	w8, #0x4                // =4
   10ea4:      	add	x0, sp, #0x70
   10ea8:      	mov	w1, #0x8                // =8
   10eac:      	blr	x8
   10eb0:      	ldr	x8, [sp, #0x70]
   10eb4:      	cmp	x21, x8
   10eb8:      	b.eq	0x10fa8 <generic_kprobe_path+0x74c8>
   10ebc:      	add	x23, x21, #0x18
   10ec0:      	mov	w8, #0x4                // =4
   10ec4:      	add	x9, sp, #0x98
   10ec8:      	add	x0, sp, #0x98
   10ecc:      	mov	w1, #0x8                // =8
   10ed0:      	mov	x2, x23
   10ed4:      	blr	x8
   10ed8:      	ldr	x8, [sp, #0x98]
   10edc:      	cmp	x8, x21
   10ee0:      	b.eq	0x10fa8 <generic_kprobe_path+0x74c8>
   10ee4:      	mov	w8, #0x4                // =4
   10ee8:      	add	x9, sp, #0x78
   10eec:      	add	x0, sp, #0x78
   10ef0:      	mov	w1, #0x8                // =8
   10ef4:      	mov	x2, x23
   10ef8:      	blr	x8
   10efc:      	add	x2, x21, #0x20
   10f00:      	mov	w8, #0x4                // =4
   10f04:      	mov	w9, #0x10               // =16
   10f08:      	add	x10, sp, #0x80
   10f0c:      	add	x0, sp, #0x80
   10f10:      	mov	w1, #0x10               // =16
   10f14:      	blr	x8
   10f18:      	ldr	w21, [sp, #0x84]
   10f1c:      	ldr	x8, [sp, #0x40]
   10f20:      	ldr	x10, [sp, #0x60]
   10f24:      	sub	x12, x10, x8
   10f28:      	ldr	w23, [sp, #0x68]
   10f2c:      	subs	w10, w21, w23
   10f30:      	ldr	x9, [sp, #0x88]
   10f34:      	csel	w10, wzr, w10, lo
   10f38:      	cmp	w23, w21
   10f3c:      	csel	w11, w23, w21, lo
   10f40:      	cinc	w13, w11, hi
   10f44:      	sub	w14, w23, w13
   10f48:      	subs	x12, x12, x13
   10f4c:      	str	w14, [sp, #0x68]
   10f50:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   10f54:      	cmp	x12, #0xfff
   10f58:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   10f5c:      	cmp	w23, w21
   10f60:      	b.ls	0x10f6c <generic_kprobe_path+0x748c>
   10f64:      	mov	w13, #0x2f              // =47
   10f68:      	strb	w13, [x8, x12]
   10f6c:      	add	x19, x8, x12
   10f70:      	cmp	w23, w21
   10f74:      	add	x2, x9, x10
   10f78:      	and	w1, w11, #0xff
   10f7c:      	mov	w8, #0x4                // =4
   10f80:      	cinc	x0, x19, hi
   10f84:      	blr	x8
   10f88:      	cmp	w23, w21
   10f8c:      	str	x19, [sp, #0x60]
   10f90:      	add	x19, sp, #0x70
   10f94:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   10f98:      	ldr	x21, [sp, #0x78]
   10f9c:      	ldp	x2, x24, [sp, #0x50]
   10fa0:      	str	x21, [sp, #0x48]
   10fa4:      	b	0x10ff4 <generic_kprobe_path+0x7514>
   10fa8:      	add	x2, x24, #0x10
   10fac:      	mov	w8, #0x4                // =4
   10fb0:      	add	x9, sp, #0x98
   10fb4:      	add	x0, sp, #0x98
   10fb8:      	mov	w1, #0x8                // =8
   10fbc:      	blr	x8
   10fc0:      	ldr	x8, [sp, #0x58]
   10fc4:      	ldr	x9, [sp, #0x98]
   10fc8:      	cmp	x8, x9
   10fcc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   10fd0:      	add	x2, x24, #0x18
   10fd4:      	mov	w8, #0x4                // =4
   10fd8:      	mov	x0, x22
   10fdc:      	mov	w1, #0x8                // =8
   10fe0:      	blr	x8
   10fe4:      	ldr	x24, [sp, #0x98]
   10fe8:      	ldr	x21, [sp, #0x48]
   10fec:      	add	x2, x24, #0x20
   10ff0:      	stp	x2, x24, [sp, #0x50]
   10ff4:      	ldr	x8, [sp, #0x30]
   10ff8:      	cmp	x21, x8
   10ffc:      	b.ne	0x1100c <generic_kprobe_path+0x752c>
   11000:      	ldr	x8, [sp, #0x38]
   11004:      	cmp	x2, x8
   11008:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1100c:      	mov	w8, #0x4                // =4
   11010:      	add	x0, sp, #0x70
   11014:      	mov	w1, #0x8                // =8
   11018:      	blr	x8
   1101c:      	ldr	x8, [sp, #0x70]
   11020:      	cmp	x21, x8
   11024:      	b.eq	0x11114 <generic_kprobe_path+0x7634>
   11028:      	add	x23, x21, #0x18
   1102c:      	mov	w8, #0x4                // =4
   11030:      	add	x9, sp, #0x98
   11034:      	add	x0, sp, #0x98
   11038:      	mov	w1, #0x8                // =8
   1103c:      	mov	x2, x23
   11040:      	blr	x8
   11044:      	ldr	x8, [sp, #0x98]
   11048:      	cmp	x8, x21
   1104c:      	b.eq	0x11114 <generic_kprobe_path+0x7634>
   11050:      	mov	w8, #0x4                // =4
   11054:      	add	x9, sp, #0x78
   11058:      	add	x0, sp, #0x78
   1105c:      	mov	w1, #0x8                // =8
   11060:      	mov	x2, x23
   11064:      	blr	x8
   11068:      	add	x2, x21, #0x20
   1106c:      	mov	w8, #0x4                // =4
   11070:      	mov	w9, #0x10               // =16
   11074:      	add	x10, sp, #0x80
   11078:      	add	x0, sp, #0x80
   1107c:      	mov	w1, #0x10               // =16
   11080:      	blr	x8
   11084:      	ldr	w21, [sp, #0x84]
   11088:      	ldr	x8, [sp, #0x40]
   1108c:      	ldr	x10, [sp, #0x60]
   11090:      	sub	x12, x10, x8
   11094:      	ldr	w23, [sp, #0x68]
   11098:      	subs	w10, w21, w23
   1109c:      	ldr	x9, [sp, #0x88]
   110a0:      	csel	w10, wzr, w10, lo
   110a4:      	cmp	w23, w21
   110a8:      	csel	w11, w23, w21, lo
   110ac:      	cinc	w13, w11, hi
   110b0:      	sub	w14, w23, w13
   110b4:      	subs	x12, x12, x13
   110b8:      	str	w14, [sp, #0x68]
   110bc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   110c0:      	cmp	x12, #0xfff
   110c4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   110c8:      	cmp	w23, w21
   110cc:      	b.ls	0x110d8 <generic_kprobe_path+0x75f8>
   110d0:      	mov	w13, #0x2f              // =47
   110d4:      	strb	w13, [x8, x12]
   110d8:      	add	x19, x8, x12
   110dc:      	cmp	w23, w21
   110e0:      	add	x2, x9, x10
   110e4:      	and	w1, w11, #0xff
   110e8:      	mov	w8, #0x4                // =4
   110ec:      	cinc	x0, x19, hi
   110f0:      	blr	x8
   110f4:      	cmp	w23, w21
   110f8:      	str	x19, [sp, #0x60]
   110fc:      	add	x19, sp, #0x70
   11100:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11104:      	ldr	x21, [sp, #0x78]
   11108:      	ldp	x2, x24, [sp, #0x50]
   1110c:      	str	x21, [sp, #0x48]
   11110:      	b	0x11160 <generic_kprobe_path+0x7680>
   11114:      	add	x2, x24, #0x10
   11118:      	mov	w8, #0x4                // =4
   1111c:      	add	x9, sp, #0x98
   11120:      	add	x0, sp, #0x98
   11124:      	mov	w1, #0x8                // =8
   11128:      	blr	x8
   1112c:      	ldr	x8, [sp, #0x58]
   11130:      	ldr	x9, [sp, #0x98]
   11134:      	cmp	x8, x9
   11138:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1113c:      	add	x2, x24, #0x18
   11140:      	mov	w8, #0x4                // =4
   11144:      	mov	x0, x22
   11148:      	mov	w1, #0x8                // =8
   1114c:      	blr	x8
   11150:      	ldr	x24, [sp, #0x98]
   11154:      	ldr	x21, [sp, #0x48]
   11158:      	add	x2, x24, #0x20
   1115c:      	stp	x2, x24, [sp, #0x50]
   11160:      	ldr	x8, [sp, #0x30]
   11164:      	cmp	x21, x8
   11168:      	b.ne	0x11178 <generic_kprobe_path+0x7698>
   1116c:      	ldr	x8, [sp, #0x38]
   11170:      	cmp	x2, x8
   11174:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11178:      	mov	w8, #0x4                // =4
   1117c:      	add	x0, sp, #0x70
   11180:      	mov	w1, #0x8                // =8
   11184:      	blr	x8
   11188:      	ldr	x8, [sp, #0x70]
   1118c:      	cmp	x21, x8
   11190:      	b.eq	0x11280 <generic_kprobe_path+0x77a0>
   11194:      	add	x23, x21, #0x18
   11198:      	mov	w8, #0x4                // =4
   1119c:      	add	x9, sp, #0x98
   111a0:      	add	x0, sp, #0x98
   111a4:      	mov	w1, #0x8                // =8
   111a8:      	mov	x2, x23
   111ac:      	blr	x8
   111b0:      	ldr	x8, [sp, #0x98]
   111b4:      	cmp	x8, x21
   111b8:      	b.eq	0x11280 <generic_kprobe_path+0x77a0>
   111bc:      	mov	w8, #0x4                // =4
   111c0:      	add	x9, sp, #0x78
   111c4:      	add	x0, sp, #0x78
   111c8:      	mov	w1, #0x8                // =8
   111cc:      	mov	x2, x23
   111d0:      	blr	x8
   111d4:      	add	x2, x21, #0x20
   111d8:      	mov	w8, #0x4                // =4
   111dc:      	mov	w9, #0x10               // =16
   111e0:      	add	x10, sp, #0x80
   111e4:      	add	x0, sp, #0x80
   111e8:      	mov	w1, #0x10               // =16
   111ec:      	blr	x8
   111f0:      	ldr	w21, [sp, #0x84]
   111f4:      	ldr	x8, [sp, #0x40]
   111f8:      	ldr	x10, [sp, #0x60]
   111fc:      	sub	x12, x10, x8
   11200:      	ldr	w23, [sp, #0x68]
   11204:      	subs	w10, w21, w23
   11208:      	ldr	x9, [sp, #0x88]
   1120c:      	csel	w10, wzr, w10, lo
   11210:      	cmp	w23, w21
   11214:      	csel	w11, w23, w21, lo
   11218:      	cinc	w13, w11, hi
   1121c:      	sub	w14, w23, w13
   11220:      	subs	x12, x12, x13
   11224:      	str	w14, [sp, #0x68]
   11228:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   1122c:      	cmp	x12, #0xfff
   11230:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11234:      	cmp	w23, w21
   11238:      	b.ls	0x11244 <generic_kprobe_path+0x7764>
   1123c:      	mov	w13, #0x2f              // =47
   11240:      	strb	w13, [x8, x12]
   11244:      	add	x19, x8, x12
   11248:      	cmp	w23, w21
   1124c:      	add	x2, x9, x10
   11250:      	and	w1, w11, #0xff
   11254:      	mov	w8, #0x4                // =4
   11258:      	cinc	x0, x19, hi
   1125c:      	blr	x8
   11260:      	cmp	w23, w21
   11264:      	str	x19, [sp, #0x60]
   11268:      	add	x19, sp, #0x70
   1126c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11270:      	ldr	x21, [sp, #0x78]
   11274:      	ldp	x2, x24, [sp, #0x50]
   11278:      	str	x21, [sp, #0x48]
   1127c:      	b	0x112cc <generic_kprobe_path+0x77ec>
   11280:      	add	x2, x24, #0x10
   11284:      	mov	w8, #0x4                // =4
   11288:      	add	x9, sp, #0x98
   1128c:      	add	x0, sp, #0x98
   11290:      	mov	w1, #0x8                // =8
   11294:      	blr	x8
   11298:      	ldr	x8, [sp, #0x58]
   1129c:      	ldr	x9, [sp, #0x98]
   112a0:      	cmp	x8, x9
   112a4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   112a8:      	add	x2, x24, #0x18
   112ac:      	mov	w8, #0x4                // =4
   112b0:      	mov	x0, x22
   112b4:      	mov	w1, #0x8                // =8
   112b8:      	blr	x8
   112bc:      	ldr	x24, [sp, #0x98]
   112c0:      	ldr	x21, [sp, #0x48]
   112c4:      	add	x2, x24, #0x20
   112c8:      	stp	x2, x24, [sp, #0x50]
   112cc:      	ldr	x8, [sp, #0x30]
   112d0:      	cmp	x21, x8
   112d4:      	b.ne	0x112e4 <generic_kprobe_path+0x7804>
   112d8:      	ldr	x8, [sp, #0x38]
   112dc:      	cmp	x2, x8
   112e0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   112e4:      	mov	w8, #0x4                // =4
   112e8:      	add	x0, sp, #0x70
   112ec:      	mov	w1, #0x8                // =8
   112f0:      	blr	x8
   112f4:      	ldr	x8, [sp, #0x70]
   112f8:      	cmp	x21, x8
   112fc:      	b.eq	0x113ec <generic_kprobe_path+0x790c>
   11300:      	add	x23, x21, #0x18
   11304:      	mov	w8, #0x4                // =4
   11308:      	add	x9, sp, #0x98
   1130c:      	add	x0, sp, #0x98
   11310:      	mov	w1, #0x8                // =8
   11314:      	mov	x2, x23
   11318:      	blr	x8
   1131c:      	ldr	x8, [sp, #0x98]
   11320:      	cmp	x8, x21
   11324:      	b.eq	0x113ec <generic_kprobe_path+0x790c>
   11328:      	mov	w8, #0x4                // =4
   1132c:      	add	x9, sp, #0x78
   11330:      	add	x0, sp, #0x78
   11334:      	mov	w1, #0x8                // =8
   11338:      	mov	x2, x23
   1133c:      	blr	x8
   11340:      	add	x2, x21, #0x20
   11344:      	mov	w8, #0x4                // =4
   11348:      	mov	w9, #0x10               // =16
   1134c:      	add	x10, sp, #0x80
   11350:      	add	x0, sp, #0x80
   11354:      	mov	w1, #0x10               // =16
   11358:      	blr	x8
   1135c:      	ldr	w21, [sp, #0x84]
   11360:      	ldr	x8, [sp, #0x40]
   11364:      	ldr	x10, [sp, #0x60]
   11368:      	sub	x12, x10, x8
   1136c:      	ldr	w23, [sp, #0x68]
   11370:      	subs	w10, w21, w23
   11374:      	ldr	x9, [sp, #0x88]
   11378:      	csel	w10, wzr, w10, lo
   1137c:      	cmp	w23, w21
   11380:      	csel	w11, w23, w21, lo
   11384:      	cinc	w13, w11, hi
   11388:      	sub	w14, w23, w13
   1138c:      	subs	x12, x12, x13
   11390:      	str	w14, [sp, #0x68]
   11394:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11398:      	cmp	x12, #0xfff
   1139c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   113a0:      	cmp	w23, w21
   113a4:      	b.ls	0x113b0 <generic_kprobe_path+0x78d0>
   113a8:      	mov	w13, #0x2f              // =47
   113ac:      	strb	w13, [x8, x12]
   113b0:      	add	x19, x8, x12
   113b4:      	cmp	w23, w21
   113b8:      	add	x2, x9, x10
   113bc:      	and	w1, w11, #0xff
   113c0:      	mov	w8, #0x4                // =4
   113c4:      	cinc	x0, x19, hi
   113c8:      	blr	x8
   113cc:      	cmp	w23, w21
   113d0:      	str	x19, [sp, #0x60]
   113d4:      	add	x19, sp, #0x70
   113d8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   113dc:      	ldr	x21, [sp, #0x78]
   113e0:      	ldp	x2, x24, [sp, #0x50]
   113e4:      	str	x21, [sp, #0x48]
   113e8:      	b	0x11438 <generic_kprobe_path+0x7958>
   113ec:      	add	x2, x24, #0x10
   113f0:      	mov	w8, #0x4                // =4
   113f4:      	add	x9, sp, #0x98
   113f8:      	add	x0, sp, #0x98
   113fc:      	mov	w1, #0x8                // =8
   11400:      	blr	x8
   11404:      	ldr	x8, [sp, #0x58]
   11408:      	ldr	x9, [sp, #0x98]
   1140c:      	cmp	x8, x9
   11410:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11414:      	add	x2, x24, #0x18
   11418:      	mov	w8, #0x4                // =4
   1141c:      	mov	x0, x22
   11420:      	mov	w1, #0x8                // =8
   11424:      	blr	x8
   11428:      	ldr	x24, [sp, #0x98]
   1142c:      	ldr	x21, [sp, #0x48]
   11430:      	add	x2, x24, #0x20
   11434:      	stp	x2, x24, [sp, #0x50]
   11438:      	ldr	x8, [sp, #0x30]
   1143c:      	cmp	x21, x8
   11440:      	b.ne	0x11450 <generic_kprobe_path+0x7970>
   11444:      	ldr	x8, [sp, #0x38]
   11448:      	cmp	x2, x8
   1144c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11450:      	mov	w8, #0x4                // =4
   11454:      	add	x0, sp, #0x70
   11458:      	mov	w1, #0x8                // =8
   1145c:      	blr	x8
   11460:      	ldr	x8, [sp, #0x70]
   11464:      	cmp	x21, x8
   11468:      	b.eq	0x11558 <generic_kprobe_path+0x7a78>
   1146c:      	add	x23, x21, #0x18
   11470:      	mov	w8, #0x4                // =4
   11474:      	add	x9, sp, #0x98
   11478:      	add	x0, sp, #0x98
   1147c:      	mov	w1, #0x8                // =8
   11480:      	mov	x2, x23
   11484:      	blr	x8
   11488:      	ldr	x8, [sp, #0x98]
   1148c:      	cmp	x8, x21
   11490:      	b.eq	0x11558 <generic_kprobe_path+0x7a78>
   11494:      	mov	w8, #0x4                // =4
   11498:      	add	x9, sp, #0x78
   1149c:      	add	x0, sp, #0x78
   114a0:      	mov	w1, #0x8                // =8
   114a4:      	mov	x2, x23
   114a8:      	blr	x8
   114ac:      	add	x2, x21, #0x20
   114b0:      	mov	w8, #0x4                // =4
   114b4:      	mov	w9, #0x10               // =16
   114b8:      	add	x10, sp, #0x80
   114bc:      	add	x0, sp, #0x80
   114c0:      	mov	w1, #0x10               // =16
   114c4:      	blr	x8
   114c8:      	ldr	w21, [sp, #0x84]
   114cc:      	ldr	x8, [sp, #0x40]
   114d0:      	ldr	x10, [sp, #0x60]
   114d4:      	sub	x12, x10, x8
   114d8:      	ldr	w23, [sp, #0x68]
   114dc:      	subs	w10, w21, w23
   114e0:      	ldr	x9, [sp, #0x88]
   114e4:      	csel	w10, wzr, w10, lo
   114e8:      	cmp	w23, w21
   114ec:      	csel	w11, w23, w21, lo
   114f0:      	cinc	w13, w11, hi
   114f4:      	sub	w14, w23, w13
   114f8:      	subs	x12, x12, x13
   114fc:      	str	w14, [sp, #0x68]
   11500:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11504:      	cmp	x12, #0xfff
   11508:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   1150c:      	cmp	w23, w21
   11510:      	b.ls	0x1151c <generic_kprobe_path+0x7a3c>
   11514:      	mov	w13, #0x2f              // =47
   11518:      	strb	w13, [x8, x12]
   1151c:      	add	x19, x8, x12
   11520:      	cmp	w23, w21
   11524:      	add	x2, x9, x10
   11528:      	and	w1, w11, #0xff
   1152c:      	mov	w8, #0x4                // =4
   11530:      	cinc	x0, x19, hi
   11534:      	blr	x8
   11538:      	cmp	w23, w21
   1153c:      	str	x19, [sp, #0x60]
   11540:      	add	x19, sp, #0x70
   11544:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11548:      	ldr	x21, [sp, #0x78]
   1154c:      	ldp	x2, x24, [sp, #0x50]
   11550:      	str	x21, [sp, #0x48]
   11554:      	b	0x115a4 <generic_kprobe_path+0x7ac4>
   11558:      	add	x2, x24, #0x10
   1155c:      	mov	w8, #0x4                // =4
   11560:      	add	x9, sp, #0x98
   11564:      	add	x0, sp, #0x98
   11568:      	mov	w1, #0x8                // =8
   1156c:      	blr	x8
   11570:      	ldr	x8, [sp, #0x58]
   11574:      	ldr	x9, [sp, #0x98]
   11578:      	cmp	x8, x9
   1157c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11580:      	add	x2, x24, #0x18
   11584:      	mov	w8, #0x4                // =4
   11588:      	mov	x0, x22
   1158c:      	mov	w1, #0x8                // =8
   11590:      	blr	x8
   11594:      	ldr	x24, [sp, #0x98]
   11598:      	ldr	x21, [sp, #0x48]
   1159c:      	add	x2, x24, #0x20
   115a0:      	stp	x2, x24, [sp, #0x50]
   115a4:      	ldr	x8, [sp, #0x30]
   115a8:      	cmp	x21, x8
   115ac:      	b.ne	0x115bc <generic_kprobe_path+0x7adc>
   115b0:      	ldr	x8, [sp, #0x38]
   115b4:      	cmp	x2, x8
   115b8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   115bc:      	mov	w8, #0x4                // =4
   115c0:      	add	x0, sp, #0x70
   115c4:      	mov	w1, #0x8                // =8
   115c8:      	blr	x8
   115cc:      	ldr	x8, [sp, #0x70]
   115d0:      	cmp	x21, x8
   115d4:      	b.eq	0x116c4 <generic_kprobe_path+0x7be4>
   115d8:      	add	x23, x21, #0x18
   115dc:      	mov	w8, #0x4                // =4
   115e0:      	add	x9, sp, #0x98
   115e4:      	add	x0, sp, #0x98
   115e8:      	mov	w1, #0x8                // =8
   115ec:      	mov	x2, x23
   115f0:      	blr	x8
   115f4:      	ldr	x8, [sp, #0x98]
   115f8:      	cmp	x8, x21
   115fc:      	b.eq	0x116c4 <generic_kprobe_path+0x7be4>
   11600:      	mov	w8, #0x4                // =4
   11604:      	add	x9, sp, #0x78
   11608:      	add	x0, sp, #0x78
   1160c:      	mov	w1, #0x8                // =8
   11610:      	mov	x2, x23
   11614:      	blr	x8
   11618:      	add	x2, x21, #0x20
   1161c:      	mov	w8, #0x4                // =4
   11620:      	mov	w9, #0x10               // =16
   11624:      	add	x10, sp, #0x80
   11628:      	add	x0, sp, #0x80
   1162c:      	mov	w1, #0x10               // =16
   11630:      	blr	x8
   11634:      	ldr	w21, [sp, #0x84]
   11638:      	ldr	x8, [sp, #0x40]
   1163c:      	ldr	x10, [sp, #0x60]
   11640:      	sub	x12, x10, x8
   11644:      	ldr	w23, [sp, #0x68]
   11648:      	subs	w10, w21, w23
   1164c:      	ldr	x9, [sp, #0x88]
   11650:      	csel	w10, wzr, w10, lo
   11654:      	cmp	w23, w21
   11658:      	csel	w11, w23, w21, lo
   1165c:      	cinc	w13, w11, hi
   11660:      	sub	w14, w23, w13
   11664:      	subs	x12, x12, x13
   11668:      	str	w14, [sp, #0x68]
   1166c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11670:      	cmp	x12, #0xfff
   11674:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11678:      	cmp	w23, w21
   1167c:      	b.ls	0x11688 <generic_kprobe_path+0x7ba8>
   11680:      	mov	w13, #0x2f              // =47
   11684:      	strb	w13, [x8, x12]
   11688:      	add	x19, x8, x12
   1168c:      	cmp	w23, w21
   11690:      	add	x2, x9, x10
   11694:      	and	w1, w11, #0xff
   11698:      	mov	w8, #0x4                // =4
   1169c:      	cinc	x0, x19, hi
   116a0:      	blr	x8
   116a4:      	cmp	w23, w21
   116a8:      	str	x19, [sp, #0x60]
   116ac:      	add	x19, sp, #0x70
   116b0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   116b4:      	ldr	x21, [sp, #0x78]
   116b8:      	ldp	x2, x24, [sp, #0x50]
   116bc:      	str	x21, [sp, #0x48]
   116c0:      	b	0x11710 <generic_kprobe_path+0x7c30>
   116c4:      	add	x2, x24, #0x10
   116c8:      	mov	w8, #0x4                // =4
   116cc:      	add	x9, sp, #0x98
   116d0:      	add	x0, sp, #0x98
   116d4:      	mov	w1, #0x8                // =8
   116d8:      	blr	x8
   116dc:      	ldr	x8, [sp, #0x58]
   116e0:      	ldr	x9, [sp, #0x98]
   116e4:      	cmp	x8, x9
   116e8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   116ec:      	add	x2, x24, #0x18
   116f0:      	mov	w8, #0x4                // =4
   116f4:      	mov	x0, x22
   116f8:      	mov	w1, #0x8                // =8
   116fc:      	blr	x8
   11700:      	ldr	x24, [sp, #0x98]
   11704:      	ldr	x21, [sp, #0x48]
   11708:      	add	x2, x24, #0x20
   1170c:      	stp	x2, x24, [sp, #0x50]
   11710:      	ldr	x8, [sp, #0x30]
   11714:      	cmp	x21, x8
   11718:      	b.ne	0x11728 <generic_kprobe_path+0x7c48>
   1171c:      	ldr	x8, [sp, #0x38]
   11720:      	cmp	x2, x8
   11724:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11728:      	mov	w8, #0x4                // =4
   1172c:      	add	x0, sp, #0x70
   11730:      	mov	w1, #0x8                // =8
   11734:      	blr	x8
   11738:      	ldr	x8, [sp, #0x70]
   1173c:      	cmp	x21, x8
   11740:      	b.eq	0x11830 <generic_kprobe_path+0x7d50>
   11744:      	add	x23, x21, #0x18
   11748:      	mov	w8, #0x4                // =4
   1174c:      	add	x9, sp, #0x98
   11750:      	add	x0, sp, #0x98
   11754:      	mov	w1, #0x8                // =8
   11758:      	mov	x2, x23
   1175c:      	blr	x8
   11760:      	ldr	x8, [sp, #0x98]
   11764:      	cmp	x8, x21
   11768:      	b.eq	0x11830 <generic_kprobe_path+0x7d50>
   1176c:      	mov	w8, #0x4                // =4
   11770:      	add	x9, sp, #0x78
   11774:      	add	x0, sp, #0x78
   11778:      	mov	w1, #0x8                // =8
   1177c:      	mov	x2, x23
   11780:      	blr	x8
   11784:      	add	x2, x21, #0x20
   11788:      	mov	w8, #0x4                // =4
   1178c:      	mov	w9, #0x10               // =16
   11790:      	add	x10, sp, #0x80
   11794:      	add	x0, sp, #0x80
   11798:      	mov	w1, #0x10               // =16
   1179c:      	blr	x8
   117a0:      	ldr	w21, [sp, #0x84]
   117a4:      	ldr	x8, [sp, #0x40]
   117a8:      	ldr	x10, [sp, #0x60]
   117ac:      	sub	x12, x10, x8
   117b0:      	ldr	w23, [sp, #0x68]
   117b4:      	subs	w10, w21, w23
   117b8:      	ldr	x9, [sp, #0x88]
   117bc:      	csel	w10, wzr, w10, lo
   117c0:      	cmp	w23, w21
   117c4:      	csel	w11, w23, w21, lo
   117c8:      	cinc	w13, w11, hi
   117cc:      	sub	w14, w23, w13
   117d0:      	subs	x12, x12, x13
   117d4:      	str	w14, [sp, #0x68]
   117d8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   117dc:      	cmp	x12, #0xfff
   117e0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   117e4:      	cmp	w23, w21
   117e8:      	b.ls	0x117f4 <generic_kprobe_path+0x7d14>
   117ec:      	mov	w13, #0x2f              // =47
   117f0:      	strb	w13, [x8, x12]
   117f4:      	add	x19, x8, x12
   117f8:      	cmp	w23, w21
   117fc:      	add	x2, x9, x10
   11800:      	and	w1, w11, #0xff
   11804:      	mov	w8, #0x4                // =4
   11808:      	cinc	x0, x19, hi
   1180c:      	blr	x8
   11810:      	cmp	w23, w21
   11814:      	str	x19, [sp, #0x60]
   11818:      	add	x19, sp, #0x70
   1181c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11820:      	ldr	x21, [sp, #0x78]
   11824:      	ldp	x2, x24, [sp, #0x50]
   11828:      	str	x21, [sp, #0x48]
   1182c:      	b	0x1187c <generic_kprobe_path+0x7d9c>
   11830:      	add	x2, x24, #0x10
   11834:      	mov	w8, #0x4                // =4
   11838:      	add	x9, sp, #0x98
   1183c:      	add	x0, sp, #0x98
   11840:      	mov	w1, #0x8                // =8
   11844:      	blr	x8
   11848:      	ldr	x8, [sp, #0x58]
   1184c:      	ldr	x9, [sp, #0x98]
   11850:      	cmp	x8, x9
   11854:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11858:      	add	x2, x24, #0x18
   1185c:      	mov	w8, #0x4                // =4
   11860:      	mov	x0, x22
   11864:      	mov	w1, #0x8                // =8
   11868:      	blr	x8
   1186c:      	ldr	x24, [sp, #0x98]
   11870:      	ldr	x21, [sp, #0x48]
   11874:      	add	x2, x24, #0x20
   11878:      	stp	x2, x24, [sp, #0x50]
   1187c:      	ldr	x8, [sp, #0x30]
   11880:      	cmp	x21, x8
   11884:      	b.ne	0x11894 <generic_kprobe_path+0x7db4>
   11888:      	ldr	x8, [sp, #0x38]
   1188c:      	cmp	x2, x8
   11890:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11894:      	str	x25, [sp, #0x8]
   11898:      	mov	w8, #0x4                // =4
   1189c:      	add	x0, sp, #0x70
   118a0:      	mov	w1, #0x8                // =8
   118a4:      	blr	x8
   118a8:      	ldr	x8, [sp, #0x70]
   118ac:      	cmp	x21, x8
   118b0:      	b.eq	0x119a4 <generic_kprobe_path+0x7ec4>
   118b4:      	add	x23, x21, #0x18
   118b8:      	mov	w8, #0x4                // =4
   118bc:      	add	x9, sp, #0x98
   118c0:      	add	x0, sp, #0x98
   118c4:      	mov	w1, #0x8                // =8
   118c8:      	mov	x2, x23
   118cc:      	blr	x8
   118d0:      	ldr	x8, [sp, #0x98]
   118d4:      	cmp	x8, x21
   118d8:      	b.eq	0x119a4 <generic_kprobe_path+0x7ec4>
   118dc:      	mov	w8, #0x4                // =4
   118e0:      	add	x9, sp, #0x78
   118e4:      	add	x0, sp, #0x78
   118e8:      	mov	w1, #0x8                // =8
   118ec:      	mov	x2, x23
   118f0:      	blr	x8
   118f4:      	add	x2, x21, #0x20
   118f8:      	mov	w8, #0x4                // =4
   118fc:      	mov	w9, #0x10               // =16
   11900:      	add	x10, sp, #0x80
   11904:      	add	x0, sp, #0x80
   11908:      	mov	w1, #0x10               // =16
   1190c:      	blr	x8
   11910:      	ldr	w21, [sp, #0x84]
   11914:      	ldr	x8, [sp, #0x40]
   11918:      	ldr	x10, [sp, #0x60]
   1191c:      	sub	x12, x10, x8
   11920:      	ldr	w23, [sp, #0x68]
   11924:      	subs	w10, w21, w23
   11928:      	ldr	x9, [sp, #0x88]
   1192c:      	ldr	x25, [sp, #0x8]
   11930:      	csel	w10, wzr, w10, lo
   11934:      	cmp	w23, w21
   11938:      	csel	w11, w23, w21, lo
   1193c:      	cinc	w13, w11, hi
   11940:      	sub	w14, w23, w13
   11944:      	subs	x12, x12, x13
   11948:      	str	w14, [sp, #0x68]
   1194c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11950:      	cmp	x12, #0xfff
   11954:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11958:      	cmp	w23, w21
   1195c:      	b.ls	0x11968 <generic_kprobe_path+0x7e88>
   11960:      	mov	w13, #0x2f              // =47
   11964:      	strb	w13, [x8, x12]
   11968:      	add	x19, x8, x12
   1196c:      	cmp	w23, w21
   11970:      	add	x2, x9, x10
   11974:      	and	w1, w11, #0xff
   11978:      	mov	w8, #0x4                // =4
   1197c:      	cinc	x0, x19, hi
   11980:      	blr	x8
   11984:      	ldr	x25, [sp, #0x8]
   11988:      	cmp	w23, w21
   1198c:      	str	x19, [sp, #0x60]
   11990:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11994:      	ldr	x21, [sp, #0x78]
   11998:      	ldp	x2, x24, [sp, #0x50]
   1199c:      	str	x21, [sp, #0x48]
   119a0:      	b	0x119f4 <generic_kprobe_path+0x7f14>
   119a4:      	add	x2, x24, #0x10
   119a8:      	mov	w8, #0x4                // =4
   119ac:      	add	x9, sp, #0x98
   119b0:      	add	x0, sp, #0x98
   119b4:      	mov	w1, #0x8                // =8
   119b8:      	blr	x8
   119bc:      	ldr	x8, [sp, #0x58]
   119c0:      	ldr	x9, [sp, #0x98]
   119c4:      	cmp	x8, x9
   119c8:      	ldr	x25, [sp, #0x8]
   119cc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   119d0:      	add	x2, x24, #0x18
   119d4:      	mov	w8, #0x4                // =4
   119d8:      	mov	x0, x22
   119dc:      	mov	w1, #0x8                // =8
   119e0:      	blr	x8
   119e4:      	ldr	x24, [sp, #0x98]
   119e8:      	ldr	x21, [sp, #0x48]
   119ec:      	add	x2, x24, #0x20
   119f0:      	stp	x2, x24, [sp, #0x50]
   119f4:      	ldr	x8, [sp, #0x30]
   119f8:      	ldr	x25, [sp, #0x8]
   119fc:      	add	x9, sp, #0x70
   11a00:      	cmp	x21, x8
   11a04:      	b.ne	0x11a14 <generic_kprobe_path+0x7f34>
   11a08:      	ldr	x8, [sp, #0x38]
   11a0c:      	cmp	x2, x8
   11a10:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11a14:      	mov	w8, #0x4                // =4
   11a18:      	add	x0, sp, #0x70
   11a1c:      	mov	w1, #0x8                // =8
   11a20:      	blr	x8
   11a24:      	ldr	x8, [sp, #0x70]
   11a28:      	cmp	x21, x8
   11a2c:      	b.eq	0x11b20 <generic_kprobe_path+0x8040>
   11a30:      	add	x23, x21, #0x18
   11a34:      	mov	w8, #0x4                // =4
   11a38:      	add	x9, sp, #0x98
   11a3c:      	add	x0, sp, #0x98
   11a40:      	mov	w1, #0x8                // =8
   11a44:      	mov	x2, x23
   11a48:      	blr	x8
   11a4c:      	ldr	x8, [sp, #0x98]
   11a50:      	cmp	x8, x21
   11a54:      	b.eq	0x11b20 <generic_kprobe_path+0x8040>
   11a58:      	mov	w8, #0x4                // =4
   11a5c:      	add	x9, sp, #0x78
   11a60:      	add	x0, sp, #0x78
   11a64:      	mov	w1, #0x8                // =8
   11a68:      	mov	x2, x23
   11a6c:      	blr	x8
   11a70:      	add	x2, x21, #0x20
   11a74:      	mov	w8, #0x4                // =4
   11a78:      	mov	w9, #0x10               // =16
   11a7c:      	add	x10, sp, #0x80
   11a80:      	add	x0, sp, #0x80
   11a84:      	mov	w1, #0x10               // =16
   11a88:      	blr	x8
   11a8c:      	ldr	w21, [sp, #0x84]
   11a90:      	ldr	x8, [sp, #0x40]
   11a94:      	ldr	x10, [sp, #0x60]
   11a98:      	sub	x12, x10, x8
   11a9c:      	ldr	w23, [sp, #0x68]
   11aa0:      	subs	w10, w21, w23
   11aa4:      	ldr	x9, [sp, #0x88]
   11aa8:      	ldr	x25, [sp, #0x8]
   11aac:      	csel	w10, wzr, w10, lo
   11ab0:      	cmp	w23, w21
   11ab4:      	csel	w11, w23, w21, lo
   11ab8:      	cinc	w13, w11, hi
   11abc:      	sub	w14, w23, w13
   11ac0:      	subs	x12, x12, x13
   11ac4:      	str	w14, [sp, #0x68]
   11ac8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11acc:      	cmp	x12, #0xfff
   11ad0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11ad4:      	cmp	w23, w21
   11ad8:      	b.ls	0x11ae4 <generic_kprobe_path+0x8004>
   11adc:      	mov	w13, #0x2f              // =47
   11ae0:      	strb	w13, [x8, x12]
   11ae4:      	add	x19, x8, x12
   11ae8:      	cmp	w23, w21
   11aec:      	add	x2, x9, x10
   11af0:      	and	w1, w11, #0xff
   11af4:      	mov	w8, #0x4                // =4
   11af8:      	cinc	x0, x19, hi
   11afc:      	blr	x8
   11b00:      	ldr	x25, [sp, #0x8]
   11b04:      	cmp	w23, w21
   11b08:      	str	x19, [sp, #0x60]
   11b0c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11b10:      	ldr	x21, [sp, #0x78]
   11b14:      	ldp	x2, x24, [sp, #0x50]
   11b18:      	str	x21, [sp, #0x48]
   11b1c:      	b	0x11b70 <generic_kprobe_path+0x8090>
   11b20:      	add	x2, x24, #0x10
   11b24:      	mov	w8, #0x4                // =4
   11b28:      	add	x9, sp, #0x98
   11b2c:      	add	x0, sp, #0x98
   11b30:      	mov	w1, #0x8                // =8
   11b34:      	blr	x8
   11b38:      	ldr	x8, [sp, #0x58]
   11b3c:      	ldr	x9, [sp, #0x98]
   11b40:      	cmp	x8, x9
   11b44:      	ldr	x25, [sp, #0x8]
   11b48:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11b4c:      	add	x2, x24, #0x18
   11b50:      	mov	w8, #0x4                // =4
   11b54:      	mov	x0, x22
   11b58:      	mov	w1, #0x8                // =8
   11b5c:      	blr	x8
   11b60:      	ldr	x24, [sp, #0x98]
   11b64:      	ldr	x21, [sp, #0x48]
   11b68:      	add	x2, x24, #0x20
   11b6c:      	stp	x2, x24, [sp, #0x50]
   11b70:      	ldr	x8, [sp, #0x30]
   11b74:      	ldr	x25, [sp, #0x8]
   11b78:      	add	x9, sp, #0x70
   11b7c:      	cmp	x21, x8
   11b80:      	b.ne	0x11b90 <generic_kprobe_path+0x80b0>
   11b84:      	ldr	x8, [sp, #0x38]
   11b88:      	cmp	x2, x8
   11b8c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11b90:      	mov	w8, #0x4                // =4
   11b94:      	add	x0, sp, #0x70
   11b98:      	mov	w1, #0x8                // =8
   11b9c:      	blr	x8
   11ba0:      	ldr	x8, [sp, #0x70]
   11ba4:      	cmp	x21, x8
   11ba8:      	b.eq	0x11c9c <generic_kprobe_path+0x81bc>
   11bac:      	add	x23, x21, #0x18
   11bb0:      	mov	w8, #0x4                // =4
   11bb4:      	add	x9, sp, #0x98
   11bb8:      	add	x0, sp, #0x98
   11bbc:      	mov	w1, #0x8                // =8
   11bc0:      	mov	x2, x23
   11bc4:      	blr	x8
   11bc8:      	ldr	x8, [sp, #0x98]
   11bcc:      	cmp	x8, x21
   11bd0:      	b.eq	0x11c9c <generic_kprobe_path+0x81bc>
   11bd4:      	mov	w8, #0x4                // =4
   11bd8:      	add	x9, sp, #0x78
   11bdc:      	add	x0, sp, #0x78
   11be0:      	mov	w1, #0x8                // =8
   11be4:      	mov	x2, x23
   11be8:      	blr	x8
   11bec:      	add	x2, x21, #0x20
   11bf0:      	mov	w8, #0x4                // =4
   11bf4:      	mov	w9, #0x10               // =16
   11bf8:      	add	x10, sp, #0x80
   11bfc:      	add	x0, sp, #0x80
   11c00:      	mov	w1, #0x10               // =16
   11c04:      	blr	x8
   11c08:      	ldr	w21, [sp, #0x84]
   11c0c:      	ldr	x8, [sp, #0x40]
   11c10:      	ldr	x10, [sp, #0x60]
   11c14:      	sub	x12, x10, x8
   11c18:      	ldr	w23, [sp, #0x68]
   11c1c:      	subs	w10, w21, w23
   11c20:      	ldr	x9, [sp, #0x88]
   11c24:      	ldr	x25, [sp, #0x8]
   11c28:      	csel	w10, wzr, w10, lo
   11c2c:      	cmp	w23, w21
   11c30:      	csel	w11, w23, w21, lo
   11c34:      	cinc	w13, w11, hi
   11c38:      	sub	w14, w23, w13
   11c3c:      	subs	x12, x12, x13
   11c40:      	str	w14, [sp, #0x68]
   11c44:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11c48:      	cmp	x12, #0xfff
   11c4c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11c50:      	cmp	w23, w21
   11c54:      	b.ls	0x11c60 <generic_kprobe_path+0x8180>
   11c58:      	mov	w13, #0x2f              // =47
   11c5c:      	strb	w13, [x8, x12]
   11c60:      	add	x19, x8, x12
   11c64:      	cmp	w23, w21
   11c68:      	add	x2, x9, x10
   11c6c:      	and	w1, w11, #0xff
   11c70:      	mov	w8, #0x4                // =4
   11c74:      	cinc	x0, x19, hi
   11c78:      	blr	x8
   11c7c:      	ldr	x25, [sp, #0x8]
   11c80:      	cmp	w23, w21
   11c84:      	str	x19, [sp, #0x60]
   11c88:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11c8c:      	ldr	x21, [sp, #0x78]
   11c90:      	ldp	x2, x24, [sp, #0x50]
   11c94:      	str	x21, [sp, #0x48]
   11c98:      	b	0x11cec <generic_kprobe_path+0x820c>
   11c9c:      	add	x2, x24, #0x10
   11ca0:      	mov	w8, #0x4                // =4
   11ca4:      	add	x9, sp, #0x98
   11ca8:      	add	x0, sp, #0x98
   11cac:      	mov	w1, #0x8                // =8
   11cb0:      	blr	x8
   11cb4:      	ldr	x8, [sp, #0x58]
   11cb8:      	ldr	x9, [sp, #0x98]
   11cbc:      	cmp	x8, x9
   11cc0:      	ldr	x25, [sp, #0x8]
   11cc4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11cc8:      	add	x2, x24, #0x18
   11ccc:      	mov	w8, #0x4                // =4
   11cd0:      	mov	x0, x22
   11cd4:      	mov	w1, #0x8                // =8
   11cd8:      	blr	x8
   11cdc:      	ldr	x24, [sp, #0x98]
   11ce0:      	ldr	x21, [sp, #0x48]
   11ce4:      	add	x2, x24, #0x20
   11ce8:      	stp	x2, x24, [sp, #0x50]
   11cec:      	ldr	x8, [sp, #0x30]
   11cf0:      	ldr	x25, [sp, #0x8]
   11cf4:      	add	x9, sp, #0x70
   11cf8:      	cmp	x21, x8
   11cfc:      	b.ne	0x11d0c <generic_kprobe_path+0x822c>
   11d00:      	ldr	x8, [sp, #0x38]
   11d04:      	cmp	x2, x8
   11d08:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11d0c:      	mov	w8, #0x4                // =4
   11d10:      	add	x0, sp, #0x70
   11d14:      	mov	w1, #0x8                // =8
   11d18:      	blr	x8
   11d1c:      	ldr	x8, [sp, #0x70]
   11d20:      	cmp	x21, x8
   11d24:      	b.eq	0x11e18 <generic_kprobe_path+0x8338>
   11d28:      	add	x23, x21, #0x18
   11d2c:      	mov	w8, #0x4                // =4
   11d30:      	add	x9, sp, #0x98
   11d34:      	add	x0, sp, #0x98
   11d38:      	mov	w1, #0x8                // =8
   11d3c:      	mov	x2, x23
   11d40:      	blr	x8
   11d44:      	ldr	x8, [sp, #0x98]
   11d48:      	cmp	x8, x21
   11d4c:      	b.eq	0x11e18 <generic_kprobe_path+0x8338>
   11d50:      	mov	w8, #0x4                // =4
   11d54:      	add	x9, sp, #0x78
   11d58:      	add	x0, sp, #0x78
   11d5c:      	mov	w1, #0x8                // =8
   11d60:      	mov	x2, x23
   11d64:      	blr	x8
   11d68:      	add	x2, x21, #0x20
   11d6c:      	mov	w8, #0x4                // =4
   11d70:      	mov	w9, #0x10               // =16
   11d74:      	add	x10, sp, #0x80
   11d78:      	add	x0, sp, #0x80
   11d7c:      	mov	w1, #0x10               // =16
   11d80:      	blr	x8
   11d84:      	ldr	w21, [sp, #0x84]
   11d88:      	ldr	x8, [sp, #0x40]
   11d8c:      	ldr	x10, [sp, #0x60]
   11d90:      	sub	x12, x10, x8
   11d94:      	ldr	w23, [sp, #0x68]
   11d98:      	subs	w10, w21, w23
   11d9c:      	ldr	x9, [sp, #0x88]
   11da0:      	ldr	x25, [sp, #0x8]
   11da4:      	csel	w10, wzr, w10, lo
   11da8:      	cmp	w23, w21
   11dac:      	csel	w11, w23, w21, lo
   11db0:      	cinc	w13, w11, hi
   11db4:      	sub	w14, w23, w13
   11db8:      	subs	x12, x12, x13
   11dbc:      	str	w14, [sp, #0x68]
   11dc0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11dc4:      	cmp	x12, #0xfff
   11dc8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11dcc:      	cmp	w23, w21
   11dd0:      	b.ls	0x11ddc <generic_kprobe_path+0x82fc>
   11dd4:      	mov	w13, #0x2f              // =47
   11dd8:      	strb	w13, [x8, x12]
   11ddc:      	add	x19, x8, x12
   11de0:      	cmp	w23, w21
   11de4:      	add	x2, x9, x10
   11de8:      	and	w1, w11, #0xff
   11dec:      	mov	w8, #0x4                // =4
   11df0:      	cinc	x0, x19, hi
   11df4:      	blr	x8
   11df8:      	ldr	x25, [sp, #0x8]
   11dfc:      	cmp	w23, w21
   11e00:      	str	x19, [sp, #0x60]
   11e04:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11e08:      	ldr	x21, [sp, #0x78]
   11e0c:      	ldp	x2, x24, [sp, #0x50]
   11e10:      	str	x21, [sp, #0x48]
   11e14:      	b	0x11e68 <generic_kprobe_path+0x8388>
   11e18:      	add	x2, x24, #0x10
   11e1c:      	mov	w8, #0x4                // =4
   11e20:      	add	x9, sp, #0x98
   11e24:      	add	x0, sp, #0x98
   11e28:      	mov	w1, #0x8                // =8
   11e2c:      	blr	x8
   11e30:      	ldr	x8, [sp, #0x58]
   11e34:      	ldr	x9, [sp, #0x98]
   11e38:      	cmp	x8, x9
   11e3c:      	ldr	x25, [sp, #0x8]
   11e40:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11e44:      	add	x2, x24, #0x18
   11e48:      	mov	w8, #0x4                // =4
   11e4c:      	mov	x0, x22
   11e50:      	mov	w1, #0x8                // =8
   11e54:      	blr	x8
   11e58:      	ldr	x24, [sp, #0x98]
   11e5c:      	ldr	x21, [sp, #0x48]
   11e60:      	add	x2, x24, #0x20
   11e64:      	stp	x2, x24, [sp, #0x50]
   11e68:      	ldr	x8, [sp, #0x30]
   11e6c:      	ldr	x25, [sp, #0x8]
   11e70:      	add	x9, sp, #0x70
   11e74:      	cmp	x21, x8
   11e78:      	b.ne	0x11e88 <generic_kprobe_path+0x83a8>
   11e7c:      	ldr	x8, [sp, #0x38]
   11e80:      	cmp	x2, x8
   11e84:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11e88:      	mov	w8, #0x4                // =4
   11e8c:      	add	x0, sp, #0x70
   11e90:      	mov	w1, #0x8                // =8
   11e94:      	blr	x8
   11e98:      	ldr	x8, [sp, #0x70]
   11e9c:      	cmp	x21, x8
   11ea0:      	b.eq	0x11f94 <generic_kprobe_path+0x84b4>
   11ea4:      	add	x23, x21, #0x18
   11ea8:      	mov	w8, #0x4                // =4
   11eac:      	add	x9, sp, #0x98
   11eb0:      	add	x0, sp, #0x98
   11eb4:      	mov	w1, #0x8                // =8
   11eb8:      	mov	x2, x23
   11ebc:      	blr	x8
   11ec0:      	ldr	x8, [sp, #0x98]
   11ec4:      	cmp	x8, x21
   11ec8:      	b.eq	0x11f94 <generic_kprobe_path+0x84b4>
   11ecc:      	mov	w8, #0x4                // =4
   11ed0:      	add	x9, sp, #0x78
   11ed4:      	add	x0, sp, #0x78
   11ed8:      	mov	w1, #0x8                // =8
   11edc:      	mov	x2, x23
   11ee0:      	blr	x8
   11ee4:      	add	x2, x21, #0x20
   11ee8:      	mov	w8, #0x4                // =4
   11eec:      	mov	w9, #0x10               // =16
   11ef0:      	add	x10, sp, #0x80
   11ef4:      	add	x0, sp, #0x80
   11ef8:      	mov	w1, #0x10               // =16
   11efc:      	blr	x8
   11f00:      	ldr	w21, [sp, #0x84]
   11f04:      	ldr	x8, [sp, #0x40]
   11f08:      	ldr	x10, [sp, #0x60]
   11f0c:      	sub	x12, x10, x8
   11f10:      	ldr	w23, [sp, #0x68]
   11f14:      	subs	w10, w21, w23
   11f18:      	ldr	x9, [sp, #0x88]
   11f1c:      	ldr	x25, [sp, #0x8]
   11f20:      	csel	w10, wzr, w10, lo
   11f24:      	cmp	w23, w21
   11f28:      	csel	w11, w23, w21, lo
   11f2c:      	cinc	w13, w11, hi
   11f30:      	sub	w14, w23, w13
   11f34:      	subs	x12, x12, x13
   11f38:      	str	w14, [sp, #0x68]
   11f3c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   11f40:      	cmp	x12, #0xfff
   11f44:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   11f48:      	cmp	w23, w21
   11f4c:      	b.ls	0x11f58 <generic_kprobe_path+0x8478>
   11f50:      	mov	w13, #0x2f              // =47
   11f54:      	strb	w13, [x8, x12]
   11f58:      	add	x19, x8, x12
   11f5c:      	cmp	w23, w21
   11f60:      	add	x2, x9, x10
   11f64:      	and	w1, w11, #0xff
   11f68:      	mov	w8, #0x4                // =4
   11f6c:      	cinc	x0, x19, hi
   11f70:      	blr	x8
   11f74:      	ldr	x25, [sp, #0x8]
   11f78:      	cmp	w23, w21
   11f7c:      	str	x19, [sp, #0x60]
   11f80:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   11f84:      	ldr	x21, [sp, #0x78]
   11f88:      	ldp	x2, x24, [sp, #0x50]
   11f8c:      	str	x21, [sp, #0x48]
   11f90:      	b	0x11fe4 <generic_kprobe_path+0x8504>
   11f94:      	add	x2, x24, #0x10
   11f98:      	mov	w8, #0x4                // =4
   11f9c:      	add	x9, sp, #0x98
   11fa0:      	add	x0, sp, #0x98
   11fa4:      	mov	w1, #0x8                // =8
   11fa8:      	blr	x8
   11fac:      	ldr	x8, [sp, #0x58]
   11fb0:      	ldr	x9, [sp, #0x98]
   11fb4:      	cmp	x8, x9
   11fb8:      	ldr	x25, [sp, #0x8]
   11fbc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   11fc0:      	add	x2, x24, #0x18
   11fc4:      	mov	w8, #0x4                // =4
   11fc8:      	mov	x0, x22
   11fcc:      	mov	w1, #0x8                // =8
   11fd0:      	blr	x8
   11fd4:      	ldr	x24, [sp, #0x98]
   11fd8:      	ldr	x21, [sp, #0x48]
   11fdc:      	add	x2, x24, #0x20
   11fe0:      	stp	x2, x24, [sp, #0x50]
   11fe4:      	ldr	x8, [sp, #0x30]
   11fe8:      	ldr	x25, [sp, #0x8]
   11fec:      	add	x9, sp, #0x70
   11ff0:      	cmp	x21, x8
   11ff4:      	b.ne	0x12004 <generic_kprobe_path+0x8524>
   11ff8:      	ldr	x8, [sp, #0x38]
   11ffc:      	cmp	x2, x8
   12000:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12004:      	mov	w8, #0x4                // =4
   12008:      	add	x0, sp, #0x70
   1200c:      	mov	w1, #0x8                // =8
   12010:      	blr	x8
   12014:      	ldr	x8, [sp, #0x70]
   12018:      	cmp	x21, x8
   1201c:      	b.eq	0x12110 <generic_kprobe_path+0x8630>
   12020:      	add	x23, x21, #0x18
   12024:      	mov	w8, #0x4                // =4
   12028:      	add	x9, sp, #0x98
   1202c:      	add	x0, sp, #0x98
   12030:      	mov	w1, #0x8                // =8
   12034:      	mov	x2, x23
   12038:      	blr	x8
   1203c:      	ldr	x8, [sp, #0x98]
   12040:      	cmp	x8, x21
   12044:      	b.eq	0x12110 <generic_kprobe_path+0x8630>
   12048:      	mov	w8, #0x4                // =4
   1204c:      	add	x9, sp, #0x78
   12050:      	add	x0, sp, #0x78
   12054:      	mov	w1, #0x8                // =8
   12058:      	mov	x2, x23
   1205c:      	blr	x8
   12060:      	add	x2, x21, #0x20
   12064:      	mov	w8, #0x4                // =4
   12068:      	mov	w9, #0x10               // =16
   1206c:      	add	x10, sp, #0x80
   12070:      	add	x0, sp, #0x80
   12074:      	mov	w1, #0x10               // =16
   12078:      	blr	x8
   1207c:      	ldr	w21, [sp, #0x84]
   12080:      	ldr	x8, [sp, #0x40]
   12084:      	ldr	x10, [sp, #0x60]
   12088:      	sub	x12, x10, x8
   1208c:      	ldr	w23, [sp, #0x68]
   12090:      	subs	w10, w21, w23
   12094:      	ldr	x9, [sp, #0x88]
   12098:      	ldr	x25, [sp, #0x8]
   1209c:      	csel	w10, wzr, w10, lo
   120a0:      	cmp	w23, w21
   120a4:      	csel	w11, w23, w21, lo
   120a8:      	cinc	w13, w11, hi
   120ac:      	sub	w14, w23, w13
   120b0:      	subs	x12, x12, x13
   120b4:      	str	w14, [sp, #0x68]
   120b8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   120bc:      	cmp	x12, #0xfff
   120c0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   120c4:      	cmp	w23, w21
   120c8:      	b.ls	0x120d4 <generic_kprobe_path+0x85f4>
   120cc:      	mov	w13, #0x2f              // =47
   120d0:      	strb	w13, [x8, x12]
   120d4:      	add	x19, x8, x12
   120d8:      	cmp	w23, w21
   120dc:      	add	x2, x9, x10
   120e0:      	and	w1, w11, #0xff
   120e4:      	mov	w8, #0x4                // =4
   120e8:      	cinc	x0, x19, hi
   120ec:      	blr	x8
   120f0:      	ldr	x25, [sp, #0x8]
   120f4:      	cmp	w23, w21
   120f8:      	str	x19, [sp, #0x60]
   120fc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   12100:      	ldr	x21, [sp, #0x78]
   12104:      	ldp	x2, x24, [sp, #0x50]
   12108:      	str	x21, [sp, #0x48]
   1210c:      	b	0x12160 <generic_kprobe_path+0x8680>
   12110:      	add	x2, x24, #0x10
   12114:      	mov	w8, #0x4                // =4
   12118:      	add	x9, sp, #0x98
   1211c:      	add	x0, sp, #0x98
   12120:      	mov	w1, #0x8                // =8
   12124:      	blr	x8
   12128:      	ldr	x8, [sp, #0x58]
   1212c:      	ldr	x9, [sp, #0x98]
   12130:      	cmp	x8, x9
   12134:      	ldr	x25, [sp, #0x8]
   12138:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1213c:      	add	x2, x24, #0x18
   12140:      	mov	w8, #0x4                // =4
   12144:      	mov	x0, x22
   12148:      	mov	w1, #0x8                // =8
   1214c:      	blr	x8
   12150:      	ldr	x24, [sp, #0x98]
   12154:      	ldr	x21, [sp, #0x48]
   12158:      	add	x2, x24, #0x20
   1215c:      	stp	x2, x24, [sp, #0x50]
   12160:      	ldr	x8, [sp, #0x30]
   12164:      	ldr	x25, [sp, #0x8]
   12168:      	add	x9, sp, #0x70
   1216c:      	cmp	x21, x8
   12170:      	b.ne	0x12180 <generic_kprobe_path+0x86a0>
   12174:      	ldr	x8, [sp, #0x38]
   12178:      	cmp	x2, x8
   1217c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12180:      	mov	w8, #0x4                // =4
   12184:      	add	x0, sp, #0x70
   12188:      	mov	w1, #0x8                // =8
   1218c:      	blr	x8
   12190:      	ldr	x8, [sp, #0x70]
   12194:      	cmp	x21, x8
   12198:      	b.eq	0x1228c <generic_kprobe_path+0x87ac>
   1219c:      	add	x23, x21, #0x18
   121a0:      	mov	w8, #0x4                // =4
   121a4:      	add	x9, sp, #0x98
   121a8:      	add	x0, sp, #0x98
   121ac:      	mov	w1, #0x8                // =8
   121b0:      	mov	x2, x23
   121b4:      	blr	x8
   121b8:      	ldr	x8, [sp, #0x98]
   121bc:      	cmp	x8, x21
   121c0:      	b.eq	0x1228c <generic_kprobe_path+0x87ac>
   121c4:      	mov	w8, #0x4                // =4
   121c8:      	add	x9, sp, #0x78
   121cc:      	add	x0, sp, #0x78
   121d0:      	mov	w1, #0x8                // =8
   121d4:      	mov	x2, x23
   121d8:      	blr	x8
   121dc:      	add	x2, x21, #0x20
   121e0:      	mov	w8, #0x4                // =4
   121e4:      	mov	w9, #0x10               // =16
   121e8:      	add	x10, sp, #0x80
   121ec:      	add	x0, sp, #0x80
   121f0:      	mov	w1, #0x10               // =16
   121f4:      	blr	x8
   121f8:      	ldr	w21, [sp, #0x84]
   121fc:      	ldr	x8, [sp, #0x40]
   12200:      	ldr	x10, [sp, #0x60]
   12204:      	sub	x12, x10, x8
   12208:      	ldr	w23, [sp, #0x68]
   1220c:      	subs	w10, w21, w23
   12210:      	ldr	x9, [sp, #0x88]
   12214:      	ldr	x25, [sp, #0x8]
   12218:      	csel	w10, wzr, w10, lo
   1221c:      	cmp	w23, w21
   12220:      	csel	w11, w23, w21, lo
   12224:      	cinc	w13, w11, hi
   12228:      	sub	w14, w23, w13
   1222c:      	subs	x12, x12, x13
   12230:      	str	w14, [sp, #0x68]
   12234:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12238:      	cmp	x12, #0xfff
   1223c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12240:      	cmp	w23, w21
   12244:      	b.ls	0x12250 <generic_kprobe_path+0x8770>
   12248:      	mov	w13, #0x2f              // =47
   1224c:      	strb	w13, [x8, x12]
   12250:      	add	x19, x8, x12
   12254:      	cmp	w23, w21
   12258:      	add	x2, x9, x10
   1225c:      	and	w1, w11, #0xff
   12260:      	mov	w8, #0x4                // =4
   12264:      	cinc	x0, x19, hi
   12268:      	blr	x8
   1226c:      	ldr	x25, [sp, #0x8]
   12270:      	cmp	w23, w21
   12274:      	str	x19, [sp, #0x60]
   12278:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   1227c:      	ldr	x21, [sp, #0x78]
   12280:      	ldp	x2, x24, [sp, #0x50]
   12284:      	str	x21, [sp, #0x48]
   12288:      	b	0x122dc <generic_kprobe_path+0x87fc>
   1228c:      	add	x2, x24, #0x10
   12290:      	mov	w8, #0x4                // =4
   12294:      	add	x9, sp, #0x98
   12298:      	add	x0, sp, #0x98
   1229c:      	mov	w1, #0x8                // =8
   122a0:      	blr	x8
   122a4:      	ldr	x8, [sp, #0x58]
   122a8:      	ldr	x9, [sp, #0x98]
   122ac:      	cmp	x8, x9
   122b0:      	ldr	x25, [sp, #0x8]
   122b4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   122b8:      	add	x2, x24, #0x18
   122bc:      	mov	w8, #0x4                // =4
   122c0:      	mov	x0, x22
   122c4:      	mov	w1, #0x8                // =8
   122c8:      	blr	x8
   122cc:      	ldr	x24, [sp, #0x98]
   122d0:      	ldr	x21, [sp, #0x48]
   122d4:      	add	x2, x24, #0x20
   122d8:      	stp	x2, x24, [sp, #0x50]
   122dc:      	ldr	x8, [sp, #0x30]
   122e0:      	ldr	x25, [sp, #0x8]
   122e4:      	add	x9, sp, #0x70
   122e8:      	cmp	x21, x8
   122ec:      	b.ne	0x122fc <generic_kprobe_path+0x881c>
   122f0:      	ldr	x8, [sp, #0x38]
   122f4:      	cmp	x2, x8
   122f8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   122fc:      	mov	w8, #0x4                // =4
   12300:      	add	x0, sp, #0x70
   12304:      	mov	w1, #0x8                // =8
   12308:      	blr	x8
   1230c:      	ldr	x8, [sp, #0x70]
   12310:      	cmp	x21, x8
   12314:      	b.eq	0x12408 <generic_kprobe_path+0x8928>
   12318:      	add	x23, x21, #0x18
   1231c:      	mov	w8, #0x4                // =4
   12320:      	add	x9, sp, #0x98
   12324:      	add	x0, sp, #0x98
   12328:      	mov	w1, #0x8                // =8
   1232c:      	mov	x2, x23
   12330:      	blr	x8
   12334:      	ldr	x8, [sp, #0x98]
   12338:      	cmp	x8, x21
   1233c:      	b.eq	0x12408 <generic_kprobe_path+0x8928>
   12340:      	mov	w8, #0x4                // =4
   12344:      	add	x9, sp, #0x78
   12348:      	add	x0, sp, #0x78
   1234c:      	mov	w1, #0x8                // =8
   12350:      	mov	x2, x23
   12354:      	blr	x8
   12358:      	add	x2, x21, #0x20
   1235c:      	mov	w8, #0x4                // =4
   12360:      	mov	w9, #0x10               // =16
   12364:      	add	x10, sp, #0x80
   12368:      	add	x0, sp, #0x80
   1236c:      	mov	w1, #0x10               // =16
   12370:      	blr	x8
   12374:      	ldr	w21, [sp, #0x84]
   12378:      	ldr	x8, [sp, #0x40]
   1237c:      	ldr	x10, [sp, #0x60]
   12380:      	sub	x12, x10, x8
   12384:      	ldr	w23, [sp, #0x68]
   12388:      	subs	w10, w21, w23
   1238c:      	ldr	x9, [sp, #0x88]
   12390:      	ldr	x25, [sp, #0x8]
   12394:      	csel	w10, wzr, w10, lo
   12398:      	cmp	w23, w21
   1239c:      	csel	w11, w23, w21, lo
   123a0:      	cinc	w13, w11, hi
   123a4:      	sub	w14, w23, w13
   123a8:      	subs	x12, x12, x13
   123ac:      	str	w14, [sp, #0x68]
   123b0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   123b4:      	cmp	x12, #0xfff
   123b8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   123bc:      	cmp	w23, w21
   123c0:      	b.ls	0x123cc <generic_kprobe_path+0x88ec>
   123c4:      	mov	w13, #0x2f              // =47
   123c8:      	strb	w13, [x8, x12]
   123cc:      	add	x19, x8, x12
   123d0:      	cmp	w23, w21
   123d4:      	add	x2, x9, x10
   123d8:      	and	w1, w11, #0xff
   123dc:      	mov	w8, #0x4                // =4
   123e0:      	cinc	x0, x19, hi
   123e4:      	blr	x8
   123e8:      	ldr	x25, [sp, #0x8]
   123ec:      	cmp	w23, w21
   123f0:      	str	x19, [sp, #0x60]
   123f4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   123f8:      	ldr	x21, [sp, #0x78]
   123fc:      	ldp	x2, x24, [sp, #0x50]
   12400:      	str	x21, [sp, #0x48]
   12404:      	b	0x12458 <generic_kprobe_path+0x8978>
   12408:      	add	x2, x24, #0x10
   1240c:      	mov	w8, #0x4                // =4
   12410:      	add	x9, sp, #0x98
   12414:      	add	x0, sp, #0x98
   12418:      	mov	w1, #0x8                // =8
   1241c:      	blr	x8
   12420:      	ldr	x8, [sp, #0x58]
   12424:      	ldr	x9, [sp, #0x98]
   12428:      	cmp	x8, x9
   1242c:      	ldr	x25, [sp, #0x8]
   12430:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12434:      	add	x2, x24, #0x18
   12438:      	mov	w8, #0x4                // =4
   1243c:      	mov	x0, x22
   12440:      	mov	w1, #0x8                // =8
   12444:      	blr	x8
   12448:      	ldr	x24, [sp, #0x98]
   1244c:      	ldr	x21, [sp, #0x48]
   12450:      	add	x2, x24, #0x20
   12454:      	stp	x2, x24, [sp, #0x50]
   12458:      	ldr	x8, [sp, #0x30]
   1245c:      	ldr	x25, [sp, #0x8]
   12460:      	add	x9, sp, #0x70
   12464:      	cmp	x21, x8
   12468:      	b.ne	0x12478 <generic_kprobe_path+0x8998>
   1246c:      	ldr	x8, [sp, #0x38]
   12470:      	cmp	x2, x8
   12474:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12478:      	mov	w8, #0x4                // =4
   1247c:      	add	x0, sp, #0x70
   12480:      	mov	w1, #0x8                // =8
   12484:      	blr	x8
   12488:      	ldr	x8, [sp, #0x70]
   1248c:      	cmp	x21, x8
   12490:      	b.eq	0x12584 <generic_kprobe_path+0x8aa4>
   12494:      	add	x23, x21, #0x18
   12498:      	mov	w8, #0x4                // =4
   1249c:      	add	x9, sp, #0x98
   124a0:      	add	x0, sp, #0x98
   124a4:      	mov	w1, #0x8                // =8
   124a8:      	mov	x2, x23
   124ac:      	blr	x8
   124b0:      	ldr	x8, [sp, #0x98]
   124b4:      	cmp	x8, x21
   124b8:      	b.eq	0x12584 <generic_kprobe_path+0x8aa4>
   124bc:      	mov	w8, #0x4                // =4
   124c0:      	add	x9, sp, #0x78
   124c4:      	add	x0, sp, #0x78
   124c8:      	mov	w1, #0x8                // =8
   124cc:      	mov	x2, x23
   124d0:      	blr	x8
   124d4:      	add	x2, x21, #0x20
   124d8:      	mov	w8, #0x4                // =4
   124dc:      	mov	w9, #0x10               // =16
   124e0:      	add	x10, sp, #0x80
   124e4:      	add	x0, sp, #0x80
   124e8:      	mov	w1, #0x10               // =16
   124ec:      	blr	x8
   124f0:      	ldr	w21, [sp, #0x84]
   124f4:      	ldr	x8, [sp, #0x40]
   124f8:      	ldr	x10, [sp, #0x60]
   124fc:      	sub	x12, x10, x8
   12500:      	ldr	w23, [sp, #0x68]
   12504:      	subs	w10, w21, w23
   12508:      	ldr	x9, [sp, #0x88]
   1250c:      	ldr	x25, [sp, #0x8]
   12510:      	csel	w10, wzr, w10, lo
   12514:      	cmp	w23, w21
   12518:      	csel	w11, w23, w21, lo
   1251c:      	cinc	w13, w11, hi
   12520:      	sub	w14, w23, w13
   12524:      	subs	x12, x12, x13
   12528:      	str	w14, [sp, #0x68]
   1252c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12530:      	cmp	x12, #0xfff
   12534:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12538:      	cmp	w23, w21
   1253c:      	b.ls	0x12548 <generic_kprobe_path+0x8a68>
   12540:      	mov	w13, #0x2f              // =47
   12544:      	strb	w13, [x8, x12]
   12548:      	add	x19, x8, x12
   1254c:      	cmp	w23, w21
   12550:      	add	x2, x9, x10
   12554:      	and	w1, w11, #0xff
   12558:      	mov	w8, #0x4                // =4
   1255c:      	cinc	x0, x19, hi
   12560:      	blr	x8
   12564:      	ldr	x25, [sp, #0x8]
   12568:      	cmp	w23, w21
   1256c:      	str	x19, [sp, #0x60]
   12570:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   12574:      	ldr	x21, [sp, #0x78]
   12578:      	ldp	x2, x24, [sp, #0x50]
   1257c:      	str	x21, [sp, #0x48]
   12580:      	b	0x125d4 <generic_kprobe_path+0x8af4>
   12584:      	add	x2, x24, #0x10
   12588:      	mov	w8, #0x4                // =4
   1258c:      	add	x9, sp, #0x98
   12590:      	add	x0, sp, #0x98
   12594:      	mov	w1, #0x8                // =8
   12598:      	blr	x8
   1259c:      	ldr	x8, [sp, #0x58]
   125a0:      	ldr	x9, [sp, #0x98]
   125a4:      	cmp	x8, x9
   125a8:      	ldr	x25, [sp, #0x8]
   125ac:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   125b0:      	add	x2, x24, #0x18
   125b4:      	mov	w8, #0x4                // =4
   125b8:      	mov	x0, x22
   125bc:      	mov	w1, #0x8                // =8
   125c0:      	blr	x8
   125c4:      	ldr	x24, [sp, #0x98]
   125c8:      	ldr	x21, [sp, #0x48]
   125cc:      	add	x2, x24, #0x20
   125d0:      	stp	x2, x24, [sp, #0x50]
   125d4:      	ldr	x8, [sp, #0x30]
   125d8:      	ldr	x25, [sp, #0x8]
   125dc:      	add	x9, sp, #0x70
   125e0:      	cmp	x21, x8
   125e4:      	b.ne	0x125f4 <generic_kprobe_path+0x8b14>
   125e8:      	ldr	x8, [sp, #0x38]
   125ec:      	cmp	x2, x8
   125f0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   125f4:      	mov	w8, #0x4                // =4
   125f8:      	add	x0, sp, #0x70
   125fc:      	mov	w1, #0x8                // =8
   12600:      	blr	x8
   12604:      	ldr	x8, [sp, #0x70]
   12608:      	cmp	x21, x8
   1260c:      	b.eq	0x12700 <generic_kprobe_path+0x8c20>
   12610:      	add	x23, x21, #0x18
   12614:      	mov	w8, #0x4                // =4
   12618:      	add	x9, sp, #0x98
   1261c:      	add	x0, sp, #0x98
   12620:      	mov	w1, #0x8                // =8
   12624:      	mov	x2, x23
   12628:      	blr	x8
   1262c:      	ldr	x8, [sp, #0x98]
   12630:      	cmp	x8, x21
   12634:      	b.eq	0x12700 <generic_kprobe_path+0x8c20>
   12638:      	mov	w8, #0x4                // =4
   1263c:      	add	x9, sp, #0x78
   12640:      	add	x0, sp, #0x78
   12644:      	mov	w1, #0x8                // =8
   12648:      	mov	x2, x23
   1264c:      	blr	x8
   12650:      	add	x2, x21, #0x20
   12654:      	mov	w8, #0x4                // =4
   12658:      	mov	w9, #0x10               // =16
   1265c:      	add	x10, sp, #0x80
   12660:      	add	x0, sp, #0x80
   12664:      	mov	w1, #0x10               // =16
   12668:      	blr	x8
   1266c:      	ldr	w21, [sp, #0x84]
   12670:      	ldr	x8, [sp, #0x40]
   12674:      	ldr	x10, [sp, #0x60]
   12678:      	sub	x12, x10, x8
   1267c:      	ldr	w23, [sp, #0x68]
   12680:      	subs	w10, w21, w23
   12684:      	ldr	x9, [sp, #0x88]
   12688:      	ldr	x25, [sp, #0x8]
   1268c:      	csel	w10, wzr, w10, lo
   12690:      	cmp	w23, w21
   12694:      	csel	w11, w23, w21, lo
   12698:      	cinc	w13, w11, hi
   1269c:      	sub	w14, w23, w13
   126a0:      	subs	x12, x12, x13
   126a4:      	str	w14, [sp, #0x68]
   126a8:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   126ac:      	cmp	x12, #0xfff
   126b0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   126b4:      	cmp	w23, w21
   126b8:      	b.ls	0x126c4 <generic_kprobe_path+0x8be4>
   126bc:      	mov	w13, #0x2f              // =47
   126c0:      	strb	w13, [x8, x12]
   126c4:      	add	x19, x8, x12
   126c8:      	cmp	w23, w21
   126cc:      	add	x2, x9, x10
   126d0:      	and	w1, w11, #0xff
   126d4:      	mov	w8, #0x4                // =4
   126d8:      	cinc	x0, x19, hi
   126dc:      	blr	x8
   126e0:      	ldr	x25, [sp, #0x8]
   126e4:      	cmp	w23, w21
   126e8:      	str	x19, [sp, #0x60]
   126ec:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   126f0:      	ldr	x21, [sp, #0x78]
   126f4:      	ldp	x2, x24, [sp, #0x50]
   126f8:      	str	x21, [sp, #0x48]
   126fc:      	b	0x12750 <generic_kprobe_path+0x8c70>
   12700:      	add	x2, x24, #0x10
   12704:      	mov	w8, #0x4                // =4
   12708:      	add	x9, sp, #0x98
   1270c:      	add	x0, sp, #0x98
   12710:      	mov	w1, #0x8                // =8
   12714:      	blr	x8
   12718:      	ldr	x8, [sp, #0x58]
   1271c:      	ldr	x9, [sp, #0x98]
   12720:      	cmp	x8, x9
   12724:      	ldr	x25, [sp, #0x8]
   12728:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1272c:      	add	x2, x24, #0x18
   12730:      	mov	w8, #0x4                // =4
   12734:      	mov	x0, x22
   12738:      	mov	w1, #0x8                // =8
   1273c:      	blr	x8
   12740:      	ldr	x24, [sp, #0x98]
   12744:      	ldr	x21, [sp, #0x48]
   12748:      	add	x2, x24, #0x20
   1274c:      	stp	x2, x24, [sp, #0x50]
   12750:      	ldr	x8, [sp, #0x30]
   12754:      	ldr	x25, [sp, #0x8]
   12758:      	add	x9, sp, #0x70
   1275c:      	cmp	x21, x8
   12760:      	b.ne	0x12770 <generic_kprobe_path+0x8c90>
   12764:      	ldr	x8, [sp, #0x38]
   12768:      	cmp	x2, x8
   1276c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12770:      	mov	w8, #0x4                // =4
   12774:      	add	x0, sp, #0x70
   12778:      	mov	w1, #0x8                // =8
   1277c:      	blr	x8
   12780:      	ldr	x8, [sp, #0x70]
   12784:      	cmp	x21, x8
   12788:      	b.eq	0x1287c <generic_kprobe_path+0x8d9c>
   1278c:      	add	x23, x21, #0x18
   12790:      	mov	w8, #0x4                // =4
   12794:      	add	x9, sp, #0x98
   12798:      	add	x0, sp, #0x98
   1279c:      	mov	w1, #0x8                // =8
   127a0:      	mov	x2, x23
   127a4:      	blr	x8
   127a8:      	ldr	x8, [sp, #0x98]
   127ac:      	cmp	x8, x21
   127b0:      	b.eq	0x1287c <generic_kprobe_path+0x8d9c>
   127b4:      	mov	w8, #0x4                // =4
   127b8:      	add	x9, sp, #0x78
   127bc:      	add	x0, sp, #0x78
   127c0:      	mov	w1, #0x8                // =8
   127c4:      	mov	x2, x23
   127c8:      	blr	x8
   127cc:      	add	x2, x21, #0x20
   127d0:      	mov	w8, #0x4                // =4
   127d4:      	mov	w9, #0x10               // =16
   127d8:      	add	x10, sp, #0x80
   127dc:      	add	x0, sp, #0x80
   127e0:      	mov	w1, #0x10               // =16
   127e4:      	blr	x8
   127e8:      	ldr	w21, [sp, #0x84]
   127ec:      	ldr	x8, [sp, #0x40]
   127f0:      	ldr	x10, [sp, #0x60]
   127f4:      	sub	x12, x10, x8
   127f8:      	ldr	w23, [sp, #0x68]
   127fc:      	subs	w10, w21, w23
   12800:      	ldr	x9, [sp, #0x88]
   12804:      	ldr	x25, [sp, #0x8]
   12808:      	csel	w10, wzr, w10, lo
   1280c:      	cmp	w23, w21
   12810:      	csel	w11, w23, w21, lo
   12814:      	cinc	w13, w11, hi
   12818:      	sub	w14, w23, w13
   1281c:      	subs	x12, x12, x13
   12820:      	str	w14, [sp, #0x68]
   12824:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12828:      	cmp	x12, #0xfff
   1282c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12830:      	cmp	w23, w21
   12834:      	b.ls	0x12840 <generic_kprobe_path+0x8d60>
   12838:      	mov	w13, #0x2f              // =47
   1283c:      	strb	w13, [x8, x12]
   12840:      	add	x19, x8, x12
   12844:      	cmp	w23, w21
   12848:      	add	x2, x9, x10
   1284c:      	and	w1, w11, #0xff
   12850:      	mov	w8, #0x4                // =4
   12854:      	cinc	x0, x19, hi
   12858:      	blr	x8
   1285c:      	ldr	x25, [sp, #0x8]
   12860:      	cmp	w23, w21
   12864:      	str	x19, [sp, #0x60]
   12868:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   1286c:      	ldr	x21, [sp, #0x78]
   12870:      	ldp	x2, x24, [sp, #0x50]
   12874:      	str	x21, [sp, #0x48]
   12878:      	b	0x128cc <generic_kprobe_path+0x8dec>
   1287c:      	add	x2, x24, #0x10
   12880:      	mov	w8, #0x4                // =4
   12884:      	add	x9, sp, #0x98
   12888:      	add	x0, sp, #0x98
   1288c:      	mov	w1, #0x8                // =8
   12890:      	blr	x8
   12894:      	ldr	x8, [sp, #0x58]
   12898:      	ldr	x9, [sp, #0x98]
   1289c:      	cmp	x8, x9
   128a0:      	ldr	x25, [sp, #0x8]
   128a4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   128a8:      	add	x2, x24, #0x18
   128ac:      	mov	w8, #0x4                // =4
   128b0:      	mov	x0, x22
   128b4:      	mov	w1, #0x8                // =8
   128b8:      	blr	x8
   128bc:      	ldr	x24, [sp, #0x98]
   128c0:      	ldr	x21, [sp, #0x48]
   128c4:      	add	x2, x24, #0x20
   128c8:      	stp	x2, x24, [sp, #0x50]
   128cc:      	ldr	x8, [sp, #0x30]
   128d0:      	ldr	x25, [sp, #0x8]
   128d4:      	add	x9, sp, #0x70
   128d8:      	cmp	x21, x8
   128dc:      	b.ne	0x128ec <generic_kprobe_path+0x8e0c>
   128e0:      	ldr	x8, [sp, #0x38]
   128e4:      	cmp	x2, x8
   128e8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   128ec:      	mov	w8, #0x4                // =4
   128f0:      	add	x0, sp, #0x70
   128f4:      	mov	w1, #0x8                // =8
   128f8:      	blr	x8
   128fc:      	ldr	x8, [sp, #0x70]
   12900:      	cmp	x21, x8
   12904:      	b.eq	0x129f8 <generic_kprobe_path+0x8f18>
   12908:      	add	x23, x21, #0x18
   1290c:      	mov	w8, #0x4                // =4
   12910:      	add	x9, sp, #0x98
   12914:      	add	x0, sp, #0x98
   12918:      	mov	w1, #0x8                // =8
   1291c:      	mov	x2, x23
   12920:      	blr	x8
   12924:      	ldr	x8, [sp, #0x98]
   12928:      	cmp	x8, x21
   1292c:      	b.eq	0x129f8 <generic_kprobe_path+0x8f18>
   12930:      	mov	w8, #0x4                // =4
   12934:      	add	x9, sp, #0x78
   12938:      	add	x0, sp, #0x78
   1293c:      	mov	w1, #0x8                // =8
   12940:      	mov	x2, x23
   12944:      	blr	x8
   12948:      	add	x2, x21, #0x20
   1294c:      	mov	w8, #0x4                // =4
   12950:      	mov	w9, #0x10               // =16
   12954:      	add	x10, sp, #0x80
   12958:      	add	x0, sp, #0x80
   1295c:      	mov	w1, #0x10               // =16
   12960:      	blr	x8
   12964:      	ldr	w21, [sp, #0x84]
   12968:      	ldr	x8, [sp, #0x40]
   1296c:      	ldr	x10, [sp, #0x60]
   12970:      	sub	x12, x10, x8
   12974:      	ldr	w23, [sp, #0x68]
   12978:      	subs	w10, w21, w23
   1297c:      	ldr	x9, [sp, #0x88]
   12980:      	ldr	x25, [sp, #0x8]
   12984:      	csel	w10, wzr, w10, lo
   12988:      	cmp	w23, w21
   1298c:      	csel	w11, w23, w21, lo
   12990:      	cinc	w13, w11, hi
   12994:      	sub	w14, w23, w13
   12998:      	subs	x12, x12, x13
   1299c:      	str	w14, [sp, #0x68]
   129a0:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   129a4:      	cmp	x12, #0xfff
   129a8:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   129ac:      	cmp	w23, w21
   129b0:      	b.ls	0x129bc <generic_kprobe_path+0x8edc>
   129b4:      	mov	w13, #0x2f              // =47
   129b8:      	strb	w13, [x8, x12]
   129bc:      	add	x19, x8, x12
   129c0:      	cmp	w23, w21
   129c4:      	add	x2, x9, x10
   129c8:      	and	w1, w11, #0xff
   129cc:      	mov	w8, #0x4                // =4
   129d0:      	cinc	x0, x19, hi
   129d4:      	blr	x8
   129d8:      	ldr	x25, [sp, #0x8]
   129dc:      	cmp	w23, w21
   129e0:      	str	x19, [sp, #0x60]
   129e4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   129e8:      	ldr	x21, [sp, #0x78]
   129ec:      	ldp	x2, x24, [sp, #0x50]
   129f0:      	str	x21, [sp, #0x48]
   129f4:      	b	0x12a48 <generic_kprobe_path+0x8f68>
   129f8:      	add	x2, x24, #0x10
   129fc:      	mov	w8, #0x4                // =4
   12a00:      	add	x9, sp, #0x98
   12a04:      	add	x0, sp, #0x98
   12a08:      	mov	w1, #0x8                // =8
   12a0c:      	blr	x8
   12a10:      	ldr	x8, [sp, #0x58]
   12a14:      	ldr	x9, [sp, #0x98]
   12a18:      	cmp	x8, x9
   12a1c:      	ldr	x25, [sp, #0x8]
   12a20:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12a24:      	add	x2, x24, #0x18
   12a28:      	mov	w8, #0x4                // =4
   12a2c:      	mov	x0, x22
   12a30:      	mov	w1, #0x8                // =8
   12a34:      	blr	x8
   12a38:      	ldr	x24, [sp, #0x98]
   12a3c:      	ldr	x21, [sp, #0x48]
   12a40:      	add	x2, x24, #0x20
   12a44:      	stp	x2, x24, [sp, #0x50]
   12a48:      	ldr	x8, [sp, #0x30]
   12a4c:      	ldr	x25, [sp, #0x8]
   12a50:      	add	x9, sp, #0x70
   12a54:      	cmp	x21, x8
   12a58:      	b.ne	0x12a68 <generic_kprobe_path+0x8f88>
   12a5c:      	ldr	x8, [sp, #0x38]
   12a60:      	cmp	x2, x8
   12a64:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12a68:      	mov	w8, #0x4                // =4
   12a6c:      	add	x0, sp, #0x70
   12a70:      	mov	w1, #0x8                // =8
   12a74:      	blr	x8
   12a78:      	ldr	x8, [sp, #0x70]
   12a7c:      	cmp	x21, x8
   12a80:      	b.eq	0x12b74 <generic_kprobe_path+0x9094>
   12a84:      	add	x23, x21, #0x18
   12a88:      	mov	w8, #0x4                // =4
   12a8c:      	add	x9, sp, #0x98
   12a90:      	add	x0, sp, #0x98
   12a94:      	mov	w1, #0x8                // =8
   12a98:      	mov	x2, x23
   12a9c:      	blr	x8
   12aa0:      	ldr	x8, [sp, #0x98]
   12aa4:      	cmp	x8, x21
   12aa8:      	b.eq	0x12b74 <generic_kprobe_path+0x9094>
   12aac:      	mov	w8, #0x4                // =4
   12ab0:      	add	x9, sp, #0x78
   12ab4:      	add	x0, sp, #0x78
   12ab8:      	mov	w1, #0x8                // =8
   12abc:      	mov	x2, x23
   12ac0:      	blr	x8
   12ac4:      	add	x2, x21, #0x20
   12ac8:      	mov	w8, #0x4                // =4
   12acc:      	mov	w9, #0x10               // =16
   12ad0:      	add	x10, sp, #0x80
   12ad4:      	add	x0, sp, #0x80
   12ad8:      	mov	w1, #0x10               // =16
   12adc:      	blr	x8
   12ae0:      	ldr	w21, [sp, #0x84]
   12ae4:      	ldr	x8, [sp, #0x40]
   12ae8:      	ldr	x10, [sp, #0x60]
   12aec:      	sub	x12, x10, x8
   12af0:      	ldr	w23, [sp, #0x68]
   12af4:      	subs	w10, w21, w23
   12af8:      	ldr	x9, [sp, #0x88]
   12afc:      	ldr	x25, [sp, #0x8]
   12b00:      	csel	w10, wzr, w10, lo
   12b04:      	cmp	w23, w21
   12b08:      	csel	w11, w23, w21, lo
   12b0c:      	cinc	w13, w11, hi
   12b10:      	sub	w14, w23, w13
   12b14:      	subs	x12, x12, x13
   12b18:      	str	w14, [sp, #0x68]
   12b1c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12b20:      	cmp	x12, #0xfff
   12b24:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12b28:      	cmp	w23, w21
   12b2c:      	b.ls	0x12b38 <generic_kprobe_path+0x9058>
   12b30:      	mov	w13, #0x2f              // =47
   12b34:      	strb	w13, [x8, x12]
   12b38:      	add	x19, x8, x12
   12b3c:      	cmp	w23, w21
   12b40:      	add	x2, x9, x10
   12b44:      	and	w1, w11, #0xff
   12b48:      	mov	w8, #0x4                // =4
   12b4c:      	cinc	x0, x19, hi
   12b50:      	blr	x8
   12b54:      	ldr	x25, [sp, #0x8]
   12b58:      	cmp	w23, w21
   12b5c:      	str	x19, [sp, #0x60]
   12b60:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   12b64:      	ldr	x21, [sp, #0x78]
   12b68:      	ldp	x2, x24, [sp, #0x50]
   12b6c:      	str	x21, [sp, #0x48]
   12b70:      	b	0x12bc4 <generic_kprobe_path+0x90e4>
   12b74:      	add	x2, x24, #0x10
   12b78:      	mov	w8, #0x4                // =4
   12b7c:      	add	x9, sp, #0x98
   12b80:      	add	x0, sp, #0x98
   12b84:      	mov	w1, #0x8                // =8
   12b88:      	blr	x8
   12b8c:      	ldr	x8, [sp, #0x58]
   12b90:      	ldr	x9, [sp, #0x98]
   12b94:      	cmp	x8, x9
   12b98:      	ldr	x25, [sp, #0x8]
   12b9c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12ba0:      	add	x2, x24, #0x18
   12ba4:      	mov	w8, #0x4                // =4
   12ba8:      	mov	x0, x22
   12bac:      	mov	w1, #0x8                // =8
   12bb0:      	blr	x8
   12bb4:      	ldr	x24, [sp, #0x98]
   12bb8:      	ldr	x21, [sp, #0x48]
   12bbc:      	add	x2, x24, #0x20
   12bc0:      	stp	x2, x24, [sp, #0x50]
   12bc4:      	ldr	x8, [sp, #0x30]
   12bc8:      	ldr	x25, [sp, #0x8]
   12bcc:      	add	x9, sp, #0x70
   12bd0:      	cmp	x21, x8
   12bd4:      	b.ne	0x12be4 <generic_kprobe_path+0x9104>
   12bd8:      	ldr	x8, [sp, #0x38]
   12bdc:      	cmp	x2, x8
   12be0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12be4:      	mov	w8, #0x4                // =4
   12be8:      	add	x0, sp, #0x70
   12bec:      	mov	w1, #0x8                // =8
   12bf0:      	blr	x8
   12bf4:      	ldr	x8, [sp, #0x70]
   12bf8:      	cmp	x21, x8
   12bfc:      	b.eq	0x12cf0 <generic_kprobe_path+0x9210>
   12c00:      	add	x23, x21, #0x18
   12c04:      	mov	w8, #0x4                // =4
   12c08:      	add	x9, sp, #0x98
   12c0c:      	add	x0, sp, #0x98
   12c10:      	mov	w1, #0x8                // =8
   12c14:      	mov	x2, x23
   12c18:      	blr	x8
   12c1c:      	ldr	x8, [sp, #0x98]
   12c20:      	cmp	x8, x21
   12c24:      	b.eq	0x12cf0 <generic_kprobe_path+0x9210>
   12c28:      	mov	w8, #0x4                // =4
   12c2c:      	add	x9, sp, #0x78
   12c30:      	add	x0, sp, #0x78
   12c34:      	mov	w1, #0x8                // =8
   12c38:      	mov	x2, x23
   12c3c:      	blr	x8
   12c40:      	add	x2, x21, #0x20
   12c44:      	mov	w8, #0x4                // =4
   12c48:      	mov	w9, #0x10               // =16
   12c4c:      	add	x10, sp, #0x80
   12c50:      	add	x0, sp, #0x80
   12c54:      	mov	w1, #0x10               // =16
   12c58:      	blr	x8
   12c5c:      	ldr	w21, [sp, #0x84]
   12c60:      	ldr	x8, [sp, #0x40]
   12c64:      	ldr	x10, [sp, #0x60]
   12c68:      	sub	x12, x10, x8
   12c6c:      	ldr	w23, [sp, #0x68]
   12c70:      	subs	w10, w21, w23
   12c74:      	ldr	x9, [sp, #0x88]
   12c78:      	ldr	x25, [sp, #0x8]
   12c7c:      	csel	w10, wzr, w10, lo
   12c80:      	cmp	w23, w21
   12c84:      	csel	w11, w23, w21, lo
   12c88:      	cinc	w13, w11, hi
   12c8c:      	sub	w14, w23, w13
   12c90:      	subs	x12, x12, x13
   12c94:      	str	w14, [sp, #0x68]
   12c98:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12c9c:      	cmp	x12, #0xfff
   12ca0:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12ca4:      	cmp	w23, w21
   12ca8:      	b.ls	0x12cb4 <generic_kprobe_path+0x91d4>
   12cac:      	mov	w13, #0x2f              // =47
   12cb0:      	strb	w13, [x8, x12]
   12cb4:      	add	x19, x8, x12
   12cb8:      	cmp	w23, w21
   12cbc:      	add	x2, x9, x10
   12cc0:      	and	w1, w11, #0xff
   12cc4:      	mov	w8, #0x4                // =4
   12cc8:      	cinc	x0, x19, hi
   12ccc:      	blr	x8
   12cd0:      	ldr	x25, [sp, #0x8]
   12cd4:      	cmp	w23, w21
   12cd8:      	str	x19, [sp, #0x60]
   12cdc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   12ce0:      	ldr	x21, [sp, #0x78]
   12ce4:      	ldp	x2, x24, [sp, #0x50]
   12ce8:      	str	x21, [sp, #0x48]
   12cec:      	b	0x12d40 <generic_kprobe_path+0x9260>
   12cf0:      	add	x2, x24, #0x10
   12cf4:      	mov	w8, #0x4                // =4
   12cf8:      	add	x9, sp, #0x98
   12cfc:      	add	x0, sp, #0x98
   12d00:      	mov	w1, #0x8                // =8
   12d04:      	blr	x8
   12d08:      	ldr	x8, [sp, #0x58]
   12d0c:      	ldr	x9, [sp, #0x98]
   12d10:      	cmp	x8, x9
   12d14:      	ldr	x25, [sp, #0x8]
   12d18:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12d1c:      	add	x2, x24, #0x18
   12d20:      	mov	w8, #0x4                // =4
   12d24:      	mov	x0, x22
   12d28:      	mov	w1, #0x8                // =8
   12d2c:      	blr	x8
   12d30:      	ldr	x24, [sp, #0x98]
   12d34:      	ldr	x21, [sp, #0x48]
   12d38:      	add	x2, x24, #0x20
   12d3c:      	stp	x2, x24, [sp, #0x50]
   12d40:      	ldr	x8, [sp, #0x30]
   12d44:      	ldr	x25, [sp, #0x8]
   12d48:      	add	x9, sp, #0x70
   12d4c:      	cmp	x21, x8
   12d50:      	b.ne	0x12d60 <generic_kprobe_path+0x9280>
   12d54:      	ldr	x8, [sp, #0x38]
   12d58:      	cmp	x2, x8
   12d5c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12d60:      	mov	w8, #0x4                // =4
   12d64:      	add	x0, sp, #0x70
   12d68:      	mov	w1, #0x8                // =8
   12d6c:      	blr	x8
   12d70:      	ldr	x8, [sp, #0x70]
   12d74:      	cmp	x21, x8
   12d78:      	b.eq	0x12e6c <generic_kprobe_path+0x938c>
   12d7c:      	add	x23, x21, #0x18
   12d80:      	mov	w8, #0x4                // =4
   12d84:      	add	x9, sp, #0x98
   12d88:      	add	x0, sp, #0x98
   12d8c:      	mov	w1, #0x8                // =8
   12d90:      	mov	x2, x23
   12d94:      	blr	x8
   12d98:      	ldr	x8, [sp, #0x98]
   12d9c:      	cmp	x8, x21
   12da0:      	b.eq	0x12e6c <generic_kprobe_path+0x938c>
   12da4:      	mov	w8, #0x4                // =4
   12da8:      	add	x9, sp, #0x78
   12dac:      	add	x0, sp, #0x78
   12db0:      	mov	w1, #0x8                // =8
   12db4:      	mov	x2, x23
   12db8:      	blr	x8
   12dbc:      	add	x2, x21, #0x20
   12dc0:      	mov	w8, #0x4                // =4
   12dc4:      	mov	w9, #0x10               // =16
   12dc8:      	add	x10, sp, #0x80
   12dcc:      	add	x0, sp, #0x80
   12dd0:      	mov	w1, #0x10               // =16
   12dd4:      	blr	x8
   12dd8:      	ldr	w21, [sp, #0x84]
   12ddc:      	ldr	x8, [sp, #0x40]
   12de0:      	ldr	x10, [sp, #0x60]
   12de4:      	sub	x12, x10, x8
   12de8:      	ldr	w23, [sp, #0x68]
   12dec:      	subs	w10, w21, w23
   12df0:      	ldr	x9, [sp, #0x88]
   12df4:      	ldr	x25, [sp, #0x8]
   12df8:      	csel	w10, wzr, w10, lo
   12dfc:      	cmp	w23, w21
   12e00:      	csel	w11, w23, w21, lo
   12e04:      	cinc	w13, w11, hi
   12e08:      	sub	w14, w23, w13
   12e0c:      	subs	x12, x12, x13
   12e10:      	str	w14, [sp, #0x68]
   12e14:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12e18:      	cmp	x12, #0xfff
   12e1c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12e20:      	cmp	w23, w21
   12e24:      	b.ls	0x12e30 <generic_kprobe_path+0x9350>
   12e28:      	mov	w13, #0x2f              // =47
   12e2c:      	strb	w13, [x8, x12]
   12e30:      	add	x19, x8, x12
   12e34:      	cmp	w23, w21
   12e38:      	add	x2, x9, x10
   12e3c:      	and	w1, w11, #0xff
   12e40:      	mov	w8, #0x4                // =4
   12e44:      	cinc	x0, x19, hi
   12e48:      	blr	x8
   12e4c:      	ldr	x25, [sp, #0x8]
   12e50:      	cmp	w23, w21
   12e54:      	str	x19, [sp, #0x60]
   12e58:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   12e5c:      	ldr	x21, [sp, #0x78]
   12e60:      	ldp	x2, x24, [sp, #0x50]
   12e64:      	str	x21, [sp, #0x48]
   12e68:      	b	0x12ebc <generic_kprobe_path+0x93dc>
   12e6c:      	add	x2, x24, #0x10
   12e70:      	mov	w8, #0x4                // =4
   12e74:      	add	x9, sp, #0x98
   12e78:      	add	x0, sp, #0x98
   12e7c:      	mov	w1, #0x8                // =8
   12e80:      	blr	x8
   12e84:      	ldr	x8, [sp, #0x58]
   12e88:      	ldr	x9, [sp, #0x98]
   12e8c:      	cmp	x8, x9
   12e90:      	ldr	x25, [sp, #0x8]
   12e94:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12e98:      	add	x2, x24, #0x18
   12e9c:      	mov	w8, #0x4                // =4
   12ea0:      	mov	x0, x22
   12ea4:      	mov	w1, #0x8                // =8
   12ea8:      	blr	x8
   12eac:      	ldr	x24, [sp, #0x98]
   12eb0:      	ldr	x21, [sp, #0x48]
   12eb4:      	add	x2, x24, #0x20
   12eb8:      	stp	x2, x24, [sp, #0x50]
   12ebc:      	ldr	x8, [sp, #0x30]
   12ec0:      	ldr	x25, [sp, #0x8]
   12ec4:      	add	x9, sp, #0x70
   12ec8:      	cmp	x21, x8
   12ecc:      	b.ne	0x12edc <generic_kprobe_path+0x93fc>
   12ed0:      	ldr	x8, [sp, #0x38]
   12ed4:      	cmp	x2, x8
   12ed8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   12edc:      	mov	w8, #0x4                // =4
   12ee0:      	add	x0, sp, #0x70
   12ee4:      	mov	w1, #0x8                // =8
   12ee8:      	blr	x8
   12eec:      	ldr	x8, [sp, #0x70]
   12ef0:      	cmp	x21, x8
   12ef4:      	b.eq	0x12fe8 <generic_kprobe_path+0x9508>
   12ef8:      	add	x23, x21, #0x18
   12efc:      	mov	w8, #0x4                // =4
   12f00:      	add	x9, sp, #0x98
   12f04:      	add	x0, sp, #0x98
   12f08:      	mov	w1, #0x8                // =8
   12f0c:      	mov	x2, x23
   12f10:      	blr	x8
   12f14:      	ldr	x8, [sp, #0x98]
   12f18:      	cmp	x8, x21
   12f1c:      	b.eq	0x12fe8 <generic_kprobe_path+0x9508>
   12f20:      	mov	w8, #0x4                // =4
   12f24:      	add	x9, sp, #0x78
   12f28:      	add	x0, sp, #0x78
   12f2c:      	mov	w1, #0x8                // =8
   12f30:      	mov	x2, x23
   12f34:      	blr	x8
   12f38:      	add	x2, x21, #0x20
   12f3c:      	mov	w8, #0x4                // =4
   12f40:      	mov	w9, #0x10               // =16
   12f44:      	add	x10, sp, #0x80
   12f48:      	add	x0, sp, #0x80
   12f4c:      	mov	w1, #0x10               // =16
   12f50:      	blr	x8
   12f54:      	ldr	w21, [sp, #0x84]
   12f58:      	ldr	x8, [sp, #0x40]
   12f5c:      	ldr	x10, [sp, #0x60]
   12f60:      	sub	x12, x10, x8
   12f64:      	ldr	w23, [sp, #0x68]
   12f68:      	subs	w10, w21, w23
   12f6c:      	ldr	x9, [sp, #0x88]
   12f70:      	ldr	x25, [sp, #0x8]
   12f74:      	csel	w10, wzr, w10, lo
   12f78:      	cmp	w23, w21
   12f7c:      	csel	w11, w23, w21, lo
   12f80:      	cinc	w13, w11, hi
   12f84:      	sub	w14, w23, w13
   12f88:      	subs	x12, x12, x13
   12f8c:      	str	w14, [sp, #0x68]
   12f90:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   12f94:      	cmp	x12, #0xfff
   12f98:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   12f9c:      	cmp	w23, w21
   12fa0:      	b.ls	0x12fac <generic_kprobe_path+0x94cc>
   12fa4:      	mov	w13, #0x2f              // =47
   12fa8:      	strb	w13, [x8, x12]
   12fac:      	add	x19, x8, x12
   12fb0:      	cmp	w23, w21
   12fb4:      	add	x2, x9, x10
   12fb8:      	and	w1, w11, #0xff
   12fbc:      	mov	w8, #0x4                // =4
   12fc0:      	cinc	x0, x19, hi
   12fc4:      	blr	x8
   12fc8:      	ldr	x25, [sp, #0x8]
   12fcc:      	cmp	w23, w21
   12fd0:      	str	x19, [sp, #0x60]
   12fd4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   12fd8:      	ldr	x21, [sp, #0x78]
   12fdc:      	ldp	x2, x24, [sp, #0x50]
   12fe0:      	str	x21, [sp, #0x48]
   12fe4:      	b	0x13038 <generic_kprobe_path+0x9558>
   12fe8:      	add	x2, x24, #0x10
   12fec:      	mov	w8, #0x4                // =4
   12ff0:      	add	x9, sp, #0x98
   12ff4:      	add	x0, sp, #0x98
   12ff8:      	mov	w1, #0x8                // =8
   12ffc:      	blr	x8
   13000:      	ldr	x8, [sp, #0x58]
   13004:      	ldr	x9, [sp, #0x98]
   13008:      	cmp	x8, x9
   1300c:      	ldr	x25, [sp, #0x8]
   13010:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13014:      	add	x2, x24, #0x18
   13018:      	mov	w8, #0x4                // =4
   1301c:      	mov	x0, x22
   13020:      	mov	w1, #0x8                // =8
   13024:      	blr	x8
   13028:      	ldr	x24, [sp, #0x98]
   1302c:      	ldr	x21, [sp, #0x48]
   13030:      	add	x2, x24, #0x20
   13034:      	stp	x2, x24, [sp, #0x50]
   13038:      	ldr	x8, [sp, #0x30]
   1303c:      	ldr	x25, [sp, #0x8]
   13040:      	add	x9, sp, #0x70
   13044:      	cmp	x21, x8
   13048:      	b.ne	0x13058 <generic_kprobe_path+0x9578>
   1304c:      	ldr	x8, [sp, #0x38]
   13050:      	cmp	x2, x8
   13054:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13058:      	mov	w8, #0x4                // =4
   1305c:      	add	x0, sp, #0x70
   13060:      	mov	w1, #0x8                // =8
   13064:      	blr	x8
   13068:      	ldr	x8, [sp, #0x70]
   1306c:      	cmp	x21, x8
   13070:      	b.eq	0x13164 <generic_kprobe_path+0x9684>
   13074:      	add	x23, x21, #0x18
   13078:      	mov	w8, #0x4                // =4
   1307c:      	add	x9, sp, #0x98
   13080:      	add	x0, sp, #0x98
   13084:      	mov	w1, #0x8                // =8
   13088:      	mov	x2, x23
   1308c:      	blr	x8
   13090:      	ldr	x8, [sp, #0x98]
   13094:      	cmp	x8, x21
   13098:      	b.eq	0x13164 <generic_kprobe_path+0x9684>
   1309c:      	mov	w8, #0x4                // =4
   130a0:      	add	x9, sp, #0x78
   130a4:      	add	x0, sp, #0x78
   130a8:      	mov	w1, #0x8                // =8
   130ac:      	mov	x2, x23
   130b0:      	blr	x8
   130b4:      	add	x2, x21, #0x20
   130b8:      	mov	w8, #0x4                // =4
   130bc:      	mov	w9, #0x10               // =16
   130c0:      	add	x10, sp, #0x80
   130c4:      	add	x0, sp, #0x80
   130c8:      	mov	w1, #0x10               // =16
   130cc:      	blr	x8
   130d0:      	ldr	w21, [sp, #0x84]
   130d4:      	ldr	x8, [sp, #0x40]
   130d8:      	ldr	x10, [sp, #0x60]
   130dc:      	sub	x12, x10, x8
   130e0:      	ldr	w23, [sp, #0x68]
   130e4:      	subs	w10, w21, w23
   130e8:      	ldr	x9, [sp, #0x88]
   130ec:      	ldr	x25, [sp, #0x8]
   130f0:      	csel	w10, wzr, w10, lo
   130f4:      	cmp	w23, w21
   130f8:      	csel	w11, w23, w21, lo
   130fc:      	cinc	w13, w11, hi
   13100:      	sub	w14, w23, w13
   13104:      	subs	x12, x12, x13
   13108:      	str	w14, [sp, #0x68]
   1310c:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13110:      	cmp	x12, #0xfff
   13114:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13118:      	cmp	w23, w21
   1311c:      	b.ls	0x13128 <generic_kprobe_path+0x9648>
   13120:      	mov	w13, #0x2f              // =47
   13124:      	strb	w13, [x8, x12]
   13128:      	add	x19, x8, x12
   1312c:      	cmp	w23, w21
   13130:      	add	x2, x9, x10
   13134:      	and	w1, w11, #0xff
   13138:      	mov	w8, #0x4                // =4
   1313c:      	cinc	x0, x19, hi
   13140:      	blr	x8
   13144:      	ldr	x25, [sp, #0x8]
   13148:      	cmp	w23, w21
   1314c:      	str	x19, [sp, #0x60]
   13150:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   13154:      	ldr	x21, [sp, #0x78]
   13158:      	ldp	x2, x24, [sp, #0x50]
   1315c:      	str	x21, [sp, #0x48]
   13160:      	b	0x131b4 <generic_kprobe_path+0x96d4>
   13164:      	add	x2, x24, #0x10
   13168:      	mov	w8, #0x4                // =4
   1316c:      	add	x9, sp, #0x98
   13170:      	add	x0, sp, #0x98
   13174:      	mov	w1, #0x8                // =8
   13178:      	blr	x8
   1317c:      	ldr	x8, [sp, #0x58]
   13180:      	ldr	x9, [sp, #0x98]
   13184:      	cmp	x8, x9
   13188:      	ldr	x25, [sp, #0x8]
   1318c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13190:      	add	x2, x24, #0x18
   13194:      	mov	w8, #0x4                // =4
   13198:      	mov	x0, x22
   1319c:      	mov	w1, #0x8                // =8
   131a0:      	blr	x8
   131a4:      	ldr	x24, [sp, #0x98]
   131a8:      	ldr	x21, [sp, #0x48]
   131ac:      	add	x2, x24, #0x20
   131b0:      	stp	x2, x24, [sp, #0x50]
   131b4:      	ldr	x8, [sp, #0x30]
   131b8:      	ldr	x25, [sp, #0x8]
   131bc:      	add	x9, sp, #0x70
   131c0:      	cmp	x21, x8
   131c4:      	b.ne	0x131d4 <generic_kprobe_path+0x96f4>
   131c8:      	ldr	x8, [sp, #0x38]
   131cc:      	cmp	x2, x8
   131d0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   131d4:      	mov	w8, #0x4                // =4
   131d8:      	add	x0, sp, #0x70
   131dc:      	mov	w1, #0x8                // =8
   131e0:      	blr	x8
   131e4:      	ldr	x8, [sp, #0x70]
   131e8:      	cmp	x21, x8
   131ec:      	b.eq	0x132e0 <generic_kprobe_path+0x9800>
   131f0:      	add	x23, x21, #0x18
   131f4:      	mov	w8, #0x4                // =4
   131f8:      	add	x9, sp, #0x98
   131fc:      	add	x0, sp, #0x98
   13200:      	mov	w1, #0x8                // =8
   13204:      	mov	x2, x23
   13208:      	blr	x8
   1320c:      	ldr	x8, [sp, #0x98]
   13210:      	cmp	x8, x21
   13214:      	b.eq	0x132e0 <generic_kprobe_path+0x9800>
   13218:      	mov	w8, #0x4                // =4
   1321c:      	add	x9, sp, #0x78
   13220:      	add	x0, sp, #0x78
   13224:      	mov	w1, #0x8                // =8
   13228:      	mov	x2, x23
   1322c:      	blr	x8
   13230:      	add	x2, x21, #0x20
   13234:      	mov	w8, #0x4                // =4
   13238:      	mov	w9, #0x10               // =16
   1323c:      	add	x10, sp, #0x80
   13240:      	add	x0, sp, #0x80
   13244:      	mov	w1, #0x10               // =16
   13248:      	blr	x8
   1324c:      	ldr	w21, [sp, #0x84]
   13250:      	ldr	x8, [sp, #0x40]
   13254:      	ldr	x10, [sp, #0x60]
   13258:      	sub	x12, x10, x8
   1325c:      	ldr	w23, [sp, #0x68]
   13260:      	subs	w10, w21, w23
   13264:      	ldr	x9, [sp, #0x88]
   13268:      	ldr	x25, [sp, #0x8]
   1326c:      	csel	w10, wzr, w10, lo
   13270:      	cmp	w23, w21
   13274:      	csel	w11, w23, w21, lo
   13278:      	cinc	w13, w11, hi
   1327c:      	sub	w14, w23, w13
   13280:      	subs	x12, x12, x13
   13284:      	str	w14, [sp, #0x68]
   13288:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   1328c:      	cmp	x12, #0xfff
   13290:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13294:      	cmp	w23, w21
   13298:      	b.ls	0x132a4 <generic_kprobe_path+0x97c4>
   1329c:      	mov	w13, #0x2f              // =47
   132a0:      	strb	w13, [x8, x12]
   132a4:      	add	x19, x8, x12
   132a8:      	cmp	w23, w21
   132ac:      	add	x2, x9, x10
   132b0:      	and	w1, w11, #0xff
   132b4:      	mov	w8, #0x4                // =4
   132b8:      	cinc	x0, x19, hi
   132bc:      	blr	x8
   132c0:      	ldr	x25, [sp, #0x8]
   132c4:      	cmp	w23, w21
   132c8:      	str	x19, [sp, #0x60]
   132cc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   132d0:      	ldr	x21, [sp, #0x78]
   132d4:      	ldp	x2, x24, [sp, #0x50]
   132d8:      	str	x21, [sp, #0x48]
   132dc:      	b	0x13330 <generic_kprobe_path+0x9850>
   132e0:      	add	x2, x24, #0x10
   132e4:      	mov	w8, #0x4                // =4
   132e8:      	add	x9, sp, #0x98
   132ec:      	add	x0, sp, #0x98
   132f0:      	mov	w1, #0x8                // =8
   132f4:      	blr	x8
   132f8:      	ldr	x8, [sp, #0x58]
   132fc:      	ldr	x9, [sp, #0x98]
   13300:      	cmp	x8, x9
   13304:      	ldr	x25, [sp, #0x8]
   13308:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1330c:      	add	x2, x24, #0x18
   13310:      	mov	w8, #0x4                // =4
   13314:      	mov	x0, x22
   13318:      	mov	w1, #0x8                // =8
   1331c:      	blr	x8
   13320:      	ldr	x24, [sp, #0x98]
   13324:      	ldr	x21, [sp, #0x48]
   13328:      	add	x2, x24, #0x20
   1332c:      	stp	x2, x24, [sp, #0x50]
   13330:      	ldr	x8, [sp, #0x30]
   13334:      	ldr	x25, [sp, #0x8]
   13338:      	add	x9, sp, #0x70
   1333c:      	cmp	x21, x8
   13340:      	b.ne	0x13350 <generic_kprobe_path+0x9870>
   13344:      	ldr	x8, [sp, #0x38]
   13348:      	cmp	x2, x8
   1334c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13350:      	mov	w8, #0x4                // =4
   13354:      	add	x0, sp, #0x70
   13358:      	mov	w1, #0x8                // =8
   1335c:      	blr	x8
   13360:      	ldr	x8, [sp, #0x70]
   13364:      	cmp	x21, x8
   13368:      	b.eq	0x1345c <generic_kprobe_path+0x997c>
   1336c:      	add	x23, x21, #0x18
   13370:      	mov	w8, #0x4                // =4
   13374:      	add	x9, sp, #0x98
   13378:      	add	x0, sp, #0x98
   1337c:      	mov	w1, #0x8                // =8
   13380:      	mov	x2, x23
   13384:      	blr	x8
   13388:      	ldr	x8, [sp, #0x98]
   1338c:      	cmp	x8, x21
   13390:      	b.eq	0x1345c <generic_kprobe_path+0x997c>
   13394:      	mov	w8, #0x4                // =4
   13398:      	add	x9, sp, #0x78
   1339c:      	add	x0, sp, #0x78
   133a0:      	mov	w1, #0x8                // =8
   133a4:      	mov	x2, x23
   133a8:      	blr	x8
   133ac:      	add	x2, x21, #0x20
   133b0:      	mov	w8, #0x4                // =4
   133b4:      	mov	w9, #0x10               // =16
   133b8:      	add	x10, sp, #0x80
   133bc:      	add	x0, sp, #0x80
   133c0:      	mov	w1, #0x10               // =16
   133c4:      	blr	x8
   133c8:      	ldr	w21, [sp, #0x84]
   133cc:      	ldr	x8, [sp, #0x40]
   133d0:      	ldr	x10, [sp, #0x60]
   133d4:      	sub	x12, x10, x8
   133d8:      	ldr	w23, [sp, #0x68]
   133dc:      	subs	w10, w21, w23
   133e0:      	ldr	x9, [sp, #0x88]
   133e4:      	ldr	x25, [sp, #0x8]
   133e8:      	csel	w10, wzr, w10, lo
   133ec:      	cmp	w23, w21
   133f0:      	csel	w11, w23, w21, lo
   133f4:      	cinc	w13, w11, hi
   133f8:      	sub	w14, w23, w13
   133fc:      	subs	x12, x12, x13
   13400:      	str	w14, [sp, #0x68]
   13404:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13408:      	cmp	x12, #0xfff
   1340c:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13410:      	cmp	w23, w21
   13414:      	b.ls	0x13420 <generic_kprobe_path+0x9940>
   13418:      	mov	w13, #0x2f              // =47
   1341c:      	strb	w13, [x8, x12]
   13420:      	add	x19, x8, x12
   13424:      	cmp	w23, w21
   13428:      	add	x2, x9, x10
   1342c:      	and	w1, w11, #0xff
   13430:      	mov	w8, #0x4                // =4
   13434:      	cinc	x0, x19, hi
   13438:      	blr	x8
   1343c:      	ldr	x25, [sp, #0x8]
   13440:      	cmp	w23, w21
   13444:      	str	x19, [sp, #0x60]
   13448:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   1344c:      	ldr	x21, [sp, #0x78]
   13450:      	ldp	x2, x24, [sp, #0x50]
   13454:      	str	x21, [sp, #0x48]
   13458:      	b	0x134ac <generic_kprobe_path+0x99cc>
   1345c:      	add	x2, x24, #0x10
   13460:      	mov	w8, #0x4                // =4
   13464:      	add	x9, sp, #0x98
   13468:      	add	x0, sp, #0x98
   1346c:      	mov	w1, #0x8                // =8
   13470:      	blr	x8
   13474:      	ldr	x8, [sp, #0x58]
   13478:      	ldr	x9, [sp, #0x98]
   1347c:      	cmp	x8, x9
   13480:      	ldr	x25, [sp, #0x8]
   13484:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13488:      	add	x2, x24, #0x18
   1348c:      	mov	w8, #0x4                // =4
   13490:      	mov	x0, x22
   13494:      	mov	w1, #0x8                // =8
   13498:      	blr	x8
   1349c:      	ldr	x24, [sp, #0x98]
   134a0:      	ldr	x21, [sp, #0x48]
   134a4:      	add	x2, x24, #0x20
   134a8:      	stp	x2, x24, [sp, #0x50]
   134ac:      	ldr	x8, [sp, #0x30]
   134b0:      	ldr	x25, [sp, #0x8]
   134b4:      	add	x9, sp, #0x70
   134b8:      	cmp	x21, x8
   134bc:      	b.ne	0x134cc <generic_kprobe_path+0x99ec>
   134c0:      	ldr	x8, [sp, #0x38]
   134c4:      	cmp	x2, x8
   134c8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   134cc:      	mov	w8, #0x4                // =4
   134d0:      	add	x0, sp, #0x70
   134d4:      	mov	w1, #0x8                // =8
   134d8:      	blr	x8
   134dc:      	ldr	x8, [sp, #0x70]
   134e0:      	cmp	x21, x8
   134e4:      	b.eq	0x135d8 <generic_kprobe_path+0x9af8>
   134e8:      	add	x23, x21, #0x18
   134ec:      	mov	w8, #0x4                // =4
   134f0:      	add	x9, sp, #0x98
   134f4:      	add	x0, sp, #0x98
   134f8:      	mov	w1, #0x8                // =8
   134fc:      	mov	x2, x23
   13500:      	blr	x8
   13504:      	ldr	x8, [sp, #0x98]
   13508:      	cmp	x8, x21
   1350c:      	b.eq	0x135d8 <generic_kprobe_path+0x9af8>
   13510:      	mov	w8, #0x4                // =4
   13514:      	add	x9, sp, #0x78
   13518:      	add	x0, sp, #0x78
   1351c:      	mov	w1, #0x8                // =8
   13520:      	mov	x2, x23
   13524:      	blr	x8
   13528:      	add	x2, x21, #0x20
   1352c:      	mov	w8, #0x4                // =4
   13530:      	mov	w9, #0x10               // =16
   13534:      	add	x10, sp, #0x80
   13538:      	add	x0, sp, #0x80
   1353c:      	mov	w1, #0x10               // =16
   13540:      	blr	x8
   13544:      	ldr	w21, [sp, #0x84]
   13548:      	ldr	x8, [sp, #0x40]
   1354c:      	ldr	x10, [sp, #0x60]
   13550:      	sub	x12, x10, x8
   13554:      	ldr	w23, [sp, #0x68]
   13558:      	subs	w10, w21, w23
   1355c:      	ldr	x9, [sp, #0x88]
   13560:      	ldr	x25, [sp, #0x8]
   13564:      	csel	w10, wzr, w10, lo
   13568:      	cmp	w23, w21
   1356c:      	csel	w11, w23, w21, lo
   13570:      	cinc	w13, w11, hi
   13574:      	sub	w14, w23, w13
   13578:      	subs	x12, x12, x13
   1357c:      	str	w14, [sp, #0x68]
   13580:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13584:      	cmp	x12, #0xfff
   13588:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   1358c:      	cmp	w23, w21
   13590:      	b.ls	0x1359c <generic_kprobe_path+0x9abc>
   13594:      	mov	w13, #0x2f              // =47
   13598:      	strb	w13, [x8, x12]
   1359c:      	add	x19, x8, x12
   135a0:      	cmp	w23, w21
   135a4:      	add	x2, x9, x10
   135a8:      	and	w1, w11, #0xff
   135ac:      	mov	w8, #0x4                // =4
   135b0:      	cinc	x0, x19, hi
   135b4:      	blr	x8
   135b8:      	ldr	x25, [sp, #0x8]
   135bc:      	cmp	w23, w21
   135c0:      	str	x19, [sp, #0x60]
   135c4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   135c8:      	ldr	x21, [sp, #0x78]
   135cc:      	ldp	x2, x24, [sp, #0x50]
   135d0:      	str	x21, [sp, #0x48]
   135d4:      	b	0x13628 <generic_kprobe_path+0x9b48>
   135d8:      	add	x2, x24, #0x10
   135dc:      	mov	w8, #0x4                // =4
   135e0:      	add	x9, sp, #0x98
   135e4:      	add	x0, sp, #0x98
   135e8:      	mov	w1, #0x8                // =8
   135ec:      	blr	x8
   135f0:      	ldr	x8, [sp, #0x58]
   135f4:      	ldr	x9, [sp, #0x98]
   135f8:      	cmp	x8, x9
   135fc:      	ldr	x25, [sp, #0x8]
   13600:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13604:      	add	x2, x24, #0x18
   13608:      	mov	w8, #0x4                // =4
   1360c:      	mov	x0, x22
   13610:      	mov	w1, #0x8                // =8
   13614:      	blr	x8
   13618:      	ldr	x24, [sp, #0x98]
   1361c:      	ldr	x21, [sp, #0x48]
   13620:      	add	x2, x24, #0x20
   13624:      	stp	x2, x24, [sp, #0x50]
   13628:      	ldr	x8, [sp, #0x30]
   1362c:      	ldr	x25, [sp, #0x8]
   13630:      	add	x9, sp, #0x70
   13634:      	cmp	x21, x8
   13638:      	b.ne	0x13648 <generic_kprobe_path+0x9b68>
   1363c:      	ldr	x8, [sp, #0x38]
   13640:      	cmp	x2, x8
   13644:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13648:      	mov	w8, #0x4                // =4
   1364c:      	add	x0, sp, #0x70
   13650:      	mov	w1, #0x8                // =8
   13654:      	blr	x8
   13658:      	ldr	x8, [sp, #0x70]
   1365c:      	cmp	x21, x8
   13660:      	b.eq	0x13754 <generic_kprobe_path+0x9c74>
   13664:      	add	x23, x21, #0x18
   13668:      	mov	w8, #0x4                // =4
   1366c:      	add	x9, sp, #0x98
   13670:      	add	x0, sp, #0x98
   13674:      	mov	w1, #0x8                // =8
   13678:      	mov	x2, x23
   1367c:      	blr	x8
   13680:      	ldr	x8, [sp, #0x98]
   13684:      	cmp	x8, x21
   13688:      	b.eq	0x13754 <generic_kprobe_path+0x9c74>
   1368c:      	mov	w8, #0x4                // =4
   13690:      	add	x9, sp, #0x78
   13694:      	add	x0, sp, #0x78
   13698:      	mov	w1, #0x8                // =8
   1369c:      	mov	x2, x23
   136a0:      	blr	x8
   136a4:      	add	x2, x21, #0x20
   136a8:      	mov	w8, #0x4                // =4
   136ac:      	mov	w9, #0x10               // =16
   136b0:      	add	x10, sp, #0x80
   136b4:      	add	x0, sp, #0x80
   136b8:      	mov	w1, #0x10               // =16
   136bc:      	blr	x8
   136c0:      	ldr	w21, [sp, #0x84]
   136c4:      	ldr	x8, [sp, #0x40]
   136c8:      	ldr	x10, [sp, #0x60]
   136cc:      	sub	x12, x10, x8
   136d0:      	ldr	w23, [sp, #0x68]
   136d4:      	subs	w10, w21, w23
   136d8:      	ldr	x9, [sp, #0x88]
   136dc:      	ldr	x25, [sp, #0x8]
   136e0:      	csel	w10, wzr, w10, lo
   136e4:      	cmp	w23, w21
   136e8:      	csel	w11, w23, w21, lo
   136ec:      	cinc	w13, w11, hi
   136f0:      	sub	w14, w23, w13
   136f4:      	subs	x12, x12, x13
   136f8:      	str	w14, [sp, #0x68]
   136fc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13700:      	cmp	x12, #0xfff
   13704:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13708:      	cmp	w23, w21
   1370c:      	b.ls	0x13718 <generic_kprobe_path+0x9c38>
   13710:      	mov	w13, #0x2f              // =47
   13714:      	strb	w13, [x8, x12]
   13718:      	add	x19, x8, x12
   1371c:      	cmp	w23, w21
   13720:      	add	x2, x9, x10
   13724:      	and	w1, w11, #0xff
   13728:      	mov	w8, #0x4                // =4
   1372c:      	cinc	x0, x19, hi
   13730:      	blr	x8
   13734:      	ldr	x25, [sp, #0x8]
   13738:      	cmp	w23, w21
   1373c:      	str	x19, [sp, #0x60]
   13740:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   13744:      	ldr	x21, [sp, #0x78]
   13748:      	ldp	x2, x24, [sp, #0x50]
   1374c:      	str	x21, [sp, #0x48]
   13750:      	b	0x137a4 <generic_kprobe_path+0x9cc4>
   13754:      	add	x2, x24, #0x10
   13758:      	mov	w8, #0x4                // =4
   1375c:      	add	x9, sp, #0x98
   13760:      	add	x0, sp, #0x98
   13764:      	mov	w1, #0x8                // =8
   13768:      	blr	x8
   1376c:      	ldr	x8, [sp, #0x58]
   13770:      	ldr	x9, [sp, #0x98]
   13774:      	cmp	x8, x9
   13778:      	ldr	x25, [sp, #0x8]
   1377c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13780:      	add	x2, x24, #0x18
   13784:      	mov	w8, #0x4                // =4
   13788:      	mov	x0, x22
   1378c:      	mov	w1, #0x8                // =8
   13790:      	blr	x8
   13794:      	ldr	x24, [sp, #0x98]
   13798:      	ldr	x21, [sp, #0x48]
   1379c:      	add	x2, x24, #0x20
   137a0:      	stp	x2, x24, [sp, #0x50]
   137a4:      	ldr	x8, [sp, #0x30]
   137a8:      	ldr	x25, [sp, #0x8]
   137ac:      	add	x9, sp, #0x70
   137b0:      	cmp	x21, x8
   137b4:      	b.ne	0x137c4 <generic_kprobe_path+0x9ce4>
   137b8:      	ldr	x8, [sp, #0x38]
   137bc:      	cmp	x2, x8
   137c0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   137c4:      	mov	w8, #0x4                // =4
   137c8:      	add	x0, sp, #0x70
   137cc:      	mov	w1, #0x8                // =8
   137d0:      	blr	x8
   137d4:      	ldr	x8, [sp, #0x70]
   137d8:      	cmp	x21, x8
   137dc:      	b.eq	0x138d0 <generic_kprobe_path+0x9df0>
   137e0:      	add	x23, x21, #0x18
   137e4:      	mov	w8, #0x4                // =4
   137e8:      	add	x9, sp, #0x98
   137ec:      	add	x0, sp, #0x98
   137f0:      	mov	w1, #0x8                // =8
   137f4:      	mov	x2, x23
   137f8:      	blr	x8
   137fc:      	ldr	x8, [sp, #0x98]
   13800:      	cmp	x8, x21
   13804:      	b.eq	0x138d0 <generic_kprobe_path+0x9df0>
   13808:      	mov	w8, #0x4                // =4
   1380c:      	add	x9, sp, #0x78
   13810:      	add	x0, sp, #0x78
   13814:      	mov	w1, #0x8                // =8
   13818:      	mov	x2, x23
   1381c:      	blr	x8
   13820:      	add	x2, x21, #0x20
   13824:      	mov	w8, #0x4                // =4
   13828:      	mov	w9, #0x10               // =16
   1382c:      	add	x10, sp, #0x80
   13830:      	add	x0, sp, #0x80
   13834:      	mov	w1, #0x10               // =16
   13838:      	blr	x8
   1383c:      	ldr	w21, [sp, #0x84]
   13840:      	ldr	x8, [sp, #0x40]
   13844:      	ldr	x10, [sp, #0x60]
   13848:      	sub	x12, x10, x8
   1384c:      	ldr	w23, [sp, #0x68]
   13850:      	subs	w10, w21, w23
   13854:      	ldr	x9, [sp, #0x88]
   13858:      	ldr	x25, [sp, #0x8]
   1385c:      	csel	w10, wzr, w10, lo
   13860:      	cmp	w23, w21
   13864:      	csel	w11, w23, w21, lo
   13868:      	cinc	w13, w11, hi
   1386c:      	sub	w14, w23, w13
   13870:      	subs	x12, x12, x13
   13874:      	str	w14, [sp, #0x68]
   13878:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   1387c:      	cmp	x12, #0xfff
   13880:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13884:      	cmp	w23, w21
   13888:      	b.ls	0x13894 <generic_kprobe_path+0x9db4>
   1388c:      	mov	w13, #0x2f              // =47
   13890:      	strb	w13, [x8, x12]
   13894:      	add	x19, x8, x12
   13898:      	cmp	w23, w21
   1389c:      	add	x2, x9, x10
   138a0:      	and	w1, w11, #0xff
   138a4:      	mov	w8, #0x4                // =4
   138a8:      	cinc	x0, x19, hi
   138ac:      	blr	x8
   138b0:      	ldr	x25, [sp, #0x8]
   138b4:      	cmp	w23, w21
   138b8:      	str	x19, [sp, #0x60]
   138bc:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   138c0:      	ldr	x21, [sp, #0x78]
   138c4:      	ldp	x2, x24, [sp, #0x50]
   138c8:      	str	x21, [sp, #0x48]
   138cc:      	b	0x13920 <generic_kprobe_path+0x9e40>
   138d0:      	add	x2, x24, #0x10
   138d4:      	mov	w8, #0x4                // =4
   138d8:      	add	x9, sp, #0x98
   138dc:      	add	x0, sp, #0x98
   138e0:      	mov	w1, #0x8                // =8
   138e4:      	blr	x8
   138e8:      	ldr	x8, [sp, #0x58]
   138ec:      	ldr	x9, [sp, #0x98]
   138f0:      	cmp	x8, x9
   138f4:      	ldr	x25, [sp, #0x8]
   138f8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   138fc:      	add	x2, x24, #0x18
   13900:      	mov	w8, #0x4                // =4
   13904:      	mov	x0, x22
   13908:      	mov	w1, #0x8                // =8
   1390c:      	blr	x8
   13910:      	ldr	x24, [sp, #0x98]
   13914:      	ldr	x21, [sp, #0x48]
   13918:      	add	x2, x24, #0x20
   1391c:      	stp	x2, x24, [sp, #0x50]
   13920:      	ldr	x8, [sp, #0x30]
   13924:      	ldr	x25, [sp, #0x8]
   13928:      	add	x9, sp, #0x70
   1392c:      	cmp	x21, x8
   13930:      	b.ne	0x13940 <generic_kprobe_path+0x9e60>
   13934:      	ldr	x8, [sp, #0x38]
   13938:      	cmp	x2, x8
   1393c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13940:      	mov	w8, #0x4                // =4
   13944:      	add	x0, sp, #0x70
   13948:      	mov	w1, #0x8                // =8
   1394c:      	blr	x8
   13950:      	ldr	x8, [sp, #0x70]
   13954:      	cmp	x21, x8
   13958:      	b.eq	0x13a4c <generic_kprobe_path+0x9f6c>
   1395c:      	add	x23, x21, #0x18
   13960:      	mov	w8, #0x4                // =4
   13964:      	add	x9, sp, #0x98
   13968:      	add	x0, sp, #0x98
   1396c:      	mov	w1, #0x8                // =8
   13970:      	mov	x2, x23
   13974:      	blr	x8
   13978:      	ldr	x8, [sp, #0x98]
   1397c:      	cmp	x8, x21
   13980:      	b.eq	0x13a4c <generic_kprobe_path+0x9f6c>
   13984:      	mov	w8, #0x4                // =4
   13988:      	add	x9, sp, #0x78
   1398c:      	add	x0, sp, #0x78
   13990:      	mov	w1, #0x8                // =8
   13994:      	mov	x2, x23
   13998:      	blr	x8
   1399c:      	add	x2, x21, #0x20
   139a0:      	mov	w8, #0x4                // =4
   139a4:      	mov	w9, #0x10               // =16
   139a8:      	add	x10, sp, #0x80
   139ac:      	add	x0, sp, #0x80
   139b0:      	mov	w1, #0x10               // =16
   139b4:      	blr	x8
   139b8:      	ldr	w21, [sp, #0x84]
   139bc:      	ldr	x8, [sp, #0x40]
   139c0:      	ldr	x10, [sp, #0x60]
   139c4:      	sub	x12, x10, x8
   139c8:      	ldr	w23, [sp, #0x68]
   139cc:      	subs	w10, w21, w23
   139d0:      	ldr	x9, [sp, #0x88]
   139d4:      	ldr	x25, [sp, #0x8]
   139d8:      	csel	w10, wzr, w10, lo
   139dc:      	cmp	w23, w21
   139e0:      	csel	w11, w23, w21, lo
   139e4:      	cinc	w13, w11, hi
   139e8:      	sub	w14, w23, w13
   139ec:      	subs	x12, x12, x13
   139f0:      	str	w14, [sp, #0x68]
   139f4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   139f8:      	cmp	x12, #0xfff
   139fc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13a00:      	cmp	w23, w21
   13a04:      	b.ls	0x13a10 <generic_kprobe_path+0x9f30>
   13a08:      	mov	w13, #0x2f              // =47
   13a0c:      	strb	w13, [x8, x12]
   13a10:      	add	x19, x8, x12
   13a14:      	cmp	w23, w21
   13a18:      	add	x2, x9, x10
   13a1c:      	and	w1, w11, #0xff
   13a20:      	mov	w8, #0x4                // =4
   13a24:      	cinc	x0, x19, hi
   13a28:      	blr	x8
   13a2c:      	ldr	x25, [sp, #0x8]
   13a30:      	cmp	w23, w21
   13a34:      	str	x19, [sp, #0x60]
   13a38:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   13a3c:      	ldr	x21, [sp, #0x78]
   13a40:      	ldp	x2, x24, [sp, #0x50]
   13a44:      	str	x21, [sp, #0x48]
   13a48:      	b	0x13a9c <generic_kprobe_path+0x9fbc>
   13a4c:      	add	x2, x24, #0x10
   13a50:      	mov	w8, #0x4                // =4
   13a54:      	add	x9, sp, #0x98
   13a58:      	add	x0, sp, #0x98
   13a5c:      	mov	w1, #0x8                // =8
   13a60:      	blr	x8
   13a64:      	ldr	x8, [sp, #0x58]
   13a68:      	ldr	x9, [sp, #0x98]
   13a6c:      	cmp	x8, x9
   13a70:      	ldr	x25, [sp, #0x8]
   13a74:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13a78:      	add	x2, x24, #0x18
   13a7c:      	mov	w8, #0x4                // =4
   13a80:      	mov	x0, x22
   13a84:      	mov	w1, #0x8                // =8
   13a88:      	blr	x8
   13a8c:      	ldr	x24, [sp, #0x98]
   13a90:      	ldr	x21, [sp, #0x48]
   13a94:      	add	x2, x24, #0x20
   13a98:      	stp	x2, x24, [sp, #0x50]
   13a9c:      	ldr	x8, [sp, #0x30]
   13aa0:      	ldr	x25, [sp, #0x8]
   13aa4:      	add	x9, sp, #0x70
   13aa8:      	cmp	x21, x8
   13aac:      	b.ne	0x13abc <generic_kprobe_path+0x9fdc>
   13ab0:      	ldr	x8, [sp, #0x38]
   13ab4:      	cmp	x2, x8
   13ab8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13abc:      	mov	w8, #0x4                // =4
   13ac0:      	add	x0, sp, #0x70
   13ac4:      	mov	w1, #0x8                // =8
   13ac8:      	blr	x8
   13acc:      	ldr	x8, [sp, #0x70]
   13ad0:      	cmp	x21, x8
   13ad4:      	b.eq	0x13bc8 <generic_kprobe_path+0xa0e8>
   13ad8:      	add	x23, x21, #0x18
   13adc:      	mov	w8, #0x4                // =4
   13ae0:      	add	x9, sp, #0x98
   13ae4:      	add	x0, sp, #0x98
   13ae8:      	mov	w1, #0x8                // =8
   13aec:      	mov	x2, x23
   13af0:      	blr	x8
   13af4:      	ldr	x8, [sp, #0x98]
   13af8:      	cmp	x8, x21
   13afc:      	b.eq	0x13bc8 <generic_kprobe_path+0xa0e8>
   13b00:      	mov	w8, #0x4                // =4
   13b04:      	add	x9, sp, #0x78
   13b08:      	add	x0, sp, #0x78
   13b0c:      	mov	w1, #0x8                // =8
   13b10:      	mov	x2, x23
   13b14:      	blr	x8
   13b18:      	add	x2, x21, #0x20
   13b1c:      	mov	w8, #0x4                // =4
   13b20:      	mov	w9, #0x10               // =16
   13b24:      	add	x10, sp, #0x80
   13b28:      	add	x0, sp, #0x80
   13b2c:      	mov	w1, #0x10               // =16
   13b30:      	blr	x8
   13b34:      	ldr	w21, [sp, #0x84]
   13b38:      	ldr	x8, [sp, #0x40]
   13b3c:      	ldr	x10, [sp, #0x60]
   13b40:      	sub	x12, x10, x8
   13b44:      	ldr	w23, [sp, #0x68]
   13b48:      	subs	w10, w21, w23
   13b4c:      	ldr	x9, [sp, #0x88]
   13b50:      	ldr	x25, [sp, #0x8]
   13b54:      	csel	w10, wzr, w10, lo
   13b58:      	cmp	w23, w21
   13b5c:      	csel	w11, w23, w21, lo
   13b60:      	cinc	w13, w11, hi
   13b64:      	sub	w14, w23, w13
   13b68:      	subs	x12, x12, x13
   13b6c:      	str	w14, [sp, #0x68]
   13b70:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13b74:      	cmp	x12, #0xfff
   13b78:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13b7c:      	cmp	w23, w21
   13b80:      	b.ls	0x13b8c <generic_kprobe_path+0xa0ac>
   13b84:      	mov	w13, #0x2f              // =47
   13b88:      	strb	w13, [x8, x12]
   13b8c:      	add	x19, x8, x12
   13b90:      	cmp	w23, w21
   13b94:      	add	x2, x9, x10
   13b98:      	and	w1, w11, #0xff
   13b9c:      	mov	w8, #0x4                // =4
   13ba0:      	cinc	x0, x19, hi
   13ba4:      	blr	x8
   13ba8:      	ldr	x25, [sp, #0x8]
   13bac:      	cmp	w23, w21
   13bb0:      	str	x19, [sp, #0x60]
   13bb4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   13bb8:      	ldr	x21, [sp, #0x78]
   13bbc:      	ldp	x2, x24, [sp, #0x50]
   13bc0:      	str	x21, [sp, #0x48]
   13bc4:      	b	0x13c18 <generic_kprobe_path+0xa138>
   13bc8:      	add	x2, x24, #0x10
   13bcc:      	mov	w8, #0x4                // =4
   13bd0:      	add	x9, sp, #0x98
   13bd4:      	add	x0, sp, #0x98
   13bd8:      	mov	w1, #0x8                // =8
   13bdc:      	blr	x8
   13be0:      	ldr	x8, [sp, #0x58]
   13be4:      	ldr	x9, [sp, #0x98]
   13be8:      	cmp	x8, x9
   13bec:      	ldr	x25, [sp, #0x8]
   13bf0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13bf4:      	add	x2, x24, #0x18
   13bf8:      	mov	w8, #0x4                // =4
   13bfc:      	mov	x0, x22
   13c00:      	mov	w1, #0x8                // =8
   13c04:      	blr	x8
   13c08:      	ldr	x24, [sp, #0x98]
   13c0c:      	ldr	x21, [sp, #0x48]
   13c10:      	add	x2, x24, #0x20
   13c14:      	stp	x2, x24, [sp, #0x50]
   13c18:      	ldr	x8, [sp, #0x30]
   13c1c:      	ldr	x25, [sp, #0x8]
   13c20:      	add	x9, sp, #0x70
   13c24:      	cmp	x21, x8
   13c28:      	b.ne	0x13c38 <generic_kprobe_path+0xa158>
   13c2c:      	ldr	x8, [sp, #0x38]
   13c30:      	cmp	x2, x8
   13c34:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13c38:      	mov	w8, #0x4                // =4
   13c3c:      	add	x0, sp, #0x70
   13c40:      	mov	w1, #0x8                // =8
   13c44:      	blr	x8
   13c48:      	ldr	x8, [sp, #0x70]
   13c4c:      	cmp	x21, x8
   13c50:      	b.eq	0x13d44 <generic_kprobe_path+0xa264>
   13c54:      	add	x23, x21, #0x18
   13c58:      	mov	w8, #0x4                // =4
   13c5c:      	add	x9, sp, #0x98
   13c60:      	add	x0, sp, #0x98
   13c64:      	mov	w1, #0x8                // =8
   13c68:      	mov	x2, x23
   13c6c:      	blr	x8
   13c70:      	ldr	x8, [sp, #0x98]
   13c74:      	cmp	x8, x21
   13c78:      	b.eq	0x13d44 <generic_kprobe_path+0xa264>
   13c7c:      	mov	w8, #0x4                // =4
   13c80:      	add	x9, sp, #0x78
   13c84:      	add	x0, sp, #0x78
   13c88:      	mov	w1, #0x8                // =8
   13c8c:      	mov	x2, x23
   13c90:      	blr	x8
   13c94:      	add	x2, x21, #0x20
   13c98:      	mov	w8, #0x4                // =4
   13c9c:      	mov	w9, #0x10               // =16
   13ca0:      	add	x10, sp, #0x80
   13ca4:      	add	x0, sp, #0x80
   13ca8:      	mov	w1, #0x10               // =16
   13cac:      	blr	x8
   13cb0:      	ldr	w21, [sp, #0x84]
   13cb4:      	ldr	x8, [sp, #0x40]
   13cb8:      	ldr	x10, [sp, #0x60]
   13cbc:      	sub	x12, x10, x8
   13cc0:      	ldr	w23, [sp, #0x68]
   13cc4:      	subs	w10, w21, w23
   13cc8:      	ldr	x9, [sp, #0x88]
   13ccc:      	ldr	x25, [sp, #0x8]
   13cd0:      	csel	w10, wzr, w10, lo
   13cd4:      	cmp	w23, w21
   13cd8:      	csel	w11, w23, w21, lo
   13cdc:      	cinc	w13, w11, hi
   13ce0:      	sub	w14, w23, w13
   13ce4:      	subs	x12, x12, x13
   13ce8:      	str	w14, [sp, #0x68]
   13cec:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13cf0:      	cmp	x12, #0xfff
   13cf4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13cf8:      	cmp	w23, w21
   13cfc:      	b.ls	0x13d08 <generic_kprobe_path+0xa228>
   13d00:      	mov	w13, #0x2f              // =47
   13d04:      	strb	w13, [x8, x12]
   13d08:      	add	x19, x8, x12
   13d0c:      	cmp	w23, w21
   13d10:      	add	x2, x9, x10
   13d14:      	and	w1, w11, #0xff
   13d18:      	mov	w8, #0x4                // =4
   13d1c:      	cinc	x0, x19, hi
   13d20:      	blr	x8
   13d24:      	ldr	x25, [sp, #0x8]
   13d28:      	cmp	w23, w21
   13d2c:      	str	x19, [sp, #0x60]
   13d30:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   13d34:      	ldr	x21, [sp, #0x78]
   13d38:      	ldp	x2, x24, [sp, #0x50]
   13d3c:      	str	x21, [sp, #0x48]
   13d40:      	b	0x13d94 <generic_kprobe_path+0xa2b4>
   13d44:      	add	x2, x24, #0x10
   13d48:      	mov	w8, #0x4                // =4
   13d4c:      	add	x9, sp, #0x98
   13d50:      	add	x0, sp, #0x98
   13d54:      	mov	w1, #0x8                // =8
   13d58:      	blr	x8
   13d5c:      	ldr	x8, [sp, #0x58]
   13d60:      	ldr	x9, [sp, #0x98]
   13d64:      	cmp	x8, x9
   13d68:      	ldr	x25, [sp, #0x8]
   13d6c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13d70:      	add	x2, x24, #0x18
   13d74:      	mov	w8, #0x4                // =4
   13d78:      	mov	x0, x22
   13d7c:      	mov	w1, #0x8                // =8
   13d80:      	blr	x8
   13d84:      	ldr	x24, [sp, #0x98]
   13d88:      	ldr	x21, [sp, #0x48]
   13d8c:      	add	x2, x24, #0x20
   13d90:      	stp	x2, x24, [sp, #0x50]
   13d94:      	ldr	x8, [sp, #0x30]
   13d98:      	ldr	x25, [sp, #0x8]
   13d9c:      	add	x9, sp, #0x70
   13da0:      	cmp	x21, x8
   13da4:      	b.ne	0x13db4 <generic_kprobe_path+0xa2d4>
   13da8:      	ldr	x8, [sp, #0x38]
   13dac:      	cmp	x2, x8
   13db0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13db4:      	mov	w8, #0x4                // =4
   13db8:      	add	x0, sp, #0x70
   13dbc:      	mov	w1, #0x8                // =8
   13dc0:      	blr	x8
   13dc4:      	ldr	x8, [sp, #0x70]
   13dc8:      	cmp	x21, x8
   13dcc:      	b.eq	0x13ec0 <generic_kprobe_path+0xa3e0>
   13dd0:      	add	x23, x21, #0x18
   13dd4:      	mov	w8, #0x4                // =4
   13dd8:      	add	x9, sp, #0x98
   13ddc:      	add	x0, sp, #0x98
   13de0:      	mov	w1, #0x8                // =8
   13de4:      	mov	x2, x23
   13de8:      	blr	x8
   13dec:      	ldr	x8, [sp, #0x98]
   13df0:      	cmp	x8, x21
   13df4:      	b.eq	0x13ec0 <generic_kprobe_path+0xa3e0>
   13df8:      	mov	w8, #0x4                // =4
   13dfc:      	add	x9, sp, #0x78
   13e00:      	add	x0, sp, #0x78
   13e04:      	mov	w1, #0x8                // =8
   13e08:      	mov	x2, x23
   13e0c:      	blr	x8
   13e10:      	add	x2, x21, #0x20
   13e14:      	mov	w8, #0x4                // =4
   13e18:      	mov	w9, #0x10               // =16
   13e1c:      	add	x10, sp, #0x80
   13e20:      	add	x0, sp, #0x80
   13e24:      	mov	w1, #0x10               // =16
   13e28:      	blr	x8
   13e2c:      	ldr	w21, [sp, #0x84]
   13e30:      	ldr	x8, [sp, #0x40]
   13e34:      	ldr	x10, [sp, #0x60]
   13e38:      	sub	x12, x10, x8
   13e3c:      	ldr	w23, [sp, #0x68]
   13e40:      	subs	w10, w21, w23
   13e44:      	ldr	x9, [sp, #0x88]
   13e48:      	ldr	x25, [sp, #0x8]
   13e4c:      	csel	w10, wzr, w10, lo
   13e50:      	cmp	w23, w21
   13e54:      	csel	w11, w23, w21, lo
   13e58:      	cinc	w13, w11, hi
   13e5c:      	sub	w14, w23, w13
   13e60:      	subs	x12, x12, x13
   13e64:      	str	w14, [sp, #0x68]
   13e68:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13e6c:      	cmp	x12, #0xfff
   13e70:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13e74:      	cmp	w23, w21
   13e78:      	b.ls	0x13e84 <generic_kprobe_path+0xa3a4>
   13e7c:      	mov	w13, #0x2f              // =47
   13e80:      	strb	w13, [x8, x12]
   13e84:      	add	x19, x8, x12
   13e88:      	cmp	w23, w21
   13e8c:      	add	x2, x9, x10
   13e90:      	and	w1, w11, #0xff
   13e94:      	mov	w8, #0x4                // =4
   13e98:      	cinc	x0, x19, hi
   13e9c:      	blr	x8
   13ea0:      	ldr	x25, [sp, #0x8]
   13ea4:      	cmp	w23, w21
   13ea8:      	str	x19, [sp, #0x60]
   13eac:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   13eb0:      	ldr	x21, [sp, #0x78]
   13eb4:      	ldp	x2, x24, [sp, #0x50]
   13eb8:      	str	x21, [sp, #0x48]
   13ebc:      	b	0x13f10 <generic_kprobe_path+0xa430>
   13ec0:      	add	x2, x24, #0x10
   13ec4:      	mov	w8, #0x4                // =4
   13ec8:      	add	x9, sp, #0x98
   13ecc:      	add	x0, sp, #0x98
   13ed0:      	mov	w1, #0x8                // =8
   13ed4:      	blr	x8
   13ed8:      	ldr	x8, [sp, #0x58]
   13edc:      	ldr	x9, [sp, #0x98]
   13ee0:      	cmp	x8, x9
   13ee4:      	ldr	x25, [sp, #0x8]
   13ee8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13eec:      	add	x2, x24, #0x18
   13ef0:      	mov	w8, #0x4                // =4
   13ef4:      	mov	x0, x22
   13ef8:      	mov	w1, #0x8                // =8
   13efc:      	blr	x8
   13f00:      	ldr	x24, [sp, #0x98]
   13f04:      	ldr	x21, [sp, #0x48]
   13f08:      	add	x2, x24, #0x20
   13f0c:      	stp	x2, x24, [sp, #0x50]
   13f10:      	ldr	x8, [sp, #0x30]
   13f14:      	ldr	x25, [sp, #0x8]
   13f18:      	add	x9, sp, #0x70
   13f1c:      	cmp	x21, x8
   13f20:      	b.ne	0x13f30 <generic_kprobe_path+0xa450>
   13f24:      	ldr	x8, [sp, #0x38]
   13f28:      	cmp	x2, x8
   13f2c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   13f30:      	mov	w8, #0x4                // =4
   13f34:      	add	x0, sp, #0x70
   13f38:      	mov	w1, #0x8                // =8
   13f3c:      	blr	x8
   13f40:      	ldr	x8, [sp, #0x70]
   13f44:      	cmp	x21, x8
   13f48:      	b.eq	0x1403c <generic_kprobe_path+0xa55c>
   13f4c:      	add	x23, x21, #0x18
   13f50:      	mov	w8, #0x4                // =4
   13f54:      	add	x9, sp, #0x98
   13f58:      	add	x0, sp, #0x98
   13f5c:      	mov	w1, #0x8                // =8
   13f60:      	mov	x2, x23
   13f64:      	blr	x8
   13f68:      	ldr	x8, [sp, #0x98]
   13f6c:      	cmp	x8, x21
   13f70:      	b.eq	0x1403c <generic_kprobe_path+0xa55c>
   13f74:      	mov	w8, #0x4                // =4
   13f78:      	add	x9, sp, #0x78
   13f7c:      	add	x0, sp, #0x78
   13f80:      	mov	w1, #0x8                // =8
   13f84:      	mov	x2, x23
   13f88:      	blr	x8
   13f8c:      	add	x2, x21, #0x20
   13f90:      	mov	w8, #0x4                // =4
   13f94:      	mov	w9, #0x10               // =16
   13f98:      	add	x10, sp, #0x80
   13f9c:      	add	x0, sp, #0x80
   13fa0:      	mov	w1, #0x10               // =16
   13fa4:      	blr	x8
   13fa8:      	ldr	w21, [sp, #0x84]
   13fac:      	ldr	x8, [sp, #0x40]
   13fb0:      	ldr	x10, [sp, #0x60]
   13fb4:      	sub	x12, x10, x8
   13fb8:      	ldr	w23, [sp, #0x68]
   13fbc:      	subs	w10, w21, w23
   13fc0:      	ldr	x9, [sp, #0x88]
   13fc4:      	ldr	x25, [sp, #0x8]
   13fc8:      	csel	w10, wzr, w10, lo
   13fcc:      	cmp	w23, w21
   13fd0:      	csel	w11, w23, w21, lo
   13fd4:      	cinc	w13, w11, hi
   13fd8:      	sub	w14, w23, w13
   13fdc:      	subs	x12, x12, x13
   13fe0:      	str	w14, [sp, #0x68]
   13fe4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   13fe8:      	cmp	x12, #0xfff
   13fec:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   13ff0:      	cmp	w23, w21
   13ff4:      	b.ls	0x14000 <generic_kprobe_path+0xa520>
   13ff8:      	mov	w13, #0x2f              // =47
   13ffc:      	strb	w13, [x8, x12]
   14000:      	add	x19, x8, x12
   14004:      	cmp	w23, w21
   14008:      	add	x2, x9, x10
   1400c:      	and	w1, w11, #0xff
   14010:      	mov	w8, #0x4                // =4
   14014:      	cinc	x0, x19, hi
   14018:      	blr	x8
   1401c:      	ldr	x25, [sp, #0x8]
   14020:      	cmp	w23, w21
   14024:      	str	x19, [sp, #0x60]
   14028:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   1402c:      	ldr	x21, [sp, #0x78]
   14030:      	ldp	x2, x24, [sp, #0x50]
   14034:      	str	x21, [sp, #0x48]
   14038:      	b	0x1408c <generic_kprobe_path+0xa5ac>
   1403c:      	add	x2, x24, #0x10
   14040:      	mov	w8, #0x4                // =4
   14044:      	add	x9, sp, #0x98
   14048:      	add	x0, sp, #0x98
   1404c:      	mov	w1, #0x8                // =8
   14050:      	blr	x8
   14054:      	ldr	x8, [sp, #0x58]
   14058:      	ldr	x9, [sp, #0x98]
   1405c:      	cmp	x8, x9
   14060:      	ldr	x25, [sp, #0x8]
   14064:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14068:      	add	x2, x24, #0x18
   1406c:      	mov	w8, #0x4                // =4
   14070:      	mov	x0, x22
   14074:      	mov	w1, #0x8                // =8
   14078:      	blr	x8
   1407c:      	ldr	x24, [sp, #0x98]
   14080:      	ldr	x21, [sp, #0x48]
   14084:      	add	x2, x24, #0x20
   14088:      	stp	x2, x24, [sp, #0x50]
   1408c:      	ldr	x8, [sp, #0x30]
   14090:      	ldr	x25, [sp, #0x8]
   14094:      	add	x9, sp, #0x70
   14098:      	cmp	x21, x8
   1409c:      	b.ne	0x140ac <generic_kprobe_path+0xa5cc>
   140a0:      	ldr	x8, [sp, #0x38]
   140a4:      	cmp	x2, x8
   140a8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   140ac:      	mov	w8, #0x4                // =4
   140b0:      	add	x0, sp, #0x70
   140b4:      	mov	w1, #0x8                // =8
   140b8:      	blr	x8
   140bc:      	ldr	x8, [sp, #0x70]
   140c0:      	cmp	x21, x8
   140c4:      	b.eq	0x141b8 <generic_kprobe_path+0xa6d8>
   140c8:      	add	x23, x21, #0x18
   140cc:      	mov	w8, #0x4                // =4
   140d0:      	add	x9, sp, #0x98
   140d4:      	add	x0, sp, #0x98
   140d8:      	mov	w1, #0x8                // =8
   140dc:      	mov	x2, x23
   140e0:      	blr	x8
   140e4:      	ldr	x8, [sp, #0x98]
   140e8:      	cmp	x8, x21
   140ec:      	b.eq	0x141b8 <generic_kprobe_path+0xa6d8>
   140f0:      	mov	w8, #0x4                // =4
   140f4:      	add	x9, sp, #0x78
   140f8:      	add	x0, sp, #0x78
   140fc:      	mov	w1, #0x8                // =8
   14100:      	mov	x2, x23
   14104:      	blr	x8
   14108:      	add	x2, x21, #0x20
   1410c:      	mov	w8, #0x4                // =4
   14110:      	mov	w9, #0x10               // =16
   14114:      	add	x10, sp, #0x80
   14118:      	add	x0, sp, #0x80
   1411c:      	mov	w1, #0x10               // =16
   14120:      	blr	x8
   14124:      	ldr	w21, [sp, #0x84]
   14128:      	ldr	x8, [sp, #0x40]
   1412c:      	ldr	x10, [sp, #0x60]
   14130:      	sub	x12, x10, x8
   14134:      	ldr	w23, [sp, #0x68]
   14138:      	subs	w10, w21, w23
   1413c:      	ldr	x9, [sp, #0x88]
   14140:      	ldr	x25, [sp, #0x8]
   14144:      	csel	w10, wzr, w10, lo
   14148:      	cmp	w23, w21
   1414c:      	csel	w11, w23, w21, lo
   14150:      	cinc	w13, w11, hi
   14154:      	sub	w14, w23, w13
   14158:      	subs	x12, x12, x13
   1415c:      	str	w14, [sp, #0x68]
   14160:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   14164:      	cmp	x12, #0xfff
   14168:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   1416c:      	cmp	w23, w21
   14170:      	b.ls	0x1417c <generic_kprobe_path+0xa69c>
   14174:      	mov	w13, #0x2f              // =47
   14178:      	strb	w13, [x8, x12]
   1417c:      	add	x19, x8, x12
   14180:      	cmp	w23, w21
   14184:      	add	x2, x9, x10
   14188:      	and	w1, w11, #0xff
   1418c:      	mov	w8, #0x4                // =4
   14190:      	cinc	x0, x19, hi
   14194:      	blr	x8
   14198:      	ldr	x25, [sp, #0x8]
   1419c:      	cmp	w23, w21
   141a0:      	str	x19, [sp, #0x60]
   141a4:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   141a8:      	ldr	x21, [sp, #0x78]
   141ac:      	ldp	x2, x24, [sp, #0x50]
   141b0:      	str	x21, [sp, #0x48]
   141b4:      	b	0x14208 <generic_kprobe_path+0xa728>
   141b8:      	add	x2, x24, #0x10
   141bc:      	mov	w8, #0x4                // =4
   141c0:      	add	x9, sp, #0x98
   141c4:      	add	x0, sp, #0x98
   141c8:      	mov	w1, #0x8                // =8
   141cc:      	blr	x8
   141d0:      	ldr	x8, [sp, #0x58]
   141d4:      	ldr	x9, [sp, #0x98]
   141d8:      	cmp	x8, x9
   141dc:      	ldr	x25, [sp, #0x8]
   141e0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   141e4:      	add	x2, x24, #0x18
   141e8:      	mov	w8, #0x4                // =4
   141ec:      	mov	x0, x22
   141f0:      	mov	w1, #0x8                // =8
   141f4:      	blr	x8
   141f8:      	ldr	x24, [sp, #0x98]
   141fc:      	ldr	x21, [sp, #0x48]
   14200:      	add	x2, x24, #0x20
   14204:      	stp	x2, x24, [sp, #0x50]
   14208:      	ldr	x8, [sp, #0x30]
   1420c:      	ldr	x25, [sp, #0x8]
   14210:      	add	x9, sp, #0x70
   14214:      	cmp	x21, x8
   14218:      	b.ne	0x14228 <generic_kprobe_path+0xa748>
   1421c:      	ldr	x8, [sp, #0x38]
   14220:      	cmp	x2, x8
   14224:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14228:      	mov	w8, #0x4                // =4
   1422c:      	add	x0, sp, #0x70
   14230:      	mov	w1, #0x8                // =8
   14234:      	blr	x8
   14238:      	ldr	x8, [sp, #0x70]
   1423c:      	cmp	x21, x8
   14240:      	b.eq	0x14334 <generic_kprobe_path+0xa854>
   14244:      	add	x23, x21, #0x18
   14248:      	mov	w8, #0x4                // =4
   1424c:      	add	x9, sp, #0x98
   14250:      	add	x0, sp, #0x98
   14254:      	mov	w1, #0x8                // =8
   14258:      	mov	x2, x23
   1425c:      	blr	x8
   14260:      	ldr	x8, [sp, #0x98]
   14264:      	cmp	x8, x21
   14268:      	b.eq	0x14334 <generic_kprobe_path+0xa854>
   1426c:      	mov	w8, #0x4                // =4
   14270:      	add	x9, sp, #0x78
   14274:      	add	x0, sp, #0x78
   14278:      	mov	w1, #0x8                // =8
   1427c:      	mov	x2, x23
   14280:      	blr	x8
   14284:      	add	x2, x21, #0x20
   14288:      	mov	w8, #0x4                // =4
   1428c:      	mov	w9, #0x10               // =16
   14290:      	add	x10, sp, #0x80
   14294:      	add	x0, sp, #0x80
   14298:      	mov	w1, #0x10               // =16
   1429c:      	blr	x8
   142a0:      	ldr	w21, [sp, #0x84]
   142a4:      	ldr	x8, [sp, #0x40]
   142a8:      	ldr	x10, [sp, #0x60]
   142ac:      	sub	x12, x10, x8
   142b0:      	ldr	w23, [sp, #0x68]
   142b4:      	subs	w10, w21, w23
   142b8:      	ldr	x9, [sp, #0x88]
   142bc:      	ldr	x25, [sp, #0x8]
   142c0:      	csel	w10, wzr, w10, lo
   142c4:      	cmp	w23, w21
   142c8:      	csel	w11, w23, w21, lo
   142cc:      	cinc	w13, w11, hi
   142d0:      	sub	w14, w23, w13
   142d4:      	subs	x12, x12, x13
   142d8:      	str	w14, [sp, #0x68]
   142dc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   142e0:      	cmp	x12, #0xfff
   142e4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   142e8:      	cmp	w23, w21
   142ec:      	b.ls	0x142f8 <generic_kprobe_path+0xa818>
   142f0:      	mov	w13, #0x2f              // =47
   142f4:      	strb	w13, [x8, x12]
   142f8:      	add	x19, x8, x12
   142fc:      	cmp	w23, w21
   14300:      	add	x2, x9, x10
   14304:      	and	w1, w11, #0xff
   14308:      	mov	w8, #0x4                // =4
   1430c:      	cinc	x0, x19, hi
   14310:      	blr	x8
   14314:      	ldr	x25, [sp, #0x8]
   14318:      	cmp	w23, w21
   1431c:      	str	x19, [sp, #0x60]
   14320:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14324:      	ldr	x21, [sp, #0x78]
   14328:      	ldp	x2, x24, [sp, #0x50]
   1432c:      	str	x21, [sp, #0x48]
   14330:      	b	0x14384 <generic_kprobe_path+0xa8a4>
   14334:      	add	x2, x24, #0x10
   14338:      	mov	w8, #0x4                // =4
   1433c:      	add	x9, sp, #0x98
   14340:      	add	x0, sp, #0x98
   14344:      	mov	w1, #0x8                // =8
   14348:      	blr	x8
   1434c:      	ldr	x8, [sp, #0x58]
   14350:      	ldr	x9, [sp, #0x98]
   14354:      	cmp	x8, x9
   14358:      	ldr	x25, [sp, #0x8]
   1435c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14360:      	add	x2, x24, #0x18
   14364:      	mov	w8, #0x4                // =4
   14368:      	mov	x0, x22
   1436c:      	mov	w1, #0x8                // =8
   14370:      	blr	x8
   14374:      	ldr	x24, [sp, #0x98]
   14378:      	ldr	x21, [sp, #0x48]
   1437c:      	add	x2, x24, #0x20
   14380:      	stp	x2, x24, [sp, #0x50]
   14384:      	ldr	x8, [sp, #0x30]
   14388:      	ldr	x25, [sp, #0x8]
   1438c:      	add	x9, sp, #0x70
   14390:      	cmp	x21, x8
   14394:      	b.ne	0x143a4 <generic_kprobe_path+0xa8c4>
   14398:      	ldr	x8, [sp, #0x38]
   1439c:      	cmp	x2, x8
   143a0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   143a4:      	mov	w8, #0x4                // =4
   143a8:      	add	x0, sp, #0x70
   143ac:      	mov	w1, #0x8                // =8
   143b0:      	blr	x8
   143b4:      	ldr	x8, [sp, #0x70]
   143b8:      	cmp	x21, x8
   143bc:      	b.eq	0x144b0 <generic_kprobe_path+0xa9d0>
   143c0:      	add	x23, x21, #0x18
   143c4:      	mov	w8, #0x4                // =4
   143c8:      	add	x9, sp, #0x98
   143cc:      	add	x0, sp, #0x98
   143d0:      	mov	w1, #0x8                // =8
   143d4:      	mov	x2, x23
   143d8:      	blr	x8
   143dc:      	ldr	x8, [sp, #0x98]
   143e0:      	cmp	x8, x21
   143e4:      	b.eq	0x144b0 <generic_kprobe_path+0xa9d0>
   143e8:      	mov	w8, #0x4                // =4
   143ec:      	add	x9, sp, #0x78
   143f0:      	add	x0, sp, #0x78
   143f4:      	mov	w1, #0x8                // =8
   143f8:      	mov	x2, x23
   143fc:      	blr	x8
   14400:      	add	x2, x21, #0x20
   14404:      	mov	w8, #0x4                // =4
   14408:      	mov	w9, #0x10               // =16
   1440c:      	add	x10, sp, #0x80
   14410:      	add	x0, sp, #0x80
   14414:      	mov	w1, #0x10               // =16
   14418:      	blr	x8
   1441c:      	ldr	w21, [sp, #0x84]
   14420:      	ldr	x8, [sp, #0x40]
   14424:      	ldr	x10, [sp, #0x60]
   14428:      	sub	x12, x10, x8
   1442c:      	ldr	w23, [sp, #0x68]
   14430:      	subs	w10, w21, w23
   14434:      	ldr	x9, [sp, #0x88]
   14438:      	ldr	x25, [sp, #0x8]
   1443c:      	csel	w10, wzr, w10, lo
   14440:      	cmp	w23, w21
   14444:      	csel	w11, w23, w21, lo
   14448:      	cinc	w13, w11, hi
   1444c:      	sub	w14, w23, w13
   14450:      	subs	x12, x12, x13
   14454:      	str	w14, [sp, #0x68]
   14458:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   1445c:      	cmp	x12, #0xfff
   14460:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   14464:      	cmp	w23, w21
   14468:      	b.ls	0x14474 <generic_kprobe_path+0xa994>
   1446c:      	mov	w13, #0x2f              // =47
   14470:      	strb	w13, [x8, x12]
   14474:      	add	x19, x8, x12
   14478:      	cmp	w23, w21
   1447c:      	add	x2, x9, x10
   14480:      	and	w1, w11, #0xff
   14484:      	mov	w8, #0x4                // =4
   14488:      	cinc	x0, x19, hi
   1448c:      	blr	x8
   14490:      	ldr	x25, [sp, #0x8]
   14494:      	cmp	w23, w21
   14498:      	str	x19, [sp, #0x60]
   1449c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   144a0:      	ldr	x21, [sp, #0x78]
   144a4:      	ldp	x2, x24, [sp, #0x50]
   144a8:      	str	x21, [sp, #0x48]
   144ac:      	b	0x14500 <generic_kprobe_path+0xaa20>
   144b0:      	add	x2, x24, #0x10
   144b4:      	mov	w8, #0x4                // =4
   144b8:      	add	x9, sp, #0x98
   144bc:      	add	x0, sp, #0x98
   144c0:      	mov	w1, #0x8                // =8
   144c4:      	blr	x8
   144c8:      	ldr	x8, [sp, #0x58]
   144cc:      	ldr	x9, [sp, #0x98]
   144d0:      	cmp	x8, x9
   144d4:      	ldr	x25, [sp, #0x8]
   144d8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   144dc:      	add	x2, x24, #0x18
   144e0:      	mov	w8, #0x4                // =4
   144e4:      	mov	x0, x22
   144e8:      	mov	w1, #0x8                // =8
   144ec:      	blr	x8
   144f0:      	ldr	x24, [sp, #0x98]
   144f4:      	ldr	x21, [sp, #0x48]
   144f8:      	add	x2, x24, #0x20
   144fc:      	stp	x2, x24, [sp, #0x50]
   14500:      	ldr	x8, [sp, #0x30]
   14504:      	ldr	x25, [sp, #0x8]
   14508:      	add	x9, sp, #0x70
   1450c:      	cmp	x21, x8
   14510:      	b.ne	0x14520 <generic_kprobe_path+0xaa40>
   14514:      	ldr	x8, [sp, #0x38]
   14518:      	cmp	x2, x8
   1451c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14520:      	mov	w8, #0x4                // =4
   14524:      	add	x0, sp, #0x70
   14528:      	mov	w1, #0x8                // =8
   1452c:      	blr	x8
   14530:      	ldr	x8, [sp, #0x70]
   14534:      	cmp	x21, x8
   14538:      	b.eq	0x1462c <generic_kprobe_path+0xab4c>
   1453c:      	add	x23, x21, #0x18
   14540:      	mov	w8, #0x4                // =4
   14544:      	add	x9, sp, #0x98
   14548:      	add	x0, sp, #0x98
   1454c:      	mov	w1, #0x8                // =8
   14550:      	mov	x2, x23
   14554:      	blr	x8
   14558:      	ldr	x8, [sp, #0x98]
   1455c:      	cmp	x8, x21
   14560:      	b.eq	0x1462c <generic_kprobe_path+0xab4c>
   14564:      	mov	w8, #0x4                // =4
   14568:      	add	x9, sp, #0x78
   1456c:      	add	x0, sp, #0x78
   14570:      	mov	w1, #0x8                // =8
   14574:      	mov	x2, x23
   14578:      	blr	x8
   1457c:      	add	x2, x21, #0x20
   14580:      	mov	w8, #0x4                // =4
   14584:      	mov	w9, #0x10               // =16
   14588:      	add	x10, sp, #0x80
   1458c:      	add	x0, sp, #0x80
   14590:      	mov	w1, #0x10               // =16
   14594:      	blr	x8
   14598:      	ldr	w21, [sp, #0x84]
   1459c:      	ldr	x8, [sp, #0x40]
   145a0:      	ldr	x10, [sp, #0x60]
   145a4:      	sub	x12, x10, x8
   145a8:      	ldr	w23, [sp, #0x68]
   145ac:      	subs	w10, w21, w23
   145b0:      	ldr	x9, [sp, #0x88]
   145b4:      	ldr	x25, [sp, #0x8]
   145b8:      	csel	w10, wzr, w10, lo
   145bc:      	cmp	w23, w21
   145c0:      	csel	w11, w23, w21, lo
   145c4:      	cinc	w13, w11, hi
   145c8:      	sub	w14, w23, w13
   145cc:      	subs	x12, x12, x13
   145d0:      	str	w14, [sp, #0x68]
   145d4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   145d8:      	cmp	x12, #0xfff
   145dc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   145e0:      	cmp	w23, w21
   145e4:      	b.ls	0x145f0 <generic_kprobe_path+0xab10>
   145e8:      	mov	w13, #0x2f              // =47
   145ec:      	strb	w13, [x8, x12]
   145f0:      	add	x19, x8, x12
   145f4:      	cmp	w23, w21
   145f8:      	add	x2, x9, x10
   145fc:      	and	w1, w11, #0xff
   14600:      	mov	w8, #0x4                // =4
   14604:      	cinc	x0, x19, hi
   14608:      	blr	x8
   1460c:      	ldr	x25, [sp, #0x8]
   14610:      	cmp	w23, w21
   14614:      	str	x19, [sp, #0x60]
   14618:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   1461c:      	ldr	x21, [sp, #0x78]
   14620:      	ldp	x2, x24, [sp, #0x50]
   14624:      	str	x21, [sp, #0x48]
   14628:      	b	0x1467c <generic_kprobe_path+0xab9c>
   1462c:      	add	x2, x24, #0x10
   14630:      	mov	w8, #0x4                // =4
   14634:      	add	x9, sp, #0x98
   14638:      	add	x0, sp, #0x98
   1463c:      	mov	w1, #0x8                // =8
   14640:      	blr	x8
   14644:      	ldr	x8, [sp, #0x58]
   14648:      	ldr	x9, [sp, #0x98]
   1464c:      	cmp	x8, x9
   14650:      	ldr	x25, [sp, #0x8]
   14654:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14658:      	add	x2, x24, #0x18
   1465c:      	mov	w8, #0x4                // =4
   14660:      	mov	x0, x22
   14664:      	mov	w1, #0x8                // =8
   14668:      	blr	x8
   1466c:      	ldr	x24, [sp, #0x98]
   14670:      	ldr	x21, [sp, #0x48]
   14674:      	add	x2, x24, #0x20
   14678:      	stp	x2, x24, [sp, #0x50]
   1467c:      	ldr	x8, [sp, #0x30]
   14680:      	ldr	x25, [sp, #0x8]
   14684:      	add	x9, sp, #0x70
   14688:      	cmp	x21, x8
   1468c:      	b.ne	0x1469c <generic_kprobe_path+0xabbc>
   14690:      	ldr	x8, [sp, #0x38]
   14694:      	cmp	x2, x8
   14698:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1469c:      	mov	w8, #0x4                // =4
   146a0:      	add	x0, sp, #0x70
   146a4:      	mov	w1, #0x8                // =8
   146a8:      	blr	x8
   146ac:      	ldr	x8, [sp, #0x70]
   146b0:      	cmp	x21, x8
   146b4:      	b.eq	0x147a8 <generic_kprobe_path+0xacc8>
   146b8:      	add	x23, x21, #0x18
   146bc:      	mov	w8, #0x4                // =4
   146c0:      	add	x9, sp, #0x98
   146c4:      	add	x0, sp, #0x98
   146c8:      	mov	w1, #0x8                // =8
   146cc:      	mov	x2, x23
   146d0:      	blr	x8
   146d4:      	ldr	x8, [sp, #0x98]
   146d8:      	cmp	x8, x21
   146dc:      	b.eq	0x147a8 <generic_kprobe_path+0xacc8>
   146e0:      	mov	w8, #0x4                // =4
   146e4:      	add	x9, sp, #0x78
   146e8:      	add	x0, sp, #0x78
   146ec:      	mov	w1, #0x8                // =8
   146f0:      	mov	x2, x23
   146f4:      	blr	x8
   146f8:      	add	x2, x21, #0x20
   146fc:      	mov	w8, #0x4                // =4
   14700:      	mov	w9, #0x10               // =16
   14704:      	add	x10, sp, #0x80
   14708:      	add	x0, sp, #0x80
   1470c:      	mov	w1, #0x10               // =16
   14710:      	blr	x8
   14714:      	ldr	w21, [sp, #0x84]
   14718:      	ldr	x8, [sp, #0x40]
   1471c:      	ldr	x10, [sp, #0x60]
   14720:      	sub	x12, x10, x8
   14724:      	ldr	w23, [sp, #0x68]
   14728:      	subs	w10, w21, w23
   1472c:      	ldr	x9, [sp, #0x88]
   14730:      	ldr	x25, [sp, #0x8]
   14734:      	csel	w10, wzr, w10, lo
   14738:      	cmp	w23, w21
   1473c:      	csel	w11, w23, w21, lo
   14740:      	cinc	w13, w11, hi
   14744:      	sub	w14, w23, w13
   14748:      	subs	x12, x12, x13
   1474c:      	str	w14, [sp, #0x68]
   14750:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   14754:      	cmp	x12, #0xfff
   14758:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   1475c:      	cmp	w23, w21
   14760:      	b.ls	0x1476c <generic_kprobe_path+0xac8c>
   14764:      	mov	w13, #0x2f              // =47
   14768:      	strb	w13, [x8, x12]
   1476c:      	add	x19, x8, x12
   14770:      	cmp	w23, w21
   14774:      	add	x2, x9, x10
   14778:      	and	w1, w11, #0xff
   1477c:      	mov	w8, #0x4                // =4
   14780:      	cinc	x0, x19, hi
   14784:      	blr	x8
   14788:      	ldr	x25, [sp, #0x8]
   1478c:      	cmp	w23, w21
   14790:      	str	x19, [sp, #0x60]
   14794:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14798:      	ldr	x21, [sp, #0x78]
   1479c:      	ldp	x2, x24, [sp, #0x50]
   147a0:      	str	x21, [sp, #0x48]
   147a4:      	b	0x147f8 <generic_kprobe_path+0xad18>
   147a8:      	add	x2, x24, #0x10
   147ac:      	mov	w8, #0x4                // =4
   147b0:      	add	x9, sp, #0x98
   147b4:      	add	x0, sp, #0x98
   147b8:      	mov	w1, #0x8                // =8
   147bc:      	blr	x8
   147c0:      	ldr	x8, [sp, #0x58]
   147c4:      	ldr	x9, [sp, #0x98]
   147c8:      	cmp	x8, x9
   147cc:      	ldr	x25, [sp, #0x8]
   147d0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   147d4:      	add	x2, x24, #0x18
   147d8:      	mov	w8, #0x4                // =4
   147dc:      	mov	x0, x22
   147e0:      	mov	w1, #0x8                // =8
   147e4:      	blr	x8
   147e8:      	ldr	x24, [sp, #0x98]
   147ec:      	ldr	x21, [sp, #0x48]
   147f0:      	add	x2, x24, #0x20
   147f4:      	stp	x2, x24, [sp, #0x50]
   147f8:      	ldr	x8, [sp, #0x30]
   147fc:      	ldr	x25, [sp, #0x8]
   14800:      	add	x9, sp, #0x70
   14804:      	cmp	x21, x8
   14808:      	b.ne	0x14818 <generic_kprobe_path+0xad38>
   1480c:      	ldr	x8, [sp, #0x38]
   14810:      	cmp	x2, x8
   14814:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14818:      	mov	w8, #0x4                // =4
   1481c:      	add	x0, sp, #0x70
   14820:      	mov	w1, #0x8                // =8
   14824:      	blr	x8
   14828:      	ldr	x8, [sp, #0x70]
   1482c:      	cmp	x21, x8
   14830:      	b.eq	0x14924 <generic_kprobe_path+0xae44>
   14834:      	add	x23, x21, #0x18
   14838:      	mov	w8, #0x4                // =4
   1483c:      	add	x9, sp, #0x98
   14840:      	add	x0, sp, #0x98
   14844:      	mov	w1, #0x8                // =8
   14848:      	mov	x2, x23
   1484c:      	blr	x8
   14850:      	ldr	x8, [sp, #0x98]
   14854:      	cmp	x8, x21
   14858:      	b.eq	0x14924 <generic_kprobe_path+0xae44>
   1485c:      	mov	w8, #0x4                // =4
   14860:      	add	x9, sp, #0x78
   14864:      	add	x0, sp, #0x78
   14868:      	mov	w1, #0x8                // =8
   1486c:      	mov	x2, x23
   14870:      	blr	x8
   14874:      	add	x2, x21, #0x20
   14878:      	mov	w8, #0x4                // =4
   1487c:      	mov	w9, #0x10               // =16
   14880:      	add	x10, sp, #0x80
   14884:      	add	x0, sp, #0x80
   14888:      	mov	w1, #0x10               // =16
   1488c:      	blr	x8
   14890:      	ldr	w21, [sp, #0x84]
   14894:      	ldr	x8, [sp, #0x40]
   14898:      	ldr	x10, [sp, #0x60]
   1489c:      	sub	x12, x10, x8
   148a0:      	ldr	w23, [sp, #0x68]
   148a4:      	subs	w10, w21, w23
   148a8:      	ldr	x9, [sp, #0x88]
   148ac:      	ldr	x25, [sp, #0x8]
   148b0:      	csel	w10, wzr, w10, lo
   148b4:      	cmp	w23, w21
   148b8:      	csel	w11, w23, w21, lo
   148bc:      	cinc	w13, w11, hi
   148c0:      	sub	w14, w23, w13
   148c4:      	subs	x12, x12, x13
   148c8:      	str	w14, [sp, #0x68]
   148cc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   148d0:      	cmp	x12, #0xfff
   148d4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   148d8:      	cmp	w23, w21
   148dc:      	b.ls	0x148e8 <generic_kprobe_path+0xae08>
   148e0:      	mov	w13, #0x2f              // =47
   148e4:      	strb	w13, [x8, x12]
   148e8:      	add	x19, x8, x12
   148ec:      	cmp	w23, w21
   148f0:      	add	x2, x9, x10
   148f4:      	and	w1, w11, #0xff
   148f8:      	mov	w8, #0x4                // =4
   148fc:      	cinc	x0, x19, hi
   14900:      	blr	x8
   14904:      	ldr	x25, [sp, #0x8]
   14908:      	cmp	w23, w21
   1490c:      	str	x19, [sp, #0x60]
   14910:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14914:      	ldr	x21, [sp, #0x78]
   14918:      	ldp	x2, x24, [sp, #0x50]
   1491c:      	str	x21, [sp, #0x48]
   14920:      	b	0x14974 <generic_kprobe_path+0xae94>
   14924:      	add	x2, x24, #0x10
   14928:      	mov	w8, #0x4                // =4
   1492c:      	add	x9, sp, #0x98
   14930:      	add	x0, sp, #0x98
   14934:      	mov	w1, #0x8                // =8
   14938:      	blr	x8
   1493c:      	ldr	x8, [sp, #0x58]
   14940:      	ldr	x9, [sp, #0x98]
   14944:      	cmp	x8, x9
   14948:      	ldr	x25, [sp, #0x8]
   1494c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14950:      	add	x2, x24, #0x18
   14954:      	mov	w8, #0x4                // =4
   14958:      	mov	x0, x22
   1495c:      	mov	w1, #0x8                // =8
   14960:      	blr	x8
   14964:      	ldr	x24, [sp, #0x98]
   14968:      	ldr	x21, [sp, #0x48]
   1496c:      	add	x2, x24, #0x20
   14970:      	stp	x2, x24, [sp, #0x50]
   14974:      	ldr	x8, [sp, #0x30]
   14978:      	ldr	x25, [sp, #0x8]
   1497c:      	add	x9, sp, #0x70
   14980:      	cmp	x21, x8
   14984:      	b.ne	0x14994 <generic_kprobe_path+0xaeb4>
   14988:      	ldr	x8, [sp, #0x38]
   1498c:      	cmp	x2, x8
   14990:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14994:      	mov	w8, #0x4                // =4
   14998:      	add	x0, sp, #0x70
   1499c:      	mov	w1, #0x8                // =8
   149a0:      	blr	x8
   149a4:      	ldr	x8, [sp, #0x70]
   149a8:      	cmp	x21, x8
   149ac:      	b.eq	0x14aa0 <generic_kprobe_path+0xafc0>
   149b0:      	add	x23, x21, #0x18
   149b4:      	mov	w8, #0x4                // =4
   149b8:      	add	x9, sp, #0x98
   149bc:      	add	x0, sp, #0x98
   149c0:      	mov	w1, #0x8                // =8
   149c4:      	mov	x2, x23
   149c8:      	blr	x8
   149cc:      	ldr	x8, [sp, #0x98]
   149d0:      	cmp	x8, x21
   149d4:      	b.eq	0x14aa0 <generic_kprobe_path+0xafc0>
   149d8:      	mov	w8, #0x4                // =4
   149dc:      	add	x9, sp, #0x78
   149e0:      	add	x0, sp, #0x78
   149e4:      	mov	w1, #0x8                // =8
   149e8:      	mov	x2, x23
   149ec:      	blr	x8
   149f0:      	add	x2, x21, #0x20
   149f4:      	mov	w8, #0x4                // =4
   149f8:      	mov	w9, #0x10               // =16
   149fc:      	add	x10, sp, #0x80
   14a00:      	add	x0, sp, #0x80
   14a04:      	mov	w1, #0x10               // =16
   14a08:      	blr	x8
   14a0c:      	ldr	w21, [sp, #0x84]
   14a10:      	ldr	x8, [sp, #0x40]
   14a14:      	ldr	x10, [sp, #0x60]
   14a18:      	sub	x12, x10, x8
   14a1c:      	ldr	w23, [sp, #0x68]
   14a20:      	subs	w10, w21, w23
   14a24:      	ldr	x9, [sp, #0x88]
   14a28:      	ldr	x25, [sp, #0x8]
   14a2c:      	csel	w10, wzr, w10, lo
   14a30:      	cmp	w23, w21
   14a34:      	csel	w11, w23, w21, lo
   14a38:      	cinc	w13, w11, hi
   14a3c:      	sub	w14, w23, w13
   14a40:      	subs	x12, x12, x13
   14a44:      	str	w14, [sp, #0x68]
   14a48:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   14a4c:      	cmp	x12, #0xfff
   14a50:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   14a54:      	cmp	w23, w21
   14a58:      	b.ls	0x14a64 <generic_kprobe_path+0xaf84>
   14a5c:      	mov	w13, #0x2f              // =47
   14a60:      	strb	w13, [x8, x12]
   14a64:      	add	x19, x8, x12
   14a68:      	cmp	w23, w21
   14a6c:      	add	x2, x9, x10
   14a70:      	and	w1, w11, #0xff
   14a74:      	mov	w8, #0x4                // =4
   14a78:      	cinc	x0, x19, hi
   14a7c:      	blr	x8
   14a80:      	ldr	x25, [sp, #0x8]
   14a84:      	cmp	w23, w21
   14a88:      	str	x19, [sp, #0x60]
   14a8c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14a90:      	ldr	x21, [sp, #0x78]
   14a94:      	ldp	x2, x24, [sp, #0x50]
   14a98:      	str	x21, [sp, #0x48]
   14a9c:      	b	0x14af0 <generic_kprobe_path+0xb010>
   14aa0:      	add	x2, x24, #0x10
   14aa4:      	mov	w8, #0x4                // =4
   14aa8:      	add	x9, sp, #0x98
   14aac:      	add	x0, sp, #0x98
   14ab0:      	mov	w1, #0x8                // =8
   14ab4:      	blr	x8
   14ab8:      	ldr	x8, [sp, #0x58]
   14abc:      	ldr	x9, [sp, #0x98]
   14ac0:      	cmp	x8, x9
   14ac4:      	ldr	x25, [sp, #0x8]
   14ac8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14acc:      	add	x2, x24, #0x18
   14ad0:      	mov	w8, #0x4                // =4
   14ad4:      	mov	x0, x22
   14ad8:      	mov	w1, #0x8                // =8
   14adc:      	blr	x8
   14ae0:      	ldr	x24, [sp, #0x98]
   14ae4:      	ldr	x21, [sp, #0x48]
   14ae8:      	add	x2, x24, #0x20
   14aec:      	stp	x2, x24, [sp, #0x50]
   14af0:      	ldr	x8, [sp, #0x30]
   14af4:      	ldr	x25, [sp, #0x8]
   14af8:      	add	x9, sp, #0x70
   14afc:      	cmp	x21, x8
   14b00:      	b.ne	0x14b10 <generic_kprobe_path+0xb030>
   14b04:      	ldr	x8, [sp, #0x38]
   14b08:      	cmp	x2, x8
   14b0c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14b10:      	mov	w8, #0x4                // =4
   14b14:      	add	x0, sp, #0x70
   14b18:      	mov	w1, #0x8                // =8
   14b1c:      	blr	x8
   14b20:      	ldr	x8, [sp, #0x70]
   14b24:      	cmp	x21, x8
   14b28:      	b.eq	0x14c1c <generic_kprobe_path+0xb13c>
   14b2c:      	add	x23, x21, #0x18
   14b30:      	mov	w8, #0x4                // =4
   14b34:      	add	x9, sp, #0x98
   14b38:      	add	x0, sp, #0x98
   14b3c:      	mov	w1, #0x8                // =8
   14b40:      	mov	x2, x23
   14b44:      	blr	x8
   14b48:      	ldr	x8, [sp, #0x98]
   14b4c:      	cmp	x8, x21
   14b50:      	b.eq	0x14c1c <generic_kprobe_path+0xb13c>
   14b54:      	mov	w8, #0x4                // =4
   14b58:      	add	x9, sp, #0x78
   14b5c:      	add	x0, sp, #0x78
   14b60:      	mov	w1, #0x8                // =8
   14b64:      	mov	x2, x23
   14b68:      	blr	x8
   14b6c:      	add	x2, x21, #0x20
   14b70:      	mov	w8, #0x4                // =4
   14b74:      	mov	w9, #0x10               // =16
   14b78:      	add	x10, sp, #0x80
   14b7c:      	add	x0, sp, #0x80
   14b80:      	mov	w1, #0x10               // =16
   14b84:      	blr	x8
   14b88:      	ldr	w21, [sp, #0x84]
   14b8c:      	ldr	x8, [sp, #0x40]
   14b90:      	ldr	x10, [sp, #0x60]
   14b94:      	sub	x12, x10, x8
   14b98:      	ldr	w23, [sp, #0x68]
   14b9c:      	subs	w10, w21, w23
   14ba0:      	ldr	x9, [sp, #0x88]
   14ba4:      	ldr	x25, [sp, #0x8]
   14ba8:      	csel	w10, wzr, w10, lo
   14bac:      	cmp	w23, w21
   14bb0:      	csel	w11, w23, w21, lo
   14bb4:      	cinc	w13, w11, hi
   14bb8:      	sub	w14, w23, w13
   14bbc:      	subs	x12, x12, x13
   14bc0:      	str	w14, [sp, #0x68]
   14bc4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   14bc8:      	cmp	x12, #0xfff
   14bcc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   14bd0:      	cmp	w23, w21
   14bd4:      	b.ls	0x14be0 <generic_kprobe_path+0xb100>
   14bd8:      	mov	w13, #0x2f              // =47
   14bdc:      	strb	w13, [x8, x12]
   14be0:      	add	x19, x8, x12
   14be4:      	cmp	w23, w21
   14be8:      	add	x2, x9, x10
   14bec:      	and	w1, w11, #0xff
   14bf0:      	mov	w8, #0x4                // =4
   14bf4:      	cinc	x0, x19, hi
   14bf8:      	blr	x8
   14bfc:      	ldr	x25, [sp, #0x8]
   14c00:      	cmp	w23, w21
   14c04:      	str	x19, [sp, #0x60]
   14c08:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14c0c:      	ldr	x21, [sp, #0x78]
   14c10:      	ldp	x2, x24, [sp, #0x50]
   14c14:      	str	x21, [sp, #0x48]
   14c18:      	b	0x14c6c <generic_kprobe_path+0xb18c>
   14c1c:      	add	x2, x24, #0x10
   14c20:      	mov	w8, #0x4                // =4
   14c24:      	add	x9, sp, #0x98
   14c28:      	add	x0, sp, #0x98
   14c2c:      	mov	w1, #0x8                // =8
   14c30:      	blr	x8
   14c34:      	ldr	x8, [sp, #0x58]
   14c38:      	ldr	x9, [sp, #0x98]
   14c3c:      	cmp	x8, x9
   14c40:      	ldr	x25, [sp, #0x8]
   14c44:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14c48:      	add	x2, x24, #0x18
   14c4c:      	mov	w8, #0x4                // =4
   14c50:      	mov	x0, x22
   14c54:      	mov	w1, #0x8                // =8
   14c58:      	blr	x8
   14c5c:      	ldr	x24, [sp, #0x98]
   14c60:      	ldr	x21, [sp, #0x48]
   14c64:      	add	x2, x24, #0x20
   14c68:      	stp	x2, x24, [sp, #0x50]
   14c6c:      	ldr	x8, [sp, #0x30]
   14c70:      	ldr	x25, [sp, #0x8]
   14c74:      	add	x9, sp, #0x70
   14c78:      	cmp	x21, x8
   14c7c:      	b.ne	0x14c8c <generic_kprobe_path+0xb1ac>
   14c80:      	ldr	x8, [sp, #0x38]
   14c84:      	cmp	x2, x8
   14c88:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14c8c:      	mov	w8, #0x4                // =4
   14c90:      	add	x0, sp, #0x70
   14c94:      	mov	w1, #0x8                // =8
   14c98:      	blr	x8
   14c9c:      	ldr	x8, [sp, #0x70]
   14ca0:      	cmp	x21, x8
   14ca4:      	b.eq	0x14d98 <generic_kprobe_path+0xb2b8>
   14ca8:      	add	x23, x21, #0x18
   14cac:      	mov	w8, #0x4                // =4
   14cb0:      	add	x9, sp, #0x98
   14cb4:      	add	x0, sp, #0x98
   14cb8:      	mov	w1, #0x8                // =8
   14cbc:      	mov	x2, x23
   14cc0:      	blr	x8
   14cc4:      	ldr	x8, [sp, #0x98]
   14cc8:      	cmp	x8, x21
   14ccc:      	b.eq	0x14d98 <generic_kprobe_path+0xb2b8>
   14cd0:      	mov	w8, #0x4                // =4
   14cd4:      	add	x9, sp, #0x78
   14cd8:      	add	x0, sp, #0x78
   14cdc:      	mov	w1, #0x8                // =8
   14ce0:      	mov	x2, x23
   14ce4:      	blr	x8
   14ce8:      	add	x2, x21, #0x20
   14cec:      	mov	w8, #0x4                // =4
   14cf0:      	mov	w9, #0x10               // =16
   14cf4:      	add	x10, sp, #0x80
   14cf8:      	add	x0, sp, #0x80
   14cfc:      	mov	w1, #0x10               // =16
   14d00:      	blr	x8
   14d04:      	ldr	w21, [sp, #0x84]
   14d08:      	ldr	x8, [sp, #0x40]
   14d0c:      	ldr	x10, [sp, #0x60]
   14d10:      	sub	x12, x10, x8
   14d14:      	ldr	w23, [sp, #0x68]
   14d18:      	subs	w10, w21, w23
   14d1c:      	ldr	x9, [sp, #0x88]
   14d20:      	ldr	x25, [sp, #0x8]
   14d24:      	csel	w10, wzr, w10, lo
   14d28:      	cmp	w23, w21
   14d2c:      	csel	w11, w23, w21, lo
   14d30:      	cinc	w13, w11, hi
   14d34:      	sub	w14, w23, w13
   14d38:      	subs	x12, x12, x13
   14d3c:      	str	w14, [sp, #0x68]
   14d40:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   14d44:      	cmp	x12, #0xfff
   14d48:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   14d4c:      	cmp	w23, w21
   14d50:      	b.ls	0x14d5c <generic_kprobe_path+0xb27c>
   14d54:      	mov	w13, #0x2f              // =47
   14d58:      	strb	w13, [x8, x12]
   14d5c:      	add	x19, x8, x12
   14d60:      	cmp	w23, w21
   14d64:      	add	x2, x9, x10
   14d68:      	and	w1, w11, #0xff
   14d6c:      	mov	w8, #0x4                // =4
   14d70:      	cinc	x0, x19, hi
   14d74:      	blr	x8
   14d78:      	ldr	x25, [sp, #0x8]
   14d7c:      	cmp	w23, w21
   14d80:      	str	x19, [sp, #0x60]
   14d84:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14d88:      	ldr	x21, [sp, #0x78]
   14d8c:      	ldp	x2, x24, [sp, #0x50]
   14d90:      	str	x21, [sp, #0x48]
   14d94:      	b	0x14de8 <generic_kprobe_path+0xb308>
   14d98:      	add	x2, x24, #0x10
   14d9c:      	mov	w8, #0x4                // =4
   14da0:      	add	x9, sp, #0x98
   14da4:      	add	x0, sp, #0x98
   14da8:      	mov	w1, #0x8                // =8
   14dac:      	blr	x8
   14db0:      	ldr	x8, [sp, #0x58]
   14db4:      	ldr	x9, [sp, #0x98]
   14db8:      	cmp	x8, x9
   14dbc:      	ldr	x25, [sp, #0x8]
   14dc0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14dc4:      	add	x2, x24, #0x18
   14dc8:      	mov	w8, #0x4                // =4
   14dcc:      	mov	x0, x22
   14dd0:      	mov	w1, #0x8                // =8
   14dd4:      	blr	x8
   14dd8:      	ldr	x24, [sp, #0x98]
   14ddc:      	ldr	x21, [sp, #0x48]
   14de0:      	add	x2, x24, #0x20
   14de4:      	stp	x2, x24, [sp, #0x50]
   14de8:      	ldr	x8, [sp, #0x30]
   14dec:      	ldr	x25, [sp, #0x8]
   14df0:      	add	x9, sp, #0x70
   14df4:      	cmp	x21, x8
   14df8:      	b.ne	0x14e08 <generic_kprobe_path+0xb328>
   14dfc:      	ldr	x8, [sp, #0x38]
   14e00:      	cmp	x2, x8
   14e04:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14e08:      	mov	w8, #0x4                // =4
   14e0c:      	add	x0, sp, #0x70
   14e10:      	mov	w1, #0x8                // =8
   14e14:      	blr	x8
   14e18:      	ldr	x8, [sp, #0x70]
   14e1c:      	cmp	x21, x8
   14e20:      	b.eq	0x14f14 <generic_kprobe_path+0xb434>
   14e24:      	add	x23, x21, #0x18
   14e28:      	mov	w8, #0x4                // =4
   14e2c:      	add	x9, sp, #0x98
   14e30:      	add	x0, sp, #0x98
   14e34:      	mov	w1, #0x8                // =8
   14e38:      	mov	x2, x23
   14e3c:      	blr	x8
   14e40:      	ldr	x8, [sp, #0x98]
   14e44:      	cmp	x8, x21
   14e48:      	b.eq	0x14f14 <generic_kprobe_path+0xb434>
   14e4c:      	mov	w8, #0x4                // =4
   14e50:      	add	x9, sp, #0x78
   14e54:      	add	x0, sp, #0x78
   14e58:      	mov	w1, #0x8                // =8
   14e5c:      	mov	x2, x23
   14e60:      	blr	x8
   14e64:      	add	x2, x21, #0x20
   14e68:      	mov	w8, #0x4                // =4
   14e6c:      	mov	w9, #0x10               // =16
   14e70:      	add	x10, sp, #0x80
   14e74:      	add	x0, sp, #0x80
   14e78:      	mov	w1, #0x10               // =16
   14e7c:      	blr	x8
   14e80:      	ldr	w21, [sp, #0x84]
   14e84:      	ldr	x8, [sp, #0x40]
   14e88:      	ldr	x10, [sp, #0x60]
   14e8c:      	sub	x12, x10, x8
   14e90:      	ldr	w23, [sp, #0x68]
   14e94:      	subs	w10, w21, w23
   14e98:      	ldr	x9, [sp, #0x88]
   14e9c:      	ldr	x25, [sp, #0x8]
   14ea0:      	csel	w10, wzr, w10, lo
   14ea4:      	cmp	w23, w21
   14ea8:      	csel	w11, w23, w21, lo
   14eac:      	cinc	w13, w11, hi
   14eb0:      	sub	w14, w23, w13
   14eb4:      	subs	x12, x12, x13
   14eb8:      	str	w14, [sp, #0x68]
   14ebc:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   14ec0:      	cmp	x12, #0xfff
   14ec4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   14ec8:      	cmp	w23, w21
   14ecc:      	b.ls	0x14ed8 <generic_kprobe_path+0xb3f8>
   14ed0:      	mov	w13, #0x2f              // =47
   14ed4:      	strb	w13, [x8, x12]
   14ed8:      	add	x19, x8, x12
   14edc:      	cmp	w23, w21
   14ee0:      	add	x2, x9, x10
   14ee4:      	and	w1, w11, #0xff
   14ee8:      	mov	w8, #0x4                // =4
   14eec:      	cinc	x0, x19, hi
   14ef0:      	blr	x8
   14ef4:      	ldr	x25, [sp, #0x8]
   14ef8:      	cmp	w23, w21
   14efc:      	str	x19, [sp, #0x60]
   14f00:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   14f04:      	ldr	x21, [sp, #0x78]
   14f08:      	ldp	x2, x24, [sp, #0x50]
   14f0c:      	str	x21, [sp, #0x48]
   14f10:      	b	0x14f64 <generic_kprobe_path+0xb484>
   14f14:      	add	x2, x24, #0x10
   14f18:      	mov	w8, #0x4                // =4
   14f1c:      	add	x9, sp, #0x98
   14f20:      	add	x0, sp, #0x98
   14f24:      	mov	w1, #0x8                // =8
   14f28:      	blr	x8
   14f2c:      	ldr	x8, [sp, #0x58]
   14f30:      	ldr	x9, [sp, #0x98]
   14f34:      	cmp	x8, x9
   14f38:      	ldr	x25, [sp, #0x8]
   14f3c:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14f40:      	add	x2, x24, #0x18
   14f44:      	mov	w8, #0x4                // =4
   14f48:      	mov	x0, x22
   14f4c:      	mov	w1, #0x8                // =8
   14f50:      	blr	x8
   14f54:      	ldr	x24, [sp, #0x98]
   14f58:      	ldr	x21, [sp, #0x48]
   14f5c:      	add	x2, x24, #0x20
   14f60:      	stp	x2, x24, [sp, #0x50]
   14f64:      	ldr	x8, [sp, #0x30]
   14f68:      	ldr	x25, [sp, #0x8]
   14f6c:      	add	x9, sp, #0x70
   14f70:      	cmp	x21, x8
   14f74:      	b.ne	0x14f84 <generic_kprobe_path+0xb4a4>
   14f78:      	ldr	x8, [sp, #0x38]
   14f7c:      	cmp	x2, x8
   14f80:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   14f84:      	mov	w8, #0x4                // =4
   14f88:      	add	x0, sp, #0x70
   14f8c:      	mov	w1, #0x8                // =8
   14f90:      	blr	x8
   14f94:      	ldr	x8, [sp, #0x70]
   14f98:      	cmp	x21, x8
   14f9c:      	b.eq	0x15090 <generic_kprobe_path+0xb5b0>
   14fa0:      	add	x23, x21, #0x18
   14fa4:      	mov	w8, #0x4                // =4
   14fa8:      	add	x9, sp, #0x98
   14fac:      	add	x0, sp, #0x98
   14fb0:      	mov	w1, #0x8                // =8
   14fb4:      	mov	x2, x23
   14fb8:      	blr	x8
   14fbc:      	ldr	x8, [sp, #0x98]
   14fc0:      	cmp	x8, x21
   14fc4:      	b.eq	0x15090 <generic_kprobe_path+0xb5b0>
   14fc8:      	mov	w8, #0x4                // =4
   14fcc:      	add	x9, sp, #0x78
   14fd0:      	add	x0, sp, #0x78
   14fd4:      	mov	w1, #0x8                // =8
   14fd8:      	mov	x2, x23
   14fdc:      	blr	x8
   14fe0:      	add	x2, x21, #0x20
   14fe4:      	mov	w8, #0x4                // =4
   14fe8:      	mov	w9, #0x10               // =16
   14fec:      	add	x10, sp, #0x80
   14ff0:      	add	x0, sp, #0x80
   14ff4:      	mov	w1, #0x10               // =16
   14ff8:      	blr	x8
   14ffc:      	ldr	w21, [sp, #0x84]
   15000:      	ldr	x8, [sp, #0x40]
   15004:      	ldr	x10, [sp, #0x60]
   15008:      	sub	x12, x10, x8
   1500c:      	ldr	w23, [sp, #0x68]
   15010:      	subs	w10, w21, w23
   15014:      	ldr	x9, [sp, #0x88]
   15018:      	ldr	x25, [sp, #0x8]
   1501c:      	csel	w10, wzr, w10, lo
   15020:      	cmp	w23, w21
   15024:      	csel	w11, w23, w21, lo
   15028:      	cinc	w13, w11, hi
   1502c:      	sub	w14, w23, w13
   15030:      	subs	x12, x12, x13
   15034:      	str	w14, [sp, #0x68]
   15038:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   1503c:      	cmp	x12, #0xfff
   15040:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   15044:      	cmp	w23, w21
   15048:      	b.ls	0x15054 <generic_kprobe_path+0xb574>
   1504c:      	mov	w13, #0x2f              // =47
   15050:      	strb	w13, [x8, x12]
   15054:      	add	x19, x8, x12
   15058:      	cmp	w23, w21
   1505c:      	add	x2, x9, x10
   15060:      	and	w1, w11, #0xff
   15064:      	mov	w8, #0x4                // =4
   15068:      	cinc	x0, x19, hi
   1506c:      	blr	x8
   15070:      	ldr	x25, [sp, #0x8]
   15074:      	cmp	w23, w21
   15078:      	str	x19, [sp, #0x60]
   1507c:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   15080:      	ldr	x21, [sp, #0x78]
   15084:      	ldp	x2, x24, [sp, #0x50]
   15088:      	str	x21, [sp, #0x48]
   1508c:      	b	0x150e0 <generic_kprobe_path+0xb600>
   15090:      	add	x2, x24, #0x10
   15094:      	mov	w8, #0x4                // =4
   15098:      	add	x9, sp, #0x98
   1509c:      	add	x0, sp, #0x98
   150a0:      	mov	w1, #0x8                // =8
   150a4:      	blr	x8
   150a8:      	ldr	x8, [sp, #0x58]
   150ac:      	ldr	x9, [sp, #0x98]
   150b0:      	cmp	x8, x9
   150b4:      	ldr	x25, [sp, #0x8]
   150b8:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   150bc:      	add	x2, x24, #0x18
   150c0:      	mov	w8, #0x4                // =4
   150c4:      	mov	x0, x22
   150c8:      	mov	w1, #0x8                // =8
   150cc:      	blr	x8
   150d0:      	ldr	x24, [sp, #0x98]
   150d4:      	ldr	x21, [sp, #0x48]
   150d8:      	add	x2, x24, #0x20
   150dc:      	stp	x2, x24, [sp, #0x50]
   150e0:      	ldr	x8, [sp, #0x30]
   150e4:      	ldr	x25, [sp, #0x8]
   150e8:      	add	x9, sp, #0x70
   150ec:      	cmp	x21, x8
   150f0:      	b.ne	0x15100 <generic_kprobe_path+0xb620>
   150f4:      	ldr	x8, [sp, #0x38]
   150f8:      	cmp	x2, x8
   150fc:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   15100:      	mov	w8, #0x4                // =4
   15104:      	add	x0, sp, #0x70
   15108:      	mov	w1, #0x8                // =8
   1510c:      	blr	x8
   15110:      	ldr	x8, [sp, #0x70]
   15114:      	cmp	x21, x8
   15118:      	b.eq	0x1520c <generic_kprobe_path+0xb72c>
   1511c:      	add	x23, x21, #0x18
   15120:      	mov	w8, #0x4                // =4
   15124:      	add	x9, sp, #0x98
   15128:      	add	x0, sp, #0x98
   1512c:      	mov	w1, #0x8                // =8
   15130:      	mov	x2, x23
   15134:      	blr	x8
   15138:      	ldr	x8, [sp, #0x98]
   1513c:      	cmp	x8, x21
   15140:      	b.eq	0x1520c <generic_kprobe_path+0xb72c>
   15144:      	mov	w8, #0x4                // =4
   15148:      	add	x9, sp, #0x78
   1514c:      	add	x0, sp, #0x78
   15150:      	mov	w1, #0x8                // =8
   15154:      	mov	x2, x23
   15158:      	blr	x8
   1515c:      	add	x2, x21, #0x20
   15160:      	mov	w8, #0x4                // =4
   15164:      	mov	w9, #0x10               // =16
   15168:      	add	x10, sp, #0x80
   1516c:      	add	x0, sp, #0x80
   15170:      	mov	w1, #0x10               // =16
   15174:      	blr	x8
   15178:      	ldr	w21, [sp, #0x84]
   1517c:      	ldr	x8, [sp, #0x40]
   15180:      	ldr	x10, [sp, #0x60]
   15184:      	sub	x12, x10, x8
   15188:      	ldr	w23, [sp, #0x68]
   1518c:      	subs	w10, w21, w23
   15190:      	ldr	x9, [sp, #0x88]
   15194:      	ldr	x25, [sp, #0x8]
   15198:      	csel	w10, wzr, w10, lo
   1519c:      	cmp	w23, w21
   151a0:      	csel	w11, w23, w21, lo
   151a4:      	cinc	w13, w11, hi
   151a8:      	sub	w14, w23, w13
   151ac:      	subs	x12, x12, x13
   151b0:      	str	w14, [sp, #0x68]
   151b4:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   151b8:      	cmp	x12, #0xfff
   151bc:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   151c0:      	cmp	w23, w21
   151c4:      	b.ls	0x151d0 <generic_kprobe_path+0xb6f0>
   151c8:      	mov	w13, #0x2f              // =47
   151cc:      	strb	w13, [x8, x12]
   151d0:      	add	x19, x8, x12
   151d4:      	cmp	w23, w21
   151d8:      	add	x2, x9, x10
   151dc:      	and	w1, w11, #0xff
   151e0:      	mov	w8, #0x4                // =4
   151e4:      	cinc	x0, x19, hi
   151e8:      	blr	x8
   151ec:      	ldr	x25, [sp, #0x8]
   151f0:      	cmp	w23, w21
   151f4:      	str	x19, [sp, #0x60]
   151f8:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   151fc:      	ldr	x21, [sp, #0x78]
   15200:      	ldp	x2, x24, [sp, #0x50]
   15204:      	str	x21, [sp, #0x48]
   15208:      	b	0x1525c <generic_kprobe_path+0xb77c>
   1520c:      	add	x2, x24, #0x10
   15210:      	mov	w8, #0x4                // =4
   15214:      	add	x9, sp, #0x98
   15218:      	add	x0, sp, #0x98
   1521c:      	mov	w1, #0x8                // =8
   15220:      	blr	x8
   15224:      	ldr	x8, [sp, #0x58]
   15228:      	ldr	x9, [sp, #0x98]
   1522c:      	cmp	x8, x9
   15230:      	ldr	x25, [sp, #0x8]
   15234:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   15238:      	add	x2, x24, #0x18
   1523c:      	mov	w8, #0x4                // =4
   15240:      	mov	x0, x22
   15244:      	mov	w1, #0x8                // =8
   15248:      	blr	x8
   1524c:      	ldr	x24, [sp, #0x98]
   15250:      	ldr	x21, [sp, #0x48]
   15254:      	add	x2, x24, #0x20
   15258:      	stp	x2, x24, [sp, #0x50]
   1525c:      	ldr	x8, [sp, #0x30]
   15260:      	ldr	x25, [sp, #0x8]
   15264:      	add	x9, sp, #0x70
   15268:      	cmp	x21, x8
   1526c:      	b.ne	0x1527c <generic_kprobe_path+0xb79c>
   15270:      	ldr	x8, [sp, #0x38]
   15274:      	cmp	x2, x8
   15278:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1527c:      	mov	w8, #0x4                // =4
   15280:      	add	x0, sp, #0x70
   15284:      	mov	w1, #0x8                // =8
   15288:      	blr	x8
   1528c:      	ldr	x8, [sp, #0x70]
   15290:      	cmp	x21, x8
   15294:      	b.eq	0x15388 <generic_kprobe_path+0xb8a8>
   15298:      	add	x23, x21, #0x18
   1529c:      	mov	w8, #0x4                // =4
   152a0:      	add	x9, sp, #0x98
   152a4:      	add	x0, sp, #0x98
   152a8:      	mov	w1, #0x8                // =8
   152ac:      	mov	x2, x23
   152b0:      	blr	x8
   152b4:      	ldr	x8, [sp, #0x98]
   152b8:      	cmp	x8, x21
   152bc:      	b.eq	0x15388 <generic_kprobe_path+0xb8a8>
   152c0:      	mov	w8, #0x4                // =4
   152c4:      	add	x9, sp, #0x78
   152c8:      	add	x0, sp, #0x78
   152cc:      	mov	w1, #0x8                // =8
   152d0:      	mov	x2, x23
   152d4:      	blr	x8
   152d8:      	add	x2, x21, #0x20
   152dc:      	mov	w8, #0x4                // =4
   152e0:      	mov	w9, #0x10               // =16
   152e4:      	add	x10, sp, #0x80
   152e8:      	add	x0, sp, #0x80
   152ec:      	mov	w1, #0x10               // =16
   152f0:      	blr	x8
   152f4:      	ldr	w21, [sp, #0x84]
   152f8:      	ldr	x8, [sp, #0x40]
   152fc:      	ldr	x10, [sp, #0x60]
   15300:      	sub	x12, x10, x8
   15304:      	ldr	w23, [sp, #0x68]
   15308:      	subs	w10, w21, w23
   1530c:      	ldr	x9, [sp, #0x88]
   15310:      	ldr	x25, [sp, #0x8]
   15314:      	csel	w10, wzr, w10, lo
   15318:      	cmp	w23, w21
   1531c:      	csel	w11, w23, w21, lo
   15320:      	cinc	w13, w11, hi
   15324:      	sub	w14, w23, w13
   15328:      	subs	x12, x12, x13
   1532c:      	str	w14, [sp, #0x68]
   15330:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   15334:      	cmp	x12, #0xfff
   15338:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   1533c:      	cmp	w23, w21
   15340:      	b.ls	0x1534c <generic_kprobe_path+0xb86c>
   15344:      	mov	w13, #0x2f              // =47
   15348:      	strb	w13, [x8, x12]
   1534c:      	add	x19, x8, x12
   15350:      	cmp	w23, w21
   15354:      	add	x2, x9, x10
   15358:      	and	w1, w11, #0xff
   1535c:      	mov	w8, #0x4                // =4
   15360:      	cinc	x0, x19, hi
   15364:      	blr	x8
   15368:      	ldr	x25, [sp, #0x8]
   1536c:      	cmp	w23, w21
   15370:      	str	x19, [sp, #0x60]
   15374:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   15378:      	ldr	x21, [sp, #0x78]
   1537c:      	ldp	x2, x24, [sp, #0x50]
   15380:      	str	x21, [sp, #0x48]
   15384:      	b	0x153d8 <generic_kprobe_path+0xb8f8>
   15388:      	add	x2, x24, #0x10
   1538c:      	mov	w8, #0x4                // =4
   15390:      	add	x9, sp, #0x98
   15394:      	add	x0, sp, #0x98
   15398:      	mov	w1, #0x8                // =8
   1539c:      	blr	x8
   153a0:      	ldr	x8, [sp, #0x58]
   153a4:      	ldr	x9, [sp, #0x98]
   153a8:      	cmp	x8, x9
   153ac:      	ldr	x25, [sp, #0x8]
   153b0:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   153b4:      	add	x2, x24, #0x18
   153b8:      	mov	w8, #0x4                // =4
   153bc:      	mov	x0, x22
   153c0:      	mov	w1, #0x8                // =8
   153c4:      	blr	x8
   153c8:      	ldr	x24, [sp, #0x98]
   153cc:      	ldr	x21, [sp, #0x48]
   153d0:      	add	x2, x24, #0x20
   153d4:      	stp	x2, x24, [sp, #0x50]
   153d8:      	ldr	x8, [sp, #0x30]
   153dc:      	ldr	x25, [sp, #0x8]
   153e0:      	add	x9, sp, #0x70
   153e4:      	cmp	x21, x8
   153e8:      	b.ne	0x153f8 <generic_kprobe_path+0xb918>
   153ec:      	ldr	x8, [sp, #0x38]
   153f0:      	cmp	x2, x8
   153f4:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   153f8:      	mov	w8, #0x4                // =4
   153fc:      	add	x0, sp, #0x70
   15400:      	mov	w1, #0x8                // =8
   15404:      	blr	x8
   15408:      	ldr	x8, [sp, #0x70]
   1540c:      	cmp	x21, x8
   15410:      	b.eq	0x15500 <generic_kprobe_path+0xba20>
   15414:      	add	x23, x21, #0x18
   15418:      	mov	w8, #0x4                // =4
   1541c:      	add	x9, sp, #0x98
   15420:      	add	x0, sp, #0x98
   15424:      	mov	w1, #0x8                // =8
   15428:      	mov	x2, x23
   1542c:      	blr	x8
   15430:      	ldr	x8, [sp, #0x98]
   15434:      	cmp	x8, x21
   15438:      	b.eq	0x15500 <generic_kprobe_path+0xba20>
   1543c:      	mov	w8, #0x4                // =4
   15440:      	add	x9, sp, #0x78
   15444:      	add	x0, sp, #0x78
   15448:      	mov	w1, #0x8                // =8
   1544c:      	mov	x2, x23
   15450:      	blr	x8
   15454:      	add	x2, x21, #0x20
   15458:      	mov	w8, #0x4                // =4
   1545c:      	mov	w9, #0x10               // =16
   15460:      	add	x10, sp, #0x80
   15464:      	add	x0, sp, #0x80
   15468:      	mov	w1, #0x10               // =16
   1546c:      	blr	x8
   15470:      	ldr	w21, [sp, #0x84]
   15474:      	ldr	x8, [sp, #0x40]
   15478:      	ldr	x10, [sp, #0x60]
   1547c:      	sub	x12, x10, x8
   15480:      	ldr	w23, [sp, #0x68]
   15484:      	subs	w10, w21, w23
   15488:      	ldr	x9, [sp, #0x88]
   1548c:      	ldr	x25, [sp, #0x8]
   15490:      	csel	w10, wzr, w10, lo
   15494:      	cmp	w23, w21
   15498:      	csel	w11, w23, w21, lo
   1549c:      	cinc	w13, w11, hi
   154a0:      	sub	w14, w23, w13
   154a4:      	subs	x12, x12, x13
   154a8:      	str	w14, [sp, #0x68]
   154ac:      	b.lo	0x15568 <generic_kprobe_path+0xba88>
   154b0:      	cmp	x12, #0xfff
   154b4:      	b.hi	0x15568 <generic_kprobe_path+0xba88>
   154b8:      	cmp	w23, w21
   154bc:      	b.ls	0x154c8 <generic_kprobe_path+0xb9e8>
   154c0:      	mov	w13, #0x2f              // =47
   154c4:      	strb	w13, [x8, x12]
   154c8:      	add	x19, x8, x12
   154cc:      	cmp	w23, w21
   154d0:      	add	x2, x9, x10
   154d4:      	and	w1, w11, #0xff
   154d8:      	mov	w8, #0x4                // =4
   154dc:      	cinc	x0, x19, hi
   154e0:      	blr	x8
   154e4:      	ldr	x25, [sp, #0x8]
   154e8:      	cmp	w23, w21
   154ec:      	str	x19, [sp, #0x60]
   154f0:      	b.ls	0x15568 <generic_kprobe_path+0xba88>
   154f4:      	ldr	x8, [sp, #0x78]
   154f8:      	str	x8, [sp, #0x48]
   154fc:      	b	0x1554c <generic_kprobe_path+0xba6c>
   15500:      	add	x2, x24, #0x10
   15504:      	mov	w8, #0x4                // =4
   15508:      	add	x9, sp, #0x98
   1550c:      	add	x0, sp, #0x98
   15510:      	mov	w1, #0x8                // =8
   15514:      	blr	x8
   15518:      	ldr	x8, [sp, #0x58]
   1551c:      	ldr	x9, [sp, #0x98]
   15520:      	cmp	x8, x9
   15524:      	ldr	x25, [sp, #0x8]
   15528:      	b.eq	0x15560 <generic_kprobe_path+0xba80>
   1552c:      	add	x2, x24, #0x18
   15530:      	mov	w8, #0x4                // =4
   15534:      	mov	x0, x22
   15538:      	mov	w1, #0x8                // =8
   1553c:      	blr	x8
   15540:      	ldr	x8, [sp, #0x98]
   15544:      	add	x9, x8, #0x20
   15548:      	stp	x9, x8, [sp, #0x50]
   1554c:      	ldr	x25, [sp, #0x8]
   15550:      	subs	w20, w20, #0x80
   15554:      	add	x19, sp, #0x70
   15558:      	b.ne	0x9c5c <generic_kprobe_path+0x17c>
   1555c:      	b	0x15568 <generic_kprobe_path+0xba88>
   15560:      	mov	w8, #0x1                // =1
   15564:      	strb	w8, [sp, #0x6c]
   15568:      	ldr	w8, [x25, #0x8]
   1556c:      	ldp	x10, x20, [sp, #0x10]
   15570:      	add	w8, w8, #0x1
   15574:      	str	w8, [x25, #0x8]
   15578:      	ldr	w9, [sp, #0x60]
   1557c:      	sub	w9, w9, w10
   15580:      	str	w9, [x25, #0x4]
   15584:      	ldrb	w9, [sp, #0x6c]
   15588:      	cbnz	w9, 0x155c0 <generic_kprobe_path+0xbae0>
   1558c:      	cmp	w8, #0x8
   15590:      	b.eq	0x155c0 <generic_kprobe_path+0xbae0>
   15594:      	ldp	x8, x9, [sp, #0x48]
   15598:      	mov	w2, #0x6                // =6
   1559c:      	str	x8, [x20, #0x6458]
   155a0:      	ldr	x8, [sp, #0x58]
   155a4:      	str	x9, [x20, #0x6460]
   155a8:      	adrp	x9, 0x15000 <generic_kprobe_path+0xb520>
   155ac:      	str	x8, [x20, #0x6468]
   155b0:      	mov	w8, #0xc                // =12
   155b4:      	ldr	x9, [x9]
   155b8:      	ldr	x0, [sp, #0x20]
   155bc:      	b	0x155d4 <generic_kprobe_path+0xbaf4>
   155c0:      	adrp	x9, 0x15000 <generic_kprobe_path+0xb520>
   155c4:      	mov	w2, #0x1                // =1
   155c8:      	mov	w8, #0xc                // =12
   155cc:      	ldr	x9, [x9]
   155d0:      	ldr	x0, [sp, #0x20]
   155d4:      	adrp	x1, 0x15000 <generic_kprobe_path+0xb520>
   155d8:      	ldr	x1, [x1]
   155dc:      	blr	x8
   155e0:      	b	0x1597c <generic_kprobe_path+0xbe9c>
   155e4:      	str	w23, [sp, #0x98]
   155e8:      	mov	x3, xzr
   155ec:      	mov	w8, #0x2                // =2
   155f0:      	add	x9, sp, #0x30
   155f4:      	add	x10, sp, #0x98
   155f8:      	add	x1, sp, #0x30
   155fc:      	add	x2, sp, #0x98
   15600:      	mov	x0, x22
   15604:      	blr	x8
   15608:      	ldr	x23, [sp, #0x80]
   1560c:      	mov	w8, #0x8                // =8
   15610:      	mov	w9, #0x4                // =4
   15614:      	add	x10, sp, #0x30
   15618:      	add	x0, sp, #0x30
   1561c:      	mov	w1, #0x8                // =8
   15620:      	add	x2, x23, #0x10
   15624:      	blr	x9
   15628:      	ldr	x8, [sp, #0x30]
   1562c:      	cbnz	x8, 0x15674 <generic_kprobe_path+0xbb94>
   15630:      	add	x2, x23, #0x18
   15634:      	mov	w8, #0x8                // =8
   15638:      	mov	w9, #0x4                // =4
   1563c:      	add	x10, sp, #0x30
   15640:      	add	x0, sp, #0x30
   15644:      	mov	w1, #0x8                // =8
   15648:      	blr	x9
   1564c:      	ldr	x8, [sp, #0x30]
   15650:      	cmp	x8, x23
   15654:      	b.eq	0x15674 <generic_kprobe_path+0xbb94>
   15658:      	adrp	x8, 0x15000 <generic_kprobe_path+0xb520>
   1565c:      	add	x8, x8, #0x0
   15660:      	add	x29, x21, #0xff5
   15664:      	ldr	x8, [x8]
   15668:      	str	x8, [x29]
   1566c:      	mov	w8, #0x2964             // =10596
   15670:      	strh	w8, [x29, #0x8]
   15674:      	mov	w8, #0x23               // =35
   15678:      	blr	x8
   1567c:      	add	x2, x0, #0xb30
   15680:      	mov	w8, #0x8                // =8
   15684:      	mov	w9, #0x4                // =4
   15688:      	add	x10, sp, #0x98
   1568c:      	add	x0, sp, #0x98
   15690:      	mov	w1, #0x8                // =8
   15694:      	blr	x9
   15698:      	cbz	x0, 0x15708 <generic_kprobe_path+0xbc28>
   1569c:      	neg	w8, w0
   156a0:      	mov	w9, #0x1                // =1
   156a4:      	add	x1, sp, #0x30
   156a8:      	strh	w8, [sp, #0x30]
   156ac:      	mov	w8, #0x6                // =6
   156b0:      	mov	x0, x22
   156b4:      	mov	w23, #0x1               // =1
   156b8:      	strh	w8, [sp, #0x32]
   156bc:      	mov	x8, #0x33               // =51
   156c0:      	movk	x8, #0x4, lsl #32
   156c4:      	stur	x8, [sp, #0x34]
   156c8:      	add	x8, sp, #0x30
   156cc:      	blr	x9
   156d0:      	cbz	x0, 0x156e4 <generic_kprobe_path+0xbc04>
   156d4:      	ldr	w8, [x0]
   156d8:      	add	w8, w8, #0x1
   156dc:      	str	w8, [x0]
   156e0:      	b	0x15708 <generic_kprobe_path+0xbc28>
   156e4:      	str	w23, [sp, #0x78]
   156e8:      	mov	x3, xzr
   156ec:      	mov	w8, #0x2                // =2
   156f0:      	add	x9, sp, #0x30
   156f4:      	add	x10, sp, #0x78
   156f8:      	add	x1, sp, #0x30
   156fc:      	add	x2, sp, #0x78
   15700:      	mov	x0, x22
   15704:      	blr	x8
   15708:      	ldr	x8, [sp, #0x98]
   1570c:      	mov	w9, #0x6448             // =25672
   15710:      	ldr	x23, [x20, #0x6440]
   15714:      	mov	w1, #0x8                // =8
   15718:      	add	x0, x20, x9
   1571c:      	mov	w9, #0x4                // =4
   15720:      	add	x24, x8, #0x18
   15724:      	add	x2, x8, #0x20
   15728:      	mov	w8, #0x8                // =8
   1572c:      	blr	x9
   15730:      	cbz	x0, 0x157a0 <generic_kprobe_path+0xbcc0>
   15734:      	neg	w8, w0
   15738:      	mov	w9, #0x1                // =1
   1573c:      	add	x1, sp, #0x30
   15740:      	strh	w8, [sp, #0x30]
   15744:      	mov	w8, #0x6                // =6
   15748:      	mov	x0, x22
   1574c:      	mov	w19, #0x1               // =1
   15750:      	strh	w8, [sp, #0x32]
   15754:      	mov	x8, #0x38               // =56
   15758:      	movk	x8, #0x4, lsl #32
   1575c:      	stur	x8, [sp, #0x34]
   15760:      	add	x8, sp, #0x30
   15764:      	blr	x9
   15768:      	cbz	x0, 0x1577c <generic_kprobe_path+0xbc9c>
   1576c:      	ldr	w8, [x0]
   15770:      	add	w8, w8, #0x1
   15774:      	str	w8, [x0]
   15778:      	b	0x157a0 <generic_kprobe_path+0xbcc0>
   1577c:      	str	w19, [sp, #0x78]
   15780:      	mov	x3, xzr
   15784:      	mov	w8, #0x2                // =2
   15788:      	add	x9, sp, #0x30
   1578c:      	add	x10, sp, #0x78
   15790:      	add	x1, sp, #0x30
   15794:      	add	x2, sp, #0x78
   15798:      	mov	x0, x22
   1579c:      	blr	x8
   157a0:      	mov	w8, #0x6450             // =25680
   157a4:      	mov	w9, #0x4                // =4
   157a8:      	mov	w1, #0x8                // =8
   157ac:      	mov	x2, x24
   157b0:      	add	x0, x20, x8
   157b4:      	mov	w8, #0x8                // =8
   157b8:      	blr	x9
   157bc:      	cbz	x0, 0x1582c <generic_kprobe_path+0xbd4c>
   157c0:      	neg	w8, w0
   157c4:      	mov	w9, #0x1                // =1
   157c8:      	add	x1, sp, #0x30
   157cc:      	strh	w8, [sp, #0x30]
   157d0:      	mov	w8, #0x6                // =6
   157d4:      	mov	x0, x22
   157d8:      	mov	w19, #0x1               // =1
   157dc:      	strh	w8, [sp, #0x32]
   157e0:      	mov	x8, #0x39               // =57
   157e4:      	movk	x8, #0x4, lsl #32
   157e8:      	stur	x8, [sp, #0x34]
   157ec:      	add	x8, sp, #0x30
   157f0:      	blr	x9
   157f4:      	cbz	x0, 0x15808 <generic_kprobe_path+0xbd28>
   157f8:      	ldr	w8, [x0]
   157fc:      	add	w8, w8, #0x1
   15800:      	str	w8, [x0]
   15804:      	b	0x1582c <generic_kprobe_path+0xbd4c>
   15808:      	str	w19, [sp, #0x78]
   1580c:      	mov	x3, xzr
   15810:      	mov	w8, #0x2                // =2
   15814:      	add	x9, sp, #0x30
   15818:      	add	x10, sp, #0x78
   1581c:      	add	x1, sp, #0x30
   15820:      	add	x2, sp, #0x78
   15824:      	mov	x0, x22
   15828:      	blr	x8
   1582c:      	mov	w8, #0x6458             // =25688
   15830:      	add	x2, x23, #0x8
   15834:      	mov	w9, #0x4                // =4
   15838:      	mov	w1, #0x8                // =8
   1583c:      	add	x0, x20, x8
   15840:      	mov	w8, #0x8                // =8
   15844:      	blr	x9
   15848:      	cbz	x0, 0x158b8 <generic_kprobe_path+0xbdd8>
   1584c:      	neg	w8, w0
   15850:      	mov	w9, #0x1                // =1
   15854:      	add	x1, sp, #0x30
   15858:      	strh	w8, [sp, #0x30]
   1585c:      	mov	w8, #0x6                // =6
   15860:      	mov	x0, x22
   15864:      	mov	w19, #0x1               // =1
   15868:      	strh	w8, [sp, #0x32]
   1586c:      	mov	x8, #0x3a               // =58
   15870:      	movk	x8, #0x4, lsl #32
   15874:      	stur	x8, [sp, #0x34]
   15878:      	add	x8, sp, #0x30
   1587c:      	blr	x9
   15880:      	cbz	x0, 0x15894 <generic_kprobe_path+0xbdb4>
   15884:      	ldr	w8, [x0]
   15888:      	add	w8, w8, #0x1
   1588c:      	str	w8, [x0]
   15890:      	b	0x158b8 <generic_kprobe_path+0xbdd8>
   15894:      	str	w19, [sp, #0x78]
   15898:      	mov	x3, xzr
   1589c:      	mov	w8, #0x2                // =2
   158a0:      	add	x9, sp, #0x30
   158a4:      	add	x10, sp, #0x78
   158a8:      	add	x1, sp, #0x30
   158ac:      	add	x2, sp, #0x78
   158b0:      	mov	x0, x22
   158b4:      	blr	x8
   158b8:      	mov	w8, #0x6460             // =25696
   158bc:      	mov	w9, #0x4                // =4
   158c0:      	mov	w1, #0x8                // =8
   158c4:      	mov	x2, x23
   158c8:      	add	x0, x20, x8
   158cc:      	mov	w8, #0x8                // =8
   158d0:      	blr	x9
   158d4:      	cbz	x0, 0x15944 <generic_kprobe_path+0xbe64>
   158d8:      	neg	w8, w0
   158dc:      	mov	w9, #0x1                // =1
   158e0:      	add	x1, sp, #0x30
   158e4:      	strh	w8, [sp, #0x30]
   158e8:      	mov	w8, #0x6                // =6
   158ec:      	mov	x0, x22
   158f0:      	mov	w19, #0x1               // =1
   158f4:      	strh	w8, [sp, #0x32]
   158f8:      	mov	x8, #0x3b               // =59
   158fc:      	movk	x8, #0x4, lsl #32
   15900:      	stur	x8, [sp, #0x34]
   15904:      	add	x8, sp, #0x30
   15908:      	blr	x9
   1590c:      	cbz	x0, 0x15920 <generic_kprobe_path+0xbe40>
   15910:      	ldr	w8, [x0]
   15914:      	add	w8, w8, #0x1
   15918:      	str	w8, [x0]
   1591c:      	b	0x15944 <generic_kprobe_path+0xbe64>
   15920:      	str	w19, [sp, #0x78]
   15924:      	mov	x3, xzr
   15928:      	mov	w8, #0x2                // =2
   1592c:      	add	x9, sp, #0x30
   15930:      	add	x10, sp, #0x78
   15934:      	add	x1, sp, #0x30
   15938:      	add	x2, sp, #0x78
   1593c:      	mov	x0, x22
   15940:      	blr	x8
   15944:      	ldr	x8, [x20, #0x6460]
   15948:      	mov	w9, #0x1                // =1
   1594c:      	adrp	x1, 0x15000 <generic_kprobe_path+0xb520>
   15950:      	mov	w2, #0x6                // =6
   15954:      	str	w9, [x25]
   15958:      	mov	w9, #0xc                // =12
   1595c:      	sub	x8, x8, #0x20
   15960:      	str	x8, [x20, #0x6468]
   15964:      	sub	w8, w29, w21
   15968:      	stp	w8, wzr, [x25, #0x4]
   1596c:      	mov	w8, #0x6                // =6
   15970:      	ldr	x1, [x1]
   15974:      	ldr	x0, [sp, #0x20]
   15978:      	blr	x9
   1597c:      	ldp	x20, x19, [sp, #0xd0]
   15980:      	mov	w0, wzr
   15984:      	ldr	x29, [sp, #0x90]
   15988:      	ldp	x22, x21, [sp, #0xc0]
   1598c:      	ldp	x24, x23, [sp, #0xb0]
   15990:      	ldp	x30, x25, [sp, #0xa0]
   15994:      	add	sp, sp, #0xe0
   15998:      	ret

Disassembly of section kprobe/generic_kprobe:

0000000000000000 <generic_kprobe_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_kprobe_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x540 <generic_kprobe_event+0x540>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	adrp	x0, 0x0 <generic_kprobe_event>
      48:      	mov	w8, #0x1                // =1
      4c:      	str	wzr, [x21]
      50:      	mov	x1, x21
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x540 <generic_kprobe_event+0x540>
      60:      	ldr	w8, [x0, #0x64]
      64:      	str	w8, [sp, #0x1c]
      68:      	cbz	w8, 0x224 <generic_kprobe_event+0x224>
      6c:      	adrp	x22, 0x0 <generic_kprobe_event>
      70:      	mov	w8, #0x1                // =1
      74:      	add	x9, sp, #0x1c
      78:      	ldr	x22, [x22]
      7c:      	mov	x24, x0
      80:      	add	x1, sp, #0x1c
      84:      	mov	x0, x22
      88:      	blr	x8
      8c:      	cbz	x0, 0x540 <generic_kprobe_event+0x540>
      90:      	mov	x23, x0
      94:      	str	wzr, [sp, #0x84]
      98:      	adrp	x0, 0x0 <generic_kprobe_event>
      9c:      	mov	w8, #0x1                // =1
      a0:      	ldr	x0, [x0]
      a4:      	add	x9, sp, #0x84
      a8:      	add	x1, sp, #0x84
      ac:      	blr	x8
      b0:      	cbz	x0, 0xdc <generic_kprobe_event+0xdc>
      b4:      	ldr	x8, [x0, #0x20]
      b8:      	mov	w9, #0x7270             // =29296
      bc:      	movk	w9, #0x6367, lsl #16
      c0:      	cmp	x8, x9
      c4:      	b.ne	0xe4 <generic_kprobe_event+0xe4>
      c8:      	mov	w8, #0x50               // =80
      cc:      	blr	x8
      d0:      	str	x0, [sp, #0x30]
      d4:      	cbnz	x0, 0x1d8 <generic_kprobe_event+0x1d8>
      d8:      	b	0x540 <generic_kprobe_event+0x540>
      dc:      	mov	w25, wzr
      e0:      	b	0xe8 <generic_kprobe_event+0xe8>
      e4:      	ldr	w25, [x0, #0x10]
      e8:      	mov	w8, #0x23               // =35
      ec:      	blr	x8
      f0:      	str	xzr, [sp, #0x88]
      f4:      	add	x2, x0, #0xcd0
      f8:      	mov	w8, #0x8                // =8
      fc:      	mov	w9, #0x71               // =113
     100:      	add	x10, sp, #0x20
     104:      	add	x0, sp, #0x20
     108:      	mov	w1, #0x8                // =8
     10c:      	blr	x9
     110:      	ldr	x8, [sp, #0x20]
     114:      	cbz	x8, 0x540 <generic_kprobe_event+0x540>
     118:      	cmp	w25, #0xb
     11c:      	b.hi	0x540 <generic_kprobe_event+0x540>
     120:      	ubfiz	x9, x25, #3, #32
     124:      	mov	w10, #0x8               // =8
     128:      	mov	w11, #0x71              // =113
     12c:      	add	x12, sp, #0x38
     130:      	add	x0, sp, #0x38
     134:      	mov	w1, #0x8                // =8
     138:      	add	x8, x8, x9
     13c:      	ldr	x8, [sp, #0x20]
     140:      	add	x2, x8, x9
     144:      	blr	x11
     148:      	ldr	x8, [sp, #0x38]
     14c:      	cbz	x8, 0x540 <generic_kprobe_event+0x540>
     150:      	mov	w9, #0x8                // =8
     154:      	mov	w10, #0x71              // =113
     158:      	add	x11, sp, #0x88
     15c:      	ldr	x2, [sp, #0x38]
     160:      	add	x0, sp, #0x88
     164:      	mov	w1, #0x8                // =8
     168:      	blr	x10
     16c:      	ldr	x8, [sp, #0x88]
     170:      	cbz	x8, 0x540 <generic_kprobe_event+0x540>
     174:      	str	xzr, [sp, #0x38]
     178:      	add	x2, x8, #0x100
     17c:      	mov	w8, #0x8                // =8
     180:      	mov	w9, #0x71               // =113
     184:      	add	x10, sp, #0x38
     188:      	add	x0, sp, #0x38
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x9
     194:      	ldr	x8, [sp, #0x38]
     198:      	str	xzr, [sp, #0x38]
     19c:      	cbz	x8, 0x1cc <generic_kprobe_event+0x1cc>
     1a0:      	add	x2, x8, #0x60
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	w9, #0x71               // =113
     1ac:      	add	x10, sp, #0x38
     1b0:      	add	x0, sp, #0x38
     1b4:      	mov	w1, #0x8                // =8
     1b8:      	blr	x9
     1bc:      	ldr	x0, [sp, #0x38]
     1c0:      	str	x0, [sp, #0x30]
     1c4:      	cbnz	x0, 0x1d8 <generic_kprobe_event+0x1d8>
     1c8:      	b	0x540 <generic_kprobe_event+0x540>
     1cc:      	mov	x0, xzr
     1d0:      	str	xzr, [sp, #0x30]
     1d4:      	cbz	xzr, 0x540 <generic_kprobe_event+0x540>
     1d8:      	str	x0, [sp, #0x38]
     1dc:      	adrp	x0, 0x0 <generic_kprobe_event>
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x9, sp, #0x38
     1e8:      	ldr	x0, [x0]
     1ec:      	add	x1, sp, #0x38
     1f0:      	blr	x8
     1f4:      	cbz	x0, 0x204 <generic_kprobe_event+0x204>
     1f8:      	ldr	x8, [x0]
     1fc:      	cbz	x8, 0x204 <generic_kprobe_event+0x204>
     200:      	str	x8, [sp, #0x30]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x9, sp, #0x30
     20c:      	add	x1, sp, #0x30
     210:      	mov	x0, x23
     214:      	blr	x8
     218:      	mov	x8, x0
     21c:      	mov	x0, x24
     220:      	cbz	x8, 0x55c <generic_kprobe_event+0x55c>
     224:      	ldr	w9, [x0]
     228:      	mov	w8, #0x6420             // =25632
     22c:      	stur	xzr, [x21, #0x4]
     230:      	str	xzr, [x20, #0x5eb8]
     234:      	str	xzr, [x20, #0x5ec0]
     238:      	str	wzr, [x20, x8]
     23c:      	mov	w8, #0x23               // =35
     240:      	str	xzr, [x20, #0x5ec8]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x9, xzr, [x20, #0x60]
     250:      	mov	w9, #0x5eb8             // =24248
     254:      	add	x9, x20, x9
     258:      	strb	wzr, [x9, #0x28]
     25c:      	blr	x8
     260:      	add	x2, x0, #0xb50
     264:      	mov	w25, #0x8               // =8
     268:      	add	x8, sp, #0x88
     26c:      	mov	w9, #0x4                // =4
     270:      	mov	x22, x0
     274:      	add	x0, sp, #0x88
     278:      	mov	w1, #0x8                // =8
     27c:      	add	x23, x20, #0x20
     280:      	mov	w24, #0x4               // =4
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x88]
     28c:      	mov	w9, #0x48               // =72
     290:      	add	x10, sp, #0x38
     294:      	mov	w11, #0x4               // =4
     298:      	ldr	x2, [sp, #0x88]
     29c:      	add	x0, sp, #0x38
     2a0:      	mov	w1, #0x48               // =72
     2a4:      	blr	x11
     2a8:      	ldr	x8, [sp, #0x40]
     2ac:      	mov	w9, #0x4                // =4
     2b0:      	mov	x0, x23
     2b4:      	mov	w1, #0x4                // =4
     2b8:      	add	x8, x8, #0x218
     2bc:      	ldr	x8, [sp, #0x40]
     2c0:      	add	x2, x8, #0x218
     2c4:      	blr	x9
     2c8:      	ldr	x8, [sp, #0x48]
     2cc:      	add	x0, x20, #0x24
     2d0:      	mov	w9, #0x4                // =4
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	add	x8, x8, #0x4d8
     2dc:      	ldr	x8, [sp, #0x48]
     2e0:      	add	x2, x8, #0x4d8
     2e4:      	blr	x9
     2e8:      	ldr	x8, [sp, #0x50]
     2ec:      	add	x0, x20, #0x28
     2f0:      	mov	w9, #0x4                // =4
     2f4:      	mov	w1, #0x4                // =4
     2f8:      	add	x8, x8, #0x58
     2fc:      	ldr	x8, [sp, #0x50]
     300:      	add	x2, x8, #0x58
     304:      	blr	x9
     308:      	str	xzr, [sp, #0x30]
     30c:      	add	x2, x22, #0x938
     310:      	add	x8, sp, #0x30
     314:      	add	x0, sp, #0x30
     318:      	mov	w1, #0x8                // =8
     31c:      	blr	x24
     320:      	ldr	x8, [sp, #0x30]
     324:      	cbz	x8, 0x3a8 <generic_kprobe_event+0x3a8>
     328:      	str	wzr, [sp, #0x10]
     32c:      	add	x8, x8, #0x4
     330:      	add	x9, sp, #0x10
     334:      	mov	w10, #0x4               // =4
     338:      	add	x0, sp, #0x10
     33c:      	mov	w1, #0x4                // =4
     340:      	mov	w23, #0x4               // =4
     344:      	ldr	x8, [sp, #0x30]
     348:      	add	x2, x8, #0x4
     34c:      	blr	x10
     350:      	ldr	x8, [sp, #0x30]
     354:      	ldrsw	x9, [sp, #0x10]
     358:      	add	x10, sp, #0x20
     35c:      	mov	w11, #0x4               // =4
     360:      	add	x0, sp, #0x20
     364:      	mov	w1, #0x10               // =16
     368:      	add	x8, x8, x9, lsl #4
     36c:      	mov	w9, #0x10               // =16
     370:      	add	x8, x8, #0x80
     374:      	ldr	x8, [sp, #0x30]
     378:      	ldrsw	x9, [sp, #0x10]
     37c:      	add	x8, x8, x9, lsl #4
     380:      	add	x2, x8, #0x80
     384:      	blr	x11
     388:      	ldr	x8, [sp, #0x28]
     38c:      	add	x0, x20, #0x2c
     390:      	mov	w1, #0x4                // =4
     394:      	add	x8, x8, #0x158
     398:      	ldr	x8, [sp, #0x28]
     39c:      	add	x2, x8, #0x158
     3a0:      	blr	x23
     3a4:      	b	0x3ac <generic_kprobe_event+0x3ac>
     3a8:      	str	wzr, [x20, #0x2c]
     3ac:      	ldr	x8, [sp, #0x58]
     3b0:      	add	x0, x20, #0x30
     3b4:      	mov	w9, #0x4                // =4
     3b8:      	mov	w1, #0x4                // =4
     3bc:      	mov	w24, #0x4               // =4
     3c0:      	add	x8, x8, #0x158
     3c4:      	ldr	x8, [sp, #0x58]
     3c8:      	add	x2, x8, #0x158
     3cc:      	blr	x9
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	add	x0, x20, #0x34
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w1, #0x4                // =4
     3e0:      	add	x8, x8, #0x118
     3e4:      	ldr	x8, [sp, #0x60]
     3e8:      	add	x2, x8, #0x118
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x68]
     3f4:      	add	x0, x20, #0x38
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x8, x8, #0x98
     404:      	ldr	x8, [sp, #0x68]
     408:      	add	x2, x8, #0x98
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x70]
     414:      	add	x0, x20, #0x3c
     418:      	mov	w9, #0x4                // =4
     41c:      	mov	w1, #0x4                // =4
     420:      	add	x8, x8, #0x98
     424:      	ldr	x8, [sp, #0x70]
     428:      	add	x2, x8, #0x98
     42c:      	blr	x9
     430:      	ldr	x8, [sp, #0x78]
     434:      	add	x0, x20, #0x40
     438:      	mov	w9, #0x4                // =4
     43c:      	mov	w1, #0x4                // =4
     440:      	add	x8, x8, #0x58
     444:      	ldr	x8, [sp, #0x78]
     448:      	add	x2, x8, #0x58
     44c:      	blr	x9
     450:      	str	xzr, [sp, #0x20]
     454:      	str	xzr, [sp, #0x30]
     458:      	add	x22, x22, #0xae0
     45c:      	mov	w25, #0x8               // =8
     460:      	add	x8, sp, #0x20
     464:      	mov	w9, #0x4                // =4
     468:      	add	x0, sp, #0x20
     46c:      	mov	w1, #0x8                // =8
     470:      	mov	x2, x22
     474:      	blr	x9
     478:      	ldr	x8, [sp, #0x20]
     47c:      	add	x9, sp, #0x30
     480:      	mov	w10, #0x4               // =4
     484:      	add	x0, sp, #0x30
     488:      	mov	w1, #0x8                // =8
     48c:      	add	x8, x8, #0x90
     490:      	ldr	x8, [sp, #0x20]
     494:      	add	x2, x8, #0x90
     498:      	blr	x10
     49c:      	ldr	x8, [sp, #0x30]
     4a0:      	add	x0, x20, #0x44
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	mov	w1, #0x4                // =4
     4ac:      	add	x8, x8, #0x158
     4b0:      	ldr	x8, [sp, #0x30]
     4b4:      	add	x2, x8, #0x158
     4b8:      	blr	x9
     4bc:      	add	x8, sp, #0x38
     4c0:      	mov	w9, #0x4                // =4
     4c4:      	add	x0, sp, #0x38
     4c8:      	mov	w1, #0x8                // =8
     4cc:      	mov	x2, x22
     4d0:      	add	x23, x20, #0x48
     4d4:      	blr	x9
     4d8:      	ldr	x22, [sp, #0x38]
     4dc:      	add	x0, x20, #0x50
     4e0:      	mov	w8, #0x4                // =4
     4e4:      	mov	w1, #0x8                // =8
     4e8:      	add	x2, x22, #0x40
     4ec:      	blr	x8
     4f0:      	add	x0, x20, #0x58
     4f4:      	add	x2, x22, #0x30
     4f8:      	mov	w8, #0x4                // =4
     4fc:      	mov	w1, #0x8                // =8
     500:      	blr	x8
     504:      	add	x2, x22, #0x38
     508:      	mov	x0, x23
     50c:      	mov	w1, #0x8                // =8
     510:      	blr	x24
     514:      	strb	wzr, [x21, #0x10]
     518:      	strb	wzr, [x20, #0x1]
     51c:      	adrp	x1, 0x0 <generic_kprobe_event>
     520:      	mov	w8, #0x2                // =2
     524:      	mov	w9, #0xc                // =12
     528:      	mov	x0, x19
     52c:      	str	xzr, [x20, #0x5ee8]
     530:      	str	xzr, [x20, #0x5ef0]
     534:      	ldr	x1, [x1]
     538:      	mov	w2, #0x2                // =2
     53c:      	blr	x9
     540:      	ldp	x20, x19, [sp, #0xc0]
     544:      	mov	w0, wzr
     548:      	ldp	x22, x21, [sp, #0xb0]
     54c:      	ldp	x24, x23, [sp, #0xa0]
     550:      	ldp	x30, x25, [sp, #0x90]
     554:      	add	sp, sp, #0xd0
     558:      	ret
     55c:      	mov	x8, #-0x1               // =-1
     560:      	mov	w9, #0x1                // =1
     564:      	add	x1, sp, #0x10
     568:      	str	x8, [sp, #0x10]
     56c:      	add	x8, sp, #0x10
     570:      	mov	x0, x23
     574:      	mov	w25, #0x1               // =1
     578:      	blr	x9
     57c:      	cbz	x0, 0x540 <generic_kprobe_event+0x540>
     580:      	str	w25, [sp, #0x1c]
     584:      	add	x8, sp, #0x1c
     588:      	add	x1, sp, #0x1c
     58c:      	mov	x0, x22
     590:      	blr	x25
     594:      	cbz	x0, 0x540 <generic_kprobe_event+0x540>
     598:      	mov	w8, #0x1                // =1
     59c:      	add	x9, sp, #0x30
     5a0:      	add	x1, sp, #0x30
     5a4:      	blr	x8
     5a8:      	mov	x8, x0
     5ac:      	mov	x0, x24
     5b0:      	cbnz	x8, 0x540 <generic_kprobe_event+0x540>
     5b4:      	b	0x224 <generic_kprobe_event+0x224>

Disassembly of section kprobe/generic_kprobe_override:

0000000000000000 <generic_kprobe_override>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	w8, #0xe                // =14
       c:      	mov	x20, x0
      10:      	blr	x8
      14:      	str	x0, [sp, #0x8]
      18:      	adrp	x19, 0x0 <generic_kprobe_override>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x8
      24:      	ldr	x19, [x19]
      28:      	add	x1, sp, #0x8
      2c:      	mov	x0, x19
      30:      	blr	x8
      34:      	cbz	x0, 0x60 <generic_kprobe_override+0x60>
      38:      	ldrsw	x8, [x0]
      3c:      	mov	w9, #0x3a               // =58
      40:      	ldrsw	x1, [x0]
      44:      	mov	x0, x20
      48:      	blr	x9
      4c:      	mov	w8, #0x3                // =3
      50:      	add	x9, sp, #0x8
      54:      	add	x1, sp, #0x8
      58:      	mov	x0, x19
      5c:      	blr	x8
      60:      	ldp	x20, x19, [sp, #0x10]
      64:      	mov	w0, wzr
      68:      	ldr	x30, [sp], #0x20
      6c:      	ret

Disassembly of section fmod_ret/security_task_prctl:

0000000000000000 <generic_fmodret_override>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	w8, #0xe                // =14
       c:      	blr	x8
      10:      	str	x0, [sp, #0x8]
      14:      	adrp	x19, 0x0 <generic_fmodret_override>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0x8
      20:      	ldr	x19, [x19]
      24:      	add	x1, sp, #0x8
      28:      	mov	x0, x19
      2c:      	blr	x8
      30:      	cbz	x0, 0x50 <generic_fmodret_override+0x50>
      34:      	mov	w8, #0x3                // =3
      38:      	add	x9, sp, #0x8
      3c:      	mov	x20, x0
      40:      	add	x1, sp, #0x8
      44:      	mov	x0, x19
      48:      	blr	x8
      4c:      	ldrsw	x0, [x20]
      50:      	ldp	x20, x19, [sp, #0x10]
      54:      	ldr	x30, [sp], #0x20
      58:      	ret
