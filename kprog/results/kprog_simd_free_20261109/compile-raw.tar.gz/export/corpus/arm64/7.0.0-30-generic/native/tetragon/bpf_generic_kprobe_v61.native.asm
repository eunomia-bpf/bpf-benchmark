
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_kprobe_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <read_reg>:
       0:      	ror	w9, w1, #0x3
       4:      	mov	x8, xzr
       8:      	cmp	w9, #0xf
       c:      	b.le	0x48 <read_reg+0x48>
      10:      	cmp	w9, #0x17
      14:      	b.le	0x9c <read_reg+0x9c>
      18:      	cmp	w9, #0x1b
      1c:      	b.le	0xc4 <read_reg+0xc4>
      20:      	cmp	w9, #0x1d
      24:      	b.le	0x15c <read_reg+0x15c>
      28:      	cmp	w9, #0x1e
      2c:      	b.eq	0x27c <read_reg+0x27c>
      30:      	cmp	w9, #0x20
      34:      	b.eq	0x21c <read_reg+0x21c>
      38:      	cmp	w9, #0x1f
      3c:      	b.ne	0x290 <read_reg+0x290>
      40:      	add	x0, x0, #0xf8
      44:      	b	0x280 <read_reg+0x280>
      48:      	cmp	w9, #0x7
      4c:      	b.gt	0x74 <read_reg+0x74>
      50:      	cmp	w9, #0x3
      54:      	b.gt	0xe4 <read_reg+0xe4>
      58:      	cmp	w9, #0x1
      5c:      	b.gt	0x174 <read_reg+0x174>
      60:      	cbz	w9, 0x280 <read_reg+0x280>
      64:      	cmp	w9, #0x1
      68:      	b.ne	0x290 <read_reg+0x290>
      6c:      	add	x0, x0, #0x8
      70:      	b	0x280 <read_reg+0x280>
      74:      	cmp	w9, #0xb
      78:      	b.gt	0x104 <read_reg+0x104>
      7c:      	cmp	w9, #0x9
      80:      	b.gt	0x18c <read_reg+0x18c>
      84:      	cmp	w9, #0x8
      88:      	b.eq	0x224 <read_reg+0x224>
      8c:      	cmp	w9, #0x9
      90:      	b.ne	0x290 <read_reg+0x290>
      94:      	add	x0, x0, #0x48
      98:      	b	0x280 <read_reg+0x280>
      9c:      	cmp	w9, #0x13
      a0:      	b.gt	0x124 <read_reg+0x124>
      a4:      	cmp	w9, #0x11
      a8:      	b.gt	0x1d4 <read_reg+0x1d4>
      ac:      	cmp	w9, #0x10
      b0:      	b.eq	0x25c <read_reg+0x25c>
      b4:      	cmp	w9, #0x11
      b8:      	b.ne	0x290 <read_reg+0x290>
      bc:      	add	x0, x0, #0x88
      c0:      	b	0x280 <read_reg+0x280>
      c4:      	cmp	w9, #0x19
      c8:      	b.gt	0x144 <read_reg+0x144>
      cc:      	cmp	w9, #0x18
      d0:      	b.eq	0x204 <read_reg+0x204>
      d4:      	cmp	w9, #0x19
      d8:      	b.ne	0x290 <read_reg+0x290>
      dc:      	add	x0, x0, #0xc8
      e0:      	b	0x280 <read_reg+0x280>
      e4:      	cmp	w9, #0x5
      e8:      	b.gt	0x1a4 <read_reg+0x1a4>
      ec:      	cmp	w9, #0x4
      f0:      	b.eq	0x22c <read_reg+0x22c>
      f4:      	cmp	w9, #0x5
      f8:      	b.ne	0x290 <read_reg+0x290>
      fc:      	add	x0, x0, #0x28
     100:      	b	0x280 <read_reg+0x280>
     104:      	cmp	w9, #0xd
     108:      	b.gt	0x1bc <read_reg+0x1bc>
     10c:      	cmp	w9, #0xc
     110:      	b.eq	0x234 <read_reg+0x234>
     114:      	cmp	w9, #0xd
     118:      	b.ne	0x290 <read_reg+0x290>
     11c:      	add	x0, x0, #0x68
     120:      	b	0x280 <read_reg+0x280>
     124:      	cmp	w9, #0x15
     128:      	b.gt	0x1ec <read_reg+0x1ec>
     12c:      	cmp	w9, #0x14
     130:      	b.eq	0x264 <read_reg+0x264>
     134:      	cmp	w9, #0x15
     138:      	b.ne	0x290 <read_reg+0x290>
     13c:      	add	x0, x0, #0xa8
     140:      	b	0x280 <read_reg+0x280>
     144:      	cmp	w9, #0x1a
     148:      	b.eq	0x20c <read_reg+0x20c>
     14c:      	cmp	w9, #0x1b
     150:      	b.ne	0x290 <read_reg+0x290>
     154:      	add	x0, x0, #0xd8
     158:      	b	0x280 <read_reg+0x280>
     15c:      	cmp	w9, #0x1c
     160:      	b.eq	0x214 <read_reg+0x214>
     164:      	cmp	w9, #0x1d
     168:      	b.ne	0x290 <read_reg+0x290>
     16c:      	add	x0, x0, #0xe8
     170:      	b	0x280 <read_reg+0x280>
     174:      	cmp	w9, #0x2
     178:      	b.eq	0x23c <read_reg+0x23c>
     17c:      	cmp	w9, #0x3
     180:      	b.ne	0x290 <read_reg+0x290>
     184:      	add	x0, x0, #0x18
     188:      	b	0x280 <read_reg+0x280>
     18c:      	cmp	w9, #0xa
     190:      	b.eq	0x244 <read_reg+0x244>
     194:      	cmp	w9, #0xb
     198:      	b.ne	0x290 <read_reg+0x290>
     19c:      	add	x0, x0, #0x58
     1a0:      	b	0x280 <read_reg+0x280>
     1a4:      	cmp	w9, #0x6
     1a8:      	b.eq	0x24c <read_reg+0x24c>
     1ac:      	cmp	w9, #0x7
     1b0:      	b.ne	0x290 <read_reg+0x290>
     1b4:      	add	x0, x0, #0x38
     1b8:      	b	0x280 <read_reg+0x280>
     1bc:      	cmp	w9, #0xe
     1c0:      	b.eq	0x254 <read_reg+0x254>
     1c4:      	cmp	w9, #0xf
     1c8:      	b.ne	0x290 <read_reg+0x290>
     1cc:      	add	x0, x0, #0x78
     1d0:      	b	0x280 <read_reg+0x280>
     1d4:      	cmp	w9, #0x12
     1d8:      	b.eq	0x26c <read_reg+0x26c>
     1dc:      	cmp	w9, #0x13
     1e0:      	b.ne	0x290 <read_reg+0x290>
     1e4:      	add	x0, x0, #0x98
     1e8:      	b	0x280 <read_reg+0x280>
     1ec:      	cmp	w9, #0x16
     1f0:      	b.eq	0x274 <read_reg+0x274>
     1f4:      	cmp	w9, #0x17
     1f8:      	b.ne	0x290 <read_reg+0x290>
     1fc:      	add	x0, x0, #0xb8
     200:      	b	0x280 <read_reg+0x280>
     204:      	add	x0, x0, #0xc0
     208:      	b	0x280 <read_reg+0x280>
     20c:      	add	x0, x0, #0xd0
     210:      	b	0x280 <read_reg+0x280>
     214:      	add	x0, x0, #0xe0
     218:      	b	0x280 <read_reg+0x280>
     21c:      	add	x0, x0, #0x100
     220:      	b	0x280 <read_reg+0x280>
     224:      	add	x0, x0, #0x40
     228:      	b	0x280 <read_reg+0x280>
     22c:      	add	x0, x0, #0x20
     230:      	b	0x280 <read_reg+0x280>
     234:      	add	x0, x0, #0x60
     238:      	b	0x280 <read_reg+0x280>
     23c:      	add	x0, x0, #0x10
     240:      	b	0x280 <read_reg+0x280>
     244:      	add	x0, x0, #0x50
     248:      	b	0x280 <read_reg+0x280>
     24c:      	add	x0, x0, #0x30
     250:      	b	0x280 <read_reg+0x280>
     254:      	add	x0, x0, #0x70
     258:      	b	0x280 <read_reg+0x280>
     25c:      	add	x0, x0, #0x80
     260:      	b	0x280 <read_reg+0x280>
     264:      	add	x0, x0, #0xa0
     268:      	b	0x280 <read_reg+0x280>
     26c:      	add	x0, x0, #0x90
     270:      	b	0x280 <read_reg+0x280>
     274:      	add	x0, x0, #0xb0
     278:      	b	0x280 <read_reg+0x280>
     27c:      	add	x0, x0, #0xf0
     280:      	ldr	x8, [x0]
     284:      	mov	x9, #-0x1               // =-1
     288:      	lsr	x9, x9, x2
     28c:      	and	x8, x8, x9
     290:      	mov	x0, x8
     294:      	ret
     298:      	nop
     29c:      	nop

00000000000002a0 <extract_arg_depth>:
     2a0:      	cmp	w0, #0x9
     2a4:      	b.ls	0x2b0 <extract_arg_depth+0x10>
     2a8:      	mov	w0, #0x1                // =1
     2ac:      	ret
     2b0:      	str	x30, [sp, #-0x20]!
     2b4:      	stp	x20, x19, [sp, #0x10]
     2b8:      	ldr	x8, [x1]
     2bc:      	add	x9, x8, w0, uxtw #3
     2c0:      	ldrh	w9, [x9, #0x6]
     2c4:      	cbz	w9, 0x354 <extract_arg_depth+0xb4>
     2c8:      	mov	w9, w0
     2cc:      	add	x10, x8, x9, lsl #3
     2d0:      	ldr	x8, [x1, #0x8]
     2d4:      	ldr	w11, [x10]
     2d8:      	ldrh	w10, [x10, #0x4]
     2dc:      	ldr	x9, [x8]
     2e0:      	add	x9, x9, x11
     2e4:      	str	x9, [x8]
     2e8:      	cbz	w10, 0x318 <extract_arg_depth+0x78>
     2ec:      	ldrb	w10, [x1, #0x10]
     2f0:      	mov	w19, w0
     2f4:      	cbz	w10, 0x328 <extract_arg_depth+0x88>
     2f8:      	mov	w10, #0x8               // =8
     2fc:      	mov	w11, #0x94              // =148
     300:      	ldr	x0, [x1, #0x8]
     304:      	mov	x20, x1
     308:      	mov	w1, #0x8                // =8
     30c:      	ldr	x2, [x0]
     310:      	blr	x11
     314:      	tbnz	w0, #0x1f, 0x348 <extract_arg_depth+0xa8>
     318:      	mov	w0, wzr
     31c:      	ldp	x20, x19, [sp, #0x10]
     320:      	ldr	x30, [sp], #0x20
     324:      	ret
     328:      	mov	w10, #0x8               // =8
     32c:      	mov	w11, #0x4               // =4
     330:      	ldr	x0, [x1, #0x8]
     334:      	mov	x20, x1
     338:      	mov	w1, #0x8                // =8
     33c:      	ldr	x2, [x0]
     340:      	blr	x11
     344:      	tbz	w0, #0x1f, 0x318 <extract_arg_depth+0x78>
     348:      	ldr	x9, [x20, #0x18]
     34c:      	add	w8, w19, #0x1
     350:      	str	w8, [x9]
     354:      	mov	w0, #0x1                // =1
     358:      	ldp	x20, x19, [sp, #0x10]
     35c:      	ldr	x30, [sp], #0x20
     360:      	ret
     364:      	nop
     368:      	nop
     36c:      	nop

0000000000000370 <do_bytes>:
     370:      	sub	sp, sp, #0x40
     374:      	stp	x30, x23, [sp, #0x10]
     378:      	stp	x22, x21, [sp, #0x20]
     37c:      	stp	x20, x19, [sp, #0x30]
     380:      	mov	x19, x3
     384:      	mov	x21, x2
     388:      	mov	x20, x1
     38c:      	mov	x22, x0
     390:      	bl	0x5b0 <__do_bytes>
     394:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     398:      	and	x23, x0, #0x7fffffff
     39c:      	subs	x3, x19, x23
     3a0:      	b.eq	0x598 <do_bytes+0x228>
     3a4:      	add	x2, x23, x21
     3a8:      	mov	x0, x22
     3ac:      	mov	x1, x20
     3b0:      	bl	0x5b0 <__do_bytes>
     3b4:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     3b8:      	and	x8, x0, #0x7fffffff
     3bc:      	add	x23, x8, x23
     3c0:      	subs	x3, x19, x23
     3c4:      	b.eq	0x598 <do_bytes+0x228>
     3c8:      	add	x2, x23, x21
     3cc:      	mov	x0, x22
     3d0:      	mov	x1, x20
     3d4:      	bl	0x5b0 <__do_bytes>
     3d8:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     3dc:      	and	x8, x0, #0x7fffffff
     3e0:      	add	x23, x8, x23
     3e4:      	subs	x3, x19, x23
     3e8:      	b.eq	0x598 <do_bytes+0x228>
     3ec:      	add	x2, x23, x21
     3f0:      	mov	x0, x22
     3f4:      	mov	x1, x20
     3f8:      	bl	0x5b0 <__do_bytes>
     3fc:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     400:      	and	x8, x0, #0x7fffffff
     404:      	add	x23, x8, x23
     408:      	subs	x3, x19, x23
     40c:      	b.eq	0x598 <do_bytes+0x228>
     410:      	add	x2, x23, x21
     414:      	mov	x0, x22
     418:      	mov	x1, x20
     41c:      	bl	0x5b0 <__do_bytes>
     420:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     424:      	and	x8, x0, #0x7fffffff
     428:      	add	x23, x8, x23
     42c:      	subs	x3, x19, x23
     430:      	b.eq	0x598 <do_bytes+0x228>
     434:      	add	x2, x23, x21
     438:      	mov	x0, x22
     43c:      	mov	x1, x20
     440:      	bl	0x5b0 <__do_bytes>
     444:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     448:      	and	x8, x0, #0x7fffffff
     44c:      	add	x23, x8, x23
     450:      	subs	x3, x19, x23
     454:      	b.eq	0x598 <do_bytes+0x228>
     458:      	add	x2, x23, x21
     45c:      	mov	x0, x22
     460:      	mov	x1, x20
     464:      	bl	0x5b0 <__do_bytes>
     468:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     46c:      	and	x8, x0, #0x7fffffff
     470:      	add	x23, x8, x23
     474:      	subs	x3, x19, x23
     478:      	b.eq	0x598 <do_bytes+0x228>
     47c:      	add	x2, x23, x21
     480:      	mov	x0, x22
     484:      	mov	x1, x20
     488:      	bl	0x5b0 <__do_bytes>
     48c:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     490:      	and	x8, x0, #0x7fffffff
     494:      	add	x23, x8, x23
     498:      	subs	x3, x19, x23
     49c:      	b.eq	0x598 <do_bytes+0x228>
     4a0:      	add	x2, x23, x21
     4a4:      	mov	x0, x22
     4a8:      	mov	x1, x20
     4ac:      	bl	0x5b0 <__do_bytes>
     4b0:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     4b4:      	and	x8, x0, #0x7fffffff
     4b8:      	add	x23, x8, x23
     4bc:      	subs	x3, x19, x23
     4c0:      	b.eq	0x598 <do_bytes+0x228>
     4c4:      	add	x2, x23, x21
     4c8:      	mov	x0, x22
     4cc:      	mov	x1, x20
     4d0:      	bl	0x5b0 <__do_bytes>
     4d4:      	tbnz	w0, #0x1f, 0x4f8 <do_bytes+0x188>
     4d8:      	and	x8, x0, #0x7fffffff
     4dc:      	add	x19, x8, x23
     4e0:      	mov	x0, x19
     4e4:      	ldp	x20, x19, [sp, #0x30]
     4e8:      	ldp	x22, x21, [sp, #0x20]
     4ec:      	ldp	x30, x23, [sp, #0x10]
     4f0:      	add	sp, sp, #0x40
     4f4:      	ret
     4f8:      	sxtw	x19, w0
     4fc:      	str	wzr, [sp, #0xc]
     500:      	adrp	x0, 0x0 <read_reg>
     504:      	mov	w8, #0x1                // =1
     508:      	ldr	x0, [x0]
     50c:      	add	x9, sp, #0xc
     510:      	add	x1, sp, #0xc
     514:      	blr	x8
     518:      	cbz	x0, 0x598 <do_bytes+0x228>
     51c:      	cmn	x19, #0xc
     520:      	b.gt	0x544 <do_bytes+0x1d4>
     524:      	cmn	x19, #0x1c
     528:      	b.eq	0x564 <do_bytes+0x1f4>
     52c:      	cmn	x19, #0x16
     530:      	b.eq	0x57c <do_bytes+0x20c>
     534:      	cmn	x19, #0x10
     538:      	b.ne	0x574 <do_bytes+0x204>
     53c:      	add	x8, x0, #0x558
     540:      	b	0x588 <do_bytes+0x218>
     544:      	cmn	x19, #0xb
     548:      	b.eq	0x56c <do_bytes+0x1fc>
     54c:      	cmn	x19, #0x7
     550:      	b.eq	0x584 <do_bytes+0x214>
     554:      	cmn	x19, #0x2
     558:      	b.ne	0x574 <do_bytes+0x204>
     55c:      	add	x8, x0, #0x548
     560:      	b	0x588 <do_bytes+0x218>
     564:      	add	x8, x0, #0x568
     568:      	b	0x588 <do_bytes+0x218>
     56c:      	add	x8, x0, #0x570
     570:      	b	0x588 <do_bytes+0x218>
     574:      	add	x8, x0, #0x540
     578:      	b	0x588 <do_bytes+0x218>
     57c:      	add	x8, x0, #0x560
     580:      	b	0x588 <do_bytes+0x218>
     584:      	add	x8, x0, #0x550
     588:      	ldaxr	x9, [x8]
     58c:      	add	x9, x9, #0x1
     590:      	stlxr	w10, x9, [x8]
     594:      	cbnz	w10, 0x588 <do_bytes+0x218>
     598:      	mov	x0, x19
     59c:      	ldp	x20, x19, [sp, #0x30]
     5a0:      	ldp	x22, x21, [sp, #0x20]
     5a4:      	ldp	x30, x23, [sp, #0x10]
     5a8:      	add	sp, sp, #0x40
     5ac:      	ret

00000000000005b0 <__do_bytes>:
     5b0:      	str	x30, [sp, #-0x30]!
     5b4:      	stp	x22, x21, [sp, #0x10]
     5b8:      	stp	x20, x19, [sp, #0x20]
     5bc:      	tbnz	x3, #0x3f, 0x654 <__do_bytes+0xa4>
     5c0:      	mov	w8, #0x7fe0             // =32736
     5c4:      	mov	x22, x0
     5c8:      	add	x0, x1, #0x20
     5cc:      	mov	x20, x1
     5d0:      	cmp	x3, x8
     5d4:      	csel	x19, x3, x8, lo
     5d8:      	mov	w8, #0x4                // =4
     5dc:      	mov	w1, w19
     5e0:      	blr	x8
     5e4:      	tbnz	w0, #0x1f, 0x68c <__do_bytes+0xdc>
     5e8:      	add	w21, w19, #0x20
     5ec:      	str	wzr, [sp, #0xc]
     5f0:      	adrp	x0, 0x0 <read_reg>
     5f4:      	mov	w8, #0x1                // =1
     5f8:      	str	w21, [x20, #0x4]
     5fc:      	add	x9, sp, #0xc
     600:      	add	x1, sp, #0xc
     604:      	ldr	x0, [x0]
     608:      	blr	x8
     60c:      	cbz	x0, 0x66c <__do_bytes+0xbc>
     610:      	ldrb	w8, [x0, #0x28]
     614:      	cbz	w8, 0x66c <__do_bytes+0xbc>
     618:      	adrp	x1, 0x0 <read_reg>
     61c:      	mov	w8, #-0x1               // =-1
     620:      	mov	w9, #0x19               // =25
     624:      	ldr	x1, [x1]
     628:      	mov	x0, x22
     62c:      	mov	w2, #-0x1               // =-1
     630:      	mov	x3, x20
     634:      	mov	x4, x21
     638:      	blr	x9
     63c:      	tbnz	w0, #0x1f, 0x68c <__do_bytes+0xdc>
     640:      	mov	x0, x19
     644:      	ldp	x20, x19, [sp, #0x20]
     648:      	ldp	x22, x21, [sp, #0x10]
     64c:      	ldr	x30, [sp], #0x30
     650:      	ret
     654:      	mov	x19, #-0x1              // =-1
     658:      	mov	x0, x19
     65c:      	ldp	x20, x19, [sp, #0x20]
     660:      	ldp	x22, x21, [sp, #0x10]
     664:      	ldr	x30, [sp], #0x30
     668:      	ret
     66c:      	adrp	x0, 0x0 <read_reg>
     670:      	mov	x3, xzr
     674:      	mov	w8, #0x82               // =130
     678:      	ldr	x0, [x0]
     67c:      	mov	x1, x20
     680:      	mov	x2, x21
     684:      	blr	x8
     688:      	tbz	w0, #0x1f, 0x640 <__do_bytes+0x90>
     68c:      	sxtw	x19, w0
     690:      	mov	x0, x19
     694:      	ldp	x20, x19, [sp, #0x20]
     698:      	ldp	x22, x21, [sp, #0x10]
     69c:      	ldr	x30, [sp], #0x30
     6a0:      	ret
     6a4:      	nop
     6a8:      	nop
     6ac:      	nop

00000000000006b0 <filter_64ty>:
     6b0:      	str	x30, [sp, #-0x10]!
     6b4:      	mov	x8, x0
     6b8:      	mov	x0, xzr
     6bc:      	ldr	w9, [x8, #0x4]
     6c0:      	cmp	w9, #0x20
     6c4:      	b.hi	0x724 <filter_64ty+0x74>
     6c8:      	mov	w10, #0x1               // =1
     6cc:      	mov	w11, #0x101e            // =4126
     6d0:      	lsl	x10, x10, x9
     6d4:      	tst	x10, x11
     6d8:      	b.eq	0x6ec <filter_64ty+0x3c>
     6dc:      	mov	x0, x8
     6e0:      	bl	0x8b0 <filter_64ty_selector_val>
     6e4:      	ldr	x30, [sp], #0x10
     6e8:      	ret
     6ec:      	mov	w10, #0x1               // =1
     6f0:      	lsl	x10, x10, x9
     6f4:      	tst	x10, #0xc00
     6f8:      	b.ne	0x71c <filter_64ty+0x6c>
     6fc:      	mov	w10, #0x1               // =1
     700:      	lsl	x9, x10, x9
     704:      	tst	x9, #0x180000000
     708:      	b.eq	0x724 <filter_64ty+0x74>
     70c:      	mov	x0, x8
     710:      	bl	0xcb0 <filter_64ty_range>
     714:      	ldr	x30, [sp], #0x10
     718:      	ret
     71c:      	mov	x0, x8
     720:      	bl	0xc10 <filter_64ty_map>
     724:      	ldr	x30, [sp], #0x10
     728:      	ret
     72c:      	nop

0000000000000730 <filter_32ty>:
     730:      	str	x30, [sp, #-0x10]!
     734:      	mov	x8, x0
     738:      	mov	x0, xzr
     73c:      	ldr	w9, [x8, #0x4]
     740:      	cmp	w9, #0x20
     744:      	b.hi	0x7a4 <filter_32ty+0x74>
     748:      	mov	w10, #0x1               // =1
     74c:      	mov	w11, #0x101e            // =4126
     750:      	lsl	x10, x10, x9
     754:      	tst	x10, x11
     758:      	b.eq	0x76c <filter_32ty+0x3c>
     75c:      	mov	x0, x8
     760:      	bl	0xf00 <filter_32ty_selector_val>
     764:      	ldr	x30, [sp], #0x10
     768:      	ret
     76c:      	mov	w10, #0x1               // =1
     770:      	lsl	x10, x10, x9
     774:      	tst	x10, #0xc00
     778:      	b.ne	0x79c <filter_32ty+0x6c>
     77c:      	mov	w10, #0x1               // =1
     780:      	lsl	x9, x10, x9
     784:      	tst	x9, #0x180000000
     788:      	b.eq	0x7a4 <filter_32ty+0x74>
     78c:      	mov	x0, x8
     790:      	bl	0x1320 <filter_32ty_range>
     794:      	ldr	x30, [sp], #0x10
     798:      	ret
     79c:      	mov	x0, x8
     7a0:      	bl	0x1260 <filter_32ty_map>
     7a4:      	ldr	x30, [sp], #0x10
     7a8:      	ret
     7ac:      	nop

00000000000007b0 <filter_16ty>:
     7b0:      	str	x30, [sp, #-0x10]!
     7b4:      	mov	x8, x0
     7b8:      	mov	x0, xzr
     7bc:      	ldr	w9, [x8, #0x4]
     7c0:      	cmp	w9, #0x20
     7c4:      	b.hi	0x824 <filter_16ty+0x74>
     7c8:      	mov	w10, #0x1               // =1
     7cc:      	mov	w11, #0x101e            // =4126
     7d0:      	lsl	x10, x10, x9
     7d4:      	tst	x10, x11
     7d8:      	b.eq	0x7ec <filter_16ty+0x3c>
     7dc:      	mov	x0, x8
     7e0:      	bl	0x1570 <filter_16ty_selector_val>
     7e4:      	ldr	x30, [sp], #0x10
     7e8:      	ret
     7ec:      	mov	w10, #0x1               // =1
     7f0:      	lsl	x10, x10, x9
     7f4:      	tst	x10, #0xc00
     7f8:      	b.ne	0x81c <filter_16ty+0x6c>
     7fc:      	mov	w10, #0x1               // =1
     800:      	lsl	x9, x10, x9
     804:      	tst	x9, #0x180000000
     808:      	b.eq	0x824 <filter_16ty+0x74>
     80c:      	mov	x0, x8
     810:      	bl	0x1990 <filter_16ty_range>
     814:      	ldr	x30, [sp], #0x10
     818:      	ret
     81c:      	mov	x0, x8
     820:      	bl	0x18d0 <filter_16ty_map>
     824:      	ldr	x30, [sp], #0x10
     828:      	ret
     82c:      	nop

0000000000000830 <filter_8ty>:
     830:      	str	x30, [sp, #-0x10]!
     834:      	mov	x8, x0
     838:      	mov	x0, xzr
     83c:      	ldr	w9, [x8, #0x4]
     840:      	cmp	w9, #0x20
     844:      	b.hi	0x8a4 <filter_8ty+0x74>
     848:      	mov	w10, #0x1               // =1
     84c:      	mov	w11, #0x101e            // =4126
     850:      	lsl	x10, x10, x9
     854:      	tst	x10, x11
     858:      	b.eq	0x86c <filter_8ty+0x3c>
     85c:      	mov	x0, x8
     860:      	bl	0x1be0 <filter_8ty_selector_val>
     864:      	ldr	x30, [sp], #0x10
     868:      	ret
     86c:      	mov	w10, #0x1               // =1
     870:      	lsl	x10, x10, x9
     874:      	tst	x10, #0xc00
     878:      	b.ne	0x89c <filter_8ty+0x6c>
     87c:      	mov	w10, #0x1               // =1
     880:      	lsl	x9, x10, x9
     884:      	tst	x9, #0x180000000
     888:      	b.eq	0x8a4 <filter_8ty+0x74>
     88c:      	mov	x0, x8
     890:      	bl	0x2000 <filter_8ty_range>
     894:      	ldr	x30, [sp], #0x10
     898:      	ret
     89c:      	mov	x0, x8
     8a0:      	bl	0x1f40 <filter_8ty_map>
     8a4:      	ldr	x30, [sp], #0x10
     8a8:      	ret
     8ac:      	nop

00000000000008b0 <filter_64ty_selector_val>:
     8b0:      	ldr	w8, [x0, #0x4]
     8b4:      	cmp	w8, #0x25
     8b8:      	b.hi	0x92c <filter_64ty_selector_val+0x7c>
     8bc:      	mov	x10, #0x40              // =64
     8c0:      	mov	w9, #0x1                // =1
     8c4:      	movk	x10, #0xc00, lsl #16
     8c8:      	lsl	x9, x9, x8
     8cc:      	movk	x10, #0x20, lsl #32
     8d0:      	tst	x9, x10
     8d4:      	b.eq	0x8e0 <filter_64ty_selector_val+0x30>
     8d8:      	mov	w0, #0x1                // =1
     8dc:      	ret
     8e0:      	mov	w9, #0x1                // =1
     8e4:      	lsl	x9, x9, x8
     8e8:      	tst	x9, #0x18
     8ec:      	b.eq	0x90c <filter_64ty_selector_val+0x5c>
     8f0:      	ldr	x9, [x1]
     8f4:      	ldr	x10, [x0, #0x10]
     8f8:      	cmp	x9, x10
     8fc:      	b.ne	0x9ac <filter_64ty_selector_val+0xfc>
     900:      	cmp	w8, #0x3
     904:      	cset	w0, eq
     908:      	ret
     90c:      	cmp	x8, #0xc
     910:      	b.ne	0x92c <filter_64ty_selector_val+0x7c>
     914:      	ldr	x8, [x1]
     918:      	ldr	x9, [x0, #0x10]
     91c:      	tst	x8, x9
     920:      	b.eq	0xa58 <filter_64ty_selector_val+0x1a8>
     924:      	mov	w0, #0x1                // =1
     928:      	ret
     92c:      	cmp	w8, #0x1
     930:      	b.eq	0x974 <filter_64ty_selector_val+0xc4>
     934:      	cmp	w8, #0x2
     938:      	b.ne	0xc00 <filter_64ty_selector_val+0x350>
     93c:      	ldr	w8, [x0, #0xc]
     940:      	cmp	w8, #0xc
     944:      	b.hi	0xa90 <filter_64ty_selector_val+0x1e0>
     948:      	mov	w9, #0x1                // =1
     94c:      	lsl	w8, w9, w8
     950:      	mov	w9, #0x1402             // =5122
     954:      	tst	w8, w9
     958:      	b.eq	0xa90 <filter_64ty_selector_val+0x1e0>
     95c:      	ldr	x8, [x1]
     960:      	ldr	x9, [x0, #0x10]
     964:      	cmp	x8, x9
     968:      	b.ge	0xa38 <filter_64ty_selector_val+0x188>
     96c:      	mov	w0, #0x1                // =1
     970:      	ret
     974:      	ldr	w8, [x0, #0xc]
     978:      	cmp	w8, #0xc
     97c:      	b.hi	0xa78 <filter_64ty_selector_val+0x1c8>
     980:      	mov	w9, #0x1                // =1
     984:      	lsl	w8, w9, w8
     988:      	mov	w9, #0x1402             // =5122
     98c:      	tst	w8, w9
     990:      	b.eq	0xa78 <filter_64ty_selector_val+0x1c8>
     994:      	ldr	x8, [x1]
     998:      	ldr	x9, [x0, #0x10]
     99c:      	cmp	x8, x9
     9a0:      	b.le	0xa18 <filter_64ty_selector_val+0x168>
     9a4:      	mov	w0, #0x1                // =1
     9a8:      	ret
     9ac:      	ldr	w10, [x0, #0x8]
     9b0:      	cmp	w10, #0x11
     9b4:      	b.lo	0x9ec <filter_64ty_selector_val+0x13c>
     9b8:      	ldr	x11, [x0, #0x18]
     9bc:      	cmp	x9, x11
     9c0:      	b.eq	0x900 <filter_64ty_selector_val+0x50>
     9c4:      	cmp	w10, #0x19
     9c8:      	b.lo	0x9ec <filter_64ty_selector_val+0x13c>
     9cc:      	ldr	x11, [x0, #0x20]
     9d0:      	cmp	x9, x11
     9d4:      	b.eq	0x900 <filter_64ty_selector_val+0x50>
     9d8:      	cmp	w10, #0x21
     9dc:      	b.lo	0x9ec <filter_64ty_selector_val+0x13c>
     9e0:      	ldr	x10, [x0, #0x28]
     9e4:      	cmp	x9, x10
     9e8:      	b.eq	0x900 <filter_64ty_selector_val+0x50>
     9ec:      	cmp	w8, #0x25
     9f0:      	b.hi	0xc00 <filter_64ty_selector_val+0x350>
     9f4:      	mov	w9, #0x1                // =1
     9f8:      	lsl	x8, x9, x8
     9fc:      	mov	x9, #0x50               // =80
     a00:      	movk	x9, #0xc00, lsl #16
     a04:      	movk	x9, #0x20, lsl #32
     a08:      	tst	x8, x9
     a0c:      	b.eq	0xc00 <filter_64ty_selector_val+0x350>
     a10:      	mov	w0, #0x1                // =1
     a14:      	ret
     a18:      	ldr	w9, [x0, #0x8]
     a1c:      	cmp	w9, #0x11
     a20:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     a24:      	ldr	x10, [x0, #0x18]
     a28:      	cmp	x8, x10
     a2c:      	b.le	0xae8 <filter_64ty_selector_val+0x238>
     a30:      	mov	w0, #0x1                // =1
     a34:      	ret
     a38:      	ldr	w9, [x0, #0x8]
     a3c:      	cmp	w9, #0x11
     a40:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     a44:      	ldr	x10, [x0, #0x18]
     a48:      	cmp	x8, x10
     a4c:      	b.ge	0xb04 <filter_64ty_selector_val+0x254>
     a50:      	mov	w0, #0x1                // =1
     a54:      	ret
     a58:      	ldr	w9, [x0, #0x8]
     a5c:      	cmp	w9, #0x11
     a60:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     a64:      	ldr	x10, [x0, #0x18]
     a68:      	tst	x8, x10
     a6c:      	b.eq	0xb20 <filter_64ty_selector_val+0x270>
     a70:      	mov	w0, #0x1                // =1
     a74:      	ret
     a78:      	ldr	x8, [x1]
     a7c:      	ldr	x9, [x0, #0x10]
     a80:      	cmp	x8, x9
     a84:      	b.ls	0xaa8 <filter_64ty_selector_val+0x1f8>
     a88:      	mov	w0, #0x1                // =1
     a8c:      	ret
     a90:      	ldr	x8, [x1]
     a94:      	ldr	x9, [x0, #0x10]
     a98:      	cmp	x8, x9
     a9c:      	b.hs	0xac8 <filter_64ty_selector_val+0x218>
     aa0:      	mov	w0, #0x1                // =1
     aa4:      	ret
     aa8:      	ldr	w9, [x0, #0x8]
     aac:      	cmp	w9, #0x11
     ab0:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     ab4:      	ldr	x10, [x0, #0x18]
     ab8:      	cmp	x8, x10
     abc:      	b.ls	0xb3c <filter_64ty_selector_val+0x28c>
     ac0:      	mov	w0, #0x1                // =1
     ac4:      	ret
     ac8:      	ldr	w9, [x0, #0x8]
     acc:      	cmp	w9, #0x11
     ad0:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     ad4:      	ldr	x10, [x0, #0x18]
     ad8:      	cmp	x8, x10
     adc:      	b.hs	0xb58 <filter_64ty_selector_val+0x2a8>
     ae0:      	mov	w0, #0x1                // =1
     ae4:      	ret
     ae8:      	cmp	w9, #0x19
     aec:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     af0:      	ldr	x10, [x0, #0x20]
     af4:      	cmp	x8, x10
     af8:      	b.le	0xb74 <filter_64ty_selector_val+0x2c4>
     afc:      	mov	w0, #0x1                // =1
     b00:      	ret
     b04:      	cmp	w9, #0x19
     b08:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     b0c:      	ldr	x10, [x0, #0x20]
     b10:      	cmp	x8, x10
     b14:      	b.ge	0xb90 <filter_64ty_selector_val+0x2e0>
     b18:      	mov	w0, #0x1                // =1
     b1c:      	ret
     b20:      	cmp	w9, #0x19
     b24:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     b28:      	ldr	x10, [x0, #0x20]
     b2c:      	tst	x8, x10
     b30:      	b.eq	0xbac <filter_64ty_selector_val+0x2fc>
     b34:      	mov	w0, #0x1                // =1
     b38:      	ret
     b3c:      	cmp	w9, #0x19
     b40:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     b44:      	ldr	x10, [x0, #0x20]
     b48:      	cmp	x8, x10
     b4c:      	b.ls	0xbc8 <filter_64ty_selector_val+0x318>
     b50:      	mov	w0, #0x1                // =1
     b54:      	ret
     b58:      	cmp	w9, #0x19
     b5c:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     b60:      	ldr	x10, [x0, #0x20]
     b64:      	cmp	x8, x10
     b68:      	b.hs	0xbe4 <filter_64ty_selector_val+0x334>
     b6c:      	mov	w0, #0x1                // =1
     b70:      	ret
     b74:      	cmp	w9, #0x21
     b78:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     b7c:      	ldr	x9, [x0, #0x28]
     b80:      	cmp	x8, x9
     b84:      	b.le	0xc00 <filter_64ty_selector_val+0x350>
     b88:      	mov	w0, #0x1                // =1
     b8c:      	ret
     b90:      	cmp	w9, #0x21
     b94:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     b98:      	ldr	x9, [x0, #0x28]
     b9c:      	cmp	x8, x9
     ba0:      	b.ge	0xc00 <filter_64ty_selector_val+0x350>
     ba4:      	mov	w0, #0x1                // =1
     ba8:      	ret
     bac:      	cmp	w9, #0x21
     bb0:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     bb4:      	ldr	x9, [x0, #0x28]
     bb8:      	tst	x8, x9
     bbc:      	b.eq	0xc00 <filter_64ty_selector_val+0x350>
     bc0:      	mov	w0, #0x1                // =1
     bc4:      	ret
     bc8:      	cmp	w9, #0x21
     bcc:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     bd0:      	ldr	x9, [x0, #0x28]
     bd4:      	cmp	x8, x9
     bd8:      	b.ls	0xc00 <filter_64ty_selector_val+0x350>
     bdc:      	mov	w0, #0x1                // =1
     be0:      	ret
     be4:      	cmp	w9, #0x21
     be8:      	b.lo	0xc00 <filter_64ty_selector_val+0x350>
     bec:      	ldr	x9, [x0, #0x28]
     bf0:      	cmp	x8, x9
     bf4:      	b.hs	0xc00 <filter_64ty_selector_val+0x350>
     bf8:      	mov	w0, #0x1                // =1
     bfc:      	ret
     c00:      	mov	x0, xzr
     c04:      	ret
     c08:      	nop
     c0c:      	nop

0000000000000c10 <filter_64ty_map>:
     c10:      	sub	sp, sp, #0x30
     c14:      	str	x30, [sp, #0x10]
     c18:      	stp	x20, x19, [sp, #0x20]
     c1c:      	ldrb	w8, [x0, #0x10]
     c20:      	mov	x19, x0
     c24:      	adrp	x0, 0x0 <read_reg>
     c28:      	add	x9, sp, #0x1c
     c2c:      	str	w8, [sp, #0x1c]
     c30:      	mov	w8, #0x1                // =1
     c34:      	mov	x20, x1
     c38:      	add	x1, sp, #0x1c
     c3c:      	ldr	x0, [x0]
     c40:      	blr	x8
     c44:      	cbz	x0, 0xc94 <filter_64ty_map+0x84>
     c48:      	ldr	x8, [x20]
     c4c:      	add	x9, sp, #0x8
     c50:      	add	x1, sp, #0x8
     c54:      	str	x8, [sp, #0x8]
     c58:      	mov	w8, #0x1                // =1
     c5c:      	blr	x8
     c60:      	ldr	w8, [x19, #0x4]
     c64:      	cmp	w8, #0xb
     c68:      	b.eq	0xc80 <filter_64ty_map+0x70>
     c6c:      	cmp	w8, #0xa
     c70:      	b.ne	0xc8c <filter_64ty_map+0x7c>
     c74:      	cmp	x0, #0x0
     c78:      	cset	w8, ne
     c7c:      	b	0xc90 <filter_64ty_map+0x80>
     c80:      	cmp	x0, #0x0
     c84:      	cset	w8, eq
     c88:      	b	0xc90 <filter_64ty_map+0x80>
     c8c:      	mov	w8, wzr
     c90:      	mov	w0, w8
     c94:      	ldp	x20, x19, [sp, #0x20]
     c98:      	ldr	x30, [sp, #0x10]
     c9c:      	add	sp, sp, #0x30
     ca0:      	ret
     ca4:      	nop
     ca8:      	nop
     cac:      	nop

0000000000000cb0 <filter_64ty_range>:
     cb0:      	ldr	w9, [x0, #0xc]
     cb4:      	ldr	w8, [x0, #0x4]
     cb8:      	mov	w10, #0x1               // =1
     cbc:      	cmp	w9, #0xc
     cc0:      	lsl	w9, w10, w9
     cc4:      	mov	w10, #0x1402            // =5122
     cc8:      	and	w9, w9, w10
     ccc:      	ccmp	w9, #0x0, #0x4, ls
     cd0:      	b.eq	0xdd0 <filter_64ty_range+0x120>
     cd4:      	ldr	x10, [x1]
     cd8:      	cmp	w8, #0x1f
     cdc:      	b.ne	0xd64 <filter_64ty_range+0xb4>
     ce0:      	ldr	x9, [x0, #0x10]
     ce4:      	cmp	x9, x10
     ce8:      	b.gt	0xcf8 <filter_64ty_range+0x48>
     cec:      	ldr	x9, [x0, #0x18]
     cf0:      	cmp	x10, x9
     cf4:      	b.le	0xdf4 <filter_64ty_range+0x144>
     cf8:      	ldr	w9, [x0, #0x8]
     cfc:      	cmp	w9, #0x19
     d00:      	b.lo	0xee0 <filter_64ty_range+0x230>
     d04:      	ldr	x11, [x0, #0x20]
     d08:      	cmp	x11, x10
     d0c:      	b.gt	0xd1c <filter_64ty_range+0x6c>
     d10:      	ldr	x11, [x0, #0x28]
     d14:      	cmp	x10, x11
     d18:      	b.le	0xdf4 <filter_64ty_range+0x144>
     d1c:      	cmp	w9, #0x29
     d20:      	b.lo	0xee0 <filter_64ty_range+0x230>
     d24:      	ldr	x11, [x0, #0x30]
     d28:      	cmp	x11, x10
     d2c:      	b.gt	0xd3c <filter_64ty_range+0x8c>
     d30:      	ldr	x11, [x0, #0x38]
     d34:      	cmp	x10, x11
     d38:      	b.le	0xdf4 <filter_64ty_range+0x144>
     d3c:      	cmp	w9, #0x39
     d40:      	b.lo	0xee0 <filter_64ty_range+0x230>
     d44:      	ldr	x11, [x0, #0x40]
     d48:      	mov	w9, wzr
     d4c:      	cmp	x11, x10
     d50:      	b.gt	0xed0 <filter_64ty_range+0x220>
     d54:      	ldr	x11, [x0, #0x48]
     d58:      	cmp	x10, x11
     d5c:      	b.le	0xdf4 <filter_64ty_range+0x144>
     d60:      	b	0xed0 <filter_64ty_range+0x220>
     d64:      	ldp	x9, x12, [x0, #0x10]
     d68:      	cmp	x9, x10
     d6c:      	ldr	w11, [x0, #0x8]
     d70:      	ccmp	x10, x12, #0x0, le
     d74:      	cset	w9, le
     d78:      	cmp	w11, #0x19
     d7c:      	b.lo	0xed0 <filter_64ty_range+0x220>
     d80:      	ldp	x12, x13, [x0, #0x20]
     d84:      	cmp	x12, x10
     d88:      	ccmp	x10, x13, #0x0, le
     d8c:      	csinc	w9, w9, wzr, gt
     d90:      	cmp	w11, #0x29
     d94:      	b.lo	0xed0 <filter_64ty_range+0x220>
     d98:      	ldp	x12, x13, [x0, #0x30]
     d9c:      	cmp	x12, x10
     da0:      	ccmp	x10, x13, #0x0, le
     da4:      	csinc	w9, w9, wzr, gt
     da8:      	cmp	w11, #0x39
     dac:      	b.lo	0xed0 <filter_64ty_range+0x220>
     db0:      	ldp	x11, x12, [x0, #0x40]
     db4:      	cmp	x11, x10
     db8:      	ccmp	x10, x12, #0x0, le
     dbc:      	csinc	w9, w9, wzr, gt
     dc0:      	cmp	w8, #0x20
     dc4:      	eor	w8, w9, #0x1
     dc8:      	csel	w0, wzr, w8, ne
     dcc:      	ret
     dd0:      	ldr	x10, [x1]
     dd4:      	cmp	w8, #0x1f
     dd8:      	b.ne	0xdfc <filter_64ty_range+0x14c>
     ddc:      	ldr	x9, [x0, #0x10]
     de0:      	cmp	x9, x10
     de4:      	b.hi	0xe68 <filter_64ty_range+0x1b8>
     de8:      	ldr	x9, [x0, #0x18]
     dec:      	cmp	x10, x9
     df0:      	b.hi	0xe68 <filter_64ty_range+0x1b8>
     df4:      	mov	w0, #0x1                // =1
     df8:      	ret
     dfc:      	ldp	x9, x12, [x0, #0x10]
     e00:      	cmp	x9, x10
     e04:      	ldr	w11, [x0, #0x8]
     e08:      	ccmp	x10, x12, #0x2, ls
     e0c:      	cset	w9, ls
     e10:      	cmp	w11, #0x19
     e14:      	b.lo	0xed0 <filter_64ty_range+0x220>
     e18:      	ldp	x12, x13, [x0, #0x20]
     e1c:      	cmp	x12, x10
     e20:      	ccmp	x10, x13, #0x2, ls
     e24:      	csinc	w9, w9, wzr, hi
     e28:      	cmp	w11, #0x29
     e2c:      	b.lo	0xed0 <filter_64ty_range+0x220>
     e30:      	ldp	x12, x13, [x0, #0x30]
     e34:      	cmp	x12, x10
     e38:      	ccmp	x10, x13, #0x2, ls
     e3c:      	csinc	w9, w9, wzr, hi
     e40:      	cmp	w11, #0x39
     e44:      	b.lo	0xed0 <filter_64ty_range+0x220>
     e48:      	ldp	x11, x12, [x0, #0x40]
     e4c:      	cmp	x11, x10
     e50:      	ccmp	x10, x12, #0x2, ls
     e54:      	csinc	w9, w9, wzr, hi
     e58:      	cmp	w8, #0x20
     e5c:      	eor	w8, w9, #0x1
     e60:      	csel	w0, wzr, w8, ne
     e64:      	ret
     e68:      	ldr	w9, [x0, #0x8]
     e6c:      	cmp	w9, #0x19
     e70:      	b.lo	0xee0 <filter_64ty_range+0x230>
     e74:      	ldr	x11, [x0, #0x20]
     e78:      	cmp	x11, x10
     e7c:      	b.hi	0xe8c <filter_64ty_range+0x1dc>
     e80:      	ldr	x11, [x0, #0x28]
     e84:      	cmp	x10, x11
     e88:      	b.ls	0xdf4 <filter_64ty_range+0x144>
     e8c:      	cmp	w9, #0x29
     e90:      	b.lo	0xee0 <filter_64ty_range+0x230>
     e94:      	ldr	x11, [x0, #0x30]
     e98:      	cmp	x11, x10
     e9c:      	b.hi	0xeac <filter_64ty_range+0x1fc>
     ea0:      	ldr	x11, [x0, #0x38]
     ea4:      	cmp	x10, x11
     ea8:      	b.ls	0xdf4 <filter_64ty_range+0x144>
     eac:      	cmp	w9, #0x39
     eb0:      	b.lo	0xee0 <filter_64ty_range+0x230>
     eb4:      	ldr	x11, [x0, #0x40]
     eb8:      	mov	w9, wzr
     ebc:      	cmp	x11, x10
     ec0:      	b.hi	0xed0 <filter_64ty_range+0x220>
     ec4:      	ldr	x11, [x0, #0x48]
     ec8:      	cmp	x10, x11
     ecc:      	b.ls	0xdf4 <filter_64ty_range+0x144>
     ed0:      	cmp	w8, #0x20
     ed4:      	eor	w8, w9, #0x1
     ed8:      	csel	w0, wzr, w8, ne
     edc:      	ret
     ee0:      	mov	w9, wzr
     ee4:      	cmp	w8, #0x20
     ee8:      	eor	w8, w9, #0x1
     eec:      	csel	w0, wzr, w8, ne
     ef0:      	ret
     ef4:      	nop
     ef8:      	nop
     efc:      	nop

0000000000000f00 <filter_32ty_selector_val>:
     f00:      	ldr	w8, [x0, #0x4]
     f04:      	cmp	w8, #0x25
     f08:      	b.hi	0xf7c <filter_32ty_selector_val+0x7c>
     f0c:      	mov	x10, #0x40              // =64
     f10:      	mov	w9, #0x1                // =1
     f14:      	movk	x10, #0xc00, lsl #16
     f18:      	lsl	x9, x9, x8
     f1c:      	movk	x10, #0x20, lsl #32
     f20:      	tst	x9, x10
     f24:      	b.eq	0xf30 <filter_32ty_selector_val+0x30>
     f28:      	mov	w0, #0x1                // =1
     f2c:      	ret
     f30:      	mov	w9, #0x1                // =1
     f34:      	lsl	x9, x9, x8
     f38:      	tst	x9, #0x18
     f3c:      	b.eq	0xf5c <filter_32ty_selector_val+0x5c>
     f40:      	ldr	w9, [x1]
     f44:      	ldr	w10, [x0, #0x10]
     f48:      	cmp	w9, w10
     f4c:      	b.ne	0xffc <filter_32ty_selector_val+0xfc>
     f50:      	cmp	w8, #0x3
     f54:      	cset	w0, eq
     f58:      	ret
     f5c:      	cmp	x8, #0xc
     f60:      	b.ne	0xf7c <filter_32ty_selector_val+0x7c>
     f64:      	ldr	w8, [x1]
     f68:      	ldr	w9, [x0, #0x10]
     f6c:      	tst	w8, w9
     f70:      	b.eq	0x10a8 <filter_32ty_selector_val+0x1a8>
     f74:      	mov	w0, #0x1                // =1
     f78:      	ret
     f7c:      	cmp	w8, #0x1
     f80:      	b.eq	0xfc4 <filter_32ty_selector_val+0xc4>
     f84:      	cmp	w8, #0x2
     f88:      	b.ne	0x1250 <filter_32ty_selector_val+0x350>
     f8c:      	ldr	w8, [x0, #0xc]
     f90:      	cmp	w8, #0xc
     f94:      	b.hi	0x10e0 <filter_32ty_selector_val+0x1e0>
     f98:      	mov	w9, #0x1                // =1
     f9c:      	lsl	w8, w9, w8
     fa0:      	mov	w9, #0x1402             // =5122
     fa4:      	tst	w8, w9
     fa8:      	b.eq	0x10e0 <filter_32ty_selector_val+0x1e0>
     fac:      	ldr	w8, [x1]
     fb0:      	ldr	w9, [x0, #0x10]
     fb4:      	cmp	w8, w9
     fb8:      	b.ge	0x1088 <filter_32ty_selector_val+0x188>
     fbc:      	mov	w0, #0x1                // =1
     fc0:      	ret
     fc4:      	ldr	w8, [x0, #0xc]
     fc8:      	cmp	w8, #0xc
     fcc:      	b.hi	0x10c8 <filter_32ty_selector_val+0x1c8>
     fd0:      	mov	w9, #0x1                // =1
     fd4:      	lsl	w8, w9, w8
     fd8:      	mov	w9, #0x1402             // =5122
     fdc:      	tst	w8, w9
     fe0:      	b.eq	0x10c8 <filter_32ty_selector_val+0x1c8>
     fe4:      	ldr	w8, [x1]
     fe8:      	ldr	w9, [x0, #0x10]
     fec:      	cmp	w8, w9
     ff0:      	b.le	0x1068 <filter_32ty_selector_val+0x168>
     ff4:      	mov	w0, #0x1                // =1
     ff8:      	ret
     ffc:      	ldr	w10, [x0, #0x8]
    1000:      	cmp	w10, #0xd
    1004:      	b.lo	0x103c <filter_32ty_selector_val+0x13c>
    1008:      	ldr	w11, [x0, #0x14]
    100c:      	cmp	w9, w11
    1010:      	b.eq	0xf50 <filter_32ty_selector_val+0x50>
    1014:      	cmp	w10, #0x11
    1018:      	b.lo	0x103c <filter_32ty_selector_val+0x13c>
    101c:      	ldr	w11, [x0, #0x18]
    1020:      	cmp	w9, w11
    1024:      	b.eq	0xf50 <filter_32ty_selector_val+0x50>
    1028:      	cmp	w10, #0x15
    102c:      	b.lo	0x103c <filter_32ty_selector_val+0x13c>
    1030:      	ldr	w10, [x0, #0x1c]
    1034:      	cmp	w9, w10
    1038:      	b.eq	0xf50 <filter_32ty_selector_val+0x50>
    103c:      	cmp	w8, #0x25
    1040:      	b.hi	0x1250 <filter_32ty_selector_val+0x350>
    1044:      	mov	w9, #0x1                // =1
    1048:      	lsl	x8, x9, x8
    104c:      	mov	x9, #0x50               // =80
    1050:      	movk	x9, #0xc00, lsl #16
    1054:      	movk	x9, #0x20, lsl #32
    1058:      	tst	x8, x9
    105c:      	b.eq	0x1250 <filter_32ty_selector_val+0x350>
    1060:      	mov	w0, #0x1                // =1
    1064:      	ret
    1068:      	ldr	w9, [x0, #0x8]
    106c:      	cmp	w9, #0xd
    1070:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1074:      	ldr	w10, [x0, #0x14]
    1078:      	cmp	w8, w10
    107c:      	b.le	0x1138 <filter_32ty_selector_val+0x238>
    1080:      	mov	w0, #0x1                // =1
    1084:      	ret
    1088:      	ldr	w9, [x0, #0x8]
    108c:      	cmp	w9, #0xd
    1090:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1094:      	ldr	w10, [x0, #0x14]
    1098:      	cmp	w8, w10
    109c:      	b.ge	0x1154 <filter_32ty_selector_val+0x254>
    10a0:      	mov	w0, #0x1                // =1
    10a4:      	ret
    10a8:      	ldr	w9, [x0, #0x8]
    10ac:      	cmp	w9, #0xd
    10b0:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    10b4:      	ldr	w10, [x0, #0x14]
    10b8:      	tst	w8, w10
    10bc:      	b.eq	0x1170 <filter_32ty_selector_val+0x270>
    10c0:      	mov	w0, #0x1                // =1
    10c4:      	ret
    10c8:      	ldr	w8, [x1]
    10cc:      	ldr	w9, [x0, #0x10]
    10d0:      	cmp	w8, w9
    10d4:      	b.ls	0x10f8 <filter_32ty_selector_val+0x1f8>
    10d8:      	mov	w0, #0x1                // =1
    10dc:      	ret
    10e0:      	ldr	w8, [x1]
    10e4:      	ldr	w9, [x0, #0x10]
    10e8:      	cmp	w8, w9
    10ec:      	b.hs	0x1118 <filter_32ty_selector_val+0x218>
    10f0:      	mov	w0, #0x1                // =1
    10f4:      	ret
    10f8:      	ldr	w9, [x0, #0x8]
    10fc:      	cmp	w9, #0xd
    1100:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1104:      	ldr	w10, [x0, #0x14]
    1108:      	cmp	w8, w10
    110c:      	b.ls	0x118c <filter_32ty_selector_val+0x28c>
    1110:      	mov	w0, #0x1                // =1
    1114:      	ret
    1118:      	ldr	w9, [x0, #0x8]
    111c:      	cmp	w9, #0xd
    1120:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1124:      	ldr	w10, [x0, #0x14]
    1128:      	cmp	w8, w10
    112c:      	b.hs	0x11a8 <filter_32ty_selector_val+0x2a8>
    1130:      	mov	w0, #0x1                // =1
    1134:      	ret
    1138:      	cmp	w9, #0x11
    113c:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1140:      	ldr	w10, [x0, #0x18]
    1144:      	cmp	w8, w10
    1148:      	b.le	0x11c4 <filter_32ty_selector_val+0x2c4>
    114c:      	mov	w0, #0x1                // =1
    1150:      	ret
    1154:      	cmp	w9, #0x11
    1158:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    115c:      	ldr	w10, [x0, #0x18]
    1160:      	cmp	w8, w10
    1164:      	b.ge	0x11e0 <filter_32ty_selector_val+0x2e0>
    1168:      	mov	w0, #0x1                // =1
    116c:      	ret
    1170:      	cmp	w9, #0x11
    1174:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1178:      	ldr	w10, [x0, #0x18]
    117c:      	tst	w8, w10
    1180:      	b.eq	0x11fc <filter_32ty_selector_val+0x2fc>
    1184:      	mov	w0, #0x1                // =1
    1188:      	ret
    118c:      	cmp	w9, #0x11
    1190:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1194:      	ldr	w10, [x0, #0x18]
    1198:      	cmp	w8, w10
    119c:      	b.ls	0x1218 <filter_32ty_selector_val+0x318>
    11a0:      	mov	w0, #0x1                // =1
    11a4:      	ret
    11a8:      	cmp	w9, #0x11
    11ac:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    11b0:      	ldr	w10, [x0, #0x18]
    11b4:      	cmp	w8, w10
    11b8:      	b.hs	0x1234 <filter_32ty_selector_val+0x334>
    11bc:      	mov	w0, #0x1                // =1
    11c0:      	ret
    11c4:      	cmp	w9, #0x15
    11c8:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    11cc:      	ldr	w9, [x0, #0x1c]
    11d0:      	cmp	w8, w9
    11d4:      	b.le	0x1250 <filter_32ty_selector_val+0x350>
    11d8:      	mov	w0, #0x1                // =1
    11dc:      	ret
    11e0:      	cmp	w9, #0x15
    11e4:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    11e8:      	ldr	w9, [x0, #0x1c]
    11ec:      	cmp	w8, w9
    11f0:      	b.ge	0x1250 <filter_32ty_selector_val+0x350>
    11f4:      	mov	w0, #0x1                // =1
    11f8:      	ret
    11fc:      	cmp	w9, #0x15
    1200:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1204:      	ldr	w9, [x0, #0x1c]
    1208:      	tst	w8, w9
    120c:      	b.eq	0x1250 <filter_32ty_selector_val+0x350>
    1210:      	mov	w0, #0x1                // =1
    1214:      	ret
    1218:      	cmp	w9, #0x15
    121c:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    1220:      	ldr	w9, [x0, #0x1c]
    1224:      	cmp	w8, w9
    1228:      	b.ls	0x1250 <filter_32ty_selector_val+0x350>
    122c:      	mov	w0, #0x1                // =1
    1230:      	ret
    1234:      	cmp	w9, #0x15
    1238:      	b.lo	0x1250 <filter_32ty_selector_val+0x350>
    123c:      	ldr	w9, [x0, #0x1c]
    1240:      	cmp	w8, w9
    1244:      	b.hs	0x1250 <filter_32ty_selector_val+0x350>
    1248:      	mov	w0, #0x1                // =1
    124c:      	ret
    1250:      	mov	x0, xzr
    1254:      	ret
    1258:      	nop
    125c:      	nop

0000000000001260 <filter_32ty_map>:
    1260:      	sub	sp, sp, #0x30
    1264:      	str	x30, [sp, #0x10]
    1268:      	stp	x20, x19, [sp, #0x20]
    126c:      	ldrb	w8, [x0, #0x10]
    1270:      	mov	x19, x0
    1274:      	adrp	x0, 0x1000 <filter_32ty_selector_val+0x100>
    1278:      	add	x9, sp, #0x1c
    127c:      	str	w8, [sp, #0x1c]
    1280:      	mov	w8, #0x1                // =1
    1284:      	mov	x20, x1
    1288:      	add	x1, sp, #0x1c
    128c:      	ldr	x0, [x0]
    1290:      	blr	x8
    1294:      	cbz	x0, 0x1308 <filter_32ty_map+0xa8>
    1298:      	ldr	w8, [x20]
    129c:      	mov	w9, #0x1                // =1
    12a0:      	add	x1, sp, #0x8
    12a4:      	mov	w20, #0x1               // =1
    12a8:      	str	x8, [sp, #0x8]
    12ac:      	add	x8, sp, #0x8
    12b0:      	blr	x9
    12b4:      	ldr	w9, [x19, #0x4]
    12b8:      	mov	w8, wzr
    12bc:      	cmp	w9, #0x1d
    12c0:      	b.hi	0x1304 <filter_32ty_map+0xa4>
    12c4:      	mov	w11, #0x8400            // =33792
    12c8:      	lsl	w10, w20, w9
    12cc:      	movk	w11, #0x3003, lsl #16
    12d0:      	tst	w10, w11
    12d4:      	b.eq	0x12e4 <filter_32ty_map+0x84>
    12d8:      	cmp	x0, #0x0
    12dc:      	cset	w8, ne
    12e0:      	b	0x1304 <filter_32ty_map+0xa4>
    12e4:      	mov	w10, #0x1               // =1
    12e8:      	lsl	w9, w10, w9
    12ec:      	mov	w10, #0x800             // =2048
    12f0:      	movk	w10, #0xc, lsl #16
    12f4:      	tst	w9, w10
    12f8:      	b.eq	0x1304 <filter_32ty_map+0xa4>
    12fc:      	cmp	x0, #0x0
    1300:      	cset	w8, eq
    1304:      	mov	w0, w8
    1308:      	ldp	x20, x19, [sp, #0x20]
    130c:      	ldr	x30, [sp, #0x10]
    1310:      	add	sp, sp, #0x30
    1314:      	ret
    1318:      	nop
    131c:      	nop

0000000000001320 <filter_32ty_range>:
    1320:      	ldr	w9, [x0, #0xc]
    1324:      	ldr	w8, [x0, #0x4]
    1328:      	mov	w10, #0x1               // =1
    132c:      	cmp	w9, #0xc
    1330:      	lsl	w9, w10, w9
    1334:      	mov	w10, #0x1402            // =5122
    1338:      	and	w9, w9, w10
    133c:      	ccmp	w9, #0x0, #0x4, ls
    1340:      	b.eq	0x1440 <filter_32ty_range+0x120>
    1344:      	ldr	w10, [x1]
    1348:      	cmp	w8, #0x1f
    134c:      	b.ne	0x13d4 <filter_32ty_range+0xb4>
    1350:      	ldr	w9, [x0, #0x10]
    1354:      	cmp	w9, w10
    1358:      	b.gt	0x1368 <filter_32ty_range+0x48>
    135c:      	ldr	w9, [x0, #0x14]
    1360:      	cmp	w10, w9
    1364:      	b.le	0x1464 <filter_32ty_range+0x144>
    1368:      	ldr	w9, [x0, #0x8]
    136c:      	cmp	w9, #0x11
    1370:      	b.lo	0x1550 <filter_32ty_range+0x230>
    1374:      	ldr	w11, [x0, #0x18]
    1378:      	cmp	w11, w10
    137c:      	b.gt	0x138c <filter_32ty_range+0x6c>
    1380:      	ldr	w11, [x0, #0x1c]
    1384:      	cmp	w10, w11
    1388:      	b.le	0x1464 <filter_32ty_range+0x144>
    138c:      	cmp	w9, #0x19
    1390:      	b.lo	0x1550 <filter_32ty_range+0x230>
    1394:      	ldr	w11, [x0, #0x20]
    1398:      	cmp	w11, w10
    139c:      	b.gt	0x13ac <filter_32ty_range+0x8c>
    13a0:      	ldr	w11, [x0, #0x24]
    13a4:      	cmp	w10, w11
    13a8:      	b.le	0x1464 <filter_32ty_range+0x144>
    13ac:      	cmp	w9, #0x21
    13b0:      	b.lo	0x1550 <filter_32ty_range+0x230>
    13b4:      	ldr	w11, [x0, #0x28]
    13b8:      	mov	w9, wzr
    13bc:      	cmp	w11, w10
    13c0:      	b.gt	0x1540 <filter_32ty_range+0x220>
    13c4:      	ldr	w11, [x0, #0x2c]
    13c8:      	cmp	w10, w11
    13cc:      	b.le	0x1464 <filter_32ty_range+0x144>
    13d0:      	b	0x1540 <filter_32ty_range+0x220>
    13d4:      	ldp	w9, w12, [x0, #0x10]
    13d8:      	ldr	w11, [x0, #0x8]
    13dc:      	cmp	w9, w10
    13e0:      	ccmp	w10, w12, #0x0, le
    13e4:      	cset	w9, le
    13e8:      	cmp	w11, #0x11
    13ec:      	b.lo	0x1540 <filter_32ty_range+0x220>
    13f0:      	ldp	w12, w13, [x0, #0x18]
    13f4:      	cmp	w12, w10
    13f8:      	ccmp	w10, w13, #0x0, le
    13fc:      	csinc	w9, w9, wzr, gt
    1400:      	cmp	w11, #0x19
    1404:      	b.lo	0x1540 <filter_32ty_range+0x220>
    1408:      	ldp	w12, w13, [x0, #0x20]
    140c:      	cmp	w12, w10
    1410:      	ccmp	w10, w13, #0x0, le
    1414:      	csinc	w9, w9, wzr, gt
    1418:      	cmp	w11, #0x21
    141c:      	b.lo	0x1540 <filter_32ty_range+0x220>
    1420:      	ldp	w11, w12, [x0, #0x28]
    1424:      	cmp	w11, w10
    1428:      	ccmp	w10, w12, #0x0, le
    142c:      	csinc	w9, w9, wzr, gt
    1430:      	cmp	w8, #0x20
    1434:      	eor	w8, w9, #0x1
    1438:      	csel	w0, wzr, w8, ne
    143c:      	ret
    1440:      	ldr	w10, [x1]
    1444:      	cmp	w8, #0x1f
    1448:      	b.ne	0x146c <filter_32ty_range+0x14c>
    144c:      	ldr	w9, [x0, #0x10]
    1450:      	cmp	w9, w10
    1454:      	b.hi	0x14d8 <filter_32ty_range+0x1b8>
    1458:      	ldr	w9, [x0, #0x14]
    145c:      	cmp	w10, w9
    1460:      	b.hi	0x14d8 <filter_32ty_range+0x1b8>
    1464:      	mov	w0, #0x1                // =1
    1468:      	ret
    146c:      	ldp	w9, w12, [x0, #0x10]
    1470:      	ldr	w11, [x0, #0x8]
    1474:      	cmp	w9, w10
    1478:      	ccmp	w10, w12, #0x2, ls
    147c:      	cset	w9, ls
    1480:      	cmp	w11, #0x11
    1484:      	b.lo	0x1540 <filter_32ty_range+0x220>
    1488:      	ldp	w12, w13, [x0, #0x18]
    148c:      	cmp	w12, w10
    1490:      	ccmp	w10, w13, #0x2, ls
    1494:      	csinc	w9, w9, wzr, hi
    1498:      	cmp	w11, #0x19
    149c:      	b.lo	0x1540 <filter_32ty_range+0x220>
    14a0:      	ldp	w12, w13, [x0, #0x20]
    14a4:      	cmp	w12, w10
    14a8:      	ccmp	w10, w13, #0x2, ls
    14ac:      	csinc	w9, w9, wzr, hi
    14b0:      	cmp	w11, #0x21
    14b4:      	b.lo	0x1540 <filter_32ty_range+0x220>
    14b8:      	ldp	w11, w12, [x0, #0x28]
    14bc:      	cmp	w11, w10
    14c0:      	ccmp	w10, w12, #0x2, ls
    14c4:      	csinc	w9, w9, wzr, hi
    14c8:      	cmp	w8, #0x20
    14cc:      	eor	w8, w9, #0x1
    14d0:      	csel	w0, wzr, w8, ne
    14d4:      	ret
    14d8:      	ldr	w9, [x0, #0x8]
    14dc:      	cmp	w9, #0x11
    14e0:      	b.lo	0x1550 <filter_32ty_range+0x230>
    14e4:      	ldr	w11, [x0, #0x18]
    14e8:      	cmp	w11, w10
    14ec:      	b.hi	0x14fc <filter_32ty_range+0x1dc>
    14f0:      	ldr	w11, [x0, #0x1c]
    14f4:      	cmp	w10, w11
    14f8:      	b.ls	0x1464 <filter_32ty_range+0x144>
    14fc:      	cmp	w9, #0x19
    1500:      	b.lo	0x1550 <filter_32ty_range+0x230>
    1504:      	ldr	w11, [x0, #0x20]
    1508:      	cmp	w11, w10
    150c:      	b.hi	0x151c <filter_32ty_range+0x1fc>
    1510:      	ldr	w11, [x0, #0x24]
    1514:      	cmp	w10, w11
    1518:      	b.ls	0x1464 <filter_32ty_range+0x144>
    151c:      	cmp	w9, #0x21
    1520:      	b.lo	0x1550 <filter_32ty_range+0x230>
    1524:      	ldr	w11, [x0, #0x28]
    1528:      	mov	w9, wzr
    152c:      	cmp	w11, w10
    1530:      	b.hi	0x1540 <filter_32ty_range+0x220>
    1534:      	ldr	w11, [x0, #0x2c]
    1538:      	cmp	w10, w11
    153c:      	b.ls	0x1464 <filter_32ty_range+0x144>
    1540:      	cmp	w8, #0x20
    1544:      	eor	w8, w9, #0x1
    1548:      	csel	w0, wzr, w8, ne
    154c:      	ret
    1550:      	mov	w9, wzr
    1554:      	cmp	w8, #0x20
    1558:      	eor	w8, w9, #0x1
    155c:      	csel	w0, wzr, w8, ne
    1560:      	ret
    1564:      	nop
    1568:      	nop
    156c:      	nop

0000000000001570 <filter_16ty_selector_val>:
    1570:      	ldr	w8, [x0, #0x4]
    1574:      	cmp	w8, #0x25
    1578:      	b.hi	0x15ec <filter_16ty_selector_val+0x7c>
    157c:      	mov	x10, #0x40              // =64
    1580:      	mov	w9, #0x1                // =1
    1584:      	movk	x10, #0xc00, lsl #16
    1588:      	lsl	x9, x9, x8
    158c:      	movk	x10, #0x20, lsl #32
    1590:      	tst	x9, x10
    1594:      	b.eq	0x15a0 <filter_16ty_selector_val+0x30>
    1598:      	mov	w0, #0x1                // =1
    159c:      	ret
    15a0:      	mov	w9, #0x1                // =1
    15a4:      	lsl	x9, x9, x8
    15a8:      	tst	x9, #0x18
    15ac:      	b.eq	0x15cc <filter_16ty_selector_val+0x5c>
    15b0:      	ldrh	w9, [x1]
    15b4:      	ldr	w10, [x0, #0x10]
    15b8:      	cmp	w10, w9
    15bc:      	b.ne	0x166c <filter_16ty_selector_val+0xfc>
    15c0:      	cmp	w8, #0x3
    15c4:      	cset	w0, eq
    15c8:      	ret
    15cc:      	cmp	x8, #0xc
    15d0:      	b.ne	0x15ec <filter_16ty_selector_val+0x7c>
    15d4:      	ldrh	w8, [x1]
    15d8:      	ldr	w9, [x0, #0x10]
    15dc:      	tst	w9, w8
    15e0:      	b.eq	0x1718 <filter_16ty_selector_val+0x1a8>
    15e4:      	mov	w0, #0x1                // =1
    15e8:      	ret
    15ec:      	cmp	w8, #0x1
    15f0:      	b.eq	0x1634 <filter_16ty_selector_val+0xc4>
    15f4:      	cmp	w8, #0x2
    15f8:      	b.ne	0x18c0 <filter_16ty_selector_val+0x350>
    15fc:      	ldr	w8, [x0, #0xc]
    1600:      	cmp	w8, #0xc
    1604:      	b.hi	0x1750 <filter_16ty_selector_val+0x1e0>
    1608:      	mov	w9, #0x1                // =1
    160c:      	lsl	w8, w9, w8
    1610:      	mov	w9, #0x1402             // =5122
    1614:      	tst	w8, w9
    1618:      	b.eq	0x1750 <filter_16ty_selector_val+0x1e0>
    161c:      	ldrsh	w8, [x1]
    1620:      	ldr	w9, [x0, #0x10]
    1624:      	cmp	w9, w8
    1628:      	b.le	0x16f8 <filter_16ty_selector_val+0x188>
    162c:      	mov	w0, #0x1                // =1
    1630:      	ret
    1634:      	ldr	w8, [x0, #0xc]
    1638:      	cmp	w8, #0xc
    163c:      	b.hi	0x1738 <filter_16ty_selector_val+0x1c8>
    1640:      	mov	w9, #0x1                // =1
    1644:      	lsl	w8, w9, w8
    1648:      	mov	w9, #0x1402             // =5122
    164c:      	tst	w8, w9
    1650:      	b.eq	0x1738 <filter_16ty_selector_val+0x1c8>
    1654:      	ldrsh	w8, [x1]
    1658:      	ldr	w9, [x0, #0x10]
    165c:      	cmp	w9, w8
    1660:      	b.ge	0x16d8 <filter_16ty_selector_val+0x168>
    1664:      	mov	w0, #0x1                // =1
    1668:      	ret
    166c:      	ldr	w10, [x0, #0x8]
    1670:      	cmp	w10, #0xd
    1674:      	b.lo	0x16ac <filter_16ty_selector_val+0x13c>
    1678:      	ldr	w11, [x0, #0x14]
    167c:      	cmp	w11, w9
    1680:      	b.eq	0x15c0 <filter_16ty_selector_val+0x50>
    1684:      	cmp	w10, #0x11
    1688:      	b.lo	0x16ac <filter_16ty_selector_val+0x13c>
    168c:      	ldr	w11, [x0, #0x18]
    1690:      	cmp	w11, w9
    1694:      	b.eq	0x15c0 <filter_16ty_selector_val+0x50>
    1698:      	cmp	w10, #0x15
    169c:      	b.lo	0x16ac <filter_16ty_selector_val+0x13c>
    16a0:      	ldr	w10, [x0, #0x1c]
    16a4:      	cmp	w10, w9
    16a8:      	b.eq	0x15c0 <filter_16ty_selector_val+0x50>
    16ac:      	cmp	w8, #0x25
    16b0:      	b.hi	0x18c0 <filter_16ty_selector_val+0x350>
    16b4:      	mov	w9, #0x1                // =1
    16b8:      	lsl	x8, x9, x8
    16bc:      	mov	x9, #0x50               // =80
    16c0:      	movk	x9, #0xc00, lsl #16
    16c4:      	movk	x9, #0x20, lsl #32
    16c8:      	tst	x8, x9
    16cc:      	b.eq	0x18c0 <filter_16ty_selector_val+0x350>
    16d0:      	mov	w0, #0x1                // =1
    16d4:      	ret
    16d8:      	ldr	w9, [x0, #0x8]
    16dc:      	cmp	w9, #0xd
    16e0:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    16e4:      	ldr	w10, [x0, #0x14]
    16e8:      	cmp	w10, w8
    16ec:      	b.ge	0x17a8 <filter_16ty_selector_val+0x238>
    16f0:      	mov	w0, #0x1                // =1
    16f4:      	ret
    16f8:      	ldr	w9, [x0, #0x8]
    16fc:      	cmp	w9, #0xd
    1700:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1704:      	ldr	w10, [x0, #0x14]
    1708:      	cmp	w10, w8
    170c:      	b.le	0x17c4 <filter_16ty_selector_val+0x254>
    1710:      	mov	w0, #0x1                // =1
    1714:      	ret
    1718:      	ldr	w9, [x0, #0x8]
    171c:      	cmp	w9, #0xd
    1720:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1724:      	ldr	w10, [x0, #0x14]
    1728:      	tst	w10, w8
    172c:      	b.eq	0x17e0 <filter_16ty_selector_val+0x270>
    1730:      	mov	w0, #0x1                // =1
    1734:      	ret
    1738:      	ldrh	w8, [x1]
    173c:      	ldr	w9, [x0, #0x10]
    1740:      	cmp	w9, w8
    1744:      	b.hs	0x1768 <filter_16ty_selector_val+0x1f8>
    1748:      	mov	w0, #0x1                // =1
    174c:      	ret
    1750:      	ldrh	w8, [x1]
    1754:      	ldr	w9, [x0, #0x10]
    1758:      	cmp	w9, w8
    175c:      	b.ls	0x1788 <filter_16ty_selector_val+0x218>
    1760:      	mov	w0, #0x1                // =1
    1764:      	ret
    1768:      	ldr	w9, [x0, #0x8]
    176c:      	cmp	w9, #0xd
    1770:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1774:      	ldr	w10, [x0, #0x14]
    1778:      	cmp	w10, w8
    177c:      	b.hs	0x17fc <filter_16ty_selector_val+0x28c>
    1780:      	mov	w0, #0x1                // =1
    1784:      	ret
    1788:      	ldr	w9, [x0, #0x8]
    178c:      	cmp	w9, #0xd
    1790:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1794:      	ldr	w10, [x0, #0x14]
    1798:      	cmp	w10, w8
    179c:      	b.ls	0x1818 <filter_16ty_selector_val+0x2a8>
    17a0:      	mov	w0, #0x1                // =1
    17a4:      	ret
    17a8:      	cmp	w9, #0x11
    17ac:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    17b0:      	ldr	w10, [x0, #0x18]
    17b4:      	cmp	w10, w8
    17b8:      	b.ge	0x1834 <filter_16ty_selector_val+0x2c4>
    17bc:      	mov	w0, #0x1                // =1
    17c0:      	ret
    17c4:      	cmp	w9, #0x11
    17c8:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    17cc:      	ldr	w10, [x0, #0x18]
    17d0:      	cmp	w10, w8
    17d4:      	b.le	0x1850 <filter_16ty_selector_val+0x2e0>
    17d8:      	mov	w0, #0x1                // =1
    17dc:      	ret
    17e0:      	cmp	w9, #0x11
    17e4:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    17e8:      	ldr	w10, [x0, #0x18]
    17ec:      	tst	w10, w8
    17f0:      	b.eq	0x186c <filter_16ty_selector_val+0x2fc>
    17f4:      	mov	w0, #0x1                // =1
    17f8:      	ret
    17fc:      	cmp	w9, #0x11
    1800:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1804:      	ldr	w10, [x0, #0x18]
    1808:      	cmp	w10, w8
    180c:      	b.hs	0x1888 <filter_16ty_selector_val+0x318>
    1810:      	mov	w0, #0x1                // =1
    1814:      	ret
    1818:      	cmp	w9, #0x11
    181c:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1820:      	ldr	w10, [x0, #0x18]
    1824:      	cmp	w10, w8
    1828:      	b.ls	0x18a4 <filter_16ty_selector_val+0x334>
    182c:      	mov	w0, #0x1                // =1
    1830:      	ret
    1834:      	cmp	w9, #0x15
    1838:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    183c:      	ldr	w9, [x0, #0x1c]
    1840:      	cmp	w9, w8
    1844:      	b.ge	0x18c0 <filter_16ty_selector_val+0x350>
    1848:      	mov	w0, #0x1                // =1
    184c:      	ret
    1850:      	cmp	w9, #0x15
    1854:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1858:      	ldr	w9, [x0, #0x1c]
    185c:      	cmp	w9, w8
    1860:      	b.le	0x18c0 <filter_16ty_selector_val+0x350>
    1864:      	mov	w0, #0x1                // =1
    1868:      	ret
    186c:      	cmp	w9, #0x15
    1870:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1874:      	ldr	w9, [x0, #0x1c]
    1878:      	tst	w9, w8
    187c:      	b.eq	0x18c0 <filter_16ty_selector_val+0x350>
    1880:      	mov	w0, #0x1                // =1
    1884:      	ret
    1888:      	cmp	w9, #0x15
    188c:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    1890:      	ldr	w9, [x0, #0x1c]
    1894:      	cmp	w9, w8
    1898:      	b.hs	0x18c0 <filter_16ty_selector_val+0x350>
    189c:      	mov	w0, #0x1                // =1
    18a0:      	ret
    18a4:      	cmp	w9, #0x15
    18a8:      	b.lo	0x18c0 <filter_16ty_selector_val+0x350>
    18ac:      	ldr	w9, [x0, #0x1c]
    18b0:      	cmp	w9, w8
    18b4:      	b.ls	0x18c0 <filter_16ty_selector_val+0x350>
    18b8:      	mov	w0, #0x1                // =1
    18bc:      	ret
    18c0:      	mov	x0, xzr
    18c4:      	ret
    18c8:      	nop
    18cc:      	nop

00000000000018d0 <filter_16ty_map>:
    18d0:      	sub	sp, sp, #0x30
    18d4:      	str	x30, [sp, #0x10]
    18d8:      	stp	x20, x19, [sp, #0x20]
    18dc:      	ldrb	w8, [x0, #0x10]
    18e0:      	mov	x19, x0
    18e4:      	adrp	x0, 0x1000 <filter_32ty_selector_val+0x100>
    18e8:      	add	x9, sp, #0x1c
    18ec:      	str	w8, [sp, #0x1c]
    18f0:      	mov	w8, #0x1                // =1
    18f4:      	mov	x20, x1
    18f8:      	add	x1, sp, #0x1c
    18fc:      	ldr	x0, [x0]
    1900:      	blr	x8
    1904:      	cbz	x0, 0x1978 <filter_16ty_map+0xa8>
    1908:      	ldrh	w8, [x20]
    190c:      	mov	w9, #0x1                // =1
    1910:      	add	x1, sp, #0x8
    1914:      	mov	w20, #0x1               // =1
    1918:      	str	x8, [sp, #0x8]
    191c:      	add	x8, sp, #0x8
    1920:      	blr	x9
    1924:      	ldr	w9, [x19, #0x4]
    1928:      	mov	w8, wzr
    192c:      	cmp	w9, #0x1d
    1930:      	b.hi	0x1974 <filter_16ty_map+0xa4>
    1934:      	mov	w11, #0x8400            // =33792
    1938:      	lsl	w10, w20, w9
    193c:      	movk	w11, #0x3003, lsl #16
    1940:      	tst	w10, w11
    1944:      	b.eq	0x1954 <filter_16ty_map+0x84>
    1948:      	cmp	x0, #0x0
    194c:      	cset	w8, ne
    1950:      	b	0x1974 <filter_16ty_map+0xa4>
    1954:      	mov	w10, #0x1               // =1
    1958:      	lsl	w9, w10, w9
    195c:      	mov	w10, #0x800             // =2048
    1960:      	movk	w10, #0xc, lsl #16
    1964:      	tst	w9, w10
    1968:      	b.eq	0x1974 <filter_16ty_map+0xa4>
    196c:      	cmp	x0, #0x0
    1970:      	cset	w8, eq
    1974:      	mov	w0, w8
    1978:      	ldp	x20, x19, [sp, #0x20]
    197c:      	ldr	x30, [sp, #0x10]
    1980:      	add	sp, sp, #0x30
    1984:      	ret
    1988:      	nop
    198c:      	nop

0000000000001990 <filter_16ty_range>:
    1990:      	ldr	w9, [x0, #0xc]
    1994:      	ldr	w8, [x0, #0x4]
    1998:      	mov	w10, #0x1               // =1
    199c:      	cmp	w9, #0xc
    19a0:      	lsl	w9, w10, w9
    19a4:      	mov	w10, #0x1402            // =5122
    19a8:      	and	w9, w9, w10
    19ac:      	ccmp	w9, #0x0, #0x4, ls
    19b0:      	b.eq	0x1ab0 <filter_16ty_range+0x120>
    19b4:      	ldrsh	w10, [x1]
    19b8:      	cmp	w8, #0x1f
    19bc:      	b.ne	0x1a44 <filter_16ty_range+0xb4>
    19c0:      	ldr	w9, [x0, #0x10]
    19c4:      	cmp	w9, w10
    19c8:      	b.gt	0x19d8 <filter_16ty_range+0x48>
    19cc:      	ldr	w9, [x0, #0x14]
    19d0:      	cmp	w9, w10
    19d4:      	b.ge	0x1ad4 <filter_16ty_range+0x144>
    19d8:      	ldr	w9, [x0, #0x8]
    19dc:      	cmp	w9, #0x11
    19e0:      	b.lo	0x1bc0 <filter_16ty_range+0x230>
    19e4:      	ldr	w11, [x0, #0x18]
    19e8:      	cmp	w11, w10
    19ec:      	b.gt	0x19fc <filter_16ty_range+0x6c>
    19f0:      	ldr	w11, [x0, #0x1c]
    19f4:      	cmp	w11, w10
    19f8:      	b.ge	0x1ad4 <filter_16ty_range+0x144>
    19fc:      	cmp	w9, #0x19
    1a00:      	b.lo	0x1bc0 <filter_16ty_range+0x230>
    1a04:      	ldr	w11, [x0, #0x20]
    1a08:      	cmp	w11, w10
    1a0c:      	b.gt	0x1a1c <filter_16ty_range+0x8c>
    1a10:      	ldr	w11, [x0, #0x24]
    1a14:      	cmp	w11, w10
    1a18:      	b.ge	0x1ad4 <filter_16ty_range+0x144>
    1a1c:      	cmp	w9, #0x21
    1a20:      	b.lo	0x1bc0 <filter_16ty_range+0x230>
    1a24:      	ldr	w11, [x0, #0x28]
    1a28:      	mov	w9, wzr
    1a2c:      	cmp	w11, w10
    1a30:      	b.gt	0x1bb0 <filter_16ty_range+0x220>
    1a34:      	ldr	w11, [x0, #0x2c]
    1a38:      	cmp	w11, w10
    1a3c:      	b.ge	0x1ad4 <filter_16ty_range+0x144>
    1a40:      	b	0x1bb0 <filter_16ty_range+0x220>
    1a44:      	ldp	w9, w12, [x0, #0x10]
    1a48:      	ldr	w11, [x0, #0x8]
    1a4c:      	cmp	w9, w10
    1a50:      	ccmp	w12, w10, #0x8, le
    1a54:      	cset	w9, ge
    1a58:      	cmp	w11, #0x11
    1a5c:      	b.lo	0x1bb0 <filter_16ty_range+0x220>
    1a60:      	ldp	w12, w13, [x0, #0x18]
    1a64:      	cmp	w12, w10
    1a68:      	ccmp	w13, w10, #0x8, le
    1a6c:      	csinc	w9, w9, wzr, lt
    1a70:      	cmp	w11, #0x19
    1a74:      	b.lo	0x1bb0 <filter_16ty_range+0x220>
    1a78:      	ldp	w12, w13, [x0, #0x20]
    1a7c:      	cmp	w12, w10
    1a80:      	ccmp	w13, w10, #0x8, le
    1a84:      	csinc	w9, w9, wzr, lt
    1a88:      	cmp	w11, #0x21
    1a8c:      	b.lo	0x1bb0 <filter_16ty_range+0x220>
    1a90:      	ldp	w11, w12, [x0, #0x28]
    1a94:      	cmp	w11, w10
    1a98:      	ccmp	w12, w10, #0x8, le
    1a9c:      	csinc	w9, w9, wzr, lt
    1aa0:      	cmp	w8, #0x20
    1aa4:      	eor	w8, w9, #0x1
    1aa8:      	csel	w0, wzr, w8, ne
    1aac:      	ret
    1ab0:      	ldrh	w10, [x1]
    1ab4:      	cmp	w8, #0x1f
    1ab8:      	b.ne	0x1adc <filter_16ty_range+0x14c>
    1abc:      	ldr	w9, [x0, #0x10]
    1ac0:      	cmp	w9, w10
    1ac4:      	b.hi	0x1b48 <filter_16ty_range+0x1b8>
    1ac8:      	ldr	w9, [x0, #0x14]
    1acc:      	cmp	w9, w10
    1ad0:      	b.lo	0x1b48 <filter_16ty_range+0x1b8>
    1ad4:      	mov	w0, #0x1                // =1
    1ad8:      	ret
    1adc:      	ldp	w9, w12, [x0, #0x10]
    1ae0:      	ldr	w11, [x0, #0x8]
    1ae4:      	cmp	w9, w10
    1ae8:      	ccmp	w12, w10, #0x0, ls
    1aec:      	cset	w9, hs
    1af0:      	cmp	w11, #0x11
    1af4:      	b.lo	0x1bb0 <filter_16ty_range+0x220>
    1af8:      	ldp	w12, w13, [x0, #0x18]
    1afc:      	cmp	w12, w10
    1b00:      	ccmp	w13, w10, #0x0, ls
    1b04:      	csinc	w9, w9, wzr, lo
    1b08:      	cmp	w11, #0x19
    1b0c:      	b.lo	0x1bb0 <filter_16ty_range+0x220>
    1b10:      	ldp	w12, w13, [x0, #0x20]
    1b14:      	cmp	w12, w10
    1b18:      	ccmp	w13, w10, #0x0, ls
    1b1c:      	csinc	w9, w9, wzr, lo
    1b20:      	cmp	w11, #0x21
    1b24:      	b.lo	0x1bb0 <filter_16ty_range+0x220>
    1b28:      	ldp	w11, w12, [x0, #0x28]
    1b2c:      	cmp	w11, w10
    1b30:      	ccmp	w12, w10, #0x0, ls
    1b34:      	csinc	w9, w9, wzr, lo
    1b38:      	cmp	w8, #0x20
    1b3c:      	eor	w8, w9, #0x1
    1b40:      	csel	w0, wzr, w8, ne
    1b44:      	ret
    1b48:      	ldr	w9, [x0, #0x8]
    1b4c:      	cmp	w9, #0x11
    1b50:      	b.lo	0x1bc0 <filter_16ty_range+0x230>
    1b54:      	ldr	w11, [x0, #0x18]
    1b58:      	cmp	w11, w10
    1b5c:      	b.hi	0x1b6c <filter_16ty_range+0x1dc>
    1b60:      	ldr	w11, [x0, #0x1c]
    1b64:      	cmp	w11, w10
    1b68:      	b.hs	0x1ad4 <filter_16ty_range+0x144>
    1b6c:      	cmp	w9, #0x19
    1b70:      	b.lo	0x1bc0 <filter_16ty_range+0x230>
    1b74:      	ldr	w11, [x0, #0x20]
    1b78:      	cmp	w11, w10
    1b7c:      	b.hi	0x1b8c <filter_16ty_range+0x1fc>
    1b80:      	ldr	w11, [x0, #0x24]
    1b84:      	cmp	w11, w10
    1b88:      	b.hs	0x1ad4 <filter_16ty_range+0x144>
    1b8c:      	cmp	w9, #0x21
    1b90:      	b.lo	0x1bc0 <filter_16ty_range+0x230>
    1b94:      	ldr	w11, [x0, #0x28]
    1b98:      	mov	w9, wzr
    1b9c:      	cmp	w11, w10
    1ba0:      	b.hi	0x1bb0 <filter_16ty_range+0x220>
    1ba4:      	ldr	w11, [x0, #0x2c]
    1ba8:      	cmp	w11, w10
    1bac:      	b.hs	0x1ad4 <filter_16ty_range+0x144>
    1bb0:      	cmp	w8, #0x20
    1bb4:      	eor	w8, w9, #0x1
    1bb8:      	csel	w0, wzr, w8, ne
    1bbc:      	ret
    1bc0:      	mov	w9, wzr
    1bc4:      	cmp	w8, #0x20
    1bc8:      	eor	w8, w9, #0x1
    1bcc:      	csel	w0, wzr, w8, ne
    1bd0:      	ret
    1bd4:      	nop
    1bd8:      	nop
    1bdc:      	nop

0000000000001be0 <filter_8ty_selector_val>:
    1be0:      	ldr	w8, [x0, #0x4]
    1be4:      	cmp	w8, #0x25
    1be8:      	b.hi	0x1c5c <filter_8ty_selector_val+0x7c>
    1bec:      	mov	x10, #0x40              // =64
    1bf0:      	mov	w9, #0x1                // =1
    1bf4:      	movk	x10, #0xc00, lsl #16
    1bf8:      	lsl	x9, x9, x8
    1bfc:      	movk	x10, #0x20, lsl #32
    1c00:      	tst	x9, x10
    1c04:      	b.eq	0x1c10 <filter_8ty_selector_val+0x30>
    1c08:      	mov	w0, #0x1                // =1
    1c0c:      	ret
    1c10:      	mov	w9, #0x1                // =1
    1c14:      	lsl	x9, x9, x8
    1c18:      	tst	x9, #0x18
    1c1c:      	b.eq	0x1c3c <filter_8ty_selector_val+0x5c>
    1c20:      	ldrb	w9, [x1]
    1c24:      	ldr	w10, [x0, #0x10]
    1c28:      	cmp	w10, w9
    1c2c:      	b.ne	0x1cdc <filter_8ty_selector_val+0xfc>
    1c30:      	cmp	w8, #0x3
    1c34:      	cset	w0, eq
    1c38:      	ret
    1c3c:      	cmp	x8, #0xc
    1c40:      	b.ne	0x1c5c <filter_8ty_selector_val+0x7c>
    1c44:      	ldrb	w8, [x1]
    1c48:      	ldr	w9, [x0, #0x10]
    1c4c:      	tst	w9, w8
    1c50:      	b.eq	0x1d88 <filter_8ty_selector_val+0x1a8>
    1c54:      	mov	w0, #0x1                // =1
    1c58:      	ret
    1c5c:      	cmp	w8, #0x1
    1c60:      	b.eq	0x1ca4 <filter_8ty_selector_val+0xc4>
    1c64:      	cmp	w8, #0x2
    1c68:      	b.ne	0x1f30 <filter_8ty_selector_val+0x350>
    1c6c:      	ldr	w8, [x0, #0xc]
    1c70:      	cmp	w8, #0xc
    1c74:      	b.hi	0x1dc0 <filter_8ty_selector_val+0x1e0>
    1c78:      	mov	w9, #0x1                // =1
    1c7c:      	lsl	w8, w9, w8
    1c80:      	mov	w9, #0x1402             // =5122
    1c84:      	tst	w8, w9
    1c88:      	b.eq	0x1dc0 <filter_8ty_selector_val+0x1e0>
    1c8c:      	ldrsb	w8, [x1]
    1c90:      	ldr	w9, [x0, #0x10]
    1c94:      	cmp	w9, w8
    1c98:      	b.le	0x1d68 <filter_8ty_selector_val+0x188>
    1c9c:      	mov	w0, #0x1                // =1
    1ca0:      	ret
    1ca4:      	ldr	w8, [x0, #0xc]
    1ca8:      	cmp	w8, #0xc
    1cac:      	b.hi	0x1da8 <filter_8ty_selector_val+0x1c8>
    1cb0:      	mov	w9, #0x1                // =1
    1cb4:      	lsl	w8, w9, w8
    1cb8:      	mov	w9, #0x1402             // =5122
    1cbc:      	tst	w8, w9
    1cc0:      	b.eq	0x1da8 <filter_8ty_selector_val+0x1c8>
    1cc4:      	ldrsb	w8, [x1]
    1cc8:      	ldr	w9, [x0, #0x10]
    1ccc:      	cmp	w9, w8
    1cd0:      	b.ge	0x1d48 <filter_8ty_selector_val+0x168>
    1cd4:      	mov	w0, #0x1                // =1
    1cd8:      	ret
    1cdc:      	ldr	w10, [x0, #0x8]
    1ce0:      	cmp	w10, #0xd
    1ce4:      	b.lo	0x1d1c <filter_8ty_selector_val+0x13c>
    1ce8:      	ldr	w11, [x0, #0x14]
    1cec:      	cmp	w11, w9
    1cf0:      	b.eq	0x1c30 <filter_8ty_selector_val+0x50>
    1cf4:      	cmp	w10, #0x11
    1cf8:      	b.lo	0x1d1c <filter_8ty_selector_val+0x13c>
    1cfc:      	ldr	w11, [x0, #0x18]
    1d00:      	cmp	w11, w9
    1d04:      	b.eq	0x1c30 <filter_8ty_selector_val+0x50>
    1d08:      	cmp	w10, #0x15
    1d0c:      	b.lo	0x1d1c <filter_8ty_selector_val+0x13c>
    1d10:      	ldr	w10, [x0, #0x1c]
    1d14:      	cmp	w10, w9
    1d18:      	b.eq	0x1c30 <filter_8ty_selector_val+0x50>
    1d1c:      	cmp	w8, #0x25
    1d20:      	b.hi	0x1f30 <filter_8ty_selector_val+0x350>
    1d24:      	mov	w9, #0x1                // =1
    1d28:      	lsl	x8, x9, x8
    1d2c:      	mov	x9, #0x50               // =80
    1d30:      	movk	x9, #0xc00, lsl #16
    1d34:      	movk	x9, #0x20, lsl #32
    1d38:      	tst	x8, x9
    1d3c:      	b.eq	0x1f30 <filter_8ty_selector_val+0x350>
    1d40:      	mov	w0, #0x1                // =1
    1d44:      	ret
    1d48:      	ldr	w9, [x0, #0x8]
    1d4c:      	cmp	w9, #0xd
    1d50:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1d54:      	ldr	w10, [x0, #0x14]
    1d58:      	cmp	w10, w8
    1d5c:      	b.ge	0x1e18 <filter_8ty_selector_val+0x238>
    1d60:      	mov	w0, #0x1                // =1
    1d64:      	ret
    1d68:      	ldr	w9, [x0, #0x8]
    1d6c:      	cmp	w9, #0xd
    1d70:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1d74:      	ldr	w10, [x0, #0x14]
    1d78:      	cmp	w10, w8
    1d7c:      	b.le	0x1e34 <filter_8ty_selector_val+0x254>
    1d80:      	mov	w0, #0x1                // =1
    1d84:      	ret
    1d88:      	ldr	w9, [x0, #0x8]
    1d8c:      	cmp	w9, #0xd
    1d90:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1d94:      	ldr	w10, [x0, #0x14]
    1d98:      	tst	w10, w8
    1d9c:      	b.eq	0x1e50 <filter_8ty_selector_val+0x270>
    1da0:      	mov	w0, #0x1                // =1
    1da4:      	ret
    1da8:      	ldrb	w8, [x1]
    1dac:      	ldr	w9, [x0, #0x10]
    1db0:      	cmp	w9, w8
    1db4:      	b.hs	0x1dd8 <filter_8ty_selector_val+0x1f8>
    1db8:      	mov	w0, #0x1                // =1
    1dbc:      	ret
    1dc0:      	ldrb	w8, [x1]
    1dc4:      	ldr	w9, [x0, #0x10]
    1dc8:      	cmp	w9, w8
    1dcc:      	b.ls	0x1df8 <filter_8ty_selector_val+0x218>
    1dd0:      	mov	w0, #0x1                // =1
    1dd4:      	ret
    1dd8:      	ldr	w9, [x0, #0x8]
    1ddc:      	cmp	w9, #0xd
    1de0:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1de4:      	ldr	w10, [x0, #0x14]
    1de8:      	cmp	w10, w8
    1dec:      	b.hs	0x1e6c <filter_8ty_selector_val+0x28c>
    1df0:      	mov	w0, #0x1                // =1
    1df4:      	ret
    1df8:      	ldr	w9, [x0, #0x8]
    1dfc:      	cmp	w9, #0xd
    1e00:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1e04:      	ldr	w10, [x0, #0x14]
    1e08:      	cmp	w10, w8
    1e0c:      	b.ls	0x1e88 <filter_8ty_selector_val+0x2a8>
    1e10:      	mov	w0, #0x1                // =1
    1e14:      	ret
    1e18:      	cmp	w9, #0x11
    1e1c:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1e20:      	ldr	w10, [x0, #0x18]
    1e24:      	cmp	w10, w8
    1e28:      	b.ge	0x1ea4 <filter_8ty_selector_val+0x2c4>
    1e2c:      	mov	w0, #0x1                // =1
    1e30:      	ret
    1e34:      	cmp	w9, #0x11
    1e38:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1e3c:      	ldr	w10, [x0, #0x18]
    1e40:      	cmp	w10, w8
    1e44:      	b.le	0x1ec0 <filter_8ty_selector_val+0x2e0>
    1e48:      	mov	w0, #0x1                // =1
    1e4c:      	ret
    1e50:      	cmp	w9, #0x11
    1e54:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1e58:      	ldr	w10, [x0, #0x18]
    1e5c:      	tst	w10, w8
    1e60:      	b.eq	0x1edc <filter_8ty_selector_val+0x2fc>
    1e64:      	mov	w0, #0x1                // =1
    1e68:      	ret
    1e6c:      	cmp	w9, #0x11
    1e70:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1e74:      	ldr	w10, [x0, #0x18]
    1e78:      	cmp	w10, w8
    1e7c:      	b.hs	0x1ef8 <filter_8ty_selector_val+0x318>
    1e80:      	mov	w0, #0x1                // =1
    1e84:      	ret
    1e88:      	cmp	w9, #0x11
    1e8c:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1e90:      	ldr	w10, [x0, #0x18]
    1e94:      	cmp	w10, w8
    1e98:      	b.ls	0x1f14 <filter_8ty_selector_val+0x334>
    1e9c:      	mov	w0, #0x1                // =1
    1ea0:      	ret
    1ea4:      	cmp	w9, #0x15
    1ea8:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1eac:      	ldr	w9, [x0, #0x1c]
    1eb0:      	cmp	w9, w8
    1eb4:      	b.ge	0x1f30 <filter_8ty_selector_val+0x350>
    1eb8:      	mov	w0, #0x1                // =1
    1ebc:      	ret
    1ec0:      	cmp	w9, #0x15
    1ec4:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1ec8:      	ldr	w9, [x0, #0x1c]
    1ecc:      	cmp	w9, w8
    1ed0:      	b.le	0x1f30 <filter_8ty_selector_val+0x350>
    1ed4:      	mov	w0, #0x1                // =1
    1ed8:      	ret
    1edc:      	cmp	w9, #0x15
    1ee0:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1ee4:      	ldr	w9, [x0, #0x1c]
    1ee8:      	tst	w9, w8
    1eec:      	b.eq	0x1f30 <filter_8ty_selector_val+0x350>
    1ef0:      	mov	w0, #0x1                // =1
    1ef4:      	ret
    1ef8:      	cmp	w9, #0x15
    1efc:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1f00:      	ldr	w9, [x0, #0x1c]
    1f04:      	cmp	w9, w8
    1f08:      	b.hs	0x1f30 <filter_8ty_selector_val+0x350>
    1f0c:      	mov	w0, #0x1                // =1
    1f10:      	ret
    1f14:      	cmp	w9, #0x15
    1f18:      	b.lo	0x1f30 <filter_8ty_selector_val+0x350>
    1f1c:      	ldr	w9, [x0, #0x1c]
    1f20:      	cmp	w9, w8
    1f24:      	b.ls	0x1f30 <filter_8ty_selector_val+0x350>
    1f28:      	mov	w0, #0x1                // =1
    1f2c:      	ret
    1f30:      	mov	x0, xzr
    1f34:      	ret
    1f38:      	nop
    1f3c:      	nop

0000000000001f40 <filter_8ty_map>:
    1f40:      	sub	sp, sp, #0x30
    1f44:      	str	x30, [sp, #0x10]
    1f48:      	stp	x20, x19, [sp, #0x20]
    1f4c:      	ldrb	w8, [x0, #0x10]
    1f50:      	mov	x19, x0
    1f54:      	adrp	x0, 0x1000 <filter_32ty_selector_val+0x100>
    1f58:      	add	x9, sp, #0x1c
    1f5c:      	str	w8, [sp, #0x1c]
    1f60:      	mov	w8, #0x1                // =1
    1f64:      	mov	x20, x1
    1f68:      	add	x1, sp, #0x1c
    1f6c:      	ldr	x0, [x0]
    1f70:      	blr	x8
    1f74:      	cbz	x0, 0x1fe8 <filter_8ty_map+0xa8>
    1f78:      	ldrb	w8, [x20]
    1f7c:      	mov	w9, #0x1                // =1
    1f80:      	add	x1, sp, #0x8
    1f84:      	mov	w20, #0x1               // =1
    1f88:      	str	x8, [sp, #0x8]
    1f8c:      	add	x8, sp, #0x8
    1f90:      	blr	x9
    1f94:      	ldr	w9, [x19, #0x4]
    1f98:      	mov	w8, wzr
    1f9c:      	cmp	w9, #0x1d
    1fa0:      	b.hi	0x1fe4 <filter_8ty_map+0xa4>
    1fa4:      	mov	w11, #0x8400            // =33792
    1fa8:      	lsl	w10, w20, w9
    1fac:      	movk	w11, #0x3003, lsl #16
    1fb0:      	tst	w10, w11
    1fb4:      	b.eq	0x1fc4 <filter_8ty_map+0x84>
    1fb8:      	cmp	x0, #0x0
    1fbc:      	cset	w8, ne
    1fc0:      	b	0x1fe4 <filter_8ty_map+0xa4>
    1fc4:      	mov	w10, #0x1               // =1
    1fc8:      	lsl	w9, w10, w9
    1fcc:      	mov	w10, #0x800             // =2048
    1fd0:      	movk	w10, #0xc, lsl #16
    1fd4:      	tst	w9, w10
    1fd8:      	b.eq	0x1fe4 <filter_8ty_map+0xa4>
    1fdc:      	cmp	x0, #0x0
    1fe0:      	cset	w8, eq
    1fe4:      	mov	w0, w8
    1fe8:      	ldp	x20, x19, [sp, #0x20]
    1fec:      	ldr	x30, [sp, #0x10]
    1ff0:      	add	sp, sp, #0x30
    1ff4:      	ret
    1ff8:      	nop
    1ffc:      	nop

0000000000002000 <filter_8ty_range>:
    2000:      	ldr	w9, [x0, #0xc]
    2004:      	ldr	w8, [x0, #0x4]
    2008:      	mov	w10, #0x1               // =1
    200c:      	cmp	w9, #0xc
    2010:      	lsl	w9, w10, w9
    2014:      	mov	w10, #0x1402            // =5122
    2018:      	and	w9, w9, w10
    201c:      	ccmp	w9, #0x0, #0x4, ls
    2020:      	b.eq	0x2120 <filter_8ty_range+0x120>
    2024:      	ldrsb	w10, [x1]
    2028:      	cmp	w8, #0x1f
    202c:      	b.ne	0x20b4 <filter_8ty_range+0xb4>
    2030:      	ldr	w9, [x0, #0x10]
    2034:      	cmp	w9, w10
    2038:      	b.gt	0x2048 <filter_8ty_range+0x48>
    203c:      	ldr	w9, [x0, #0x14]
    2040:      	cmp	w9, w10
    2044:      	b.ge	0x2144 <filter_8ty_range+0x144>
    2048:      	ldr	w9, [x0, #0x8]
    204c:      	cmp	w9, #0x11
    2050:      	b.lo	0x2230 <filter_8ty_range+0x230>
    2054:      	ldr	w11, [x0, #0x18]
    2058:      	cmp	w11, w10
    205c:      	b.gt	0x206c <filter_8ty_range+0x6c>
    2060:      	ldr	w11, [x0, #0x1c]
    2064:      	cmp	w11, w10
    2068:      	b.ge	0x2144 <filter_8ty_range+0x144>
    206c:      	cmp	w9, #0x19
    2070:      	b.lo	0x2230 <filter_8ty_range+0x230>
    2074:      	ldr	w11, [x0, #0x20]
    2078:      	cmp	w11, w10
    207c:      	b.gt	0x208c <filter_8ty_range+0x8c>
    2080:      	ldr	w11, [x0, #0x24]
    2084:      	cmp	w11, w10
    2088:      	b.ge	0x2144 <filter_8ty_range+0x144>
    208c:      	cmp	w9, #0x21
    2090:      	b.lo	0x2230 <filter_8ty_range+0x230>
    2094:      	ldr	w11, [x0, #0x28]
    2098:      	mov	w9, wzr
    209c:      	cmp	w11, w10
    20a0:      	b.gt	0x2220 <filter_8ty_range+0x220>
    20a4:      	ldr	w11, [x0, #0x2c]
    20a8:      	cmp	w11, w10
    20ac:      	b.ge	0x2144 <filter_8ty_range+0x144>
    20b0:      	b	0x2220 <filter_8ty_range+0x220>
    20b4:      	ldp	w9, w12, [x0, #0x10]
    20b8:      	ldr	w11, [x0, #0x8]
    20bc:      	cmp	w9, w10
    20c0:      	ccmp	w12, w10, #0x8, le
    20c4:      	cset	w9, ge
    20c8:      	cmp	w11, #0x11
    20cc:      	b.lo	0x2220 <filter_8ty_range+0x220>
    20d0:      	ldp	w12, w13, [x0, #0x18]
    20d4:      	cmp	w12, w10
    20d8:      	ccmp	w13, w10, #0x8, le
    20dc:      	csinc	w9, w9, wzr, lt
    20e0:      	cmp	w11, #0x19
    20e4:      	b.lo	0x2220 <filter_8ty_range+0x220>
    20e8:      	ldp	w12, w13, [x0, #0x20]
    20ec:      	cmp	w12, w10
    20f0:      	ccmp	w13, w10, #0x8, le
    20f4:      	csinc	w9, w9, wzr, lt
    20f8:      	cmp	w11, #0x21
    20fc:      	b.lo	0x2220 <filter_8ty_range+0x220>
    2100:      	ldp	w11, w12, [x0, #0x28]
    2104:      	cmp	w11, w10
    2108:      	ccmp	w12, w10, #0x8, le
    210c:      	csinc	w9, w9, wzr, lt
    2110:      	cmp	w8, #0x20
    2114:      	eor	w8, w9, #0x1
    2118:      	csel	w0, wzr, w8, ne
    211c:      	ret
    2120:      	ldrb	w10, [x1]
    2124:      	cmp	w8, #0x1f
    2128:      	b.ne	0x214c <filter_8ty_range+0x14c>
    212c:      	ldr	w9, [x0, #0x10]
    2130:      	cmp	w9, w10
    2134:      	b.hi	0x21b8 <filter_8ty_range+0x1b8>
    2138:      	ldr	w9, [x0, #0x14]
    213c:      	cmp	w9, w10
    2140:      	b.lo	0x21b8 <filter_8ty_range+0x1b8>
    2144:      	mov	w0, #0x1                // =1
    2148:      	ret
    214c:      	ldp	w9, w12, [x0, #0x10]
    2150:      	ldr	w11, [x0, #0x8]
    2154:      	cmp	w9, w10
    2158:      	ccmp	w12, w10, #0x0, ls
    215c:      	cset	w9, hs
    2160:      	cmp	w11, #0x11
    2164:      	b.lo	0x2220 <filter_8ty_range+0x220>
    2168:      	ldp	w12, w13, [x0, #0x18]
    216c:      	cmp	w12, w10
    2170:      	ccmp	w13, w10, #0x0, ls
    2174:      	csinc	w9, w9, wzr, lo
    2178:      	cmp	w11, #0x19
    217c:      	b.lo	0x2220 <filter_8ty_range+0x220>
    2180:      	ldp	w12, w13, [x0, #0x20]
    2184:      	cmp	w12, w10
    2188:      	ccmp	w13, w10, #0x0, ls
    218c:      	csinc	w9, w9, wzr, lo
    2190:      	cmp	w11, #0x21
    2194:      	b.lo	0x2220 <filter_8ty_range+0x220>
    2198:      	ldp	w11, w12, [x0, #0x28]
    219c:      	cmp	w11, w10
    21a0:      	ccmp	w12, w10, #0x0, ls
    21a4:      	csinc	w9, w9, wzr, lo
    21a8:      	cmp	w8, #0x20
    21ac:      	eor	w8, w9, #0x1
    21b0:      	csel	w0, wzr, w8, ne
    21b4:      	ret
    21b8:      	ldr	w9, [x0, #0x8]
    21bc:      	cmp	w9, #0x11
    21c0:      	b.lo	0x2230 <filter_8ty_range+0x230>
    21c4:      	ldr	w11, [x0, #0x18]
    21c8:      	cmp	w11, w10
    21cc:      	b.hi	0x21dc <filter_8ty_range+0x1dc>
    21d0:      	ldr	w11, [x0, #0x1c]
    21d4:      	cmp	w11, w10
    21d8:      	b.hs	0x2144 <filter_8ty_range+0x144>
    21dc:      	cmp	w9, #0x19
    21e0:      	b.lo	0x2230 <filter_8ty_range+0x230>
    21e4:      	ldr	w11, [x0, #0x20]
    21e8:      	cmp	w11, w10
    21ec:      	b.hi	0x21fc <filter_8ty_range+0x1fc>
    21f0:      	ldr	w11, [x0, #0x24]
    21f4:      	cmp	w11, w10
    21f8:      	b.hs	0x2144 <filter_8ty_range+0x144>
    21fc:      	cmp	w9, #0x21
    2200:      	b.lo	0x2230 <filter_8ty_range+0x230>
    2204:      	ldr	w11, [x0, #0x28]
    2208:      	mov	w9, wzr
    220c:      	cmp	w11, w10
    2210:      	b.hi	0x2220 <filter_8ty_range+0x220>
    2214:      	ldr	w11, [x0, #0x2c]
    2218:      	cmp	w11, w10
    221c:      	b.hs	0x2144 <filter_8ty_range+0x144>
    2220:      	cmp	w8, #0x20
    2224:      	eor	w8, w9, #0x1
    2228:      	csel	w0, wzr, w8, ne
    222c:      	ret
    2230:      	mov	w9, wzr
    2234:      	cmp	w8, #0x20
    2238:      	eor	w8, w9, #0x1
    223c:      	csel	w0, wzr, w8, ne
    2240:      	ret
    2244:      	nop
    2248:      	nop
    224c:      	nop

0000000000002250 <filter_file_buf>:
    2250:      	stp	x30, x19, [sp, #-0x10]!
    2254:      	ldr	w2, [x1]
    2258:      	ldr	w8, [x0, #0x4]
    225c:      	mov	x19, x0
    2260:      	cbnz	w2, 0x227c <filter_file_buf+0x2c>
    2264:      	and	w9, w8, #0xfffffffe
    2268:      	cmp	w9, #0x24
    226c:      	b.eq	0x227c <filter_file_buf+0x2c>
    2270:      	mov	x0, xzr
    2274:      	ldp	x30, x19, [sp], #0x10
    2278:      	ret
    227c:      	cmp	w8, #0x25
    2280:      	b.hi	0x22dc <filter_file_buf+0x8c>
    2284:      	mov	w9, #0x1                // =1
    2288:      	mov	w10, #0x100             // =256
    228c:      	lsl	x9, x9, x8
    2290:      	movk	w10, #0x400, lsl #16
    2294:      	tst	x9, x10
    2298:      	b.ne	0x2320 <filter_file_buf+0xd0>
    229c:      	mov	w9, #0x1                // =1
    22a0:      	mov	w10, #0x200             // =512
    22a4:      	lsl	x9, x9, x8
    22a8:      	movk	w10, #0x800, lsl #16
    22ac:      	tst	x9, x10
    22b0:      	b.ne	0x2304 <filter_file_buf+0xb4>
    22b4:      	mov	w9, #0x1                // =1
    22b8:      	lsl	x9, x9, x8
    22bc:      	tst	x9, #0x3000000000
    22c0:      	b.eq	0x22dc <filter_file_buf+0x8c>
    22c4:      	mov	x0, x19
    22c8:      	bl	0x2f30 <filter_file_type>
    22cc:      	ldr	w8, [x19, #0x4]
    22d0:      	cmp	w8, #0x25
    22d4:      	b.ls	0x2348 <filter_file_buf+0xf8>
    22d8:      	b	0x236c <filter_file_buf+0x11c>
    22dc:      	sub	w9, w8, #0x3
    22e0:      	cmp	w9, #0x2
    22e4:      	b.hs	0x233c <filter_file_buf+0xec>
    22e8:      	add	x1, x1, #0x4
    22ec:      	mov	x0, x19
    22f0:      	bl	0x2960 <filter_char_buf_equal>
    22f4:      	ldr	w8, [x19, #0x4]
    22f8:      	cmp	w8, #0x25
    22fc:      	b.ls	0x2348 <filter_file_buf+0xf8>
    2300:      	b	0x236c <filter_file_buf+0x11c>
    2304:      	ldr	w0, [x19, #0x10]
    2308:      	add	x1, x1, #0x4
    230c:      	bl	0x2e50 <filter_char_buf_postfix>
    2310:      	ldr	w8, [x19, #0x4]
    2314:      	cmp	w8, #0x25
    2318:      	b.ls	0x2348 <filter_file_buf+0xf8>
    231c:      	b	0x236c <filter_file_buf+0x11c>
    2320:      	ldr	w0, [x19, #0x10]
    2324:      	add	x1, x1, #0x4
    2328:      	bl	0x2d90 <filter_char_buf_prefix>
    232c:      	ldr	w8, [x19, #0x4]
    2330:      	cmp	w8, #0x25
    2334:      	b.ls	0x2348 <filter_file_buf+0xf8>
    2338:      	b	0x236c <filter_file_buf+0x11c>
    233c:      	mov	x0, xzr
    2340:      	cmp	w8, #0x25
    2344:      	b.hi	0x236c <filter_file_buf+0x11c>
    2348:      	mov	w8, w8
    234c:      	mov	w9, #0x1                // =1
    2350:      	lsl	x8, x9, x8
    2354:      	mov	x9, #0x50               // =80
    2358:      	movk	x9, #0xc00, lsl #16
    235c:      	movk	x9, #0x20, lsl #32
    2360:      	tst	x8, x9
    2364:      	b.eq	0x236c <filter_file_buf+0x11c>
    2368:      	eor	x0, x0, #0x1
    236c:      	ldp	x30, x19, [sp], #0x10
    2370:      	ret
    2374:      	nop
    2378:      	nop
    237c:      	nop

0000000000002380 <filter_char_buf>:
    2380:      	stp	x30, x19, [sp, #-0x10]!
    2384:      	mov	w8, w2
    2388:      	mov	x19, x0
    238c:      	add	x9, x1, w2, sxtw
    2390:      	ldur	w2, [x9, #-0x4]
    2394:      	add	x1, x1, w8, uxtw
    2398:      	ldr	w8, [x0, #0x4]
    239c:      	mov	x0, xzr
    23a0:      	cmp	w8, #0x19
    23a4:      	b.gt	0x23c8 <filter_char_buf+0x48>
    23a8:      	sub	w9, w8, #0x3
    23ac:      	cmp	w9, #0x2
    23b0:      	b.lo	0x2414 <filter_char_buf+0x94>
    23b4:      	cmp	w8, #0x8
    23b8:      	b.eq	0x2408 <filter_char_buf+0x88>
    23bc:      	cmp	w8, #0x9
    23c0:      	b.eq	0x23e0 <filter_char_buf+0x60>
    23c4:      	b	0x2430 <filter_char_buf+0xb0>
    23c8:      	cmp	w8, #0x20
    23cc:      	b.gt	0x23ec <filter_char_buf+0x6c>
    23d0:      	cmp	w8, #0x1a
    23d4:      	b.eq	0x2408 <filter_char_buf+0x88>
    23d8:      	cmp	w8, #0x1b
    23dc:      	b.ne	0x2430 <filter_char_buf+0xb0>
    23e0:      	ldr	w0, [x19, #0x10]
    23e4:      	bl	0x2e50 <filter_char_buf_postfix>
    23e8:      	b	0x242c <filter_char_buf+0xac>
    23ec:      	cmp	w8, #0x21
    23f0:      	b.eq	0x2420 <filter_char_buf+0xa0>
    23f4:      	cmp	w8, #0x22
    23f8:      	b.ne	0x2430 <filter_char_buf+0xb0>
    23fc:      	mov	x0, x19
    2400:      	mov	w3, #0x1                // =1
    2404:      	b	0x2428 <filter_char_buf+0xa8>
    2408:      	ldr	w0, [x19, #0x10]
    240c:      	bl	0x2d90 <filter_char_buf_prefix>
    2410:      	b	0x242c <filter_char_buf+0xac>
    2414:      	mov	x0, x19
    2418:      	bl	0x2960 <filter_char_buf_equal>
    241c:      	b	0x242c <filter_char_buf+0xac>
    2420:      	mov	x0, x19
    2424:      	mov	w3, wzr
    2428:      	bl	0x3030 <filter_char_substring>
    242c:      	ldr	w8, [x19, #0x4]
    2430:      	cmp	w8, #0x25
    2434:      	b.hi	0x2460 <filter_char_buf+0xe0>
    2438:      	mov	w8, w8
    243c:      	mov	w9, #0x1                // =1
    2440:      	lsl	x8, x9, x8
    2444:      	mov	x9, #0x50               // =80
    2448:      	movk	x9, #0xc00, lsl #16
    244c:      	movk	x9, #0x20, lsl #32
    2450:      	tst	x8, x9
    2454:      	b.eq	0x2460 <filter_char_buf+0xe0>
    2458:      	cmp	x0, #0x0
    245c:      	cset	w0, eq
    2460:      	ldp	x30, x19, [sp], #0x10
    2464:      	ret
    2468:      	nop
    246c:      	nop

0000000000002470 <filter_inet>:
    2470:      	sub	sp, sp, #0x80
    2474:      	str	x30, [sp, #0x50]
    2478:      	stp	x22, x21, [sp, #0x60]
    247c:      	stp	x20, x19, [sp, #0x70]
    2480:      	ldr	w10, [x0, #0xc]
    2484:      	mov	x8, xzr
    2488:      	stp	xzr, xzr, [sp, #0x28]
    248c:      	cmp	w10, #0x27
    2490:      	str	xzr, [sp, #0x10]
    2494:      	stp	xzr, xzr, [sp, #0x18]
    2498:      	str	wzr, [sp, #0x58]
    249c:      	str	wzr, [sp, #0xc]
    24a0:      	b.gt	0x24ec <filter_inet+0x7c>
    24a4:      	cmp	w10, #0x5
    24a8:      	b.eq	0x2520 <filter_inet+0xb0>
    24ac:      	cmp	w10, #0x7
    24b0:      	mov	x11, x1
    24b4:      	b.ne	0x26f4 <filter_inet+0x284>
    24b8:      	ldr	w9, [x0, #0x4]
    24bc:      	mov	x8, xzr
    24c0:      	cmp	w9, #0x13
    24c4:      	b.le	0x2568 <filter_inet+0xf8>
    24c8:      	cmp	w9, #0x17
    24cc:      	b.gt	0x2504 <filter_inet+0x94>
    24d0:      	sub	w10, w9, #0x14
    24d4:      	cmp	w10, #0x2
    24d8:      	b.lo	0x25c4 <filter_inet+0x154>
    24dc:      	sub	w10, w9, #0x16
    24e0:      	cmp	w10, #0x2
    24e4:      	b.lo	0x25bc <filter_inet+0x14c>
    24e8:      	b	0x26f4 <filter_inet+0x284>
    24ec:      	cmp	w10, #0x28
    24f0:      	b.eq	0x2538 <filter_inet+0xc8>
    24f4:      	cmp	w10, #0x29
    24f8:      	mov	x11, x1
    24fc:      	b.eq	0x24b8 <filter_inet+0x48>
    2500:      	b	0x26f4 <filter_inet+0x284>
    2504:      	cmp	w9, #0x1b
    2508:      	b.gt	0x2608 <filter_inet+0x198>
    250c:      	cmp	w9, #0x18
    2510:      	b.eq	0x26c4 <filter_inet+0x254>
    2514:      	cmp	w9, #0x19
    2518:      	b.eq	0x2628 <filter_inet+0x1b8>
    251c:      	b	0x26f4 <filter_inet+0x284>
    2520:      	mov	x11, xzr
    2524:      	ldr	w9, [x0, #0x4]
    2528:      	mov	x8, xzr
    252c:      	cmp	w9, #0x13
    2530:      	b.gt	0x24c8 <filter_inet+0x58>
    2534:      	b	0x2568 <filter_inet+0xf8>
    2538:      	ldrh	w8, [x1]
    253c:      	ldrh	w9, [x1, #0x2]
    2540:      	mov	x11, xzr
    2544:      	strh	w8, [sp, #0x36]
    2548:      	strh	w9, [sp, #0x30]
    254c:      	ldp	x8, x9, [x1, #0x8]
    2550:      	add	x1, sp, #0x10
    2554:      	stp	x8, x9, [sp, #0x10]
    2558:      	ldr	w9, [x0, #0x4]
    255c:      	mov	x8, xzr
    2560:      	cmp	w9, #0x13
    2564:      	b.gt	0x24c8 <filter_inet+0x58>
    2568:      	cmp	w9, #0xf
    256c:      	b.le	0x2590 <filter_inet+0x120>
    2570:      	cmp	w9, #0x11
    2574:      	b.gt	0x25ac <filter_inet+0x13c>
    2578:      	cmp	w9, #0x10
    257c:      	b.eq	0x25bc <filter_inet+0x14c>
    2580:      	cmp	w9, #0x11
    2584:      	b.ne	0x26f4 <filter_inet+0x284>
    2588:      	ldrh	w8, [x1, #0x24]
    258c:      	b	0x27dc <filter_inet+0x36c>
    2590:      	cmp	w9, #0xd
    2594:      	b.eq	0x26c4 <filter_inet+0x254>
    2598:      	cmp	w9, #0xe
    259c:      	b.eq	0x2628 <filter_inet+0x1b8>
    25a0:      	cmp	w9, #0xf
    25a4:      	b.eq	0x25c4 <filter_inet+0x154>
    25a8:      	b	0x26f4 <filter_inet+0x284>
    25ac:      	cmp	w9, #0x12
    25b0:      	b.eq	0x25c4 <filter_inet+0x154>
    25b4:      	cmp	w9, #0x13
    25b8:      	b.ne	0x26f4 <filter_inet+0x284>
    25bc:      	ldrh	w10, [x1, #0x22]
    25c0:      	b	0x25c8 <filter_inet+0x158>
    25c4:      	ldrh	w10, [x1, #0x20]
    25c8:      	mov	w19, wzr
    25cc:      	mov	w20, wzr
    25d0:      	mov	x21, xzr
    25d4:      	str	w10, [sp, #0xc]
    25d8:      	mov	x8, xzr
    25dc:      	cmp	w9, #0x11
    25e0:      	b.gt	0x2640 <filter_inet+0x1d0>
    25e4:      	sub	w10, w9, #0xd
    25e8:      	cmp	w10, #0x2
    25ec:      	b.lo	0x2678 <filter_inet+0x208>
    25f0:      	sub	w10, w9, #0xf
    25f4:      	cmp	w10, #0x2
    25f8:      	b.lo	0x26ec <filter_inet+0x27c>
    25fc:      	cmp	w9, #0x11
    2600:      	b.eq	0x27e0 <filter_inet+0x370>
    2604:      	b	0x26f4 <filter_inet+0x284>
    2608:      	cmp	w9, #0x1c
    260c:      	b.eq	0x27d8 <filter_inet+0x368>
    2610:      	cmp	w9, #0x1d
    2614:      	b.ne	0x26f4 <filter_inet+0x284>
    2618:      	cmp	w10, #0x7
    261c:      	b.ne	0x2830 <filter_inet+0x3c0>
    2620:      	cbnz	x11, 0x283c <filter_inet+0x3cc>
    2624:      	b	0x27e0 <filter_inet+0x370>
    2628:      	ldp	w19, w20, [x1, #0x10]
    262c:      	ldr	x21, [x1, #0x18]
    2630:      	mov	w10, wzr
    2634:      	mov	x8, xzr
    2638:      	cmp	w9, #0x11
    263c:      	b.le	0x25e4 <filter_inet+0x174>
    2640:      	cmp	w9, #0x19
    2644:      	b.hi	0x26e0 <filter_inet+0x270>
    2648:      	mov	w11, #0x1               // =1
    264c:      	mov	w12, #0x500000          // =5242880
    2650:      	lsl	w11, w11, w9
    2654:      	tst	w11, w12
    2658:      	b.ne	0x270c <filter_inet+0x29c>
    265c:      	mov	w12, #0xa00000          // =10485760
    2660:      	tst	w11, w12
    2664:      	b.ne	0x272c <filter_inet+0x2bc>
    2668:      	mov	w10, #0x1               // =1
    266c:      	lsl	w10, w10, w9
    2670:      	tst	w10, #0x3000000
    2674:      	b.eq	0x26e0 <filter_inet+0x270>
    2678:      	ldrh	w8, [x1, #0x26]
    267c:      	cmp	w8, #0xa
    2680:      	b.eq	0x274c <filter_inet+0x2dc>
    2684:      	cmp	w8, #0x2
    2688:      	b.ne	0x27bc <filter_inet+0x34c>
    268c:      	ldr	w8, [x0, #0x10]
    2690:      	mov	x22, x0
    2694:      	adrp	x0, 0x2000 <filter_8ty_range>
    2698:      	add	x9, sp, #0x5c
    269c:      	str	w8, [sp, #0x5c]
    26a0:      	mov	w8, #0x1                // =1
    26a4:      	add	x1, sp, #0x5c
    26a8:      	ldr	x0, [x0]
    26ac:      	blr	x8
    26b0:      	cbz	x0, 0x27fc <filter_inet+0x38c>
    26b4:      	mov	w8, #0x20               // =32
    26b8:      	add	x1, sp, #0x3c
    26bc:      	stp	w8, w19, [sp, #0x3c]
    26c0:      	b	0x278c <filter_inet+0x31c>
    26c4:      	ldp	w19, w20, [x1]
    26c8:      	ldr	x21, [x1, #0x8]
    26cc:      	mov	w10, wzr
    26d0:      	mov	x8, xzr
    26d4:      	cmp	w9, #0x11
    26d8:      	b.le	0x25e4 <filter_inet+0x174>
    26dc:      	b	0x2640 <filter_inet+0x1d0>
    26e0:      	sub	w9, w9, #0x12
    26e4:      	cmp	w9, #0x2
    26e8:      	b.hs	0x26f4 <filter_inet+0x284>
    26ec:      	add	x1, sp, #0xc
    26f0:      	b	0x27e4 <filter_inet+0x374>
    26f4:      	ldp	x20, x19, [sp, #0x70]
    26f8:      	mov	x0, x8
    26fc:      	ldr	x30, [sp, #0x50]
    2700:      	ldp	x22, x21, [sp, #0x60]
    2704:      	add	sp, sp, #0x80
    2708:      	ret
    270c:      	cmp	w10, #0x400
    2710:      	cset	w8, lo
    2714:      	ldp	x20, x19, [sp, #0x70]
    2718:      	mov	x0, x8
    271c:      	ldr	x30, [sp, #0x50]
    2720:      	ldp	x22, x21, [sp, #0x60]
    2724:      	add	sp, sp, #0x80
    2728:      	ret
    272c:      	cmp	w10, #0x3ff
    2730:      	cset	w8, hi
    2734:      	ldp	x20, x19, [sp, #0x70]
    2738:      	mov	x0, x8
    273c:      	ldr	x30, [sp, #0x50]
    2740:      	ldp	x22, x21, [sp, #0x60]
    2744:      	add	sp, sp, #0x80
    2748:      	ret
    274c:      	ldr	w8, [x0, #0x14]
    2750:      	mov	x22, x0
    2754:      	adrp	x0, 0x2000 <filter_8ty_range>
    2758:      	add	x9, sp, #0x5c
    275c:      	str	w8, [sp, #0x5c]
    2760:      	mov	w8, #0x1                // =1
    2764:      	add	x1, sp, #0x5c
    2768:      	ldr	x0, [x0]
    276c:      	blr	x8
    2770:      	cbz	x0, 0x27fc <filter_inet+0x38c>
    2774:      	mov	w8, #0x80               // =128
    2778:      	add	x1, sp, #0x3c
    277c:      	stp	w20, w21, [sp, #0x44]
    2780:      	stp	w8, w19, [sp, #0x3c]
    2784:      	lsr	x8, x21, #32
    2788:      	str	w8, [sp, #0x4c]
    278c:      	mov	w8, #0x1                // =1
    2790:      	blr	x8
    2794:      	ldr	w8, [x22, #0x4]
    2798:      	sub	w9, w8, #0x18
    279c:      	cmp	w9, #0x2
    27a0:      	b.lo	0x280c <filter_inet+0x39c>
    27a4:      	sub	w8, w8, #0xd
    27a8:      	cmp	w8, #0x1
    27ac:      	b.hi	0x27bc <filter_inet+0x34c>
    27b0:      	cmp	x0, #0x0
    27b4:      	cset	w8, ne
    27b8:      	b	0x2814 <filter_inet+0x3a4>
    27bc:      	mov	w8, wzr
    27c0:      	ldp	x20, x19, [sp, #0x70]
    27c4:      	mov	x0, x8
    27c8:      	ldr	x30, [sp, #0x50]
    27cc:      	ldp	x22, x21, [sp, #0x60]
    27d0:      	add	sp, sp, #0x80
    27d4:      	ret
    27d8:      	ldrh	w8, [x1, #0x26]
    27dc:      	str	w8, [sp, #0x58]
    27e0:      	add	x1, sp, #0x58
    27e4:      	bl	0x1260 <filter_32ty_map>
    27e8:      	ldp	x20, x19, [sp, #0x70]
    27ec:      	ldr	x30, [sp, #0x50]
    27f0:      	ldp	x22, x21, [sp, #0x60]
    27f4:      	add	sp, sp, #0x80
    27f8:      	ret
    27fc:      	ldr	w8, [x22, #0x4]
    2800:      	and	w8, w8, #0xfffffffe
    2804:      	cmp	w8, #0x18
    2808:      	b	0x2810 <filter_inet+0x3a0>
    280c:      	cmp	x0, #0x0
    2810:      	cset	w8, eq
    2814:      	mov	w8, w8
    2818:      	ldp	x20, x19, [sp, #0x70]
    281c:      	mov	x0, x8
    2820:      	ldr	x30, [sp, #0x50]
    2824:      	ldp	x22, x21, [sp, #0x60]
    2828:      	add	sp, sp, #0x80
    282c:      	ret
    2830:      	cmp	w10, #0x29
    2834:      	b.ne	0x2844 <filter_inet+0x3d4>
    2838:      	cbz	x11, 0x2844 <filter_inet+0x3d4>
    283c:      	ldrb	w8, [x11, #0x3a]
    2840:      	str	w8, [sp, #0x58]
    2844:      	cmp	w10, #0x29
    2848:      	b.eq	0x27e0 <filter_inet+0x370>
    284c:      	cmp	w10, #0x7
    2850:      	b.eq	0x27e0 <filter_inet+0x370>
    2854:      	mov	x8, xzr
    2858:      	ldp	x20, x19, [sp, #0x70]
    285c:      	mov	x0, x8
    2860:      	ldr	x30, [sp, #0x50]
    2864:      	ldp	x22, x21, [sp, #0x60]
    2868:      	add	sp, sp, #0x80
    286c:      	ret

0000000000002870 <filter_sockaddr_un>:
    2870:      	sub	sp, sp, #0x20
    2874:      	stp	x30, x19, [sp, #0x10]
    2878:      	mov	x19, x0
    287c:      	ldrb	w2, [x1, #0x3]
    2880:      	mov	x0, xzr
    2884:      	ldr	w8, [x19, #0x4]
    2888:      	cmp	w8, #0x19
    288c:      	b.gt	0x28e0 <filter_sockaddr_un+0x70>
    2890:      	sub	w9, w8, #0x3
    2894:      	cmp	w9, #0x2
    2898:      	b.hs	0x28f4 <filter_sockaddr_un+0x84>
    289c:      	add	x1, x1, #0x4
    28a0:      	mov	x0, x19
    28a4:      	bl	0x2960 <filter_char_buf_equal>
    28a8:      	ldr	w8, [x19, #0x4]
    28ac:      	cmp	w8, #0x25
    28b0:      	b.hi	0x28d4 <filter_sockaddr_un+0x64>
    28b4:      	mov	w9, #0x1                // =1
    28b8:      	lsl	x8, x9, x8
    28bc:      	mov	x9, #0x50               // =80
    28c0:      	movk	x9, #0xc00, lsl #16
    28c4:      	movk	x9, #0x20, lsl #32
    28c8:      	tst	x8, x9
    28cc:      	b.eq	0x28d4 <filter_sockaddr_un+0x64>
    28d0:      	eor	x0, x0, #0x1
    28d4:      	ldp	x30, x19, [sp, #0x10]
    28d8:      	add	sp, sp, #0x20
    28dc:      	ret
    28e0:      	cmp	w8, #0x1c
    28e4:      	b.eq	0x2940 <filter_sockaddr_un+0xd0>
    28e8:      	cmp	w8, #0x1a
    28ec:      	b.eq	0x28fc <filter_sockaddr_un+0x8c>
    28f0:      	b	0x28d4 <filter_sockaddr_un+0x64>
    28f4:      	cmp	w8, #0x8
    28f8:      	b.ne	0x28d4 <filter_sockaddr_un+0x64>
    28fc:      	ldr	w0, [x19, #0x10]
    2900:      	add	x1, x1, #0x4
    2904:      	bl	0x2d90 <filter_char_buf_prefix>
    2908:      	ldr	w8, [x19, #0x4]
    290c:      	cmp	w8, #0x25
    2910:      	b.hi	0x28d4 <filter_sockaddr_un+0x64>
    2914:      	mov	w9, #0x1                // =1
    2918:      	lsl	x8, x9, x8
    291c:      	mov	x9, #0x50               // =80
    2920:      	movk	x9, #0xc00, lsl #16
    2924:      	movk	x9, #0x20, lsl #32
    2928:      	tst	x8, x9
    292c:      	b.eq	0x28d4 <filter_sockaddr_un+0x64>
    2930:      	eor	x0, x0, #0x1
    2934:      	ldp	x30, x19, [sp, #0x10]
    2938:      	add	sp, sp, #0x20
    293c:      	ret
    2940:      	ldrh	w8, [x1]
    2944:      	add	x1, sp, #0xc
    2948:      	mov	x0, x19
    294c:      	str	w8, [sp, #0xc]
    2950:      	bl	0x1260 <filter_32ty_map>
    2954:      	ldp	x30, x19, [sp, #0x10]
    2958:      	add	sp, sp, #0x20
    295c:      	ret

0000000000002960 <filter_char_buf_equal>:
    2960:      	str	x29, [sp, #-0x50]!
    2964:      	stp	x30, x25, [sp, #0x10]
    2968:      	stp	x24, x23, [sp, #0x20]
    296c:      	stp	x22, x21, [sp, #0x30]
    2970:      	stp	x20, x19, [sp, #0x40]
    2974:      	cmp	w2, #0x1, lsl #12       // =0x1000
    2978:      	str	wzr, [sp, #0x8]
    297c:      	b.ls	0x299c <filter_char_buf_equal+0x3c>
    2980:      	mov	x0, xzr
    2984:      	ldp	x20, x19, [sp, #0x40]
    2988:      	ldp	x22, x21, [sp, #0x30]
    298c:      	ldp	x24, x23, [sp, #0x20]
    2990:      	ldp	x30, x25, [sp, #0x10]
    2994:      	ldr	x29, [sp], #0x50
    2998:      	ret
    299c:      	and	w9, w2, #0xffff
    29a0:      	add	x8, x0, #0x10
    29a4:      	cmp	w9, #0x90
    29a8:      	b.hi	0x2a18 <filter_char_buf_equal+0xb8>
    29ac:      	and	w9, w2, #0xff
    29b0:      	mov	w10, #0xab              // =171
    29b4:      	tst	w2, #0xffff
    29b8:      	mul	w9, w9, w10
    29bc:      	mov	w10, #0x18              // =24
    29c0:      	lsr	w9, w9, #12
    29c4:      	msub	w9, w9, w10, w2
    29c8:      	b.eq	0x29d8 <filter_char_buf_equal+0x78>
    29cc:      	tst	w9, #0xff
    29d0:      	mov	w23, w2
    29d4:      	b.eq	0x29f0 <filter_char_buf_equal+0x90>
    29d8:      	sub	w9, w2, w9, uxtb
    29dc:      	and	w10, w9, #0xffff
    29e0:      	add	w9, w9, #0x18
    29e4:      	and	w23, w9, #0xffff
    29e8:      	cmp	w10, #0x78
    29ec:      	b.hi	0x2a8c <filter_char_buf_equal+0x12c>
    29f0:      	and	w9, w23, #0xff
    29f4:      	mov	w10, #0xab              // =171
    29f8:      	mul	w9, w9, w10
    29fc:      	lsr	w9, w9, #12
    2a00:      	sub	w22, w9, #0x1
    2a04:      	and	w9, w22, #0xf
    2a08:      	ldr	w24, [x8, w9, uxtw #2]
    2a0c:      	cmn	w24, #0x1
    2a10:      	b.ne	0x2b04 <filter_char_buf_equal+0x1a4>
    2a14:      	b	0x2cac <filter_char_buf_equal+0x34c>
    2a18:      	cmp	w9, #0x101
    2a1c:      	b.hs	0x2a5c <filter_char_buf_equal+0xfc>
    2a20:      	mov	w23, #0x100             // =256
    2a24:      	sub	w9, w23, #0x100
    2a28:      	ror	w9, w9, #0x8
    2a2c:      	cmp	w9, #0x2
    2a30:      	b.le	0x2a9c <filter_char_buf_equal+0x13c>
    2a34:      	cmp	w9, #0x3
    2a38:      	b.eq	0x2ad8 <filter_char_buf_equal+0x178>
    2a3c:      	cmp	w9, #0x7
    2a40:      	b.ne	0x2ac0 <filter_char_buf_equal+0x160>
    2a44:      	mov	w22, #0x9               // =9
    2a48:      	and	w9, w22, #0xf
    2a4c:      	ldr	w24, [x8, w9, uxtw #2]
    2a50:      	cmn	w24, #0x1
    2a54:      	b.ne	0x2b04 <filter_char_buf_equal+0x1a4>
    2a58:      	b	0x2cac <filter_char_buf_equal+0x34c>
    2a5c:      	and	w9, w2, #0xffff
    2a60:      	cmp	w9, #0x201
    2a64:      	b.hs	0x2a80 <filter_char_buf_equal+0x120>
    2a68:      	mov	w23, #0x200             // =512
    2a6c:      	sub	w9, w23, #0x100
    2a70:      	ror	w9, w9, #0x8
    2a74:      	cmp	w9, #0x2
    2a78:      	b.le	0x2a9c <filter_char_buf_equal+0x13c>
    2a7c:      	b	0x2a34 <filter_char_buf_equal+0xd4>
    2a80:      	cmp	w9, #0x401
    2a84:      	b.hs	0x2c64 <filter_char_buf_equal+0x304>
    2a88:      	mov	w23, #0x400             // =1024
    2a8c:      	sub	w9, w23, #0x100
    2a90:      	ror	w9, w9, #0x8
    2a94:      	cmp	w9, #0x2
    2a98:      	b.gt	0x2a34 <filter_char_buf_equal+0xd4>
    2a9c:      	cbz	w9, 0x2af0 <filter_char_buf_equal+0x190>
    2aa0:      	cmp	w9, #0x1
    2aa4:      	b.ne	0x2ac0 <filter_char_buf_equal+0x160>
    2aa8:      	mov	w22, #0x7               // =7
    2aac:      	and	w9, w22, #0xf
    2ab0:      	ldr	w24, [x8, w9, uxtw #2]
    2ab4:      	cmn	w24, #0x1
    2ab8:      	b.ne	0x2b04 <filter_char_buf_equal+0x1a4>
    2abc:      	b	0x2cac <filter_char_buf_equal+0x34c>
    2ac0:      	mov	w22, #0xa               // =10
    2ac4:      	and	w9, w22, #0xf
    2ac8:      	ldr	w24, [x8, w9, uxtw #2]
    2acc:      	cmn	w24, #0x1
    2ad0:      	b.ne	0x2b04 <filter_char_buf_equal+0x1a4>
    2ad4:      	b	0x2cac <filter_char_buf_equal+0x34c>
    2ad8:      	mov	w22, #0x8               // =8
    2adc:      	and	w9, w22, #0xf
    2ae0:      	ldr	w24, [x8, w9, uxtw #2]
    2ae4:      	cmn	w24, #0x1
    2ae8:      	b.ne	0x2b04 <filter_char_buf_equal+0x1a4>
    2aec:      	b	0x2cac <filter_char_buf_equal+0x34c>
    2af0:      	mov	w22, #0x6               // =6
    2af4:      	and	w9, w22, #0xf
    2af8:      	ldr	w24, [x8, w9, uxtw #2]
    2afc:      	cmn	w24, #0x1
    2b00:      	b.eq	0x2cac <filter_char_buf_equal+0x34c>
    2b04:      	adrp	x0, 0x2000 <filter_8ty_range>
    2b08:      	add	x29, sp, #0x8
    2b0c:      	mov	w8, #0x1                // =1
    2b10:      	ldr	x0, [x0]
    2b14:      	mov	x25, x1
    2b18:      	add	x1, sp, #0x8
    2b1c:      	mov	w21, w2
    2b20:      	mov	w20, #0x1               // =1
    2b24:      	blr	x8
    2b28:      	mov	x19, x0
    2b2c:      	adrp	x0, 0x2000 <filter_8ty_range>
    2b30:      	add	x1, sp, #0x8
    2b34:      	ldr	x0, [x0]
    2b38:      	blr	x20
    2b3c:      	mov	x20, x0
    2b40:      	mov	x0, xzr
    2b44:      	cbz	x19, 0x2984 <filter_char_buf_equal+0x24>
    2b48:      	cbz	x20, 0x2984 <filter_char_buf_equal+0x24>
    2b4c:      	mov	x0, x19
    2b50:      	cmp	w22, #0x5
    2b54:      	b.gt	0x2b8c <filter_char_buf_equal+0x22c>
    2b58:      	strb	w21, [x0], #0x1
    2b5c:      	mov	w29, w21
    2b60:      	mov	w8, #0x4                // =4
    2b64:      	mov	x2, x25
    2b68:      	mov	w1, w21
    2b6c:      	blr	x8
    2b70:      	subs	w8, w23, w21
    2b74:      	b.ls	0x2bc4 <filter_char_buf_equal+0x264>
    2b78:      	add	x9, x19, x29
    2b7c:      	and	w1, w8, #0xfff
    2b80:      	mov	w8, #0x4                // =4
    2b84:      	add	x0, x9, #0x1
    2b88:      	b	0x2bbc <filter_char_buf_equal+0x25c>
    2b8c:      	strh	w21, [x0], #0x2
    2b90:      	mov	w29, w21
    2b94:      	mov	w8, #0x4                // =4
    2b98:      	mov	x2, x25
    2b9c:      	mov	w1, w21
    2ba0:      	blr	x8
    2ba4:      	subs	w8, w23, w21
    2ba8:      	b.ls	0x2bc4 <filter_char_buf_equal+0x264>
    2bac:      	add	x9, x19, x29
    2bb0:      	and	w1, w8, #0xfff
    2bb4:      	mov	w8, #0x4                // =4
    2bb8:      	add	x0, x9, #0x2
    2bbc:      	mov	x2, x20
    2bc0:      	blr	x8
    2bc4:      	cmp	w22, #0x4
    2bc8:      	str	w24, [sp, #0xc]
    2bcc:      	b.le	0x2c04 <filter_char_buf_equal+0x2a4>
    2bd0:      	cmp	w22, #0x7
    2bd4:      	b.gt	0x2c38 <filter_char_buf_equal+0x2d8>
    2bd8:      	cmp	w22, #0x5
    2bdc:      	b.eq	0x2d2c <filter_char_buf_equal+0x3cc>
    2be0:      	cmp	w22, #0x6
    2be4:      	b.eq	0x2cf0 <filter_char_buf_equal+0x390>
    2be8:      	cmp	w22, #0x7
    2bec:      	b.ne	0x2cac <filter_char_buf_equal+0x34c>
    2bf0:      	adrp	x0, 0x2000 <filter_8ty_range>
    2bf4:      	mov	w8, #0x1                // =1
    2bf8:      	add	x9, sp, #0xc
    2bfc:      	ldr	x0, [x0]
    2c00:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2c04:      	cmp	w22, #0x1
    2c08:      	b.le	0x2c8c <filter_char_buf_equal+0x32c>
    2c0c:      	cmp	w22, #0x2
    2c10:      	b.eq	0x2d18 <filter_char_buf_equal+0x3b8>
    2c14:      	cmp	w22, #0x3
    2c18:      	b.eq	0x2cdc <filter_char_buf_equal+0x37c>
    2c1c:      	cmp	w22, #0x4
    2c20:      	b.ne	0x2cac <filter_char_buf_equal+0x34c>
    2c24:      	adrp	x0, 0x2000 <filter_8ty_range>
    2c28:      	mov	w8, #0x1                // =1
    2c2c:      	add	x9, sp, #0xc
    2c30:      	ldr	x0, [x0]
    2c34:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2c38:      	cmp	w22, #0x8
    2c3c:      	b.eq	0x2d40 <filter_char_buf_equal+0x3e0>
    2c40:      	cmp	w22, #0x9
    2c44:      	b.eq	0x2d04 <filter_char_buf_equal+0x3a4>
    2c48:      	cmp	w22, #0xa
    2c4c:      	b.ne	0x2cac <filter_char_buf_equal+0x34c>
    2c50:      	adrp	x0, 0x2000 <filter_8ty_range>
    2c54:      	mov	w8, #0x1                // =1
    2c58:      	add	x9, sp, #0xc
    2c5c:      	ldr	x0, [x0]
    2c60:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2c64:      	and	w9, w2, #0xffff
    2c68:      	mov	w10, #0x1000            // =4096
    2c6c:      	cmp	w9, #0x800
    2c70:      	mov	w9, #0x800              // =2048
    2c74:      	csel	w23, w10, w9, hi
    2c78:      	sub	w9, w23, #0x100
    2c7c:      	ror	w9, w9, #0x8
    2c80:      	cmp	w9, #0x2
    2c84:      	b.le	0x2a9c <filter_char_buf_equal+0x13c>
    2c88:      	b	0x2a34 <filter_char_buf_equal+0xd4>
    2c8c:      	cbz	w22, 0x2cc8 <filter_char_buf_equal+0x368>
    2c90:      	cmp	w22, #0x1
    2c94:      	b.ne	0x2cac <filter_char_buf_equal+0x34c>
    2c98:      	adrp	x0, 0x2000 <filter_8ty_range>
    2c9c:      	mov	w8, #0x1                // =1
    2ca0:      	add	x9, sp, #0xc
    2ca4:      	ldr	x0, [x0]
    2ca8:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2cac:      	mov	x0, xzr
    2cb0:      	ldp	x20, x19, [sp, #0x40]
    2cb4:      	ldp	x22, x21, [sp, #0x30]
    2cb8:      	ldp	x24, x23, [sp, #0x20]
    2cbc:      	ldp	x30, x25, [sp, #0x10]
    2cc0:      	ldr	x29, [sp], #0x50
    2cc4:      	ret
    2cc8:      	adrp	x0, 0x2000 <filter_8ty_range>
    2ccc:      	mov	w8, #0x1                // =1
    2cd0:      	add	x9, sp, #0xc
    2cd4:      	ldr	x0, [x0]
    2cd8:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2cdc:      	adrp	x0, 0x2000 <filter_8ty_range>
    2ce0:      	mov	w8, #0x1                // =1
    2ce4:      	add	x9, sp, #0xc
    2ce8:      	ldr	x0, [x0]
    2cec:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2cf0:      	adrp	x0, 0x2000 <filter_8ty_range>
    2cf4:      	mov	w8, #0x1                // =1
    2cf8:      	add	x9, sp, #0xc
    2cfc:      	ldr	x0, [x0]
    2d00:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2d04:      	adrp	x0, 0x2000 <filter_8ty_range>
    2d08:      	mov	w8, #0x1                // =1
    2d0c:      	add	x9, sp, #0xc
    2d10:      	ldr	x0, [x0]
    2d14:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2d18:      	adrp	x0, 0x2000 <filter_8ty_range>
    2d1c:      	mov	w8, #0x1                // =1
    2d20:      	add	x9, sp, #0xc
    2d24:      	ldr	x0, [x0]
    2d28:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2d2c:      	adrp	x0, 0x2000 <filter_8ty_range>
    2d30:      	mov	w8, #0x1                // =1
    2d34:      	add	x9, sp, #0xc
    2d38:      	ldr	x0, [x0]
    2d3c:      	b	0x2d50 <filter_char_buf_equal+0x3f0>
    2d40:      	adrp	x0, 0x2000 <filter_8ty_range>
    2d44:      	mov	w8, #0x1                // =1
    2d48:      	add	x9, sp, #0xc
    2d4c:      	ldr	x0, [x0]
    2d50:      	add	x1, sp, #0xc
    2d54:      	blr	x8
    2d58:      	cbz	x0, 0x2984 <filter_char_buf_equal+0x24>
    2d5c:      	mov	w8, #0x1                // =1
    2d60:      	mov	x1, x19
    2d64:      	blr	x8
    2d68:      	cmp	x0, #0x0
    2d6c:      	cset	w0, ne
    2d70:      	ldp	x20, x19, [sp, #0x40]
    2d74:      	ldp	x22, x21, [sp, #0x30]
    2d78:      	ldp	x24, x23, [sp, #0x20]
    2d7c:      	ldp	x30, x25, [sp, #0x10]
    2d80:      	ldr	x29, [sp], #0x50
    2d84:      	ret
    2d88:      	nop
    2d8c:      	nop

0000000000002d90 <filter_char_buf_prefix>:
    2d90:      	sub	sp, sp, #0x30
    2d94:      	stp	x30, x21, [sp, #0x10]
    2d98:      	stp	x20, x19, [sp, #0x20]
    2d9c:      	stp	wzr, w0, [sp, #0x8]
    2da0:      	adrp	x0, 0x2000 <filter_8ty_range>
    2da4:      	mov	w8, #0x1                // =1
    2da8:      	add	x9, sp, #0xc
    2dac:      	ldr	x0, [x0]
    2db0:      	mov	x19, x1
    2db4:      	add	x1, sp, #0xc
    2db8:      	mov	w20, w2
    2dbc:      	blr	x8
    2dc0:      	mov	x8, x0
    2dc4:      	mov	x0, xzr
    2dc8:      	cbz	w20, 0x2e34 <filter_char_buf_prefix+0xa4>
    2dcc:      	cbz	x8, 0x2e34 <filter_char_buf_prefix+0xa4>
    2dd0:      	adrp	x0, 0x2000 <filter_8ty_range>
    2dd4:      	mov	x21, x8
    2dd8:      	mov	w8, #0x1                // =1
    2ddc:      	ldr	x0, [x0]
    2de0:      	add	x9, sp, #0x8
    2de4:      	add	x1, sp, #0x8
    2de8:      	blr	x8
    2dec:      	cbz	x0, 0x2e34 <filter_char_buf_prefix+0xa4>
    2df0:      	cmp	w20, #0xff
    2df4:      	mov	w8, #0xff               // =255
    2df8:      	mov	x2, x19
    2dfc:      	csel	w1, w20, w8, lo
    2e00:      	mov	x8, x0
    2e04:      	mov	x20, x0
    2e08:      	lsl	w9, w1, #3
    2e0c:      	str	w9, [x8], #0x4
    2e10:      	mov	w9, #0x4                // =4
    2e14:      	mov	x0, x8
    2e18:      	blr	x9
    2e1c:      	mov	w8, #0x1                // =1
    2e20:      	mov	x0, x21
    2e24:      	mov	x1, x20
    2e28:      	blr	x8
    2e2c:      	cmp	x0, #0x0
    2e30:      	cset	w0, ne
    2e34:      	ldp	x20, x19, [sp, #0x20]
    2e38:      	ldp	x30, x21, [sp, #0x10]
    2e3c:      	add	sp, sp, #0x30
    2e40:      	ret
    2e44:      	nop
    2e48:      	nop
    2e4c:      	nop

0000000000002e50 <filter_char_buf_postfix>:
    2e50:      	sub	sp, sp, #0x30
    2e54:      	stp	x30, x21, [sp, #0x10]
    2e58:      	stp	x20, x19, [sp, #0x20]
    2e5c:      	stp	wzr, w0, [sp, #0x8]
    2e60:      	adrp	x0, 0x2000 <filter_8ty_range>
    2e64:      	mov	w8, #0x1                // =1
    2e68:      	add	x9, sp, #0xc
    2e6c:      	ldr	x0, [x0]
    2e70:      	mov	x19, x1
    2e74:      	add	x1, sp, #0xc
    2e78:      	mov	w20, w2
    2e7c:      	blr	x8
    2e80:      	mov	x8, x0
    2e84:      	mov	x0, xzr
    2e88:      	cbz	w20, 0x2f1c <filter_char_buf_postfix+0xcc>
    2e8c:      	cbz	x8, 0x2f1c <filter_char_buf_postfix+0xcc>
    2e90:      	adrp	x0, 0x2000 <filter_8ty_range>
    2e94:      	mov	x21, x8
    2e98:      	mov	w8, #0x1                // =1
    2e9c:      	ldr	x0, [x0]
    2ea0:      	add	x9, sp, #0x8
    2ea4:      	add	x1, sp, #0x8
    2ea8:      	blr	x8
    2eac:      	cbz	x0, 0x2f1c <filter_char_buf_postfix+0xcc>
    2eb0:      	cmp	w20, #0x7f
    2eb4:      	mov	w9, #0x7f               // =127
    2eb8:      	mov	x1, x0
    2ebc:      	mov	x8, xzr
    2ec0:      	sub	w10, w20, #0x1
    2ec4:      	csel	w9, w20, w9, lo
    2ec8:      	lsl	w9, w9, #3
    2ecc:      	str	w9, [x0]
    2ed0:      	mov	w9, w20
    2ed4:      	nop
    2ed8:      	nop
    2edc:      	nop
    2ee0:      	cmp	x8, #0x7f
    2ee4:      	b.eq	0x2f08 <filter_char_buf_postfix+0xb8>
    2ee8:      	and	x11, x10, #0xfff
    2eec:      	add	x12, x1, x8
    2ef0:      	add	x8, x8, #0x1
    2ef4:      	ldrb	w11, [x19, x11]
    2ef8:      	sub	w10, w10, #0x1
    2efc:      	cmp	x9, x8
    2f00:      	strb	w11, [x12, #0x4]
    2f04:      	b.ne	0x2ee0 <filter_char_buf_postfix+0x90>
    2f08:      	mov	w8, #0x1                // =1
    2f0c:      	mov	x0, x21
    2f10:      	blr	x8
    2f14:      	cmp	x0, #0x0
    2f18:      	cset	w0, ne
    2f1c:      	ldp	x20, x19, [sp, #0x20]
    2f20:      	ldp	x30, x21, [sp, #0x10]
    2f24:      	add	sp, sp, #0x30
    2f28:      	ret
    2f2c:      	nop

0000000000002f30 <filter_file_type>:
    2f30:      	sub	sp, sp, #0x20
    2f34:      	stp	x30, x19, [sp, #0x10]
    2f38:      	ldr	w8, [x1]
    2f3c:      	strh	wzr, [sp, #0xc]
    2f40:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2f44:      	b.hi	0x301c <filter_file_type+0xec>
    2f48:      	add	x9, x1, #0x4
    2f4c:      	mov	w10, #0x2               // =2
    2f50:      	mov	w11, #0x4               // =4
    2f54:      	add	x12, sp, #0xc
    2f58:      	mov	x19, x0
    2f5c:      	add	x0, sp, #0xc
    2f60:      	add	x8, x9, x8
    2f64:      	add	x8, x8, #0x4
    2f68:      	ldr	w8, [x1]
    2f6c:      	mov	w1, #0x2                // =2
    2f70:      	add	x8, x9, x8
    2f74:      	add	x2, x8, #0x4
    2f78:      	blr	x11
    2f7c:      	ldr	w9, [x19, #0x10]
    2f80:      	cbz	w9, 0x301c <filter_file_type+0xec>
    2f84:      	ldrh	w8, [sp, #0xc]
    2f88:      	and	w8, w8, #0xf000
    2f8c:      	cmp	w9, w8
    2f90:      	b.ne	0x2fa4 <filter_file_type+0x74>
    2f94:      	mov	w0, #0x1                // =1
    2f98:      	ldp	x30, x19, [sp, #0x10]
    2f9c:      	add	sp, sp, #0x20
    2fa0:      	ret
    2fa4:      	ldr	w9, [x19, #0x8]
    2fa8:      	cmp	w9, #0xc
    2fac:      	b.ls	0x301c <filter_file_type+0xec>
    2fb0:      	ldr	w10, [x19, #0x14]
    2fb4:      	cbz	w10, 0x301c <filter_file_type+0xec>
    2fb8:      	cmp	w10, w8
    2fbc:      	b.ne	0x2fd0 <filter_file_type+0xa0>
    2fc0:      	mov	w0, #0x1                // =1
    2fc4:      	ldp	x30, x19, [sp, #0x10]
    2fc8:      	add	sp, sp, #0x20
    2fcc:      	ret
    2fd0:      	cmp	w9, #0x11
    2fd4:      	b.lo	0x301c <filter_file_type+0xec>
    2fd8:      	ldr	w10, [x19, #0x18]
    2fdc:      	cbz	w10, 0x301c <filter_file_type+0xec>
    2fe0:      	cmp	w10, w8
    2fe4:      	b.ne	0x2ff8 <filter_file_type+0xc8>
    2fe8:      	mov	w0, #0x1                // =1
    2fec:      	ldp	x30, x19, [sp, #0x10]
    2ff0:      	add	sp, sp, #0x20
    2ff4:      	ret
    2ff8:      	cmp	w9, #0x15
    2ffc:      	b.lo	0x301c <filter_file_type+0xec>
    3000:      	ldr	w9, [x19, #0x1c]
    3004:      	cbz	w9, 0x301c <filter_file_type+0xec>
    3008:      	cmp	w9, w8
    300c:      	cset	w0, eq
    3010:      	ldp	x30, x19, [sp, #0x10]
    3014:      	add	sp, sp, #0x20
    3018:      	ret
    301c:      	mov	x0, xzr
    3020:      	ldp	x30, x19, [sp, #0x10]
    3024:      	add	sp, sp, #0x20
    3028:      	ret
    302c:      	nop

0000000000003030 <filter_char_substring>:
    3030:      	str	x29, [sp, #-0x50]!
    3034:      	stp	x30, x25, [sp, #0x10]
    3038:      	stp	x24, x23, [sp, #0x20]
    303c:      	stp	x22, x21, [sp, #0x30]
    3040:      	stp	x20, x19, [sp, #0x40]
    3044:      	mov	x21, x1
    3048:      	mov	x19, x0
    304c:      	add	x23, x0, #0x10
    3050:      	mov	w24, w2
    3054:      	tbz	w3, #0x0, 0x3148 <filter_char_substring+0x118>
    3058:      	cbz	w2, 0x3208 <filter_char_substring+0x1d8>
    305c:      	adrp	x22, 0x3000 <filter_file_type+0xd0>
    3060:      	mov	x25, xzr
    3064:      	mov	w29, wzr
    3068:      	ldr	x22, [x22]
    306c:      	add	x20, sp, #0xc
    3070:      	nop
    3074:      	nop
    3078:      	nop
    307c:      	nop
    3080:      	ldr	w8, [x23, x25, lsl #2]
    3084:      	add	x1, sp, #0xc
    3088:      	mov	x0, x22
    308c:      	str	w8, [sp, #0xc]
    3090:      	mov	w8, #0x1                // =1
    3094:      	blr	x8
    3098:      	cbz	x0, 0x32a8 <filter_char_substring+0x278>
    309c:      	mov	x8, xzr
    30a0:      	mov	x9, x21
    30a4:      	mov	x10, x24
    30a8:      	b	0x30c0 <filter_char_substring+0x90>
    30ac:      	add	x8, x8, #0x1
    30b0:      	sub	x10, x10, #0x1
    30b4:      	add	x9, x9, #0x1
    30b8:      	cmp	x8, x24
    30bc:      	b.eq	0x3124 <filter_char_substring+0xf4>
    30c0:      	mov	x11, xzr
    30c4:      	cmp	x10, x11
    30c8:      	b.eq	0x30ac <filter_char_substring+0x7c>
    30cc:      	ldrb	w12, [x0, x11]
    30d0:      	cbz	w12, 0x3120 <filter_char_substring+0xf0>
    30d4:      	ldrb	w13, [x9, x11]
    30d8:      	sub	w14, w13, #0x41
    30dc:      	orr	w15, w13, #0x20
    30e0:      	cmp	w14, #0x1a
    30e4:      	sub	w14, w12, #0x41
    30e8:      	csel	w13, w15, w13, lo
    30ec:      	orr	w15, w12, #0x20
    30f0:      	cmp	w14, #0x1a
    30f4:      	csel	w12, w15, w12, lo
    30f8:      	cmp	x11, #0x62
    30fc:      	b.hi	0x30ac <filter_char_substring+0x7c>
    3100:      	add	x11, x11, #0x1
    3104:      	cmp	w13, w12
    3108:      	b.eq	0x30c4 <filter_char_substring+0x94>
    310c:      	b	0x30ac <filter_char_substring+0x7c>
    3110:      	nop
    3114:      	nop
    3118:      	nop
    311c:      	nop
    3120:      	tbz	w8, #0x1f, 0x32c0 <filter_char_substring+0x290>
    3124:      	ldr	w9, [x19, #0x8]
    3128:      	add	w8, w29, #0xc
    312c:      	cmp	w8, w9
    3130:      	b.hs	0x32a4 <filter_char_substring+0x274>
    3134:      	add	x25, x25, #0x1
    3138:      	add	w29, w29, #0x4
    313c:      	cmp	x25, #0x64
    3140:      	b.ne	0x3080 <filter_char_substring+0x50>
    3144:      	b	0x32a4 <filter_char_substring+0x274>
    3148:      	cbz	w2, 0x325c <filter_char_substring+0x22c>
    314c:      	adrp	x22, 0x3000 <filter_file_type+0xd0>
    3150:      	mov	x25, xzr
    3154:      	mov	w29, wzr
    3158:      	ldr	x22, [x22]
    315c:      	add	x20, sp, #0xc
    3160:      	ldr	w8, [x23, x25, lsl #2]
    3164:      	add	x1, sp, #0xc
    3168:      	mov	x0, x22
    316c:      	str	w8, [sp, #0xc]
    3170:      	mov	w8, #0x1                // =1
    3174:      	blr	x8
    3178:      	cbz	x0, 0x32a8 <filter_char_substring+0x278>
    317c:      	mov	x8, xzr
    3180:      	mov	x9, x21
    3184:      	mov	x10, x24
    3188:      	b	0x31a0 <filter_char_substring+0x170>
    318c:      	add	x8, x8, #0x1
    3190:      	sub	x10, x10, #0x1
    3194:      	add	x9, x9, #0x1
    3198:      	cmp	x8, x24
    319c:      	b.eq	0x31e4 <filter_char_substring+0x1b4>
    31a0:      	mov	x11, xzr
    31a4:      	cmp	x10, x11
    31a8:      	b.eq	0x318c <filter_char_substring+0x15c>
    31ac:      	ldrb	w12, [x0, x11]
    31b0:      	cbz	w12, 0x31e0 <filter_char_substring+0x1b0>
    31b4:      	cmp	x11, #0x62
    31b8:      	b.hi	0x318c <filter_char_substring+0x15c>
    31bc:      	ldrb	w13, [x9, x11]
    31c0:      	add	x11, x11, #0x1
    31c4:      	cmp	w13, w12
    31c8:      	b.eq	0x31a4 <filter_char_substring+0x174>
    31cc:      	b	0x318c <filter_char_substring+0x15c>
    31d0:      	nop
    31d4:      	nop
    31d8:      	nop
    31dc:      	nop
    31e0:      	tbz	w8, #0x1f, 0x32c0 <filter_char_substring+0x290>
    31e4:      	ldr	w9, [x19, #0x8]
    31e8:      	add	w8, w29, #0xc
    31ec:      	cmp	w8, w9
    31f0:      	b.hs	0x32a4 <filter_char_substring+0x274>
    31f4:      	add	x25, x25, #0x1
    31f8:      	add	w29, w29, #0x4
    31fc:      	cmp	x25, #0x64
    3200:      	b.ne	0x3160 <filter_char_substring+0x130>
    3204:      	b	0x32a4 <filter_char_substring+0x274>
    3208:      	adrp	x20, 0x3000 <filter_file_type+0xd0>
    320c:      	mov	w21, #0x10              // =16
    3210:      	add	x22, sp, #0xc
    3214:      	ldr	x20, [x20]
    3218:      	nop
    321c:      	nop
    3220:      	ldr	w8, [x19, x21]
    3224:      	add	x1, sp, #0xc
    3228:      	mov	x0, x20
    322c:      	str	w8, [sp, #0xc]
    3230:      	mov	w8, #0x1                // =1
    3234:      	blr	x8
    3238:      	cbz	x0, 0x32a8 <filter_char_substring+0x278>
    323c:      	ldr	w8, [x19, #0x8]
    3240:      	add	x21, x21, #0x4
    3244:      	sub	w9, w21, #0x8
    3248:      	cmp	w9, w8
    324c:      	b.hs	0x32a4 <filter_char_substring+0x274>
    3250:      	cmp	x21, #0x1a0
    3254:      	b.ne	0x3220 <filter_char_substring+0x1f0>
    3258:      	b	0x32a4 <filter_char_substring+0x274>
    325c:      	adrp	x20, 0x3000 <filter_file_type+0xd0>
    3260:      	mov	w21, #0x10              // =16
    3264:      	add	x22, sp, #0xc
    3268:      	ldr	x20, [x20]
    326c:      	ldr	w8, [x19, x21]
    3270:      	add	x1, sp, #0xc
    3274:      	mov	x0, x20
    3278:      	str	w8, [sp, #0xc]
    327c:      	mov	w8, #0x1                // =1
    3280:      	blr	x8
    3284:      	cbz	x0, 0x32a8 <filter_char_substring+0x278>
    3288:      	ldr	w8, [x19, #0x8]
    328c:      	add	x21, x21, #0x4
    3290:      	sub	w9, w21, #0x8
    3294:      	cmp	w9, w8
    3298:      	b.hs	0x32a4 <filter_char_substring+0x274>
    329c:      	cmp	x21, #0x1a0
    32a0:      	b.ne	0x326c <filter_char_substring+0x23c>
    32a4:      	mov	x0, xzr
    32a8:      	ldp	x20, x19, [sp, #0x40]
    32ac:      	ldp	x22, x21, [sp, #0x30]
    32b0:      	ldp	x24, x23, [sp, #0x20]
    32b4:      	ldp	x30, x25, [sp, #0x10]
    32b8:      	ldr	x29, [sp], #0x50
    32bc:      	ret
    32c0:      	mov	w0, #0x1                // =1
    32c4:      	ldp	x20, x19, [sp, #0x40]
    32c8:      	ldp	x22, x21, [sp, #0x30]
    32cc:      	ldp	x24, x23, [sp, #0x20]
    32d0:      	ldp	x30, x25, [sp, #0x10]
    32d4:      	ldr	x29, [sp], #0x50
    32d8:      	ret
    32dc:      	nop

00000000000032e0 <do_action>:
    32e0:      	sub	sp, sp, #0xd0
    32e4:      	str	x29, [sp, #0x80]
    32e8:      	stp	x30, x25, [sp, #0x90]
    32ec:      	stp	x24, x23, [sp, #0xa0]
    32f0:      	stp	x22, x21, [sp, #0xb0]
    32f4:      	stp	x20, x19, [sp, #0xc0]
    32f8:      	add	x8, x2, w1, uxtw #2
    32fc:      	str	wzr, [sp, #0x44]
    3300:      	adrp	x24, 0x3000 <filter_file_type+0xd0>
    3304:      	add	x9, sp, #0x44
    3308:      	mov	w20, w1
    330c:      	ldrsw	x29, [x8, #0x4]
    3310:      	ldr	x24, [x24]
    3314:      	mov	w8, #0x1                // =1
    3318:      	mov	x19, x0
    331c:      	add	x1, sp, #0x44
    3320:      	mov	w25, w4
    3324:      	mov	x23, x3
    3328:      	mov	x21, x2
    332c:      	mov	x0, x24
    3330:      	blr	x8
    3334:      	cbz	x0, 0x3f1c <do_action+0xc3c>
    3338:      	mov	x22, x0
    333c:      	cmp	w29, #0x7
    3340:      	b.gt	0x3364 <do_action+0x84>
    3344:      	cmp	w29, #0x3
    3348:      	b.gt	0x33b0 <do_action+0xd0>
    334c:      	cmp	w29, #0x1
    3350:      	b.gt	0x34e8 <do_action+0x208>
    3354:      	cbz	w29, 0x376c <do_action+0x48c>
    3358:      	cmp	w29, #0x1
    335c:      	b.eq	0x34f8 <do_action+0x218>
    3360:      	b	0x3f14 <do_action+0xc34>
    3364:      	cmp	w29, #0xb
    3368:      	b.gt	0x34bc <do_action+0x1dc>
    336c:      	sub	w8, w29, #0xa
    3370:      	cmp	w8, #0x2
    3374:      	b.lo	0x35e8 <do_action+0x308>
    3378:      	cmp	w29, #0x8
    337c:      	b.eq	0x3634 <do_action+0x354>
    3380:      	cmp	w29, #0x9
    3384:      	b.ne	0x3f14 <do_action+0xc34>
    3388:      	add	w20, w20, #0x1
    338c:      	add	x8, x21, w20, uxtw #2
    3390:      	ldr	w0, [x8, #0x4]
    3394:      	tbz	w25, #0x0, 0x3818 <do_action+0x538>
    3398:      	sxtw	x8, w0
    339c:      	mov	w9, #0x6d               // =109
    33a0:      	blr	x9
    33a4:      	mov	w19, #0x2               // =2
    33a8:      	mov	w24, w20
    33ac:      	b	0x3ed4 <do_action+0xbf4>
    33b0:      	sub	w8, w29, #0x6
    33b4:      	cmp	w8, #0x2
    33b8:      	b.lo	0x3620 <do_action+0x340>
    33bc:      	cmp	w29, #0x4
    33c0:      	b.eq	0x363c <do_action+0x35c>
    33c4:      	cmp	w29, #0x5
    33c8:      	b.ne	0x3f14 <do_action+0xc34>
    33cc:      	add	w9, w20, #0x1
    33d0:      	add	x8, x21, #0x4
    33d4:      	add	w20, w20, #0x2
    33d8:      	ldr	w9, [x8, w9, uxtw #2]
    33dc:      	and	x9, x9, #0x7
    33e0:      	cmp	w9, #0x4
    33e4:      	b.hi	0x3f14 <do_action+0xc34>
    33e8:      	add	x10, x22, x9, lsl #2
    33ec:      	mov	w11, #0x5ea0            // =24224
    33f0:      	ldr	w10, [x10, x11]
    33f4:      	cbnz	w10, 0x3f14 <do_action+0xc34>
    33f8:      	ldr	w19, [x8, w20, uxtw #2]
    33fc:      	add	x8, x22, x9, lsl #3
    3400:      	ldr	x8, [x8, #0x5e78]
    3404:      	str	wzr, [sp, #0x54]
    3408:      	and	x8, x8, #0x7ff
    340c:      	add	x8, x22, x8
    3410:      	ldr	w8, [x8, #0x90]
    3414:      	str	w8, [sp, #0x50]
    3418:      	mov	w8, #0xe                // =14
    341c:      	blr	x8
    3420:      	lsr	x8, x0, #32
    3424:      	adrp	x21, 0x3000 <filter_file_type+0xd0>
    3428:      	add	x9, sp, #0x48
    342c:      	str	x8, [sp, #0x48]
    3430:      	mov	w8, #0x1                // =1
    3434:      	add	x1, sp, #0x48
    3438:      	ldr	x21, [x21]
    343c:      	mov	x0, x21
    3440:      	blr	x8
    3444:      	cbz	x0, 0x3f14 <do_action+0xc34>
    3448:      	and	x8, x19, #0x7
    344c:      	cmp	w8, #0x4
    3450:      	b.hi	0x3f14 <do_action+0xc34>
    3454:      	add	x9, x22, x8, lsl #2
    3458:      	mov	w10, #0x5ea0            // =24224
    345c:      	ldr	w9, [x9, x10]
    3460:      	cbnz	w9, 0x3f14 <do_action+0xc34>
    3464:      	add	x8, x22, x8, lsl #3
    3468:      	mov	x19, x22
    346c:      	ldr	x8, [x8, #0x5e78]
    3470:      	str	wzr, [sp, #0x54]
    3474:      	and	x8, x8, #0x7ff
    3478:      	add	x8, x22, x8
    347c:      	mov	x22, x0
    3480:      	ldr	w8, [x8, #0x90]
    3484:      	str	w8, [sp, #0x50]
    3488:      	mov	w8, #0xe                // =14
    348c:      	blr	x8
    3490:      	lsr	x8, x0, #32
    3494:      	mov	x3, xzr
    3498:      	add	x9, sp, #0x48
    349c:      	str	x8, [sp, #0x48]
    34a0:      	mov	w8, #0x2                // =2
    34a4:      	add	x1, sp, #0x48
    34a8:      	mov	x0, x21
    34ac:      	mov	x2, x22
    34b0:      	mov	x22, x19
    34b4:      	blr	x8
    34b8:      	b	0x3f14 <do_action+0xc34>
    34bc:      	cmp	w29, #0xc
    34c0:      	b.eq	0x3824 <do_action+0x544>
    34c4:      	cmp	w29, #0xd
    34c8:      	b.eq	0x36cc <do_action+0x3ec>
    34cc:      	cmp	w29, #0xe
    34d0:      	b.ne	0x3f14 <do_action+0xc34>
    34d4:      	tst	w25, #0x1
    34d8:      	mov	w8, #0x8                // =8
    34dc:      	add	w24, w20, #0x2
    34e0:      	cinc	x19, x8, eq
    34e4:      	b	0x3ed4 <do_action+0xbf4>
    34e8:      	cmp	w29, #0x2
    34ec:      	b.eq	0x3810 <do_action+0x530>
    34f0:      	cmp	w29, #0x3
    34f4:      	b.ne	0x3f14 <do_action+0xc34>
    34f8:      	add	w8, w20, #0x1
    34fc:      	add	x9, x21, #0x4
    3500:      	add	w20, w20, #0x2
    3504:      	str	wzr, [sp, #0x68]
    3508:      	ldr	w21, [x9, w8, uxtw #2]
    350c:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3510:      	ldr	w19, [x9, w20, uxtw #2]
    3514:      	ldr	x0, [x0]
    3518:      	mov	w8, #0x1                // =1
    351c:      	add	x9, sp, #0x68
    3520:      	add	x1, sp, #0x68
    3524:      	blr	x8
    3528:      	cbz	x0, 0x3614 <do_action+0x334>
    352c:      	and	x8, x21, #0x7
    3530:      	cmp	w8, #0x4
    3534:      	b.hi	0x3610 <do_action+0x330>
    3538:      	add	x9, x22, x8, lsl #2
    353c:      	mov	w10, #0x5ea0            // =24224
    3540:      	ldr	w9, [x9, x10]
    3544:      	cbnz	w9, 0x3610 <do_action+0x330>
    3548:      	add	x8, x22, x8, lsl #3
    354c:      	mov	x21, x0
    3550:      	ldr	x8, [x8, #0x5e78]
    3554:      	str	wzr, [sp, #0x54]
    3558:      	and	x8, x8, #0x7ff
    355c:      	add	x8, x22, x8
    3560:      	ldr	w8, [x8, #0x90]
    3564:      	str	w8, [sp, #0x50]
    3568:      	mov	w8, #0xe                // =14
    356c:      	blr	x8
    3570:      	lsr	x8, x0, #32
    3574:      	cmp	w29, #0x1
    3578:      	str	x8, [sp, #0x48]
    357c:      	b.ne	0x3ac4 <do_action+0x7e4>
    3580:      	and	x8, x19, #0x7
    3584:      	cmp	w8, #0x4
    3588:      	b.hi	0x3610 <do_action+0x330>
    358c:      	add	x9, x22, x8, lsl #2
    3590:      	mov	w10, #0x5ea0            // =24224
    3594:      	ldr	w9, [x9, x10]
    3598:      	cbnz	w9, 0x3610 <do_action+0x330>
    359c:      	add	x8, x22, x8, lsl #3
    35a0:      	mov	x0, x21
    35a4:      	ldr	x8, [x8, #0x5e78]
    35a8:      	and	x8, x8, #0x7ff
    35ac:      	add	x2, x22, x8
    35b0:      	ldr	w8, [x2, #0x90]!
    35b4:      	and	x8, x8, #0xfff
    35b8:      	add	x1, x8, #0x8
    35bc:      	mov	w8, #0x4                // =4
    35c0:      	blr	x8
    35c4:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    35c8:      	mov	x3, xzr
    35cc:      	mov	w8, #0x2                // =2
    35d0:      	ldr	x0, [x0]
    35d4:      	add	x9, sp, #0x48
    35d8:      	add	x1, sp, #0x48
    35dc:      	mov	x2, x21
    35e0:      	blr	x8
    35e4:      	b	0x3610 <do_action+0x330>
    35e8:      	add	w20, w20, #0x1
    35ec:      	add	x8, x21, w20, uxtw #2
    35f0:      	ldr	w8, [x8, #0x4]
    35f4:      	and	x8, x8, #0x7
    35f8:      	cmp	w8, #0x4
    35fc:      	b.hi	0x3610 <do_action+0x330>
    3600:      	add	x9, x22, x8, lsl #2
    3604:      	mov	w10, #0x5ea0            // =24224
    3608:      	ldr	w9, [x9, x10]
    360c:      	cbz	w9, 0x391c <do_action+0x63c>
    3610:      	mov	w0, wzr
    3614:      	cbz	w0, 0x3f14 <do_action+0xc34>
    3618:      	mov	w0, wzr
    361c:      	b	0x3f1c <do_action+0xc3c>
    3620:      	add	w20, w20, #0x1
    3624:      	add	x8, x21, w20, uxtw #2
    3628:      	ldr	w8, [x8, #0x4]
    362c:      	str	w8, [x22, #0x78]
    3630:      	b	0x3f14 <do_action+0xc34>
    3634:      	strb	wzr, [x23]
    3638:      	b	0x3f14 <do_action+0xc34>
    363c:      	add	w24, w20, #0x1
    3640:      	tbz	w25, #0x0, 0x390c <do_action+0x62c>
    3644:      	add	x8, x21, w24, uxtw #2
    3648:      	ldr	w19, [x8, #0x4]
    364c:      	mov	w8, #0xe                // =14
    3650:      	str	w19, [sp, #0x78]
    3654:      	blr	x8
    3658:      	str	x0, [sp, #0x68]
    365c:      	adrp	x21, 0x3000 <filter_file_type+0xd0>
    3660:      	mov	w8, #0x1                // =1
    3664:      	add	x9, sp, #0x68
    3668:      	ldr	x21, [x21]
    366c:      	add	x1, sp, #0x68
    3670:      	mov	x0, x21
    3674:      	blr	x8
    3678:      	cbz	x0, 0x3a24 <do_action+0x744>
    367c:      	mov	w8, #0x11               // =17
    3680:      	adrp	x21, 0x3000 <filter_file_type+0xd0>
    3684:      	mov	w9, #0x1                // =1
    3688:      	mov	x20, x0
    368c:      	add	x1, sp, #0x48
    3690:      	mov	x23, x22
    3694:      	mov	w22, #0x1               // =1
    3698:      	movk	w8, #0xe, lsl #16
    369c:      	str	w8, [sp, #0x48]
    36a0:      	mov	w8, #0x35c              // =860
    36a4:      	stur	x8, [sp, #0x4c]
    36a8:      	add	x8, sp, #0x48
    36ac:      	ldr	x21, [x21]
    36b0:      	mov	x0, x21
    36b4:      	blr	x9
    36b8:      	cbz	x0, 0x3ae0 <do_action+0x800>
    36bc:      	ldr	w8, [x0]
    36c0:      	add	w8, w8, #0x1
    36c4:      	str	w8, [x0]
    36c8:      	b	0x3b04 <do_action+0x824>
    36cc:      	mov	w8, #0xe                // =14
    36d0:      	blr	x8
    36d4:      	str	x0, [sp, #0x58]
    36d8:      	adrp	x21, 0x3000 <filter_file_type+0xd0>
    36dc:      	add	x8, sp, #0x58
    36e0:      	mov	w9, #0x1                // =1
    36e4:      	ldr	x21, [x21]
    36e8:      	add	x1, sp, #0x58
    36ec:      	mov	w19, #0x1               // =1
    36f0:      	mov	x0, x21
    36f4:      	blr	x9
    36f8:      	cbz	x0, 0x3f14 <do_action+0xc34>
    36fc:      	ldur	x8, [x0, #0x4]
    3700:      	mov	x25, x22
    3704:      	adrp	x22, 0x3000 <filter_file_type+0xd0>
    3708:      	mov	w9, #0x1                // =1
    370c:      	str	x8, [sp, #0x68]
    3710:      	mov	w8, #0x2                // =2
    3714:      	add	x1, sp, #0x68
    3718:      	str	w8, [sp, #0x70]
    371c:      	add	x8, sp, #0x68
    3720:      	ldr	x22, [x22]
    3724:      	mov	x0, x22
    3728:      	blr	x9
    372c:      	str	w19, [sp, #0x8c]
    3730:      	cbz	x0, 0x39a8 <do_action+0x6c8>
    3734:      	nop
    3738:      	nop
    373c:      	nop
    3740:      	ldaxr	w8, [x0]
    3744:      	add	w8, w8, #0x1
    3748:      	stlxr	w9, w8, [x0]
    374c:      	cbnz	w9, 0x3740 <do_action+0x460>
    3750:      	mov	w8, #0x3                // =3
    3754:      	add	x9, sp, #0x58
    3758:      	add	x1, sp, #0x58
    375c:      	mov	x0, x21
    3760:      	blr	x8
    3764:      	mov	x22, x25
    3768:      	b	0x3f14 <do_action+0xc34>
    376c:      	add	w8, w20, #0x1
    3770:      	add	x9, x21, #0x4
    3774:      	str	x19, [sp, #0x30]
    3778:      	ldr	w25, [x9, w8, uxtw #2]
    377c:      	add	w8, w20, #0x2
    3780:      	ldr	w19, [x9, w8, uxtw #2]
    3784:      	mov	w8, #0x7d               // =125
    3788:      	blr	x8
    378c:      	str	x0, [sp, #0x8]
    3790:      	str	x0, [sp, #0x48]
    3794:      	str	wzr, [sp, #0x58]
    3798:      	cbz	w25, 0x3da0 <do_action+0xac0>
    379c:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    37a0:      	mov	w8, #0x1                // =1
    37a4:      	add	x9, sp, #0x58
    37a8:      	ldr	x0, [x0]
    37ac:      	add	x1, sp, #0x58
    37b0:      	blr	x8
    37b4:      	cbz	x0, 0x3da0 <do_action+0xac0>
    37b8:      	mov	x10, x0
    37bc:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    37c0:      	mov	w8, #0x1                // =1
    37c4:      	ldr	x0, [x0]
    37c8:      	add	x9, sp, #0x58
    37cc:      	add	x1, sp, #0x58
    37d0:      	str	x10, [sp, #0x10]
    37d4:      	blr	x8
    37d8:      	ldr	x9, [sp, #0x10]
    37dc:      	ldr	x8, [x22, #0x60]
    37e0:      	mov	x2, x0
    37e4:      	cmp	w19, #0x2
    37e8:      	str	x8, [x9]
    37ec:      	ldr	x8, [x22, #0x70]
    37f0:      	str	x8, [x9, #0x8]
    37f4:      	b.eq	0x3bb8 <do_action+0x8d8>
    37f8:      	cmp	w19, #0x1
    37fc:      	b.eq	0x3bac <do_action+0x8cc>
    3800:      	cbnz	w19, 0x3da0 <do_action+0xac0>
    3804:      	ldr	w8, [x22, #0x7c]
    3808:      	str	x25, [sp]
    380c:      	b	0x3bc0 <do_action+0x8e0>
    3810:      	mov	w0, #0x9                // =9
    3814:      	tbnz	w25, #0x0, 0x3398 <do_action+0xb8>
    3818:      	mov	w19, #0x3               // =3
    381c:      	mov	w24, w20
    3820:      	b	0x3ed4 <do_action+0xbf4>
    3824:      	add	w24, w20, #0x3
    3828:      	tbz	w25, #0x0, 0x3914 <do_action+0x634>
    382c:      	add	x9, x21, #0x4
    3830:      	add	w10, w20, #0x2
    3834:      	ldr	w8, [x9, w24, uxtw #2]
    3838:      	ldr	w19, [x9, w10, uxtw #2]
    383c:      	add	w10, w20, #0x1
    3840:      	ldr	w20, [x9, w10, uxtw #2]
    3844:      	cmp	w8, #0x4
    3848:      	b.hi	0x385c <do_action+0x57c>
    384c:      	add	x9, x22, x8, lsl #2
    3850:      	mov	w10, #0x5ea0            // =24224
    3854:      	ldr	w9, [x9, x10]
    3858:      	cbz	w9, 0x3e38 <do_action+0xb58>
    385c:      	mov	x8, xzr
    3860:      	ldr	w9, [x22, #0x60]
    3864:      	orr	x21, x9, x8
    3868:      	mov	w8, #0xe                // =14
    386c:      	blr	x8
    3870:      	str	x0, [sp, #0x78]
    3874:      	strh	w20, [sp, #0x68]
    3878:      	add	x8, sp, #0x78
    387c:      	mov	w9, #0x1                // =1
    3880:      	add	x1, sp, #0x78
    3884:      	strh	w19, [sp, #0x6a]
    3888:      	stur	x21, [sp, #0x6c]
    388c:      	adrp	x21, 0x3000 <filter_file_type+0xd0>
    3890:      	ldr	x21, [x21]
    3894:      	mov	w19, #0x1               // =1
    3898:      	mov	x0, x21
    389c:      	blr	x9
    38a0:      	cbz	x0, 0x3a4c <do_action+0x76c>
    38a4:      	ldur	x8, [x0, #0x4]
    38a8:      	str	w19, [sp, #0x60]
    38ac:      	adrp	x21, 0x3000 <filter_file_type+0xd0>
    38b0:      	mov	w9, #0x1                // =1
    38b4:      	mov	x20, x0
    38b8:      	add	x1, sp, #0x58
    38bc:      	str	x8, [sp, #0x58]
    38c0:      	add	x8, sp, #0x58
    38c4:      	ldr	x21, [x21]
    38c8:      	mov	x0, x21
    38cc:      	blr	x9
    38d0:      	mov	x25, x22
    38d4:      	str	w19, [sp, #0x88]
    38d8:      	cbz	x0, 0x3b30 <do_action+0x850>
    38dc:      	nop
    38e0:      	ldaxr	w8, [x0]
    38e4:      	add	w8, w8, #0x1
    38e8:      	stlxr	w9, w8, [x0]
    38ec:      	cbnz	w9, 0x38e0 <do_action+0x600>
    38f0:      	ldr	x8, [sp, #0x68]
    38f4:      	ldr	w9, [sp, #0x70]
    38f8:      	mov	x22, x25
    38fc:      	mov	w19, #0x6               // =6
    3900:      	str	w9, [x20, #0x8]
    3904:      	str	x8, [x20]
    3908:      	b	0x3ed4 <do_action+0xbf4>
    390c:      	mov	w19, #0x5               // =5
    3910:      	b	0x3ed4 <do_action+0xbf4>
    3914:      	mov	w19, #0x7               // =7
    3918:      	b	0x3ed4 <do_action+0xbf4>
    391c:      	add	x8, x22, x8, lsl #3
    3920:      	ldr	x8, [x8, #0x5e78]
    3924:      	and	x8, x8, #0x7ff
    3928:      	add	x8, x22, x8
    392c:      	ldr	x8, [x8, #0xb8]
    3930:      	str	x8, [sp, #0x68]
    3934:      	cbz	x8, 0x3610 <do_action+0x330>
    3938:      	cmp	w29, #0xa
    393c:      	b.ne	0x3b14 <do_action+0x834>
    3940:      	mov	w8, #0xe                // =14
    3944:      	blr	x8
    3948:      	lsr	x8, x0, #32
    394c:      	mov	x21, x0
    3950:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3954:      	str	w8, [sp, #0x48]
    3958:      	mov	w8, #0x1                // =1
    395c:      	add	x9, sp, #0x48
    3960:      	add	x1, sp, #0x48
    3964:      	ldr	x0, [x0]
    3968:      	blr	x8
    396c:      	cbz	x0, 0x3614 <do_action+0x334>
    3970:      	ldr	w8, [x0]
    3974:      	mov	x3, xzr
    3978:      	add	x9, sp, #0x68
    397c:      	add	x10, sp, #0x48
    3980:      	stp	w8, w21, [sp, #0x48]
    3984:      	ldr	x8, [x0, #0x8]
    3988:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    398c:      	add	x1, sp, #0x68
    3990:      	add	x2, sp, #0x48
    3994:      	str	x8, [sp, #0x50]
    3998:      	mov	w8, #0x2                // =2
    399c:      	ldr	x0, [x0]
    39a0:      	blr	x8
    39a4:      	b	0x3610 <do_action+0x330>
    39a8:      	mov	w8, #0x1                // =1
    39ac:      	mov	w9, #0x2                // =2
    39b0:      	add	x10, sp, #0x68
    39b4:      	add	x11, sp, #0x8c
    39b8:      	add	x1, sp, #0x68
    39bc:      	add	x2, sp, #0x8c
    39c0:      	mov	x0, x22
    39c4:      	mov	w3, #0x1                // =1
    39c8:      	blr	x9
    39cc:      	cbz	x0, 0x3750 <do_action+0x470>
    39d0:      	mov	x23, x0
    39d4:      	adrp	x24, 0x3000 <filter_file_type+0xd0>
    39d8:      	mov	w9, #0x1                // =1
    39dc:      	add	x1, sp, #0x48
    39e0:      	mov	w19, #0x1               // =1
    39e4:      	neg	w8, w23
    39e8:      	strh	w8, [sp, #0x48]
    39ec:      	mov	w8, #0x3                // =3
    39f0:      	strh	w8, [sp, #0x4a]
    39f4:      	mov	x8, #0x3b               // =59
    39f8:      	movk	x8, #0x2, lsl #32
    39fc:      	stur	x8, [sp, #0x4c]
    3a00:      	add	x8, sp, #0x48
    3a04:      	ldr	x24, [x24]
    3a08:      	mov	x0, x24
    3a0c:      	blr	x9
    3a10:      	cbz	x0, 0x3e54 <do_action+0xb74>
    3a14:      	ldr	w8, [x0]
    3a18:      	add	w8, w8, #0x1
    3a1c:      	str	w8, [x0]
    3a20:      	b	0x3e78 <do_action+0xb98>
    3a24:      	mov	x3, xzr
    3a28:      	mov	w8, #0x2                // =2
    3a2c:      	add	x9, sp, #0x68
    3a30:      	add	x10, sp, #0x78
    3a34:      	add	x1, sp, #0x68
    3a38:      	add	x2, sp, #0x78
    3a3c:      	mov	x0, x21
    3a40:      	blr	x8
    3a44:      	mov	w19, #0x4               // =4
    3a48:      	b	0x3ed4 <do_action+0xbf4>
    3a4c:      	mov	x3, xzr
    3a50:      	mov	w8, #0x2                // =2
    3a54:      	add	x9, sp, #0x78
    3a58:      	add	x10, sp, #0x68
    3a5c:      	add	x1, sp, #0x78
    3a60:      	add	x2, sp, #0x68
    3a64:      	mov	x0, x21
    3a68:      	blr	x8
    3a6c:      	cbz	x0, 0x3ed0 <do_action+0xbf0>
    3a70:      	neg	w8, w0
    3a74:      	adrp	x20, 0x3000 <filter_file_type+0xd0>
    3a78:      	mov	w9, #0x1                // =1
    3a7c:      	strh	w8, [sp, #0x48]
    3a80:      	mov	w8, #0x3                // =3
    3a84:      	add	x1, sp, #0x48
    3a88:      	mov	w19, #0x1               // =1
    3a8c:      	strh	w8, [sp, #0x4a]
    3a90:      	mov	x8, #0x6b               // =107
    3a94:      	movk	x8, #0x2, lsl #32
    3a98:      	stur	x8, [sp, #0x4c]
    3a9c:      	add	x8, sp, #0x48
    3aa0:      	ldr	x20, [x20]
    3aa4:      	mov	x0, x20
    3aa8:      	blr	x9
    3aac:      	cbz	x0, 0x3eac <do_action+0xbcc>
    3ab0:      	ldr	w8, [x0]
    3ab4:      	mov	w19, #0x6               // =6
    3ab8:      	add	w8, w8, #0x1
    3abc:      	str	w8, [x0]
    3ac0:      	b	0x3ed4 <do_action+0xbf4>
    3ac4:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3ac8:      	mov	w8, #0x3                // =3
    3acc:      	add	x9, sp, #0x48
    3ad0:      	ldr	x0, [x0]
    3ad4:      	add	x1, sp, #0x48
    3ad8:      	blr	x8
    3adc:      	b	0x3614 <do_action+0x334>
    3ae0:      	str	w22, [sp, #0x58]
    3ae4:      	mov	x3, xzr
    3ae8:      	mov	w8, #0x2                // =2
    3aec:      	add	x9, sp, #0x48
    3af0:      	add	x10, sp, #0x58
    3af4:      	add	x1, sp, #0x48
    3af8:      	add	x2, sp, #0x58
    3afc:      	mov	x0, x21
    3b00:      	blr	x8
    3b04:      	str	w19, [x20]
    3b08:      	mov	x22, x23
    3b0c:      	mov	w19, #0x4               // =4
    3b10:      	b	0x3ed4 <do_action+0xbf4>
    3b14:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3b18:      	mov	w8, #0x3                // =3
    3b1c:      	add	x9, sp, #0x68
    3b20:      	ldr	x0, [x0]
    3b24:      	add	x1, sp, #0x68
    3b28:      	blr	x8
    3b2c:      	b	0x3614 <do_action+0x334>
    3b30:      	mov	w8, #0x1                // =1
    3b34:      	mov	w9, #0x2                // =2
    3b38:      	add	x10, sp, #0x58
    3b3c:      	add	x11, sp, #0x88
    3b40:      	add	x1, sp, #0x58
    3b44:      	add	x2, sp, #0x88
    3b48:      	mov	x0, x21
    3b4c:      	mov	w3, #0x1                // =1
    3b50:      	blr	x9
    3b54:      	cbz	x0, 0x38f0 <do_action+0x610>
    3b58:      	mov	x22, x0
    3b5c:      	adrp	x23, 0x3000 <filter_file_type+0xd0>
    3b60:      	mov	w9, #0x1                // =1
    3b64:      	add	x1, sp, #0x48
    3b68:      	mov	w19, #0x1               // =1
    3b6c:      	neg	w8, w22
    3b70:      	strh	w8, [sp, #0x48]
    3b74:      	mov	w8, #0x3                // =3
    3b78:      	strh	w8, [sp, #0x4a]
    3b7c:      	mov	x8, #0x3b               // =59
    3b80:      	movk	x8, #0x2, lsl #32
    3b84:      	stur	x8, [sp, #0x4c]
    3b88:      	add	x8, sp, #0x48
    3b8c:      	ldr	x23, [x23]
    3b90:      	mov	x0, x23
    3b94:      	blr	x9
    3b98:      	cbz	x0, 0x3f38 <do_action+0xc58>
    3b9c:      	ldr	w8, [x0]
    3ba0:      	add	w8, w8, #0x1
    3ba4:      	str	w8, [x0]
    3ba8:      	b	0x3f5c <do_action+0xc7c>
    3bac:      	ldr	w8, [x22, #0x10]
    3bb0:      	str	x25, [sp]
    3bb4:      	b	0x3bc0 <do_action+0x8e0>
    3bb8:      	str	x25, [sp]
    3bbc:      	mov	w8, wzr
    3bc0:      	mov	w8, w8
    3bc4:      	add	x0, x9, #0x18
    3bc8:      	mov	w1, #0xc8               // =200
    3bcc:      	str	x8, [x9, #0x10]
    3bd0:      	mov	w8, #0xc8               // =200
    3bd4:      	mov	w9, #0x4                // =4
    3bd8:      	str	x0, [sp, #0x18]
    3bdc:      	blr	x9
    3be0:      	ldr	x19, [sp, #0x30]
    3be4:      	mov	w8, #0x5e78             // =24184
    3be8:      	mov	x25, xzr
    3bec:      	str	wzr, [sp, #0x2c]
    3bf0:      	add	x10, x22, x8
    3bf4:      	str	x29, [sp, #0x20]
    3bf8:      	b	0x3c0c <do_action+0x92c>
    3bfc:      	add	x25, x25, #0x4
    3c00:      	add	x10, x10, #0x8
    3c04:      	cmp	x25, #0x14
    3c08:      	b.eq	0x3d44 <do_action+0xa64>
    3c0c:      	str	x10, [sp, #0x38]
    3c10:      	str	wzr, [sp, #0x68]
    3c14:      	mov	w8, #0x1                // =1
    3c18:      	add	x9, sp, #0x68
    3c1c:      	add	x1, sp, #0x68
    3c20:      	mov	x0, x24
    3c24:      	blr	x8
    3c28:      	cbz	x0, 0x3d44 <do_action+0xa64>
    3c2c:      	mov	w8, #0x5ef8             // =24312
    3c30:      	add	x1, x0, x8
    3c34:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3c38:      	mov	w8, #0x1                // =1
    3c3c:      	ldr	x0, [x0]
    3c40:      	blr	x8
    3c44:      	cbz	x0, 0x3d44 <do_action+0xa64>
    3c48:      	add	x8, x0, x25
    3c4c:      	ldr	x10, [sp, #0x38]
    3c50:      	ldr	w8, [x8, #0x40]
    3c54:      	cmn	w8, #0x1
    3c58:      	b.eq	0x3d44 <do_action+0xa64>
    3c5c:      	ldr	x8, [x10]
    3c60:      	ldr	w9, [x22, #0x4]
    3c64:      	cmp	x8, x9
    3c68:      	b.ge	0x3d44 <do_action+0xa64>
    3c6c:      	cmp	x25, #0x10
    3c70:      	b.eq	0x3cd8 <do_action+0x9f8>
    3c74:      	str	wzr, [sp, #0x68]
    3c78:      	mov	w8, #0x1                // =1
    3c7c:      	add	x9, sp, #0x68
    3c80:      	add	x1, sp, #0x68
    3c84:      	mov	x0, x24
    3c88:      	blr	x8
    3c8c:      	cbz	x0, 0x3cd0 <do_action+0x9f0>
    3c90:      	mov	w8, #0x5ef8             // =24312
    3c94:      	add	x1, x0, x8
    3c98:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3c9c:      	mov	w8, #0x1                // =1
    3ca0:      	ldr	x0, [x0]
    3ca4:      	blr	x8
    3ca8:      	cbz	x0, 0x3cd0 <do_action+0x9f0>
    3cac:      	ldr	x10, [sp, #0x38]
    3cb0:      	add	x8, x0, x25
    3cb4:      	ldr	w9, [x8, #0x44]
    3cb8:      	ldr	x8, [x10]
    3cbc:      	cmn	w9, #0x1
    3cc0:      	b.eq	0x3cd8 <do_action+0x9f8>
    3cc4:      	ldr	w9, [x10, #0x8]
    3cc8:      	sub	w9, w9, w8
    3ccc:      	b	0x3ce4 <do_action+0xa04>
    3cd0:      	ldr	x10, [sp, #0x38]
    3cd4:      	ldr	x8, [x10]
    3cd8:      	ldr	w9, [x22, #0x4]
    3cdc:      	sub	w9, w9, w8
    3ce0:      	add	w9, w9, #0x4
    3ce4:      	cmp	w9, #0x1
    3ce8:      	b.lt	0x3bfc <do_action+0x91c>
    3cec:      	mov	w10, #0x3ffc            // =16380
    3cf0:      	cmp	w9, #0x28
    3cf4:      	mov	x19, x22
    3cf8:      	add	w8, w8, w10
    3cfc:      	mov	w10, #0x28              // =40
    3d00:      	csel	w29, w9, w10, lt
    3d04:      	ldr	w9, [sp, #0x2c]
    3d08:      	and	x8, x8, #0x3fff
    3d0c:      	add	x8, x22, x8
    3d10:      	mov	w1, w29
    3d14:      	add	x2, x8, #0x90
    3d18:      	mov	w8, #0x4                // =4
    3d1c:      	and	w22, w9, #0xff
    3d20:      	ldr	x9, [sp, #0x18]
    3d24:      	add	x0, x9, x22
    3d28:      	blr	x8
    3d2c:      	add	w8, w29, w22
    3d30:      	mov	x22, x19
    3d34:      	ldp	x19, x10, [sp, #0x30]
    3d38:      	ldr	x29, [sp, #0x20]
    3d3c:      	str	w8, [sp, #0x2c]
    3d40:      	b	0x3bfc <do_action+0x91c>
    3d44:      	adrp	x24, 0x3000 <filter_file_type+0xd0>
    3d48:      	mov	w8, #0x1                // =1
    3d4c:      	ldr	x24, [x24]
    3d50:      	ldr	x1, [sp, #0x10]
    3d54:      	mov	x0, x24
    3d58:      	blr	x8
    3d5c:      	cbz	x0, 0x3d84 <do_action+0xaa4>
    3d60:      	ldp	x10, x11, [sp]
    3d64:      	mov	x9, #-0x4240            // =-16960
    3d68:      	movk	x9, #0xfff0, lsl #16
    3d6c:      	ldr	x8, [x0]
    3d70:      	madd	x9, x10, x9, x11
    3d74:      	cmp	x8, x9
    3d78:      	b.ls	0x3d84 <do_action+0xaa4>
    3d7c:      	strb	wzr, [x23]
    3d80:      	b	0x3da4 <do_action+0xac4>
    3d84:      	ldr	x1, [sp, #0x10]
    3d88:      	mov	x3, xzr
    3d8c:      	mov	w8, #0x2                // =2
    3d90:      	add	x9, sp, #0x48
    3d94:      	add	x2, sp, #0x48
    3d98:      	mov	x0, x24
    3d9c:      	blr	x8
    3da0:      	ldr	x19, [sp, #0x30]
    3da4:      	add	w8, w20, #0x3
    3da8:      	adrp	x23, 0x3000 <filter_file_type+0xd0>
    3dac:      	add	x8, x21, w8, uxtw #2
    3db0:      	ldr	w8, [x8, #0x4]
    3db4:      	ldr	x23, [x23]
    3db8:      	cbz	w8, 0x3de0 <do_action+0xb00>
    3dbc:      	ldrb	w8, [x22, #0x1]
    3dc0:      	mov	x2, xzr
    3dc4:      	mov	x0, x19
    3dc8:      	mov	x1, x23
    3dcc:      	orr	w8, w8, #0x2
    3dd0:      	strb	w8, [x22, #0x1]
    3dd4:      	mov	w8, #0x1b               // =27
    3dd8:      	blr	x8
    3ddc:      	str	x0, [x22, #0x80]
    3de0:      	add	w8, w20, #0x4
    3de4:      	add	x8, x21, w8, uxtw #2
    3de8:      	ldr	w8, [x8, #0x4]
    3dec:      	cbz	w8, 0x3e18 <do_action+0xb38>
    3df0:      	ldrb	w8, [x22, #0x1]
    3df4:      	mov	w9, #0x1b               // =27
    3df8:      	mov	x0, x19
    3dfc:      	mov	x1, x23
    3e00:      	mov	w2, #0x100              // =256
    3e04:      	orr	w8, w8, #0x4
    3e08:      	strb	w8, [x22, #0x1]
    3e0c:      	mov	w8, #0x100              // =256
    3e10:      	blr	x9
    3e14:      	str	x0, [x22, #0x88]
    3e18:      	add	w20, w20, #0x5
    3e1c:      	add	x8, x21, w20, uxtw #2
    3e20:      	ldr	w8, [x8, #0x4]
    3e24:      	cbz	w8, 0x3f14 <do_action+0xc34>
    3e28:      	ldrb	w8, [x22, #0x1]
    3e2c:      	orr	w8, w8, #0x8
    3e30:      	strb	w8, [x22, #0x1]
    3e34:      	b	0x3f14 <do_action+0xc34>
    3e38:      	add	x8, x22, x8, lsl #3
    3e3c:      	ldr	x8, [x8, #0x5e78]
    3e40:      	and	x8, x8, #0x7ff
    3e44:      	add	x8, x22, x8
    3e48:      	ldr	x8, [x8, #0x90]
    3e4c:      	lsl	x8, x8, #32
    3e50:      	b	0x3860 <do_action+0x580>
    3e54:      	str	w19, [sp, #0x78]
    3e58:      	mov	x3, xzr
    3e5c:      	mov	w8, #0x2                // =2
    3e60:      	add	x9, sp, #0x48
    3e64:      	add	x10, sp, #0x78
    3e68:      	add	x1, sp, #0x48
    3e6c:      	add	x2, sp, #0x78
    3e70:      	mov	x0, x24
    3e74:      	blr	x8
    3e78:      	cbz	w23, 0x3750 <do_action+0x470>
    3e7c:      	mov	w8, #0x1                // =1
    3e80:      	add	x9, sp, #0x68
    3e84:      	add	x1, sp, #0x68
    3e88:      	mov	x0, x22
    3e8c:      	blr	x8
    3e90:      	cbz	x0, 0x3750 <do_action+0x470>
    3e94:      	ldr	w8, [sp, #0x8c]
    3e98:      	ldaxr	w9, [x0]
    3e9c:      	add	w9, w9, w8
    3ea0:      	stlxr	w10, w9, [x0]
    3ea4:      	cbnz	w10, 0x3e98 <do_action+0xbb8>
    3ea8:      	b	0x3750 <do_action+0x470>
    3eac:      	str	w19, [sp, #0x58]
    3eb0:      	mov	x3, xzr
    3eb4:      	mov	w8, #0x2                // =2
    3eb8:      	add	x9, sp, #0x48
    3ebc:      	add	x10, sp, #0x58
    3ec0:      	add	x1, sp, #0x48
    3ec4:      	add	x2, sp, #0x58
    3ec8:      	mov	x0, x20
    3ecc:      	blr	x8
    3ed0:      	mov	w19, #0x6               // =6
    3ed4:      	str	wzr, [sp, #0x48]
    3ed8:      	adrp	x0, 0x3000 <filter_file_type+0xd0>
    3edc:      	mov	w8, #0x1                // =1
    3ee0:      	add	x9, sp, #0x48
    3ee4:      	ldr	x0, [x0]
    3ee8:      	add	x1, sp, #0x48
    3eec:      	blr	x8
    3ef0:      	cbz	x0, 0x3f10 <do_action+0xc30>
    3ef4:      	add	x8, x0, x19, lsl #3
    3ef8:      	nop
    3efc:      	nop
    3f00:      	ldaxr	x9, [x8]
    3f04:      	add	x9, x9, #0x1
    3f08:      	stlxr	w10, x9, [x8]
    3f0c:      	cbnz	w10, 0x3f00 <do_action+0xc20>
    3f10:      	mov	w20, w24
    3f14:      	add	w0, w20, #0x1
    3f18:      	str	x29, [x22, #0x70]
    3f1c:      	ldp	x20, x19, [sp, #0xc0]
    3f20:      	ldr	x29, [sp, #0x80]
    3f24:      	ldp	x22, x21, [sp, #0xb0]
    3f28:      	ldp	x24, x23, [sp, #0xa0]
    3f2c:      	ldp	x30, x25, [sp, #0x90]
    3f30:      	add	sp, sp, #0xd0
    3f34:      	ret
    3f38:      	str	w19, [sp, #0x8c]
    3f3c:      	mov	x3, xzr
    3f40:      	mov	w8, #0x2                // =2
    3f44:      	add	x9, sp, #0x48
    3f48:      	add	x10, sp, #0x8c
    3f4c:      	add	x1, sp, #0x48
    3f50:      	add	x2, sp, #0x8c
    3f54:      	mov	x0, x23
    3f58:      	blr	x8
    3f5c:      	cbz	w22, 0x38f0 <do_action+0x610>
    3f60:      	mov	w8, #0x1                // =1
    3f64:      	add	x9, sp, #0x58
    3f68:      	add	x1, sp, #0x58
    3f6c:      	mov	x0, x21
    3f70:      	blr	x8
    3f74:      	cbz	x0, 0x38f0 <do_action+0x610>
    3f78:      	ldr	w8, [sp, #0x88]
    3f7c:      	ldaxr	w9, [x0]
    3f80:      	add	w9, w9, w8
    3f84:      	stlxr	w10, w9, [x0]
    3f88:      	cbnz	w10, 0x3f7c <do_action+0xc9c>
    3f8c:      	b	0x38f0 <do_action+0x610>

Disassembly of section kprobe:

0000000000000000 <generic_kprobe_setup_event>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	x30, x25, [sp, #0x40]
       8:      	stp	x24, x23, [sp, #0x50]
       c:      	stp	x22, x21, [sp, #0x60]
      10:      	stp	x20, x19, [sp, #0x70]
      14:      	str	wzr, [sp, #0x4]
      18:      	adrp	x20, 0x0 <generic_kprobe_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x4
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x4
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x344 <generic_kprobe_setup_event+0x344>
      3c:      	adrp	x21, 0x0 <generic_kprobe_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x344 <generic_kprobe_setup_event+0x344>
      60:      	ldr	w8, [x0, #0x54]
      64:      	mov	x23, x0
      68:      	cbz	w8, 0x104 <generic_kprobe_setup_event+0x104>
      6c:      	cbz	x19, 0x344 <generic_kprobe_setup_event+0x344>
      70:      	add	x2, x19, #0x110
      74:      	mov	w25, #0x8               // =8
      78:      	add	x8, sp, #0x18
      7c:      	mov	w9, #0x4                // =4
      80:      	add	x0, sp, #0x18
      84:      	mov	w1, #0x8                // =8
      88:      	mov	w24, #0x4               // =4
      8c:      	blr	x9
      90:      	ldr	x8, [sp, #0x18]
      94:      	add	x2, x19, #0x8
      98:      	mov	w9, #0x4                // =4
      9c:      	add	x0, sp, #0x18
      a0:      	str	x8, [x22, #0x5e50]
      a4:      	add	x8, sp, #0x18
      a8:      	mov	w1, #0x8                // =8
      ac:      	blr	x9
      b0:      	ldr	x8, [sp, #0x18]
      b4:      	add	x2, x19, #0x10
      b8:      	mov	w9, #0x4                // =4
      bc:      	add	x0, sp, #0x18
      c0:      	str	x8, [x22, #0x5e58]
      c4:      	add	x8, sp, #0x18
      c8:      	mov	w1, #0x8                // =8
      cc:      	blr	x9
      d0:      	ldr	x8, [sp, #0x18]
      d4:      	add	x2, x19, #0x18
      d8:      	mov	w9, #0x4                // =4
      dc:      	add	x0, sp, #0x18
      e0:      	str	x8, [x22, #0x5e60]
      e4:      	add	x8, sp, #0x18
      e8:      	mov	w1, #0x8                // =8
      ec:      	blr	x9
      f0:      	ldr	x8, [sp, #0x18]
      f4:      	add	x2, x19, #0x20
      f8:      	str	x8, [x22, #0x5e68]
      fc:      	add	x8, sp, #0x18
     100:      	b	0x194 <generic_kprobe_setup_event+0x194>
     104:      	mov	w25, #0x8               // =8
     108:      	add	x8, sp, #0x18
     10c:      	mov	w9, #0x4                // =4
     110:      	add	x0, sp, #0x18
     114:      	mov	w1, #0x8                // =8
     118:      	mov	x2, x19
     11c:      	mov	w24, #0x4               // =4
     120:      	blr	x9
     124:      	ldr	x8, [sp, #0x18]
     128:      	add	x2, x19, #0x8
     12c:      	mov	w9, #0x4                // =4
     130:      	add	x0, sp, #0x18
     134:      	str	x8, [x22, #0x5e50]
     138:      	add	x8, sp, #0x18
     13c:      	mov	w1, #0x8                // =8
     140:      	blr	x9
     144:      	ldr	x8, [sp, #0x18]
     148:      	add	x2, x19, #0x10
     14c:      	mov	w9, #0x4                // =4
     150:      	add	x0, sp, #0x18
     154:      	str	x8, [x22, #0x5e58]
     158:      	add	x8, sp, #0x18
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x9
     164:      	ldr	x8, [sp, #0x18]
     168:      	add	x2, x19, #0x18
     16c:      	mov	w9, #0x4                // =4
     170:      	add	x0, sp, #0x18
     174:      	str	x8, [x22, #0x5e60]
     178:      	add	x8, sp, #0x18
     17c:      	mov	w1, #0x8                // =8
     180:      	blr	x9
     184:      	ldr	x8, [sp, #0x18]
     188:      	add	x2, x19, #0x20
     18c:      	str	x8, [x22, #0x5e68]
     190:      	add	x8, sp, #0x18
     194:      	add	x0, sp, #0x18
     198:      	mov	w1, #0x8                // =8
     19c:      	blr	x24
     1a0:      	ldr	x8, [sp, #0x18]
     1a4:      	strh	wzr, [x22, #0x2]
     1a8:      	str	wzr, [x22, #0x4]
     1ac:      	str	x8, [x22, #0x5e70]
     1b0:      	mov	w8, #0xd                // =13
     1b4:      	strb	w8, [x22]
     1b8:      	mov	w8, #0x7d               // =125
     1bc:      	blr	x8
     1c0:      	str	x0, [x22, #0x8]
     1c4:      	str	xzr, [x22, #0x70]
     1c8:      	mov	w8, #0xe                // =14
     1cc:      	mov	w24, #0xe               // =14
     1d0:      	str	wzr, [x22, #0x14]
     1d4:      	blr	x8
     1d8:      	str	w0, [x22, #0x7c]
     1dc:      	blr	x24
     1e0:      	cmn	x0, #0x16
     1e4:      	b.ne	0x208 <generic_kprobe_setup_event+0x208>
     1e8:      	add	x2, x19, #0xe8
     1ec:      	mov	w8, #0x8                // =8
     1f0:      	mov	w9, #0x4                // =4
     1f4:      	add	x10, sp, #0x18
     1f8:      	add	x0, sp, #0x18
     1fc:      	mov	w1, #0x8                // =8
     200:      	blr	x9
     204:      	ldr	x0, [sp, #0x18]
     208:      	str	x0, [x22, #0x68]
     20c:      	ldr	w8, [x23, #0x5c]
     210:      	cmp	w8, #0x1
     214:      	b.lt	0x2cc <generic_kprobe_setup_event+0x2cc>
     218:      	ldr	x8, [x22, #0x60]
     21c:      	ldr	x9, [x22, #0x8]
     220:      	mov	w10, #0x1               // =1
     224:      	mov	x3, xzr
     228:      	add	x1, sp, #0x8
     22c:      	add	x2, sp, #0x18
     230:      	str	xzr, [sp, #0x28]
     234:      	stp	x9, x10, [sp, #0x18]
     238:      	stp	x8, x0, [sp, #0x8]
     23c:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     240:      	mov	w8, #0x2                // =2
     244:      	add	x9, sp, #0x8
     248:      	add	x10, sp, #0x18
     24c:      	ldr	x0, [x0]
     250:      	blr	x8
     254:      	cbz	x0, 0x2cc <generic_kprobe_setup_event+0x2cc>
     258:      	neg	w8, w0
     25c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     260:      	mov	w9, #0x1                // =1
     264:      	strh	w8, [sp, #0x34]
     268:      	mov	w8, #0x5                // =5
     26c:      	add	x1, sp, #0x34
     270:      	mov	w23, #0x1               // =1
     274:      	strh	w8, [sp, #0x36]
     278:      	mov	x8, #0x46               // =70
     27c:      	movk	x8, #0x2, lsl #32
     280:      	stur	x8, [sp, #0x38]
     284:      	add	x8, sp, #0x34
     288:      	ldr	x22, [x22]
     28c:      	mov	x0, x22
     290:      	blr	x9
     294:      	cbz	x0, 0x2a8 <generic_kprobe_setup_event+0x2a8>
     298:      	ldr	w8, [x0]
     29c:      	add	w8, w8, #0x1
     2a0:      	str	w8, [x0]
     2a4:      	b	0x2cc <generic_kprobe_setup_event+0x2cc>
     2a8:      	str	w23, [sp, #0x30]
     2ac:      	mov	x3, xzr
     2b0:      	mov	w8, #0x2                // =2
     2b4:      	add	x9, sp, #0x34
     2b8:      	add	x10, sp, #0x30
     2bc:      	add	x1, sp, #0x34
     2c0:      	add	x2, sp, #0x30
     2c4:      	mov	x0, x22
     2c8:      	blr	x8
     2cc:      	str	wzr, [sp, #0x18]
     2d0:      	mov	w8, #0x1                // =1
     2d4:      	add	x9, sp, #0x18
     2d8:      	add	x1, sp, #0x18
     2dc:      	mov	x0, x20
     2e0:      	blr	x8
     2e4:      	adrp	x20, 0x0 <generic_kprobe_setup_event>
     2e8:      	ldr	x20, [x20]
     2ec:      	cbz	x0, 0x314 <generic_kprobe_setup_event+0x314>
     2f0:      	mov	w8, #0x5ef8             // =24312
     2f4:      	add	x1, x0, x8
     2f8:      	mov	w8, #0x1                // =1
     2fc:      	mov	x0, x21
     300:      	blr	x8
     304:      	cbz	x0, 0x314 <generic_kprobe_setup_event+0x314>
     308:      	ldr	w8, [x0, #0x40]
     30c:      	cmn	w8, #0x1
     310:      	b.ne	0x32c <generic_kprobe_setup_event+0x32c>
     314:      	mov	w8, #0x3                // =3
     318:      	mov	w9, #0xc                // =12
     31c:      	mov	x0, x19
     320:      	mov	x1, x20
     324:      	mov	w2, #0x3                // =3
     328:      	blr	x9
     32c:      	mov	w8, #0x1                // =1
     330:      	mov	w9, #0xc                // =12
     334:      	mov	x0, x19
     338:      	mov	x1, x20
     33c:      	mov	w2, #0x1                // =1
     340:      	blr	x9
     344:      	ldp	x20, x19, [sp, #0x70]
     348:      	mov	w0, wzr
     34c:      	ldp	x22, x21, [sp, #0x60]
     350:      	ldp	x24, x23, [sp, #0x50]
     354:      	ldp	x30, x25, [sp, #0x40]
     358:      	add	sp, sp, #0x80
     35c:      	ret

0000000000000360 <generic_kprobe_process_event>:
     360:      	sub	sp, sp, #0x160
     364:      	str	x29, [sp, #0x110]
     368:      	stp	x30, x25, [sp, #0x120]
     36c:      	stp	x24, x23, [sp, #0x130]
     370:      	stp	x22, x21, [sp, #0x140]
     374:      	stp	x20, x19, [sp, #0x150]
     378:      	str	wzr, [sp, #0x5c]
     37c:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     380:      	mov	w8, #0x1                // =1
     384:      	add	x9, sp, #0x5c
     388:      	ldr	x25, [x25]
     38c:      	mov	x19, x0
     390:      	add	x1, sp, #0x5c
     394:      	mov	x0, x25
     398:      	blr	x8
     39c:      	cbz	x0, 0x8cc <generic_kprobe_process_event+0x56c>
     3a0:      	ldr	w24, [x0, #0x4]
     3a4:      	mov	w21, #0x5efc            // =24316
     3a8:      	mov	x20, x0
     3ac:      	ldr	w23, [x0, x21]
     3b0:      	lsr	w8, w24, #3
     3b4:      	cmp	w8, #0x464
     3b8:      	b.hi	0x830 <generic_kprobe_process_event+0x4d0>
     3bc:      	str	wzr, [sp, #0x68]
     3c0:      	mov	w8, #0x1                // =1
     3c4:      	add	x9, sp, #0x68
     3c8:      	add	x1, sp, #0x68
     3cc:      	mov	x0, x25
     3d0:      	blr	x8
     3d4:      	cbz	x0, 0x830 <generic_kprobe_process_event+0x4d0>
     3d8:      	mov	w8, #0x5ef8             // =24312
     3dc:      	mov	x22, x0
     3e0:      	add	x1, x0, x8
     3e4:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     3e8:      	mov	w8, #0x1                // =1
     3ec:      	ldr	x0, [x0]
     3f0:      	blr	x8
     3f4:      	cmp	w23, #0x4
     3f8:      	ccmp	x0, #0x0, #0x4, le
     3fc:      	b.eq	0x830 <generic_kprobe_process_event+0x4d0>
     400:      	and	x29, x23, #0x7
     404:      	str	x24, [sp, #0x118]
     408:      	str	x23, [sp, #0x50]
     40c:      	mov	w9, #0x5ea0             // =24224
     410:      	add	x8, x0, x29, lsl #2
     414:      	ldrsw	x24, [x8, #0x18]
     418:      	ldr	w23, [x8, #0x4]
     41c:      	add	x8, x22, x29, lsl #2
     420:      	add	x25, x8, x9
     424:      	str	wzr, [x25]
     428:      	and	x10, x24, #0xffffffff
     42c:      	str	x10, [sp, #0x40]
     430:      	tbnz	w24, #0x8, 0x454 <generic_kprobe_process_event+0xf4>
     434:      	tbnz	w10, #0x7, 0x460 <generic_kprobe_process_event+0x100>
     438:      	tbnz	w24, #0x6, 0x4b8 <generic_kprobe_process_event+0x158>
     43c:      	add	x8, x0, x29, lsl #2
     440:      	ldr	w8, [x8, #0x40]
     444:      	and	x8, x8, #0x7
     448:      	add	x8, x22, x8, lsl #3
     44c:      	ldr	x10, [x8, #0x5e50]
     450:      	b	0x4ec <generic_kprobe_process_event+0x18c>
     454:      	mov	x10, xzr
     458:      	str	xzr, [sp, #0x60]
     45c:      	b	0x5e8 <generic_kprobe_process_event+0x288>
     460:      	add	x8, x0, x29, lsl #2
     464:      	mov	w10, #0x40              // =64
     468:      	ldrb	w9, [x8, #0x2c2]
     46c:      	ldrh	w1, [x8, #0x2c0]
     470:      	sub	w22, w10, w9, lsl #3
     474:      	ldr	w9, [x0, #0x54]
     478:      	cbz	w9, 0x4c8 <generic_kprobe_process_event+0x168>
     47c:      	cbz	x19, 0x4e8 <generic_kprobe_process_event+0x188>
     480:      	add	x2, x19, x1
     484:      	mov	w8, #0x8                // =8
     488:      	mov	w9, #0x4                // =4
     48c:      	add	x10, sp, #0x98
     490:      	mov	x21, x0
     494:      	add	x0, sp, #0x98
     498:      	mov	w1, #0x8                // =8
     49c:      	blr	x9
     4a0:      	ldr	x8, [sp, #0x98]
     4a4:      	mov	x0, x21
     4a8:      	mov	w21, #0x5efc            // =24316
     4ac:      	lsl	x8, x8, x22
     4b0:      	asr	x10, x8, x22
     4b4:      	b	0x4ec <generic_kprobe_process_event+0x18c>
     4b8:      	mov	w8, #0x23               // =35
     4bc:      	mov	x21, x0
     4c0:      	blr	x8
     4c4:      	b	0x4d8 <generic_kprobe_process_event+0x178>
     4c8:      	mov	x21, x0
     4cc:      	mov	x0, x19
     4d0:      	mov	w2, w22
     4d4:      	bl	0x4d4 <generic_kprobe_process_event+0x174>
     4d8:      	mov	x10, x0
     4dc:      	mov	x0, x21
     4e0:      	mov	w21, #0x5efc            // =24316
     4e4:      	b	0x4ec <generic_kprobe_process_event+0x18c>
     4e8:      	mov	x10, xzr
     4ec:      	cmp	w29, #0x4
     4f0:      	str	x10, [sp, #0x60]
     4f4:      	b.hi	0x5e8 <generic_kprobe_process_event+0x288>
     4f8:      	mov	w8, #0x50               // =80
     4fc:      	umaddl	x8, w29, w8, x0
     500:      	ldrh	w9, [x8, #0x76]
     504:      	cbz	w9, 0x5e8 <generic_kprobe_process_event+0x288>
     508:      	add	x8, x8, #0x70
     50c:      	add	x9, sp, #0x60
     510:      	strb	wzr, [sp, #0xa8]
     514:      	str	x25, [sp, #0xb0]
     518:      	stp	x8, x9, [sp, #0x98]
     51c:      	adrp	x8, 0x0 <generic_kprobe_setup_event>
     520:      	ldr	x8, [x8]
     524:      	ldrb	w8, [x8]
     528:      	cbz	w8, 0x5bc <generic_kprobe_process_event+0x25c>
     52c:      	mov	x25, xzr
     530:      	mov	w22, #0x1               // =1
     534:      	mov	w21, #0x8               // =8
     538:      	b	0x564 <generic_kprobe_process_event+0x204>
     53c:      	mov	w10, #0x4               // =4
     540:      	ldr	x0, [sp, #0xa0]
     544:      	mov	w1, #0x8                // =8
     548:      	ldr	x2, [x0]
     54c:      	blr	x10
     550:      	tbnz	w0, #0x1f, 0x5b0 <generic_kprobe_process_event+0x250>
     554:      	add	x25, x25, #0x8
     558:      	add	w22, w22, #0x1
     55c:      	cmp	x25, #0x50
     560:      	b.eq	0x5e0 <generic_kprobe_process_event+0x280>
     564:      	ldr	x8, [sp, #0x98]
     568:      	add	x10, x8, x25
     56c:      	ldrh	w8, [x10, #0x6]
     570:      	cbz	w8, 0x5e0 <generic_kprobe_process_event+0x280>
     574:      	ldr	x8, [sp, #0xa0]
     578:      	ldr	w11, [x10]
     57c:      	ldr	x9, [x8]
     580:      	add	x9, x9, x11
     584:      	str	x9, [x8]
     588:      	ldrh	w10, [x10, #0x4]
     58c:      	cbz	w10, 0x554 <generic_kprobe_process_event+0x1f4>
     590:      	ldrb	w10, [sp, #0xa8]
     594:      	cbz	w10, 0x53c <generic_kprobe_process_event+0x1dc>
     598:      	mov	w10, #0x94              // =148
     59c:      	ldr	x0, [sp, #0xa0]
     5a0:      	mov	w1, #0x8                // =8
     5a4:      	ldr	x2, [x0]
     5a8:      	blr	x10
     5ac:      	tbz	w0, #0x1f, 0x554 <generic_kprobe_process_event+0x1f4>
     5b0:      	ldr	x8, [sp, #0xb0]
     5b4:      	str	w22, [x8]
     5b8:      	b	0x5e0 <generic_kprobe_process_event+0x280>
     5bc:      	mov	x3, xzr
     5c0:      	adrp	x1, 0x0 <generic_kprobe_setup_event>
     5c4:      	add	x1, x1, #0x0
     5c8:      	mov	w8, #0xa                // =10
     5cc:      	mov	w9, #0xb5               // =181
     5d0:      	add	x10, sp, #0x98
     5d4:      	add	x2, sp, #0x98
     5d8:      	mov	w0, #0xa                // =10
     5dc:      	blr	x9
     5e0:      	ldr	x10, [sp, #0x60]
     5e4:      	mov	w21, #0x5efc            // =24316
     5e8:      	mov	w22, #0x1000            // =4096
     5ec:      	cmp	w23, #0x15
     5f0:      	b.gt	0x62c <generic_kprobe_process_event+0x2cc>
     5f4:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     5f8:      	cmp	w23, #0xb
     5fc:      	ldr	x25, [x25]
     600:      	b.gt	0x664 <generic_kprobe_process_event+0x304>
     604:      	cmp	w23, #0x5
     608:      	b.gt	0x6d4 <generic_kprobe_process_event+0x374>
     60c:      	cmp	w23, #0x3
     610:      	b.gt	0x768 <generic_kprobe_process_event+0x408>
     614:      	sub	w8, w23, #0x2
     618:      	cmp	w8, #0x2
     61c:      	b.lo	0x724 <generic_kprobe_process_event+0x3c4>
     620:      	cmp	w23, #0x1
     624:      	b.eq	0x724 <generic_kprobe_process_event+0x3c4>
     628:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     62c:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     630:      	cmp	w23, #0x20
     634:      	ldr	x25, [x25]
     638:      	b.le	0x688 <generic_kprobe_process_event+0x328>
     63c:      	cmp	w23, #0x27
     640:      	b.gt	0x6ac <generic_kprobe_process_event+0x34c>
     644:      	sub	w8, w23, #0x21
     648:      	cmp	w8, #0x4
     64c:      	b.lo	0x780 <generic_kprobe_process_event+0x420>
     650:      	cmp	w23, #0x25
     654:      	b.eq	0x7a4 <generic_kprobe_process_event+0x444>
     658:      	cmp	w23, #0x27
     65c:      	b.eq	0x72c <generic_kprobe_process_event+0x3cc>
     660:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     664:      	cmp	w23, #0x11
     668:      	b.gt	0x6f8 <generic_kprobe_process_event+0x398>
     66c:      	sub	w8, w23, #0xf
     670:      	cmp	w8, #0x3
     674:      	b.lo	0x7a4 <generic_kprobe_process_event+0x444>
     678:      	sub	w8, w23, #0xc
     67c:      	cmp	w8, #0x2
     680:      	b.lo	0x724 <generic_kprobe_process_event+0x3c4>
     684:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     688:      	cmp	w23, #0x1a
     68c:      	b.gt	0x718 <generic_kprobe_process_event+0x3b8>
     690:      	cmp	w23, #0x16
     694:      	b.eq	0x72c <generic_kprobe_process_event+0x3cc>
     698:      	cmp	w23, #0x17
     69c:      	b.eq	0x780 <generic_kprobe_process_event+0x420>
     6a0:      	cmp	w23, #0x1a
     6a4:      	b.eq	0x798 <generic_kprobe_process_event+0x438>
     6a8:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     6ac:      	cmp	w23, #0x29
     6b0:      	b.le	0x74c <generic_kprobe_process_event+0x3ec>
     6b4:      	cmp	w23, #0x2a
     6b8:      	b.eq	0x7a4 <generic_kprobe_process_event+0x444>
     6bc:      	cmp	w23, #0x2b
     6c0:      	b.eq	0x760 <generic_kprobe_process_event+0x400>
     6c4:      	cmp	w23, #0x2c
     6c8:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     6cc:      	mov	w22, #0x70              // =112
     6d0:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     6d4:      	cmp	w23, #0x9
     6d8:      	b.gt	0x780 <generic_kprobe_process_event+0x420>
     6dc:      	cmp	w23, #0x6
     6e0:      	b.eq	0x7a4 <generic_kprobe_process_event+0x444>
     6e4:      	cmp	w23, #0x7
     6e8:      	b.eq	0x778 <generic_kprobe_process_event+0x418>
     6ec:      	cmp	w23, #0x8
     6f0:      	b.eq	0x798 <generic_kprobe_process_event+0x438>
     6f4:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     6f8:      	cmp	w23, #0x13
     6fc:      	b.gt	0x734 <generic_kprobe_process_event+0x3d4>
     700:      	cmp	w23, #0x12
     704:      	mov	x22, x24
     708:      	b.eq	0x7a4 <generic_kprobe_process_event+0x444>
     70c:      	cmp	w23, #0x13
     710:      	b.eq	0x760 <generic_kprobe_process_event+0x400>
     714:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     718:      	sub	w8, w23, #0x1d
     71c:      	cmp	w8, #0x4
     720:      	b.hs	0x790 <generic_kprobe_process_event+0x430>
     724:      	mov	w22, #0x4               // =4
     728:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     72c:      	mov	w22, #0x10              // =16
     730:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     734:      	cmp	w23, #0x14
     738:      	b.eq	0x788 <generic_kprobe_process_event+0x428>
     73c:      	cmp	w23, #0x15
     740:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     744:      	mov	w22, #0x20              // =32
     748:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     74c:      	cmp	w23, #0x28
     750:      	b.eq	0x760 <generic_kprobe_process_event+0x400>
     754:      	cmp	w23, #0x29
     758:      	b.eq	0x778 <generic_kprobe_process_event+0x418>
     75c:      	b	0x7a0 <generic_kprobe_process_event+0x440>
     760:      	mov	w22, #0x18              // =24
     764:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     768:      	cmp	w23, #0x4
     76c:      	b.eq	0x780 <generic_kprobe_process_event+0x420>
     770:      	cmp	w23, #0x5
     774:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     778:      	mov	w22, #0x40              // =64
     77c:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     780:      	mov	w22, #0x8               // =8
     784:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     788:      	mov	w22, #0x98              // =152
     78c:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     790:      	cmp	w23, #0x1b
     794:      	b.ne	0x7a0 <generic_kprobe_process_event+0x440>
     798:      	mov	w22, #0x50              // =80
     79c:      	b	0x7a4 <generic_kprobe_process_event+0x444>
     7a0:      	mov	x22, xzr
     7a4:      	str	x10, [sp, #0x48]
     7a8:      	str	wzr, [sp, #0x6c]
     7ac:      	mov	w8, #0x1                // =1
     7b0:      	add	x9, sp, #0x6c
     7b4:      	add	x1, sp, #0x6c
     7b8:      	mov	x0, x25
     7bc:      	blr	x8
     7c0:      	cbz	x0, 0x828 <generic_kprobe_process_event+0x4c8>
     7c4:      	ldr	x9, [sp, #0x118]
     7c8:      	mov	w8, #0x3ffb             // =16379
     7cc:      	sub	x8, x8, x22
     7d0:      	cmp	x8, x9
     7d4:      	b.ls	0x828 <generic_kprobe_process_event+0x4c8>
     7d8:      	add	x22, x0, x29, lsl #2
     7dc:      	mov	w8, #0x5ea0             // =24224
     7e0:      	add	x11, x0, #0x90
     7e4:      	ldr	w9, [x22, x8]
     7e8:      	ldr	x8, [sp, #0x118]
     7ec:      	add	x10, x0, x29, lsl #3
     7f0:      	str	w9, [x11, x8]
     7f4:      	add	x8, x8, #0x4
     7f8:      	str	x8, [x10, #0x5e78]
     7fc:      	cbz	w9, 0x8ec <generic_kprobe_process_event+0x58c>
     800:      	ldr	x23, [sp, #0x50]
     804:      	ldr	x24, [sp, #0x118]
     808:      	mov	w8, #0x4                // =4
     80c:      	add	w24, w8, w24
     810:      	str	w24, [x20, #0x4]
     814:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     818:      	cmp	w23, #0x3
     81c:      	ldr	x22, [x22]
     820:      	b.le	0x844 <generic_kprobe_process_event+0x4e4>
     824:      	b	0x8b0 <generic_kprobe_process_event+0x550>
     828:      	ldr	x23, [sp, #0x50]
     82c:      	ldr	x24, [sp, #0x118]
     830:      	str	w24, [x20, #0x4]
     834:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     838:      	cmp	w23, #0x3
     83c:      	ldr	x22, [x22]
     840:      	b.gt	0x8b0 <generic_kprobe_process_event+0x550>
     844:      	str	wzr, [sp, #0x98]
     848:      	mov	w8, #0x1                // =1
     84c:      	add	x9, sp, #0x98
     850:      	add	x1, sp, #0x98
     854:      	mov	x0, x25
     858:      	blr	x8
     85c:      	cbz	x0, 0x8b0 <generic_kprobe_process_event+0x550>
     860:      	mov	w8, #0x5ef8             // =24312
     864:      	add	x1, x0, x8
     868:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     86c:      	mov	w8, #0x1                // =1
     870:      	ldr	x0, [x0]
     874:      	blr	x8
     878:      	cbz	x0, 0x8b0 <generic_kprobe_process_event+0x550>
     87c:      	add	w8, w23, #0x1
     880:      	and	w9, w8, #0x7
     884:      	add	x9, x0, w9, uxtw #2
     888:      	ldr	w9, [x9, #0x40]
     88c:      	cmn	w9, #0x1
     890:      	b.eq	0x8b0 <generic_kprobe_process_event+0x550>
     894:      	str	w8, [x20, x21]
     898:      	mov	w8, #0x1                // =1
     89c:      	mov	w9, #0xc                // =12
     8a0:      	mov	x0, x19
     8a4:      	mov	x1, x22
     8a8:      	mov	w2, #0x1                // =1
     8ac:      	blr	x9
     8b0:      	str	wzr, [x20, x21]
     8b4:      	mov	w8, #0x3                // =3
     8b8:      	mov	w9, #0xc                // =12
     8bc:      	mov	x0, x19
     8c0:      	mov	x1, x22
     8c4:      	mov	w2, #0x3                // =3
     8c8:      	blr	x9
     8cc:      	ldp	x20, x19, [sp, #0x150]
     8d0:      	mov	w0, wzr
     8d4:      	ldr	x29, [sp, #0x110]
     8d8:      	ldp	x22, x21, [sp, #0x140]
     8dc:      	ldp	x24, x23, [sp, #0x130]
     8e0:      	ldp	x30, x25, [sp, #0x120]
     8e4:      	add	sp, sp, #0x160
     8e8:      	ret
     8ec:      	ldr	x10, [sp, #0x48]
     8f0:      	and	x29, x8, #0x3fff
     8f4:      	add	x9, sp, #0xe0
     8f8:      	cmp	w23, #0x17
     8fc:      	str	xzr, [x9, #0x10]
     900:      	add	x8, x11, x29
     904:      	stp	x8, x11, [sp, #0x30]
     908:      	str	x10, [sp, #0x98]
     90c:      	b.le	0x934 <generic_kprobe_process_event+0x5d4>
     910:      	cmp	w23, #0x18
     914:      	b.eq	0x950 <generic_kprobe_process_event+0x5f0>
     918:      	cmp	w23, #0x25
     91c:      	b.eq	0x9a0 <generic_kprobe_process_event+0x640>
     920:      	cmp	w23, #0x2a
     924:      	b.ne	0xecc <generic_kprobe_process_event+0xb6c>
     928:      	stp	xzr, x10, [sp, #0x70]
     92c:      	add	x21, sp, #0x70
     930:      	b	0xa00 <generic_kprobe_process_event+0x6a0>
     934:      	cmp	w23, #0xf
     938:      	b.eq	0x9d4 <generic_kprobe_process_event+0x674>
     93c:      	cmp	w23, #0x10
     940:      	b.ne	0xecc <generic_kprobe_process_event+0xb6c>
     944:      	add	x21, sp, #0x100
     948:      	add	x23, sp, #0xe0
     94c:      	b	0x978 <generic_kprobe_process_event+0x618>
     950:      	add	x21, sp, #0x100
     954:      	mov	w8, #0x8                // =8
     958:      	mov	w9, #0x4                // =4
     95c:      	ldr	x2, [sp, #0x98]
     960:      	add	x0, sp, #0x100
     964:      	mov	w1, #0x8                // =8
     968:      	blr	x9
     96c:      	add	x23, sp, #0xe0
     970:      	ldr	x8, [x23, #0x20]
     974:      	str	x8, [sp, #0x98]
     978:      	mov	w8, #0x8                // =8
     97c:      	mov	w9, #0x4                // =4
     980:      	add	x10, sp, #0x98
     984:      	add	x0, sp, #0x100
     988:      	add	x2, sp, #0x98
     98c:      	mov	w1, #0x8                // =8
     990:      	blr	x9
     994:      	ldr	x8, [x23, #0x20]
     998:      	add	x21, x8, #0x40
     99c:      	b	0xa00 <generic_kprobe_process_event+0x6a0>
     9a0:      	add	x8, x10, #0x40
     9a4:      	mov	w9, #0x8                // =8
     9a8:      	mov	w10, #0x4               // =4
     9ac:      	str	x8, [sp, #0x98]
     9b0:      	add	x11, sp, #0x100
     9b4:      	add	x0, sp, #0x100
     9b8:      	mov	w1, #0x8                // =8
     9bc:      	ldr	x2, [sp, #0x98]
     9c0:      	blr	x10
     9c4:      	add	x8, sp, #0xe0
     9c8:      	ldr	x8, [x8, #0x20]
     9cc:      	add	x21, x8, #0x40
     9d0:      	b	0xa00 <generic_kprobe_process_event+0x6a0>
     9d4:      	mov	w8, #0x8                // =8
     9d8:      	mov	w9, #0x4                // =4
     9dc:      	add	x10, sp, #0xf0
     9e0:      	add	x11, sp, #0x98
     9e4:      	add	x0, sp, #0xf0
     9e8:      	add	x2, sp, #0x98
     9ec:      	mov	w1, #0x8                // =8
     9f0:      	blr	x9
     9f4:      	add	x8, sp, #0xe0
     9f8:      	ldr	x21, [x8, #0x10]
     9fc:      	cbz	x21, 0x108c <generic_kprobe_process_event+0xd2c>
     a00:      	str	wzr, [sp, #0x84]
     a04:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     a08:      	mov	w8, #0x1                // =1
     a0c:      	add	x9, sp, #0x84
     a10:      	ldr	x0, [x0]
     a14:      	add	x1, sp, #0x84
     a18:      	blr	x8
     a1c:      	cbz	x0, 0xfc8 <generic_kprobe_process_event+0xc68>
     a20:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     a24:      	str	x22, [sp, #0x20]
     a28:      	mov	x24, x0
     a2c:      	str	x8, [sp, #0x40]
     a30:      	mov	w8, #0x23               // =35
     a34:      	blr	x8
     a38:      	add	x2, x0, #0xb30
     a3c:      	mov	w23, #0x8               // =8
     a40:      	add	x8, sp, #0x88
     a44:      	mov	w9, #0x4                // =4
     a48:      	add	x0, sp, #0x88
     a4c:      	mov	w1, #0x8                // =8
     a50:      	mov	w22, #0x4               // =4
     a54:      	blr	x9
     a58:      	ldr	x8, [sp, #0x88]
     a5c:      	add	x2, x21, #0x8
     a60:      	mov	w9, #0x4                // =4
     a64:      	add	x0, sp, #0x90
     a68:      	stp	x8, x21, [sp, #0x10]
     a6c:      	add	x8, x8, #0x18
     a70:      	mov	w1, #0x8                // =8
     a74:      	str	x8, [sp, #0x48]
     a78:      	add	x8, sp, #0x90
     a7c:      	str	x2, [sp, #0x28]
     a80:      	blr	x9
     a84:      	ldr	x21, [sp, #0x90]
     a88:      	add	x29, sp, #0x98
     a8c:      	add	x0, sp, #0x98
     a90:      	mov	w1, #0x8                // =8
     a94:      	add	x2, x21, #0x10
     a98:      	blr	x22
     a9c:      	ldr	x8, [sp, #0x98]
     aa0:      	cbz	x8, 0xab0 <generic_kprobe_process_event+0x750>
     aa4:      	ldr	x9, [sp, #0x40]
     aa8:      	mov	w8, #0x1000             // =4096
     aac:      	b	0xaf8 <generic_kprobe_process_event+0x798>
     ab0:      	add	x2, x21, #0x18
     ab4:      	mov	w8, #0x8                // =8
     ab8:      	mov	w9, #0x4                // =4
     abc:      	add	x10, sp, #0x98
     ac0:      	add	x0, sp, #0x98
     ac4:      	mov	w1, #0x8                // =8
     ac8:      	blr	x9
     acc:      	ldr	x8, [sp, #0x98]
     ad0:      	cmp	x8, x21
     ad4:      	b.eq	0xaa4 <generic_kprobe_process_event+0x744>
     ad8:      	mov	w8, #0x2964             // =10596
     adc:      	add	x9, x24, #0xff6
     ae0:      	strh	w8, [x24, #0xffe]
     ae4:      	adrp	x8, 0x0 <generic_kprobe_setup_event>
     ae8:      	add	x8, x8, #0x0
     aec:      	ldr	x8, [x8]
     af0:      	str	x8, [x9]
     af4:      	mov	w8, #0xff6              // =4086
     af8:      	str	x9, [sp, #0x40]
     afc:      	str	x9, [sp, #0xc8]
     b00:      	ldr	x9, [sp, #0x10]
     b04:      	mov	w21, #0x8               // =8
     b08:      	add	x0, sp, #0x98
     b0c:      	mov	w1, #0x8                // =8
     b10:      	stp	xzr, xzr, [sp, #0x98]
     b14:      	add	x23, x29, #0x8
     b18:      	add	x25, x29, #0x18
     b1c:      	mov	w22, #0x4               // =4
     b20:      	add	x2, x9, #0x20
     b24:      	stp	x24, xzr, [sp, #0xa8]
     b28:      	stp	xzr, xzr, [sp, #0xb8]
     b2c:      	str	w8, [sp, #0xd0]
     b30:      	mov	w8, #0x4                // =4
     b34:      	add	x24, x29, #0x20
     b38:      	strb	wzr, [sp, #0xd4]
     b3c:      	blr	x8
     b40:      	ldr	x2, [sp, #0x48]
     b44:      	mov	w8, #0x4                // =4
     b48:      	mov	x0, x23
     b4c:      	mov	w1, #0x8                // =8
     b50:      	blr	x8
     b54:      	ldr	x2, [sp, #0x28]
     b58:      	mov	w8, #0x4                // =4
     b5c:      	mov	x0, x25
     b60:      	mov	w1, #0x8                // =8
     b64:      	str	x25, [sp, #0x48]
     b68:      	blr	x8
     b6c:      	ldr	x2, [sp, #0x18]
     b70:      	mov	x0, x24
     b74:      	mov	w1, #0x8                // =8
     b78:      	blr	x22
     b7c:      	ldr	x8, [sp, #0xb8]
     b80:      	sub	x8, x8, #0x20
     b84:      	str	x8, [sp, #0xc0]
     b88:      	adrp	x8, 0x0 <generic_kprobe_setup_event>
     b8c:      	ldr	x8, [x8]
     b90:      	ldrb	w8, [x8]
     b94:      	cbz	w8, 0xd38 <generic_kprobe_process_event+0x9d8>
     b98:      	mov	w23, #0x800             // =2048
     b9c:      	mov	w24, #0x8               // =8
     ba0:      	add	x22, sp, #0xe0
     ba4:      	ldp	x21, x2, [sp, #0xb0]
     ba8:      	ldp	x8, x9, [sp, #0x98]
     bac:      	cmp	x21, x8
     bb0:      	ccmp	x2, x9, #0x0, eq
     bb4:      	b.eq	0xf68 <generic_kprobe_process_event+0xc08>
     bb8:      	ldr	x25, [sp, #0xc0]
     bbc:      	mov	w8, #0x4                // =4
     bc0:      	add	x9, sp, #0xe0
     bc4:      	add	x0, sp, #0xe0
     bc8:      	mov	w1, #0x8                // =8
     bcc:      	blr	x8
     bd0:      	ldr	x8, [x22]
     bd4:      	add	x29, sp, #0xe0
     bd8:      	cmp	x21, x8
     bdc:      	b.eq	0xcd8 <generic_kprobe_process_event+0x978>
     be0:      	add	x22, x21, #0x18
     be4:      	mov	w8, #0x4                // =4
     be8:      	add	x9, sp, #0x100
     bec:      	add	x0, sp, #0x100
     bf0:      	mov	w1, #0x8                // =8
     bf4:      	mov	x2, x22
     bf8:      	blr	x8
     bfc:      	ldr	x8, [x29, #0x20]
     c00:      	cmp	x8, x21
     c04:      	b.eq	0xcd8 <generic_kprobe_process_event+0x978>
     c08:      	mov	w8, #0x4                // =4
     c0c:      	add	x9, sp, #0xe8
     c10:      	add	x0, sp, #0xe8
     c14:      	mov	w1, #0x8                // =8
     c18:      	mov	x2, x22
     c1c:      	blr	x8
     c20:      	add	x2, x21, #0x20
     c24:      	mov	w8, #0x4                // =4
     c28:      	mov	w9, #0x10               // =16
     c2c:      	add	x10, sp, #0xf0
     c30:      	add	x0, sp, #0xf0
     c34:      	mov	w1, #0x10               // =16
     c38:      	blr	x8
     c3c:      	ldr	w21, [sp, #0xf4]
     c40:      	ldr	x8, [sp, #0xa8]
     c44:      	ldr	x10, [sp, #0xc8]
     c48:      	sub	x12, x10, x8
     c4c:      	ldr	w22, [sp, #0xd0]
     c50:      	subs	w10, w21, w22
     c54:      	ldr	x9, [x29, #0x18]
     c58:      	csel	w10, wzr, w10, lo
     c5c:      	cmp	w22, w21
     c60:      	csel	w11, w22, w21, lo
     c64:      	cinc	w13, w11, hi
     c68:      	sub	w14, w22, w13
     c6c:      	subs	x12, x12, x13
     c70:      	str	w14, [sp, #0xd0]
     c74:      	b.lo	0xf70 <generic_kprobe_process_event+0xc10>
     c78:      	cmp	x12, #0xfff
     c7c:      	b.hi	0xf70 <generic_kprobe_process_event+0xc10>
     c80:      	cmp	w22, w21
     c84:      	b.ls	0xc90 <generic_kprobe_process_event+0x930>
     c88:      	mov	w13, #0x2f              // =47
     c8c:      	strb	w13, [x8, x12]
     c90:      	add	x25, x8, x12
     c94:      	cmp	w22, w21
     c98:      	add	x2, x9, x10
     c9c:      	and	w1, w11, #0xff
     ca0:      	mov	w8, #0x4                // =4
     ca4:      	cinc	x0, x25, hi
     ca8:      	blr	x8
     cac:      	cmp	w22, w21
     cb0:      	str	x25, [sp, #0xc8]
     cb4:      	b.ls	0xf70 <generic_kprobe_process_event+0xc10>
     cb8:      	add	x22, sp, #0xe0
     cbc:      	ldr	x8, [x22, #0x8]
     cc0:      	str	x8, [sp, #0xb0]
     cc4:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     cc8:      	subs	w23, w23, #0x1
     ccc:      	ldr	x25, [x25]
     cd0:      	b.ne	0xba4 <generic_kprobe_process_event+0x844>
     cd4:      	b	0xf88 <generic_kprobe_process_event+0xc28>
     cd8:      	add	x2, x25, #0x10
     cdc:      	mov	w8, #0x4                // =4
     ce0:      	add	x9, sp, #0x100
     ce4:      	add	x0, sp, #0x100
     ce8:      	mov	w1, #0x8                // =8
     cec:      	blr	x8
     cf0:      	ldr	x8, [sp, #0xc0]
     cf4:      	ldr	x9, [x29, #0x20]
     cf8:      	add	x22, sp, #0xe0
     cfc:      	cmp	x8, x9
     d00:      	b.eq	0xf78 <generic_kprobe_process_event+0xc18>
     d04:      	ldr	x0, [sp, #0x48]
     d08:      	add	x2, x25, #0x18
     d0c:      	mov	w8, #0x4                // =4
     d10:      	mov	w1, #0x8                // =8
     d14:      	blr	x8
     d18:      	ldr	x8, [x22, #0x20]
     d1c:      	add	x9, x8, #0x20
     d20:      	stp	x9, x8, [sp, #0xb8]
     d24:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     d28:      	subs	w23, w23, #0x1
     d2c:      	ldr	x25, [x25]
     d30:      	b.ne	0xba4 <generic_kprobe_process_event+0x844>
     d34:      	b	0xf88 <generic_kprobe_process_event+0xc28>
     d38:      	mov	w23, #0x800             // =2048
     d3c:      	mov	w24, #0x8               // =8
     d40:      	add	x22, sp, #0xe0
     d44:      	b	0xd58 <generic_kprobe_process_event+0x9f8>
     d48:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     d4c:      	subs	w23, w23, #0x1
     d50:      	ldr	x25, [x25]
     d54:      	b.eq	0xf88 <generic_kprobe_process_event+0xc28>
     d58:      	ldp	x21, x2, [sp, #0xb0]
     d5c:      	ldp	x8, x9, [sp, #0x98]
     d60:      	cmp	x21, x8
     d64:      	ccmp	x2, x9, #0x0, eq
     d68:      	b.eq	0xf68 <generic_kprobe_process_event+0xc08>
     d6c:      	ldr	x25, [sp, #0xc0]
     d70:      	mov	w8, #0x4                // =4
     d74:      	add	x9, sp, #0xe0
     d78:      	add	x0, sp, #0xe0
     d7c:      	mov	w1, #0x8                // =8
     d80:      	blr	x8
     d84:      	ldr	x8, [x22]
     d88:      	add	x29, sp, #0xe0
     d8c:      	cmp	x21, x8
     d90:      	b.eq	0xe7c <generic_kprobe_process_event+0xb1c>
     d94:      	add	x22, x21, #0x18
     d98:      	mov	w8, #0x4                // =4
     d9c:      	add	x9, sp, #0x100
     da0:      	add	x0, sp, #0x100
     da4:      	mov	w1, #0x8                // =8
     da8:      	mov	x2, x22
     dac:      	blr	x8
     db0:      	ldr	x8, [x29, #0x20]
     db4:      	cmp	x8, x21
     db8:      	b.eq	0xe7c <generic_kprobe_process_event+0xb1c>
     dbc:      	mov	w8, #0x4                // =4
     dc0:      	add	x9, sp, #0xe8
     dc4:      	add	x0, sp, #0xe8
     dc8:      	mov	w1, #0x8                // =8
     dcc:      	mov	x2, x22
     dd0:      	blr	x8
     dd4:      	add	x2, x21, #0x20
     dd8:      	mov	w8, #0x4                // =4
     ddc:      	mov	w9, #0x10               // =16
     de0:      	add	x10, sp, #0xf0
     de4:      	add	x0, sp, #0xf0
     de8:      	mov	w1, #0x10               // =16
     dec:      	blr	x8
     df0:      	ldr	w21, [sp, #0xf4]
     df4:      	ldr	x8, [sp, #0xa8]
     df8:      	ldr	x10, [sp, #0xc8]
     dfc:      	sub	x12, x10, x8
     e00:      	ldr	w22, [sp, #0xd0]
     e04:      	subs	w10, w21, w22
     e08:      	ldr	x9, [x29, #0x18]
     e0c:      	csel	w10, wzr, w10, lo
     e10:      	cmp	w22, w21
     e14:      	csel	w11, w22, w21, lo
     e18:      	cinc	w13, w11, hi
     e1c:      	sub	w14, w22, w13
     e20:      	subs	x12, x12, x13
     e24:      	str	w14, [sp, #0xd0]
     e28:      	b.lo	0xf70 <generic_kprobe_process_event+0xc10>
     e2c:      	cmp	x12, #0xfff
     e30:      	b.hi	0xf70 <generic_kprobe_process_event+0xc10>
     e34:      	cmp	w22, w21
     e38:      	b.ls	0xe44 <generic_kprobe_process_event+0xae4>
     e3c:      	mov	w13, #0x2f              // =47
     e40:      	strb	w13, [x8, x12]
     e44:      	add	x25, x8, x12
     e48:      	cmp	w22, w21
     e4c:      	add	x2, x9, x10
     e50:      	and	w1, w11, #0xff
     e54:      	mov	w8, #0x4                // =4
     e58:      	cinc	x0, x25, hi
     e5c:      	blr	x8
     e60:      	cmp	w22, w21
     e64:      	str	x25, [sp, #0xc8]
     e68:      	b.ls	0xf70 <generic_kprobe_process_event+0xc10>
     e6c:      	add	x22, sp, #0xe0
     e70:      	ldr	x8, [x22, #0x8]
     e74:      	str	x8, [sp, #0xb0]
     e78:      	b	0xd48 <generic_kprobe_process_event+0x9e8>
     e7c:      	add	x2, x25, #0x10
     e80:      	mov	w8, #0x4                // =4
     e84:      	add	x9, sp, #0x100
     e88:      	add	x0, sp, #0x100
     e8c:      	mov	w1, #0x8                // =8
     e90:      	blr	x8
     e94:      	ldr	x8, [sp, #0xc0]
     e98:      	ldr	x9, [x29, #0x20]
     e9c:      	add	x22, sp, #0xe0
     ea0:      	cmp	x8, x9
     ea4:      	b.eq	0xf78 <generic_kprobe_process_event+0xc18>
     ea8:      	ldr	x0, [sp, #0x48]
     eac:      	add	x2, x25, #0x18
     eb0:      	mov	w8, #0x4                // =4
     eb4:      	mov	w1, #0x8                // =8
     eb8:      	blr	x8
     ebc:      	ldr	x8, [x22, #0x20]
     ec0:      	add	x9, x8, #0x20
     ec4:      	stp	x9, x8, [sp, #0xb8]
     ec8:      	b	0xd48 <generic_kprobe_process_event+0x9e8>
     ecc:      	cmp	w23, #0x2c
     ed0:      	b.hi	0x108c <generic_kprobe_process_event+0xd2c>
     ed4:      	mov	x9, #0x7cf2             // =31986
     ed8:      	mov	w8, #0x1                // =1
     edc:      	movk	x9, #0xf202, lsl #16
     ee0:      	lsl	x8, x8, x23
     ee4:      	movk	x9, #0x11c1, lsl #32
     ee8:      	tst	x8, x9
     eec:      	b.eq	0x108c <generic_kprobe_process_event+0xd2c>
     ef0:      	add	x8, sp, #0xe0
     ef4:      	str	x22, [sp, #0x20]
     ef8:      	str	wzr, [sp, #0x88]
     efc:      	add	x9, sp, #0x88
     f00:      	add	x1, sp, #0x88
     f04:      	mov	x0, x25
     f08:      	str	x10, [x8]
     f0c:      	mov	w8, #0x1                // =1
     f10:      	blr	x8
     f14:      	mov	x22, xzr
     f18:      	cbz	x0, 0x2378 <generic_kprobe_process_event+0x2018>
     f1c:      	ldr	x11, [sp, #0x38]
     f20:      	cmp	w23, #0x10
     f24:      	b.le	0x1104 <generic_kprobe_process_event+0xda4>
     f28:      	cmp	w23, #0x1e
     f2c:      	mov	w21, #0x5efc            // =24316
     f30:      	b.le	0x1220 <generic_kprobe_process_event+0xec0>
     f34:      	cmp	w23, #0x26
     f38:      	b.gt	0x1300 <generic_kprobe_process_event+0xfa0>
     f3c:      	sub	w8, w23, #0x1f
     f40:      	cmp	w8, #0x2
     f44:      	b.hs	0x1730 <generic_kprobe_process_event+0x13d0>
     f48:      	mov	w8, #0x1                // =1
     f4c:      	add	x9, sp, #0xe0
     f50:      	mov	w10, #0x4               // =4
     f54:      	ldr	x0, [sp, #0x30]
     f58:      	mov	w22, #0x4               // =4
     f5c:      	add	x2, sp, #0xe0
     f60:      	mov	w1, #0x1                // =1
     f64:      	b	0x1440 <generic_kprobe_process_event+0x10e0>
     f68:      	mov	w8, #0x1                // =1
     f6c:      	strb	w8, [sp, #0xd4]
     f70:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     f74:      	b	0xf84 <generic_kprobe_process_event+0xc24>
     f78:      	mov	w8, #0x1                // =1
     f7c:      	adrp	x25, 0x0 <generic_kprobe_setup_event>
     f80:      	strb	w8, [sp, #0xd4]
     f84:      	ldr	x25, [x25]
     f88:      	ldr	x8, [sp, #0xc8]
     f8c:      	ldr	x2, [sp, #0x40]
     f90:      	cmp	x8, x2
     f94:      	b.eq	0xfdc <generic_kprobe_process_event+0xc7c>
     f98:      	ldrb	w9, [sp, #0xd4]
     f9c:      	mov	w11, #0x1000            // =4096
     fa0:      	cmp	w9, #0x0
     fa4:      	ldr	w9, [sp, #0xd0]
     fa8:      	cset	w10, eq
     fac:      	sub	w11, w11, w9
     fb0:      	cmp	w9, #0x0
     fb4:      	csel	w9, w11, w9, gt
     fb8:      	cbz	x8, 0xfc8 <generic_kprobe_process_event+0xc68>
     fbc:      	lsl	w21, w10, #1
     fc0:      	mov	x2, x8
     fc4:      	b	0xfe4 <generic_kprobe_process_event+0xc84>
     fc8:      	ldr	x23, [sp, #0x50]
     fcc:      	ldr	x24, [sp, #0x118]
     fd0:      	mov	x22, xzr
     fd4:      	mov	w21, #0x5efc            // =24316
     fd8:      	b	0x3238 <generic_kprobe_process_event+0x2ed8>
     fdc:      	mov	w21, wzr
     fe0:      	mov	w9, wzr
     fe4:      	ldr	x29, [sp, #0x30]
     fe8:      	and	w22, w9, #0xfff
     fec:      	mov	w8, #0x4                // =4
     ff0:      	mov	w23, #0x4               // =4
     ff4:      	mov	w1, w22
     ff8:      	add	x0, x29, #0x4
     ffc:      	blr	x8
    1000:      	str	w22, [x29]
    1004:      	ldr	x2, [sp, #0x28]
    1008:      	mov	w24, #0x8               // =8
    100c:      	add	x8, sp, #0x98
    1010:      	mov	w9, #0x4                // =4
    1014:      	add	x0, sp, #0x98
    1018:      	mov	w1, #0x8                // =8
    101c:      	blr	x9
    1020:      	ldr	x8, [sp, #0x98]
    1024:      	add	x9, sp, #0xf0
    1028:      	mov	w10, #0x4               // =4
    102c:      	add	x0, sp, #0xf0
    1030:      	mov	w1, #0x8                // =8
    1034:      	add	x8, x8, #0x30
    1038:      	ldr	x8, [sp, #0x98]
    103c:      	add	x2, x8, #0x30
    1040:      	blr	x10
    1044:      	add	x11, sp, #0xe0
    1048:      	mov	w9, #0x2                // =2
    104c:      	add	x10, sp, #0x100
    1050:      	ldr	x8, [x11, #0x10]
    1054:      	add	x0, sp, #0x100
    1058:      	mov	w1, #0x2                // =2
    105c:      	ldr	x2, [x11, #0x10]
    1060:      	blr	x23
    1064:      	add	x8, x29, x22
    1068:      	ldr	x23, [sp, #0x50]
    106c:      	ldr	x11, [sp, #0x38]
    1070:      	add	w22, w22, #0xa
    1074:      	mov	w10, #0x5ea0            // =24224
    1078:      	str	w21, [x8, #0x4]
    107c:      	mov	w21, #0x5efc            // =24316
    1080:      	ldrh	w9, [sp, #0x100]
    1084:      	strh	w9, [x8, #0x8]
    1088:      	b	0x3230 <generic_kprobe_process_event+0x2ed0>
    108c:      	str	x22, [sp, #0x20]
    1090:      	str	wzr, [sp, #0x88]
    1094:      	mov	w8, #0x1                // =1
    1098:      	add	x9, sp, #0x88
    109c:      	add	x1, sp, #0x88
    10a0:      	mov	x0, x25
    10a4:      	blr	x8
    10a8:      	mov	x22, xzr
    10ac:      	cbz	x0, 0x2ad8 <generic_kprobe_process_event+0x2778>
    10b0:      	cmp	w23, #0x19
    10b4:      	mov	w21, #0x5efc            // =24316
    10b8:      	b.gt	0x12cc <generic_kprobe_process_event+0xf6c>
    10bc:      	ldr	x25, [sp, #0x30]
    10c0:      	cmp	w23, #0x12
    10c4:      	b.le	0x13c8 <generic_kprobe_process_event+0x1068>
    10c8:      	cmp	w23, #0x14
    10cc:      	b.le	0x167c <generic_kprobe_process_event+0x131c>
    10d0:      	cmp	w23, #0x15
    10d4:      	b.eq	0x1d80 <generic_kprobe_process_event+0x1a20>
    10d8:      	cmp	w23, #0x16
    10dc:      	b.eq	0x1d24 <generic_kprobe_process_event+0x19c4>
    10e0:      	ldr	x11, [sp, #0x38]
    10e4:      	ldr	x8, [sp, #0x48]
    10e8:      	cmp	w23, #0x17
    10ec:      	mov	w21, #0x5efc            // =24316
    10f0:      	mov	w10, #0x5ea0            // =24224
    10f4:      	b.ne	0x2ae4 <generic_kprobe_process_event+0x2784>
    10f8:      	stp	w8, wzr, [x25]
    10fc:      	mov	w22, #0x8               // =8
    1100:      	b	0x2ae4 <generic_kprobe_process_event+0x2784>
    1104:      	cmp	w23, #0x9
    1108:      	mov	w21, #0x5efc            // =24316
    110c:      	mov	w10, #0x5ea0            // =24224
    1110:      	b.gt	0x1250 <generic_kprobe_process_event+0xef0>
    1114:      	cmp	w23, #0x4
    1118:      	b.le	0x1448 <generic_kprobe_process_event+0x10e8>
    111c:      	cmp	w23, #0x5
    1120:      	b.eq	0x194c <generic_kprobe_process_event+0x15ec>
    1124:      	cmp	w23, #0x6
    1128:      	b.eq	0x12ac <generic_kprobe_process_event+0xf4c>
    112c:      	ldr	x11, [sp, #0x38]
    1130:      	cmp	w23, #0x7
    1134:      	mov	w10, #0x5ea0            // =24224
    1138:      	b.ne	0x322c <generic_kprobe_process_event+0x2ecc>
    113c:      	add	x8, sp, #0xe0
    1140:      	ldr	x25, [sp, #0x30]
    1144:      	mov	x24, x0
    1148:      	mov	w22, #0x2               // =2
    114c:      	ldr	x23, [x8]
    1150:      	mov	w8, #0x4                // =4
    1154:      	mov	w1, #0x2                // =2
    1158:      	mov	w21, #0x4               // =4
    115c:      	str	x23, [x25, #0x28]
    1160:      	add	x0, x25, #0x26
    1164:      	add	x2, x23, #0x10
    1168:      	blr	x8
    116c:      	add	x0, x25, #0x3a
    1170:      	add	x2, x23, #0x12
    1174:      	mov	w8, #0x1                // =1
    1178:      	mov	w9, #0x4                // =4
    117c:      	mov	w1, #0x1                // =1
    1180:      	blr	x9
    1184:      	add	x0, x25, #0x38
    1188:      	add	x2, x23, #0x21e
    118c:      	mov	w8, #0x4                // =4
    1190:      	mov	w1, #0x2                // =2
    1194:      	blr	x8
    1198:      	add	x0, x25, #0x24
    119c:      	add	x2, x23, #0x21c
    11a0:      	mov	w8, #0x4                // =4
    11a4:      	mov	w1, #0x2                // =2
    11a8:      	blr	x8
    11ac:      	add	x0, x25, #0x30
    11b0:      	add	x2, x23, #0x214
    11b4:      	mov	w8, #0x4                // =4
    11b8:      	mov	w1, #0x4                // =4
    11bc:      	blr	x8
    11c0:      	add	x0, x25, #0x34
    11c4:      	add	x2, x23, #0x210
    11c8:      	mov	w1, #0x4                // =4
    11cc:      	blr	x21
    11d0:      	ldrh	w8, [x25, #0x26]
    11d4:      	mov	x22, x25
    11d8:      	stp	xzr, xzr, [x25]
    11dc:      	cmp	w8, #0xa
    11e0:      	str	xzr, [x25, #0x18]
    11e4:      	str	xzr, [x22, #0x10]!
    11e8:      	b.eq	0x2134 <generic_kprobe_process_event+0x1dd4>
    11ec:      	cmp	w8, #0x2
    11f0:      	b.ne	0x2160 <generic_kprobe_process_event+0x1e00>
    11f4:      	ldr	x0, [sp, #0x30]
    11f8:      	add	x2, x23, #0x4
    11fc:      	mov	w8, #0x4                // =4
    1200:      	mov	w1, #0x4                // =4
    1204:      	mov	w21, #0x4               // =4
    1208:      	blr	x8
    120c:      	mov	x0, x22
    1210:      	mov	w1, #0x4                // =4
    1214:      	mov	x2, x23
    1218:      	blr	x21
    121c:      	b	0x2160 <generic_kprobe_process_event+0x1e00>
    1220:      	cmp	w23, #0x1c
    1224:      	b.gt	0x1424 <generic_kprobe_process_event+0x10c4>
    1228:      	cmp	w23, #0x11
    122c:      	b.eq	0x1764 <generic_kprobe_process_event+0x1404>
    1230:      	cmp	w23, #0x19
    1234:      	b.eq	0x1818 <generic_kprobe_process_event+0x14b8>
    1238:      	adrp	x25, 0x1000 <generic_kprobe_process_event+0xca0>
    123c:      	cmp	w23, #0x1c
    1240:      	mov	w10, #0x5ea0            // =24224
    1244:      	ldr	x25, [x25]
    1248:      	b.eq	0x1458 <generic_kprobe_process_event+0x10f8>
    124c:      	b	0x322c <generic_kprobe_process_event+0x2ecc>
    1250:      	sub	w8, w23, #0xa
    1254:      	cmp	w8, #0x2
    1258:      	b.lo	0x1458 <generic_kprobe_process_event+0x10f8>
    125c:      	sub	w8, w23, #0xc
    1260:      	cmp	w8, #0x2
    1264:      	b.lo	0x1478 <generic_kprobe_process_event+0x1118>
    1268:      	cmp	w23, #0xe
    126c:      	b.ne	0x322c <generic_kprobe_process_event+0x2ecc>
    1270:      	mov	w21, #0x8               // =8
    1274:      	add	x8, sp, #0x98
    1278:      	add	x23, sp, #0xe0
    127c:      	mov	w9, #0x4                // =4
    1280:      	add	x0, sp, #0x98
    1284:      	add	x2, sp, #0xe0
    1288:      	mov	w1, #0x8                // =8
    128c:      	mov	w22, #0x4               // =4
    1290:      	blr	x9
    1294:      	ldr	x8, [sp, #0x98]
    1298:      	add	x0, sp, #0xe0
    129c:      	mov	w1, #0x8                // =8
    12a0:      	mov	w21, #0x5efc            // =24316
    12a4:      	ldr	x2, [sp, #0x98]
    12a8:      	blr	x22
    12ac:      	ldr	x23, [sp, #0x30]
    12b0:      	add	x8, sp, #0xe0
    12b4:      	mov	w9, #0x2d               // =45
    12b8:      	mov	w1, #0x1001             // =4097
    12bc:      	ldr	x2, [x8]
    12c0:      	mov	w8, #0x1001             // =4097
    12c4:      	add	x0, x23, #0x4
    12c8:      	b	0x1ac8 <generic_kprobe_process_event+0x1768>
    12cc:      	ldr	x25, [sp, #0x30]
    12d0:      	ldr	x2, [sp, #0x48]
    12d4:      	cmp	w23, #0x20
    12d8:      	b.le	0x15c0 <generic_kprobe_process_event+0x1260>
    12dc:      	sub	w8, w23, #0x21
    12e0:      	cmp	w8, #0x4
    12e4:      	b.hs	0x14a4 <generic_kprobe_process_event+0x1144>
    12e8:      	mov	w22, #0x8               // =8
    12ec:      	mov	w8, #0x4                // =4
    12f0:      	mov	x0, x25
    12f4:      	mov	w1, #0x8                // =8
    12f8:      	blr	x8
    12fc:      	b	0x2adc <generic_kprobe_process_event+0x277c>
    1300:      	cmp	w23, #0x27
    1304:      	b.eq	0x1aa8 <generic_kprobe_process_event+0x1748>
    1308:      	cmp	w23, #0x28
    130c:      	b.eq	0x1ae4 <generic_kprobe_process_event+0x1784>
    1310:      	cmp	w23, #0x2c
    1314:      	mov	w10, #0x5ea0            // =24224
    1318:      	b.ne	0x322c <generic_kprobe_process_event+0x2ecc>
    131c:      	ldr	x0, [sp, #0x30]
    1320:      	add	x8, sp, #0xe0
    1324:      	strb	wzr, [sp, #0x98]
    1328:      	mov	w9, #0x4                // =4
    132c:      	mov	w1, #0x2                // =2
    1330:      	ldr	x22, [x8]
    1334:      	mov	w8, #0x2                // =2
    1338:      	stp	xzr, xzr, [x0]
    133c:      	stp	xzr, xzr, [x0, #0x10]
    1340:      	mov	x2, x22
    1344:      	stp	xzr, xzr, [x0, #0x20]
    1348:      	stp	xzr, xzr, [x0, #0x30]
    134c:      	stp	xzr, xzr, [x0, #0x40]
    1350:      	stp	xzr, xzr, [x0, #0x50]
    1354:      	stp	xzr, xzr, [x0, #0x60]
    1358:      	blr	x9
    135c:      	tbnz	x0, #0x3f, 0x2374 <generic_kprobe_process_event+0x2014>
    1360:      	add	x23, x22, #0x2
    1364:      	mov	w8, #0x1                // =1
    1368:      	mov	w9, #0x4                // =4
    136c:      	add	x10, sp, #0x98
    1370:      	add	x0, sp, #0x98
    1374:      	mov	w1, #0x1                // =1
    1378:      	mov	x2, x23
    137c:      	blr	x9
    1380:      	tbnz	x0, #0x3f, 0x2374 <generic_kprobe_process_event+0x2014>
    1384:      	ldrb	w8, [sp, #0x98]
    1388:      	ldr	x10, [sp, #0x30]
    138c:      	cmp	w8, #0x0
    1390:      	add	x0, x10, #0x4
    1394:      	cset	w9, eq
    1398:      	strb	w9, [x10, #0x2]
    139c:      	cbz	w8, 0x234c <generic_kprobe_process_event+0x1fec>
    13a0:      	mov	w8, #0x6c               // =108
    13a4:      	mov	w9, #0x2d               // =45
    13a8:      	mov	w1, #0x6c               // =108
    13ac:      	mov	x2, x23
    13b0:      	blr	x9
    13b4:      	adrp	x25, 0x1000 <generic_kprobe_process_event+0xca0>
    13b8:      	ldr	x25, [x25]
    13bc:      	tbnz	w0, #0x1f, 0x2374 <generic_kprobe_process_event+0x2014>
    13c0:      	sub	w21, w0, #0x1
    13c4:      	b	0x236c <generic_kprobe_process_event+0x200c>
    13c8:      	cmp	w23, #0x7
    13cc:      	b.gt	0x1638 <generic_kprobe_process_event+0x12d8>
    13d0:      	cmp	w23, #0x2
    13d4:      	b.eq	0x1b60 <generic_kprobe_process_event+0x1800>
    13d8:      	ldr	x11, [sp, #0x38]
    13dc:      	cmp	w23, #0x3
    13e0:      	mov	w10, #0x5ea0            // =24224
    13e4:      	b.ne	0x2ae4 <generic_kprobe_process_event+0x2784>
    13e8:      	ldr	x8, [sp, #0x40]
    13ec:      	add	x23, x0, #0x90
    13f0:      	mov	x25, x0
    13f4:      	add	x29, x23, x29
    13f8:      	and	w8, w8, #0xf
    13fc:      	cmp	w8, #0x2
    1400:      	b.le	0x22c4 <generic_kprobe_process_event+0x1f64>
    1404:      	cmp	w8, #0x3
    1408:      	b.eq	0x2458 <generic_kprobe_process_event+0x20f8>
    140c:      	cmp	w8, #0x4
    1410:      	b.eq	0x2460 <generic_kprobe_process_event+0x2100>
    1414:      	cmp	w8, #0x5
    1418:      	b.ne	0x24b4 <generic_kprobe_process_event+0x2154>
    141c:      	mov	w8, #0x5e70             // =24176
    1420:      	b	0x246c <generic_kprobe_process_event+0x210c>
    1424:      	ldr	x0, [sp, #0x30]
    1428:      	mov	w8, #0x2                // =2
    142c:      	add	x9, sp, #0xe0
    1430:      	mov	w10, #0x4               // =4
    1434:      	mov	w22, #0x4               // =4
    1438:      	add	x2, sp, #0xe0
    143c:      	mov	w1, #0x2                // =2
    1440:      	blr	x10
    1444:      	b	0x1494 <generic_kprobe_process_event+0x1134>
    1448:      	cmp	w23, #0x1
    144c:      	b.eq	0x1478 <generic_kprobe_process_event+0x1118>
    1450:      	cmp	w23, #0x4
    1454:      	b.ne	0x322c <generic_kprobe_process_event+0x2ecc>
    1458:      	ldr	x0, [sp, #0x30]
    145c:      	mov	w22, #0x8               // =8
    1460:      	mov	w8, #0x4                // =4
    1464:      	add	x9, sp, #0xe0
    1468:      	add	x2, sp, #0xe0
    146c:      	mov	w1, #0x8                // =8
    1470:      	blr	x8
    1474:      	b	0x1494 <generic_kprobe_process_event+0x1134>
    1478:      	ldr	x0, [sp, #0x30]
    147c:      	add	x8, sp, #0xe0
    1480:      	mov	w9, #0x4                // =4
    1484:      	add	x2, sp, #0xe0
    1488:      	mov	w1, #0x4                // =4
    148c:      	mov	w22, #0x4               // =4
    1490:      	blr	x9
    1494:      	ldr	x11, [sp, #0x38]
    1498:      	ldr	x23, [sp, #0x50]
    149c:      	mov	w10, #0x5ea0            // =24224
    14a0:      	b	0x3230 <generic_kprobe_process_event+0x2ed0>
    14a4:      	cmp	w23, #0x2b
    14a8:      	b.eq	0x1e34 <generic_kprobe_process_event+0x1ad4>
    14ac:      	ldr	x11, [sp, #0x38]
    14b0:      	cmp	w23, #0x29
    14b4:      	mov	w21, #0x5efc            // =24316
    14b8:      	mov	w10, #0x5ea0            // =24224
    14bc:      	b.ne	0x2ae4 <generic_kprobe_process_event+0x2784>
    14c0:      	add	x2, x2, #0x18
    14c4:      	mov	w8, #0x8                // =8
    14c8:      	mov	w9, #0x4                // =4
    14cc:      	add	x10, sp, #0x98
    14d0:      	mov	x24, x0
    14d4:      	add	x0, sp, #0x98
    14d8:      	mov	w1, #0x8                // =8
    14dc:      	mov	x29, x11
    14e0:      	blr	x9
    14e4:      	ldr	x23, [sp, #0x98]
    14e8:      	cbz	x23, 0x2408 <generic_kprobe_process_event+0x20a8>
    14ec:      	str	x23, [x25, #0x28]
    14f0:      	add	x0, x25, #0x26
    14f4:      	add	x2, x23, #0x10
    14f8:      	mov	w22, #0x2               // =2
    14fc:      	mov	w8, #0x4                // =4
    1500:      	mov	w1, #0x2                // =2
    1504:      	mov	w21, #0x4               // =4
    1508:      	blr	x8
    150c:      	add	x0, x25, #0x3a
    1510:      	add	x2, x23, #0x12
    1514:      	mov	w8, #0x1                // =1
    1518:      	mov	w9, #0x4                // =4
    151c:      	mov	w1, #0x1                // =1
    1520:      	blr	x9
    1524:      	add	x0, x25, #0x38
    1528:      	add	x2, x23, #0x21e
    152c:      	mov	w8, #0x4                // =4
    1530:      	mov	w1, #0x2                // =2
    1534:      	blr	x8
    1538:      	add	x0, x25, #0x24
    153c:      	add	x2, x23, #0x21c
    1540:      	mov	w8, #0x4                // =4
    1544:      	mov	w1, #0x2                // =2
    1548:      	blr	x8
    154c:      	add	x0, x25, #0x30
    1550:      	add	x2, x23, #0x214
    1554:      	mov	w8, #0x4                // =4
    1558:      	mov	w1, #0x4                // =4
    155c:      	blr	x8
    1560:      	add	x0, x25, #0x34
    1564:      	add	x2, x23, #0x210
    1568:      	mov	w1, #0x4                // =4
    156c:      	blr	x21
    1570:      	ldrh	w8, [x25, #0x26]
    1574:      	mov	x22, x25
    1578:      	stp	xzr, xzr, [x25]
    157c:      	cmp	w8, #0xa
    1580:      	str	xzr, [x25, #0x18]
    1584:      	str	xzr, [x22, #0x10]!
    1588:      	b.eq	0x2398 <generic_kprobe_process_event+0x2038>
    158c:      	cmp	w8, #0x2
    1590:      	b.ne	0x23c4 <generic_kprobe_process_event+0x2064>
    1594:      	ldr	x0, [sp, #0x30]
    1598:      	add	x2, x23, #0x4
    159c:      	mov	w8, #0x4                // =4
    15a0:      	mov	w1, #0x4                // =4
    15a4:      	mov	w21, #0x4               // =4
    15a8:      	blr	x8
    15ac:      	mov	x0, x22
    15b0:      	mov	w1, #0x4                // =4
    15b4:      	mov	x2, x23
    15b8:      	blr	x21
    15bc:      	b	0x23c4 <generic_kprobe_process_event+0x2064>
    15c0:      	cmp	w23, #0x1a
    15c4:      	b.eq	0x1ec0 <generic_kprobe_process_event+0x1b60>
    15c8:      	ldr	x11, [sp, #0x38]
    15cc:      	cmp	w23, #0x1b
    15d0:      	mov	w10, #0x5ea0            // =24224
    15d4:      	b.ne	0x2ae4 <generic_kprobe_process_event+0x2784>
    15d8:      	mov	x0, x25
    15dc:      	stp	xzr, xzr, [x25, #0x40]
    15e0:      	add	x2, x2, #0x18
    15e4:      	mov	w8, #0x3f               // =63
    15e8:      	mov	w9, #0x2d               // =45
    15ec:      	mov	w1, #0x3f               // =63
    15f0:      	stp	xzr, xzr, [x25, #0x30]
    15f4:      	mov	x23, x11
    15f8:      	str	xzr, [x25, #0x18]
    15fc:      	stp	xzr, xzr, [x25, #0x20]
    1600:      	str	xzr, [x0, #0x10]!
    1604:      	stp	xzr, xzr, [x25]
    1608:      	blr	x9
    160c:      	tbnz	x0, #0x3f, 0x2338 <generic_kprobe_process_event+0x1fd8>
    1610:      	ldr	x8, [sp, #0x30]
    1614:      	mov	w9, #0x4                // =4
    1618:      	mov	w1, #0x8                // =8
    161c:      	add	x0, x8, #0x8
    1620:      	ldr	x8, [sp, #0x48]
    1624:      	add	x2, x8, #0x360
    1628:      	mov	w8, #0x8                // =8
    162c:      	blr	x9
    1630:      	mov	w22, #0x50              // =80
    1634:      	b	0x233c <generic_kprobe_process_event+0x1fdc>
    1638:      	cmp	w23, #0x8
    163c:      	b.eq	0x1bac <generic_kprobe_process_event+0x184c>
    1640:      	ldr	x11, [sp, #0x38]
    1644:      	ldr	x2, [sp, #0x48]
    1648:      	cmp	w23, #0x12
    164c:      	mov	w21, #0x5efc            // =24316
    1650:      	mov	w10, #0x5ea0            // =24224
    1654:      	b.ne	0x2ae4 <generic_kprobe_process_event+0x2784>
    1658:      	ldr	x8, [sp, #0x40]
    165c:      	mov	x0, x25
    1660:      	mov	x23, x11
    1664:      	and	x22, x8, #0x3ff
    1668:      	mov	w8, #0x4                // =4
    166c:      	mov	w1, w22
    1670:      	blr	x8
    1674:      	mov	x11, x23
    1678:      	b	0x2ae0 <generic_kprobe_process_event+0x2780>
    167c:      	cmp	w23, #0x13
    1680:      	b.eq	0x1df4 <generic_kprobe_process_event+0x1a94>
    1684:      	ldr	x11, [sp, #0x38]
    1688:      	ldr	x29, [sp, #0x48]
    168c:      	cmp	w23, #0x14
    1690:      	mov	w21, #0x5efc            // =24316
    1694:      	mov	w10, #0x5ea0            // =24224
    1698:      	b.ne	0x2ae4 <generic_kprobe_process_event+0x2784>
    169c:      	str	xzr, [sp, #0x98]
    16a0:      	add	x2, x29, #0x110
    16a4:      	mov	w23, #0x8               // =8
    16a8:      	add	x8, sp, #0x98
    16ac:      	mov	w9, #0x4                // =4
    16b0:      	add	x0, sp, #0x98
    16b4:      	mov	w1, #0x8                // =8
    16b8:      	add	x22, x29, #0xd8
    16bc:      	mov	w21, #0x4               // =4
    16c0:      	mov	x24, x11
    16c4:      	blr	x9
    16c8:      	ldr	x8, [sp, #0x98]
    16cc:      	mov	w9, #0x80               // =128
    16d0:      	mov	w10, #0x2d              // =45
    16d4:      	mov	x0, x25
    16d8:      	ldr	x2, [sp, #0x98]
    16dc:      	mov	w1, #0x80               // =128
    16e0:      	blr	x10
    16e4:      	add	x0, x25, #0x90
    16e8:      	mov	w8, #0x4                // =4
    16ec:      	mov	w1, #0x4                // =4
    16f0:      	mov	x2, x22
    16f4:      	blr	x8
    16f8:      	add	x0, x25, #0x80
    16fc:      	add	x2, x29, #0xe0
    1700:      	mov	w8, #0x4                // =4
    1704:      	mov	w1, #0x8                // =8
    1708:      	blr	x8
    170c:      	add	x0, x25, #0x88
    1710:      	add	x2, x29, #0x118
    1714:      	mov	w1, #0x8                // =8
    1718:      	blr	x21
    171c:      	mov	x11, x24
    1720:      	mov	w10, #0x5ea0            // =24224
    1724:      	mov	w21, #0x5efc            // =24316
    1728:      	mov	w22, #0x98              // =152
    172c:      	b	0x2ae4 <generic_kprobe_process_event+0x2784>
    1730:      	cmp	w23, #0x26
    1734:      	mov	w10, #0x5ea0            // =24224
    1738:      	b.ne	0x322c <generic_kprobe_process_event+0x2ecc>
    173c:      	add	x8, sp, #0xe0
    1740:      	ldr	x23, [sp, #0x30]
    1744:      	ldr	x8, [x8]
    1748:      	add	x0, x23, #0x4
    174c:      	add	x2, x19, w8, uxth
    1750:      	ubfx	w8, w8, #16, #12
    1754:      	add	w1, w8, #0x1
    1758:      	mov	w8, #0x2d               // =45
    175c:      	blr	x8
    1760:      	b	0x1acc <generic_kprobe_process_event+0x176c>
    1764:      	str	xzr, [sp, #0xa0]
    1768:      	mov	w8, #0xe                // =14
    176c:      	blr	x8
    1770:      	lsr	x8, x0, #32
    1774:      	add	x9, sp, #0xf0
    1778:      	add	x10, sp, #0xe0
    177c:      	str	x8, [sp, #0x98]
    1780:      	mov	w8, #0x4                // =4
    1784:      	add	x0, sp, #0xf0
    1788:      	add	x2, sp, #0xe0
    178c:      	mov	w1, #0x4                // =4
    1790:      	blr	x8
    1794:      	ldr	w8, [sp, #0xf0]
    1798:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    179c:      	add	x9, sp, #0x98
    17a0:      	add	x1, sp, #0x98
    17a4:      	str	w8, [sp, #0xa0]
    17a8:      	mov	w8, #0x1                // =1
    17ac:      	ldr	x0, [x0]
    17b0:      	blr	x8
    17b4:      	cbz	x0, 0x1f98 <generic_kprobe_process_event+0x1c38>
    17b8:      	ldr	x24, [sp, #0x30]
    17bc:      	ldr	w21, [x0]
    17c0:      	add	x8, sp, #0xf0
    17c4:      	mov	w9, #0x4                // =4
    17c8:      	add	x2, sp, #0xf0
    17cc:      	mov	x22, x0
    17d0:      	mov	w1, #0x4                // =4
    17d4:      	mov	w23, #0x4               // =4
    17d8:      	mov	x0, x24
    17dc:      	blr	x9
    17e0:      	and	x21, x21, #0xfff
    17e4:      	add	x0, x24, #0x4
    17e8:      	mov	w8, #0x4                // =4
    17ec:      	mov	x2, x22
    17f0:      	add	x1, x21, #0x4
    17f4:      	blr	x8
    17f8:      	add	w21, w21, #0x8
    17fc:      	mov	w1, #0x4                // =4
    1800:      	add	x8, x21, x22
    1804:      	add	x0, x24, x21
    1808:      	sub	x2, x8, #0x4
    180c:      	blr	x23
    1810:      	add	x22, x21, #0x4
    1814:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    1818:      	add	x8, sp, #0xe0
    181c:      	mov	w9, #0x4                // =4
    1820:      	add	x10, sp, #0x84
    1824:      	ldr	x22, [x8]
    1828:      	mov	w8, #0x1                // =1
    182c:      	mov	x25, x0
    1830:      	add	x0, sp, #0x84
    1834:      	mov	w1, #0x1                // =1
    1838:      	mov	x2, x22
    183c:      	blr	x9
    1840:      	ldrb	w8, [sp, #0x84]
    1844:      	cbz	w8, 0x1fa0 <generic_kprobe_process_event+0x1c40>
    1848:      	cmp	w8, #0x1
    184c:      	b.ne	0x21ec <generic_kprobe_process_event+0x1e8c>
    1850:      	add	x2, x22, #0x10
    1854:      	mov	w23, #0x8               // =8
    1858:      	add	x8, sp, #0xf0
    185c:      	mov	w9, #0x4                // =4
    1860:      	add	x0, sp, #0xf0
    1864:      	mov	w1, #0x8                // =8
    1868:      	mov	w21, #0x4               // =4
    186c:      	blr	x9
    1870:      	add	x22, sp, #0xe0
    1874:      	add	x8, sp, #0x100
    1878:      	mov	w9, #0x4                // =4
    187c:      	ldr	x2, [x22, #0x10]
    1880:      	add	x0, sp, #0x100
    1884:      	mov	w1, #0x8                // =8
    1888:      	blr	x9
    188c:      	ldr	x8, [x22, #0x10]
    1890:      	add	x0, sp, #0xe8
    1894:      	mov	w1, #0x8                // =8
    1898:      	add	x2, x8, #0x8
    189c:      	add	x8, sp, #0xe8
    18a0:      	blr	x21
    18a4:      	ldr	x8, [x22, #0x20]
    18a8:      	ldr	x22, [x22, #0x8]
    18ac:      	str	x8, [sp, #0x48]
    18b0:      	add	x8, x25, #0x90
    18b4:      	add	x29, x8, x29
    18b8:      	tbz	w24, #0x5, 0x25b8 <generic_kprobe_process_event+0x2258>
    18bc:      	cmp	x22, #0x1, lsl #12      // =0x1000
    18c0:      	b.lo	0x25a0 <generic_kprobe_process_event+0x2240>
    18c4:      	mov	w8, #0x1                // =1
    18c8:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    18cc:      	add	x9, sp, #0x90
    18d0:      	str	w8, [x29]
    18d4:      	str	wzr, [sp, #0x90]
    18d8:      	add	x1, sp, #0x90
    18dc:      	ldr	x0, [x0]
    18e0:      	blr	x8
    18e4:      	cbz	x0, 0x26c0 <generic_kprobe_process_event+0x2360>
    18e8:      	mov	w8, #0x18               // =24
    18ec:      	mov	x24, x0
    18f0:      	str	w8, [x0]
    18f4:      	mov	w8, #0xe                // =14
    18f8:      	blr	x8
    18fc:      	mov	x21, x24
    1900:      	cmn	x0, #0x16
    1904:      	str	x0, [x21, #0x10]!
    1908:      	b.ne	0x1930 <generic_kprobe_process_event+0x15d0>
    190c:      	add	x2, x19, #0xe8
    1910:      	mov	w8, #0x8                // =8
    1914:      	mov	w9, #0x4                // =4
    1918:      	add	x10, sp, #0x98
    191c:      	add	x0, sp, #0x98
    1920:      	mov	w1, #0x8                // =8
    1924:      	blr	x9
    1928:      	ldr	x8, [sp, #0x98]
    192c:      	str	x8, [x21]
    1930:      	mov	w8, #0x7d               // =125
    1934:      	blr	x8
    1938:      	str	x0, [x24, #0x18]
    193c:      	ldr	x2, [sp, #0x48]
    1940:      	mov	x0, x19
    1944:      	mov	x1, x24
    1948:      	b	0x207c <generic_kprobe_process_event+0x1d1c>
    194c:      	add	x8, sp, #0xe0
    1950:      	ldr	x21, [sp, #0x30]
    1954:      	mov	w1, #0x4                // =4
    1958:      	mov	w23, #0x4               // =4
    195c:      	ldr	x24, [x8]
    1960:      	mov	w8, #0x4                // =4
    1964:      	add	x0, x21, #0x28
    1968:      	add	x2, x24, #0x98
    196c:      	blr	x8
    1970:      	add	x0, x21, #0x2c
    1974:      	add	x2, x24, #0x70
    1978:      	mov	w8, #0x4                // =4
    197c:      	mov	w1, #0x4                // =4
    1980:      	blr	x8
    1984:      	add	x0, x21, #0x30
    1988:      	add	x2, x24, #0x90
    198c:      	mov	w8, #0x4                // =4
    1990:      	mov	w1, #0x4                // =4
    1994:      	blr	x8
    1998:      	add	x0, x21, #0x34
    199c:      	add	x2, x24, #0xa8
    19a0:      	mov	w8, #0x4                // =4
    19a4:      	mov	w1, #0x4                // =4
    19a8:      	blr	x8
    19ac:      	str	xzr, [sp, #0x98]
    19b0:      	add	x2, x24, #0xc8
    19b4:      	mov	w8, #0x8                // =8
    19b8:      	add	x9, sp, #0x98
    19bc:      	mov	w10, #0x4               // =4
    19c0:      	add	x0, sp, #0x98
    19c4:      	mov	w1, #0x8                // =8
    19c8:      	blr	x10
    19cc:      	add	x2, x24, #0xb8
    19d0:      	mov	w8, #0x2                // =2
    19d4:      	add	x9, sp, #0xe8
    19d8:      	mov	w10, #0x4               // =4
    19dc:      	add	x0, sp, #0xe8
    19e0:      	mov	w1, #0x2                // =2
    19e4:      	blr	x10
    19e8:      	ldr	x8, [sp, #0x98]
    19ec:      	ldrh	w9, [sp, #0xe8]
    19f0:      	add	x0, sp, #0xdc
    19f4:      	mov	w1, #0x1                // =1
    19f8:      	add	x22, x8, x9
    19fc:      	mov	w8, #0x1                // =1
    1a00:      	add	x9, sp, #0xdc
    1a04:      	mov	x2, x22
    1a08:      	blr	x23
    1a0c:      	ldrb	w8, [sp, #0xdc]
    1a10:      	lsr	w8, w8, #4
    1a14:      	cmp	w8, #0x6
    1a18:      	b.eq	0x20a8 <generic_kprobe_process_event+0x1d48>
    1a1c:      	cmp	w8, #0x4
    1a20:      	b.ne	0x3214 <generic_kprobe_process_event+0x2eb4>
    1a24:      	add	x2, x22, #0x9
    1a28:      	mov	w8, #0x1                // =1
    1a2c:      	add	x9, sp, #0x84
    1a30:      	mov	w10, #0x4               // =4
    1a34:      	add	x0, sp, #0x84
    1a38:      	mov	w1, #0x1                // =1
    1a3c:      	mov	w21, #0x4               // =4
    1a40:      	blr	x10
    1a44:      	ldr	x0, [sp, #0x30]
    1a48:      	ldrb	w8, [sp, #0x84]
    1a4c:      	mov	w25, #0x2               // =2
    1a50:      	add	x2, x22, #0xc
    1a54:      	mov	w1, #0x4                // =4
    1a58:      	mov	x23, x0
    1a5c:      	strh	w8, [x0, #0x24]
    1a60:      	strh	w25, [x0, #0x26]
    1a64:      	stp	xzr, xzr, [x0]
    1a68:      	str	xzr, [x0, #0x18]
    1a6c:      	mov	w8, #0x4                // =4
    1a70:      	str	xzr, [x23, #0x10]!
    1a74:      	blr	x8
    1a78:      	add	x2, x22, #0x10
    1a7c:      	mov	w8, #0x4                // =4
    1a80:      	mov	x0, x23
    1a84:      	mov	w1, #0x4                // =4
    1a88:      	blr	x8
    1a8c:      	add	x2, x24, #0xb6
    1a90:      	add	x8, sp, #0x90
    1a94:      	add	x0, sp, #0x90
    1a98:      	mov	w1, #0x2                // =2
    1a9c:      	blr	x21
    1aa0:      	ldrb	w25, [sp, #0x84]
    1aa4:      	b	0x30d8 <generic_kprobe_process_event+0x2d78>
    1aa8:      	add	x8, sp, #0xe0
    1aac:      	ldr	x23, [sp, #0x30]
    1ab0:      	mov	w9, #0x2d               // =45
    1ab4:      	mov	w1, #0x11               // =17
    1ab8:      	ldr	x8, [x8]
    1abc:      	add	x0, x23, #0x4
    1ac0:      	add	x2, x8, #0x118
    1ac4:      	mov	w8, #0x11               // =17
    1ac8:      	blr	x9
    1acc:      	mov	x22, x0
    1ad0:      	tbnz	x0, #0x3f, 0x3224 <generic_kprobe_process_event+0x2ec4>
    1ad4:      	sub	w8, w22, #0x1
    1ad8:      	add	x22, x22, #0x3
    1adc:      	str	w8, [x23]
    1ae0:      	b	0x3224 <generic_kprobe_process_event+0x2ec4>
    1ae4:      	ldr	x23, [sp, #0x30]
    1ae8:      	add	x8, sp, #0xe0
    1aec:      	mov	w9, #0x4                // =4
    1af0:      	mov	w1, #0x2                // =2
    1af4:      	ldr	x22, [x8]
    1af8:      	mov	w8, #0x2                // =2
    1afc:      	str	xzr, [x23]
    1b00:      	stp	xzr, xzr, [x23, #0x8]
    1b04:      	mov	x0, x23
    1b08:      	mov	x2, x22
    1b0c:      	blr	x9
    1b10:      	tbnz	x0, #0x3f, 0x2330 <generic_kprobe_process_event+0x1fd0>
    1b14:      	ldrh	w8, [x23]
    1b18:      	cmp	w8, #0xa
    1b1c:      	b.eq	0x22dc <generic_kprobe_process_event+0x1f7c>
    1b20:      	cmp	w8, #0x2
    1b24:      	b.ne	0x2310 <generic_kprobe_process_event+0x1fb0>
    1b28:      	add	x2, x22, #0x4
    1b2c:      	add	x8, sp, #0x98
    1b30:      	mov	w9, #0x4                // =4
    1b34:      	add	x0, sp, #0x98
    1b38:      	mov	w1, #0x4                // =4
    1b3c:      	mov	w21, #0x4               // =4
    1b40:      	blr	x9
    1b44:      	ldr	w8, [sp, #0x98]
    1b48:      	ldr	x9, [sp, #0x30]
    1b4c:      	add	x2, x22, #0x2
    1b50:      	add	x0, x9, #0x2
    1b54:      	str	x8, [x9, #0x8]
    1b58:      	mov	w8, #0x2                // =2
    1b5c:      	b	0x2308 <generic_kprobe_process_event+0x1fa8>
    1b60:      	add	x25, x0, #0x90
    1b64:      	mov	x22, x0
    1b68:      	add	x8, sp, #0xe0
    1b6c:      	str	xzr, [x8]
    1b70:      	add	x23, x25, x29
    1b74:      	tbnz	w24, #0x4, 0x21fc <generic_kprobe_process_event+0x1e9c>
    1b78:      	and	w9, w24, #0xf
    1b7c:      	mov	x8, xzr
    1b80:      	and	x29, x24, #0xffffffff
    1b84:      	cmp	w9, #0x2
    1b88:      	b.le	0x2380 <generic_kprobe_process_event+0x2020>
    1b8c:      	cmp	w9, #0x3
    1b90:      	b.eq	0x26d4 <generic_kprobe_process_event+0x2374>
    1b94:      	cmp	w9, #0x4
    1b98:      	b.eq	0x26dc <generic_kprobe_process_event+0x237c>
    1b9c:      	cmp	w9, #0x5
    1ba0:      	b.ne	0x26f0 <generic_kprobe_process_event+0x2390>
    1ba4:      	mov	w8, #0x5e70             // =24176
    1ba8:      	b	0x26e8 <generic_kprobe_process_event+0x2388>
    1bac:      	ldr	x29, [sp, #0x48]
    1bb0:      	mov	w8, #0x4                // =4
    1bb4:      	mov	x0, x25
    1bb8:      	mov	w1, #0x4                // =4
    1bbc:      	add	x22, x25, #0x28
    1bc0:      	add	x24, x25, #0x40
    1bc4:      	mov	w23, #0x4               // =4
    1bc8:      	add	x2, x29, #0x8
    1bcc:      	blr	x8
    1bd0:      	add	x0, x25, #0x4
    1bd4:      	add	x2, x29, #0xc
    1bd8:      	mov	w8, #0x4                // =4
    1bdc:      	mov	w1, #0x4                // =4
    1be0:      	blr	x8
    1be4:      	add	x0, x25, #0x10
    1be8:      	add	x2, x29, #0x18
    1bec:      	mov	w8, #0x4                // =4
    1bf0:      	mov	w1, #0x4                // =4
    1bf4:      	blr	x8
    1bf8:      	add	x0, x25, #0x14
    1bfc:      	add	x2, x29, #0x1c
    1c00:      	mov	w8, #0x4                // =4
    1c04:      	mov	w1, #0x4                // =4
    1c08:      	blr	x8
    1c0c:      	add	x0, x25, #0x8
    1c10:      	add	x2, x29, #0x10
    1c14:      	mov	w8, #0x4                // =4
    1c18:      	mov	w1, #0x4                // =4
    1c1c:      	blr	x8
    1c20:      	add	x0, x25, #0xc
    1c24:      	add	x2, x29, #0x14
    1c28:      	mov	w8, #0x4                // =4
    1c2c:      	mov	w1, #0x4                // =4
    1c30:      	blr	x8
    1c34:      	add	x0, x25, #0x18
    1c38:      	add	x2, x29, #0x20
    1c3c:      	mov	w8, #0x4                // =4
    1c40:      	mov	w1, #0x4                // =4
    1c44:      	blr	x8
    1c48:      	add	x0, x25, #0x1c
    1c4c:      	add	x2, x29, #0x24
    1c50:      	mov	w8, #0x4                // =4
    1c54:      	mov	w1, #0x4                // =4
    1c58:      	blr	x8
    1c5c:      	str	wzr, [x25, #0x24]
    1c60:      	add	x0, x25, #0x20
    1c64:      	add	x2, x29, #0x28
    1c68:      	mov	w8, #0x4                // =4
    1c6c:      	mov	w1, #0x4                // =4
    1c70:      	blr	x8
    1c74:      	add	x0, x25, #0x30
    1c78:      	add	x2, x29, #0x40
    1c7c:      	mov	w21, #0x8               // =8
    1c80:      	mov	w8, #0x4                // =4
    1c84:      	mov	w1, #0x8                // =8
    1c88:      	blr	x8
    1c8c:      	add	x0, x25, #0x38
    1c90:      	add	x2, x29, #0x30
    1c94:      	mov	w8, #0x4                // =4
    1c98:      	mov	w1, #0x8                // =8
    1c9c:      	blr	x8
    1ca0:      	add	x2, x29, #0x38
    1ca4:      	mov	w8, #0x4                // =4
    1ca8:      	mov	x0, x22
    1cac:      	mov	w1, #0x8                // =8
    1cb0:      	blr	x8
    1cb4:      	add	x2, x29, #0x90
    1cb8:      	add	x8, sp, #0x98
    1cbc:      	mov	w9, #0x4                // =4
    1cc0:      	add	x0, sp, #0x98
    1cc4:      	mov	w1, #0x8                // =8
    1cc8:      	blr	x9
    1ccc:      	ldr	x21, [sp, #0x98]
    1cd0:      	mov	w8, #0x4                // =4
    1cd4:      	mov	x0, x24
    1cd8:      	mov	w1, #0x4                // =4
    1cdc:      	add	x2, x21, #0xc8
    1ce0:      	blr	x8
    1ce4:      	add	x0, x25, #0x44
    1ce8:      	add	x2, x21, #0xcc
    1cec:      	mov	w8, #0x4                // =4
    1cf0:      	mov	w1, #0x4                // =4
    1cf4:      	blr	x8
    1cf8:      	add	x0, x25, #0x48
    1cfc:      	add	x2, x21, #0xd0
    1d00:      	mov	w8, #0x4                // =4
    1d04:      	mov	w1, #0x4                // =4
    1d08:      	blr	x8
    1d0c:      	add	x0, x25, #0x4c
    1d10:      	add	x2, x21, #0x158
    1d14:      	mov	w1, #0x4                // =4
    1d18:      	blr	x23
    1d1c:      	mov	w22, #0x50              // =80
    1d20:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    1d24:      	ldr	x22, [sp, #0x48]
    1d28:      	mov	w8, #0x4                // =4
    1d2c:      	mov	x0, x25
    1d30:      	mov	w1, #0x4                // =4
    1d34:      	mov	w21, #0x4               // =4
    1d38:      	add	x2, x22, #0xc8
    1d3c:      	blr	x8
    1d40:      	add	x0, x25, #0x4
    1d44:      	add	x2, x22, #0xcc
    1d48:      	mov	w8, #0x4                // =4
    1d4c:      	mov	w1, #0x4                // =4
    1d50:      	blr	x8
    1d54:      	add	x0, x25, #0x8
    1d58:      	add	x2, x22, #0xd0
    1d5c:      	mov	w8, #0x4                // =4
    1d60:      	mov	w1, #0x4                // =4
    1d64:      	blr	x8
    1d68:      	add	x0, x25, #0xc
    1d6c:      	add	x2, x22, #0x158
    1d70:      	mov	w1, #0x4                // =4
    1d74:      	blr	x21
    1d78:      	mov	w22, #0x10              // =16
    1d7c:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    1d80:      	ldr	x22, [sp, #0x48]
    1d84:      	mov	w8, #0x4                // =4
    1d88:      	mov	x0, x25
    1d8c:      	mov	w1, #0x4                // =4
    1d90:      	mov	w21, #0x4               // =4
    1d94:      	add	x2, x22, #0x38
    1d98:      	blr	x8
    1d9c:      	add	x0, x25, #0x4
    1da0:      	add	x2, x22, #0x3c
    1da4:      	mov	w8, #0x4                // =4
    1da8:      	mov	w1, #0x4                // =4
    1dac:      	blr	x8
    1db0:      	add	x0, x25, #0x8
    1db4:      	add	x2, x22, #0x40
    1db8:      	mov	w8, #0x4                // =4
    1dbc:      	mov	w1, #0x4                // =4
    1dc0:      	blr	x8
    1dc4:      	add	x0, x25, #0xc
    1dc8:      	add	x2, x22, #0x44
    1dcc:      	mov	w8, #0x4                // =4
    1dd0:      	mov	w1, #0x4                // =4
    1dd4:      	blr	x8
    1dd8:      	add	x0, x25, #0x10
    1ddc:      	add	x2, x22, #0x80
    1de0:      	mov	w8, #0x10               // =16
    1de4:      	mov	w1, #0x10               // =16
    1de8:      	blr	x21
    1dec:      	mov	w22, #0x20              // =32
    1df0:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    1df4:      	ldr	x22, [sp, #0x48]
    1df8:      	mov	w8, #0x4                // =4
    1dfc:      	mov	x0, x25
    1e00:      	mov	w1, #0x4                // =4
    1e04:      	mov	w21, #0x4               // =4
    1e08:      	mov	x2, x22
    1e0c:      	blr	x8
    1e10:      	add	x0, x25, #0x4
    1e14:      	add	x2, x22, #0x4
    1e18:      	mov	w8, #0x4                // =4
    1e1c:      	mov	w1, #0x4                // =4
    1e20:      	blr	x8
    1e24:      	add	x0, x25, #0x8
    1e28:      	add	x2, x22, #0x30
    1e2c:      	mov	w8, #0x10               // =16
    1e30:      	b	0x1eb0 <generic_kprobe_process_event+0x1b50>
    1e34:      	mov	x22, x2
    1e38:      	add	x2, x2, #0x4
    1e3c:      	add	x8, sp, #0x98
    1e40:      	mov	w9, #0x4                // =4
    1e44:      	add	x0, sp, #0x98
    1e48:      	mov	w1, #0x4                // =4
    1e4c:      	mov	w21, #0x4               // =4
    1e50:      	blr	x9
    1e54:      	ldr	w8, [sp, #0x98]
    1e58:      	add	x2, x22, #0xc
    1e5c:      	add	x0, sp, #0x98
    1e60:      	mov	w1, #0x4                // =4
    1e64:      	str	w8, [x25]
    1e68:      	add	x8, sp, #0x98
    1e6c:      	blr	x21
    1e70:      	ldr	w8, [sp, #0x98]
    1e74:      	add	x2, x22, #0x50
    1e78:      	add	x9, sp, #0x98
    1e7c:      	mov	w10, #0x2d              // =45
    1e80:      	str	w8, [x25, #0x4]
    1e84:      	mov	w8, #0x8                // =8
    1e88:      	add	x0, sp, #0x98
    1e8c:      	mov	w1, #0x8                // =8
    1e90:      	mov	w21, #0x2d              // =45
    1e94:      	blr	x10
    1e98:      	ldr	x8, [sp, #0x98]
    1e9c:      	add	x0, x25, #0x8
    1ea0:      	mov	w9, #0x10               // =16
    1ea4:      	add	x8, x8, #0x3f8
    1ea8:      	ldr	x8, [sp, #0x98]
    1eac:      	add	x2, x8, #0x3f8
    1eb0:      	mov	w1, #0x10               // =16
    1eb4:      	blr	x21
    1eb8:      	mov	w22, #0x18              // =24
    1ebc:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    1ec0:      	stp	xzr, xzr, [x25, #0x40]
    1ec4:      	mov	w8, #0x8                // =8
    1ec8:      	mov	w9, #0x4                // =4
    1ecc:      	add	x10, sp, #0x98
    1ed0:      	add	x0, sp, #0x98
    1ed4:      	mov	w1, #0x8                // =8
    1ed8:      	stp	xzr, xzr, [x25, #0x30]
    1edc:      	stp	xzr, xzr, [x25, #0x20]
    1ee0:      	stp	xzr, xzr, [x25, #0x10]
    1ee4:      	stp	xzr, xzr, [x25]
    1ee8:      	blr	x9
    1eec:      	mov	x22, xzr
    1ef0:      	cbnz	x0, 0x2ad8 <generic_kprobe_process_event+0x2778>
    1ef4:      	ldr	x8, [sp, #0x30]
    1ef8:      	mov	w9, #0x3f               // =63
    1efc:      	mov	w10, #0x2d              // =45
    1f00:      	mov	w1, #0x3f               // =63
    1f04:      	add	x0, x8, #0x10
    1f08:      	ldr	x8, [sp, #0x98]
    1f0c:      	ldr	x2, [sp, #0x98]
    1f10:      	blr	x10
    1f14:      	tbnz	x0, #0x3f, 0x2640 <generic_kprobe_process_event+0x22e0>
    1f18:      	ldr	x23, [sp, #0x48]
    1f1c:      	mov	w21, #0x8               // =8
    1f20:      	add	x8, sp, #0xf0
    1f24:      	mov	w9, #0x4                // =4
    1f28:      	add	x0, sp, #0xf0
    1f2c:      	mov	w1, #0x8                // =8
    1f30:      	mov	w22, #0x4               // =4
    1f34:      	add	x2, x23, #0x8
    1f38:      	blr	x9
    1f3c:      	ldr	x8, [sp, #0x30]
    1f40:      	add	x10, sp, #0xe0
    1f44:      	mov	w9, #0x4                // =4
    1f48:      	mov	w1, #0x8                // =8
    1f4c:      	add	x0, x8, #0x8
    1f50:      	ldr	x8, [x10, #0x10]
    1f54:      	add	x8, x8, #0x360
    1f58:      	ldr	x8, [x10, #0x10]
    1f5c:      	add	x2, x8, #0x360
    1f60:      	blr	x9
    1f64:      	add	x2, x23, #0x58
    1f68:      	add	x8, sp, #0xf0
    1f6c:      	add	x0, sp, #0xf0
    1f70:      	mov	w1, #0x4                // =4
    1f74:      	blr	x22
    1f78:      	cbnz	x0, 0x1f90 <generic_kprobe_process_event+0x1c30>
    1f7c:      	ldr	w8, [sp, #0xf0]
    1f80:      	ldr	x9, [sp, #0x30]
    1f84:      	cmp	w8, #0x0
    1f88:      	cset	w8, ne
    1f8c:      	str	w8, [x9]
    1f90:      	mov	w22, #0x50              // =80
    1f94:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    1f98:      	mov	x22, #-0x1              // =-1
    1f9c:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    1fa0:      	add	x2, x22, #0x10
    1fa4:      	mov	w21, #0x8               // =8
    1fa8:      	add	x8, sp, #0x100
    1fac:      	mov	w9, #0x4                // =4
    1fb0:      	add	x0, sp, #0x100
    1fb4:      	mov	w1, #0x8                // =8
    1fb8:      	mov	w23, #0x4               // =4
    1fbc:      	blr	x9
    1fc0:      	add	x2, x22, #0x18
    1fc4:      	add	x8, sp, #0xe8
    1fc8:      	add	x0, sp, #0xe8
    1fcc:      	mov	w1, #0x8                // =8
    1fd0:      	blr	x23
    1fd4:      	add	x8, sp, #0xe0
    1fd8:      	ldr	x9, [sp, #0x40]
    1fdc:      	ldr	x23, [x8, #0x20]
    1fe0:      	ldr	x22, [x8, #0x8]
    1fe4:      	add	x8, x25, #0x90
    1fe8:      	add	x29, x8, x29
    1fec:      	tbz	w9, #0x5, 0x2600 <generic_kprobe_process_event+0x22a0>
    1ff0:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1ff4:      	b.lo	0x25e8 <generic_kprobe_process_event+0x2288>
    1ff8:      	mov	w8, #0x1                // =1
    1ffc:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    2000:      	add	x9, sp, #0x90
    2004:      	str	w8, [x29]
    2008:      	str	wzr, [sp, #0x90]
    200c:      	add	x1, sp, #0x90
    2010:      	ldr	x0, [x0]
    2014:      	blr	x8
    2018:      	cbz	x0, 0x26c0 <generic_kprobe_process_event+0x2360>
    201c:      	mov	w8, #0x18               // =24
    2020:      	mov	x24, x0
    2024:      	str	w8, [x0]
    2028:      	mov	w8, #0xe                // =14
    202c:      	blr	x8
    2030:      	mov	x21, x24
    2034:      	cmn	x0, #0x16
    2038:      	str	x0, [x21, #0x10]!
    203c:      	b.ne	0x2064 <generic_kprobe_process_event+0x1d04>
    2040:      	add	x2, x19, #0xe8
    2044:      	mov	w8, #0x8                // =8
    2048:      	mov	w9, #0x4                // =4
    204c:      	add	x10, sp, #0x98
    2050:      	add	x0, sp, #0x98
    2054:      	mov	w1, #0x8                // =8
    2058:      	blr	x9
    205c:      	ldr	x8, [sp, #0x98]
    2060:      	str	x8, [x21]
    2064:      	mov	w8, #0x7d               // =125
    2068:      	blr	x8
    206c:      	str	x0, [x24, #0x18]
    2070:      	mov	x0, x19
    2074:      	mov	x1, x24
    2078:      	mov	x2, x23
    207c:      	ldp	x8, x9, [x21]
    2080:      	stur	x9, [x29, #0x1c]
    2084:      	stur	x8, [x29, #0x14]
    2088:      	mov	x3, x22
    208c:      	bl	0x208c <generic_kprobe_process_event+0x1d2c>
    2090:      	tbnz	w0, #0x1f, 0x2830 <generic_kprobe_process_event+0x24d0>
    2094:      	sub	w8, w22, w0
    2098:      	cmn	x22, #0x1
    209c:      	stur	xzr, [x29, #0x4]
    20a0:      	csel	w8, wzr, w8, eq
    20a4:      	b	0x283c <generic_kprobe_process_event+0x24dc>
    20a8:      	ldr	x8, [sp, #0x98]
    20ac:      	ldrh	w21, [sp, #0xe8]
    20b0:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    20b4:      	add	x9, sp, #0xf0
    20b8:      	add	x1, sp, #0xf0
    20bc:      	add	x29, x8, x21
    20c0:      	str	x8, [sp, #0x48]
    20c4:      	str	wzr, [sp, #0xf0]
    20c8:      	mov	w8, #0x1                // =1
    20cc:      	ldr	x0, [x0]
    20d0:      	blr	x8
    20d4:      	cbz	x0, 0x3094 <generic_kprobe_process_event+0x2d34>
    20d8:      	mov	w8, #0xff               // =255
    20dc:      	strh	w21, [x0]
    20e0:      	strb	wzr, [x0, #0x7]
    20e4:      	add	x22, x0, #0x6
    20e8:      	add	x2, x29, #0x6
    20ec:      	mov	w9, #0x4                // =4
    20f0:      	strb	w8, [x0, #0x5]
    20f4:      	mov	w8, #0x1                // =1
    20f8:      	mov	x23, x0
    20fc:      	mov	x0, x22
    2100:      	mov	w1, #0x1                // =1
    2104:      	blr	x9
    2108:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    210c:      	ldrb	w8, [x23, #0x5]
    2110:      	cmp	w8, #0x32
    2114:      	b.gt	0x2648 <generic_kprobe_process_event+0x22e8>
    2118:      	cbz	w8, 0x26c8 <generic_kprobe_process_event+0x2368>
    211c:      	cmp	w8, #0x2b
    2120:      	b.eq	0x26c8 <generic_kprobe_process_event+0x2368>
    2124:      	cmp	w8, #0x2c
    2128:      	b.ne	0x2bc0 <generic_kprobe_process_event+0x2860>
    212c:      	mov	w8, #0x8                // =8
    2130:      	b	0x2b08 <generic_kprobe_process_event+0x27a8>
    2134:      	ldr	x0, [sp, #0x30]
    2138:      	add	x2, x23, #0x48
    213c:      	mov	w21, #0x10              // =16
    2140:      	mov	w8, #0x4                // =4
    2144:      	mov	w1, #0x10               // =16
    2148:      	mov	w25, #0x4               // =4
    214c:      	blr	x8
    2150:      	add	x2, x23, #0x38
    2154:      	mov	x0, x22
    2158:      	mov	w1, #0x10               // =16
    215c:      	blr	x25
    2160:      	ldr	x25, [sp, #0x30]
    2164:      	add	x2, x23, #0xe
    2168:      	mov	w21, #0x2               // =2
    216c:      	mov	w8, #0x4                // =4
    2170:      	mov	w1, #0x2                // =2
    2174:      	add	x22, x23, #0xc
    2178:      	mov	w23, #0x4               // =4
    217c:      	add	x0, x25, #0x20
    2180:      	blr	x8
    2184:      	add	x0, x25, #0x22
    2188:      	mov	w1, #0x2                // =2
    218c:      	mov	x2, x22
    2190:      	blr	x23
    2194:      	ldrh	w8, [x25, #0x22]
    2198:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    219c:      	add	x9, sp, #0x98
    21a0:      	add	x1, sp, #0x98
    21a4:      	rev	w8, w8
    21a8:      	lsr	w8, w8, #16
    21ac:      	strh	w8, [x25, #0x22]
    21b0:      	add	x8, sp, #0xe0
    21b4:      	ldr	x8, [x8]
    21b8:      	str	x8, [sp, #0x98]
    21bc:      	mov	w8, #0x1                // =1
    21c0:      	ldr	x0, [x0]
    21c4:      	blr	x8
    21c8:      	cbz	x0, 0x3214 <generic_kprobe_process_event+0x2eb4>
    21cc:      	ldr	w8, [x0]
    21d0:      	mov	w22, #0x40              // =64
    21d4:      	str	w8, [x24, #0x10]
    21d8:      	ldr	x8, [x0, #0x8]
    21dc:      	str	x8, [x24, #0x18]
    21e0:      	ldr	w8, [x0, #0x4]
    21e4:      	str	w8, [x24, #0x7c]
    21e8:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    21ec:      	add	x8, x25, x29
    21f0:      	mov	w22, #0x8               // =8
    21f4:      	str	xzr, [x8, #0x90]
    21f8:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    21fc:      	mov	w8, #0xe                // =14
    2200:      	blr	x8
    2204:      	cmn	x0, #0x16
    2208:      	b.ne	0x222c <generic_kprobe_process_event+0x1ecc>
    220c:      	add	x2, x19, #0xe8
    2210:      	mov	w8, #0x8                // =8
    2214:      	mov	w9, #0x4                // =4
    2218:      	add	x10, sp, #0x98
    221c:      	add	x0, sp, #0x98
    2220:      	mov	w1, #0x8                // =8
    2224:      	blr	x9
    2228:      	ldr	x0, [sp, #0x98]
    222c:      	ldr	x10, [x22, #0x8]
    2230:      	ldr	x9, [sp, #0x48]
    2234:      	mov	x3, xzr
    2238:      	add	x1, sp, #0xf0
    223c:      	add	x2, sp, #0x98
    2240:      	add	x21, sp, #0xe0
    2244:      	ldr	x8, [x22, #0x60]
    2248:      	str	xzr, [sp, #0xa8]
    224c:      	stp	x10, x9, [sp, #0x98]
    2250:      	add	x9, sp, #0xe0
    2254:      	add	x10, sp, #0x98
    2258:      	stp	x8, x0, [x9, #0x10]
    225c:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2260:      	mov	w8, #0x2                // =2
    2264:      	add	x9, sp, #0xf0
    2268:      	ldr	x0, [x0]
    226c:      	blr	x8
    2270:      	cbz	x0, 0x268c <generic_kprobe_process_event+0x232c>
    2274:      	neg	w8, w0
    2278:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    227c:      	mov	w9, #0x1                // =1
    2280:      	strh	w8, [sp, #0x100]
    2284:      	mov	w8, #0x5                // =5
    2288:      	add	x1, sp, #0x100
    228c:      	strh	w8, [sp, #0x102]
    2290:      	mov	x8, #0x46               // =70
    2294:      	movk	x8, #0x2, lsl #32
    2298:      	stur	x8, [x21, #0x24]
    229c:      	add	x8, sp, #0x100
    22a0:      	mov	w21, #0x1               // =1
    22a4:      	ldr	x22, [x22]
    22a8:      	mov	x0, x22
    22ac:      	blr	x9
    22b0:      	cbz	x0, 0x2668 <generic_kprobe_process_event+0x2308>
    22b4:      	ldr	w8, [x0]
    22b8:      	add	w8, w8, #0x1
    22bc:      	str	w8, [x0]
    22c0:      	b	0x268c <generic_kprobe_process_event+0x232c>
    22c4:      	cmp	w8, #0x1
    22c8:      	b.eq	0x2468 <generic_kprobe_process_event+0x2108>
    22cc:      	cmp	w8, #0x2
    22d0:      	b.ne	0x24b4 <generic_kprobe_process_event+0x2154>
    22d4:      	mov	w8, #0x5e58             // =24152
    22d8:      	b	0x246c <generic_kprobe_process_event+0x210c>
    22dc:      	ldr	x23, [sp, #0x30]
    22e0:      	add	x2, x22, #0x8
    22e4:      	mov	w8, #0x10               // =16
    22e8:      	mov	w9, #0x4                // =4
    22ec:      	mov	w1, #0x10               // =16
    22f0:      	mov	w21, #0x4               // =4
    22f4:      	add	x0, x23, #0x8
    22f8:      	blr	x9
    22fc:      	add	x0, x23, #0x2
    2300:      	add	x2, x22, #0x2
    2304:      	mov	w8, #0x2                // =2
    2308:      	mov	w1, #0x2                // =2
    230c:      	blr	x21
    2310:      	ldr	x9, [sp, #0x30]
    2314:      	adrp	x25, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2318:      	mov	w21, #0x5efc            // =24316
    231c:      	ldrh	w8, [x9, #0x2]
    2320:      	rev	w8, w8
    2324:      	lsr	w8, w8, #16
    2328:      	strh	w8, [x9, #0x2]
    232c:      	ldr	x25, [x25]
    2330:      	mov	w22, #0x18              // =24
    2334:      	b	0x3224 <generic_kprobe_process_event+0x2ec4>
    2338:      	mov	x22, xzr
    233c:      	mov	w21, #0x5efc            // =24316
    2340:      	mov	w10, #0x5ea0            // =24224
    2344:      	mov	x11, x23
    2348:      	b	0x2ae4 <generic_kprobe_process_event+0x2784>
    234c:      	add	x2, x22, #0x3
    2350:      	mov	w21, #0x6b              // =107
    2354:      	mov	w8, #0x71               // =113
    2358:      	mov	w1, #0x6b               // =107
    235c:      	blr	x8
    2360:      	adrp	x25, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2364:      	ldr	x25, [x25]
    2368:      	tbnz	w0, #0x1f, 0x2374 <generic_kprobe_process_event+0x2014>
    236c:      	ldr	x8, [sp, #0x30]
    2370:      	strb	w21, [x8, #0x3]
    2374:      	mov	w22, #0x70              // =112
    2378:      	mov	w21, #0x5efc            // =24316
    237c:      	b	0x3224 <generic_kprobe_process_event+0x2ec4>
    2380:      	cmp	w9, #0x1
    2384:      	b.eq	0x26e4 <generic_kprobe_process_event+0x2384>
    2388:      	cmp	w9, #0x2
    238c:      	b.ne	0x26f0 <generic_kprobe_process_event+0x2390>
    2390:      	mov	w8, #0x5e58             // =24152
    2394:      	b	0x26e8 <generic_kprobe_process_event+0x2388>
    2398:      	ldr	x0, [sp, #0x30]
    239c:      	add	x2, x23, #0x48
    23a0:      	mov	w21, #0x10              // =16
    23a4:      	mov	w8, #0x4                // =4
    23a8:      	mov	w1, #0x10               // =16
    23ac:      	mov	w25, #0x4               // =4
    23b0:      	blr	x8
    23b4:      	add	x2, x23, #0x38
    23b8:      	mov	x0, x22
    23bc:      	mov	w1, #0x10               // =16
    23c0:      	blr	x25
    23c4:      	ldr	x25, [sp, #0x30]
    23c8:      	add	x2, x23, #0xe
    23cc:      	mov	w21, #0x2               // =2
    23d0:      	mov	w8, #0x4                // =4
    23d4:      	mov	w1, #0x2                // =2
    23d8:      	add	x22, x23, #0xc
    23dc:      	mov	w23, #0x4               // =4
    23e0:      	add	x0, x25, #0x20
    23e4:      	blr	x8
    23e8:      	add	x0, x25, #0x22
    23ec:      	mov	w1, #0x2                // =2
    23f0:      	mov	x2, x22
    23f4:      	blr	x23
    23f8:      	ldrh	w8, [x25, #0x22]
    23fc:      	rev	w8, w8
    2400:      	lsr	w8, w8, #16
    2404:      	strh	w8, [x25, #0x22]
    2408:      	ldr	x8, [x25, #0x28]
    240c:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2410:      	add	x9, sp, #0x98
    2414:      	add	x1, sp, #0x98
    2418:      	str	x8, [sp, #0x98]
    241c:      	mov	w8, #0x1                // =1
    2420:      	ldr	x0, [x0]
    2424:      	blr	x8
    2428:      	cbz	x0, 0x2444 <generic_kprobe_process_event+0x20e4>
    242c:      	ldr	w8, [x0]
    2430:      	str	w8, [x24, #0x10]
    2434:      	ldr	x8, [x0, #0x8]
    2438:      	str	x8, [x24, #0x18]
    243c:      	ldr	w8, [x0, #0x4]
    2440:      	str	w8, [x24, #0x7c]
    2444:      	mov	w22, #0x40              // =64
    2448:      	mov	w21, #0x5efc            // =24316
    244c:      	mov	w10, #0x5ea0            // =24224
    2450:      	mov	x11, x29
    2454:      	b	0x2ae4 <generic_kprobe_process_event+0x2784>
    2458:      	mov	w8, #0x5e60             // =24160
    245c:      	b	0x246c <generic_kprobe_process_event+0x210c>
    2460:      	mov	w8, #0x5e68             // =24168
    2464:      	b	0x246c <generic_kprobe_process_event+0x210c>
    2468:      	mov	w8, #0x5e50             // =24144
    246c:      	add	x8, x25, x8
    2470:      	ldr	x24, [x8]
    2474:      	ldr	x8, [sp, #0x40]
    2478:      	tbnz	w8, #0x4, 0x24c4 <generic_kprobe_process_event+0x2164>
    247c:      	cbz	x24, 0x2590 <generic_kprobe_process_event+0x2230>
    2480:      	ldr	x2, [sp, #0x48]
    2484:      	mov	w8, #0x10               // =16
    2488:      	mov	w9, #0x4                // =4
    248c:      	add	x10, sp, #0x98
    2490:      	add	x0, sp, #0x98
    2494:      	mov	w1, #0x10               // =16
    2498:      	blr	x9
    249c:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    24a0:      	ldr	x22, [sp, #0xa0]
    24a4:      	cmp	x22, #0xffe
    24a8:      	b.ls	0x2848 <generic_kprobe_process_event+0x24e8>
    24ac:      	mov	w8, #-0x3               // =-3
    24b0:      	b	0x2ad0 <generic_kprobe_process_event+0x2770>
    24b4:      	ldr	x8, [sp, #0x40]
    24b8:      	mov	x24, xzr
    24bc:      	mov	x22, xzr
    24c0:      	tbz	w8, #0x4, 0x2594 <generic_kprobe_process_event+0x2234>
    24c4:      	mov	w8, #0xe                // =14
    24c8:      	blr	x8
    24cc:      	cmn	x0, #0x16
    24d0:      	b.ne	0x24f4 <generic_kprobe_process_event+0x2194>
    24d4:      	add	x2, x19, #0xe8
    24d8:      	mov	w8, #0x8                // =8
    24dc:      	mov	w9, #0x4                // =4
    24e0:      	add	x10, sp, #0x98
    24e4:      	add	x0, sp, #0x98
    24e8:      	mov	w1, #0x8                // =8
    24ec:      	blr	x9
    24f0:      	ldr	x0, [sp, #0x98]
    24f4:      	ldr	x10, [x25, #0x8]
    24f8:      	ldr	x9, [sp, #0x48]
    24fc:      	mov	x3, xzr
    2500:      	add	x1, sp, #0xf0
    2504:      	add	x2, sp, #0x98
    2508:      	add	x21, sp, #0xe0
    250c:      	ldr	x8, [x25, #0x60]
    2510:      	str	x24, [sp, #0xa8]
    2514:      	stp	x10, x9, [sp, #0x98]
    2518:      	add	x9, sp, #0xe0
    251c:      	add	x10, sp, #0x98
    2520:      	stp	x8, x0, [x9, #0x10]
    2524:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2528:      	mov	w8, #0x2                // =2
    252c:      	add	x9, sp, #0xf0
    2530:      	ldr	x0, [x0]
    2534:      	blr	x8
    2538:      	cbz	x0, 0x26b8 <generic_kprobe_process_event+0x2358>
    253c:      	neg	w8, w0
    2540:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2544:      	mov	w9, #0x1                // =1
    2548:      	strh	w8, [sp, #0x100]
    254c:      	mov	w8, #0x5                // =5
    2550:      	add	x1, sp, #0x100
    2554:      	strh	w8, [sp, #0x102]
    2558:      	mov	x8, #0x57               // =87
    255c:      	movk	x8, #0x2, lsl #32
    2560:      	stur	x8, [x21, #0x24]
    2564:      	add	x8, sp, #0x100
    2568:      	mov	w21, #0x1               // =1
    256c:      	ldr	x22, [x22]
    2570:      	mov	x0, x22
    2574:      	blr	x9
    2578:      	cbz	x0, 0x2694 <generic_kprobe_process_event+0x2334>
    257c:      	ldr	w8, [x0]
    2580:      	add	w8, w8, #0x1
    2584:      	str	w8, [x0]
    2588:      	mov	w8, #-0x4               // =-4
    258c:      	b	0x2ad0 <generic_kprobe_process_event+0x2770>
    2590:      	mov	x22, xzr
    2594:      	stp	w22, w22, [x29]
    2598:      	add	x22, x22, #0x8
    259c:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    25a0:      	ldr	x9, [sp, #0x118]
    25a4:      	str	wzr, [x29]
    25a8:      	mov	w23, #0xc               // =12
    25ac:      	add	w9, w9, #0x8
    25b0:      	and	x9, x9, #0x3fff
    25b4:      	add	x29, x8, x9
    25b8:      	cmp	x22, #0xfff
    25bc:      	mov	w8, #0xfff              // =4095
    25c0:      	ldr	x2, [sp, #0x48]
    25c4:      	add	x0, x29, #0x8
    25c8:      	csel	x24, x22, x8, lo
    25cc:      	mov	w8, #0x4                // =4
    25d0:      	mov	w1, w24
    25d4:      	blr	x8
    25d8:      	tbnz	w0, #0x1f, 0x2630 <generic_kprobe_process_event+0x22d0>
    25dc:      	stp	w22, w24, [x29]
    25e0:      	add	x22, x23, x24
    25e4:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    25e8:      	ldr	x9, [sp, #0x118]
    25ec:      	str	wzr, [x29]
    25f0:      	mov	w21, #0xc               // =12
    25f4:      	add	w9, w9, #0x8
    25f8:      	and	x9, x9, #0x3fff
    25fc:      	add	x29, x8, x9
    2600:      	cmp	x22, #0xfff
    2604:      	mov	w8, #0xfff              // =4095
    2608:      	add	x0, x29, #0x8
    260c:      	mov	x2, x23
    2610:      	csel	x24, x22, x8, lo
    2614:      	mov	w8, #0x4                // =4
    2618:      	mov	w1, w24
    261c:      	blr	x8
    2620:      	tbnz	w0, #0x1f, 0x2630 <generic_kprobe_process_event+0x22d0>
    2624:      	stp	w22, w24, [x29]
    2628:      	add	x22, x21, x24
    262c:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    2630:      	mov	w8, #-0x2               // =-2
    2634:      	mov	w22, #0x4               // =4
    2638:      	str	w8, [x29]
    263c:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    2640:      	mov	x22, xzr
    2644:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    2648:      	cmp	w8, #0x33
    264c:      	b.eq	0x2afc <generic_kprobe_process_event+0x279c>
    2650:      	cmp	w8, #0x3c
    2654:      	b.eq	0x26c8 <generic_kprobe_process_event+0x2368>
    2658:      	cmp	w8, #0xff
    265c:      	b.ne	0x2bc0 <generic_kprobe_process_event+0x2860>
    2660:      	mov	w8, #0x28               // =40
    2664:      	b	0x2b08 <generic_kprobe_process_event+0x27a8>
    2668:      	str	w21, [sp, #0x90]
    266c:      	mov	x3, xzr
    2670:      	mov	w8, #0x2                // =2
    2674:      	add	x9, sp, #0x100
    2678:      	add	x10, sp, #0x90
    267c:      	add	x1, sp, #0x100
    2680:      	add	x2, sp, #0x90
    2684:      	mov	x0, x22
    2688:      	blr	x8
    268c:      	mov	w8, #-0x4               // =-4
    2690:      	b	0x2824 <generic_kprobe_process_event+0x24c4>
    2694:      	str	w21, [sp, #0xe8]
    2698:      	mov	x3, xzr
    269c:      	mov	w8, #0x2                // =2
    26a0:      	add	x9, sp, #0x100
    26a4:      	add	x10, sp, #0xe8
    26a8:      	add	x1, sp, #0x100
    26ac:      	add	x2, sp, #0xe8
    26b0:      	mov	x0, x22
    26b4:      	blr	x8
    26b8:      	mov	w8, #-0x4               // =-4
    26bc:      	b	0x2ad0 <generic_kprobe_process_event+0x2770>
    26c0:      	mov	w22, #0x4               // =4
    26c4:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    26c8:      	ldrb	w8, [x23, #0x7]
    26cc:      	lsl	w8, w8, #3
    26d0:      	b	0x2b04 <generic_kprobe_process_event+0x27a4>
    26d4:      	mov	w8, #0x5e60             // =24160
    26d8:      	b	0x26e8 <generic_kprobe_process_event+0x2388>
    26dc:      	mov	w8, #0x5e68             // =24168
    26e0:      	b	0x26e8 <generic_kprobe_process_event+0x2388>
    26e4:      	mov	w8, #0x5e50             // =24144
    26e8:      	add	x8, x22, x8
    26ec:      	ldr	x8, [x8]
    26f0:      	add	x22, sp, #0xe0
    26f4:      	mov	w21, #0x8               // =8
    26f8:      	add	x9, sp, #0xe0
    26fc:      	str	x8, [x22, #0x8]
    2700:      	mov	w8, #0x4                // =4
    2704:      	add	x10, sp, #0xe8
    2708:      	add	x0, sp, #0xe0
    270c:      	add	x2, sp, #0xe8
    2710:      	mov	w1, #0x8                // =8
    2714:      	blr	x8
    2718:      	ldr	x22, [x22]
    271c:      	tbz	w29, #0x5, 0x27f0 <generic_kprobe_process_event+0x2490>
    2720:      	cmp	x22, #0x1, lsl #12      // =0x1000
    2724:      	b.lo	0x27d8 <generic_kprobe_process_event+0x2478>
    2728:      	mov	w8, #0x1                // =1
    272c:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2730:      	add	x9, sp, #0xf0
    2734:      	str	w8, [x23]
    2738:      	str	wzr, [sp, #0xf0]
    273c:      	add	x1, sp, #0xf0
    2740:      	ldr	x0, [x0]
    2744:      	blr	x8
    2748:      	cbz	x0, 0x2af4 <generic_kprobe_process_event+0x2794>
    274c:      	mov	w8, #0x18               // =24
    2750:      	mov	x24, x0
    2754:      	str	w8, [x0]
    2758:      	mov	w8, #0xe                // =14
    275c:      	blr	x8
    2760:      	mov	x21, x24
    2764:      	cmn	x0, #0x16
    2768:      	str	x0, [x21, #0x10]!
    276c:      	b.ne	0x2794 <generic_kprobe_process_event+0x2434>
    2770:      	add	x2, x19, #0xe8
    2774:      	mov	w8, #0x8                // =8
    2778:      	mov	w9, #0x4                // =4
    277c:      	add	x10, sp, #0x98
    2780:      	add	x0, sp, #0x98
    2784:      	mov	w1, #0x8                // =8
    2788:      	blr	x9
    278c:      	ldr	x8, [sp, #0x98]
    2790:      	str	x8, [x21]
    2794:      	mov	w8, #0x7d               // =125
    2798:      	blr	x8
    279c:      	str	x0, [x24, #0x18]
    27a0:      	ldr	x2, [sp, #0x48]
    27a4:      	mov	x0, x19
    27a8:      	mov	x1, x24
    27ac:      	mov	x3, x22
    27b0:      	ldp	x8, x9, [x21]
    27b4:      	stur	x9, [x23, #0x1c]
    27b8:      	stur	x8, [x23, #0x14]
    27bc:      	bl	0x27bc <generic_kprobe_process_event+0x245c>
    27c0:      	tbnz	w0, #0x1f, 0x2be4 <generic_kprobe_process_event+0x2884>
    27c4:      	sub	w8, w22, w0
    27c8:      	cmn	x22, #0x1
    27cc:      	stur	xzr, [x23, #0x4]
    27d0:      	csel	w8, wzr, w8, eq
    27d4:      	b	0x2bf0 <generic_kprobe_process_event+0x2890>
    27d8:      	ldr	x8, [sp, #0x118]
    27dc:      	str	wzr, [x23]
    27e0:      	mov	w21, #0xc               // =12
    27e4:      	add	w8, w8, #0x8
    27e8:      	and	x8, x8, #0x3fff
    27ec:      	add	x23, x25, x8
    27f0:      	cmp	x22, #0xfff
    27f4:      	mov	w8, #0xfff              // =4095
    27f8:      	ldr	x2, [sp, #0x48]
    27fc:      	add	x0, x23, #0x8
    2800:      	csel	x24, x22, x8, lo
    2804:      	mov	w8, #0x4                // =4
    2808:      	mov	w1, w24
    280c:      	blr	x8
    2810:      	tbnz	w0, #0x1f, 0x2820 <generic_kprobe_process_event+0x24c0>
    2814:      	stp	w22, w24, [x23]
    2818:      	add	x22, x21, x24
    281c:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    2820:      	mov	w8, #-0x2               // =-2
    2824:      	str	w8, [x23]
    2828:      	mov	w22, #0x4               // =4
    282c:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    2830:      	mov	w8, wzr
    2834:      	stp	w0, wzr, [x29, #0x4]
    2838:      	mov	w0, wzr
    283c:      	mov	w22, #0x24              // =36
    2840:      	stp	w8, w0, [x29, #0xc]
    2844:      	b	0x3218 <generic_kprobe_process_event+0x2eb8>
    2848:      	ldr	x8, [sp, #0x118]
    284c:      	mov	w9, #0x4                // =4
    2850:      	mov	w1, w22
    2854:      	add	x21, x8, #0xc
    2858:      	and	x8, x21, #0x3fff
    285c:      	add	x0, x23, x8
    2860:      	ldr	x8, [sp, #0x98]
    2864:      	ldr	x2, [sp, #0x98]
    2868:      	blr	x9
    286c:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2870:      	cmp	x24, #0x1
    2874:      	b.eq	0x2594 <generic_kprobe_process_event+0x2234>
    2878:      	ldr	x8, [sp, #0x48]
    287c:      	mov	w9, #0x4                // =4
    2880:      	add	x10, sp, #0x98
    2884:      	add	x0, sp, #0x98
    2888:      	mov	w1, #0x10               // =16
    288c:      	add	x2, x8, #0x10
    2890:      	mov	w8, #0x10               // =16
    2894:      	blr	x9
    2898:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    289c:      	ldr	x25, [sp, #0xa0]
    28a0:      	cmp	x25, #0xffe
    28a4:      	b.hi	0x24ac <generic_kprobe_process_event+0x214c>
    28a8:      	add	x21, x22, x21
    28ac:      	mov	w9, #0x4                // =4
    28b0:      	mov	w1, w25
    28b4:      	and	x8, x21, #0x3fff
    28b8:      	add	x0, x23, x8
    28bc:      	ldr	x8, [sp, #0x98]
    28c0:      	ldr	x2, [sp, #0x98]
    28c4:      	blr	x9
    28c8:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    28cc:      	add	x22, x25, x22
    28d0:      	cmp	x24, #0x3
    28d4:      	b.lo	0x2594 <generic_kprobe_process_event+0x2234>
    28d8:      	ldr	x8, [sp, #0x48]
    28dc:      	mov	w9, #0x4                // =4
    28e0:      	add	x10, sp, #0x98
    28e4:      	add	x0, sp, #0x98
    28e8:      	mov	w1, #0x10               // =16
    28ec:      	add	x2, x8, #0x20
    28f0:      	mov	w8, #0x10               // =16
    28f4:      	blr	x9
    28f8:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    28fc:      	ldr	x8, [sp, #0xa0]
    2900:      	cmp	x8, #0xffe
    2904:      	str	x8, [sp, #0x40]
    2908:      	b.hi	0x24ac <generic_kprobe_process_event+0x214c>
    290c:      	add	x21, x25, x21
    2910:      	mov	w9, #0x4                // =4
    2914:      	ldr	x1, [sp, #0x40]
    2918:      	and	x8, x21, #0x3fff
    291c:      	add	x0, x23, x8
    2920:      	ldr	x8, [sp, #0x98]
    2924:      	ldr	x2, [sp, #0x98]
    2928:      	blr	x9
    292c:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2930:      	ldr	x8, [sp, #0x40]
    2934:      	cmp	x24, #0x3
    2938:      	add	x22, x8, x22
    293c:      	b.eq	0x2594 <generic_kprobe_process_event+0x2234>
    2940:      	ldr	x8, [sp, #0x48]
    2944:      	mov	w9, #0x4                // =4
    2948:      	add	x10, sp, #0x98
    294c:      	add	x0, sp, #0x98
    2950:      	mov	w1, #0x10               // =16
    2954:      	add	x2, x8, #0x30
    2958:      	mov	w8, #0x10               // =16
    295c:      	blr	x9
    2960:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2964:      	ldr	x25, [sp, #0xa0]
    2968:      	cmp	x25, #0xffe
    296c:      	b.hi	0x24ac <generic_kprobe_process_event+0x214c>
    2970:      	ldr	x8, [sp, #0x40]
    2974:      	mov	w9, #0x4                // =4
    2978:      	mov	w1, w25
    297c:      	add	x21, x8, x21
    2980:      	and	x8, x21, #0x3fff
    2984:      	add	x0, x23, x8
    2988:      	ldr	x8, [sp, #0x98]
    298c:      	ldr	x2, [sp, #0x98]
    2990:      	blr	x9
    2994:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2998:      	add	x22, x25, x22
    299c:      	cmp	x24, #0x5
    29a0:      	b.lo	0x2594 <generic_kprobe_process_event+0x2234>
    29a4:      	ldr	x8, [sp, #0x48]
    29a8:      	mov	w9, #0x4                // =4
    29ac:      	add	x10, sp, #0x98
    29b0:      	add	x0, sp, #0x98
    29b4:      	mov	w1, #0x10               // =16
    29b8:      	add	x2, x8, #0x40
    29bc:      	mov	w8, #0x10               // =16
    29c0:      	blr	x9
    29c4:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    29c8:      	ldr	x8, [sp, #0xa0]
    29cc:      	cmp	x8, #0xffe
    29d0:      	str	x8, [sp, #0x40]
    29d4:      	b.hi	0x24ac <generic_kprobe_process_event+0x214c>
    29d8:      	add	x21, x25, x21
    29dc:      	mov	w9, #0x4                // =4
    29e0:      	ldr	x1, [sp, #0x40]
    29e4:      	and	x8, x21, #0x3fff
    29e8:      	add	x0, x23, x8
    29ec:      	ldr	x8, [sp, #0x98]
    29f0:      	ldr	x2, [sp, #0x98]
    29f4:      	blr	x9
    29f8:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    29fc:      	ldr	x8, [sp, #0x40]
    2a00:      	cmp	x24, #0x5
    2a04:      	add	x22, x8, x22
    2a08:      	b.eq	0x2594 <generic_kprobe_process_event+0x2234>
    2a0c:      	ldr	x8, [sp, #0x48]
    2a10:      	mov	w9, #0x4                // =4
    2a14:      	add	x10, sp, #0x98
    2a18:      	add	x0, sp, #0x98
    2a1c:      	mov	w1, #0x10               // =16
    2a20:      	add	x2, x8, #0x50
    2a24:      	mov	w8, #0x10               // =16
    2a28:      	blr	x9
    2a2c:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2a30:      	ldr	x25, [sp, #0xa0]
    2a34:      	cmp	x25, #0xffe
    2a38:      	b.hi	0x24ac <generic_kprobe_process_event+0x214c>
    2a3c:      	ldr	x8, [sp, #0x40]
    2a40:      	mov	w9, #0x4                // =4
    2a44:      	mov	w1, w25
    2a48:      	add	x21, x8, x21
    2a4c:      	and	x8, x21, #0x3fff
    2a50:      	add	x0, x23, x8
    2a54:      	ldr	x8, [sp, #0x98]
    2a58:      	ldr	x2, [sp, #0x98]
    2a5c:      	blr	x9
    2a60:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2a64:      	add	x22, x25, x22
    2a68:      	cmp	x24, #0x7
    2a6c:      	b.lo	0x2594 <generic_kprobe_process_event+0x2234>
    2a70:      	ldr	x8, [sp, #0x48]
    2a74:      	mov	w9, #0x4                // =4
    2a78:      	add	x10, sp, #0x98
    2a7c:      	add	x0, sp, #0x98
    2a80:      	mov	w1, #0x10               // =16
    2a84:      	add	x2, x8, #0x60
    2a88:      	mov	w8, #0x10               // =16
    2a8c:      	blr	x9
    2a90:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2a94:      	ldr	x24, [sp, #0xa0]
    2a98:      	cmp	x24, #0xffe
    2a9c:      	b.hi	0x24ac <generic_kprobe_process_event+0x214c>
    2aa0:      	add	x8, x25, x21
    2aa4:      	mov	w9, #0x4                // =4
    2aa8:      	mov	w1, w24
    2aac:      	and	x8, x8, #0x3fff
    2ab0:      	add	x0, x23, x8
    2ab4:      	ldr	x8, [sp, #0x98]
    2ab8:      	ldr	x2, [sp, #0x98]
    2abc:      	blr	x9
    2ac0:      	tbnz	w0, #0x1f, 0x2acc <generic_kprobe_process_event+0x276c>
    2ac4:      	add	x22, x24, x22
    2ac8:      	b	0x2594 <generic_kprobe_process_event+0x2234>
    2acc:      	mov	w8, #-0x2               // =-2
    2ad0:      	str	w8, [x29]
    2ad4:      	mov	w22, #0x4               // =4
    2ad8:      	mov	w21, #0x5efc            // =24316
    2adc:      	ldr	x11, [sp, #0x38]
    2ae0:      	mov	w10, #0x5ea0            // =24224
    2ae4:      	adrp	x25, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2ae8:      	ldr	x23, [sp, #0x50]
    2aec:      	ldr	x25, [x25]
    2af0:      	b	0x3230 <generic_kprobe_process_event+0x2ed0>
    2af4:      	mov	w22, #0x4               // =4
    2af8:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    2afc:      	ldrb	w8, [x23, #0x7]
    2b00:      	lsl	w8, w8, #2
    2b04:      	add	w8, w8, #0x8
    2b08:      	strh	w8, [x23, #0x2]
    2b0c:      	ldrh	w9, [x23]
    2b10:      	ldrb	w25, [x23, #0x6]
    2b14:      	add	w8, w9, w8
    2b18:      	cmp	w25, #0x3c
    2b1c:      	strh	w8, [x23]
    2b20:      	b.hi	0x2bdc <generic_kprobe_process_event+0x287c>
    2b24:      	mov	x21, #0x1               // =1
    2b28:      	mov	w9, #0x1                // =1
    2b2c:      	movk	x21, #0x1800, lsl #32
    2b30:      	lsl	x9, x9, x25
    2b34:      	movk	x21, #0x1008, lsl #48
    2b38:      	tst	x9, x21
    2b3c:      	b.eq	0x2bdc <generic_kprobe_process_event+0x287c>
    2b40:      	ldr	x11, [sp, #0x48]
    2b44:      	strb	w25, [x23, #0x5]
    2b48:      	mov	w9, #0x2                // =2
    2b4c:      	mov	w10, #0x4               // =4
    2b50:      	mov	x0, x22
    2b54:      	mov	w1, #0x2                // =2
    2b58:      	add	x8, x11, w8, uxth
    2b5c:      	ldrh	w8, [x23]
    2b60:      	add	x2, x11, x8
    2b64:      	blr	x10
    2b68:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    2b6c:      	ldrb	w8, [x23, #0x5]
    2b70:      	cmp	w8, #0x32
    2b74:      	b.gt	0x2b94 <generic_kprobe_process_event+0x2834>
    2b78:      	cbz	w8, 0x2bb4 <generic_kprobe_process_event+0x2854>
    2b7c:      	cmp	w8, #0x2b
    2b80:      	b.eq	0x2bb4 <generic_kprobe_process_event+0x2854>
    2b84:      	cmp	w8, #0x2c
    2b88:      	b.ne	0x2cb4 <generic_kprobe_process_event+0x2954>
    2b8c:      	mov	w8, #0x8                // =8
    2b90:      	b	0x2c08 <generic_kprobe_process_event+0x28a8>
    2b94:      	cmp	w8, #0x33
    2b98:      	b.eq	0x2bfc <generic_kprobe_process_event+0x289c>
    2b9c:      	cmp	w8, #0x3c
    2ba0:      	b.eq	0x2bb4 <generic_kprobe_process_event+0x2854>
    2ba4:      	cmp	w8, #0xff
    2ba8:      	b.ne	0x2cb4 <generic_kprobe_process_event+0x2954>
    2bac:      	mov	w8, #0x28               // =40
    2bb0:      	b	0x2c08 <generic_kprobe_process_event+0x28a8>
    2bb4:      	ldrb	w8, [x23, #0x7]
    2bb8:      	lsl	w8, w8, #3
    2bbc:      	b	0x2c04 <generic_kprobe_process_event+0x28a4>
    2bc0:      	ldrh	w8, [x23, #0x2]
    2bc4:      	ldrh	w9, [x23]
    2bc8:      	ldrb	w25, [x23, #0x6]
    2bcc:      	add	w8, w9, w8
    2bd0:      	cmp	w25, #0x3c
    2bd4:      	strh	w8, [x23]
    2bd8:      	b.ls	0x2b24 <generic_kprobe_process_event+0x27c4>
    2bdc:      	strh	w8, [sp, #0x90]
    2be0:      	b	0x3098 <generic_kprobe_process_event+0x2d38>
    2be4:      	mov	w8, wzr
    2be8:      	stp	w0, wzr, [x23, #0x4]
    2bec:      	mov	w0, wzr
    2bf0:      	mov	w22, #0x24              // =36
    2bf4:      	stp	w8, w0, [x23, #0xc]
    2bf8:      	b	0x2ad8 <generic_kprobe_process_event+0x2778>
    2bfc:      	ldrb	w8, [x23, #0x7]
    2c00:      	lsl	w8, w8, #2
    2c04:      	add	w8, w8, #0x8
    2c08:      	strh	w8, [x23, #0x2]
    2c0c:      	ldrh	w9, [x23]
    2c10:      	ldrb	w25, [x23, #0x6]
    2c14:      	add	w8, w9, w8
    2c18:      	cmp	w25, #0x3c
    2c1c:      	strh	w8, [x23]
    2c20:      	b.hi	0x328c <generic_kprobe_process_event+0x2f2c>
    2c24:      	mov	w9, #0x1                // =1
    2c28:      	lsl	x9, x9, x25
    2c2c:      	tst	x9, x21
    2c30:      	b.eq	0x328c <generic_kprobe_process_event+0x2f2c>
    2c34:      	ldr	x11, [sp, #0x48]
    2c38:      	strb	w25, [x23, #0x5]
    2c3c:      	mov	w9, #0x2                // =2
    2c40:      	mov	w10, #0x4               // =4
    2c44:      	mov	x0, x22
    2c48:      	mov	w1, #0x2                // =2
    2c4c:      	add	x8, x11, w8, uxth
    2c50:      	ldrh	w8, [x23]
    2c54:      	add	x2, x11, x8
    2c58:      	blr	x10
    2c5c:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    2c60:      	ldrb	w8, [x23, #0x5]
    2c64:      	cmp	w8, #0x32
    2c68:      	b.gt	0x2c88 <generic_kprobe_process_event+0x2928>
    2c6c:      	cbz	w8, 0x2ca8 <generic_kprobe_process_event+0x2948>
    2c70:      	cmp	w8, #0x2b
    2c74:      	b.eq	0x2ca8 <generic_kprobe_process_event+0x2948>
    2c78:      	cmp	w8, #0x2c
    2c7c:      	b.ne	0x2d8c <generic_kprobe_process_event+0x2a2c>
    2c80:      	mov	w8, #0x8                // =8
    2c84:      	b	0x2ce0 <generic_kprobe_process_event+0x2980>
    2c88:      	cmp	w8, #0x33
    2c8c:      	b.eq	0x2cd4 <generic_kprobe_process_event+0x2974>
    2c90:      	cmp	w8, #0x3c
    2c94:      	b.eq	0x2ca8 <generic_kprobe_process_event+0x2948>
    2c98:      	cmp	w8, #0xff
    2c9c:      	b.ne	0x2d8c <generic_kprobe_process_event+0x2a2c>
    2ca0:      	mov	w8, #0x28               // =40
    2ca4:      	b	0x2ce0 <generic_kprobe_process_event+0x2980>
    2ca8:      	ldrb	w8, [x23, #0x7]
    2cac:      	lsl	w8, w8, #3
    2cb0:      	b	0x2cdc <generic_kprobe_process_event+0x297c>
    2cb4:      	ldrh	w8, [x23, #0x2]
    2cb8:      	ldrh	w9, [x23]
    2cbc:      	ldrb	w25, [x23, #0x6]
    2cc0:      	add	w8, w9, w8
    2cc4:      	cmp	w25, #0x3c
    2cc8:      	strh	w8, [x23]
    2ccc:      	b.ls	0x2c24 <generic_kprobe_process_event+0x28c4>
    2cd0:      	b	0x328c <generic_kprobe_process_event+0x2f2c>
    2cd4:      	ldrb	w8, [x23, #0x7]
    2cd8:      	lsl	w8, w8, #2
    2cdc:      	add	w8, w8, #0x8
    2ce0:      	strh	w8, [x23, #0x2]
    2ce4:      	ldrh	w9, [x23]
    2ce8:      	ldrb	w25, [x23, #0x6]
    2cec:      	add	w8, w9, w8
    2cf0:      	cmp	w25, #0x3c
    2cf4:      	strh	w8, [x23]
    2cf8:      	b.hi	0x328c <generic_kprobe_process_event+0x2f2c>
    2cfc:      	mov	w9, #0x1                // =1
    2d00:      	lsl	x9, x9, x25
    2d04:      	tst	x9, x21
    2d08:      	b.eq	0x328c <generic_kprobe_process_event+0x2f2c>
    2d0c:      	ldr	x11, [sp, #0x48]
    2d10:      	strb	w25, [x23, #0x5]
    2d14:      	mov	w9, #0x2                // =2
    2d18:      	mov	w10, #0x4               // =4
    2d1c:      	mov	x0, x22
    2d20:      	mov	w1, #0x2                // =2
    2d24:      	add	x8, x11, w8, uxth
    2d28:      	ldrh	w8, [x23]
    2d2c:      	add	x2, x11, x8
    2d30:      	blr	x10
    2d34:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    2d38:      	ldrb	w8, [x23, #0x5]
    2d3c:      	cmp	w8, #0x32
    2d40:      	b.gt	0x2d60 <generic_kprobe_process_event+0x2a00>
    2d44:      	cbz	w8, 0x2d80 <generic_kprobe_process_event+0x2a20>
    2d48:      	cmp	w8, #0x2b
    2d4c:      	b.eq	0x2d80 <generic_kprobe_process_event+0x2a20>
    2d50:      	cmp	w8, #0x2c
    2d54:      	b.ne	0x2e64 <generic_kprobe_process_event+0x2b04>
    2d58:      	mov	w8, #0x8                // =8
    2d5c:      	b	0x2db8 <generic_kprobe_process_event+0x2a58>
    2d60:      	cmp	w8, #0x33
    2d64:      	b.eq	0x2dac <generic_kprobe_process_event+0x2a4c>
    2d68:      	cmp	w8, #0x3c
    2d6c:      	b.eq	0x2d80 <generic_kprobe_process_event+0x2a20>
    2d70:      	cmp	w8, #0xff
    2d74:      	b.ne	0x2e64 <generic_kprobe_process_event+0x2b04>
    2d78:      	mov	w8, #0x28               // =40
    2d7c:      	b	0x2db8 <generic_kprobe_process_event+0x2a58>
    2d80:      	ldrb	w8, [x23, #0x7]
    2d84:      	lsl	w8, w8, #3
    2d88:      	b	0x2db4 <generic_kprobe_process_event+0x2a54>
    2d8c:      	ldrh	w8, [x23, #0x2]
    2d90:      	ldrh	w9, [x23]
    2d94:      	ldrb	w25, [x23, #0x6]
    2d98:      	add	w8, w9, w8
    2d9c:      	cmp	w25, #0x3c
    2da0:      	strh	w8, [x23]
    2da4:      	b.ls	0x2cfc <generic_kprobe_process_event+0x299c>
    2da8:      	b	0x328c <generic_kprobe_process_event+0x2f2c>
    2dac:      	ldrb	w8, [x23, #0x7]
    2db0:      	lsl	w8, w8, #2
    2db4:      	add	w8, w8, #0x8
    2db8:      	strh	w8, [x23, #0x2]
    2dbc:      	ldrh	w9, [x23]
    2dc0:      	ldrb	w25, [x23, #0x6]
    2dc4:      	add	w8, w9, w8
    2dc8:      	cmp	w25, #0x3c
    2dcc:      	strh	w8, [x23]
    2dd0:      	b.hi	0x328c <generic_kprobe_process_event+0x2f2c>
    2dd4:      	mov	w9, #0x1                // =1
    2dd8:      	lsl	x9, x9, x25
    2ddc:      	tst	x9, x21
    2de0:      	b.eq	0x328c <generic_kprobe_process_event+0x2f2c>
    2de4:      	ldr	x11, [sp, #0x48]
    2de8:      	strb	w25, [x23, #0x5]
    2dec:      	mov	w9, #0x2                // =2
    2df0:      	mov	w10, #0x4               // =4
    2df4:      	mov	x0, x22
    2df8:      	mov	w1, #0x2                // =2
    2dfc:      	add	x8, x11, w8, uxth
    2e00:      	ldrh	w8, [x23]
    2e04:      	add	x2, x11, x8
    2e08:      	blr	x10
    2e0c:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    2e10:      	ldrb	w8, [x23, #0x5]
    2e14:      	cmp	w8, #0x32
    2e18:      	b.gt	0x2e38 <generic_kprobe_process_event+0x2ad8>
    2e1c:      	cbz	w8, 0x2e58 <generic_kprobe_process_event+0x2af8>
    2e20:      	cmp	w8, #0x2b
    2e24:      	b.eq	0x2e58 <generic_kprobe_process_event+0x2af8>
    2e28:      	cmp	w8, #0x2c
    2e2c:      	b.ne	0x2f3c <generic_kprobe_process_event+0x2bdc>
    2e30:      	mov	w8, #0x8                // =8
    2e34:      	b	0x2e90 <generic_kprobe_process_event+0x2b30>
    2e38:      	cmp	w8, #0x33
    2e3c:      	b.eq	0x2e84 <generic_kprobe_process_event+0x2b24>
    2e40:      	cmp	w8, #0x3c
    2e44:      	b.eq	0x2e58 <generic_kprobe_process_event+0x2af8>
    2e48:      	cmp	w8, #0xff
    2e4c:      	b.ne	0x2f3c <generic_kprobe_process_event+0x2bdc>
    2e50:      	mov	w8, #0x28               // =40
    2e54:      	b	0x2e90 <generic_kprobe_process_event+0x2b30>
    2e58:      	ldrb	w8, [x23, #0x7]
    2e5c:      	lsl	w8, w8, #3
    2e60:      	b	0x2e8c <generic_kprobe_process_event+0x2b2c>
    2e64:      	ldrh	w8, [x23, #0x2]
    2e68:      	ldrh	w9, [x23]
    2e6c:      	ldrb	w25, [x23, #0x6]
    2e70:      	add	w8, w9, w8
    2e74:      	cmp	w25, #0x3c
    2e78:      	strh	w8, [x23]
    2e7c:      	b.ls	0x2dd4 <generic_kprobe_process_event+0x2a74>
    2e80:      	b	0x328c <generic_kprobe_process_event+0x2f2c>
    2e84:      	ldrb	w8, [x23, #0x7]
    2e88:      	lsl	w8, w8, #2
    2e8c:      	add	w8, w8, #0x8
    2e90:      	strh	w8, [x23, #0x2]
    2e94:      	ldrh	w9, [x23]
    2e98:      	ldrb	w25, [x23, #0x6]
    2e9c:      	add	w8, w9, w8
    2ea0:      	cmp	w25, #0x3c
    2ea4:      	strh	w8, [x23]
    2ea8:      	b.hi	0x328c <generic_kprobe_process_event+0x2f2c>
    2eac:      	mov	w9, #0x1                // =1
    2eb0:      	lsl	x9, x9, x25
    2eb4:      	tst	x9, x21
    2eb8:      	b.eq	0x328c <generic_kprobe_process_event+0x2f2c>
    2ebc:      	ldr	x11, [sp, #0x48]
    2ec0:      	strb	w25, [x23, #0x5]
    2ec4:      	mov	w9, #0x2                // =2
    2ec8:      	mov	w10, #0x4               // =4
    2ecc:      	mov	x0, x22
    2ed0:      	mov	w1, #0x2                // =2
    2ed4:      	add	x8, x11, w8, uxth
    2ed8:      	ldrh	w8, [x23]
    2edc:      	add	x2, x11, x8
    2ee0:      	blr	x10
    2ee4:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    2ee8:      	ldrb	w8, [x23, #0x5]
    2eec:      	cmp	w8, #0x32
    2ef0:      	b.gt	0x2f10 <generic_kprobe_process_event+0x2bb0>
    2ef4:      	cbz	w8, 0x2f30 <generic_kprobe_process_event+0x2bd0>
    2ef8:      	cmp	w8, #0x2b
    2efc:      	b.eq	0x2f30 <generic_kprobe_process_event+0x2bd0>
    2f00:      	cmp	w8, #0x2c
    2f04:      	b.ne	0x3014 <generic_kprobe_process_event+0x2cb4>
    2f08:      	mov	w8, #0x8                // =8
    2f0c:      	b	0x2f68 <generic_kprobe_process_event+0x2c08>
    2f10:      	cmp	w8, #0x33
    2f14:      	b.eq	0x2f5c <generic_kprobe_process_event+0x2bfc>
    2f18:      	cmp	w8, #0x3c
    2f1c:      	b.eq	0x2f30 <generic_kprobe_process_event+0x2bd0>
    2f20:      	cmp	w8, #0xff
    2f24:      	b.ne	0x3014 <generic_kprobe_process_event+0x2cb4>
    2f28:      	mov	w8, #0x28               // =40
    2f2c:      	b	0x2f68 <generic_kprobe_process_event+0x2c08>
    2f30:      	ldrb	w8, [x23, #0x7]
    2f34:      	lsl	w8, w8, #3
    2f38:      	b	0x2f64 <generic_kprobe_process_event+0x2c04>
    2f3c:      	ldrh	w8, [x23, #0x2]
    2f40:      	ldrh	w9, [x23]
    2f44:      	ldrb	w25, [x23, #0x6]
    2f48:      	add	w8, w9, w8
    2f4c:      	cmp	w25, #0x3c
    2f50:      	strh	w8, [x23]
    2f54:      	b.ls	0x2eac <generic_kprobe_process_event+0x2b4c>
    2f58:      	b	0x328c <generic_kprobe_process_event+0x2f2c>
    2f5c:      	ldrb	w8, [x23, #0x7]
    2f60:      	lsl	w8, w8, #2
    2f64:      	add	w8, w8, #0x8
    2f68:      	strh	w8, [x23, #0x2]
    2f6c:      	ldrh	w9, [x23]
    2f70:      	ldrb	w25, [x23, #0x6]
    2f74:      	add	w8, w9, w8
    2f78:      	cmp	w25, #0x3c
    2f7c:      	strh	w8, [x23]
    2f80:      	b.hi	0x328c <generic_kprobe_process_event+0x2f2c>
    2f84:      	mov	w9, #0x1                // =1
    2f88:      	lsl	x9, x9, x25
    2f8c:      	tst	x9, x21
    2f90:      	b.eq	0x328c <generic_kprobe_process_event+0x2f2c>
    2f94:      	ldr	x11, [sp, #0x48]
    2f98:      	strb	w25, [x23, #0x5]
    2f9c:      	mov	w9, #0x2                // =2
    2fa0:      	mov	w10, #0x4               // =4
    2fa4:      	mov	x0, x22
    2fa8:      	mov	w1, #0x2                // =2
    2fac:      	add	x8, x11, w8, uxth
    2fb0:      	ldrh	w8, [x23]
    2fb4:      	add	x2, x11, x8
    2fb8:      	blr	x10
    2fbc:      	tbnz	x0, #0x3f, 0x3094 <generic_kprobe_process_event+0x2d34>
    2fc0:      	ldrb	w8, [x23, #0x5]
    2fc4:      	cmp	w8, #0x32
    2fc8:      	b.gt	0x2fe8 <generic_kprobe_process_event+0x2c88>
    2fcc:      	cbz	w8, 0x3008 <generic_kprobe_process_event+0x2ca8>
    2fd0:      	cmp	w8, #0x2b
    2fd4:      	b.eq	0x3008 <generic_kprobe_process_event+0x2ca8>
    2fd8:      	cmp	w8, #0x2c
    2fdc:      	b.ne	0x3270 <generic_kprobe_process_event+0x2f10>
    2fe0:      	mov	w8, #0x8                // =8
    2fe4:      	b	0x3040 <generic_kprobe_process_event+0x2ce0>
    2fe8:      	cmp	w8, #0x33
    2fec:      	b.eq	0x3034 <generic_kprobe_process_event+0x2cd4>
    2ff0:      	cmp	w8, #0x3c
    2ff4:      	b.eq	0x3008 <generic_kprobe_process_event+0x2ca8>
    2ff8:      	cmp	w8, #0xff
    2ffc:      	b.ne	0x3270 <generic_kprobe_process_event+0x2f10>
    3000:      	mov	w8, #0x28               // =40
    3004:      	b	0x3040 <generic_kprobe_process_event+0x2ce0>
    3008:      	ldrb	w8, [x23, #0x7]
    300c:      	lsl	w8, w8, #3
    3010:      	b	0x303c <generic_kprobe_process_event+0x2cdc>
    3014:      	ldrh	w8, [x23, #0x2]
    3018:      	ldrh	w9, [x23]
    301c:      	ldrb	w25, [x23, #0x6]
    3020:      	add	w8, w9, w8
    3024:      	cmp	w25, #0x3c
    3028:      	strh	w8, [x23]
    302c:      	b.ls	0x2f84 <generic_kprobe_process_event+0x2c24>
    3030:      	b	0x328c <generic_kprobe_process_event+0x2f2c>
    3034:      	ldrb	w8, [x23, #0x7]
    3038:      	lsl	w8, w8, #2
    303c:      	add	w8, w8, #0x8
    3040:      	strh	w8, [x23, #0x2]
    3044:      	ldrh	w9, [x23]
    3048:      	ldrb	w25, [x23, #0x6]
    304c:      	add	w8, w9, w8
    3050:      	cmp	w25, #0x3c
    3054:      	strh	w8, [x23]
    3058:      	b.hi	0x328c <generic_kprobe_process_event+0x2f2c>
    305c:      	mov	w9, #0x1                // =1
    3060:      	lsl	x9, x9, x25
    3064:      	tst	x9, x21
    3068:      	b.eq	0x328c <generic_kprobe_process_event+0x2f2c>
    306c:      	ldr	x11, [sp, #0x48]
    3070:      	strb	w25, [x23, #0x5]
    3074:      	mov	w9, #0x2                // =2
    3078:      	mov	w10, #0x4               // =4
    307c:      	mov	x0, x22
    3080:      	mov	w1, #0x2                // =2
    3084:      	add	x8, x11, w8, uxth
    3088:      	ldrh	w8, [x23]
    308c:      	add	x2, x11, x8
    3090:      	blr	x10
    3094:      	mov	w25, wzr
    3098:      	ldr	x23, [sp, #0x30]
    309c:      	mov	w8, #0xa                // =10
    30a0:      	strb	w25, [sp, #0x84]
    30a4:      	add	x2, x29, #0x8
    30a8:      	mov	w21, #0x10              // =16
    30ac:      	mov	w1, #0x10               // =16
    30b0:      	mov	w22, #0x4               // =4
    30b4:      	strh	w25, [x23, #0x24]
    30b8:      	strh	w8, [x23, #0x26]
    30bc:      	mov	w8, #0x4                // =4
    30c0:      	mov	x0, x23
    30c4:      	blr	x8
    30c8:      	add	x0, x23, #0x10
    30cc:      	add	x2, x29, #0x18
    30d0:      	mov	w1, #0x10               // =16
    30d4:      	blr	x22
    30d8:      	cmp	w25, #0x11
    30dc:      	b.eq	0x3120 <generic_kprobe_process_event+0x2dc0>
    30e0:      	cmp	w25, #0x6
    30e4:      	b.ne	0x3160 <generic_kprobe_process_event+0x2e00>
    30e8:      	ldr	x8, [sp, #0x98]
    30ec:      	ldrh	w9, [sp, #0x90]
    30f0:      	mov	w21, #0x2               // =2
    30f4:      	mov	w1, #0x2                // =2
    30f8:      	mov	w23, #0x4               // =4
    30fc:      	add	x22, x8, x9
    3100:      	ldr	x25, [sp, #0x30]
    3104:      	add	x0, x25, #0x20
    3108:      	mov	w8, #0x4                // =4
    310c:      	mov	x2, x22
    3110:      	blr	x8
    3114:      	add	x0, x25, #0x22
    3118:      	add	x2, x22, #0x2
    311c:      	b	0x3154 <generic_kprobe_process_event+0x2df4>
    3120:      	ldr	x8, [sp, #0x98]
    3124:      	ldrh	w9, [sp, #0x90]
    3128:      	mov	w21, #0x2               // =2
    312c:      	mov	w1, #0x2                // =2
    3130:      	mov	w23, #0x4               // =4
    3134:      	add	x22, x8, x9
    3138:      	ldr	x25, [sp, #0x30]
    313c:      	add	x0, x25, #0x20
    3140:      	mov	w8, #0x4                // =4
    3144:      	mov	x2, x22
    3148:      	blr	x8
    314c:      	add	x0, x25, #0x22
    3150:      	add	x2, x22, #0x2
    3154:      	mov	w1, #0x2                // =2
    3158:      	blr	x23
    315c:      	b	0x3168 <generic_kprobe_process_event+0x2e08>
    3160:      	ldr	x8, [sp, #0x30]
    3164:      	str	wzr, [x8, #0x20]
    3168:      	ldr	x9, [sp, #0x30]
    316c:      	add	x2, x24, #0xe0
    3170:      	add	x10, sp, #0xf0
    3174:      	add	x0, sp, #0xf0
    3178:      	ldrh	w8, [x9, #0x20]
    317c:      	mov	w1, #0x8                // =8
    3180:      	rev	w8, w8
    3184:      	lsr	w8, w8, #16
    3188:      	strh	w8, [x9, #0x20]
    318c:      	ldrh	w8, [x9, #0x22]
    3190:      	rev	w8, w8
    3194:      	lsr	w8, w8, #16
    3198:      	strh	w8, [x9, #0x22]
    319c:      	mov	w8, #0x8                // =8
    31a0:      	mov	w9, #0x4                // =4
    31a4:      	blr	x9
    31a8:      	add	x8, sp, #0xe0
    31ac:      	ldr	x8, [x8, #0x10]
    31b0:      	cbz	x8, 0x3214 <generic_kprobe_process_event+0x2eb4>
    31b4:      	add	x8, x8, #0x5
    31b8:      	mov	w9, #0x8                // =8
    31bc:      	add	x10, sp, #0x100
    31c0:      	mov	w11, #0x4               // =4
    31c4:      	add	x22, sp, #0xe0
    31c8:      	ldr	x8, [x22, #0x10]
    31cc:      	add	x0, sp, #0x100
    31d0:      	mov	w1, #0x8                // =8
    31d4:      	mov	w21, #0x4               // =4
    31d8:      	add	x2, x8, #0x5
    31dc:      	blr	x11
    31e0:      	ldr	x8, [x22, #0x10]
    31e4:      	ldr	x9, [x22, #0x20]
    31e8:      	mov	w1, #0x4                // =4
    31ec:      	add	x22, x8, x9, lsl #3
    31f0:      	ldr	x23, [sp, #0x30]
    31f4:      	add	x0, x23, #0x38
    31f8:      	mov	w8, #0x4                // =4
    31fc:      	add	x2, x22, #0x44
    3200:      	blr	x8
    3204:      	add	x0, x23, #0x3c
    3208:      	add	x2, x22, #0x45
    320c:      	mov	w1, #0x4                // =4
    3210:      	blr	x21
    3214:      	mov	w22, #0x40              // =64
    3218:      	adrp	x25, 0x3000 <generic_kprobe_process_event+0x2ca0>
    321c:      	mov	w21, #0x5efc            // =24316
    3220:      	ldr	x25, [x25]
    3224:      	ldr	x11, [sp, #0x38]
    3228:      	mov	w10, #0x5ea0            // =24224
    322c:      	ldr	x23, [sp, #0x50]
    3230:      	ldr	x24, [sp, #0x118]
    3234:      	tbnz	w22, #0x1f, 0x325c <generic_kprobe_process_event+0x2efc>
    3238:      	and	w8, w22, #0x7fffffff
    323c:      	add	w8, w8, #0x4
    3240:      	add	w24, w8, w24
    3244:      	str	w24, [x20, #0x4]
    3248:      	adrp	x22, 0x3000 <generic_kprobe_process_event+0x2ca0>
    324c:      	cmp	w23, #0x3
    3250:      	ldr	x22, [x22]
    3254:      	b.le	0x844 <generic_kprobe_process_event+0x4e4>
    3258:      	b	0x8b0 <generic_kprobe_process_event+0x550>
    325c:      	ldr	x9, [sp, #0x20]
    3260:      	mov	w8, #-0x1               // =-1
    3264:      	str	w8, [x9, x10]
    3268:      	str	w8, [x11, x24]
    326c:      	b	0x808 <generic_kprobe_process_event+0x4a8>
    3270:      	ldrh	w8, [x23, #0x2]
    3274:      	ldrh	w9, [x23]
    3278:      	ldrb	w25, [x23, #0x6]
    327c:      	add	w8, w9, w8
    3280:      	cmp	w25, #0x3c
    3284:      	strh	w8, [x23]
    3288:      	b.ls	0x305c <generic_kprobe_process_event+0x2cfc>
    328c:      	strh	w8, [sp, #0x90]
    3290:      	b	0x3098 <generic_kprobe_process_event+0x2d38>
    3294:      	nop
    3298:      	nop
    329c:      	nop

00000000000032a0 <generic_kprobe_process_filter>:
    32a0:      	sub	sp, sp, #0x130
    32a4:      	str	x29, [sp, #0xe0]
    32a8:      	stp	x30, x25, [sp, #0xf0]
    32ac:      	stp	x24, x23, [sp, #0x100]
    32b0:      	stp	x22, x21, [sp, #0x110]
    32b4:      	stp	x20, x19, [sp, #0x120]
    32b8:      	mov	x20, x0
    32bc:      	str	wzr, [sp, #0x54]
    32c0:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    32c4:      	mov	w8, #0x1                // =1
    32c8:      	ldr	x0, [x0]
    32cc:      	add	x9, sp, #0x54
    32d0:      	add	x1, sp, #0x54
    32d4:      	blr	x8
    32d8:      	cbz	x0, 0x55cc <generic_kprobe_process_filter+0x232c>
    32dc:      	mov	w8, #0x5ec0             // =24256
    32e0:      	mov	x22, x0
    32e4:      	add	x29, x0, x8
    32e8:      	mov	w8, #0x23               // =35
    32ec:      	blr	x8
    32f0:      	str	x0, [sp, #0x58]
    32f4:      	add	x8, x0, #0x8d4
    32f8:      	mov	w9, #0x4                // =4
    32fc:      	mov	w10, #0x71              // =113
    3300:      	add	x11, sp, #0xd8
    3304:      	add	x0, sp, #0xd8
    3308:      	mov	w1, #0x4                // =4
    330c:      	ldr	x8, [sp, #0x58]
    3310:      	add	x2, x8, #0x8d4
    3314:      	blr	x10
    3318:      	ldr	w8, [sp, #0xd8]
    331c:      	adrp	x19, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3320:      	add	x9, sp, #0xc8
    3324:      	add	x1, sp, #0xc8
    3328:      	str	w8, [sp, #0xc8]
    332c:      	mov	w8, #0x1                // =1
    3330:      	ldr	x19, [x19]
    3334:      	mov	x0, x19
    3338:      	blr	x8
    333c:      	cbz	x0, 0x334c <generic_kprobe_process_filter+0xac>
    3340:      	ldr	x8, [x0, #0x8]
    3344:      	mov	x24, x0
    3348:      	cbnz	x8, 0x412c <generic_kprobe_process_filter+0xe8c>
    334c:      	ldr	x8, [sp, #0x58]
    3350:      	mov	w9, #0x8                // =8
    3354:      	mov	w10, #0x71              // =113
    3358:      	add	x11, sp, #0x58
    335c:      	add	x0, sp, #0x58
    3360:      	mov	w1, #0x8                // =8
    3364:      	add	x8, x8, #0x8e0
    3368:      	ldr	x8, [sp, #0x58]
    336c:      	add	x2, x8, #0x8e0
    3370:      	blr	x10
    3374:      	ldr	x8, [sp, #0x58]
    3378:      	cbz	x8, 0x34f4 <generic_kprobe_process_filter+0x254>
    337c:      	add	x8, x8, #0x8d4
    3380:      	mov	w9, #0x4                // =4
    3384:      	mov	w10, #0x71              // =113
    3388:      	add	x11, sp, #0xd8
    338c:      	ldr	x8, [sp, #0x58]
    3390:      	add	x0, sp, #0xd8
    3394:      	mov	w1, #0x4                // =4
    3398:      	add	x2, x8, #0x8d4
    339c:      	blr	x10
    33a0:      	ldr	w8, [sp, #0xd8]
    33a4:      	add	x9, sp, #0xc8
    33a8:      	add	x1, sp, #0xc8
    33ac:      	mov	x0, x19
    33b0:      	str	w8, [sp, #0xc8]
    33b4:      	mov	w8, #0x1                // =1
    33b8:      	blr	x8
    33bc:      	cbz	x0, 0x33cc <generic_kprobe_process_filter+0x12c>
    33c0:      	ldr	x8, [x0, #0x8]
    33c4:      	mov	x24, x0
    33c8:      	cbnz	x8, 0x412c <generic_kprobe_process_filter+0xe8c>
    33cc:      	ldr	x8, [sp, #0x58]
    33d0:      	mov	w9, #0x8                // =8
    33d4:      	mov	w10, #0x71              // =113
    33d8:      	add	x11, sp, #0x58
    33dc:      	add	x0, sp, #0x58
    33e0:      	mov	w1, #0x8                // =8
    33e4:      	add	x8, x8, #0x8e0
    33e8:      	ldr	x8, [sp, #0x58]
    33ec:      	add	x2, x8, #0x8e0
    33f0:      	blr	x10
    33f4:      	ldr	x8, [sp, #0x58]
    33f8:      	cbz	x8, 0x34f4 <generic_kprobe_process_filter+0x254>
    33fc:      	add	x8, x8, #0x8d4
    3400:      	mov	w9, #0x4                // =4
    3404:      	mov	w10, #0x71              // =113
    3408:      	add	x11, sp, #0xd8
    340c:      	ldr	x8, [sp, #0x58]
    3410:      	add	x0, sp, #0xd8
    3414:      	mov	w1, #0x4                // =4
    3418:      	add	x2, x8, #0x8d4
    341c:      	blr	x10
    3420:      	ldr	w8, [sp, #0xd8]
    3424:      	add	x9, sp, #0xc8
    3428:      	add	x1, sp, #0xc8
    342c:      	mov	x0, x19
    3430:      	str	w8, [sp, #0xc8]
    3434:      	mov	w8, #0x1                // =1
    3438:      	blr	x8
    343c:      	cbz	x0, 0x344c <generic_kprobe_process_filter+0x1ac>
    3440:      	ldr	x8, [x0, #0x8]
    3444:      	mov	x24, x0
    3448:      	cbnz	x8, 0x412c <generic_kprobe_process_filter+0xe8c>
    344c:      	ldr	x8, [sp, #0x58]
    3450:      	mov	w9, #0x8                // =8
    3454:      	mov	w10, #0x71              // =113
    3458:      	add	x11, sp, #0x58
    345c:      	add	x0, sp, #0x58
    3460:      	mov	w1, #0x8                // =8
    3464:      	add	x8, x8, #0x8e0
    3468:      	ldr	x8, [sp, #0x58]
    346c:      	add	x2, x8, #0x8e0
    3470:      	blr	x10
    3474:      	ldr	x8, [sp, #0x58]
    3478:      	cbz	x8, 0x34f4 <generic_kprobe_process_filter+0x254>
    347c:      	add	x8, x8, #0x8d4
    3480:      	mov	w9, #0x4                // =4
    3484:      	mov	w10, #0x71              // =113
    3488:      	add	x11, sp, #0xd8
    348c:      	ldr	x8, [sp, #0x58]
    3490:      	add	x0, sp, #0xd8
    3494:      	mov	w1, #0x4                // =4
    3498:      	add	x2, x8, #0x8d4
    349c:      	blr	x10
    34a0:      	ldr	w8, [sp, #0xd8]
    34a4:      	add	x9, sp, #0xc8
    34a8:      	add	x1, sp, #0xc8
    34ac:      	mov	x0, x19
    34b0:      	str	w8, [sp, #0xc8]
    34b4:      	mov	w8, #0x1                // =1
    34b8:      	blr	x8
    34bc:      	cbz	x0, 0x34cc <generic_kprobe_process_filter+0x22c>
    34c0:      	ldr	x8, [x0, #0x8]
    34c4:      	mov	x24, x0
    34c8:      	cbnz	x8, 0x412c <generic_kprobe_process_filter+0xe8c>
    34cc:      	ldr	x8, [sp, #0x58]
    34d0:      	mov	w9, #0x8                // =8
    34d4:      	mov	w10, #0x71              // =113
    34d8:      	add	x11, sp, #0x58
    34dc:      	add	x0, sp, #0x58
    34e0:      	mov	w1, #0x8                // =8
    34e4:      	add	x8, x8, #0x8e0
    34e8:      	ldr	x8, [sp, #0x58]
    34ec:      	add	x2, x8, #0x8e0
    34f0:      	blr	x10
    34f4:      	str	x20, [sp, #0x38]
    34f8:      	mov	w8, #0x23               // =35
    34fc:      	blr	x8
    3500:      	add	x2, x0, #0x8d4
    3504:      	mov	w8, #0x4                // =4
    3508:      	add	x9, sp, #0x58
    350c:      	mov	x24, x0
    3510:      	add	x0, sp, #0x58
    3514:      	mov	w1, #0x4                // =4
    3518:      	blr	x8
    351c:      	ldr	w8, [sp, #0x58]
    3520:      	mov	x19, x29
    3524:      	str	w8, [x19, #0x50]!
    3528:      	mov	w8, #0x7d               // =125
    352c:      	blr	x8
    3530:      	str	x0, [x22, #0x5f18]
    3534:      	str	wzr, [x19, #0x10]
    3538:      	add	x2, x24, #0x60
    353c:      	mov	w8, #0x8                // =8
    3540:      	mov	w9, #0x71               // =113
    3544:      	add	x10, sp, #0xc8
    3548:      	str	xzr, [x22, #0x5f28]
    354c:      	str	x19, [sp, #0x48]
    3550:      	add	x0, sp, #0xc8
    3554:      	mov	w1, #0x8                // =8
    3558:      	str	wzr, [x19, #0x20]
    355c:      	blr	x9
    3560:      	ldr	x8, [sp, #0xc8]
    3564:      	cbz	x8, 0x35d4 <generic_kprobe_process_filter+0x334>
    3568:      	add	x8, x8, #0x4
    356c:      	mov	w9, #0x4                // =4
    3570:      	mov	w10, #0x71              // =113
    3574:      	add	x11, sp, #0xd8
    3578:      	ldr	x8, [sp, #0xc8]
    357c:      	add	x0, sp, #0xd8
    3580:      	mov	w1, #0x4                // =4
    3584:      	add	x2, x8, #0x4
    3588:      	blr	x10
    358c:      	ldr	w8, [sp, #0xd8]
    3590:      	cbz	w8, 0x35d4 <generic_kprobe_process_filter+0x334>
    3594:      	ldr	x9, [sp, #0xc8]
    3598:      	lsl	w8, w8, #4
    359c:      	mov	w10, #0x71              // =113
    35a0:      	add	x11, sp, #0x58
    35a4:      	add	x0, sp, #0x58
    35a8:      	mov	w1, #0x10               // =16
    35ac:      	add	x8, x9, x8
    35b0:      	mov	w9, #0x10               // =16
    35b4:      	add	x8, x8, #0x80
    35b8:      	ldr	w9, [sp, #0xd8]
    35bc:      	ldr	x8, [sp, #0xc8]
    35c0:      	lsl	w9, w9, #4
    35c4:      	add	x8, x8, x9
    35c8:      	add	x2, x8, #0x80
    35cc:      	blr	x10
    35d0:      	ldr	w8, [sp, #0x58]
    35d4:      	str	w8, [x29, #0x74]
    35d8:      	mov	w8, #0x5f60             // =24416
    35dc:      	str	x22, [sp, #0xe8]
    35e0:      	add	x23, x24, #0xae0
    35e4:      	mov	w19, #0x8               // =8
    35e8:      	add	x25, x22, x8
    35ec:      	add	x8, sp, #0x58
    35f0:      	mov	w9, #0x4                // =4
    35f4:      	add	x0, sp, #0x58
    35f8:      	mov	w1, #0x8                // =8
    35fc:      	mov	x2, x23
    3600:      	mov	w21, #0x4               // =4
    3604:      	blr	x9
    3608:      	ldr	x20, [sp, #0x58]
    360c:      	ldr	x9, [sp, #0xe8]
    3610:      	mov	w8, #0x5f68             // =24424
    3614:      	mov	w1, #0x8                // =8
    3618:      	add	x0, x9, x8
    361c:      	add	x2, x20, #0x40
    3620:      	mov	w8, #0x4                // =4
    3624:      	blr	x8
    3628:      	ldr	x9, [sp, #0xe8]
    362c:      	mov	w8, #0x5f70             // =24432
    3630:      	add	x2, x20, #0x30
    3634:      	mov	w1, #0x8                // =8
    3638:      	add	x0, x9, x8
    363c:      	mov	w8, #0x4                // =4
    3640:      	blr	x8
    3644:      	add	x2, x20, #0x38
    3648:      	mov	w8, #0x4                // =4
    364c:      	mov	x0, x25
    3650:      	mov	w1, #0x8                // =8
    3654:      	blr	x8
    3658:      	ldr	x9, [sp, #0xe8]
    365c:      	mov	w8, #0x5f38             // =24376
    3660:      	add	x2, x24, #0xb50
    3664:      	add	x0, sp, #0xd8
    3668:      	mov	w1, #0x8                // =8
    366c:      	add	x25, x9, x8
    3670:      	add	x8, sp, #0xd8
    3674:      	mov	w9, #0x4                // =4
    3678:      	blr	x9
    367c:      	add	x12, sp, #0xd8
    3680:      	mov	w9, #0x48               // =72
    3684:      	add	x10, sp, #0x58
    3688:      	ldr	x8, [x12]
    368c:      	mov	w11, #0x4               // =4
    3690:      	add	x0, sp, #0x58
    3694:      	mov	w1, #0x48               // =72
    3698:      	ldr	x2, [x12]
    369c:      	blr	x11
    36a0:      	ldr	x8, [sp, #0x60]
    36a4:      	mov	w9, #0x4                // =4
    36a8:      	mov	x0, x25
    36ac:      	mov	w1, #0x4                // =4
    36b0:      	add	x8, x8, #0x218
    36b4:      	ldr	x8, [sp, #0x60]
    36b8:      	ldr	x22, [sp, #0xe8]
    36bc:      	add	x2, x8, #0x218
    36c0:      	blr	x9
    36c4:      	mov	w8, #0x5f3c             // =24380
    36c8:      	mov	w9, #0x4                // =4
    36cc:      	mov	w1, #0x4                // =4
    36d0:      	add	x0, x22, x8
    36d4:      	ldr	x8, [sp, #0x68]
    36d8:      	add	x8, x8, #0x4d8
    36dc:      	ldr	x8, [sp, #0x68]
    36e0:      	add	x2, x8, #0x4d8
    36e4:      	blr	x9
    36e8:      	mov	w8, #0x5f40             // =24384
    36ec:      	mov	w9, #0x4                // =4
    36f0:      	mov	w1, #0x4                // =4
    36f4:      	add	x0, x22, x8
    36f8:      	ldr	x8, [sp, #0x70]
    36fc:      	add	x8, x8, #0x58
    3700:      	ldr	x8, [sp, #0x70]
    3704:      	add	x2, x8, #0x58
    3708:      	blr	x9
    370c:      	str	xzr, [sp, #0xc0]
    3710:      	add	x2, x24, #0x938
    3714:      	add	x8, sp, #0xc0
    3718:      	add	x0, sp, #0xc0
    371c:      	mov	w1, #0x8                // =8
    3720:      	blr	x21
    3724:      	ldr	x8, [sp, #0xc0]
    3728:      	cbz	x8, 0x37b0 <generic_kprobe_process_filter+0x510>
    372c:      	str	wzr, [sp, #0xb8]
    3730:      	add	x8, x8, #0x4
    3734:      	add	x9, sp, #0xb8
    3738:      	mov	w10, #0x4               // =4
    373c:      	add	x0, sp, #0xb8
    3740:      	mov	w1, #0x4                // =4
    3744:      	mov	w19, #0x4               // =4
    3748:      	ldr	x8, [sp, #0xc0]
    374c:      	add	x2, x8, #0x4
    3750:      	blr	x10
    3754:      	ldr	x8, [sp, #0xc0]
    3758:      	ldrsw	x9, [sp, #0xb8]
    375c:      	add	x10, sp, #0xc8
    3760:      	mov	w11, #0x4               // =4
    3764:      	add	x0, sp, #0xc8
    3768:      	mov	w1, #0x10               // =16
    376c:      	add	x8, x8, x9, lsl #4
    3770:      	mov	w9, #0x10               // =16
    3774:      	add	x8, x8, #0x80
    3778:      	ldr	x8, [sp, #0xc0]
    377c:      	ldrsw	x9, [sp, #0xb8]
    3780:      	add	x8, x8, x9, lsl #4
    3784:      	add	x2, x8, #0x80
    3788:      	blr	x11
    378c:      	mov	w8, #0x5f44             // =24388
    3790:      	mov	w1, #0x4                // =4
    3794:      	add	x0, x22, x8
    3798:      	ldr	x8, [sp, #0xd0]
    379c:      	add	x8, x8, #0x158
    37a0:      	ldr	x8, [sp, #0xd0]
    37a4:      	add	x2, x8, #0x158
    37a8:      	blr	x19
    37ac:      	b	0x37b4 <generic_kprobe_process_filter+0x514>
    37b0:      	str	wzr, [x29, #0x84]
    37b4:      	mov	w8, #0x5f48             // =24392
    37b8:      	mov	w9, #0x4                // =4
    37bc:      	mov	w1, #0x4                // =4
    37c0:      	mov	w19, #0x4               // =4
    37c4:      	add	x0, x22, x8
    37c8:      	ldr	x8, [sp, #0x78]
    37cc:      	add	x8, x8, #0x158
    37d0:      	ldr	x8, [sp, #0x78]
    37d4:      	add	x2, x8, #0x158
    37d8:      	blr	x9
    37dc:      	mov	w8, #0x5f4c             // =24396
    37e0:      	mov	w9, #0x4                // =4
    37e4:      	mov	w1, #0x4                // =4
    37e8:      	add	x0, x22, x8
    37ec:      	ldr	x8, [sp, #0x80]
    37f0:      	add	x8, x8, #0x118
    37f4:      	ldr	x8, [sp, #0x80]
    37f8:      	add	x2, x8, #0x118
    37fc:      	blr	x9
    3800:      	mov	w8, #0x5f50             // =24400
    3804:      	mov	w9, #0x4                // =4
    3808:      	mov	w1, #0x4                // =4
    380c:      	add	x0, x22, x8
    3810:      	ldr	x8, [sp, #0x88]
    3814:      	add	x8, x8, #0x98
    3818:      	ldr	x8, [sp, #0x88]
    381c:      	add	x2, x8, #0x98
    3820:      	blr	x9
    3824:      	mov	w8, #0x5f54             // =24404
    3828:      	mov	w9, #0x4                // =4
    382c:      	mov	w1, #0x4                // =4
    3830:      	add	x0, x22, x8
    3834:      	ldr	x8, [sp, #0x90]
    3838:      	add	x8, x8, #0x98
    383c:      	ldr	x8, [sp, #0x90]
    3840:      	add	x2, x8, #0x98
    3844:      	blr	x9
    3848:      	mov	w8, #0x5f58             // =24408
    384c:      	mov	w9, #0x4                // =4
    3850:      	mov	w1, #0x4                // =4
    3854:      	add	x0, x22, x8
    3858:      	ldr	x8, [sp, #0x98]
    385c:      	add	x8, x8, #0x58
    3860:      	ldr	x8, [sp, #0x98]
    3864:      	add	x2, x8, #0x58
    3868:      	blr	x9
    386c:      	stp	xzr, xzr, [sp, #0xc0]
    3870:      	mov	w20, #0x8               // =8
    3874:      	add	x8, sp, #0xc8
    3878:      	mov	w9, #0x4                // =4
    387c:      	add	x0, sp, #0xc8
    3880:      	mov	w1, #0x8                // =8
    3884:      	mov	x2, x23
    3888:      	blr	x9
    388c:      	ldr	x8, [sp, #0xc8]
    3890:      	add	x9, sp, #0xc0
    3894:      	mov	w10, #0x4               // =4
    3898:      	add	x0, sp, #0xc0
    389c:      	mov	w1, #0x8                // =8
    38a0:      	add	x8, x8, #0x90
    38a4:      	ldr	x8, [sp, #0xc8]
    38a8:      	add	x2, x8, #0x90
    38ac:      	blr	x10
    38b0:      	mov	w8, #0x5f5c             // =24412
    38b4:      	mov	w1, #0x4                // =4
    38b8:      	add	x0, x22, x8
    38bc:      	ldr	x8, [sp, #0xc0]
    38c0:      	add	x8, x8, #0x158
    38c4:      	ldr	x8, [sp, #0xc0]
    38c8:      	add	x2, x8, #0x158
    38cc:      	blr	x19
    38d0:      	ldr	w8, [x29, #0x74]
    38d4:      	cmp	w8, #0x1
    38d8:      	b.ne	0x38e8 <generic_kprobe_process_filter+0x648>
    38dc:      	ldr	w8, [x29, #0x70]
    38e0:      	orr	w8, w8, #0x2000000
    38e4:      	str	w8, [x29, #0x70]
    38e8:      	add	x0, x29, #0xb8
    38ec:      	mov	w1, wzr
    38f0:      	mov	w2, #0x308              // =776
    38f4:      	bl	0x38f4 <generic_kprobe_process_filter+0x654>
    38f8:      	mov	w8, #0x6290             // =25232
    38fc:      	add	x2, x24, #0x858
    3900:      	mov	w19, #0x8               // =8
    3904:      	mov	w9, #0x4                // =4
    3908:      	add	x0, sp, #0xc8
    390c:      	mov	w1, #0x8                // =8
    3910:      	mov	w20, #0x4               // =4
    3914:      	add	x21, x22, x8
    3918:      	add	x8, sp, #0xc8
    391c:      	blr	x9
    3920:      	ldr	x8, [sp, #0xc8]
    3924:      	add	x9, sp, #0x58
    3928:      	add	x0, sp, #0x58
    392c:      	mov	w1, #0x8                // =8
    3930:      	add	x8, x8, #0x528
    3934:      	ldr	x8, [sp, #0xc8]
    3938:      	add	x2, x8, #0x528
    393c:      	blr	x20
    3940:      	str	wzr, [sp, #0xa4]
    3944:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3948:      	ldr	x19, [sp, #0x58]
    394c:      	mov	w8, #0x1                // =1
    3950:      	add	x9, sp, #0xa4
    3954:      	add	x1, sp, #0xa4
    3958:      	ldr	x0, [x0]
    395c:      	blr	x8
    3960:      	cbz	x0, 0x3f74 <generic_kprobe_process_filter+0xcd4>
    3964:      	mov	w8, #0x1000             // =4096
    3968:      	str	x21, [sp, #0x30]
    396c:      	str	x29, [sp, #0x40]
    3970:      	mov	x24, x0
    3974:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    3978:      	str	w8, [x29, #0x550]
    397c:      	mov	w8, #0x23               // =35
    3980:      	blr	x8
    3984:      	add	x2, x0, #0xb30
    3988:      	mov	w23, #0x8               // =8
    398c:      	add	x8, sp, #0xa8
    3990:      	mov	w9, #0x4                // =4
    3994:      	add	x0, sp, #0xa8
    3998:      	mov	w1, #0x8                // =8
    399c:      	mov	w29, #0x4               // =4
    39a0:      	blr	x9
    39a4:      	ldr	x22, [sp, #0xa8]
    39a8:      	add	x25, x19, #0x48
    39ac:      	add	x8, sp, #0xb0
    39b0:      	mov	w9, #0x4                // =4
    39b4:      	add	x0, sp, #0xb0
    39b8:      	mov	w1, #0x8                // =8
    39bc:      	mov	x2, x25
    39c0:      	blr	x9
    39c4:      	ldr	x21, [sp, #0xb0]
    39c8:      	add	x8, sp, #0x58
    39cc:      	add	x0, sp, #0x58
    39d0:      	mov	w1, #0x8                // =8
    39d4:      	add	x2, x21, #0x10
    39d8:      	blr	x29
    39dc:      	ldr	x8, [sp, #0x58]
    39e0:      	cbz	x8, 0x3c14 <generic_kprobe_process_filter+0x974>
    39e4:      	ldr	x8, [sp, #0x40]
    39e8:      	stp	xzr, xzr, [sp, #0x58]
    39ec:      	add	x21, x22, #0x18
    39f0:      	add	x9, sp, #0x58
    39f4:      	add	x2, x22, #0x20
    39f8:      	mov	w22, #0x8               // =8
    39fc:      	stp	x24, xzr, [sp, #0x68]
    3a00:      	add	x0, sp, #0x58
    3a04:      	mov	w1, #0x8                // =8
    3a08:      	add	x29, x19, #0x40
    3a0c:      	add	x19, x9, #0x8
    3a10:      	add	x24, x9, #0x18
    3a14:      	stp	xzr, xzr, [sp, #0x78]
    3a18:      	add	x23, x9, #0x20
    3a1c:      	str	x20, [sp, #0x88]
    3a20:      	str	x20, [sp, #0x28]
    3a24:      	mov	w20, #0x4               // =4
    3a28:      	ldr	w8, [x8, #0x550]
    3a2c:      	strb	wzr, [sp, #0x94]
    3a30:      	str	w8, [sp, #0x90]
    3a34:      	mov	w8, #0x4                // =4
    3a38:      	blr	x8
    3a3c:      	mov	w8, #0x4                // =4
    3a40:      	mov	x0, x19
    3a44:      	mov	w1, #0x8                // =8
    3a48:      	mov	x2, x21
    3a4c:      	blr	x8
    3a50:      	mov	w8, #0x4                // =4
    3a54:      	mov	x0, x24
    3a58:      	mov	w1, #0x8                // =8
    3a5c:      	mov	x2, x25
    3a60:      	blr	x8
    3a64:      	mov	x0, x23
    3a68:      	mov	w1, #0x8                // =8
    3a6c:      	mov	x2, x29
    3a70:      	blr	x20
    3a74:      	ldr	x8, [sp, #0x78]
    3a78:      	sub	x8, x8, #0x20
    3a7c:      	str	x8, [sp, #0x80]
    3a80:      	adrp	x8, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3a84:      	ldr	x8, [x8]
    3a88:      	ldrb	w8, [x8]
    3a8c:      	cbz	w8, 0x3c68 <generic_kprobe_process_filter+0x9c8>
    3a90:      	mov	w19, #0x800             // =2048
    3a94:      	mov	w21, #0x8               // =8
    3a98:      	add	x23, sp, #0xb8
    3a9c:      	add	x29, sp, #0xd8
    3aa0:      	b	0x3af4 <generic_kprobe_process_filter+0x854>
    3aa4:      	add	x2, x22, #0x10
    3aa8:      	mov	w8, #0x4                // =4
    3aac:      	add	x0, sp, #0xd8
    3ab0:      	mov	w1, #0x8                // =8
    3ab4:      	blr	x8
    3ab8:      	add	x20, sp, #0xd8
    3abc:      	ldr	x8, [sp, #0x80]
    3ac0:      	ldr	x9, [x20]
    3ac4:      	cmp	x8, x9
    3ac8:      	b.eq	0x3df0 <generic_kprobe_process_filter+0xb50>
    3acc:      	add	x2, x22, #0x18
    3ad0:      	mov	w8, #0x4                // =4
    3ad4:      	mov	x0, x24
    3ad8:      	mov	w1, #0x8                // =8
    3adc:      	blr	x8
    3ae0:      	ldr	x8, [x20]
    3ae4:      	add	x9, x8, #0x20
    3ae8:      	stp	x9, x8, [sp, #0x78]
    3aec:      	subs	w19, w19, #0x1
    3af0:      	b.eq	0x3df8 <generic_kprobe_process_filter+0xb58>
    3af4:      	ldp	x20, x2, [sp, #0x70]
    3af8:      	ldp	x8, x9, [sp, #0x58]
    3afc:      	cmp	x20, x8
    3b00:      	ccmp	x2, x9, #0x0, eq
    3b04:      	b.eq	0x3df0 <generic_kprobe_process_filter+0xb50>
    3b08:      	ldr	x22, [sp, #0x80]
    3b0c:      	mov	w8, #0x4                // =4
    3b10:      	add	x0, sp, #0xb8
    3b14:      	mov	w1, #0x8                // =8
    3b18:      	blr	x8
    3b1c:      	ldr	x8, [sp, #0xb8]
    3b20:      	cmp	x20, x8
    3b24:      	b.eq	0x3aa4 <generic_kprobe_process_filter+0x804>
    3b28:      	add	x25, x20, #0x18
    3b2c:      	mov	w8, #0x4                // =4
    3b30:      	add	x0, sp, #0xd8
    3b34:      	mov	w1, #0x8                // =8
    3b38:      	mov	x2, x25
    3b3c:      	blr	x8
    3b40:      	add	x8, sp, #0xd8
    3b44:      	ldr	x8, [x8]
    3b48:      	cmp	x8, x20
    3b4c:      	b.eq	0x3aa4 <generic_kprobe_process_filter+0x804>
    3b50:      	mov	w8, #0x4                // =4
    3b54:      	add	x9, sp, #0xc0
    3b58:      	add	x0, sp, #0xc0
    3b5c:      	mov	w1, #0x8                // =8
    3b60:      	mov	x2, x25
    3b64:      	blr	x8
    3b68:      	add	x2, x20, #0x20
    3b6c:      	mov	w8, #0x4                // =4
    3b70:      	mov	w9, #0x10               // =16
    3b74:      	add	x10, sp, #0xc8
    3b78:      	add	x0, sp, #0xc8
    3b7c:      	mov	w1, #0x10               // =16
    3b80:      	blr	x8
    3b84:      	ldr	w20, [sp, #0xcc]
    3b88:      	ldr	x8, [sp, #0x68]
    3b8c:      	ldr	x10, [sp, #0x88]
    3b90:      	sub	x12, x10, x8
    3b94:      	ldr	w22, [sp, #0x90]
    3b98:      	subs	w10, w20, w22
    3b9c:      	ldr	x9, [sp, #0xd0]
    3ba0:      	csel	w10, wzr, w10, lo
    3ba4:      	cmp	w22, w20
    3ba8:      	csel	w11, w22, w20, lo
    3bac:      	cinc	w13, w11, hi
    3bb0:      	sub	w14, w22, w13
    3bb4:      	subs	x12, x12, x13
    3bb8:      	str	w14, [sp, #0x90]
    3bbc:      	b.lo	0x3df8 <generic_kprobe_process_filter+0xb58>
    3bc0:      	cmp	x12, #0xfff
    3bc4:      	b.hi	0x3df8 <generic_kprobe_process_filter+0xb58>
    3bc8:      	cmp	w22, w20
    3bcc:      	b.ls	0x3bd8 <generic_kprobe_process_filter+0x938>
    3bd0:      	mov	w13, #0x2f              // =47
    3bd4:      	strb	w13, [x8, x12]
    3bd8:      	add	x25, x8, x12
    3bdc:      	cmp	w22, w20
    3be0:      	add	x2, x9, x10
    3be4:      	and	w1, w11, #0xff
    3be8:      	mov	w8, #0x4                // =4
    3bec:      	cinc	x0, x25, hi
    3bf0:      	blr	x8
    3bf4:      	cmp	w22, w20
    3bf8:      	str	x25, [sp, #0x88]
    3bfc:      	b.ls	0x3df8 <generic_kprobe_process_filter+0xb58>
    3c00:      	ldr	x8, [sp, #0xc0]
    3c04:      	str	x8, [sp, #0x70]
    3c08:      	subs	w19, w19, #0x1
    3c0c:      	b.ne	0x3af4 <generic_kprobe_process_filter+0x854>
    3c10:      	b	0x3df8 <generic_kprobe_process_filter+0xb58>
    3c14:      	add	x2, x21, #0x18
    3c18:      	mov	w8, #0x8                // =8
    3c1c:      	mov	w9, #0x4                // =4
    3c20:      	add	x10, sp, #0x58
    3c24:      	add	x0, sp, #0x58
    3c28:      	mov	w1, #0x8                // =8
    3c2c:      	blr	x9
    3c30:      	ldr	x8, [sp, #0x58]
    3c34:      	cmp	x8, x21
    3c38:      	b.eq	0x39e4 <generic_kprobe_process_filter+0x744>
    3c3c:      	ldr	x29, [sp, #0x40]
    3c40:      	ldr	w9, [x29, #0x550]
    3c44:      	sub	w8, w9, #0xa
    3c48:      	cmp	w9, #0x9
    3c4c:      	str	w8, [x29, #0x550]
    3c50:      	b.gt	0x4320 <generic_kprobe_process_filter+0x1080>
    3c54:      	ldr	x21, [sp, #0x30]
    3c58:      	mov	w9, #-0x24              // =-36
    3c5c:      	mov	x24, x20
    3c60:      	str	w9, [x29, #0x554]
    3c64:      	b	0x3e5c <generic_kprobe_process_filter+0xbbc>
    3c68:      	mov	w19, #0x800             // =2048
    3c6c:      	mov	w21, #0x8               // =8
    3c70:      	add	x23, sp, #0xb8
    3c74:      	add	x29, sp, #0xd8
    3c78:      	b	0x3cd0 <generic_kprobe_process_filter+0xa30>
    3c7c:      	nop
    3c80:      	add	x2, x22, #0x10
    3c84:      	mov	w8, #0x4                // =4
    3c88:      	add	x0, sp, #0xd8
    3c8c:      	mov	w1, #0x8                // =8
    3c90:      	blr	x8
    3c94:      	add	x20, sp, #0xd8
    3c98:      	ldr	x8, [sp, #0x80]
    3c9c:      	ldr	x9, [x20]
    3ca0:      	cmp	x8, x9
    3ca4:      	b.eq	0x3df0 <generic_kprobe_process_filter+0xb50>
    3ca8:      	add	x2, x22, #0x18
    3cac:      	mov	w8, #0x4                // =4
    3cb0:      	mov	x0, x24
    3cb4:      	mov	w1, #0x8                // =8
    3cb8:      	blr	x8
    3cbc:      	ldr	x8, [x20]
    3cc0:      	add	x9, x8, #0x20
    3cc4:      	stp	x9, x8, [sp, #0x78]
    3cc8:      	subs	w19, w19, #0x1
    3ccc:      	b.eq	0x3df8 <generic_kprobe_process_filter+0xb58>
    3cd0:      	ldp	x20, x2, [sp, #0x70]
    3cd4:      	ldp	x8, x9, [sp, #0x58]
    3cd8:      	cmp	x20, x8
    3cdc:      	ccmp	x2, x9, #0x0, eq
    3ce0:      	b.eq	0x3df0 <generic_kprobe_process_filter+0xb50>
    3ce4:      	ldr	x22, [sp, #0x80]
    3ce8:      	mov	w8, #0x4                // =4
    3cec:      	add	x0, sp, #0xb8
    3cf0:      	mov	w1, #0x8                // =8
    3cf4:      	blr	x8
    3cf8:      	ldr	x8, [sp, #0xb8]
    3cfc:      	cmp	x20, x8
    3d00:      	b.eq	0x3c80 <generic_kprobe_process_filter+0x9e0>
    3d04:      	add	x25, x20, #0x18
    3d08:      	mov	w8, #0x4                // =4
    3d0c:      	add	x0, sp, #0xd8
    3d10:      	mov	w1, #0x8                // =8
    3d14:      	mov	x2, x25
    3d18:      	blr	x8
    3d1c:      	add	x8, sp, #0xd8
    3d20:      	ldr	x8, [x8]
    3d24:      	cmp	x8, x20
    3d28:      	b.eq	0x3c80 <generic_kprobe_process_filter+0x9e0>
    3d2c:      	mov	w8, #0x4                // =4
    3d30:      	add	x9, sp, #0xc0
    3d34:      	add	x0, sp, #0xc0
    3d38:      	mov	w1, #0x8                // =8
    3d3c:      	mov	x2, x25
    3d40:      	blr	x8
    3d44:      	add	x2, x20, #0x20
    3d48:      	mov	w8, #0x4                // =4
    3d4c:      	mov	w9, #0x10               // =16
    3d50:      	add	x10, sp, #0xc8
    3d54:      	add	x0, sp, #0xc8
    3d58:      	mov	w1, #0x10               // =16
    3d5c:      	blr	x8
    3d60:      	ldr	w20, [sp, #0xcc]
    3d64:      	ldr	x8, [sp, #0x68]
    3d68:      	ldr	x10, [sp, #0x88]
    3d6c:      	sub	x12, x10, x8
    3d70:      	ldr	w22, [sp, #0x90]
    3d74:      	subs	w10, w20, w22
    3d78:      	ldr	x9, [sp, #0xd0]
    3d7c:      	csel	w10, wzr, w10, lo
    3d80:      	cmp	w22, w20
    3d84:      	csel	w11, w22, w20, lo
    3d88:      	cinc	w13, w11, hi
    3d8c:      	sub	w14, w22, w13
    3d90:      	subs	x12, x12, x13
    3d94:      	str	w14, [sp, #0x90]
    3d98:      	b.lo	0x3df8 <generic_kprobe_process_filter+0xb58>
    3d9c:      	cmp	x12, #0xfff
    3da0:      	b.hi	0x3df8 <generic_kprobe_process_filter+0xb58>
    3da4:      	cmp	w22, w20
    3da8:      	b.ls	0x3db4 <generic_kprobe_process_filter+0xb14>
    3dac:      	mov	w13, #0x2f              // =47
    3db0:      	strb	w13, [x8, x12]
    3db4:      	add	x25, x8, x12
    3db8:      	cmp	w22, w20
    3dbc:      	add	x2, x9, x10
    3dc0:      	and	w1, w11, #0xff
    3dc4:      	mov	w8, #0x4                // =4
    3dc8:      	cinc	x0, x25, hi
    3dcc:      	blr	x8
    3dd0:      	cmp	w22, w20
    3dd4:      	str	x25, [sp, #0x88]
    3dd8:      	b.ls	0x3df8 <generic_kprobe_process_filter+0xb58>
    3ddc:      	ldr	x8, [sp, #0xc0]
    3de0:      	str	x8, [sp, #0x70]
    3de4:      	subs	w19, w19, #0x1
    3de8:      	b.ne	0x3cd0 <generic_kprobe_process_filter+0xa30>
    3dec:      	b	0x3df8 <generic_kprobe_process_filter+0xb58>
    3df0:      	mov	w8, #0x1                // =1
    3df4:      	strb	w8, [sp, #0x94]
    3df8:      	ldr	x24, [sp, #0x88]
    3dfc:      	ldr	x9, [sp, #0x28]
    3e00:      	cmp	x24, x9
    3e04:      	b.eq	0x3e48 <generic_kprobe_process_filter+0xba8>
    3e08:      	ldrb	w8, [sp, #0x94]
    3e0c:      	ldr	x29, [sp, #0x40]
    3e10:      	cmp	w8, #0x0
    3e14:      	ldr	x21, [sp, #0x30]
    3e18:      	cset	w8, eq
    3e1c:      	lsl	w9, w8, #1
    3e20:      	ldr	w8, [sp, #0x90]
    3e24:      	cmp	w8, #0x1
    3e28:      	str	w8, [x29, #0x550]
    3e2c:      	str	w9, [x29, #0x554]
    3e30:      	b.lt	0x3e40 <generic_kprobe_process_filter+0xba0>
    3e34:      	mov	w9, #0x1000             // =4096
    3e38:      	sub	w8, w9, w8
    3e3c:      	str	w8, [x29, #0x550]
    3e40:      	cbnz	x24, 0x3e5c <generic_kprobe_process_filter+0xbbc>
    3e44:      	b	0x3f74 <generic_kprobe_process_filter+0xcd4>
    3e48:      	ldr	x29, [sp, #0x40]
    3e4c:      	ldr	x21, [sp, #0x30]
    3e50:      	mov	w8, wzr
    3e54:      	mov	x24, x9
    3e58:      	str	xzr, [x29, #0x550]
    3e5c:      	subs	w9, w8, #0x7f
    3e60:      	mov	w10, #0x7f              // =127
    3e64:      	mov	x11, x29
    3e68:      	mov	x0, x21
    3e6c:      	mov	x2, x24
    3e70:      	csel	w29, w8, w10, lo
    3e74:      	csel	w19, wzr, w9, lo
    3e78:      	cmp	w8, #0xff
    3e7c:      	mov	w9, #0xff               // =255
    3e80:      	csel	w8, w8, w9, lo
    3e84:      	and	w1, w8, #0xff
    3e88:      	str	w1, [x11, #0x550]
    3e8c:      	mov	w8, #0x4                // =4
    3e90:      	blr	x8
    3e94:      	adrp	x25, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3e98:      	ldr	x25, [x25]
    3e9c:      	cbz	x0, 0x3f0c <generic_kprobe_process_filter+0xc6c>
    3ea0:      	neg	w8, w0
    3ea4:      	mov	w9, #0x1                // =1
    3ea8:      	add	x1, sp, #0x58
    3eac:      	strh	w8, [sp, #0x58]
    3eb0:      	mov	w8, #0x8                // =8
    3eb4:      	mov	x0, x25
    3eb8:      	mov	w20, #0x1               // =1
    3ebc:      	strh	w8, [sp, #0x5a]
    3ec0:      	mov	x8, #0x2de              // =734
    3ec4:      	movk	x8, #0x4, lsl #32
    3ec8:      	stur	x8, [sp, #0x5c]
    3ecc:      	add	x8, sp, #0x58
    3ed0:      	blr	x9
    3ed4:      	cbz	x0, 0x3ee8 <generic_kprobe_process_filter+0xc48>
    3ed8:      	ldr	w8, [x0]
    3edc:      	add	w8, w8, #0x1
    3ee0:      	str	w8, [x0]
    3ee4:      	b	0x3f0c <generic_kprobe_process_filter+0xc6c>
    3ee8:      	str	w20, [sp, #0xc8]
    3eec:      	mov	x3, xzr
    3ef0:      	mov	w8, #0x2                // =2
    3ef4:      	add	x9, sp, #0x58
    3ef8:      	add	x10, sp, #0xc8
    3efc:      	add	x1, sp, #0x58
    3f00:      	add	x2, sp, #0xc8
    3f04:      	mov	x0, x25
    3f08:      	blr	x8
    3f0c:      	ldr	x9, [sp, #0xe8]
    3f10:      	mov	w8, #0x6390             // =25488
    3f14:      	add	x2, x24, x19
    3f18:      	mov	w1, w29
    3f1c:      	add	x0, x9, x8
    3f20:      	mov	w8, #0x4                // =4
    3f24:      	blr	x8
    3f28:      	ldr	x29, [sp, #0x40]
    3f2c:      	cbz	x0, 0x3f74 <generic_kprobe_process_filter+0xcd4>
    3f30:      	neg	w8, w0
    3f34:      	mov	w9, #0x1                // =1
    3f38:      	add	x1, sp, #0x58
    3f3c:      	strh	w8, [sp, #0x58]
    3f40:      	mov	w8, #0x8                // =8
    3f44:      	mov	x0, x25
    3f48:      	mov	w19, #0x1               // =1
    3f4c:      	strh	w8, [sp, #0x5a]
    3f50:      	mov	x8, #0x2e0              // =736
    3f54:      	movk	x8, #0x4, lsl #32
    3f58:      	stur	x8, [sp, #0x5c]
    3f5c:      	add	x8, sp, #0x58
    3f60:      	blr	x9
    3f64:      	cbz	x0, 0x3f9c <generic_kprobe_process_filter+0xcfc>
    3f68:      	ldr	w8, [x0]
    3f6c:      	add	w8, w8, #0x1
    3f70:      	str	w8, [x0]
    3f74:      	ldr	w8, [x29, #0x550]
    3f78:      	sub	w9, w8, #0x101
    3f7c:      	cmn	w9, #0x101
    3f80:      	b.hi	0x3fd0 <generic_kprobe_process_filter+0xd30>
    3f84:      	ldr	x20, [sp, #0x38]
    3f88:      	ldr	x22, [sp, #0xe8]
    3f8c:      	mov	w8, #-0x1               // =-1
    3f90:      	ldr	x24, [sp, #0x48]
    3f94:      	stur	w8, [x29, #0xb8]
    3f98:      	b	0x4120 <generic_kprobe_process_filter+0xe80>
    3f9c:      	str	w19, [sp, #0xc8]
    3fa0:      	mov	x3, xzr
    3fa4:      	mov	w8, #0x2                // =2
    3fa8:      	add	x9, sp, #0x58
    3fac:      	add	x10, sp, #0xc8
    3fb0:      	add	x1, sp, #0x58
    3fb4:      	add	x2, sp, #0xc8
    3fb8:      	mov	x0, x25
    3fbc:      	blr	x8
    3fc0:      	ldr	w8, [x29, #0x550]
    3fc4:      	sub	w9, w8, #0x101
    3fc8:      	cmn	w9, #0x101
    3fcc:      	b.ls	0x3f84 <generic_kprobe_process_filter+0xce4>
    3fd0:      	ldr	x22, [sp, #0xe8]
    3fd4:      	and	x24, x8, #0xff
    3fd8:      	mov	w8, #0x5f80             // =24448
    3fdc:      	mov	x2, x21
    3fe0:      	mov	w1, w24
    3fe4:      	add	x0, x22, x8
    3fe8:      	mov	w8, #0x4                // =4
    3fec:      	blr	x8
    3ff0:      	mov	x23, x0
    3ff4:      	cbz	x0, 0x4070 <generic_kprobe_process_filter+0xdd0>
    3ff8:      	neg	w8, w23
    3ffc:      	adrp	x25, 0x3000 <generic_kprobe_process_event+0x2ca0>
    4000:      	mov	w9, #0x1                // =1
    4004:      	strh	w8, [sp, #0x58]
    4008:      	mov	w8, #0xf                // =15
    400c:      	add	x1, sp, #0x58
    4010:      	mov	w19, #0x1               // =1
    4014:      	strh	w8, [sp, #0x5a]
    4018:      	mov	x8, #0x164              // =356
    401c:      	movk	x8, #0x4, lsl #32
    4020:      	stur	x8, [sp, #0x5c]
    4024:      	add	x8, sp, #0x58
    4028:      	ldr	x25, [x25]
    402c:      	mov	x0, x25
    4030:      	blr	x9
    4034:      	cbz	x0, 0x4048 <generic_kprobe_process_filter+0xda8>
    4038:      	ldr	w8, [x0]
    403c:      	add	w8, w8, #0x1
    4040:      	str	w8, [x0]
    4044:      	b	0x406c <generic_kprobe_process_filter+0xdcc>
    4048:      	str	w19, [sp, #0xc8]
    404c:      	mov	x3, xzr
    4050:      	mov	w8, #0x2                // =2
    4054:      	add	x9, sp, #0x58
    4058:      	add	x10, sp, #0xc8
    405c:      	add	x1, sp, #0x58
    4060:      	add	x2, sp, #0xc8
    4064:      	mov	x0, x25
    4068:      	blr	x8
    406c:      	ldr	x22, [sp, #0xe8]
    4070:      	cmp	w23, #0x0
    4074:      	csel	w8, w24, w23, eq
    4078:      	cmp	w24, #0x7f
    407c:      	stur	w8, [x29, #0xb8]
    4080:      	mov	w8, #0x7f               // =127
    4084:      	csel	w1, w24, w8, lo
    4088:      	mov	w8, #0x6080             // =24704
    408c:      	add	x0, x22, x8
    4090:      	mov	w8, #0x6390             // =25488
    4094:      	add	x2, x22, x8
    4098:      	mov	w8, #0x4                // =4
    409c:      	blr	x8
    40a0:      	ldr	x20, [sp, #0x38]
    40a4:      	ldr	x24, [sp, #0x48]
    40a8:      	cbz	x0, 0x4120 <generic_kprobe_process_filter+0xe80>
    40ac:      	neg	w8, w0
    40b0:      	adrp	x23, 0x4000 <generic_kprobe_process_filter+0xd60>
    40b4:      	mov	w9, #0x1                // =1
    40b8:      	strh	w8, [sp, #0x58]
    40bc:      	mov	w8, #0xf                // =15
    40c0:      	add	x1, sp, #0x58
    40c4:      	mov	w19, #0x1               // =1
    40c8:      	strh	w8, [sp, #0x5a]
    40cc:      	mov	x8, #0x16a              // =362
    40d0:      	movk	x8, #0x4, lsl #32
    40d4:      	stur	x8, [sp, #0x5c]
    40d8:      	add	x8, sp, #0x58
    40dc:      	ldr	x23, [x23]
    40e0:      	mov	x0, x23
    40e4:      	blr	x9
    40e8:      	cbz	x0, 0x40fc <generic_kprobe_process_filter+0xe5c>
    40ec:      	ldr	w8, [x0]
    40f0:      	add	w8, w8, #0x1
    40f4:      	str	w8, [x0]
    40f8:      	b	0x4120 <generic_kprobe_process_filter+0xe80>
    40fc:      	str	w19, [sp, #0xc8]
    4100:      	mov	x3, xzr
    4104:      	mov	w8, #0x2                // =2
    4108:      	add	x9, sp, #0x58
    410c:      	add	x10, sp, #0xc8
    4110:      	add	x1, sp, #0x58
    4114:      	add	x2, sp, #0xc8
    4118:      	mov	x0, x23
    411c:      	blr	x8
    4120:      	ldrb	w8, [x22, #0x1]
    4124:      	orr	w8, w8, #0x10
    4128:      	strb	w8, [x22, #0x1]
    412c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4130:      	mov	w8, #0x5ef8             // =24312
    4134:      	ldr	x0, [x0]
    4138:      	add	x1, x22, x8
    413c:      	mov	w8, #0x1                // =1
    4140:      	blr	x8
    4144:      	cbz	x0, 0x55cc <generic_kprobe_process_filter+0x232c>
    4148:      	ldr	x21, [x22, #0x5eb8]
    414c:      	cmp	x21, #0x6
    4150:      	b.hs	0x42e8 <generic_kprobe_process_filter+0x1048>
    4154:      	ldrsw	x8, [x0]
    4158:      	mov	x23, x0
    415c:      	cbz	w8, 0x4304 <generic_kprobe_process_filter+0x1064>
    4160:      	cmp	x21, x8
    4164:      	b.hs	0x42e8 <generic_kprobe_process_filter+0x1048>
    4168:      	str	x8, [sp, #0x28]
    416c:      	stp	x29, x24, [sp, #0x40]
    4170:      	adrp	x24, 0x4000 <generic_kprobe_process_filter+0xd60>
    4174:      	mov	w8, #0x1                // =1
    4178:      	add	x9, sp, #0xd8
    417c:      	str	x22, [sp, #0xe8]
    4180:      	add	x1, sp, #0xd8
    4184:      	str	x20, [sp, #0x38]
    4188:      	str	w21, [sp, #0xd8]
    418c:      	str	wzr, [sp, #0xc0]
    4190:      	ldr	x24, [x24]
    4194:      	mov	x0, x24
    4198:      	blr	x8
    419c:      	cbz	x0, 0x45ac <generic_kprobe_process_filter+0x130c>
    41a0:      	ldr	w8, [x0]
    41a4:      	mov	x25, x0
    41a8:      	cbz	w8, 0x45ac <generic_kprobe_process_filter+0x130c>
    41ac:      	ldr	x9, [sp, #0x48]
    41b0:      	ldr	w9, [x9, #0x68]
    41b4:      	tbnz	w9, #0x1f, 0x5574 <generic_kprobe_process_filter+0x22d4>
    41b8:      	cmp	w8, #0x1b
    41bc:      	b.hi	0x5574 <generic_kprobe_process_filter+0x22d4>
    41c0:      	mov	w9, #0x1                // =1
    41c4:      	lsl	w9, w9, w8
    41c8:      	tst	w9, #0x60
    41cc:      	b.ne	0x43c4 <generic_kprobe_process_filter+0x1124>
    41d0:      	mov	w10, #0x100             // =256
    41d4:      	movk	w10, #0x400, lsl #16
    41d8:      	tst	w9, w10
    41dc:      	b.ne	0x4340 <generic_kprobe_process_filter+0x10a0>
    41e0:      	mov	w9, #0x1                // =1
    41e4:      	lsl	w8, w9, w8
    41e8:      	mov	w9, #0x200              // =512
    41ec:      	movk	w9, #0x800, lsl #16
    41f0:      	tst	w8, w9
    41f4:      	b.eq	0x5574 <generic_kprobe_process_filter+0x22d4>
    41f8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    41fc:      	add	x1, x25, #0x4
    4200:      	mov	w8, #0x1                // =1
    4204:      	ldr	x0, [x0]
    4208:      	blr	x8
    420c:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4210:      	ldr	x8, [sp, #0x48]
    4214:      	mov	x20, x0
    4218:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    421c:      	mov	w9, #0x7f               // =127
    4220:      	ldr	w8, [x8, #0x68]
    4224:      	ldr	x0, [x0]
    4228:      	add	x1, sp, #0xc0
    422c:      	cmp	w8, #0x7f
    4230:      	csel	w19, w8, w9, lt
    4234:      	mov	w8, #0x1                // =1
    4238:      	add	x9, sp, #0xc0
    423c:      	blr	x8
    4240:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4244:      	sxtw	x1, w19
    4248:      	mov	x29, x0
    424c:      	lsl	w8, w1, #3
    4250:      	str	w8, [x0]
    4254:      	ldr	x8, [sp, #0x48]
    4258:      	ldr	w8, [x8, #0x6c]
    425c:      	cbnz	w8, 0x42bc <generic_kprobe_process_filter+0x101c>
    4260:      	ldr	x11, [sp, #0x48]
    4264:      	and	w13, w1, #0x7f
    4268:      	mov	x8, xzr
    426c:      	ldr	w12, [x11, #0x68]
    4270:      	add	x9, x11, #0x1f0
    4274:      	add	x10, x11, #0x170
    4278:      	sub	w11, w12, w1
    427c:      	add	w12, w12, w13
    4280:      	add	w11, w11, w13
    4284:      	mvn	w13, w1
    4288:      	add	w12, w13, w12
    428c:      	cmp	x8, #0x7f
    4290:      	b.eq	0x42b0 <generic_kprobe_process_filter+0x1010>
    4294:      	and	x13, x12, #0x7f
    4298:      	sub	w12, w12, #0x1
    429c:      	ldrb	w13, [x10, x13]
    42a0:      	strb	w13, [x9, x8]
    42a4:      	add	x8, x8, #0x1
    42a8:      	cmp	x11, x8
    42ac:      	b.ne	0x428c <generic_kprobe_process_filter+0xfec>
    42b0:      	ldr	x9, [sp, #0x48]
    42b4:      	mov	w8, #0x1                // =1
    42b8:      	str	w8, [x9, #0x6c]
    42bc:      	cmp	w1, #0x7f
    42c0:      	b.hi	0x42dc <generic_kprobe_process_filter+0x103c>
    42c4:      	ldr	x8, [sp, #0x48]
    42c8:      	add	x0, x29, #0x4
    42cc:      	add	x2, x8, #0x1f0
    42d0:      	mov	w8, #0x4                // =4
    42d4:      	blr	x8
    42d8:      	tbnz	x0, #0x3f, 0x5574 <generic_kprobe_process_filter+0x22d4>
    42dc:      	mov	w8, #0x1                // =1
    42e0:      	mov	x0, x20
    42e4:      	b	0x43bc <generic_kprobe_process_filter+0x111c>
    42e8:      	ldr	w8, [x24]
    42ec:      	str	w8, [x22, #0x10]
    42f0:      	ldr	x8, [x24, #0x8]
    42f4:      	str	x8, [x22, #0x18]
    42f8:      	ldrb	w8, [x29]
    42fc:      	cbnz	w8, 0x55b0 <generic_kprobe_process_filter+0x2310>
    4300:      	b	0x55cc <generic_kprobe_process_filter+0x232c>
    4304:      	mov	w8, #0x1                // =1
    4308:      	strb	w8, [x29]
    430c:      	ldr	w8, [x24]
    4310:      	str	w8, [x22, #0x10]
    4314:      	ldr	x8, [x24, #0x8]
    4318:      	str	x8, [x22, #0x18]
    431c:      	b	0x55b0 <generic_kprobe_process_filter+0x2310>
    4320:      	mov	w8, #0x2964             // =10596
    4324:      	add	x20, x24, #0xff6
    4328:      	strh	w8, [x24, #0xffe]
    432c:      	adrp	x8, 0x4000 <generic_kprobe_process_filter+0xd60>
    4330:      	add	x8, x8, #0x0
    4334:      	ldr	x8, [x8]
    4338:      	str	x8, [x20]
    433c:      	b	0x39e4 <generic_kprobe_process_filter+0x744>
    4340:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4344:      	add	x1, x25, #0x4
    4348:      	mov	w8, #0x1                // =1
    434c:      	ldr	x0, [x0]
    4350:      	blr	x8
    4354:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4358:      	mov	x19, x0
    435c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4360:      	mov	w8, #0x1                // =1
    4364:      	ldr	x0, [x0]
    4368:      	add	x9, sp, #0xc0
    436c:      	add	x1, sp, #0xc0
    4370:      	blr	x8
    4374:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4378:      	mov	w1, wzr
    437c:      	mov	w2, #0x104              // =260
    4380:      	mov	x29, x0
    4384:      	bl	0x4384 <generic_kprobe_process_filter+0x10e4>
    4388:      	ldr	x10, [sp, #0x48]
    438c:      	mov	x0, x29
    4390:      	ldr	w8, [x10, #0x68]
    4394:      	add	x2, x10, #0x70
    4398:      	lsl	w9, w8, #3
    439c:      	and	x8, x8, #0xff
    43a0:      	str	w9, [x0], #0x4
    43a4:      	mov	w9, #0x4                // =4
    43a8:      	ldrb	w1, [x10, #0x68]
    43ac:      	blr	x9
    43b0:      	tbnz	x0, #0x3f, 0x5574 <generic_kprobe_process_filter+0x22d4>
    43b4:      	mov	w8, #0x1                // =1
    43b8:      	mov	x0, x19
    43bc:      	mov	x1, x29
    43c0:      	b	0x4574 <generic_kprobe_process_filter+0x12d4>
    43c4:      	str	wzr, [sp, #0xc8]
    43c8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    43cc:      	mov	w8, #0x1                // =1
    43d0:      	add	x9, sp, #0xc8
    43d4:      	ldr	x0, [x0]
    43d8:      	add	x1, sp, #0xc8
    43dc:      	blr	x8
    43e0:      	cbz	x0, 0x4520 <generic_kprobe_process_filter+0x1280>
    43e4:      	ldr	x9, [sp, #0x48]
    43e8:      	ldr	x8, [x0]
    43ec:      	ldr	x9, [x9, #0x378]
    43f0:      	cmp	x8, x9
    43f4:      	b.eq	0x4520 <generic_kprobe_process_filter+0x1280>
    43f8:      	str	x0, [sp, #0x30]
    43fc:      	adrp	x8, 0x4000 <generic_kprobe_process_filter+0xd60>
    4400:      	mov	w20, wzr
    4404:      	mov	x19, xzr
    4408:      	ldr	x8, [x8]
    440c:      	ldrb	w8, [x8]
    4410:      	ldr	x9, [sp, #0x48]
    4414:      	add	x22, x9, #0x370
    4418:      	cbz	w8, 0x44e8 <generic_kprobe_process_filter+0x1248>
    441c:      	ldr	x8, [sp, #0x48]
    4420:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4424:      	add	x9, sp, #0x58
    4428:      	add	x1, sp, #0x58
    442c:      	ldr	w8, [x8, #0x10]
    4430:      	str	w8, [sp, #0x58]
    4434:      	mov	w8, #0x1                // =1
    4438:      	ldr	x0, [x0]
    443c:      	blr	x8
    4440:      	cbz	x0, 0x4510 <generic_kprobe_process_filter+0x1270>
    4444:      	mov	x29, x0
    4448:      	add	x1, x0, #0x70
    444c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4450:      	ldr	x0, [x0]
    4454:      	mov	w8, #0x1                // =1
    4458:      	blr	x8
    445c:      	cbz	x0, 0x4478 <generic_kprobe_process_filter+0x11d8>
    4460:      	ldr	x8, [x0]
    4464:      	cbz	x8, 0x4478 <generic_kprobe_process_filter+0x11d8>
    4468:      	ldaxr	x9, [x22]
    446c:      	orr	x9, x9, x8
    4470:      	stlxr	w10, x9, [x22]
    4474:      	cbnz	w10, 0x4468 <generic_kprobe_process_filter+0x11c8>
    4478:      	cmp	x29, x19
    447c:      	b.eq	0x4510 <generic_kprobe_process_filter+0x1270>
    4480:      	mov	w8, #0x86a0             // =34464
    4484:      	add	w20, w20, #0x1
    4488:      	mov	x19, x29
    448c:      	movk	w8, #0x1, lsl #16
    4490:      	cmp	w20, w8
    4494:      	b.ne	0x441c <generic_kprobe_process_filter+0x117c>
    4498:      	b	0x4510 <generic_kprobe_process_filter+0x1270>
    449c:      	mov	x29, x0
    44a0:      	add	x1, x0, #0x70
    44a4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    44a8:      	ldr	x0, [x0]
    44ac:      	mov	w8, #0x1                // =1
    44b0:      	blr	x8
    44b4:      	cbz	x0, 0x44d0 <generic_kprobe_process_filter+0x1230>
    44b8:      	ldr	x8, [x0]
    44bc:      	cbz	x8, 0x44d0 <generic_kprobe_process_filter+0x1230>
    44c0:      	ldaxr	x9, [x22]
    44c4:      	orr	x9, x9, x8
    44c8:      	stlxr	w10, x9, [x22]
    44cc:      	cbnz	w10, 0x44c0 <generic_kprobe_process_filter+0x1220>
    44d0:      	cmp	x29, x19
    44d4:      	b.eq	0x4510 <generic_kprobe_process_filter+0x1270>
    44d8:      	add	w20, w20, #0x1
    44dc:      	mov	x19, x29
    44e0:      	cmp	w20, #0x400
    44e4:      	b.eq	0x4510 <generic_kprobe_process_filter+0x1270>
    44e8:      	ldr	x8, [sp, #0x48]
    44ec:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    44f0:      	add	x9, sp, #0x58
    44f4:      	add	x1, sp, #0x58
    44f8:      	ldr	w8, [x8, #0x10]
    44fc:      	str	w8, [sp, #0x58]
    4500:      	mov	w8, #0x1                // =1
    4504:      	ldr	x0, [x0]
    4508:      	blr	x8
    450c:      	cbnz	x0, 0x449c <generic_kprobe_process_filter+0x11fc>
    4510:      	ldr	x8, [sp, #0x30]
    4514:      	ldr	x9, [sp, #0x48]
    4518:      	ldr	x8, [x8]
    451c:      	str	x8, [x9, #0x378]
    4520:      	ldr	w8, [x25, #0x8]
    4524:      	cmn	w8, #0x1
    4528:      	b.eq	0x454c <generic_kprobe_process_filter+0x12ac>
    452c:      	ldr	x9, [sp, #0x48]
    4530:      	ldr	x9, [x9, #0x370]
    4534:      	lsr	x8, x9, x8
    4538:      	tbz	w8, #0x0, 0x454c <generic_kprobe_process_filter+0x12ac>
    453c:      	mov	x0, #0xffee             // =65518
    4540:      	movk	x0, #0xadc0, lsl #16
    4544:      	movk	x0, #0xb, lsl #32
    4548:      	b	0x4578 <generic_kprobe_process_filter+0x12d8>
    454c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4550:      	mov	w8, #0x1                // =1
    4554:      	add	x9, sp, #0xd8
    4558:      	ldr	x0, [x0]
    455c:      	add	x1, sp, #0xd8
    4560:      	blr	x8
    4564:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4568:      	ldr	x8, [sp, #0x48]
    456c:      	add	x1, x8, #0x70
    4570:      	mov	w8, #0x1                // =1
    4574:      	blr	x8
    4578:      	ldr	w8, [x25]
    457c:      	cmp	w8, #0x25
    4580:      	b.hi	0x45a8 <generic_kprobe_process_filter+0x1308>
    4584:      	mov	w9, #0x1                // =1
    4588:      	lsl	x8, x9, x8
    458c:      	mov	x9, #0x50               // =80
    4590:      	movk	x9, #0xc00, lsl #16
    4594:      	movk	x9, #0x20, lsl #32
    4598:      	tst	x8, x9
    459c:      	b.eq	0x45a8 <generic_kprobe_process_filter+0x1308>
    45a0:      	cbnz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    45a4:      	b	0x45ac <generic_kprobe_process_filter+0x130c>
    45a8:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    45ac:      	adrp	x8, 0x4000 <generic_kprobe_process_filter+0xd60>
    45b0:      	ldr	x8, [x8]
    45b4:      	ldrb	w8, [x8]
    45b8:      	cbz	w8, 0x4980 <generic_kprobe_process_filter+0x16e0>
    45bc:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    45c0:      	mov	w8, #0x1                // =1
    45c4:      	ldr	x0, [x0]
    45c8:      	ldr	x1, [sp, #0x48]
    45cc:      	blr	x8
    45d0:      	cbz	x0, 0x4980 <generic_kprobe_process_filter+0x16e0>
    45d4:      	add	w8, w21, #0x5
    45d8:      	str	wzr, [sp, #0xc0]
    45dc:      	add	x9, sp, #0xd8
    45e0:      	mov	x25, x0
    45e4:      	str	w8, [sp, #0xd8]
    45e8:      	mov	w8, #0x1                // =1
    45ec:      	add	x1, sp, #0xd8
    45f0:      	mov	x0, x24
    45f4:      	blr	x8
    45f8:      	cbz	x0, 0x4980 <generic_kprobe_process_filter+0x16e0>
    45fc:      	ldr	w8, [x0]
    4600:      	mov	x24, x0
    4604:      	cbz	w8, 0x4980 <generic_kprobe_process_filter+0x16e0>
    4608:      	ldr	w9, [x25]
    460c:      	tbnz	w9, #0x1f, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4610:      	cmp	w8, #0x1b
    4614:      	b.hi	0x5574 <generic_kprobe_process_filter+0x22d4>
    4618:      	mov	w9, #0x1                // =1
    461c:      	lsl	w9, w9, w8
    4620:      	tst	w9, #0x60
    4624:      	b.ne	0x47ac <generic_kprobe_process_filter+0x150c>
    4628:      	mov	w10, #0x100             // =256
    462c:      	movk	w10, #0x400, lsl #16
    4630:      	tst	w9, w10
    4634:      	b.ne	0x472c <generic_kprobe_process_filter+0x148c>
    4638:      	mov	w9, #0x1                // =1
    463c:      	lsl	w8, w9, w8
    4640:      	mov	w9, #0x200              // =512
    4644:      	movk	w9, #0x800, lsl #16
    4648:      	tst	w8, w9
    464c:      	b.eq	0x5574 <generic_kprobe_process_filter+0x22d4>
    4650:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4654:      	add	x1, x24, #0x4
    4658:      	mov	w8, #0x1                // =1
    465c:      	ldr	x0, [x0]
    4660:      	blr	x8
    4664:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4668:      	ldr	w8, [x25]
    466c:      	mov	x20, x0
    4670:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4674:      	mov	w9, #0x7f               // =127
    4678:      	ldr	x0, [x0]
    467c:      	add	x1, sp, #0xc0
    4680:      	cmp	w8, #0x7f
    4684:      	csel	w19, w8, w9, lt
    4688:      	mov	w8, #0x1                // =1
    468c:      	add	x9, sp, #0xc0
    4690:      	blr	x8
    4694:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4698:      	sxtw	x1, w19
    469c:      	mov	x29, x0
    46a0:      	lsl	w8, w1, #3
    46a4:      	str	w8, [x0]
    46a8:      	ldr	w8, [x25, #0x4]
    46ac:      	cbnz	w8, 0x4704 <generic_kprobe_process_filter+0x1464>
    46b0:      	ldr	w12, [x25]
    46b4:      	and	w13, w1, #0x7f
    46b8:      	mov	x8, xzr
    46bc:      	add	x9, x25, #0x188
    46c0:      	add	x10, x25, #0x108
    46c4:      	sub	w11, w12, w1
    46c8:      	add	w12, w12, w13
    46cc:      	add	w11, w11, w13
    46d0:      	mvn	w13, w1
    46d4:      	add	w12, w13, w12
    46d8:      	cmp	x8, #0x7f
    46dc:      	b.eq	0x46fc <generic_kprobe_process_filter+0x145c>
    46e0:      	and	x13, x12, #0x7f
    46e4:      	sub	w12, w12, #0x1
    46e8:      	ldrb	w13, [x10, x13]
    46ec:      	strb	w13, [x9, x8]
    46f0:      	add	x8, x8, #0x1
    46f4:      	cmp	x11, x8
    46f8:      	b.ne	0x46d8 <generic_kprobe_process_filter+0x1438>
    46fc:      	mov	w8, #0x1                // =1
    4700:      	str	w8, [x25, #0x4]
    4704:      	cmp	w1, #0x7f
    4708:      	b.hi	0x4720 <generic_kprobe_process_filter+0x1480>
    470c:      	add	x0, x29, #0x4
    4710:      	add	x2, x25, #0x188
    4714:      	mov	w8, #0x4                // =4
    4718:      	blr	x8
    471c:      	tbnz	x0, #0x3f, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4720:      	mov	w8, #0x1                // =1
    4724:      	mov	x0, x20
    4728:      	b	0x47a4 <generic_kprobe_process_filter+0x1504>
    472c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4730:      	add	x1, x24, #0x4
    4734:      	mov	w8, #0x1                // =1
    4738:      	ldr	x0, [x0]
    473c:      	blr	x8
    4740:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4744:      	mov	x19, x0
    4748:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    474c:      	mov	w8, #0x1                // =1
    4750:      	ldr	x0, [x0]
    4754:      	add	x9, sp, #0xc0
    4758:      	add	x1, sp, #0xc0
    475c:      	blr	x8
    4760:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4764:      	mov	w1, wzr
    4768:      	mov	w2, #0x104              // =260
    476c:      	mov	x29, x0
    4770:      	bl	0x4770 <generic_kprobe_process_filter+0x14d0>
    4774:      	ldr	w8, [x25]
    4778:      	mov	x0, x29
    477c:      	add	x2, x25, #0x8
    4780:      	lsl	w9, w8, #3
    4784:      	and	x8, x8, #0xff
    4788:      	str	w9, [x0], #0x4
    478c:      	mov	w9, #0x4                // =4
    4790:      	ldrb	w1, [x25]
    4794:      	blr	x9
    4798:      	tbnz	x0, #0x3f, 0x5574 <generic_kprobe_process_filter+0x22d4>
    479c:      	mov	w8, #0x1                // =1
    47a0:      	mov	x0, x19
    47a4:      	mov	x1, x29
    47a8:      	b	0x4948 <generic_kprobe_process_filter+0x16a8>
    47ac:      	str	wzr, [sp, #0xc8]
    47b0:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    47b4:      	mov	w8, #0x1                // =1
    47b8:      	add	x9, sp, #0xc8
    47bc:      	ldr	x0, [x0]
    47c0:      	add	x1, sp, #0xc8
    47c4:      	blr	x8
    47c8:      	cbz	x0, 0x48fc <generic_kprobe_process_filter+0x165c>
    47cc:      	ldr	x8, [x0]
    47d0:      	ldr	x9, [x25, #0x310]
    47d4:      	cmp	x8, x9
    47d8:      	b.eq	0x48fc <generic_kprobe_process_filter+0x165c>
    47dc:      	str	x0, [sp, #0x30]
    47e0:      	adrp	x8, 0x4000 <generic_kprobe_process_filter+0xd60>
    47e4:      	add	x22, x25, #0x308
    47e8:      	mov	w20, wzr
    47ec:      	ldr	x8, [x8]
    47f0:      	mov	x19, xzr
    47f4:      	ldrb	w8, [x8]
    47f8:      	cbz	w8, 0x48c8 <generic_kprobe_process_filter+0x1628>
    47fc:      	ldr	x8, [sp, #0x48]
    4800:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4804:      	add	x9, sp, #0x58
    4808:      	add	x1, sp, #0x58
    480c:      	ldr	w8, [x8, #0x10]
    4810:      	str	w8, [sp, #0x58]
    4814:      	mov	w8, #0x1                // =1
    4818:      	ldr	x0, [x0]
    481c:      	blr	x8
    4820:      	cbz	x0, 0x48f0 <generic_kprobe_process_filter+0x1650>
    4824:      	mov	x29, x0
    4828:      	add	x1, x0, #0x70
    482c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4830:      	ldr	x0, [x0]
    4834:      	mov	w8, #0x1                // =1
    4838:      	blr	x8
    483c:      	cbz	x0, 0x4858 <generic_kprobe_process_filter+0x15b8>
    4840:      	ldr	x8, [x0]
    4844:      	cbz	x8, 0x4858 <generic_kprobe_process_filter+0x15b8>
    4848:      	ldaxr	x9, [x22]
    484c:      	orr	x9, x9, x8
    4850:      	stlxr	w10, x9, [x22]
    4854:      	cbnz	w10, 0x4848 <generic_kprobe_process_filter+0x15a8>
    4858:      	cmp	x29, x19
    485c:      	b.eq	0x48f0 <generic_kprobe_process_filter+0x1650>
    4860:      	mov	w8, #0x86a0             // =34464
    4864:      	add	w20, w20, #0x1
    4868:      	mov	x19, x29
    486c:      	movk	w8, #0x1, lsl #16
    4870:      	cmp	w20, w8
    4874:      	b.ne	0x47fc <generic_kprobe_process_filter+0x155c>
    4878:      	b	0x48f0 <generic_kprobe_process_filter+0x1650>
    487c:      	mov	x29, x0
    4880:      	add	x1, x0, #0x70
    4884:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4888:      	ldr	x0, [x0]
    488c:      	mov	w8, #0x1                // =1
    4890:      	blr	x8
    4894:      	cbz	x0, 0x48b0 <generic_kprobe_process_filter+0x1610>
    4898:      	ldr	x8, [x0]
    489c:      	cbz	x8, 0x48b0 <generic_kprobe_process_filter+0x1610>
    48a0:      	ldaxr	x9, [x22]
    48a4:      	orr	x9, x9, x8
    48a8:      	stlxr	w10, x9, [x22]
    48ac:      	cbnz	w10, 0x48a0 <generic_kprobe_process_filter+0x1600>
    48b0:      	cmp	x29, x19
    48b4:      	b.eq	0x48f0 <generic_kprobe_process_filter+0x1650>
    48b8:      	add	w20, w20, #0x1
    48bc:      	mov	x19, x29
    48c0:      	cmp	w20, #0x400
    48c4:      	b.eq	0x48f0 <generic_kprobe_process_filter+0x1650>
    48c8:      	ldr	x8, [sp, #0x48]
    48cc:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    48d0:      	add	x9, sp, #0x58
    48d4:      	add	x1, sp, #0x58
    48d8:      	ldr	w8, [x8, #0x10]
    48dc:      	str	w8, [sp, #0x58]
    48e0:      	mov	w8, #0x1                // =1
    48e4:      	ldr	x0, [x0]
    48e8:      	blr	x8
    48ec:      	cbnz	x0, 0x487c <generic_kprobe_process_filter+0x15dc>
    48f0:      	ldr	x8, [sp, #0x30]
    48f4:      	ldr	x8, [x8]
    48f8:      	str	x8, [x25, #0x310]
    48fc:      	ldr	w8, [x24, #0x8]
    4900:      	cmn	w8, #0x1
    4904:      	b.eq	0x4924 <generic_kprobe_process_filter+0x1684>
    4908:      	ldr	x9, [x25, #0x308]
    490c:      	lsr	x8, x9, x8
    4910:      	tbz	w8, #0x0, 0x4924 <generic_kprobe_process_filter+0x1684>
    4914:      	mov	x0, #0xffee             // =65518
    4918:      	movk	x0, #0xadc0, lsl #16
    491c:      	movk	x0, #0xb, lsl #32
    4920:      	b	0x494c <generic_kprobe_process_filter+0x16ac>
    4924:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4928:      	mov	w8, #0x1                // =1
    492c:      	add	x9, sp, #0xd8
    4930:      	ldr	x0, [x0]
    4934:      	add	x1, sp, #0xd8
    4938:      	blr	x8
    493c:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4940:      	add	x1, x25, #0x8
    4944:      	mov	w8, #0x1                // =1
    4948:      	blr	x8
    494c:      	ldr	w8, [x24]
    4950:      	cmp	w8, #0x25
    4954:      	b.hi	0x497c <generic_kprobe_process_filter+0x16dc>
    4958:      	mov	w9, #0x1                // =1
    495c:      	lsl	x8, x9, x8
    4960:      	mov	x9, #0x50               // =80
    4964:      	movk	x9, #0xc00, lsl #16
    4968:      	movk	x9, #0x20, lsl #32
    496c:      	tst	x8, x9
    4970:      	b.eq	0x497c <generic_kprobe_process_filter+0x16dc>
    4974:      	cbnz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4978:      	b	0x4980 <generic_kprobe_process_filter+0x16e0>
    497c:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4980:      	lsl	w8, w21, #2
    4984:      	add	x9, x8, #0x4
    4988:      	ldr	w8, [x9, x23]
    498c:      	add	w9, w8, w9
    4990:      	and	w11, w9, #0x3ff
    4994:      	add	w9, w9, #0x4
    4998:      	and	x9, x9, #0x3ff
    499c:      	add	x10, x11, #0x8
    49a0:      	ldr	w9, [x9, x23]
    49a4:      	cmp	w9, #0x5
    49a8:      	b.lo	0x4a38 <generic_kprobe_process_filter+0x1798>
    49ac:      	add	x9, x10, x23
    49b0:      	ldr	w10, [x9, #0x8]
    49b4:      	ldp	w12, w22, [x9]
    49b8:      	stp	x9, x11, [sp, #0x8]
    49bc:      	mov	w9, #0x4                // =4
    49c0:      	cmp	w10, #0x4
    49c4:      	stp	xzr, xzr, [sp, #0x58]
    49c8:      	csel	w9, w10, w9, lo
    49cc:      	cmp	w12, #0x6
    49d0:      	b.ne	0x49dc <generic_kprobe_process_filter+0x173c>
    49d4:      	mov	x11, #0x100000001       // =4294967297
    49d8:      	stp	x11, x11, [sp, #0x58]
    49dc:      	cbz	w10, 0x4e40 <generic_kprobe_process_filter+0x1ba0>
    49e0:      	ldr	x10, [sp, #0x48]
    49e4:      	add	w8, w8, w21, lsl #2
    49e8:      	tst	x22, #0x1
    49ec:      	add	x25, sp, #0x58
    49f0:      	str	w12, [sp, #0x30]
    49f4:      	add	w8, w8, #0x4
    49f8:      	and	x8, x8, #0x3ff
    49fc:      	add	x21, x8, #0x14
    4a00:      	sub	x8, x9, #0x1
    4a04:      	mov	w9, #0x3                // =3
    4a08:      	add	x11, x10, #0x24
    4a0c:      	str	x11, [sp, #0x20]
    4a10:      	csel	x11, x10, x11, eq
    4a14:      	cmp	x8, #0x3
    4a18:      	add	x10, x10, #0x10
    4a1c:      	csel	x8, x8, x9, lo
    4a20:      	and	x9, x21, #0x7fc
    4a24:      	mov	x20, x11
    4a28:      	str	x10, [sp, #0x18]
    4a2c:      	add	x19, x23, x9
    4a30:      	add	x24, x8, #0x1
    4a34:      	b	0x4a70 <generic_kprobe_process_filter+0x17d0>
    4a38:      	mov	w9, #0x1                // =1
    4a3c:      	mov	w8, w10
    4a40:      	b	0x4e88 <generic_kprobe_process_filter+0x1be8>
    4a44:      	mov	w8, #0x1                // =1
    4a48:      	ldr	w12, [sp, #0x30]
    4a4c:      	mov	x11, x20
    4a50:      	cmp	w12, #0x6
    4a54:      	eor	w8, w8, #0x1
    4a58:      	csinc	w9, w8, wzr, eq
    4a5c:      	str	w9, [x25], #0x4
    4a60:      	add	x21, x21, #0x4
    4a64:      	add	x19, x19, #0x4
    4a68:      	subs	x24, x24, #0x1
    4a6c:      	b.eq	0x4e40 <generic_kprobe_process_filter+0x1ba0>
    4a70:      	cmp	x21, #0x3e8
    4a74:      	b.ls	0x4c98 <generic_kprobe_process_filter+0x19f8>
    4a78:      	mov	x29, xzr
    4a7c:      	tbz	w22, #0x1, 0x4ca0 <generic_kprobe_process_filter+0x1a00>
    4a80:      	tbnz	w22, #0x0, 0x4ccc <generic_kprobe_process_filter+0x1a2c>
    4a84:      	ldr	x10, [sp, #0x48]
    4a88:      	mov	w8, #0x1                // =1
    4a8c:      	ldr	w9, [x10]
    4a90:      	cmp	x29, x9
    4a94:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4a98:      	ldr	w9, [x10, #0x10]
    4a9c:      	cmp	x29, x9
    4aa0:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4aa4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4aa8:      	mov	w8, #0x1                // =1
    4aac:      	ldr	x0, [x0]
    4ab0:      	ldr	x1, [sp, #0x18]
    4ab4:      	blr	x8
    4ab8:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4abc:      	ldr	w9, [x0]
    4ac0:      	mov	x1, x0
    4ac4:      	mov	w8, #0x1                // =1
    4ac8:      	cmp	x29, x9
    4acc:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4ad0:      	ldr	w9, [x1, #0x10]!
    4ad4:      	ldr	w12, [sp, #0x30]
    4ad8:      	mov	x11, x20
    4adc:      	cmp	x29, x9
    4ae0:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4ae4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4ae8:      	mov	w8, #0x1                // =1
    4aec:      	ldr	x0, [x0]
    4af0:      	blr	x8
    4af4:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4af8:      	ldr	w9, [x0]
    4afc:      	mov	x1, x0
    4b00:      	mov	w8, #0x1                // =1
    4b04:      	cmp	x29, x9
    4b08:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4b0c:      	ldr	w9, [x1, #0x10]!
    4b10:      	ldr	w12, [sp, #0x30]
    4b14:      	mov	x11, x20
    4b18:      	cmp	x29, x9
    4b1c:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4b20:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4b24:      	mov	w8, #0x1                // =1
    4b28:      	ldr	x0, [x0]
    4b2c:      	blr	x8
    4b30:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4b34:      	ldr	w9, [x0]
    4b38:      	mov	x1, x0
    4b3c:      	mov	w8, #0x1                // =1
    4b40:      	cmp	x29, x9
    4b44:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4b48:      	ldr	w9, [x1, #0x10]!
    4b4c:      	ldr	w12, [sp, #0x30]
    4b50:      	mov	x11, x20
    4b54:      	cmp	x29, x9
    4b58:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4b5c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4b60:      	mov	w8, #0x1                // =1
    4b64:      	ldr	x0, [x0]
    4b68:      	blr	x8
    4b6c:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4b70:      	ldr	w9, [x0]
    4b74:      	mov	x1, x0
    4b78:      	mov	w8, #0x1                // =1
    4b7c:      	cmp	x29, x9
    4b80:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4b84:      	ldr	w9, [x1, #0x10]!
    4b88:      	ldr	w12, [sp, #0x30]
    4b8c:      	mov	x11, x20
    4b90:      	cmp	x29, x9
    4b94:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4b98:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4b9c:      	mov	w8, #0x1                // =1
    4ba0:      	ldr	x0, [x0]
    4ba4:      	blr	x8
    4ba8:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4bac:      	ldr	w9, [x0]
    4bb0:      	mov	x1, x0
    4bb4:      	mov	w8, #0x1                // =1
    4bb8:      	cmp	x29, x9
    4bbc:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4bc0:      	ldr	w9, [x1, #0x10]!
    4bc4:      	ldr	w12, [sp, #0x30]
    4bc8:      	mov	x11, x20
    4bcc:      	cmp	x29, x9
    4bd0:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4bd4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4bd8:      	mov	w8, #0x1                // =1
    4bdc:      	ldr	x0, [x0]
    4be0:      	blr	x8
    4be4:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4be8:      	ldr	w9, [x0]
    4bec:      	mov	x1, x0
    4bf0:      	mov	w8, #0x1                // =1
    4bf4:      	cmp	x29, x9
    4bf8:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4bfc:      	ldr	w9, [x1, #0x10]!
    4c00:      	ldr	w12, [sp, #0x30]
    4c04:      	mov	x11, x20
    4c08:      	cmp	x29, x9
    4c0c:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4c10:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4c14:      	mov	w8, #0x1                // =1
    4c18:      	ldr	x0, [x0]
    4c1c:      	blr	x8
    4c20:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4c24:      	ldr	w9, [x0]
    4c28:      	mov	x1, x0
    4c2c:      	mov	w8, #0x1                // =1
    4c30:      	cmp	x29, x9
    4c34:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4c38:      	ldr	w9, [x1, #0x10]!
    4c3c:      	ldr	w12, [sp, #0x30]
    4c40:      	mov	x11, x20
    4c44:      	cmp	x29, x9
    4c48:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4c4c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4c50:      	mov	w8, #0x1                // =1
    4c54:      	ldr	x0, [x0]
    4c58:      	blr	x8
    4c5c:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4c60:      	ldr	w9, [x0]
    4c64:      	mov	x1, x0
    4c68:      	mov	w8, #0x1                // =1
    4c6c:      	cmp	x29, x9
    4c70:      	b.eq	0x4a48 <generic_kprobe_process_filter+0x17a8>
    4c74:      	ldr	w9, [x1, #0x10]!
    4c78:      	ldr	w12, [sp, #0x30]
    4c7c:      	mov	x11, x20
    4c80:      	cmp	x29, x9
    4c84:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4c88:      	adrp	x9, 0x4000 <generic_kprobe_process_filter+0xd60>
    4c8c:      	mov	w8, #0x1                // =1
    4c90:      	ldr	x9, [x9]
    4c94:      	b	0x4e18 <generic_kprobe_process_filter+0x1b78>
    4c98:      	ldr	w29, [x19]
    4c9c:      	tbnz	w22, #0x1, 0x4a80 <generic_kprobe_process_filter+0x17e0>
    4ca0:      	ldr	w8, [x11]
    4ca4:      	cmp	w12, #0x5
    4ca8:      	b.ne	0x4cbc <generic_kprobe_process_filter+0x1a1c>
    4cac:      	cmp	x29, x8
    4cb0:      	b.eq	0x4cbc <generic_kprobe_process_filter+0x1a1c>
    4cb4:      	mov	w9, wzr
    4cb8:      	b	0x4a5c <generic_kprobe_process_filter+0x17bc>
    4cbc:      	cmp	w12, #0x6
    4cc0:      	ccmp	x29, x8, #0x0, eq
    4cc4:      	cset	w9, ne
    4cc8:      	b	0x4a5c <generic_kprobe_process_filter+0x17bc>
    4ccc:      	ldr	x8, [sp, #0x20]
    4cd0:      	ldr	w9, [x8]
    4cd4:      	cbz	w9, 0x4a5c <generic_kprobe_process_filter+0x17bc>
    4cd8:      	mov	w8, #0x1                // =1
    4cdc:      	cbz	x29, 0x4a50 <generic_kprobe_process_filter+0x17b0>
    4ce0:      	cmp	x29, x9
    4ce4:      	b.eq	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4ce8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4cec:      	mov	w8, #0x1                // =1
    4cf0:      	ldr	x0, [x0]
    4cf4:      	ldr	x1, [sp, #0x18]
    4cf8:      	blr	x8
    4cfc:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4d00:      	ldr	w8, [x0, #0x24]
    4d04:      	cmp	x29, x8
    4d08:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4d0c:      	add	x1, x0, #0x10
    4d10:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4d14:      	mov	w8, #0x1                // =1
    4d18:      	ldr	x0, [x0]
    4d1c:      	blr	x8
    4d20:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4d24:      	ldr	w8, [x0, #0x24]
    4d28:      	cmp	x29, x8
    4d2c:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4d30:      	add	x1, x0, #0x10
    4d34:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4d38:      	mov	w8, #0x1                // =1
    4d3c:      	ldr	x0, [x0]
    4d40:      	blr	x8
    4d44:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4d48:      	ldr	w8, [x0, #0x24]
    4d4c:      	cmp	x29, x8
    4d50:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4d54:      	add	x1, x0, #0x10
    4d58:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4d5c:      	mov	w8, #0x1                // =1
    4d60:      	ldr	x0, [x0]
    4d64:      	blr	x8
    4d68:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4d6c:      	ldr	w8, [x0, #0x24]
    4d70:      	cmp	x29, x8
    4d74:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4d78:      	add	x1, x0, #0x10
    4d7c:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4d80:      	mov	w8, #0x1                // =1
    4d84:      	ldr	x0, [x0]
    4d88:      	blr	x8
    4d8c:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4d90:      	ldr	w8, [x0, #0x24]
    4d94:      	cmp	x29, x8
    4d98:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4d9c:      	add	x1, x0, #0x10
    4da0:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4da4:      	mov	w8, #0x1                // =1
    4da8:      	ldr	x0, [x0]
    4dac:      	blr	x8
    4db0:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4db4:      	ldr	w8, [x0, #0x24]
    4db8:      	cmp	x29, x8
    4dbc:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4dc0:      	add	x1, x0, #0x10
    4dc4:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4dc8:      	mov	w8, #0x1                // =1
    4dcc:      	ldr	x0, [x0]
    4dd0:      	blr	x8
    4dd4:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4dd8:      	ldr	w8, [x0, #0x24]
    4ddc:      	cmp	x29, x8
    4de0:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4de4:      	add	x1, x0, #0x10
    4de8:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4dec:      	mov	w8, #0x1                // =1
    4df0:      	ldr	x0, [x0]
    4df4:      	blr	x8
    4df8:      	cbz	x0, 0x4e24 <generic_kprobe_process_filter+0x1b84>
    4dfc:      	ldr	w8, [x0, #0x24]
    4e00:      	cmp	x29, x8
    4e04:      	b.eq	0x4a44 <generic_kprobe_process_filter+0x17a4>
    4e08:      	adrp	x9, 0x4000 <generic_kprobe_process_filter+0xd60>
    4e0c:      	add	x1, x0, #0x10
    4e10:      	mov	w8, #0x1                // =1
    4e14:      	ldr	x9, [x9]
    4e18:      	adrp	x0, 0x4000 <generic_kprobe_process_filter+0xd60>
    4e1c:      	ldr	x0, [x0]
    4e20:      	blr	x8
    4e24:      	ldr	w12, [sp, #0x30]
    4e28:      	mov	w8, wzr
    4e2c:      	mov	w9, wzr
    4e30:      	mov	x11, x20
    4e34:      	cmp	w12, #0x5
    4e38:      	b.ne	0x4a50 <generic_kprobe_process_filter+0x17b0>
    4e3c:      	b	0x4a5c <generic_kprobe_process_filter+0x17bc>
    4e40:      	ldp	w8, w9, [sp, #0x58]
    4e44:      	ldp	w10, w11, [sp, #0x60]
    4e48:      	cmp	w12, #0x6
    4e4c:      	b.ne	0x4e60 <generic_kprobe_process_filter+0x1bc0>
    4e50:      	and	w8, w9, w8
    4e54:      	and	w9, w10, w11
    4e58:      	and	w9, w8, w9
    4e5c:      	b	0x4e6c <generic_kprobe_process_filter+0x1bcc>
    4e60:      	orr	w8, w9, w8
    4e64:      	orr	w9, w10, w11
    4e68:      	orr	w9, w8, w9
    4e6c:      	ldr	x8, [sp, #0x10]
    4e70:      	cbz	w9, 0x5574 <generic_kprobe_process_filter+0x22d4>
    4e74:      	ldr	x10, [sp, #0x8]
    4e78:      	add	w8, w8, #0x14
    4e7c:      	ldr	w10, [x10, #0x8]
    4e80:      	ubfiz	w10, w10, #2, #3
    4e84:      	add	w8, w10, w8
    4e88:      	and	x10, x8, #0x3ff
    4e8c:      	add	w8, w8, #0x4
    4e90:      	mov	w19, #0xa               // =10
    4e94:      	ldr	w10, [x10, x23]
    4e98:      	mov	w20, #0x4               // =4
    4e9c:      	mov	x25, #0x100000001       // =4294967297
    4ea0:      	sub	w22, w10, #0x4
    4ea4:      	ldr	x10, [sp, #0xe8]
    4ea8:      	add	x10, x10, #0x20
    4eac:      	str	x10, [sp, #0x30]
    4eb0:      	b	0x4ec8 <generic_kprobe_process_filter+0x1c28>
    4eb4:      	nop
    4eb8:      	nop
    4ebc:      	nop
    4ec0:      	subs	x19, x19, #0x1
    4ec4:      	b.eq	0x5094 <generic_kprobe_process_filter+0x1df4>
    4ec8:      	cbz	w22, 0x4ec0 <generic_kprobe_process_filter+0x1c20>
    4ecc:      	and	x9, x8, #0x3ff
    4ed0:      	add	x10, x9, x23
    4ed4:      	ldr	w29, [x10, #0x8]
    4ed8:      	ldp	w9, w24, [x10]
    4edc:      	stp	xzr, xzr, [sp, #0x58]
    4ee0:      	cmp	w29, #0x4
    4ee4:      	csel	w10, w29, w20, lo
    4ee8:      	cmp	w24, #0x6
    4eec:      	b.ne	0x4ef4 <generic_kprobe_process_filter+0x1c54>
    4ef0:      	stp	x25, x25, [sp, #0x58]
    4ef4:      	add	w21, w8, #0xc
    4ef8:      	cbz	w29, 0x504c <generic_kprobe_process_filter+0x1dac>
    4efc:      	and	x9, x9, #0xf
    4f00:      	cmp	w9, #0xa
    4f04:      	b.lo	0x4f30 <generic_kprobe_process_filter+0x1c90>
    4f08:      	sub	x8, x10, #0x1
    4f0c:      	mov	w9, #0x3                // =3
    4f10:      	add	x0, sp, #0x58
    4f14:      	mov	w1, wzr
    4f18:      	cmp	x8, #0x3
    4f1c:      	csel	x8, x8, x9, lo
    4f20:      	lsl	x8, x8, #2
    4f24:      	add	x2, x8, #0x4
    4f28:      	bl	0x4f28 <generic_kprobe_process_filter+0x1c88>
    4f2c:      	b	0x504c <generic_kprobe_process_filter+0x1dac>
    4f30:      	cmp	w21, #0x3e8
    4f34:      	b.ls	0x4f40 <generic_kprobe_process_filter+0x1ca0>
    4f38:      	mov	w11, wzr
    4f3c:      	b	0x4f48 <generic_kprobe_process_filter+0x1ca8>
    4f40:      	and	w11, w21, #0xfffffffc
    4f44:      	ldr	w11, [x23, w11, uxtw]
    4f48:      	ldr	x12, [sp, #0x30]
    4f4c:      	cmp	w24, #0x5
    4f50:      	sub	x10, x10, #0x1
    4f54:      	ldr	w9, [x12, x9, lsl #2]
    4f58:      	cset	w12, ne
    4f5c:      	cmp	w24, #0x6
    4f60:      	cset	w13, ne
    4f64:      	cmp	w11, w9
    4f68:      	csinc	w11, w12, wzr, ne
    4f6c:      	csinc	w12, w13, wzr, eq
    4f70:      	and	w11, w11, w12
    4f74:      	str	w11, [sp, #0x58]
    4f78:      	cbz	x10, 0x504c <generic_kprobe_process_filter+0x1dac>
    4f7c:      	add	w11, w8, #0x10
    4f80:      	cmp	w11, #0x3e8
    4f84:      	b.ls	0x4f90 <generic_kprobe_process_filter+0x1cf0>
    4f88:      	mov	w11, wzr
    4f8c:      	b	0x4f98 <generic_kprobe_process_filter+0x1cf8>
    4f90:      	and	w11, w11, #0xfffffffc
    4f94:      	ldr	w11, [x23, w11, uxtw]
    4f98:      	cmp	w24, #0x5
    4f9c:      	cset	w12, ne
    4fa0:      	cmp	w24, #0x6
    4fa4:      	cset	w13, ne
    4fa8:      	cmp	w11, w9
    4fac:      	csinc	w11, w12, wzr, ne
    4fb0:      	csinc	w12, w13, wzr, eq
    4fb4:      	cmp	x10, #0x1
    4fb8:      	and	w11, w11, w12
    4fbc:      	str	w11, [sp, #0x5c]
    4fc0:      	b.eq	0x504c <generic_kprobe_process_filter+0x1dac>
    4fc4:      	add	w11, w8, #0x14
    4fc8:      	cmp	w11, #0x3e8
    4fcc:      	b.ls	0x4fd8 <generic_kprobe_process_filter+0x1d38>
    4fd0:      	mov	w11, wzr
    4fd4:      	b	0x4fe0 <generic_kprobe_process_filter+0x1d40>
    4fd8:      	and	w11, w11, #0xfffffffc
    4fdc:      	ldr	w11, [x23, w11, uxtw]
    4fe0:      	cmp	w24, #0x5
    4fe4:      	cset	w12, ne
    4fe8:      	cmp	w24, #0x6
    4fec:      	cset	w13, ne
    4ff0:      	cmp	w11, w9
    4ff4:      	csinc	w11, w12, wzr, ne
    4ff8:      	csinc	w12, w13, wzr, eq
    4ffc:      	cmp	x10, #0x2
    5000:      	and	w11, w11, w12
    5004:      	str	w11, [sp, #0x60]
    5008:      	b.eq	0x504c <generic_kprobe_process_filter+0x1dac>
    500c:      	add	w8, w8, #0x18
    5010:      	cmp	w8, #0x3e8
    5014:      	b.ls	0x5020 <generic_kprobe_process_filter+0x1d80>
    5018:      	mov	w8, wzr
    501c:      	b	0x5028 <generic_kprobe_process_filter+0x1d88>
    5020:      	and	w8, w8, #0xfffffffc
    5024:      	ldr	w8, [x23, w8, uxtw]
    5028:      	cmp	w24, #0x5
    502c:      	cset	w10, ne
    5030:      	cmp	w24, #0x6
    5034:      	cset	w11, ne
    5038:      	cmp	w8, w9
    503c:      	csinc	w8, w10, wzr, ne
    5040:      	csinc	w9, w11, wzr, eq
    5044:      	and	w8, w8, w9
    5048:      	str	w8, [sp, #0x64]
    504c:      	ldp	w8, w9, [sp, #0x58]
    5050:      	ldp	w10, w11, [sp, #0x60]
    5054:      	cmp	w24, #0x6
    5058:      	b.ne	0x506c <generic_kprobe_process_filter+0x1dcc>
    505c:      	and	w8, w9, w8
    5060:      	and	w9, w10, w11
    5064:      	and	w9, w8, w9
    5068:      	b	0x5078 <generic_kprobe_process_filter+0x1dd8>
    506c:      	orr	w8, w9, w8
    5070:      	orr	w9, w10, w11
    5074:      	orr	w9, w8, w9
    5078:      	cbz	w9, 0x5574 <generic_kprobe_process_filter+0x22d4>
    507c:      	lsl	w8, w29, #2
    5080:      	sub	w10, w22, w29, lsl #2
    5084:      	and	w8, w8, #0x1c
    5088:      	sub	w22, w10, #0xc
    508c:      	add	w8, w8, w21
    5090:      	b	0x4ec0 <generic_kprobe_process_filter+0x1c20>
    5094:      	mov	w10, w8
    5098:      	add	w19, w8, #0x4
    509c:      	and	x10, x10, #0x3ff
    50a0:      	ldr	w10, [x10, x23]
    50a4:      	cmp	w10, #0x4
    50a8:      	b.ne	0x5140 <generic_kprobe_process_filter+0x1ea0>
    50ac:      	cbz	w9, 0x5574 <generic_kprobe_process_filter+0x22d4>
    50b0:      	mov	w8, w19
    50b4:      	and	x8, x8, #0x3ff
    50b8:      	ldr	w9, [x8, x23]
    50bc:      	add	w8, w19, #0x4
    50c0:      	cmp	w9, #0x4
    50c4:      	mov	w9, w8
    50c8:      	b.eq	0x5470 <generic_kprobe_process_filter+0x21d0>
    50cc:      	and	x8, x8, #0x3ff
    50d0:      	add	x8, x8, x23
    50d4:      	ldp	w20, w22, [x8]
    50d8:      	mov	w8, #0xe                // =14
    50dc:      	blr	x8
    50e0:      	lsr	x8, x0, #32
    50e4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    50e8:      	add	x9, sp, #0x58
    50ec:      	str	w8, [sp, #0x58]
    50f0:      	mov	w8, #0x1                // =1
    50f4:      	add	x1, sp, #0x58
    50f8:      	ldr	x0, [x0]
    50fc:      	blr	x8
    5100:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    5104:      	cmp	w20, #0x5
    5108:      	b.eq	0x51bc <generic_kprobe_process_filter+0x1f1c>
    510c:      	cmp	w20, #0x6
    5110:      	b.ne	0x5574 <generic_kprobe_process_filter+0x22d4>
    5114:      	ldr	x11, [sp, #0xe8]
    5118:      	mov	w8, #0x5ee8             // =24296
    511c:      	add	x8, x11, x8
    5120:      	tbnz	w22, #0x0, 0x51f0 <generic_kprobe_process_filter+0x1f50>
    5124:      	ldr	w9, [x0, #0x28]
    5128:      	cbz	w9, 0x51e8 <generic_kprobe_process_filter+0x1f48>
    512c:      	ldr	x10, [sp, #0x30]
    5130:      	ldr	w10, [x10]
    5134:      	cmp	w9, w10
    5138:      	b.eq	0x51f0 <generic_kprobe_process_filter+0x1f50>
    513c:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5140:      	and	x9, x19, #0x3ff
    5144:      	add	w19, w8, #0x18
    5148:      	add	x9, x9, x23
    514c:      	ldp	w8, w10, [x9]
    5150:      	ldr	w12, [x9, #0x8]
    5154:      	ldur	x11, [x9, #0xc]
    5158:      	cbz	w12, 0x517c <generic_kprobe_process_filter+0x1edc>
    515c:      	ldr	x14, [sp, #0xe8]
    5160:      	mov	w9, wzr
    5164:      	cmp	w8, #0x2
    5168:      	b.hi	0x50ac <generic_kprobe_process_filter+0x1e0c>
    516c:      	ldr	w13, [x14, #0x44]
    5170:      	cmp	w13, w12
    5174:      	b.ne	0x5190 <generic_kprobe_process_filter+0x1ef0>
    5178:      	b	0x50ac <generic_kprobe_process_filter+0x1e0c>
    517c:      	ldr	x14, [sp, #0xe8]
    5180:      	cmp	w8, #0x2
    5184:      	b.ls	0x5190 <generic_kprobe_process_filter+0x1ef0>
    5188:      	mov	w9, wzr
    518c:      	b	0x50ac <generic_kprobe_process_filter+0x1e0c>
    5190:      	add	x9, x14, #0x48
    5194:      	cmp	w10, #0x5
    5198:      	ldr	x8, [x9, x8, lsl #3]
    519c:      	and	x8, x8, x11
    51a0:      	b.ne	0x51b0 <generic_kprobe_process_filter+0x1f10>
    51a4:      	cmp	x8, #0x0
    51a8:      	cset	w9, ne
    51ac:      	b	0x50ac <generic_kprobe_process_filter+0x1e0c>
    51b0:      	cmp	x8, #0x0
    51b4:      	cset	w9, eq
    51b8:      	b	0x50ac <generic_kprobe_process_filter+0x1e0c>
    51bc:      	ldr	x11, [sp, #0xe8]
    51c0:      	mov	w8, #0x5ee8             // =24296
    51c4:      	add	x8, x11, x8
    51c8:      	tbz	w22, #0x0, 0x5214 <generic_kprobe_process_filter+0x1f74>
    51cc:      	ldr	w9, [x0, #0x28]
    51d0:      	cbz	w9, 0x520c <generic_kprobe_process_filter+0x1f6c>
    51d4:      	ldr	x10, [sp, #0x30]
    51d8:      	ldr	w10, [x10]
    51dc:      	cmp	w9, w10
    51e0:      	b.eq	0x5214 <generic_kprobe_process_filter+0x1f74>
    51e4:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    51e8:      	mov	w9, #0x1                // =1
    51ec:      	str	x9, [x8]
    51f0:      	tbnz	w22, #0x1, 0x5238 <generic_kprobe_process_filter+0x1f98>
    51f4:      	ldr	w9, [x0, #0x2c]
    51f8:      	cbz	w9, 0x5230 <generic_kprobe_process_filter+0x1f90>
    51fc:      	ldr	w10, [x11, #0x24]
    5200:      	cmp	w9, w10
    5204:      	b.eq	0x5238 <generic_kprobe_process_filter+0x1f98>
    5208:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    520c:      	mov	w9, #0x1                // =1
    5210:      	str	x9, [x8]
    5214:      	tbz	w22, #0x1, 0x525c <generic_kprobe_process_filter+0x1fbc>
    5218:      	ldr	w9, [x0, #0x2c]
    521c:      	cbz	w9, 0x5254 <generic_kprobe_process_filter+0x1fb4>
    5220:      	ldr	w10, [x11, #0x24]
    5224:      	cmp	w9, w10
    5228:      	b.eq	0x525c <generic_kprobe_process_filter+0x1fbc>
    522c:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5230:      	mov	w9, #0x1                // =1
    5234:      	str	x9, [x8]
    5238:      	tbnz	w22, #0x2, 0x5280 <generic_kprobe_process_filter+0x1fe0>
    523c:      	ldr	w9, [x0, #0x30]
    5240:      	cbz	w9, 0x5278 <generic_kprobe_process_filter+0x1fd8>
    5244:      	ldr	w10, [x11, #0x28]
    5248:      	cmp	w9, w10
    524c:      	b.eq	0x5280 <generic_kprobe_process_filter+0x1fe0>
    5250:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5254:      	mov	w9, #0x1                // =1
    5258:      	str	x9, [x8]
    525c:      	tbz	w22, #0x2, 0x52a4 <generic_kprobe_process_filter+0x2004>
    5260:      	ldr	w9, [x0, #0x30]
    5264:      	cbz	w9, 0x529c <generic_kprobe_process_filter+0x1ffc>
    5268:      	ldr	w10, [x11, #0x28]
    526c:      	cmp	w9, w10
    5270:      	b.eq	0x52a4 <generic_kprobe_process_filter+0x2004>
    5274:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5278:      	mov	w9, #0x1                // =1
    527c:      	str	x9, [x8]
    5280:      	tbnz	w22, #0x3, 0x52c8 <generic_kprobe_process_filter+0x2028>
    5284:      	ldr	w9, [x0, #0x34]
    5288:      	cbz	w9, 0x52c0 <generic_kprobe_process_filter+0x2020>
    528c:      	ldr	w10, [x11, #0x2c]
    5290:      	cmp	w9, w10
    5294:      	b.eq	0x52c8 <generic_kprobe_process_filter+0x2028>
    5298:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    529c:      	mov	w9, #0x1                // =1
    52a0:      	str	x9, [x8]
    52a4:      	tbz	w22, #0x3, 0x52ec <generic_kprobe_process_filter+0x204c>
    52a8:      	ldr	w9, [x0, #0x34]
    52ac:      	cbz	w9, 0x52e4 <generic_kprobe_process_filter+0x2044>
    52b0:      	ldr	w10, [x11, #0x2c]
    52b4:      	cmp	w9, w10
    52b8:      	b.eq	0x52ec <generic_kprobe_process_filter+0x204c>
    52bc:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    52c0:      	mov	w9, #0x1                // =1
    52c4:      	str	x9, [x8]
    52c8:      	tbnz	w22, #0x4, 0x5310 <generic_kprobe_process_filter+0x2070>
    52cc:      	ldr	w9, [x0, #0x38]
    52d0:      	cbz	w9, 0x5308 <generic_kprobe_process_filter+0x2068>
    52d4:      	ldr	w10, [x11, #0x30]
    52d8:      	cmp	w9, w10
    52dc:      	b.eq	0x5310 <generic_kprobe_process_filter+0x2070>
    52e0:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    52e4:      	mov	w9, #0x1                // =1
    52e8:      	str	x9, [x8]
    52ec:      	tbz	w22, #0x4, 0x5334 <generic_kprobe_process_filter+0x2094>
    52f0:      	ldr	w9, [x0, #0x38]
    52f4:      	cbz	w9, 0x532c <generic_kprobe_process_filter+0x208c>
    52f8:      	ldr	w10, [x11, #0x30]
    52fc:      	cmp	w9, w10
    5300:      	b.eq	0x5334 <generic_kprobe_process_filter+0x2094>
    5304:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5308:      	mov	w9, #0x1                // =1
    530c:      	str	x9, [x8]
    5310:      	tbnz	w22, #0x5, 0x5358 <generic_kprobe_process_filter+0x20b8>
    5314:      	ldr	w9, [x0, #0x3c]
    5318:      	cbz	w9, 0x5350 <generic_kprobe_process_filter+0x20b0>
    531c:      	ldr	w10, [x11, #0x34]
    5320:      	cmp	w9, w10
    5324:      	b.eq	0x5358 <generic_kprobe_process_filter+0x20b8>
    5328:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    532c:      	mov	w9, #0x1                // =1
    5330:      	str	x9, [x8]
    5334:      	tbz	w22, #0x5, 0x537c <generic_kprobe_process_filter+0x20dc>
    5338:      	ldr	w9, [x0, #0x3c]
    533c:      	cbz	w9, 0x5374 <generic_kprobe_process_filter+0x20d4>
    5340:      	ldr	w10, [x11, #0x34]
    5344:      	cmp	w9, w10
    5348:      	b.eq	0x537c <generic_kprobe_process_filter+0x20dc>
    534c:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5350:      	mov	w9, #0x1                // =1
    5354:      	str	x9, [x8]
    5358:      	tbnz	w22, #0x6, 0x53a0 <generic_kprobe_process_filter+0x2100>
    535c:      	ldr	w9, [x0, #0x40]
    5360:      	cbz	w9, 0x5398 <generic_kprobe_process_filter+0x20f8>
    5364:      	ldr	w10, [x11, #0x38]
    5368:      	cmp	w9, w10
    536c:      	b.eq	0x53a0 <generic_kprobe_process_filter+0x2100>
    5370:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5374:      	mov	w9, #0x1                // =1
    5378:      	str	x9, [x8]
    537c:      	tbz	w22, #0x6, 0x53c4 <generic_kprobe_process_filter+0x2124>
    5380:      	ldr	w9, [x0, #0x40]
    5384:      	cbz	w9, 0x53bc <generic_kprobe_process_filter+0x211c>
    5388:      	ldr	w10, [x11, #0x38]
    538c:      	cmp	w9, w10
    5390:      	b.eq	0x53c4 <generic_kprobe_process_filter+0x2124>
    5394:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5398:      	mov	w9, #0x1                // =1
    539c:      	str	x9, [x8]
    53a0:      	tbnz	w22, #0x7, 0x53e8 <generic_kprobe_process_filter+0x2148>
    53a4:      	ldr	w9, [x0, #0x44]
    53a8:      	cbz	w9, 0x53e0 <generic_kprobe_process_filter+0x2140>
    53ac:      	ldr	w10, [x11, #0x3c]
    53b0:      	cmp	w9, w10
    53b4:      	b.eq	0x53e8 <generic_kprobe_process_filter+0x2148>
    53b8:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    53bc:      	mov	w9, #0x1                // =1
    53c0:      	str	x9, [x8]
    53c4:      	tbz	w22, #0x7, 0x5410 <generic_kprobe_process_filter+0x2170>
    53c8:      	ldr	w9, [x0, #0x44]
    53cc:      	cbz	w9, 0x5408 <generic_kprobe_process_filter+0x2168>
    53d0:      	ldr	w10, [x11, #0x3c]
    53d4:      	cmp	w9, w10
    53d8:      	b.eq	0x5410 <generic_kprobe_process_filter+0x2170>
    53dc:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    53e0:      	mov	w9, #0x1                // =1
    53e4:      	str	x9, [x8]
    53e8:      	tbnz	w22, #0x8, 0x5438 <generic_kprobe_process_filter+0x2198>
    53ec:      	ldr	w9, [x0, #0x48]
    53f0:      	cbz	w9, 0x5430 <generic_kprobe_process_filter+0x2190>
    53f4:      	ldr	x10, [sp, #0xe8]
    53f8:      	ldr	w10, [x10, #0x40]
    53fc:      	cmp	w9, w10
    5400:      	b.eq	0x5438 <generic_kprobe_process_filter+0x2198>
    5404:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5408:      	mov	w9, #0x1                // =1
    540c:      	str	x9, [x8]
    5410:      	tbz	w22, #0x8, 0x5448 <generic_kprobe_process_filter+0x21a8>
    5414:      	ldr	w9, [x0, #0x48]
    5418:      	cbz	w9, 0x5440 <generic_kprobe_process_filter+0x21a0>
    541c:      	ldr	x10, [sp, #0xe8]
    5420:      	ldr	w10, [x10, #0x40]
    5424:      	cmp	w9, w10
    5428:      	b.eq	0x5448 <generic_kprobe_process_filter+0x21a8>
    542c:      	b	0x5464 <generic_kprobe_process_filter+0x21c4>
    5430:      	mov	w9, #0x1                // =1
    5434:      	str	x9, [x8]
    5438:      	tbz	w22, #0x9, 0x544c <generic_kprobe_process_filter+0x21ac>
    543c:      	b	0x5574 <generic_kprobe_process_filter+0x22d4>
    5440:      	mov	w9, #0x1                // =1
    5444:      	str	x9, [x8]
    5448:      	tbz	w22, #0x9, 0x5574 <generic_kprobe_process_filter+0x22d4>
    544c:      	ldr	w9, [x0, #0x4c]
    5450:      	cbz	w9, 0x556c <generic_kprobe_process_filter+0x22cc>
    5454:      	ldr	x10, [sp, #0xe8]
    5458:      	ldr	w10, [x10, #0x44]
    545c:      	cmp	w9, w10
    5460:      	b.eq	0x5574 <generic_kprobe_process_filter+0x22d4>
    5464:      	add	w9, w19, #0xc
    5468:      	mov	w10, #0x1               // =1
    546c:      	str	x10, [x8]
    5470:      	and	x8, x9, #0x3ff
    5474:      	adrp	x24, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5478:      	ldr	w8, [x8, x23]
    547c:      	ldr	x24, [x24]
    5480:      	cmp	w8, #0x4
    5484:      	b.ne	0x54b8 <generic_kprobe_process_filter+0x2218>
    5488:      	ldr	x9, [sp, #0xe8]
    548c:      	mov	w8, #0x5eb8             // =24248
    5490:      	add	x8, x9, x8
    5494:      	ldr	x9, [x9, #0x5eb8]
    5498:      	and	x9, x9, #0x1f
    549c:      	add	x8, x8, x9
    54a0:      	mov	w9, #0x1                // =1
    54a4:      	strb	w9, [x8, #0x9]
    54a8:      	ldr	x8, [sp, #0x40]
    54ac:      	strb	w9, [x8, #0x20]
    54b0:      	strb	w9, [x8]
    54b4:      	b	0x5574 <generic_kprobe_process_filter+0x22d4>
    54b8:      	add	w8, w9, #0x4
    54bc:      	and	x8, x8, #0x3ff
    54c0:      	add	x8, x8, x23
    54c4:      	ldp	w21, w19, [x8]
    54c8:      	ldr	w22, [x8, #0x8]
    54cc:      	ldur	x20, [x8, #0xc]
    54d0:      	mov	w8, #0xe                // =14
    54d4:      	blr	x8
    54d8:      	lsr	x8, x0, #32
    54dc:      	add	x9, sp, #0x58
    54e0:      	add	x1, sp, #0x58
    54e4:      	str	w8, [sp, #0x58]
    54e8:      	mov	w8, #0x1                // =1
    54ec:      	mov	x0, x24
    54f0:      	blr	x8
    54f4:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x22d4>
    54f8:      	cmp	w21, #0x2
    54fc:      	cbz	w22, 0x5518 <generic_kprobe_process_filter+0x2278>
    5500:      	b.hi	0x5574 <generic_kprobe_process_filter+0x22d4>
    5504:      	ldr	x8, [sp, #0xe8]
    5508:      	ldr	w8, [x8, #0x44]
    550c:      	cmp	w8, w22
    5510:      	b.ne	0x551c <generic_kprobe_process_filter+0x227c>
    5514:      	b	0x5574 <generic_kprobe_process_filter+0x22d4>
    5518:      	b.hi	0x5574 <generic_kprobe_process_filter+0x22d4>
    551c:      	ldr	x8, [sp, #0xe8]
    5520:      	lsl	x10, x21, #3
    5524:      	add	x9, x8, #0x48
    5528:      	add	x8, x0, x21, lsl #3
    552c:      	ldr	x8, [x8, #0x50]
    5530:      	ldr	x9, [x9, x10]
    5534:      	eor	x10, x9, x8
    5538:      	tst	x10, x20
    553c:      	b.eq	0x554c <generic_kprobe_process_filter+0x22ac>
    5540:      	cmp	w19, #0x5
    5544:      	b.eq	0x555c <generic_kprobe_process_filter+0x22bc>
    5548:      	b	0x5574 <generic_kprobe_process_filter+0x22d4>
    554c:      	cmp	x8, x9
    5550:      	b.eq	0x5574 <generic_kprobe_process_filter+0x22d4>
    5554:      	cmp	w19, #0x6
    5558:      	b.ne	0x5574 <generic_kprobe_process_filter+0x22d4>
    555c:      	ldr	x9, [sp, #0xe8]
    5560:      	mov	w8, #0x1                // =1
    5564:      	str	x8, [x9, #0x5ef0]
    5568:      	b	0x5488 <generic_kprobe_process_filter+0x21e8>
    556c:      	mov	w9, #0x1                // =1
    5570:      	str	x9, [x8]
    5574:      	ldr	x9, [sp, #0xe8]
    5578:      	ldr	x10, [sp, #0x28]
    557c:      	ldr	x8, [x9, #0x5eb8]
    5580:      	add	x8, x8, #0x1
    5584:      	cmp	x8, x10
    5588:      	str	x8, [x9, #0x5eb8]
    558c:      	b.ls	0x55ec <generic_kprobe_process_filter+0x234c>
    5590:      	ldr	x10, [sp, #0x48]
    5594:      	ldr	w8, [x10]
    5598:      	str	w8, [x9, #0x10]
    559c:      	ldr	x8, [x10, #0x8]
    55a0:      	str	x8, [x9, #0x18]
    55a4:      	ldp	x20, x8, [sp, #0x38]
    55a8:      	ldrb	w8, [x8]
    55ac:      	cbz	w8, 0x55cc <generic_kprobe_process_filter+0x232c>
    55b0:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    55b4:      	mov	x8, xzr
    55b8:      	mov	w9, #0xc                // =12
    55bc:      	ldr	x1, [x1]
    55c0:      	mov	x0, x20
    55c4:      	mov	w2, wzr
    55c8:      	blr	x9
    55cc:      	ldp	x20, x19, [sp, #0x120]
    55d0:      	mov	w0, wzr
    55d4:      	ldr	x29, [sp, #0xe0]
    55d8:      	ldp	x22, x21, [sp, #0x110]
    55dc:      	ldp	x24, x23, [sp, #0x100]
    55e0:      	ldp	x30, x25, [sp, #0xf0]
    55e4:      	add	sp, sp, #0x130
    55e8:      	ret
    55ec:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    55f0:      	mov	w8, #0x2                // =2
    55f4:      	mov	w9, #0xc                // =12
    55f8:      	ldr	x1, [x1]
    55fc:      	ldr	x0, [sp, #0x38]
    5600:      	mov	w2, #0x2                // =2
    5604:      	b	0x55c8 <generic_kprobe_process_filter+0x2328>
    5608:      	nop
    560c:      	nop

0000000000005610 <generic_kprobe_filter_arg>:
    5610:      	sub	sp, sp, #0x70
    5614:      	str	x29, [sp, #0x20]
    5618:      	stp	x30, x25, [sp, #0x30]
    561c:      	stp	x24, x23, [sp, #0x40]
    5620:      	stp	x22, x21, [sp, #0x50]
    5624:      	stp	x20, x19, [sp, #0x60]
    5628:      	mov	x19, x0
    562c:      	str	wzr, [sp, #0x2c]
    5630:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5634:      	mov	w8, #0x1                // =1
    5638:      	ldr	x0, [x0]
    563c:      	add	x9, sp, #0x2c
    5640:      	add	x1, sp, #0x2c
    5644:      	blr	x8
    5648:      	cbz	x0, 0x59d4 <generic_kprobe_filter_arg+0x3c4>
    564c:      	mov	w8, #0x5ec1             // =24257
    5650:      	mov	x20, x0
    5654:      	add	x22, x0, x8
    5658:      	mov	w8, #0x5ef8             // =24312
    565c:      	add	x1, x0, x8
    5660:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5664:      	ldur	w23, [x22, #0x3f]
    5668:      	mov	w8, #0x1                // =1
    566c:      	ldr	x0, [x0]
    5670:      	blr	x8
    5674:      	cbz	x0, 0x59b8 <generic_kprobe_filter_arg+0x3a8>
    5678:      	ldrb	w8, [x22, #0x1f]
    567c:      	cbz	w8, 0x59b8 <generic_kprobe_filter_arg+0x3a8>
    5680:      	and	x8, x23, #0x7
    5684:      	mov	w10, #0x5ec1            // =24257
    5688:      	add	x9, x20, x8
    568c:      	ldrb	w9, [x9, x10]
    5690:      	cbz	w9, 0x5710 <generic_kprobe_filter_arg+0x100>
    5694:      	lsl	w8, w8, #2
    5698:      	mov	x21, x0
    569c:      	add	x8, x8, #0x4
    56a0:      	ldr	w9, [x8, x0]
    56a4:      	add	x8, x8, x9
    56a8:      	add	x8, x8, #0x4
    56ac:      	and	x9, x8, #0x3ff
    56b0:      	ldr	w9, [x9, x0]
    56b4:      	add	x8, x8, x9
    56b8:      	and	x9, x8, #0x3ff
    56bc:      	ldr	w9, [x9, x0]
    56c0:      	add	x8, x8, x9
    56c4:      	and	x9, x8, #0x3ff
    56c8:      	ldr	w9, [x9, x0]
    56cc:      	add	x8, x8, x9
    56d0:      	and	x9, x8, #0x3ff
    56d4:      	ldr	w9, [x9, x0]
    56d8:      	add	x8, x8, x9
    56dc:      	and	x9, x8, #0x3ff
    56e0:      	ldr	w9, [x9, x0]
    56e4:      	add	x25, x8, x9
    56e8:      	and	x8, x25, #0x3ff
    56ec:      	add	x29, x0, x8
    56f0:      	str	x8, [sp, #0x8]
    56f4:      	ldr	w8, [x29]
    56f8:      	cmp	w8, #0x19
    56fc:      	b.hs	0x5758 <generic_kprobe_filter_arg+0x148>
    5700:      	ldr	x8, [sp, #0x8]
    5704:      	cmp	w8, #0x1
    5708:      	b.eq	0x59b8 <generic_kprobe_filter_arg+0x3a8>
    570c:      	cbnz	w8, 0x5994 <generic_kprobe_filter_arg+0x384>
    5710:      	cmp	w23, #0x1
    5714:      	b.gt	0x5730 <generic_kprobe_filter_arg+0x120>
    5718:      	cmn	w23, #0x1
    571c:      	b.eq	0x59f4 <generic_kprobe_filter_arg+0x3e4>
    5720:      	cbz	w23, 0x5a04 <generic_kprobe_filter_arg+0x3f4>
    5724:      	cmp	w23, #0x1
    5728:      	b.eq	0x5a14 <generic_kprobe_filter_arg+0x404>
    572c:      	b	0x5748 <generic_kprobe_filter_arg+0x138>
    5730:      	cmp	w23, #0x2
    5734:      	b.eq	0x5a24 <generic_kprobe_filter_arg+0x414>
    5738:      	cmp	w23, #0x3
    573c:      	b.eq	0x5a34 <generic_kprobe_filter_arg+0x424>
    5740:      	cmp	w23, #0x4
    5744:      	b.eq	0x5a44 <generic_kprobe_filter_arg+0x434>
    5748:      	cmp	w23, #0x4
    574c:      	b.gt	0x5a70 <generic_kprobe_filter_arg+0x460>
    5750:      	add	w8, w23, #0x1
    5754:      	b	0x5a50 <generic_kprobe_filter_arg+0x440>
    5758:      	mov	w24, #0x4               // =4
    575c:      	nop
    5760:      	ldr	w8, [x29, x24]
    5764:      	tst	w8, #0x3ff
    5768:      	b.eq	0x5700 <generic_kprobe_filter_arg+0xf0>
    576c:      	add	w8, w25, w8
    5770:      	and	x8, x8, #0x3ff
    5774:      	add	x0, x21, x8
    5778:      	ldr	w9, [x0, #0x4]
    577c:      	cmp	w9, #0x23
    5780:      	b.eq	0x5710 <generic_kprobe_filter_arg+0x100>
    5784:      	ldr	w8, [x0]
    5788:      	cmp	w8, #0x4
    578c:      	b.hi	0x5710 <generic_kprobe_filter_arg+0x100>
    5790:      	add	x10, x20, x8, lsl #2
    5794:      	mov	w11, #0x5ea0            // =24224
    5798:      	ldr	w10, [x10, x11]
    579c:      	cbnz	w10, 0x5710 <generic_kprobe_filter_arg+0x100>
    57a0:      	add	x8, x20, x8, lsl #3
    57a4:      	ldr	x8, [x8, #0x5e78]
    57a8:      	and	x8, x8, #0x7ff
    57ac:      	add	x8, x20, x8
    57b0:      	add	x1, x8, #0x90
    57b4:      	ldr	w8, [x0, #0xc]
    57b8:      	cmp	w8, #0x1b
    57bc:      	b.le	0x57e0 <generic_kprobe_filter_arg+0x1d0>
    57c0:      	cmp	w8, #0x25
    57c4:      	b.gt	0x5814 <generic_kprobe_filter_arg+0x204>
    57c8:      	sub	w10, w8, #0x1c
    57cc:      	cmp	w10, #0x9
    57d0:      	b.lo	0x5858 <generic_kprobe_filter_arg+0x248>
    57d4:      	cmp	w8, #0x25
    57d8:      	b.eq	0x5940 <generic_kprobe_filter_arg+0x330>
    57dc:      	b	0x5984 <generic_kprobe_filter_arg+0x374>
    57e0:      	cmp	w8, #0x9
    57e4:      	b.le	0x5838 <generic_kprobe_filter_arg+0x228>
    57e8:      	sub	w10, w8, #0xa
    57ec:      	cmp	w10, #0x4
    57f0:      	b.lo	0x5858 <generic_kprobe_filter_arg+0x248>
    57f4:      	sub	w9, w8, #0xf
    57f8:      	cmp	w9, #0x2
    57fc:      	b.lo	0x5940 <generic_kprobe_filter_arg+0x330>
    5800:      	cmp	w8, #0x11
    5804:      	b.ne	0x5984 <generic_kprobe_filter_arg+0x374>
    5808:      	add	x1, x1, #0x4
    580c:      	bl	0x580c <generic_kprobe_filter_arg+0x1fc>
    5810:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    5814:      	cmp	w8, #0x29
    5818:      	b.gt	0x5928 <generic_kprobe_filter_arg+0x318>
    581c:      	sub	w9, w8, #0x26
    5820:      	cmp	w9, #0x2
    5824:      	b.lo	0x58dc <generic_kprobe_filter_arg+0x2cc>
    5828:      	sub	w8, w8, #0x28
    582c:      	cmp	w8, #0x2
    5830:      	b.lo	0x58d4 <generic_kprobe_filter_arg+0x2c4>
    5834:      	b	0x5984 <generic_kprobe_filter_arg+0x374>
    5838:      	cmp	w8, #0x4
    583c:      	b.gt	0x58bc <generic_kprobe_filter_arg+0x2ac>
    5840:      	cmp	w8, #0x1
    5844:      	b.eq	0x5858 <generic_kprobe_filter_arg+0x248>
    5848:      	cmp	w8, #0x2
    584c:      	b.eq	0x5964 <generic_kprobe_filter_arg+0x354>
    5850:      	cmp	w8, #0x4
    5854:      	b.ne	0x5984 <generic_kprobe_filter_arg+0x374>
    5858:      	cmp	w8, #0xb
    585c:      	b.le	0x589c <generic_kprobe_filter_arg+0x28c>
    5860:      	cmp	w8, #0x24
    5864:      	b.hi	0x5948 <generic_kprobe_filter_arg+0x338>
    5868:      	mov	w11, #0x1               // =1
    586c:      	lsl	x10, x11, x8
    5870:      	tst	x10, #0x1e00000000
    5874:      	b.ne	0x58e4 <generic_kprobe_filter_arg+0x2d4>
    5878:      	lsl	x9, x11, x8
    587c:      	tst	x9, #0x60000000
    5880:      	mov	w9, #0x1                // =1
    5884:      	b.ne	0x595c <generic_kprobe_filter_arg+0x34c>
    5888:      	lsl	x9, x9, x8
    588c:      	tst	x9, #0x180000000
    5890:      	b.eq	0x5948 <generic_kprobe_filter_arg+0x338>
    5894:      	bl	0x5894 <generic_kprobe_filter_arg+0x284>
    5898:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    589c:      	sub	w9, w8, #0xa
    58a0:      	cmp	w9, #0x2
    58a4:      	b.lo	0x5978 <generic_kprobe_filter_arg+0x368>
    58a8:      	cmp	w8, #0x1
    58ac:      	b.eq	0x5954 <generic_kprobe_filter_arg+0x344>
    58b0:      	cmp	w8, #0x4
    58b4:      	b.eq	0x5954 <generic_kprobe_filter_arg+0x344>
    58b8:      	b	0x5984 <generic_kprobe_filter_arg+0x374>
    58bc:      	cmp	w8, #0x5
    58c0:      	b.eq	0x58d4 <generic_kprobe_filter_arg+0x2c4>
    58c4:      	cmp	w8, #0x6
    58c8:      	b.eq	0x58dc <generic_kprobe_filter_arg+0x2cc>
    58cc:      	cmp	w8, #0x7
    58d0:      	b.ne	0x5984 <generic_kprobe_filter_arg+0x374>
    58d4:      	bl	0x58d4 <generic_kprobe_filter_arg+0x2c4>
    58d8:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    58dc:      	mov	w2, #0x4                // =4
    58e0:      	b	0x5968 <generic_kprobe_filter_arg+0x358>
    58e4:      	cmp	w9, #0x1e
    58e8:      	b.ne	0x5978 <generic_kprobe_filter_arg+0x368>
    58ec:      	ldr	w8, [x0, #0x10]
    58f0:      	mov	w10, #0x5ea0            // =24224
    58f4:      	and	x8, x8, #0x7
    58f8:      	add	x9, x20, x8, lsl #2
    58fc:      	ldr	w9, [x9, x10]
    5900:      	cbnz	w9, 0x5710 <generic_kprobe_filter_arg+0x100>
    5904:      	add	x8, x20, x8, lsl #3
    5908:      	ldr	x9, [x1]
    590c:      	ldr	x8, [x8, #0x5e78]
    5910:      	and	x8, x8, #0x7ff
    5914:      	add	x8, x20, x8
    5918:      	ldr	x8, [x8, #0x90]
    591c:      	bics	xzr, x8, x9
    5920:      	cset	w0, ne
    5924:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    5928:      	cmp	w8, #0x2a
    592c:      	b.eq	0x5940 <generic_kprobe_filter_arg+0x330>
    5930:      	cmp	w8, #0x2c
    5934:      	b.ne	0x5984 <generic_kprobe_filter_arg+0x374>
    5938:      	bl	0x5938 <generic_kprobe_filter_arg+0x328>
    593c:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    5940:      	bl	0x5940 <generic_kprobe_filter_arg+0x330>
    5944:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    5948:      	sub	w9, w8, #0xc
    594c:      	cmp	w9, #0x2
    5950:      	b.hs	0x5970 <generic_kprobe_filter_arg+0x360>
    5954:      	bl	0x5954 <generic_kprobe_filter_arg+0x344>
    5958:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    595c:      	bl	0x595c <generic_kprobe_filter_arg+0x34c>
    5960:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    5964:      	mov	w2, #0x8                // =8
    5968:      	bl	0x5968 <generic_kprobe_filter_arg+0x358>
    596c:      	b	0x5980 <generic_kprobe_filter_arg+0x370>
    5970:      	cmp	w8, #0x1c
    5974:      	b.ne	0x5984 <generic_kprobe_filter_arg+0x374>
    5978:      	bl	0x5978 <generic_kprobe_filter_arg+0x368>
    597c:      	nop
    5980:      	cbz	x0, 0x5710 <generic_kprobe_filter_arg+0x100>
    5984:      	add	x24, x24, #0x4
    5988:      	cmp	x24, #0x18
    598c:      	b.ne	0x5760 <generic_kprobe_filter_arg+0x150>
    5990:      	b	0x5700 <generic_kprobe_filter_arg+0xf0>
    5994:      	ldr	x8, [sp, #0x8]
    5998:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    599c:      	mov	w9, #0xc                // =12
    59a0:      	mov	x0, x19
    59a4:      	stur	w8, [x22, #0x43]
    59a8:      	mov	w8, #0x4                // =4
    59ac:      	mov	w2, #0x4                // =4
    59b0:      	ldr	x1, [x1]
    59b4:      	blr	x9
    59b8:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    59bc:      	mov	w8, #0x5                // =5
    59c0:      	mov	w9, #0xc                // =12
    59c4:      	ldr	x1, [x1]
    59c8:      	mov	x0, x19
    59cc:      	mov	w2, #0x5                // =5
    59d0:      	blr	x9
    59d4:      	ldp	x20, x19, [sp, #0x60]
    59d8:      	mov	w0, wzr
    59dc:      	ldr	x29, [sp, #0x20]
    59e0:      	ldp	x22, x21, [sp, #0x50]
    59e4:      	ldp	x24, x23, [sp, #0x40]
    59e8:      	ldp	x30, x25, [sp, #0x30]
    59ec:      	add	sp, sp, #0x70
    59f0:      	ret
    59f4:      	ldrb	w8, [x22]
    59f8:      	cbz	w8, 0x5a04 <generic_kprobe_filter_arg+0x3f4>
    59fc:      	mov	w8, wzr
    5a00:      	b	0x5a50 <generic_kprobe_filter_arg+0x440>
    5a04:      	ldrb	w8, [x22, #0x1]
    5a08:      	cbz	w8, 0x5a14 <generic_kprobe_filter_arg+0x404>
    5a0c:      	mov	w8, #0x1                // =1
    5a10:      	b	0x5a50 <generic_kprobe_filter_arg+0x440>
    5a14:      	ldrb	w8, [x22, #0x2]
    5a18:      	cbz	w8, 0x5a24 <generic_kprobe_filter_arg+0x414>
    5a1c:      	mov	w8, #0x2                // =2
    5a20:      	b	0x5a50 <generic_kprobe_filter_arg+0x440>
    5a24:      	ldrb	w8, [x22, #0x3]
    5a28:      	cbz	w8, 0x5a34 <generic_kprobe_filter_arg+0x424>
    5a2c:      	mov	w8, #0x3                // =3
    5a30:      	b	0x5a50 <generic_kprobe_filter_arg+0x440>
    5a34:      	ldrb	w8, [x22, #0x4]
    5a38:      	cbz	w8, 0x5a44 <generic_kprobe_filter_arg+0x434>
    5a3c:      	mov	w8, #0x4                // =4
    5a40:      	b	0x5a50 <generic_kprobe_filter_arg+0x440>
    5a44:      	ldrb	w8, [x22, #0x5]
    5a48:      	cbz	w8, 0x5a70 <generic_kprobe_filter_arg+0x460>
    5a4c:      	mov	w8, #0x5                // =5
    5a50:      	stur	w8, [x22, #0x3f]
    5a54:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5a58:      	mov	w8, #0x3                // =3
    5a5c:      	mov	w9, #0xc                // =12
    5a60:      	ldr	x1, [x1]
    5a64:      	mov	x0, x19
    5a68:      	mov	w2, #0x3                // =3
    5a6c:      	blr	x9
    5a70:      	ldr	x19, [x20, #0x60]
    5a74:      	mov	w8, #0xe                // =14
    5a78:      	blr	x8
    5a7c:      	stp	x19, x0, [sp, #0x10]
    5a80:      	adrp	x19, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5a84:      	mov	w8, #0x1                // =1
    5a88:      	add	x9, sp, #0x10
    5a8c:      	add	x1, sp, #0x10
    5a90:      	ldr	x19, [x19]
    5a94:      	mov	x0, x19
    5a98:      	blr	x8
    5a9c:      	cbz	x0, 0x59d4 <generic_kprobe_filter_arg+0x3c4>
    5aa0:      	mov	w8, #0x3                // =3
    5aa4:      	add	x9, sp, #0x10
    5aa8:      	add	x1, sp, #0x10
    5aac:      	mov	x0, x19
    5ab0:      	blr	x8
    5ab4:      	b	0x59d4 <generic_kprobe_filter_arg+0x3c4>
    5ab8:      	nop
    5abc:      	nop

0000000000005ac0 <generic_kprobe_actions>:
    5ac0:      	sub	sp, sp, #0x40
    5ac4:      	str	x30, [sp, #0x10]
    5ac8:      	stp	x22, x21, [sp, #0x20]
    5acc:      	stp	x20, x19, [sp, #0x30]
    5ad0:      	mov	x19, x0
    5ad4:      	str	wzr, [sp, #0xc]
    5ad8:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5adc:      	mov	w8, #0x1                // =1
    5ae0:      	ldr	x0, [x0]
    5ae4:      	add	x9, sp, #0xc
    5ae8:      	add	x1, sp, #0xc
    5aec:      	blr	x8
    5af0:      	cbz	x0, 0x5c08 <generic_kprobe_actions+0x148>
    5af4:      	mov	w8, #0x5f04             // =24324
    5af8:      	ldr	w22, [x0, x8]
    5afc:      	cmp	w22, #0x2
    5b00:      	b.lt	0x5c08 <generic_kprobe_actions+0x148>
    5b04:      	mov	w8, #0x5ef8             // =24312
    5b08:      	mov	w20, #0x1               // =1
    5b0c:      	add	x1, x0, x8
    5b10:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5b14:      	mov	w8, #0x1                // =1
    5b18:      	ldr	x0, [x0]
    5b1c:      	blr	x8
    5b20:      	cbz	x0, 0x5c08 <generic_kprobe_actions+0x148>
    5b24:      	and	x8, x22, #0x7ff
    5b28:      	mov	x21, x0
    5b2c:      	strb	w20, [sp, #0x1c]
    5b30:      	mov	w9, #0x1                // =1
    5b34:      	ldr	w8, [x0, x8]
    5b38:      	str	wzr, [sp, #0x18]
    5b3c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5b40:      	add	x1, sp, #0x18
    5b44:      	ldr	x0, [x0]
    5b48:      	add	w8, w8, w22
    5b4c:      	and	w22, w8, #0x7ff
    5b50:      	add	x8, sp, #0x18
    5b54:      	blr	x9
    5b58:      	cbz	x0, 0x5b68 <generic_kprobe_actions+0xa8>
    5b5c:      	ldrb	w8, [x0]
    5b60:      	cmp	w8, #0x0
    5b64:      	cset	w20, eq
    5b68:      	ldr	w8, [x21, x22]
    5b6c:      	cmp	w8, #0x5
    5b70:      	b.lo	0x5be4 <generic_kprobe_actions+0x124>
    5b74:      	add	x2, x21, x22
    5b78:      	add	x3, sp, #0x1c
    5b7c:      	mov	x0, x19
    5b80:      	mov	w1, wzr
    5b84:      	mov	w4, w20
    5b88:      	bl	0x5b88 <generic_kprobe_actions+0xc8>
    5b8c:      	ldr	w9, [x21, x22]
    5b90:      	lsl	w8, w0, #2
    5b94:      	add	w8, w8, #0x4
    5b98:      	cmp	w8, w9
    5b9c:      	b.hs	0x5be4 <generic_kprobe_actions+0x124>
    5ba0:      	mov	w1, w0
    5ba4:      	add	x2, x21, x22
    5ba8:      	add	x3, sp, #0x1c
    5bac:      	mov	x0, x19
    5bb0:      	mov	w4, w20
    5bb4:      	bl	0x5bb4 <generic_kprobe_actions+0xf4>
    5bb8:      	ldr	w9, [x21, x22]
    5bbc:      	lsl	w8, w0, #2
    5bc0:      	add	w8, w8, #0x4
    5bc4:      	cmp	w8, w9
    5bc8:      	b.hs	0x5be4 <generic_kprobe_actions+0x124>
    5bcc:      	mov	w1, w0
    5bd0:      	add	x2, x21, x22
    5bd4:      	add	x3, sp, #0x1c
    5bd8:      	mov	x0, x19
    5bdc:      	mov	w4, w20
    5be0:      	bl	0x5be0 <generic_kprobe_actions+0x120>
    5be4:      	ldrb	w8, [sp, #0x1c]
    5be8:      	cbz	w8, 0x5c08 <generic_kprobe_actions+0x148>
    5bec:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5bf0:      	mov	w8, #0x5                // =5
    5bf4:      	mov	w9, #0xc                // =12
    5bf8:      	ldr	x1, [x1]
    5bfc:      	mov	x0, x19
    5c00:      	mov	w2, #0x5                // =5
    5c04:      	blr	x9
    5c08:      	ldp	x20, x19, [sp, #0x30]
    5c0c:      	mov	w0, wzr
    5c10:      	ldr	x30, [sp, #0x10]
    5c14:      	ldp	x22, x21, [sp, #0x20]
    5c18:      	add	sp, sp, #0x40
    5c1c:      	ret

0000000000005c20 <generic_kprobe_output>:
    5c20:      	sub	sp, sp, #0xc0
    5c24:      	str	x29, [sp, #0x70]
    5c28:      	stp	x30, x25, [sp, #0x80]
    5c2c:      	stp	x24, x23, [sp, #0x90]
    5c30:      	stp	x22, x21, [sp, #0xa0]
    5c34:      	stp	x20, x19, [sp, #0xb0]
    5c38:      	mov	x20, x0
    5c3c:      	str	wzr, [sp, #0x4]
    5c40:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5c44:      	mov	w8, #0x1                // =1
    5c48:      	ldr	x0, [x0]
    5c4c:      	add	x9, sp, #0x4
    5c50:      	add	x1, sp, #0x4
    5c54:      	blr	x8
    5c58:      	cbz	x0, 0x61f0 <generic_kprobe_output+0x5d0>
    5c5c:      	adrp	x21, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5c60:      	ldr	x8, [x0, #0x5ee8]
    5c64:      	mov	x19, x0
    5c68:      	ldr	x21, [x21]
    5c6c:      	cbz	x8, 0x5ef8 <generic_kprobe_output+0x2d8>
    5c70:      	mov	w8, #0xe                // =14
    5c74:      	blr	x8
    5c78:      	mov	w8, #0x23               // =35
    5c7c:      	lsr	x22, x0, #32
    5c80:      	blr	x8
    5c84:      	str	w22, [sp, #0x28]
    5c88:      	mov	w8, #0x1                // =1
    5c8c:      	add	x9, sp, #0x28
    5c90:      	mov	x23, x0
    5c94:      	add	x1, sp, #0x28
    5c98:      	mov	x0, x21
    5c9c:      	blr	x8
    5ca0:      	cbz	x0, 0x5ef8 <generic_kprobe_output+0x2d8>
    5ca4:      	add	x2, x23, #0xb50
    5ca8:      	mov	w29, #0x8               // =8
    5cac:      	add	x8, sp, #0x78
    5cb0:      	mov	w9, #0x4                // =4
    5cb4:      	mov	x22, x0
    5cb8:      	add	x24, x0, #0x28
    5cbc:      	add	x0, sp, #0x78
    5cc0:      	mov	w1, #0x8                // =8
    5cc4:      	mov	w25, #0x4               // =4
    5cc8:      	blr	x9
    5ccc:      	ldr	x8, [sp, #0x78]
    5cd0:      	mov	w9, #0x48               // =72
    5cd4:      	add	x10, sp, #0x28
    5cd8:      	mov	w11, #0x4               // =4
    5cdc:      	ldr	x2, [sp, #0x78]
    5ce0:      	add	x0, sp, #0x28
    5ce4:      	mov	w1, #0x48               // =72
    5ce8:      	blr	x11
    5cec:      	ldr	x8, [sp, #0x30]
    5cf0:      	mov	w9, #0x4                // =4
    5cf4:      	mov	x0, x24
    5cf8:      	mov	w1, #0x4                // =4
    5cfc:      	add	x8, x8, #0x218
    5d00:      	ldr	x8, [sp, #0x30]
    5d04:      	add	x2, x8, #0x218
    5d08:      	blr	x9
    5d0c:      	ldr	x8, [sp, #0x38]
    5d10:      	add	x0, x22, #0x2c
    5d14:      	mov	w9, #0x4                // =4
    5d18:      	mov	w1, #0x4                // =4
    5d1c:      	add	x8, x8, #0x4d8
    5d20:      	ldr	x8, [sp, #0x38]
    5d24:      	add	x2, x8, #0x4d8
    5d28:      	blr	x9
    5d2c:      	ldr	x8, [sp, #0x40]
    5d30:      	add	x0, x22, #0x30
    5d34:      	mov	w9, #0x4                // =4
    5d38:      	mov	w1, #0x4                // =4
    5d3c:      	add	x8, x8, #0x58
    5d40:      	ldr	x8, [sp, #0x40]
    5d44:      	add	x2, x8, #0x58
    5d48:      	blr	x9
    5d4c:      	str	xzr, [sp, #0x20]
    5d50:      	add	x2, x23, #0x938
    5d54:      	add	x8, sp, #0x20
    5d58:      	add	x0, sp, #0x20
    5d5c:      	mov	w1, #0x8                // =8
    5d60:      	blr	x25
    5d64:      	ldr	x8, [sp, #0x20]
    5d68:      	cbz	x8, 0x5dec <generic_kprobe_output+0x1cc>
    5d6c:      	str	wzr, [sp, #0x1c]
    5d70:      	add	x8, x8, #0x4
    5d74:      	add	x9, sp, #0x1c
    5d78:      	mov	w10, #0x4               // =4
    5d7c:      	add	x0, sp, #0x1c
    5d80:      	mov	w1, #0x4                // =4
    5d84:      	mov	w24, #0x4               // =4
    5d88:      	ldr	x8, [sp, #0x20]
    5d8c:      	add	x2, x8, #0x4
    5d90:      	blr	x10
    5d94:      	ldr	x8, [sp, #0x20]
    5d98:      	ldrsw	x9, [sp, #0x1c]
    5d9c:      	add	x10, sp, #0x8
    5da0:      	mov	w11, #0x4               // =4
    5da4:      	add	x0, sp, #0x8
    5da8:      	mov	w1, #0x10               // =16
    5dac:      	add	x8, x8, x9, lsl #4
    5db0:      	mov	w9, #0x10               // =16
    5db4:      	add	x8, x8, #0x80
    5db8:      	ldr	x8, [sp, #0x20]
    5dbc:      	ldrsw	x9, [sp, #0x1c]
    5dc0:      	add	x8, x8, x9, lsl #4
    5dc4:      	add	x2, x8, #0x80
    5dc8:      	blr	x11
    5dcc:      	ldr	x8, [sp, #0x10]
    5dd0:      	add	x0, x22, #0x34
    5dd4:      	mov	w1, #0x4                // =4
    5dd8:      	add	x8, x8, #0x158
    5ddc:      	ldr	x8, [sp, #0x10]
    5de0:      	add	x2, x8, #0x158
    5de4:      	blr	x24
    5de8:      	b	0x5df0 <generic_kprobe_output+0x1d0>
    5dec:      	str	wzr, [x22, #0x34]
    5df0:      	ldr	x8, [sp, #0x48]
    5df4:      	add	x0, x22, #0x38
    5df8:      	mov	w9, #0x4                // =4
    5dfc:      	mov	w1, #0x4                // =4
    5e00:      	mov	w24, #0x4               // =4
    5e04:      	add	x8, x8, #0x158
    5e08:      	ldr	x8, [sp, #0x48]
    5e0c:      	add	x2, x8, #0x158
    5e10:      	blr	x9
    5e14:      	ldr	x8, [sp, #0x50]
    5e18:      	add	x0, x22, #0x3c
    5e1c:      	mov	w9, #0x4                // =4
    5e20:      	mov	w1, #0x4                // =4
    5e24:      	add	x8, x8, #0x118
    5e28:      	ldr	x8, [sp, #0x50]
    5e2c:      	add	x2, x8, #0x118
    5e30:      	blr	x9
    5e34:      	ldr	x8, [sp, #0x58]
    5e38:      	add	x0, x22, #0x40
    5e3c:      	mov	w9, #0x4                // =4
    5e40:      	mov	w1, #0x4                // =4
    5e44:      	add	x8, x8, #0x98
    5e48:      	ldr	x8, [sp, #0x58]
    5e4c:      	add	x2, x8, #0x98
    5e50:      	blr	x9
    5e54:      	ldr	x8, [sp, #0x60]
    5e58:      	add	x0, x22, #0x44
    5e5c:      	mov	w9, #0x4                // =4
    5e60:      	mov	w1, #0x4                // =4
    5e64:      	add	x8, x8, #0x98
    5e68:      	ldr	x8, [sp, #0x60]
    5e6c:      	add	x2, x8, #0x98
    5e70:      	blr	x9
    5e74:      	ldr	x8, [sp, #0x68]
    5e78:      	add	x0, x22, #0x48
    5e7c:      	mov	w9, #0x4                // =4
    5e80:      	mov	w1, #0x4                // =4
    5e84:      	add	x8, x8, #0x58
    5e88:      	ldr	x8, [sp, #0x68]
    5e8c:      	add	x2, x8, #0x58
    5e90:      	blr	x9
    5e94:      	str	xzr, [sp, #0x8]
    5e98:      	str	xzr, [sp, #0x20]
    5e9c:      	add	x2, x23, #0xae0
    5ea0:      	mov	w23, #0x8               // =8
    5ea4:      	add	x8, sp, #0x8
    5ea8:      	mov	w9, #0x4                // =4
    5eac:      	add	x0, sp, #0x8
    5eb0:      	mov	w1, #0x8                // =8
    5eb4:      	blr	x9
    5eb8:      	ldr	x8, [sp, #0x8]
    5ebc:      	add	x9, sp, #0x20
    5ec0:      	mov	w10, #0x4               // =4
    5ec4:      	add	x0, sp, #0x20
    5ec8:      	mov	w1, #0x8                // =8
    5ecc:      	add	x8, x8, #0x90
    5ed0:      	ldr	x8, [sp, #0x8]
    5ed4:      	add	x2, x8, #0x90
    5ed8:      	blr	x10
    5edc:      	ldr	x8, [sp, #0x20]
    5ee0:      	add	x0, x22, #0x4c
    5ee4:      	mov	w1, #0x4                // =4
    5ee8:      	add	x8, x8, #0x158
    5eec:      	ldr	x8, [sp, #0x20]
    5ef0:      	add	x2, x8, #0x158
    5ef4:      	blr	x24
    5ef8:      	ldr	x8, [x19, #0x5ef0]
    5efc:      	cbz	x8, 0x5f98 <generic_kprobe_output+0x378>
    5f00:      	mov	w8, #0xe                // =14
    5f04:      	blr	x8
    5f08:      	mov	w8, #0x23               // =35
    5f0c:      	lsr	x23, x0, #32
    5f10:      	blr	x8
    5f14:      	str	w23, [sp, #0x28]
    5f18:      	mov	w8, #0x1                // =1
    5f1c:      	add	x9, sp, #0x28
    5f20:      	mov	x22, x0
    5f24:      	add	x1, sp, #0x28
    5f28:      	mov	x0, x21
    5f2c:      	blr	x8
    5f30:      	cbz	x0, 0x5f98 <generic_kprobe_output+0x378>
    5f34:      	add	x2, x22, #0xae0
    5f38:      	mov	w22, #0x8               // =8
    5f3c:      	add	x8, sp, #0x28
    5f40:      	mov	w9, #0x4                // =4
    5f44:      	add	x21, x0, #0x50
    5f48:      	mov	x24, x0
    5f4c:      	add	x0, sp, #0x28
    5f50:      	mov	w1, #0x8                // =8
    5f54:      	mov	w23, #0x4               // =4
    5f58:      	blr	x9
    5f5c:      	ldr	x25, [sp, #0x28]
    5f60:      	add	x0, x24, #0x58
    5f64:      	mov	w8, #0x4                // =4
    5f68:      	mov	w1, #0x8                // =8
    5f6c:      	add	x2, x25, #0x40
    5f70:      	blr	x8
    5f74:      	add	x0, x24, #0x60
    5f78:      	add	x2, x25, #0x30
    5f7c:      	mov	w8, #0x4                // =4
    5f80:      	mov	w1, #0x8                // =8
    5f84:      	blr	x8
    5f88:      	add	x2, x25, #0x38
    5f8c:      	mov	x0, x21
    5f90:      	mov	w1, #0x8                // =8
    5f94:      	blr	x23
    5f98:      	ldr	w8, [x19, #0x4]
    5f9c:      	mov	w9, #0x2328             // =9000
    5fa0:      	str	wzr, [sp, #0x8]
    5fa4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5fa8:      	add	x1, sp, #0x8
    5fac:      	add	w8, w8, #0x90
    5fb0:      	ldr	x0, [x0]
    5fb4:      	and	w8, w8, #0x7fff
    5fb8:      	cmp	w8, w9
    5fbc:      	csel	w21, w8, w9, lo
    5fc0:      	mov	w8, #0x1                // =1
    5fc4:      	add	x9, sp, #0x8
    5fc8:      	blr	x8
    5fcc:      	cbz	x0, 0x6038 <generic_kprobe_output+0x418>
    5fd0:      	ldrb	w8, [x0, #0x28]
    5fd4:      	cbz	w8, 0x6038 <generic_kprobe_output+0x418>
    5fd8:      	adrp	x1, 0x5000 <generic_kprobe_process_filter+0x1d60>
    5fdc:      	mov	w8, #-0x1               // =-1
    5fe0:      	mov	w9, #0x19               // =25
    5fe4:      	ldr	x1, [x1]
    5fe8:      	mov	x0, x20
    5fec:      	mov	w2, #-0x1               // =-1
    5ff0:      	mov	x3, x19
    5ff4:      	mov	x4, x21
    5ff8:      	blr	x9
    5ffc:      	tbnz	x0, #0x3f, 0x60e4 <generic_kprobe_output+0x4c4>
    6000:      	str	wzr, [sp, #0x28]
    6004:      	adrp	x0, 0x6000 <generic_kprobe_output+0x3e0>
    6008:      	mov	w8, #0x1                // =1
    600c:      	add	x9, sp, #0x28
    6010:      	ldr	x0, [x0]
    6014:      	add	x1, sp, #0x28
    6018:      	blr	x8
    601c:      	cbz	x0, 0x61f0 <generic_kprobe_output+0x5d0>
    6020:      	add	x8, x0, #0x8
    6024:      	ldaxr	x9, [x8]
    6028:      	add	x9, x9, #0x1
    602c:      	stlxr	w10, x9, [x8]
    6030:      	cbnz	w10, 0x6024 <generic_kprobe_output+0x404>
    6034:      	b	0x61f0 <generic_kprobe_output+0x5d0>
    6038:      	adrp	x0, 0x6000 <generic_kprobe_output+0x3e0>
    603c:      	mov	x3, xzr
    6040:      	mov	w8, #0x82               // =130
    6044:      	ldr	x0, [x0]
    6048:      	mov	x1, x19
    604c:      	mov	x2, x21
    6050:      	blr	x8
    6054:      	tbnz	x0, #0x3f, 0x6094 <generic_kprobe_output+0x474>
    6058:      	str	wzr, [sp, #0x28]
    605c:      	adrp	x0, 0x6000 <generic_kprobe_output+0x3e0>
    6060:      	mov	w8, #0x1                // =1
    6064:      	add	x9, sp, #0x28
    6068:      	ldr	x0, [x0]
    606c:      	add	x1, sp, #0x28
    6070:      	blr	x8
    6074:      	cbz	x0, 0x61f0 <generic_kprobe_output+0x5d0>
    6078:      	add	x8, x0, #0x8
    607c:      	nop
    6080:      	ldaxr	x9, [x8]
    6084:      	add	x9, x9, #0x1
    6088:      	stlxr	w10, x9, [x8]
    608c:      	cbnz	w10, 0x6080 <generic_kprobe_output+0x460>
    6090:      	b	0x61f0 <generic_kprobe_output+0x5d0>
    6094:      	mov	x19, x0
    6098:      	str	wzr, [sp, #0x28]
    609c:      	adrp	x0, 0x6000 <generic_kprobe_output+0x3e0>
    60a0:      	mov	w8, #0x1                // =1
    60a4:      	ldr	x0, [x0]
    60a8:      	add	x9, sp, #0x28
    60ac:      	add	x1, sp, #0x28
    60b0:      	blr	x8
    60b4:      	cbz	x0, 0x61f0 <generic_kprobe_output+0x5d0>
    60b8:      	mov	x8, x19
    60bc:      	cmn	x19, #0xc
    60c0:      	b.gt	0x6134 <generic_kprobe_output+0x514>
    60c4:      	cmn	x8, #0x1c
    60c8:      	b.eq	0x6174 <generic_kprobe_output+0x554>
    60cc:      	cmn	x8, #0x16
    60d0:      	b.eq	0x618c <generic_kprobe_output+0x56c>
    60d4:      	cmn	x8, #0x10
    60d8:      	b.ne	0x6184 <generic_kprobe_output+0x564>
    60dc:      	add	x8, x0, #0x2f0
    60e0:      	b	0x61a0 <generic_kprobe_output+0x580>
    60e4:      	mov	x19, x0
    60e8:      	str	wzr, [sp, #0x28]
    60ec:      	adrp	x0, 0x6000 <generic_kprobe_output+0x3e0>
    60f0:      	mov	w8, #0x1                // =1
    60f4:      	ldr	x0, [x0]
    60f8:      	add	x9, sp, #0x28
    60fc:      	add	x1, sp, #0x28
    6100:      	blr	x8
    6104:      	cbz	x0, 0x61f0 <generic_kprobe_output+0x5d0>
    6108:      	mov	x8, x19
    610c:      	cmn	x19, #0xc
    6110:      	b.gt	0x6154 <generic_kprobe_output+0x534>
    6114:      	cmn	x8, #0x1c
    6118:      	b.eq	0x61b4 <generic_kprobe_output+0x594>
    611c:      	cmn	x8, #0x16
    6120:      	b.eq	0x61cc <generic_kprobe_output+0x5ac>
    6124:      	cmn	x8, #0x10
    6128:      	b.ne	0x61c4 <generic_kprobe_output+0x5a4>
    612c:      	add	x8, x0, #0x2f0
    6130:      	b	0x61e0 <generic_kprobe_output+0x5c0>
    6134:      	cmn	x8, #0xb
    6138:      	b.eq	0x617c <generic_kprobe_output+0x55c>
    613c:      	cmn	x8, #0x7
    6140:      	b.eq	0x6194 <generic_kprobe_output+0x574>
    6144:      	cmn	x8, #0x2
    6148:      	b.ne	0x6184 <generic_kprobe_output+0x564>
    614c:      	add	x8, x0, #0x2e0
    6150:      	b	0x61a0 <generic_kprobe_output+0x580>
    6154:      	cmn	x8, #0xb
    6158:      	b.eq	0x61bc <generic_kprobe_output+0x59c>
    615c:      	cmn	x8, #0x7
    6160:      	b.eq	0x61d4 <generic_kprobe_output+0x5b4>
    6164:      	cmn	x8, #0x2
    6168:      	b.ne	0x61c4 <generic_kprobe_output+0x5a4>
    616c:      	add	x8, x0, #0x2e0
    6170:      	b	0x61e0 <generic_kprobe_output+0x5c0>
    6174:      	add	x8, x0, #0x300
    6178:      	b	0x61a0 <generic_kprobe_output+0x580>
    617c:      	add	x8, x0, #0x308
    6180:      	b	0x61a0 <generic_kprobe_output+0x580>
    6184:      	add	x8, x0, #0x2d8
    6188:      	b	0x61a0 <generic_kprobe_output+0x580>
    618c:      	add	x8, x0, #0x2f8
    6190:      	b	0x61a0 <generic_kprobe_output+0x580>
    6194:      	add	x8, x0, #0x2e8
    6198:      	nop
    619c:      	nop
    61a0:      	ldaxr	x9, [x8]
    61a4:      	add	x9, x9, #0x1
    61a8:      	stlxr	w10, x9, [x8]
    61ac:      	cbnz	w10, 0x61a0 <generic_kprobe_output+0x580>
    61b0:      	b	0x61f0 <generic_kprobe_output+0x5d0>
    61b4:      	add	x8, x0, #0x300
    61b8:      	b	0x61e0 <generic_kprobe_output+0x5c0>
    61bc:      	add	x8, x0, #0x308
    61c0:      	b	0x61e0 <generic_kprobe_output+0x5c0>
    61c4:      	add	x8, x0, #0x2d8
    61c8:      	b	0x61e0 <generic_kprobe_output+0x5c0>
    61cc:      	add	x8, x0, #0x2f8
    61d0:      	b	0x61e0 <generic_kprobe_output+0x5c0>
    61d4:      	add	x8, x0, #0x2e8
    61d8:      	nop
    61dc:      	nop
    61e0:      	ldaxr	x9, [x8]
    61e4:      	add	x9, x9, #0x1
    61e8:      	stlxr	w10, x9, [x8]
    61ec:      	cbnz	w10, 0x61e0 <generic_kprobe_output+0x5c0>
    61f0:      	ldp	x20, x19, [sp, #0xb0]
    61f4:      	mov	w0, wzr
    61f8:      	ldr	x29, [sp, #0x70]
    61fc:      	ldp	x22, x21, [sp, #0xa0]
    6200:      	ldp	x24, x23, [sp, #0x90]
    6204:      	ldp	x30, x25, [sp, #0x80]
    6208:      	add	sp, sp, #0xc0
    620c:      	ret

Disassembly of section kprobe/generic_kprobe:

0000000000000000 <generic_kprobe_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_kprobe_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x538 <generic_kprobe_event+0x538>
      38:      	add	x23, x0, #0x5, lsl #12  // =0x5000
      3c:      	mov	x20, x0
      40:      	adrp	x0, 0x0 <generic_kprobe_event>
      44:      	str	wzr, [x23, #0xef8]
      48:      	add	x1, x23, #0xef8
      4c:      	mov	w8, #0x1                // =1
      50:      	ldr	x0, [x0]
      54:      	blr	x8
      58:      	cbz	x0, 0x538 <generic_kprobe_event+0x538>
      5c:      	ldr	w8, [x0, #0x64]
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_kprobe_event+0x220>
      68:      	adrp	x21, 0x0 <generic_kprobe_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x21, [x21]
      78:      	mov	x24, x0
      7c:      	add	x1, sp, #0x1c
      80:      	mov	x0, x21
      84:      	blr	x8
      88:      	cbz	x0, 0x538 <generic_kprobe_event+0x538>
      8c:      	mov	x22, x0
      90:      	str	wzr, [sp, #0x84]
      94:      	adrp	x0, 0x0 <generic_kprobe_event>
      98:      	mov	w8, #0x1                // =1
      9c:      	ldr	x0, [x0]
      a0:      	add	x9, sp, #0x84
      a4:      	add	x1, sp, #0x84
      a8:      	blr	x8
      ac:      	cbz	x0, 0xd8 <generic_kprobe_event+0xd8>
      b0:      	ldr	x8, [x0, #0x20]
      b4:      	mov	w9, #0x7270             // =29296
      b8:      	movk	w9, #0x6367, lsl #16
      bc:      	cmp	x8, x9
      c0:      	b.ne	0xe0 <generic_kprobe_event+0xe0>
      c4:      	mov	w8, #0x50               // =80
      c8:      	blr	x8
      cc:      	str	x0, [sp, #0x30]
      d0:      	cbnz	x0, 0x1d4 <generic_kprobe_event+0x1d4>
      d4:      	b	0x538 <generic_kprobe_event+0x538>
      d8:      	mov	w25, wzr
      dc:      	b	0xe4 <generic_kprobe_event+0xe4>
      e0:      	ldr	w25, [x0, #0x10]
      e4:      	mov	w8, #0x23               // =35
      e8:      	blr	x8
      ec:      	str	xzr, [sp, #0x88]
      f0:      	add	x2, x0, #0xcd0
      f4:      	mov	w8, #0x8                // =8
      f8:      	mov	w9, #0x71               // =113
      fc:      	add	x10, sp, #0x20
     100:      	add	x0, sp, #0x20
     104:      	mov	w1, #0x8                // =8
     108:      	blr	x9
     10c:      	ldr	x8, [sp, #0x20]
     110:      	cbz	x8, 0x538 <generic_kprobe_event+0x538>
     114:      	cmp	w25, #0xb
     118:      	b.hi	0x538 <generic_kprobe_event+0x538>
     11c:      	ubfiz	x9, x25, #3, #32
     120:      	mov	w10, #0x8               // =8
     124:      	mov	w11, #0x71              // =113
     128:      	add	x12, sp, #0x38
     12c:      	add	x0, sp, #0x38
     130:      	mov	w1, #0x8                // =8
     134:      	add	x8, x8, x9
     138:      	ldr	x8, [sp, #0x20]
     13c:      	add	x2, x8, x9
     140:      	blr	x11
     144:      	ldr	x8, [sp, #0x38]
     148:      	cbz	x8, 0x538 <generic_kprobe_event+0x538>
     14c:      	mov	w9, #0x8                // =8
     150:      	mov	w10, #0x71              // =113
     154:      	add	x11, sp, #0x88
     158:      	ldr	x2, [sp, #0x38]
     15c:      	add	x0, sp, #0x88
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x10
     168:      	ldr	x8, [sp, #0x88]
     16c:      	cbz	x8, 0x538 <generic_kprobe_event+0x538>
     170:      	str	xzr, [sp, #0x38]
     174:      	add	x2, x8, #0x100
     178:      	mov	w8, #0x8                // =8
     17c:      	mov	w9, #0x71               // =113
     180:      	add	x10, sp, #0x38
     184:      	add	x0, sp, #0x38
     188:      	mov	w1, #0x8                // =8
     18c:      	blr	x9
     190:      	ldr	x8, [sp, #0x38]
     194:      	str	xzr, [sp, #0x38]
     198:      	cbz	x8, 0x1c8 <generic_kprobe_event+0x1c8>
     19c:      	add	x2, x8, #0x60
     1a0:      	mov	w8, #0x8                // =8
     1a4:      	mov	w9, #0x71               // =113
     1a8:      	add	x10, sp, #0x38
     1ac:      	add	x0, sp, #0x38
     1b0:      	mov	w1, #0x8                // =8
     1b4:      	blr	x9
     1b8:      	ldr	x0, [sp, #0x38]
     1bc:      	str	x0, [sp, #0x30]
     1c0:      	cbnz	x0, 0x1d4 <generic_kprobe_event+0x1d4>
     1c4:      	b	0x538 <generic_kprobe_event+0x538>
     1c8:      	mov	x0, xzr
     1cc:      	str	xzr, [sp, #0x30]
     1d0:      	cbz	xzr, 0x538 <generic_kprobe_event+0x538>
     1d4:      	str	x0, [sp, #0x38]
     1d8:      	adrp	x0, 0x0 <generic_kprobe_event>
     1dc:      	mov	w8, #0x1                // =1
     1e0:      	add	x9, sp, #0x38
     1e4:      	ldr	x0, [x0]
     1e8:      	add	x1, sp, #0x38
     1ec:      	blr	x8
     1f0:      	cbz	x0, 0x200 <generic_kprobe_event+0x200>
     1f4:      	ldr	x8, [x0]
     1f8:      	cbz	x8, 0x200 <generic_kprobe_event+0x200>
     1fc:      	str	x8, [sp, #0x30]
     200:      	mov	w8, #0x1                // =1
     204:      	add	x9, sp, #0x30
     208:      	add	x1, sp, #0x30
     20c:      	mov	x0, x22
     210:      	blr	x8
     214:      	mov	x8, x0
     218:      	mov	x0, x24
     21c:      	cbz	x8, 0x554 <generic_kprobe_event+0x554>
     220:      	ldr	w8, [x0]
     224:      	add	x9, x23, #0xefc
     228:      	str	xzr, [x20, #0x5eb8]
     22c:      	str	xzr, [x20, #0x5ec0]
     230:      	str	xzr, [x20, #0x5ec8]
     234:      	str	xzr, [x9]
     238:      	str	xzr, [x20, #0x5ed0]
     23c:      	str	xzr, [x20, #0x5ed8]
     240:      	stp	x8, xzr, [x20, #0x60]
     244:      	mov	w8, #0x5eb8             // =24248
     248:      	add	x8, x20, x8
     24c:      	strb	wzr, [x8, #0x28]
     250:      	mov	w8, #0x23               // =35
     254:      	blr	x8
     258:      	add	x2, x0, #0xb50
     25c:      	mov	w25, #0x8               // =8
     260:      	add	x8, sp, #0x88
     264:      	mov	w9, #0x4                // =4
     268:      	mov	x21, x0
     26c:      	add	x0, sp, #0x88
     270:      	mov	w1, #0x8                // =8
     274:      	add	x22, x20, #0x20
     278:      	mov	w24, #0x4               // =4
     27c:      	blr	x9
     280:      	ldr	x8, [sp, #0x88]
     284:      	mov	w9, #0x48               // =72
     288:      	add	x10, sp, #0x38
     28c:      	mov	w11, #0x4               // =4
     290:      	ldr	x2, [sp, #0x88]
     294:      	add	x0, sp, #0x38
     298:      	mov	w1, #0x48               // =72
     29c:      	blr	x11
     2a0:      	ldr	x8, [sp, #0x40]
     2a4:      	mov	w9, #0x4                // =4
     2a8:      	mov	x0, x22
     2ac:      	mov	w1, #0x4                // =4
     2b0:      	add	x8, x8, #0x218
     2b4:      	ldr	x8, [sp, #0x40]
     2b8:      	add	x2, x8, #0x218
     2bc:      	blr	x9
     2c0:      	ldr	x8, [sp, #0x48]
     2c4:      	add	x0, x20, #0x24
     2c8:      	mov	w9, #0x4                // =4
     2cc:      	mov	w1, #0x4                // =4
     2d0:      	add	x8, x8, #0x4d8
     2d4:      	ldr	x8, [sp, #0x48]
     2d8:      	add	x2, x8, #0x4d8
     2dc:      	blr	x9
     2e0:      	ldr	x8, [sp, #0x50]
     2e4:      	add	x0, x20, #0x28
     2e8:      	mov	w9, #0x4                // =4
     2ec:      	mov	w1, #0x4                // =4
     2f0:      	add	x8, x8, #0x58
     2f4:      	ldr	x8, [sp, #0x50]
     2f8:      	add	x2, x8, #0x58
     2fc:      	blr	x9
     300:      	str	xzr, [sp, #0x30]
     304:      	add	x2, x21, #0x938
     308:      	add	x8, sp, #0x30
     30c:      	add	x0, sp, #0x30
     310:      	mov	w1, #0x8                // =8
     314:      	blr	x24
     318:      	ldr	x8, [sp, #0x30]
     31c:      	cbz	x8, 0x3a0 <generic_kprobe_event+0x3a0>
     320:      	str	wzr, [sp, #0x10]
     324:      	add	x8, x8, #0x4
     328:      	add	x9, sp, #0x10
     32c:      	mov	w10, #0x4               // =4
     330:      	add	x0, sp, #0x10
     334:      	mov	w1, #0x4                // =4
     338:      	mov	w22, #0x4               // =4
     33c:      	ldr	x8, [sp, #0x30]
     340:      	add	x2, x8, #0x4
     344:      	blr	x10
     348:      	ldr	x8, [sp, #0x30]
     34c:      	ldrsw	x9, [sp, #0x10]
     350:      	add	x10, sp, #0x20
     354:      	mov	w11, #0x4               // =4
     358:      	add	x0, sp, #0x20
     35c:      	mov	w1, #0x10               // =16
     360:      	add	x8, x8, x9, lsl #4
     364:      	mov	w9, #0x10               // =16
     368:      	add	x8, x8, #0x80
     36c:      	ldr	x8, [sp, #0x30]
     370:      	ldrsw	x9, [sp, #0x10]
     374:      	add	x8, x8, x9, lsl #4
     378:      	add	x2, x8, #0x80
     37c:      	blr	x11
     380:      	ldr	x8, [sp, #0x28]
     384:      	add	x0, x20, #0x2c
     388:      	mov	w1, #0x4                // =4
     38c:      	add	x8, x8, #0x158
     390:      	ldr	x8, [sp, #0x28]
     394:      	add	x2, x8, #0x158
     398:      	blr	x22
     39c:      	b	0x3a4 <generic_kprobe_event+0x3a4>
     3a0:      	str	wzr, [x20, #0x2c]
     3a4:      	ldr	x8, [sp, #0x58]
     3a8:      	add	x0, x20, #0x30
     3ac:      	mov	w9, #0x4                // =4
     3b0:      	mov	w1, #0x4                // =4
     3b4:      	mov	w24, #0x4               // =4
     3b8:      	add	x8, x8, #0x158
     3bc:      	ldr	x8, [sp, #0x58]
     3c0:      	add	x2, x8, #0x158
     3c4:      	blr	x9
     3c8:      	ldr	x8, [sp, #0x60]
     3cc:      	add	x0, x20, #0x34
     3d0:      	mov	w9, #0x4                // =4
     3d4:      	mov	w1, #0x4                // =4
     3d8:      	add	x8, x8, #0x118
     3dc:      	ldr	x8, [sp, #0x60]
     3e0:      	add	x2, x8, #0x118
     3e4:      	blr	x9
     3e8:      	ldr	x8, [sp, #0x68]
     3ec:      	add	x0, x20, #0x38
     3f0:      	mov	w9, #0x4                // =4
     3f4:      	mov	w1, #0x4                // =4
     3f8:      	add	x8, x8, #0x98
     3fc:      	ldr	x8, [sp, #0x68]
     400:      	add	x2, x8, #0x98
     404:      	blr	x9
     408:      	ldr	x8, [sp, #0x70]
     40c:      	add	x0, x20, #0x3c
     410:      	mov	w9, #0x4                // =4
     414:      	mov	w1, #0x4                // =4
     418:      	add	x8, x8, #0x98
     41c:      	ldr	x8, [sp, #0x70]
     420:      	add	x2, x8, #0x98
     424:      	blr	x9
     428:      	ldr	x8, [sp, #0x78]
     42c:      	add	x0, x20, #0x40
     430:      	mov	w9, #0x4                // =4
     434:      	mov	w1, #0x4                // =4
     438:      	add	x8, x8, #0x58
     43c:      	ldr	x8, [sp, #0x78]
     440:      	add	x2, x8, #0x58
     444:      	blr	x9
     448:      	str	xzr, [sp, #0x20]
     44c:      	str	xzr, [sp, #0x30]
     450:      	add	x21, x21, #0xae0
     454:      	mov	w25, #0x8               // =8
     458:      	add	x8, sp, #0x20
     45c:      	mov	w9, #0x4                // =4
     460:      	add	x0, sp, #0x20
     464:      	mov	w1, #0x8                // =8
     468:      	mov	x2, x21
     46c:      	blr	x9
     470:      	ldr	x8, [sp, #0x20]
     474:      	add	x9, sp, #0x30
     478:      	mov	w10, #0x4               // =4
     47c:      	add	x0, sp, #0x30
     480:      	mov	w1, #0x8                // =8
     484:      	add	x8, x8, #0x90
     488:      	ldr	x8, [sp, #0x20]
     48c:      	add	x2, x8, #0x90
     490:      	blr	x10
     494:      	ldr	x8, [sp, #0x30]
     498:      	add	x0, x20, #0x44
     49c:      	mov	w9, #0x4                // =4
     4a0:      	mov	w1, #0x4                // =4
     4a4:      	add	x8, x8, #0x158
     4a8:      	ldr	x8, [sp, #0x30]
     4ac:      	add	x2, x8, #0x158
     4b0:      	blr	x9
     4b4:      	add	x8, sp, #0x38
     4b8:      	mov	w9, #0x4                // =4
     4bc:      	add	x0, sp, #0x38
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	mov	x2, x21
     4c8:      	add	x22, x20, #0x48
     4cc:      	blr	x9
     4d0:      	ldr	x21, [sp, #0x38]
     4d4:      	add	x0, x20, #0x50
     4d8:      	mov	w8, #0x4                // =4
     4dc:      	mov	w1, #0x8                // =8
     4e0:      	add	x2, x21, #0x40
     4e4:      	blr	x8
     4e8:      	add	x0, x20, #0x58
     4ec:      	add	x2, x21, #0x30
     4f0:      	mov	w8, #0x4                // =4
     4f4:      	mov	w1, #0x8                // =8
     4f8:      	blr	x8
     4fc:      	add	x2, x21, #0x38
     500:      	mov	x0, x22
     504:      	mov	w1, #0x8                // =8
     508:      	blr	x24
     50c:      	strb	wzr, [x23, #0xf08]
     510:      	strb	wzr, [x20, #0x1]
     514:      	adrp	x1, 0x0 <generic_kprobe_event>
     518:      	mov	w8, #0x2                // =2
     51c:      	mov	w9, #0xc                // =12
     520:      	mov	x0, x19
     524:      	str	xzr, [x20, #0x5ee8]
     528:      	str	xzr, [x20, #0x5ef0]
     52c:      	ldr	x1, [x1]
     530:      	mov	w2, #0x2                // =2
     534:      	blr	x9
     538:      	ldp	x20, x19, [sp, #0xc0]
     53c:      	mov	w0, wzr
     540:      	ldp	x22, x21, [sp, #0xb0]
     544:      	ldp	x24, x23, [sp, #0xa0]
     548:      	ldp	x30, x25, [sp, #0x90]
     54c:      	add	sp, sp, #0xd0
     550:      	ret
     554:      	mov	x8, #-0x1               // =-1
     558:      	mov	w9, #0x1                // =1
     55c:      	add	x1, sp, #0x10
     560:      	str	x8, [sp, #0x10]
     564:      	add	x8, sp, #0x10
     568:      	mov	x0, x22
     56c:      	mov	w25, #0x1               // =1
     570:      	blr	x9
     574:      	cbz	x0, 0x538 <generic_kprobe_event+0x538>
     578:      	str	w25, [sp, #0x1c]
     57c:      	add	x8, sp, #0x1c
     580:      	add	x1, sp, #0x1c
     584:      	mov	x0, x21
     588:      	blr	x25
     58c:      	cbz	x0, 0x538 <generic_kprobe_event+0x538>
     590:      	mov	w8, #0x1                // =1
     594:      	add	x9, sp, #0x30
     598:      	add	x1, sp, #0x30
     59c:      	blr	x8
     5a0:      	mov	x8, x0
     5a4:      	mov	x0, x24
     5a8:      	cbnz	x8, 0x538 <generic_kprobe_event+0x538>
     5ac:      	b	0x220 <generic_kprobe_event+0x220>

Disassembly of section kprobe/generic_kprobe_override:

0000000000000000 <generic_kprobe_override>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	w8, #0xe                // =14
       c:      	mov	x20, x0
      10:      	blr	x8
      14:      	str	x0, [sp, #0x8]
      18:      	adrp	x19, 0x0 <generic_kprobe_override>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x8
      24:      	ldr	x19, [x19]
      28:      	add	x1, sp, #0x8
      2c:      	mov	x0, x19
      30:      	blr	x8
      34:      	cbz	x0, 0x60 <generic_kprobe_override+0x60>
      38:      	ldrsw	x8, [x0]
      3c:      	mov	w9, #0x3a               // =58
      40:      	ldrsw	x1, [x0]
      44:      	mov	x0, x20
      48:      	blr	x9
      4c:      	mov	w8, #0x3                // =3
      50:      	add	x9, sp, #0x8
      54:      	add	x1, sp, #0x8
      58:      	mov	x0, x19
      5c:      	blr	x8
      60:      	ldp	x20, x19, [sp, #0x10]
      64:      	mov	w0, wzr
      68:      	ldr	x30, [sp], #0x20
      6c:      	ret

Disassembly of section fmod_ret/security_task_prctl:

0000000000000000 <generic_fmodret_override>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	w8, #0xe                // =14
       c:      	blr	x8
      10:      	str	x0, [sp, #0x8]
      14:      	adrp	x19, 0x0 <generic_fmodret_override>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0x8
      20:      	ldr	x19, [x19]
      24:      	add	x1, sp, #0x8
      28:      	mov	x0, x19
      2c:      	blr	x8
      30:      	cbz	x0, 0x50 <generic_fmodret_override+0x50>
      34:      	mov	w8, #0x3                // =3
      38:      	add	x9, sp, #0x8
      3c:      	mov	x20, x0
      40:      	add	x1, sp, #0x8
      44:      	mov	x0, x19
      48:      	blr	x8
      4c:      	ldrsw	x0, [x20]
      50:      	ldp	x20, x19, [sp, #0x10]
      54:      	ldr	x30, [sp], #0x20
      58:      	ret
