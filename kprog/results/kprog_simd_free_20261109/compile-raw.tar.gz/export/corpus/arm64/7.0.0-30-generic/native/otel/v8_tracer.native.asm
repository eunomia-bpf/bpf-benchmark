
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/v8_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_v8:

0000000000000000 <perf_unwind_v8>:
       0:      	sub	sp, sp, #0x100
       4:      	str	x29, [sp, #0xb0]
       8:      	stp	x30, x25, [sp, #0xc0]
       c:      	stp	x24, x23, [sp, #0xd0]
      10:      	stp	x22, x21, [sp, #0xe0]
      14:      	stp	x20, x19, [sp, #0xf0]
      18:      	str	wzr, [sp, #0x70]
      1c:      	adrp	x20, 0x0 <perf_unwind_v8>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x70
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x70
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x1a78 <perf_unwind_v8+0x1a78>
      40:      	ldr	w8, [x0]
      44:      	adrp	x22, 0x0 <perf_unwind_v8>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0xb8]
      50:      	ldr	x22, [x22]
      54:      	ldr	w8, [x22]
      58:      	cbnz	w8, 0x6a4 <perf_unwind_v8+0x6a4>
      5c:      	adrp	x0, 0x0 <perf_unwind_v8>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0xb8
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0xb8
      70:      	blr	x8
      74:      	adrp	x24, 0x0 <perf_unwind_v8>
      78:      	ldr	x24, [x24]
      7c:      	cbz	x0, 0x114 <perf_unwind_v8+0x114>
      80:      	mov	w8, #0x37               // =55
      84:      	add	x9, sp, #0x58
      88:      	mov	x23, x0
      8c:      	str	w8, [sp, #0x58]
      90:      	mov	w8, #0x1                // =1
      94:      	add	x1, sp, #0x58
      98:      	mov	x0, x24
      9c:      	blr	x8
      a0:      	cbz	x0, 0x14c <perf_unwind_v8+0x14c>
      a4:      	ldr	x8, [x0]
      a8:      	add	x8, x8, #0x1
      ac:      	str	x8, [x0]
      b0:      	ldr	x29, [x21, #0xed8]
      b4:      	ldr	x25, [x21, #0xee0]
      b8:      	ldr	x24, [x21, #0xed0]
      bc:      	ldr	w8, [x22]
      c0:      	cbz	w8, 0x168 <perf_unwind_v8+0x168>
      c4:      	adrp	x8, 0x0 <perf_unwind_v8>
      c8:      	add	x8, x8, #0x0
      cc:      	add	x0, sp, #0x70
      d0:      	ldp	x9, x10, [x8]
      d4:      	mov	w1, #0x1f               // =31
      d8:      	mov	x2, x24
      dc:      	mov	x3, x29
      e0:      	stp	x9, x10, [sp, #0x70]
      e4:      	ldr	x9, [x8, #0x10]
      e8:      	ldur	x8, [x8, #0x17]
      ec:      	add	x10, sp, #0x70
      f0:      	mov	x4, x25
      f4:      	str	x9, [sp, #0x80]
      f8:      	stur	x8, [sp, #0x87]
      fc:      	mov	w8, #0x1f               // =31
     100:      	mov	w9, #0x6                // =6
     104:      	blr	x9
     108:      	cmp	x25, x29
     10c:      	b.hs	0x170 <perf_unwind_v8+0x170>
     110:      	b	0x1954 <perf_unwind_v8+0x1954>
     114:      	ldr	w8, [x22]
     118:      	cbnz	w8, 0x818 <perf_unwind_v8+0x818>
     11c:      	mov	w8, #0x54               // =84
     120:      	add	x9, sp, #0x58
     124:      	add	x1, sp, #0x58
     128:      	str	w8, [sp, #0x58]
     12c:      	mov	w8, #0x1                // =1
     130:      	mov	x0, x24
     134:      	blr	x8
     138:      	cbz	x0, 0x214 <perf_unwind_v8+0x214>
     13c:      	ldr	x8, [x0]
     140:      	add	x8, x8, #0x1
     144:      	str	x8, [x0]
     148:      	b	0x21c <perf_unwind_v8+0x21c>
     14c:      	ldr	w8, [x22]
     150:      	cbnz	w8, 0x8d8 <perf_unwind_v8+0x8d8>
     154:      	ldr	x29, [x21, #0xed8]
     158:      	ldr	x25, [x21, #0xee0]
     15c:      	ldr	x24, [x21, #0xed0]
     160:      	ldr	w8, [x22]
     164:      	cbnz	w8, 0xc4 <perf_unwind_v8+0xc4>
     168:      	cmp	x25, x29
     16c:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
     170:      	add	x8, x29, #0x2, lsl #12  // =0x2000
     174:      	cmp	x25, x8
     178:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
     17c:      	add	x22, x21, #0xf70
     180:      	sub	x2, x25, #0x40
     184:      	mov	w8, #0x40               // =64
     188:      	mov	w9, #0x70               // =112
     18c:      	mov	w1, #0x40               // =64
     190:      	mov	x0, x22
     194:      	blr	x9
     198:      	cbz	x0, 0x228 <perf_unwind_v8+0x228>
     19c:      	adrp	x22, 0x0 <perf_unwind_v8>
     1a0:      	ldr	x22, [x22]
     1a4:      	ldr	w8, [x22]
     1a8:      	cbnz	w8, 0x934 <perf_unwind_v8+0x934>
     1ac:      	mov	w8, #0x39               // =57
     1b0:      	adrp	x24, 0x0 <perf_unwind_v8>
     1b4:      	add	x9, sp, #0x58
     1b8:      	str	w8, [sp, #0x58]
     1bc:      	mov	w8, #0x1                // =1
     1c0:      	add	x1, sp, #0x58
     1c4:      	ldr	x24, [x24]
     1c8:      	mov	x0, x24
     1cc:      	blr	x8
     1d0:      	cbnz	x0, 0x198c <perf_unwind_v8+0x198c>
     1d4:      	ldr	w8, [x22]
     1d8:      	cbz	w8, 0x19a4 <perf_unwind_v8+0x19a4>
     1dc:      	adrp	x8, 0x0 <perf_unwind_v8>
     1e0:      	add	x8, x8, #0x0
     1e4:      	ldp	x9, x10, [x8, #0x10]
     1e8:      	stp	x9, x10, [sp, #0x80]
     1ec:      	ldr	x9, [x8, #0x20]
     1f0:      	add	x10, sp, #0x70
     1f4:      	str	x9, [sp, #0x90]
     1f8:      	ldur	x9, [x8, #0x26]
     1fc:      	stur	x9, [sp, #0x96]
     200:      	ldp	x9, x8, [x8]
     204:      	stp	x9, x8, [sp, #0x70]
     208:      	mov	w8, #0x2e               // =46
     20c:      	mov	w9, #0x6                // =6
     210:      	b	0x1b60 <perf_unwind_v8+0x1b60>
     214:      	ldr	w8, [x22]
     218:      	cbnz	w8, 0x9a8 <perf_unwind_v8+0x9a8>
     21c:      	mov	w29, wzr
     220:      	mov	w8, #0x138a             // =5002
     224:      	b	0x19ac <perf_unwind_v8+0x19ac>
     228:      	ldrb	w9, [x23, #0x14]
     22c:      	str	x22, [sp, #0x50]
     230:      	cmp	x9, #0x38
     234:      	b.hi	0x250 <perf_unwind_v8+0x250>
     238:      	ldrb	w8, [x23, #0x15]
     23c:      	cmp	x8, #0x38
     240:      	b.hi	0x250 <perf_unwind_v8+0x250>
     244:      	ldrb	w10, [x23, #0x16]
     248:      	cmp	x10, #0x38
     24c:      	b.ls	0x26c <perf_unwind_v8+0x26c>
     250:      	mov	w29, wzr
     254:      	mov	w8, #0x1                // =1
     258:      	adrp	x24, 0x0 <perf_unwind_v8>
     25c:      	adrp	x22, 0x0 <perf_unwind_v8>
     260:      	ldr	x24, [x24]
     264:      	ldr	x22, [x22]
     268:      	b	0x19ac <perf_unwind_v8+0x19ac>
     26c:      	ldr	x11, [sp, #0x50]
     270:      	add	x25, x21, #0xfb0
     274:      	ldr	x9, [x11, x9]
     278:      	tbnz	w9, #0x0, 0x2f0 <perf_unwind_v8+0x2f0>
     27c:      	str	x25, [sp, #0x48]
     280:      	adrp	x8, 0x0 <perf_unwind_v8>
     284:      	lsr	x25, x9, #1
     288:      	ldr	x8, [x8]
     28c:      	ldr	w8, [x8]
     290:      	cbnz	w8, 0xc0c <perf_unwind_v8+0xc0c>
     294:      	ldrb	w24, [x21, #0xf20]
     298:      	mov	x29, xzr
     29c:      	ldr	w8, [x21, #0x2c0]
     2a0:      	cmp	w8, #0x7f
     2a4:      	b.lo	0x3ec <perf_unwind_v8+0x3ec>
     2a8:      	adrp	x22, 0x0 <perf_unwind_v8>
     2ac:      	ldr	x22, [x22]
     2b0:      	ldr	w8, [x22]
     2b4:      	cbnz	w8, 0xca0 <perf_unwind_v8+0xca0>
     2b8:      	mov	w8, #0x2                // =2
     2bc:      	adrp	x24, 0x0 <perf_unwind_v8>
     2c0:      	add	x9, sp, #0x58
     2c4:      	str	w8, [sp, #0x58]
     2c8:      	mov	w8, #0x1                // =1
     2cc:      	add	x1, sp, #0x58
     2d0:      	ldr	x24, [x24]
     2d4:      	mov	x0, x24
     2d8:      	blr	x8
     2dc:      	cbz	x0, 0x5bc <perf_unwind_v8+0x5bc>
     2e0:      	ldr	x8, [x0]
     2e4:      	add	x8, x8, #0x1
     2e8:      	str	x8, [x0]
     2ec:      	b	0x5c4 <perf_unwind_v8+0x5c4>
     2f0:      	ldr	x8, [x11, x8]
     2f4:      	ldr	x22, [x11, x10]
     2f8:      	and	x9, x8, #0x3
     2fc:      	and	x8, x8, #0xfffffffffffffffc
     300:      	cmp	x9, #0x1
     304:      	csel	x9, x8, xzr, eq
     308:      	str	x9, [sp, #0x40]
     30c:      	cbz	x9, 0x384 <perf_unwind_v8+0x384>
     310:      	ldrb	w8, [x23, #0xc]
     314:      	add	x10, sp, #0x70
     318:      	add	x0, sp, #0x70
     31c:      	mov	w1, #0x8                // =8
     320:      	add	x2, x9, x8
     324:      	mov	w8, #0x8                // =8
     328:      	mov	w9, #0x70               // =112
     32c:      	blr	x9
     330:      	cbnz	x0, 0x384 <perf_unwind_v8+0x384>
     334:      	ldr	x8, [sp, #0x70]
     338:      	and	x9, x8, #0x3
     33c:      	cmp	x9, #0x1
     340:      	b.ne	0x384 <perf_unwind_v8+0x384>
     344:      	and	x8, x8, #0xfffffffffffffffc
     348:      	cbz	x8, 0x388 <perf_unwind_v8+0x388>
     34c:      	ldrb	w9, [x23, #0xd]
     350:      	mov	w10, #0x2               // =2
     354:      	mov	w11, #0x70              // =112
     358:      	add	x12, sp, #0x70
     35c:      	add	x0, sp, #0x70
     360:      	mov	w1, #0x2                // =2
     364:      	add	x9, x8, x9
     368:      	ldrb	w9, [x23, #0xd]
     36c:      	add	x2, x8, x9
     370:      	blr	x11
     374:      	ldrh	w8, [sp, #0x70]
     378:      	cmp	x0, #0x0
     37c:      	csel	w8, w8, wzr, eq
     380:      	b	0x388 <perf_unwind_v8+0x388>
     384:      	mov	w8, wzr
     388:      	ldrh	w9, [x23, #0x4]
     38c:      	cmp	w9, w8, uxth
     390:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
     394:      	ldrh	w9, [x23, #0x6]
     398:      	str	x25, [sp, #0x48]
     39c:      	cmp	w9, w8, uxth
     3a0:      	b.hs	0x4cc <perf_unwind_v8+0x4cc>
     3a4:      	adrp	x22, 0x0 <perf_unwind_v8>
     3a8:      	ldr	x22, [x22]
     3ac:      	ldr	w9, [x22]
     3b0:      	cbnz	w9, 0xc50 <perf_unwind_v8+0xc50>
     3b4:      	mov	w8, #0x3a               // =58
     3b8:      	adrp	x24, 0x0 <perf_unwind_v8>
     3bc:      	add	x9, sp, #0x58
     3c0:      	str	w8, [sp, #0x58]
     3c4:      	mov	w8, #0x1                // =1
     3c8:      	add	x1, sp, #0x58
     3cc:      	ldr	x24, [x24]
     3d0:      	mov	x0, x24
     3d4:      	blr	x8
     3d8:      	cbz	x0, 0x4b8 <perf_unwind_v8+0x4b8>
     3dc:      	ldr	x8, [x0]
     3e0:      	add	x8, x8, #0x1
     3e4:      	str	x8, [x0]
     3e8:      	b	0x4c0 <perf_unwind_v8+0x4c0>
     3ec:      	add	w9, w8, #0x1
     3f0:      	mov	w10, #0x8               // =8
     3f4:      	add	x11, sp, #0x70
     3f8:      	str	w9, [x21, #0x2c0]
     3fc:      	mov	w9, #0x18               // =24
     400:      	add	x0, sp, #0x70
     404:      	mov	w1, #0x10               // =16
     408:      	umaddl	x8, w8, w9, x21
     40c:      	add	x9, x8, #0x2d0
     410:      	str	x29, [x8, #0x2d0]
     414:      	str	x25, [x8, #0x2d8]
     418:      	strb	w10, [x8, #0x2e0]
     41c:      	strb	w24, [x8, #0x2e1]
     420:      	strh	wzr, [x8, #0x2e6]
     424:      	mov	w10, #0x70              // =112
     428:      	stur	wzr, [x9, #0x12]
     42c:      	mov	w9, #0x10               // =16
     430:      	ldr	x8, [x21, #0xee0]
     434:      	ldr	x2, [x21, #0xee0]
     438:      	blr	x10
     43c:      	cbz	x0, 0x5d0 <perf_unwind_v8+0x5d0>
     440:      	adrp	x22, 0x0 <perf_unwind_v8>
     444:      	ldr	x22, [x22]
     448:      	ldr	w8, [x22]
     44c:      	cbnz	w8, 0xd74 <perf_unwind_v8+0xd74>
     450:      	mov	w8, #0x39               // =57
     454:      	adrp	x24, 0x0 <perf_unwind_v8>
     458:      	add	x9, sp, #0x58
     45c:      	str	w8, [sp, #0x58]
     460:      	mov	w8, #0x1                // =1
     464:      	add	x1, sp, #0x58
     468:      	ldr	x24, [x24]
     46c:      	mov	x0, x24
     470:      	blr	x8
     474:      	cbnz	x0, 0x198c <perf_unwind_v8+0x198c>
     478:      	ldr	w8, [x22]
     47c:      	cbz	w8, 0x19a4 <perf_unwind_v8+0x19a4>
     480:      	adrp	x8, 0x0 <perf_unwind_v8>
     484:      	add	x8, x8, #0x0
     488:      	ldp	x9, x10, [x8, #0x10]
     48c:      	stp	x9, x10, [sp, #0x80]
     490:      	ldr	x9, [x8, #0x20]
     494:      	add	x10, sp, #0x70
     498:      	str	x9, [sp, #0x90]
     49c:      	ldur	x9, [x8, #0x26]
     4a0:      	stur	x9, [sp, #0x96]
     4a4:      	ldp	x9, x8, [x8]
     4a8:      	stp	x9, x8, [sp, #0x70]
     4ac:      	mov	w8, #0x2e               // =46
     4b0:      	mov	w9, #0x6                // =6
     4b4:      	b	0x1b60 <perf_unwind_v8+0x1b60>
     4b8:      	ldr	w8, [x22]
     4bc:      	cbnz	w8, 0xdb4 <perf_unwind_v8+0xdb4>
     4c0:      	mov	w29, wzr
     4c4:      	mov	w8, #0x1389             // =5001
     4c8:      	b	0x19ac <perf_unwind_v8+0x19ac>
     4cc:      	ldrb	w8, [x23, #0xf]
     4d0:      	ldr	x9, [sp, #0x40]
     4d4:      	add	x10, sp, #0x70
     4d8:      	add	x0, sp, #0x70
     4dc:      	mov	w1, #0x8                // =8
     4e0:      	add	x2, x9, x8
     4e4:      	mov	w8, #0x8                // =8
     4e8:      	mov	w9, #0x70               // =112
     4ec:      	blr	x9
     4f0:      	cbnz	x0, 0x584 <perf_unwind_v8+0x584>
     4f4:      	ldr	x8, [sp, #0x70]
     4f8:      	and	x9, x8, #0x3
     4fc:      	cmp	x9, #0x1
     500:      	b.ne	0x584 <perf_unwind_v8+0x584>
     504:      	and	x9, x8, #0xfffffffffffffffc
     508:      	cbz	x9, 0x584 <perf_unwind_v8+0x584>
     50c:      	ldrb	w8, [x23, #0xc]
     510:      	mov	x25, x9
     514:      	add	x10, sp, #0x70
     518:      	add	x0, sp, #0x70
     51c:      	mov	w1, #0x8                // =8
     520:      	add	x2, x9, x8
     524:      	mov	w8, #0x8                // =8
     528:      	mov	w9, #0x70               // =112
     52c:      	blr	x9
     530:      	cbnz	x0, 0x84c <perf_unwind_v8+0x84c>
     534:      	ldr	x8, [sp, #0x70]
     538:      	and	x9, x8, #0x3
     53c:      	cmp	x9, #0x1
     540:      	b.ne	0x84c <perf_unwind_v8+0x84c>
     544:      	and	x8, x8, #0xfffffffffffffffc
     548:      	cbz	x8, 0x850 <perf_unwind_v8+0x850>
     54c:      	ldrb	w9, [x23, #0xd]
     550:      	mov	w10, #0x2               // =2
     554:      	mov	w11, #0x70              // =112
     558:      	add	x12, sp, #0x70
     55c:      	add	x0, sp, #0x70
     560:      	mov	w1, #0x2                // =2
     564:      	add	x9, x8, x9
     568:      	ldrb	w9, [x23, #0xd]
     56c:      	add	x2, x8, x9
     570:      	blr	x11
     574:      	ldrh	w8, [sp, #0x70]
     578:      	cmp	x0, #0x0
     57c:      	csel	w8, w8, wzr, eq
     580:      	b	0x850 <perf_unwind_v8+0x850>
     584:      	mov	x11, xzr
     588:      	mov	w8, wzr
     58c:      	ldrh	w9, [x23, #0xa]
     590:      	cmp	w9, wzr, uxth
     594:      	b.ne	0x860 <perf_unwind_v8+0x860>
     598:      	lsr	x25, x22, #32
     59c:      	cbz	x25, 0x6dc <perf_unwind_v8+0x6dc>
     5a0:      	tbnz	w22, #0x0, 0x6dc <perf_unwind_v8+0x6dc>
     5a4:      	adrp	x8, 0x0 <perf_unwind_v8>
     5a8:      	ldr	x8, [x8]
     5ac:      	ldr	w8, [x8]
     5b0:      	cbnz	w8, 0x13f0 <perf_unwind_v8+0x13f0>
     5b4:      	orr	x29, x11, #0x1
     5b8:      	b	0xa80 <perf_unwind_v8+0xa80>
     5bc:      	ldr	w8, [x22]
     5c0:      	cbnz	w8, 0xe18 <perf_unwind_v8+0xe18>
     5c4:      	mov	w29, wzr
     5c8:      	mov	w8, #0x2                // =2
     5cc:      	b	0x19ac <perf_unwind_v8+0x19ac>
     5d0:      	ldr	x8, [x21, #0xee0]
     5d4:      	add	x9, x8, #0x10
     5d8:      	str	x9, [x21, #0xed8]
     5dc:      	ldp	x9, x10, [sp, #0x70]
     5e0:      	str	x9, [x21, #0xee0]
     5e4:      	mov	w9, #0x101              // =257
     5e8:      	str	x10, [x21, #0xed0]
     5ec:      	strh	w9, [x21, #0xf20]
     5f0:      	cbnz	x29, 0x604 <perf_unwind_v8+0x604>
     5f4:      	cmp	x25, #0x1
     5f8:      	b.ne	0x604 <perf_unwind_v8+0x604>
     5fc:      	add	x8, x8, #0xa0
     600:      	str	x8, [x21, #0xed8]
     604:      	adrp	x8, 0x0 <perf_unwind_v8>
     608:      	adrp	x0, 0x0 <perf_unwind_v8>
     60c:      	ldr	x8, [x8]
     610:      	ldr	w8, [x8]
     614:      	ldr	x0, [x0]
     618:      	cbnz	w8, 0xe60 <perf_unwind_v8+0xe60>
     61c:      	mov	w8, #0x38               // =56
     620:      	add	x9, sp, #0x58
     624:      	add	x1, sp, #0x58
     628:      	str	w8, [sp, #0x58]
     62c:      	mov	w8, #0x1                // =1
     630:      	blr	x8
     634:      	cbz	x0, 0x654 <perf_unwind_v8+0x654>
     638:      	ldr	x8, [x0]
     63c:      	add	x8, x8, #0x1
     640:      	str	x8, [x0]
     644:      	adrp	x8, 0x0 <perf_unwind_v8>
     648:      	ldr	x8, [x8]
     64c:      	ldr	w8, [x8]
     650:      	b	0x664 <perf_unwind_v8+0x664>
     654:      	adrp	x8, 0x0 <perf_unwind_v8>
     658:      	ldr	x8, [x8]
     65c:      	ldr	w8, [x8]
     660:      	cbnz	w8, 0x1368 <perf_unwind_v8+0x1368>
     664:      	ldr	x24, [x21, #0xed0]
     668:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
     66c:      	cbnz	w8, 0xeb0 <perf_unwind_v8+0xeb0>
     670:      	lsr	x8, x24, #56
     674:      	cbz	x8, 0xefc <perf_unwind_v8+0xefc>
     678:      	adrp	x22, 0x0 <perf_unwind_v8>
     67c:      	ldr	x22, [x22]
     680:      	ldr	w8, [x22]
     684:      	cbnz	w8, 0x13b0 <perf_unwind_v8+0x13b0>
     688:      	mov	w8, #0xb                // =11
     68c:      	adrp	x24, 0x0 <perf_unwind_v8>
     690:      	mov	w29, wzr
     694:      	str	w8, [x21, #0xf18]
     698:      	mov	w8, #0xfab              // =4011
     69c:      	ldr	x24, [x24]
     6a0:      	b	0x19ac <perf_unwind_v8+0x19ac>
     6a4:      	adrp	x8, 0x0 <perf_unwind_v8>
     6a8:      	add	x8, x8, #0x0
     6ac:      	add	x0, sp, #0x70
     6b0:      	ldp	x9, x10, [x8]
     6b4:      	ldr	x8, [x8, #0x10]
     6b8:      	mov	w1, #0x18               // =24
     6bc:      	stp	x9, x10, [sp, #0x70]
     6c0:      	str	x8, [sp, #0x80]
     6c4:      	mov	w8, #0x18               // =24
     6c8:      	mov	w9, #0x6                // =6
     6cc:      	add	x10, sp, #0x70
     6d0:      	ldr	w2, [x21, #0x2c0]
     6d4:      	blr	x9
     6d8:      	b	0x5c <perf_unwind_v8+0x5c>
     6dc:      	orr	x8, x11, #0x2
     6e0:      	ldr	x9, [sp, #0x40]
     6e4:      	add	x10, sp, #0x70
     6e8:      	add	x0, sp, #0x70
     6ec:      	stp	x11, x8, [sp, #0x30]
     6f0:      	ldrb	w8, [x23, #0xe]
     6f4:      	mov	w1, #0x8                // =8
     6f8:      	add	x2, x9, x8
     6fc:      	mov	w8, #0x8                // =8
     700:      	mov	w9, #0x70               // =112
     704:      	blr	x9
     708:      	cbnz	x0, 0x7b0 <perf_unwind_v8+0x7b0>
     70c:      	ldr	x8, [sp, #0x70]
     710:      	and	x9, x8, #0x3
     714:      	cmp	x9, #0x1
     718:      	b.ne	0x7b0 <perf_unwind_v8+0x7b0>
     71c:      	and	x8, x8, #0xfffffffffffffffc
     720:      	mov	x25, x8
     724:      	cbz	x8, 0x7b8 <perf_unwind_v8+0x7b8>
     728:      	ldrb	w8, [x23, #0xc]
     72c:      	mov	w9, #0x70               // =112
     730:      	add	x10, sp, #0x70
     734:      	add	x0, sp, #0x70
     738:      	mov	w1, #0x8                // =8
     73c:      	add	x2, x25, x8
     740:      	mov	w8, #0x8                // =8
     744:      	blr	x9
     748:      	cbnz	x0, 0xa08 <perf_unwind_v8+0xa08>
     74c:      	ldr	x8, [sp, #0x70]
     750:      	and	x9, x8, #0x3
     754:      	cmp	x9, #0x1
     758:      	b.ne	0xa08 <perf_unwind_v8+0xa08>
     75c:      	and	x8, x8, #0xfffffffffffffffc
     760:      	cbz	x8, 0x7b8 <perf_unwind_v8+0x7b8>
     764:      	ldrb	w9, [x23, #0xd]
     768:      	mov	w10, #0x2               // =2
     76c:      	mov	w11, #0x70              // =112
     770:      	add	x12, sp, #0x70
     774:      	add	x0, sp, #0x70
     778:      	mov	w1, #0x2                // =2
     77c:      	add	x9, x8, x9
     780:      	ldrb	w9, [x23, #0xd]
     784:      	add	x2, x8, x9
     788:      	blr	x11
     78c:      	ldrh	w8, [sp, #0x70]
     790:      	cmp	x0, #0x0
     794:      	csel	w8, w8, wzr, eq
     798:      	and	w4, w8, #0xffff
     79c:      	ldrh	w8, [x23, #0x8]
     7a0:      	ldr	x0, [sp, #0x48]
     7a4:      	cmp	w4, w8
     7a8:      	b.eq	0x7cc <perf_unwind_v8+0x7cc>
     7ac:      	b	0xa20 <perf_unwind_v8+0xa20>
     7b0:      	mov	x25, xzr
     7b4:      	mov	w8, wzr
     7b8:      	and	w4, w8, #0xffff
     7bc:      	ldrh	w8, [x23, #0x8]
     7c0:      	ldr	x0, [sp, #0x48]
     7c4:      	cmp	w4, w8
     7c8:      	b.ne	0xa20 <perf_unwind_v8+0xa20>
     7cc:      	mov	w8, #0x60               // =96
     7d0:      	mov	w9, #0x70               // =112
     7d4:      	mov	w1, #0x60               // =96
     7d8:      	mov	x2, x25
     7dc:      	blr	x9
     7e0:      	cbz	x0, 0x978 <perf_unwind_v8+0x978>
     7e4:      	mov	w8, #0x3b               // =59
     7e8:      	adrp	x0, 0x0 <perf_unwind_v8>
     7ec:      	add	x9, sp, #0x58
     7f0:      	str	w8, [sp, #0x58]
     7f4:      	mov	w8, #0x1                // =1
     7f8:      	add	x1, sp, #0x58
     7fc:      	ldr	x0, [x0]
     800:      	blr	x8
     804:      	cbz	x0, 0x9f0 <perf_unwind_v8+0x9f0>
     808:      	ldr	x8, [x0]
     80c:      	add	x8, x8, #0x1
     810:      	str	x8, [x0]
     814:      	b	0xa00 <perf_unwind_v8+0xa00>
     818:      	adrp	x8, 0x0 <perf_unwind_v8>
     81c:      	add	x8, x8, #0x0
     820:      	add	x0, sp, #0x70
     824:      	ldp	x9, x10, [x8]
     828:      	mov	w1, #0x20               // =32
     82c:      	stp	x9, x10, [sp, #0x70]
     830:      	ldp	x9, x8, [x8, #0x10]
     834:      	add	x10, sp, #0x70
     838:      	stp	x9, x8, [sp, #0x80]
     83c:      	mov	w8, #0x20               // =32
     840:      	mov	w9, #0x6                // =6
     844:      	blr	x9
     848:      	b	0x11c <perf_unwind_v8+0x11c>
     84c:      	mov	w8, wzr
     850:      	mov	x11, x25
     854:      	ldrh	w9, [x23, #0xa]
     858:      	cmp	w9, w8, uxth
     85c:      	b.eq	0x598 <perf_unwind_v8+0x598>
     860:      	adrp	x22, 0x0 <perf_unwind_v8>
     864:      	ldr	x22, [x22]
     868:      	ldr	w8, [x22]
     86c:      	cbnz	w8, 0x132c <perf_unwind_v8+0x132c>
     870:      	mov	w8, #0x3a               // =58
     874:      	adrp	x24, 0x0 <perf_unwind_v8>
     878:      	add	x9, sp, #0x58
     87c:      	str	w8, [sp, #0x58]
     880:      	mov	w8, #0x1                // =1
     884:      	add	x1, sp, #0x58
     888:      	ldr	x24, [x24]
     88c:      	mov	x0, x24
     890:      	blr	x8
     894:      	cbnz	x0, 0x3dc <perf_unwind_v8+0x3dc>
     898:      	ldr	w8, [x22]
     89c:      	cbz	w8, 0x4c0 <perf_unwind_v8+0x4c0>
     8a0:      	adrp	x8, 0x0 <perf_unwind_v8>
     8a4:      	add	x8, x8, #0x0
     8a8:      	ldp	x9, x10, [x8, #0x10]
     8ac:      	stp	x9, x10, [sp, #0x80]
     8b0:      	ldr	x9, [x8, #0x20]
     8b4:      	add	x10, sp, #0x70
     8b8:      	str	x9, [sp, #0x90]
     8bc:      	ldur	x9, [x8, #0x26]
     8c0:      	stur	x9, [sp, #0x96]
     8c4:      	ldp	x9, x8, [x8]
     8c8:      	stp	x9, x8, [sp, #0x70]
     8cc:      	mov	w8, #0x2e               // =46
     8d0:      	mov	w9, #0x6                // =6
     8d4:      	b	0xde8 <perf_unwind_v8+0xde8>
     8d8:      	adrp	x8, 0x0 <perf_unwind_v8>
     8dc:      	add	x8, x8, #0x0
     8e0:      	add	x0, sp, #0x70
     8e4:      	ldp	x9, x10, [x8, #0x10]
     8e8:      	mov	w1, #0x2e               // =46
     8ec:      	stp	x9, x10, [sp, #0x80]
     8f0:      	ldr	x9, [x8, #0x20]
     8f4:      	add	x10, sp, #0x70
     8f8:      	str	x9, [sp, #0x90]
     8fc:      	ldur	x9, [x8, #0x26]
     900:      	stur	x9, [sp, #0x96]
     904:      	ldp	x9, x8, [x8]
     908:      	stp	x9, x8, [sp, #0x70]
     90c:      	mov	w8, #0x2e               // =46
     910:      	mov	w9, #0x6                // =6
     914:      	ldr	w2, [sp, #0x58]
     918:      	blr	x9
     91c:      	ldr	x29, [x21, #0xed8]
     920:      	ldr	x25, [x21, #0xee0]
     924:      	ldr	x24, [x21, #0xed0]
     928:      	ldr	w8, [x22]
     92c:      	cbz	w8, 0x168 <perf_unwind_v8+0x168>
     930:      	b	0xc4 <perf_unwind_v8+0xc4>
     934:      	adrp	x8, 0x0 <perf_unwind_v8>
     938:      	add	x8, x8, #0x0
     93c:      	add	x0, sp, #0x70
     940:      	ldp	x9, x10, [x8, #0x10]
     944:      	mov	w1, #0x2e               // =46
     948:      	stp	x9, x10, [sp, #0x80]
     94c:      	ldr	x9, [x8, #0x20]
     950:      	add	x10, sp, #0x70
     954:      	str	x9, [sp, #0x90]
     958:      	ldur	x9, [x8, #0x26]
     95c:      	stur	x9, [sp, #0x96]
     960:      	ldp	x9, x8, [x8]
     964:      	stp	x9, x8, [sp, #0x70]
     968:      	mov	w8, #0x2e               // =46
     96c:      	mov	w9, #0x6                // =6
     970:      	blr	x9
     974:      	b	0x1ac <perf_unwind_v8+0x1ac>
     978:      	ldrb	w8, [x23, #0x12]
     97c:      	cmp	x8, #0x5c
     980:      	b.hi	0x250 <perf_unwind_v8+0x250>
     984:      	ldrb	w9, [x23, #0x13]
     988:      	cmp	x9, #0x5c
     98c:      	b.hi	0x250 <perf_unwind_v8+0x250>
     990:      	ldrb	w11, [x23, #0x10]
     994:      	ldrb	w10, [x23, #0x11]
     998:      	cbz	w11, 0xaec <perf_unwind_v8+0xaec>
     99c:      	ldr	x11, [sp, #0x48]
     9a0:      	ldr	x22, [x11, x10]
     9a4:      	b	0xaf0 <perf_unwind_v8+0xaf0>
     9a8:      	adrp	x8, 0x0 <perf_unwind_v8>
     9ac:      	add	x8, x8, #0x0
     9b0:      	add	x0, sp, #0x70
     9b4:      	ldp	x9, x10, [x8, #0x10]
     9b8:      	mov	w1, #0x2e               // =46
     9bc:      	stp	x9, x10, [sp, #0x80]
     9c0:      	ldr	x9, [x8, #0x20]
     9c4:      	add	x10, sp, #0x70
     9c8:      	str	x9, [sp, #0x90]
     9cc:      	ldur	x9, [x8, #0x26]
     9d0:      	stur	x9, [sp, #0x96]
     9d4:      	ldp	x9, x8, [x8]
     9d8:      	stp	x9, x8, [sp, #0x70]
     9dc:      	mov	w8, #0x2e               // =46
     9e0:      	mov	w9, #0x6                // =6
     9e4:      	ldr	w2, [sp, #0x58]
     9e8:      	blr	x9
     9ec:      	b	0x21c <perf_unwind_v8+0x21c>
     9f0:      	adrp	x8, 0x0 <perf_unwind_v8>
     9f4:      	ldr	x8, [x8]
     9f8:      	ldr	w8, [x8]
     9fc:      	cbnz	w8, 0x1bbc <perf_unwind_v8+0x1bbc>
     a00:      	ldr	x29, [sp, #0x38]
     a04:      	b	0xa7c <perf_unwind_v8+0xa7c>
     a08:      	mov	w8, wzr
     a0c:      	and	w4, wzr, #0xffff
     a10:      	ldrh	w8, [x23, #0x8]
     a14:      	ldr	x0, [sp, #0x48]
     a18:      	cmp	w4, w8
     a1c:      	b.eq	0x7cc <perf_unwind_v8+0x7cc>
     a20:      	adrp	x8, 0x0 <perf_unwind_v8>
     a24:      	ldr	x8, [x8]
     a28:      	ldr	w8, [x8]
     a2c:      	cbnz	w8, 0x1518 <perf_unwind_v8+0x1518>
     a30:      	mov	w8, #0x3b               // =59
     a34:      	adrp	x0, 0x0 <perf_unwind_v8>
     a38:      	add	x9, sp, #0x58
     a3c:      	str	w8, [sp, #0x58]
     a40:      	mov	w8, #0x1                // =1
     a44:      	add	x1, sp, #0x58
     a48:      	ldr	x0, [x0]
     a4c:      	blr	x8
     a50:      	ldr	x29, [sp, #0x38]
     a54:      	cbz	x0, 0xa6c <perf_unwind_v8+0xa6c>
     a58:      	ldr	x8, [x0]
     a5c:      	mov	x25, xzr
     a60:      	add	x8, x8, #0x1
     a64:      	str	x8, [x0]
     a68:      	b	0xa80 <perf_unwind_v8+0xa80>
     a6c:      	adrp	x8, 0x0 <perf_unwind_v8>
     a70:      	ldr	x8, [x8]
     a74:      	ldr	w8, [x8]
     a78:      	cbnz	w8, 0x18c0 <perf_unwind_v8+0x18c0>
     a7c:      	mov	x25, xzr
     a80:      	adrp	x8, 0x0 <perf_unwind_v8>
     a84:      	ldr	x8, [x8]
     a88:      	ldrb	w24, [x21, #0xf20]
     a8c:      	ldr	w8, [x8]
     a90:      	cbz	w8, 0x29c <perf_unwind_v8+0x29c>
     a94:      	mov	w8, #0x786c             // =30828
     a98:      	add	x0, sp, #0x70
     a9c:      	mov	w1, #0x3c               // =60
     aa0:      	mov	x2, x25
     aa4:      	mov	x3, x29
     aa8:      	movk	w8, #0xa, lsl #16
     aac:      	str	w8, [sp, #0xa8]
     ab0:      	adrp	x8, 0x0 <perf_unwind_v8>
     ab4:      	add	x8, x8, #0x0
     ab8:      	ldp	x9, x10, [x8, #0x20]
     abc:      	stp	x9, x10, [sp, #0x90]
     ac0:      	ldr	x9, [x8, #0x30]
     ac4:      	str	x9, [sp, #0xa0]
     ac8:      	ldp	x9, x10, [x8]
     acc:      	stp	x9, x10, [sp, #0x70]
     ad0:      	add	x10, sp, #0x70
     ad4:      	ldp	x8, x9, [x8, #0x10]
     ad8:      	stp	x8, x9, [sp, #0x80]
     adc:      	mov	w8, #0x3c               // =60
     ae0:      	mov	w9, #0x6                // =6
     ae4:      	blr	x9
     ae8:      	b	0x29c <perf_unwind_v8+0x29c>
     aec:      	add	x22, x25, x10
     af0:      	ldr	x10, [sp, #0x48]
     af4:      	ldr	w9, [x10, x9]
     af8:      	ldr	w8, [x10, x8]
     afc:      	str	w9, [sp, #0x18]
     b00:      	ldrb	w9, [x23, #0x18]
     b04:      	str	x8, [sp, #0x20]
     b08:      	add	x8, x22, x8
     b0c:      	str	x8, [sp, #0x28]
     b10:      	adrp	x8, 0x0 <perf_unwind_v8>
     b14:      	str	w9, [sp, #0xc]
     b18:      	ldrb	w9, [x23, #0x17]
     b1c:      	str	x9, [sp, #0x10]
     b20:      	ldr	x8, [x8]
     b24:      	ldr	w8, [x8]
     b28:      	cbnz	w8, 0x1c18 <perf_unwind_v8+0x1c18>
     b2c:      	cmp	x24, x22
     b30:      	b.lo	0xb80 <perf_unwind_v8+0xb80>
     b34:      	ldr	x8, [sp, #0x28]
     b38:      	cmp	x24, x8
     b3c:      	b.hs	0xb80 <perf_unwind_v8+0xb80>
     b40:      	ldr	w8, [sp, #0x18]
     b44:      	ldr	w9, [sp, #0xc]
     b48:      	orr	x11, x25, #0x3
     b4c:      	and	w8, w8, w9
     b50:      	ldr	x9, [sp, #0x10]
     b54:      	ldr	x10, [sp, #0x40]
     b58:      	orr	x10, x10, #0x4
     b5c:      	lsr	w8, w8, w9
     b60:      	ldrb	w9, [x23, #0x19]
     b64:      	cmp	w8, w9
     b68:      	ldr	x9, [sp, #0x20]
     b6c:      	csel	x29, x10, x11, eq
     b70:      	orr	w8, w8, w9, lsl #4
     b74:      	sub	x9, x24, x22
     b78:      	orr	x25, x9, x8, lsl #32
     b7c:      	b	0xa80 <perf_unwind_v8+0xa80>
     b80:      	ldr	w8, [x21, #0x2c0]
     b84:      	cbz	w8, 0xba8 <perf_unwind_v8+0xba8>
     b88:      	adrp	x8, 0x0 <perf_unwind_v8>
     b8c:      	ldr	x8, [x8]
     b90:      	ldr	w8, [x8]
     b94:      	cbnz	w8, 0x1ea4 <perf_unwind_v8+0x1ea4>
     b98:      	ldr	x29, [sp, #0x38]
     b9c:      	ldrb	w24, [x21, #0xf20]
     ba0:      	mov	x25, xzr
     ba4:      	b	0x29c <perf_unwind_v8+0x29c>
     ba8:      	sub	x2, x29, #0x18
     bac:      	mov	w8, #0x18               // =24
     bb0:      	mov	w9, #0x70               // =112
     bb4:      	add	x10, sp, #0x58
     bb8:      	add	x0, sp, #0x58
     bbc:      	mov	w1, #0x18               // =24
     bc0:      	blr	x9
     bc4:      	cbz	x0, 0xcdc <perf_unwind_v8+0xcdc>
     bc8:      	adrp	x8, 0x0 <perf_unwind_v8>
     bcc:      	ldr	x8, [x8]
     bd0:      	ldr	w8, [x8]
     bd4:      	cbnz	w8, 0x1f28 <perf_unwind_v8+0x1f28>
     bd8:      	mov	w8, #0x39               // =57
     bdc:      	adrp	x0, 0x0 <perf_unwind_v8>
     be0:      	add	x9, sp, #0xbc
     be4:      	str	w8, [sp, #0xbc]
     be8:      	mov	w8, #0x1                // =1
     bec:      	add	x1, sp, #0xbc
     bf0:      	ldr	x0, [x0]
     bf4:      	blr	x8
     bf8:      	cbz	x0, 0xdfc <perf_unwind_v8+0xdfc>
     bfc:      	ldr	x8, [x0]
     c00:      	add	x8, x8, #0x1
     c04:      	str	x8, [x0]
     c08:      	b	0xe0c <perf_unwind_v8+0xe0c>
     c0c:      	adrp	x8, 0x0 <perf_unwind_v8>
     c10:      	add	x8, x8, #0x0
     c14:      	add	x0, sp, #0x70
     c18:      	ldp	x9, x10, [x8]
     c1c:      	mov	w1, #0x1d               // =29
     c20:      	mov	x2, x25
     c24:      	stp	x9, x10, [sp, #0x70]
     c28:      	ldr	x9, [x8, #0x10]
     c2c:      	ldur	x8, [x8, #0x15]
     c30:      	add	x10, sp, #0x70
     c34:      	str	x9, [sp, #0x80]
     c38:      	stur	x8, [sp, #0x85]
     c3c:      	mov	w8, #0x1d               // =29
     c40:      	mov	w9, #0x6                // =6
     c44:      	blr	x9
     c48:      	mov	x29, xzr
     c4c:      	b	0xa80 <perf_unwind_v8+0xa80>
     c50:      	mov	w9, #0xa                // =10
     c54:      	add	x0, sp, #0x70
     c58:      	and	w3, w8, #0xffff
     c5c:      	strh	w9, [sp, #0x98]
     c60:      	adrp	x9, 0x0 <perf_unwind_v8>
     c64:      	add	x9, x9, #0x0
     c68:      	mov	w1, #0x2a               // =42
     c6c:      	ldp	x10, x11, [x9, #0x10]
     c70:      	stp	x10, x11, [sp, #0x80]
     c74:      	ldr	x10, [x9, #0x20]
     c78:      	add	x11, sp, #0x70
     c7c:      	str	x10, [sp, #0x90]
     c80:      	ldp	x9, x10, [x9]
     c84:      	stp	x9, x10, [sp, #0x70]
     c88:      	mov	w9, #0x2a               // =42
     c8c:      	mov	w10, #0x6               // =6
     c90:      	ldrh	w2, [x23, #0x4]
     c94:      	ldrh	w4, [x23, #0x6]
     c98:      	blr	x10
     c9c:      	b	0x3b4 <perf_unwind_v8+0x3b4>
     ca0:      	adrp	x8, 0x0 <perf_unwind_v8>
     ca4:      	add	x8, x8, #0x0
     ca8:      	add	x0, sp, #0x70
     cac:      	ldp	x9, x10, [x8, #0x10]
     cb0:      	mov	w1, #0x25               // =37
     cb4:      	stp	x9, x10, [sp, #0x80]
     cb8:      	ldur	x9, [x8, #0x1d]
     cbc:      	add	x10, sp, #0x70
     cc0:      	stur	x9, [sp, #0x8d]
     cc4:      	ldp	x8, x9, [x8]
     cc8:      	stp	x8, x9, [sp, #0x70]
     ccc:      	mov	w8, #0x25               // =37
     cd0:      	mov	w9, #0x6                // =6
     cd4:      	blr	x9
     cd8:      	b	0x2b8 <perf_unwind_v8+0x2b8>
     cdc:      	ldr	x24, [sp, #0x68]
     ce0:      	cmp	x24, x22
     ce4:      	b.lo	0xcf4 <perf_unwind_v8+0xcf4>
     ce8:      	ldr	x8, [sp, #0x28]
     cec:      	cmp	x24, x8
     cf0:      	b.lo	0xd24 <perf_unwind_v8+0xd24>
     cf4:      	ldr	x24, [sp, #0x60]
     cf8:      	cmp	x24, x22
     cfc:      	b.lo	0xd0c <perf_unwind_v8+0xd0c>
     d00:      	ldr	x8, [sp, #0x28]
     d04:      	cmp	x24, x8
     d08:      	b.lo	0xd24 <perf_unwind_v8+0xd24>
     d0c:      	ldr	x24, [sp, #0x58]
     d10:      	cmp	x24, x22
     d14:      	b.lo	0x143c <perf_unwind_v8+0x143c>
     d18:      	ldr	x8, [sp, #0x28]
     d1c:      	cmp	x24, x8
     d20:      	b.hs	0x143c <perf_unwind_v8+0x143c>
     d24:      	adrp	x8, 0x0 <perf_unwind_v8>
     d28:      	ldr	x8, [x8]
     d2c:      	ldr	w8, [x8]
     d30:      	cbz	w8, 0xb40 <perf_unwind_v8+0xb40>
     d34:      	adrp	x8, 0x0 <perf_unwind_v8>
     d38:      	add	x8, x8, #0x0
     d3c:      	add	x0, sp, #0x70
     d40:      	ldp	x9, x10, [x8, #0x10]
     d44:      	mov	w1, #0x27               // =39
     d48:      	mov	x2, x24
     d4c:      	stp	x9, x10, [sp, #0x80]
     d50:      	ldur	x9, [x8, #0x1f]
     d54:      	add	x10, sp, #0x70
     d58:      	stur	x9, [sp, #0x8f]
     d5c:      	ldp	x8, x9, [x8]
     d60:      	stp	x8, x9, [sp, #0x70]
     d64:      	mov	w8, #0x27               // =39
     d68:      	mov	w9, #0x6                // =6
     d6c:      	blr	x9
     d70:      	b	0xb40 <perf_unwind_v8+0xb40>
     d74:      	mov	w8, #0x7265             // =29285
     d78:      	add	x0, sp, #0x70
     d7c:      	mov	w1, #0x1c               // =28
     d80:      	movk	w8, #0xa, lsl #16
     d84:      	str	w8, [sp, #0x88]
     d88:      	adrp	x8, 0x0 <perf_unwind_v8>
     d8c:      	add	x8, x8, #0x0
     d90:      	ldp	x9, x10, [x8]
     d94:      	ldr	x8, [x8, #0x10]
     d98:      	stp	x9, x10, [sp, #0x70]
     d9c:      	str	x8, [sp, #0x80]
     da0:      	mov	w8, #0x1c               // =28
     da4:      	mov	w9, #0x6                // =6
     da8:      	add	x10, sp, #0x70
     dac:      	blr	x9
     db0:      	b	0x450 <perf_unwind_v8+0x450>
     db4:      	adrp	x8, 0x0 <perf_unwind_v8>
     db8:      	add	x8, x8, #0x0
     dbc:      	ldp	x9, x10, [x8, #0x10]
     dc0:      	stp	x9, x10, [sp, #0x80]
     dc4:      	ldr	x9, [x8, #0x20]
     dc8:      	add	x10, sp, #0x70
     dcc:      	str	x9, [sp, #0x90]
     dd0:      	ldur	x9, [x8, #0x26]
     dd4:      	stur	x9, [sp, #0x96]
     dd8:      	ldp	x9, x8, [x8]
     ddc:      	stp	x9, x8, [sp, #0x70]
     de0:      	mov	w8, #0x2e               // =46
     de4:      	mov	w9, #0x6                // =6
     de8:      	ldr	w2, [sp, #0x58]
     dec:      	add	x0, sp, #0x70
     df0:      	mov	w1, #0x2e               // =46
     df4:      	blr	x9
     df8:      	b	0x4c0 <perf_unwind_v8+0x4c0>
     dfc:      	adrp	x8, 0x0 <perf_unwind_v8>
     e00:      	ldr	x8, [x8]
     e04:      	ldr	w8, [x8]
     e08:      	cbnz	w8, 0x201c <perf_unwind_v8+0x201c>
     e0c:      	mov	w29, wzr
     e10:      	mov	w8, #0x1388             // =5000
     e14:      	b	0x258 <perf_unwind_v8+0x258>
     e18:      	adrp	x8, 0x0 <perf_unwind_v8>
     e1c:      	add	x8, x8, #0x0
     e20:      	add	x0, sp, #0x70
     e24:      	ldp	x9, x10, [x8, #0x10]
     e28:      	mov	w1, #0x2e               // =46
     e2c:      	stp	x9, x10, [sp, #0x80]
     e30:      	ldr	x9, [x8, #0x20]
     e34:      	add	x10, sp, #0x70
     e38:      	str	x9, [sp, #0x90]
     e3c:      	ldur	x9, [x8, #0x26]
     e40:      	stur	x9, [sp, #0x96]
     e44:      	ldp	x9, x8, [x8]
     e48:      	stp	x9, x8, [sp, #0x70]
     e4c:      	mov	w8, #0x2e               // =46
     e50:      	mov	w9, #0x6                // =6
     e54:      	ldr	w2, [sp, #0x58]
     e58:      	blr	x9
     e5c:      	b	0x5c4 <perf_unwind_v8+0x5c4>
     e60:      	adrp	x8, 0x0 <perf_unwind_v8>
     e64:      	add	x8, x8, #0x0
     e68:      	mov	x24, x0
     e6c:      	ldp	x9, x10, [x8]
     e70:      	add	x0, sp, #0x70
     e74:      	mov	w1, #0x1f               // =31
     e78:      	stp	x9, x10, [sp, #0x70]
     e7c:      	ldr	x9, [x8, #0x10]
     e80:      	ldur	x8, [x8, #0x17]
     e84:      	add	x10, sp, #0x70
     e88:      	str	x9, [sp, #0x80]
     e8c:      	stur	x8, [sp, #0x87]
     e90:      	mov	w8, #0x1f               // =31
     e94:      	mov	w9, #0x6                // =6
     e98:      	ldr	x2, [x21, #0xed0]
     e9c:      	ldr	x3, [x21, #0xed8]
     ea0:      	ldr	x4, [x21, #0xee0]
     ea4:      	blr	x9
     ea8:      	mov	x0, x24
     eac:      	b	0x61c <perf_unwind_v8+0x61c>
     eb0:      	adrp	x8, 0x0 <perf_unwind_v8>
     eb4:      	add	x8, x8, #0x0
     eb8:      	strb	wzr, [sp, #0xa0]
     ebc:      	add	x0, sp, #0x70
     ec0:      	ldp	x9, x10, [x8, #0x10]
     ec4:      	mov	w1, #0x31               // =49
     ec8:      	stp	x9, x10, [sp, #0x80]
     ecc:      	ldp	x9, x10, [x8, #0x20]
     ed0:      	stp	x9, x10, [sp, #0x90]
     ed4:      	ldp	x9, x8, [x8]
     ed8:      	add	x10, sp, #0x70
     edc:      	stp	x9, x8, [sp, #0x70]
     ee0:      	mov	w8, #0x31               // =49
     ee4:      	mov	w9, #0x6                // =6
     ee8:      	ldr	w2, [x21, #0x2c0]
     eec:      	blr	x9
     ef0:      	ldr	x24, [x21, #0xed0]
     ef4:      	lsr	x8, x24, #56
     ef8:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
     efc:      	cmp	x24, #0xfff
     f00:      	b.hi	0xf30 <perf_unwind_v8+0xf30>
     f04:      	adrp	x22, 0x0 <perf_unwind_v8>
     f08:      	ldr	x22, [x22]
     f0c:      	ldr	w8, [x22]
     f10:      	cbnz	w8, 0x14d8 <perf_unwind_v8+0x14d8>
     f14:      	mov	w8, #0x31               // =49
     f18:      	adrp	x24, 0x0 <perf_unwind_v8>
     f1c:      	mov	w29, wzr
     f20:      	str	w8, [x21, #0xf18]
     f24:      	mov	w8, #0xfae              // =4014
     f28:      	ldr	x24, [x24]
     f2c:      	b	0x19ac <perf_unwind_v8+0x19ac>
     f30:      	ldr	w8, [x21]
     f34:      	mov	w9, #0x60               // =96
     f38:      	adrp	x0, 0x0 <perf_unwind_v8>
     f3c:      	add	x1, sp, #0x58
     f40:      	rev	w8, w8
     f44:      	stp	w9, w8, [sp, #0x58]
     f48:      	rev	x8, x24
     f4c:      	add	x9, sp, #0x58
     f50:      	str	x8, [sp, #0x60]
     f54:      	mov	w8, #0x1                // =1
     f58:      	ldr	x0, [x0]
     f5c:      	blr	x8
     f60:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
     f64:      	ldr	x8, [x0, #0x8]
     f68:      	and	x9, x8, #0xffffffffffffff
     f6c:      	lsr	x29, x8, #56
     f70:      	str	x9, [x21, #0xf10]
     f74:      	ldr	x8, [x0]
     f78:      	str	x8, [x21, #0xf00]
     f7c:      	sub	x8, x24, x9
     f80:      	str	x8, [x21, #0xf08]
     f84:      	adrp	x8, 0x0 <perf_unwind_v8>
     f88:      	ldr	x8, [x8]
     f8c:      	ldr	w8, [x8]
     f90:      	cbnz	w8, 0x1564 <perf_unwind_v8+0x1564>
     f94:      	cmp	w29, #0x1
     f98:      	b.ne	0x1034 <perf_unwind_v8+0x1034>
     f9c:      	ldr	x8, [x21, #0xf00]
     fa0:      	adrp	x0, 0x0 <perf_unwind_v8>
     fa4:      	ldr	x25, [x21, #0xf08]
     fa8:      	mov	w9, #0x1                // =1
     fac:      	add	x1, sp, #0x58
     fb0:      	mov	w29, #0x1               // =1
     fb4:      	str	x8, [sp, #0x58]
     fb8:      	add	x8, sp, #0x58
     fbc:      	ldr	x0, [x0]
     fc0:      	blr	x9
     fc4:      	cbz	x0, 0x1034 <perf_unwind_v8+0x1034>
     fc8:      	ldr	x8, [x0]
     fcc:      	mov	x24, x0
     fd0:      	cmp	x8, x25
     fd4:      	b.hi	0xfe4 <perf_unwind_v8+0xfe4>
     fd8:      	ldr	x8, [x24, #0x8]
     fdc:      	cmp	x8, x25
     fe0:      	b.hs	0xffc <perf_unwind_v8+0xffc>
     fe4:      	ldr	x8, [x24, #0x10]
     fe8:      	cmp	x8, x25
     fec:      	b.hi	0x102c <perf_unwind_v8+0x102c>
     ff0:      	ldr	x8, [x24, #0x18]
     ff4:      	cmp	x8, x25
     ff8:      	b.lo	0x102c <perf_unwind_v8+0x102c>
     ffc:      	adrp	x8, 0x0 <perf_unwind_v8>
    1000:      	ldr	x8, [x8]
    1004:      	ldr	w8, [x8]
    1008:      	cbnz	w8, 0x1ce4 <perf_unwind_v8+0x1ce4>
    100c:      	ldrh	w8, [x24, #0x20]
    1010:      	ldr	w9, [x21, #0x1370]
    1014:      	lsr	w8, w9, w8
    1018:      	tbz	w8, #0x0, 0x1d30 <perf_unwind_v8+0x1d30>
    101c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1020:      	ldr	x8, [x8]
    1024:      	ldr	w8, [x8]
    1028:      	cbnz	w8, 0x1d7c <perf_unwind_v8+0x1d7c>
    102c:      	mov	w29, #0x1               // =1
    1030:      	b	0x1034 <perf_unwind_v8+0x1034>
    1034:      	cmp	w29, #0x7
    1038:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    103c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1040:      	ldr	x29, [x21, #0xed8]
    1044:      	ldr	x25, [x21, #0xee0]
    1048:      	ldr	x24, [x21, #0xed0]
    104c:      	ldr	x8, [x8]
    1050:      	ldr	w8, [x8]
    1054:      	cbnz	w8, 0x1908 <perf_unwind_v8+0x1908>
    1058:      	cmp	x25, x29
    105c:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    1060:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    1064:      	cmp	x25, x8
    1068:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    106c:      	ldr	x0, [sp, #0x50]
    1070:      	sub	x2, x25, #0x40
    1074:      	mov	w8, #0x40               // =64
    1078:      	mov	w9, #0x70               // =112
    107c:      	mov	w1, #0x40               // =64
    1080:      	blr	x9
    1084:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    1088:      	ldrb	w9, [x23, #0x14]
    108c:      	cmp	x9, #0x38
    1090:      	b.hi	0x250 <perf_unwind_v8+0x250>
    1094:      	ldrb	w8, [x23, #0x15]
    1098:      	cmp	x8, #0x38
    109c:      	b.hi	0x250 <perf_unwind_v8+0x250>
    10a0:      	ldrb	w10, [x23, #0x16]
    10a4:      	cmp	x10, #0x38
    10a8:      	b.hi	0x250 <perf_unwind_v8+0x250>
    10ac:      	ldr	x11, [sp, #0x50]
    10b0:      	ldr	x9, [x11, x9]
    10b4:      	tbnz	w9, #0x0, 0x11b8 <perf_unwind_v8+0x11b8>
    10b8:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    10bc:      	lsr	x25, x9, #1
    10c0:      	ldr	x8, [x8]
    10c4:      	ldr	w8, [x8]
    10c8:      	cbnz	w8, 0x2064 <perf_unwind_v8+0x2064>
    10cc:      	ldrb	w24, [x21, #0xf20]
    10d0:      	mov	x22, xzr
    10d4:      	ldr	w8, [x21, #0x2c0]
    10d8:      	cmp	w8, #0x7e
    10dc:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    10e0:      	add	w9, w8, #0x1
    10e4:      	mov	w10, #0x8               // =8
    10e8:      	add	x11, sp, #0x70
    10ec:      	str	w9, [x21, #0x2c0]
    10f0:      	mov	w9, #0x18               // =24
    10f4:      	add	x0, sp, #0x70
    10f8:      	mov	w1, #0x10               // =16
    10fc:      	umaddl	x8, w8, w9, x21
    1100:      	add	x9, x8, #0x2d0
    1104:      	str	x22, [x8, #0x2d0]
    1108:      	str	x25, [x8, #0x2d8]
    110c:      	strb	w10, [x8, #0x2e0]
    1110:      	strb	w24, [x8, #0x2e1]
    1114:      	strh	wzr, [x8, #0x2e6]
    1118:      	mov	w10, #0x70              // =112
    111c:      	stur	wzr, [x9, #0x12]
    1120:      	mov	w9, #0x10               // =16
    1124:      	ldr	x8, [x21, #0xee0]
    1128:      	ldr	x2, [x21, #0xee0]
    112c:      	blr	x10
    1130:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    1134:      	ldr	x8, [x21, #0xee0]
    1138:      	add	x9, x8, #0x10
    113c:      	str	x9, [x21, #0xed8]
    1140:      	ldp	x9, x10, [sp, #0x70]
    1144:      	str	x9, [x21, #0xee0]
    1148:      	mov	w9, #0x101              // =257
    114c:      	str	x10, [x21, #0xed0]
    1150:      	strh	w9, [x21, #0xf20]
    1154:      	cbnz	x22, 0x1168 <perf_unwind_v8+0x1168>
    1158:      	cmp	x25, #0x1
    115c:      	b.ne	0x1168 <perf_unwind_v8+0x1168>
    1160:      	add	x8, x8, #0xa0
    1164:      	str	x8, [x21, #0xed8]
    1168:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    116c:      	ldr	x8, [x8]
    1170:      	ldr	w8, [x8]
    1174:      	cbnz	w8, 0x20a8 <perf_unwind_v8+0x20a8>
    1178:      	mov	w8, #0x38               // =56
    117c:      	adrp	x0, 0x1000 <perf_unwind_v8+0x1000>
    1180:      	add	x9, sp, #0x58
    1184:      	str	w8, [sp, #0x58]
    1188:      	mov	w8, #0x1                // =1
    118c:      	add	x1, sp, #0x58
    1190:      	ldr	x0, [x0]
    1194:      	blr	x8
    1198:      	cbz	x0, 0x160c <perf_unwind_v8+0x160c>
    119c:      	ldr	x8, [x0]
    11a0:      	add	x8, x8, #0x1
    11a4:      	str	x8, [x0]
    11a8:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    11ac:      	ldr	x8, [x8]
    11b0:      	ldr	w8, [x8]
    11b4:      	b	0x161c <perf_unwind_v8+0x161c>
    11b8:      	ldr	x9, [sp, #0x50]
    11bc:      	ldr	x8, [x9, x8]
    11c0:      	ldr	x22, [x9, x10]
    11c4:      	and	x9, x8, #0x3
    11c8:      	and	x8, x8, #0xfffffffffffffffc
    11cc:      	cmp	x9, #0x1
    11d0:      	csel	x29, x8, xzr, eq
    11d4:      	cbz	x29, 0x124c <perf_unwind_v8+0x124c>
    11d8:      	ldrb	w8, [x23, #0xc]
    11dc:      	mov	w9, #0x70               // =112
    11e0:      	add	x10, sp, #0x70
    11e4:      	add	x0, sp, #0x70
    11e8:      	mov	w1, #0x8                // =8
    11ec:      	add	x2, x29, x8
    11f0:      	mov	w8, #0x8                // =8
    11f4:      	blr	x9
    11f8:      	cbnz	x0, 0x124c <perf_unwind_v8+0x124c>
    11fc:      	ldr	x8, [sp, #0x70]
    1200:      	and	x9, x8, #0x3
    1204:      	cmp	x9, #0x1
    1208:      	b.ne	0x124c <perf_unwind_v8+0x124c>
    120c:      	and	x8, x8, #0xfffffffffffffffc
    1210:      	cbz	x8, 0x1250 <perf_unwind_v8+0x1250>
    1214:      	ldrb	w9, [x23, #0xd]
    1218:      	mov	w10, #0x2               // =2
    121c:      	mov	w11, #0x70              // =112
    1220:      	add	x12, sp, #0x70
    1224:      	add	x0, sp, #0x70
    1228:      	mov	w1, #0x2                // =2
    122c:      	add	x9, x8, x9
    1230:      	ldrb	w9, [x23, #0xd]
    1234:      	add	x2, x8, x9
    1238:      	blr	x11
    123c:      	ldrh	w8, [sp, #0x70]
    1240:      	cmp	x0, #0x0
    1244:      	csel	w8, w8, wzr, eq
    1248:      	b	0x1250 <perf_unwind_v8+0x1250>
    124c:      	mov	w8, wzr
    1250:      	ldrh	w9, [x23, #0x4]
    1254:      	cmp	w9, w8, uxth
    1258:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    125c:      	ldrh	w9, [x23, #0x6]
    1260:      	cmp	w9, w8, uxth
    1264:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    1268:      	ldrb	w8, [x23, #0xf]
    126c:      	mov	w9, #0x70               // =112
    1270:      	add	x10, sp, #0x70
    1274:      	add	x0, sp, #0x70
    1278:      	mov	w1, #0x8                // =8
    127c:      	add	x2, x29, x8
    1280:      	mov	w8, #0x8                // =8
    1284:      	blr	x9
    1288:      	cbnz	x0, 0x149c <perf_unwind_v8+0x149c>
    128c:      	ldr	x8, [sp, #0x70]
    1290:      	and	x9, x8, #0x3
    1294:      	cmp	x9, #0x1
    1298:      	b.ne	0x149c <perf_unwind_v8+0x149c>
    129c:      	and	x8, x8, #0xfffffffffffffffc
    12a0:      	str	x8, [sp, #0x40]
    12a4:      	cbz	x8, 0x1c04 <perf_unwind_v8+0x1c04>
    12a8:      	ldrb	w8, [x23, #0xc]
    12ac:      	ldr	x9, [sp, #0x40]
    12b0:      	add	x10, sp, #0x70
    12b4:      	add	x0, sp, #0x70
    12b8:      	mov	w1, #0x8                // =8
    12bc:      	add	x2, x9, x8
    12c0:      	mov	w8, #0x8                // =8
    12c4:      	mov	w9, #0x70               // =112
    12c8:      	blr	x9
    12cc:      	cbnz	x0, 0x14a0 <perf_unwind_v8+0x14a0>
    12d0:      	ldr	x8, [sp, #0x70]
    12d4:      	and	x9, x8, #0x3
    12d8:      	cmp	x9, #0x1
    12dc:      	b.ne	0x14a0 <perf_unwind_v8+0x14a0>
    12e0:      	and	x8, x8, #0xfffffffffffffffc
    12e4:      	cbz	x8, 0x14a4 <perf_unwind_v8+0x14a4>
    12e8:      	ldrb	w9, [x23, #0xd]
    12ec:      	mov	w10, #0x2               // =2
    12f0:      	mov	w11, #0x70              // =112
    12f4:      	add	x12, sp, #0x70
    12f8:      	add	x0, sp, #0x70
    12fc:      	mov	w1, #0x2                // =2
    1300:      	add	x9, x8, x9
    1304:      	ldrb	w9, [x23, #0xd]
    1308:      	add	x2, x8, x9
    130c:      	blr	x11
    1310:      	ldrh	w8, [sp, #0x70]
    1314:      	cmp	x0, #0x0
    1318:      	csel	w8, w8, wzr, eq
    131c:      	ldrh	w9, [x23, #0xa]
    1320:      	cmp	w9, w8, uxth
    1324:      	b.ne	0x860 <perf_unwind_v8+0x860>
    1328:      	b	0x14b0 <perf_unwind_v8+0x14b0>
    132c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1330:      	add	x8, x8, #0x0
    1334:      	add	x0, sp, #0x70
    1338:      	ldp	x9, x10, [x8]
    133c:      	mov	w1, #0x1f               // =31
    1340:      	stp	x9, x10, [sp, #0x70]
    1344:      	ldr	x9, [x8, #0x10]
    1348:      	ldur	x8, [x8, #0x17]
    134c:      	add	x10, sp, #0x70
    1350:      	str	x9, [sp, #0x80]
    1354:      	stur	x8, [sp, #0x87]
    1358:      	mov	w8, #0x1f               // =31
    135c:      	mov	w9, #0x6                // =6
    1360:      	blr	x9
    1364:      	b	0x870 <perf_unwind_v8+0x870>
    1368:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    136c:      	add	x8, x8, #0x0
    1370:      	add	x0, sp, #0x70
    1374:      	ldp	x9, x10, [x8, #0x10]
    1378:      	mov	w1, #0x2e               // =46
    137c:      	stp	x9, x10, [sp, #0x80]
    1380:      	ldr	x9, [x8, #0x20]
    1384:      	add	x10, sp, #0x70
    1388:      	str	x9, [sp, #0x90]
    138c:      	ldur	x9, [x8, #0x26]
    1390:      	stur	x9, [sp, #0x96]
    1394:      	ldp	x9, x8, [x8]
    1398:      	stp	x9, x8, [sp, #0x70]
    139c:      	mov	w8, #0x2e               // =46
    13a0:      	mov	w9, #0x6                // =6
    13a4:      	ldr	w2, [sp, #0x58]
    13a8:      	blr	x9
    13ac:      	b	0x644 <perf_unwind_v8+0x644>
    13b0:      	mov	w8, #0xa                // =10
    13b4:      	add	x0, sp, #0x70
    13b8:      	mov	w1, #0x22               // =34
    13bc:      	strh	w8, [sp, #0x90]
    13c0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    13c4:      	add	x8, x8, #0x0
    13c8:      	mov	x2, x24
    13cc:      	ldp	x9, x10, [x8]
    13d0:      	stp	x9, x10, [sp, #0x70]
    13d4:      	ldp	x9, x8, [x8, #0x10]
    13d8:      	add	x10, sp, #0x70
    13dc:      	stp	x9, x8, [sp, #0x80]
    13e0:      	mov	w8, #0x22               // =34
    13e4:      	mov	w9, #0x6                // =6
    13e8:      	blr	x9
    13ec:      	b	0x688 <perf_unwind_v8+0x688>
    13f0:      	mov	w8, #0x786c             // =30828
    13f4:      	add	x0, sp, #0x70
    13f8:      	mov	w1, #0x1c               // =28
    13fc:      	mov	x2, x25
    1400:      	mov	x22, x11
    1404:      	movk	w8, #0xa, lsl #16
    1408:      	str	w8, [sp, #0x88]
    140c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1410:      	add	x8, x8, #0x0
    1414:      	ldp	x9, x10, [x8]
    1418:      	ldr	x8, [x8, #0x10]
    141c:      	stp	x9, x10, [sp, #0x70]
    1420:      	str	x8, [sp, #0x80]
    1424:      	mov	w8, #0x1c               // =28
    1428:      	mov	w9, #0x6                // =6
    142c:      	add	x10, sp, #0x70
    1430:      	blr	x9
    1434:      	mov	x11, x22
    1438:      	b	0x5b4 <perf_unwind_v8+0x5b4>
    143c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1440:      	ldr	x8, [x8]
    1444:      	ldr	w8, [x8]
    1448:      	cbz	w8, 0xa00 <perf_unwind_v8+0xa00>
    144c:      	mov	w8, #0x786c             // =30828
    1450:      	add	x0, sp, #0x70
    1454:      	mov	w1, #0x33               // =51
    1458:      	movk	w8, #0xa, lsl #16
    145c:      	stur	w8, [sp, #0x9f]
    1460:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1464:      	add	x8, x8, #0x0
    1468:      	ldp	x9, x10, [x8, #0x10]
    146c:      	stp	x9, x10, [sp, #0x80]
    1470:      	ldp	x9, x10, [x8, #0x20]
    1474:      	stp	x9, x10, [sp, #0x90]
    1478:      	ldp	x9, x8, [x8]
    147c:      	add	x10, sp, #0x70
    1480:      	stp	x9, x8, [sp, #0x70]
    1484:      	mov	w8, #0x33               // =51
    1488:      	mov	w9, #0x6                // =6
    148c:      	ldp	x3, x2, [sp, #0x60]
    1490:      	ldr	x4, [sp, #0x58]
    1494:      	blr	x9
    1498:      	b	0xa00 <perf_unwind_v8+0xa00>
    149c:      	str	xzr, [sp, #0x40]
    14a0:      	mov	w8, wzr
    14a4:      	ldrh	w9, [x23, #0xa]
    14a8:      	cmp	w9, w8, uxth
    14ac:      	b.ne	0x860 <perf_unwind_v8+0x860>
    14b0:      	lsr	x25, x22, #32
    14b4:      	cbz	x25, 0x1744 <perf_unwind_v8+0x1744>
    14b8:      	tbnz	w22, #0x0, 0x1744 <perf_unwind_v8+0x1744>
    14bc:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    14c0:      	ldr	x8, [x8]
    14c4:      	ldr	w8, [x8]
    14c8:      	cbnz	w8, 0x2188 <perf_unwind_v8+0x2188>
    14cc:      	ldr	x8, [sp, #0x40]
    14d0:      	orr	x22, x8, #0x1
    14d4:      	b	0x1e2c <perf_unwind_v8+0x1e2c>
    14d8:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    14dc:      	add	x8, x8, #0x0
    14e0:      	add	x0, sp, #0x70
    14e4:      	ldp	x9, x10, [x8]
    14e8:      	mov	w1, #0x1e               // =30
    14ec:      	mov	x2, x24
    14f0:      	stp	x9, x10, [sp, #0x70]
    14f4:      	ldr	x9, [x8, #0x10]
    14f8:      	ldur	x8, [x8, #0x16]
    14fc:      	add	x10, sp, #0x70
    1500:      	str	x9, [sp, #0x80]
    1504:      	stur	x8, [sp, #0x86]
    1508:      	mov	w8, #0x1e               // =30
    150c:      	mov	w9, #0x6                // =6
    1510:      	blr	x9
    1514:      	b	0xf14 <perf_unwind_v8+0xf14>
    1518:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    151c:      	add	x8, x8, #0x0
    1520:      	add	x0, sp, #0x70
    1524:      	ldp	x9, x10, [x8, #0x10]
    1528:      	mov	w1, #0x2e               // =46
    152c:      	mov	x3, x25
    1530:      	stp	x9, x10, [sp, #0x80]
    1534:      	ldr	x9, [x8, #0x20]
    1538:      	add	x10, sp, #0x70
    153c:      	str	x9, [sp, #0x90]
    1540:      	ldur	x9, [x8, #0x26]
    1544:      	stur	x9, [sp, #0x96]
    1548:      	ldp	x9, x8, [x8]
    154c:      	stp	x9, x8, [sp, #0x70]
    1550:      	mov	w8, #0x2e               // =46
    1554:      	mov	w9, #0x6                // =6
    1558:      	ldr	x2, [sp, #0x40]
    155c:      	blr	x9
    1560:      	b	0xa30 <perf_unwind_v8+0xa30>
    1564:      	mov	w8, #0xa                // =10
    1568:      	add	x0, sp, #0x70
    156c:      	mov	w1, #0x32               // =50
    1570:      	strh	w8, [sp, #0xa0]
    1574:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1578:      	add	x8, x8, #0x0
    157c:      	mov	x2, x24
    1580:      	ldp	x9, x10, [x8, #0x10]
    1584:      	mov	w4, w29
    1588:      	stp	x9, x10, [sp, #0x80]
    158c:      	ldp	x9, x10, [x8, #0x20]
    1590:      	stp	x9, x10, [sp, #0x90]
    1594:      	ldp	x9, x8, [x8]
    1598:      	add	x10, sp, #0x70
    159c:      	stp	x9, x8, [sp, #0x70]
    15a0:      	mov	w8, #0x32               // =50
    15a4:      	mov	w9, #0x6                // =6
    15a8:      	ldr	x3, [x21, #0xf00]
    15ac:      	blr	x9
    15b0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    15b4:      	ldr	x8, [x8]
    15b8:      	ldr	w8, [x8]
    15bc:      	cbz	w8, 0xf94 <perf_unwind_v8+0xf94>
    15c0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    15c4:      	add	x8, x8, #0x0
    15c8:      	add	x0, sp, #0x70
    15cc:      	ldp	x9, x10, [x8, #0x10]
    15d0:      	mov	w1, #0x2f               // =47
    15d4:      	stp	x9, x10, [sp, #0x80]
    15d8:      	ldr	x9, [x8, #0x20]
    15dc:      	add	x10, sp, #0x70
    15e0:      	str	x9, [sp, #0x90]
    15e4:      	ldur	x9, [x8, #0x27]
    15e8:      	stur	x9, [sp, #0x97]
    15ec:      	ldp	x9, x8, [x8]
    15f0:      	stp	x9, x8, [sp, #0x70]
    15f4:      	mov	w8, #0x2f               // =47
    15f8:      	mov	w9, #0x6                // =6
    15fc:      	ldr	x2, [x21, #0xf10]
    1600:      	ldr	x3, [x21, #0xf08]
    1604:      	blr	x9
    1608:      	b	0xf94 <perf_unwind_v8+0xf94>
    160c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1610:      	ldr	x8, [x8]
    1614:      	ldr	w8, [x8]
    1618:      	cbnz	w8, 0x2140 <perf_unwind_v8+0x2140>
    161c:      	ldr	x24, [x21, #0xed0]
    1620:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    1624:      	cbnz	w8, 0x20f0 <perf_unwind_v8+0x20f0>
    1628:      	lsr	x8, x24, #56
    162c:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    1630:      	cmp	x24, #0x1, lsl #12      // =0x1000
    1634:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    1638:      	ldr	w8, [x21]
    163c:      	mov	w9, #0x60               // =96
    1640:      	adrp	x0, 0x1000 <perf_unwind_v8+0x1000>
    1644:      	add	x1, sp, #0x58
    1648:      	rev	w8, w8
    164c:      	stp	w9, w8, [sp, #0x58]
    1650:      	rev	x8, x24
    1654:      	add	x9, sp, #0x58
    1658:      	str	x8, [sp, #0x60]
    165c:      	mov	w8, #0x1                // =1
    1660:      	ldr	x0, [x0]
    1664:      	blr	x8
    1668:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    166c:      	ldr	x8, [x0, #0x8]
    1670:      	and	x9, x8, #0xffffffffffffff
    1674:      	lsr	x29, x8, #56
    1678:      	str	x9, [x21, #0xf10]
    167c:      	ldr	x8, [x0]
    1680:      	str	x8, [x21, #0xf00]
    1684:      	sub	x8, x24, x9
    1688:      	str	x8, [x21, #0xf08]
    168c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1690:      	ldr	x8, [x8]
    1694:      	ldr	w8, [x8]
    1698:      	cbnz	w8, 0x2218 <perf_unwind_v8+0x2218>
    169c:      	cmp	w29, #0x1
    16a0:      	b.ne	0x2434 <perf_unwind_v8+0x2434>
    16a4:      	ldr	x8, [x21, #0xf00]
    16a8:      	adrp	x0, 0x1000 <perf_unwind_v8+0x1000>
    16ac:      	ldr	x25, [x21, #0xf08]
    16b0:      	mov	w9, #0x1                // =1
    16b4:      	add	x1, sp, #0x58
    16b8:      	mov	w29, #0x1               // =1
    16bc:      	str	x8, [sp, #0x58]
    16c0:      	add	x8, sp, #0x58
    16c4:      	ldr	x0, [x0]
    16c8:      	blr	x9
    16cc:      	cbz	x0, 0x1e98 <perf_unwind_v8+0x1e98>
    16d0:      	ldr	x8, [x0]
    16d4:      	mov	x24, x0
    16d8:      	cmp	x8, x25
    16dc:      	b.hi	0x16ec <perf_unwind_v8+0x16ec>
    16e0:      	ldr	x8, [x24, #0x8]
    16e4:      	cmp	x8, x25
    16e8:      	b.hs	0x1704 <perf_unwind_v8+0x1704>
    16ec:      	ldr	x8, [x24, #0x10]
    16f0:      	cmp	x8, x25
    16f4:      	b.hi	0x1734 <perf_unwind_v8+0x1734>
    16f8:      	ldr	x8, [x24, #0x18]
    16fc:      	cmp	x8, x25
    1700:      	b.lo	0x1734 <perf_unwind_v8+0x1734>
    1704:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1708:      	ldr	x8, [x8]
    170c:      	ldr	w8, [x8]
    1710:      	cbnz	w8, 0x23a4 <perf_unwind_v8+0x23a4>
    1714:      	ldrh	w8, [x24, #0x20]
    1718:      	ldr	w9, [x21, #0x1370]
    171c:      	lsr	w8, w9, w8
    1720:      	tbz	w8, #0x0, 0x23f0 <perf_unwind_v8+0x23f0>
    1724:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1728:      	ldr	x8, [x8]
    172c:      	ldr	w8, [x8]
    1730:      	cbnz	w8, 0x2ab0 <perf_unwind_v8+0x2ab0>
    1734:      	mov	w29, #0x1               // =1
    1738:      	cmp	w29, #0x7
    173c:      	b.eq	0x243c <perf_unwind_v8+0x243c>
    1740:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    1744:      	ldr	x8, [sp, #0x40]
    1748:      	mov	w9, #0x70               // =112
    174c:      	add	x10, sp, #0x70
    1750:      	add	x0, sp, #0x70
    1754:      	mov	w1, #0x8                // =8
    1758:      	orr	x22, x8, #0x2
    175c:      	ldrb	w8, [x23, #0xe]
    1760:      	add	x2, x29, x8
    1764:      	mov	w8, #0x8                // =8
    1768:      	blr	x9
    176c:      	cbnz	x0, 0x1810 <perf_unwind_v8+0x1810>
    1770:      	ldr	x8, [sp, #0x70]
    1774:      	and	x9, x8, #0x3
    1778:      	cmp	x9, #0x1
    177c:      	b.ne	0x1810 <perf_unwind_v8+0x1810>
    1780:      	and	x8, x8, #0xfffffffffffffffc
    1784:      	mov	x25, x8
    1788:      	cbz	x8, 0x1818 <perf_unwind_v8+0x1818>
    178c:      	ldrb	w8, [x23, #0xc]
    1790:      	mov	w9, #0x70               // =112
    1794:      	add	x10, sp, #0x70
    1798:      	add	x0, sp, #0x70
    179c:      	mov	w1, #0x8                // =8
    17a0:      	add	x2, x25, x8
    17a4:      	mov	w8, #0x8                // =8
    17a8:      	blr	x9
    17ac:      	cbnz	x0, 0x1dbc <perf_unwind_v8+0x1dbc>
    17b0:      	ldr	x8, [sp, #0x70]
    17b4:      	and	x9, x8, #0x3
    17b8:      	cmp	x9, #0x1
    17bc:      	b.ne	0x1dbc <perf_unwind_v8+0x1dbc>
    17c0:      	and	x8, x8, #0xfffffffffffffffc
    17c4:      	cbz	x8, 0x1818 <perf_unwind_v8+0x1818>
    17c8:      	ldrb	w9, [x23, #0xd]
    17cc:      	mov	w10, #0x2               // =2
    17d0:      	mov	w11, #0x70              // =112
    17d4:      	add	x12, sp, #0x70
    17d8:      	add	x0, sp, #0x70
    17dc:      	mov	w1, #0x2                // =2
    17e0:      	add	x9, x8, x9
    17e4:      	ldrb	w9, [x23, #0xd]
    17e8:      	add	x2, x8, x9
    17ec:      	blr	x11
    17f0:      	ldrh	w8, [sp, #0x70]
    17f4:      	cmp	x0, #0x0
    17f8:      	csel	w8, w8, wzr, eq
    17fc:      	and	w4, w8, #0xffff
    1800:      	ldrh	w8, [x23, #0x8]
    1804:      	cmp	w4, w8
    1808:      	b.eq	0x1828 <perf_unwind_v8+0x1828>
    180c:      	b	0x1dd0 <perf_unwind_v8+0x1dd0>
    1810:      	mov	x25, xzr
    1814:      	mov	w8, wzr
    1818:      	and	w4, w8, #0xffff
    181c:      	ldrh	w8, [x23, #0x8]
    1820:      	cmp	w4, w8
    1824:      	b.ne	0x1dd0 <perf_unwind_v8+0x1dd0>
    1828:      	ldr	x0, [sp, #0x48]
    182c:      	mov	w8, #0x60               // =96
    1830:      	mov	w9, #0x70               // =112
    1834:      	mov	x2, x25
    1838:      	mov	w1, #0x60               // =96
    183c:      	blr	x9
    1840:      	cbz	x0, 0x1cb4 <perf_unwind_v8+0x1cb4>
    1844:      	mov	w8, #0x3b               // =59
    1848:      	adrp	x0, 0x1000 <perf_unwind_v8+0x1000>
    184c:      	add	x9, sp, #0x58
    1850:      	str	w8, [sp, #0x58]
    1854:      	mov	w8, #0x1                // =1
    1858:      	add	x1, sp, #0x58
    185c:      	ldr	x0, [x0]
    1860:      	blr	x8
    1864:      	cbnz	x0, 0x1e04 <perf_unwind_v8+0x1e04>
    1868:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    186c:      	ldr	x8, [x8]
    1870:      	ldr	w8, [x8]
    1874:      	cbz	w8, 0x1e28 <perf_unwind_v8+0x1e28>
    1878:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    187c:      	add	x8, x8, #0x0
    1880:      	add	x0, sp, #0x70
    1884:      	ldp	x9, x10, [x8, #0x10]
    1888:      	mov	w1, #0x2e               // =46
    188c:      	stp	x9, x10, [sp, #0x80]
    1890:      	ldr	x9, [x8, #0x20]
    1894:      	add	x10, sp, #0x70
    1898:      	str	x9, [sp, #0x90]
    189c:      	ldur	x9, [x8, #0x26]
    18a0:      	stur	x9, [sp, #0x96]
    18a4:      	ldp	x9, x8, [x8]
    18a8:      	stp	x9, x8, [sp, #0x70]
    18ac:      	mov	w8, #0x2e               // =46
    18b0:      	mov	w9, #0x6                // =6
    18b4:      	ldr	w2, [sp, #0x58]
    18b8:      	blr	x9
    18bc:      	b	0x1e28 <perf_unwind_v8+0x1e28>
    18c0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    18c4:      	add	x8, x8, #0x0
    18c8:      	add	x0, sp, #0x70
    18cc:      	ldp	x9, x10, [x8, #0x10]
    18d0:      	mov	w1, #0x2e               // =46
    18d4:      	stp	x9, x10, [sp, #0x80]
    18d8:      	ldr	x9, [x8, #0x20]
    18dc:      	add	x10, sp, #0x70
    18e0:      	str	x9, [sp, #0x90]
    18e4:      	ldur	x9, [x8, #0x26]
    18e8:      	stur	x9, [sp, #0x96]
    18ec:      	ldp	x9, x8, [x8]
    18f0:      	stp	x9, x8, [sp, #0x70]
    18f4:      	mov	w8, #0x2e               // =46
    18f8:      	mov	w9, #0x6                // =6
    18fc:      	ldr	w2, [sp, #0x58]
    1900:      	blr	x9
    1904:      	b	0xa7c <perf_unwind_v8+0xa7c>
    1908:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    190c:      	add	x8, x8, #0x0
    1910:      	add	x0, sp, #0x70
    1914:      	ldp	x9, x10, [x8]
    1918:      	mov	w1, #0x1f               // =31
    191c:      	mov	x2, x24
    1920:      	mov	x3, x29
    1924:      	stp	x9, x10, [sp, #0x70]
    1928:      	ldr	x9, [x8, #0x10]
    192c:      	ldur	x8, [x8, #0x17]
    1930:      	add	x10, sp, #0x70
    1934:      	mov	x4, x25
    1938:      	str	x9, [sp, #0x80]
    193c:      	stur	x8, [sp, #0x87]
    1940:      	mov	w8, #0x1f               // =31
    1944:      	mov	w9, #0x6                // =6
    1948:      	blr	x9
    194c:      	cmp	x25, x29
    1950:      	b.hs	0x1060 <perf_unwind_v8+0x1060>
    1954:      	adrp	x22, 0x1000 <perf_unwind_v8+0x1000>
    1958:      	ldr	x22, [x22]
    195c:      	ldr	w8, [x22]
    1960:      	cbnz	w8, 0x1ae4 <perf_unwind_v8+0x1ae4>
    1964:      	mov	w8, #0x39               // =57
    1968:      	adrp	x24, 0x1000 <perf_unwind_v8+0x1000>
    196c:      	add	x9, sp, #0x58
    1970:      	str	w8, [sp, #0x58]
    1974:      	mov	w8, #0x1                // =1
    1978:      	add	x1, sp, #0x58
    197c:      	ldr	x24, [x24]
    1980:      	mov	x0, x24
    1984:      	blr	x8
    1988:      	cbz	x0, 0x199c <perf_unwind_v8+0x199c>
    198c:      	ldr	x8, [x0]
    1990:      	add	x8, x8, #0x1
    1994:      	str	x8, [x0]
    1998:      	b	0x19a4 <perf_unwind_v8+0x19a4>
    199c:      	ldr	w8, [x22]
    19a0:      	cbnz	w8, 0x1b2c <perf_unwind_v8+0x1b2c>
    19a4:      	mov	w29, wzr
    19a8:      	mov	w8, #0x1388             // =5000
    19ac:      	str	w8, [x21, #0xf1c]
    19b0:      	str	wzr, [sp, #0x70]
    19b4:      	mov	w8, #0x1                // =1
    19b8:      	add	x9, sp, #0x70
    19bc:      	add	x1, sp, #0x70
    19c0:      	mov	x0, x20
    19c4:      	blr	x8
    19c8:      	cbz	x0, 0x1a1c <perf_unwind_v8+0x1a1c>
    19cc:      	mov	w20, #0x1374            // =4980
    19d0:      	mov	w2, w29
    19d4:      	ldrb	w8, [x0, x20]
    19d8:      	cmp	w8, #0x1d
    19dc:      	b.lo	0x1a48 <perf_unwind_v8+0x1a48>
    19e0:      	mov	w8, #0x5                // =5
    19e4:      	add	x9, sp, #0x58
    19e8:      	mov	x21, x0
    19ec:      	str	w8, [x0, #0xf1c]
    19f0:      	mov	w8, #0x44               // =68
    19f4:      	add	x1, sp, #0x58
    19f8:      	mov	x0, x24
    19fc:      	str	w8, [sp, #0x58]
    1a00:      	mov	w8, #0x1                // =1
    1a04:      	blr	x8
    1a08:      	cbz	x0, 0x1a34 <perf_unwind_v8+0x1a34>
    1a0c:      	ldr	x8, [x0]
    1a10:      	add	x8, x8, #0x1
    1a14:      	str	x8, [x0]
    1a18:      	b	0x1a3c <perf_unwind_v8+0x1a3c>
    1a1c:      	adrp	x10, 0x1000 <perf_unwind_v8+0x1000>
    1a20:      	mov	x9, xzr
    1a24:      	mov	w8, #0xc                // =12
    1a28:      	ldr	x10, [x10]
    1a2c:      	mov	w2, wzr
    1a30:      	b	0x1a60 <perf_unwind_v8+0x1a60>
    1a34:      	ldr	w8, [x22]
    1a38:      	cbnz	w8, 0x1b74 <perf_unwind_v8+0x1b74>
    1a3c:      	ldrb	w8, [x21, x20]
    1a40:      	mov	w2, wzr
    1a44:      	mov	x0, x21
    1a48:      	add	w8, w8, #0x1
    1a4c:      	adrp	x10, 0x1000 <perf_unwind_v8+0x1000>
    1a50:      	mov	w9, w2
    1a54:      	strb	w8, [x0, x20]
    1a58:      	mov	w8, #0xc                // =12
    1a5c:      	ldr	x10, [x10]
    1a60:      	adrp	x1, 0x1000 <perf_unwind_v8+0x1000>
    1a64:      	mov	x0, x19
    1a68:      	ldr	x1, [x1]
    1a6c:      	blr	x8
    1a70:      	ldr	w8, [x22]
    1a74:      	cbnz	w8, 0x1a98 <perf_unwind_v8+0x1a98>
    1a78:      	ldp	x20, x19, [sp, #0xf0]
    1a7c:      	mov	w0, #-0x1               // =-1
    1a80:      	ldr	x29, [sp, #0xb0]
    1a84:      	ldp	x22, x21, [sp, #0xe0]
    1a88:      	ldp	x24, x23, [sp, #0xd0]
    1a8c:      	ldp	x30, x25, [sp, #0xc0]
    1a90:      	add	sp, sp, #0x100
    1a94:      	ret
    1a98:      	mov	w8, #0x6465             // =25701
    1a9c:      	add	x0, sp, #0x70
    1aa0:      	mov	w1, #0x33               // =51
    1aa4:      	mov	w2, w29
    1aa8:      	movk	w8, #0xa, lsl #16
    1aac:      	stur	w8, [sp, #0x9f]
    1ab0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1ab4:      	add	x8, x8, #0x0
    1ab8:      	ldp	x9, x10, [x8, #0x10]
    1abc:      	stp	x9, x10, [sp, #0x80]
    1ac0:      	ldp	x9, x10, [x8, #0x20]
    1ac4:      	stp	x9, x10, [sp, #0x90]
    1ac8:      	ldp	x9, x8, [x8]
    1acc:      	add	x10, sp, #0x70
    1ad0:      	stp	x9, x8, [sp, #0x70]
    1ad4:      	mov	w8, #0x33               // =51
    1ad8:      	mov	w9, #0x6                // =6
    1adc:      	blr	x9
    1ae0:      	b	0x1a78 <perf_unwind_v8+0x1a78>
    1ae4:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1ae8:      	add	x8, x8, #0x0
    1aec:      	strb	wzr, [sp, #0x98]
    1af0:      	add	x0, sp, #0x70
    1af4:      	ldp	x9, x10, [x8, #0x10]
    1af8:      	mov	w1, #0x29               // =41
    1afc:      	mov	x2, x25
    1b00:      	mov	x3, x29
    1b04:      	stp	x9, x10, [sp, #0x80]
    1b08:      	ldr	x9, [x8, #0x20]
    1b0c:      	add	x10, sp, #0x70
    1b10:      	str	x9, [sp, #0x90]
    1b14:      	ldp	x8, x9, [x8]
    1b18:      	stp	x8, x9, [sp, #0x70]
    1b1c:      	mov	w8, #0x29               // =41
    1b20:      	mov	w9, #0x6                // =6
    1b24:      	blr	x9
    1b28:      	b	0x1964 <perf_unwind_v8+0x1964>
    1b2c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1b30:      	add	x8, x8, #0x0
    1b34:      	ldp	x9, x10, [x8, #0x10]
    1b38:      	stp	x9, x10, [sp, #0x80]
    1b3c:      	ldr	x9, [x8, #0x20]
    1b40:      	add	x10, sp, #0x70
    1b44:      	str	x9, [sp, #0x90]
    1b48:      	ldur	x9, [x8, #0x26]
    1b4c:      	stur	x9, [sp, #0x96]
    1b50:      	ldp	x9, x8, [x8]
    1b54:      	stp	x9, x8, [sp, #0x70]
    1b58:      	mov	w8, #0x2e               // =46
    1b5c:      	mov	w9, #0x6                // =6
    1b60:      	ldr	w2, [sp, #0x58]
    1b64:      	add	x0, sp, #0x70
    1b68:      	mov	w1, #0x2e               // =46
    1b6c:      	blr	x9
    1b70:      	b	0x19a4 <perf_unwind_v8+0x19a4>
    1b74:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1b78:      	add	x8, x8, #0x0
    1b7c:      	add	x0, sp, #0x70
    1b80:      	ldp	x9, x10, [x8, #0x10]
    1b84:      	mov	w1, #0x2e               // =46
    1b88:      	stp	x9, x10, [sp, #0x80]
    1b8c:      	ldr	x9, [x8, #0x20]
    1b90:      	add	x10, sp, #0x70
    1b94:      	str	x9, [sp, #0x90]
    1b98:      	ldur	x9, [x8, #0x26]
    1b9c:      	stur	x9, [sp, #0x96]
    1ba0:      	ldp	x9, x8, [x8]
    1ba4:      	stp	x9, x8, [sp, #0x70]
    1ba8:      	mov	w8, #0x2e               // =46
    1bac:      	mov	w9, #0x6                // =6
    1bb0:      	ldr	w2, [sp, #0x58]
    1bb4:      	blr	x9
    1bb8:      	b	0x1a3c <perf_unwind_v8+0x1a3c>
    1bbc:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1bc0:      	add	x8, x8, #0x0
    1bc4:      	add	x0, sp, #0x70
    1bc8:      	ldp	x9, x10, [x8, #0x10]
    1bcc:      	mov	w1, #0x2e               // =46
    1bd0:      	stp	x9, x10, [sp, #0x80]
    1bd4:      	ldr	x9, [x8, #0x20]
    1bd8:      	add	x10, sp, #0x70
    1bdc:      	str	x9, [sp, #0x90]
    1be0:      	ldur	x9, [x8, #0x26]
    1be4:      	stur	x9, [sp, #0x96]
    1be8:      	ldp	x9, x8, [x8]
    1bec:      	stp	x9, x8, [sp, #0x70]
    1bf0:      	mov	w8, #0x2e               // =46
    1bf4:      	mov	w9, #0x6                // =6
    1bf8:      	ldr	w2, [sp, #0x58]
    1bfc:      	blr	x9
    1c00:      	b	0xa00 <perf_unwind_v8+0xa00>
    1c04:      	str	xzr, [sp, #0x40]
    1c08:      	ldrh	w9, [x23, #0xa]
    1c0c:      	cmp	w9, w8, uxth
    1c10:      	b.ne	0x860 <perf_unwind_v8+0x860>
    1c14:      	b	0x14b0 <perf_unwind_v8+0x14b0>
    1c18:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1c1c:      	add	x8, x8, #0x0
    1c20:      	strb	wzr, [sp, #0x98]
    1c24:      	add	x0, sp, #0x70
    1c28:      	ldp	x9, x10, [x8, #0x10]
    1c2c:      	mov	w1, #0x29               // =41
    1c30:      	mov	x4, x25
    1c34:      	stp	x9, x10, [sp, #0x80]
    1c38:      	ldr	x9, [x8, #0x20]
    1c3c:      	add	x10, sp, #0x70
    1c40:      	str	x9, [sp, #0x90]
    1c44:      	ldp	x8, x9, [x8]
    1c48:      	stp	x8, x9, [sp, #0x70]
    1c4c:      	mov	w8, #0x29               // =41
    1c50:      	mov	w9, #0x6                // =6
    1c54:      	ldr	x2, [sp, #0x40]
    1c58:      	ldr	x3, [sp, #0x30]
    1c5c:      	blr	x9
    1c60:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1c64:      	ldr	x8, [x8]
    1c68:      	ldr	w8, [x8]
    1c6c:      	cbz	w8, 0xb2c <perf_unwind_v8+0xb2c>
    1c70:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1c74:      	add	x8, x8, #0x0
    1c78:      	add	x0, sp, #0x70
    1c7c:      	ldp	x9, x10, [x8, #0x10]
    1c80:      	mov	w1, #0x25               // =37
    1c84:      	mov	x2, x22
    1c88:      	stp	x9, x10, [sp, #0x80]
    1c8c:      	ldur	x9, [x8, #0x1d]
    1c90:      	add	x10, sp, #0x70
    1c94:      	stur	x9, [sp, #0x8d]
    1c98:      	ldp	x8, x9, [x8]
    1c9c:      	stp	x8, x9, [sp, #0x70]
    1ca0:      	mov	w8, #0x25               // =37
    1ca4:      	mov	w9, #0x6                // =6
    1ca8:      	ldp	x4, x3, [sp, #0x20]
    1cac:      	blr	x9
    1cb0:      	b	0xb2c <perf_unwind_v8+0xb2c>
    1cb4:      	ldrb	w8, [x23, #0x12]
    1cb8:      	cmp	x8, #0x5c
    1cbc:      	b.hi	0x250 <perf_unwind_v8+0x250>
    1cc0:      	ldrb	w9, [x23, #0x13]
    1cc4:      	cmp	x9, #0x5c
    1cc8:      	b.hi	0x250 <perf_unwind_v8+0x250>
    1ccc:      	ldrb	w11, [x23, #0x10]
    1cd0:      	ldrb	w10, [x23, #0x11]
    1cd4:      	cbz	w11, 0x1f68 <perf_unwind_v8+0x1f68>
    1cd8:      	ldr	x11, [sp, #0x48]
    1cdc:      	ldr	x10, [x11, x10]
    1ce0:      	b	0x1f6c <perf_unwind_v8+0x1f6c>
    1ce4:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1ce8:      	add	x8, x8, #0x0
    1cec:      	add	x0, sp, #0x70
    1cf0:      	ldp	x9, x10, [x8]
    1cf4:      	mov	w1, #0x1e               // =30
    1cf8:      	stp	x9, x10, [sp, #0x70]
    1cfc:      	ldr	x9, [x8, #0x10]
    1d00:      	ldur	x8, [x8, #0x16]
    1d04:      	add	x10, sp, #0x70
    1d08:      	str	x9, [sp, #0x80]
    1d0c:      	stur	x8, [sp, #0x86]
    1d10:      	mov	w8, #0x1e               // =30
    1d14:      	mov	w9, #0x6                // =6
    1d18:      	ldrh	w2, [x24, #0x20]
    1d1c:      	blr	x9
    1d20:      	ldrh	w8, [x24, #0x20]
    1d24:      	ldr	w9, [x21, #0x1370]
    1d28:      	lsr	w8, w9, w8
    1d2c:      	tbnz	w8, #0x0, 0x101c <perf_unwind_v8+0x101c>
    1d30:      	str	wzr, [sp, #0xbc]
    1d34:      	adrp	x0, 0x1000 <perf_unwind_v8+0x1000>
    1d38:      	mov	w8, #0x1                // =1
    1d3c:      	add	x9, sp, #0xbc
    1d40:      	ldr	x0, [x0]
    1d44:      	add	x1, sp, #0xbc
    1d48:      	blr	x8
    1d4c:      	cbz	x0, 0x1d64 <perf_unwind_v8+0x1d64>
    1d50:      	ldr	x8, [x0]
    1d54:      	add	x8, x8, #0x1
    1d58:      	str	x8, [x0]
    1d5c:      	ldrh	w29, [x24, #0x20]
    1d60:      	b	0x1034 <perf_unwind_v8+0x1034>
    1d64:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1d68:      	ldr	x8, [x8]
    1d6c:      	ldr	w8, [x8]
    1d70:      	cbnz	w8, 0x1ee0 <perf_unwind_v8+0x1ee0>
    1d74:      	ldrh	w29, [x24, #0x20]
    1d78:      	b	0x1034 <perf_unwind_v8+0x1034>
    1d7c:      	mov	w8, #0x656e             // =25966
    1d80:      	add	x0, sp, #0x70
    1d84:      	mov	w1, #0x1b               // =27
    1d88:      	movk	w8, #0xa, lsl #16
    1d8c:      	stur	w8, [sp, #0x87]
    1d90:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1d94:      	add	x8, x8, #0x0
    1d98:      	ldp	x9, x10, [x8]
    1d9c:      	ldr	x8, [x8, #0x10]
    1da0:      	stp	x9, x10, [sp, #0x70]
    1da4:      	str	x8, [sp, #0x80]
    1da8:      	mov	w8, #0x1b               // =27
    1dac:      	mov	w9, #0x6                // =6
    1db0:      	add	x10, sp, #0x70
    1db4:      	blr	x9
    1db8:      	b	0x102c <perf_unwind_v8+0x102c>
    1dbc:      	mov	w8, wzr
    1dc0:      	and	w4, wzr, #0xffff
    1dc4:      	ldrh	w8, [x23, #0x8]
    1dc8:      	cmp	w4, w8
    1dcc:      	b.eq	0x1828 <perf_unwind_v8+0x1828>
    1dd0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1dd4:      	ldr	x8, [x8]
    1dd8:      	ldr	w8, [x8]
    1ddc:      	cbnz	w8, 0x21cc <perf_unwind_v8+0x21cc>
    1de0:      	mov	w8, #0x3b               // =59
    1de4:      	adrp	x0, 0x1000 <perf_unwind_v8+0x1000>
    1de8:      	add	x9, sp, #0x58
    1dec:      	str	w8, [sp, #0x58]
    1df0:      	mov	w8, #0x1                // =1
    1df4:      	add	x1, sp, #0x58
    1df8:      	ldr	x0, [x0]
    1dfc:      	blr	x8
    1e00:      	cbz	x0, 0x1e18 <perf_unwind_v8+0x1e18>
    1e04:      	ldr	x8, [x0]
    1e08:      	mov	x25, xzr
    1e0c:      	add	x8, x8, #0x1
    1e10:      	str	x8, [x0]
    1e14:      	b	0x1e2c <perf_unwind_v8+0x1e2c>
    1e18:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1e1c:      	ldr	x8, [x8]
    1e20:      	ldr	w8, [x8]
    1e24:      	cbnz	w8, 0x22c0 <perf_unwind_v8+0x22c0>
    1e28:      	mov	x25, xzr
    1e2c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1e30:      	ldr	x8, [x8]
    1e34:      	ldrb	w24, [x21, #0xf20]
    1e38:      	ldr	w8, [x8]
    1e3c:      	cbz	w8, 0x10d4 <perf_unwind_v8+0x10d4>
    1e40:      	mov	w8, #0x786c             // =30828
    1e44:      	add	x0, sp, #0x70
    1e48:      	mov	w1, #0x3c               // =60
    1e4c:      	mov	x2, x25
    1e50:      	mov	x3, x22
    1e54:      	movk	w8, #0xa, lsl #16
    1e58:      	str	w8, [sp, #0xa8]
    1e5c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1e60:      	add	x8, x8, #0x0
    1e64:      	ldp	x9, x10, [x8, #0x20]
    1e68:      	stp	x9, x10, [sp, #0x90]
    1e6c:      	ldr	x9, [x8, #0x30]
    1e70:      	str	x9, [sp, #0xa0]
    1e74:      	ldp	x9, x10, [x8]
    1e78:      	stp	x9, x10, [sp, #0x70]
    1e7c:      	add	x10, sp, #0x70
    1e80:      	ldp	x8, x9, [x8, #0x10]
    1e84:      	stp	x8, x9, [sp, #0x80]
    1e88:      	mov	w8, #0x3c               // =60
    1e8c:      	mov	w9, #0x6                // =6
    1e90:      	blr	x9
    1e94:      	b	0x10d4 <perf_unwind_v8+0x10d4>
    1e98:      	cmp	w29, #0x7
    1e9c:      	b.eq	0x243c <perf_unwind_v8+0x243c>
    1ea0:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    1ea4:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1ea8:      	add	x8, x8, #0x0
    1eac:      	add	x0, sp, #0x70
    1eb0:      	ldp	x9, x10, [x8, #0x10]
    1eb4:      	mov	w1, #0x30               // =48
    1eb8:      	stp	x9, x10, [sp, #0x80]
    1ebc:      	ldp	x9, x10, [x8, #0x20]
    1ec0:      	stp	x9, x10, [sp, #0x90]
    1ec4:      	ldp	x9, x8, [x8]
    1ec8:      	add	x10, sp, #0x70
    1ecc:      	stp	x9, x8, [sp, #0x70]
    1ed0:      	mov	w8, #0x30               // =48
    1ed4:      	mov	w9, #0x6                // =6
    1ed8:      	blr	x9
    1edc:      	b	0xa00 <perf_unwind_v8+0xa00>
    1ee0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1ee4:      	add	x8, x8, #0x0
    1ee8:      	add	x0, sp, #0x70
    1eec:      	ldp	x9, x10, [x8, #0x10]
    1ef0:      	mov	w1, #0x2e               // =46
    1ef4:      	stp	x9, x10, [sp, #0x80]
    1ef8:      	ldr	x9, [x8, #0x20]
    1efc:      	add	x10, sp, #0x70
    1f00:      	str	x9, [sp, #0x90]
    1f04:      	ldur	x9, [x8, #0x26]
    1f08:      	stur	x9, [sp, #0x96]
    1f0c:      	ldp	x9, x8, [x8]
    1f10:      	stp	x9, x8, [sp, #0x70]
    1f14:      	mov	w8, #0x2e               // =46
    1f18:      	mov	w9, #0x6                // =6
    1f1c:      	ldr	w2, [sp, #0xbc]
    1f20:      	blr	x9
    1f24:      	b	0x1d74 <perf_unwind_v8+0x1d74>
    1f28:      	mov	w8, #0x7265             // =29285
    1f2c:      	add	x0, sp, #0x70
    1f30:      	mov	w1, #0x1c               // =28
    1f34:      	movk	w8, #0xa, lsl #16
    1f38:      	str	w8, [sp, #0x88]
    1f3c:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1f40:      	add	x8, x8, #0x0
    1f44:      	ldp	x9, x10, [x8]
    1f48:      	ldr	x8, [x8, #0x10]
    1f4c:      	stp	x9, x10, [sp, #0x70]
    1f50:      	str	x8, [sp, #0x80]
    1f54:      	mov	w8, #0x1c               // =28
    1f58:      	mov	w9, #0x6                // =6
    1f5c:      	add	x10, sp, #0x70
    1f60:      	blr	x9
    1f64:      	b	0xbd8 <perf_unwind_v8+0xbd8>
    1f68:      	add	x10, x25, x10
    1f6c:      	str	x10, [sp, #0x38]
    1f70:      	ldr	x10, [sp, #0x48]
    1f74:      	ldr	w9, [x10, x9]
    1f78:      	ldr	w8, [x10, x8]
    1f7c:      	str	w9, [sp, #0x20]
    1f80:      	ldrb	w9, [x23, #0x18]
    1f84:      	str	x8, [sp, #0x28]
    1f88:      	str	w9, [sp, #0x10]
    1f8c:      	ldrb	w9, [x23, #0x17]
    1f90:      	str	x9, [sp, #0x18]
    1f94:      	ldr	x9, [sp, #0x38]
    1f98:      	add	x8, x9, x8
    1f9c:      	str	x8, [sp, #0x30]
    1fa0:      	adrp	x8, 0x1000 <perf_unwind_v8+0x1000>
    1fa4:      	ldr	x8, [x8]
    1fa8:      	ldr	w8, [x8]
    1fac:      	cbnz	w8, 0x2308 <perf_unwind_v8+0x2308>
    1fb0:      	ldr	x8, [sp, #0x38]
    1fb4:      	subs	x8, x24, x8
    1fb8:      	b.lo	0x2000 <perf_unwind_v8+0x2000>
    1fbc:      	ldr	x9, [sp, #0x30]
    1fc0:      	cmp	x24, x9
    1fc4:      	b.hs	0x2000 <perf_unwind_v8+0x2000>
    1fc8:      	ldr	w9, [sp, #0x20]
    1fcc:      	ldr	w10, [sp, #0x10]
    1fd0:      	orr	x11, x29, #0x4
    1fd4:      	orr	x12, x25, #0x3
    1fd8:      	and	w9, w9, w10
    1fdc:      	ldr	x10, [sp, #0x18]
    1fe0:      	lsr	w9, w9, w10
    1fe4:      	ldrb	w10, [x23, #0x19]
    1fe8:      	cmp	w9, w10
    1fec:      	ldr	x10, [sp, #0x28]
    1ff0:      	csel	x22, x11, x12, eq
    1ff4:      	orr	w9, w9, w10, lsl #4
    1ff8:      	orr	x25, x8, x9, lsl #32
    1ffc:      	b	0x1e2c <perf_unwind_v8+0x1e2c>
    2000:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2004:      	ldr	x8, [x8]
    2008:      	ldr	w8, [x8]
    200c:      	cbnz	w8, 0x2afc <perf_unwind_v8+0x2afc>
    2010:      	ldrb	w24, [x21, #0xf20]
    2014:      	mov	x25, xzr
    2018:      	b	0x10d4 <perf_unwind_v8+0x10d4>
    201c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2020:      	add	x8, x8, #0x0
    2024:      	add	x0, sp, #0x70
    2028:      	ldp	x9, x10, [x8, #0x10]
    202c:      	mov	w1, #0x2e               // =46
    2030:      	stp	x9, x10, [sp, #0x80]
    2034:      	ldr	x9, [x8, #0x20]
    2038:      	add	x10, sp, #0x70
    203c:      	str	x9, [sp, #0x90]
    2040:      	ldur	x9, [x8, #0x26]
    2044:      	stur	x9, [sp, #0x96]
    2048:      	ldp	x9, x8, [x8]
    204c:      	stp	x9, x8, [sp, #0x70]
    2050:      	mov	w8, #0x2e               // =46
    2054:      	mov	w9, #0x6                // =6
    2058:      	ldr	w2, [sp, #0xbc]
    205c:      	blr	x9
    2060:      	b	0xe0c <perf_unwind_v8+0xe0c>
    2064:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2068:      	add	x8, x8, #0x0
    206c:      	add	x0, sp, #0x70
    2070:      	ldp	x9, x10, [x8]
    2074:      	mov	w1, #0x1d               // =29
    2078:      	mov	x2, x25
    207c:      	stp	x9, x10, [sp, #0x70]
    2080:      	ldr	x9, [x8, #0x10]
    2084:      	ldur	x8, [x8, #0x15]
    2088:      	add	x10, sp, #0x70
    208c:      	str	x9, [sp, #0x80]
    2090:      	stur	x8, [sp, #0x85]
    2094:      	mov	w8, #0x1d               // =29
    2098:      	mov	w9, #0x6                // =6
    209c:      	blr	x9
    20a0:      	mov	x22, xzr
    20a4:      	b	0x1e2c <perf_unwind_v8+0x1e2c>
    20a8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    20ac:      	add	x8, x8, #0x0
    20b0:      	add	x0, sp, #0x70
    20b4:      	ldp	x9, x10, [x8]
    20b8:      	mov	w1, #0x1f               // =31
    20bc:      	stp	x9, x10, [sp, #0x70]
    20c0:      	ldr	x9, [x8, #0x10]
    20c4:      	ldur	x8, [x8, #0x17]
    20c8:      	add	x10, sp, #0x70
    20cc:      	str	x9, [sp, #0x80]
    20d0:      	stur	x8, [sp, #0x87]
    20d4:      	mov	w8, #0x1f               // =31
    20d8:      	mov	w9, #0x6                // =6
    20dc:      	ldr	x2, [x21, #0xed0]
    20e0:      	ldr	x3, [x21, #0xed8]
    20e4:      	ldr	x4, [x21, #0xee0]
    20e8:      	blr	x9
    20ec:      	b	0x1178 <perf_unwind_v8+0x1178>
    20f0:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    20f4:      	add	x8, x8, #0x0
    20f8:      	strb	wzr, [sp, #0xa0]
    20fc:      	add	x0, sp, #0x70
    2100:      	ldp	x9, x10, [x8, #0x10]
    2104:      	mov	w1, #0x31               // =49
    2108:      	stp	x9, x10, [sp, #0x80]
    210c:      	ldp	x9, x10, [x8, #0x20]
    2110:      	stp	x9, x10, [sp, #0x90]
    2114:      	ldp	x9, x8, [x8]
    2118:      	add	x10, sp, #0x70
    211c:      	stp	x9, x8, [sp, #0x70]
    2120:      	mov	w8, #0x31               // =49
    2124:      	mov	w9, #0x6                // =6
    2128:      	ldr	w2, [x21, #0x2c0]
    212c:      	blr	x9
    2130:      	ldr	x24, [x21, #0xed0]
    2134:      	lsr	x8, x24, #56
    2138:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    213c:      	b	0x1630 <perf_unwind_v8+0x1630>
    2140:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2144:      	add	x8, x8, #0x0
    2148:      	add	x0, sp, #0x70
    214c:      	ldp	x9, x10, [x8, #0x10]
    2150:      	mov	w1, #0x2e               // =46
    2154:      	stp	x9, x10, [sp, #0x80]
    2158:      	ldr	x9, [x8, #0x20]
    215c:      	add	x10, sp, #0x70
    2160:      	str	x9, [sp, #0x90]
    2164:      	ldur	x9, [x8, #0x26]
    2168:      	stur	x9, [sp, #0x96]
    216c:      	ldp	x9, x8, [x8]
    2170:      	stp	x9, x8, [sp, #0x70]
    2174:      	mov	w8, #0x2e               // =46
    2178:      	mov	w9, #0x6                // =6
    217c:      	ldr	w2, [sp, #0x58]
    2180:      	blr	x9
    2184:      	b	0x11a8 <perf_unwind_v8+0x11a8>
    2188:      	mov	w8, #0x786c             // =30828
    218c:      	add	x0, sp, #0x70
    2190:      	mov	w1, #0x1c               // =28
    2194:      	mov	x2, x25
    2198:      	movk	w8, #0xa, lsl #16
    219c:      	str	w8, [sp, #0x88]
    21a0:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    21a4:      	add	x8, x8, #0x0
    21a8:      	ldp	x9, x10, [x8]
    21ac:      	ldr	x8, [x8, #0x10]
    21b0:      	stp	x9, x10, [sp, #0x70]
    21b4:      	mov	w9, #0x6                // =6
    21b8:      	str	x8, [sp, #0x80]
    21bc:      	mov	w8, #0x1c               // =28
    21c0:      	add	x10, sp, #0x70
    21c4:      	blr	x9
    21c8:      	b	0x14cc <perf_unwind_v8+0x14cc>
    21cc:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    21d0:      	add	x8, x8, #0x0
    21d4:      	add	x0, sp, #0x70
    21d8:      	ldp	x9, x10, [x8, #0x10]
    21dc:      	mov	w1, #0x2e               // =46
    21e0:      	mov	x2, x29
    21e4:      	mov	x3, x25
    21e8:      	stp	x9, x10, [sp, #0x80]
    21ec:      	ldr	x9, [x8, #0x20]
    21f0:      	add	x10, sp, #0x70
    21f4:      	str	x9, [sp, #0x90]
    21f8:      	ldur	x9, [x8, #0x26]
    21fc:      	stur	x9, [sp, #0x96]
    2200:      	ldp	x9, x8, [x8]
    2204:      	stp	x9, x8, [sp, #0x70]
    2208:      	mov	w8, #0x2e               // =46
    220c:      	mov	w9, #0x6                // =6
    2210:      	blr	x9
    2214:      	b	0x1de0 <perf_unwind_v8+0x1de0>
    2218:      	mov	w8, #0xa                // =10
    221c:      	add	x0, sp, #0x70
    2220:      	mov	w1, #0x32               // =50
    2224:      	strh	w8, [sp, #0xa0]
    2228:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    222c:      	add	x8, x8, #0x0
    2230:      	mov	x2, x24
    2234:      	ldp	x9, x10, [x8, #0x10]
    2238:      	mov	w4, w29
    223c:      	stp	x9, x10, [sp, #0x80]
    2240:      	ldp	x9, x10, [x8, #0x20]
    2244:      	stp	x9, x10, [sp, #0x90]
    2248:      	ldp	x9, x8, [x8]
    224c:      	add	x10, sp, #0x70
    2250:      	stp	x9, x8, [sp, #0x70]
    2254:      	mov	w8, #0x32               // =50
    2258:      	mov	w9, #0x6                // =6
    225c:      	ldr	x3, [x21, #0xf00]
    2260:      	blr	x9
    2264:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2268:      	ldr	x8, [x8]
    226c:      	ldr	w8, [x8]
    2270:      	cbz	w8, 0x169c <perf_unwind_v8+0x169c>
    2274:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2278:      	add	x8, x8, #0x0
    227c:      	add	x0, sp, #0x70
    2280:      	ldp	x9, x10, [x8, #0x10]
    2284:      	mov	w1, #0x2f               // =47
    2288:      	stp	x9, x10, [sp, #0x80]
    228c:      	ldr	x9, [x8, #0x20]
    2290:      	add	x10, sp, #0x70
    2294:      	str	x9, [sp, #0x90]
    2298:      	ldur	x9, [x8, #0x27]
    229c:      	stur	x9, [sp, #0x97]
    22a0:      	ldp	x9, x8, [x8]
    22a4:      	stp	x9, x8, [sp, #0x70]
    22a8:      	mov	w8, #0x2f               // =47
    22ac:      	mov	w9, #0x6                // =6
    22b0:      	ldr	x2, [x21, #0xf10]
    22b4:      	ldr	x3, [x21, #0xf08]
    22b8:      	blr	x9
    22bc:      	b	0x169c <perf_unwind_v8+0x169c>
    22c0:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    22c4:      	add	x8, x8, #0x0
    22c8:      	add	x0, sp, #0x70
    22cc:      	ldp	x9, x10, [x8, #0x10]
    22d0:      	mov	w1, #0x2e               // =46
    22d4:      	stp	x9, x10, [sp, #0x80]
    22d8:      	ldr	x9, [x8, #0x20]
    22dc:      	add	x10, sp, #0x70
    22e0:      	str	x9, [sp, #0x90]
    22e4:      	ldur	x9, [x8, #0x26]
    22e8:      	stur	x9, [sp, #0x96]
    22ec:      	ldp	x9, x8, [x8]
    22f0:      	stp	x9, x8, [sp, #0x70]
    22f4:      	mov	w8, #0x2e               // =46
    22f8:      	mov	w9, #0x6                // =6
    22fc:      	ldr	w2, [sp, #0x58]
    2300:      	blr	x9
    2304:      	b	0x1e28 <perf_unwind_v8+0x1e28>
    2308:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    230c:      	add	x8, x8, #0x0
    2310:      	strb	wzr, [sp, #0x98]
    2314:      	add	x0, sp, #0x70
    2318:      	ldp	x9, x10, [x8, #0x10]
    231c:      	mov	w1, #0x29               // =41
    2320:      	mov	x2, x29
    2324:      	mov	x4, x25
    2328:      	stp	x9, x10, [sp, #0x80]
    232c:      	ldr	x9, [x8, #0x20]
    2330:      	add	x10, sp, #0x70
    2334:      	str	x9, [sp, #0x90]
    2338:      	ldp	x8, x9, [x8]
    233c:      	stp	x8, x9, [sp, #0x70]
    2340:      	mov	w8, #0x29               // =41
    2344:      	mov	w9, #0x6                // =6
    2348:      	ldr	x3, [sp, #0x40]
    234c:      	blr	x9
    2350:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2354:      	ldr	x8, [x8]
    2358:      	ldr	w8, [x8]
    235c:      	cbz	w8, 0x1fb0 <perf_unwind_v8+0x1fb0>
    2360:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2364:      	add	x8, x8, #0x0
    2368:      	add	x0, sp, #0x70
    236c:      	ldp	x9, x10, [x8, #0x10]
    2370:      	mov	w1, #0x25               // =37
    2374:      	stp	x9, x10, [sp, #0x80]
    2378:      	ldur	x9, [x8, #0x1d]
    237c:      	add	x10, sp, #0x70
    2380:      	stur	x9, [sp, #0x8d]
    2384:      	ldp	x8, x9, [x8]
    2388:      	stp	x8, x9, [sp, #0x70]
    238c:      	mov	w8, #0x25               // =37
    2390:      	mov	w9, #0x6                // =6
    2394:      	ldp	x3, x2, [sp, #0x30]
    2398:      	ldr	x4, [sp, #0x28]
    239c:      	blr	x9
    23a0:      	b	0x1fb0 <perf_unwind_v8+0x1fb0>
    23a4:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    23a8:      	add	x8, x8, #0x0
    23ac:      	add	x0, sp, #0x70
    23b0:      	ldp	x9, x10, [x8]
    23b4:      	mov	w1, #0x1e               // =30
    23b8:      	stp	x9, x10, [sp, #0x70]
    23bc:      	ldr	x9, [x8, #0x10]
    23c0:      	ldur	x8, [x8, #0x16]
    23c4:      	add	x10, sp, #0x70
    23c8:      	str	x9, [sp, #0x80]
    23cc:      	stur	x8, [sp, #0x86]
    23d0:      	mov	w8, #0x1e               // =30
    23d4:      	mov	w9, #0x6                // =6
    23d8:      	ldrh	w2, [x24, #0x20]
    23dc:      	blr	x9
    23e0:      	ldrh	w8, [x24, #0x20]
    23e4:      	ldr	w9, [x21, #0x1370]
    23e8:      	lsr	w8, w9, w8
    23ec:      	tbnz	w8, #0x0, 0x1724 <perf_unwind_v8+0x1724>
    23f0:      	str	wzr, [sp, #0xbc]
    23f4:      	adrp	x0, 0x2000 <perf_unwind_v8+0x2000>
    23f8:      	mov	w8, #0x1                // =1
    23fc:      	add	x9, sp, #0xbc
    2400:      	ldr	x0, [x0]
    2404:      	add	x1, sp, #0xbc
    2408:      	blr	x8
    240c:      	cbz	x0, 0x2420 <perf_unwind_v8+0x2420>
    2410:      	ldr	x8, [x0]
    2414:      	add	x8, x8, #0x1
    2418:      	str	x8, [x0]
    241c:      	b	0x2430 <perf_unwind_v8+0x2430>
    2420:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2424:      	ldr	x8, [x8]
    2428:      	ldr	w8, [x8]
    242c:      	cbnz	w8, 0x2c20 <perf_unwind_v8+0x2c20>
    2430:      	ldrh	w29, [x24, #0x20]
    2434:      	cmp	w29, #0x7
    2438:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    243c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2440:      	ldr	x29, [x21, #0xed8]
    2444:      	ldr	x25, [x21, #0xee0]
    2448:      	ldr	x24, [x21, #0xed0]
    244c:      	ldr	x8, [x8]
    2450:      	ldr	w8, [x8]
    2454:      	cbnz	w8, 0x2a1c <perf_unwind_v8+0x2a1c>
    2458:      	cmp	x25, x29
    245c:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    2460:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    2464:      	cmp	x25, x8
    2468:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    246c:      	ldr	x0, [sp, #0x50]
    2470:      	sub	x2, x25, #0x40
    2474:      	mov	w8, #0x40               // =64
    2478:      	mov	w9, #0x70               // =112
    247c:      	mov	w1, #0x40               // =64
    2480:      	blr	x9
    2484:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    2488:      	ldrb	w9, [x23, #0x14]
    248c:      	cmp	x9, #0x38
    2490:      	b.hi	0x250 <perf_unwind_v8+0x250>
    2494:      	ldrb	w8, [x23, #0x15]
    2498:      	cmp	x8, #0x38
    249c:      	b.hi	0x250 <perf_unwind_v8+0x250>
    24a0:      	ldrb	w10, [x23, #0x16]
    24a4:      	cmp	x10, #0x38
    24a8:      	b.hi	0x250 <perf_unwind_v8+0x250>
    24ac:      	ldr	x11, [sp, #0x50]
    24b0:      	ldr	x9, [x11, x9]
    24b4:      	tbnz	w9, #0x0, 0x25b8 <perf_unwind_v8+0x25b8>
    24b8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    24bc:      	lsr	x25, x9, #1
    24c0:      	ldr	x8, [x8]
    24c4:      	ldr	w8, [x8]
    24c8:      	cbnz	w8, 0x2d1c <perf_unwind_v8+0x2d1c>
    24cc:      	ldrb	w24, [x21, #0xf20]
    24d0:      	mov	x22, xzr
    24d4:      	ldr	w8, [x21, #0x2c0]
    24d8:      	cmp	w8, #0x7e
    24dc:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    24e0:      	add	w9, w8, #0x1
    24e4:      	mov	w10, #0x8               // =8
    24e8:      	add	x11, sp, #0x70
    24ec:      	str	w9, [x21, #0x2c0]
    24f0:      	mov	w9, #0x18               // =24
    24f4:      	add	x0, sp, #0x70
    24f8:      	mov	w1, #0x10               // =16
    24fc:      	umaddl	x8, w8, w9, x21
    2500:      	add	x9, x8, #0x2d0
    2504:      	str	x22, [x8, #0x2d0]
    2508:      	str	x25, [x8, #0x2d8]
    250c:      	strb	w10, [x8, #0x2e0]
    2510:      	strb	w24, [x8, #0x2e1]
    2514:      	strh	wzr, [x8, #0x2e6]
    2518:      	mov	w10, #0x70              // =112
    251c:      	stur	wzr, [x9, #0x12]
    2520:      	mov	w9, #0x10               // =16
    2524:      	ldr	x8, [x21, #0xee0]
    2528:      	ldr	x2, [x21, #0xee0]
    252c:      	blr	x10
    2530:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    2534:      	ldr	x8, [x21, #0xee0]
    2538:      	add	x9, x8, #0x10
    253c:      	str	x9, [x21, #0xed8]
    2540:      	ldp	x9, x10, [sp, #0x70]
    2544:      	str	x9, [x21, #0xee0]
    2548:      	mov	w9, #0x101              // =257
    254c:      	str	x10, [x21, #0xed0]
    2550:      	strh	w9, [x21, #0xf20]
    2554:      	cbnz	x22, 0x2568 <perf_unwind_v8+0x2568>
    2558:      	cmp	x25, #0x1
    255c:      	b.ne	0x2568 <perf_unwind_v8+0x2568>
    2560:      	add	x8, x8, #0xa0
    2564:      	str	x8, [x21, #0xed8]
    2568:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    256c:      	ldr	x8, [x8]
    2570:      	ldr	w8, [x8]
    2574:      	cbnz	w8, 0x2d60 <perf_unwind_v8+0x2d60>
    2578:      	mov	w8, #0x38               // =56
    257c:      	adrp	x0, 0x2000 <perf_unwind_v8+0x2000>
    2580:      	add	x9, sp, #0x58
    2584:      	str	w8, [sp, #0x58]
    2588:      	mov	w8, #0x1                // =1
    258c:      	add	x1, sp, #0x58
    2590:      	ldr	x0, [x0]
    2594:      	blr	x8
    2598:      	cbz	x0, 0x2768 <perf_unwind_v8+0x2768>
    259c:      	ldr	x8, [x0]
    25a0:      	add	x8, x8, #0x1
    25a4:      	str	x8, [x0]
    25a8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    25ac:      	ldr	x8, [x8]
    25b0:      	ldr	w8, [x8]
    25b4:      	b	0x2778 <perf_unwind_v8+0x2778>
    25b8:      	ldr	x9, [sp, #0x50]
    25bc:      	ldr	x8, [x9, x8]
    25c0:      	ldr	x22, [x9, x10]
    25c4:      	and	x9, x8, #0x3
    25c8:      	and	x8, x8, #0xfffffffffffffffc
    25cc:      	cmp	x9, #0x1
    25d0:      	csel	x29, x8, xzr, eq
    25d4:      	cbz	x29, 0x264c <perf_unwind_v8+0x264c>
    25d8:      	ldrb	w8, [x23, #0xc]
    25dc:      	mov	w9, #0x70               // =112
    25e0:      	add	x10, sp, #0x70
    25e4:      	add	x0, sp, #0x70
    25e8:      	mov	w1, #0x8                // =8
    25ec:      	add	x2, x29, x8
    25f0:      	mov	w8, #0x8                // =8
    25f4:      	blr	x9
    25f8:      	cbnz	x0, 0x264c <perf_unwind_v8+0x264c>
    25fc:      	ldr	x8, [sp, #0x70]
    2600:      	and	x9, x8, #0x3
    2604:      	cmp	x9, #0x1
    2608:      	b.ne	0x264c <perf_unwind_v8+0x264c>
    260c:      	and	x8, x8, #0xfffffffffffffffc
    2610:      	cbz	x8, 0x2650 <perf_unwind_v8+0x2650>
    2614:      	ldrb	w9, [x23, #0xd]
    2618:      	mov	w10, #0x2               // =2
    261c:      	mov	w11, #0x70              // =112
    2620:      	add	x12, sp, #0x70
    2624:      	add	x0, sp, #0x70
    2628:      	mov	w1, #0x2                // =2
    262c:      	add	x9, x8, x9
    2630:      	ldrb	w9, [x23, #0xd]
    2634:      	add	x2, x8, x9
    2638:      	blr	x11
    263c:      	ldrh	w8, [sp, #0x70]
    2640:      	cmp	x0, #0x0
    2644:      	csel	w8, w8, wzr, eq
    2648:      	b	0x2650 <perf_unwind_v8+0x2650>
    264c:      	mov	w8, wzr
    2650:      	ldrh	w9, [x23, #0x4]
    2654:      	cmp	w9, w8, uxth
    2658:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    265c:      	ldrh	w9, [x23, #0x6]
    2660:      	cmp	w9, w8, uxth
    2664:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    2668:      	ldrb	w8, [x23, #0xf]
    266c:      	mov	w9, #0x70               // =112
    2670:      	add	x10, sp, #0x70
    2674:      	add	x0, sp, #0x70
    2678:      	mov	w1, #0x8                // =8
    267c:      	add	x2, x29, x8
    2680:      	mov	w8, #0x8                // =8
    2684:      	blr	x9
    2688:      	cbnz	x0, 0x272c <perf_unwind_v8+0x272c>
    268c:      	ldr	x8, [sp, #0x70]
    2690:      	and	x9, x8, #0x3
    2694:      	cmp	x9, #0x1
    2698:      	b.ne	0x272c <perf_unwind_v8+0x272c>
    269c:      	and	x8, x8, #0xfffffffffffffffc
    26a0:      	str	x8, [sp, #0x40]
    26a4:      	cbz	x8, 0x2a6c <perf_unwind_v8+0x2a6c>
    26a8:      	ldrb	w8, [x23, #0xc]
    26ac:      	ldr	x9, [sp, #0x40]
    26b0:      	add	x10, sp, #0x70
    26b4:      	add	x0, sp, #0x70
    26b8:      	mov	w1, #0x8                // =8
    26bc:      	add	x2, x9, x8
    26c0:      	mov	w8, #0x8                // =8
    26c4:      	mov	w9, #0x70               // =112
    26c8:      	blr	x9
    26cc:      	cbnz	x0, 0x2730 <perf_unwind_v8+0x2730>
    26d0:      	ldr	x8, [sp, #0x70]
    26d4:      	and	x9, x8, #0x3
    26d8:      	cmp	x9, #0x1
    26dc:      	b.ne	0x2730 <perf_unwind_v8+0x2730>
    26e0:      	and	x8, x8, #0xfffffffffffffffc
    26e4:      	cbz	x8, 0x2734 <perf_unwind_v8+0x2734>
    26e8:      	ldrb	w9, [x23, #0xd]
    26ec:      	mov	w10, #0x2               // =2
    26f0:      	mov	w11, #0x70              // =112
    26f4:      	add	x12, sp, #0x70
    26f8:      	add	x0, sp, #0x70
    26fc:      	mov	w1, #0x2                // =2
    2700:      	add	x9, x8, x9
    2704:      	ldrb	w9, [x23, #0xd]
    2708:      	add	x2, x8, x9
    270c:      	blr	x11
    2710:      	ldrh	w8, [sp, #0x70]
    2714:      	cmp	x0, #0x0
    2718:      	csel	w8, w8, wzr, eq
    271c:      	ldrh	w9, [x23, #0xa]
    2720:      	cmp	w9, w8, uxth
    2724:      	b.ne	0x860 <perf_unwind_v8+0x860>
    2728:      	b	0x2740 <perf_unwind_v8+0x2740>
    272c:      	str	xzr, [sp, #0x40]
    2730:      	mov	w8, wzr
    2734:      	ldrh	w9, [x23, #0xa]
    2738:      	cmp	w9, w8, uxth
    273c:      	b.ne	0x860 <perf_unwind_v8+0x860>
    2740:      	lsr	x25, x22, #32
    2744:      	cbz	x25, 0x28a0 <perf_unwind_v8+0x28a0>
    2748:      	tbnz	w22, #0x0, 0x28a0 <perf_unwind_v8+0x28a0>
    274c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2750:      	ldr	x8, [x8]
    2754:      	ldr	w8, [x8]
    2758:      	cbnz	w8, 0x2e40 <perf_unwind_v8+0x2e40>
    275c:      	ldr	x8, [sp, #0x40]
    2760:      	orr	x22, x8, #0x1
    2764:      	b	0x2ba8 <perf_unwind_v8+0x2ba8>
    2768:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    276c:      	ldr	x8, [x8]
    2770:      	ldr	w8, [x8]
    2774:      	cbnz	w8, 0x2df8 <perf_unwind_v8+0x2df8>
    2778:      	ldr	x24, [x21, #0xed0]
    277c:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    2780:      	cbnz	w8, 0x2da8 <perf_unwind_v8+0x2da8>
    2784:      	lsr	x8, x24, #56
    2788:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    278c:      	cmp	x24, #0x1, lsl #12      // =0x1000
    2790:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    2794:      	ldr	w8, [x21]
    2798:      	mov	w9, #0x60               // =96
    279c:      	adrp	x0, 0x2000 <perf_unwind_v8+0x2000>
    27a0:      	add	x1, sp, #0x58
    27a4:      	rev	w8, w8
    27a8:      	stp	w9, w8, [sp, #0x58]
    27ac:      	rev	x8, x24
    27b0:      	add	x9, sp, #0x58
    27b4:      	str	x8, [sp, #0x60]
    27b8:      	mov	w8, #0x1                // =1
    27bc:      	ldr	x0, [x0]
    27c0:      	blr	x8
    27c4:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    27c8:      	ldr	x8, [x0, #0x8]
    27cc:      	and	x9, x8, #0xffffffffffffff
    27d0:      	lsr	x29, x8, #56
    27d4:      	str	x9, [x21, #0xf10]
    27d8:      	ldr	x8, [x0]
    27dc:      	str	x8, [x21, #0xf00]
    27e0:      	sub	x8, x24, x9
    27e4:      	str	x8, [x21, #0xf08]
    27e8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    27ec:      	ldr	x8, [x8]
    27f0:      	ldr	w8, [x8]
    27f4:      	cbnz	w8, 0x2ed0 <perf_unwind_v8+0x2ed0>
    27f8:      	cmp	w29, #0x1
    27fc:      	b.ne	0x3050 <perf_unwind_v8+0x3050>
    2800:      	ldr	x8, [x21, #0xf00]
    2804:      	adrp	x0, 0x2000 <perf_unwind_v8+0x2000>
    2808:      	ldr	x25, [x21, #0xf08]
    280c:      	mov	w9, #0x1                // =1
    2810:      	add	x1, sp, #0x58
    2814:      	mov	w29, #0x1               // =1
    2818:      	str	x8, [sp, #0x58]
    281c:      	add	x8, sp, #0x58
    2820:      	ldr	x0, [x0]
    2824:      	blr	x9
    2828:      	cbz	x0, 0x2c14 <perf_unwind_v8+0x2c14>
    282c:      	ldr	x8, [x0]
    2830:      	mov	x24, x0
    2834:      	cmp	x8, x25
    2838:      	b.hi	0x2848 <perf_unwind_v8+0x2848>
    283c:      	ldr	x8, [x24, #0x8]
    2840:      	cmp	x8, x25
    2844:      	b.hs	0x2860 <perf_unwind_v8+0x2860>
    2848:      	ldr	x8, [x24, #0x10]
    284c:      	cmp	x8, x25
    2850:      	b.hi	0x2890 <perf_unwind_v8+0x2890>
    2854:      	ldr	x8, [x24, #0x18]
    2858:      	cmp	x8, x25
    285c:      	b.lo	0x2890 <perf_unwind_v8+0x2890>
    2860:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2864:      	ldr	x8, [x8]
    2868:      	ldr	w8, [x8]
    286c:      	cbnz	w8, 0x2fc0 <perf_unwind_v8+0x2fc0>
    2870:      	ldrh	w8, [x24, #0x20]
    2874:      	ldr	w9, [x21, #0x1370]
    2878:      	lsr	w8, w9, w8
    287c:      	tbz	w8, #0x0, 0x300c <perf_unwind_v8+0x300c>
    2880:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2884:      	ldr	x8, [x8]
    2888:      	ldr	w8, [x8]
    288c:      	cbnz	w8, 0x37f4 <perf_unwind_v8+0x37f4>
    2890:      	mov	w29, #0x1               // =1
    2894:      	cmp	w29, #0x7
    2898:      	b.eq	0x3058 <perf_unwind_v8+0x3058>
    289c:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    28a0:      	ldr	x8, [sp, #0x40]
    28a4:      	mov	w9, #0x70               // =112
    28a8:      	add	x10, sp, #0x70
    28ac:      	add	x0, sp, #0x70
    28b0:      	mov	w1, #0x8                // =8
    28b4:      	orr	x22, x8, #0x2
    28b8:      	ldrb	w8, [x23, #0xe]
    28bc:      	add	x2, x29, x8
    28c0:      	mov	w8, #0x8                // =8
    28c4:      	blr	x9
    28c8:      	cbnz	x0, 0x296c <perf_unwind_v8+0x296c>
    28cc:      	ldr	x8, [sp, #0x70]
    28d0:      	and	x9, x8, #0x3
    28d4:      	cmp	x9, #0x1
    28d8:      	b.ne	0x296c <perf_unwind_v8+0x296c>
    28dc:      	and	x8, x8, #0xfffffffffffffffc
    28e0:      	mov	x25, x8
    28e4:      	cbz	x8, 0x2974 <perf_unwind_v8+0x2974>
    28e8:      	ldrb	w8, [x23, #0xc]
    28ec:      	mov	w9, #0x70               // =112
    28f0:      	add	x10, sp, #0x70
    28f4:      	add	x0, sp, #0x70
    28f8:      	mov	w1, #0x8                // =8
    28fc:      	add	x2, x25, x8
    2900:      	mov	w8, #0x8                // =8
    2904:      	blr	x9
    2908:      	cbnz	x0, 0x2b38 <perf_unwind_v8+0x2b38>
    290c:      	ldr	x8, [sp, #0x70]
    2910:      	and	x9, x8, #0x3
    2914:      	cmp	x9, #0x1
    2918:      	b.ne	0x2b38 <perf_unwind_v8+0x2b38>
    291c:      	and	x8, x8, #0xfffffffffffffffc
    2920:      	cbz	x8, 0x2974 <perf_unwind_v8+0x2974>
    2924:      	ldrb	w9, [x23, #0xd]
    2928:      	mov	w10, #0x2               // =2
    292c:      	mov	w11, #0x70              // =112
    2930:      	add	x12, sp, #0x70
    2934:      	add	x0, sp, #0x70
    2938:      	mov	w1, #0x2                // =2
    293c:      	add	x9, x8, x9
    2940:      	ldrb	w9, [x23, #0xd]
    2944:      	add	x2, x8, x9
    2948:      	blr	x11
    294c:      	ldrh	w8, [sp, #0x70]
    2950:      	cmp	x0, #0x0
    2954:      	csel	w8, w8, wzr, eq
    2958:      	and	w4, w8, #0xffff
    295c:      	ldrh	w8, [x23, #0x8]
    2960:      	cmp	w4, w8
    2964:      	b.eq	0x2984 <perf_unwind_v8+0x2984>
    2968:      	b	0x2b4c <perf_unwind_v8+0x2b4c>
    296c:      	mov	x25, xzr
    2970:      	mov	w8, wzr
    2974:      	and	w4, w8, #0xffff
    2978:      	ldrh	w8, [x23, #0x8]
    297c:      	cmp	w4, w8
    2980:      	b.ne	0x2b4c <perf_unwind_v8+0x2b4c>
    2984:      	ldr	x0, [sp, #0x48]
    2988:      	mov	w8, #0x60               // =96
    298c:      	mov	w9, #0x70               // =112
    2990:      	mov	x2, x25
    2994:      	mov	w1, #0x60               // =96
    2998:      	blr	x9
    299c:      	cbz	x0, 0x2a80 <perf_unwind_v8+0x2a80>
    29a0:      	mov	w8, #0x3b               // =59
    29a4:      	adrp	x0, 0x2000 <perf_unwind_v8+0x2000>
    29a8:      	add	x9, sp, #0x58
    29ac:      	str	w8, [sp, #0x58]
    29b0:      	mov	w8, #0x1                // =1
    29b4:      	add	x1, sp, #0x58
    29b8:      	ldr	x0, [x0]
    29bc:      	blr	x8
    29c0:      	cbnz	x0, 0x2b80 <perf_unwind_v8+0x2b80>
    29c4:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    29c8:      	ldr	x8, [x8]
    29cc:      	ldr	w8, [x8]
    29d0:      	cbz	w8, 0x2ba4 <perf_unwind_v8+0x2ba4>
    29d4:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    29d8:      	add	x8, x8, #0x0
    29dc:      	add	x0, sp, #0x70
    29e0:      	ldp	x9, x10, [x8, #0x10]
    29e4:      	mov	w1, #0x2e               // =46
    29e8:      	stp	x9, x10, [sp, #0x80]
    29ec:      	ldr	x9, [x8, #0x20]
    29f0:      	add	x10, sp, #0x70
    29f4:      	str	x9, [sp, #0x90]
    29f8:      	ldur	x9, [x8, #0x26]
    29fc:      	stur	x9, [sp, #0x96]
    2a00:      	ldp	x9, x8, [x8]
    2a04:      	stp	x9, x8, [sp, #0x70]
    2a08:      	mov	w8, #0x2e               // =46
    2a0c:      	mov	w9, #0x6                // =6
    2a10:      	ldr	w2, [sp, #0x58]
    2a14:      	blr	x9
    2a18:      	b	0x2ba4 <perf_unwind_v8+0x2ba4>
    2a1c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2a20:      	add	x8, x8, #0x0
    2a24:      	add	x0, sp, #0x70
    2a28:      	ldp	x9, x10, [x8]
    2a2c:      	mov	w1, #0x1f               // =31
    2a30:      	mov	x2, x24
    2a34:      	mov	x3, x29
    2a38:      	stp	x9, x10, [sp, #0x70]
    2a3c:      	ldr	x9, [x8, #0x10]
    2a40:      	ldur	x8, [x8, #0x17]
    2a44:      	add	x10, sp, #0x70
    2a48:      	mov	x4, x25
    2a4c:      	str	x9, [sp, #0x80]
    2a50:      	stur	x8, [sp, #0x87]
    2a54:      	mov	w8, #0x1f               // =31
    2a58:      	mov	w9, #0x6                // =6
    2a5c:      	blr	x9
    2a60:      	cmp	x25, x29
    2a64:      	b.hs	0x2460 <perf_unwind_v8+0x2460>
    2a68:      	b	0x1954 <perf_unwind_v8+0x1954>
    2a6c:      	str	xzr, [sp, #0x40]
    2a70:      	ldrh	w9, [x23, #0xa]
    2a74:      	cmp	w9, w8, uxth
    2a78:      	b.ne	0x860 <perf_unwind_v8+0x860>
    2a7c:      	b	0x2740 <perf_unwind_v8+0x2740>
    2a80:      	ldrb	w8, [x23, #0x12]
    2a84:      	cmp	x8, #0x5c
    2a88:      	b.hi	0x250 <perf_unwind_v8+0x250>
    2a8c:      	ldrb	w9, [x23, #0x13]
    2a90:      	cmp	x9, #0x5c
    2a94:      	b.hi	0x250 <perf_unwind_v8+0x250>
    2a98:      	ldrb	w11, [x23, #0x10]
    2a9c:      	ldrb	w10, [x23, #0x11]
    2aa0:      	cbz	w11, 0x2c68 <perf_unwind_v8+0x2c68>
    2aa4:      	ldr	x11, [sp, #0x48]
    2aa8:      	ldr	x10, [x11, x10]
    2aac:      	b	0x2c6c <perf_unwind_v8+0x2c6c>
    2ab0:      	mov	w8, #0x656e             // =25966
    2ab4:      	add	x0, sp, #0x70
    2ab8:      	mov	w1, #0x1b               // =27
    2abc:      	movk	w8, #0xa, lsl #16
    2ac0:      	stur	w8, [sp, #0x87]
    2ac4:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2ac8:      	add	x8, x8, #0x0
    2acc:      	ldp	x9, x10, [x8]
    2ad0:      	ldr	x8, [x8, #0x10]
    2ad4:      	stp	x9, x10, [sp, #0x70]
    2ad8:      	str	x8, [sp, #0x80]
    2adc:      	mov	w8, #0x1b               // =27
    2ae0:      	mov	w9, #0x6                // =6
    2ae4:      	add	x10, sp, #0x70
    2ae8:      	blr	x9
    2aec:      	mov	w29, #0x1               // =1
    2af0:      	cmp	w29, #0x7
    2af4:      	b.eq	0x243c <perf_unwind_v8+0x243c>
    2af8:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    2afc:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2b00:      	add	x8, x8, #0x0
    2b04:      	add	x0, sp, #0x70
    2b08:      	ldp	x9, x10, [x8, #0x10]
    2b0c:      	mov	w1, #0x30               // =48
    2b10:      	stp	x9, x10, [sp, #0x80]
    2b14:      	ldp	x9, x10, [x8, #0x20]
    2b18:      	stp	x9, x10, [sp, #0x90]
    2b1c:      	ldp	x9, x8, [x8]
    2b20:      	add	x10, sp, #0x70
    2b24:      	stp	x9, x8, [sp, #0x70]
    2b28:      	mov	w8, #0x30               // =48
    2b2c:      	mov	w9, #0x6                // =6
    2b30:      	blr	x9
    2b34:      	b	0x1e28 <perf_unwind_v8+0x1e28>
    2b38:      	mov	w8, wzr
    2b3c:      	and	w4, wzr, #0xffff
    2b40:      	ldrh	w8, [x23, #0x8]
    2b44:      	cmp	w4, w8
    2b48:      	b.eq	0x2984 <perf_unwind_v8+0x2984>
    2b4c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2b50:      	ldr	x8, [x8]
    2b54:      	ldr	w8, [x8]
    2b58:      	cbnz	w8, 0x2e84 <perf_unwind_v8+0x2e84>
    2b5c:      	mov	w8, #0x3b               // =59
    2b60:      	adrp	x0, 0x2000 <perf_unwind_v8+0x2000>
    2b64:      	add	x9, sp, #0x58
    2b68:      	str	w8, [sp, #0x58]
    2b6c:      	mov	w8, #0x1                // =1
    2b70:      	add	x1, sp, #0x58
    2b74:      	ldr	x0, [x0]
    2b78:      	blr	x8
    2b7c:      	cbz	x0, 0x2b94 <perf_unwind_v8+0x2b94>
    2b80:      	ldr	x8, [x0]
    2b84:      	mov	x25, xzr
    2b88:      	add	x8, x8, #0x1
    2b8c:      	str	x8, [x0]
    2b90:      	b	0x2ba8 <perf_unwind_v8+0x2ba8>
    2b94:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2b98:      	ldr	x8, [x8]
    2b9c:      	ldr	w8, [x8]
    2ba0:      	cbnz	w8, 0x2f78 <perf_unwind_v8+0x2f78>
    2ba4:      	mov	x25, xzr
    2ba8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2bac:      	ldr	x8, [x8]
    2bb0:      	ldrb	w24, [x21, #0xf20]
    2bb4:      	ldr	w8, [x8]
    2bb8:      	cbz	w8, 0x24d4 <perf_unwind_v8+0x24d4>
    2bbc:      	mov	w8, #0x786c             // =30828
    2bc0:      	add	x0, sp, #0x70
    2bc4:      	mov	w1, #0x3c               // =60
    2bc8:      	mov	x2, x25
    2bcc:      	mov	x3, x22
    2bd0:      	movk	w8, #0xa, lsl #16
    2bd4:      	str	w8, [sp, #0xa8]
    2bd8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2bdc:      	add	x8, x8, #0x0
    2be0:      	ldp	x9, x10, [x8, #0x20]
    2be4:      	stp	x9, x10, [sp, #0x90]
    2be8:      	ldr	x9, [x8, #0x30]
    2bec:      	str	x9, [sp, #0xa0]
    2bf0:      	ldp	x9, x10, [x8]
    2bf4:      	stp	x9, x10, [sp, #0x70]
    2bf8:      	add	x10, sp, #0x70
    2bfc:      	ldp	x8, x9, [x8, #0x10]
    2c00:      	stp	x8, x9, [sp, #0x80]
    2c04:      	mov	w8, #0x3c               // =60
    2c08:      	mov	w9, #0x6                // =6
    2c0c:      	blr	x9
    2c10:      	b	0x24d4 <perf_unwind_v8+0x24d4>
    2c14:      	cmp	w29, #0x7
    2c18:      	b.eq	0x3058 <perf_unwind_v8+0x3058>
    2c1c:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    2c20:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2c24:      	add	x8, x8, #0x0
    2c28:      	add	x0, sp, #0x70
    2c2c:      	ldp	x9, x10, [x8, #0x10]
    2c30:      	mov	w1, #0x2e               // =46
    2c34:      	stp	x9, x10, [sp, #0x80]
    2c38:      	ldr	x9, [x8, #0x20]
    2c3c:      	add	x10, sp, #0x70
    2c40:      	str	x9, [sp, #0x90]
    2c44:      	ldur	x9, [x8, #0x26]
    2c48:      	stur	x9, [sp, #0x96]
    2c4c:      	ldp	x9, x8, [x8]
    2c50:      	stp	x9, x8, [sp, #0x70]
    2c54:      	mov	w8, #0x2e               // =46
    2c58:      	mov	w9, #0x6                // =6
    2c5c:      	ldr	w2, [sp, #0xbc]
    2c60:      	blr	x9
    2c64:      	b	0x2430 <perf_unwind_v8+0x2430>
    2c68:      	add	x10, x25, x10
    2c6c:      	str	x10, [sp, #0x38]
    2c70:      	ldr	x10, [sp, #0x48]
    2c74:      	ldr	w9, [x10, x9]
    2c78:      	ldr	w8, [x10, x8]
    2c7c:      	str	w9, [sp, #0x20]
    2c80:      	ldrb	w9, [x23, #0x18]
    2c84:      	str	x8, [sp, #0x28]
    2c88:      	str	w9, [sp, #0x10]
    2c8c:      	ldrb	w9, [x23, #0x17]
    2c90:      	str	x9, [sp, #0x18]
    2c94:      	ldr	x9, [sp, #0x38]
    2c98:      	add	x8, x9, x8
    2c9c:      	str	x8, [sp, #0x30]
    2ca0:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2ca4:      	ldr	x8, [x8]
    2ca8:      	ldr	w8, [x8]
    2cac:      	cbnz	w8, 0x3840 <perf_unwind_v8+0x3840>
    2cb0:      	ldr	x8, [sp, #0x38]
    2cb4:      	subs	x8, x24, x8
    2cb8:      	b.lo	0x2d00 <perf_unwind_v8+0x2d00>
    2cbc:      	ldr	x9, [sp, #0x30]
    2cc0:      	cmp	x24, x9
    2cc4:      	b.hs	0x2d00 <perf_unwind_v8+0x2d00>
    2cc8:      	ldr	w9, [sp, #0x20]
    2ccc:      	ldr	w10, [sp, #0x10]
    2cd0:      	orr	x11, x29, #0x4
    2cd4:      	orr	x12, x25, #0x3
    2cd8:      	and	w9, w9, w10
    2cdc:      	ldr	x10, [sp, #0x18]
    2ce0:      	lsr	w9, w9, w10
    2ce4:      	ldrb	w10, [x23, #0x19]
    2ce8:      	cmp	w9, w10
    2cec:      	ldr	x10, [sp, #0x28]
    2cf0:      	csel	x22, x11, x12, eq
    2cf4:      	orr	w9, w9, w10, lsl #4
    2cf8:      	orr	x25, x8, x9, lsl #32
    2cfc:      	b	0x2ba8 <perf_unwind_v8+0x2ba8>
    2d00:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2d04:      	ldr	x8, [x8]
    2d08:      	ldr	w8, [x8]
    2d0c:      	cbnz	w8, 0x38dc <perf_unwind_v8+0x38dc>
    2d10:      	ldrb	w24, [x21, #0xf20]
    2d14:      	mov	x25, xzr
    2d18:      	b	0x24d4 <perf_unwind_v8+0x24d4>
    2d1c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2d20:      	add	x8, x8, #0x0
    2d24:      	add	x0, sp, #0x70
    2d28:      	ldp	x9, x10, [x8]
    2d2c:      	mov	w1, #0x1d               // =29
    2d30:      	mov	x2, x25
    2d34:      	stp	x9, x10, [sp, #0x70]
    2d38:      	ldr	x9, [x8, #0x10]
    2d3c:      	ldur	x8, [x8, #0x15]
    2d40:      	add	x10, sp, #0x70
    2d44:      	str	x9, [sp, #0x80]
    2d48:      	stur	x8, [sp, #0x85]
    2d4c:      	mov	w8, #0x1d               // =29
    2d50:      	mov	w9, #0x6                // =6
    2d54:      	blr	x9
    2d58:      	mov	x22, xzr
    2d5c:      	b	0x2ba8 <perf_unwind_v8+0x2ba8>
    2d60:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2d64:      	add	x8, x8, #0x0
    2d68:      	add	x0, sp, #0x70
    2d6c:      	ldp	x9, x10, [x8]
    2d70:      	mov	w1, #0x1f               // =31
    2d74:      	stp	x9, x10, [sp, #0x70]
    2d78:      	ldr	x9, [x8, #0x10]
    2d7c:      	ldur	x8, [x8, #0x17]
    2d80:      	add	x10, sp, #0x70
    2d84:      	str	x9, [sp, #0x80]
    2d88:      	stur	x8, [sp, #0x87]
    2d8c:      	mov	w8, #0x1f               // =31
    2d90:      	mov	w9, #0x6                // =6
    2d94:      	ldr	x2, [x21, #0xed0]
    2d98:      	ldr	x3, [x21, #0xed8]
    2d9c:      	ldr	x4, [x21, #0xee0]
    2da0:      	blr	x9
    2da4:      	b	0x2578 <perf_unwind_v8+0x2578>
    2da8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2dac:      	add	x8, x8, #0x0
    2db0:      	strb	wzr, [sp, #0xa0]
    2db4:      	add	x0, sp, #0x70
    2db8:      	ldp	x9, x10, [x8, #0x10]
    2dbc:      	mov	w1, #0x31               // =49
    2dc0:      	stp	x9, x10, [sp, #0x80]
    2dc4:      	ldp	x9, x10, [x8, #0x20]
    2dc8:      	stp	x9, x10, [sp, #0x90]
    2dcc:      	ldp	x9, x8, [x8]
    2dd0:      	add	x10, sp, #0x70
    2dd4:      	stp	x9, x8, [sp, #0x70]
    2dd8:      	mov	w8, #0x31               // =49
    2ddc:      	mov	w9, #0x6                // =6
    2de0:      	ldr	w2, [x21, #0x2c0]
    2de4:      	blr	x9
    2de8:      	ldr	x24, [x21, #0xed0]
    2dec:      	lsr	x8, x24, #56
    2df0:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    2df4:      	b	0x278c <perf_unwind_v8+0x278c>
    2df8:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2dfc:      	add	x8, x8, #0x0
    2e00:      	add	x0, sp, #0x70
    2e04:      	ldp	x9, x10, [x8, #0x10]
    2e08:      	mov	w1, #0x2e               // =46
    2e0c:      	stp	x9, x10, [sp, #0x80]
    2e10:      	ldr	x9, [x8, #0x20]
    2e14:      	add	x10, sp, #0x70
    2e18:      	str	x9, [sp, #0x90]
    2e1c:      	ldur	x9, [x8, #0x26]
    2e20:      	stur	x9, [sp, #0x96]
    2e24:      	ldp	x9, x8, [x8]
    2e28:      	stp	x9, x8, [sp, #0x70]
    2e2c:      	mov	w8, #0x2e               // =46
    2e30:      	mov	w9, #0x6                // =6
    2e34:      	ldr	w2, [sp, #0x58]
    2e38:      	blr	x9
    2e3c:      	b	0x25a8 <perf_unwind_v8+0x25a8>
    2e40:      	mov	w8, #0x786c             // =30828
    2e44:      	add	x0, sp, #0x70
    2e48:      	mov	w1, #0x1c               // =28
    2e4c:      	mov	x2, x25
    2e50:      	movk	w8, #0xa, lsl #16
    2e54:      	str	w8, [sp, #0x88]
    2e58:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2e5c:      	add	x8, x8, #0x0
    2e60:      	ldp	x9, x10, [x8]
    2e64:      	ldr	x8, [x8, #0x10]
    2e68:      	stp	x9, x10, [sp, #0x70]
    2e6c:      	mov	w9, #0x6                // =6
    2e70:      	str	x8, [sp, #0x80]
    2e74:      	mov	w8, #0x1c               // =28
    2e78:      	add	x10, sp, #0x70
    2e7c:      	blr	x9
    2e80:      	b	0x275c <perf_unwind_v8+0x275c>
    2e84:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2e88:      	add	x8, x8, #0x0
    2e8c:      	add	x0, sp, #0x70
    2e90:      	ldp	x9, x10, [x8, #0x10]
    2e94:      	mov	w1, #0x2e               // =46
    2e98:      	mov	x2, x29
    2e9c:      	mov	x3, x25
    2ea0:      	stp	x9, x10, [sp, #0x80]
    2ea4:      	ldr	x9, [x8, #0x20]
    2ea8:      	add	x10, sp, #0x70
    2eac:      	str	x9, [sp, #0x90]
    2eb0:      	ldur	x9, [x8, #0x26]
    2eb4:      	stur	x9, [sp, #0x96]
    2eb8:      	ldp	x9, x8, [x8]
    2ebc:      	stp	x9, x8, [sp, #0x70]
    2ec0:      	mov	w8, #0x2e               // =46
    2ec4:      	mov	w9, #0x6                // =6
    2ec8:      	blr	x9
    2ecc:      	b	0x2b5c <perf_unwind_v8+0x2b5c>
    2ed0:      	mov	w8, #0xa                // =10
    2ed4:      	add	x0, sp, #0x70
    2ed8:      	mov	w1, #0x32               // =50
    2edc:      	strh	w8, [sp, #0xa0]
    2ee0:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2ee4:      	add	x8, x8, #0x0
    2ee8:      	mov	x2, x24
    2eec:      	ldp	x9, x10, [x8, #0x10]
    2ef0:      	mov	w4, w29
    2ef4:      	stp	x9, x10, [sp, #0x80]
    2ef8:      	ldp	x9, x10, [x8, #0x20]
    2efc:      	stp	x9, x10, [sp, #0x90]
    2f00:      	ldp	x9, x8, [x8]
    2f04:      	add	x10, sp, #0x70
    2f08:      	stp	x9, x8, [sp, #0x70]
    2f0c:      	mov	w8, #0x32               // =50
    2f10:      	mov	w9, #0x6                // =6
    2f14:      	ldr	x3, [x21, #0xf00]
    2f18:      	blr	x9
    2f1c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2f20:      	ldr	x8, [x8]
    2f24:      	ldr	w8, [x8]
    2f28:      	cbz	w8, 0x27f8 <perf_unwind_v8+0x27f8>
    2f2c:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2f30:      	add	x8, x8, #0x0
    2f34:      	add	x0, sp, #0x70
    2f38:      	ldp	x9, x10, [x8, #0x10]
    2f3c:      	mov	w1, #0x2f               // =47
    2f40:      	stp	x9, x10, [sp, #0x80]
    2f44:      	ldr	x9, [x8, #0x20]
    2f48:      	add	x10, sp, #0x70
    2f4c:      	str	x9, [sp, #0x90]
    2f50:      	ldur	x9, [x8, #0x27]
    2f54:      	stur	x9, [sp, #0x97]
    2f58:      	ldp	x9, x8, [x8]
    2f5c:      	stp	x9, x8, [sp, #0x70]
    2f60:      	mov	w8, #0x2f               // =47
    2f64:      	mov	w9, #0x6                // =6
    2f68:      	ldr	x2, [x21, #0xf10]
    2f6c:      	ldr	x3, [x21, #0xf08]
    2f70:      	blr	x9
    2f74:      	b	0x27f8 <perf_unwind_v8+0x27f8>
    2f78:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2f7c:      	add	x8, x8, #0x0
    2f80:      	add	x0, sp, #0x70
    2f84:      	ldp	x9, x10, [x8, #0x10]
    2f88:      	mov	w1, #0x2e               // =46
    2f8c:      	stp	x9, x10, [sp, #0x80]
    2f90:      	ldr	x9, [x8, #0x20]
    2f94:      	add	x10, sp, #0x70
    2f98:      	str	x9, [sp, #0x90]
    2f9c:      	ldur	x9, [x8, #0x26]
    2fa0:      	stur	x9, [sp, #0x96]
    2fa4:      	ldp	x9, x8, [x8]
    2fa8:      	stp	x9, x8, [sp, #0x70]
    2fac:      	mov	w8, #0x2e               // =46
    2fb0:      	mov	w9, #0x6                // =6
    2fb4:      	ldr	w2, [sp, #0x58]
    2fb8:      	blr	x9
    2fbc:      	b	0x2ba4 <perf_unwind_v8+0x2ba4>
    2fc0:      	adrp	x8, 0x2000 <perf_unwind_v8+0x2000>
    2fc4:      	add	x8, x8, #0x0
    2fc8:      	add	x0, sp, #0x70
    2fcc:      	ldp	x9, x10, [x8]
    2fd0:      	mov	w1, #0x1e               // =30
    2fd4:      	stp	x9, x10, [sp, #0x70]
    2fd8:      	ldr	x9, [x8, #0x10]
    2fdc:      	ldur	x8, [x8, #0x16]
    2fe0:      	add	x10, sp, #0x70
    2fe4:      	str	x9, [sp, #0x80]
    2fe8:      	stur	x8, [sp, #0x86]
    2fec:      	mov	w8, #0x1e               // =30
    2ff0:      	mov	w9, #0x6                // =6
    2ff4:      	ldrh	w2, [x24, #0x20]
    2ff8:      	blr	x9
    2ffc:      	ldrh	w8, [x24, #0x20]
    3000:      	ldr	w9, [x21, #0x1370]
    3004:      	lsr	w8, w9, w8
    3008:      	tbnz	w8, #0x0, 0x2880 <perf_unwind_v8+0x2880>
    300c:      	str	wzr, [sp, #0xbc]
    3010:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    3014:      	mov	w8, #0x1                // =1
    3018:      	add	x9, sp, #0xbc
    301c:      	ldr	x0, [x0]
    3020:      	add	x1, sp, #0xbc
    3024:      	blr	x8
    3028:      	cbz	x0, 0x303c <perf_unwind_v8+0x303c>
    302c:      	ldr	x8, [x0]
    3030:      	add	x8, x8, #0x1
    3034:      	str	x8, [x0]
    3038:      	b	0x304c <perf_unwind_v8+0x304c>
    303c:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3040:      	ldr	x8, [x8]
    3044:      	ldr	w8, [x8]
    3048:      	cbnz	w8, 0x3918 <perf_unwind_v8+0x3918>
    304c:      	ldrh	w29, [x24, #0x20]
    3050:      	cmp	w29, #0x7
    3054:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    3058:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    305c:      	ldr	x29, [x21, #0xed8]
    3060:      	ldr	x25, [x21, #0xee0]
    3064:      	ldr	x24, [x21, #0xed0]
    3068:      	ldr	x8, [x8]
    306c:      	ldr	w8, [x8]
    3070:      	cbnz	w8, 0x3670 <perf_unwind_v8+0x3670>
    3074:      	cmp	x25, x29
    3078:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    307c:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    3080:      	cmp	x25, x8
    3084:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    3088:      	ldr	x0, [sp, #0x50]
    308c:      	sub	x2, x25, #0x40
    3090:      	mov	w8, #0x40               // =64
    3094:      	mov	w9, #0x70               // =112
    3098:      	mov	w1, #0x40               // =64
    309c:      	blr	x9
    30a0:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    30a4:      	ldrb	w9, [x23, #0x14]
    30a8:      	cmp	x9, #0x38
    30ac:      	b.hi	0x250 <perf_unwind_v8+0x250>
    30b0:      	ldrb	w8, [x23, #0x15]
    30b4:      	cmp	x8, #0x38
    30b8:      	b.hi	0x250 <perf_unwind_v8+0x250>
    30bc:      	ldrb	w10, [x23, #0x16]
    30c0:      	cmp	x10, #0x38
    30c4:      	b.hi	0x250 <perf_unwind_v8+0x250>
    30c8:      	ldr	x11, [sp, #0x50]
    30cc:      	ldr	x9, [x11, x9]
    30d0:      	tbnz	w9, #0x0, 0x31d4 <perf_unwind_v8+0x31d4>
    30d4:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    30d8:      	lsr	x25, x9, #1
    30dc:      	ldr	x8, [x8]
    30e0:      	ldr	w8, [x8]
    30e4:      	cbnz	w8, 0x3960 <perf_unwind_v8+0x3960>
    30e8:      	ldrb	w24, [x21, #0xf20]
    30ec:      	mov	x22, xzr
    30f0:      	ldr	w8, [x21, #0x2c0]
    30f4:      	cmp	w8, #0x7e
    30f8:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    30fc:      	add	w9, w8, #0x1
    3100:      	mov	w10, #0x8               // =8
    3104:      	add	x11, sp, #0x70
    3108:      	str	w9, [x21, #0x2c0]
    310c:      	mov	w9, #0x18               // =24
    3110:      	add	x0, sp, #0x70
    3114:      	mov	w1, #0x10               // =16
    3118:      	umaddl	x8, w8, w9, x21
    311c:      	add	x9, x8, #0x2d0
    3120:      	str	x22, [x8, #0x2d0]
    3124:      	str	x25, [x8, #0x2d8]
    3128:      	strb	w10, [x8, #0x2e0]
    312c:      	strb	w24, [x8, #0x2e1]
    3130:      	strh	wzr, [x8, #0x2e6]
    3134:      	mov	w10, #0x70              // =112
    3138:      	stur	wzr, [x9, #0x12]
    313c:      	mov	w9, #0x10               // =16
    3140:      	ldr	x8, [x21, #0xee0]
    3144:      	ldr	x2, [x21, #0xee0]
    3148:      	blr	x10
    314c:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    3150:      	ldr	x8, [x21, #0xee0]
    3154:      	add	x9, x8, #0x10
    3158:      	str	x9, [x21, #0xed8]
    315c:      	ldp	x9, x10, [sp, #0x70]
    3160:      	str	x9, [x21, #0xee0]
    3164:      	mov	w9, #0x101              // =257
    3168:      	str	x10, [x21, #0xed0]
    316c:      	strh	w9, [x21, #0xf20]
    3170:      	cbnz	x22, 0x3184 <perf_unwind_v8+0x3184>
    3174:      	cmp	x25, #0x1
    3178:      	b.ne	0x3184 <perf_unwind_v8+0x3184>
    317c:      	add	x8, x8, #0xa0
    3180:      	str	x8, [x21, #0xed8]
    3184:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3188:      	ldr	x8, [x8]
    318c:      	ldr	w8, [x8]
    3190:      	cbnz	w8, 0x39a4 <perf_unwind_v8+0x39a4>
    3194:      	mov	w8, #0x38               // =56
    3198:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    319c:      	add	x9, sp, #0x58
    31a0:      	str	w8, [sp, #0x58]
    31a4:      	mov	w8, #0x1                // =1
    31a8:      	add	x1, sp, #0x58
    31ac:      	ldr	x0, [x0]
    31b0:      	blr	x8
    31b4:      	cbz	x0, 0x3384 <perf_unwind_v8+0x3384>
    31b8:      	ldr	x8, [x0]
    31bc:      	add	x8, x8, #0x1
    31c0:      	str	x8, [x0]
    31c4:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    31c8:      	ldr	x8, [x8]
    31cc:      	ldr	w8, [x8]
    31d0:      	b	0x3394 <perf_unwind_v8+0x3394>
    31d4:      	ldr	x9, [sp, #0x50]
    31d8:      	ldr	x8, [x9, x8]
    31dc:      	ldr	x22, [x9, x10]
    31e0:      	and	x9, x8, #0x3
    31e4:      	and	x8, x8, #0xfffffffffffffffc
    31e8:      	cmp	x9, #0x1
    31ec:      	csel	x29, x8, xzr, eq
    31f0:      	cbz	x29, 0x3268 <perf_unwind_v8+0x3268>
    31f4:      	ldrb	w8, [x23, #0xc]
    31f8:      	mov	w9, #0x70               // =112
    31fc:      	add	x10, sp, #0x70
    3200:      	add	x0, sp, #0x70
    3204:      	mov	w1, #0x8                // =8
    3208:      	add	x2, x29, x8
    320c:      	mov	w8, #0x8                // =8
    3210:      	blr	x9
    3214:      	cbnz	x0, 0x3268 <perf_unwind_v8+0x3268>
    3218:      	ldr	x8, [sp, #0x70]
    321c:      	and	x9, x8, #0x3
    3220:      	cmp	x9, #0x1
    3224:      	b.ne	0x3268 <perf_unwind_v8+0x3268>
    3228:      	and	x8, x8, #0xfffffffffffffffc
    322c:      	cbz	x8, 0x326c <perf_unwind_v8+0x326c>
    3230:      	ldrb	w9, [x23, #0xd]
    3234:      	mov	w10, #0x2               // =2
    3238:      	mov	w11, #0x70              // =112
    323c:      	add	x12, sp, #0x70
    3240:      	add	x0, sp, #0x70
    3244:      	mov	w1, #0x2                // =2
    3248:      	add	x9, x8, x9
    324c:      	ldrb	w9, [x23, #0xd]
    3250:      	add	x2, x8, x9
    3254:      	blr	x11
    3258:      	ldrh	w8, [sp, #0x70]
    325c:      	cmp	x0, #0x0
    3260:      	csel	w8, w8, wzr, eq
    3264:      	b	0x326c <perf_unwind_v8+0x326c>
    3268:      	mov	w8, wzr
    326c:      	ldrh	w9, [x23, #0x4]
    3270:      	cmp	w9, w8, uxth
    3274:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    3278:      	ldrh	w9, [x23, #0x6]
    327c:      	cmp	w9, w8, uxth
    3280:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    3284:      	ldrb	w8, [x23, #0xf]
    3288:      	mov	w9, #0x70               // =112
    328c:      	add	x10, sp, #0x70
    3290:      	add	x0, sp, #0x70
    3294:      	mov	w1, #0x8                // =8
    3298:      	add	x2, x29, x8
    329c:      	mov	w8, #0x8                // =8
    32a0:      	blr	x9
    32a4:      	cbnz	x0, 0x3348 <perf_unwind_v8+0x3348>
    32a8:      	ldr	x8, [sp, #0x70]
    32ac:      	and	x9, x8, #0x3
    32b0:      	cmp	x9, #0x1
    32b4:      	b.ne	0x3348 <perf_unwind_v8+0x3348>
    32b8:      	and	x8, x8, #0xfffffffffffffffc
    32bc:      	str	x8, [sp, #0x40]
    32c0:      	cbz	x8, 0x37e0 <perf_unwind_v8+0x37e0>
    32c4:      	ldrb	w8, [x23, #0xc]
    32c8:      	ldr	x9, [sp, #0x40]
    32cc:      	add	x10, sp, #0x70
    32d0:      	add	x0, sp, #0x70
    32d4:      	mov	w1, #0x8                // =8
    32d8:      	add	x2, x9, x8
    32dc:      	mov	w8, #0x8                // =8
    32e0:      	mov	w9, #0x70               // =112
    32e4:      	blr	x9
    32e8:      	cbnz	x0, 0x334c <perf_unwind_v8+0x334c>
    32ec:      	ldr	x8, [sp, #0x70]
    32f0:      	and	x9, x8, #0x3
    32f4:      	cmp	x9, #0x1
    32f8:      	b.ne	0x334c <perf_unwind_v8+0x334c>
    32fc:      	and	x8, x8, #0xfffffffffffffffc
    3300:      	cbz	x8, 0x3350 <perf_unwind_v8+0x3350>
    3304:      	ldrb	w9, [x23, #0xd]
    3308:      	mov	w10, #0x2               // =2
    330c:      	mov	w11, #0x70              // =112
    3310:      	add	x12, sp, #0x70
    3314:      	add	x0, sp, #0x70
    3318:      	mov	w1, #0x2                // =2
    331c:      	add	x9, x8, x9
    3320:      	ldrb	w9, [x23, #0xd]
    3324:      	add	x2, x8, x9
    3328:      	blr	x11
    332c:      	ldrh	w8, [sp, #0x70]
    3330:      	cmp	x0, #0x0
    3334:      	csel	w8, w8, wzr, eq
    3338:      	ldrh	w9, [x23, #0xa]
    333c:      	cmp	w9, w8, uxth
    3340:      	b.ne	0x860 <perf_unwind_v8+0x860>
    3344:      	b	0x335c <perf_unwind_v8+0x335c>
    3348:      	str	xzr, [sp, #0x40]
    334c:      	mov	w8, wzr
    3350:      	ldrh	w9, [x23, #0xa]
    3354:      	cmp	w9, w8, uxth
    3358:      	b.ne	0x860 <perf_unwind_v8+0x860>
    335c:      	lsr	x25, x22, #32
    3360:      	cbz	x25, 0x3594 <perf_unwind_v8+0x3594>
    3364:      	tbnz	w22, #0x0, 0x3594 <perf_unwind_v8+0x3594>
    3368:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    336c:      	ldr	x8, [x8]
    3370:      	ldr	w8, [x8]
    3374:      	cbnz	w8, 0x39ec <perf_unwind_v8+0x39ec>
    3378:      	ldr	x8, [sp, #0x40]
    337c:      	orr	x22, x8, #0x1
    3380:      	b	0x4048 <perf_unwind_v8+0x4048>
    3384:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3388:      	ldr	x8, [x8]
    338c:      	ldr	w8, [x8]
    3390:      	cbnz	w8, 0x3a30 <perf_unwind_v8+0x3a30>
    3394:      	ldr	x24, [x21, #0xed0]
    3398:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    339c:      	cbnz	w8, 0x3a78 <perf_unwind_v8+0x3a78>
    33a0:      	lsr	x8, x24, #56
    33a4:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    33a8:      	cmp	x24, #0x1, lsl #12      // =0x1000
    33ac:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    33b0:      	ldr	w8, [x21]
    33b4:      	mov	w9, #0x60               // =96
    33b8:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    33bc:      	add	x1, sp, #0x58
    33c0:      	rev	w8, w8
    33c4:      	stp	w9, w8, [sp, #0x58]
    33c8:      	rev	x8, x24
    33cc:      	add	x9, sp, #0x58
    33d0:      	str	x8, [sp, #0x60]
    33d4:      	mov	w8, #0x1                // =1
    33d8:      	ldr	x0, [x0]
    33dc:      	blr	x8
    33e0:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    33e4:      	ldr	x8, [x0, #0x8]
    33e8:      	and	x9, x8, #0xffffffffffffff
    33ec:      	lsr	x29, x8, #56
    33f0:      	str	x9, [x21, #0xf10]
    33f4:      	ldr	x8, [x0]
    33f8:      	str	x8, [x21, #0xf00]
    33fc:      	sub	x8, x24, x9
    3400:      	str	x8, [x21, #0xf08]
    3404:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3408:      	ldr	x8, [x8]
    340c:      	ldr	w8, [x8]
    3410:      	cbz	w8, 0x34b8 <perf_unwind_v8+0x34b8>
    3414:      	mov	w8, #0xa                // =10
    3418:      	add	x0, sp, #0x70
    341c:      	mov	w1, #0x32               // =50
    3420:      	strh	w8, [sp, #0xa0]
    3424:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3428:      	add	x8, x8, #0x0
    342c:      	mov	x2, x24
    3430:      	ldp	x9, x10, [x8, #0x10]
    3434:      	mov	w4, w29
    3438:      	stp	x9, x10, [sp, #0x80]
    343c:      	ldp	x9, x10, [x8, #0x20]
    3440:      	stp	x9, x10, [sp, #0x90]
    3444:      	ldp	x9, x8, [x8]
    3448:      	add	x10, sp, #0x70
    344c:      	stp	x9, x8, [sp, #0x70]
    3450:      	mov	w8, #0x32               // =50
    3454:      	mov	w9, #0x6                // =6
    3458:      	ldr	x3, [x21, #0xf00]
    345c:      	blr	x9
    3460:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3464:      	ldr	x8, [x8]
    3468:      	ldr	w8, [x8]
    346c:      	cbz	w8, 0x34b8 <perf_unwind_v8+0x34b8>
    3470:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3474:      	add	x8, x8, #0x0
    3478:      	add	x0, sp, #0x70
    347c:      	ldp	x9, x10, [x8, #0x10]
    3480:      	mov	w1, #0x2f               // =47
    3484:      	stp	x9, x10, [sp, #0x80]
    3488:      	ldr	x9, [x8, #0x20]
    348c:      	add	x10, sp, #0x70
    3490:      	str	x9, [sp, #0x90]
    3494:      	ldur	x9, [x8, #0x27]
    3498:      	stur	x9, [sp, #0x97]
    349c:      	ldp	x9, x8, [x8]
    34a0:      	stp	x9, x8, [sp, #0x70]
    34a4:      	mov	w8, #0x2f               // =47
    34a8:      	mov	w9, #0x6                // =6
    34ac:      	ldr	x2, [x21, #0xf10]
    34b0:      	ldr	x3, [x21, #0xf08]
    34b4:      	blr	x9
    34b8:      	cmp	w29, #0x1
    34bc:      	b.ne	0x3c20 <perf_unwind_v8+0x3c20>
    34c0:      	ldr	x8, [x21, #0xf00]
    34c4:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    34c8:      	ldr	x25, [x21, #0xf08]
    34cc:      	mov	w9, #0x1                // =1
    34d0:      	add	x1, sp, #0x58
    34d4:      	mov	w29, #0x1               // =1
    34d8:      	str	x8, [sp, #0x58]
    34dc:      	add	x8, sp, #0x58
    34e0:      	ldr	x0, [x0]
    34e4:      	blr	x9
    34e8:      	cbz	x0, 0x3ac8 <perf_unwind_v8+0x3ac8>
    34ec:      	ldr	x8, [x0]
    34f0:      	mov	x24, x0
    34f4:      	cmp	x8, x25
    34f8:      	b.hi	0x3508 <perf_unwind_v8+0x3508>
    34fc:      	ldr	x8, [x24, #0x8]
    3500:      	cmp	x8, x25
    3504:      	b.hs	0x3520 <perf_unwind_v8+0x3520>
    3508:      	ldr	x8, [x24, #0x10]
    350c:      	cmp	x8, x25
    3510:      	b.hi	0x358c <perf_unwind_v8+0x358c>
    3514:      	ldr	x8, [x24, #0x18]
    3518:      	cmp	x8, x25
    351c:      	b.lo	0x358c <perf_unwind_v8+0x358c>
    3520:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3524:      	ldr	x8, [x8]
    3528:      	ldr	w8, [x8]
    352c:      	cbz	w8, 0x356c <perf_unwind_v8+0x356c>
    3530:      	adrp	x10, 0x3000 <perf_unwind_v8+0x3000>
    3534:      	add	x10, x10, #0x0
    3538:      	add	x0, sp, #0x70
    353c:      	ldp	x8, x9, [x10]
    3540:      	mov	w1, #0x1e               // =30
    3544:      	stp	x8, x9, [sp, #0x70]
    3548:      	ldr	x8, [x10, #0x10]
    354c:      	mov	w9, #0x6                // =6
    3550:      	str	x8, [sp, #0x80]
    3554:      	ldur	x8, [x10, #0x16]
    3558:      	add	x10, sp, #0x70
    355c:      	stur	x8, [sp, #0x86]
    3560:      	mov	w8, #0x1e               // =30
    3564:      	ldrh	w2, [x24, #0x20]
    3568:      	blr	x9
    356c:      	ldrh	w8, [x24, #0x20]
    3570:      	ldr	w9, [x21, #0x1370]
    3574:      	lsr	w8, w9, w8
    3578:      	tbz	w8, #0x0, 0x3acc <perf_unwind_v8+0x3acc>
    357c:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3580:      	ldr	x8, [x8]
    3584:      	ldr	w8, [x8]
    3588:      	cbnz	w8, 0x3afc <perf_unwind_v8+0x3afc>
    358c:      	mov	w29, #0x1               // =1
    3590:      	b	0x3c20 <perf_unwind_v8+0x3c20>
    3594:      	ldr	x8, [sp, #0x40]
    3598:      	mov	w9, #0x70               // =112
    359c:      	add	x10, sp, #0x70
    35a0:      	add	x0, sp, #0x70
    35a4:      	mov	w1, #0x8                // =8
    35a8:      	orr	x22, x8, #0x2
    35ac:      	ldrb	w8, [x23, #0xe]
    35b0:      	add	x2, x29, x8
    35b4:      	mov	w8, #0x8                // =8
    35b8:      	blr	x9
    35bc:      	cbz	x0, 0x3750 <perf_unwind_v8+0x3750>
    35c0:      	mov	x25, xzr
    35c4:      	mov	w8, wzr
    35c8:      	and	w4, w8, #0xffff
    35cc:      	ldrh	w8, [x23, #0x8]
    35d0:      	cmp	w4, w8
    35d4:      	b.ne	0x36c0 <perf_unwind_v8+0x36c0>
    35d8:      	ldr	x0, [sp, #0x48]
    35dc:      	mov	w8, #0x60               // =96
    35e0:      	mov	w9, #0x70               // =112
    35e4:      	mov	x2, x25
    35e8:      	mov	w1, #0x60               // =96
    35ec:      	blr	x9
    35f0:      	cbz	x0, 0x3b40 <perf_unwind_v8+0x3b40>
    35f4:      	mov	w8, #0x3b               // =59
    35f8:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    35fc:      	add	x9, sp, #0x58
    3600:      	str	w8, [sp, #0x58]
    3604:      	mov	w8, #0x1                // =1
    3608:      	add	x1, sp, #0x58
    360c:      	ldr	x0, [x0]
    3610:      	blr	x8
    3614:      	cbnz	x0, 0x373c <perf_unwind_v8+0x373c>
    3618:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    361c:      	ldr	x8, [x8]
    3620:      	ldr	w8, [x8]
    3624:      	cbz	w8, 0x4044 <perf_unwind_v8+0x4044>
    3628:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    362c:      	add	x8, x8, #0x0
    3630:      	add	x0, sp, #0x70
    3634:      	ldp	x9, x10, [x8, #0x10]
    3638:      	mov	w1, #0x2e               // =46
    363c:      	stp	x9, x10, [sp, #0x80]
    3640:      	ldr	x9, [x8, #0x20]
    3644:      	add	x10, sp, #0x70
    3648:      	str	x9, [sp, #0x90]
    364c:      	ldur	x9, [x8, #0x26]
    3650:      	stur	x9, [sp, #0x96]
    3654:      	ldp	x9, x8, [x8]
    3658:      	stp	x9, x8, [sp, #0x70]
    365c:      	mov	w8, #0x2e               // =46
    3660:      	mov	w9, #0x6                // =6
    3664:      	ldr	w2, [sp, #0x58]
    3668:      	blr	x9
    366c:      	b	0x4044 <perf_unwind_v8+0x4044>
    3670:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3674:      	add	x8, x8, #0x0
    3678:      	add	x0, sp, #0x70
    367c:      	ldp	x9, x10, [x8]
    3680:      	mov	w1, #0x1f               // =31
    3684:      	mov	x2, x24
    3688:      	mov	x3, x29
    368c:      	stp	x9, x10, [sp, #0x70]
    3690:      	ldr	x9, [x8, #0x10]
    3694:      	ldur	x8, [x8, #0x17]
    3698:      	add	x10, sp, #0x70
    369c:      	mov	x4, x25
    36a0:      	str	x9, [sp, #0x80]
    36a4:      	stur	x8, [sp, #0x87]
    36a8:      	mov	w8, #0x1f               // =31
    36ac:      	mov	w9, #0x6                // =6
    36b0:      	blr	x9
    36b4:      	cmp	x25, x29
    36b8:      	b.hs	0x307c <perf_unwind_v8+0x307c>
    36bc:      	b	0x1954 <perf_unwind_v8+0x1954>
    36c0:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    36c4:      	ldr	x8, [x8]
    36c8:      	ldr	w8, [x8]
    36cc:      	cbz	w8, 0x3718 <perf_unwind_v8+0x3718>
    36d0:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    36d4:      	add	x8, x8, #0x0
    36d8:      	add	x0, sp, #0x70
    36dc:      	ldp	x9, x10, [x8, #0x10]
    36e0:      	mov	w1, #0x2e               // =46
    36e4:      	mov	x2, x29
    36e8:      	mov	x3, x25
    36ec:      	stp	x9, x10, [sp, #0x80]
    36f0:      	ldr	x9, [x8, #0x20]
    36f4:      	add	x10, sp, #0x70
    36f8:      	str	x9, [sp, #0x90]
    36fc:      	ldur	x9, [x8, #0x26]
    3700:      	stur	x9, [sp, #0x96]
    3704:      	ldp	x9, x8, [x8]
    3708:      	stp	x9, x8, [sp, #0x70]
    370c:      	mov	w8, #0x2e               // =46
    3710:      	mov	w9, #0x6                // =6
    3714:      	blr	x9
    3718:      	mov	w8, #0x3b               // =59
    371c:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    3720:      	add	x9, sp, #0x58
    3724:      	str	w8, [sp, #0x58]
    3728:      	mov	w8, #0x1                // =1
    372c:      	add	x1, sp, #0x58
    3730:      	ldr	x0, [x0]
    3734:      	blr	x8
    3738:      	cbz	x0, 0x3b70 <perf_unwind_v8+0x3b70>
    373c:      	ldr	x8, [x0]
    3740:      	mov	x25, xzr
    3744:      	add	x8, x8, #0x1
    3748:      	str	x8, [x0]
    374c:      	b	0x4048 <perf_unwind_v8+0x4048>
    3750:      	ldr	x8, [sp, #0x70]
    3754:      	and	x9, x8, #0x3
    3758:      	cmp	x9, #0x1
    375c:      	b.ne	0x35c0 <perf_unwind_v8+0x35c0>
    3760:      	and	x8, x8, #0xfffffffffffffffc
    3764:      	mov	x25, x8
    3768:      	cbz	x8, 0x35c8 <perf_unwind_v8+0x35c8>
    376c:      	ldrb	w8, [x23, #0xc]
    3770:      	mov	w9, #0x70               // =112
    3774:      	add	x10, sp, #0x70
    3778:      	add	x0, sp, #0x70
    377c:      	mov	w1, #0x8                // =8
    3780:      	add	x2, x25, x8
    3784:      	mov	w8, #0x8                // =8
    3788:      	blr	x9
    378c:      	cbnz	x0, 0x35c4 <perf_unwind_v8+0x35c4>
    3790:      	ldr	x8, [sp, #0x70]
    3794:      	and	x9, x8, #0x3
    3798:      	cmp	x9, #0x1
    379c:      	b.ne	0x35c4 <perf_unwind_v8+0x35c4>
    37a0:      	and	x8, x8, #0xfffffffffffffffc
    37a4:      	cbz	x8, 0x35c8 <perf_unwind_v8+0x35c8>
    37a8:      	ldrb	w9, [x23, #0xd]
    37ac:      	mov	w10, #0x2               // =2
    37b0:      	mov	w11, #0x70              // =112
    37b4:      	add	x12, sp, #0x70
    37b8:      	add	x0, sp, #0x70
    37bc:      	mov	w1, #0x2                // =2
    37c0:      	add	x9, x8, x9
    37c4:      	ldrb	w9, [x23, #0xd]
    37c8:      	add	x2, x8, x9
    37cc:      	blr	x11
    37d0:      	ldrh	w8, [sp, #0x70]
    37d4:      	cmp	x0, #0x0
    37d8:      	csel	w8, w8, wzr, eq
    37dc:      	b	0x35c8 <perf_unwind_v8+0x35c8>
    37e0:      	str	xzr, [sp, #0x40]
    37e4:      	ldrh	w9, [x23, #0xa]
    37e8:      	cmp	w9, w8, uxth
    37ec:      	b.ne	0x860 <perf_unwind_v8+0x860>
    37f0:      	b	0x335c <perf_unwind_v8+0x335c>
    37f4:      	mov	w8, #0x656e             // =25966
    37f8:      	add	x0, sp, #0x70
    37fc:      	mov	w1, #0x1b               // =27
    3800:      	movk	w8, #0xa, lsl #16
    3804:      	stur	w8, [sp, #0x87]
    3808:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    380c:      	add	x8, x8, #0x0
    3810:      	ldp	x9, x10, [x8]
    3814:      	ldr	x8, [x8, #0x10]
    3818:      	stp	x9, x10, [sp, #0x70]
    381c:      	str	x8, [sp, #0x80]
    3820:      	mov	w8, #0x1b               // =27
    3824:      	mov	w9, #0x6                // =6
    3828:      	add	x10, sp, #0x70
    382c:      	blr	x9
    3830:      	mov	w29, #0x1               // =1
    3834:      	cmp	w29, #0x7
    3838:      	b.eq	0x3058 <perf_unwind_v8+0x3058>
    383c:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    3840:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3844:      	add	x8, x8, #0x0
    3848:      	strb	wzr, [sp, #0x98]
    384c:      	add	x0, sp, #0x70
    3850:      	ldp	x9, x10, [x8, #0x10]
    3854:      	mov	w1, #0x29               // =41
    3858:      	mov	x2, x29
    385c:      	mov	x4, x25
    3860:      	stp	x9, x10, [sp, #0x80]
    3864:      	ldr	x9, [x8, #0x20]
    3868:      	add	x10, sp, #0x70
    386c:      	str	x9, [sp, #0x90]
    3870:      	ldp	x8, x9, [x8]
    3874:      	stp	x8, x9, [sp, #0x70]
    3878:      	mov	w8, #0x29               // =41
    387c:      	mov	w9, #0x6                // =6
    3880:      	ldr	x3, [sp, #0x40]
    3884:      	blr	x9
    3888:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    388c:      	ldr	x8, [x8]
    3890:      	ldr	w8, [x8]
    3894:      	cbz	w8, 0x2cb0 <perf_unwind_v8+0x2cb0>
    3898:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    389c:      	add	x8, x8, #0x0
    38a0:      	add	x0, sp, #0x70
    38a4:      	ldp	x9, x10, [x8, #0x10]
    38a8:      	mov	w1, #0x25               // =37
    38ac:      	stp	x9, x10, [sp, #0x80]
    38b0:      	ldur	x9, [x8, #0x1d]
    38b4:      	add	x10, sp, #0x70
    38b8:      	stur	x9, [sp, #0x8d]
    38bc:      	ldp	x8, x9, [x8]
    38c0:      	stp	x8, x9, [sp, #0x70]
    38c4:      	mov	w8, #0x25               // =37
    38c8:      	mov	w9, #0x6                // =6
    38cc:      	ldp	x3, x2, [sp, #0x30]
    38d0:      	ldr	x4, [sp, #0x28]
    38d4:      	blr	x9
    38d8:      	b	0x2cb0 <perf_unwind_v8+0x2cb0>
    38dc:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    38e0:      	add	x8, x8, #0x0
    38e4:      	add	x0, sp, #0x70
    38e8:      	ldp	x9, x10, [x8, #0x10]
    38ec:      	mov	w1, #0x30               // =48
    38f0:      	stp	x9, x10, [sp, #0x80]
    38f4:      	ldp	x9, x10, [x8, #0x20]
    38f8:      	stp	x9, x10, [sp, #0x90]
    38fc:      	ldp	x9, x8, [x8]
    3900:      	add	x10, sp, #0x70
    3904:      	stp	x9, x8, [sp, #0x70]
    3908:      	mov	w8, #0x30               // =48
    390c:      	mov	w9, #0x6                // =6
    3910:      	blr	x9
    3914:      	b	0x2ba4 <perf_unwind_v8+0x2ba4>
    3918:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    391c:      	add	x8, x8, #0x0
    3920:      	add	x0, sp, #0x70
    3924:      	ldp	x9, x10, [x8, #0x10]
    3928:      	mov	w1, #0x2e               // =46
    392c:      	stp	x9, x10, [sp, #0x80]
    3930:      	ldr	x9, [x8, #0x20]
    3934:      	add	x10, sp, #0x70
    3938:      	str	x9, [sp, #0x90]
    393c:      	ldur	x9, [x8, #0x26]
    3940:      	stur	x9, [sp, #0x96]
    3944:      	ldp	x9, x8, [x8]
    3948:      	stp	x9, x8, [sp, #0x70]
    394c:      	mov	w8, #0x2e               // =46
    3950:      	mov	w9, #0x6                // =6
    3954:      	ldr	w2, [sp, #0xbc]
    3958:      	blr	x9
    395c:      	b	0x304c <perf_unwind_v8+0x304c>
    3960:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3964:      	add	x8, x8, #0x0
    3968:      	add	x0, sp, #0x70
    396c:      	ldp	x9, x10, [x8]
    3970:      	mov	w1, #0x1d               // =29
    3974:      	mov	x2, x25
    3978:      	stp	x9, x10, [sp, #0x70]
    397c:      	ldr	x9, [x8, #0x10]
    3980:      	ldur	x8, [x8, #0x15]
    3984:      	add	x10, sp, #0x70
    3988:      	str	x9, [sp, #0x80]
    398c:      	stur	x8, [sp, #0x85]
    3990:      	mov	w8, #0x1d               // =29
    3994:      	mov	w9, #0x6                // =6
    3998:      	blr	x9
    399c:      	mov	x22, xzr
    39a0:      	b	0x4048 <perf_unwind_v8+0x4048>
    39a4:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    39a8:      	add	x8, x8, #0x0
    39ac:      	add	x0, sp, #0x70
    39b0:      	ldp	x9, x10, [x8]
    39b4:      	mov	w1, #0x1f               // =31
    39b8:      	stp	x9, x10, [sp, #0x70]
    39bc:      	ldr	x9, [x8, #0x10]
    39c0:      	ldur	x8, [x8, #0x17]
    39c4:      	add	x10, sp, #0x70
    39c8:      	str	x9, [sp, #0x80]
    39cc:      	stur	x8, [sp, #0x87]
    39d0:      	mov	w8, #0x1f               // =31
    39d4:      	mov	w9, #0x6                // =6
    39d8:      	ldr	x2, [x21, #0xed0]
    39dc:      	ldr	x3, [x21, #0xed8]
    39e0:      	ldr	x4, [x21, #0xee0]
    39e4:      	blr	x9
    39e8:      	b	0x3194 <perf_unwind_v8+0x3194>
    39ec:      	mov	w8, #0x786c             // =30828
    39f0:      	add	x0, sp, #0x70
    39f4:      	mov	w1, #0x1c               // =28
    39f8:      	mov	x2, x25
    39fc:      	movk	w8, #0xa, lsl #16
    3a00:      	str	w8, [sp, #0x88]
    3a04:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3a08:      	add	x8, x8, #0x0
    3a0c:      	ldp	x9, x10, [x8]
    3a10:      	ldr	x8, [x8, #0x10]
    3a14:      	stp	x9, x10, [sp, #0x70]
    3a18:      	mov	w9, #0x6                // =6
    3a1c:      	str	x8, [sp, #0x80]
    3a20:      	mov	w8, #0x1c               // =28
    3a24:      	add	x10, sp, #0x70
    3a28:      	blr	x9
    3a2c:      	b	0x3378 <perf_unwind_v8+0x3378>
    3a30:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3a34:      	add	x8, x8, #0x0
    3a38:      	add	x0, sp, #0x70
    3a3c:      	ldp	x9, x10, [x8, #0x10]
    3a40:      	mov	w1, #0x2e               // =46
    3a44:      	stp	x9, x10, [sp, #0x80]
    3a48:      	ldr	x9, [x8, #0x20]
    3a4c:      	add	x10, sp, #0x70
    3a50:      	str	x9, [sp, #0x90]
    3a54:      	ldur	x9, [x8, #0x26]
    3a58:      	stur	x9, [sp, #0x96]
    3a5c:      	ldp	x9, x8, [x8]
    3a60:      	stp	x9, x8, [sp, #0x70]
    3a64:      	mov	w8, #0x2e               // =46
    3a68:      	mov	w9, #0x6                // =6
    3a6c:      	ldr	w2, [sp, #0x58]
    3a70:      	blr	x9
    3a74:      	b	0x31c4 <perf_unwind_v8+0x31c4>
    3a78:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3a7c:      	add	x8, x8, #0x0
    3a80:      	strb	wzr, [sp, #0xa0]
    3a84:      	add	x0, sp, #0x70
    3a88:      	ldp	x9, x10, [x8, #0x10]
    3a8c:      	mov	w1, #0x31               // =49
    3a90:      	stp	x9, x10, [sp, #0x80]
    3a94:      	ldp	x9, x10, [x8, #0x20]
    3a98:      	stp	x9, x10, [sp, #0x90]
    3a9c:      	ldp	x9, x8, [x8]
    3aa0:      	add	x10, sp, #0x70
    3aa4:      	stp	x9, x8, [sp, #0x70]
    3aa8:      	mov	w8, #0x31               // =49
    3aac:      	mov	w9, #0x6                // =6
    3ab0:      	ldr	w2, [x21, #0x2c0]
    3ab4:      	blr	x9
    3ab8:      	ldr	x24, [x21, #0xed0]
    3abc:      	lsr	x8, x24, #56
    3ac0:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    3ac4:      	b	0x33a8 <perf_unwind_v8+0x33a8>
    3ac8:      	b	0x3c20 <perf_unwind_v8+0x3c20>
    3acc:      	str	wzr, [sp, #0xbc]
    3ad0:      	adrp	x0, 0x3000 <perf_unwind_v8+0x3000>
    3ad4:      	mov	w8, #0x1                // =1
    3ad8:      	add	x9, sp, #0xbc
    3adc:      	ldr	x0, [x0]
    3ae0:      	add	x1, sp, #0xbc
    3ae4:      	blr	x8
    3ae8:      	cbz	x0, 0x3bc8 <perf_unwind_v8+0x3bc8>
    3aec:      	ldr	x8, [x0]
    3af0:      	add	x8, x8, #0x1
    3af4:      	str	x8, [x0]
    3af8:      	b	0x3c1c <perf_unwind_v8+0x3c1c>
    3afc:      	mov	w8, #0x656e             // =25966
    3b00:      	adrp	x10, 0x3000 <perf_unwind_v8+0x3000>
    3b04:      	add	x10, x10, #0x0
    3b08:      	add	x0, sp, #0x70
    3b0c:      	mov	w1, #0x1b               // =27
    3b10:      	movk	w8, #0xa, lsl #16
    3b14:      	stur	w8, [sp, #0x87]
    3b18:      	ldp	x8, x9, [x10]
    3b1c:      	stp	x8, x9, [sp, #0x70]
    3b20:      	ldr	x8, [x10, #0x10]
    3b24:      	mov	w9, #0x6                // =6
    3b28:      	add	x10, sp, #0x70
    3b2c:      	str	x8, [sp, #0x80]
    3b30:      	mov	w8, #0x1b               // =27
    3b34:      	blr	x9
    3b38:      	mov	w29, #0x1               // =1
    3b3c:      	b	0x3c20 <perf_unwind_v8+0x3c20>
    3b40:      	ldrb	w8, [x23, #0x12]
    3b44:      	cmp	x8, #0x5c
    3b48:      	b.hi	0x250 <perf_unwind_v8+0x250>
    3b4c:      	ldrb	w9, [x23, #0x13]
    3b50:      	cmp	x9, #0x5c
    3b54:      	b.hi	0x250 <perf_unwind_v8+0x250>
    3b58:      	ldrb	w11, [x23, #0x10]
    3b5c:      	ldrb	w10, [x23, #0x11]
    3b60:      	cbz	w11, 0x3d0c <perf_unwind_v8+0x3d0c>
    3b64:      	ldr	x11, [sp, #0x48]
    3b68:      	ldr	x10, [x11, x10]
    3b6c:      	b	0x3d10 <perf_unwind_v8+0x3d10>
    3b70:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3b74:      	ldr	x8, [x8]
    3b78:      	ldr	w8, [x8]
    3b7c:      	cbz	w8, 0x4044 <perf_unwind_v8+0x4044>
    3b80:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3b84:      	add	x8, x8, #0x0
    3b88:      	add	x0, sp, #0x70
    3b8c:      	ldp	x9, x10, [x8, #0x10]
    3b90:      	mov	w1, #0x2e               // =46
    3b94:      	stp	x9, x10, [sp, #0x80]
    3b98:      	ldr	x9, [x8, #0x20]
    3b9c:      	add	x10, sp, #0x70
    3ba0:      	str	x9, [sp, #0x90]
    3ba4:      	ldur	x9, [x8, #0x26]
    3ba8:      	stur	x9, [sp, #0x96]
    3bac:      	ldp	x9, x8, [x8]
    3bb0:      	stp	x9, x8, [sp, #0x70]
    3bb4:      	mov	w8, #0x2e               // =46
    3bb8:      	mov	w9, #0x6                // =6
    3bbc:      	ldr	w2, [sp, #0x58]
    3bc0:      	blr	x9
    3bc4:      	b	0x4044 <perf_unwind_v8+0x4044>
    3bc8:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3bcc:      	ldr	x8, [x8]
    3bd0:      	ldr	w8, [x8]
    3bd4:      	cbz	w8, 0x3c1c <perf_unwind_v8+0x3c1c>
    3bd8:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3bdc:      	add	x8, x8, #0x0
    3be0:      	add	x0, sp, #0x70
    3be4:      	ldp	x9, x10, [x8, #0x10]
    3be8:      	mov	w1, #0x2e               // =46
    3bec:      	stp	x9, x10, [sp, #0x80]
    3bf0:      	ldr	x9, [x8, #0x20]
    3bf4:      	add	x10, sp, #0x70
    3bf8:      	str	x9, [sp, #0x90]
    3bfc:      	ldur	x9, [x8, #0x26]
    3c00:      	stur	x9, [sp, #0x96]
    3c04:      	ldp	x9, x8, [x8]
    3c08:      	stp	x9, x8, [sp, #0x70]
    3c0c:      	mov	w8, #0x2e               // =46
    3c10:      	mov	w9, #0x6                // =6
    3c14:      	ldr	w2, [sp, #0xbc]
    3c18:      	blr	x9
    3c1c:      	ldrh	w29, [x24, #0x20]
    3c20:      	cmp	w29, #0x7
    3c24:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    3c28:      	ldr	x8, [x21, #0xed0]
    3c2c:      	ldr	x29, [x21, #0xed8]
    3c30:      	ldr	x25, [x21, #0xee0]
    3c34:      	str	x8, [sp, #0x30]
    3c38:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3c3c:      	ldr	x8, [x8]
    3c40:      	ldr	w8, [x8]
    3c44:      	cbz	w8, 0x3c8c <perf_unwind_v8+0x3c8c>
    3c48:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3c4c:      	add	x8, x8, #0x0
    3c50:      	add	x0, sp, #0x70
    3c54:      	ldp	x9, x10, [x8]
    3c58:      	mov	w1, #0x1f               // =31
    3c5c:      	mov	x3, x29
    3c60:      	mov	x4, x25
    3c64:      	stp	x9, x10, [sp, #0x70]
    3c68:      	ldr	x9, [x8, #0x10]
    3c6c:      	ldur	x8, [x8, #0x17]
    3c70:      	add	x10, sp, #0x70
    3c74:      	str	x9, [sp, #0x80]
    3c78:      	stur	x8, [sp, #0x87]
    3c7c:      	mov	w8, #0x1f               // =31
    3c80:      	mov	w9, #0x6                // =6
    3c84:      	ldr	x2, [sp, #0x30]
    3c88:      	blr	x9
    3c8c:      	cmp	x25, x29
    3c90:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    3c94:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    3c98:      	cmp	x25, x8
    3c9c:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    3ca0:      	ldr	x0, [sp, #0x50]
    3ca4:      	sub	x2, x25, #0x40
    3ca8:      	mov	w8, #0x40               // =64
    3cac:      	mov	w9, #0x70               // =112
    3cb0:      	mov	w1, #0x40               // =64
    3cb4:      	blr	x9
    3cb8:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    3cbc:      	ldrb	w9, [x23, #0x14]
    3cc0:      	cmp	x9, #0x38
    3cc4:      	b.hi	0x250 <perf_unwind_v8+0x250>
    3cc8:      	ldrb	w8, [x23, #0x15]
    3ccc:      	cmp	x8, #0x38
    3cd0:      	b.hi	0x250 <perf_unwind_v8+0x250>
    3cd4:      	ldrb	w10, [x23, #0x16]
    3cd8:      	cmp	x10, #0x38
    3cdc:      	b.hi	0x250 <perf_unwind_v8+0x250>
    3ce0:      	ldr	x11, [sp, #0x50]
    3ce4:      	ldr	x9, [x11, x9]
    3ce8:      	tbnz	w9, #0x0, 0x3e3c <perf_unwind_v8+0x3e3c>
    3cec:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3cf0:      	lsr	x24, x9, #1
    3cf4:      	ldr	x8, [x8]
    3cf8:      	ldr	w8, [x8]
    3cfc:      	cbnz	w8, 0x3ed8 <perf_unwind_v8+0x3ed8>
    3d00:      	ldrb	w25, [x21, #0xf20]
    3d04:      	str	xzr, [sp, #0x40]
    3d08:      	b	0x45a0 <perf_unwind_v8+0x45a0>
    3d0c:      	add	x10, x25, x10
    3d10:      	str	x10, [sp, #0x38]
    3d14:      	ldr	x10, [sp, #0x48]
    3d18:      	ldr	w9, [x10, x9]
    3d1c:      	ldr	w8, [x10, x8]
    3d20:      	str	w9, [sp, #0x20]
    3d24:      	ldrb	w9, [x23, #0x18]
    3d28:      	str	x8, [sp, #0x30]
    3d2c:      	str	w9, [sp, #0x10]
    3d30:      	ldrb	w9, [x23, #0x17]
    3d34:      	str	x9, [sp, #0x18]
    3d38:      	ldr	x9, [sp, #0x38]
    3d3c:      	add	x8, x9, x8
    3d40:      	str	x8, [sp, #0x28]
    3d44:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3d48:      	ldr	x8, [x8]
    3d4c:      	ldr	w8, [x8]
    3d50:      	cbz	w8, 0x3dec <perf_unwind_v8+0x3dec>
    3d54:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3d58:      	add	x8, x8, #0x0
    3d5c:      	strb	wzr, [sp, #0x98]
    3d60:      	add	x0, sp, #0x70
    3d64:      	ldp	x9, x10, [x8, #0x10]
    3d68:      	mov	w1, #0x29               // =41
    3d6c:      	mov	x2, x29
    3d70:      	mov	x4, x25
    3d74:      	stp	x9, x10, [sp, #0x80]
    3d78:      	ldr	x9, [x8, #0x20]
    3d7c:      	add	x10, sp, #0x70
    3d80:      	str	x9, [sp, #0x90]
    3d84:      	ldp	x8, x9, [x8]
    3d88:      	stp	x8, x9, [sp, #0x70]
    3d8c:      	mov	w8, #0x29               // =41
    3d90:      	mov	w9, #0x6                // =6
    3d94:      	ldr	x3, [sp, #0x40]
    3d98:      	blr	x9
    3d9c:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3da0:      	ldr	x8, [x8]
    3da4:      	ldr	w8, [x8]
    3da8:      	cbz	w8, 0x3dec <perf_unwind_v8+0x3dec>
    3dac:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3db0:      	add	x8, x8, #0x0
    3db4:      	add	x0, sp, #0x70
    3db8:      	ldp	x9, x10, [x8, #0x10]
    3dbc:      	mov	w1, #0x25               // =37
    3dc0:      	stp	x9, x10, [sp, #0x80]
    3dc4:      	ldur	x9, [x8, #0x1d]
    3dc8:      	add	x10, sp, #0x70
    3dcc:      	stur	x9, [sp, #0x8d]
    3dd0:      	ldp	x8, x9, [x8]
    3dd4:      	stp	x8, x9, [sp, #0x70]
    3dd8:      	mov	w8, #0x25               // =37
    3ddc:      	mov	w9, #0x6                // =6
    3de0:      	ldp	x4, x2, [sp, #0x30]
    3de4:      	ldr	x3, [sp, #0x28]
    3de8:      	blr	x9
    3dec:      	ldr	x8, [sp, #0x38]
    3df0:      	subs	x8, x24, x8
    3df4:      	b.lo	0x3f1c <perf_unwind_v8+0x3f1c>
    3df8:      	ldr	x9, [sp, #0x28]
    3dfc:      	cmp	x24, x9
    3e00:      	b.hs	0x3f1c <perf_unwind_v8+0x3f1c>
    3e04:      	ldr	w9, [sp, #0x20]
    3e08:      	ldr	w10, [sp, #0x10]
    3e0c:      	orr	x11, x29, #0x4
    3e10:      	orr	x12, x25, #0x3
    3e14:      	and	w9, w9, w10
    3e18:      	ldr	x10, [sp, #0x18]
    3e1c:      	lsr	w9, w9, w10
    3e20:      	ldrb	w10, [x23, #0x19]
    3e24:      	cmp	w9, w10
    3e28:      	ldr	x10, [sp, #0x30]
    3e2c:      	csel	x22, x11, x12, eq
    3e30:      	orr	w9, w9, w10, lsl #4
    3e34:      	orr	x25, x8, x9, lsl #32
    3e38:      	b	0x4048 <perf_unwind_v8+0x4048>
    3e3c:      	ldr	x9, [sp, #0x50]
    3e40:      	ldr	x8, [x9, x8]
    3e44:      	ldr	x25, [x9, x10]
    3e48:      	and	x9, x8, #0x3
    3e4c:      	and	x8, x8, #0xfffffffffffffffc
    3e50:      	cmp	x9, #0x1
    3e54:      	csel	x8, x8, xzr, eq
    3e58:      	str	x8, [sp, #0x38]
    3e5c:      	cbz	x8, 0x3f3c <perf_unwind_v8+0x3f3c>
    3e60:      	ldrb	w8, [x23, #0xc]
    3e64:      	ldr	x9, [sp, #0x38]
    3e68:      	add	x10, sp, #0x70
    3e6c:      	add	x0, sp, #0x70
    3e70:      	mov	w1, #0x8                // =8
    3e74:      	add	x2, x9, x8
    3e78:      	mov	w8, #0x8                // =8
    3e7c:      	mov	w9, #0x70               // =112
    3e80:      	blr	x9
    3e84:      	cbnz	x0, 0x3f38 <perf_unwind_v8+0x3f38>
    3e88:      	ldr	x8, [sp, #0x70]
    3e8c:      	and	x9, x8, #0x3
    3e90:      	cmp	x9, #0x1
    3e94:      	b.ne	0x3f38 <perf_unwind_v8+0x3f38>
    3e98:      	and	x8, x8, #0xfffffffffffffffc
    3e9c:      	cbz	x8, 0x3f3c <perf_unwind_v8+0x3f3c>
    3ea0:      	ldrb	w9, [x23, #0xd]
    3ea4:      	mov	w10, #0x2               // =2
    3ea8:      	mov	w11, #0x70              // =112
    3eac:      	add	x12, sp, #0x70
    3eb0:      	add	x0, sp, #0x70
    3eb4:      	mov	w1, #0x2                // =2
    3eb8:      	add	x9, x8, x9
    3ebc:      	ldrb	w9, [x23, #0xd]
    3ec0:      	add	x2, x8, x9
    3ec4:      	blr	x11
    3ec8:      	ldrh	w8, [sp, #0x70]
    3ecc:      	cmp	x0, #0x0
    3ed0:      	csel	w8, w8, wzr, eq
    3ed4:      	b	0x3f3c <perf_unwind_v8+0x3f3c>
    3ed8:      	adrp	x10, 0x3000 <perf_unwind_v8+0x3000>
    3edc:      	add	x10, x10, #0x0
    3ee0:      	add	x0, sp, #0x70
    3ee4:      	ldp	x8, x9, [x10]
    3ee8:      	mov	w1, #0x1d               // =29
    3eec:      	mov	x2, x24
    3ef0:      	stp	x8, x9, [sp, #0x70]
    3ef4:      	ldr	x8, [x10, #0x10]
    3ef8:      	mov	w9, #0x6                // =6
    3efc:      	str	x8, [sp, #0x80]
    3f00:      	ldur	x8, [x10, #0x15]
    3f04:      	add	x10, sp, #0x70
    3f08:      	stur	x8, [sp, #0x85]
    3f0c:      	mov	w8, #0x1d               // =29
    3f10:      	blr	x9
    3f14:      	str	xzr, [sp, #0x40]
    3f18:      	b	0x4538 <perf_unwind_v8+0x4538>
    3f1c:      	adrp	x8, 0x3000 <perf_unwind_v8+0x3000>
    3f20:      	ldr	x8, [x8]
    3f24:      	ldr	w8, [x8]
    3f28:      	cbnz	w8, 0x400c <perf_unwind_v8+0x400c>
    3f2c:      	ldrb	w24, [x21, #0xf20]
    3f30:      	mov	x25, xzr
    3f34:      	b	0x30f0 <perf_unwind_v8+0x30f0>
    3f38:      	mov	w8, wzr
    3f3c:      	ldrh	w9, [x23, #0x4]
    3f40:      	cmp	w9, w8, uxth
    3f44:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    3f48:      	ldrh	w9, [x23, #0x6]
    3f4c:      	cmp	w9, w8, uxth
    3f50:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    3f54:      	ldrb	w8, [x23, #0xf]
    3f58:      	ldr	x9, [sp, #0x38]
    3f5c:      	add	x10, sp, #0x70
    3f60:      	add	x0, sp, #0x70
    3f64:      	mov	w1, #0x8                // =8
    3f68:      	add	x2, x9, x8
    3f6c:      	mov	w8, #0x8                // =8
    3f70:      	mov	w9, #0x70               // =112
    3f74:      	blr	x9
    3f78:      	cbnz	x0, 0x40b4 <perf_unwind_v8+0x40b4>
    3f7c:      	ldr	x8, [sp, #0x70]
    3f80:      	and	x9, x8, #0x3
    3f84:      	cmp	x9, #0x1
    3f88:      	b.ne	0x40b4 <perf_unwind_v8+0x40b4>
    3f8c:      	and	x8, x8, #0xfffffffffffffffc
    3f90:      	mov	x22, x8
    3f94:      	cbz	x8, 0x40bc <perf_unwind_v8+0x40bc>
    3f98:      	ldrb	w8, [x23, #0xc]
    3f9c:      	mov	w9, #0x70               // =112
    3fa0:      	add	x10, sp, #0x70
    3fa4:      	add	x0, sp, #0x70
    3fa8:      	mov	w1, #0x8                // =8
    3fac:      	add	x2, x22, x8
    3fb0:      	mov	w8, #0x8                // =8
    3fb4:      	blr	x9
    3fb8:      	cbnz	x0, 0x40b8 <perf_unwind_v8+0x40b8>
    3fbc:      	ldr	x8, [sp, #0x70]
    3fc0:      	and	x9, x8, #0x3
    3fc4:      	cmp	x9, #0x1
    3fc8:      	b.ne	0x40b8 <perf_unwind_v8+0x40b8>
    3fcc:      	and	x8, x8, #0xfffffffffffffffc
    3fd0:      	cbz	x8, 0x40bc <perf_unwind_v8+0x40bc>
    3fd4:      	ldrb	w9, [x23, #0xd]
    3fd8:      	mov	w10, #0x2               // =2
    3fdc:      	mov	w11, #0x70              // =112
    3fe0:      	add	x12, sp, #0x70
    3fe4:      	add	x0, sp, #0x70
    3fe8:      	mov	w1, #0x2                // =2
    3fec:      	add	x9, x8, x9
    3ff0:      	ldrb	w9, [x23, #0xd]
    3ff4:      	add	x2, x8, x9
    3ff8:      	blr	x11
    3ffc:      	ldrh	w8, [sp, #0x70]
    4000:      	cmp	x0, #0x0
    4004:      	csel	w8, w8, wzr, eq
    4008:      	b	0x40bc <perf_unwind_v8+0x40bc>
    400c:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4010:      	add	x8, x8, #0x0
    4014:      	add	x0, sp, #0x70
    4018:      	ldp	x9, x10, [x8, #0x10]
    401c:      	mov	w1, #0x30               // =48
    4020:      	stp	x9, x10, [sp, #0x80]
    4024:      	ldp	x9, x10, [x8, #0x20]
    4028:      	stp	x9, x10, [sp, #0x90]
    402c:      	ldp	x9, x8, [x8]
    4030:      	add	x10, sp, #0x70
    4034:      	stp	x9, x8, [sp, #0x70]
    4038:      	mov	w8, #0x30               // =48
    403c:      	mov	w9, #0x6                // =6
    4040:      	blr	x9
    4044:      	mov	x25, xzr
    4048:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    404c:      	ldr	x8, [x8]
    4050:      	ldrb	w24, [x21, #0xf20]
    4054:      	ldr	w8, [x8]
    4058:      	cbz	w8, 0x30f0 <perf_unwind_v8+0x30f0>
    405c:      	mov	w8, #0x786c             // =30828
    4060:      	add	x0, sp, #0x70
    4064:      	mov	w1, #0x3c               // =60
    4068:      	mov	x2, x25
    406c:      	mov	x3, x22
    4070:      	movk	w8, #0xa, lsl #16
    4074:      	str	w8, [sp, #0xa8]
    4078:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    407c:      	add	x8, x8, #0x0
    4080:      	ldp	x9, x10, [x8, #0x20]
    4084:      	stp	x9, x10, [sp, #0x90]
    4088:      	ldr	x9, [x8, #0x30]
    408c:      	str	x9, [sp, #0xa0]
    4090:      	ldp	x9, x10, [x8]
    4094:      	stp	x9, x10, [sp, #0x70]
    4098:      	add	x10, sp, #0x70
    409c:      	ldp	x8, x9, [x8, #0x10]
    40a0:      	stp	x8, x9, [sp, #0x80]
    40a4:      	mov	w8, #0x3c               // =60
    40a8:      	mov	w9, #0x6                // =6
    40ac:      	blr	x9
    40b0:      	b	0x30f0 <perf_unwind_v8+0x30f0>
    40b4:      	mov	x22, xzr
    40b8:      	mov	w8, wzr
    40bc:      	ldrh	w9, [x23, #0xa]
    40c0:      	cmp	w9, w8, uxth
    40c4:      	b.ne	0x860 <perf_unwind_v8+0x860>
    40c8:      	lsr	x24, x25, #32
    40cc:      	cbz	x24, 0x4130 <perf_unwind_v8+0x4130>
    40d0:      	tbnz	w25, #0x0, 0x4130 <perf_unwind_v8+0x4130>
    40d4:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    40d8:      	ldr	x8, [x8]
    40dc:      	ldr	w8, [x8]
    40e0:      	cbz	w8, 0x4124 <perf_unwind_v8+0x4124>
    40e4:      	mov	w8, #0x786c             // =30828
    40e8:      	add	x0, sp, #0x70
    40ec:      	mov	w1, #0x1c               // =28
    40f0:      	mov	x2, x24
    40f4:      	movk	w8, #0xa, lsl #16
    40f8:      	str	w8, [sp, #0x88]
    40fc:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4100:      	add	x8, x8, #0x0
    4104:      	ldp	x9, x10, [x8]
    4108:      	ldr	x8, [x8, #0x10]
    410c:      	stp	x9, x10, [sp, #0x70]
    4110:      	mov	w9, #0x6                // =6
    4114:      	str	x8, [sp, #0x80]
    4118:      	mov	w8, #0x1c               // =28
    411c:      	add	x10, sp, #0x70
    4120:      	blr	x9
    4124:      	orr	x8, x22, #0x1
    4128:      	str	x8, [sp, #0x40]
    412c:      	b	0x4538 <perf_unwind_v8+0x4538>
    4130:      	orr	x8, x22, #0x2
    4134:      	ldr	x9, [sp, #0x38]
    4138:      	add	x10, sp, #0x70
    413c:      	add	x0, sp, #0x70
    4140:      	str	x8, [sp, #0x40]
    4144:      	ldrb	w8, [x23, #0xe]
    4148:      	mov	w1, #0x8                // =8
    414c:      	add	x2, x9, x8
    4150:      	mov	w8, #0x8                // =8
    4154:      	mov	w9, #0x70               // =112
    4158:      	blr	x9
    415c:      	cbnz	x0, 0x41ec <perf_unwind_v8+0x41ec>
    4160:      	ldr	x8, [sp, #0x70]
    4164:      	and	x9, x8, #0x3
    4168:      	cmp	x9, #0x1
    416c:      	b.ne	0x41ec <perf_unwind_v8+0x41ec>
    4170:      	and	x24, x8, #0xfffffffffffffffc
    4174:      	cbz	x24, 0x41f0 <perf_unwind_v8+0x41f0>
    4178:      	ldrb	w8, [x23, #0xc]
    417c:      	mov	w9, #0x70               // =112
    4180:      	add	x10, sp, #0x70
    4184:      	add	x0, sp, #0x70
    4188:      	mov	w1, #0x8                // =8
    418c:      	add	x2, x24, x8
    4190:      	mov	w8, #0x8                // =8
    4194:      	blr	x9
    4198:      	cbnz	x0, 0x41f0 <perf_unwind_v8+0x41f0>
    419c:      	ldr	x8, [sp, #0x70]
    41a0:      	and	x9, x8, #0x3
    41a4:      	cmp	x9, #0x1
    41a8:      	b.ne	0x41f0 <perf_unwind_v8+0x41f0>
    41ac:      	and	x8, x8, #0xfffffffffffffffc
    41b0:      	cbz	x8, 0x41f4 <perf_unwind_v8+0x41f4>
    41b4:      	ldrb	w9, [x23, #0xd]
    41b8:      	mov	w10, #0x2               // =2
    41bc:      	mov	w11, #0x70              // =112
    41c0:      	add	x12, sp, #0x70
    41c4:      	add	x0, sp, #0x70
    41c8:      	mov	w1, #0x2                // =2
    41cc:      	add	x9, x8, x9
    41d0:      	ldrb	w9, [x23, #0xd]
    41d4:      	add	x2, x8, x9
    41d8:      	blr	x11
    41dc:      	ldrh	w8, [sp, #0x70]
    41e0:      	cmp	x0, #0x0
    41e4:      	csel	w8, w8, wzr, eq
    41e8:      	b	0x41f4 <perf_unwind_v8+0x41f4>
    41ec:      	mov	x24, xzr
    41f0:      	mov	w8, wzr
    41f4:      	and	w4, w8, #0xffff
    41f8:      	ldrh	w8, [x23, #0x8]
    41fc:      	cmp	w4, w8
    4200:      	b.ne	0x429c <perf_unwind_v8+0x429c>
    4204:      	ldr	x0, [sp, #0x48]
    4208:      	mov	w8, #0x60               // =96
    420c:      	mov	w9, #0x70               // =112
    4210:      	mov	w1, #0x60               // =96
    4214:      	mov	x2, x24
    4218:      	blr	x9
    421c:      	cbz	x0, 0x432c <perf_unwind_v8+0x432c>
    4220:      	mov	w8, #0x3b               // =59
    4224:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    4228:      	add	x9, sp, #0x58
    422c:      	str	w8, [sp, #0x58]
    4230:      	mov	w8, #0x1                // =1
    4234:      	add	x1, sp, #0x58
    4238:      	ldr	x0, [x0]
    423c:      	blr	x8
    4240:      	cbnz	x0, 0x4318 <perf_unwind_v8+0x4318>
    4244:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4248:      	ldr	x8, [x8]
    424c:      	ldr	w8, [x8]
    4250:      	cbz	w8, 0x4534 <perf_unwind_v8+0x4534>
    4254:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4258:      	add	x8, x8, #0x0
    425c:      	add	x0, sp, #0x70
    4260:      	ldp	x9, x10, [x8, #0x10]
    4264:      	mov	w1, #0x2e               // =46
    4268:      	stp	x9, x10, [sp, #0x80]
    426c:      	ldr	x9, [x8, #0x20]
    4270:      	add	x10, sp, #0x70
    4274:      	str	x9, [sp, #0x90]
    4278:      	ldur	x9, [x8, #0x26]
    427c:      	stur	x9, [sp, #0x96]
    4280:      	ldp	x9, x8, [x8]
    4284:      	stp	x9, x8, [sp, #0x70]
    4288:      	mov	w8, #0x2e               // =46
    428c:      	mov	w9, #0x6                // =6
    4290:      	ldr	w2, [sp, #0x58]
    4294:      	blr	x9
    4298:      	b	0x4534 <perf_unwind_v8+0x4534>
    429c:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    42a0:      	ldr	x8, [x8]
    42a4:      	ldr	w8, [x8]
    42a8:      	cbz	w8, 0x42f4 <perf_unwind_v8+0x42f4>
    42ac:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    42b0:      	add	x8, x8, #0x0
    42b4:      	add	x0, sp, #0x70
    42b8:      	ldp	x9, x10, [x8, #0x10]
    42bc:      	mov	w1, #0x2e               // =46
    42c0:      	mov	x3, x24
    42c4:      	stp	x9, x10, [sp, #0x80]
    42c8:      	ldr	x9, [x8, #0x20]
    42cc:      	add	x10, sp, #0x70
    42d0:      	str	x9, [sp, #0x90]
    42d4:      	ldur	x9, [x8, #0x26]
    42d8:      	stur	x9, [sp, #0x96]
    42dc:      	ldp	x9, x8, [x8]
    42e0:      	stp	x9, x8, [sp, #0x70]
    42e4:      	mov	w8, #0x2e               // =46
    42e8:      	mov	w9, #0x6                // =6
    42ec:      	ldr	x2, [sp, #0x38]
    42f0:      	blr	x9
    42f4:      	mov	w8, #0x3b               // =59
    42f8:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    42fc:      	add	x9, sp, #0x58
    4300:      	str	w8, [sp, #0x58]
    4304:      	mov	w8, #0x1                // =1
    4308:      	add	x1, sp, #0x58
    430c:      	ldr	x0, [x0]
    4310:      	blr	x8
    4314:      	cbz	x0, 0x435c <perf_unwind_v8+0x435c>
    4318:      	ldr	x8, [x0]
    431c:      	mov	x24, xzr
    4320:      	add	x8, x8, #0x1
    4324:      	str	x8, [x0]
    4328:      	b	0x4538 <perf_unwind_v8+0x4538>
    432c:      	ldrb	w8, [x23, #0x12]
    4330:      	cmp	x8, #0x5c
    4334:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4338:      	ldrb	w9, [x23, #0x13]
    433c:      	cmp	x9, #0x5c
    4340:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4344:      	ldrb	w11, [x23, #0x10]
    4348:      	ldrb	w10, [x23, #0x11]
    434c:      	cbz	w11, 0x43b4 <perf_unwind_v8+0x43b4>
    4350:      	ldr	x11, [sp, #0x48]
    4354:      	ldr	x25, [x11, x10]
    4358:      	b	0x43b8 <perf_unwind_v8+0x43b8>
    435c:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4360:      	ldr	x8, [x8]
    4364:      	ldr	w8, [x8]
    4368:      	cbz	w8, 0x4534 <perf_unwind_v8+0x4534>
    436c:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4370:      	add	x8, x8, #0x0
    4374:      	add	x0, sp, #0x70
    4378:      	ldp	x9, x10, [x8, #0x10]
    437c:      	mov	w1, #0x2e               // =46
    4380:      	stp	x9, x10, [sp, #0x80]
    4384:      	ldr	x9, [x8, #0x20]
    4388:      	add	x10, sp, #0x70
    438c:      	str	x9, [sp, #0x90]
    4390:      	ldur	x9, [x8, #0x26]
    4394:      	stur	x9, [sp, #0x96]
    4398:      	ldp	x9, x8, [x8]
    439c:      	stp	x9, x8, [sp, #0x70]
    43a0:      	mov	w8, #0x2e               // =46
    43a4:      	mov	w9, #0x6                // =6
    43a8:      	ldr	w2, [sp, #0x58]
    43ac:      	blr	x9
    43b0:      	b	0x4534 <perf_unwind_v8+0x4534>
    43b4:      	add	x25, x24, x10
    43b8:      	ldr	x10, [sp, #0x48]
    43bc:      	ldr	w29, [x10, x8]
    43c0:      	ldr	w8, [x10, x9]
    43c4:      	str	w8, [sp, #0x20]
    43c8:      	ldrb	w8, [x23, #0x18]
    43cc:      	str	w8, [sp, #0x10]
    43d0:      	ldrb	w8, [x23, #0x17]
    43d4:      	str	x8, [sp, #0x18]
    43d8:      	add	x8, x25, x29
    43dc:      	str	x8, [sp, #0x28]
    43e0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    43e4:      	ldr	x8, [x8]
    43e8:      	ldr	w8, [x8]
    43ec:      	cbz	w8, 0x448c <perf_unwind_v8+0x448c>
    43f0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    43f4:      	add	x8, x8, #0x0
    43f8:      	strb	wzr, [sp, #0x98]
    43fc:      	add	x0, sp, #0x70
    4400:      	ldp	x9, x10, [x8, #0x10]
    4404:      	mov	w1, #0x29               // =41
    4408:      	mov	x3, x22
    440c:      	mov	x4, x24
    4410:      	stp	x9, x10, [sp, #0x80]
    4414:      	ldr	x9, [x8, #0x20]
    4418:      	add	x10, sp, #0x70
    441c:      	str	x9, [sp, #0x90]
    4420:      	ldp	x8, x9, [x8]
    4424:      	stp	x8, x9, [sp, #0x70]
    4428:      	mov	w8, #0x29               // =41
    442c:      	mov	w9, #0x6                // =6
    4430:      	ldr	x2, [sp, #0x38]
    4434:      	blr	x9
    4438:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    443c:      	ldr	x8, [x8]
    4440:      	ldr	w8, [x8]
    4444:      	cbz	w8, 0x448c <perf_unwind_v8+0x448c>
    4448:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    444c:      	add	x8, x8, #0x0
    4450:      	add	x0, sp, #0x70
    4454:      	ldp	x9, x10, [x8, #0x10]
    4458:      	mov	w1, #0x25               // =37
    445c:      	mov	x2, x25
    4460:      	mov	w4, w29
    4464:      	stp	x9, x10, [sp, #0x80]
    4468:      	ldur	x9, [x8, #0x1d]
    446c:      	add	x10, sp, #0x70
    4470:      	stur	x9, [sp, #0x8d]
    4474:      	ldp	x8, x9, [x8]
    4478:      	stp	x8, x9, [sp, #0x70]
    447c:      	mov	w8, #0x25               // =37
    4480:      	mov	w9, #0x6                // =6
    4484:      	ldr	x3, [sp, #0x28]
    4488:      	blr	x9
    448c:      	ldr	x8, [sp, #0x30]
    4490:      	subs	x8, x8, x25
    4494:      	b.lo	0x44e0 <perf_unwind_v8+0x44e0>
    4498:      	ldp	x10, x9, [sp, #0x28]
    449c:      	cmp	x9, x10
    44a0:      	b.hs	0x44e0 <perf_unwind_v8+0x44e0>
    44a4:      	ldr	w9, [sp, #0x20]
    44a8:      	ldr	w10, [sp, #0x10]
    44ac:      	orr	x12, x24, #0x3
    44b0:      	and	w9, w9, w10
    44b4:      	ldr	x10, [sp, #0x18]
    44b8:      	ldr	x11, [sp, #0x38]
    44bc:      	orr	x11, x11, #0x4
    44c0:      	lsr	w9, w9, w10
    44c4:      	ldrb	w10, [x23, #0x19]
    44c8:      	cmp	w9, w10
    44cc:      	orr	w9, w9, w29, lsl #4
    44d0:      	csel	x10, x11, x12, eq
    44d4:      	orr	x24, x8, x9, lsl #32
    44d8:      	str	x10, [sp, #0x40]
    44dc:      	b	0x4538 <perf_unwind_v8+0x4538>
    44e0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    44e4:      	ldr	x8, [x8]
    44e8:      	ldr	w8, [x8]
    44ec:      	cbnz	w8, 0x44fc <perf_unwind_v8+0x44fc>
    44f0:      	ldrb	w25, [x21, #0xf20]
    44f4:      	mov	x24, xzr
    44f8:      	b	0x45a0 <perf_unwind_v8+0x45a0>
    44fc:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4500:      	add	x8, x8, #0x0
    4504:      	add	x0, sp, #0x70
    4508:      	ldp	x9, x10, [x8, #0x10]
    450c:      	mov	w1, #0x30               // =48
    4510:      	stp	x9, x10, [sp, #0x80]
    4514:      	ldp	x9, x10, [x8, #0x20]
    4518:      	stp	x9, x10, [sp, #0x90]
    451c:      	ldp	x9, x8, [x8]
    4520:      	add	x10, sp, #0x70
    4524:      	stp	x9, x8, [sp, #0x70]
    4528:      	mov	w8, #0x30               // =48
    452c:      	mov	w9, #0x6                // =6
    4530:      	blr	x9
    4534:      	mov	x24, xzr
    4538:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    453c:      	ldr	x8, [x8]
    4540:      	ldrb	w25, [x21, #0xf20]
    4544:      	ldr	w8, [x8]
    4548:      	cbz	w8, 0x45a0 <perf_unwind_v8+0x45a0>
    454c:      	mov	w8, #0x786c             // =30828
    4550:      	add	x0, sp, #0x70
    4554:      	mov	w1, #0x3c               // =60
    4558:      	mov	x2, x24
    455c:      	movk	w8, #0xa, lsl #16
    4560:      	str	w8, [sp, #0xa8]
    4564:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4568:      	add	x8, x8, #0x0
    456c:      	ldp	x9, x10, [x8, #0x20]
    4570:      	stp	x9, x10, [sp, #0x90]
    4574:      	ldr	x9, [x8, #0x30]
    4578:      	str	x9, [sp, #0xa0]
    457c:      	ldp	x9, x10, [x8]
    4580:      	stp	x9, x10, [sp, #0x70]
    4584:      	add	x10, sp, #0x70
    4588:      	ldp	x8, x9, [x8, #0x10]
    458c:      	stp	x8, x9, [sp, #0x80]
    4590:      	mov	w8, #0x3c               // =60
    4594:      	mov	w9, #0x6                // =6
    4598:      	ldr	x3, [sp, #0x40]
    459c:      	blr	x9
    45a0:      	ldr	w8, [x21, #0x2c0]
    45a4:      	cmp	w8, #0x7e
    45a8:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    45ac:      	add	w9, w8, #0x1
    45b0:      	mov	w10, #0x8               // =8
    45b4:      	add	x11, sp, #0x70
    45b8:      	str	w9, [x21, #0x2c0]
    45bc:      	mov	w9, #0x18               // =24
    45c0:      	add	x0, sp, #0x70
    45c4:      	mov	w1, #0x10               // =16
    45c8:      	umaddl	x8, w8, w9, x21
    45cc:      	ldr	x9, [sp, #0x40]
    45d0:      	str	x24, [x8, #0x2d8]
    45d4:      	strb	w10, [x8, #0x2e0]
    45d8:      	strb	w25, [x8, #0x2e1]
    45dc:      	strh	wzr, [x8, #0x2e6]
    45e0:      	mov	w10, #0x70              // =112
    45e4:      	str	x9, [x8, #0x2d0]
    45e8:      	add	x9, x8, #0x2d0
    45ec:      	stur	wzr, [x9, #0x12]
    45f0:      	mov	w9, #0x10               // =16
    45f4:      	ldr	x8, [x21, #0xee0]
    45f8:      	ldr	x2, [x21, #0xee0]
    45fc:      	blr	x10
    4600:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    4604:      	ldr	x8, [x21, #0xee0]
    4608:      	add	x9, x8, #0x10
    460c:      	str	x9, [x21, #0xed8]
    4610:      	ldp	x9, x10, [sp, #0x70]
    4614:      	str	x9, [x21, #0xee0]
    4618:      	mov	w9, #0x101              // =257
    461c:      	str	x10, [x21, #0xed0]
    4620:      	strh	w9, [x21, #0xf20]
    4624:      	ldr	x9, [sp, #0x40]
    4628:      	cbnz	x9, 0x463c <perf_unwind_v8+0x463c>
    462c:      	cmp	x24, #0x1
    4630:      	b.ne	0x463c <perf_unwind_v8+0x463c>
    4634:      	add	x8, x8, #0xa0
    4638:      	str	x8, [x21, #0xed8]
    463c:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4640:      	ldr	x8, [x8]
    4644:      	ldr	w8, [x8]
    4648:      	cbz	w8, 0x4690 <perf_unwind_v8+0x4690>
    464c:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4650:      	add	x8, x8, #0x0
    4654:      	add	x0, sp, #0x70
    4658:      	ldp	x9, x10, [x8]
    465c:      	mov	w1, #0x1f               // =31
    4660:      	stp	x9, x10, [sp, #0x70]
    4664:      	ldr	x9, [x8, #0x10]
    4668:      	ldur	x8, [x8, #0x17]
    466c:      	add	x10, sp, #0x70
    4670:      	str	x9, [sp, #0x80]
    4674:      	stur	x8, [sp, #0x87]
    4678:      	mov	w8, #0x1f               // =31
    467c:      	mov	w9, #0x6                // =6
    4680:      	ldr	x2, [x21, #0xed0]
    4684:      	ldr	x3, [x21, #0xed8]
    4688:      	ldr	x4, [x21, #0xee0]
    468c:      	blr	x9
    4690:      	mov	w8, #0x38               // =56
    4694:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    4698:      	add	x9, sp, #0x58
    469c:      	str	w8, [sp, #0x58]
    46a0:      	mov	w8, #0x1                // =1
    46a4:      	add	x1, sp, #0x58
    46a8:      	ldr	x0, [x0]
    46ac:      	blr	x8
    46b0:      	cbz	x0, 0x46c4 <perf_unwind_v8+0x46c4>
    46b4:      	ldr	x8, [x0]
    46b8:      	add	x8, x8, #0x1
    46bc:      	str	x8, [x0]
    46c0:      	b	0x4718 <perf_unwind_v8+0x4718>
    46c4:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    46c8:      	ldr	x8, [x8]
    46cc:      	ldr	w8, [x8]
    46d0:      	cbz	w8, 0x4724 <perf_unwind_v8+0x4724>
    46d4:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    46d8:      	add	x8, x8, #0x0
    46dc:      	add	x0, sp, #0x70
    46e0:      	ldp	x9, x10, [x8, #0x10]
    46e4:      	mov	w1, #0x2e               // =46
    46e8:      	stp	x9, x10, [sp, #0x80]
    46ec:      	ldr	x9, [x8, #0x20]
    46f0:      	add	x10, sp, #0x70
    46f4:      	str	x9, [sp, #0x90]
    46f8:      	ldur	x9, [x8, #0x26]
    46fc:      	stur	x9, [sp, #0x96]
    4700:      	ldp	x9, x8, [x8]
    4704:      	stp	x9, x8, [sp, #0x70]
    4708:      	mov	w8, #0x2e               // =46
    470c:      	mov	w9, #0x6                // =6
    4710:      	ldr	w2, [sp, #0x58]
    4714:      	blr	x9
    4718:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    471c:      	ldr	x8, [x8]
    4720:      	ldr	w8, [x8]
    4724:      	ldr	x24, [x21, #0xed0]
    4728:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    472c:      	cbz	w8, 0x4774 <perf_unwind_v8+0x4774>
    4730:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4734:      	add	x8, x8, #0x0
    4738:      	strb	wzr, [sp, #0xa0]
    473c:      	add	x0, sp, #0x70
    4740:      	ldp	x9, x10, [x8, #0x10]
    4744:      	mov	w1, #0x31               // =49
    4748:      	stp	x9, x10, [sp, #0x80]
    474c:      	ldp	x9, x10, [x8, #0x20]
    4750:      	stp	x9, x10, [sp, #0x90]
    4754:      	ldp	x9, x8, [x8]
    4758:      	add	x10, sp, #0x70
    475c:      	stp	x9, x8, [sp, #0x70]
    4760:      	mov	w8, #0x31               // =49
    4764:      	mov	w9, #0x6                // =6
    4768:      	ldr	w2, [x21, #0x2c0]
    476c:      	blr	x9
    4770:      	ldr	x24, [x21, #0xed0]
    4774:      	lsr	x8, x24, #56
    4778:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    477c:      	cmp	x24, #0x1, lsl #12      // =0x1000
    4780:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    4784:      	ldr	w8, [x21]
    4788:      	mov	w9, #0x60               // =96
    478c:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    4790:      	add	x1, sp, #0x58
    4794:      	rev	w8, w8
    4798:      	stp	w9, w8, [sp, #0x58]
    479c:      	rev	x8, x24
    47a0:      	add	x9, sp, #0x58
    47a4:      	str	x8, [sp, #0x60]
    47a8:      	mov	w8, #0x1                // =1
    47ac:      	ldr	x0, [x0]
    47b0:      	blr	x8
    47b4:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    47b8:      	ldr	x8, [x0, #0x8]
    47bc:      	and	x9, x8, #0xffffffffffffff
    47c0:      	lsr	x29, x8, #56
    47c4:      	str	x9, [x21, #0xf10]
    47c8:      	ldr	x8, [x0]
    47cc:      	str	x8, [x21, #0xf00]
    47d0:      	sub	x8, x24, x9
    47d4:      	str	x8, [x21, #0xf08]
    47d8:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    47dc:      	ldr	x8, [x8]
    47e0:      	ldr	w8, [x8]
    47e4:      	cbz	w8, 0x488c <perf_unwind_v8+0x488c>
    47e8:      	mov	w8, #0xa                // =10
    47ec:      	add	x0, sp, #0x70
    47f0:      	mov	w1, #0x32               // =50
    47f4:      	strh	w8, [sp, #0xa0]
    47f8:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    47fc:      	add	x8, x8, #0x0
    4800:      	mov	x2, x24
    4804:      	ldp	x9, x10, [x8, #0x10]
    4808:      	mov	w4, w29
    480c:      	stp	x9, x10, [sp, #0x80]
    4810:      	ldp	x9, x10, [x8, #0x20]
    4814:      	stp	x9, x10, [sp, #0x90]
    4818:      	ldp	x9, x8, [x8]
    481c:      	add	x10, sp, #0x70
    4820:      	stp	x9, x8, [sp, #0x70]
    4824:      	mov	w8, #0x32               // =50
    4828:      	mov	w9, #0x6                // =6
    482c:      	ldr	x3, [x21, #0xf00]
    4830:      	blr	x9
    4834:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4838:      	ldr	x8, [x8]
    483c:      	ldr	w8, [x8]
    4840:      	cbz	w8, 0x488c <perf_unwind_v8+0x488c>
    4844:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4848:      	add	x8, x8, #0x0
    484c:      	add	x0, sp, #0x70
    4850:      	ldp	x9, x10, [x8, #0x10]
    4854:      	mov	w1, #0x2f               // =47
    4858:      	stp	x9, x10, [sp, #0x80]
    485c:      	ldr	x9, [x8, #0x20]
    4860:      	add	x10, sp, #0x70
    4864:      	str	x9, [sp, #0x90]
    4868:      	ldur	x9, [x8, #0x27]
    486c:      	stur	x9, [sp, #0x97]
    4870:      	ldp	x9, x8, [x8]
    4874:      	stp	x9, x8, [sp, #0x70]
    4878:      	mov	w8, #0x2f               // =47
    487c:      	mov	w9, #0x6                // =6
    4880:      	ldr	x2, [x21, #0xf10]
    4884:      	ldr	x3, [x21, #0xf08]
    4888:      	blr	x9
    488c:      	cmp	w29, #0x1
    4890:      	b.ne	0x4a38 <perf_unwind_v8+0x4a38>
    4894:      	ldr	x8, [x21, #0xf00]
    4898:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    489c:      	ldr	x25, [x21, #0xf08]
    48a0:      	mov	w9, #0x1                // =1
    48a4:      	add	x1, sp, #0x58
    48a8:      	mov	w29, #0x1               // =1
    48ac:      	str	x8, [sp, #0x58]
    48b0:      	add	x8, sp, #0x58
    48b4:      	ldr	x0, [x0]
    48b8:      	blr	x9
    48bc:      	cbz	x0, 0x4968 <perf_unwind_v8+0x4968>
    48c0:      	ldr	x8, [x0]
    48c4:      	mov	x24, x0
    48c8:      	cmp	x8, x25
    48cc:      	b.hi	0x48dc <perf_unwind_v8+0x48dc>
    48d0:      	ldr	x8, [x24, #0x8]
    48d4:      	cmp	x8, x25
    48d8:      	b.hs	0x48f4 <perf_unwind_v8+0x48f4>
    48dc:      	ldr	x8, [x24, #0x10]
    48e0:      	cmp	x8, x25
    48e4:      	b.hi	0x4960 <perf_unwind_v8+0x4960>
    48e8:      	ldr	x8, [x24, #0x18]
    48ec:      	cmp	x8, x25
    48f0:      	b.lo	0x4960 <perf_unwind_v8+0x4960>
    48f4:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    48f8:      	ldr	x8, [x8]
    48fc:      	ldr	w8, [x8]
    4900:      	cbz	w8, 0x4940 <perf_unwind_v8+0x4940>
    4904:      	adrp	x10, 0x4000 <perf_unwind_v8+0x4000>
    4908:      	add	x10, x10, #0x0
    490c:      	add	x0, sp, #0x70
    4910:      	ldp	x8, x9, [x10]
    4914:      	mov	w1, #0x1e               // =30
    4918:      	stp	x8, x9, [sp, #0x70]
    491c:      	ldr	x8, [x10, #0x10]
    4920:      	mov	w9, #0x6                // =6
    4924:      	str	x8, [sp, #0x80]
    4928:      	ldur	x8, [x10, #0x16]
    492c:      	add	x10, sp, #0x70
    4930:      	stur	x8, [sp, #0x86]
    4934:      	mov	w8, #0x1e               // =30
    4938:      	ldrh	w2, [x24, #0x20]
    493c:      	blr	x9
    4940:      	ldrh	w8, [x24, #0x20]
    4944:      	ldr	w9, [x21, #0x1370]
    4948:      	lsr	w8, w9, w8
    494c:      	tbz	w8, #0x0, 0x496c <perf_unwind_v8+0x496c>
    4950:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4954:      	ldr	x8, [x8]
    4958:      	ldr	w8, [x8]
    495c:      	cbnz	w8, 0x499c <perf_unwind_v8+0x499c>
    4960:      	mov	w29, #0x1               // =1
    4964:      	b	0x4a38 <perf_unwind_v8+0x4a38>
    4968:      	b	0x4a38 <perf_unwind_v8+0x4a38>
    496c:      	str	wzr, [sp, #0xbc]
    4970:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    4974:      	mov	w8, #0x1                // =1
    4978:      	add	x9, sp, #0xbc
    497c:      	ldr	x0, [x0]
    4980:      	add	x1, sp, #0xbc
    4984:      	blr	x8
    4988:      	cbz	x0, 0x49e0 <perf_unwind_v8+0x49e0>
    498c:      	ldr	x8, [x0]
    4990:      	add	x8, x8, #0x1
    4994:      	str	x8, [x0]
    4998:      	b	0x4a34 <perf_unwind_v8+0x4a34>
    499c:      	mov	w8, #0x656e             // =25966
    49a0:      	adrp	x10, 0x4000 <perf_unwind_v8+0x4000>
    49a4:      	add	x10, x10, #0x0
    49a8:      	add	x0, sp, #0x70
    49ac:      	mov	w1, #0x1b               // =27
    49b0:      	movk	w8, #0xa, lsl #16
    49b4:      	stur	w8, [sp, #0x87]
    49b8:      	ldp	x8, x9, [x10]
    49bc:      	stp	x8, x9, [sp, #0x70]
    49c0:      	ldr	x8, [x10, #0x10]
    49c4:      	mov	w9, #0x6                // =6
    49c8:      	add	x10, sp, #0x70
    49cc:      	str	x8, [sp, #0x80]
    49d0:      	mov	w8, #0x1b               // =27
    49d4:      	blr	x9
    49d8:      	mov	w29, #0x1               // =1
    49dc:      	b	0x4a38 <perf_unwind_v8+0x4a38>
    49e0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    49e4:      	ldr	x8, [x8]
    49e8:      	ldr	w8, [x8]
    49ec:      	cbz	w8, 0x4a34 <perf_unwind_v8+0x4a34>
    49f0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    49f4:      	add	x8, x8, #0x0
    49f8:      	add	x0, sp, #0x70
    49fc:      	ldp	x9, x10, [x8, #0x10]
    4a00:      	mov	w1, #0x2e               // =46
    4a04:      	stp	x9, x10, [sp, #0x80]
    4a08:      	ldr	x9, [x8, #0x20]
    4a0c:      	add	x10, sp, #0x70
    4a10:      	str	x9, [sp, #0x90]
    4a14:      	ldur	x9, [x8, #0x26]
    4a18:      	stur	x9, [sp, #0x96]
    4a1c:      	ldp	x9, x8, [x8]
    4a20:      	stp	x9, x8, [sp, #0x70]
    4a24:      	mov	w8, #0x2e               // =46
    4a28:      	mov	w9, #0x6                // =6
    4a2c:      	ldr	w2, [sp, #0xbc]
    4a30:      	blr	x9
    4a34:      	ldrh	w29, [x24, #0x20]
    4a38:      	cmp	w29, #0x7
    4a3c:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    4a40:      	ldr	x8, [x21, #0xed0]
    4a44:      	ldr	x29, [x21, #0xed8]
    4a48:      	ldr	x25, [x21, #0xee0]
    4a4c:      	str	x8, [sp, #0x30]
    4a50:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4a54:      	ldr	x8, [x8]
    4a58:      	ldr	w8, [x8]
    4a5c:      	cbz	w8, 0x4aa4 <perf_unwind_v8+0x4aa4>
    4a60:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4a64:      	add	x8, x8, #0x0
    4a68:      	add	x0, sp, #0x70
    4a6c:      	ldp	x9, x10, [x8]
    4a70:      	mov	w1, #0x1f               // =31
    4a74:      	mov	x3, x29
    4a78:      	mov	x4, x25
    4a7c:      	stp	x9, x10, [sp, #0x70]
    4a80:      	ldr	x9, [x8, #0x10]
    4a84:      	ldur	x8, [x8, #0x17]
    4a88:      	add	x10, sp, #0x70
    4a8c:      	str	x9, [sp, #0x80]
    4a90:      	stur	x8, [sp, #0x87]
    4a94:      	mov	w8, #0x1f               // =31
    4a98:      	mov	w9, #0x6                // =6
    4a9c:      	ldr	x2, [sp, #0x30]
    4aa0:      	blr	x9
    4aa4:      	cmp	x25, x29
    4aa8:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    4aac:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    4ab0:      	cmp	x25, x8
    4ab4:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    4ab8:      	ldr	x0, [sp, #0x50]
    4abc:      	sub	x2, x25, #0x40
    4ac0:      	mov	w8, #0x40               // =64
    4ac4:      	mov	w9, #0x70               // =112
    4ac8:      	mov	w1, #0x40               // =64
    4acc:      	blr	x9
    4ad0:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    4ad4:      	ldrb	w9, [x23, #0x14]
    4ad8:      	cmp	x9, #0x38
    4adc:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4ae0:      	ldrb	w8, [x23, #0x15]
    4ae4:      	cmp	x8, #0x38
    4ae8:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4aec:      	ldrb	w10, [x23, #0x16]
    4af0:      	cmp	x10, #0x38
    4af4:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4af8:      	ldr	x11, [sp, #0x50]
    4afc:      	ldr	x9, [x11, x9]
    4b00:      	tbnz	w9, #0x0, 0x4b24 <perf_unwind_v8+0x4b24>
    4b04:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4b08:      	lsr	x24, x9, #1
    4b0c:      	ldr	x8, [x8]
    4b10:      	ldr	w8, [x8]
    4b14:      	cbnz	w8, 0x4bc0 <perf_unwind_v8+0x4bc0>
    4b18:      	ldrb	w25, [x21, #0xf20]
    4b1c:      	str	xzr, [sp, #0x40]
    4b20:      	b	0x51c4 <perf_unwind_v8+0x51c4>
    4b24:      	ldr	x9, [sp, #0x50]
    4b28:      	ldr	x8, [x9, x8]
    4b2c:      	ldr	x25, [x9, x10]
    4b30:      	and	x9, x8, #0x3
    4b34:      	and	x8, x8, #0xfffffffffffffffc
    4b38:      	cmp	x9, #0x1
    4b3c:      	csel	x8, x8, xzr, eq
    4b40:      	str	x8, [sp, #0x38]
    4b44:      	cbz	x8, 0x4c08 <perf_unwind_v8+0x4c08>
    4b48:      	ldrb	w8, [x23, #0xc]
    4b4c:      	ldr	x9, [sp, #0x38]
    4b50:      	add	x10, sp, #0x70
    4b54:      	add	x0, sp, #0x70
    4b58:      	mov	w1, #0x8                // =8
    4b5c:      	add	x2, x9, x8
    4b60:      	mov	w8, #0x8                // =8
    4b64:      	mov	w9, #0x70               // =112
    4b68:      	blr	x9
    4b6c:      	cbnz	x0, 0x4c04 <perf_unwind_v8+0x4c04>
    4b70:      	ldr	x8, [sp, #0x70]
    4b74:      	and	x9, x8, #0x3
    4b78:      	cmp	x9, #0x1
    4b7c:      	b.ne	0x4c04 <perf_unwind_v8+0x4c04>
    4b80:      	and	x8, x8, #0xfffffffffffffffc
    4b84:      	cbz	x8, 0x4c08 <perf_unwind_v8+0x4c08>
    4b88:      	ldrb	w9, [x23, #0xd]
    4b8c:      	mov	w10, #0x2               // =2
    4b90:      	mov	w11, #0x70              // =112
    4b94:      	add	x12, sp, #0x70
    4b98:      	add	x0, sp, #0x70
    4b9c:      	mov	w1, #0x2                // =2
    4ba0:      	add	x9, x8, x9
    4ba4:      	ldrb	w9, [x23, #0xd]
    4ba8:      	add	x2, x8, x9
    4bac:      	blr	x11
    4bb0:      	ldrh	w8, [sp, #0x70]
    4bb4:      	cmp	x0, #0x0
    4bb8:      	csel	w8, w8, wzr, eq
    4bbc:      	b	0x4c08 <perf_unwind_v8+0x4c08>
    4bc0:      	adrp	x10, 0x4000 <perf_unwind_v8+0x4000>
    4bc4:      	add	x10, x10, #0x0
    4bc8:      	add	x0, sp, #0x70
    4bcc:      	ldp	x8, x9, [x10]
    4bd0:      	mov	w1, #0x1d               // =29
    4bd4:      	mov	x2, x24
    4bd8:      	stp	x8, x9, [sp, #0x70]
    4bdc:      	ldr	x8, [x10, #0x10]
    4be0:      	mov	w9, #0x6                // =6
    4be4:      	str	x8, [sp, #0x80]
    4be8:      	ldur	x8, [x10, #0x15]
    4bec:      	add	x10, sp, #0x70
    4bf0:      	stur	x8, [sp, #0x85]
    4bf4:      	mov	w8, #0x1d               // =29
    4bf8:      	blr	x9
    4bfc:      	str	xzr, [sp, #0x40]
    4c00:      	b	0x515c <perf_unwind_v8+0x515c>
    4c04:      	mov	w8, wzr
    4c08:      	ldrh	w9, [x23, #0x4]
    4c0c:      	cmp	w9, w8, uxth
    4c10:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    4c14:      	ldrh	w9, [x23, #0x6]
    4c18:      	cmp	w9, w8, uxth
    4c1c:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    4c20:      	ldrb	w8, [x23, #0xf]
    4c24:      	ldr	x9, [sp, #0x38]
    4c28:      	add	x10, sp, #0x70
    4c2c:      	add	x0, sp, #0x70
    4c30:      	mov	w1, #0x8                // =8
    4c34:      	add	x2, x9, x8
    4c38:      	mov	w8, #0x8                // =8
    4c3c:      	mov	w9, #0x70               // =112
    4c40:      	blr	x9
    4c44:      	cbnz	x0, 0x4cd8 <perf_unwind_v8+0x4cd8>
    4c48:      	ldr	x8, [sp, #0x70]
    4c4c:      	and	x9, x8, #0x3
    4c50:      	cmp	x9, #0x1
    4c54:      	b.ne	0x4cd8 <perf_unwind_v8+0x4cd8>
    4c58:      	and	x8, x8, #0xfffffffffffffffc
    4c5c:      	mov	x22, x8
    4c60:      	cbz	x8, 0x4ce0 <perf_unwind_v8+0x4ce0>
    4c64:      	ldrb	w8, [x23, #0xc]
    4c68:      	mov	w9, #0x70               // =112
    4c6c:      	add	x10, sp, #0x70
    4c70:      	add	x0, sp, #0x70
    4c74:      	mov	w1, #0x8                // =8
    4c78:      	add	x2, x22, x8
    4c7c:      	mov	w8, #0x8                // =8
    4c80:      	blr	x9
    4c84:      	cbnz	x0, 0x4cdc <perf_unwind_v8+0x4cdc>
    4c88:      	ldr	x8, [sp, #0x70]
    4c8c:      	and	x9, x8, #0x3
    4c90:      	cmp	x9, #0x1
    4c94:      	b.ne	0x4cdc <perf_unwind_v8+0x4cdc>
    4c98:      	and	x8, x8, #0xfffffffffffffffc
    4c9c:      	cbz	x8, 0x4ce0 <perf_unwind_v8+0x4ce0>
    4ca0:      	ldrb	w9, [x23, #0xd]
    4ca4:      	mov	w10, #0x2               // =2
    4ca8:      	mov	w11, #0x70              // =112
    4cac:      	add	x12, sp, #0x70
    4cb0:      	add	x0, sp, #0x70
    4cb4:      	mov	w1, #0x2                // =2
    4cb8:      	add	x9, x8, x9
    4cbc:      	ldrb	w9, [x23, #0xd]
    4cc0:      	add	x2, x8, x9
    4cc4:      	blr	x11
    4cc8:      	ldrh	w8, [sp, #0x70]
    4ccc:      	cmp	x0, #0x0
    4cd0:      	csel	w8, w8, wzr, eq
    4cd4:      	b	0x4ce0 <perf_unwind_v8+0x4ce0>
    4cd8:      	mov	x22, xzr
    4cdc:      	mov	w8, wzr
    4ce0:      	ldrh	w9, [x23, #0xa]
    4ce4:      	cmp	w9, w8, uxth
    4ce8:      	b.ne	0x860 <perf_unwind_v8+0x860>
    4cec:      	lsr	x24, x25, #32
    4cf0:      	cbz	x24, 0x4d54 <perf_unwind_v8+0x4d54>
    4cf4:      	tbnz	w25, #0x0, 0x4d54 <perf_unwind_v8+0x4d54>
    4cf8:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4cfc:      	ldr	x8, [x8]
    4d00:      	ldr	w8, [x8]
    4d04:      	cbz	w8, 0x4d48 <perf_unwind_v8+0x4d48>
    4d08:      	mov	w8, #0x786c             // =30828
    4d0c:      	add	x0, sp, #0x70
    4d10:      	mov	w1, #0x1c               // =28
    4d14:      	mov	x2, x24
    4d18:      	movk	w8, #0xa, lsl #16
    4d1c:      	str	w8, [sp, #0x88]
    4d20:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4d24:      	add	x8, x8, #0x0
    4d28:      	ldp	x9, x10, [x8]
    4d2c:      	ldr	x8, [x8, #0x10]
    4d30:      	stp	x9, x10, [sp, #0x70]
    4d34:      	mov	w9, #0x6                // =6
    4d38:      	str	x8, [sp, #0x80]
    4d3c:      	mov	w8, #0x1c               // =28
    4d40:      	add	x10, sp, #0x70
    4d44:      	blr	x9
    4d48:      	orr	x8, x22, #0x1
    4d4c:      	str	x8, [sp, #0x40]
    4d50:      	b	0x515c <perf_unwind_v8+0x515c>
    4d54:      	orr	x8, x22, #0x2
    4d58:      	ldr	x9, [sp, #0x38]
    4d5c:      	add	x10, sp, #0x70
    4d60:      	add	x0, sp, #0x70
    4d64:      	str	x8, [sp, #0x40]
    4d68:      	ldrb	w8, [x23, #0xe]
    4d6c:      	mov	w1, #0x8                // =8
    4d70:      	add	x2, x9, x8
    4d74:      	mov	w8, #0x8                // =8
    4d78:      	mov	w9, #0x70               // =112
    4d7c:      	blr	x9
    4d80:      	cbnz	x0, 0x4e10 <perf_unwind_v8+0x4e10>
    4d84:      	ldr	x8, [sp, #0x70]
    4d88:      	and	x9, x8, #0x3
    4d8c:      	cmp	x9, #0x1
    4d90:      	b.ne	0x4e10 <perf_unwind_v8+0x4e10>
    4d94:      	and	x24, x8, #0xfffffffffffffffc
    4d98:      	cbz	x24, 0x4e14 <perf_unwind_v8+0x4e14>
    4d9c:      	ldrb	w8, [x23, #0xc]
    4da0:      	mov	w9, #0x70               // =112
    4da4:      	add	x10, sp, #0x70
    4da8:      	add	x0, sp, #0x70
    4dac:      	mov	w1, #0x8                // =8
    4db0:      	add	x2, x24, x8
    4db4:      	mov	w8, #0x8                // =8
    4db8:      	blr	x9
    4dbc:      	cbnz	x0, 0x4e14 <perf_unwind_v8+0x4e14>
    4dc0:      	ldr	x8, [sp, #0x70]
    4dc4:      	and	x9, x8, #0x3
    4dc8:      	cmp	x9, #0x1
    4dcc:      	b.ne	0x4e14 <perf_unwind_v8+0x4e14>
    4dd0:      	and	x8, x8, #0xfffffffffffffffc
    4dd4:      	cbz	x8, 0x4e18 <perf_unwind_v8+0x4e18>
    4dd8:      	ldrb	w9, [x23, #0xd]
    4ddc:      	mov	w10, #0x2               // =2
    4de0:      	mov	w11, #0x70              // =112
    4de4:      	add	x12, sp, #0x70
    4de8:      	add	x0, sp, #0x70
    4dec:      	mov	w1, #0x2                // =2
    4df0:      	add	x9, x8, x9
    4df4:      	ldrb	w9, [x23, #0xd]
    4df8:      	add	x2, x8, x9
    4dfc:      	blr	x11
    4e00:      	ldrh	w8, [sp, #0x70]
    4e04:      	cmp	x0, #0x0
    4e08:      	csel	w8, w8, wzr, eq
    4e0c:      	b	0x4e18 <perf_unwind_v8+0x4e18>
    4e10:      	mov	x24, xzr
    4e14:      	mov	w8, wzr
    4e18:      	and	w4, w8, #0xffff
    4e1c:      	ldrh	w8, [x23, #0x8]
    4e20:      	cmp	w4, w8
    4e24:      	b.ne	0x4ec0 <perf_unwind_v8+0x4ec0>
    4e28:      	ldr	x0, [sp, #0x48]
    4e2c:      	mov	w8, #0x60               // =96
    4e30:      	mov	w9, #0x70               // =112
    4e34:      	mov	w1, #0x60               // =96
    4e38:      	mov	x2, x24
    4e3c:      	blr	x9
    4e40:      	cbz	x0, 0x4f50 <perf_unwind_v8+0x4f50>
    4e44:      	mov	w8, #0x3b               // =59
    4e48:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    4e4c:      	add	x9, sp, #0x58
    4e50:      	str	w8, [sp, #0x58]
    4e54:      	mov	w8, #0x1                // =1
    4e58:      	add	x1, sp, #0x58
    4e5c:      	ldr	x0, [x0]
    4e60:      	blr	x8
    4e64:      	cbnz	x0, 0x4f3c <perf_unwind_v8+0x4f3c>
    4e68:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4e6c:      	ldr	x8, [x8]
    4e70:      	ldr	w8, [x8]
    4e74:      	cbz	w8, 0x5158 <perf_unwind_v8+0x5158>
    4e78:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4e7c:      	add	x8, x8, #0x0
    4e80:      	add	x0, sp, #0x70
    4e84:      	ldp	x9, x10, [x8, #0x10]
    4e88:      	mov	w1, #0x2e               // =46
    4e8c:      	stp	x9, x10, [sp, #0x80]
    4e90:      	ldr	x9, [x8, #0x20]
    4e94:      	add	x10, sp, #0x70
    4e98:      	str	x9, [sp, #0x90]
    4e9c:      	ldur	x9, [x8, #0x26]
    4ea0:      	stur	x9, [sp, #0x96]
    4ea4:      	ldp	x9, x8, [x8]
    4ea8:      	stp	x9, x8, [sp, #0x70]
    4eac:      	mov	w8, #0x2e               // =46
    4eb0:      	mov	w9, #0x6                // =6
    4eb4:      	ldr	w2, [sp, #0x58]
    4eb8:      	blr	x9
    4ebc:      	b	0x5158 <perf_unwind_v8+0x5158>
    4ec0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4ec4:      	ldr	x8, [x8]
    4ec8:      	ldr	w8, [x8]
    4ecc:      	cbz	w8, 0x4f18 <perf_unwind_v8+0x4f18>
    4ed0:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4ed4:      	add	x8, x8, #0x0
    4ed8:      	add	x0, sp, #0x70
    4edc:      	ldp	x9, x10, [x8, #0x10]
    4ee0:      	mov	w1, #0x2e               // =46
    4ee4:      	mov	x3, x24
    4ee8:      	stp	x9, x10, [sp, #0x80]
    4eec:      	ldr	x9, [x8, #0x20]
    4ef0:      	add	x10, sp, #0x70
    4ef4:      	str	x9, [sp, #0x90]
    4ef8:      	ldur	x9, [x8, #0x26]
    4efc:      	stur	x9, [sp, #0x96]
    4f00:      	ldp	x9, x8, [x8]
    4f04:      	stp	x9, x8, [sp, #0x70]
    4f08:      	mov	w8, #0x2e               // =46
    4f0c:      	mov	w9, #0x6                // =6
    4f10:      	ldr	x2, [sp, #0x38]
    4f14:      	blr	x9
    4f18:      	mov	w8, #0x3b               // =59
    4f1c:      	adrp	x0, 0x4000 <perf_unwind_v8+0x4000>
    4f20:      	add	x9, sp, #0x58
    4f24:      	str	w8, [sp, #0x58]
    4f28:      	mov	w8, #0x1                // =1
    4f2c:      	add	x1, sp, #0x58
    4f30:      	ldr	x0, [x0]
    4f34:      	blr	x8
    4f38:      	cbz	x0, 0x4f80 <perf_unwind_v8+0x4f80>
    4f3c:      	ldr	x8, [x0]
    4f40:      	mov	x24, xzr
    4f44:      	add	x8, x8, #0x1
    4f48:      	str	x8, [x0]
    4f4c:      	b	0x515c <perf_unwind_v8+0x515c>
    4f50:      	ldrb	w8, [x23, #0x12]
    4f54:      	cmp	x8, #0x5c
    4f58:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4f5c:      	ldrb	w9, [x23, #0x13]
    4f60:      	cmp	x9, #0x5c
    4f64:      	b.hi	0x250 <perf_unwind_v8+0x250>
    4f68:      	ldrb	w11, [x23, #0x10]
    4f6c:      	ldrb	w10, [x23, #0x11]
    4f70:      	cbz	w11, 0x4fd8 <perf_unwind_v8+0x4fd8>
    4f74:      	ldr	x11, [sp, #0x48]
    4f78:      	ldr	x25, [x11, x10]
    4f7c:      	b	0x4fdc <perf_unwind_v8+0x4fdc>
    4f80:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4f84:      	ldr	x8, [x8]
    4f88:      	ldr	w8, [x8]
    4f8c:      	cbz	w8, 0x5158 <perf_unwind_v8+0x5158>
    4f90:      	adrp	x8, 0x4000 <perf_unwind_v8+0x4000>
    4f94:      	add	x8, x8, #0x0
    4f98:      	add	x0, sp, #0x70
    4f9c:      	ldp	x9, x10, [x8, #0x10]
    4fa0:      	mov	w1, #0x2e               // =46
    4fa4:      	stp	x9, x10, [sp, #0x80]
    4fa8:      	ldr	x9, [x8, #0x20]
    4fac:      	add	x10, sp, #0x70
    4fb0:      	str	x9, [sp, #0x90]
    4fb4:      	ldur	x9, [x8, #0x26]
    4fb8:      	stur	x9, [sp, #0x96]
    4fbc:      	ldp	x9, x8, [x8]
    4fc0:      	stp	x9, x8, [sp, #0x70]
    4fc4:      	mov	w8, #0x2e               // =46
    4fc8:      	mov	w9, #0x6                // =6
    4fcc:      	ldr	w2, [sp, #0x58]
    4fd0:      	blr	x9
    4fd4:      	b	0x5158 <perf_unwind_v8+0x5158>
    4fd8:      	add	x25, x24, x10
    4fdc:      	ldr	x10, [sp, #0x48]
    4fe0:      	ldr	w29, [x10, x8]
    4fe4:      	ldr	w8, [x10, x9]
    4fe8:      	str	w8, [sp, #0x20]
    4fec:      	ldrb	w8, [x23, #0x18]
    4ff0:      	str	w8, [sp, #0x10]
    4ff4:      	ldrb	w8, [x23, #0x17]
    4ff8:      	str	x8, [sp, #0x18]
    4ffc:      	add	x8, x25, x29
    5000:      	str	x8, [sp, #0x28]
    5004:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5008:      	ldr	x8, [x8]
    500c:      	ldr	w8, [x8]
    5010:      	cbz	w8, 0x50b0 <perf_unwind_v8+0x50b0>
    5014:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5018:      	add	x8, x8, #0x0
    501c:      	strb	wzr, [sp, #0x98]
    5020:      	add	x0, sp, #0x70
    5024:      	ldp	x9, x10, [x8, #0x10]
    5028:      	mov	w1, #0x29               // =41
    502c:      	mov	x3, x22
    5030:      	mov	x4, x24
    5034:      	stp	x9, x10, [sp, #0x80]
    5038:      	ldr	x9, [x8, #0x20]
    503c:      	add	x10, sp, #0x70
    5040:      	str	x9, [sp, #0x90]
    5044:      	ldp	x8, x9, [x8]
    5048:      	stp	x8, x9, [sp, #0x70]
    504c:      	mov	w8, #0x29               // =41
    5050:      	mov	w9, #0x6                // =6
    5054:      	ldr	x2, [sp, #0x38]
    5058:      	blr	x9
    505c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5060:      	ldr	x8, [x8]
    5064:      	ldr	w8, [x8]
    5068:      	cbz	w8, 0x50b0 <perf_unwind_v8+0x50b0>
    506c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5070:      	add	x8, x8, #0x0
    5074:      	add	x0, sp, #0x70
    5078:      	ldp	x9, x10, [x8, #0x10]
    507c:      	mov	w1, #0x25               // =37
    5080:      	mov	x2, x25
    5084:      	mov	w4, w29
    5088:      	stp	x9, x10, [sp, #0x80]
    508c:      	ldur	x9, [x8, #0x1d]
    5090:      	add	x10, sp, #0x70
    5094:      	stur	x9, [sp, #0x8d]
    5098:      	ldp	x8, x9, [x8]
    509c:      	stp	x8, x9, [sp, #0x70]
    50a0:      	mov	w8, #0x25               // =37
    50a4:      	mov	w9, #0x6                // =6
    50a8:      	ldr	x3, [sp, #0x28]
    50ac:      	blr	x9
    50b0:      	ldr	x8, [sp, #0x30]
    50b4:      	subs	x8, x8, x25
    50b8:      	b.lo	0x5104 <perf_unwind_v8+0x5104>
    50bc:      	ldp	x10, x9, [sp, #0x28]
    50c0:      	cmp	x9, x10
    50c4:      	b.hs	0x5104 <perf_unwind_v8+0x5104>
    50c8:      	ldr	w9, [sp, #0x20]
    50cc:      	ldr	w10, [sp, #0x10]
    50d0:      	orr	x12, x24, #0x3
    50d4:      	and	w9, w9, w10
    50d8:      	ldr	x10, [sp, #0x18]
    50dc:      	ldr	x11, [sp, #0x38]
    50e0:      	orr	x11, x11, #0x4
    50e4:      	lsr	w9, w9, w10
    50e8:      	ldrb	w10, [x23, #0x19]
    50ec:      	cmp	w9, w10
    50f0:      	orr	w9, w9, w29, lsl #4
    50f4:      	csel	x10, x11, x12, eq
    50f8:      	orr	x24, x8, x9, lsl #32
    50fc:      	str	x10, [sp, #0x40]
    5100:      	b	0x515c <perf_unwind_v8+0x515c>
    5104:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5108:      	ldr	x8, [x8]
    510c:      	ldr	w8, [x8]
    5110:      	cbnz	w8, 0x5120 <perf_unwind_v8+0x5120>
    5114:      	ldrb	w25, [x21, #0xf20]
    5118:      	mov	x24, xzr
    511c:      	b	0x51c4 <perf_unwind_v8+0x51c4>
    5120:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5124:      	add	x8, x8, #0x0
    5128:      	add	x0, sp, #0x70
    512c:      	ldp	x9, x10, [x8, #0x10]
    5130:      	mov	w1, #0x30               // =48
    5134:      	stp	x9, x10, [sp, #0x80]
    5138:      	ldp	x9, x10, [x8, #0x20]
    513c:      	stp	x9, x10, [sp, #0x90]
    5140:      	ldp	x9, x8, [x8]
    5144:      	add	x10, sp, #0x70
    5148:      	stp	x9, x8, [sp, #0x70]
    514c:      	mov	w8, #0x30               // =48
    5150:      	mov	w9, #0x6                // =6
    5154:      	blr	x9
    5158:      	mov	x24, xzr
    515c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5160:      	ldr	x8, [x8]
    5164:      	ldrb	w25, [x21, #0xf20]
    5168:      	ldr	w8, [x8]
    516c:      	cbz	w8, 0x51c4 <perf_unwind_v8+0x51c4>
    5170:      	mov	w8, #0x786c             // =30828
    5174:      	add	x0, sp, #0x70
    5178:      	mov	w1, #0x3c               // =60
    517c:      	mov	x2, x24
    5180:      	movk	w8, #0xa, lsl #16
    5184:      	str	w8, [sp, #0xa8]
    5188:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    518c:      	add	x8, x8, #0x0
    5190:      	ldp	x9, x10, [x8, #0x20]
    5194:      	stp	x9, x10, [sp, #0x90]
    5198:      	ldr	x9, [x8, #0x30]
    519c:      	str	x9, [sp, #0xa0]
    51a0:      	ldp	x9, x10, [x8]
    51a4:      	stp	x9, x10, [sp, #0x70]
    51a8:      	add	x10, sp, #0x70
    51ac:      	ldp	x8, x9, [x8, #0x10]
    51b0:      	stp	x8, x9, [sp, #0x80]
    51b4:      	mov	w8, #0x3c               // =60
    51b8:      	mov	w9, #0x6                // =6
    51bc:      	ldr	x3, [sp, #0x40]
    51c0:      	blr	x9
    51c4:      	ldr	w8, [x21, #0x2c0]
    51c8:      	cmp	w8, #0x7e
    51cc:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    51d0:      	add	w9, w8, #0x1
    51d4:      	mov	w10, #0x8               // =8
    51d8:      	add	x11, sp, #0x70
    51dc:      	str	w9, [x21, #0x2c0]
    51e0:      	mov	w9, #0x18               // =24
    51e4:      	add	x0, sp, #0x70
    51e8:      	mov	w1, #0x10               // =16
    51ec:      	umaddl	x8, w8, w9, x21
    51f0:      	ldr	x9, [sp, #0x40]
    51f4:      	str	x24, [x8, #0x2d8]
    51f8:      	strb	w10, [x8, #0x2e0]
    51fc:      	strb	w25, [x8, #0x2e1]
    5200:      	strh	wzr, [x8, #0x2e6]
    5204:      	mov	w10, #0x70              // =112
    5208:      	str	x9, [x8, #0x2d0]
    520c:      	add	x9, x8, #0x2d0
    5210:      	stur	wzr, [x9, #0x12]
    5214:      	mov	w9, #0x10               // =16
    5218:      	ldr	x8, [x21, #0xee0]
    521c:      	ldr	x2, [x21, #0xee0]
    5220:      	blr	x10
    5224:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    5228:      	ldr	x8, [x21, #0xee0]
    522c:      	add	x9, x8, #0x10
    5230:      	str	x9, [x21, #0xed8]
    5234:      	ldp	x9, x10, [sp, #0x70]
    5238:      	str	x9, [x21, #0xee0]
    523c:      	mov	w9, #0x101              // =257
    5240:      	str	x10, [x21, #0xed0]
    5244:      	strh	w9, [x21, #0xf20]
    5248:      	ldr	x9, [sp, #0x40]
    524c:      	cbnz	x9, 0x5260 <perf_unwind_v8+0x5260>
    5250:      	cmp	x24, #0x1
    5254:      	b.ne	0x5260 <perf_unwind_v8+0x5260>
    5258:      	add	x8, x8, #0xa0
    525c:      	str	x8, [x21, #0xed8]
    5260:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5264:      	ldr	x8, [x8]
    5268:      	ldr	w8, [x8]
    526c:      	cbz	w8, 0x52b4 <perf_unwind_v8+0x52b4>
    5270:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5274:      	add	x8, x8, #0x0
    5278:      	add	x0, sp, #0x70
    527c:      	ldp	x9, x10, [x8]
    5280:      	mov	w1, #0x1f               // =31
    5284:      	stp	x9, x10, [sp, #0x70]
    5288:      	ldr	x9, [x8, #0x10]
    528c:      	ldur	x8, [x8, #0x17]
    5290:      	add	x10, sp, #0x70
    5294:      	str	x9, [sp, #0x80]
    5298:      	stur	x8, [sp, #0x87]
    529c:      	mov	w8, #0x1f               // =31
    52a0:      	mov	w9, #0x6                // =6
    52a4:      	ldr	x2, [x21, #0xed0]
    52a8:      	ldr	x3, [x21, #0xed8]
    52ac:      	ldr	x4, [x21, #0xee0]
    52b0:      	blr	x9
    52b4:      	mov	w8, #0x38               // =56
    52b8:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    52bc:      	add	x9, sp, #0x58
    52c0:      	str	w8, [sp, #0x58]
    52c4:      	mov	w8, #0x1                // =1
    52c8:      	add	x1, sp, #0x58
    52cc:      	ldr	x0, [x0]
    52d0:      	blr	x8
    52d4:      	cbz	x0, 0x52e8 <perf_unwind_v8+0x52e8>
    52d8:      	ldr	x8, [x0]
    52dc:      	add	x8, x8, #0x1
    52e0:      	str	x8, [x0]
    52e4:      	b	0x533c <perf_unwind_v8+0x533c>
    52e8:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    52ec:      	ldr	x8, [x8]
    52f0:      	ldr	w8, [x8]
    52f4:      	cbz	w8, 0x5348 <perf_unwind_v8+0x5348>
    52f8:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    52fc:      	add	x8, x8, #0x0
    5300:      	add	x0, sp, #0x70
    5304:      	ldp	x9, x10, [x8, #0x10]
    5308:      	mov	w1, #0x2e               // =46
    530c:      	stp	x9, x10, [sp, #0x80]
    5310:      	ldr	x9, [x8, #0x20]
    5314:      	add	x10, sp, #0x70
    5318:      	str	x9, [sp, #0x90]
    531c:      	ldur	x9, [x8, #0x26]
    5320:      	stur	x9, [sp, #0x96]
    5324:      	ldp	x9, x8, [x8]
    5328:      	stp	x9, x8, [sp, #0x70]
    532c:      	mov	w8, #0x2e               // =46
    5330:      	mov	w9, #0x6                // =6
    5334:      	ldr	w2, [sp, #0x58]
    5338:      	blr	x9
    533c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5340:      	ldr	x8, [x8]
    5344:      	ldr	w8, [x8]
    5348:      	ldr	x24, [x21, #0xed0]
    534c:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    5350:      	cbz	w8, 0x5398 <perf_unwind_v8+0x5398>
    5354:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5358:      	add	x8, x8, #0x0
    535c:      	strb	wzr, [sp, #0xa0]
    5360:      	add	x0, sp, #0x70
    5364:      	ldp	x9, x10, [x8, #0x10]
    5368:      	mov	w1, #0x31               // =49
    536c:      	stp	x9, x10, [sp, #0x80]
    5370:      	ldp	x9, x10, [x8, #0x20]
    5374:      	stp	x9, x10, [sp, #0x90]
    5378:      	ldp	x9, x8, [x8]
    537c:      	add	x10, sp, #0x70
    5380:      	stp	x9, x8, [sp, #0x70]
    5384:      	mov	w8, #0x31               // =49
    5388:      	mov	w9, #0x6                // =6
    538c:      	ldr	w2, [x21, #0x2c0]
    5390:      	blr	x9
    5394:      	ldr	x24, [x21, #0xed0]
    5398:      	lsr	x8, x24, #56
    539c:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    53a0:      	cmp	x24, #0x1, lsl #12      // =0x1000
    53a4:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    53a8:      	ldr	w8, [x21]
    53ac:      	mov	w9, #0x60               // =96
    53b0:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    53b4:      	add	x1, sp, #0x58
    53b8:      	rev	w8, w8
    53bc:      	stp	w9, w8, [sp, #0x58]
    53c0:      	rev	x8, x24
    53c4:      	add	x9, sp, #0x58
    53c8:      	str	x8, [sp, #0x60]
    53cc:      	mov	w8, #0x1                // =1
    53d0:      	ldr	x0, [x0]
    53d4:      	blr	x8
    53d8:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    53dc:      	ldr	x8, [x0, #0x8]
    53e0:      	and	x9, x8, #0xffffffffffffff
    53e4:      	lsr	x29, x8, #56
    53e8:      	str	x9, [x21, #0xf10]
    53ec:      	ldr	x8, [x0]
    53f0:      	str	x8, [x21, #0xf00]
    53f4:      	sub	x8, x24, x9
    53f8:      	str	x8, [x21, #0xf08]
    53fc:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5400:      	ldr	x8, [x8]
    5404:      	ldr	w8, [x8]
    5408:      	cbz	w8, 0x54b0 <perf_unwind_v8+0x54b0>
    540c:      	mov	w8, #0xa                // =10
    5410:      	add	x0, sp, #0x70
    5414:      	mov	w1, #0x32               // =50
    5418:      	strh	w8, [sp, #0xa0]
    541c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5420:      	add	x8, x8, #0x0
    5424:      	mov	x2, x24
    5428:      	ldp	x9, x10, [x8, #0x10]
    542c:      	mov	w4, w29
    5430:      	stp	x9, x10, [sp, #0x80]
    5434:      	ldp	x9, x10, [x8, #0x20]
    5438:      	stp	x9, x10, [sp, #0x90]
    543c:      	ldp	x9, x8, [x8]
    5440:      	add	x10, sp, #0x70
    5444:      	stp	x9, x8, [sp, #0x70]
    5448:      	mov	w8, #0x32               // =50
    544c:      	mov	w9, #0x6                // =6
    5450:      	ldr	x3, [x21, #0xf00]
    5454:      	blr	x9
    5458:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    545c:      	ldr	x8, [x8]
    5460:      	ldr	w8, [x8]
    5464:      	cbz	w8, 0x54b0 <perf_unwind_v8+0x54b0>
    5468:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    546c:      	add	x8, x8, #0x0
    5470:      	add	x0, sp, #0x70
    5474:      	ldp	x9, x10, [x8, #0x10]
    5478:      	mov	w1, #0x2f               // =47
    547c:      	stp	x9, x10, [sp, #0x80]
    5480:      	ldr	x9, [x8, #0x20]
    5484:      	add	x10, sp, #0x70
    5488:      	str	x9, [sp, #0x90]
    548c:      	ldur	x9, [x8, #0x27]
    5490:      	stur	x9, [sp, #0x97]
    5494:      	ldp	x9, x8, [x8]
    5498:      	stp	x9, x8, [sp, #0x70]
    549c:      	mov	w8, #0x2f               // =47
    54a0:      	mov	w9, #0x6                // =6
    54a4:      	ldr	x2, [x21, #0xf10]
    54a8:      	ldr	x3, [x21, #0xf08]
    54ac:      	blr	x9
    54b0:      	cmp	w29, #0x1
    54b4:      	b.ne	0x565c <perf_unwind_v8+0x565c>
    54b8:      	ldr	x8, [x21, #0xf00]
    54bc:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    54c0:      	ldr	x25, [x21, #0xf08]
    54c4:      	mov	w9, #0x1                // =1
    54c8:      	add	x1, sp, #0x58
    54cc:      	mov	w29, #0x1               // =1
    54d0:      	str	x8, [sp, #0x58]
    54d4:      	add	x8, sp, #0x58
    54d8:      	ldr	x0, [x0]
    54dc:      	blr	x9
    54e0:      	cbz	x0, 0x558c <perf_unwind_v8+0x558c>
    54e4:      	ldr	x8, [x0]
    54e8:      	mov	x24, x0
    54ec:      	cmp	x8, x25
    54f0:      	b.hi	0x5500 <perf_unwind_v8+0x5500>
    54f4:      	ldr	x8, [x24, #0x8]
    54f8:      	cmp	x8, x25
    54fc:      	b.hs	0x5518 <perf_unwind_v8+0x5518>
    5500:      	ldr	x8, [x24, #0x10]
    5504:      	cmp	x8, x25
    5508:      	b.hi	0x5584 <perf_unwind_v8+0x5584>
    550c:      	ldr	x8, [x24, #0x18]
    5510:      	cmp	x8, x25
    5514:      	b.lo	0x5584 <perf_unwind_v8+0x5584>
    5518:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    551c:      	ldr	x8, [x8]
    5520:      	ldr	w8, [x8]
    5524:      	cbz	w8, 0x5564 <perf_unwind_v8+0x5564>
    5528:      	adrp	x10, 0x5000 <perf_unwind_v8+0x5000>
    552c:      	add	x10, x10, #0x0
    5530:      	add	x0, sp, #0x70
    5534:      	ldp	x8, x9, [x10]
    5538:      	mov	w1, #0x1e               // =30
    553c:      	stp	x8, x9, [sp, #0x70]
    5540:      	ldr	x8, [x10, #0x10]
    5544:      	mov	w9, #0x6                // =6
    5548:      	str	x8, [sp, #0x80]
    554c:      	ldur	x8, [x10, #0x16]
    5550:      	add	x10, sp, #0x70
    5554:      	stur	x8, [sp, #0x86]
    5558:      	mov	w8, #0x1e               // =30
    555c:      	ldrh	w2, [x24, #0x20]
    5560:      	blr	x9
    5564:      	ldrh	w8, [x24, #0x20]
    5568:      	ldr	w9, [x21, #0x1370]
    556c:      	lsr	w8, w9, w8
    5570:      	tbz	w8, #0x0, 0x5590 <perf_unwind_v8+0x5590>
    5574:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5578:      	ldr	x8, [x8]
    557c:      	ldr	w8, [x8]
    5580:      	cbnz	w8, 0x55c0 <perf_unwind_v8+0x55c0>
    5584:      	mov	w29, #0x1               // =1
    5588:      	b	0x565c <perf_unwind_v8+0x565c>
    558c:      	b	0x565c <perf_unwind_v8+0x565c>
    5590:      	str	wzr, [sp, #0xbc]
    5594:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    5598:      	mov	w8, #0x1                // =1
    559c:      	add	x9, sp, #0xbc
    55a0:      	ldr	x0, [x0]
    55a4:      	add	x1, sp, #0xbc
    55a8:      	blr	x8
    55ac:      	cbz	x0, 0x5604 <perf_unwind_v8+0x5604>
    55b0:      	ldr	x8, [x0]
    55b4:      	add	x8, x8, #0x1
    55b8:      	str	x8, [x0]
    55bc:      	b	0x5658 <perf_unwind_v8+0x5658>
    55c0:      	mov	w8, #0x656e             // =25966
    55c4:      	adrp	x10, 0x5000 <perf_unwind_v8+0x5000>
    55c8:      	add	x10, x10, #0x0
    55cc:      	add	x0, sp, #0x70
    55d0:      	mov	w1, #0x1b               // =27
    55d4:      	movk	w8, #0xa, lsl #16
    55d8:      	stur	w8, [sp, #0x87]
    55dc:      	ldp	x8, x9, [x10]
    55e0:      	stp	x8, x9, [sp, #0x70]
    55e4:      	ldr	x8, [x10, #0x10]
    55e8:      	mov	w9, #0x6                // =6
    55ec:      	add	x10, sp, #0x70
    55f0:      	str	x8, [sp, #0x80]
    55f4:      	mov	w8, #0x1b               // =27
    55f8:      	blr	x9
    55fc:      	mov	w29, #0x1               // =1
    5600:      	b	0x565c <perf_unwind_v8+0x565c>
    5604:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5608:      	ldr	x8, [x8]
    560c:      	ldr	w8, [x8]
    5610:      	cbz	w8, 0x5658 <perf_unwind_v8+0x5658>
    5614:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5618:      	add	x8, x8, #0x0
    561c:      	add	x0, sp, #0x70
    5620:      	ldp	x9, x10, [x8, #0x10]
    5624:      	mov	w1, #0x2e               // =46
    5628:      	stp	x9, x10, [sp, #0x80]
    562c:      	ldr	x9, [x8, #0x20]
    5630:      	add	x10, sp, #0x70
    5634:      	str	x9, [sp, #0x90]
    5638:      	ldur	x9, [x8, #0x26]
    563c:      	stur	x9, [sp, #0x96]
    5640:      	ldp	x9, x8, [x8]
    5644:      	stp	x9, x8, [sp, #0x70]
    5648:      	mov	w8, #0x2e               // =46
    564c:      	mov	w9, #0x6                // =6
    5650:      	ldr	w2, [sp, #0xbc]
    5654:      	blr	x9
    5658:      	ldrh	w29, [x24, #0x20]
    565c:      	cmp	w29, #0x7
    5660:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    5664:      	ldr	x8, [x21, #0xed0]
    5668:      	ldr	x29, [x21, #0xed8]
    566c:      	ldr	x25, [x21, #0xee0]
    5670:      	str	x8, [sp, #0x30]
    5674:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5678:      	ldr	x8, [x8]
    567c:      	ldr	w8, [x8]
    5680:      	cbz	w8, 0x56c8 <perf_unwind_v8+0x56c8>
    5684:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5688:      	add	x8, x8, #0x0
    568c:      	add	x0, sp, #0x70
    5690:      	ldp	x9, x10, [x8]
    5694:      	mov	w1, #0x1f               // =31
    5698:      	mov	x3, x29
    569c:      	mov	x4, x25
    56a0:      	stp	x9, x10, [sp, #0x70]
    56a4:      	ldr	x9, [x8, #0x10]
    56a8:      	ldur	x8, [x8, #0x17]
    56ac:      	add	x10, sp, #0x70
    56b0:      	str	x9, [sp, #0x80]
    56b4:      	stur	x8, [sp, #0x87]
    56b8:      	mov	w8, #0x1f               // =31
    56bc:      	mov	w9, #0x6                // =6
    56c0:      	ldr	x2, [sp, #0x30]
    56c4:      	blr	x9
    56c8:      	cmp	x25, x29
    56cc:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    56d0:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    56d4:      	cmp	x25, x8
    56d8:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    56dc:      	ldr	x0, [sp, #0x50]
    56e0:      	sub	x2, x25, #0x40
    56e4:      	mov	w8, #0x40               // =64
    56e8:      	mov	w9, #0x70               // =112
    56ec:      	mov	w1, #0x40               // =64
    56f0:      	blr	x9
    56f4:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    56f8:      	ldrb	w9, [x23, #0x14]
    56fc:      	cmp	x9, #0x38
    5700:      	b.hi	0x250 <perf_unwind_v8+0x250>
    5704:      	ldrb	w8, [x23, #0x15]
    5708:      	cmp	x8, #0x38
    570c:      	b.hi	0x250 <perf_unwind_v8+0x250>
    5710:      	ldrb	w10, [x23, #0x16]
    5714:      	cmp	x10, #0x38
    5718:      	b.hi	0x250 <perf_unwind_v8+0x250>
    571c:      	ldr	x11, [sp, #0x50]
    5720:      	ldr	x9, [x11, x9]
    5724:      	tbnz	w9, #0x0, 0x5748 <perf_unwind_v8+0x5748>
    5728:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    572c:      	lsr	x24, x9, #1
    5730:      	ldr	x8, [x8]
    5734:      	ldr	w8, [x8]
    5738:      	cbnz	w8, 0x57e4 <perf_unwind_v8+0x57e4>
    573c:      	ldrb	w25, [x21, #0xf20]
    5740:      	str	xzr, [sp, #0x40]
    5744:      	b	0x5de8 <perf_unwind_v8+0x5de8>
    5748:      	ldr	x9, [sp, #0x50]
    574c:      	ldr	x8, [x9, x8]
    5750:      	ldr	x25, [x9, x10]
    5754:      	and	x9, x8, #0x3
    5758:      	and	x8, x8, #0xfffffffffffffffc
    575c:      	cmp	x9, #0x1
    5760:      	csel	x8, x8, xzr, eq
    5764:      	str	x8, [sp, #0x38]
    5768:      	cbz	x8, 0x582c <perf_unwind_v8+0x582c>
    576c:      	ldrb	w8, [x23, #0xc]
    5770:      	ldr	x9, [sp, #0x38]
    5774:      	add	x10, sp, #0x70
    5778:      	add	x0, sp, #0x70
    577c:      	mov	w1, #0x8                // =8
    5780:      	add	x2, x9, x8
    5784:      	mov	w8, #0x8                // =8
    5788:      	mov	w9, #0x70               // =112
    578c:      	blr	x9
    5790:      	cbnz	x0, 0x5828 <perf_unwind_v8+0x5828>
    5794:      	ldr	x8, [sp, #0x70]
    5798:      	and	x9, x8, #0x3
    579c:      	cmp	x9, #0x1
    57a0:      	b.ne	0x5828 <perf_unwind_v8+0x5828>
    57a4:      	and	x8, x8, #0xfffffffffffffffc
    57a8:      	cbz	x8, 0x582c <perf_unwind_v8+0x582c>
    57ac:      	ldrb	w9, [x23, #0xd]
    57b0:      	mov	w10, #0x2               // =2
    57b4:      	mov	w11, #0x70              // =112
    57b8:      	add	x12, sp, #0x70
    57bc:      	add	x0, sp, #0x70
    57c0:      	mov	w1, #0x2                // =2
    57c4:      	add	x9, x8, x9
    57c8:      	ldrb	w9, [x23, #0xd]
    57cc:      	add	x2, x8, x9
    57d0:      	blr	x11
    57d4:      	ldrh	w8, [sp, #0x70]
    57d8:      	cmp	x0, #0x0
    57dc:      	csel	w8, w8, wzr, eq
    57e0:      	b	0x582c <perf_unwind_v8+0x582c>
    57e4:      	adrp	x10, 0x5000 <perf_unwind_v8+0x5000>
    57e8:      	add	x10, x10, #0x0
    57ec:      	add	x0, sp, #0x70
    57f0:      	ldp	x8, x9, [x10]
    57f4:      	mov	w1, #0x1d               // =29
    57f8:      	mov	x2, x24
    57fc:      	stp	x8, x9, [sp, #0x70]
    5800:      	ldr	x8, [x10, #0x10]
    5804:      	mov	w9, #0x6                // =6
    5808:      	str	x8, [sp, #0x80]
    580c:      	ldur	x8, [x10, #0x15]
    5810:      	add	x10, sp, #0x70
    5814:      	stur	x8, [sp, #0x85]
    5818:      	mov	w8, #0x1d               // =29
    581c:      	blr	x9
    5820:      	str	xzr, [sp, #0x40]
    5824:      	b	0x5d80 <perf_unwind_v8+0x5d80>
    5828:      	mov	w8, wzr
    582c:      	ldrh	w9, [x23, #0x4]
    5830:      	cmp	w9, w8, uxth
    5834:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    5838:      	ldrh	w9, [x23, #0x6]
    583c:      	cmp	w9, w8, uxth
    5840:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    5844:      	ldrb	w8, [x23, #0xf]
    5848:      	ldr	x9, [sp, #0x38]
    584c:      	add	x10, sp, #0x70
    5850:      	add	x0, sp, #0x70
    5854:      	mov	w1, #0x8                // =8
    5858:      	add	x2, x9, x8
    585c:      	mov	w8, #0x8                // =8
    5860:      	mov	w9, #0x70               // =112
    5864:      	blr	x9
    5868:      	cbnz	x0, 0x58fc <perf_unwind_v8+0x58fc>
    586c:      	ldr	x8, [sp, #0x70]
    5870:      	and	x9, x8, #0x3
    5874:      	cmp	x9, #0x1
    5878:      	b.ne	0x58fc <perf_unwind_v8+0x58fc>
    587c:      	and	x8, x8, #0xfffffffffffffffc
    5880:      	mov	x22, x8
    5884:      	cbz	x8, 0x5904 <perf_unwind_v8+0x5904>
    5888:      	ldrb	w8, [x23, #0xc]
    588c:      	mov	w9, #0x70               // =112
    5890:      	add	x10, sp, #0x70
    5894:      	add	x0, sp, #0x70
    5898:      	mov	w1, #0x8                // =8
    589c:      	add	x2, x22, x8
    58a0:      	mov	w8, #0x8                // =8
    58a4:      	blr	x9
    58a8:      	cbnz	x0, 0x5900 <perf_unwind_v8+0x5900>
    58ac:      	ldr	x8, [sp, #0x70]
    58b0:      	and	x9, x8, #0x3
    58b4:      	cmp	x9, #0x1
    58b8:      	b.ne	0x5900 <perf_unwind_v8+0x5900>
    58bc:      	and	x8, x8, #0xfffffffffffffffc
    58c0:      	cbz	x8, 0x5904 <perf_unwind_v8+0x5904>
    58c4:      	ldrb	w9, [x23, #0xd]
    58c8:      	mov	w10, #0x2               // =2
    58cc:      	mov	w11, #0x70              // =112
    58d0:      	add	x12, sp, #0x70
    58d4:      	add	x0, sp, #0x70
    58d8:      	mov	w1, #0x2                // =2
    58dc:      	add	x9, x8, x9
    58e0:      	ldrb	w9, [x23, #0xd]
    58e4:      	add	x2, x8, x9
    58e8:      	blr	x11
    58ec:      	ldrh	w8, [sp, #0x70]
    58f0:      	cmp	x0, #0x0
    58f4:      	csel	w8, w8, wzr, eq
    58f8:      	b	0x5904 <perf_unwind_v8+0x5904>
    58fc:      	mov	x22, xzr
    5900:      	mov	w8, wzr
    5904:      	ldrh	w9, [x23, #0xa]
    5908:      	cmp	w9, w8, uxth
    590c:      	b.ne	0x860 <perf_unwind_v8+0x860>
    5910:      	lsr	x24, x25, #32
    5914:      	cbz	x24, 0x5978 <perf_unwind_v8+0x5978>
    5918:      	tbnz	w25, #0x0, 0x5978 <perf_unwind_v8+0x5978>
    591c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5920:      	ldr	x8, [x8]
    5924:      	ldr	w8, [x8]
    5928:      	cbz	w8, 0x596c <perf_unwind_v8+0x596c>
    592c:      	mov	w8, #0x786c             // =30828
    5930:      	add	x0, sp, #0x70
    5934:      	mov	w1, #0x1c               // =28
    5938:      	mov	x2, x24
    593c:      	movk	w8, #0xa, lsl #16
    5940:      	str	w8, [sp, #0x88]
    5944:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5948:      	add	x8, x8, #0x0
    594c:      	ldp	x9, x10, [x8]
    5950:      	ldr	x8, [x8, #0x10]
    5954:      	stp	x9, x10, [sp, #0x70]
    5958:      	mov	w9, #0x6                // =6
    595c:      	str	x8, [sp, #0x80]
    5960:      	mov	w8, #0x1c               // =28
    5964:      	add	x10, sp, #0x70
    5968:      	blr	x9
    596c:      	orr	x8, x22, #0x1
    5970:      	str	x8, [sp, #0x40]
    5974:      	b	0x5d80 <perf_unwind_v8+0x5d80>
    5978:      	orr	x8, x22, #0x2
    597c:      	ldr	x9, [sp, #0x38]
    5980:      	add	x10, sp, #0x70
    5984:      	add	x0, sp, #0x70
    5988:      	str	x8, [sp, #0x40]
    598c:      	ldrb	w8, [x23, #0xe]
    5990:      	mov	w1, #0x8                // =8
    5994:      	add	x2, x9, x8
    5998:      	mov	w8, #0x8                // =8
    599c:      	mov	w9, #0x70               // =112
    59a0:      	blr	x9
    59a4:      	cbnz	x0, 0x5a34 <perf_unwind_v8+0x5a34>
    59a8:      	ldr	x8, [sp, #0x70]
    59ac:      	and	x9, x8, #0x3
    59b0:      	cmp	x9, #0x1
    59b4:      	b.ne	0x5a34 <perf_unwind_v8+0x5a34>
    59b8:      	and	x24, x8, #0xfffffffffffffffc
    59bc:      	cbz	x24, 0x5a38 <perf_unwind_v8+0x5a38>
    59c0:      	ldrb	w8, [x23, #0xc]
    59c4:      	mov	w9, #0x70               // =112
    59c8:      	add	x10, sp, #0x70
    59cc:      	add	x0, sp, #0x70
    59d0:      	mov	w1, #0x8                // =8
    59d4:      	add	x2, x24, x8
    59d8:      	mov	w8, #0x8                // =8
    59dc:      	blr	x9
    59e0:      	cbnz	x0, 0x5a38 <perf_unwind_v8+0x5a38>
    59e4:      	ldr	x8, [sp, #0x70]
    59e8:      	and	x9, x8, #0x3
    59ec:      	cmp	x9, #0x1
    59f0:      	b.ne	0x5a38 <perf_unwind_v8+0x5a38>
    59f4:      	and	x8, x8, #0xfffffffffffffffc
    59f8:      	cbz	x8, 0x5a3c <perf_unwind_v8+0x5a3c>
    59fc:      	ldrb	w9, [x23, #0xd]
    5a00:      	mov	w10, #0x2               // =2
    5a04:      	mov	w11, #0x70              // =112
    5a08:      	add	x12, sp, #0x70
    5a0c:      	add	x0, sp, #0x70
    5a10:      	mov	w1, #0x2                // =2
    5a14:      	add	x9, x8, x9
    5a18:      	ldrb	w9, [x23, #0xd]
    5a1c:      	add	x2, x8, x9
    5a20:      	blr	x11
    5a24:      	ldrh	w8, [sp, #0x70]
    5a28:      	cmp	x0, #0x0
    5a2c:      	csel	w8, w8, wzr, eq
    5a30:      	b	0x5a3c <perf_unwind_v8+0x5a3c>
    5a34:      	mov	x24, xzr
    5a38:      	mov	w8, wzr
    5a3c:      	and	w4, w8, #0xffff
    5a40:      	ldrh	w8, [x23, #0x8]
    5a44:      	cmp	w4, w8
    5a48:      	b.ne	0x5ae4 <perf_unwind_v8+0x5ae4>
    5a4c:      	ldr	x0, [sp, #0x48]
    5a50:      	mov	w8, #0x60               // =96
    5a54:      	mov	w9, #0x70               // =112
    5a58:      	mov	w1, #0x60               // =96
    5a5c:      	mov	x2, x24
    5a60:      	blr	x9
    5a64:      	cbz	x0, 0x5b74 <perf_unwind_v8+0x5b74>
    5a68:      	mov	w8, #0x3b               // =59
    5a6c:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    5a70:      	add	x9, sp, #0x58
    5a74:      	str	w8, [sp, #0x58]
    5a78:      	mov	w8, #0x1                // =1
    5a7c:      	add	x1, sp, #0x58
    5a80:      	ldr	x0, [x0]
    5a84:      	blr	x8
    5a88:      	cbnz	x0, 0x5b60 <perf_unwind_v8+0x5b60>
    5a8c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5a90:      	ldr	x8, [x8]
    5a94:      	ldr	w8, [x8]
    5a98:      	cbz	w8, 0x5d7c <perf_unwind_v8+0x5d7c>
    5a9c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5aa0:      	add	x8, x8, #0x0
    5aa4:      	add	x0, sp, #0x70
    5aa8:      	ldp	x9, x10, [x8, #0x10]
    5aac:      	mov	w1, #0x2e               // =46
    5ab0:      	stp	x9, x10, [sp, #0x80]
    5ab4:      	ldr	x9, [x8, #0x20]
    5ab8:      	add	x10, sp, #0x70
    5abc:      	str	x9, [sp, #0x90]
    5ac0:      	ldur	x9, [x8, #0x26]
    5ac4:      	stur	x9, [sp, #0x96]
    5ac8:      	ldp	x9, x8, [x8]
    5acc:      	stp	x9, x8, [sp, #0x70]
    5ad0:      	mov	w8, #0x2e               // =46
    5ad4:      	mov	w9, #0x6                // =6
    5ad8:      	ldr	w2, [sp, #0x58]
    5adc:      	blr	x9
    5ae0:      	b	0x5d7c <perf_unwind_v8+0x5d7c>
    5ae4:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5ae8:      	ldr	x8, [x8]
    5aec:      	ldr	w8, [x8]
    5af0:      	cbz	w8, 0x5b3c <perf_unwind_v8+0x5b3c>
    5af4:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5af8:      	add	x8, x8, #0x0
    5afc:      	add	x0, sp, #0x70
    5b00:      	ldp	x9, x10, [x8, #0x10]
    5b04:      	mov	w1, #0x2e               // =46
    5b08:      	mov	x3, x24
    5b0c:      	stp	x9, x10, [sp, #0x80]
    5b10:      	ldr	x9, [x8, #0x20]
    5b14:      	add	x10, sp, #0x70
    5b18:      	str	x9, [sp, #0x90]
    5b1c:      	ldur	x9, [x8, #0x26]
    5b20:      	stur	x9, [sp, #0x96]
    5b24:      	ldp	x9, x8, [x8]
    5b28:      	stp	x9, x8, [sp, #0x70]
    5b2c:      	mov	w8, #0x2e               // =46
    5b30:      	mov	w9, #0x6                // =6
    5b34:      	ldr	x2, [sp, #0x38]
    5b38:      	blr	x9
    5b3c:      	mov	w8, #0x3b               // =59
    5b40:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    5b44:      	add	x9, sp, #0x58
    5b48:      	str	w8, [sp, #0x58]
    5b4c:      	mov	w8, #0x1                // =1
    5b50:      	add	x1, sp, #0x58
    5b54:      	ldr	x0, [x0]
    5b58:      	blr	x8
    5b5c:      	cbz	x0, 0x5ba4 <perf_unwind_v8+0x5ba4>
    5b60:      	ldr	x8, [x0]
    5b64:      	mov	x24, xzr
    5b68:      	add	x8, x8, #0x1
    5b6c:      	str	x8, [x0]
    5b70:      	b	0x5d80 <perf_unwind_v8+0x5d80>
    5b74:      	ldrb	w8, [x23, #0x12]
    5b78:      	cmp	x8, #0x5c
    5b7c:      	b.hi	0x250 <perf_unwind_v8+0x250>
    5b80:      	ldrb	w9, [x23, #0x13]
    5b84:      	cmp	x9, #0x5c
    5b88:      	b.hi	0x250 <perf_unwind_v8+0x250>
    5b8c:      	ldrb	w11, [x23, #0x10]
    5b90:      	ldrb	w10, [x23, #0x11]
    5b94:      	cbz	w11, 0x5bfc <perf_unwind_v8+0x5bfc>
    5b98:      	ldr	x11, [sp, #0x48]
    5b9c:      	ldr	x25, [x11, x10]
    5ba0:      	b	0x5c00 <perf_unwind_v8+0x5c00>
    5ba4:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5ba8:      	ldr	x8, [x8]
    5bac:      	ldr	w8, [x8]
    5bb0:      	cbz	w8, 0x5d7c <perf_unwind_v8+0x5d7c>
    5bb4:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5bb8:      	add	x8, x8, #0x0
    5bbc:      	add	x0, sp, #0x70
    5bc0:      	ldp	x9, x10, [x8, #0x10]
    5bc4:      	mov	w1, #0x2e               // =46
    5bc8:      	stp	x9, x10, [sp, #0x80]
    5bcc:      	ldr	x9, [x8, #0x20]
    5bd0:      	add	x10, sp, #0x70
    5bd4:      	str	x9, [sp, #0x90]
    5bd8:      	ldur	x9, [x8, #0x26]
    5bdc:      	stur	x9, [sp, #0x96]
    5be0:      	ldp	x9, x8, [x8]
    5be4:      	stp	x9, x8, [sp, #0x70]
    5be8:      	mov	w8, #0x2e               // =46
    5bec:      	mov	w9, #0x6                // =6
    5bf0:      	ldr	w2, [sp, #0x58]
    5bf4:      	blr	x9
    5bf8:      	b	0x5d7c <perf_unwind_v8+0x5d7c>
    5bfc:      	add	x25, x24, x10
    5c00:      	ldr	x10, [sp, #0x48]
    5c04:      	ldr	w29, [x10, x8]
    5c08:      	ldr	w8, [x10, x9]
    5c0c:      	str	w8, [sp, #0x20]
    5c10:      	ldrb	w8, [x23, #0x18]
    5c14:      	str	w8, [sp, #0x10]
    5c18:      	ldrb	w8, [x23, #0x17]
    5c1c:      	str	x8, [sp, #0x18]
    5c20:      	add	x8, x25, x29
    5c24:      	str	x8, [sp, #0x28]
    5c28:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5c2c:      	ldr	x8, [x8]
    5c30:      	ldr	w8, [x8]
    5c34:      	cbz	w8, 0x5cd4 <perf_unwind_v8+0x5cd4>
    5c38:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5c3c:      	add	x8, x8, #0x0
    5c40:      	strb	wzr, [sp, #0x98]
    5c44:      	add	x0, sp, #0x70
    5c48:      	ldp	x9, x10, [x8, #0x10]
    5c4c:      	mov	w1, #0x29               // =41
    5c50:      	mov	x3, x22
    5c54:      	mov	x4, x24
    5c58:      	stp	x9, x10, [sp, #0x80]
    5c5c:      	ldr	x9, [x8, #0x20]
    5c60:      	add	x10, sp, #0x70
    5c64:      	str	x9, [sp, #0x90]
    5c68:      	ldp	x8, x9, [x8]
    5c6c:      	stp	x8, x9, [sp, #0x70]
    5c70:      	mov	w8, #0x29               // =41
    5c74:      	mov	w9, #0x6                // =6
    5c78:      	ldr	x2, [sp, #0x38]
    5c7c:      	blr	x9
    5c80:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5c84:      	ldr	x8, [x8]
    5c88:      	ldr	w8, [x8]
    5c8c:      	cbz	w8, 0x5cd4 <perf_unwind_v8+0x5cd4>
    5c90:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5c94:      	add	x8, x8, #0x0
    5c98:      	add	x0, sp, #0x70
    5c9c:      	ldp	x9, x10, [x8, #0x10]
    5ca0:      	mov	w1, #0x25               // =37
    5ca4:      	mov	x2, x25
    5ca8:      	mov	w4, w29
    5cac:      	stp	x9, x10, [sp, #0x80]
    5cb0:      	ldur	x9, [x8, #0x1d]
    5cb4:      	add	x10, sp, #0x70
    5cb8:      	stur	x9, [sp, #0x8d]
    5cbc:      	ldp	x8, x9, [x8]
    5cc0:      	stp	x8, x9, [sp, #0x70]
    5cc4:      	mov	w8, #0x25               // =37
    5cc8:      	mov	w9, #0x6                // =6
    5ccc:      	ldr	x3, [sp, #0x28]
    5cd0:      	blr	x9
    5cd4:      	ldr	x8, [sp, #0x30]
    5cd8:      	subs	x8, x8, x25
    5cdc:      	b.lo	0x5d28 <perf_unwind_v8+0x5d28>
    5ce0:      	ldp	x10, x9, [sp, #0x28]
    5ce4:      	cmp	x9, x10
    5ce8:      	b.hs	0x5d28 <perf_unwind_v8+0x5d28>
    5cec:      	ldr	w9, [sp, #0x20]
    5cf0:      	ldr	w10, [sp, #0x10]
    5cf4:      	orr	x12, x24, #0x3
    5cf8:      	and	w9, w9, w10
    5cfc:      	ldr	x10, [sp, #0x18]
    5d00:      	ldr	x11, [sp, #0x38]
    5d04:      	orr	x11, x11, #0x4
    5d08:      	lsr	w9, w9, w10
    5d0c:      	ldrb	w10, [x23, #0x19]
    5d10:      	cmp	w9, w10
    5d14:      	orr	w9, w9, w29, lsl #4
    5d18:      	csel	x10, x11, x12, eq
    5d1c:      	orr	x24, x8, x9, lsl #32
    5d20:      	str	x10, [sp, #0x40]
    5d24:      	b	0x5d80 <perf_unwind_v8+0x5d80>
    5d28:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5d2c:      	ldr	x8, [x8]
    5d30:      	ldr	w8, [x8]
    5d34:      	cbnz	w8, 0x5d44 <perf_unwind_v8+0x5d44>
    5d38:      	ldrb	w25, [x21, #0xf20]
    5d3c:      	mov	x24, xzr
    5d40:      	b	0x5de8 <perf_unwind_v8+0x5de8>
    5d44:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5d48:      	add	x8, x8, #0x0
    5d4c:      	add	x0, sp, #0x70
    5d50:      	ldp	x9, x10, [x8, #0x10]
    5d54:      	mov	w1, #0x30               // =48
    5d58:      	stp	x9, x10, [sp, #0x80]
    5d5c:      	ldp	x9, x10, [x8, #0x20]
    5d60:      	stp	x9, x10, [sp, #0x90]
    5d64:      	ldp	x9, x8, [x8]
    5d68:      	add	x10, sp, #0x70
    5d6c:      	stp	x9, x8, [sp, #0x70]
    5d70:      	mov	w8, #0x30               // =48
    5d74:      	mov	w9, #0x6                // =6
    5d78:      	blr	x9
    5d7c:      	mov	x24, xzr
    5d80:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5d84:      	ldr	x8, [x8]
    5d88:      	ldrb	w25, [x21, #0xf20]
    5d8c:      	ldr	w8, [x8]
    5d90:      	cbz	w8, 0x5de8 <perf_unwind_v8+0x5de8>
    5d94:      	mov	w8, #0x786c             // =30828
    5d98:      	add	x0, sp, #0x70
    5d9c:      	mov	w1, #0x3c               // =60
    5da0:      	mov	x2, x24
    5da4:      	movk	w8, #0xa, lsl #16
    5da8:      	str	w8, [sp, #0xa8]
    5dac:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5db0:      	add	x8, x8, #0x0
    5db4:      	ldp	x9, x10, [x8, #0x20]
    5db8:      	stp	x9, x10, [sp, #0x90]
    5dbc:      	ldr	x9, [x8, #0x30]
    5dc0:      	str	x9, [sp, #0xa0]
    5dc4:      	ldp	x9, x10, [x8]
    5dc8:      	stp	x9, x10, [sp, #0x70]
    5dcc:      	add	x10, sp, #0x70
    5dd0:      	ldp	x8, x9, [x8, #0x10]
    5dd4:      	stp	x8, x9, [sp, #0x80]
    5dd8:      	mov	w8, #0x3c               // =60
    5ddc:      	mov	w9, #0x6                // =6
    5de0:      	ldr	x3, [sp, #0x40]
    5de4:      	blr	x9
    5de8:      	ldr	w8, [x21, #0x2c0]
    5dec:      	cmp	w8, #0x7e
    5df0:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    5df4:      	add	w9, w8, #0x1
    5df8:      	mov	w10, #0x8               // =8
    5dfc:      	add	x11, sp, #0x70
    5e00:      	str	w9, [x21, #0x2c0]
    5e04:      	mov	w9, #0x18               // =24
    5e08:      	add	x0, sp, #0x70
    5e0c:      	mov	w1, #0x10               // =16
    5e10:      	umaddl	x8, w8, w9, x21
    5e14:      	ldr	x9, [sp, #0x40]
    5e18:      	str	x24, [x8, #0x2d8]
    5e1c:      	strb	w10, [x8, #0x2e0]
    5e20:      	strb	w25, [x8, #0x2e1]
    5e24:      	strh	wzr, [x8, #0x2e6]
    5e28:      	mov	w10, #0x70              // =112
    5e2c:      	str	x9, [x8, #0x2d0]
    5e30:      	add	x9, x8, #0x2d0
    5e34:      	stur	wzr, [x9, #0x12]
    5e38:      	mov	w9, #0x10               // =16
    5e3c:      	ldr	x8, [x21, #0xee0]
    5e40:      	ldr	x2, [x21, #0xee0]
    5e44:      	blr	x10
    5e48:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    5e4c:      	ldr	x8, [x21, #0xee0]
    5e50:      	add	x9, x8, #0x10
    5e54:      	str	x9, [x21, #0xed8]
    5e58:      	ldp	x9, x10, [sp, #0x70]
    5e5c:      	str	x9, [x21, #0xee0]
    5e60:      	mov	w9, #0x101              // =257
    5e64:      	str	x10, [x21, #0xed0]
    5e68:      	strh	w9, [x21, #0xf20]
    5e6c:      	ldr	x9, [sp, #0x40]
    5e70:      	cbnz	x9, 0x5e84 <perf_unwind_v8+0x5e84>
    5e74:      	cmp	x24, #0x1
    5e78:      	b.ne	0x5e84 <perf_unwind_v8+0x5e84>
    5e7c:      	add	x8, x8, #0xa0
    5e80:      	str	x8, [x21, #0xed8]
    5e84:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5e88:      	ldr	x8, [x8]
    5e8c:      	ldr	w8, [x8]
    5e90:      	cbz	w8, 0x5ed8 <perf_unwind_v8+0x5ed8>
    5e94:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5e98:      	add	x8, x8, #0x0
    5e9c:      	add	x0, sp, #0x70
    5ea0:      	ldp	x9, x10, [x8]
    5ea4:      	mov	w1, #0x1f               // =31
    5ea8:      	stp	x9, x10, [sp, #0x70]
    5eac:      	ldr	x9, [x8, #0x10]
    5eb0:      	ldur	x8, [x8, #0x17]
    5eb4:      	add	x10, sp, #0x70
    5eb8:      	str	x9, [sp, #0x80]
    5ebc:      	stur	x8, [sp, #0x87]
    5ec0:      	mov	w8, #0x1f               // =31
    5ec4:      	mov	w9, #0x6                // =6
    5ec8:      	ldr	x2, [x21, #0xed0]
    5ecc:      	ldr	x3, [x21, #0xed8]
    5ed0:      	ldr	x4, [x21, #0xee0]
    5ed4:      	blr	x9
    5ed8:      	mov	w8, #0x38               // =56
    5edc:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    5ee0:      	add	x9, sp, #0x58
    5ee4:      	str	w8, [sp, #0x58]
    5ee8:      	mov	w8, #0x1                // =1
    5eec:      	add	x1, sp, #0x58
    5ef0:      	ldr	x0, [x0]
    5ef4:      	blr	x8
    5ef8:      	cbz	x0, 0x5f0c <perf_unwind_v8+0x5f0c>
    5efc:      	ldr	x8, [x0]
    5f00:      	add	x8, x8, #0x1
    5f04:      	str	x8, [x0]
    5f08:      	b	0x5f60 <perf_unwind_v8+0x5f60>
    5f0c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5f10:      	ldr	x8, [x8]
    5f14:      	ldr	w8, [x8]
    5f18:      	cbz	w8, 0x5f6c <perf_unwind_v8+0x5f6c>
    5f1c:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5f20:      	add	x8, x8, #0x0
    5f24:      	add	x0, sp, #0x70
    5f28:      	ldp	x9, x10, [x8, #0x10]
    5f2c:      	mov	w1, #0x2e               // =46
    5f30:      	stp	x9, x10, [sp, #0x80]
    5f34:      	ldr	x9, [x8, #0x20]
    5f38:      	add	x10, sp, #0x70
    5f3c:      	str	x9, [sp, #0x90]
    5f40:      	ldur	x9, [x8, #0x26]
    5f44:      	stur	x9, [sp, #0x96]
    5f48:      	ldp	x9, x8, [x8]
    5f4c:      	stp	x9, x8, [sp, #0x70]
    5f50:      	mov	w8, #0x2e               // =46
    5f54:      	mov	w9, #0x6                // =6
    5f58:      	ldr	w2, [sp, #0x58]
    5f5c:      	blr	x9
    5f60:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5f64:      	ldr	x8, [x8]
    5f68:      	ldr	w8, [x8]
    5f6c:      	ldr	x24, [x21, #0xed0]
    5f70:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    5f74:      	cbz	w8, 0x5fbc <perf_unwind_v8+0x5fbc>
    5f78:      	adrp	x8, 0x5000 <perf_unwind_v8+0x5000>
    5f7c:      	add	x8, x8, #0x0
    5f80:      	strb	wzr, [sp, #0xa0]
    5f84:      	add	x0, sp, #0x70
    5f88:      	ldp	x9, x10, [x8, #0x10]
    5f8c:      	mov	w1, #0x31               // =49
    5f90:      	stp	x9, x10, [sp, #0x80]
    5f94:      	ldp	x9, x10, [x8, #0x20]
    5f98:      	stp	x9, x10, [sp, #0x90]
    5f9c:      	ldp	x9, x8, [x8]
    5fa0:      	add	x10, sp, #0x70
    5fa4:      	stp	x9, x8, [sp, #0x70]
    5fa8:      	mov	w8, #0x31               // =49
    5fac:      	mov	w9, #0x6                // =6
    5fb0:      	ldr	w2, [x21, #0x2c0]
    5fb4:      	blr	x9
    5fb8:      	ldr	x24, [x21, #0xed0]
    5fbc:      	lsr	x8, x24, #56
    5fc0:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    5fc4:      	cmp	x24, #0x1, lsl #12      // =0x1000
    5fc8:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    5fcc:      	ldr	w8, [x21]
    5fd0:      	mov	w9, #0x60               // =96
    5fd4:      	adrp	x0, 0x5000 <perf_unwind_v8+0x5000>
    5fd8:      	add	x1, sp, #0x58
    5fdc:      	rev	w8, w8
    5fe0:      	stp	w9, w8, [sp, #0x58]
    5fe4:      	rev	x8, x24
    5fe8:      	add	x9, sp, #0x58
    5fec:      	str	x8, [sp, #0x60]
    5ff0:      	mov	w8, #0x1                // =1
    5ff4:      	ldr	x0, [x0]
    5ff8:      	blr	x8
    5ffc:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    6000:      	ldr	x8, [x0, #0x8]
    6004:      	and	x9, x8, #0xffffffffffffff
    6008:      	lsr	x29, x8, #56
    600c:      	str	x9, [x21, #0xf10]
    6010:      	ldr	x8, [x0]
    6014:      	str	x8, [x21, #0xf00]
    6018:      	sub	x8, x24, x9
    601c:      	str	x8, [x21, #0xf08]
    6020:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6024:      	ldr	x8, [x8]
    6028:      	ldr	w8, [x8]
    602c:      	cbz	w8, 0x60d4 <perf_unwind_v8+0x60d4>
    6030:      	mov	w8, #0xa                // =10
    6034:      	add	x0, sp, #0x70
    6038:      	mov	w1, #0x32               // =50
    603c:      	strh	w8, [sp, #0xa0]
    6040:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6044:      	add	x8, x8, #0x0
    6048:      	mov	x2, x24
    604c:      	ldp	x9, x10, [x8, #0x10]
    6050:      	mov	w4, w29
    6054:      	stp	x9, x10, [sp, #0x80]
    6058:      	ldp	x9, x10, [x8, #0x20]
    605c:      	stp	x9, x10, [sp, #0x90]
    6060:      	ldp	x9, x8, [x8]
    6064:      	add	x10, sp, #0x70
    6068:      	stp	x9, x8, [sp, #0x70]
    606c:      	mov	w8, #0x32               // =50
    6070:      	mov	w9, #0x6                // =6
    6074:      	ldr	x3, [x21, #0xf00]
    6078:      	blr	x9
    607c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6080:      	ldr	x8, [x8]
    6084:      	ldr	w8, [x8]
    6088:      	cbz	w8, 0x60d4 <perf_unwind_v8+0x60d4>
    608c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6090:      	add	x8, x8, #0x0
    6094:      	add	x0, sp, #0x70
    6098:      	ldp	x9, x10, [x8, #0x10]
    609c:      	mov	w1, #0x2f               // =47
    60a0:      	stp	x9, x10, [sp, #0x80]
    60a4:      	ldr	x9, [x8, #0x20]
    60a8:      	add	x10, sp, #0x70
    60ac:      	str	x9, [sp, #0x90]
    60b0:      	ldur	x9, [x8, #0x27]
    60b4:      	stur	x9, [sp, #0x97]
    60b8:      	ldp	x9, x8, [x8]
    60bc:      	stp	x9, x8, [sp, #0x70]
    60c0:      	mov	w8, #0x2f               // =47
    60c4:      	mov	w9, #0x6                // =6
    60c8:      	ldr	x2, [x21, #0xf10]
    60cc:      	ldr	x3, [x21, #0xf08]
    60d0:      	blr	x9
    60d4:      	cmp	w29, #0x1
    60d8:      	b.ne	0x6280 <perf_unwind_v8+0x6280>
    60dc:      	ldr	x8, [x21, #0xf00]
    60e0:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    60e4:      	ldr	x25, [x21, #0xf08]
    60e8:      	mov	w9, #0x1                // =1
    60ec:      	add	x1, sp, #0x58
    60f0:      	mov	w29, #0x1               // =1
    60f4:      	str	x8, [sp, #0x58]
    60f8:      	add	x8, sp, #0x58
    60fc:      	ldr	x0, [x0]
    6100:      	blr	x9
    6104:      	cbz	x0, 0x61b0 <perf_unwind_v8+0x61b0>
    6108:      	ldr	x8, [x0]
    610c:      	mov	x24, x0
    6110:      	cmp	x8, x25
    6114:      	b.hi	0x6124 <perf_unwind_v8+0x6124>
    6118:      	ldr	x8, [x24, #0x8]
    611c:      	cmp	x8, x25
    6120:      	b.hs	0x613c <perf_unwind_v8+0x613c>
    6124:      	ldr	x8, [x24, #0x10]
    6128:      	cmp	x8, x25
    612c:      	b.hi	0x61a8 <perf_unwind_v8+0x61a8>
    6130:      	ldr	x8, [x24, #0x18]
    6134:      	cmp	x8, x25
    6138:      	b.lo	0x61a8 <perf_unwind_v8+0x61a8>
    613c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6140:      	ldr	x8, [x8]
    6144:      	ldr	w8, [x8]
    6148:      	cbz	w8, 0x6188 <perf_unwind_v8+0x6188>
    614c:      	adrp	x10, 0x6000 <perf_unwind_v8+0x6000>
    6150:      	add	x10, x10, #0x0
    6154:      	add	x0, sp, #0x70
    6158:      	ldp	x8, x9, [x10]
    615c:      	mov	w1, #0x1e               // =30
    6160:      	stp	x8, x9, [sp, #0x70]
    6164:      	ldr	x8, [x10, #0x10]
    6168:      	mov	w9, #0x6                // =6
    616c:      	str	x8, [sp, #0x80]
    6170:      	ldur	x8, [x10, #0x16]
    6174:      	add	x10, sp, #0x70
    6178:      	stur	x8, [sp, #0x86]
    617c:      	mov	w8, #0x1e               // =30
    6180:      	ldrh	w2, [x24, #0x20]
    6184:      	blr	x9
    6188:      	ldrh	w8, [x24, #0x20]
    618c:      	ldr	w9, [x21, #0x1370]
    6190:      	lsr	w8, w9, w8
    6194:      	tbz	w8, #0x0, 0x61b4 <perf_unwind_v8+0x61b4>
    6198:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    619c:      	ldr	x8, [x8]
    61a0:      	ldr	w8, [x8]
    61a4:      	cbnz	w8, 0x61e4 <perf_unwind_v8+0x61e4>
    61a8:      	mov	w29, #0x1               // =1
    61ac:      	b	0x6280 <perf_unwind_v8+0x6280>
    61b0:      	b	0x6280 <perf_unwind_v8+0x6280>
    61b4:      	str	wzr, [sp, #0xbc]
    61b8:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    61bc:      	mov	w8, #0x1                // =1
    61c0:      	add	x9, sp, #0xbc
    61c4:      	ldr	x0, [x0]
    61c8:      	add	x1, sp, #0xbc
    61cc:      	blr	x8
    61d0:      	cbz	x0, 0x6228 <perf_unwind_v8+0x6228>
    61d4:      	ldr	x8, [x0]
    61d8:      	add	x8, x8, #0x1
    61dc:      	str	x8, [x0]
    61e0:      	b	0x627c <perf_unwind_v8+0x627c>
    61e4:      	mov	w8, #0x656e             // =25966
    61e8:      	adrp	x10, 0x6000 <perf_unwind_v8+0x6000>
    61ec:      	add	x10, x10, #0x0
    61f0:      	add	x0, sp, #0x70
    61f4:      	mov	w1, #0x1b               // =27
    61f8:      	movk	w8, #0xa, lsl #16
    61fc:      	stur	w8, [sp, #0x87]
    6200:      	ldp	x8, x9, [x10]
    6204:      	stp	x8, x9, [sp, #0x70]
    6208:      	ldr	x8, [x10, #0x10]
    620c:      	mov	w9, #0x6                // =6
    6210:      	add	x10, sp, #0x70
    6214:      	str	x8, [sp, #0x80]
    6218:      	mov	w8, #0x1b               // =27
    621c:      	blr	x9
    6220:      	mov	w29, #0x1               // =1
    6224:      	b	0x6280 <perf_unwind_v8+0x6280>
    6228:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    622c:      	ldr	x8, [x8]
    6230:      	ldr	w8, [x8]
    6234:      	cbz	w8, 0x627c <perf_unwind_v8+0x627c>
    6238:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    623c:      	add	x8, x8, #0x0
    6240:      	add	x0, sp, #0x70
    6244:      	ldp	x9, x10, [x8, #0x10]
    6248:      	mov	w1, #0x2e               // =46
    624c:      	stp	x9, x10, [sp, #0x80]
    6250:      	ldr	x9, [x8, #0x20]
    6254:      	add	x10, sp, #0x70
    6258:      	str	x9, [sp, #0x90]
    625c:      	ldur	x9, [x8, #0x26]
    6260:      	stur	x9, [sp, #0x96]
    6264:      	ldp	x9, x8, [x8]
    6268:      	stp	x9, x8, [sp, #0x70]
    626c:      	mov	w8, #0x2e               // =46
    6270:      	mov	w9, #0x6                // =6
    6274:      	ldr	w2, [sp, #0xbc]
    6278:      	blr	x9
    627c:      	ldrh	w29, [x24, #0x20]
    6280:      	cmp	w29, #0x7
    6284:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    6288:      	ldr	x8, [x21, #0xed0]
    628c:      	ldr	x29, [x21, #0xed8]
    6290:      	ldr	x25, [x21, #0xee0]
    6294:      	str	x8, [sp, #0x38]
    6298:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    629c:      	ldr	x8, [x8]
    62a0:      	ldr	w8, [x8]
    62a4:      	cbz	w8, 0x62ec <perf_unwind_v8+0x62ec>
    62a8:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    62ac:      	add	x8, x8, #0x0
    62b0:      	add	x0, sp, #0x70
    62b4:      	ldp	x9, x10, [x8]
    62b8:      	mov	w1, #0x1f               // =31
    62bc:      	mov	x3, x29
    62c0:      	mov	x4, x25
    62c4:      	stp	x9, x10, [sp, #0x70]
    62c8:      	ldr	x9, [x8, #0x10]
    62cc:      	ldur	x8, [x8, #0x17]
    62d0:      	add	x10, sp, #0x70
    62d4:      	str	x9, [sp, #0x80]
    62d8:      	stur	x8, [sp, #0x87]
    62dc:      	mov	w8, #0x1f               // =31
    62e0:      	mov	w9, #0x6                // =6
    62e4:      	ldr	x2, [sp, #0x38]
    62e8:      	blr	x9
    62ec:      	cmp	x25, x29
    62f0:      	b.lo	0x1954 <perf_unwind_v8+0x1954>
    62f4:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    62f8:      	cmp	x25, x8
    62fc:      	b.hs	0x1954 <perf_unwind_v8+0x1954>
    6300:      	ldr	x0, [sp, #0x50]
    6304:      	sub	x2, x25, #0x40
    6308:      	mov	w8, #0x40               // =64
    630c:      	mov	w9, #0x70               // =112
    6310:      	mov	w1, #0x40               // =64
    6314:      	blr	x9
    6318:      	cbnz	x0, 0x19c <perf_unwind_v8+0x19c>
    631c:      	ldrb	w9, [x23, #0x14]
    6320:      	cmp	x9, #0x38
    6324:      	b.hi	0x250 <perf_unwind_v8+0x250>
    6328:      	ldrb	w8, [x23, #0x15]
    632c:      	cmp	x8, #0x38
    6330:      	b.hi	0x250 <perf_unwind_v8+0x250>
    6334:      	ldrb	w10, [x23, #0x16]
    6338:      	cmp	x10, #0x38
    633c:      	b.hi	0x250 <perf_unwind_v8+0x250>
    6340:      	ldr	x11, [sp, #0x50]
    6344:      	ldr	x9, [x11, x9]
    6348:      	tbnz	w9, #0x0, 0x636c <perf_unwind_v8+0x636c>
    634c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6350:      	lsr	x24, x9, #1
    6354:      	ldr	x8, [x8]
    6358:      	ldr	w8, [x8]
    635c:      	cbnz	w8, 0x6408 <perf_unwind_v8+0x6408>
    6360:      	ldrb	w23, [x21, #0xf20]
    6364:      	str	xzr, [sp, #0x50]
    6368:      	b	0x6a10 <perf_unwind_v8+0x6a10>
    636c:      	ldr	x22, [sp, #0x50]
    6370:      	ldr	x8, [x22, x8]
    6374:      	ldr	x25, [x22, x10]
    6378:      	and	x9, x8, #0x3
    637c:      	and	x8, x8, #0xfffffffffffffffc
    6380:      	cmp	x9, #0x1
    6384:      	csel	x8, x8, xzr, eq
    6388:      	str	x8, [sp, #0x40]
    638c:      	cbz	x8, 0x6450 <perf_unwind_v8+0x6450>
    6390:      	ldrb	w8, [x23, #0xc]
    6394:      	ldr	x9, [sp, #0x40]
    6398:      	add	x10, sp, #0x70
    639c:      	add	x0, sp, #0x70
    63a0:      	mov	w1, #0x8                // =8
    63a4:      	add	x2, x9, x8
    63a8:      	mov	w8, #0x8                // =8
    63ac:      	mov	w9, #0x70               // =112
    63b0:      	blr	x9
    63b4:      	cbnz	x0, 0x644c <perf_unwind_v8+0x644c>
    63b8:      	ldr	x8, [sp, #0x70]
    63bc:      	and	x9, x8, #0x3
    63c0:      	cmp	x9, #0x1
    63c4:      	b.ne	0x644c <perf_unwind_v8+0x644c>
    63c8:      	and	x8, x8, #0xfffffffffffffffc
    63cc:      	cbz	x8, 0x6450 <perf_unwind_v8+0x6450>
    63d0:      	ldrb	w9, [x23, #0xd]
    63d4:      	mov	w10, #0x2               // =2
    63d8:      	mov	w11, #0x70              // =112
    63dc:      	add	x12, sp, #0x70
    63e0:      	add	x0, sp, #0x70
    63e4:      	mov	w1, #0x2                // =2
    63e8:      	add	x9, x8, x9
    63ec:      	ldrb	w9, [x23, #0xd]
    63f0:      	add	x2, x8, x9
    63f4:      	blr	x11
    63f8:      	ldrh	w8, [sp, #0x70]
    63fc:      	cmp	x0, #0x0
    6400:      	csel	w8, w8, wzr, eq
    6404:      	b	0x6450 <perf_unwind_v8+0x6450>
    6408:      	adrp	x10, 0x6000 <perf_unwind_v8+0x6000>
    640c:      	add	x10, x10, #0x0
    6410:      	add	x0, sp, #0x70
    6414:      	ldp	x8, x9, [x10]
    6418:      	mov	w1, #0x1d               // =29
    641c:      	mov	x2, x24
    6420:      	stp	x8, x9, [sp, #0x70]
    6424:      	ldr	x8, [x10, #0x10]
    6428:      	mov	w9, #0x6                // =6
    642c:      	str	x8, [sp, #0x80]
    6430:      	ldur	x8, [x10, #0x15]
    6434:      	add	x10, sp, #0x70
    6438:      	stur	x8, [sp, #0x85]
    643c:      	mov	w8, #0x1d               // =29
    6440:      	blr	x9
    6444:      	str	xzr, [sp, #0x50]
    6448:      	b	0x69a8 <perf_unwind_v8+0x69a8>
    644c:      	mov	w8, wzr
    6450:      	ldrh	w9, [x23, #0x4]
    6454:      	cmp	w9, w8, uxth
    6458:      	b.hi	0x3a4 <perf_unwind_v8+0x3a4>
    645c:      	ldrh	w9, [x23, #0x6]
    6460:      	cmp	w9, w8, uxth
    6464:      	b.lo	0x3a4 <perf_unwind_v8+0x3a4>
    6468:      	ldrb	w8, [x23, #0xf]
    646c:      	ldr	x9, [sp, #0x40]
    6470:      	add	x10, sp, #0x70
    6474:      	add	x0, sp, #0x70
    6478:      	mov	w1, #0x8                // =8
    647c:      	add	x2, x9, x8
    6480:      	mov	w8, #0x8                // =8
    6484:      	mov	w9, #0x70               // =112
    6488:      	blr	x9
    648c:      	cbnz	x0, 0x6520 <perf_unwind_v8+0x6520>
    6490:      	ldr	x8, [sp, #0x70]
    6494:      	and	x9, x8, #0x3
    6498:      	cmp	x9, #0x1
    649c:      	b.ne	0x6520 <perf_unwind_v8+0x6520>
    64a0:      	and	x8, x8, #0xfffffffffffffffc
    64a4:      	mov	x22, x8
    64a8:      	cbz	x8, 0x6528 <perf_unwind_v8+0x6528>
    64ac:      	ldrb	w8, [x23, #0xc]
    64b0:      	mov	w9, #0x70               // =112
    64b4:      	add	x10, sp, #0x70
    64b8:      	add	x0, sp, #0x70
    64bc:      	mov	w1, #0x8                // =8
    64c0:      	add	x2, x22, x8
    64c4:      	mov	w8, #0x8                // =8
    64c8:      	blr	x9
    64cc:      	cbnz	x0, 0x6524 <perf_unwind_v8+0x6524>
    64d0:      	ldr	x8, [sp, #0x70]
    64d4:      	and	x9, x8, #0x3
    64d8:      	cmp	x9, #0x1
    64dc:      	b.ne	0x6524 <perf_unwind_v8+0x6524>
    64e0:      	and	x8, x8, #0xfffffffffffffffc
    64e4:      	cbz	x8, 0x6528 <perf_unwind_v8+0x6528>
    64e8:      	ldrb	w9, [x23, #0xd]
    64ec:      	mov	w10, #0x2               // =2
    64f0:      	mov	w11, #0x70              // =112
    64f4:      	add	x12, sp, #0x70
    64f8:      	add	x0, sp, #0x70
    64fc:      	mov	w1, #0x2                // =2
    6500:      	add	x9, x8, x9
    6504:      	ldrb	w9, [x23, #0xd]
    6508:      	add	x2, x8, x9
    650c:      	blr	x11
    6510:      	ldrh	w8, [sp, #0x70]
    6514:      	cmp	x0, #0x0
    6518:      	csel	w8, w8, wzr, eq
    651c:      	b	0x6528 <perf_unwind_v8+0x6528>
    6520:      	mov	x22, xzr
    6524:      	mov	w8, wzr
    6528:      	ldrh	w9, [x23, #0xa]
    652c:      	cmp	w9, w8, uxth
    6530:      	b.ne	0x860 <perf_unwind_v8+0x860>
    6534:      	lsr	x24, x25, #32
    6538:      	cbz	x24, 0x659c <perf_unwind_v8+0x659c>
    653c:      	tbnz	w25, #0x0, 0x659c <perf_unwind_v8+0x659c>
    6540:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6544:      	ldr	x8, [x8]
    6548:      	ldr	w8, [x8]
    654c:      	cbz	w8, 0x6590 <perf_unwind_v8+0x6590>
    6550:      	mov	w8, #0x786c             // =30828
    6554:      	add	x0, sp, #0x70
    6558:      	mov	w1, #0x1c               // =28
    655c:      	mov	x2, x24
    6560:      	movk	w8, #0xa, lsl #16
    6564:      	str	w8, [sp, #0x88]
    6568:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    656c:      	add	x8, x8, #0x0
    6570:      	ldp	x9, x10, [x8]
    6574:      	ldr	x8, [x8, #0x10]
    6578:      	stp	x9, x10, [sp, #0x70]
    657c:      	mov	w9, #0x6                // =6
    6580:      	str	x8, [sp, #0x80]
    6584:      	mov	w8, #0x1c               // =28
    6588:      	add	x10, sp, #0x70
    658c:      	blr	x9
    6590:      	orr	x8, x22, #0x1
    6594:      	str	x8, [sp, #0x50]
    6598:      	b	0x69a8 <perf_unwind_v8+0x69a8>
    659c:      	orr	x8, x22, #0x2
    65a0:      	ldr	x9, [sp, #0x40]
    65a4:      	add	x10, sp, #0x70
    65a8:      	add	x0, sp, #0x70
    65ac:      	str	x8, [sp, #0x50]
    65b0:      	ldrb	w8, [x23, #0xe]
    65b4:      	mov	w1, #0x8                // =8
    65b8:      	add	x2, x9, x8
    65bc:      	mov	w8, #0x8                // =8
    65c0:      	mov	w9, #0x70               // =112
    65c4:      	blr	x9
    65c8:      	cbnz	x0, 0x6658 <perf_unwind_v8+0x6658>
    65cc:      	ldr	x8, [sp, #0x70]
    65d0:      	and	x9, x8, #0x3
    65d4:      	cmp	x9, #0x1
    65d8:      	b.ne	0x6658 <perf_unwind_v8+0x6658>
    65dc:      	and	x24, x8, #0xfffffffffffffffc
    65e0:      	cbz	x24, 0x665c <perf_unwind_v8+0x665c>
    65e4:      	ldrb	w8, [x23, #0xc]
    65e8:      	mov	w9, #0x70               // =112
    65ec:      	add	x10, sp, #0x70
    65f0:      	add	x0, sp, #0x70
    65f4:      	mov	w1, #0x8                // =8
    65f8:      	add	x2, x24, x8
    65fc:      	mov	w8, #0x8                // =8
    6600:      	blr	x9
    6604:      	cbnz	x0, 0x665c <perf_unwind_v8+0x665c>
    6608:      	ldr	x8, [sp, #0x70]
    660c:      	and	x9, x8, #0x3
    6610:      	cmp	x9, #0x1
    6614:      	b.ne	0x665c <perf_unwind_v8+0x665c>
    6618:      	and	x8, x8, #0xfffffffffffffffc
    661c:      	cbz	x8, 0x6660 <perf_unwind_v8+0x6660>
    6620:      	ldrb	w9, [x23, #0xd]
    6624:      	mov	w10, #0x2               // =2
    6628:      	mov	w11, #0x70              // =112
    662c:      	add	x12, sp, #0x70
    6630:      	add	x0, sp, #0x70
    6634:      	mov	w1, #0x2                // =2
    6638:      	add	x9, x8, x9
    663c:      	ldrb	w9, [x23, #0xd]
    6640:      	add	x2, x8, x9
    6644:      	blr	x11
    6648:      	ldrh	w8, [sp, #0x70]
    664c:      	cmp	x0, #0x0
    6650:      	csel	w8, w8, wzr, eq
    6654:      	b	0x6660 <perf_unwind_v8+0x6660>
    6658:      	mov	x24, xzr
    665c:      	mov	w8, wzr
    6660:      	and	w4, w8, #0xffff
    6664:      	ldrh	w8, [x23, #0x8]
    6668:      	cmp	w4, w8
    666c:      	b.ne	0x670c <perf_unwind_v8+0x670c>
    6670:      	ldr	x0, [sp, #0x48]
    6674:      	mov	w8, #0x60               // =96
    6678:      	mov	w9, #0x70               // =112
    667c:      	mov	w1, #0x60               // =96
    6680:      	mov	x2, x24
    6684:      	mov	x25, x0
    6688:      	blr	x9
    668c:      	cbz	x0, 0x679c <perf_unwind_v8+0x679c>
    6690:      	mov	w8, #0x3b               // =59
    6694:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    6698:      	add	x9, sp, #0x58
    669c:      	str	w8, [sp, #0x58]
    66a0:      	mov	w8, #0x1                // =1
    66a4:      	add	x1, sp, #0x58
    66a8:      	ldr	x0, [x0]
    66ac:      	blr	x8
    66b0:      	cbnz	x0, 0x6788 <perf_unwind_v8+0x6788>
    66b4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    66b8:      	ldr	x8, [x8]
    66bc:      	ldr	w8, [x8]
    66c0:      	cbz	w8, 0x69a4 <perf_unwind_v8+0x69a4>
    66c4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    66c8:      	add	x8, x8, #0x0
    66cc:      	add	x0, sp, #0x70
    66d0:      	ldp	x9, x10, [x8, #0x10]
    66d4:      	mov	w1, #0x2e               // =46
    66d8:      	stp	x9, x10, [sp, #0x80]
    66dc:      	ldr	x9, [x8, #0x20]
    66e0:      	add	x10, sp, #0x70
    66e4:      	str	x9, [sp, #0x90]
    66e8:      	ldur	x9, [x8, #0x26]
    66ec:      	stur	x9, [sp, #0x96]
    66f0:      	ldp	x9, x8, [x8]
    66f4:      	stp	x9, x8, [sp, #0x70]
    66f8:      	mov	w8, #0x2e               // =46
    66fc:      	mov	w9, #0x6                // =6
    6700:      	ldr	w2, [sp, #0x58]
    6704:      	blr	x9
    6708:      	b	0x69a4 <perf_unwind_v8+0x69a4>
    670c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6710:      	ldr	x8, [x8]
    6714:      	ldr	w8, [x8]
    6718:      	cbz	w8, 0x6764 <perf_unwind_v8+0x6764>
    671c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6720:      	add	x8, x8, #0x0
    6724:      	add	x0, sp, #0x70
    6728:      	ldp	x9, x10, [x8, #0x10]
    672c:      	mov	w1, #0x2e               // =46
    6730:      	mov	x3, x24
    6734:      	stp	x9, x10, [sp, #0x80]
    6738:      	ldr	x9, [x8, #0x20]
    673c:      	add	x10, sp, #0x70
    6740:      	str	x9, [sp, #0x90]
    6744:      	ldur	x9, [x8, #0x26]
    6748:      	stur	x9, [sp, #0x96]
    674c:      	ldp	x9, x8, [x8]
    6750:      	stp	x9, x8, [sp, #0x70]
    6754:      	mov	w8, #0x2e               // =46
    6758:      	mov	w9, #0x6                // =6
    675c:      	ldr	x2, [sp, #0x40]
    6760:      	blr	x9
    6764:      	mov	w8, #0x3b               // =59
    6768:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    676c:      	add	x9, sp, #0x58
    6770:      	str	w8, [sp, #0x58]
    6774:      	mov	w8, #0x1                // =1
    6778:      	add	x1, sp, #0x58
    677c:      	ldr	x0, [x0]
    6780:      	blr	x8
    6784:      	cbz	x0, 0x67c8 <perf_unwind_v8+0x67c8>
    6788:      	ldr	x8, [x0]
    678c:      	mov	x24, xzr
    6790:      	add	x8, x8, #0x1
    6794:      	str	x8, [x0]
    6798:      	b	0x69a8 <perf_unwind_v8+0x69a8>
    679c:      	ldrb	w8, [x23, #0x12]
    67a0:      	cmp	x8, #0x5c
    67a4:      	b.hi	0x250 <perf_unwind_v8+0x250>
    67a8:      	ldrb	w9, [x23, #0x13]
    67ac:      	cmp	x9, #0x5c
    67b0:      	b.hi	0x250 <perf_unwind_v8+0x250>
    67b4:      	ldrb	w11, [x23, #0x10]
    67b8:      	ldrb	w10, [x23, #0x11]
    67bc:      	cbz	w11, 0x6820 <perf_unwind_v8+0x6820>
    67c0:      	ldr	x29, [x25, x10]
    67c4:      	b	0x6824 <perf_unwind_v8+0x6824>
    67c8:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    67cc:      	ldr	x8, [x8]
    67d0:      	ldr	w8, [x8]
    67d4:      	cbz	w8, 0x69a4 <perf_unwind_v8+0x69a4>
    67d8:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    67dc:      	add	x8, x8, #0x0
    67e0:      	add	x0, sp, #0x70
    67e4:      	ldp	x9, x10, [x8, #0x10]
    67e8:      	mov	w1, #0x2e               // =46
    67ec:      	stp	x9, x10, [sp, #0x80]
    67f0:      	ldr	x9, [x8, #0x20]
    67f4:      	add	x10, sp, #0x70
    67f8:      	str	x9, [sp, #0x90]
    67fc:      	ldur	x9, [x8, #0x26]
    6800:      	stur	x9, [sp, #0x96]
    6804:      	ldp	x9, x8, [x8]
    6808:      	stp	x9, x8, [sp, #0x70]
    680c:      	mov	w8, #0x2e               // =46
    6810:      	mov	w9, #0x6                // =6
    6814:      	ldr	w2, [sp, #0x58]
    6818:      	blr	x9
    681c:      	b	0x69a4 <perf_unwind_v8+0x69a4>
    6820:      	add	x29, x24, x10
    6824:      	mov	x10, x25
    6828:      	ldr	w25, [x25, x8]
    682c:      	ldr	w8, [x10, x9]
    6830:      	str	w8, [sp, #0x30]
    6834:      	ldrb	w8, [x23, #0x18]
    6838:      	str	w8, [sp, #0x20]
    683c:      	ldrb	w8, [x23, #0x17]
    6840:      	str	x8, [sp, #0x28]
    6844:      	add	x8, x29, x25
    6848:      	str	x8, [sp, #0x48]
    684c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6850:      	ldr	x8, [x8]
    6854:      	ldr	w8, [x8]
    6858:      	cbz	w8, 0x68f8 <perf_unwind_v8+0x68f8>
    685c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6860:      	add	x8, x8, #0x0
    6864:      	strb	wzr, [sp, #0x98]
    6868:      	add	x0, sp, #0x70
    686c:      	ldp	x9, x10, [x8, #0x10]
    6870:      	mov	w1, #0x29               // =41
    6874:      	mov	x3, x22
    6878:      	mov	x4, x24
    687c:      	stp	x9, x10, [sp, #0x80]
    6880:      	ldr	x9, [x8, #0x20]
    6884:      	add	x10, sp, #0x70
    6888:      	str	x9, [sp, #0x90]
    688c:      	ldp	x8, x9, [x8]
    6890:      	stp	x8, x9, [sp, #0x70]
    6894:      	mov	w8, #0x29               // =41
    6898:      	mov	w9, #0x6                // =6
    689c:      	ldr	x2, [sp, #0x40]
    68a0:      	blr	x9
    68a4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    68a8:      	ldr	x8, [x8]
    68ac:      	ldr	w8, [x8]
    68b0:      	cbz	w8, 0x68f8 <perf_unwind_v8+0x68f8>
    68b4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    68b8:      	add	x8, x8, #0x0
    68bc:      	add	x0, sp, #0x70
    68c0:      	ldp	x9, x10, [x8, #0x10]
    68c4:      	mov	w1, #0x25               // =37
    68c8:      	mov	x2, x29
    68cc:      	mov	w4, w25
    68d0:      	stp	x9, x10, [sp, #0x80]
    68d4:      	ldur	x9, [x8, #0x1d]
    68d8:      	add	x10, sp, #0x70
    68dc:      	stur	x9, [sp, #0x8d]
    68e0:      	ldp	x8, x9, [x8]
    68e4:      	stp	x8, x9, [sp, #0x70]
    68e8:      	mov	w8, #0x25               // =37
    68ec:      	mov	w9, #0x6                // =6
    68f0:      	ldr	x3, [sp, #0x48]
    68f4:      	blr	x9
    68f8:      	ldr	x8, [sp, #0x38]
    68fc:      	subs	x8, x8, x29
    6900:      	b.lo	0x6950 <perf_unwind_v8+0x6950>
    6904:      	ldr	x9, [sp, #0x38]
    6908:      	ldr	x10, [sp, #0x48]
    690c:      	cmp	x9, x10
    6910:      	b.hs	0x6950 <perf_unwind_v8+0x6950>
    6914:      	ldr	w9, [sp, #0x30]
    6918:      	ldr	w10, [sp, #0x20]
    691c:      	orr	x12, x24, #0x3
    6920:      	and	w9, w9, w10
    6924:      	ldr	x10, [sp, #0x28]
    6928:      	ldr	x11, [sp, #0x40]
    692c:      	orr	x11, x11, #0x4
    6930:      	lsr	w9, w9, w10
    6934:      	ldrb	w10, [x23, #0x19]
    6938:      	cmp	w9, w10
    693c:      	orr	w9, w9, w25, lsl #4
    6940:      	csel	x10, x11, x12, eq
    6944:      	orr	x24, x8, x9, lsl #32
    6948:      	str	x10, [sp, #0x50]
    694c:      	b	0x69a8 <perf_unwind_v8+0x69a8>
    6950:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6954:      	ldr	x8, [x8]
    6958:      	ldr	w8, [x8]
    695c:      	cbnz	w8, 0x696c <perf_unwind_v8+0x696c>
    6960:      	ldrb	w23, [x21, #0xf20]
    6964:      	mov	x24, xzr
    6968:      	b	0x6a10 <perf_unwind_v8+0x6a10>
    696c:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6970:      	add	x8, x8, #0x0
    6974:      	add	x0, sp, #0x70
    6978:      	ldp	x9, x10, [x8, #0x10]
    697c:      	mov	w1, #0x30               // =48
    6980:      	stp	x9, x10, [sp, #0x80]
    6984:      	ldp	x9, x10, [x8, #0x20]
    6988:      	stp	x9, x10, [sp, #0x90]
    698c:      	ldp	x9, x8, [x8]
    6990:      	add	x10, sp, #0x70
    6994:      	stp	x9, x8, [sp, #0x70]
    6998:      	mov	w8, #0x30               // =48
    699c:      	mov	w9, #0x6                // =6
    69a0:      	blr	x9
    69a4:      	mov	x24, xzr
    69a8:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    69ac:      	ldr	x8, [x8]
    69b0:      	ldrb	w23, [x21, #0xf20]
    69b4:      	ldr	w8, [x8]
    69b8:      	cbz	w8, 0x6a10 <perf_unwind_v8+0x6a10>
    69bc:      	mov	w8, #0x786c             // =30828
    69c0:      	add	x0, sp, #0x70
    69c4:      	mov	w1, #0x3c               // =60
    69c8:      	mov	x2, x24
    69cc:      	movk	w8, #0xa, lsl #16
    69d0:      	str	w8, [sp, #0xa8]
    69d4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    69d8:      	add	x8, x8, #0x0
    69dc:      	ldp	x9, x10, [x8, #0x20]
    69e0:      	stp	x9, x10, [sp, #0x90]
    69e4:      	ldr	x9, [x8, #0x30]
    69e8:      	str	x9, [sp, #0xa0]
    69ec:      	ldp	x9, x10, [x8]
    69f0:      	stp	x9, x10, [sp, #0x70]
    69f4:      	add	x10, sp, #0x70
    69f8:      	ldp	x8, x9, [x8, #0x10]
    69fc:      	stp	x8, x9, [sp, #0x80]
    6a00:      	mov	w8, #0x3c               // =60
    6a04:      	mov	w9, #0x6                // =6
    6a08:      	ldr	x3, [sp, #0x50]
    6a0c:      	blr	x9
    6a10:      	ldr	w8, [x21, #0x2c0]
    6a14:      	cmp	w8, #0x7e
    6a18:      	b.hi	0x2a8 <perf_unwind_v8+0x2a8>
    6a1c:      	add	w9, w8, #0x1
    6a20:      	mov	w10, #0x8               // =8
    6a24:      	add	x11, sp, #0x70
    6a28:      	str	w9, [x21, #0x2c0]
    6a2c:      	mov	w9, #0x18               // =24
    6a30:      	add	x0, sp, #0x70
    6a34:      	mov	w1, #0x10               // =16
    6a38:      	umaddl	x8, w8, w9, x21
    6a3c:      	ldr	x9, [sp, #0x50]
    6a40:      	str	x24, [x8, #0x2d8]
    6a44:      	strb	w10, [x8, #0x2e0]
    6a48:      	strb	w23, [x8, #0x2e1]
    6a4c:      	strh	wzr, [x8, #0x2e6]
    6a50:      	mov	w10, #0x70              // =112
    6a54:      	str	x9, [x8, #0x2d0]
    6a58:      	add	x9, x8, #0x2d0
    6a5c:      	stur	wzr, [x9, #0x12]
    6a60:      	mov	w9, #0x10               // =16
    6a64:      	ldr	x8, [x21, #0xee0]
    6a68:      	ldr	x2, [x21, #0xee0]
    6a6c:      	blr	x10
    6a70:      	cbnz	x0, 0x440 <perf_unwind_v8+0x440>
    6a74:      	ldr	x8, [x21, #0xee0]
    6a78:      	add	x9, x8, #0x10
    6a7c:      	str	x9, [x21, #0xed8]
    6a80:      	ldp	x9, x10, [sp, #0x70]
    6a84:      	str	x9, [x21, #0xee0]
    6a88:      	mov	w9, #0x101              // =257
    6a8c:      	str	x10, [x21, #0xed0]
    6a90:      	strh	w9, [x21, #0xf20]
    6a94:      	ldr	x9, [sp, #0x50]
    6a98:      	cbnz	x9, 0x6aac <perf_unwind_v8+0x6aac>
    6a9c:      	cmp	x24, #0x1
    6aa0:      	b.ne	0x6aac <perf_unwind_v8+0x6aac>
    6aa4:      	add	x8, x8, #0xa0
    6aa8:      	str	x8, [x21, #0xed8]
    6aac:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6ab0:      	ldr	x8, [x8]
    6ab4:      	ldr	w8, [x8]
    6ab8:      	cbz	w8, 0x6b00 <perf_unwind_v8+0x6b00>
    6abc:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6ac0:      	add	x8, x8, #0x0
    6ac4:      	add	x0, sp, #0x70
    6ac8:      	ldp	x9, x10, [x8]
    6acc:      	mov	w1, #0x1f               // =31
    6ad0:      	stp	x9, x10, [sp, #0x70]
    6ad4:      	ldr	x9, [x8, #0x10]
    6ad8:      	ldur	x8, [x8, #0x17]
    6adc:      	add	x10, sp, #0x70
    6ae0:      	str	x9, [sp, #0x80]
    6ae4:      	stur	x8, [sp, #0x87]
    6ae8:      	mov	w8, #0x1f               // =31
    6aec:      	mov	w9, #0x6                // =6
    6af0:      	ldr	x2, [x21, #0xed0]
    6af4:      	ldr	x3, [x21, #0xed8]
    6af8:      	ldr	x4, [x21, #0xee0]
    6afc:      	blr	x9
    6b00:      	mov	w8, #0x38               // =56
    6b04:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    6b08:      	add	x9, sp, #0x58
    6b0c:      	str	w8, [sp, #0x58]
    6b10:      	mov	w8, #0x1                // =1
    6b14:      	add	x1, sp, #0x58
    6b18:      	ldr	x0, [x0]
    6b1c:      	blr	x8
    6b20:      	cbz	x0, 0x6b34 <perf_unwind_v8+0x6b34>
    6b24:      	ldr	x8, [x0]
    6b28:      	add	x8, x8, #0x1
    6b2c:      	str	x8, [x0]
    6b30:      	b	0x6b88 <perf_unwind_v8+0x6b88>
    6b34:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6b38:      	ldr	x8, [x8]
    6b3c:      	ldr	w8, [x8]
    6b40:      	cbz	w8, 0x6b94 <perf_unwind_v8+0x6b94>
    6b44:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6b48:      	add	x8, x8, #0x0
    6b4c:      	add	x0, sp, #0x70
    6b50:      	ldp	x9, x10, [x8, #0x10]
    6b54:      	mov	w1, #0x2e               // =46
    6b58:      	stp	x9, x10, [sp, #0x80]
    6b5c:      	ldr	x9, [x8, #0x20]
    6b60:      	add	x10, sp, #0x70
    6b64:      	str	x9, [sp, #0x90]
    6b68:      	ldur	x9, [x8, #0x26]
    6b6c:      	stur	x9, [sp, #0x96]
    6b70:      	ldp	x9, x8, [x8]
    6b74:      	stp	x9, x8, [sp, #0x70]
    6b78:      	mov	w8, #0x2e               // =46
    6b7c:      	mov	w9, #0x6                // =6
    6b80:      	ldr	w2, [sp, #0x58]
    6b84:      	blr	x9
    6b88:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6b8c:      	ldr	x8, [x8]
    6b90:      	ldr	w8, [x8]
    6b94:      	ldr	x24, [x21, #0xed0]
    6b98:      	cbz	x24, 0x6dd8 <perf_unwind_v8+0x6dd8>
    6b9c:      	cbz	w8, 0x6be4 <perf_unwind_v8+0x6be4>
    6ba0:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6ba4:      	add	x8, x8, #0x0
    6ba8:      	strb	wzr, [sp, #0xa0]
    6bac:      	add	x0, sp, #0x70
    6bb0:      	ldp	x9, x10, [x8, #0x10]
    6bb4:      	mov	w1, #0x31               // =49
    6bb8:      	stp	x9, x10, [sp, #0x80]
    6bbc:      	ldp	x9, x10, [x8, #0x20]
    6bc0:      	stp	x9, x10, [sp, #0x90]
    6bc4:      	ldp	x9, x8, [x8]
    6bc8:      	add	x10, sp, #0x70
    6bcc:      	stp	x9, x8, [sp, #0x70]
    6bd0:      	mov	w8, #0x31               // =49
    6bd4:      	mov	w9, #0x6                // =6
    6bd8:      	ldr	w2, [x21, #0x2c0]
    6bdc:      	blr	x9
    6be0:      	ldr	x24, [x21, #0xed0]
    6be4:      	lsr	x8, x24, #56
    6be8:      	cbnz	x8, 0x678 <perf_unwind_v8+0x678>
    6bec:      	cmp	x24, #0x1, lsl #12      // =0x1000
    6bf0:      	b.lo	0xf04 <perf_unwind_v8+0xf04>
    6bf4:      	ldr	w8, [x21]
    6bf8:      	mov	w9, #0x60               // =96
    6bfc:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    6c00:      	add	x1, sp, #0x58
    6c04:      	rev	w8, w8
    6c08:      	stp	w9, w8, [sp, #0x58]
    6c0c:      	rev	x8, x24
    6c10:      	add	x9, sp, #0x58
    6c14:      	str	x8, [sp, #0x60]
    6c18:      	mov	w8, #0x1                // =1
    6c1c:      	ldr	x0, [x0]
    6c20:      	blr	x8
    6c24:      	cbz	x0, 0x6e00 <perf_unwind_v8+0x6e00>
    6c28:      	ldr	x8, [x0, #0x8]
    6c2c:      	and	x9, x8, #0xffffffffffffff
    6c30:      	lsr	x29, x8, #56
    6c34:      	str	x9, [x21, #0xf10]
    6c38:      	ldr	x8, [x0]
    6c3c:      	str	x8, [x21, #0xf00]
    6c40:      	sub	x8, x24, x9
    6c44:      	str	x8, [x21, #0xf08]
    6c48:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6c4c:      	ldr	x8, [x8]
    6c50:      	ldr	w8, [x8]
    6c54:      	cbz	w8, 0x6cfc <perf_unwind_v8+0x6cfc>
    6c58:      	mov	w8, #0xa                // =10
    6c5c:      	add	x0, sp, #0x70
    6c60:      	mov	w1, #0x32               // =50
    6c64:      	strh	w8, [sp, #0xa0]
    6c68:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6c6c:      	add	x8, x8, #0x0
    6c70:      	mov	x2, x24
    6c74:      	ldp	x9, x10, [x8, #0x10]
    6c78:      	mov	w4, w29
    6c7c:      	stp	x9, x10, [sp, #0x80]
    6c80:      	ldp	x9, x10, [x8, #0x20]
    6c84:      	stp	x9, x10, [sp, #0x90]
    6c88:      	ldp	x9, x8, [x8]
    6c8c:      	add	x10, sp, #0x70
    6c90:      	stp	x9, x8, [sp, #0x70]
    6c94:      	mov	w8, #0x32               // =50
    6c98:      	mov	w9, #0x6                // =6
    6c9c:      	ldr	x3, [x21, #0xf00]
    6ca0:      	blr	x9
    6ca4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6ca8:      	ldr	x8, [x8]
    6cac:      	ldr	w8, [x8]
    6cb0:      	cbz	w8, 0x6cfc <perf_unwind_v8+0x6cfc>
    6cb4:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6cb8:      	add	x8, x8, #0x0
    6cbc:      	add	x0, sp, #0x70
    6cc0:      	ldp	x9, x10, [x8, #0x10]
    6cc4:      	mov	w1, #0x2f               // =47
    6cc8:      	stp	x9, x10, [sp, #0x80]
    6ccc:      	ldr	x9, [x8, #0x20]
    6cd0:      	add	x10, sp, #0x70
    6cd4:      	str	x9, [sp, #0x90]
    6cd8:      	ldur	x9, [x8, #0x27]
    6cdc:      	stur	x9, [sp, #0x97]
    6ce0:      	ldp	x9, x8, [x8]
    6ce4:      	stp	x9, x8, [sp, #0x70]
    6ce8:      	mov	w8, #0x2f               // =47
    6cec:      	mov	w9, #0x6                // =6
    6cf0:      	ldr	x2, [x21, #0xf10]
    6cf4:      	ldr	x3, [x21, #0xf08]
    6cf8:      	blr	x9
    6cfc:      	cmp	w29, #0x1
    6d00:      	b.ne	0x6f80 <perf_unwind_v8+0x6f80>
    6d04:      	ldr	x8, [x21, #0xf00]
    6d08:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    6d0c:      	ldr	x24, [x21, #0xf08]
    6d10:      	mov	w9, #0x1                // =1
    6d14:      	add	x1, sp, #0x58
    6d18:      	mov	w29, #0x1               // =1
    6d1c:      	str	x8, [sp, #0x58]
    6d20:      	add	x8, sp, #0x58
    6d24:      	ldr	x0, [x0]
    6d28:      	blr	x9
    6d2c:      	cbz	x0, 0x6eb0 <perf_unwind_v8+0x6eb0>
    6d30:      	ldr	x8, [x0]
    6d34:      	mov	x23, x0
    6d38:      	cmp	x8, x24
    6d3c:      	b.hi	0x6d4c <perf_unwind_v8+0x6d4c>
    6d40:      	ldr	x8, [x23, #0x8]
    6d44:      	cmp	x8, x24
    6d48:      	b.hs	0x6d64 <perf_unwind_v8+0x6d64>
    6d4c:      	ldr	x8, [x23, #0x10]
    6d50:      	cmp	x8, x24
    6d54:      	b.hi	0x6dd0 <perf_unwind_v8+0x6dd0>
    6d58:      	ldr	x8, [x23, #0x18]
    6d5c:      	cmp	x8, x24
    6d60:      	b.lo	0x6dd0 <perf_unwind_v8+0x6dd0>
    6d64:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6d68:      	ldr	x8, [x8]
    6d6c:      	ldr	w8, [x8]
    6d70:      	cbz	w8, 0x6db0 <perf_unwind_v8+0x6db0>
    6d74:      	adrp	x10, 0x6000 <perf_unwind_v8+0x6000>
    6d78:      	add	x10, x10, #0x0
    6d7c:      	add	x0, sp, #0x70
    6d80:      	ldp	x8, x9, [x10]
    6d84:      	mov	w1, #0x1e               // =30
    6d88:      	stp	x8, x9, [sp, #0x70]
    6d8c:      	ldr	x8, [x10, #0x10]
    6d90:      	mov	w9, #0x6                // =6
    6d94:      	str	x8, [sp, #0x80]
    6d98:      	ldur	x8, [x10, #0x16]
    6d9c:      	add	x10, sp, #0x70
    6da0:      	stur	x8, [sp, #0x86]
    6da4:      	mov	w8, #0x1e               // =30
    6da8:      	ldrh	w2, [x23, #0x20]
    6dac:      	blr	x9
    6db0:      	ldrh	w8, [x23, #0x20]
    6db4:      	ldr	w9, [x21, #0x1370]
    6db8:      	lsr	w8, w9, w8
    6dbc:      	tbz	w8, #0x0, 0x6eb4 <perf_unwind_v8+0x6eb4>
    6dc0:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6dc4:      	ldr	x8, [x8]
    6dc8:      	ldr	w8, [x8]
    6dcc:      	cbnz	w8, 0x6ee4 <perf_unwind_v8+0x6ee4>
    6dd0:      	mov	w29, #0x1               // =1
    6dd4:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    6dd8:      	adrp	x24, 0x6000 <perf_unwind_v8+0x6000>
    6ddc:      	adrp	x22, 0x6000 <perf_unwind_v8+0x6000>
    6de0:      	ldr	x24, [x24]
    6de4:      	ldr	x22, [x22]
    6de8:      	cbnz	w8, 0x6e24 <perf_unwind_v8+0x6e24>
    6dec:      	mov	w8, #0x1                // =1
    6df0:      	mov	w29, wzr
    6df4:      	str	w8, [x21, #0xf18]
    6df8:      	mov	w8, #0xfad              // =4013
    6dfc:      	b	0x19ac <perf_unwind_v8+0x19ac>
    6e00:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6e04:      	ldr	x8, [x8]
    6e08:      	ldr	w8, [x8]
    6e0c:      	cbnz	w8, 0x6e64 <perf_unwind_v8+0x6e64>
    6e10:      	mov	w8, #0xc                // =12
    6e14:      	mov	w29, wzr
    6e18:      	str	w8, [x21, #0xf18]
    6e1c:      	mov	w8, #0xfac              // =4012
    6e20:      	b	0x258 <perf_unwind_v8+0x258>
    6e24:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6e28:      	add	x8, x8, #0x0
    6e2c:      	strb	wzr, [sp, #0xa0]
    6e30:      	add	x0, sp, #0x70
    6e34:      	ldp	x9, x10, [x8, #0x10]
    6e38:      	mov	w1, #0x31               // =49
    6e3c:      	stp	x9, x10, [sp, #0x80]
    6e40:      	ldp	x9, x10, [x8, #0x20]
    6e44:      	stp	x9, x10, [sp, #0x90]
    6e48:      	ldp	x9, x8, [x8]
    6e4c:      	add	x10, sp, #0x70
    6e50:      	stp	x9, x8, [sp, #0x70]
    6e54:      	mov	w8, #0x31               // =49
    6e58:      	mov	w9, #0x6                // =6
    6e5c:      	blr	x9
    6e60:      	b	0x6dec <perf_unwind_v8+0x6dec>
    6e64:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6e68:      	add	x8, x8, #0x0
    6e6c:      	strb	wzr, [sp, #0xa8]
    6e70:      	add	x0, sp, #0x70
    6e74:      	ldp	x9, x10, [x8, #0x20]
    6e78:      	mov	w1, #0x39               // =57
    6e7c:      	mov	x2, x24
    6e80:      	stp	x9, x10, [sp, #0x90]
    6e84:      	ldr	x9, [x8, #0x30]
    6e88:      	str	x9, [sp, #0xa0]
    6e8c:      	ldp	x9, x10, [x8]
    6e90:      	stp	x9, x10, [sp, #0x70]
    6e94:      	ldp	x8, x9, [x8, #0x10]
    6e98:      	add	x10, sp, #0x70
    6e9c:      	stp	x8, x9, [sp, #0x80]
    6ea0:      	mov	w8, #0x39               // =57
    6ea4:      	mov	w9, #0x6                // =6
    6ea8:      	blr	x9
    6eac:      	b	0x6e10 <perf_unwind_v8+0x6e10>
    6eb0:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    6eb4:      	str	wzr, [sp, #0xbc]
    6eb8:      	adrp	x0, 0x6000 <perf_unwind_v8+0x6000>
    6ebc:      	mov	w8, #0x1                // =1
    6ec0:      	add	x9, sp, #0xbc
    6ec4:      	ldr	x0, [x0]
    6ec8:      	add	x1, sp, #0xbc
    6ecc:      	blr	x8
    6ed0:      	cbz	x0, 0x6f28 <perf_unwind_v8+0x6f28>
    6ed4:      	ldr	x8, [x0]
    6ed8:      	add	x8, x8, #0x1
    6edc:      	str	x8, [x0]
    6ee0:      	b	0x6f7c <perf_unwind_v8+0x6f7c>
    6ee4:      	mov	w8, #0x656e             // =25966
    6ee8:      	adrp	x10, 0x6000 <perf_unwind_v8+0x6000>
    6eec:      	add	x10, x10, #0x0
    6ef0:      	add	x0, sp, #0x70
    6ef4:      	mov	w1, #0x1b               // =27
    6ef8:      	movk	w8, #0xa, lsl #16
    6efc:      	stur	w8, [sp, #0x87]
    6f00:      	ldp	x8, x9, [x10]
    6f04:      	stp	x8, x9, [sp, #0x70]
    6f08:      	ldr	x8, [x10, #0x10]
    6f0c:      	mov	w9, #0x6                // =6
    6f10:      	add	x10, sp, #0x70
    6f14:      	str	x8, [sp, #0x80]
    6f18:      	mov	w8, #0x1b               // =27
    6f1c:      	blr	x9
    6f20:      	mov	w29, #0x1               // =1
    6f24:      	b	0x6f80 <perf_unwind_v8+0x6f80>
    6f28:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6f2c:      	ldr	x8, [x8]
    6f30:      	ldr	w8, [x8]
    6f34:      	cbz	w8, 0x6f7c <perf_unwind_v8+0x6f7c>
    6f38:      	adrp	x8, 0x6000 <perf_unwind_v8+0x6000>
    6f3c:      	add	x8, x8, #0x0
    6f40:      	add	x0, sp, #0x70
    6f44:      	ldp	x9, x10, [x8, #0x10]
    6f48:      	mov	w1, #0x2e               // =46
    6f4c:      	stp	x9, x10, [sp, #0x80]
    6f50:      	ldr	x9, [x8, #0x20]
    6f54:      	add	x10, sp, #0x70
    6f58:      	str	x9, [sp, #0x90]
    6f5c:      	ldur	x9, [x8, #0x26]
    6f60:      	stur	x9, [sp, #0x96]
    6f64:      	ldp	x9, x8, [x8]
    6f68:      	stp	x9, x8, [sp, #0x70]
    6f6c:      	mov	w8, #0x2e               // =46
    6f70:      	mov	w9, #0x6                // =6
    6f74:      	ldr	w2, [sp, #0xbc]
    6f78:      	blr	x9
    6f7c:      	ldrh	w29, [x23, #0x20]
    6f80:      	mov	w8, wzr
    6f84:      	b	0x258 <perf_unwind_v8+0x258>

Disassembly of section kprobe/unwind_v8:

0000000000000000 <kprobe_unwind_v8>:
       0:      	sub	sp, sp, #0x100
       4:      	str	x29, [sp, #0xb0]
       8:      	stp	x30, x25, [sp, #0xc0]
       c:      	stp	x24, x23, [sp, #0xd0]
      10:      	stp	x22, x21, [sp, #0xe0]
      14:      	stp	x20, x19, [sp, #0xf0]
      18:      	str	wzr, [sp, #0x70]
      1c:      	adrp	x20, 0x0 <kprobe_unwind_v8>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x70
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x70
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x1a78 <kprobe_unwind_v8+0x1a78>
      40:      	ldr	w8, [x0]
      44:      	adrp	x22, 0x0 <kprobe_unwind_v8>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0xb8]
      50:      	ldr	x22, [x22]
      54:      	ldr	w8, [x22]
      58:      	cbnz	w8, 0x6a4 <kprobe_unwind_v8+0x6a4>
      5c:      	adrp	x0, 0x0 <kprobe_unwind_v8>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0xb8
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0xb8
      70:      	blr	x8
      74:      	adrp	x24, 0x0 <kprobe_unwind_v8>
      78:      	ldr	x24, [x24]
      7c:      	cbz	x0, 0x114 <kprobe_unwind_v8+0x114>
      80:      	mov	w8, #0x37               // =55
      84:      	add	x9, sp, #0x58
      88:      	mov	x23, x0
      8c:      	str	w8, [sp, #0x58]
      90:      	mov	w8, #0x1                // =1
      94:      	add	x1, sp, #0x58
      98:      	mov	x0, x24
      9c:      	blr	x8
      a0:      	cbz	x0, 0x14c <kprobe_unwind_v8+0x14c>
      a4:      	ldr	x8, [x0]
      a8:      	add	x8, x8, #0x1
      ac:      	str	x8, [x0]
      b0:      	ldr	x29, [x21, #0xed8]
      b4:      	ldr	x25, [x21, #0xee0]
      b8:      	ldr	x24, [x21, #0xed0]
      bc:      	ldr	w8, [x22]
      c0:      	cbz	w8, 0x168 <kprobe_unwind_v8+0x168>
      c4:      	adrp	x8, 0x0 <kprobe_unwind_v8>
      c8:      	add	x8, x8, #0x0
      cc:      	add	x0, sp, #0x70
      d0:      	ldp	x9, x10, [x8]
      d4:      	mov	w1, #0x1f               // =31
      d8:      	mov	x2, x24
      dc:      	mov	x3, x29
      e0:      	stp	x9, x10, [sp, #0x70]
      e4:      	ldr	x9, [x8, #0x10]
      e8:      	ldur	x8, [x8, #0x17]
      ec:      	add	x10, sp, #0x70
      f0:      	mov	x4, x25
      f4:      	str	x9, [sp, #0x80]
      f8:      	stur	x8, [sp, #0x87]
      fc:      	mov	w8, #0x1f               // =31
     100:      	mov	w9, #0x6                // =6
     104:      	blr	x9
     108:      	cmp	x25, x29
     10c:      	b.hs	0x170 <kprobe_unwind_v8+0x170>
     110:      	b	0x1954 <kprobe_unwind_v8+0x1954>
     114:      	ldr	w8, [x22]
     118:      	cbnz	w8, 0x818 <kprobe_unwind_v8+0x818>
     11c:      	mov	w8, #0x54               // =84
     120:      	add	x9, sp, #0x58
     124:      	add	x1, sp, #0x58
     128:      	str	w8, [sp, #0x58]
     12c:      	mov	w8, #0x1                // =1
     130:      	mov	x0, x24
     134:      	blr	x8
     138:      	cbz	x0, 0x214 <kprobe_unwind_v8+0x214>
     13c:      	ldr	x8, [x0]
     140:      	add	x8, x8, #0x1
     144:      	str	x8, [x0]
     148:      	b	0x21c <kprobe_unwind_v8+0x21c>
     14c:      	ldr	w8, [x22]
     150:      	cbnz	w8, 0x8d8 <kprobe_unwind_v8+0x8d8>
     154:      	ldr	x29, [x21, #0xed8]
     158:      	ldr	x25, [x21, #0xee0]
     15c:      	ldr	x24, [x21, #0xed0]
     160:      	ldr	w8, [x22]
     164:      	cbnz	w8, 0xc4 <kprobe_unwind_v8+0xc4>
     168:      	cmp	x25, x29
     16c:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
     170:      	add	x8, x29, #0x2, lsl #12  // =0x2000
     174:      	cmp	x25, x8
     178:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
     17c:      	add	x22, x21, #0xf70
     180:      	sub	x2, x25, #0x40
     184:      	mov	w8, #0x40               // =64
     188:      	mov	w9, #0x70               // =112
     18c:      	mov	w1, #0x40               // =64
     190:      	mov	x0, x22
     194:      	blr	x9
     198:      	cbz	x0, 0x228 <kprobe_unwind_v8+0x228>
     19c:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     1a0:      	ldr	x22, [x22]
     1a4:      	ldr	w8, [x22]
     1a8:      	cbnz	w8, 0x934 <kprobe_unwind_v8+0x934>
     1ac:      	mov	w8, #0x39               // =57
     1b0:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     1b4:      	add	x9, sp, #0x58
     1b8:      	str	w8, [sp, #0x58]
     1bc:      	mov	w8, #0x1                // =1
     1c0:      	add	x1, sp, #0x58
     1c4:      	ldr	x24, [x24]
     1c8:      	mov	x0, x24
     1cc:      	blr	x8
     1d0:      	cbnz	x0, 0x198c <kprobe_unwind_v8+0x198c>
     1d4:      	ldr	w8, [x22]
     1d8:      	cbz	w8, 0x19a4 <kprobe_unwind_v8+0x19a4>
     1dc:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     1e0:      	add	x8, x8, #0x0
     1e4:      	ldp	x9, x10, [x8, #0x10]
     1e8:      	stp	x9, x10, [sp, #0x80]
     1ec:      	ldr	x9, [x8, #0x20]
     1f0:      	add	x10, sp, #0x70
     1f4:      	str	x9, [sp, #0x90]
     1f8:      	ldur	x9, [x8, #0x26]
     1fc:      	stur	x9, [sp, #0x96]
     200:      	ldp	x9, x8, [x8]
     204:      	stp	x9, x8, [sp, #0x70]
     208:      	mov	w8, #0x2e               // =46
     20c:      	mov	w9, #0x6                // =6
     210:      	b	0x1b60 <kprobe_unwind_v8+0x1b60>
     214:      	ldr	w8, [x22]
     218:      	cbnz	w8, 0x9a8 <kprobe_unwind_v8+0x9a8>
     21c:      	mov	w29, wzr
     220:      	mov	w8, #0x138a             // =5002
     224:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
     228:      	ldrb	w9, [x23, #0x14]
     22c:      	str	x22, [sp, #0x50]
     230:      	cmp	x9, #0x38
     234:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
     238:      	ldrb	w8, [x23, #0x15]
     23c:      	cmp	x8, #0x38
     240:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
     244:      	ldrb	w10, [x23, #0x16]
     248:      	cmp	x10, #0x38
     24c:      	b.ls	0x26c <kprobe_unwind_v8+0x26c>
     250:      	mov	w29, wzr
     254:      	mov	w8, #0x1                // =1
     258:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     25c:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     260:      	ldr	x24, [x24]
     264:      	ldr	x22, [x22]
     268:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
     26c:      	ldr	x11, [sp, #0x50]
     270:      	add	x25, x21, #0xfb0
     274:      	ldr	x9, [x11, x9]
     278:      	tbnz	w9, #0x0, 0x2f0 <kprobe_unwind_v8+0x2f0>
     27c:      	str	x25, [sp, #0x48]
     280:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     284:      	lsr	x25, x9, #1
     288:      	ldr	x8, [x8]
     28c:      	ldr	w8, [x8]
     290:      	cbnz	w8, 0xc0c <kprobe_unwind_v8+0xc0c>
     294:      	ldrb	w24, [x21, #0xf20]
     298:      	mov	x29, xzr
     29c:      	ldr	w8, [x21, #0x2c0]
     2a0:      	cmp	w8, #0x7f
     2a4:      	b.lo	0x3ec <kprobe_unwind_v8+0x3ec>
     2a8:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     2ac:      	ldr	x22, [x22]
     2b0:      	ldr	w8, [x22]
     2b4:      	cbnz	w8, 0xca0 <kprobe_unwind_v8+0xca0>
     2b8:      	mov	w8, #0x2                // =2
     2bc:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     2c0:      	add	x9, sp, #0x58
     2c4:      	str	w8, [sp, #0x58]
     2c8:      	mov	w8, #0x1                // =1
     2cc:      	add	x1, sp, #0x58
     2d0:      	ldr	x24, [x24]
     2d4:      	mov	x0, x24
     2d8:      	blr	x8
     2dc:      	cbz	x0, 0x5bc <kprobe_unwind_v8+0x5bc>
     2e0:      	ldr	x8, [x0]
     2e4:      	add	x8, x8, #0x1
     2e8:      	str	x8, [x0]
     2ec:      	b	0x5c4 <kprobe_unwind_v8+0x5c4>
     2f0:      	ldr	x8, [x11, x8]
     2f4:      	ldr	x22, [x11, x10]
     2f8:      	and	x9, x8, #0x3
     2fc:      	and	x8, x8, #0xfffffffffffffffc
     300:      	cmp	x9, #0x1
     304:      	csel	x9, x8, xzr, eq
     308:      	str	x9, [sp, #0x40]
     30c:      	cbz	x9, 0x384 <kprobe_unwind_v8+0x384>
     310:      	ldrb	w8, [x23, #0xc]
     314:      	add	x10, sp, #0x70
     318:      	add	x0, sp, #0x70
     31c:      	mov	w1, #0x8                // =8
     320:      	add	x2, x9, x8
     324:      	mov	w8, #0x8                // =8
     328:      	mov	w9, #0x70               // =112
     32c:      	blr	x9
     330:      	cbnz	x0, 0x384 <kprobe_unwind_v8+0x384>
     334:      	ldr	x8, [sp, #0x70]
     338:      	and	x9, x8, #0x3
     33c:      	cmp	x9, #0x1
     340:      	b.ne	0x384 <kprobe_unwind_v8+0x384>
     344:      	and	x8, x8, #0xfffffffffffffffc
     348:      	cbz	x8, 0x388 <kprobe_unwind_v8+0x388>
     34c:      	ldrb	w9, [x23, #0xd]
     350:      	mov	w10, #0x2               // =2
     354:      	mov	w11, #0x70              // =112
     358:      	add	x12, sp, #0x70
     35c:      	add	x0, sp, #0x70
     360:      	mov	w1, #0x2                // =2
     364:      	add	x9, x8, x9
     368:      	ldrb	w9, [x23, #0xd]
     36c:      	add	x2, x8, x9
     370:      	blr	x11
     374:      	ldrh	w8, [sp, #0x70]
     378:      	cmp	x0, #0x0
     37c:      	csel	w8, w8, wzr, eq
     380:      	b	0x388 <kprobe_unwind_v8+0x388>
     384:      	mov	w8, wzr
     388:      	ldrh	w9, [x23, #0x4]
     38c:      	cmp	w9, w8, uxth
     390:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
     394:      	ldrh	w9, [x23, #0x6]
     398:      	str	x25, [sp, #0x48]
     39c:      	cmp	w9, w8, uxth
     3a0:      	b.hs	0x4cc <kprobe_unwind_v8+0x4cc>
     3a4:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     3a8:      	ldr	x22, [x22]
     3ac:      	ldr	w9, [x22]
     3b0:      	cbnz	w9, 0xc50 <kprobe_unwind_v8+0xc50>
     3b4:      	mov	w8, #0x3a               // =58
     3b8:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     3bc:      	add	x9, sp, #0x58
     3c0:      	str	w8, [sp, #0x58]
     3c4:      	mov	w8, #0x1                // =1
     3c8:      	add	x1, sp, #0x58
     3cc:      	ldr	x24, [x24]
     3d0:      	mov	x0, x24
     3d4:      	blr	x8
     3d8:      	cbz	x0, 0x4b8 <kprobe_unwind_v8+0x4b8>
     3dc:      	ldr	x8, [x0]
     3e0:      	add	x8, x8, #0x1
     3e4:      	str	x8, [x0]
     3e8:      	b	0x4c0 <kprobe_unwind_v8+0x4c0>
     3ec:      	add	w9, w8, #0x1
     3f0:      	mov	w10, #0x8               // =8
     3f4:      	add	x11, sp, #0x70
     3f8:      	str	w9, [x21, #0x2c0]
     3fc:      	mov	w9, #0x18               // =24
     400:      	add	x0, sp, #0x70
     404:      	mov	w1, #0x10               // =16
     408:      	umaddl	x8, w8, w9, x21
     40c:      	add	x9, x8, #0x2d0
     410:      	str	x29, [x8, #0x2d0]
     414:      	str	x25, [x8, #0x2d8]
     418:      	strb	w10, [x8, #0x2e0]
     41c:      	strb	w24, [x8, #0x2e1]
     420:      	strh	wzr, [x8, #0x2e6]
     424:      	mov	w10, #0x70              // =112
     428:      	stur	wzr, [x9, #0x12]
     42c:      	mov	w9, #0x10               // =16
     430:      	ldr	x8, [x21, #0xee0]
     434:      	ldr	x2, [x21, #0xee0]
     438:      	blr	x10
     43c:      	cbz	x0, 0x5d0 <kprobe_unwind_v8+0x5d0>
     440:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     444:      	ldr	x22, [x22]
     448:      	ldr	w8, [x22]
     44c:      	cbnz	w8, 0xd74 <kprobe_unwind_v8+0xd74>
     450:      	mov	w8, #0x39               // =57
     454:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     458:      	add	x9, sp, #0x58
     45c:      	str	w8, [sp, #0x58]
     460:      	mov	w8, #0x1                // =1
     464:      	add	x1, sp, #0x58
     468:      	ldr	x24, [x24]
     46c:      	mov	x0, x24
     470:      	blr	x8
     474:      	cbnz	x0, 0x198c <kprobe_unwind_v8+0x198c>
     478:      	ldr	w8, [x22]
     47c:      	cbz	w8, 0x19a4 <kprobe_unwind_v8+0x19a4>
     480:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     484:      	add	x8, x8, #0x0
     488:      	ldp	x9, x10, [x8, #0x10]
     48c:      	stp	x9, x10, [sp, #0x80]
     490:      	ldr	x9, [x8, #0x20]
     494:      	add	x10, sp, #0x70
     498:      	str	x9, [sp, #0x90]
     49c:      	ldur	x9, [x8, #0x26]
     4a0:      	stur	x9, [sp, #0x96]
     4a4:      	ldp	x9, x8, [x8]
     4a8:      	stp	x9, x8, [sp, #0x70]
     4ac:      	mov	w8, #0x2e               // =46
     4b0:      	mov	w9, #0x6                // =6
     4b4:      	b	0x1b60 <kprobe_unwind_v8+0x1b60>
     4b8:      	ldr	w8, [x22]
     4bc:      	cbnz	w8, 0xdb4 <kprobe_unwind_v8+0xdb4>
     4c0:      	mov	w29, wzr
     4c4:      	mov	w8, #0x1389             // =5001
     4c8:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
     4cc:      	ldrb	w8, [x23, #0xf]
     4d0:      	ldr	x9, [sp, #0x40]
     4d4:      	add	x10, sp, #0x70
     4d8:      	add	x0, sp, #0x70
     4dc:      	mov	w1, #0x8                // =8
     4e0:      	add	x2, x9, x8
     4e4:      	mov	w8, #0x8                // =8
     4e8:      	mov	w9, #0x70               // =112
     4ec:      	blr	x9
     4f0:      	cbnz	x0, 0x584 <kprobe_unwind_v8+0x584>
     4f4:      	ldr	x8, [sp, #0x70]
     4f8:      	and	x9, x8, #0x3
     4fc:      	cmp	x9, #0x1
     500:      	b.ne	0x584 <kprobe_unwind_v8+0x584>
     504:      	and	x9, x8, #0xfffffffffffffffc
     508:      	cbz	x9, 0x584 <kprobe_unwind_v8+0x584>
     50c:      	ldrb	w8, [x23, #0xc]
     510:      	mov	x25, x9
     514:      	add	x10, sp, #0x70
     518:      	add	x0, sp, #0x70
     51c:      	mov	w1, #0x8                // =8
     520:      	add	x2, x9, x8
     524:      	mov	w8, #0x8                // =8
     528:      	mov	w9, #0x70               // =112
     52c:      	blr	x9
     530:      	cbnz	x0, 0x84c <kprobe_unwind_v8+0x84c>
     534:      	ldr	x8, [sp, #0x70]
     538:      	and	x9, x8, #0x3
     53c:      	cmp	x9, #0x1
     540:      	b.ne	0x84c <kprobe_unwind_v8+0x84c>
     544:      	and	x8, x8, #0xfffffffffffffffc
     548:      	cbz	x8, 0x850 <kprobe_unwind_v8+0x850>
     54c:      	ldrb	w9, [x23, #0xd]
     550:      	mov	w10, #0x2               // =2
     554:      	mov	w11, #0x70              // =112
     558:      	add	x12, sp, #0x70
     55c:      	add	x0, sp, #0x70
     560:      	mov	w1, #0x2                // =2
     564:      	add	x9, x8, x9
     568:      	ldrb	w9, [x23, #0xd]
     56c:      	add	x2, x8, x9
     570:      	blr	x11
     574:      	ldrh	w8, [sp, #0x70]
     578:      	cmp	x0, #0x0
     57c:      	csel	w8, w8, wzr, eq
     580:      	b	0x850 <kprobe_unwind_v8+0x850>
     584:      	mov	x11, xzr
     588:      	mov	w8, wzr
     58c:      	ldrh	w9, [x23, #0xa]
     590:      	cmp	w9, wzr, uxth
     594:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
     598:      	lsr	x25, x22, #32
     59c:      	cbz	x25, 0x6dc <kprobe_unwind_v8+0x6dc>
     5a0:      	tbnz	w22, #0x0, 0x6dc <kprobe_unwind_v8+0x6dc>
     5a4:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     5a8:      	ldr	x8, [x8]
     5ac:      	ldr	w8, [x8]
     5b0:      	cbnz	w8, 0x13f0 <kprobe_unwind_v8+0x13f0>
     5b4:      	orr	x29, x11, #0x1
     5b8:      	b	0xa80 <kprobe_unwind_v8+0xa80>
     5bc:      	ldr	w8, [x22]
     5c0:      	cbnz	w8, 0xe18 <kprobe_unwind_v8+0xe18>
     5c4:      	mov	w29, wzr
     5c8:      	mov	w8, #0x2                // =2
     5cc:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
     5d0:      	ldr	x8, [x21, #0xee0]
     5d4:      	add	x9, x8, #0x10
     5d8:      	str	x9, [x21, #0xed8]
     5dc:      	ldp	x9, x10, [sp, #0x70]
     5e0:      	str	x9, [x21, #0xee0]
     5e4:      	mov	w9, #0x101              // =257
     5e8:      	str	x10, [x21, #0xed0]
     5ec:      	strh	w9, [x21, #0xf20]
     5f0:      	cbnz	x29, 0x604 <kprobe_unwind_v8+0x604>
     5f4:      	cmp	x25, #0x1
     5f8:      	b.ne	0x604 <kprobe_unwind_v8+0x604>
     5fc:      	add	x8, x8, #0xa0
     600:      	str	x8, [x21, #0xed8]
     604:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     608:      	adrp	x0, 0x0 <kprobe_unwind_v8>
     60c:      	ldr	x8, [x8]
     610:      	ldr	w8, [x8]
     614:      	ldr	x0, [x0]
     618:      	cbnz	w8, 0xe60 <kprobe_unwind_v8+0xe60>
     61c:      	mov	w8, #0x38               // =56
     620:      	add	x9, sp, #0x58
     624:      	add	x1, sp, #0x58
     628:      	str	w8, [sp, #0x58]
     62c:      	mov	w8, #0x1                // =1
     630:      	blr	x8
     634:      	cbz	x0, 0x654 <kprobe_unwind_v8+0x654>
     638:      	ldr	x8, [x0]
     63c:      	add	x8, x8, #0x1
     640:      	str	x8, [x0]
     644:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     648:      	ldr	x8, [x8]
     64c:      	ldr	w8, [x8]
     650:      	b	0x664 <kprobe_unwind_v8+0x664>
     654:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     658:      	ldr	x8, [x8]
     65c:      	ldr	w8, [x8]
     660:      	cbnz	w8, 0x1368 <kprobe_unwind_v8+0x1368>
     664:      	ldr	x24, [x21, #0xed0]
     668:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
     66c:      	cbnz	w8, 0xeb0 <kprobe_unwind_v8+0xeb0>
     670:      	lsr	x8, x24, #56
     674:      	cbz	x8, 0xefc <kprobe_unwind_v8+0xefc>
     678:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     67c:      	ldr	x22, [x22]
     680:      	ldr	w8, [x22]
     684:      	cbnz	w8, 0x13b0 <kprobe_unwind_v8+0x13b0>
     688:      	mov	w8, #0xb                // =11
     68c:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     690:      	mov	w29, wzr
     694:      	str	w8, [x21, #0xf18]
     698:      	mov	w8, #0xfab              // =4011
     69c:      	ldr	x24, [x24]
     6a0:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
     6a4:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     6a8:      	add	x8, x8, #0x0
     6ac:      	add	x0, sp, #0x70
     6b0:      	ldp	x9, x10, [x8]
     6b4:      	ldr	x8, [x8, #0x10]
     6b8:      	mov	w1, #0x18               // =24
     6bc:      	stp	x9, x10, [sp, #0x70]
     6c0:      	str	x8, [sp, #0x80]
     6c4:      	mov	w8, #0x18               // =24
     6c8:      	mov	w9, #0x6                // =6
     6cc:      	add	x10, sp, #0x70
     6d0:      	ldr	w2, [x21, #0x2c0]
     6d4:      	blr	x9
     6d8:      	b	0x5c <kprobe_unwind_v8+0x5c>
     6dc:      	orr	x8, x11, #0x2
     6e0:      	ldr	x9, [sp, #0x40]
     6e4:      	add	x10, sp, #0x70
     6e8:      	add	x0, sp, #0x70
     6ec:      	stp	x11, x8, [sp, #0x30]
     6f0:      	ldrb	w8, [x23, #0xe]
     6f4:      	mov	w1, #0x8                // =8
     6f8:      	add	x2, x9, x8
     6fc:      	mov	w8, #0x8                // =8
     700:      	mov	w9, #0x70               // =112
     704:      	blr	x9
     708:      	cbnz	x0, 0x7b0 <kprobe_unwind_v8+0x7b0>
     70c:      	ldr	x8, [sp, #0x70]
     710:      	and	x9, x8, #0x3
     714:      	cmp	x9, #0x1
     718:      	b.ne	0x7b0 <kprobe_unwind_v8+0x7b0>
     71c:      	and	x8, x8, #0xfffffffffffffffc
     720:      	mov	x25, x8
     724:      	cbz	x8, 0x7b8 <kprobe_unwind_v8+0x7b8>
     728:      	ldrb	w8, [x23, #0xc]
     72c:      	mov	w9, #0x70               // =112
     730:      	add	x10, sp, #0x70
     734:      	add	x0, sp, #0x70
     738:      	mov	w1, #0x8                // =8
     73c:      	add	x2, x25, x8
     740:      	mov	w8, #0x8                // =8
     744:      	blr	x9
     748:      	cbnz	x0, 0xa08 <kprobe_unwind_v8+0xa08>
     74c:      	ldr	x8, [sp, #0x70]
     750:      	and	x9, x8, #0x3
     754:      	cmp	x9, #0x1
     758:      	b.ne	0xa08 <kprobe_unwind_v8+0xa08>
     75c:      	and	x8, x8, #0xfffffffffffffffc
     760:      	cbz	x8, 0x7b8 <kprobe_unwind_v8+0x7b8>
     764:      	ldrb	w9, [x23, #0xd]
     768:      	mov	w10, #0x2               // =2
     76c:      	mov	w11, #0x70              // =112
     770:      	add	x12, sp, #0x70
     774:      	add	x0, sp, #0x70
     778:      	mov	w1, #0x2                // =2
     77c:      	add	x9, x8, x9
     780:      	ldrb	w9, [x23, #0xd]
     784:      	add	x2, x8, x9
     788:      	blr	x11
     78c:      	ldrh	w8, [sp, #0x70]
     790:      	cmp	x0, #0x0
     794:      	csel	w8, w8, wzr, eq
     798:      	and	w4, w8, #0xffff
     79c:      	ldrh	w8, [x23, #0x8]
     7a0:      	ldr	x0, [sp, #0x48]
     7a4:      	cmp	w4, w8
     7a8:      	b.eq	0x7cc <kprobe_unwind_v8+0x7cc>
     7ac:      	b	0xa20 <kprobe_unwind_v8+0xa20>
     7b0:      	mov	x25, xzr
     7b4:      	mov	w8, wzr
     7b8:      	and	w4, w8, #0xffff
     7bc:      	ldrh	w8, [x23, #0x8]
     7c0:      	ldr	x0, [sp, #0x48]
     7c4:      	cmp	w4, w8
     7c8:      	b.ne	0xa20 <kprobe_unwind_v8+0xa20>
     7cc:      	mov	w8, #0x60               // =96
     7d0:      	mov	w9, #0x70               // =112
     7d4:      	mov	w1, #0x60               // =96
     7d8:      	mov	x2, x25
     7dc:      	blr	x9
     7e0:      	cbz	x0, 0x978 <kprobe_unwind_v8+0x978>
     7e4:      	mov	w8, #0x3b               // =59
     7e8:      	adrp	x0, 0x0 <kprobe_unwind_v8>
     7ec:      	add	x9, sp, #0x58
     7f0:      	str	w8, [sp, #0x58]
     7f4:      	mov	w8, #0x1                // =1
     7f8:      	add	x1, sp, #0x58
     7fc:      	ldr	x0, [x0]
     800:      	blr	x8
     804:      	cbz	x0, 0x9f0 <kprobe_unwind_v8+0x9f0>
     808:      	ldr	x8, [x0]
     80c:      	add	x8, x8, #0x1
     810:      	str	x8, [x0]
     814:      	b	0xa00 <kprobe_unwind_v8+0xa00>
     818:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     81c:      	add	x8, x8, #0x0
     820:      	add	x0, sp, #0x70
     824:      	ldp	x9, x10, [x8]
     828:      	mov	w1, #0x20               // =32
     82c:      	stp	x9, x10, [sp, #0x70]
     830:      	ldp	x9, x8, [x8, #0x10]
     834:      	add	x10, sp, #0x70
     838:      	stp	x9, x8, [sp, #0x80]
     83c:      	mov	w8, #0x20               // =32
     840:      	mov	w9, #0x6                // =6
     844:      	blr	x9
     848:      	b	0x11c <kprobe_unwind_v8+0x11c>
     84c:      	mov	w8, wzr
     850:      	mov	x11, x25
     854:      	ldrh	w9, [x23, #0xa]
     858:      	cmp	w9, w8, uxth
     85c:      	b.eq	0x598 <kprobe_unwind_v8+0x598>
     860:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     864:      	ldr	x22, [x22]
     868:      	ldr	w8, [x22]
     86c:      	cbnz	w8, 0x132c <kprobe_unwind_v8+0x132c>
     870:      	mov	w8, #0x3a               // =58
     874:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     878:      	add	x9, sp, #0x58
     87c:      	str	w8, [sp, #0x58]
     880:      	mov	w8, #0x1                // =1
     884:      	add	x1, sp, #0x58
     888:      	ldr	x24, [x24]
     88c:      	mov	x0, x24
     890:      	blr	x8
     894:      	cbnz	x0, 0x3dc <kprobe_unwind_v8+0x3dc>
     898:      	ldr	w8, [x22]
     89c:      	cbz	w8, 0x4c0 <kprobe_unwind_v8+0x4c0>
     8a0:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     8a4:      	add	x8, x8, #0x0
     8a8:      	ldp	x9, x10, [x8, #0x10]
     8ac:      	stp	x9, x10, [sp, #0x80]
     8b0:      	ldr	x9, [x8, #0x20]
     8b4:      	add	x10, sp, #0x70
     8b8:      	str	x9, [sp, #0x90]
     8bc:      	ldur	x9, [x8, #0x26]
     8c0:      	stur	x9, [sp, #0x96]
     8c4:      	ldp	x9, x8, [x8]
     8c8:      	stp	x9, x8, [sp, #0x70]
     8cc:      	mov	w8, #0x2e               // =46
     8d0:      	mov	w9, #0x6                // =6
     8d4:      	b	0xde8 <kprobe_unwind_v8+0xde8>
     8d8:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     8dc:      	add	x8, x8, #0x0
     8e0:      	add	x0, sp, #0x70
     8e4:      	ldp	x9, x10, [x8, #0x10]
     8e8:      	mov	w1, #0x2e               // =46
     8ec:      	stp	x9, x10, [sp, #0x80]
     8f0:      	ldr	x9, [x8, #0x20]
     8f4:      	add	x10, sp, #0x70
     8f8:      	str	x9, [sp, #0x90]
     8fc:      	ldur	x9, [x8, #0x26]
     900:      	stur	x9, [sp, #0x96]
     904:      	ldp	x9, x8, [x8]
     908:      	stp	x9, x8, [sp, #0x70]
     90c:      	mov	w8, #0x2e               // =46
     910:      	mov	w9, #0x6                // =6
     914:      	ldr	w2, [sp, #0x58]
     918:      	blr	x9
     91c:      	ldr	x29, [x21, #0xed8]
     920:      	ldr	x25, [x21, #0xee0]
     924:      	ldr	x24, [x21, #0xed0]
     928:      	ldr	w8, [x22]
     92c:      	cbz	w8, 0x168 <kprobe_unwind_v8+0x168>
     930:      	b	0xc4 <kprobe_unwind_v8+0xc4>
     934:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     938:      	add	x8, x8, #0x0
     93c:      	add	x0, sp, #0x70
     940:      	ldp	x9, x10, [x8, #0x10]
     944:      	mov	w1, #0x2e               // =46
     948:      	stp	x9, x10, [sp, #0x80]
     94c:      	ldr	x9, [x8, #0x20]
     950:      	add	x10, sp, #0x70
     954:      	str	x9, [sp, #0x90]
     958:      	ldur	x9, [x8, #0x26]
     95c:      	stur	x9, [sp, #0x96]
     960:      	ldp	x9, x8, [x8]
     964:      	stp	x9, x8, [sp, #0x70]
     968:      	mov	w8, #0x2e               // =46
     96c:      	mov	w9, #0x6                // =6
     970:      	blr	x9
     974:      	b	0x1ac <kprobe_unwind_v8+0x1ac>
     978:      	ldrb	w8, [x23, #0x12]
     97c:      	cmp	x8, #0x5c
     980:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
     984:      	ldrb	w9, [x23, #0x13]
     988:      	cmp	x9, #0x5c
     98c:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
     990:      	ldrb	w11, [x23, #0x10]
     994:      	ldrb	w10, [x23, #0x11]
     998:      	cbz	w11, 0xaec <kprobe_unwind_v8+0xaec>
     99c:      	ldr	x11, [sp, #0x48]
     9a0:      	ldr	x22, [x11, x10]
     9a4:      	b	0xaf0 <kprobe_unwind_v8+0xaf0>
     9a8:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     9ac:      	add	x8, x8, #0x0
     9b0:      	add	x0, sp, #0x70
     9b4:      	ldp	x9, x10, [x8, #0x10]
     9b8:      	mov	w1, #0x2e               // =46
     9bc:      	stp	x9, x10, [sp, #0x80]
     9c0:      	ldr	x9, [x8, #0x20]
     9c4:      	add	x10, sp, #0x70
     9c8:      	str	x9, [sp, #0x90]
     9cc:      	ldur	x9, [x8, #0x26]
     9d0:      	stur	x9, [sp, #0x96]
     9d4:      	ldp	x9, x8, [x8]
     9d8:      	stp	x9, x8, [sp, #0x70]
     9dc:      	mov	w8, #0x2e               // =46
     9e0:      	mov	w9, #0x6                // =6
     9e4:      	ldr	w2, [sp, #0x58]
     9e8:      	blr	x9
     9ec:      	b	0x21c <kprobe_unwind_v8+0x21c>
     9f0:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     9f4:      	ldr	x8, [x8]
     9f8:      	ldr	w8, [x8]
     9fc:      	cbnz	w8, 0x1bbc <kprobe_unwind_v8+0x1bbc>
     a00:      	ldr	x29, [sp, #0x38]
     a04:      	b	0xa7c <kprobe_unwind_v8+0xa7c>
     a08:      	mov	w8, wzr
     a0c:      	and	w4, wzr, #0xffff
     a10:      	ldrh	w8, [x23, #0x8]
     a14:      	ldr	x0, [sp, #0x48]
     a18:      	cmp	w4, w8
     a1c:      	b.eq	0x7cc <kprobe_unwind_v8+0x7cc>
     a20:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     a24:      	ldr	x8, [x8]
     a28:      	ldr	w8, [x8]
     a2c:      	cbnz	w8, 0x1518 <kprobe_unwind_v8+0x1518>
     a30:      	mov	w8, #0x3b               // =59
     a34:      	adrp	x0, 0x0 <kprobe_unwind_v8>
     a38:      	add	x9, sp, #0x58
     a3c:      	str	w8, [sp, #0x58]
     a40:      	mov	w8, #0x1                // =1
     a44:      	add	x1, sp, #0x58
     a48:      	ldr	x0, [x0]
     a4c:      	blr	x8
     a50:      	ldr	x29, [sp, #0x38]
     a54:      	cbz	x0, 0xa6c <kprobe_unwind_v8+0xa6c>
     a58:      	ldr	x8, [x0]
     a5c:      	mov	x25, xzr
     a60:      	add	x8, x8, #0x1
     a64:      	str	x8, [x0]
     a68:      	b	0xa80 <kprobe_unwind_v8+0xa80>
     a6c:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     a70:      	ldr	x8, [x8]
     a74:      	ldr	w8, [x8]
     a78:      	cbnz	w8, 0x18c0 <kprobe_unwind_v8+0x18c0>
     a7c:      	mov	x25, xzr
     a80:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     a84:      	ldr	x8, [x8]
     a88:      	ldrb	w24, [x21, #0xf20]
     a8c:      	ldr	w8, [x8]
     a90:      	cbz	w8, 0x29c <kprobe_unwind_v8+0x29c>
     a94:      	mov	w8, #0x786c             // =30828
     a98:      	add	x0, sp, #0x70
     a9c:      	mov	w1, #0x3c               // =60
     aa0:      	mov	x2, x25
     aa4:      	mov	x3, x29
     aa8:      	movk	w8, #0xa, lsl #16
     aac:      	str	w8, [sp, #0xa8]
     ab0:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     ab4:      	add	x8, x8, #0x0
     ab8:      	ldp	x9, x10, [x8, #0x20]
     abc:      	stp	x9, x10, [sp, #0x90]
     ac0:      	ldr	x9, [x8, #0x30]
     ac4:      	str	x9, [sp, #0xa0]
     ac8:      	ldp	x9, x10, [x8]
     acc:      	stp	x9, x10, [sp, #0x70]
     ad0:      	add	x10, sp, #0x70
     ad4:      	ldp	x8, x9, [x8, #0x10]
     ad8:      	stp	x8, x9, [sp, #0x80]
     adc:      	mov	w8, #0x3c               // =60
     ae0:      	mov	w9, #0x6                // =6
     ae4:      	blr	x9
     ae8:      	b	0x29c <kprobe_unwind_v8+0x29c>
     aec:      	add	x22, x25, x10
     af0:      	ldr	x10, [sp, #0x48]
     af4:      	ldr	w9, [x10, x9]
     af8:      	ldr	w8, [x10, x8]
     afc:      	str	w9, [sp, #0x18]
     b00:      	ldrb	w9, [x23, #0x18]
     b04:      	str	x8, [sp, #0x20]
     b08:      	add	x8, x22, x8
     b0c:      	str	x8, [sp, #0x28]
     b10:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     b14:      	str	w9, [sp, #0xc]
     b18:      	ldrb	w9, [x23, #0x17]
     b1c:      	str	x9, [sp, #0x10]
     b20:      	ldr	x8, [x8]
     b24:      	ldr	w8, [x8]
     b28:      	cbnz	w8, 0x1c18 <kprobe_unwind_v8+0x1c18>
     b2c:      	cmp	x24, x22
     b30:      	b.lo	0xb80 <kprobe_unwind_v8+0xb80>
     b34:      	ldr	x8, [sp, #0x28]
     b38:      	cmp	x24, x8
     b3c:      	b.hs	0xb80 <kprobe_unwind_v8+0xb80>
     b40:      	ldr	w8, [sp, #0x18]
     b44:      	ldr	w9, [sp, #0xc]
     b48:      	orr	x11, x25, #0x3
     b4c:      	and	w8, w8, w9
     b50:      	ldr	x9, [sp, #0x10]
     b54:      	ldr	x10, [sp, #0x40]
     b58:      	orr	x10, x10, #0x4
     b5c:      	lsr	w8, w8, w9
     b60:      	ldrb	w9, [x23, #0x19]
     b64:      	cmp	w8, w9
     b68:      	ldr	x9, [sp, #0x20]
     b6c:      	csel	x29, x10, x11, eq
     b70:      	orr	w8, w8, w9, lsl #4
     b74:      	sub	x9, x24, x22
     b78:      	orr	x25, x9, x8, lsl #32
     b7c:      	b	0xa80 <kprobe_unwind_v8+0xa80>
     b80:      	ldr	w8, [x21, #0x2c0]
     b84:      	cbz	w8, 0xba8 <kprobe_unwind_v8+0xba8>
     b88:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     b8c:      	ldr	x8, [x8]
     b90:      	ldr	w8, [x8]
     b94:      	cbnz	w8, 0x1ea4 <kprobe_unwind_v8+0x1ea4>
     b98:      	ldr	x29, [sp, #0x38]
     b9c:      	ldrb	w24, [x21, #0xf20]
     ba0:      	mov	x25, xzr
     ba4:      	b	0x29c <kprobe_unwind_v8+0x29c>
     ba8:      	sub	x2, x29, #0x18
     bac:      	mov	w8, #0x18               // =24
     bb0:      	mov	w9, #0x70               // =112
     bb4:      	add	x10, sp, #0x58
     bb8:      	add	x0, sp, #0x58
     bbc:      	mov	w1, #0x18               // =24
     bc0:      	blr	x9
     bc4:      	cbz	x0, 0xcdc <kprobe_unwind_v8+0xcdc>
     bc8:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     bcc:      	ldr	x8, [x8]
     bd0:      	ldr	w8, [x8]
     bd4:      	cbnz	w8, 0x1f28 <kprobe_unwind_v8+0x1f28>
     bd8:      	mov	w8, #0x39               // =57
     bdc:      	adrp	x0, 0x0 <kprobe_unwind_v8>
     be0:      	add	x9, sp, #0xbc
     be4:      	str	w8, [sp, #0xbc]
     be8:      	mov	w8, #0x1                // =1
     bec:      	add	x1, sp, #0xbc
     bf0:      	ldr	x0, [x0]
     bf4:      	blr	x8
     bf8:      	cbz	x0, 0xdfc <kprobe_unwind_v8+0xdfc>
     bfc:      	ldr	x8, [x0]
     c00:      	add	x8, x8, #0x1
     c04:      	str	x8, [x0]
     c08:      	b	0xe0c <kprobe_unwind_v8+0xe0c>
     c0c:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     c10:      	add	x8, x8, #0x0
     c14:      	add	x0, sp, #0x70
     c18:      	ldp	x9, x10, [x8]
     c1c:      	mov	w1, #0x1d               // =29
     c20:      	mov	x2, x25
     c24:      	stp	x9, x10, [sp, #0x70]
     c28:      	ldr	x9, [x8, #0x10]
     c2c:      	ldur	x8, [x8, #0x15]
     c30:      	add	x10, sp, #0x70
     c34:      	str	x9, [sp, #0x80]
     c38:      	stur	x8, [sp, #0x85]
     c3c:      	mov	w8, #0x1d               // =29
     c40:      	mov	w9, #0x6                // =6
     c44:      	blr	x9
     c48:      	mov	x29, xzr
     c4c:      	b	0xa80 <kprobe_unwind_v8+0xa80>
     c50:      	mov	w9, #0xa                // =10
     c54:      	add	x0, sp, #0x70
     c58:      	and	w3, w8, #0xffff
     c5c:      	strh	w9, [sp, #0x98]
     c60:      	adrp	x9, 0x0 <kprobe_unwind_v8>
     c64:      	add	x9, x9, #0x0
     c68:      	mov	w1, #0x2a               // =42
     c6c:      	ldp	x10, x11, [x9, #0x10]
     c70:      	stp	x10, x11, [sp, #0x80]
     c74:      	ldr	x10, [x9, #0x20]
     c78:      	add	x11, sp, #0x70
     c7c:      	str	x10, [sp, #0x90]
     c80:      	ldp	x9, x10, [x9]
     c84:      	stp	x9, x10, [sp, #0x70]
     c88:      	mov	w9, #0x2a               // =42
     c8c:      	mov	w10, #0x6               // =6
     c90:      	ldrh	w2, [x23, #0x4]
     c94:      	ldrh	w4, [x23, #0x6]
     c98:      	blr	x10
     c9c:      	b	0x3b4 <kprobe_unwind_v8+0x3b4>
     ca0:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     ca4:      	add	x8, x8, #0x0
     ca8:      	add	x0, sp, #0x70
     cac:      	ldp	x9, x10, [x8, #0x10]
     cb0:      	mov	w1, #0x25               // =37
     cb4:      	stp	x9, x10, [sp, #0x80]
     cb8:      	ldur	x9, [x8, #0x1d]
     cbc:      	add	x10, sp, #0x70
     cc0:      	stur	x9, [sp, #0x8d]
     cc4:      	ldp	x8, x9, [x8]
     cc8:      	stp	x8, x9, [sp, #0x70]
     ccc:      	mov	w8, #0x25               // =37
     cd0:      	mov	w9, #0x6                // =6
     cd4:      	blr	x9
     cd8:      	b	0x2b8 <kprobe_unwind_v8+0x2b8>
     cdc:      	ldr	x24, [sp, #0x68]
     ce0:      	cmp	x24, x22
     ce4:      	b.lo	0xcf4 <kprobe_unwind_v8+0xcf4>
     ce8:      	ldr	x8, [sp, #0x28]
     cec:      	cmp	x24, x8
     cf0:      	b.lo	0xd24 <kprobe_unwind_v8+0xd24>
     cf4:      	ldr	x24, [sp, #0x60]
     cf8:      	cmp	x24, x22
     cfc:      	b.lo	0xd0c <kprobe_unwind_v8+0xd0c>
     d00:      	ldr	x8, [sp, #0x28]
     d04:      	cmp	x24, x8
     d08:      	b.lo	0xd24 <kprobe_unwind_v8+0xd24>
     d0c:      	ldr	x24, [sp, #0x58]
     d10:      	cmp	x24, x22
     d14:      	b.lo	0x143c <kprobe_unwind_v8+0x143c>
     d18:      	ldr	x8, [sp, #0x28]
     d1c:      	cmp	x24, x8
     d20:      	b.hs	0x143c <kprobe_unwind_v8+0x143c>
     d24:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     d28:      	ldr	x8, [x8]
     d2c:      	ldr	w8, [x8]
     d30:      	cbz	w8, 0xb40 <kprobe_unwind_v8+0xb40>
     d34:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     d38:      	add	x8, x8, #0x0
     d3c:      	add	x0, sp, #0x70
     d40:      	ldp	x9, x10, [x8, #0x10]
     d44:      	mov	w1, #0x27               // =39
     d48:      	mov	x2, x24
     d4c:      	stp	x9, x10, [sp, #0x80]
     d50:      	ldur	x9, [x8, #0x1f]
     d54:      	add	x10, sp, #0x70
     d58:      	stur	x9, [sp, #0x8f]
     d5c:      	ldp	x8, x9, [x8]
     d60:      	stp	x8, x9, [sp, #0x70]
     d64:      	mov	w8, #0x27               // =39
     d68:      	mov	w9, #0x6                // =6
     d6c:      	blr	x9
     d70:      	b	0xb40 <kprobe_unwind_v8+0xb40>
     d74:      	mov	w8, #0x7265             // =29285
     d78:      	add	x0, sp, #0x70
     d7c:      	mov	w1, #0x1c               // =28
     d80:      	movk	w8, #0xa, lsl #16
     d84:      	str	w8, [sp, #0x88]
     d88:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     d8c:      	add	x8, x8, #0x0
     d90:      	ldp	x9, x10, [x8]
     d94:      	ldr	x8, [x8, #0x10]
     d98:      	stp	x9, x10, [sp, #0x70]
     d9c:      	str	x8, [sp, #0x80]
     da0:      	mov	w8, #0x1c               // =28
     da4:      	mov	w9, #0x6                // =6
     da8:      	add	x10, sp, #0x70
     dac:      	blr	x9
     db0:      	b	0x450 <kprobe_unwind_v8+0x450>
     db4:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     db8:      	add	x8, x8, #0x0
     dbc:      	ldp	x9, x10, [x8, #0x10]
     dc0:      	stp	x9, x10, [sp, #0x80]
     dc4:      	ldr	x9, [x8, #0x20]
     dc8:      	add	x10, sp, #0x70
     dcc:      	str	x9, [sp, #0x90]
     dd0:      	ldur	x9, [x8, #0x26]
     dd4:      	stur	x9, [sp, #0x96]
     dd8:      	ldp	x9, x8, [x8]
     ddc:      	stp	x9, x8, [sp, #0x70]
     de0:      	mov	w8, #0x2e               // =46
     de4:      	mov	w9, #0x6                // =6
     de8:      	ldr	w2, [sp, #0x58]
     dec:      	add	x0, sp, #0x70
     df0:      	mov	w1, #0x2e               // =46
     df4:      	blr	x9
     df8:      	b	0x4c0 <kprobe_unwind_v8+0x4c0>
     dfc:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     e00:      	ldr	x8, [x8]
     e04:      	ldr	w8, [x8]
     e08:      	cbnz	w8, 0x201c <kprobe_unwind_v8+0x201c>
     e0c:      	mov	w29, wzr
     e10:      	mov	w8, #0x1388             // =5000
     e14:      	b	0x258 <kprobe_unwind_v8+0x258>
     e18:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     e1c:      	add	x8, x8, #0x0
     e20:      	add	x0, sp, #0x70
     e24:      	ldp	x9, x10, [x8, #0x10]
     e28:      	mov	w1, #0x2e               // =46
     e2c:      	stp	x9, x10, [sp, #0x80]
     e30:      	ldr	x9, [x8, #0x20]
     e34:      	add	x10, sp, #0x70
     e38:      	str	x9, [sp, #0x90]
     e3c:      	ldur	x9, [x8, #0x26]
     e40:      	stur	x9, [sp, #0x96]
     e44:      	ldp	x9, x8, [x8]
     e48:      	stp	x9, x8, [sp, #0x70]
     e4c:      	mov	w8, #0x2e               // =46
     e50:      	mov	w9, #0x6                // =6
     e54:      	ldr	w2, [sp, #0x58]
     e58:      	blr	x9
     e5c:      	b	0x5c4 <kprobe_unwind_v8+0x5c4>
     e60:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     e64:      	add	x8, x8, #0x0
     e68:      	mov	x24, x0
     e6c:      	ldp	x9, x10, [x8]
     e70:      	add	x0, sp, #0x70
     e74:      	mov	w1, #0x1f               // =31
     e78:      	stp	x9, x10, [sp, #0x70]
     e7c:      	ldr	x9, [x8, #0x10]
     e80:      	ldur	x8, [x8, #0x17]
     e84:      	add	x10, sp, #0x70
     e88:      	str	x9, [sp, #0x80]
     e8c:      	stur	x8, [sp, #0x87]
     e90:      	mov	w8, #0x1f               // =31
     e94:      	mov	w9, #0x6                // =6
     e98:      	ldr	x2, [x21, #0xed0]
     e9c:      	ldr	x3, [x21, #0xed8]
     ea0:      	ldr	x4, [x21, #0xee0]
     ea4:      	blr	x9
     ea8:      	mov	x0, x24
     eac:      	b	0x61c <kprobe_unwind_v8+0x61c>
     eb0:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     eb4:      	add	x8, x8, #0x0
     eb8:      	strb	wzr, [sp, #0xa0]
     ebc:      	add	x0, sp, #0x70
     ec0:      	ldp	x9, x10, [x8, #0x10]
     ec4:      	mov	w1, #0x31               // =49
     ec8:      	stp	x9, x10, [sp, #0x80]
     ecc:      	ldp	x9, x10, [x8, #0x20]
     ed0:      	stp	x9, x10, [sp, #0x90]
     ed4:      	ldp	x9, x8, [x8]
     ed8:      	add	x10, sp, #0x70
     edc:      	stp	x9, x8, [sp, #0x70]
     ee0:      	mov	w8, #0x31               // =49
     ee4:      	mov	w9, #0x6                // =6
     ee8:      	ldr	w2, [x21, #0x2c0]
     eec:      	blr	x9
     ef0:      	ldr	x24, [x21, #0xed0]
     ef4:      	lsr	x8, x24, #56
     ef8:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
     efc:      	cmp	x24, #0xfff
     f00:      	b.hi	0xf30 <kprobe_unwind_v8+0xf30>
     f04:      	adrp	x22, 0x0 <kprobe_unwind_v8>
     f08:      	ldr	x22, [x22]
     f0c:      	ldr	w8, [x22]
     f10:      	cbnz	w8, 0x14d8 <kprobe_unwind_v8+0x14d8>
     f14:      	mov	w8, #0x31               // =49
     f18:      	adrp	x24, 0x0 <kprobe_unwind_v8>
     f1c:      	mov	w29, wzr
     f20:      	str	w8, [x21, #0xf18]
     f24:      	mov	w8, #0xfae              // =4014
     f28:      	ldr	x24, [x24]
     f2c:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
     f30:      	ldr	w8, [x21]
     f34:      	mov	w9, #0x60               // =96
     f38:      	adrp	x0, 0x0 <kprobe_unwind_v8>
     f3c:      	add	x1, sp, #0x58
     f40:      	rev	w8, w8
     f44:      	stp	w9, w8, [sp, #0x58]
     f48:      	rev	x8, x24
     f4c:      	add	x9, sp, #0x58
     f50:      	str	x8, [sp, #0x60]
     f54:      	mov	w8, #0x1                // =1
     f58:      	ldr	x0, [x0]
     f5c:      	blr	x8
     f60:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
     f64:      	ldr	x8, [x0, #0x8]
     f68:      	and	x9, x8, #0xffffffffffffff
     f6c:      	lsr	x29, x8, #56
     f70:      	str	x9, [x21, #0xf10]
     f74:      	ldr	x8, [x0]
     f78:      	str	x8, [x21, #0xf00]
     f7c:      	sub	x8, x24, x9
     f80:      	str	x8, [x21, #0xf08]
     f84:      	adrp	x8, 0x0 <kprobe_unwind_v8>
     f88:      	ldr	x8, [x8]
     f8c:      	ldr	w8, [x8]
     f90:      	cbnz	w8, 0x1564 <kprobe_unwind_v8+0x1564>
     f94:      	cmp	w29, #0x1
     f98:      	b.ne	0x1034 <kprobe_unwind_v8+0x1034>
     f9c:      	ldr	x8, [x21, #0xf00]
     fa0:      	adrp	x0, 0x0 <kprobe_unwind_v8>
     fa4:      	ldr	x25, [x21, #0xf08]
     fa8:      	mov	w9, #0x1                // =1
     fac:      	add	x1, sp, #0x58
     fb0:      	mov	w29, #0x1               // =1
     fb4:      	str	x8, [sp, #0x58]
     fb8:      	add	x8, sp, #0x58
     fbc:      	ldr	x0, [x0]
     fc0:      	blr	x9
     fc4:      	cbz	x0, 0x1034 <kprobe_unwind_v8+0x1034>
     fc8:      	ldr	x8, [x0]
     fcc:      	mov	x24, x0
     fd0:      	cmp	x8, x25
     fd4:      	b.hi	0xfe4 <kprobe_unwind_v8+0xfe4>
     fd8:      	ldr	x8, [x24, #0x8]
     fdc:      	cmp	x8, x25
     fe0:      	b.hs	0xffc <kprobe_unwind_v8+0xffc>
     fe4:      	ldr	x8, [x24, #0x10]
     fe8:      	cmp	x8, x25
     fec:      	b.hi	0x102c <kprobe_unwind_v8+0x102c>
     ff0:      	ldr	x8, [x24, #0x18]
     ff4:      	cmp	x8, x25
     ff8:      	b.lo	0x102c <kprobe_unwind_v8+0x102c>
     ffc:      	adrp	x8, 0x0 <kprobe_unwind_v8>
    1000:      	ldr	x8, [x8]
    1004:      	ldr	w8, [x8]
    1008:      	cbnz	w8, 0x1ce4 <kprobe_unwind_v8+0x1ce4>
    100c:      	ldrh	w8, [x24, #0x20]
    1010:      	ldr	w9, [x21, #0x1370]
    1014:      	lsr	w8, w9, w8
    1018:      	tbz	w8, #0x0, 0x1d30 <kprobe_unwind_v8+0x1d30>
    101c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1020:      	ldr	x8, [x8]
    1024:      	ldr	w8, [x8]
    1028:      	cbnz	w8, 0x1d7c <kprobe_unwind_v8+0x1d7c>
    102c:      	mov	w29, #0x1               // =1
    1030:      	b	0x1034 <kprobe_unwind_v8+0x1034>
    1034:      	cmp	w29, #0x7
    1038:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    103c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1040:      	ldr	x29, [x21, #0xed8]
    1044:      	ldr	x25, [x21, #0xee0]
    1048:      	ldr	x24, [x21, #0xed0]
    104c:      	ldr	x8, [x8]
    1050:      	ldr	w8, [x8]
    1054:      	cbnz	w8, 0x1908 <kprobe_unwind_v8+0x1908>
    1058:      	cmp	x25, x29
    105c:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    1060:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    1064:      	cmp	x25, x8
    1068:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    106c:      	ldr	x0, [sp, #0x50]
    1070:      	sub	x2, x25, #0x40
    1074:      	mov	w8, #0x40               // =64
    1078:      	mov	w9, #0x70               // =112
    107c:      	mov	w1, #0x40               // =64
    1080:      	blr	x9
    1084:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    1088:      	ldrb	w9, [x23, #0x14]
    108c:      	cmp	x9, #0x38
    1090:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    1094:      	ldrb	w8, [x23, #0x15]
    1098:      	cmp	x8, #0x38
    109c:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    10a0:      	ldrb	w10, [x23, #0x16]
    10a4:      	cmp	x10, #0x38
    10a8:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    10ac:      	ldr	x11, [sp, #0x50]
    10b0:      	ldr	x9, [x11, x9]
    10b4:      	tbnz	w9, #0x0, 0x11b8 <kprobe_unwind_v8+0x11b8>
    10b8:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    10bc:      	lsr	x25, x9, #1
    10c0:      	ldr	x8, [x8]
    10c4:      	ldr	w8, [x8]
    10c8:      	cbnz	w8, 0x2064 <kprobe_unwind_v8+0x2064>
    10cc:      	ldrb	w24, [x21, #0xf20]
    10d0:      	mov	x22, xzr
    10d4:      	ldr	w8, [x21, #0x2c0]
    10d8:      	cmp	w8, #0x7e
    10dc:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    10e0:      	add	w9, w8, #0x1
    10e4:      	mov	w10, #0x8               // =8
    10e8:      	add	x11, sp, #0x70
    10ec:      	str	w9, [x21, #0x2c0]
    10f0:      	mov	w9, #0x18               // =24
    10f4:      	add	x0, sp, #0x70
    10f8:      	mov	w1, #0x10               // =16
    10fc:      	umaddl	x8, w8, w9, x21
    1100:      	add	x9, x8, #0x2d0
    1104:      	str	x22, [x8, #0x2d0]
    1108:      	str	x25, [x8, #0x2d8]
    110c:      	strb	w10, [x8, #0x2e0]
    1110:      	strb	w24, [x8, #0x2e1]
    1114:      	strh	wzr, [x8, #0x2e6]
    1118:      	mov	w10, #0x70              // =112
    111c:      	stur	wzr, [x9, #0x12]
    1120:      	mov	w9, #0x10               // =16
    1124:      	ldr	x8, [x21, #0xee0]
    1128:      	ldr	x2, [x21, #0xee0]
    112c:      	blr	x10
    1130:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    1134:      	ldr	x8, [x21, #0xee0]
    1138:      	add	x9, x8, #0x10
    113c:      	str	x9, [x21, #0xed8]
    1140:      	ldp	x9, x10, [sp, #0x70]
    1144:      	str	x9, [x21, #0xee0]
    1148:      	mov	w9, #0x101              // =257
    114c:      	str	x10, [x21, #0xed0]
    1150:      	strh	w9, [x21, #0xf20]
    1154:      	cbnz	x22, 0x1168 <kprobe_unwind_v8+0x1168>
    1158:      	cmp	x25, #0x1
    115c:      	b.ne	0x1168 <kprobe_unwind_v8+0x1168>
    1160:      	add	x8, x8, #0xa0
    1164:      	str	x8, [x21, #0xed8]
    1168:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    116c:      	ldr	x8, [x8]
    1170:      	ldr	w8, [x8]
    1174:      	cbnz	w8, 0x20a8 <kprobe_unwind_v8+0x20a8>
    1178:      	mov	w8, #0x38               // =56
    117c:      	adrp	x0, 0x1000 <kprobe_unwind_v8+0x1000>
    1180:      	add	x9, sp, #0x58
    1184:      	str	w8, [sp, #0x58]
    1188:      	mov	w8, #0x1                // =1
    118c:      	add	x1, sp, #0x58
    1190:      	ldr	x0, [x0]
    1194:      	blr	x8
    1198:      	cbz	x0, 0x160c <kprobe_unwind_v8+0x160c>
    119c:      	ldr	x8, [x0]
    11a0:      	add	x8, x8, #0x1
    11a4:      	str	x8, [x0]
    11a8:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    11ac:      	ldr	x8, [x8]
    11b0:      	ldr	w8, [x8]
    11b4:      	b	0x161c <kprobe_unwind_v8+0x161c>
    11b8:      	ldr	x9, [sp, #0x50]
    11bc:      	ldr	x8, [x9, x8]
    11c0:      	ldr	x22, [x9, x10]
    11c4:      	and	x9, x8, #0x3
    11c8:      	and	x8, x8, #0xfffffffffffffffc
    11cc:      	cmp	x9, #0x1
    11d0:      	csel	x29, x8, xzr, eq
    11d4:      	cbz	x29, 0x124c <kprobe_unwind_v8+0x124c>
    11d8:      	ldrb	w8, [x23, #0xc]
    11dc:      	mov	w9, #0x70               // =112
    11e0:      	add	x10, sp, #0x70
    11e4:      	add	x0, sp, #0x70
    11e8:      	mov	w1, #0x8                // =8
    11ec:      	add	x2, x29, x8
    11f0:      	mov	w8, #0x8                // =8
    11f4:      	blr	x9
    11f8:      	cbnz	x0, 0x124c <kprobe_unwind_v8+0x124c>
    11fc:      	ldr	x8, [sp, #0x70]
    1200:      	and	x9, x8, #0x3
    1204:      	cmp	x9, #0x1
    1208:      	b.ne	0x124c <kprobe_unwind_v8+0x124c>
    120c:      	and	x8, x8, #0xfffffffffffffffc
    1210:      	cbz	x8, 0x1250 <kprobe_unwind_v8+0x1250>
    1214:      	ldrb	w9, [x23, #0xd]
    1218:      	mov	w10, #0x2               // =2
    121c:      	mov	w11, #0x70              // =112
    1220:      	add	x12, sp, #0x70
    1224:      	add	x0, sp, #0x70
    1228:      	mov	w1, #0x2                // =2
    122c:      	add	x9, x8, x9
    1230:      	ldrb	w9, [x23, #0xd]
    1234:      	add	x2, x8, x9
    1238:      	blr	x11
    123c:      	ldrh	w8, [sp, #0x70]
    1240:      	cmp	x0, #0x0
    1244:      	csel	w8, w8, wzr, eq
    1248:      	b	0x1250 <kprobe_unwind_v8+0x1250>
    124c:      	mov	w8, wzr
    1250:      	ldrh	w9, [x23, #0x4]
    1254:      	cmp	w9, w8, uxth
    1258:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    125c:      	ldrh	w9, [x23, #0x6]
    1260:      	cmp	w9, w8, uxth
    1264:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    1268:      	ldrb	w8, [x23, #0xf]
    126c:      	mov	w9, #0x70               // =112
    1270:      	add	x10, sp, #0x70
    1274:      	add	x0, sp, #0x70
    1278:      	mov	w1, #0x8                // =8
    127c:      	add	x2, x29, x8
    1280:      	mov	w8, #0x8                // =8
    1284:      	blr	x9
    1288:      	cbnz	x0, 0x149c <kprobe_unwind_v8+0x149c>
    128c:      	ldr	x8, [sp, #0x70]
    1290:      	and	x9, x8, #0x3
    1294:      	cmp	x9, #0x1
    1298:      	b.ne	0x149c <kprobe_unwind_v8+0x149c>
    129c:      	and	x8, x8, #0xfffffffffffffffc
    12a0:      	str	x8, [sp, #0x40]
    12a4:      	cbz	x8, 0x1c04 <kprobe_unwind_v8+0x1c04>
    12a8:      	ldrb	w8, [x23, #0xc]
    12ac:      	ldr	x9, [sp, #0x40]
    12b0:      	add	x10, sp, #0x70
    12b4:      	add	x0, sp, #0x70
    12b8:      	mov	w1, #0x8                // =8
    12bc:      	add	x2, x9, x8
    12c0:      	mov	w8, #0x8                // =8
    12c4:      	mov	w9, #0x70               // =112
    12c8:      	blr	x9
    12cc:      	cbnz	x0, 0x14a0 <kprobe_unwind_v8+0x14a0>
    12d0:      	ldr	x8, [sp, #0x70]
    12d4:      	and	x9, x8, #0x3
    12d8:      	cmp	x9, #0x1
    12dc:      	b.ne	0x14a0 <kprobe_unwind_v8+0x14a0>
    12e0:      	and	x8, x8, #0xfffffffffffffffc
    12e4:      	cbz	x8, 0x14a4 <kprobe_unwind_v8+0x14a4>
    12e8:      	ldrb	w9, [x23, #0xd]
    12ec:      	mov	w10, #0x2               // =2
    12f0:      	mov	w11, #0x70              // =112
    12f4:      	add	x12, sp, #0x70
    12f8:      	add	x0, sp, #0x70
    12fc:      	mov	w1, #0x2                // =2
    1300:      	add	x9, x8, x9
    1304:      	ldrb	w9, [x23, #0xd]
    1308:      	add	x2, x8, x9
    130c:      	blr	x11
    1310:      	ldrh	w8, [sp, #0x70]
    1314:      	cmp	x0, #0x0
    1318:      	csel	w8, w8, wzr, eq
    131c:      	ldrh	w9, [x23, #0xa]
    1320:      	cmp	w9, w8, uxth
    1324:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    1328:      	b	0x14b0 <kprobe_unwind_v8+0x14b0>
    132c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1330:      	add	x8, x8, #0x0
    1334:      	add	x0, sp, #0x70
    1338:      	ldp	x9, x10, [x8]
    133c:      	mov	w1, #0x1f               // =31
    1340:      	stp	x9, x10, [sp, #0x70]
    1344:      	ldr	x9, [x8, #0x10]
    1348:      	ldur	x8, [x8, #0x17]
    134c:      	add	x10, sp, #0x70
    1350:      	str	x9, [sp, #0x80]
    1354:      	stur	x8, [sp, #0x87]
    1358:      	mov	w8, #0x1f               // =31
    135c:      	mov	w9, #0x6                // =6
    1360:      	blr	x9
    1364:      	b	0x870 <kprobe_unwind_v8+0x870>
    1368:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    136c:      	add	x8, x8, #0x0
    1370:      	add	x0, sp, #0x70
    1374:      	ldp	x9, x10, [x8, #0x10]
    1378:      	mov	w1, #0x2e               // =46
    137c:      	stp	x9, x10, [sp, #0x80]
    1380:      	ldr	x9, [x8, #0x20]
    1384:      	add	x10, sp, #0x70
    1388:      	str	x9, [sp, #0x90]
    138c:      	ldur	x9, [x8, #0x26]
    1390:      	stur	x9, [sp, #0x96]
    1394:      	ldp	x9, x8, [x8]
    1398:      	stp	x9, x8, [sp, #0x70]
    139c:      	mov	w8, #0x2e               // =46
    13a0:      	mov	w9, #0x6                // =6
    13a4:      	ldr	w2, [sp, #0x58]
    13a8:      	blr	x9
    13ac:      	b	0x644 <kprobe_unwind_v8+0x644>
    13b0:      	mov	w8, #0xa                // =10
    13b4:      	add	x0, sp, #0x70
    13b8:      	mov	w1, #0x22               // =34
    13bc:      	strh	w8, [sp, #0x90]
    13c0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    13c4:      	add	x8, x8, #0x0
    13c8:      	mov	x2, x24
    13cc:      	ldp	x9, x10, [x8]
    13d0:      	stp	x9, x10, [sp, #0x70]
    13d4:      	ldp	x9, x8, [x8, #0x10]
    13d8:      	add	x10, sp, #0x70
    13dc:      	stp	x9, x8, [sp, #0x80]
    13e0:      	mov	w8, #0x22               // =34
    13e4:      	mov	w9, #0x6                // =6
    13e8:      	blr	x9
    13ec:      	b	0x688 <kprobe_unwind_v8+0x688>
    13f0:      	mov	w8, #0x786c             // =30828
    13f4:      	add	x0, sp, #0x70
    13f8:      	mov	w1, #0x1c               // =28
    13fc:      	mov	x2, x25
    1400:      	mov	x22, x11
    1404:      	movk	w8, #0xa, lsl #16
    1408:      	str	w8, [sp, #0x88]
    140c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1410:      	add	x8, x8, #0x0
    1414:      	ldp	x9, x10, [x8]
    1418:      	ldr	x8, [x8, #0x10]
    141c:      	stp	x9, x10, [sp, #0x70]
    1420:      	str	x8, [sp, #0x80]
    1424:      	mov	w8, #0x1c               // =28
    1428:      	mov	w9, #0x6                // =6
    142c:      	add	x10, sp, #0x70
    1430:      	blr	x9
    1434:      	mov	x11, x22
    1438:      	b	0x5b4 <kprobe_unwind_v8+0x5b4>
    143c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1440:      	ldr	x8, [x8]
    1444:      	ldr	w8, [x8]
    1448:      	cbz	w8, 0xa00 <kprobe_unwind_v8+0xa00>
    144c:      	mov	w8, #0x786c             // =30828
    1450:      	add	x0, sp, #0x70
    1454:      	mov	w1, #0x33               // =51
    1458:      	movk	w8, #0xa, lsl #16
    145c:      	stur	w8, [sp, #0x9f]
    1460:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1464:      	add	x8, x8, #0x0
    1468:      	ldp	x9, x10, [x8, #0x10]
    146c:      	stp	x9, x10, [sp, #0x80]
    1470:      	ldp	x9, x10, [x8, #0x20]
    1474:      	stp	x9, x10, [sp, #0x90]
    1478:      	ldp	x9, x8, [x8]
    147c:      	add	x10, sp, #0x70
    1480:      	stp	x9, x8, [sp, #0x70]
    1484:      	mov	w8, #0x33               // =51
    1488:      	mov	w9, #0x6                // =6
    148c:      	ldp	x3, x2, [sp, #0x60]
    1490:      	ldr	x4, [sp, #0x58]
    1494:      	blr	x9
    1498:      	b	0xa00 <kprobe_unwind_v8+0xa00>
    149c:      	str	xzr, [sp, #0x40]
    14a0:      	mov	w8, wzr
    14a4:      	ldrh	w9, [x23, #0xa]
    14a8:      	cmp	w9, w8, uxth
    14ac:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    14b0:      	lsr	x25, x22, #32
    14b4:      	cbz	x25, 0x1744 <kprobe_unwind_v8+0x1744>
    14b8:      	tbnz	w22, #0x0, 0x1744 <kprobe_unwind_v8+0x1744>
    14bc:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    14c0:      	ldr	x8, [x8]
    14c4:      	ldr	w8, [x8]
    14c8:      	cbnz	w8, 0x2188 <kprobe_unwind_v8+0x2188>
    14cc:      	ldr	x8, [sp, #0x40]
    14d0:      	orr	x22, x8, #0x1
    14d4:      	b	0x1e2c <kprobe_unwind_v8+0x1e2c>
    14d8:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    14dc:      	add	x8, x8, #0x0
    14e0:      	add	x0, sp, #0x70
    14e4:      	ldp	x9, x10, [x8]
    14e8:      	mov	w1, #0x1e               // =30
    14ec:      	mov	x2, x24
    14f0:      	stp	x9, x10, [sp, #0x70]
    14f4:      	ldr	x9, [x8, #0x10]
    14f8:      	ldur	x8, [x8, #0x16]
    14fc:      	add	x10, sp, #0x70
    1500:      	str	x9, [sp, #0x80]
    1504:      	stur	x8, [sp, #0x86]
    1508:      	mov	w8, #0x1e               // =30
    150c:      	mov	w9, #0x6                // =6
    1510:      	blr	x9
    1514:      	b	0xf14 <kprobe_unwind_v8+0xf14>
    1518:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    151c:      	add	x8, x8, #0x0
    1520:      	add	x0, sp, #0x70
    1524:      	ldp	x9, x10, [x8, #0x10]
    1528:      	mov	w1, #0x2e               // =46
    152c:      	mov	x3, x25
    1530:      	stp	x9, x10, [sp, #0x80]
    1534:      	ldr	x9, [x8, #0x20]
    1538:      	add	x10, sp, #0x70
    153c:      	str	x9, [sp, #0x90]
    1540:      	ldur	x9, [x8, #0x26]
    1544:      	stur	x9, [sp, #0x96]
    1548:      	ldp	x9, x8, [x8]
    154c:      	stp	x9, x8, [sp, #0x70]
    1550:      	mov	w8, #0x2e               // =46
    1554:      	mov	w9, #0x6                // =6
    1558:      	ldr	x2, [sp, #0x40]
    155c:      	blr	x9
    1560:      	b	0xa30 <kprobe_unwind_v8+0xa30>
    1564:      	mov	w8, #0xa                // =10
    1568:      	add	x0, sp, #0x70
    156c:      	mov	w1, #0x32               // =50
    1570:      	strh	w8, [sp, #0xa0]
    1574:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1578:      	add	x8, x8, #0x0
    157c:      	mov	x2, x24
    1580:      	ldp	x9, x10, [x8, #0x10]
    1584:      	mov	w4, w29
    1588:      	stp	x9, x10, [sp, #0x80]
    158c:      	ldp	x9, x10, [x8, #0x20]
    1590:      	stp	x9, x10, [sp, #0x90]
    1594:      	ldp	x9, x8, [x8]
    1598:      	add	x10, sp, #0x70
    159c:      	stp	x9, x8, [sp, #0x70]
    15a0:      	mov	w8, #0x32               // =50
    15a4:      	mov	w9, #0x6                // =6
    15a8:      	ldr	x3, [x21, #0xf00]
    15ac:      	blr	x9
    15b0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    15b4:      	ldr	x8, [x8]
    15b8:      	ldr	w8, [x8]
    15bc:      	cbz	w8, 0xf94 <kprobe_unwind_v8+0xf94>
    15c0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    15c4:      	add	x8, x8, #0x0
    15c8:      	add	x0, sp, #0x70
    15cc:      	ldp	x9, x10, [x8, #0x10]
    15d0:      	mov	w1, #0x2f               // =47
    15d4:      	stp	x9, x10, [sp, #0x80]
    15d8:      	ldr	x9, [x8, #0x20]
    15dc:      	add	x10, sp, #0x70
    15e0:      	str	x9, [sp, #0x90]
    15e4:      	ldur	x9, [x8, #0x27]
    15e8:      	stur	x9, [sp, #0x97]
    15ec:      	ldp	x9, x8, [x8]
    15f0:      	stp	x9, x8, [sp, #0x70]
    15f4:      	mov	w8, #0x2f               // =47
    15f8:      	mov	w9, #0x6                // =6
    15fc:      	ldr	x2, [x21, #0xf10]
    1600:      	ldr	x3, [x21, #0xf08]
    1604:      	blr	x9
    1608:      	b	0xf94 <kprobe_unwind_v8+0xf94>
    160c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1610:      	ldr	x8, [x8]
    1614:      	ldr	w8, [x8]
    1618:      	cbnz	w8, 0x2140 <kprobe_unwind_v8+0x2140>
    161c:      	ldr	x24, [x21, #0xed0]
    1620:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    1624:      	cbnz	w8, 0x20f0 <kprobe_unwind_v8+0x20f0>
    1628:      	lsr	x8, x24, #56
    162c:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    1630:      	cmp	x24, #0x1, lsl #12      // =0x1000
    1634:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    1638:      	ldr	w8, [x21]
    163c:      	mov	w9, #0x60               // =96
    1640:      	adrp	x0, 0x1000 <kprobe_unwind_v8+0x1000>
    1644:      	add	x1, sp, #0x58
    1648:      	rev	w8, w8
    164c:      	stp	w9, w8, [sp, #0x58]
    1650:      	rev	x8, x24
    1654:      	add	x9, sp, #0x58
    1658:      	str	x8, [sp, #0x60]
    165c:      	mov	w8, #0x1                // =1
    1660:      	ldr	x0, [x0]
    1664:      	blr	x8
    1668:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    166c:      	ldr	x8, [x0, #0x8]
    1670:      	and	x9, x8, #0xffffffffffffff
    1674:      	lsr	x29, x8, #56
    1678:      	str	x9, [x21, #0xf10]
    167c:      	ldr	x8, [x0]
    1680:      	str	x8, [x21, #0xf00]
    1684:      	sub	x8, x24, x9
    1688:      	str	x8, [x21, #0xf08]
    168c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1690:      	ldr	x8, [x8]
    1694:      	ldr	w8, [x8]
    1698:      	cbnz	w8, 0x2218 <kprobe_unwind_v8+0x2218>
    169c:      	cmp	w29, #0x1
    16a0:      	b.ne	0x2434 <kprobe_unwind_v8+0x2434>
    16a4:      	ldr	x8, [x21, #0xf00]
    16a8:      	adrp	x0, 0x1000 <kprobe_unwind_v8+0x1000>
    16ac:      	ldr	x25, [x21, #0xf08]
    16b0:      	mov	w9, #0x1                // =1
    16b4:      	add	x1, sp, #0x58
    16b8:      	mov	w29, #0x1               // =1
    16bc:      	str	x8, [sp, #0x58]
    16c0:      	add	x8, sp, #0x58
    16c4:      	ldr	x0, [x0]
    16c8:      	blr	x9
    16cc:      	cbz	x0, 0x1e98 <kprobe_unwind_v8+0x1e98>
    16d0:      	ldr	x8, [x0]
    16d4:      	mov	x24, x0
    16d8:      	cmp	x8, x25
    16dc:      	b.hi	0x16ec <kprobe_unwind_v8+0x16ec>
    16e0:      	ldr	x8, [x24, #0x8]
    16e4:      	cmp	x8, x25
    16e8:      	b.hs	0x1704 <kprobe_unwind_v8+0x1704>
    16ec:      	ldr	x8, [x24, #0x10]
    16f0:      	cmp	x8, x25
    16f4:      	b.hi	0x1734 <kprobe_unwind_v8+0x1734>
    16f8:      	ldr	x8, [x24, #0x18]
    16fc:      	cmp	x8, x25
    1700:      	b.lo	0x1734 <kprobe_unwind_v8+0x1734>
    1704:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1708:      	ldr	x8, [x8]
    170c:      	ldr	w8, [x8]
    1710:      	cbnz	w8, 0x23a4 <kprobe_unwind_v8+0x23a4>
    1714:      	ldrh	w8, [x24, #0x20]
    1718:      	ldr	w9, [x21, #0x1370]
    171c:      	lsr	w8, w9, w8
    1720:      	tbz	w8, #0x0, 0x23f0 <kprobe_unwind_v8+0x23f0>
    1724:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1728:      	ldr	x8, [x8]
    172c:      	ldr	w8, [x8]
    1730:      	cbnz	w8, 0x2ab0 <kprobe_unwind_v8+0x2ab0>
    1734:      	mov	w29, #0x1               // =1
    1738:      	cmp	w29, #0x7
    173c:      	b.eq	0x243c <kprobe_unwind_v8+0x243c>
    1740:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    1744:      	ldr	x8, [sp, #0x40]
    1748:      	mov	w9, #0x70               // =112
    174c:      	add	x10, sp, #0x70
    1750:      	add	x0, sp, #0x70
    1754:      	mov	w1, #0x8                // =8
    1758:      	orr	x22, x8, #0x2
    175c:      	ldrb	w8, [x23, #0xe]
    1760:      	add	x2, x29, x8
    1764:      	mov	w8, #0x8                // =8
    1768:      	blr	x9
    176c:      	cbnz	x0, 0x1810 <kprobe_unwind_v8+0x1810>
    1770:      	ldr	x8, [sp, #0x70]
    1774:      	and	x9, x8, #0x3
    1778:      	cmp	x9, #0x1
    177c:      	b.ne	0x1810 <kprobe_unwind_v8+0x1810>
    1780:      	and	x8, x8, #0xfffffffffffffffc
    1784:      	mov	x25, x8
    1788:      	cbz	x8, 0x1818 <kprobe_unwind_v8+0x1818>
    178c:      	ldrb	w8, [x23, #0xc]
    1790:      	mov	w9, #0x70               // =112
    1794:      	add	x10, sp, #0x70
    1798:      	add	x0, sp, #0x70
    179c:      	mov	w1, #0x8                // =8
    17a0:      	add	x2, x25, x8
    17a4:      	mov	w8, #0x8                // =8
    17a8:      	blr	x9
    17ac:      	cbnz	x0, 0x1dbc <kprobe_unwind_v8+0x1dbc>
    17b0:      	ldr	x8, [sp, #0x70]
    17b4:      	and	x9, x8, #0x3
    17b8:      	cmp	x9, #0x1
    17bc:      	b.ne	0x1dbc <kprobe_unwind_v8+0x1dbc>
    17c0:      	and	x8, x8, #0xfffffffffffffffc
    17c4:      	cbz	x8, 0x1818 <kprobe_unwind_v8+0x1818>
    17c8:      	ldrb	w9, [x23, #0xd]
    17cc:      	mov	w10, #0x2               // =2
    17d0:      	mov	w11, #0x70              // =112
    17d4:      	add	x12, sp, #0x70
    17d8:      	add	x0, sp, #0x70
    17dc:      	mov	w1, #0x2                // =2
    17e0:      	add	x9, x8, x9
    17e4:      	ldrb	w9, [x23, #0xd]
    17e8:      	add	x2, x8, x9
    17ec:      	blr	x11
    17f0:      	ldrh	w8, [sp, #0x70]
    17f4:      	cmp	x0, #0x0
    17f8:      	csel	w8, w8, wzr, eq
    17fc:      	and	w4, w8, #0xffff
    1800:      	ldrh	w8, [x23, #0x8]
    1804:      	cmp	w4, w8
    1808:      	b.eq	0x1828 <kprobe_unwind_v8+0x1828>
    180c:      	b	0x1dd0 <kprobe_unwind_v8+0x1dd0>
    1810:      	mov	x25, xzr
    1814:      	mov	w8, wzr
    1818:      	and	w4, w8, #0xffff
    181c:      	ldrh	w8, [x23, #0x8]
    1820:      	cmp	w4, w8
    1824:      	b.ne	0x1dd0 <kprobe_unwind_v8+0x1dd0>
    1828:      	ldr	x0, [sp, #0x48]
    182c:      	mov	w8, #0x60               // =96
    1830:      	mov	w9, #0x70               // =112
    1834:      	mov	x2, x25
    1838:      	mov	w1, #0x60               // =96
    183c:      	blr	x9
    1840:      	cbz	x0, 0x1cb4 <kprobe_unwind_v8+0x1cb4>
    1844:      	mov	w8, #0x3b               // =59
    1848:      	adrp	x0, 0x1000 <kprobe_unwind_v8+0x1000>
    184c:      	add	x9, sp, #0x58
    1850:      	str	w8, [sp, #0x58]
    1854:      	mov	w8, #0x1                // =1
    1858:      	add	x1, sp, #0x58
    185c:      	ldr	x0, [x0]
    1860:      	blr	x8
    1864:      	cbnz	x0, 0x1e04 <kprobe_unwind_v8+0x1e04>
    1868:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    186c:      	ldr	x8, [x8]
    1870:      	ldr	w8, [x8]
    1874:      	cbz	w8, 0x1e28 <kprobe_unwind_v8+0x1e28>
    1878:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    187c:      	add	x8, x8, #0x0
    1880:      	add	x0, sp, #0x70
    1884:      	ldp	x9, x10, [x8, #0x10]
    1888:      	mov	w1, #0x2e               // =46
    188c:      	stp	x9, x10, [sp, #0x80]
    1890:      	ldr	x9, [x8, #0x20]
    1894:      	add	x10, sp, #0x70
    1898:      	str	x9, [sp, #0x90]
    189c:      	ldur	x9, [x8, #0x26]
    18a0:      	stur	x9, [sp, #0x96]
    18a4:      	ldp	x9, x8, [x8]
    18a8:      	stp	x9, x8, [sp, #0x70]
    18ac:      	mov	w8, #0x2e               // =46
    18b0:      	mov	w9, #0x6                // =6
    18b4:      	ldr	w2, [sp, #0x58]
    18b8:      	blr	x9
    18bc:      	b	0x1e28 <kprobe_unwind_v8+0x1e28>
    18c0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    18c4:      	add	x8, x8, #0x0
    18c8:      	add	x0, sp, #0x70
    18cc:      	ldp	x9, x10, [x8, #0x10]
    18d0:      	mov	w1, #0x2e               // =46
    18d4:      	stp	x9, x10, [sp, #0x80]
    18d8:      	ldr	x9, [x8, #0x20]
    18dc:      	add	x10, sp, #0x70
    18e0:      	str	x9, [sp, #0x90]
    18e4:      	ldur	x9, [x8, #0x26]
    18e8:      	stur	x9, [sp, #0x96]
    18ec:      	ldp	x9, x8, [x8]
    18f0:      	stp	x9, x8, [sp, #0x70]
    18f4:      	mov	w8, #0x2e               // =46
    18f8:      	mov	w9, #0x6                // =6
    18fc:      	ldr	w2, [sp, #0x58]
    1900:      	blr	x9
    1904:      	b	0xa7c <kprobe_unwind_v8+0xa7c>
    1908:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    190c:      	add	x8, x8, #0x0
    1910:      	add	x0, sp, #0x70
    1914:      	ldp	x9, x10, [x8]
    1918:      	mov	w1, #0x1f               // =31
    191c:      	mov	x2, x24
    1920:      	mov	x3, x29
    1924:      	stp	x9, x10, [sp, #0x70]
    1928:      	ldr	x9, [x8, #0x10]
    192c:      	ldur	x8, [x8, #0x17]
    1930:      	add	x10, sp, #0x70
    1934:      	mov	x4, x25
    1938:      	str	x9, [sp, #0x80]
    193c:      	stur	x8, [sp, #0x87]
    1940:      	mov	w8, #0x1f               // =31
    1944:      	mov	w9, #0x6                // =6
    1948:      	blr	x9
    194c:      	cmp	x25, x29
    1950:      	b.hs	0x1060 <kprobe_unwind_v8+0x1060>
    1954:      	adrp	x22, 0x1000 <kprobe_unwind_v8+0x1000>
    1958:      	ldr	x22, [x22]
    195c:      	ldr	w8, [x22]
    1960:      	cbnz	w8, 0x1ae4 <kprobe_unwind_v8+0x1ae4>
    1964:      	mov	w8, #0x39               // =57
    1968:      	adrp	x24, 0x1000 <kprobe_unwind_v8+0x1000>
    196c:      	add	x9, sp, #0x58
    1970:      	str	w8, [sp, #0x58]
    1974:      	mov	w8, #0x1                // =1
    1978:      	add	x1, sp, #0x58
    197c:      	ldr	x24, [x24]
    1980:      	mov	x0, x24
    1984:      	blr	x8
    1988:      	cbz	x0, 0x199c <kprobe_unwind_v8+0x199c>
    198c:      	ldr	x8, [x0]
    1990:      	add	x8, x8, #0x1
    1994:      	str	x8, [x0]
    1998:      	b	0x19a4 <kprobe_unwind_v8+0x19a4>
    199c:      	ldr	w8, [x22]
    19a0:      	cbnz	w8, 0x1b2c <kprobe_unwind_v8+0x1b2c>
    19a4:      	mov	w29, wzr
    19a8:      	mov	w8, #0x1388             // =5000
    19ac:      	str	w8, [x21, #0xf1c]
    19b0:      	str	wzr, [sp, #0x70]
    19b4:      	mov	w8, #0x1                // =1
    19b8:      	add	x9, sp, #0x70
    19bc:      	add	x1, sp, #0x70
    19c0:      	mov	x0, x20
    19c4:      	blr	x8
    19c8:      	cbz	x0, 0x1a1c <kprobe_unwind_v8+0x1a1c>
    19cc:      	mov	w20, #0x1374            // =4980
    19d0:      	mov	w2, w29
    19d4:      	ldrb	w8, [x0, x20]
    19d8:      	cmp	w8, #0x1d
    19dc:      	b.lo	0x1a48 <kprobe_unwind_v8+0x1a48>
    19e0:      	mov	w8, #0x5                // =5
    19e4:      	add	x9, sp, #0x58
    19e8:      	mov	x21, x0
    19ec:      	str	w8, [x0, #0xf1c]
    19f0:      	mov	w8, #0x44               // =68
    19f4:      	add	x1, sp, #0x58
    19f8:      	mov	x0, x24
    19fc:      	str	w8, [sp, #0x58]
    1a00:      	mov	w8, #0x1                // =1
    1a04:      	blr	x8
    1a08:      	cbz	x0, 0x1a34 <kprobe_unwind_v8+0x1a34>
    1a0c:      	ldr	x8, [x0]
    1a10:      	add	x8, x8, #0x1
    1a14:      	str	x8, [x0]
    1a18:      	b	0x1a3c <kprobe_unwind_v8+0x1a3c>
    1a1c:      	adrp	x10, 0x1000 <kprobe_unwind_v8+0x1000>
    1a20:      	mov	x9, xzr
    1a24:      	mov	w8, #0xc                // =12
    1a28:      	ldr	x10, [x10]
    1a2c:      	mov	w2, wzr
    1a30:      	b	0x1a60 <kprobe_unwind_v8+0x1a60>
    1a34:      	ldr	w8, [x22]
    1a38:      	cbnz	w8, 0x1b74 <kprobe_unwind_v8+0x1b74>
    1a3c:      	ldrb	w8, [x21, x20]
    1a40:      	mov	w2, wzr
    1a44:      	mov	x0, x21
    1a48:      	add	w8, w8, #0x1
    1a4c:      	adrp	x10, 0x1000 <kprobe_unwind_v8+0x1000>
    1a50:      	mov	w9, w2
    1a54:      	strb	w8, [x0, x20]
    1a58:      	mov	w8, #0xc                // =12
    1a5c:      	ldr	x10, [x10]
    1a60:      	adrp	x1, 0x1000 <kprobe_unwind_v8+0x1000>
    1a64:      	mov	x0, x19
    1a68:      	ldr	x1, [x1]
    1a6c:      	blr	x8
    1a70:      	ldr	w8, [x22]
    1a74:      	cbnz	w8, 0x1a98 <kprobe_unwind_v8+0x1a98>
    1a78:      	ldp	x20, x19, [sp, #0xf0]
    1a7c:      	mov	w0, #-0x1               // =-1
    1a80:      	ldr	x29, [sp, #0xb0]
    1a84:      	ldp	x22, x21, [sp, #0xe0]
    1a88:      	ldp	x24, x23, [sp, #0xd0]
    1a8c:      	ldp	x30, x25, [sp, #0xc0]
    1a90:      	add	sp, sp, #0x100
    1a94:      	ret
    1a98:      	mov	w8, #0x6465             // =25701
    1a9c:      	add	x0, sp, #0x70
    1aa0:      	mov	w1, #0x33               // =51
    1aa4:      	mov	w2, w29
    1aa8:      	movk	w8, #0xa, lsl #16
    1aac:      	stur	w8, [sp, #0x9f]
    1ab0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1ab4:      	add	x8, x8, #0x0
    1ab8:      	ldp	x9, x10, [x8, #0x10]
    1abc:      	stp	x9, x10, [sp, #0x80]
    1ac0:      	ldp	x9, x10, [x8, #0x20]
    1ac4:      	stp	x9, x10, [sp, #0x90]
    1ac8:      	ldp	x9, x8, [x8]
    1acc:      	add	x10, sp, #0x70
    1ad0:      	stp	x9, x8, [sp, #0x70]
    1ad4:      	mov	w8, #0x33               // =51
    1ad8:      	mov	w9, #0x6                // =6
    1adc:      	blr	x9
    1ae0:      	b	0x1a78 <kprobe_unwind_v8+0x1a78>
    1ae4:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1ae8:      	add	x8, x8, #0x0
    1aec:      	strb	wzr, [sp, #0x98]
    1af0:      	add	x0, sp, #0x70
    1af4:      	ldp	x9, x10, [x8, #0x10]
    1af8:      	mov	w1, #0x29               // =41
    1afc:      	mov	x2, x25
    1b00:      	mov	x3, x29
    1b04:      	stp	x9, x10, [sp, #0x80]
    1b08:      	ldr	x9, [x8, #0x20]
    1b0c:      	add	x10, sp, #0x70
    1b10:      	str	x9, [sp, #0x90]
    1b14:      	ldp	x8, x9, [x8]
    1b18:      	stp	x8, x9, [sp, #0x70]
    1b1c:      	mov	w8, #0x29               // =41
    1b20:      	mov	w9, #0x6                // =6
    1b24:      	blr	x9
    1b28:      	b	0x1964 <kprobe_unwind_v8+0x1964>
    1b2c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1b30:      	add	x8, x8, #0x0
    1b34:      	ldp	x9, x10, [x8, #0x10]
    1b38:      	stp	x9, x10, [sp, #0x80]
    1b3c:      	ldr	x9, [x8, #0x20]
    1b40:      	add	x10, sp, #0x70
    1b44:      	str	x9, [sp, #0x90]
    1b48:      	ldur	x9, [x8, #0x26]
    1b4c:      	stur	x9, [sp, #0x96]
    1b50:      	ldp	x9, x8, [x8]
    1b54:      	stp	x9, x8, [sp, #0x70]
    1b58:      	mov	w8, #0x2e               // =46
    1b5c:      	mov	w9, #0x6                // =6
    1b60:      	ldr	w2, [sp, #0x58]
    1b64:      	add	x0, sp, #0x70
    1b68:      	mov	w1, #0x2e               // =46
    1b6c:      	blr	x9
    1b70:      	b	0x19a4 <kprobe_unwind_v8+0x19a4>
    1b74:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1b78:      	add	x8, x8, #0x0
    1b7c:      	add	x0, sp, #0x70
    1b80:      	ldp	x9, x10, [x8, #0x10]
    1b84:      	mov	w1, #0x2e               // =46
    1b88:      	stp	x9, x10, [sp, #0x80]
    1b8c:      	ldr	x9, [x8, #0x20]
    1b90:      	add	x10, sp, #0x70
    1b94:      	str	x9, [sp, #0x90]
    1b98:      	ldur	x9, [x8, #0x26]
    1b9c:      	stur	x9, [sp, #0x96]
    1ba0:      	ldp	x9, x8, [x8]
    1ba4:      	stp	x9, x8, [sp, #0x70]
    1ba8:      	mov	w8, #0x2e               // =46
    1bac:      	mov	w9, #0x6                // =6
    1bb0:      	ldr	w2, [sp, #0x58]
    1bb4:      	blr	x9
    1bb8:      	b	0x1a3c <kprobe_unwind_v8+0x1a3c>
    1bbc:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1bc0:      	add	x8, x8, #0x0
    1bc4:      	add	x0, sp, #0x70
    1bc8:      	ldp	x9, x10, [x8, #0x10]
    1bcc:      	mov	w1, #0x2e               // =46
    1bd0:      	stp	x9, x10, [sp, #0x80]
    1bd4:      	ldr	x9, [x8, #0x20]
    1bd8:      	add	x10, sp, #0x70
    1bdc:      	str	x9, [sp, #0x90]
    1be0:      	ldur	x9, [x8, #0x26]
    1be4:      	stur	x9, [sp, #0x96]
    1be8:      	ldp	x9, x8, [x8]
    1bec:      	stp	x9, x8, [sp, #0x70]
    1bf0:      	mov	w8, #0x2e               // =46
    1bf4:      	mov	w9, #0x6                // =6
    1bf8:      	ldr	w2, [sp, #0x58]
    1bfc:      	blr	x9
    1c00:      	b	0xa00 <kprobe_unwind_v8+0xa00>
    1c04:      	str	xzr, [sp, #0x40]
    1c08:      	ldrh	w9, [x23, #0xa]
    1c0c:      	cmp	w9, w8, uxth
    1c10:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    1c14:      	b	0x14b0 <kprobe_unwind_v8+0x14b0>
    1c18:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1c1c:      	add	x8, x8, #0x0
    1c20:      	strb	wzr, [sp, #0x98]
    1c24:      	add	x0, sp, #0x70
    1c28:      	ldp	x9, x10, [x8, #0x10]
    1c2c:      	mov	w1, #0x29               // =41
    1c30:      	mov	x4, x25
    1c34:      	stp	x9, x10, [sp, #0x80]
    1c38:      	ldr	x9, [x8, #0x20]
    1c3c:      	add	x10, sp, #0x70
    1c40:      	str	x9, [sp, #0x90]
    1c44:      	ldp	x8, x9, [x8]
    1c48:      	stp	x8, x9, [sp, #0x70]
    1c4c:      	mov	w8, #0x29               // =41
    1c50:      	mov	w9, #0x6                // =6
    1c54:      	ldr	x2, [sp, #0x40]
    1c58:      	ldr	x3, [sp, #0x30]
    1c5c:      	blr	x9
    1c60:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1c64:      	ldr	x8, [x8]
    1c68:      	ldr	w8, [x8]
    1c6c:      	cbz	w8, 0xb2c <kprobe_unwind_v8+0xb2c>
    1c70:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1c74:      	add	x8, x8, #0x0
    1c78:      	add	x0, sp, #0x70
    1c7c:      	ldp	x9, x10, [x8, #0x10]
    1c80:      	mov	w1, #0x25               // =37
    1c84:      	mov	x2, x22
    1c88:      	stp	x9, x10, [sp, #0x80]
    1c8c:      	ldur	x9, [x8, #0x1d]
    1c90:      	add	x10, sp, #0x70
    1c94:      	stur	x9, [sp, #0x8d]
    1c98:      	ldp	x8, x9, [x8]
    1c9c:      	stp	x8, x9, [sp, #0x70]
    1ca0:      	mov	w8, #0x25               // =37
    1ca4:      	mov	w9, #0x6                // =6
    1ca8:      	ldp	x4, x3, [sp, #0x20]
    1cac:      	blr	x9
    1cb0:      	b	0xb2c <kprobe_unwind_v8+0xb2c>
    1cb4:      	ldrb	w8, [x23, #0x12]
    1cb8:      	cmp	x8, #0x5c
    1cbc:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    1cc0:      	ldrb	w9, [x23, #0x13]
    1cc4:      	cmp	x9, #0x5c
    1cc8:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    1ccc:      	ldrb	w11, [x23, #0x10]
    1cd0:      	ldrb	w10, [x23, #0x11]
    1cd4:      	cbz	w11, 0x1f68 <kprobe_unwind_v8+0x1f68>
    1cd8:      	ldr	x11, [sp, #0x48]
    1cdc:      	ldr	x10, [x11, x10]
    1ce0:      	b	0x1f6c <kprobe_unwind_v8+0x1f6c>
    1ce4:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1ce8:      	add	x8, x8, #0x0
    1cec:      	add	x0, sp, #0x70
    1cf0:      	ldp	x9, x10, [x8]
    1cf4:      	mov	w1, #0x1e               // =30
    1cf8:      	stp	x9, x10, [sp, #0x70]
    1cfc:      	ldr	x9, [x8, #0x10]
    1d00:      	ldur	x8, [x8, #0x16]
    1d04:      	add	x10, sp, #0x70
    1d08:      	str	x9, [sp, #0x80]
    1d0c:      	stur	x8, [sp, #0x86]
    1d10:      	mov	w8, #0x1e               // =30
    1d14:      	mov	w9, #0x6                // =6
    1d18:      	ldrh	w2, [x24, #0x20]
    1d1c:      	blr	x9
    1d20:      	ldrh	w8, [x24, #0x20]
    1d24:      	ldr	w9, [x21, #0x1370]
    1d28:      	lsr	w8, w9, w8
    1d2c:      	tbnz	w8, #0x0, 0x101c <kprobe_unwind_v8+0x101c>
    1d30:      	str	wzr, [sp, #0xbc]
    1d34:      	adrp	x0, 0x1000 <kprobe_unwind_v8+0x1000>
    1d38:      	mov	w8, #0x1                // =1
    1d3c:      	add	x9, sp, #0xbc
    1d40:      	ldr	x0, [x0]
    1d44:      	add	x1, sp, #0xbc
    1d48:      	blr	x8
    1d4c:      	cbz	x0, 0x1d64 <kprobe_unwind_v8+0x1d64>
    1d50:      	ldr	x8, [x0]
    1d54:      	add	x8, x8, #0x1
    1d58:      	str	x8, [x0]
    1d5c:      	ldrh	w29, [x24, #0x20]
    1d60:      	b	0x1034 <kprobe_unwind_v8+0x1034>
    1d64:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1d68:      	ldr	x8, [x8]
    1d6c:      	ldr	w8, [x8]
    1d70:      	cbnz	w8, 0x1ee0 <kprobe_unwind_v8+0x1ee0>
    1d74:      	ldrh	w29, [x24, #0x20]
    1d78:      	b	0x1034 <kprobe_unwind_v8+0x1034>
    1d7c:      	mov	w8, #0x656e             // =25966
    1d80:      	add	x0, sp, #0x70
    1d84:      	mov	w1, #0x1b               // =27
    1d88:      	movk	w8, #0xa, lsl #16
    1d8c:      	stur	w8, [sp, #0x87]
    1d90:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1d94:      	add	x8, x8, #0x0
    1d98:      	ldp	x9, x10, [x8]
    1d9c:      	ldr	x8, [x8, #0x10]
    1da0:      	stp	x9, x10, [sp, #0x70]
    1da4:      	str	x8, [sp, #0x80]
    1da8:      	mov	w8, #0x1b               // =27
    1dac:      	mov	w9, #0x6                // =6
    1db0:      	add	x10, sp, #0x70
    1db4:      	blr	x9
    1db8:      	b	0x102c <kprobe_unwind_v8+0x102c>
    1dbc:      	mov	w8, wzr
    1dc0:      	and	w4, wzr, #0xffff
    1dc4:      	ldrh	w8, [x23, #0x8]
    1dc8:      	cmp	w4, w8
    1dcc:      	b.eq	0x1828 <kprobe_unwind_v8+0x1828>
    1dd0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1dd4:      	ldr	x8, [x8]
    1dd8:      	ldr	w8, [x8]
    1ddc:      	cbnz	w8, 0x21cc <kprobe_unwind_v8+0x21cc>
    1de0:      	mov	w8, #0x3b               // =59
    1de4:      	adrp	x0, 0x1000 <kprobe_unwind_v8+0x1000>
    1de8:      	add	x9, sp, #0x58
    1dec:      	str	w8, [sp, #0x58]
    1df0:      	mov	w8, #0x1                // =1
    1df4:      	add	x1, sp, #0x58
    1df8:      	ldr	x0, [x0]
    1dfc:      	blr	x8
    1e00:      	cbz	x0, 0x1e18 <kprobe_unwind_v8+0x1e18>
    1e04:      	ldr	x8, [x0]
    1e08:      	mov	x25, xzr
    1e0c:      	add	x8, x8, #0x1
    1e10:      	str	x8, [x0]
    1e14:      	b	0x1e2c <kprobe_unwind_v8+0x1e2c>
    1e18:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1e1c:      	ldr	x8, [x8]
    1e20:      	ldr	w8, [x8]
    1e24:      	cbnz	w8, 0x22c0 <kprobe_unwind_v8+0x22c0>
    1e28:      	mov	x25, xzr
    1e2c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1e30:      	ldr	x8, [x8]
    1e34:      	ldrb	w24, [x21, #0xf20]
    1e38:      	ldr	w8, [x8]
    1e3c:      	cbz	w8, 0x10d4 <kprobe_unwind_v8+0x10d4>
    1e40:      	mov	w8, #0x786c             // =30828
    1e44:      	add	x0, sp, #0x70
    1e48:      	mov	w1, #0x3c               // =60
    1e4c:      	mov	x2, x25
    1e50:      	mov	x3, x22
    1e54:      	movk	w8, #0xa, lsl #16
    1e58:      	str	w8, [sp, #0xa8]
    1e5c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1e60:      	add	x8, x8, #0x0
    1e64:      	ldp	x9, x10, [x8, #0x20]
    1e68:      	stp	x9, x10, [sp, #0x90]
    1e6c:      	ldr	x9, [x8, #0x30]
    1e70:      	str	x9, [sp, #0xa0]
    1e74:      	ldp	x9, x10, [x8]
    1e78:      	stp	x9, x10, [sp, #0x70]
    1e7c:      	add	x10, sp, #0x70
    1e80:      	ldp	x8, x9, [x8, #0x10]
    1e84:      	stp	x8, x9, [sp, #0x80]
    1e88:      	mov	w8, #0x3c               // =60
    1e8c:      	mov	w9, #0x6                // =6
    1e90:      	blr	x9
    1e94:      	b	0x10d4 <kprobe_unwind_v8+0x10d4>
    1e98:      	cmp	w29, #0x7
    1e9c:      	b.eq	0x243c <kprobe_unwind_v8+0x243c>
    1ea0:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    1ea4:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1ea8:      	add	x8, x8, #0x0
    1eac:      	add	x0, sp, #0x70
    1eb0:      	ldp	x9, x10, [x8, #0x10]
    1eb4:      	mov	w1, #0x30               // =48
    1eb8:      	stp	x9, x10, [sp, #0x80]
    1ebc:      	ldp	x9, x10, [x8, #0x20]
    1ec0:      	stp	x9, x10, [sp, #0x90]
    1ec4:      	ldp	x9, x8, [x8]
    1ec8:      	add	x10, sp, #0x70
    1ecc:      	stp	x9, x8, [sp, #0x70]
    1ed0:      	mov	w8, #0x30               // =48
    1ed4:      	mov	w9, #0x6                // =6
    1ed8:      	blr	x9
    1edc:      	b	0xa00 <kprobe_unwind_v8+0xa00>
    1ee0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1ee4:      	add	x8, x8, #0x0
    1ee8:      	add	x0, sp, #0x70
    1eec:      	ldp	x9, x10, [x8, #0x10]
    1ef0:      	mov	w1, #0x2e               // =46
    1ef4:      	stp	x9, x10, [sp, #0x80]
    1ef8:      	ldr	x9, [x8, #0x20]
    1efc:      	add	x10, sp, #0x70
    1f00:      	str	x9, [sp, #0x90]
    1f04:      	ldur	x9, [x8, #0x26]
    1f08:      	stur	x9, [sp, #0x96]
    1f0c:      	ldp	x9, x8, [x8]
    1f10:      	stp	x9, x8, [sp, #0x70]
    1f14:      	mov	w8, #0x2e               // =46
    1f18:      	mov	w9, #0x6                // =6
    1f1c:      	ldr	w2, [sp, #0xbc]
    1f20:      	blr	x9
    1f24:      	b	0x1d74 <kprobe_unwind_v8+0x1d74>
    1f28:      	mov	w8, #0x7265             // =29285
    1f2c:      	add	x0, sp, #0x70
    1f30:      	mov	w1, #0x1c               // =28
    1f34:      	movk	w8, #0xa, lsl #16
    1f38:      	str	w8, [sp, #0x88]
    1f3c:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1f40:      	add	x8, x8, #0x0
    1f44:      	ldp	x9, x10, [x8]
    1f48:      	ldr	x8, [x8, #0x10]
    1f4c:      	stp	x9, x10, [sp, #0x70]
    1f50:      	str	x8, [sp, #0x80]
    1f54:      	mov	w8, #0x1c               // =28
    1f58:      	mov	w9, #0x6                // =6
    1f5c:      	add	x10, sp, #0x70
    1f60:      	blr	x9
    1f64:      	b	0xbd8 <kprobe_unwind_v8+0xbd8>
    1f68:      	add	x10, x25, x10
    1f6c:      	str	x10, [sp, #0x38]
    1f70:      	ldr	x10, [sp, #0x48]
    1f74:      	ldr	w9, [x10, x9]
    1f78:      	ldr	w8, [x10, x8]
    1f7c:      	str	w9, [sp, #0x20]
    1f80:      	ldrb	w9, [x23, #0x18]
    1f84:      	str	x8, [sp, #0x28]
    1f88:      	str	w9, [sp, #0x10]
    1f8c:      	ldrb	w9, [x23, #0x17]
    1f90:      	str	x9, [sp, #0x18]
    1f94:      	ldr	x9, [sp, #0x38]
    1f98:      	add	x8, x9, x8
    1f9c:      	str	x8, [sp, #0x30]
    1fa0:      	adrp	x8, 0x1000 <kprobe_unwind_v8+0x1000>
    1fa4:      	ldr	x8, [x8]
    1fa8:      	ldr	w8, [x8]
    1fac:      	cbnz	w8, 0x2308 <kprobe_unwind_v8+0x2308>
    1fb0:      	ldr	x8, [sp, #0x38]
    1fb4:      	subs	x8, x24, x8
    1fb8:      	b.lo	0x2000 <kprobe_unwind_v8+0x2000>
    1fbc:      	ldr	x9, [sp, #0x30]
    1fc0:      	cmp	x24, x9
    1fc4:      	b.hs	0x2000 <kprobe_unwind_v8+0x2000>
    1fc8:      	ldr	w9, [sp, #0x20]
    1fcc:      	ldr	w10, [sp, #0x10]
    1fd0:      	orr	x11, x29, #0x4
    1fd4:      	orr	x12, x25, #0x3
    1fd8:      	and	w9, w9, w10
    1fdc:      	ldr	x10, [sp, #0x18]
    1fe0:      	lsr	w9, w9, w10
    1fe4:      	ldrb	w10, [x23, #0x19]
    1fe8:      	cmp	w9, w10
    1fec:      	ldr	x10, [sp, #0x28]
    1ff0:      	csel	x22, x11, x12, eq
    1ff4:      	orr	w9, w9, w10, lsl #4
    1ff8:      	orr	x25, x8, x9, lsl #32
    1ffc:      	b	0x1e2c <kprobe_unwind_v8+0x1e2c>
    2000:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2004:      	ldr	x8, [x8]
    2008:      	ldr	w8, [x8]
    200c:      	cbnz	w8, 0x2afc <kprobe_unwind_v8+0x2afc>
    2010:      	ldrb	w24, [x21, #0xf20]
    2014:      	mov	x25, xzr
    2018:      	b	0x10d4 <kprobe_unwind_v8+0x10d4>
    201c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2020:      	add	x8, x8, #0x0
    2024:      	add	x0, sp, #0x70
    2028:      	ldp	x9, x10, [x8, #0x10]
    202c:      	mov	w1, #0x2e               // =46
    2030:      	stp	x9, x10, [sp, #0x80]
    2034:      	ldr	x9, [x8, #0x20]
    2038:      	add	x10, sp, #0x70
    203c:      	str	x9, [sp, #0x90]
    2040:      	ldur	x9, [x8, #0x26]
    2044:      	stur	x9, [sp, #0x96]
    2048:      	ldp	x9, x8, [x8]
    204c:      	stp	x9, x8, [sp, #0x70]
    2050:      	mov	w8, #0x2e               // =46
    2054:      	mov	w9, #0x6                // =6
    2058:      	ldr	w2, [sp, #0xbc]
    205c:      	blr	x9
    2060:      	b	0xe0c <kprobe_unwind_v8+0xe0c>
    2064:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2068:      	add	x8, x8, #0x0
    206c:      	add	x0, sp, #0x70
    2070:      	ldp	x9, x10, [x8]
    2074:      	mov	w1, #0x1d               // =29
    2078:      	mov	x2, x25
    207c:      	stp	x9, x10, [sp, #0x70]
    2080:      	ldr	x9, [x8, #0x10]
    2084:      	ldur	x8, [x8, #0x15]
    2088:      	add	x10, sp, #0x70
    208c:      	str	x9, [sp, #0x80]
    2090:      	stur	x8, [sp, #0x85]
    2094:      	mov	w8, #0x1d               // =29
    2098:      	mov	w9, #0x6                // =6
    209c:      	blr	x9
    20a0:      	mov	x22, xzr
    20a4:      	b	0x1e2c <kprobe_unwind_v8+0x1e2c>
    20a8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    20ac:      	add	x8, x8, #0x0
    20b0:      	add	x0, sp, #0x70
    20b4:      	ldp	x9, x10, [x8]
    20b8:      	mov	w1, #0x1f               // =31
    20bc:      	stp	x9, x10, [sp, #0x70]
    20c0:      	ldr	x9, [x8, #0x10]
    20c4:      	ldur	x8, [x8, #0x17]
    20c8:      	add	x10, sp, #0x70
    20cc:      	str	x9, [sp, #0x80]
    20d0:      	stur	x8, [sp, #0x87]
    20d4:      	mov	w8, #0x1f               // =31
    20d8:      	mov	w9, #0x6                // =6
    20dc:      	ldr	x2, [x21, #0xed0]
    20e0:      	ldr	x3, [x21, #0xed8]
    20e4:      	ldr	x4, [x21, #0xee0]
    20e8:      	blr	x9
    20ec:      	b	0x1178 <kprobe_unwind_v8+0x1178>
    20f0:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    20f4:      	add	x8, x8, #0x0
    20f8:      	strb	wzr, [sp, #0xa0]
    20fc:      	add	x0, sp, #0x70
    2100:      	ldp	x9, x10, [x8, #0x10]
    2104:      	mov	w1, #0x31               // =49
    2108:      	stp	x9, x10, [sp, #0x80]
    210c:      	ldp	x9, x10, [x8, #0x20]
    2110:      	stp	x9, x10, [sp, #0x90]
    2114:      	ldp	x9, x8, [x8]
    2118:      	add	x10, sp, #0x70
    211c:      	stp	x9, x8, [sp, #0x70]
    2120:      	mov	w8, #0x31               // =49
    2124:      	mov	w9, #0x6                // =6
    2128:      	ldr	w2, [x21, #0x2c0]
    212c:      	blr	x9
    2130:      	ldr	x24, [x21, #0xed0]
    2134:      	lsr	x8, x24, #56
    2138:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    213c:      	b	0x1630 <kprobe_unwind_v8+0x1630>
    2140:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2144:      	add	x8, x8, #0x0
    2148:      	add	x0, sp, #0x70
    214c:      	ldp	x9, x10, [x8, #0x10]
    2150:      	mov	w1, #0x2e               // =46
    2154:      	stp	x9, x10, [sp, #0x80]
    2158:      	ldr	x9, [x8, #0x20]
    215c:      	add	x10, sp, #0x70
    2160:      	str	x9, [sp, #0x90]
    2164:      	ldur	x9, [x8, #0x26]
    2168:      	stur	x9, [sp, #0x96]
    216c:      	ldp	x9, x8, [x8]
    2170:      	stp	x9, x8, [sp, #0x70]
    2174:      	mov	w8, #0x2e               // =46
    2178:      	mov	w9, #0x6                // =6
    217c:      	ldr	w2, [sp, #0x58]
    2180:      	blr	x9
    2184:      	b	0x11a8 <kprobe_unwind_v8+0x11a8>
    2188:      	mov	w8, #0x786c             // =30828
    218c:      	add	x0, sp, #0x70
    2190:      	mov	w1, #0x1c               // =28
    2194:      	mov	x2, x25
    2198:      	movk	w8, #0xa, lsl #16
    219c:      	str	w8, [sp, #0x88]
    21a0:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    21a4:      	add	x8, x8, #0x0
    21a8:      	ldp	x9, x10, [x8]
    21ac:      	ldr	x8, [x8, #0x10]
    21b0:      	stp	x9, x10, [sp, #0x70]
    21b4:      	mov	w9, #0x6                // =6
    21b8:      	str	x8, [sp, #0x80]
    21bc:      	mov	w8, #0x1c               // =28
    21c0:      	add	x10, sp, #0x70
    21c4:      	blr	x9
    21c8:      	b	0x14cc <kprobe_unwind_v8+0x14cc>
    21cc:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    21d0:      	add	x8, x8, #0x0
    21d4:      	add	x0, sp, #0x70
    21d8:      	ldp	x9, x10, [x8, #0x10]
    21dc:      	mov	w1, #0x2e               // =46
    21e0:      	mov	x2, x29
    21e4:      	mov	x3, x25
    21e8:      	stp	x9, x10, [sp, #0x80]
    21ec:      	ldr	x9, [x8, #0x20]
    21f0:      	add	x10, sp, #0x70
    21f4:      	str	x9, [sp, #0x90]
    21f8:      	ldur	x9, [x8, #0x26]
    21fc:      	stur	x9, [sp, #0x96]
    2200:      	ldp	x9, x8, [x8]
    2204:      	stp	x9, x8, [sp, #0x70]
    2208:      	mov	w8, #0x2e               // =46
    220c:      	mov	w9, #0x6                // =6
    2210:      	blr	x9
    2214:      	b	0x1de0 <kprobe_unwind_v8+0x1de0>
    2218:      	mov	w8, #0xa                // =10
    221c:      	add	x0, sp, #0x70
    2220:      	mov	w1, #0x32               // =50
    2224:      	strh	w8, [sp, #0xa0]
    2228:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    222c:      	add	x8, x8, #0x0
    2230:      	mov	x2, x24
    2234:      	ldp	x9, x10, [x8, #0x10]
    2238:      	mov	w4, w29
    223c:      	stp	x9, x10, [sp, #0x80]
    2240:      	ldp	x9, x10, [x8, #0x20]
    2244:      	stp	x9, x10, [sp, #0x90]
    2248:      	ldp	x9, x8, [x8]
    224c:      	add	x10, sp, #0x70
    2250:      	stp	x9, x8, [sp, #0x70]
    2254:      	mov	w8, #0x32               // =50
    2258:      	mov	w9, #0x6                // =6
    225c:      	ldr	x3, [x21, #0xf00]
    2260:      	blr	x9
    2264:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2268:      	ldr	x8, [x8]
    226c:      	ldr	w8, [x8]
    2270:      	cbz	w8, 0x169c <kprobe_unwind_v8+0x169c>
    2274:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2278:      	add	x8, x8, #0x0
    227c:      	add	x0, sp, #0x70
    2280:      	ldp	x9, x10, [x8, #0x10]
    2284:      	mov	w1, #0x2f               // =47
    2288:      	stp	x9, x10, [sp, #0x80]
    228c:      	ldr	x9, [x8, #0x20]
    2290:      	add	x10, sp, #0x70
    2294:      	str	x9, [sp, #0x90]
    2298:      	ldur	x9, [x8, #0x27]
    229c:      	stur	x9, [sp, #0x97]
    22a0:      	ldp	x9, x8, [x8]
    22a4:      	stp	x9, x8, [sp, #0x70]
    22a8:      	mov	w8, #0x2f               // =47
    22ac:      	mov	w9, #0x6                // =6
    22b0:      	ldr	x2, [x21, #0xf10]
    22b4:      	ldr	x3, [x21, #0xf08]
    22b8:      	blr	x9
    22bc:      	b	0x169c <kprobe_unwind_v8+0x169c>
    22c0:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    22c4:      	add	x8, x8, #0x0
    22c8:      	add	x0, sp, #0x70
    22cc:      	ldp	x9, x10, [x8, #0x10]
    22d0:      	mov	w1, #0x2e               // =46
    22d4:      	stp	x9, x10, [sp, #0x80]
    22d8:      	ldr	x9, [x8, #0x20]
    22dc:      	add	x10, sp, #0x70
    22e0:      	str	x9, [sp, #0x90]
    22e4:      	ldur	x9, [x8, #0x26]
    22e8:      	stur	x9, [sp, #0x96]
    22ec:      	ldp	x9, x8, [x8]
    22f0:      	stp	x9, x8, [sp, #0x70]
    22f4:      	mov	w8, #0x2e               // =46
    22f8:      	mov	w9, #0x6                // =6
    22fc:      	ldr	w2, [sp, #0x58]
    2300:      	blr	x9
    2304:      	b	0x1e28 <kprobe_unwind_v8+0x1e28>
    2308:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    230c:      	add	x8, x8, #0x0
    2310:      	strb	wzr, [sp, #0x98]
    2314:      	add	x0, sp, #0x70
    2318:      	ldp	x9, x10, [x8, #0x10]
    231c:      	mov	w1, #0x29               // =41
    2320:      	mov	x2, x29
    2324:      	mov	x4, x25
    2328:      	stp	x9, x10, [sp, #0x80]
    232c:      	ldr	x9, [x8, #0x20]
    2330:      	add	x10, sp, #0x70
    2334:      	str	x9, [sp, #0x90]
    2338:      	ldp	x8, x9, [x8]
    233c:      	stp	x8, x9, [sp, #0x70]
    2340:      	mov	w8, #0x29               // =41
    2344:      	mov	w9, #0x6                // =6
    2348:      	ldr	x3, [sp, #0x40]
    234c:      	blr	x9
    2350:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2354:      	ldr	x8, [x8]
    2358:      	ldr	w8, [x8]
    235c:      	cbz	w8, 0x1fb0 <kprobe_unwind_v8+0x1fb0>
    2360:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2364:      	add	x8, x8, #0x0
    2368:      	add	x0, sp, #0x70
    236c:      	ldp	x9, x10, [x8, #0x10]
    2370:      	mov	w1, #0x25               // =37
    2374:      	stp	x9, x10, [sp, #0x80]
    2378:      	ldur	x9, [x8, #0x1d]
    237c:      	add	x10, sp, #0x70
    2380:      	stur	x9, [sp, #0x8d]
    2384:      	ldp	x8, x9, [x8]
    2388:      	stp	x8, x9, [sp, #0x70]
    238c:      	mov	w8, #0x25               // =37
    2390:      	mov	w9, #0x6                // =6
    2394:      	ldp	x3, x2, [sp, #0x30]
    2398:      	ldr	x4, [sp, #0x28]
    239c:      	blr	x9
    23a0:      	b	0x1fb0 <kprobe_unwind_v8+0x1fb0>
    23a4:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    23a8:      	add	x8, x8, #0x0
    23ac:      	add	x0, sp, #0x70
    23b0:      	ldp	x9, x10, [x8]
    23b4:      	mov	w1, #0x1e               // =30
    23b8:      	stp	x9, x10, [sp, #0x70]
    23bc:      	ldr	x9, [x8, #0x10]
    23c0:      	ldur	x8, [x8, #0x16]
    23c4:      	add	x10, sp, #0x70
    23c8:      	str	x9, [sp, #0x80]
    23cc:      	stur	x8, [sp, #0x86]
    23d0:      	mov	w8, #0x1e               // =30
    23d4:      	mov	w9, #0x6                // =6
    23d8:      	ldrh	w2, [x24, #0x20]
    23dc:      	blr	x9
    23e0:      	ldrh	w8, [x24, #0x20]
    23e4:      	ldr	w9, [x21, #0x1370]
    23e8:      	lsr	w8, w9, w8
    23ec:      	tbnz	w8, #0x0, 0x1724 <kprobe_unwind_v8+0x1724>
    23f0:      	str	wzr, [sp, #0xbc]
    23f4:      	adrp	x0, 0x2000 <kprobe_unwind_v8+0x2000>
    23f8:      	mov	w8, #0x1                // =1
    23fc:      	add	x9, sp, #0xbc
    2400:      	ldr	x0, [x0]
    2404:      	add	x1, sp, #0xbc
    2408:      	blr	x8
    240c:      	cbz	x0, 0x2420 <kprobe_unwind_v8+0x2420>
    2410:      	ldr	x8, [x0]
    2414:      	add	x8, x8, #0x1
    2418:      	str	x8, [x0]
    241c:      	b	0x2430 <kprobe_unwind_v8+0x2430>
    2420:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2424:      	ldr	x8, [x8]
    2428:      	ldr	w8, [x8]
    242c:      	cbnz	w8, 0x2c20 <kprobe_unwind_v8+0x2c20>
    2430:      	ldrh	w29, [x24, #0x20]
    2434:      	cmp	w29, #0x7
    2438:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    243c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2440:      	ldr	x29, [x21, #0xed8]
    2444:      	ldr	x25, [x21, #0xee0]
    2448:      	ldr	x24, [x21, #0xed0]
    244c:      	ldr	x8, [x8]
    2450:      	ldr	w8, [x8]
    2454:      	cbnz	w8, 0x2a1c <kprobe_unwind_v8+0x2a1c>
    2458:      	cmp	x25, x29
    245c:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    2460:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    2464:      	cmp	x25, x8
    2468:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    246c:      	ldr	x0, [sp, #0x50]
    2470:      	sub	x2, x25, #0x40
    2474:      	mov	w8, #0x40               // =64
    2478:      	mov	w9, #0x70               // =112
    247c:      	mov	w1, #0x40               // =64
    2480:      	blr	x9
    2484:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    2488:      	ldrb	w9, [x23, #0x14]
    248c:      	cmp	x9, #0x38
    2490:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    2494:      	ldrb	w8, [x23, #0x15]
    2498:      	cmp	x8, #0x38
    249c:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    24a0:      	ldrb	w10, [x23, #0x16]
    24a4:      	cmp	x10, #0x38
    24a8:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    24ac:      	ldr	x11, [sp, #0x50]
    24b0:      	ldr	x9, [x11, x9]
    24b4:      	tbnz	w9, #0x0, 0x25b8 <kprobe_unwind_v8+0x25b8>
    24b8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    24bc:      	lsr	x25, x9, #1
    24c0:      	ldr	x8, [x8]
    24c4:      	ldr	w8, [x8]
    24c8:      	cbnz	w8, 0x2d1c <kprobe_unwind_v8+0x2d1c>
    24cc:      	ldrb	w24, [x21, #0xf20]
    24d0:      	mov	x22, xzr
    24d4:      	ldr	w8, [x21, #0x2c0]
    24d8:      	cmp	w8, #0x7e
    24dc:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    24e0:      	add	w9, w8, #0x1
    24e4:      	mov	w10, #0x8               // =8
    24e8:      	add	x11, sp, #0x70
    24ec:      	str	w9, [x21, #0x2c0]
    24f0:      	mov	w9, #0x18               // =24
    24f4:      	add	x0, sp, #0x70
    24f8:      	mov	w1, #0x10               // =16
    24fc:      	umaddl	x8, w8, w9, x21
    2500:      	add	x9, x8, #0x2d0
    2504:      	str	x22, [x8, #0x2d0]
    2508:      	str	x25, [x8, #0x2d8]
    250c:      	strb	w10, [x8, #0x2e0]
    2510:      	strb	w24, [x8, #0x2e1]
    2514:      	strh	wzr, [x8, #0x2e6]
    2518:      	mov	w10, #0x70              // =112
    251c:      	stur	wzr, [x9, #0x12]
    2520:      	mov	w9, #0x10               // =16
    2524:      	ldr	x8, [x21, #0xee0]
    2528:      	ldr	x2, [x21, #0xee0]
    252c:      	blr	x10
    2530:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    2534:      	ldr	x8, [x21, #0xee0]
    2538:      	add	x9, x8, #0x10
    253c:      	str	x9, [x21, #0xed8]
    2540:      	ldp	x9, x10, [sp, #0x70]
    2544:      	str	x9, [x21, #0xee0]
    2548:      	mov	w9, #0x101              // =257
    254c:      	str	x10, [x21, #0xed0]
    2550:      	strh	w9, [x21, #0xf20]
    2554:      	cbnz	x22, 0x2568 <kprobe_unwind_v8+0x2568>
    2558:      	cmp	x25, #0x1
    255c:      	b.ne	0x2568 <kprobe_unwind_v8+0x2568>
    2560:      	add	x8, x8, #0xa0
    2564:      	str	x8, [x21, #0xed8]
    2568:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    256c:      	ldr	x8, [x8]
    2570:      	ldr	w8, [x8]
    2574:      	cbnz	w8, 0x2d60 <kprobe_unwind_v8+0x2d60>
    2578:      	mov	w8, #0x38               // =56
    257c:      	adrp	x0, 0x2000 <kprobe_unwind_v8+0x2000>
    2580:      	add	x9, sp, #0x58
    2584:      	str	w8, [sp, #0x58]
    2588:      	mov	w8, #0x1                // =1
    258c:      	add	x1, sp, #0x58
    2590:      	ldr	x0, [x0]
    2594:      	blr	x8
    2598:      	cbz	x0, 0x2768 <kprobe_unwind_v8+0x2768>
    259c:      	ldr	x8, [x0]
    25a0:      	add	x8, x8, #0x1
    25a4:      	str	x8, [x0]
    25a8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    25ac:      	ldr	x8, [x8]
    25b0:      	ldr	w8, [x8]
    25b4:      	b	0x2778 <kprobe_unwind_v8+0x2778>
    25b8:      	ldr	x9, [sp, #0x50]
    25bc:      	ldr	x8, [x9, x8]
    25c0:      	ldr	x22, [x9, x10]
    25c4:      	and	x9, x8, #0x3
    25c8:      	and	x8, x8, #0xfffffffffffffffc
    25cc:      	cmp	x9, #0x1
    25d0:      	csel	x29, x8, xzr, eq
    25d4:      	cbz	x29, 0x264c <kprobe_unwind_v8+0x264c>
    25d8:      	ldrb	w8, [x23, #0xc]
    25dc:      	mov	w9, #0x70               // =112
    25e0:      	add	x10, sp, #0x70
    25e4:      	add	x0, sp, #0x70
    25e8:      	mov	w1, #0x8                // =8
    25ec:      	add	x2, x29, x8
    25f0:      	mov	w8, #0x8                // =8
    25f4:      	blr	x9
    25f8:      	cbnz	x0, 0x264c <kprobe_unwind_v8+0x264c>
    25fc:      	ldr	x8, [sp, #0x70]
    2600:      	and	x9, x8, #0x3
    2604:      	cmp	x9, #0x1
    2608:      	b.ne	0x264c <kprobe_unwind_v8+0x264c>
    260c:      	and	x8, x8, #0xfffffffffffffffc
    2610:      	cbz	x8, 0x2650 <kprobe_unwind_v8+0x2650>
    2614:      	ldrb	w9, [x23, #0xd]
    2618:      	mov	w10, #0x2               // =2
    261c:      	mov	w11, #0x70              // =112
    2620:      	add	x12, sp, #0x70
    2624:      	add	x0, sp, #0x70
    2628:      	mov	w1, #0x2                // =2
    262c:      	add	x9, x8, x9
    2630:      	ldrb	w9, [x23, #0xd]
    2634:      	add	x2, x8, x9
    2638:      	blr	x11
    263c:      	ldrh	w8, [sp, #0x70]
    2640:      	cmp	x0, #0x0
    2644:      	csel	w8, w8, wzr, eq
    2648:      	b	0x2650 <kprobe_unwind_v8+0x2650>
    264c:      	mov	w8, wzr
    2650:      	ldrh	w9, [x23, #0x4]
    2654:      	cmp	w9, w8, uxth
    2658:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    265c:      	ldrh	w9, [x23, #0x6]
    2660:      	cmp	w9, w8, uxth
    2664:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    2668:      	ldrb	w8, [x23, #0xf]
    266c:      	mov	w9, #0x70               // =112
    2670:      	add	x10, sp, #0x70
    2674:      	add	x0, sp, #0x70
    2678:      	mov	w1, #0x8                // =8
    267c:      	add	x2, x29, x8
    2680:      	mov	w8, #0x8                // =8
    2684:      	blr	x9
    2688:      	cbnz	x0, 0x272c <kprobe_unwind_v8+0x272c>
    268c:      	ldr	x8, [sp, #0x70]
    2690:      	and	x9, x8, #0x3
    2694:      	cmp	x9, #0x1
    2698:      	b.ne	0x272c <kprobe_unwind_v8+0x272c>
    269c:      	and	x8, x8, #0xfffffffffffffffc
    26a0:      	str	x8, [sp, #0x40]
    26a4:      	cbz	x8, 0x2a6c <kprobe_unwind_v8+0x2a6c>
    26a8:      	ldrb	w8, [x23, #0xc]
    26ac:      	ldr	x9, [sp, #0x40]
    26b0:      	add	x10, sp, #0x70
    26b4:      	add	x0, sp, #0x70
    26b8:      	mov	w1, #0x8                // =8
    26bc:      	add	x2, x9, x8
    26c0:      	mov	w8, #0x8                // =8
    26c4:      	mov	w9, #0x70               // =112
    26c8:      	blr	x9
    26cc:      	cbnz	x0, 0x2730 <kprobe_unwind_v8+0x2730>
    26d0:      	ldr	x8, [sp, #0x70]
    26d4:      	and	x9, x8, #0x3
    26d8:      	cmp	x9, #0x1
    26dc:      	b.ne	0x2730 <kprobe_unwind_v8+0x2730>
    26e0:      	and	x8, x8, #0xfffffffffffffffc
    26e4:      	cbz	x8, 0x2734 <kprobe_unwind_v8+0x2734>
    26e8:      	ldrb	w9, [x23, #0xd]
    26ec:      	mov	w10, #0x2               // =2
    26f0:      	mov	w11, #0x70              // =112
    26f4:      	add	x12, sp, #0x70
    26f8:      	add	x0, sp, #0x70
    26fc:      	mov	w1, #0x2                // =2
    2700:      	add	x9, x8, x9
    2704:      	ldrb	w9, [x23, #0xd]
    2708:      	add	x2, x8, x9
    270c:      	blr	x11
    2710:      	ldrh	w8, [sp, #0x70]
    2714:      	cmp	x0, #0x0
    2718:      	csel	w8, w8, wzr, eq
    271c:      	ldrh	w9, [x23, #0xa]
    2720:      	cmp	w9, w8, uxth
    2724:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    2728:      	b	0x2740 <kprobe_unwind_v8+0x2740>
    272c:      	str	xzr, [sp, #0x40]
    2730:      	mov	w8, wzr
    2734:      	ldrh	w9, [x23, #0xa]
    2738:      	cmp	w9, w8, uxth
    273c:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    2740:      	lsr	x25, x22, #32
    2744:      	cbz	x25, 0x28a0 <kprobe_unwind_v8+0x28a0>
    2748:      	tbnz	w22, #0x0, 0x28a0 <kprobe_unwind_v8+0x28a0>
    274c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2750:      	ldr	x8, [x8]
    2754:      	ldr	w8, [x8]
    2758:      	cbnz	w8, 0x2e40 <kprobe_unwind_v8+0x2e40>
    275c:      	ldr	x8, [sp, #0x40]
    2760:      	orr	x22, x8, #0x1
    2764:      	b	0x2ba8 <kprobe_unwind_v8+0x2ba8>
    2768:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    276c:      	ldr	x8, [x8]
    2770:      	ldr	w8, [x8]
    2774:      	cbnz	w8, 0x2df8 <kprobe_unwind_v8+0x2df8>
    2778:      	ldr	x24, [x21, #0xed0]
    277c:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    2780:      	cbnz	w8, 0x2da8 <kprobe_unwind_v8+0x2da8>
    2784:      	lsr	x8, x24, #56
    2788:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    278c:      	cmp	x24, #0x1, lsl #12      // =0x1000
    2790:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    2794:      	ldr	w8, [x21]
    2798:      	mov	w9, #0x60               // =96
    279c:      	adrp	x0, 0x2000 <kprobe_unwind_v8+0x2000>
    27a0:      	add	x1, sp, #0x58
    27a4:      	rev	w8, w8
    27a8:      	stp	w9, w8, [sp, #0x58]
    27ac:      	rev	x8, x24
    27b0:      	add	x9, sp, #0x58
    27b4:      	str	x8, [sp, #0x60]
    27b8:      	mov	w8, #0x1                // =1
    27bc:      	ldr	x0, [x0]
    27c0:      	blr	x8
    27c4:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    27c8:      	ldr	x8, [x0, #0x8]
    27cc:      	and	x9, x8, #0xffffffffffffff
    27d0:      	lsr	x29, x8, #56
    27d4:      	str	x9, [x21, #0xf10]
    27d8:      	ldr	x8, [x0]
    27dc:      	str	x8, [x21, #0xf00]
    27e0:      	sub	x8, x24, x9
    27e4:      	str	x8, [x21, #0xf08]
    27e8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    27ec:      	ldr	x8, [x8]
    27f0:      	ldr	w8, [x8]
    27f4:      	cbnz	w8, 0x2ed0 <kprobe_unwind_v8+0x2ed0>
    27f8:      	cmp	w29, #0x1
    27fc:      	b.ne	0x3050 <kprobe_unwind_v8+0x3050>
    2800:      	ldr	x8, [x21, #0xf00]
    2804:      	adrp	x0, 0x2000 <kprobe_unwind_v8+0x2000>
    2808:      	ldr	x25, [x21, #0xf08]
    280c:      	mov	w9, #0x1                // =1
    2810:      	add	x1, sp, #0x58
    2814:      	mov	w29, #0x1               // =1
    2818:      	str	x8, [sp, #0x58]
    281c:      	add	x8, sp, #0x58
    2820:      	ldr	x0, [x0]
    2824:      	blr	x9
    2828:      	cbz	x0, 0x2c14 <kprobe_unwind_v8+0x2c14>
    282c:      	ldr	x8, [x0]
    2830:      	mov	x24, x0
    2834:      	cmp	x8, x25
    2838:      	b.hi	0x2848 <kprobe_unwind_v8+0x2848>
    283c:      	ldr	x8, [x24, #0x8]
    2840:      	cmp	x8, x25
    2844:      	b.hs	0x2860 <kprobe_unwind_v8+0x2860>
    2848:      	ldr	x8, [x24, #0x10]
    284c:      	cmp	x8, x25
    2850:      	b.hi	0x2890 <kprobe_unwind_v8+0x2890>
    2854:      	ldr	x8, [x24, #0x18]
    2858:      	cmp	x8, x25
    285c:      	b.lo	0x2890 <kprobe_unwind_v8+0x2890>
    2860:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2864:      	ldr	x8, [x8]
    2868:      	ldr	w8, [x8]
    286c:      	cbnz	w8, 0x2fc0 <kprobe_unwind_v8+0x2fc0>
    2870:      	ldrh	w8, [x24, #0x20]
    2874:      	ldr	w9, [x21, #0x1370]
    2878:      	lsr	w8, w9, w8
    287c:      	tbz	w8, #0x0, 0x300c <kprobe_unwind_v8+0x300c>
    2880:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2884:      	ldr	x8, [x8]
    2888:      	ldr	w8, [x8]
    288c:      	cbnz	w8, 0x37f4 <kprobe_unwind_v8+0x37f4>
    2890:      	mov	w29, #0x1               // =1
    2894:      	cmp	w29, #0x7
    2898:      	b.eq	0x3058 <kprobe_unwind_v8+0x3058>
    289c:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    28a0:      	ldr	x8, [sp, #0x40]
    28a4:      	mov	w9, #0x70               // =112
    28a8:      	add	x10, sp, #0x70
    28ac:      	add	x0, sp, #0x70
    28b0:      	mov	w1, #0x8                // =8
    28b4:      	orr	x22, x8, #0x2
    28b8:      	ldrb	w8, [x23, #0xe]
    28bc:      	add	x2, x29, x8
    28c0:      	mov	w8, #0x8                // =8
    28c4:      	blr	x9
    28c8:      	cbnz	x0, 0x296c <kprobe_unwind_v8+0x296c>
    28cc:      	ldr	x8, [sp, #0x70]
    28d0:      	and	x9, x8, #0x3
    28d4:      	cmp	x9, #0x1
    28d8:      	b.ne	0x296c <kprobe_unwind_v8+0x296c>
    28dc:      	and	x8, x8, #0xfffffffffffffffc
    28e0:      	mov	x25, x8
    28e4:      	cbz	x8, 0x2974 <kprobe_unwind_v8+0x2974>
    28e8:      	ldrb	w8, [x23, #0xc]
    28ec:      	mov	w9, #0x70               // =112
    28f0:      	add	x10, sp, #0x70
    28f4:      	add	x0, sp, #0x70
    28f8:      	mov	w1, #0x8                // =8
    28fc:      	add	x2, x25, x8
    2900:      	mov	w8, #0x8                // =8
    2904:      	blr	x9
    2908:      	cbnz	x0, 0x2b38 <kprobe_unwind_v8+0x2b38>
    290c:      	ldr	x8, [sp, #0x70]
    2910:      	and	x9, x8, #0x3
    2914:      	cmp	x9, #0x1
    2918:      	b.ne	0x2b38 <kprobe_unwind_v8+0x2b38>
    291c:      	and	x8, x8, #0xfffffffffffffffc
    2920:      	cbz	x8, 0x2974 <kprobe_unwind_v8+0x2974>
    2924:      	ldrb	w9, [x23, #0xd]
    2928:      	mov	w10, #0x2               // =2
    292c:      	mov	w11, #0x70              // =112
    2930:      	add	x12, sp, #0x70
    2934:      	add	x0, sp, #0x70
    2938:      	mov	w1, #0x2                // =2
    293c:      	add	x9, x8, x9
    2940:      	ldrb	w9, [x23, #0xd]
    2944:      	add	x2, x8, x9
    2948:      	blr	x11
    294c:      	ldrh	w8, [sp, #0x70]
    2950:      	cmp	x0, #0x0
    2954:      	csel	w8, w8, wzr, eq
    2958:      	and	w4, w8, #0xffff
    295c:      	ldrh	w8, [x23, #0x8]
    2960:      	cmp	w4, w8
    2964:      	b.eq	0x2984 <kprobe_unwind_v8+0x2984>
    2968:      	b	0x2b4c <kprobe_unwind_v8+0x2b4c>
    296c:      	mov	x25, xzr
    2970:      	mov	w8, wzr
    2974:      	and	w4, w8, #0xffff
    2978:      	ldrh	w8, [x23, #0x8]
    297c:      	cmp	w4, w8
    2980:      	b.ne	0x2b4c <kprobe_unwind_v8+0x2b4c>
    2984:      	ldr	x0, [sp, #0x48]
    2988:      	mov	w8, #0x60               // =96
    298c:      	mov	w9, #0x70               // =112
    2990:      	mov	x2, x25
    2994:      	mov	w1, #0x60               // =96
    2998:      	blr	x9
    299c:      	cbz	x0, 0x2a80 <kprobe_unwind_v8+0x2a80>
    29a0:      	mov	w8, #0x3b               // =59
    29a4:      	adrp	x0, 0x2000 <kprobe_unwind_v8+0x2000>
    29a8:      	add	x9, sp, #0x58
    29ac:      	str	w8, [sp, #0x58]
    29b0:      	mov	w8, #0x1                // =1
    29b4:      	add	x1, sp, #0x58
    29b8:      	ldr	x0, [x0]
    29bc:      	blr	x8
    29c0:      	cbnz	x0, 0x2b80 <kprobe_unwind_v8+0x2b80>
    29c4:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    29c8:      	ldr	x8, [x8]
    29cc:      	ldr	w8, [x8]
    29d0:      	cbz	w8, 0x2ba4 <kprobe_unwind_v8+0x2ba4>
    29d4:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    29d8:      	add	x8, x8, #0x0
    29dc:      	add	x0, sp, #0x70
    29e0:      	ldp	x9, x10, [x8, #0x10]
    29e4:      	mov	w1, #0x2e               // =46
    29e8:      	stp	x9, x10, [sp, #0x80]
    29ec:      	ldr	x9, [x8, #0x20]
    29f0:      	add	x10, sp, #0x70
    29f4:      	str	x9, [sp, #0x90]
    29f8:      	ldur	x9, [x8, #0x26]
    29fc:      	stur	x9, [sp, #0x96]
    2a00:      	ldp	x9, x8, [x8]
    2a04:      	stp	x9, x8, [sp, #0x70]
    2a08:      	mov	w8, #0x2e               // =46
    2a0c:      	mov	w9, #0x6                // =6
    2a10:      	ldr	w2, [sp, #0x58]
    2a14:      	blr	x9
    2a18:      	b	0x2ba4 <kprobe_unwind_v8+0x2ba4>
    2a1c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2a20:      	add	x8, x8, #0x0
    2a24:      	add	x0, sp, #0x70
    2a28:      	ldp	x9, x10, [x8]
    2a2c:      	mov	w1, #0x1f               // =31
    2a30:      	mov	x2, x24
    2a34:      	mov	x3, x29
    2a38:      	stp	x9, x10, [sp, #0x70]
    2a3c:      	ldr	x9, [x8, #0x10]
    2a40:      	ldur	x8, [x8, #0x17]
    2a44:      	add	x10, sp, #0x70
    2a48:      	mov	x4, x25
    2a4c:      	str	x9, [sp, #0x80]
    2a50:      	stur	x8, [sp, #0x87]
    2a54:      	mov	w8, #0x1f               // =31
    2a58:      	mov	w9, #0x6                // =6
    2a5c:      	blr	x9
    2a60:      	cmp	x25, x29
    2a64:      	b.hs	0x2460 <kprobe_unwind_v8+0x2460>
    2a68:      	b	0x1954 <kprobe_unwind_v8+0x1954>
    2a6c:      	str	xzr, [sp, #0x40]
    2a70:      	ldrh	w9, [x23, #0xa]
    2a74:      	cmp	w9, w8, uxth
    2a78:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    2a7c:      	b	0x2740 <kprobe_unwind_v8+0x2740>
    2a80:      	ldrb	w8, [x23, #0x12]
    2a84:      	cmp	x8, #0x5c
    2a88:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    2a8c:      	ldrb	w9, [x23, #0x13]
    2a90:      	cmp	x9, #0x5c
    2a94:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    2a98:      	ldrb	w11, [x23, #0x10]
    2a9c:      	ldrb	w10, [x23, #0x11]
    2aa0:      	cbz	w11, 0x2c68 <kprobe_unwind_v8+0x2c68>
    2aa4:      	ldr	x11, [sp, #0x48]
    2aa8:      	ldr	x10, [x11, x10]
    2aac:      	b	0x2c6c <kprobe_unwind_v8+0x2c6c>
    2ab0:      	mov	w8, #0x656e             // =25966
    2ab4:      	add	x0, sp, #0x70
    2ab8:      	mov	w1, #0x1b               // =27
    2abc:      	movk	w8, #0xa, lsl #16
    2ac0:      	stur	w8, [sp, #0x87]
    2ac4:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2ac8:      	add	x8, x8, #0x0
    2acc:      	ldp	x9, x10, [x8]
    2ad0:      	ldr	x8, [x8, #0x10]
    2ad4:      	stp	x9, x10, [sp, #0x70]
    2ad8:      	str	x8, [sp, #0x80]
    2adc:      	mov	w8, #0x1b               // =27
    2ae0:      	mov	w9, #0x6                // =6
    2ae4:      	add	x10, sp, #0x70
    2ae8:      	blr	x9
    2aec:      	mov	w29, #0x1               // =1
    2af0:      	cmp	w29, #0x7
    2af4:      	b.eq	0x243c <kprobe_unwind_v8+0x243c>
    2af8:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    2afc:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2b00:      	add	x8, x8, #0x0
    2b04:      	add	x0, sp, #0x70
    2b08:      	ldp	x9, x10, [x8, #0x10]
    2b0c:      	mov	w1, #0x30               // =48
    2b10:      	stp	x9, x10, [sp, #0x80]
    2b14:      	ldp	x9, x10, [x8, #0x20]
    2b18:      	stp	x9, x10, [sp, #0x90]
    2b1c:      	ldp	x9, x8, [x8]
    2b20:      	add	x10, sp, #0x70
    2b24:      	stp	x9, x8, [sp, #0x70]
    2b28:      	mov	w8, #0x30               // =48
    2b2c:      	mov	w9, #0x6                // =6
    2b30:      	blr	x9
    2b34:      	b	0x1e28 <kprobe_unwind_v8+0x1e28>
    2b38:      	mov	w8, wzr
    2b3c:      	and	w4, wzr, #0xffff
    2b40:      	ldrh	w8, [x23, #0x8]
    2b44:      	cmp	w4, w8
    2b48:      	b.eq	0x2984 <kprobe_unwind_v8+0x2984>
    2b4c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2b50:      	ldr	x8, [x8]
    2b54:      	ldr	w8, [x8]
    2b58:      	cbnz	w8, 0x2e84 <kprobe_unwind_v8+0x2e84>
    2b5c:      	mov	w8, #0x3b               // =59
    2b60:      	adrp	x0, 0x2000 <kprobe_unwind_v8+0x2000>
    2b64:      	add	x9, sp, #0x58
    2b68:      	str	w8, [sp, #0x58]
    2b6c:      	mov	w8, #0x1                // =1
    2b70:      	add	x1, sp, #0x58
    2b74:      	ldr	x0, [x0]
    2b78:      	blr	x8
    2b7c:      	cbz	x0, 0x2b94 <kprobe_unwind_v8+0x2b94>
    2b80:      	ldr	x8, [x0]
    2b84:      	mov	x25, xzr
    2b88:      	add	x8, x8, #0x1
    2b8c:      	str	x8, [x0]
    2b90:      	b	0x2ba8 <kprobe_unwind_v8+0x2ba8>
    2b94:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2b98:      	ldr	x8, [x8]
    2b9c:      	ldr	w8, [x8]
    2ba0:      	cbnz	w8, 0x2f78 <kprobe_unwind_v8+0x2f78>
    2ba4:      	mov	x25, xzr
    2ba8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2bac:      	ldr	x8, [x8]
    2bb0:      	ldrb	w24, [x21, #0xf20]
    2bb4:      	ldr	w8, [x8]
    2bb8:      	cbz	w8, 0x24d4 <kprobe_unwind_v8+0x24d4>
    2bbc:      	mov	w8, #0x786c             // =30828
    2bc0:      	add	x0, sp, #0x70
    2bc4:      	mov	w1, #0x3c               // =60
    2bc8:      	mov	x2, x25
    2bcc:      	mov	x3, x22
    2bd0:      	movk	w8, #0xa, lsl #16
    2bd4:      	str	w8, [sp, #0xa8]
    2bd8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2bdc:      	add	x8, x8, #0x0
    2be0:      	ldp	x9, x10, [x8, #0x20]
    2be4:      	stp	x9, x10, [sp, #0x90]
    2be8:      	ldr	x9, [x8, #0x30]
    2bec:      	str	x9, [sp, #0xa0]
    2bf0:      	ldp	x9, x10, [x8]
    2bf4:      	stp	x9, x10, [sp, #0x70]
    2bf8:      	add	x10, sp, #0x70
    2bfc:      	ldp	x8, x9, [x8, #0x10]
    2c00:      	stp	x8, x9, [sp, #0x80]
    2c04:      	mov	w8, #0x3c               // =60
    2c08:      	mov	w9, #0x6                // =6
    2c0c:      	blr	x9
    2c10:      	b	0x24d4 <kprobe_unwind_v8+0x24d4>
    2c14:      	cmp	w29, #0x7
    2c18:      	b.eq	0x3058 <kprobe_unwind_v8+0x3058>
    2c1c:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    2c20:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2c24:      	add	x8, x8, #0x0
    2c28:      	add	x0, sp, #0x70
    2c2c:      	ldp	x9, x10, [x8, #0x10]
    2c30:      	mov	w1, #0x2e               // =46
    2c34:      	stp	x9, x10, [sp, #0x80]
    2c38:      	ldr	x9, [x8, #0x20]
    2c3c:      	add	x10, sp, #0x70
    2c40:      	str	x9, [sp, #0x90]
    2c44:      	ldur	x9, [x8, #0x26]
    2c48:      	stur	x9, [sp, #0x96]
    2c4c:      	ldp	x9, x8, [x8]
    2c50:      	stp	x9, x8, [sp, #0x70]
    2c54:      	mov	w8, #0x2e               // =46
    2c58:      	mov	w9, #0x6                // =6
    2c5c:      	ldr	w2, [sp, #0xbc]
    2c60:      	blr	x9
    2c64:      	b	0x2430 <kprobe_unwind_v8+0x2430>
    2c68:      	add	x10, x25, x10
    2c6c:      	str	x10, [sp, #0x38]
    2c70:      	ldr	x10, [sp, #0x48]
    2c74:      	ldr	w9, [x10, x9]
    2c78:      	ldr	w8, [x10, x8]
    2c7c:      	str	w9, [sp, #0x20]
    2c80:      	ldrb	w9, [x23, #0x18]
    2c84:      	str	x8, [sp, #0x28]
    2c88:      	str	w9, [sp, #0x10]
    2c8c:      	ldrb	w9, [x23, #0x17]
    2c90:      	str	x9, [sp, #0x18]
    2c94:      	ldr	x9, [sp, #0x38]
    2c98:      	add	x8, x9, x8
    2c9c:      	str	x8, [sp, #0x30]
    2ca0:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2ca4:      	ldr	x8, [x8]
    2ca8:      	ldr	w8, [x8]
    2cac:      	cbnz	w8, 0x3840 <kprobe_unwind_v8+0x3840>
    2cb0:      	ldr	x8, [sp, #0x38]
    2cb4:      	subs	x8, x24, x8
    2cb8:      	b.lo	0x2d00 <kprobe_unwind_v8+0x2d00>
    2cbc:      	ldr	x9, [sp, #0x30]
    2cc0:      	cmp	x24, x9
    2cc4:      	b.hs	0x2d00 <kprobe_unwind_v8+0x2d00>
    2cc8:      	ldr	w9, [sp, #0x20]
    2ccc:      	ldr	w10, [sp, #0x10]
    2cd0:      	orr	x11, x29, #0x4
    2cd4:      	orr	x12, x25, #0x3
    2cd8:      	and	w9, w9, w10
    2cdc:      	ldr	x10, [sp, #0x18]
    2ce0:      	lsr	w9, w9, w10
    2ce4:      	ldrb	w10, [x23, #0x19]
    2ce8:      	cmp	w9, w10
    2cec:      	ldr	x10, [sp, #0x28]
    2cf0:      	csel	x22, x11, x12, eq
    2cf4:      	orr	w9, w9, w10, lsl #4
    2cf8:      	orr	x25, x8, x9, lsl #32
    2cfc:      	b	0x2ba8 <kprobe_unwind_v8+0x2ba8>
    2d00:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2d04:      	ldr	x8, [x8]
    2d08:      	ldr	w8, [x8]
    2d0c:      	cbnz	w8, 0x38dc <kprobe_unwind_v8+0x38dc>
    2d10:      	ldrb	w24, [x21, #0xf20]
    2d14:      	mov	x25, xzr
    2d18:      	b	0x24d4 <kprobe_unwind_v8+0x24d4>
    2d1c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2d20:      	add	x8, x8, #0x0
    2d24:      	add	x0, sp, #0x70
    2d28:      	ldp	x9, x10, [x8]
    2d2c:      	mov	w1, #0x1d               // =29
    2d30:      	mov	x2, x25
    2d34:      	stp	x9, x10, [sp, #0x70]
    2d38:      	ldr	x9, [x8, #0x10]
    2d3c:      	ldur	x8, [x8, #0x15]
    2d40:      	add	x10, sp, #0x70
    2d44:      	str	x9, [sp, #0x80]
    2d48:      	stur	x8, [sp, #0x85]
    2d4c:      	mov	w8, #0x1d               // =29
    2d50:      	mov	w9, #0x6                // =6
    2d54:      	blr	x9
    2d58:      	mov	x22, xzr
    2d5c:      	b	0x2ba8 <kprobe_unwind_v8+0x2ba8>
    2d60:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2d64:      	add	x8, x8, #0x0
    2d68:      	add	x0, sp, #0x70
    2d6c:      	ldp	x9, x10, [x8]
    2d70:      	mov	w1, #0x1f               // =31
    2d74:      	stp	x9, x10, [sp, #0x70]
    2d78:      	ldr	x9, [x8, #0x10]
    2d7c:      	ldur	x8, [x8, #0x17]
    2d80:      	add	x10, sp, #0x70
    2d84:      	str	x9, [sp, #0x80]
    2d88:      	stur	x8, [sp, #0x87]
    2d8c:      	mov	w8, #0x1f               // =31
    2d90:      	mov	w9, #0x6                // =6
    2d94:      	ldr	x2, [x21, #0xed0]
    2d98:      	ldr	x3, [x21, #0xed8]
    2d9c:      	ldr	x4, [x21, #0xee0]
    2da0:      	blr	x9
    2da4:      	b	0x2578 <kprobe_unwind_v8+0x2578>
    2da8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2dac:      	add	x8, x8, #0x0
    2db0:      	strb	wzr, [sp, #0xa0]
    2db4:      	add	x0, sp, #0x70
    2db8:      	ldp	x9, x10, [x8, #0x10]
    2dbc:      	mov	w1, #0x31               // =49
    2dc0:      	stp	x9, x10, [sp, #0x80]
    2dc4:      	ldp	x9, x10, [x8, #0x20]
    2dc8:      	stp	x9, x10, [sp, #0x90]
    2dcc:      	ldp	x9, x8, [x8]
    2dd0:      	add	x10, sp, #0x70
    2dd4:      	stp	x9, x8, [sp, #0x70]
    2dd8:      	mov	w8, #0x31               // =49
    2ddc:      	mov	w9, #0x6                // =6
    2de0:      	ldr	w2, [x21, #0x2c0]
    2de4:      	blr	x9
    2de8:      	ldr	x24, [x21, #0xed0]
    2dec:      	lsr	x8, x24, #56
    2df0:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    2df4:      	b	0x278c <kprobe_unwind_v8+0x278c>
    2df8:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2dfc:      	add	x8, x8, #0x0
    2e00:      	add	x0, sp, #0x70
    2e04:      	ldp	x9, x10, [x8, #0x10]
    2e08:      	mov	w1, #0x2e               // =46
    2e0c:      	stp	x9, x10, [sp, #0x80]
    2e10:      	ldr	x9, [x8, #0x20]
    2e14:      	add	x10, sp, #0x70
    2e18:      	str	x9, [sp, #0x90]
    2e1c:      	ldur	x9, [x8, #0x26]
    2e20:      	stur	x9, [sp, #0x96]
    2e24:      	ldp	x9, x8, [x8]
    2e28:      	stp	x9, x8, [sp, #0x70]
    2e2c:      	mov	w8, #0x2e               // =46
    2e30:      	mov	w9, #0x6                // =6
    2e34:      	ldr	w2, [sp, #0x58]
    2e38:      	blr	x9
    2e3c:      	b	0x25a8 <kprobe_unwind_v8+0x25a8>
    2e40:      	mov	w8, #0x786c             // =30828
    2e44:      	add	x0, sp, #0x70
    2e48:      	mov	w1, #0x1c               // =28
    2e4c:      	mov	x2, x25
    2e50:      	movk	w8, #0xa, lsl #16
    2e54:      	str	w8, [sp, #0x88]
    2e58:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2e5c:      	add	x8, x8, #0x0
    2e60:      	ldp	x9, x10, [x8]
    2e64:      	ldr	x8, [x8, #0x10]
    2e68:      	stp	x9, x10, [sp, #0x70]
    2e6c:      	mov	w9, #0x6                // =6
    2e70:      	str	x8, [sp, #0x80]
    2e74:      	mov	w8, #0x1c               // =28
    2e78:      	add	x10, sp, #0x70
    2e7c:      	blr	x9
    2e80:      	b	0x275c <kprobe_unwind_v8+0x275c>
    2e84:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2e88:      	add	x8, x8, #0x0
    2e8c:      	add	x0, sp, #0x70
    2e90:      	ldp	x9, x10, [x8, #0x10]
    2e94:      	mov	w1, #0x2e               // =46
    2e98:      	mov	x2, x29
    2e9c:      	mov	x3, x25
    2ea0:      	stp	x9, x10, [sp, #0x80]
    2ea4:      	ldr	x9, [x8, #0x20]
    2ea8:      	add	x10, sp, #0x70
    2eac:      	str	x9, [sp, #0x90]
    2eb0:      	ldur	x9, [x8, #0x26]
    2eb4:      	stur	x9, [sp, #0x96]
    2eb8:      	ldp	x9, x8, [x8]
    2ebc:      	stp	x9, x8, [sp, #0x70]
    2ec0:      	mov	w8, #0x2e               // =46
    2ec4:      	mov	w9, #0x6                // =6
    2ec8:      	blr	x9
    2ecc:      	b	0x2b5c <kprobe_unwind_v8+0x2b5c>
    2ed0:      	mov	w8, #0xa                // =10
    2ed4:      	add	x0, sp, #0x70
    2ed8:      	mov	w1, #0x32               // =50
    2edc:      	strh	w8, [sp, #0xa0]
    2ee0:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2ee4:      	add	x8, x8, #0x0
    2ee8:      	mov	x2, x24
    2eec:      	ldp	x9, x10, [x8, #0x10]
    2ef0:      	mov	w4, w29
    2ef4:      	stp	x9, x10, [sp, #0x80]
    2ef8:      	ldp	x9, x10, [x8, #0x20]
    2efc:      	stp	x9, x10, [sp, #0x90]
    2f00:      	ldp	x9, x8, [x8]
    2f04:      	add	x10, sp, #0x70
    2f08:      	stp	x9, x8, [sp, #0x70]
    2f0c:      	mov	w8, #0x32               // =50
    2f10:      	mov	w9, #0x6                // =6
    2f14:      	ldr	x3, [x21, #0xf00]
    2f18:      	blr	x9
    2f1c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2f20:      	ldr	x8, [x8]
    2f24:      	ldr	w8, [x8]
    2f28:      	cbz	w8, 0x27f8 <kprobe_unwind_v8+0x27f8>
    2f2c:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2f30:      	add	x8, x8, #0x0
    2f34:      	add	x0, sp, #0x70
    2f38:      	ldp	x9, x10, [x8, #0x10]
    2f3c:      	mov	w1, #0x2f               // =47
    2f40:      	stp	x9, x10, [sp, #0x80]
    2f44:      	ldr	x9, [x8, #0x20]
    2f48:      	add	x10, sp, #0x70
    2f4c:      	str	x9, [sp, #0x90]
    2f50:      	ldur	x9, [x8, #0x27]
    2f54:      	stur	x9, [sp, #0x97]
    2f58:      	ldp	x9, x8, [x8]
    2f5c:      	stp	x9, x8, [sp, #0x70]
    2f60:      	mov	w8, #0x2f               // =47
    2f64:      	mov	w9, #0x6                // =6
    2f68:      	ldr	x2, [x21, #0xf10]
    2f6c:      	ldr	x3, [x21, #0xf08]
    2f70:      	blr	x9
    2f74:      	b	0x27f8 <kprobe_unwind_v8+0x27f8>
    2f78:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2f7c:      	add	x8, x8, #0x0
    2f80:      	add	x0, sp, #0x70
    2f84:      	ldp	x9, x10, [x8, #0x10]
    2f88:      	mov	w1, #0x2e               // =46
    2f8c:      	stp	x9, x10, [sp, #0x80]
    2f90:      	ldr	x9, [x8, #0x20]
    2f94:      	add	x10, sp, #0x70
    2f98:      	str	x9, [sp, #0x90]
    2f9c:      	ldur	x9, [x8, #0x26]
    2fa0:      	stur	x9, [sp, #0x96]
    2fa4:      	ldp	x9, x8, [x8]
    2fa8:      	stp	x9, x8, [sp, #0x70]
    2fac:      	mov	w8, #0x2e               // =46
    2fb0:      	mov	w9, #0x6                // =6
    2fb4:      	ldr	w2, [sp, #0x58]
    2fb8:      	blr	x9
    2fbc:      	b	0x2ba4 <kprobe_unwind_v8+0x2ba4>
    2fc0:      	adrp	x8, 0x2000 <kprobe_unwind_v8+0x2000>
    2fc4:      	add	x8, x8, #0x0
    2fc8:      	add	x0, sp, #0x70
    2fcc:      	ldp	x9, x10, [x8]
    2fd0:      	mov	w1, #0x1e               // =30
    2fd4:      	stp	x9, x10, [sp, #0x70]
    2fd8:      	ldr	x9, [x8, #0x10]
    2fdc:      	ldur	x8, [x8, #0x16]
    2fe0:      	add	x10, sp, #0x70
    2fe4:      	str	x9, [sp, #0x80]
    2fe8:      	stur	x8, [sp, #0x86]
    2fec:      	mov	w8, #0x1e               // =30
    2ff0:      	mov	w9, #0x6                // =6
    2ff4:      	ldrh	w2, [x24, #0x20]
    2ff8:      	blr	x9
    2ffc:      	ldrh	w8, [x24, #0x20]
    3000:      	ldr	w9, [x21, #0x1370]
    3004:      	lsr	w8, w9, w8
    3008:      	tbnz	w8, #0x0, 0x2880 <kprobe_unwind_v8+0x2880>
    300c:      	str	wzr, [sp, #0xbc]
    3010:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    3014:      	mov	w8, #0x1                // =1
    3018:      	add	x9, sp, #0xbc
    301c:      	ldr	x0, [x0]
    3020:      	add	x1, sp, #0xbc
    3024:      	blr	x8
    3028:      	cbz	x0, 0x303c <kprobe_unwind_v8+0x303c>
    302c:      	ldr	x8, [x0]
    3030:      	add	x8, x8, #0x1
    3034:      	str	x8, [x0]
    3038:      	b	0x304c <kprobe_unwind_v8+0x304c>
    303c:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3040:      	ldr	x8, [x8]
    3044:      	ldr	w8, [x8]
    3048:      	cbnz	w8, 0x3918 <kprobe_unwind_v8+0x3918>
    304c:      	ldrh	w29, [x24, #0x20]
    3050:      	cmp	w29, #0x7
    3054:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    3058:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    305c:      	ldr	x29, [x21, #0xed8]
    3060:      	ldr	x25, [x21, #0xee0]
    3064:      	ldr	x24, [x21, #0xed0]
    3068:      	ldr	x8, [x8]
    306c:      	ldr	w8, [x8]
    3070:      	cbnz	w8, 0x3670 <kprobe_unwind_v8+0x3670>
    3074:      	cmp	x25, x29
    3078:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    307c:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    3080:      	cmp	x25, x8
    3084:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    3088:      	ldr	x0, [sp, #0x50]
    308c:      	sub	x2, x25, #0x40
    3090:      	mov	w8, #0x40               // =64
    3094:      	mov	w9, #0x70               // =112
    3098:      	mov	w1, #0x40               // =64
    309c:      	blr	x9
    30a0:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    30a4:      	ldrb	w9, [x23, #0x14]
    30a8:      	cmp	x9, #0x38
    30ac:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    30b0:      	ldrb	w8, [x23, #0x15]
    30b4:      	cmp	x8, #0x38
    30b8:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    30bc:      	ldrb	w10, [x23, #0x16]
    30c0:      	cmp	x10, #0x38
    30c4:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    30c8:      	ldr	x11, [sp, #0x50]
    30cc:      	ldr	x9, [x11, x9]
    30d0:      	tbnz	w9, #0x0, 0x31d4 <kprobe_unwind_v8+0x31d4>
    30d4:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    30d8:      	lsr	x25, x9, #1
    30dc:      	ldr	x8, [x8]
    30e0:      	ldr	w8, [x8]
    30e4:      	cbnz	w8, 0x3960 <kprobe_unwind_v8+0x3960>
    30e8:      	ldrb	w24, [x21, #0xf20]
    30ec:      	mov	x22, xzr
    30f0:      	ldr	w8, [x21, #0x2c0]
    30f4:      	cmp	w8, #0x7e
    30f8:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    30fc:      	add	w9, w8, #0x1
    3100:      	mov	w10, #0x8               // =8
    3104:      	add	x11, sp, #0x70
    3108:      	str	w9, [x21, #0x2c0]
    310c:      	mov	w9, #0x18               // =24
    3110:      	add	x0, sp, #0x70
    3114:      	mov	w1, #0x10               // =16
    3118:      	umaddl	x8, w8, w9, x21
    311c:      	add	x9, x8, #0x2d0
    3120:      	str	x22, [x8, #0x2d0]
    3124:      	str	x25, [x8, #0x2d8]
    3128:      	strb	w10, [x8, #0x2e0]
    312c:      	strb	w24, [x8, #0x2e1]
    3130:      	strh	wzr, [x8, #0x2e6]
    3134:      	mov	w10, #0x70              // =112
    3138:      	stur	wzr, [x9, #0x12]
    313c:      	mov	w9, #0x10               // =16
    3140:      	ldr	x8, [x21, #0xee0]
    3144:      	ldr	x2, [x21, #0xee0]
    3148:      	blr	x10
    314c:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    3150:      	ldr	x8, [x21, #0xee0]
    3154:      	add	x9, x8, #0x10
    3158:      	str	x9, [x21, #0xed8]
    315c:      	ldp	x9, x10, [sp, #0x70]
    3160:      	str	x9, [x21, #0xee0]
    3164:      	mov	w9, #0x101              // =257
    3168:      	str	x10, [x21, #0xed0]
    316c:      	strh	w9, [x21, #0xf20]
    3170:      	cbnz	x22, 0x3184 <kprobe_unwind_v8+0x3184>
    3174:      	cmp	x25, #0x1
    3178:      	b.ne	0x3184 <kprobe_unwind_v8+0x3184>
    317c:      	add	x8, x8, #0xa0
    3180:      	str	x8, [x21, #0xed8]
    3184:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3188:      	ldr	x8, [x8]
    318c:      	ldr	w8, [x8]
    3190:      	cbnz	w8, 0x39a4 <kprobe_unwind_v8+0x39a4>
    3194:      	mov	w8, #0x38               // =56
    3198:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    319c:      	add	x9, sp, #0x58
    31a0:      	str	w8, [sp, #0x58]
    31a4:      	mov	w8, #0x1                // =1
    31a8:      	add	x1, sp, #0x58
    31ac:      	ldr	x0, [x0]
    31b0:      	blr	x8
    31b4:      	cbz	x0, 0x3384 <kprobe_unwind_v8+0x3384>
    31b8:      	ldr	x8, [x0]
    31bc:      	add	x8, x8, #0x1
    31c0:      	str	x8, [x0]
    31c4:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    31c8:      	ldr	x8, [x8]
    31cc:      	ldr	w8, [x8]
    31d0:      	b	0x3394 <kprobe_unwind_v8+0x3394>
    31d4:      	ldr	x9, [sp, #0x50]
    31d8:      	ldr	x8, [x9, x8]
    31dc:      	ldr	x22, [x9, x10]
    31e0:      	and	x9, x8, #0x3
    31e4:      	and	x8, x8, #0xfffffffffffffffc
    31e8:      	cmp	x9, #0x1
    31ec:      	csel	x29, x8, xzr, eq
    31f0:      	cbz	x29, 0x3268 <kprobe_unwind_v8+0x3268>
    31f4:      	ldrb	w8, [x23, #0xc]
    31f8:      	mov	w9, #0x70               // =112
    31fc:      	add	x10, sp, #0x70
    3200:      	add	x0, sp, #0x70
    3204:      	mov	w1, #0x8                // =8
    3208:      	add	x2, x29, x8
    320c:      	mov	w8, #0x8                // =8
    3210:      	blr	x9
    3214:      	cbnz	x0, 0x3268 <kprobe_unwind_v8+0x3268>
    3218:      	ldr	x8, [sp, #0x70]
    321c:      	and	x9, x8, #0x3
    3220:      	cmp	x9, #0x1
    3224:      	b.ne	0x3268 <kprobe_unwind_v8+0x3268>
    3228:      	and	x8, x8, #0xfffffffffffffffc
    322c:      	cbz	x8, 0x326c <kprobe_unwind_v8+0x326c>
    3230:      	ldrb	w9, [x23, #0xd]
    3234:      	mov	w10, #0x2               // =2
    3238:      	mov	w11, #0x70              // =112
    323c:      	add	x12, sp, #0x70
    3240:      	add	x0, sp, #0x70
    3244:      	mov	w1, #0x2                // =2
    3248:      	add	x9, x8, x9
    324c:      	ldrb	w9, [x23, #0xd]
    3250:      	add	x2, x8, x9
    3254:      	blr	x11
    3258:      	ldrh	w8, [sp, #0x70]
    325c:      	cmp	x0, #0x0
    3260:      	csel	w8, w8, wzr, eq
    3264:      	b	0x326c <kprobe_unwind_v8+0x326c>
    3268:      	mov	w8, wzr
    326c:      	ldrh	w9, [x23, #0x4]
    3270:      	cmp	w9, w8, uxth
    3274:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    3278:      	ldrh	w9, [x23, #0x6]
    327c:      	cmp	w9, w8, uxth
    3280:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    3284:      	ldrb	w8, [x23, #0xf]
    3288:      	mov	w9, #0x70               // =112
    328c:      	add	x10, sp, #0x70
    3290:      	add	x0, sp, #0x70
    3294:      	mov	w1, #0x8                // =8
    3298:      	add	x2, x29, x8
    329c:      	mov	w8, #0x8                // =8
    32a0:      	blr	x9
    32a4:      	cbnz	x0, 0x3348 <kprobe_unwind_v8+0x3348>
    32a8:      	ldr	x8, [sp, #0x70]
    32ac:      	and	x9, x8, #0x3
    32b0:      	cmp	x9, #0x1
    32b4:      	b.ne	0x3348 <kprobe_unwind_v8+0x3348>
    32b8:      	and	x8, x8, #0xfffffffffffffffc
    32bc:      	str	x8, [sp, #0x40]
    32c0:      	cbz	x8, 0x37e0 <kprobe_unwind_v8+0x37e0>
    32c4:      	ldrb	w8, [x23, #0xc]
    32c8:      	ldr	x9, [sp, #0x40]
    32cc:      	add	x10, sp, #0x70
    32d0:      	add	x0, sp, #0x70
    32d4:      	mov	w1, #0x8                // =8
    32d8:      	add	x2, x9, x8
    32dc:      	mov	w8, #0x8                // =8
    32e0:      	mov	w9, #0x70               // =112
    32e4:      	blr	x9
    32e8:      	cbnz	x0, 0x334c <kprobe_unwind_v8+0x334c>
    32ec:      	ldr	x8, [sp, #0x70]
    32f0:      	and	x9, x8, #0x3
    32f4:      	cmp	x9, #0x1
    32f8:      	b.ne	0x334c <kprobe_unwind_v8+0x334c>
    32fc:      	and	x8, x8, #0xfffffffffffffffc
    3300:      	cbz	x8, 0x3350 <kprobe_unwind_v8+0x3350>
    3304:      	ldrb	w9, [x23, #0xd]
    3308:      	mov	w10, #0x2               // =2
    330c:      	mov	w11, #0x70              // =112
    3310:      	add	x12, sp, #0x70
    3314:      	add	x0, sp, #0x70
    3318:      	mov	w1, #0x2                // =2
    331c:      	add	x9, x8, x9
    3320:      	ldrb	w9, [x23, #0xd]
    3324:      	add	x2, x8, x9
    3328:      	blr	x11
    332c:      	ldrh	w8, [sp, #0x70]
    3330:      	cmp	x0, #0x0
    3334:      	csel	w8, w8, wzr, eq
    3338:      	ldrh	w9, [x23, #0xa]
    333c:      	cmp	w9, w8, uxth
    3340:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    3344:      	b	0x335c <kprobe_unwind_v8+0x335c>
    3348:      	str	xzr, [sp, #0x40]
    334c:      	mov	w8, wzr
    3350:      	ldrh	w9, [x23, #0xa]
    3354:      	cmp	w9, w8, uxth
    3358:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    335c:      	lsr	x25, x22, #32
    3360:      	cbz	x25, 0x3594 <kprobe_unwind_v8+0x3594>
    3364:      	tbnz	w22, #0x0, 0x3594 <kprobe_unwind_v8+0x3594>
    3368:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    336c:      	ldr	x8, [x8]
    3370:      	ldr	w8, [x8]
    3374:      	cbnz	w8, 0x39ec <kprobe_unwind_v8+0x39ec>
    3378:      	ldr	x8, [sp, #0x40]
    337c:      	orr	x22, x8, #0x1
    3380:      	b	0x4048 <kprobe_unwind_v8+0x4048>
    3384:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3388:      	ldr	x8, [x8]
    338c:      	ldr	w8, [x8]
    3390:      	cbnz	w8, 0x3a30 <kprobe_unwind_v8+0x3a30>
    3394:      	ldr	x24, [x21, #0xed0]
    3398:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    339c:      	cbnz	w8, 0x3a78 <kprobe_unwind_v8+0x3a78>
    33a0:      	lsr	x8, x24, #56
    33a4:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    33a8:      	cmp	x24, #0x1, lsl #12      // =0x1000
    33ac:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    33b0:      	ldr	w8, [x21]
    33b4:      	mov	w9, #0x60               // =96
    33b8:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    33bc:      	add	x1, sp, #0x58
    33c0:      	rev	w8, w8
    33c4:      	stp	w9, w8, [sp, #0x58]
    33c8:      	rev	x8, x24
    33cc:      	add	x9, sp, #0x58
    33d0:      	str	x8, [sp, #0x60]
    33d4:      	mov	w8, #0x1                // =1
    33d8:      	ldr	x0, [x0]
    33dc:      	blr	x8
    33e0:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    33e4:      	ldr	x8, [x0, #0x8]
    33e8:      	and	x9, x8, #0xffffffffffffff
    33ec:      	lsr	x29, x8, #56
    33f0:      	str	x9, [x21, #0xf10]
    33f4:      	ldr	x8, [x0]
    33f8:      	str	x8, [x21, #0xf00]
    33fc:      	sub	x8, x24, x9
    3400:      	str	x8, [x21, #0xf08]
    3404:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3408:      	ldr	x8, [x8]
    340c:      	ldr	w8, [x8]
    3410:      	cbz	w8, 0x34b8 <kprobe_unwind_v8+0x34b8>
    3414:      	mov	w8, #0xa                // =10
    3418:      	add	x0, sp, #0x70
    341c:      	mov	w1, #0x32               // =50
    3420:      	strh	w8, [sp, #0xa0]
    3424:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3428:      	add	x8, x8, #0x0
    342c:      	mov	x2, x24
    3430:      	ldp	x9, x10, [x8, #0x10]
    3434:      	mov	w4, w29
    3438:      	stp	x9, x10, [sp, #0x80]
    343c:      	ldp	x9, x10, [x8, #0x20]
    3440:      	stp	x9, x10, [sp, #0x90]
    3444:      	ldp	x9, x8, [x8]
    3448:      	add	x10, sp, #0x70
    344c:      	stp	x9, x8, [sp, #0x70]
    3450:      	mov	w8, #0x32               // =50
    3454:      	mov	w9, #0x6                // =6
    3458:      	ldr	x3, [x21, #0xf00]
    345c:      	blr	x9
    3460:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3464:      	ldr	x8, [x8]
    3468:      	ldr	w8, [x8]
    346c:      	cbz	w8, 0x34b8 <kprobe_unwind_v8+0x34b8>
    3470:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3474:      	add	x8, x8, #0x0
    3478:      	add	x0, sp, #0x70
    347c:      	ldp	x9, x10, [x8, #0x10]
    3480:      	mov	w1, #0x2f               // =47
    3484:      	stp	x9, x10, [sp, #0x80]
    3488:      	ldr	x9, [x8, #0x20]
    348c:      	add	x10, sp, #0x70
    3490:      	str	x9, [sp, #0x90]
    3494:      	ldur	x9, [x8, #0x27]
    3498:      	stur	x9, [sp, #0x97]
    349c:      	ldp	x9, x8, [x8]
    34a0:      	stp	x9, x8, [sp, #0x70]
    34a4:      	mov	w8, #0x2f               // =47
    34a8:      	mov	w9, #0x6                // =6
    34ac:      	ldr	x2, [x21, #0xf10]
    34b0:      	ldr	x3, [x21, #0xf08]
    34b4:      	blr	x9
    34b8:      	cmp	w29, #0x1
    34bc:      	b.ne	0x3c20 <kprobe_unwind_v8+0x3c20>
    34c0:      	ldr	x8, [x21, #0xf00]
    34c4:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    34c8:      	ldr	x25, [x21, #0xf08]
    34cc:      	mov	w9, #0x1                // =1
    34d0:      	add	x1, sp, #0x58
    34d4:      	mov	w29, #0x1               // =1
    34d8:      	str	x8, [sp, #0x58]
    34dc:      	add	x8, sp, #0x58
    34e0:      	ldr	x0, [x0]
    34e4:      	blr	x9
    34e8:      	cbz	x0, 0x3ac8 <kprobe_unwind_v8+0x3ac8>
    34ec:      	ldr	x8, [x0]
    34f0:      	mov	x24, x0
    34f4:      	cmp	x8, x25
    34f8:      	b.hi	0x3508 <kprobe_unwind_v8+0x3508>
    34fc:      	ldr	x8, [x24, #0x8]
    3500:      	cmp	x8, x25
    3504:      	b.hs	0x3520 <kprobe_unwind_v8+0x3520>
    3508:      	ldr	x8, [x24, #0x10]
    350c:      	cmp	x8, x25
    3510:      	b.hi	0x358c <kprobe_unwind_v8+0x358c>
    3514:      	ldr	x8, [x24, #0x18]
    3518:      	cmp	x8, x25
    351c:      	b.lo	0x358c <kprobe_unwind_v8+0x358c>
    3520:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3524:      	ldr	x8, [x8]
    3528:      	ldr	w8, [x8]
    352c:      	cbz	w8, 0x356c <kprobe_unwind_v8+0x356c>
    3530:      	adrp	x10, 0x3000 <kprobe_unwind_v8+0x3000>
    3534:      	add	x10, x10, #0x0
    3538:      	add	x0, sp, #0x70
    353c:      	ldp	x8, x9, [x10]
    3540:      	mov	w1, #0x1e               // =30
    3544:      	stp	x8, x9, [sp, #0x70]
    3548:      	ldr	x8, [x10, #0x10]
    354c:      	mov	w9, #0x6                // =6
    3550:      	str	x8, [sp, #0x80]
    3554:      	ldur	x8, [x10, #0x16]
    3558:      	add	x10, sp, #0x70
    355c:      	stur	x8, [sp, #0x86]
    3560:      	mov	w8, #0x1e               // =30
    3564:      	ldrh	w2, [x24, #0x20]
    3568:      	blr	x9
    356c:      	ldrh	w8, [x24, #0x20]
    3570:      	ldr	w9, [x21, #0x1370]
    3574:      	lsr	w8, w9, w8
    3578:      	tbz	w8, #0x0, 0x3acc <kprobe_unwind_v8+0x3acc>
    357c:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3580:      	ldr	x8, [x8]
    3584:      	ldr	w8, [x8]
    3588:      	cbnz	w8, 0x3afc <kprobe_unwind_v8+0x3afc>
    358c:      	mov	w29, #0x1               // =1
    3590:      	b	0x3c20 <kprobe_unwind_v8+0x3c20>
    3594:      	ldr	x8, [sp, #0x40]
    3598:      	mov	w9, #0x70               // =112
    359c:      	add	x10, sp, #0x70
    35a0:      	add	x0, sp, #0x70
    35a4:      	mov	w1, #0x8                // =8
    35a8:      	orr	x22, x8, #0x2
    35ac:      	ldrb	w8, [x23, #0xe]
    35b0:      	add	x2, x29, x8
    35b4:      	mov	w8, #0x8                // =8
    35b8:      	blr	x9
    35bc:      	cbz	x0, 0x3750 <kprobe_unwind_v8+0x3750>
    35c0:      	mov	x25, xzr
    35c4:      	mov	w8, wzr
    35c8:      	and	w4, w8, #0xffff
    35cc:      	ldrh	w8, [x23, #0x8]
    35d0:      	cmp	w4, w8
    35d4:      	b.ne	0x36c0 <kprobe_unwind_v8+0x36c0>
    35d8:      	ldr	x0, [sp, #0x48]
    35dc:      	mov	w8, #0x60               // =96
    35e0:      	mov	w9, #0x70               // =112
    35e4:      	mov	x2, x25
    35e8:      	mov	w1, #0x60               // =96
    35ec:      	blr	x9
    35f0:      	cbz	x0, 0x3b40 <kprobe_unwind_v8+0x3b40>
    35f4:      	mov	w8, #0x3b               // =59
    35f8:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    35fc:      	add	x9, sp, #0x58
    3600:      	str	w8, [sp, #0x58]
    3604:      	mov	w8, #0x1                // =1
    3608:      	add	x1, sp, #0x58
    360c:      	ldr	x0, [x0]
    3610:      	blr	x8
    3614:      	cbnz	x0, 0x373c <kprobe_unwind_v8+0x373c>
    3618:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    361c:      	ldr	x8, [x8]
    3620:      	ldr	w8, [x8]
    3624:      	cbz	w8, 0x4044 <kprobe_unwind_v8+0x4044>
    3628:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    362c:      	add	x8, x8, #0x0
    3630:      	add	x0, sp, #0x70
    3634:      	ldp	x9, x10, [x8, #0x10]
    3638:      	mov	w1, #0x2e               // =46
    363c:      	stp	x9, x10, [sp, #0x80]
    3640:      	ldr	x9, [x8, #0x20]
    3644:      	add	x10, sp, #0x70
    3648:      	str	x9, [sp, #0x90]
    364c:      	ldur	x9, [x8, #0x26]
    3650:      	stur	x9, [sp, #0x96]
    3654:      	ldp	x9, x8, [x8]
    3658:      	stp	x9, x8, [sp, #0x70]
    365c:      	mov	w8, #0x2e               // =46
    3660:      	mov	w9, #0x6                // =6
    3664:      	ldr	w2, [sp, #0x58]
    3668:      	blr	x9
    366c:      	b	0x4044 <kprobe_unwind_v8+0x4044>
    3670:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3674:      	add	x8, x8, #0x0
    3678:      	add	x0, sp, #0x70
    367c:      	ldp	x9, x10, [x8]
    3680:      	mov	w1, #0x1f               // =31
    3684:      	mov	x2, x24
    3688:      	mov	x3, x29
    368c:      	stp	x9, x10, [sp, #0x70]
    3690:      	ldr	x9, [x8, #0x10]
    3694:      	ldur	x8, [x8, #0x17]
    3698:      	add	x10, sp, #0x70
    369c:      	mov	x4, x25
    36a0:      	str	x9, [sp, #0x80]
    36a4:      	stur	x8, [sp, #0x87]
    36a8:      	mov	w8, #0x1f               // =31
    36ac:      	mov	w9, #0x6                // =6
    36b0:      	blr	x9
    36b4:      	cmp	x25, x29
    36b8:      	b.hs	0x307c <kprobe_unwind_v8+0x307c>
    36bc:      	b	0x1954 <kprobe_unwind_v8+0x1954>
    36c0:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    36c4:      	ldr	x8, [x8]
    36c8:      	ldr	w8, [x8]
    36cc:      	cbz	w8, 0x3718 <kprobe_unwind_v8+0x3718>
    36d0:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    36d4:      	add	x8, x8, #0x0
    36d8:      	add	x0, sp, #0x70
    36dc:      	ldp	x9, x10, [x8, #0x10]
    36e0:      	mov	w1, #0x2e               // =46
    36e4:      	mov	x2, x29
    36e8:      	mov	x3, x25
    36ec:      	stp	x9, x10, [sp, #0x80]
    36f0:      	ldr	x9, [x8, #0x20]
    36f4:      	add	x10, sp, #0x70
    36f8:      	str	x9, [sp, #0x90]
    36fc:      	ldur	x9, [x8, #0x26]
    3700:      	stur	x9, [sp, #0x96]
    3704:      	ldp	x9, x8, [x8]
    3708:      	stp	x9, x8, [sp, #0x70]
    370c:      	mov	w8, #0x2e               // =46
    3710:      	mov	w9, #0x6                // =6
    3714:      	blr	x9
    3718:      	mov	w8, #0x3b               // =59
    371c:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    3720:      	add	x9, sp, #0x58
    3724:      	str	w8, [sp, #0x58]
    3728:      	mov	w8, #0x1                // =1
    372c:      	add	x1, sp, #0x58
    3730:      	ldr	x0, [x0]
    3734:      	blr	x8
    3738:      	cbz	x0, 0x3b70 <kprobe_unwind_v8+0x3b70>
    373c:      	ldr	x8, [x0]
    3740:      	mov	x25, xzr
    3744:      	add	x8, x8, #0x1
    3748:      	str	x8, [x0]
    374c:      	b	0x4048 <kprobe_unwind_v8+0x4048>
    3750:      	ldr	x8, [sp, #0x70]
    3754:      	and	x9, x8, #0x3
    3758:      	cmp	x9, #0x1
    375c:      	b.ne	0x35c0 <kprobe_unwind_v8+0x35c0>
    3760:      	and	x8, x8, #0xfffffffffffffffc
    3764:      	mov	x25, x8
    3768:      	cbz	x8, 0x35c8 <kprobe_unwind_v8+0x35c8>
    376c:      	ldrb	w8, [x23, #0xc]
    3770:      	mov	w9, #0x70               // =112
    3774:      	add	x10, sp, #0x70
    3778:      	add	x0, sp, #0x70
    377c:      	mov	w1, #0x8                // =8
    3780:      	add	x2, x25, x8
    3784:      	mov	w8, #0x8                // =8
    3788:      	blr	x9
    378c:      	cbnz	x0, 0x35c4 <kprobe_unwind_v8+0x35c4>
    3790:      	ldr	x8, [sp, #0x70]
    3794:      	and	x9, x8, #0x3
    3798:      	cmp	x9, #0x1
    379c:      	b.ne	0x35c4 <kprobe_unwind_v8+0x35c4>
    37a0:      	and	x8, x8, #0xfffffffffffffffc
    37a4:      	cbz	x8, 0x35c8 <kprobe_unwind_v8+0x35c8>
    37a8:      	ldrb	w9, [x23, #0xd]
    37ac:      	mov	w10, #0x2               // =2
    37b0:      	mov	w11, #0x70              // =112
    37b4:      	add	x12, sp, #0x70
    37b8:      	add	x0, sp, #0x70
    37bc:      	mov	w1, #0x2                // =2
    37c0:      	add	x9, x8, x9
    37c4:      	ldrb	w9, [x23, #0xd]
    37c8:      	add	x2, x8, x9
    37cc:      	blr	x11
    37d0:      	ldrh	w8, [sp, #0x70]
    37d4:      	cmp	x0, #0x0
    37d8:      	csel	w8, w8, wzr, eq
    37dc:      	b	0x35c8 <kprobe_unwind_v8+0x35c8>
    37e0:      	str	xzr, [sp, #0x40]
    37e4:      	ldrh	w9, [x23, #0xa]
    37e8:      	cmp	w9, w8, uxth
    37ec:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    37f0:      	b	0x335c <kprobe_unwind_v8+0x335c>
    37f4:      	mov	w8, #0x656e             // =25966
    37f8:      	add	x0, sp, #0x70
    37fc:      	mov	w1, #0x1b               // =27
    3800:      	movk	w8, #0xa, lsl #16
    3804:      	stur	w8, [sp, #0x87]
    3808:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    380c:      	add	x8, x8, #0x0
    3810:      	ldp	x9, x10, [x8]
    3814:      	ldr	x8, [x8, #0x10]
    3818:      	stp	x9, x10, [sp, #0x70]
    381c:      	str	x8, [sp, #0x80]
    3820:      	mov	w8, #0x1b               // =27
    3824:      	mov	w9, #0x6                // =6
    3828:      	add	x10, sp, #0x70
    382c:      	blr	x9
    3830:      	mov	w29, #0x1               // =1
    3834:      	cmp	w29, #0x7
    3838:      	b.eq	0x3058 <kprobe_unwind_v8+0x3058>
    383c:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    3840:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3844:      	add	x8, x8, #0x0
    3848:      	strb	wzr, [sp, #0x98]
    384c:      	add	x0, sp, #0x70
    3850:      	ldp	x9, x10, [x8, #0x10]
    3854:      	mov	w1, #0x29               // =41
    3858:      	mov	x2, x29
    385c:      	mov	x4, x25
    3860:      	stp	x9, x10, [sp, #0x80]
    3864:      	ldr	x9, [x8, #0x20]
    3868:      	add	x10, sp, #0x70
    386c:      	str	x9, [sp, #0x90]
    3870:      	ldp	x8, x9, [x8]
    3874:      	stp	x8, x9, [sp, #0x70]
    3878:      	mov	w8, #0x29               // =41
    387c:      	mov	w9, #0x6                // =6
    3880:      	ldr	x3, [sp, #0x40]
    3884:      	blr	x9
    3888:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    388c:      	ldr	x8, [x8]
    3890:      	ldr	w8, [x8]
    3894:      	cbz	w8, 0x2cb0 <kprobe_unwind_v8+0x2cb0>
    3898:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    389c:      	add	x8, x8, #0x0
    38a0:      	add	x0, sp, #0x70
    38a4:      	ldp	x9, x10, [x8, #0x10]
    38a8:      	mov	w1, #0x25               // =37
    38ac:      	stp	x9, x10, [sp, #0x80]
    38b0:      	ldur	x9, [x8, #0x1d]
    38b4:      	add	x10, sp, #0x70
    38b8:      	stur	x9, [sp, #0x8d]
    38bc:      	ldp	x8, x9, [x8]
    38c0:      	stp	x8, x9, [sp, #0x70]
    38c4:      	mov	w8, #0x25               // =37
    38c8:      	mov	w9, #0x6                // =6
    38cc:      	ldp	x3, x2, [sp, #0x30]
    38d0:      	ldr	x4, [sp, #0x28]
    38d4:      	blr	x9
    38d8:      	b	0x2cb0 <kprobe_unwind_v8+0x2cb0>
    38dc:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    38e0:      	add	x8, x8, #0x0
    38e4:      	add	x0, sp, #0x70
    38e8:      	ldp	x9, x10, [x8, #0x10]
    38ec:      	mov	w1, #0x30               // =48
    38f0:      	stp	x9, x10, [sp, #0x80]
    38f4:      	ldp	x9, x10, [x8, #0x20]
    38f8:      	stp	x9, x10, [sp, #0x90]
    38fc:      	ldp	x9, x8, [x8]
    3900:      	add	x10, sp, #0x70
    3904:      	stp	x9, x8, [sp, #0x70]
    3908:      	mov	w8, #0x30               // =48
    390c:      	mov	w9, #0x6                // =6
    3910:      	blr	x9
    3914:      	b	0x2ba4 <kprobe_unwind_v8+0x2ba4>
    3918:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    391c:      	add	x8, x8, #0x0
    3920:      	add	x0, sp, #0x70
    3924:      	ldp	x9, x10, [x8, #0x10]
    3928:      	mov	w1, #0x2e               // =46
    392c:      	stp	x9, x10, [sp, #0x80]
    3930:      	ldr	x9, [x8, #0x20]
    3934:      	add	x10, sp, #0x70
    3938:      	str	x9, [sp, #0x90]
    393c:      	ldur	x9, [x8, #0x26]
    3940:      	stur	x9, [sp, #0x96]
    3944:      	ldp	x9, x8, [x8]
    3948:      	stp	x9, x8, [sp, #0x70]
    394c:      	mov	w8, #0x2e               // =46
    3950:      	mov	w9, #0x6                // =6
    3954:      	ldr	w2, [sp, #0xbc]
    3958:      	blr	x9
    395c:      	b	0x304c <kprobe_unwind_v8+0x304c>
    3960:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3964:      	add	x8, x8, #0x0
    3968:      	add	x0, sp, #0x70
    396c:      	ldp	x9, x10, [x8]
    3970:      	mov	w1, #0x1d               // =29
    3974:      	mov	x2, x25
    3978:      	stp	x9, x10, [sp, #0x70]
    397c:      	ldr	x9, [x8, #0x10]
    3980:      	ldur	x8, [x8, #0x15]
    3984:      	add	x10, sp, #0x70
    3988:      	str	x9, [sp, #0x80]
    398c:      	stur	x8, [sp, #0x85]
    3990:      	mov	w8, #0x1d               // =29
    3994:      	mov	w9, #0x6                // =6
    3998:      	blr	x9
    399c:      	mov	x22, xzr
    39a0:      	b	0x4048 <kprobe_unwind_v8+0x4048>
    39a4:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    39a8:      	add	x8, x8, #0x0
    39ac:      	add	x0, sp, #0x70
    39b0:      	ldp	x9, x10, [x8]
    39b4:      	mov	w1, #0x1f               // =31
    39b8:      	stp	x9, x10, [sp, #0x70]
    39bc:      	ldr	x9, [x8, #0x10]
    39c0:      	ldur	x8, [x8, #0x17]
    39c4:      	add	x10, sp, #0x70
    39c8:      	str	x9, [sp, #0x80]
    39cc:      	stur	x8, [sp, #0x87]
    39d0:      	mov	w8, #0x1f               // =31
    39d4:      	mov	w9, #0x6                // =6
    39d8:      	ldr	x2, [x21, #0xed0]
    39dc:      	ldr	x3, [x21, #0xed8]
    39e0:      	ldr	x4, [x21, #0xee0]
    39e4:      	blr	x9
    39e8:      	b	0x3194 <kprobe_unwind_v8+0x3194>
    39ec:      	mov	w8, #0x786c             // =30828
    39f0:      	add	x0, sp, #0x70
    39f4:      	mov	w1, #0x1c               // =28
    39f8:      	mov	x2, x25
    39fc:      	movk	w8, #0xa, lsl #16
    3a00:      	str	w8, [sp, #0x88]
    3a04:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3a08:      	add	x8, x8, #0x0
    3a0c:      	ldp	x9, x10, [x8]
    3a10:      	ldr	x8, [x8, #0x10]
    3a14:      	stp	x9, x10, [sp, #0x70]
    3a18:      	mov	w9, #0x6                // =6
    3a1c:      	str	x8, [sp, #0x80]
    3a20:      	mov	w8, #0x1c               // =28
    3a24:      	add	x10, sp, #0x70
    3a28:      	blr	x9
    3a2c:      	b	0x3378 <kprobe_unwind_v8+0x3378>
    3a30:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3a34:      	add	x8, x8, #0x0
    3a38:      	add	x0, sp, #0x70
    3a3c:      	ldp	x9, x10, [x8, #0x10]
    3a40:      	mov	w1, #0x2e               // =46
    3a44:      	stp	x9, x10, [sp, #0x80]
    3a48:      	ldr	x9, [x8, #0x20]
    3a4c:      	add	x10, sp, #0x70
    3a50:      	str	x9, [sp, #0x90]
    3a54:      	ldur	x9, [x8, #0x26]
    3a58:      	stur	x9, [sp, #0x96]
    3a5c:      	ldp	x9, x8, [x8]
    3a60:      	stp	x9, x8, [sp, #0x70]
    3a64:      	mov	w8, #0x2e               // =46
    3a68:      	mov	w9, #0x6                // =6
    3a6c:      	ldr	w2, [sp, #0x58]
    3a70:      	blr	x9
    3a74:      	b	0x31c4 <kprobe_unwind_v8+0x31c4>
    3a78:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3a7c:      	add	x8, x8, #0x0
    3a80:      	strb	wzr, [sp, #0xa0]
    3a84:      	add	x0, sp, #0x70
    3a88:      	ldp	x9, x10, [x8, #0x10]
    3a8c:      	mov	w1, #0x31               // =49
    3a90:      	stp	x9, x10, [sp, #0x80]
    3a94:      	ldp	x9, x10, [x8, #0x20]
    3a98:      	stp	x9, x10, [sp, #0x90]
    3a9c:      	ldp	x9, x8, [x8]
    3aa0:      	add	x10, sp, #0x70
    3aa4:      	stp	x9, x8, [sp, #0x70]
    3aa8:      	mov	w8, #0x31               // =49
    3aac:      	mov	w9, #0x6                // =6
    3ab0:      	ldr	w2, [x21, #0x2c0]
    3ab4:      	blr	x9
    3ab8:      	ldr	x24, [x21, #0xed0]
    3abc:      	lsr	x8, x24, #56
    3ac0:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    3ac4:      	b	0x33a8 <kprobe_unwind_v8+0x33a8>
    3ac8:      	b	0x3c20 <kprobe_unwind_v8+0x3c20>
    3acc:      	str	wzr, [sp, #0xbc]
    3ad0:      	adrp	x0, 0x3000 <kprobe_unwind_v8+0x3000>
    3ad4:      	mov	w8, #0x1                // =1
    3ad8:      	add	x9, sp, #0xbc
    3adc:      	ldr	x0, [x0]
    3ae0:      	add	x1, sp, #0xbc
    3ae4:      	blr	x8
    3ae8:      	cbz	x0, 0x3bc8 <kprobe_unwind_v8+0x3bc8>
    3aec:      	ldr	x8, [x0]
    3af0:      	add	x8, x8, #0x1
    3af4:      	str	x8, [x0]
    3af8:      	b	0x3c1c <kprobe_unwind_v8+0x3c1c>
    3afc:      	mov	w8, #0x656e             // =25966
    3b00:      	adrp	x10, 0x3000 <kprobe_unwind_v8+0x3000>
    3b04:      	add	x10, x10, #0x0
    3b08:      	add	x0, sp, #0x70
    3b0c:      	mov	w1, #0x1b               // =27
    3b10:      	movk	w8, #0xa, lsl #16
    3b14:      	stur	w8, [sp, #0x87]
    3b18:      	ldp	x8, x9, [x10]
    3b1c:      	stp	x8, x9, [sp, #0x70]
    3b20:      	ldr	x8, [x10, #0x10]
    3b24:      	mov	w9, #0x6                // =6
    3b28:      	add	x10, sp, #0x70
    3b2c:      	str	x8, [sp, #0x80]
    3b30:      	mov	w8, #0x1b               // =27
    3b34:      	blr	x9
    3b38:      	mov	w29, #0x1               // =1
    3b3c:      	b	0x3c20 <kprobe_unwind_v8+0x3c20>
    3b40:      	ldrb	w8, [x23, #0x12]
    3b44:      	cmp	x8, #0x5c
    3b48:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    3b4c:      	ldrb	w9, [x23, #0x13]
    3b50:      	cmp	x9, #0x5c
    3b54:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    3b58:      	ldrb	w11, [x23, #0x10]
    3b5c:      	ldrb	w10, [x23, #0x11]
    3b60:      	cbz	w11, 0x3d0c <kprobe_unwind_v8+0x3d0c>
    3b64:      	ldr	x11, [sp, #0x48]
    3b68:      	ldr	x10, [x11, x10]
    3b6c:      	b	0x3d10 <kprobe_unwind_v8+0x3d10>
    3b70:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3b74:      	ldr	x8, [x8]
    3b78:      	ldr	w8, [x8]
    3b7c:      	cbz	w8, 0x4044 <kprobe_unwind_v8+0x4044>
    3b80:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3b84:      	add	x8, x8, #0x0
    3b88:      	add	x0, sp, #0x70
    3b8c:      	ldp	x9, x10, [x8, #0x10]
    3b90:      	mov	w1, #0x2e               // =46
    3b94:      	stp	x9, x10, [sp, #0x80]
    3b98:      	ldr	x9, [x8, #0x20]
    3b9c:      	add	x10, sp, #0x70
    3ba0:      	str	x9, [sp, #0x90]
    3ba4:      	ldur	x9, [x8, #0x26]
    3ba8:      	stur	x9, [sp, #0x96]
    3bac:      	ldp	x9, x8, [x8]
    3bb0:      	stp	x9, x8, [sp, #0x70]
    3bb4:      	mov	w8, #0x2e               // =46
    3bb8:      	mov	w9, #0x6                // =6
    3bbc:      	ldr	w2, [sp, #0x58]
    3bc0:      	blr	x9
    3bc4:      	b	0x4044 <kprobe_unwind_v8+0x4044>
    3bc8:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3bcc:      	ldr	x8, [x8]
    3bd0:      	ldr	w8, [x8]
    3bd4:      	cbz	w8, 0x3c1c <kprobe_unwind_v8+0x3c1c>
    3bd8:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3bdc:      	add	x8, x8, #0x0
    3be0:      	add	x0, sp, #0x70
    3be4:      	ldp	x9, x10, [x8, #0x10]
    3be8:      	mov	w1, #0x2e               // =46
    3bec:      	stp	x9, x10, [sp, #0x80]
    3bf0:      	ldr	x9, [x8, #0x20]
    3bf4:      	add	x10, sp, #0x70
    3bf8:      	str	x9, [sp, #0x90]
    3bfc:      	ldur	x9, [x8, #0x26]
    3c00:      	stur	x9, [sp, #0x96]
    3c04:      	ldp	x9, x8, [x8]
    3c08:      	stp	x9, x8, [sp, #0x70]
    3c0c:      	mov	w8, #0x2e               // =46
    3c10:      	mov	w9, #0x6                // =6
    3c14:      	ldr	w2, [sp, #0xbc]
    3c18:      	blr	x9
    3c1c:      	ldrh	w29, [x24, #0x20]
    3c20:      	cmp	w29, #0x7
    3c24:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    3c28:      	ldr	x8, [x21, #0xed0]
    3c2c:      	ldr	x29, [x21, #0xed8]
    3c30:      	ldr	x25, [x21, #0xee0]
    3c34:      	str	x8, [sp, #0x30]
    3c38:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3c3c:      	ldr	x8, [x8]
    3c40:      	ldr	w8, [x8]
    3c44:      	cbz	w8, 0x3c8c <kprobe_unwind_v8+0x3c8c>
    3c48:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3c4c:      	add	x8, x8, #0x0
    3c50:      	add	x0, sp, #0x70
    3c54:      	ldp	x9, x10, [x8]
    3c58:      	mov	w1, #0x1f               // =31
    3c5c:      	mov	x3, x29
    3c60:      	mov	x4, x25
    3c64:      	stp	x9, x10, [sp, #0x70]
    3c68:      	ldr	x9, [x8, #0x10]
    3c6c:      	ldur	x8, [x8, #0x17]
    3c70:      	add	x10, sp, #0x70
    3c74:      	str	x9, [sp, #0x80]
    3c78:      	stur	x8, [sp, #0x87]
    3c7c:      	mov	w8, #0x1f               // =31
    3c80:      	mov	w9, #0x6                // =6
    3c84:      	ldr	x2, [sp, #0x30]
    3c88:      	blr	x9
    3c8c:      	cmp	x25, x29
    3c90:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    3c94:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    3c98:      	cmp	x25, x8
    3c9c:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    3ca0:      	ldr	x0, [sp, #0x50]
    3ca4:      	sub	x2, x25, #0x40
    3ca8:      	mov	w8, #0x40               // =64
    3cac:      	mov	w9, #0x70               // =112
    3cb0:      	mov	w1, #0x40               // =64
    3cb4:      	blr	x9
    3cb8:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    3cbc:      	ldrb	w9, [x23, #0x14]
    3cc0:      	cmp	x9, #0x38
    3cc4:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    3cc8:      	ldrb	w8, [x23, #0x15]
    3ccc:      	cmp	x8, #0x38
    3cd0:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    3cd4:      	ldrb	w10, [x23, #0x16]
    3cd8:      	cmp	x10, #0x38
    3cdc:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    3ce0:      	ldr	x11, [sp, #0x50]
    3ce4:      	ldr	x9, [x11, x9]
    3ce8:      	tbnz	w9, #0x0, 0x3e3c <kprobe_unwind_v8+0x3e3c>
    3cec:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3cf0:      	lsr	x24, x9, #1
    3cf4:      	ldr	x8, [x8]
    3cf8:      	ldr	w8, [x8]
    3cfc:      	cbnz	w8, 0x3ed8 <kprobe_unwind_v8+0x3ed8>
    3d00:      	ldrb	w25, [x21, #0xf20]
    3d04:      	str	xzr, [sp, #0x40]
    3d08:      	b	0x45a0 <kprobe_unwind_v8+0x45a0>
    3d0c:      	add	x10, x25, x10
    3d10:      	str	x10, [sp, #0x38]
    3d14:      	ldr	x10, [sp, #0x48]
    3d18:      	ldr	w9, [x10, x9]
    3d1c:      	ldr	w8, [x10, x8]
    3d20:      	str	w9, [sp, #0x20]
    3d24:      	ldrb	w9, [x23, #0x18]
    3d28:      	str	x8, [sp, #0x30]
    3d2c:      	str	w9, [sp, #0x10]
    3d30:      	ldrb	w9, [x23, #0x17]
    3d34:      	str	x9, [sp, #0x18]
    3d38:      	ldr	x9, [sp, #0x38]
    3d3c:      	add	x8, x9, x8
    3d40:      	str	x8, [sp, #0x28]
    3d44:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3d48:      	ldr	x8, [x8]
    3d4c:      	ldr	w8, [x8]
    3d50:      	cbz	w8, 0x3dec <kprobe_unwind_v8+0x3dec>
    3d54:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3d58:      	add	x8, x8, #0x0
    3d5c:      	strb	wzr, [sp, #0x98]
    3d60:      	add	x0, sp, #0x70
    3d64:      	ldp	x9, x10, [x8, #0x10]
    3d68:      	mov	w1, #0x29               // =41
    3d6c:      	mov	x2, x29
    3d70:      	mov	x4, x25
    3d74:      	stp	x9, x10, [sp, #0x80]
    3d78:      	ldr	x9, [x8, #0x20]
    3d7c:      	add	x10, sp, #0x70
    3d80:      	str	x9, [sp, #0x90]
    3d84:      	ldp	x8, x9, [x8]
    3d88:      	stp	x8, x9, [sp, #0x70]
    3d8c:      	mov	w8, #0x29               // =41
    3d90:      	mov	w9, #0x6                // =6
    3d94:      	ldr	x3, [sp, #0x40]
    3d98:      	blr	x9
    3d9c:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3da0:      	ldr	x8, [x8]
    3da4:      	ldr	w8, [x8]
    3da8:      	cbz	w8, 0x3dec <kprobe_unwind_v8+0x3dec>
    3dac:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3db0:      	add	x8, x8, #0x0
    3db4:      	add	x0, sp, #0x70
    3db8:      	ldp	x9, x10, [x8, #0x10]
    3dbc:      	mov	w1, #0x25               // =37
    3dc0:      	stp	x9, x10, [sp, #0x80]
    3dc4:      	ldur	x9, [x8, #0x1d]
    3dc8:      	add	x10, sp, #0x70
    3dcc:      	stur	x9, [sp, #0x8d]
    3dd0:      	ldp	x8, x9, [x8]
    3dd4:      	stp	x8, x9, [sp, #0x70]
    3dd8:      	mov	w8, #0x25               // =37
    3ddc:      	mov	w9, #0x6                // =6
    3de0:      	ldp	x4, x2, [sp, #0x30]
    3de4:      	ldr	x3, [sp, #0x28]
    3de8:      	blr	x9
    3dec:      	ldr	x8, [sp, #0x38]
    3df0:      	subs	x8, x24, x8
    3df4:      	b.lo	0x3f1c <kprobe_unwind_v8+0x3f1c>
    3df8:      	ldr	x9, [sp, #0x28]
    3dfc:      	cmp	x24, x9
    3e00:      	b.hs	0x3f1c <kprobe_unwind_v8+0x3f1c>
    3e04:      	ldr	w9, [sp, #0x20]
    3e08:      	ldr	w10, [sp, #0x10]
    3e0c:      	orr	x11, x29, #0x4
    3e10:      	orr	x12, x25, #0x3
    3e14:      	and	w9, w9, w10
    3e18:      	ldr	x10, [sp, #0x18]
    3e1c:      	lsr	w9, w9, w10
    3e20:      	ldrb	w10, [x23, #0x19]
    3e24:      	cmp	w9, w10
    3e28:      	ldr	x10, [sp, #0x30]
    3e2c:      	csel	x22, x11, x12, eq
    3e30:      	orr	w9, w9, w10, lsl #4
    3e34:      	orr	x25, x8, x9, lsl #32
    3e38:      	b	0x4048 <kprobe_unwind_v8+0x4048>
    3e3c:      	ldr	x9, [sp, #0x50]
    3e40:      	ldr	x8, [x9, x8]
    3e44:      	ldr	x25, [x9, x10]
    3e48:      	and	x9, x8, #0x3
    3e4c:      	and	x8, x8, #0xfffffffffffffffc
    3e50:      	cmp	x9, #0x1
    3e54:      	csel	x8, x8, xzr, eq
    3e58:      	str	x8, [sp, #0x38]
    3e5c:      	cbz	x8, 0x3f3c <kprobe_unwind_v8+0x3f3c>
    3e60:      	ldrb	w8, [x23, #0xc]
    3e64:      	ldr	x9, [sp, #0x38]
    3e68:      	add	x10, sp, #0x70
    3e6c:      	add	x0, sp, #0x70
    3e70:      	mov	w1, #0x8                // =8
    3e74:      	add	x2, x9, x8
    3e78:      	mov	w8, #0x8                // =8
    3e7c:      	mov	w9, #0x70               // =112
    3e80:      	blr	x9
    3e84:      	cbnz	x0, 0x3f38 <kprobe_unwind_v8+0x3f38>
    3e88:      	ldr	x8, [sp, #0x70]
    3e8c:      	and	x9, x8, #0x3
    3e90:      	cmp	x9, #0x1
    3e94:      	b.ne	0x3f38 <kprobe_unwind_v8+0x3f38>
    3e98:      	and	x8, x8, #0xfffffffffffffffc
    3e9c:      	cbz	x8, 0x3f3c <kprobe_unwind_v8+0x3f3c>
    3ea0:      	ldrb	w9, [x23, #0xd]
    3ea4:      	mov	w10, #0x2               // =2
    3ea8:      	mov	w11, #0x70              // =112
    3eac:      	add	x12, sp, #0x70
    3eb0:      	add	x0, sp, #0x70
    3eb4:      	mov	w1, #0x2                // =2
    3eb8:      	add	x9, x8, x9
    3ebc:      	ldrb	w9, [x23, #0xd]
    3ec0:      	add	x2, x8, x9
    3ec4:      	blr	x11
    3ec8:      	ldrh	w8, [sp, #0x70]
    3ecc:      	cmp	x0, #0x0
    3ed0:      	csel	w8, w8, wzr, eq
    3ed4:      	b	0x3f3c <kprobe_unwind_v8+0x3f3c>
    3ed8:      	adrp	x10, 0x3000 <kprobe_unwind_v8+0x3000>
    3edc:      	add	x10, x10, #0x0
    3ee0:      	add	x0, sp, #0x70
    3ee4:      	ldp	x8, x9, [x10]
    3ee8:      	mov	w1, #0x1d               // =29
    3eec:      	mov	x2, x24
    3ef0:      	stp	x8, x9, [sp, #0x70]
    3ef4:      	ldr	x8, [x10, #0x10]
    3ef8:      	mov	w9, #0x6                // =6
    3efc:      	str	x8, [sp, #0x80]
    3f00:      	ldur	x8, [x10, #0x15]
    3f04:      	add	x10, sp, #0x70
    3f08:      	stur	x8, [sp, #0x85]
    3f0c:      	mov	w8, #0x1d               // =29
    3f10:      	blr	x9
    3f14:      	str	xzr, [sp, #0x40]
    3f18:      	b	0x4538 <kprobe_unwind_v8+0x4538>
    3f1c:      	adrp	x8, 0x3000 <kprobe_unwind_v8+0x3000>
    3f20:      	ldr	x8, [x8]
    3f24:      	ldr	w8, [x8]
    3f28:      	cbnz	w8, 0x400c <kprobe_unwind_v8+0x400c>
    3f2c:      	ldrb	w24, [x21, #0xf20]
    3f30:      	mov	x25, xzr
    3f34:      	b	0x30f0 <kprobe_unwind_v8+0x30f0>
    3f38:      	mov	w8, wzr
    3f3c:      	ldrh	w9, [x23, #0x4]
    3f40:      	cmp	w9, w8, uxth
    3f44:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    3f48:      	ldrh	w9, [x23, #0x6]
    3f4c:      	cmp	w9, w8, uxth
    3f50:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    3f54:      	ldrb	w8, [x23, #0xf]
    3f58:      	ldr	x9, [sp, #0x38]
    3f5c:      	add	x10, sp, #0x70
    3f60:      	add	x0, sp, #0x70
    3f64:      	mov	w1, #0x8                // =8
    3f68:      	add	x2, x9, x8
    3f6c:      	mov	w8, #0x8                // =8
    3f70:      	mov	w9, #0x70               // =112
    3f74:      	blr	x9
    3f78:      	cbnz	x0, 0x40b4 <kprobe_unwind_v8+0x40b4>
    3f7c:      	ldr	x8, [sp, #0x70]
    3f80:      	and	x9, x8, #0x3
    3f84:      	cmp	x9, #0x1
    3f88:      	b.ne	0x40b4 <kprobe_unwind_v8+0x40b4>
    3f8c:      	and	x8, x8, #0xfffffffffffffffc
    3f90:      	mov	x22, x8
    3f94:      	cbz	x8, 0x40bc <kprobe_unwind_v8+0x40bc>
    3f98:      	ldrb	w8, [x23, #0xc]
    3f9c:      	mov	w9, #0x70               // =112
    3fa0:      	add	x10, sp, #0x70
    3fa4:      	add	x0, sp, #0x70
    3fa8:      	mov	w1, #0x8                // =8
    3fac:      	add	x2, x22, x8
    3fb0:      	mov	w8, #0x8                // =8
    3fb4:      	blr	x9
    3fb8:      	cbnz	x0, 0x40b8 <kprobe_unwind_v8+0x40b8>
    3fbc:      	ldr	x8, [sp, #0x70]
    3fc0:      	and	x9, x8, #0x3
    3fc4:      	cmp	x9, #0x1
    3fc8:      	b.ne	0x40b8 <kprobe_unwind_v8+0x40b8>
    3fcc:      	and	x8, x8, #0xfffffffffffffffc
    3fd0:      	cbz	x8, 0x40bc <kprobe_unwind_v8+0x40bc>
    3fd4:      	ldrb	w9, [x23, #0xd]
    3fd8:      	mov	w10, #0x2               // =2
    3fdc:      	mov	w11, #0x70              // =112
    3fe0:      	add	x12, sp, #0x70
    3fe4:      	add	x0, sp, #0x70
    3fe8:      	mov	w1, #0x2                // =2
    3fec:      	add	x9, x8, x9
    3ff0:      	ldrb	w9, [x23, #0xd]
    3ff4:      	add	x2, x8, x9
    3ff8:      	blr	x11
    3ffc:      	ldrh	w8, [sp, #0x70]
    4000:      	cmp	x0, #0x0
    4004:      	csel	w8, w8, wzr, eq
    4008:      	b	0x40bc <kprobe_unwind_v8+0x40bc>
    400c:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4010:      	add	x8, x8, #0x0
    4014:      	add	x0, sp, #0x70
    4018:      	ldp	x9, x10, [x8, #0x10]
    401c:      	mov	w1, #0x30               // =48
    4020:      	stp	x9, x10, [sp, #0x80]
    4024:      	ldp	x9, x10, [x8, #0x20]
    4028:      	stp	x9, x10, [sp, #0x90]
    402c:      	ldp	x9, x8, [x8]
    4030:      	add	x10, sp, #0x70
    4034:      	stp	x9, x8, [sp, #0x70]
    4038:      	mov	w8, #0x30               // =48
    403c:      	mov	w9, #0x6                // =6
    4040:      	blr	x9
    4044:      	mov	x25, xzr
    4048:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    404c:      	ldr	x8, [x8]
    4050:      	ldrb	w24, [x21, #0xf20]
    4054:      	ldr	w8, [x8]
    4058:      	cbz	w8, 0x30f0 <kprobe_unwind_v8+0x30f0>
    405c:      	mov	w8, #0x786c             // =30828
    4060:      	add	x0, sp, #0x70
    4064:      	mov	w1, #0x3c               // =60
    4068:      	mov	x2, x25
    406c:      	mov	x3, x22
    4070:      	movk	w8, #0xa, lsl #16
    4074:      	str	w8, [sp, #0xa8]
    4078:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    407c:      	add	x8, x8, #0x0
    4080:      	ldp	x9, x10, [x8, #0x20]
    4084:      	stp	x9, x10, [sp, #0x90]
    4088:      	ldr	x9, [x8, #0x30]
    408c:      	str	x9, [sp, #0xa0]
    4090:      	ldp	x9, x10, [x8]
    4094:      	stp	x9, x10, [sp, #0x70]
    4098:      	add	x10, sp, #0x70
    409c:      	ldp	x8, x9, [x8, #0x10]
    40a0:      	stp	x8, x9, [sp, #0x80]
    40a4:      	mov	w8, #0x3c               // =60
    40a8:      	mov	w9, #0x6                // =6
    40ac:      	blr	x9
    40b0:      	b	0x30f0 <kprobe_unwind_v8+0x30f0>
    40b4:      	mov	x22, xzr
    40b8:      	mov	w8, wzr
    40bc:      	ldrh	w9, [x23, #0xa]
    40c0:      	cmp	w9, w8, uxth
    40c4:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    40c8:      	lsr	x24, x25, #32
    40cc:      	cbz	x24, 0x4130 <kprobe_unwind_v8+0x4130>
    40d0:      	tbnz	w25, #0x0, 0x4130 <kprobe_unwind_v8+0x4130>
    40d4:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    40d8:      	ldr	x8, [x8]
    40dc:      	ldr	w8, [x8]
    40e0:      	cbz	w8, 0x4124 <kprobe_unwind_v8+0x4124>
    40e4:      	mov	w8, #0x786c             // =30828
    40e8:      	add	x0, sp, #0x70
    40ec:      	mov	w1, #0x1c               // =28
    40f0:      	mov	x2, x24
    40f4:      	movk	w8, #0xa, lsl #16
    40f8:      	str	w8, [sp, #0x88]
    40fc:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4100:      	add	x8, x8, #0x0
    4104:      	ldp	x9, x10, [x8]
    4108:      	ldr	x8, [x8, #0x10]
    410c:      	stp	x9, x10, [sp, #0x70]
    4110:      	mov	w9, #0x6                // =6
    4114:      	str	x8, [sp, #0x80]
    4118:      	mov	w8, #0x1c               // =28
    411c:      	add	x10, sp, #0x70
    4120:      	blr	x9
    4124:      	orr	x8, x22, #0x1
    4128:      	str	x8, [sp, #0x40]
    412c:      	b	0x4538 <kprobe_unwind_v8+0x4538>
    4130:      	orr	x8, x22, #0x2
    4134:      	ldr	x9, [sp, #0x38]
    4138:      	add	x10, sp, #0x70
    413c:      	add	x0, sp, #0x70
    4140:      	str	x8, [sp, #0x40]
    4144:      	ldrb	w8, [x23, #0xe]
    4148:      	mov	w1, #0x8                // =8
    414c:      	add	x2, x9, x8
    4150:      	mov	w8, #0x8                // =8
    4154:      	mov	w9, #0x70               // =112
    4158:      	blr	x9
    415c:      	cbnz	x0, 0x41ec <kprobe_unwind_v8+0x41ec>
    4160:      	ldr	x8, [sp, #0x70]
    4164:      	and	x9, x8, #0x3
    4168:      	cmp	x9, #0x1
    416c:      	b.ne	0x41ec <kprobe_unwind_v8+0x41ec>
    4170:      	and	x24, x8, #0xfffffffffffffffc
    4174:      	cbz	x24, 0x41f0 <kprobe_unwind_v8+0x41f0>
    4178:      	ldrb	w8, [x23, #0xc]
    417c:      	mov	w9, #0x70               // =112
    4180:      	add	x10, sp, #0x70
    4184:      	add	x0, sp, #0x70
    4188:      	mov	w1, #0x8                // =8
    418c:      	add	x2, x24, x8
    4190:      	mov	w8, #0x8                // =8
    4194:      	blr	x9
    4198:      	cbnz	x0, 0x41f0 <kprobe_unwind_v8+0x41f0>
    419c:      	ldr	x8, [sp, #0x70]
    41a0:      	and	x9, x8, #0x3
    41a4:      	cmp	x9, #0x1
    41a8:      	b.ne	0x41f0 <kprobe_unwind_v8+0x41f0>
    41ac:      	and	x8, x8, #0xfffffffffffffffc
    41b0:      	cbz	x8, 0x41f4 <kprobe_unwind_v8+0x41f4>
    41b4:      	ldrb	w9, [x23, #0xd]
    41b8:      	mov	w10, #0x2               // =2
    41bc:      	mov	w11, #0x70              // =112
    41c0:      	add	x12, sp, #0x70
    41c4:      	add	x0, sp, #0x70
    41c8:      	mov	w1, #0x2                // =2
    41cc:      	add	x9, x8, x9
    41d0:      	ldrb	w9, [x23, #0xd]
    41d4:      	add	x2, x8, x9
    41d8:      	blr	x11
    41dc:      	ldrh	w8, [sp, #0x70]
    41e0:      	cmp	x0, #0x0
    41e4:      	csel	w8, w8, wzr, eq
    41e8:      	b	0x41f4 <kprobe_unwind_v8+0x41f4>
    41ec:      	mov	x24, xzr
    41f0:      	mov	w8, wzr
    41f4:      	and	w4, w8, #0xffff
    41f8:      	ldrh	w8, [x23, #0x8]
    41fc:      	cmp	w4, w8
    4200:      	b.ne	0x429c <kprobe_unwind_v8+0x429c>
    4204:      	ldr	x0, [sp, #0x48]
    4208:      	mov	w8, #0x60               // =96
    420c:      	mov	w9, #0x70               // =112
    4210:      	mov	w1, #0x60               // =96
    4214:      	mov	x2, x24
    4218:      	blr	x9
    421c:      	cbz	x0, 0x432c <kprobe_unwind_v8+0x432c>
    4220:      	mov	w8, #0x3b               // =59
    4224:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    4228:      	add	x9, sp, #0x58
    422c:      	str	w8, [sp, #0x58]
    4230:      	mov	w8, #0x1                // =1
    4234:      	add	x1, sp, #0x58
    4238:      	ldr	x0, [x0]
    423c:      	blr	x8
    4240:      	cbnz	x0, 0x4318 <kprobe_unwind_v8+0x4318>
    4244:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4248:      	ldr	x8, [x8]
    424c:      	ldr	w8, [x8]
    4250:      	cbz	w8, 0x4534 <kprobe_unwind_v8+0x4534>
    4254:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4258:      	add	x8, x8, #0x0
    425c:      	add	x0, sp, #0x70
    4260:      	ldp	x9, x10, [x8, #0x10]
    4264:      	mov	w1, #0x2e               // =46
    4268:      	stp	x9, x10, [sp, #0x80]
    426c:      	ldr	x9, [x8, #0x20]
    4270:      	add	x10, sp, #0x70
    4274:      	str	x9, [sp, #0x90]
    4278:      	ldur	x9, [x8, #0x26]
    427c:      	stur	x9, [sp, #0x96]
    4280:      	ldp	x9, x8, [x8]
    4284:      	stp	x9, x8, [sp, #0x70]
    4288:      	mov	w8, #0x2e               // =46
    428c:      	mov	w9, #0x6                // =6
    4290:      	ldr	w2, [sp, #0x58]
    4294:      	blr	x9
    4298:      	b	0x4534 <kprobe_unwind_v8+0x4534>
    429c:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    42a0:      	ldr	x8, [x8]
    42a4:      	ldr	w8, [x8]
    42a8:      	cbz	w8, 0x42f4 <kprobe_unwind_v8+0x42f4>
    42ac:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    42b0:      	add	x8, x8, #0x0
    42b4:      	add	x0, sp, #0x70
    42b8:      	ldp	x9, x10, [x8, #0x10]
    42bc:      	mov	w1, #0x2e               // =46
    42c0:      	mov	x3, x24
    42c4:      	stp	x9, x10, [sp, #0x80]
    42c8:      	ldr	x9, [x8, #0x20]
    42cc:      	add	x10, sp, #0x70
    42d0:      	str	x9, [sp, #0x90]
    42d4:      	ldur	x9, [x8, #0x26]
    42d8:      	stur	x9, [sp, #0x96]
    42dc:      	ldp	x9, x8, [x8]
    42e0:      	stp	x9, x8, [sp, #0x70]
    42e4:      	mov	w8, #0x2e               // =46
    42e8:      	mov	w9, #0x6                // =6
    42ec:      	ldr	x2, [sp, #0x38]
    42f0:      	blr	x9
    42f4:      	mov	w8, #0x3b               // =59
    42f8:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    42fc:      	add	x9, sp, #0x58
    4300:      	str	w8, [sp, #0x58]
    4304:      	mov	w8, #0x1                // =1
    4308:      	add	x1, sp, #0x58
    430c:      	ldr	x0, [x0]
    4310:      	blr	x8
    4314:      	cbz	x0, 0x435c <kprobe_unwind_v8+0x435c>
    4318:      	ldr	x8, [x0]
    431c:      	mov	x24, xzr
    4320:      	add	x8, x8, #0x1
    4324:      	str	x8, [x0]
    4328:      	b	0x4538 <kprobe_unwind_v8+0x4538>
    432c:      	ldrb	w8, [x23, #0x12]
    4330:      	cmp	x8, #0x5c
    4334:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4338:      	ldrb	w9, [x23, #0x13]
    433c:      	cmp	x9, #0x5c
    4340:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4344:      	ldrb	w11, [x23, #0x10]
    4348:      	ldrb	w10, [x23, #0x11]
    434c:      	cbz	w11, 0x43b4 <kprobe_unwind_v8+0x43b4>
    4350:      	ldr	x11, [sp, #0x48]
    4354:      	ldr	x25, [x11, x10]
    4358:      	b	0x43b8 <kprobe_unwind_v8+0x43b8>
    435c:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4360:      	ldr	x8, [x8]
    4364:      	ldr	w8, [x8]
    4368:      	cbz	w8, 0x4534 <kprobe_unwind_v8+0x4534>
    436c:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4370:      	add	x8, x8, #0x0
    4374:      	add	x0, sp, #0x70
    4378:      	ldp	x9, x10, [x8, #0x10]
    437c:      	mov	w1, #0x2e               // =46
    4380:      	stp	x9, x10, [sp, #0x80]
    4384:      	ldr	x9, [x8, #0x20]
    4388:      	add	x10, sp, #0x70
    438c:      	str	x9, [sp, #0x90]
    4390:      	ldur	x9, [x8, #0x26]
    4394:      	stur	x9, [sp, #0x96]
    4398:      	ldp	x9, x8, [x8]
    439c:      	stp	x9, x8, [sp, #0x70]
    43a0:      	mov	w8, #0x2e               // =46
    43a4:      	mov	w9, #0x6                // =6
    43a8:      	ldr	w2, [sp, #0x58]
    43ac:      	blr	x9
    43b0:      	b	0x4534 <kprobe_unwind_v8+0x4534>
    43b4:      	add	x25, x24, x10
    43b8:      	ldr	x10, [sp, #0x48]
    43bc:      	ldr	w29, [x10, x8]
    43c0:      	ldr	w8, [x10, x9]
    43c4:      	str	w8, [sp, #0x20]
    43c8:      	ldrb	w8, [x23, #0x18]
    43cc:      	str	w8, [sp, #0x10]
    43d0:      	ldrb	w8, [x23, #0x17]
    43d4:      	str	x8, [sp, #0x18]
    43d8:      	add	x8, x25, x29
    43dc:      	str	x8, [sp, #0x28]
    43e0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    43e4:      	ldr	x8, [x8]
    43e8:      	ldr	w8, [x8]
    43ec:      	cbz	w8, 0x448c <kprobe_unwind_v8+0x448c>
    43f0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    43f4:      	add	x8, x8, #0x0
    43f8:      	strb	wzr, [sp, #0x98]
    43fc:      	add	x0, sp, #0x70
    4400:      	ldp	x9, x10, [x8, #0x10]
    4404:      	mov	w1, #0x29               // =41
    4408:      	mov	x3, x22
    440c:      	mov	x4, x24
    4410:      	stp	x9, x10, [sp, #0x80]
    4414:      	ldr	x9, [x8, #0x20]
    4418:      	add	x10, sp, #0x70
    441c:      	str	x9, [sp, #0x90]
    4420:      	ldp	x8, x9, [x8]
    4424:      	stp	x8, x9, [sp, #0x70]
    4428:      	mov	w8, #0x29               // =41
    442c:      	mov	w9, #0x6                // =6
    4430:      	ldr	x2, [sp, #0x38]
    4434:      	blr	x9
    4438:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    443c:      	ldr	x8, [x8]
    4440:      	ldr	w8, [x8]
    4444:      	cbz	w8, 0x448c <kprobe_unwind_v8+0x448c>
    4448:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    444c:      	add	x8, x8, #0x0
    4450:      	add	x0, sp, #0x70
    4454:      	ldp	x9, x10, [x8, #0x10]
    4458:      	mov	w1, #0x25               // =37
    445c:      	mov	x2, x25
    4460:      	mov	w4, w29
    4464:      	stp	x9, x10, [sp, #0x80]
    4468:      	ldur	x9, [x8, #0x1d]
    446c:      	add	x10, sp, #0x70
    4470:      	stur	x9, [sp, #0x8d]
    4474:      	ldp	x8, x9, [x8]
    4478:      	stp	x8, x9, [sp, #0x70]
    447c:      	mov	w8, #0x25               // =37
    4480:      	mov	w9, #0x6                // =6
    4484:      	ldr	x3, [sp, #0x28]
    4488:      	blr	x9
    448c:      	ldr	x8, [sp, #0x30]
    4490:      	subs	x8, x8, x25
    4494:      	b.lo	0x44e0 <kprobe_unwind_v8+0x44e0>
    4498:      	ldp	x10, x9, [sp, #0x28]
    449c:      	cmp	x9, x10
    44a0:      	b.hs	0x44e0 <kprobe_unwind_v8+0x44e0>
    44a4:      	ldr	w9, [sp, #0x20]
    44a8:      	ldr	w10, [sp, #0x10]
    44ac:      	orr	x12, x24, #0x3
    44b0:      	and	w9, w9, w10
    44b4:      	ldr	x10, [sp, #0x18]
    44b8:      	ldr	x11, [sp, #0x38]
    44bc:      	orr	x11, x11, #0x4
    44c0:      	lsr	w9, w9, w10
    44c4:      	ldrb	w10, [x23, #0x19]
    44c8:      	cmp	w9, w10
    44cc:      	orr	w9, w9, w29, lsl #4
    44d0:      	csel	x10, x11, x12, eq
    44d4:      	orr	x24, x8, x9, lsl #32
    44d8:      	str	x10, [sp, #0x40]
    44dc:      	b	0x4538 <kprobe_unwind_v8+0x4538>
    44e0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    44e4:      	ldr	x8, [x8]
    44e8:      	ldr	w8, [x8]
    44ec:      	cbnz	w8, 0x44fc <kprobe_unwind_v8+0x44fc>
    44f0:      	ldrb	w25, [x21, #0xf20]
    44f4:      	mov	x24, xzr
    44f8:      	b	0x45a0 <kprobe_unwind_v8+0x45a0>
    44fc:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4500:      	add	x8, x8, #0x0
    4504:      	add	x0, sp, #0x70
    4508:      	ldp	x9, x10, [x8, #0x10]
    450c:      	mov	w1, #0x30               // =48
    4510:      	stp	x9, x10, [sp, #0x80]
    4514:      	ldp	x9, x10, [x8, #0x20]
    4518:      	stp	x9, x10, [sp, #0x90]
    451c:      	ldp	x9, x8, [x8]
    4520:      	add	x10, sp, #0x70
    4524:      	stp	x9, x8, [sp, #0x70]
    4528:      	mov	w8, #0x30               // =48
    452c:      	mov	w9, #0x6                // =6
    4530:      	blr	x9
    4534:      	mov	x24, xzr
    4538:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    453c:      	ldr	x8, [x8]
    4540:      	ldrb	w25, [x21, #0xf20]
    4544:      	ldr	w8, [x8]
    4548:      	cbz	w8, 0x45a0 <kprobe_unwind_v8+0x45a0>
    454c:      	mov	w8, #0x786c             // =30828
    4550:      	add	x0, sp, #0x70
    4554:      	mov	w1, #0x3c               // =60
    4558:      	mov	x2, x24
    455c:      	movk	w8, #0xa, lsl #16
    4560:      	str	w8, [sp, #0xa8]
    4564:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4568:      	add	x8, x8, #0x0
    456c:      	ldp	x9, x10, [x8, #0x20]
    4570:      	stp	x9, x10, [sp, #0x90]
    4574:      	ldr	x9, [x8, #0x30]
    4578:      	str	x9, [sp, #0xa0]
    457c:      	ldp	x9, x10, [x8]
    4580:      	stp	x9, x10, [sp, #0x70]
    4584:      	add	x10, sp, #0x70
    4588:      	ldp	x8, x9, [x8, #0x10]
    458c:      	stp	x8, x9, [sp, #0x80]
    4590:      	mov	w8, #0x3c               // =60
    4594:      	mov	w9, #0x6                // =6
    4598:      	ldr	x3, [sp, #0x40]
    459c:      	blr	x9
    45a0:      	ldr	w8, [x21, #0x2c0]
    45a4:      	cmp	w8, #0x7e
    45a8:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    45ac:      	add	w9, w8, #0x1
    45b0:      	mov	w10, #0x8               // =8
    45b4:      	add	x11, sp, #0x70
    45b8:      	str	w9, [x21, #0x2c0]
    45bc:      	mov	w9, #0x18               // =24
    45c0:      	add	x0, sp, #0x70
    45c4:      	mov	w1, #0x10               // =16
    45c8:      	umaddl	x8, w8, w9, x21
    45cc:      	ldr	x9, [sp, #0x40]
    45d0:      	str	x24, [x8, #0x2d8]
    45d4:      	strb	w10, [x8, #0x2e0]
    45d8:      	strb	w25, [x8, #0x2e1]
    45dc:      	strh	wzr, [x8, #0x2e6]
    45e0:      	mov	w10, #0x70              // =112
    45e4:      	str	x9, [x8, #0x2d0]
    45e8:      	add	x9, x8, #0x2d0
    45ec:      	stur	wzr, [x9, #0x12]
    45f0:      	mov	w9, #0x10               // =16
    45f4:      	ldr	x8, [x21, #0xee0]
    45f8:      	ldr	x2, [x21, #0xee0]
    45fc:      	blr	x10
    4600:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    4604:      	ldr	x8, [x21, #0xee0]
    4608:      	add	x9, x8, #0x10
    460c:      	str	x9, [x21, #0xed8]
    4610:      	ldp	x9, x10, [sp, #0x70]
    4614:      	str	x9, [x21, #0xee0]
    4618:      	mov	w9, #0x101              // =257
    461c:      	str	x10, [x21, #0xed0]
    4620:      	strh	w9, [x21, #0xf20]
    4624:      	ldr	x9, [sp, #0x40]
    4628:      	cbnz	x9, 0x463c <kprobe_unwind_v8+0x463c>
    462c:      	cmp	x24, #0x1
    4630:      	b.ne	0x463c <kprobe_unwind_v8+0x463c>
    4634:      	add	x8, x8, #0xa0
    4638:      	str	x8, [x21, #0xed8]
    463c:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4640:      	ldr	x8, [x8]
    4644:      	ldr	w8, [x8]
    4648:      	cbz	w8, 0x4690 <kprobe_unwind_v8+0x4690>
    464c:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4650:      	add	x8, x8, #0x0
    4654:      	add	x0, sp, #0x70
    4658:      	ldp	x9, x10, [x8]
    465c:      	mov	w1, #0x1f               // =31
    4660:      	stp	x9, x10, [sp, #0x70]
    4664:      	ldr	x9, [x8, #0x10]
    4668:      	ldur	x8, [x8, #0x17]
    466c:      	add	x10, sp, #0x70
    4670:      	str	x9, [sp, #0x80]
    4674:      	stur	x8, [sp, #0x87]
    4678:      	mov	w8, #0x1f               // =31
    467c:      	mov	w9, #0x6                // =6
    4680:      	ldr	x2, [x21, #0xed0]
    4684:      	ldr	x3, [x21, #0xed8]
    4688:      	ldr	x4, [x21, #0xee0]
    468c:      	blr	x9
    4690:      	mov	w8, #0x38               // =56
    4694:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    4698:      	add	x9, sp, #0x58
    469c:      	str	w8, [sp, #0x58]
    46a0:      	mov	w8, #0x1                // =1
    46a4:      	add	x1, sp, #0x58
    46a8:      	ldr	x0, [x0]
    46ac:      	blr	x8
    46b0:      	cbz	x0, 0x46c4 <kprobe_unwind_v8+0x46c4>
    46b4:      	ldr	x8, [x0]
    46b8:      	add	x8, x8, #0x1
    46bc:      	str	x8, [x0]
    46c0:      	b	0x4718 <kprobe_unwind_v8+0x4718>
    46c4:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    46c8:      	ldr	x8, [x8]
    46cc:      	ldr	w8, [x8]
    46d0:      	cbz	w8, 0x4724 <kprobe_unwind_v8+0x4724>
    46d4:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    46d8:      	add	x8, x8, #0x0
    46dc:      	add	x0, sp, #0x70
    46e0:      	ldp	x9, x10, [x8, #0x10]
    46e4:      	mov	w1, #0x2e               // =46
    46e8:      	stp	x9, x10, [sp, #0x80]
    46ec:      	ldr	x9, [x8, #0x20]
    46f0:      	add	x10, sp, #0x70
    46f4:      	str	x9, [sp, #0x90]
    46f8:      	ldur	x9, [x8, #0x26]
    46fc:      	stur	x9, [sp, #0x96]
    4700:      	ldp	x9, x8, [x8]
    4704:      	stp	x9, x8, [sp, #0x70]
    4708:      	mov	w8, #0x2e               // =46
    470c:      	mov	w9, #0x6                // =6
    4710:      	ldr	w2, [sp, #0x58]
    4714:      	blr	x9
    4718:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    471c:      	ldr	x8, [x8]
    4720:      	ldr	w8, [x8]
    4724:      	ldr	x24, [x21, #0xed0]
    4728:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    472c:      	cbz	w8, 0x4774 <kprobe_unwind_v8+0x4774>
    4730:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4734:      	add	x8, x8, #0x0
    4738:      	strb	wzr, [sp, #0xa0]
    473c:      	add	x0, sp, #0x70
    4740:      	ldp	x9, x10, [x8, #0x10]
    4744:      	mov	w1, #0x31               // =49
    4748:      	stp	x9, x10, [sp, #0x80]
    474c:      	ldp	x9, x10, [x8, #0x20]
    4750:      	stp	x9, x10, [sp, #0x90]
    4754:      	ldp	x9, x8, [x8]
    4758:      	add	x10, sp, #0x70
    475c:      	stp	x9, x8, [sp, #0x70]
    4760:      	mov	w8, #0x31               // =49
    4764:      	mov	w9, #0x6                // =6
    4768:      	ldr	w2, [x21, #0x2c0]
    476c:      	blr	x9
    4770:      	ldr	x24, [x21, #0xed0]
    4774:      	lsr	x8, x24, #56
    4778:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    477c:      	cmp	x24, #0x1, lsl #12      // =0x1000
    4780:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    4784:      	ldr	w8, [x21]
    4788:      	mov	w9, #0x60               // =96
    478c:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    4790:      	add	x1, sp, #0x58
    4794:      	rev	w8, w8
    4798:      	stp	w9, w8, [sp, #0x58]
    479c:      	rev	x8, x24
    47a0:      	add	x9, sp, #0x58
    47a4:      	str	x8, [sp, #0x60]
    47a8:      	mov	w8, #0x1                // =1
    47ac:      	ldr	x0, [x0]
    47b0:      	blr	x8
    47b4:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    47b8:      	ldr	x8, [x0, #0x8]
    47bc:      	and	x9, x8, #0xffffffffffffff
    47c0:      	lsr	x29, x8, #56
    47c4:      	str	x9, [x21, #0xf10]
    47c8:      	ldr	x8, [x0]
    47cc:      	str	x8, [x21, #0xf00]
    47d0:      	sub	x8, x24, x9
    47d4:      	str	x8, [x21, #0xf08]
    47d8:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    47dc:      	ldr	x8, [x8]
    47e0:      	ldr	w8, [x8]
    47e4:      	cbz	w8, 0x488c <kprobe_unwind_v8+0x488c>
    47e8:      	mov	w8, #0xa                // =10
    47ec:      	add	x0, sp, #0x70
    47f0:      	mov	w1, #0x32               // =50
    47f4:      	strh	w8, [sp, #0xa0]
    47f8:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    47fc:      	add	x8, x8, #0x0
    4800:      	mov	x2, x24
    4804:      	ldp	x9, x10, [x8, #0x10]
    4808:      	mov	w4, w29
    480c:      	stp	x9, x10, [sp, #0x80]
    4810:      	ldp	x9, x10, [x8, #0x20]
    4814:      	stp	x9, x10, [sp, #0x90]
    4818:      	ldp	x9, x8, [x8]
    481c:      	add	x10, sp, #0x70
    4820:      	stp	x9, x8, [sp, #0x70]
    4824:      	mov	w8, #0x32               // =50
    4828:      	mov	w9, #0x6                // =6
    482c:      	ldr	x3, [x21, #0xf00]
    4830:      	blr	x9
    4834:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4838:      	ldr	x8, [x8]
    483c:      	ldr	w8, [x8]
    4840:      	cbz	w8, 0x488c <kprobe_unwind_v8+0x488c>
    4844:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4848:      	add	x8, x8, #0x0
    484c:      	add	x0, sp, #0x70
    4850:      	ldp	x9, x10, [x8, #0x10]
    4854:      	mov	w1, #0x2f               // =47
    4858:      	stp	x9, x10, [sp, #0x80]
    485c:      	ldr	x9, [x8, #0x20]
    4860:      	add	x10, sp, #0x70
    4864:      	str	x9, [sp, #0x90]
    4868:      	ldur	x9, [x8, #0x27]
    486c:      	stur	x9, [sp, #0x97]
    4870:      	ldp	x9, x8, [x8]
    4874:      	stp	x9, x8, [sp, #0x70]
    4878:      	mov	w8, #0x2f               // =47
    487c:      	mov	w9, #0x6                // =6
    4880:      	ldr	x2, [x21, #0xf10]
    4884:      	ldr	x3, [x21, #0xf08]
    4888:      	blr	x9
    488c:      	cmp	w29, #0x1
    4890:      	b.ne	0x4a38 <kprobe_unwind_v8+0x4a38>
    4894:      	ldr	x8, [x21, #0xf00]
    4898:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    489c:      	ldr	x25, [x21, #0xf08]
    48a0:      	mov	w9, #0x1                // =1
    48a4:      	add	x1, sp, #0x58
    48a8:      	mov	w29, #0x1               // =1
    48ac:      	str	x8, [sp, #0x58]
    48b0:      	add	x8, sp, #0x58
    48b4:      	ldr	x0, [x0]
    48b8:      	blr	x9
    48bc:      	cbz	x0, 0x4968 <kprobe_unwind_v8+0x4968>
    48c0:      	ldr	x8, [x0]
    48c4:      	mov	x24, x0
    48c8:      	cmp	x8, x25
    48cc:      	b.hi	0x48dc <kprobe_unwind_v8+0x48dc>
    48d0:      	ldr	x8, [x24, #0x8]
    48d4:      	cmp	x8, x25
    48d8:      	b.hs	0x48f4 <kprobe_unwind_v8+0x48f4>
    48dc:      	ldr	x8, [x24, #0x10]
    48e0:      	cmp	x8, x25
    48e4:      	b.hi	0x4960 <kprobe_unwind_v8+0x4960>
    48e8:      	ldr	x8, [x24, #0x18]
    48ec:      	cmp	x8, x25
    48f0:      	b.lo	0x4960 <kprobe_unwind_v8+0x4960>
    48f4:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    48f8:      	ldr	x8, [x8]
    48fc:      	ldr	w8, [x8]
    4900:      	cbz	w8, 0x4940 <kprobe_unwind_v8+0x4940>
    4904:      	adrp	x10, 0x4000 <kprobe_unwind_v8+0x4000>
    4908:      	add	x10, x10, #0x0
    490c:      	add	x0, sp, #0x70
    4910:      	ldp	x8, x9, [x10]
    4914:      	mov	w1, #0x1e               // =30
    4918:      	stp	x8, x9, [sp, #0x70]
    491c:      	ldr	x8, [x10, #0x10]
    4920:      	mov	w9, #0x6                // =6
    4924:      	str	x8, [sp, #0x80]
    4928:      	ldur	x8, [x10, #0x16]
    492c:      	add	x10, sp, #0x70
    4930:      	stur	x8, [sp, #0x86]
    4934:      	mov	w8, #0x1e               // =30
    4938:      	ldrh	w2, [x24, #0x20]
    493c:      	blr	x9
    4940:      	ldrh	w8, [x24, #0x20]
    4944:      	ldr	w9, [x21, #0x1370]
    4948:      	lsr	w8, w9, w8
    494c:      	tbz	w8, #0x0, 0x496c <kprobe_unwind_v8+0x496c>
    4950:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4954:      	ldr	x8, [x8]
    4958:      	ldr	w8, [x8]
    495c:      	cbnz	w8, 0x499c <kprobe_unwind_v8+0x499c>
    4960:      	mov	w29, #0x1               // =1
    4964:      	b	0x4a38 <kprobe_unwind_v8+0x4a38>
    4968:      	b	0x4a38 <kprobe_unwind_v8+0x4a38>
    496c:      	str	wzr, [sp, #0xbc]
    4970:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    4974:      	mov	w8, #0x1                // =1
    4978:      	add	x9, sp, #0xbc
    497c:      	ldr	x0, [x0]
    4980:      	add	x1, sp, #0xbc
    4984:      	blr	x8
    4988:      	cbz	x0, 0x49e0 <kprobe_unwind_v8+0x49e0>
    498c:      	ldr	x8, [x0]
    4990:      	add	x8, x8, #0x1
    4994:      	str	x8, [x0]
    4998:      	b	0x4a34 <kprobe_unwind_v8+0x4a34>
    499c:      	mov	w8, #0x656e             // =25966
    49a0:      	adrp	x10, 0x4000 <kprobe_unwind_v8+0x4000>
    49a4:      	add	x10, x10, #0x0
    49a8:      	add	x0, sp, #0x70
    49ac:      	mov	w1, #0x1b               // =27
    49b0:      	movk	w8, #0xa, lsl #16
    49b4:      	stur	w8, [sp, #0x87]
    49b8:      	ldp	x8, x9, [x10]
    49bc:      	stp	x8, x9, [sp, #0x70]
    49c0:      	ldr	x8, [x10, #0x10]
    49c4:      	mov	w9, #0x6                // =6
    49c8:      	add	x10, sp, #0x70
    49cc:      	str	x8, [sp, #0x80]
    49d0:      	mov	w8, #0x1b               // =27
    49d4:      	blr	x9
    49d8:      	mov	w29, #0x1               // =1
    49dc:      	b	0x4a38 <kprobe_unwind_v8+0x4a38>
    49e0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    49e4:      	ldr	x8, [x8]
    49e8:      	ldr	w8, [x8]
    49ec:      	cbz	w8, 0x4a34 <kprobe_unwind_v8+0x4a34>
    49f0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    49f4:      	add	x8, x8, #0x0
    49f8:      	add	x0, sp, #0x70
    49fc:      	ldp	x9, x10, [x8, #0x10]
    4a00:      	mov	w1, #0x2e               // =46
    4a04:      	stp	x9, x10, [sp, #0x80]
    4a08:      	ldr	x9, [x8, #0x20]
    4a0c:      	add	x10, sp, #0x70
    4a10:      	str	x9, [sp, #0x90]
    4a14:      	ldur	x9, [x8, #0x26]
    4a18:      	stur	x9, [sp, #0x96]
    4a1c:      	ldp	x9, x8, [x8]
    4a20:      	stp	x9, x8, [sp, #0x70]
    4a24:      	mov	w8, #0x2e               // =46
    4a28:      	mov	w9, #0x6                // =6
    4a2c:      	ldr	w2, [sp, #0xbc]
    4a30:      	blr	x9
    4a34:      	ldrh	w29, [x24, #0x20]
    4a38:      	cmp	w29, #0x7
    4a3c:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    4a40:      	ldr	x8, [x21, #0xed0]
    4a44:      	ldr	x29, [x21, #0xed8]
    4a48:      	ldr	x25, [x21, #0xee0]
    4a4c:      	str	x8, [sp, #0x30]
    4a50:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4a54:      	ldr	x8, [x8]
    4a58:      	ldr	w8, [x8]
    4a5c:      	cbz	w8, 0x4aa4 <kprobe_unwind_v8+0x4aa4>
    4a60:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4a64:      	add	x8, x8, #0x0
    4a68:      	add	x0, sp, #0x70
    4a6c:      	ldp	x9, x10, [x8]
    4a70:      	mov	w1, #0x1f               // =31
    4a74:      	mov	x3, x29
    4a78:      	mov	x4, x25
    4a7c:      	stp	x9, x10, [sp, #0x70]
    4a80:      	ldr	x9, [x8, #0x10]
    4a84:      	ldur	x8, [x8, #0x17]
    4a88:      	add	x10, sp, #0x70
    4a8c:      	str	x9, [sp, #0x80]
    4a90:      	stur	x8, [sp, #0x87]
    4a94:      	mov	w8, #0x1f               // =31
    4a98:      	mov	w9, #0x6                // =6
    4a9c:      	ldr	x2, [sp, #0x30]
    4aa0:      	blr	x9
    4aa4:      	cmp	x25, x29
    4aa8:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    4aac:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    4ab0:      	cmp	x25, x8
    4ab4:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    4ab8:      	ldr	x0, [sp, #0x50]
    4abc:      	sub	x2, x25, #0x40
    4ac0:      	mov	w8, #0x40               // =64
    4ac4:      	mov	w9, #0x70               // =112
    4ac8:      	mov	w1, #0x40               // =64
    4acc:      	blr	x9
    4ad0:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    4ad4:      	ldrb	w9, [x23, #0x14]
    4ad8:      	cmp	x9, #0x38
    4adc:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4ae0:      	ldrb	w8, [x23, #0x15]
    4ae4:      	cmp	x8, #0x38
    4ae8:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4aec:      	ldrb	w10, [x23, #0x16]
    4af0:      	cmp	x10, #0x38
    4af4:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4af8:      	ldr	x11, [sp, #0x50]
    4afc:      	ldr	x9, [x11, x9]
    4b00:      	tbnz	w9, #0x0, 0x4b24 <kprobe_unwind_v8+0x4b24>
    4b04:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4b08:      	lsr	x24, x9, #1
    4b0c:      	ldr	x8, [x8]
    4b10:      	ldr	w8, [x8]
    4b14:      	cbnz	w8, 0x4bc0 <kprobe_unwind_v8+0x4bc0>
    4b18:      	ldrb	w25, [x21, #0xf20]
    4b1c:      	str	xzr, [sp, #0x40]
    4b20:      	b	0x51c4 <kprobe_unwind_v8+0x51c4>
    4b24:      	ldr	x9, [sp, #0x50]
    4b28:      	ldr	x8, [x9, x8]
    4b2c:      	ldr	x25, [x9, x10]
    4b30:      	and	x9, x8, #0x3
    4b34:      	and	x8, x8, #0xfffffffffffffffc
    4b38:      	cmp	x9, #0x1
    4b3c:      	csel	x8, x8, xzr, eq
    4b40:      	str	x8, [sp, #0x38]
    4b44:      	cbz	x8, 0x4c08 <kprobe_unwind_v8+0x4c08>
    4b48:      	ldrb	w8, [x23, #0xc]
    4b4c:      	ldr	x9, [sp, #0x38]
    4b50:      	add	x10, sp, #0x70
    4b54:      	add	x0, sp, #0x70
    4b58:      	mov	w1, #0x8                // =8
    4b5c:      	add	x2, x9, x8
    4b60:      	mov	w8, #0x8                // =8
    4b64:      	mov	w9, #0x70               // =112
    4b68:      	blr	x9
    4b6c:      	cbnz	x0, 0x4c04 <kprobe_unwind_v8+0x4c04>
    4b70:      	ldr	x8, [sp, #0x70]
    4b74:      	and	x9, x8, #0x3
    4b78:      	cmp	x9, #0x1
    4b7c:      	b.ne	0x4c04 <kprobe_unwind_v8+0x4c04>
    4b80:      	and	x8, x8, #0xfffffffffffffffc
    4b84:      	cbz	x8, 0x4c08 <kprobe_unwind_v8+0x4c08>
    4b88:      	ldrb	w9, [x23, #0xd]
    4b8c:      	mov	w10, #0x2               // =2
    4b90:      	mov	w11, #0x70              // =112
    4b94:      	add	x12, sp, #0x70
    4b98:      	add	x0, sp, #0x70
    4b9c:      	mov	w1, #0x2                // =2
    4ba0:      	add	x9, x8, x9
    4ba4:      	ldrb	w9, [x23, #0xd]
    4ba8:      	add	x2, x8, x9
    4bac:      	blr	x11
    4bb0:      	ldrh	w8, [sp, #0x70]
    4bb4:      	cmp	x0, #0x0
    4bb8:      	csel	w8, w8, wzr, eq
    4bbc:      	b	0x4c08 <kprobe_unwind_v8+0x4c08>
    4bc0:      	adrp	x10, 0x4000 <kprobe_unwind_v8+0x4000>
    4bc4:      	add	x10, x10, #0x0
    4bc8:      	add	x0, sp, #0x70
    4bcc:      	ldp	x8, x9, [x10]
    4bd0:      	mov	w1, #0x1d               // =29
    4bd4:      	mov	x2, x24
    4bd8:      	stp	x8, x9, [sp, #0x70]
    4bdc:      	ldr	x8, [x10, #0x10]
    4be0:      	mov	w9, #0x6                // =6
    4be4:      	str	x8, [sp, #0x80]
    4be8:      	ldur	x8, [x10, #0x15]
    4bec:      	add	x10, sp, #0x70
    4bf0:      	stur	x8, [sp, #0x85]
    4bf4:      	mov	w8, #0x1d               // =29
    4bf8:      	blr	x9
    4bfc:      	str	xzr, [sp, #0x40]
    4c00:      	b	0x515c <kprobe_unwind_v8+0x515c>
    4c04:      	mov	w8, wzr
    4c08:      	ldrh	w9, [x23, #0x4]
    4c0c:      	cmp	w9, w8, uxth
    4c10:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    4c14:      	ldrh	w9, [x23, #0x6]
    4c18:      	cmp	w9, w8, uxth
    4c1c:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    4c20:      	ldrb	w8, [x23, #0xf]
    4c24:      	ldr	x9, [sp, #0x38]
    4c28:      	add	x10, sp, #0x70
    4c2c:      	add	x0, sp, #0x70
    4c30:      	mov	w1, #0x8                // =8
    4c34:      	add	x2, x9, x8
    4c38:      	mov	w8, #0x8                // =8
    4c3c:      	mov	w9, #0x70               // =112
    4c40:      	blr	x9
    4c44:      	cbnz	x0, 0x4cd8 <kprobe_unwind_v8+0x4cd8>
    4c48:      	ldr	x8, [sp, #0x70]
    4c4c:      	and	x9, x8, #0x3
    4c50:      	cmp	x9, #0x1
    4c54:      	b.ne	0x4cd8 <kprobe_unwind_v8+0x4cd8>
    4c58:      	and	x8, x8, #0xfffffffffffffffc
    4c5c:      	mov	x22, x8
    4c60:      	cbz	x8, 0x4ce0 <kprobe_unwind_v8+0x4ce0>
    4c64:      	ldrb	w8, [x23, #0xc]
    4c68:      	mov	w9, #0x70               // =112
    4c6c:      	add	x10, sp, #0x70
    4c70:      	add	x0, sp, #0x70
    4c74:      	mov	w1, #0x8                // =8
    4c78:      	add	x2, x22, x8
    4c7c:      	mov	w8, #0x8                // =8
    4c80:      	blr	x9
    4c84:      	cbnz	x0, 0x4cdc <kprobe_unwind_v8+0x4cdc>
    4c88:      	ldr	x8, [sp, #0x70]
    4c8c:      	and	x9, x8, #0x3
    4c90:      	cmp	x9, #0x1
    4c94:      	b.ne	0x4cdc <kprobe_unwind_v8+0x4cdc>
    4c98:      	and	x8, x8, #0xfffffffffffffffc
    4c9c:      	cbz	x8, 0x4ce0 <kprobe_unwind_v8+0x4ce0>
    4ca0:      	ldrb	w9, [x23, #0xd]
    4ca4:      	mov	w10, #0x2               // =2
    4ca8:      	mov	w11, #0x70              // =112
    4cac:      	add	x12, sp, #0x70
    4cb0:      	add	x0, sp, #0x70
    4cb4:      	mov	w1, #0x2                // =2
    4cb8:      	add	x9, x8, x9
    4cbc:      	ldrb	w9, [x23, #0xd]
    4cc0:      	add	x2, x8, x9
    4cc4:      	blr	x11
    4cc8:      	ldrh	w8, [sp, #0x70]
    4ccc:      	cmp	x0, #0x0
    4cd0:      	csel	w8, w8, wzr, eq
    4cd4:      	b	0x4ce0 <kprobe_unwind_v8+0x4ce0>
    4cd8:      	mov	x22, xzr
    4cdc:      	mov	w8, wzr
    4ce0:      	ldrh	w9, [x23, #0xa]
    4ce4:      	cmp	w9, w8, uxth
    4ce8:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    4cec:      	lsr	x24, x25, #32
    4cf0:      	cbz	x24, 0x4d54 <kprobe_unwind_v8+0x4d54>
    4cf4:      	tbnz	w25, #0x0, 0x4d54 <kprobe_unwind_v8+0x4d54>
    4cf8:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4cfc:      	ldr	x8, [x8]
    4d00:      	ldr	w8, [x8]
    4d04:      	cbz	w8, 0x4d48 <kprobe_unwind_v8+0x4d48>
    4d08:      	mov	w8, #0x786c             // =30828
    4d0c:      	add	x0, sp, #0x70
    4d10:      	mov	w1, #0x1c               // =28
    4d14:      	mov	x2, x24
    4d18:      	movk	w8, #0xa, lsl #16
    4d1c:      	str	w8, [sp, #0x88]
    4d20:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4d24:      	add	x8, x8, #0x0
    4d28:      	ldp	x9, x10, [x8]
    4d2c:      	ldr	x8, [x8, #0x10]
    4d30:      	stp	x9, x10, [sp, #0x70]
    4d34:      	mov	w9, #0x6                // =6
    4d38:      	str	x8, [sp, #0x80]
    4d3c:      	mov	w8, #0x1c               // =28
    4d40:      	add	x10, sp, #0x70
    4d44:      	blr	x9
    4d48:      	orr	x8, x22, #0x1
    4d4c:      	str	x8, [sp, #0x40]
    4d50:      	b	0x515c <kprobe_unwind_v8+0x515c>
    4d54:      	orr	x8, x22, #0x2
    4d58:      	ldr	x9, [sp, #0x38]
    4d5c:      	add	x10, sp, #0x70
    4d60:      	add	x0, sp, #0x70
    4d64:      	str	x8, [sp, #0x40]
    4d68:      	ldrb	w8, [x23, #0xe]
    4d6c:      	mov	w1, #0x8                // =8
    4d70:      	add	x2, x9, x8
    4d74:      	mov	w8, #0x8                // =8
    4d78:      	mov	w9, #0x70               // =112
    4d7c:      	blr	x9
    4d80:      	cbnz	x0, 0x4e10 <kprobe_unwind_v8+0x4e10>
    4d84:      	ldr	x8, [sp, #0x70]
    4d88:      	and	x9, x8, #0x3
    4d8c:      	cmp	x9, #0x1
    4d90:      	b.ne	0x4e10 <kprobe_unwind_v8+0x4e10>
    4d94:      	and	x24, x8, #0xfffffffffffffffc
    4d98:      	cbz	x24, 0x4e14 <kprobe_unwind_v8+0x4e14>
    4d9c:      	ldrb	w8, [x23, #0xc]
    4da0:      	mov	w9, #0x70               // =112
    4da4:      	add	x10, sp, #0x70
    4da8:      	add	x0, sp, #0x70
    4dac:      	mov	w1, #0x8                // =8
    4db0:      	add	x2, x24, x8
    4db4:      	mov	w8, #0x8                // =8
    4db8:      	blr	x9
    4dbc:      	cbnz	x0, 0x4e14 <kprobe_unwind_v8+0x4e14>
    4dc0:      	ldr	x8, [sp, #0x70]
    4dc4:      	and	x9, x8, #0x3
    4dc8:      	cmp	x9, #0x1
    4dcc:      	b.ne	0x4e14 <kprobe_unwind_v8+0x4e14>
    4dd0:      	and	x8, x8, #0xfffffffffffffffc
    4dd4:      	cbz	x8, 0x4e18 <kprobe_unwind_v8+0x4e18>
    4dd8:      	ldrb	w9, [x23, #0xd]
    4ddc:      	mov	w10, #0x2               // =2
    4de0:      	mov	w11, #0x70              // =112
    4de4:      	add	x12, sp, #0x70
    4de8:      	add	x0, sp, #0x70
    4dec:      	mov	w1, #0x2                // =2
    4df0:      	add	x9, x8, x9
    4df4:      	ldrb	w9, [x23, #0xd]
    4df8:      	add	x2, x8, x9
    4dfc:      	blr	x11
    4e00:      	ldrh	w8, [sp, #0x70]
    4e04:      	cmp	x0, #0x0
    4e08:      	csel	w8, w8, wzr, eq
    4e0c:      	b	0x4e18 <kprobe_unwind_v8+0x4e18>
    4e10:      	mov	x24, xzr
    4e14:      	mov	w8, wzr
    4e18:      	and	w4, w8, #0xffff
    4e1c:      	ldrh	w8, [x23, #0x8]
    4e20:      	cmp	w4, w8
    4e24:      	b.ne	0x4ec0 <kprobe_unwind_v8+0x4ec0>
    4e28:      	ldr	x0, [sp, #0x48]
    4e2c:      	mov	w8, #0x60               // =96
    4e30:      	mov	w9, #0x70               // =112
    4e34:      	mov	w1, #0x60               // =96
    4e38:      	mov	x2, x24
    4e3c:      	blr	x9
    4e40:      	cbz	x0, 0x4f50 <kprobe_unwind_v8+0x4f50>
    4e44:      	mov	w8, #0x3b               // =59
    4e48:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    4e4c:      	add	x9, sp, #0x58
    4e50:      	str	w8, [sp, #0x58]
    4e54:      	mov	w8, #0x1                // =1
    4e58:      	add	x1, sp, #0x58
    4e5c:      	ldr	x0, [x0]
    4e60:      	blr	x8
    4e64:      	cbnz	x0, 0x4f3c <kprobe_unwind_v8+0x4f3c>
    4e68:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4e6c:      	ldr	x8, [x8]
    4e70:      	ldr	w8, [x8]
    4e74:      	cbz	w8, 0x5158 <kprobe_unwind_v8+0x5158>
    4e78:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4e7c:      	add	x8, x8, #0x0
    4e80:      	add	x0, sp, #0x70
    4e84:      	ldp	x9, x10, [x8, #0x10]
    4e88:      	mov	w1, #0x2e               // =46
    4e8c:      	stp	x9, x10, [sp, #0x80]
    4e90:      	ldr	x9, [x8, #0x20]
    4e94:      	add	x10, sp, #0x70
    4e98:      	str	x9, [sp, #0x90]
    4e9c:      	ldur	x9, [x8, #0x26]
    4ea0:      	stur	x9, [sp, #0x96]
    4ea4:      	ldp	x9, x8, [x8]
    4ea8:      	stp	x9, x8, [sp, #0x70]
    4eac:      	mov	w8, #0x2e               // =46
    4eb0:      	mov	w9, #0x6                // =6
    4eb4:      	ldr	w2, [sp, #0x58]
    4eb8:      	blr	x9
    4ebc:      	b	0x5158 <kprobe_unwind_v8+0x5158>
    4ec0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4ec4:      	ldr	x8, [x8]
    4ec8:      	ldr	w8, [x8]
    4ecc:      	cbz	w8, 0x4f18 <kprobe_unwind_v8+0x4f18>
    4ed0:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4ed4:      	add	x8, x8, #0x0
    4ed8:      	add	x0, sp, #0x70
    4edc:      	ldp	x9, x10, [x8, #0x10]
    4ee0:      	mov	w1, #0x2e               // =46
    4ee4:      	mov	x3, x24
    4ee8:      	stp	x9, x10, [sp, #0x80]
    4eec:      	ldr	x9, [x8, #0x20]
    4ef0:      	add	x10, sp, #0x70
    4ef4:      	str	x9, [sp, #0x90]
    4ef8:      	ldur	x9, [x8, #0x26]
    4efc:      	stur	x9, [sp, #0x96]
    4f00:      	ldp	x9, x8, [x8]
    4f04:      	stp	x9, x8, [sp, #0x70]
    4f08:      	mov	w8, #0x2e               // =46
    4f0c:      	mov	w9, #0x6                // =6
    4f10:      	ldr	x2, [sp, #0x38]
    4f14:      	blr	x9
    4f18:      	mov	w8, #0x3b               // =59
    4f1c:      	adrp	x0, 0x4000 <kprobe_unwind_v8+0x4000>
    4f20:      	add	x9, sp, #0x58
    4f24:      	str	w8, [sp, #0x58]
    4f28:      	mov	w8, #0x1                // =1
    4f2c:      	add	x1, sp, #0x58
    4f30:      	ldr	x0, [x0]
    4f34:      	blr	x8
    4f38:      	cbz	x0, 0x4f80 <kprobe_unwind_v8+0x4f80>
    4f3c:      	ldr	x8, [x0]
    4f40:      	mov	x24, xzr
    4f44:      	add	x8, x8, #0x1
    4f48:      	str	x8, [x0]
    4f4c:      	b	0x515c <kprobe_unwind_v8+0x515c>
    4f50:      	ldrb	w8, [x23, #0x12]
    4f54:      	cmp	x8, #0x5c
    4f58:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4f5c:      	ldrb	w9, [x23, #0x13]
    4f60:      	cmp	x9, #0x5c
    4f64:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    4f68:      	ldrb	w11, [x23, #0x10]
    4f6c:      	ldrb	w10, [x23, #0x11]
    4f70:      	cbz	w11, 0x4fd8 <kprobe_unwind_v8+0x4fd8>
    4f74:      	ldr	x11, [sp, #0x48]
    4f78:      	ldr	x25, [x11, x10]
    4f7c:      	b	0x4fdc <kprobe_unwind_v8+0x4fdc>
    4f80:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4f84:      	ldr	x8, [x8]
    4f88:      	ldr	w8, [x8]
    4f8c:      	cbz	w8, 0x5158 <kprobe_unwind_v8+0x5158>
    4f90:      	adrp	x8, 0x4000 <kprobe_unwind_v8+0x4000>
    4f94:      	add	x8, x8, #0x0
    4f98:      	add	x0, sp, #0x70
    4f9c:      	ldp	x9, x10, [x8, #0x10]
    4fa0:      	mov	w1, #0x2e               // =46
    4fa4:      	stp	x9, x10, [sp, #0x80]
    4fa8:      	ldr	x9, [x8, #0x20]
    4fac:      	add	x10, sp, #0x70
    4fb0:      	str	x9, [sp, #0x90]
    4fb4:      	ldur	x9, [x8, #0x26]
    4fb8:      	stur	x9, [sp, #0x96]
    4fbc:      	ldp	x9, x8, [x8]
    4fc0:      	stp	x9, x8, [sp, #0x70]
    4fc4:      	mov	w8, #0x2e               // =46
    4fc8:      	mov	w9, #0x6                // =6
    4fcc:      	ldr	w2, [sp, #0x58]
    4fd0:      	blr	x9
    4fd4:      	b	0x5158 <kprobe_unwind_v8+0x5158>
    4fd8:      	add	x25, x24, x10
    4fdc:      	ldr	x10, [sp, #0x48]
    4fe0:      	ldr	w29, [x10, x8]
    4fe4:      	ldr	w8, [x10, x9]
    4fe8:      	str	w8, [sp, #0x20]
    4fec:      	ldrb	w8, [x23, #0x18]
    4ff0:      	str	w8, [sp, #0x10]
    4ff4:      	ldrb	w8, [x23, #0x17]
    4ff8:      	str	x8, [sp, #0x18]
    4ffc:      	add	x8, x25, x29
    5000:      	str	x8, [sp, #0x28]
    5004:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5008:      	ldr	x8, [x8]
    500c:      	ldr	w8, [x8]
    5010:      	cbz	w8, 0x50b0 <kprobe_unwind_v8+0x50b0>
    5014:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5018:      	add	x8, x8, #0x0
    501c:      	strb	wzr, [sp, #0x98]
    5020:      	add	x0, sp, #0x70
    5024:      	ldp	x9, x10, [x8, #0x10]
    5028:      	mov	w1, #0x29               // =41
    502c:      	mov	x3, x22
    5030:      	mov	x4, x24
    5034:      	stp	x9, x10, [sp, #0x80]
    5038:      	ldr	x9, [x8, #0x20]
    503c:      	add	x10, sp, #0x70
    5040:      	str	x9, [sp, #0x90]
    5044:      	ldp	x8, x9, [x8]
    5048:      	stp	x8, x9, [sp, #0x70]
    504c:      	mov	w8, #0x29               // =41
    5050:      	mov	w9, #0x6                // =6
    5054:      	ldr	x2, [sp, #0x38]
    5058:      	blr	x9
    505c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5060:      	ldr	x8, [x8]
    5064:      	ldr	w8, [x8]
    5068:      	cbz	w8, 0x50b0 <kprobe_unwind_v8+0x50b0>
    506c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5070:      	add	x8, x8, #0x0
    5074:      	add	x0, sp, #0x70
    5078:      	ldp	x9, x10, [x8, #0x10]
    507c:      	mov	w1, #0x25               // =37
    5080:      	mov	x2, x25
    5084:      	mov	w4, w29
    5088:      	stp	x9, x10, [sp, #0x80]
    508c:      	ldur	x9, [x8, #0x1d]
    5090:      	add	x10, sp, #0x70
    5094:      	stur	x9, [sp, #0x8d]
    5098:      	ldp	x8, x9, [x8]
    509c:      	stp	x8, x9, [sp, #0x70]
    50a0:      	mov	w8, #0x25               // =37
    50a4:      	mov	w9, #0x6                // =6
    50a8:      	ldr	x3, [sp, #0x28]
    50ac:      	blr	x9
    50b0:      	ldr	x8, [sp, #0x30]
    50b4:      	subs	x8, x8, x25
    50b8:      	b.lo	0x5104 <kprobe_unwind_v8+0x5104>
    50bc:      	ldp	x10, x9, [sp, #0x28]
    50c0:      	cmp	x9, x10
    50c4:      	b.hs	0x5104 <kprobe_unwind_v8+0x5104>
    50c8:      	ldr	w9, [sp, #0x20]
    50cc:      	ldr	w10, [sp, #0x10]
    50d0:      	orr	x12, x24, #0x3
    50d4:      	and	w9, w9, w10
    50d8:      	ldr	x10, [sp, #0x18]
    50dc:      	ldr	x11, [sp, #0x38]
    50e0:      	orr	x11, x11, #0x4
    50e4:      	lsr	w9, w9, w10
    50e8:      	ldrb	w10, [x23, #0x19]
    50ec:      	cmp	w9, w10
    50f0:      	orr	w9, w9, w29, lsl #4
    50f4:      	csel	x10, x11, x12, eq
    50f8:      	orr	x24, x8, x9, lsl #32
    50fc:      	str	x10, [sp, #0x40]
    5100:      	b	0x515c <kprobe_unwind_v8+0x515c>
    5104:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5108:      	ldr	x8, [x8]
    510c:      	ldr	w8, [x8]
    5110:      	cbnz	w8, 0x5120 <kprobe_unwind_v8+0x5120>
    5114:      	ldrb	w25, [x21, #0xf20]
    5118:      	mov	x24, xzr
    511c:      	b	0x51c4 <kprobe_unwind_v8+0x51c4>
    5120:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5124:      	add	x8, x8, #0x0
    5128:      	add	x0, sp, #0x70
    512c:      	ldp	x9, x10, [x8, #0x10]
    5130:      	mov	w1, #0x30               // =48
    5134:      	stp	x9, x10, [sp, #0x80]
    5138:      	ldp	x9, x10, [x8, #0x20]
    513c:      	stp	x9, x10, [sp, #0x90]
    5140:      	ldp	x9, x8, [x8]
    5144:      	add	x10, sp, #0x70
    5148:      	stp	x9, x8, [sp, #0x70]
    514c:      	mov	w8, #0x30               // =48
    5150:      	mov	w9, #0x6                // =6
    5154:      	blr	x9
    5158:      	mov	x24, xzr
    515c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5160:      	ldr	x8, [x8]
    5164:      	ldrb	w25, [x21, #0xf20]
    5168:      	ldr	w8, [x8]
    516c:      	cbz	w8, 0x51c4 <kprobe_unwind_v8+0x51c4>
    5170:      	mov	w8, #0x786c             // =30828
    5174:      	add	x0, sp, #0x70
    5178:      	mov	w1, #0x3c               // =60
    517c:      	mov	x2, x24
    5180:      	movk	w8, #0xa, lsl #16
    5184:      	str	w8, [sp, #0xa8]
    5188:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    518c:      	add	x8, x8, #0x0
    5190:      	ldp	x9, x10, [x8, #0x20]
    5194:      	stp	x9, x10, [sp, #0x90]
    5198:      	ldr	x9, [x8, #0x30]
    519c:      	str	x9, [sp, #0xa0]
    51a0:      	ldp	x9, x10, [x8]
    51a4:      	stp	x9, x10, [sp, #0x70]
    51a8:      	add	x10, sp, #0x70
    51ac:      	ldp	x8, x9, [x8, #0x10]
    51b0:      	stp	x8, x9, [sp, #0x80]
    51b4:      	mov	w8, #0x3c               // =60
    51b8:      	mov	w9, #0x6                // =6
    51bc:      	ldr	x3, [sp, #0x40]
    51c0:      	blr	x9
    51c4:      	ldr	w8, [x21, #0x2c0]
    51c8:      	cmp	w8, #0x7e
    51cc:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    51d0:      	add	w9, w8, #0x1
    51d4:      	mov	w10, #0x8               // =8
    51d8:      	add	x11, sp, #0x70
    51dc:      	str	w9, [x21, #0x2c0]
    51e0:      	mov	w9, #0x18               // =24
    51e4:      	add	x0, sp, #0x70
    51e8:      	mov	w1, #0x10               // =16
    51ec:      	umaddl	x8, w8, w9, x21
    51f0:      	ldr	x9, [sp, #0x40]
    51f4:      	str	x24, [x8, #0x2d8]
    51f8:      	strb	w10, [x8, #0x2e0]
    51fc:      	strb	w25, [x8, #0x2e1]
    5200:      	strh	wzr, [x8, #0x2e6]
    5204:      	mov	w10, #0x70              // =112
    5208:      	str	x9, [x8, #0x2d0]
    520c:      	add	x9, x8, #0x2d0
    5210:      	stur	wzr, [x9, #0x12]
    5214:      	mov	w9, #0x10               // =16
    5218:      	ldr	x8, [x21, #0xee0]
    521c:      	ldr	x2, [x21, #0xee0]
    5220:      	blr	x10
    5224:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    5228:      	ldr	x8, [x21, #0xee0]
    522c:      	add	x9, x8, #0x10
    5230:      	str	x9, [x21, #0xed8]
    5234:      	ldp	x9, x10, [sp, #0x70]
    5238:      	str	x9, [x21, #0xee0]
    523c:      	mov	w9, #0x101              // =257
    5240:      	str	x10, [x21, #0xed0]
    5244:      	strh	w9, [x21, #0xf20]
    5248:      	ldr	x9, [sp, #0x40]
    524c:      	cbnz	x9, 0x5260 <kprobe_unwind_v8+0x5260>
    5250:      	cmp	x24, #0x1
    5254:      	b.ne	0x5260 <kprobe_unwind_v8+0x5260>
    5258:      	add	x8, x8, #0xa0
    525c:      	str	x8, [x21, #0xed8]
    5260:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5264:      	ldr	x8, [x8]
    5268:      	ldr	w8, [x8]
    526c:      	cbz	w8, 0x52b4 <kprobe_unwind_v8+0x52b4>
    5270:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5274:      	add	x8, x8, #0x0
    5278:      	add	x0, sp, #0x70
    527c:      	ldp	x9, x10, [x8]
    5280:      	mov	w1, #0x1f               // =31
    5284:      	stp	x9, x10, [sp, #0x70]
    5288:      	ldr	x9, [x8, #0x10]
    528c:      	ldur	x8, [x8, #0x17]
    5290:      	add	x10, sp, #0x70
    5294:      	str	x9, [sp, #0x80]
    5298:      	stur	x8, [sp, #0x87]
    529c:      	mov	w8, #0x1f               // =31
    52a0:      	mov	w9, #0x6                // =6
    52a4:      	ldr	x2, [x21, #0xed0]
    52a8:      	ldr	x3, [x21, #0xed8]
    52ac:      	ldr	x4, [x21, #0xee0]
    52b0:      	blr	x9
    52b4:      	mov	w8, #0x38               // =56
    52b8:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    52bc:      	add	x9, sp, #0x58
    52c0:      	str	w8, [sp, #0x58]
    52c4:      	mov	w8, #0x1                // =1
    52c8:      	add	x1, sp, #0x58
    52cc:      	ldr	x0, [x0]
    52d0:      	blr	x8
    52d4:      	cbz	x0, 0x52e8 <kprobe_unwind_v8+0x52e8>
    52d8:      	ldr	x8, [x0]
    52dc:      	add	x8, x8, #0x1
    52e0:      	str	x8, [x0]
    52e4:      	b	0x533c <kprobe_unwind_v8+0x533c>
    52e8:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    52ec:      	ldr	x8, [x8]
    52f0:      	ldr	w8, [x8]
    52f4:      	cbz	w8, 0x5348 <kprobe_unwind_v8+0x5348>
    52f8:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    52fc:      	add	x8, x8, #0x0
    5300:      	add	x0, sp, #0x70
    5304:      	ldp	x9, x10, [x8, #0x10]
    5308:      	mov	w1, #0x2e               // =46
    530c:      	stp	x9, x10, [sp, #0x80]
    5310:      	ldr	x9, [x8, #0x20]
    5314:      	add	x10, sp, #0x70
    5318:      	str	x9, [sp, #0x90]
    531c:      	ldur	x9, [x8, #0x26]
    5320:      	stur	x9, [sp, #0x96]
    5324:      	ldp	x9, x8, [x8]
    5328:      	stp	x9, x8, [sp, #0x70]
    532c:      	mov	w8, #0x2e               // =46
    5330:      	mov	w9, #0x6                // =6
    5334:      	ldr	w2, [sp, #0x58]
    5338:      	blr	x9
    533c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5340:      	ldr	x8, [x8]
    5344:      	ldr	w8, [x8]
    5348:      	ldr	x24, [x21, #0xed0]
    534c:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    5350:      	cbz	w8, 0x5398 <kprobe_unwind_v8+0x5398>
    5354:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5358:      	add	x8, x8, #0x0
    535c:      	strb	wzr, [sp, #0xa0]
    5360:      	add	x0, sp, #0x70
    5364:      	ldp	x9, x10, [x8, #0x10]
    5368:      	mov	w1, #0x31               // =49
    536c:      	stp	x9, x10, [sp, #0x80]
    5370:      	ldp	x9, x10, [x8, #0x20]
    5374:      	stp	x9, x10, [sp, #0x90]
    5378:      	ldp	x9, x8, [x8]
    537c:      	add	x10, sp, #0x70
    5380:      	stp	x9, x8, [sp, #0x70]
    5384:      	mov	w8, #0x31               // =49
    5388:      	mov	w9, #0x6                // =6
    538c:      	ldr	w2, [x21, #0x2c0]
    5390:      	blr	x9
    5394:      	ldr	x24, [x21, #0xed0]
    5398:      	lsr	x8, x24, #56
    539c:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    53a0:      	cmp	x24, #0x1, lsl #12      // =0x1000
    53a4:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    53a8:      	ldr	w8, [x21]
    53ac:      	mov	w9, #0x60               // =96
    53b0:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    53b4:      	add	x1, sp, #0x58
    53b8:      	rev	w8, w8
    53bc:      	stp	w9, w8, [sp, #0x58]
    53c0:      	rev	x8, x24
    53c4:      	add	x9, sp, #0x58
    53c8:      	str	x8, [sp, #0x60]
    53cc:      	mov	w8, #0x1                // =1
    53d0:      	ldr	x0, [x0]
    53d4:      	blr	x8
    53d8:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    53dc:      	ldr	x8, [x0, #0x8]
    53e0:      	and	x9, x8, #0xffffffffffffff
    53e4:      	lsr	x29, x8, #56
    53e8:      	str	x9, [x21, #0xf10]
    53ec:      	ldr	x8, [x0]
    53f0:      	str	x8, [x21, #0xf00]
    53f4:      	sub	x8, x24, x9
    53f8:      	str	x8, [x21, #0xf08]
    53fc:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5400:      	ldr	x8, [x8]
    5404:      	ldr	w8, [x8]
    5408:      	cbz	w8, 0x54b0 <kprobe_unwind_v8+0x54b0>
    540c:      	mov	w8, #0xa                // =10
    5410:      	add	x0, sp, #0x70
    5414:      	mov	w1, #0x32               // =50
    5418:      	strh	w8, [sp, #0xa0]
    541c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5420:      	add	x8, x8, #0x0
    5424:      	mov	x2, x24
    5428:      	ldp	x9, x10, [x8, #0x10]
    542c:      	mov	w4, w29
    5430:      	stp	x9, x10, [sp, #0x80]
    5434:      	ldp	x9, x10, [x8, #0x20]
    5438:      	stp	x9, x10, [sp, #0x90]
    543c:      	ldp	x9, x8, [x8]
    5440:      	add	x10, sp, #0x70
    5444:      	stp	x9, x8, [sp, #0x70]
    5448:      	mov	w8, #0x32               // =50
    544c:      	mov	w9, #0x6                // =6
    5450:      	ldr	x3, [x21, #0xf00]
    5454:      	blr	x9
    5458:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    545c:      	ldr	x8, [x8]
    5460:      	ldr	w8, [x8]
    5464:      	cbz	w8, 0x54b0 <kprobe_unwind_v8+0x54b0>
    5468:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    546c:      	add	x8, x8, #0x0
    5470:      	add	x0, sp, #0x70
    5474:      	ldp	x9, x10, [x8, #0x10]
    5478:      	mov	w1, #0x2f               // =47
    547c:      	stp	x9, x10, [sp, #0x80]
    5480:      	ldr	x9, [x8, #0x20]
    5484:      	add	x10, sp, #0x70
    5488:      	str	x9, [sp, #0x90]
    548c:      	ldur	x9, [x8, #0x27]
    5490:      	stur	x9, [sp, #0x97]
    5494:      	ldp	x9, x8, [x8]
    5498:      	stp	x9, x8, [sp, #0x70]
    549c:      	mov	w8, #0x2f               // =47
    54a0:      	mov	w9, #0x6                // =6
    54a4:      	ldr	x2, [x21, #0xf10]
    54a8:      	ldr	x3, [x21, #0xf08]
    54ac:      	blr	x9
    54b0:      	cmp	w29, #0x1
    54b4:      	b.ne	0x565c <kprobe_unwind_v8+0x565c>
    54b8:      	ldr	x8, [x21, #0xf00]
    54bc:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    54c0:      	ldr	x25, [x21, #0xf08]
    54c4:      	mov	w9, #0x1                // =1
    54c8:      	add	x1, sp, #0x58
    54cc:      	mov	w29, #0x1               // =1
    54d0:      	str	x8, [sp, #0x58]
    54d4:      	add	x8, sp, #0x58
    54d8:      	ldr	x0, [x0]
    54dc:      	blr	x9
    54e0:      	cbz	x0, 0x558c <kprobe_unwind_v8+0x558c>
    54e4:      	ldr	x8, [x0]
    54e8:      	mov	x24, x0
    54ec:      	cmp	x8, x25
    54f0:      	b.hi	0x5500 <kprobe_unwind_v8+0x5500>
    54f4:      	ldr	x8, [x24, #0x8]
    54f8:      	cmp	x8, x25
    54fc:      	b.hs	0x5518 <kprobe_unwind_v8+0x5518>
    5500:      	ldr	x8, [x24, #0x10]
    5504:      	cmp	x8, x25
    5508:      	b.hi	0x5584 <kprobe_unwind_v8+0x5584>
    550c:      	ldr	x8, [x24, #0x18]
    5510:      	cmp	x8, x25
    5514:      	b.lo	0x5584 <kprobe_unwind_v8+0x5584>
    5518:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    551c:      	ldr	x8, [x8]
    5520:      	ldr	w8, [x8]
    5524:      	cbz	w8, 0x5564 <kprobe_unwind_v8+0x5564>
    5528:      	adrp	x10, 0x5000 <kprobe_unwind_v8+0x5000>
    552c:      	add	x10, x10, #0x0
    5530:      	add	x0, sp, #0x70
    5534:      	ldp	x8, x9, [x10]
    5538:      	mov	w1, #0x1e               // =30
    553c:      	stp	x8, x9, [sp, #0x70]
    5540:      	ldr	x8, [x10, #0x10]
    5544:      	mov	w9, #0x6                // =6
    5548:      	str	x8, [sp, #0x80]
    554c:      	ldur	x8, [x10, #0x16]
    5550:      	add	x10, sp, #0x70
    5554:      	stur	x8, [sp, #0x86]
    5558:      	mov	w8, #0x1e               // =30
    555c:      	ldrh	w2, [x24, #0x20]
    5560:      	blr	x9
    5564:      	ldrh	w8, [x24, #0x20]
    5568:      	ldr	w9, [x21, #0x1370]
    556c:      	lsr	w8, w9, w8
    5570:      	tbz	w8, #0x0, 0x5590 <kprobe_unwind_v8+0x5590>
    5574:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5578:      	ldr	x8, [x8]
    557c:      	ldr	w8, [x8]
    5580:      	cbnz	w8, 0x55c0 <kprobe_unwind_v8+0x55c0>
    5584:      	mov	w29, #0x1               // =1
    5588:      	b	0x565c <kprobe_unwind_v8+0x565c>
    558c:      	b	0x565c <kprobe_unwind_v8+0x565c>
    5590:      	str	wzr, [sp, #0xbc]
    5594:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    5598:      	mov	w8, #0x1                // =1
    559c:      	add	x9, sp, #0xbc
    55a0:      	ldr	x0, [x0]
    55a4:      	add	x1, sp, #0xbc
    55a8:      	blr	x8
    55ac:      	cbz	x0, 0x5604 <kprobe_unwind_v8+0x5604>
    55b0:      	ldr	x8, [x0]
    55b4:      	add	x8, x8, #0x1
    55b8:      	str	x8, [x0]
    55bc:      	b	0x5658 <kprobe_unwind_v8+0x5658>
    55c0:      	mov	w8, #0x656e             // =25966
    55c4:      	adrp	x10, 0x5000 <kprobe_unwind_v8+0x5000>
    55c8:      	add	x10, x10, #0x0
    55cc:      	add	x0, sp, #0x70
    55d0:      	mov	w1, #0x1b               // =27
    55d4:      	movk	w8, #0xa, lsl #16
    55d8:      	stur	w8, [sp, #0x87]
    55dc:      	ldp	x8, x9, [x10]
    55e0:      	stp	x8, x9, [sp, #0x70]
    55e4:      	ldr	x8, [x10, #0x10]
    55e8:      	mov	w9, #0x6                // =6
    55ec:      	add	x10, sp, #0x70
    55f0:      	str	x8, [sp, #0x80]
    55f4:      	mov	w8, #0x1b               // =27
    55f8:      	blr	x9
    55fc:      	mov	w29, #0x1               // =1
    5600:      	b	0x565c <kprobe_unwind_v8+0x565c>
    5604:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5608:      	ldr	x8, [x8]
    560c:      	ldr	w8, [x8]
    5610:      	cbz	w8, 0x5658 <kprobe_unwind_v8+0x5658>
    5614:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5618:      	add	x8, x8, #0x0
    561c:      	add	x0, sp, #0x70
    5620:      	ldp	x9, x10, [x8, #0x10]
    5624:      	mov	w1, #0x2e               // =46
    5628:      	stp	x9, x10, [sp, #0x80]
    562c:      	ldr	x9, [x8, #0x20]
    5630:      	add	x10, sp, #0x70
    5634:      	str	x9, [sp, #0x90]
    5638:      	ldur	x9, [x8, #0x26]
    563c:      	stur	x9, [sp, #0x96]
    5640:      	ldp	x9, x8, [x8]
    5644:      	stp	x9, x8, [sp, #0x70]
    5648:      	mov	w8, #0x2e               // =46
    564c:      	mov	w9, #0x6                // =6
    5650:      	ldr	w2, [sp, #0xbc]
    5654:      	blr	x9
    5658:      	ldrh	w29, [x24, #0x20]
    565c:      	cmp	w29, #0x7
    5660:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    5664:      	ldr	x8, [x21, #0xed0]
    5668:      	ldr	x29, [x21, #0xed8]
    566c:      	ldr	x25, [x21, #0xee0]
    5670:      	str	x8, [sp, #0x30]
    5674:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5678:      	ldr	x8, [x8]
    567c:      	ldr	w8, [x8]
    5680:      	cbz	w8, 0x56c8 <kprobe_unwind_v8+0x56c8>
    5684:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5688:      	add	x8, x8, #0x0
    568c:      	add	x0, sp, #0x70
    5690:      	ldp	x9, x10, [x8]
    5694:      	mov	w1, #0x1f               // =31
    5698:      	mov	x3, x29
    569c:      	mov	x4, x25
    56a0:      	stp	x9, x10, [sp, #0x70]
    56a4:      	ldr	x9, [x8, #0x10]
    56a8:      	ldur	x8, [x8, #0x17]
    56ac:      	add	x10, sp, #0x70
    56b0:      	str	x9, [sp, #0x80]
    56b4:      	stur	x8, [sp, #0x87]
    56b8:      	mov	w8, #0x1f               // =31
    56bc:      	mov	w9, #0x6                // =6
    56c0:      	ldr	x2, [sp, #0x30]
    56c4:      	blr	x9
    56c8:      	cmp	x25, x29
    56cc:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    56d0:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    56d4:      	cmp	x25, x8
    56d8:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    56dc:      	ldr	x0, [sp, #0x50]
    56e0:      	sub	x2, x25, #0x40
    56e4:      	mov	w8, #0x40               // =64
    56e8:      	mov	w9, #0x70               // =112
    56ec:      	mov	w1, #0x40               // =64
    56f0:      	blr	x9
    56f4:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    56f8:      	ldrb	w9, [x23, #0x14]
    56fc:      	cmp	x9, #0x38
    5700:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    5704:      	ldrb	w8, [x23, #0x15]
    5708:      	cmp	x8, #0x38
    570c:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    5710:      	ldrb	w10, [x23, #0x16]
    5714:      	cmp	x10, #0x38
    5718:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    571c:      	ldr	x11, [sp, #0x50]
    5720:      	ldr	x9, [x11, x9]
    5724:      	tbnz	w9, #0x0, 0x5748 <kprobe_unwind_v8+0x5748>
    5728:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    572c:      	lsr	x24, x9, #1
    5730:      	ldr	x8, [x8]
    5734:      	ldr	w8, [x8]
    5738:      	cbnz	w8, 0x57e4 <kprobe_unwind_v8+0x57e4>
    573c:      	ldrb	w25, [x21, #0xf20]
    5740:      	str	xzr, [sp, #0x40]
    5744:      	b	0x5de8 <kprobe_unwind_v8+0x5de8>
    5748:      	ldr	x9, [sp, #0x50]
    574c:      	ldr	x8, [x9, x8]
    5750:      	ldr	x25, [x9, x10]
    5754:      	and	x9, x8, #0x3
    5758:      	and	x8, x8, #0xfffffffffffffffc
    575c:      	cmp	x9, #0x1
    5760:      	csel	x8, x8, xzr, eq
    5764:      	str	x8, [sp, #0x38]
    5768:      	cbz	x8, 0x582c <kprobe_unwind_v8+0x582c>
    576c:      	ldrb	w8, [x23, #0xc]
    5770:      	ldr	x9, [sp, #0x38]
    5774:      	add	x10, sp, #0x70
    5778:      	add	x0, sp, #0x70
    577c:      	mov	w1, #0x8                // =8
    5780:      	add	x2, x9, x8
    5784:      	mov	w8, #0x8                // =8
    5788:      	mov	w9, #0x70               // =112
    578c:      	blr	x9
    5790:      	cbnz	x0, 0x5828 <kprobe_unwind_v8+0x5828>
    5794:      	ldr	x8, [sp, #0x70]
    5798:      	and	x9, x8, #0x3
    579c:      	cmp	x9, #0x1
    57a0:      	b.ne	0x5828 <kprobe_unwind_v8+0x5828>
    57a4:      	and	x8, x8, #0xfffffffffffffffc
    57a8:      	cbz	x8, 0x582c <kprobe_unwind_v8+0x582c>
    57ac:      	ldrb	w9, [x23, #0xd]
    57b0:      	mov	w10, #0x2               // =2
    57b4:      	mov	w11, #0x70              // =112
    57b8:      	add	x12, sp, #0x70
    57bc:      	add	x0, sp, #0x70
    57c0:      	mov	w1, #0x2                // =2
    57c4:      	add	x9, x8, x9
    57c8:      	ldrb	w9, [x23, #0xd]
    57cc:      	add	x2, x8, x9
    57d0:      	blr	x11
    57d4:      	ldrh	w8, [sp, #0x70]
    57d8:      	cmp	x0, #0x0
    57dc:      	csel	w8, w8, wzr, eq
    57e0:      	b	0x582c <kprobe_unwind_v8+0x582c>
    57e4:      	adrp	x10, 0x5000 <kprobe_unwind_v8+0x5000>
    57e8:      	add	x10, x10, #0x0
    57ec:      	add	x0, sp, #0x70
    57f0:      	ldp	x8, x9, [x10]
    57f4:      	mov	w1, #0x1d               // =29
    57f8:      	mov	x2, x24
    57fc:      	stp	x8, x9, [sp, #0x70]
    5800:      	ldr	x8, [x10, #0x10]
    5804:      	mov	w9, #0x6                // =6
    5808:      	str	x8, [sp, #0x80]
    580c:      	ldur	x8, [x10, #0x15]
    5810:      	add	x10, sp, #0x70
    5814:      	stur	x8, [sp, #0x85]
    5818:      	mov	w8, #0x1d               // =29
    581c:      	blr	x9
    5820:      	str	xzr, [sp, #0x40]
    5824:      	b	0x5d80 <kprobe_unwind_v8+0x5d80>
    5828:      	mov	w8, wzr
    582c:      	ldrh	w9, [x23, #0x4]
    5830:      	cmp	w9, w8, uxth
    5834:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    5838:      	ldrh	w9, [x23, #0x6]
    583c:      	cmp	w9, w8, uxth
    5840:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    5844:      	ldrb	w8, [x23, #0xf]
    5848:      	ldr	x9, [sp, #0x38]
    584c:      	add	x10, sp, #0x70
    5850:      	add	x0, sp, #0x70
    5854:      	mov	w1, #0x8                // =8
    5858:      	add	x2, x9, x8
    585c:      	mov	w8, #0x8                // =8
    5860:      	mov	w9, #0x70               // =112
    5864:      	blr	x9
    5868:      	cbnz	x0, 0x58fc <kprobe_unwind_v8+0x58fc>
    586c:      	ldr	x8, [sp, #0x70]
    5870:      	and	x9, x8, #0x3
    5874:      	cmp	x9, #0x1
    5878:      	b.ne	0x58fc <kprobe_unwind_v8+0x58fc>
    587c:      	and	x8, x8, #0xfffffffffffffffc
    5880:      	mov	x22, x8
    5884:      	cbz	x8, 0x5904 <kprobe_unwind_v8+0x5904>
    5888:      	ldrb	w8, [x23, #0xc]
    588c:      	mov	w9, #0x70               // =112
    5890:      	add	x10, sp, #0x70
    5894:      	add	x0, sp, #0x70
    5898:      	mov	w1, #0x8                // =8
    589c:      	add	x2, x22, x8
    58a0:      	mov	w8, #0x8                // =8
    58a4:      	blr	x9
    58a8:      	cbnz	x0, 0x5900 <kprobe_unwind_v8+0x5900>
    58ac:      	ldr	x8, [sp, #0x70]
    58b0:      	and	x9, x8, #0x3
    58b4:      	cmp	x9, #0x1
    58b8:      	b.ne	0x5900 <kprobe_unwind_v8+0x5900>
    58bc:      	and	x8, x8, #0xfffffffffffffffc
    58c0:      	cbz	x8, 0x5904 <kprobe_unwind_v8+0x5904>
    58c4:      	ldrb	w9, [x23, #0xd]
    58c8:      	mov	w10, #0x2               // =2
    58cc:      	mov	w11, #0x70              // =112
    58d0:      	add	x12, sp, #0x70
    58d4:      	add	x0, sp, #0x70
    58d8:      	mov	w1, #0x2                // =2
    58dc:      	add	x9, x8, x9
    58e0:      	ldrb	w9, [x23, #0xd]
    58e4:      	add	x2, x8, x9
    58e8:      	blr	x11
    58ec:      	ldrh	w8, [sp, #0x70]
    58f0:      	cmp	x0, #0x0
    58f4:      	csel	w8, w8, wzr, eq
    58f8:      	b	0x5904 <kprobe_unwind_v8+0x5904>
    58fc:      	mov	x22, xzr
    5900:      	mov	w8, wzr
    5904:      	ldrh	w9, [x23, #0xa]
    5908:      	cmp	w9, w8, uxth
    590c:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    5910:      	lsr	x24, x25, #32
    5914:      	cbz	x24, 0x5978 <kprobe_unwind_v8+0x5978>
    5918:      	tbnz	w25, #0x0, 0x5978 <kprobe_unwind_v8+0x5978>
    591c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5920:      	ldr	x8, [x8]
    5924:      	ldr	w8, [x8]
    5928:      	cbz	w8, 0x596c <kprobe_unwind_v8+0x596c>
    592c:      	mov	w8, #0x786c             // =30828
    5930:      	add	x0, sp, #0x70
    5934:      	mov	w1, #0x1c               // =28
    5938:      	mov	x2, x24
    593c:      	movk	w8, #0xa, lsl #16
    5940:      	str	w8, [sp, #0x88]
    5944:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5948:      	add	x8, x8, #0x0
    594c:      	ldp	x9, x10, [x8]
    5950:      	ldr	x8, [x8, #0x10]
    5954:      	stp	x9, x10, [sp, #0x70]
    5958:      	mov	w9, #0x6                // =6
    595c:      	str	x8, [sp, #0x80]
    5960:      	mov	w8, #0x1c               // =28
    5964:      	add	x10, sp, #0x70
    5968:      	blr	x9
    596c:      	orr	x8, x22, #0x1
    5970:      	str	x8, [sp, #0x40]
    5974:      	b	0x5d80 <kprobe_unwind_v8+0x5d80>
    5978:      	orr	x8, x22, #0x2
    597c:      	ldr	x9, [sp, #0x38]
    5980:      	add	x10, sp, #0x70
    5984:      	add	x0, sp, #0x70
    5988:      	str	x8, [sp, #0x40]
    598c:      	ldrb	w8, [x23, #0xe]
    5990:      	mov	w1, #0x8                // =8
    5994:      	add	x2, x9, x8
    5998:      	mov	w8, #0x8                // =8
    599c:      	mov	w9, #0x70               // =112
    59a0:      	blr	x9
    59a4:      	cbnz	x0, 0x5a34 <kprobe_unwind_v8+0x5a34>
    59a8:      	ldr	x8, [sp, #0x70]
    59ac:      	and	x9, x8, #0x3
    59b0:      	cmp	x9, #0x1
    59b4:      	b.ne	0x5a34 <kprobe_unwind_v8+0x5a34>
    59b8:      	and	x24, x8, #0xfffffffffffffffc
    59bc:      	cbz	x24, 0x5a38 <kprobe_unwind_v8+0x5a38>
    59c0:      	ldrb	w8, [x23, #0xc]
    59c4:      	mov	w9, #0x70               // =112
    59c8:      	add	x10, sp, #0x70
    59cc:      	add	x0, sp, #0x70
    59d0:      	mov	w1, #0x8                // =8
    59d4:      	add	x2, x24, x8
    59d8:      	mov	w8, #0x8                // =8
    59dc:      	blr	x9
    59e0:      	cbnz	x0, 0x5a38 <kprobe_unwind_v8+0x5a38>
    59e4:      	ldr	x8, [sp, #0x70]
    59e8:      	and	x9, x8, #0x3
    59ec:      	cmp	x9, #0x1
    59f0:      	b.ne	0x5a38 <kprobe_unwind_v8+0x5a38>
    59f4:      	and	x8, x8, #0xfffffffffffffffc
    59f8:      	cbz	x8, 0x5a3c <kprobe_unwind_v8+0x5a3c>
    59fc:      	ldrb	w9, [x23, #0xd]
    5a00:      	mov	w10, #0x2               // =2
    5a04:      	mov	w11, #0x70              // =112
    5a08:      	add	x12, sp, #0x70
    5a0c:      	add	x0, sp, #0x70
    5a10:      	mov	w1, #0x2                // =2
    5a14:      	add	x9, x8, x9
    5a18:      	ldrb	w9, [x23, #0xd]
    5a1c:      	add	x2, x8, x9
    5a20:      	blr	x11
    5a24:      	ldrh	w8, [sp, #0x70]
    5a28:      	cmp	x0, #0x0
    5a2c:      	csel	w8, w8, wzr, eq
    5a30:      	b	0x5a3c <kprobe_unwind_v8+0x5a3c>
    5a34:      	mov	x24, xzr
    5a38:      	mov	w8, wzr
    5a3c:      	and	w4, w8, #0xffff
    5a40:      	ldrh	w8, [x23, #0x8]
    5a44:      	cmp	w4, w8
    5a48:      	b.ne	0x5ae4 <kprobe_unwind_v8+0x5ae4>
    5a4c:      	ldr	x0, [sp, #0x48]
    5a50:      	mov	w8, #0x60               // =96
    5a54:      	mov	w9, #0x70               // =112
    5a58:      	mov	w1, #0x60               // =96
    5a5c:      	mov	x2, x24
    5a60:      	blr	x9
    5a64:      	cbz	x0, 0x5b74 <kprobe_unwind_v8+0x5b74>
    5a68:      	mov	w8, #0x3b               // =59
    5a6c:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    5a70:      	add	x9, sp, #0x58
    5a74:      	str	w8, [sp, #0x58]
    5a78:      	mov	w8, #0x1                // =1
    5a7c:      	add	x1, sp, #0x58
    5a80:      	ldr	x0, [x0]
    5a84:      	blr	x8
    5a88:      	cbnz	x0, 0x5b60 <kprobe_unwind_v8+0x5b60>
    5a8c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5a90:      	ldr	x8, [x8]
    5a94:      	ldr	w8, [x8]
    5a98:      	cbz	w8, 0x5d7c <kprobe_unwind_v8+0x5d7c>
    5a9c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5aa0:      	add	x8, x8, #0x0
    5aa4:      	add	x0, sp, #0x70
    5aa8:      	ldp	x9, x10, [x8, #0x10]
    5aac:      	mov	w1, #0x2e               // =46
    5ab0:      	stp	x9, x10, [sp, #0x80]
    5ab4:      	ldr	x9, [x8, #0x20]
    5ab8:      	add	x10, sp, #0x70
    5abc:      	str	x9, [sp, #0x90]
    5ac0:      	ldur	x9, [x8, #0x26]
    5ac4:      	stur	x9, [sp, #0x96]
    5ac8:      	ldp	x9, x8, [x8]
    5acc:      	stp	x9, x8, [sp, #0x70]
    5ad0:      	mov	w8, #0x2e               // =46
    5ad4:      	mov	w9, #0x6                // =6
    5ad8:      	ldr	w2, [sp, #0x58]
    5adc:      	blr	x9
    5ae0:      	b	0x5d7c <kprobe_unwind_v8+0x5d7c>
    5ae4:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5ae8:      	ldr	x8, [x8]
    5aec:      	ldr	w8, [x8]
    5af0:      	cbz	w8, 0x5b3c <kprobe_unwind_v8+0x5b3c>
    5af4:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5af8:      	add	x8, x8, #0x0
    5afc:      	add	x0, sp, #0x70
    5b00:      	ldp	x9, x10, [x8, #0x10]
    5b04:      	mov	w1, #0x2e               // =46
    5b08:      	mov	x3, x24
    5b0c:      	stp	x9, x10, [sp, #0x80]
    5b10:      	ldr	x9, [x8, #0x20]
    5b14:      	add	x10, sp, #0x70
    5b18:      	str	x9, [sp, #0x90]
    5b1c:      	ldur	x9, [x8, #0x26]
    5b20:      	stur	x9, [sp, #0x96]
    5b24:      	ldp	x9, x8, [x8]
    5b28:      	stp	x9, x8, [sp, #0x70]
    5b2c:      	mov	w8, #0x2e               // =46
    5b30:      	mov	w9, #0x6                // =6
    5b34:      	ldr	x2, [sp, #0x38]
    5b38:      	blr	x9
    5b3c:      	mov	w8, #0x3b               // =59
    5b40:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    5b44:      	add	x9, sp, #0x58
    5b48:      	str	w8, [sp, #0x58]
    5b4c:      	mov	w8, #0x1                // =1
    5b50:      	add	x1, sp, #0x58
    5b54:      	ldr	x0, [x0]
    5b58:      	blr	x8
    5b5c:      	cbz	x0, 0x5ba4 <kprobe_unwind_v8+0x5ba4>
    5b60:      	ldr	x8, [x0]
    5b64:      	mov	x24, xzr
    5b68:      	add	x8, x8, #0x1
    5b6c:      	str	x8, [x0]
    5b70:      	b	0x5d80 <kprobe_unwind_v8+0x5d80>
    5b74:      	ldrb	w8, [x23, #0x12]
    5b78:      	cmp	x8, #0x5c
    5b7c:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    5b80:      	ldrb	w9, [x23, #0x13]
    5b84:      	cmp	x9, #0x5c
    5b88:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    5b8c:      	ldrb	w11, [x23, #0x10]
    5b90:      	ldrb	w10, [x23, #0x11]
    5b94:      	cbz	w11, 0x5bfc <kprobe_unwind_v8+0x5bfc>
    5b98:      	ldr	x11, [sp, #0x48]
    5b9c:      	ldr	x25, [x11, x10]
    5ba0:      	b	0x5c00 <kprobe_unwind_v8+0x5c00>
    5ba4:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5ba8:      	ldr	x8, [x8]
    5bac:      	ldr	w8, [x8]
    5bb0:      	cbz	w8, 0x5d7c <kprobe_unwind_v8+0x5d7c>
    5bb4:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5bb8:      	add	x8, x8, #0x0
    5bbc:      	add	x0, sp, #0x70
    5bc0:      	ldp	x9, x10, [x8, #0x10]
    5bc4:      	mov	w1, #0x2e               // =46
    5bc8:      	stp	x9, x10, [sp, #0x80]
    5bcc:      	ldr	x9, [x8, #0x20]
    5bd0:      	add	x10, sp, #0x70
    5bd4:      	str	x9, [sp, #0x90]
    5bd8:      	ldur	x9, [x8, #0x26]
    5bdc:      	stur	x9, [sp, #0x96]
    5be0:      	ldp	x9, x8, [x8]
    5be4:      	stp	x9, x8, [sp, #0x70]
    5be8:      	mov	w8, #0x2e               // =46
    5bec:      	mov	w9, #0x6                // =6
    5bf0:      	ldr	w2, [sp, #0x58]
    5bf4:      	blr	x9
    5bf8:      	b	0x5d7c <kprobe_unwind_v8+0x5d7c>
    5bfc:      	add	x25, x24, x10
    5c00:      	ldr	x10, [sp, #0x48]
    5c04:      	ldr	w29, [x10, x8]
    5c08:      	ldr	w8, [x10, x9]
    5c0c:      	str	w8, [sp, #0x20]
    5c10:      	ldrb	w8, [x23, #0x18]
    5c14:      	str	w8, [sp, #0x10]
    5c18:      	ldrb	w8, [x23, #0x17]
    5c1c:      	str	x8, [sp, #0x18]
    5c20:      	add	x8, x25, x29
    5c24:      	str	x8, [sp, #0x28]
    5c28:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5c2c:      	ldr	x8, [x8]
    5c30:      	ldr	w8, [x8]
    5c34:      	cbz	w8, 0x5cd4 <kprobe_unwind_v8+0x5cd4>
    5c38:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5c3c:      	add	x8, x8, #0x0
    5c40:      	strb	wzr, [sp, #0x98]
    5c44:      	add	x0, sp, #0x70
    5c48:      	ldp	x9, x10, [x8, #0x10]
    5c4c:      	mov	w1, #0x29               // =41
    5c50:      	mov	x3, x22
    5c54:      	mov	x4, x24
    5c58:      	stp	x9, x10, [sp, #0x80]
    5c5c:      	ldr	x9, [x8, #0x20]
    5c60:      	add	x10, sp, #0x70
    5c64:      	str	x9, [sp, #0x90]
    5c68:      	ldp	x8, x9, [x8]
    5c6c:      	stp	x8, x9, [sp, #0x70]
    5c70:      	mov	w8, #0x29               // =41
    5c74:      	mov	w9, #0x6                // =6
    5c78:      	ldr	x2, [sp, #0x38]
    5c7c:      	blr	x9
    5c80:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5c84:      	ldr	x8, [x8]
    5c88:      	ldr	w8, [x8]
    5c8c:      	cbz	w8, 0x5cd4 <kprobe_unwind_v8+0x5cd4>
    5c90:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5c94:      	add	x8, x8, #0x0
    5c98:      	add	x0, sp, #0x70
    5c9c:      	ldp	x9, x10, [x8, #0x10]
    5ca0:      	mov	w1, #0x25               // =37
    5ca4:      	mov	x2, x25
    5ca8:      	mov	w4, w29
    5cac:      	stp	x9, x10, [sp, #0x80]
    5cb0:      	ldur	x9, [x8, #0x1d]
    5cb4:      	add	x10, sp, #0x70
    5cb8:      	stur	x9, [sp, #0x8d]
    5cbc:      	ldp	x8, x9, [x8]
    5cc0:      	stp	x8, x9, [sp, #0x70]
    5cc4:      	mov	w8, #0x25               // =37
    5cc8:      	mov	w9, #0x6                // =6
    5ccc:      	ldr	x3, [sp, #0x28]
    5cd0:      	blr	x9
    5cd4:      	ldr	x8, [sp, #0x30]
    5cd8:      	subs	x8, x8, x25
    5cdc:      	b.lo	0x5d28 <kprobe_unwind_v8+0x5d28>
    5ce0:      	ldp	x10, x9, [sp, #0x28]
    5ce4:      	cmp	x9, x10
    5ce8:      	b.hs	0x5d28 <kprobe_unwind_v8+0x5d28>
    5cec:      	ldr	w9, [sp, #0x20]
    5cf0:      	ldr	w10, [sp, #0x10]
    5cf4:      	orr	x12, x24, #0x3
    5cf8:      	and	w9, w9, w10
    5cfc:      	ldr	x10, [sp, #0x18]
    5d00:      	ldr	x11, [sp, #0x38]
    5d04:      	orr	x11, x11, #0x4
    5d08:      	lsr	w9, w9, w10
    5d0c:      	ldrb	w10, [x23, #0x19]
    5d10:      	cmp	w9, w10
    5d14:      	orr	w9, w9, w29, lsl #4
    5d18:      	csel	x10, x11, x12, eq
    5d1c:      	orr	x24, x8, x9, lsl #32
    5d20:      	str	x10, [sp, #0x40]
    5d24:      	b	0x5d80 <kprobe_unwind_v8+0x5d80>
    5d28:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5d2c:      	ldr	x8, [x8]
    5d30:      	ldr	w8, [x8]
    5d34:      	cbnz	w8, 0x5d44 <kprobe_unwind_v8+0x5d44>
    5d38:      	ldrb	w25, [x21, #0xf20]
    5d3c:      	mov	x24, xzr
    5d40:      	b	0x5de8 <kprobe_unwind_v8+0x5de8>
    5d44:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5d48:      	add	x8, x8, #0x0
    5d4c:      	add	x0, sp, #0x70
    5d50:      	ldp	x9, x10, [x8, #0x10]
    5d54:      	mov	w1, #0x30               // =48
    5d58:      	stp	x9, x10, [sp, #0x80]
    5d5c:      	ldp	x9, x10, [x8, #0x20]
    5d60:      	stp	x9, x10, [sp, #0x90]
    5d64:      	ldp	x9, x8, [x8]
    5d68:      	add	x10, sp, #0x70
    5d6c:      	stp	x9, x8, [sp, #0x70]
    5d70:      	mov	w8, #0x30               // =48
    5d74:      	mov	w9, #0x6                // =6
    5d78:      	blr	x9
    5d7c:      	mov	x24, xzr
    5d80:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5d84:      	ldr	x8, [x8]
    5d88:      	ldrb	w25, [x21, #0xf20]
    5d8c:      	ldr	w8, [x8]
    5d90:      	cbz	w8, 0x5de8 <kprobe_unwind_v8+0x5de8>
    5d94:      	mov	w8, #0x786c             // =30828
    5d98:      	add	x0, sp, #0x70
    5d9c:      	mov	w1, #0x3c               // =60
    5da0:      	mov	x2, x24
    5da4:      	movk	w8, #0xa, lsl #16
    5da8:      	str	w8, [sp, #0xa8]
    5dac:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5db0:      	add	x8, x8, #0x0
    5db4:      	ldp	x9, x10, [x8, #0x20]
    5db8:      	stp	x9, x10, [sp, #0x90]
    5dbc:      	ldr	x9, [x8, #0x30]
    5dc0:      	str	x9, [sp, #0xa0]
    5dc4:      	ldp	x9, x10, [x8]
    5dc8:      	stp	x9, x10, [sp, #0x70]
    5dcc:      	add	x10, sp, #0x70
    5dd0:      	ldp	x8, x9, [x8, #0x10]
    5dd4:      	stp	x8, x9, [sp, #0x80]
    5dd8:      	mov	w8, #0x3c               // =60
    5ddc:      	mov	w9, #0x6                // =6
    5de0:      	ldr	x3, [sp, #0x40]
    5de4:      	blr	x9
    5de8:      	ldr	w8, [x21, #0x2c0]
    5dec:      	cmp	w8, #0x7e
    5df0:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    5df4:      	add	w9, w8, #0x1
    5df8:      	mov	w10, #0x8               // =8
    5dfc:      	add	x11, sp, #0x70
    5e00:      	str	w9, [x21, #0x2c0]
    5e04:      	mov	w9, #0x18               // =24
    5e08:      	add	x0, sp, #0x70
    5e0c:      	mov	w1, #0x10               // =16
    5e10:      	umaddl	x8, w8, w9, x21
    5e14:      	ldr	x9, [sp, #0x40]
    5e18:      	str	x24, [x8, #0x2d8]
    5e1c:      	strb	w10, [x8, #0x2e0]
    5e20:      	strb	w25, [x8, #0x2e1]
    5e24:      	strh	wzr, [x8, #0x2e6]
    5e28:      	mov	w10, #0x70              // =112
    5e2c:      	str	x9, [x8, #0x2d0]
    5e30:      	add	x9, x8, #0x2d0
    5e34:      	stur	wzr, [x9, #0x12]
    5e38:      	mov	w9, #0x10               // =16
    5e3c:      	ldr	x8, [x21, #0xee0]
    5e40:      	ldr	x2, [x21, #0xee0]
    5e44:      	blr	x10
    5e48:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    5e4c:      	ldr	x8, [x21, #0xee0]
    5e50:      	add	x9, x8, #0x10
    5e54:      	str	x9, [x21, #0xed8]
    5e58:      	ldp	x9, x10, [sp, #0x70]
    5e5c:      	str	x9, [x21, #0xee0]
    5e60:      	mov	w9, #0x101              // =257
    5e64:      	str	x10, [x21, #0xed0]
    5e68:      	strh	w9, [x21, #0xf20]
    5e6c:      	ldr	x9, [sp, #0x40]
    5e70:      	cbnz	x9, 0x5e84 <kprobe_unwind_v8+0x5e84>
    5e74:      	cmp	x24, #0x1
    5e78:      	b.ne	0x5e84 <kprobe_unwind_v8+0x5e84>
    5e7c:      	add	x8, x8, #0xa0
    5e80:      	str	x8, [x21, #0xed8]
    5e84:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5e88:      	ldr	x8, [x8]
    5e8c:      	ldr	w8, [x8]
    5e90:      	cbz	w8, 0x5ed8 <kprobe_unwind_v8+0x5ed8>
    5e94:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5e98:      	add	x8, x8, #0x0
    5e9c:      	add	x0, sp, #0x70
    5ea0:      	ldp	x9, x10, [x8]
    5ea4:      	mov	w1, #0x1f               // =31
    5ea8:      	stp	x9, x10, [sp, #0x70]
    5eac:      	ldr	x9, [x8, #0x10]
    5eb0:      	ldur	x8, [x8, #0x17]
    5eb4:      	add	x10, sp, #0x70
    5eb8:      	str	x9, [sp, #0x80]
    5ebc:      	stur	x8, [sp, #0x87]
    5ec0:      	mov	w8, #0x1f               // =31
    5ec4:      	mov	w9, #0x6                // =6
    5ec8:      	ldr	x2, [x21, #0xed0]
    5ecc:      	ldr	x3, [x21, #0xed8]
    5ed0:      	ldr	x4, [x21, #0xee0]
    5ed4:      	blr	x9
    5ed8:      	mov	w8, #0x38               // =56
    5edc:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    5ee0:      	add	x9, sp, #0x58
    5ee4:      	str	w8, [sp, #0x58]
    5ee8:      	mov	w8, #0x1                // =1
    5eec:      	add	x1, sp, #0x58
    5ef0:      	ldr	x0, [x0]
    5ef4:      	blr	x8
    5ef8:      	cbz	x0, 0x5f0c <kprobe_unwind_v8+0x5f0c>
    5efc:      	ldr	x8, [x0]
    5f00:      	add	x8, x8, #0x1
    5f04:      	str	x8, [x0]
    5f08:      	b	0x5f60 <kprobe_unwind_v8+0x5f60>
    5f0c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5f10:      	ldr	x8, [x8]
    5f14:      	ldr	w8, [x8]
    5f18:      	cbz	w8, 0x5f6c <kprobe_unwind_v8+0x5f6c>
    5f1c:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5f20:      	add	x8, x8, #0x0
    5f24:      	add	x0, sp, #0x70
    5f28:      	ldp	x9, x10, [x8, #0x10]
    5f2c:      	mov	w1, #0x2e               // =46
    5f30:      	stp	x9, x10, [sp, #0x80]
    5f34:      	ldr	x9, [x8, #0x20]
    5f38:      	add	x10, sp, #0x70
    5f3c:      	str	x9, [sp, #0x90]
    5f40:      	ldur	x9, [x8, #0x26]
    5f44:      	stur	x9, [sp, #0x96]
    5f48:      	ldp	x9, x8, [x8]
    5f4c:      	stp	x9, x8, [sp, #0x70]
    5f50:      	mov	w8, #0x2e               // =46
    5f54:      	mov	w9, #0x6                // =6
    5f58:      	ldr	w2, [sp, #0x58]
    5f5c:      	blr	x9
    5f60:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5f64:      	ldr	x8, [x8]
    5f68:      	ldr	w8, [x8]
    5f6c:      	ldr	x24, [x21, #0xed0]
    5f70:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    5f74:      	cbz	w8, 0x5fbc <kprobe_unwind_v8+0x5fbc>
    5f78:      	adrp	x8, 0x5000 <kprobe_unwind_v8+0x5000>
    5f7c:      	add	x8, x8, #0x0
    5f80:      	strb	wzr, [sp, #0xa0]
    5f84:      	add	x0, sp, #0x70
    5f88:      	ldp	x9, x10, [x8, #0x10]
    5f8c:      	mov	w1, #0x31               // =49
    5f90:      	stp	x9, x10, [sp, #0x80]
    5f94:      	ldp	x9, x10, [x8, #0x20]
    5f98:      	stp	x9, x10, [sp, #0x90]
    5f9c:      	ldp	x9, x8, [x8]
    5fa0:      	add	x10, sp, #0x70
    5fa4:      	stp	x9, x8, [sp, #0x70]
    5fa8:      	mov	w8, #0x31               // =49
    5fac:      	mov	w9, #0x6                // =6
    5fb0:      	ldr	w2, [x21, #0x2c0]
    5fb4:      	blr	x9
    5fb8:      	ldr	x24, [x21, #0xed0]
    5fbc:      	lsr	x8, x24, #56
    5fc0:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    5fc4:      	cmp	x24, #0x1, lsl #12      // =0x1000
    5fc8:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    5fcc:      	ldr	w8, [x21]
    5fd0:      	mov	w9, #0x60               // =96
    5fd4:      	adrp	x0, 0x5000 <kprobe_unwind_v8+0x5000>
    5fd8:      	add	x1, sp, #0x58
    5fdc:      	rev	w8, w8
    5fe0:      	stp	w9, w8, [sp, #0x58]
    5fe4:      	rev	x8, x24
    5fe8:      	add	x9, sp, #0x58
    5fec:      	str	x8, [sp, #0x60]
    5ff0:      	mov	w8, #0x1                // =1
    5ff4:      	ldr	x0, [x0]
    5ff8:      	blr	x8
    5ffc:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    6000:      	ldr	x8, [x0, #0x8]
    6004:      	and	x9, x8, #0xffffffffffffff
    6008:      	lsr	x29, x8, #56
    600c:      	str	x9, [x21, #0xf10]
    6010:      	ldr	x8, [x0]
    6014:      	str	x8, [x21, #0xf00]
    6018:      	sub	x8, x24, x9
    601c:      	str	x8, [x21, #0xf08]
    6020:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6024:      	ldr	x8, [x8]
    6028:      	ldr	w8, [x8]
    602c:      	cbz	w8, 0x60d4 <kprobe_unwind_v8+0x60d4>
    6030:      	mov	w8, #0xa                // =10
    6034:      	add	x0, sp, #0x70
    6038:      	mov	w1, #0x32               // =50
    603c:      	strh	w8, [sp, #0xa0]
    6040:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6044:      	add	x8, x8, #0x0
    6048:      	mov	x2, x24
    604c:      	ldp	x9, x10, [x8, #0x10]
    6050:      	mov	w4, w29
    6054:      	stp	x9, x10, [sp, #0x80]
    6058:      	ldp	x9, x10, [x8, #0x20]
    605c:      	stp	x9, x10, [sp, #0x90]
    6060:      	ldp	x9, x8, [x8]
    6064:      	add	x10, sp, #0x70
    6068:      	stp	x9, x8, [sp, #0x70]
    606c:      	mov	w8, #0x32               // =50
    6070:      	mov	w9, #0x6                // =6
    6074:      	ldr	x3, [x21, #0xf00]
    6078:      	blr	x9
    607c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6080:      	ldr	x8, [x8]
    6084:      	ldr	w8, [x8]
    6088:      	cbz	w8, 0x60d4 <kprobe_unwind_v8+0x60d4>
    608c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6090:      	add	x8, x8, #0x0
    6094:      	add	x0, sp, #0x70
    6098:      	ldp	x9, x10, [x8, #0x10]
    609c:      	mov	w1, #0x2f               // =47
    60a0:      	stp	x9, x10, [sp, #0x80]
    60a4:      	ldr	x9, [x8, #0x20]
    60a8:      	add	x10, sp, #0x70
    60ac:      	str	x9, [sp, #0x90]
    60b0:      	ldur	x9, [x8, #0x27]
    60b4:      	stur	x9, [sp, #0x97]
    60b8:      	ldp	x9, x8, [x8]
    60bc:      	stp	x9, x8, [sp, #0x70]
    60c0:      	mov	w8, #0x2f               // =47
    60c4:      	mov	w9, #0x6                // =6
    60c8:      	ldr	x2, [x21, #0xf10]
    60cc:      	ldr	x3, [x21, #0xf08]
    60d0:      	blr	x9
    60d4:      	cmp	w29, #0x1
    60d8:      	b.ne	0x6280 <kprobe_unwind_v8+0x6280>
    60dc:      	ldr	x8, [x21, #0xf00]
    60e0:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    60e4:      	ldr	x25, [x21, #0xf08]
    60e8:      	mov	w9, #0x1                // =1
    60ec:      	add	x1, sp, #0x58
    60f0:      	mov	w29, #0x1               // =1
    60f4:      	str	x8, [sp, #0x58]
    60f8:      	add	x8, sp, #0x58
    60fc:      	ldr	x0, [x0]
    6100:      	blr	x9
    6104:      	cbz	x0, 0x61b0 <kprobe_unwind_v8+0x61b0>
    6108:      	ldr	x8, [x0]
    610c:      	mov	x24, x0
    6110:      	cmp	x8, x25
    6114:      	b.hi	0x6124 <kprobe_unwind_v8+0x6124>
    6118:      	ldr	x8, [x24, #0x8]
    611c:      	cmp	x8, x25
    6120:      	b.hs	0x613c <kprobe_unwind_v8+0x613c>
    6124:      	ldr	x8, [x24, #0x10]
    6128:      	cmp	x8, x25
    612c:      	b.hi	0x61a8 <kprobe_unwind_v8+0x61a8>
    6130:      	ldr	x8, [x24, #0x18]
    6134:      	cmp	x8, x25
    6138:      	b.lo	0x61a8 <kprobe_unwind_v8+0x61a8>
    613c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6140:      	ldr	x8, [x8]
    6144:      	ldr	w8, [x8]
    6148:      	cbz	w8, 0x6188 <kprobe_unwind_v8+0x6188>
    614c:      	adrp	x10, 0x6000 <kprobe_unwind_v8+0x6000>
    6150:      	add	x10, x10, #0x0
    6154:      	add	x0, sp, #0x70
    6158:      	ldp	x8, x9, [x10]
    615c:      	mov	w1, #0x1e               // =30
    6160:      	stp	x8, x9, [sp, #0x70]
    6164:      	ldr	x8, [x10, #0x10]
    6168:      	mov	w9, #0x6                // =6
    616c:      	str	x8, [sp, #0x80]
    6170:      	ldur	x8, [x10, #0x16]
    6174:      	add	x10, sp, #0x70
    6178:      	stur	x8, [sp, #0x86]
    617c:      	mov	w8, #0x1e               // =30
    6180:      	ldrh	w2, [x24, #0x20]
    6184:      	blr	x9
    6188:      	ldrh	w8, [x24, #0x20]
    618c:      	ldr	w9, [x21, #0x1370]
    6190:      	lsr	w8, w9, w8
    6194:      	tbz	w8, #0x0, 0x61b4 <kprobe_unwind_v8+0x61b4>
    6198:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    619c:      	ldr	x8, [x8]
    61a0:      	ldr	w8, [x8]
    61a4:      	cbnz	w8, 0x61e4 <kprobe_unwind_v8+0x61e4>
    61a8:      	mov	w29, #0x1               // =1
    61ac:      	b	0x6280 <kprobe_unwind_v8+0x6280>
    61b0:      	b	0x6280 <kprobe_unwind_v8+0x6280>
    61b4:      	str	wzr, [sp, #0xbc]
    61b8:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    61bc:      	mov	w8, #0x1                // =1
    61c0:      	add	x9, sp, #0xbc
    61c4:      	ldr	x0, [x0]
    61c8:      	add	x1, sp, #0xbc
    61cc:      	blr	x8
    61d0:      	cbz	x0, 0x6228 <kprobe_unwind_v8+0x6228>
    61d4:      	ldr	x8, [x0]
    61d8:      	add	x8, x8, #0x1
    61dc:      	str	x8, [x0]
    61e0:      	b	0x627c <kprobe_unwind_v8+0x627c>
    61e4:      	mov	w8, #0x656e             // =25966
    61e8:      	adrp	x10, 0x6000 <kprobe_unwind_v8+0x6000>
    61ec:      	add	x10, x10, #0x0
    61f0:      	add	x0, sp, #0x70
    61f4:      	mov	w1, #0x1b               // =27
    61f8:      	movk	w8, #0xa, lsl #16
    61fc:      	stur	w8, [sp, #0x87]
    6200:      	ldp	x8, x9, [x10]
    6204:      	stp	x8, x9, [sp, #0x70]
    6208:      	ldr	x8, [x10, #0x10]
    620c:      	mov	w9, #0x6                // =6
    6210:      	add	x10, sp, #0x70
    6214:      	str	x8, [sp, #0x80]
    6218:      	mov	w8, #0x1b               // =27
    621c:      	blr	x9
    6220:      	mov	w29, #0x1               // =1
    6224:      	b	0x6280 <kprobe_unwind_v8+0x6280>
    6228:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    622c:      	ldr	x8, [x8]
    6230:      	ldr	w8, [x8]
    6234:      	cbz	w8, 0x627c <kprobe_unwind_v8+0x627c>
    6238:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    623c:      	add	x8, x8, #0x0
    6240:      	add	x0, sp, #0x70
    6244:      	ldp	x9, x10, [x8, #0x10]
    6248:      	mov	w1, #0x2e               // =46
    624c:      	stp	x9, x10, [sp, #0x80]
    6250:      	ldr	x9, [x8, #0x20]
    6254:      	add	x10, sp, #0x70
    6258:      	str	x9, [sp, #0x90]
    625c:      	ldur	x9, [x8, #0x26]
    6260:      	stur	x9, [sp, #0x96]
    6264:      	ldp	x9, x8, [x8]
    6268:      	stp	x9, x8, [sp, #0x70]
    626c:      	mov	w8, #0x2e               // =46
    6270:      	mov	w9, #0x6                // =6
    6274:      	ldr	w2, [sp, #0xbc]
    6278:      	blr	x9
    627c:      	ldrh	w29, [x24, #0x20]
    6280:      	cmp	w29, #0x7
    6284:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    6288:      	ldr	x8, [x21, #0xed0]
    628c:      	ldr	x29, [x21, #0xed8]
    6290:      	ldr	x25, [x21, #0xee0]
    6294:      	str	x8, [sp, #0x38]
    6298:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    629c:      	ldr	x8, [x8]
    62a0:      	ldr	w8, [x8]
    62a4:      	cbz	w8, 0x62ec <kprobe_unwind_v8+0x62ec>
    62a8:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    62ac:      	add	x8, x8, #0x0
    62b0:      	add	x0, sp, #0x70
    62b4:      	ldp	x9, x10, [x8]
    62b8:      	mov	w1, #0x1f               // =31
    62bc:      	mov	x3, x29
    62c0:      	mov	x4, x25
    62c4:      	stp	x9, x10, [sp, #0x70]
    62c8:      	ldr	x9, [x8, #0x10]
    62cc:      	ldur	x8, [x8, #0x17]
    62d0:      	add	x10, sp, #0x70
    62d4:      	str	x9, [sp, #0x80]
    62d8:      	stur	x8, [sp, #0x87]
    62dc:      	mov	w8, #0x1f               // =31
    62e0:      	mov	w9, #0x6                // =6
    62e4:      	ldr	x2, [sp, #0x38]
    62e8:      	blr	x9
    62ec:      	cmp	x25, x29
    62f0:      	b.lo	0x1954 <kprobe_unwind_v8+0x1954>
    62f4:      	add	x8, x29, #0x2, lsl #12  // =0x2000
    62f8:      	cmp	x25, x8
    62fc:      	b.hs	0x1954 <kprobe_unwind_v8+0x1954>
    6300:      	ldr	x0, [sp, #0x50]
    6304:      	sub	x2, x25, #0x40
    6308:      	mov	w8, #0x40               // =64
    630c:      	mov	w9, #0x70               // =112
    6310:      	mov	w1, #0x40               // =64
    6314:      	blr	x9
    6318:      	cbnz	x0, 0x19c <kprobe_unwind_v8+0x19c>
    631c:      	ldrb	w9, [x23, #0x14]
    6320:      	cmp	x9, #0x38
    6324:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    6328:      	ldrb	w8, [x23, #0x15]
    632c:      	cmp	x8, #0x38
    6330:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    6334:      	ldrb	w10, [x23, #0x16]
    6338:      	cmp	x10, #0x38
    633c:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    6340:      	ldr	x11, [sp, #0x50]
    6344:      	ldr	x9, [x11, x9]
    6348:      	tbnz	w9, #0x0, 0x636c <kprobe_unwind_v8+0x636c>
    634c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6350:      	lsr	x24, x9, #1
    6354:      	ldr	x8, [x8]
    6358:      	ldr	w8, [x8]
    635c:      	cbnz	w8, 0x6408 <kprobe_unwind_v8+0x6408>
    6360:      	ldrb	w23, [x21, #0xf20]
    6364:      	str	xzr, [sp, #0x50]
    6368:      	b	0x6a10 <kprobe_unwind_v8+0x6a10>
    636c:      	ldr	x22, [sp, #0x50]
    6370:      	ldr	x8, [x22, x8]
    6374:      	ldr	x25, [x22, x10]
    6378:      	and	x9, x8, #0x3
    637c:      	and	x8, x8, #0xfffffffffffffffc
    6380:      	cmp	x9, #0x1
    6384:      	csel	x8, x8, xzr, eq
    6388:      	str	x8, [sp, #0x40]
    638c:      	cbz	x8, 0x6450 <kprobe_unwind_v8+0x6450>
    6390:      	ldrb	w8, [x23, #0xc]
    6394:      	ldr	x9, [sp, #0x40]
    6398:      	add	x10, sp, #0x70
    639c:      	add	x0, sp, #0x70
    63a0:      	mov	w1, #0x8                // =8
    63a4:      	add	x2, x9, x8
    63a8:      	mov	w8, #0x8                // =8
    63ac:      	mov	w9, #0x70               // =112
    63b0:      	blr	x9
    63b4:      	cbnz	x0, 0x644c <kprobe_unwind_v8+0x644c>
    63b8:      	ldr	x8, [sp, #0x70]
    63bc:      	and	x9, x8, #0x3
    63c0:      	cmp	x9, #0x1
    63c4:      	b.ne	0x644c <kprobe_unwind_v8+0x644c>
    63c8:      	and	x8, x8, #0xfffffffffffffffc
    63cc:      	cbz	x8, 0x6450 <kprobe_unwind_v8+0x6450>
    63d0:      	ldrb	w9, [x23, #0xd]
    63d4:      	mov	w10, #0x2               // =2
    63d8:      	mov	w11, #0x70              // =112
    63dc:      	add	x12, sp, #0x70
    63e0:      	add	x0, sp, #0x70
    63e4:      	mov	w1, #0x2                // =2
    63e8:      	add	x9, x8, x9
    63ec:      	ldrb	w9, [x23, #0xd]
    63f0:      	add	x2, x8, x9
    63f4:      	blr	x11
    63f8:      	ldrh	w8, [sp, #0x70]
    63fc:      	cmp	x0, #0x0
    6400:      	csel	w8, w8, wzr, eq
    6404:      	b	0x6450 <kprobe_unwind_v8+0x6450>
    6408:      	adrp	x10, 0x6000 <kprobe_unwind_v8+0x6000>
    640c:      	add	x10, x10, #0x0
    6410:      	add	x0, sp, #0x70
    6414:      	ldp	x8, x9, [x10]
    6418:      	mov	w1, #0x1d               // =29
    641c:      	mov	x2, x24
    6420:      	stp	x8, x9, [sp, #0x70]
    6424:      	ldr	x8, [x10, #0x10]
    6428:      	mov	w9, #0x6                // =6
    642c:      	str	x8, [sp, #0x80]
    6430:      	ldur	x8, [x10, #0x15]
    6434:      	add	x10, sp, #0x70
    6438:      	stur	x8, [sp, #0x85]
    643c:      	mov	w8, #0x1d               // =29
    6440:      	blr	x9
    6444:      	str	xzr, [sp, #0x50]
    6448:      	b	0x69a8 <kprobe_unwind_v8+0x69a8>
    644c:      	mov	w8, wzr
    6450:      	ldrh	w9, [x23, #0x4]
    6454:      	cmp	w9, w8, uxth
    6458:      	b.hi	0x3a4 <kprobe_unwind_v8+0x3a4>
    645c:      	ldrh	w9, [x23, #0x6]
    6460:      	cmp	w9, w8, uxth
    6464:      	b.lo	0x3a4 <kprobe_unwind_v8+0x3a4>
    6468:      	ldrb	w8, [x23, #0xf]
    646c:      	ldr	x9, [sp, #0x40]
    6470:      	add	x10, sp, #0x70
    6474:      	add	x0, sp, #0x70
    6478:      	mov	w1, #0x8                // =8
    647c:      	add	x2, x9, x8
    6480:      	mov	w8, #0x8                // =8
    6484:      	mov	w9, #0x70               // =112
    6488:      	blr	x9
    648c:      	cbnz	x0, 0x6520 <kprobe_unwind_v8+0x6520>
    6490:      	ldr	x8, [sp, #0x70]
    6494:      	and	x9, x8, #0x3
    6498:      	cmp	x9, #0x1
    649c:      	b.ne	0x6520 <kprobe_unwind_v8+0x6520>
    64a0:      	and	x8, x8, #0xfffffffffffffffc
    64a4:      	mov	x22, x8
    64a8:      	cbz	x8, 0x6528 <kprobe_unwind_v8+0x6528>
    64ac:      	ldrb	w8, [x23, #0xc]
    64b0:      	mov	w9, #0x70               // =112
    64b4:      	add	x10, sp, #0x70
    64b8:      	add	x0, sp, #0x70
    64bc:      	mov	w1, #0x8                // =8
    64c0:      	add	x2, x22, x8
    64c4:      	mov	w8, #0x8                // =8
    64c8:      	blr	x9
    64cc:      	cbnz	x0, 0x6524 <kprobe_unwind_v8+0x6524>
    64d0:      	ldr	x8, [sp, #0x70]
    64d4:      	and	x9, x8, #0x3
    64d8:      	cmp	x9, #0x1
    64dc:      	b.ne	0x6524 <kprobe_unwind_v8+0x6524>
    64e0:      	and	x8, x8, #0xfffffffffffffffc
    64e4:      	cbz	x8, 0x6528 <kprobe_unwind_v8+0x6528>
    64e8:      	ldrb	w9, [x23, #0xd]
    64ec:      	mov	w10, #0x2               // =2
    64f0:      	mov	w11, #0x70              // =112
    64f4:      	add	x12, sp, #0x70
    64f8:      	add	x0, sp, #0x70
    64fc:      	mov	w1, #0x2                // =2
    6500:      	add	x9, x8, x9
    6504:      	ldrb	w9, [x23, #0xd]
    6508:      	add	x2, x8, x9
    650c:      	blr	x11
    6510:      	ldrh	w8, [sp, #0x70]
    6514:      	cmp	x0, #0x0
    6518:      	csel	w8, w8, wzr, eq
    651c:      	b	0x6528 <kprobe_unwind_v8+0x6528>
    6520:      	mov	x22, xzr
    6524:      	mov	w8, wzr
    6528:      	ldrh	w9, [x23, #0xa]
    652c:      	cmp	w9, w8, uxth
    6530:      	b.ne	0x860 <kprobe_unwind_v8+0x860>
    6534:      	lsr	x24, x25, #32
    6538:      	cbz	x24, 0x659c <kprobe_unwind_v8+0x659c>
    653c:      	tbnz	w25, #0x0, 0x659c <kprobe_unwind_v8+0x659c>
    6540:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6544:      	ldr	x8, [x8]
    6548:      	ldr	w8, [x8]
    654c:      	cbz	w8, 0x6590 <kprobe_unwind_v8+0x6590>
    6550:      	mov	w8, #0x786c             // =30828
    6554:      	add	x0, sp, #0x70
    6558:      	mov	w1, #0x1c               // =28
    655c:      	mov	x2, x24
    6560:      	movk	w8, #0xa, lsl #16
    6564:      	str	w8, [sp, #0x88]
    6568:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    656c:      	add	x8, x8, #0x0
    6570:      	ldp	x9, x10, [x8]
    6574:      	ldr	x8, [x8, #0x10]
    6578:      	stp	x9, x10, [sp, #0x70]
    657c:      	mov	w9, #0x6                // =6
    6580:      	str	x8, [sp, #0x80]
    6584:      	mov	w8, #0x1c               // =28
    6588:      	add	x10, sp, #0x70
    658c:      	blr	x9
    6590:      	orr	x8, x22, #0x1
    6594:      	str	x8, [sp, #0x50]
    6598:      	b	0x69a8 <kprobe_unwind_v8+0x69a8>
    659c:      	orr	x8, x22, #0x2
    65a0:      	ldr	x9, [sp, #0x40]
    65a4:      	add	x10, sp, #0x70
    65a8:      	add	x0, sp, #0x70
    65ac:      	str	x8, [sp, #0x50]
    65b0:      	ldrb	w8, [x23, #0xe]
    65b4:      	mov	w1, #0x8                // =8
    65b8:      	add	x2, x9, x8
    65bc:      	mov	w8, #0x8                // =8
    65c0:      	mov	w9, #0x70               // =112
    65c4:      	blr	x9
    65c8:      	cbnz	x0, 0x6658 <kprobe_unwind_v8+0x6658>
    65cc:      	ldr	x8, [sp, #0x70]
    65d0:      	and	x9, x8, #0x3
    65d4:      	cmp	x9, #0x1
    65d8:      	b.ne	0x6658 <kprobe_unwind_v8+0x6658>
    65dc:      	and	x24, x8, #0xfffffffffffffffc
    65e0:      	cbz	x24, 0x665c <kprobe_unwind_v8+0x665c>
    65e4:      	ldrb	w8, [x23, #0xc]
    65e8:      	mov	w9, #0x70               // =112
    65ec:      	add	x10, sp, #0x70
    65f0:      	add	x0, sp, #0x70
    65f4:      	mov	w1, #0x8                // =8
    65f8:      	add	x2, x24, x8
    65fc:      	mov	w8, #0x8                // =8
    6600:      	blr	x9
    6604:      	cbnz	x0, 0x665c <kprobe_unwind_v8+0x665c>
    6608:      	ldr	x8, [sp, #0x70]
    660c:      	and	x9, x8, #0x3
    6610:      	cmp	x9, #0x1
    6614:      	b.ne	0x665c <kprobe_unwind_v8+0x665c>
    6618:      	and	x8, x8, #0xfffffffffffffffc
    661c:      	cbz	x8, 0x6660 <kprobe_unwind_v8+0x6660>
    6620:      	ldrb	w9, [x23, #0xd]
    6624:      	mov	w10, #0x2               // =2
    6628:      	mov	w11, #0x70              // =112
    662c:      	add	x12, sp, #0x70
    6630:      	add	x0, sp, #0x70
    6634:      	mov	w1, #0x2                // =2
    6638:      	add	x9, x8, x9
    663c:      	ldrb	w9, [x23, #0xd]
    6640:      	add	x2, x8, x9
    6644:      	blr	x11
    6648:      	ldrh	w8, [sp, #0x70]
    664c:      	cmp	x0, #0x0
    6650:      	csel	w8, w8, wzr, eq
    6654:      	b	0x6660 <kprobe_unwind_v8+0x6660>
    6658:      	mov	x24, xzr
    665c:      	mov	w8, wzr
    6660:      	and	w4, w8, #0xffff
    6664:      	ldrh	w8, [x23, #0x8]
    6668:      	cmp	w4, w8
    666c:      	b.ne	0x670c <kprobe_unwind_v8+0x670c>
    6670:      	ldr	x0, [sp, #0x48]
    6674:      	mov	w8, #0x60               // =96
    6678:      	mov	w9, #0x70               // =112
    667c:      	mov	w1, #0x60               // =96
    6680:      	mov	x2, x24
    6684:      	mov	x25, x0
    6688:      	blr	x9
    668c:      	cbz	x0, 0x679c <kprobe_unwind_v8+0x679c>
    6690:      	mov	w8, #0x3b               // =59
    6694:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    6698:      	add	x9, sp, #0x58
    669c:      	str	w8, [sp, #0x58]
    66a0:      	mov	w8, #0x1                // =1
    66a4:      	add	x1, sp, #0x58
    66a8:      	ldr	x0, [x0]
    66ac:      	blr	x8
    66b0:      	cbnz	x0, 0x6788 <kprobe_unwind_v8+0x6788>
    66b4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    66b8:      	ldr	x8, [x8]
    66bc:      	ldr	w8, [x8]
    66c0:      	cbz	w8, 0x69a4 <kprobe_unwind_v8+0x69a4>
    66c4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    66c8:      	add	x8, x8, #0x0
    66cc:      	add	x0, sp, #0x70
    66d0:      	ldp	x9, x10, [x8, #0x10]
    66d4:      	mov	w1, #0x2e               // =46
    66d8:      	stp	x9, x10, [sp, #0x80]
    66dc:      	ldr	x9, [x8, #0x20]
    66e0:      	add	x10, sp, #0x70
    66e4:      	str	x9, [sp, #0x90]
    66e8:      	ldur	x9, [x8, #0x26]
    66ec:      	stur	x9, [sp, #0x96]
    66f0:      	ldp	x9, x8, [x8]
    66f4:      	stp	x9, x8, [sp, #0x70]
    66f8:      	mov	w8, #0x2e               // =46
    66fc:      	mov	w9, #0x6                // =6
    6700:      	ldr	w2, [sp, #0x58]
    6704:      	blr	x9
    6708:      	b	0x69a4 <kprobe_unwind_v8+0x69a4>
    670c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6710:      	ldr	x8, [x8]
    6714:      	ldr	w8, [x8]
    6718:      	cbz	w8, 0x6764 <kprobe_unwind_v8+0x6764>
    671c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6720:      	add	x8, x8, #0x0
    6724:      	add	x0, sp, #0x70
    6728:      	ldp	x9, x10, [x8, #0x10]
    672c:      	mov	w1, #0x2e               // =46
    6730:      	mov	x3, x24
    6734:      	stp	x9, x10, [sp, #0x80]
    6738:      	ldr	x9, [x8, #0x20]
    673c:      	add	x10, sp, #0x70
    6740:      	str	x9, [sp, #0x90]
    6744:      	ldur	x9, [x8, #0x26]
    6748:      	stur	x9, [sp, #0x96]
    674c:      	ldp	x9, x8, [x8]
    6750:      	stp	x9, x8, [sp, #0x70]
    6754:      	mov	w8, #0x2e               // =46
    6758:      	mov	w9, #0x6                // =6
    675c:      	ldr	x2, [sp, #0x40]
    6760:      	blr	x9
    6764:      	mov	w8, #0x3b               // =59
    6768:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    676c:      	add	x9, sp, #0x58
    6770:      	str	w8, [sp, #0x58]
    6774:      	mov	w8, #0x1                // =1
    6778:      	add	x1, sp, #0x58
    677c:      	ldr	x0, [x0]
    6780:      	blr	x8
    6784:      	cbz	x0, 0x67c8 <kprobe_unwind_v8+0x67c8>
    6788:      	ldr	x8, [x0]
    678c:      	mov	x24, xzr
    6790:      	add	x8, x8, #0x1
    6794:      	str	x8, [x0]
    6798:      	b	0x69a8 <kprobe_unwind_v8+0x69a8>
    679c:      	ldrb	w8, [x23, #0x12]
    67a0:      	cmp	x8, #0x5c
    67a4:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    67a8:      	ldrb	w9, [x23, #0x13]
    67ac:      	cmp	x9, #0x5c
    67b0:      	b.hi	0x250 <kprobe_unwind_v8+0x250>
    67b4:      	ldrb	w11, [x23, #0x10]
    67b8:      	ldrb	w10, [x23, #0x11]
    67bc:      	cbz	w11, 0x6820 <kprobe_unwind_v8+0x6820>
    67c0:      	ldr	x29, [x25, x10]
    67c4:      	b	0x6824 <kprobe_unwind_v8+0x6824>
    67c8:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    67cc:      	ldr	x8, [x8]
    67d0:      	ldr	w8, [x8]
    67d4:      	cbz	w8, 0x69a4 <kprobe_unwind_v8+0x69a4>
    67d8:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    67dc:      	add	x8, x8, #0x0
    67e0:      	add	x0, sp, #0x70
    67e4:      	ldp	x9, x10, [x8, #0x10]
    67e8:      	mov	w1, #0x2e               // =46
    67ec:      	stp	x9, x10, [sp, #0x80]
    67f0:      	ldr	x9, [x8, #0x20]
    67f4:      	add	x10, sp, #0x70
    67f8:      	str	x9, [sp, #0x90]
    67fc:      	ldur	x9, [x8, #0x26]
    6800:      	stur	x9, [sp, #0x96]
    6804:      	ldp	x9, x8, [x8]
    6808:      	stp	x9, x8, [sp, #0x70]
    680c:      	mov	w8, #0x2e               // =46
    6810:      	mov	w9, #0x6                // =6
    6814:      	ldr	w2, [sp, #0x58]
    6818:      	blr	x9
    681c:      	b	0x69a4 <kprobe_unwind_v8+0x69a4>
    6820:      	add	x29, x24, x10
    6824:      	mov	x10, x25
    6828:      	ldr	w25, [x25, x8]
    682c:      	ldr	w8, [x10, x9]
    6830:      	str	w8, [sp, #0x30]
    6834:      	ldrb	w8, [x23, #0x18]
    6838:      	str	w8, [sp, #0x20]
    683c:      	ldrb	w8, [x23, #0x17]
    6840:      	str	x8, [sp, #0x28]
    6844:      	add	x8, x29, x25
    6848:      	str	x8, [sp, #0x48]
    684c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6850:      	ldr	x8, [x8]
    6854:      	ldr	w8, [x8]
    6858:      	cbz	w8, 0x68f8 <kprobe_unwind_v8+0x68f8>
    685c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6860:      	add	x8, x8, #0x0
    6864:      	strb	wzr, [sp, #0x98]
    6868:      	add	x0, sp, #0x70
    686c:      	ldp	x9, x10, [x8, #0x10]
    6870:      	mov	w1, #0x29               // =41
    6874:      	mov	x3, x22
    6878:      	mov	x4, x24
    687c:      	stp	x9, x10, [sp, #0x80]
    6880:      	ldr	x9, [x8, #0x20]
    6884:      	add	x10, sp, #0x70
    6888:      	str	x9, [sp, #0x90]
    688c:      	ldp	x8, x9, [x8]
    6890:      	stp	x8, x9, [sp, #0x70]
    6894:      	mov	w8, #0x29               // =41
    6898:      	mov	w9, #0x6                // =6
    689c:      	ldr	x2, [sp, #0x40]
    68a0:      	blr	x9
    68a4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    68a8:      	ldr	x8, [x8]
    68ac:      	ldr	w8, [x8]
    68b0:      	cbz	w8, 0x68f8 <kprobe_unwind_v8+0x68f8>
    68b4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    68b8:      	add	x8, x8, #0x0
    68bc:      	add	x0, sp, #0x70
    68c0:      	ldp	x9, x10, [x8, #0x10]
    68c4:      	mov	w1, #0x25               // =37
    68c8:      	mov	x2, x29
    68cc:      	mov	w4, w25
    68d0:      	stp	x9, x10, [sp, #0x80]
    68d4:      	ldur	x9, [x8, #0x1d]
    68d8:      	add	x10, sp, #0x70
    68dc:      	stur	x9, [sp, #0x8d]
    68e0:      	ldp	x8, x9, [x8]
    68e4:      	stp	x8, x9, [sp, #0x70]
    68e8:      	mov	w8, #0x25               // =37
    68ec:      	mov	w9, #0x6                // =6
    68f0:      	ldr	x3, [sp, #0x48]
    68f4:      	blr	x9
    68f8:      	ldr	x8, [sp, #0x38]
    68fc:      	subs	x8, x8, x29
    6900:      	b.lo	0x6950 <kprobe_unwind_v8+0x6950>
    6904:      	ldr	x9, [sp, #0x38]
    6908:      	ldr	x10, [sp, #0x48]
    690c:      	cmp	x9, x10
    6910:      	b.hs	0x6950 <kprobe_unwind_v8+0x6950>
    6914:      	ldr	w9, [sp, #0x30]
    6918:      	ldr	w10, [sp, #0x20]
    691c:      	orr	x12, x24, #0x3
    6920:      	and	w9, w9, w10
    6924:      	ldr	x10, [sp, #0x28]
    6928:      	ldr	x11, [sp, #0x40]
    692c:      	orr	x11, x11, #0x4
    6930:      	lsr	w9, w9, w10
    6934:      	ldrb	w10, [x23, #0x19]
    6938:      	cmp	w9, w10
    693c:      	orr	w9, w9, w25, lsl #4
    6940:      	csel	x10, x11, x12, eq
    6944:      	orr	x24, x8, x9, lsl #32
    6948:      	str	x10, [sp, #0x50]
    694c:      	b	0x69a8 <kprobe_unwind_v8+0x69a8>
    6950:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6954:      	ldr	x8, [x8]
    6958:      	ldr	w8, [x8]
    695c:      	cbnz	w8, 0x696c <kprobe_unwind_v8+0x696c>
    6960:      	ldrb	w23, [x21, #0xf20]
    6964:      	mov	x24, xzr
    6968:      	b	0x6a10 <kprobe_unwind_v8+0x6a10>
    696c:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6970:      	add	x8, x8, #0x0
    6974:      	add	x0, sp, #0x70
    6978:      	ldp	x9, x10, [x8, #0x10]
    697c:      	mov	w1, #0x30               // =48
    6980:      	stp	x9, x10, [sp, #0x80]
    6984:      	ldp	x9, x10, [x8, #0x20]
    6988:      	stp	x9, x10, [sp, #0x90]
    698c:      	ldp	x9, x8, [x8]
    6990:      	add	x10, sp, #0x70
    6994:      	stp	x9, x8, [sp, #0x70]
    6998:      	mov	w8, #0x30               // =48
    699c:      	mov	w9, #0x6                // =6
    69a0:      	blr	x9
    69a4:      	mov	x24, xzr
    69a8:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    69ac:      	ldr	x8, [x8]
    69b0:      	ldrb	w23, [x21, #0xf20]
    69b4:      	ldr	w8, [x8]
    69b8:      	cbz	w8, 0x6a10 <kprobe_unwind_v8+0x6a10>
    69bc:      	mov	w8, #0x786c             // =30828
    69c0:      	add	x0, sp, #0x70
    69c4:      	mov	w1, #0x3c               // =60
    69c8:      	mov	x2, x24
    69cc:      	movk	w8, #0xa, lsl #16
    69d0:      	str	w8, [sp, #0xa8]
    69d4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    69d8:      	add	x8, x8, #0x0
    69dc:      	ldp	x9, x10, [x8, #0x20]
    69e0:      	stp	x9, x10, [sp, #0x90]
    69e4:      	ldr	x9, [x8, #0x30]
    69e8:      	str	x9, [sp, #0xa0]
    69ec:      	ldp	x9, x10, [x8]
    69f0:      	stp	x9, x10, [sp, #0x70]
    69f4:      	add	x10, sp, #0x70
    69f8:      	ldp	x8, x9, [x8, #0x10]
    69fc:      	stp	x8, x9, [sp, #0x80]
    6a00:      	mov	w8, #0x3c               // =60
    6a04:      	mov	w9, #0x6                // =6
    6a08:      	ldr	x3, [sp, #0x50]
    6a0c:      	blr	x9
    6a10:      	ldr	w8, [x21, #0x2c0]
    6a14:      	cmp	w8, #0x7e
    6a18:      	b.hi	0x2a8 <kprobe_unwind_v8+0x2a8>
    6a1c:      	add	w9, w8, #0x1
    6a20:      	mov	w10, #0x8               // =8
    6a24:      	add	x11, sp, #0x70
    6a28:      	str	w9, [x21, #0x2c0]
    6a2c:      	mov	w9, #0x18               // =24
    6a30:      	add	x0, sp, #0x70
    6a34:      	mov	w1, #0x10               // =16
    6a38:      	umaddl	x8, w8, w9, x21
    6a3c:      	ldr	x9, [sp, #0x50]
    6a40:      	str	x24, [x8, #0x2d8]
    6a44:      	strb	w10, [x8, #0x2e0]
    6a48:      	strb	w23, [x8, #0x2e1]
    6a4c:      	strh	wzr, [x8, #0x2e6]
    6a50:      	mov	w10, #0x70              // =112
    6a54:      	str	x9, [x8, #0x2d0]
    6a58:      	add	x9, x8, #0x2d0
    6a5c:      	stur	wzr, [x9, #0x12]
    6a60:      	mov	w9, #0x10               // =16
    6a64:      	ldr	x8, [x21, #0xee0]
    6a68:      	ldr	x2, [x21, #0xee0]
    6a6c:      	blr	x10
    6a70:      	cbnz	x0, 0x440 <kprobe_unwind_v8+0x440>
    6a74:      	ldr	x8, [x21, #0xee0]
    6a78:      	add	x9, x8, #0x10
    6a7c:      	str	x9, [x21, #0xed8]
    6a80:      	ldp	x9, x10, [sp, #0x70]
    6a84:      	str	x9, [x21, #0xee0]
    6a88:      	mov	w9, #0x101              // =257
    6a8c:      	str	x10, [x21, #0xed0]
    6a90:      	strh	w9, [x21, #0xf20]
    6a94:      	ldr	x9, [sp, #0x50]
    6a98:      	cbnz	x9, 0x6aac <kprobe_unwind_v8+0x6aac>
    6a9c:      	cmp	x24, #0x1
    6aa0:      	b.ne	0x6aac <kprobe_unwind_v8+0x6aac>
    6aa4:      	add	x8, x8, #0xa0
    6aa8:      	str	x8, [x21, #0xed8]
    6aac:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6ab0:      	ldr	x8, [x8]
    6ab4:      	ldr	w8, [x8]
    6ab8:      	cbz	w8, 0x6b00 <kprobe_unwind_v8+0x6b00>
    6abc:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6ac0:      	add	x8, x8, #0x0
    6ac4:      	add	x0, sp, #0x70
    6ac8:      	ldp	x9, x10, [x8]
    6acc:      	mov	w1, #0x1f               // =31
    6ad0:      	stp	x9, x10, [sp, #0x70]
    6ad4:      	ldr	x9, [x8, #0x10]
    6ad8:      	ldur	x8, [x8, #0x17]
    6adc:      	add	x10, sp, #0x70
    6ae0:      	str	x9, [sp, #0x80]
    6ae4:      	stur	x8, [sp, #0x87]
    6ae8:      	mov	w8, #0x1f               // =31
    6aec:      	mov	w9, #0x6                // =6
    6af0:      	ldr	x2, [x21, #0xed0]
    6af4:      	ldr	x3, [x21, #0xed8]
    6af8:      	ldr	x4, [x21, #0xee0]
    6afc:      	blr	x9
    6b00:      	mov	w8, #0x38               // =56
    6b04:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    6b08:      	add	x9, sp, #0x58
    6b0c:      	str	w8, [sp, #0x58]
    6b10:      	mov	w8, #0x1                // =1
    6b14:      	add	x1, sp, #0x58
    6b18:      	ldr	x0, [x0]
    6b1c:      	blr	x8
    6b20:      	cbz	x0, 0x6b34 <kprobe_unwind_v8+0x6b34>
    6b24:      	ldr	x8, [x0]
    6b28:      	add	x8, x8, #0x1
    6b2c:      	str	x8, [x0]
    6b30:      	b	0x6b88 <kprobe_unwind_v8+0x6b88>
    6b34:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6b38:      	ldr	x8, [x8]
    6b3c:      	ldr	w8, [x8]
    6b40:      	cbz	w8, 0x6b94 <kprobe_unwind_v8+0x6b94>
    6b44:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6b48:      	add	x8, x8, #0x0
    6b4c:      	add	x0, sp, #0x70
    6b50:      	ldp	x9, x10, [x8, #0x10]
    6b54:      	mov	w1, #0x2e               // =46
    6b58:      	stp	x9, x10, [sp, #0x80]
    6b5c:      	ldr	x9, [x8, #0x20]
    6b60:      	add	x10, sp, #0x70
    6b64:      	str	x9, [sp, #0x90]
    6b68:      	ldur	x9, [x8, #0x26]
    6b6c:      	stur	x9, [sp, #0x96]
    6b70:      	ldp	x9, x8, [x8]
    6b74:      	stp	x9, x8, [sp, #0x70]
    6b78:      	mov	w8, #0x2e               // =46
    6b7c:      	mov	w9, #0x6                // =6
    6b80:      	ldr	w2, [sp, #0x58]
    6b84:      	blr	x9
    6b88:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6b8c:      	ldr	x8, [x8]
    6b90:      	ldr	w8, [x8]
    6b94:      	ldr	x24, [x21, #0xed0]
    6b98:      	cbz	x24, 0x6dd8 <kprobe_unwind_v8+0x6dd8>
    6b9c:      	cbz	w8, 0x6be4 <kprobe_unwind_v8+0x6be4>
    6ba0:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6ba4:      	add	x8, x8, #0x0
    6ba8:      	strb	wzr, [sp, #0xa0]
    6bac:      	add	x0, sp, #0x70
    6bb0:      	ldp	x9, x10, [x8, #0x10]
    6bb4:      	mov	w1, #0x31               // =49
    6bb8:      	stp	x9, x10, [sp, #0x80]
    6bbc:      	ldp	x9, x10, [x8, #0x20]
    6bc0:      	stp	x9, x10, [sp, #0x90]
    6bc4:      	ldp	x9, x8, [x8]
    6bc8:      	add	x10, sp, #0x70
    6bcc:      	stp	x9, x8, [sp, #0x70]
    6bd0:      	mov	w8, #0x31               // =49
    6bd4:      	mov	w9, #0x6                // =6
    6bd8:      	ldr	w2, [x21, #0x2c0]
    6bdc:      	blr	x9
    6be0:      	ldr	x24, [x21, #0xed0]
    6be4:      	lsr	x8, x24, #56
    6be8:      	cbnz	x8, 0x678 <kprobe_unwind_v8+0x678>
    6bec:      	cmp	x24, #0x1, lsl #12      // =0x1000
    6bf0:      	b.lo	0xf04 <kprobe_unwind_v8+0xf04>
    6bf4:      	ldr	w8, [x21]
    6bf8:      	mov	w9, #0x60               // =96
    6bfc:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    6c00:      	add	x1, sp, #0x58
    6c04:      	rev	w8, w8
    6c08:      	stp	w9, w8, [sp, #0x58]
    6c0c:      	rev	x8, x24
    6c10:      	add	x9, sp, #0x58
    6c14:      	str	x8, [sp, #0x60]
    6c18:      	mov	w8, #0x1                // =1
    6c1c:      	ldr	x0, [x0]
    6c20:      	blr	x8
    6c24:      	cbz	x0, 0x6e00 <kprobe_unwind_v8+0x6e00>
    6c28:      	ldr	x8, [x0, #0x8]
    6c2c:      	and	x9, x8, #0xffffffffffffff
    6c30:      	lsr	x29, x8, #56
    6c34:      	str	x9, [x21, #0xf10]
    6c38:      	ldr	x8, [x0]
    6c3c:      	str	x8, [x21, #0xf00]
    6c40:      	sub	x8, x24, x9
    6c44:      	str	x8, [x21, #0xf08]
    6c48:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6c4c:      	ldr	x8, [x8]
    6c50:      	ldr	w8, [x8]
    6c54:      	cbz	w8, 0x6cfc <kprobe_unwind_v8+0x6cfc>
    6c58:      	mov	w8, #0xa                // =10
    6c5c:      	add	x0, sp, #0x70
    6c60:      	mov	w1, #0x32               // =50
    6c64:      	strh	w8, [sp, #0xa0]
    6c68:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6c6c:      	add	x8, x8, #0x0
    6c70:      	mov	x2, x24
    6c74:      	ldp	x9, x10, [x8, #0x10]
    6c78:      	mov	w4, w29
    6c7c:      	stp	x9, x10, [sp, #0x80]
    6c80:      	ldp	x9, x10, [x8, #0x20]
    6c84:      	stp	x9, x10, [sp, #0x90]
    6c88:      	ldp	x9, x8, [x8]
    6c8c:      	add	x10, sp, #0x70
    6c90:      	stp	x9, x8, [sp, #0x70]
    6c94:      	mov	w8, #0x32               // =50
    6c98:      	mov	w9, #0x6                // =6
    6c9c:      	ldr	x3, [x21, #0xf00]
    6ca0:      	blr	x9
    6ca4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6ca8:      	ldr	x8, [x8]
    6cac:      	ldr	w8, [x8]
    6cb0:      	cbz	w8, 0x6cfc <kprobe_unwind_v8+0x6cfc>
    6cb4:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6cb8:      	add	x8, x8, #0x0
    6cbc:      	add	x0, sp, #0x70
    6cc0:      	ldp	x9, x10, [x8, #0x10]
    6cc4:      	mov	w1, #0x2f               // =47
    6cc8:      	stp	x9, x10, [sp, #0x80]
    6ccc:      	ldr	x9, [x8, #0x20]
    6cd0:      	add	x10, sp, #0x70
    6cd4:      	str	x9, [sp, #0x90]
    6cd8:      	ldur	x9, [x8, #0x27]
    6cdc:      	stur	x9, [sp, #0x97]
    6ce0:      	ldp	x9, x8, [x8]
    6ce4:      	stp	x9, x8, [sp, #0x70]
    6ce8:      	mov	w8, #0x2f               // =47
    6cec:      	mov	w9, #0x6                // =6
    6cf0:      	ldr	x2, [x21, #0xf10]
    6cf4:      	ldr	x3, [x21, #0xf08]
    6cf8:      	blr	x9
    6cfc:      	cmp	w29, #0x1
    6d00:      	b.ne	0x6f80 <kprobe_unwind_v8+0x6f80>
    6d04:      	ldr	x8, [x21, #0xf00]
    6d08:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    6d0c:      	ldr	x24, [x21, #0xf08]
    6d10:      	mov	w9, #0x1                // =1
    6d14:      	add	x1, sp, #0x58
    6d18:      	mov	w29, #0x1               // =1
    6d1c:      	str	x8, [sp, #0x58]
    6d20:      	add	x8, sp, #0x58
    6d24:      	ldr	x0, [x0]
    6d28:      	blr	x9
    6d2c:      	cbz	x0, 0x6eb0 <kprobe_unwind_v8+0x6eb0>
    6d30:      	ldr	x8, [x0]
    6d34:      	mov	x23, x0
    6d38:      	cmp	x8, x24
    6d3c:      	b.hi	0x6d4c <kprobe_unwind_v8+0x6d4c>
    6d40:      	ldr	x8, [x23, #0x8]
    6d44:      	cmp	x8, x24
    6d48:      	b.hs	0x6d64 <kprobe_unwind_v8+0x6d64>
    6d4c:      	ldr	x8, [x23, #0x10]
    6d50:      	cmp	x8, x24
    6d54:      	b.hi	0x6dd0 <kprobe_unwind_v8+0x6dd0>
    6d58:      	ldr	x8, [x23, #0x18]
    6d5c:      	cmp	x8, x24
    6d60:      	b.lo	0x6dd0 <kprobe_unwind_v8+0x6dd0>
    6d64:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6d68:      	ldr	x8, [x8]
    6d6c:      	ldr	w8, [x8]
    6d70:      	cbz	w8, 0x6db0 <kprobe_unwind_v8+0x6db0>
    6d74:      	adrp	x10, 0x6000 <kprobe_unwind_v8+0x6000>
    6d78:      	add	x10, x10, #0x0
    6d7c:      	add	x0, sp, #0x70
    6d80:      	ldp	x8, x9, [x10]
    6d84:      	mov	w1, #0x1e               // =30
    6d88:      	stp	x8, x9, [sp, #0x70]
    6d8c:      	ldr	x8, [x10, #0x10]
    6d90:      	mov	w9, #0x6                // =6
    6d94:      	str	x8, [sp, #0x80]
    6d98:      	ldur	x8, [x10, #0x16]
    6d9c:      	add	x10, sp, #0x70
    6da0:      	stur	x8, [sp, #0x86]
    6da4:      	mov	w8, #0x1e               // =30
    6da8:      	ldrh	w2, [x23, #0x20]
    6dac:      	blr	x9
    6db0:      	ldrh	w8, [x23, #0x20]
    6db4:      	ldr	w9, [x21, #0x1370]
    6db8:      	lsr	w8, w9, w8
    6dbc:      	tbz	w8, #0x0, 0x6eb4 <kprobe_unwind_v8+0x6eb4>
    6dc0:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6dc4:      	ldr	x8, [x8]
    6dc8:      	ldr	w8, [x8]
    6dcc:      	cbnz	w8, 0x6ee4 <kprobe_unwind_v8+0x6ee4>
    6dd0:      	mov	w29, #0x1               // =1
    6dd4:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    6dd8:      	adrp	x24, 0x6000 <kprobe_unwind_v8+0x6000>
    6ddc:      	adrp	x22, 0x6000 <kprobe_unwind_v8+0x6000>
    6de0:      	ldr	x24, [x24]
    6de4:      	ldr	x22, [x22]
    6de8:      	cbnz	w8, 0x6e24 <kprobe_unwind_v8+0x6e24>
    6dec:      	mov	w8, #0x1                // =1
    6df0:      	mov	w29, wzr
    6df4:      	str	w8, [x21, #0xf18]
    6df8:      	mov	w8, #0xfad              // =4013
    6dfc:      	b	0x19ac <kprobe_unwind_v8+0x19ac>
    6e00:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6e04:      	ldr	x8, [x8]
    6e08:      	ldr	w8, [x8]
    6e0c:      	cbnz	w8, 0x6e64 <kprobe_unwind_v8+0x6e64>
    6e10:      	mov	w8, #0xc                // =12
    6e14:      	mov	w29, wzr
    6e18:      	str	w8, [x21, #0xf18]
    6e1c:      	mov	w8, #0xfac              // =4012
    6e20:      	b	0x258 <kprobe_unwind_v8+0x258>
    6e24:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6e28:      	add	x8, x8, #0x0
    6e2c:      	strb	wzr, [sp, #0xa0]
    6e30:      	add	x0, sp, #0x70
    6e34:      	ldp	x9, x10, [x8, #0x10]
    6e38:      	mov	w1, #0x31               // =49
    6e3c:      	stp	x9, x10, [sp, #0x80]
    6e40:      	ldp	x9, x10, [x8, #0x20]
    6e44:      	stp	x9, x10, [sp, #0x90]
    6e48:      	ldp	x9, x8, [x8]
    6e4c:      	add	x10, sp, #0x70
    6e50:      	stp	x9, x8, [sp, #0x70]
    6e54:      	mov	w8, #0x31               // =49
    6e58:      	mov	w9, #0x6                // =6
    6e5c:      	blr	x9
    6e60:      	b	0x6dec <kprobe_unwind_v8+0x6dec>
    6e64:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6e68:      	add	x8, x8, #0x0
    6e6c:      	strb	wzr, [sp, #0xa8]
    6e70:      	add	x0, sp, #0x70
    6e74:      	ldp	x9, x10, [x8, #0x20]
    6e78:      	mov	w1, #0x39               // =57
    6e7c:      	mov	x2, x24
    6e80:      	stp	x9, x10, [sp, #0x90]
    6e84:      	ldr	x9, [x8, #0x30]
    6e88:      	str	x9, [sp, #0xa0]
    6e8c:      	ldp	x9, x10, [x8]
    6e90:      	stp	x9, x10, [sp, #0x70]
    6e94:      	ldp	x8, x9, [x8, #0x10]
    6e98:      	add	x10, sp, #0x70
    6e9c:      	stp	x8, x9, [sp, #0x80]
    6ea0:      	mov	w8, #0x39               // =57
    6ea4:      	mov	w9, #0x6                // =6
    6ea8:      	blr	x9
    6eac:      	b	0x6e10 <kprobe_unwind_v8+0x6e10>
    6eb0:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    6eb4:      	str	wzr, [sp, #0xbc]
    6eb8:      	adrp	x0, 0x6000 <kprobe_unwind_v8+0x6000>
    6ebc:      	mov	w8, #0x1                // =1
    6ec0:      	add	x9, sp, #0xbc
    6ec4:      	ldr	x0, [x0]
    6ec8:      	add	x1, sp, #0xbc
    6ecc:      	blr	x8
    6ed0:      	cbz	x0, 0x6f28 <kprobe_unwind_v8+0x6f28>
    6ed4:      	ldr	x8, [x0]
    6ed8:      	add	x8, x8, #0x1
    6edc:      	str	x8, [x0]
    6ee0:      	b	0x6f7c <kprobe_unwind_v8+0x6f7c>
    6ee4:      	mov	w8, #0x656e             // =25966
    6ee8:      	adrp	x10, 0x6000 <kprobe_unwind_v8+0x6000>
    6eec:      	add	x10, x10, #0x0
    6ef0:      	add	x0, sp, #0x70
    6ef4:      	mov	w1, #0x1b               // =27
    6ef8:      	movk	w8, #0xa, lsl #16
    6efc:      	stur	w8, [sp, #0x87]
    6f00:      	ldp	x8, x9, [x10]
    6f04:      	stp	x8, x9, [sp, #0x70]
    6f08:      	ldr	x8, [x10, #0x10]
    6f0c:      	mov	w9, #0x6                // =6
    6f10:      	add	x10, sp, #0x70
    6f14:      	str	x8, [sp, #0x80]
    6f18:      	mov	w8, #0x1b               // =27
    6f1c:      	blr	x9
    6f20:      	mov	w29, #0x1               // =1
    6f24:      	b	0x6f80 <kprobe_unwind_v8+0x6f80>
    6f28:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6f2c:      	ldr	x8, [x8]
    6f30:      	ldr	w8, [x8]
    6f34:      	cbz	w8, 0x6f7c <kprobe_unwind_v8+0x6f7c>
    6f38:      	adrp	x8, 0x6000 <kprobe_unwind_v8+0x6000>
    6f3c:      	add	x8, x8, #0x0
    6f40:      	add	x0, sp, #0x70
    6f44:      	ldp	x9, x10, [x8, #0x10]
    6f48:      	mov	w1, #0x2e               // =46
    6f4c:      	stp	x9, x10, [sp, #0x80]
    6f50:      	ldr	x9, [x8, #0x20]
    6f54:      	add	x10, sp, #0x70
    6f58:      	str	x9, [sp, #0x90]
    6f5c:      	ldur	x9, [x8, #0x26]
    6f60:      	stur	x9, [sp, #0x96]
    6f64:      	ldp	x9, x8, [x8]
    6f68:      	stp	x9, x8, [sp, #0x70]
    6f6c:      	mov	w8, #0x2e               // =46
    6f70:      	mov	w9, #0x6                // =6
    6f74:      	ldr	w2, [sp, #0xbc]
    6f78:      	blr	x9
    6f7c:      	ldrh	w29, [x23, #0x20]
    6f80:      	mov	w8, wzr
    6f84:      	b	0x258 <kprobe_unwind_v8+0x258>
