
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_loader_v511.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/perf_event_mmap_output:

0000000000000000 <loader_kprobe>:
       0:      	sub	sp, sp, #0x50
       4:      	stp	x30, x23, [sp, #0x20]
       8:      	stp	x22, x21, [sp, #0x30]
       c:      	stp	x20, x19, [sp, #0x40]
      10:      	mov	x19, x0
      14:      	str	wzr, [sp, #0x18]
      18:      	adrp	x0, 0x0 <loader_kprobe>
      1c:      	mov	w8, #0x1                // =1
      20:      	ldr	x0, [x0]
      24:      	add	x9, sp, #0x18
      28:      	add	x1, sp, #0x14
      2c:      	str	wzr, [sp, #0x14]
      30:      	blr	x8
      34:      	cbz	x0, 0x394 <loader_kprobe+0x394>
      38:      	mov	w8, #0x8                // =8
      3c:      	mov	w9, #0x4                // =4
      40:      	add	x10, sp, #0x8
      44:      	mov	x20, x0
      48:      	add	x0, sp, #0x8
      4c:      	mov	w1, #0x8                // =8
      50:      	mov	x2, x19
      54:      	blr	x9
      58:      	ldr	x22, [sp, #0x8]
      5c:      	ldr	x8, [x20, #0x1040]
      60:      	cbz	x8, 0x70 <loader_kprobe+0x70>
      64:      	cmp	x8, x22
      68:      	b.ne	0x394 <loader_kprobe+0x394>
      6c:      	b	0xc8 <loader_kprobe+0xc8>
      70:      	str	wzr, [sp, #0x4]
      74:      	adrp	x0, 0x0 <loader_kprobe>
      78:      	mov	w8, #0x1                // =1
      7c:      	add	x9, sp, #0x4
      80:      	ldr	x0, [x0]
      84:      	mov	x1, sp
      88:      	str	wzr, [sp]
      8c:      	blr	x8
      90:      	cbz	x0, 0x394 <loader_kprobe+0x394>
      94:      	add	x2, x22, #0x3f0
      98:      	mov	w8, #0x8                // =8
      9c:      	mov	w9, #0x4                // =4
      a0:      	add	x10, sp, #0x8
      a4:      	mov	x21, x0
      a8:      	add	x0, sp, #0x8
      ac:      	mov	w1, #0x8                // =8
      b0:      	blr	x9
      b4:      	ldr	x8, [sp, #0x8]
      b8:      	ldr	x9, [x21]
      bc:      	cmp	x9, x8
      c0:      	b.ne	0x394 <loader_kprobe+0x394>
      c4:      	str	x22, [x20, #0x1040]
      c8:      	mov	w8, #0x23               // =35
      cc:      	blr	x8
      d0:      	add	x2, x0, #0x8d4
      d4:      	mov	w8, #0x4                // =4
      d8:      	add	x9, sp, #0x8
      dc:      	add	x0, sp, #0x8
      e0:      	mov	w1, #0x4                // =4
      e4:      	blr	x8
      e8:      	ldr	w21, [sp, #0x8]
      ec:      	adrp	x0, 0x0 <loader_kprobe>
      f0:      	mov	w8, #0x1                // =1
      f4:      	add	x9, sp, #0x8
      f8:      	str	w21, [sp, #0x8]
      fc:      	add	x1, sp, #0x8
     100:      	ldr	x0, [x0]
     104:      	blr	x8
     108:      	cbz	x0, 0x394 <loader_kprobe+0x394>
     10c:      	ldr	w8, [x0]
     110:      	add	x2, x19, #0x8
     114:      	add	x9, sp, #0x8
     118:      	mov	w10, #0x4               // =4
     11c:      	str	w8, [x20, #0x10]
     120:      	mov	w1, #0x8                // =8
     124:      	mov	w23, #0x4               // =4
     128:      	ldr	x8, [x0, #0x8]
     12c:      	add	x0, sp, #0x8
     130:      	str	x8, [x20, #0x18]
     134:      	mov	w8, #0x8                // =8
     138:      	blr	x10
     13c:      	ldr	x22, [sp, #0x8]
     140:      	add	x8, sp, #0x8
     144:      	add	x0, sp, #0x8
     148:      	mov	w1, #0x4                // =4
     14c:      	add	x2, x22, #0x4c
     150:      	blr	x23
     154:      	ldr	w8, [sp, #0x8]
     158:      	str	w8, [x20, #0x24]
     15c:      	cbz	w8, 0x394 <loader_kprobe+0x394>
     160:      	add	x0, x20, #0x2c
     164:      	add	x2, x22, #0x38
     168:      	mov	w8, #0x14               // =20
     16c:      	mov	w9, #0x4                // =4
     170:      	mov	w1, #0x14               // =20
     174:      	mov	w23, #0x4               // =4
     178:      	blr	x9
     17c:      	add	x2, x22, #0x8
     180:      	mov	w8, #0x8                // =8
     184:      	add	x9, sp, #0x8
     188:      	add	x0, sp, #0x8
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x23
     194:      	ldr	x2, [sp, #0x8]
     198:      	add	x0, x20, #0x40
     19c:      	mov	w8, #0x1000             // =4096
     1a0:      	mov	w9, #0x2d               // =45
     1a4:      	mov	w1, #0x1000             // =4096
     1a8:      	blr	x9
     1ac:      	mov	w8, #0x1040             // =4160
     1b0:      	str	w0, [x20, #0x28]
     1b4:      	str	w21, [x20, #0x20]
     1b8:      	str	w8, [x20, #0x4]
     1bc:      	mov	w8, #0x7d               // =125
     1c0:      	blr	x8
     1c4:      	mov	w8, #0x1a               // =26
     1c8:      	str	x0, [x20, #0x8]
     1cc:      	adrp	x0, 0x0 <loader_kprobe>
     1d0:      	add	x9, sp, #0x1c
     1d4:      	strh	w8, [x20]
     1d8:      	mov	w8, #0x1                // =1
     1dc:      	str	wzr, [sp, #0x1c]
     1e0:      	add	x1, sp, #0x1c
     1e4:      	ldr	x0, [x0]
     1e8:      	blr	x8
     1ec:      	cbz	x0, 0x274 <loader_kprobe+0x274>
     1f0:      	ldrb	w8, [x0, #0x28]
     1f4:      	cbz	w8, 0x274 <loader_kprobe+0x274>
     1f8:      	adrp	x1, 0x0 <loader_kprobe>
     1fc:      	mov	w8, #-0x1               // =-1
     200:      	mov	w9, #0x1040             // =4160
     204:      	ldr	x1, [x1]
     208:      	mov	w10, #0x19              // =25
     20c:      	mov	x0, x19
     210:      	mov	w2, #-0x1               // =-1
     214:      	mov	x3, x20
     218:      	mov	w4, #0x1040             // =4160
     21c:      	blr	x10
     220:      	tbz	x0, #0x3f, 0x394 <loader_kprobe+0x394>
     224:      	mov	x19, x0
     228:      	str	wzr, [sp, #0x8]
     22c:      	adrp	x0, 0x0 <loader_kprobe>
     230:      	mov	w8, #0x1                // =1
     234:      	ldr	x0, [x0]
     238:      	add	x9, sp, #0x8
     23c:      	add	x1, sp, #0x8
     240:      	blr	x8
     244:      	cbz	x0, 0x394 <loader_kprobe+0x394>
     248:      	mov	x8, x19
     24c:      	cmn	x19, #0xc
     250:      	b.gt	0x308 <loader_kprobe+0x308>
     254:      	cmn	x8, #0x1c
     258:      	b.eq	0x360 <loader_kprobe+0x360>
     25c:      	cmn	x8, #0x16
     260:      	b.eq	0x378 <loader_kprobe+0x378>
     264:      	cmn	x8, #0x10
     268:      	b.ne	0x370 <loader_kprobe+0x370>
     26c:      	add	x8, x0, #0x5c8
     270:      	b	0x384 <loader_kprobe+0x384>
     274:      	adrp	x0, 0x0 <loader_kprobe>
     278:      	mov	x3, xzr
     27c:      	mov	w8, #0x1040             // =4160
     280:      	ldr	x0, [x0]
     284:      	mov	w9, #0x82               // =130
     288:      	mov	x1, x20
     28c:      	mov	w2, #0x1040             // =4160
     290:      	blr	x9
     294:      	tbz	x0, #0x3f, 0x394 <loader_kprobe+0x394>
     298:      	mov	x19, x0
     29c:      	str	wzr, [sp, #0x8]
     2a0:      	adrp	x0, 0x0 <loader_kprobe>
     2a4:      	mov	w8, #0x1                // =1
     2a8:      	ldr	x0, [x0]
     2ac:      	add	x9, sp, #0x8
     2b0:      	add	x1, sp, #0x8
     2b4:      	blr	x8
     2b8:      	cbz	x0, 0x394 <loader_kprobe+0x394>
     2bc:      	mov	x8, x19
     2c0:      	cmn	x19, #0xc
     2c4:      	b.gt	0x2e8 <loader_kprobe+0x2e8>
     2c8:      	cmn	x8, #0x1c
     2cc:      	b.eq	0x328 <loader_kprobe+0x328>
     2d0:      	cmn	x8, #0x16
     2d4:      	b.eq	0x340 <loader_kprobe+0x340>
     2d8:      	cmn	x8, #0x10
     2dc:      	b.ne	0x338 <loader_kprobe+0x338>
     2e0:      	add	x8, x0, #0x5c8
     2e4:      	b	0x34c <loader_kprobe+0x34c>
     2e8:      	cmn	x8, #0xb
     2ec:      	b.eq	0x330 <loader_kprobe+0x330>
     2f0:      	cmn	x8, #0x7
     2f4:      	b.eq	0x348 <loader_kprobe+0x348>
     2f8:      	cmn	x8, #0x2
     2fc:      	b.ne	0x338 <loader_kprobe+0x338>
     300:      	add	x8, x0, #0x5b8
     304:      	b	0x34c <loader_kprobe+0x34c>
     308:      	cmn	x8, #0xb
     30c:      	b.eq	0x368 <loader_kprobe+0x368>
     310:      	cmn	x8, #0x7
     314:      	b.eq	0x380 <loader_kprobe+0x380>
     318:      	cmn	x8, #0x2
     31c:      	b.ne	0x370 <loader_kprobe+0x370>
     320:      	add	x8, x0, #0x5b8
     324:      	b	0x384 <loader_kprobe+0x384>
     328:      	add	x8, x0, #0x5d8
     32c:      	b	0x34c <loader_kprobe+0x34c>
     330:      	add	x8, x0, #0x5e0
     334:      	b	0x34c <loader_kprobe+0x34c>
     338:      	add	x8, x0, #0x5b0
     33c:      	b	0x34c <loader_kprobe+0x34c>
     340:      	add	x8, x0, #0x5d0
     344:      	b	0x34c <loader_kprobe+0x34c>
     348:      	add	x8, x0, #0x5c0
     34c:      	ldaxr	x9, [x8]
     350:      	add	x9, x9, #0x1
     354:      	stlxr	w10, x9, [x8]
     358:      	cbnz	w10, 0x34c <loader_kprobe+0x34c>
     35c:      	b	0x394 <loader_kprobe+0x394>
     360:      	add	x8, x0, #0x5d8
     364:      	b	0x384 <loader_kprobe+0x384>
     368:      	add	x8, x0, #0x5e0
     36c:      	b	0x384 <loader_kprobe+0x384>
     370:      	add	x8, x0, #0x5b0
     374:      	b	0x384 <loader_kprobe+0x384>
     378:      	add	x8, x0, #0x5d0
     37c:      	b	0x384 <loader_kprobe+0x384>
     380:      	add	x8, x0, #0x5c0
     384:      	ldaxr	x9, [x8]
     388:      	add	x9, x9, #0x1
     38c:      	stlxr	w10, x9, [x8]
     390:      	cbnz	w10, 0x384 <loader_kprobe+0x384>
     394:      	ldp	x20, x19, [sp, #0x40]
     398:      	mov	w0, wzr
     39c:      	ldp	x22, x21, [sp, #0x30]
     3a0:      	ldp	x30, x23, [sp, #0x20]
     3a4:      	add	sp, sp, #0x50
     3a8:      	ret
