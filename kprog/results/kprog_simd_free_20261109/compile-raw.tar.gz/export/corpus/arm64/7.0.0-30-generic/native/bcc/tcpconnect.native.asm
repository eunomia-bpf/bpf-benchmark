
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/tcpconnect.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/tcp_v4_connect:

0000000000000000 <tcp_v4_connect>:
       0:      	sub	sp, sp, #0x20
       4:      	ldr	x8, [x0]
       8:      	stp	x30, x8, [sp, #0x10]
       c:      	bl	0xc <tcp_v4_connect+0xc>
      10:      	str	w0, [sp, #0xc]
      14:      	adrp	x8, 0x0 <tcp_v4_connect>
      18:      	ldr	x8, [x8]
      1c:      	ldr	w9, [x8]
      20:      	cbz	w9, 0x34 <tcp_v4_connect+0x34>
      24:      	ldr	w8, [x8]
      28:      	lsr	x9, x0, #32
      2c:      	cmp	w8, w9
      30:      	b.ne	0x70 <tcp_v4_connect+0x70>
      34:      	bl	0x34 <tcp_v4_connect+0x34>
      38:      	adrp	x8, 0x0 <tcp_v4_connect>
      3c:      	ldr	x8, [x8]
      40:      	ldr	w9, [x8]
      44:      	cmn	w9, #0x1
      48:      	b.eq	0x58 <tcp_v4_connect+0x58>
      4c:      	ldr	w8, [x8]
      50:      	cmp	w8, w0
      54:      	b.ne	0x70 <tcp_v4_connect+0x70>
      58:      	adrp	x0, 0x0 <tcp_v4_connect>
      5c:      	add	x1, sp, #0xc
      60:      	add	x2, sp, #0x18
      64:      	ldr	x0, [x0]
      68:      	mov	x3, xzr
      6c:      	bl	0x6c <tcp_v4_connect+0x6c>
      70:      	ldr	x30, [sp, #0x10]
      74:      	mov	w0, wzr
      78:      	add	sp, sp, #0x20
      7c:      	ret

Disassembly of section kretprobe/tcp_v4_connect:

0000000000000000 <tcp_v4_connect_ret>:
       0:      	sub	sp, sp, #0x90
       4:      	stp	x30, x23, [sp, #0x60]
       8:      	stp	x22, x21, [sp, #0x70]
       c:      	stp	x20, x19, [sp, #0x80]
      10:      	ldr	w20, [x0]
      14:      	mov	x19, x0
      18:      	bl	0x18 <tcp_v4_connect_ret+0x18>
      1c:      	mov	x21, x0
      20:      	strh	wzr, [sp, #0x10]
      24:      	adrp	x0, 0x0 <tcp_v4_connect_ret>
      28:      	add	x1, sp, #0x14
      2c:      	str	w21, [sp, #0x14]
      30:      	ldr	x0, [x0]
      34:      	bl	0x34 <tcp_v4_connect_ret+0x34>
      38:      	cbz	x0, 0x50 <tcp_v4_connect_ret+0x50>
      3c:      	cbz	x20, 0x68 <tcp_v4_connect_ret+0x68>
      40:      	adrp	x0, 0x0 <tcp_v4_connect_ret>
      44:      	add	x1, sp, #0x14
      48:      	ldr	x0, [x0]
      4c:      	bl	0x4c <tcp_v4_connect_ret+0x4c>
      50:      	ldp	x20, x19, [sp, #0x80]
      54:      	mov	w0, wzr
      58:      	ldp	x22, x21, [sp, #0x70]
      5c:      	ldp	x30, x23, [sp, #0x60]
      60:      	add	sp, sp, #0x90
      64:      	ret
      68:      	adrp	x8, 0x0 <tcp_v4_connect_ret>
      6c:      	ldr	x20, [x0]
      70:      	ldr	x8, [x8]
      74:      	ldrb	w8, [x8]
      78:      	cbz	w8, 0x8c <tcp_v4_connect_ret+0x8c>
      7c:      	add	x0, sp, #0x10
      80:      	add	x2, x20, #0xe
      84:      	mov	w1, #0x2                // =2
      88:      	bl	0x88 <tcp_v4_connect_ret+0x88>
      8c:      	add	x0, sp, #0xc
      90:      	add	x2, x20, #0xc
      94:      	mov	w1, #0x2                // =2
      98:      	bl	0x98 <tcp_v4_connect_ret+0x98>
      9c:      	adrp	x8, 0x0 <tcp_v4_connect_ret>
      a0:      	ldrh	w22, [sp, #0xc]
      a4:      	ldr	x8, [x8]
      a8:      	ldr	w9, [x8]
      ac:      	cbz	w9, 0xf0 <tcp_v4_connect_ret+0xf0>
      b0:      	ldr	w9, [x8]
      b4:      	cmp	w9, #0x1
      b8:      	b.lt	0x40 <tcp_v4_connect_ret+0x40>
      bc:      	adrp	x10, 0x0 <tcp_v4_connect_ret>
      c0:      	mov	x9, xzr
      c4:      	ldr	x10, [x10]
      c8:      	ldr	w11, [x10, x9, lsl #2]
      cc:      	cmp	w11, w22
      d0:      	b.eq	0xf0 <tcp_v4_connect_ret+0xf0>
      d4:      	ldrsw	x11, [x8]
      d8:      	cmp	x9, #0x3e
      dc:      	b.hi	0x40 <tcp_v4_connect_ret+0x40>
      e0:      	add	x9, x9, #0x1
      e4:      	cmp	x9, x11
      e8:      	b.lt	0xc8 <tcp_v4_connect_ret+0xc8>
      ec:      	b	0x40 <tcp_v4_connect_ret+0x40>
      f0:      	adrp	x8, 0x0 <tcp_v4_connect_ret>
      f4:      	ldr	x8, [x8]
      f8:      	ldrb	w8, [x8]
      fc:      	ldrh	w23, [sp, #0x10]
     100:      	cbz	w8, 0x160 <tcp_v4_connect_ret+0x160>
     104:      	add	x0, sp, #0x18
     108:      	add	x2, x20, #0x4
     10c:      	mov	w1, #0x4                // =4
     110:      	str	wzr, [sp, #0x20]
     114:      	str	xzr, [sp, #0x18]
     118:      	add	x19, sp, #0x18
     11c:      	bl	0x11c <tcp_v4_connect_ret+0x11c>
     120:      	orr	x0, x19, #0x4
     124:      	mov	w1, #0x4                // =4
     128:      	mov	x2, x20
     12c:      	bl	0x12c <tcp_v4_connect_ret+0x12c>
     130:      	strh	w23, [sp, #0x20]
     134:      	strh	w22, [sp, #0x22]
     138:      	adrp	x0, 0x0 <tcp_v4_connect_ret>
     13c:      	add	x1, sp, #0x18
     140:      	ldr	x0, [x0]
     144:      	bl	0x144 <tcp_v4_connect_ret+0x144>
     148:      	cbz	x0, 0x204 <tcp_v4_connect_ret+0x204>
     14c:      	ldxr	x8, [x0]
     150:      	add	x8, x8, #0x1
     154:      	stxr	w9, x8, [x0]
     158:      	cbnz	w9, 0x14c <tcp_v4_connect_ret+0x14c>
     15c:      	b	0x40 <tcp_v4_connect_ret+0x40>
     160:      	lsr	x8, x21, #32
     164:      	mov	w9, #0x2                // =2
     168:      	stp	xzr, xzr, [sp, #0x50]
     16c:      	add	x21, sp, #0x18
     170:      	str	xzr, [sp, #0x18]
     174:      	stp	xzr, xzr, [sp, #0x40]
     178:      	stp	w9, w8, [sp, #0x50]
     17c:      	stp	xzr, xzr, [sp, #0x30]
     180:      	stp	xzr, xzr, [sp, #0x20]
     184:      	bl	0x184 <tcp_v4_connect_ret+0x184>
     188:      	str	w0, [sp, #0x58]
     18c:      	bl	0x18c <tcp_v4_connect_ret+0x18c>
     190:      	mov	x9, #0xf7cf             // =63439
     194:      	lsr	x8, x0, #3
     198:      	add	x0, sp, #0x18
     19c:      	add	x2, x20, #0x4
     1a0:      	mov	w1, #0x4                // =4
     1a4:      	movk	x9, #0xe353, lsl #16
     1a8:      	movk	x9, #0x9ba5, lsl #32
     1ac:      	movk	x9, #0x20c4, lsl #48
     1b0:      	umulh	x8, x8, x9
     1b4:      	lsr	x8, x8, #4
     1b8:      	str	x8, [sp, #0x48]
     1bc:      	bl	0x1bc <tcp_v4_connect_ret+0x1bc>
     1c0:      	add	x0, x21, #0x10
     1c4:      	mov	w1, #0x4                // =4
     1c8:      	mov	x2, x20
     1cc:      	bl	0x1cc <tcp_v4_connect_ret+0x1cc>
     1d0:      	add	x0, x21, #0x20
     1d4:      	mov	w1, #0x10               // =16
     1d8:      	strh	w23, [sp, #0x5c]
     1dc:      	strh	w22, [sp, #0x5e]
     1e0:      	bl	0x1e0 <tcp_v4_connect_ret+0x1e0>
     1e4:      	adrp	x1, 0x0 <tcp_v4_connect_ret>
     1e8:      	add	x3, sp, #0x18
     1ec:      	mov	x0, x19
     1f0:      	ldr	x1, [x1]
     1f4:      	mov	w2, #-0x1               // =-1
     1f8:      	mov	w4, #0x48               // =72
     1fc:      	bl	0x1fc <tcp_v4_connect_ret+0x1fc>
     200:      	b	0x40 <tcp_v4_connect_ret+0x40>
     204:      	adrp	x0, 0x0 <tcp_v4_connect_ret>
     208:      	adrp	x2, 0x0 <tcp_v4_connect_ret>
     20c:      	add	x2, x2, #0x0
     210:      	ldr	x0, [x0]
     214:      	add	x1, sp, #0x18
     218:      	mov	w3, #0x1                // =1
     21c:      	bl	0x21c <tcp_v4_connect_ret+0x21c>
     220:      	cbz	x0, 0x22c <tcp_v4_connect_ret+0x22c>
     224:      	cmn	x0, #0x11
     228:      	b.ne	0x40 <tcp_v4_connect_ret+0x40>
     22c:      	adrp	x0, 0x0 <tcp_v4_connect_ret>
     230:      	add	x1, sp, #0x18
     234:      	ldr	x0, [x0]
     238:      	bl	0x238 <tcp_v4_connect_ret+0x238>
     23c:      	cbnz	x0, 0x14c <tcp_v4_connect_ret+0x14c>
     240:      	b	0x40 <tcp_v4_connect_ret+0x40>

Disassembly of section kprobe/tcp_v6_connect:

0000000000000000 <tcp_v6_connect>:
       0:      	sub	sp, sp, #0x20
       4:      	ldr	x8, [x0]
       8:      	stp	x30, x8, [sp, #0x10]
       c:      	bl	0xc <tcp_v6_connect+0xc>
      10:      	str	w0, [sp, #0xc]
      14:      	adrp	x8, 0x0 <tcp_v6_connect>
      18:      	ldr	x8, [x8]
      1c:      	ldr	w9, [x8]
      20:      	cbz	w9, 0x34 <tcp_v6_connect+0x34>
      24:      	ldr	w8, [x8]
      28:      	lsr	x9, x0, #32
      2c:      	cmp	w8, w9
      30:      	b.ne	0x70 <tcp_v6_connect+0x70>
      34:      	bl	0x34 <tcp_v6_connect+0x34>
      38:      	adrp	x8, 0x0 <tcp_v6_connect>
      3c:      	ldr	x8, [x8]
      40:      	ldr	w9, [x8]
      44:      	cmn	w9, #0x1
      48:      	b.eq	0x58 <tcp_v6_connect+0x58>
      4c:      	ldr	w8, [x8]
      50:      	cmp	w8, w0
      54:      	b.ne	0x70 <tcp_v6_connect+0x70>
      58:      	adrp	x0, 0x0 <tcp_v6_connect>
      5c:      	add	x1, sp, #0xc
      60:      	add	x2, sp, #0x18
      64:      	ldr	x0, [x0]
      68:      	mov	x3, xzr
      6c:      	bl	0x6c <tcp_v6_connect+0x6c>
      70:      	ldr	x30, [sp, #0x10]
      74:      	mov	w0, wzr
      78:      	add	sp, sp, #0x20
      7c:      	ret

Disassembly of section kretprobe/tcp_v6_connect:

0000000000000000 <tcp_v6_connect_ret>:
       0:      	sub	sp, sp, #0x90
       4:      	stp	x30, x23, [sp, #0x60]
       8:      	stp	x22, x21, [sp, #0x70]
       c:      	stp	x20, x19, [sp, #0x80]
      10:      	ldr	w21, [x0]
      14:      	mov	x19, x0
      18:      	bl	0x18 <tcp_v6_connect_ret+0x18>
      1c:      	mov	x20, x0
      20:      	strh	wzr, [sp, #0x10]
      24:      	adrp	x0, 0x0 <tcp_v6_connect_ret>
      28:      	add	x1, sp, #0x14
      2c:      	str	w20, [sp, #0x14]
      30:      	ldr	x0, [x0]
      34:      	bl	0x34 <tcp_v6_connect_ret+0x34>
      38:      	cbz	x0, 0x50 <tcp_v6_connect_ret+0x50>
      3c:      	cbz	x21, 0x68 <tcp_v6_connect_ret+0x68>
      40:      	adrp	x0, 0x0 <tcp_v6_connect_ret>
      44:      	add	x1, sp, #0x14
      48:      	ldr	x0, [x0]
      4c:      	bl	0x4c <tcp_v6_connect_ret+0x4c>
      50:      	ldp	x20, x19, [sp, #0x80]
      54:      	mov	w0, wzr
      58:      	ldp	x22, x21, [sp, #0x70]
      5c:      	ldp	x30, x23, [sp, #0x60]
      60:      	add	sp, sp, #0x90
      64:      	ret
      68:      	adrp	x8, 0x0 <tcp_v6_connect_ret>
      6c:      	ldr	x21, [x0]
      70:      	ldr	x8, [x8]
      74:      	ldrb	w8, [x8]
      78:      	cbz	w8, 0x8c <tcp_v6_connect_ret+0x8c>
      7c:      	add	x0, sp, #0x10
      80:      	add	x2, x21, #0xe
      84:      	mov	w1, #0x2                // =2
      88:      	bl	0x88 <tcp_v6_connect_ret+0x88>
      8c:      	add	x0, sp, #0xc
      90:      	add	x2, x21, #0xc
      94:      	mov	w1, #0x2                // =2
      98:      	bl	0x98 <tcp_v6_connect_ret+0x98>
      9c:      	adrp	x8, 0x0 <tcp_v6_connect_ret>
      a0:      	ldrh	w22, [sp, #0xc]
      a4:      	ldr	x8, [x8]
      a8:      	ldr	w9, [x8]
      ac:      	cbz	w9, 0xf0 <tcp_v6_connect_ret+0xf0>
      b0:      	ldr	w9, [x8]
      b4:      	cmp	w9, #0x1
      b8:      	b.lt	0x40 <tcp_v6_connect_ret+0x40>
      bc:      	adrp	x10, 0x0 <tcp_v6_connect_ret>
      c0:      	mov	x9, xzr
      c4:      	ldr	x10, [x10]
      c8:      	ldr	w11, [x10, x9, lsl #2]
      cc:      	cmp	w11, w22
      d0:      	b.eq	0xf0 <tcp_v6_connect_ret+0xf0>
      d4:      	ldrsw	x11, [x8]
      d8:      	cmp	x9, #0x3e
      dc:      	b.hi	0x40 <tcp_v6_connect_ret+0x40>
      e0:      	add	x9, x9, #0x1
      e4:      	cmp	x9, x11
      e8:      	b.lt	0xc8 <tcp_v6_connect_ret+0xc8>
      ec:      	b	0x40 <tcp_v6_connect_ret+0x40>
      f0:      	adrp	x8, 0x0 <tcp_v6_connect_ret>
      f4:      	ldr	x8, [x8]
      f8:      	ldrb	w8, [x8]
      fc:      	ldrh	w23, [sp, #0x10]
     100:      	cbz	w8, 0x174 <tcp_v6_connect_ret+0x174>
     104:      	add	x0, sp, #0x18
     108:      	add	x2, x21, #0x48
     10c:      	mov	w1, #0x10               // =16
     110:      	str	wzr, [sp, #0x38]
     114:      	stp	xzr, xzr, [sp, #0x28]
     118:      	add	x19, sp, #0x18
     11c:      	stp	xzr, xzr, [sp, #0x18]
     120:      	bl	0x120 <tcp_v6_connect_ret+0x120>
     124:      	add	x0, x19, #0x10
     128:      	add	x2, x21, #0x38
     12c:      	mov	w1, #0x10               // =16
     130:      	bl	0x130 <tcp_v6_connect_ret+0x130>
     134:      	strh	w23, [sp, #0x38]
     138:      	strh	w22, [sp, #0x3a]
     13c:      	adrp	x0, 0x0 <tcp_v6_connect_ret>
     140:      	add	x1, sp, #0x18
     144:      	ldr	x0, [x0]
     148:      	bl	0x148 <tcp_v6_connect_ret+0x148>
     14c:      	cbz	x0, 0x218 <tcp_v6_connect_ret+0x218>
     150:      	nop
     154:      	nop
     158:      	nop
     15c:      	nop
     160:      	ldxr	x8, [x0]
     164:      	add	x8, x8, #0x1
     168:      	stxr	w9, x8, [x0]
     16c:      	cbnz	w9, 0x160 <tcp_v6_connect_ret+0x160>
     170:      	b	0x40 <tcp_v6_connect_ret+0x40>
     174:      	lsr	x8, x20, #32
     178:      	mov	w9, #0xa                // =10
     17c:      	stp	xzr, xzr, [sp, #0x50]
     180:      	add	x20, sp, #0x18
     184:      	str	xzr, [sp, #0x18]
     188:      	stp	xzr, xzr, [sp, #0x40]
     18c:      	stp	w9, w8, [sp, #0x50]
     190:      	stp	xzr, xzr, [sp, #0x30]
     194:      	stp	xzr, xzr, [sp, #0x20]
     198:      	bl	0x198 <tcp_v6_connect_ret+0x198>
     19c:      	str	w0, [sp, #0x58]
     1a0:      	bl	0x1a0 <tcp_v6_connect_ret+0x1a0>
     1a4:      	mov	x9, #0xf7cf             // =63439
     1a8:      	lsr	x8, x0, #3
     1ac:      	add	x0, sp, #0x18
     1b0:      	add	x2, x21, #0x48
     1b4:      	mov	w1, #0x10               // =16
     1b8:      	movk	x9, #0xe353, lsl #16
     1bc:      	movk	x9, #0x9ba5, lsl #32
     1c0:      	movk	x9, #0x20c4, lsl #48
     1c4:      	umulh	x8, x8, x9
     1c8:      	lsr	x8, x8, #4
     1cc:      	str	x8, [sp, #0x48]
     1d0:      	bl	0x1d0 <tcp_v6_connect_ret+0x1d0>
     1d4:      	add	x0, x20, #0x10
     1d8:      	add	x2, x21, #0x38
     1dc:      	mov	w1, #0x10               // =16
     1e0:      	bl	0x1e0 <tcp_v6_connect_ret+0x1e0>
     1e4:      	add	x0, x20, #0x20
     1e8:      	mov	w1, #0x10               // =16
     1ec:      	strh	w23, [sp, #0x5c]
     1f0:      	strh	w22, [sp, #0x5e]
     1f4:      	bl	0x1f4 <tcp_v6_connect_ret+0x1f4>
     1f8:      	adrp	x1, 0x0 <tcp_v6_connect_ret>
     1fc:      	add	x3, sp, #0x18
     200:      	mov	x0, x19
     204:      	ldr	x1, [x1]
     208:      	mov	w2, #-0x1               // =-1
     20c:      	mov	w4, #0x48               // =72
     210:      	bl	0x210 <tcp_v6_connect_ret+0x210>
     214:      	b	0x40 <tcp_v6_connect_ret+0x40>
     218:      	adrp	x0, 0x0 <tcp_v6_connect_ret>
     21c:      	adrp	x2, 0x0 <tcp_v6_connect_ret>
     220:      	add	x2, x2, #0x0
     224:      	ldr	x0, [x0]
     228:      	add	x1, sp, #0x18
     22c:      	mov	w3, #0x1                // =1
     230:      	bl	0x230 <tcp_v6_connect_ret+0x230>
     234:      	cbz	x0, 0x240 <tcp_v6_connect_ret+0x240>
     238:      	cmn	x0, #0x11
     23c:      	b.ne	0x40 <tcp_v6_connect_ret+0x40>
     240:      	adrp	x0, 0x0 <tcp_v6_connect_ret>
     244:      	add	x1, sp, #0x18
     248:      	ldr	x0, [x0]
     24c:      	bl	0x24c <tcp_v6_connect_ret+0x24c>
     250:      	cbnz	x0, 0x160 <tcp_v6_connect_ret+0x160>
     254:      	b	0x40 <tcp_v6_connect_ret+0x40>
