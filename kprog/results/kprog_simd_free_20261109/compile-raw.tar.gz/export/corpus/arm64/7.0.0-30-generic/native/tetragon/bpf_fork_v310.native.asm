
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_fork_v310.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/wake_up_new_task:

0000000000000000 <event_wake_up_new_task>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	ldr	x23, [x0]
      1c:      	cbz	x23, 0x7f4 <event_wake_up_new_task+0x7f4>
      20:      	add	x2, x23, #0x8d4
      24:      	mov	w8, #0x4                // =4
      28:      	add	x9, sp, #0x38
      2c:      	mov	x19, x0
      30:      	add	x0, sp, #0x38
      34:      	mov	w1, #0x4                // =4
      38:      	blr	x8
      3c:      	ldr	w22, [sp, #0x38]
      40:      	str	x23, [sp, #0x38]
      44:      	add	x8, x23, #0x8e0
      48:      	mov	w9, #0x8                // =8
      4c:      	mov	w10, #0x71              // =113
      50:      	add	x11, sp, #0x38
      54:      	add	x0, sp, #0x38
      58:      	mov	w1, #0x8                // =8
      5c:      	ldr	x8, [sp, #0x38]
      60:      	add	x2, x8, #0x8e0
      64:      	blr	x10
      68:      	ldr	x8, [sp, #0x38]
      6c:      	cbz	x8, 0x7f4 <event_wake_up_new_task+0x7f4>
      70:      	add	x8, x8, #0x8d4
      74:      	mov	w9, #0x4                // =4
      78:      	mov	w10, #0x71              // =113
      7c:      	add	x11, sp, #0x88
      80:      	ldr	x8, [sp, #0x38]
      84:      	add	x0, sp, #0x88
      88:      	mov	w1, #0x4                // =4
      8c:      	add	x2, x8, #0x8d4
      90:      	blr	x10
      94:      	ldr	w8, [sp, #0x88]
      98:      	adrp	x21, 0x0 <event_wake_up_new_task>
      9c:      	add	x9, sp, #0x18
      a0:      	add	x1, sp, #0x18
      a4:      	str	w8, [sp, #0x18]
      a8:      	mov	w8, #0x1                // =1
      ac:      	ldr	x21, [x21]
      b0:      	mov	x0, x21
      b4:      	blr	x8
      b8:      	cbz	x0, 0xc4 <event_wake_up_new_task+0xc4>
      bc:      	ldr	x8, [x0, #0x8]
      c0:      	cbnz	x8, 0x238 <event_wake_up_new_task+0x238>
      c4:      	ldr	x8, [sp, #0x38]
      c8:      	mov	w9, #0x8                // =8
      cc:      	mov	w10, #0x71              // =113
      d0:      	add	x11, sp, #0x38
      d4:      	add	x0, sp, #0x38
      d8:      	mov	w1, #0x8                // =8
      dc:      	add	x8, x8, #0x8e0
      e0:      	ldr	x8, [sp, #0x38]
      e4:      	add	x2, x8, #0x8e0
      e8:      	blr	x10
      ec:      	ldr	x8, [sp, #0x38]
      f0:      	cbz	x8, 0x7f4 <event_wake_up_new_task+0x7f4>
      f4:      	add	x8, x8, #0x8d4
      f8:      	mov	w9, #0x4                // =4
      fc:      	mov	w10, #0x71              // =113
     100:      	add	x11, sp, #0x88
     104:      	ldr	x8, [sp, #0x38]
     108:      	add	x0, sp, #0x88
     10c:      	mov	w1, #0x4                // =4
     110:      	add	x2, x8, #0x8d4
     114:      	blr	x10
     118:      	ldr	w8, [sp, #0x88]
     11c:      	add	x9, sp, #0x18
     120:      	add	x1, sp, #0x18
     124:      	mov	x0, x21
     128:      	str	w8, [sp, #0x18]
     12c:      	mov	w8, #0x1                // =1
     130:      	blr	x8
     134:      	cbz	x0, 0x140 <event_wake_up_new_task+0x140>
     138:      	ldr	x8, [x0, #0x8]
     13c:      	cbnz	x8, 0x238 <event_wake_up_new_task+0x238>
     140:      	ldr	x8, [sp, #0x38]
     144:      	mov	w9, #0x8                // =8
     148:      	mov	w10, #0x71              // =113
     14c:      	add	x11, sp, #0x38
     150:      	add	x0, sp, #0x38
     154:      	mov	w1, #0x8                // =8
     158:      	add	x8, x8, #0x8e0
     15c:      	ldr	x8, [sp, #0x38]
     160:      	add	x2, x8, #0x8e0
     164:      	blr	x10
     168:      	ldr	x8, [sp, #0x38]
     16c:      	cbz	x8, 0x7f4 <event_wake_up_new_task+0x7f4>
     170:      	add	x8, x8, #0x8d4
     174:      	mov	w9, #0x4                // =4
     178:      	mov	w10, #0x71              // =113
     17c:      	add	x11, sp, #0x88
     180:      	ldr	x8, [sp, #0x38]
     184:      	add	x0, sp, #0x88
     188:      	mov	w1, #0x4                // =4
     18c:      	add	x2, x8, #0x8d4
     190:      	blr	x10
     194:      	ldr	w8, [sp, #0x88]
     198:      	add	x9, sp, #0x18
     19c:      	add	x1, sp, #0x18
     1a0:      	mov	x0, x21
     1a4:      	str	w8, [sp, #0x18]
     1a8:      	mov	w8, #0x1                // =1
     1ac:      	blr	x8
     1b0:      	cbz	x0, 0x1bc <event_wake_up_new_task+0x1bc>
     1b4:      	ldr	x8, [x0, #0x8]
     1b8:      	cbnz	x8, 0x238 <event_wake_up_new_task+0x238>
     1bc:      	ldr	x8, [sp, #0x38]
     1c0:      	mov	w9, #0x8                // =8
     1c4:      	mov	w10, #0x71              // =113
     1c8:      	add	x11, sp, #0x38
     1cc:      	add	x0, sp, #0x38
     1d0:      	mov	w1, #0x8                // =8
     1d4:      	add	x8, x8, #0x8e0
     1d8:      	ldr	x8, [sp, #0x38]
     1dc:      	add	x2, x8, #0x8e0
     1e0:      	blr	x10
     1e4:      	ldr	x8, [sp, #0x38]
     1e8:      	cbz	x8, 0x7f4 <event_wake_up_new_task+0x7f4>
     1ec:      	add	x8, x8, #0x8d4
     1f0:      	mov	w9, #0x4                // =4
     1f4:      	mov	w10, #0x71              // =113
     1f8:      	add	x11, sp, #0x88
     1fc:      	ldr	x8, [sp, #0x38]
     200:      	add	x0, sp, #0x88
     204:      	mov	w1, #0x4                // =4
     208:      	add	x2, x8, #0x8d4
     20c:      	blr	x10
     210:      	ldr	w8, [sp, #0x88]
     214:      	add	x9, sp, #0x18
     218:      	add	x1, sp, #0x18
     21c:      	mov	x0, x21
     220:      	str	w8, [sp, #0x18]
     224:      	mov	w8, #0x1                // =1
     228:      	blr	x8
     22c:      	cbz	x0, 0x7f4 <event_wake_up_new_task+0x7f4>
     230:      	ldr	x8, [x0, #0x8]
     234:      	cbz	x8, 0x7f4 <event_wake_up_new_task+0x7f4>
     238:      	str	x0, [sp, #0x10]
     23c:      	str	w22, [sp, #0x18]
     240:      	mov	w8, #0x1                // =1
     244:      	add	x9, sp, #0x18
     248:      	add	x1, sp, #0x18
     24c:      	mov	x0, x21
     250:      	blr	x8
     254:      	cbz	x0, 0x4d4 <event_wake_up_new_task+0x4d4>
     258:      	mov	x20, x0
     25c:      	ldr	x8, [x20, #0x8]
     260:      	cbnz	x8, 0x7f4 <event_wake_up_new_task+0x7f4>
     264:      	mov	w8, #0x1                // =1
     268:      	str	w22, [x20]
     26c:      	str	w8, [x20, #0x20]
     270:      	mov	w8, #0x5                // =5
     274:      	blr	x8
     278:      	str	x0, [x20, #0x8]
     27c:      	add	x2, x23, #0x60
     280:      	mov	w8, #0x8                // =8
     284:      	mov	w9, #0x71               // =113
     288:      	add	x10, sp, #0x18
     28c:      	add	x0, sp, #0x18
     290:      	mov	w1, #0x8                // =8
     294:      	blr	x9
     298:      	ldr	x8, [sp, #0x18]
     29c:      	cbz	x8, 0x30c <event_wake_up_new_task+0x30c>
     2a0:      	add	x8, x8, #0x4
     2a4:      	mov	w9, #0x4                // =4
     2a8:      	mov	w10, #0x71              // =113
     2ac:      	add	x11, sp, #0x88
     2b0:      	ldr	x8, [sp, #0x18]
     2b4:      	add	x0, sp, #0x88
     2b8:      	mov	w1, #0x4                // =4
     2bc:      	add	x2, x8, #0x4
     2c0:      	blr	x10
     2c4:      	ldr	w8, [sp, #0x88]
     2c8:      	cbz	w8, 0x30c <event_wake_up_new_task+0x30c>
     2cc:      	ldr	x9, [sp, #0x18]
     2d0:      	lsl	w8, w8, #4
     2d4:      	mov	w10, #0x71              // =113
     2d8:      	add	x11, sp, #0x38
     2dc:      	add	x0, sp, #0x38
     2e0:      	mov	w1, #0x10               // =16
     2e4:      	add	x8, x9, x8
     2e8:      	mov	w9, #0x10               // =16
     2ec:      	add	x8, x8, #0x80
     2f0:      	ldr	w9, [sp, #0x88]
     2f4:      	ldr	x8, [sp, #0x18]
     2f8:      	lsl	w9, w9, #4
     2fc:      	add	x8, x8, x9
     300:      	add	x2, x8, #0x80
     304:      	blr	x10
     308:      	ldr	w8, [sp, #0x38]
     30c:      	ldr	x21, [sp, #0x10]
     310:      	add	x0, x20, #0x68
     314:      	mov	w2, #0x318              // =792
     318:      	str	w8, [x20, #0x24]
     31c:      	add	x1, x21, #0x68
     320:      	bl	0x320 <event_wake_up_new_task+0x320>
     324:      	ldp	x9, x8, [x21]
     328:      	mov	x25, x20
     32c:      	add	x2, x23, #0xae0
     330:      	mov	w24, #0x8               // =8
     334:      	add	x0, sp, #0x38
     338:      	mov	w1, #0x8                // =8
     33c:      	mov	w29, #0x4               // =4
     340:      	stp	x9, x8, [x25, #0x10]!
     344:      	add	x8, sp, #0x38
     348:      	mov	w9, #0x4                // =4
     34c:      	add	x22, x25, #0x40
     350:      	str	x2, [sp, #0x8]
     354:      	blr	x9
     358:      	ldr	x21, [sp, #0x38]
     35c:      	add	x0, x25, #0x48
     360:      	mov	w8, #0x4                // =4
     364:      	mov	w1, #0x8                // =8
     368:      	add	x2, x21, #0x40
     36c:      	blr	x8
     370:      	add	x0, x25, #0x50
     374:      	add	x2, x21, #0x30
     378:      	mov	w8, #0x4                // =4
     37c:      	mov	w1, #0x8                // =8
     380:      	blr	x8
     384:      	add	x2, x21, #0x38
     388:      	mov	w8, #0x4                // =4
     38c:      	mov	x0, x22
     390:      	mov	w1, #0x8                // =8
     394:      	blr	x8
     398:      	add	x2, x23, #0xb50
     39c:      	add	x8, sp, #0x88
     3a0:      	mov	w9, #0x4                // =4
     3a4:      	add	x0, sp, #0x88
     3a8:      	mov	w1, #0x8                // =8
     3ac:      	add	x22, x25, #0x18
     3b0:      	blr	x9
     3b4:      	ldr	x8, [sp, #0x88]
     3b8:      	mov	w9, #0x48               // =72
     3bc:      	add	x10, sp, #0x38
     3c0:      	mov	w11, #0x4               // =4
     3c4:      	ldr	x2, [sp, #0x88]
     3c8:      	add	x0, sp, #0x38
     3cc:      	mov	w1, #0x48               // =72
     3d0:      	blr	x11
     3d4:      	ldr	x8, [sp, #0x40]
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	x0, x22
     3e0:      	mov	w1, #0x4                // =4
     3e4:      	add	x8, x8, #0x218
     3e8:      	ldr	x8, [sp, #0x40]
     3ec:      	add	x2, x8, #0x218
     3f0:      	blr	x9
     3f4:      	ldr	x8, [sp, #0x48]
     3f8:      	add	x0, x25, #0x1c
     3fc:      	mov	w9, #0x4                // =4
     400:      	mov	w1, #0x4                // =4
     404:      	add	x8, x8, #0x4d8
     408:      	ldr	x8, [sp, #0x48]
     40c:      	add	x2, x8, #0x4d8
     410:      	blr	x9
     414:      	ldr	x8, [sp, #0x50]
     418:      	add	x0, x25, #0x20
     41c:      	mov	w9, #0x4                // =4
     420:      	mov	w1, #0x4                // =4
     424:      	add	x8, x8, #0x58
     428:      	ldr	x8, [sp, #0x50]
     42c:      	add	x2, x8, #0x58
     430:      	blr	x9
     434:      	str	xzr, [sp, #0x30]
     438:      	add	x2, x23, #0x938
     43c:      	add	x8, sp, #0x30
     440:      	add	x0, sp, #0x30
     444:      	mov	w1, #0x8                // =8
     448:      	blr	x29
     44c:      	ldr	x8, [sp, #0x30]
     450:      	cbz	x8, 0x570 <event_wake_up_new_task+0x570>
     454:      	str	wzr, [sp, #0x2c]
     458:      	add	x8, x8, #0x4
     45c:      	add	x9, sp, #0x2c
     460:      	mov	w10, #0x4               // =4
     464:      	add	x0, sp, #0x2c
     468:      	mov	w1, #0x4                // =4
     46c:      	mov	w21, #0x4               // =4
     470:      	ldr	x8, [sp, #0x30]
     474:      	add	x2, x8, #0x4
     478:      	blr	x10
     47c:      	ldr	x8, [sp, #0x30]
     480:      	ldrsw	x9, [sp, #0x2c]
     484:      	add	x10, sp, #0x18
     488:      	mov	w11, #0x4               // =4
     48c:      	add	x0, sp, #0x18
     490:      	mov	w1, #0x10               // =16
     494:      	add	x8, x8, x9, lsl #4
     498:      	mov	w9, #0x10               // =16
     49c:      	add	x8, x8, #0x80
     4a0:      	ldr	x8, [sp, #0x30]
     4a4:      	ldrsw	x9, [sp, #0x2c]
     4a8:      	add	x8, x8, x9, lsl #4
     4ac:      	add	x2, x8, #0x80
     4b0:      	blr	x11
     4b4:      	ldr	x8, [sp, #0x20]
     4b8:      	add	x0, x20, #0x34
     4bc:      	mov	w1, #0x4                // =4
     4c0:      	add	x8, x8, #0x158
     4c4:      	ldr	x8, [sp, #0x20]
     4c8:      	add	x2, x8, #0x158
     4cc:      	blr	x21
     4d0:      	b	0x574 <event_wake_up_new_task+0x574>
     4d4:      	str	wzr, [sp, #0x88]
     4d8:      	adrp	x0, 0x0 <event_wake_up_new_task>
     4dc:      	mov	w8, #0x1                // =1
     4e0:      	add	x9, sp, #0x88
     4e4:      	ldr	x0, [x0]
     4e8:      	add	x1, sp, #0x88
     4ec:      	blr	x8
     4f0:      	cbz	x0, 0x7f4 <event_wake_up_new_task+0x7f4>
     4f4:      	mov	w1, wzr
     4f8:      	mov	w2, #0x380              // =896
     4fc:      	mov	x20, x0
     500:      	bl	0x500 <event_wake_up_new_task+0x500>
     504:      	mov	x3, xzr
     508:      	mov	w8, #0x2                // =2
     50c:      	add	x9, sp, #0x18
     510:      	add	x1, sp, #0x18
     514:      	mov	x0, x21
     518:      	mov	x2, x20
     51c:      	blr	x8
     520:      	cbz	w0, 0x77c <event_wake_up_new_task+0x77c>
     524:      	mov	w8, #0x1                // =1
     528:      	adrp	x0, 0x0 <event_wake_up_new_task>
     52c:      	add	x9, sp, #0x38
     530:      	str	w8, [sp, #0x38]
     534:      	ldr	x0, [x0]
     538:      	add	x1, sp, #0x38
     53c:      	blr	x8
     540:      	cbz	x0, 0x550 <event_wake_up_new_task+0x550>
     544:      	ldr	x8, [x0]
     548:      	add	x8, x8, #0x1
     54c:      	str	x8, [x0]
     550:      	mov	w8, #0x1                // =1
     554:      	add	x9, sp, #0x18
     558:      	add	x1, sp, #0x18
     55c:      	mov	x0, x21
     560:      	blr	x8
     564:      	mov	x20, x0
     568:      	cbnz	x0, 0x25c <event_wake_up_new_task+0x25c>
     56c:      	b	0x7f4 <event_wake_up_new_task+0x7f4>
     570:      	str	wzr, [x20, #0x34]
     574:      	ldr	x8, [sp, #0x58]
     578:      	add	x0, x20, #0x38
     57c:      	mov	w9, #0x4                // =4
     580:      	mov	w1, #0x4                // =4
     584:      	mov	w22, #0x4               // =4
     588:      	add	x8, x8, #0x158
     58c:      	ldr	x8, [sp, #0x58]
     590:      	add	x2, x8, #0x158
     594:      	blr	x9
     598:      	ldr	x8, [sp, #0x60]
     59c:      	add	x0, x20, #0x3c
     5a0:      	mov	w9, #0x4                // =4
     5a4:      	mov	w1, #0x4                // =4
     5a8:      	add	x8, x8, #0x118
     5ac:      	ldr	x8, [sp, #0x60]
     5b0:      	add	x2, x8, #0x118
     5b4:      	blr	x9
     5b8:      	ldr	x8, [sp, #0x68]
     5bc:      	add	x0, x20, #0x40
     5c0:      	mov	w9, #0x4                // =4
     5c4:      	mov	w1, #0x4                // =4
     5c8:      	add	x8, x8, #0x98
     5cc:      	ldr	x8, [sp, #0x68]
     5d0:      	add	x2, x8, #0x98
     5d4:      	blr	x9
     5d8:      	ldr	x8, [sp, #0x70]
     5dc:      	add	x0, x20, #0x44
     5e0:      	mov	w9, #0x4                // =4
     5e4:      	mov	w1, #0x4                // =4
     5e8:      	add	x8, x8, #0x98
     5ec:      	ldr	x8, [sp, #0x70]
     5f0:      	add	x2, x8, #0x98
     5f4:      	blr	x9
     5f8:      	ldr	x8, [sp, #0x78]
     5fc:      	add	x0, x20, #0x48
     600:      	mov	w9, #0x4                // =4
     604:      	mov	w1, #0x4                // =4
     608:      	add	x8, x8, #0x58
     60c:      	ldr	x8, [sp, #0x78]
     610:      	add	x2, x8, #0x58
     614:      	blr	x9
     618:      	str	xzr, [sp, #0x18]
     61c:      	str	xzr, [sp, #0x30]
     620:      	ldr	x2, [sp, #0x8]
     624:      	mov	w21, #0x8               // =8
     628:      	add	x8, sp, #0x18
     62c:      	mov	w9, #0x4                // =4
     630:      	add	x0, sp, #0x18
     634:      	mov	w1, #0x8                // =8
     638:      	blr	x9
     63c:      	ldr	x8, [sp, #0x18]
     640:      	add	x9, sp, #0x30
     644:      	mov	w10, #0x4               // =4
     648:      	add	x0, sp, #0x30
     64c:      	mov	w1, #0x8                // =8
     650:      	add	x8, x8, #0x90
     654:      	ldr	x8, [sp, #0x18]
     658:      	add	x2, x8, #0x90
     65c:      	blr	x10
     660:      	ldr	x8, [sp, #0x30]
     664:      	add	x0, x20, #0x4c
     668:      	mov	w1, #0x4                // =4
     66c:      	add	x8, x8, #0x158
     670:      	ldr	x8, [sp, #0x30]
     674:      	add	x2, x8, #0x158
     678:      	blr	x22
     67c:      	ldr	x8, [sp, #0x10]
     680:      	ldrb	w8, [x8, #0x23]
     684:      	tbnz	w8, #0x1, 0x694 <event_wake_up_new_task+0x694>
     688:      	ldr	w8, [x20, #0x24]
     68c:      	cmp	w8, #0x1
     690:      	b.ne	0x6a0 <event_wake_up_new_task+0x6a0>
     694:      	ldr	w8, [x20, #0x20]
     698:      	orr	w8, w8, #0x2000000
     69c:      	str	w8, [x20, #0x20]
     6a0:      	mov	w8, #0x17               // =23
     6a4:      	ldp	x9, x10, [x25]
     6a8:      	mov	w21, #0x38              // =56
     6ac:      	add	x2, x23, #0x8d0
     6b0:      	add	x0, sp, #0x18
     6b4:      	strb	w8, [sp, #0x38]
     6b8:      	ldr	x8, [x20, #0x8]
     6bc:      	mov	w1, #0x4                // =4
     6c0:      	str	w21, [sp, #0x3c]
     6c4:      	str	x8, [sp, #0x40]
     6c8:      	stp	x9, x10, [sp, #0x48]
     6cc:      	add	x9, sp, #0x18
     6d0:      	ldr	w8, [x20]
     6d4:      	str	w8, [sp, #0x58]
     6d8:      	mov	w8, #0x4                // =4
     6dc:      	blr	x8
     6e0:      	ldr	w8, [sp, #0x18]
     6e4:      	adrp	x1, 0x0 <event_wake_up_new_task>
     6e8:      	mov	w9, #0x19               // =25
     6ec:      	add	x10, sp, #0x38
     6f0:      	str	w8, [sp, #0x5c]
     6f4:      	add	x3, sp, #0x38
     6f8:      	mov	x0, x19
     6fc:      	mov	w2, #-0x1               // =-1
     700:      	mov	w4, #0x38               // =56
     704:      	ldr	x8, [x20, #0x8]
     708:      	str	x8, [sp, #0x68]
     70c:      	ldr	w8, [x20, #0x24]
     710:      	str	w8, [sp, #0x60]
     714:      	ldr	w8, [x20, #0x20]
     718:      	str	w8, [sp, #0x64]
     71c:      	mov	w8, #-0x1               // =-1
     720:      	ldr	x1, [x1]
     724:      	blr	x9
     728:      	tbz	x0, #0x3f, 0x7f4 <event_wake_up_new_task+0x7f4>
     72c:      	mov	x19, x0
     730:      	str	wzr, [sp, #0x18]
     734:      	adrp	x0, 0x0 <event_wake_up_new_task>
     738:      	mov	w8, #0x1                // =1
     73c:      	ldr	x0, [x0]
     740:      	add	x9, sp, #0x18
     744:      	add	x1, sp, #0x18
     748:      	blr	x8
     74c:      	cbz	x0, 0x7f4 <event_wake_up_new_task+0x7f4>
     750:      	mov	x8, x19
     754:      	cmn	x19, #0xc
     758:      	b.gt	0x7a0 <event_wake_up_new_task+0x7a0>
     75c:      	cmn	x8, #0x1c
     760:      	b.eq	0x7c0 <event_wake_up_new_task+0x7c0>
     764:      	cmn	x8, #0x16
     768:      	b.eq	0x7d8 <event_wake_up_new_task+0x7d8>
     76c:      	cmn	x8, #0x10
     770:      	b.ne	0x7d0 <event_wake_up_new_task+0x7d0>
     774:      	add	x8, x0, #0x520
     778:      	b	0x7e4 <event_wake_up_new_task+0x7e4>
     77c:      	str	wzr, [sp, #0x38]
     780:      	adrp	x0, 0x0 <event_wake_up_new_task>
     784:      	mov	w8, #0x1                // =1
     788:      	add	x9, sp, #0x38
     78c:      	ldr	x0, [x0]
     790:      	add	x1, sp, #0x38
     794:      	blr	x8
     798:      	cbnz	x0, 0x544 <event_wake_up_new_task+0x544>
     79c:      	b	0x550 <event_wake_up_new_task+0x550>
     7a0:      	cmn	x8, #0xb
     7a4:      	b.eq	0x7c8 <event_wake_up_new_task+0x7c8>
     7a8:      	cmn	x8, #0x7
     7ac:      	b.eq	0x7e0 <event_wake_up_new_task+0x7e0>
     7b0:      	cmn	x8, #0x2
     7b4:      	b.ne	0x7d0 <event_wake_up_new_task+0x7d0>
     7b8:      	add	x8, x0, #0x510
     7bc:      	b	0x7e4 <event_wake_up_new_task+0x7e4>
     7c0:      	add	x8, x0, #0x530
     7c4:      	b	0x7e4 <event_wake_up_new_task+0x7e4>
     7c8:      	add	x8, x0, #0x538
     7cc:      	b	0x7e4 <event_wake_up_new_task+0x7e4>
     7d0:      	add	x8, x0, #0x508
     7d4:      	b	0x7e4 <event_wake_up_new_task+0x7e4>
     7d8:      	add	x8, x0, #0x528
     7dc:      	b	0x7e4 <event_wake_up_new_task+0x7e4>
     7e0:      	add	x8, x0, #0x518
     7e4:      	ldaxr	x9, [x8]
     7e8:      	add	x9, x9, #0x1
     7ec:      	stlxr	w10, x9, [x8]
     7f0:      	cbnz	w10, 0x7e4 <event_wake_up_new_task+0x7e4>
     7f4:      	ldp	x20, x19, [sp, #0xc0]
     7f8:      	mov	w0, wzr
     7fc:      	ldr	x29, [sp, #0x80]
     800:      	ldp	x22, x21, [sp, #0xb0]
     804:      	ldp	x24, x23, [sp, #0xa0]
     808:      	ldp	x30, x25, [sp, #0x90]
     80c:      	add	sp, sp, #0xd0
     810:      	ret
