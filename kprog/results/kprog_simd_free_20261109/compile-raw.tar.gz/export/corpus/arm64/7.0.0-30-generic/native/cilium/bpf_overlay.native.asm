
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/cilium/bpf_overlay.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	adrp	x8, 0x0 <__check_cluster_id_bits>
       4:      	ldr	x8, [x8]
       8:      	ldr	wzr, [x8]
       c:      	ret

0000000000000010 <__check_device_mtu>:
      10:      	adrp	x8, 0x0 <__check_cluster_id_bits>
      14:      	ldr	x8, [x8]
      18:      	ldrh	wzr, [x8]
      1c:      	ret

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	sub	sp, sp, #0xa0
       4:      	str	x29, [sp, #0x50]
       8:      	stp	x30, x25, [sp, #0x60]
       c:      	stp	x24, x23, [sp, #0x70]
      10:      	stp	x22, x21, [sp, #0x80]
      14:      	stp	x20, x19, [sp, #0x90]
      18:      	adrp	x8, 0x0 <tail_drop_notify>
      1c:      	ldr	w23, [x0, #0x38]
      20:      	mov	x19, x0
      24:      	ldr	x8, [x8]
      28:      	ldrb	w8, [x8]
      2c:      	cbz	w8, 0x54 <tail_drop_notify+0x54>
      30:      	str	wzr, [sp, #0x10]
      34:      	mov	w8, #0x1                // =1
      38:      	adrp	x0, 0x0 <tail_drop_notify>
      3c:      	add	x1, sp, #0x10
      40:      	ldr	x0, [x0]
      44:      	blr	x8
      48:      	cbz	x0, 0x58 <tail_drop_notify+0x58>
      4c:      	ldr	x0, [x0]
      50:      	b	0x58 <tail_drop_notify+0x58>
      54:      	mov	x0, xzr
      58:      	mov	w20, #0x2               // =2
      5c:      	adrp	x9, 0x0 <tail_drop_notify>
      60:      	ldr	w25, [x19, #0x70]
      64:      	ldr	w22, [x19, #0x40]
      68:      	mov	w8, w25
      6c:      	str	x20, [sp, #0x40]
      70:      	ldr	x9, [x9]
      74:      	ldr	w10, [x9]
      78:      	cbz	w10, 0x1a4 <tail_drop_notify+0x1a4>
      7c:      	str	x0, [sp, #0x8]
      80:      	adrp	x8, 0x0 <tail_drop_notify>
      84:      	ldr	x8, [x8]
      88:      	ldr	w29, [x8]
      8c:      	ldr	w24, [x9]
      90:      	mov	w8, #0x5                // =5
      94:      	blr	x8
      98:      	str	w20, [sp, #0x5c]
      9c:      	mov	x21, x0
      a0:      	mov	w8, #0x1                // =1
      a4:      	adrp	x0, 0x0 <tail_drop_notify>
      a8:      	add	x1, sp, #0x5c
      ac:      	ldr	x0, [x0]
      b0:      	blr	x8
      b4:      	mov	x20, x0
      b8:      	cbnz	x0, 0xe4 <tail_drop_notify+0xe4>
      bc:      	str	xzr, [sp, #0x48]
      c0:      	mov	w8, #0x2                // =2
      c4:      	adrp	x0, 0x0 <tail_drop_notify>
      c8:      	add	x1, sp, #0x5c
      cc:      	add	x2, sp, #0x48
      d0:      	mov	w3, wzr
      d4:      	add	x20, sp, #0x48
      d8:      	ldr	x0, [x0]
      dc:      	blr	x8
      e0:      	tbnz	w0, #0x1f, 0x258 <tail_drop_notify+0x258>
      e4:      	mov	w8, #0x1                // =1
      e8:      	adrp	x0, 0x0 <tail_drop_notify>
      ec:      	add	x1, sp, #0x40
      f0:      	ldr	x0, [x0]
      f4:      	blr	x8
      f8:      	cbz	x0, 0x160 <tail_drop_notify+0x160>
      fc:      	ldr	x8, [x0]
     100:      	mov	w9, #0xca00             // =51712
     104:      	movk	w9, #0x3b9a, lsl #16
     108:      	sub	x10, x21, x8
     10c:      	cmp	x10, x9
     110:      	b.ls	0x18c <tail_drop_notify+0x18c>
     114:      	mov	x11, #0x5a53            // =23123
     118:      	lsr	x8, x10, #9
     11c:      	neg	x10, x10
     120:      	movk	x11, #0xa09b, lsl #16
     124:      	movk	x11, #0xb82f, lsl #32
     128:      	movk	x11, #0x44, lsl #48
     12c:      	umulh	x8, x8, x11
     130:      	lsr	x11, x8, #11
     134:      	ldr	x8, [x0, #0x8]
     138:      	madd	x9, x11, x9, x10
     13c:      	madd	x8, x11, x24, x8
     140:      	add	x9, x21, x9
     144:      	cmp	x8, x29
     148:      	stp	x9, x8, [x0]
     14c:      	b.ls	0x158 <tail_drop_notify+0x158>
     150:      	mov	x8, x29
     154:      	str	x29, [x0, #0x8]
     158:      	cbnz	x8, 0x194 <tail_drop_notify+0x194>
     15c:      	b	0x278 <tail_drop_notify+0x278>
     160:      	sub	x8, x24, #0x1
     164:      	adrp	x0, 0x0 <tail_drop_notify>
     168:      	add	x1, sp, #0x40
     16c:      	stp	x21, x8, [sp, #0x10]
     170:      	mov	w8, #0x2                // =2
     174:      	add	x2, sp, #0x10
     178:      	mov	w3, wzr
     17c:      	ldr	x0, [x0]
     180:      	blr	x8
     184:      	tbz	w0, #0x1f, 0x19c <tail_drop_notify+0x19c>
     188:      	b	0x278 <tail_drop_notify+0x278>
     18c:      	ldr	x8, [x0, #0x8]
     190:      	cbz	x8, 0x278 <tail_drop_notify+0x278>
     194:      	sub	x8, x8, #0x1
     198:      	str	x8, [x0, #0x8]
     19c:      	ldr	w8, [x19, #0x70]
     1a0:      	ldr	x0, [sp, #0x8]
     1a4:      	ldrh	w9, [x19, #0xb4]
     1a8:      	mov	w10, #0xdd86            // =56710
     1ac:      	cmp	w9, w10
     1b0:      	adrp	x10, 0x0 <tail_drop_notify>
     1b4:      	ldr	x10, [x10]
     1b8:      	cset	w9, eq
     1bc:      	ldr	w10, [x10]
     1c0:      	ldr	w14, [x19, #0x98]
     1c4:      	ldr	w12, [x19, #0x3c]
     1c8:      	ldr	x13, [x19, #0x10]
     1cc:      	cmp	w8, w10
     1d0:      	csel	w8, w8, w10, lo
     1d4:      	ldp	w10, w11, [x19, #0x30]
     1d8:      	cbz	x13, 0x1e0 <tail_drop_notify+0x1e0>
     1dc:      	ldr	w13, [x13, #0xe0]
     1e0:      	mov	w15, #0x1               // =1
     1e4:      	lsr	w16, w22, #8
     1e8:      	stp	w14, w25, [sp, #0x14]
     1ec:      	lsr	w14, w22, #16
     1f0:      	strb	w23, [sp, #0x11]
     1f4:      	mov	w17, #0x3               // =3
     1f8:      	strb	w15, [sp, #0x10]
     1fc:      	lsr	w15, w23, #8
     200:      	strh	wzr, [sp, #0x12]
     204:      	adrp	x1, 0x0 <tail_drop_notify>
     208:      	add	x3, sp, #0x10
     20c:      	mov	w4, #0x30               // =48
     210:      	strh	w8, [sp, #0x1c]
     214:      	strh	w17, [sp, #0x1e]
     218:      	stp	w10, w11, [sp, #0x20]
     21c:      	mov	w10, #-0x1              // =-1
     220:      	orr	x2, x10, x8, lsl #32
     224:      	str	w12, [sp, #0x28]
     228:      	strh	w14, [sp, #0x2c]
     22c:      	strb	w16, [sp, #0x2e]
     230:      	strb	w15, [sp, #0x2f]
     234:      	str	w13, [sp, #0x30]
     238:      	strb	w9, [sp, #0x34]
     23c:      	mov	w9, #0x19               // =25
     240:      	sturh	wzr, [sp, #0x35]
     244:      	strb	wzr, [sp, #0x37]
     248:      	str	x0, [sp, #0x38]
     24c:      	ldr	x1, [x1]
     250:      	mov	x0, x19
     254:      	blr	x9
     258:      	and	w0, w22, #0xff
     25c:      	ldp	x20, x19, [sp, #0x90]
     260:      	ldr	x29, [sp, #0x50]
     264:      	ldp	x22, x21, [sp, #0x80]
     268:      	ldp	x24, x23, [sp, #0x70]
     26c:      	ldp	x30, x25, [sp, #0x60]
     270:      	add	sp, sp, #0xa0
     274:      	ret
     278:      	ldr	x8, [x20]
     27c:      	add	x8, x8, #0x1
     280:      	str	x8, [x20]
     284:      	b	0x258 <tail_drop_notify+0x258>
     288:      	nop
     28c:      	nop

0000000000000290 <tail_icmp6_send_time_exceeded>:
     290:      	sub	sp, sp, #0xf0
     294:      	stp	x30, x23, [sp, #0xc0]
     298:      	stp	x22, x21, [sp, #0xd0]
     29c:      	stp	x20, x19, [sp, #0xe0]
     2a0:      	mov	w8, #0x3a               // =58
     2a4:      	ldp	w20, w22, [x0, #0x30]
     2a8:      	str	wzr, [x0, #0x30]
     2ac:      	adrp	x1, 0x0 <tail_drop_notify>
     2b0:      	add	x3, sp, #0xa8
     2b4:      	mov	w2, #-0x1               // =-1
     2b8:      	mov	w4, #0x14               // =20
     2bc:      	stp	xzr, xzr, [sp, #0x58]
     2c0:      	mov	x19, x0
     2c4:      	add	x21, sp, #0x18
     2c8:      	stp	xzr, xzr, [sp, #0x48]
     2cc:      	str	xzr, [sp, #0x20]
     2d0:      	strh	wzr, [sp, #0x14]
     2d4:      	strb	w8, [sp, #0x10]
     2d8:      	adrp	x8, 0x0 <tail_drop_notify>
     2dc:      	stp	xzr, xzr, [sp, #0x38]
     2e0:      	stp	xzr, xzr, [sp, #0x28]
     2e4:      	ldr	x8, [x8]
     2e8:      	ldr	x9, [x8]
     2ec:      	str	x9, [sp, #0x8]
     2f0:      	ldr	x8, [x8, #0x8]
     2f4:      	str	x8, [sp]
     2f8:      	mov	w8, #0x3                // =3
     2fc:      	str	xzr, [sp, #0xb0]
     300:      	str	wzr, [sp, #0xb8]
     304:      	ldr	w9, [x0, #0x98]
     308:      	str	x8, [sp, #0x18]
     30c:      	mov	w8, #0xe02              // =3586
     310:      	stp	w8, w9, [sp, #0xa8]
     314:      	mov	w8, #0x19               // =25
     318:      	ldr	x1, [x1]
     31c:      	blr	x8
     320:      	mov	w8, #0x1a               // =26
     324:      	add	x2, x21, #0x8
     328:      	mov	x0, x19
     32c:      	mov	w1, w20
     330:      	mov	w3, #0x28               // =40
     334:      	blr	x8
     338:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     33c:      	mov	w8, #0x9                // =9
     340:      	add	w1, w20, #0x6
     344:      	add	x2, sp, #0x10
     348:      	mov	x0, x19
     34c:      	mov	w3, #0x1                // =1
     350:      	mov	w4, wzr
     354:      	blr	x8
     358:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     35c:      	ldrb	w8, [sp, #0x26]
     360:      	cmp	w8, #0x6
     364:      	b.eq	0x490 <tail_icmp6_send_time_exceeded+0x200>
     368:      	cmp	w8, #0x3a
     36c:      	b.eq	0x378 <tail_icmp6_send_time_exceeded+0xe8>
     370:      	cmp	w8, #0x11
     374:      	b.ne	0x7cc <tail_icmp6_send_time_exceeded+0x53c>
     378:      	mov	w8, #0x1a               // =26
     37c:      	add	w1, w20, #0x28
     380:      	add	x2, x21, #0x30
     384:      	mov	x0, x19
     388:      	mov	w3, #0x8                // =8
     38c:      	blr	x8
     390:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     394:      	mov	w8, #0x1c               // =28
     398:      	add	x2, sp, #0x18
     39c:      	mov	x0, xzr
     3a0:      	mov	w1, wzr
     3a4:      	mov	w3, #0x38               // =56
     3a8:      	mov	w4, wzr
     3ac:      	mov	w21, #0x1c              // =28
     3b0:      	add	x23, sp, #0x18
     3b4:      	blr	x8
     3b8:      	mov	w8, #0x38000000         // =939524096
     3bc:      	mov	w4, w0
     3c0:      	add	x2, x23, #0x10
     3c4:      	str	w8, [sp, #0xa8]
     3c8:      	mov	w8, #0x3a000000         // =973078528
     3cc:      	mov	x0, xzr
     3d0:      	mov	w1, wzr
     3d4:      	str	w8, [sp, #0x98]
     3d8:      	mov	w8, #0x1c               // =28
     3dc:      	mov	w3, #0x10               // =16
     3e0:      	blr	x8
     3e4:      	mov	w8, #0x1c               // =28
     3e8:      	mov	w4, w0
     3ec:      	add	x2, x23, #0x20
     3f0:      	mov	x0, xzr
     3f4:      	mov	w1, wzr
     3f8:      	mov	w3, #0x10               // =16
     3fc:      	blr	x8
     400:      	mov	w8, #0x1c               // =28
     404:      	mov	w4, w0
     408:      	add	x2, sp, #0xa8
     40c:      	mov	x0, xzr
     410:      	mov	w1, wzr
     414:      	mov	w3, #0x4                // =4
     418:      	blr	x8
     41c:      	mov	w4, w0
     420:      	add	x2, sp, #0x98
     424:      	mov	x0, xzr
     428:      	mov	w1, wzr
     42c:      	mov	w3, #0x4                // =4
     430:      	blr	x21
     434:      	mov	w8, #0x3800             // =14336
     438:      	mov	w9, #0x26               // =38
     43c:      	mov	w21, w0
     440:      	strh	w8, [sp, #0x14]
     444:      	ldrh	w8, [sp, #0x24]
     448:      	mov	x0, x19
     44c:      	mov	w2, wzr
     450:      	ldr	w10, [x19, #0x70]
     454:      	rev	w8, w8
     458:      	sub	w8, w10, w8, lsr #16
     45c:      	add	w1, w8, #0x38
     460:      	blr	x9
     464:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     468:      	mov	w8, #0x9                // =9
     46c:      	add	w1, w20, #0x28
     470:      	add	x2, sp, #0x18
     474:      	mov	x0, x19
     478:      	mov	w3, #0x38               // =56
     47c:      	mov	w4, wzr
     480:      	blr	x8
     484:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     488:      	mov	w8, #0x9                // =9
     48c:      	b	0x5a4 <tail_icmp6_send_time_exceeded+0x314>
     490:      	mov	w8, #0x1a               // =26
     494:      	add	w1, w20, #0x28
     498:      	add	x2, x21, #0x30
     49c:      	mov	x0, x19
     4a0:      	mov	w3, #0x14               // =20
     4a4:      	blr	x8
     4a8:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     4ac:      	mov	w8, #0x1c               // =28
     4b0:      	add	x2, sp, #0x18
     4b4:      	mov	x0, xzr
     4b8:      	mov	w1, wzr
     4bc:      	mov	w3, #0x44               // =68
     4c0:      	mov	w4, wzr
     4c4:      	mov	w21, #0x1c              // =28
     4c8:      	add	x23, sp, #0x18
     4cc:      	blr	x8
     4d0:      	mov	w8, #0x44000000         // =1140850688
     4d4:      	mov	w4, w0
     4d8:      	add	x2, x23, #0x10
     4dc:      	str	w8, [sp, #0xa8]
     4e0:      	mov	w8, #0x3a000000         // =973078528
     4e4:      	mov	x0, xzr
     4e8:      	mov	w1, wzr
     4ec:      	str	w8, [sp, #0x98]
     4f0:      	mov	w8, #0x1c               // =28
     4f4:      	mov	w3, #0x10               // =16
     4f8:      	blr	x8
     4fc:      	mov	w8, #0x1c               // =28
     500:      	mov	w4, w0
     504:      	add	x2, x23, #0x20
     508:      	mov	x0, xzr
     50c:      	mov	w1, wzr
     510:      	mov	w3, #0x10               // =16
     514:      	blr	x8
     518:      	mov	w8, #0x1c               // =28
     51c:      	mov	w4, w0
     520:      	add	x2, sp, #0xa8
     524:      	mov	x0, xzr
     528:      	mov	w1, wzr
     52c:      	mov	w3, #0x4                // =4
     530:      	blr	x8
     534:      	mov	w4, w0
     538:      	add	x2, sp, #0x98
     53c:      	mov	x0, xzr
     540:      	mov	w1, wzr
     544:      	mov	w3, #0x4                // =4
     548:      	blr	x21
     54c:      	mov	w8, #0x4400             // =17408
     550:      	mov	w9, #0x26               // =38
     554:      	mov	w21, w0
     558:      	strh	w8, [sp, #0x14]
     55c:      	ldrh	w8, [sp, #0x24]
     560:      	mov	x0, x19
     564:      	mov	w2, wzr
     568:      	ldr	w10, [x19, #0x70]
     56c:      	rev	w8, w8
     570:      	sub	w8, w10, w8, lsr #16
     574:      	add	w1, w8, #0x44
     578:      	blr	x9
     57c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     580:      	mov	w8, #0x9                // =9
     584:      	add	w1, w20, #0x28
     588:      	add	x2, sp, #0x18
     58c:      	mov	x0, x19
     590:      	mov	w3, #0x44               // =68
     594:      	mov	w4, wzr
     598:      	blr	x8
     59c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     5a0:      	mov	w8, #0x9                // =9
     5a4:      	add	w1, w20, #0x4
     5a8:      	add	x2, sp, #0x14
     5ac:      	mov	x0, x19
     5b0:      	mov	w3, #0x2                // =2
     5b4:      	mov	w4, wzr
     5b8:      	blr	x8
     5bc:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     5c0:      	mov	w8, #0xb                // =11
     5c4:      	add	w1, w20, #0x2a
     5c8:      	mov	x0, x19
     5cc:      	mov	w2, wzr
     5d0:      	mov	w3, w21
     5d4:      	mov	w4, #0x10               // =16
     5d8:      	blr	x8
     5dc:      	tbnz	w0, #0x1f, 0x88c <tail_icmp6_send_time_exceeded+0x5fc>
     5e0:      	ldp	x9, x8, [sp]
     5e4:      	add	w1, w20, #0x8
     5e8:      	add	x2, sp, #0x78
     5ec:      	mov	x0, x19
     5f0:      	mov	w3, #0x10               // =16
     5f4:      	stp	x8, x9, [sp, #0x98]
     5f8:      	adrp	x8, 0x0 <tail_drop_notify>
     5fc:      	ldr	x8, [x8]
     600:      	ldr	x8, [x8]
     604:      	str	x8, [sp, #0x88]
     608:      	mov	w8, #0x1a               // =26
     60c:      	blr	x8
     610:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     614:      	mov	w8, #0x1a               // =26
     618:      	add	w1, w20, #0x18
     61c:      	add	x2, sp, #0x68
     620:      	mov	x0, x19
     624:      	mov	w3, #0x10               // =16
     628:      	blr	x8
     62c:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     630:      	mov	w8, #0x9                // =9
     634:      	add	w1, w20, #0x8
     638:      	add	x2, sp, #0x98
     63c:      	mov	x0, x19
     640:      	mov	w3, #0x10               // =16
     644:      	mov	w4, wzr
     648:      	blr	x8
     64c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     650:      	mov	w8, #0x9                // =9
     654:      	add	w1, w20, #0x18
     658:      	add	x2, sp, #0x78
     65c:      	mov	x0, x19
     660:      	mov	w3, #0x10               // =16
     664:      	mov	w4, wzr
     668:      	blr	x8
     66c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     670:      	mov	w8, #0x1c               // =28
     674:      	add	x0, sp, #0x78
     678:      	add	x2, sp, #0x98
     67c:      	mov	w1, #0x10               // =16
     680:      	mov	w3, #0x10               // =16
     684:      	mov	w4, wzr
     688:      	blr	x8
     68c:      	mov	w3, w0
     690:      	mov	w8, #0xb                // =11
     694:      	add	w1, w20, #0x2a
     698:      	mov	x0, x19
     69c:      	mov	w2, wzr
     6a0:      	mov	w4, #0x10               // =16
     6a4:      	blr	x8
     6a8:      	tbnz	w0, #0x1f, 0x88c <tail_icmp6_send_time_exceeded+0x5fc>
     6ac:      	mov	w8, #0x1c               // =28
     6b0:      	add	x0, sp, #0x68
     6b4:      	add	x2, sp, #0x78
     6b8:      	mov	w1, #0x10               // =16
     6bc:      	mov	w3, #0x10               // =16
     6c0:      	mov	w4, wzr
     6c4:      	blr	x8
     6c8:      	mov	w3, w0
     6cc:      	mov	w8, #0xb                // =11
     6d0:      	add	w1, w20, #0x2a
     6d4:      	mov	x0, x19
     6d8:      	mov	w2, wzr
     6dc:      	mov	w4, #0x10               // =16
     6e0:      	blr	x8
     6e4:      	tbnz	w0, #0x1f, 0x88c <tail_icmp6_send_time_exceeded+0x5fc>
     6e8:      	mov	w8, #0x1a               // =26
     6ec:      	add	x2, sp, #0x90
     6f0:      	mov	x0, x19
     6f4:      	mov	w1, #0x6                // =6
     6f8:      	mov	w3, #0x6                // =6
     6fc:      	blr	x8
     700:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     704:      	mov	w8, #0x9                // =9
     708:      	add	x2, sp, #0x90
     70c:      	mov	x0, x19
     710:      	mov	w1, wzr
     714:      	mov	w3, #0x6                // =6
     718:      	mov	w4, wzr
     71c:      	blr	x8
     720:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     724:      	mov	w8, #0x9                // =9
     728:      	add	x2, sp, #0x88
     72c:      	mov	x0, x19
     730:      	mov	w1, #0x6                // =6
     734:      	mov	w3, #0x6                // =6
     738:      	mov	w4, wzr
     73c:      	blr	x8
     740:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     744:      	ldr	x8, [x19, #0x10]
     748:      	cbz	x8, 0x750 <tail_icmp6_send_time_exceeded+0x4c0>
     74c:      	ldr	w8, [x8, #0xe0]
     750:      	adrp	x10, 0x0 <tail_drop_notify>
     754:      	ldr	w9, [x19, #0x70]
     758:      	mov	w11, #0x403             // =1027
     75c:      	adrp	x1, 0x0 <tail_drop_notify>
     760:      	ldr	x10, [x10]
     764:      	add	x3, sp, #0xa8
     768:      	mov	x0, x19
     76c:      	mov	w4, #0x18               // =24
     770:      	ldr	w10, [x10]
     774:      	ldr	w12, [x19, #0x98]
     778:      	str	w9, [sp, #0xb0]
     77c:      	stp	w8, wzr, [sp, #0xb8]
     780:      	mov	w8, #0x19               // =25
     784:      	cmp	w9, w10
     788:      	stp	w11, w12, [sp, #0xa8]
     78c:      	csel	w10, w9, w10, lo
     790:      	mov	w9, #0x1                // =1
     794:      	strh	w10, [sp, #0xb4]
     798:      	strh	w9, [sp, #0xb6]
     79c:      	mov	w9, #-0x1               // =-1
     7a0:      	orr	x2, x9, x10, lsl #32
     7a4:      	ldr	x1, [x1]
     7a8:      	blr	x8
     7ac:      	ldr	x8, [x19, #0x10]
     7b0:      	cbz	x8, 0x894 <tail_icmp6_send_time_exceeded+0x604>
     7b4:      	ldr	w0, [x8, #0xe0]
     7b8:      	b	0x898 <tail_icmp6_send_time_exceeded+0x608>
     7bc:      	mov	w0, #-0x86              // =-134
     7c0:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     7c4:      	mov	w0, #-0x8d              // =-141
     7c8:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     7cc:      	mov	w0, #-0x8e              // =-142
     7d0:      	cmp	w0, #0x0
     7d4:      	str	xzr, [x19, #0x30]
     7d8:      	ldr	w20, [x19, #0x70]
     7dc:      	add	x1, sp, #0xa8
     7e0:      	cneg	w8, w0, mi
     7e4:      	adrp	x0, 0x0 <tail_drop_notify>
     7e8:      	and	w9, w8, #0xff
     7ec:      	str	w9, [x19, #0x38]
     7f0:      	mov	x9, #0x670200000000     // =113258287595520
     7f4:      	movk	x9, #0x142, lsl #48
     7f8:      	stur	x9, [x19, #0x3c]
     7fc:      	mov	x9, #0x1420000          // =21102592
     800:      	movk	x9, #0x67, lsl #32
     804:      	str	x9, [sp, #0xa8]
     808:      	strb	w8, [sp, #0xa8]
     80c:      	and	w8, w22, #0x3
     810:      	strb	w8, [sp, #0xa9]
     814:      	mov	w8, #0x1                // =1
     818:      	ldr	x0, [x0]
     81c:      	blr	x8
     820:      	cbz	x0, 0x838 <tail_icmp6_send_time_exceeded+0x5a8>
     824:      	ldp	x8, x9, [x0]
     828:      	add	x8, x8, #0x1
     82c:      	add	x9, x9, x20
     830:      	stp	x8, x9, [x0]
     834:      	b	0x85c <tail_icmp6_send_time_exceeded+0x5cc>
     838:      	mov	w8, #0x1                // =1
     83c:      	adrp	x0, 0x0 <tail_drop_notify>
     840:      	add	x1, sp, #0xa8
     844:      	stp	x8, x20, [sp, #0x18]
     848:      	mov	w8, #0x2                // =2
     84c:      	add	x2, sp, #0x18
     850:      	mov	w3, wzr
     854:      	ldr	x0, [x0]
     858:      	blr	x8
     85c:      	mov	w8, #0xc                // =12
     860:      	adrp	x1, 0x0 <tail_drop_notify>
     864:      	mov	x0, x19
     868:      	ldr	x1, [x1]
     86c:      	mov	w2, #0x1                // =1
     870:      	blr	x8
     874:      	mov	w0, #0x2                // =2
     878:      	ldp	x20, x19, [sp, #0xe0]
     87c:      	ldp	x22, x21, [sp, #0xd0]
     880:      	ldp	x30, x23, [sp, #0xc0]
     884:      	add	sp, sp, #0xf0
     888:      	ret
     88c:      	mov	w0, #-0x9a              // =-154
     890:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     894:      	mov	w0, wzr
     898:      	mov	w8, #0x17               // =23
     89c:      	mov	w1, wzr
     8a0:      	blr	x8
     8a4:      	tbnz	w0, #0x1f, 0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     8a8:      	cmp	w0, #0x2
     8ac:      	b.ne	0x878 <tail_icmp6_send_time_exceeded+0x5e8>
     8b0:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>

Disassembly of section tc/entry:

0000000000000000 <cil_from_overlay>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x20]
       8:      	stp	x22, x21, [sp, #0x30]
       c:      	stp	x20, x19, [sp, #0x40]
      10:      	str	wzr, [x0, #0x30]
      14:      	adrp	x8, 0x0 <cil_from_overlay>
      18:      	mov	x19, x0
      1c:      	str	wzr, [x0, #0x34]
      20:      	str	wzr, [x0, #0x38]
      24:      	str	wzr, [x0, #0x3c]
      28:      	str	wzr, [x0, #0x40]
      2c:      	ldr	x8, [x8]
      30:      	ldrb	w9, [x8]
      34:      	cbz	w9, 0x84 <cil_from_overlay+0x84>
      38:      	ldrb	w21, [x8]
      3c:      	ldr	x10, [x19, #0xd0]
      40:      	add	x8, x10, #0xe
      44:      	ldr	x9, [x19, #0x50]
      48:      	cmp	x8, x9
      4c:      	b.hi	0x64 <cil_from_overlay+0x64>
      50:      	ldrh	w11, [x10, #0xc]
      54:      	add	x10, x10, #0x22
      58:      	cmp	w11, #0x8
      5c:      	ccmp	x10, x9, #0x2, eq
      60:      	b.ls	0xfc <cil_from_overlay+0xfc>
      64:      	str	wzr, [sp, #0x10]
      68:      	mov	w8, #0x1                // =1
      6c:      	adrp	x0, 0x0 <cil_from_overlay>
      70:      	add	x1, sp, #0x10
      74:      	ldr	x0, [x0]
      78:      	blr	x8
      7c:      	cbz	x0, 0x84 <cil_from_overlay+0x84>
      80:      	str	xzr, [x0]
      84:      	ldr	x8, [x19, #0xd0]
      88:      	ldr	x9, [x19, #0x50]
      8c:      	add	x10, x8, #0xe
      90:      	cmp	x10, x9
      94:      	b.hi	0x1c0 <cil_from_overlay+0x1c0>
      98:      	ldrh	w20, [x8, #0xc]
      9c:      	cmp	w20, #0x6
      a0:      	b.lo	0x1c0 <cil_from_overlay+0x1c0>
      a4:      	adrp	x8, 0x0 <cil_from_overlay>
      a8:      	adrp	x0, 0x0 <cil_from_overlay>
      ac:      	add	x1, sp, #0x28
      b0:      	ldr	x8, [x8]
      b4:      	ldr	wzr, [x8]
      b8:      	mov	x8, #0x103              // =259
      bc:      	ldr	w21, [x19, #0x70]
      c0:      	movk	x8, #0x230, lsl #16
      c4:      	movk	x8, #0x3, lsl #32
      c8:      	str	x8, [sp, #0x28]
      cc:      	mov	w8, #0x1                // =1
      d0:      	ldr	x0, [x0]
      d4:      	blr	x8
      d8:      	cbz	x0, 0x134 <cil_from_overlay+0x134>
      dc:      	ldp	x8, x9, [x0]
      e0:      	add	x8, x8, #0x1
      e4:      	add	x9, x9, x21
      e8:      	stp	x8, x9, [x0]
      ec:      	mov	w8, #0xdd86             // =56710
      f0:      	cmp	w20, w8
      f4:      	b.ne	0x164 <cil_from_overlay+0x164>
      f8:      	b	0x16c <cil_from_overlay+0x16c>
      fc:      	ldrb	w8, [x8]
     100:      	and	w22, w8, #0xf
     104:      	cmp	w22, #0x6
     108:      	b.hs	0x1d8 <cil_from_overlay+0x1d8>
     10c:      	mov	x20, xzr
     110:      	str	wzr, [sp, #0x10]
     114:      	mov	w8, #0x1                // =1
     118:      	adrp	x0, 0x0 <cil_from_overlay>
     11c:      	add	x1, sp, #0x10
     120:      	ldr	x0, [x0]
     124:      	blr	x8
     128:      	cbz	x0, 0x84 <cil_from_overlay+0x84>
     12c:      	str	x20, [x0]
     130:      	b	0x84 <cil_from_overlay+0x84>
     134:      	mov	w8, #0x1                // =1
     138:      	adrp	x0, 0x0 <cil_from_overlay>
     13c:      	add	x1, sp, #0x28
     140:      	stp	x8, x21, [sp, #0x10]
     144:      	mov	w8, #0x2                // =2
     148:      	add	x2, sp, #0x10
     14c:      	mov	w3, wzr
     150:      	ldr	x0, [x0]
     154:      	blr	x8
     158:      	mov	w8, #0xdd86             // =56710
     15c:      	cmp	w20, w8
     160:      	b.eq	0x16c <cil_from_overlay+0x16c>
     164:      	cmp	w20, #0x8
     168:      	b.ne	0x1c0 <cil_from_overlay+0x1c0>
     16c:      	mov	w8, #0x8b               // =139
     170:      	ldr	w20, [x19, #0x70]
     174:      	adrp	x0, 0x0 <cil_from_overlay>
     178:      	add	x1, sp, #0x28
     17c:      	stp	xzr, x8, [x19, #0x30]
     180:      	mov	w8, #0x302              // =770
     184:      	movk	w8, #0x250, lsl #16
     188:      	str	w8, [x19, #0x40]
     18c:      	mov	x8, #0x18b              // =395
     190:      	movk	x8, #0x250, lsl #16
     194:      	movk	x8, #0x3, lsl #32
     198:      	str	x8, [sp, #0x28]
     19c:      	mov	w8, #0x1                // =1
     1a0:      	ldr	x0, [x0]
     1a4:      	blr	x8
     1a8:      	cbz	x0, 0x20c <cil_from_overlay+0x20c>
     1ac:      	ldp	x8, x9, [x0]
     1b0:      	add	x8, x8, #0x1
     1b4:      	add	x9, x9, x20
     1b8:      	stp	x8, x9, [x0]
     1bc:      	b	0x230 <cil_from_overlay+0x230>
     1c0:      	mov	w0, wzr
     1c4:      	ldp	x20, x19, [sp, #0x40]
     1c8:      	ldr	x30, [sp, #0x20]
     1cc:      	ldp	x22, x21, [sp, #0x30]
     1d0:      	add	sp, sp, #0x50
     1d4:      	ret
     1d8:      	mov	w8, #0x1a               // =26
     1dc:      	add	x2, sp, #0x28
     1e0:      	mov	x0, x19
     1e4:      	mov	w1, #0x22               // =34
     1e8:      	mov	w3, #0x1                // =1
     1ec:      	blr	x8
     1f0:      	tbnz	w0, #0x1f, 0x64 <cil_from_overlay+0x64>
     1f4:      	ldrb	w8, [sp, #0x28]
     1f8:      	cbz	w8, 0x10c <cil_from_overlay+0x10c>
     1fc:      	cmp	w8, #0x1
     200:      	b.ne	0x260 <cil_from_overlay+0x260>
     204:      	mov	w20, #0x23              // =35
     208:      	b	0x2d8 <cil_from_overlay+0x2d8>
     20c:      	mov	w8, #0x1                // =1
     210:      	adrp	x0, 0x0 <cil_from_overlay>
     214:      	add	x1, sp, #0x28
     218:      	stp	x8, x20, [sp, #0x10]
     21c:      	mov	w8, #0x2                // =2
     220:      	add	x2, sp, #0x10
     224:      	mov	w3, wzr
     228:      	ldr	x0, [x0]
     22c:      	blr	x8
     230:      	mov	w8, #0xc                // =12
     234:      	adrp	x1, 0x0 <cil_from_overlay>
     238:      	mov	x0, x19
     23c:      	ldr	x1, [x1]
     240:      	mov	w2, #0x1                // =1
     244:      	blr	x8
     248:      	mov	w0, #0x2                // =2
     24c:      	ldp	x20, x19, [sp, #0x40]
     250:      	ldr	x30, [sp, #0x20]
     254:      	ldp	x22, x21, [sp, #0x30]
     258:      	add	sp, sp, #0x50
     25c:      	ret
     260:      	mov	w8, #0x1a               // =26
     264:      	add	x2, sp, #0xc
     268:      	mov	x0, x19
     26c:      	mov	w1, #0x23               // =35
     270:      	mov	w3, #0x1                // =1
     274:      	blr	x8
     278:      	tbnz	w0, #0x1f, 0x64 <cil_from_overlay+0x64>
     27c:      	ldrb	w8, [sp, #0x28]
     280:      	cmp	w8, w21
     284:      	b.ne	0x2d0 <cil_from_overlay+0x2d0>
     288:      	mov	w20, #0x22              // =34
     28c:      	ldrb	w8, [sp, #0xc]
     290:      	cmp	w8, #0xa
     294:      	b.eq	0x3cc <cil_from_overlay+0x3cc>
     298:      	cmp	w8, #0x6
     29c:      	b.eq	0x3a0 <cil_from_overlay+0x3a0>
     2a0:      	cmp	w8, #0x4
     2a4:      	b.ne	0x64 <cil_from_overlay+0x64>
     2a8:      	mov	w8, #0x1a               // =26
     2ac:      	add	w1, w20, #0x2
     2b0:      	add	x2, sp, #0x10
     2b4:      	mov	x0, x19
     2b8:      	mov	w3, #0x2                // =2
     2bc:      	blr	x8
     2c0:      	ldrh	w8, [sp, #0x10]
     2c4:      	rev	w8, w8
     2c8:      	lsr	w8, w8, #16
     2cc:      	b	0x3ec <cil_from_overlay+0x3ec>
     2d0:      	ldrb	w8, [sp, #0xc]
     2d4:      	add	w20, w8, #0x22
     2d8:      	lsl	w8, w22, #2
     2dc:      	add	w22, w8, #0x22
     2e0:      	cmp	w20, w22
     2e4:      	b.hs	0x10c <cil_from_overlay+0x10c>
     2e8:      	mov	w8, #0x1a               // =26
     2ec:      	add	x2, sp, #0x28
     2f0:      	mov	x0, x19
     2f4:      	mov	w1, w20
     2f8:      	mov	w3, #0x1                // =1
     2fc:      	blr	x8
     300:      	tbnz	w0, #0x1f, 0x64 <cil_from_overlay+0x64>
     304:      	ldrb	w8, [sp, #0x28]
     308:      	cbz	w8, 0x10c <cil_from_overlay+0x10c>
     30c:      	cmp	w8, #0x1
     310:      	b.eq	0x340 <cil_from_overlay+0x340>
     314:      	mov	w8, #0x1a               // =26
     318:      	add	w1, w20, #0x1
     31c:      	add	x2, sp, #0xc
     320:      	mov	x0, x19
     324:      	mov	w3, #0x1                // =1
     328:      	blr	x8
     32c:      	tbnz	w0, #0x1f, 0x64 <cil_from_overlay+0x64>
     330:      	ldrb	w8, [sp, #0x28]
     334:      	cmp	w8, w21
     338:      	b.eq	0x28c <cil_from_overlay+0x28c>
     33c:      	ldrb	w8, [sp, #0xc]
     340:      	add	w20, w20, w8
     344:      	cmp	w20, w22
     348:      	b.hs	0x10c <cil_from_overlay+0x10c>
     34c:      	mov	w8, #0x1a               // =26
     350:      	add	x2, sp, #0x28
     354:      	mov	x0, x19
     358:      	mov	w1, w20
     35c:      	mov	w3, #0x1                // =1
     360:      	blr	x8
     364:      	tbnz	w0, #0x1f, 0x64 <cil_from_overlay+0x64>
     368:      	ldrb	w8, [sp, #0x28]
     36c:      	cmp	w8, #0x2
     370:      	b.lo	0x10c <cil_from_overlay+0x10c>
     374:      	mov	w8, #0x1a               // =26
     378:      	add	w1, w20, #0x1
     37c:      	add	x2, sp, #0xc
     380:      	mov	x0, x19
     384:      	mov	w3, #0x1                // =1
     388:      	blr	x8
     38c:      	tbnz	w0, #0x1f, 0x64 <cil_from_overlay+0x64>
     390:      	ldrb	w8, [sp, #0x28]
     394:      	cmp	w8, w21
     398:      	b.ne	0x10c <cil_from_overlay+0x10c>
     39c:      	b	0x28c <cil_from_overlay+0x28c>
     3a0:      	mov	w8, #0x1a               // =26
     3a4:      	add	w1, w20, #0x2
     3a8:      	add	x2, sp, #0x10
     3ac:      	mov	x0, x19
     3b0:      	mov	w3, #0x4                // =4
     3b4:      	blr	x8
     3b8:      	ldr	w8, [sp, #0x10]
     3bc:      	cmp	w0, #0x0
     3c0:      	rev	w8, w8
     3c4:      	csel	w20, wzr, w8, lt
     3c8:      	b	0x3f4 <cil_from_overlay+0x3f4>
     3cc:      	mov	w8, #0x1a               // =26
     3d0:      	add	w1, w20, #0x2
     3d4:      	add	x2, sp, #0x10
     3d8:      	mov	x0, x19
     3dc:      	mov	w3, #0x8                // =8
     3e0:      	blr	x8
     3e4:      	ldr	x8, [sp, #0x10]
     3e8:      	rev	x8, x8
     3ec:      	cmp	w0, #0x0
     3f0:      	csel	x20, xzr, x8, lt
     3f4:      	tbz	w0, #0x1f, 0x110 <cil_from_overlay+0x110>
     3f8:      	b	0x64 <cil_from_overlay+0x64>
     3fc:      	nop

0000000000000400 <cil_to_overlay>:
     400:      	sub	sp, sp, #0x70
     404:      	str	x30, [sp, #0x40]
     408:      	stp	x22, x21, [sp, #0x50]
     40c:      	stp	x20, x19, [sp, #0x60]
     410:      	str	wzr, [sp, #0x30]
     414:      	stp	xzr, xzr, [sp, #0x20]
     418:      	adrp	x8, 0x0 <cil_from_overlay>
     41c:      	mov	x19, x0
     420:      	stp	xzr, xzr, [sp, #0x10]
     424:      	str	xzr, [sp, #0x8]
     428:      	str	wzr, [x0, #0x30]
     42c:      	str	wzr, [x0, #0x34]
     430:      	str	wzr, [x0, #0x38]
     434:      	str	wzr, [x0, #0x3c]
     438:      	str	wzr, [x0, #0x40]
     43c:      	ldr	x8, [x8]
     440:      	ldrb	w9, [x8]
     444:      	cbz	w9, 0x494 <cil_to_overlay+0x94>
     448:      	ldrb	w21, [x8]
     44c:      	ldr	x10, [x19, #0xd0]
     450:      	add	x8, x10, #0xe
     454:      	ldr	x9, [x19, #0x50]
     458:      	cmp	x8, x9
     45c:      	b.hi	0x474 <cil_to_overlay+0x74>
     460:      	ldrh	w11, [x10, #0xc]
     464:      	add	x10, x10, #0x22
     468:      	cmp	w11, #0x8
     46c:      	ccmp	x10, x9, #0x2, eq
     470:      	b.ls	0x528 <cil_to_overlay+0x128>
     474:      	str	wzr, [sp, #0x38]
     478:      	mov	w8, #0x1                // =1
     47c:      	adrp	x0, 0x0 <cil_from_overlay>
     480:      	add	x1, sp, #0x38
     484:      	ldr	x0, [x0]
     488:      	blr	x8
     48c:      	cbz	x0, 0x494 <cil_to_overlay+0x94>
     490:      	str	xzr, [x0]
     494:      	mov	w8, #0x14               // =20
     498:      	add	x1, sp, #0x8
     49c:      	mov	x0, x19
     4a0:      	mov	w2, #0x1c               // =28
     4a4:      	mov	w3, wzr
     4a8:      	blr	x8
     4ac:      	adrp	x9, 0x0 <cil_from_overlay>
     4b0:      	ldr	w8, [sp, #0x8]
     4b4:      	cmp	w0, #0x0
     4b8:      	mov	w11, #0x18              // =24
     4bc:      	ldr	x9, [x9]
     4c0:      	mov	w13, #-0x1              // =-1
     4c4:      	mov	w0, wzr
     4c8:      	csel	w8, w8, wzr, eq
     4cc:      	ldr	w10, [x9]
     4d0:      	ldr	w12, [x9]
     4d4:      	ldr	w14, [x9]
     4d8:      	ldr	w9, [x9]
     4dc:      	ldp	x22, x21, [sp, #0x50]
     4e0:      	ldr	x30, [sp, #0x40]
     4e4:      	sub	w10, w11, w10
     4e8:      	lsl	w12, w13, w12
     4ec:      	neg	w14, w14
     4f0:      	sub	w9, w11, w9
     4f4:      	lsr	w10, w8, w10
     4f8:      	lsl	w9, w13, w9
     4fc:      	bic	w10, w10, w12
     500:      	bic	w8, w8, w9
     504:      	and	w12, w10, #0x7fffff00
     508:      	lsl	w12, w12, w14
     50c:      	bfxil	w12, w10, #0, #8
     510:      	orr	w8, w12, w8, lsl #16
     514:      	orr	w8, w8, #0x400
     518:      	str	w8, [x19, #0xa8]
     51c:      	ldp	x20, x19, [sp, #0x60]
     520:      	add	sp, sp, #0x70
     524:      	ret
     528:      	ldrb	w8, [x8]
     52c:      	and	w22, w8, #0xf
     530:      	cmp	w22, #0x6
     534:      	b.hs	0x560 <cil_to_overlay+0x160>
     538:      	mov	x20, xzr
     53c:      	str	wzr, [sp, #0x38]
     540:      	mov	w8, #0x1                // =1
     544:      	adrp	x0, 0x0 <cil_from_overlay>
     548:      	add	x1, sp, #0x38
     54c:      	ldr	x0, [x0]
     550:      	blr	x8
     554:      	cbz	x0, 0x494 <cil_to_overlay+0x94>
     558:      	str	x20, [x0]
     55c:      	b	0x494 <cil_to_overlay+0x94>
     560:      	mov	w8, #0x1a               // =26
     564:      	add	x2, sp, #0x4c
     568:      	mov	x0, x19
     56c:      	mov	w1, #0x22               // =34
     570:      	mov	w3, #0x1                // =1
     574:      	blr	x8
     578:      	tbnz	w0, #0x1f, 0x474 <cil_to_overlay+0x74>
     57c:      	ldrb	w8, [sp, #0x4c]
     580:      	cbz	w8, 0x538 <cil_to_overlay+0x138>
     584:      	cmp	w8, #0x1
     588:      	b.ne	0x594 <cil_to_overlay+0x194>
     58c:      	mov	w20, #0x23              // =35
     590:      	b	0x60c <cil_to_overlay+0x20c>
     594:      	mov	w8, #0x1a               // =26
     598:      	add	x2, sp, #0x48
     59c:      	mov	x0, x19
     5a0:      	mov	w1, #0x23               // =35
     5a4:      	mov	w3, #0x1                // =1
     5a8:      	blr	x8
     5ac:      	tbnz	w0, #0x1f, 0x474 <cil_to_overlay+0x74>
     5b0:      	ldrb	w8, [sp, #0x4c]
     5b4:      	cmp	w8, w21
     5b8:      	b.ne	0x604 <cil_to_overlay+0x204>
     5bc:      	mov	w20, #0x22              // =34
     5c0:      	ldrb	w8, [sp, #0x48]
     5c4:      	cmp	w8, #0xa
     5c8:      	b.eq	0x700 <cil_to_overlay+0x300>
     5cc:      	cmp	w8, #0x6
     5d0:      	b.eq	0x6d4 <cil_to_overlay+0x2d4>
     5d4:      	cmp	w8, #0x4
     5d8:      	b.ne	0x474 <cil_to_overlay+0x74>
     5dc:      	mov	w8, #0x1a               // =26
     5e0:      	add	w1, w20, #0x2
     5e4:      	add	x2, sp, #0x38
     5e8:      	mov	x0, x19
     5ec:      	mov	w3, #0x2                // =2
     5f0:      	blr	x8
     5f4:      	ldrh	w8, [sp, #0x38]
     5f8:      	rev	w8, w8
     5fc:      	lsr	w8, w8, #16
     600:      	b	0x720 <cil_to_overlay+0x320>
     604:      	ldrb	w8, [sp, #0x48]
     608:      	add	w20, w8, #0x22
     60c:      	lsl	w8, w22, #2
     610:      	add	w22, w8, #0x22
     614:      	cmp	w20, w22
     618:      	b.hs	0x538 <cil_to_overlay+0x138>
     61c:      	mov	w8, #0x1a               // =26
     620:      	add	x2, sp, #0x4c
     624:      	mov	x0, x19
     628:      	mov	w1, w20
     62c:      	mov	w3, #0x1                // =1
     630:      	blr	x8
     634:      	tbnz	w0, #0x1f, 0x474 <cil_to_overlay+0x74>
     638:      	ldrb	w8, [sp, #0x4c]
     63c:      	cbz	w8, 0x538 <cil_to_overlay+0x138>
     640:      	cmp	w8, #0x1
     644:      	b.eq	0x674 <cil_to_overlay+0x274>
     648:      	mov	w8, #0x1a               // =26
     64c:      	add	w1, w20, #0x1
     650:      	add	x2, sp, #0x48
     654:      	mov	x0, x19
     658:      	mov	w3, #0x1                // =1
     65c:      	blr	x8
     660:      	tbnz	w0, #0x1f, 0x474 <cil_to_overlay+0x74>
     664:      	ldrb	w8, [sp, #0x4c]
     668:      	cmp	w8, w21
     66c:      	b.eq	0x5c0 <cil_to_overlay+0x1c0>
     670:      	ldrb	w8, [sp, #0x48]
     674:      	add	w20, w20, w8
     678:      	cmp	w20, w22
     67c:      	b.hs	0x538 <cil_to_overlay+0x138>
     680:      	mov	w8, #0x1a               // =26
     684:      	add	x2, sp, #0x4c
     688:      	mov	x0, x19
     68c:      	mov	w1, w20
     690:      	mov	w3, #0x1                // =1
     694:      	blr	x8
     698:      	tbnz	w0, #0x1f, 0x474 <cil_to_overlay+0x74>
     69c:      	ldrb	w8, [sp, #0x4c]
     6a0:      	cmp	w8, #0x2
     6a4:      	b.lo	0x538 <cil_to_overlay+0x138>
     6a8:      	mov	w8, #0x1a               // =26
     6ac:      	add	w1, w20, #0x1
     6b0:      	add	x2, sp, #0x48
     6b4:      	mov	x0, x19
     6b8:      	mov	w3, #0x1                // =1
     6bc:      	blr	x8
     6c0:      	tbnz	w0, #0x1f, 0x474 <cil_to_overlay+0x74>
     6c4:      	ldrb	w8, [sp, #0x4c]
     6c8:      	cmp	w8, w21
     6cc:      	b.ne	0x538 <cil_to_overlay+0x138>
     6d0:      	b	0x5c0 <cil_to_overlay+0x1c0>
     6d4:      	mov	w8, #0x1a               // =26
     6d8:      	add	w1, w20, #0x2
     6dc:      	add	x2, sp, #0x38
     6e0:      	mov	x0, x19
     6e4:      	mov	w3, #0x4                // =4
     6e8:      	blr	x8
     6ec:      	ldr	w8, [sp, #0x38]
     6f0:      	cmp	w0, #0x0
     6f4:      	rev	w8, w8
     6f8:      	csel	w20, wzr, w8, lt
     6fc:      	b	0x728 <cil_to_overlay+0x328>
     700:      	mov	w8, #0x1a               // =26
     704:      	add	w1, w20, #0x2
     708:      	add	x2, sp, #0x38
     70c:      	mov	x0, x19
     710:      	mov	w3, #0x8                // =8
     714:      	blr	x8
     718:      	ldr	x8, [sp, #0x38]
     71c:      	rev	x8, x8
     720:      	cmp	w0, #0x0
     724:      	csel	x20, xzr, x8, lt
     728:      	tbz	w0, #0x1f, 0x53c <cil_to_overlay+0x13c>
     72c:      	b	0x474 <cil_to_overlay+0x74>
