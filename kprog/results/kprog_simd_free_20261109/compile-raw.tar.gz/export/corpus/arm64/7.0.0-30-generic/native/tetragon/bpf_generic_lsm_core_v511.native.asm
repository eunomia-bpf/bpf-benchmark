
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_core_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section lsm:

0000000000000000 <generic_lsm_setup_event>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	str	wzr, [sp, #0x1c]
      18:      	adrp	x20, 0x0 <generic_lsm_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x1c
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x1c
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x1ac <generic_lsm_setup_event+0x1ac>
      3c:      	adrp	x21, 0x0 <generic_lsm_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x1ac <generic_lsm_setup_event+0x1ac>
      60:      	mov	w24, #0x8               // =8
      64:      	add	x8, sp, #0x8
      68:      	mov	w9, #0x4                // =4
      6c:      	add	x0, sp, #0x8
      70:      	mov	w1, #0x8                // =8
      74:      	mov	x2, x19
      78:      	mov	w23, #0x4               // =4
      7c:      	blr	x9
      80:      	ldr	x8, [sp, #0x8]
      84:      	add	x2, x19, #0x8
      88:      	mov	w9, #0x4                // =4
      8c:      	add	x0, sp, #0x8
      90:      	str	x8, [x22, #0x5e50]
      94:      	add	x8, sp, #0x8
      98:      	mov	w1, #0x8                // =8
      9c:      	blr	x9
      a0:      	ldr	x8, [sp, #0x8]
      a4:      	add	x2, x19, #0x10
      a8:      	mov	w9, #0x4                // =4
      ac:      	add	x0, sp, #0x8
      b0:      	str	x8, [x22, #0x5e58]
      b4:      	add	x8, sp, #0x8
      b8:      	mov	w1, #0x8                // =8
      bc:      	blr	x9
      c0:      	ldr	x8, [sp, #0x8]
      c4:      	add	x2, x19, #0x18
      c8:      	mov	w9, #0x4                // =4
      cc:      	add	x0, sp, #0x8
      d0:      	str	x8, [x22, #0x5e60]
      d4:      	add	x8, sp, #0x8
      d8:      	mov	w1, #0x8                // =8
      dc:      	blr	x9
      e0:      	ldr	x8, [sp, #0x8]
      e4:      	add	x2, x19, #0x20
      e8:      	add	x0, sp, #0x8
      ec:      	mov	w1, #0x8                // =8
      f0:      	str	x8, [x22, #0x5e68]
      f4:      	add	x8, sp, #0x8
      f8:      	blr	x23
      fc:      	ldr	x8, [sp, #0x8]
     100:      	strh	wzr, [x22, #0x2]
     104:      	str	wzr, [x22, #0x4]
     108:      	str	x8, [x22, #0x5e70]
     10c:      	mov	w8, #0x10               // =16
     110:      	strb	w8, [x22]
     114:      	mov	w8, #0x7d               // =125
     118:      	blr	x8
     11c:      	str	x0, [x22, #0x8]
     120:      	str	xzr, [x22, #0x70]
     124:      	mov	w8, #0xe                // =14
     128:      	str	wzr, [x22, #0x14]
     12c:      	blr	x8
     130:      	str	w0, [x22, #0x7c]
     134:      	str	wzr, [sp, #0x8]
     138:      	mov	w8, #0x1                // =1
     13c:      	add	x9, sp, #0x8
     140:      	add	x1, sp, #0x8
     144:      	mov	x0, x20
     148:      	blr	x8
     14c:      	adrp	x20, 0x0 <generic_lsm_setup_event>
     150:      	ldr	x20, [x20]
     154:      	cbz	x0, 0x17c <generic_lsm_setup_event+0x17c>
     158:      	mov	w8, #0x5ef8             // =24312
     15c:      	add	x1, x0, x8
     160:      	mov	w8, #0x1                // =1
     164:      	mov	x0, x21
     168:      	blr	x8
     16c:      	cbz	x0, 0x17c <generic_lsm_setup_event+0x17c>
     170:      	ldr	w8, [x0, #0x40]
     174:      	cmn	w8, #0x1
     178:      	b.ne	0x194 <generic_lsm_setup_event+0x194>
     17c:      	mov	w8, #0x3                // =3
     180:      	mov	w9, #0xc                // =12
     184:      	mov	x0, x19
     188:      	mov	x1, x20
     18c:      	mov	w2, #0x3                // =3
     190:      	blr	x9
     194:      	mov	w8, #0x1                // =1
     198:      	mov	w9, #0xc                // =12
     19c:      	mov	x0, x19
     1a0:      	mov	x1, x20
     1a4:      	mov	w2, #0x1                // =1
     1a8:      	blr	x9
     1ac:      	ldp	x20, x19, [sp, #0x40]
     1b0:      	mov	w0, wzr
     1b4:      	ldr	x30, [sp, #0x10]
     1b8:      	ldp	x22, x21, [sp, #0x30]
     1bc:      	ldp	x24, x23, [sp, #0x20]
     1c0:      	add	sp, sp, #0x50
     1c4:      	ret
     1c8:      	nop
     1cc:      	nop

00000000000001d0 <generic_lsm_process_event>:
     1d0:      	sub	sp, sp, #0x140
     1d4:      	str	x29, [sp, #0xf0]
     1d8:      	stp	x30, x25, [sp, #0x100]
     1dc:      	stp	x24, x23, [sp, #0x110]
     1e0:      	stp	x22, x21, [sp, #0x120]
     1e4:      	stp	x20, x19, [sp, #0x130]
     1e8:      	str	wzr, [sp, #0x4c]
     1ec:      	adrp	x21, 0x0 <generic_lsm_setup_event>
     1f0:      	mov	w8, #0x1                // =1
     1f4:      	add	x9, sp, #0x4c
     1f8:      	ldr	x21, [x21]
     1fc:      	mov	x19, x0
     200:      	add	x1, sp, #0x4c
     204:      	mov	x0, x21
     208:      	blr	x8
     20c:      	cbz	x0, 0x3a20 <generic_lsm_process_event+0x3850>
     210:      	ldr	w24, [x0, #0x4]
     214:      	mov	w22, #0x5efc            // =24316
     218:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     21c:      	mov	x20, x0
     220:      	ldr	w25, [x0, x22]
     224:      	ldr	x29, [x29]
     228:      	lsr	w8, w24, #3
     22c:      	cmp	w8, #0x464
     230:      	b.hi	0x398c <generic_lsm_process_event+0x37bc>
     234:      	str	wzr, [sp, #0x58]
     238:      	mov	w8, #0x1                // =1
     23c:      	add	x9, sp, #0x58
     240:      	add	x1, sp, #0x58
     244:      	mov	x0, x21
     248:      	blr	x8
     24c:      	cbz	x0, 0x398c <generic_lsm_process_event+0x37bc>
     250:      	mov	w8, #0x5ef8             // =24312
     254:      	mov	x23, x0
     258:      	add	x1, x0, x8
     25c:      	adrp	x0, 0x0 <generic_lsm_setup_event>
     260:      	mov	w8, #0x1                // =1
     264:      	ldr	x0, [x0]
     268:      	blr	x8
     26c:      	cmp	w25, #0x4
     270:      	ccmp	x0, #0x0, #0x4, le
     274:      	b.eq	0x398c <generic_lsm_process_event+0x37bc>
     278:      	str	x25, [sp, #0x40]
     27c:      	and	x25, x25, #0x7
     280:      	str	x24, [sp, #0xf8]
     284:      	mov	w9, #0x5ea0             // =24224
     288:      	add	x8, x0, x25, lsl #2
     28c:      	ldrsw	x21, [x8, #0x18]
     290:      	ldr	w24, [x8, #0x4]
     294:      	add	x8, x23, x25, lsl #2
     298:      	str	wzr, [x8, x9]
     29c:      	and	x11, x21, #0xffffffff
     2a0:      	tbnz	w21, #0x8, 0x2c8 <generic_lsm_process_event+0xf8>
     2a4:      	str	x8, [sp, #0x38]
     2a8:      	tbnz	w21, #0x7, 0x2d0 <generic_lsm_process_event+0x100>
     2ac:      	tbnz	w11, #0x6, 0x2dc <generic_lsm_process_event+0x10c>
     2b0:      	add	x8, x0, x25, lsl #2
     2b4:      	ldr	w8, [x8, #0x40]
     2b8:      	and	x8, x8, #0x7
     2bc:      	add	x8, x23, x8, lsl #3
     2c0:      	ldr	x8, [x8, #0x5e50]
     2c4:      	b	0x2f8 <generic_lsm_process_event+0x128>
     2c8:      	str	xzr, [sp, #0x50]
     2cc:      	b	0x8e8 <generic_lsm_process_event+0x718>
     2d0:      	mov	x8, xzr
     2d4:      	str	xzr, [sp, #0x50]
     2d8:      	b	0x2fc <generic_lsm_process_event+0x12c>
     2dc:      	mov	w8, #0x23               // =35
     2e0:      	mov	x23, x0
     2e4:      	mov	x22, x11
     2e8:      	blr	x8
     2ec:      	mov	x11, x22
     2f0:      	mov	x8, x0
     2f4:      	mov	x0, x23
     2f8:      	str	x8, [sp, #0x50]
     2fc:      	cmp	w25, #0x4
     300:      	b.hi	0x8e8 <generic_lsm_process_event+0x718>
     304:      	mov	w9, #0x50               // =80
     308:      	umaddl	x23, w25, w9, x0
     30c:      	ldrh	w9, [x23, #0x76]
     310:      	cbz	w9, 0x8e8 <generic_lsm_process_event+0x718>
     314:      	adrp	x9, 0x0 <generic_lsm_setup_event>
     318:      	ldr	x9, [x9]
     31c:      	ldrb	w10, [x9]
     320:      	ldur	w9, [x23, #0x70]
     324:      	add	x8, x8, x9
     328:      	str	x8, [sp, #0x50]
     32c:      	ldurh	w9, [x23, #0x74]
     330:      	cbz	w10, 0x5fc <generic_lsm_process_event+0x42c>
     334:      	cbz	w9, 0x360 <generic_lsm_process_event+0x190>
     338:      	mov	w9, #0x8                // =8
     33c:      	mov	w10, #0x4               // =4
     340:      	mov	x22, x11
     344:      	add	x11, sp, #0x50
     348:      	ldr	x2, [sp, #0x50]
     34c:      	add	x0, sp, #0x50
     350:      	mov	w1, #0x8                // =8
     354:      	blr	x10
     358:      	mov	x11, x22
     35c:      	tbnz	w0, #0x1f, 0x8c8 <generic_lsm_process_event+0x6f8>
     360:      	ldurh	w8, [x23, #0x7e]
     364:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     368:      	ldr	x8, [sp, #0x50]
     36c:      	ldur	w9, [x23, #0x78]
     370:      	add	x8, x8, x9
     374:      	str	x8, [sp, #0x50]
     378:      	ldurh	w9, [x23, #0x7c]
     37c:      	cbz	w9, 0x3a8 <generic_lsm_process_event+0x1d8>
     380:      	mov	w9, #0x8                // =8
     384:      	mov	w10, #0x4               // =4
     388:      	mov	x22, x11
     38c:      	add	x11, sp, #0x50
     390:      	ldr	x2, [sp, #0x50]
     394:      	add	x0, sp, #0x50
     398:      	mov	w1, #0x8                // =8
     39c:      	blr	x10
     3a0:      	mov	x11, x22
     3a4:      	tbnz	w0, #0x1f, 0x8d0 <generic_lsm_process_event+0x700>
     3a8:      	ldurh	w8, [x23, #0x86]
     3ac:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     3b0:      	ldr	x8, [sp, #0x50]
     3b4:      	ldur	w9, [x23, #0x80]
     3b8:      	add	x8, x8, x9
     3bc:      	str	x8, [sp, #0x50]
     3c0:      	ldurh	w9, [x23, #0x84]
     3c4:      	cbz	w9, 0x3f0 <generic_lsm_process_event+0x220>
     3c8:      	mov	w9, #0x8                // =8
     3cc:      	mov	w10, #0x4               // =4
     3d0:      	mov	x22, x11
     3d4:      	add	x11, sp, #0x50
     3d8:      	ldr	x2, [sp, #0x50]
     3dc:      	add	x0, sp, #0x50
     3e0:      	mov	w1, #0x8                // =8
     3e4:      	blr	x10
     3e8:      	mov	x11, x22
     3ec:      	tbnz	w0, #0x1f, 0x8d8 <generic_lsm_process_event+0x708>
     3f0:      	ldurh	w8, [x23, #0x8e]
     3f4:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     3f8:      	ldr	x8, [sp, #0x50]
     3fc:      	ldur	w9, [x23, #0x88]
     400:      	add	x8, x8, x9
     404:      	str	x8, [sp, #0x50]
     408:      	ldurh	w9, [x23, #0x8c]
     40c:      	cbz	w9, 0x43c <generic_lsm_process_event+0x26c>
     410:      	mov	w9, #0x8                // =8
     414:      	add	x10, sp, #0x50
     418:      	mov	x22, x11
     41c:      	mov	w11, #0x4               // =4
     420:      	ldr	x2, [sp, #0x50]
     424:      	add	x0, sp, #0x50
     428:      	mov	w1, #0x8                // =8
     42c:      	blr	x11
     430:      	mov	w10, #0x4               // =4
     434:      	mov	x11, x22
     438:      	tbnz	w0, #0x1f, 0x8dc <generic_lsm_process_event+0x70c>
     43c:      	ldurh	w8, [x23, #0x96]
     440:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     444:      	ldr	x8, [sp, #0x50]
     448:      	ldur	w9, [x23, #0x90]
     44c:      	add	x8, x8, x9
     450:      	str	x8, [sp, #0x50]
     454:      	ldurh	w9, [x23, #0x94]
     458:      	cbz	w9, 0x484 <generic_lsm_process_event+0x2b4>
     45c:      	mov	w9, #0x8                // =8
     460:      	mov	w10, #0x4               // =4
     464:      	mov	x22, x11
     468:      	add	x11, sp, #0x50
     46c:      	ldr	x2, [sp, #0x50]
     470:      	add	x0, sp, #0x50
     474:      	mov	w1, #0x8                // =8
     478:      	blr	x10
     47c:      	mov	x11, x22
     480:      	tbnz	w0, #0x1f, 0x15c4 <generic_lsm_process_event+0x13f4>
     484:      	ldurh	w8, [x23, #0x9e]
     488:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     48c:      	ldr	x8, [sp, #0x50]
     490:      	ldur	w9, [x23, #0x98]
     494:      	mov	x22, x11
     498:      	add	x8, x8, x9
     49c:      	str	x8, [sp, #0x50]
     4a0:      	ldurh	w9, [x23, #0x9c]
     4a4:      	cbz	w9, 0x4c8 <generic_lsm_process_event+0x2f8>
     4a8:      	mov	w9, #0x8                // =8
     4ac:      	mov	w10, #0x4               // =4
     4b0:      	add	x11, sp, #0x50
     4b4:      	ldr	x2, [sp, #0x50]
     4b8:      	add	x0, sp, #0x50
     4bc:      	mov	w1, #0x8                // =8
     4c0:      	blr	x10
     4c4:      	tbnz	w0, #0x1f, 0x17b0 <generic_lsm_process_event+0x15e0>
     4c8:      	ldurh	w8, [x23, #0xa6]
     4cc:      	mov	x11, x22
     4d0:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     4d4:      	ldr	x8, [sp, #0x50]
     4d8:      	ldur	w9, [x23, #0xa0]
     4dc:      	add	x8, x8, x9
     4e0:      	str	x8, [sp, #0x50]
     4e4:      	ldurh	w9, [x23, #0xa4]
     4e8:      	cbz	w9, 0x50c <generic_lsm_process_event+0x33c>
     4ec:      	mov	w9, #0x8                // =8
     4f0:      	mov	w10, #0x4               // =4
     4f4:      	add	x11, sp, #0x50
     4f8:      	ldr	x2, [sp, #0x50]
     4fc:      	add	x0, sp, #0x50
     500:      	mov	w1, #0x8                // =8
     504:      	blr	x10
     508:      	tbnz	w0, #0x1f, 0x190c <generic_lsm_process_event+0x173c>
     50c:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     510:      	ldurh	w8, [x23, #0xae]
     514:      	mov	x11, x22
     518:      	ldr	x29, [x29]
     51c:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     520:      	ldr	x8, [sp, #0x50]
     524:      	ldur	w9, [x23, #0xa8]
     528:      	add	x8, x8, x9
     52c:      	str	x8, [sp, #0x50]
     530:      	ldurh	w9, [x23, #0xac]
     534:      	cbz	w9, 0x568 <generic_lsm_process_event+0x398>
     538:      	mov	w29, #0x8               // =8
     53c:      	mov	w9, #0x4                // =4
     540:      	add	x10, sp, #0x50
     544:      	ldr	x2, [sp, #0x50]
     548:      	add	x0, sp, #0x50
     54c:      	mov	w1, #0x8                // =8
     550:      	blr	x9
     554:      	mov	w10, w29
     558:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     55c:      	mov	x11, x22
     560:      	ldr	x29, [x29]
     564:      	tbnz	w0, #0x1f, 0x8dc <generic_lsm_process_event+0x70c>
     568:      	ldurh	w8, [x23, #0xb6]
     56c:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     570:      	ldr	x8, [sp, #0x50]
     574:      	ldur	w9, [x23, #0xb0]
     578:      	add	x8, x8, x9
     57c:      	str	x8, [sp, #0x50]
     580:      	ldurh	w9, [x23, #0xb4]
     584:      	cbz	w9, 0x5a8 <generic_lsm_process_event+0x3d8>
     588:      	mov	w9, #0x8                // =8
     58c:      	mov	w10, #0x4               // =4
     590:      	add	x11, sp, #0x50
     594:      	ldr	x2, [sp, #0x50]
     598:      	add	x0, sp, #0x50
     59c:      	mov	w1, #0x8                // =8
     5a0:      	blr	x10
     5a4:      	tbnz	w0, #0x1f, 0x25c8 <generic_lsm_process_event+0x23f8>
     5a8:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     5ac:      	ldurh	w8, [x23, #0xbe]
     5b0:      	mov	x11, x22
     5b4:      	ldr	x29, [x29]
     5b8:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     5bc:      	ldr	x8, [sp, #0x50]
     5c0:      	ldur	w9, [x23, #0xb8]
     5c4:      	add	x8, x8, x9
     5c8:      	str	x8, [sp, #0x50]
     5cc:      	ldurh	w9, [x23, #0xbc]
     5d0:      	cbz	w9, 0x8e8 <generic_lsm_process_event+0x718>
     5d4:      	mov	w9, #0x8                // =8
     5d8:      	mov	w10, #0x4               // =4
     5dc:      	add	x11, sp, #0x50
     5e0:      	ldr	x2, [sp, #0x50]
     5e4:      	add	x0, sp, #0x50
     5e8:      	mov	w1, #0x8                // =8
     5ec:      	blr	x10
     5f0:      	mov	x11, x22
     5f4:      	tbz	w0, #0x1f, 0x8e8 <generic_lsm_process_event+0x718>
     5f8:      	b	0x8c0 <generic_lsm_process_event+0x6f0>
     5fc:      	cbz	w9, 0x628 <generic_lsm_process_event+0x458>
     600:      	mov	w9, #0x8                // =8
     604:      	mov	w10, #0x4               // =4
     608:      	mov	x22, x11
     60c:      	add	x11, sp, #0x50
     610:      	ldr	x2, [sp, #0x50]
     614:      	add	x0, sp, #0x50
     618:      	mov	w1, #0x8                // =8
     61c:      	blr	x10
     620:      	mov	x11, x22
     624:      	tbnz	w0, #0x1f, 0x8c8 <generic_lsm_process_event+0x6f8>
     628:      	ldurh	w8, [x23, #0x7e]
     62c:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     630:      	ldr	x8, [sp, #0x50]
     634:      	ldur	w9, [x23, #0x78]
     638:      	add	x8, x8, x9
     63c:      	str	x8, [sp, #0x50]
     640:      	ldurh	w9, [x23, #0x7c]
     644:      	cbz	w9, 0x670 <generic_lsm_process_event+0x4a0>
     648:      	mov	w9, #0x8                // =8
     64c:      	mov	w10, #0x4               // =4
     650:      	mov	x22, x11
     654:      	add	x11, sp, #0x50
     658:      	ldr	x2, [sp, #0x50]
     65c:      	add	x0, sp, #0x50
     660:      	mov	w1, #0x8                // =8
     664:      	blr	x10
     668:      	mov	x11, x22
     66c:      	tbnz	w0, #0x1f, 0x8d0 <generic_lsm_process_event+0x700>
     670:      	ldurh	w8, [x23, #0x86]
     674:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     678:      	ldr	x8, [sp, #0x50]
     67c:      	ldur	w9, [x23, #0x80]
     680:      	add	x8, x8, x9
     684:      	str	x8, [sp, #0x50]
     688:      	ldurh	w9, [x23, #0x84]
     68c:      	cbz	w9, 0x6b8 <generic_lsm_process_event+0x4e8>
     690:      	mov	w9, #0x8                // =8
     694:      	mov	w10, #0x4               // =4
     698:      	mov	x22, x11
     69c:      	add	x11, sp, #0x50
     6a0:      	ldr	x2, [sp, #0x50]
     6a4:      	add	x0, sp, #0x50
     6a8:      	mov	w1, #0x8                // =8
     6ac:      	blr	x10
     6b0:      	mov	x11, x22
     6b4:      	tbnz	w0, #0x1f, 0x8d8 <generic_lsm_process_event+0x708>
     6b8:      	ldurh	w8, [x23, #0x8e]
     6bc:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     6c0:      	ldr	x8, [sp, #0x50]
     6c4:      	ldur	w9, [x23, #0x88]
     6c8:      	add	x8, x8, x9
     6cc:      	str	x8, [sp, #0x50]
     6d0:      	ldurh	w9, [x23, #0x8c]
     6d4:      	cbz	w9, 0x704 <generic_lsm_process_event+0x534>
     6d8:      	mov	w9, #0x8                // =8
     6dc:      	add	x10, sp, #0x50
     6e0:      	mov	x22, x11
     6e4:      	mov	w11, #0x4               // =4
     6e8:      	ldr	x2, [sp, #0x50]
     6ec:      	add	x0, sp, #0x50
     6f0:      	mov	w1, #0x8                // =8
     6f4:      	blr	x11
     6f8:      	mov	w10, #0x4               // =4
     6fc:      	mov	x11, x22
     700:      	tbnz	w0, #0x1f, 0x8dc <generic_lsm_process_event+0x70c>
     704:      	ldurh	w8, [x23, #0x96]
     708:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     70c:      	ldr	x8, [sp, #0x50]
     710:      	ldur	w9, [x23, #0x90]
     714:      	add	x8, x8, x9
     718:      	str	x8, [sp, #0x50]
     71c:      	ldurh	w9, [x23, #0x94]
     720:      	cbz	w9, 0x74c <generic_lsm_process_event+0x57c>
     724:      	mov	w9, #0x8                // =8
     728:      	mov	w10, #0x4               // =4
     72c:      	mov	x22, x11
     730:      	add	x11, sp, #0x50
     734:      	ldr	x2, [sp, #0x50]
     738:      	add	x0, sp, #0x50
     73c:      	mov	w1, #0x8                // =8
     740:      	blr	x10
     744:      	mov	x11, x22
     748:      	tbnz	w0, #0x1f, 0x15c4 <generic_lsm_process_event+0x13f4>
     74c:      	ldurh	w8, [x23, #0x9e]
     750:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     754:      	ldr	x8, [sp, #0x50]
     758:      	ldur	w9, [x23, #0x98]
     75c:      	mov	x22, x11
     760:      	add	x8, x8, x9
     764:      	str	x8, [sp, #0x50]
     768:      	ldurh	w9, [x23, #0x9c]
     76c:      	cbz	w9, 0x790 <generic_lsm_process_event+0x5c0>
     770:      	mov	w9, #0x8                // =8
     774:      	mov	w10, #0x4               // =4
     778:      	add	x11, sp, #0x50
     77c:      	ldr	x2, [sp, #0x50]
     780:      	add	x0, sp, #0x50
     784:      	mov	w1, #0x8                // =8
     788:      	blr	x10
     78c:      	tbnz	w0, #0x1f, 0x17b0 <generic_lsm_process_event+0x15e0>
     790:      	ldurh	w8, [x23, #0xa6]
     794:      	mov	x11, x22
     798:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     79c:      	ldr	x8, [sp, #0x50]
     7a0:      	ldur	w9, [x23, #0xa0]
     7a4:      	add	x8, x8, x9
     7a8:      	str	x8, [sp, #0x50]
     7ac:      	ldurh	w9, [x23, #0xa4]
     7b0:      	cbz	w9, 0x7d4 <generic_lsm_process_event+0x604>
     7b4:      	mov	w9, #0x8                // =8
     7b8:      	mov	w10, #0x4               // =4
     7bc:      	add	x11, sp, #0x50
     7c0:      	ldr	x2, [sp, #0x50]
     7c4:      	add	x0, sp, #0x50
     7c8:      	mov	w1, #0x8                // =8
     7cc:      	blr	x10
     7d0:      	tbnz	w0, #0x1f, 0x190c <generic_lsm_process_event+0x173c>
     7d4:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     7d8:      	ldurh	w8, [x23, #0xae]
     7dc:      	mov	x11, x22
     7e0:      	ldr	x29, [x29]
     7e4:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     7e8:      	ldr	x8, [sp, #0x50]
     7ec:      	ldur	w9, [x23, #0xa8]
     7f0:      	add	x8, x8, x9
     7f4:      	str	x8, [sp, #0x50]
     7f8:      	ldurh	w9, [x23, #0xac]
     7fc:      	cbz	w9, 0x830 <generic_lsm_process_event+0x660>
     800:      	mov	w29, #0x8               // =8
     804:      	mov	w9, #0x4                // =4
     808:      	add	x10, sp, #0x50
     80c:      	ldr	x2, [sp, #0x50]
     810:      	add	x0, sp, #0x50
     814:      	mov	w1, #0x8                // =8
     818:      	blr	x9
     81c:      	mov	w10, w29
     820:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     824:      	mov	x11, x22
     828:      	ldr	x29, [x29]
     82c:      	tbnz	w0, #0x1f, 0x8dc <generic_lsm_process_event+0x70c>
     830:      	ldurh	w8, [x23, #0xb6]
     834:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     838:      	ldr	x8, [sp, #0x50]
     83c:      	ldur	w9, [x23, #0xb0]
     840:      	add	x8, x8, x9
     844:      	str	x8, [sp, #0x50]
     848:      	ldurh	w9, [x23, #0xb4]
     84c:      	cbz	w9, 0x870 <generic_lsm_process_event+0x6a0>
     850:      	mov	w9, #0x8                // =8
     854:      	mov	w10, #0x4               // =4
     858:      	add	x11, sp, #0x50
     85c:      	ldr	x2, [sp, #0x50]
     860:      	add	x0, sp, #0x50
     864:      	mov	w1, #0x8                // =8
     868:      	blr	x10
     86c:      	tbnz	w0, #0x1f, 0x25c8 <generic_lsm_process_event+0x23f8>
     870:      	adrp	x29, 0x0 <generic_lsm_setup_event>
     874:      	ldurh	w8, [x23, #0xbe]
     878:      	mov	x11, x22
     87c:      	ldr	x29, [x29]
     880:      	cbz	w8, 0x8e8 <generic_lsm_process_event+0x718>
     884:      	ldr	x8, [sp, #0x50]
     888:      	ldur	w9, [x23, #0xb8]
     88c:      	add	x8, x8, x9
     890:      	str	x8, [sp, #0x50]
     894:      	ldurh	w9, [x23, #0xbc]
     898:      	cbz	w9, 0x8e8 <generic_lsm_process_event+0x718>
     89c:      	mov	w9, #0x8                // =8
     8a0:      	mov	w10, #0x4               // =4
     8a4:      	add	x11, sp, #0x50
     8a8:      	ldr	x2, [sp, #0x50]
     8ac:      	add	x0, sp, #0x50
     8b0:      	mov	w1, #0x8                // =8
     8b4:      	blr	x10
     8b8:      	mov	x11, x22
     8bc:      	tbz	w0, #0x1f, 0x8e8 <generic_lsm_process_event+0x718>
     8c0:      	mov	w10, #0xa               // =10
     8c4:      	b	0x8dc <generic_lsm_process_event+0x70c>
     8c8:      	mov	w10, #0x1               // =1
     8cc:      	b	0x8dc <generic_lsm_process_event+0x70c>
     8d0:      	mov	w10, #0x2               // =2
     8d4:      	b	0x8dc <generic_lsm_process_event+0x70c>
     8d8:      	mov	w10, #0x3               // =3
     8dc:      	ldr	x8, [sp, #0x38]
     8e0:      	mov	w9, #0x5ea0             // =24224
     8e4:      	str	w10, [x8, x9]
     8e8:      	mov	x9, #0x8000             // =32768
     8ec:      	mov	w8, #0x1                // =1
     8f0:      	cmp	w24, #0x2a
     8f4:      	add	x22, sp, #0xd0
     8f8:      	movk	x9, #0x101, lsl #16
     8fc:      	lsl	x8, x8, x24
     900:      	movk	x9, #0x420, lsl #32
     904:      	and	x8, x8, x9
     908:      	ccmp	x8, #0x0, #0x4, ls
     90c:      	b.eq	0x9f8 <generic_lsm_process_event+0x828>
     910:      	str	wzr, [sp, #0xd8]
     914:      	adrp	x0, 0x0 <generic_lsm_setup_event>
     918:      	ldr	x21, [sp, #0x50]
     91c:      	mov	w8, #0x1                // =1
     920:      	add	x9, sp, #0xd8
     924:      	add	x1, sp, #0xd8
     928:      	ldr	x0, [x0]
     92c:      	blr	x8
     930:      	cbz	x0, 0x9a4 <generic_lsm_process_event+0x7d4>
     934:      	mov	w8, #0x6420             // =25632
     938:      	mov	x22, x29
     93c:      	mov	x23, x0
     940:      	add	x29, x0, x8
     944:      	ldr	w8, [x29]
     948:      	cbz	w8, 0x9ac <generic_lsm_process_event+0x7dc>
     94c:      	str	wzr, [x29]
     950:      	adrp	x0, 0x0 <generic_lsm_setup_event>
     954:      	mov	w8, #0x1                // =1
     958:      	add	x9, sp, #0xd8
     95c:      	ldr	x0, [x0]
     960:      	add	x1, sp, #0xd8
     964:      	blr	x8
     968:      	cbz	x0, 0xa44 <generic_lsm_process_event+0x874>
     96c:      	add	x8, x23, x25, lsl #2
     970:      	mov	w9, #0x5ea0             // =24224
     974:      	ldr	x24, [sp, #0xf8]
     978:      	add	x11, x23, x25, lsl #3
     97c:      	ldr	w10, [x8, x9]
     980:      	add	x8, x23, #0x90
     984:      	adrp	x21, 0x0 <generic_lsm_setup_event>
     988:      	add	x9, x24, #0x4
     98c:      	str	w10, [x8, x24]
     990:      	str	x9, [x11, #0x5e78]
     994:      	ldr	x21, [x21]
     998:      	cbz	w10, 0xaa0 <generic_lsm_process_event+0x8d0>
     99c:      	mov	w8, #0x4                // =4
     9a0:      	b	0xb58 <generic_lsm_process_event+0x988>
     9a4:      	mov	x8, xzr
     9a8:      	b	0x3974 <generic_lsm_process_event+0x37a4>
     9ac:      	add	x8, sp, #0xd0
     9b0:      	cmp	w24, #0x17
     9b4:      	str	x21, [sp, #0x88]
     9b8:      	str	xzr, [x8, #0x10]
     9bc:      	b.le	0xa78 <generic_lsm_process_event+0x8a8>
     9c0:      	ldr	x25, [sp, #0x40]
     9c4:      	cmp	w24, #0x18
     9c8:      	mov	x29, x22
     9cc:      	mov	w22, #0x5efc            // =24316
     9d0:      	b.eq	0xbb4 <generic_lsm_process_event+0x9e4>
     9d4:      	cmp	w24, #0x25
     9d8:      	b.eq	0xbf8 <generic_lsm_process_event+0xa28>
     9dc:      	cmp	w24, #0x2a
     9e0:      	b.ne	0xc84 <generic_lsm_process_event+0xab4>
     9e4:      	mov	w8, #0x6430             // =25648
     9e8:      	str	xzr, [x23, #0x6430]
     9ec:      	str	x21, [x23, #0x6438]
     9f0:      	add	x8, x23, x8
     9f4:      	b	0xc24 <generic_lsm_process_event+0xa54>
     9f8:      	ldr	x8, [sp, #0x50]
     9fc:      	cmp	w24, #0x15
     a00:      	stp	x11, x8, [sp, #0x30]
     a04:      	b.gt	0xa50 <generic_lsm_process_event+0x880>
     a08:      	mov	w23, #0x1000            // =4096
     a0c:      	cmp	w24, #0x9
     a10:      	b.le	0xb68 <generic_lsm_process_event+0x998>
     a14:      	cmp	w24, #0x10
     a18:      	b.le	0xc8c <generic_lsm_process_event+0xabc>
     a1c:      	cmp	w24, #0x12
     a20:      	b.le	0xd24 <generic_lsm_process_event+0xb54>
     a24:      	cmp	w24, #0x13
     a28:      	b.eq	0xd1c <generic_lsm_process_event+0xb4c>
     a2c:      	cmp	w24, #0x14
     a30:      	b.eq	0xd5c <generic_lsm_process_event+0xb8c>
     a34:      	cmp	w24, #0x15
     a38:      	b.ne	0xd6c <generic_lsm_process_event+0xb9c>
     a3c:      	mov	w23, #0x20              // =32
     a40:      	b	0xd70 <generic_lsm_process_event+0xba0>
     a44:      	mov	x8, xzr
     a48:      	mov	x29, x22
     a4c:      	b	0x3974 <generic_lsm_process_event+0x37a4>
     a50:      	cmp	w24, #0x20
     a54:      	b.le	0xb90 <generic_lsm_process_event+0x9c0>
     a58:      	cmp	w24, #0x27
     a5c:      	b.gt	0xcb0 <generic_lsm_process_event+0xae0>
     a60:      	sub	w8, w24, #0x21
     a64:      	cmp	w8, #0x4
     a68:      	b.lo	0xca8 <generic_lsm_process_event+0xad8>
     a6c:      	cmp	w24, #0x27
     a70:      	b.eq	0xcfc <generic_lsm_process_event+0xb2c>
     a74:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     a78:      	ldr	x25, [sp, #0x40]
     a7c:      	add	x21, sp, #0xd0
     a80:      	cmp	w24, #0xf
     a84:      	mov	x29, x22
     a88:      	mov	w22, #0x5efc            // =24316
     a8c:      	b.eq	0xc50 <generic_lsm_process_event+0xa80>
     a90:      	cmp	w24, #0x10
     a94:      	b.ne	0xc84 <generic_lsm_process_event+0xab4>
     a98:      	add	x24, sp, #0x60
     a9c:      	b	0xbd8 <generic_lsm_process_event+0xa08>
     aa0:      	add	x21, x8, x9
     aa4:      	ldr	w8, [x29, #0x4]
     aa8:      	ldr	x25, [x23, #0x6440]
     aac:      	mov	w24, #0x4               // =4
     ab0:      	and	x9, x8, #0xfff
     ab4:      	add	x2, x0, x9
     ab8:      	mov	w9, #0xfff              // =4095
     abc:      	add	x0, x21, #0x4
     ac0:      	sub	w8, w9, w8
     ac4:      	and	w23, w8, #0xfff
     ac8:      	mov	w8, #0x4                // =4
     acc:      	mov	w1, w23
     ad0:      	blr	x8
     ad4:      	str	w23, [x21]
     ad8:      	add	x2, x25, #0x8
     adc:      	mov	w25, #0x8               // =8
     ae0:      	add	x8, sp, #0x88
     ae4:      	mov	w9, #0x4                // =4
     ae8:      	add	x0, sp, #0x88
     aec:      	mov	w1, #0x8                // =8
     af0:      	blr	x9
     af4:      	ldr	x8, [sp, #0x88]
     af8:      	add	x9, sp, #0xe0
     afc:      	mov	w10, #0x4               // =4
     b00:      	add	x0, sp, #0xe0
     b04:      	mov	w1, #0x8                // =8
     b08:      	add	x8, x8, #0x30
     b0c:      	ldr	x8, [sp, #0x88]
     b10:      	add	x2, x8, #0x30
     b14:      	blr	x10
     b18:      	add	x11, sp, #0xd0
     b1c:      	mov	w9, #0x2                // =2
     b20:      	add	x10, sp, #0x60
     b24:      	ldr	x8, [x11, #0x10]
     b28:      	add	x0, sp, #0x60
     b2c:      	mov	w1, #0x2                // =2
     b30:      	ldr	x2, [x11, #0x10]
     b34:      	blr	x24
     b38:      	add	x8, x21, x23
     b3c:      	adrp	x21, 0x0 <generic_lsm_setup_event>
     b40:      	ldr	x24, [sp, #0xf8]
     b44:      	ldr	x21, [x21]
     b48:      	str	wzr, [x8, #0x4]
     b4c:      	ldrh	w9, [sp, #0x60]
     b50:      	strh	w9, [x8, #0x8]
     b54:      	add	w8, w23, #0xe
     b58:      	ldr	x25, [sp, #0x40]
     b5c:      	mov	x29, x22
     b60:      	mov	w22, #0x5efc            // =24316
     b64:      	b	0x3988 <generic_lsm_process_event+0x37b8>
     b68:      	cmp	w24, #0x4
     b6c:      	b.gt	0xccc <generic_lsm_process_event+0xafc>
     b70:      	sub	w8, w24, #0x2
     b74:      	cmp	w8, #0x2
     b78:      	b.lo	0xcf4 <generic_lsm_process_event+0xb24>
     b7c:      	cmp	w24, #0x1
     b80:      	b.eq	0xcf4 <generic_lsm_process_event+0xb24>
     b84:      	cmp	w24, #0x4
     b88:      	b.eq	0xca8 <generic_lsm_process_event+0xad8>
     b8c:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     b90:      	cmp	w24, #0x1a
     b94:      	b.gt	0xce8 <generic_lsm_process_event+0xb18>
     b98:      	cmp	w24, #0x16
     b9c:      	b.eq	0xcfc <generic_lsm_process_event+0xb2c>
     ba0:      	cmp	w24, #0x17
     ba4:      	b.eq	0xca8 <generic_lsm_process_event+0xad8>
     ba8:      	cmp	w24, #0x1a
     bac:      	b.eq	0xd4c <generic_lsm_process_event+0xb7c>
     bb0:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     bb4:      	add	x24, sp, #0x60
     bb8:      	mov	w8, #0x8                // =8
     bbc:      	mov	w9, #0x4                // =4
     bc0:      	ldr	x2, [sp, #0x88]
     bc4:      	add	x0, sp, #0x60
     bc8:      	mov	w1, #0x8                // =8
     bcc:      	blr	x9
     bd0:      	ldr	x8, [sp, #0x60]
     bd4:      	str	x8, [sp, #0x88]
     bd8:      	mov	w8, #0x8                // =8
     bdc:      	mov	w9, #0x4                // =4
     be0:      	add	x10, sp, #0x88
     be4:      	add	x0, sp, #0x60
     be8:      	add	x2, sp, #0x88
     bec:      	mov	w1, #0x8                // =8
     bf0:      	blr	x9
     bf4:      	b	0xc1c <generic_lsm_process_event+0xa4c>
     bf8:      	add	x8, x21, #0x40
     bfc:      	mov	w9, #0x8                // =8
     c00:      	mov	w10, #0x4               // =4
     c04:      	str	x8, [sp, #0x88]
     c08:      	add	x11, sp, #0x60
     c0c:      	add	x0, sp, #0x60
     c10:      	mov	w1, #0x8                // =8
     c14:      	ldr	x2, [sp, #0x88]
     c18:      	blr	x10
     c1c:      	ldr	x8, [sp, #0x60]
     c20:      	add	x8, x8, #0x40
     c24:      	adrp	x21, 0x0 <generic_lsm_setup_event>
     c28:      	ldr	x21, [x21]
     c2c:      	str	x8, [x23, #0x6440]
     c30:      	mov	w8, #0x6                // =6
     c34:      	mov	w9, #0xc                // =12
     c38:      	mov	x0, x19
     c3c:      	mov	x1, x29
     c40:      	mov	w2, #0x6                // =6
     c44:      	blr	x9
     c48:      	mov	x8, xzr
     c4c:      	b	0x3984 <generic_lsm_process_event+0x37b4>
     c50:      	mov	w8, #0x8                // =8
     c54:      	mov	w9, #0x4                // =4
     c58:      	add	x10, sp, #0xe0
     c5c:      	add	x11, sp, #0x88
     c60:      	add	x0, sp, #0xe0
     c64:      	add	x2, sp, #0x88
     c68:      	mov	w1, #0x8                // =8
     c6c:      	blr	x9
     c70:      	ldr	x8, [x21, #0x10]
     c74:      	adrp	x21, 0x0 <generic_lsm_setup_event>
     c78:      	ldr	x21, [x21]
     c7c:      	cbnz	x8, 0xc2c <generic_lsm_process_event+0xa5c>
     c80:      	b	0x3984 <generic_lsm_process_event+0x37b4>
     c84:      	mov	x8, xzr
     c88:      	b	0x397c <generic_lsm_process_event+0x37ac>
     c8c:      	sub	w8, w24, #0xa
     c90:      	cmp	w8, #0x2
     c94:      	b.lo	0xca8 <generic_lsm_process_event+0xad8>
     c98:      	sub	w8, w24, #0xc
     c9c:      	cmp	w8, #0x2
     ca0:      	b.lo	0xcf4 <generic_lsm_process_event+0xb24>
     ca4:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     ca8:      	mov	w23, #0x8               // =8
     cac:      	b	0xd70 <generic_lsm_process_event+0xba0>
     cb0:      	cmp	w24, #0x2a
     cb4:      	b.gt	0xd04 <generic_lsm_process_event+0xb34>
     cb8:      	cmp	w24, #0x28
     cbc:      	b.eq	0xd1c <generic_lsm_process_event+0xb4c>
     cc0:      	cmp	w24, #0x29
     cc4:      	b.eq	0xd54 <generic_lsm_process_event+0xb84>
     cc8:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     ccc:      	cmp	w24, #0x6
     cd0:      	b.gt	0xd3c <generic_lsm_process_event+0xb6c>
     cd4:      	cmp	w24, #0x5
     cd8:      	b.eq	0xd54 <generic_lsm_process_event+0xb84>
     cdc:      	cmp	w24, #0x6
     ce0:      	b.eq	0xd70 <generic_lsm_process_event+0xba0>
     ce4:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     ce8:      	sub	w8, w24, #0x1d
     cec:      	cmp	w8, #0x4
     cf0:      	b.hs	0xd64 <generic_lsm_process_event+0xb94>
     cf4:      	mov	w23, #0x4               // =4
     cf8:      	b	0xd70 <generic_lsm_process_event+0xba0>
     cfc:      	mov	w23, #0x10              // =16
     d00:      	b	0xd70 <generic_lsm_process_event+0xba0>
     d04:      	cmp	w24, #0x2b
     d08:      	b.eq	0xd1c <generic_lsm_process_event+0xb4c>
     d0c:      	cmp	w24, #0x2c
     d10:      	b.ne	0xd6c <generic_lsm_process_event+0xb9c>
     d14:      	mov	w23, #0x70              // =112
     d18:      	b	0xd70 <generic_lsm_process_event+0xba0>
     d1c:      	mov	w23, #0x18              // =24
     d20:      	b	0xd70 <generic_lsm_process_event+0xba0>
     d24:      	cmp	w24, #0x11
     d28:      	b.eq	0xd70 <generic_lsm_process_event+0xba0>
     d2c:      	cmp	w24, #0x12
     d30:      	mov	x23, x21
     d34:      	b.eq	0xd70 <generic_lsm_process_event+0xba0>
     d38:      	b	0xd6c <generic_lsm_process_event+0xb9c>
     d3c:      	cmp	w24, #0x7
     d40:      	b.eq	0xd54 <generic_lsm_process_event+0xb84>
     d44:      	cmp	w24, #0x8
     d48:      	b.ne	0xd6c <generic_lsm_process_event+0xb9c>
     d4c:      	mov	w23, #0x50              // =80
     d50:      	b	0xd70 <generic_lsm_process_event+0xba0>
     d54:      	mov	w23, #0x40              // =64
     d58:      	b	0xd70 <generic_lsm_process_event+0xba0>
     d5c:      	mov	w23, #0x98              // =152
     d60:      	b	0xd70 <generic_lsm_process_event+0xba0>
     d64:      	cmp	w24, #0x1b
     d68:      	b.eq	0xd4c <generic_lsm_process_event+0xb7c>
     d6c:      	mov	x23, xzr
     d70:      	str	wzr, [sp, #0x5c]
     d74:      	adrp	x0, 0x0 <generic_lsm_setup_event>
     d78:      	mov	w8, #0x1                // =1
     d7c:      	add	x9, sp, #0x5c
     d80:      	ldr	x0, [x0]
     d84:      	add	x1, sp, #0x5c
     d88:      	blr	x8
     d8c:      	mov	x8, xzr
     d90:      	cbz	x0, 0x3974 <generic_lsm_process_event+0x37a4>
     d94:      	ldr	x10, [sp, #0xf8]
     d98:      	mov	w9, #0x3ffb             // =16379
     d9c:      	sub	x9, x9, x23
     da0:      	cmp	x9, x10
     da4:      	b.ls	0x3974 <generic_lsm_process_event+0x37a4>
     da8:      	add	x12, x0, x25, lsl #2
     dac:      	mov	w8, #0x5ea0             // =24224
     db0:      	ldr	x9, [sp, #0xf8]
     db4:      	add	x10, x0, #0x90
     db8:      	ldr	w8, [x12, x8]
     dbc:      	add	x23, x9, #0x4
     dc0:      	str	w8, [x10, x9]
     dc4:      	add	x9, x0, x25, lsl #3
     dc8:      	str	x23, [x9, #0x5e78]
     dcc:      	cbz	w8, 0xdd8 <generic_lsm_process_event+0xc08>
     dd0:      	mov	w8, #0x4                // =4
     dd4:      	b	0x3974 <generic_lsm_process_event+0x37a4>
     dd8:      	ldr	x11, [sp, #0x38]
     ddc:      	add	x8, x10, x23
     de0:      	cmp	w24, #0x17
     de4:      	str	xzr, [x22, #0x10]
     de8:      	str	x12, [sp, #0x28]
     dec:      	stp	x8, x10, [sp, #0x18]
     df0:      	str	x11, [sp, #0x88]
     df4:      	b.le	0xe1c <generic_lsm_process_event+0xc4c>
     df8:      	cmp	w24, #0x18
     dfc:      	b.eq	0xe34 <generic_lsm_process_event+0xc64>
     e00:      	cmp	w24, #0x25
     e04:      	b.eq	0xe78 <generic_lsm_process_event+0xca8>
     e08:      	cmp	w24, #0x2a
     e0c:      	b.ne	0x1520 <generic_lsm_process_event+0x1350>
     e10:      	stp	xzr, x11, [sp, #0x60]
     e14:      	add	x25, sp, #0x60
     e18:      	b	0xea4 <generic_lsm_process_event+0xcd4>
     e1c:      	cmp	w24, #0xf
     e20:      	b.eq	0x147c <generic_lsm_process_event+0x12ac>
     e24:      	cmp	w24, #0x10
     e28:      	b.ne	0x1520 <generic_lsm_process_event+0x1350>
     e2c:      	add	x21, sp, #0xd8
     e30:      	b	0xe58 <generic_lsm_process_event+0xc88>
     e34:      	add	x21, sp, #0xd8
     e38:      	mov	w8, #0x8                // =8
     e3c:      	mov	w9, #0x4                // =4
     e40:      	ldr	x2, [sp, #0x88]
     e44:      	add	x0, sp, #0xd8
     e48:      	mov	w1, #0x8                // =8
     e4c:      	blr	x9
     e50:      	ldr	x8, [x22, #0x8]
     e54:      	str	x8, [sp, #0x88]
     e58:      	mov	w8, #0x8                // =8
     e5c:      	mov	w9, #0x4                // =4
     e60:      	add	x10, sp, #0x88
     e64:      	add	x0, sp, #0xd8
     e68:      	add	x2, sp, #0x88
     e6c:      	mov	w1, #0x8                // =8
     e70:      	blr	x9
     e74:      	b	0xe9c <generic_lsm_process_event+0xccc>
     e78:      	add	x8, x11, #0x40
     e7c:      	mov	w9, #0x8                // =8
     e80:      	mov	w10, #0x4               // =4
     e84:      	str	x8, [sp, #0x88]
     e88:      	add	x11, sp, #0xd8
     e8c:      	add	x0, sp, #0xd8
     e90:      	mov	w1, #0x8                // =8
     e94:      	ldr	x2, [sp, #0x88]
     e98:      	blr	x10
     e9c:      	ldr	x8, [x22, #0x8]
     ea0:      	add	x25, x8, #0x40
     ea4:      	str	wzr, [sp, #0x74]
     ea8:      	adrp	x0, 0x0 <generic_lsm_setup_event>
     eac:      	mov	w8, #0x1                // =1
     eb0:      	add	x9, sp, #0x74
     eb4:      	ldr	x0, [x0]
     eb8:      	add	x1, sp, #0x74
     ebc:      	blr	x8
     ec0:      	cbz	x0, 0x13d0 <generic_lsm_process_event+0x1200>
     ec4:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     ec8:      	mov	x24, x0
     ecc:      	str	x8, [sp, #0x30]
     ed0:      	mov	w8, #0x23               // =35
     ed4:      	blr	x8
     ed8:      	add	x2, x0, #0xb30
     edc:      	mov	w29, #0x8               // =8
     ee0:      	add	x8, sp, #0x78
     ee4:      	mov	w9, #0x4                // =4
     ee8:      	add	x0, sp, #0x78
     eec:      	mov	w1, #0x8                // =8
     ef0:      	mov	w21, #0x4               // =4
     ef4:      	blr	x9
     ef8:      	ldr	x8, [sp, #0x78]
     efc:      	add	x2, x25, #0x8
     f00:      	mov	w9, #0x4                // =4
     f04:      	add	x0, sp, #0x80
     f08:      	mov	w1, #0x8                // =8
     f0c:      	mov	x22, x8
     f10:      	add	x8, x8, #0x18
     f14:      	str	x8, [sp, #0x38]
     f18:      	add	x8, sp, #0x80
     f1c:      	str	x2, [sp, #0x10]
     f20:      	blr	x9
     f24:      	ldr	x23, [sp, #0x80]
     f28:      	add	x8, sp, #0x88
     f2c:      	add	x0, sp, #0x88
     f30:      	mov	w1, #0x8                // =8
     f34:      	add	x2, x23, #0x10
     f38:      	blr	x21
     f3c:      	ldr	x8, [sp, #0x88]
     f40:      	str	x25, [sp, #0x8]
     f44:      	cbz	x8, 0xf54 <generic_lsm_process_event+0xd84>
     f48:      	ldr	x9, [sp, #0x30]
     f4c:      	mov	w8, #0x1000             // =4096
     f50:      	b	0xf9c <generic_lsm_process_event+0xdcc>
     f54:      	add	x2, x23, #0x18
     f58:      	mov	w8, #0x8                // =8
     f5c:      	mov	w9, #0x4                // =4
     f60:      	add	x10, sp, #0x88
     f64:      	add	x0, sp, #0x88
     f68:      	mov	w1, #0x8                // =8
     f6c:      	blr	x9
     f70:      	ldr	x8, [sp, #0x88]
     f74:      	cmp	x8, x23
     f78:      	b.eq	0xf48 <generic_lsm_process_event+0xd78>
     f7c:      	mov	w8, #0x2964             // =10596
     f80:      	add	x9, x24, #0xff6
     f84:      	strh	w8, [x24, #0xffe]
     f88:      	adrp	x8, 0x0 <generic_lsm_setup_event>
     f8c:      	add	x8, x8, #0x0
     f90:      	ldr	x8, [x8]
     f94:      	str	x8, [x9]
     f98:      	mov	w8, #0xff6              // =4086
     f9c:      	stp	xzr, xzr, [sp, #0x88]
     fa0:      	add	x10, sp, #0x88
     fa4:      	add	x2, x22, #0x20
     fa8:      	mov	w21, #0x8               // =8
     fac:      	add	x0, sp, #0x88
     fb0:      	mov	w1, #0x8                // =8
     fb4:      	stp	x24, xzr, [sp, #0x98]
     fb8:      	add	x23, x10, #0x8
     fbc:      	add	x25, x10, #0x18
     fc0:      	stp	xzr, xzr, [sp, #0xa8]
     fc4:      	add	x24, x10, #0x20
     fc8:      	mov	w29, #0x4               // =4
     fcc:      	str	x9, [sp, #0x30]
     fd0:      	str	x9, [sp, #0xb8]
     fd4:      	str	w8, [sp, #0xc0]
     fd8:      	mov	w8, #0x4                // =4
     fdc:      	strb	wzr, [sp, #0xc4]
     fe0:      	blr	x8
     fe4:      	ldr	x2, [sp, #0x38]
     fe8:      	mov	w8, #0x4                // =4
     fec:      	mov	x0, x23
     ff0:      	mov	w1, #0x8                // =8
     ff4:      	blr	x8
     ff8:      	ldr	x2, [sp, #0x10]
     ffc:      	mov	w8, #0x4                // =4
    1000:      	mov	x0, x25
    1004:      	mov	w1, #0x8                // =8
    1008:      	str	x25, [sp, #0x38]
    100c:      	blr	x8
    1010:      	ldr	x2, [sp, #0x8]
    1014:      	mov	x0, x24
    1018:      	mov	w1, #0x8                // =8
    101c:      	blr	x29
    1020:      	ldr	x8, [sp, #0xa8]
    1024:      	sub	x8, x8, #0x20
    1028:      	str	x8, [sp, #0xb0]
    102c:      	adrp	x8, 0x1000 <generic_lsm_process_event+0xe30>
    1030:      	ldr	x8, [x8]
    1034:      	ldrb	w8, [x8]
    1038:      	cbz	w8, 0x11e0 <generic_lsm_process_event+0x1010>
    103c:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1040:      	mov	w21, #0x80              // =128
    1044:      	mov	w23, #0x8               // =8
    1048:      	ldr	x29, [x29]
    104c:      	b	0x1058 <generic_lsm_process_event+0xe88>
    1050:      	subs	w21, w21, #0x1
    1054:      	b.eq	0x1390 <generic_lsm_process_event+0x11c0>
    1058:      	ldp	x25, x2, [sp, #0xa0]
    105c:      	ldp	x8, x9, [sp, #0x88]
    1060:      	cmp	x25, x8
    1064:      	ccmp	x2, x9, #0x0, eq
    1068:      	b.eq	0x1388 <generic_lsm_process_event+0x11b8>
    106c:      	ldr	x24, [sp, #0xb0]
    1070:      	mov	w8, #0x4                // =4
    1074:      	add	x9, sp, #0xc8
    1078:      	add	x0, sp, #0xc8
    107c:      	mov	w1, #0x8                // =8
    1080:      	blr	x8
    1084:      	ldr	x8, [sp, #0xc8]
    1088:      	mov	w22, #0x8               // =8
    108c:      	cmp	x25, x8
    1090:      	b.eq	0x1188 <generic_lsm_process_event+0xfb8>
    1094:      	add	x23, x25, #0x18
    1098:      	mov	w8, #0x4                // =4
    109c:      	add	x9, sp, #0xd8
    10a0:      	add	x0, sp, #0xd8
    10a4:      	mov	w1, #0x8                // =8
    10a8:      	mov	x2, x23
    10ac:      	blr	x8
    10b0:      	add	x8, sp, #0xd0
    10b4:      	ldr	x8, [x8, #0x8]
    10b8:      	cmp	x8, x25
    10bc:      	b.eq	0x1188 <generic_lsm_process_event+0xfb8>
    10c0:      	mov	w8, #0x4                // =4
    10c4:      	add	x9, sp, #0xd0
    10c8:      	add	x0, sp, #0xd0
    10cc:      	mov	w1, #0x8                // =8
    10d0:      	mov	x2, x23
    10d4:      	blr	x8
    10d8:      	add	x2, x25, #0x20
    10dc:      	mov	w8, #0x4                // =4
    10e0:      	mov	w9, #0x10               // =16
    10e4:      	add	x10, sp, #0xe0
    10e8:      	add	x0, sp, #0xe0
    10ec:      	mov	w1, #0x10               // =16
    10f0:      	blr	x8
    10f4:      	add	x8, sp, #0xd0
    10f8:      	ldr	w23, [sp, #0xe4]
    10fc:      	ldr	x10, [sp, #0xb8]
    1100:      	add	x22, sp, #0xd0
    1104:      	ldr	w24, [sp, #0xc0]
    1108:      	ldr	x9, [x8, #0x18]
    110c:      	ldr	x8, [sp, #0x98]
    1110:      	sub	x12, x10, x8
    1114:      	subs	w10, w23, w24
    1118:      	csel	w10, wzr, w10, lo
    111c:      	cmp	w24, w23
    1120:      	csel	w11, w24, w23, lo
    1124:      	cinc	w13, w11, hi
    1128:      	sub	w14, w24, w13
    112c:      	subs	x12, x12, x13
    1130:      	str	w14, [sp, #0xc0]
    1134:      	b.lo	0x1390 <generic_lsm_process_event+0x11c0>
    1138:      	cmp	x12, #0xfff
    113c:      	b.hi	0x1390 <generic_lsm_process_event+0x11c0>
    1140:      	cmp	w24, w23
    1144:      	b.ls	0x1150 <generic_lsm_process_event+0xf80>
    1148:      	mov	w13, #0x2f              // =47
    114c:      	strb	w13, [x8, x12]
    1150:      	add	x25, x8, x12
    1154:      	cmp	w24, w23
    1158:      	add	x2, x9, x10
    115c:      	and	w1, w11, #0xff
    1160:      	mov	w8, #0x4                // =4
    1164:      	cinc	x0, x25, hi
    1168:      	blr	x8
    116c:      	cmp	w24, w23
    1170:      	str	x25, [sp, #0xb8]
    1174:      	b.ls	0x1390 <generic_lsm_process_event+0x11c0>
    1178:      	ldr	x8, [x22]
    117c:      	mov	w23, #0x8               // =8
    1180:      	str	x8, [sp, #0xa0]
    1184:      	b	0x1050 <generic_lsm_process_event+0xe80>
    1188:      	add	x2, x24, #0x10
    118c:      	mov	w8, #0x4                // =4
    1190:      	add	x9, sp, #0xd8
    1194:      	add	x0, sp, #0xd8
    1198:      	mov	w1, #0x8                // =8
    119c:      	blr	x8
    11a0:      	add	x9, sp, #0xd0
    11a4:      	ldr	x8, [sp, #0xb0]
    11a8:      	mov	w23, #0x8               // =8
    11ac:      	add	x22, sp, #0xd0
    11b0:      	ldr	x9, [x9, #0x8]
    11b4:      	cmp	x8, x9
    11b8:      	b.eq	0x1388 <generic_lsm_process_event+0x11b8>
    11bc:      	ldr	x0, [sp, #0x38]
    11c0:      	add	x2, x24, #0x18
    11c4:      	mov	w8, #0x4                // =4
    11c8:      	mov	w1, #0x8                // =8
    11cc:      	blr	x8
    11d0:      	ldr	x8, [x22, #0x8]
    11d4:      	add	x9, x8, #0x20
    11d8:      	stp	x9, x8, [sp, #0xa8]
    11dc:      	b	0x1050 <generic_lsm_process_event+0xe80>
    11e0:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    11e4:      	mov	w21, #0x80              // =128
    11e8:      	mov	w23, #0x8               // =8
    11ec:      	ldr	x29, [x29]
    11f0:      	ldp	x25, x2, [sp, #0xa0]
    11f4:      	ldp	x8, x9, [sp, #0x88]
    11f8:      	cmp	x25, x8
    11fc:      	ccmp	x2, x9, #0x0, eq
    1200:      	b.eq	0x1388 <generic_lsm_process_event+0x11b8>
    1204:      	ldr	x24, [sp, #0xb0]
    1208:      	mov	w8, #0x4                // =4
    120c:      	add	x9, sp, #0xc8
    1210:      	add	x0, sp, #0xc8
    1214:      	mov	w1, #0x8                // =8
    1218:      	blr	x8
    121c:      	ldr	x8, [sp, #0xc8]
    1220:      	mov	w22, #0x8               // =8
    1224:      	cmp	x25, x8
    1228:      	b.eq	0x1328 <generic_lsm_process_event+0x1158>
    122c:      	add	x23, x25, #0x18
    1230:      	mov	w8, #0x4                // =4
    1234:      	add	x9, sp, #0xd8
    1238:      	add	x0, sp, #0xd8
    123c:      	mov	w1, #0x8                // =8
    1240:      	mov	x2, x23
    1244:      	blr	x8
    1248:      	add	x8, sp, #0xd0
    124c:      	ldr	x8, [x8, #0x8]
    1250:      	cmp	x8, x25
    1254:      	b.eq	0x1328 <generic_lsm_process_event+0x1158>
    1258:      	mov	w8, #0x4                // =4
    125c:      	add	x9, sp, #0xd0
    1260:      	add	x0, sp, #0xd0
    1264:      	mov	w1, #0x8                // =8
    1268:      	mov	x2, x23
    126c:      	blr	x8
    1270:      	add	x2, x25, #0x20
    1274:      	mov	w8, #0x4                // =4
    1278:      	mov	w9, #0x10               // =16
    127c:      	add	x10, sp, #0xe0
    1280:      	add	x0, sp, #0xe0
    1284:      	mov	w1, #0x10               // =16
    1288:      	blr	x8
    128c:      	add	x8, sp, #0xd0
    1290:      	ldr	w23, [sp, #0xe4]
    1294:      	ldr	x10, [sp, #0xb8]
    1298:      	add	x22, sp, #0xd0
    129c:      	ldr	w24, [sp, #0xc0]
    12a0:      	ldr	x9, [x8, #0x18]
    12a4:      	ldr	x8, [sp, #0x98]
    12a8:      	sub	x12, x10, x8
    12ac:      	subs	w10, w23, w24
    12b0:      	csel	w10, wzr, w10, lo
    12b4:      	cmp	w24, w23
    12b8:      	csel	w11, w24, w23, lo
    12bc:      	cinc	w13, w11, hi
    12c0:      	sub	w14, w24, w13
    12c4:      	subs	x12, x12, x13
    12c8:      	str	w14, [sp, #0xc0]
    12cc:      	b.lo	0x1390 <generic_lsm_process_event+0x11c0>
    12d0:      	cmp	x12, #0xfff
    12d4:      	b.hi	0x1390 <generic_lsm_process_event+0x11c0>
    12d8:      	cmp	w24, w23
    12dc:      	b.ls	0x12e8 <generic_lsm_process_event+0x1118>
    12e0:      	mov	w13, #0x2f              // =47
    12e4:      	strb	w13, [x8, x12]
    12e8:      	add	x25, x8, x12
    12ec:      	cmp	w24, w23
    12f0:      	add	x2, x9, x10
    12f4:      	and	w1, w11, #0xff
    12f8:      	mov	w8, #0x4                // =4
    12fc:      	cinc	x0, x25, hi
    1300:      	blr	x8
    1304:      	cmp	w24, w23
    1308:      	str	x25, [sp, #0xb8]
    130c:      	b.ls	0x1390 <generic_lsm_process_event+0x11c0>
    1310:      	ldr	x8, [x22]
    1314:      	mov	w23, #0x8               // =8
    1318:      	str	x8, [sp, #0xa0]
    131c:      	subs	w21, w21, #0x1
    1320:      	b.ne	0x11f0 <generic_lsm_process_event+0x1020>
    1324:      	b	0x1390 <generic_lsm_process_event+0x11c0>
    1328:      	add	x2, x24, #0x10
    132c:      	mov	w8, #0x4                // =4
    1330:      	add	x9, sp, #0xd8
    1334:      	add	x0, sp, #0xd8
    1338:      	mov	w1, #0x8                // =8
    133c:      	blr	x8
    1340:      	add	x9, sp, #0xd0
    1344:      	ldr	x8, [sp, #0xb0]
    1348:      	mov	w23, #0x8               // =8
    134c:      	add	x22, sp, #0xd0
    1350:      	ldr	x9, [x9, #0x8]
    1354:      	cmp	x8, x9
    1358:      	b.eq	0x1388 <generic_lsm_process_event+0x11b8>
    135c:      	ldr	x0, [sp, #0x38]
    1360:      	add	x2, x24, #0x18
    1364:      	mov	w8, #0x4                // =4
    1368:      	mov	w1, #0x8                // =8
    136c:      	blr	x8
    1370:      	ldr	x8, [x22, #0x8]
    1374:      	add	x9, x8, #0x20
    1378:      	stp	x9, x8, [sp, #0xa8]
    137c:      	subs	w21, w21, #0x1
    1380:      	b.ne	0x11f0 <generic_lsm_process_event+0x1020>
    1384:      	b	0x1390 <generic_lsm_process_event+0x11c0>
    1388:      	mov	w8, #0x1                // =1
    138c:      	strb	w8, [sp, #0xc4]
    1390:      	ldr	x8, [sp, #0xb8]
    1394:      	ldr	x2, [sp, #0x30]
    1398:      	cmp	x8, x2
    139c:      	b.eq	0x13d8 <generic_lsm_process_event+0x1208>
    13a0:      	ldrb	w9, [sp, #0xc4]
    13a4:      	mov	w11, #0x1000            // =4096
    13a8:      	cmp	w9, #0x0
    13ac:      	ldr	w9, [sp, #0xc0]
    13b0:      	cset	w10, eq
    13b4:      	sub	w11, w11, w9
    13b8:      	cmp	w9, #0x0
    13bc:      	csel	w9, w11, w9, gt
    13c0:      	cbz	x8, 0x13d0 <generic_lsm_process_event+0x1200>
    13c4:      	lsl	w21, w10, #1
    13c8:      	mov	x2, x8
    13cc:      	b	0x13e0 <generic_lsm_process_event+0x1210>
    13d0:      	mov	x25, xzr
    13d4:      	b	0x396c <generic_lsm_process_event+0x379c>
    13d8:      	mov	w9, wzr
    13dc:      	mov	w21, wzr
    13e0:      	ldr	x22, [sp, #0x18]
    13e4:      	and	w23, w9, #0xfff
    13e8:      	mov	w8, #0x4                // =4
    13ec:      	mov	w24, #0x4               // =4
    13f0:      	mov	w1, w23
    13f4:      	add	x0, x22, #0x4
    13f8:      	blr	x8
    13fc:      	str	w23, [x22]
    1400:      	ldr	x2, [sp, #0x10]
    1404:      	mov	w25, #0x8               // =8
    1408:      	add	x8, sp, #0x88
    140c:      	mov	w9, #0x4                // =4
    1410:      	add	x0, sp, #0x88
    1414:      	mov	w1, #0x8                // =8
    1418:      	blr	x9
    141c:      	ldr	x8, [sp, #0x88]
    1420:      	add	x9, sp, #0xe0
    1424:      	mov	w10, #0x4               // =4
    1428:      	add	x0, sp, #0xe0
    142c:      	mov	w1, #0x8                // =8
    1430:      	add	x8, x8, #0x30
    1434:      	ldr	x8, [sp, #0x88]
    1438:      	add	x2, x8, #0x30
    143c:      	blr	x10
    1440:      	add	x11, sp, #0xd0
    1444:      	mov	w9, #0x2                // =2
    1448:      	add	x10, sp, #0xd8
    144c:      	ldr	x8, [x11, #0x10]
    1450:      	add	x0, sp, #0xd8
    1454:      	mov	w1, #0x2                // =2
    1458:      	ldr	x2, [x11, #0x10]
    145c:      	blr	x24
    1460:      	add	x8, x22, x23
    1464:      	add	w25, w23, #0xa
    1468:      	str	w21, [x8, #0x4]
    146c:      	ldrh	w9, [sp, #0xd8]
    1470:      	strh	w9, [x8, #0x8]
    1474:      	ldp	x10, x12, [sp, #0x20]
    1478:      	b	0x3964 <generic_lsm_process_event+0x3794>
    147c:      	mov	w8, #0x8                // =8
    1480:      	mov	w9, #0x4                // =4
    1484:      	add	x10, sp, #0xe0
    1488:      	add	x11, sp, #0x88
    148c:      	add	x0, sp, #0xe0
    1490:      	add	x2, sp, #0x88
    1494:      	mov	w1, #0x8                // =8
    1498:      	blr	x9
    149c:      	ldr	x25, [x22, #0x10]
    14a0:      	cbnz	x25, 0xea4 <generic_lsm_process_event+0xcd4>
    14a4:      	str	wzr, [sp, #0x80]
    14a8:      	adrp	x0, 0x1000 <generic_lsm_process_event+0xe30>
    14ac:      	mov	w8, #0x1                // =1
    14b0:      	add	x9, sp, #0x80
    14b4:      	ldr	x0, [x0]
    14b8:      	add	x1, sp, #0x80
    14bc:      	blr	x8
    14c0:      	mov	x25, xzr
    14c4:      	cbz	x0, 0x395c <generic_lsm_process_event+0x378c>
    14c8:      	cmp	w24, #0x19
    14cc:      	b.gt	0x17bc <generic_lsm_process_event+0x15ec>
    14d0:      	add	x9, sp, #0xd0
    14d4:      	cmp	w24, #0x12
    14d8:      	str	x0, [sp, #0x10]
    14dc:      	b.le	0x18b0 <generic_lsm_process_event+0x16e0>
    14e0:      	cmp	w24, #0x14
    14e4:      	b.le	0x1b90 <generic_lsm_process_event+0x19c0>
    14e8:      	cmp	w24, #0x15
    14ec:      	b.eq	0x2388 <generic_lsm_process_event+0x21b8>
    14f0:      	cmp	w24, #0x16
    14f4:      	b.eq	0x2328 <generic_lsm_process_event+0x2158>
    14f8:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    14fc:      	cmp	w24, #0x17
    1500:      	ldr	x29, [x29]
    1504:      	ldr	x12, [sp, #0x28]
    1508:      	b.ne	0x3960 <generic_lsm_process_event+0x3790>
    150c:      	ldr	x8, [sp, #0x18]
    1510:      	ldr	x9, [sp, #0x38]
    1514:      	mov	w25, #0x8               // =8
    1518:      	stp	w9, wzr, [x8]
    151c:      	b	0x3960 <generic_lsm_process_event+0x3790>
    1520:      	cmp	w24, #0x2c
    1524:      	b.hi	0x14a4 <generic_lsm_process_event+0x12d4>
    1528:      	mov	x9, #0x7cf2             // =31986
    152c:      	mov	w8, #0x1                // =1
    1530:      	movk	x9, #0xf202, lsl #16
    1534:      	lsl	x8, x8, x24
    1538:      	movk	x9, #0x11c1, lsl #32
    153c:      	tst	x8, x9
    1540:      	b.eq	0x14a4 <generic_lsm_process_event+0x12d4>
    1544:      	str	x11, [x22]
    1548:      	str	wzr, [sp, #0x80]
    154c:      	adrp	x0, 0x1000 <generic_lsm_process_event+0xe30>
    1550:      	mov	w8, #0x1                // =1
    1554:      	add	x9, sp, #0x80
    1558:      	add	x1, sp, #0x80
    155c:      	ldr	x0, [x0]
    1560:      	blr	x8
    1564:      	mov	x25, xzr
    1568:      	cbz	x0, 0x1474 <generic_lsm_process_event+0x12a4>
    156c:      	ldr	x12, [sp, #0x28]
    1570:      	cmp	w24, #0x10
    1574:      	b.le	0x15cc <generic_lsm_process_event+0x13fc>
    1578:      	add	x11, sp, #0xd0
    157c:      	cmp	w24, #0x1e
    1580:      	b.le	0x16e8 <generic_lsm_process_event+0x1518>
    1584:      	mov	x21, x29
    1588:      	cmp	w24, #0x26
    158c:      	b.gt	0x17ec <generic_lsm_process_event+0x161c>
    1590:      	sub	w8, w24, #0x1f
    1594:      	cmp	w8, #0x2
    1598:      	b.hs	0x1c48 <generic_lsm_process_event+0x1a78>
    159c:      	ldr	x0, [sp, #0x18]
    15a0:      	mov	w8, #0x1                // =1
    15a4:      	add	x9, sp, #0xd0
    15a8:      	mov	w10, #0x4               // =4
    15ac:      	add	x2, sp, #0xd0
    15b0:      	mov	w1, #0x1                // =1
    15b4:      	mov	w25, #0x4               // =4
    15b8:      	blr	x10
    15bc:      	mov	x29, x21
    15c0:      	b	0x395c <generic_lsm_process_event+0x378c>
    15c4:      	mov	w10, #0x5               // =5
    15c8:      	b	0x8dc <generic_lsm_process_event+0x70c>
    15cc:      	cmp	w24, #0x9
    15d0:      	b.gt	0x170c <generic_lsm_process_event+0x153c>
    15d4:      	cmp	w24, #0x4
    15d8:      	b.le	0x1944 <generic_lsm_process_event+0x1774>
    15dc:      	cmp	w24, #0x5
    15e0:      	b.eq	0x1f48 <generic_lsm_process_event+0x1d78>
    15e4:      	cmp	w24, #0x6
    15e8:      	b.eq	0x1774 <generic_lsm_process_event+0x15a4>
    15ec:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    15f0:      	cmp	w24, #0x7
    15f4:      	mov	w9, #0x5ea0             // =24224
    15f8:      	ldr	x29, [x29]
    15fc:      	ldp	x10, x12, [sp, #0x20]
    1600:      	b.ne	0x3968 <generic_lsm_process_event+0x3798>
    1604:      	add	x8, sp, #0xd0
    1608:      	ldr	x22, [sp, #0x18]
    160c:      	mov	x21, x0
    1610:      	mov	w25, #0x2               // =2
    1614:      	ldr	x23, [x8]
    1618:      	mov	w8, #0x4                // =4
    161c:      	mov	w1, #0x2                // =2
    1620:      	mov	w24, #0x4               // =4
    1624:      	str	x23, [x22, #0x28]
    1628:      	add	x0, x22, #0x26
    162c:      	add	x2, x23, #0x10
    1630:      	blr	x8
    1634:      	add	x0, x22, #0x3a
    1638:      	add	x2, x23, #0x12
    163c:      	mov	w8, #0x1                // =1
    1640:      	mov	w9, #0x4                // =4
    1644:      	mov	w1, #0x1                // =1
    1648:      	blr	x9
    164c:      	add	x0, x22, #0x38
    1650:      	add	x2, x23, #0x21e
    1654:      	mov	w8, #0x4                // =4
    1658:      	mov	w1, #0x2                // =2
    165c:      	blr	x8
    1660:      	add	x0, x22, #0x24
    1664:      	add	x2, x23, #0x21c
    1668:      	mov	w8, #0x4                // =4
    166c:      	mov	w1, #0x2                // =2
    1670:      	blr	x8
    1674:      	add	x0, x22, #0x30
    1678:      	add	x2, x23, #0x214
    167c:      	mov	w8, #0x4                // =4
    1680:      	mov	w1, #0x4                // =4
    1684:      	blr	x8
    1688:      	add	x0, x22, #0x34
    168c:      	add	x2, x23, #0x210
    1690:      	mov	w1, #0x4                // =4
    1694:      	blr	x24
    1698:      	ldrh	w8, [x22, #0x26]
    169c:      	mov	x24, x22
    16a0:      	stp	xzr, xzr, [x22]
    16a4:      	cmp	w8, #0xa
    16a8:      	str	xzr, [x22, #0x18]
    16ac:      	str	xzr, [x24, #0x10]!
    16b0:      	b.eq	0x2660 <generic_lsm_process_event+0x2490>
    16b4:      	cmp	w8, #0x2
    16b8:      	b.ne	0x268c <generic_lsm_process_event+0x24bc>
    16bc:      	ldr	x0, [sp, #0x18]
    16c0:      	add	x2, x23, #0x4
    16c4:      	mov	w8, #0x4                // =4
    16c8:      	mov	w1, #0x4                // =4
    16cc:      	mov	w25, #0x4               // =4
    16d0:      	blr	x8
    16d4:      	mov	x0, x24
    16d8:      	mov	w1, #0x4                // =4
    16dc:      	mov	x2, x23
    16e0:      	blr	x25
    16e4:      	b	0x268c <generic_lsm_process_event+0x24bc>
    16e8:      	cmp	w24, #0x1c
    16ec:      	str	x0, [sp, #0x38]
    16f0:      	b.gt	0x1920 <generic_lsm_process_event+0x1750>
    16f4:      	cmp	w24, #0x11
    16f8:      	b.eq	0x1c80 <generic_lsm_process_event+0x1ab0>
    16fc:      	cmp	w24, #0x19
    1700:      	b.eq	0x1d34 <generic_lsm_process_event+0x1b64>
    1704:      	cmp	w24, #0x1c
    1708:      	b	0x1958 <generic_lsm_process_event+0x1788>
    170c:      	sub	w8, w24, #0xa
    1710:      	cmp	w8, #0x2
    1714:      	b.lo	0x1964 <generic_lsm_process_event+0x1794>
    1718:      	sub	w8, w24, #0xc
    171c:      	cmp	w8, #0x2
    1720:      	b.lo	0x1990 <generic_lsm_process_event+0x17c0>
    1724:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1728:      	cmp	w24, #0xe
    172c:      	mov	w9, #0x5ea0             // =24224
    1730:      	ldr	x29, [x29]
    1734:      	ldp	x10, x12, [sp, #0x20]
    1738:      	b.ne	0x3968 <generic_lsm_process_event+0x3798>
    173c:      	mov	w21, #0x8               // =8
    1740:      	add	x8, sp, #0x88
    1744:      	add	x24, sp, #0xd0
    1748:      	mov	w9, #0x4                // =4
    174c:      	add	x0, sp, #0x88
    1750:      	add	x2, sp, #0xd0
    1754:      	mov	w1, #0x8                // =8
    1758:      	mov	w23, #0x4               // =4
    175c:      	blr	x9
    1760:      	ldr	x8, [sp, #0x88]
    1764:      	add	x0, sp, #0xd0
    1768:      	mov	w1, #0x8                // =8
    176c:      	ldr	x2, [sp, #0x88]
    1770:      	blr	x23
    1774:      	add	x8, sp, #0xd0
    1778:      	mov	w9, #0x2d               // =45
    177c:      	mov	w1, #0x1001             // =4097
    1780:      	ldr	x2, [x8]
    1784:      	ldr	x8, [sp, #0x18]
    1788:      	add	x0, x8, #0x4
    178c:      	mov	w8, #0x1001             // =4097
    1790:      	blr	x9
    1794:      	mov	x25, x0
    1798:      	tbnz	x0, #0x3f, 0x3954 <generic_lsm_process_event+0x3784>
    179c:      	ldr	x9, [sp, #0x18]
    17a0:      	sub	w8, w25, #0x1
    17a4:      	add	x25, x25, #0x3
    17a8:      	str	w8, [x9]
    17ac:      	b	0x3954 <generic_lsm_process_event+0x3784>
    17b0:      	mov	w10, #0x6               // =6
    17b4:      	mov	x11, x22
    17b8:      	b	0x8dc <generic_lsm_process_event+0x70c>
    17bc:      	cmp	w24, #0x20
    17c0:      	b.le	0x1ad0 <generic_lsm_process_event+0x1900>
    17c4:      	sub	w8, w24, #0x21
    17c8:      	cmp	w8, #0x4
    17cc:      	b.hs	0x19b0 <generic_lsm_process_event+0x17e0>
    17d0:      	ldr	x0, [sp, #0x18]
    17d4:      	ldr	x2, [sp, #0x38]
    17d8:      	mov	w25, #0x8               // =8
    17dc:      	mov	w8, #0x4                // =4
    17e0:      	mov	w1, #0x8                // =8
    17e4:      	blr	x8
    17e8:      	b	0x3954 <generic_lsm_process_event+0x3784>
    17ec:      	cmp	w24, #0x27
    17f0:      	b.eq	0x20a4 <generic_lsm_process_event+0x1ed4>
    17f4:      	cmp	w24, #0x28
    17f8:      	b.eq	0x20e4 <generic_lsm_process_event+0x1f14>
    17fc:      	ldp	x10, x12, [sp, #0x20]
    1800:      	cmp	w24, #0x2c
    1804:      	mov	x29, x21
    1808:      	mov	w9, #0x5ea0             // =24224
    180c:      	b.ne	0x3968 <generic_lsm_process_event+0x3798>
    1810:      	ldr	x0, [sp, #0x18]
    1814:      	ldr	x23, [x11]
    1818:      	mov	w8, #0x2                // =2
    181c:      	mov	w9, #0x4                // =4
    1820:      	mov	w1, #0x2                // =2
    1824:      	mov	x2, x23
    1828:      	strb	wzr, [sp, #0x88]
    182c:      	stp	xzr, xzr, [x0]
    1830:      	stp	xzr, xzr, [x0, #0x10]
    1834:      	stp	xzr, xzr, [x0, #0x20]
    1838:      	stp	xzr, xzr, [x0, #0x30]
    183c:      	stp	xzr, xzr, [x0, #0x40]
    1840:      	stp	xzr, xzr, [x0, #0x50]
    1844:      	stp	xzr, xzr, [x0, #0x60]
    1848:      	blr	x9
    184c:      	tbnz	x0, #0x3f, 0x2874 <generic_lsm_process_event+0x26a4>
    1850:      	add	x24, x23, #0x2
    1854:      	mov	w8, #0x1                // =1
    1858:      	mov	w9, #0x4                // =4
    185c:      	add	x10, sp, #0x88
    1860:      	add	x0, sp, #0x88
    1864:      	mov	w1, #0x1                // =1
    1868:      	mov	x2, x24
    186c:      	blr	x9
    1870:      	tbnz	x0, #0x3f, 0x2874 <generic_lsm_process_event+0x26a4>
    1874:      	ldrb	w8, [sp, #0x88]
    1878:      	ldr	x10, [sp, #0x18]
    187c:      	cmp	w8, #0x0
    1880:      	add	x0, x10, #0x4
    1884:      	cset	w9, eq
    1888:      	strb	w9, [x10, #0x2]
    188c:      	cbz	w8, 0x2854 <generic_lsm_process_event+0x2684>
    1890:      	mov	w8, #0x6c               // =108
    1894:      	mov	w9, #0x2d               // =45
    1898:      	mov	w1, #0x6c               // =108
    189c:      	mov	x2, x24
    18a0:      	blr	x9
    18a4:      	tbnz	w0, #0x1f, 0x2874 <generic_lsm_process_event+0x26a4>
    18a8:      	sub	w22, w0, #0x1
    18ac:      	b	0x286c <generic_lsm_process_event+0x269c>
    18b0:      	cmp	w24, #0x7
    18b4:      	b.gt	0x1b50 <generic_lsm_process_event+0x1980>
    18b8:      	cmp	w24, #0x2
    18bc:      	b.eq	0x215c <generic_lsm_process_event+0x1f8c>
    18c0:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    18c4:      	cmp	w24, #0x3
    18c8:      	ldr	x29, [x29]
    18cc:      	ldr	x12, [sp, #0x28]
    18d0:      	b.ne	0x3960 <generic_lsm_process_event+0x3790>
    18d4:      	ldr	x8, [sp, #0x10]
    18d8:      	add	x24, x8, #0x90
    18dc:      	and	w8, w21, #0xf
    18e0:      	add	x22, x24, x23
    18e4:      	cmp	w8, #0x2
    18e8:      	b.le	0x27e8 <generic_lsm_process_event+0x2618>
    18ec:      	cmp	w8, #0x3
    18f0:      	b.eq	0x29b0 <generic_lsm_process_event+0x27e0>
    18f4:      	cmp	w8, #0x4
    18f8:      	b.eq	0x29b8 <generic_lsm_process_event+0x27e8>
    18fc:      	cmp	w8, #0x5
    1900:      	b.ne	0x2a10 <generic_lsm_process_event+0x2840>
    1904:      	mov	w9, #0x5e70             // =24176
    1908:      	b	0x29c4 <generic_lsm_process_event+0x27f4>
    190c:      	mov	w10, #0x7               // =7
    1910:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1914:      	mov	x11, x22
    1918:      	ldr	x29, [x29]
    191c:      	b	0x8dc <generic_lsm_process_event+0x70c>
    1920:      	ldr	x0, [sp, #0x18]
    1924:      	mov	w8, #0x2                // =2
    1928:      	add	x9, sp, #0xd0
    192c:      	mov	w10, #0x4               // =4
    1930:      	add	x2, sp, #0xd0
    1934:      	mov	w1, #0x2                // =2
    1938:      	mov	w25, #0x4               // =4
    193c:      	blr	x10
    1940:      	b	0x395c <generic_lsm_process_event+0x378c>
    1944:      	cmp	w24, #0x1
    1948:      	b.eq	0x1990 <generic_lsm_process_event+0x17c0>
    194c:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1950:      	cmp	w24, #0x4
    1954:      	ldr	x29, [x29]
    1958:      	ldp	x10, x12, [sp, #0x20]
    195c:      	mov	w9, #0x5ea0             // =24224
    1960:      	b.ne	0x3968 <generic_lsm_process_event+0x3798>
    1964:      	ldr	x0, [sp, #0x18]
    1968:      	mov	w25, #0x8               // =8
    196c:      	mov	w8, #0x4                // =4
    1970:      	add	x9, sp, #0xd0
    1974:      	add	x2, sp, #0xd0
    1978:      	mov	w1, #0x8                // =8
    197c:      	mov	x21, x12
    1980:      	blr	x8
    1984:      	ldr	x10, [sp, #0x20]
    1988:      	mov	x12, x21
    198c:      	b	0x3964 <generic_lsm_process_event+0x3794>
    1990:      	ldr	x0, [sp, #0x18]
    1994:      	add	x8, sp, #0xd0
    1998:      	mov	w9, #0x4                // =4
    199c:      	add	x2, sp, #0xd0
    19a0:      	mov	w1, #0x4                // =4
    19a4:      	mov	w25, #0x4               // =4
    19a8:      	blr	x9
    19ac:      	b	0x3954 <generic_lsm_process_event+0x3784>
    19b0:      	cmp	w24, #0x2b
    19b4:      	b.eq	0x2444 <generic_lsm_process_event+0x2274>
    19b8:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    19bc:      	cmp	w24, #0x29
    19c0:      	ldr	x29, [x29]
    19c4:      	ldr	x12, [sp, #0x28]
    19c8:      	b.ne	0x3960 <generic_lsm_process_event+0x3790>
    19cc:      	ldr	x8, [sp, #0x38]
    19d0:      	mov	w9, #0x4                // =4
    19d4:      	add	x10, sp, #0x88
    19d8:      	mov	x21, x0
    19dc:      	add	x0, sp, #0x88
    19e0:      	mov	w1, #0x8                // =8
    19e4:      	add	x2, x8, #0x18
    19e8:      	mov	w8, #0x8                // =8
    19ec:      	blr	x9
    19f0:      	ldr	x23, [sp, #0x88]
    19f4:      	cbz	x23, 0x296c <generic_lsm_process_event+0x279c>
    19f8:      	ldr	x22, [sp, #0x18]
    19fc:      	add	x2, x23, #0x10
    1a00:      	mov	w25, #0x2               // =2
    1a04:      	mov	w8, #0x4                // =4
    1a08:      	str	x23, [x22, #0x28]
    1a0c:      	add	x0, x22, #0x26
    1a10:      	mov	w1, #0x2                // =2
    1a14:      	mov	w24, #0x4               // =4
    1a18:      	blr	x8
    1a1c:      	add	x0, x22, #0x3a
    1a20:      	add	x2, x23, #0x12
    1a24:      	mov	w8, #0x1                // =1
    1a28:      	mov	w9, #0x4                // =4
    1a2c:      	mov	w1, #0x1                // =1
    1a30:      	blr	x9
    1a34:      	add	x0, x22, #0x38
    1a38:      	add	x2, x23, #0x21e
    1a3c:      	mov	w8, #0x4                // =4
    1a40:      	mov	w1, #0x2                // =2
    1a44:      	blr	x8
    1a48:      	add	x0, x22, #0x24
    1a4c:      	add	x2, x23, #0x21c
    1a50:      	mov	w8, #0x4                // =4
    1a54:      	mov	w1, #0x2                // =2
    1a58:      	blr	x8
    1a5c:      	add	x0, x22, #0x30
    1a60:      	add	x2, x23, #0x214
    1a64:      	mov	w8, #0x4                // =4
    1a68:      	mov	w1, #0x4                // =4
    1a6c:      	blr	x8
    1a70:      	add	x0, x22, #0x34
    1a74:      	add	x2, x23, #0x210
    1a78:      	mov	w1, #0x4                // =4
    1a7c:      	blr	x24
    1a80:      	ldrh	w8, [x22, #0x26]
    1a84:      	mov	x24, x22
    1a88:      	stp	xzr, xzr, [x22]
    1a8c:      	cmp	w8, #0xa
    1a90:      	str	xzr, [x22, #0x18]
    1a94:      	str	xzr, [x24, #0x10]!
    1a98:      	b.eq	0x28fc <generic_lsm_process_event+0x272c>
    1a9c:      	cmp	w8, #0x2
    1aa0:      	b.ne	0x2928 <generic_lsm_process_event+0x2758>
    1aa4:      	ldr	x0, [sp, #0x18]
    1aa8:      	add	x2, x23, #0x4
    1aac:      	mov	w8, #0x4                // =4
    1ab0:      	mov	w1, #0x4                // =4
    1ab4:      	mov	w25, #0x4               // =4
    1ab8:      	blr	x8
    1abc:      	mov	x0, x24
    1ac0:      	mov	w1, #0x4                // =4
    1ac4:      	mov	x2, x23
    1ac8:      	blr	x25
    1acc:      	b	0x2928 <generic_lsm_process_event+0x2758>
    1ad0:      	cmp	w24, #0x1a
    1ad4:      	b.eq	0x24d4 <generic_lsm_process_event+0x2304>
    1ad8:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1adc:      	cmp	w24, #0x1b
    1ae0:      	ldr	x29, [x29]
    1ae4:      	ldr	x12, [sp, #0x28]
    1ae8:      	b.ne	0x3960 <generic_lsm_process_event+0x3790>
    1aec:      	ldr	x10, [sp, #0x18]
    1af0:      	ldr	x8, [sp, #0x38]
    1af4:      	mov	w9, #0x2d               // =45
    1af8:      	mov	w1, #0x3f               // =63
    1afc:      	mov	x0, x10
    1b00:      	stp	xzr, xzr, [x10, #0x40]
    1b04:      	stp	xzr, xzr, [x10, #0x30]
    1b08:      	stp	xzr, xzr, [x10, #0x20]
    1b0c:      	str	xzr, [x10, #0x18]
    1b10:      	stp	xzr, xzr, [x10]
    1b14:      	add	x2, x8, #0x18
    1b18:      	mov	w8, #0x3f               // =63
    1b1c:      	str	xzr, [x0, #0x10]!
    1b20:      	blr	x9
    1b24:      	tbnz	x0, #0x3f, 0x2718 <generic_lsm_process_event+0x2548>
    1b28:      	ldr	x8, [sp, #0x18]
    1b2c:      	mov	w9, #0x4                // =4
    1b30:      	mov	w1, #0x8                // =8
    1b34:      	add	x0, x8, #0x8
    1b38:      	ldr	x8, [sp, #0x38]
    1b3c:      	add	x2, x8, #0x360
    1b40:      	mov	w8, #0x8                // =8
    1b44:      	blr	x9
    1b48:      	mov	w25, #0x50              // =80
    1b4c:      	b	0x3954 <generic_lsm_process_event+0x3784>
    1b50:      	cmp	w24, #0x8
    1b54:      	b.eq	0x21ac <generic_lsm_process_event+0x1fdc>
    1b58:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1b5c:      	cmp	w24, #0x12
    1b60:      	ldr	x29, [x29]
    1b64:      	ldr	x12, [sp, #0x28]
    1b68:      	b.ne	0x3960 <generic_lsm_process_event+0x3790>
    1b6c:      	ldp	x8, x2, [sp, #0x30]
    1b70:      	mov	x21, x12
    1b74:      	and	x25, x8, #0x3ff
    1b78:      	ldr	x0, [sp, #0x18]
    1b7c:      	mov	w8, #0x4                // =4
    1b80:      	mov	w1, w25
    1b84:      	blr	x8
    1b88:      	mov	x12, x21
    1b8c:      	b	0x3960 <generic_lsm_process_event+0x3790>
    1b90:      	cmp	w24, #0x13
    1b94:      	b.eq	0x2400 <generic_lsm_process_event+0x2230>
    1b98:      	adrp	x29, 0x1000 <generic_lsm_process_event+0xe30>
    1b9c:      	cmp	w24, #0x14
    1ba0:      	ldr	x29, [x29]
    1ba4:      	ldr	x12, [sp, #0x28]
    1ba8:      	b.ne	0x3960 <generic_lsm_process_event+0x3790>
    1bac:      	ldr	x22, [sp, #0x38]
    1bb0:      	str	xzr, [sp, #0x88]
    1bb4:      	mov	w10, #0x8               // =8
    1bb8:      	add	x8, sp, #0x88
    1bbc:      	mov	w9, #0x4                // =4
    1bc0:      	add	x0, sp, #0x88
    1bc4:      	mov	w1, #0x8                // =8
    1bc8:      	mov	w21, #0x4               // =4
    1bcc:      	mov	x24, x12
    1bd0:      	add	x2, x22, #0x110
    1bd4:      	add	x23, x22, #0xd8
    1bd8:      	blr	x9
    1bdc:      	ldr	x8, [sp, #0x88]
    1be0:      	mov	w9, #0x80               // =128
    1be4:      	mov	w10, #0x2d              // =45
    1be8:      	ldr	x25, [sp, #0x18]
    1bec:      	mov	w1, #0x80               // =128
    1bf0:      	mov	x0, x25
    1bf4:      	ldr	x2, [sp, #0x88]
    1bf8:      	blr	x10
    1bfc:      	add	x0, x25, #0x90
    1c00:      	mov	w8, #0x4                // =4
    1c04:      	mov	w1, #0x4                // =4
    1c08:      	mov	x2, x23
    1c0c:      	blr	x8
    1c10:      	add	x0, x25, #0x80
    1c14:      	add	x2, x22, #0xe0
    1c18:      	mov	w8, #0x4                // =4
    1c1c:      	mov	w9, #0x8                // =8
    1c20:      	mov	w1, #0x8                // =8
    1c24:      	mov	w23, #0x8               // =8
    1c28:      	blr	x8
    1c2c:      	add	x0, x25, #0x88
    1c30:      	add	x2, x22, #0x118
    1c34:      	mov	w1, #0x8                // =8
    1c38:      	blr	x21
    1c3c:      	mov	x12, x24
    1c40:      	mov	w25, #0x98              // =152
    1c44:      	b	0x3960 <generic_lsm_process_event+0x3790>
    1c48:      	ldp	x10, x12, [sp, #0x20]
    1c4c:      	cmp	w24, #0x26
    1c50:      	mov	x29, x21
    1c54:      	mov	w9, #0x5ea0             // =24224
    1c58:      	b.ne	0x3968 <generic_lsm_process_event+0x3798>
    1c5c:      	ldr	x8, [x11]
    1c60:      	ldr	x9, [sp, #0x18]
    1c64:      	add	x2, x19, w8, uxth
    1c68:      	ubfx	w8, w8, #16, #12
    1c6c:      	add	x0, x9, #0x4
    1c70:      	add	w1, w8, #0x1
    1c74:      	mov	w8, #0x2d               // =45
    1c78:      	blr	x8
    1c7c:      	b	0x20c4 <generic_lsm_process_event+0x1ef4>
    1c80:      	str	xzr, [sp, #0x90]
    1c84:      	mov	w8, #0xe                // =14
    1c88:      	blr	x8
    1c8c:      	lsr	x8, x0, #32
    1c90:      	add	x9, sp, #0xe0
    1c94:      	add	x10, sp, #0xd0
    1c98:      	str	x8, [sp, #0x88]
    1c9c:      	mov	w8, #0x4                // =4
    1ca0:      	add	x0, sp, #0xe0
    1ca4:      	add	x2, sp, #0xd0
    1ca8:      	mov	w1, #0x4                // =4
    1cac:      	blr	x8
    1cb0:      	ldr	w8, [sp, #0xe0]
    1cb4:      	adrp	x0, 0x1000 <generic_lsm_process_event+0xe30>
    1cb8:      	add	x9, sp, #0x88
    1cbc:      	add	x1, sp, #0x88
    1cc0:      	str	w8, [sp, #0x90]
    1cc4:      	mov	w8, #0x1                // =1
    1cc8:      	ldr	x0, [x0]
    1ccc:      	blr	x8
    1cd0:      	cbz	x0, 0x25d0 <generic_lsm_process_event+0x2400>
    1cd4:      	ldr	x25, [sp, #0x18]
    1cd8:      	ldr	w21, [x0]
    1cdc:      	add	x8, sp, #0xe0
    1ce0:      	mov	w9, #0x4                // =4
    1ce4:      	mov	x23, x0
    1ce8:      	add	x2, sp, #0xe0
    1cec:      	mov	w1, #0x4                // =4
    1cf0:      	mov	w24, #0x4               // =4
    1cf4:      	mov	x0, x25
    1cf8:      	blr	x9
    1cfc:      	and	x21, x21, #0xfff
    1d00:      	add	x0, x25, #0x4
    1d04:      	mov	w8, #0x4                // =4
    1d08:      	mov	x2, x23
    1d0c:      	add	x1, x21, #0x4
    1d10:      	blr	x8
    1d14:      	add	w21, w21, #0x8
    1d18:      	mov	w1, #0x4                // =4
    1d1c:      	add	x8, x21, x23
    1d20:      	add	x0, x25, x21
    1d24:      	sub	x2, x8, #0x4
    1d28:      	blr	x24
    1d2c:      	add	x25, x21, #0x4
    1d30:      	b	0x395c <generic_lsm_process_event+0x378c>
    1d34:      	ldr	x24, [x11]
    1d38:      	mov	w8, #0x1                // =1
    1d3c:      	mov	w9, #0x4                // =4
    1d40:      	add	x10, sp, #0x78
    1d44:      	add	x0, sp, #0x78
    1d48:      	mov	w1, #0x1                // =1
    1d4c:      	mov	x2, x24
    1d50:      	blr	x9
    1d54:      	ldrb	w8, [sp, #0x78]
    1d58:      	cmp	w8, #0x1
    1d5c:      	b.ne	0x25b4 <generic_lsm_process_event+0x23e4>
    1d60:      	add	x2, x24, #0x10
    1d64:      	mov	w24, #0x8               // =8
    1d68:      	add	x8, sp, #0xe0
    1d6c:      	mov	w9, #0x4                // =4
    1d70:      	add	x0, sp, #0xe0
    1d74:      	mov	w1, #0x8                // =8
    1d78:      	mov	w25, #0x4               // =4
    1d7c:      	blr	x9
    1d80:      	add	x22, sp, #0xd0
    1d84:      	add	x8, sp, #0x60
    1d88:      	mov	w9, #0x4                // =4
    1d8c:      	ldr	x2, [x22, #0x10]
    1d90:      	add	x0, sp, #0x60
    1d94:      	mov	w1, #0x8                // =8
    1d98:      	blr	x9
    1d9c:      	ldr	x8, [x22, #0x10]
    1da0:      	add	x0, sp, #0xd8
    1da4:      	mov	w1, #0x8                // =8
    1da8:      	add	x2, x8, #0x8
    1dac:      	add	x8, sp, #0xd8
    1db0:      	blr	x25
    1db4:      	ldr	x8, [sp, #0x38]
    1db8:      	ldr	x10, [sp, #0x60]
    1dbc:      	add	x8, x8, #0x90
    1dc0:      	ldr	x22, [x22, #0x8]
    1dc4:      	add	x9, x8, x23
    1dc8:      	stp	x10, x9, [sp, #0x30]
    1dcc:      	tbz	w21, #0x5, 0x289c <generic_lsm_process_event+0x26cc>
    1dd0:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1dd4:      	b.lo	0x2880 <generic_lsm_process_event+0x26b0>
    1dd8:      	ldr	x9, [sp, #0x38]
    1ddc:      	mov	w8, #0x1                // =1
    1de0:      	adrp	x0, 0x1000 <generic_lsm_process_event+0xe30>
    1de4:      	add	x1, sp, #0xc8
    1de8:      	str	w8, [x9]
    1dec:      	str	wzr, [sp, #0xc8]
    1df0:      	add	x9, sp, #0xc8
    1df4:      	ldr	x0, [x0]
    1df8:      	blr	x8
    1dfc:      	str	x0, [sp, #0x18]
    1e00:      	cbz	x0, 0x2b80 <generic_lsm_process_event+0x29b0>
    1e04:      	ldr	x23, [sp, #0x18]
    1e08:      	mov	w8, #0x18               // =24
    1e0c:      	str	w8, [x23]
    1e10:      	mov	w8, #0xe                // =14
    1e14:      	blr	x8
    1e18:      	str	x0, [x23, #0x10]!
    1e1c:      	cmn	x0, #0x16
    1e20:      	b.ne	0x1e48 <generic_lsm_process_event+0x1c78>
    1e24:      	add	x2, x19, #0xe8
    1e28:      	mov	w8, #0x8                // =8
    1e2c:      	mov	w9, #0x4                // =4
    1e30:      	add	x10, sp, #0x88
    1e34:      	add	x0, sp, #0x88
    1e38:      	mov	w1, #0x8                // =8
    1e3c:      	blr	x9
    1e40:      	ldr	x8, [sp, #0x88]
    1e44:      	str	x8, [x23]
    1e48:      	mov	w8, #0x7d               // =125
    1e4c:      	blr	x8
    1e50:      	ldr	x8, [sp, #0x18]
    1e54:      	ldr	x10, [sp, #0x38]
    1e58:      	mov	x21, xzr
    1e5c:      	mov	w25, #0xa               // =10
    1e60:      	str	x0, [x8, #0x18]
    1e64:      	add	x8, x8, #0x20
    1e68:      	str	x8, [sp, #0x10]
    1e6c:      	ldp	x8, x9, [x23]
    1e70:      	stur	x8, [x10, #0x14]
    1e74:      	stur	x9, [x10, #0x1c]
    1e78:      	subs	x8, x22, x21
    1e7c:      	b.mi	0x304c <generic_lsm_process_event+0x2e7c>
    1e80:      	ldr	x9, [sp, #0x30]
    1e84:      	ldr	x0, [sp, #0x10]
    1e88:      	add	x2, x21, x9
    1e8c:      	mov	w9, #0x7fe0             // =32736
    1e90:      	cmp	x8, x9
    1e94:      	csel	x24, x8, x9, lo
    1e98:      	mov	w8, #0x4                // =4
    1e9c:      	mov	w1, w24
    1ea0:      	blr	x8
    1ea4:      	tbnz	w0, #0x1f, 0x1f24 <generic_lsm_process_event+0x1d54>
    1ea8:      	ldr	x8, [sp, #0x18]
    1eac:      	add	w23, w24, #0x20
    1eb0:      	str	wzr, [sp, #0x88]
    1eb4:      	adrp	x0, 0x1000 <generic_lsm_process_event+0xe30>
    1eb8:      	add	x9, sp, #0x88
    1ebc:      	add	x1, sp, #0x88
    1ec0:      	str	w23, [x8, #0x4]
    1ec4:      	mov	w8, #0x1                // =1
    1ec8:      	ldr	x0, [x0]
    1ecc:      	blr	x8
    1ed0:      	cbz	x0, 0x1f04 <generic_lsm_process_event+0x1d34>
    1ed4:      	ldrb	w8, [x0, #0x28]
    1ed8:      	cbz	w8, 0x1f04 <generic_lsm_process_event+0x1d34>
    1edc:      	adrp	x1, 0x1000 <generic_lsm_process_event+0xe30>
    1ee0:      	ldr	x3, [sp, #0x18]
    1ee4:      	mov	w8, #0x19               // =25
    1ee8:      	mov	w9, #-0x1               // =-1
    1eec:      	ldr	x1, [x1]
    1ef0:      	mov	x0, x19
    1ef4:      	mov	w2, #-0x1               // =-1
    1ef8:      	mov	x4, x23
    1efc:      	blr	x8
    1f00:      	b	0x1f20 <generic_lsm_process_event+0x1d50>
    1f04:      	adrp	x0, 0x1000 <generic_lsm_process_event+0xe30>
    1f08:      	ldr	x1, [sp, #0x18]
    1f0c:      	mov	x3, xzr
    1f10:      	mov	w8, #0x82               // =130
    1f14:      	ldr	x0, [x0]
    1f18:      	mov	x2, x23
    1f1c:      	blr	x8
    1f20:      	tbz	w0, #0x1f, 0x1f28 <generic_lsm_process_event+0x1d58>
    1f24:      	sxtw	x24, w0
    1f28:      	tbnz	w24, #0x1f, 0x3054 <generic_lsm_process_event+0x2e84>
    1f2c:      	and	x8, x24, #0x7fffffff
    1f30:      	add	x21, x8, x21
    1f34:      	cmp	x21, x22
    1f38:      	b.eq	0x30a0 <generic_lsm_process_event+0x2ed0>
    1f3c:      	subs	w25, w25, #0x1
    1f40:      	b.ne	0x1e78 <generic_lsm_process_event+0x1ca8>
    1f44:      	b	0x341c <generic_lsm_process_event+0x324c>
    1f48:      	add	x8, sp, #0xd0
    1f4c:      	ldr	x22, [sp, #0x18]
    1f50:      	mov	w1, #0x4                // =4
    1f54:      	mov	w24, #0x4               // =4
    1f58:      	ldr	x21, [x8]
    1f5c:      	mov	w8, #0x4                // =4
    1f60:      	add	x0, x22, #0x28
    1f64:      	add	x2, x21, #0x98
    1f68:      	blr	x8
    1f6c:      	add	x0, x22, #0x2c
    1f70:      	add	x2, x21, #0x70
    1f74:      	mov	w8, #0x4                // =4
    1f78:      	mov	w1, #0x4                // =4
    1f7c:      	blr	x8
    1f80:      	add	x0, x22, #0x30
    1f84:      	add	x2, x21, #0x90
    1f88:      	mov	w8, #0x4                // =4
    1f8c:      	mov	w1, #0x4                // =4
    1f90:      	blr	x8
    1f94:      	add	x0, x22, #0x34
    1f98:      	add	x2, x21, #0xa8
    1f9c:      	mov	w8, #0x4                // =4
    1fa0:      	mov	w1, #0x4                // =4
    1fa4:      	blr	x8
    1fa8:      	str	xzr, [sp, #0x88]
    1fac:      	add	x2, x21, #0xc8
    1fb0:      	mov	w8, #0x8                // =8
    1fb4:      	add	x9, sp, #0x88
    1fb8:      	mov	w10, #0x4               // =4
    1fbc:      	add	x0, sp, #0x88
    1fc0:      	mov	w1, #0x8                // =8
    1fc4:      	blr	x10
    1fc8:      	add	x2, x21, #0xb8
    1fcc:      	mov	w8, #0x2                // =2
    1fd0:      	add	x9, sp, #0xd8
    1fd4:      	mov	w10, #0x4               // =4
    1fd8:      	add	x0, sp, #0xd8
    1fdc:      	mov	w1, #0x2                // =2
    1fe0:      	blr	x10
    1fe4:      	ldr	x8, [sp, #0x88]
    1fe8:      	ldrh	w9, [sp, #0xd8]
    1fec:      	add	x0, sp, #0x74
    1ff0:      	mov	w1, #0x1                // =1
    1ff4:      	add	x23, x8, x9
    1ff8:      	mov	w8, #0x1                // =1
    1ffc:      	add	x9, sp, #0x74
    2000:      	mov	x2, x23
    2004:      	blr	x24
    2008:      	ldrb	w8, [sp, #0x74]
    200c:      	lsr	w8, w8, #4
    2010:      	cmp	w8, #0x6
    2014:      	b.eq	0x25d8 <generic_lsm_process_event+0x2408>
    2018:      	cmp	w8, #0x4
    201c:      	b.ne	0x3950 <generic_lsm_process_event+0x3780>
    2020:      	add	x2, x23, #0x9
    2024:      	mov	w8, #0x1                // =1
    2028:      	add	x9, sp, #0x78
    202c:      	mov	w10, #0x4               // =4
    2030:      	add	x0, sp, #0x78
    2034:      	mov	w1, #0x1                // =1
    2038:      	mov	w25, #0x4               // =4
    203c:      	blr	x10
    2040:      	ldr	x0, [sp, #0x18]
    2044:      	ldrb	w8, [sp, #0x78]
    2048:      	mov	w29, #0x2               // =2
    204c:      	add	x2, x23, #0xc
    2050:      	mov	w1, #0x4                // =4
    2054:      	mov	x24, x0
    2058:      	strh	w8, [x0, #0x24]
    205c:      	strh	w29, [x0, #0x26]
    2060:      	stp	xzr, xzr, [x0]
    2064:      	str	xzr, [x0, #0x18]
    2068:      	mov	w8, #0x4                // =4
    206c:      	str	xzr, [x24, #0x10]!
    2070:      	blr	x8
    2074:      	add	x2, x23, #0x10
    2078:      	mov	w8, #0x4                // =4
    207c:      	mov	x0, x24
    2080:      	mov	w1, #0x4                // =4
    2084:      	blr	x8
    2088:      	add	x2, x21, #0xb6
    208c:      	add	x8, sp, #0xc8
    2090:      	add	x0, sp, #0xc8
    2094:      	mov	w1, #0x2                // =2
    2098:      	blr	x25
    209c:      	ldrb	w25, [sp, #0x78]
    20a0:      	b	0x3814 <generic_lsm_process_event+0x3644>
    20a4:      	ldr	x8, [x11]
    20a8:      	mov	w9, #0x2d               // =45
    20ac:      	mov	w1, #0x11               // =17
    20b0:      	add	x2, x8, #0x118
    20b4:      	ldr	x8, [sp, #0x18]
    20b8:      	add	x0, x8, #0x4
    20bc:      	mov	w8, #0x11               // =17
    20c0:      	blr	x9
    20c4:      	mov	x25, x0
    20c8:      	tbnz	x0, #0x3f, 0x2878 <generic_lsm_process_event+0x26a8>
    20cc:      	ldr	x9, [sp, #0x18]
    20d0:      	sub	w8, w25, #0x1
    20d4:      	add	x25, x25, #0x3
    20d8:      	mov	x29, x21
    20dc:      	str	w8, [x9]
    20e0:      	b	0x395c <generic_lsm_process_event+0x378c>
    20e4:      	ldr	x0, [sp, #0x18]
    20e8:      	ldr	x23, [x11]
    20ec:      	mov	w8, #0x2                // =2
    20f0:      	mov	w9, #0x4                // =4
    20f4:      	mov	w1, #0x2                // =2
    20f8:      	mov	x2, x23
    20fc:      	str	xzr, [x0]
    2100:      	stp	xzr, xzr, [x0, #0x8]
    2104:      	blr	x9
    2108:      	tbnz	x0, #0x3f, 0x2848 <generic_lsm_process_event+0x2678>
    210c:      	ldr	x8, [sp, #0x18]
    2110:      	ldrh	w8, [x8]
    2114:      	cmp	w8, #0xa
    2118:      	b.eq	0x2800 <generic_lsm_process_event+0x2630>
    211c:      	cmp	w8, #0x2
    2120:      	b.ne	0x2834 <generic_lsm_process_event+0x2664>
    2124:      	add	x2, x23, #0x4
    2128:      	add	x8, sp, #0x88
    212c:      	mov	w9, #0x4                // =4
    2130:      	add	x0, sp, #0x88
    2134:      	mov	w1, #0x4                // =4
    2138:      	mov	w22, #0x4               // =4
    213c:      	blr	x9
    2140:      	ldr	w8, [sp, #0x88]
    2144:      	ldr	x9, [sp, #0x18]
    2148:      	add	x2, x23, #0x2
    214c:      	add	x0, x9, #0x2
    2150:      	str	x8, [x9, #0x8]
    2154:      	mov	w8, #0x2                // =2
    2158:      	b	0x282c <generic_lsm_process_event+0x265c>
    215c:      	ldr	x8, [sp, #0x10]
    2160:      	str	xzr, [x9]
    2164:      	add	x24, x8, #0x90
    2168:      	add	x8, x24, x23
    216c:      	str	x8, [sp, #0x18]
    2170:      	tbnz	w21, #0x4, 0x2720 <generic_lsm_process_event+0x2550>
    2174:      	ldr	x9, [sp, #0x30]
    2178:      	mov	x8, xzr
    217c:      	and	x23, x21, #0xffffffff
    2180:      	and	w9, w9, #0xf
    2184:      	cmp	w9, #0x2
    2188:      	b.le	0x28e4 <generic_lsm_process_event+0x2714>
    218c:      	cmp	w9, #0x3
    2190:      	b.eq	0x2b88 <generic_lsm_process_event+0x29b8>
    2194:      	cmp	w9, #0x4
    2198:      	b.eq	0x2b90 <generic_lsm_process_event+0x29c0>
    219c:      	cmp	w9, #0x5
    21a0:      	b.ne	0x2ba8 <generic_lsm_process_event+0x29d8>
    21a4:      	mov	w9, #0x5e70             // =24176
    21a8:      	b	0x2b9c <generic_lsm_process_event+0x29cc>
    21ac:      	ldr	x25, [sp, #0x38]
    21b0:      	ldr	x22, [sp, #0x18]
    21b4:      	mov	w8, #0x4                // =4
    21b8:      	mov	w1, #0x4                // =4
    21bc:      	mov	w21, #0x4               // =4
    21c0:      	add	x2, x25, #0x8
    21c4:      	mov	x0, x22
    21c8:      	add	x23, x22, #0x28
    21cc:      	add	x29, x22, #0x40
    21d0:      	blr	x8
    21d4:      	add	x0, x22, #0x4
    21d8:      	add	x2, x25, #0xc
    21dc:      	mov	w8, #0x4                // =4
    21e0:      	mov	w1, #0x4                // =4
    21e4:      	blr	x8
    21e8:      	add	x0, x22, #0x10
    21ec:      	add	x2, x25, #0x18
    21f0:      	mov	w8, #0x4                // =4
    21f4:      	mov	w1, #0x4                // =4
    21f8:      	blr	x8
    21fc:      	add	x0, x22, #0x14
    2200:      	add	x2, x25, #0x1c
    2204:      	mov	w8, #0x4                // =4
    2208:      	mov	w1, #0x4                // =4
    220c:      	blr	x8
    2210:      	add	x0, x22, #0x8
    2214:      	add	x2, x25, #0x10
    2218:      	mov	w8, #0x4                // =4
    221c:      	mov	w1, #0x4                // =4
    2220:      	blr	x8
    2224:      	add	x0, x22, #0xc
    2228:      	add	x2, x25, #0x14
    222c:      	mov	w8, #0x4                // =4
    2230:      	mov	w1, #0x4                // =4
    2234:      	blr	x8
    2238:      	add	x0, x22, #0x18
    223c:      	add	x2, x25, #0x20
    2240:      	mov	w8, #0x4                // =4
    2244:      	mov	w1, #0x4                // =4
    2248:      	blr	x8
    224c:      	add	x0, x22, #0x1c
    2250:      	add	x2, x25, #0x24
    2254:      	mov	w8, #0x4                // =4
    2258:      	mov	w1, #0x4                // =4
    225c:      	blr	x8
    2260:      	str	wzr, [x22, #0x24]
    2264:      	add	x0, x22, #0x20
    2268:      	add	x2, x25, #0x28
    226c:      	mov	w8, #0x4                // =4
    2270:      	mov	w1, #0x4                // =4
    2274:      	blr	x8
    2278:      	add	x0, x22, #0x30
    227c:      	add	x2, x25, #0x40
    2280:      	mov	w24, #0x8               // =8
    2284:      	mov	w8, #0x4                // =4
    2288:      	mov	w1, #0x8                // =8
    228c:      	blr	x8
    2290:      	add	x0, x22, #0x38
    2294:      	add	x2, x25, #0x30
    2298:      	mov	w8, #0x4                // =4
    229c:      	mov	w1, #0x8                // =8
    22a0:      	blr	x8
    22a4:      	add	x2, x25, #0x38
    22a8:      	mov	w8, #0x4                // =4
    22ac:      	mov	x0, x23
    22b0:      	mov	w1, #0x8                // =8
    22b4:      	blr	x8
    22b8:      	add	x2, x25, #0x90
    22bc:      	add	x8, sp, #0x88
    22c0:      	mov	w9, #0x4                // =4
    22c4:      	add	x0, sp, #0x88
    22c8:      	mov	w1, #0x8                // =8
    22cc:      	blr	x9
    22d0:      	ldr	x23, [sp, #0x88]
    22d4:      	mov	w8, #0x4                // =4
    22d8:      	mov	x0, x29
    22dc:      	mov	w1, #0x4                // =4
    22e0:      	add	x2, x23, #0xc8
    22e4:      	blr	x8
    22e8:      	add	x0, x22, #0x44
    22ec:      	add	x2, x23, #0xcc
    22f0:      	mov	w8, #0x4                // =4
    22f4:      	mov	w1, #0x4                // =4
    22f8:      	blr	x8
    22fc:      	add	x0, x22, #0x48
    2300:      	add	x2, x23, #0xd0
    2304:      	mov	w8, #0x4                // =4
    2308:      	mov	w1, #0x4                // =4
    230c:      	blr	x8
    2310:      	add	x0, x22, #0x4c
    2314:      	add	x2, x23, #0x158
    2318:      	mov	w1, #0x4                // =4
    231c:      	blr	x21
    2320:      	mov	w25, #0x50              // =80
    2324:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2328:      	ldr	x23, [sp, #0x38]
    232c:      	ldr	x22, [sp, #0x18]
    2330:      	mov	w8, #0x4                // =4
    2334:      	mov	w1, #0x4                // =4
    2338:      	mov	w21, #0x4               // =4
    233c:      	add	x2, x23, #0xc8
    2340:      	mov	x0, x22
    2344:      	blr	x8
    2348:      	add	x0, x22, #0x4
    234c:      	add	x2, x23, #0xcc
    2350:      	mov	w8, #0x4                // =4
    2354:      	mov	w1, #0x4                // =4
    2358:      	blr	x8
    235c:      	add	x0, x22, #0x8
    2360:      	add	x2, x23, #0xd0
    2364:      	mov	w8, #0x4                // =4
    2368:      	mov	w1, #0x4                // =4
    236c:      	blr	x8
    2370:      	add	x0, x22, #0xc
    2374:      	add	x2, x23, #0x158
    2378:      	mov	w1, #0x4                // =4
    237c:      	blr	x21
    2380:      	mov	w25, #0x10              // =16
    2384:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2388:      	ldr	x23, [sp, #0x38]
    238c:      	ldr	x22, [sp, #0x18]
    2390:      	mov	w8, #0x4                // =4
    2394:      	mov	w1, #0x4                // =4
    2398:      	mov	w21, #0x4               // =4
    239c:      	add	x2, x23, #0x38
    23a0:      	mov	x0, x22
    23a4:      	blr	x8
    23a8:      	add	x0, x22, #0x4
    23ac:      	add	x2, x23, #0x3c
    23b0:      	mov	w8, #0x4                // =4
    23b4:      	mov	w1, #0x4                // =4
    23b8:      	blr	x8
    23bc:      	add	x0, x22, #0x8
    23c0:      	add	x2, x23, #0x40
    23c4:      	mov	w8, #0x4                // =4
    23c8:      	mov	w1, #0x4                // =4
    23cc:      	blr	x8
    23d0:      	add	x0, x22, #0xc
    23d4:      	add	x2, x23, #0x44
    23d8:      	mov	w8, #0x4                // =4
    23dc:      	mov	w1, #0x4                // =4
    23e0:      	blr	x8
    23e4:      	add	x0, x22, #0x10
    23e8:      	add	x2, x23, #0x80
    23ec:      	mov	w8, #0x10               // =16
    23f0:      	mov	w1, #0x10               // =16
    23f4:      	blr	x21
    23f8:      	mov	w25, #0x20              // =32
    23fc:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2400:      	ldr	x22, [sp, #0x18]
    2404:      	ldr	x23, [sp, #0x38]
    2408:      	mov	w8, #0x4                // =4
    240c:      	mov	w1, #0x4                // =4
    2410:      	mov	w21, #0x4               // =4
    2414:      	mov	x0, x22
    2418:      	mov	x2, x23
    241c:      	blr	x8
    2420:      	add	x0, x22, #0x4
    2424:      	add	x2, x23, #0x4
    2428:      	mov	w8, #0x4                // =4
    242c:      	mov	w1, #0x4                // =4
    2430:      	blr	x8
    2434:      	add	x0, x22, #0x8
    2438:      	add	x2, x23, #0x30
    243c:      	mov	w8, #0x10               // =16
    2440:      	b	0x24c4 <generic_lsm_process_event+0x22f4>
    2444:      	ldr	x23, [sp, #0x38]
    2448:      	add	x8, sp, #0x88
    244c:      	mov	w9, #0x4                // =4
    2450:      	add	x0, sp, #0x88
    2454:      	mov	w1, #0x4                // =4
    2458:      	mov	w21, #0x4               // =4
    245c:      	add	x2, x23, #0x4
    2460:      	blr	x9
    2464:      	ldr	w8, [sp, #0x88]
    2468:      	ldr	x22, [sp, #0x18]
    246c:      	add	x2, x23, #0xc
    2470:      	add	x0, sp, #0x88
    2474:      	mov	w1, #0x4                // =4
    2478:      	str	w8, [x22]
    247c:      	add	x8, sp, #0x88
    2480:      	blr	x21
    2484:      	ldr	w8, [sp, #0x88]
    2488:      	add	x2, x23, #0x50
    248c:      	add	x9, sp, #0x88
    2490:      	mov	w10, #0x2d              // =45
    2494:      	str	w8, [x22, #0x4]
    2498:      	mov	w8, #0x8                // =8
    249c:      	add	x0, sp, #0x88
    24a0:      	mov	w1, #0x8                // =8
    24a4:      	mov	w21, #0x2d              // =45
    24a8:      	blr	x10
    24ac:      	ldr	x8, [sp, #0x88]
    24b0:      	add	x0, x22, #0x8
    24b4:      	mov	w9, #0x10               // =16
    24b8:      	add	x8, x8, #0x3f8
    24bc:      	ldr	x8, [sp, #0x88]
    24c0:      	add	x2, x8, #0x3f8
    24c4:      	mov	w1, #0x10               // =16
    24c8:      	blr	x21
    24cc:      	mov	w25, #0x18              // =24
    24d0:      	b	0x3954 <generic_lsm_process_event+0x3784>
    24d4:      	ldr	x11, [sp, #0x18]
    24d8:      	ldr	x2, [sp, #0x38]
    24dc:      	mov	w8, #0x8                // =8
    24e0:      	mov	w9, #0x4                // =4
    24e4:      	add	x10, sp, #0x88
    24e8:      	add	x0, sp, #0x88
    24ec:      	mov	w1, #0x8                // =8
    24f0:      	stp	xzr, xzr, [x11, #0x40]
    24f4:      	stp	xzr, xzr, [x11, #0x30]
    24f8:      	stp	xzr, xzr, [x11, #0x20]
    24fc:      	stp	xzr, xzr, [x11, #0x10]
    2500:      	stp	xzr, xzr, [x11]
    2504:      	blr	x9
    2508:      	mov	x25, xzr
    250c:      	cbnz	x0, 0x3954 <generic_lsm_process_event+0x3784>
    2510:      	ldr	x8, [sp, #0x18]
    2514:      	mov	w9, #0x3f               // =63
    2518:      	mov	w10, #0x2d              // =45
    251c:      	mov	w1, #0x3f               // =63
    2520:      	add	x0, x8, #0x10
    2524:      	ldr	x8, [sp, #0x88]
    2528:      	ldr	x2, [sp, #0x88]
    252c:      	blr	x10
    2530:      	tbnz	x0, #0x3f, 0x2718 <generic_lsm_process_event+0x2548>
    2534:      	ldr	x22, [sp, #0x38]
    2538:      	mov	w21, #0x8               // =8
    253c:      	add	x8, sp, #0xe0
    2540:      	mov	w9, #0x4                // =4
    2544:      	add	x0, sp, #0xe0
    2548:      	mov	w1, #0x8                // =8
    254c:      	mov	w23, #0x4               // =4
    2550:      	add	x2, x22, #0x8
    2554:      	blr	x9
    2558:      	ldr	x8, [sp, #0x18]
    255c:      	add	x10, sp, #0xd0
    2560:      	mov	w9, #0x4                // =4
    2564:      	mov	w1, #0x8                // =8
    2568:      	add	x0, x8, #0x8
    256c:      	ldr	x8, [x10, #0x10]
    2570:      	add	x8, x8, #0x360
    2574:      	ldr	x8, [x10, #0x10]
    2578:      	add	x2, x8, #0x360
    257c:      	blr	x9
    2580:      	add	x2, x22, #0x58
    2584:      	add	x8, sp, #0xe0
    2588:      	add	x0, sp, #0xe0
    258c:      	mov	w1, #0x4                // =4
    2590:      	blr	x23
    2594:      	cbnz	x0, 0x25ac <generic_lsm_process_event+0x23dc>
    2598:      	ldr	w8, [sp, #0xe0]
    259c:      	ldr	x9, [sp, #0x18]
    25a0:      	cmp	w8, #0x0
    25a4:      	cset	w8, ne
    25a8:      	str	w8, [x9]
    25ac:      	mov	w25, #0x50              // =80
    25b0:      	b	0x3954 <generic_lsm_process_event+0x3784>
    25b4:      	ldr	x8, [sp, #0x38]
    25b8:      	mov	w25, #0x8               // =8
    25bc:      	add	x8, x8, x23
    25c0:      	str	xzr, [x8, #0x90]
    25c4:      	b	0x395c <generic_lsm_process_event+0x378c>
    25c8:      	mov	w10, #0x9               // =9
    25cc:      	b	0x1910 <generic_lsm_process_event+0x1740>
    25d0:      	mov	x25, #-0x1              // =-1
    25d4:      	b	0x395c <generic_lsm_process_event+0x378c>
    25d8:      	str	wzr, [sp, #0xe0]
    25dc:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    25e0:      	ldr	x22, [sp, #0x88]
    25e4:      	mov	w8, #0x1                // =1
    25e8:      	add	x9, sp, #0xe0
    25ec:      	add	x1, sp, #0xe0
    25f0:      	ldrh	w23, [sp, #0xd8]
    25f4:      	ldr	x0, [x0]
    25f8:      	add	x29, x22, x23
    25fc:      	blr	x8
    2600:      	cbz	x0, 0x37d0 <generic_lsm_process_event+0x3600>
    2604:      	mov	w8, #0xff               // =255
    2608:      	strh	w23, [x0]
    260c:      	strb	wzr, [x0, #0x7]
    2610:      	add	x23, x0, #0x6
    2614:      	add	x2, x29, #0x6
    2618:      	mov	w9, #0x4                // =4
    261c:      	strb	w8, [x0, #0x5]
    2620:      	mov	w8, #0x1                // =1
    2624:      	mov	x24, x0
    2628:      	mov	x0, x23
    262c:      	mov	w1, #0x1                // =1
    2630:      	blr	x9
    2634:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    2638:      	ldrb	w8, [x24, #0x5]
    263c:      	cmp	w8, #0x32
    2640:      	b.gt	0x2afc <generic_lsm_process_event+0x292c>
    2644:      	cbz	w8, 0x2b74 <generic_lsm_process_event+0x29a4>
    2648:      	cmp	w8, #0x2b
    264c:      	b.eq	0x2b74 <generic_lsm_process_event+0x29a4>
    2650:      	cmp	w8, #0x2c
    2654:      	b.ne	0x3168 <generic_lsm_process_event+0x2f98>
    2658:      	mov	w8, #0x8                // =8
    265c:      	b	0x30b4 <generic_lsm_process_event+0x2ee4>
    2660:      	ldr	x0, [sp, #0x18]
    2664:      	add	x2, x23, #0x48
    2668:      	mov	w25, #0x10              // =16
    266c:      	mov	w8, #0x4                // =4
    2670:      	mov	w1, #0x10               // =16
    2674:      	mov	w29, #0x4               // =4
    2678:      	blr	x8
    267c:      	add	x2, x23, #0x38
    2680:      	mov	x0, x24
    2684:      	mov	w1, #0x10               // =16
    2688:      	blr	x29
    268c:      	ldr	x22, [sp, #0x18]
    2690:      	add	x24, x23, #0xc
    2694:      	add	x2, x23, #0xe
    2698:      	mov	w23, #0x2               // =2
    269c:      	mov	w8, #0x4                // =4
    26a0:      	mov	w1, #0x2                // =2
    26a4:      	mov	w25, #0x4               // =4
    26a8:      	add	x0, x22, #0x20
    26ac:      	blr	x8
    26b0:      	add	x0, x22, #0x22
    26b4:      	mov	w1, #0x2                // =2
    26b8:      	mov	x2, x24
    26bc:      	blr	x25
    26c0:      	ldrh	w8, [x22, #0x22]
    26c4:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    26c8:      	add	x9, sp, #0x88
    26cc:      	add	x1, sp, #0x88
    26d0:      	rev	w8, w8
    26d4:      	lsr	w8, w8, #16
    26d8:      	strh	w8, [x22, #0x22]
    26dc:      	add	x8, sp, #0xd0
    26e0:      	ldr	x8, [x8]
    26e4:      	str	x8, [sp, #0x88]
    26e8:      	mov	w8, #0x1                // =1
    26ec:      	ldr	x0, [x0]
    26f0:      	blr	x8
    26f4:      	cbz	x0, 0x3950 <generic_lsm_process_event+0x3780>
    26f8:      	ldr	w8, [x0]
    26fc:      	mov	w25, #0x40              // =64
    2700:      	str	w8, [x21, #0x10]
    2704:      	ldr	x8, [x0, #0x8]
    2708:      	str	x8, [x21, #0x18]
    270c:      	ldr	w8, [x0, #0x4]
    2710:      	str	w8, [x21, #0x7c]
    2714:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2718:      	mov	x25, xzr
    271c:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2720:      	mov	w8, #0xe                // =14
    2724:      	blr	x8
    2728:      	cmn	x0, #0x16
    272c:      	b.ne	0x2750 <generic_lsm_process_event+0x2580>
    2730:      	add	x2, x19, #0xe8
    2734:      	mov	w8, #0x8                // =8
    2738:      	mov	w9, #0x4                // =4
    273c:      	add	x10, sp, #0x88
    2740:      	add	x0, sp, #0x88
    2744:      	mov	w1, #0x8                // =8
    2748:      	blr	x9
    274c:      	ldr	x0, [sp, #0x88]
    2750:      	ldr	x8, [sp, #0x10]
    2754:      	mov	x3, xzr
    2758:      	add	x1, sp, #0xe0
    275c:      	add	x2, sp, #0x88
    2760:      	ldr	x9, [x8, #0x60]
    2764:      	ldr	x10, [x8, #0x8]
    2768:      	ldr	x8, [sp, #0x38]
    276c:      	str	xzr, [sp, #0x98]
    2770:      	stp	x10, x8, [sp, #0x88]
    2774:      	add	x8, sp, #0xd0
    2778:      	add	x10, sp, #0x88
    277c:      	stp	x9, x0, [x8, #0x10]
    2780:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    2784:      	mov	w8, #0x2                // =2
    2788:      	add	x9, sp, #0xe0
    278c:      	ldr	x0, [x0]
    2790:      	blr	x8
    2794:      	cbz	x0, 0x2b40 <generic_lsm_process_event+0x2970>
    2798:      	neg	w8, w0
    279c:      	adrp	x23, 0x2000 <generic_lsm_process_event+0x1e30>
    27a0:      	mov	w9, #0x1                // =1
    27a4:      	strh	w8, [sp, #0x60]
    27a8:      	mov	w8, #0x5                // =5
    27ac:      	add	x1, sp, #0x60
    27b0:      	mov	w21, #0x1               // =1
    27b4:      	strh	w8, [sp, #0x62]
    27b8:      	mov	x8, #0x46               // =70
    27bc:      	movk	x8, #0x2, lsl #32
    27c0:      	stur	x8, [sp, #0x64]
    27c4:      	add	x8, sp, #0x60
    27c8:      	ldr	x23, [x23]
    27cc:      	mov	x0, x23
    27d0:      	blr	x9
    27d4:      	cbz	x0, 0x2b1c <generic_lsm_process_event+0x294c>
    27d8:      	ldr	w8, [x0]
    27dc:      	add	w8, w8, #0x1
    27e0:      	str	w8, [x0]
    27e4:      	b	0x2b40 <generic_lsm_process_event+0x2970>
    27e8:      	cmp	w8, #0x1
    27ec:      	b.eq	0x29c0 <generic_lsm_process_event+0x27f0>
    27f0:      	cmp	w8, #0x2
    27f4:      	b.ne	0x2a10 <generic_lsm_process_event+0x2840>
    27f8:      	mov	w9, #0x5e58             // =24152
    27fc:      	b	0x29c4 <generic_lsm_process_event+0x27f4>
    2800:      	ldr	x24, [sp, #0x18]
    2804:      	add	x2, x23, #0x8
    2808:      	mov	w8, #0x10               // =16
    280c:      	mov	w9, #0x4                // =4
    2810:      	mov	w1, #0x10               // =16
    2814:      	mov	w22, #0x4               // =4
    2818:      	add	x0, x24, #0x8
    281c:      	blr	x9
    2820:      	add	x0, x24, #0x2
    2824:      	add	x2, x23, #0x2
    2828:      	mov	w8, #0x2                // =2
    282c:      	mov	w1, #0x2                // =2
    2830:      	blr	x22
    2834:      	ldr	x9, [sp, #0x18]
    2838:      	ldrh	w8, [x9, #0x2]
    283c:      	rev	w8, w8
    2840:      	lsr	w8, w8, #16
    2844:      	strh	w8, [x9, #0x2]
    2848:      	mov	w25, #0x18              // =24
    284c:      	mov	x29, x21
    2850:      	b	0x395c <generic_lsm_process_event+0x378c>
    2854:      	add	x2, x23, #0x3
    2858:      	mov	w22, #0x6b              // =107
    285c:      	mov	w8, #0x71               // =113
    2860:      	mov	w1, #0x6b               // =107
    2864:      	blr	x8
    2868:      	tbnz	w0, #0x1f, 0x2874 <generic_lsm_process_event+0x26a4>
    286c:      	ldr	x8, [sp, #0x18]
    2870:      	strb	w22, [x8, #0x3]
    2874:      	mov	w25, #0x70              // =112
    2878:      	mov	x29, x21
    287c:      	b	0x395c <generic_lsm_process_event+0x378c>
    2880:      	ldr	x9, [sp, #0x38]
    2884:      	mov	w24, #0xc               // =12
    2888:      	str	wzr, [x9]
    288c:      	ldr	x9, [sp, #0xf8]
    2890:      	add	x8, x8, x9
    2894:      	add	x8, x8, #0x8
    2898:      	str	x8, [sp, #0x38]
    289c:      	cmp	x22, #0xfff
    28a0:      	mov	w8, #0xfff              // =4095
    28a4:      	csel	x23, x22, x8, lo
    28a8:      	ldp	x2, x8, [sp, #0x30]
    28ac:      	mov	w1, w23
    28b0:      	add	x0, x8, #0x8
    28b4:      	mov	w8, #0x4                // =4
    28b8:      	blr	x8
    28bc:      	tbnz	w0, #0x1f, 0x28d0 <generic_lsm_process_event+0x2700>
    28c0:      	ldr	x8, [sp, #0x38]
    28c4:      	add	x25, x24, x23
    28c8:      	stp	w22, w23, [x8]
    28cc:      	b	0x395c <generic_lsm_process_event+0x378c>
    28d0:      	ldr	x9, [sp, #0x38]
    28d4:      	mov	w8, #-0x2               // =-2
    28d8:      	mov	w25, #0x4               // =4
    28dc:      	str	w8, [x9]
    28e0:      	b	0x395c <generic_lsm_process_event+0x378c>
    28e4:      	cmp	w9, #0x1
    28e8:      	b.eq	0x2b98 <generic_lsm_process_event+0x29c8>
    28ec:      	cmp	w9, #0x2
    28f0:      	b.ne	0x2ba8 <generic_lsm_process_event+0x29d8>
    28f4:      	mov	w9, #0x5e58             // =24152
    28f8:      	b	0x2b9c <generic_lsm_process_event+0x29cc>
    28fc:      	ldr	x0, [sp, #0x18]
    2900:      	add	x2, x23, #0x48
    2904:      	mov	w25, #0x10              // =16
    2908:      	mov	w8, #0x4                // =4
    290c:      	mov	w1, #0x10               // =16
    2910:      	mov	w29, #0x4               // =4
    2914:      	blr	x8
    2918:      	add	x2, x23, #0x38
    291c:      	mov	x0, x24
    2920:      	mov	w1, #0x10               // =16
    2924:      	blr	x29
    2928:      	ldr	x22, [sp, #0x18]
    292c:      	add	x24, x23, #0xc
    2930:      	add	x2, x23, #0xe
    2934:      	mov	w23, #0x2               // =2
    2938:      	mov	w8, #0x4                // =4
    293c:      	mov	w1, #0x2                // =2
    2940:      	mov	w25, #0x4               // =4
    2944:      	add	x0, x22, #0x20
    2948:      	blr	x8
    294c:      	add	x0, x22, #0x22
    2950:      	mov	w1, #0x2                // =2
    2954:      	mov	x2, x24
    2958:      	blr	x25
    295c:      	ldrh	w8, [x22, #0x22]
    2960:      	rev	w8, w8
    2964:      	lsr	w8, w8, #16
    2968:      	strh	w8, [x22, #0x22]
    296c:      	ldr	x8, [sp, #0x18]
    2970:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    2974:      	add	x9, sp, #0x88
    2978:      	add	x1, sp, #0x88
    297c:      	ldr	x8, [x8, #0x28]
    2980:      	str	x8, [sp, #0x88]
    2984:      	mov	w8, #0x1                // =1
    2988:      	ldr	x0, [x0]
    298c:      	blr	x8
    2990:      	cbz	x0, 0x3950 <generic_lsm_process_event+0x3780>
    2994:      	ldr	w8, [x0]
    2998:      	str	w8, [x21, #0x10]
    299c:      	ldr	x8, [x0, #0x8]
    29a0:      	str	x8, [x21, #0x18]
    29a4:      	ldr	w8, [x0, #0x4]
    29a8:      	str	w8, [x21, #0x7c]
    29ac:      	b	0x3950 <generic_lsm_process_event+0x3780>
    29b0:      	mov	w9, #0x5e60             // =24160
    29b4:      	b	0x29c4 <generic_lsm_process_event+0x27f4>
    29b8:      	mov	w9, #0x5e68             // =24168
    29bc:      	b	0x29c4 <generic_lsm_process_event+0x27f4>
    29c0:      	mov	w9, #0x5e50             // =24144
    29c4:      	ldr	x8, [sp, #0x10]
    29c8:      	add	x8, x8, x9
    29cc:      	ldr	x21, [x8]
    29d0:      	ldr	x8, [sp, #0x30]
    29d4:      	tbnz	w8, #0x4, 0x2a20 <generic_lsm_process_event+0x2850>
    29d8:      	cbz	x21, 0x2aec <generic_lsm_process_event+0x291c>
    29dc:      	ldr	x2, [sp, #0x38]
    29e0:      	mov	w8, #0x10               // =16
    29e4:      	mov	w9, #0x4                // =4
    29e8:      	add	x10, sp, #0x88
    29ec:      	add	x0, sp, #0x88
    29f0:      	mov	w1, #0x10               // =16
    29f4:      	blr	x9
    29f8:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    29fc:      	ldr	x23, [sp, #0x90]
    2a00:      	cmp	x23, #0xffe
    2a04:      	b.ls	0x2db0 <generic_lsm_process_event+0x2be0>
    2a08:      	mov	w8, #-0x3               // =-3
    2a0c:      	b	0x3040 <generic_lsm_process_event+0x2e70>
    2a10:      	ldr	x8, [sp, #0x30]
    2a14:      	mov	x21, xzr
    2a18:      	mov	x23, xzr
    2a1c:      	tbz	w8, #0x4, 0x2af0 <generic_lsm_process_event+0x2920>
    2a20:      	mov	w8, #0xe                // =14
    2a24:      	blr	x8
    2a28:      	cmn	x0, #0x16
    2a2c:      	b.ne	0x2a50 <generic_lsm_process_event+0x2880>
    2a30:      	add	x2, x19, #0xe8
    2a34:      	mov	w8, #0x8                // =8
    2a38:      	mov	w9, #0x4                // =4
    2a3c:      	add	x10, sp, #0x88
    2a40:      	add	x0, sp, #0x88
    2a44:      	mov	w1, #0x8                // =8
    2a48:      	blr	x9
    2a4c:      	ldr	x0, [sp, #0x88]
    2a50:      	ldr	x8, [sp, #0x10]
    2a54:      	mov	x3, xzr
    2a58:      	add	x1, sp, #0xe0
    2a5c:      	add	x2, sp, #0x88
    2a60:      	ldr	x9, [x8, #0x60]
    2a64:      	ldr	x10, [x8, #0x8]
    2a68:      	ldr	x8, [sp, #0x38]
    2a6c:      	str	x21, [sp, #0x98]
    2a70:      	stp	x10, x8, [sp, #0x88]
    2a74:      	add	x8, sp, #0xd0
    2a78:      	add	x10, sp, #0x88
    2a7c:      	stp	x9, x0, [x8, #0x10]
    2a80:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    2a84:      	mov	w8, #0x2                // =2
    2a88:      	add	x9, sp, #0xe0
    2a8c:      	ldr	x0, [x0]
    2a90:      	blr	x8
    2a94:      	cbz	x0, 0x2b6c <generic_lsm_process_event+0x299c>
    2a98:      	neg	w8, w0
    2a9c:      	adrp	x23, 0x2000 <generic_lsm_process_event+0x1e30>
    2aa0:      	mov	w9, #0x1                // =1
    2aa4:      	strh	w8, [sp, #0x60]
    2aa8:      	mov	w8, #0x5                // =5
    2aac:      	add	x1, sp, #0x60
    2ab0:      	mov	w21, #0x1               // =1
    2ab4:      	strh	w8, [sp, #0x62]
    2ab8:      	mov	x8, #0x57               // =87
    2abc:      	movk	x8, #0x2, lsl #32
    2ac0:      	stur	x8, [sp, #0x64]
    2ac4:      	add	x8, sp, #0x60
    2ac8:      	ldr	x23, [x23]
    2acc:      	mov	x0, x23
    2ad0:      	blr	x9
    2ad4:      	cbz	x0, 0x2b48 <generic_lsm_process_event+0x2978>
    2ad8:      	ldr	w8, [x0]
    2adc:      	add	w8, w8, #0x1
    2ae0:      	str	w8, [x0]
    2ae4:      	mov	w8, #-0x4               // =-4
    2ae8:      	b	0x3040 <generic_lsm_process_event+0x2e70>
    2aec:      	mov	x23, xzr
    2af0:      	stp	w23, w23, [x22]
    2af4:      	add	x25, x23, #0x8
    2af8:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2afc:      	cmp	w8, #0x33
    2b00:      	b.eq	0x30a8 <generic_lsm_process_event+0x2ed8>
    2b04:      	cmp	w8, #0x3c
    2b08:      	b.eq	0x2b74 <generic_lsm_process_event+0x29a4>
    2b0c:      	cmp	w8, #0xff
    2b10:      	b.ne	0x3168 <generic_lsm_process_event+0x2f98>
    2b14:      	mov	w8, #0x28               // =40
    2b18:      	b	0x30b4 <generic_lsm_process_event+0x2ee4>
    2b1c:      	str	w21, [sp, #0xc8]
    2b20:      	mov	x3, xzr
    2b24:      	mov	w8, #0x2                // =2
    2b28:      	add	x9, sp, #0x60
    2b2c:      	add	x10, sp, #0xc8
    2b30:      	add	x1, sp, #0x60
    2b34:      	add	x2, sp, #0xc8
    2b38:      	mov	x0, x23
    2b3c:      	blr	x8
    2b40:      	mov	w8, #-0x4               // =-4
    2b44:      	b	0x2da0 <generic_lsm_process_event+0x2bd0>
    2b48:      	str	w21, [sp, #0xd8]
    2b4c:      	mov	x3, xzr
    2b50:      	mov	w8, #0x2                // =2
    2b54:      	add	x9, sp, #0x60
    2b58:      	add	x10, sp, #0xd8
    2b5c:      	add	x1, sp, #0x60
    2b60:      	add	x2, sp, #0xd8
    2b64:      	mov	x0, x23
    2b68:      	blr	x8
    2b6c:      	mov	w8, #-0x4               // =-4
    2b70:      	b	0x3040 <generic_lsm_process_event+0x2e70>
    2b74:      	ldrb	w8, [x24, #0x7]
    2b78:      	lsl	w8, w8, #3
    2b7c:      	b	0x30b0 <generic_lsm_process_event+0x2ee0>
    2b80:      	mov	w25, #0x4               // =4
    2b84:      	b	0x395c <generic_lsm_process_event+0x378c>
    2b88:      	mov	w9, #0x5e60             // =24160
    2b8c:      	b	0x2b9c <generic_lsm_process_event+0x29cc>
    2b90:      	mov	w9, #0x5e68             // =24168
    2b94:      	b	0x2b9c <generic_lsm_process_event+0x29cc>
    2b98:      	mov	w9, #0x5e50             // =24144
    2b9c:      	ldr	x8, [sp, #0x10]
    2ba0:      	add	x8, x8, x9
    2ba4:      	ldr	x8, [x8]
    2ba8:      	add	x21, sp, #0xd0
    2bac:      	mov	w25, #0x8               // =8
    2bb0:      	add	x9, sp, #0xd0
    2bb4:      	str	x8, [x21, #0x8]
    2bb8:      	mov	w8, #0x4                // =4
    2bbc:      	add	x10, sp, #0xd8
    2bc0:      	add	x0, sp, #0xd0
    2bc4:      	add	x2, sp, #0xd8
    2bc8:      	mov	w1, #0x8                // =8
    2bcc:      	blr	x8
    2bd0:      	ldr	x21, [x21]
    2bd4:      	tbz	w23, #0x5, 0x2d64 <generic_lsm_process_event+0x2b94>
    2bd8:      	cmp	x21, #0x1, lsl #12      // =0x1000
    2bdc:      	b.lo	0x2d48 <generic_lsm_process_event+0x2b78>
    2be0:      	ldr	x9, [sp, #0x18]
    2be4:      	mov	w8, #0x1                // =1
    2be8:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    2bec:      	add	x1, sp, #0xe0
    2bf0:      	str	w8, [x9]
    2bf4:      	str	wzr, [sp, #0xe0]
    2bf8:      	add	x9, sp, #0xe0
    2bfc:      	ldr	x0, [x0]
    2c00:      	blr	x8
    2c04:      	cbz	x0, 0x3044 <generic_lsm_process_event+0x2e74>
    2c08:      	mov	w8, #0x18               // =24
    2c0c:      	mov	x29, x0
    2c10:      	str	w8, [x0]
    2c14:      	mov	w8, #0xe                // =14
    2c18:      	blr	x8
    2c1c:      	mov	x23, x29
    2c20:      	cmn	x0, #0x16
    2c24:      	str	x0, [x23, #0x10]!
    2c28:      	b.ne	0x2c50 <generic_lsm_process_event+0x2a80>
    2c2c:      	add	x2, x19, #0xe8
    2c30:      	mov	w8, #0x8                // =8
    2c34:      	mov	w9, #0x4                // =4
    2c38:      	add	x10, sp, #0x88
    2c3c:      	add	x0, sp, #0x88
    2c40:      	mov	w1, #0x8                // =8
    2c44:      	blr	x9
    2c48:      	ldr	x8, [sp, #0x88]
    2c4c:      	str	x8, [x23]
    2c50:      	mov	w8, #0x7d               // =125
    2c54:      	blr	x8
    2c58:      	str	x0, [x29, #0x18]
    2c5c:      	add	x8, x29, #0x20
    2c60:      	ldr	x10, [sp, #0x18]
    2c64:      	mov	x25, xzr
    2c68:      	mov	w24, #0xa               // =10
    2c6c:      	str	x8, [sp, #0x30]
    2c70:      	ldp	x8, x9, [x23]
    2c74:      	stur	x8, [x10, #0x14]
    2c78:      	stur	x9, [x10, #0x1c]
    2c7c:      	subs	x8, x21, x25
    2c80:      	b.mi	0x31ac <generic_lsm_process_event+0x2fdc>
    2c84:      	ldp	x0, x9, [sp, #0x30]
    2c88:      	add	x2, x25, x9
    2c8c:      	mov	w9, #0x7fe0             // =32736
    2c90:      	cmp	x8, x9
    2c94:      	csel	x23, x8, x9, lo
    2c98:      	mov	w8, #0x4                // =4
    2c9c:      	mov	w1, w23
    2ca0:      	blr	x8
    2ca4:      	tbnz	w0, #0x1f, 0x2d24 <generic_lsm_process_event+0x2b54>
    2ca8:      	add	w8, w23, #0x20
    2cac:      	str	wzr, [sp, #0x88]
    2cb0:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    2cb4:      	add	x9, sp, #0x88
    2cb8:      	str	w8, [x29, #0x4]
    2cbc:      	mov	x22, x8
    2cc0:      	mov	w8, #0x1                // =1
    2cc4:      	add	x1, sp, #0x88
    2cc8:      	ldr	x0, [x0]
    2ccc:      	blr	x8
    2cd0:      	cbz	x0, 0x2d04 <generic_lsm_process_event+0x2b34>
    2cd4:      	ldrb	w8, [x0, #0x28]
    2cd8:      	cbz	w8, 0x2d04 <generic_lsm_process_event+0x2b34>
    2cdc:      	adrp	x1, 0x2000 <generic_lsm_process_event+0x1e30>
    2ce0:      	mov	w8, #0x19               // =25
    2ce4:      	mov	w9, #-0x1               // =-1
    2ce8:      	ldr	x1, [x1]
    2cec:      	mov	x0, x19
    2cf0:      	mov	w2, #-0x1               // =-1
    2cf4:      	mov	x3, x29
    2cf8:      	mov	x4, x22
    2cfc:      	blr	x8
    2d00:      	b	0x2d20 <generic_lsm_process_event+0x2b50>
    2d04:      	adrp	x0, 0x2000 <generic_lsm_process_event+0x1e30>
    2d08:      	mov	x3, xzr
    2d0c:      	mov	w8, #0x82               // =130
    2d10:      	ldr	x0, [x0]
    2d14:      	mov	x1, x29
    2d18:      	mov	x2, x22
    2d1c:      	blr	x8
    2d20:      	tbz	w0, #0x1f, 0x2d28 <generic_lsm_process_event+0x2b58>
    2d24:      	sxtw	x23, w0
    2d28:      	tbnz	w23, #0x1f, 0x31b4 <generic_lsm_process_event+0x2fe4>
    2d2c:      	and	x8, x23, #0x7fffffff
    2d30:      	add	x25, x8, x25
    2d34:      	cmp	x25, x21
    2d38:      	b.eq	0x3200 <generic_lsm_process_event+0x3030>
    2d3c:      	subs	w24, w24, #0x1
    2d40:      	b.ne	0x2c7c <generic_lsm_process_event+0x2aac>
    2d44:      	b	0x356c <generic_lsm_process_event+0x339c>
    2d48:      	ldr	x8, [sp, #0x18]
    2d4c:      	mov	w25, #0xc               // =12
    2d50:      	str	wzr, [x8]
    2d54:      	ldr	x8, [sp, #0xf8]
    2d58:      	add	x8, x24, x8
    2d5c:      	add	x8, x8, #0x8
    2d60:      	str	x8, [sp, #0x18]
    2d64:      	cmp	x21, #0xfff
    2d68:      	mov	w8, #0xfff              // =4095
    2d6c:      	ldr	x2, [sp, #0x38]
    2d70:      	csel	x23, x21, x8, lo
    2d74:      	ldr	x8, [sp, #0x18]
    2d78:      	mov	w1, w23
    2d7c:      	add	x0, x8, #0x8
    2d80:      	mov	w8, #0x4                // =4
    2d84:      	blr	x8
    2d88:      	tbnz	w0, #0x1f, 0x2d9c <generic_lsm_process_event+0x2bcc>
    2d8c:      	ldr	x8, [sp, #0x18]
    2d90:      	add	x25, x25, x23
    2d94:      	stp	w21, w23, [x8]
    2d98:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2d9c:      	mov	w8, #-0x2               // =-2
    2da0:      	ldr	x9, [sp, #0x18]
    2da4:      	mov	w25, #0x4               // =4
    2da8:      	str	w8, [x9]
    2dac:      	b	0x3954 <generic_lsm_process_event+0x3784>
    2db0:      	ldr	x8, [sp, #0xf8]
    2db4:      	mov	w9, #0x4                // =4
    2db8:      	mov	w1, w23
    2dbc:      	add	x25, x8, #0xc
    2dc0:      	ldr	x8, [sp, #0x88]
    2dc4:      	add	x0, x24, x25
    2dc8:      	ldr	x2, [sp, #0x88]
    2dcc:      	blr	x9
    2dd0:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2dd4:      	cmp	x21, #0x1
    2dd8:      	b.eq	0x2af0 <generic_lsm_process_event+0x2920>
    2ddc:      	ldr	x8, [sp, #0x38]
    2de0:      	mov	w9, #0x4                // =4
    2de4:      	add	x10, sp, #0x88
    2de8:      	add	x0, sp, #0x88
    2dec:      	mov	w1, #0x10               // =16
    2df0:      	add	x2, x8, #0x10
    2df4:      	mov	w8, #0x10               // =16
    2df8:      	blr	x9
    2dfc:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2e00:      	ldr	x8, [sp, #0x90]
    2e04:      	cmp	x8, #0xffe
    2e08:      	b.hi	0x2a08 <generic_lsm_process_event+0x2838>
    2e0c:      	add	x25, x23, x25
    2e10:      	mov	x29, x8
    2e14:      	ldr	x8, [sp, #0x88]
    2e18:      	mov	w9, #0x4                // =4
    2e1c:      	add	x0, x24, x25
    2e20:      	mov	x1, x29
    2e24:      	ldr	x2, [sp, #0x88]
    2e28:      	blr	x9
    2e2c:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2e30:      	add	x23, x29, x23
    2e34:      	cmp	x21, #0x3
    2e38:      	b.lo	0x2af0 <generic_lsm_process_event+0x2920>
    2e3c:      	ldr	x8, [sp, #0x38]
    2e40:      	mov	w9, #0x4                // =4
    2e44:      	add	x10, sp, #0x88
    2e48:      	add	x0, sp, #0x88
    2e4c:      	mov	w1, #0x10               // =16
    2e50:      	add	x2, x8, #0x20
    2e54:      	mov	w8, #0x10               // =16
    2e58:      	blr	x9
    2e5c:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2e60:      	ldr	x8, [sp, #0x90]
    2e64:      	cmp	x8, #0xffe
    2e68:      	str	x8, [sp, #0x30]
    2e6c:      	b.hi	0x2a08 <generic_lsm_process_event+0x2838>
    2e70:      	add	x25, x29, x25
    2e74:      	mov	w9, #0x4                // =4
    2e78:      	ldr	x1, [sp, #0x30]
    2e7c:      	and	x8, x25, #0x3fff
    2e80:      	add	x0, x24, x8
    2e84:      	ldr	x8, [sp, #0x88]
    2e88:      	ldr	x2, [sp, #0x88]
    2e8c:      	blr	x9
    2e90:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2e94:      	ldr	x8, [sp, #0x30]
    2e98:      	cmp	x21, #0x3
    2e9c:      	add	x23, x8, x23
    2ea0:      	b.eq	0x2af0 <generic_lsm_process_event+0x2920>
    2ea4:      	ldr	x8, [sp, #0x38]
    2ea8:      	mov	w9, #0x4                // =4
    2eac:      	add	x10, sp, #0x88
    2eb0:      	add	x0, sp, #0x88
    2eb4:      	mov	w1, #0x10               // =16
    2eb8:      	add	x2, x8, #0x30
    2ebc:      	mov	w8, #0x10               // =16
    2ec0:      	blr	x9
    2ec4:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2ec8:      	ldr	x8, [sp, #0x90]
    2ecc:      	cmp	x8, #0xffe
    2ed0:      	str	x8, [sp, #0x18]
    2ed4:      	b.hi	0x2a08 <generic_lsm_process_event+0x2838>
    2ed8:      	ldr	x8, [sp, #0x30]
    2edc:      	mov	w9, #0x4                // =4
    2ee0:      	ldr	x1, [sp, #0x18]
    2ee4:      	add	x25, x8, x25
    2ee8:      	and	x8, x25, #0x3fff
    2eec:      	add	x0, x24, x8
    2ef0:      	ldr	x8, [sp, #0x88]
    2ef4:      	ldr	x2, [sp, #0x88]
    2ef8:      	blr	x9
    2efc:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2f00:      	ldr	x8, [sp, #0x18]
    2f04:      	cmp	x21, #0x5
    2f08:      	add	x23, x8, x23
    2f0c:      	b.lo	0x2af0 <generic_lsm_process_event+0x2920>
    2f10:      	ldr	x8, [sp, #0x38]
    2f14:      	mov	w9, #0x4                // =4
    2f18:      	add	x10, sp, #0x88
    2f1c:      	add	x0, sp, #0x88
    2f20:      	mov	w1, #0x10               // =16
    2f24:      	add	x2, x8, #0x40
    2f28:      	mov	w8, #0x10               // =16
    2f2c:      	blr	x9
    2f30:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2f34:      	ldr	x29, [sp, #0x90]
    2f38:      	cmp	x29, #0xffe
    2f3c:      	b.hi	0x2a08 <generic_lsm_process_event+0x2838>
    2f40:      	ldr	x8, [sp, #0x18]
    2f44:      	mov	w9, #0x4                // =4
    2f48:      	mov	w1, w29
    2f4c:      	add	x25, x8, x25
    2f50:      	and	x8, x25, #0x3fff
    2f54:      	add	x0, x24, x8
    2f58:      	ldr	x8, [sp, #0x88]
    2f5c:      	ldr	x2, [sp, #0x88]
    2f60:      	blr	x9
    2f64:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2f68:      	add	x23, x29, x23
    2f6c:      	cmp	x21, #0x5
    2f70:      	b.eq	0x2af0 <generic_lsm_process_event+0x2920>
    2f74:      	ldr	x8, [sp, #0x38]
    2f78:      	mov	w9, #0x4                // =4
    2f7c:      	add	x10, sp, #0x88
    2f80:      	add	x0, sp, #0x88
    2f84:      	mov	w1, #0x10               // =16
    2f88:      	add	x2, x8, #0x50
    2f8c:      	mov	w8, #0x10               // =16
    2f90:      	blr	x9
    2f94:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2f98:      	ldr	x8, [sp, #0x90]
    2f9c:      	cmp	x8, #0xffe
    2fa0:      	str	x8, [sp, #0x30]
    2fa4:      	b.hi	0x2a08 <generic_lsm_process_event+0x2838>
    2fa8:      	add	x25, x29, x25
    2fac:      	mov	w9, #0x4                // =4
    2fb0:      	ldr	x1, [sp, #0x30]
    2fb4:      	and	x8, x25, #0x3fff
    2fb8:      	add	x0, x24, x8
    2fbc:      	ldr	x8, [sp, #0x88]
    2fc0:      	ldr	x2, [sp, #0x88]
    2fc4:      	blr	x9
    2fc8:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    2fcc:      	ldr	x8, [sp, #0x30]
    2fd0:      	cmp	x21, #0x7
    2fd4:      	add	x23, x8, x23
    2fd8:      	b.lo	0x2af0 <generic_lsm_process_event+0x2920>
    2fdc:      	ldr	x8, [sp, #0x38]
    2fe0:      	mov	w9, #0x4                // =4
    2fe4:      	add	x10, sp, #0x88
    2fe8:      	add	x0, sp, #0x88
    2fec:      	mov	w1, #0x10               // =16
    2ff0:      	add	x2, x8, #0x60
    2ff4:      	mov	w8, #0x10               // =16
    2ff8:      	blr	x9
    2ffc:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    3000:      	ldr	x21, [sp, #0x90]
    3004:      	cmp	x21, #0xffe
    3008:      	b.hi	0x2a08 <generic_lsm_process_event+0x2838>
    300c:      	ldr	x8, [sp, #0x30]
    3010:      	mov	w9, #0x4                // =4
    3014:      	mov	w1, w21
    3018:      	add	x8, x8, x25
    301c:      	and	x8, x8, #0x3fff
    3020:      	add	x0, x24, x8
    3024:      	ldr	x8, [sp, #0x88]
    3028:      	ldr	x2, [sp, #0x88]
    302c:      	blr	x9
    3030:      	tbnz	w0, #0x1f, 0x303c <generic_lsm_process_event+0x2e6c>
    3034:      	add	x23, x21, x23
    3038:      	b	0x2af0 <generic_lsm_process_event+0x2920>
    303c:      	mov	w8, #-0x2               // =-2
    3040:      	str	w8, [x22]
    3044:      	mov	w25, #0x4               // =4
    3048:      	b	0x3954 <generic_lsm_process_event+0x3784>
    304c:      	mov	x21, #-0x1              // =-1
    3050:      	b	0x3058 <generic_lsm_process_event+0x2e88>
    3054:      	mov	x21, x24
    3058:      	str	wzr, [sp, #0x88]
    305c:      	adrp	x0, 0x3000 <generic_lsm_process_event+0x2e30>
    3060:      	mov	w8, #0x1                // =1
    3064:      	add	x9, sp, #0x88
    3068:      	ldr	x0, [x0]
    306c:      	add	x1, sp, #0x88
    3070:      	blr	x8
    3074:      	cbz	x0, 0x341c <generic_lsm_process_event+0x324c>
    3078:      	cmn	x21, #0xc
    307c:      	b.gt	0x318c <generic_lsm_process_event+0x2fbc>
    3080:      	cmn	x21, #0x1c
    3084:      	b.eq	0x33e8 <generic_lsm_process_event+0x3218>
    3088:      	cmn	x21, #0x16
    308c:      	b.eq	0x3400 <generic_lsm_process_event+0x3230>
    3090:      	cmn	x21, #0x10
    3094:      	b.ne	0x33f8 <generic_lsm_process_event+0x3228>
    3098:      	add	x8, x0, #0x558
    309c:      	b	0x340c <generic_lsm_process_event+0x323c>
    30a0:      	mov	x21, x22
    30a4:      	b	0x341c <generic_lsm_process_event+0x324c>
    30a8:      	ldrb	w8, [x24, #0x7]
    30ac:      	lsl	w8, w8, #2
    30b0:      	add	w8, w8, #0x8
    30b4:      	strh	w8, [x24, #0x2]
    30b8:      	ldrh	w9, [x24]
    30bc:      	ldrb	w25, [x24, #0x6]
    30c0:      	add	w8, w9, w8
    30c4:      	cmp	w25, #0x3c
    30c8:      	strh	w8, [x24]
    30cc:      	b.hi	0x3184 <generic_lsm_process_event+0x2fb4>
    30d0:      	mov	x10, #0x1               // =1
    30d4:      	mov	w9, #0x1                // =1
    30d8:      	movk	x10, #0x1800, lsl #32
    30dc:      	lsl	x9, x9, x25
    30e0:      	movk	x10, #0x1008, lsl #48
    30e4:      	tst	x9, x10
    30e8:      	b.eq	0x3184 <generic_lsm_process_event+0x2fb4>
    30ec:      	strb	w25, [x24, #0x5]
    30f0:      	add	x8, x22, w8, uxth
    30f4:      	mov	w9, #0x2                // =2
    30f8:      	mov	w10, #0x4               // =4
    30fc:      	mov	x0, x23
    3100:      	mov	w1, #0x2                // =2
    3104:      	ldrh	w8, [x24]
    3108:      	add	x2, x22, x8
    310c:      	blr	x10
    3110:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    3114:      	ldrb	w8, [x24, #0x5]
    3118:      	cmp	w8, #0x32
    311c:      	b.gt	0x313c <generic_lsm_process_event+0x2f6c>
    3120:      	cbz	w8, 0x315c <generic_lsm_process_event+0x2f8c>
    3124:      	cmp	w8, #0x2b
    3128:      	b.eq	0x315c <generic_lsm_process_event+0x2f8c>
    312c:      	cmp	w8, #0x2c
    3130:      	b.ne	0x32c8 <generic_lsm_process_event+0x30f8>
    3134:      	mov	w8, #0x8                // =8
    3138:      	b	0x3214 <generic_lsm_process_event+0x3044>
    313c:      	cmp	w8, #0x33
    3140:      	b.eq	0x3208 <generic_lsm_process_event+0x3038>
    3144:      	cmp	w8, #0x3c
    3148:      	b.eq	0x315c <generic_lsm_process_event+0x2f8c>
    314c:      	cmp	w8, #0xff
    3150:      	b.ne	0x32c8 <generic_lsm_process_event+0x30f8>
    3154:      	mov	w8, #0x28               // =40
    3158:      	b	0x3214 <generic_lsm_process_event+0x3044>
    315c:      	ldrb	w8, [x24, #0x7]
    3160:      	lsl	w8, w8, #3
    3164:      	b	0x3210 <generic_lsm_process_event+0x3040>
    3168:      	ldrh	w8, [x24, #0x2]
    316c:      	ldrh	w9, [x24]
    3170:      	ldrb	w25, [x24, #0x6]
    3174:      	add	w8, w9, w8
    3178:      	cmp	w25, #0x3c
    317c:      	strh	w8, [x24]
    3180:      	b.ls	0x30d0 <generic_lsm_process_event+0x2f00>
    3184:      	strh	w8, [sp, #0xc8]
    3188:      	b	0x37d4 <generic_lsm_process_event+0x3604>
    318c:      	cmn	x21, #0xb
    3190:      	b.eq	0x33f0 <generic_lsm_process_event+0x3220>
    3194:      	cmn	x21, #0x7
    3198:      	b.eq	0x3408 <generic_lsm_process_event+0x3238>
    319c:      	cmn	x21, #0x2
    31a0:      	b.ne	0x33f8 <generic_lsm_process_event+0x3228>
    31a4:      	add	x8, x0, #0x548
    31a8:      	b	0x340c <generic_lsm_process_event+0x323c>
    31ac:      	mov	x25, #-0x1              // =-1
    31b0:      	b	0x31b8 <generic_lsm_process_event+0x2fe8>
    31b4:      	mov	x25, x23
    31b8:      	str	wzr, [sp, #0x88]
    31bc:      	adrp	x0, 0x3000 <generic_lsm_process_event+0x2e30>
    31c0:      	mov	w8, #0x1                // =1
    31c4:      	add	x9, sp, #0x88
    31c8:      	ldr	x0, [x0]
    31cc:      	add	x1, sp, #0x88
    31d0:      	blr	x8
    31d4:      	cbz	x0, 0x356c <generic_lsm_process_event+0x339c>
    31d8:      	cmn	x25, #0xc
    31dc:      	b.gt	0x32e8 <generic_lsm_process_event+0x3118>
    31e0:      	cmn	x25, #0x1c
    31e4:      	b.eq	0x3538 <generic_lsm_process_event+0x3368>
    31e8:      	cmn	x25, #0x16
    31ec:      	b.eq	0x3550 <generic_lsm_process_event+0x3380>
    31f0:      	cmn	x25, #0x10
    31f4:      	b.ne	0x3548 <generic_lsm_process_event+0x3378>
    31f8:      	add	x8, x0, #0x558
    31fc:      	b	0x355c <generic_lsm_process_event+0x338c>
    3200:      	mov	x25, x21
    3204:      	b	0x356c <generic_lsm_process_event+0x339c>
    3208:      	ldrb	w8, [x24, #0x7]
    320c:      	lsl	w8, w8, #2
    3210:      	add	w8, w8, #0x8
    3214:      	strh	w8, [x24, #0x2]
    3218:      	ldrh	w9, [x24]
    321c:      	ldrb	w25, [x24, #0x6]
    3220:      	add	w8, w9, w8
    3224:      	cmp	w25, #0x3c
    3228:      	strh	w8, [x24]
    322c:      	b.hi	0x3a70 <generic_lsm_process_event+0x38a0>
    3230:      	mov	x10, #0x1               // =1
    3234:      	mov	w9, #0x1                // =1
    3238:      	movk	x10, #0x1800, lsl #32
    323c:      	lsl	x9, x9, x25
    3240:      	movk	x10, #0x1008, lsl #48
    3244:      	tst	x9, x10
    3248:      	b.eq	0x3a70 <generic_lsm_process_event+0x38a0>
    324c:      	strb	w25, [x24, #0x5]
    3250:      	add	x8, x22, w8, uxth
    3254:      	mov	w9, #0x2                // =2
    3258:      	mov	w10, #0x4               // =4
    325c:      	mov	x0, x23
    3260:      	mov	w1, #0x2                // =2
    3264:      	ldrh	w8, [x24]
    3268:      	add	x2, x22, x8
    326c:      	blr	x10
    3270:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    3274:      	ldrb	w8, [x24, #0x5]
    3278:      	cmp	w8, #0x32
    327c:      	b.gt	0x329c <generic_lsm_process_event+0x30cc>
    3280:      	cbz	w8, 0x32bc <generic_lsm_process_event+0x30ec>
    3284:      	cmp	w8, #0x2b
    3288:      	b.eq	0x32bc <generic_lsm_process_event+0x30ec>
    328c:      	cmp	w8, #0x2c
    3290:      	b.ne	0x33c8 <generic_lsm_process_event+0x31f8>
    3294:      	mov	w8, #0x8                // =8
    3298:      	b	0x3314 <generic_lsm_process_event+0x3144>
    329c:      	cmp	w8, #0x33
    32a0:      	b.eq	0x3308 <generic_lsm_process_event+0x3138>
    32a4:      	cmp	w8, #0x3c
    32a8:      	b.eq	0x32bc <generic_lsm_process_event+0x30ec>
    32ac:      	cmp	w8, #0xff
    32b0:      	b.ne	0x33c8 <generic_lsm_process_event+0x31f8>
    32b4:      	mov	w8, #0x28               // =40
    32b8:      	b	0x3314 <generic_lsm_process_event+0x3144>
    32bc:      	ldrb	w8, [x24, #0x7]
    32c0:      	lsl	w8, w8, #3
    32c4:      	b	0x3310 <generic_lsm_process_event+0x3140>
    32c8:      	ldrh	w8, [x24, #0x2]
    32cc:      	ldrh	w9, [x24]
    32d0:      	ldrb	w25, [x24, #0x6]
    32d4:      	add	w8, w9, w8
    32d8:      	cmp	w25, #0x3c
    32dc:      	strh	w8, [x24]
    32e0:      	b.ls	0x3230 <generic_lsm_process_event+0x3060>
    32e4:      	b	0x3a70 <generic_lsm_process_event+0x38a0>
    32e8:      	cmn	x25, #0xb
    32ec:      	b.eq	0x3540 <generic_lsm_process_event+0x3370>
    32f0:      	cmn	x25, #0x7
    32f4:      	b.eq	0x3558 <generic_lsm_process_event+0x3388>
    32f8:      	cmn	x25, #0x2
    32fc:      	b.ne	0x3548 <generic_lsm_process_event+0x3378>
    3300:      	add	x8, x0, #0x548
    3304:      	b	0x355c <generic_lsm_process_event+0x338c>
    3308:      	ldrb	w8, [x24, #0x7]
    330c:      	lsl	w8, w8, #2
    3310:      	add	w8, w8, #0x8
    3314:      	strh	w8, [x24, #0x2]
    3318:      	ldrh	w9, [x24]
    331c:      	ldrb	w25, [x24, #0x6]
    3320:      	add	w8, w9, w8
    3324:      	cmp	w25, #0x3c
    3328:      	strh	w8, [x24]
    332c:      	b.hi	0x3a70 <generic_lsm_process_event+0x38a0>
    3330:      	mov	x10, #0x1               // =1
    3334:      	mov	w9, #0x1                // =1
    3338:      	movk	x10, #0x1800, lsl #32
    333c:      	lsl	x9, x9, x25
    3340:      	movk	x10, #0x1008, lsl #48
    3344:      	tst	x9, x10
    3348:      	b.eq	0x3a70 <generic_lsm_process_event+0x38a0>
    334c:      	strb	w25, [x24, #0x5]
    3350:      	add	x8, x22, w8, uxth
    3354:      	mov	w9, #0x2                // =2
    3358:      	mov	w10, #0x4               // =4
    335c:      	mov	x0, x23
    3360:      	mov	w1, #0x2                // =2
    3364:      	ldrh	w8, [x24]
    3368:      	add	x2, x22, x8
    336c:      	blr	x10
    3370:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    3374:      	ldrb	w8, [x24, #0x5]
    3378:      	cmp	w8, #0x32
    337c:      	b.gt	0x339c <generic_lsm_process_event+0x31cc>
    3380:      	cbz	w8, 0x33bc <generic_lsm_process_event+0x31ec>
    3384:      	cmp	w8, #0x2b
    3388:      	b.eq	0x33bc <generic_lsm_process_event+0x31ec>
    338c:      	cmp	w8, #0x2c
    3390:      	b.ne	0x3518 <generic_lsm_process_event+0x3348>
    3394:      	mov	w8, #0x8                // =8
    3398:      	b	0x3464 <generic_lsm_process_event+0x3294>
    339c:      	cmp	w8, #0x33
    33a0:      	b.eq	0x3458 <generic_lsm_process_event+0x3288>
    33a4:      	cmp	w8, #0x3c
    33a8:      	b.eq	0x33bc <generic_lsm_process_event+0x31ec>
    33ac:      	cmp	w8, #0xff
    33b0:      	b.ne	0x3518 <generic_lsm_process_event+0x3348>
    33b4:      	mov	w8, #0x28               // =40
    33b8:      	b	0x3464 <generic_lsm_process_event+0x3294>
    33bc:      	ldrb	w8, [x24, #0x7]
    33c0:      	lsl	w8, w8, #3
    33c4:      	b	0x3460 <generic_lsm_process_event+0x3290>
    33c8:      	ldrh	w8, [x24, #0x2]
    33cc:      	ldrh	w9, [x24]
    33d0:      	ldrb	w25, [x24, #0x6]
    33d4:      	add	w8, w9, w8
    33d8:      	cmp	w25, #0x3c
    33dc:      	strh	w8, [x24]
    33e0:      	b.ls	0x3330 <generic_lsm_process_event+0x3160>
    33e4:      	b	0x3a70 <generic_lsm_process_event+0x38a0>
    33e8:      	add	x8, x0, #0x568
    33ec:      	b	0x340c <generic_lsm_process_event+0x323c>
    33f0:      	add	x8, x0, #0x570
    33f4:      	b	0x340c <generic_lsm_process_event+0x323c>
    33f8:      	add	x8, x0, #0x540
    33fc:      	b	0x340c <generic_lsm_process_event+0x323c>
    3400:      	add	x8, x0, #0x560
    3404:      	b	0x340c <generic_lsm_process_event+0x323c>
    3408:      	add	x8, x0, #0x550
    340c:      	ldaxr	x9, [x8]
    3410:      	add	x9, x9, #0x1
    3414:      	stlxr	w10, x9, [x8]
    3418:      	cbnz	w10, 0x340c <generic_lsm_process_event+0x323c>
    341c:      	tbnz	w21, #0x1f, 0x3438 <generic_lsm_process_event+0x3268>
    3420:      	ldr	x8, [sp, #0x38]
    3424:      	cmn	x22, #0x1
    3428:      	stur	xzr, [x8, #0x4]
    342c:      	sub	w8, w22, w21
    3430:      	csel	w8, wzr, w8, eq
    3434:      	b	0x3448 <generic_lsm_process_event+0x3278>
    3438:      	ldr	x9, [sp, #0x38]
    343c:      	mov	w8, wzr
    3440:      	stp	w21, wzr, [x9, #0x4]
    3444:      	mov	w21, wzr
    3448:      	ldr	x9, [sp, #0x38]
    344c:      	mov	w25, #0x24              // =36
    3450:      	stp	w8, w21, [x9, #0xc]
    3454:      	b	0x395c <generic_lsm_process_event+0x378c>
    3458:      	ldrb	w8, [x24, #0x7]
    345c:      	lsl	w8, w8, #2
    3460:      	add	w8, w8, #0x8
    3464:      	strh	w8, [x24, #0x2]
    3468:      	ldrh	w9, [x24]
    346c:      	ldrb	w25, [x24, #0x6]
    3470:      	add	w8, w9, w8
    3474:      	cmp	w25, #0x3c
    3478:      	strh	w8, [x24]
    347c:      	b.hi	0x3a70 <generic_lsm_process_event+0x38a0>
    3480:      	mov	x10, #0x1               // =1
    3484:      	mov	w9, #0x1                // =1
    3488:      	movk	x10, #0x1800, lsl #32
    348c:      	lsl	x9, x9, x25
    3490:      	movk	x10, #0x1008, lsl #48
    3494:      	tst	x9, x10
    3498:      	b.eq	0x3a70 <generic_lsm_process_event+0x38a0>
    349c:      	strb	w25, [x24, #0x5]
    34a0:      	add	x8, x22, w8, uxth
    34a4:      	mov	w9, #0x2                // =2
    34a8:      	mov	w10, #0x4               // =4
    34ac:      	mov	x0, x23
    34b0:      	mov	w1, #0x2                // =2
    34b4:      	ldrh	w8, [x24]
    34b8:      	add	x2, x22, x8
    34bc:      	blr	x10
    34c0:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    34c4:      	ldrb	w8, [x24, #0x5]
    34c8:      	cmp	w8, #0x32
    34cc:      	b.gt	0x34ec <generic_lsm_process_event+0x331c>
    34d0:      	cbz	w8, 0x350c <generic_lsm_process_event+0x333c>
    34d4:      	cmp	w8, #0x2b
    34d8:      	b.eq	0x350c <generic_lsm_process_event+0x333c>
    34dc:      	cmp	w8, #0x2c
    34e0:      	b.ne	0x3668 <generic_lsm_process_event+0x3498>
    34e4:      	mov	w8, #0x8                // =8
    34e8:      	b	0x35b4 <generic_lsm_process_event+0x33e4>
    34ec:      	cmp	w8, #0x33
    34f0:      	b.eq	0x35a8 <generic_lsm_process_event+0x33d8>
    34f4:      	cmp	w8, #0x3c
    34f8:      	b.eq	0x350c <generic_lsm_process_event+0x333c>
    34fc:      	cmp	w8, #0xff
    3500:      	b.ne	0x3668 <generic_lsm_process_event+0x3498>
    3504:      	mov	w8, #0x28               // =40
    3508:      	b	0x35b4 <generic_lsm_process_event+0x33e4>
    350c:      	ldrb	w8, [x24, #0x7]
    3510:      	lsl	w8, w8, #3
    3514:      	b	0x35b0 <generic_lsm_process_event+0x33e0>
    3518:      	ldrh	w8, [x24, #0x2]
    351c:      	ldrh	w9, [x24]
    3520:      	ldrb	w25, [x24, #0x6]
    3524:      	add	w8, w9, w8
    3528:      	cmp	w25, #0x3c
    352c:      	strh	w8, [x24]
    3530:      	b.ls	0x3480 <generic_lsm_process_event+0x32b0>
    3534:      	b	0x3a70 <generic_lsm_process_event+0x38a0>
    3538:      	add	x8, x0, #0x568
    353c:      	b	0x355c <generic_lsm_process_event+0x338c>
    3540:      	add	x8, x0, #0x570
    3544:      	b	0x355c <generic_lsm_process_event+0x338c>
    3548:      	add	x8, x0, #0x540
    354c:      	b	0x355c <generic_lsm_process_event+0x338c>
    3550:      	add	x8, x0, #0x560
    3554:      	b	0x355c <generic_lsm_process_event+0x338c>
    3558:      	add	x8, x0, #0x550
    355c:      	ldaxr	x9, [x8]
    3560:      	add	x9, x9, #0x1
    3564:      	stlxr	w10, x9, [x8]
    3568:      	cbnz	w10, 0x355c <generic_lsm_process_event+0x338c>
    356c:      	tbnz	w25, #0x1f, 0x3588 <generic_lsm_process_event+0x33b8>
    3570:      	ldr	x8, [sp, #0x18]
    3574:      	cmn	x21, #0x1
    3578:      	stur	xzr, [x8, #0x4]
    357c:      	sub	w8, w21, w25
    3580:      	csel	w8, wzr, w8, eq
    3584:      	b	0x3598 <generic_lsm_process_event+0x33c8>
    3588:      	ldr	x9, [sp, #0x18]
    358c:      	mov	w8, wzr
    3590:      	stp	w25, wzr, [x9, #0x4]
    3594:      	mov	w25, wzr
    3598:      	ldr	x9, [sp, #0x18]
    359c:      	stp	w8, w25, [x9, #0xc]
    35a0:      	mov	w25, #0x24              // =36
    35a4:      	b	0x3954 <generic_lsm_process_event+0x3784>
    35a8:      	ldrb	w8, [x24, #0x7]
    35ac:      	lsl	w8, w8, #2
    35b0:      	add	w8, w8, #0x8
    35b4:      	strh	w8, [x24, #0x2]
    35b8:      	ldrh	w9, [x24]
    35bc:      	ldrb	w25, [x24, #0x6]
    35c0:      	add	w8, w9, w8
    35c4:      	cmp	w25, #0x3c
    35c8:      	strh	w8, [x24]
    35cc:      	b.hi	0x3a70 <generic_lsm_process_event+0x38a0>
    35d0:      	mov	x10, #0x1               // =1
    35d4:      	mov	w9, #0x1                // =1
    35d8:      	movk	x10, #0x1800, lsl #32
    35dc:      	lsl	x9, x9, x25
    35e0:      	movk	x10, #0x1008, lsl #48
    35e4:      	tst	x9, x10
    35e8:      	b.eq	0x3a70 <generic_lsm_process_event+0x38a0>
    35ec:      	strb	w25, [x24, #0x5]
    35f0:      	add	x8, x22, w8, uxth
    35f4:      	mov	w9, #0x2                // =2
    35f8:      	mov	w10, #0x4               // =4
    35fc:      	mov	x0, x23
    3600:      	mov	w1, #0x2                // =2
    3604:      	ldrh	w8, [x24]
    3608:      	add	x2, x22, x8
    360c:      	blr	x10
    3610:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    3614:      	ldrb	w8, [x24, #0x5]
    3618:      	cmp	w8, #0x32
    361c:      	b.gt	0x363c <generic_lsm_process_event+0x346c>
    3620:      	cbz	w8, 0x365c <generic_lsm_process_event+0x348c>
    3624:      	cmp	w8, #0x2b
    3628:      	b.eq	0x365c <generic_lsm_process_event+0x348c>
    362c:      	cmp	w8, #0x2c
    3630:      	b.ne	0x3748 <generic_lsm_process_event+0x3578>
    3634:      	mov	w8, #0x8                // =8
    3638:      	b	0x3694 <generic_lsm_process_event+0x34c4>
    363c:      	cmp	w8, #0x33
    3640:      	b.eq	0x3688 <generic_lsm_process_event+0x34b8>
    3644:      	cmp	w8, #0x3c
    3648:      	b.eq	0x365c <generic_lsm_process_event+0x348c>
    364c:      	cmp	w8, #0xff
    3650:      	b.ne	0x3748 <generic_lsm_process_event+0x3578>
    3654:      	mov	w8, #0x28               // =40
    3658:      	b	0x3694 <generic_lsm_process_event+0x34c4>
    365c:      	ldrb	w8, [x24, #0x7]
    3660:      	lsl	w8, w8, #3
    3664:      	b	0x3690 <generic_lsm_process_event+0x34c0>
    3668:      	ldrh	w8, [x24, #0x2]
    366c:      	ldrh	w9, [x24]
    3670:      	ldrb	w25, [x24, #0x6]
    3674:      	add	w8, w9, w8
    3678:      	cmp	w25, #0x3c
    367c:      	strh	w8, [x24]
    3680:      	b.ls	0x35d0 <generic_lsm_process_event+0x3400>
    3684:      	b	0x3a70 <generic_lsm_process_event+0x38a0>
    3688:      	ldrb	w8, [x24, #0x7]
    368c:      	lsl	w8, w8, #2
    3690:      	add	w8, w8, #0x8
    3694:      	strh	w8, [x24, #0x2]
    3698:      	ldrh	w9, [x24]
    369c:      	ldrb	w25, [x24, #0x6]
    36a0:      	add	w8, w9, w8
    36a4:      	cmp	w25, #0x3c
    36a8:      	strh	w8, [x24]
    36ac:      	b.hi	0x3a70 <generic_lsm_process_event+0x38a0>
    36b0:      	mov	x10, #0x1               // =1
    36b4:      	mov	w9, #0x1                // =1
    36b8:      	movk	x10, #0x1800, lsl #32
    36bc:      	lsl	x9, x9, x25
    36c0:      	movk	x10, #0x1008, lsl #48
    36c4:      	tst	x9, x10
    36c8:      	b.eq	0x3a70 <generic_lsm_process_event+0x38a0>
    36cc:      	strb	w25, [x24, #0x5]
    36d0:      	add	x8, x22, w8, uxth
    36d4:      	mov	w9, #0x2                // =2
    36d8:      	mov	w10, #0x4               // =4
    36dc:      	mov	x0, x23
    36e0:      	mov	w1, #0x2                // =2
    36e4:      	ldrh	w8, [x24]
    36e8:      	add	x2, x22, x8
    36ec:      	blr	x10
    36f0:      	tbnz	x0, #0x3f, 0x37d0 <generic_lsm_process_event+0x3600>
    36f4:      	ldrb	w8, [x24, #0x5]
    36f8:      	cmp	w8, #0x32
    36fc:      	b.gt	0x371c <generic_lsm_process_event+0x354c>
    3700:      	cbz	w8, 0x373c <generic_lsm_process_event+0x356c>
    3704:      	cmp	w8, #0x2b
    3708:      	b.eq	0x373c <generic_lsm_process_event+0x356c>
    370c:      	cmp	w8, #0x2c
    3710:      	b.ne	0x3a54 <generic_lsm_process_event+0x3884>
    3714:      	mov	w8, #0x8                // =8
    3718:      	b	0x3774 <generic_lsm_process_event+0x35a4>
    371c:      	cmp	w8, #0x33
    3720:      	b.eq	0x3768 <generic_lsm_process_event+0x3598>
    3724:      	cmp	w8, #0x3c
    3728:      	b.eq	0x373c <generic_lsm_process_event+0x356c>
    372c:      	cmp	w8, #0xff
    3730:      	b.ne	0x3a54 <generic_lsm_process_event+0x3884>
    3734:      	mov	w8, #0x28               // =40
    3738:      	b	0x3774 <generic_lsm_process_event+0x35a4>
    373c:      	ldrb	w8, [x24, #0x7]
    3740:      	lsl	w8, w8, #3
    3744:      	b	0x3770 <generic_lsm_process_event+0x35a0>
    3748:      	ldrh	w8, [x24, #0x2]
    374c:      	ldrh	w9, [x24]
    3750:      	ldrb	w25, [x24, #0x6]
    3754:      	add	w8, w9, w8
    3758:      	cmp	w25, #0x3c
    375c:      	strh	w8, [x24]
    3760:      	b.ls	0x36b0 <generic_lsm_process_event+0x34e0>
    3764:      	b	0x3a70 <generic_lsm_process_event+0x38a0>
    3768:      	ldrb	w8, [x24, #0x7]
    376c:      	lsl	w8, w8, #2
    3770:      	add	w8, w8, #0x8
    3774:      	strh	w8, [x24, #0x2]
    3778:      	ldrh	w9, [x24]
    377c:      	ldrb	w25, [x24, #0x6]
    3780:      	add	w8, w9, w8
    3784:      	cmp	w25, #0x3c
    3788:      	strh	w8, [x24]
    378c:      	b.hi	0x3a70 <generic_lsm_process_event+0x38a0>
    3790:      	mov	x10, #0x1               // =1
    3794:      	mov	w9, #0x1                // =1
    3798:      	movk	x10, #0x1800, lsl #32
    379c:      	lsl	x9, x9, x25
    37a0:      	movk	x10, #0x1008, lsl #48
    37a4:      	tst	x9, x10
    37a8:      	b.eq	0x3a70 <generic_lsm_process_event+0x38a0>
    37ac:      	strb	w25, [x24, #0x5]
    37b0:      	add	x8, x22, w8, uxth
    37b4:      	mov	w9, #0x2                // =2
    37b8:      	mov	w10, #0x4               // =4
    37bc:      	mov	x0, x23
    37c0:      	mov	w1, #0x2                // =2
    37c4:      	ldrh	w8, [x24]
    37c8:      	add	x2, x22, x8
    37cc:      	blr	x10
    37d0:      	mov	w25, wzr
    37d4:      	ldr	x22, [sp, #0x18]
    37d8:      	mov	w8, #0xa                // =10
    37dc:      	strb	w25, [sp, #0x78]
    37e0:      	add	x2, x29, #0x8
    37e4:      	mov	w23, #0x10              // =16
    37e8:      	mov	w1, #0x10               // =16
    37ec:      	mov	w24, #0x4               // =4
    37f0:      	strh	w25, [x22, #0x24]
    37f4:      	strh	w8, [x22, #0x26]
    37f8:      	mov	w8, #0x4                // =4
    37fc:      	mov	x0, x22
    3800:      	blr	x8
    3804:      	add	x0, x22, #0x10
    3808:      	add	x2, x29, #0x18
    380c:      	mov	w1, #0x10               // =16
    3810:      	blr	x24
    3814:      	cmp	w25, #0x11
    3818:      	b.eq	0x385c <generic_lsm_process_event+0x368c>
    381c:      	cmp	w25, #0x6
    3820:      	b.ne	0x389c <generic_lsm_process_event+0x36cc>
    3824:      	ldr	x8, [sp, #0x88]
    3828:      	ldrh	w9, [sp, #0xc8]
    382c:      	mov	w24, #0x2               // =2
    3830:      	mov	w1, #0x2                // =2
    3834:      	mov	w25, #0x4               // =4
    3838:      	add	x23, x8, x9
    383c:      	ldr	x22, [sp, #0x18]
    3840:      	add	x0, x22, #0x20
    3844:      	mov	w8, #0x4                // =4
    3848:      	mov	x2, x23
    384c:      	blr	x8
    3850:      	add	x0, x22, #0x22
    3854:      	add	x2, x23, #0x2
    3858:      	b	0x3890 <generic_lsm_process_event+0x36c0>
    385c:      	ldr	x8, [sp, #0x88]
    3860:      	ldrh	w9, [sp, #0xc8]
    3864:      	mov	w24, #0x2               // =2
    3868:      	mov	w1, #0x2                // =2
    386c:      	mov	w25, #0x4               // =4
    3870:      	add	x23, x8, x9
    3874:      	ldr	x22, [sp, #0x18]
    3878:      	add	x0, x22, #0x20
    387c:      	mov	w8, #0x4                // =4
    3880:      	mov	x2, x23
    3884:      	blr	x8
    3888:      	add	x0, x22, #0x22
    388c:      	add	x2, x23, #0x2
    3890:      	mov	w1, #0x2                // =2
    3894:      	blr	x25
    3898:      	b	0x38a4 <generic_lsm_process_event+0x36d4>
    389c:      	ldr	x8, [sp, #0x18]
    38a0:      	str	wzr, [x8, #0x20]
    38a4:      	ldr	x9, [sp, #0x18]
    38a8:      	add	x2, x21, #0xe0
    38ac:      	add	x10, sp, #0xe0
    38b0:      	add	x0, sp, #0xe0
    38b4:      	ldrh	w8, [x9, #0x20]
    38b8:      	mov	w1, #0x8                // =8
    38bc:      	rev	w8, w8
    38c0:      	lsr	w8, w8, #16
    38c4:      	strh	w8, [x9, #0x20]
    38c8:      	ldrh	w8, [x9, #0x22]
    38cc:      	rev	w8, w8
    38d0:      	lsr	w8, w8, #16
    38d4:      	strh	w8, [x9, #0x22]
    38d8:      	mov	w8, #0x8                // =8
    38dc:      	mov	w9, #0x4                // =4
    38e0:      	blr	x9
    38e4:      	add	x8, sp, #0xd0
    38e8:      	ldr	x8, [x8, #0x10]
    38ec:      	cbz	x8, 0x3950 <generic_lsm_process_event+0x3780>
    38f0:      	add	x8, x8, #0x5
    38f4:      	mov	w9, #0x8                // =8
    38f8:      	add	x10, sp, #0x60
    38fc:      	mov	w11, #0x4               // =4
    3900:      	add	x22, sp, #0xd0
    3904:      	ldr	x8, [x22, #0x10]
    3908:      	add	x0, sp, #0x60
    390c:      	mov	w1, #0x8                // =8
    3910:      	mov	w21, #0x4               // =4
    3914:      	add	x2, x8, #0x5
    3918:      	blr	x11
    391c:      	ldr	x8, [x22, #0x10]
    3920:      	ldr	x9, [sp, #0x60]
    3924:      	mov	w1, #0x4                // =4
    3928:      	add	x23, x8, x9, lsl #3
    392c:      	ldr	x22, [sp, #0x18]
    3930:      	add	x0, x22, #0x38
    3934:      	mov	w8, #0x4                // =4
    3938:      	add	x2, x23, #0x44
    393c:      	blr	x8
    3940:      	add	x0, x22, #0x3c
    3944:      	add	x2, x23, #0x45
    3948:      	mov	w1, #0x4                // =4
    394c:      	blr	x21
    3950:      	mov	w25, #0x40              // =64
    3954:      	adrp	x29, 0x3000 <generic_lsm_process_event+0x2e30>
    3958:      	ldr	x29, [x29]
    395c:      	ldr	x12, [sp, #0x28]
    3960:      	ldr	x10, [sp, #0x20]
    3964:      	mov	w9, #0x5ea0             // =24224
    3968:      	tbnz	w25, #0x1f, 0x3a40 <generic_lsm_process_event+0x3870>
    396c:      	and	x8, x25, #0x7fffffff
    3970:      	add	x8, x8, #0x4
    3974:      	ldr	x25, [sp, #0x40]
    3978:      	mov	w22, #0x5efc            // =24316
    397c:      	adrp	x21, 0x3000 <generic_lsm_process_event+0x2e30>
    3980:      	ldr	x21, [x21]
    3984:      	ldr	x24, [sp, #0xf8]
    3988:      	add	w24, w24, w8
    398c:      	cmp	w25, #0x3
    3990:      	str	w24, [x20, #0x4]
    3994:      	b.gt	0x3a04 <generic_lsm_process_event+0x3834>
    3998:      	str	wzr, [sp, #0x88]
    399c:      	mov	w8, #0x1                // =1
    39a0:      	add	x9, sp, #0x88
    39a4:      	add	x1, sp, #0x88
    39a8:      	mov	x0, x21
    39ac:      	blr	x8
    39b0:      	cbz	x0, 0x3a04 <generic_lsm_process_event+0x3834>
    39b4:      	mov	w8, #0x5ef8             // =24312
    39b8:      	add	x1, x0, x8
    39bc:      	adrp	x0, 0x3000 <generic_lsm_process_event+0x2e30>
    39c0:      	mov	w8, #0x1                // =1
    39c4:      	ldr	x0, [x0]
    39c8:      	blr	x8
    39cc:      	cbz	x0, 0x3a04 <generic_lsm_process_event+0x3834>
    39d0:      	add	w8, w25, #0x1
    39d4:      	and	w9, w8, #0x7
    39d8:      	add	x9, x0, w9, uxtw #2
    39dc:      	ldr	w9, [x9, #0x40]
    39e0:      	cmn	w9, #0x1
    39e4:      	b.eq	0x3a04 <generic_lsm_process_event+0x3834>
    39e8:      	str	w8, [x20, x22]
    39ec:      	mov	w8, #0x1                // =1
    39f0:      	mov	w9, #0xc                // =12
    39f4:      	mov	x0, x19
    39f8:      	mov	x1, x29
    39fc:      	mov	w2, #0x1                // =1
    3a00:      	blr	x9
    3a04:      	str	wzr, [x20, x22]
    3a08:      	mov	w8, #0x3                // =3
    3a0c:      	mov	w9, #0xc                // =12
    3a10:      	mov	x0, x19
    3a14:      	mov	x1, x29
    3a18:      	mov	w2, #0x3                // =3
    3a1c:      	blr	x9
    3a20:      	ldp	x20, x19, [sp, #0x130]
    3a24:      	mov	w0, wzr
    3a28:      	ldr	x29, [sp, #0xf0]
    3a2c:      	ldp	x22, x21, [sp, #0x120]
    3a30:      	ldp	x24, x23, [sp, #0x110]
    3a34:      	ldp	x30, x25, [sp, #0x100]
    3a38:      	add	sp, sp, #0x140
    3a3c:      	ret
    3a40:      	mov	w8, #-0x1               // =-1
    3a44:      	str	w8, [x12, x9]
    3a48:      	ldr	x9, [sp, #0xf8]
    3a4c:      	str	w8, [x10, x9]
    3a50:      	b	0xdd0 <generic_lsm_process_event+0xc00>
    3a54:      	ldrh	w8, [x24, #0x2]
    3a58:      	ldrh	w9, [x24]
    3a5c:      	ldrb	w25, [x24, #0x6]
    3a60:      	add	w8, w9, w8
    3a64:      	cmp	w25, #0x3c
    3a68:      	strh	w8, [x24]
    3a6c:      	b.ls	0x3790 <generic_lsm_process_event+0x35c0>
    3a70:      	strh	w8, [sp, #0xc8]
    3a74:      	b	0x37d4 <generic_lsm_process_event+0x3604>
    3a78:      	nop
    3a7c:      	nop

0000000000003a80 <generic_lsm_process_filter>:
    3a80:      	sub	sp, sp, #0x130
    3a84:      	str	x29, [sp, #0xe0]
    3a88:      	stp	x30, x25, [sp, #0xf0]
    3a8c:      	stp	x24, x23, [sp, #0x100]
    3a90:      	stp	x22, x21, [sp, #0x110]
    3a94:      	stp	x20, x19, [sp, #0x120]
    3a98:      	mov	x20, x0
    3a9c:      	str	wzr, [sp, #0x54]
    3aa0:      	adrp	x0, 0x3000 <generic_lsm_process_event+0x2e30>
    3aa4:      	mov	w8, #0x1                // =1
    3aa8:      	ldr	x0, [x0]
    3aac:      	add	x9, sp, #0x54
    3ab0:      	add	x1, sp, #0x54
    3ab4:      	blr	x8
    3ab8:      	cbz	x0, 0x5dac <generic_lsm_process_filter+0x232c>
    3abc:      	mov	w8, #0x5ec0             // =24256
    3ac0:      	mov	x22, x0
    3ac4:      	add	x29, x0, x8
    3ac8:      	mov	w8, #0x23               // =35
    3acc:      	blr	x8
    3ad0:      	str	x0, [sp, #0x58]
    3ad4:      	add	x8, x0, #0x8d4
    3ad8:      	mov	w9, #0x4                // =4
    3adc:      	mov	w10, #0x71              // =113
    3ae0:      	add	x11, sp, #0xd8
    3ae4:      	add	x0, sp, #0xd8
    3ae8:      	mov	w1, #0x4                // =4
    3aec:      	ldr	x8, [sp, #0x58]
    3af0:      	add	x2, x8, #0x8d4
    3af4:      	blr	x10
    3af8:      	ldr	w8, [sp, #0xd8]
    3afc:      	adrp	x19, 0x3000 <generic_lsm_process_event+0x2e30>
    3b00:      	add	x9, sp, #0xc8
    3b04:      	add	x1, sp, #0xc8
    3b08:      	str	w8, [sp, #0xc8]
    3b0c:      	mov	w8, #0x1                // =1
    3b10:      	ldr	x19, [x19]
    3b14:      	mov	x0, x19
    3b18:      	blr	x8
    3b1c:      	cbz	x0, 0x3b2c <generic_lsm_process_filter+0xac>
    3b20:      	ldr	x8, [x0, #0x8]
    3b24:      	mov	x24, x0
    3b28:      	cbnz	x8, 0x490c <generic_lsm_process_filter+0xe8c>
    3b2c:      	ldr	x8, [sp, #0x58]
    3b30:      	mov	w9, #0x8                // =8
    3b34:      	mov	w10, #0x71              // =113
    3b38:      	add	x11, sp, #0x58
    3b3c:      	add	x0, sp, #0x58
    3b40:      	mov	w1, #0x8                // =8
    3b44:      	add	x8, x8, #0x8e0
    3b48:      	ldr	x8, [sp, #0x58]
    3b4c:      	add	x2, x8, #0x8e0
    3b50:      	blr	x10
    3b54:      	ldr	x8, [sp, #0x58]
    3b58:      	cbz	x8, 0x3cd4 <generic_lsm_process_filter+0x254>
    3b5c:      	add	x8, x8, #0x8d4
    3b60:      	mov	w9, #0x4                // =4
    3b64:      	mov	w10, #0x71              // =113
    3b68:      	add	x11, sp, #0xd8
    3b6c:      	ldr	x8, [sp, #0x58]
    3b70:      	add	x0, sp, #0xd8
    3b74:      	mov	w1, #0x4                // =4
    3b78:      	add	x2, x8, #0x8d4
    3b7c:      	blr	x10
    3b80:      	ldr	w8, [sp, #0xd8]
    3b84:      	add	x9, sp, #0xc8
    3b88:      	add	x1, sp, #0xc8
    3b8c:      	mov	x0, x19
    3b90:      	str	w8, [sp, #0xc8]
    3b94:      	mov	w8, #0x1                // =1
    3b98:      	blr	x8
    3b9c:      	cbz	x0, 0x3bac <generic_lsm_process_filter+0x12c>
    3ba0:      	ldr	x8, [x0, #0x8]
    3ba4:      	mov	x24, x0
    3ba8:      	cbnz	x8, 0x490c <generic_lsm_process_filter+0xe8c>
    3bac:      	ldr	x8, [sp, #0x58]
    3bb0:      	mov	w9, #0x8                // =8
    3bb4:      	mov	w10, #0x71              // =113
    3bb8:      	add	x11, sp, #0x58
    3bbc:      	add	x0, sp, #0x58
    3bc0:      	mov	w1, #0x8                // =8
    3bc4:      	add	x8, x8, #0x8e0
    3bc8:      	ldr	x8, [sp, #0x58]
    3bcc:      	add	x2, x8, #0x8e0
    3bd0:      	blr	x10
    3bd4:      	ldr	x8, [sp, #0x58]
    3bd8:      	cbz	x8, 0x3cd4 <generic_lsm_process_filter+0x254>
    3bdc:      	add	x8, x8, #0x8d4
    3be0:      	mov	w9, #0x4                // =4
    3be4:      	mov	w10, #0x71              // =113
    3be8:      	add	x11, sp, #0xd8
    3bec:      	ldr	x8, [sp, #0x58]
    3bf0:      	add	x0, sp, #0xd8
    3bf4:      	mov	w1, #0x4                // =4
    3bf8:      	add	x2, x8, #0x8d4
    3bfc:      	blr	x10
    3c00:      	ldr	w8, [sp, #0xd8]
    3c04:      	add	x9, sp, #0xc8
    3c08:      	add	x1, sp, #0xc8
    3c0c:      	mov	x0, x19
    3c10:      	str	w8, [sp, #0xc8]
    3c14:      	mov	w8, #0x1                // =1
    3c18:      	blr	x8
    3c1c:      	cbz	x0, 0x3c2c <generic_lsm_process_filter+0x1ac>
    3c20:      	ldr	x8, [x0, #0x8]
    3c24:      	mov	x24, x0
    3c28:      	cbnz	x8, 0x490c <generic_lsm_process_filter+0xe8c>
    3c2c:      	ldr	x8, [sp, #0x58]
    3c30:      	mov	w9, #0x8                // =8
    3c34:      	mov	w10, #0x71              // =113
    3c38:      	add	x11, sp, #0x58
    3c3c:      	add	x0, sp, #0x58
    3c40:      	mov	w1, #0x8                // =8
    3c44:      	add	x8, x8, #0x8e0
    3c48:      	ldr	x8, [sp, #0x58]
    3c4c:      	add	x2, x8, #0x8e0
    3c50:      	blr	x10
    3c54:      	ldr	x8, [sp, #0x58]
    3c58:      	cbz	x8, 0x3cd4 <generic_lsm_process_filter+0x254>
    3c5c:      	add	x8, x8, #0x8d4
    3c60:      	mov	w9, #0x4                // =4
    3c64:      	mov	w10, #0x71              // =113
    3c68:      	add	x11, sp, #0xd8
    3c6c:      	ldr	x8, [sp, #0x58]
    3c70:      	add	x0, sp, #0xd8
    3c74:      	mov	w1, #0x4                // =4
    3c78:      	add	x2, x8, #0x8d4
    3c7c:      	blr	x10
    3c80:      	ldr	w8, [sp, #0xd8]
    3c84:      	add	x9, sp, #0xc8
    3c88:      	add	x1, sp, #0xc8
    3c8c:      	mov	x0, x19
    3c90:      	str	w8, [sp, #0xc8]
    3c94:      	mov	w8, #0x1                // =1
    3c98:      	blr	x8
    3c9c:      	cbz	x0, 0x3cac <generic_lsm_process_filter+0x22c>
    3ca0:      	ldr	x8, [x0, #0x8]
    3ca4:      	mov	x24, x0
    3ca8:      	cbnz	x8, 0x490c <generic_lsm_process_filter+0xe8c>
    3cac:      	ldr	x8, [sp, #0x58]
    3cb0:      	mov	w9, #0x8                // =8
    3cb4:      	mov	w10, #0x71              // =113
    3cb8:      	add	x11, sp, #0x58
    3cbc:      	add	x0, sp, #0x58
    3cc0:      	mov	w1, #0x8                // =8
    3cc4:      	add	x8, x8, #0x8e0
    3cc8:      	ldr	x8, [sp, #0x58]
    3ccc:      	add	x2, x8, #0x8e0
    3cd0:      	blr	x10
    3cd4:      	str	x20, [sp, #0x38]
    3cd8:      	mov	w8, #0x23               // =35
    3cdc:      	blr	x8
    3ce0:      	add	x2, x0, #0x8d4
    3ce4:      	mov	w8, #0x4                // =4
    3ce8:      	add	x9, sp, #0x58
    3cec:      	mov	x24, x0
    3cf0:      	add	x0, sp, #0x58
    3cf4:      	mov	w1, #0x4                // =4
    3cf8:      	blr	x8
    3cfc:      	ldr	w8, [sp, #0x58]
    3d00:      	mov	x19, x29
    3d04:      	str	w8, [x19, #0x50]!
    3d08:      	mov	w8, #0x7d               // =125
    3d0c:      	blr	x8
    3d10:      	str	x0, [x22, #0x5f18]
    3d14:      	str	wzr, [x19, #0x10]
    3d18:      	add	x2, x24, #0x60
    3d1c:      	mov	w8, #0x8                // =8
    3d20:      	mov	w9, #0x71               // =113
    3d24:      	add	x10, sp, #0xc8
    3d28:      	str	xzr, [x22, #0x5f28]
    3d2c:      	str	x19, [sp, #0x48]
    3d30:      	add	x0, sp, #0xc8
    3d34:      	mov	w1, #0x8                // =8
    3d38:      	str	wzr, [x19, #0x20]
    3d3c:      	blr	x9
    3d40:      	ldr	x8, [sp, #0xc8]
    3d44:      	cbz	x8, 0x3db4 <generic_lsm_process_filter+0x334>
    3d48:      	add	x8, x8, #0x4
    3d4c:      	mov	w9, #0x4                // =4
    3d50:      	mov	w10, #0x71              // =113
    3d54:      	add	x11, sp, #0xd8
    3d58:      	ldr	x8, [sp, #0xc8]
    3d5c:      	add	x0, sp, #0xd8
    3d60:      	mov	w1, #0x4                // =4
    3d64:      	add	x2, x8, #0x4
    3d68:      	blr	x10
    3d6c:      	ldr	w8, [sp, #0xd8]
    3d70:      	cbz	w8, 0x3db4 <generic_lsm_process_filter+0x334>
    3d74:      	ldr	x9, [sp, #0xc8]
    3d78:      	lsl	w8, w8, #4
    3d7c:      	mov	w10, #0x71              // =113
    3d80:      	add	x11, sp, #0x58
    3d84:      	add	x0, sp, #0x58
    3d88:      	mov	w1, #0x10               // =16
    3d8c:      	add	x8, x9, x8
    3d90:      	mov	w9, #0x10               // =16
    3d94:      	add	x8, x8, #0x80
    3d98:      	ldr	w9, [sp, #0xd8]
    3d9c:      	ldr	x8, [sp, #0xc8]
    3da0:      	lsl	w9, w9, #4
    3da4:      	add	x8, x8, x9
    3da8:      	add	x2, x8, #0x80
    3dac:      	blr	x10
    3db0:      	ldr	w8, [sp, #0x58]
    3db4:      	str	w8, [x29, #0x74]
    3db8:      	mov	w8, #0x5f60             // =24416
    3dbc:      	str	x22, [sp, #0xe8]
    3dc0:      	add	x23, x24, #0xae0
    3dc4:      	mov	w19, #0x8               // =8
    3dc8:      	add	x25, x22, x8
    3dcc:      	add	x8, sp, #0x58
    3dd0:      	mov	w9, #0x4                // =4
    3dd4:      	add	x0, sp, #0x58
    3dd8:      	mov	w1, #0x8                // =8
    3ddc:      	mov	x2, x23
    3de0:      	mov	w21, #0x4               // =4
    3de4:      	blr	x9
    3de8:      	ldr	x20, [sp, #0x58]
    3dec:      	ldr	x9, [sp, #0xe8]
    3df0:      	mov	w8, #0x5f68             // =24424
    3df4:      	mov	w1, #0x8                // =8
    3df8:      	add	x0, x9, x8
    3dfc:      	add	x2, x20, #0x40
    3e00:      	mov	w8, #0x4                // =4
    3e04:      	blr	x8
    3e08:      	ldr	x9, [sp, #0xe8]
    3e0c:      	mov	w8, #0x5f70             // =24432
    3e10:      	add	x2, x20, #0x30
    3e14:      	mov	w1, #0x8                // =8
    3e18:      	add	x0, x9, x8
    3e1c:      	mov	w8, #0x4                // =4
    3e20:      	blr	x8
    3e24:      	add	x2, x20, #0x38
    3e28:      	mov	w8, #0x4                // =4
    3e2c:      	mov	x0, x25
    3e30:      	mov	w1, #0x8                // =8
    3e34:      	blr	x8
    3e38:      	ldr	x9, [sp, #0xe8]
    3e3c:      	mov	w8, #0x5f38             // =24376
    3e40:      	add	x2, x24, #0xb50
    3e44:      	add	x0, sp, #0xd8
    3e48:      	mov	w1, #0x8                // =8
    3e4c:      	add	x25, x9, x8
    3e50:      	add	x8, sp, #0xd8
    3e54:      	mov	w9, #0x4                // =4
    3e58:      	blr	x9
    3e5c:      	add	x12, sp, #0xd8
    3e60:      	mov	w9, #0x48               // =72
    3e64:      	add	x10, sp, #0x58
    3e68:      	ldr	x8, [x12]
    3e6c:      	mov	w11, #0x4               // =4
    3e70:      	add	x0, sp, #0x58
    3e74:      	mov	w1, #0x48               // =72
    3e78:      	ldr	x2, [x12]
    3e7c:      	blr	x11
    3e80:      	ldr	x8, [sp, #0x60]
    3e84:      	mov	w9, #0x4                // =4
    3e88:      	mov	x0, x25
    3e8c:      	mov	w1, #0x4                // =4
    3e90:      	add	x8, x8, #0x218
    3e94:      	ldr	x8, [sp, #0x60]
    3e98:      	ldr	x22, [sp, #0xe8]
    3e9c:      	add	x2, x8, #0x218
    3ea0:      	blr	x9
    3ea4:      	mov	w8, #0x5f3c             // =24380
    3ea8:      	mov	w9, #0x4                // =4
    3eac:      	mov	w1, #0x4                // =4
    3eb0:      	add	x0, x22, x8
    3eb4:      	ldr	x8, [sp, #0x68]
    3eb8:      	add	x8, x8, #0x4d8
    3ebc:      	ldr	x8, [sp, #0x68]
    3ec0:      	add	x2, x8, #0x4d8
    3ec4:      	blr	x9
    3ec8:      	mov	w8, #0x5f40             // =24384
    3ecc:      	mov	w9, #0x4                // =4
    3ed0:      	mov	w1, #0x4                // =4
    3ed4:      	add	x0, x22, x8
    3ed8:      	ldr	x8, [sp, #0x70]
    3edc:      	add	x8, x8, #0x58
    3ee0:      	ldr	x8, [sp, #0x70]
    3ee4:      	add	x2, x8, #0x58
    3ee8:      	blr	x9
    3eec:      	str	xzr, [sp, #0xc0]
    3ef0:      	add	x2, x24, #0x938
    3ef4:      	add	x8, sp, #0xc0
    3ef8:      	add	x0, sp, #0xc0
    3efc:      	mov	w1, #0x8                // =8
    3f00:      	blr	x21
    3f04:      	ldr	x8, [sp, #0xc0]
    3f08:      	cbz	x8, 0x3f90 <generic_lsm_process_filter+0x510>
    3f0c:      	str	wzr, [sp, #0xb8]
    3f10:      	add	x8, x8, #0x4
    3f14:      	add	x9, sp, #0xb8
    3f18:      	mov	w10, #0x4               // =4
    3f1c:      	add	x0, sp, #0xb8
    3f20:      	mov	w1, #0x4                // =4
    3f24:      	mov	w19, #0x4               // =4
    3f28:      	ldr	x8, [sp, #0xc0]
    3f2c:      	add	x2, x8, #0x4
    3f30:      	blr	x10
    3f34:      	ldr	x8, [sp, #0xc0]
    3f38:      	ldrsw	x9, [sp, #0xb8]
    3f3c:      	add	x10, sp, #0xc8
    3f40:      	mov	w11, #0x4               // =4
    3f44:      	add	x0, sp, #0xc8
    3f48:      	mov	w1, #0x10               // =16
    3f4c:      	add	x8, x8, x9, lsl #4
    3f50:      	mov	w9, #0x10               // =16
    3f54:      	add	x8, x8, #0x80
    3f58:      	ldr	x8, [sp, #0xc0]
    3f5c:      	ldrsw	x9, [sp, #0xb8]
    3f60:      	add	x8, x8, x9, lsl #4
    3f64:      	add	x2, x8, #0x80
    3f68:      	blr	x11
    3f6c:      	mov	w8, #0x5f44             // =24388
    3f70:      	mov	w1, #0x4                // =4
    3f74:      	add	x0, x22, x8
    3f78:      	ldr	x8, [sp, #0xd0]
    3f7c:      	add	x8, x8, #0x158
    3f80:      	ldr	x8, [sp, #0xd0]
    3f84:      	add	x2, x8, #0x158
    3f88:      	blr	x19
    3f8c:      	b	0x3f94 <generic_lsm_process_filter+0x514>
    3f90:      	str	wzr, [x29, #0x84]
    3f94:      	mov	w8, #0x5f48             // =24392
    3f98:      	mov	w9, #0x4                // =4
    3f9c:      	mov	w1, #0x4                // =4
    3fa0:      	mov	w19, #0x4               // =4
    3fa4:      	add	x0, x22, x8
    3fa8:      	ldr	x8, [sp, #0x78]
    3fac:      	add	x8, x8, #0x158
    3fb0:      	ldr	x8, [sp, #0x78]
    3fb4:      	add	x2, x8, #0x158
    3fb8:      	blr	x9
    3fbc:      	mov	w8, #0x5f4c             // =24396
    3fc0:      	mov	w9, #0x4                // =4
    3fc4:      	mov	w1, #0x4                // =4
    3fc8:      	add	x0, x22, x8
    3fcc:      	ldr	x8, [sp, #0x80]
    3fd0:      	add	x8, x8, #0x118
    3fd4:      	ldr	x8, [sp, #0x80]
    3fd8:      	add	x2, x8, #0x118
    3fdc:      	blr	x9
    3fe0:      	mov	w8, #0x5f50             // =24400
    3fe4:      	mov	w9, #0x4                // =4
    3fe8:      	mov	w1, #0x4                // =4
    3fec:      	add	x0, x22, x8
    3ff0:      	ldr	x8, [sp, #0x88]
    3ff4:      	add	x8, x8, #0x98
    3ff8:      	ldr	x8, [sp, #0x88]
    3ffc:      	add	x2, x8, #0x98
    4000:      	blr	x9
    4004:      	mov	w8, #0x5f54             // =24404
    4008:      	mov	w9, #0x4                // =4
    400c:      	mov	w1, #0x4                // =4
    4010:      	add	x0, x22, x8
    4014:      	ldr	x8, [sp, #0x90]
    4018:      	add	x8, x8, #0x98
    401c:      	ldr	x8, [sp, #0x90]
    4020:      	add	x2, x8, #0x98
    4024:      	blr	x9
    4028:      	mov	w8, #0x5f58             // =24408
    402c:      	mov	w9, #0x4                // =4
    4030:      	mov	w1, #0x4                // =4
    4034:      	add	x0, x22, x8
    4038:      	ldr	x8, [sp, #0x98]
    403c:      	add	x8, x8, #0x58
    4040:      	ldr	x8, [sp, #0x98]
    4044:      	add	x2, x8, #0x58
    4048:      	blr	x9
    404c:      	stp	xzr, xzr, [sp, #0xc0]
    4050:      	mov	w20, #0x8               // =8
    4054:      	add	x8, sp, #0xc8
    4058:      	mov	w9, #0x4                // =4
    405c:      	add	x0, sp, #0xc8
    4060:      	mov	w1, #0x8                // =8
    4064:      	mov	x2, x23
    4068:      	blr	x9
    406c:      	ldr	x8, [sp, #0xc8]
    4070:      	add	x9, sp, #0xc0
    4074:      	mov	w10, #0x4               // =4
    4078:      	add	x0, sp, #0xc0
    407c:      	mov	w1, #0x8                // =8
    4080:      	add	x8, x8, #0x90
    4084:      	ldr	x8, [sp, #0xc8]
    4088:      	add	x2, x8, #0x90
    408c:      	blr	x10
    4090:      	mov	w8, #0x5f5c             // =24412
    4094:      	mov	w1, #0x4                // =4
    4098:      	add	x0, x22, x8
    409c:      	ldr	x8, [sp, #0xc0]
    40a0:      	add	x8, x8, #0x158
    40a4:      	ldr	x8, [sp, #0xc0]
    40a8:      	add	x2, x8, #0x158
    40ac:      	blr	x19
    40b0:      	ldr	w8, [x29, #0x74]
    40b4:      	cmp	w8, #0x1
    40b8:      	b.ne	0x40c8 <generic_lsm_process_filter+0x648>
    40bc:      	ldr	w8, [x29, #0x70]
    40c0:      	orr	w8, w8, #0x2000000
    40c4:      	str	w8, [x29, #0x70]
    40c8:      	add	x0, x29, #0xb8
    40cc:      	mov	w1, wzr
    40d0:      	mov	w2, #0x308              // =776
    40d4:      	bl	0x40d4 <generic_lsm_process_filter+0x654>
    40d8:      	mov	w8, #0x6290             // =25232
    40dc:      	add	x2, x24, #0x858
    40e0:      	mov	w19, #0x8               // =8
    40e4:      	mov	w9, #0x4                // =4
    40e8:      	add	x0, sp, #0xc8
    40ec:      	mov	w1, #0x8                // =8
    40f0:      	mov	w20, #0x4               // =4
    40f4:      	add	x21, x22, x8
    40f8:      	add	x8, sp, #0xc8
    40fc:      	blr	x9
    4100:      	ldr	x8, [sp, #0xc8]
    4104:      	add	x9, sp, #0x58
    4108:      	add	x0, sp, #0x58
    410c:      	mov	w1, #0x8                // =8
    4110:      	add	x8, x8, #0x528
    4114:      	ldr	x8, [sp, #0xc8]
    4118:      	add	x2, x8, #0x528
    411c:      	blr	x20
    4120:      	str	wzr, [sp, #0xa4]
    4124:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4128:      	ldr	x19, [sp, #0x58]
    412c:      	mov	w8, #0x1                // =1
    4130:      	add	x9, sp, #0xa4
    4134:      	add	x1, sp, #0xa4
    4138:      	ldr	x0, [x0]
    413c:      	blr	x8
    4140:      	cbz	x0, 0x4754 <generic_lsm_process_filter+0xcd4>
    4144:      	mov	w8, #0x1000             // =4096
    4148:      	str	x21, [sp, #0x30]
    414c:      	str	x29, [sp, #0x40]
    4150:      	mov	x24, x0
    4154:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    4158:      	str	w8, [x29, #0x550]
    415c:      	mov	w8, #0x23               // =35
    4160:      	blr	x8
    4164:      	add	x2, x0, #0xb30
    4168:      	mov	w23, #0x8               // =8
    416c:      	add	x8, sp, #0xa8
    4170:      	mov	w9, #0x4                // =4
    4174:      	add	x0, sp, #0xa8
    4178:      	mov	w1, #0x8                // =8
    417c:      	mov	w29, #0x4               // =4
    4180:      	blr	x9
    4184:      	ldr	x22, [sp, #0xa8]
    4188:      	add	x25, x19, #0x48
    418c:      	add	x8, sp, #0xb0
    4190:      	mov	w9, #0x4                // =4
    4194:      	add	x0, sp, #0xb0
    4198:      	mov	w1, #0x8                // =8
    419c:      	mov	x2, x25
    41a0:      	blr	x9
    41a4:      	ldr	x21, [sp, #0xb0]
    41a8:      	add	x8, sp, #0x58
    41ac:      	add	x0, sp, #0x58
    41b0:      	mov	w1, #0x8                // =8
    41b4:      	add	x2, x21, #0x10
    41b8:      	blr	x29
    41bc:      	ldr	x8, [sp, #0x58]
    41c0:      	cbz	x8, 0x43f4 <generic_lsm_process_filter+0x974>
    41c4:      	ldr	x8, [sp, #0x40]
    41c8:      	stp	xzr, xzr, [sp, #0x58]
    41cc:      	add	x21, x22, #0x18
    41d0:      	add	x9, sp, #0x58
    41d4:      	add	x2, x22, #0x20
    41d8:      	mov	w22, #0x8               // =8
    41dc:      	stp	x24, xzr, [sp, #0x68]
    41e0:      	add	x0, sp, #0x58
    41e4:      	mov	w1, #0x8                // =8
    41e8:      	add	x29, x19, #0x40
    41ec:      	add	x19, x9, #0x8
    41f0:      	add	x24, x9, #0x18
    41f4:      	stp	xzr, xzr, [sp, #0x78]
    41f8:      	add	x23, x9, #0x20
    41fc:      	str	x20, [sp, #0x88]
    4200:      	str	x20, [sp, #0x28]
    4204:      	mov	w20, #0x4               // =4
    4208:      	ldr	w8, [x8, #0x550]
    420c:      	strb	wzr, [sp, #0x94]
    4210:      	str	w8, [sp, #0x90]
    4214:      	mov	w8, #0x4                // =4
    4218:      	blr	x8
    421c:      	mov	w8, #0x4                // =4
    4220:      	mov	x0, x19
    4224:      	mov	w1, #0x8                // =8
    4228:      	mov	x2, x21
    422c:      	blr	x8
    4230:      	mov	w8, #0x4                // =4
    4234:      	mov	x0, x24
    4238:      	mov	w1, #0x8                // =8
    423c:      	mov	x2, x25
    4240:      	blr	x8
    4244:      	mov	x0, x23
    4248:      	mov	w1, #0x8                // =8
    424c:      	mov	x2, x29
    4250:      	blr	x20
    4254:      	ldr	x8, [sp, #0x78]
    4258:      	sub	x8, x8, #0x20
    425c:      	str	x8, [sp, #0x80]
    4260:      	adrp	x8, 0x4000 <generic_lsm_process_filter+0x580>
    4264:      	ldr	x8, [x8]
    4268:      	ldrb	w8, [x8]
    426c:      	cbz	w8, 0x4448 <generic_lsm_process_filter+0x9c8>
    4270:      	mov	w19, #0x80              // =128
    4274:      	mov	w21, #0x8               // =8
    4278:      	add	x23, sp, #0xb8
    427c:      	add	x29, sp, #0xd8
    4280:      	b	0x42d4 <generic_lsm_process_filter+0x854>
    4284:      	add	x2, x22, #0x10
    4288:      	mov	w8, #0x4                // =4
    428c:      	add	x0, sp, #0xd8
    4290:      	mov	w1, #0x8                // =8
    4294:      	blr	x8
    4298:      	add	x20, sp, #0xd8
    429c:      	ldr	x8, [sp, #0x80]
    42a0:      	ldr	x9, [x20]
    42a4:      	cmp	x8, x9
    42a8:      	b.eq	0x45d0 <generic_lsm_process_filter+0xb50>
    42ac:      	add	x2, x22, #0x18
    42b0:      	mov	w8, #0x4                // =4
    42b4:      	mov	x0, x24
    42b8:      	mov	w1, #0x8                // =8
    42bc:      	blr	x8
    42c0:      	ldr	x8, [x20]
    42c4:      	add	x9, x8, #0x20
    42c8:      	stp	x9, x8, [sp, #0x78]
    42cc:      	subs	w19, w19, #0x1
    42d0:      	b.eq	0x45d8 <generic_lsm_process_filter+0xb58>
    42d4:      	ldp	x20, x2, [sp, #0x70]
    42d8:      	ldp	x8, x9, [sp, #0x58]
    42dc:      	cmp	x20, x8
    42e0:      	ccmp	x2, x9, #0x0, eq
    42e4:      	b.eq	0x45d0 <generic_lsm_process_filter+0xb50>
    42e8:      	ldr	x22, [sp, #0x80]
    42ec:      	mov	w8, #0x4                // =4
    42f0:      	add	x0, sp, #0xb8
    42f4:      	mov	w1, #0x8                // =8
    42f8:      	blr	x8
    42fc:      	ldr	x8, [sp, #0xb8]
    4300:      	cmp	x20, x8
    4304:      	b.eq	0x4284 <generic_lsm_process_filter+0x804>
    4308:      	add	x25, x20, #0x18
    430c:      	mov	w8, #0x4                // =4
    4310:      	add	x0, sp, #0xd8
    4314:      	mov	w1, #0x8                // =8
    4318:      	mov	x2, x25
    431c:      	blr	x8
    4320:      	add	x8, sp, #0xd8
    4324:      	ldr	x8, [x8]
    4328:      	cmp	x8, x20
    432c:      	b.eq	0x4284 <generic_lsm_process_filter+0x804>
    4330:      	mov	w8, #0x4                // =4
    4334:      	add	x9, sp, #0xc0
    4338:      	add	x0, sp, #0xc0
    433c:      	mov	w1, #0x8                // =8
    4340:      	mov	x2, x25
    4344:      	blr	x8
    4348:      	add	x2, x20, #0x20
    434c:      	mov	w8, #0x4                // =4
    4350:      	mov	w9, #0x10               // =16
    4354:      	add	x10, sp, #0xc8
    4358:      	add	x0, sp, #0xc8
    435c:      	mov	w1, #0x10               // =16
    4360:      	blr	x8
    4364:      	ldr	w20, [sp, #0xcc]
    4368:      	ldr	x8, [sp, #0x68]
    436c:      	ldr	x10, [sp, #0x88]
    4370:      	sub	x12, x10, x8
    4374:      	ldr	w22, [sp, #0x90]
    4378:      	subs	w10, w20, w22
    437c:      	ldr	x9, [sp, #0xd0]
    4380:      	csel	w10, wzr, w10, lo
    4384:      	cmp	w22, w20
    4388:      	csel	w11, w22, w20, lo
    438c:      	cinc	w13, w11, hi
    4390:      	sub	w14, w22, w13
    4394:      	subs	x12, x12, x13
    4398:      	str	w14, [sp, #0x90]
    439c:      	b.lo	0x45d8 <generic_lsm_process_filter+0xb58>
    43a0:      	cmp	x12, #0xfff
    43a4:      	b.hi	0x45d8 <generic_lsm_process_filter+0xb58>
    43a8:      	cmp	w22, w20
    43ac:      	b.ls	0x43b8 <generic_lsm_process_filter+0x938>
    43b0:      	mov	w13, #0x2f              // =47
    43b4:      	strb	w13, [x8, x12]
    43b8:      	add	x25, x8, x12
    43bc:      	cmp	w22, w20
    43c0:      	add	x2, x9, x10
    43c4:      	and	w1, w11, #0xff
    43c8:      	mov	w8, #0x4                // =4
    43cc:      	cinc	x0, x25, hi
    43d0:      	blr	x8
    43d4:      	cmp	w22, w20
    43d8:      	str	x25, [sp, #0x88]
    43dc:      	b.ls	0x45d8 <generic_lsm_process_filter+0xb58>
    43e0:      	ldr	x8, [sp, #0xc0]
    43e4:      	str	x8, [sp, #0x70]
    43e8:      	subs	w19, w19, #0x1
    43ec:      	b.ne	0x42d4 <generic_lsm_process_filter+0x854>
    43f0:      	b	0x45d8 <generic_lsm_process_filter+0xb58>
    43f4:      	add	x2, x21, #0x18
    43f8:      	mov	w8, #0x8                // =8
    43fc:      	mov	w9, #0x4                // =4
    4400:      	add	x10, sp, #0x58
    4404:      	add	x0, sp, #0x58
    4408:      	mov	w1, #0x8                // =8
    440c:      	blr	x9
    4410:      	ldr	x8, [sp, #0x58]
    4414:      	cmp	x8, x21
    4418:      	b.eq	0x41c4 <generic_lsm_process_filter+0x744>
    441c:      	ldr	x29, [sp, #0x40]
    4420:      	ldr	w9, [x29, #0x550]
    4424:      	sub	w8, w9, #0xa
    4428:      	cmp	w9, #0x9
    442c:      	str	w8, [x29, #0x550]
    4430:      	b.gt	0x4b00 <generic_lsm_process_filter+0x1080>
    4434:      	ldr	x21, [sp, #0x30]
    4438:      	mov	w9, #-0x24              // =-36
    443c:      	mov	x24, x20
    4440:      	str	w9, [x29, #0x554]
    4444:      	b	0x463c <generic_lsm_process_filter+0xbbc>
    4448:      	mov	w19, #0x80              // =128
    444c:      	mov	w21, #0x8               // =8
    4450:      	add	x23, sp, #0xb8
    4454:      	add	x29, sp, #0xd8
    4458:      	b	0x44b0 <generic_lsm_process_filter+0xa30>
    445c:      	nop
    4460:      	add	x2, x22, #0x10
    4464:      	mov	w8, #0x4                // =4
    4468:      	add	x0, sp, #0xd8
    446c:      	mov	w1, #0x8                // =8
    4470:      	blr	x8
    4474:      	add	x20, sp, #0xd8
    4478:      	ldr	x8, [sp, #0x80]
    447c:      	ldr	x9, [x20]
    4480:      	cmp	x8, x9
    4484:      	b.eq	0x45d0 <generic_lsm_process_filter+0xb50>
    4488:      	add	x2, x22, #0x18
    448c:      	mov	w8, #0x4                // =4
    4490:      	mov	x0, x24
    4494:      	mov	w1, #0x8                // =8
    4498:      	blr	x8
    449c:      	ldr	x8, [x20]
    44a0:      	add	x9, x8, #0x20
    44a4:      	stp	x9, x8, [sp, #0x78]
    44a8:      	subs	w19, w19, #0x1
    44ac:      	b.eq	0x45d8 <generic_lsm_process_filter+0xb58>
    44b0:      	ldp	x20, x2, [sp, #0x70]
    44b4:      	ldp	x8, x9, [sp, #0x58]
    44b8:      	cmp	x20, x8
    44bc:      	ccmp	x2, x9, #0x0, eq
    44c0:      	b.eq	0x45d0 <generic_lsm_process_filter+0xb50>
    44c4:      	ldr	x22, [sp, #0x80]
    44c8:      	mov	w8, #0x4                // =4
    44cc:      	add	x0, sp, #0xb8
    44d0:      	mov	w1, #0x8                // =8
    44d4:      	blr	x8
    44d8:      	ldr	x8, [sp, #0xb8]
    44dc:      	cmp	x20, x8
    44e0:      	b.eq	0x4460 <generic_lsm_process_filter+0x9e0>
    44e4:      	add	x25, x20, #0x18
    44e8:      	mov	w8, #0x4                // =4
    44ec:      	add	x0, sp, #0xd8
    44f0:      	mov	w1, #0x8                // =8
    44f4:      	mov	x2, x25
    44f8:      	blr	x8
    44fc:      	add	x8, sp, #0xd8
    4500:      	ldr	x8, [x8]
    4504:      	cmp	x8, x20
    4508:      	b.eq	0x4460 <generic_lsm_process_filter+0x9e0>
    450c:      	mov	w8, #0x4                // =4
    4510:      	add	x9, sp, #0xc0
    4514:      	add	x0, sp, #0xc0
    4518:      	mov	w1, #0x8                // =8
    451c:      	mov	x2, x25
    4520:      	blr	x8
    4524:      	add	x2, x20, #0x20
    4528:      	mov	w8, #0x4                // =4
    452c:      	mov	w9, #0x10               // =16
    4530:      	add	x10, sp, #0xc8
    4534:      	add	x0, sp, #0xc8
    4538:      	mov	w1, #0x10               // =16
    453c:      	blr	x8
    4540:      	ldr	w20, [sp, #0xcc]
    4544:      	ldr	x8, [sp, #0x68]
    4548:      	ldr	x10, [sp, #0x88]
    454c:      	sub	x12, x10, x8
    4550:      	ldr	w22, [sp, #0x90]
    4554:      	subs	w10, w20, w22
    4558:      	ldr	x9, [sp, #0xd0]
    455c:      	csel	w10, wzr, w10, lo
    4560:      	cmp	w22, w20
    4564:      	csel	w11, w22, w20, lo
    4568:      	cinc	w13, w11, hi
    456c:      	sub	w14, w22, w13
    4570:      	subs	x12, x12, x13
    4574:      	str	w14, [sp, #0x90]
    4578:      	b.lo	0x45d8 <generic_lsm_process_filter+0xb58>
    457c:      	cmp	x12, #0xfff
    4580:      	b.hi	0x45d8 <generic_lsm_process_filter+0xb58>
    4584:      	cmp	w22, w20
    4588:      	b.ls	0x4594 <generic_lsm_process_filter+0xb14>
    458c:      	mov	w13, #0x2f              // =47
    4590:      	strb	w13, [x8, x12]
    4594:      	add	x25, x8, x12
    4598:      	cmp	w22, w20
    459c:      	add	x2, x9, x10
    45a0:      	and	w1, w11, #0xff
    45a4:      	mov	w8, #0x4                // =4
    45a8:      	cinc	x0, x25, hi
    45ac:      	blr	x8
    45b0:      	cmp	w22, w20
    45b4:      	str	x25, [sp, #0x88]
    45b8:      	b.ls	0x45d8 <generic_lsm_process_filter+0xb58>
    45bc:      	ldr	x8, [sp, #0xc0]
    45c0:      	str	x8, [sp, #0x70]
    45c4:      	subs	w19, w19, #0x1
    45c8:      	b.ne	0x44b0 <generic_lsm_process_filter+0xa30>
    45cc:      	b	0x45d8 <generic_lsm_process_filter+0xb58>
    45d0:      	mov	w8, #0x1                // =1
    45d4:      	strb	w8, [sp, #0x94]
    45d8:      	ldr	x24, [sp, #0x88]
    45dc:      	ldr	x9, [sp, #0x28]
    45e0:      	cmp	x24, x9
    45e4:      	b.eq	0x4628 <generic_lsm_process_filter+0xba8>
    45e8:      	ldrb	w8, [sp, #0x94]
    45ec:      	ldr	x29, [sp, #0x40]
    45f0:      	cmp	w8, #0x0
    45f4:      	ldr	x21, [sp, #0x30]
    45f8:      	cset	w8, eq
    45fc:      	lsl	w9, w8, #1
    4600:      	ldr	w8, [sp, #0x90]
    4604:      	cmp	w8, #0x1
    4608:      	str	w8, [x29, #0x550]
    460c:      	str	w9, [x29, #0x554]
    4610:      	b.lt	0x4620 <generic_lsm_process_filter+0xba0>
    4614:      	mov	w9, #0x1000             // =4096
    4618:      	sub	w8, w9, w8
    461c:      	str	w8, [x29, #0x550]
    4620:      	cbnz	x24, 0x463c <generic_lsm_process_filter+0xbbc>
    4624:      	b	0x4754 <generic_lsm_process_filter+0xcd4>
    4628:      	ldr	x29, [sp, #0x40]
    462c:      	ldr	x21, [sp, #0x30]
    4630:      	mov	w8, wzr
    4634:      	mov	x24, x9
    4638:      	str	xzr, [x29, #0x550]
    463c:      	subs	w9, w8, #0x7f
    4640:      	mov	w10, #0x7f              // =127
    4644:      	mov	x11, x29
    4648:      	mov	x0, x21
    464c:      	mov	x2, x24
    4650:      	csel	w29, w8, w10, lo
    4654:      	csel	w19, wzr, w9, lo
    4658:      	cmp	w8, #0xff
    465c:      	mov	w9, #0xff               // =255
    4660:      	csel	w8, w8, w9, lo
    4664:      	and	w1, w8, #0xff
    4668:      	str	w1, [x11, #0x550]
    466c:      	mov	w8, #0x4                // =4
    4670:      	blr	x8
    4674:      	adrp	x25, 0x4000 <generic_lsm_process_filter+0x580>
    4678:      	ldr	x25, [x25]
    467c:      	cbz	x0, 0x46ec <generic_lsm_process_filter+0xc6c>
    4680:      	neg	w8, w0
    4684:      	mov	w9, #0x1                // =1
    4688:      	add	x1, sp, #0x58
    468c:      	strh	w8, [sp, #0x58]
    4690:      	mov	w8, #0x8                // =8
    4694:      	mov	x0, x25
    4698:      	mov	w20, #0x1               // =1
    469c:      	strh	w8, [sp, #0x5a]
    46a0:      	mov	x8, #0x2de              // =734
    46a4:      	movk	x8, #0x4, lsl #32
    46a8:      	stur	x8, [sp, #0x5c]
    46ac:      	add	x8, sp, #0x58
    46b0:      	blr	x9
    46b4:      	cbz	x0, 0x46c8 <generic_lsm_process_filter+0xc48>
    46b8:      	ldr	w8, [x0]
    46bc:      	add	w8, w8, #0x1
    46c0:      	str	w8, [x0]
    46c4:      	b	0x46ec <generic_lsm_process_filter+0xc6c>
    46c8:      	str	w20, [sp, #0xc8]
    46cc:      	mov	x3, xzr
    46d0:      	mov	w8, #0x2                // =2
    46d4:      	add	x9, sp, #0x58
    46d8:      	add	x10, sp, #0xc8
    46dc:      	add	x1, sp, #0x58
    46e0:      	add	x2, sp, #0xc8
    46e4:      	mov	x0, x25
    46e8:      	blr	x8
    46ec:      	ldr	x9, [sp, #0xe8]
    46f0:      	mov	w8, #0x6390             // =25488
    46f4:      	add	x2, x24, x19
    46f8:      	mov	w1, w29
    46fc:      	add	x0, x9, x8
    4700:      	mov	w8, #0x4                // =4
    4704:      	blr	x8
    4708:      	ldr	x29, [sp, #0x40]
    470c:      	cbz	x0, 0x4754 <generic_lsm_process_filter+0xcd4>
    4710:      	neg	w8, w0
    4714:      	mov	w9, #0x1                // =1
    4718:      	add	x1, sp, #0x58
    471c:      	strh	w8, [sp, #0x58]
    4720:      	mov	w8, #0x8                // =8
    4724:      	mov	x0, x25
    4728:      	mov	w19, #0x1               // =1
    472c:      	strh	w8, [sp, #0x5a]
    4730:      	mov	x8, #0x2e0              // =736
    4734:      	movk	x8, #0x4, lsl #32
    4738:      	stur	x8, [sp, #0x5c]
    473c:      	add	x8, sp, #0x58
    4740:      	blr	x9
    4744:      	cbz	x0, 0x477c <generic_lsm_process_filter+0xcfc>
    4748:      	ldr	w8, [x0]
    474c:      	add	w8, w8, #0x1
    4750:      	str	w8, [x0]
    4754:      	ldr	w8, [x29, #0x550]
    4758:      	sub	w9, w8, #0x101
    475c:      	cmn	w9, #0x101
    4760:      	b.hi	0x47b0 <generic_lsm_process_filter+0xd30>
    4764:      	ldr	x20, [sp, #0x38]
    4768:      	ldr	x22, [sp, #0xe8]
    476c:      	mov	w8, #-0x1               // =-1
    4770:      	ldr	x24, [sp, #0x48]
    4774:      	stur	w8, [x29, #0xb8]
    4778:      	b	0x4900 <generic_lsm_process_filter+0xe80>
    477c:      	str	w19, [sp, #0xc8]
    4780:      	mov	x3, xzr
    4784:      	mov	w8, #0x2                // =2
    4788:      	add	x9, sp, #0x58
    478c:      	add	x10, sp, #0xc8
    4790:      	add	x1, sp, #0x58
    4794:      	add	x2, sp, #0xc8
    4798:      	mov	x0, x25
    479c:      	blr	x8
    47a0:      	ldr	w8, [x29, #0x550]
    47a4:      	sub	w9, w8, #0x101
    47a8:      	cmn	w9, #0x101
    47ac:      	b.ls	0x4764 <generic_lsm_process_filter+0xce4>
    47b0:      	ldr	x22, [sp, #0xe8]
    47b4:      	and	x24, x8, #0xff
    47b8:      	mov	w8, #0x5f80             // =24448
    47bc:      	mov	x2, x21
    47c0:      	mov	w1, w24
    47c4:      	add	x0, x22, x8
    47c8:      	mov	w8, #0x4                // =4
    47cc:      	blr	x8
    47d0:      	mov	x23, x0
    47d4:      	cbz	x0, 0x4850 <generic_lsm_process_filter+0xdd0>
    47d8:      	neg	w8, w23
    47dc:      	adrp	x25, 0x4000 <generic_lsm_process_filter+0x580>
    47e0:      	mov	w9, #0x1                // =1
    47e4:      	strh	w8, [sp, #0x58]
    47e8:      	mov	w8, #0xf                // =15
    47ec:      	add	x1, sp, #0x58
    47f0:      	mov	w19, #0x1               // =1
    47f4:      	strh	w8, [sp, #0x5a]
    47f8:      	mov	x8, #0x164              // =356
    47fc:      	movk	x8, #0x4, lsl #32
    4800:      	stur	x8, [sp, #0x5c]
    4804:      	add	x8, sp, #0x58
    4808:      	ldr	x25, [x25]
    480c:      	mov	x0, x25
    4810:      	blr	x9
    4814:      	cbz	x0, 0x4828 <generic_lsm_process_filter+0xda8>
    4818:      	ldr	w8, [x0]
    481c:      	add	w8, w8, #0x1
    4820:      	str	w8, [x0]
    4824:      	b	0x484c <generic_lsm_process_filter+0xdcc>
    4828:      	str	w19, [sp, #0xc8]
    482c:      	mov	x3, xzr
    4830:      	mov	w8, #0x2                // =2
    4834:      	add	x9, sp, #0x58
    4838:      	add	x10, sp, #0xc8
    483c:      	add	x1, sp, #0x58
    4840:      	add	x2, sp, #0xc8
    4844:      	mov	x0, x25
    4848:      	blr	x8
    484c:      	ldr	x22, [sp, #0xe8]
    4850:      	cmp	w23, #0x0
    4854:      	csel	w8, w24, w23, eq
    4858:      	cmp	w24, #0x7f
    485c:      	stur	w8, [x29, #0xb8]
    4860:      	mov	w8, #0x7f               // =127
    4864:      	csel	w1, w24, w8, lo
    4868:      	mov	w8, #0x6080             // =24704
    486c:      	add	x0, x22, x8
    4870:      	mov	w8, #0x6390             // =25488
    4874:      	add	x2, x22, x8
    4878:      	mov	w8, #0x4                // =4
    487c:      	blr	x8
    4880:      	ldr	x20, [sp, #0x38]
    4884:      	ldr	x24, [sp, #0x48]
    4888:      	cbz	x0, 0x4900 <generic_lsm_process_filter+0xe80>
    488c:      	neg	w8, w0
    4890:      	adrp	x23, 0x4000 <generic_lsm_process_filter+0x580>
    4894:      	mov	w9, #0x1                // =1
    4898:      	strh	w8, [sp, #0x58]
    489c:      	mov	w8, #0xf                // =15
    48a0:      	add	x1, sp, #0x58
    48a4:      	mov	w19, #0x1               // =1
    48a8:      	strh	w8, [sp, #0x5a]
    48ac:      	mov	x8, #0x16a              // =362
    48b0:      	movk	x8, #0x4, lsl #32
    48b4:      	stur	x8, [sp, #0x5c]
    48b8:      	add	x8, sp, #0x58
    48bc:      	ldr	x23, [x23]
    48c0:      	mov	x0, x23
    48c4:      	blr	x9
    48c8:      	cbz	x0, 0x48dc <generic_lsm_process_filter+0xe5c>
    48cc:      	ldr	w8, [x0]
    48d0:      	add	w8, w8, #0x1
    48d4:      	str	w8, [x0]
    48d8:      	b	0x4900 <generic_lsm_process_filter+0xe80>
    48dc:      	str	w19, [sp, #0xc8]
    48e0:      	mov	x3, xzr
    48e4:      	mov	w8, #0x2                // =2
    48e8:      	add	x9, sp, #0x58
    48ec:      	add	x10, sp, #0xc8
    48f0:      	add	x1, sp, #0x58
    48f4:      	add	x2, sp, #0xc8
    48f8:      	mov	x0, x23
    48fc:      	blr	x8
    4900:      	ldrb	w8, [x22, #0x1]
    4904:      	orr	w8, w8, #0x10
    4908:      	strb	w8, [x22, #0x1]
    490c:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4910:      	mov	w8, #0x5ef8             // =24312
    4914:      	ldr	x0, [x0]
    4918:      	add	x1, x22, x8
    491c:      	mov	w8, #0x1                // =1
    4920:      	blr	x8
    4924:      	cbz	x0, 0x5dac <generic_lsm_process_filter+0x232c>
    4928:      	ldr	x21, [x22, #0x5eb8]
    492c:      	cmp	x21, #0x6
    4930:      	b.hs	0x4ac8 <generic_lsm_process_filter+0x1048>
    4934:      	ldrsw	x8, [x0]
    4938:      	mov	x23, x0
    493c:      	cbz	w8, 0x4ae4 <generic_lsm_process_filter+0x1064>
    4940:      	cmp	x21, x8
    4944:      	b.hs	0x4ac8 <generic_lsm_process_filter+0x1048>
    4948:      	str	x8, [sp, #0x28]
    494c:      	stp	x29, x24, [sp, #0x40]
    4950:      	adrp	x24, 0x4000 <generic_lsm_process_filter+0x580>
    4954:      	mov	w8, #0x1                // =1
    4958:      	add	x9, sp, #0xd8
    495c:      	str	x22, [sp, #0xe8]
    4960:      	add	x1, sp, #0xd8
    4964:      	str	x20, [sp, #0x38]
    4968:      	str	w21, [sp, #0xd8]
    496c:      	str	wzr, [sp, #0xc0]
    4970:      	ldr	x24, [x24]
    4974:      	mov	x0, x24
    4978:      	blr	x8
    497c:      	cbz	x0, 0x4d94 <generic_lsm_process_filter+0x1314>
    4980:      	ldr	w8, [x0]
    4984:      	mov	x25, x0
    4988:      	cbz	w8, 0x4d94 <generic_lsm_process_filter+0x1314>
    498c:      	ldr	x9, [sp, #0x48]
    4990:      	ldr	w9, [x9, #0x68]
    4994:      	tbnz	w9, #0x1f, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4998:      	cmp	w8, #0x1b
    499c:      	b.hi	0x5d54 <generic_lsm_process_filter+0x22d4>
    49a0:      	mov	w9, #0x1                // =1
    49a4:      	lsl	w9, w9, w8
    49a8:      	tst	w9, #0x60
    49ac:      	b.ne	0x4ba4 <generic_lsm_process_filter+0x1124>
    49b0:      	mov	w10, #0x100             // =256
    49b4:      	movk	w10, #0x400, lsl #16
    49b8:      	tst	w9, w10
    49bc:      	b.ne	0x4b20 <generic_lsm_process_filter+0x10a0>
    49c0:      	mov	w9, #0x1                // =1
    49c4:      	lsl	w8, w9, w8
    49c8:      	mov	w9, #0x200              // =512
    49cc:      	movk	w9, #0x800, lsl #16
    49d0:      	tst	w8, w9
    49d4:      	b.eq	0x5d54 <generic_lsm_process_filter+0x22d4>
    49d8:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    49dc:      	add	x1, x25, #0x4
    49e0:      	mov	w8, #0x1                // =1
    49e4:      	ldr	x0, [x0]
    49e8:      	blr	x8
    49ec:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    49f0:      	ldr	x8, [sp, #0x48]
    49f4:      	mov	x20, x0
    49f8:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    49fc:      	mov	w9, #0x7f               // =127
    4a00:      	ldr	w8, [x8, #0x68]
    4a04:      	ldr	x0, [x0]
    4a08:      	add	x1, sp, #0xc0
    4a0c:      	cmp	w8, #0x7f
    4a10:      	csel	w19, w8, w9, lt
    4a14:      	mov	w8, #0x1                // =1
    4a18:      	add	x9, sp, #0xc0
    4a1c:      	blr	x8
    4a20:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4a24:      	sxtw	x1, w19
    4a28:      	mov	x29, x0
    4a2c:      	lsl	w8, w1, #3
    4a30:      	str	w8, [x0]
    4a34:      	ldr	x8, [sp, #0x48]
    4a38:      	ldr	w8, [x8, #0x6c]
    4a3c:      	cbnz	w8, 0x4a9c <generic_lsm_process_filter+0x101c>
    4a40:      	ldr	x11, [sp, #0x48]
    4a44:      	and	w13, w1, #0x7f
    4a48:      	mov	x8, xzr
    4a4c:      	ldr	w12, [x11, #0x68]
    4a50:      	add	x9, x11, #0x1f0
    4a54:      	add	x10, x11, #0x170
    4a58:      	sub	w11, w12, w1
    4a5c:      	add	w12, w12, w13
    4a60:      	add	w11, w11, w13
    4a64:      	mvn	w13, w1
    4a68:      	add	w12, w13, w12
    4a6c:      	cmp	x8, #0x7f
    4a70:      	b.eq	0x4a90 <generic_lsm_process_filter+0x1010>
    4a74:      	and	x13, x12, #0x7f
    4a78:      	sub	w12, w12, #0x1
    4a7c:      	ldrb	w13, [x10, x13]
    4a80:      	strb	w13, [x9, x8]
    4a84:      	add	x8, x8, #0x1
    4a88:      	cmp	x11, x8
    4a8c:      	b.ne	0x4a6c <generic_lsm_process_filter+0xfec>
    4a90:      	ldr	x9, [sp, #0x48]
    4a94:      	mov	w8, #0x1                // =1
    4a98:      	str	w8, [x9, #0x6c]
    4a9c:      	cmp	w1, #0x7f
    4aa0:      	b.hi	0x4abc <generic_lsm_process_filter+0x103c>
    4aa4:      	ldr	x8, [sp, #0x48]
    4aa8:      	add	x0, x29, #0x4
    4aac:      	add	x2, x8, #0x1f0
    4ab0:      	mov	w8, #0x4                // =4
    4ab4:      	blr	x8
    4ab8:      	tbnz	x0, #0x3f, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4abc:      	mov	w8, #0x1                // =1
    4ac0:      	mov	x0, x20
    4ac4:      	b	0x4b9c <generic_lsm_process_filter+0x111c>
    4ac8:      	ldr	w8, [x24]
    4acc:      	str	w8, [x22, #0x10]
    4ad0:      	ldr	x8, [x24, #0x8]
    4ad4:      	str	x8, [x22, #0x18]
    4ad8:      	ldrb	w8, [x29]
    4adc:      	cbnz	w8, 0x5d90 <generic_lsm_process_filter+0x2310>
    4ae0:      	b	0x5dac <generic_lsm_process_filter+0x232c>
    4ae4:      	mov	w8, #0x1                // =1
    4ae8:      	strb	w8, [x29]
    4aec:      	ldr	w8, [x24]
    4af0:      	str	w8, [x22, #0x10]
    4af4:      	ldr	x8, [x24, #0x8]
    4af8:      	str	x8, [x22, #0x18]
    4afc:      	b	0x5d90 <generic_lsm_process_filter+0x2310>
    4b00:      	mov	w8, #0x2964             // =10596
    4b04:      	add	x20, x24, #0xff6
    4b08:      	strh	w8, [x24, #0xffe]
    4b0c:      	adrp	x8, 0x4000 <generic_lsm_process_filter+0x580>
    4b10:      	add	x8, x8, #0x0
    4b14:      	ldr	x8, [x8]
    4b18:      	str	x8, [x20]
    4b1c:      	b	0x41c4 <generic_lsm_process_filter+0x744>
    4b20:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4b24:      	add	x1, x25, #0x4
    4b28:      	mov	w8, #0x1                // =1
    4b2c:      	ldr	x0, [x0]
    4b30:      	blr	x8
    4b34:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4b38:      	mov	x19, x0
    4b3c:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4b40:      	mov	w8, #0x1                // =1
    4b44:      	ldr	x0, [x0]
    4b48:      	add	x9, sp, #0xc0
    4b4c:      	add	x1, sp, #0xc0
    4b50:      	blr	x8
    4b54:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4b58:      	mov	w1, wzr
    4b5c:      	mov	w2, #0x104              // =260
    4b60:      	mov	x29, x0
    4b64:      	bl	0x4b64 <generic_lsm_process_filter+0x10e4>
    4b68:      	ldr	x10, [sp, #0x48]
    4b6c:      	mov	x0, x29
    4b70:      	ldr	w8, [x10, #0x68]
    4b74:      	add	x2, x10, #0x70
    4b78:      	lsl	w9, w8, #3
    4b7c:      	and	x8, x8, #0xff
    4b80:      	str	w9, [x0], #0x4
    4b84:      	mov	w9, #0x4                // =4
    4b88:      	ldrb	w1, [x10, #0x68]
    4b8c:      	blr	x9
    4b90:      	tbnz	x0, #0x3f, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4b94:      	mov	w8, #0x1                // =1
    4b98:      	mov	x0, x19
    4b9c:      	mov	x1, x29
    4ba0:      	b	0x4d5c <generic_lsm_process_filter+0x12dc>
    4ba4:      	str	wzr, [sp, #0xc8]
    4ba8:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4bac:      	mov	w8, #0x1                // =1
    4bb0:      	add	x9, sp, #0xc8
    4bb4:      	ldr	x0, [x0]
    4bb8:      	add	x1, sp, #0xc8
    4bbc:      	blr	x8
    4bc0:      	cbz	x0, 0x4d08 <generic_lsm_process_filter+0x1288>
    4bc4:      	ldr	x9, [sp, #0x48]
    4bc8:      	ldr	x8, [x0]
    4bcc:      	ldr	x9, [x9, #0x378]
    4bd0:      	cmp	x8, x9
    4bd4:      	b.eq	0x4d08 <generic_lsm_process_filter+0x1288>
    4bd8:      	str	x0, [sp, #0x30]
    4bdc:      	adrp	x8, 0x4000 <generic_lsm_process_filter+0x580>
    4be0:      	ldr	x8, [x8]
    4be4:      	ldrb	w8, [x8]
    4be8:      	cbz	w8, 0x4c74 <generic_lsm_process_filter+0x11f4>
    4bec:      	adrp	x19, 0x4000 <generic_lsm_process_filter+0x580>
    4bf0:      	mov	w20, #0x869f            // =34463
    4bf4:      	mov	x22, xzr
    4bf8:      	ldr	x19, [x19]
    4bfc:      	movk	w20, #0x1, lsl #16
    4c00:      	b	0x4c18 <generic_lsm_process_filter+0x1198>
    4c04:      	cmp	x29, x22
    4c08:      	mov	x22, x29
    4c0c:      	ccmp	w20, #0x0, #0x4, ne
    4c10:      	sub	w20, w20, #0x1
    4c14:      	b.eq	0x4cf8 <generic_lsm_process_filter+0x1278>
    4c18:      	ldr	x8, [sp, #0x48]
    4c1c:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4c20:      	add	x9, sp, #0x58
    4c24:      	add	x1, sp, #0x58
    4c28:      	ldr	w8, [x8, #0x10]
    4c2c:      	str	w8, [sp, #0x58]
    4c30:      	mov	w8, #0x1                // =1
    4c34:      	ldr	x0, [x0]
    4c38:      	blr	x8
    4c3c:      	cbz	x0, 0x4cf8 <generic_lsm_process_filter+0x1278>
    4c40:      	add	x1, x0, #0x70
    4c44:      	mov	w8, #0x1                // =1
    4c48:      	mov	x29, x0
    4c4c:      	mov	x0, x19
    4c50:      	blr	x8
    4c54:      	cbz	x0, 0x4c04 <generic_lsm_process_filter+0x1184>
    4c58:      	ldr	x8, [x0]
    4c5c:      	cbz	x8, 0x4c04 <generic_lsm_process_filter+0x1184>
    4c60:      	ldr	x10, [sp, #0x48]
    4c64:      	ldr	x9, [x10, #0x370]
    4c68:      	orr	x8, x9, x8
    4c6c:      	str	x8, [x10, #0x370]
    4c70:      	b	0x4c04 <generic_lsm_process_filter+0x1184>
    4c74:      	adrp	x19, 0x4000 <generic_lsm_process_filter+0x580>
    4c78:      	mov	x22, xzr
    4c7c:      	mov	w20, #0x3ff             // =1023
    4c80:      	ldr	x19, [x19]
    4c84:      	b	0x4c9c <generic_lsm_process_filter+0x121c>
    4c88:      	cmp	x29, x22
    4c8c:      	mov	x22, x29
    4c90:      	ccmp	w20, #0x0, #0x4, ne
    4c94:      	sub	w20, w20, #0x1
    4c98:      	b.eq	0x4cf8 <generic_lsm_process_filter+0x1278>
    4c9c:      	ldr	x8, [sp, #0x48]
    4ca0:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4ca4:      	add	x9, sp, #0x58
    4ca8:      	add	x1, sp, #0x58
    4cac:      	ldr	w8, [x8, #0x10]
    4cb0:      	str	w8, [sp, #0x58]
    4cb4:      	mov	w8, #0x1                // =1
    4cb8:      	ldr	x0, [x0]
    4cbc:      	blr	x8
    4cc0:      	cbz	x0, 0x4cf8 <generic_lsm_process_filter+0x1278>
    4cc4:      	add	x1, x0, #0x70
    4cc8:      	mov	w8, #0x1                // =1
    4ccc:      	mov	x29, x0
    4cd0:      	mov	x0, x19
    4cd4:      	blr	x8
    4cd8:      	cbz	x0, 0x4c88 <generic_lsm_process_filter+0x1208>
    4cdc:      	ldr	x8, [x0]
    4ce0:      	cbz	x8, 0x4c88 <generic_lsm_process_filter+0x1208>
    4ce4:      	ldr	x10, [sp, #0x48]
    4ce8:      	ldr	x9, [x10, #0x370]
    4cec:      	orr	x8, x9, x8
    4cf0:      	str	x8, [x10, #0x370]
    4cf4:      	b	0x4c88 <generic_lsm_process_filter+0x1208>
    4cf8:      	ldr	x8, [sp, #0x30]
    4cfc:      	ldr	x9, [sp, #0x48]
    4d00:      	ldr	x8, [x8]
    4d04:      	str	x8, [x9, #0x378]
    4d08:      	ldr	w8, [x25, #0x8]
    4d0c:      	cmn	w8, #0x1
    4d10:      	b.eq	0x4d34 <generic_lsm_process_filter+0x12b4>
    4d14:      	ldr	x9, [sp, #0x48]
    4d18:      	ldr	x9, [x9, #0x370]
    4d1c:      	lsr	x8, x9, x8
    4d20:      	tbz	w8, #0x0, 0x4d34 <generic_lsm_process_filter+0x12b4>
    4d24:      	mov	x0, #0xffee             // =65518
    4d28:      	movk	x0, #0xadc0, lsl #16
    4d2c:      	movk	x0, #0xb, lsl #32
    4d30:      	b	0x4d60 <generic_lsm_process_filter+0x12e0>
    4d34:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4d38:      	mov	w8, #0x1                // =1
    4d3c:      	add	x9, sp, #0xd8
    4d40:      	ldr	x0, [x0]
    4d44:      	add	x1, sp, #0xd8
    4d48:      	blr	x8
    4d4c:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4d50:      	ldr	x8, [sp, #0x48]
    4d54:      	add	x1, x8, #0x70
    4d58:      	mov	w8, #0x1                // =1
    4d5c:      	blr	x8
    4d60:      	ldr	w8, [x25]
    4d64:      	cmp	w8, #0x25
    4d68:      	b.hi	0x4d90 <generic_lsm_process_filter+0x1310>
    4d6c:      	mov	w9, #0x1                // =1
    4d70:      	lsl	x8, x9, x8
    4d74:      	mov	x9, #0x50               // =80
    4d78:      	movk	x9, #0xc00, lsl #16
    4d7c:      	movk	x9, #0x20, lsl #32
    4d80:      	tst	x8, x9
    4d84:      	b.eq	0x4d90 <generic_lsm_process_filter+0x1310>
    4d88:      	cbnz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4d8c:      	b	0x4d94 <generic_lsm_process_filter+0x1314>
    4d90:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4d94:      	adrp	x8, 0x4000 <generic_lsm_process_filter+0x580>
    4d98:      	ldr	x8, [x8]
    4d9c:      	ldrb	w8, [x8]
    4da0:      	cbz	w8, 0x516c <generic_lsm_process_filter+0x16ec>
    4da4:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4da8:      	mov	w8, #0x1                // =1
    4dac:      	ldr	x0, [x0]
    4db0:      	ldr	x1, [sp, #0x48]
    4db4:      	blr	x8
    4db8:      	cbz	x0, 0x516c <generic_lsm_process_filter+0x16ec>
    4dbc:      	add	w8, w21, #0x5
    4dc0:      	str	wzr, [sp, #0xc0]
    4dc4:      	add	x9, sp, #0xd8
    4dc8:      	mov	x25, x0
    4dcc:      	str	w8, [sp, #0xd8]
    4dd0:      	mov	w8, #0x1                // =1
    4dd4:      	add	x1, sp, #0xd8
    4dd8:      	mov	x0, x24
    4ddc:      	blr	x8
    4de0:      	cbz	x0, 0x516c <generic_lsm_process_filter+0x16ec>
    4de4:      	ldr	w8, [x0]
    4de8:      	mov	x24, x0
    4dec:      	cbz	w8, 0x516c <generic_lsm_process_filter+0x16ec>
    4df0:      	ldr	w9, [x25]
    4df4:      	tbnz	w9, #0x1f, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4df8:      	cmp	w8, #0x1b
    4dfc:      	b.hi	0x5d54 <generic_lsm_process_filter+0x22d4>
    4e00:      	mov	w9, #0x1                // =1
    4e04:      	lsl	w9, w9, w8
    4e08:      	tst	w9, #0x60
    4e0c:      	b.ne	0x4f94 <generic_lsm_process_filter+0x1514>
    4e10:      	mov	w10, #0x100             // =256
    4e14:      	movk	w10, #0x400, lsl #16
    4e18:      	tst	w9, w10
    4e1c:      	b.ne	0x4f14 <generic_lsm_process_filter+0x1494>
    4e20:      	mov	w9, #0x1                // =1
    4e24:      	lsl	w8, w9, w8
    4e28:      	mov	w9, #0x200              // =512
    4e2c:      	movk	w9, #0x800, lsl #16
    4e30:      	tst	w8, w9
    4e34:      	b.eq	0x5d54 <generic_lsm_process_filter+0x22d4>
    4e38:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4e3c:      	add	x1, x24, #0x4
    4e40:      	mov	w8, #0x1                // =1
    4e44:      	ldr	x0, [x0]
    4e48:      	blr	x8
    4e4c:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4e50:      	ldr	w8, [x25]
    4e54:      	mov	x20, x0
    4e58:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4e5c:      	mov	w9, #0x7f               // =127
    4e60:      	ldr	x0, [x0]
    4e64:      	add	x1, sp, #0xc0
    4e68:      	cmp	w8, #0x7f
    4e6c:      	csel	w19, w8, w9, lt
    4e70:      	mov	w8, #0x1                // =1
    4e74:      	add	x9, sp, #0xc0
    4e78:      	blr	x8
    4e7c:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4e80:      	sxtw	x1, w19
    4e84:      	mov	x29, x0
    4e88:      	lsl	w8, w1, #3
    4e8c:      	str	w8, [x0]
    4e90:      	ldr	w8, [x25, #0x4]
    4e94:      	cbnz	w8, 0x4eec <generic_lsm_process_filter+0x146c>
    4e98:      	ldr	w12, [x25]
    4e9c:      	and	w13, w1, #0x7f
    4ea0:      	mov	x8, xzr
    4ea4:      	add	x9, x25, #0x188
    4ea8:      	add	x10, x25, #0x108
    4eac:      	sub	w11, w12, w1
    4eb0:      	add	w12, w12, w13
    4eb4:      	add	w11, w11, w13
    4eb8:      	mvn	w13, w1
    4ebc:      	add	w12, w13, w12
    4ec0:      	cmp	x8, #0x7f
    4ec4:      	b.eq	0x4ee4 <generic_lsm_process_filter+0x1464>
    4ec8:      	and	x13, x12, #0x7f
    4ecc:      	sub	w12, w12, #0x1
    4ed0:      	ldrb	w13, [x10, x13]
    4ed4:      	strb	w13, [x9, x8]
    4ed8:      	add	x8, x8, #0x1
    4edc:      	cmp	x11, x8
    4ee0:      	b.ne	0x4ec0 <generic_lsm_process_filter+0x1440>
    4ee4:      	mov	w8, #0x1                // =1
    4ee8:      	str	w8, [x25, #0x4]
    4eec:      	cmp	w1, #0x7f
    4ef0:      	b.hi	0x4f08 <generic_lsm_process_filter+0x1488>
    4ef4:      	add	x0, x29, #0x4
    4ef8:      	add	x2, x25, #0x188
    4efc:      	mov	w8, #0x4                // =4
    4f00:      	blr	x8
    4f04:      	tbnz	x0, #0x3f, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4f08:      	mov	w8, #0x1                // =1
    4f0c:      	mov	x0, x20
    4f10:      	b	0x4f8c <generic_lsm_process_filter+0x150c>
    4f14:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4f18:      	add	x1, x24, #0x4
    4f1c:      	mov	w8, #0x1                // =1
    4f20:      	ldr	x0, [x0]
    4f24:      	blr	x8
    4f28:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4f2c:      	mov	x19, x0
    4f30:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4f34:      	mov	w8, #0x1                // =1
    4f38:      	ldr	x0, [x0]
    4f3c:      	add	x9, sp, #0xc0
    4f40:      	add	x1, sp, #0xc0
    4f44:      	blr	x8
    4f48:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4f4c:      	mov	w1, wzr
    4f50:      	mov	w2, #0x104              // =260
    4f54:      	mov	x29, x0
    4f58:      	bl	0x4f58 <generic_lsm_process_filter+0x14d8>
    4f5c:      	ldr	w8, [x25]
    4f60:      	mov	x0, x29
    4f64:      	add	x2, x25, #0x8
    4f68:      	lsl	w9, w8, #3
    4f6c:      	and	x8, x8, #0xff
    4f70:      	str	w9, [x0], #0x4
    4f74:      	mov	w9, #0x4                // =4
    4f78:      	ldrb	w1, [x25]
    4f7c:      	blr	x9
    4f80:      	tbnz	x0, #0x3f, 0x5d54 <generic_lsm_process_filter+0x22d4>
    4f84:      	mov	w8, #0x1                // =1
    4f88:      	mov	x0, x19
    4f8c:      	mov	x1, x29
    4f90:      	b	0x5134 <generic_lsm_process_filter+0x16b4>
    4f94:      	str	wzr, [sp, #0xc8]
    4f98:      	adrp	x0, 0x4000 <generic_lsm_process_filter+0x580>
    4f9c:      	mov	w8, #0x1                // =1
    4fa0:      	add	x9, sp, #0xc8
    4fa4:      	ldr	x0, [x0]
    4fa8:      	add	x1, sp, #0xc8
    4fac:      	blr	x8
    4fb0:      	cbz	x0, 0x50e8 <generic_lsm_process_filter+0x1668>
    4fb4:      	ldr	x8, [x0]
    4fb8:      	ldr	x9, [x25, #0x310]
    4fbc:      	cmp	x8, x9
    4fc0:      	b.eq	0x50e8 <generic_lsm_process_filter+0x1668>
    4fc4:      	str	x0, [sp, #0x30]
    4fc8:      	adrp	x8, 0x4000 <generic_lsm_process_filter+0x580>
    4fcc:      	ldr	x8, [x8]
    4fd0:      	ldrb	w8, [x8]
    4fd4:      	cbz	w8, 0x505c <generic_lsm_process_filter+0x15dc>
    4fd8:      	adrp	x19, 0x4000 <generic_lsm_process_filter+0x580>
    4fdc:      	mov	w20, #0x869f            // =34463
    4fe0:      	mov	x22, xzr
    4fe4:      	ldr	x19, [x19]
    4fe8:      	movk	w20, #0x1, lsl #16
    4fec:      	b	0x5004 <generic_lsm_process_filter+0x1584>
    4ff0:      	cmp	x29, x22
    4ff4:      	mov	x22, x29
    4ff8:      	ccmp	w20, #0x0, #0x4, ne
    4ffc:      	sub	w20, w20, #0x1
    5000:      	b.eq	0x50dc <generic_lsm_process_filter+0x165c>
    5004:      	ldr	x8, [sp, #0x48]
    5008:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    500c:      	add	x9, sp, #0x58
    5010:      	add	x1, sp, #0x58
    5014:      	ldr	w8, [x8, #0x10]
    5018:      	str	w8, [sp, #0x58]
    501c:      	mov	w8, #0x1                // =1
    5020:      	ldr	x0, [x0]
    5024:      	blr	x8
    5028:      	cbz	x0, 0x50dc <generic_lsm_process_filter+0x165c>
    502c:      	add	x1, x0, #0x70
    5030:      	mov	w8, #0x1                // =1
    5034:      	mov	x29, x0
    5038:      	mov	x0, x19
    503c:      	blr	x8
    5040:      	cbz	x0, 0x4ff0 <generic_lsm_process_filter+0x1570>
    5044:      	ldr	x8, [x0]
    5048:      	cbz	x8, 0x4ff0 <generic_lsm_process_filter+0x1570>
    504c:      	ldr	x9, [x25, #0x308]
    5050:      	orr	x8, x9, x8
    5054:      	str	x8, [x25, #0x308]
    5058:      	b	0x4ff0 <generic_lsm_process_filter+0x1570>
    505c:      	adrp	x19, 0x5000 <generic_lsm_process_filter+0x1580>
    5060:      	mov	x22, xzr
    5064:      	mov	w20, #0x3ff             // =1023
    5068:      	ldr	x19, [x19]
    506c:      	b	0x5084 <generic_lsm_process_filter+0x1604>
    5070:      	cmp	x29, x22
    5074:      	mov	x22, x29
    5078:      	ccmp	w20, #0x0, #0x4, ne
    507c:      	sub	w20, w20, #0x1
    5080:      	b.eq	0x50dc <generic_lsm_process_filter+0x165c>
    5084:      	ldr	x8, [sp, #0x48]
    5088:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    508c:      	add	x9, sp, #0x58
    5090:      	add	x1, sp, #0x58
    5094:      	ldr	w8, [x8, #0x10]
    5098:      	str	w8, [sp, #0x58]
    509c:      	mov	w8, #0x1                // =1
    50a0:      	ldr	x0, [x0]
    50a4:      	blr	x8
    50a8:      	cbz	x0, 0x50dc <generic_lsm_process_filter+0x165c>
    50ac:      	add	x1, x0, #0x70
    50b0:      	mov	w8, #0x1                // =1
    50b4:      	mov	x29, x0
    50b8:      	mov	x0, x19
    50bc:      	blr	x8
    50c0:      	cbz	x0, 0x5070 <generic_lsm_process_filter+0x15f0>
    50c4:      	ldr	x8, [x0]
    50c8:      	cbz	x8, 0x5070 <generic_lsm_process_filter+0x15f0>
    50cc:      	ldr	x9, [x25, #0x308]
    50d0:      	orr	x8, x9, x8
    50d4:      	str	x8, [x25, #0x308]
    50d8:      	b	0x5070 <generic_lsm_process_filter+0x15f0>
    50dc:      	ldr	x8, [sp, #0x30]
    50e0:      	ldr	x8, [x8]
    50e4:      	str	x8, [x25, #0x310]
    50e8:      	ldr	w8, [x24, #0x8]
    50ec:      	cmn	w8, #0x1
    50f0:      	b.eq	0x5110 <generic_lsm_process_filter+0x1690>
    50f4:      	ldr	x9, [x25, #0x308]
    50f8:      	lsr	x8, x9, x8
    50fc:      	tbz	w8, #0x0, 0x5110 <generic_lsm_process_filter+0x1690>
    5100:      	mov	x0, #0xffee             // =65518
    5104:      	movk	x0, #0xadc0, lsl #16
    5108:      	movk	x0, #0xb, lsl #32
    510c:      	b	0x5138 <generic_lsm_process_filter+0x16b8>
    5110:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5114:      	mov	w8, #0x1                // =1
    5118:      	add	x9, sp, #0xd8
    511c:      	ldr	x0, [x0]
    5120:      	add	x1, sp, #0xd8
    5124:      	blr	x8
    5128:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    512c:      	add	x1, x25, #0x8
    5130:      	mov	w8, #0x1                // =1
    5134:      	blr	x8
    5138:      	ldr	w8, [x24]
    513c:      	cmp	w8, #0x25
    5140:      	b.hi	0x5168 <generic_lsm_process_filter+0x16e8>
    5144:      	mov	w9, #0x1                // =1
    5148:      	lsl	x8, x9, x8
    514c:      	mov	x9, #0x50               // =80
    5150:      	movk	x9, #0xc00, lsl #16
    5154:      	movk	x9, #0x20, lsl #32
    5158:      	tst	x8, x9
    515c:      	b.eq	0x5168 <generic_lsm_process_filter+0x16e8>
    5160:      	cbnz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    5164:      	b	0x516c <generic_lsm_process_filter+0x16ec>
    5168:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    516c:      	lsl	w8, w21, #2
    5170:      	add	x9, x8, #0x4
    5174:      	ldr	w8, [x9, x23]
    5178:      	add	w9, w8, w9
    517c:      	and	w11, w9, #0x3ff
    5180:      	add	w9, w9, #0x4
    5184:      	and	x9, x9, #0x3ff
    5188:      	add	x10, x11, #0x8
    518c:      	ldr	w9, [x9, x23]
    5190:      	cmp	w9, #0x5
    5194:      	b.lo	0x5224 <generic_lsm_process_filter+0x17a4>
    5198:      	add	x9, x10, x23
    519c:      	ldr	w10, [x9, #0x8]
    51a0:      	ldp	w12, w22, [x9]
    51a4:      	stp	x9, x11, [sp, #0x8]
    51a8:      	mov	w9, #0x4                // =4
    51ac:      	cmp	w10, #0x4
    51b0:      	stp	xzr, xzr, [sp, #0x58]
    51b4:      	csel	w9, w10, w9, lo
    51b8:      	cmp	w12, #0x6
    51bc:      	b.ne	0x51c8 <generic_lsm_process_filter+0x1748>
    51c0:      	mov	x11, #0x100000001       // =4294967297
    51c4:      	stp	x11, x11, [sp, #0x58]
    51c8:      	cbz	w10, 0x562c <generic_lsm_process_filter+0x1bac>
    51cc:      	ldr	x10, [sp, #0x48]
    51d0:      	add	w8, w8, w21, lsl #2
    51d4:      	tst	x22, #0x1
    51d8:      	add	x25, sp, #0x58
    51dc:      	str	w12, [sp, #0x30]
    51e0:      	add	w8, w8, #0x4
    51e4:      	and	x8, x8, #0x3ff
    51e8:      	add	x21, x8, #0x14
    51ec:      	sub	x8, x9, #0x1
    51f0:      	mov	w9, #0x3                // =3
    51f4:      	add	x11, x10, #0x24
    51f8:      	str	x11, [sp, #0x20]
    51fc:      	csel	x11, x10, x11, eq
    5200:      	cmp	x8, #0x3
    5204:      	add	x10, x10, #0x10
    5208:      	csel	x8, x8, x9, lo
    520c:      	and	x9, x21, #0x7fc
    5210:      	mov	x20, x11
    5214:      	str	x10, [sp, #0x18]
    5218:      	add	x19, x23, x9
    521c:      	add	x24, x8, #0x1
    5220:      	b	0x525c <generic_lsm_process_filter+0x17dc>
    5224:      	mov	w9, #0x1                // =1
    5228:      	mov	w8, w10
    522c:      	b	0x5674 <generic_lsm_process_filter+0x1bf4>
    5230:      	mov	w8, #0x1                // =1
    5234:      	ldr	w12, [sp, #0x30]
    5238:      	mov	x11, x20
    523c:      	cmp	w12, #0x6
    5240:      	eor	w8, w8, #0x1
    5244:      	csinc	w9, w8, wzr, eq
    5248:      	str	w9, [x25], #0x4
    524c:      	add	x21, x21, #0x4
    5250:      	add	x19, x19, #0x4
    5254:      	subs	x24, x24, #0x1
    5258:      	b.eq	0x562c <generic_lsm_process_filter+0x1bac>
    525c:      	cmp	x21, #0x3e8
    5260:      	b.ls	0x5484 <generic_lsm_process_filter+0x1a04>
    5264:      	mov	x29, xzr
    5268:      	tbz	w22, #0x1, 0x548c <generic_lsm_process_filter+0x1a0c>
    526c:      	tbnz	w22, #0x0, 0x54b8 <generic_lsm_process_filter+0x1a38>
    5270:      	ldr	x10, [sp, #0x48]
    5274:      	mov	w8, #0x1                // =1
    5278:      	ldr	w9, [x10]
    527c:      	cmp	x29, x9
    5280:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    5284:      	ldr	w9, [x10, #0x10]
    5288:      	cmp	x29, x9
    528c:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    5290:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5294:      	mov	w8, #0x1                // =1
    5298:      	ldr	x0, [x0]
    529c:      	ldr	x1, [sp, #0x18]
    52a0:      	blr	x8
    52a4:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    52a8:      	ldr	w9, [x0]
    52ac:      	mov	x1, x0
    52b0:      	mov	w8, #0x1                // =1
    52b4:      	cmp	x29, x9
    52b8:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    52bc:      	ldr	w9, [x1, #0x10]!
    52c0:      	ldr	w12, [sp, #0x30]
    52c4:      	mov	x11, x20
    52c8:      	cmp	x29, x9
    52cc:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    52d0:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    52d4:      	mov	w8, #0x1                // =1
    52d8:      	ldr	x0, [x0]
    52dc:      	blr	x8
    52e0:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    52e4:      	ldr	w9, [x0]
    52e8:      	mov	x1, x0
    52ec:      	mov	w8, #0x1                // =1
    52f0:      	cmp	x29, x9
    52f4:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    52f8:      	ldr	w9, [x1, #0x10]!
    52fc:      	ldr	w12, [sp, #0x30]
    5300:      	mov	x11, x20
    5304:      	cmp	x29, x9
    5308:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    530c:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5310:      	mov	w8, #0x1                // =1
    5314:      	ldr	x0, [x0]
    5318:      	blr	x8
    531c:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    5320:      	ldr	w9, [x0]
    5324:      	mov	x1, x0
    5328:      	mov	w8, #0x1                // =1
    532c:      	cmp	x29, x9
    5330:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    5334:      	ldr	w9, [x1, #0x10]!
    5338:      	ldr	w12, [sp, #0x30]
    533c:      	mov	x11, x20
    5340:      	cmp	x29, x9
    5344:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    5348:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    534c:      	mov	w8, #0x1                // =1
    5350:      	ldr	x0, [x0]
    5354:      	blr	x8
    5358:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    535c:      	ldr	w9, [x0]
    5360:      	mov	x1, x0
    5364:      	mov	w8, #0x1                // =1
    5368:      	cmp	x29, x9
    536c:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    5370:      	ldr	w9, [x1, #0x10]!
    5374:      	ldr	w12, [sp, #0x30]
    5378:      	mov	x11, x20
    537c:      	cmp	x29, x9
    5380:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    5384:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5388:      	mov	w8, #0x1                // =1
    538c:      	ldr	x0, [x0]
    5390:      	blr	x8
    5394:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    5398:      	ldr	w9, [x0]
    539c:      	mov	x1, x0
    53a0:      	mov	w8, #0x1                // =1
    53a4:      	cmp	x29, x9
    53a8:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    53ac:      	ldr	w9, [x1, #0x10]!
    53b0:      	ldr	w12, [sp, #0x30]
    53b4:      	mov	x11, x20
    53b8:      	cmp	x29, x9
    53bc:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    53c0:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    53c4:      	mov	w8, #0x1                // =1
    53c8:      	ldr	x0, [x0]
    53cc:      	blr	x8
    53d0:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    53d4:      	ldr	w9, [x0]
    53d8:      	mov	x1, x0
    53dc:      	mov	w8, #0x1                // =1
    53e0:      	cmp	x29, x9
    53e4:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    53e8:      	ldr	w9, [x1, #0x10]!
    53ec:      	ldr	w12, [sp, #0x30]
    53f0:      	mov	x11, x20
    53f4:      	cmp	x29, x9
    53f8:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    53fc:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5400:      	mov	w8, #0x1                // =1
    5404:      	ldr	x0, [x0]
    5408:      	blr	x8
    540c:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    5410:      	ldr	w9, [x0]
    5414:      	mov	x1, x0
    5418:      	mov	w8, #0x1                // =1
    541c:      	cmp	x29, x9
    5420:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    5424:      	ldr	w9, [x1, #0x10]!
    5428:      	ldr	w12, [sp, #0x30]
    542c:      	mov	x11, x20
    5430:      	cmp	x29, x9
    5434:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    5438:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    543c:      	mov	w8, #0x1                // =1
    5440:      	ldr	x0, [x0]
    5444:      	blr	x8
    5448:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    544c:      	ldr	w9, [x0]
    5450:      	mov	x1, x0
    5454:      	mov	w8, #0x1                // =1
    5458:      	cmp	x29, x9
    545c:      	b.eq	0x5234 <generic_lsm_process_filter+0x17b4>
    5460:      	ldr	w9, [x1, #0x10]!
    5464:      	ldr	w12, [sp, #0x30]
    5468:      	mov	x11, x20
    546c:      	cmp	x29, x9
    5470:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    5474:      	adrp	x9, 0x5000 <generic_lsm_process_filter+0x1580>
    5478:      	mov	w8, #0x1                // =1
    547c:      	ldr	x9, [x9]
    5480:      	b	0x5604 <generic_lsm_process_filter+0x1b84>
    5484:      	ldr	w29, [x19]
    5488:      	tbnz	w22, #0x1, 0x526c <generic_lsm_process_filter+0x17ec>
    548c:      	ldr	w8, [x11]
    5490:      	cmp	w12, #0x5
    5494:      	b.ne	0x54a8 <generic_lsm_process_filter+0x1a28>
    5498:      	cmp	x29, x8
    549c:      	b.eq	0x54a8 <generic_lsm_process_filter+0x1a28>
    54a0:      	mov	w9, wzr
    54a4:      	b	0x5248 <generic_lsm_process_filter+0x17c8>
    54a8:      	cmp	w12, #0x6
    54ac:      	ccmp	x29, x8, #0x0, eq
    54b0:      	cset	w9, ne
    54b4:      	b	0x5248 <generic_lsm_process_filter+0x17c8>
    54b8:      	ldr	x8, [sp, #0x20]
    54bc:      	ldr	w9, [x8]
    54c0:      	cbz	w9, 0x5248 <generic_lsm_process_filter+0x17c8>
    54c4:      	mov	w8, #0x1                // =1
    54c8:      	cbz	x29, 0x523c <generic_lsm_process_filter+0x17bc>
    54cc:      	cmp	x29, x9
    54d0:      	b.eq	0x523c <generic_lsm_process_filter+0x17bc>
    54d4:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    54d8:      	mov	w8, #0x1                // =1
    54dc:      	ldr	x0, [x0]
    54e0:      	ldr	x1, [sp, #0x18]
    54e4:      	blr	x8
    54e8:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    54ec:      	ldr	w8, [x0, #0x24]
    54f0:      	cmp	x29, x8
    54f4:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    54f8:      	add	x1, x0, #0x10
    54fc:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5500:      	mov	w8, #0x1                // =1
    5504:      	ldr	x0, [x0]
    5508:      	blr	x8
    550c:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    5510:      	ldr	w8, [x0, #0x24]
    5514:      	cmp	x29, x8
    5518:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    551c:      	add	x1, x0, #0x10
    5520:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5524:      	mov	w8, #0x1                // =1
    5528:      	ldr	x0, [x0]
    552c:      	blr	x8
    5530:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    5534:      	ldr	w8, [x0, #0x24]
    5538:      	cmp	x29, x8
    553c:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    5540:      	add	x1, x0, #0x10
    5544:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5548:      	mov	w8, #0x1                // =1
    554c:      	ldr	x0, [x0]
    5550:      	blr	x8
    5554:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    5558:      	ldr	w8, [x0, #0x24]
    555c:      	cmp	x29, x8
    5560:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    5564:      	add	x1, x0, #0x10
    5568:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    556c:      	mov	w8, #0x1                // =1
    5570:      	ldr	x0, [x0]
    5574:      	blr	x8
    5578:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    557c:      	ldr	w8, [x0, #0x24]
    5580:      	cmp	x29, x8
    5584:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    5588:      	add	x1, x0, #0x10
    558c:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5590:      	mov	w8, #0x1                // =1
    5594:      	ldr	x0, [x0]
    5598:      	blr	x8
    559c:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    55a0:      	ldr	w8, [x0, #0x24]
    55a4:      	cmp	x29, x8
    55a8:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    55ac:      	add	x1, x0, #0x10
    55b0:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    55b4:      	mov	w8, #0x1                // =1
    55b8:      	ldr	x0, [x0]
    55bc:      	blr	x8
    55c0:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    55c4:      	ldr	w8, [x0, #0x24]
    55c8:      	cmp	x29, x8
    55cc:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    55d0:      	add	x1, x0, #0x10
    55d4:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    55d8:      	mov	w8, #0x1                // =1
    55dc:      	ldr	x0, [x0]
    55e0:      	blr	x8
    55e4:      	cbz	x0, 0x5610 <generic_lsm_process_filter+0x1b90>
    55e8:      	ldr	w8, [x0, #0x24]
    55ec:      	cmp	x29, x8
    55f0:      	b.eq	0x5230 <generic_lsm_process_filter+0x17b0>
    55f4:      	adrp	x9, 0x5000 <generic_lsm_process_filter+0x1580>
    55f8:      	add	x1, x0, #0x10
    55fc:      	mov	w8, #0x1                // =1
    5600:      	ldr	x9, [x9]
    5604:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5608:      	ldr	x0, [x0]
    560c:      	blr	x8
    5610:      	ldr	w12, [sp, #0x30]
    5614:      	mov	w8, wzr
    5618:      	mov	w9, wzr
    561c:      	mov	x11, x20
    5620:      	cmp	w12, #0x5
    5624:      	b.ne	0x523c <generic_lsm_process_filter+0x17bc>
    5628:      	b	0x5248 <generic_lsm_process_filter+0x17c8>
    562c:      	ldp	w8, w9, [sp, #0x58]
    5630:      	ldp	w10, w11, [sp, #0x60]
    5634:      	cmp	w12, #0x6
    5638:      	b.ne	0x564c <generic_lsm_process_filter+0x1bcc>
    563c:      	and	w8, w9, w8
    5640:      	and	w9, w10, w11
    5644:      	and	w9, w8, w9
    5648:      	b	0x5658 <generic_lsm_process_filter+0x1bd8>
    564c:      	orr	w8, w9, w8
    5650:      	orr	w9, w10, w11
    5654:      	orr	w9, w8, w9
    5658:      	ldr	x8, [sp, #0x10]
    565c:      	cbz	w9, 0x5d54 <generic_lsm_process_filter+0x22d4>
    5660:      	ldr	x10, [sp, #0x8]
    5664:      	add	w8, w8, #0x14
    5668:      	ldr	w10, [x10, #0x8]
    566c:      	ubfiz	w10, w10, #2, #3
    5670:      	add	w8, w10, w8
    5674:      	and	x10, x8, #0x3ff
    5678:      	add	w8, w8, #0x4
    567c:      	mov	w19, #0xa               // =10
    5680:      	ldr	w10, [x10, x23]
    5684:      	mov	w20, #0x4               // =4
    5688:      	mov	x25, #0x100000001       // =4294967297
    568c:      	sub	w22, w10, #0x4
    5690:      	ldr	x10, [sp, #0xe8]
    5694:      	add	x10, x10, #0x20
    5698:      	str	x10, [sp, #0x30]
    569c:      	b	0x56a8 <generic_lsm_process_filter+0x1c28>
    56a0:      	subs	x19, x19, #0x1
    56a4:      	b.eq	0x5874 <generic_lsm_process_filter+0x1df4>
    56a8:      	cbz	w22, 0x56a0 <generic_lsm_process_filter+0x1c20>
    56ac:      	and	x9, x8, #0x3ff
    56b0:      	add	x10, x9, x23
    56b4:      	ldr	w29, [x10, #0x8]
    56b8:      	ldp	w9, w24, [x10]
    56bc:      	stp	xzr, xzr, [sp, #0x58]
    56c0:      	cmp	w29, #0x4
    56c4:      	csel	w10, w29, w20, lo
    56c8:      	cmp	w24, #0x6
    56cc:      	b.ne	0x56d4 <generic_lsm_process_filter+0x1c54>
    56d0:      	stp	x25, x25, [sp, #0x58]
    56d4:      	add	w21, w8, #0xc
    56d8:      	cbz	w29, 0x582c <generic_lsm_process_filter+0x1dac>
    56dc:      	and	x9, x9, #0xf
    56e0:      	cmp	w9, #0xa
    56e4:      	b.lo	0x5710 <generic_lsm_process_filter+0x1c90>
    56e8:      	sub	x8, x10, #0x1
    56ec:      	mov	w9, #0x3                // =3
    56f0:      	add	x0, sp, #0x58
    56f4:      	mov	w1, wzr
    56f8:      	cmp	x8, #0x3
    56fc:      	csel	x8, x8, x9, lo
    5700:      	lsl	x8, x8, #2
    5704:      	add	x2, x8, #0x4
    5708:      	bl	0x5708 <generic_lsm_process_filter+0x1c88>
    570c:      	b	0x582c <generic_lsm_process_filter+0x1dac>
    5710:      	cmp	w21, #0x3e8
    5714:      	b.ls	0x5720 <generic_lsm_process_filter+0x1ca0>
    5718:      	mov	w11, wzr
    571c:      	b	0x5728 <generic_lsm_process_filter+0x1ca8>
    5720:      	and	w11, w21, #0xfffffffc
    5724:      	ldr	w11, [x23, w11, uxtw]
    5728:      	ldr	x12, [sp, #0x30]
    572c:      	cmp	w24, #0x5
    5730:      	sub	x10, x10, #0x1
    5734:      	ldr	w9, [x12, x9, lsl #2]
    5738:      	cset	w12, ne
    573c:      	cmp	w24, #0x6
    5740:      	cset	w13, ne
    5744:      	cmp	w11, w9
    5748:      	csinc	w11, w12, wzr, ne
    574c:      	csinc	w12, w13, wzr, eq
    5750:      	and	w11, w11, w12
    5754:      	str	w11, [sp, #0x58]
    5758:      	cbz	x10, 0x582c <generic_lsm_process_filter+0x1dac>
    575c:      	add	w11, w8, #0x10
    5760:      	cmp	w11, #0x3e8
    5764:      	b.ls	0x5770 <generic_lsm_process_filter+0x1cf0>
    5768:      	mov	w11, wzr
    576c:      	b	0x5778 <generic_lsm_process_filter+0x1cf8>
    5770:      	and	w11, w11, #0xfffffffc
    5774:      	ldr	w11, [x23, w11, uxtw]
    5778:      	cmp	w24, #0x5
    577c:      	cset	w12, ne
    5780:      	cmp	w24, #0x6
    5784:      	cset	w13, ne
    5788:      	cmp	w11, w9
    578c:      	csinc	w11, w12, wzr, ne
    5790:      	csinc	w12, w13, wzr, eq
    5794:      	cmp	x10, #0x1
    5798:      	and	w11, w11, w12
    579c:      	str	w11, [sp, #0x5c]
    57a0:      	b.eq	0x582c <generic_lsm_process_filter+0x1dac>
    57a4:      	add	w11, w8, #0x14
    57a8:      	cmp	w11, #0x3e8
    57ac:      	b.ls	0x57b8 <generic_lsm_process_filter+0x1d38>
    57b0:      	mov	w11, wzr
    57b4:      	b	0x57c0 <generic_lsm_process_filter+0x1d40>
    57b8:      	and	w11, w11, #0xfffffffc
    57bc:      	ldr	w11, [x23, w11, uxtw]
    57c0:      	cmp	w24, #0x5
    57c4:      	cset	w12, ne
    57c8:      	cmp	w24, #0x6
    57cc:      	cset	w13, ne
    57d0:      	cmp	w11, w9
    57d4:      	csinc	w11, w12, wzr, ne
    57d8:      	csinc	w12, w13, wzr, eq
    57dc:      	cmp	x10, #0x2
    57e0:      	and	w11, w11, w12
    57e4:      	str	w11, [sp, #0x60]
    57e8:      	b.eq	0x582c <generic_lsm_process_filter+0x1dac>
    57ec:      	add	w8, w8, #0x18
    57f0:      	cmp	w8, #0x3e8
    57f4:      	b.ls	0x5800 <generic_lsm_process_filter+0x1d80>
    57f8:      	mov	w8, wzr
    57fc:      	b	0x5808 <generic_lsm_process_filter+0x1d88>
    5800:      	and	w8, w8, #0xfffffffc
    5804:      	ldr	w8, [x23, w8, uxtw]
    5808:      	cmp	w24, #0x5
    580c:      	cset	w10, ne
    5810:      	cmp	w24, #0x6
    5814:      	cset	w11, ne
    5818:      	cmp	w8, w9
    581c:      	csinc	w8, w10, wzr, ne
    5820:      	csinc	w9, w11, wzr, eq
    5824:      	and	w8, w8, w9
    5828:      	str	w8, [sp, #0x64]
    582c:      	ldp	w8, w9, [sp, #0x58]
    5830:      	ldp	w10, w11, [sp, #0x60]
    5834:      	cmp	w24, #0x6
    5838:      	b.ne	0x584c <generic_lsm_process_filter+0x1dcc>
    583c:      	and	w8, w9, w8
    5840:      	and	w9, w10, w11
    5844:      	and	w9, w8, w9
    5848:      	b	0x5858 <generic_lsm_process_filter+0x1dd8>
    584c:      	orr	w8, w9, w8
    5850:      	orr	w9, w10, w11
    5854:      	orr	w9, w8, w9
    5858:      	cbz	w9, 0x5d54 <generic_lsm_process_filter+0x22d4>
    585c:      	lsl	w8, w29, #2
    5860:      	sub	w10, w22, w29, lsl #2
    5864:      	and	w8, w8, #0x1c
    5868:      	sub	w22, w10, #0xc
    586c:      	add	w8, w8, w21
    5870:      	b	0x56a0 <generic_lsm_process_filter+0x1c20>
    5874:      	mov	w10, w8
    5878:      	add	w19, w8, #0x4
    587c:      	and	x10, x10, #0x3ff
    5880:      	ldr	w10, [x10, x23]
    5884:      	cmp	w10, #0x4
    5888:      	b.ne	0x5920 <generic_lsm_process_filter+0x1ea0>
    588c:      	cbz	w9, 0x5d54 <generic_lsm_process_filter+0x22d4>
    5890:      	mov	w8, w19
    5894:      	and	x8, x8, #0x3ff
    5898:      	ldr	w9, [x8, x23]
    589c:      	add	w8, w19, #0x4
    58a0:      	cmp	w9, #0x4
    58a4:      	mov	w9, w8
    58a8:      	b.eq	0x5c50 <generic_lsm_process_filter+0x21d0>
    58ac:      	and	x8, x8, #0x3ff
    58b0:      	add	x8, x8, x23
    58b4:      	ldp	w20, w22, [x8]
    58b8:      	mov	w8, #0xe                // =14
    58bc:      	blr	x8
    58c0:      	lsr	x8, x0, #32
    58c4:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    58c8:      	add	x9, sp, #0x58
    58cc:      	str	w8, [sp, #0x58]
    58d0:      	mov	w8, #0x1                // =1
    58d4:      	add	x1, sp, #0x58
    58d8:      	ldr	x0, [x0]
    58dc:      	blr	x8
    58e0:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    58e4:      	cmp	w20, #0x5
    58e8:      	b.eq	0x599c <generic_lsm_process_filter+0x1f1c>
    58ec:      	cmp	w20, #0x6
    58f0:      	b.ne	0x5d54 <generic_lsm_process_filter+0x22d4>
    58f4:      	ldr	x11, [sp, #0xe8]
    58f8:      	mov	w8, #0x5ee8             // =24296
    58fc:      	add	x8, x11, x8
    5900:      	tbnz	w22, #0x0, 0x59d0 <generic_lsm_process_filter+0x1f50>
    5904:      	ldr	w9, [x0, #0x28]
    5908:      	cbz	w9, 0x59c8 <generic_lsm_process_filter+0x1f48>
    590c:      	ldr	x10, [sp, #0x30]
    5910:      	ldr	w10, [x10]
    5914:      	cmp	w9, w10
    5918:      	b.eq	0x59d0 <generic_lsm_process_filter+0x1f50>
    591c:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5920:      	and	x9, x19, #0x3ff
    5924:      	add	w19, w8, #0x18
    5928:      	add	x9, x9, x23
    592c:      	ldp	w8, w10, [x9]
    5930:      	ldr	w12, [x9, #0x8]
    5934:      	ldur	x11, [x9, #0xc]
    5938:      	cbz	w12, 0x595c <generic_lsm_process_filter+0x1edc>
    593c:      	ldr	x14, [sp, #0xe8]
    5940:      	mov	w9, wzr
    5944:      	cmp	w8, #0x2
    5948:      	b.hi	0x588c <generic_lsm_process_filter+0x1e0c>
    594c:      	ldr	w13, [x14, #0x44]
    5950:      	cmp	w13, w12
    5954:      	b.ne	0x5970 <generic_lsm_process_filter+0x1ef0>
    5958:      	b	0x588c <generic_lsm_process_filter+0x1e0c>
    595c:      	ldr	x14, [sp, #0xe8]
    5960:      	cmp	w8, #0x2
    5964:      	b.ls	0x5970 <generic_lsm_process_filter+0x1ef0>
    5968:      	mov	w9, wzr
    596c:      	b	0x588c <generic_lsm_process_filter+0x1e0c>
    5970:      	add	x9, x14, #0x48
    5974:      	cmp	w10, #0x5
    5978:      	ldr	x8, [x9, x8, lsl #3]
    597c:      	and	x8, x8, x11
    5980:      	b.ne	0x5990 <generic_lsm_process_filter+0x1f10>
    5984:      	cmp	x8, #0x0
    5988:      	cset	w9, ne
    598c:      	b	0x588c <generic_lsm_process_filter+0x1e0c>
    5990:      	cmp	x8, #0x0
    5994:      	cset	w9, eq
    5998:      	b	0x588c <generic_lsm_process_filter+0x1e0c>
    599c:      	ldr	x11, [sp, #0xe8]
    59a0:      	mov	w8, #0x5ee8             // =24296
    59a4:      	add	x8, x11, x8
    59a8:      	tbz	w22, #0x0, 0x59f4 <generic_lsm_process_filter+0x1f74>
    59ac:      	ldr	w9, [x0, #0x28]
    59b0:      	cbz	w9, 0x59ec <generic_lsm_process_filter+0x1f6c>
    59b4:      	ldr	x10, [sp, #0x30]
    59b8:      	ldr	w10, [x10]
    59bc:      	cmp	w9, w10
    59c0:      	b.eq	0x59f4 <generic_lsm_process_filter+0x1f74>
    59c4:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    59c8:      	mov	w9, #0x1                // =1
    59cc:      	str	x9, [x8]
    59d0:      	tbnz	w22, #0x1, 0x5a18 <generic_lsm_process_filter+0x1f98>
    59d4:      	ldr	w9, [x0, #0x2c]
    59d8:      	cbz	w9, 0x5a10 <generic_lsm_process_filter+0x1f90>
    59dc:      	ldr	w10, [x11, #0x24]
    59e0:      	cmp	w9, w10
    59e4:      	b.eq	0x5a18 <generic_lsm_process_filter+0x1f98>
    59e8:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    59ec:      	mov	w9, #0x1                // =1
    59f0:      	str	x9, [x8]
    59f4:      	tbz	w22, #0x1, 0x5a3c <generic_lsm_process_filter+0x1fbc>
    59f8:      	ldr	w9, [x0, #0x2c]
    59fc:      	cbz	w9, 0x5a34 <generic_lsm_process_filter+0x1fb4>
    5a00:      	ldr	w10, [x11, #0x24]
    5a04:      	cmp	w9, w10
    5a08:      	b.eq	0x5a3c <generic_lsm_process_filter+0x1fbc>
    5a0c:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5a10:      	mov	w9, #0x1                // =1
    5a14:      	str	x9, [x8]
    5a18:      	tbnz	w22, #0x2, 0x5a60 <generic_lsm_process_filter+0x1fe0>
    5a1c:      	ldr	w9, [x0, #0x30]
    5a20:      	cbz	w9, 0x5a58 <generic_lsm_process_filter+0x1fd8>
    5a24:      	ldr	w10, [x11, #0x28]
    5a28:      	cmp	w9, w10
    5a2c:      	b.eq	0x5a60 <generic_lsm_process_filter+0x1fe0>
    5a30:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5a34:      	mov	w9, #0x1                // =1
    5a38:      	str	x9, [x8]
    5a3c:      	tbz	w22, #0x2, 0x5a84 <generic_lsm_process_filter+0x2004>
    5a40:      	ldr	w9, [x0, #0x30]
    5a44:      	cbz	w9, 0x5a7c <generic_lsm_process_filter+0x1ffc>
    5a48:      	ldr	w10, [x11, #0x28]
    5a4c:      	cmp	w9, w10
    5a50:      	b.eq	0x5a84 <generic_lsm_process_filter+0x2004>
    5a54:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5a58:      	mov	w9, #0x1                // =1
    5a5c:      	str	x9, [x8]
    5a60:      	tbnz	w22, #0x3, 0x5aa8 <generic_lsm_process_filter+0x2028>
    5a64:      	ldr	w9, [x0, #0x34]
    5a68:      	cbz	w9, 0x5aa0 <generic_lsm_process_filter+0x2020>
    5a6c:      	ldr	w10, [x11, #0x2c]
    5a70:      	cmp	w9, w10
    5a74:      	b.eq	0x5aa8 <generic_lsm_process_filter+0x2028>
    5a78:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5a7c:      	mov	w9, #0x1                // =1
    5a80:      	str	x9, [x8]
    5a84:      	tbz	w22, #0x3, 0x5acc <generic_lsm_process_filter+0x204c>
    5a88:      	ldr	w9, [x0, #0x34]
    5a8c:      	cbz	w9, 0x5ac4 <generic_lsm_process_filter+0x2044>
    5a90:      	ldr	w10, [x11, #0x2c]
    5a94:      	cmp	w9, w10
    5a98:      	b.eq	0x5acc <generic_lsm_process_filter+0x204c>
    5a9c:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5aa0:      	mov	w9, #0x1                // =1
    5aa4:      	str	x9, [x8]
    5aa8:      	tbnz	w22, #0x4, 0x5af0 <generic_lsm_process_filter+0x2070>
    5aac:      	ldr	w9, [x0, #0x38]
    5ab0:      	cbz	w9, 0x5ae8 <generic_lsm_process_filter+0x2068>
    5ab4:      	ldr	w10, [x11, #0x30]
    5ab8:      	cmp	w9, w10
    5abc:      	b.eq	0x5af0 <generic_lsm_process_filter+0x2070>
    5ac0:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5ac4:      	mov	w9, #0x1                // =1
    5ac8:      	str	x9, [x8]
    5acc:      	tbz	w22, #0x4, 0x5b14 <generic_lsm_process_filter+0x2094>
    5ad0:      	ldr	w9, [x0, #0x38]
    5ad4:      	cbz	w9, 0x5b0c <generic_lsm_process_filter+0x208c>
    5ad8:      	ldr	w10, [x11, #0x30]
    5adc:      	cmp	w9, w10
    5ae0:      	b.eq	0x5b14 <generic_lsm_process_filter+0x2094>
    5ae4:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5ae8:      	mov	w9, #0x1                // =1
    5aec:      	str	x9, [x8]
    5af0:      	tbnz	w22, #0x5, 0x5b38 <generic_lsm_process_filter+0x20b8>
    5af4:      	ldr	w9, [x0, #0x3c]
    5af8:      	cbz	w9, 0x5b30 <generic_lsm_process_filter+0x20b0>
    5afc:      	ldr	w10, [x11, #0x34]
    5b00:      	cmp	w9, w10
    5b04:      	b.eq	0x5b38 <generic_lsm_process_filter+0x20b8>
    5b08:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5b0c:      	mov	w9, #0x1                // =1
    5b10:      	str	x9, [x8]
    5b14:      	tbz	w22, #0x5, 0x5b5c <generic_lsm_process_filter+0x20dc>
    5b18:      	ldr	w9, [x0, #0x3c]
    5b1c:      	cbz	w9, 0x5b54 <generic_lsm_process_filter+0x20d4>
    5b20:      	ldr	w10, [x11, #0x34]
    5b24:      	cmp	w9, w10
    5b28:      	b.eq	0x5b5c <generic_lsm_process_filter+0x20dc>
    5b2c:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5b30:      	mov	w9, #0x1                // =1
    5b34:      	str	x9, [x8]
    5b38:      	tbnz	w22, #0x6, 0x5b80 <generic_lsm_process_filter+0x2100>
    5b3c:      	ldr	w9, [x0, #0x40]
    5b40:      	cbz	w9, 0x5b78 <generic_lsm_process_filter+0x20f8>
    5b44:      	ldr	w10, [x11, #0x38]
    5b48:      	cmp	w9, w10
    5b4c:      	b.eq	0x5b80 <generic_lsm_process_filter+0x2100>
    5b50:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5b54:      	mov	w9, #0x1                // =1
    5b58:      	str	x9, [x8]
    5b5c:      	tbz	w22, #0x6, 0x5ba4 <generic_lsm_process_filter+0x2124>
    5b60:      	ldr	w9, [x0, #0x40]
    5b64:      	cbz	w9, 0x5b9c <generic_lsm_process_filter+0x211c>
    5b68:      	ldr	w10, [x11, #0x38]
    5b6c:      	cmp	w9, w10
    5b70:      	b.eq	0x5ba4 <generic_lsm_process_filter+0x2124>
    5b74:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5b78:      	mov	w9, #0x1                // =1
    5b7c:      	str	x9, [x8]
    5b80:      	tbnz	w22, #0x7, 0x5bc8 <generic_lsm_process_filter+0x2148>
    5b84:      	ldr	w9, [x0, #0x44]
    5b88:      	cbz	w9, 0x5bc0 <generic_lsm_process_filter+0x2140>
    5b8c:      	ldr	w10, [x11, #0x3c]
    5b90:      	cmp	w9, w10
    5b94:      	b.eq	0x5bc8 <generic_lsm_process_filter+0x2148>
    5b98:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5b9c:      	mov	w9, #0x1                // =1
    5ba0:      	str	x9, [x8]
    5ba4:      	tbz	w22, #0x7, 0x5bf0 <generic_lsm_process_filter+0x2170>
    5ba8:      	ldr	w9, [x0, #0x44]
    5bac:      	cbz	w9, 0x5be8 <generic_lsm_process_filter+0x2168>
    5bb0:      	ldr	w10, [x11, #0x3c]
    5bb4:      	cmp	w9, w10
    5bb8:      	b.eq	0x5bf0 <generic_lsm_process_filter+0x2170>
    5bbc:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5bc0:      	mov	w9, #0x1                // =1
    5bc4:      	str	x9, [x8]
    5bc8:      	tbnz	w22, #0x8, 0x5c18 <generic_lsm_process_filter+0x2198>
    5bcc:      	ldr	w9, [x0, #0x48]
    5bd0:      	cbz	w9, 0x5c10 <generic_lsm_process_filter+0x2190>
    5bd4:      	ldr	x10, [sp, #0xe8]
    5bd8:      	ldr	w10, [x10, #0x40]
    5bdc:      	cmp	w9, w10
    5be0:      	b.eq	0x5c18 <generic_lsm_process_filter+0x2198>
    5be4:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5be8:      	mov	w9, #0x1                // =1
    5bec:      	str	x9, [x8]
    5bf0:      	tbz	w22, #0x8, 0x5c28 <generic_lsm_process_filter+0x21a8>
    5bf4:      	ldr	w9, [x0, #0x48]
    5bf8:      	cbz	w9, 0x5c20 <generic_lsm_process_filter+0x21a0>
    5bfc:      	ldr	x10, [sp, #0xe8]
    5c00:      	ldr	w10, [x10, #0x40]
    5c04:      	cmp	w9, w10
    5c08:      	b.eq	0x5c28 <generic_lsm_process_filter+0x21a8>
    5c0c:      	b	0x5c44 <generic_lsm_process_filter+0x21c4>
    5c10:      	mov	w9, #0x1                // =1
    5c14:      	str	x9, [x8]
    5c18:      	tbz	w22, #0x9, 0x5c2c <generic_lsm_process_filter+0x21ac>
    5c1c:      	b	0x5d54 <generic_lsm_process_filter+0x22d4>
    5c20:      	mov	w9, #0x1                // =1
    5c24:      	str	x9, [x8]
    5c28:      	tbz	w22, #0x9, 0x5d54 <generic_lsm_process_filter+0x22d4>
    5c2c:      	ldr	w9, [x0, #0x4c]
    5c30:      	cbz	w9, 0x5d4c <generic_lsm_process_filter+0x22cc>
    5c34:      	ldr	x10, [sp, #0xe8]
    5c38:      	ldr	w10, [x10, #0x44]
    5c3c:      	cmp	w9, w10
    5c40:      	b.eq	0x5d54 <generic_lsm_process_filter+0x22d4>
    5c44:      	add	w9, w19, #0xc
    5c48:      	mov	w10, #0x1               // =1
    5c4c:      	str	x10, [x8]
    5c50:      	and	x8, x9, #0x3ff
    5c54:      	adrp	x24, 0x5000 <generic_lsm_process_filter+0x1580>
    5c58:      	ldr	w8, [x8, x23]
    5c5c:      	ldr	x24, [x24]
    5c60:      	cmp	w8, #0x4
    5c64:      	b.ne	0x5c98 <generic_lsm_process_filter+0x2218>
    5c68:      	ldr	x9, [sp, #0xe8]
    5c6c:      	mov	w8, #0x5eb8             // =24248
    5c70:      	add	x8, x9, x8
    5c74:      	ldr	x9, [x9, #0x5eb8]
    5c78:      	and	x9, x9, #0x1f
    5c7c:      	add	x8, x8, x9
    5c80:      	mov	w9, #0x1                // =1
    5c84:      	strb	w9, [x8, #0x9]
    5c88:      	ldr	x8, [sp, #0x40]
    5c8c:      	strb	w9, [x8, #0x20]
    5c90:      	strb	w9, [x8]
    5c94:      	b	0x5d54 <generic_lsm_process_filter+0x22d4>
    5c98:      	add	w8, w9, #0x4
    5c9c:      	and	x8, x8, #0x3ff
    5ca0:      	add	x8, x8, x23
    5ca4:      	ldp	w21, w19, [x8]
    5ca8:      	ldr	w22, [x8, #0x8]
    5cac:      	ldur	x20, [x8, #0xc]
    5cb0:      	mov	w8, #0xe                // =14
    5cb4:      	blr	x8
    5cb8:      	lsr	x8, x0, #32
    5cbc:      	add	x9, sp, #0x58
    5cc0:      	add	x1, sp, #0x58
    5cc4:      	str	w8, [sp, #0x58]
    5cc8:      	mov	w8, #0x1                // =1
    5ccc:      	mov	x0, x24
    5cd0:      	blr	x8
    5cd4:      	cbz	x0, 0x5d54 <generic_lsm_process_filter+0x22d4>
    5cd8:      	cmp	w21, #0x2
    5cdc:      	cbz	w22, 0x5cf8 <generic_lsm_process_filter+0x2278>
    5ce0:      	b.hi	0x5d54 <generic_lsm_process_filter+0x22d4>
    5ce4:      	ldr	x8, [sp, #0xe8]
    5ce8:      	ldr	w8, [x8, #0x44]
    5cec:      	cmp	w8, w22
    5cf0:      	b.ne	0x5cfc <generic_lsm_process_filter+0x227c>
    5cf4:      	b	0x5d54 <generic_lsm_process_filter+0x22d4>
    5cf8:      	b.hi	0x5d54 <generic_lsm_process_filter+0x22d4>
    5cfc:      	ldr	x8, [sp, #0xe8]
    5d00:      	lsl	x10, x21, #3
    5d04:      	add	x9, x8, #0x48
    5d08:      	add	x8, x0, x21, lsl #3
    5d0c:      	ldr	x8, [x8, #0x50]
    5d10:      	ldr	x9, [x9, x10]
    5d14:      	eor	x10, x9, x8
    5d18:      	tst	x10, x20
    5d1c:      	b.eq	0x5d2c <generic_lsm_process_filter+0x22ac>
    5d20:      	cmp	w19, #0x5
    5d24:      	b.eq	0x5d3c <generic_lsm_process_filter+0x22bc>
    5d28:      	b	0x5d54 <generic_lsm_process_filter+0x22d4>
    5d2c:      	cmp	x8, x9
    5d30:      	b.eq	0x5d54 <generic_lsm_process_filter+0x22d4>
    5d34:      	cmp	w19, #0x6
    5d38:      	b.ne	0x5d54 <generic_lsm_process_filter+0x22d4>
    5d3c:      	ldr	x9, [sp, #0xe8]
    5d40:      	mov	w8, #0x1                // =1
    5d44:      	str	x8, [x9, #0x5ef0]
    5d48:      	b	0x5c68 <generic_lsm_process_filter+0x21e8>
    5d4c:      	mov	w9, #0x1                // =1
    5d50:      	str	x9, [x8]
    5d54:      	ldr	x9, [sp, #0xe8]
    5d58:      	ldr	x10, [sp, #0x28]
    5d5c:      	ldr	x8, [x9, #0x5eb8]
    5d60:      	add	x8, x8, #0x1
    5d64:      	cmp	x8, x10
    5d68:      	str	x8, [x9, #0x5eb8]
    5d6c:      	b.ls	0x5dcc <generic_lsm_process_filter+0x234c>
    5d70:      	ldr	x10, [sp, #0x48]
    5d74:      	ldr	w8, [x10]
    5d78:      	str	w8, [x9, #0x10]
    5d7c:      	ldr	x8, [x10, #0x8]
    5d80:      	str	x8, [x9, #0x18]
    5d84:      	ldp	x20, x8, [sp, #0x38]
    5d88:      	ldrb	w8, [x8]
    5d8c:      	cbz	w8, 0x5dac <generic_lsm_process_filter+0x232c>
    5d90:      	adrp	x1, 0x5000 <generic_lsm_process_filter+0x1580>
    5d94:      	mov	x8, xzr
    5d98:      	mov	w9, #0xc                // =12
    5d9c:      	ldr	x1, [x1]
    5da0:      	mov	x0, x20
    5da4:      	mov	w2, wzr
    5da8:      	blr	x9
    5dac:      	ldp	x20, x19, [sp, #0x120]
    5db0:      	mov	w0, wzr
    5db4:      	ldr	x29, [sp, #0xe0]
    5db8:      	ldp	x22, x21, [sp, #0x110]
    5dbc:      	ldp	x24, x23, [sp, #0x100]
    5dc0:      	ldp	x30, x25, [sp, #0xf0]
    5dc4:      	add	sp, sp, #0x130
    5dc8:      	ret
    5dcc:      	adrp	x1, 0x5000 <generic_lsm_process_filter+0x1580>
    5dd0:      	mov	w8, #0x2                // =2
    5dd4:      	mov	w9, #0xc                // =12
    5dd8:      	ldr	x1, [x1]
    5ddc:      	ldr	x0, [sp, #0x38]
    5de0:      	mov	w2, #0x2                // =2
    5de4:      	b	0x5da8 <generic_lsm_process_filter+0x2328>
    5de8:      	nop
    5dec:      	nop

0000000000005df0 <generic_lsm_filter_arg>:
    5df0:      	sub	sp, sp, #0xf0
    5df4:      	str	x29, [sp, #0xa0]
    5df8:      	stp	x30, x25, [sp, #0xb0]
    5dfc:      	stp	x24, x23, [sp, #0xc0]
    5e00:      	stp	x22, x21, [sp, #0xd0]
    5e04:      	stp	x20, x19, [sp, #0xe0]
    5e08:      	mov	x19, x0
    5e0c:      	str	wzr, [sp, #0xa8]
    5e10:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5e14:      	mov	w8, #0x1                // =1
    5e18:      	ldr	x0, [x0]
    5e1c:      	add	x9, sp, #0xa8
    5e20:      	add	x1, sp, #0xa8
    5e24:      	blr	x8
    5e28:      	cbz	x0, 0x5f98 <generic_lsm_filter_arg+0x1a8>
    5e2c:      	mov	w8, #0x5ec1             // =24257
    5e30:      	mov	x20, x0
    5e34:      	add	x22, x0, x8
    5e38:      	mov	w8, #0x5ef8             // =24312
    5e3c:      	add	x1, x0, x8
    5e40:      	adrp	x0, 0x5000 <generic_lsm_process_filter+0x1580>
    5e44:      	ldur	w23, [x22, #0x3f]
    5e48:      	mov	w8, #0x1                // =1
    5e4c:      	ldr	x0, [x0]
    5e50:      	blr	x8
    5e54:      	cbz	x0, 0x5f7c <generic_lsm_filter_arg+0x18c>
    5e58:      	ldrb	w8, [x22, #0x1f]
    5e5c:      	cbz	w8, 0x5f7c <generic_lsm_filter_arg+0x18c>
    5e60:      	and	x8, x23, #0x7
    5e64:      	mov	w10, #0x5ec1            // =24257
    5e68:      	stp	x23, x22, [sp, #0x50]
    5e6c:      	add	x9, x20, x8
    5e70:      	ldrb	w9, [x9, x10]
    5e74:      	cbz	w9, 0x5eec <generic_lsm_filter_arg+0xfc>
    5e78:      	lsl	w8, w8, #2
    5e7c:      	mov	x21, x0
    5e80:      	add	x8, x8, #0x4
    5e84:      	ldr	w9, [x8, x0]
    5e88:      	add	x8, x8, x9
    5e8c:      	add	x8, x8, #0x4
    5e90:      	and	x9, x8, #0x3ff
    5e94:      	ldr	w9, [x9, x0]
    5e98:      	add	x8, x8, x9
    5e9c:      	and	x9, x8, #0x3ff
    5ea0:      	ldr	w9, [x9, x0]
    5ea4:      	add	x8, x8, x9
    5ea8:      	and	x9, x8, #0x3ff
    5eac:      	ldr	w9, [x9, x0]
    5eb0:      	add	x8, x8, x9
    5eb4:      	and	x9, x8, #0x3ff
    5eb8:      	ldr	w9, [x9, x0]
    5ebc:      	add	x8, x8, x9
    5ec0:      	and	x9, x8, #0x3ff
    5ec4:      	ldr	w9, [x9, x0]
    5ec8:      	add	x16, x8, x9
    5ecc:      	and	x15, x16, #0x3ff
    5ed0:      	add	x17, x0, x15
    5ed4:      	ldr	w8, [x17]
    5ed8:      	cmp	w8, #0x19
    5edc:      	b.hs	0x5f40 <generic_lsm_filter_arg+0x150>
    5ee0:      	cmp	w15, #0x1
    5ee4:      	b.eq	0x5f7c <generic_lsm_filter_arg+0x18c>
    5ee8:      	cbnz	w15, 0x5f58 <generic_lsm_filter_arg+0x168>
    5eec:      	ldr	x8, [sp, #0x50]
    5ef0:      	cmp	w8, #0x1
    5ef4:      	b.gt	0x5f14 <generic_lsm_filter_arg+0x124>
    5ef8:      	ldr	x9, [sp, #0x58]
    5efc:      	cmn	w8, #0x1
    5f00:      	b.eq	0x5fb8 <generic_lsm_filter_arg+0x1c8>
    5f04:      	cbz	w8, 0x5fc8 <generic_lsm_filter_arg+0x1d8>
    5f08:      	cmp	w8, #0x1
    5f0c:      	b.eq	0x5fd8 <generic_lsm_filter_arg+0x1e8>
    5f10:      	b	0x5f30 <generic_lsm_filter_arg+0x140>
    5f14:      	ldr	x9, [sp, #0x58]
    5f18:      	cmp	w8, #0x2
    5f1c:      	b.eq	0x5fe8 <generic_lsm_filter_arg+0x1f8>
    5f20:      	cmp	w8, #0x3
    5f24:      	b.eq	0x5ff8 <generic_lsm_filter_arg+0x208>
    5f28:      	cmp	w8, #0x4
    5f2c:      	b.eq	0x6008 <generic_lsm_filter_arg+0x218>
    5f30:      	cmp	w8, #0x4
    5f34:      	b.gt	0x6034 <generic_lsm_filter_arg+0x244>
    5f38:      	add	w8, w8, #0x1
    5f3c:      	b	0x6014 <generic_lsm_filter_arg+0x224>
    5f40:      	mov	x24, xzr
    5f44:      	mov	w2, #0x5ea0             // =24224
    5f48:      	mov	w12, #0x1               // =1
    5f4c:      	stp	x19, x17, [sp, #0x30]
    5f50:      	stp	x16, x15, [sp, #0x40]
    5f54:      	b	0x6094 <generic_lsm_filter_arg+0x2a4>
    5f58:      	ldr	x8, [sp, #0x58]
    5f5c:      	adrp	x1, 0x5000 <generic_lsm_process_filter+0x1580>
    5f60:      	mov	w9, #0xc                // =12
    5f64:      	mov	x0, x19
    5f68:      	stur	w15, [x8, #0x43]
    5f6c:      	mov	w8, #0x4                // =4
    5f70:      	mov	w2, #0x4                // =4
    5f74:      	ldr	x1, [x1]
    5f78:      	blr	x9
    5f7c:      	adrp	x1, 0x5000 <generic_lsm_process_filter+0x1580>
    5f80:      	mov	w8, #0x5                // =5
    5f84:      	mov	w9, #0xc                // =12
    5f88:      	ldr	x1, [x1]
    5f8c:      	mov	x0, x19
    5f90:      	mov	w2, #0x5                // =5
    5f94:      	blr	x9
    5f98:      	ldp	x20, x19, [sp, #0xe0]
    5f9c:      	mov	w0, wzr
    5fa0:      	ldr	x29, [sp, #0xa0]
    5fa4:      	ldp	x22, x21, [sp, #0xd0]
    5fa8:      	ldp	x24, x23, [sp, #0xc0]
    5fac:      	ldp	x30, x25, [sp, #0xb0]
    5fb0:      	add	sp, sp, #0xf0
    5fb4:      	ret
    5fb8:      	ldrb	w8, [x9]
    5fbc:      	cbz	w8, 0x5fc8 <generic_lsm_filter_arg+0x1d8>
    5fc0:      	mov	w8, wzr
    5fc4:      	b	0x6014 <generic_lsm_filter_arg+0x224>
    5fc8:      	ldrb	w8, [x9, #0x1]
    5fcc:      	cbz	w8, 0x5fd8 <generic_lsm_filter_arg+0x1e8>
    5fd0:      	mov	w8, #0x1                // =1
    5fd4:      	b	0x6014 <generic_lsm_filter_arg+0x224>
    5fd8:      	ldrb	w8, [x9, #0x2]
    5fdc:      	cbz	w8, 0x5fe8 <generic_lsm_filter_arg+0x1f8>
    5fe0:      	mov	w8, #0x2                // =2
    5fe4:      	b	0x6014 <generic_lsm_filter_arg+0x224>
    5fe8:      	ldrb	w8, [x9, #0x3]
    5fec:      	cbz	w8, 0x5ff8 <generic_lsm_filter_arg+0x208>
    5ff0:      	mov	w8, #0x3                // =3
    5ff4:      	b	0x6014 <generic_lsm_filter_arg+0x224>
    5ff8:      	ldrb	w8, [x9, #0x4]
    5ffc:      	cbz	w8, 0x6008 <generic_lsm_filter_arg+0x218>
    6000:      	mov	w8, #0x4                // =4
    6004:      	b	0x6014 <generic_lsm_filter_arg+0x224>
    6008:      	ldrb	w8, [x9, #0x5]
    600c:      	cbz	w8, 0x6034 <generic_lsm_filter_arg+0x244>
    6010:      	mov	w8, #0x5                // =5
    6014:      	stur	w8, [x9, #0x3f]
    6018:      	adrp	x1, 0x6000 <generic_lsm_filter_arg+0x210>
    601c:      	mov	w8, #0x3                // =3
    6020:      	mov	w9, #0xc                // =12
    6024:      	ldr	x1, [x1]
    6028:      	mov	x0, x19
    602c:      	mov	w2, #0x3                // =3
    6030:      	blr	x9
    6034:      	ldr	x19, [x20, #0x60]
    6038:      	mov	w8, #0xe                // =14
    603c:      	blr	x8
    6040:      	stp	x19, x0, [sp, #0x60]
    6044:      	adrp	x19, 0x6000 <generic_lsm_filter_arg+0x210>
    6048:      	mov	w8, #0x1                // =1
    604c:      	add	x9, sp, #0x60
    6050:      	add	x1, sp, #0x60
    6054:      	ldr	x19, [x19]
    6058:      	mov	x0, x19
    605c:      	blr	x8
    6060:      	cbz	x0, 0x5f98 <generic_lsm_filter_arg+0x1a8>
    6064:      	mov	w8, #0x3                // =3
    6068:      	add	x9, sp, #0x60
    606c:      	add	x1, sp, #0x60
    6070:      	mov	x0, x19
    6074:      	blr	x8
    6078:      	b	0x5f98 <generic_lsm_filter_arg+0x1a8>
    607c:      	cmp	w8, #0x3
    6080:      	cset	w22, eq
    6084:      	cbz	x22, 0x5eec <generic_lsm_filter_arg+0xfc>
    6088:      	add	x24, x24, #0x1
    608c:      	cmp	x24, #0x5
    6090:      	b.eq	0x5ee0 <generic_lsm_filter_arg+0xf0>
    6094:      	add	x8, x17, x24, lsl #2
    6098:      	ldr	w8, [x8, #0x4]
    609c:      	tst	w8, #0x3ff
    60a0:      	b.eq	0x5ee0 <generic_lsm_filter_arg+0xf0>
    60a4:      	add	w8, w16, w8
    60a8:      	and	x8, x8, #0x3ff
    60ac:      	add	x23, x21, x8
    60b0:      	ldr	w8, [x23, #0x4]
    60b4:      	cmp	w8, #0x23
    60b8:      	b.eq	0x5eec <generic_lsm_filter_arg+0xfc>
    60bc:      	ldr	w9, [x23]
    60c0:      	cmp	w9, #0x4
    60c4:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    60c8:      	add	x10, x20, x9, lsl #2
    60cc:      	ldr	w10, [x10, x2]
    60d0:      	cbnz	w10, 0x5eec <generic_lsm_filter_arg+0xfc>
    60d4:      	add	x9, x20, x9, lsl #3
    60d8:      	ldr	x9, [x9, #0x5e78]
    60dc:      	and	x9, x9, #0x7ff
    60e0:      	add	x9, x20, x9
    60e4:      	add	x25, x9, #0x90
    60e8:      	ldr	w9, [x23, #0xc]
    60ec:      	cmp	w9, #0x1b
    60f0:      	b.le	0x6114 <generic_lsm_filter_arg+0x324>
    60f4:      	cmp	w9, #0x25
    60f8:      	b.gt	0x6144 <generic_lsm_filter_arg+0x354>
    60fc:      	sub	w10, w9, #0x1c
    6100:      	cmp	w10, #0x9
    6104:      	b.lo	0x6188 <generic_lsm_filter_arg+0x398>
    6108:      	cmp	w9, #0x25
    610c:      	b.eq	0x633c <generic_lsm_filter_arg+0x54c>
    6110:      	b	0x6088 <generic_lsm_filter_arg+0x298>
    6114:      	cmp	w9, #0x9
    6118:      	b.le	0x6168 <generic_lsm_filter_arg+0x378>
    611c:      	sub	w10, w9, #0xa
    6120:      	cmp	w10, #0x4
    6124:      	b.lo	0x6188 <generic_lsm_filter_arg+0x398>
    6128:      	sub	w10, w9, #0xf
    612c:      	cmp	w10, #0x2
    6130:      	b.lo	0x633c <generic_lsm_filter_arg+0x54c>
    6134:      	cmp	w9, #0x11
    6138:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    613c:      	add	x25, x25, #0x4
    6140:      	b	0x633c <generic_lsm_filter_arg+0x54c>
    6144:      	cmp	w9, #0x29
    6148:      	b.gt	0x62b4 <generic_lsm_filter_arg+0x4c4>
    614c:      	sub	w10, w9, #0x26
    6150:      	cmp	w10, #0x2
    6154:      	b.lo	0x625c <generic_lsm_filter_arg+0x46c>
    6158:      	sub	w10, w9, #0x28
    615c:      	cmp	w10, #0x2
    6160:      	b.lo	0x6234 <generic_lsm_filter_arg+0x444>
    6164:      	b	0x6088 <generic_lsm_filter_arg+0x298>
    6168:      	cmp	w9, #0x4
    616c:      	b.gt	0x621c <generic_lsm_filter_arg+0x42c>
    6170:      	cmp	w9, #0x1
    6174:      	b.eq	0x6188 <generic_lsm_filter_arg+0x398>
    6178:      	cmp	w9, #0x2
    617c:      	b.eq	0x676c <generic_lsm_filter_arg+0x97c>
    6180:      	cmp	w9, #0x4
    6184:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    6188:      	cmp	w9, #0xb
    618c:      	b.le	0x61fc <generic_lsm_filter_arg+0x40c>
    6190:      	cmp	w9, #0x24
    6194:      	b.hi	0x63f8 <generic_lsm_filter_arg+0x608>
    6198:      	lsl	x10, x12, x9
    619c:      	tst	x10, #0x1e00000000
    61a0:      	b.ne	0x628c <generic_lsm_filter_arg+0x49c>
    61a4:      	lsl	x10, x12, x9
    61a8:      	tst	x10, #0x60000000
    61ac:      	b.ne	0x65b4 <generic_lsm_filter_arg+0x7c4>
    61b0:      	lsl	x10, x12, x9
    61b4:      	tst	x10, #0x180000000
    61b8:      	b.eq	0x63f8 <generic_lsm_filter_arg+0x608>
    61bc:      	cmp	w8, #0x20
    61c0:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    61c4:      	lsl	x9, x12, x8
    61c8:      	mov	w10, #0x101e            // =4126
    61cc:      	tst	x9, x10
    61d0:      	b.eq	0x6bf4 <generic_lsm_filter_arg+0xe04>
    61d4:      	ldr	w9, [x23, #0x10]
    61d8:      	cmp	w8, #0x2
    61dc:      	b.le	0x7190 <generic_lsm_filter_arg+0x13a0>
    61e0:      	sub	w10, w8, #0x3
    61e4:      	cmp	w10, #0x2
    61e8:      	b.hs	0x7744 <generic_lsm_filter_arg+0x1954>
    61ec:      	ldrb	w10, [x25]
    61f0:      	cmp	w9, w10
    61f4:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    61f8:      	b	0x78cc <generic_lsm_filter_arg+0x1adc>
    61fc:      	sub	w10, w9, #0xa
    6200:      	cmp	w10, #0x2
    6204:      	b.lo	0x67e0 <generic_lsm_filter_arg+0x9f0>
    6208:      	cmp	w9, #0x1
    620c:      	b.eq	0x6404 <generic_lsm_filter_arg+0x614>
    6210:      	cmp	w9, #0x4
    6214:      	b.eq	0x6404 <generic_lsm_filter_arg+0x614>
    6218:      	b	0x6088 <generic_lsm_filter_arg+0x298>
    621c:      	cmp	w9, #0x5
    6220:      	b.eq	0x6234 <generic_lsm_filter_arg+0x444>
    6224:      	cmp	w9, #0x6
    6228:      	b.eq	0x625c <generic_lsm_filter_arg+0x46c>
    622c:      	cmp	w9, #0x7
    6230:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    6234:      	mov	x22, xzr
    6238:      	cmp	w9, #0x27
    623c:      	stp	xzr, xzr, [sp, #0x78]
    6240:      	str	xzr, [sp, #0x60]
    6244:      	stp	xzr, xzr, [sp, #0x68]
    6248:      	b.gt	0x6444 <generic_lsm_filter_arg+0x654>
    624c:      	cmp	w9, #0x5
    6250:      	b.eq	0x6900 <generic_lsm_filter_arg+0xb10>
    6254:      	cmp	w9, #0x7
    6258:      	b	0x6450 <generic_lsm_filter_arg+0x660>
    625c:      	ldr	w29, [x25], #0x4
    6260:      	mov	x22, xzr
    6264:      	cmp	w8, #0x19
    6268:      	b.gt	0x64b0 <generic_lsm_filter_arg+0x6c0>
    626c:      	sub	w9, w8, #0x3
    6270:      	cmp	w9, #0x2
    6274:      	b.lo	0x6b84 <generic_lsm_filter_arg+0xd94>
    6278:      	cmp	w8, #0x8
    627c:      	b.eq	0x6aec <generic_lsm_filter_arg+0xcfc>
    6280:      	cmp	w8, #0x9
    6284:      	b.eq	0x64c8 <generic_lsm_filter_arg+0x6d8>
    6288:      	b	0x70b0 <generic_lsm_filter_arg+0x12c0>
    628c:      	cmp	w8, #0x9
    6290:      	b.le	0x675c <generic_lsm_filter_arg+0x96c>
    6294:      	cmp	w8, #0x1d
    6298:      	b.gt	0x6aac <generic_lsm_filter_arg+0xcbc>
    629c:      	sub	w10, w8, #0xa
    62a0:      	cmp	w10, #0x2
    62a4:      	b.lo	0x686c <generic_lsm_filter_arg+0xa7c>
    62a8:      	cmp	w8, #0xc
    62ac:      	b.eq	0x67f8 <generic_lsm_filter_arg+0xa08>
    62b0:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    62b4:      	cmp	w9, #0x2a
    62b8:      	b.eq	0x633c <generic_lsm_filter_arg+0x54c>
    62bc:      	cmp	w9, #0x2c
    62c0:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    62c4:      	ldrb	w29, [x25, #0x3]
    62c8:      	add	x10, x25, #0x4
    62cc:      	cmp	w8, #0x19
    62d0:      	b.gt	0x6e80 <generic_lsm_filter_arg+0x1090>
    62d4:      	sub	w9, w8, #0x3
    62d8:      	cmp	w9, #0x2
    62dc:      	b.hs	0x73e4 <generic_lsm_filter_arg+0x15f4>
    62e0:      	cmp	w29, #0x90
    62e4:      	str	wzr, [sp, #0x88]
    62e8:      	b.hi	0x7480 <generic_lsm_filter_arg+0x1690>
    62ec:      	mov	w8, #0xaaab             // =43691
    62f0:      	mov	w9, #0x18               // =24
    62f4:      	movk	w8, #0xaaa, lsl #16
    62f8:      	umull	x8, w29, w8
    62fc:      	lsr	x8, x8, #32
    6300:      	msub	w8, w8, w9, w29
    6304:      	cbz	w29, 0x6310 <generic_lsm_filter_arg+0x520>
    6308:      	mov	w13, w29
    630c:      	cbz	w8, 0x6324 <generic_lsm_filter_arg+0x534>
    6310:      	sub	w8, w29, w8, uxtb
    6314:      	add	w9, w8, #0x18
    6318:      	cmp	w8, #0x78
    631c:      	and	w13, w9, #0xffff
    6320:      	b.hi	0x7484 <generic_lsm_filter_arg+0x1694>
    6324:      	and	w8, w13, #0xff
    6328:      	mov	w9, #0xab               // =171
    632c:      	mul	w8, w8, w9
    6330:      	lsr	w8, w8, #12
    6334:      	sub	w11, w8, #0x1
    6338:      	b	0x7e78 <generic_lsm_filter_arg+0x2088>
    633c:      	ldr	w29, [x25]
    6340:      	and	w9, w8, #0xfffffffe
    6344:      	cmp	w9, #0x24
    6348:      	b.eq	0x6350 <generic_lsm_filter_arg+0x560>
    634c:      	cbz	w29, 0x5eec <generic_lsm_filter_arg+0xfc>
    6350:      	cmp	w8, #0x25
    6354:      	b.hi	0x6594 <generic_lsm_filter_arg+0x7a4>
    6358:      	mov	w10, #0x100             // =256
    635c:      	lsl	x9, x12, x8
    6360:      	movk	w10, #0x400, lsl #16
    6364:      	tst	x9, x10
    6368:      	b.ne	0x66c4 <generic_lsm_filter_arg+0x8d4>
    636c:      	mov	w10, #0x200             // =512
    6370:      	lsl	x9, x12, x8
    6374:      	movk	w10, #0x800, lsl #16
    6378:      	tst	x9, x10
    637c:      	b.ne	0x65f4 <generic_lsm_filter_arg+0x804>
    6380:      	lsl	x9, x12, x8
    6384:      	tst	x9, #0x3000000000
    6388:      	b.eq	0x6594 <generic_lsm_filter_arg+0x7a4>
    638c:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6390:      	strh	wzr, [sp, #0x60]
    6394:      	b.hi	0x65ac <generic_lsm_filter_arg+0x7bc>
    6398:      	add	x8, x25, #0x4
    639c:      	mov	w10, #0x4               // =4
    63a0:      	add	x11, sp, #0x60
    63a4:      	mov	w12, #0x2               // =2
    63a8:      	add	x0, sp, #0x60
    63ac:      	mov	w1, #0x2                // =2
    63b0:      	add	x9, x8, x29
    63b4:      	add	x9, x9, #0x4
    63b8:      	ldr	w9, [x25]
    63bc:      	add	x8, x8, x9
    63c0:      	add	x2, x8, #0x4
    63c4:      	blr	x10
    63c8:      	ldr	w9, [x23, #0x10]
    63cc:      	cbz	w9, 0x8bd0 <generic_lsm_filter_arg+0x2de0>
    63d0:      	ldrh	w8, [sp, #0x60]
    63d4:      	ldp	x16, x15, [sp, #0x40]
    63d8:      	mov	w2, #0x5ea0             // =24224
    63dc:      	mov	w12, #0x1               // =1
    63e0:      	and	w8, w8, #0xf000
    63e4:      	ldr	x17, [sp, #0x38]
    63e8:      	cmp	w9, w8
    63ec:      	b.ne	0x7774 <generic_lsm_filter_arg+0x1984>
    63f0:      	mov	w22, #0x1               // =1
    63f4:      	b	0x8be4 <generic_lsm_filter_arg+0x2df4>
    63f8:      	sub	w10, w9, #0xc
    63fc:      	cmp	w10, #0x2
    6400:      	b.hs	0x67d8 <generic_lsm_filter_arg+0x9e8>
    6404:      	cmp	w8, #0x20
    6408:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    640c:      	lsl	x10, x12, x8
    6410:      	mov	w11, #0x101e            // =4126
    6414:      	tst	x10, x11
    6418:      	b.eq	0x645c <generic_lsm_filter_arg+0x66c>
    641c:      	ldr	w10, [x23, #0x10]
    6420:      	cmp	w8, #0x2
    6424:      	b.le	0x67a0 <generic_lsm_filter_arg+0x9b0>
    6428:      	sub	w11, w8, #0x3
    642c:      	cmp	w11, #0x2
    6430:      	b.hs	0x6bdc <generic_lsm_filter_arg+0xdec>
    6434:      	ldr	w11, [x25]
    6438:      	cmp	w11, w10
    643c:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    6440:      	b	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    6444:      	cmp	w9, #0x28
    6448:      	b.eq	0x6908 <generic_lsm_filter_arg+0xb18>
    644c:      	cmp	w9, #0x29
    6450:      	mov	x10, x25
    6454:      	b.eq	0x6930 <generic_lsm_filter_arg+0xb40>
    6458:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    645c:      	lsl	x10, x12, x8
    6460:      	tst	x10, #0xc00
    6464:      	b.ne	0x68c8 <generic_lsm_filter_arg+0xad8>
    6468:      	lsl	x10, x12, x8
    646c:      	tst	x10, #0x180000000
    6470:      	b.eq	0x5eec <generic_lsm_filter_arg+0xfc>
    6474:      	cmp	w8, #0x1f
    6478:      	b.ne	0x6e50 <generic_lsm_filter_arg+0x1060>
    647c:      	ldp	w11, w10, [x23, #0x10]
    6480:      	cmp	w9, #0xc
    6484:      	b.hi	0x7940 <generic_lsm_filter_arg+0x1b50>
    6488:      	lsl	w8, w12, w9
    648c:      	mov	w13, #0x1402            // =5122
    6490:      	tst	w8, w13
    6494:      	b.eq	0x7940 <generic_lsm_filter_arg+0x1b50>
    6498:      	ldr	w8, [x25]
    649c:      	cmp	w11, w8
    64a0:      	b.gt	0x7954 <generic_lsm_filter_arg+0x1b64>
    64a4:      	cmp	w8, w10
    64a8:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    64ac:      	b	0x7954 <generic_lsm_filter_arg+0x1b64>
    64b0:      	cmp	w8, #0x20
    64b4:      	b.gt	0x69a4 <generic_lsm_filter_arg+0xbb4>
    64b8:      	cmp	w8, #0x1a
    64bc:      	b.eq	0x6aec <generic_lsm_filter_arg+0xcfc>
    64c0:      	cmp	w8, #0x1b
    64c4:      	b.ne	0x70b0 <generic_lsm_filter_arg+0x12c0>
    64c8:      	ldr	w8, [x23, #0x10]
    64cc:      	str	wzr, [sp, #0x88]
    64d0:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    64d4:      	add	x9, sp, #0x60
    64d8:      	add	x1, sp, #0x60
    64dc:      	str	w8, [sp, #0x60]
    64e0:      	mov	w8, #0x1                // =1
    64e4:      	ldr	x0, [x0]
    64e8:      	blr	x8
    64ec:      	mov	x22, xzr
    64f0:      	cbz	w29, 0x70a0 <generic_lsm_filter_arg+0x12b0>
    64f4:      	cbz	x0, 0x70a0 <generic_lsm_filter_arg+0x12b0>
    64f8:      	mov	x19, x0
    64fc:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6500:      	mov	w8, #0x1                // =1
    6504:      	ldr	x0, [x0]
    6508:      	add	x9, sp, #0x88
    650c:      	add	x1, sp, #0x88
    6510:      	blr	x8
    6514:      	cbz	x0, 0x7098 <generic_lsm_filter_arg+0x12a8>
    6518:      	cmp	w29, #0x7f
    651c:      	mov	w9, #0x7f               // =127
    6520:      	mov	w11, #0x1               // =1
    6524:      	mov	x1, x0
    6528:      	mov	x8, xzr
    652c:      	sub	w12, w29, #0x2
    6530:      	sub	w13, w29, #0x1
    6534:      	csel	w9, w29, w9, lo
    6538:      	sub	x11, x11, x29
    653c:      	lsl	w10, w9, #3
    6540:      	mov	x9, x0
    6544:      	str	w10, [x9], #0x5
    6548:      	neg	x10, x29
    654c:      	add	w14, w13, w8
    6550:      	cmp	x11, x8
    6554:      	and	x14, x14, #0xfff
    6558:      	ldrb	w14, [x25, x14]
    655c:      	sturb	w14, [x9, #-0x1]
    6560:      	b.eq	0x6588 <generic_lsm_filter_arg+0x798>
    6564:      	cmn	x8, #0x7e
    6568:      	b.eq	0x6588 <generic_lsm_filter_arg+0x798>
    656c:      	add	w14, w12, w8
    6570:      	sub	x8, x8, #0x2
    6574:      	and	x14, x14, #0xfff
    6578:      	cmp	x10, x8
    657c:      	ldrb	w14, [x25, x14]
    6580:      	strb	w14, [x9], #0x2
    6584:      	b.ne	0x654c <generic_lsm_filter_arg+0x75c>
    6588:      	mov	w8, #0x1                // =1
    658c:      	mov	x0, x19
    6590:      	b	0x6b74 <generic_lsm_filter_arg+0xd84>
    6594:      	sub	w8, w8, #0x3
    6598:      	cmp	w8, #0x2
    659c:      	b.hs	0x65ac <generic_lsm_filter_arg+0x7bc>
    65a0:      	cmp	w29, #0x1, lsl #12      // =0x1000
    65a4:      	str	wzr, [sp, #0x88]
    65a8:      	b.ls	0x6ce4 <generic_lsm_filter_arg+0xef4>
    65ac:      	mov	x22, xzr
    65b0:      	b	0x8be4 <generic_lsm_filter_arg+0x2df4>
    65b4:      	cmp	w8, #0x20
    65b8:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    65bc:      	lsl	x9, x12, x8
    65c0:      	mov	w10, #0x101e            // =4126
    65c4:      	tst	x9, x10
    65c8:      	b.eq	0x6c20 <generic_lsm_filter_arg+0xe30>
    65cc:      	ldr	w9, [x23, #0x10]
    65d0:      	cmp	w8, #0x2
    65d4:      	b.le	0x71b0 <generic_lsm_filter_arg+0x13c0>
    65d8:      	sub	w10, w8, #0x3
    65dc:      	cmp	w10, #0x2
    65e0:      	b.hs	0x775c <generic_lsm_filter_arg+0x196c>
    65e4:      	ldrh	w10, [x25]
    65e8:      	cmp	w9, w10
    65ec:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    65f0:      	b	0x790c <generic_lsm_filter_arg+0x1b1c>
    65f4:      	ldr	w8, [x23, #0x10]
    65f8:      	str	wzr, [sp, #0x88]
    65fc:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6600:      	add	x9, sp, #0x60
    6604:      	add	x1, sp, #0x60
    6608:      	str	w8, [sp, #0x60]
    660c:      	mov	w8, #0x1                // =1
    6610:      	ldr	x0, [x0]
    6614:      	blr	x8
    6618:      	mov	x22, xzr
    661c:      	cbz	w29, 0x8bd4 <generic_lsm_filter_arg+0x2de4>
    6620:      	cbz	x0, 0x8bd4 <generic_lsm_filter_arg+0x2de4>
    6624:      	mov	x19, x0
    6628:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    662c:      	mov	w8, #0x1                // =1
    6630:      	ldr	x0, [x0]
    6634:      	add	x9, sp, #0x88
    6638:      	add	x1, sp, #0x88
    663c:      	blr	x8
    6640:      	cbz	x0, 0x77c4 <generic_lsm_filter_arg+0x19d4>
    6644:      	cmp	w29, #0x7f
    6648:      	mov	w10, #0x7f              // =127
    664c:      	mov	w12, #0x1               // =1
    6650:      	mov	x1, x0
    6654:      	mov	x8, xzr
    6658:      	add	x9, x25, #0x4
    665c:      	sub	w13, w29, #0x2
    6660:      	sub	w14, w29, #0x1
    6664:      	csel	w10, w29, w10, lo
    6668:      	sub	x12, x12, x29
    666c:      	lsl	w11, w10, #3
    6670:      	mov	x10, x0
    6674:      	str	w11, [x10], #0x5
    6678:      	neg	x11, x29
    667c:      	add	w15, w14, w8
    6680:      	cmp	x12, x8
    6684:      	and	x15, x15, #0xfff
    6688:      	ldrb	w15, [x9, x15]
    668c:      	sturb	w15, [x10, #-0x1]
    6690:      	b.eq	0x66b8 <generic_lsm_filter_arg+0x8c8>
    6694:      	cmn	x8, #0x7e
    6698:      	b.eq	0x66b8 <generic_lsm_filter_arg+0x8c8>
    669c:      	add	w15, w13, w8
    66a0:      	sub	x8, x8, #0x2
    66a4:      	and	x15, x15, #0xfff
    66a8:      	cmp	x11, x8
    66ac:      	ldrb	w15, [x9, x15]
    66b0:      	strb	w15, [x10], #0x2
    66b4:      	b.ne	0x667c <generic_lsm_filter_arg+0x88c>
    66b8:      	mov	w8, #0x1                // =1
    66bc:      	mov	x0, x19
    66c0:      	b	0x674c <generic_lsm_filter_arg+0x95c>
    66c4:      	ldr	w8, [x23, #0x10]
    66c8:      	str	wzr, [sp, #0x88]
    66cc:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    66d0:      	add	x9, sp, #0x60
    66d4:      	add	x1, sp, #0x60
    66d8:      	str	w8, [sp, #0x60]
    66dc:      	mov	w8, #0x1                // =1
    66e0:      	ldr	x0, [x0]
    66e4:      	blr	x8
    66e8:      	mov	x22, xzr
    66ec:      	cbz	w29, 0x8bd4 <generic_lsm_filter_arg+0x2de4>
    66f0:      	cbz	x0, 0x8bd4 <generic_lsm_filter_arg+0x2de4>
    66f4:      	mov	x19, x0
    66f8:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    66fc:      	mov	w8, #0x1                // =1
    6700:      	ldr	x0, [x0]
    6704:      	add	x9, sp, #0x88
    6708:      	add	x1, sp, #0x88
    670c:      	blr	x8
    6710:      	cbz	x0, 0x77c4 <generic_lsm_filter_arg+0x19d4>
    6714:      	cmp	w29, #0xff
    6718:      	mov	w8, #0xff               // =255
    671c:      	add	x2, x25, #0x4
    6720:      	mov	x22, x0
    6724:      	csel	w1, w29, w8, lo
    6728:      	mov	x8, x0
    672c:      	lsl	w9, w1, #3
    6730:      	str	w9, [x8], #0x4
    6734:      	mov	w9, #0x4                // =4
    6738:      	mov	x0, x8
    673c:      	blr	x9
    6740:      	mov	w8, #0x1                // =1
    6744:      	mov	x0, x19
    6748:      	mov	x1, x22
    674c:      	blr	x8
    6750:      	cmp	x0, #0x0
    6754:      	cset	w22, ne
    6758:      	b	0x77c8 <generic_lsm_filter_arg+0x19d8>
    675c:      	sub	w10, w8, #0x1
    6760:      	cmp	w10, #0x4
    6764:      	b.lo	0x67f8 <generic_lsm_filter_arg+0xa08>
    6768:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    676c:      	add	x29, x25, #0x8
    6770:      	ldr	w25, [x25, #0x4]
    6774:      	mov	x22, xzr
    6778:      	cmp	w8, #0x19
    677c:      	b.gt	0x6d54 <generic_lsm_filter_arg+0xf64>
    6780:      	sub	w9, w8, #0x3
    6784:      	cmp	w9, #0x2
    6788:      	b.lo	0x7570 <generic_lsm_filter_arg+0x1780>
    678c:      	cmp	w8, #0x8
    6790:      	b.eq	0x74e4 <generic_lsm_filter_arg+0x16f4>
    6794:      	cmp	w8, #0x9
    6798:      	b.eq	0x6d6c <generic_lsm_filter_arg+0xf7c>
    679c:      	b	0x9174 <generic_lsm_filter_arg+0x3384>
    67a0:      	cmp	w8, #0x1
    67a4:      	b.eq	0x6fbc <generic_lsm_filter_arg+0x11cc>
    67a8:      	cmp	w8, #0x2
    67ac:      	b.ne	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    67b0:      	cmp	w9, #0xc
    67b4:      	b.hi	0x7c94 <generic_lsm_filter_arg+0x1ea4>
    67b8:      	lsl	w11, w12, w9
    67bc:      	mov	w13, #0x1402            // =5122
    67c0:      	tst	w11, w13
    67c4:      	b.eq	0x7c94 <generic_lsm_filter_arg+0x1ea4>
    67c8:      	ldr	w11, [x25]
    67cc:      	cmp	w11, w10
    67d0:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    67d4:      	b	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    67d8:      	cmp	w9, #0x1c
    67dc:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    67e0:      	cmp	w8, #0x20
    67e4:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    67e8:      	lsl	x10, x12, x8
    67ec:      	mov	w11, #0x101e            // =4126
    67f0:      	tst	x10, x11
    67f4:      	b.eq	0x6820 <generic_lsm_filter_arg+0xa30>
    67f8:      	ldr	x10, [x23, #0x10]
    67fc:      	cmp	w8, #0x2
    6800:      	b.le	0x683c <generic_lsm_filter_arg+0xa4c>
    6804:      	sub	w11, w8, #0x3
    6808:      	cmp	w11, #0x2
    680c:      	b.hs	0x6a94 <generic_lsm_filter_arg+0xca4>
    6810:      	ldr	x11, [x25]
    6814:      	cmp	x11, x10
    6818:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    681c:      	b	0x76b8 <generic_lsm_filter_arg+0x18c8>
    6820:      	lsl	x10, x12, x8
    6824:      	tst	x10, #0xc00
    6828:      	b.ne	0x686c <generic_lsm_filter_arg+0xa7c>
    682c:      	lsl	x10, x12, x8
    6830:      	tst	x10, #0x180000000
    6834:      	b.ne	0x6ab8 <generic_lsm_filter_arg+0xcc8>
    6838:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    683c:      	cmp	w8, #0x1
    6840:      	b.eq	0x6cc4 <generic_lsm_filter_arg+0xed4>
    6844:      	cmp	w8, #0x2
    6848:      	b.ne	0x76b8 <generic_lsm_filter_arg+0x18c8>
    684c:      	cmp	w9, #0xc
    6850:      	b.eq	0x685c <generic_lsm_filter_arg+0xa6c>
    6854:      	cmp	w9, #0xa
    6858:      	b.ne	0x76ac <generic_lsm_filter_arg+0x18bc>
    685c:      	ldr	x11, [x25]
    6860:      	cmp	x11, x10
    6864:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    6868:      	b	0x76b8 <generic_lsm_filter_arg+0x18c8>
    686c:      	ldrb	w8, [x23, #0x10]
    6870:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6874:      	add	x9, sp, #0x88
    6878:      	add	x1, sp, #0x88
    687c:      	str	w8, [sp, #0x88]
    6880:      	mov	w8, #0x1                // =1
    6884:      	ldr	x0, [x0]
    6888:      	blr	x8
    688c:      	cbz	x0, 0x6e38 <generic_lsm_filter_arg+0x1048>
    6890:      	ldr	x8, [x25]
    6894:      	add	x9, sp, #0x60
    6898:      	add	x1, sp, #0x60
    689c:      	str	x8, [sp, #0x60]
    68a0:      	mov	w8, #0x1                // =1
    68a4:      	blr	x8
    68a8:      	ldr	w8, [x23, #0x4]
    68ac:      	cmp	w8, #0xb
    68b0:      	b.eq	0x7264 <generic_lsm_filter_arg+0x1474>
    68b4:      	cmp	w8, #0xa
    68b8:      	mov	w12, #0x1               // =1
    68bc:      	b.eq	0x7304 <generic_lsm_filter_arg+0x1514>
    68c0:      	mov	w8, wzr
    68c4:      	b	0x730c <generic_lsm_filter_arg+0x151c>
    68c8:      	ldrb	w8, [x23, #0x10]
    68cc:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    68d0:      	add	x9, sp, #0x88
    68d4:      	add	x1, sp, #0x88
    68d8:      	str	w8, [sp, #0x88]
    68dc:      	mov	w8, #0x1                // =1
    68e0:      	ldr	x0, [x0]
    68e4:      	blr	x8
    68e8:      	cbz	x0, 0x7680 <generic_lsm_filter_arg+0x1890>
    68ec:      	ldr	w8, [x25]
    68f0:      	add	x9, sp, #0x60
    68f4:      	str	x8, [sp, #0x60]
    68f8:      	mov	w8, #0x1                // =1
    68fc:      	b	0x723c <generic_lsm_filter_arg+0x144c>
    6900:      	mov	x10, xzr
    6904:      	b	0x6930 <generic_lsm_filter_arg+0xb40>
    6908:      	ldrh	w11, [x25]
    690c:      	mov	x10, xzr
    6910:      	strh	w11, [sp, #0x86]
    6914:      	ldrh	w11, [x25, #0x2]
    6918:      	strh	w11, [sp, #0x80]
    691c:      	ldr	x11, [x25, #0x8]
    6920:      	str	x11, [sp, #0x60]
    6924:      	ldr	x11, [x25, #0x10]
    6928:      	add	x25, sp, #0x60
    692c:      	str	x11, [sp, #0x68]
    6930:      	mov	x22, xzr
    6934:      	cmp	w8, #0x13
    6938:      	b.le	0x6960 <generic_lsm_filter_arg+0xb70>
    693c:      	cmp	w8, #0x17
    6940:      	b.gt	0x6988 <generic_lsm_filter_arg+0xb98>
    6944:      	sub	w9, w8, #0x14
    6948:      	cmp	w9, #0x2
    694c:      	b.lo	0x6ebc <generic_lsm_filter_arg+0x10cc>
    6950:      	sub	w9, w8, #0x16
    6954:      	cmp	w9, #0x2
    6958:      	b.lo	0x6ea8 <generic_lsm_filter_arg+0x10b8>
    695c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    6960:      	cmp	w8, #0xf
    6964:      	b.le	0x6b98 <generic_lsm_filter_arg+0xda8>
    6968:      	cmp	w8, #0x11
    696c:      	b.gt	0x6e98 <generic_lsm_filter_arg+0x10a8>
    6970:      	cmp	w8, #0x10
    6974:      	b.eq	0x6ea8 <generic_lsm_filter_arg+0x10b8>
    6978:      	cmp	w8, #0x11
    697c:      	b.ne	0x6084 <generic_lsm_filter_arg+0x294>
    6980:      	ldrh	w22, [x25, #0x24]
    6984:      	b	0x7614 <generic_lsm_filter_arg+0x1824>
    6988:      	cmp	w8, #0x1b
    698c:      	b.gt	0x6ed0 <generic_lsm_filter_arg+0x10e0>
    6990:      	cmp	w8, #0x18
    6994:      	b.eq	0x6f00 <generic_lsm_filter_arg+0x1110>
    6998:      	cmp	w8, #0x19
    699c:      	b.eq	0x6ef4 <generic_lsm_filter_arg+0x1104>
    69a0:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    69a4:      	cmp	w8, #0x21
    69a8:      	b.eq	0x6fe4 <generic_lsm_filter_arg+0x11f4>
    69ac:      	cmp	w8, #0x22
    69b0:      	b.ne	0x70b0 <generic_lsm_filter_arg+0x12c0>
    69b4:      	mov	x22, xzr
    69b8:      	mov	w19, wzr
    69bc:      	add	x8, x23, #0x10
    69c0:      	str	x8, [sp, #0x28]
    69c4:      	ldr	x8, [sp, #0x28]
    69c8:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    69cc:      	add	x9, sp, #0x60
    69d0:      	add	x1, sp, #0x60
    69d4:      	ldr	w8, [x8, x22, lsl #2]
    69d8:      	str	w8, [sp, #0x60]
    69dc:      	mov	w8, #0x1                // =1
    69e0:      	ldr	x0, [x0]
    69e4:      	blr	x8
    69e8:      	cbz	x0, 0x7098 <generic_lsm_filter_arg+0x12a8>
    69ec:      	cbz	w29, 0x6a70 <generic_lsm_filter_arg+0xc80>
    69f0:      	mov	x8, xzr
    69f4:      	mov	x9, x25
    69f8:      	mov	x10, x29
    69fc:      	b	0x6a14 <generic_lsm_filter_arg+0xc24>
    6a00:      	add	x8, x8, #0x1
    6a04:      	sub	x10, x10, #0x1
    6a08:      	add	x9, x9, #0x1
    6a0c:      	cmp	x8, x29
    6a10:      	b.eq	0x6a70 <generic_lsm_filter_arg+0xc80>
    6a14:      	mov	x11, xzr
    6a18:      	nop
    6a1c:      	nop
    6a20:      	cmp	x10, x11
    6a24:      	b.eq	0x6a00 <generic_lsm_filter_arg+0xc10>
    6a28:      	ldrb	w12, [x0, x11]
    6a2c:      	cbz	w12, 0x6a6c <generic_lsm_filter_arg+0xc7c>
    6a30:      	ldrb	w13, [x9, x11]
    6a34:      	sub	w14, w13, #0x41
    6a38:      	orr	w15, w13, #0x20
    6a3c:      	cmp	w14, #0x1a
    6a40:      	sub	w14, w12, #0x41
    6a44:      	csel	w13, w15, w13, lo
    6a48:      	orr	w15, w12, #0x20
    6a4c:      	cmp	w14, #0x1a
    6a50:      	csel	w12, w15, w12, lo
    6a54:      	cmp	x11, #0x62
    6a58:      	b.hi	0x6a00 <generic_lsm_filter_arg+0xc10>
    6a5c:      	add	x11, x11, #0x1
    6a60:      	cmp	w13, w12
    6a64:      	b.eq	0x6a20 <generic_lsm_filter_arg+0xc30>
    6a68:      	b	0x6a00 <generic_lsm_filter_arg+0xc10>
    6a6c:      	tbz	w8, #0x1f, 0x78b8 <generic_lsm_filter_arg+0x1ac8>
    6a70:      	ldr	w9, [x23, #0x8]
    6a74:      	add	w8, w19, #0xc
    6a78:      	cmp	w8, w9
    6a7c:      	b.hs	0x7098 <generic_lsm_filter_arg+0x12a8>
    6a80:      	add	x22, x22, #0x1
    6a84:      	add	w19, w19, #0x4
    6a88:      	cmp	x22, #0x64
    6a8c:      	b.ne	0x69c4 <generic_lsm_filter_arg+0xbd4>
    6a90:      	b	0x7098 <generic_lsm_filter_arg+0x12a8>
    6a94:      	cmp	w8, #0xc
    6a98:      	b.ne	0x76b8 <generic_lsm_filter_arg+0x18c8>
    6a9c:      	ldr	x11, [x25]
    6aa0:      	tst	x11, x10
    6aa4:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    6aa8:      	b	0x76b8 <generic_lsm_filter_arg+0x18c8>
    6aac:      	sub	w10, w8, #0x1f
    6ab0:      	cmp	w10, #0x2
    6ab4:      	b.hs	0x7330 <generic_lsm_filter_arg+0x1540>
    6ab8:      	cmp	w8, #0x1f
    6abc:      	b.ne	0x6bb4 <generic_lsm_filter_arg+0xdc4>
    6ac0:      	ldp	x11, x10, [x23, #0x10]
    6ac4:      	cmp	w9, #0xa
    6ac8:      	b.eq	0x6ad4 <generic_lsm_filter_arg+0xce4>
    6acc:      	cmp	w9, #0xc
    6ad0:      	b.ne	0x7584 <generic_lsm_filter_arg+0x1794>
    6ad4:      	ldr	x8, [x25]
    6ad8:      	cmp	x11, x8
    6adc:      	b.gt	0x7598 <generic_lsm_filter_arg+0x17a8>
    6ae0:      	cmp	x8, x10
    6ae4:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    6ae8:      	b	0x7598 <generic_lsm_filter_arg+0x17a8>
    6aec:      	ldr	w8, [x23, #0x10]
    6af0:      	str	wzr, [sp, #0x88]
    6af4:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6af8:      	add	x9, sp, #0x60
    6afc:      	add	x1, sp, #0x60
    6b00:      	str	w8, [sp, #0x60]
    6b04:      	mov	w8, #0x1                // =1
    6b08:      	ldr	x0, [x0]
    6b0c:      	blr	x8
    6b10:      	mov	x22, xzr
    6b14:      	cbz	w29, 0x70a0 <generic_lsm_filter_arg+0x12b0>
    6b18:      	cbz	x0, 0x70a0 <generic_lsm_filter_arg+0x12b0>
    6b1c:      	mov	x19, x0
    6b20:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6b24:      	mov	w8, #0x1                // =1
    6b28:      	ldr	x0, [x0]
    6b2c:      	add	x9, sp, #0x88
    6b30:      	add	x1, sp, #0x88
    6b34:      	blr	x8
    6b38:      	cbz	x0, 0x7098 <generic_lsm_filter_arg+0x12a8>
    6b3c:      	cmp	w29, #0xff
    6b40:      	mov	w8, #0xff               // =255
    6b44:      	mov	x22, x0
    6b48:      	mov	x2, x25
    6b4c:      	csel	w1, w29, w8, lo
    6b50:      	mov	x8, x0
    6b54:      	lsl	w9, w1, #3
    6b58:      	str	w9, [x8], #0x4
    6b5c:      	mov	w9, #0x4                // =4
    6b60:      	mov	x0, x8
    6b64:      	blr	x9
    6b68:      	mov	w8, #0x1                // =1
    6b6c:      	mov	x0, x19
    6b70:      	mov	x1, x22
    6b74:      	blr	x8
    6b78:      	cmp	x0, #0x0
    6b7c:      	cset	w22, ne
    6b80:      	b	0x709c <generic_lsm_filter_arg+0x12ac>
    6b84:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6b88:      	str	wzr, [sp, #0x88]
    6b8c:      	b.ls	0x70d8 <generic_lsm_filter_arg+0x12e8>
    6b90:      	mov	x22, xzr
    6b94:      	b	0x70b0 <generic_lsm_filter_arg+0x12c0>
    6b98:      	cmp	w8, #0xd
    6b9c:      	b.eq	0x6f00 <generic_lsm_filter_arg+0x1110>
    6ba0:      	cmp	w8, #0xe
    6ba4:      	b.eq	0x6ef4 <generic_lsm_filter_arg+0x1104>
    6ba8:      	cmp	w8, #0xf
    6bac:      	b.eq	0x6ebc <generic_lsm_filter_arg+0x10cc>
    6bb0:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    6bb4:      	ldp	x11, x8, [x23, #0x10]
    6bb8:      	cmp	w9, #0xc
    6bbc:      	b.eq	0x6bc8 <generic_lsm_filter_arg+0xdd8>
    6bc0:      	cmp	w9, #0xa
    6bc4:      	b.ne	0x75d0 <generic_lsm_filter_arg+0x17e0>
    6bc8:      	ldr	x10, [x25]
    6bcc:      	cmp	x11, x10
    6bd0:      	ccmp	x10, x8, #0x0, le
    6bd4:      	cset	w8, le
    6bd8:      	b	0x75e0 <generic_lsm_filter_arg+0x17f0>
    6bdc:      	cmp	w8, #0xc
    6be0:      	b.ne	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    6be4:      	ldr	w11, [x25]
    6be8:      	tst	w11, w10
    6bec:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    6bf0:      	b	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    6bf4:      	lsl	x9, x12, x8
    6bf8:      	tst	x9, #0xc00
    6bfc:      	b.ne	0x71d0 <generic_lsm_filter_arg+0x13e0>
    6c00:      	lsl	x9, x12, x8
    6c04:      	tst	x9, #0x180000000
    6c08:      	b.eq	0x5eec <generic_lsm_filter_arg+0xfc>
    6c0c:      	cmp	w8, #0x1f
    6c10:      	b.ne	0x77f4 <generic_lsm_filter_arg+0x1a04>
    6c14:      	ldr	w9, [x23, #0x10]
    6c18:      	ldrb	w8, [x25]
    6c1c:      	b	0x6c48 <generic_lsm_filter_arg+0xe58>
    6c20:      	lsl	x9, x12, x8
    6c24:      	tst	x9, #0xc00
    6c28:      	b.ne	0x7208 <generic_lsm_filter_arg+0x1418>
    6c2c:      	lsl	x9, x12, x8
    6c30:      	tst	x9, #0x180000000
    6c34:      	b.eq	0x5eec <generic_lsm_filter_arg+0xfc>
    6c38:      	cmp	w8, #0x1f
    6c3c:      	b.ne	0x7818 <generic_lsm_filter_arg+0x1a28>
    6c40:      	ldr	w9, [x23, #0x10]
    6c44:      	ldrh	w8, [x25]
    6c48:      	cmp	w9, w8
    6c4c:      	b.hi	0x6c5c <generic_lsm_filter_arg+0xe6c>
    6c50:      	ldr	w9, [x23, #0x14]
    6c54:      	cmp	w9, w8
    6c58:      	b.hs	0x6088 <generic_lsm_filter_arg+0x298>
    6c5c:      	ldr	w9, [x23, #0x8]
    6c60:      	cmp	w9, #0x11
    6c64:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    6c68:      	ldr	w10, [x23, #0x18]
    6c6c:      	cmp	w10, w8
    6c70:      	b.hi	0x6c80 <generic_lsm_filter_arg+0xe90>
    6c74:      	ldr	w10, [x23, #0x1c]
    6c78:      	cmp	w10, w8
    6c7c:      	b.hs	0x6088 <generic_lsm_filter_arg+0x298>
    6c80:      	cmp	w9, #0x19
    6c84:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    6c88:      	ldr	w10, [x23, #0x20]
    6c8c:      	cmp	w10, w8
    6c90:      	b.hi	0x6ca0 <generic_lsm_filter_arg+0xeb0>
    6c94:      	ldr	w10, [x23, #0x24]
    6c98:      	cmp	w10, w8
    6c9c:      	b.hs	0x6088 <generic_lsm_filter_arg+0x298>
    6ca0:      	cmp	w9, #0x21
    6ca4:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    6ca8:      	ldr	w9, [x23, #0x28]
    6cac:      	cmp	w9, w8
    6cb0:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    6cb4:      	ldr	w9, [x23, #0x2c]
    6cb8:      	cmp	w9, w8
    6cbc:      	b.hs	0x6088 <generic_lsm_filter_arg+0x298>
    6cc0:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    6cc4:      	cmp	w9, #0xc
    6cc8:      	b.eq	0x6cd4 <generic_lsm_filter_arg+0xee4>
    6ccc:      	cmp	w9, #0xa
    6cd0:      	b.ne	0x769c <generic_lsm_filter_arg+0x18ac>
    6cd4:      	ldr	x11, [x25]
    6cd8:      	cmp	x11, x10
    6cdc:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    6ce0:      	b	0x76b8 <generic_lsm_filter_arg+0x18c8>
    6ce4:      	and	w8, w29, #0xffff
    6ce8:      	cmp	w8, #0x90
    6cec:      	b.hi	0x7284 <generic_lsm_filter_arg+0x1494>
    6cf0:      	and	w8, w29, #0xff
    6cf4:      	mov	w9, #0xab               // =171
    6cf8:      	tst	w29, #0xffff
    6cfc:      	mul	w8, w8, w9
    6d00:      	mov	w9, #0x18               // =24
    6d04:      	lsr	w8, w8, #12
    6d08:      	msub	w8, w8, w9, w29
    6d0c:      	b.eq	0x6d20 <generic_lsm_filter_arg+0xf30>
    6d10:      	tst	w8, #0xff
    6d14:      	mov	w9, w29
    6d18:      	mov	w11, w29
    6d1c:      	b.eq	0x6d3c <generic_lsm_filter_arg+0xf4c>
    6d20:      	sub	w8, w29, w8, uxtb
    6d24:      	and	w9, w8, #0xffff
    6d28:      	add	w8, w8, #0x18
    6d2c:      	and	w11, w8, #0xffff
    6d30:      	cmp	w9, #0x78
    6d34:      	b.hi	0x8240 <generic_lsm_filter_arg+0x2450>
    6d38:      	mov	w9, w11
    6d3c:      	and	w8, w9, #0xff
    6d40:      	mov	w9, #0xab               // =171
    6d44:      	mul	w8, w8, w9
    6d48:      	lsr	w8, w8, #12
    6d4c:      	sub	w10, w8, #0x1
    6d50:      	b	0x8290 <generic_lsm_filter_arg+0x24a0>
    6d54:      	cmp	w8, #0x20
    6d58:      	b.gt	0x7370 <generic_lsm_filter_arg+0x1580>
    6d5c:      	cmp	w8, #0x1a
    6d60:      	b.eq	0x74e4 <generic_lsm_filter_arg+0x16f4>
    6d64:      	cmp	w8, #0x1b
    6d68:      	b.ne	0x9174 <generic_lsm_filter_arg+0x3384>
    6d6c:      	ldr	w8, [x23, #0x10]
    6d70:      	str	wzr, [sp, #0x88]
    6d74:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6d78:      	add	x9, sp, #0x60
    6d7c:      	add	x1, sp, #0x60
    6d80:      	mov	w19, #0x1               // =1
    6d84:      	str	w8, [sp, #0x60]
    6d88:      	mov	w8, #0x1                // =1
    6d8c:      	ldr	x0, [x0]
    6d90:      	blr	x8
    6d94:      	mov	x22, xzr
    6d98:      	cbz	w25, 0x9170 <generic_lsm_filter_arg+0x3380>
    6d9c:      	cbz	x0, 0x9170 <generic_lsm_filter_arg+0x3380>
    6da0:      	mov	x22, x0
    6da4:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6da8:      	mov	w8, #0x1                // =1
    6dac:      	ldr	x0, [x0]
    6db0:      	add	x9, sp, #0x88
    6db4:      	add	x1, sp, #0x88
    6db8:      	blr	x8
    6dbc:      	cbz	x0, 0x916c <generic_lsm_filter_arg+0x337c>
    6dc0:      	cmp	w25, #0x7f
    6dc4:      	mov	w9, #0x7f               // =127
    6dc8:      	mov	x1, x0
    6dcc:      	mov	x8, xzr
    6dd0:      	sub	x11, x19, x25
    6dd4:      	sub	w12, w25, #0x2
    6dd8:      	sub	w13, w25, #0x1
    6ddc:      	csel	w9, w25, w9, lo
    6de0:      	lsl	w10, w9, #3
    6de4:      	mov	x9, x0
    6de8:      	str	w10, [x9], #0x5
    6dec:      	neg	x10, x25
    6df0:      	add	w14, w13, w8
    6df4:      	cmp	x11, x8
    6df8:      	and	x14, x14, #0xfff
    6dfc:      	ldrb	w14, [x29, x14]
    6e00:      	sturb	w14, [x9, #-0x1]
    6e04:      	b.eq	0x6e2c <generic_lsm_filter_arg+0x103c>
    6e08:      	cmn	x8, #0x7e
    6e0c:      	b.eq	0x6e2c <generic_lsm_filter_arg+0x103c>
    6e10:      	add	w14, w12, w8
    6e14:      	sub	x8, x8, #0x2
    6e18:      	and	x14, x14, #0xfff
    6e1c:      	cmp	x10, x8
    6e20:      	ldrb	w14, [x29, x14]
    6e24:      	strb	w14, [x9], #0x2
    6e28:      	b.ne	0x6df0 <generic_lsm_filter_arg+0x1000>
    6e2c:      	mov	w8, #0x1                // =1
    6e30:      	mov	x0, x22
    6e34:      	b	0x915c <generic_lsm_filter_arg+0x336c>
    6e38:      	mov	x22, xzr
    6e3c:      	ldp	x16, x15, [sp, #0x40]
    6e40:      	mov	w2, #0x5ea0             // =24224
    6e44:      	mov	w12, #0x1               // =1
    6e48:      	ldr	x17, [sp, #0x38]
    6e4c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    6e50:      	ldp	w11, w8, [x23, #0x10]
    6e54:      	cmp	w9, #0xc
    6e58:      	b.hi	0x7998 <generic_lsm_filter_arg+0x1ba8>
    6e5c:      	lsl	w10, w12, w9
    6e60:      	mov	w13, #0x1402            // =5122
    6e64:      	tst	w10, w13
    6e68:      	b.eq	0x7998 <generic_lsm_filter_arg+0x1ba8>
    6e6c:      	ldr	w10, [x25]
    6e70:      	cmp	w11, w10
    6e74:      	ccmp	w10, w8, #0x0, le
    6e78:      	cset	w8, le
    6e7c:      	b	0x79a8 <generic_lsm_filter_arg+0x1bb8>
    6e80:      	cmp	w8, #0x1c
    6e84:      	b.eq	0x74a8 <generic_lsm_filter_arg+0x16b8>
    6e88:      	mov	x25, x10
    6e8c:      	cmp	w8, #0x1a
    6e90:      	b.eq	0x73f0 <generic_lsm_filter_arg+0x1600>
    6e94:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    6e98:      	cmp	w8, #0x12
    6e9c:      	b.eq	0x6ebc <generic_lsm_filter_arg+0x10cc>
    6ea0:      	cmp	w8, #0x13
    6ea4:      	b.ne	0x6084 <generic_lsm_filter_arg+0x294>
    6ea8:      	ldrh	w29, [x25, #0x22]
    6eac:      	mov	w11, wzr
    6eb0:      	mov	w13, wzr
    6eb4:      	mov	x19, xzr
    6eb8:      	b	0x6f0c <generic_lsm_filter_arg+0x111c>
    6ebc:      	ldrh	w29, [x25, #0x20]
    6ec0:      	mov	w11, wzr
    6ec4:      	mov	w13, wzr
    6ec8:      	mov	x19, xzr
    6ecc:      	b	0x6f0c <generic_lsm_filter_arg+0x111c>
    6ed0:      	cmp	w8, #0x1c
    6ed4:      	b.eq	0x7610 <generic_lsm_filter_arg+0x1820>
    6ed8:      	cmp	w8, #0x1d
    6edc:      	b.ne	0x6084 <generic_lsm_filter_arg+0x294>
    6ee0:      	cmp	w9, #0x7
    6ee4:      	b.ne	0x7b44 <generic_lsm_filter_arg+0x1d54>
    6ee8:      	cbnz	x10, 0x7b54 <generic_lsm_filter_arg+0x1d64>
    6eec:      	mov	x19, xzr
    6ef0:      	b	0x7b68 <generic_lsm_filter_arg+0x1d78>
    6ef4:      	ldp	w11, w13, [x25, #0x10]
    6ef8:      	ldr	x19, [x25, #0x18]
    6efc:      	b	0x6f08 <generic_lsm_filter_arg+0x1118>
    6f00:      	ldp	w11, w13, [x25]
    6f04:      	ldr	x19, [x25, #0x8]
    6f08:      	mov	x29, xzr
    6f0c:      	mov	x22, xzr
    6f10:      	cmp	w8, #0x11
    6f14:      	b.gt	0x6f40 <generic_lsm_filter_arg+0x1150>
    6f18:      	sub	w9, w8, #0xd
    6f1c:      	cmp	w9, #0x2
    6f20:      	b.lo	0x6f6c <generic_lsm_filter_arg+0x117c>
    6f24:      	ldr	x19, [sp, #0x30]
    6f28:      	sub	w9, w8, #0xf
    6f2c:      	cmp	w9, #0x2
    6f30:      	b.lo	0x7158 <generic_lsm_filter_arg+0x1368>
    6f34:      	cmp	w8, #0x11
    6f38:      	b.eq	0x7614 <generic_lsm_filter_arg+0x1824>
    6f3c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    6f40:      	cmp	w8, #0x19
    6f44:      	b.hi	0x7148 <generic_lsm_filter_arg+0x1358>
    6f48:      	lsl	w9, w12, w8
    6f4c:      	mov	w10, #0x500000          // =5242880
    6f50:      	tst	w9, w10
    6f54:      	b.ne	0x7244 <generic_lsm_filter_arg+0x1454>
    6f58:      	mov	w10, #0xa00000          // =10485760
    6f5c:      	tst	w9, w10
    6f60:      	b.ne	0x7254 <generic_lsm_filter_arg+0x1464>
    6f64:      	tst	w9, #0x3000000
    6f68:      	b.eq	0x7148 <generic_lsm_filter_arg+0x1358>
    6f6c:      	ldrh	w8, [x25, #0x26]
    6f70:      	cmp	w8, #0xa
    6f74:      	b.eq	0x7294 <generic_lsm_filter_arg+0x14a4>
    6f78:      	cmp	w8, #0x2
    6f7c:      	b.ne	0x7320 <generic_lsm_filter_arg+0x1530>
    6f80:      	ldr	w8, [x23, #0x10]
    6f84:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6f88:      	add	x9, sp, #0xac
    6f8c:      	add	x1, sp, #0xac
    6f90:      	str	w8, [sp, #0xac]
    6f94:      	mov	w8, #0x1                // =1
    6f98:      	mov	w22, w11
    6f9c:      	ldr	x0, [x0]
    6fa0:      	blr	x8
    6fa4:      	ldr	x19, [sp, #0x30]
    6fa8:      	cbz	x0, 0x7c50 <generic_lsm_filter_arg+0x1e60>
    6fac:      	mov	w8, #0x20               // =32
    6fb0:      	add	x1, sp, #0x88
    6fb4:      	stp	w8, w22, [sp, #0x88]
    6fb8:      	b	0x72dc <generic_lsm_filter_arg+0x14ec>
    6fbc:      	cmp	w9, #0xc
    6fc0:      	b.hi	0x7c84 <generic_lsm_filter_arg+0x1e94>
    6fc4:      	lsl	w11, w12, w9
    6fc8:      	mov	w13, #0x1402            // =5122
    6fcc:      	tst	w11, w13
    6fd0:      	b.eq	0x7c84 <generic_lsm_filter_arg+0x1e94>
    6fd4:      	ldr	w11, [x25]
    6fd8:      	cmp	w11, w10
    6fdc:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    6fe0:      	b	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    6fe4:      	mov	x19, xzr
    6fe8:      	mov	w22, wzr
    6fec:      	add	x8, x23, #0x10
    6ff0:      	str	x8, [sp, #0x28]
    6ff4:      	ldr	x8, [sp, #0x28]
    6ff8:      	adrp	x0, 0x6000 <generic_lsm_filter_arg+0x210>
    6ffc:      	add	x9, sp, #0x60
    7000:      	add	x1, sp, #0x60
    7004:      	ldr	w8, [x8, x19, lsl #2]
    7008:      	str	w8, [sp, #0x60]
    700c:      	mov	w8, #0x1                // =1
    7010:      	ldr	x0, [x0]
    7014:      	blr	x8
    7018:      	cbz	x0, 0x7098 <generic_lsm_filter_arg+0x12a8>
    701c:      	cbz	w29, 0x7078 <generic_lsm_filter_arg+0x1288>
    7020:      	mov	x8, xzr
    7024:      	mov	x9, x25
    7028:      	mov	x10, x29
    702c:      	b	0x7044 <generic_lsm_filter_arg+0x1254>
    7030:      	add	x8, x8, #0x1
    7034:      	sub	x10, x10, #0x1
    7038:      	add	x9, x9, #0x1
    703c:      	cmp	x8, x29
    7040:      	b.eq	0x7078 <generic_lsm_filter_arg+0x1288>
    7044:      	mov	x11, xzr
    7048:      	cmp	x10, x11
    704c:      	b.eq	0x7030 <generic_lsm_filter_arg+0x1240>
    7050:      	ldrb	w12, [x0, x11]
    7054:      	cbz	w12, 0x7074 <generic_lsm_filter_arg+0x1284>
    7058:      	cmp	x11, #0x62
    705c:      	b.hi	0x7030 <generic_lsm_filter_arg+0x1240>
    7060:      	ldrb	w13, [x9, x11]
    7064:      	add	x11, x11, #0x1
    7068:      	cmp	w13, w12
    706c:      	b.eq	0x7048 <generic_lsm_filter_arg+0x1258>
    7070:      	b	0x7030 <generic_lsm_filter_arg+0x1240>
    7074:      	tbz	w8, #0x1f, 0x78b8 <generic_lsm_filter_arg+0x1ac8>
    7078:      	ldr	w9, [x23, #0x8]
    707c:      	add	w8, w22, #0xc
    7080:      	cmp	w8, w9
    7084:      	b.hs	0x7098 <generic_lsm_filter_arg+0x12a8>
    7088:      	add	x19, x19, #0x1
    708c:      	add	w22, w22, #0x4
    7090:      	cmp	x19, #0x64
    7094:      	b.ne	0x6ff4 <generic_lsm_filter_arg+0x1204>
    7098:      	mov	x22, xzr
    709c:      	ldr	x19, [sp, #0x30]
    70a0:      	ldp	x16, x15, [sp, #0x40]
    70a4:      	mov	w2, #0x5ea0             // =24224
    70a8:      	ldr	x17, [sp, #0x38]
    70ac:      	mov	w12, #0x1               // =1
    70b0:      	ldr	w8, [x23, #0x4]
    70b4:      	cmp	w8, #0x25
    70b8:      	b.hi	0x6084 <generic_lsm_filter_arg+0x294>
    70bc:      	mov	x9, #0x50               // =80
    70c0:      	lsl	x8, x12, x8
    70c4:      	movk	x9, #0xc00, lsl #16
    70c8:      	movk	x9, #0x20, lsl #32
    70cc:      	tst	x8, x9
    70d0:      	b.ne	0x91a8 <generic_lsm_filter_arg+0x33b8>
    70d4:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    70d8:      	and	w8, w29, #0xffff
    70dc:      	cmp	w8, #0x90
    70e0:      	b.hi	0x768c <generic_lsm_filter_arg+0x189c>
    70e4:      	and	w8, w29, #0xff
    70e8:      	mov	w9, #0xab               // =171
    70ec:      	tst	w29, #0xffff
    70f0:      	mul	w8, w8, w9
    70f4:      	mov	w9, #0x18               // =24
    70f8:      	lsr	w8, w8, #12
    70fc:      	msub	w8, w8, w9, w29
    7100:      	b.eq	0x7114 <generic_lsm_filter_arg+0x1324>
    7104:      	tst	w8, #0xff
    7108:      	mov	w9, w29
    710c:      	mov	w11, w29
    7110:      	b.eq	0x7130 <generic_lsm_filter_arg+0x1340>
    7114:      	sub	w8, w29, w8, uxtb
    7118:      	and	w9, w8, #0xffff
    711c:      	add	w8, w8, #0x18
    7120:      	and	w11, w8, #0xffff
    7124:      	cmp	w9, #0x78
    7128:      	b.hi	0x870c <generic_lsm_filter_arg+0x291c>
    712c:      	mov	w9, w11
    7130:      	and	w8, w9, #0xff
    7134:      	mov	w9, #0xab               // =171
    7138:      	mul	w8, w8, w9
    713c:      	lsr	w8, w8, #12
    7140:      	sub	w10, w8, #0x1
    7144:      	b	0x875c <generic_lsm_filter_arg+0x296c>
    7148:      	ldr	x19, [sp, #0x30]
    714c:      	sub	w8, w8, #0x12
    7150:      	cmp	w8, #0x2
    7154:      	b.hs	0x6084 <generic_lsm_filter_arg+0x294>
    7158:      	ldrb	w8, [x23, #0x10]
    715c:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7160:      	add	x9, sp, #0xac
    7164:      	add	x1, sp, #0xac
    7168:      	str	w8, [sp, #0xac]
    716c:      	mov	w8, #0x1                // =1
    7170:      	ldr	x0, [x0]
    7174:      	blr	x8
    7178:      	cbz	x0, 0x7680 <generic_lsm_filter_arg+0x1890>
    717c:      	str	x29, [sp, #0x88]
    7180:      	mov	w8, #0x1                // =1
    7184:      	add	x9, sp, #0x88
    7188:      	add	x1, sp, #0x88
    718c:      	b	0x7648 <generic_lsm_filter_arg+0x1858>
    7190:      	cmp	w8, #0x1
    7194:      	b.eq	0x78c0 <generic_lsm_filter_arg+0x1ad0>
    7198:      	cmp	w8, #0x2
    719c:      	b.ne	0x78cc <generic_lsm_filter_arg+0x1adc>
    71a0:      	ldrb	w10, [x25]
    71a4:      	cmp	w9, w10
    71a8:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    71ac:      	b	0x78cc <generic_lsm_filter_arg+0x1adc>
    71b0:      	cmp	w8, #0x1
    71b4:      	b.eq	0x7900 <generic_lsm_filter_arg+0x1b10>
    71b8:      	cmp	w8, #0x2
    71bc:      	b.ne	0x790c <generic_lsm_filter_arg+0x1b1c>
    71c0:      	ldrh	w10, [x25]
    71c4:      	cmp	w9, w10
    71c8:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    71cc:      	b	0x790c <generic_lsm_filter_arg+0x1b1c>
    71d0:      	ldrb	w8, [x23, #0x10]
    71d4:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    71d8:      	add	x9, sp, #0x88
    71dc:      	add	x1, sp, #0x88
    71e0:      	str	w8, [sp, #0x88]
    71e4:      	mov	w8, #0x1                // =1
    71e8:      	ldr	x0, [x0]
    71ec:      	blr	x8
    71f0:      	cbz	x0, 0x7680 <generic_lsm_filter_arg+0x1890>
    71f4:      	ldrb	w8, [x25]
    71f8:      	add	x9, sp, #0x60
    71fc:      	str	x8, [sp, #0x60]
    7200:      	mov	w8, #0x1                // =1
    7204:      	b	0x723c <generic_lsm_filter_arg+0x144c>
    7208:      	ldrb	w8, [x23, #0x10]
    720c:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7210:      	add	x9, sp, #0x88
    7214:      	add	x1, sp, #0x88
    7218:      	str	w8, [sp, #0x88]
    721c:      	mov	w8, #0x1                // =1
    7220:      	ldr	x0, [x0]
    7224:      	blr	x8
    7228:      	cbz	x0, 0x7680 <generic_lsm_filter_arg+0x1890>
    722c:      	ldrh	w8, [x25]
    7230:      	add	x9, sp, #0x60
    7234:      	str	x8, [sp, #0x60]
    7238:      	mov	w8, #0x1                // =1
    723c:      	add	x1, sp, #0x60
    7240:      	b	0x7648 <generic_lsm_filter_arg+0x1858>
    7244:      	ldr	x19, [sp, #0x30]
    7248:      	cmp	x29, #0x400
    724c:      	cset	w22, lo
    7250:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7254:      	ldr	x19, [sp, #0x30]
    7258:      	cmp	x29, #0x3ff
    725c:      	cset	w22, hi
    7260:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7264:      	ldp	x16, x15, [sp, #0x40]
    7268:      	cmp	x0, #0x0
    726c:      	mov	w2, #0x5ea0             // =24224
    7270:      	mov	w12, #0x1               // =1
    7274:      	cset	w8, eq
    7278:      	ldr	x17, [sp, #0x38]
    727c:      	mov	w22, w8
    7280:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7284:      	cmp	w8, #0x101
    7288:      	b.hs	0x789c <generic_lsm_filter_arg+0x1aac>
    728c:      	mov	w11, #0x100             // =256
    7290:      	b	0x8240 <generic_lsm_filter_arg+0x2450>
    7294:      	ldr	w8, [x23, #0x14]
    7298:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    729c:      	add	x9, sp, #0xac
    72a0:      	add	x1, sp, #0xac
    72a4:      	str	w8, [sp, #0xac]
    72a8:      	mov	w8, #0x1                // =1
    72ac:      	mov	w25, w13
    72b0:      	mov	w22, w11
    72b4:      	ldr	x0, [x0]
    72b8:      	blr	x8
    72bc:      	cbz	x0, 0x7c58 <generic_lsm_filter_arg+0x1e68>
    72c0:      	mov	w8, #0x80               // =128
    72c4:      	stp	w25, w19, [sp, #0x90]
    72c8:      	add	x1, sp, #0x88
    72cc:      	stp	w8, w22, [sp, #0x88]
    72d0:      	lsr	x8, x19, #32
    72d4:      	ldr	x19, [sp, #0x30]
    72d8:      	str	w8, [sp, #0x98]
    72dc:      	mov	w8, #0x1                // =1
    72e0:      	blr	x8
    72e4:      	ldr	w8, [x23, #0x4]
    72e8:      	sub	w9, w8, #0x18
    72ec:      	cmp	w9, #0x2
    72f0:      	b.lo	0x78b0 <generic_lsm_filter_arg+0x1ac0>
    72f4:      	sub	w8, w8, #0xd
    72f8:      	mov	w12, #0x1               // =1
    72fc:      	cmp	w8, #0x1
    7300:      	b.hi	0x68c0 <generic_lsm_filter_arg+0xad0>
    7304:      	cmp	x0, #0x0
    7308:      	cset	w8, ne
    730c:      	ldp	x16, x15, [sp, #0x40]
    7310:      	mov	w2, #0x5ea0             // =24224
    7314:      	mov	w22, w8
    7318:      	ldr	x17, [sp, #0x38]
    731c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7320:      	ldr	x19, [sp, #0x30]
    7324:      	mov	w8, wzr
    7328:      	mov	w22, wzr
    732c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7330:      	cmp	w8, #0x1e
    7334:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    7338:      	ldr	w8, [x23, #0x10]
    733c:      	and	x8, x8, #0x7
    7340:      	add	x9, x20, x8, lsl #2
    7344:      	ldr	w9, [x9, x2]
    7348:      	cbnz	w9, 0x5eec <generic_lsm_filter_arg+0xfc>
    734c:      	add	x8, x20, x8, lsl #3
    7350:      	ldr	x9, [x25]
    7354:      	ldr	x8, [x8, #0x5e78]
    7358:      	and	x8, x8, #0x7ff
    735c:      	add	x8, x20, x8
    7360:      	ldr	x8, [x8, #0x90]
    7364:      	bics	xzr, x8, x9
    7368:      	cset	w22, ne
    736c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7370:      	cmp	w8, #0x21
    7374:      	b.eq	0x79e4 <generic_lsm_filter_arg+0x1bf4>
    7378:      	cmp	w8, #0x22
    737c:      	b.ne	0x9174 <generic_lsm_filter_arg+0x3384>
    7380:      	mov	w19, #0x10              // =16
    7384:      	ldr	w8, [x23, x19]
    7388:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    738c:      	add	x9, sp, #0x60
    7390:      	add	x1, sp, #0x60
    7394:      	str	w8, [sp, #0x60]
    7398:      	mov	w8, #0x1                // =1
    739c:      	ldr	x0, [x0]
    73a0:      	blr	x8
    73a4:      	cbz	x0, 0x916c <generic_lsm_filter_arg+0x337c>
    73a8:      	mov	x1, x0
    73ac:      	mov	x0, x29
    73b0:      	mov	x2, x25
    73b4:      	bl	0x73b4 <generic_lsm_filter_arg+0x15c4>
    73b8:      	tbz	w0, #0x1f, 0x81c4 <generic_lsm_filter_arg+0x23d4>
    73bc:      	ldr	w8, [x23, #0x8]
    73c0:      	add	x19, x19, #0x4
    73c4:      	mov	w12, #0x1               // =1
    73c8:      	mov	x22, xzr
    73cc:      	sub	w9, w19, #0x8
    73d0:      	cmp	w9, w8
    73d4:      	b.hs	0x9174 <generic_lsm_filter_arg+0x3384>
    73d8:      	cmp	x19, #0x1a0
    73dc:      	b.ne	0x7384 <generic_lsm_filter_arg+0x1594>
    73e0:      	b	0x9174 <generic_lsm_filter_arg+0x3384>
    73e4:      	mov	x25, x10
    73e8:      	cmp	w8, #0x8
    73ec:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    73f0:      	ldr	w8, [x23, #0x10]
    73f4:      	str	wzr, [sp, #0x88]
    73f8:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    73fc:      	add	x9, sp, #0x60
    7400:      	add	x1, sp, #0x60
    7404:      	str	w8, [sp, #0x60]
    7408:      	mov	w8, #0x1                // =1
    740c:      	ldr	x0, [x0]
    7410:      	blr	x8
    7414:      	mov	x22, xzr
    7418:      	cbz	w29, 0x7d84 <generic_lsm_filter_arg+0x1f94>
    741c:      	cbz	x0, 0x7d84 <generic_lsm_filter_arg+0x1f94>
    7420:      	mov	x19, x0
    7424:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7428:      	mov	w8, #0x1                // =1
    742c:      	ldr	x0, [x0]
    7430:      	add	x9, sp, #0x88
    7434:      	add	x1, sp, #0x88
    7438:      	blr	x8
    743c:      	cbz	x0, 0x7d7c <generic_lsm_filter_arg+0x1f8c>
    7440:      	lsl	w9, w29, #3
    7444:      	mov	x8, x0
    7448:      	mov	x2, x25
    744c:      	mov	w1, w29
    7450:      	str	w9, [x8], #0x4
    7454:      	mov	w9, #0x4                // =4
    7458:      	mov	x25, x0
    745c:      	mov	x0, x8
    7460:      	blr	x9
    7464:      	mov	w8, #0x1                // =1
    7468:      	mov	x0, x19
    746c:      	mov	x1, x25
    7470:      	blr	x8
    7474:      	cmp	x0, #0x0
    7478:      	cset	w22, ne
    747c:      	b	0x7d80 <generic_lsm_filter_arg+0x1f90>
    7480:      	mov	w13, #0x100             // =256
    7484:      	sub	w8, w13, #0x100
    7488:      	ror	w8, w8, #0x8
    748c:      	cmp	w8, #0x2
    7490:      	b.gt	0x7884 <generic_lsm_filter_arg+0x1a94>
    7494:      	cbz	w8, 0x7e6c <generic_lsm_filter_arg+0x207c>
    7498:      	cmp	w8, #0x1
    749c:      	b.ne	0x7e64 <generic_lsm_filter_arg+0x2074>
    74a0:      	mov	w11, #0x7               // =7
    74a4:      	b	0x7e78 <generic_lsm_filter_arg+0x2088>
    74a8:      	ldrb	w8, [x23, #0x10]
    74ac:      	ldrh	w19, [x25]
    74b0:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    74b4:      	add	x9, sp, #0x88
    74b8:      	add	x1, sp, #0x88
    74bc:      	str	w8, [sp, #0x88]
    74c0:      	mov	w8, #0x1                // =1
    74c4:      	ldr	x0, [x0]
    74c8:      	blr	x8
    74cc:      	cbz	x0, 0x7bf8 <generic_lsm_filter_arg+0x1e08>
    74d0:      	str	x19, [sp, #0x60]
    74d4:      	mov	w8, #0x1                // =1
    74d8:      	add	x9, sp, #0x60
    74dc:      	add	x1, sp, #0x60
    74e0:      	b	0x7b9c <generic_lsm_filter_arg+0x1dac>
    74e4:      	ldr	w8, [x23, #0x10]
    74e8:      	str	wzr, [sp, #0x88]
    74ec:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    74f0:      	add	x9, sp, #0x60
    74f4:      	add	x1, sp, #0x60
    74f8:      	str	w8, [sp, #0x60]
    74fc:      	mov	w8, #0x1                // =1
    7500:      	ldr	x0, [x0]
    7504:      	blr	x8
    7508:      	mov	x22, xzr
    750c:      	cbz	w25, 0x9170 <generic_lsm_filter_arg+0x3380>
    7510:      	cbz	x0, 0x9170 <generic_lsm_filter_arg+0x3380>
    7514:      	mov	x19, x0
    7518:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    751c:      	mov	w8, #0x1                // =1
    7520:      	ldr	x0, [x0]
    7524:      	add	x9, sp, #0x88
    7528:      	add	x1, sp, #0x88
    752c:      	blr	x8
    7530:      	cbz	x0, 0x916c <generic_lsm_filter_arg+0x337c>
    7534:      	cmp	w25, #0xff
    7538:      	mov	w8, #0xff               // =255
    753c:      	mov	x22, x0
    7540:      	mov	x2, x29
    7544:      	csel	w1, w25, w8, lo
    7548:      	mov	x8, x0
    754c:      	lsl	w9, w1, #3
    7550:      	str	w9, [x8], #0x4
    7554:      	mov	w9, #0x4                // =4
    7558:      	mov	x0, x8
    755c:      	blr	x9
    7560:      	mov	w8, #0x1                // =1
    7564:      	mov	x0, x19
    7568:      	mov	x1, x22
    756c:      	b	0x915c <generic_lsm_filter_arg+0x336c>
    7570:      	cmp	w25, #0x1, lsl #12      // =0x1000
    7574:      	str	wzr, [sp, #0x88]
    7578:      	b.ls	0x7a98 <generic_lsm_filter_arg+0x1ca8>
    757c:      	mov	x22, xzr
    7580:      	b	0x9174 <generic_lsm_filter_arg+0x3384>
    7584:      	ldr	x8, [x25]
    7588:      	cmp	x11, x8
    758c:      	b.hi	0x7598 <generic_lsm_filter_arg+0x17a8>
    7590:      	cmp	x8, x10
    7594:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    7598:      	ldr	w10, [x23, #0x8]
    759c:      	cmp	w10, #0x19
    75a0:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    75a4:      	ldp	x12, x11, [x23, #0x20]
    75a8:      	cmp	w9, #0xc
    75ac:      	b.eq	0x75b8 <generic_lsm_filter_arg+0x17c8>
    75b0:      	cmp	w9, #0xa
    75b4:      	b.ne	0x7c08 <generic_lsm_filter_arg+0x1e18>
    75b8:      	cmp	x12, x8
    75bc:      	mov	w12, #0x1               // =1
    75c0:      	b.gt	0x7c1c <generic_lsm_filter_arg+0x1e2c>
    75c4:      	cmp	x8, x11
    75c8:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    75cc:      	b	0x7c1c <generic_lsm_filter_arg+0x1e2c>
    75d0:      	ldr	x10, [x25]
    75d4:      	cmp	x11, x10
    75d8:      	ccmp	x10, x8, #0x2, ls
    75dc:      	cset	w8, ls
    75e0:      	ldr	w11, [x23, #0x8]
    75e4:      	cmp	w11, #0x19
    75e8:      	b.lo	0x8678 <generic_lsm_filter_arg+0x2888>
    75ec:      	ldp	x13, x12, [x23, #0x20]
    75f0:      	cmp	w9, #0xc
    75f4:      	b.eq	0x7600 <generic_lsm_filter_arg+0x1810>
    75f8:      	cmp	w9, #0xa
    75fc:      	b.ne	0x7b08 <generic_lsm_filter_arg+0x1d18>
    7600:      	cmp	x13, x10
    7604:      	ccmp	x10, x12, #0x0, le
    7608:      	cset	w12, le
    760c:      	b	0x7b14 <generic_lsm_filter_arg+0x1d24>
    7610:      	ldrh	w22, [x25, #0x26]
    7614:      	ldrb	w8, [x23, #0x10]
    7618:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    761c:      	add	x9, sp, #0xac
    7620:      	add	x1, sp, #0xac
    7624:      	str	w8, [sp, #0xac]
    7628:      	mov	w8, #0x1                // =1
    762c:      	ldr	x0, [x0]
    7630:      	blr	x8
    7634:      	cbz	x0, 0x7680 <generic_lsm_filter_arg+0x1890>
    7638:      	str	x22, [sp, #0x88]
    763c:      	mov	w8, #0x1                // =1
    7640:      	add	x9, sp, #0x88
    7644:      	add	x1, sp, #0x88
    7648:      	blr	x8
    764c:      	ldr	w9, [x23, #0x4]
    7650:      	mov	w8, wzr
    7654:      	mov	w12, #0x1               // =1
    7658:      	cmp	w9, #0x1d
    765c:      	b.hi	0x7be4 <generic_lsm_filter_arg+0x1df4>
    7660:      	mov	w10, #0x8400            // =33792
    7664:      	lsl	w9, w12, w9
    7668:      	movk	w10, #0x3003, lsl #16
    766c:      	tst	w9, w10
    7670:      	b.eq	0x7bcc <generic_lsm_filter_arg+0x1ddc>
    7674:      	cmp	x0, #0x0
    7678:      	cset	w8, ne
    767c:      	b	0x7be4 <generic_lsm_filter_arg+0x1df4>
    7680:      	mov	x22, xzr
    7684:      	mov	w12, #0x1               // =1
    7688:      	b	0x7be8 <generic_lsm_filter_arg+0x1df8>
    768c:      	cmp	w8, #0x101
    7690:      	b.hs	0x7d68 <generic_lsm_filter_arg+0x1f78>
    7694:      	mov	w11, #0x100             // =256
    7698:      	b	0x870c <generic_lsm_filter_arg+0x291c>
    769c:      	ldr	x11, [x25]
    76a0:      	cmp	x11, x10
    76a4:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    76a8:      	b	0x76b8 <generic_lsm_filter_arg+0x18c8>
    76ac:      	ldr	x11, [x25]
    76b0:      	cmp	x11, x10
    76b4:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    76b8:      	ldr	w10, [x23, #0x8]
    76bc:      	cmp	w10, #0x11
    76c0:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    76c4:      	ldr	x11, [x23, #0x18]
    76c8:      	cmp	w8, #0x2
    76cc:      	b.le	0x76f0 <generic_lsm_filter_arg+0x1900>
    76d0:      	sub	w12, w8, #0x3
    76d4:      	cmp	w12, #0x2
    76d8:      	b.hs	0x7724 <generic_lsm_filter_arg+0x1934>
    76dc:      	ldr	x12, [x25]
    76e0:      	cmp	x12, x11
    76e4:      	mov	w12, #0x1               // =1
    76e8:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    76ec:      	b	0x810c <generic_lsm_filter_arg+0x231c>
    76f0:      	cmp	w8, #0x1
    76f4:      	b.eq	0x77d0 <generic_lsm_filter_arg+0x19e0>
    76f8:      	cmp	w8, #0x2
    76fc:      	b.ne	0x810c <generic_lsm_filter_arg+0x231c>
    7700:      	cmp	w9, #0xc
    7704:      	b.eq	0x7710 <generic_lsm_filter_arg+0x1920>
    7708:      	cmp	w9, #0xa
    770c:      	b.ne	0x80fc <generic_lsm_filter_arg+0x230c>
    7710:      	ldr	x12, [x25]
    7714:      	cmp	x12, x11
    7718:      	mov	w12, #0x1               // =1
    771c:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    7720:      	b	0x810c <generic_lsm_filter_arg+0x231c>
    7724:      	cmp	w8, #0xc
    7728:      	mov	w12, #0x1               // =1
    772c:      	b.ne	0x810c <generic_lsm_filter_arg+0x231c>
    7730:      	ldr	x12, [x25]
    7734:      	tst	x12, x11
    7738:      	mov	w12, #0x1               // =1
    773c:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    7740:      	b	0x810c <generic_lsm_filter_arg+0x231c>
    7744:      	cmp	w8, #0xc
    7748:      	b.ne	0x78cc <generic_lsm_filter_arg+0x1adc>
    774c:      	ldrb	w10, [x25]
    7750:      	tst	w9, w10
    7754:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    7758:      	b	0x78cc <generic_lsm_filter_arg+0x1adc>
    775c:      	cmp	w8, #0xc
    7760:      	b.ne	0x790c <generic_lsm_filter_arg+0x1b1c>
    7764:      	ldrh	w10, [x25]
    7768:      	tst	w9, w10
    776c:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    7770:      	b	0x790c <generic_lsm_filter_arg+0x1b1c>
    7774:      	ldr	w9, [x23, #0x8]
    7778:      	cmp	w9, #0xd
    777c:      	b.lo	0x65ac <generic_lsm_filter_arg+0x7bc>
    7780:      	ldr	w10, [x23, #0x14]
    7784:      	cbz	w10, 0x65ac <generic_lsm_filter_arg+0x7bc>
    7788:      	cmp	w10, w8
    778c:      	b.eq	0x63f0 <generic_lsm_filter_arg+0x600>
    7790:      	cmp	w9, #0x11
    7794:      	b.lo	0x65ac <generic_lsm_filter_arg+0x7bc>
    7798:      	ldr	w10, [x23, #0x18]
    779c:      	cbz	w10, 0x65ac <generic_lsm_filter_arg+0x7bc>
    77a0:      	cmp	w10, w8
    77a4:      	b.eq	0x63f0 <generic_lsm_filter_arg+0x600>
    77a8:      	cmp	w9, #0x15
    77ac:      	b.lo	0x77c4 <generic_lsm_filter_arg+0x19d4>
    77b0:      	ldr	w9, [x23, #0x1c]
    77b4:      	cbz	w9, 0x77c4 <generic_lsm_filter_arg+0x19d4>
    77b8:      	cmp	w9, w8
    77bc:      	cset	w22, eq
    77c0:      	b	0x77c8 <generic_lsm_filter_arg+0x19d8>
    77c4:      	mov	x22, xzr
    77c8:      	ldr	x19, [sp, #0x30]
    77cc:      	b	0x8bd4 <generic_lsm_filter_arg+0x2de4>
    77d0:      	cmp	w9, #0xc
    77d4:      	b.eq	0x77e0 <generic_lsm_filter_arg+0x19f0>
    77d8:      	cmp	w9, #0xa
    77dc:      	b.ne	0x80e8 <generic_lsm_filter_arg+0x22f8>
    77e0:      	ldr	x12, [x25]
    77e4:      	cmp	x12, x11
    77e8:      	mov	w12, #0x1               // =1
    77ec:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    77f0:      	b	0x810c <generic_lsm_filter_arg+0x231c>
    77f4:      	ldp	w8, w11, [x23, #0x10]
    77f8:      	ldrb	w9, [x25]
    77fc:      	cmp	w8, w9
    7800:      	ldr	w10, [x23, #0x8]
    7804:      	ccmp	w11, w9, #0x0, ls
    7808:      	cset	w8, hs
    780c:      	cmp	w10, #0x11
    7810:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    7814:      	b	0x7838 <generic_lsm_filter_arg+0x1a48>
    7818:      	ldp	w8, w11, [x23, #0x10]
    781c:      	ldrh	w9, [x25]
    7820:      	cmp	w8, w9
    7824:      	ldr	w10, [x23, #0x8]
    7828:      	ccmp	w11, w9, #0x0, ls
    782c:      	cset	w8, hs
    7830:      	cmp	w10, #0x11
    7834:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    7838:      	ldp	w11, w12, [x23, #0x18]
    783c:      	cmp	w11, w9
    7840:      	ccmp	w12, w9, #0x0, ls
    7844:      	mov	w12, #0x1               // =1
    7848:      	csinc	w8, w8, wzr, lo
    784c:      	cmp	w10, #0x19
    7850:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    7854:      	ldp	w11, w12, [x23, #0x20]
    7858:      	cmp	w11, w9
    785c:      	ccmp	w12, w9, #0x0, ls
    7860:      	mov	w12, #0x1               // =1
    7864:      	csinc	w8, w8, wzr, lo
    7868:      	cmp	w10, #0x21
    786c:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    7870:      	ldp	w10, w11, [x23, #0x28]
    7874:      	cmp	w10, w9
    7878:      	ccmp	w11, w9, #0x0, ls
    787c:      	csinc	w8, w8, wzr, lo
    7880:      	b	0x894c <generic_lsm_filter_arg+0x2b5c>
    7884:      	cmp	w8, #0x3
    7888:      	b.eq	0x7e74 <generic_lsm_filter_arg+0x2084>
    788c:      	cmp	w8, #0x7
    7890:      	b.ne	0x7e64 <generic_lsm_filter_arg+0x2074>
    7894:      	mov	w11, #0x9               // =9
    7898:      	b	0x7e78 <generic_lsm_filter_arg+0x2088>
    789c:      	and	w8, w29, #0xffff
    78a0:      	cmp	w8, #0x201
    78a4:      	b.hs	0x7dfc <generic_lsm_filter_arg+0x200c>
    78a8:      	mov	w11, #0x200             // =512
    78ac:      	b	0x8240 <generic_lsm_filter_arg+0x2450>
    78b0:      	cmp	x0, #0x0
    78b4:      	b	0x7c68 <generic_lsm_filter_arg+0x1e78>
    78b8:      	mov	w22, #0x1               // =1
    78bc:      	b	0x709c <generic_lsm_filter_arg+0x12ac>
    78c0:      	ldrb	w10, [x25]
    78c4:      	cmp	w9, w10
    78c8:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    78cc:      	ldr	w9, [x23, #0x8]
    78d0:      	cmp	w9, #0xd
    78d4:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    78d8:      	ldr	w10, [x23, #0x14]
    78dc:      	cmp	w8, #0x2
    78e0:      	b.le	0x7dbc <generic_lsm_filter_arg+0x1fcc>
    78e4:      	sub	w11, w8, #0x3
    78e8:      	cmp	w11, #0x2
    78ec:      	b.hs	0x8194 <generic_lsm_filter_arg+0x23a4>
    78f0:      	ldrb	w11, [x25]
    78f4:      	cmp	w10, w11
    78f8:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    78fc:      	b	0x8448 <generic_lsm_filter_arg+0x2658>
    7900:      	ldrh	w10, [x25]
    7904:      	cmp	w9, w10
    7908:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    790c:      	ldr	w9, [x23, #0x8]
    7910:      	cmp	w9, #0xd
    7914:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    7918:      	ldr	w10, [x23, #0x14]
    791c:      	cmp	w8, #0x2
    7920:      	b.le	0x7ddc <generic_lsm_filter_arg+0x1fec>
    7924:      	sub	w11, w8, #0x3
    7928:      	cmp	w11, #0x2
    792c:      	b.hs	0x81ac <generic_lsm_filter_arg+0x23bc>
    7930:      	ldrh	w11, [x25]
    7934:      	cmp	w10, w11
    7938:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    793c:      	b	0x8484 <generic_lsm_filter_arg+0x2694>
    7940:      	ldr	w8, [x25]
    7944:      	cmp	w11, w8
    7948:      	b.hi	0x7954 <generic_lsm_filter_arg+0x1b64>
    794c:      	cmp	w8, w10
    7950:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    7954:      	ldr	w10, [x23, #0x8]
    7958:      	cmp	w10, #0x11
    795c:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    7960:      	ldp	w12, w11, [x23, #0x18]
    7964:      	mov	w13, #0x1               // =1
    7968:      	cmp	w9, #0xc
    796c:      	b.hi	0x8004 <generic_lsm_filter_arg+0x2214>
    7970:      	lsl	w13, w13, w9
    7974:      	mov	w14, #0x1402            // =5122
    7978:      	tst	w13, w14
    797c:      	b.eq	0x8004 <generic_lsm_filter_arg+0x2214>
    7980:      	cmp	w12, w8
    7984:      	mov	w12, #0x1               // =1
    7988:      	b.gt	0x8018 <generic_lsm_filter_arg+0x2228>
    798c:      	cmp	w8, w11
    7990:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    7994:      	b	0x8018 <generic_lsm_filter_arg+0x2228>
    7998:      	ldr	w10, [x25]
    799c:      	cmp	w11, w10
    79a0:      	ccmp	w10, w8, #0x2, ls
    79a4:      	cset	w8, ls
    79a8:      	ldr	w11, [x23, #0x8]
    79ac:      	cmp	w11, #0x11
    79b0:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    79b4:      	ldp	w13, w12, [x23, #0x18]
    79b8:      	mov	w14, #0x1               // =1
    79bc:      	cmp	w9, #0xc
    79c0:      	b.hi	0x7e0c <generic_lsm_filter_arg+0x201c>
    79c4:      	lsl	w14, w14, w9
    79c8:      	mov	w1, #0x1402             // =5122
    79cc:      	tst	w14, w1
    79d0:      	b.eq	0x7e0c <generic_lsm_filter_arg+0x201c>
    79d4:      	cmp	w13, w10
    79d8:      	ccmp	w10, w12, #0x0, le
    79dc:      	cset	w12, le
    79e0:      	b	0x7e18 <generic_lsm_filter_arg+0x2028>
    79e4:      	str	x29, [sp, #0x28]
    79e8:      	mov	x19, xzr
    79ec:      	mov	w22, wzr
    79f0:      	add	x29, x23, #0x10
    79f4:      	ldr	w8, [x29, x19, lsl #2]
    79f8:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    79fc:      	add	x9, sp, #0x60
    7a00:      	add	x1, sp, #0x60
    7a04:      	str	w8, [sp, #0x60]
    7a08:      	mov	w8, #0x1                // =1
    7a0c:      	ldr	x0, [x0]
    7a10:      	blr	x8
    7a14:      	cbz	x0, 0x916c <generic_lsm_filter_arg+0x337c>
    7a18:      	cbz	w25, 0x7a74 <generic_lsm_filter_arg+0x1c84>
    7a1c:      	ldr	x9, [sp, #0x28]
    7a20:      	mov	x8, xzr
    7a24:      	mov	x10, x25
    7a28:      	b	0x7a40 <generic_lsm_filter_arg+0x1c50>
    7a2c:      	add	x8, x8, #0x1
    7a30:      	sub	x10, x10, #0x1
    7a34:      	add	x9, x9, #0x1
    7a38:      	cmp	x8, x25
    7a3c:      	b.eq	0x7a74 <generic_lsm_filter_arg+0x1c84>
    7a40:      	mov	x11, xzr
    7a44:      	cmp	x10, x11
    7a48:      	b.eq	0x7a2c <generic_lsm_filter_arg+0x1c3c>
    7a4c:      	ldrb	w12, [x0, x11]
    7a50:      	cbz	w12, 0x7a70 <generic_lsm_filter_arg+0x1c80>
    7a54:      	cmp	x11, #0x62
    7a58:      	b.hi	0x7a2c <generic_lsm_filter_arg+0x1c3c>
    7a5c:      	ldrb	w13, [x9, x11]
    7a60:      	add	x11, x11, #0x1
    7a64:      	cmp	w13, w12
    7a68:      	b.eq	0x7a44 <generic_lsm_filter_arg+0x1c54>
    7a6c:      	b	0x7a2c <generic_lsm_filter_arg+0x1c3c>
    7a70:      	tbz	w8, #0x1f, 0x81c4 <generic_lsm_filter_arg+0x23d4>
    7a74:      	ldr	w9, [x23, #0x8]
    7a78:      	add	w8, w22, #0xc
    7a7c:      	cmp	w8, w9
    7a80:      	b.hs	0x916c <generic_lsm_filter_arg+0x337c>
    7a84:      	add	x19, x19, #0x1
    7a88:      	add	w22, w22, #0x4
    7a8c:      	cmp	x19, #0x64
    7a90:      	b.ne	0x79f4 <generic_lsm_filter_arg+0x1c04>
    7a94:      	b	0x916c <generic_lsm_filter_arg+0x337c>
    7a98:      	and	w8, w25, #0xffff
    7a9c:      	cmp	w8, #0x90
    7aa0:      	b.hi	0x8058 <generic_lsm_filter_arg+0x2268>
    7aa4:      	and	w8, w25, #0xff
    7aa8:      	mov	w9, #0xab               // =171
    7aac:      	tst	w25, #0xffff
    7ab0:      	mul	w8, w8, w9
    7ab4:      	mov	w9, #0x18               // =24
    7ab8:      	lsr	w8, w8, #12
    7abc:      	msub	w8, w8, w9, w25
    7ac0:      	b.eq	0x7ad4 <generic_lsm_filter_arg+0x1ce4>
    7ac4:      	tst	w8, #0xff
    7ac8:      	mov	w9, w25
    7acc:      	mov	w11, w25
    7ad0:      	b.eq	0x7af0 <generic_lsm_filter_arg+0x1d00>
    7ad4:      	sub	w8, w25, w8, uxtb
    7ad8:      	and	w9, w8, #0xffff
    7adc:      	add	w8, w8, #0x18
    7ae0:      	and	w11, w8, #0xffff
    7ae4:      	cmp	w9, #0x78
    7ae8:      	b.hi	0x8e60 <generic_lsm_filter_arg+0x3070>
    7aec:      	mov	w9, w11
    7af0:      	and	w8, w9, #0xff
    7af4:      	mov	w9, #0xab               // =171
    7af8:      	mul	w8, w8, w9
    7afc:      	lsr	w8, w8, #12
    7b00:      	sub	w10, w8, #0x1
    7b04:      	b	0x8eb0 <generic_lsm_filter_arg+0x30c0>
    7b08:      	cmp	x13, x10
    7b0c:      	ccmp	x10, x12, #0x2, ls
    7b10:      	cset	w12, ls
    7b14:      	orr	w8, w8, w12
    7b18:      	cmp	w11, #0x29
    7b1c:      	b.lo	0x8678 <generic_lsm_filter_arg+0x2888>
    7b20:      	ldp	x13, x12, [x23, #0x30]
    7b24:      	cmp	w9, #0xc
    7b28:      	b.eq	0x7b34 <generic_lsm_filter_arg+0x1d44>
    7b2c:      	cmp	w9, #0xa
    7b30:      	b.ne	0x8068 <generic_lsm_filter_arg+0x2278>
    7b34:      	cmp	x13, x10
    7b38:      	ccmp	x10, x12, #0x0, le
    7b3c:      	cset	w12, le
    7b40:      	b	0x8074 <generic_lsm_filter_arg+0x2284>
    7b44:      	mov	x19, xzr
    7b48:      	cmp	w9, #0x29
    7b4c:      	b.ne	0x7b58 <generic_lsm_filter_arg+0x1d68>
    7b50:      	cbz	x10, 0x7b58 <generic_lsm_filter_arg+0x1d68>
    7b54:      	ldrb	w19, [x10, #0x3a]
    7b58:      	cmp	w9, #0x29
    7b5c:      	b.eq	0x7b68 <generic_lsm_filter_arg+0x1d78>
    7b60:      	cmp	w9, #0x7
    7b64:      	b.ne	0x7e58 <generic_lsm_filter_arg+0x2068>
    7b68:      	ldrb	w8, [x23, #0x10]
    7b6c:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7b70:      	add	x9, sp, #0xac
    7b74:      	add	x1, sp, #0xac
    7b78:      	str	w8, [sp, #0xac]
    7b7c:      	mov	w8, #0x1                // =1
    7b80:      	ldr	x0, [x0]
    7b84:      	blr	x8
    7b88:      	cbz	x0, 0x7bf8 <generic_lsm_filter_arg+0x1e08>
    7b8c:      	str	x19, [sp, #0x88]
    7b90:      	mov	w8, #0x1                // =1
    7b94:      	add	x9, sp, #0x88
    7b98:      	add	x1, sp, #0x88
    7b9c:      	blr	x8
    7ba0:      	ldr	w9, [x23, #0x4]
    7ba4:      	mov	w8, wzr
    7ba8:      	cmp	w9, #0x1d
    7bac:      	b.hi	0x8b18 <generic_lsm_filter_arg+0x2d28>
    7bb0:      	ldr	x19, [sp, #0x30]
    7bb4:      	mov	w12, #0x1               // =1
    7bb8:      	mov	w10, #0x8400            // =33792
    7bbc:      	lsl	w9, w12, w9
    7bc0:      	movk	w10, #0x3003, lsl #16
    7bc4:      	tst	w9, w10
    7bc8:      	b.ne	0x7674 <generic_lsm_filter_arg+0x1884>
    7bcc:      	mov	w10, #0x800             // =2048
    7bd0:      	movk	w10, #0xc, lsl #16
    7bd4:      	tst	w9, w10
    7bd8:      	b.eq	0x7be4 <generic_lsm_filter_arg+0x1df4>
    7bdc:      	cmp	x0, #0x0
    7be0:      	cset	w8, eq
    7be4:      	mov	w22, w8
    7be8:      	ldp	x16, x15, [sp, #0x40]
    7bec:      	mov	w2, #0x5ea0             // =24224
    7bf0:      	ldr	x17, [sp, #0x38]
    7bf4:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7bf8:      	ldr	x19, [sp, #0x30]
    7bfc:      	mov	x22, xzr
    7c00:      	mov	w12, #0x1               // =1
    7c04:      	b	0x7be8 <generic_lsm_filter_arg+0x1df8>
    7c08:      	cmp	x12, x8
    7c0c:      	mov	w12, #0x1               // =1
    7c10:      	b.hi	0x7c1c <generic_lsm_filter_arg+0x1e2c>
    7c14:      	cmp	x8, x11
    7c18:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    7c1c:      	cmp	w10, #0x29
    7c20:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    7c24:      	ldp	x12, x11, [x23, #0x30]
    7c28:      	cmp	w9, #0xc
    7c2c:      	b.eq	0x7c38 <generic_lsm_filter_arg+0x1e48>
    7c30:      	cmp	w9, #0xa
    7c34:      	b.ne	0x80a4 <generic_lsm_filter_arg+0x22b4>
    7c38:      	cmp	x12, x8
    7c3c:      	mov	w12, #0x1               // =1
    7c40:      	b.gt	0x80b8 <generic_lsm_filter_arg+0x22c8>
    7c44:      	cmp	x8, x11
    7c48:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    7c4c:      	b	0x80b8 <generic_lsm_filter_arg+0x22c8>
    7c50:      	ldr	w8, [x23, #0x4]
    7c54:      	b	0x7c60 <generic_lsm_filter_arg+0x1e70>
    7c58:      	ldr	w8, [x23, #0x4]
    7c5c:      	ldr	x19, [sp, #0x30]
    7c60:      	and	w8, w8, #0xfffffffe
    7c64:      	cmp	w8, #0x18
    7c68:      	cset	w8, eq
    7c6c:      	ldp	x16, x15, [sp, #0x40]
    7c70:      	mov	w2, #0x5ea0             // =24224
    7c74:      	mov	w12, #0x1               // =1
    7c78:      	mov	w22, w8
    7c7c:      	ldr	x17, [sp, #0x38]
    7c80:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7c84:      	ldr	w11, [x25]
    7c88:      	cmp	w11, w10
    7c8c:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    7c90:      	b	0x7ca0 <generic_lsm_filter_arg+0x1eb0>
    7c94:      	ldr	w11, [x25]
    7c98:      	cmp	w11, w10
    7c9c:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    7ca0:      	ldr	w10, [x23, #0x8]
    7ca4:      	cmp	w10, #0xd
    7ca8:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    7cac:      	ldr	w11, [x23, #0x14]
    7cb0:      	cmp	w8, #0x2
    7cb4:      	b.le	0x7cd8 <generic_lsm_filter_arg+0x1ee8>
    7cb8:      	sub	w12, w8, #0x3
    7cbc:      	cmp	w12, #0x2
    7cc0:      	b.hs	0x7d18 <generic_lsm_filter_arg+0x1f28>
    7cc4:      	ldr	w12, [x25]
    7cc8:      	cmp	w12, w11
    7ccc:      	mov	w12, #0x1               // =1
    7cd0:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    7cd4:      	b	0x85a4 <generic_lsm_filter_arg+0x27b4>
    7cd8:      	cmp	w8, #0x1
    7cdc:      	b.eq	0x7d38 <generic_lsm_filter_arg+0x1f48>
    7ce0:      	cmp	w8, #0x2
    7ce4:      	b.ne	0x85a4 <generic_lsm_filter_arg+0x27b4>
    7ce8:      	mov	w12, #0x1               // =1
    7cec:      	cmp	w9, #0xc
    7cf0:      	b.hi	0x8594 <generic_lsm_filter_arg+0x27a4>
    7cf4:      	lsl	w12, w12, w9
    7cf8:      	mov	w13, #0x1402            // =5122
    7cfc:      	tst	w12, w13
    7d00:      	b.eq	0x8594 <generic_lsm_filter_arg+0x27a4>
    7d04:      	ldr	w12, [x25]
    7d08:      	cmp	w12, w11
    7d0c:      	mov	w12, #0x1               // =1
    7d10:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    7d14:      	b	0x85a4 <generic_lsm_filter_arg+0x27b4>
    7d18:      	cmp	w8, #0xc
    7d1c:      	mov	w12, #0x1               // =1
    7d20:      	b.ne	0x85a4 <generic_lsm_filter_arg+0x27b4>
    7d24:      	ldr	w12, [x25]
    7d28:      	tst	w12, w11
    7d2c:      	mov	w12, #0x1               // =1
    7d30:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    7d34:      	b	0x85a4 <generic_lsm_filter_arg+0x27b4>
    7d38:      	mov	w12, #0x1               // =1
    7d3c:      	cmp	w9, #0xc
    7d40:      	b.hi	0x8580 <generic_lsm_filter_arg+0x2790>
    7d44:      	lsl	w12, w12, w9
    7d48:      	mov	w13, #0x1402            // =5122
    7d4c:      	tst	w12, w13
    7d50:      	b.eq	0x8580 <generic_lsm_filter_arg+0x2790>
    7d54:      	ldr	w12, [x25]
    7d58:      	cmp	w12, w11
    7d5c:      	mov	w12, #0x1               // =1
    7d60:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    7d64:      	b	0x85a4 <generic_lsm_filter_arg+0x27b4>
    7d68:      	and	w8, w29, #0xffff
    7d6c:      	cmp	w8, #0x201
    7d70:      	b.hs	0x81cc <generic_lsm_filter_arg+0x23dc>
    7d74:      	mov	w11, #0x200             // =512
    7d78:      	b	0x870c <generic_lsm_filter_arg+0x291c>
    7d7c:      	mov	x22, xzr
    7d80:      	ldr	x19, [sp, #0x30]
    7d84:      	ldr	w8, [x23, #0x4]
    7d88:      	cmp	w8, #0x25
    7d8c:      	b.hi	0x6e3c <generic_lsm_filter_arg+0x104c>
    7d90:      	mov	x9, #0x50               // =80
    7d94:      	ldp	x16, x15, [sp, #0x40]
    7d98:      	mov	w12, #0x1               // =1
    7d9c:      	mov	w2, #0x5ea0             // =24224
    7da0:      	movk	x9, #0xc00, lsl #16
    7da4:      	ldr	x17, [sp, #0x38]
    7da8:      	lsl	x8, x12, x8
    7dac:      	movk	x9, #0x20, lsl #32
    7db0:      	tst	x8, x9
    7db4:      	b.ne	0x8c08 <generic_lsm_filter_arg+0x2e18>
    7db8:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7dbc:      	cmp	w8, #0x1
    7dc0:      	b.eq	0x843c <generic_lsm_filter_arg+0x264c>
    7dc4:      	cmp	w8, #0x2
    7dc8:      	b.ne	0x8448 <generic_lsm_filter_arg+0x2658>
    7dcc:      	ldrb	w11, [x25]
    7dd0:      	cmp	w10, w11
    7dd4:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    7dd8:      	b	0x8448 <generic_lsm_filter_arg+0x2658>
    7ddc:      	cmp	w8, #0x1
    7de0:      	b.eq	0x8478 <generic_lsm_filter_arg+0x2688>
    7de4:      	cmp	w8, #0x2
    7de8:      	b.ne	0x8484 <generic_lsm_filter_arg+0x2694>
    7dec:      	ldrh	w11, [x25]
    7df0:      	cmp	w10, w11
    7df4:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    7df8:      	b	0x8484 <generic_lsm_filter_arg+0x2694>
    7dfc:      	cmp	w8, #0x401
    7e00:      	b.hs	0x822c <generic_lsm_filter_arg+0x243c>
    7e04:      	mov	w11, #0x400             // =1024
    7e08:      	b	0x8240 <generic_lsm_filter_arg+0x2450>
    7e0c:      	cmp	w13, w10
    7e10:      	ccmp	w10, w12, #0x2, ls
    7e14:      	cset	w12, ls
    7e18:      	orr	w8, w8, w12
    7e1c:      	cmp	w11, #0x19
    7e20:      	mov	w12, #0x1               // =1
    7e24:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    7e28:      	ldp	w13, w12, [x23, #0x20]
    7e2c:      	mov	w14, #0x1               // =1
    7e30:      	cmp	w9, #0xc
    7e34:      	b.hi	0x84d4 <generic_lsm_filter_arg+0x26e4>
    7e38:      	lsl	w14, w14, w9
    7e3c:      	mov	w1, #0x1402             // =5122
    7e40:      	tst	w14, w1
    7e44:      	b.eq	0x84d4 <generic_lsm_filter_arg+0x26e4>
    7e48:      	cmp	w13, w10
    7e4c:      	ccmp	w10, w12, #0x0, le
    7e50:      	cset	w12, le
    7e54:      	b	0x84e0 <generic_lsm_filter_arg+0x26f0>
    7e58:      	ldr	x19, [sp, #0x30]
    7e5c:      	mov	x22, xzr
    7e60:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7e64:      	mov	w11, #0xa               // =10
    7e68:      	b	0x7e78 <generic_lsm_filter_arg+0x2088>
    7e6c:      	mov	w11, #0x6               // =6
    7e70:      	b	0x7e78 <generic_lsm_filter_arg+0x2088>
    7e74:      	mov	w11, #0x8               // =8
    7e78:      	add	x8, x23, #0x10
    7e7c:      	and	w9, w11, #0xf
    7e80:      	ldr	w8, [x8, w9, uxtw #2]
    7e84:      	cmn	w8, #0x1
    7e88:      	b.eq	0x7f38 <generic_lsm_filter_arg+0x2148>
    7e8c:      	str	w8, [sp, #0x10]
    7e90:      	stp	w13, w11, [sp, #0x1c]
    7e94:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7e98:      	mov	w8, #0x1                // =1
    7e9c:      	add	x22, sp, #0x88
    7ea0:      	add	x1, sp, #0x88
    7ea4:      	str	x10, [sp, #0x28]
    7ea8:      	ldr	x0, [x0]
    7eac:      	blr	x8
    7eb0:      	mov	x25, x0
    7eb4:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7eb8:      	mov	w8, #0x1                // =1
    7ebc:      	ldr	x0, [x0]
    7ec0:      	add	x1, sp, #0x88
    7ec4:      	blr	x8
    7ec8:      	mov	x22, xzr
    7ecc:      	cbz	x25, 0x8bd4 <generic_lsm_filter_arg+0x2de4>
    7ed0:      	ldp	x16, x15, [sp, #0x40]
    7ed4:      	mov	w2, #0x5ea0             // =24224
    7ed8:      	mov	w12, #0x1               // =1
    7edc:      	ldr	x17, [sp, #0x38]
    7ee0:      	cbz	x0, 0x8be4 <generic_lsm_filter_arg+0x2df4>
    7ee4:      	mov	x8, x25
    7ee8:      	ldr	w25, [sp, #0x20]
    7eec:      	mov	x22, x0
    7ef0:      	mov	x0, x8
    7ef4:      	str	x8, [sp, #0x8]
    7ef8:      	cmp	w25, #0x5
    7efc:      	b.gt	0x7f4c <generic_lsm_filter_arg+0x215c>
    7f00:      	strb	w29, [x0], #0x1
    7f04:      	ldr	x2, [sp, #0x28]
    7f08:      	mov	w8, #0x4                // =4
    7f0c:      	mov	w1, w29
    7f10:      	blr	x8
    7f14:      	ldr	w8, [sp, #0x1c]
    7f18:      	subs	w8, w8, w29
    7f1c:      	b.ls	0x7f88 <generic_lsm_filter_arg+0x2198>
    7f20:      	ldr	x9, [sp, #0x8]
    7f24:      	and	w1, w8, #0xfff
    7f28:      	mov	w8, #0x4                // =4
    7f2c:      	add	x9, x9, x29
    7f30:      	add	x0, x9, #0x1
    7f34:      	b	0x7f80 <generic_lsm_filter_arg+0x2190>
    7f38:      	mov	x22, xzr
    7f3c:      	ldr	w8, [x23, #0x4]
    7f40:      	cmp	w8, #0x25
    7f44:      	b.ls	0x8bf0 <generic_lsm_filter_arg+0x2e00>
    7f48:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    7f4c:      	strh	w29, [x0], #0x2
    7f50:      	ldr	x2, [sp, #0x28]
    7f54:      	mov	w8, #0x4                // =4
    7f58:      	mov	w1, w29
    7f5c:      	blr	x8
    7f60:      	ldr	w8, [sp, #0x1c]
    7f64:      	subs	w8, w8, w29
    7f68:      	b.ls	0x7f88 <generic_lsm_filter_arg+0x2198>
    7f6c:      	ldr	x9, [sp, #0x8]
    7f70:      	and	w1, w8, #0xfff
    7f74:      	mov	w8, #0x4                // =4
    7f78:      	add	x9, x9, x29
    7f7c:      	add	x0, x9, #0x2
    7f80:      	mov	x2, x22
    7f84:      	blr	x8
    7f88:      	ldr	w8, [sp, #0x10]
    7f8c:      	cmp	w25, #0x4
    7f90:      	mov	w12, #0x1               // =1
    7f94:      	str	w8, [sp, #0x60]
    7f98:      	b.le	0x7fd0 <generic_lsm_filter_arg+0x21e0>
    7f9c:      	cmp	w25, #0x7
    7fa0:      	b.gt	0x8200 <generic_lsm_filter_arg+0x2410>
    7fa4:      	cmp	w25, #0x5
    7fa8:      	b.eq	0x8b88 <generic_lsm_filter_arg+0x2d98>
    7fac:      	cmp	w25, #0x6
    7fb0:      	b.eq	0x8b4c <generic_lsm_filter_arg+0x2d5c>
    7fb4:      	cmp	w25, #0x7
    7fb8:      	b.ne	0x8c10 <generic_lsm_filter_arg+0x2e20>
    7fbc:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7fc0:      	mov	w8, #0x1                // =1
    7fc4:      	add	x9, sp, #0x60
    7fc8:      	ldr	x0, [x0]
    7fcc:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    7fd0:      	cmp	w25, #0x1
    7fd4:      	b.le	0x8684 <generic_lsm_filter_arg+0x2894>
    7fd8:      	cmp	w25, #0x2
    7fdc:      	b.eq	0x8b74 <generic_lsm_filter_arg+0x2d84>
    7fe0:      	cmp	w25, #0x3
    7fe4:      	b.eq	0x8b38 <generic_lsm_filter_arg+0x2d48>
    7fe8:      	cmp	w25, #0x4
    7fec:      	b.ne	0x8c10 <generic_lsm_filter_arg+0x2e20>
    7ff0:      	adrp	x0, 0x7000 <generic_lsm_filter_arg+0x1210>
    7ff4:      	mov	w8, #0x1                // =1
    7ff8:      	add	x9, sp, #0x60
    7ffc:      	ldr	x0, [x0]
    8000:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8004:      	cmp	w12, w8
    8008:      	mov	w12, #0x1               // =1
    800c:      	b.hi	0x8018 <generic_lsm_filter_arg+0x2228>
    8010:      	cmp	w8, w11
    8014:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    8018:      	cmp	w10, #0x19
    801c:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    8020:      	ldp	w12, w11, [x23, #0x20]
    8024:      	mov	w13, #0x1               // =1
    8028:      	cmp	w9, #0xc
    802c:      	b.hi	0x8534 <generic_lsm_filter_arg+0x2744>
    8030:      	lsl	w13, w13, w9
    8034:      	mov	w14, #0x1402            // =5122
    8038:      	tst	w13, w14
    803c:      	b.eq	0x8534 <generic_lsm_filter_arg+0x2744>
    8040:      	cmp	w12, w8
    8044:      	mov	w12, #0x1               // =1
    8048:      	b.gt	0x8548 <generic_lsm_filter_arg+0x2758>
    804c:      	cmp	w8, w11
    8050:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    8054:      	b	0x8548 <generic_lsm_filter_arg+0x2758>
    8058:      	cmp	w8, #0x101
    805c:      	b.hs	0x8520 <generic_lsm_filter_arg+0x2730>
    8060:      	mov	w11, #0x100             // =256
    8064:      	b	0x8e60 <generic_lsm_filter_arg+0x3070>
    8068:      	cmp	x13, x10
    806c:      	ccmp	x10, x12, #0x2, ls
    8070:      	cset	w12, ls
    8074:      	orr	w8, w8, w12
    8078:      	cmp	w11, #0x39
    807c:      	b.lo	0x8678 <generic_lsm_filter_arg+0x2888>
    8080:      	ldp	x12, x11, [x23, #0x40]
    8084:      	cmp	w9, #0xc
    8088:      	b.eq	0x8094 <generic_lsm_filter_arg+0x22a4>
    808c:      	cmp	w9, #0xa
    8090:      	b.ne	0x8668 <generic_lsm_filter_arg+0x2878>
    8094:      	cmp	x12, x10
    8098:      	ccmp	x10, x11, #0x0, le
    809c:      	cset	w9, le
    80a0:      	b	0x8674 <generic_lsm_filter_arg+0x2884>
    80a4:      	cmp	x12, x8
    80a8:      	mov	w12, #0x1               // =1
    80ac:      	b.hi	0x80b8 <generic_lsm_filter_arg+0x22c8>
    80b0:      	cmp	x8, x11
    80b4:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    80b8:      	cmp	w10, #0x39
    80bc:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    80c0:      	ldp	x11, x10, [x23, #0x40]
    80c4:      	cmp	w9, #0xc
    80c8:      	b.eq	0x80d4 <generic_lsm_filter_arg+0x22e4>
    80cc:      	cmp	w9, #0xa
    80d0:      	b.ne	0x86a4 <generic_lsm_filter_arg+0x28b4>
    80d4:      	cmp	x11, x8
    80d8:      	b.gt	0x5eec <generic_lsm_filter_arg+0xfc>
    80dc:      	cmp	x8, x10
    80e0:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    80e4:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    80e8:      	ldr	x12, [x25]
    80ec:      	cmp	x12, x11
    80f0:      	mov	w12, #0x1               // =1
    80f4:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    80f8:      	b	0x810c <generic_lsm_filter_arg+0x231c>
    80fc:      	ldr	x12, [x25]
    8100:      	cmp	x12, x11
    8104:      	mov	w12, #0x1               // =1
    8108:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    810c:      	cmp	w10, #0x19
    8110:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8114:      	ldr	x11, [x23, #0x20]
    8118:      	cmp	w8, #0x2
    811c:      	b.le	0x8140 <generic_lsm_filter_arg+0x2350>
    8120:      	sub	w12, w8, #0x3
    8124:      	cmp	w12, #0x2
    8128:      	b.hs	0x8174 <generic_lsm_filter_arg+0x2384>
    812c:      	ldr	x12, [x25]
    8130:      	cmp	x12, x11
    8134:      	mov	w12, #0x1               // =1
    8138:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    813c:      	b	0x8978 <generic_lsm_filter_arg+0x2b88>
    8140:      	cmp	w8, #0x1
    8144:      	b.eq	0x81dc <generic_lsm_filter_arg+0x23ec>
    8148:      	cmp	w8, #0x2
    814c:      	b.ne	0x8978 <generic_lsm_filter_arg+0x2b88>
    8150:      	cmp	w9, #0xc
    8154:      	b.eq	0x8160 <generic_lsm_filter_arg+0x2370>
    8158:      	cmp	w9, #0xa
    815c:      	b.ne	0x8968 <generic_lsm_filter_arg+0x2b78>
    8160:      	ldr	x12, [x25]
    8164:      	cmp	x12, x11
    8168:      	mov	w12, #0x1               // =1
    816c:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    8170:      	b	0x8978 <generic_lsm_filter_arg+0x2b88>
    8174:      	cmp	w8, #0xc
    8178:      	mov	w12, #0x1               // =1
    817c:      	b.ne	0x8978 <generic_lsm_filter_arg+0x2b88>
    8180:      	ldr	x12, [x25]
    8184:      	tst	x12, x11
    8188:      	mov	w12, #0x1               // =1
    818c:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    8190:      	b	0x8978 <generic_lsm_filter_arg+0x2b88>
    8194:      	cmp	w8, #0xc
    8198:      	b.ne	0x8448 <generic_lsm_filter_arg+0x2658>
    819c:      	ldrb	w11, [x25]
    81a0:      	tst	w10, w11
    81a4:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    81a8:      	b	0x8448 <generic_lsm_filter_arg+0x2658>
    81ac:      	cmp	w8, #0xc
    81b0:      	b.ne	0x8484 <generic_lsm_filter_arg+0x2694>
    81b4:      	ldrh	w11, [x25]
    81b8:      	tst	w10, w11
    81bc:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    81c0:      	b	0x8484 <generic_lsm_filter_arg+0x2694>
    81c4:      	mov	w22, #0x1               // =1
    81c8:      	b	0x9170 <generic_lsm_filter_arg+0x3380>
    81cc:      	cmp	w8, #0x401
    81d0:      	b.hs	0x86f8 <generic_lsm_filter_arg+0x2908>
    81d4:      	mov	w11, #0x400             // =1024
    81d8:      	b	0x870c <generic_lsm_filter_arg+0x291c>
    81dc:      	cmp	w9, #0xc
    81e0:      	b.eq	0x81ec <generic_lsm_filter_arg+0x23fc>
    81e4:      	cmp	w9, #0xa
    81e8:      	b.ne	0x8954 <generic_lsm_filter_arg+0x2b64>
    81ec:      	ldr	x12, [x25]
    81f0:      	cmp	x12, x11
    81f4:      	mov	w12, #0x1               // =1
    81f8:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    81fc:      	b	0x8978 <generic_lsm_filter_arg+0x2b88>
    8200:      	cmp	w25, #0x8
    8204:      	b.eq	0x8b9c <generic_lsm_filter_arg+0x2dac>
    8208:      	cmp	w25, #0x9
    820c:      	b.eq	0x8b60 <generic_lsm_filter_arg+0x2d70>
    8210:      	cmp	w25, #0xa
    8214:      	b.ne	0x8c10 <generic_lsm_filter_arg+0x2e20>
    8218:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    821c:      	mov	w8, #0x1                // =1
    8220:      	add	x9, sp, #0x60
    8224:      	ldr	x0, [x0]
    8228:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    822c:      	and	w8, w29, #0xffff
    8230:      	mov	w9, #0x1000             // =4096
    8234:      	cmp	w8, #0x800
    8238:      	mov	w8, #0x800              // =2048
    823c:      	csel	w11, w9, w8, hi
    8240:      	sub	w8, w11, #0x100
    8244:      	ror	w8, w8, #0x8
    8248:      	cmp	w8, #0x2
    824c:      	b.gt	0x8264 <generic_lsm_filter_arg+0x2474>
    8250:      	cbz	w8, 0x8284 <generic_lsm_filter_arg+0x2494>
    8254:      	cmp	w8, #0x1
    8258:      	b.ne	0x827c <generic_lsm_filter_arg+0x248c>
    825c:      	mov	w10, #0x7               // =7
    8260:      	b	0x8290 <generic_lsm_filter_arg+0x24a0>
    8264:      	cmp	w8, #0x3
    8268:      	b.eq	0x828c <generic_lsm_filter_arg+0x249c>
    826c:      	cmp	w8, #0x7
    8270:      	b.ne	0x827c <generic_lsm_filter_arg+0x248c>
    8274:      	mov	w10, #0x9               // =9
    8278:      	b	0x8290 <generic_lsm_filter_arg+0x24a0>
    827c:      	mov	w10, #0xa               // =10
    8280:      	b	0x8290 <generic_lsm_filter_arg+0x24a0>
    8284:      	mov	w10, #0x6               // =6
    8288:      	b	0x8290 <generic_lsm_filter_arg+0x24a0>
    828c:      	mov	w10, #0x8               // =8
    8290:      	add	x8, x23, #0x10
    8294:      	and	w9, w10, #0xf
    8298:      	ldr	w8, [x8, w9, uxtw #2]
    829c:      	cmn	w8, #0x1
    82a0:      	b.eq	0x8bd0 <generic_lsm_filter_arg+0x2de0>
    82a4:      	str	w8, [sp, #0x10]
    82a8:      	str	w11, [sp, #0x1c]
    82ac:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    82b0:      	mov	w8, #0x1                // =1
    82b4:      	add	x22, sp, #0x88
    82b8:      	add	x1, sp, #0x88
    82bc:      	str	w10, [sp, #0x28]
    82c0:      	ldr	x0, [x0]
    82c4:      	blr	x8
    82c8:      	str	x0, [sp, #0x20]
    82cc:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    82d0:      	mov	w8, #0x1                // =1
    82d4:      	add	x1, sp, #0x88
    82d8:      	ldr	x0, [x0]
    82dc:      	blr	x8
    82e0:      	ldr	x9, [sp, #0x20]
    82e4:      	mov	x22, xzr
    82e8:      	cbz	x9, 0x8bd4 <generic_lsm_filter_arg+0x2de4>
    82ec:      	ldp	x16, x15, [sp, #0x40]
    82f0:      	mov	w2, #0x5ea0             // =24224
    82f4:      	mov	w12, #0x1               // =1
    82f8:      	ldr	x17, [sp, #0x38]
    82fc:      	cbz	x0, 0x8be4 <generic_lsm_filter_arg+0x2df4>
    8300:      	mov	x8, x9
    8304:      	ldr	w9, [sp, #0x28]
    8308:      	mov	x22, x0
    830c:      	add	x2, x25, #0x4
    8310:      	mov	x25, x8
    8314:      	mov	x0, x8
    8318:      	cmp	w9, #0x5
    831c:      	b.gt	0x8350 <generic_lsm_filter_arg+0x2560>
    8320:      	strb	w29, [x0], #0x1
    8324:      	mov	w8, #0x4                // =4
    8328:      	mov	w1, w29
    832c:      	blr	x8
    8330:      	ldr	w8, [sp, #0x1c]
    8334:      	subs	w8, w8, w29
    8338:      	b.ls	0x8384 <generic_lsm_filter_arg+0x2594>
    833c:      	add	x9, x25, x29
    8340:      	and	w1, w8, #0xfff
    8344:      	mov	w8, #0x4                // =4
    8348:      	add	x0, x9, #0x1
    834c:      	b	0x837c <generic_lsm_filter_arg+0x258c>
    8350:      	strh	w29, [x0], #0x2
    8354:      	mov	w8, #0x4                // =4
    8358:      	mov	w1, w29
    835c:      	blr	x8
    8360:      	ldr	w8, [sp, #0x1c]
    8364:      	subs	w8, w8, w29
    8368:      	b.ls	0x8384 <generic_lsm_filter_arg+0x2594>
    836c:      	add	x9, x25, x29
    8370:      	and	w1, w8, #0xfff
    8374:      	mov	w8, #0x4                // =4
    8378:      	add	x0, x9, #0x2
    837c:      	mov	x2, x22
    8380:      	blr	x8
    8384:      	ldr	w8, [sp, #0x10]
    8388:      	ldp	x16, x15, [sp, #0x40]
    838c:      	mov	w2, #0x5ea0             // =24224
    8390:      	mov	w12, #0x1               // =1
    8394:      	ldr	x17, [sp, #0x38]
    8398:      	str	w8, [sp, #0x60]
    839c:      	ldr	w8, [sp, #0x28]
    83a0:      	cmp	w8, #0x4
    83a4:      	b.le	0x83dc <generic_lsm_filter_arg+0x25ec>
    83a8:      	cmp	w8, #0x7
    83ac:      	b.gt	0x8410 <generic_lsm_filter_arg+0x2620>
    83b0:      	cmp	w8, #0x5
    83b4:      	b.eq	0x8a8c <generic_lsm_filter_arg+0x2c9c>
    83b8:      	cmp	w8, #0x6
    83bc:      	b.eq	0x8a50 <generic_lsm_filter_arg+0x2c60>
    83c0:      	cmp	w8, #0x7
    83c4:      	b.ne	0x65ac <generic_lsm_filter_arg+0x7bc>
    83c8:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    83cc:      	mov	w8, #0x1                // =1
    83d0:      	add	x9, sp, #0x60
    83d4:      	ldr	x0, [x0]
    83d8:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    83dc:      	cmp	w8, #0x1
    83e0:      	b.le	0x84b4 <generic_lsm_filter_arg+0x26c4>
    83e4:      	cmp	w8, #0x2
    83e8:      	b.eq	0x8a78 <generic_lsm_filter_arg+0x2c88>
    83ec:      	cmp	w8, #0x3
    83f0:      	b.eq	0x8a3c <generic_lsm_filter_arg+0x2c4c>
    83f4:      	cmp	w8, #0x4
    83f8:      	b.ne	0x65ac <generic_lsm_filter_arg+0x7bc>
    83fc:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8400:      	mov	w8, #0x1                // =1
    8404:      	add	x9, sp, #0x60
    8408:      	ldr	x0, [x0]
    840c:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8410:      	cmp	w8, #0x8
    8414:      	b.eq	0x8aa0 <generic_lsm_filter_arg+0x2cb0>
    8418:      	cmp	w8, #0x9
    841c:      	b.eq	0x8a64 <generic_lsm_filter_arg+0x2c74>
    8420:      	cmp	w8, #0xa
    8424:      	b.ne	0x65ac <generic_lsm_filter_arg+0x7bc>
    8428:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    842c:      	mov	w8, #0x1                // =1
    8430:      	add	x9, sp, #0x60
    8434:      	ldr	x0, [x0]
    8438:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    843c:      	ldrb	w11, [x25]
    8440:      	cmp	w10, w11
    8444:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    8448:      	cmp	w9, #0x11
    844c:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8450:      	ldr	w10, [x23, #0x18]
    8454:      	cmp	w8, #0x2
    8458:      	b.le	0x86b8 <generic_lsm_filter_arg+0x28c8>
    845c:      	sub	w11, w8, #0x3
    8460:      	cmp	w11, #0x2
    8464:      	b.hs	0x89f8 <generic_lsm_filter_arg+0x2c08>
    8468:      	ldrb	w11, [x25]
    846c:      	cmp	w10, w11
    8470:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    8474:      	b	0x8d04 <generic_lsm_filter_arg+0x2f14>
    8478:      	ldrh	w11, [x25]
    847c:      	cmp	w10, w11
    8480:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    8484:      	cmp	w9, #0x11
    8488:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    848c:      	ldr	w10, [x23, #0x18]
    8490:      	cmp	w8, #0x2
    8494:      	b.le	0x86d8 <generic_lsm_filter_arg+0x28e8>
    8498:      	sub	w11, w8, #0x3
    849c:      	cmp	w11, #0x2
    84a0:      	b.hs	0x8a10 <generic_lsm_filter_arg+0x2c20>
    84a4:      	ldrh	w11, [x25]
    84a8:      	cmp	w10, w11
    84ac:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    84b0:      	b	0x8d48 <generic_lsm_filter_arg+0x2f58>
    84b4:      	cbz	w8, 0x8a28 <generic_lsm_filter_arg+0x2c38>
    84b8:      	cmp	w8, #0x1
    84bc:      	b.ne	0x65ac <generic_lsm_filter_arg+0x7bc>
    84c0:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    84c4:      	mov	w8, #0x1                // =1
    84c8:      	add	x9, sp, #0x60
    84cc:      	ldr	x0, [x0]
    84d0:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    84d4:      	cmp	w13, w10
    84d8:      	ccmp	w10, w12, #0x2, ls
    84dc:      	cset	w12, ls
    84e0:      	orr	w8, w8, w12
    84e4:      	cmp	w11, #0x21
    84e8:      	mov	w12, #0x1               // =1
    84ec:      	b.lo	0x894c <generic_lsm_filter_arg+0x2b5c>
    84f0:      	ldp	w12, w11, [x23, #0x28]
    84f4:      	mov	w13, #0x1               // =1
    84f8:      	cmp	w9, #0xc
    84fc:      	b.hi	0x8938 <generic_lsm_filter_arg+0x2b48>
    8500:      	lsl	w9, w13, w9
    8504:      	mov	w13, #0x1402            // =5122
    8508:      	tst	w9, w13
    850c:      	b.eq	0x8938 <generic_lsm_filter_arg+0x2b48>
    8510:      	cmp	w12, w10
    8514:      	ccmp	w10, w11, #0x0, le
    8518:      	cset	w9, le
    851c:      	b	0x8944 <generic_lsm_filter_arg+0x2b54>
    8520:      	and	w8, w25, #0xffff
    8524:      	cmp	w8, #0x201
    8528:      	b.hs	0x8ad4 <generic_lsm_filter_arg+0x2ce4>
    852c:      	mov	w11, #0x200             // =512
    8530:      	b	0x8e60 <generic_lsm_filter_arg+0x3070>
    8534:      	cmp	w12, w8
    8538:      	mov	w12, #0x1               // =1
    853c:      	b.hi	0x8548 <generic_lsm_filter_arg+0x2758>
    8540:      	cmp	w8, w11
    8544:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    8548:      	cmp	w10, #0x21
    854c:      	b.lo	0x5eec <generic_lsm_filter_arg+0xfc>
    8550:      	ldp	w11, w10, [x23, #0x28]
    8554:      	cmp	w9, #0xc
    8558:      	b.hi	0x8ae4 <generic_lsm_filter_arg+0x2cf4>
    855c:      	lsl	w9, w12, w9
    8560:      	mov	w13, #0x1402            // =5122
    8564:      	tst	w9, w13
    8568:      	b.eq	0x8ae4 <generic_lsm_filter_arg+0x2cf4>
    856c:      	cmp	w11, w8
    8570:      	b.gt	0x5eec <generic_lsm_filter_arg+0xfc>
    8574:      	cmp	w8, w10
    8578:      	b.le	0x6088 <generic_lsm_filter_arg+0x298>
    857c:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    8580:      	ldr	w12, [x25]
    8584:      	cmp	w12, w11
    8588:      	mov	w12, #0x1               // =1
    858c:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    8590:      	b	0x85a4 <generic_lsm_filter_arg+0x27b4>
    8594:      	ldr	w12, [x25]
    8598:      	cmp	w12, w11
    859c:      	mov	w12, #0x1               // =1
    85a0:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    85a4:      	cmp	w10, #0x11
    85a8:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    85ac:      	ldr	w11, [x23, #0x18]
    85b0:      	cmp	w8, #0x2
    85b4:      	b.le	0x85d8 <generic_lsm_filter_arg+0x27e8>
    85b8:      	sub	w12, w8, #0x3
    85bc:      	cmp	w12, #0x2
    85c0:      	b.hs	0x8618 <generic_lsm_filter_arg+0x2828>
    85c4:      	ldr	w12, [x25]
    85c8:      	cmp	w12, w11
    85cc:      	mov	w12, #0x1               // =1
    85d0:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    85d4:      	b	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    85d8:      	cmp	w8, #0x1
    85dc:      	b.eq	0x8638 <generic_lsm_filter_arg+0x2848>
    85e0:      	cmp	w8, #0x2
    85e4:      	b.ne	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    85e8:      	mov	w12, #0x1               // =1
    85ec:      	cmp	w9, #0xc
    85f0:      	b.hi	0x8d94 <generic_lsm_filter_arg+0x2fa4>
    85f4:      	lsl	w12, w12, w9
    85f8:      	mov	w13, #0x1402            // =5122
    85fc:      	tst	w12, w13
    8600:      	b.eq	0x8d94 <generic_lsm_filter_arg+0x2fa4>
    8604:      	ldr	w12, [x25]
    8608:      	cmp	w12, w11
    860c:      	mov	w12, #0x1               // =1
    8610:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    8614:      	b	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    8618:      	cmp	w8, #0xc
    861c:      	mov	w12, #0x1               // =1
    8620:      	b.ne	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    8624:      	ldr	w12, [x25]
    8628:      	tst	w12, w11
    862c:      	mov	w12, #0x1               // =1
    8630:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    8634:      	b	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    8638:      	mov	w12, #0x1               // =1
    863c:      	cmp	w9, #0xc
    8640:      	b.hi	0x8d80 <generic_lsm_filter_arg+0x2f90>
    8644:      	lsl	w12, w12, w9
    8648:      	mov	w13, #0x1402            // =5122
    864c:      	tst	w12, w13
    8650:      	b.eq	0x8d80 <generic_lsm_filter_arg+0x2f90>
    8654:      	ldr	w12, [x25]
    8658:      	cmp	w12, w11
    865c:      	mov	w12, #0x1               // =1
    8660:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    8664:      	b	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    8668:      	cmp	x12, x10
    866c:      	ccmp	x10, x11, #0x2, ls
    8670:      	cset	w9, ls
    8674:      	orr	w8, w8, w9
    8678:      	mov	w12, #0x1               // =1
    867c:      	tbz	w8, #0x0, 0x6088 <generic_lsm_filter_arg+0x298>
    8680:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    8684:      	cbz	w25, 0x8b24 <generic_lsm_filter_arg+0x2d34>
    8688:      	cmp	w25, #0x1
    868c:      	b.ne	0x8c10 <generic_lsm_filter_arg+0x2e20>
    8690:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8694:      	mov	w8, #0x1                // =1
    8698:      	add	x9, sp, #0x60
    869c:      	ldr	x0, [x0]
    86a0:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    86a4:      	cmp	x11, x8
    86a8:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    86ac:      	cmp	x8, x10
    86b0:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    86b4:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    86b8:      	cmp	w8, #0x1
    86bc:      	b.eq	0x8cf8 <generic_lsm_filter_arg+0x2f08>
    86c0:      	cmp	w8, #0x2
    86c4:      	b.ne	0x8d04 <generic_lsm_filter_arg+0x2f14>
    86c8:      	ldrb	w11, [x25]
    86cc:      	cmp	w10, w11
    86d0:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    86d4:      	b	0x8d04 <generic_lsm_filter_arg+0x2f14>
    86d8:      	cmp	w8, #0x1
    86dc:      	b.eq	0x8d3c <generic_lsm_filter_arg+0x2f4c>
    86e0:      	cmp	w8, #0x2
    86e4:      	b.ne	0x8d48 <generic_lsm_filter_arg+0x2f58>
    86e8:      	ldrh	w11, [x25]
    86ec:      	cmp	w10, w11
    86f0:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    86f4:      	b	0x8d48 <generic_lsm_filter_arg+0x2f58>
    86f8:      	and	w8, w29, #0xffff
    86fc:      	mov	w9, #0x1000             // =4096
    8700:      	cmp	w8, #0x800
    8704:      	mov	w8, #0x800              // =2048
    8708:      	csel	w11, w9, w8, hi
    870c:      	sub	w8, w11, #0x100
    8710:      	ror	w8, w8, #0x8
    8714:      	cmp	w8, #0x2
    8718:      	b.gt	0x8730 <generic_lsm_filter_arg+0x2940>
    871c:      	cbz	w8, 0x8750 <generic_lsm_filter_arg+0x2960>
    8720:      	cmp	w8, #0x1
    8724:      	b.ne	0x8748 <generic_lsm_filter_arg+0x2958>
    8728:      	mov	w10, #0x7               // =7
    872c:      	b	0x875c <generic_lsm_filter_arg+0x296c>
    8730:      	cmp	w8, #0x3
    8734:      	b.eq	0x8758 <generic_lsm_filter_arg+0x2968>
    8738:      	cmp	w8, #0x7
    873c:      	b.ne	0x8748 <generic_lsm_filter_arg+0x2958>
    8740:      	mov	w10, #0x9               // =9
    8744:      	b	0x875c <generic_lsm_filter_arg+0x296c>
    8748:      	mov	w10, #0xa               // =10
    874c:      	b	0x875c <generic_lsm_filter_arg+0x296c>
    8750:      	mov	w10, #0x6               // =6
    8754:      	b	0x875c <generic_lsm_filter_arg+0x296c>
    8758:      	mov	w10, #0x8               // =8
    875c:      	add	x8, x23, #0x10
    8760:      	and	w9, w10, #0xf
    8764:      	ldr	w8, [x8, w9, uxtw #2]
    8768:      	cmn	w8, #0x1
    876c:      	b.eq	0x8820 <generic_lsm_filter_arg+0x2a30>
    8770:      	str	w8, [sp, #0x1c]
    8774:      	str	w11, [sp, #0x10]
    8778:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    877c:      	mov	w8, #0x1                // =1
    8780:      	add	x22, sp, #0x88
    8784:      	add	x1, sp, #0x88
    8788:      	str	w10, [sp, #0x28]
    878c:      	ldr	x0, [x0]
    8790:      	blr	x8
    8794:      	str	x0, [sp, #0x20]
    8798:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    879c:      	mov	w8, #0x1                // =1
    87a0:      	add	x1, sp, #0x88
    87a4:      	ldr	x0, [x0]
    87a8:      	blr	x8
    87ac:      	ldr	x9, [sp, #0x20]
    87b0:      	mov	x22, xzr
    87b4:      	cbz	x9, 0x70a0 <generic_lsm_filter_arg+0x12b0>
    87b8:      	ldp	x16, x15, [sp, #0x40]
    87bc:      	mov	w2, #0x5ea0             // =24224
    87c0:      	mov	w12, #0x1               // =1
    87c4:      	ldr	x17, [sp, #0x38]
    87c8:      	cbz	x0, 0x70b0 <generic_lsm_filter_arg+0x12c0>
    87cc:      	mov	x8, x9
    87d0:      	ldr	w9, [sp, #0x28]
    87d4:      	mov	x22, x0
    87d8:      	cmp	w9, #0x5
    87dc:      	b.gt	0x8828 <generic_lsm_filter_arg+0x2a38>
    87e0:      	mov	x0, x8
    87e4:      	mov	x9, x8
    87e8:      	mov	w8, #0x4                // =4
    87ec:      	mov	w1, w29
    87f0:      	mov	x2, x25
    87f4:      	strb	w29, [x0], #0x1
    87f8:      	mov	x25, x9
    87fc:      	blr	x8
    8800:      	ldr	w8, [sp, #0x10]
    8804:      	subs	w8, w8, w29
    8808:      	b.ls	0x886c <generic_lsm_filter_arg+0x2a7c>
    880c:      	add	x9, x25, x29
    8810:      	and	w1, w8, #0xfff
    8814:      	mov	w8, #0x4                // =4
    8818:      	add	x0, x9, #0x1
    881c:      	b	0x8864 <generic_lsm_filter_arg+0x2a74>
    8820:      	mov	x22, xzr
    8824:      	b	0x70ac <generic_lsm_filter_arg+0x12bc>
    8828:      	mov	x0, x8
    882c:      	mov	x9, x8
    8830:      	mov	w8, #0x4                // =4
    8834:      	mov	w1, w29
    8838:      	mov	x2, x25
    883c:      	strh	w29, [x0], #0x2
    8840:      	mov	x25, x9
    8844:      	blr	x8
    8848:      	ldr	w8, [sp, #0x10]
    884c:      	subs	w8, w8, w29
    8850:      	b.ls	0x886c <generic_lsm_filter_arg+0x2a7c>
    8854:      	add	x9, x25, x29
    8858:      	and	w1, w8, #0xfff
    885c:      	mov	w8, #0x4                // =4
    8860:      	add	x0, x9, #0x2
    8864:      	mov	x2, x22
    8868:      	blr	x8
    886c:      	ldr	w8, [sp, #0x1c]
    8870:      	mov	w12, #0x1               // =1
    8874:      	str	w8, [sp, #0x60]
    8878:      	ldr	w8, [sp, #0x28]
    887c:      	cmp	w8, #0x4
    8880:      	b.le	0x88b8 <generic_lsm_filter_arg+0x2ac8>
    8884:      	cmp	w8, #0x7
    8888:      	b.gt	0x88ec <generic_lsm_filter_arg+0x2afc>
    888c:      	cmp	w8, #0x5
    8890:      	b.eq	0x8c94 <generic_lsm_filter_arg+0x2ea4>
    8894:      	cmp	w8, #0x6
    8898:      	b.eq	0x8c58 <generic_lsm_filter_arg+0x2e68>
    889c:      	cmp	w8, #0x7
    88a0:      	b.ne	0x8ce4 <generic_lsm_filter_arg+0x2ef4>
    88a4:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    88a8:      	mov	w8, #0x1                // =1
    88ac:      	add	x9, sp, #0x60
    88b0:      	ldr	x0, [x0]
    88b4:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    88b8:      	cmp	w8, #0x1
    88bc:      	b.le	0x8918 <generic_lsm_filter_arg+0x2b28>
    88c0:      	cmp	w8, #0x2
    88c4:      	b.eq	0x8c80 <generic_lsm_filter_arg+0x2e90>
    88c8:      	cmp	w8, #0x3
    88cc:      	b.eq	0x8c44 <generic_lsm_filter_arg+0x2e54>
    88d0:      	cmp	w8, #0x4
    88d4:      	b.ne	0x8ce4 <generic_lsm_filter_arg+0x2ef4>
    88d8:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    88dc:      	mov	w8, #0x1                // =1
    88e0:      	add	x9, sp, #0x60
    88e4:      	ldr	x0, [x0]
    88e8:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    88ec:      	cmp	w8, #0x8
    88f0:      	b.eq	0x8ca8 <generic_lsm_filter_arg+0x2eb8>
    88f4:      	cmp	w8, #0x9
    88f8:      	b.eq	0x8c6c <generic_lsm_filter_arg+0x2e7c>
    88fc:      	cmp	w8, #0xa
    8900:      	b.ne	0x8ce4 <generic_lsm_filter_arg+0x2ef4>
    8904:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8908:      	mov	w8, #0x1                // =1
    890c:      	add	x9, sp, #0x60
    8910:      	ldr	x0, [x0]
    8914:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8918:      	cbz	w8, 0x8c30 <generic_lsm_filter_arg+0x2e40>
    891c:      	cmp	w8, #0x1
    8920:      	b.ne	0x8ce4 <generic_lsm_filter_arg+0x2ef4>
    8924:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8928:      	mov	w8, #0x1                // =1
    892c:      	add	x9, sp, #0x60
    8930:      	ldr	x0, [x0]
    8934:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8938:      	cmp	w12, w10
    893c:      	ccmp	w10, w11, #0x2, ls
    8940:      	cset	w9, ls
    8944:      	orr	w8, w8, w9
    8948:      	mov	w12, #0x1               // =1
    894c:      	tbz	w8, #0x0, 0x6088 <generic_lsm_filter_arg+0x298>
    8950:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    8954:      	ldr	x12, [x25]
    8958:      	cmp	x12, x11
    895c:      	mov	w12, #0x1               // =1
    8960:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    8964:      	b	0x8978 <generic_lsm_filter_arg+0x2b88>
    8968:      	ldr	x12, [x25]
    896c:      	cmp	x12, x11
    8970:      	mov	w12, #0x1               // =1
    8974:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    8978:      	cmp	w10, #0x21
    897c:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8980:      	ldr	x10, [x23, #0x28]
    8984:      	cmp	w8, #0x2
    8988:      	b.le	0x89b8 <generic_lsm_filter_arg+0x2bc8>
    898c:      	sub	w9, w8, #0x3
    8990:      	cmp	w9, #0x2
    8994:      	b.lo	0x89e8 <generic_lsm_filter_arg+0x2bf8>
    8998:      	cmp	w8, #0x6
    899c:      	b.eq	0x6088 <generic_lsm_filter_arg+0x298>
    89a0:      	cmp	w8, #0xc
    89a4:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    89a8:      	ldr	x9, [x25]
    89ac:      	tst	x9, x10
    89b0:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    89b4:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    89b8:      	cmp	w8, #0x1
    89bc:      	b.eq	0x8af8 <generic_lsm_filter_arg+0x2d08>
    89c0:      	cmp	w8, #0x2
    89c4:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    89c8:      	cmp	w9, #0xc
    89cc:      	b.eq	0x89d8 <generic_lsm_filter_arg+0x2be8>
    89d0:      	cmp	w9, #0xa
    89d4:      	b.ne	0x90a0 <generic_lsm_filter_arg+0x32b0>
    89d8:      	ldr	x9, [x25]
    89dc:      	cmp	x9, x10
    89e0:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    89e4:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    89e8:      	ldr	x9, [x25]
    89ec:      	cmp	x9, x10
    89f0:      	b.ne	0x91e4 <generic_lsm_filter_arg+0x33f4>
    89f4:      	b	0x607c <generic_lsm_filter_arg+0x28c>
    89f8:      	cmp	w8, #0xc
    89fc:      	b.ne	0x8d04 <generic_lsm_filter_arg+0x2f14>
    8a00:      	ldrb	w11, [x25]
    8a04:      	tst	w10, w11
    8a08:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    8a0c:      	b	0x8d04 <generic_lsm_filter_arg+0x2f14>
    8a10:      	cmp	w8, #0xc
    8a14:      	b.ne	0x8d48 <generic_lsm_filter_arg+0x2f58>
    8a18:      	ldrh	w11, [x25]
    8a1c:      	tst	w10, w11
    8a20:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    8a24:      	b	0x8d48 <generic_lsm_filter_arg+0x2f58>
    8a28:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8a2c:      	mov	w8, #0x1                // =1
    8a30:      	add	x9, sp, #0x60
    8a34:      	ldr	x0, [x0]
    8a38:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8a3c:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8a40:      	mov	w8, #0x1                // =1
    8a44:      	add	x9, sp, #0x60
    8a48:      	ldr	x0, [x0]
    8a4c:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8a50:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8a54:      	mov	w8, #0x1                // =1
    8a58:      	add	x9, sp, #0x60
    8a5c:      	ldr	x0, [x0]
    8a60:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8a64:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8a68:      	mov	w8, #0x1                // =1
    8a6c:      	add	x9, sp, #0x60
    8a70:      	ldr	x0, [x0]
    8a74:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8a78:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8a7c:      	mov	w8, #0x1                // =1
    8a80:      	add	x9, sp, #0x60
    8a84:      	ldr	x0, [x0]
    8a88:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8a8c:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8a90:      	mov	w8, #0x1                // =1
    8a94:      	add	x9, sp, #0x60
    8a98:      	ldr	x0, [x0]
    8a9c:      	b	0x8ab0 <generic_lsm_filter_arg+0x2cc0>
    8aa0:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8aa4:      	mov	w8, #0x1                // =1
    8aa8:      	add	x9, sp, #0x60
    8aac:      	ldr	x0, [x0]
    8ab0:      	add	x1, sp, #0x60
    8ab4:      	blr	x8
    8ab8:      	cbz	x0, 0x8bd0 <generic_lsm_filter_arg+0x2de0>
    8abc:      	mov	w8, #0x1                // =1
    8ac0:      	mov	x1, x25
    8ac4:      	blr	x8
    8ac8:      	cmp	x0, #0x0
    8acc:      	cset	w22, ne
    8ad0:      	b	0x8bd4 <generic_lsm_filter_arg+0x2de4>
    8ad4:      	cmp	w8, #0x401
    8ad8:      	b.hs	0x8e4c <generic_lsm_filter_arg+0x305c>
    8adc:      	mov	w11, #0x400             // =1024
    8ae0:      	b	0x8e60 <generic_lsm_filter_arg+0x3070>
    8ae4:      	cmp	w11, w8
    8ae8:      	b.hi	0x5eec <generic_lsm_filter_arg+0xfc>
    8aec:      	cmp	w8, w10
    8af0:      	b.ls	0x6088 <generic_lsm_filter_arg+0x298>
    8af4:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    8af8:      	cmp	w9, #0xc
    8afc:      	b.eq	0x8b08 <generic_lsm_filter_arg+0x2d18>
    8b00:      	cmp	w9, #0xa
    8b04:      	b.ne	0x90b0 <generic_lsm_filter_arg+0x32c0>
    8b08:      	ldr	x9, [x25]
    8b0c:      	cmp	x9, x10
    8b10:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    8b14:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8b18:      	ldr	x19, [sp, #0x30]
    8b1c:      	mov	w12, #0x1               // =1
    8b20:      	b	0x7be4 <generic_lsm_filter_arg+0x1df4>
    8b24:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8b28:      	mov	w8, #0x1                // =1
    8b2c:      	add	x9, sp, #0x60
    8b30:      	ldr	x0, [x0]
    8b34:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8b38:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8b3c:      	mov	w8, #0x1                // =1
    8b40:      	add	x9, sp, #0x60
    8b44:      	ldr	x0, [x0]
    8b48:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8b4c:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8b50:      	mov	w8, #0x1                // =1
    8b54:      	add	x9, sp, #0x60
    8b58:      	ldr	x0, [x0]
    8b5c:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8b60:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8b64:      	mov	w8, #0x1                // =1
    8b68:      	add	x9, sp, #0x60
    8b6c:      	ldr	x0, [x0]
    8b70:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8b74:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8b78:      	mov	w8, #0x1                // =1
    8b7c:      	add	x9, sp, #0x60
    8b80:      	ldr	x0, [x0]
    8b84:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8b88:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8b8c:      	mov	w8, #0x1                // =1
    8b90:      	add	x9, sp, #0x60
    8b94:      	ldr	x0, [x0]
    8b98:      	b	0x8bac <generic_lsm_filter_arg+0x2dbc>
    8b9c:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8ba0:      	mov	w8, #0x1                // =1
    8ba4:      	add	x9, sp, #0x60
    8ba8:      	ldr	x0, [x0]
    8bac:      	add	x1, sp, #0x60
    8bb0:      	blr	x8
    8bb4:      	cbz	x0, 0x8bd0 <generic_lsm_filter_arg+0x2de0>
    8bb8:      	ldr	x1, [sp, #0x8]
    8bbc:      	mov	w8, #0x1                // =1
    8bc0:      	blr	x8
    8bc4:      	cmp	x0, #0x0
    8bc8:      	cset	w22, ne
    8bcc:      	b	0x8bd4 <generic_lsm_filter_arg+0x2de4>
    8bd0:      	mov	x22, xzr
    8bd4:      	ldp	x16, x15, [sp, #0x40]
    8bd8:      	mov	w2, #0x5ea0             // =24224
    8bdc:      	mov	w12, #0x1               // =1
    8be0:      	ldr	x17, [sp, #0x38]
    8be4:      	ldr	w8, [x23, #0x4]
    8be8:      	cmp	w8, #0x25
    8bec:      	b.hi	0x6084 <generic_lsm_filter_arg+0x294>
    8bf0:      	mov	x9, #0x50               // =80
    8bf4:      	lsl	x8, x12, x8
    8bf8:      	movk	x9, #0xc00, lsl #16
    8bfc:      	movk	x9, #0x20, lsl #32
    8c00:      	tst	x8, x9
    8c04:      	b.eq	0x6084 <generic_lsm_filter_arg+0x294>
    8c08:      	eor	x22, x22, #0x1
    8c0c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    8c10:      	ldp	x16, x15, [sp, #0x40]
    8c14:      	mov	x22, xzr
    8c18:      	mov	w2, #0x5ea0             // =24224
    8c1c:      	ldr	x17, [sp, #0x38]
    8c20:      	ldr	w8, [x23, #0x4]
    8c24:      	cmp	w8, #0x25
    8c28:      	b.ls	0x8bf0 <generic_lsm_filter_arg+0x2e00>
    8c2c:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    8c30:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8c34:      	mov	w8, #0x1                // =1
    8c38:      	add	x9, sp, #0x60
    8c3c:      	ldr	x0, [x0]
    8c40:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8c44:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8c48:      	mov	w8, #0x1                // =1
    8c4c:      	add	x9, sp, #0x60
    8c50:      	ldr	x0, [x0]
    8c54:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8c58:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8c5c:      	mov	w8, #0x1                // =1
    8c60:      	add	x9, sp, #0x60
    8c64:      	ldr	x0, [x0]
    8c68:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8c6c:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8c70:      	mov	w8, #0x1                // =1
    8c74:      	add	x9, sp, #0x60
    8c78:      	ldr	x0, [x0]
    8c7c:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8c80:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8c84:      	mov	w8, #0x1                // =1
    8c88:      	add	x9, sp, #0x60
    8c8c:      	ldr	x0, [x0]
    8c90:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8c94:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8c98:      	mov	w8, #0x1                // =1
    8c9c:      	add	x9, sp, #0x60
    8ca0:      	ldr	x0, [x0]
    8ca4:      	b	0x8cb8 <generic_lsm_filter_arg+0x2ec8>
    8ca8:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8cac:      	mov	w8, #0x1                // =1
    8cb0:      	add	x9, sp, #0x60
    8cb4:      	ldr	x0, [x0]
    8cb8:      	add	x1, sp, #0x60
    8cbc:      	blr	x8
    8cc0:      	cbz	x0, 0x8cdc <generic_lsm_filter_arg+0x2eec>
    8cc4:      	mov	w8, #0x1                // =1
    8cc8:      	mov	x1, x25
    8ccc:      	blr	x8
    8cd0:      	cmp	x0, #0x0
    8cd4:      	cset	w22, ne
    8cd8:      	b	0x70a0 <generic_lsm_filter_arg+0x12b0>
    8cdc:      	mov	x22, xzr
    8ce0:      	b	0x70a0 <generic_lsm_filter_arg+0x12b0>
    8ce4:      	ldp	x16, x15, [sp, #0x40]
    8ce8:      	mov	x22, xzr
    8cec:      	mov	w2, #0x5ea0             // =24224
    8cf0:      	ldr	x17, [sp, #0x38]
    8cf4:      	b	0x70b0 <generic_lsm_filter_arg+0x12c0>
    8cf8:      	ldrb	w11, [x25]
    8cfc:      	cmp	w10, w11
    8d00:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    8d04:      	cmp	w9, #0x15
    8d08:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8d0c:      	ldr	w9, [x23, #0x1c]
    8d10:      	cmp	w8, #0x2
    8d14:      	b.le	0x9058 <generic_lsm_filter_arg+0x3268>
    8d18:      	sub	w10, w8, #0x3
    8d1c:      	cmp	w10, #0x2
    8d20:      	b.lo	0x9088 <generic_lsm_filter_arg+0x3298>
    8d24:      	cmp	w8, #0x6
    8d28:      	b.eq	0x6088 <generic_lsm_filter_arg+0x298>
    8d2c:      	cmp	w8, #0xc
    8d30:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    8d34:      	ldrb	w10, [x25]
    8d38:      	b	0x8dd8 <generic_lsm_filter_arg+0x2fe8>
    8d3c:      	ldrh	w11, [x25]
    8d40:      	cmp	w10, w11
    8d44:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    8d48:      	cmp	w9, #0x15
    8d4c:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8d50:      	ldr	w9, [x23, #0x1c]
    8d54:      	cmp	w8, #0x2
    8d58:      	b.le	0x9070 <generic_lsm_filter_arg+0x3280>
    8d5c:      	sub	w10, w8, #0x3
    8d60:      	cmp	w10, #0x2
    8d64:      	b.lo	0x9090 <generic_lsm_filter_arg+0x32a0>
    8d68:      	cmp	w8, #0x6
    8d6c:      	b.eq	0x6088 <generic_lsm_filter_arg+0x298>
    8d70:      	cmp	w8, #0xc
    8d74:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    8d78:      	ldrh	w10, [x25]
    8d7c:      	b	0x8dd8 <generic_lsm_filter_arg+0x2fe8>
    8d80:      	ldr	w12, [x25]
    8d84:      	cmp	w12, w11
    8d88:      	mov	w12, #0x1               // =1
    8d8c:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    8d90:      	b	0x8da4 <generic_lsm_filter_arg+0x2fb4>
    8d94:      	ldr	w12, [x25]
    8d98:      	cmp	w12, w11
    8d9c:      	mov	w12, #0x1               // =1
    8da0:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    8da4:      	cmp	w10, #0x15
    8da8:      	b.lo	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8dac:      	ldr	w10, [x23, #0x1c]
    8db0:      	cmp	w8, #0x2
    8db4:      	b.le	0x8de4 <generic_lsm_filter_arg+0x2ff4>
    8db8:      	sub	w9, w8, #0x3
    8dbc:      	cmp	w9, #0x2
    8dc0:      	b.lo	0x8e1c <generic_lsm_filter_arg+0x302c>
    8dc4:      	cmp	w8, #0x6
    8dc8:      	b.eq	0x6088 <generic_lsm_filter_arg+0x298>
    8dcc:      	cmp	w8, #0xc
    8dd0:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    8dd4:      	ldr	w9, [x25]
    8dd8:      	tst	w9, w10
    8ddc:      	b.ne	0x6088 <generic_lsm_filter_arg+0x298>
    8de0:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8de4:      	cmp	w8, #0x1
    8de8:      	b.eq	0x8e24 <generic_lsm_filter_arg+0x3034>
    8dec:      	cmp	w8, #0x2
    8df0:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    8df4:      	cmp	w9, #0xc
    8df8:      	b.hi	0x91c8 <generic_lsm_filter_arg+0x33d8>
    8dfc:      	lsl	w9, w12, w9
    8e00:      	mov	w11, #0x1402            // =5122
    8e04:      	tst	w9, w11
    8e08:      	b.eq	0x91c8 <generic_lsm_filter_arg+0x33d8>
    8e0c:      	ldr	w9, [x25]
    8e10:      	cmp	w9, w10
    8e14:      	b.lt	0x6088 <generic_lsm_filter_arg+0x298>
    8e18:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8e1c:      	ldr	w9, [x25]
    8e20:      	b	0x9094 <generic_lsm_filter_arg+0x32a4>
    8e24:      	cmp	w9, #0xc
    8e28:      	b.hi	0x91d8 <generic_lsm_filter_arg+0x33e8>
    8e2c:      	lsl	w9, w12, w9
    8e30:      	mov	w11, #0x1402            // =5122
    8e34:      	tst	w9, w11
    8e38:      	b.eq	0x91d8 <generic_lsm_filter_arg+0x33e8>
    8e3c:      	ldr	w9, [x25]
    8e40:      	cmp	w9, w10
    8e44:      	b.gt	0x6088 <generic_lsm_filter_arg+0x298>
    8e48:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    8e4c:      	and	w8, w25, #0xffff
    8e50:      	mov	w9, #0x1000             // =4096
    8e54:      	cmp	w8, #0x800
    8e58:      	mov	w8, #0x800              // =2048
    8e5c:      	csel	w11, w9, w8, hi
    8e60:      	sub	w8, w11, #0x100
    8e64:      	ror	w8, w8, #0x8
    8e68:      	cmp	w8, #0x2
    8e6c:      	b.gt	0x8e84 <generic_lsm_filter_arg+0x3094>
    8e70:      	cbz	w8, 0x8ea4 <generic_lsm_filter_arg+0x30b4>
    8e74:      	cmp	w8, #0x1
    8e78:      	b.ne	0x8e9c <generic_lsm_filter_arg+0x30ac>
    8e7c:      	mov	w10, #0x7               // =7
    8e80:      	b	0x8eb0 <generic_lsm_filter_arg+0x30c0>
    8e84:      	cmp	w8, #0x3
    8e88:      	b.eq	0x8eac <generic_lsm_filter_arg+0x30bc>
    8e8c:      	cmp	w8, #0x7
    8e90:      	b.ne	0x8e9c <generic_lsm_filter_arg+0x30ac>
    8e94:      	mov	w10, #0x9               // =9
    8e98:      	b	0x8eb0 <generic_lsm_filter_arg+0x30c0>
    8e9c:      	mov	w10, #0xa               // =10
    8ea0:      	b	0x8eb0 <generic_lsm_filter_arg+0x30c0>
    8ea4:      	mov	w10, #0x6               // =6
    8ea8:      	b	0x8eb0 <generic_lsm_filter_arg+0x30c0>
    8eac:      	mov	w10, #0x8               // =8
    8eb0:      	add	x8, x23, #0x10
    8eb4:      	and	w9, w10, #0xf
    8eb8:      	ldr	w8, [x8, w9, uxtw #2]
    8ebc:      	cmn	w8, #0x1
    8ec0:      	b.eq	0x916c <generic_lsm_filter_arg+0x337c>
    8ec4:      	stp	w8, w11, [sp, #0x1c]
    8ec8:      	str	w10, [sp, #0x28]
    8ecc:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8ed0:      	mov	w8, #0x1                // =1
    8ed4:      	add	x19, sp, #0x88
    8ed8:      	add	x1, sp, #0x88
    8edc:      	ldr	x0, [x0]
    8ee0:      	blr	x8
    8ee4:      	mov	x9, x0
    8ee8:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8eec:      	mov	w8, #0x1                // =1
    8ef0:      	ldr	x0, [x0]
    8ef4:      	add	x1, sp, #0x88
    8ef8:      	mov	x19, x9
    8efc:      	blr	x8
    8f00:      	mov	x22, xzr
    8f04:      	cbz	x19, 0x9170 <generic_lsm_filter_arg+0x3380>
    8f08:      	mov	w12, #0x1               // =1
    8f0c:      	cbz	x0, 0x9174 <generic_lsm_filter_arg+0x3384>
    8f10:      	ldr	w22, [sp, #0x28]
    8f14:      	str	x0, [sp, #0x10]
    8f18:      	mov	x0, x19
    8f1c:      	cmp	w22, #0x5
    8f20:      	b.gt	0x8f5c <generic_lsm_filter_arg+0x316c>
    8f24:      	strb	w25, [x0], #0x1
    8f28:      	mov	w8, #0x4                // =4
    8f2c:      	mov	w1, w25
    8f30:      	mov	x2, x29
    8f34:      	blr	x8
    8f38:      	ldr	w8, [sp, #0x20]
    8f3c:      	subs	w8, w8, w25
    8f40:      	b.ls	0x8f94 <generic_lsm_filter_arg+0x31a4>
    8f44:      	add	x9, x19, x25
    8f48:      	and	w1, w8, #0xfff
    8f4c:      	mov	w8, #0x4                // =4
    8f50:      	ldr	x2, [sp, #0x10]
    8f54:      	add	x0, x9, #0x1
    8f58:      	b	0x8f90 <generic_lsm_filter_arg+0x31a0>
    8f5c:      	strh	w25, [x0], #0x2
    8f60:      	mov	w8, #0x4                // =4
    8f64:      	mov	w1, w25
    8f68:      	mov	x2, x29
    8f6c:      	blr	x8
    8f70:      	ldr	w8, [sp, #0x20]
    8f74:      	subs	w8, w8, w25
    8f78:      	b.ls	0x8f94 <generic_lsm_filter_arg+0x31a4>
    8f7c:      	add	x9, x19, x25
    8f80:      	ldr	x2, [sp, #0x10]
    8f84:      	and	w1, w8, #0xfff
    8f88:      	mov	w8, #0x4                // =4
    8f8c:      	add	x0, x9, #0x2
    8f90:      	blr	x8
    8f94:      	ldr	w8, [sp, #0x1c]
    8f98:      	cmp	w22, #0x4
    8f9c:      	str	w8, [sp, #0x60]
    8fa0:      	b.le	0x8fd8 <generic_lsm_filter_arg+0x31e8>
    8fa4:      	cmp	w22, #0x7
    8fa8:      	b.gt	0x900c <generic_lsm_filter_arg+0x321c>
    8fac:      	cmp	w22, #0x5
    8fb0:      	b.eq	0x9124 <generic_lsm_filter_arg+0x3334>
    8fb4:      	cmp	w22, #0x6
    8fb8:      	b.eq	0x90e8 <generic_lsm_filter_arg+0x32f8>
    8fbc:      	cmp	w22, #0x7
    8fc0:      	b.ne	0x916c <generic_lsm_filter_arg+0x337c>
    8fc4:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8fc8:      	mov	w8, #0x1                // =1
    8fcc:      	add	x9, sp, #0x60
    8fd0:      	ldr	x0, [x0]
    8fd4:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    8fd8:      	cmp	w22, #0x1
    8fdc:      	b.le	0x9038 <generic_lsm_filter_arg+0x3248>
    8fe0:      	cmp	w22, #0x2
    8fe4:      	b.eq	0x9110 <generic_lsm_filter_arg+0x3320>
    8fe8:      	cmp	w22, #0x3
    8fec:      	b.eq	0x90d4 <generic_lsm_filter_arg+0x32e4>
    8ff0:      	cmp	w22, #0x4
    8ff4:      	b.ne	0x916c <generic_lsm_filter_arg+0x337c>
    8ff8:      	adrp	x0, 0x8000 <generic_lsm_filter_arg+0x2210>
    8ffc:      	mov	w8, #0x1                // =1
    9000:      	add	x9, sp, #0x60
    9004:      	ldr	x0, [x0]
    9008:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    900c:      	cmp	w22, #0x8
    9010:      	b.eq	0x9138 <generic_lsm_filter_arg+0x3348>
    9014:      	cmp	w22, #0x9
    9018:      	b.eq	0x90fc <generic_lsm_filter_arg+0x330c>
    901c:      	cmp	w22, #0xa
    9020:      	b.ne	0x916c <generic_lsm_filter_arg+0x337c>
    9024:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9028:      	mov	w8, #0x1                // =1
    902c:      	add	x9, sp, #0x60
    9030:      	ldr	x0, [x0]
    9034:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    9038:      	cbz	w22, 0x90c0 <generic_lsm_filter_arg+0x32d0>
    903c:      	cmp	w22, #0x1
    9040:      	b.ne	0x916c <generic_lsm_filter_arg+0x337c>
    9044:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9048:      	mov	w8, #0x1                // =1
    904c:      	add	x9, sp, #0x60
    9050:      	ldr	x0, [x0]
    9054:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    9058:      	cmp	w8, #0x1
    905c:      	b.eq	0x91b8 <generic_lsm_filter_arg+0x33c8>
    9060:      	cmp	w8, #0x2
    9064:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    9068:      	ldrb	w10, [x25]
    906c:      	b	0x91dc <generic_lsm_filter_arg+0x33ec>
    9070:      	cmp	w8, #0x1
    9074:      	b.eq	0x91c0 <generic_lsm_filter_arg+0x33d0>
    9078:      	cmp	w8, #0x2
    907c:      	b.ne	0x5eec <generic_lsm_filter_arg+0xfc>
    9080:      	ldrh	w10, [x25]
    9084:      	b	0x91dc <generic_lsm_filter_arg+0x33ec>
    9088:      	ldrb	w10, [x25]
    908c:      	b	0x9094 <generic_lsm_filter_arg+0x32a4>
    9090:      	ldrh	w10, [x25]
    9094:      	cmp	w9, w10
    9098:      	b.eq	0x607c <generic_lsm_filter_arg+0x28c>
    909c:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    90a0:      	ldr	x9, [x25]
    90a4:      	cmp	x9, x10
    90a8:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    90ac:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    90b0:      	ldr	x9, [x25]
    90b4:      	cmp	x9, x10
    90b8:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    90bc:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    90c0:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    90c4:      	mov	w8, #0x1                // =1
    90c8:      	add	x9, sp, #0x60
    90cc:      	ldr	x0, [x0]
    90d0:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    90d4:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    90d8:      	mov	w8, #0x1                // =1
    90dc:      	add	x9, sp, #0x60
    90e0:      	ldr	x0, [x0]
    90e4:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    90e8:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    90ec:      	mov	w8, #0x1                // =1
    90f0:      	add	x9, sp, #0x60
    90f4:      	ldr	x0, [x0]
    90f8:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    90fc:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9100:      	mov	w8, #0x1                // =1
    9104:      	add	x9, sp, #0x60
    9108:      	ldr	x0, [x0]
    910c:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    9110:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9114:      	mov	w8, #0x1                // =1
    9118:      	add	x9, sp, #0x60
    911c:      	ldr	x0, [x0]
    9120:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    9124:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9128:      	mov	w8, #0x1                // =1
    912c:      	add	x9, sp, #0x60
    9130:      	ldr	x0, [x0]
    9134:      	b	0x9148 <generic_lsm_filter_arg+0x3358>
    9138:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    913c:      	mov	w8, #0x1                // =1
    9140:      	add	x9, sp, #0x60
    9144:      	ldr	x0, [x0]
    9148:      	add	x1, sp, #0x60
    914c:      	blr	x8
    9150:      	cbz	x0, 0x916c <generic_lsm_filter_arg+0x337c>
    9154:      	mov	w8, #0x1                // =1
    9158:      	mov	x1, x19
    915c:      	blr	x8
    9160:      	cmp	x0, #0x0
    9164:      	cset	w22, ne
    9168:      	b	0x9170 <generic_lsm_filter_arg+0x3380>
    916c:      	mov	x22, xzr
    9170:      	mov	w12, #0x1               // =1
    9174:      	ldr	w8, [x23, #0x4]
    9178:      	ldp	x16, x15, [sp, #0x40]
    917c:      	mov	w2, #0x5ea0             // =24224
    9180:      	cmp	w8, #0x25
    9184:      	ldr	x17, [sp, #0x38]
    9188:      	b.hi	0x91b0 <generic_lsm_filter_arg+0x33c0>
    918c:      	mov	x9, #0x50               // =80
    9190:      	ldr	x19, [sp, #0x30]
    9194:      	lsl	x8, x12, x8
    9198:      	movk	x9, #0xc00, lsl #16
    919c:      	movk	x9, #0x20, lsl #32
    91a0:      	tst	x8, x9
    91a4:      	b.eq	0x6084 <generic_lsm_filter_arg+0x294>
    91a8:      	cmp	x22, #0x0
    91ac:      	b	0x6080 <generic_lsm_filter_arg+0x290>
    91b0:      	ldr	x19, [sp, #0x30]
    91b4:      	b	0x6084 <generic_lsm_filter_arg+0x294>
    91b8:      	ldrb	w10, [x25]
    91bc:      	b	0x91cc <generic_lsm_filter_arg+0x33dc>
    91c0:      	ldrh	w10, [x25]
    91c4:      	b	0x91cc <generic_lsm_filter_arg+0x33dc>
    91c8:      	ldr	w9, [x25]
    91cc:      	cmp	w9, w10
    91d0:      	b.lo	0x6088 <generic_lsm_filter_arg+0x298>
    91d4:      	b	0x91e4 <generic_lsm_filter_arg+0x33f4>
    91d8:      	ldr	w9, [x25]
    91dc:      	cmp	w9, w10
    91e0:      	b.hi	0x6088 <generic_lsm_filter_arg+0x298>
    91e4:      	orr	w8, w8, #0x2
    91e8:      	cmp	w8, #0x6
    91ec:      	b.eq	0x6088 <generic_lsm_filter_arg+0x298>
    91f0:      	b	0x5eec <generic_lsm_filter_arg+0xfc>
    91f4:      	nop
    91f8:      	nop
    91fc:      	nop

0000000000009200 <generic_lsm_actions>:
    9200:      	sub	sp, sp, #0x110
    9204:      	str	x29, [sp, #0xc0]
    9208:      	stp	x30, x25, [sp, #0xd0]
    920c:      	stp	x24, x23, [sp, #0xe0]
    9210:      	stp	x22, x21, [sp, #0xf0]
    9214:      	stp	x20, x19, [sp, #0x100]
    9218:      	str	x0, [sp, #0x50]
    921c:      	str	wzr, [sp, #0x9c]
    9220:      	adrp	x25, 0x9000 <generic_lsm_filter_arg+0x3210>
    9224:      	mov	w8, #0x1                // =1
    9228:      	add	x9, sp, #0x9c
    922c:      	add	x1, sp, #0x9c
    9230:      	ldr	x25, [x25]
    9234:      	mov	x0, x25
    9238:      	blr	x8
    923c:      	cbz	x0, 0x92c8 <generic_lsm_actions+0xc8>
    9240:      	mov	w8, #0x5f04             // =24324
    9244:      	ldr	w19, [x0, x8]
    9248:      	cmp	w19, #0x2
    924c:      	b.lt	0x92c8 <generic_lsm_actions+0xc8>
    9250:      	mov	w8, #0x5ef8             // =24312
    9254:      	add	x1, x0, x8
    9258:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    925c:      	mov	w8, #0x1                // =1
    9260:      	ldr	x0, [x0]
    9264:      	blr	x8
    9268:      	cbz	x0, 0x92c8 <generic_lsm_actions+0xc8>
    926c:      	and	x8, x19, #0x7ff
    9270:      	add	x9, sp, #0xa0
    9274:      	add	x1, sp, #0xa0
    9278:      	ldr	w8, [x0, x8]
    927c:      	str	wzr, [sp, #0xa0]
    9280:      	add	w8, w8, w19
    9284:      	and	w8, w8, #0x7ff
    9288:      	add	x21, x0, x8
    928c:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9290:      	mov	w8, #0x1                // =1
    9294:      	ldr	x0, [x0]
    9298:      	blr	x8
    929c:      	cbz	x0, 0x93dc <generic_lsm_actions+0x1dc>
    92a0:      	ldrb	w8, [x0]
    92a4:      	tst	w8, #0xff
    92a8:      	cset	w8, eq
    92ac:      	str	w8, [sp, #0x3c]
    92b0:      	mov	w8, #0x8                // =8
    92b4:      	cinc	x9, x8, ne
    92b8:      	mov	w8, #0x6                // =6
    92bc:      	cinc	x8, x8, ne
    92c0:      	stp	x8, x9, [sp, #0x28]
    92c4:      	b	0x93f4 <generic_lsm_actions+0x1f4>
    92c8:      	mov	x20, xzr
    92cc:      	str	wzr, [sp, #0xb8]
    92d0:      	mov	w8, #0x1                // =1
    92d4:      	add	x9, sp, #0xb8
    92d8:      	add	x1, sp, #0xb8
    92dc:      	mov	x0, x25
    92e0:      	blr	x8
    92e4:      	cbz	x0, 0x93c0 <generic_lsm_actions+0x1c0>
    92e8:      	mov	w19, #0x5f08            // =24328
    92ec:      	strb	w20, [x0, x19]
    92f0:      	cbz	x20, 0x9360 <generic_lsm_actions+0x160>
    92f4:      	ldrb	w8, [x0, #0x1]
    92f8:      	tbz	w8, #0x3, 0x9360 <generic_lsm_actions+0x160>
    92fc:      	mov	w8, #0xe                // =14
    9300:      	mov	x20, x0
    9304:      	blr	x8
    9308:      	mov	w8, #0x1                // =1
    930c:      	str	x0, [sp, #0xa8]
    9310:      	stur	xzr, [sp, #0x59]
    9314:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9318:      	mov	x3, xzr
    931c:      	add	x9, sp, #0xa8
    9320:      	stur	xzr, [sp, #0x61]
    9324:      	stur	xzr, [sp, #0x69]
    9328:      	add	x10, sp, #0x58
    932c:      	add	x1, sp, #0xa8
    9330:      	add	x2, sp, #0x58
    9334:      	stur	xzr, [sp, #0x71]
    9338:      	stur	xzr, [sp, #0x79]
    933c:      	stur	xzr, [sp, #0x81]
    9340:      	stur	xzr, [sp, #0x89]
    9344:      	stur	xzr, [sp, #0x91]
    9348:      	strb	wzr, [sp, #0x99]
    934c:      	strb	w8, [sp, #0x58]
    9350:      	ldr	x0, [x0]
    9354:      	mov	w8, #0x2                // =2
    9358:      	blr	x8
    935c:      	ldrb	w20, [x20, x19]
    9360:      	cbz	w20, 0x936c <generic_lsm_actions+0x16c>
    9364:      	mov	w0, wzr
    9368:      	b	0x93c0 <generic_lsm_actions+0x1c0>
    936c:      	mov	w8, #0xe                // =14
    9370:      	blr	x8
    9374:      	str	x0, [sp, #0x58]
    9378:      	adrp	x19, 0x9000 <generic_lsm_filter_arg+0x3210>
    937c:      	mov	w8, #0x1                // =1
    9380:      	add	x9, sp, #0x58
    9384:      	ldr	x19, [x19]
    9388:      	add	x1, sp, #0x58
    938c:      	mov	x0, x19
    9390:      	blr	x8
    9394:      	cbz	x0, 0x93c0 <generic_lsm_actions+0x1c0>
    9398:      	mov	w8, #0x3                // =3
    939c:      	add	x9, sp, #0x58
    93a0:      	mov	x20, x0
    93a4:      	add	x1, sp, #0x58
    93a8:      	mov	x0, x19
    93ac:      	blr	x8
    93b0:      	ldr	w8, [x20]
    93b4:      	sub	w9, w8, #0x1
    93b8:      	cmn	w9, #0x1, lsl #12       // =0x1000
    93bc:      	csinv	w0, w8, wzr, hs
    93c0:      	ldp	x20, x19, [sp, #0x100]
    93c4:      	ldr	x29, [sp, #0xc0]
    93c8:      	ldp	x22, x21, [sp, #0xf0]
    93cc:      	ldp	x24, x23, [sp, #0xe0]
    93d0:      	ldp	x30, x25, [sp, #0xd0]
    93d4:      	add	sp, sp, #0x110
    93d8:      	ret
    93dc:      	mov	w8, #0x1                // =1
    93e0:      	str	w8, [sp, #0x3c]
    93e4:      	mov	w8, #0x6                // =6
    93e8:      	str	x8, [sp, #0x28]
    93ec:      	mov	w8, #0x8                // =8
    93f0:      	str	x8, [sp, #0x30]
    93f4:      	mov	w22, wzr
    93f8:      	mov	w20, wzr
    93fc:      	add	x19, sp, #0xa4
    9400:      	str	x21, [sp, #0x40]
    9404:      	mov	w8, #0x1                // =1
    9408:      	str	w8, [sp, #0x4c]
    940c:      	b	0x9430 <generic_lsm_actions+0x230>
    9410:      	nop
    9414:      	nop
    9418:      	nop
    941c:      	nop
    9420:      	mov	w20, wzr
    9424:      	add	w22, w22, #0x1
    9428:      	cmp	w22, #0x3
    942c:      	b.eq	0x9e14 <generic_lsm_actions+0xc14>
    9430:      	ldr	w9, [x21]
    9434:      	lsl	w8, w20, #2
    9438:      	add	w8, w8, #0x4
    943c:      	cmp	w8, w9
    9440:      	b.hs	0x9e14 <generic_lsm_actions+0xc14>
    9444:      	add	x8, x21, w20, uxtw #2
    9448:      	add	x1, sp, #0xa4
    944c:      	mov	x0, x25
    9450:      	ldrsw	x24, [x8, #0x4]
    9454:      	str	wzr, [sp, #0xa4]
    9458:      	mov	w8, #0x1                // =1
    945c:      	blr	x8
    9460:      	cbz	x0, 0x9420 <generic_lsm_actions+0x220>
    9464:      	mov	x23, x0
    9468:      	cmp	w24, #0x7
    946c:      	b.gt	0x94a0 <generic_lsm_actions+0x2a0>
    9470:      	cmp	w24, #0x3
    9474:      	b.gt	0x94ec <generic_lsm_actions+0x2ec>
    9478:      	cmp	w24, #0x1
    947c:      	b.gt	0x9618 <generic_lsm_actions+0x418>
    9480:      	cbz	w24, 0x97f0 <generic_lsm_actions+0x5f0>
    9484:      	cmp	w24, #0x1
    9488:      	b.eq	0x9628 <generic_lsm_actions+0x428>
    948c:      	b	0x9afc <generic_lsm_actions+0x8fc>
    9490:      	nop
    9494:      	nop
    9498:      	nop
    949c:      	nop
    94a0:      	cmp	w24, #0xb
    94a4:      	b.gt	0x95f4 <generic_lsm_actions+0x3f4>
    94a8:      	sub	w8, w24, #0xa
    94ac:      	cmp	w8, #0x2
    94b0:      	b.lo	0x967c <generic_lsm_actions+0x47c>
    94b4:      	cmp	w24, #0x8
    94b8:      	b.eq	0x96c4 <generic_lsm_actions+0x4c4>
    94bc:      	cmp	w24, #0x9
    94c0:      	b.ne	0x9afc <generic_lsm_actions+0x8fc>
    94c4:      	add	w20, w20, #0x1
    94c8:      	add	x8, x21, w20, uxtw #2
    94cc:      	ldr	w0, [x8, #0x4]
    94d0:      	ldr	w8, [sp, #0x3c]
    94d4:      	cbz	w8, 0x9894 <generic_lsm_actions+0x694>
    94d8:      	sxtw	x8, w0
    94dc:      	mov	w9, #0x6d               // =109
    94e0:      	blr	x9
    94e4:      	mov	w19, #0x2               // =2
    94e8:      	b	0x9ac4 <generic_lsm_actions+0x8c4>
    94ec:      	sub	w8, w24, #0x6
    94f0:      	cmp	w8, #0x2
    94f4:      	b.lo	0x96b0 <generic_lsm_actions+0x4b0>
    94f8:      	cmp	w24, #0x4
    94fc:      	b.eq	0x96cc <generic_lsm_actions+0x4cc>
    9500:      	cmp	w24, #0x5
    9504:      	b.ne	0x9afc <generic_lsm_actions+0x8fc>
    9508:      	add	w8, w20, #0x1
    950c:      	add	x9, x21, #0x4
    9510:      	add	w20, w20, #0x2
    9514:      	ldr	w8, [x9, w8, uxtw #2]
    9518:      	ldr	w19, [x9, w20, uxtw #2]
    951c:      	stp	xzr, xzr, [sp, #0x58]
    9520:      	and	x8, x8, #0x7
    9524:      	cmp	w8, #0x4
    9528:      	b.hi	0x9af8 <generic_lsm_actions+0x8f8>
    952c:      	add	x9, x23, x8, lsl #2
    9530:      	mov	w10, #0x5ea0            // =24224
    9534:      	ldr	w9, [x9, x10]
    9538:      	cbnz	w9, 0x9af8 <generic_lsm_actions+0x8f8>
    953c:      	add	x8, x23, x8, lsl #3
    9540:      	ldr	x8, [x8, #0x5e78]
    9544:      	and	x8, x8, #0x7ff
    9548:      	add	x8, x23, x8
    954c:      	ldr	w8, [x8, #0x90]
    9550:      	str	w8, [sp, #0x60]
    9554:      	mov	w8, #0xe                // =14
    9558:      	blr	x8
    955c:      	lsr	x8, x0, #32
    9560:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9564:      	add	x9, sp, #0x58
    9568:      	str	x8, [sp, #0x58]
    956c:      	mov	w8, #0x1                // =1
    9570:      	add	x1, sp, #0x58
    9574:      	ldr	x0, [x0]
    9578:      	blr	x8
    957c:      	cbz	x0, 0x9af8 <generic_lsm_actions+0x8f8>
    9580:      	and	x8, x19, #0x7
    9584:      	cmp	w8, #0x4
    9588:      	b.hi	0x9af8 <generic_lsm_actions+0x8f8>
    958c:      	add	x9, x23, x8, lsl #2
    9590:      	mov	w10, #0x5ea0            // =24224
    9594:      	ldr	w9, [x9, x10]
    9598:      	cbnz	w9, 0x9af8 <generic_lsm_actions+0x8f8>
    959c:      	add	x8, x23, x8, lsl #3
    95a0:      	mov	x21, x0
    95a4:      	ldr	x8, [x8, #0x5e78]
    95a8:      	str	wzr, [sp, #0x64]
    95ac:      	and	x8, x8, #0x7ff
    95b0:      	add	x8, x23, x8
    95b4:      	ldr	w8, [x8, #0x90]
    95b8:      	str	w8, [sp, #0x60]
    95bc:      	mov	w8, #0xe                // =14
    95c0:      	blr	x8
    95c4:      	lsr	x8, x0, #32
    95c8:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    95cc:      	mov	x3, xzr
    95d0:      	str	x8, [sp, #0x58]
    95d4:      	mov	w8, #0x2                // =2
    95d8:      	add	x9, sp, #0x58
    95dc:      	mov	x2, x21
    95e0:      	ldr	x0, [x0]
    95e4:      	add	x1, sp, #0x58
    95e8:      	ldr	x21, [sp, #0x40]
    95ec:      	blr	x8
    95f0:      	b	0x9af8 <generic_lsm_actions+0x8f8>
    95f4:      	cmp	w24, #0xc
    95f8:      	b.eq	0x989c <generic_lsm_actions+0x69c>
    95fc:      	cmp	w24, #0xd
    9600:      	b.eq	0x9758 <generic_lsm_actions+0x558>
    9604:      	cmp	w24, #0xe
    9608:      	b.ne	0x9afc <generic_lsm_actions+0x8fc>
    960c:      	ldr	x19, [sp, #0x30]
    9610:      	add	w20, w20, #0x2
    9614:      	b	0x9ac4 <generic_lsm_actions+0x8c4>
    9618:      	cmp	w24, #0x2
    961c:      	b.eq	0x9888 <generic_lsm_actions+0x688>
    9620:      	cmp	w24, #0x3
    9624:      	b.ne	0x9afc <generic_lsm_actions+0x8fc>
    9628:      	add	w8, w20, #0x1
    962c:      	add	x9, x21, #0x4
    9630:      	add	w20, w20, #0x2
    9634:      	ldr	w21, [x9, w8, uxtw #2]
    9638:      	ldr	w19, [x9, w20, uxtw #2]
    963c:      	stp	xzr, xzr, [sp, #0x58]
    9640:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9644:      	mov	w8, #0x1                // =1
    9648:      	add	x9, sp, #0xa8
    964c:      	add	x1, sp, #0xa8
    9650:      	str	wzr, [sp, #0xa8]
    9654:      	ldr	x0, [x0]
    9658:      	blr	x8
    965c:      	cbz	x0, 0x9670 <generic_lsm_actions+0x470>
    9660:      	and	x8, x21, #0x7
    9664:      	cmp	w8, #0x4
    9668:      	b.ls	0x98a8 <generic_lsm_actions+0x6a8>
    966c:      	mov	w0, wzr
    9670:      	ldr	x21, [sp, #0x40]
    9674:      	add	x19, sp, #0xa4
    9678:      	b	0x96a8 <generic_lsm_actions+0x4a8>
    967c:      	add	w20, w20, #0x1
    9680:      	add	x8, x21, w20, uxtw #2
    9684:      	ldr	w8, [x8, #0x4]
    9688:      	and	x8, x8, #0x7
    968c:      	cmp	w8, #0x4
    9690:      	b.hi	0x96a4 <generic_lsm_actions+0x4a4>
    9694:      	add	x9, x23, x8, lsl #2
    9698:      	mov	w10, #0x5ea0            // =24224
    969c:      	ldr	w9, [x9, x10]
    96a0:      	cbz	w9, 0x98d0 <generic_lsm_actions+0x6d0>
    96a4:      	mov	w0, wzr
    96a8:      	cbnz	w0, 0x9420 <generic_lsm_actions+0x220>
    96ac:      	b	0x9afc <generic_lsm_actions+0x8fc>
    96b0:      	add	w20, w20, #0x1
    96b4:      	add	x8, x21, w20, uxtw #2
    96b8:      	ldr	w8, [x8, #0x4]
    96bc:      	str	w8, [x23, #0x78]
    96c0:      	b	0x9afc <generic_lsm_actions+0x8fc>
    96c4:      	str	wzr, [sp, #0x4c]
    96c8:      	b	0x9afc <generic_lsm_actions+0x8fc>
    96cc:      	ldr	w8, [sp, #0x3c]
    96d0:      	add	w20, w20, #0x1
    96d4:      	cbz	w8, 0x98c8 <generic_lsm_actions+0x6c8>
    96d8:      	add	x8, x21, w20, uxtw #2
    96dc:      	ldr	w8, [x8, #0x4]
    96e0:      	str	w8, [sp, #0xcc]
    96e4:      	mov	w8, #0xe                // =14
    96e8:      	blr	x8
    96ec:      	str	x0, [sp, #0xa8]
    96f0:      	adrp	x29, 0x9000 <generic_lsm_filter_arg+0x3210>
    96f4:      	mov	w8, #0x1                // =1
    96f8:      	add	x19, sp, #0xa8
    96fc:      	ldr	x29, [x29]
    9700:      	add	x1, sp, #0xa8
    9704:      	mov	x0, x29
    9708:      	blr	x8
    970c:      	cbz	x0, 0x9a70 <generic_lsm_actions+0x870>
    9710:      	mov	w8, #0x11               // =17
    9714:      	adrp	x29, 0x9000 <generic_lsm_filter_arg+0x3210>
    9718:      	add	x19, sp, #0x58
    971c:      	mov	x21, x0
    9720:      	add	x1, sp, #0x58
    9724:      	movk	w8, #0xe, lsl #16
    9728:      	str	w8, [sp, #0x58]
    972c:      	mov	w8, #0x35c              // =860
    9730:      	stur	x8, [sp, #0x5c]
    9734:      	mov	w8, #0x1                // =1
    9738:      	ldr	x29, [x29]
    973c:      	mov	x0, x29
    9740:      	blr	x8
    9744:      	cbz	x0, 0x9a90 <generic_lsm_actions+0x890>
    9748:      	ldr	w8, [x0]
    974c:      	add	w8, w8, #0x1
    9750:      	str	w8, [x0]
    9754:      	b	0x9ab4 <generic_lsm_actions+0x8b4>
    9758:      	mov	w8, #0xe                // =14
    975c:      	blr	x8
    9760:      	str	x0, [sp, #0xb8]
    9764:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9768:      	mov	w8, #0x1                // =1
    976c:      	add	x9, sp, #0xb8
    9770:      	ldr	x0, [x0]
    9774:      	add	x1, sp, #0xb8
    9778:      	blr	x8
    977c:      	cbz	x0, 0x9afc <generic_lsm_actions+0x8fc>
    9780:      	ldur	x8, [x0, #0x4]
    9784:      	adrp	x29, 0x9000 <generic_lsm_filter_arg+0x3210>
    9788:      	add	x21, sp, #0xa8
    978c:      	add	x1, sp, #0xa8
    9790:      	str	x8, [sp, #0xa8]
    9794:      	mov	w8, #0x2                // =2
    9798:      	str	w8, [sp, #0xb0]
    979c:      	mov	w8, #0x1                // =1
    97a0:      	ldr	x29, [x29]
    97a4:      	mov	x0, x29
    97a8:      	blr	x8
    97ac:      	mov	w9, #0x1                // =1
    97b0:      	str	w9, [sp, #0xc8]
    97b4:      	cbz	x0, 0x9a00 <generic_lsm_actions+0x800>
    97b8:      	nop
    97bc:      	nop
    97c0:      	ldaxr	w8, [x0]
    97c4:      	add	w8, w8, #0x1
    97c8:      	stlxr	w9, w8, [x0]
    97cc:      	cbnz	w9, 0x97c0 <generic_lsm_actions+0x5c0>
    97d0:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    97d4:      	mov	w8, #0x3                // =3
    97d8:      	add	x9, sp, #0xb8
    97dc:      	ldr	x0, [x0]
    97e0:      	add	x1, sp, #0xb8
    97e4:      	blr	x8
    97e8:      	ldr	x21, [sp, #0x40]
    97ec:      	b	0x9afc <generic_lsm_actions+0x8fc>
    97f0:      	add	w8, w20, #0x1
    97f4:      	add	x9, x21, #0x4
    97f8:      	ldr	w29, [x9, w8, uxtw #2]
    97fc:      	add	w8, w20, #0x2
    9800:      	ldr	w19, [x9, w8, uxtw #2]
    9804:      	mov	w8, #0x7d               // =125
    9808:      	blr	x8
    980c:      	str	x0, [sp, #0x58]
    9810:      	str	wzr, [sp, #0xb8]
    9814:      	str	x29, [sp, #0x10]
    9818:      	cbz	w29, 0x9d14 <generic_lsm_actions+0xb14>
    981c:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9820:      	mov	w8, #0x1                // =1
    9824:      	add	x9, sp, #0xb8
    9828:      	ldr	x0, [x0]
    982c:      	add	x1, sp, #0xb8
    9830:      	blr	x8
    9834:      	cbz	x0, 0x9d14 <generic_lsm_actions+0xb14>
    9838:      	str	x0, [sp, #0x18]
    983c:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9840:      	mov	w8, #0x1                // =1
    9844:      	add	x9, sp, #0xb8
    9848:      	ldr	x0, [x0]
    984c:      	add	x1, sp, #0xb8
    9850:      	blr	x8
    9854:      	ldr	x9, [sp, #0x18]
    9858:      	ldr	x8, [x23, #0x60]
    985c:      	mov	x2, x0
    9860:      	cmp	w19, #0x2
    9864:      	str	x8, [x9]
    9868:      	ldr	x8, [x23, #0x70]
    986c:      	str	x8, [x9, #0x8]
    9870:      	b.eq	0x9b54 <generic_lsm_actions+0x954>
    9874:      	cmp	w19, #0x1
    9878:      	b.eq	0x9b4c <generic_lsm_actions+0x94c>
    987c:      	cbnz	w19, 0x9d14 <generic_lsm_actions+0xb14>
    9880:      	ldr	w8, [x23, #0x7c]
    9884:      	b	0x9b58 <generic_lsm_actions+0x958>
    9888:      	mov	w0, #0x9                // =9
    988c:      	ldr	w8, [sp, #0x3c]
    9890:      	cbnz	w8, 0x94d8 <generic_lsm_actions+0x2d8>
    9894:      	mov	w19, #0x3               // =3
    9898:      	b	0x9ac4 <generic_lsm_actions+0x8c4>
    989c:      	ldr	x19, [sp, #0x28]
    98a0:      	add	w20, w20, #0x3
    98a4:      	b	0x9ac4 <generic_lsm_actions+0x8c4>
    98a8:      	add	x9, x23, x8, lsl #2
    98ac:      	mov	w10, #0x5ea0            // =24224
    98b0:      	ldr	x21, [sp, #0x40]
    98b4:      	ldr	w9, [x9, x10]
    98b8:      	cbz	w9, 0x9954 <generic_lsm_actions+0x754>
    98bc:      	mov	w0, wzr
    98c0:      	add	x19, sp, #0xa4
    98c4:      	b	0x96a8 <generic_lsm_actions+0x4a8>
    98c8:      	mov	w19, #0x5               // =5
    98cc:      	b	0x9ac4 <generic_lsm_actions+0x8c4>
    98d0:      	add	x8, x23, x8, lsl #3
    98d4:      	ldr	x8, [x8, #0x5e78]
    98d8:      	and	x8, x8, #0x7ff
    98dc:      	add	x8, x23, x8
    98e0:      	ldr	x8, [x8, #0xb8]
    98e4:      	str	x8, [sp, #0xa8]
    98e8:      	cbz	x8, 0x96a4 <generic_lsm_actions+0x4a4>
    98ec:      	cmp	w24, #0xa
    98f0:      	b.ne	0x9b30 <generic_lsm_actions+0x930>
    98f4:      	mov	w8, #0xe                // =14
    98f8:      	blr	x8
    98fc:      	lsr	x8, x0, #32
    9900:      	mov	x21, x0
    9904:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9908:      	str	w8, [sp, #0x58]
    990c:      	mov	w8, #0x1                // =1
    9910:      	add	x29, sp, #0x58
    9914:      	add	x1, sp, #0x58
    9918:      	ldr	x0, [x0]
    991c:      	blr	x8
    9920:      	cbz	x0, 0x99f8 <generic_lsm_actions+0x7f8>
    9924:      	ldr	w8, [x0]
    9928:      	mov	x3, xzr
    992c:      	add	x9, sp, #0xa8
    9930:      	add	x1, sp, #0xa8
    9934:      	stp	w8, w21, [sp, #0x58]
    9938:      	ldr	x8, [x0, #0x8]
    993c:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9940:      	add	x2, sp, #0x58
    9944:      	str	x8, [sp, #0x60]
    9948:      	mov	w8, #0x2                // =2
    994c:      	ldr	x0, [x0]
    9950:      	b	0x99f0 <generic_lsm_actions+0x7f0>
    9954:      	add	x8, x23, x8, lsl #3
    9958:      	mov	x21, x0
    995c:      	ldr	x8, [x8, #0x5e78]
    9960:      	str	wzr, [sp, #0x64]
    9964:      	and	x8, x8, #0x7ff
    9968:      	add	x8, x23, x8
    996c:      	ldr	w8, [x8, #0x90]
    9970:      	str	w8, [sp, #0x60]
    9974:      	mov	w8, #0xe                // =14
    9978:      	blr	x8
    997c:      	lsr	x8, x0, #32
    9980:      	cmp	w24, #0x1
    9984:      	str	x8, [sp, #0x58]
    9988:      	b.ne	0x9b14 <generic_lsm_actions+0x914>
    998c:      	and	x8, x19, #0x7
    9990:      	cmp	w8, #0x4
    9994:      	b.hi	0x966c <generic_lsm_actions+0x46c>
    9998:      	add	x9, x23, x8, lsl #2
    999c:      	mov	w10, #0x5ea0            // =24224
    99a0:      	add	x19, sp, #0xa4
    99a4:      	ldr	w9, [x9, x10]
    99a8:      	cbnz	w9, 0x99f4 <generic_lsm_actions+0x7f4>
    99ac:      	add	x8, x23, x8, lsl #3
    99b0:      	mov	x0, x21
    99b4:      	ldr	x8, [x8, #0x5e78]
    99b8:      	and	x8, x8, #0x7ff
    99bc:      	add	x2, x23, x8
    99c0:      	ldr	w8, [x2, #0x90]!
    99c4:      	and	x8, x8, #0xfff
    99c8:      	add	x1, x8, #0x8
    99cc:      	mov	w8, #0x4                // =4
    99d0:      	blr	x8
    99d4:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    99d8:      	mov	x3, xzr
    99dc:      	mov	w8, #0x2                // =2
    99e0:      	ldr	x0, [x0]
    99e4:      	add	x9, sp, #0x58
    99e8:      	add	x1, sp, #0x58
    99ec:      	mov	x2, x21
    99f0:      	blr	x8
    99f4:      	mov	w0, wzr
    99f8:      	ldr	x21, [sp, #0x40]
    99fc:      	b	0x96a8 <generic_lsm_actions+0x4a8>
    9a00:      	mov	w8, #0x2                // =2
    9a04:      	add	x10, sp, #0xc8
    9a08:      	add	x1, sp, #0xa8
    9a0c:      	add	x2, sp, #0xc8
    9a10:      	mov	x0, x29
    9a14:      	mov	w3, #0x1                // =1
    9a18:      	blr	x8
    9a1c:      	cbz	x0, 0x97d0 <generic_lsm_actions+0x5d0>
    9a20:      	mov	x29, x0
    9a24:      	adrp	x21, 0x9000 <generic_lsm_filter_arg+0x3210>
    9a28:      	add	x10, sp, #0x58
    9a2c:      	add	x1, sp, #0x58
    9a30:      	neg	w8, w29
    9a34:      	strh	w8, [sp, #0x58]
    9a38:      	mov	w8, #0x3                // =3
    9a3c:      	strh	w8, [sp, #0x5a]
    9a40:      	mov	x8, #0x3b               // =59
    9a44:      	movk	x8, #0x2, lsl #32
    9a48:      	stur	x8, [sp, #0x5c]
    9a4c:      	mov	w8, #0x1                // =1
    9a50:      	ldr	x21, [x21]
    9a54:      	mov	x0, x21
    9a58:      	blr	x8
    9a5c:      	cbz	x0, 0x9dac <generic_lsm_actions+0xbac>
    9a60:      	ldr	w8, [x0]
    9a64:      	add	w8, w8, #0x1
    9a68:      	str	w8, [x0]
    9a6c:      	b	0x9dd4 <generic_lsm_actions+0xbd4>
    9a70:      	mov	x3, xzr
    9a74:      	mov	w8, #0x2                // =2
    9a78:      	add	x9, sp, #0xcc
    9a7c:      	add	x1, sp, #0xa8
    9a80:      	add	x2, sp, #0xcc
    9a84:      	mov	x0, x29
    9a88:      	blr	x8
    9a8c:      	b	0x9abc <generic_lsm_actions+0x8bc>
    9a90:      	mov	w8, #0x1                // =1
    9a94:      	mov	x3, xzr
    9a98:      	add	x9, sp, #0xb8
    9a9c:      	str	w8, [sp, #0xb8]
    9aa0:      	mov	w8, #0x2                // =2
    9aa4:      	add	x1, sp, #0x58
    9aa8:      	add	x2, sp, #0xb8
    9aac:      	mov	x0, x29
    9ab0:      	blr	x8
    9ab4:      	ldr	w8, [sp, #0xcc]
    9ab8:      	str	w8, [x21]
    9abc:      	ldr	x21, [sp, #0x40]
    9ac0:      	mov	w19, #0x4               // =4
    9ac4:      	str	wzr, [sp, #0x58]
    9ac8:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9acc:      	mov	w8, #0x1                // =1
    9ad0:      	add	x9, sp, #0x58
    9ad4:      	ldr	x0, [x0]
    9ad8:      	add	x1, sp, #0x58
    9adc:      	blr	x8
    9ae0:      	cbz	x0, 0x9af8 <generic_lsm_actions+0x8f8>
    9ae4:      	add	x8, x0, x19, lsl #3
    9ae8:      	ldaxr	x9, [x8]
    9aec:      	add	x9, x9, #0x1
    9af0:      	stlxr	w10, x9, [x8]
    9af4:      	cbnz	w10, 0x9ae8 <generic_lsm_actions+0x8e8>
    9af8:      	add	x19, sp, #0xa4
    9afc:      	add	w20, w20, #0x1
    9b00:      	str	x24, [x23, #0x70]
    9b04:      	add	w22, w22, #0x1
    9b08:      	cmp	w22, #0x3
    9b0c:      	b.ne	0x9430 <generic_lsm_actions+0x230>
    9b10:      	b	0x9e14 <generic_lsm_actions+0xc14>
    9b14:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9b18:      	mov	w8, #0x3                // =3
    9b1c:      	add	x9, sp, #0x58
    9b20:      	ldr	x0, [x0]
    9b24:      	add	x1, sp, #0x58
    9b28:      	blr	x8
    9b2c:      	b	0x9670 <generic_lsm_actions+0x470>
    9b30:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9b34:      	mov	w8, #0x3                // =3
    9b38:      	add	x9, sp, #0xa8
    9b3c:      	ldr	x0, [x0]
    9b40:      	add	x1, sp, #0xa8
    9b44:      	blr	x8
    9b48:      	b	0x96a8 <generic_lsm_actions+0x4a8>
    9b4c:      	ldr	w8, [x23, #0x10]
    9b50:      	b	0x9b58 <generic_lsm_actions+0x958>
    9b54:      	mov	x8, xzr
    9b58:      	str	x8, [x9, #0x10]
    9b5c:      	add	x0, x9, #0x18
    9b60:      	mov	w8, #0x4                // =4
    9b64:      	mov	w9, #0xc8               // =200
    9b68:      	mov	w1, #0xc8               // =200
    9b6c:      	str	x0, [sp, #0x20]
    9b70:      	blr	x8
    9b74:      	mov	w8, #0x5e78             // =24184
    9b78:      	mov	x21, xzr
    9b7c:      	mov	w29, wzr
    9b80:      	add	x19, x23, x8
    9b84:      	b	0x9b98 <generic_lsm_actions+0x998>
    9b88:      	add	x21, x21, #0x4
    9b8c:      	add	x19, x19, #0x8
    9b90:      	cmp	x21, #0x14
    9b94:      	b.eq	0x9cb0 <generic_lsm_actions+0xab0>
    9b98:      	str	wzr, [sp, #0xa8]
    9b9c:      	mov	w8, #0x1                // =1
    9ba0:      	add	x9, sp, #0xa8
    9ba4:      	add	x1, sp, #0xa8
    9ba8:      	mov	x0, x25
    9bac:      	blr	x8
    9bb0:      	cbz	x0, 0x9cb0 <generic_lsm_actions+0xab0>
    9bb4:      	mov	w8, #0x5ef8             // =24312
    9bb8:      	add	x1, x0, x8
    9bbc:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9bc0:      	mov	w8, #0x1                // =1
    9bc4:      	ldr	x0, [x0]
    9bc8:      	blr	x8
    9bcc:      	cbz	x0, 0x9cb0 <generic_lsm_actions+0xab0>
    9bd0:      	add	x8, x0, x21
    9bd4:      	ldr	w8, [x8, #0x40]
    9bd8:      	cmn	w8, #0x1
    9bdc:      	b.eq	0x9cb0 <generic_lsm_actions+0xab0>
    9be0:      	ldr	x8, [x19]
    9be4:      	ldr	w9, [x23, #0x4]
    9be8:      	cmp	x8, x9
    9bec:      	b.ge	0x9cb0 <generic_lsm_actions+0xab0>
    9bf0:      	cmp	x21, #0x10
    9bf4:      	b.eq	0x9c54 <generic_lsm_actions+0xa54>
    9bf8:      	str	wzr, [sp, #0xa8]
    9bfc:      	mov	w8, #0x1                // =1
    9c00:      	add	x9, sp, #0xa8
    9c04:      	add	x1, sp, #0xa8
    9c08:      	mov	x0, x25
    9c0c:      	blr	x8
    9c10:      	cbz	x0, 0x9c50 <generic_lsm_actions+0xa50>
    9c14:      	mov	w8, #0x5ef8             // =24312
    9c18:      	add	x1, x0, x8
    9c1c:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9c20:      	mov	w8, #0x1                // =1
    9c24:      	ldr	x0, [x0]
    9c28:      	blr	x8
    9c2c:      	cbz	x0, 0x9c50 <generic_lsm_actions+0xa50>
    9c30:      	add	x8, x0, x21
    9c34:      	ldr	w9, [x8, #0x44]
    9c38:      	ldr	x8, [x19]
    9c3c:      	cmn	w9, #0x1
    9c40:      	b.eq	0x9c54 <generic_lsm_actions+0xa54>
    9c44:      	ldr	w9, [x19, #0x8]
    9c48:      	sub	w9, w9, w8
    9c4c:      	b	0x9c60 <generic_lsm_actions+0xa60>
    9c50:      	ldr	x8, [x19]
    9c54:      	ldr	w9, [x23, #0x4]
    9c58:      	sub	w9, w9, w8
    9c5c:      	add	w9, w9, #0x4
    9c60:      	cmp	w9, #0x1
    9c64:      	b.lt	0x9b88 <generic_lsm_actions+0x988>
    9c68:      	mov	w10, #0x3ffc            // =16380
    9c6c:      	cmp	w9, #0x28
    9c70:      	add	w8, w8, w10
    9c74:      	mov	w10, #0x28              // =40
    9c78:      	and	w25, w29, #0xff
    9c7c:      	csel	w29, w9, w10, lt
    9c80:      	ldr	x9, [sp, #0x20]
    9c84:      	and	x8, x8, #0x3fff
    9c88:      	add	x8, x23, x8
    9c8c:      	mov	w1, w29
    9c90:      	add	x2, x8, #0x90
    9c94:      	mov	w8, #0x4                // =4
    9c98:      	add	x0, x9, x25
    9c9c:      	blr	x8
    9ca0:      	add	w29, w29, w25
    9ca4:      	adrp	x25, 0x9000 <generic_lsm_filter_arg+0x3210>
    9ca8:      	ldr	x25, [x25]
    9cac:      	b	0x9b88 <generic_lsm_actions+0x988>
    9cb0:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9cb4:      	mov	w8, #0x1                // =1
    9cb8:      	ldr	x0, [x0]
    9cbc:      	ldr	x1, [sp, #0x18]
    9cc0:      	blr	x8
    9cc4:      	ldr	x21, [sp, #0x40]
    9cc8:      	cbz	x0, 0x9cf4 <generic_lsm_actions+0xaf4>
    9ccc:      	ldr	x9, [sp, #0x58]
    9cd0:      	ldr	x11, [sp, #0x10]
    9cd4:      	mov	x10, #-0x4240           // =-16960
    9cd8:      	movk	x10, #0xfff0, lsl #16
    9cdc:      	ldr	x8, [x0]
    9ce0:      	madd	x9, x11, x10, x9
    9ce4:      	cmp	x8, x9
    9ce8:      	b.ls	0x9cf4 <generic_lsm_actions+0xaf4>
    9cec:      	str	wzr, [sp, #0x4c]
    9cf0:      	b	0x9d14 <generic_lsm_actions+0xb14>
    9cf4:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9cf8:      	mov	x3, xzr
    9cfc:      	mov	w8, #0x2                // =2
    9d00:      	ldr	x0, [x0]
    9d04:      	ldr	x1, [sp, #0x18]
    9d08:      	add	x9, sp, #0x58
    9d0c:      	add	x2, sp, #0x58
    9d10:      	blr	x8
    9d14:      	add	w8, w20, #0x3
    9d18:      	add	x19, sp, #0xa4
    9d1c:      	add	x8, x21, w8, uxtw #2
    9d20:      	ldr	w8, [x8, #0x4]
    9d24:      	cbz	w8, 0x9d50 <generic_lsm_actions+0xb50>
    9d28:      	ldrb	w8, [x23, #0x1]
    9d2c:      	adrp	x1, 0x9000 <generic_lsm_filter_arg+0x3210>
    9d30:      	mov	x2, xzr
    9d34:      	orr	w8, w8, #0x2
    9d38:      	strb	w8, [x23, #0x1]
    9d3c:      	mov	w8, #0x1b               // =27
    9d40:      	ldr	x1, [x1]
    9d44:      	ldr	x0, [sp, #0x50]
    9d48:      	blr	x8
    9d4c:      	str	x0, [x23, #0x80]
    9d50:      	add	w8, w20, #0x4
    9d54:      	add	x8, x21, w8, uxtw #2
    9d58:      	ldr	w8, [x8, #0x4]
    9d5c:      	cbz	w8, 0x9d8c <generic_lsm_actions+0xb8c>
    9d60:      	ldrb	w8, [x23, #0x1]
    9d64:      	adrp	x1, 0x9000 <generic_lsm_filter_arg+0x3210>
    9d68:      	mov	w9, #0x100              // =256
    9d6c:      	mov	w2, #0x100              // =256
    9d70:      	orr	w8, w8, #0x4
    9d74:      	strb	w8, [x23, #0x1]
    9d78:      	mov	w8, #0x1b               // =27
    9d7c:      	ldr	x1, [x1]
    9d80:      	ldr	x0, [sp, #0x50]
    9d84:      	blr	x8
    9d88:      	str	x0, [x23, #0x88]
    9d8c:      	add	w20, w20, #0x5
    9d90:      	add	x8, x21, w20, uxtw #2
    9d94:      	ldr	w8, [x8, #0x4]
    9d98:      	cbz	w8, 0x9afc <generic_lsm_actions+0x8fc>
    9d9c:      	ldrb	w8, [x23, #0x1]
    9da0:      	orr	w8, w8, #0x8
    9da4:      	strb	w8, [x23, #0x1]
    9da8:      	b	0x9afc <generic_lsm_actions+0x8fc>
    9dac:      	mov	w8, #0x1                // =1
    9db0:      	mov	x3, xzr
    9db4:      	add	x9, sp, #0xcc
    9db8:      	str	w8, [sp, #0xcc]
    9dbc:      	mov	w8, #0x2                // =2
    9dc0:      	add	x10, sp, #0x58
    9dc4:      	add	x1, sp, #0x58
    9dc8:      	add	x2, sp, #0xcc
    9dcc:      	mov	x0, x21
    9dd0:      	blr	x8
    9dd4:      	cbz	w29, 0x97d0 <generic_lsm_actions+0x5d0>
    9dd8:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9ddc:      	mov	w8, #0x1                // =1
    9de0:      	add	x9, sp, #0xa8
    9de4:      	ldr	x0, [x0]
    9de8:      	add	x1, sp, #0xa8
    9dec:      	blr	x8
    9df0:      	cbz	x0, 0x97d0 <generic_lsm_actions+0x5d0>
    9df4:      	ldr	w8, [sp, #0xc8]
    9df8:      	nop
    9dfc:      	nop
    9e00:      	ldaxr	w9, [x0]
    9e04:      	add	w9, w9, w8
    9e08:      	stlxr	w10, w9, [x0]
    9e0c:      	cbnz	w10, 0x9e00 <generic_lsm_actions+0xc00>
    9e10:      	b	0x97d0 <generic_lsm_actions+0x5d0>
    9e14:      	ldr	w8, [sp, #0x4c]
    9e18:      	cbz	w8, 0x9e38 <generic_lsm_actions+0xc38>
    9e1c:      	adrp	x1, 0x9000 <generic_lsm_filter_arg+0x3210>
    9e20:      	mov	w8, #0x5                // =5
    9e24:      	mov	w9, #0xc                // =12
    9e28:      	ldr	x1, [x1]
    9e2c:      	ldr	x0, [sp, #0x50]
    9e30:      	mov	w2, #0x5                // =5
    9e34:      	blr	x9
    9e38:      	ldr	w8, [sp, #0x4c]
    9e3c:      	cmp	w8, #0x0
    9e40:      	cset	w20, ne
    9e44:      	b	0x92cc <generic_lsm_actions+0xcc>
    9e48:      	nop
    9e4c:      	nop

0000000000009e50 <generic_lsm_path>:
    9e50:      	sub	sp, sp, #0xe0
    9e54:      	str	x29, [sp, #0x90]
    9e58:      	stp	x30, x25, [sp, #0xa0]
    9e5c:      	stp	x24, x23, [sp, #0xb0]
    9e60:      	stp	x22, x21, [sp, #0xc0]
    9e64:      	stp	x20, x19, [sp, #0xd0]
    9e68:      	mov	x19, x0
    9e6c:      	str	wzr, [sp, #0x28]
    9e70:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9e74:      	mov	w8, #0x1                // =1
    9e78:      	ldr	x0, [x0]
    9e7c:      	add	x9, sp, #0x28
    9e80:      	add	x1, sp, #0x28
    9e84:      	blr	x8
    9e88:      	cbz	x0, 0x15cec <generic_lsm_path+0xbe9c>
    9e8c:      	mov	w8, #0x6420             // =25632
    9e90:      	add	x25, x0, x8
    9e94:      	ldr	w8, [x25]
    9e98:      	cmp	w8, #0x1
    9e9c:      	b.eq	0x9f48 <generic_lsm_path+0xf8>
    9ea0:      	cbnz	w8, 0x15cec <generic_lsm_path+0xbe9c>
    9ea4:      	mov	x20, x0
    9ea8:      	ldr	x22, [x0, #0x6440]
    9eac:      	str	wzr, [sp, #0x70]
    9eb0:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9eb4:      	mov	w8, #0x1                // =1
    9eb8:      	add	x9, sp, #0x70
    9ebc:      	ldr	x0, [x0]
    9ec0:      	add	x1, sp, #0x70
    9ec4:      	blr	x8
    9ec8:      	cbz	x0, 0x15cec <generic_lsm_path+0xbe9c>
    9ecc:      	str	x19, [sp, #0x20]
    9ed0:      	add	x2, x22, #0x8
    9ed4:      	mov	w8, #0x8                // =8
    9ed8:      	mov	w9, #0x4                // =4
    9edc:      	add	x10, sp, #0x80
    9ee0:      	mov	x21, x0
    9ee4:      	add	x29, x0, #0xfff
    9ee8:      	add	x0, sp, #0x80
    9eec:      	mov	w1, #0x8                // =8
    9ef0:      	blr	x9
    9ef4:      	adrp	x22, 0x9000 <generic_lsm_filter_arg+0x3210>
    9ef8:      	ldr	x22, [x22]
    9efc:      	cbz	x0, 0x15978 <generic_lsm_path+0xbb28>
    9f00:      	neg	w8, w0
    9f04:      	mov	w9, #0x1                // =1
    9f08:      	add	x1, sp, #0x30
    9f0c:      	strh	w8, [sp, #0x30]
    9f10:      	mov	w8, #0x6                // =6
    9f14:      	mov	x0, x22
    9f18:      	mov	w23, #0x1               // =1
    9f1c:      	strh	w8, [sp, #0x32]
    9f20:      	mov	x8, #0x2c               // =44
    9f24:      	movk	x8, #0x4, lsl #32
    9f28:      	stur	x8, [sp, #0x34]
    9f2c:      	add	x8, sp, #0x30
    9f30:      	blr	x9
    9f34:      	cbz	x0, 0x15954 <generic_lsm_path+0xbb04>
    9f38:      	ldr	w8, [x0]
    9f3c:      	add	w8, w8, #0x1
    9f40:      	str	w8, [x0]
    9f44:      	b	0x15978 <generic_lsm_path+0xbb28>
    9f48:      	ldr	x8, [x0, #0x6448]
    9f4c:      	ldr	x9, [x0, #0x6450]
    9f50:      	mov	x20, x0
    9f54:      	add	x1, sp, #0x2c
    9f58:      	str	xzr, [sp, #0x60]
    9f5c:      	str	wzr, [sp, #0x68]
    9f60:      	strb	wzr, [sp, #0x6c]
    9f64:      	str	wzr, [sp, #0x2c]
    9f68:      	stp	x8, x9, [sp, #0x30]
    9f6c:      	ldr	x8, [x0, #0x6458]
    9f70:      	ldr	x9, [x0, #0x6468]
    9f74:      	stp	xzr, x8, [sp, #0x40]
    9f78:      	ldr	x8, [x0, #0x6460]
    9f7c:      	adrp	x0, 0x9000 <generic_lsm_filter_arg+0x3210>
    9f80:      	stp	x8, x9, [sp, #0x50]
    9f84:      	mov	w8, #0x1                // =1
    9f88:      	add	x9, sp, #0x2c
    9f8c:      	ldr	x0, [x0]
    9f90:      	blr	x8
    9f94:      	cbz	x0, 0x15cec <generic_lsm_path+0xbe9c>
    9f98:      	str	x0, [sp, #0x40]
    9f9c:      	add	x10, sp, #0x30
    9fa0:      	stp	x20, x19, [sp, #0x18]
    9fa4:      	mov	w20, #0x200             // =512
    9fa8:      	mov	w29, #0x8               // =8
    9fac:      	ldr	w8, [x25, #0x4]
    9fb0:      	add	x22, x10, #0x18
    9fb4:      	add	x19, sp, #0x70
    9fb8:      	and	x9, x8, #0xfff
    9fbc:      	str	x0, [sp, #0x10]
    9fc0:      	str	w8, [sp, #0x68]
    9fc4:      	add	x9, x0, x9
    9fc8:      	str	x9, [sp, #0x60]
    9fcc:      	ldp	x21, x2, [sp, #0x48]
    9fd0:      	ldp	x8, x9, [sp, #0x30]
    9fd4:      	cmp	x21, x8
    9fd8:      	ccmp	x2, x9, #0x0, eq
    9fdc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    9fe0:      	ldr	x24, [sp, #0x58]
    9fe4:      	mov	w8, #0x4                // =4
    9fe8:      	add	x0, sp, #0x70
    9fec:      	mov	w1, #0x8                // =8
    9ff0:      	blr	x8
    9ff4:      	ldr	x8, [sp, #0x70]
    9ff8:      	cmp	x21, x8
    9ffc:      	b.eq	0xa0f8 <generic_lsm_path+0x2a8>
    a000:      	add	x23, x21, #0x18
    a004:      	mov	w8, #0x4                // =4
    a008:      	add	x9, sp, #0x98
    a00c:      	add	x0, sp, #0x98
    a010:      	mov	w1, #0x8                // =8
    a014:      	mov	x2, x23
    a018:      	blr	x8
    a01c:      	ldr	x8, [sp, #0x98]
    a020:      	cmp	x8, x21
    a024:      	b.eq	0xa0f8 <generic_lsm_path+0x2a8>
    a028:      	mov	w8, #0x4                // =4
    a02c:      	add	x9, sp, #0x78
    a030:      	add	x0, sp, #0x78
    a034:      	mov	w1, #0x8                // =8
    a038:      	mov	x2, x23
    a03c:      	blr	x8
    a040:      	add	x2, x21, #0x20
    a044:      	mov	w8, #0x4                // =4
    a048:      	mov	w9, #0x10               // =16
    a04c:      	add	x10, sp, #0x80
    a050:      	add	x0, sp, #0x80
    a054:      	mov	w1, #0x10               // =16
    a058:      	blr	x8
    a05c:      	ldr	w21, [sp, #0x84]
    a060:      	ldr	x8, [sp, #0x40]
    a064:      	ldr	x10, [sp, #0x60]
    a068:      	sub	x12, x10, x8
    a06c:      	ldr	w23, [sp, #0x68]
    a070:      	subs	w10, w21, w23
    a074:      	ldr	x9, [sp, #0x88]
    a078:      	csel	w10, wzr, w10, lo
    a07c:      	cmp	w23, w21
    a080:      	csel	w11, w23, w21, lo
    a084:      	cinc	w13, w11, hi
    a088:      	sub	w14, w23, w13
    a08c:      	subs	x12, x12, x13
    a090:      	str	w14, [sp, #0x68]
    a094:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a098:      	cmp	x12, #0xfff
    a09c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a0a0:      	cmp	w23, w21
    a0a4:      	b.ls	0xa0b0 <generic_lsm_path+0x260>
    a0a8:      	mov	w13, #0x2f              // =47
    a0ac:      	strb	w13, [x8, x12]
    a0b0:      	add	x19, x8, x12
    a0b4:      	cmp	w23, w21
    a0b8:      	add	x2, x9, x10
    a0bc:      	and	w1, w11, #0xff
    a0c0:      	mov	w8, #0x4                // =4
    a0c4:      	cinc	x0, x19, hi
    a0c8:      	blr	x8
    a0cc:      	cmp	w23, w21
    a0d0:      	str	x19, [sp, #0x60]
    a0d4:      	add	x19, sp, #0x70
    a0d8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a0dc:      	ldr	x21, [sp, #0x78]
    a0e0:      	ldp	x2, x24, [sp, #0x50]
    a0e4:      	str	x21, [sp, #0x48]
    a0e8:      	ldr	x8, [sp, #0x30]
    a0ec:      	cmp	x21, x8
    a0f0:      	b.eq	0xa150 <generic_lsm_path+0x300>
    a0f4:      	b	0xa15c <generic_lsm_path+0x30c>
    a0f8:      	add	x2, x24, #0x10
    a0fc:      	mov	w8, #0x4                // =4
    a100:      	add	x9, sp, #0x98
    a104:      	add	x0, sp, #0x98
    a108:      	mov	w1, #0x8                // =8
    a10c:      	blr	x8
    a110:      	ldr	x8, [sp, #0x58]
    a114:      	ldr	x9, [sp, #0x98]
    a118:      	cmp	x8, x9
    a11c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a120:      	add	x2, x24, #0x18
    a124:      	mov	w8, #0x4                // =4
    a128:      	mov	x0, x22
    a12c:      	mov	w1, #0x8                // =8
    a130:      	blr	x8
    a134:      	ldr	x24, [sp, #0x98]
    a138:      	ldr	x21, [sp, #0x48]
    a13c:      	add	x2, x24, #0x20
    a140:      	stp	x2, x24, [sp, #0x50]
    a144:      	ldr	x8, [sp, #0x30]
    a148:      	cmp	x21, x8
    a14c:      	b.ne	0xa15c <generic_lsm_path+0x30c>
    a150:      	ldr	x8, [sp, #0x38]
    a154:      	cmp	x2, x8
    a158:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a15c:      	mov	w8, #0x4                // =4
    a160:      	add	x0, sp, #0x70
    a164:      	mov	w1, #0x8                // =8
    a168:      	blr	x8
    a16c:      	ldr	x8, [sp, #0x70]
    a170:      	cmp	x21, x8
    a174:      	b.eq	0xa270 <generic_lsm_path+0x420>
    a178:      	add	x23, x21, #0x18
    a17c:      	mov	w8, #0x4                // =4
    a180:      	add	x9, sp, #0x98
    a184:      	add	x0, sp, #0x98
    a188:      	mov	w1, #0x8                // =8
    a18c:      	mov	x2, x23
    a190:      	blr	x8
    a194:      	ldr	x8, [sp, #0x98]
    a198:      	cmp	x8, x21
    a19c:      	b.eq	0xa270 <generic_lsm_path+0x420>
    a1a0:      	mov	w8, #0x4                // =4
    a1a4:      	add	x9, sp, #0x78
    a1a8:      	add	x0, sp, #0x78
    a1ac:      	mov	w1, #0x8                // =8
    a1b0:      	mov	x2, x23
    a1b4:      	blr	x8
    a1b8:      	add	x2, x21, #0x20
    a1bc:      	mov	w8, #0x4                // =4
    a1c0:      	mov	w9, #0x10               // =16
    a1c4:      	add	x10, sp, #0x80
    a1c8:      	add	x0, sp, #0x80
    a1cc:      	mov	w1, #0x10               // =16
    a1d0:      	blr	x8
    a1d4:      	ldr	w21, [sp, #0x84]
    a1d8:      	ldr	x8, [sp, #0x40]
    a1dc:      	ldr	x10, [sp, #0x60]
    a1e0:      	sub	x12, x10, x8
    a1e4:      	ldr	w23, [sp, #0x68]
    a1e8:      	subs	w10, w21, w23
    a1ec:      	ldr	x9, [sp, #0x88]
    a1f0:      	csel	w10, wzr, w10, lo
    a1f4:      	cmp	w23, w21
    a1f8:      	csel	w11, w23, w21, lo
    a1fc:      	cinc	w13, w11, hi
    a200:      	sub	w14, w23, w13
    a204:      	subs	x12, x12, x13
    a208:      	str	w14, [sp, #0x68]
    a20c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a210:      	cmp	x12, #0xfff
    a214:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a218:      	cmp	w23, w21
    a21c:      	b.ls	0xa228 <generic_lsm_path+0x3d8>
    a220:      	mov	w13, #0x2f              // =47
    a224:      	strb	w13, [x8, x12]
    a228:      	add	x19, x8, x12
    a22c:      	cmp	w23, w21
    a230:      	add	x2, x9, x10
    a234:      	and	w1, w11, #0xff
    a238:      	mov	w8, #0x4                // =4
    a23c:      	cinc	x0, x19, hi
    a240:      	blr	x8
    a244:      	cmp	w23, w21
    a248:      	str	x19, [sp, #0x60]
    a24c:      	add	x19, sp, #0x70
    a250:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a254:      	ldr	x21, [sp, #0x78]
    a258:      	ldp	x2, x24, [sp, #0x50]
    a25c:      	str	x21, [sp, #0x48]
    a260:      	ldr	x8, [sp, #0x30]
    a264:      	cmp	x21, x8
    a268:      	b.eq	0xa2c8 <generic_lsm_path+0x478>
    a26c:      	b	0xa2d4 <generic_lsm_path+0x484>
    a270:      	add	x2, x24, #0x10
    a274:      	mov	w8, #0x4                // =4
    a278:      	add	x9, sp, #0x98
    a27c:      	add	x0, sp, #0x98
    a280:      	mov	w1, #0x8                // =8
    a284:      	blr	x8
    a288:      	ldr	x8, [sp, #0x58]
    a28c:      	ldr	x9, [sp, #0x98]
    a290:      	cmp	x8, x9
    a294:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a298:      	add	x2, x24, #0x18
    a29c:      	mov	w8, #0x4                // =4
    a2a0:      	mov	x0, x22
    a2a4:      	mov	w1, #0x8                // =8
    a2a8:      	blr	x8
    a2ac:      	ldr	x24, [sp, #0x98]
    a2b0:      	ldr	x21, [sp, #0x48]
    a2b4:      	add	x2, x24, #0x20
    a2b8:      	stp	x2, x24, [sp, #0x50]
    a2bc:      	ldr	x8, [sp, #0x30]
    a2c0:      	cmp	x21, x8
    a2c4:      	b.ne	0xa2d4 <generic_lsm_path+0x484>
    a2c8:      	ldr	x8, [sp, #0x38]
    a2cc:      	cmp	x2, x8
    a2d0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a2d4:      	mov	w8, #0x4                // =4
    a2d8:      	add	x0, sp, #0x70
    a2dc:      	mov	w1, #0x8                // =8
    a2e0:      	blr	x8
    a2e4:      	ldr	x8, [sp, #0x70]
    a2e8:      	cmp	x21, x8
    a2ec:      	b.eq	0xa3e8 <generic_lsm_path+0x598>
    a2f0:      	add	x23, x21, #0x18
    a2f4:      	mov	w8, #0x4                // =4
    a2f8:      	add	x9, sp, #0x98
    a2fc:      	add	x0, sp, #0x98
    a300:      	mov	w1, #0x8                // =8
    a304:      	mov	x2, x23
    a308:      	blr	x8
    a30c:      	ldr	x8, [sp, #0x98]
    a310:      	cmp	x8, x21
    a314:      	b.eq	0xa3e8 <generic_lsm_path+0x598>
    a318:      	mov	w8, #0x4                // =4
    a31c:      	add	x9, sp, #0x78
    a320:      	add	x0, sp, #0x78
    a324:      	mov	w1, #0x8                // =8
    a328:      	mov	x2, x23
    a32c:      	blr	x8
    a330:      	add	x2, x21, #0x20
    a334:      	mov	w8, #0x4                // =4
    a338:      	mov	w9, #0x10               // =16
    a33c:      	add	x10, sp, #0x80
    a340:      	add	x0, sp, #0x80
    a344:      	mov	w1, #0x10               // =16
    a348:      	blr	x8
    a34c:      	ldr	w21, [sp, #0x84]
    a350:      	ldr	x8, [sp, #0x40]
    a354:      	ldr	x10, [sp, #0x60]
    a358:      	sub	x12, x10, x8
    a35c:      	ldr	w23, [sp, #0x68]
    a360:      	subs	w10, w21, w23
    a364:      	ldr	x9, [sp, #0x88]
    a368:      	csel	w10, wzr, w10, lo
    a36c:      	cmp	w23, w21
    a370:      	csel	w11, w23, w21, lo
    a374:      	cinc	w13, w11, hi
    a378:      	sub	w14, w23, w13
    a37c:      	subs	x12, x12, x13
    a380:      	str	w14, [sp, #0x68]
    a384:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a388:      	cmp	x12, #0xfff
    a38c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a390:      	cmp	w23, w21
    a394:      	b.ls	0xa3a0 <generic_lsm_path+0x550>
    a398:      	mov	w13, #0x2f              // =47
    a39c:      	strb	w13, [x8, x12]
    a3a0:      	add	x19, x8, x12
    a3a4:      	cmp	w23, w21
    a3a8:      	add	x2, x9, x10
    a3ac:      	and	w1, w11, #0xff
    a3b0:      	mov	w8, #0x4                // =4
    a3b4:      	cinc	x0, x19, hi
    a3b8:      	blr	x8
    a3bc:      	cmp	w23, w21
    a3c0:      	str	x19, [sp, #0x60]
    a3c4:      	add	x19, sp, #0x70
    a3c8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a3cc:      	ldr	x21, [sp, #0x78]
    a3d0:      	ldp	x2, x24, [sp, #0x50]
    a3d4:      	str	x21, [sp, #0x48]
    a3d8:      	ldr	x8, [sp, #0x30]
    a3dc:      	cmp	x21, x8
    a3e0:      	b.eq	0xa440 <generic_lsm_path+0x5f0>
    a3e4:      	b	0xa44c <generic_lsm_path+0x5fc>
    a3e8:      	add	x2, x24, #0x10
    a3ec:      	mov	w8, #0x4                // =4
    a3f0:      	add	x9, sp, #0x98
    a3f4:      	add	x0, sp, #0x98
    a3f8:      	mov	w1, #0x8                // =8
    a3fc:      	blr	x8
    a400:      	ldr	x8, [sp, #0x58]
    a404:      	ldr	x9, [sp, #0x98]
    a408:      	cmp	x8, x9
    a40c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a410:      	add	x2, x24, #0x18
    a414:      	mov	w8, #0x4                // =4
    a418:      	mov	x0, x22
    a41c:      	mov	w1, #0x8                // =8
    a420:      	blr	x8
    a424:      	ldr	x24, [sp, #0x98]
    a428:      	ldr	x21, [sp, #0x48]
    a42c:      	add	x2, x24, #0x20
    a430:      	stp	x2, x24, [sp, #0x50]
    a434:      	ldr	x8, [sp, #0x30]
    a438:      	cmp	x21, x8
    a43c:      	b.ne	0xa44c <generic_lsm_path+0x5fc>
    a440:      	ldr	x8, [sp, #0x38]
    a444:      	cmp	x2, x8
    a448:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a44c:      	mov	w8, #0x4                // =4
    a450:      	add	x0, sp, #0x70
    a454:      	mov	w1, #0x8                // =8
    a458:      	blr	x8
    a45c:      	ldr	x8, [sp, #0x70]
    a460:      	cmp	x21, x8
    a464:      	b.eq	0xa560 <generic_lsm_path+0x710>
    a468:      	add	x23, x21, #0x18
    a46c:      	mov	w8, #0x4                // =4
    a470:      	add	x9, sp, #0x98
    a474:      	add	x0, sp, #0x98
    a478:      	mov	w1, #0x8                // =8
    a47c:      	mov	x2, x23
    a480:      	blr	x8
    a484:      	ldr	x8, [sp, #0x98]
    a488:      	cmp	x8, x21
    a48c:      	b.eq	0xa560 <generic_lsm_path+0x710>
    a490:      	mov	w8, #0x4                // =4
    a494:      	add	x9, sp, #0x78
    a498:      	add	x0, sp, #0x78
    a49c:      	mov	w1, #0x8                // =8
    a4a0:      	mov	x2, x23
    a4a4:      	blr	x8
    a4a8:      	add	x2, x21, #0x20
    a4ac:      	mov	w8, #0x4                // =4
    a4b0:      	mov	w9, #0x10               // =16
    a4b4:      	add	x10, sp, #0x80
    a4b8:      	add	x0, sp, #0x80
    a4bc:      	mov	w1, #0x10               // =16
    a4c0:      	blr	x8
    a4c4:      	ldr	w21, [sp, #0x84]
    a4c8:      	ldr	x8, [sp, #0x40]
    a4cc:      	ldr	x10, [sp, #0x60]
    a4d0:      	sub	x12, x10, x8
    a4d4:      	ldr	w23, [sp, #0x68]
    a4d8:      	subs	w10, w21, w23
    a4dc:      	ldr	x9, [sp, #0x88]
    a4e0:      	csel	w10, wzr, w10, lo
    a4e4:      	cmp	w23, w21
    a4e8:      	csel	w11, w23, w21, lo
    a4ec:      	cinc	w13, w11, hi
    a4f0:      	sub	w14, w23, w13
    a4f4:      	subs	x12, x12, x13
    a4f8:      	str	w14, [sp, #0x68]
    a4fc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a500:      	cmp	x12, #0xfff
    a504:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a508:      	cmp	w23, w21
    a50c:      	b.ls	0xa518 <generic_lsm_path+0x6c8>
    a510:      	mov	w13, #0x2f              // =47
    a514:      	strb	w13, [x8, x12]
    a518:      	add	x19, x8, x12
    a51c:      	cmp	w23, w21
    a520:      	add	x2, x9, x10
    a524:      	and	w1, w11, #0xff
    a528:      	mov	w8, #0x4                // =4
    a52c:      	cinc	x0, x19, hi
    a530:      	blr	x8
    a534:      	cmp	w23, w21
    a538:      	str	x19, [sp, #0x60]
    a53c:      	add	x19, sp, #0x70
    a540:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a544:      	ldr	x21, [sp, #0x78]
    a548:      	ldp	x2, x24, [sp, #0x50]
    a54c:      	str	x21, [sp, #0x48]
    a550:      	ldr	x8, [sp, #0x30]
    a554:      	cmp	x21, x8
    a558:      	b.eq	0xa5b8 <generic_lsm_path+0x768>
    a55c:      	b	0xa5c4 <generic_lsm_path+0x774>
    a560:      	add	x2, x24, #0x10
    a564:      	mov	w8, #0x4                // =4
    a568:      	add	x9, sp, #0x98
    a56c:      	add	x0, sp, #0x98
    a570:      	mov	w1, #0x8                // =8
    a574:      	blr	x8
    a578:      	ldr	x8, [sp, #0x58]
    a57c:      	ldr	x9, [sp, #0x98]
    a580:      	cmp	x8, x9
    a584:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a588:      	add	x2, x24, #0x18
    a58c:      	mov	w8, #0x4                // =4
    a590:      	mov	x0, x22
    a594:      	mov	w1, #0x8                // =8
    a598:      	blr	x8
    a59c:      	ldr	x24, [sp, #0x98]
    a5a0:      	ldr	x21, [sp, #0x48]
    a5a4:      	add	x2, x24, #0x20
    a5a8:      	stp	x2, x24, [sp, #0x50]
    a5ac:      	ldr	x8, [sp, #0x30]
    a5b0:      	cmp	x21, x8
    a5b4:      	b.ne	0xa5c4 <generic_lsm_path+0x774>
    a5b8:      	ldr	x8, [sp, #0x38]
    a5bc:      	cmp	x2, x8
    a5c0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a5c4:      	mov	w8, #0x4                // =4
    a5c8:      	add	x0, sp, #0x70
    a5cc:      	mov	w1, #0x8                // =8
    a5d0:      	blr	x8
    a5d4:      	ldr	x8, [sp, #0x70]
    a5d8:      	cmp	x21, x8
    a5dc:      	b.eq	0xa6d8 <generic_lsm_path+0x888>
    a5e0:      	add	x23, x21, #0x18
    a5e4:      	mov	w8, #0x4                // =4
    a5e8:      	add	x9, sp, #0x98
    a5ec:      	add	x0, sp, #0x98
    a5f0:      	mov	w1, #0x8                // =8
    a5f4:      	mov	x2, x23
    a5f8:      	blr	x8
    a5fc:      	ldr	x8, [sp, #0x98]
    a600:      	cmp	x8, x21
    a604:      	b.eq	0xa6d8 <generic_lsm_path+0x888>
    a608:      	mov	w8, #0x4                // =4
    a60c:      	add	x9, sp, #0x78
    a610:      	add	x0, sp, #0x78
    a614:      	mov	w1, #0x8                // =8
    a618:      	mov	x2, x23
    a61c:      	blr	x8
    a620:      	add	x2, x21, #0x20
    a624:      	mov	w8, #0x4                // =4
    a628:      	mov	w9, #0x10               // =16
    a62c:      	add	x10, sp, #0x80
    a630:      	add	x0, sp, #0x80
    a634:      	mov	w1, #0x10               // =16
    a638:      	blr	x8
    a63c:      	ldr	w21, [sp, #0x84]
    a640:      	ldr	x8, [sp, #0x40]
    a644:      	ldr	x10, [sp, #0x60]
    a648:      	sub	x12, x10, x8
    a64c:      	ldr	w23, [sp, #0x68]
    a650:      	subs	w10, w21, w23
    a654:      	ldr	x9, [sp, #0x88]
    a658:      	csel	w10, wzr, w10, lo
    a65c:      	cmp	w23, w21
    a660:      	csel	w11, w23, w21, lo
    a664:      	cinc	w13, w11, hi
    a668:      	sub	w14, w23, w13
    a66c:      	subs	x12, x12, x13
    a670:      	str	w14, [sp, #0x68]
    a674:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a678:      	cmp	x12, #0xfff
    a67c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a680:      	cmp	w23, w21
    a684:      	b.ls	0xa690 <generic_lsm_path+0x840>
    a688:      	mov	w13, #0x2f              // =47
    a68c:      	strb	w13, [x8, x12]
    a690:      	add	x19, x8, x12
    a694:      	cmp	w23, w21
    a698:      	add	x2, x9, x10
    a69c:      	and	w1, w11, #0xff
    a6a0:      	mov	w8, #0x4                // =4
    a6a4:      	cinc	x0, x19, hi
    a6a8:      	blr	x8
    a6ac:      	cmp	w23, w21
    a6b0:      	str	x19, [sp, #0x60]
    a6b4:      	add	x19, sp, #0x70
    a6b8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a6bc:      	ldr	x21, [sp, #0x78]
    a6c0:      	ldp	x2, x24, [sp, #0x50]
    a6c4:      	str	x21, [sp, #0x48]
    a6c8:      	ldr	x8, [sp, #0x30]
    a6cc:      	cmp	x21, x8
    a6d0:      	b.eq	0xa730 <generic_lsm_path+0x8e0>
    a6d4:      	b	0xa73c <generic_lsm_path+0x8ec>
    a6d8:      	add	x2, x24, #0x10
    a6dc:      	mov	w8, #0x4                // =4
    a6e0:      	add	x9, sp, #0x98
    a6e4:      	add	x0, sp, #0x98
    a6e8:      	mov	w1, #0x8                // =8
    a6ec:      	blr	x8
    a6f0:      	ldr	x8, [sp, #0x58]
    a6f4:      	ldr	x9, [sp, #0x98]
    a6f8:      	cmp	x8, x9
    a6fc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a700:      	add	x2, x24, #0x18
    a704:      	mov	w8, #0x4                // =4
    a708:      	mov	x0, x22
    a70c:      	mov	w1, #0x8                // =8
    a710:      	blr	x8
    a714:      	ldr	x24, [sp, #0x98]
    a718:      	ldr	x21, [sp, #0x48]
    a71c:      	add	x2, x24, #0x20
    a720:      	stp	x2, x24, [sp, #0x50]
    a724:      	ldr	x8, [sp, #0x30]
    a728:      	cmp	x21, x8
    a72c:      	b.ne	0xa73c <generic_lsm_path+0x8ec>
    a730:      	ldr	x8, [sp, #0x38]
    a734:      	cmp	x2, x8
    a738:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a73c:      	mov	w8, #0x4                // =4
    a740:      	add	x0, sp, #0x70
    a744:      	mov	w1, #0x8                // =8
    a748:      	blr	x8
    a74c:      	ldr	x8, [sp, #0x70]
    a750:      	cmp	x21, x8
    a754:      	b.eq	0xa850 <generic_lsm_path+0xa00>
    a758:      	add	x23, x21, #0x18
    a75c:      	mov	w8, #0x4                // =4
    a760:      	add	x9, sp, #0x98
    a764:      	add	x0, sp, #0x98
    a768:      	mov	w1, #0x8                // =8
    a76c:      	mov	x2, x23
    a770:      	blr	x8
    a774:      	ldr	x8, [sp, #0x98]
    a778:      	cmp	x8, x21
    a77c:      	b.eq	0xa850 <generic_lsm_path+0xa00>
    a780:      	mov	w8, #0x4                // =4
    a784:      	add	x9, sp, #0x78
    a788:      	add	x0, sp, #0x78
    a78c:      	mov	w1, #0x8                // =8
    a790:      	mov	x2, x23
    a794:      	blr	x8
    a798:      	add	x2, x21, #0x20
    a79c:      	mov	w8, #0x4                // =4
    a7a0:      	mov	w9, #0x10               // =16
    a7a4:      	add	x10, sp, #0x80
    a7a8:      	add	x0, sp, #0x80
    a7ac:      	mov	w1, #0x10               // =16
    a7b0:      	blr	x8
    a7b4:      	ldr	w21, [sp, #0x84]
    a7b8:      	ldr	x8, [sp, #0x40]
    a7bc:      	ldr	x10, [sp, #0x60]
    a7c0:      	sub	x12, x10, x8
    a7c4:      	ldr	w23, [sp, #0x68]
    a7c8:      	subs	w10, w21, w23
    a7cc:      	ldr	x9, [sp, #0x88]
    a7d0:      	csel	w10, wzr, w10, lo
    a7d4:      	cmp	w23, w21
    a7d8:      	csel	w11, w23, w21, lo
    a7dc:      	cinc	w13, w11, hi
    a7e0:      	sub	w14, w23, w13
    a7e4:      	subs	x12, x12, x13
    a7e8:      	str	w14, [sp, #0x68]
    a7ec:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a7f0:      	cmp	x12, #0xfff
    a7f4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a7f8:      	cmp	w23, w21
    a7fc:      	b.ls	0xa808 <generic_lsm_path+0x9b8>
    a800:      	mov	w13, #0x2f              // =47
    a804:      	strb	w13, [x8, x12]
    a808:      	add	x19, x8, x12
    a80c:      	cmp	w23, w21
    a810:      	add	x2, x9, x10
    a814:      	and	w1, w11, #0xff
    a818:      	mov	w8, #0x4                // =4
    a81c:      	cinc	x0, x19, hi
    a820:      	blr	x8
    a824:      	cmp	w23, w21
    a828:      	str	x19, [sp, #0x60]
    a82c:      	add	x19, sp, #0x70
    a830:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a834:      	ldr	x21, [sp, #0x78]
    a838:      	ldp	x2, x24, [sp, #0x50]
    a83c:      	str	x21, [sp, #0x48]
    a840:      	ldr	x8, [sp, #0x30]
    a844:      	cmp	x21, x8
    a848:      	b.eq	0xa8a8 <generic_lsm_path+0xa58>
    a84c:      	b	0xa8b4 <generic_lsm_path+0xa64>
    a850:      	add	x2, x24, #0x10
    a854:      	mov	w8, #0x4                // =4
    a858:      	add	x9, sp, #0x98
    a85c:      	add	x0, sp, #0x98
    a860:      	mov	w1, #0x8                // =8
    a864:      	blr	x8
    a868:      	ldr	x8, [sp, #0x58]
    a86c:      	ldr	x9, [sp, #0x98]
    a870:      	cmp	x8, x9
    a874:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a878:      	add	x2, x24, #0x18
    a87c:      	mov	w8, #0x4                // =4
    a880:      	mov	x0, x22
    a884:      	mov	w1, #0x8                // =8
    a888:      	blr	x8
    a88c:      	ldr	x24, [sp, #0x98]
    a890:      	ldr	x21, [sp, #0x48]
    a894:      	add	x2, x24, #0x20
    a898:      	stp	x2, x24, [sp, #0x50]
    a89c:      	ldr	x8, [sp, #0x30]
    a8a0:      	cmp	x21, x8
    a8a4:      	b.ne	0xa8b4 <generic_lsm_path+0xa64>
    a8a8:      	ldr	x8, [sp, #0x38]
    a8ac:      	cmp	x2, x8
    a8b0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a8b4:      	mov	w8, #0x4                // =4
    a8b8:      	add	x0, sp, #0x70
    a8bc:      	mov	w1, #0x8                // =8
    a8c0:      	blr	x8
    a8c4:      	ldr	x8, [sp, #0x70]
    a8c8:      	cmp	x21, x8
    a8cc:      	b.eq	0xa9c8 <generic_lsm_path+0xb78>
    a8d0:      	add	x23, x21, #0x18
    a8d4:      	mov	w8, #0x4                // =4
    a8d8:      	add	x9, sp, #0x98
    a8dc:      	add	x0, sp, #0x98
    a8e0:      	mov	w1, #0x8                // =8
    a8e4:      	mov	x2, x23
    a8e8:      	blr	x8
    a8ec:      	ldr	x8, [sp, #0x98]
    a8f0:      	cmp	x8, x21
    a8f4:      	b.eq	0xa9c8 <generic_lsm_path+0xb78>
    a8f8:      	mov	w8, #0x4                // =4
    a8fc:      	add	x9, sp, #0x78
    a900:      	add	x0, sp, #0x78
    a904:      	mov	w1, #0x8                // =8
    a908:      	mov	x2, x23
    a90c:      	blr	x8
    a910:      	add	x2, x21, #0x20
    a914:      	mov	w8, #0x4                // =4
    a918:      	mov	w9, #0x10               // =16
    a91c:      	add	x10, sp, #0x80
    a920:      	add	x0, sp, #0x80
    a924:      	mov	w1, #0x10               // =16
    a928:      	blr	x8
    a92c:      	ldr	w21, [sp, #0x84]
    a930:      	ldr	x8, [sp, #0x40]
    a934:      	ldr	x10, [sp, #0x60]
    a938:      	sub	x12, x10, x8
    a93c:      	ldr	w23, [sp, #0x68]
    a940:      	subs	w10, w21, w23
    a944:      	ldr	x9, [sp, #0x88]
    a948:      	csel	w10, wzr, w10, lo
    a94c:      	cmp	w23, w21
    a950:      	csel	w11, w23, w21, lo
    a954:      	cinc	w13, w11, hi
    a958:      	sub	w14, w23, w13
    a95c:      	subs	x12, x12, x13
    a960:      	str	w14, [sp, #0x68]
    a964:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    a968:      	cmp	x12, #0xfff
    a96c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    a970:      	cmp	w23, w21
    a974:      	b.ls	0xa980 <generic_lsm_path+0xb30>
    a978:      	mov	w13, #0x2f              // =47
    a97c:      	strb	w13, [x8, x12]
    a980:      	add	x19, x8, x12
    a984:      	cmp	w23, w21
    a988:      	add	x2, x9, x10
    a98c:      	and	w1, w11, #0xff
    a990:      	mov	w8, #0x4                // =4
    a994:      	cinc	x0, x19, hi
    a998:      	blr	x8
    a99c:      	cmp	w23, w21
    a9a0:      	str	x19, [sp, #0x60]
    a9a4:      	add	x19, sp, #0x70
    a9a8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    a9ac:      	ldr	x21, [sp, #0x78]
    a9b0:      	ldp	x2, x24, [sp, #0x50]
    a9b4:      	str	x21, [sp, #0x48]
    a9b8:      	ldr	x8, [sp, #0x30]
    a9bc:      	cmp	x21, x8
    a9c0:      	b.eq	0xaa20 <generic_lsm_path+0xbd0>
    a9c4:      	b	0xaa2c <generic_lsm_path+0xbdc>
    a9c8:      	add	x2, x24, #0x10
    a9cc:      	mov	w8, #0x4                // =4
    a9d0:      	add	x9, sp, #0x98
    a9d4:      	add	x0, sp, #0x98
    a9d8:      	mov	w1, #0x8                // =8
    a9dc:      	blr	x8
    a9e0:      	ldr	x8, [sp, #0x58]
    a9e4:      	ldr	x9, [sp, #0x98]
    a9e8:      	cmp	x8, x9
    a9ec:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    a9f0:      	add	x2, x24, #0x18
    a9f4:      	mov	w8, #0x4                // =4
    a9f8:      	mov	x0, x22
    a9fc:      	mov	w1, #0x8                // =8
    aa00:      	blr	x8
    aa04:      	ldr	x24, [sp, #0x98]
    aa08:      	ldr	x21, [sp, #0x48]
    aa0c:      	add	x2, x24, #0x20
    aa10:      	stp	x2, x24, [sp, #0x50]
    aa14:      	ldr	x8, [sp, #0x30]
    aa18:      	cmp	x21, x8
    aa1c:      	b.ne	0xaa2c <generic_lsm_path+0xbdc>
    aa20:      	ldr	x8, [sp, #0x38]
    aa24:      	cmp	x2, x8
    aa28:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    aa2c:      	mov	w8, #0x4                // =4
    aa30:      	add	x0, sp, #0x70
    aa34:      	mov	w1, #0x8                // =8
    aa38:      	blr	x8
    aa3c:      	ldr	x8, [sp, #0x70]
    aa40:      	cmp	x21, x8
    aa44:      	b.eq	0xab40 <generic_lsm_path+0xcf0>
    aa48:      	add	x23, x21, #0x18
    aa4c:      	mov	w8, #0x4                // =4
    aa50:      	add	x9, sp, #0x98
    aa54:      	add	x0, sp, #0x98
    aa58:      	mov	w1, #0x8                // =8
    aa5c:      	mov	x2, x23
    aa60:      	blr	x8
    aa64:      	ldr	x8, [sp, #0x98]
    aa68:      	cmp	x8, x21
    aa6c:      	b.eq	0xab40 <generic_lsm_path+0xcf0>
    aa70:      	mov	w8, #0x4                // =4
    aa74:      	add	x9, sp, #0x78
    aa78:      	add	x0, sp, #0x78
    aa7c:      	mov	w1, #0x8                // =8
    aa80:      	mov	x2, x23
    aa84:      	blr	x8
    aa88:      	add	x2, x21, #0x20
    aa8c:      	mov	w8, #0x4                // =4
    aa90:      	mov	w9, #0x10               // =16
    aa94:      	add	x10, sp, #0x80
    aa98:      	add	x0, sp, #0x80
    aa9c:      	mov	w1, #0x10               // =16
    aaa0:      	blr	x8
    aaa4:      	ldr	w21, [sp, #0x84]
    aaa8:      	ldr	x8, [sp, #0x40]
    aaac:      	ldr	x10, [sp, #0x60]
    aab0:      	sub	x12, x10, x8
    aab4:      	ldr	w23, [sp, #0x68]
    aab8:      	subs	w10, w21, w23
    aabc:      	ldr	x9, [sp, #0x88]
    aac0:      	csel	w10, wzr, w10, lo
    aac4:      	cmp	w23, w21
    aac8:      	csel	w11, w23, w21, lo
    aacc:      	cinc	w13, w11, hi
    aad0:      	sub	w14, w23, w13
    aad4:      	subs	x12, x12, x13
    aad8:      	str	w14, [sp, #0x68]
    aadc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    aae0:      	cmp	x12, #0xfff
    aae4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    aae8:      	cmp	w23, w21
    aaec:      	b.ls	0xaaf8 <generic_lsm_path+0xca8>
    aaf0:      	mov	w13, #0x2f              // =47
    aaf4:      	strb	w13, [x8, x12]
    aaf8:      	add	x19, x8, x12
    aafc:      	cmp	w23, w21
    ab00:      	add	x2, x9, x10
    ab04:      	and	w1, w11, #0xff
    ab08:      	mov	w8, #0x4                // =4
    ab0c:      	cinc	x0, x19, hi
    ab10:      	blr	x8
    ab14:      	cmp	w23, w21
    ab18:      	str	x19, [sp, #0x60]
    ab1c:      	add	x19, sp, #0x70
    ab20:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ab24:      	ldr	x21, [sp, #0x78]
    ab28:      	ldp	x2, x24, [sp, #0x50]
    ab2c:      	str	x21, [sp, #0x48]
    ab30:      	ldr	x8, [sp, #0x30]
    ab34:      	cmp	x21, x8
    ab38:      	b.eq	0xab98 <generic_lsm_path+0xd48>
    ab3c:      	b	0xaba4 <generic_lsm_path+0xd54>
    ab40:      	add	x2, x24, #0x10
    ab44:      	mov	w8, #0x4                // =4
    ab48:      	add	x9, sp, #0x98
    ab4c:      	add	x0, sp, #0x98
    ab50:      	mov	w1, #0x8                // =8
    ab54:      	blr	x8
    ab58:      	ldr	x8, [sp, #0x58]
    ab5c:      	ldr	x9, [sp, #0x98]
    ab60:      	cmp	x8, x9
    ab64:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ab68:      	add	x2, x24, #0x18
    ab6c:      	mov	w8, #0x4                // =4
    ab70:      	mov	x0, x22
    ab74:      	mov	w1, #0x8                // =8
    ab78:      	blr	x8
    ab7c:      	ldr	x24, [sp, #0x98]
    ab80:      	ldr	x21, [sp, #0x48]
    ab84:      	add	x2, x24, #0x20
    ab88:      	stp	x2, x24, [sp, #0x50]
    ab8c:      	ldr	x8, [sp, #0x30]
    ab90:      	cmp	x21, x8
    ab94:      	b.ne	0xaba4 <generic_lsm_path+0xd54>
    ab98:      	ldr	x8, [sp, #0x38]
    ab9c:      	cmp	x2, x8
    aba0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    aba4:      	mov	w8, #0x4                // =4
    aba8:      	add	x0, sp, #0x70
    abac:      	mov	w1, #0x8                // =8
    abb0:      	blr	x8
    abb4:      	ldr	x8, [sp, #0x70]
    abb8:      	cmp	x21, x8
    abbc:      	b.eq	0xacb8 <generic_lsm_path+0xe68>
    abc0:      	add	x23, x21, #0x18
    abc4:      	mov	w8, #0x4                // =4
    abc8:      	add	x9, sp, #0x98
    abcc:      	add	x0, sp, #0x98
    abd0:      	mov	w1, #0x8                // =8
    abd4:      	mov	x2, x23
    abd8:      	blr	x8
    abdc:      	ldr	x8, [sp, #0x98]
    abe0:      	cmp	x8, x21
    abe4:      	b.eq	0xacb8 <generic_lsm_path+0xe68>
    abe8:      	mov	w8, #0x4                // =4
    abec:      	add	x9, sp, #0x78
    abf0:      	add	x0, sp, #0x78
    abf4:      	mov	w1, #0x8                // =8
    abf8:      	mov	x2, x23
    abfc:      	blr	x8
    ac00:      	add	x2, x21, #0x20
    ac04:      	mov	w8, #0x4                // =4
    ac08:      	mov	w9, #0x10               // =16
    ac0c:      	add	x10, sp, #0x80
    ac10:      	add	x0, sp, #0x80
    ac14:      	mov	w1, #0x10               // =16
    ac18:      	blr	x8
    ac1c:      	ldr	w21, [sp, #0x84]
    ac20:      	ldr	x8, [sp, #0x40]
    ac24:      	ldr	x10, [sp, #0x60]
    ac28:      	sub	x12, x10, x8
    ac2c:      	ldr	w23, [sp, #0x68]
    ac30:      	subs	w10, w21, w23
    ac34:      	ldr	x9, [sp, #0x88]
    ac38:      	csel	w10, wzr, w10, lo
    ac3c:      	cmp	w23, w21
    ac40:      	csel	w11, w23, w21, lo
    ac44:      	cinc	w13, w11, hi
    ac48:      	sub	w14, w23, w13
    ac4c:      	subs	x12, x12, x13
    ac50:      	str	w14, [sp, #0x68]
    ac54:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    ac58:      	cmp	x12, #0xfff
    ac5c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    ac60:      	cmp	w23, w21
    ac64:      	b.ls	0xac70 <generic_lsm_path+0xe20>
    ac68:      	mov	w13, #0x2f              // =47
    ac6c:      	strb	w13, [x8, x12]
    ac70:      	add	x19, x8, x12
    ac74:      	cmp	w23, w21
    ac78:      	add	x2, x9, x10
    ac7c:      	and	w1, w11, #0xff
    ac80:      	mov	w8, #0x4                // =4
    ac84:      	cinc	x0, x19, hi
    ac88:      	blr	x8
    ac8c:      	cmp	w23, w21
    ac90:      	str	x19, [sp, #0x60]
    ac94:      	add	x19, sp, #0x70
    ac98:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ac9c:      	ldr	x21, [sp, #0x78]
    aca0:      	ldp	x2, x24, [sp, #0x50]
    aca4:      	str	x21, [sp, #0x48]
    aca8:      	ldr	x8, [sp, #0x30]
    acac:      	cmp	x21, x8
    acb0:      	b.eq	0xad10 <generic_lsm_path+0xec0>
    acb4:      	b	0xad1c <generic_lsm_path+0xecc>
    acb8:      	add	x2, x24, #0x10
    acbc:      	mov	w8, #0x4                // =4
    acc0:      	add	x9, sp, #0x98
    acc4:      	add	x0, sp, #0x98
    acc8:      	mov	w1, #0x8                // =8
    accc:      	blr	x8
    acd0:      	ldr	x8, [sp, #0x58]
    acd4:      	ldr	x9, [sp, #0x98]
    acd8:      	cmp	x8, x9
    acdc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ace0:      	add	x2, x24, #0x18
    ace4:      	mov	w8, #0x4                // =4
    ace8:      	mov	x0, x22
    acec:      	mov	w1, #0x8                // =8
    acf0:      	blr	x8
    acf4:      	ldr	x24, [sp, #0x98]
    acf8:      	ldr	x21, [sp, #0x48]
    acfc:      	add	x2, x24, #0x20
    ad00:      	stp	x2, x24, [sp, #0x50]
    ad04:      	ldr	x8, [sp, #0x30]
    ad08:      	cmp	x21, x8
    ad0c:      	b.ne	0xad1c <generic_lsm_path+0xecc>
    ad10:      	ldr	x8, [sp, #0x38]
    ad14:      	cmp	x2, x8
    ad18:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ad1c:      	mov	w8, #0x4                // =4
    ad20:      	add	x0, sp, #0x70
    ad24:      	mov	w1, #0x8                // =8
    ad28:      	blr	x8
    ad2c:      	ldr	x8, [sp, #0x70]
    ad30:      	cmp	x21, x8
    ad34:      	b.eq	0xae24 <generic_lsm_path+0xfd4>
    ad38:      	add	x23, x21, #0x18
    ad3c:      	mov	w8, #0x4                // =4
    ad40:      	add	x9, sp, #0x98
    ad44:      	add	x0, sp, #0x98
    ad48:      	mov	w1, #0x8                // =8
    ad4c:      	mov	x2, x23
    ad50:      	blr	x8
    ad54:      	ldr	x8, [sp, #0x98]
    ad58:      	cmp	x8, x21
    ad5c:      	b.eq	0xae24 <generic_lsm_path+0xfd4>
    ad60:      	mov	w8, #0x4                // =4
    ad64:      	add	x9, sp, #0x78
    ad68:      	add	x0, sp, #0x78
    ad6c:      	mov	w1, #0x8                // =8
    ad70:      	mov	x2, x23
    ad74:      	blr	x8
    ad78:      	add	x2, x21, #0x20
    ad7c:      	mov	w8, #0x4                // =4
    ad80:      	mov	w9, #0x10               // =16
    ad84:      	add	x10, sp, #0x80
    ad88:      	add	x0, sp, #0x80
    ad8c:      	mov	w1, #0x10               // =16
    ad90:      	blr	x8
    ad94:      	ldr	w21, [sp, #0x84]
    ad98:      	ldr	x8, [sp, #0x40]
    ad9c:      	ldr	x10, [sp, #0x60]
    ada0:      	sub	x12, x10, x8
    ada4:      	ldr	w23, [sp, #0x68]
    ada8:      	subs	w10, w21, w23
    adac:      	ldr	x9, [sp, #0x88]
    adb0:      	csel	w10, wzr, w10, lo
    adb4:      	cmp	w23, w21
    adb8:      	csel	w11, w23, w21, lo
    adbc:      	cinc	w13, w11, hi
    adc0:      	sub	w14, w23, w13
    adc4:      	subs	x12, x12, x13
    adc8:      	str	w14, [sp, #0x68]
    adcc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    add0:      	cmp	x12, #0xfff
    add4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    add8:      	cmp	w23, w21
    addc:      	b.ls	0xade8 <generic_lsm_path+0xf98>
    ade0:      	mov	w13, #0x2f              // =47
    ade4:      	strb	w13, [x8, x12]
    ade8:      	add	x19, x8, x12
    adec:      	cmp	w23, w21
    adf0:      	add	x2, x9, x10
    adf4:      	and	w1, w11, #0xff
    adf8:      	mov	w8, #0x4                // =4
    adfc:      	cinc	x0, x19, hi
    ae00:      	blr	x8
    ae04:      	cmp	w23, w21
    ae08:      	str	x19, [sp, #0x60]
    ae0c:      	add	x19, sp, #0x70
    ae10:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ae14:      	ldr	x21, [sp, #0x78]
    ae18:      	ldp	x2, x24, [sp, #0x50]
    ae1c:      	str	x21, [sp, #0x48]
    ae20:      	b	0xae70 <generic_lsm_path+0x1020>
    ae24:      	add	x2, x24, #0x10
    ae28:      	mov	w8, #0x4                // =4
    ae2c:      	add	x9, sp, #0x98
    ae30:      	add	x0, sp, #0x98
    ae34:      	mov	w1, #0x8                // =8
    ae38:      	blr	x8
    ae3c:      	ldr	x8, [sp, #0x58]
    ae40:      	ldr	x9, [sp, #0x98]
    ae44:      	cmp	x8, x9
    ae48:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ae4c:      	add	x2, x24, #0x18
    ae50:      	mov	w8, #0x4                // =4
    ae54:      	mov	x0, x22
    ae58:      	mov	w1, #0x8                // =8
    ae5c:      	blr	x8
    ae60:      	ldr	x24, [sp, #0x98]
    ae64:      	ldr	x21, [sp, #0x48]
    ae68:      	add	x2, x24, #0x20
    ae6c:      	stp	x2, x24, [sp, #0x50]
    ae70:      	ldr	x8, [sp, #0x30]
    ae74:      	cmp	x21, x8
    ae78:      	b.ne	0xae88 <generic_lsm_path+0x1038>
    ae7c:      	ldr	x8, [sp, #0x38]
    ae80:      	cmp	x2, x8
    ae84:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ae88:      	mov	w8, #0x4                // =4
    ae8c:      	add	x0, sp, #0x70
    ae90:      	mov	w1, #0x8                // =8
    ae94:      	blr	x8
    ae98:      	ldr	x8, [sp, #0x70]
    ae9c:      	cmp	x21, x8
    aea0:      	b.eq	0xaf90 <generic_lsm_path+0x1140>
    aea4:      	add	x23, x21, #0x18
    aea8:      	mov	w8, #0x4                // =4
    aeac:      	add	x9, sp, #0x98
    aeb0:      	add	x0, sp, #0x98
    aeb4:      	mov	w1, #0x8                // =8
    aeb8:      	mov	x2, x23
    aebc:      	blr	x8
    aec0:      	ldr	x8, [sp, #0x98]
    aec4:      	cmp	x8, x21
    aec8:      	b.eq	0xaf90 <generic_lsm_path+0x1140>
    aecc:      	mov	w8, #0x4                // =4
    aed0:      	add	x9, sp, #0x78
    aed4:      	add	x0, sp, #0x78
    aed8:      	mov	w1, #0x8                // =8
    aedc:      	mov	x2, x23
    aee0:      	blr	x8
    aee4:      	add	x2, x21, #0x20
    aee8:      	mov	w8, #0x4                // =4
    aeec:      	mov	w9, #0x10               // =16
    aef0:      	add	x10, sp, #0x80
    aef4:      	add	x0, sp, #0x80
    aef8:      	mov	w1, #0x10               // =16
    aefc:      	blr	x8
    af00:      	ldr	w21, [sp, #0x84]
    af04:      	ldr	x8, [sp, #0x40]
    af08:      	ldr	x10, [sp, #0x60]
    af0c:      	sub	x12, x10, x8
    af10:      	ldr	w23, [sp, #0x68]
    af14:      	subs	w10, w21, w23
    af18:      	ldr	x9, [sp, #0x88]
    af1c:      	csel	w10, wzr, w10, lo
    af20:      	cmp	w23, w21
    af24:      	csel	w11, w23, w21, lo
    af28:      	cinc	w13, w11, hi
    af2c:      	sub	w14, w23, w13
    af30:      	subs	x12, x12, x13
    af34:      	str	w14, [sp, #0x68]
    af38:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    af3c:      	cmp	x12, #0xfff
    af40:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    af44:      	cmp	w23, w21
    af48:      	b.ls	0xaf54 <generic_lsm_path+0x1104>
    af4c:      	mov	w13, #0x2f              // =47
    af50:      	strb	w13, [x8, x12]
    af54:      	add	x19, x8, x12
    af58:      	cmp	w23, w21
    af5c:      	add	x2, x9, x10
    af60:      	and	w1, w11, #0xff
    af64:      	mov	w8, #0x4                // =4
    af68:      	cinc	x0, x19, hi
    af6c:      	blr	x8
    af70:      	cmp	w23, w21
    af74:      	str	x19, [sp, #0x60]
    af78:      	add	x19, sp, #0x70
    af7c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    af80:      	ldr	x21, [sp, #0x78]
    af84:      	ldp	x2, x24, [sp, #0x50]
    af88:      	str	x21, [sp, #0x48]
    af8c:      	b	0xafdc <generic_lsm_path+0x118c>
    af90:      	add	x2, x24, #0x10
    af94:      	mov	w8, #0x4                // =4
    af98:      	add	x9, sp, #0x98
    af9c:      	add	x0, sp, #0x98
    afa0:      	mov	w1, #0x8                // =8
    afa4:      	blr	x8
    afa8:      	ldr	x8, [sp, #0x58]
    afac:      	ldr	x9, [sp, #0x98]
    afb0:      	cmp	x8, x9
    afb4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    afb8:      	add	x2, x24, #0x18
    afbc:      	mov	w8, #0x4                // =4
    afc0:      	mov	x0, x22
    afc4:      	mov	w1, #0x8                // =8
    afc8:      	blr	x8
    afcc:      	ldr	x24, [sp, #0x98]
    afd0:      	ldr	x21, [sp, #0x48]
    afd4:      	add	x2, x24, #0x20
    afd8:      	stp	x2, x24, [sp, #0x50]
    afdc:      	ldr	x8, [sp, #0x30]
    afe0:      	cmp	x21, x8
    afe4:      	b.ne	0xaff4 <generic_lsm_path+0x11a4>
    afe8:      	ldr	x8, [sp, #0x38]
    afec:      	cmp	x2, x8
    aff0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    aff4:      	mov	w8, #0x4                // =4
    aff8:      	add	x0, sp, #0x70
    affc:      	mov	w1, #0x8                // =8
    b000:      	blr	x8
    b004:      	ldr	x8, [sp, #0x70]
    b008:      	cmp	x21, x8
    b00c:      	b.eq	0xb0fc <generic_lsm_path+0x12ac>
    b010:      	add	x23, x21, #0x18
    b014:      	mov	w8, #0x4                // =4
    b018:      	add	x9, sp, #0x98
    b01c:      	add	x0, sp, #0x98
    b020:      	mov	w1, #0x8                // =8
    b024:      	mov	x2, x23
    b028:      	blr	x8
    b02c:      	ldr	x8, [sp, #0x98]
    b030:      	cmp	x8, x21
    b034:      	b.eq	0xb0fc <generic_lsm_path+0x12ac>
    b038:      	mov	w8, #0x4                // =4
    b03c:      	add	x9, sp, #0x78
    b040:      	add	x0, sp, #0x78
    b044:      	mov	w1, #0x8                // =8
    b048:      	mov	x2, x23
    b04c:      	blr	x8
    b050:      	add	x2, x21, #0x20
    b054:      	mov	w8, #0x4                // =4
    b058:      	mov	w9, #0x10               // =16
    b05c:      	add	x10, sp, #0x80
    b060:      	add	x0, sp, #0x80
    b064:      	mov	w1, #0x10               // =16
    b068:      	blr	x8
    b06c:      	ldr	w21, [sp, #0x84]
    b070:      	ldr	x8, [sp, #0x40]
    b074:      	ldr	x10, [sp, #0x60]
    b078:      	sub	x12, x10, x8
    b07c:      	ldr	w23, [sp, #0x68]
    b080:      	subs	w10, w21, w23
    b084:      	ldr	x9, [sp, #0x88]
    b088:      	csel	w10, wzr, w10, lo
    b08c:      	cmp	w23, w21
    b090:      	csel	w11, w23, w21, lo
    b094:      	cinc	w13, w11, hi
    b098:      	sub	w14, w23, w13
    b09c:      	subs	x12, x12, x13
    b0a0:      	str	w14, [sp, #0x68]
    b0a4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b0a8:      	cmp	x12, #0xfff
    b0ac:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b0b0:      	cmp	w23, w21
    b0b4:      	b.ls	0xb0c0 <generic_lsm_path+0x1270>
    b0b8:      	mov	w13, #0x2f              // =47
    b0bc:      	strb	w13, [x8, x12]
    b0c0:      	add	x19, x8, x12
    b0c4:      	cmp	w23, w21
    b0c8:      	add	x2, x9, x10
    b0cc:      	and	w1, w11, #0xff
    b0d0:      	mov	w8, #0x4                // =4
    b0d4:      	cinc	x0, x19, hi
    b0d8:      	blr	x8
    b0dc:      	cmp	w23, w21
    b0e0:      	str	x19, [sp, #0x60]
    b0e4:      	add	x19, sp, #0x70
    b0e8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b0ec:      	ldr	x21, [sp, #0x78]
    b0f0:      	ldp	x2, x24, [sp, #0x50]
    b0f4:      	str	x21, [sp, #0x48]
    b0f8:      	b	0xb148 <generic_lsm_path+0x12f8>
    b0fc:      	add	x2, x24, #0x10
    b100:      	mov	w8, #0x4                // =4
    b104:      	add	x9, sp, #0x98
    b108:      	add	x0, sp, #0x98
    b10c:      	mov	w1, #0x8                // =8
    b110:      	blr	x8
    b114:      	ldr	x8, [sp, #0x58]
    b118:      	ldr	x9, [sp, #0x98]
    b11c:      	cmp	x8, x9
    b120:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b124:      	add	x2, x24, #0x18
    b128:      	mov	w8, #0x4                // =4
    b12c:      	mov	x0, x22
    b130:      	mov	w1, #0x8                // =8
    b134:      	blr	x8
    b138:      	ldr	x24, [sp, #0x98]
    b13c:      	ldr	x21, [sp, #0x48]
    b140:      	add	x2, x24, #0x20
    b144:      	stp	x2, x24, [sp, #0x50]
    b148:      	ldr	x8, [sp, #0x30]
    b14c:      	cmp	x21, x8
    b150:      	b.ne	0xb160 <generic_lsm_path+0x1310>
    b154:      	ldr	x8, [sp, #0x38]
    b158:      	cmp	x2, x8
    b15c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b160:      	mov	w8, #0x4                // =4
    b164:      	add	x0, sp, #0x70
    b168:      	mov	w1, #0x8                // =8
    b16c:      	blr	x8
    b170:      	ldr	x8, [sp, #0x70]
    b174:      	cmp	x21, x8
    b178:      	b.eq	0xb268 <generic_lsm_path+0x1418>
    b17c:      	add	x23, x21, #0x18
    b180:      	mov	w8, #0x4                // =4
    b184:      	add	x9, sp, #0x98
    b188:      	add	x0, sp, #0x98
    b18c:      	mov	w1, #0x8                // =8
    b190:      	mov	x2, x23
    b194:      	blr	x8
    b198:      	ldr	x8, [sp, #0x98]
    b19c:      	cmp	x8, x21
    b1a0:      	b.eq	0xb268 <generic_lsm_path+0x1418>
    b1a4:      	mov	w8, #0x4                // =4
    b1a8:      	add	x9, sp, #0x78
    b1ac:      	add	x0, sp, #0x78
    b1b0:      	mov	w1, #0x8                // =8
    b1b4:      	mov	x2, x23
    b1b8:      	blr	x8
    b1bc:      	add	x2, x21, #0x20
    b1c0:      	mov	w8, #0x4                // =4
    b1c4:      	mov	w9, #0x10               // =16
    b1c8:      	add	x10, sp, #0x80
    b1cc:      	add	x0, sp, #0x80
    b1d0:      	mov	w1, #0x10               // =16
    b1d4:      	blr	x8
    b1d8:      	ldr	w21, [sp, #0x84]
    b1dc:      	ldr	x8, [sp, #0x40]
    b1e0:      	ldr	x10, [sp, #0x60]
    b1e4:      	sub	x12, x10, x8
    b1e8:      	ldr	w23, [sp, #0x68]
    b1ec:      	subs	w10, w21, w23
    b1f0:      	ldr	x9, [sp, #0x88]
    b1f4:      	csel	w10, wzr, w10, lo
    b1f8:      	cmp	w23, w21
    b1fc:      	csel	w11, w23, w21, lo
    b200:      	cinc	w13, w11, hi
    b204:      	sub	w14, w23, w13
    b208:      	subs	x12, x12, x13
    b20c:      	str	w14, [sp, #0x68]
    b210:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b214:      	cmp	x12, #0xfff
    b218:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b21c:      	cmp	w23, w21
    b220:      	b.ls	0xb22c <generic_lsm_path+0x13dc>
    b224:      	mov	w13, #0x2f              // =47
    b228:      	strb	w13, [x8, x12]
    b22c:      	add	x19, x8, x12
    b230:      	cmp	w23, w21
    b234:      	add	x2, x9, x10
    b238:      	and	w1, w11, #0xff
    b23c:      	mov	w8, #0x4                // =4
    b240:      	cinc	x0, x19, hi
    b244:      	blr	x8
    b248:      	cmp	w23, w21
    b24c:      	str	x19, [sp, #0x60]
    b250:      	add	x19, sp, #0x70
    b254:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b258:      	ldr	x21, [sp, #0x78]
    b25c:      	ldp	x2, x24, [sp, #0x50]
    b260:      	str	x21, [sp, #0x48]
    b264:      	b	0xb2b4 <generic_lsm_path+0x1464>
    b268:      	add	x2, x24, #0x10
    b26c:      	mov	w8, #0x4                // =4
    b270:      	add	x9, sp, #0x98
    b274:      	add	x0, sp, #0x98
    b278:      	mov	w1, #0x8                // =8
    b27c:      	blr	x8
    b280:      	ldr	x8, [sp, #0x58]
    b284:      	ldr	x9, [sp, #0x98]
    b288:      	cmp	x8, x9
    b28c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b290:      	add	x2, x24, #0x18
    b294:      	mov	w8, #0x4                // =4
    b298:      	mov	x0, x22
    b29c:      	mov	w1, #0x8                // =8
    b2a0:      	blr	x8
    b2a4:      	ldr	x24, [sp, #0x98]
    b2a8:      	ldr	x21, [sp, #0x48]
    b2ac:      	add	x2, x24, #0x20
    b2b0:      	stp	x2, x24, [sp, #0x50]
    b2b4:      	ldr	x8, [sp, #0x30]
    b2b8:      	cmp	x21, x8
    b2bc:      	b.ne	0xb2cc <generic_lsm_path+0x147c>
    b2c0:      	ldr	x8, [sp, #0x38]
    b2c4:      	cmp	x2, x8
    b2c8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b2cc:      	mov	w8, #0x4                // =4
    b2d0:      	add	x0, sp, #0x70
    b2d4:      	mov	w1, #0x8                // =8
    b2d8:      	blr	x8
    b2dc:      	ldr	x8, [sp, #0x70]
    b2e0:      	cmp	x21, x8
    b2e4:      	b.eq	0xb3d4 <generic_lsm_path+0x1584>
    b2e8:      	add	x23, x21, #0x18
    b2ec:      	mov	w8, #0x4                // =4
    b2f0:      	add	x9, sp, #0x98
    b2f4:      	add	x0, sp, #0x98
    b2f8:      	mov	w1, #0x8                // =8
    b2fc:      	mov	x2, x23
    b300:      	blr	x8
    b304:      	ldr	x8, [sp, #0x98]
    b308:      	cmp	x8, x21
    b30c:      	b.eq	0xb3d4 <generic_lsm_path+0x1584>
    b310:      	mov	w8, #0x4                // =4
    b314:      	add	x9, sp, #0x78
    b318:      	add	x0, sp, #0x78
    b31c:      	mov	w1, #0x8                // =8
    b320:      	mov	x2, x23
    b324:      	blr	x8
    b328:      	add	x2, x21, #0x20
    b32c:      	mov	w8, #0x4                // =4
    b330:      	mov	w9, #0x10               // =16
    b334:      	add	x10, sp, #0x80
    b338:      	add	x0, sp, #0x80
    b33c:      	mov	w1, #0x10               // =16
    b340:      	blr	x8
    b344:      	ldr	w21, [sp, #0x84]
    b348:      	ldr	x8, [sp, #0x40]
    b34c:      	ldr	x10, [sp, #0x60]
    b350:      	sub	x12, x10, x8
    b354:      	ldr	w23, [sp, #0x68]
    b358:      	subs	w10, w21, w23
    b35c:      	ldr	x9, [sp, #0x88]
    b360:      	csel	w10, wzr, w10, lo
    b364:      	cmp	w23, w21
    b368:      	csel	w11, w23, w21, lo
    b36c:      	cinc	w13, w11, hi
    b370:      	sub	w14, w23, w13
    b374:      	subs	x12, x12, x13
    b378:      	str	w14, [sp, #0x68]
    b37c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b380:      	cmp	x12, #0xfff
    b384:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b388:      	cmp	w23, w21
    b38c:      	b.ls	0xb398 <generic_lsm_path+0x1548>
    b390:      	mov	w13, #0x2f              // =47
    b394:      	strb	w13, [x8, x12]
    b398:      	add	x19, x8, x12
    b39c:      	cmp	w23, w21
    b3a0:      	add	x2, x9, x10
    b3a4:      	and	w1, w11, #0xff
    b3a8:      	mov	w8, #0x4                // =4
    b3ac:      	cinc	x0, x19, hi
    b3b0:      	blr	x8
    b3b4:      	cmp	w23, w21
    b3b8:      	str	x19, [sp, #0x60]
    b3bc:      	add	x19, sp, #0x70
    b3c0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b3c4:      	ldr	x21, [sp, #0x78]
    b3c8:      	ldp	x2, x24, [sp, #0x50]
    b3cc:      	str	x21, [sp, #0x48]
    b3d0:      	b	0xb420 <generic_lsm_path+0x15d0>
    b3d4:      	add	x2, x24, #0x10
    b3d8:      	mov	w8, #0x4                // =4
    b3dc:      	add	x9, sp, #0x98
    b3e0:      	add	x0, sp, #0x98
    b3e4:      	mov	w1, #0x8                // =8
    b3e8:      	blr	x8
    b3ec:      	ldr	x8, [sp, #0x58]
    b3f0:      	ldr	x9, [sp, #0x98]
    b3f4:      	cmp	x8, x9
    b3f8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b3fc:      	add	x2, x24, #0x18
    b400:      	mov	w8, #0x4                // =4
    b404:      	mov	x0, x22
    b408:      	mov	w1, #0x8                // =8
    b40c:      	blr	x8
    b410:      	ldr	x24, [sp, #0x98]
    b414:      	ldr	x21, [sp, #0x48]
    b418:      	add	x2, x24, #0x20
    b41c:      	stp	x2, x24, [sp, #0x50]
    b420:      	ldr	x8, [sp, #0x30]
    b424:      	cmp	x21, x8
    b428:      	b.ne	0xb438 <generic_lsm_path+0x15e8>
    b42c:      	ldr	x8, [sp, #0x38]
    b430:      	cmp	x2, x8
    b434:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b438:      	mov	w8, #0x4                // =4
    b43c:      	add	x0, sp, #0x70
    b440:      	mov	w1, #0x8                // =8
    b444:      	blr	x8
    b448:      	ldr	x8, [sp, #0x70]
    b44c:      	cmp	x21, x8
    b450:      	b.eq	0xb540 <generic_lsm_path+0x16f0>
    b454:      	add	x23, x21, #0x18
    b458:      	mov	w8, #0x4                // =4
    b45c:      	add	x9, sp, #0x98
    b460:      	add	x0, sp, #0x98
    b464:      	mov	w1, #0x8                // =8
    b468:      	mov	x2, x23
    b46c:      	blr	x8
    b470:      	ldr	x8, [sp, #0x98]
    b474:      	cmp	x8, x21
    b478:      	b.eq	0xb540 <generic_lsm_path+0x16f0>
    b47c:      	mov	w8, #0x4                // =4
    b480:      	add	x9, sp, #0x78
    b484:      	add	x0, sp, #0x78
    b488:      	mov	w1, #0x8                // =8
    b48c:      	mov	x2, x23
    b490:      	blr	x8
    b494:      	add	x2, x21, #0x20
    b498:      	mov	w8, #0x4                // =4
    b49c:      	mov	w9, #0x10               // =16
    b4a0:      	add	x10, sp, #0x80
    b4a4:      	add	x0, sp, #0x80
    b4a8:      	mov	w1, #0x10               // =16
    b4ac:      	blr	x8
    b4b0:      	ldr	w21, [sp, #0x84]
    b4b4:      	ldr	x8, [sp, #0x40]
    b4b8:      	ldr	x10, [sp, #0x60]
    b4bc:      	sub	x12, x10, x8
    b4c0:      	ldr	w23, [sp, #0x68]
    b4c4:      	subs	w10, w21, w23
    b4c8:      	ldr	x9, [sp, #0x88]
    b4cc:      	csel	w10, wzr, w10, lo
    b4d0:      	cmp	w23, w21
    b4d4:      	csel	w11, w23, w21, lo
    b4d8:      	cinc	w13, w11, hi
    b4dc:      	sub	w14, w23, w13
    b4e0:      	subs	x12, x12, x13
    b4e4:      	str	w14, [sp, #0x68]
    b4e8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b4ec:      	cmp	x12, #0xfff
    b4f0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b4f4:      	cmp	w23, w21
    b4f8:      	b.ls	0xb504 <generic_lsm_path+0x16b4>
    b4fc:      	mov	w13, #0x2f              // =47
    b500:      	strb	w13, [x8, x12]
    b504:      	add	x19, x8, x12
    b508:      	cmp	w23, w21
    b50c:      	add	x2, x9, x10
    b510:      	and	w1, w11, #0xff
    b514:      	mov	w8, #0x4                // =4
    b518:      	cinc	x0, x19, hi
    b51c:      	blr	x8
    b520:      	cmp	w23, w21
    b524:      	str	x19, [sp, #0x60]
    b528:      	add	x19, sp, #0x70
    b52c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b530:      	ldr	x21, [sp, #0x78]
    b534:      	ldp	x2, x24, [sp, #0x50]
    b538:      	str	x21, [sp, #0x48]
    b53c:      	b	0xb58c <generic_lsm_path+0x173c>
    b540:      	add	x2, x24, #0x10
    b544:      	mov	w8, #0x4                // =4
    b548:      	add	x9, sp, #0x98
    b54c:      	add	x0, sp, #0x98
    b550:      	mov	w1, #0x8                // =8
    b554:      	blr	x8
    b558:      	ldr	x8, [sp, #0x58]
    b55c:      	ldr	x9, [sp, #0x98]
    b560:      	cmp	x8, x9
    b564:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b568:      	add	x2, x24, #0x18
    b56c:      	mov	w8, #0x4                // =4
    b570:      	mov	x0, x22
    b574:      	mov	w1, #0x8                // =8
    b578:      	blr	x8
    b57c:      	ldr	x24, [sp, #0x98]
    b580:      	ldr	x21, [sp, #0x48]
    b584:      	add	x2, x24, #0x20
    b588:      	stp	x2, x24, [sp, #0x50]
    b58c:      	ldr	x8, [sp, #0x30]
    b590:      	cmp	x21, x8
    b594:      	b.ne	0xb5a4 <generic_lsm_path+0x1754>
    b598:      	ldr	x8, [sp, #0x38]
    b59c:      	cmp	x2, x8
    b5a0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b5a4:      	mov	w8, #0x4                // =4
    b5a8:      	add	x0, sp, #0x70
    b5ac:      	mov	w1, #0x8                // =8
    b5b0:      	blr	x8
    b5b4:      	ldr	x8, [sp, #0x70]
    b5b8:      	cmp	x21, x8
    b5bc:      	b.eq	0xb6ac <generic_lsm_path+0x185c>
    b5c0:      	add	x23, x21, #0x18
    b5c4:      	mov	w8, #0x4                // =4
    b5c8:      	add	x9, sp, #0x98
    b5cc:      	add	x0, sp, #0x98
    b5d0:      	mov	w1, #0x8                // =8
    b5d4:      	mov	x2, x23
    b5d8:      	blr	x8
    b5dc:      	ldr	x8, [sp, #0x98]
    b5e0:      	cmp	x8, x21
    b5e4:      	b.eq	0xb6ac <generic_lsm_path+0x185c>
    b5e8:      	mov	w8, #0x4                // =4
    b5ec:      	add	x9, sp, #0x78
    b5f0:      	add	x0, sp, #0x78
    b5f4:      	mov	w1, #0x8                // =8
    b5f8:      	mov	x2, x23
    b5fc:      	blr	x8
    b600:      	add	x2, x21, #0x20
    b604:      	mov	w8, #0x4                // =4
    b608:      	mov	w9, #0x10               // =16
    b60c:      	add	x10, sp, #0x80
    b610:      	add	x0, sp, #0x80
    b614:      	mov	w1, #0x10               // =16
    b618:      	blr	x8
    b61c:      	ldr	w21, [sp, #0x84]
    b620:      	ldr	x8, [sp, #0x40]
    b624:      	ldr	x10, [sp, #0x60]
    b628:      	sub	x12, x10, x8
    b62c:      	ldr	w23, [sp, #0x68]
    b630:      	subs	w10, w21, w23
    b634:      	ldr	x9, [sp, #0x88]
    b638:      	csel	w10, wzr, w10, lo
    b63c:      	cmp	w23, w21
    b640:      	csel	w11, w23, w21, lo
    b644:      	cinc	w13, w11, hi
    b648:      	sub	w14, w23, w13
    b64c:      	subs	x12, x12, x13
    b650:      	str	w14, [sp, #0x68]
    b654:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b658:      	cmp	x12, #0xfff
    b65c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b660:      	cmp	w23, w21
    b664:      	b.ls	0xb670 <generic_lsm_path+0x1820>
    b668:      	mov	w13, #0x2f              // =47
    b66c:      	strb	w13, [x8, x12]
    b670:      	add	x19, x8, x12
    b674:      	cmp	w23, w21
    b678:      	add	x2, x9, x10
    b67c:      	and	w1, w11, #0xff
    b680:      	mov	w8, #0x4                // =4
    b684:      	cinc	x0, x19, hi
    b688:      	blr	x8
    b68c:      	cmp	w23, w21
    b690:      	str	x19, [sp, #0x60]
    b694:      	add	x19, sp, #0x70
    b698:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b69c:      	ldr	x21, [sp, #0x78]
    b6a0:      	ldp	x2, x24, [sp, #0x50]
    b6a4:      	str	x21, [sp, #0x48]
    b6a8:      	b	0xb6f8 <generic_lsm_path+0x18a8>
    b6ac:      	add	x2, x24, #0x10
    b6b0:      	mov	w8, #0x4                // =4
    b6b4:      	add	x9, sp, #0x98
    b6b8:      	add	x0, sp, #0x98
    b6bc:      	mov	w1, #0x8                // =8
    b6c0:      	blr	x8
    b6c4:      	ldr	x8, [sp, #0x58]
    b6c8:      	ldr	x9, [sp, #0x98]
    b6cc:      	cmp	x8, x9
    b6d0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b6d4:      	add	x2, x24, #0x18
    b6d8:      	mov	w8, #0x4                // =4
    b6dc:      	mov	x0, x22
    b6e0:      	mov	w1, #0x8                // =8
    b6e4:      	blr	x8
    b6e8:      	ldr	x24, [sp, #0x98]
    b6ec:      	ldr	x21, [sp, #0x48]
    b6f0:      	add	x2, x24, #0x20
    b6f4:      	stp	x2, x24, [sp, #0x50]
    b6f8:      	ldr	x8, [sp, #0x30]
    b6fc:      	cmp	x21, x8
    b700:      	b.ne	0xb710 <generic_lsm_path+0x18c0>
    b704:      	ldr	x8, [sp, #0x38]
    b708:      	cmp	x2, x8
    b70c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b710:      	mov	w8, #0x4                // =4
    b714:      	add	x0, sp, #0x70
    b718:      	mov	w1, #0x8                // =8
    b71c:      	blr	x8
    b720:      	ldr	x8, [sp, #0x70]
    b724:      	cmp	x21, x8
    b728:      	b.eq	0xb818 <generic_lsm_path+0x19c8>
    b72c:      	add	x23, x21, #0x18
    b730:      	mov	w8, #0x4                // =4
    b734:      	add	x9, sp, #0x98
    b738:      	add	x0, sp, #0x98
    b73c:      	mov	w1, #0x8                // =8
    b740:      	mov	x2, x23
    b744:      	blr	x8
    b748:      	ldr	x8, [sp, #0x98]
    b74c:      	cmp	x8, x21
    b750:      	b.eq	0xb818 <generic_lsm_path+0x19c8>
    b754:      	mov	w8, #0x4                // =4
    b758:      	add	x9, sp, #0x78
    b75c:      	add	x0, sp, #0x78
    b760:      	mov	w1, #0x8                // =8
    b764:      	mov	x2, x23
    b768:      	blr	x8
    b76c:      	add	x2, x21, #0x20
    b770:      	mov	w8, #0x4                // =4
    b774:      	mov	w9, #0x10               // =16
    b778:      	add	x10, sp, #0x80
    b77c:      	add	x0, sp, #0x80
    b780:      	mov	w1, #0x10               // =16
    b784:      	blr	x8
    b788:      	ldr	w21, [sp, #0x84]
    b78c:      	ldr	x8, [sp, #0x40]
    b790:      	ldr	x10, [sp, #0x60]
    b794:      	sub	x12, x10, x8
    b798:      	ldr	w23, [sp, #0x68]
    b79c:      	subs	w10, w21, w23
    b7a0:      	ldr	x9, [sp, #0x88]
    b7a4:      	csel	w10, wzr, w10, lo
    b7a8:      	cmp	w23, w21
    b7ac:      	csel	w11, w23, w21, lo
    b7b0:      	cinc	w13, w11, hi
    b7b4:      	sub	w14, w23, w13
    b7b8:      	subs	x12, x12, x13
    b7bc:      	str	w14, [sp, #0x68]
    b7c0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b7c4:      	cmp	x12, #0xfff
    b7c8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b7cc:      	cmp	w23, w21
    b7d0:      	b.ls	0xb7dc <generic_lsm_path+0x198c>
    b7d4:      	mov	w13, #0x2f              // =47
    b7d8:      	strb	w13, [x8, x12]
    b7dc:      	add	x19, x8, x12
    b7e0:      	cmp	w23, w21
    b7e4:      	add	x2, x9, x10
    b7e8:      	and	w1, w11, #0xff
    b7ec:      	mov	w8, #0x4                // =4
    b7f0:      	cinc	x0, x19, hi
    b7f4:      	blr	x8
    b7f8:      	cmp	w23, w21
    b7fc:      	str	x19, [sp, #0x60]
    b800:      	add	x19, sp, #0x70
    b804:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b808:      	ldr	x21, [sp, #0x78]
    b80c:      	ldp	x2, x24, [sp, #0x50]
    b810:      	str	x21, [sp, #0x48]
    b814:      	b	0xb864 <generic_lsm_path+0x1a14>
    b818:      	add	x2, x24, #0x10
    b81c:      	mov	w8, #0x4                // =4
    b820:      	add	x9, sp, #0x98
    b824:      	add	x0, sp, #0x98
    b828:      	mov	w1, #0x8                // =8
    b82c:      	blr	x8
    b830:      	ldr	x8, [sp, #0x58]
    b834:      	ldr	x9, [sp, #0x98]
    b838:      	cmp	x8, x9
    b83c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b840:      	add	x2, x24, #0x18
    b844:      	mov	w8, #0x4                // =4
    b848:      	mov	x0, x22
    b84c:      	mov	w1, #0x8                // =8
    b850:      	blr	x8
    b854:      	ldr	x24, [sp, #0x98]
    b858:      	ldr	x21, [sp, #0x48]
    b85c:      	add	x2, x24, #0x20
    b860:      	stp	x2, x24, [sp, #0x50]
    b864:      	ldr	x8, [sp, #0x30]
    b868:      	cmp	x21, x8
    b86c:      	b.ne	0xb87c <generic_lsm_path+0x1a2c>
    b870:      	ldr	x8, [sp, #0x38]
    b874:      	cmp	x2, x8
    b878:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b87c:      	mov	w8, #0x4                // =4
    b880:      	add	x0, sp, #0x70
    b884:      	mov	w1, #0x8                // =8
    b888:      	blr	x8
    b88c:      	ldr	x8, [sp, #0x70]
    b890:      	cmp	x21, x8
    b894:      	b.eq	0xb984 <generic_lsm_path+0x1b34>
    b898:      	add	x23, x21, #0x18
    b89c:      	mov	w8, #0x4                // =4
    b8a0:      	add	x9, sp, #0x98
    b8a4:      	add	x0, sp, #0x98
    b8a8:      	mov	w1, #0x8                // =8
    b8ac:      	mov	x2, x23
    b8b0:      	blr	x8
    b8b4:      	ldr	x8, [sp, #0x98]
    b8b8:      	cmp	x8, x21
    b8bc:      	b.eq	0xb984 <generic_lsm_path+0x1b34>
    b8c0:      	mov	w8, #0x4                // =4
    b8c4:      	add	x9, sp, #0x78
    b8c8:      	add	x0, sp, #0x78
    b8cc:      	mov	w1, #0x8                // =8
    b8d0:      	mov	x2, x23
    b8d4:      	blr	x8
    b8d8:      	add	x2, x21, #0x20
    b8dc:      	mov	w8, #0x4                // =4
    b8e0:      	mov	w9, #0x10               // =16
    b8e4:      	add	x10, sp, #0x80
    b8e8:      	add	x0, sp, #0x80
    b8ec:      	mov	w1, #0x10               // =16
    b8f0:      	blr	x8
    b8f4:      	ldr	w21, [sp, #0x84]
    b8f8:      	ldr	x8, [sp, #0x40]
    b8fc:      	ldr	x10, [sp, #0x60]
    b900:      	sub	x12, x10, x8
    b904:      	ldr	w23, [sp, #0x68]
    b908:      	subs	w10, w21, w23
    b90c:      	ldr	x9, [sp, #0x88]
    b910:      	csel	w10, wzr, w10, lo
    b914:      	cmp	w23, w21
    b918:      	csel	w11, w23, w21, lo
    b91c:      	cinc	w13, w11, hi
    b920:      	sub	w14, w23, w13
    b924:      	subs	x12, x12, x13
    b928:      	str	w14, [sp, #0x68]
    b92c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    b930:      	cmp	x12, #0xfff
    b934:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    b938:      	cmp	w23, w21
    b93c:      	b.ls	0xb948 <generic_lsm_path+0x1af8>
    b940:      	mov	w13, #0x2f              // =47
    b944:      	strb	w13, [x8, x12]
    b948:      	add	x19, x8, x12
    b94c:      	cmp	w23, w21
    b950:      	add	x2, x9, x10
    b954:      	and	w1, w11, #0xff
    b958:      	mov	w8, #0x4                // =4
    b95c:      	cinc	x0, x19, hi
    b960:      	blr	x8
    b964:      	cmp	w23, w21
    b968:      	str	x19, [sp, #0x60]
    b96c:      	add	x19, sp, #0x70
    b970:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    b974:      	ldr	x21, [sp, #0x78]
    b978:      	ldp	x2, x24, [sp, #0x50]
    b97c:      	str	x21, [sp, #0x48]
    b980:      	b	0xb9d0 <generic_lsm_path+0x1b80>
    b984:      	add	x2, x24, #0x10
    b988:      	mov	w8, #0x4                // =4
    b98c:      	add	x9, sp, #0x98
    b990:      	add	x0, sp, #0x98
    b994:      	mov	w1, #0x8                // =8
    b998:      	blr	x8
    b99c:      	ldr	x8, [sp, #0x58]
    b9a0:      	ldr	x9, [sp, #0x98]
    b9a4:      	cmp	x8, x9
    b9a8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b9ac:      	add	x2, x24, #0x18
    b9b0:      	mov	w8, #0x4                // =4
    b9b4:      	mov	x0, x22
    b9b8:      	mov	w1, #0x8                // =8
    b9bc:      	blr	x8
    b9c0:      	ldr	x24, [sp, #0x98]
    b9c4:      	ldr	x21, [sp, #0x48]
    b9c8:      	add	x2, x24, #0x20
    b9cc:      	stp	x2, x24, [sp, #0x50]
    b9d0:      	ldr	x8, [sp, #0x30]
    b9d4:      	cmp	x21, x8
    b9d8:      	b.ne	0xb9e8 <generic_lsm_path+0x1b98>
    b9dc:      	ldr	x8, [sp, #0x38]
    b9e0:      	cmp	x2, x8
    b9e4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    b9e8:      	mov	w8, #0x4                // =4
    b9ec:      	add	x0, sp, #0x70
    b9f0:      	mov	w1, #0x8                // =8
    b9f4:      	blr	x8
    b9f8:      	ldr	x8, [sp, #0x70]
    b9fc:      	cmp	x21, x8
    ba00:      	b.eq	0xbaf0 <generic_lsm_path+0x1ca0>
    ba04:      	add	x23, x21, #0x18
    ba08:      	mov	w8, #0x4                // =4
    ba0c:      	add	x9, sp, #0x98
    ba10:      	add	x0, sp, #0x98
    ba14:      	mov	w1, #0x8                // =8
    ba18:      	mov	x2, x23
    ba1c:      	blr	x8
    ba20:      	ldr	x8, [sp, #0x98]
    ba24:      	cmp	x8, x21
    ba28:      	b.eq	0xbaf0 <generic_lsm_path+0x1ca0>
    ba2c:      	mov	w8, #0x4                // =4
    ba30:      	add	x9, sp, #0x78
    ba34:      	add	x0, sp, #0x78
    ba38:      	mov	w1, #0x8                // =8
    ba3c:      	mov	x2, x23
    ba40:      	blr	x8
    ba44:      	add	x2, x21, #0x20
    ba48:      	mov	w8, #0x4                // =4
    ba4c:      	mov	w9, #0x10               // =16
    ba50:      	add	x10, sp, #0x80
    ba54:      	add	x0, sp, #0x80
    ba58:      	mov	w1, #0x10               // =16
    ba5c:      	blr	x8
    ba60:      	ldr	w21, [sp, #0x84]
    ba64:      	ldr	x8, [sp, #0x40]
    ba68:      	ldr	x10, [sp, #0x60]
    ba6c:      	sub	x12, x10, x8
    ba70:      	ldr	w23, [sp, #0x68]
    ba74:      	subs	w10, w21, w23
    ba78:      	ldr	x9, [sp, #0x88]
    ba7c:      	csel	w10, wzr, w10, lo
    ba80:      	cmp	w23, w21
    ba84:      	csel	w11, w23, w21, lo
    ba88:      	cinc	w13, w11, hi
    ba8c:      	sub	w14, w23, w13
    ba90:      	subs	x12, x12, x13
    ba94:      	str	w14, [sp, #0x68]
    ba98:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    ba9c:      	cmp	x12, #0xfff
    baa0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    baa4:      	cmp	w23, w21
    baa8:      	b.ls	0xbab4 <generic_lsm_path+0x1c64>
    baac:      	mov	w13, #0x2f              // =47
    bab0:      	strb	w13, [x8, x12]
    bab4:      	add	x19, x8, x12
    bab8:      	cmp	w23, w21
    babc:      	add	x2, x9, x10
    bac0:      	and	w1, w11, #0xff
    bac4:      	mov	w8, #0x4                // =4
    bac8:      	cinc	x0, x19, hi
    bacc:      	blr	x8
    bad0:      	cmp	w23, w21
    bad4:      	str	x19, [sp, #0x60]
    bad8:      	add	x19, sp, #0x70
    badc:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    bae0:      	ldr	x21, [sp, #0x78]
    bae4:      	ldp	x2, x24, [sp, #0x50]
    bae8:      	str	x21, [sp, #0x48]
    baec:      	b	0xbb3c <generic_lsm_path+0x1cec>
    baf0:      	add	x2, x24, #0x10
    baf4:      	mov	w8, #0x4                // =4
    baf8:      	add	x9, sp, #0x98
    bafc:      	add	x0, sp, #0x98
    bb00:      	mov	w1, #0x8                // =8
    bb04:      	blr	x8
    bb08:      	ldr	x8, [sp, #0x58]
    bb0c:      	ldr	x9, [sp, #0x98]
    bb10:      	cmp	x8, x9
    bb14:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bb18:      	add	x2, x24, #0x18
    bb1c:      	mov	w8, #0x4                // =4
    bb20:      	mov	x0, x22
    bb24:      	mov	w1, #0x8                // =8
    bb28:      	blr	x8
    bb2c:      	ldr	x24, [sp, #0x98]
    bb30:      	ldr	x21, [sp, #0x48]
    bb34:      	add	x2, x24, #0x20
    bb38:      	stp	x2, x24, [sp, #0x50]
    bb3c:      	ldr	x8, [sp, #0x30]
    bb40:      	cmp	x21, x8
    bb44:      	b.ne	0xbb54 <generic_lsm_path+0x1d04>
    bb48:      	ldr	x8, [sp, #0x38]
    bb4c:      	cmp	x2, x8
    bb50:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bb54:      	mov	w8, #0x4                // =4
    bb58:      	add	x0, sp, #0x70
    bb5c:      	mov	w1, #0x8                // =8
    bb60:      	blr	x8
    bb64:      	ldr	x8, [sp, #0x70]
    bb68:      	cmp	x21, x8
    bb6c:      	b.eq	0xbc5c <generic_lsm_path+0x1e0c>
    bb70:      	add	x23, x21, #0x18
    bb74:      	mov	w8, #0x4                // =4
    bb78:      	add	x9, sp, #0x98
    bb7c:      	add	x0, sp, #0x98
    bb80:      	mov	w1, #0x8                // =8
    bb84:      	mov	x2, x23
    bb88:      	blr	x8
    bb8c:      	ldr	x8, [sp, #0x98]
    bb90:      	cmp	x8, x21
    bb94:      	b.eq	0xbc5c <generic_lsm_path+0x1e0c>
    bb98:      	mov	w8, #0x4                // =4
    bb9c:      	add	x9, sp, #0x78
    bba0:      	add	x0, sp, #0x78
    bba4:      	mov	w1, #0x8                // =8
    bba8:      	mov	x2, x23
    bbac:      	blr	x8
    bbb0:      	add	x2, x21, #0x20
    bbb4:      	mov	w8, #0x4                // =4
    bbb8:      	mov	w9, #0x10               // =16
    bbbc:      	add	x10, sp, #0x80
    bbc0:      	add	x0, sp, #0x80
    bbc4:      	mov	w1, #0x10               // =16
    bbc8:      	blr	x8
    bbcc:      	ldr	w21, [sp, #0x84]
    bbd0:      	ldr	x8, [sp, #0x40]
    bbd4:      	ldr	x10, [sp, #0x60]
    bbd8:      	sub	x12, x10, x8
    bbdc:      	ldr	w23, [sp, #0x68]
    bbe0:      	subs	w10, w21, w23
    bbe4:      	ldr	x9, [sp, #0x88]
    bbe8:      	csel	w10, wzr, w10, lo
    bbec:      	cmp	w23, w21
    bbf0:      	csel	w11, w23, w21, lo
    bbf4:      	cinc	w13, w11, hi
    bbf8:      	sub	w14, w23, w13
    bbfc:      	subs	x12, x12, x13
    bc00:      	str	w14, [sp, #0x68]
    bc04:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    bc08:      	cmp	x12, #0xfff
    bc0c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    bc10:      	cmp	w23, w21
    bc14:      	b.ls	0xbc20 <generic_lsm_path+0x1dd0>
    bc18:      	mov	w13, #0x2f              // =47
    bc1c:      	strb	w13, [x8, x12]
    bc20:      	add	x19, x8, x12
    bc24:      	cmp	w23, w21
    bc28:      	add	x2, x9, x10
    bc2c:      	and	w1, w11, #0xff
    bc30:      	mov	w8, #0x4                // =4
    bc34:      	cinc	x0, x19, hi
    bc38:      	blr	x8
    bc3c:      	cmp	w23, w21
    bc40:      	str	x19, [sp, #0x60]
    bc44:      	add	x19, sp, #0x70
    bc48:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    bc4c:      	ldr	x21, [sp, #0x78]
    bc50:      	ldp	x2, x24, [sp, #0x50]
    bc54:      	str	x21, [sp, #0x48]
    bc58:      	b	0xbca8 <generic_lsm_path+0x1e58>
    bc5c:      	add	x2, x24, #0x10
    bc60:      	mov	w8, #0x4                // =4
    bc64:      	add	x9, sp, #0x98
    bc68:      	add	x0, sp, #0x98
    bc6c:      	mov	w1, #0x8                // =8
    bc70:      	blr	x8
    bc74:      	ldr	x8, [sp, #0x58]
    bc78:      	ldr	x9, [sp, #0x98]
    bc7c:      	cmp	x8, x9
    bc80:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bc84:      	add	x2, x24, #0x18
    bc88:      	mov	w8, #0x4                // =4
    bc8c:      	mov	x0, x22
    bc90:      	mov	w1, #0x8                // =8
    bc94:      	blr	x8
    bc98:      	ldr	x24, [sp, #0x98]
    bc9c:      	ldr	x21, [sp, #0x48]
    bca0:      	add	x2, x24, #0x20
    bca4:      	stp	x2, x24, [sp, #0x50]
    bca8:      	ldr	x8, [sp, #0x30]
    bcac:      	cmp	x21, x8
    bcb0:      	b.ne	0xbcc0 <generic_lsm_path+0x1e70>
    bcb4:      	ldr	x8, [sp, #0x38]
    bcb8:      	cmp	x2, x8
    bcbc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bcc0:      	mov	w8, #0x4                // =4
    bcc4:      	add	x0, sp, #0x70
    bcc8:      	mov	w1, #0x8                // =8
    bccc:      	blr	x8
    bcd0:      	ldr	x8, [sp, #0x70]
    bcd4:      	cmp	x21, x8
    bcd8:      	b.eq	0xbdc8 <generic_lsm_path+0x1f78>
    bcdc:      	add	x23, x21, #0x18
    bce0:      	mov	w8, #0x4                // =4
    bce4:      	add	x9, sp, #0x98
    bce8:      	add	x0, sp, #0x98
    bcec:      	mov	w1, #0x8                // =8
    bcf0:      	mov	x2, x23
    bcf4:      	blr	x8
    bcf8:      	ldr	x8, [sp, #0x98]
    bcfc:      	cmp	x8, x21
    bd00:      	b.eq	0xbdc8 <generic_lsm_path+0x1f78>
    bd04:      	mov	w8, #0x4                // =4
    bd08:      	add	x9, sp, #0x78
    bd0c:      	add	x0, sp, #0x78
    bd10:      	mov	w1, #0x8                // =8
    bd14:      	mov	x2, x23
    bd18:      	blr	x8
    bd1c:      	add	x2, x21, #0x20
    bd20:      	mov	w8, #0x4                // =4
    bd24:      	mov	w9, #0x10               // =16
    bd28:      	add	x10, sp, #0x80
    bd2c:      	add	x0, sp, #0x80
    bd30:      	mov	w1, #0x10               // =16
    bd34:      	blr	x8
    bd38:      	ldr	w21, [sp, #0x84]
    bd3c:      	ldr	x8, [sp, #0x40]
    bd40:      	ldr	x10, [sp, #0x60]
    bd44:      	sub	x12, x10, x8
    bd48:      	ldr	w23, [sp, #0x68]
    bd4c:      	subs	w10, w21, w23
    bd50:      	ldr	x9, [sp, #0x88]
    bd54:      	csel	w10, wzr, w10, lo
    bd58:      	cmp	w23, w21
    bd5c:      	csel	w11, w23, w21, lo
    bd60:      	cinc	w13, w11, hi
    bd64:      	sub	w14, w23, w13
    bd68:      	subs	x12, x12, x13
    bd6c:      	str	w14, [sp, #0x68]
    bd70:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    bd74:      	cmp	x12, #0xfff
    bd78:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    bd7c:      	cmp	w23, w21
    bd80:      	b.ls	0xbd8c <generic_lsm_path+0x1f3c>
    bd84:      	mov	w13, #0x2f              // =47
    bd88:      	strb	w13, [x8, x12]
    bd8c:      	add	x19, x8, x12
    bd90:      	cmp	w23, w21
    bd94:      	add	x2, x9, x10
    bd98:      	and	w1, w11, #0xff
    bd9c:      	mov	w8, #0x4                // =4
    bda0:      	cinc	x0, x19, hi
    bda4:      	blr	x8
    bda8:      	cmp	w23, w21
    bdac:      	str	x19, [sp, #0x60]
    bdb0:      	add	x19, sp, #0x70
    bdb4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    bdb8:      	ldr	x21, [sp, #0x78]
    bdbc:      	ldp	x2, x24, [sp, #0x50]
    bdc0:      	str	x21, [sp, #0x48]
    bdc4:      	b	0xbe14 <generic_lsm_path+0x1fc4>
    bdc8:      	add	x2, x24, #0x10
    bdcc:      	mov	w8, #0x4                // =4
    bdd0:      	add	x9, sp, #0x98
    bdd4:      	add	x0, sp, #0x98
    bdd8:      	mov	w1, #0x8                // =8
    bddc:      	blr	x8
    bde0:      	ldr	x8, [sp, #0x58]
    bde4:      	ldr	x9, [sp, #0x98]
    bde8:      	cmp	x8, x9
    bdec:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bdf0:      	add	x2, x24, #0x18
    bdf4:      	mov	w8, #0x4                // =4
    bdf8:      	mov	x0, x22
    bdfc:      	mov	w1, #0x8                // =8
    be00:      	blr	x8
    be04:      	ldr	x24, [sp, #0x98]
    be08:      	ldr	x21, [sp, #0x48]
    be0c:      	add	x2, x24, #0x20
    be10:      	stp	x2, x24, [sp, #0x50]
    be14:      	ldr	x8, [sp, #0x30]
    be18:      	cmp	x21, x8
    be1c:      	b.ne	0xbe2c <generic_lsm_path+0x1fdc>
    be20:      	ldr	x8, [sp, #0x38]
    be24:      	cmp	x2, x8
    be28:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    be2c:      	mov	w8, #0x4                // =4
    be30:      	add	x0, sp, #0x70
    be34:      	mov	w1, #0x8                // =8
    be38:      	blr	x8
    be3c:      	ldr	x8, [sp, #0x70]
    be40:      	cmp	x21, x8
    be44:      	b.eq	0xbf34 <generic_lsm_path+0x20e4>
    be48:      	add	x23, x21, #0x18
    be4c:      	mov	w8, #0x4                // =4
    be50:      	add	x9, sp, #0x98
    be54:      	add	x0, sp, #0x98
    be58:      	mov	w1, #0x8                // =8
    be5c:      	mov	x2, x23
    be60:      	blr	x8
    be64:      	ldr	x8, [sp, #0x98]
    be68:      	cmp	x8, x21
    be6c:      	b.eq	0xbf34 <generic_lsm_path+0x20e4>
    be70:      	mov	w8, #0x4                // =4
    be74:      	add	x9, sp, #0x78
    be78:      	add	x0, sp, #0x78
    be7c:      	mov	w1, #0x8                // =8
    be80:      	mov	x2, x23
    be84:      	blr	x8
    be88:      	add	x2, x21, #0x20
    be8c:      	mov	w8, #0x4                // =4
    be90:      	mov	w9, #0x10               // =16
    be94:      	add	x10, sp, #0x80
    be98:      	add	x0, sp, #0x80
    be9c:      	mov	w1, #0x10               // =16
    bea0:      	blr	x8
    bea4:      	ldr	w21, [sp, #0x84]
    bea8:      	ldr	x8, [sp, #0x40]
    beac:      	ldr	x10, [sp, #0x60]
    beb0:      	sub	x12, x10, x8
    beb4:      	ldr	w23, [sp, #0x68]
    beb8:      	subs	w10, w21, w23
    bebc:      	ldr	x9, [sp, #0x88]
    bec0:      	csel	w10, wzr, w10, lo
    bec4:      	cmp	w23, w21
    bec8:      	csel	w11, w23, w21, lo
    becc:      	cinc	w13, w11, hi
    bed0:      	sub	w14, w23, w13
    bed4:      	subs	x12, x12, x13
    bed8:      	str	w14, [sp, #0x68]
    bedc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    bee0:      	cmp	x12, #0xfff
    bee4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    bee8:      	cmp	w23, w21
    beec:      	b.ls	0xbef8 <generic_lsm_path+0x20a8>
    bef0:      	mov	w13, #0x2f              // =47
    bef4:      	strb	w13, [x8, x12]
    bef8:      	add	x19, x8, x12
    befc:      	cmp	w23, w21
    bf00:      	add	x2, x9, x10
    bf04:      	and	w1, w11, #0xff
    bf08:      	mov	w8, #0x4                // =4
    bf0c:      	cinc	x0, x19, hi
    bf10:      	blr	x8
    bf14:      	cmp	w23, w21
    bf18:      	str	x19, [sp, #0x60]
    bf1c:      	add	x19, sp, #0x70
    bf20:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    bf24:      	ldr	x21, [sp, #0x78]
    bf28:      	ldp	x2, x24, [sp, #0x50]
    bf2c:      	str	x21, [sp, #0x48]
    bf30:      	b	0xbf80 <generic_lsm_path+0x2130>
    bf34:      	add	x2, x24, #0x10
    bf38:      	mov	w8, #0x4                // =4
    bf3c:      	add	x9, sp, #0x98
    bf40:      	add	x0, sp, #0x98
    bf44:      	mov	w1, #0x8                // =8
    bf48:      	blr	x8
    bf4c:      	ldr	x8, [sp, #0x58]
    bf50:      	ldr	x9, [sp, #0x98]
    bf54:      	cmp	x8, x9
    bf58:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bf5c:      	add	x2, x24, #0x18
    bf60:      	mov	w8, #0x4                // =4
    bf64:      	mov	x0, x22
    bf68:      	mov	w1, #0x8                // =8
    bf6c:      	blr	x8
    bf70:      	ldr	x24, [sp, #0x98]
    bf74:      	ldr	x21, [sp, #0x48]
    bf78:      	add	x2, x24, #0x20
    bf7c:      	stp	x2, x24, [sp, #0x50]
    bf80:      	ldr	x8, [sp, #0x30]
    bf84:      	cmp	x21, x8
    bf88:      	b.ne	0xbf98 <generic_lsm_path+0x2148>
    bf8c:      	ldr	x8, [sp, #0x38]
    bf90:      	cmp	x2, x8
    bf94:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    bf98:      	mov	w8, #0x4                // =4
    bf9c:      	add	x0, sp, #0x70
    bfa0:      	mov	w1, #0x8                // =8
    bfa4:      	blr	x8
    bfa8:      	ldr	x8, [sp, #0x70]
    bfac:      	cmp	x21, x8
    bfb0:      	b.eq	0xc0a0 <generic_lsm_path+0x2250>
    bfb4:      	add	x23, x21, #0x18
    bfb8:      	mov	w8, #0x4                // =4
    bfbc:      	add	x9, sp, #0x98
    bfc0:      	add	x0, sp, #0x98
    bfc4:      	mov	w1, #0x8                // =8
    bfc8:      	mov	x2, x23
    bfcc:      	blr	x8
    bfd0:      	ldr	x8, [sp, #0x98]
    bfd4:      	cmp	x8, x21
    bfd8:      	b.eq	0xc0a0 <generic_lsm_path+0x2250>
    bfdc:      	mov	w8, #0x4                // =4
    bfe0:      	add	x9, sp, #0x78
    bfe4:      	add	x0, sp, #0x78
    bfe8:      	mov	w1, #0x8                // =8
    bfec:      	mov	x2, x23
    bff0:      	blr	x8
    bff4:      	add	x2, x21, #0x20
    bff8:      	mov	w8, #0x4                // =4
    bffc:      	mov	w9, #0x10               // =16
    c000:      	add	x10, sp, #0x80
    c004:      	add	x0, sp, #0x80
    c008:      	mov	w1, #0x10               // =16
    c00c:      	blr	x8
    c010:      	ldr	w21, [sp, #0x84]
    c014:      	ldr	x8, [sp, #0x40]
    c018:      	ldr	x10, [sp, #0x60]
    c01c:      	sub	x12, x10, x8
    c020:      	ldr	w23, [sp, #0x68]
    c024:      	subs	w10, w21, w23
    c028:      	ldr	x9, [sp, #0x88]
    c02c:      	csel	w10, wzr, w10, lo
    c030:      	cmp	w23, w21
    c034:      	csel	w11, w23, w21, lo
    c038:      	cinc	w13, w11, hi
    c03c:      	sub	w14, w23, w13
    c040:      	subs	x12, x12, x13
    c044:      	str	w14, [sp, #0x68]
    c048:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c04c:      	cmp	x12, #0xfff
    c050:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c054:      	cmp	w23, w21
    c058:      	b.ls	0xc064 <generic_lsm_path+0x2214>
    c05c:      	mov	w13, #0x2f              // =47
    c060:      	strb	w13, [x8, x12]
    c064:      	add	x19, x8, x12
    c068:      	cmp	w23, w21
    c06c:      	add	x2, x9, x10
    c070:      	and	w1, w11, #0xff
    c074:      	mov	w8, #0x4                // =4
    c078:      	cinc	x0, x19, hi
    c07c:      	blr	x8
    c080:      	cmp	w23, w21
    c084:      	str	x19, [sp, #0x60]
    c088:      	add	x19, sp, #0x70
    c08c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c090:      	ldr	x21, [sp, #0x78]
    c094:      	ldp	x2, x24, [sp, #0x50]
    c098:      	str	x21, [sp, #0x48]
    c09c:      	b	0xc0ec <generic_lsm_path+0x229c>
    c0a0:      	add	x2, x24, #0x10
    c0a4:      	mov	w8, #0x4                // =4
    c0a8:      	add	x9, sp, #0x98
    c0ac:      	add	x0, sp, #0x98
    c0b0:      	mov	w1, #0x8                // =8
    c0b4:      	blr	x8
    c0b8:      	ldr	x8, [sp, #0x58]
    c0bc:      	ldr	x9, [sp, #0x98]
    c0c0:      	cmp	x8, x9
    c0c4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c0c8:      	add	x2, x24, #0x18
    c0cc:      	mov	w8, #0x4                // =4
    c0d0:      	mov	x0, x22
    c0d4:      	mov	w1, #0x8                // =8
    c0d8:      	blr	x8
    c0dc:      	ldr	x24, [sp, #0x98]
    c0e0:      	ldr	x21, [sp, #0x48]
    c0e4:      	add	x2, x24, #0x20
    c0e8:      	stp	x2, x24, [sp, #0x50]
    c0ec:      	ldr	x8, [sp, #0x30]
    c0f0:      	cmp	x21, x8
    c0f4:      	b.ne	0xc104 <generic_lsm_path+0x22b4>
    c0f8:      	ldr	x8, [sp, #0x38]
    c0fc:      	cmp	x2, x8
    c100:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c104:      	mov	w8, #0x4                // =4
    c108:      	add	x0, sp, #0x70
    c10c:      	mov	w1, #0x8                // =8
    c110:      	blr	x8
    c114:      	ldr	x8, [sp, #0x70]
    c118:      	cmp	x21, x8
    c11c:      	b.eq	0xc20c <generic_lsm_path+0x23bc>
    c120:      	add	x23, x21, #0x18
    c124:      	mov	w8, #0x4                // =4
    c128:      	add	x9, sp, #0x98
    c12c:      	add	x0, sp, #0x98
    c130:      	mov	w1, #0x8                // =8
    c134:      	mov	x2, x23
    c138:      	blr	x8
    c13c:      	ldr	x8, [sp, #0x98]
    c140:      	cmp	x8, x21
    c144:      	b.eq	0xc20c <generic_lsm_path+0x23bc>
    c148:      	mov	w8, #0x4                // =4
    c14c:      	add	x9, sp, #0x78
    c150:      	add	x0, sp, #0x78
    c154:      	mov	w1, #0x8                // =8
    c158:      	mov	x2, x23
    c15c:      	blr	x8
    c160:      	add	x2, x21, #0x20
    c164:      	mov	w8, #0x4                // =4
    c168:      	mov	w9, #0x10               // =16
    c16c:      	add	x10, sp, #0x80
    c170:      	add	x0, sp, #0x80
    c174:      	mov	w1, #0x10               // =16
    c178:      	blr	x8
    c17c:      	ldr	w21, [sp, #0x84]
    c180:      	ldr	x8, [sp, #0x40]
    c184:      	ldr	x10, [sp, #0x60]
    c188:      	sub	x12, x10, x8
    c18c:      	ldr	w23, [sp, #0x68]
    c190:      	subs	w10, w21, w23
    c194:      	ldr	x9, [sp, #0x88]
    c198:      	csel	w10, wzr, w10, lo
    c19c:      	cmp	w23, w21
    c1a0:      	csel	w11, w23, w21, lo
    c1a4:      	cinc	w13, w11, hi
    c1a8:      	sub	w14, w23, w13
    c1ac:      	subs	x12, x12, x13
    c1b0:      	str	w14, [sp, #0x68]
    c1b4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c1b8:      	cmp	x12, #0xfff
    c1bc:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c1c0:      	cmp	w23, w21
    c1c4:      	b.ls	0xc1d0 <generic_lsm_path+0x2380>
    c1c8:      	mov	w13, #0x2f              // =47
    c1cc:      	strb	w13, [x8, x12]
    c1d0:      	add	x19, x8, x12
    c1d4:      	cmp	w23, w21
    c1d8:      	add	x2, x9, x10
    c1dc:      	and	w1, w11, #0xff
    c1e0:      	mov	w8, #0x4                // =4
    c1e4:      	cinc	x0, x19, hi
    c1e8:      	blr	x8
    c1ec:      	cmp	w23, w21
    c1f0:      	str	x19, [sp, #0x60]
    c1f4:      	add	x19, sp, #0x70
    c1f8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c1fc:      	ldr	x21, [sp, #0x78]
    c200:      	ldp	x2, x24, [sp, #0x50]
    c204:      	str	x21, [sp, #0x48]
    c208:      	b	0xc258 <generic_lsm_path+0x2408>
    c20c:      	add	x2, x24, #0x10
    c210:      	mov	w8, #0x4                // =4
    c214:      	add	x9, sp, #0x98
    c218:      	add	x0, sp, #0x98
    c21c:      	mov	w1, #0x8                // =8
    c220:      	blr	x8
    c224:      	ldr	x8, [sp, #0x58]
    c228:      	ldr	x9, [sp, #0x98]
    c22c:      	cmp	x8, x9
    c230:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c234:      	add	x2, x24, #0x18
    c238:      	mov	w8, #0x4                // =4
    c23c:      	mov	x0, x22
    c240:      	mov	w1, #0x8                // =8
    c244:      	blr	x8
    c248:      	ldr	x24, [sp, #0x98]
    c24c:      	ldr	x21, [sp, #0x48]
    c250:      	add	x2, x24, #0x20
    c254:      	stp	x2, x24, [sp, #0x50]
    c258:      	ldr	x8, [sp, #0x30]
    c25c:      	cmp	x21, x8
    c260:      	b.ne	0xc270 <generic_lsm_path+0x2420>
    c264:      	ldr	x8, [sp, #0x38]
    c268:      	cmp	x2, x8
    c26c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c270:      	mov	w8, #0x4                // =4
    c274:      	add	x0, sp, #0x70
    c278:      	mov	w1, #0x8                // =8
    c27c:      	blr	x8
    c280:      	ldr	x8, [sp, #0x70]
    c284:      	cmp	x21, x8
    c288:      	b.eq	0xc378 <generic_lsm_path+0x2528>
    c28c:      	add	x23, x21, #0x18
    c290:      	mov	w8, #0x4                // =4
    c294:      	add	x9, sp, #0x98
    c298:      	add	x0, sp, #0x98
    c29c:      	mov	w1, #0x8                // =8
    c2a0:      	mov	x2, x23
    c2a4:      	blr	x8
    c2a8:      	ldr	x8, [sp, #0x98]
    c2ac:      	cmp	x8, x21
    c2b0:      	b.eq	0xc378 <generic_lsm_path+0x2528>
    c2b4:      	mov	w8, #0x4                // =4
    c2b8:      	add	x9, sp, #0x78
    c2bc:      	add	x0, sp, #0x78
    c2c0:      	mov	w1, #0x8                // =8
    c2c4:      	mov	x2, x23
    c2c8:      	blr	x8
    c2cc:      	add	x2, x21, #0x20
    c2d0:      	mov	w8, #0x4                // =4
    c2d4:      	mov	w9, #0x10               // =16
    c2d8:      	add	x10, sp, #0x80
    c2dc:      	add	x0, sp, #0x80
    c2e0:      	mov	w1, #0x10               // =16
    c2e4:      	blr	x8
    c2e8:      	ldr	w21, [sp, #0x84]
    c2ec:      	ldr	x8, [sp, #0x40]
    c2f0:      	ldr	x10, [sp, #0x60]
    c2f4:      	sub	x12, x10, x8
    c2f8:      	ldr	w23, [sp, #0x68]
    c2fc:      	subs	w10, w21, w23
    c300:      	ldr	x9, [sp, #0x88]
    c304:      	csel	w10, wzr, w10, lo
    c308:      	cmp	w23, w21
    c30c:      	csel	w11, w23, w21, lo
    c310:      	cinc	w13, w11, hi
    c314:      	sub	w14, w23, w13
    c318:      	subs	x12, x12, x13
    c31c:      	str	w14, [sp, #0x68]
    c320:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c324:      	cmp	x12, #0xfff
    c328:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c32c:      	cmp	w23, w21
    c330:      	b.ls	0xc33c <generic_lsm_path+0x24ec>
    c334:      	mov	w13, #0x2f              // =47
    c338:      	strb	w13, [x8, x12]
    c33c:      	add	x19, x8, x12
    c340:      	cmp	w23, w21
    c344:      	add	x2, x9, x10
    c348:      	and	w1, w11, #0xff
    c34c:      	mov	w8, #0x4                // =4
    c350:      	cinc	x0, x19, hi
    c354:      	blr	x8
    c358:      	cmp	w23, w21
    c35c:      	str	x19, [sp, #0x60]
    c360:      	add	x19, sp, #0x70
    c364:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c368:      	ldr	x21, [sp, #0x78]
    c36c:      	ldp	x2, x24, [sp, #0x50]
    c370:      	str	x21, [sp, #0x48]
    c374:      	b	0xc3c4 <generic_lsm_path+0x2574>
    c378:      	add	x2, x24, #0x10
    c37c:      	mov	w8, #0x4                // =4
    c380:      	add	x9, sp, #0x98
    c384:      	add	x0, sp, #0x98
    c388:      	mov	w1, #0x8                // =8
    c38c:      	blr	x8
    c390:      	ldr	x8, [sp, #0x58]
    c394:      	ldr	x9, [sp, #0x98]
    c398:      	cmp	x8, x9
    c39c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c3a0:      	add	x2, x24, #0x18
    c3a4:      	mov	w8, #0x4                // =4
    c3a8:      	mov	x0, x22
    c3ac:      	mov	w1, #0x8                // =8
    c3b0:      	blr	x8
    c3b4:      	ldr	x24, [sp, #0x98]
    c3b8:      	ldr	x21, [sp, #0x48]
    c3bc:      	add	x2, x24, #0x20
    c3c0:      	stp	x2, x24, [sp, #0x50]
    c3c4:      	ldr	x8, [sp, #0x30]
    c3c8:      	cmp	x21, x8
    c3cc:      	b.ne	0xc3dc <generic_lsm_path+0x258c>
    c3d0:      	ldr	x8, [sp, #0x38]
    c3d4:      	cmp	x2, x8
    c3d8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c3dc:      	mov	w8, #0x4                // =4
    c3e0:      	add	x0, sp, #0x70
    c3e4:      	mov	w1, #0x8                // =8
    c3e8:      	blr	x8
    c3ec:      	ldr	x8, [sp, #0x70]
    c3f0:      	cmp	x21, x8
    c3f4:      	b.eq	0xc4e4 <generic_lsm_path+0x2694>
    c3f8:      	add	x23, x21, #0x18
    c3fc:      	mov	w8, #0x4                // =4
    c400:      	add	x9, sp, #0x98
    c404:      	add	x0, sp, #0x98
    c408:      	mov	w1, #0x8                // =8
    c40c:      	mov	x2, x23
    c410:      	blr	x8
    c414:      	ldr	x8, [sp, #0x98]
    c418:      	cmp	x8, x21
    c41c:      	b.eq	0xc4e4 <generic_lsm_path+0x2694>
    c420:      	mov	w8, #0x4                // =4
    c424:      	add	x9, sp, #0x78
    c428:      	add	x0, sp, #0x78
    c42c:      	mov	w1, #0x8                // =8
    c430:      	mov	x2, x23
    c434:      	blr	x8
    c438:      	add	x2, x21, #0x20
    c43c:      	mov	w8, #0x4                // =4
    c440:      	mov	w9, #0x10               // =16
    c444:      	add	x10, sp, #0x80
    c448:      	add	x0, sp, #0x80
    c44c:      	mov	w1, #0x10               // =16
    c450:      	blr	x8
    c454:      	ldr	w21, [sp, #0x84]
    c458:      	ldr	x8, [sp, #0x40]
    c45c:      	ldr	x10, [sp, #0x60]
    c460:      	sub	x12, x10, x8
    c464:      	ldr	w23, [sp, #0x68]
    c468:      	subs	w10, w21, w23
    c46c:      	ldr	x9, [sp, #0x88]
    c470:      	csel	w10, wzr, w10, lo
    c474:      	cmp	w23, w21
    c478:      	csel	w11, w23, w21, lo
    c47c:      	cinc	w13, w11, hi
    c480:      	sub	w14, w23, w13
    c484:      	subs	x12, x12, x13
    c488:      	str	w14, [sp, #0x68]
    c48c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c490:      	cmp	x12, #0xfff
    c494:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c498:      	cmp	w23, w21
    c49c:      	b.ls	0xc4a8 <generic_lsm_path+0x2658>
    c4a0:      	mov	w13, #0x2f              // =47
    c4a4:      	strb	w13, [x8, x12]
    c4a8:      	add	x19, x8, x12
    c4ac:      	cmp	w23, w21
    c4b0:      	add	x2, x9, x10
    c4b4:      	and	w1, w11, #0xff
    c4b8:      	mov	w8, #0x4                // =4
    c4bc:      	cinc	x0, x19, hi
    c4c0:      	blr	x8
    c4c4:      	cmp	w23, w21
    c4c8:      	str	x19, [sp, #0x60]
    c4cc:      	add	x19, sp, #0x70
    c4d0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c4d4:      	ldr	x21, [sp, #0x78]
    c4d8:      	ldp	x2, x24, [sp, #0x50]
    c4dc:      	str	x21, [sp, #0x48]
    c4e0:      	b	0xc530 <generic_lsm_path+0x26e0>
    c4e4:      	add	x2, x24, #0x10
    c4e8:      	mov	w8, #0x4                // =4
    c4ec:      	add	x9, sp, #0x98
    c4f0:      	add	x0, sp, #0x98
    c4f4:      	mov	w1, #0x8                // =8
    c4f8:      	blr	x8
    c4fc:      	ldr	x8, [sp, #0x58]
    c500:      	ldr	x9, [sp, #0x98]
    c504:      	cmp	x8, x9
    c508:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c50c:      	add	x2, x24, #0x18
    c510:      	mov	w8, #0x4                // =4
    c514:      	mov	x0, x22
    c518:      	mov	w1, #0x8                // =8
    c51c:      	blr	x8
    c520:      	ldr	x24, [sp, #0x98]
    c524:      	ldr	x21, [sp, #0x48]
    c528:      	add	x2, x24, #0x20
    c52c:      	stp	x2, x24, [sp, #0x50]
    c530:      	ldr	x8, [sp, #0x30]
    c534:      	cmp	x21, x8
    c538:      	b.ne	0xc548 <generic_lsm_path+0x26f8>
    c53c:      	ldr	x8, [sp, #0x38]
    c540:      	cmp	x2, x8
    c544:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c548:      	mov	w8, #0x4                // =4
    c54c:      	add	x0, sp, #0x70
    c550:      	mov	w1, #0x8                // =8
    c554:      	blr	x8
    c558:      	ldr	x8, [sp, #0x70]
    c55c:      	cmp	x21, x8
    c560:      	b.eq	0xc650 <generic_lsm_path+0x2800>
    c564:      	add	x23, x21, #0x18
    c568:      	mov	w8, #0x4                // =4
    c56c:      	add	x9, sp, #0x98
    c570:      	add	x0, sp, #0x98
    c574:      	mov	w1, #0x8                // =8
    c578:      	mov	x2, x23
    c57c:      	blr	x8
    c580:      	ldr	x8, [sp, #0x98]
    c584:      	cmp	x8, x21
    c588:      	b.eq	0xc650 <generic_lsm_path+0x2800>
    c58c:      	mov	w8, #0x4                // =4
    c590:      	add	x9, sp, #0x78
    c594:      	add	x0, sp, #0x78
    c598:      	mov	w1, #0x8                // =8
    c59c:      	mov	x2, x23
    c5a0:      	blr	x8
    c5a4:      	add	x2, x21, #0x20
    c5a8:      	mov	w8, #0x4                // =4
    c5ac:      	mov	w9, #0x10               // =16
    c5b0:      	add	x10, sp, #0x80
    c5b4:      	add	x0, sp, #0x80
    c5b8:      	mov	w1, #0x10               // =16
    c5bc:      	blr	x8
    c5c0:      	ldr	w21, [sp, #0x84]
    c5c4:      	ldr	x8, [sp, #0x40]
    c5c8:      	ldr	x10, [sp, #0x60]
    c5cc:      	sub	x12, x10, x8
    c5d0:      	ldr	w23, [sp, #0x68]
    c5d4:      	subs	w10, w21, w23
    c5d8:      	ldr	x9, [sp, #0x88]
    c5dc:      	csel	w10, wzr, w10, lo
    c5e0:      	cmp	w23, w21
    c5e4:      	csel	w11, w23, w21, lo
    c5e8:      	cinc	w13, w11, hi
    c5ec:      	sub	w14, w23, w13
    c5f0:      	subs	x12, x12, x13
    c5f4:      	str	w14, [sp, #0x68]
    c5f8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c5fc:      	cmp	x12, #0xfff
    c600:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c604:      	cmp	w23, w21
    c608:      	b.ls	0xc614 <generic_lsm_path+0x27c4>
    c60c:      	mov	w13, #0x2f              // =47
    c610:      	strb	w13, [x8, x12]
    c614:      	add	x19, x8, x12
    c618:      	cmp	w23, w21
    c61c:      	add	x2, x9, x10
    c620:      	and	w1, w11, #0xff
    c624:      	mov	w8, #0x4                // =4
    c628:      	cinc	x0, x19, hi
    c62c:      	blr	x8
    c630:      	cmp	w23, w21
    c634:      	str	x19, [sp, #0x60]
    c638:      	add	x19, sp, #0x70
    c63c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c640:      	ldr	x21, [sp, #0x78]
    c644:      	ldp	x2, x24, [sp, #0x50]
    c648:      	str	x21, [sp, #0x48]
    c64c:      	b	0xc69c <generic_lsm_path+0x284c>
    c650:      	add	x2, x24, #0x10
    c654:      	mov	w8, #0x4                // =4
    c658:      	add	x9, sp, #0x98
    c65c:      	add	x0, sp, #0x98
    c660:      	mov	w1, #0x8                // =8
    c664:      	blr	x8
    c668:      	ldr	x8, [sp, #0x58]
    c66c:      	ldr	x9, [sp, #0x98]
    c670:      	cmp	x8, x9
    c674:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c678:      	add	x2, x24, #0x18
    c67c:      	mov	w8, #0x4                // =4
    c680:      	mov	x0, x22
    c684:      	mov	w1, #0x8                // =8
    c688:      	blr	x8
    c68c:      	ldr	x24, [sp, #0x98]
    c690:      	ldr	x21, [sp, #0x48]
    c694:      	add	x2, x24, #0x20
    c698:      	stp	x2, x24, [sp, #0x50]
    c69c:      	ldr	x8, [sp, #0x30]
    c6a0:      	cmp	x21, x8
    c6a4:      	b.ne	0xc6b4 <generic_lsm_path+0x2864>
    c6a8:      	ldr	x8, [sp, #0x38]
    c6ac:      	cmp	x2, x8
    c6b0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c6b4:      	mov	w8, #0x4                // =4
    c6b8:      	add	x0, sp, #0x70
    c6bc:      	mov	w1, #0x8                // =8
    c6c0:      	blr	x8
    c6c4:      	ldr	x8, [sp, #0x70]
    c6c8:      	cmp	x21, x8
    c6cc:      	b.eq	0xc7bc <generic_lsm_path+0x296c>
    c6d0:      	add	x23, x21, #0x18
    c6d4:      	mov	w8, #0x4                // =4
    c6d8:      	add	x9, sp, #0x98
    c6dc:      	add	x0, sp, #0x98
    c6e0:      	mov	w1, #0x8                // =8
    c6e4:      	mov	x2, x23
    c6e8:      	blr	x8
    c6ec:      	ldr	x8, [sp, #0x98]
    c6f0:      	cmp	x8, x21
    c6f4:      	b.eq	0xc7bc <generic_lsm_path+0x296c>
    c6f8:      	mov	w8, #0x4                // =4
    c6fc:      	add	x9, sp, #0x78
    c700:      	add	x0, sp, #0x78
    c704:      	mov	w1, #0x8                // =8
    c708:      	mov	x2, x23
    c70c:      	blr	x8
    c710:      	add	x2, x21, #0x20
    c714:      	mov	w8, #0x4                // =4
    c718:      	mov	w9, #0x10               // =16
    c71c:      	add	x10, sp, #0x80
    c720:      	add	x0, sp, #0x80
    c724:      	mov	w1, #0x10               // =16
    c728:      	blr	x8
    c72c:      	ldr	w21, [sp, #0x84]
    c730:      	ldr	x8, [sp, #0x40]
    c734:      	ldr	x10, [sp, #0x60]
    c738:      	sub	x12, x10, x8
    c73c:      	ldr	w23, [sp, #0x68]
    c740:      	subs	w10, w21, w23
    c744:      	ldr	x9, [sp, #0x88]
    c748:      	csel	w10, wzr, w10, lo
    c74c:      	cmp	w23, w21
    c750:      	csel	w11, w23, w21, lo
    c754:      	cinc	w13, w11, hi
    c758:      	sub	w14, w23, w13
    c75c:      	subs	x12, x12, x13
    c760:      	str	w14, [sp, #0x68]
    c764:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c768:      	cmp	x12, #0xfff
    c76c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c770:      	cmp	w23, w21
    c774:      	b.ls	0xc780 <generic_lsm_path+0x2930>
    c778:      	mov	w13, #0x2f              // =47
    c77c:      	strb	w13, [x8, x12]
    c780:      	add	x19, x8, x12
    c784:      	cmp	w23, w21
    c788:      	add	x2, x9, x10
    c78c:      	and	w1, w11, #0xff
    c790:      	mov	w8, #0x4                // =4
    c794:      	cinc	x0, x19, hi
    c798:      	blr	x8
    c79c:      	cmp	w23, w21
    c7a0:      	str	x19, [sp, #0x60]
    c7a4:      	add	x19, sp, #0x70
    c7a8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c7ac:      	ldr	x21, [sp, #0x78]
    c7b0:      	ldp	x2, x24, [sp, #0x50]
    c7b4:      	str	x21, [sp, #0x48]
    c7b8:      	b	0xc808 <generic_lsm_path+0x29b8>
    c7bc:      	add	x2, x24, #0x10
    c7c0:      	mov	w8, #0x4                // =4
    c7c4:      	add	x9, sp, #0x98
    c7c8:      	add	x0, sp, #0x98
    c7cc:      	mov	w1, #0x8                // =8
    c7d0:      	blr	x8
    c7d4:      	ldr	x8, [sp, #0x58]
    c7d8:      	ldr	x9, [sp, #0x98]
    c7dc:      	cmp	x8, x9
    c7e0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c7e4:      	add	x2, x24, #0x18
    c7e8:      	mov	w8, #0x4                // =4
    c7ec:      	mov	x0, x22
    c7f0:      	mov	w1, #0x8                // =8
    c7f4:      	blr	x8
    c7f8:      	ldr	x24, [sp, #0x98]
    c7fc:      	ldr	x21, [sp, #0x48]
    c800:      	add	x2, x24, #0x20
    c804:      	stp	x2, x24, [sp, #0x50]
    c808:      	ldr	x8, [sp, #0x30]
    c80c:      	cmp	x21, x8
    c810:      	b.ne	0xc820 <generic_lsm_path+0x29d0>
    c814:      	ldr	x8, [sp, #0x38]
    c818:      	cmp	x2, x8
    c81c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c820:      	mov	w8, #0x4                // =4
    c824:      	add	x0, sp, #0x70
    c828:      	mov	w1, #0x8                // =8
    c82c:      	blr	x8
    c830:      	ldr	x8, [sp, #0x70]
    c834:      	cmp	x21, x8
    c838:      	b.eq	0xc928 <generic_lsm_path+0x2ad8>
    c83c:      	add	x23, x21, #0x18
    c840:      	mov	w8, #0x4                // =4
    c844:      	add	x9, sp, #0x98
    c848:      	add	x0, sp, #0x98
    c84c:      	mov	w1, #0x8                // =8
    c850:      	mov	x2, x23
    c854:      	blr	x8
    c858:      	ldr	x8, [sp, #0x98]
    c85c:      	cmp	x8, x21
    c860:      	b.eq	0xc928 <generic_lsm_path+0x2ad8>
    c864:      	mov	w8, #0x4                // =4
    c868:      	add	x9, sp, #0x78
    c86c:      	add	x0, sp, #0x78
    c870:      	mov	w1, #0x8                // =8
    c874:      	mov	x2, x23
    c878:      	blr	x8
    c87c:      	add	x2, x21, #0x20
    c880:      	mov	w8, #0x4                // =4
    c884:      	mov	w9, #0x10               // =16
    c888:      	add	x10, sp, #0x80
    c88c:      	add	x0, sp, #0x80
    c890:      	mov	w1, #0x10               // =16
    c894:      	blr	x8
    c898:      	ldr	w21, [sp, #0x84]
    c89c:      	ldr	x8, [sp, #0x40]
    c8a0:      	ldr	x10, [sp, #0x60]
    c8a4:      	sub	x12, x10, x8
    c8a8:      	ldr	w23, [sp, #0x68]
    c8ac:      	subs	w10, w21, w23
    c8b0:      	ldr	x9, [sp, #0x88]
    c8b4:      	csel	w10, wzr, w10, lo
    c8b8:      	cmp	w23, w21
    c8bc:      	csel	w11, w23, w21, lo
    c8c0:      	cinc	w13, w11, hi
    c8c4:      	sub	w14, w23, w13
    c8c8:      	subs	x12, x12, x13
    c8cc:      	str	w14, [sp, #0x68]
    c8d0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    c8d4:      	cmp	x12, #0xfff
    c8d8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    c8dc:      	cmp	w23, w21
    c8e0:      	b.ls	0xc8ec <generic_lsm_path+0x2a9c>
    c8e4:      	mov	w13, #0x2f              // =47
    c8e8:      	strb	w13, [x8, x12]
    c8ec:      	add	x19, x8, x12
    c8f0:      	cmp	w23, w21
    c8f4:      	add	x2, x9, x10
    c8f8:      	and	w1, w11, #0xff
    c8fc:      	mov	w8, #0x4                // =4
    c900:      	cinc	x0, x19, hi
    c904:      	blr	x8
    c908:      	cmp	w23, w21
    c90c:      	str	x19, [sp, #0x60]
    c910:      	add	x19, sp, #0x70
    c914:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    c918:      	ldr	x21, [sp, #0x78]
    c91c:      	ldp	x2, x24, [sp, #0x50]
    c920:      	str	x21, [sp, #0x48]
    c924:      	b	0xc974 <generic_lsm_path+0x2b24>
    c928:      	add	x2, x24, #0x10
    c92c:      	mov	w8, #0x4                // =4
    c930:      	add	x9, sp, #0x98
    c934:      	add	x0, sp, #0x98
    c938:      	mov	w1, #0x8                // =8
    c93c:      	blr	x8
    c940:      	ldr	x8, [sp, #0x58]
    c944:      	ldr	x9, [sp, #0x98]
    c948:      	cmp	x8, x9
    c94c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c950:      	add	x2, x24, #0x18
    c954:      	mov	w8, #0x4                // =4
    c958:      	mov	x0, x22
    c95c:      	mov	w1, #0x8                // =8
    c960:      	blr	x8
    c964:      	ldr	x24, [sp, #0x98]
    c968:      	ldr	x21, [sp, #0x48]
    c96c:      	add	x2, x24, #0x20
    c970:      	stp	x2, x24, [sp, #0x50]
    c974:      	ldr	x8, [sp, #0x30]
    c978:      	cmp	x21, x8
    c97c:      	b.ne	0xc98c <generic_lsm_path+0x2b3c>
    c980:      	ldr	x8, [sp, #0x38]
    c984:      	cmp	x2, x8
    c988:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    c98c:      	mov	w8, #0x4                // =4
    c990:      	add	x0, sp, #0x70
    c994:      	mov	w1, #0x8                // =8
    c998:      	blr	x8
    c99c:      	ldr	x8, [sp, #0x70]
    c9a0:      	cmp	x21, x8
    c9a4:      	b.eq	0xca94 <generic_lsm_path+0x2c44>
    c9a8:      	add	x23, x21, #0x18
    c9ac:      	mov	w8, #0x4                // =4
    c9b0:      	add	x9, sp, #0x98
    c9b4:      	add	x0, sp, #0x98
    c9b8:      	mov	w1, #0x8                // =8
    c9bc:      	mov	x2, x23
    c9c0:      	blr	x8
    c9c4:      	ldr	x8, [sp, #0x98]
    c9c8:      	cmp	x8, x21
    c9cc:      	b.eq	0xca94 <generic_lsm_path+0x2c44>
    c9d0:      	mov	w8, #0x4                // =4
    c9d4:      	add	x9, sp, #0x78
    c9d8:      	add	x0, sp, #0x78
    c9dc:      	mov	w1, #0x8                // =8
    c9e0:      	mov	x2, x23
    c9e4:      	blr	x8
    c9e8:      	add	x2, x21, #0x20
    c9ec:      	mov	w8, #0x4                // =4
    c9f0:      	mov	w9, #0x10               // =16
    c9f4:      	add	x10, sp, #0x80
    c9f8:      	add	x0, sp, #0x80
    c9fc:      	mov	w1, #0x10               // =16
    ca00:      	blr	x8
    ca04:      	ldr	w21, [sp, #0x84]
    ca08:      	ldr	x8, [sp, #0x40]
    ca0c:      	ldr	x10, [sp, #0x60]
    ca10:      	sub	x12, x10, x8
    ca14:      	ldr	w23, [sp, #0x68]
    ca18:      	subs	w10, w21, w23
    ca1c:      	ldr	x9, [sp, #0x88]
    ca20:      	csel	w10, wzr, w10, lo
    ca24:      	cmp	w23, w21
    ca28:      	csel	w11, w23, w21, lo
    ca2c:      	cinc	w13, w11, hi
    ca30:      	sub	w14, w23, w13
    ca34:      	subs	x12, x12, x13
    ca38:      	str	w14, [sp, #0x68]
    ca3c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    ca40:      	cmp	x12, #0xfff
    ca44:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    ca48:      	cmp	w23, w21
    ca4c:      	b.ls	0xca58 <generic_lsm_path+0x2c08>
    ca50:      	mov	w13, #0x2f              // =47
    ca54:      	strb	w13, [x8, x12]
    ca58:      	add	x19, x8, x12
    ca5c:      	cmp	w23, w21
    ca60:      	add	x2, x9, x10
    ca64:      	and	w1, w11, #0xff
    ca68:      	mov	w8, #0x4                // =4
    ca6c:      	cinc	x0, x19, hi
    ca70:      	blr	x8
    ca74:      	cmp	w23, w21
    ca78:      	str	x19, [sp, #0x60]
    ca7c:      	add	x19, sp, #0x70
    ca80:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ca84:      	ldr	x21, [sp, #0x78]
    ca88:      	ldp	x2, x24, [sp, #0x50]
    ca8c:      	str	x21, [sp, #0x48]
    ca90:      	b	0xcae0 <generic_lsm_path+0x2c90>
    ca94:      	add	x2, x24, #0x10
    ca98:      	mov	w8, #0x4                // =4
    ca9c:      	add	x9, sp, #0x98
    caa0:      	add	x0, sp, #0x98
    caa4:      	mov	w1, #0x8                // =8
    caa8:      	blr	x8
    caac:      	ldr	x8, [sp, #0x58]
    cab0:      	ldr	x9, [sp, #0x98]
    cab4:      	cmp	x8, x9
    cab8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cabc:      	add	x2, x24, #0x18
    cac0:      	mov	w8, #0x4                // =4
    cac4:      	mov	x0, x22
    cac8:      	mov	w1, #0x8                // =8
    cacc:      	blr	x8
    cad0:      	ldr	x24, [sp, #0x98]
    cad4:      	ldr	x21, [sp, #0x48]
    cad8:      	add	x2, x24, #0x20
    cadc:      	stp	x2, x24, [sp, #0x50]
    cae0:      	ldr	x8, [sp, #0x30]
    cae4:      	cmp	x21, x8
    cae8:      	b.ne	0xcaf8 <generic_lsm_path+0x2ca8>
    caec:      	ldr	x8, [sp, #0x38]
    caf0:      	cmp	x2, x8
    caf4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    caf8:      	mov	w8, #0x4                // =4
    cafc:      	add	x0, sp, #0x70
    cb00:      	mov	w1, #0x8                // =8
    cb04:      	blr	x8
    cb08:      	ldr	x8, [sp, #0x70]
    cb0c:      	cmp	x21, x8
    cb10:      	b.eq	0xcc00 <generic_lsm_path+0x2db0>
    cb14:      	add	x23, x21, #0x18
    cb18:      	mov	w8, #0x4                // =4
    cb1c:      	add	x9, sp, #0x98
    cb20:      	add	x0, sp, #0x98
    cb24:      	mov	w1, #0x8                // =8
    cb28:      	mov	x2, x23
    cb2c:      	blr	x8
    cb30:      	ldr	x8, [sp, #0x98]
    cb34:      	cmp	x8, x21
    cb38:      	b.eq	0xcc00 <generic_lsm_path+0x2db0>
    cb3c:      	mov	w8, #0x4                // =4
    cb40:      	add	x9, sp, #0x78
    cb44:      	add	x0, sp, #0x78
    cb48:      	mov	w1, #0x8                // =8
    cb4c:      	mov	x2, x23
    cb50:      	blr	x8
    cb54:      	add	x2, x21, #0x20
    cb58:      	mov	w8, #0x4                // =4
    cb5c:      	mov	w9, #0x10               // =16
    cb60:      	add	x10, sp, #0x80
    cb64:      	add	x0, sp, #0x80
    cb68:      	mov	w1, #0x10               // =16
    cb6c:      	blr	x8
    cb70:      	ldr	w21, [sp, #0x84]
    cb74:      	ldr	x8, [sp, #0x40]
    cb78:      	ldr	x10, [sp, #0x60]
    cb7c:      	sub	x12, x10, x8
    cb80:      	ldr	w23, [sp, #0x68]
    cb84:      	subs	w10, w21, w23
    cb88:      	ldr	x9, [sp, #0x88]
    cb8c:      	csel	w10, wzr, w10, lo
    cb90:      	cmp	w23, w21
    cb94:      	csel	w11, w23, w21, lo
    cb98:      	cinc	w13, w11, hi
    cb9c:      	sub	w14, w23, w13
    cba0:      	subs	x12, x12, x13
    cba4:      	str	w14, [sp, #0x68]
    cba8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    cbac:      	cmp	x12, #0xfff
    cbb0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    cbb4:      	cmp	w23, w21
    cbb8:      	b.ls	0xcbc4 <generic_lsm_path+0x2d74>
    cbbc:      	mov	w13, #0x2f              // =47
    cbc0:      	strb	w13, [x8, x12]
    cbc4:      	add	x19, x8, x12
    cbc8:      	cmp	w23, w21
    cbcc:      	add	x2, x9, x10
    cbd0:      	and	w1, w11, #0xff
    cbd4:      	mov	w8, #0x4                // =4
    cbd8:      	cinc	x0, x19, hi
    cbdc:      	blr	x8
    cbe0:      	cmp	w23, w21
    cbe4:      	str	x19, [sp, #0x60]
    cbe8:      	add	x19, sp, #0x70
    cbec:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    cbf0:      	ldr	x21, [sp, #0x78]
    cbf4:      	ldp	x2, x24, [sp, #0x50]
    cbf8:      	str	x21, [sp, #0x48]
    cbfc:      	b	0xcc4c <generic_lsm_path+0x2dfc>
    cc00:      	add	x2, x24, #0x10
    cc04:      	mov	w8, #0x4                // =4
    cc08:      	add	x9, sp, #0x98
    cc0c:      	add	x0, sp, #0x98
    cc10:      	mov	w1, #0x8                // =8
    cc14:      	blr	x8
    cc18:      	ldr	x8, [sp, #0x58]
    cc1c:      	ldr	x9, [sp, #0x98]
    cc20:      	cmp	x8, x9
    cc24:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cc28:      	add	x2, x24, #0x18
    cc2c:      	mov	w8, #0x4                // =4
    cc30:      	mov	x0, x22
    cc34:      	mov	w1, #0x8                // =8
    cc38:      	blr	x8
    cc3c:      	ldr	x24, [sp, #0x98]
    cc40:      	ldr	x21, [sp, #0x48]
    cc44:      	add	x2, x24, #0x20
    cc48:      	stp	x2, x24, [sp, #0x50]
    cc4c:      	ldr	x8, [sp, #0x30]
    cc50:      	cmp	x21, x8
    cc54:      	b.ne	0xcc64 <generic_lsm_path+0x2e14>
    cc58:      	ldr	x8, [sp, #0x38]
    cc5c:      	cmp	x2, x8
    cc60:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cc64:      	mov	w8, #0x4                // =4
    cc68:      	add	x0, sp, #0x70
    cc6c:      	mov	w1, #0x8                // =8
    cc70:      	blr	x8
    cc74:      	ldr	x8, [sp, #0x70]
    cc78:      	cmp	x21, x8
    cc7c:      	b.eq	0xcd6c <generic_lsm_path+0x2f1c>
    cc80:      	add	x23, x21, #0x18
    cc84:      	mov	w8, #0x4                // =4
    cc88:      	add	x9, sp, #0x98
    cc8c:      	add	x0, sp, #0x98
    cc90:      	mov	w1, #0x8                // =8
    cc94:      	mov	x2, x23
    cc98:      	blr	x8
    cc9c:      	ldr	x8, [sp, #0x98]
    cca0:      	cmp	x8, x21
    cca4:      	b.eq	0xcd6c <generic_lsm_path+0x2f1c>
    cca8:      	mov	w8, #0x4                // =4
    ccac:      	add	x9, sp, #0x78
    ccb0:      	add	x0, sp, #0x78
    ccb4:      	mov	w1, #0x8                // =8
    ccb8:      	mov	x2, x23
    ccbc:      	blr	x8
    ccc0:      	add	x2, x21, #0x20
    ccc4:      	mov	w8, #0x4                // =4
    ccc8:      	mov	w9, #0x10               // =16
    cccc:      	add	x10, sp, #0x80
    ccd0:      	add	x0, sp, #0x80
    ccd4:      	mov	w1, #0x10               // =16
    ccd8:      	blr	x8
    ccdc:      	ldr	w21, [sp, #0x84]
    cce0:      	ldr	x8, [sp, #0x40]
    cce4:      	ldr	x10, [sp, #0x60]
    cce8:      	sub	x12, x10, x8
    ccec:      	ldr	w23, [sp, #0x68]
    ccf0:      	subs	w10, w21, w23
    ccf4:      	ldr	x9, [sp, #0x88]
    ccf8:      	csel	w10, wzr, w10, lo
    ccfc:      	cmp	w23, w21
    cd00:      	csel	w11, w23, w21, lo
    cd04:      	cinc	w13, w11, hi
    cd08:      	sub	w14, w23, w13
    cd0c:      	subs	x12, x12, x13
    cd10:      	str	w14, [sp, #0x68]
    cd14:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    cd18:      	cmp	x12, #0xfff
    cd1c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    cd20:      	cmp	w23, w21
    cd24:      	b.ls	0xcd30 <generic_lsm_path+0x2ee0>
    cd28:      	mov	w13, #0x2f              // =47
    cd2c:      	strb	w13, [x8, x12]
    cd30:      	add	x19, x8, x12
    cd34:      	cmp	w23, w21
    cd38:      	add	x2, x9, x10
    cd3c:      	and	w1, w11, #0xff
    cd40:      	mov	w8, #0x4                // =4
    cd44:      	cinc	x0, x19, hi
    cd48:      	blr	x8
    cd4c:      	cmp	w23, w21
    cd50:      	str	x19, [sp, #0x60]
    cd54:      	add	x19, sp, #0x70
    cd58:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    cd5c:      	ldr	x21, [sp, #0x78]
    cd60:      	ldp	x2, x24, [sp, #0x50]
    cd64:      	str	x21, [sp, #0x48]
    cd68:      	b	0xcdb8 <generic_lsm_path+0x2f68>
    cd6c:      	add	x2, x24, #0x10
    cd70:      	mov	w8, #0x4                // =4
    cd74:      	add	x9, sp, #0x98
    cd78:      	add	x0, sp, #0x98
    cd7c:      	mov	w1, #0x8                // =8
    cd80:      	blr	x8
    cd84:      	ldr	x8, [sp, #0x58]
    cd88:      	ldr	x9, [sp, #0x98]
    cd8c:      	cmp	x8, x9
    cd90:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cd94:      	add	x2, x24, #0x18
    cd98:      	mov	w8, #0x4                // =4
    cd9c:      	mov	x0, x22
    cda0:      	mov	w1, #0x8                // =8
    cda4:      	blr	x8
    cda8:      	ldr	x24, [sp, #0x98]
    cdac:      	ldr	x21, [sp, #0x48]
    cdb0:      	add	x2, x24, #0x20
    cdb4:      	stp	x2, x24, [sp, #0x50]
    cdb8:      	ldr	x8, [sp, #0x30]
    cdbc:      	cmp	x21, x8
    cdc0:      	b.ne	0xcdd0 <generic_lsm_path+0x2f80>
    cdc4:      	ldr	x8, [sp, #0x38]
    cdc8:      	cmp	x2, x8
    cdcc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cdd0:      	mov	w8, #0x4                // =4
    cdd4:      	add	x0, sp, #0x70
    cdd8:      	mov	w1, #0x8                // =8
    cddc:      	blr	x8
    cde0:      	ldr	x8, [sp, #0x70]
    cde4:      	cmp	x21, x8
    cde8:      	b.eq	0xced8 <generic_lsm_path+0x3088>
    cdec:      	add	x23, x21, #0x18
    cdf0:      	mov	w8, #0x4                // =4
    cdf4:      	add	x9, sp, #0x98
    cdf8:      	add	x0, sp, #0x98
    cdfc:      	mov	w1, #0x8                // =8
    ce00:      	mov	x2, x23
    ce04:      	blr	x8
    ce08:      	ldr	x8, [sp, #0x98]
    ce0c:      	cmp	x8, x21
    ce10:      	b.eq	0xced8 <generic_lsm_path+0x3088>
    ce14:      	mov	w8, #0x4                // =4
    ce18:      	add	x9, sp, #0x78
    ce1c:      	add	x0, sp, #0x78
    ce20:      	mov	w1, #0x8                // =8
    ce24:      	mov	x2, x23
    ce28:      	blr	x8
    ce2c:      	add	x2, x21, #0x20
    ce30:      	mov	w8, #0x4                // =4
    ce34:      	mov	w9, #0x10               // =16
    ce38:      	add	x10, sp, #0x80
    ce3c:      	add	x0, sp, #0x80
    ce40:      	mov	w1, #0x10               // =16
    ce44:      	blr	x8
    ce48:      	ldr	w21, [sp, #0x84]
    ce4c:      	ldr	x8, [sp, #0x40]
    ce50:      	ldr	x10, [sp, #0x60]
    ce54:      	sub	x12, x10, x8
    ce58:      	ldr	w23, [sp, #0x68]
    ce5c:      	subs	w10, w21, w23
    ce60:      	ldr	x9, [sp, #0x88]
    ce64:      	csel	w10, wzr, w10, lo
    ce68:      	cmp	w23, w21
    ce6c:      	csel	w11, w23, w21, lo
    ce70:      	cinc	w13, w11, hi
    ce74:      	sub	w14, w23, w13
    ce78:      	subs	x12, x12, x13
    ce7c:      	str	w14, [sp, #0x68]
    ce80:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    ce84:      	cmp	x12, #0xfff
    ce88:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    ce8c:      	cmp	w23, w21
    ce90:      	b.ls	0xce9c <generic_lsm_path+0x304c>
    ce94:      	mov	w13, #0x2f              // =47
    ce98:      	strb	w13, [x8, x12]
    ce9c:      	add	x19, x8, x12
    cea0:      	cmp	w23, w21
    cea4:      	add	x2, x9, x10
    cea8:      	and	w1, w11, #0xff
    ceac:      	mov	w8, #0x4                // =4
    ceb0:      	cinc	x0, x19, hi
    ceb4:      	blr	x8
    ceb8:      	cmp	w23, w21
    cebc:      	str	x19, [sp, #0x60]
    cec0:      	add	x19, sp, #0x70
    cec4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    cec8:      	ldr	x21, [sp, #0x78]
    cecc:      	ldp	x2, x24, [sp, #0x50]
    ced0:      	str	x21, [sp, #0x48]
    ced4:      	b	0xcf24 <generic_lsm_path+0x30d4>
    ced8:      	add	x2, x24, #0x10
    cedc:      	mov	w8, #0x4                // =4
    cee0:      	add	x9, sp, #0x98
    cee4:      	add	x0, sp, #0x98
    cee8:      	mov	w1, #0x8                // =8
    ceec:      	blr	x8
    cef0:      	ldr	x8, [sp, #0x58]
    cef4:      	ldr	x9, [sp, #0x98]
    cef8:      	cmp	x8, x9
    cefc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cf00:      	add	x2, x24, #0x18
    cf04:      	mov	w8, #0x4                // =4
    cf08:      	mov	x0, x22
    cf0c:      	mov	w1, #0x8                // =8
    cf10:      	blr	x8
    cf14:      	ldr	x24, [sp, #0x98]
    cf18:      	ldr	x21, [sp, #0x48]
    cf1c:      	add	x2, x24, #0x20
    cf20:      	stp	x2, x24, [sp, #0x50]
    cf24:      	ldr	x8, [sp, #0x30]
    cf28:      	cmp	x21, x8
    cf2c:      	b.ne	0xcf3c <generic_lsm_path+0x30ec>
    cf30:      	ldr	x8, [sp, #0x38]
    cf34:      	cmp	x2, x8
    cf38:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    cf3c:      	mov	w8, #0x4                // =4
    cf40:      	add	x0, sp, #0x70
    cf44:      	mov	w1, #0x8                // =8
    cf48:      	blr	x8
    cf4c:      	ldr	x8, [sp, #0x70]
    cf50:      	cmp	x21, x8
    cf54:      	b.eq	0xd044 <generic_lsm_path+0x31f4>
    cf58:      	add	x23, x21, #0x18
    cf5c:      	mov	w8, #0x4                // =4
    cf60:      	add	x9, sp, #0x98
    cf64:      	add	x0, sp, #0x98
    cf68:      	mov	w1, #0x8                // =8
    cf6c:      	mov	x2, x23
    cf70:      	blr	x8
    cf74:      	ldr	x8, [sp, #0x98]
    cf78:      	cmp	x8, x21
    cf7c:      	b.eq	0xd044 <generic_lsm_path+0x31f4>
    cf80:      	mov	w8, #0x4                // =4
    cf84:      	add	x9, sp, #0x78
    cf88:      	add	x0, sp, #0x78
    cf8c:      	mov	w1, #0x8                // =8
    cf90:      	mov	x2, x23
    cf94:      	blr	x8
    cf98:      	add	x2, x21, #0x20
    cf9c:      	mov	w8, #0x4                // =4
    cfa0:      	mov	w9, #0x10               // =16
    cfa4:      	add	x10, sp, #0x80
    cfa8:      	add	x0, sp, #0x80
    cfac:      	mov	w1, #0x10               // =16
    cfb0:      	blr	x8
    cfb4:      	ldr	w21, [sp, #0x84]
    cfb8:      	ldr	x8, [sp, #0x40]
    cfbc:      	ldr	x10, [sp, #0x60]
    cfc0:      	sub	x12, x10, x8
    cfc4:      	ldr	w23, [sp, #0x68]
    cfc8:      	subs	w10, w21, w23
    cfcc:      	ldr	x9, [sp, #0x88]
    cfd0:      	csel	w10, wzr, w10, lo
    cfd4:      	cmp	w23, w21
    cfd8:      	csel	w11, w23, w21, lo
    cfdc:      	cinc	w13, w11, hi
    cfe0:      	sub	w14, w23, w13
    cfe4:      	subs	x12, x12, x13
    cfe8:      	str	w14, [sp, #0x68]
    cfec:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    cff0:      	cmp	x12, #0xfff
    cff4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    cff8:      	cmp	w23, w21
    cffc:      	b.ls	0xd008 <generic_lsm_path+0x31b8>
    d000:      	mov	w13, #0x2f              // =47
    d004:      	strb	w13, [x8, x12]
    d008:      	add	x19, x8, x12
    d00c:      	cmp	w23, w21
    d010:      	add	x2, x9, x10
    d014:      	and	w1, w11, #0xff
    d018:      	mov	w8, #0x4                // =4
    d01c:      	cinc	x0, x19, hi
    d020:      	blr	x8
    d024:      	cmp	w23, w21
    d028:      	str	x19, [sp, #0x60]
    d02c:      	add	x19, sp, #0x70
    d030:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d034:      	ldr	x21, [sp, #0x78]
    d038:      	ldp	x2, x24, [sp, #0x50]
    d03c:      	str	x21, [sp, #0x48]
    d040:      	b	0xd090 <generic_lsm_path+0x3240>
    d044:      	add	x2, x24, #0x10
    d048:      	mov	w8, #0x4                // =4
    d04c:      	add	x9, sp, #0x98
    d050:      	add	x0, sp, #0x98
    d054:      	mov	w1, #0x8                // =8
    d058:      	blr	x8
    d05c:      	ldr	x8, [sp, #0x58]
    d060:      	ldr	x9, [sp, #0x98]
    d064:      	cmp	x8, x9
    d068:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d06c:      	add	x2, x24, #0x18
    d070:      	mov	w8, #0x4                // =4
    d074:      	mov	x0, x22
    d078:      	mov	w1, #0x8                // =8
    d07c:      	blr	x8
    d080:      	ldr	x24, [sp, #0x98]
    d084:      	ldr	x21, [sp, #0x48]
    d088:      	add	x2, x24, #0x20
    d08c:      	stp	x2, x24, [sp, #0x50]
    d090:      	ldr	x8, [sp, #0x30]
    d094:      	cmp	x21, x8
    d098:      	b.ne	0xd0a8 <generic_lsm_path+0x3258>
    d09c:      	ldr	x8, [sp, #0x38]
    d0a0:      	cmp	x2, x8
    d0a4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d0a8:      	mov	w8, #0x4                // =4
    d0ac:      	add	x0, sp, #0x70
    d0b0:      	mov	w1, #0x8                // =8
    d0b4:      	blr	x8
    d0b8:      	ldr	x8, [sp, #0x70]
    d0bc:      	cmp	x21, x8
    d0c0:      	b.eq	0xd1b0 <generic_lsm_path+0x3360>
    d0c4:      	add	x23, x21, #0x18
    d0c8:      	mov	w8, #0x4                // =4
    d0cc:      	add	x9, sp, #0x98
    d0d0:      	add	x0, sp, #0x98
    d0d4:      	mov	w1, #0x8                // =8
    d0d8:      	mov	x2, x23
    d0dc:      	blr	x8
    d0e0:      	ldr	x8, [sp, #0x98]
    d0e4:      	cmp	x8, x21
    d0e8:      	b.eq	0xd1b0 <generic_lsm_path+0x3360>
    d0ec:      	mov	w8, #0x4                // =4
    d0f0:      	add	x9, sp, #0x78
    d0f4:      	add	x0, sp, #0x78
    d0f8:      	mov	w1, #0x8                // =8
    d0fc:      	mov	x2, x23
    d100:      	blr	x8
    d104:      	add	x2, x21, #0x20
    d108:      	mov	w8, #0x4                // =4
    d10c:      	mov	w9, #0x10               // =16
    d110:      	add	x10, sp, #0x80
    d114:      	add	x0, sp, #0x80
    d118:      	mov	w1, #0x10               // =16
    d11c:      	blr	x8
    d120:      	ldr	w21, [sp, #0x84]
    d124:      	ldr	x8, [sp, #0x40]
    d128:      	ldr	x10, [sp, #0x60]
    d12c:      	sub	x12, x10, x8
    d130:      	ldr	w23, [sp, #0x68]
    d134:      	subs	w10, w21, w23
    d138:      	ldr	x9, [sp, #0x88]
    d13c:      	csel	w10, wzr, w10, lo
    d140:      	cmp	w23, w21
    d144:      	csel	w11, w23, w21, lo
    d148:      	cinc	w13, w11, hi
    d14c:      	sub	w14, w23, w13
    d150:      	subs	x12, x12, x13
    d154:      	str	w14, [sp, #0x68]
    d158:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d15c:      	cmp	x12, #0xfff
    d160:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d164:      	cmp	w23, w21
    d168:      	b.ls	0xd174 <generic_lsm_path+0x3324>
    d16c:      	mov	w13, #0x2f              // =47
    d170:      	strb	w13, [x8, x12]
    d174:      	add	x19, x8, x12
    d178:      	cmp	w23, w21
    d17c:      	add	x2, x9, x10
    d180:      	and	w1, w11, #0xff
    d184:      	mov	w8, #0x4                // =4
    d188:      	cinc	x0, x19, hi
    d18c:      	blr	x8
    d190:      	cmp	w23, w21
    d194:      	str	x19, [sp, #0x60]
    d198:      	add	x19, sp, #0x70
    d19c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d1a0:      	ldr	x21, [sp, #0x78]
    d1a4:      	ldp	x2, x24, [sp, #0x50]
    d1a8:      	str	x21, [sp, #0x48]
    d1ac:      	b	0xd1fc <generic_lsm_path+0x33ac>
    d1b0:      	add	x2, x24, #0x10
    d1b4:      	mov	w8, #0x4                // =4
    d1b8:      	add	x9, sp, #0x98
    d1bc:      	add	x0, sp, #0x98
    d1c0:      	mov	w1, #0x8                // =8
    d1c4:      	blr	x8
    d1c8:      	ldr	x8, [sp, #0x58]
    d1cc:      	ldr	x9, [sp, #0x98]
    d1d0:      	cmp	x8, x9
    d1d4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d1d8:      	add	x2, x24, #0x18
    d1dc:      	mov	w8, #0x4                // =4
    d1e0:      	mov	x0, x22
    d1e4:      	mov	w1, #0x8                // =8
    d1e8:      	blr	x8
    d1ec:      	ldr	x24, [sp, #0x98]
    d1f0:      	ldr	x21, [sp, #0x48]
    d1f4:      	add	x2, x24, #0x20
    d1f8:      	stp	x2, x24, [sp, #0x50]
    d1fc:      	ldr	x8, [sp, #0x30]
    d200:      	cmp	x21, x8
    d204:      	b.ne	0xd214 <generic_lsm_path+0x33c4>
    d208:      	ldr	x8, [sp, #0x38]
    d20c:      	cmp	x2, x8
    d210:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d214:      	mov	w8, #0x4                // =4
    d218:      	add	x0, sp, #0x70
    d21c:      	mov	w1, #0x8                // =8
    d220:      	blr	x8
    d224:      	ldr	x8, [sp, #0x70]
    d228:      	cmp	x21, x8
    d22c:      	b.eq	0xd31c <generic_lsm_path+0x34cc>
    d230:      	add	x23, x21, #0x18
    d234:      	mov	w8, #0x4                // =4
    d238:      	add	x9, sp, #0x98
    d23c:      	add	x0, sp, #0x98
    d240:      	mov	w1, #0x8                // =8
    d244:      	mov	x2, x23
    d248:      	blr	x8
    d24c:      	ldr	x8, [sp, #0x98]
    d250:      	cmp	x8, x21
    d254:      	b.eq	0xd31c <generic_lsm_path+0x34cc>
    d258:      	mov	w8, #0x4                // =4
    d25c:      	add	x9, sp, #0x78
    d260:      	add	x0, sp, #0x78
    d264:      	mov	w1, #0x8                // =8
    d268:      	mov	x2, x23
    d26c:      	blr	x8
    d270:      	add	x2, x21, #0x20
    d274:      	mov	w8, #0x4                // =4
    d278:      	mov	w9, #0x10               // =16
    d27c:      	add	x10, sp, #0x80
    d280:      	add	x0, sp, #0x80
    d284:      	mov	w1, #0x10               // =16
    d288:      	blr	x8
    d28c:      	ldr	w21, [sp, #0x84]
    d290:      	ldr	x8, [sp, #0x40]
    d294:      	ldr	x10, [sp, #0x60]
    d298:      	sub	x12, x10, x8
    d29c:      	ldr	w23, [sp, #0x68]
    d2a0:      	subs	w10, w21, w23
    d2a4:      	ldr	x9, [sp, #0x88]
    d2a8:      	csel	w10, wzr, w10, lo
    d2ac:      	cmp	w23, w21
    d2b0:      	csel	w11, w23, w21, lo
    d2b4:      	cinc	w13, w11, hi
    d2b8:      	sub	w14, w23, w13
    d2bc:      	subs	x12, x12, x13
    d2c0:      	str	w14, [sp, #0x68]
    d2c4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d2c8:      	cmp	x12, #0xfff
    d2cc:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d2d0:      	cmp	w23, w21
    d2d4:      	b.ls	0xd2e0 <generic_lsm_path+0x3490>
    d2d8:      	mov	w13, #0x2f              // =47
    d2dc:      	strb	w13, [x8, x12]
    d2e0:      	add	x19, x8, x12
    d2e4:      	cmp	w23, w21
    d2e8:      	add	x2, x9, x10
    d2ec:      	and	w1, w11, #0xff
    d2f0:      	mov	w8, #0x4                // =4
    d2f4:      	cinc	x0, x19, hi
    d2f8:      	blr	x8
    d2fc:      	cmp	w23, w21
    d300:      	str	x19, [sp, #0x60]
    d304:      	add	x19, sp, #0x70
    d308:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d30c:      	ldr	x21, [sp, #0x78]
    d310:      	ldp	x2, x24, [sp, #0x50]
    d314:      	str	x21, [sp, #0x48]
    d318:      	b	0xd368 <generic_lsm_path+0x3518>
    d31c:      	add	x2, x24, #0x10
    d320:      	mov	w8, #0x4                // =4
    d324:      	add	x9, sp, #0x98
    d328:      	add	x0, sp, #0x98
    d32c:      	mov	w1, #0x8                // =8
    d330:      	blr	x8
    d334:      	ldr	x8, [sp, #0x58]
    d338:      	ldr	x9, [sp, #0x98]
    d33c:      	cmp	x8, x9
    d340:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d344:      	add	x2, x24, #0x18
    d348:      	mov	w8, #0x4                // =4
    d34c:      	mov	x0, x22
    d350:      	mov	w1, #0x8                // =8
    d354:      	blr	x8
    d358:      	ldr	x24, [sp, #0x98]
    d35c:      	ldr	x21, [sp, #0x48]
    d360:      	add	x2, x24, #0x20
    d364:      	stp	x2, x24, [sp, #0x50]
    d368:      	ldr	x8, [sp, #0x30]
    d36c:      	cmp	x21, x8
    d370:      	b.ne	0xd380 <generic_lsm_path+0x3530>
    d374:      	ldr	x8, [sp, #0x38]
    d378:      	cmp	x2, x8
    d37c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d380:      	mov	w8, #0x4                // =4
    d384:      	add	x0, sp, #0x70
    d388:      	mov	w1, #0x8                // =8
    d38c:      	blr	x8
    d390:      	ldr	x8, [sp, #0x70]
    d394:      	cmp	x21, x8
    d398:      	b.eq	0xd488 <generic_lsm_path+0x3638>
    d39c:      	add	x23, x21, #0x18
    d3a0:      	mov	w8, #0x4                // =4
    d3a4:      	add	x9, sp, #0x98
    d3a8:      	add	x0, sp, #0x98
    d3ac:      	mov	w1, #0x8                // =8
    d3b0:      	mov	x2, x23
    d3b4:      	blr	x8
    d3b8:      	ldr	x8, [sp, #0x98]
    d3bc:      	cmp	x8, x21
    d3c0:      	b.eq	0xd488 <generic_lsm_path+0x3638>
    d3c4:      	mov	w8, #0x4                // =4
    d3c8:      	add	x9, sp, #0x78
    d3cc:      	add	x0, sp, #0x78
    d3d0:      	mov	w1, #0x8                // =8
    d3d4:      	mov	x2, x23
    d3d8:      	blr	x8
    d3dc:      	add	x2, x21, #0x20
    d3e0:      	mov	w8, #0x4                // =4
    d3e4:      	mov	w9, #0x10               // =16
    d3e8:      	add	x10, sp, #0x80
    d3ec:      	add	x0, sp, #0x80
    d3f0:      	mov	w1, #0x10               // =16
    d3f4:      	blr	x8
    d3f8:      	ldr	w21, [sp, #0x84]
    d3fc:      	ldr	x8, [sp, #0x40]
    d400:      	ldr	x10, [sp, #0x60]
    d404:      	sub	x12, x10, x8
    d408:      	ldr	w23, [sp, #0x68]
    d40c:      	subs	w10, w21, w23
    d410:      	ldr	x9, [sp, #0x88]
    d414:      	csel	w10, wzr, w10, lo
    d418:      	cmp	w23, w21
    d41c:      	csel	w11, w23, w21, lo
    d420:      	cinc	w13, w11, hi
    d424:      	sub	w14, w23, w13
    d428:      	subs	x12, x12, x13
    d42c:      	str	w14, [sp, #0x68]
    d430:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d434:      	cmp	x12, #0xfff
    d438:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d43c:      	cmp	w23, w21
    d440:      	b.ls	0xd44c <generic_lsm_path+0x35fc>
    d444:      	mov	w13, #0x2f              // =47
    d448:      	strb	w13, [x8, x12]
    d44c:      	add	x19, x8, x12
    d450:      	cmp	w23, w21
    d454:      	add	x2, x9, x10
    d458:      	and	w1, w11, #0xff
    d45c:      	mov	w8, #0x4                // =4
    d460:      	cinc	x0, x19, hi
    d464:      	blr	x8
    d468:      	cmp	w23, w21
    d46c:      	str	x19, [sp, #0x60]
    d470:      	add	x19, sp, #0x70
    d474:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d478:      	ldr	x21, [sp, #0x78]
    d47c:      	ldp	x2, x24, [sp, #0x50]
    d480:      	str	x21, [sp, #0x48]
    d484:      	b	0xd4d4 <generic_lsm_path+0x3684>
    d488:      	add	x2, x24, #0x10
    d48c:      	mov	w8, #0x4                // =4
    d490:      	add	x9, sp, #0x98
    d494:      	add	x0, sp, #0x98
    d498:      	mov	w1, #0x8                // =8
    d49c:      	blr	x8
    d4a0:      	ldr	x8, [sp, #0x58]
    d4a4:      	ldr	x9, [sp, #0x98]
    d4a8:      	cmp	x8, x9
    d4ac:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d4b0:      	add	x2, x24, #0x18
    d4b4:      	mov	w8, #0x4                // =4
    d4b8:      	mov	x0, x22
    d4bc:      	mov	w1, #0x8                // =8
    d4c0:      	blr	x8
    d4c4:      	ldr	x24, [sp, #0x98]
    d4c8:      	ldr	x21, [sp, #0x48]
    d4cc:      	add	x2, x24, #0x20
    d4d0:      	stp	x2, x24, [sp, #0x50]
    d4d4:      	ldr	x8, [sp, #0x30]
    d4d8:      	cmp	x21, x8
    d4dc:      	b.ne	0xd4ec <generic_lsm_path+0x369c>
    d4e0:      	ldr	x8, [sp, #0x38]
    d4e4:      	cmp	x2, x8
    d4e8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d4ec:      	mov	w8, #0x4                // =4
    d4f0:      	add	x0, sp, #0x70
    d4f4:      	mov	w1, #0x8                // =8
    d4f8:      	blr	x8
    d4fc:      	ldr	x8, [sp, #0x70]
    d500:      	cmp	x21, x8
    d504:      	b.eq	0xd5f4 <generic_lsm_path+0x37a4>
    d508:      	add	x23, x21, #0x18
    d50c:      	mov	w8, #0x4                // =4
    d510:      	add	x9, sp, #0x98
    d514:      	add	x0, sp, #0x98
    d518:      	mov	w1, #0x8                // =8
    d51c:      	mov	x2, x23
    d520:      	blr	x8
    d524:      	ldr	x8, [sp, #0x98]
    d528:      	cmp	x8, x21
    d52c:      	b.eq	0xd5f4 <generic_lsm_path+0x37a4>
    d530:      	mov	w8, #0x4                // =4
    d534:      	add	x9, sp, #0x78
    d538:      	add	x0, sp, #0x78
    d53c:      	mov	w1, #0x8                // =8
    d540:      	mov	x2, x23
    d544:      	blr	x8
    d548:      	add	x2, x21, #0x20
    d54c:      	mov	w8, #0x4                // =4
    d550:      	mov	w9, #0x10               // =16
    d554:      	add	x10, sp, #0x80
    d558:      	add	x0, sp, #0x80
    d55c:      	mov	w1, #0x10               // =16
    d560:      	blr	x8
    d564:      	ldr	w21, [sp, #0x84]
    d568:      	ldr	x8, [sp, #0x40]
    d56c:      	ldr	x10, [sp, #0x60]
    d570:      	sub	x12, x10, x8
    d574:      	ldr	w23, [sp, #0x68]
    d578:      	subs	w10, w21, w23
    d57c:      	ldr	x9, [sp, #0x88]
    d580:      	csel	w10, wzr, w10, lo
    d584:      	cmp	w23, w21
    d588:      	csel	w11, w23, w21, lo
    d58c:      	cinc	w13, w11, hi
    d590:      	sub	w14, w23, w13
    d594:      	subs	x12, x12, x13
    d598:      	str	w14, [sp, #0x68]
    d59c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d5a0:      	cmp	x12, #0xfff
    d5a4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d5a8:      	cmp	w23, w21
    d5ac:      	b.ls	0xd5b8 <generic_lsm_path+0x3768>
    d5b0:      	mov	w13, #0x2f              // =47
    d5b4:      	strb	w13, [x8, x12]
    d5b8:      	add	x19, x8, x12
    d5bc:      	cmp	w23, w21
    d5c0:      	add	x2, x9, x10
    d5c4:      	and	w1, w11, #0xff
    d5c8:      	mov	w8, #0x4                // =4
    d5cc:      	cinc	x0, x19, hi
    d5d0:      	blr	x8
    d5d4:      	cmp	w23, w21
    d5d8:      	str	x19, [sp, #0x60]
    d5dc:      	add	x19, sp, #0x70
    d5e0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d5e4:      	ldr	x21, [sp, #0x78]
    d5e8:      	ldp	x2, x24, [sp, #0x50]
    d5ec:      	str	x21, [sp, #0x48]
    d5f0:      	b	0xd640 <generic_lsm_path+0x37f0>
    d5f4:      	add	x2, x24, #0x10
    d5f8:      	mov	w8, #0x4                // =4
    d5fc:      	add	x9, sp, #0x98
    d600:      	add	x0, sp, #0x98
    d604:      	mov	w1, #0x8                // =8
    d608:      	blr	x8
    d60c:      	ldr	x8, [sp, #0x58]
    d610:      	ldr	x9, [sp, #0x98]
    d614:      	cmp	x8, x9
    d618:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d61c:      	add	x2, x24, #0x18
    d620:      	mov	w8, #0x4                // =4
    d624:      	mov	x0, x22
    d628:      	mov	w1, #0x8                // =8
    d62c:      	blr	x8
    d630:      	ldr	x24, [sp, #0x98]
    d634:      	ldr	x21, [sp, #0x48]
    d638:      	add	x2, x24, #0x20
    d63c:      	stp	x2, x24, [sp, #0x50]
    d640:      	ldr	x8, [sp, #0x30]
    d644:      	cmp	x21, x8
    d648:      	b.ne	0xd658 <generic_lsm_path+0x3808>
    d64c:      	ldr	x8, [sp, #0x38]
    d650:      	cmp	x2, x8
    d654:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d658:      	mov	w8, #0x4                // =4
    d65c:      	add	x0, sp, #0x70
    d660:      	mov	w1, #0x8                // =8
    d664:      	blr	x8
    d668:      	ldr	x8, [sp, #0x70]
    d66c:      	cmp	x21, x8
    d670:      	b.eq	0xd760 <generic_lsm_path+0x3910>
    d674:      	add	x23, x21, #0x18
    d678:      	mov	w8, #0x4                // =4
    d67c:      	add	x9, sp, #0x98
    d680:      	add	x0, sp, #0x98
    d684:      	mov	w1, #0x8                // =8
    d688:      	mov	x2, x23
    d68c:      	blr	x8
    d690:      	ldr	x8, [sp, #0x98]
    d694:      	cmp	x8, x21
    d698:      	b.eq	0xd760 <generic_lsm_path+0x3910>
    d69c:      	mov	w8, #0x4                // =4
    d6a0:      	add	x9, sp, #0x78
    d6a4:      	add	x0, sp, #0x78
    d6a8:      	mov	w1, #0x8                // =8
    d6ac:      	mov	x2, x23
    d6b0:      	blr	x8
    d6b4:      	add	x2, x21, #0x20
    d6b8:      	mov	w8, #0x4                // =4
    d6bc:      	mov	w9, #0x10               // =16
    d6c0:      	add	x10, sp, #0x80
    d6c4:      	add	x0, sp, #0x80
    d6c8:      	mov	w1, #0x10               // =16
    d6cc:      	blr	x8
    d6d0:      	ldr	w21, [sp, #0x84]
    d6d4:      	ldr	x8, [sp, #0x40]
    d6d8:      	ldr	x10, [sp, #0x60]
    d6dc:      	sub	x12, x10, x8
    d6e0:      	ldr	w23, [sp, #0x68]
    d6e4:      	subs	w10, w21, w23
    d6e8:      	ldr	x9, [sp, #0x88]
    d6ec:      	csel	w10, wzr, w10, lo
    d6f0:      	cmp	w23, w21
    d6f4:      	csel	w11, w23, w21, lo
    d6f8:      	cinc	w13, w11, hi
    d6fc:      	sub	w14, w23, w13
    d700:      	subs	x12, x12, x13
    d704:      	str	w14, [sp, #0x68]
    d708:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d70c:      	cmp	x12, #0xfff
    d710:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d714:      	cmp	w23, w21
    d718:      	b.ls	0xd724 <generic_lsm_path+0x38d4>
    d71c:      	mov	w13, #0x2f              // =47
    d720:      	strb	w13, [x8, x12]
    d724:      	add	x19, x8, x12
    d728:      	cmp	w23, w21
    d72c:      	add	x2, x9, x10
    d730:      	and	w1, w11, #0xff
    d734:      	mov	w8, #0x4                // =4
    d738:      	cinc	x0, x19, hi
    d73c:      	blr	x8
    d740:      	cmp	w23, w21
    d744:      	str	x19, [sp, #0x60]
    d748:      	add	x19, sp, #0x70
    d74c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d750:      	ldr	x21, [sp, #0x78]
    d754:      	ldp	x2, x24, [sp, #0x50]
    d758:      	str	x21, [sp, #0x48]
    d75c:      	b	0xd7ac <generic_lsm_path+0x395c>
    d760:      	add	x2, x24, #0x10
    d764:      	mov	w8, #0x4                // =4
    d768:      	add	x9, sp, #0x98
    d76c:      	add	x0, sp, #0x98
    d770:      	mov	w1, #0x8                // =8
    d774:      	blr	x8
    d778:      	ldr	x8, [sp, #0x58]
    d77c:      	ldr	x9, [sp, #0x98]
    d780:      	cmp	x8, x9
    d784:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d788:      	add	x2, x24, #0x18
    d78c:      	mov	w8, #0x4                // =4
    d790:      	mov	x0, x22
    d794:      	mov	w1, #0x8                // =8
    d798:      	blr	x8
    d79c:      	ldr	x24, [sp, #0x98]
    d7a0:      	ldr	x21, [sp, #0x48]
    d7a4:      	add	x2, x24, #0x20
    d7a8:      	stp	x2, x24, [sp, #0x50]
    d7ac:      	ldr	x8, [sp, #0x30]
    d7b0:      	cmp	x21, x8
    d7b4:      	b.ne	0xd7c4 <generic_lsm_path+0x3974>
    d7b8:      	ldr	x8, [sp, #0x38]
    d7bc:      	cmp	x2, x8
    d7c0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d7c4:      	mov	w8, #0x4                // =4
    d7c8:      	add	x0, sp, #0x70
    d7cc:      	mov	w1, #0x8                // =8
    d7d0:      	blr	x8
    d7d4:      	ldr	x8, [sp, #0x70]
    d7d8:      	cmp	x21, x8
    d7dc:      	b.eq	0xd8cc <generic_lsm_path+0x3a7c>
    d7e0:      	add	x23, x21, #0x18
    d7e4:      	mov	w8, #0x4                // =4
    d7e8:      	add	x9, sp, #0x98
    d7ec:      	add	x0, sp, #0x98
    d7f0:      	mov	w1, #0x8                // =8
    d7f4:      	mov	x2, x23
    d7f8:      	blr	x8
    d7fc:      	ldr	x8, [sp, #0x98]
    d800:      	cmp	x8, x21
    d804:      	b.eq	0xd8cc <generic_lsm_path+0x3a7c>
    d808:      	mov	w8, #0x4                // =4
    d80c:      	add	x9, sp, #0x78
    d810:      	add	x0, sp, #0x78
    d814:      	mov	w1, #0x8                // =8
    d818:      	mov	x2, x23
    d81c:      	blr	x8
    d820:      	add	x2, x21, #0x20
    d824:      	mov	w8, #0x4                // =4
    d828:      	mov	w9, #0x10               // =16
    d82c:      	add	x10, sp, #0x80
    d830:      	add	x0, sp, #0x80
    d834:      	mov	w1, #0x10               // =16
    d838:      	blr	x8
    d83c:      	ldr	w21, [sp, #0x84]
    d840:      	ldr	x8, [sp, #0x40]
    d844:      	ldr	x10, [sp, #0x60]
    d848:      	sub	x12, x10, x8
    d84c:      	ldr	w23, [sp, #0x68]
    d850:      	subs	w10, w21, w23
    d854:      	ldr	x9, [sp, #0x88]
    d858:      	csel	w10, wzr, w10, lo
    d85c:      	cmp	w23, w21
    d860:      	csel	w11, w23, w21, lo
    d864:      	cinc	w13, w11, hi
    d868:      	sub	w14, w23, w13
    d86c:      	subs	x12, x12, x13
    d870:      	str	w14, [sp, #0x68]
    d874:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d878:      	cmp	x12, #0xfff
    d87c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d880:      	cmp	w23, w21
    d884:      	b.ls	0xd890 <generic_lsm_path+0x3a40>
    d888:      	mov	w13, #0x2f              // =47
    d88c:      	strb	w13, [x8, x12]
    d890:      	add	x19, x8, x12
    d894:      	cmp	w23, w21
    d898:      	add	x2, x9, x10
    d89c:      	and	w1, w11, #0xff
    d8a0:      	mov	w8, #0x4                // =4
    d8a4:      	cinc	x0, x19, hi
    d8a8:      	blr	x8
    d8ac:      	cmp	w23, w21
    d8b0:      	str	x19, [sp, #0x60]
    d8b4:      	add	x19, sp, #0x70
    d8b8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    d8bc:      	ldr	x21, [sp, #0x78]
    d8c0:      	ldp	x2, x24, [sp, #0x50]
    d8c4:      	str	x21, [sp, #0x48]
    d8c8:      	b	0xd918 <generic_lsm_path+0x3ac8>
    d8cc:      	add	x2, x24, #0x10
    d8d0:      	mov	w8, #0x4                // =4
    d8d4:      	add	x9, sp, #0x98
    d8d8:      	add	x0, sp, #0x98
    d8dc:      	mov	w1, #0x8                // =8
    d8e0:      	blr	x8
    d8e4:      	ldr	x8, [sp, #0x58]
    d8e8:      	ldr	x9, [sp, #0x98]
    d8ec:      	cmp	x8, x9
    d8f0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d8f4:      	add	x2, x24, #0x18
    d8f8:      	mov	w8, #0x4                // =4
    d8fc:      	mov	x0, x22
    d900:      	mov	w1, #0x8                // =8
    d904:      	blr	x8
    d908:      	ldr	x24, [sp, #0x98]
    d90c:      	ldr	x21, [sp, #0x48]
    d910:      	add	x2, x24, #0x20
    d914:      	stp	x2, x24, [sp, #0x50]
    d918:      	ldr	x8, [sp, #0x30]
    d91c:      	cmp	x21, x8
    d920:      	b.ne	0xd930 <generic_lsm_path+0x3ae0>
    d924:      	ldr	x8, [sp, #0x38]
    d928:      	cmp	x2, x8
    d92c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    d930:      	mov	w8, #0x4                // =4
    d934:      	add	x0, sp, #0x70
    d938:      	mov	w1, #0x8                // =8
    d93c:      	blr	x8
    d940:      	ldr	x8, [sp, #0x70]
    d944:      	cmp	x21, x8
    d948:      	b.eq	0xda38 <generic_lsm_path+0x3be8>
    d94c:      	add	x23, x21, #0x18
    d950:      	mov	w8, #0x4                // =4
    d954:      	add	x9, sp, #0x98
    d958:      	add	x0, sp, #0x98
    d95c:      	mov	w1, #0x8                // =8
    d960:      	mov	x2, x23
    d964:      	blr	x8
    d968:      	ldr	x8, [sp, #0x98]
    d96c:      	cmp	x8, x21
    d970:      	b.eq	0xda38 <generic_lsm_path+0x3be8>
    d974:      	mov	w8, #0x4                // =4
    d978:      	add	x9, sp, #0x78
    d97c:      	add	x0, sp, #0x78
    d980:      	mov	w1, #0x8                // =8
    d984:      	mov	x2, x23
    d988:      	blr	x8
    d98c:      	add	x2, x21, #0x20
    d990:      	mov	w8, #0x4                // =4
    d994:      	mov	w9, #0x10               // =16
    d998:      	add	x10, sp, #0x80
    d99c:      	add	x0, sp, #0x80
    d9a0:      	mov	w1, #0x10               // =16
    d9a4:      	blr	x8
    d9a8:      	ldr	w21, [sp, #0x84]
    d9ac:      	ldr	x8, [sp, #0x40]
    d9b0:      	ldr	x10, [sp, #0x60]
    d9b4:      	sub	x12, x10, x8
    d9b8:      	ldr	w23, [sp, #0x68]
    d9bc:      	subs	w10, w21, w23
    d9c0:      	ldr	x9, [sp, #0x88]
    d9c4:      	csel	w10, wzr, w10, lo
    d9c8:      	cmp	w23, w21
    d9cc:      	csel	w11, w23, w21, lo
    d9d0:      	cinc	w13, w11, hi
    d9d4:      	sub	w14, w23, w13
    d9d8:      	subs	x12, x12, x13
    d9dc:      	str	w14, [sp, #0x68]
    d9e0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    d9e4:      	cmp	x12, #0xfff
    d9e8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    d9ec:      	cmp	w23, w21
    d9f0:      	b.ls	0xd9fc <generic_lsm_path+0x3bac>
    d9f4:      	mov	w13, #0x2f              // =47
    d9f8:      	strb	w13, [x8, x12]
    d9fc:      	add	x19, x8, x12
    da00:      	cmp	w23, w21
    da04:      	add	x2, x9, x10
    da08:      	and	w1, w11, #0xff
    da0c:      	mov	w8, #0x4                // =4
    da10:      	cinc	x0, x19, hi
    da14:      	blr	x8
    da18:      	cmp	w23, w21
    da1c:      	str	x19, [sp, #0x60]
    da20:      	add	x19, sp, #0x70
    da24:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    da28:      	ldr	x21, [sp, #0x78]
    da2c:      	ldp	x2, x24, [sp, #0x50]
    da30:      	str	x21, [sp, #0x48]
    da34:      	b	0xda84 <generic_lsm_path+0x3c34>
    da38:      	add	x2, x24, #0x10
    da3c:      	mov	w8, #0x4                // =4
    da40:      	add	x9, sp, #0x98
    da44:      	add	x0, sp, #0x98
    da48:      	mov	w1, #0x8                // =8
    da4c:      	blr	x8
    da50:      	ldr	x8, [sp, #0x58]
    da54:      	ldr	x9, [sp, #0x98]
    da58:      	cmp	x8, x9
    da5c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    da60:      	add	x2, x24, #0x18
    da64:      	mov	w8, #0x4                // =4
    da68:      	mov	x0, x22
    da6c:      	mov	w1, #0x8                // =8
    da70:      	blr	x8
    da74:      	ldr	x24, [sp, #0x98]
    da78:      	ldr	x21, [sp, #0x48]
    da7c:      	add	x2, x24, #0x20
    da80:      	stp	x2, x24, [sp, #0x50]
    da84:      	ldr	x8, [sp, #0x30]
    da88:      	cmp	x21, x8
    da8c:      	b.ne	0xda9c <generic_lsm_path+0x3c4c>
    da90:      	ldr	x8, [sp, #0x38]
    da94:      	cmp	x2, x8
    da98:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    da9c:      	mov	w8, #0x4                // =4
    daa0:      	add	x0, sp, #0x70
    daa4:      	mov	w1, #0x8                // =8
    daa8:      	blr	x8
    daac:      	ldr	x8, [sp, #0x70]
    dab0:      	cmp	x21, x8
    dab4:      	b.eq	0xdba4 <generic_lsm_path+0x3d54>
    dab8:      	add	x23, x21, #0x18
    dabc:      	mov	w8, #0x4                // =4
    dac0:      	add	x9, sp, #0x98
    dac4:      	add	x0, sp, #0x98
    dac8:      	mov	w1, #0x8                // =8
    dacc:      	mov	x2, x23
    dad0:      	blr	x8
    dad4:      	ldr	x8, [sp, #0x98]
    dad8:      	cmp	x8, x21
    dadc:      	b.eq	0xdba4 <generic_lsm_path+0x3d54>
    dae0:      	mov	w8, #0x4                // =4
    dae4:      	add	x9, sp, #0x78
    dae8:      	add	x0, sp, #0x78
    daec:      	mov	w1, #0x8                // =8
    daf0:      	mov	x2, x23
    daf4:      	blr	x8
    daf8:      	add	x2, x21, #0x20
    dafc:      	mov	w8, #0x4                // =4
    db00:      	mov	w9, #0x10               // =16
    db04:      	add	x10, sp, #0x80
    db08:      	add	x0, sp, #0x80
    db0c:      	mov	w1, #0x10               // =16
    db10:      	blr	x8
    db14:      	ldr	w21, [sp, #0x84]
    db18:      	ldr	x8, [sp, #0x40]
    db1c:      	ldr	x10, [sp, #0x60]
    db20:      	sub	x12, x10, x8
    db24:      	ldr	w23, [sp, #0x68]
    db28:      	subs	w10, w21, w23
    db2c:      	ldr	x9, [sp, #0x88]
    db30:      	csel	w10, wzr, w10, lo
    db34:      	cmp	w23, w21
    db38:      	csel	w11, w23, w21, lo
    db3c:      	cinc	w13, w11, hi
    db40:      	sub	w14, w23, w13
    db44:      	subs	x12, x12, x13
    db48:      	str	w14, [sp, #0x68]
    db4c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    db50:      	cmp	x12, #0xfff
    db54:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    db58:      	cmp	w23, w21
    db5c:      	b.ls	0xdb68 <generic_lsm_path+0x3d18>
    db60:      	mov	w13, #0x2f              // =47
    db64:      	strb	w13, [x8, x12]
    db68:      	add	x19, x8, x12
    db6c:      	cmp	w23, w21
    db70:      	add	x2, x9, x10
    db74:      	and	w1, w11, #0xff
    db78:      	mov	w8, #0x4                // =4
    db7c:      	cinc	x0, x19, hi
    db80:      	blr	x8
    db84:      	cmp	w23, w21
    db88:      	str	x19, [sp, #0x60]
    db8c:      	add	x19, sp, #0x70
    db90:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    db94:      	ldr	x21, [sp, #0x78]
    db98:      	ldp	x2, x24, [sp, #0x50]
    db9c:      	str	x21, [sp, #0x48]
    dba0:      	b	0xdbf0 <generic_lsm_path+0x3da0>
    dba4:      	add	x2, x24, #0x10
    dba8:      	mov	w8, #0x4                // =4
    dbac:      	add	x9, sp, #0x98
    dbb0:      	add	x0, sp, #0x98
    dbb4:      	mov	w1, #0x8                // =8
    dbb8:      	blr	x8
    dbbc:      	ldr	x8, [sp, #0x58]
    dbc0:      	ldr	x9, [sp, #0x98]
    dbc4:      	cmp	x8, x9
    dbc8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    dbcc:      	add	x2, x24, #0x18
    dbd0:      	mov	w8, #0x4                // =4
    dbd4:      	mov	x0, x22
    dbd8:      	mov	w1, #0x8                // =8
    dbdc:      	blr	x8
    dbe0:      	ldr	x24, [sp, #0x98]
    dbe4:      	ldr	x21, [sp, #0x48]
    dbe8:      	add	x2, x24, #0x20
    dbec:      	stp	x2, x24, [sp, #0x50]
    dbf0:      	ldr	x8, [sp, #0x30]
    dbf4:      	cmp	x21, x8
    dbf8:      	b.ne	0xdc08 <generic_lsm_path+0x3db8>
    dbfc:      	ldr	x8, [sp, #0x38]
    dc00:      	cmp	x2, x8
    dc04:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    dc08:      	mov	w8, #0x4                // =4
    dc0c:      	add	x0, sp, #0x70
    dc10:      	mov	w1, #0x8                // =8
    dc14:      	blr	x8
    dc18:      	ldr	x8, [sp, #0x70]
    dc1c:      	cmp	x21, x8
    dc20:      	b.eq	0xdd10 <generic_lsm_path+0x3ec0>
    dc24:      	add	x23, x21, #0x18
    dc28:      	mov	w8, #0x4                // =4
    dc2c:      	add	x9, sp, #0x98
    dc30:      	add	x0, sp, #0x98
    dc34:      	mov	w1, #0x8                // =8
    dc38:      	mov	x2, x23
    dc3c:      	blr	x8
    dc40:      	ldr	x8, [sp, #0x98]
    dc44:      	cmp	x8, x21
    dc48:      	b.eq	0xdd10 <generic_lsm_path+0x3ec0>
    dc4c:      	mov	w8, #0x4                // =4
    dc50:      	add	x9, sp, #0x78
    dc54:      	add	x0, sp, #0x78
    dc58:      	mov	w1, #0x8                // =8
    dc5c:      	mov	x2, x23
    dc60:      	blr	x8
    dc64:      	add	x2, x21, #0x20
    dc68:      	mov	w8, #0x4                // =4
    dc6c:      	mov	w9, #0x10               // =16
    dc70:      	add	x10, sp, #0x80
    dc74:      	add	x0, sp, #0x80
    dc78:      	mov	w1, #0x10               // =16
    dc7c:      	blr	x8
    dc80:      	ldr	w21, [sp, #0x84]
    dc84:      	ldr	x8, [sp, #0x40]
    dc88:      	ldr	x10, [sp, #0x60]
    dc8c:      	sub	x12, x10, x8
    dc90:      	ldr	w23, [sp, #0x68]
    dc94:      	subs	w10, w21, w23
    dc98:      	ldr	x9, [sp, #0x88]
    dc9c:      	csel	w10, wzr, w10, lo
    dca0:      	cmp	w23, w21
    dca4:      	csel	w11, w23, w21, lo
    dca8:      	cinc	w13, w11, hi
    dcac:      	sub	w14, w23, w13
    dcb0:      	subs	x12, x12, x13
    dcb4:      	str	w14, [sp, #0x68]
    dcb8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    dcbc:      	cmp	x12, #0xfff
    dcc0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    dcc4:      	cmp	w23, w21
    dcc8:      	b.ls	0xdcd4 <generic_lsm_path+0x3e84>
    dccc:      	mov	w13, #0x2f              // =47
    dcd0:      	strb	w13, [x8, x12]
    dcd4:      	add	x19, x8, x12
    dcd8:      	cmp	w23, w21
    dcdc:      	add	x2, x9, x10
    dce0:      	and	w1, w11, #0xff
    dce4:      	mov	w8, #0x4                // =4
    dce8:      	cinc	x0, x19, hi
    dcec:      	blr	x8
    dcf0:      	cmp	w23, w21
    dcf4:      	str	x19, [sp, #0x60]
    dcf8:      	add	x19, sp, #0x70
    dcfc:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    dd00:      	ldr	x21, [sp, #0x78]
    dd04:      	ldp	x2, x24, [sp, #0x50]
    dd08:      	str	x21, [sp, #0x48]
    dd0c:      	b	0xdd5c <generic_lsm_path+0x3f0c>
    dd10:      	add	x2, x24, #0x10
    dd14:      	mov	w8, #0x4                // =4
    dd18:      	add	x9, sp, #0x98
    dd1c:      	add	x0, sp, #0x98
    dd20:      	mov	w1, #0x8                // =8
    dd24:      	blr	x8
    dd28:      	ldr	x8, [sp, #0x58]
    dd2c:      	ldr	x9, [sp, #0x98]
    dd30:      	cmp	x8, x9
    dd34:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    dd38:      	add	x2, x24, #0x18
    dd3c:      	mov	w8, #0x4                // =4
    dd40:      	mov	x0, x22
    dd44:      	mov	w1, #0x8                // =8
    dd48:      	blr	x8
    dd4c:      	ldr	x24, [sp, #0x98]
    dd50:      	ldr	x21, [sp, #0x48]
    dd54:      	add	x2, x24, #0x20
    dd58:      	stp	x2, x24, [sp, #0x50]
    dd5c:      	ldr	x8, [sp, #0x30]
    dd60:      	cmp	x21, x8
    dd64:      	b.ne	0xdd74 <generic_lsm_path+0x3f24>
    dd68:      	ldr	x8, [sp, #0x38]
    dd6c:      	cmp	x2, x8
    dd70:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    dd74:      	mov	w8, #0x4                // =4
    dd78:      	add	x0, sp, #0x70
    dd7c:      	mov	w1, #0x8                // =8
    dd80:      	blr	x8
    dd84:      	ldr	x8, [sp, #0x70]
    dd88:      	cmp	x21, x8
    dd8c:      	b.eq	0xde7c <generic_lsm_path+0x402c>
    dd90:      	add	x23, x21, #0x18
    dd94:      	mov	w8, #0x4                // =4
    dd98:      	add	x9, sp, #0x98
    dd9c:      	add	x0, sp, #0x98
    dda0:      	mov	w1, #0x8                // =8
    dda4:      	mov	x2, x23
    dda8:      	blr	x8
    ddac:      	ldr	x8, [sp, #0x98]
    ddb0:      	cmp	x8, x21
    ddb4:      	b.eq	0xde7c <generic_lsm_path+0x402c>
    ddb8:      	mov	w8, #0x4                // =4
    ddbc:      	add	x9, sp, #0x78
    ddc0:      	add	x0, sp, #0x78
    ddc4:      	mov	w1, #0x8                // =8
    ddc8:      	mov	x2, x23
    ddcc:      	blr	x8
    ddd0:      	add	x2, x21, #0x20
    ddd4:      	mov	w8, #0x4                // =4
    ddd8:      	mov	w9, #0x10               // =16
    dddc:      	add	x10, sp, #0x80
    dde0:      	add	x0, sp, #0x80
    dde4:      	mov	w1, #0x10               // =16
    dde8:      	blr	x8
    ddec:      	ldr	w21, [sp, #0x84]
    ddf0:      	ldr	x8, [sp, #0x40]
    ddf4:      	ldr	x10, [sp, #0x60]
    ddf8:      	sub	x12, x10, x8
    ddfc:      	ldr	w23, [sp, #0x68]
    de00:      	subs	w10, w21, w23
    de04:      	ldr	x9, [sp, #0x88]
    de08:      	csel	w10, wzr, w10, lo
    de0c:      	cmp	w23, w21
    de10:      	csel	w11, w23, w21, lo
    de14:      	cinc	w13, w11, hi
    de18:      	sub	w14, w23, w13
    de1c:      	subs	x12, x12, x13
    de20:      	str	w14, [sp, #0x68]
    de24:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    de28:      	cmp	x12, #0xfff
    de2c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    de30:      	cmp	w23, w21
    de34:      	b.ls	0xde40 <generic_lsm_path+0x3ff0>
    de38:      	mov	w13, #0x2f              // =47
    de3c:      	strb	w13, [x8, x12]
    de40:      	add	x19, x8, x12
    de44:      	cmp	w23, w21
    de48:      	add	x2, x9, x10
    de4c:      	and	w1, w11, #0xff
    de50:      	mov	w8, #0x4                // =4
    de54:      	cinc	x0, x19, hi
    de58:      	blr	x8
    de5c:      	cmp	w23, w21
    de60:      	str	x19, [sp, #0x60]
    de64:      	add	x19, sp, #0x70
    de68:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    de6c:      	ldr	x21, [sp, #0x78]
    de70:      	ldp	x2, x24, [sp, #0x50]
    de74:      	str	x21, [sp, #0x48]
    de78:      	b	0xdec8 <generic_lsm_path+0x4078>
    de7c:      	add	x2, x24, #0x10
    de80:      	mov	w8, #0x4                // =4
    de84:      	add	x9, sp, #0x98
    de88:      	add	x0, sp, #0x98
    de8c:      	mov	w1, #0x8                // =8
    de90:      	blr	x8
    de94:      	ldr	x8, [sp, #0x58]
    de98:      	ldr	x9, [sp, #0x98]
    de9c:      	cmp	x8, x9
    dea0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    dea4:      	add	x2, x24, #0x18
    dea8:      	mov	w8, #0x4                // =4
    deac:      	mov	x0, x22
    deb0:      	mov	w1, #0x8                // =8
    deb4:      	blr	x8
    deb8:      	ldr	x24, [sp, #0x98]
    debc:      	ldr	x21, [sp, #0x48]
    dec0:      	add	x2, x24, #0x20
    dec4:      	stp	x2, x24, [sp, #0x50]
    dec8:      	ldr	x8, [sp, #0x30]
    decc:      	cmp	x21, x8
    ded0:      	b.ne	0xdee0 <generic_lsm_path+0x4090>
    ded4:      	ldr	x8, [sp, #0x38]
    ded8:      	cmp	x2, x8
    dedc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    dee0:      	mov	w8, #0x4                // =4
    dee4:      	add	x0, sp, #0x70
    dee8:      	mov	w1, #0x8                // =8
    deec:      	blr	x8
    def0:      	ldr	x8, [sp, #0x70]
    def4:      	cmp	x21, x8
    def8:      	b.eq	0xdfe8 <generic_lsm_path+0x4198>
    defc:      	add	x23, x21, #0x18
    df00:      	mov	w8, #0x4                // =4
    df04:      	add	x9, sp, #0x98
    df08:      	add	x0, sp, #0x98
    df0c:      	mov	w1, #0x8                // =8
    df10:      	mov	x2, x23
    df14:      	blr	x8
    df18:      	ldr	x8, [sp, #0x98]
    df1c:      	cmp	x8, x21
    df20:      	b.eq	0xdfe8 <generic_lsm_path+0x4198>
    df24:      	mov	w8, #0x4                // =4
    df28:      	add	x9, sp, #0x78
    df2c:      	add	x0, sp, #0x78
    df30:      	mov	w1, #0x8                // =8
    df34:      	mov	x2, x23
    df38:      	blr	x8
    df3c:      	add	x2, x21, #0x20
    df40:      	mov	w8, #0x4                // =4
    df44:      	mov	w9, #0x10               // =16
    df48:      	add	x10, sp, #0x80
    df4c:      	add	x0, sp, #0x80
    df50:      	mov	w1, #0x10               // =16
    df54:      	blr	x8
    df58:      	ldr	w21, [sp, #0x84]
    df5c:      	ldr	x8, [sp, #0x40]
    df60:      	ldr	x10, [sp, #0x60]
    df64:      	sub	x12, x10, x8
    df68:      	ldr	w23, [sp, #0x68]
    df6c:      	subs	w10, w21, w23
    df70:      	ldr	x9, [sp, #0x88]
    df74:      	csel	w10, wzr, w10, lo
    df78:      	cmp	w23, w21
    df7c:      	csel	w11, w23, w21, lo
    df80:      	cinc	w13, w11, hi
    df84:      	sub	w14, w23, w13
    df88:      	subs	x12, x12, x13
    df8c:      	str	w14, [sp, #0x68]
    df90:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    df94:      	cmp	x12, #0xfff
    df98:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    df9c:      	cmp	w23, w21
    dfa0:      	b.ls	0xdfac <generic_lsm_path+0x415c>
    dfa4:      	mov	w13, #0x2f              // =47
    dfa8:      	strb	w13, [x8, x12]
    dfac:      	add	x19, x8, x12
    dfb0:      	cmp	w23, w21
    dfb4:      	add	x2, x9, x10
    dfb8:      	and	w1, w11, #0xff
    dfbc:      	mov	w8, #0x4                // =4
    dfc0:      	cinc	x0, x19, hi
    dfc4:      	blr	x8
    dfc8:      	cmp	w23, w21
    dfcc:      	str	x19, [sp, #0x60]
    dfd0:      	add	x19, sp, #0x70
    dfd4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    dfd8:      	ldr	x21, [sp, #0x78]
    dfdc:      	ldp	x2, x24, [sp, #0x50]
    dfe0:      	str	x21, [sp, #0x48]
    dfe4:      	b	0xe034 <generic_lsm_path+0x41e4>
    dfe8:      	add	x2, x24, #0x10
    dfec:      	mov	w8, #0x4                // =4
    dff0:      	add	x9, sp, #0x98
    dff4:      	add	x0, sp, #0x98
    dff8:      	mov	w1, #0x8                // =8
    dffc:      	blr	x8
    e000:      	ldr	x8, [sp, #0x58]
    e004:      	ldr	x9, [sp, #0x98]
    e008:      	cmp	x8, x9
    e00c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e010:      	add	x2, x24, #0x18
    e014:      	mov	w8, #0x4                // =4
    e018:      	mov	x0, x22
    e01c:      	mov	w1, #0x8                // =8
    e020:      	blr	x8
    e024:      	ldr	x24, [sp, #0x98]
    e028:      	ldr	x21, [sp, #0x48]
    e02c:      	add	x2, x24, #0x20
    e030:      	stp	x2, x24, [sp, #0x50]
    e034:      	ldr	x8, [sp, #0x30]
    e038:      	cmp	x21, x8
    e03c:      	b.ne	0xe04c <generic_lsm_path+0x41fc>
    e040:      	ldr	x8, [sp, #0x38]
    e044:      	cmp	x2, x8
    e048:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e04c:      	mov	w8, #0x4                // =4
    e050:      	add	x0, sp, #0x70
    e054:      	mov	w1, #0x8                // =8
    e058:      	blr	x8
    e05c:      	ldr	x8, [sp, #0x70]
    e060:      	cmp	x21, x8
    e064:      	b.eq	0xe154 <generic_lsm_path+0x4304>
    e068:      	add	x23, x21, #0x18
    e06c:      	mov	w8, #0x4                // =4
    e070:      	add	x9, sp, #0x98
    e074:      	add	x0, sp, #0x98
    e078:      	mov	w1, #0x8                // =8
    e07c:      	mov	x2, x23
    e080:      	blr	x8
    e084:      	ldr	x8, [sp, #0x98]
    e088:      	cmp	x8, x21
    e08c:      	b.eq	0xe154 <generic_lsm_path+0x4304>
    e090:      	mov	w8, #0x4                // =4
    e094:      	add	x9, sp, #0x78
    e098:      	add	x0, sp, #0x78
    e09c:      	mov	w1, #0x8                // =8
    e0a0:      	mov	x2, x23
    e0a4:      	blr	x8
    e0a8:      	add	x2, x21, #0x20
    e0ac:      	mov	w8, #0x4                // =4
    e0b0:      	mov	w9, #0x10               // =16
    e0b4:      	add	x10, sp, #0x80
    e0b8:      	add	x0, sp, #0x80
    e0bc:      	mov	w1, #0x10               // =16
    e0c0:      	blr	x8
    e0c4:      	ldr	w21, [sp, #0x84]
    e0c8:      	ldr	x8, [sp, #0x40]
    e0cc:      	ldr	x10, [sp, #0x60]
    e0d0:      	sub	x12, x10, x8
    e0d4:      	ldr	w23, [sp, #0x68]
    e0d8:      	subs	w10, w21, w23
    e0dc:      	ldr	x9, [sp, #0x88]
    e0e0:      	csel	w10, wzr, w10, lo
    e0e4:      	cmp	w23, w21
    e0e8:      	csel	w11, w23, w21, lo
    e0ec:      	cinc	w13, w11, hi
    e0f0:      	sub	w14, w23, w13
    e0f4:      	subs	x12, x12, x13
    e0f8:      	str	w14, [sp, #0x68]
    e0fc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e100:      	cmp	x12, #0xfff
    e104:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e108:      	cmp	w23, w21
    e10c:      	b.ls	0xe118 <generic_lsm_path+0x42c8>
    e110:      	mov	w13, #0x2f              // =47
    e114:      	strb	w13, [x8, x12]
    e118:      	add	x19, x8, x12
    e11c:      	cmp	w23, w21
    e120:      	add	x2, x9, x10
    e124:      	and	w1, w11, #0xff
    e128:      	mov	w8, #0x4                // =4
    e12c:      	cinc	x0, x19, hi
    e130:      	blr	x8
    e134:      	cmp	w23, w21
    e138:      	str	x19, [sp, #0x60]
    e13c:      	add	x19, sp, #0x70
    e140:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e144:      	ldr	x21, [sp, #0x78]
    e148:      	ldp	x2, x24, [sp, #0x50]
    e14c:      	str	x21, [sp, #0x48]
    e150:      	b	0xe1a0 <generic_lsm_path+0x4350>
    e154:      	add	x2, x24, #0x10
    e158:      	mov	w8, #0x4                // =4
    e15c:      	add	x9, sp, #0x98
    e160:      	add	x0, sp, #0x98
    e164:      	mov	w1, #0x8                // =8
    e168:      	blr	x8
    e16c:      	ldr	x8, [sp, #0x58]
    e170:      	ldr	x9, [sp, #0x98]
    e174:      	cmp	x8, x9
    e178:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e17c:      	add	x2, x24, #0x18
    e180:      	mov	w8, #0x4                // =4
    e184:      	mov	x0, x22
    e188:      	mov	w1, #0x8                // =8
    e18c:      	blr	x8
    e190:      	ldr	x24, [sp, #0x98]
    e194:      	ldr	x21, [sp, #0x48]
    e198:      	add	x2, x24, #0x20
    e19c:      	stp	x2, x24, [sp, #0x50]
    e1a0:      	ldr	x8, [sp, #0x30]
    e1a4:      	cmp	x21, x8
    e1a8:      	b.ne	0xe1b8 <generic_lsm_path+0x4368>
    e1ac:      	ldr	x8, [sp, #0x38]
    e1b0:      	cmp	x2, x8
    e1b4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e1b8:      	mov	w8, #0x4                // =4
    e1bc:      	add	x0, sp, #0x70
    e1c0:      	mov	w1, #0x8                // =8
    e1c4:      	blr	x8
    e1c8:      	ldr	x8, [sp, #0x70]
    e1cc:      	cmp	x21, x8
    e1d0:      	b.eq	0xe2c0 <generic_lsm_path+0x4470>
    e1d4:      	add	x23, x21, #0x18
    e1d8:      	mov	w8, #0x4                // =4
    e1dc:      	add	x9, sp, #0x98
    e1e0:      	add	x0, sp, #0x98
    e1e4:      	mov	w1, #0x8                // =8
    e1e8:      	mov	x2, x23
    e1ec:      	blr	x8
    e1f0:      	ldr	x8, [sp, #0x98]
    e1f4:      	cmp	x8, x21
    e1f8:      	b.eq	0xe2c0 <generic_lsm_path+0x4470>
    e1fc:      	mov	w8, #0x4                // =4
    e200:      	add	x9, sp, #0x78
    e204:      	add	x0, sp, #0x78
    e208:      	mov	w1, #0x8                // =8
    e20c:      	mov	x2, x23
    e210:      	blr	x8
    e214:      	add	x2, x21, #0x20
    e218:      	mov	w8, #0x4                // =4
    e21c:      	mov	w9, #0x10               // =16
    e220:      	add	x10, sp, #0x80
    e224:      	add	x0, sp, #0x80
    e228:      	mov	w1, #0x10               // =16
    e22c:      	blr	x8
    e230:      	ldr	w21, [sp, #0x84]
    e234:      	ldr	x8, [sp, #0x40]
    e238:      	ldr	x10, [sp, #0x60]
    e23c:      	sub	x12, x10, x8
    e240:      	ldr	w23, [sp, #0x68]
    e244:      	subs	w10, w21, w23
    e248:      	ldr	x9, [sp, #0x88]
    e24c:      	csel	w10, wzr, w10, lo
    e250:      	cmp	w23, w21
    e254:      	csel	w11, w23, w21, lo
    e258:      	cinc	w13, w11, hi
    e25c:      	sub	w14, w23, w13
    e260:      	subs	x12, x12, x13
    e264:      	str	w14, [sp, #0x68]
    e268:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e26c:      	cmp	x12, #0xfff
    e270:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e274:      	cmp	w23, w21
    e278:      	b.ls	0xe284 <generic_lsm_path+0x4434>
    e27c:      	mov	w13, #0x2f              // =47
    e280:      	strb	w13, [x8, x12]
    e284:      	add	x19, x8, x12
    e288:      	cmp	w23, w21
    e28c:      	add	x2, x9, x10
    e290:      	and	w1, w11, #0xff
    e294:      	mov	w8, #0x4                // =4
    e298:      	cinc	x0, x19, hi
    e29c:      	blr	x8
    e2a0:      	cmp	w23, w21
    e2a4:      	str	x19, [sp, #0x60]
    e2a8:      	add	x19, sp, #0x70
    e2ac:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e2b0:      	ldr	x21, [sp, #0x78]
    e2b4:      	ldp	x2, x24, [sp, #0x50]
    e2b8:      	str	x21, [sp, #0x48]
    e2bc:      	b	0xe30c <generic_lsm_path+0x44bc>
    e2c0:      	add	x2, x24, #0x10
    e2c4:      	mov	w8, #0x4                // =4
    e2c8:      	add	x9, sp, #0x98
    e2cc:      	add	x0, sp, #0x98
    e2d0:      	mov	w1, #0x8                // =8
    e2d4:      	blr	x8
    e2d8:      	ldr	x8, [sp, #0x58]
    e2dc:      	ldr	x9, [sp, #0x98]
    e2e0:      	cmp	x8, x9
    e2e4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e2e8:      	add	x2, x24, #0x18
    e2ec:      	mov	w8, #0x4                // =4
    e2f0:      	mov	x0, x22
    e2f4:      	mov	w1, #0x8                // =8
    e2f8:      	blr	x8
    e2fc:      	ldr	x24, [sp, #0x98]
    e300:      	ldr	x21, [sp, #0x48]
    e304:      	add	x2, x24, #0x20
    e308:      	stp	x2, x24, [sp, #0x50]
    e30c:      	ldr	x8, [sp, #0x30]
    e310:      	cmp	x21, x8
    e314:      	b.ne	0xe324 <generic_lsm_path+0x44d4>
    e318:      	ldr	x8, [sp, #0x38]
    e31c:      	cmp	x2, x8
    e320:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e324:      	mov	w8, #0x4                // =4
    e328:      	add	x0, sp, #0x70
    e32c:      	mov	w1, #0x8                // =8
    e330:      	blr	x8
    e334:      	ldr	x8, [sp, #0x70]
    e338:      	cmp	x21, x8
    e33c:      	b.eq	0xe42c <generic_lsm_path+0x45dc>
    e340:      	add	x23, x21, #0x18
    e344:      	mov	w8, #0x4                // =4
    e348:      	add	x9, sp, #0x98
    e34c:      	add	x0, sp, #0x98
    e350:      	mov	w1, #0x8                // =8
    e354:      	mov	x2, x23
    e358:      	blr	x8
    e35c:      	ldr	x8, [sp, #0x98]
    e360:      	cmp	x8, x21
    e364:      	b.eq	0xe42c <generic_lsm_path+0x45dc>
    e368:      	mov	w8, #0x4                // =4
    e36c:      	add	x9, sp, #0x78
    e370:      	add	x0, sp, #0x78
    e374:      	mov	w1, #0x8                // =8
    e378:      	mov	x2, x23
    e37c:      	blr	x8
    e380:      	add	x2, x21, #0x20
    e384:      	mov	w8, #0x4                // =4
    e388:      	mov	w9, #0x10               // =16
    e38c:      	add	x10, sp, #0x80
    e390:      	add	x0, sp, #0x80
    e394:      	mov	w1, #0x10               // =16
    e398:      	blr	x8
    e39c:      	ldr	w21, [sp, #0x84]
    e3a0:      	ldr	x8, [sp, #0x40]
    e3a4:      	ldr	x10, [sp, #0x60]
    e3a8:      	sub	x12, x10, x8
    e3ac:      	ldr	w23, [sp, #0x68]
    e3b0:      	subs	w10, w21, w23
    e3b4:      	ldr	x9, [sp, #0x88]
    e3b8:      	csel	w10, wzr, w10, lo
    e3bc:      	cmp	w23, w21
    e3c0:      	csel	w11, w23, w21, lo
    e3c4:      	cinc	w13, w11, hi
    e3c8:      	sub	w14, w23, w13
    e3cc:      	subs	x12, x12, x13
    e3d0:      	str	w14, [sp, #0x68]
    e3d4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e3d8:      	cmp	x12, #0xfff
    e3dc:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e3e0:      	cmp	w23, w21
    e3e4:      	b.ls	0xe3f0 <generic_lsm_path+0x45a0>
    e3e8:      	mov	w13, #0x2f              // =47
    e3ec:      	strb	w13, [x8, x12]
    e3f0:      	add	x19, x8, x12
    e3f4:      	cmp	w23, w21
    e3f8:      	add	x2, x9, x10
    e3fc:      	and	w1, w11, #0xff
    e400:      	mov	w8, #0x4                // =4
    e404:      	cinc	x0, x19, hi
    e408:      	blr	x8
    e40c:      	cmp	w23, w21
    e410:      	str	x19, [sp, #0x60]
    e414:      	add	x19, sp, #0x70
    e418:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e41c:      	ldr	x21, [sp, #0x78]
    e420:      	ldp	x2, x24, [sp, #0x50]
    e424:      	str	x21, [sp, #0x48]
    e428:      	b	0xe478 <generic_lsm_path+0x4628>
    e42c:      	add	x2, x24, #0x10
    e430:      	mov	w8, #0x4                // =4
    e434:      	add	x9, sp, #0x98
    e438:      	add	x0, sp, #0x98
    e43c:      	mov	w1, #0x8                // =8
    e440:      	blr	x8
    e444:      	ldr	x8, [sp, #0x58]
    e448:      	ldr	x9, [sp, #0x98]
    e44c:      	cmp	x8, x9
    e450:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e454:      	add	x2, x24, #0x18
    e458:      	mov	w8, #0x4                // =4
    e45c:      	mov	x0, x22
    e460:      	mov	w1, #0x8                // =8
    e464:      	blr	x8
    e468:      	ldr	x24, [sp, #0x98]
    e46c:      	ldr	x21, [sp, #0x48]
    e470:      	add	x2, x24, #0x20
    e474:      	stp	x2, x24, [sp, #0x50]
    e478:      	ldr	x8, [sp, #0x30]
    e47c:      	cmp	x21, x8
    e480:      	b.ne	0xe490 <generic_lsm_path+0x4640>
    e484:      	ldr	x8, [sp, #0x38]
    e488:      	cmp	x2, x8
    e48c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e490:      	mov	w8, #0x4                // =4
    e494:      	add	x0, sp, #0x70
    e498:      	mov	w1, #0x8                // =8
    e49c:      	blr	x8
    e4a0:      	ldr	x8, [sp, #0x70]
    e4a4:      	cmp	x21, x8
    e4a8:      	b.eq	0xe598 <generic_lsm_path+0x4748>
    e4ac:      	add	x23, x21, #0x18
    e4b0:      	mov	w8, #0x4                // =4
    e4b4:      	add	x9, sp, #0x98
    e4b8:      	add	x0, sp, #0x98
    e4bc:      	mov	w1, #0x8                // =8
    e4c0:      	mov	x2, x23
    e4c4:      	blr	x8
    e4c8:      	ldr	x8, [sp, #0x98]
    e4cc:      	cmp	x8, x21
    e4d0:      	b.eq	0xe598 <generic_lsm_path+0x4748>
    e4d4:      	mov	w8, #0x4                // =4
    e4d8:      	add	x9, sp, #0x78
    e4dc:      	add	x0, sp, #0x78
    e4e0:      	mov	w1, #0x8                // =8
    e4e4:      	mov	x2, x23
    e4e8:      	blr	x8
    e4ec:      	add	x2, x21, #0x20
    e4f0:      	mov	w8, #0x4                // =4
    e4f4:      	mov	w9, #0x10               // =16
    e4f8:      	add	x10, sp, #0x80
    e4fc:      	add	x0, sp, #0x80
    e500:      	mov	w1, #0x10               // =16
    e504:      	blr	x8
    e508:      	ldr	w21, [sp, #0x84]
    e50c:      	ldr	x8, [sp, #0x40]
    e510:      	ldr	x10, [sp, #0x60]
    e514:      	sub	x12, x10, x8
    e518:      	ldr	w23, [sp, #0x68]
    e51c:      	subs	w10, w21, w23
    e520:      	ldr	x9, [sp, #0x88]
    e524:      	csel	w10, wzr, w10, lo
    e528:      	cmp	w23, w21
    e52c:      	csel	w11, w23, w21, lo
    e530:      	cinc	w13, w11, hi
    e534:      	sub	w14, w23, w13
    e538:      	subs	x12, x12, x13
    e53c:      	str	w14, [sp, #0x68]
    e540:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e544:      	cmp	x12, #0xfff
    e548:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e54c:      	cmp	w23, w21
    e550:      	b.ls	0xe55c <generic_lsm_path+0x470c>
    e554:      	mov	w13, #0x2f              // =47
    e558:      	strb	w13, [x8, x12]
    e55c:      	add	x19, x8, x12
    e560:      	cmp	w23, w21
    e564:      	add	x2, x9, x10
    e568:      	and	w1, w11, #0xff
    e56c:      	mov	w8, #0x4                // =4
    e570:      	cinc	x0, x19, hi
    e574:      	blr	x8
    e578:      	cmp	w23, w21
    e57c:      	str	x19, [sp, #0x60]
    e580:      	add	x19, sp, #0x70
    e584:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e588:      	ldr	x21, [sp, #0x78]
    e58c:      	ldp	x2, x24, [sp, #0x50]
    e590:      	str	x21, [sp, #0x48]
    e594:      	b	0xe5e4 <generic_lsm_path+0x4794>
    e598:      	add	x2, x24, #0x10
    e59c:      	mov	w8, #0x4                // =4
    e5a0:      	add	x9, sp, #0x98
    e5a4:      	add	x0, sp, #0x98
    e5a8:      	mov	w1, #0x8                // =8
    e5ac:      	blr	x8
    e5b0:      	ldr	x8, [sp, #0x58]
    e5b4:      	ldr	x9, [sp, #0x98]
    e5b8:      	cmp	x8, x9
    e5bc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e5c0:      	add	x2, x24, #0x18
    e5c4:      	mov	w8, #0x4                // =4
    e5c8:      	mov	x0, x22
    e5cc:      	mov	w1, #0x8                // =8
    e5d0:      	blr	x8
    e5d4:      	ldr	x24, [sp, #0x98]
    e5d8:      	ldr	x21, [sp, #0x48]
    e5dc:      	add	x2, x24, #0x20
    e5e0:      	stp	x2, x24, [sp, #0x50]
    e5e4:      	ldr	x8, [sp, #0x30]
    e5e8:      	cmp	x21, x8
    e5ec:      	b.ne	0xe5fc <generic_lsm_path+0x47ac>
    e5f0:      	ldr	x8, [sp, #0x38]
    e5f4:      	cmp	x2, x8
    e5f8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e5fc:      	mov	w8, #0x4                // =4
    e600:      	add	x0, sp, #0x70
    e604:      	mov	w1, #0x8                // =8
    e608:      	blr	x8
    e60c:      	ldr	x8, [sp, #0x70]
    e610:      	cmp	x21, x8
    e614:      	b.eq	0xe704 <generic_lsm_path+0x48b4>
    e618:      	add	x23, x21, #0x18
    e61c:      	mov	w8, #0x4                // =4
    e620:      	add	x9, sp, #0x98
    e624:      	add	x0, sp, #0x98
    e628:      	mov	w1, #0x8                // =8
    e62c:      	mov	x2, x23
    e630:      	blr	x8
    e634:      	ldr	x8, [sp, #0x98]
    e638:      	cmp	x8, x21
    e63c:      	b.eq	0xe704 <generic_lsm_path+0x48b4>
    e640:      	mov	w8, #0x4                // =4
    e644:      	add	x9, sp, #0x78
    e648:      	add	x0, sp, #0x78
    e64c:      	mov	w1, #0x8                // =8
    e650:      	mov	x2, x23
    e654:      	blr	x8
    e658:      	add	x2, x21, #0x20
    e65c:      	mov	w8, #0x4                // =4
    e660:      	mov	w9, #0x10               // =16
    e664:      	add	x10, sp, #0x80
    e668:      	add	x0, sp, #0x80
    e66c:      	mov	w1, #0x10               // =16
    e670:      	blr	x8
    e674:      	ldr	w21, [sp, #0x84]
    e678:      	ldr	x8, [sp, #0x40]
    e67c:      	ldr	x10, [sp, #0x60]
    e680:      	sub	x12, x10, x8
    e684:      	ldr	w23, [sp, #0x68]
    e688:      	subs	w10, w21, w23
    e68c:      	ldr	x9, [sp, #0x88]
    e690:      	csel	w10, wzr, w10, lo
    e694:      	cmp	w23, w21
    e698:      	csel	w11, w23, w21, lo
    e69c:      	cinc	w13, w11, hi
    e6a0:      	sub	w14, w23, w13
    e6a4:      	subs	x12, x12, x13
    e6a8:      	str	w14, [sp, #0x68]
    e6ac:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e6b0:      	cmp	x12, #0xfff
    e6b4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e6b8:      	cmp	w23, w21
    e6bc:      	b.ls	0xe6c8 <generic_lsm_path+0x4878>
    e6c0:      	mov	w13, #0x2f              // =47
    e6c4:      	strb	w13, [x8, x12]
    e6c8:      	add	x19, x8, x12
    e6cc:      	cmp	w23, w21
    e6d0:      	add	x2, x9, x10
    e6d4:      	and	w1, w11, #0xff
    e6d8:      	mov	w8, #0x4                // =4
    e6dc:      	cinc	x0, x19, hi
    e6e0:      	blr	x8
    e6e4:      	cmp	w23, w21
    e6e8:      	str	x19, [sp, #0x60]
    e6ec:      	add	x19, sp, #0x70
    e6f0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e6f4:      	ldr	x21, [sp, #0x78]
    e6f8:      	ldp	x2, x24, [sp, #0x50]
    e6fc:      	str	x21, [sp, #0x48]
    e700:      	b	0xe750 <generic_lsm_path+0x4900>
    e704:      	add	x2, x24, #0x10
    e708:      	mov	w8, #0x4                // =4
    e70c:      	add	x9, sp, #0x98
    e710:      	add	x0, sp, #0x98
    e714:      	mov	w1, #0x8                // =8
    e718:      	blr	x8
    e71c:      	ldr	x8, [sp, #0x58]
    e720:      	ldr	x9, [sp, #0x98]
    e724:      	cmp	x8, x9
    e728:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e72c:      	add	x2, x24, #0x18
    e730:      	mov	w8, #0x4                // =4
    e734:      	mov	x0, x22
    e738:      	mov	w1, #0x8                // =8
    e73c:      	blr	x8
    e740:      	ldr	x24, [sp, #0x98]
    e744:      	ldr	x21, [sp, #0x48]
    e748:      	add	x2, x24, #0x20
    e74c:      	stp	x2, x24, [sp, #0x50]
    e750:      	ldr	x8, [sp, #0x30]
    e754:      	cmp	x21, x8
    e758:      	b.ne	0xe768 <generic_lsm_path+0x4918>
    e75c:      	ldr	x8, [sp, #0x38]
    e760:      	cmp	x2, x8
    e764:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e768:      	mov	w8, #0x4                // =4
    e76c:      	add	x0, sp, #0x70
    e770:      	mov	w1, #0x8                // =8
    e774:      	blr	x8
    e778:      	ldr	x8, [sp, #0x70]
    e77c:      	cmp	x21, x8
    e780:      	b.eq	0xe870 <generic_lsm_path+0x4a20>
    e784:      	add	x23, x21, #0x18
    e788:      	mov	w8, #0x4                // =4
    e78c:      	add	x9, sp, #0x98
    e790:      	add	x0, sp, #0x98
    e794:      	mov	w1, #0x8                // =8
    e798:      	mov	x2, x23
    e79c:      	blr	x8
    e7a0:      	ldr	x8, [sp, #0x98]
    e7a4:      	cmp	x8, x21
    e7a8:      	b.eq	0xe870 <generic_lsm_path+0x4a20>
    e7ac:      	mov	w8, #0x4                // =4
    e7b0:      	add	x9, sp, #0x78
    e7b4:      	add	x0, sp, #0x78
    e7b8:      	mov	w1, #0x8                // =8
    e7bc:      	mov	x2, x23
    e7c0:      	blr	x8
    e7c4:      	add	x2, x21, #0x20
    e7c8:      	mov	w8, #0x4                // =4
    e7cc:      	mov	w9, #0x10               // =16
    e7d0:      	add	x10, sp, #0x80
    e7d4:      	add	x0, sp, #0x80
    e7d8:      	mov	w1, #0x10               // =16
    e7dc:      	blr	x8
    e7e0:      	ldr	w21, [sp, #0x84]
    e7e4:      	ldr	x8, [sp, #0x40]
    e7e8:      	ldr	x10, [sp, #0x60]
    e7ec:      	sub	x12, x10, x8
    e7f0:      	ldr	w23, [sp, #0x68]
    e7f4:      	subs	w10, w21, w23
    e7f8:      	ldr	x9, [sp, #0x88]
    e7fc:      	csel	w10, wzr, w10, lo
    e800:      	cmp	w23, w21
    e804:      	csel	w11, w23, w21, lo
    e808:      	cinc	w13, w11, hi
    e80c:      	sub	w14, w23, w13
    e810:      	subs	x12, x12, x13
    e814:      	str	w14, [sp, #0x68]
    e818:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e81c:      	cmp	x12, #0xfff
    e820:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e824:      	cmp	w23, w21
    e828:      	b.ls	0xe834 <generic_lsm_path+0x49e4>
    e82c:      	mov	w13, #0x2f              // =47
    e830:      	strb	w13, [x8, x12]
    e834:      	add	x19, x8, x12
    e838:      	cmp	w23, w21
    e83c:      	add	x2, x9, x10
    e840:      	and	w1, w11, #0xff
    e844:      	mov	w8, #0x4                // =4
    e848:      	cinc	x0, x19, hi
    e84c:      	blr	x8
    e850:      	cmp	w23, w21
    e854:      	str	x19, [sp, #0x60]
    e858:      	add	x19, sp, #0x70
    e85c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e860:      	ldr	x21, [sp, #0x78]
    e864:      	ldp	x2, x24, [sp, #0x50]
    e868:      	str	x21, [sp, #0x48]
    e86c:      	b	0xe8bc <generic_lsm_path+0x4a6c>
    e870:      	add	x2, x24, #0x10
    e874:      	mov	w8, #0x4                // =4
    e878:      	add	x9, sp, #0x98
    e87c:      	add	x0, sp, #0x98
    e880:      	mov	w1, #0x8                // =8
    e884:      	blr	x8
    e888:      	ldr	x8, [sp, #0x58]
    e88c:      	ldr	x9, [sp, #0x98]
    e890:      	cmp	x8, x9
    e894:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e898:      	add	x2, x24, #0x18
    e89c:      	mov	w8, #0x4                // =4
    e8a0:      	mov	x0, x22
    e8a4:      	mov	w1, #0x8                // =8
    e8a8:      	blr	x8
    e8ac:      	ldr	x24, [sp, #0x98]
    e8b0:      	ldr	x21, [sp, #0x48]
    e8b4:      	add	x2, x24, #0x20
    e8b8:      	stp	x2, x24, [sp, #0x50]
    e8bc:      	ldr	x8, [sp, #0x30]
    e8c0:      	cmp	x21, x8
    e8c4:      	b.ne	0xe8d4 <generic_lsm_path+0x4a84>
    e8c8:      	ldr	x8, [sp, #0x38]
    e8cc:      	cmp	x2, x8
    e8d0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    e8d4:      	mov	w8, #0x4                // =4
    e8d8:      	add	x0, sp, #0x70
    e8dc:      	mov	w1, #0x8                // =8
    e8e0:      	blr	x8
    e8e4:      	ldr	x8, [sp, #0x70]
    e8e8:      	cmp	x21, x8
    e8ec:      	b.eq	0xe9dc <generic_lsm_path+0x4b8c>
    e8f0:      	add	x23, x21, #0x18
    e8f4:      	mov	w8, #0x4                // =4
    e8f8:      	add	x9, sp, #0x98
    e8fc:      	add	x0, sp, #0x98
    e900:      	mov	w1, #0x8                // =8
    e904:      	mov	x2, x23
    e908:      	blr	x8
    e90c:      	ldr	x8, [sp, #0x98]
    e910:      	cmp	x8, x21
    e914:      	b.eq	0xe9dc <generic_lsm_path+0x4b8c>
    e918:      	mov	w8, #0x4                // =4
    e91c:      	add	x9, sp, #0x78
    e920:      	add	x0, sp, #0x78
    e924:      	mov	w1, #0x8                // =8
    e928:      	mov	x2, x23
    e92c:      	blr	x8
    e930:      	add	x2, x21, #0x20
    e934:      	mov	w8, #0x4                // =4
    e938:      	mov	w9, #0x10               // =16
    e93c:      	add	x10, sp, #0x80
    e940:      	add	x0, sp, #0x80
    e944:      	mov	w1, #0x10               // =16
    e948:      	blr	x8
    e94c:      	ldr	w21, [sp, #0x84]
    e950:      	ldr	x8, [sp, #0x40]
    e954:      	ldr	x10, [sp, #0x60]
    e958:      	sub	x12, x10, x8
    e95c:      	ldr	w23, [sp, #0x68]
    e960:      	subs	w10, w21, w23
    e964:      	ldr	x9, [sp, #0x88]
    e968:      	csel	w10, wzr, w10, lo
    e96c:      	cmp	w23, w21
    e970:      	csel	w11, w23, w21, lo
    e974:      	cinc	w13, w11, hi
    e978:      	sub	w14, w23, w13
    e97c:      	subs	x12, x12, x13
    e980:      	str	w14, [sp, #0x68]
    e984:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    e988:      	cmp	x12, #0xfff
    e98c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    e990:      	cmp	w23, w21
    e994:      	b.ls	0xe9a0 <generic_lsm_path+0x4b50>
    e998:      	mov	w13, #0x2f              // =47
    e99c:      	strb	w13, [x8, x12]
    e9a0:      	add	x19, x8, x12
    e9a4:      	cmp	w23, w21
    e9a8:      	add	x2, x9, x10
    e9ac:      	and	w1, w11, #0xff
    e9b0:      	mov	w8, #0x4                // =4
    e9b4:      	cinc	x0, x19, hi
    e9b8:      	blr	x8
    e9bc:      	cmp	w23, w21
    e9c0:      	str	x19, [sp, #0x60]
    e9c4:      	add	x19, sp, #0x70
    e9c8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    e9cc:      	ldr	x21, [sp, #0x78]
    e9d0:      	ldp	x2, x24, [sp, #0x50]
    e9d4:      	str	x21, [sp, #0x48]
    e9d8:      	b	0xea28 <generic_lsm_path+0x4bd8>
    e9dc:      	add	x2, x24, #0x10
    e9e0:      	mov	w8, #0x4                // =4
    e9e4:      	add	x9, sp, #0x98
    e9e8:      	add	x0, sp, #0x98
    e9ec:      	mov	w1, #0x8                // =8
    e9f0:      	blr	x8
    e9f4:      	ldr	x8, [sp, #0x58]
    e9f8:      	ldr	x9, [sp, #0x98]
    e9fc:      	cmp	x8, x9
    ea00:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ea04:      	add	x2, x24, #0x18
    ea08:      	mov	w8, #0x4                // =4
    ea0c:      	mov	x0, x22
    ea10:      	mov	w1, #0x8                // =8
    ea14:      	blr	x8
    ea18:      	ldr	x24, [sp, #0x98]
    ea1c:      	ldr	x21, [sp, #0x48]
    ea20:      	add	x2, x24, #0x20
    ea24:      	stp	x2, x24, [sp, #0x50]
    ea28:      	ldr	x8, [sp, #0x30]
    ea2c:      	cmp	x21, x8
    ea30:      	b.ne	0xea40 <generic_lsm_path+0x4bf0>
    ea34:      	ldr	x8, [sp, #0x38]
    ea38:      	cmp	x2, x8
    ea3c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ea40:      	mov	w8, #0x4                // =4
    ea44:      	add	x0, sp, #0x70
    ea48:      	mov	w1, #0x8                // =8
    ea4c:      	blr	x8
    ea50:      	ldr	x8, [sp, #0x70]
    ea54:      	cmp	x21, x8
    ea58:      	b.eq	0xeb48 <generic_lsm_path+0x4cf8>
    ea5c:      	add	x23, x21, #0x18
    ea60:      	mov	w8, #0x4                // =4
    ea64:      	add	x9, sp, #0x98
    ea68:      	add	x0, sp, #0x98
    ea6c:      	mov	w1, #0x8                // =8
    ea70:      	mov	x2, x23
    ea74:      	blr	x8
    ea78:      	ldr	x8, [sp, #0x98]
    ea7c:      	cmp	x8, x21
    ea80:      	b.eq	0xeb48 <generic_lsm_path+0x4cf8>
    ea84:      	mov	w8, #0x4                // =4
    ea88:      	add	x9, sp, #0x78
    ea8c:      	add	x0, sp, #0x78
    ea90:      	mov	w1, #0x8                // =8
    ea94:      	mov	x2, x23
    ea98:      	blr	x8
    ea9c:      	add	x2, x21, #0x20
    eaa0:      	mov	w8, #0x4                // =4
    eaa4:      	mov	w9, #0x10               // =16
    eaa8:      	add	x10, sp, #0x80
    eaac:      	add	x0, sp, #0x80
    eab0:      	mov	w1, #0x10               // =16
    eab4:      	blr	x8
    eab8:      	ldr	w21, [sp, #0x84]
    eabc:      	ldr	x8, [sp, #0x40]
    eac0:      	ldr	x10, [sp, #0x60]
    eac4:      	sub	x12, x10, x8
    eac8:      	ldr	w23, [sp, #0x68]
    eacc:      	subs	w10, w21, w23
    ead0:      	ldr	x9, [sp, #0x88]
    ead4:      	csel	w10, wzr, w10, lo
    ead8:      	cmp	w23, w21
    eadc:      	csel	w11, w23, w21, lo
    eae0:      	cinc	w13, w11, hi
    eae4:      	sub	w14, w23, w13
    eae8:      	subs	x12, x12, x13
    eaec:      	str	w14, [sp, #0x68]
    eaf0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    eaf4:      	cmp	x12, #0xfff
    eaf8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    eafc:      	cmp	w23, w21
    eb00:      	b.ls	0xeb0c <generic_lsm_path+0x4cbc>
    eb04:      	mov	w13, #0x2f              // =47
    eb08:      	strb	w13, [x8, x12]
    eb0c:      	add	x19, x8, x12
    eb10:      	cmp	w23, w21
    eb14:      	add	x2, x9, x10
    eb18:      	and	w1, w11, #0xff
    eb1c:      	mov	w8, #0x4                // =4
    eb20:      	cinc	x0, x19, hi
    eb24:      	blr	x8
    eb28:      	cmp	w23, w21
    eb2c:      	str	x19, [sp, #0x60]
    eb30:      	add	x19, sp, #0x70
    eb34:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    eb38:      	ldr	x21, [sp, #0x78]
    eb3c:      	ldp	x2, x24, [sp, #0x50]
    eb40:      	str	x21, [sp, #0x48]
    eb44:      	b	0xeb94 <generic_lsm_path+0x4d44>
    eb48:      	add	x2, x24, #0x10
    eb4c:      	mov	w8, #0x4                // =4
    eb50:      	add	x9, sp, #0x98
    eb54:      	add	x0, sp, #0x98
    eb58:      	mov	w1, #0x8                // =8
    eb5c:      	blr	x8
    eb60:      	ldr	x8, [sp, #0x58]
    eb64:      	ldr	x9, [sp, #0x98]
    eb68:      	cmp	x8, x9
    eb6c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    eb70:      	add	x2, x24, #0x18
    eb74:      	mov	w8, #0x4                // =4
    eb78:      	mov	x0, x22
    eb7c:      	mov	w1, #0x8                // =8
    eb80:      	blr	x8
    eb84:      	ldr	x24, [sp, #0x98]
    eb88:      	ldr	x21, [sp, #0x48]
    eb8c:      	add	x2, x24, #0x20
    eb90:      	stp	x2, x24, [sp, #0x50]
    eb94:      	ldr	x8, [sp, #0x30]
    eb98:      	cmp	x21, x8
    eb9c:      	b.ne	0xebac <generic_lsm_path+0x4d5c>
    eba0:      	ldr	x8, [sp, #0x38]
    eba4:      	cmp	x2, x8
    eba8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ebac:      	mov	w8, #0x4                // =4
    ebb0:      	add	x0, sp, #0x70
    ebb4:      	mov	w1, #0x8                // =8
    ebb8:      	blr	x8
    ebbc:      	ldr	x8, [sp, #0x70]
    ebc0:      	cmp	x21, x8
    ebc4:      	b.eq	0xecb4 <generic_lsm_path+0x4e64>
    ebc8:      	add	x23, x21, #0x18
    ebcc:      	mov	w8, #0x4                // =4
    ebd0:      	add	x9, sp, #0x98
    ebd4:      	add	x0, sp, #0x98
    ebd8:      	mov	w1, #0x8                // =8
    ebdc:      	mov	x2, x23
    ebe0:      	blr	x8
    ebe4:      	ldr	x8, [sp, #0x98]
    ebe8:      	cmp	x8, x21
    ebec:      	b.eq	0xecb4 <generic_lsm_path+0x4e64>
    ebf0:      	mov	w8, #0x4                // =4
    ebf4:      	add	x9, sp, #0x78
    ebf8:      	add	x0, sp, #0x78
    ebfc:      	mov	w1, #0x8                // =8
    ec00:      	mov	x2, x23
    ec04:      	blr	x8
    ec08:      	add	x2, x21, #0x20
    ec0c:      	mov	w8, #0x4                // =4
    ec10:      	mov	w9, #0x10               // =16
    ec14:      	add	x10, sp, #0x80
    ec18:      	add	x0, sp, #0x80
    ec1c:      	mov	w1, #0x10               // =16
    ec20:      	blr	x8
    ec24:      	ldr	w21, [sp, #0x84]
    ec28:      	ldr	x8, [sp, #0x40]
    ec2c:      	ldr	x10, [sp, #0x60]
    ec30:      	sub	x12, x10, x8
    ec34:      	ldr	w23, [sp, #0x68]
    ec38:      	subs	w10, w21, w23
    ec3c:      	ldr	x9, [sp, #0x88]
    ec40:      	csel	w10, wzr, w10, lo
    ec44:      	cmp	w23, w21
    ec48:      	csel	w11, w23, w21, lo
    ec4c:      	cinc	w13, w11, hi
    ec50:      	sub	w14, w23, w13
    ec54:      	subs	x12, x12, x13
    ec58:      	str	w14, [sp, #0x68]
    ec5c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    ec60:      	cmp	x12, #0xfff
    ec64:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    ec68:      	cmp	w23, w21
    ec6c:      	b.ls	0xec78 <generic_lsm_path+0x4e28>
    ec70:      	mov	w13, #0x2f              // =47
    ec74:      	strb	w13, [x8, x12]
    ec78:      	add	x19, x8, x12
    ec7c:      	cmp	w23, w21
    ec80:      	add	x2, x9, x10
    ec84:      	and	w1, w11, #0xff
    ec88:      	mov	w8, #0x4                // =4
    ec8c:      	cinc	x0, x19, hi
    ec90:      	blr	x8
    ec94:      	cmp	w23, w21
    ec98:      	str	x19, [sp, #0x60]
    ec9c:      	add	x19, sp, #0x70
    eca0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    eca4:      	ldr	x21, [sp, #0x78]
    eca8:      	ldp	x2, x24, [sp, #0x50]
    ecac:      	str	x21, [sp, #0x48]
    ecb0:      	b	0xed00 <generic_lsm_path+0x4eb0>
    ecb4:      	add	x2, x24, #0x10
    ecb8:      	mov	w8, #0x4                // =4
    ecbc:      	add	x9, sp, #0x98
    ecc0:      	add	x0, sp, #0x98
    ecc4:      	mov	w1, #0x8                // =8
    ecc8:      	blr	x8
    eccc:      	ldr	x8, [sp, #0x58]
    ecd0:      	ldr	x9, [sp, #0x98]
    ecd4:      	cmp	x8, x9
    ecd8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ecdc:      	add	x2, x24, #0x18
    ece0:      	mov	w8, #0x4                // =4
    ece4:      	mov	x0, x22
    ece8:      	mov	w1, #0x8                // =8
    ecec:      	blr	x8
    ecf0:      	ldr	x24, [sp, #0x98]
    ecf4:      	ldr	x21, [sp, #0x48]
    ecf8:      	add	x2, x24, #0x20
    ecfc:      	stp	x2, x24, [sp, #0x50]
    ed00:      	ldr	x8, [sp, #0x30]
    ed04:      	cmp	x21, x8
    ed08:      	b.ne	0xed18 <generic_lsm_path+0x4ec8>
    ed0c:      	ldr	x8, [sp, #0x38]
    ed10:      	cmp	x2, x8
    ed14:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ed18:      	mov	w8, #0x4                // =4
    ed1c:      	add	x0, sp, #0x70
    ed20:      	mov	w1, #0x8                // =8
    ed24:      	blr	x8
    ed28:      	ldr	x8, [sp, #0x70]
    ed2c:      	cmp	x21, x8
    ed30:      	b.eq	0xee20 <generic_lsm_path+0x4fd0>
    ed34:      	add	x23, x21, #0x18
    ed38:      	mov	w8, #0x4                // =4
    ed3c:      	add	x9, sp, #0x98
    ed40:      	add	x0, sp, #0x98
    ed44:      	mov	w1, #0x8                // =8
    ed48:      	mov	x2, x23
    ed4c:      	blr	x8
    ed50:      	ldr	x8, [sp, #0x98]
    ed54:      	cmp	x8, x21
    ed58:      	b.eq	0xee20 <generic_lsm_path+0x4fd0>
    ed5c:      	mov	w8, #0x4                // =4
    ed60:      	add	x9, sp, #0x78
    ed64:      	add	x0, sp, #0x78
    ed68:      	mov	w1, #0x8                // =8
    ed6c:      	mov	x2, x23
    ed70:      	blr	x8
    ed74:      	add	x2, x21, #0x20
    ed78:      	mov	w8, #0x4                // =4
    ed7c:      	mov	w9, #0x10               // =16
    ed80:      	add	x10, sp, #0x80
    ed84:      	add	x0, sp, #0x80
    ed88:      	mov	w1, #0x10               // =16
    ed8c:      	blr	x8
    ed90:      	ldr	w21, [sp, #0x84]
    ed94:      	ldr	x8, [sp, #0x40]
    ed98:      	ldr	x10, [sp, #0x60]
    ed9c:      	sub	x12, x10, x8
    eda0:      	ldr	w23, [sp, #0x68]
    eda4:      	subs	w10, w21, w23
    eda8:      	ldr	x9, [sp, #0x88]
    edac:      	csel	w10, wzr, w10, lo
    edb0:      	cmp	w23, w21
    edb4:      	csel	w11, w23, w21, lo
    edb8:      	cinc	w13, w11, hi
    edbc:      	sub	w14, w23, w13
    edc0:      	subs	x12, x12, x13
    edc4:      	str	w14, [sp, #0x68]
    edc8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    edcc:      	cmp	x12, #0xfff
    edd0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    edd4:      	cmp	w23, w21
    edd8:      	b.ls	0xede4 <generic_lsm_path+0x4f94>
    eddc:      	mov	w13, #0x2f              // =47
    ede0:      	strb	w13, [x8, x12]
    ede4:      	add	x19, x8, x12
    ede8:      	cmp	w23, w21
    edec:      	add	x2, x9, x10
    edf0:      	and	w1, w11, #0xff
    edf4:      	mov	w8, #0x4                // =4
    edf8:      	cinc	x0, x19, hi
    edfc:      	blr	x8
    ee00:      	cmp	w23, w21
    ee04:      	str	x19, [sp, #0x60]
    ee08:      	add	x19, sp, #0x70
    ee0c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ee10:      	ldr	x21, [sp, #0x78]
    ee14:      	ldp	x2, x24, [sp, #0x50]
    ee18:      	str	x21, [sp, #0x48]
    ee1c:      	b	0xee6c <generic_lsm_path+0x501c>
    ee20:      	add	x2, x24, #0x10
    ee24:      	mov	w8, #0x4                // =4
    ee28:      	add	x9, sp, #0x98
    ee2c:      	add	x0, sp, #0x98
    ee30:      	mov	w1, #0x8                // =8
    ee34:      	blr	x8
    ee38:      	ldr	x8, [sp, #0x58]
    ee3c:      	ldr	x9, [sp, #0x98]
    ee40:      	cmp	x8, x9
    ee44:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ee48:      	add	x2, x24, #0x18
    ee4c:      	mov	w8, #0x4                // =4
    ee50:      	mov	x0, x22
    ee54:      	mov	w1, #0x8                // =8
    ee58:      	blr	x8
    ee5c:      	ldr	x24, [sp, #0x98]
    ee60:      	ldr	x21, [sp, #0x48]
    ee64:      	add	x2, x24, #0x20
    ee68:      	stp	x2, x24, [sp, #0x50]
    ee6c:      	ldr	x8, [sp, #0x30]
    ee70:      	cmp	x21, x8
    ee74:      	b.ne	0xee84 <generic_lsm_path+0x5034>
    ee78:      	ldr	x8, [sp, #0x38]
    ee7c:      	cmp	x2, x8
    ee80:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ee84:      	mov	w8, #0x4                // =4
    ee88:      	add	x0, sp, #0x70
    ee8c:      	mov	w1, #0x8                // =8
    ee90:      	blr	x8
    ee94:      	ldr	x8, [sp, #0x70]
    ee98:      	cmp	x21, x8
    ee9c:      	b.eq	0xef8c <generic_lsm_path+0x513c>
    eea0:      	add	x23, x21, #0x18
    eea4:      	mov	w8, #0x4                // =4
    eea8:      	add	x9, sp, #0x98
    eeac:      	add	x0, sp, #0x98
    eeb0:      	mov	w1, #0x8                // =8
    eeb4:      	mov	x2, x23
    eeb8:      	blr	x8
    eebc:      	ldr	x8, [sp, #0x98]
    eec0:      	cmp	x8, x21
    eec4:      	b.eq	0xef8c <generic_lsm_path+0x513c>
    eec8:      	mov	w8, #0x4                // =4
    eecc:      	add	x9, sp, #0x78
    eed0:      	add	x0, sp, #0x78
    eed4:      	mov	w1, #0x8                // =8
    eed8:      	mov	x2, x23
    eedc:      	blr	x8
    eee0:      	add	x2, x21, #0x20
    eee4:      	mov	w8, #0x4                // =4
    eee8:      	mov	w9, #0x10               // =16
    eeec:      	add	x10, sp, #0x80
    eef0:      	add	x0, sp, #0x80
    eef4:      	mov	w1, #0x10               // =16
    eef8:      	blr	x8
    eefc:      	ldr	w21, [sp, #0x84]
    ef00:      	ldr	x8, [sp, #0x40]
    ef04:      	ldr	x10, [sp, #0x60]
    ef08:      	sub	x12, x10, x8
    ef0c:      	ldr	w23, [sp, #0x68]
    ef10:      	subs	w10, w21, w23
    ef14:      	ldr	x9, [sp, #0x88]
    ef18:      	csel	w10, wzr, w10, lo
    ef1c:      	cmp	w23, w21
    ef20:      	csel	w11, w23, w21, lo
    ef24:      	cinc	w13, w11, hi
    ef28:      	sub	w14, w23, w13
    ef2c:      	subs	x12, x12, x13
    ef30:      	str	w14, [sp, #0x68]
    ef34:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    ef38:      	cmp	x12, #0xfff
    ef3c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    ef40:      	cmp	w23, w21
    ef44:      	b.ls	0xef50 <generic_lsm_path+0x5100>
    ef48:      	mov	w13, #0x2f              // =47
    ef4c:      	strb	w13, [x8, x12]
    ef50:      	add	x19, x8, x12
    ef54:      	cmp	w23, w21
    ef58:      	add	x2, x9, x10
    ef5c:      	and	w1, w11, #0xff
    ef60:      	mov	w8, #0x4                // =4
    ef64:      	cinc	x0, x19, hi
    ef68:      	blr	x8
    ef6c:      	cmp	w23, w21
    ef70:      	str	x19, [sp, #0x60]
    ef74:      	add	x19, sp, #0x70
    ef78:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ef7c:      	ldr	x21, [sp, #0x78]
    ef80:      	ldp	x2, x24, [sp, #0x50]
    ef84:      	str	x21, [sp, #0x48]
    ef88:      	b	0xefd8 <generic_lsm_path+0x5188>
    ef8c:      	add	x2, x24, #0x10
    ef90:      	mov	w8, #0x4                // =4
    ef94:      	add	x9, sp, #0x98
    ef98:      	add	x0, sp, #0x98
    ef9c:      	mov	w1, #0x8                // =8
    efa0:      	blr	x8
    efa4:      	ldr	x8, [sp, #0x58]
    efa8:      	ldr	x9, [sp, #0x98]
    efac:      	cmp	x8, x9
    efb0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    efb4:      	add	x2, x24, #0x18
    efb8:      	mov	w8, #0x4                // =4
    efbc:      	mov	x0, x22
    efc0:      	mov	w1, #0x8                // =8
    efc4:      	blr	x8
    efc8:      	ldr	x24, [sp, #0x98]
    efcc:      	ldr	x21, [sp, #0x48]
    efd0:      	add	x2, x24, #0x20
    efd4:      	stp	x2, x24, [sp, #0x50]
    efd8:      	ldr	x8, [sp, #0x30]
    efdc:      	cmp	x21, x8
    efe0:      	b.ne	0xeff0 <generic_lsm_path+0x51a0>
    efe4:      	ldr	x8, [sp, #0x38]
    efe8:      	cmp	x2, x8
    efec:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    eff0:      	mov	w8, #0x4                // =4
    eff4:      	add	x0, sp, #0x70
    eff8:      	mov	w1, #0x8                // =8
    effc:      	blr	x8
    f000:      	ldr	x8, [sp, #0x70]
    f004:      	cmp	x21, x8
    f008:      	b.eq	0xf0f8 <generic_lsm_path+0x52a8>
    f00c:      	add	x23, x21, #0x18
    f010:      	mov	w8, #0x4                // =4
    f014:      	add	x9, sp, #0x98
    f018:      	add	x0, sp, #0x98
    f01c:      	mov	w1, #0x8                // =8
    f020:      	mov	x2, x23
    f024:      	blr	x8
    f028:      	ldr	x8, [sp, #0x98]
    f02c:      	cmp	x8, x21
    f030:      	b.eq	0xf0f8 <generic_lsm_path+0x52a8>
    f034:      	mov	w8, #0x4                // =4
    f038:      	add	x9, sp, #0x78
    f03c:      	add	x0, sp, #0x78
    f040:      	mov	w1, #0x8                // =8
    f044:      	mov	x2, x23
    f048:      	blr	x8
    f04c:      	add	x2, x21, #0x20
    f050:      	mov	w8, #0x4                // =4
    f054:      	mov	w9, #0x10               // =16
    f058:      	add	x10, sp, #0x80
    f05c:      	add	x0, sp, #0x80
    f060:      	mov	w1, #0x10               // =16
    f064:      	blr	x8
    f068:      	ldr	w21, [sp, #0x84]
    f06c:      	ldr	x8, [sp, #0x40]
    f070:      	ldr	x10, [sp, #0x60]
    f074:      	sub	x12, x10, x8
    f078:      	ldr	w23, [sp, #0x68]
    f07c:      	subs	w10, w21, w23
    f080:      	ldr	x9, [sp, #0x88]
    f084:      	csel	w10, wzr, w10, lo
    f088:      	cmp	w23, w21
    f08c:      	csel	w11, w23, w21, lo
    f090:      	cinc	w13, w11, hi
    f094:      	sub	w14, w23, w13
    f098:      	subs	x12, x12, x13
    f09c:      	str	w14, [sp, #0x68]
    f0a0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f0a4:      	cmp	x12, #0xfff
    f0a8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f0ac:      	cmp	w23, w21
    f0b0:      	b.ls	0xf0bc <generic_lsm_path+0x526c>
    f0b4:      	mov	w13, #0x2f              // =47
    f0b8:      	strb	w13, [x8, x12]
    f0bc:      	add	x19, x8, x12
    f0c0:      	cmp	w23, w21
    f0c4:      	add	x2, x9, x10
    f0c8:      	and	w1, w11, #0xff
    f0cc:      	mov	w8, #0x4                // =4
    f0d0:      	cinc	x0, x19, hi
    f0d4:      	blr	x8
    f0d8:      	cmp	w23, w21
    f0dc:      	str	x19, [sp, #0x60]
    f0e0:      	add	x19, sp, #0x70
    f0e4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f0e8:      	ldr	x21, [sp, #0x78]
    f0ec:      	ldp	x2, x24, [sp, #0x50]
    f0f0:      	str	x21, [sp, #0x48]
    f0f4:      	b	0xf144 <generic_lsm_path+0x52f4>
    f0f8:      	add	x2, x24, #0x10
    f0fc:      	mov	w8, #0x4                // =4
    f100:      	add	x9, sp, #0x98
    f104:      	add	x0, sp, #0x98
    f108:      	mov	w1, #0x8                // =8
    f10c:      	blr	x8
    f110:      	ldr	x8, [sp, #0x58]
    f114:      	ldr	x9, [sp, #0x98]
    f118:      	cmp	x8, x9
    f11c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f120:      	add	x2, x24, #0x18
    f124:      	mov	w8, #0x4                // =4
    f128:      	mov	x0, x22
    f12c:      	mov	w1, #0x8                // =8
    f130:      	blr	x8
    f134:      	ldr	x24, [sp, #0x98]
    f138:      	ldr	x21, [sp, #0x48]
    f13c:      	add	x2, x24, #0x20
    f140:      	stp	x2, x24, [sp, #0x50]
    f144:      	ldr	x8, [sp, #0x30]
    f148:      	cmp	x21, x8
    f14c:      	b.ne	0xf15c <generic_lsm_path+0x530c>
    f150:      	ldr	x8, [sp, #0x38]
    f154:      	cmp	x2, x8
    f158:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f15c:      	mov	w8, #0x4                // =4
    f160:      	add	x0, sp, #0x70
    f164:      	mov	w1, #0x8                // =8
    f168:      	blr	x8
    f16c:      	ldr	x8, [sp, #0x70]
    f170:      	cmp	x21, x8
    f174:      	b.eq	0xf264 <generic_lsm_path+0x5414>
    f178:      	add	x23, x21, #0x18
    f17c:      	mov	w8, #0x4                // =4
    f180:      	add	x9, sp, #0x98
    f184:      	add	x0, sp, #0x98
    f188:      	mov	w1, #0x8                // =8
    f18c:      	mov	x2, x23
    f190:      	blr	x8
    f194:      	ldr	x8, [sp, #0x98]
    f198:      	cmp	x8, x21
    f19c:      	b.eq	0xf264 <generic_lsm_path+0x5414>
    f1a0:      	mov	w8, #0x4                // =4
    f1a4:      	add	x9, sp, #0x78
    f1a8:      	add	x0, sp, #0x78
    f1ac:      	mov	w1, #0x8                // =8
    f1b0:      	mov	x2, x23
    f1b4:      	blr	x8
    f1b8:      	add	x2, x21, #0x20
    f1bc:      	mov	w8, #0x4                // =4
    f1c0:      	mov	w9, #0x10               // =16
    f1c4:      	add	x10, sp, #0x80
    f1c8:      	add	x0, sp, #0x80
    f1cc:      	mov	w1, #0x10               // =16
    f1d0:      	blr	x8
    f1d4:      	ldr	w21, [sp, #0x84]
    f1d8:      	ldr	x8, [sp, #0x40]
    f1dc:      	ldr	x10, [sp, #0x60]
    f1e0:      	sub	x12, x10, x8
    f1e4:      	ldr	w23, [sp, #0x68]
    f1e8:      	subs	w10, w21, w23
    f1ec:      	ldr	x9, [sp, #0x88]
    f1f0:      	csel	w10, wzr, w10, lo
    f1f4:      	cmp	w23, w21
    f1f8:      	csel	w11, w23, w21, lo
    f1fc:      	cinc	w13, w11, hi
    f200:      	sub	w14, w23, w13
    f204:      	subs	x12, x12, x13
    f208:      	str	w14, [sp, #0x68]
    f20c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f210:      	cmp	x12, #0xfff
    f214:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f218:      	cmp	w23, w21
    f21c:      	b.ls	0xf228 <generic_lsm_path+0x53d8>
    f220:      	mov	w13, #0x2f              // =47
    f224:      	strb	w13, [x8, x12]
    f228:      	add	x19, x8, x12
    f22c:      	cmp	w23, w21
    f230:      	add	x2, x9, x10
    f234:      	and	w1, w11, #0xff
    f238:      	mov	w8, #0x4                // =4
    f23c:      	cinc	x0, x19, hi
    f240:      	blr	x8
    f244:      	cmp	w23, w21
    f248:      	str	x19, [sp, #0x60]
    f24c:      	add	x19, sp, #0x70
    f250:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f254:      	ldr	x21, [sp, #0x78]
    f258:      	ldp	x2, x24, [sp, #0x50]
    f25c:      	str	x21, [sp, #0x48]
    f260:      	b	0xf2b0 <generic_lsm_path+0x5460>
    f264:      	add	x2, x24, #0x10
    f268:      	mov	w8, #0x4                // =4
    f26c:      	add	x9, sp, #0x98
    f270:      	add	x0, sp, #0x98
    f274:      	mov	w1, #0x8                // =8
    f278:      	blr	x8
    f27c:      	ldr	x8, [sp, #0x58]
    f280:      	ldr	x9, [sp, #0x98]
    f284:      	cmp	x8, x9
    f288:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f28c:      	add	x2, x24, #0x18
    f290:      	mov	w8, #0x4                // =4
    f294:      	mov	x0, x22
    f298:      	mov	w1, #0x8                // =8
    f29c:      	blr	x8
    f2a0:      	ldr	x24, [sp, #0x98]
    f2a4:      	ldr	x21, [sp, #0x48]
    f2a8:      	add	x2, x24, #0x20
    f2ac:      	stp	x2, x24, [sp, #0x50]
    f2b0:      	ldr	x8, [sp, #0x30]
    f2b4:      	cmp	x21, x8
    f2b8:      	b.ne	0xf2c8 <generic_lsm_path+0x5478>
    f2bc:      	ldr	x8, [sp, #0x38]
    f2c0:      	cmp	x2, x8
    f2c4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f2c8:      	mov	w8, #0x4                // =4
    f2cc:      	add	x0, sp, #0x70
    f2d0:      	mov	w1, #0x8                // =8
    f2d4:      	blr	x8
    f2d8:      	ldr	x8, [sp, #0x70]
    f2dc:      	cmp	x21, x8
    f2e0:      	b.eq	0xf3d0 <generic_lsm_path+0x5580>
    f2e4:      	add	x23, x21, #0x18
    f2e8:      	mov	w8, #0x4                // =4
    f2ec:      	add	x9, sp, #0x98
    f2f0:      	add	x0, sp, #0x98
    f2f4:      	mov	w1, #0x8                // =8
    f2f8:      	mov	x2, x23
    f2fc:      	blr	x8
    f300:      	ldr	x8, [sp, #0x98]
    f304:      	cmp	x8, x21
    f308:      	b.eq	0xf3d0 <generic_lsm_path+0x5580>
    f30c:      	mov	w8, #0x4                // =4
    f310:      	add	x9, sp, #0x78
    f314:      	add	x0, sp, #0x78
    f318:      	mov	w1, #0x8                // =8
    f31c:      	mov	x2, x23
    f320:      	blr	x8
    f324:      	add	x2, x21, #0x20
    f328:      	mov	w8, #0x4                // =4
    f32c:      	mov	w9, #0x10               // =16
    f330:      	add	x10, sp, #0x80
    f334:      	add	x0, sp, #0x80
    f338:      	mov	w1, #0x10               // =16
    f33c:      	blr	x8
    f340:      	ldr	w21, [sp, #0x84]
    f344:      	ldr	x8, [sp, #0x40]
    f348:      	ldr	x10, [sp, #0x60]
    f34c:      	sub	x12, x10, x8
    f350:      	ldr	w23, [sp, #0x68]
    f354:      	subs	w10, w21, w23
    f358:      	ldr	x9, [sp, #0x88]
    f35c:      	csel	w10, wzr, w10, lo
    f360:      	cmp	w23, w21
    f364:      	csel	w11, w23, w21, lo
    f368:      	cinc	w13, w11, hi
    f36c:      	sub	w14, w23, w13
    f370:      	subs	x12, x12, x13
    f374:      	str	w14, [sp, #0x68]
    f378:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f37c:      	cmp	x12, #0xfff
    f380:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f384:      	cmp	w23, w21
    f388:      	b.ls	0xf394 <generic_lsm_path+0x5544>
    f38c:      	mov	w13, #0x2f              // =47
    f390:      	strb	w13, [x8, x12]
    f394:      	add	x19, x8, x12
    f398:      	cmp	w23, w21
    f39c:      	add	x2, x9, x10
    f3a0:      	and	w1, w11, #0xff
    f3a4:      	mov	w8, #0x4                // =4
    f3a8:      	cinc	x0, x19, hi
    f3ac:      	blr	x8
    f3b0:      	cmp	w23, w21
    f3b4:      	str	x19, [sp, #0x60]
    f3b8:      	add	x19, sp, #0x70
    f3bc:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f3c0:      	ldr	x21, [sp, #0x78]
    f3c4:      	ldp	x2, x24, [sp, #0x50]
    f3c8:      	str	x21, [sp, #0x48]
    f3cc:      	b	0xf41c <generic_lsm_path+0x55cc>
    f3d0:      	add	x2, x24, #0x10
    f3d4:      	mov	w8, #0x4                // =4
    f3d8:      	add	x9, sp, #0x98
    f3dc:      	add	x0, sp, #0x98
    f3e0:      	mov	w1, #0x8                // =8
    f3e4:      	blr	x8
    f3e8:      	ldr	x8, [sp, #0x58]
    f3ec:      	ldr	x9, [sp, #0x98]
    f3f0:      	cmp	x8, x9
    f3f4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f3f8:      	add	x2, x24, #0x18
    f3fc:      	mov	w8, #0x4                // =4
    f400:      	mov	x0, x22
    f404:      	mov	w1, #0x8                // =8
    f408:      	blr	x8
    f40c:      	ldr	x24, [sp, #0x98]
    f410:      	ldr	x21, [sp, #0x48]
    f414:      	add	x2, x24, #0x20
    f418:      	stp	x2, x24, [sp, #0x50]
    f41c:      	ldr	x8, [sp, #0x30]
    f420:      	cmp	x21, x8
    f424:      	b.ne	0xf434 <generic_lsm_path+0x55e4>
    f428:      	ldr	x8, [sp, #0x38]
    f42c:      	cmp	x2, x8
    f430:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f434:      	mov	w8, #0x4                // =4
    f438:      	add	x0, sp, #0x70
    f43c:      	mov	w1, #0x8                // =8
    f440:      	blr	x8
    f444:      	ldr	x8, [sp, #0x70]
    f448:      	cmp	x21, x8
    f44c:      	b.eq	0xf53c <generic_lsm_path+0x56ec>
    f450:      	add	x23, x21, #0x18
    f454:      	mov	w8, #0x4                // =4
    f458:      	add	x9, sp, #0x98
    f45c:      	add	x0, sp, #0x98
    f460:      	mov	w1, #0x8                // =8
    f464:      	mov	x2, x23
    f468:      	blr	x8
    f46c:      	ldr	x8, [sp, #0x98]
    f470:      	cmp	x8, x21
    f474:      	b.eq	0xf53c <generic_lsm_path+0x56ec>
    f478:      	mov	w8, #0x4                // =4
    f47c:      	add	x9, sp, #0x78
    f480:      	add	x0, sp, #0x78
    f484:      	mov	w1, #0x8                // =8
    f488:      	mov	x2, x23
    f48c:      	blr	x8
    f490:      	add	x2, x21, #0x20
    f494:      	mov	w8, #0x4                // =4
    f498:      	mov	w9, #0x10               // =16
    f49c:      	add	x10, sp, #0x80
    f4a0:      	add	x0, sp, #0x80
    f4a4:      	mov	w1, #0x10               // =16
    f4a8:      	blr	x8
    f4ac:      	ldr	w21, [sp, #0x84]
    f4b0:      	ldr	x8, [sp, #0x40]
    f4b4:      	ldr	x10, [sp, #0x60]
    f4b8:      	sub	x12, x10, x8
    f4bc:      	ldr	w23, [sp, #0x68]
    f4c0:      	subs	w10, w21, w23
    f4c4:      	ldr	x9, [sp, #0x88]
    f4c8:      	csel	w10, wzr, w10, lo
    f4cc:      	cmp	w23, w21
    f4d0:      	csel	w11, w23, w21, lo
    f4d4:      	cinc	w13, w11, hi
    f4d8:      	sub	w14, w23, w13
    f4dc:      	subs	x12, x12, x13
    f4e0:      	str	w14, [sp, #0x68]
    f4e4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f4e8:      	cmp	x12, #0xfff
    f4ec:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f4f0:      	cmp	w23, w21
    f4f4:      	b.ls	0xf500 <generic_lsm_path+0x56b0>
    f4f8:      	mov	w13, #0x2f              // =47
    f4fc:      	strb	w13, [x8, x12]
    f500:      	add	x19, x8, x12
    f504:      	cmp	w23, w21
    f508:      	add	x2, x9, x10
    f50c:      	and	w1, w11, #0xff
    f510:      	mov	w8, #0x4                // =4
    f514:      	cinc	x0, x19, hi
    f518:      	blr	x8
    f51c:      	cmp	w23, w21
    f520:      	str	x19, [sp, #0x60]
    f524:      	add	x19, sp, #0x70
    f528:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f52c:      	ldr	x21, [sp, #0x78]
    f530:      	ldp	x2, x24, [sp, #0x50]
    f534:      	str	x21, [sp, #0x48]
    f538:      	b	0xf588 <generic_lsm_path+0x5738>
    f53c:      	add	x2, x24, #0x10
    f540:      	mov	w8, #0x4                // =4
    f544:      	add	x9, sp, #0x98
    f548:      	add	x0, sp, #0x98
    f54c:      	mov	w1, #0x8                // =8
    f550:      	blr	x8
    f554:      	ldr	x8, [sp, #0x58]
    f558:      	ldr	x9, [sp, #0x98]
    f55c:      	cmp	x8, x9
    f560:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f564:      	add	x2, x24, #0x18
    f568:      	mov	w8, #0x4                // =4
    f56c:      	mov	x0, x22
    f570:      	mov	w1, #0x8                // =8
    f574:      	blr	x8
    f578:      	ldr	x24, [sp, #0x98]
    f57c:      	ldr	x21, [sp, #0x48]
    f580:      	add	x2, x24, #0x20
    f584:      	stp	x2, x24, [sp, #0x50]
    f588:      	ldr	x8, [sp, #0x30]
    f58c:      	cmp	x21, x8
    f590:      	b.ne	0xf5a0 <generic_lsm_path+0x5750>
    f594:      	ldr	x8, [sp, #0x38]
    f598:      	cmp	x2, x8
    f59c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f5a0:      	mov	w8, #0x4                // =4
    f5a4:      	add	x0, sp, #0x70
    f5a8:      	mov	w1, #0x8                // =8
    f5ac:      	blr	x8
    f5b0:      	ldr	x8, [sp, #0x70]
    f5b4:      	cmp	x21, x8
    f5b8:      	b.eq	0xf6a8 <generic_lsm_path+0x5858>
    f5bc:      	add	x23, x21, #0x18
    f5c0:      	mov	w8, #0x4                // =4
    f5c4:      	add	x9, sp, #0x98
    f5c8:      	add	x0, sp, #0x98
    f5cc:      	mov	w1, #0x8                // =8
    f5d0:      	mov	x2, x23
    f5d4:      	blr	x8
    f5d8:      	ldr	x8, [sp, #0x98]
    f5dc:      	cmp	x8, x21
    f5e0:      	b.eq	0xf6a8 <generic_lsm_path+0x5858>
    f5e4:      	mov	w8, #0x4                // =4
    f5e8:      	add	x9, sp, #0x78
    f5ec:      	add	x0, sp, #0x78
    f5f0:      	mov	w1, #0x8                // =8
    f5f4:      	mov	x2, x23
    f5f8:      	blr	x8
    f5fc:      	add	x2, x21, #0x20
    f600:      	mov	w8, #0x4                // =4
    f604:      	mov	w9, #0x10               // =16
    f608:      	add	x10, sp, #0x80
    f60c:      	add	x0, sp, #0x80
    f610:      	mov	w1, #0x10               // =16
    f614:      	blr	x8
    f618:      	ldr	w21, [sp, #0x84]
    f61c:      	ldr	x8, [sp, #0x40]
    f620:      	ldr	x10, [sp, #0x60]
    f624:      	sub	x12, x10, x8
    f628:      	ldr	w23, [sp, #0x68]
    f62c:      	subs	w10, w21, w23
    f630:      	ldr	x9, [sp, #0x88]
    f634:      	csel	w10, wzr, w10, lo
    f638:      	cmp	w23, w21
    f63c:      	csel	w11, w23, w21, lo
    f640:      	cinc	w13, w11, hi
    f644:      	sub	w14, w23, w13
    f648:      	subs	x12, x12, x13
    f64c:      	str	w14, [sp, #0x68]
    f650:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f654:      	cmp	x12, #0xfff
    f658:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f65c:      	cmp	w23, w21
    f660:      	b.ls	0xf66c <generic_lsm_path+0x581c>
    f664:      	mov	w13, #0x2f              // =47
    f668:      	strb	w13, [x8, x12]
    f66c:      	add	x19, x8, x12
    f670:      	cmp	w23, w21
    f674:      	add	x2, x9, x10
    f678:      	and	w1, w11, #0xff
    f67c:      	mov	w8, #0x4                // =4
    f680:      	cinc	x0, x19, hi
    f684:      	blr	x8
    f688:      	cmp	w23, w21
    f68c:      	str	x19, [sp, #0x60]
    f690:      	add	x19, sp, #0x70
    f694:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f698:      	ldr	x21, [sp, #0x78]
    f69c:      	ldp	x2, x24, [sp, #0x50]
    f6a0:      	str	x21, [sp, #0x48]
    f6a4:      	b	0xf6f4 <generic_lsm_path+0x58a4>
    f6a8:      	add	x2, x24, #0x10
    f6ac:      	mov	w8, #0x4                // =4
    f6b0:      	add	x9, sp, #0x98
    f6b4:      	add	x0, sp, #0x98
    f6b8:      	mov	w1, #0x8                // =8
    f6bc:      	blr	x8
    f6c0:      	ldr	x8, [sp, #0x58]
    f6c4:      	ldr	x9, [sp, #0x98]
    f6c8:      	cmp	x8, x9
    f6cc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f6d0:      	add	x2, x24, #0x18
    f6d4:      	mov	w8, #0x4                // =4
    f6d8:      	mov	x0, x22
    f6dc:      	mov	w1, #0x8                // =8
    f6e0:      	blr	x8
    f6e4:      	ldr	x24, [sp, #0x98]
    f6e8:      	ldr	x21, [sp, #0x48]
    f6ec:      	add	x2, x24, #0x20
    f6f0:      	stp	x2, x24, [sp, #0x50]
    f6f4:      	ldr	x8, [sp, #0x30]
    f6f8:      	cmp	x21, x8
    f6fc:      	b.ne	0xf70c <generic_lsm_path+0x58bc>
    f700:      	ldr	x8, [sp, #0x38]
    f704:      	cmp	x2, x8
    f708:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f70c:      	mov	w8, #0x4                // =4
    f710:      	add	x0, sp, #0x70
    f714:      	mov	w1, #0x8                // =8
    f718:      	blr	x8
    f71c:      	ldr	x8, [sp, #0x70]
    f720:      	cmp	x21, x8
    f724:      	b.eq	0xf814 <generic_lsm_path+0x59c4>
    f728:      	add	x23, x21, #0x18
    f72c:      	mov	w8, #0x4                // =4
    f730:      	add	x9, sp, #0x98
    f734:      	add	x0, sp, #0x98
    f738:      	mov	w1, #0x8                // =8
    f73c:      	mov	x2, x23
    f740:      	blr	x8
    f744:      	ldr	x8, [sp, #0x98]
    f748:      	cmp	x8, x21
    f74c:      	b.eq	0xf814 <generic_lsm_path+0x59c4>
    f750:      	mov	w8, #0x4                // =4
    f754:      	add	x9, sp, #0x78
    f758:      	add	x0, sp, #0x78
    f75c:      	mov	w1, #0x8                // =8
    f760:      	mov	x2, x23
    f764:      	blr	x8
    f768:      	add	x2, x21, #0x20
    f76c:      	mov	w8, #0x4                // =4
    f770:      	mov	w9, #0x10               // =16
    f774:      	add	x10, sp, #0x80
    f778:      	add	x0, sp, #0x80
    f77c:      	mov	w1, #0x10               // =16
    f780:      	blr	x8
    f784:      	ldr	w21, [sp, #0x84]
    f788:      	ldr	x8, [sp, #0x40]
    f78c:      	ldr	x10, [sp, #0x60]
    f790:      	sub	x12, x10, x8
    f794:      	ldr	w23, [sp, #0x68]
    f798:      	subs	w10, w21, w23
    f79c:      	ldr	x9, [sp, #0x88]
    f7a0:      	csel	w10, wzr, w10, lo
    f7a4:      	cmp	w23, w21
    f7a8:      	csel	w11, w23, w21, lo
    f7ac:      	cinc	w13, w11, hi
    f7b0:      	sub	w14, w23, w13
    f7b4:      	subs	x12, x12, x13
    f7b8:      	str	w14, [sp, #0x68]
    f7bc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f7c0:      	cmp	x12, #0xfff
    f7c4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f7c8:      	cmp	w23, w21
    f7cc:      	b.ls	0xf7d8 <generic_lsm_path+0x5988>
    f7d0:      	mov	w13, #0x2f              // =47
    f7d4:      	strb	w13, [x8, x12]
    f7d8:      	add	x19, x8, x12
    f7dc:      	cmp	w23, w21
    f7e0:      	add	x2, x9, x10
    f7e4:      	and	w1, w11, #0xff
    f7e8:      	mov	w8, #0x4                // =4
    f7ec:      	cinc	x0, x19, hi
    f7f0:      	blr	x8
    f7f4:      	cmp	w23, w21
    f7f8:      	str	x19, [sp, #0x60]
    f7fc:      	add	x19, sp, #0x70
    f800:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f804:      	ldr	x21, [sp, #0x78]
    f808:      	ldp	x2, x24, [sp, #0x50]
    f80c:      	str	x21, [sp, #0x48]
    f810:      	b	0xf860 <generic_lsm_path+0x5a10>
    f814:      	add	x2, x24, #0x10
    f818:      	mov	w8, #0x4                // =4
    f81c:      	add	x9, sp, #0x98
    f820:      	add	x0, sp, #0x98
    f824:      	mov	w1, #0x8                // =8
    f828:      	blr	x8
    f82c:      	ldr	x8, [sp, #0x58]
    f830:      	ldr	x9, [sp, #0x98]
    f834:      	cmp	x8, x9
    f838:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f83c:      	add	x2, x24, #0x18
    f840:      	mov	w8, #0x4                // =4
    f844:      	mov	x0, x22
    f848:      	mov	w1, #0x8                // =8
    f84c:      	blr	x8
    f850:      	ldr	x24, [sp, #0x98]
    f854:      	ldr	x21, [sp, #0x48]
    f858:      	add	x2, x24, #0x20
    f85c:      	stp	x2, x24, [sp, #0x50]
    f860:      	ldr	x8, [sp, #0x30]
    f864:      	cmp	x21, x8
    f868:      	b.ne	0xf878 <generic_lsm_path+0x5a28>
    f86c:      	ldr	x8, [sp, #0x38]
    f870:      	cmp	x2, x8
    f874:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f878:      	mov	w8, #0x4                // =4
    f87c:      	add	x0, sp, #0x70
    f880:      	mov	w1, #0x8                // =8
    f884:      	blr	x8
    f888:      	ldr	x8, [sp, #0x70]
    f88c:      	cmp	x21, x8
    f890:      	b.eq	0xf980 <generic_lsm_path+0x5b30>
    f894:      	add	x23, x21, #0x18
    f898:      	mov	w8, #0x4                // =4
    f89c:      	add	x9, sp, #0x98
    f8a0:      	add	x0, sp, #0x98
    f8a4:      	mov	w1, #0x8                // =8
    f8a8:      	mov	x2, x23
    f8ac:      	blr	x8
    f8b0:      	ldr	x8, [sp, #0x98]
    f8b4:      	cmp	x8, x21
    f8b8:      	b.eq	0xf980 <generic_lsm_path+0x5b30>
    f8bc:      	mov	w8, #0x4                // =4
    f8c0:      	add	x9, sp, #0x78
    f8c4:      	add	x0, sp, #0x78
    f8c8:      	mov	w1, #0x8                // =8
    f8cc:      	mov	x2, x23
    f8d0:      	blr	x8
    f8d4:      	add	x2, x21, #0x20
    f8d8:      	mov	w8, #0x4                // =4
    f8dc:      	mov	w9, #0x10               // =16
    f8e0:      	add	x10, sp, #0x80
    f8e4:      	add	x0, sp, #0x80
    f8e8:      	mov	w1, #0x10               // =16
    f8ec:      	blr	x8
    f8f0:      	ldr	w21, [sp, #0x84]
    f8f4:      	ldr	x8, [sp, #0x40]
    f8f8:      	ldr	x10, [sp, #0x60]
    f8fc:      	sub	x12, x10, x8
    f900:      	ldr	w23, [sp, #0x68]
    f904:      	subs	w10, w21, w23
    f908:      	ldr	x9, [sp, #0x88]
    f90c:      	csel	w10, wzr, w10, lo
    f910:      	cmp	w23, w21
    f914:      	csel	w11, w23, w21, lo
    f918:      	cinc	w13, w11, hi
    f91c:      	sub	w14, w23, w13
    f920:      	subs	x12, x12, x13
    f924:      	str	w14, [sp, #0x68]
    f928:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    f92c:      	cmp	x12, #0xfff
    f930:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    f934:      	cmp	w23, w21
    f938:      	b.ls	0xf944 <generic_lsm_path+0x5af4>
    f93c:      	mov	w13, #0x2f              // =47
    f940:      	strb	w13, [x8, x12]
    f944:      	add	x19, x8, x12
    f948:      	cmp	w23, w21
    f94c:      	add	x2, x9, x10
    f950:      	and	w1, w11, #0xff
    f954:      	mov	w8, #0x4                // =4
    f958:      	cinc	x0, x19, hi
    f95c:      	blr	x8
    f960:      	cmp	w23, w21
    f964:      	str	x19, [sp, #0x60]
    f968:      	add	x19, sp, #0x70
    f96c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    f970:      	ldr	x21, [sp, #0x78]
    f974:      	ldp	x2, x24, [sp, #0x50]
    f978:      	str	x21, [sp, #0x48]
    f97c:      	b	0xf9cc <generic_lsm_path+0x5b7c>
    f980:      	add	x2, x24, #0x10
    f984:      	mov	w8, #0x4                // =4
    f988:      	add	x9, sp, #0x98
    f98c:      	add	x0, sp, #0x98
    f990:      	mov	w1, #0x8                // =8
    f994:      	blr	x8
    f998:      	ldr	x8, [sp, #0x58]
    f99c:      	ldr	x9, [sp, #0x98]
    f9a0:      	cmp	x8, x9
    f9a4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f9a8:      	add	x2, x24, #0x18
    f9ac:      	mov	w8, #0x4                // =4
    f9b0:      	mov	x0, x22
    f9b4:      	mov	w1, #0x8                // =8
    f9b8:      	blr	x8
    f9bc:      	ldr	x24, [sp, #0x98]
    f9c0:      	ldr	x21, [sp, #0x48]
    f9c4:      	add	x2, x24, #0x20
    f9c8:      	stp	x2, x24, [sp, #0x50]
    f9cc:      	ldr	x8, [sp, #0x30]
    f9d0:      	cmp	x21, x8
    f9d4:      	b.ne	0xf9e4 <generic_lsm_path+0x5b94>
    f9d8:      	ldr	x8, [sp, #0x38]
    f9dc:      	cmp	x2, x8
    f9e0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    f9e4:      	mov	w8, #0x4                // =4
    f9e8:      	add	x0, sp, #0x70
    f9ec:      	mov	w1, #0x8                // =8
    f9f0:      	blr	x8
    f9f4:      	ldr	x8, [sp, #0x70]
    f9f8:      	cmp	x21, x8
    f9fc:      	b.eq	0xfaec <generic_lsm_path+0x5c9c>
    fa00:      	add	x23, x21, #0x18
    fa04:      	mov	w8, #0x4                // =4
    fa08:      	add	x9, sp, #0x98
    fa0c:      	add	x0, sp, #0x98
    fa10:      	mov	w1, #0x8                // =8
    fa14:      	mov	x2, x23
    fa18:      	blr	x8
    fa1c:      	ldr	x8, [sp, #0x98]
    fa20:      	cmp	x8, x21
    fa24:      	b.eq	0xfaec <generic_lsm_path+0x5c9c>
    fa28:      	mov	w8, #0x4                // =4
    fa2c:      	add	x9, sp, #0x78
    fa30:      	add	x0, sp, #0x78
    fa34:      	mov	w1, #0x8                // =8
    fa38:      	mov	x2, x23
    fa3c:      	blr	x8
    fa40:      	add	x2, x21, #0x20
    fa44:      	mov	w8, #0x4                // =4
    fa48:      	mov	w9, #0x10               // =16
    fa4c:      	add	x10, sp, #0x80
    fa50:      	add	x0, sp, #0x80
    fa54:      	mov	w1, #0x10               // =16
    fa58:      	blr	x8
    fa5c:      	ldr	w21, [sp, #0x84]
    fa60:      	ldr	x8, [sp, #0x40]
    fa64:      	ldr	x10, [sp, #0x60]
    fa68:      	sub	x12, x10, x8
    fa6c:      	ldr	w23, [sp, #0x68]
    fa70:      	subs	w10, w21, w23
    fa74:      	ldr	x9, [sp, #0x88]
    fa78:      	csel	w10, wzr, w10, lo
    fa7c:      	cmp	w23, w21
    fa80:      	csel	w11, w23, w21, lo
    fa84:      	cinc	w13, w11, hi
    fa88:      	sub	w14, w23, w13
    fa8c:      	subs	x12, x12, x13
    fa90:      	str	w14, [sp, #0x68]
    fa94:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    fa98:      	cmp	x12, #0xfff
    fa9c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    faa0:      	cmp	w23, w21
    faa4:      	b.ls	0xfab0 <generic_lsm_path+0x5c60>
    faa8:      	mov	w13, #0x2f              // =47
    faac:      	strb	w13, [x8, x12]
    fab0:      	add	x19, x8, x12
    fab4:      	cmp	w23, w21
    fab8:      	add	x2, x9, x10
    fabc:      	and	w1, w11, #0xff
    fac0:      	mov	w8, #0x4                // =4
    fac4:      	cinc	x0, x19, hi
    fac8:      	blr	x8
    facc:      	cmp	w23, w21
    fad0:      	str	x19, [sp, #0x60]
    fad4:      	add	x19, sp, #0x70
    fad8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    fadc:      	ldr	x21, [sp, #0x78]
    fae0:      	ldp	x2, x24, [sp, #0x50]
    fae4:      	str	x21, [sp, #0x48]
    fae8:      	b	0xfb38 <generic_lsm_path+0x5ce8>
    faec:      	add	x2, x24, #0x10
    faf0:      	mov	w8, #0x4                // =4
    faf4:      	add	x9, sp, #0x98
    faf8:      	add	x0, sp, #0x98
    fafc:      	mov	w1, #0x8                // =8
    fb00:      	blr	x8
    fb04:      	ldr	x8, [sp, #0x58]
    fb08:      	ldr	x9, [sp, #0x98]
    fb0c:      	cmp	x8, x9
    fb10:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    fb14:      	add	x2, x24, #0x18
    fb18:      	mov	w8, #0x4                // =4
    fb1c:      	mov	x0, x22
    fb20:      	mov	w1, #0x8                // =8
    fb24:      	blr	x8
    fb28:      	ldr	x24, [sp, #0x98]
    fb2c:      	ldr	x21, [sp, #0x48]
    fb30:      	add	x2, x24, #0x20
    fb34:      	stp	x2, x24, [sp, #0x50]
    fb38:      	ldr	x8, [sp, #0x30]
    fb3c:      	cmp	x21, x8
    fb40:      	b.ne	0xfb50 <generic_lsm_path+0x5d00>
    fb44:      	ldr	x8, [sp, #0x38]
    fb48:      	cmp	x2, x8
    fb4c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    fb50:      	mov	w8, #0x4                // =4
    fb54:      	add	x0, sp, #0x70
    fb58:      	mov	w1, #0x8                // =8
    fb5c:      	blr	x8
    fb60:      	ldr	x8, [sp, #0x70]
    fb64:      	cmp	x21, x8
    fb68:      	b.eq	0xfc58 <generic_lsm_path+0x5e08>
    fb6c:      	add	x23, x21, #0x18
    fb70:      	mov	w8, #0x4                // =4
    fb74:      	add	x9, sp, #0x98
    fb78:      	add	x0, sp, #0x98
    fb7c:      	mov	w1, #0x8                // =8
    fb80:      	mov	x2, x23
    fb84:      	blr	x8
    fb88:      	ldr	x8, [sp, #0x98]
    fb8c:      	cmp	x8, x21
    fb90:      	b.eq	0xfc58 <generic_lsm_path+0x5e08>
    fb94:      	mov	w8, #0x4                // =4
    fb98:      	add	x9, sp, #0x78
    fb9c:      	add	x0, sp, #0x78
    fba0:      	mov	w1, #0x8                // =8
    fba4:      	mov	x2, x23
    fba8:      	blr	x8
    fbac:      	add	x2, x21, #0x20
    fbb0:      	mov	w8, #0x4                // =4
    fbb4:      	mov	w9, #0x10               // =16
    fbb8:      	add	x10, sp, #0x80
    fbbc:      	add	x0, sp, #0x80
    fbc0:      	mov	w1, #0x10               // =16
    fbc4:      	blr	x8
    fbc8:      	ldr	w21, [sp, #0x84]
    fbcc:      	ldr	x8, [sp, #0x40]
    fbd0:      	ldr	x10, [sp, #0x60]
    fbd4:      	sub	x12, x10, x8
    fbd8:      	ldr	w23, [sp, #0x68]
    fbdc:      	subs	w10, w21, w23
    fbe0:      	ldr	x9, [sp, #0x88]
    fbe4:      	csel	w10, wzr, w10, lo
    fbe8:      	cmp	w23, w21
    fbec:      	csel	w11, w23, w21, lo
    fbf0:      	cinc	w13, w11, hi
    fbf4:      	sub	w14, w23, w13
    fbf8:      	subs	x12, x12, x13
    fbfc:      	str	w14, [sp, #0x68]
    fc00:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    fc04:      	cmp	x12, #0xfff
    fc08:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    fc0c:      	cmp	w23, w21
    fc10:      	b.ls	0xfc1c <generic_lsm_path+0x5dcc>
    fc14:      	mov	w13, #0x2f              // =47
    fc18:      	strb	w13, [x8, x12]
    fc1c:      	add	x19, x8, x12
    fc20:      	cmp	w23, w21
    fc24:      	add	x2, x9, x10
    fc28:      	and	w1, w11, #0xff
    fc2c:      	mov	w8, #0x4                // =4
    fc30:      	cinc	x0, x19, hi
    fc34:      	blr	x8
    fc38:      	cmp	w23, w21
    fc3c:      	str	x19, [sp, #0x60]
    fc40:      	add	x19, sp, #0x70
    fc44:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    fc48:      	ldr	x21, [sp, #0x78]
    fc4c:      	ldp	x2, x24, [sp, #0x50]
    fc50:      	str	x21, [sp, #0x48]
    fc54:      	b	0xfca4 <generic_lsm_path+0x5e54>
    fc58:      	add	x2, x24, #0x10
    fc5c:      	mov	w8, #0x4                // =4
    fc60:      	add	x9, sp, #0x98
    fc64:      	add	x0, sp, #0x98
    fc68:      	mov	w1, #0x8                // =8
    fc6c:      	blr	x8
    fc70:      	ldr	x8, [sp, #0x58]
    fc74:      	ldr	x9, [sp, #0x98]
    fc78:      	cmp	x8, x9
    fc7c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    fc80:      	add	x2, x24, #0x18
    fc84:      	mov	w8, #0x4                // =4
    fc88:      	mov	x0, x22
    fc8c:      	mov	w1, #0x8                // =8
    fc90:      	blr	x8
    fc94:      	ldr	x24, [sp, #0x98]
    fc98:      	ldr	x21, [sp, #0x48]
    fc9c:      	add	x2, x24, #0x20
    fca0:      	stp	x2, x24, [sp, #0x50]
    fca4:      	ldr	x8, [sp, #0x30]
    fca8:      	cmp	x21, x8
    fcac:      	b.ne	0xfcbc <generic_lsm_path+0x5e6c>
    fcb0:      	ldr	x8, [sp, #0x38]
    fcb4:      	cmp	x2, x8
    fcb8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    fcbc:      	mov	w8, #0x4                // =4
    fcc0:      	add	x0, sp, #0x70
    fcc4:      	mov	w1, #0x8                // =8
    fcc8:      	blr	x8
    fccc:      	ldr	x8, [sp, #0x70]
    fcd0:      	cmp	x21, x8
    fcd4:      	b.eq	0xfdc4 <generic_lsm_path+0x5f74>
    fcd8:      	add	x23, x21, #0x18
    fcdc:      	mov	w8, #0x4                // =4
    fce0:      	add	x9, sp, #0x98
    fce4:      	add	x0, sp, #0x98
    fce8:      	mov	w1, #0x8                // =8
    fcec:      	mov	x2, x23
    fcf0:      	blr	x8
    fcf4:      	ldr	x8, [sp, #0x98]
    fcf8:      	cmp	x8, x21
    fcfc:      	b.eq	0xfdc4 <generic_lsm_path+0x5f74>
    fd00:      	mov	w8, #0x4                // =4
    fd04:      	add	x9, sp, #0x78
    fd08:      	add	x0, sp, #0x78
    fd0c:      	mov	w1, #0x8                // =8
    fd10:      	mov	x2, x23
    fd14:      	blr	x8
    fd18:      	add	x2, x21, #0x20
    fd1c:      	mov	w8, #0x4                // =4
    fd20:      	mov	w9, #0x10               // =16
    fd24:      	add	x10, sp, #0x80
    fd28:      	add	x0, sp, #0x80
    fd2c:      	mov	w1, #0x10               // =16
    fd30:      	blr	x8
    fd34:      	ldr	w21, [sp, #0x84]
    fd38:      	ldr	x8, [sp, #0x40]
    fd3c:      	ldr	x10, [sp, #0x60]
    fd40:      	sub	x12, x10, x8
    fd44:      	ldr	w23, [sp, #0x68]
    fd48:      	subs	w10, w21, w23
    fd4c:      	ldr	x9, [sp, #0x88]
    fd50:      	csel	w10, wzr, w10, lo
    fd54:      	cmp	w23, w21
    fd58:      	csel	w11, w23, w21, lo
    fd5c:      	cinc	w13, w11, hi
    fd60:      	sub	w14, w23, w13
    fd64:      	subs	x12, x12, x13
    fd68:      	str	w14, [sp, #0x68]
    fd6c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    fd70:      	cmp	x12, #0xfff
    fd74:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    fd78:      	cmp	w23, w21
    fd7c:      	b.ls	0xfd88 <generic_lsm_path+0x5f38>
    fd80:      	mov	w13, #0x2f              // =47
    fd84:      	strb	w13, [x8, x12]
    fd88:      	add	x19, x8, x12
    fd8c:      	cmp	w23, w21
    fd90:      	add	x2, x9, x10
    fd94:      	and	w1, w11, #0xff
    fd98:      	mov	w8, #0x4                // =4
    fd9c:      	cinc	x0, x19, hi
    fda0:      	blr	x8
    fda4:      	cmp	w23, w21
    fda8:      	str	x19, [sp, #0x60]
    fdac:      	add	x19, sp, #0x70
    fdb0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    fdb4:      	ldr	x21, [sp, #0x78]
    fdb8:      	ldp	x2, x24, [sp, #0x50]
    fdbc:      	str	x21, [sp, #0x48]
    fdc0:      	b	0xfe10 <generic_lsm_path+0x5fc0>
    fdc4:      	add	x2, x24, #0x10
    fdc8:      	mov	w8, #0x4                // =4
    fdcc:      	add	x9, sp, #0x98
    fdd0:      	add	x0, sp, #0x98
    fdd4:      	mov	w1, #0x8                // =8
    fdd8:      	blr	x8
    fddc:      	ldr	x8, [sp, #0x58]
    fde0:      	ldr	x9, [sp, #0x98]
    fde4:      	cmp	x8, x9
    fde8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    fdec:      	add	x2, x24, #0x18
    fdf0:      	mov	w8, #0x4                // =4
    fdf4:      	mov	x0, x22
    fdf8:      	mov	w1, #0x8                // =8
    fdfc:      	blr	x8
    fe00:      	ldr	x24, [sp, #0x98]
    fe04:      	ldr	x21, [sp, #0x48]
    fe08:      	add	x2, x24, #0x20
    fe0c:      	stp	x2, x24, [sp, #0x50]
    fe10:      	ldr	x8, [sp, #0x30]
    fe14:      	cmp	x21, x8
    fe18:      	b.ne	0xfe28 <generic_lsm_path+0x5fd8>
    fe1c:      	ldr	x8, [sp, #0x38]
    fe20:      	cmp	x2, x8
    fe24:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    fe28:      	mov	w8, #0x4                // =4
    fe2c:      	add	x0, sp, #0x70
    fe30:      	mov	w1, #0x8                // =8
    fe34:      	blr	x8
    fe38:      	ldr	x8, [sp, #0x70]
    fe3c:      	cmp	x21, x8
    fe40:      	b.eq	0xff30 <generic_lsm_path+0x60e0>
    fe44:      	add	x23, x21, #0x18
    fe48:      	mov	w8, #0x4                // =4
    fe4c:      	add	x9, sp, #0x98
    fe50:      	add	x0, sp, #0x98
    fe54:      	mov	w1, #0x8                // =8
    fe58:      	mov	x2, x23
    fe5c:      	blr	x8
    fe60:      	ldr	x8, [sp, #0x98]
    fe64:      	cmp	x8, x21
    fe68:      	b.eq	0xff30 <generic_lsm_path+0x60e0>
    fe6c:      	mov	w8, #0x4                // =4
    fe70:      	add	x9, sp, #0x78
    fe74:      	add	x0, sp, #0x78
    fe78:      	mov	w1, #0x8                // =8
    fe7c:      	mov	x2, x23
    fe80:      	blr	x8
    fe84:      	add	x2, x21, #0x20
    fe88:      	mov	w8, #0x4                // =4
    fe8c:      	mov	w9, #0x10               // =16
    fe90:      	add	x10, sp, #0x80
    fe94:      	add	x0, sp, #0x80
    fe98:      	mov	w1, #0x10               // =16
    fe9c:      	blr	x8
    fea0:      	ldr	w21, [sp, #0x84]
    fea4:      	ldr	x8, [sp, #0x40]
    fea8:      	ldr	x10, [sp, #0x60]
    feac:      	sub	x12, x10, x8
    feb0:      	ldr	w23, [sp, #0x68]
    feb4:      	subs	w10, w21, w23
    feb8:      	ldr	x9, [sp, #0x88]
    febc:      	csel	w10, wzr, w10, lo
    fec0:      	cmp	w23, w21
    fec4:      	csel	w11, w23, w21, lo
    fec8:      	cinc	w13, w11, hi
    fecc:      	sub	w14, w23, w13
    fed0:      	subs	x12, x12, x13
    fed4:      	str	w14, [sp, #0x68]
    fed8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
    fedc:      	cmp	x12, #0xfff
    fee0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
    fee4:      	cmp	w23, w21
    fee8:      	b.ls	0xfef4 <generic_lsm_path+0x60a4>
    feec:      	mov	w13, #0x2f              // =47
    fef0:      	strb	w13, [x8, x12]
    fef4:      	add	x19, x8, x12
    fef8:      	cmp	w23, w21
    fefc:      	add	x2, x9, x10
    ff00:      	and	w1, w11, #0xff
    ff04:      	mov	w8, #0x4                // =4
    ff08:      	cinc	x0, x19, hi
    ff0c:      	blr	x8
    ff10:      	cmp	w23, w21
    ff14:      	str	x19, [sp, #0x60]
    ff18:      	add	x19, sp, #0x70
    ff1c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
    ff20:      	ldr	x21, [sp, #0x78]
    ff24:      	ldp	x2, x24, [sp, #0x50]
    ff28:      	str	x21, [sp, #0x48]
    ff2c:      	b	0xff7c <generic_lsm_path+0x612c>
    ff30:      	add	x2, x24, #0x10
    ff34:      	mov	w8, #0x4                // =4
    ff38:      	add	x9, sp, #0x98
    ff3c:      	add	x0, sp, #0x98
    ff40:      	mov	w1, #0x8                // =8
    ff44:      	blr	x8
    ff48:      	ldr	x8, [sp, #0x58]
    ff4c:      	ldr	x9, [sp, #0x98]
    ff50:      	cmp	x8, x9
    ff54:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ff58:      	add	x2, x24, #0x18
    ff5c:      	mov	w8, #0x4                // =4
    ff60:      	mov	x0, x22
    ff64:      	mov	w1, #0x8                // =8
    ff68:      	blr	x8
    ff6c:      	ldr	x24, [sp, #0x98]
    ff70:      	ldr	x21, [sp, #0x48]
    ff74:      	add	x2, x24, #0x20
    ff78:      	stp	x2, x24, [sp, #0x50]
    ff7c:      	ldr	x8, [sp, #0x30]
    ff80:      	cmp	x21, x8
    ff84:      	b.ne	0xff94 <generic_lsm_path+0x6144>
    ff88:      	ldr	x8, [sp, #0x38]
    ff8c:      	cmp	x2, x8
    ff90:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
    ff94:      	mov	w8, #0x4                // =4
    ff98:      	add	x0, sp, #0x70
    ff9c:      	mov	w1, #0x8                // =8
    ffa0:      	blr	x8
    ffa4:      	ldr	x8, [sp, #0x70]
    ffa8:      	cmp	x21, x8
    ffac:      	b.eq	0x1009c <generic_lsm_path+0x624c>
    ffb0:      	add	x23, x21, #0x18
    ffb4:      	mov	w8, #0x4                // =4
    ffb8:      	add	x9, sp, #0x98
    ffbc:      	add	x0, sp, #0x98
    ffc0:      	mov	w1, #0x8                // =8
    ffc4:      	mov	x2, x23
    ffc8:      	blr	x8
    ffcc:      	ldr	x8, [sp, #0x98]
    ffd0:      	cmp	x8, x21
    ffd4:      	b.eq	0x1009c <generic_lsm_path+0x624c>
    ffd8:      	mov	w8, #0x4                // =4
    ffdc:      	add	x9, sp, #0x78
    ffe0:      	add	x0, sp, #0x78
    ffe4:      	mov	w1, #0x8                // =8
    ffe8:      	mov	x2, x23
    ffec:      	blr	x8
    fff0:      	add	x2, x21, #0x20
    fff4:      	mov	w8, #0x4                // =4
    fff8:      	mov	w9, #0x10               // =16
    fffc:      	add	x10, sp, #0x80
   10000:      	add	x0, sp, #0x80
   10004:      	mov	w1, #0x10               // =16
   10008:      	blr	x8
   1000c:      	ldr	w21, [sp, #0x84]
   10010:      	ldr	x8, [sp, #0x40]
   10014:      	ldr	x10, [sp, #0x60]
   10018:      	sub	x12, x10, x8
   1001c:      	ldr	w23, [sp, #0x68]
   10020:      	subs	w10, w21, w23
   10024:      	ldr	x9, [sp, #0x88]
   10028:      	csel	w10, wzr, w10, lo
   1002c:      	cmp	w23, w21
   10030:      	csel	w11, w23, w21, lo
   10034:      	cinc	w13, w11, hi
   10038:      	sub	w14, w23, w13
   1003c:      	subs	x12, x12, x13
   10040:      	str	w14, [sp, #0x68]
   10044:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10048:      	cmp	x12, #0xfff
   1004c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10050:      	cmp	w23, w21
   10054:      	b.ls	0x10060 <generic_lsm_path+0x6210>
   10058:      	mov	w13, #0x2f              // =47
   1005c:      	strb	w13, [x8, x12]
   10060:      	add	x19, x8, x12
   10064:      	cmp	w23, w21
   10068:      	add	x2, x9, x10
   1006c:      	and	w1, w11, #0xff
   10070:      	mov	w8, #0x4                // =4
   10074:      	cinc	x0, x19, hi
   10078:      	blr	x8
   1007c:      	cmp	w23, w21
   10080:      	str	x19, [sp, #0x60]
   10084:      	add	x19, sp, #0x70
   10088:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1008c:      	ldr	x21, [sp, #0x78]
   10090:      	ldp	x2, x24, [sp, #0x50]
   10094:      	str	x21, [sp, #0x48]
   10098:      	b	0x100e8 <generic_lsm_path+0x6298>
   1009c:      	add	x2, x24, #0x10
   100a0:      	mov	w8, #0x4                // =4
   100a4:      	add	x9, sp, #0x98
   100a8:      	add	x0, sp, #0x98
   100ac:      	mov	w1, #0x8                // =8
   100b0:      	blr	x8
   100b4:      	ldr	x8, [sp, #0x58]
   100b8:      	ldr	x9, [sp, #0x98]
   100bc:      	cmp	x8, x9
   100c0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   100c4:      	add	x2, x24, #0x18
   100c8:      	mov	w8, #0x4                // =4
   100cc:      	mov	x0, x22
   100d0:      	mov	w1, #0x8                // =8
   100d4:      	blr	x8
   100d8:      	ldr	x24, [sp, #0x98]
   100dc:      	ldr	x21, [sp, #0x48]
   100e0:      	add	x2, x24, #0x20
   100e4:      	stp	x2, x24, [sp, #0x50]
   100e8:      	ldr	x8, [sp, #0x30]
   100ec:      	cmp	x21, x8
   100f0:      	b.ne	0x10100 <generic_lsm_path+0x62b0>
   100f4:      	ldr	x8, [sp, #0x38]
   100f8:      	cmp	x2, x8
   100fc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10100:      	mov	w8, #0x4                // =4
   10104:      	add	x0, sp, #0x70
   10108:      	mov	w1, #0x8                // =8
   1010c:      	blr	x8
   10110:      	ldr	x8, [sp, #0x70]
   10114:      	cmp	x21, x8
   10118:      	b.eq	0x10208 <generic_lsm_path+0x63b8>
   1011c:      	add	x23, x21, #0x18
   10120:      	mov	w8, #0x4                // =4
   10124:      	add	x9, sp, #0x98
   10128:      	add	x0, sp, #0x98
   1012c:      	mov	w1, #0x8                // =8
   10130:      	mov	x2, x23
   10134:      	blr	x8
   10138:      	ldr	x8, [sp, #0x98]
   1013c:      	cmp	x8, x21
   10140:      	b.eq	0x10208 <generic_lsm_path+0x63b8>
   10144:      	mov	w8, #0x4                // =4
   10148:      	add	x9, sp, #0x78
   1014c:      	add	x0, sp, #0x78
   10150:      	mov	w1, #0x8                // =8
   10154:      	mov	x2, x23
   10158:      	blr	x8
   1015c:      	add	x2, x21, #0x20
   10160:      	mov	w8, #0x4                // =4
   10164:      	mov	w9, #0x10               // =16
   10168:      	add	x10, sp, #0x80
   1016c:      	add	x0, sp, #0x80
   10170:      	mov	w1, #0x10               // =16
   10174:      	blr	x8
   10178:      	ldr	w21, [sp, #0x84]
   1017c:      	ldr	x8, [sp, #0x40]
   10180:      	ldr	x10, [sp, #0x60]
   10184:      	sub	x12, x10, x8
   10188:      	ldr	w23, [sp, #0x68]
   1018c:      	subs	w10, w21, w23
   10190:      	ldr	x9, [sp, #0x88]
   10194:      	csel	w10, wzr, w10, lo
   10198:      	cmp	w23, w21
   1019c:      	csel	w11, w23, w21, lo
   101a0:      	cinc	w13, w11, hi
   101a4:      	sub	w14, w23, w13
   101a8:      	subs	x12, x12, x13
   101ac:      	str	w14, [sp, #0x68]
   101b0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   101b4:      	cmp	x12, #0xfff
   101b8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   101bc:      	cmp	w23, w21
   101c0:      	b.ls	0x101cc <generic_lsm_path+0x637c>
   101c4:      	mov	w13, #0x2f              // =47
   101c8:      	strb	w13, [x8, x12]
   101cc:      	add	x19, x8, x12
   101d0:      	cmp	w23, w21
   101d4:      	add	x2, x9, x10
   101d8:      	and	w1, w11, #0xff
   101dc:      	mov	w8, #0x4                // =4
   101e0:      	cinc	x0, x19, hi
   101e4:      	blr	x8
   101e8:      	cmp	w23, w21
   101ec:      	str	x19, [sp, #0x60]
   101f0:      	add	x19, sp, #0x70
   101f4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   101f8:      	ldr	x21, [sp, #0x78]
   101fc:      	ldp	x2, x24, [sp, #0x50]
   10200:      	str	x21, [sp, #0x48]
   10204:      	b	0x10254 <generic_lsm_path+0x6404>
   10208:      	add	x2, x24, #0x10
   1020c:      	mov	w8, #0x4                // =4
   10210:      	add	x9, sp, #0x98
   10214:      	add	x0, sp, #0x98
   10218:      	mov	w1, #0x8                // =8
   1021c:      	blr	x8
   10220:      	ldr	x8, [sp, #0x58]
   10224:      	ldr	x9, [sp, #0x98]
   10228:      	cmp	x8, x9
   1022c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10230:      	add	x2, x24, #0x18
   10234:      	mov	w8, #0x4                // =4
   10238:      	mov	x0, x22
   1023c:      	mov	w1, #0x8                // =8
   10240:      	blr	x8
   10244:      	ldr	x24, [sp, #0x98]
   10248:      	ldr	x21, [sp, #0x48]
   1024c:      	add	x2, x24, #0x20
   10250:      	stp	x2, x24, [sp, #0x50]
   10254:      	ldr	x8, [sp, #0x30]
   10258:      	cmp	x21, x8
   1025c:      	b.ne	0x1026c <generic_lsm_path+0x641c>
   10260:      	ldr	x8, [sp, #0x38]
   10264:      	cmp	x2, x8
   10268:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1026c:      	mov	w8, #0x4                // =4
   10270:      	add	x0, sp, #0x70
   10274:      	mov	w1, #0x8                // =8
   10278:      	blr	x8
   1027c:      	ldr	x8, [sp, #0x70]
   10280:      	cmp	x21, x8
   10284:      	b.eq	0x10374 <generic_lsm_path+0x6524>
   10288:      	add	x23, x21, #0x18
   1028c:      	mov	w8, #0x4                // =4
   10290:      	add	x9, sp, #0x98
   10294:      	add	x0, sp, #0x98
   10298:      	mov	w1, #0x8                // =8
   1029c:      	mov	x2, x23
   102a0:      	blr	x8
   102a4:      	ldr	x8, [sp, #0x98]
   102a8:      	cmp	x8, x21
   102ac:      	b.eq	0x10374 <generic_lsm_path+0x6524>
   102b0:      	mov	w8, #0x4                // =4
   102b4:      	add	x9, sp, #0x78
   102b8:      	add	x0, sp, #0x78
   102bc:      	mov	w1, #0x8                // =8
   102c0:      	mov	x2, x23
   102c4:      	blr	x8
   102c8:      	add	x2, x21, #0x20
   102cc:      	mov	w8, #0x4                // =4
   102d0:      	mov	w9, #0x10               // =16
   102d4:      	add	x10, sp, #0x80
   102d8:      	add	x0, sp, #0x80
   102dc:      	mov	w1, #0x10               // =16
   102e0:      	blr	x8
   102e4:      	ldr	w21, [sp, #0x84]
   102e8:      	ldr	x8, [sp, #0x40]
   102ec:      	ldr	x10, [sp, #0x60]
   102f0:      	sub	x12, x10, x8
   102f4:      	ldr	w23, [sp, #0x68]
   102f8:      	subs	w10, w21, w23
   102fc:      	ldr	x9, [sp, #0x88]
   10300:      	csel	w10, wzr, w10, lo
   10304:      	cmp	w23, w21
   10308:      	csel	w11, w23, w21, lo
   1030c:      	cinc	w13, w11, hi
   10310:      	sub	w14, w23, w13
   10314:      	subs	x12, x12, x13
   10318:      	str	w14, [sp, #0x68]
   1031c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10320:      	cmp	x12, #0xfff
   10324:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10328:      	cmp	w23, w21
   1032c:      	b.ls	0x10338 <generic_lsm_path+0x64e8>
   10330:      	mov	w13, #0x2f              // =47
   10334:      	strb	w13, [x8, x12]
   10338:      	add	x19, x8, x12
   1033c:      	cmp	w23, w21
   10340:      	add	x2, x9, x10
   10344:      	and	w1, w11, #0xff
   10348:      	mov	w8, #0x4                // =4
   1034c:      	cinc	x0, x19, hi
   10350:      	blr	x8
   10354:      	cmp	w23, w21
   10358:      	str	x19, [sp, #0x60]
   1035c:      	add	x19, sp, #0x70
   10360:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   10364:      	ldr	x21, [sp, #0x78]
   10368:      	ldp	x2, x24, [sp, #0x50]
   1036c:      	str	x21, [sp, #0x48]
   10370:      	b	0x103c0 <generic_lsm_path+0x6570>
   10374:      	add	x2, x24, #0x10
   10378:      	mov	w8, #0x4                // =4
   1037c:      	add	x9, sp, #0x98
   10380:      	add	x0, sp, #0x98
   10384:      	mov	w1, #0x8                // =8
   10388:      	blr	x8
   1038c:      	ldr	x8, [sp, #0x58]
   10390:      	ldr	x9, [sp, #0x98]
   10394:      	cmp	x8, x9
   10398:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1039c:      	add	x2, x24, #0x18
   103a0:      	mov	w8, #0x4                // =4
   103a4:      	mov	x0, x22
   103a8:      	mov	w1, #0x8                // =8
   103ac:      	blr	x8
   103b0:      	ldr	x24, [sp, #0x98]
   103b4:      	ldr	x21, [sp, #0x48]
   103b8:      	add	x2, x24, #0x20
   103bc:      	stp	x2, x24, [sp, #0x50]
   103c0:      	ldr	x8, [sp, #0x30]
   103c4:      	cmp	x21, x8
   103c8:      	b.ne	0x103d8 <generic_lsm_path+0x6588>
   103cc:      	ldr	x8, [sp, #0x38]
   103d0:      	cmp	x2, x8
   103d4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   103d8:      	mov	w8, #0x4                // =4
   103dc:      	add	x0, sp, #0x70
   103e0:      	mov	w1, #0x8                // =8
   103e4:      	blr	x8
   103e8:      	ldr	x8, [sp, #0x70]
   103ec:      	cmp	x21, x8
   103f0:      	b.eq	0x104e0 <generic_lsm_path+0x6690>
   103f4:      	add	x23, x21, #0x18
   103f8:      	mov	w8, #0x4                // =4
   103fc:      	add	x9, sp, #0x98
   10400:      	add	x0, sp, #0x98
   10404:      	mov	w1, #0x8                // =8
   10408:      	mov	x2, x23
   1040c:      	blr	x8
   10410:      	ldr	x8, [sp, #0x98]
   10414:      	cmp	x8, x21
   10418:      	b.eq	0x104e0 <generic_lsm_path+0x6690>
   1041c:      	mov	w8, #0x4                // =4
   10420:      	add	x9, sp, #0x78
   10424:      	add	x0, sp, #0x78
   10428:      	mov	w1, #0x8                // =8
   1042c:      	mov	x2, x23
   10430:      	blr	x8
   10434:      	add	x2, x21, #0x20
   10438:      	mov	w8, #0x4                // =4
   1043c:      	mov	w9, #0x10               // =16
   10440:      	add	x10, sp, #0x80
   10444:      	add	x0, sp, #0x80
   10448:      	mov	w1, #0x10               // =16
   1044c:      	blr	x8
   10450:      	ldr	w21, [sp, #0x84]
   10454:      	ldr	x8, [sp, #0x40]
   10458:      	ldr	x10, [sp, #0x60]
   1045c:      	sub	x12, x10, x8
   10460:      	ldr	w23, [sp, #0x68]
   10464:      	subs	w10, w21, w23
   10468:      	ldr	x9, [sp, #0x88]
   1046c:      	csel	w10, wzr, w10, lo
   10470:      	cmp	w23, w21
   10474:      	csel	w11, w23, w21, lo
   10478:      	cinc	w13, w11, hi
   1047c:      	sub	w14, w23, w13
   10480:      	subs	x12, x12, x13
   10484:      	str	w14, [sp, #0x68]
   10488:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   1048c:      	cmp	x12, #0xfff
   10490:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10494:      	cmp	w23, w21
   10498:      	b.ls	0x104a4 <generic_lsm_path+0x6654>
   1049c:      	mov	w13, #0x2f              // =47
   104a0:      	strb	w13, [x8, x12]
   104a4:      	add	x19, x8, x12
   104a8:      	cmp	w23, w21
   104ac:      	add	x2, x9, x10
   104b0:      	and	w1, w11, #0xff
   104b4:      	mov	w8, #0x4                // =4
   104b8:      	cinc	x0, x19, hi
   104bc:      	blr	x8
   104c0:      	cmp	w23, w21
   104c4:      	str	x19, [sp, #0x60]
   104c8:      	add	x19, sp, #0x70
   104cc:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   104d0:      	ldr	x21, [sp, #0x78]
   104d4:      	ldp	x2, x24, [sp, #0x50]
   104d8:      	str	x21, [sp, #0x48]
   104dc:      	b	0x1052c <generic_lsm_path+0x66dc>
   104e0:      	add	x2, x24, #0x10
   104e4:      	mov	w8, #0x4                // =4
   104e8:      	add	x9, sp, #0x98
   104ec:      	add	x0, sp, #0x98
   104f0:      	mov	w1, #0x8                // =8
   104f4:      	blr	x8
   104f8:      	ldr	x8, [sp, #0x58]
   104fc:      	ldr	x9, [sp, #0x98]
   10500:      	cmp	x8, x9
   10504:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10508:      	add	x2, x24, #0x18
   1050c:      	mov	w8, #0x4                // =4
   10510:      	mov	x0, x22
   10514:      	mov	w1, #0x8                // =8
   10518:      	blr	x8
   1051c:      	ldr	x24, [sp, #0x98]
   10520:      	ldr	x21, [sp, #0x48]
   10524:      	add	x2, x24, #0x20
   10528:      	stp	x2, x24, [sp, #0x50]
   1052c:      	ldr	x8, [sp, #0x30]
   10530:      	cmp	x21, x8
   10534:      	b.ne	0x10544 <generic_lsm_path+0x66f4>
   10538:      	ldr	x8, [sp, #0x38]
   1053c:      	cmp	x2, x8
   10540:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10544:      	mov	w8, #0x4                // =4
   10548:      	add	x0, sp, #0x70
   1054c:      	mov	w1, #0x8                // =8
   10550:      	blr	x8
   10554:      	ldr	x8, [sp, #0x70]
   10558:      	cmp	x21, x8
   1055c:      	b.eq	0x1064c <generic_lsm_path+0x67fc>
   10560:      	add	x23, x21, #0x18
   10564:      	mov	w8, #0x4                // =4
   10568:      	add	x9, sp, #0x98
   1056c:      	add	x0, sp, #0x98
   10570:      	mov	w1, #0x8                // =8
   10574:      	mov	x2, x23
   10578:      	blr	x8
   1057c:      	ldr	x8, [sp, #0x98]
   10580:      	cmp	x8, x21
   10584:      	b.eq	0x1064c <generic_lsm_path+0x67fc>
   10588:      	mov	w8, #0x4                // =4
   1058c:      	add	x9, sp, #0x78
   10590:      	add	x0, sp, #0x78
   10594:      	mov	w1, #0x8                // =8
   10598:      	mov	x2, x23
   1059c:      	blr	x8
   105a0:      	add	x2, x21, #0x20
   105a4:      	mov	w8, #0x4                // =4
   105a8:      	mov	w9, #0x10               // =16
   105ac:      	add	x10, sp, #0x80
   105b0:      	add	x0, sp, #0x80
   105b4:      	mov	w1, #0x10               // =16
   105b8:      	blr	x8
   105bc:      	ldr	w21, [sp, #0x84]
   105c0:      	ldr	x8, [sp, #0x40]
   105c4:      	ldr	x10, [sp, #0x60]
   105c8:      	sub	x12, x10, x8
   105cc:      	ldr	w23, [sp, #0x68]
   105d0:      	subs	w10, w21, w23
   105d4:      	ldr	x9, [sp, #0x88]
   105d8:      	csel	w10, wzr, w10, lo
   105dc:      	cmp	w23, w21
   105e0:      	csel	w11, w23, w21, lo
   105e4:      	cinc	w13, w11, hi
   105e8:      	sub	w14, w23, w13
   105ec:      	subs	x12, x12, x13
   105f0:      	str	w14, [sp, #0x68]
   105f4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   105f8:      	cmp	x12, #0xfff
   105fc:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10600:      	cmp	w23, w21
   10604:      	b.ls	0x10610 <generic_lsm_path+0x67c0>
   10608:      	mov	w13, #0x2f              // =47
   1060c:      	strb	w13, [x8, x12]
   10610:      	add	x19, x8, x12
   10614:      	cmp	w23, w21
   10618:      	add	x2, x9, x10
   1061c:      	and	w1, w11, #0xff
   10620:      	mov	w8, #0x4                // =4
   10624:      	cinc	x0, x19, hi
   10628:      	blr	x8
   1062c:      	cmp	w23, w21
   10630:      	str	x19, [sp, #0x60]
   10634:      	add	x19, sp, #0x70
   10638:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1063c:      	ldr	x21, [sp, #0x78]
   10640:      	ldp	x2, x24, [sp, #0x50]
   10644:      	str	x21, [sp, #0x48]
   10648:      	b	0x10698 <generic_lsm_path+0x6848>
   1064c:      	add	x2, x24, #0x10
   10650:      	mov	w8, #0x4                // =4
   10654:      	add	x9, sp, #0x98
   10658:      	add	x0, sp, #0x98
   1065c:      	mov	w1, #0x8                // =8
   10660:      	blr	x8
   10664:      	ldr	x8, [sp, #0x58]
   10668:      	ldr	x9, [sp, #0x98]
   1066c:      	cmp	x8, x9
   10670:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10674:      	add	x2, x24, #0x18
   10678:      	mov	w8, #0x4                // =4
   1067c:      	mov	x0, x22
   10680:      	mov	w1, #0x8                // =8
   10684:      	blr	x8
   10688:      	ldr	x24, [sp, #0x98]
   1068c:      	ldr	x21, [sp, #0x48]
   10690:      	add	x2, x24, #0x20
   10694:      	stp	x2, x24, [sp, #0x50]
   10698:      	ldr	x8, [sp, #0x30]
   1069c:      	cmp	x21, x8
   106a0:      	b.ne	0x106b0 <generic_lsm_path+0x6860>
   106a4:      	ldr	x8, [sp, #0x38]
   106a8:      	cmp	x2, x8
   106ac:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   106b0:      	mov	w8, #0x4                // =4
   106b4:      	add	x0, sp, #0x70
   106b8:      	mov	w1, #0x8                // =8
   106bc:      	blr	x8
   106c0:      	ldr	x8, [sp, #0x70]
   106c4:      	cmp	x21, x8
   106c8:      	b.eq	0x107b8 <generic_lsm_path+0x6968>
   106cc:      	add	x23, x21, #0x18
   106d0:      	mov	w8, #0x4                // =4
   106d4:      	add	x9, sp, #0x98
   106d8:      	add	x0, sp, #0x98
   106dc:      	mov	w1, #0x8                // =8
   106e0:      	mov	x2, x23
   106e4:      	blr	x8
   106e8:      	ldr	x8, [sp, #0x98]
   106ec:      	cmp	x8, x21
   106f0:      	b.eq	0x107b8 <generic_lsm_path+0x6968>
   106f4:      	mov	w8, #0x4                // =4
   106f8:      	add	x9, sp, #0x78
   106fc:      	add	x0, sp, #0x78
   10700:      	mov	w1, #0x8                // =8
   10704:      	mov	x2, x23
   10708:      	blr	x8
   1070c:      	add	x2, x21, #0x20
   10710:      	mov	w8, #0x4                // =4
   10714:      	mov	w9, #0x10               // =16
   10718:      	add	x10, sp, #0x80
   1071c:      	add	x0, sp, #0x80
   10720:      	mov	w1, #0x10               // =16
   10724:      	blr	x8
   10728:      	ldr	w21, [sp, #0x84]
   1072c:      	ldr	x8, [sp, #0x40]
   10730:      	ldr	x10, [sp, #0x60]
   10734:      	sub	x12, x10, x8
   10738:      	ldr	w23, [sp, #0x68]
   1073c:      	subs	w10, w21, w23
   10740:      	ldr	x9, [sp, #0x88]
   10744:      	csel	w10, wzr, w10, lo
   10748:      	cmp	w23, w21
   1074c:      	csel	w11, w23, w21, lo
   10750:      	cinc	w13, w11, hi
   10754:      	sub	w14, w23, w13
   10758:      	subs	x12, x12, x13
   1075c:      	str	w14, [sp, #0x68]
   10760:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10764:      	cmp	x12, #0xfff
   10768:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   1076c:      	cmp	w23, w21
   10770:      	b.ls	0x1077c <generic_lsm_path+0x692c>
   10774:      	mov	w13, #0x2f              // =47
   10778:      	strb	w13, [x8, x12]
   1077c:      	add	x19, x8, x12
   10780:      	cmp	w23, w21
   10784:      	add	x2, x9, x10
   10788:      	and	w1, w11, #0xff
   1078c:      	mov	w8, #0x4                // =4
   10790:      	cinc	x0, x19, hi
   10794:      	blr	x8
   10798:      	cmp	w23, w21
   1079c:      	str	x19, [sp, #0x60]
   107a0:      	add	x19, sp, #0x70
   107a4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   107a8:      	ldr	x21, [sp, #0x78]
   107ac:      	ldp	x2, x24, [sp, #0x50]
   107b0:      	str	x21, [sp, #0x48]
   107b4:      	b	0x10804 <generic_lsm_path+0x69b4>
   107b8:      	add	x2, x24, #0x10
   107bc:      	mov	w8, #0x4                // =4
   107c0:      	add	x9, sp, #0x98
   107c4:      	add	x0, sp, #0x98
   107c8:      	mov	w1, #0x8                // =8
   107cc:      	blr	x8
   107d0:      	ldr	x8, [sp, #0x58]
   107d4:      	ldr	x9, [sp, #0x98]
   107d8:      	cmp	x8, x9
   107dc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   107e0:      	add	x2, x24, #0x18
   107e4:      	mov	w8, #0x4                // =4
   107e8:      	mov	x0, x22
   107ec:      	mov	w1, #0x8                // =8
   107f0:      	blr	x8
   107f4:      	ldr	x24, [sp, #0x98]
   107f8:      	ldr	x21, [sp, #0x48]
   107fc:      	add	x2, x24, #0x20
   10800:      	stp	x2, x24, [sp, #0x50]
   10804:      	ldr	x8, [sp, #0x30]
   10808:      	cmp	x21, x8
   1080c:      	b.ne	0x1081c <generic_lsm_path+0x69cc>
   10810:      	ldr	x8, [sp, #0x38]
   10814:      	cmp	x2, x8
   10818:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1081c:      	mov	w8, #0x4                // =4
   10820:      	add	x0, sp, #0x70
   10824:      	mov	w1, #0x8                // =8
   10828:      	blr	x8
   1082c:      	ldr	x8, [sp, #0x70]
   10830:      	cmp	x21, x8
   10834:      	b.eq	0x10924 <generic_lsm_path+0x6ad4>
   10838:      	add	x23, x21, #0x18
   1083c:      	mov	w8, #0x4                // =4
   10840:      	add	x9, sp, #0x98
   10844:      	add	x0, sp, #0x98
   10848:      	mov	w1, #0x8                // =8
   1084c:      	mov	x2, x23
   10850:      	blr	x8
   10854:      	ldr	x8, [sp, #0x98]
   10858:      	cmp	x8, x21
   1085c:      	b.eq	0x10924 <generic_lsm_path+0x6ad4>
   10860:      	mov	w8, #0x4                // =4
   10864:      	add	x9, sp, #0x78
   10868:      	add	x0, sp, #0x78
   1086c:      	mov	w1, #0x8                // =8
   10870:      	mov	x2, x23
   10874:      	blr	x8
   10878:      	add	x2, x21, #0x20
   1087c:      	mov	w8, #0x4                // =4
   10880:      	mov	w9, #0x10               // =16
   10884:      	add	x10, sp, #0x80
   10888:      	add	x0, sp, #0x80
   1088c:      	mov	w1, #0x10               // =16
   10890:      	blr	x8
   10894:      	ldr	w21, [sp, #0x84]
   10898:      	ldr	x8, [sp, #0x40]
   1089c:      	ldr	x10, [sp, #0x60]
   108a0:      	sub	x12, x10, x8
   108a4:      	ldr	w23, [sp, #0x68]
   108a8:      	subs	w10, w21, w23
   108ac:      	ldr	x9, [sp, #0x88]
   108b0:      	csel	w10, wzr, w10, lo
   108b4:      	cmp	w23, w21
   108b8:      	csel	w11, w23, w21, lo
   108bc:      	cinc	w13, w11, hi
   108c0:      	sub	w14, w23, w13
   108c4:      	subs	x12, x12, x13
   108c8:      	str	w14, [sp, #0x68]
   108cc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   108d0:      	cmp	x12, #0xfff
   108d4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   108d8:      	cmp	w23, w21
   108dc:      	b.ls	0x108e8 <generic_lsm_path+0x6a98>
   108e0:      	mov	w13, #0x2f              // =47
   108e4:      	strb	w13, [x8, x12]
   108e8:      	add	x19, x8, x12
   108ec:      	cmp	w23, w21
   108f0:      	add	x2, x9, x10
   108f4:      	and	w1, w11, #0xff
   108f8:      	mov	w8, #0x4                // =4
   108fc:      	cinc	x0, x19, hi
   10900:      	blr	x8
   10904:      	cmp	w23, w21
   10908:      	str	x19, [sp, #0x60]
   1090c:      	add	x19, sp, #0x70
   10910:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   10914:      	ldr	x21, [sp, #0x78]
   10918:      	ldp	x2, x24, [sp, #0x50]
   1091c:      	str	x21, [sp, #0x48]
   10920:      	b	0x10970 <generic_lsm_path+0x6b20>
   10924:      	add	x2, x24, #0x10
   10928:      	mov	w8, #0x4                // =4
   1092c:      	add	x9, sp, #0x98
   10930:      	add	x0, sp, #0x98
   10934:      	mov	w1, #0x8                // =8
   10938:      	blr	x8
   1093c:      	ldr	x8, [sp, #0x58]
   10940:      	ldr	x9, [sp, #0x98]
   10944:      	cmp	x8, x9
   10948:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1094c:      	add	x2, x24, #0x18
   10950:      	mov	w8, #0x4                // =4
   10954:      	mov	x0, x22
   10958:      	mov	w1, #0x8                // =8
   1095c:      	blr	x8
   10960:      	ldr	x24, [sp, #0x98]
   10964:      	ldr	x21, [sp, #0x48]
   10968:      	add	x2, x24, #0x20
   1096c:      	stp	x2, x24, [sp, #0x50]
   10970:      	ldr	x8, [sp, #0x30]
   10974:      	cmp	x21, x8
   10978:      	b.ne	0x10988 <generic_lsm_path+0x6b38>
   1097c:      	ldr	x8, [sp, #0x38]
   10980:      	cmp	x2, x8
   10984:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10988:      	mov	w8, #0x4                // =4
   1098c:      	add	x0, sp, #0x70
   10990:      	mov	w1, #0x8                // =8
   10994:      	blr	x8
   10998:      	ldr	x8, [sp, #0x70]
   1099c:      	cmp	x21, x8
   109a0:      	b.eq	0x10a90 <generic_lsm_path+0x6c40>
   109a4:      	add	x23, x21, #0x18
   109a8:      	mov	w8, #0x4                // =4
   109ac:      	add	x9, sp, #0x98
   109b0:      	add	x0, sp, #0x98
   109b4:      	mov	w1, #0x8                // =8
   109b8:      	mov	x2, x23
   109bc:      	blr	x8
   109c0:      	ldr	x8, [sp, #0x98]
   109c4:      	cmp	x8, x21
   109c8:      	b.eq	0x10a90 <generic_lsm_path+0x6c40>
   109cc:      	mov	w8, #0x4                // =4
   109d0:      	add	x9, sp, #0x78
   109d4:      	add	x0, sp, #0x78
   109d8:      	mov	w1, #0x8                // =8
   109dc:      	mov	x2, x23
   109e0:      	blr	x8
   109e4:      	add	x2, x21, #0x20
   109e8:      	mov	w8, #0x4                // =4
   109ec:      	mov	w9, #0x10               // =16
   109f0:      	add	x10, sp, #0x80
   109f4:      	add	x0, sp, #0x80
   109f8:      	mov	w1, #0x10               // =16
   109fc:      	blr	x8
   10a00:      	ldr	w21, [sp, #0x84]
   10a04:      	ldr	x8, [sp, #0x40]
   10a08:      	ldr	x10, [sp, #0x60]
   10a0c:      	sub	x12, x10, x8
   10a10:      	ldr	w23, [sp, #0x68]
   10a14:      	subs	w10, w21, w23
   10a18:      	ldr	x9, [sp, #0x88]
   10a1c:      	csel	w10, wzr, w10, lo
   10a20:      	cmp	w23, w21
   10a24:      	csel	w11, w23, w21, lo
   10a28:      	cinc	w13, w11, hi
   10a2c:      	sub	w14, w23, w13
   10a30:      	subs	x12, x12, x13
   10a34:      	str	w14, [sp, #0x68]
   10a38:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10a3c:      	cmp	x12, #0xfff
   10a40:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10a44:      	cmp	w23, w21
   10a48:      	b.ls	0x10a54 <generic_lsm_path+0x6c04>
   10a4c:      	mov	w13, #0x2f              // =47
   10a50:      	strb	w13, [x8, x12]
   10a54:      	add	x19, x8, x12
   10a58:      	cmp	w23, w21
   10a5c:      	add	x2, x9, x10
   10a60:      	and	w1, w11, #0xff
   10a64:      	mov	w8, #0x4                // =4
   10a68:      	cinc	x0, x19, hi
   10a6c:      	blr	x8
   10a70:      	cmp	w23, w21
   10a74:      	str	x19, [sp, #0x60]
   10a78:      	add	x19, sp, #0x70
   10a7c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   10a80:      	ldr	x21, [sp, #0x78]
   10a84:      	ldp	x2, x24, [sp, #0x50]
   10a88:      	str	x21, [sp, #0x48]
   10a8c:      	b	0x10adc <generic_lsm_path+0x6c8c>
   10a90:      	add	x2, x24, #0x10
   10a94:      	mov	w8, #0x4                // =4
   10a98:      	add	x9, sp, #0x98
   10a9c:      	add	x0, sp, #0x98
   10aa0:      	mov	w1, #0x8                // =8
   10aa4:      	blr	x8
   10aa8:      	ldr	x8, [sp, #0x58]
   10aac:      	ldr	x9, [sp, #0x98]
   10ab0:      	cmp	x8, x9
   10ab4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10ab8:      	add	x2, x24, #0x18
   10abc:      	mov	w8, #0x4                // =4
   10ac0:      	mov	x0, x22
   10ac4:      	mov	w1, #0x8                // =8
   10ac8:      	blr	x8
   10acc:      	ldr	x24, [sp, #0x98]
   10ad0:      	ldr	x21, [sp, #0x48]
   10ad4:      	add	x2, x24, #0x20
   10ad8:      	stp	x2, x24, [sp, #0x50]
   10adc:      	ldr	x8, [sp, #0x30]
   10ae0:      	cmp	x21, x8
   10ae4:      	b.ne	0x10af4 <generic_lsm_path+0x6ca4>
   10ae8:      	ldr	x8, [sp, #0x38]
   10aec:      	cmp	x2, x8
   10af0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10af4:      	mov	w8, #0x4                // =4
   10af8:      	add	x0, sp, #0x70
   10afc:      	mov	w1, #0x8                // =8
   10b00:      	blr	x8
   10b04:      	ldr	x8, [sp, #0x70]
   10b08:      	cmp	x21, x8
   10b0c:      	b.eq	0x10bfc <generic_lsm_path+0x6dac>
   10b10:      	add	x23, x21, #0x18
   10b14:      	mov	w8, #0x4                // =4
   10b18:      	add	x9, sp, #0x98
   10b1c:      	add	x0, sp, #0x98
   10b20:      	mov	w1, #0x8                // =8
   10b24:      	mov	x2, x23
   10b28:      	blr	x8
   10b2c:      	ldr	x8, [sp, #0x98]
   10b30:      	cmp	x8, x21
   10b34:      	b.eq	0x10bfc <generic_lsm_path+0x6dac>
   10b38:      	mov	w8, #0x4                // =4
   10b3c:      	add	x9, sp, #0x78
   10b40:      	add	x0, sp, #0x78
   10b44:      	mov	w1, #0x8                // =8
   10b48:      	mov	x2, x23
   10b4c:      	blr	x8
   10b50:      	add	x2, x21, #0x20
   10b54:      	mov	w8, #0x4                // =4
   10b58:      	mov	w9, #0x10               // =16
   10b5c:      	add	x10, sp, #0x80
   10b60:      	add	x0, sp, #0x80
   10b64:      	mov	w1, #0x10               // =16
   10b68:      	blr	x8
   10b6c:      	ldr	w21, [sp, #0x84]
   10b70:      	ldr	x8, [sp, #0x40]
   10b74:      	ldr	x10, [sp, #0x60]
   10b78:      	sub	x12, x10, x8
   10b7c:      	ldr	w23, [sp, #0x68]
   10b80:      	subs	w10, w21, w23
   10b84:      	ldr	x9, [sp, #0x88]
   10b88:      	csel	w10, wzr, w10, lo
   10b8c:      	cmp	w23, w21
   10b90:      	csel	w11, w23, w21, lo
   10b94:      	cinc	w13, w11, hi
   10b98:      	sub	w14, w23, w13
   10b9c:      	subs	x12, x12, x13
   10ba0:      	str	w14, [sp, #0x68]
   10ba4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10ba8:      	cmp	x12, #0xfff
   10bac:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10bb0:      	cmp	w23, w21
   10bb4:      	b.ls	0x10bc0 <generic_lsm_path+0x6d70>
   10bb8:      	mov	w13, #0x2f              // =47
   10bbc:      	strb	w13, [x8, x12]
   10bc0:      	add	x19, x8, x12
   10bc4:      	cmp	w23, w21
   10bc8:      	add	x2, x9, x10
   10bcc:      	and	w1, w11, #0xff
   10bd0:      	mov	w8, #0x4                // =4
   10bd4:      	cinc	x0, x19, hi
   10bd8:      	blr	x8
   10bdc:      	cmp	w23, w21
   10be0:      	str	x19, [sp, #0x60]
   10be4:      	add	x19, sp, #0x70
   10be8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   10bec:      	ldr	x21, [sp, #0x78]
   10bf0:      	ldp	x2, x24, [sp, #0x50]
   10bf4:      	str	x21, [sp, #0x48]
   10bf8:      	b	0x10c48 <generic_lsm_path+0x6df8>
   10bfc:      	add	x2, x24, #0x10
   10c00:      	mov	w8, #0x4                // =4
   10c04:      	add	x9, sp, #0x98
   10c08:      	add	x0, sp, #0x98
   10c0c:      	mov	w1, #0x8                // =8
   10c10:      	blr	x8
   10c14:      	ldr	x8, [sp, #0x58]
   10c18:      	ldr	x9, [sp, #0x98]
   10c1c:      	cmp	x8, x9
   10c20:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10c24:      	add	x2, x24, #0x18
   10c28:      	mov	w8, #0x4                // =4
   10c2c:      	mov	x0, x22
   10c30:      	mov	w1, #0x8                // =8
   10c34:      	blr	x8
   10c38:      	ldr	x24, [sp, #0x98]
   10c3c:      	ldr	x21, [sp, #0x48]
   10c40:      	add	x2, x24, #0x20
   10c44:      	stp	x2, x24, [sp, #0x50]
   10c48:      	ldr	x8, [sp, #0x30]
   10c4c:      	cmp	x21, x8
   10c50:      	b.ne	0x10c60 <generic_lsm_path+0x6e10>
   10c54:      	ldr	x8, [sp, #0x38]
   10c58:      	cmp	x2, x8
   10c5c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10c60:      	mov	w8, #0x4                // =4
   10c64:      	add	x0, sp, #0x70
   10c68:      	mov	w1, #0x8                // =8
   10c6c:      	blr	x8
   10c70:      	ldr	x8, [sp, #0x70]
   10c74:      	cmp	x21, x8
   10c78:      	b.eq	0x10d68 <generic_lsm_path+0x6f18>
   10c7c:      	add	x23, x21, #0x18
   10c80:      	mov	w8, #0x4                // =4
   10c84:      	add	x9, sp, #0x98
   10c88:      	add	x0, sp, #0x98
   10c8c:      	mov	w1, #0x8                // =8
   10c90:      	mov	x2, x23
   10c94:      	blr	x8
   10c98:      	ldr	x8, [sp, #0x98]
   10c9c:      	cmp	x8, x21
   10ca0:      	b.eq	0x10d68 <generic_lsm_path+0x6f18>
   10ca4:      	mov	w8, #0x4                // =4
   10ca8:      	add	x9, sp, #0x78
   10cac:      	add	x0, sp, #0x78
   10cb0:      	mov	w1, #0x8                // =8
   10cb4:      	mov	x2, x23
   10cb8:      	blr	x8
   10cbc:      	add	x2, x21, #0x20
   10cc0:      	mov	w8, #0x4                // =4
   10cc4:      	mov	w9, #0x10               // =16
   10cc8:      	add	x10, sp, #0x80
   10ccc:      	add	x0, sp, #0x80
   10cd0:      	mov	w1, #0x10               // =16
   10cd4:      	blr	x8
   10cd8:      	ldr	w21, [sp, #0x84]
   10cdc:      	ldr	x8, [sp, #0x40]
   10ce0:      	ldr	x10, [sp, #0x60]
   10ce4:      	sub	x12, x10, x8
   10ce8:      	ldr	w23, [sp, #0x68]
   10cec:      	subs	w10, w21, w23
   10cf0:      	ldr	x9, [sp, #0x88]
   10cf4:      	csel	w10, wzr, w10, lo
   10cf8:      	cmp	w23, w21
   10cfc:      	csel	w11, w23, w21, lo
   10d00:      	cinc	w13, w11, hi
   10d04:      	sub	w14, w23, w13
   10d08:      	subs	x12, x12, x13
   10d0c:      	str	w14, [sp, #0x68]
   10d10:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10d14:      	cmp	x12, #0xfff
   10d18:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10d1c:      	cmp	w23, w21
   10d20:      	b.ls	0x10d2c <generic_lsm_path+0x6edc>
   10d24:      	mov	w13, #0x2f              // =47
   10d28:      	strb	w13, [x8, x12]
   10d2c:      	add	x19, x8, x12
   10d30:      	cmp	w23, w21
   10d34:      	add	x2, x9, x10
   10d38:      	and	w1, w11, #0xff
   10d3c:      	mov	w8, #0x4                // =4
   10d40:      	cinc	x0, x19, hi
   10d44:      	blr	x8
   10d48:      	cmp	w23, w21
   10d4c:      	str	x19, [sp, #0x60]
   10d50:      	add	x19, sp, #0x70
   10d54:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   10d58:      	ldr	x21, [sp, #0x78]
   10d5c:      	ldp	x2, x24, [sp, #0x50]
   10d60:      	str	x21, [sp, #0x48]
   10d64:      	b	0x10db4 <generic_lsm_path+0x6f64>
   10d68:      	add	x2, x24, #0x10
   10d6c:      	mov	w8, #0x4                // =4
   10d70:      	add	x9, sp, #0x98
   10d74:      	add	x0, sp, #0x98
   10d78:      	mov	w1, #0x8                // =8
   10d7c:      	blr	x8
   10d80:      	ldr	x8, [sp, #0x58]
   10d84:      	ldr	x9, [sp, #0x98]
   10d88:      	cmp	x8, x9
   10d8c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10d90:      	add	x2, x24, #0x18
   10d94:      	mov	w8, #0x4                // =4
   10d98:      	mov	x0, x22
   10d9c:      	mov	w1, #0x8                // =8
   10da0:      	blr	x8
   10da4:      	ldr	x24, [sp, #0x98]
   10da8:      	ldr	x21, [sp, #0x48]
   10dac:      	add	x2, x24, #0x20
   10db0:      	stp	x2, x24, [sp, #0x50]
   10db4:      	ldr	x8, [sp, #0x30]
   10db8:      	cmp	x21, x8
   10dbc:      	b.ne	0x10dcc <generic_lsm_path+0x6f7c>
   10dc0:      	ldr	x8, [sp, #0x38]
   10dc4:      	cmp	x2, x8
   10dc8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10dcc:      	mov	w8, #0x4                // =4
   10dd0:      	add	x0, sp, #0x70
   10dd4:      	mov	w1, #0x8                // =8
   10dd8:      	blr	x8
   10ddc:      	ldr	x8, [sp, #0x70]
   10de0:      	cmp	x21, x8
   10de4:      	b.eq	0x10ed4 <generic_lsm_path+0x7084>
   10de8:      	add	x23, x21, #0x18
   10dec:      	mov	w8, #0x4                // =4
   10df0:      	add	x9, sp, #0x98
   10df4:      	add	x0, sp, #0x98
   10df8:      	mov	w1, #0x8                // =8
   10dfc:      	mov	x2, x23
   10e00:      	blr	x8
   10e04:      	ldr	x8, [sp, #0x98]
   10e08:      	cmp	x8, x21
   10e0c:      	b.eq	0x10ed4 <generic_lsm_path+0x7084>
   10e10:      	mov	w8, #0x4                // =4
   10e14:      	add	x9, sp, #0x78
   10e18:      	add	x0, sp, #0x78
   10e1c:      	mov	w1, #0x8                // =8
   10e20:      	mov	x2, x23
   10e24:      	blr	x8
   10e28:      	add	x2, x21, #0x20
   10e2c:      	mov	w8, #0x4                // =4
   10e30:      	mov	w9, #0x10               // =16
   10e34:      	add	x10, sp, #0x80
   10e38:      	add	x0, sp, #0x80
   10e3c:      	mov	w1, #0x10               // =16
   10e40:      	blr	x8
   10e44:      	ldr	w21, [sp, #0x84]
   10e48:      	ldr	x8, [sp, #0x40]
   10e4c:      	ldr	x10, [sp, #0x60]
   10e50:      	sub	x12, x10, x8
   10e54:      	ldr	w23, [sp, #0x68]
   10e58:      	subs	w10, w21, w23
   10e5c:      	ldr	x9, [sp, #0x88]
   10e60:      	csel	w10, wzr, w10, lo
   10e64:      	cmp	w23, w21
   10e68:      	csel	w11, w23, w21, lo
   10e6c:      	cinc	w13, w11, hi
   10e70:      	sub	w14, w23, w13
   10e74:      	subs	x12, x12, x13
   10e78:      	str	w14, [sp, #0x68]
   10e7c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10e80:      	cmp	x12, #0xfff
   10e84:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10e88:      	cmp	w23, w21
   10e8c:      	b.ls	0x10e98 <generic_lsm_path+0x7048>
   10e90:      	mov	w13, #0x2f              // =47
   10e94:      	strb	w13, [x8, x12]
   10e98:      	add	x19, x8, x12
   10e9c:      	cmp	w23, w21
   10ea0:      	add	x2, x9, x10
   10ea4:      	and	w1, w11, #0xff
   10ea8:      	mov	w8, #0x4                // =4
   10eac:      	cinc	x0, x19, hi
   10eb0:      	blr	x8
   10eb4:      	cmp	w23, w21
   10eb8:      	str	x19, [sp, #0x60]
   10ebc:      	add	x19, sp, #0x70
   10ec0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   10ec4:      	ldr	x21, [sp, #0x78]
   10ec8:      	ldp	x2, x24, [sp, #0x50]
   10ecc:      	str	x21, [sp, #0x48]
   10ed0:      	b	0x10f20 <generic_lsm_path+0x70d0>
   10ed4:      	add	x2, x24, #0x10
   10ed8:      	mov	w8, #0x4                // =4
   10edc:      	add	x9, sp, #0x98
   10ee0:      	add	x0, sp, #0x98
   10ee4:      	mov	w1, #0x8                // =8
   10ee8:      	blr	x8
   10eec:      	ldr	x8, [sp, #0x58]
   10ef0:      	ldr	x9, [sp, #0x98]
   10ef4:      	cmp	x8, x9
   10ef8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10efc:      	add	x2, x24, #0x18
   10f00:      	mov	w8, #0x4                // =4
   10f04:      	mov	x0, x22
   10f08:      	mov	w1, #0x8                // =8
   10f0c:      	blr	x8
   10f10:      	ldr	x24, [sp, #0x98]
   10f14:      	ldr	x21, [sp, #0x48]
   10f18:      	add	x2, x24, #0x20
   10f1c:      	stp	x2, x24, [sp, #0x50]
   10f20:      	ldr	x8, [sp, #0x30]
   10f24:      	cmp	x21, x8
   10f28:      	b.ne	0x10f38 <generic_lsm_path+0x70e8>
   10f2c:      	ldr	x8, [sp, #0x38]
   10f30:      	cmp	x2, x8
   10f34:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   10f38:      	mov	w8, #0x4                // =4
   10f3c:      	add	x0, sp, #0x70
   10f40:      	mov	w1, #0x8                // =8
   10f44:      	blr	x8
   10f48:      	ldr	x8, [sp, #0x70]
   10f4c:      	cmp	x21, x8
   10f50:      	b.eq	0x11040 <generic_lsm_path+0x71f0>
   10f54:      	add	x23, x21, #0x18
   10f58:      	mov	w8, #0x4                // =4
   10f5c:      	add	x9, sp, #0x98
   10f60:      	add	x0, sp, #0x98
   10f64:      	mov	w1, #0x8                // =8
   10f68:      	mov	x2, x23
   10f6c:      	blr	x8
   10f70:      	ldr	x8, [sp, #0x98]
   10f74:      	cmp	x8, x21
   10f78:      	b.eq	0x11040 <generic_lsm_path+0x71f0>
   10f7c:      	mov	w8, #0x4                // =4
   10f80:      	add	x9, sp, #0x78
   10f84:      	add	x0, sp, #0x78
   10f88:      	mov	w1, #0x8                // =8
   10f8c:      	mov	x2, x23
   10f90:      	blr	x8
   10f94:      	add	x2, x21, #0x20
   10f98:      	mov	w8, #0x4                // =4
   10f9c:      	mov	w9, #0x10               // =16
   10fa0:      	add	x10, sp, #0x80
   10fa4:      	add	x0, sp, #0x80
   10fa8:      	mov	w1, #0x10               // =16
   10fac:      	blr	x8
   10fb0:      	ldr	w21, [sp, #0x84]
   10fb4:      	ldr	x8, [sp, #0x40]
   10fb8:      	ldr	x10, [sp, #0x60]
   10fbc:      	sub	x12, x10, x8
   10fc0:      	ldr	w23, [sp, #0x68]
   10fc4:      	subs	w10, w21, w23
   10fc8:      	ldr	x9, [sp, #0x88]
   10fcc:      	csel	w10, wzr, w10, lo
   10fd0:      	cmp	w23, w21
   10fd4:      	csel	w11, w23, w21, lo
   10fd8:      	cinc	w13, w11, hi
   10fdc:      	sub	w14, w23, w13
   10fe0:      	subs	x12, x12, x13
   10fe4:      	str	w14, [sp, #0x68]
   10fe8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   10fec:      	cmp	x12, #0xfff
   10ff0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   10ff4:      	cmp	w23, w21
   10ff8:      	b.ls	0x11004 <generic_lsm_path+0x71b4>
   10ffc:      	mov	w13, #0x2f              // =47
   11000:      	strb	w13, [x8, x12]
   11004:      	add	x19, x8, x12
   11008:      	cmp	w23, w21
   1100c:      	add	x2, x9, x10
   11010:      	and	w1, w11, #0xff
   11014:      	mov	w8, #0x4                // =4
   11018:      	cinc	x0, x19, hi
   1101c:      	blr	x8
   11020:      	cmp	w23, w21
   11024:      	str	x19, [sp, #0x60]
   11028:      	add	x19, sp, #0x70
   1102c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11030:      	ldr	x21, [sp, #0x78]
   11034:      	ldp	x2, x24, [sp, #0x50]
   11038:      	str	x21, [sp, #0x48]
   1103c:      	b	0x1108c <generic_lsm_path+0x723c>
   11040:      	add	x2, x24, #0x10
   11044:      	mov	w8, #0x4                // =4
   11048:      	add	x9, sp, #0x98
   1104c:      	add	x0, sp, #0x98
   11050:      	mov	w1, #0x8                // =8
   11054:      	blr	x8
   11058:      	ldr	x8, [sp, #0x58]
   1105c:      	ldr	x9, [sp, #0x98]
   11060:      	cmp	x8, x9
   11064:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11068:      	add	x2, x24, #0x18
   1106c:      	mov	w8, #0x4                // =4
   11070:      	mov	x0, x22
   11074:      	mov	w1, #0x8                // =8
   11078:      	blr	x8
   1107c:      	ldr	x24, [sp, #0x98]
   11080:      	ldr	x21, [sp, #0x48]
   11084:      	add	x2, x24, #0x20
   11088:      	stp	x2, x24, [sp, #0x50]
   1108c:      	ldr	x8, [sp, #0x30]
   11090:      	cmp	x21, x8
   11094:      	b.ne	0x110a4 <generic_lsm_path+0x7254>
   11098:      	ldr	x8, [sp, #0x38]
   1109c:      	cmp	x2, x8
   110a0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   110a4:      	mov	w8, #0x4                // =4
   110a8:      	add	x0, sp, #0x70
   110ac:      	mov	w1, #0x8                // =8
   110b0:      	blr	x8
   110b4:      	ldr	x8, [sp, #0x70]
   110b8:      	cmp	x21, x8
   110bc:      	b.eq	0x111ac <generic_lsm_path+0x735c>
   110c0:      	add	x23, x21, #0x18
   110c4:      	mov	w8, #0x4                // =4
   110c8:      	add	x9, sp, #0x98
   110cc:      	add	x0, sp, #0x98
   110d0:      	mov	w1, #0x8                // =8
   110d4:      	mov	x2, x23
   110d8:      	blr	x8
   110dc:      	ldr	x8, [sp, #0x98]
   110e0:      	cmp	x8, x21
   110e4:      	b.eq	0x111ac <generic_lsm_path+0x735c>
   110e8:      	mov	w8, #0x4                // =4
   110ec:      	add	x9, sp, #0x78
   110f0:      	add	x0, sp, #0x78
   110f4:      	mov	w1, #0x8                // =8
   110f8:      	mov	x2, x23
   110fc:      	blr	x8
   11100:      	add	x2, x21, #0x20
   11104:      	mov	w8, #0x4                // =4
   11108:      	mov	w9, #0x10               // =16
   1110c:      	add	x10, sp, #0x80
   11110:      	add	x0, sp, #0x80
   11114:      	mov	w1, #0x10               // =16
   11118:      	blr	x8
   1111c:      	ldr	w21, [sp, #0x84]
   11120:      	ldr	x8, [sp, #0x40]
   11124:      	ldr	x10, [sp, #0x60]
   11128:      	sub	x12, x10, x8
   1112c:      	ldr	w23, [sp, #0x68]
   11130:      	subs	w10, w21, w23
   11134:      	ldr	x9, [sp, #0x88]
   11138:      	csel	w10, wzr, w10, lo
   1113c:      	cmp	w23, w21
   11140:      	csel	w11, w23, w21, lo
   11144:      	cinc	w13, w11, hi
   11148:      	sub	w14, w23, w13
   1114c:      	subs	x12, x12, x13
   11150:      	str	w14, [sp, #0x68]
   11154:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11158:      	cmp	x12, #0xfff
   1115c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11160:      	cmp	w23, w21
   11164:      	b.ls	0x11170 <generic_lsm_path+0x7320>
   11168:      	mov	w13, #0x2f              // =47
   1116c:      	strb	w13, [x8, x12]
   11170:      	add	x19, x8, x12
   11174:      	cmp	w23, w21
   11178:      	add	x2, x9, x10
   1117c:      	and	w1, w11, #0xff
   11180:      	mov	w8, #0x4                // =4
   11184:      	cinc	x0, x19, hi
   11188:      	blr	x8
   1118c:      	cmp	w23, w21
   11190:      	str	x19, [sp, #0x60]
   11194:      	add	x19, sp, #0x70
   11198:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1119c:      	ldr	x21, [sp, #0x78]
   111a0:      	ldp	x2, x24, [sp, #0x50]
   111a4:      	str	x21, [sp, #0x48]
   111a8:      	b	0x111f8 <generic_lsm_path+0x73a8>
   111ac:      	add	x2, x24, #0x10
   111b0:      	mov	w8, #0x4                // =4
   111b4:      	add	x9, sp, #0x98
   111b8:      	add	x0, sp, #0x98
   111bc:      	mov	w1, #0x8                // =8
   111c0:      	blr	x8
   111c4:      	ldr	x8, [sp, #0x58]
   111c8:      	ldr	x9, [sp, #0x98]
   111cc:      	cmp	x8, x9
   111d0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   111d4:      	add	x2, x24, #0x18
   111d8:      	mov	w8, #0x4                // =4
   111dc:      	mov	x0, x22
   111e0:      	mov	w1, #0x8                // =8
   111e4:      	blr	x8
   111e8:      	ldr	x24, [sp, #0x98]
   111ec:      	ldr	x21, [sp, #0x48]
   111f0:      	add	x2, x24, #0x20
   111f4:      	stp	x2, x24, [sp, #0x50]
   111f8:      	ldr	x8, [sp, #0x30]
   111fc:      	cmp	x21, x8
   11200:      	b.ne	0x11210 <generic_lsm_path+0x73c0>
   11204:      	ldr	x8, [sp, #0x38]
   11208:      	cmp	x2, x8
   1120c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11210:      	mov	w8, #0x4                // =4
   11214:      	add	x0, sp, #0x70
   11218:      	mov	w1, #0x8                // =8
   1121c:      	blr	x8
   11220:      	ldr	x8, [sp, #0x70]
   11224:      	cmp	x21, x8
   11228:      	b.eq	0x11318 <generic_lsm_path+0x74c8>
   1122c:      	add	x23, x21, #0x18
   11230:      	mov	w8, #0x4                // =4
   11234:      	add	x9, sp, #0x98
   11238:      	add	x0, sp, #0x98
   1123c:      	mov	w1, #0x8                // =8
   11240:      	mov	x2, x23
   11244:      	blr	x8
   11248:      	ldr	x8, [sp, #0x98]
   1124c:      	cmp	x8, x21
   11250:      	b.eq	0x11318 <generic_lsm_path+0x74c8>
   11254:      	mov	w8, #0x4                // =4
   11258:      	add	x9, sp, #0x78
   1125c:      	add	x0, sp, #0x78
   11260:      	mov	w1, #0x8                // =8
   11264:      	mov	x2, x23
   11268:      	blr	x8
   1126c:      	add	x2, x21, #0x20
   11270:      	mov	w8, #0x4                // =4
   11274:      	mov	w9, #0x10               // =16
   11278:      	add	x10, sp, #0x80
   1127c:      	add	x0, sp, #0x80
   11280:      	mov	w1, #0x10               // =16
   11284:      	blr	x8
   11288:      	ldr	w21, [sp, #0x84]
   1128c:      	ldr	x8, [sp, #0x40]
   11290:      	ldr	x10, [sp, #0x60]
   11294:      	sub	x12, x10, x8
   11298:      	ldr	w23, [sp, #0x68]
   1129c:      	subs	w10, w21, w23
   112a0:      	ldr	x9, [sp, #0x88]
   112a4:      	csel	w10, wzr, w10, lo
   112a8:      	cmp	w23, w21
   112ac:      	csel	w11, w23, w21, lo
   112b0:      	cinc	w13, w11, hi
   112b4:      	sub	w14, w23, w13
   112b8:      	subs	x12, x12, x13
   112bc:      	str	w14, [sp, #0x68]
   112c0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   112c4:      	cmp	x12, #0xfff
   112c8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   112cc:      	cmp	w23, w21
   112d0:      	b.ls	0x112dc <generic_lsm_path+0x748c>
   112d4:      	mov	w13, #0x2f              // =47
   112d8:      	strb	w13, [x8, x12]
   112dc:      	add	x19, x8, x12
   112e0:      	cmp	w23, w21
   112e4:      	add	x2, x9, x10
   112e8:      	and	w1, w11, #0xff
   112ec:      	mov	w8, #0x4                // =4
   112f0:      	cinc	x0, x19, hi
   112f4:      	blr	x8
   112f8:      	cmp	w23, w21
   112fc:      	str	x19, [sp, #0x60]
   11300:      	add	x19, sp, #0x70
   11304:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11308:      	ldr	x21, [sp, #0x78]
   1130c:      	ldp	x2, x24, [sp, #0x50]
   11310:      	str	x21, [sp, #0x48]
   11314:      	b	0x11364 <generic_lsm_path+0x7514>
   11318:      	add	x2, x24, #0x10
   1131c:      	mov	w8, #0x4                // =4
   11320:      	add	x9, sp, #0x98
   11324:      	add	x0, sp, #0x98
   11328:      	mov	w1, #0x8                // =8
   1132c:      	blr	x8
   11330:      	ldr	x8, [sp, #0x58]
   11334:      	ldr	x9, [sp, #0x98]
   11338:      	cmp	x8, x9
   1133c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11340:      	add	x2, x24, #0x18
   11344:      	mov	w8, #0x4                // =4
   11348:      	mov	x0, x22
   1134c:      	mov	w1, #0x8                // =8
   11350:      	blr	x8
   11354:      	ldr	x24, [sp, #0x98]
   11358:      	ldr	x21, [sp, #0x48]
   1135c:      	add	x2, x24, #0x20
   11360:      	stp	x2, x24, [sp, #0x50]
   11364:      	ldr	x8, [sp, #0x30]
   11368:      	cmp	x21, x8
   1136c:      	b.ne	0x1137c <generic_lsm_path+0x752c>
   11370:      	ldr	x8, [sp, #0x38]
   11374:      	cmp	x2, x8
   11378:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1137c:      	mov	w8, #0x4                // =4
   11380:      	add	x0, sp, #0x70
   11384:      	mov	w1, #0x8                // =8
   11388:      	blr	x8
   1138c:      	ldr	x8, [sp, #0x70]
   11390:      	cmp	x21, x8
   11394:      	b.eq	0x11484 <generic_lsm_path+0x7634>
   11398:      	add	x23, x21, #0x18
   1139c:      	mov	w8, #0x4                // =4
   113a0:      	add	x9, sp, #0x98
   113a4:      	add	x0, sp, #0x98
   113a8:      	mov	w1, #0x8                // =8
   113ac:      	mov	x2, x23
   113b0:      	blr	x8
   113b4:      	ldr	x8, [sp, #0x98]
   113b8:      	cmp	x8, x21
   113bc:      	b.eq	0x11484 <generic_lsm_path+0x7634>
   113c0:      	mov	w8, #0x4                // =4
   113c4:      	add	x9, sp, #0x78
   113c8:      	add	x0, sp, #0x78
   113cc:      	mov	w1, #0x8                // =8
   113d0:      	mov	x2, x23
   113d4:      	blr	x8
   113d8:      	add	x2, x21, #0x20
   113dc:      	mov	w8, #0x4                // =4
   113e0:      	mov	w9, #0x10               // =16
   113e4:      	add	x10, sp, #0x80
   113e8:      	add	x0, sp, #0x80
   113ec:      	mov	w1, #0x10               // =16
   113f0:      	blr	x8
   113f4:      	ldr	w21, [sp, #0x84]
   113f8:      	ldr	x8, [sp, #0x40]
   113fc:      	ldr	x10, [sp, #0x60]
   11400:      	sub	x12, x10, x8
   11404:      	ldr	w23, [sp, #0x68]
   11408:      	subs	w10, w21, w23
   1140c:      	ldr	x9, [sp, #0x88]
   11410:      	csel	w10, wzr, w10, lo
   11414:      	cmp	w23, w21
   11418:      	csel	w11, w23, w21, lo
   1141c:      	cinc	w13, w11, hi
   11420:      	sub	w14, w23, w13
   11424:      	subs	x12, x12, x13
   11428:      	str	w14, [sp, #0x68]
   1142c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11430:      	cmp	x12, #0xfff
   11434:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11438:      	cmp	w23, w21
   1143c:      	b.ls	0x11448 <generic_lsm_path+0x75f8>
   11440:      	mov	w13, #0x2f              // =47
   11444:      	strb	w13, [x8, x12]
   11448:      	add	x19, x8, x12
   1144c:      	cmp	w23, w21
   11450:      	add	x2, x9, x10
   11454:      	and	w1, w11, #0xff
   11458:      	mov	w8, #0x4                // =4
   1145c:      	cinc	x0, x19, hi
   11460:      	blr	x8
   11464:      	cmp	w23, w21
   11468:      	str	x19, [sp, #0x60]
   1146c:      	add	x19, sp, #0x70
   11470:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11474:      	ldr	x21, [sp, #0x78]
   11478:      	ldp	x2, x24, [sp, #0x50]
   1147c:      	str	x21, [sp, #0x48]
   11480:      	b	0x114d0 <generic_lsm_path+0x7680>
   11484:      	add	x2, x24, #0x10
   11488:      	mov	w8, #0x4                // =4
   1148c:      	add	x9, sp, #0x98
   11490:      	add	x0, sp, #0x98
   11494:      	mov	w1, #0x8                // =8
   11498:      	blr	x8
   1149c:      	ldr	x8, [sp, #0x58]
   114a0:      	ldr	x9, [sp, #0x98]
   114a4:      	cmp	x8, x9
   114a8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   114ac:      	add	x2, x24, #0x18
   114b0:      	mov	w8, #0x4                // =4
   114b4:      	mov	x0, x22
   114b8:      	mov	w1, #0x8                // =8
   114bc:      	blr	x8
   114c0:      	ldr	x24, [sp, #0x98]
   114c4:      	ldr	x21, [sp, #0x48]
   114c8:      	add	x2, x24, #0x20
   114cc:      	stp	x2, x24, [sp, #0x50]
   114d0:      	ldr	x8, [sp, #0x30]
   114d4:      	cmp	x21, x8
   114d8:      	b.ne	0x114e8 <generic_lsm_path+0x7698>
   114dc:      	ldr	x8, [sp, #0x38]
   114e0:      	cmp	x2, x8
   114e4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   114e8:      	mov	w8, #0x4                // =4
   114ec:      	add	x0, sp, #0x70
   114f0:      	mov	w1, #0x8                // =8
   114f4:      	blr	x8
   114f8:      	ldr	x8, [sp, #0x70]
   114fc:      	cmp	x21, x8
   11500:      	b.eq	0x115f0 <generic_lsm_path+0x77a0>
   11504:      	add	x23, x21, #0x18
   11508:      	mov	w8, #0x4                // =4
   1150c:      	add	x9, sp, #0x98
   11510:      	add	x0, sp, #0x98
   11514:      	mov	w1, #0x8                // =8
   11518:      	mov	x2, x23
   1151c:      	blr	x8
   11520:      	ldr	x8, [sp, #0x98]
   11524:      	cmp	x8, x21
   11528:      	b.eq	0x115f0 <generic_lsm_path+0x77a0>
   1152c:      	mov	w8, #0x4                // =4
   11530:      	add	x9, sp, #0x78
   11534:      	add	x0, sp, #0x78
   11538:      	mov	w1, #0x8                // =8
   1153c:      	mov	x2, x23
   11540:      	blr	x8
   11544:      	add	x2, x21, #0x20
   11548:      	mov	w8, #0x4                // =4
   1154c:      	mov	w9, #0x10               // =16
   11550:      	add	x10, sp, #0x80
   11554:      	add	x0, sp, #0x80
   11558:      	mov	w1, #0x10               // =16
   1155c:      	blr	x8
   11560:      	ldr	w21, [sp, #0x84]
   11564:      	ldr	x8, [sp, #0x40]
   11568:      	ldr	x10, [sp, #0x60]
   1156c:      	sub	x12, x10, x8
   11570:      	ldr	w23, [sp, #0x68]
   11574:      	subs	w10, w21, w23
   11578:      	ldr	x9, [sp, #0x88]
   1157c:      	csel	w10, wzr, w10, lo
   11580:      	cmp	w23, w21
   11584:      	csel	w11, w23, w21, lo
   11588:      	cinc	w13, w11, hi
   1158c:      	sub	w14, w23, w13
   11590:      	subs	x12, x12, x13
   11594:      	str	w14, [sp, #0x68]
   11598:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   1159c:      	cmp	x12, #0xfff
   115a0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   115a4:      	cmp	w23, w21
   115a8:      	b.ls	0x115b4 <generic_lsm_path+0x7764>
   115ac:      	mov	w13, #0x2f              // =47
   115b0:      	strb	w13, [x8, x12]
   115b4:      	add	x19, x8, x12
   115b8:      	cmp	w23, w21
   115bc:      	add	x2, x9, x10
   115c0:      	and	w1, w11, #0xff
   115c4:      	mov	w8, #0x4                // =4
   115c8:      	cinc	x0, x19, hi
   115cc:      	blr	x8
   115d0:      	cmp	w23, w21
   115d4:      	str	x19, [sp, #0x60]
   115d8:      	add	x19, sp, #0x70
   115dc:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   115e0:      	ldr	x21, [sp, #0x78]
   115e4:      	ldp	x2, x24, [sp, #0x50]
   115e8:      	str	x21, [sp, #0x48]
   115ec:      	b	0x1163c <generic_lsm_path+0x77ec>
   115f0:      	add	x2, x24, #0x10
   115f4:      	mov	w8, #0x4                // =4
   115f8:      	add	x9, sp, #0x98
   115fc:      	add	x0, sp, #0x98
   11600:      	mov	w1, #0x8                // =8
   11604:      	blr	x8
   11608:      	ldr	x8, [sp, #0x58]
   1160c:      	ldr	x9, [sp, #0x98]
   11610:      	cmp	x8, x9
   11614:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11618:      	add	x2, x24, #0x18
   1161c:      	mov	w8, #0x4                // =4
   11620:      	mov	x0, x22
   11624:      	mov	w1, #0x8                // =8
   11628:      	blr	x8
   1162c:      	ldr	x24, [sp, #0x98]
   11630:      	ldr	x21, [sp, #0x48]
   11634:      	add	x2, x24, #0x20
   11638:      	stp	x2, x24, [sp, #0x50]
   1163c:      	ldr	x8, [sp, #0x30]
   11640:      	cmp	x21, x8
   11644:      	b.ne	0x11654 <generic_lsm_path+0x7804>
   11648:      	ldr	x8, [sp, #0x38]
   1164c:      	cmp	x2, x8
   11650:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11654:      	mov	w8, #0x4                // =4
   11658:      	add	x0, sp, #0x70
   1165c:      	mov	w1, #0x8                // =8
   11660:      	blr	x8
   11664:      	ldr	x8, [sp, #0x70]
   11668:      	cmp	x21, x8
   1166c:      	b.eq	0x1175c <generic_lsm_path+0x790c>
   11670:      	add	x23, x21, #0x18
   11674:      	mov	w8, #0x4                // =4
   11678:      	add	x9, sp, #0x98
   1167c:      	add	x0, sp, #0x98
   11680:      	mov	w1, #0x8                // =8
   11684:      	mov	x2, x23
   11688:      	blr	x8
   1168c:      	ldr	x8, [sp, #0x98]
   11690:      	cmp	x8, x21
   11694:      	b.eq	0x1175c <generic_lsm_path+0x790c>
   11698:      	mov	w8, #0x4                // =4
   1169c:      	add	x9, sp, #0x78
   116a0:      	add	x0, sp, #0x78
   116a4:      	mov	w1, #0x8                // =8
   116a8:      	mov	x2, x23
   116ac:      	blr	x8
   116b0:      	add	x2, x21, #0x20
   116b4:      	mov	w8, #0x4                // =4
   116b8:      	mov	w9, #0x10               // =16
   116bc:      	add	x10, sp, #0x80
   116c0:      	add	x0, sp, #0x80
   116c4:      	mov	w1, #0x10               // =16
   116c8:      	blr	x8
   116cc:      	ldr	w21, [sp, #0x84]
   116d0:      	ldr	x8, [sp, #0x40]
   116d4:      	ldr	x10, [sp, #0x60]
   116d8:      	sub	x12, x10, x8
   116dc:      	ldr	w23, [sp, #0x68]
   116e0:      	subs	w10, w21, w23
   116e4:      	ldr	x9, [sp, #0x88]
   116e8:      	csel	w10, wzr, w10, lo
   116ec:      	cmp	w23, w21
   116f0:      	csel	w11, w23, w21, lo
   116f4:      	cinc	w13, w11, hi
   116f8:      	sub	w14, w23, w13
   116fc:      	subs	x12, x12, x13
   11700:      	str	w14, [sp, #0x68]
   11704:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11708:      	cmp	x12, #0xfff
   1170c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11710:      	cmp	w23, w21
   11714:      	b.ls	0x11720 <generic_lsm_path+0x78d0>
   11718:      	mov	w13, #0x2f              // =47
   1171c:      	strb	w13, [x8, x12]
   11720:      	add	x19, x8, x12
   11724:      	cmp	w23, w21
   11728:      	add	x2, x9, x10
   1172c:      	and	w1, w11, #0xff
   11730:      	mov	w8, #0x4                // =4
   11734:      	cinc	x0, x19, hi
   11738:      	blr	x8
   1173c:      	cmp	w23, w21
   11740:      	str	x19, [sp, #0x60]
   11744:      	add	x19, sp, #0x70
   11748:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1174c:      	ldr	x21, [sp, #0x78]
   11750:      	ldp	x2, x24, [sp, #0x50]
   11754:      	str	x21, [sp, #0x48]
   11758:      	b	0x117a8 <generic_lsm_path+0x7958>
   1175c:      	add	x2, x24, #0x10
   11760:      	mov	w8, #0x4                // =4
   11764:      	add	x9, sp, #0x98
   11768:      	add	x0, sp, #0x98
   1176c:      	mov	w1, #0x8                // =8
   11770:      	blr	x8
   11774:      	ldr	x8, [sp, #0x58]
   11778:      	ldr	x9, [sp, #0x98]
   1177c:      	cmp	x8, x9
   11780:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11784:      	add	x2, x24, #0x18
   11788:      	mov	w8, #0x4                // =4
   1178c:      	mov	x0, x22
   11790:      	mov	w1, #0x8                // =8
   11794:      	blr	x8
   11798:      	ldr	x24, [sp, #0x98]
   1179c:      	ldr	x21, [sp, #0x48]
   117a0:      	add	x2, x24, #0x20
   117a4:      	stp	x2, x24, [sp, #0x50]
   117a8:      	ldr	x8, [sp, #0x30]
   117ac:      	cmp	x21, x8
   117b0:      	b.ne	0x117c0 <generic_lsm_path+0x7970>
   117b4:      	ldr	x8, [sp, #0x38]
   117b8:      	cmp	x2, x8
   117bc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   117c0:      	mov	w8, #0x4                // =4
   117c4:      	add	x0, sp, #0x70
   117c8:      	mov	w1, #0x8                // =8
   117cc:      	blr	x8
   117d0:      	ldr	x8, [sp, #0x70]
   117d4:      	cmp	x21, x8
   117d8:      	b.eq	0x118c8 <generic_lsm_path+0x7a78>
   117dc:      	add	x23, x21, #0x18
   117e0:      	mov	w8, #0x4                // =4
   117e4:      	add	x9, sp, #0x98
   117e8:      	add	x0, sp, #0x98
   117ec:      	mov	w1, #0x8                // =8
   117f0:      	mov	x2, x23
   117f4:      	blr	x8
   117f8:      	ldr	x8, [sp, #0x98]
   117fc:      	cmp	x8, x21
   11800:      	b.eq	0x118c8 <generic_lsm_path+0x7a78>
   11804:      	mov	w8, #0x4                // =4
   11808:      	add	x9, sp, #0x78
   1180c:      	add	x0, sp, #0x78
   11810:      	mov	w1, #0x8                // =8
   11814:      	mov	x2, x23
   11818:      	blr	x8
   1181c:      	add	x2, x21, #0x20
   11820:      	mov	w8, #0x4                // =4
   11824:      	mov	w9, #0x10               // =16
   11828:      	add	x10, sp, #0x80
   1182c:      	add	x0, sp, #0x80
   11830:      	mov	w1, #0x10               // =16
   11834:      	blr	x8
   11838:      	ldr	w21, [sp, #0x84]
   1183c:      	ldr	x8, [sp, #0x40]
   11840:      	ldr	x10, [sp, #0x60]
   11844:      	sub	x12, x10, x8
   11848:      	ldr	w23, [sp, #0x68]
   1184c:      	subs	w10, w21, w23
   11850:      	ldr	x9, [sp, #0x88]
   11854:      	csel	w10, wzr, w10, lo
   11858:      	cmp	w23, w21
   1185c:      	csel	w11, w23, w21, lo
   11860:      	cinc	w13, w11, hi
   11864:      	sub	w14, w23, w13
   11868:      	subs	x12, x12, x13
   1186c:      	str	w14, [sp, #0x68]
   11870:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11874:      	cmp	x12, #0xfff
   11878:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   1187c:      	cmp	w23, w21
   11880:      	b.ls	0x1188c <generic_lsm_path+0x7a3c>
   11884:      	mov	w13, #0x2f              // =47
   11888:      	strb	w13, [x8, x12]
   1188c:      	add	x19, x8, x12
   11890:      	cmp	w23, w21
   11894:      	add	x2, x9, x10
   11898:      	and	w1, w11, #0xff
   1189c:      	mov	w8, #0x4                // =4
   118a0:      	cinc	x0, x19, hi
   118a4:      	blr	x8
   118a8:      	cmp	w23, w21
   118ac:      	str	x19, [sp, #0x60]
   118b0:      	add	x19, sp, #0x70
   118b4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   118b8:      	ldr	x21, [sp, #0x78]
   118bc:      	ldp	x2, x24, [sp, #0x50]
   118c0:      	str	x21, [sp, #0x48]
   118c4:      	b	0x11914 <generic_lsm_path+0x7ac4>
   118c8:      	add	x2, x24, #0x10
   118cc:      	mov	w8, #0x4                // =4
   118d0:      	add	x9, sp, #0x98
   118d4:      	add	x0, sp, #0x98
   118d8:      	mov	w1, #0x8                // =8
   118dc:      	blr	x8
   118e0:      	ldr	x8, [sp, #0x58]
   118e4:      	ldr	x9, [sp, #0x98]
   118e8:      	cmp	x8, x9
   118ec:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   118f0:      	add	x2, x24, #0x18
   118f4:      	mov	w8, #0x4                // =4
   118f8:      	mov	x0, x22
   118fc:      	mov	w1, #0x8                // =8
   11900:      	blr	x8
   11904:      	ldr	x24, [sp, #0x98]
   11908:      	ldr	x21, [sp, #0x48]
   1190c:      	add	x2, x24, #0x20
   11910:      	stp	x2, x24, [sp, #0x50]
   11914:      	ldr	x8, [sp, #0x30]
   11918:      	cmp	x21, x8
   1191c:      	b.ne	0x1192c <generic_lsm_path+0x7adc>
   11920:      	ldr	x8, [sp, #0x38]
   11924:      	cmp	x2, x8
   11928:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1192c:      	mov	w8, #0x4                // =4
   11930:      	add	x0, sp, #0x70
   11934:      	mov	w1, #0x8                // =8
   11938:      	blr	x8
   1193c:      	ldr	x8, [sp, #0x70]
   11940:      	cmp	x21, x8
   11944:      	b.eq	0x11a34 <generic_lsm_path+0x7be4>
   11948:      	add	x23, x21, #0x18
   1194c:      	mov	w8, #0x4                // =4
   11950:      	add	x9, sp, #0x98
   11954:      	add	x0, sp, #0x98
   11958:      	mov	w1, #0x8                // =8
   1195c:      	mov	x2, x23
   11960:      	blr	x8
   11964:      	ldr	x8, [sp, #0x98]
   11968:      	cmp	x8, x21
   1196c:      	b.eq	0x11a34 <generic_lsm_path+0x7be4>
   11970:      	mov	w8, #0x4                // =4
   11974:      	add	x9, sp, #0x78
   11978:      	add	x0, sp, #0x78
   1197c:      	mov	w1, #0x8                // =8
   11980:      	mov	x2, x23
   11984:      	blr	x8
   11988:      	add	x2, x21, #0x20
   1198c:      	mov	w8, #0x4                // =4
   11990:      	mov	w9, #0x10               // =16
   11994:      	add	x10, sp, #0x80
   11998:      	add	x0, sp, #0x80
   1199c:      	mov	w1, #0x10               // =16
   119a0:      	blr	x8
   119a4:      	ldr	w21, [sp, #0x84]
   119a8:      	ldr	x8, [sp, #0x40]
   119ac:      	ldr	x10, [sp, #0x60]
   119b0:      	sub	x12, x10, x8
   119b4:      	ldr	w23, [sp, #0x68]
   119b8:      	subs	w10, w21, w23
   119bc:      	ldr	x9, [sp, #0x88]
   119c0:      	csel	w10, wzr, w10, lo
   119c4:      	cmp	w23, w21
   119c8:      	csel	w11, w23, w21, lo
   119cc:      	cinc	w13, w11, hi
   119d0:      	sub	w14, w23, w13
   119d4:      	subs	x12, x12, x13
   119d8:      	str	w14, [sp, #0x68]
   119dc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   119e0:      	cmp	x12, #0xfff
   119e4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   119e8:      	cmp	w23, w21
   119ec:      	b.ls	0x119f8 <generic_lsm_path+0x7ba8>
   119f0:      	mov	w13, #0x2f              // =47
   119f4:      	strb	w13, [x8, x12]
   119f8:      	add	x19, x8, x12
   119fc:      	cmp	w23, w21
   11a00:      	add	x2, x9, x10
   11a04:      	and	w1, w11, #0xff
   11a08:      	mov	w8, #0x4                // =4
   11a0c:      	cinc	x0, x19, hi
   11a10:      	blr	x8
   11a14:      	cmp	w23, w21
   11a18:      	str	x19, [sp, #0x60]
   11a1c:      	add	x19, sp, #0x70
   11a20:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11a24:      	ldr	x21, [sp, #0x78]
   11a28:      	ldp	x2, x24, [sp, #0x50]
   11a2c:      	str	x21, [sp, #0x48]
   11a30:      	b	0x11a80 <generic_lsm_path+0x7c30>
   11a34:      	add	x2, x24, #0x10
   11a38:      	mov	w8, #0x4                // =4
   11a3c:      	add	x9, sp, #0x98
   11a40:      	add	x0, sp, #0x98
   11a44:      	mov	w1, #0x8                // =8
   11a48:      	blr	x8
   11a4c:      	ldr	x8, [sp, #0x58]
   11a50:      	ldr	x9, [sp, #0x98]
   11a54:      	cmp	x8, x9
   11a58:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11a5c:      	add	x2, x24, #0x18
   11a60:      	mov	w8, #0x4                // =4
   11a64:      	mov	x0, x22
   11a68:      	mov	w1, #0x8                // =8
   11a6c:      	blr	x8
   11a70:      	ldr	x24, [sp, #0x98]
   11a74:      	ldr	x21, [sp, #0x48]
   11a78:      	add	x2, x24, #0x20
   11a7c:      	stp	x2, x24, [sp, #0x50]
   11a80:      	ldr	x8, [sp, #0x30]
   11a84:      	cmp	x21, x8
   11a88:      	b.ne	0x11a98 <generic_lsm_path+0x7c48>
   11a8c:      	ldr	x8, [sp, #0x38]
   11a90:      	cmp	x2, x8
   11a94:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11a98:      	mov	w8, #0x4                // =4
   11a9c:      	add	x0, sp, #0x70
   11aa0:      	mov	w1, #0x8                // =8
   11aa4:      	blr	x8
   11aa8:      	ldr	x8, [sp, #0x70]
   11aac:      	cmp	x21, x8
   11ab0:      	b.eq	0x11ba0 <generic_lsm_path+0x7d50>
   11ab4:      	add	x23, x21, #0x18
   11ab8:      	mov	w8, #0x4                // =4
   11abc:      	add	x9, sp, #0x98
   11ac0:      	add	x0, sp, #0x98
   11ac4:      	mov	w1, #0x8                // =8
   11ac8:      	mov	x2, x23
   11acc:      	blr	x8
   11ad0:      	ldr	x8, [sp, #0x98]
   11ad4:      	cmp	x8, x21
   11ad8:      	b.eq	0x11ba0 <generic_lsm_path+0x7d50>
   11adc:      	mov	w8, #0x4                // =4
   11ae0:      	add	x9, sp, #0x78
   11ae4:      	add	x0, sp, #0x78
   11ae8:      	mov	w1, #0x8                // =8
   11aec:      	mov	x2, x23
   11af0:      	blr	x8
   11af4:      	add	x2, x21, #0x20
   11af8:      	mov	w8, #0x4                // =4
   11afc:      	mov	w9, #0x10               // =16
   11b00:      	add	x10, sp, #0x80
   11b04:      	add	x0, sp, #0x80
   11b08:      	mov	w1, #0x10               // =16
   11b0c:      	blr	x8
   11b10:      	ldr	w21, [sp, #0x84]
   11b14:      	ldr	x8, [sp, #0x40]
   11b18:      	ldr	x10, [sp, #0x60]
   11b1c:      	sub	x12, x10, x8
   11b20:      	ldr	w23, [sp, #0x68]
   11b24:      	subs	w10, w21, w23
   11b28:      	ldr	x9, [sp, #0x88]
   11b2c:      	csel	w10, wzr, w10, lo
   11b30:      	cmp	w23, w21
   11b34:      	csel	w11, w23, w21, lo
   11b38:      	cinc	w13, w11, hi
   11b3c:      	sub	w14, w23, w13
   11b40:      	subs	x12, x12, x13
   11b44:      	str	w14, [sp, #0x68]
   11b48:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11b4c:      	cmp	x12, #0xfff
   11b50:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11b54:      	cmp	w23, w21
   11b58:      	b.ls	0x11b64 <generic_lsm_path+0x7d14>
   11b5c:      	mov	w13, #0x2f              // =47
   11b60:      	strb	w13, [x8, x12]
   11b64:      	add	x19, x8, x12
   11b68:      	cmp	w23, w21
   11b6c:      	add	x2, x9, x10
   11b70:      	and	w1, w11, #0xff
   11b74:      	mov	w8, #0x4                // =4
   11b78:      	cinc	x0, x19, hi
   11b7c:      	blr	x8
   11b80:      	cmp	w23, w21
   11b84:      	str	x19, [sp, #0x60]
   11b88:      	add	x19, sp, #0x70
   11b8c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11b90:      	ldr	x21, [sp, #0x78]
   11b94:      	ldp	x2, x24, [sp, #0x50]
   11b98:      	str	x21, [sp, #0x48]
   11b9c:      	b	0x11bec <generic_lsm_path+0x7d9c>
   11ba0:      	add	x2, x24, #0x10
   11ba4:      	mov	w8, #0x4                // =4
   11ba8:      	add	x9, sp, #0x98
   11bac:      	add	x0, sp, #0x98
   11bb0:      	mov	w1, #0x8                // =8
   11bb4:      	blr	x8
   11bb8:      	ldr	x8, [sp, #0x58]
   11bbc:      	ldr	x9, [sp, #0x98]
   11bc0:      	cmp	x8, x9
   11bc4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11bc8:      	add	x2, x24, #0x18
   11bcc:      	mov	w8, #0x4                // =4
   11bd0:      	mov	x0, x22
   11bd4:      	mov	w1, #0x8                // =8
   11bd8:      	blr	x8
   11bdc:      	ldr	x24, [sp, #0x98]
   11be0:      	ldr	x21, [sp, #0x48]
   11be4:      	add	x2, x24, #0x20
   11be8:      	stp	x2, x24, [sp, #0x50]
   11bec:      	ldr	x8, [sp, #0x30]
   11bf0:      	cmp	x21, x8
   11bf4:      	b.ne	0x11c04 <generic_lsm_path+0x7db4>
   11bf8:      	ldr	x8, [sp, #0x38]
   11bfc:      	cmp	x2, x8
   11c00:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11c04:      	str	x25, [sp, #0x8]
   11c08:      	mov	w8, #0x4                // =4
   11c0c:      	add	x0, sp, #0x70
   11c10:      	mov	w1, #0x8                // =8
   11c14:      	blr	x8
   11c18:      	ldr	x8, [sp, #0x70]
   11c1c:      	cmp	x21, x8
   11c20:      	b.eq	0x11d14 <generic_lsm_path+0x7ec4>
   11c24:      	add	x23, x21, #0x18
   11c28:      	mov	w8, #0x4                // =4
   11c2c:      	add	x9, sp, #0x98
   11c30:      	add	x0, sp, #0x98
   11c34:      	mov	w1, #0x8                // =8
   11c38:      	mov	x2, x23
   11c3c:      	blr	x8
   11c40:      	ldr	x8, [sp, #0x98]
   11c44:      	cmp	x8, x21
   11c48:      	b.eq	0x11d14 <generic_lsm_path+0x7ec4>
   11c4c:      	mov	w8, #0x4                // =4
   11c50:      	add	x9, sp, #0x78
   11c54:      	add	x0, sp, #0x78
   11c58:      	mov	w1, #0x8                // =8
   11c5c:      	mov	x2, x23
   11c60:      	blr	x8
   11c64:      	add	x2, x21, #0x20
   11c68:      	mov	w8, #0x4                // =4
   11c6c:      	mov	w9, #0x10               // =16
   11c70:      	add	x10, sp, #0x80
   11c74:      	add	x0, sp, #0x80
   11c78:      	mov	w1, #0x10               // =16
   11c7c:      	blr	x8
   11c80:      	ldr	w21, [sp, #0x84]
   11c84:      	ldr	x8, [sp, #0x40]
   11c88:      	ldr	x10, [sp, #0x60]
   11c8c:      	sub	x12, x10, x8
   11c90:      	ldr	w23, [sp, #0x68]
   11c94:      	subs	w10, w21, w23
   11c98:      	ldr	x9, [sp, #0x88]
   11c9c:      	ldr	x25, [sp, #0x8]
   11ca0:      	csel	w10, wzr, w10, lo
   11ca4:      	cmp	w23, w21
   11ca8:      	csel	w11, w23, w21, lo
   11cac:      	cinc	w13, w11, hi
   11cb0:      	sub	w14, w23, w13
   11cb4:      	subs	x12, x12, x13
   11cb8:      	str	w14, [sp, #0x68]
   11cbc:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11cc0:      	cmp	x12, #0xfff
   11cc4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11cc8:      	cmp	w23, w21
   11ccc:      	b.ls	0x11cd8 <generic_lsm_path+0x7e88>
   11cd0:      	mov	w13, #0x2f              // =47
   11cd4:      	strb	w13, [x8, x12]
   11cd8:      	add	x19, x8, x12
   11cdc:      	cmp	w23, w21
   11ce0:      	add	x2, x9, x10
   11ce4:      	and	w1, w11, #0xff
   11ce8:      	mov	w8, #0x4                // =4
   11cec:      	cinc	x0, x19, hi
   11cf0:      	blr	x8
   11cf4:      	ldr	x25, [sp, #0x8]
   11cf8:      	cmp	w23, w21
   11cfc:      	str	x19, [sp, #0x60]
   11d00:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11d04:      	ldr	x21, [sp, #0x78]
   11d08:      	ldp	x2, x24, [sp, #0x50]
   11d0c:      	str	x21, [sp, #0x48]
   11d10:      	b	0x11d64 <generic_lsm_path+0x7f14>
   11d14:      	add	x2, x24, #0x10
   11d18:      	mov	w8, #0x4                // =4
   11d1c:      	add	x9, sp, #0x98
   11d20:      	add	x0, sp, #0x98
   11d24:      	mov	w1, #0x8                // =8
   11d28:      	blr	x8
   11d2c:      	ldr	x8, [sp, #0x58]
   11d30:      	ldr	x9, [sp, #0x98]
   11d34:      	cmp	x8, x9
   11d38:      	ldr	x25, [sp, #0x8]
   11d3c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11d40:      	add	x2, x24, #0x18
   11d44:      	mov	w8, #0x4                // =4
   11d48:      	mov	x0, x22
   11d4c:      	mov	w1, #0x8                // =8
   11d50:      	blr	x8
   11d54:      	ldr	x24, [sp, #0x98]
   11d58:      	ldr	x21, [sp, #0x48]
   11d5c:      	add	x2, x24, #0x20
   11d60:      	stp	x2, x24, [sp, #0x50]
   11d64:      	ldr	x8, [sp, #0x30]
   11d68:      	ldr	x25, [sp, #0x8]
   11d6c:      	add	x9, sp, #0x70
   11d70:      	cmp	x21, x8
   11d74:      	b.ne	0x11d84 <generic_lsm_path+0x7f34>
   11d78:      	ldr	x8, [sp, #0x38]
   11d7c:      	cmp	x2, x8
   11d80:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11d84:      	mov	w8, #0x4                // =4
   11d88:      	add	x0, sp, #0x70
   11d8c:      	mov	w1, #0x8                // =8
   11d90:      	blr	x8
   11d94:      	ldr	x8, [sp, #0x70]
   11d98:      	cmp	x21, x8
   11d9c:      	b.eq	0x11e90 <generic_lsm_path+0x8040>
   11da0:      	add	x23, x21, #0x18
   11da4:      	mov	w8, #0x4                // =4
   11da8:      	add	x9, sp, #0x98
   11dac:      	add	x0, sp, #0x98
   11db0:      	mov	w1, #0x8                // =8
   11db4:      	mov	x2, x23
   11db8:      	blr	x8
   11dbc:      	ldr	x8, [sp, #0x98]
   11dc0:      	cmp	x8, x21
   11dc4:      	b.eq	0x11e90 <generic_lsm_path+0x8040>
   11dc8:      	mov	w8, #0x4                // =4
   11dcc:      	add	x9, sp, #0x78
   11dd0:      	add	x0, sp, #0x78
   11dd4:      	mov	w1, #0x8                // =8
   11dd8:      	mov	x2, x23
   11ddc:      	blr	x8
   11de0:      	add	x2, x21, #0x20
   11de4:      	mov	w8, #0x4                // =4
   11de8:      	mov	w9, #0x10               // =16
   11dec:      	add	x10, sp, #0x80
   11df0:      	add	x0, sp, #0x80
   11df4:      	mov	w1, #0x10               // =16
   11df8:      	blr	x8
   11dfc:      	ldr	w21, [sp, #0x84]
   11e00:      	ldr	x8, [sp, #0x40]
   11e04:      	ldr	x10, [sp, #0x60]
   11e08:      	sub	x12, x10, x8
   11e0c:      	ldr	w23, [sp, #0x68]
   11e10:      	subs	w10, w21, w23
   11e14:      	ldr	x9, [sp, #0x88]
   11e18:      	ldr	x25, [sp, #0x8]
   11e1c:      	csel	w10, wzr, w10, lo
   11e20:      	cmp	w23, w21
   11e24:      	csel	w11, w23, w21, lo
   11e28:      	cinc	w13, w11, hi
   11e2c:      	sub	w14, w23, w13
   11e30:      	subs	x12, x12, x13
   11e34:      	str	w14, [sp, #0x68]
   11e38:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11e3c:      	cmp	x12, #0xfff
   11e40:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11e44:      	cmp	w23, w21
   11e48:      	b.ls	0x11e54 <generic_lsm_path+0x8004>
   11e4c:      	mov	w13, #0x2f              // =47
   11e50:      	strb	w13, [x8, x12]
   11e54:      	add	x19, x8, x12
   11e58:      	cmp	w23, w21
   11e5c:      	add	x2, x9, x10
   11e60:      	and	w1, w11, #0xff
   11e64:      	mov	w8, #0x4                // =4
   11e68:      	cinc	x0, x19, hi
   11e6c:      	blr	x8
   11e70:      	ldr	x25, [sp, #0x8]
   11e74:      	cmp	w23, w21
   11e78:      	str	x19, [sp, #0x60]
   11e7c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11e80:      	ldr	x21, [sp, #0x78]
   11e84:      	ldp	x2, x24, [sp, #0x50]
   11e88:      	str	x21, [sp, #0x48]
   11e8c:      	b	0x11ee0 <generic_lsm_path+0x8090>
   11e90:      	add	x2, x24, #0x10
   11e94:      	mov	w8, #0x4                // =4
   11e98:      	add	x9, sp, #0x98
   11e9c:      	add	x0, sp, #0x98
   11ea0:      	mov	w1, #0x8                // =8
   11ea4:      	blr	x8
   11ea8:      	ldr	x8, [sp, #0x58]
   11eac:      	ldr	x9, [sp, #0x98]
   11eb0:      	cmp	x8, x9
   11eb4:      	ldr	x25, [sp, #0x8]
   11eb8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11ebc:      	add	x2, x24, #0x18
   11ec0:      	mov	w8, #0x4                // =4
   11ec4:      	mov	x0, x22
   11ec8:      	mov	w1, #0x8                // =8
   11ecc:      	blr	x8
   11ed0:      	ldr	x24, [sp, #0x98]
   11ed4:      	ldr	x21, [sp, #0x48]
   11ed8:      	add	x2, x24, #0x20
   11edc:      	stp	x2, x24, [sp, #0x50]
   11ee0:      	ldr	x8, [sp, #0x30]
   11ee4:      	ldr	x25, [sp, #0x8]
   11ee8:      	add	x9, sp, #0x70
   11eec:      	cmp	x21, x8
   11ef0:      	b.ne	0x11f00 <generic_lsm_path+0x80b0>
   11ef4:      	ldr	x8, [sp, #0x38]
   11ef8:      	cmp	x2, x8
   11efc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   11f00:      	mov	w8, #0x4                // =4
   11f04:      	add	x0, sp, #0x70
   11f08:      	mov	w1, #0x8                // =8
   11f0c:      	blr	x8
   11f10:      	ldr	x8, [sp, #0x70]
   11f14:      	cmp	x21, x8
   11f18:      	b.eq	0x1200c <generic_lsm_path+0x81bc>
   11f1c:      	add	x23, x21, #0x18
   11f20:      	mov	w8, #0x4                // =4
   11f24:      	add	x9, sp, #0x98
   11f28:      	add	x0, sp, #0x98
   11f2c:      	mov	w1, #0x8                // =8
   11f30:      	mov	x2, x23
   11f34:      	blr	x8
   11f38:      	ldr	x8, [sp, #0x98]
   11f3c:      	cmp	x8, x21
   11f40:      	b.eq	0x1200c <generic_lsm_path+0x81bc>
   11f44:      	mov	w8, #0x4                // =4
   11f48:      	add	x9, sp, #0x78
   11f4c:      	add	x0, sp, #0x78
   11f50:      	mov	w1, #0x8                // =8
   11f54:      	mov	x2, x23
   11f58:      	blr	x8
   11f5c:      	add	x2, x21, #0x20
   11f60:      	mov	w8, #0x4                // =4
   11f64:      	mov	w9, #0x10               // =16
   11f68:      	add	x10, sp, #0x80
   11f6c:      	add	x0, sp, #0x80
   11f70:      	mov	w1, #0x10               // =16
   11f74:      	blr	x8
   11f78:      	ldr	w21, [sp, #0x84]
   11f7c:      	ldr	x8, [sp, #0x40]
   11f80:      	ldr	x10, [sp, #0x60]
   11f84:      	sub	x12, x10, x8
   11f88:      	ldr	w23, [sp, #0x68]
   11f8c:      	subs	w10, w21, w23
   11f90:      	ldr	x9, [sp, #0x88]
   11f94:      	ldr	x25, [sp, #0x8]
   11f98:      	csel	w10, wzr, w10, lo
   11f9c:      	cmp	w23, w21
   11fa0:      	csel	w11, w23, w21, lo
   11fa4:      	cinc	w13, w11, hi
   11fa8:      	sub	w14, w23, w13
   11fac:      	subs	x12, x12, x13
   11fb0:      	str	w14, [sp, #0x68]
   11fb4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   11fb8:      	cmp	x12, #0xfff
   11fbc:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   11fc0:      	cmp	w23, w21
   11fc4:      	b.ls	0x11fd0 <generic_lsm_path+0x8180>
   11fc8:      	mov	w13, #0x2f              // =47
   11fcc:      	strb	w13, [x8, x12]
   11fd0:      	add	x19, x8, x12
   11fd4:      	cmp	w23, w21
   11fd8:      	add	x2, x9, x10
   11fdc:      	and	w1, w11, #0xff
   11fe0:      	mov	w8, #0x4                // =4
   11fe4:      	cinc	x0, x19, hi
   11fe8:      	blr	x8
   11fec:      	ldr	x25, [sp, #0x8]
   11ff0:      	cmp	w23, w21
   11ff4:      	str	x19, [sp, #0x60]
   11ff8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   11ffc:      	ldr	x21, [sp, #0x78]
   12000:      	ldp	x2, x24, [sp, #0x50]
   12004:      	str	x21, [sp, #0x48]
   12008:      	b	0x1205c <generic_lsm_path+0x820c>
   1200c:      	add	x2, x24, #0x10
   12010:      	mov	w8, #0x4                // =4
   12014:      	add	x9, sp, #0x98
   12018:      	add	x0, sp, #0x98
   1201c:      	mov	w1, #0x8                // =8
   12020:      	blr	x8
   12024:      	ldr	x8, [sp, #0x58]
   12028:      	ldr	x9, [sp, #0x98]
   1202c:      	cmp	x8, x9
   12030:      	ldr	x25, [sp, #0x8]
   12034:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12038:      	add	x2, x24, #0x18
   1203c:      	mov	w8, #0x4                // =4
   12040:      	mov	x0, x22
   12044:      	mov	w1, #0x8                // =8
   12048:      	blr	x8
   1204c:      	ldr	x24, [sp, #0x98]
   12050:      	ldr	x21, [sp, #0x48]
   12054:      	add	x2, x24, #0x20
   12058:      	stp	x2, x24, [sp, #0x50]
   1205c:      	ldr	x8, [sp, #0x30]
   12060:      	ldr	x25, [sp, #0x8]
   12064:      	add	x9, sp, #0x70
   12068:      	cmp	x21, x8
   1206c:      	b.ne	0x1207c <generic_lsm_path+0x822c>
   12070:      	ldr	x8, [sp, #0x38]
   12074:      	cmp	x2, x8
   12078:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1207c:      	mov	w8, #0x4                // =4
   12080:      	add	x0, sp, #0x70
   12084:      	mov	w1, #0x8                // =8
   12088:      	blr	x8
   1208c:      	ldr	x8, [sp, #0x70]
   12090:      	cmp	x21, x8
   12094:      	b.eq	0x12188 <generic_lsm_path+0x8338>
   12098:      	add	x23, x21, #0x18
   1209c:      	mov	w8, #0x4                // =4
   120a0:      	add	x9, sp, #0x98
   120a4:      	add	x0, sp, #0x98
   120a8:      	mov	w1, #0x8                // =8
   120ac:      	mov	x2, x23
   120b0:      	blr	x8
   120b4:      	ldr	x8, [sp, #0x98]
   120b8:      	cmp	x8, x21
   120bc:      	b.eq	0x12188 <generic_lsm_path+0x8338>
   120c0:      	mov	w8, #0x4                // =4
   120c4:      	add	x9, sp, #0x78
   120c8:      	add	x0, sp, #0x78
   120cc:      	mov	w1, #0x8                // =8
   120d0:      	mov	x2, x23
   120d4:      	blr	x8
   120d8:      	add	x2, x21, #0x20
   120dc:      	mov	w8, #0x4                // =4
   120e0:      	mov	w9, #0x10               // =16
   120e4:      	add	x10, sp, #0x80
   120e8:      	add	x0, sp, #0x80
   120ec:      	mov	w1, #0x10               // =16
   120f0:      	blr	x8
   120f4:      	ldr	w21, [sp, #0x84]
   120f8:      	ldr	x8, [sp, #0x40]
   120fc:      	ldr	x10, [sp, #0x60]
   12100:      	sub	x12, x10, x8
   12104:      	ldr	w23, [sp, #0x68]
   12108:      	subs	w10, w21, w23
   1210c:      	ldr	x9, [sp, #0x88]
   12110:      	ldr	x25, [sp, #0x8]
   12114:      	csel	w10, wzr, w10, lo
   12118:      	cmp	w23, w21
   1211c:      	csel	w11, w23, w21, lo
   12120:      	cinc	w13, w11, hi
   12124:      	sub	w14, w23, w13
   12128:      	subs	x12, x12, x13
   1212c:      	str	w14, [sp, #0x68]
   12130:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   12134:      	cmp	x12, #0xfff
   12138:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   1213c:      	cmp	w23, w21
   12140:      	b.ls	0x1214c <generic_lsm_path+0x82fc>
   12144:      	mov	w13, #0x2f              // =47
   12148:      	strb	w13, [x8, x12]
   1214c:      	add	x19, x8, x12
   12150:      	cmp	w23, w21
   12154:      	add	x2, x9, x10
   12158:      	and	w1, w11, #0xff
   1215c:      	mov	w8, #0x4                // =4
   12160:      	cinc	x0, x19, hi
   12164:      	blr	x8
   12168:      	ldr	x25, [sp, #0x8]
   1216c:      	cmp	w23, w21
   12170:      	str	x19, [sp, #0x60]
   12174:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12178:      	ldr	x21, [sp, #0x78]
   1217c:      	ldp	x2, x24, [sp, #0x50]
   12180:      	str	x21, [sp, #0x48]
   12184:      	b	0x121d8 <generic_lsm_path+0x8388>
   12188:      	add	x2, x24, #0x10
   1218c:      	mov	w8, #0x4                // =4
   12190:      	add	x9, sp, #0x98
   12194:      	add	x0, sp, #0x98
   12198:      	mov	w1, #0x8                // =8
   1219c:      	blr	x8
   121a0:      	ldr	x8, [sp, #0x58]
   121a4:      	ldr	x9, [sp, #0x98]
   121a8:      	cmp	x8, x9
   121ac:      	ldr	x25, [sp, #0x8]
   121b0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   121b4:      	add	x2, x24, #0x18
   121b8:      	mov	w8, #0x4                // =4
   121bc:      	mov	x0, x22
   121c0:      	mov	w1, #0x8                // =8
   121c4:      	blr	x8
   121c8:      	ldr	x24, [sp, #0x98]
   121cc:      	ldr	x21, [sp, #0x48]
   121d0:      	add	x2, x24, #0x20
   121d4:      	stp	x2, x24, [sp, #0x50]
   121d8:      	ldr	x8, [sp, #0x30]
   121dc:      	ldr	x25, [sp, #0x8]
   121e0:      	add	x9, sp, #0x70
   121e4:      	cmp	x21, x8
   121e8:      	b.ne	0x121f8 <generic_lsm_path+0x83a8>
   121ec:      	ldr	x8, [sp, #0x38]
   121f0:      	cmp	x2, x8
   121f4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   121f8:      	mov	w8, #0x4                // =4
   121fc:      	add	x0, sp, #0x70
   12200:      	mov	w1, #0x8                // =8
   12204:      	blr	x8
   12208:      	ldr	x8, [sp, #0x70]
   1220c:      	cmp	x21, x8
   12210:      	b.eq	0x12304 <generic_lsm_path+0x84b4>
   12214:      	add	x23, x21, #0x18
   12218:      	mov	w8, #0x4                // =4
   1221c:      	add	x9, sp, #0x98
   12220:      	add	x0, sp, #0x98
   12224:      	mov	w1, #0x8                // =8
   12228:      	mov	x2, x23
   1222c:      	blr	x8
   12230:      	ldr	x8, [sp, #0x98]
   12234:      	cmp	x8, x21
   12238:      	b.eq	0x12304 <generic_lsm_path+0x84b4>
   1223c:      	mov	w8, #0x4                // =4
   12240:      	add	x9, sp, #0x78
   12244:      	add	x0, sp, #0x78
   12248:      	mov	w1, #0x8                // =8
   1224c:      	mov	x2, x23
   12250:      	blr	x8
   12254:      	add	x2, x21, #0x20
   12258:      	mov	w8, #0x4                // =4
   1225c:      	mov	w9, #0x10               // =16
   12260:      	add	x10, sp, #0x80
   12264:      	add	x0, sp, #0x80
   12268:      	mov	w1, #0x10               // =16
   1226c:      	blr	x8
   12270:      	ldr	w21, [sp, #0x84]
   12274:      	ldr	x8, [sp, #0x40]
   12278:      	ldr	x10, [sp, #0x60]
   1227c:      	sub	x12, x10, x8
   12280:      	ldr	w23, [sp, #0x68]
   12284:      	subs	w10, w21, w23
   12288:      	ldr	x9, [sp, #0x88]
   1228c:      	ldr	x25, [sp, #0x8]
   12290:      	csel	w10, wzr, w10, lo
   12294:      	cmp	w23, w21
   12298:      	csel	w11, w23, w21, lo
   1229c:      	cinc	w13, w11, hi
   122a0:      	sub	w14, w23, w13
   122a4:      	subs	x12, x12, x13
   122a8:      	str	w14, [sp, #0x68]
   122ac:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   122b0:      	cmp	x12, #0xfff
   122b4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   122b8:      	cmp	w23, w21
   122bc:      	b.ls	0x122c8 <generic_lsm_path+0x8478>
   122c0:      	mov	w13, #0x2f              // =47
   122c4:      	strb	w13, [x8, x12]
   122c8:      	add	x19, x8, x12
   122cc:      	cmp	w23, w21
   122d0:      	add	x2, x9, x10
   122d4:      	and	w1, w11, #0xff
   122d8:      	mov	w8, #0x4                // =4
   122dc:      	cinc	x0, x19, hi
   122e0:      	blr	x8
   122e4:      	ldr	x25, [sp, #0x8]
   122e8:      	cmp	w23, w21
   122ec:      	str	x19, [sp, #0x60]
   122f0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   122f4:      	ldr	x21, [sp, #0x78]
   122f8:      	ldp	x2, x24, [sp, #0x50]
   122fc:      	str	x21, [sp, #0x48]
   12300:      	b	0x12354 <generic_lsm_path+0x8504>
   12304:      	add	x2, x24, #0x10
   12308:      	mov	w8, #0x4                // =4
   1230c:      	add	x9, sp, #0x98
   12310:      	add	x0, sp, #0x98
   12314:      	mov	w1, #0x8                // =8
   12318:      	blr	x8
   1231c:      	ldr	x8, [sp, #0x58]
   12320:      	ldr	x9, [sp, #0x98]
   12324:      	cmp	x8, x9
   12328:      	ldr	x25, [sp, #0x8]
   1232c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12330:      	add	x2, x24, #0x18
   12334:      	mov	w8, #0x4                // =4
   12338:      	mov	x0, x22
   1233c:      	mov	w1, #0x8                // =8
   12340:      	blr	x8
   12344:      	ldr	x24, [sp, #0x98]
   12348:      	ldr	x21, [sp, #0x48]
   1234c:      	add	x2, x24, #0x20
   12350:      	stp	x2, x24, [sp, #0x50]
   12354:      	ldr	x8, [sp, #0x30]
   12358:      	ldr	x25, [sp, #0x8]
   1235c:      	add	x9, sp, #0x70
   12360:      	cmp	x21, x8
   12364:      	b.ne	0x12374 <generic_lsm_path+0x8524>
   12368:      	ldr	x8, [sp, #0x38]
   1236c:      	cmp	x2, x8
   12370:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12374:      	mov	w8, #0x4                // =4
   12378:      	add	x0, sp, #0x70
   1237c:      	mov	w1, #0x8                // =8
   12380:      	blr	x8
   12384:      	ldr	x8, [sp, #0x70]
   12388:      	cmp	x21, x8
   1238c:      	b.eq	0x12480 <generic_lsm_path+0x8630>
   12390:      	add	x23, x21, #0x18
   12394:      	mov	w8, #0x4                // =4
   12398:      	add	x9, sp, #0x98
   1239c:      	add	x0, sp, #0x98
   123a0:      	mov	w1, #0x8                // =8
   123a4:      	mov	x2, x23
   123a8:      	blr	x8
   123ac:      	ldr	x8, [sp, #0x98]
   123b0:      	cmp	x8, x21
   123b4:      	b.eq	0x12480 <generic_lsm_path+0x8630>
   123b8:      	mov	w8, #0x4                // =4
   123bc:      	add	x9, sp, #0x78
   123c0:      	add	x0, sp, #0x78
   123c4:      	mov	w1, #0x8                // =8
   123c8:      	mov	x2, x23
   123cc:      	blr	x8
   123d0:      	add	x2, x21, #0x20
   123d4:      	mov	w8, #0x4                // =4
   123d8:      	mov	w9, #0x10               // =16
   123dc:      	add	x10, sp, #0x80
   123e0:      	add	x0, sp, #0x80
   123e4:      	mov	w1, #0x10               // =16
   123e8:      	blr	x8
   123ec:      	ldr	w21, [sp, #0x84]
   123f0:      	ldr	x8, [sp, #0x40]
   123f4:      	ldr	x10, [sp, #0x60]
   123f8:      	sub	x12, x10, x8
   123fc:      	ldr	w23, [sp, #0x68]
   12400:      	subs	w10, w21, w23
   12404:      	ldr	x9, [sp, #0x88]
   12408:      	ldr	x25, [sp, #0x8]
   1240c:      	csel	w10, wzr, w10, lo
   12410:      	cmp	w23, w21
   12414:      	csel	w11, w23, w21, lo
   12418:      	cinc	w13, w11, hi
   1241c:      	sub	w14, w23, w13
   12420:      	subs	x12, x12, x13
   12424:      	str	w14, [sp, #0x68]
   12428:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   1242c:      	cmp	x12, #0xfff
   12430:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   12434:      	cmp	w23, w21
   12438:      	b.ls	0x12444 <generic_lsm_path+0x85f4>
   1243c:      	mov	w13, #0x2f              // =47
   12440:      	strb	w13, [x8, x12]
   12444:      	add	x19, x8, x12
   12448:      	cmp	w23, w21
   1244c:      	add	x2, x9, x10
   12450:      	and	w1, w11, #0xff
   12454:      	mov	w8, #0x4                // =4
   12458:      	cinc	x0, x19, hi
   1245c:      	blr	x8
   12460:      	ldr	x25, [sp, #0x8]
   12464:      	cmp	w23, w21
   12468:      	str	x19, [sp, #0x60]
   1246c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12470:      	ldr	x21, [sp, #0x78]
   12474:      	ldp	x2, x24, [sp, #0x50]
   12478:      	str	x21, [sp, #0x48]
   1247c:      	b	0x124d0 <generic_lsm_path+0x8680>
   12480:      	add	x2, x24, #0x10
   12484:      	mov	w8, #0x4                // =4
   12488:      	add	x9, sp, #0x98
   1248c:      	add	x0, sp, #0x98
   12490:      	mov	w1, #0x8                // =8
   12494:      	blr	x8
   12498:      	ldr	x8, [sp, #0x58]
   1249c:      	ldr	x9, [sp, #0x98]
   124a0:      	cmp	x8, x9
   124a4:      	ldr	x25, [sp, #0x8]
   124a8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   124ac:      	add	x2, x24, #0x18
   124b0:      	mov	w8, #0x4                // =4
   124b4:      	mov	x0, x22
   124b8:      	mov	w1, #0x8                // =8
   124bc:      	blr	x8
   124c0:      	ldr	x24, [sp, #0x98]
   124c4:      	ldr	x21, [sp, #0x48]
   124c8:      	add	x2, x24, #0x20
   124cc:      	stp	x2, x24, [sp, #0x50]
   124d0:      	ldr	x8, [sp, #0x30]
   124d4:      	ldr	x25, [sp, #0x8]
   124d8:      	add	x9, sp, #0x70
   124dc:      	cmp	x21, x8
   124e0:      	b.ne	0x124f0 <generic_lsm_path+0x86a0>
   124e4:      	ldr	x8, [sp, #0x38]
   124e8:      	cmp	x2, x8
   124ec:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   124f0:      	mov	w8, #0x4                // =4
   124f4:      	add	x0, sp, #0x70
   124f8:      	mov	w1, #0x8                // =8
   124fc:      	blr	x8
   12500:      	ldr	x8, [sp, #0x70]
   12504:      	cmp	x21, x8
   12508:      	b.eq	0x125fc <generic_lsm_path+0x87ac>
   1250c:      	add	x23, x21, #0x18
   12510:      	mov	w8, #0x4                // =4
   12514:      	add	x9, sp, #0x98
   12518:      	add	x0, sp, #0x98
   1251c:      	mov	w1, #0x8                // =8
   12520:      	mov	x2, x23
   12524:      	blr	x8
   12528:      	ldr	x8, [sp, #0x98]
   1252c:      	cmp	x8, x21
   12530:      	b.eq	0x125fc <generic_lsm_path+0x87ac>
   12534:      	mov	w8, #0x4                // =4
   12538:      	add	x9, sp, #0x78
   1253c:      	add	x0, sp, #0x78
   12540:      	mov	w1, #0x8                // =8
   12544:      	mov	x2, x23
   12548:      	blr	x8
   1254c:      	add	x2, x21, #0x20
   12550:      	mov	w8, #0x4                // =4
   12554:      	mov	w9, #0x10               // =16
   12558:      	add	x10, sp, #0x80
   1255c:      	add	x0, sp, #0x80
   12560:      	mov	w1, #0x10               // =16
   12564:      	blr	x8
   12568:      	ldr	w21, [sp, #0x84]
   1256c:      	ldr	x8, [sp, #0x40]
   12570:      	ldr	x10, [sp, #0x60]
   12574:      	sub	x12, x10, x8
   12578:      	ldr	w23, [sp, #0x68]
   1257c:      	subs	w10, w21, w23
   12580:      	ldr	x9, [sp, #0x88]
   12584:      	ldr	x25, [sp, #0x8]
   12588:      	csel	w10, wzr, w10, lo
   1258c:      	cmp	w23, w21
   12590:      	csel	w11, w23, w21, lo
   12594:      	cinc	w13, w11, hi
   12598:      	sub	w14, w23, w13
   1259c:      	subs	x12, x12, x13
   125a0:      	str	w14, [sp, #0x68]
   125a4:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   125a8:      	cmp	x12, #0xfff
   125ac:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   125b0:      	cmp	w23, w21
   125b4:      	b.ls	0x125c0 <generic_lsm_path+0x8770>
   125b8:      	mov	w13, #0x2f              // =47
   125bc:      	strb	w13, [x8, x12]
   125c0:      	add	x19, x8, x12
   125c4:      	cmp	w23, w21
   125c8:      	add	x2, x9, x10
   125cc:      	and	w1, w11, #0xff
   125d0:      	mov	w8, #0x4                // =4
   125d4:      	cinc	x0, x19, hi
   125d8:      	blr	x8
   125dc:      	ldr	x25, [sp, #0x8]
   125e0:      	cmp	w23, w21
   125e4:      	str	x19, [sp, #0x60]
   125e8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   125ec:      	ldr	x21, [sp, #0x78]
   125f0:      	ldp	x2, x24, [sp, #0x50]
   125f4:      	str	x21, [sp, #0x48]
   125f8:      	b	0x1264c <generic_lsm_path+0x87fc>
   125fc:      	add	x2, x24, #0x10
   12600:      	mov	w8, #0x4                // =4
   12604:      	add	x9, sp, #0x98
   12608:      	add	x0, sp, #0x98
   1260c:      	mov	w1, #0x8                // =8
   12610:      	blr	x8
   12614:      	ldr	x8, [sp, #0x58]
   12618:      	ldr	x9, [sp, #0x98]
   1261c:      	cmp	x8, x9
   12620:      	ldr	x25, [sp, #0x8]
   12624:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12628:      	add	x2, x24, #0x18
   1262c:      	mov	w8, #0x4                // =4
   12630:      	mov	x0, x22
   12634:      	mov	w1, #0x8                // =8
   12638:      	blr	x8
   1263c:      	ldr	x24, [sp, #0x98]
   12640:      	ldr	x21, [sp, #0x48]
   12644:      	add	x2, x24, #0x20
   12648:      	stp	x2, x24, [sp, #0x50]
   1264c:      	ldr	x8, [sp, #0x30]
   12650:      	ldr	x25, [sp, #0x8]
   12654:      	add	x9, sp, #0x70
   12658:      	cmp	x21, x8
   1265c:      	b.ne	0x1266c <generic_lsm_path+0x881c>
   12660:      	ldr	x8, [sp, #0x38]
   12664:      	cmp	x2, x8
   12668:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1266c:      	mov	w8, #0x4                // =4
   12670:      	add	x0, sp, #0x70
   12674:      	mov	w1, #0x8                // =8
   12678:      	blr	x8
   1267c:      	ldr	x8, [sp, #0x70]
   12680:      	cmp	x21, x8
   12684:      	b.eq	0x12778 <generic_lsm_path+0x8928>
   12688:      	add	x23, x21, #0x18
   1268c:      	mov	w8, #0x4                // =4
   12690:      	add	x9, sp, #0x98
   12694:      	add	x0, sp, #0x98
   12698:      	mov	w1, #0x8                // =8
   1269c:      	mov	x2, x23
   126a0:      	blr	x8
   126a4:      	ldr	x8, [sp, #0x98]
   126a8:      	cmp	x8, x21
   126ac:      	b.eq	0x12778 <generic_lsm_path+0x8928>
   126b0:      	mov	w8, #0x4                // =4
   126b4:      	add	x9, sp, #0x78
   126b8:      	add	x0, sp, #0x78
   126bc:      	mov	w1, #0x8                // =8
   126c0:      	mov	x2, x23
   126c4:      	blr	x8
   126c8:      	add	x2, x21, #0x20
   126cc:      	mov	w8, #0x4                // =4
   126d0:      	mov	w9, #0x10               // =16
   126d4:      	add	x10, sp, #0x80
   126d8:      	add	x0, sp, #0x80
   126dc:      	mov	w1, #0x10               // =16
   126e0:      	blr	x8
   126e4:      	ldr	w21, [sp, #0x84]
   126e8:      	ldr	x8, [sp, #0x40]
   126ec:      	ldr	x10, [sp, #0x60]
   126f0:      	sub	x12, x10, x8
   126f4:      	ldr	w23, [sp, #0x68]
   126f8:      	subs	w10, w21, w23
   126fc:      	ldr	x9, [sp, #0x88]
   12700:      	ldr	x25, [sp, #0x8]
   12704:      	csel	w10, wzr, w10, lo
   12708:      	cmp	w23, w21
   1270c:      	csel	w11, w23, w21, lo
   12710:      	cinc	w13, w11, hi
   12714:      	sub	w14, w23, w13
   12718:      	subs	x12, x12, x13
   1271c:      	str	w14, [sp, #0x68]
   12720:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   12724:      	cmp	x12, #0xfff
   12728:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   1272c:      	cmp	w23, w21
   12730:      	b.ls	0x1273c <generic_lsm_path+0x88ec>
   12734:      	mov	w13, #0x2f              // =47
   12738:      	strb	w13, [x8, x12]
   1273c:      	add	x19, x8, x12
   12740:      	cmp	w23, w21
   12744:      	add	x2, x9, x10
   12748:      	and	w1, w11, #0xff
   1274c:      	mov	w8, #0x4                // =4
   12750:      	cinc	x0, x19, hi
   12754:      	blr	x8
   12758:      	ldr	x25, [sp, #0x8]
   1275c:      	cmp	w23, w21
   12760:      	str	x19, [sp, #0x60]
   12764:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12768:      	ldr	x21, [sp, #0x78]
   1276c:      	ldp	x2, x24, [sp, #0x50]
   12770:      	str	x21, [sp, #0x48]
   12774:      	b	0x127c8 <generic_lsm_path+0x8978>
   12778:      	add	x2, x24, #0x10
   1277c:      	mov	w8, #0x4                // =4
   12780:      	add	x9, sp, #0x98
   12784:      	add	x0, sp, #0x98
   12788:      	mov	w1, #0x8                // =8
   1278c:      	blr	x8
   12790:      	ldr	x8, [sp, #0x58]
   12794:      	ldr	x9, [sp, #0x98]
   12798:      	cmp	x8, x9
   1279c:      	ldr	x25, [sp, #0x8]
   127a0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   127a4:      	add	x2, x24, #0x18
   127a8:      	mov	w8, #0x4                // =4
   127ac:      	mov	x0, x22
   127b0:      	mov	w1, #0x8                // =8
   127b4:      	blr	x8
   127b8:      	ldr	x24, [sp, #0x98]
   127bc:      	ldr	x21, [sp, #0x48]
   127c0:      	add	x2, x24, #0x20
   127c4:      	stp	x2, x24, [sp, #0x50]
   127c8:      	ldr	x8, [sp, #0x30]
   127cc:      	ldr	x25, [sp, #0x8]
   127d0:      	add	x9, sp, #0x70
   127d4:      	cmp	x21, x8
   127d8:      	b.ne	0x127e8 <generic_lsm_path+0x8998>
   127dc:      	ldr	x8, [sp, #0x38]
   127e0:      	cmp	x2, x8
   127e4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   127e8:      	mov	w8, #0x4                // =4
   127ec:      	add	x0, sp, #0x70
   127f0:      	mov	w1, #0x8                // =8
   127f4:      	blr	x8
   127f8:      	ldr	x8, [sp, #0x70]
   127fc:      	cmp	x21, x8
   12800:      	b.eq	0x128f4 <generic_lsm_path+0x8aa4>
   12804:      	add	x23, x21, #0x18
   12808:      	mov	w8, #0x4                // =4
   1280c:      	add	x9, sp, #0x98
   12810:      	add	x0, sp, #0x98
   12814:      	mov	w1, #0x8                // =8
   12818:      	mov	x2, x23
   1281c:      	blr	x8
   12820:      	ldr	x8, [sp, #0x98]
   12824:      	cmp	x8, x21
   12828:      	b.eq	0x128f4 <generic_lsm_path+0x8aa4>
   1282c:      	mov	w8, #0x4                // =4
   12830:      	add	x9, sp, #0x78
   12834:      	add	x0, sp, #0x78
   12838:      	mov	w1, #0x8                // =8
   1283c:      	mov	x2, x23
   12840:      	blr	x8
   12844:      	add	x2, x21, #0x20
   12848:      	mov	w8, #0x4                // =4
   1284c:      	mov	w9, #0x10               // =16
   12850:      	add	x10, sp, #0x80
   12854:      	add	x0, sp, #0x80
   12858:      	mov	w1, #0x10               // =16
   1285c:      	blr	x8
   12860:      	ldr	w21, [sp, #0x84]
   12864:      	ldr	x8, [sp, #0x40]
   12868:      	ldr	x10, [sp, #0x60]
   1286c:      	sub	x12, x10, x8
   12870:      	ldr	w23, [sp, #0x68]
   12874:      	subs	w10, w21, w23
   12878:      	ldr	x9, [sp, #0x88]
   1287c:      	ldr	x25, [sp, #0x8]
   12880:      	csel	w10, wzr, w10, lo
   12884:      	cmp	w23, w21
   12888:      	csel	w11, w23, w21, lo
   1288c:      	cinc	w13, w11, hi
   12890:      	sub	w14, w23, w13
   12894:      	subs	x12, x12, x13
   12898:      	str	w14, [sp, #0x68]
   1289c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   128a0:      	cmp	x12, #0xfff
   128a4:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   128a8:      	cmp	w23, w21
   128ac:      	b.ls	0x128b8 <generic_lsm_path+0x8a68>
   128b0:      	mov	w13, #0x2f              // =47
   128b4:      	strb	w13, [x8, x12]
   128b8:      	add	x19, x8, x12
   128bc:      	cmp	w23, w21
   128c0:      	add	x2, x9, x10
   128c4:      	and	w1, w11, #0xff
   128c8:      	mov	w8, #0x4                // =4
   128cc:      	cinc	x0, x19, hi
   128d0:      	blr	x8
   128d4:      	ldr	x25, [sp, #0x8]
   128d8:      	cmp	w23, w21
   128dc:      	str	x19, [sp, #0x60]
   128e0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   128e4:      	ldr	x21, [sp, #0x78]
   128e8:      	ldp	x2, x24, [sp, #0x50]
   128ec:      	str	x21, [sp, #0x48]
   128f0:      	b	0x12944 <generic_lsm_path+0x8af4>
   128f4:      	add	x2, x24, #0x10
   128f8:      	mov	w8, #0x4                // =4
   128fc:      	add	x9, sp, #0x98
   12900:      	add	x0, sp, #0x98
   12904:      	mov	w1, #0x8                // =8
   12908:      	blr	x8
   1290c:      	ldr	x8, [sp, #0x58]
   12910:      	ldr	x9, [sp, #0x98]
   12914:      	cmp	x8, x9
   12918:      	ldr	x25, [sp, #0x8]
   1291c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12920:      	add	x2, x24, #0x18
   12924:      	mov	w8, #0x4                // =4
   12928:      	mov	x0, x22
   1292c:      	mov	w1, #0x8                // =8
   12930:      	blr	x8
   12934:      	ldr	x24, [sp, #0x98]
   12938:      	ldr	x21, [sp, #0x48]
   1293c:      	add	x2, x24, #0x20
   12940:      	stp	x2, x24, [sp, #0x50]
   12944:      	ldr	x8, [sp, #0x30]
   12948:      	ldr	x25, [sp, #0x8]
   1294c:      	add	x9, sp, #0x70
   12950:      	cmp	x21, x8
   12954:      	b.ne	0x12964 <generic_lsm_path+0x8b14>
   12958:      	ldr	x8, [sp, #0x38]
   1295c:      	cmp	x2, x8
   12960:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12964:      	mov	w8, #0x4                // =4
   12968:      	add	x0, sp, #0x70
   1296c:      	mov	w1, #0x8                // =8
   12970:      	blr	x8
   12974:      	ldr	x8, [sp, #0x70]
   12978:      	cmp	x21, x8
   1297c:      	b.eq	0x12a70 <generic_lsm_path+0x8c20>
   12980:      	add	x23, x21, #0x18
   12984:      	mov	w8, #0x4                // =4
   12988:      	add	x9, sp, #0x98
   1298c:      	add	x0, sp, #0x98
   12990:      	mov	w1, #0x8                // =8
   12994:      	mov	x2, x23
   12998:      	blr	x8
   1299c:      	ldr	x8, [sp, #0x98]
   129a0:      	cmp	x8, x21
   129a4:      	b.eq	0x12a70 <generic_lsm_path+0x8c20>
   129a8:      	mov	w8, #0x4                // =4
   129ac:      	add	x9, sp, #0x78
   129b0:      	add	x0, sp, #0x78
   129b4:      	mov	w1, #0x8                // =8
   129b8:      	mov	x2, x23
   129bc:      	blr	x8
   129c0:      	add	x2, x21, #0x20
   129c4:      	mov	w8, #0x4                // =4
   129c8:      	mov	w9, #0x10               // =16
   129cc:      	add	x10, sp, #0x80
   129d0:      	add	x0, sp, #0x80
   129d4:      	mov	w1, #0x10               // =16
   129d8:      	blr	x8
   129dc:      	ldr	w21, [sp, #0x84]
   129e0:      	ldr	x8, [sp, #0x40]
   129e4:      	ldr	x10, [sp, #0x60]
   129e8:      	sub	x12, x10, x8
   129ec:      	ldr	w23, [sp, #0x68]
   129f0:      	subs	w10, w21, w23
   129f4:      	ldr	x9, [sp, #0x88]
   129f8:      	ldr	x25, [sp, #0x8]
   129fc:      	csel	w10, wzr, w10, lo
   12a00:      	cmp	w23, w21
   12a04:      	csel	w11, w23, w21, lo
   12a08:      	cinc	w13, w11, hi
   12a0c:      	sub	w14, w23, w13
   12a10:      	subs	x12, x12, x13
   12a14:      	str	w14, [sp, #0x68]
   12a18:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   12a1c:      	cmp	x12, #0xfff
   12a20:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   12a24:      	cmp	w23, w21
   12a28:      	b.ls	0x12a34 <generic_lsm_path+0x8be4>
   12a2c:      	mov	w13, #0x2f              // =47
   12a30:      	strb	w13, [x8, x12]
   12a34:      	add	x19, x8, x12
   12a38:      	cmp	w23, w21
   12a3c:      	add	x2, x9, x10
   12a40:      	and	w1, w11, #0xff
   12a44:      	mov	w8, #0x4                // =4
   12a48:      	cinc	x0, x19, hi
   12a4c:      	blr	x8
   12a50:      	ldr	x25, [sp, #0x8]
   12a54:      	cmp	w23, w21
   12a58:      	str	x19, [sp, #0x60]
   12a5c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12a60:      	ldr	x21, [sp, #0x78]
   12a64:      	ldp	x2, x24, [sp, #0x50]
   12a68:      	str	x21, [sp, #0x48]
   12a6c:      	b	0x12ac0 <generic_lsm_path+0x8c70>
   12a70:      	add	x2, x24, #0x10
   12a74:      	mov	w8, #0x4                // =4
   12a78:      	add	x9, sp, #0x98
   12a7c:      	add	x0, sp, #0x98
   12a80:      	mov	w1, #0x8                // =8
   12a84:      	blr	x8
   12a88:      	ldr	x8, [sp, #0x58]
   12a8c:      	ldr	x9, [sp, #0x98]
   12a90:      	cmp	x8, x9
   12a94:      	ldr	x25, [sp, #0x8]
   12a98:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12a9c:      	add	x2, x24, #0x18
   12aa0:      	mov	w8, #0x4                // =4
   12aa4:      	mov	x0, x22
   12aa8:      	mov	w1, #0x8                // =8
   12aac:      	blr	x8
   12ab0:      	ldr	x24, [sp, #0x98]
   12ab4:      	ldr	x21, [sp, #0x48]
   12ab8:      	add	x2, x24, #0x20
   12abc:      	stp	x2, x24, [sp, #0x50]
   12ac0:      	ldr	x8, [sp, #0x30]
   12ac4:      	ldr	x25, [sp, #0x8]
   12ac8:      	add	x9, sp, #0x70
   12acc:      	cmp	x21, x8
   12ad0:      	b.ne	0x12ae0 <generic_lsm_path+0x8c90>
   12ad4:      	ldr	x8, [sp, #0x38]
   12ad8:      	cmp	x2, x8
   12adc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12ae0:      	mov	w8, #0x4                // =4
   12ae4:      	add	x0, sp, #0x70
   12ae8:      	mov	w1, #0x8                // =8
   12aec:      	blr	x8
   12af0:      	ldr	x8, [sp, #0x70]
   12af4:      	cmp	x21, x8
   12af8:      	b.eq	0x12bec <generic_lsm_path+0x8d9c>
   12afc:      	add	x23, x21, #0x18
   12b00:      	mov	w8, #0x4                // =4
   12b04:      	add	x9, sp, #0x98
   12b08:      	add	x0, sp, #0x98
   12b0c:      	mov	w1, #0x8                // =8
   12b10:      	mov	x2, x23
   12b14:      	blr	x8
   12b18:      	ldr	x8, [sp, #0x98]
   12b1c:      	cmp	x8, x21
   12b20:      	b.eq	0x12bec <generic_lsm_path+0x8d9c>
   12b24:      	mov	w8, #0x4                // =4
   12b28:      	add	x9, sp, #0x78
   12b2c:      	add	x0, sp, #0x78
   12b30:      	mov	w1, #0x8                // =8
   12b34:      	mov	x2, x23
   12b38:      	blr	x8
   12b3c:      	add	x2, x21, #0x20
   12b40:      	mov	w8, #0x4                // =4
   12b44:      	mov	w9, #0x10               // =16
   12b48:      	add	x10, sp, #0x80
   12b4c:      	add	x0, sp, #0x80
   12b50:      	mov	w1, #0x10               // =16
   12b54:      	blr	x8
   12b58:      	ldr	w21, [sp, #0x84]
   12b5c:      	ldr	x8, [sp, #0x40]
   12b60:      	ldr	x10, [sp, #0x60]
   12b64:      	sub	x12, x10, x8
   12b68:      	ldr	w23, [sp, #0x68]
   12b6c:      	subs	w10, w21, w23
   12b70:      	ldr	x9, [sp, #0x88]
   12b74:      	ldr	x25, [sp, #0x8]
   12b78:      	csel	w10, wzr, w10, lo
   12b7c:      	cmp	w23, w21
   12b80:      	csel	w11, w23, w21, lo
   12b84:      	cinc	w13, w11, hi
   12b88:      	sub	w14, w23, w13
   12b8c:      	subs	x12, x12, x13
   12b90:      	str	w14, [sp, #0x68]
   12b94:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   12b98:      	cmp	x12, #0xfff
   12b9c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   12ba0:      	cmp	w23, w21
   12ba4:      	b.ls	0x12bb0 <generic_lsm_path+0x8d60>
   12ba8:      	mov	w13, #0x2f              // =47
   12bac:      	strb	w13, [x8, x12]
   12bb0:      	add	x19, x8, x12
   12bb4:      	cmp	w23, w21
   12bb8:      	add	x2, x9, x10
   12bbc:      	and	w1, w11, #0xff
   12bc0:      	mov	w8, #0x4                // =4
   12bc4:      	cinc	x0, x19, hi
   12bc8:      	blr	x8
   12bcc:      	ldr	x25, [sp, #0x8]
   12bd0:      	cmp	w23, w21
   12bd4:      	str	x19, [sp, #0x60]
   12bd8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12bdc:      	ldr	x21, [sp, #0x78]
   12be0:      	ldp	x2, x24, [sp, #0x50]
   12be4:      	str	x21, [sp, #0x48]
   12be8:      	b	0x12c3c <generic_lsm_path+0x8dec>
   12bec:      	add	x2, x24, #0x10
   12bf0:      	mov	w8, #0x4                // =4
   12bf4:      	add	x9, sp, #0x98
   12bf8:      	add	x0, sp, #0x98
   12bfc:      	mov	w1, #0x8                // =8
   12c00:      	blr	x8
   12c04:      	ldr	x8, [sp, #0x58]
   12c08:      	ldr	x9, [sp, #0x98]
   12c0c:      	cmp	x8, x9
   12c10:      	ldr	x25, [sp, #0x8]
   12c14:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12c18:      	add	x2, x24, #0x18
   12c1c:      	mov	w8, #0x4                // =4
   12c20:      	mov	x0, x22
   12c24:      	mov	w1, #0x8                // =8
   12c28:      	blr	x8
   12c2c:      	ldr	x24, [sp, #0x98]
   12c30:      	ldr	x21, [sp, #0x48]
   12c34:      	add	x2, x24, #0x20
   12c38:      	stp	x2, x24, [sp, #0x50]
   12c3c:      	ldr	x8, [sp, #0x30]
   12c40:      	ldr	x25, [sp, #0x8]
   12c44:      	add	x9, sp, #0x70
   12c48:      	cmp	x21, x8
   12c4c:      	b.ne	0x12c5c <generic_lsm_path+0x8e0c>
   12c50:      	ldr	x8, [sp, #0x38]
   12c54:      	cmp	x2, x8
   12c58:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12c5c:      	mov	w8, #0x4                // =4
   12c60:      	add	x0, sp, #0x70
   12c64:      	mov	w1, #0x8                // =8
   12c68:      	blr	x8
   12c6c:      	ldr	x8, [sp, #0x70]
   12c70:      	cmp	x21, x8
   12c74:      	b.eq	0x12d68 <generic_lsm_path+0x8f18>
   12c78:      	add	x23, x21, #0x18
   12c7c:      	mov	w8, #0x4                // =4
   12c80:      	add	x9, sp, #0x98
   12c84:      	add	x0, sp, #0x98
   12c88:      	mov	w1, #0x8                // =8
   12c8c:      	mov	x2, x23
   12c90:      	blr	x8
   12c94:      	ldr	x8, [sp, #0x98]
   12c98:      	cmp	x8, x21
   12c9c:      	b.eq	0x12d68 <generic_lsm_path+0x8f18>
   12ca0:      	mov	w8, #0x4                // =4
   12ca4:      	add	x9, sp, #0x78
   12ca8:      	add	x0, sp, #0x78
   12cac:      	mov	w1, #0x8                // =8
   12cb0:      	mov	x2, x23
   12cb4:      	blr	x8
   12cb8:      	add	x2, x21, #0x20
   12cbc:      	mov	w8, #0x4                // =4
   12cc0:      	mov	w9, #0x10               // =16
   12cc4:      	add	x10, sp, #0x80
   12cc8:      	add	x0, sp, #0x80
   12ccc:      	mov	w1, #0x10               // =16
   12cd0:      	blr	x8
   12cd4:      	ldr	w21, [sp, #0x84]
   12cd8:      	ldr	x8, [sp, #0x40]
   12cdc:      	ldr	x10, [sp, #0x60]
   12ce0:      	sub	x12, x10, x8
   12ce4:      	ldr	w23, [sp, #0x68]
   12ce8:      	subs	w10, w21, w23
   12cec:      	ldr	x9, [sp, #0x88]
   12cf0:      	ldr	x25, [sp, #0x8]
   12cf4:      	csel	w10, wzr, w10, lo
   12cf8:      	cmp	w23, w21
   12cfc:      	csel	w11, w23, w21, lo
   12d00:      	cinc	w13, w11, hi
   12d04:      	sub	w14, w23, w13
   12d08:      	subs	x12, x12, x13
   12d0c:      	str	w14, [sp, #0x68]
   12d10:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   12d14:      	cmp	x12, #0xfff
   12d18:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   12d1c:      	cmp	w23, w21
   12d20:      	b.ls	0x12d2c <generic_lsm_path+0x8edc>
   12d24:      	mov	w13, #0x2f              // =47
   12d28:      	strb	w13, [x8, x12]
   12d2c:      	add	x19, x8, x12
   12d30:      	cmp	w23, w21
   12d34:      	add	x2, x9, x10
   12d38:      	and	w1, w11, #0xff
   12d3c:      	mov	w8, #0x4                // =4
   12d40:      	cinc	x0, x19, hi
   12d44:      	blr	x8
   12d48:      	ldr	x25, [sp, #0x8]
   12d4c:      	cmp	w23, w21
   12d50:      	str	x19, [sp, #0x60]
   12d54:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12d58:      	ldr	x21, [sp, #0x78]
   12d5c:      	ldp	x2, x24, [sp, #0x50]
   12d60:      	str	x21, [sp, #0x48]
   12d64:      	b	0x12db8 <generic_lsm_path+0x8f68>
   12d68:      	add	x2, x24, #0x10
   12d6c:      	mov	w8, #0x4                // =4
   12d70:      	add	x9, sp, #0x98
   12d74:      	add	x0, sp, #0x98
   12d78:      	mov	w1, #0x8                // =8
   12d7c:      	blr	x8
   12d80:      	ldr	x8, [sp, #0x58]
   12d84:      	ldr	x9, [sp, #0x98]
   12d88:      	cmp	x8, x9
   12d8c:      	ldr	x25, [sp, #0x8]
   12d90:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12d94:      	add	x2, x24, #0x18
   12d98:      	mov	w8, #0x4                // =4
   12d9c:      	mov	x0, x22
   12da0:      	mov	w1, #0x8                // =8
   12da4:      	blr	x8
   12da8:      	ldr	x24, [sp, #0x98]
   12dac:      	ldr	x21, [sp, #0x48]
   12db0:      	add	x2, x24, #0x20
   12db4:      	stp	x2, x24, [sp, #0x50]
   12db8:      	ldr	x8, [sp, #0x30]
   12dbc:      	ldr	x25, [sp, #0x8]
   12dc0:      	add	x9, sp, #0x70
   12dc4:      	cmp	x21, x8
   12dc8:      	b.ne	0x12dd8 <generic_lsm_path+0x8f88>
   12dcc:      	ldr	x8, [sp, #0x38]
   12dd0:      	cmp	x2, x8
   12dd4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12dd8:      	mov	w8, #0x4                // =4
   12ddc:      	add	x0, sp, #0x70
   12de0:      	mov	w1, #0x8                // =8
   12de4:      	blr	x8
   12de8:      	ldr	x8, [sp, #0x70]
   12dec:      	cmp	x21, x8
   12df0:      	b.eq	0x12ee4 <generic_lsm_path+0x9094>
   12df4:      	add	x23, x21, #0x18
   12df8:      	mov	w8, #0x4                // =4
   12dfc:      	add	x9, sp, #0x98
   12e00:      	add	x0, sp, #0x98
   12e04:      	mov	w1, #0x8                // =8
   12e08:      	mov	x2, x23
   12e0c:      	blr	x8
   12e10:      	ldr	x8, [sp, #0x98]
   12e14:      	cmp	x8, x21
   12e18:      	b.eq	0x12ee4 <generic_lsm_path+0x9094>
   12e1c:      	mov	w8, #0x4                // =4
   12e20:      	add	x9, sp, #0x78
   12e24:      	add	x0, sp, #0x78
   12e28:      	mov	w1, #0x8                // =8
   12e2c:      	mov	x2, x23
   12e30:      	blr	x8
   12e34:      	add	x2, x21, #0x20
   12e38:      	mov	w8, #0x4                // =4
   12e3c:      	mov	w9, #0x10               // =16
   12e40:      	add	x10, sp, #0x80
   12e44:      	add	x0, sp, #0x80
   12e48:      	mov	w1, #0x10               // =16
   12e4c:      	blr	x8
   12e50:      	ldr	w21, [sp, #0x84]
   12e54:      	ldr	x8, [sp, #0x40]
   12e58:      	ldr	x10, [sp, #0x60]
   12e5c:      	sub	x12, x10, x8
   12e60:      	ldr	w23, [sp, #0x68]
   12e64:      	subs	w10, w21, w23
   12e68:      	ldr	x9, [sp, #0x88]
   12e6c:      	ldr	x25, [sp, #0x8]
   12e70:      	csel	w10, wzr, w10, lo
   12e74:      	cmp	w23, w21
   12e78:      	csel	w11, w23, w21, lo
   12e7c:      	cinc	w13, w11, hi
   12e80:      	sub	w14, w23, w13
   12e84:      	subs	x12, x12, x13
   12e88:      	str	w14, [sp, #0x68]
   12e8c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   12e90:      	cmp	x12, #0xfff
   12e94:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   12e98:      	cmp	w23, w21
   12e9c:      	b.ls	0x12ea8 <generic_lsm_path+0x9058>
   12ea0:      	mov	w13, #0x2f              // =47
   12ea4:      	strb	w13, [x8, x12]
   12ea8:      	add	x19, x8, x12
   12eac:      	cmp	w23, w21
   12eb0:      	add	x2, x9, x10
   12eb4:      	and	w1, w11, #0xff
   12eb8:      	mov	w8, #0x4                // =4
   12ebc:      	cinc	x0, x19, hi
   12ec0:      	blr	x8
   12ec4:      	ldr	x25, [sp, #0x8]
   12ec8:      	cmp	w23, w21
   12ecc:      	str	x19, [sp, #0x60]
   12ed0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   12ed4:      	ldr	x21, [sp, #0x78]
   12ed8:      	ldp	x2, x24, [sp, #0x50]
   12edc:      	str	x21, [sp, #0x48]
   12ee0:      	b	0x12f34 <generic_lsm_path+0x90e4>
   12ee4:      	add	x2, x24, #0x10
   12ee8:      	mov	w8, #0x4                // =4
   12eec:      	add	x9, sp, #0x98
   12ef0:      	add	x0, sp, #0x98
   12ef4:      	mov	w1, #0x8                // =8
   12ef8:      	blr	x8
   12efc:      	ldr	x8, [sp, #0x58]
   12f00:      	ldr	x9, [sp, #0x98]
   12f04:      	cmp	x8, x9
   12f08:      	ldr	x25, [sp, #0x8]
   12f0c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12f10:      	add	x2, x24, #0x18
   12f14:      	mov	w8, #0x4                // =4
   12f18:      	mov	x0, x22
   12f1c:      	mov	w1, #0x8                // =8
   12f20:      	blr	x8
   12f24:      	ldr	x24, [sp, #0x98]
   12f28:      	ldr	x21, [sp, #0x48]
   12f2c:      	add	x2, x24, #0x20
   12f30:      	stp	x2, x24, [sp, #0x50]
   12f34:      	ldr	x8, [sp, #0x30]
   12f38:      	ldr	x25, [sp, #0x8]
   12f3c:      	add	x9, sp, #0x70
   12f40:      	cmp	x21, x8
   12f44:      	b.ne	0x12f54 <generic_lsm_path+0x9104>
   12f48:      	ldr	x8, [sp, #0x38]
   12f4c:      	cmp	x2, x8
   12f50:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   12f54:      	mov	w8, #0x4                // =4
   12f58:      	add	x0, sp, #0x70
   12f5c:      	mov	w1, #0x8                // =8
   12f60:      	blr	x8
   12f64:      	ldr	x8, [sp, #0x70]
   12f68:      	cmp	x21, x8
   12f6c:      	b.eq	0x13060 <generic_lsm_path+0x9210>
   12f70:      	add	x23, x21, #0x18
   12f74:      	mov	w8, #0x4                // =4
   12f78:      	add	x9, sp, #0x98
   12f7c:      	add	x0, sp, #0x98
   12f80:      	mov	w1, #0x8                // =8
   12f84:      	mov	x2, x23
   12f88:      	blr	x8
   12f8c:      	ldr	x8, [sp, #0x98]
   12f90:      	cmp	x8, x21
   12f94:      	b.eq	0x13060 <generic_lsm_path+0x9210>
   12f98:      	mov	w8, #0x4                // =4
   12f9c:      	add	x9, sp, #0x78
   12fa0:      	add	x0, sp, #0x78
   12fa4:      	mov	w1, #0x8                // =8
   12fa8:      	mov	x2, x23
   12fac:      	blr	x8
   12fb0:      	add	x2, x21, #0x20
   12fb4:      	mov	w8, #0x4                // =4
   12fb8:      	mov	w9, #0x10               // =16
   12fbc:      	add	x10, sp, #0x80
   12fc0:      	add	x0, sp, #0x80
   12fc4:      	mov	w1, #0x10               // =16
   12fc8:      	blr	x8
   12fcc:      	ldr	w21, [sp, #0x84]
   12fd0:      	ldr	x8, [sp, #0x40]
   12fd4:      	ldr	x10, [sp, #0x60]
   12fd8:      	sub	x12, x10, x8
   12fdc:      	ldr	w23, [sp, #0x68]
   12fe0:      	subs	w10, w21, w23
   12fe4:      	ldr	x9, [sp, #0x88]
   12fe8:      	ldr	x25, [sp, #0x8]
   12fec:      	csel	w10, wzr, w10, lo
   12ff0:      	cmp	w23, w21
   12ff4:      	csel	w11, w23, w21, lo
   12ff8:      	cinc	w13, w11, hi
   12ffc:      	sub	w14, w23, w13
   13000:      	subs	x12, x12, x13
   13004:      	str	w14, [sp, #0x68]
   13008:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   1300c:      	cmp	x12, #0xfff
   13010:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13014:      	cmp	w23, w21
   13018:      	b.ls	0x13024 <generic_lsm_path+0x91d4>
   1301c:      	mov	w13, #0x2f              // =47
   13020:      	strb	w13, [x8, x12]
   13024:      	add	x19, x8, x12
   13028:      	cmp	w23, w21
   1302c:      	add	x2, x9, x10
   13030:      	and	w1, w11, #0xff
   13034:      	mov	w8, #0x4                // =4
   13038:      	cinc	x0, x19, hi
   1303c:      	blr	x8
   13040:      	ldr	x25, [sp, #0x8]
   13044:      	cmp	w23, w21
   13048:      	str	x19, [sp, #0x60]
   1304c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13050:      	ldr	x21, [sp, #0x78]
   13054:      	ldp	x2, x24, [sp, #0x50]
   13058:      	str	x21, [sp, #0x48]
   1305c:      	b	0x130b0 <generic_lsm_path+0x9260>
   13060:      	add	x2, x24, #0x10
   13064:      	mov	w8, #0x4                // =4
   13068:      	add	x9, sp, #0x98
   1306c:      	add	x0, sp, #0x98
   13070:      	mov	w1, #0x8                // =8
   13074:      	blr	x8
   13078:      	ldr	x8, [sp, #0x58]
   1307c:      	ldr	x9, [sp, #0x98]
   13080:      	cmp	x8, x9
   13084:      	ldr	x25, [sp, #0x8]
   13088:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1308c:      	add	x2, x24, #0x18
   13090:      	mov	w8, #0x4                // =4
   13094:      	mov	x0, x22
   13098:      	mov	w1, #0x8                // =8
   1309c:      	blr	x8
   130a0:      	ldr	x24, [sp, #0x98]
   130a4:      	ldr	x21, [sp, #0x48]
   130a8:      	add	x2, x24, #0x20
   130ac:      	stp	x2, x24, [sp, #0x50]
   130b0:      	ldr	x8, [sp, #0x30]
   130b4:      	ldr	x25, [sp, #0x8]
   130b8:      	add	x9, sp, #0x70
   130bc:      	cmp	x21, x8
   130c0:      	b.ne	0x130d0 <generic_lsm_path+0x9280>
   130c4:      	ldr	x8, [sp, #0x38]
   130c8:      	cmp	x2, x8
   130cc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   130d0:      	mov	w8, #0x4                // =4
   130d4:      	add	x0, sp, #0x70
   130d8:      	mov	w1, #0x8                // =8
   130dc:      	blr	x8
   130e0:      	ldr	x8, [sp, #0x70]
   130e4:      	cmp	x21, x8
   130e8:      	b.eq	0x131dc <generic_lsm_path+0x938c>
   130ec:      	add	x23, x21, #0x18
   130f0:      	mov	w8, #0x4                // =4
   130f4:      	add	x9, sp, #0x98
   130f8:      	add	x0, sp, #0x98
   130fc:      	mov	w1, #0x8                // =8
   13100:      	mov	x2, x23
   13104:      	blr	x8
   13108:      	ldr	x8, [sp, #0x98]
   1310c:      	cmp	x8, x21
   13110:      	b.eq	0x131dc <generic_lsm_path+0x938c>
   13114:      	mov	w8, #0x4                // =4
   13118:      	add	x9, sp, #0x78
   1311c:      	add	x0, sp, #0x78
   13120:      	mov	w1, #0x8                // =8
   13124:      	mov	x2, x23
   13128:      	blr	x8
   1312c:      	add	x2, x21, #0x20
   13130:      	mov	w8, #0x4                // =4
   13134:      	mov	w9, #0x10               // =16
   13138:      	add	x10, sp, #0x80
   1313c:      	add	x0, sp, #0x80
   13140:      	mov	w1, #0x10               // =16
   13144:      	blr	x8
   13148:      	ldr	w21, [sp, #0x84]
   1314c:      	ldr	x8, [sp, #0x40]
   13150:      	ldr	x10, [sp, #0x60]
   13154:      	sub	x12, x10, x8
   13158:      	ldr	w23, [sp, #0x68]
   1315c:      	subs	w10, w21, w23
   13160:      	ldr	x9, [sp, #0x88]
   13164:      	ldr	x25, [sp, #0x8]
   13168:      	csel	w10, wzr, w10, lo
   1316c:      	cmp	w23, w21
   13170:      	csel	w11, w23, w21, lo
   13174:      	cinc	w13, w11, hi
   13178:      	sub	w14, w23, w13
   1317c:      	subs	x12, x12, x13
   13180:      	str	w14, [sp, #0x68]
   13184:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13188:      	cmp	x12, #0xfff
   1318c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13190:      	cmp	w23, w21
   13194:      	b.ls	0x131a0 <generic_lsm_path+0x9350>
   13198:      	mov	w13, #0x2f              // =47
   1319c:      	strb	w13, [x8, x12]
   131a0:      	add	x19, x8, x12
   131a4:      	cmp	w23, w21
   131a8:      	add	x2, x9, x10
   131ac:      	and	w1, w11, #0xff
   131b0:      	mov	w8, #0x4                // =4
   131b4:      	cinc	x0, x19, hi
   131b8:      	blr	x8
   131bc:      	ldr	x25, [sp, #0x8]
   131c0:      	cmp	w23, w21
   131c4:      	str	x19, [sp, #0x60]
   131c8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   131cc:      	ldr	x21, [sp, #0x78]
   131d0:      	ldp	x2, x24, [sp, #0x50]
   131d4:      	str	x21, [sp, #0x48]
   131d8:      	b	0x1322c <generic_lsm_path+0x93dc>
   131dc:      	add	x2, x24, #0x10
   131e0:      	mov	w8, #0x4                // =4
   131e4:      	add	x9, sp, #0x98
   131e8:      	add	x0, sp, #0x98
   131ec:      	mov	w1, #0x8                // =8
   131f0:      	blr	x8
   131f4:      	ldr	x8, [sp, #0x58]
   131f8:      	ldr	x9, [sp, #0x98]
   131fc:      	cmp	x8, x9
   13200:      	ldr	x25, [sp, #0x8]
   13204:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13208:      	add	x2, x24, #0x18
   1320c:      	mov	w8, #0x4                // =4
   13210:      	mov	x0, x22
   13214:      	mov	w1, #0x8                // =8
   13218:      	blr	x8
   1321c:      	ldr	x24, [sp, #0x98]
   13220:      	ldr	x21, [sp, #0x48]
   13224:      	add	x2, x24, #0x20
   13228:      	stp	x2, x24, [sp, #0x50]
   1322c:      	ldr	x8, [sp, #0x30]
   13230:      	ldr	x25, [sp, #0x8]
   13234:      	add	x9, sp, #0x70
   13238:      	cmp	x21, x8
   1323c:      	b.ne	0x1324c <generic_lsm_path+0x93fc>
   13240:      	ldr	x8, [sp, #0x38]
   13244:      	cmp	x2, x8
   13248:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1324c:      	mov	w8, #0x4                // =4
   13250:      	add	x0, sp, #0x70
   13254:      	mov	w1, #0x8                // =8
   13258:      	blr	x8
   1325c:      	ldr	x8, [sp, #0x70]
   13260:      	cmp	x21, x8
   13264:      	b.eq	0x13358 <generic_lsm_path+0x9508>
   13268:      	add	x23, x21, #0x18
   1326c:      	mov	w8, #0x4                // =4
   13270:      	add	x9, sp, #0x98
   13274:      	add	x0, sp, #0x98
   13278:      	mov	w1, #0x8                // =8
   1327c:      	mov	x2, x23
   13280:      	blr	x8
   13284:      	ldr	x8, [sp, #0x98]
   13288:      	cmp	x8, x21
   1328c:      	b.eq	0x13358 <generic_lsm_path+0x9508>
   13290:      	mov	w8, #0x4                // =4
   13294:      	add	x9, sp, #0x78
   13298:      	add	x0, sp, #0x78
   1329c:      	mov	w1, #0x8                // =8
   132a0:      	mov	x2, x23
   132a4:      	blr	x8
   132a8:      	add	x2, x21, #0x20
   132ac:      	mov	w8, #0x4                // =4
   132b0:      	mov	w9, #0x10               // =16
   132b4:      	add	x10, sp, #0x80
   132b8:      	add	x0, sp, #0x80
   132bc:      	mov	w1, #0x10               // =16
   132c0:      	blr	x8
   132c4:      	ldr	w21, [sp, #0x84]
   132c8:      	ldr	x8, [sp, #0x40]
   132cc:      	ldr	x10, [sp, #0x60]
   132d0:      	sub	x12, x10, x8
   132d4:      	ldr	w23, [sp, #0x68]
   132d8:      	subs	w10, w21, w23
   132dc:      	ldr	x9, [sp, #0x88]
   132e0:      	ldr	x25, [sp, #0x8]
   132e4:      	csel	w10, wzr, w10, lo
   132e8:      	cmp	w23, w21
   132ec:      	csel	w11, w23, w21, lo
   132f0:      	cinc	w13, w11, hi
   132f4:      	sub	w14, w23, w13
   132f8:      	subs	x12, x12, x13
   132fc:      	str	w14, [sp, #0x68]
   13300:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13304:      	cmp	x12, #0xfff
   13308:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   1330c:      	cmp	w23, w21
   13310:      	b.ls	0x1331c <generic_lsm_path+0x94cc>
   13314:      	mov	w13, #0x2f              // =47
   13318:      	strb	w13, [x8, x12]
   1331c:      	add	x19, x8, x12
   13320:      	cmp	w23, w21
   13324:      	add	x2, x9, x10
   13328:      	and	w1, w11, #0xff
   1332c:      	mov	w8, #0x4                // =4
   13330:      	cinc	x0, x19, hi
   13334:      	blr	x8
   13338:      	ldr	x25, [sp, #0x8]
   1333c:      	cmp	w23, w21
   13340:      	str	x19, [sp, #0x60]
   13344:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13348:      	ldr	x21, [sp, #0x78]
   1334c:      	ldp	x2, x24, [sp, #0x50]
   13350:      	str	x21, [sp, #0x48]
   13354:      	b	0x133a8 <generic_lsm_path+0x9558>
   13358:      	add	x2, x24, #0x10
   1335c:      	mov	w8, #0x4                // =4
   13360:      	add	x9, sp, #0x98
   13364:      	add	x0, sp, #0x98
   13368:      	mov	w1, #0x8                // =8
   1336c:      	blr	x8
   13370:      	ldr	x8, [sp, #0x58]
   13374:      	ldr	x9, [sp, #0x98]
   13378:      	cmp	x8, x9
   1337c:      	ldr	x25, [sp, #0x8]
   13380:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13384:      	add	x2, x24, #0x18
   13388:      	mov	w8, #0x4                // =4
   1338c:      	mov	x0, x22
   13390:      	mov	w1, #0x8                // =8
   13394:      	blr	x8
   13398:      	ldr	x24, [sp, #0x98]
   1339c:      	ldr	x21, [sp, #0x48]
   133a0:      	add	x2, x24, #0x20
   133a4:      	stp	x2, x24, [sp, #0x50]
   133a8:      	ldr	x8, [sp, #0x30]
   133ac:      	ldr	x25, [sp, #0x8]
   133b0:      	add	x9, sp, #0x70
   133b4:      	cmp	x21, x8
   133b8:      	b.ne	0x133c8 <generic_lsm_path+0x9578>
   133bc:      	ldr	x8, [sp, #0x38]
   133c0:      	cmp	x2, x8
   133c4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   133c8:      	mov	w8, #0x4                // =4
   133cc:      	add	x0, sp, #0x70
   133d0:      	mov	w1, #0x8                // =8
   133d4:      	blr	x8
   133d8:      	ldr	x8, [sp, #0x70]
   133dc:      	cmp	x21, x8
   133e0:      	b.eq	0x134d4 <generic_lsm_path+0x9684>
   133e4:      	add	x23, x21, #0x18
   133e8:      	mov	w8, #0x4                // =4
   133ec:      	add	x9, sp, #0x98
   133f0:      	add	x0, sp, #0x98
   133f4:      	mov	w1, #0x8                // =8
   133f8:      	mov	x2, x23
   133fc:      	blr	x8
   13400:      	ldr	x8, [sp, #0x98]
   13404:      	cmp	x8, x21
   13408:      	b.eq	0x134d4 <generic_lsm_path+0x9684>
   1340c:      	mov	w8, #0x4                // =4
   13410:      	add	x9, sp, #0x78
   13414:      	add	x0, sp, #0x78
   13418:      	mov	w1, #0x8                // =8
   1341c:      	mov	x2, x23
   13420:      	blr	x8
   13424:      	add	x2, x21, #0x20
   13428:      	mov	w8, #0x4                // =4
   1342c:      	mov	w9, #0x10               // =16
   13430:      	add	x10, sp, #0x80
   13434:      	add	x0, sp, #0x80
   13438:      	mov	w1, #0x10               // =16
   1343c:      	blr	x8
   13440:      	ldr	w21, [sp, #0x84]
   13444:      	ldr	x8, [sp, #0x40]
   13448:      	ldr	x10, [sp, #0x60]
   1344c:      	sub	x12, x10, x8
   13450:      	ldr	w23, [sp, #0x68]
   13454:      	subs	w10, w21, w23
   13458:      	ldr	x9, [sp, #0x88]
   1345c:      	ldr	x25, [sp, #0x8]
   13460:      	csel	w10, wzr, w10, lo
   13464:      	cmp	w23, w21
   13468:      	csel	w11, w23, w21, lo
   1346c:      	cinc	w13, w11, hi
   13470:      	sub	w14, w23, w13
   13474:      	subs	x12, x12, x13
   13478:      	str	w14, [sp, #0x68]
   1347c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13480:      	cmp	x12, #0xfff
   13484:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13488:      	cmp	w23, w21
   1348c:      	b.ls	0x13498 <generic_lsm_path+0x9648>
   13490:      	mov	w13, #0x2f              // =47
   13494:      	strb	w13, [x8, x12]
   13498:      	add	x19, x8, x12
   1349c:      	cmp	w23, w21
   134a0:      	add	x2, x9, x10
   134a4:      	and	w1, w11, #0xff
   134a8:      	mov	w8, #0x4                // =4
   134ac:      	cinc	x0, x19, hi
   134b0:      	blr	x8
   134b4:      	ldr	x25, [sp, #0x8]
   134b8:      	cmp	w23, w21
   134bc:      	str	x19, [sp, #0x60]
   134c0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   134c4:      	ldr	x21, [sp, #0x78]
   134c8:      	ldp	x2, x24, [sp, #0x50]
   134cc:      	str	x21, [sp, #0x48]
   134d0:      	b	0x13524 <generic_lsm_path+0x96d4>
   134d4:      	add	x2, x24, #0x10
   134d8:      	mov	w8, #0x4                // =4
   134dc:      	add	x9, sp, #0x98
   134e0:      	add	x0, sp, #0x98
   134e4:      	mov	w1, #0x8                // =8
   134e8:      	blr	x8
   134ec:      	ldr	x8, [sp, #0x58]
   134f0:      	ldr	x9, [sp, #0x98]
   134f4:      	cmp	x8, x9
   134f8:      	ldr	x25, [sp, #0x8]
   134fc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13500:      	add	x2, x24, #0x18
   13504:      	mov	w8, #0x4                // =4
   13508:      	mov	x0, x22
   1350c:      	mov	w1, #0x8                // =8
   13510:      	blr	x8
   13514:      	ldr	x24, [sp, #0x98]
   13518:      	ldr	x21, [sp, #0x48]
   1351c:      	add	x2, x24, #0x20
   13520:      	stp	x2, x24, [sp, #0x50]
   13524:      	ldr	x8, [sp, #0x30]
   13528:      	ldr	x25, [sp, #0x8]
   1352c:      	add	x9, sp, #0x70
   13530:      	cmp	x21, x8
   13534:      	b.ne	0x13544 <generic_lsm_path+0x96f4>
   13538:      	ldr	x8, [sp, #0x38]
   1353c:      	cmp	x2, x8
   13540:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13544:      	mov	w8, #0x4                // =4
   13548:      	add	x0, sp, #0x70
   1354c:      	mov	w1, #0x8                // =8
   13550:      	blr	x8
   13554:      	ldr	x8, [sp, #0x70]
   13558:      	cmp	x21, x8
   1355c:      	b.eq	0x13650 <generic_lsm_path+0x9800>
   13560:      	add	x23, x21, #0x18
   13564:      	mov	w8, #0x4                // =4
   13568:      	add	x9, sp, #0x98
   1356c:      	add	x0, sp, #0x98
   13570:      	mov	w1, #0x8                // =8
   13574:      	mov	x2, x23
   13578:      	blr	x8
   1357c:      	ldr	x8, [sp, #0x98]
   13580:      	cmp	x8, x21
   13584:      	b.eq	0x13650 <generic_lsm_path+0x9800>
   13588:      	mov	w8, #0x4                // =4
   1358c:      	add	x9, sp, #0x78
   13590:      	add	x0, sp, #0x78
   13594:      	mov	w1, #0x8                // =8
   13598:      	mov	x2, x23
   1359c:      	blr	x8
   135a0:      	add	x2, x21, #0x20
   135a4:      	mov	w8, #0x4                // =4
   135a8:      	mov	w9, #0x10               // =16
   135ac:      	add	x10, sp, #0x80
   135b0:      	add	x0, sp, #0x80
   135b4:      	mov	w1, #0x10               // =16
   135b8:      	blr	x8
   135bc:      	ldr	w21, [sp, #0x84]
   135c0:      	ldr	x8, [sp, #0x40]
   135c4:      	ldr	x10, [sp, #0x60]
   135c8:      	sub	x12, x10, x8
   135cc:      	ldr	w23, [sp, #0x68]
   135d0:      	subs	w10, w21, w23
   135d4:      	ldr	x9, [sp, #0x88]
   135d8:      	ldr	x25, [sp, #0x8]
   135dc:      	csel	w10, wzr, w10, lo
   135e0:      	cmp	w23, w21
   135e4:      	csel	w11, w23, w21, lo
   135e8:      	cinc	w13, w11, hi
   135ec:      	sub	w14, w23, w13
   135f0:      	subs	x12, x12, x13
   135f4:      	str	w14, [sp, #0x68]
   135f8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   135fc:      	cmp	x12, #0xfff
   13600:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13604:      	cmp	w23, w21
   13608:      	b.ls	0x13614 <generic_lsm_path+0x97c4>
   1360c:      	mov	w13, #0x2f              // =47
   13610:      	strb	w13, [x8, x12]
   13614:      	add	x19, x8, x12
   13618:      	cmp	w23, w21
   1361c:      	add	x2, x9, x10
   13620:      	and	w1, w11, #0xff
   13624:      	mov	w8, #0x4                // =4
   13628:      	cinc	x0, x19, hi
   1362c:      	blr	x8
   13630:      	ldr	x25, [sp, #0x8]
   13634:      	cmp	w23, w21
   13638:      	str	x19, [sp, #0x60]
   1363c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13640:      	ldr	x21, [sp, #0x78]
   13644:      	ldp	x2, x24, [sp, #0x50]
   13648:      	str	x21, [sp, #0x48]
   1364c:      	b	0x136a0 <generic_lsm_path+0x9850>
   13650:      	add	x2, x24, #0x10
   13654:      	mov	w8, #0x4                // =4
   13658:      	add	x9, sp, #0x98
   1365c:      	add	x0, sp, #0x98
   13660:      	mov	w1, #0x8                // =8
   13664:      	blr	x8
   13668:      	ldr	x8, [sp, #0x58]
   1366c:      	ldr	x9, [sp, #0x98]
   13670:      	cmp	x8, x9
   13674:      	ldr	x25, [sp, #0x8]
   13678:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1367c:      	add	x2, x24, #0x18
   13680:      	mov	w8, #0x4                // =4
   13684:      	mov	x0, x22
   13688:      	mov	w1, #0x8                // =8
   1368c:      	blr	x8
   13690:      	ldr	x24, [sp, #0x98]
   13694:      	ldr	x21, [sp, #0x48]
   13698:      	add	x2, x24, #0x20
   1369c:      	stp	x2, x24, [sp, #0x50]
   136a0:      	ldr	x8, [sp, #0x30]
   136a4:      	ldr	x25, [sp, #0x8]
   136a8:      	add	x9, sp, #0x70
   136ac:      	cmp	x21, x8
   136b0:      	b.ne	0x136c0 <generic_lsm_path+0x9870>
   136b4:      	ldr	x8, [sp, #0x38]
   136b8:      	cmp	x2, x8
   136bc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   136c0:      	mov	w8, #0x4                // =4
   136c4:      	add	x0, sp, #0x70
   136c8:      	mov	w1, #0x8                // =8
   136cc:      	blr	x8
   136d0:      	ldr	x8, [sp, #0x70]
   136d4:      	cmp	x21, x8
   136d8:      	b.eq	0x137cc <generic_lsm_path+0x997c>
   136dc:      	add	x23, x21, #0x18
   136e0:      	mov	w8, #0x4                // =4
   136e4:      	add	x9, sp, #0x98
   136e8:      	add	x0, sp, #0x98
   136ec:      	mov	w1, #0x8                // =8
   136f0:      	mov	x2, x23
   136f4:      	blr	x8
   136f8:      	ldr	x8, [sp, #0x98]
   136fc:      	cmp	x8, x21
   13700:      	b.eq	0x137cc <generic_lsm_path+0x997c>
   13704:      	mov	w8, #0x4                // =4
   13708:      	add	x9, sp, #0x78
   1370c:      	add	x0, sp, #0x78
   13710:      	mov	w1, #0x8                // =8
   13714:      	mov	x2, x23
   13718:      	blr	x8
   1371c:      	add	x2, x21, #0x20
   13720:      	mov	w8, #0x4                // =4
   13724:      	mov	w9, #0x10               // =16
   13728:      	add	x10, sp, #0x80
   1372c:      	add	x0, sp, #0x80
   13730:      	mov	w1, #0x10               // =16
   13734:      	blr	x8
   13738:      	ldr	w21, [sp, #0x84]
   1373c:      	ldr	x8, [sp, #0x40]
   13740:      	ldr	x10, [sp, #0x60]
   13744:      	sub	x12, x10, x8
   13748:      	ldr	w23, [sp, #0x68]
   1374c:      	subs	w10, w21, w23
   13750:      	ldr	x9, [sp, #0x88]
   13754:      	ldr	x25, [sp, #0x8]
   13758:      	csel	w10, wzr, w10, lo
   1375c:      	cmp	w23, w21
   13760:      	csel	w11, w23, w21, lo
   13764:      	cinc	w13, w11, hi
   13768:      	sub	w14, w23, w13
   1376c:      	subs	x12, x12, x13
   13770:      	str	w14, [sp, #0x68]
   13774:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13778:      	cmp	x12, #0xfff
   1377c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13780:      	cmp	w23, w21
   13784:      	b.ls	0x13790 <generic_lsm_path+0x9940>
   13788:      	mov	w13, #0x2f              // =47
   1378c:      	strb	w13, [x8, x12]
   13790:      	add	x19, x8, x12
   13794:      	cmp	w23, w21
   13798:      	add	x2, x9, x10
   1379c:      	and	w1, w11, #0xff
   137a0:      	mov	w8, #0x4                // =4
   137a4:      	cinc	x0, x19, hi
   137a8:      	blr	x8
   137ac:      	ldr	x25, [sp, #0x8]
   137b0:      	cmp	w23, w21
   137b4:      	str	x19, [sp, #0x60]
   137b8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   137bc:      	ldr	x21, [sp, #0x78]
   137c0:      	ldp	x2, x24, [sp, #0x50]
   137c4:      	str	x21, [sp, #0x48]
   137c8:      	b	0x1381c <generic_lsm_path+0x99cc>
   137cc:      	add	x2, x24, #0x10
   137d0:      	mov	w8, #0x4                // =4
   137d4:      	add	x9, sp, #0x98
   137d8:      	add	x0, sp, #0x98
   137dc:      	mov	w1, #0x8                // =8
   137e0:      	blr	x8
   137e4:      	ldr	x8, [sp, #0x58]
   137e8:      	ldr	x9, [sp, #0x98]
   137ec:      	cmp	x8, x9
   137f0:      	ldr	x25, [sp, #0x8]
   137f4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   137f8:      	add	x2, x24, #0x18
   137fc:      	mov	w8, #0x4                // =4
   13800:      	mov	x0, x22
   13804:      	mov	w1, #0x8                // =8
   13808:      	blr	x8
   1380c:      	ldr	x24, [sp, #0x98]
   13810:      	ldr	x21, [sp, #0x48]
   13814:      	add	x2, x24, #0x20
   13818:      	stp	x2, x24, [sp, #0x50]
   1381c:      	ldr	x8, [sp, #0x30]
   13820:      	ldr	x25, [sp, #0x8]
   13824:      	add	x9, sp, #0x70
   13828:      	cmp	x21, x8
   1382c:      	b.ne	0x1383c <generic_lsm_path+0x99ec>
   13830:      	ldr	x8, [sp, #0x38]
   13834:      	cmp	x2, x8
   13838:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1383c:      	mov	w8, #0x4                // =4
   13840:      	add	x0, sp, #0x70
   13844:      	mov	w1, #0x8                // =8
   13848:      	blr	x8
   1384c:      	ldr	x8, [sp, #0x70]
   13850:      	cmp	x21, x8
   13854:      	b.eq	0x13948 <generic_lsm_path+0x9af8>
   13858:      	add	x23, x21, #0x18
   1385c:      	mov	w8, #0x4                // =4
   13860:      	add	x9, sp, #0x98
   13864:      	add	x0, sp, #0x98
   13868:      	mov	w1, #0x8                // =8
   1386c:      	mov	x2, x23
   13870:      	blr	x8
   13874:      	ldr	x8, [sp, #0x98]
   13878:      	cmp	x8, x21
   1387c:      	b.eq	0x13948 <generic_lsm_path+0x9af8>
   13880:      	mov	w8, #0x4                // =4
   13884:      	add	x9, sp, #0x78
   13888:      	add	x0, sp, #0x78
   1388c:      	mov	w1, #0x8                // =8
   13890:      	mov	x2, x23
   13894:      	blr	x8
   13898:      	add	x2, x21, #0x20
   1389c:      	mov	w8, #0x4                // =4
   138a0:      	mov	w9, #0x10               // =16
   138a4:      	add	x10, sp, #0x80
   138a8:      	add	x0, sp, #0x80
   138ac:      	mov	w1, #0x10               // =16
   138b0:      	blr	x8
   138b4:      	ldr	w21, [sp, #0x84]
   138b8:      	ldr	x8, [sp, #0x40]
   138bc:      	ldr	x10, [sp, #0x60]
   138c0:      	sub	x12, x10, x8
   138c4:      	ldr	w23, [sp, #0x68]
   138c8:      	subs	w10, w21, w23
   138cc:      	ldr	x9, [sp, #0x88]
   138d0:      	ldr	x25, [sp, #0x8]
   138d4:      	csel	w10, wzr, w10, lo
   138d8:      	cmp	w23, w21
   138dc:      	csel	w11, w23, w21, lo
   138e0:      	cinc	w13, w11, hi
   138e4:      	sub	w14, w23, w13
   138e8:      	subs	x12, x12, x13
   138ec:      	str	w14, [sp, #0x68]
   138f0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   138f4:      	cmp	x12, #0xfff
   138f8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   138fc:      	cmp	w23, w21
   13900:      	b.ls	0x1390c <generic_lsm_path+0x9abc>
   13904:      	mov	w13, #0x2f              // =47
   13908:      	strb	w13, [x8, x12]
   1390c:      	add	x19, x8, x12
   13910:      	cmp	w23, w21
   13914:      	add	x2, x9, x10
   13918:      	and	w1, w11, #0xff
   1391c:      	mov	w8, #0x4                // =4
   13920:      	cinc	x0, x19, hi
   13924:      	blr	x8
   13928:      	ldr	x25, [sp, #0x8]
   1392c:      	cmp	w23, w21
   13930:      	str	x19, [sp, #0x60]
   13934:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13938:      	ldr	x21, [sp, #0x78]
   1393c:      	ldp	x2, x24, [sp, #0x50]
   13940:      	str	x21, [sp, #0x48]
   13944:      	b	0x13998 <generic_lsm_path+0x9b48>
   13948:      	add	x2, x24, #0x10
   1394c:      	mov	w8, #0x4                // =4
   13950:      	add	x9, sp, #0x98
   13954:      	add	x0, sp, #0x98
   13958:      	mov	w1, #0x8                // =8
   1395c:      	blr	x8
   13960:      	ldr	x8, [sp, #0x58]
   13964:      	ldr	x9, [sp, #0x98]
   13968:      	cmp	x8, x9
   1396c:      	ldr	x25, [sp, #0x8]
   13970:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13974:      	add	x2, x24, #0x18
   13978:      	mov	w8, #0x4                // =4
   1397c:      	mov	x0, x22
   13980:      	mov	w1, #0x8                // =8
   13984:      	blr	x8
   13988:      	ldr	x24, [sp, #0x98]
   1398c:      	ldr	x21, [sp, #0x48]
   13990:      	add	x2, x24, #0x20
   13994:      	stp	x2, x24, [sp, #0x50]
   13998:      	ldr	x8, [sp, #0x30]
   1399c:      	ldr	x25, [sp, #0x8]
   139a0:      	add	x9, sp, #0x70
   139a4:      	cmp	x21, x8
   139a8:      	b.ne	0x139b8 <generic_lsm_path+0x9b68>
   139ac:      	ldr	x8, [sp, #0x38]
   139b0:      	cmp	x2, x8
   139b4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   139b8:      	mov	w8, #0x4                // =4
   139bc:      	add	x0, sp, #0x70
   139c0:      	mov	w1, #0x8                // =8
   139c4:      	blr	x8
   139c8:      	ldr	x8, [sp, #0x70]
   139cc:      	cmp	x21, x8
   139d0:      	b.eq	0x13ac4 <generic_lsm_path+0x9c74>
   139d4:      	add	x23, x21, #0x18
   139d8:      	mov	w8, #0x4                // =4
   139dc:      	add	x9, sp, #0x98
   139e0:      	add	x0, sp, #0x98
   139e4:      	mov	w1, #0x8                // =8
   139e8:      	mov	x2, x23
   139ec:      	blr	x8
   139f0:      	ldr	x8, [sp, #0x98]
   139f4:      	cmp	x8, x21
   139f8:      	b.eq	0x13ac4 <generic_lsm_path+0x9c74>
   139fc:      	mov	w8, #0x4                // =4
   13a00:      	add	x9, sp, #0x78
   13a04:      	add	x0, sp, #0x78
   13a08:      	mov	w1, #0x8                // =8
   13a0c:      	mov	x2, x23
   13a10:      	blr	x8
   13a14:      	add	x2, x21, #0x20
   13a18:      	mov	w8, #0x4                // =4
   13a1c:      	mov	w9, #0x10               // =16
   13a20:      	add	x10, sp, #0x80
   13a24:      	add	x0, sp, #0x80
   13a28:      	mov	w1, #0x10               // =16
   13a2c:      	blr	x8
   13a30:      	ldr	w21, [sp, #0x84]
   13a34:      	ldr	x8, [sp, #0x40]
   13a38:      	ldr	x10, [sp, #0x60]
   13a3c:      	sub	x12, x10, x8
   13a40:      	ldr	w23, [sp, #0x68]
   13a44:      	subs	w10, w21, w23
   13a48:      	ldr	x9, [sp, #0x88]
   13a4c:      	ldr	x25, [sp, #0x8]
   13a50:      	csel	w10, wzr, w10, lo
   13a54:      	cmp	w23, w21
   13a58:      	csel	w11, w23, w21, lo
   13a5c:      	cinc	w13, w11, hi
   13a60:      	sub	w14, w23, w13
   13a64:      	subs	x12, x12, x13
   13a68:      	str	w14, [sp, #0x68]
   13a6c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13a70:      	cmp	x12, #0xfff
   13a74:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13a78:      	cmp	w23, w21
   13a7c:      	b.ls	0x13a88 <generic_lsm_path+0x9c38>
   13a80:      	mov	w13, #0x2f              // =47
   13a84:      	strb	w13, [x8, x12]
   13a88:      	add	x19, x8, x12
   13a8c:      	cmp	w23, w21
   13a90:      	add	x2, x9, x10
   13a94:      	and	w1, w11, #0xff
   13a98:      	mov	w8, #0x4                // =4
   13a9c:      	cinc	x0, x19, hi
   13aa0:      	blr	x8
   13aa4:      	ldr	x25, [sp, #0x8]
   13aa8:      	cmp	w23, w21
   13aac:      	str	x19, [sp, #0x60]
   13ab0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13ab4:      	ldr	x21, [sp, #0x78]
   13ab8:      	ldp	x2, x24, [sp, #0x50]
   13abc:      	str	x21, [sp, #0x48]
   13ac0:      	b	0x13b14 <generic_lsm_path+0x9cc4>
   13ac4:      	add	x2, x24, #0x10
   13ac8:      	mov	w8, #0x4                // =4
   13acc:      	add	x9, sp, #0x98
   13ad0:      	add	x0, sp, #0x98
   13ad4:      	mov	w1, #0x8                // =8
   13ad8:      	blr	x8
   13adc:      	ldr	x8, [sp, #0x58]
   13ae0:      	ldr	x9, [sp, #0x98]
   13ae4:      	cmp	x8, x9
   13ae8:      	ldr	x25, [sp, #0x8]
   13aec:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13af0:      	add	x2, x24, #0x18
   13af4:      	mov	w8, #0x4                // =4
   13af8:      	mov	x0, x22
   13afc:      	mov	w1, #0x8                // =8
   13b00:      	blr	x8
   13b04:      	ldr	x24, [sp, #0x98]
   13b08:      	ldr	x21, [sp, #0x48]
   13b0c:      	add	x2, x24, #0x20
   13b10:      	stp	x2, x24, [sp, #0x50]
   13b14:      	ldr	x8, [sp, #0x30]
   13b18:      	ldr	x25, [sp, #0x8]
   13b1c:      	add	x9, sp, #0x70
   13b20:      	cmp	x21, x8
   13b24:      	b.ne	0x13b34 <generic_lsm_path+0x9ce4>
   13b28:      	ldr	x8, [sp, #0x38]
   13b2c:      	cmp	x2, x8
   13b30:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13b34:      	mov	w8, #0x4                // =4
   13b38:      	add	x0, sp, #0x70
   13b3c:      	mov	w1, #0x8                // =8
   13b40:      	blr	x8
   13b44:      	ldr	x8, [sp, #0x70]
   13b48:      	cmp	x21, x8
   13b4c:      	b.eq	0x13c40 <generic_lsm_path+0x9df0>
   13b50:      	add	x23, x21, #0x18
   13b54:      	mov	w8, #0x4                // =4
   13b58:      	add	x9, sp, #0x98
   13b5c:      	add	x0, sp, #0x98
   13b60:      	mov	w1, #0x8                // =8
   13b64:      	mov	x2, x23
   13b68:      	blr	x8
   13b6c:      	ldr	x8, [sp, #0x98]
   13b70:      	cmp	x8, x21
   13b74:      	b.eq	0x13c40 <generic_lsm_path+0x9df0>
   13b78:      	mov	w8, #0x4                // =4
   13b7c:      	add	x9, sp, #0x78
   13b80:      	add	x0, sp, #0x78
   13b84:      	mov	w1, #0x8                // =8
   13b88:      	mov	x2, x23
   13b8c:      	blr	x8
   13b90:      	add	x2, x21, #0x20
   13b94:      	mov	w8, #0x4                // =4
   13b98:      	mov	w9, #0x10               // =16
   13b9c:      	add	x10, sp, #0x80
   13ba0:      	add	x0, sp, #0x80
   13ba4:      	mov	w1, #0x10               // =16
   13ba8:      	blr	x8
   13bac:      	ldr	w21, [sp, #0x84]
   13bb0:      	ldr	x8, [sp, #0x40]
   13bb4:      	ldr	x10, [sp, #0x60]
   13bb8:      	sub	x12, x10, x8
   13bbc:      	ldr	w23, [sp, #0x68]
   13bc0:      	subs	w10, w21, w23
   13bc4:      	ldr	x9, [sp, #0x88]
   13bc8:      	ldr	x25, [sp, #0x8]
   13bcc:      	csel	w10, wzr, w10, lo
   13bd0:      	cmp	w23, w21
   13bd4:      	csel	w11, w23, w21, lo
   13bd8:      	cinc	w13, w11, hi
   13bdc:      	sub	w14, w23, w13
   13be0:      	subs	x12, x12, x13
   13be4:      	str	w14, [sp, #0x68]
   13be8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13bec:      	cmp	x12, #0xfff
   13bf0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13bf4:      	cmp	w23, w21
   13bf8:      	b.ls	0x13c04 <generic_lsm_path+0x9db4>
   13bfc:      	mov	w13, #0x2f              // =47
   13c00:      	strb	w13, [x8, x12]
   13c04:      	add	x19, x8, x12
   13c08:      	cmp	w23, w21
   13c0c:      	add	x2, x9, x10
   13c10:      	and	w1, w11, #0xff
   13c14:      	mov	w8, #0x4                // =4
   13c18:      	cinc	x0, x19, hi
   13c1c:      	blr	x8
   13c20:      	ldr	x25, [sp, #0x8]
   13c24:      	cmp	w23, w21
   13c28:      	str	x19, [sp, #0x60]
   13c2c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13c30:      	ldr	x21, [sp, #0x78]
   13c34:      	ldp	x2, x24, [sp, #0x50]
   13c38:      	str	x21, [sp, #0x48]
   13c3c:      	b	0x13c90 <generic_lsm_path+0x9e40>
   13c40:      	add	x2, x24, #0x10
   13c44:      	mov	w8, #0x4                // =4
   13c48:      	add	x9, sp, #0x98
   13c4c:      	add	x0, sp, #0x98
   13c50:      	mov	w1, #0x8                // =8
   13c54:      	blr	x8
   13c58:      	ldr	x8, [sp, #0x58]
   13c5c:      	ldr	x9, [sp, #0x98]
   13c60:      	cmp	x8, x9
   13c64:      	ldr	x25, [sp, #0x8]
   13c68:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13c6c:      	add	x2, x24, #0x18
   13c70:      	mov	w8, #0x4                // =4
   13c74:      	mov	x0, x22
   13c78:      	mov	w1, #0x8                // =8
   13c7c:      	blr	x8
   13c80:      	ldr	x24, [sp, #0x98]
   13c84:      	ldr	x21, [sp, #0x48]
   13c88:      	add	x2, x24, #0x20
   13c8c:      	stp	x2, x24, [sp, #0x50]
   13c90:      	ldr	x8, [sp, #0x30]
   13c94:      	ldr	x25, [sp, #0x8]
   13c98:      	add	x9, sp, #0x70
   13c9c:      	cmp	x21, x8
   13ca0:      	b.ne	0x13cb0 <generic_lsm_path+0x9e60>
   13ca4:      	ldr	x8, [sp, #0x38]
   13ca8:      	cmp	x2, x8
   13cac:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13cb0:      	mov	w8, #0x4                // =4
   13cb4:      	add	x0, sp, #0x70
   13cb8:      	mov	w1, #0x8                // =8
   13cbc:      	blr	x8
   13cc0:      	ldr	x8, [sp, #0x70]
   13cc4:      	cmp	x21, x8
   13cc8:      	b.eq	0x13dbc <generic_lsm_path+0x9f6c>
   13ccc:      	add	x23, x21, #0x18
   13cd0:      	mov	w8, #0x4                // =4
   13cd4:      	add	x9, sp, #0x98
   13cd8:      	add	x0, sp, #0x98
   13cdc:      	mov	w1, #0x8                // =8
   13ce0:      	mov	x2, x23
   13ce4:      	blr	x8
   13ce8:      	ldr	x8, [sp, #0x98]
   13cec:      	cmp	x8, x21
   13cf0:      	b.eq	0x13dbc <generic_lsm_path+0x9f6c>
   13cf4:      	mov	w8, #0x4                // =4
   13cf8:      	add	x9, sp, #0x78
   13cfc:      	add	x0, sp, #0x78
   13d00:      	mov	w1, #0x8                // =8
   13d04:      	mov	x2, x23
   13d08:      	blr	x8
   13d0c:      	add	x2, x21, #0x20
   13d10:      	mov	w8, #0x4                // =4
   13d14:      	mov	w9, #0x10               // =16
   13d18:      	add	x10, sp, #0x80
   13d1c:      	add	x0, sp, #0x80
   13d20:      	mov	w1, #0x10               // =16
   13d24:      	blr	x8
   13d28:      	ldr	w21, [sp, #0x84]
   13d2c:      	ldr	x8, [sp, #0x40]
   13d30:      	ldr	x10, [sp, #0x60]
   13d34:      	sub	x12, x10, x8
   13d38:      	ldr	w23, [sp, #0x68]
   13d3c:      	subs	w10, w21, w23
   13d40:      	ldr	x9, [sp, #0x88]
   13d44:      	ldr	x25, [sp, #0x8]
   13d48:      	csel	w10, wzr, w10, lo
   13d4c:      	cmp	w23, w21
   13d50:      	csel	w11, w23, w21, lo
   13d54:      	cinc	w13, w11, hi
   13d58:      	sub	w14, w23, w13
   13d5c:      	subs	x12, x12, x13
   13d60:      	str	w14, [sp, #0x68]
   13d64:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13d68:      	cmp	x12, #0xfff
   13d6c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13d70:      	cmp	w23, w21
   13d74:      	b.ls	0x13d80 <generic_lsm_path+0x9f30>
   13d78:      	mov	w13, #0x2f              // =47
   13d7c:      	strb	w13, [x8, x12]
   13d80:      	add	x19, x8, x12
   13d84:      	cmp	w23, w21
   13d88:      	add	x2, x9, x10
   13d8c:      	and	w1, w11, #0xff
   13d90:      	mov	w8, #0x4                // =4
   13d94:      	cinc	x0, x19, hi
   13d98:      	blr	x8
   13d9c:      	ldr	x25, [sp, #0x8]
   13da0:      	cmp	w23, w21
   13da4:      	str	x19, [sp, #0x60]
   13da8:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13dac:      	ldr	x21, [sp, #0x78]
   13db0:      	ldp	x2, x24, [sp, #0x50]
   13db4:      	str	x21, [sp, #0x48]
   13db8:      	b	0x13e0c <generic_lsm_path+0x9fbc>
   13dbc:      	add	x2, x24, #0x10
   13dc0:      	mov	w8, #0x4                // =4
   13dc4:      	add	x9, sp, #0x98
   13dc8:      	add	x0, sp, #0x98
   13dcc:      	mov	w1, #0x8                // =8
   13dd0:      	blr	x8
   13dd4:      	ldr	x8, [sp, #0x58]
   13dd8:      	ldr	x9, [sp, #0x98]
   13ddc:      	cmp	x8, x9
   13de0:      	ldr	x25, [sp, #0x8]
   13de4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13de8:      	add	x2, x24, #0x18
   13dec:      	mov	w8, #0x4                // =4
   13df0:      	mov	x0, x22
   13df4:      	mov	w1, #0x8                // =8
   13df8:      	blr	x8
   13dfc:      	ldr	x24, [sp, #0x98]
   13e00:      	ldr	x21, [sp, #0x48]
   13e04:      	add	x2, x24, #0x20
   13e08:      	stp	x2, x24, [sp, #0x50]
   13e0c:      	ldr	x8, [sp, #0x30]
   13e10:      	ldr	x25, [sp, #0x8]
   13e14:      	add	x9, sp, #0x70
   13e18:      	cmp	x21, x8
   13e1c:      	b.ne	0x13e2c <generic_lsm_path+0x9fdc>
   13e20:      	ldr	x8, [sp, #0x38]
   13e24:      	cmp	x2, x8
   13e28:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13e2c:      	mov	w8, #0x4                // =4
   13e30:      	add	x0, sp, #0x70
   13e34:      	mov	w1, #0x8                // =8
   13e38:      	blr	x8
   13e3c:      	ldr	x8, [sp, #0x70]
   13e40:      	cmp	x21, x8
   13e44:      	b.eq	0x13f38 <generic_lsm_path+0xa0e8>
   13e48:      	add	x23, x21, #0x18
   13e4c:      	mov	w8, #0x4                // =4
   13e50:      	add	x9, sp, #0x98
   13e54:      	add	x0, sp, #0x98
   13e58:      	mov	w1, #0x8                // =8
   13e5c:      	mov	x2, x23
   13e60:      	blr	x8
   13e64:      	ldr	x8, [sp, #0x98]
   13e68:      	cmp	x8, x21
   13e6c:      	b.eq	0x13f38 <generic_lsm_path+0xa0e8>
   13e70:      	mov	w8, #0x4                // =4
   13e74:      	add	x9, sp, #0x78
   13e78:      	add	x0, sp, #0x78
   13e7c:      	mov	w1, #0x8                // =8
   13e80:      	mov	x2, x23
   13e84:      	blr	x8
   13e88:      	add	x2, x21, #0x20
   13e8c:      	mov	w8, #0x4                // =4
   13e90:      	mov	w9, #0x10               // =16
   13e94:      	add	x10, sp, #0x80
   13e98:      	add	x0, sp, #0x80
   13e9c:      	mov	w1, #0x10               // =16
   13ea0:      	blr	x8
   13ea4:      	ldr	w21, [sp, #0x84]
   13ea8:      	ldr	x8, [sp, #0x40]
   13eac:      	ldr	x10, [sp, #0x60]
   13eb0:      	sub	x12, x10, x8
   13eb4:      	ldr	w23, [sp, #0x68]
   13eb8:      	subs	w10, w21, w23
   13ebc:      	ldr	x9, [sp, #0x88]
   13ec0:      	ldr	x25, [sp, #0x8]
   13ec4:      	csel	w10, wzr, w10, lo
   13ec8:      	cmp	w23, w21
   13ecc:      	csel	w11, w23, w21, lo
   13ed0:      	cinc	w13, w11, hi
   13ed4:      	sub	w14, w23, w13
   13ed8:      	subs	x12, x12, x13
   13edc:      	str	w14, [sp, #0x68]
   13ee0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   13ee4:      	cmp	x12, #0xfff
   13ee8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   13eec:      	cmp	w23, w21
   13ef0:      	b.ls	0x13efc <generic_lsm_path+0xa0ac>
   13ef4:      	mov	w13, #0x2f              // =47
   13ef8:      	strb	w13, [x8, x12]
   13efc:      	add	x19, x8, x12
   13f00:      	cmp	w23, w21
   13f04:      	add	x2, x9, x10
   13f08:      	and	w1, w11, #0xff
   13f0c:      	mov	w8, #0x4                // =4
   13f10:      	cinc	x0, x19, hi
   13f14:      	blr	x8
   13f18:      	ldr	x25, [sp, #0x8]
   13f1c:      	cmp	w23, w21
   13f20:      	str	x19, [sp, #0x60]
   13f24:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   13f28:      	ldr	x21, [sp, #0x78]
   13f2c:      	ldp	x2, x24, [sp, #0x50]
   13f30:      	str	x21, [sp, #0x48]
   13f34:      	b	0x13f88 <generic_lsm_path+0xa138>
   13f38:      	add	x2, x24, #0x10
   13f3c:      	mov	w8, #0x4                // =4
   13f40:      	add	x9, sp, #0x98
   13f44:      	add	x0, sp, #0x98
   13f48:      	mov	w1, #0x8                // =8
   13f4c:      	blr	x8
   13f50:      	ldr	x8, [sp, #0x58]
   13f54:      	ldr	x9, [sp, #0x98]
   13f58:      	cmp	x8, x9
   13f5c:      	ldr	x25, [sp, #0x8]
   13f60:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13f64:      	add	x2, x24, #0x18
   13f68:      	mov	w8, #0x4                // =4
   13f6c:      	mov	x0, x22
   13f70:      	mov	w1, #0x8                // =8
   13f74:      	blr	x8
   13f78:      	ldr	x24, [sp, #0x98]
   13f7c:      	ldr	x21, [sp, #0x48]
   13f80:      	add	x2, x24, #0x20
   13f84:      	stp	x2, x24, [sp, #0x50]
   13f88:      	ldr	x8, [sp, #0x30]
   13f8c:      	ldr	x25, [sp, #0x8]
   13f90:      	add	x9, sp, #0x70
   13f94:      	cmp	x21, x8
   13f98:      	b.ne	0x13fa8 <generic_lsm_path+0xa158>
   13f9c:      	ldr	x8, [sp, #0x38]
   13fa0:      	cmp	x2, x8
   13fa4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   13fa8:      	mov	w8, #0x4                // =4
   13fac:      	add	x0, sp, #0x70
   13fb0:      	mov	w1, #0x8                // =8
   13fb4:      	blr	x8
   13fb8:      	ldr	x8, [sp, #0x70]
   13fbc:      	cmp	x21, x8
   13fc0:      	b.eq	0x140b4 <generic_lsm_path+0xa264>
   13fc4:      	add	x23, x21, #0x18
   13fc8:      	mov	w8, #0x4                // =4
   13fcc:      	add	x9, sp, #0x98
   13fd0:      	add	x0, sp, #0x98
   13fd4:      	mov	w1, #0x8                // =8
   13fd8:      	mov	x2, x23
   13fdc:      	blr	x8
   13fe0:      	ldr	x8, [sp, #0x98]
   13fe4:      	cmp	x8, x21
   13fe8:      	b.eq	0x140b4 <generic_lsm_path+0xa264>
   13fec:      	mov	w8, #0x4                // =4
   13ff0:      	add	x9, sp, #0x78
   13ff4:      	add	x0, sp, #0x78
   13ff8:      	mov	w1, #0x8                // =8
   13ffc:      	mov	x2, x23
   14000:      	blr	x8
   14004:      	add	x2, x21, #0x20
   14008:      	mov	w8, #0x4                // =4
   1400c:      	mov	w9, #0x10               // =16
   14010:      	add	x10, sp, #0x80
   14014:      	add	x0, sp, #0x80
   14018:      	mov	w1, #0x10               // =16
   1401c:      	blr	x8
   14020:      	ldr	w21, [sp, #0x84]
   14024:      	ldr	x8, [sp, #0x40]
   14028:      	ldr	x10, [sp, #0x60]
   1402c:      	sub	x12, x10, x8
   14030:      	ldr	w23, [sp, #0x68]
   14034:      	subs	w10, w21, w23
   14038:      	ldr	x9, [sp, #0x88]
   1403c:      	ldr	x25, [sp, #0x8]
   14040:      	csel	w10, wzr, w10, lo
   14044:      	cmp	w23, w21
   14048:      	csel	w11, w23, w21, lo
   1404c:      	cinc	w13, w11, hi
   14050:      	sub	w14, w23, w13
   14054:      	subs	x12, x12, x13
   14058:      	str	w14, [sp, #0x68]
   1405c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14060:      	cmp	x12, #0xfff
   14064:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14068:      	cmp	w23, w21
   1406c:      	b.ls	0x14078 <generic_lsm_path+0xa228>
   14070:      	mov	w13, #0x2f              // =47
   14074:      	strb	w13, [x8, x12]
   14078:      	add	x19, x8, x12
   1407c:      	cmp	w23, w21
   14080:      	add	x2, x9, x10
   14084:      	and	w1, w11, #0xff
   14088:      	mov	w8, #0x4                // =4
   1408c:      	cinc	x0, x19, hi
   14090:      	blr	x8
   14094:      	ldr	x25, [sp, #0x8]
   14098:      	cmp	w23, w21
   1409c:      	str	x19, [sp, #0x60]
   140a0:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   140a4:      	ldr	x21, [sp, #0x78]
   140a8:      	ldp	x2, x24, [sp, #0x50]
   140ac:      	str	x21, [sp, #0x48]
   140b0:      	b	0x14104 <generic_lsm_path+0xa2b4>
   140b4:      	add	x2, x24, #0x10
   140b8:      	mov	w8, #0x4                // =4
   140bc:      	add	x9, sp, #0x98
   140c0:      	add	x0, sp, #0x98
   140c4:      	mov	w1, #0x8                // =8
   140c8:      	blr	x8
   140cc:      	ldr	x8, [sp, #0x58]
   140d0:      	ldr	x9, [sp, #0x98]
   140d4:      	cmp	x8, x9
   140d8:      	ldr	x25, [sp, #0x8]
   140dc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   140e0:      	add	x2, x24, #0x18
   140e4:      	mov	w8, #0x4                // =4
   140e8:      	mov	x0, x22
   140ec:      	mov	w1, #0x8                // =8
   140f0:      	blr	x8
   140f4:      	ldr	x24, [sp, #0x98]
   140f8:      	ldr	x21, [sp, #0x48]
   140fc:      	add	x2, x24, #0x20
   14100:      	stp	x2, x24, [sp, #0x50]
   14104:      	ldr	x8, [sp, #0x30]
   14108:      	ldr	x25, [sp, #0x8]
   1410c:      	add	x9, sp, #0x70
   14110:      	cmp	x21, x8
   14114:      	b.ne	0x14124 <generic_lsm_path+0xa2d4>
   14118:      	ldr	x8, [sp, #0x38]
   1411c:      	cmp	x2, x8
   14120:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14124:      	mov	w8, #0x4                // =4
   14128:      	add	x0, sp, #0x70
   1412c:      	mov	w1, #0x8                // =8
   14130:      	blr	x8
   14134:      	ldr	x8, [sp, #0x70]
   14138:      	cmp	x21, x8
   1413c:      	b.eq	0x14230 <generic_lsm_path+0xa3e0>
   14140:      	add	x23, x21, #0x18
   14144:      	mov	w8, #0x4                // =4
   14148:      	add	x9, sp, #0x98
   1414c:      	add	x0, sp, #0x98
   14150:      	mov	w1, #0x8                // =8
   14154:      	mov	x2, x23
   14158:      	blr	x8
   1415c:      	ldr	x8, [sp, #0x98]
   14160:      	cmp	x8, x21
   14164:      	b.eq	0x14230 <generic_lsm_path+0xa3e0>
   14168:      	mov	w8, #0x4                // =4
   1416c:      	add	x9, sp, #0x78
   14170:      	add	x0, sp, #0x78
   14174:      	mov	w1, #0x8                // =8
   14178:      	mov	x2, x23
   1417c:      	blr	x8
   14180:      	add	x2, x21, #0x20
   14184:      	mov	w8, #0x4                // =4
   14188:      	mov	w9, #0x10               // =16
   1418c:      	add	x10, sp, #0x80
   14190:      	add	x0, sp, #0x80
   14194:      	mov	w1, #0x10               // =16
   14198:      	blr	x8
   1419c:      	ldr	w21, [sp, #0x84]
   141a0:      	ldr	x8, [sp, #0x40]
   141a4:      	ldr	x10, [sp, #0x60]
   141a8:      	sub	x12, x10, x8
   141ac:      	ldr	w23, [sp, #0x68]
   141b0:      	subs	w10, w21, w23
   141b4:      	ldr	x9, [sp, #0x88]
   141b8:      	ldr	x25, [sp, #0x8]
   141bc:      	csel	w10, wzr, w10, lo
   141c0:      	cmp	w23, w21
   141c4:      	csel	w11, w23, w21, lo
   141c8:      	cinc	w13, w11, hi
   141cc:      	sub	w14, w23, w13
   141d0:      	subs	x12, x12, x13
   141d4:      	str	w14, [sp, #0x68]
   141d8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   141dc:      	cmp	x12, #0xfff
   141e0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   141e4:      	cmp	w23, w21
   141e8:      	b.ls	0x141f4 <generic_lsm_path+0xa3a4>
   141ec:      	mov	w13, #0x2f              // =47
   141f0:      	strb	w13, [x8, x12]
   141f4:      	add	x19, x8, x12
   141f8:      	cmp	w23, w21
   141fc:      	add	x2, x9, x10
   14200:      	and	w1, w11, #0xff
   14204:      	mov	w8, #0x4                // =4
   14208:      	cinc	x0, x19, hi
   1420c:      	blr	x8
   14210:      	ldr	x25, [sp, #0x8]
   14214:      	cmp	w23, w21
   14218:      	str	x19, [sp, #0x60]
   1421c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14220:      	ldr	x21, [sp, #0x78]
   14224:      	ldp	x2, x24, [sp, #0x50]
   14228:      	str	x21, [sp, #0x48]
   1422c:      	b	0x14280 <generic_lsm_path+0xa430>
   14230:      	add	x2, x24, #0x10
   14234:      	mov	w8, #0x4                // =4
   14238:      	add	x9, sp, #0x98
   1423c:      	add	x0, sp, #0x98
   14240:      	mov	w1, #0x8                // =8
   14244:      	blr	x8
   14248:      	ldr	x8, [sp, #0x58]
   1424c:      	ldr	x9, [sp, #0x98]
   14250:      	cmp	x8, x9
   14254:      	ldr	x25, [sp, #0x8]
   14258:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1425c:      	add	x2, x24, #0x18
   14260:      	mov	w8, #0x4                // =4
   14264:      	mov	x0, x22
   14268:      	mov	w1, #0x8                // =8
   1426c:      	blr	x8
   14270:      	ldr	x24, [sp, #0x98]
   14274:      	ldr	x21, [sp, #0x48]
   14278:      	add	x2, x24, #0x20
   1427c:      	stp	x2, x24, [sp, #0x50]
   14280:      	ldr	x8, [sp, #0x30]
   14284:      	ldr	x25, [sp, #0x8]
   14288:      	add	x9, sp, #0x70
   1428c:      	cmp	x21, x8
   14290:      	b.ne	0x142a0 <generic_lsm_path+0xa450>
   14294:      	ldr	x8, [sp, #0x38]
   14298:      	cmp	x2, x8
   1429c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   142a0:      	mov	w8, #0x4                // =4
   142a4:      	add	x0, sp, #0x70
   142a8:      	mov	w1, #0x8                // =8
   142ac:      	blr	x8
   142b0:      	ldr	x8, [sp, #0x70]
   142b4:      	cmp	x21, x8
   142b8:      	b.eq	0x143ac <generic_lsm_path+0xa55c>
   142bc:      	add	x23, x21, #0x18
   142c0:      	mov	w8, #0x4                // =4
   142c4:      	add	x9, sp, #0x98
   142c8:      	add	x0, sp, #0x98
   142cc:      	mov	w1, #0x8                // =8
   142d0:      	mov	x2, x23
   142d4:      	blr	x8
   142d8:      	ldr	x8, [sp, #0x98]
   142dc:      	cmp	x8, x21
   142e0:      	b.eq	0x143ac <generic_lsm_path+0xa55c>
   142e4:      	mov	w8, #0x4                // =4
   142e8:      	add	x9, sp, #0x78
   142ec:      	add	x0, sp, #0x78
   142f0:      	mov	w1, #0x8                // =8
   142f4:      	mov	x2, x23
   142f8:      	blr	x8
   142fc:      	add	x2, x21, #0x20
   14300:      	mov	w8, #0x4                // =4
   14304:      	mov	w9, #0x10               // =16
   14308:      	add	x10, sp, #0x80
   1430c:      	add	x0, sp, #0x80
   14310:      	mov	w1, #0x10               // =16
   14314:      	blr	x8
   14318:      	ldr	w21, [sp, #0x84]
   1431c:      	ldr	x8, [sp, #0x40]
   14320:      	ldr	x10, [sp, #0x60]
   14324:      	sub	x12, x10, x8
   14328:      	ldr	w23, [sp, #0x68]
   1432c:      	subs	w10, w21, w23
   14330:      	ldr	x9, [sp, #0x88]
   14334:      	ldr	x25, [sp, #0x8]
   14338:      	csel	w10, wzr, w10, lo
   1433c:      	cmp	w23, w21
   14340:      	csel	w11, w23, w21, lo
   14344:      	cinc	w13, w11, hi
   14348:      	sub	w14, w23, w13
   1434c:      	subs	x12, x12, x13
   14350:      	str	w14, [sp, #0x68]
   14354:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14358:      	cmp	x12, #0xfff
   1435c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14360:      	cmp	w23, w21
   14364:      	b.ls	0x14370 <generic_lsm_path+0xa520>
   14368:      	mov	w13, #0x2f              // =47
   1436c:      	strb	w13, [x8, x12]
   14370:      	add	x19, x8, x12
   14374:      	cmp	w23, w21
   14378:      	add	x2, x9, x10
   1437c:      	and	w1, w11, #0xff
   14380:      	mov	w8, #0x4                // =4
   14384:      	cinc	x0, x19, hi
   14388:      	blr	x8
   1438c:      	ldr	x25, [sp, #0x8]
   14390:      	cmp	w23, w21
   14394:      	str	x19, [sp, #0x60]
   14398:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1439c:      	ldr	x21, [sp, #0x78]
   143a0:      	ldp	x2, x24, [sp, #0x50]
   143a4:      	str	x21, [sp, #0x48]
   143a8:      	b	0x143fc <generic_lsm_path+0xa5ac>
   143ac:      	add	x2, x24, #0x10
   143b0:      	mov	w8, #0x4                // =4
   143b4:      	add	x9, sp, #0x98
   143b8:      	add	x0, sp, #0x98
   143bc:      	mov	w1, #0x8                // =8
   143c0:      	blr	x8
   143c4:      	ldr	x8, [sp, #0x58]
   143c8:      	ldr	x9, [sp, #0x98]
   143cc:      	cmp	x8, x9
   143d0:      	ldr	x25, [sp, #0x8]
   143d4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   143d8:      	add	x2, x24, #0x18
   143dc:      	mov	w8, #0x4                // =4
   143e0:      	mov	x0, x22
   143e4:      	mov	w1, #0x8                // =8
   143e8:      	blr	x8
   143ec:      	ldr	x24, [sp, #0x98]
   143f0:      	ldr	x21, [sp, #0x48]
   143f4:      	add	x2, x24, #0x20
   143f8:      	stp	x2, x24, [sp, #0x50]
   143fc:      	ldr	x8, [sp, #0x30]
   14400:      	ldr	x25, [sp, #0x8]
   14404:      	add	x9, sp, #0x70
   14408:      	cmp	x21, x8
   1440c:      	b.ne	0x1441c <generic_lsm_path+0xa5cc>
   14410:      	ldr	x8, [sp, #0x38]
   14414:      	cmp	x2, x8
   14418:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1441c:      	mov	w8, #0x4                // =4
   14420:      	add	x0, sp, #0x70
   14424:      	mov	w1, #0x8                // =8
   14428:      	blr	x8
   1442c:      	ldr	x8, [sp, #0x70]
   14430:      	cmp	x21, x8
   14434:      	b.eq	0x14528 <generic_lsm_path+0xa6d8>
   14438:      	add	x23, x21, #0x18
   1443c:      	mov	w8, #0x4                // =4
   14440:      	add	x9, sp, #0x98
   14444:      	add	x0, sp, #0x98
   14448:      	mov	w1, #0x8                // =8
   1444c:      	mov	x2, x23
   14450:      	blr	x8
   14454:      	ldr	x8, [sp, #0x98]
   14458:      	cmp	x8, x21
   1445c:      	b.eq	0x14528 <generic_lsm_path+0xa6d8>
   14460:      	mov	w8, #0x4                // =4
   14464:      	add	x9, sp, #0x78
   14468:      	add	x0, sp, #0x78
   1446c:      	mov	w1, #0x8                // =8
   14470:      	mov	x2, x23
   14474:      	blr	x8
   14478:      	add	x2, x21, #0x20
   1447c:      	mov	w8, #0x4                // =4
   14480:      	mov	w9, #0x10               // =16
   14484:      	add	x10, sp, #0x80
   14488:      	add	x0, sp, #0x80
   1448c:      	mov	w1, #0x10               // =16
   14490:      	blr	x8
   14494:      	ldr	w21, [sp, #0x84]
   14498:      	ldr	x8, [sp, #0x40]
   1449c:      	ldr	x10, [sp, #0x60]
   144a0:      	sub	x12, x10, x8
   144a4:      	ldr	w23, [sp, #0x68]
   144a8:      	subs	w10, w21, w23
   144ac:      	ldr	x9, [sp, #0x88]
   144b0:      	ldr	x25, [sp, #0x8]
   144b4:      	csel	w10, wzr, w10, lo
   144b8:      	cmp	w23, w21
   144bc:      	csel	w11, w23, w21, lo
   144c0:      	cinc	w13, w11, hi
   144c4:      	sub	w14, w23, w13
   144c8:      	subs	x12, x12, x13
   144cc:      	str	w14, [sp, #0x68]
   144d0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   144d4:      	cmp	x12, #0xfff
   144d8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   144dc:      	cmp	w23, w21
   144e0:      	b.ls	0x144ec <generic_lsm_path+0xa69c>
   144e4:      	mov	w13, #0x2f              // =47
   144e8:      	strb	w13, [x8, x12]
   144ec:      	add	x19, x8, x12
   144f0:      	cmp	w23, w21
   144f4:      	add	x2, x9, x10
   144f8:      	and	w1, w11, #0xff
   144fc:      	mov	w8, #0x4                // =4
   14500:      	cinc	x0, x19, hi
   14504:      	blr	x8
   14508:      	ldr	x25, [sp, #0x8]
   1450c:      	cmp	w23, w21
   14510:      	str	x19, [sp, #0x60]
   14514:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14518:      	ldr	x21, [sp, #0x78]
   1451c:      	ldp	x2, x24, [sp, #0x50]
   14520:      	str	x21, [sp, #0x48]
   14524:      	b	0x14578 <generic_lsm_path+0xa728>
   14528:      	add	x2, x24, #0x10
   1452c:      	mov	w8, #0x4                // =4
   14530:      	add	x9, sp, #0x98
   14534:      	add	x0, sp, #0x98
   14538:      	mov	w1, #0x8                // =8
   1453c:      	blr	x8
   14540:      	ldr	x8, [sp, #0x58]
   14544:      	ldr	x9, [sp, #0x98]
   14548:      	cmp	x8, x9
   1454c:      	ldr	x25, [sp, #0x8]
   14550:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14554:      	add	x2, x24, #0x18
   14558:      	mov	w8, #0x4                // =4
   1455c:      	mov	x0, x22
   14560:      	mov	w1, #0x8                // =8
   14564:      	blr	x8
   14568:      	ldr	x24, [sp, #0x98]
   1456c:      	ldr	x21, [sp, #0x48]
   14570:      	add	x2, x24, #0x20
   14574:      	stp	x2, x24, [sp, #0x50]
   14578:      	ldr	x8, [sp, #0x30]
   1457c:      	ldr	x25, [sp, #0x8]
   14580:      	add	x9, sp, #0x70
   14584:      	cmp	x21, x8
   14588:      	b.ne	0x14598 <generic_lsm_path+0xa748>
   1458c:      	ldr	x8, [sp, #0x38]
   14590:      	cmp	x2, x8
   14594:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14598:      	mov	w8, #0x4                // =4
   1459c:      	add	x0, sp, #0x70
   145a0:      	mov	w1, #0x8                // =8
   145a4:      	blr	x8
   145a8:      	ldr	x8, [sp, #0x70]
   145ac:      	cmp	x21, x8
   145b0:      	b.eq	0x146a4 <generic_lsm_path+0xa854>
   145b4:      	add	x23, x21, #0x18
   145b8:      	mov	w8, #0x4                // =4
   145bc:      	add	x9, sp, #0x98
   145c0:      	add	x0, sp, #0x98
   145c4:      	mov	w1, #0x8                // =8
   145c8:      	mov	x2, x23
   145cc:      	blr	x8
   145d0:      	ldr	x8, [sp, #0x98]
   145d4:      	cmp	x8, x21
   145d8:      	b.eq	0x146a4 <generic_lsm_path+0xa854>
   145dc:      	mov	w8, #0x4                // =4
   145e0:      	add	x9, sp, #0x78
   145e4:      	add	x0, sp, #0x78
   145e8:      	mov	w1, #0x8                // =8
   145ec:      	mov	x2, x23
   145f0:      	blr	x8
   145f4:      	add	x2, x21, #0x20
   145f8:      	mov	w8, #0x4                // =4
   145fc:      	mov	w9, #0x10               // =16
   14600:      	add	x10, sp, #0x80
   14604:      	add	x0, sp, #0x80
   14608:      	mov	w1, #0x10               // =16
   1460c:      	blr	x8
   14610:      	ldr	w21, [sp, #0x84]
   14614:      	ldr	x8, [sp, #0x40]
   14618:      	ldr	x10, [sp, #0x60]
   1461c:      	sub	x12, x10, x8
   14620:      	ldr	w23, [sp, #0x68]
   14624:      	subs	w10, w21, w23
   14628:      	ldr	x9, [sp, #0x88]
   1462c:      	ldr	x25, [sp, #0x8]
   14630:      	csel	w10, wzr, w10, lo
   14634:      	cmp	w23, w21
   14638:      	csel	w11, w23, w21, lo
   1463c:      	cinc	w13, w11, hi
   14640:      	sub	w14, w23, w13
   14644:      	subs	x12, x12, x13
   14648:      	str	w14, [sp, #0x68]
   1464c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14650:      	cmp	x12, #0xfff
   14654:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14658:      	cmp	w23, w21
   1465c:      	b.ls	0x14668 <generic_lsm_path+0xa818>
   14660:      	mov	w13, #0x2f              // =47
   14664:      	strb	w13, [x8, x12]
   14668:      	add	x19, x8, x12
   1466c:      	cmp	w23, w21
   14670:      	add	x2, x9, x10
   14674:      	and	w1, w11, #0xff
   14678:      	mov	w8, #0x4                // =4
   1467c:      	cinc	x0, x19, hi
   14680:      	blr	x8
   14684:      	ldr	x25, [sp, #0x8]
   14688:      	cmp	w23, w21
   1468c:      	str	x19, [sp, #0x60]
   14690:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14694:      	ldr	x21, [sp, #0x78]
   14698:      	ldp	x2, x24, [sp, #0x50]
   1469c:      	str	x21, [sp, #0x48]
   146a0:      	b	0x146f4 <generic_lsm_path+0xa8a4>
   146a4:      	add	x2, x24, #0x10
   146a8:      	mov	w8, #0x4                // =4
   146ac:      	add	x9, sp, #0x98
   146b0:      	add	x0, sp, #0x98
   146b4:      	mov	w1, #0x8                // =8
   146b8:      	blr	x8
   146bc:      	ldr	x8, [sp, #0x58]
   146c0:      	ldr	x9, [sp, #0x98]
   146c4:      	cmp	x8, x9
   146c8:      	ldr	x25, [sp, #0x8]
   146cc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   146d0:      	add	x2, x24, #0x18
   146d4:      	mov	w8, #0x4                // =4
   146d8:      	mov	x0, x22
   146dc:      	mov	w1, #0x8                // =8
   146e0:      	blr	x8
   146e4:      	ldr	x24, [sp, #0x98]
   146e8:      	ldr	x21, [sp, #0x48]
   146ec:      	add	x2, x24, #0x20
   146f0:      	stp	x2, x24, [sp, #0x50]
   146f4:      	ldr	x8, [sp, #0x30]
   146f8:      	ldr	x25, [sp, #0x8]
   146fc:      	add	x9, sp, #0x70
   14700:      	cmp	x21, x8
   14704:      	b.ne	0x14714 <generic_lsm_path+0xa8c4>
   14708:      	ldr	x8, [sp, #0x38]
   1470c:      	cmp	x2, x8
   14710:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14714:      	mov	w8, #0x4                // =4
   14718:      	add	x0, sp, #0x70
   1471c:      	mov	w1, #0x8                // =8
   14720:      	blr	x8
   14724:      	ldr	x8, [sp, #0x70]
   14728:      	cmp	x21, x8
   1472c:      	b.eq	0x14820 <generic_lsm_path+0xa9d0>
   14730:      	add	x23, x21, #0x18
   14734:      	mov	w8, #0x4                // =4
   14738:      	add	x9, sp, #0x98
   1473c:      	add	x0, sp, #0x98
   14740:      	mov	w1, #0x8                // =8
   14744:      	mov	x2, x23
   14748:      	blr	x8
   1474c:      	ldr	x8, [sp, #0x98]
   14750:      	cmp	x8, x21
   14754:      	b.eq	0x14820 <generic_lsm_path+0xa9d0>
   14758:      	mov	w8, #0x4                // =4
   1475c:      	add	x9, sp, #0x78
   14760:      	add	x0, sp, #0x78
   14764:      	mov	w1, #0x8                // =8
   14768:      	mov	x2, x23
   1476c:      	blr	x8
   14770:      	add	x2, x21, #0x20
   14774:      	mov	w8, #0x4                // =4
   14778:      	mov	w9, #0x10               // =16
   1477c:      	add	x10, sp, #0x80
   14780:      	add	x0, sp, #0x80
   14784:      	mov	w1, #0x10               // =16
   14788:      	blr	x8
   1478c:      	ldr	w21, [sp, #0x84]
   14790:      	ldr	x8, [sp, #0x40]
   14794:      	ldr	x10, [sp, #0x60]
   14798:      	sub	x12, x10, x8
   1479c:      	ldr	w23, [sp, #0x68]
   147a0:      	subs	w10, w21, w23
   147a4:      	ldr	x9, [sp, #0x88]
   147a8:      	ldr	x25, [sp, #0x8]
   147ac:      	csel	w10, wzr, w10, lo
   147b0:      	cmp	w23, w21
   147b4:      	csel	w11, w23, w21, lo
   147b8:      	cinc	w13, w11, hi
   147bc:      	sub	w14, w23, w13
   147c0:      	subs	x12, x12, x13
   147c4:      	str	w14, [sp, #0x68]
   147c8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   147cc:      	cmp	x12, #0xfff
   147d0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   147d4:      	cmp	w23, w21
   147d8:      	b.ls	0x147e4 <generic_lsm_path+0xa994>
   147dc:      	mov	w13, #0x2f              // =47
   147e0:      	strb	w13, [x8, x12]
   147e4:      	add	x19, x8, x12
   147e8:      	cmp	w23, w21
   147ec:      	add	x2, x9, x10
   147f0:      	and	w1, w11, #0xff
   147f4:      	mov	w8, #0x4                // =4
   147f8:      	cinc	x0, x19, hi
   147fc:      	blr	x8
   14800:      	ldr	x25, [sp, #0x8]
   14804:      	cmp	w23, w21
   14808:      	str	x19, [sp, #0x60]
   1480c:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14810:      	ldr	x21, [sp, #0x78]
   14814:      	ldp	x2, x24, [sp, #0x50]
   14818:      	str	x21, [sp, #0x48]
   1481c:      	b	0x14870 <generic_lsm_path+0xaa20>
   14820:      	add	x2, x24, #0x10
   14824:      	mov	w8, #0x4                // =4
   14828:      	add	x9, sp, #0x98
   1482c:      	add	x0, sp, #0x98
   14830:      	mov	w1, #0x8                // =8
   14834:      	blr	x8
   14838:      	ldr	x8, [sp, #0x58]
   1483c:      	ldr	x9, [sp, #0x98]
   14840:      	cmp	x8, x9
   14844:      	ldr	x25, [sp, #0x8]
   14848:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1484c:      	add	x2, x24, #0x18
   14850:      	mov	w8, #0x4                // =4
   14854:      	mov	x0, x22
   14858:      	mov	w1, #0x8                // =8
   1485c:      	blr	x8
   14860:      	ldr	x24, [sp, #0x98]
   14864:      	ldr	x21, [sp, #0x48]
   14868:      	add	x2, x24, #0x20
   1486c:      	stp	x2, x24, [sp, #0x50]
   14870:      	ldr	x8, [sp, #0x30]
   14874:      	ldr	x25, [sp, #0x8]
   14878:      	add	x9, sp, #0x70
   1487c:      	cmp	x21, x8
   14880:      	b.ne	0x14890 <generic_lsm_path+0xaa40>
   14884:      	ldr	x8, [sp, #0x38]
   14888:      	cmp	x2, x8
   1488c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14890:      	mov	w8, #0x4                // =4
   14894:      	add	x0, sp, #0x70
   14898:      	mov	w1, #0x8                // =8
   1489c:      	blr	x8
   148a0:      	ldr	x8, [sp, #0x70]
   148a4:      	cmp	x21, x8
   148a8:      	b.eq	0x1499c <generic_lsm_path+0xab4c>
   148ac:      	add	x23, x21, #0x18
   148b0:      	mov	w8, #0x4                // =4
   148b4:      	add	x9, sp, #0x98
   148b8:      	add	x0, sp, #0x98
   148bc:      	mov	w1, #0x8                // =8
   148c0:      	mov	x2, x23
   148c4:      	blr	x8
   148c8:      	ldr	x8, [sp, #0x98]
   148cc:      	cmp	x8, x21
   148d0:      	b.eq	0x1499c <generic_lsm_path+0xab4c>
   148d4:      	mov	w8, #0x4                // =4
   148d8:      	add	x9, sp, #0x78
   148dc:      	add	x0, sp, #0x78
   148e0:      	mov	w1, #0x8                // =8
   148e4:      	mov	x2, x23
   148e8:      	blr	x8
   148ec:      	add	x2, x21, #0x20
   148f0:      	mov	w8, #0x4                // =4
   148f4:      	mov	w9, #0x10               // =16
   148f8:      	add	x10, sp, #0x80
   148fc:      	add	x0, sp, #0x80
   14900:      	mov	w1, #0x10               // =16
   14904:      	blr	x8
   14908:      	ldr	w21, [sp, #0x84]
   1490c:      	ldr	x8, [sp, #0x40]
   14910:      	ldr	x10, [sp, #0x60]
   14914:      	sub	x12, x10, x8
   14918:      	ldr	w23, [sp, #0x68]
   1491c:      	subs	w10, w21, w23
   14920:      	ldr	x9, [sp, #0x88]
   14924:      	ldr	x25, [sp, #0x8]
   14928:      	csel	w10, wzr, w10, lo
   1492c:      	cmp	w23, w21
   14930:      	csel	w11, w23, w21, lo
   14934:      	cinc	w13, w11, hi
   14938:      	sub	w14, w23, w13
   1493c:      	subs	x12, x12, x13
   14940:      	str	w14, [sp, #0x68]
   14944:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14948:      	cmp	x12, #0xfff
   1494c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14950:      	cmp	w23, w21
   14954:      	b.ls	0x14960 <generic_lsm_path+0xab10>
   14958:      	mov	w13, #0x2f              // =47
   1495c:      	strb	w13, [x8, x12]
   14960:      	add	x19, x8, x12
   14964:      	cmp	w23, w21
   14968:      	add	x2, x9, x10
   1496c:      	and	w1, w11, #0xff
   14970:      	mov	w8, #0x4                // =4
   14974:      	cinc	x0, x19, hi
   14978:      	blr	x8
   1497c:      	ldr	x25, [sp, #0x8]
   14980:      	cmp	w23, w21
   14984:      	str	x19, [sp, #0x60]
   14988:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1498c:      	ldr	x21, [sp, #0x78]
   14990:      	ldp	x2, x24, [sp, #0x50]
   14994:      	str	x21, [sp, #0x48]
   14998:      	b	0x149ec <generic_lsm_path+0xab9c>
   1499c:      	add	x2, x24, #0x10
   149a0:      	mov	w8, #0x4                // =4
   149a4:      	add	x9, sp, #0x98
   149a8:      	add	x0, sp, #0x98
   149ac:      	mov	w1, #0x8                // =8
   149b0:      	blr	x8
   149b4:      	ldr	x8, [sp, #0x58]
   149b8:      	ldr	x9, [sp, #0x98]
   149bc:      	cmp	x8, x9
   149c0:      	ldr	x25, [sp, #0x8]
   149c4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   149c8:      	add	x2, x24, #0x18
   149cc:      	mov	w8, #0x4                // =4
   149d0:      	mov	x0, x22
   149d4:      	mov	w1, #0x8                // =8
   149d8:      	blr	x8
   149dc:      	ldr	x24, [sp, #0x98]
   149e0:      	ldr	x21, [sp, #0x48]
   149e4:      	add	x2, x24, #0x20
   149e8:      	stp	x2, x24, [sp, #0x50]
   149ec:      	ldr	x8, [sp, #0x30]
   149f0:      	ldr	x25, [sp, #0x8]
   149f4:      	add	x9, sp, #0x70
   149f8:      	cmp	x21, x8
   149fc:      	b.ne	0x14a0c <generic_lsm_path+0xabbc>
   14a00:      	ldr	x8, [sp, #0x38]
   14a04:      	cmp	x2, x8
   14a08:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14a0c:      	mov	w8, #0x4                // =4
   14a10:      	add	x0, sp, #0x70
   14a14:      	mov	w1, #0x8                // =8
   14a18:      	blr	x8
   14a1c:      	ldr	x8, [sp, #0x70]
   14a20:      	cmp	x21, x8
   14a24:      	b.eq	0x14b18 <generic_lsm_path+0xacc8>
   14a28:      	add	x23, x21, #0x18
   14a2c:      	mov	w8, #0x4                // =4
   14a30:      	add	x9, sp, #0x98
   14a34:      	add	x0, sp, #0x98
   14a38:      	mov	w1, #0x8                // =8
   14a3c:      	mov	x2, x23
   14a40:      	blr	x8
   14a44:      	ldr	x8, [sp, #0x98]
   14a48:      	cmp	x8, x21
   14a4c:      	b.eq	0x14b18 <generic_lsm_path+0xacc8>
   14a50:      	mov	w8, #0x4                // =4
   14a54:      	add	x9, sp, #0x78
   14a58:      	add	x0, sp, #0x78
   14a5c:      	mov	w1, #0x8                // =8
   14a60:      	mov	x2, x23
   14a64:      	blr	x8
   14a68:      	add	x2, x21, #0x20
   14a6c:      	mov	w8, #0x4                // =4
   14a70:      	mov	w9, #0x10               // =16
   14a74:      	add	x10, sp, #0x80
   14a78:      	add	x0, sp, #0x80
   14a7c:      	mov	w1, #0x10               // =16
   14a80:      	blr	x8
   14a84:      	ldr	w21, [sp, #0x84]
   14a88:      	ldr	x8, [sp, #0x40]
   14a8c:      	ldr	x10, [sp, #0x60]
   14a90:      	sub	x12, x10, x8
   14a94:      	ldr	w23, [sp, #0x68]
   14a98:      	subs	w10, w21, w23
   14a9c:      	ldr	x9, [sp, #0x88]
   14aa0:      	ldr	x25, [sp, #0x8]
   14aa4:      	csel	w10, wzr, w10, lo
   14aa8:      	cmp	w23, w21
   14aac:      	csel	w11, w23, w21, lo
   14ab0:      	cinc	w13, w11, hi
   14ab4:      	sub	w14, w23, w13
   14ab8:      	subs	x12, x12, x13
   14abc:      	str	w14, [sp, #0x68]
   14ac0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14ac4:      	cmp	x12, #0xfff
   14ac8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14acc:      	cmp	w23, w21
   14ad0:      	b.ls	0x14adc <generic_lsm_path+0xac8c>
   14ad4:      	mov	w13, #0x2f              // =47
   14ad8:      	strb	w13, [x8, x12]
   14adc:      	add	x19, x8, x12
   14ae0:      	cmp	w23, w21
   14ae4:      	add	x2, x9, x10
   14ae8:      	and	w1, w11, #0xff
   14aec:      	mov	w8, #0x4                // =4
   14af0:      	cinc	x0, x19, hi
   14af4:      	blr	x8
   14af8:      	ldr	x25, [sp, #0x8]
   14afc:      	cmp	w23, w21
   14b00:      	str	x19, [sp, #0x60]
   14b04:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14b08:      	ldr	x21, [sp, #0x78]
   14b0c:      	ldp	x2, x24, [sp, #0x50]
   14b10:      	str	x21, [sp, #0x48]
   14b14:      	b	0x14b68 <generic_lsm_path+0xad18>
   14b18:      	add	x2, x24, #0x10
   14b1c:      	mov	w8, #0x4                // =4
   14b20:      	add	x9, sp, #0x98
   14b24:      	add	x0, sp, #0x98
   14b28:      	mov	w1, #0x8                // =8
   14b2c:      	blr	x8
   14b30:      	ldr	x8, [sp, #0x58]
   14b34:      	ldr	x9, [sp, #0x98]
   14b38:      	cmp	x8, x9
   14b3c:      	ldr	x25, [sp, #0x8]
   14b40:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14b44:      	add	x2, x24, #0x18
   14b48:      	mov	w8, #0x4                // =4
   14b4c:      	mov	x0, x22
   14b50:      	mov	w1, #0x8                // =8
   14b54:      	blr	x8
   14b58:      	ldr	x24, [sp, #0x98]
   14b5c:      	ldr	x21, [sp, #0x48]
   14b60:      	add	x2, x24, #0x20
   14b64:      	stp	x2, x24, [sp, #0x50]
   14b68:      	ldr	x8, [sp, #0x30]
   14b6c:      	ldr	x25, [sp, #0x8]
   14b70:      	add	x9, sp, #0x70
   14b74:      	cmp	x21, x8
   14b78:      	b.ne	0x14b88 <generic_lsm_path+0xad38>
   14b7c:      	ldr	x8, [sp, #0x38]
   14b80:      	cmp	x2, x8
   14b84:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14b88:      	mov	w8, #0x4                // =4
   14b8c:      	add	x0, sp, #0x70
   14b90:      	mov	w1, #0x8                // =8
   14b94:      	blr	x8
   14b98:      	ldr	x8, [sp, #0x70]
   14b9c:      	cmp	x21, x8
   14ba0:      	b.eq	0x14c94 <generic_lsm_path+0xae44>
   14ba4:      	add	x23, x21, #0x18
   14ba8:      	mov	w8, #0x4                // =4
   14bac:      	add	x9, sp, #0x98
   14bb0:      	add	x0, sp, #0x98
   14bb4:      	mov	w1, #0x8                // =8
   14bb8:      	mov	x2, x23
   14bbc:      	blr	x8
   14bc0:      	ldr	x8, [sp, #0x98]
   14bc4:      	cmp	x8, x21
   14bc8:      	b.eq	0x14c94 <generic_lsm_path+0xae44>
   14bcc:      	mov	w8, #0x4                // =4
   14bd0:      	add	x9, sp, #0x78
   14bd4:      	add	x0, sp, #0x78
   14bd8:      	mov	w1, #0x8                // =8
   14bdc:      	mov	x2, x23
   14be0:      	blr	x8
   14be4:      	add	x2, x21, #0x20
   14be8:      	mov	w8, #0x4                // =4
   14bec:      	mov	w9, #0x10               // =16
   14bf0:      	add	x10, sp, #0x80
   14bf4:      	add	x0, sp, #0x80
   14bf8:      	mov	w1, #0x10               // =16
   14bfc:      	blr	x8
   14c00:      	ldr	w21, [sp, #0x84]
   14c04:      	ldr	x8, [sp, #0x40]
   14c08:      	ldr	x10, [sp, #0x60]
   14c0c:      	sub	x12, x10, x8
   14c10:      	ldr	w23, [sp, #0x68]
   14c14:      	subs	w10, w21, w23
   14c18:      	ldr	x9, [sp, #0x88]
   14c1c:      	ldr	x25, [sp, #0x8]
   14c20:      	csel	w10, wzr, w10, lo
   14c24:      	cmp	w23, w21
   14c28:      	csel	w11, w23, w21, lo
   14c2c:      	cinc	w13, w11, hi
   14c30:      	sub	w14, w23, w13
   14c34:      	subs	x12, x12, x13
   14c38:      	str	w14, [sp, #0x68]
   14c3c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14c40:      	cmp	x12, #0xfff
   14c44:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14c48:      	cmp	w23, w21
   14c4c:      	b.ls	0x14c58 <generic_lsm_path+0xae08>
   14c50:      	mov	w13, #0x2f              // =47
   14c54:      	strb	w13, [x8, x12]
   14c58:      	add	x19, x8, x12
   14c5c:      	cmp	w23, w21
   14c60:      	add	x2, x9, x10
   14c64:      	and	w1, w11, #0xff
   14c68:      	mov	w8, #0x4                // =4
   14c6c:      	cinc	x0, x19, hi
   14c70:      	blr	x8
   14c74:      	ldr	x25, [sp, #0x8]
   14c78:      	cmp	w23, w21
   14c7c:      	str	x19, [sp, #0x60]
   14c80:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14c84:      	ldr	x21, [sp, #0x78]
   14c88:      	ldp	x2, x24, [sp, #0x50]
   14c8c:      	str	x21, [sp, #0x48]
   14c90:      	b	0x14ce4 <generic_lsm_path+0xae94>
   14c94:      	add	x2, x24, #0x10
   14c98:      	mov	w8, #0x4                // =4
   14c9c:      	add	x9, sp, #0x98
   14ca0:      	add	x0, sp, #0x98
   14ca4:      	mov	w1, #0x8                // =8
   14ca8:      	blr	x8
   14cac:      	ldr	x8, [sp, #0x58]
   14cb0:      	ldr	x9, [sp, #0x98]
   14cb4:      	cmp	x8, x9
   14cb8:      	ldr	x25, [sp, #0x8]
   14cbc:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14cc0:      	add	x2, x24, #0x18
   14cc4:      	mov	w8, #0x4                // =4
   14cc8:      	mov	x0, x22
   14ccc:      	mov	w1, #0x8                // =8
   14cd0:      	blr	x8
   14cd4:      	ldr	x24, [sp, #0x98]
   14cd8:      	ldr	x21, [sp, #0x48]
   14cdc:      	add	x2, x24, #0x20
   14ce0:      	stp	x2, x24, [sp, #0x50]
   14ce4:      	ldr	x8, [sp, #0x30]
   14ce8:      	ldr	x25, [sp, #0x8]
   14cec:      	add	x9, sp, #0x70
   14cf0:      	cmp	x21, x8
   14cf4:      	b.ne	0x14d04 <generic_lsm_path+0xaeb4>
   14cf8:      	ldr	x8, [sp, #0x38]
   14cfc:      	cmp	x2, x8
   14d00:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14d04:      	mov	w8, #0x4                // =4
   14d08:      	add	x0, sp, #0x70
   14d0c:      	mov	w1, #0x8                // =8
   14d10:      	blr	x8
   14d14:      	ldr	x8, [sp, #0x70]
   14d18:      	cmp	x21, x8
   14d1c:      	b.eq	0x14e10 <generic_lsm_path+0xafc0>
   14d20:      	add	x23, x21, #0x18
   14d24:      	mov	w8, #0x4                // =4
   14d28:      	add	x9, sp, #0x98
   14d2c:      	add	x0, sp, #0x98
   14d30:      	mov	w1, #0x8                // =8
   14d34:      	mov	x2, x23
   14d38:      	blr	x8
   14d3c:      	ldr	x8, [sp, #0x98]
   14d40:      	cmp	x8, x21
   14d44:      	b.eq	0x14e10 <generic_lsm_path+0xafc0>
   14d48:      	mov	w8, #0x4                // =4
   14d4c:      	add	x9, sp, #0x78
   14d50:      	add	x0, sp, #0x78
   14d54:      	mov	w1, #0x8                // =8
   14d58:      	mov	x2, x23
   14d5c:      	blr	x8
   14d60:      	add	x2, x21, #0x20
   14d64:      	mov	w8, #0x4                // =4
   14d68:      	mov	w9, #0x10               // =16
   14d6c:      	add	x10, sp, #0x80
   14d70:      	add	x0, sp, #0x80
   14d74:      	mov	w1, #0x10               // =16
   14d78:      	blr	x8
   14d7c:      	ldr	w21, [sp, #0x84]
   14d80:      	ldr	x8, [sp, #0x40]
   14d84:      	ldr	x10, [sp, #0x60]
   14d88:      	sub	x12, x10, x8
   14d8c:      	ldr	w23, [sp, #0x68]
   14d90:      	subs	w10, w21, w23
   14d94:      	ldr	x9, [sp, #0x88]
   14d98:      	ldr	x25, [sp, #0x8]
   14d9c:      	csel	w10, wzr, w10, lo
   14da0:      	cmp	w23, w21
   14da4:      	csel	w11, w23, w21, lo
   14da8:      	cinc	w13, w11, hi
   14dac:      	sub	w14, w23, w13
   14db0:      	subs	x12, x12, x13
   14db4:      	str	w14, [sp, #0x68]
   14db8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14dbc:      	cmp	x12, #0xfff
   14dc0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14dc4:      	cmp	w23, w21
   14dc8:      	b.ls	0x14dd4 <generic_lsm_path+0xaf84>
   14dcc:      	mov	w13, #0x2f              // =47
   14dd0:      	strb	w13, [x8, x12]
   14dd4:      	add	x19, x8, x12
   14dd8:      	cmp	w23, w21
   14ddc:      	add	x2, x9, x10
   14de0:      	and	w1, w11, #0xff
   14de4:      	mov	w8, #0x4                // =4
   14de8:      	cinc	x0, x19, hi
   14dec:      	blr	x8
   14df0:      	ldr	x25, [sp, #0x8]
   14df4:      	cmp	w23, w21
   14df8:      	str	x19, [sp, #0x60]
   14dfc:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14e00:      	ldr	x21, [sp, #0x78]
   14e04:      	ldp	x2, x24, [sp, #0x50]
   14e08:      	str	x21, [sp, #0x48]
   14e0c:      	b	0x14e60 <generic_lsm_path+0xb010>
   14e10:      	add	x2, x24, #0x10
   14e14:      	mov	w8, #0x4                // =4
   14e18:      	add	x9, sp, #0x98
   14e1c:      	add	x0, sp, #0x98
   14e20:      	mov	w1, #0x8                // =8
   14e24:      	blr	x8
   14e28:      	ldr	x8, [sp, #0x58]
   14e2c:      	ldr	x9, [sp, #0x98]
   14e30:      	cmp	x8, x9
   14e34:      	ldr	x25, [sp, #0x8]
   14e38:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14e3c:      	add	x2, x24, #0x18
   14e40:      	mov	w8, #0x4                // =4
   14e44:      	mov	x0, x22
   14e48:      	mov	w1, #0x8                // =8
   14e4c:      	blr	x8
   14e50:      	ldr	x24, [sp, #0x98]
   14e54:      	ldr	x21, [sp, #0x48]
   14e58:      	add	x2, x24, #0x20
   14e5c:      	stp	x2, x24, [sp, #0x50]
   14e60:      	ldr	x8, [sp, #0x30]
   14e64:      	ldr	x25, [sp, #0x8]
   14e68:      	add	x9, sp, #0x70
   14e6c:      	cmp	x21, x8
   14e70:      	b.ne	0x14e80 <generic_lsm_path+0xb030>
   14e74:      	ldr	x8, [sp, #0x38]
   14e78:      	cmp	x2, x8
   14e7c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14e80:      	mov	w8, #0x4                // =4
   14e84:      	add	x0, sp, #0x70
   14e88:      	mov	w1, #0x8                // =8
   14e8c:      	blr	x8
   14e90:      	ldr	x8, [sp, #0x70]
   14e94:      	cmp	x21, x8
   14e98:      	b.eq	0x14f8c <generic_lsm_path+0xb13c>
   14e9c:      	add	x23, x21, #0x18
   14ea0:      	mov	w8, #0x4                // =4
   14ea4:      	add	x9, sp, #0x98
   14ea8:      	add	x0, sp, #0x98
   14eac:      	mov	w1, #0x8                // =8
   14eb0:      	mov	x2, x23
   14eb4:      	blr	x8
   14eb8:      	ldr	x8, [sp, #0x98]
   14ebc:      	cmp	x8, x21
   14ec0:      	b.eq	0x14f8c <generic_lsm_path+0xb13c>
   14ec4:      	mov	w8, #0x4                // =4
   14ec8:      	add	x9, sp, #0x78
   14ecc:      	add	x0, sp, #0x78
   14ed0:      	mov	w1, #0x8                // =8
   14ed4:      	mov	x2, x23
   14ed8:      	blr	x8
   14edc:      	add	x2, x21, #0x20
   14ee0:      	mov	w8, #0x4                // =4
   14ee4:      	mov	w9, #0x10               // =16
   14ee8:      	add	x10, sp, #0x80
   14eec:      	add	x0, sp, #0x80
   14ef0:      	mov	w1, #0x10               // =16
   14ef4:      	blr	x8
   14ef8:      	ldr	w21, [sp, #0x84]
   14efc:      	ldr	x8, [sp, #0x40]
   14f00:      	ldr	x10, [sp, #0x60]
   14f04:      	sub	x12, x10, x8
   14f08:      	ldr	w23, [sp, #0x68]
   14f0c:      	subs	w10, w21, w23
   14f10:      	ldr	x9, [sp, #0x88]
   14f14:      	ldr	x25, [sp, #0x8]
   14f18:      	csel	w10, wzr, w10, lo
   14f1c:      	cmp	w23, w21
   14f20:      	csel	w11, w23, w21, lo
   14f24:      	cinc	w13, w11, hi
   14f28:      	sub	w14, w23, w13
   14f2c:      	subs	x12, x12, x13
   14f30:      	str	w14, [sp, #0x68]
   14f34:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   14f38:      	cmp	x12, #0xfff
   14f3c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   14f40:      	cmp	w23, w21
   14f44:      	b.ls	0x14f50 <generic_lsm_path+0xb100>
   14f48:      	mov	w13, #0x2f              // =47
   14f4c:      	strb	w13, [x8, x12]
   14f50:      	add	x19, x8, x12
   14f54:      	cmp	w23, w21
   14f58:      	add	x2, x9, x10
   14f5c:      	and	w1, w11, #0xff
   14f60:      	mov	w8, #0x4                // =4
   14f64:      	cinc	x0, x19, hi
   14f68:      	blr	x8
   14f6c:      	ldr	x25, [sp, #0x8]
   14f70:      	cmp	w23, w21
   14f74:      	str	x19, [sp, #0x60]
   14f78:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   14f7c:      	ldr	x21, [sp, #0x78]
   14f80:      	ldp	x2, x24, [sp, #0x50]
   14f84:      	str	x21, [sp, #0x48]
   14f88:      	b	0x14fdc <generic_lsm_path+0xb18c>
   14f8c:      	add	x2, x24, #0x10
   14f90:      	mov	w8, #0x4                // =4
   14f94:      	add	x9, sp, #0x98
   14f98:      	add	x0, sp, #0x98
   14f9c:      	mov	w1, #0x8                // =8
   14fa0:      	blr	x8
   14fa4:      	ldr	x8, [sp, #0x58]
   14fa8:      	ldr	x9, [sp, #0x98]
   14fac:      	cmp	x8, x9
   14fb0:      	ldr	x25, [sp, #0x8]
   14fb4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14fb8:      	add	x2, x24, #0x18
   14fbc:      	mov	w8, #0x4                // =4
   14fc0:      	mov	x0, x22
   14fc4:      	mov	w1, #0x8                // =8
   14fc8:      	blr	x8
   14fcc:      	ldr	x24, [sp, #0x98]
   14fd0:      	ldr	x21, [sp, #0x48]
   14fd4:      	add	x2, x24, #0x20
   14fd8:      	stp	x2, x24, [sp, #0x50]
   14fdc:      	ldr	x8, [sp, #0x30]
   14fe0:      	ldr	x25, [sp, #0x8]
   14fe4:      	add	x9, sp, #0x70
   14fe8:      	cmp	x21, x8
   14fec:      	b.ne	0x14ffc <generic_lsm_path+0xb1ac>
   14ff0:      	ldr	x8, [sp, #0x38]
   14ff4:      	cmp	x2, x8
   14ff8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   14ffc:      	mov	w8, #0x4                // =4
   15000:      	add	x0, sp, #0x70
   15004:      	mov	w1, #0x8                // =8
   15008:      	blr	x8
   1500c:      	ldr	x8, [sp, #0x70]
   15010:      	cmp	x21, x8
   15014:      	b.eq	0x15108 <generic_lsm_path+0xb2b8>
   15018:      	add	x23, x21, #0x18
   1501c:      	mov	w8, #0x4                // =4
   15020:      	add	x9, sp, #0x98
   15024:      	add	x0, sp, #0x98
   15028:      	mov	w1, #0x8                // =8
   1502c:      	mov	x2, x23
   15030:      	blr	x8
   15034:      	ldr	x8, [sp, #0x98]
   15038:      	cmp	x8, x21
   1503c:      	b.eq	0x15108 <generic_lsm_path+0xb2b8>
   15040:      	mov	w8, #0x4                // =4
   15044:      	add	x9, sp, #0x78
   15048:      	add	x0, sp, #0x78
   1504c:      	mov	w1, #0x8                // =8
   15050:      	mov	x2, x23
   15054:      	blr	x8
   15058:      	add	x2, x21, #0x20
   1505c:      	mov	w8, #0x4                // =4
   15060:      	mov	w9, #0x10               // =16
   15064:      	add	x10, sp, #0x80
   15068:      	add	x0, sp, #0x80
   1506c:      	mov	w1, #0x10               // =16
   15070:      	blr	x8
   15074:      	ldr	w21, [sp, #0x84]
   15078:      	ldr	x8, [sp, #0x40]
   1507c:      	ldr	x10, [sp, #0x60]
   15080:      	sub	x12, x10, x8
   15084:      	ldr	w23, [sp, #0x68]
   15088:      	subs	w10, w21, w23
   1508c:      	ldr	x9, [sp, #0x88]
   15090:      	ldr	x25, [sp, #0x8]
   15094:      	csel	w10, wzr, w10, lo
   15098:      	cmp	w23, w21
   1509c:      	csel	w11, w23, w21, lo
   150a0:      	cinc	w13, w11, hi
   150a4:      	sub	w14, w23, w13
   150a8:      	subs	x12, x12, x13
   150ac:      	str	w14, [sp, #0x68]
   150b0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   150b4:      	cmp	x12, #0xfff
   150b8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   150bc:      	cmp	w23, w21
   150c0:      	b.ls	0x150cc <generic_lsm_path+0xb27c>
   150c4:      	mov	w13, #0x2f              // =47
   150c8:      	strb	w13, [x8, x12]
   150cc:      	add	x19, x8, x12
   150d0:      	cmp	w23, w21
   150d4:      	add	x2, x9, x10
   150d8:      	and	w1, w11, #0xff
   150dc:      	mov	w8, #0x4                // =4
   150e0:      	cinc	x0, x19, hi
   150e4:      	blr	x8
   150e8:      	ldr	x25, [sp, #0x8]
   150ec:      	cmp	w23, w21
   150f0:      	str	x19, [sp, #0x60]
   150f4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   150f8:      	ldr	x21, [sp, #0x78]
   150fc:      	ldp	x2, x24, [sp, #0x50]
   15100:      	str	x21, [sp, #0x48]
   15104:      	b	0x15158 <generic_lsm_path+0xb308>
   15108:      	add	x2, x24, #0x10
   1510c:      	mov	w8, #0x4                // =4
   15110:      	add	x9, sp, #0x98
   15114:      	add	x0, sp, #0x98
   15118:      	mov	w1, #0x8                // =8
   1511c:      	blr	x8
   15120:      	ldr	x8, [sp, #0x58]
   15124:      	ldr	x9, [sp, #0x98]
   15128:      	cmp	x8, x9
   1512c:      	ldr	x25, [sp, #0x8]
   15130:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   15134:      	add	x2, x24, #0x18
   15138:      	mov	w8, #0x4                // =4
   1513c:      	mov	x0, x22
   15140:      	mov	w1, #0x8                // =8
   15144:      	blr	x8
   15148:      	ldr	x24, [sp, #0x98]
   1514c:      	ldr	x21, [sp, #0x48]
   15150:      	add	x2, x24, #0x20
   15154:      	stp	x2, x24, [sp, #0x50]
   15158:      	ldr	x8, [sp, #0x30]
   1515c:      	ldr	x25, [sp, #0x8]
   15160:      	add	x9, sp, #0x70
   15164:      	cmp	x21, x8
   15168:      	b.ne	0x15178 <generic_lsm_path+0xb328>
   1516c:      	ldr	x8, [sp, #0x38]
   15170:      	cmp	x2, x8
   15174:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   15178:      	mov	w8, #0x4                // =4
   1517c:      	add	x0, sp, #0x70
   15180:      	mov	w1, #0x8                // =8
   15184:      	blr	x8
   15188:      	ldr	x8, [sp, #0x70]
   1518c:      	cmp	x21, x8
   15190:      	b.eq	0x15284 <generic_lsm_path+0xb434>
   15194:      	add	x23, x21, #0x18
   15198:      	mov	w8, #0x4                // =4
   1519c:      	add	x9, sp, #0x98
   151a0:      	add	x0, sp, #0x98
   151a4:      	mov	w1, #0x8                // =8
   151a8:      	mov	x2, x23
   151ac:      	blr	x8
   151b0:      	ldr	x8, [sp, #0x98]
   151b4:      	cmp	x8, x21
   151b8:      	b.eq	0x15284 <generic_lsm_path+0xb434>
   151bc:      	mov	w8, #0x4                // =4
   151c0:      	add	x9, sp, #0x78
   151c4:      	add	x0, sp, #0x78
   151c8:      	mov	w1, #0x8                // =8
   151cc:      	mov	x2, x23
   151d0:      	blr	x8
   151d4:      	add	x2, x21, #0x20
   151d8:      	mov	w8, #0x4                // =4
   151dc:      	mov	w9, #0x10               // =16
   151e0:      	add	x10, sp, #0x80
   151e4:      	add	x0, sp, #0x80
   151e8:      	mov	w1, #0x10               // =16
   151ec:      	blr	x8
   151f0:      	ldr	w21, [sp, #0x84]
   151f4:      	ldr	x8, [sp, #0x40]
   151f8:      	ldr	x10, [sp, #0x60]
   151fc:      	sub	x12, x10, x8
   15200:      	ldr	w23, [sp, #0x68]
   15204:      	subs	w10, w21, w23
   15208:      	ldr	x9, [sp, #0x88]
   1520c:      	ldr	x25, [sp, #0x8]
   15210:      	csel	w10, wzr, w10, lo
   15214:      	cmp	w23, w21
   15218:      	csel	w11, w23, w21, lo
   1521c:      	cinc	w13, w11, hi
   15220:      	sub	w14, w23, w13
   15224:      	subs	x12, x12, x13
   15228:      	str	w14, [sp, #0x68]
   1522c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   15230:      	cmp	x12, #0xfff
   15234:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   15238:      	cmp	w23, w21
   1523c:      	b.ls	0x15248 <generic_lsm_path+0xb3f8>
   15240:      	mov	w13, #0x2f              // =47
   15244:      	strb	w13, [x8, x12]
   15248:      	add	x19, x8, x12
   1524c:      	cmp	w23, w21
   15250:      	add	x2, x9, x10
   15254:      	and	w1, w11, #0xff
   15258:      	mov	w8, #0x4                // =4
   1525c:      	cinc	x0, x19, hi
   15260:      	blr	x8
   15264:      	ldr	x25, [sp, #0x8]
   15268:      	cmp	w23, w21
   1526c:      	str	x19, [sp, #0x60]
   15270:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   15274:      	ldr	x21, [sp, #0x78]
   15278:      	ldp	x2, x24, [sp, #0x50]
   1527c:      	str	x21, [sp, #0x48]
   15280:      	b	0x152d4 <generic_lsm_path+0xb484>
   15284:      	add	x2, x24, #0x10
   15288:      	mov	w8, #0x4                // =4
   1528c:      	add	x9, sp, #0x98
   15290:      	add	x0, sp, #0x98
   15294:      	mov	w1, #0x8                // =8
   15298:      	blr	x8
   1529c:      	ldr	x8, [sp, #0x58]
   152a0:      	ldr	x9, [sp, #0x98]
   152a4:      	cmp	x8, x9
   152a8:      	ldr	x25, [sp, #0x8]
   152ac:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   152b0:      	add	x2, x24, #0x18
   152b4:      	mov	w8, #0x4                // =4
   152b8:      	mov	x0, x22
   152bc:      	mov	w1, #0x8                // =8
   152c0:      	blr	x8
   152c4:      	ldr	x24, [sp, #0x98]
   152c8:      	ldr	x21, [sp, #0x48]
   152cc:      	add	x2, x24, #0x20
   152d0:      	stp	x2, x24, [sp, #0x50]
   152d4:      	ldr	x8, [sp, #0x30]
   152d8:      	ldr	x25, [sp, #0x8]
   152dc:      	add	x9, sp, #0x70
   152e0:      	cmp	x21, x8
   152e4:      	b.ne	0x152f4 <generic_lsm_path+0xb4a4>
   152e8:      	ldr	x8, [sp, #0x38]
   152ec:      	cmp	x2, x8
   152f0:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   152f4:      	mov	w8, #0x4                // =4
   152f8:      	add	x0, sp, #0x70
   152fc:      	mov	w1, #0x8                // =8
   15300:      	blr	x8
   15304:      	ldr	x8, [sp, #0x70]
   15308:      	cmp	x21, x8
   1530c:      	b.eq	0x15400 <generic_lsm_path+0xb5b0>
   15310:      	add	x23, x21, #0x18
   15314:      	mov	w8, #0x4                // =4
   15318:      	add	x9, sp, #0x98
   1531c:      	add	x0, sp, #0x98
   15320:      	mov	w1, #0x8                // =8
   15324:      	mov	x2, x23
   15328:      	blr	x8
   1532c:      	ldr	x8, [sp, #0x98]
   15330:      	cmp	x8, x21
   15334:      	b.eq	0x15400 <generic_lsm_path+0xb5b0>
   15338:      	mov	w8, #0x4                // =4
   1533c:      	add	x9, sp, #0x78
   15340:      	add	x0, sp, #0x78
   15344:      	mov	w1, #0x8                // =8
   15348:      	mov	x2, x23
   1534c:      	blr	x8
   15350:      	add	x2, x21, #0x20
   15354:      	mov	w8, #0x4                // =4
   15358:      	mov	w9, #0x10               // =16
   1535c:      	add	x10, sp, #0x80
   15360:      	add	x0, sp, #0x80
   15364:      	mov	w1, #0x10               // =16
   15368:      	blr	x8
   1536c:      	ldr	w21, [sp, #0x84]
   15370:      	ldr	x8, [sp, #0x40]
   15374:      	ldr	x10, [sp, #0x60]
   15378:      	sub	x12, x10, x8
   1537c:      	ldr	w23, [sp, #0x68]
   15380:      	subs	w10, w21, w23
   15384:      	ldr	x9, [sp, #0x88]
   15388:      	ldr	x25, [sp, #0x8]
   1538c:      	csel	w10, wzr, w10, lo
   15390:      	cmp	w23, w21
   15394:      	csel	w11, w23, w21, lo
   15398:      	cinc	w13, w11, hi
   1539c:      	sub	w14, w23, w13
   153a0:      	subs	x12, x12, x13
   153a4:      	str	w14, [sp, #0x68]
   153a8:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   153ac:      	cmp	x12, #0xfff
   153b0:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   153b4:      	cmp	w23, w21
   153b8:      	b.ls	0x153c4 <generic_lsm_path+0xb574>
   153bc:      	mov	w13, #0x2f              // =47
   153c0:      	strb	w13, [x8, x12]
   153c4:      	add	x19, x8, x12
   153c8:      	cmp	w23, w21
   153cc:      	add	x2, x9, x10
   153d0:      	and	w1, w11, #0xff
   153d4:      	mov	w8, #0x4                // =4
   153d8:      	cinc	x0, x19, hi
   153dc:      	blr	x8
   153e0:      	ldr	x25, [sp, #0x8]
   153e4:      	cmp	w23, w21
   153e8:      	str	x19, [sp, #0x60]
   153ec:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   153f0:      	ldr	x21, [sp, #0x78]
   153f4:      	ldp	x2, x24, [sp, #0x50]
   153f8:      	str	x21, [sp, #0x48]
   153fc:      	b	0x15450 <generic_lsm_path+0xb600>
   15400:      	add	x2, x24, #0x10
   15404:      	mov	w8, #0x4                // =4
   15408:      	add	x9, sp, #0x98
   1540c:      	add	x0, sp, #0x98
   15410:      	mov	w1, #0x8                // =8
   15414:      	blr	x8
   15418:      	ldr	x8, [sp, #0x58]
   1541c:      	ldr	x9, [sp, #0x98]
   15420:      	cmp	x8, x9
   15424:      	ldr	x25, [sp, #0x8]
   15428:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1542c:      	add	x2, x24, #0x18
   15430:      	mov	w8, #0x4                // =4
   15434:      	mov	x0, x22
   15438:      	mov	w1, #0x8                // =8
   1543c:      	blr	x8
   15440:      	ldr	x24, [sp, #0x98]
   15444:      	ldr	x21, [sp, #0x48]
   15448:      	add	x2, x24, #0x20
   1544c:      	stp	x2, x24, [sp, #0x50]
   15450:      	ldr	x8, [sp, #0x30]
   15454:      	ldr	x25, [sp, #0x8]
   15458:      	add	x9, sp, #0x70
   1545c:      	cmp	x21, x8
   15460:      	b.ne	0x15470 <generic_lsm_path+0xb620>
   15464:      	ldr	x8, [sp, #0x38]
   15468:      	cmp	x2, x8
   1546c:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   15470:      	mov	w8, #0x4                // =4
   15474:      	add	x0, sp, #0x70
   15478:      	mov	w1, #0x8                // =8
   1547c:      	blr	x8
   15480:      	ldr	x8, [sp, #0x70]
   15484:      	cmp	x21, x8
   15488:      	b.eq	0x1557c <generic_lsm_path+0xb72c>
   1548c:      	add	x23, x21, #0x18
   15490:      	mov	w8, #0x4                // =4
   15494:      	add	x9, sp, #0x98
   15498:      	add	x0, sp, #0x98
   1549c:      	mov	w1, #0x8                // =8
   154a0:      	mov	x2, x23
   154a4:      	blr	x8
   154a8:      	ldr	x8, [sp, #0x98]
   154ac:      	cmp	x8, x21
   154b0:      	b.eq	0x1557c <generic_lsm_path+0xb72c>
   154b4:      	mov	w8, #0x4                // =4
   154b8:      	add	x9, sp, #0x78
   154bc:      	add	x0, sp, #0x78
   154c0:      	mov	w1, #0x8                // =8
   154c4:      	mov	x2, x23
   154c8:      	blr	x8
   154cc:      	add	x2, x21, #0x20
   154d0:      	mov	w8, #0x4                // =4
   154d4:      	mov	w9, #0x10               // =16
   154d8:      	add	x10, sp, #0x80
   154dc:      	add	x0, sp, #0x80
   154e0:      	mov	w1, #0x10               // =16
   154e4:      	blr	x8
   154e8:      	ldr	w21, [sp, #0x84]
   154ec:      	ldr	x8, [sp, #0x40]
   154f0:      	ldr	x10, [sp, #0x60]
   154f4:      	sub	x12, x10, x8
   154f8:      	ldr	w23, [sp, #0x68]
   154fc:      	subs	w10, w21, w23
   15500:      	ldr	x9, [sp, #0x88]
   15504:      	ldr	x25, [sp, #0x8]
   15508:      	csel	w10, wzr, w10, lo
   1550c:      	cmp	w23, w21
   15510:      	csel	w11, w23, w21, lo
   15514:      	cinc	w13, w11, hi
   15518:      	sub	w14, w23, w13
   1551c:      	subs	x12, x12, x13
   15520:      	str	w14, [sp, #0x68]
   15524:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   15528:      	cmp	x12, #0xfff
   1552c:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   15530:      	cmp	w23, w21
   15534:      	b.ls	0x15540 <generic_lsm_path+0xb6f0>
   15538:      	mov	w13, #0x2f              // =47
   1553c:      	strb	w13, [x8, x12]
   15540:      	add	x19, x8, x12
   15544:      	cmp	w23, w21
   15548:      	add	x2, x9, x10
   1554c:      	and	w1, w11, #0xff
   15550:      	mov	w8, #0x4                // =4
   15554:      	cinc	x0, x19, hi
   15558:      	blr	x8
   1555c:      	ldr	x25, [sp, #0x8]
   15560:      	cmp	w23, w21
   15564:      	str	x19, [sp, #0x60]
   15568:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   1556c:      	ldr	x21, [sp, #0x78]
   15570:      	ldp	x2, x24, [sp, #0x50]
   15574:      	str	x21, [sp, #0x48]
   15578:      	b	0x155cc <generic_lsm_path+0xb77c>
   1557c:      	add	x2, x24, #0x10
   15580:      	mov	w8, #0x4                // =4
   15584:      	add	x9, sp, #0x98
   15588:      	add	x0, sp, #0x98
   1558c:      	mov	w1, #0x8                // =8
   15590:      	blr	x8
   15594:      	ldr	x8, [sp, #0x58]
   15598:      	ldr	x9, [sp, #0x98]
   1559c:      	cmp	x8, x9
   155a0:      	ldr	x25, [sp, #0x8]
   155a4:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   155a8:      	add	x2, x24, #0x18
   155ac:      	mov	w8, #0x4                // =4
   155b0:      	mov	x0, x22
   155b4:      	mov	w1, #0x8                // =8
   155b8:      	blr	x8
   155bc:      	ldr	x24, [sp, #0x98]
   155c0:      	ldr	x21, [sp, #0x48]
   155c4:      	add	x2, x24, #0x20
   155c8:      	stp	x2, x24, [sp, #0x50]
   155cc:      	ldr	x8, [sp, #0x30]
   155d0:      	ldr	x25, [sp, #0x8]
   155d4:      	add	x9, sp, #0x70
   155d8:      	cmp	x21, x8
   155dc:      	b.ne	0x155ec <generic_lsm_path+0xb79c>
   155e0:      	ldr	x8, [sp, #0x38]
   155e4:      	cmp	x2, x8
   155e8:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   155ec:      	mov	w8, #0x4                // =4
   155f0:      	add	x0, sp, #0x70
   155f4:      	mov	w1, #0x8                // =8
   155f8:      	blr	x8
   155fc:      	ldr	x8, [sp, #0x70]
   15600:      	cmp	x21, x8
   15604:      	b.eq	0x156f8 <generic_lsm_path+0xb8a8>
   15608:      	add	x23, x21, #0x18
   1560c:      	mov	w8, #0x4                // =4
   15610:      	add	x9, sp, #0x98
   15614:      	add	x0, sp, #0x98
   15618:      	mov	w1, #0x8                // =8
   1561c:      	mov	x2, x23
   15620:      	blr	x8
   15624:      	ldr	x8, [sp, #0x98]
   15628:      	cmp	x8, x21
   1562c:      	b.eq	0x156f8 <generic_lsm_path+0xb8a8>
   15630:      	mov	w8, #0x4                // =4
   15634:      	add	x9, sp, #0x78
   15638:      	add	x0, sp, #0x78
   1563c:      	mov	w1, #0x8                // =8
   15640:      	mov	x2, x23
   15644:      	blr	x8
   15648:      	add	x2, x21, #0x20
   1564c:      	mov	w8, #0x4                // =4
   15650:      	mov	w9, #0x10               // =16
   15654:      	add	x10, sp, #0x80
   15658:      	add	x0, sp, #0x80
   1565c:      	mov	w1, #0x10               // =16
   15660:      	blr	x8
   15664:      	ldr	w21, [sp, #0x84]
   15668:      	ldr	x8, [sp, #0x40]
   1566c:      	ldr	x10, [sp, #0x60]
   15670:      	sub	x12, x10, x8
   15674:      	ldr	w23, [sp, #0x68]
   15678:      	subs	w10, w21, w23
   1567c:      	ldr	x9, [sp, #0x88]
   15680:      	ldr	x25, [sp, #0x8]
   15684:      	csel	w10, wzr, w10, lo
   15688:      	cmp	w23, w21
   1568c:      	csel	w11, w23, w21, lo
   15690:      	cinc	w13, w11, hi
   15694:      	sub	w14, w23, w13
   15698:      	subs	x12, x12, x13
   1569c:      	str	w14, [sp, #0x68]
   156a0:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   156a4:      	cmp	x12, #0xfff
   156a8:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   156ac:      	cmp	w23, w21
   156b0:      	b.ls	0x156bc <generic_lsm_path+0xb86c>
   156b4:      	mov	w13, #0x2f              // =47
   156b8:      	strb	w13, [x8, x12]
   156bc:      	add	x19, x8, x12
   156c0:      	cmp	w23, w21
   156c4:      	add	x2, x9, x10
   156c8:      	and	w1, w11, #0xff
   156cc:      	mov	w8, #0x4                // =4
   156d0:      	cinc	x0, x19, hi
   156d4:      	blr	x8
   156d8:      	ldr	x25, [sp, #0x8]
   156dc:      	cmp	w23, w21
   156e0:      	str	x19, [sp, #0x60]
   156e4:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   156e8:      	ldr	x21, [sp, #0x78]
   156ec:      	ldp	x2, x24, [sp, #0x50]
   156f0:      	str	x21, [sp, #0x48]
   156f4:      	b	0x15748 <generic_lsm_path+0xb8f8>
   156f8:      	add	x2, x24, #0x10
   156fc:      	mov	w8, #0x4                // =4
   15700:      	add	x9, sp, #0x98
   15704:      	add	x0, sp, #0x98
   15708:      	mov	w1, #0x8                // =8
   1570c:      	blr	x8
   15710:      	ldr	x8, [sp, #0x58]
   15714:      	ldr	x9, [sp, #0x98]
   15718:      	cmp	x8, x9
   1571c:      	ldr	x25, [sp, #0x8]
   15720:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   15724:      	add	x2, x24, #0x18
   15728:      	mov	w8, #0x4                // =4
   1572c:      	mov	x0, x22
   15730:      	mov	w1, #0x8                // =8
   15734:      	blr	x8
   15738:      	ldr	x24, [sp, #0x98]
   1573c:      	ldr	x21, [sp, #0x48]
   15740:      	add	x2, x24, #0x20
   15744:      	stp	x2, x24, [sp, #0x50]
   15748:      	ldr	x8, [sp, #0x30]
   1574c:      	ldr	x25, [sp, #0x8]
   15750:      	add	x9, sp, #0x70
   15754:      	cmp	x21, x8
   15758:      	b.ne	0x15768 <generic_lsm_path+0xb918>
   1575c:      	ldr	x8, [sp, #0x38]
   15760:      	cmp	x2, x8
   15764:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   15768:      	mov	w8, #0x4                // =4
   1576c:      	add	x0, sp, #0x70
   15770:      	mov	w1, #0x8                // =8
   15774:      	blr	x8
   15778:      	ldr	x8, [sp, #0x70]
   1577c:      	cmp	x21, x8
   15780:      	b.eq	0x15870 <generic_lsm_path+0xba20>
   15784:      	add	x23, x21, #0x18
   15788:      	mov	w8, #0x4                // =4
   1578c:      	add	x9, sp, #0x98
   15790:      	add	x0, sp, #0x98
   15794:      	mov	w1, #0x8                // =8
   15798:      	mov	x2, x23
   1579c:      	blr	x8
   157a0:      	ldr	x8, [sp, #0x98]
   157a4:      	cmp	x8, x21
   157a8:      	b.eq	0x15870 <generic_lsm_path+0xba20>
   157ac:      	mov	w8, #0x4                // =4
   157b0:      	add	x9, sp, #0x78
   157b4:      	add	x0, sp, #0x78
   157b8:      	mov	w1, #0x8                // =8
   157bc:      	mov	x2, x23
   157c0:      	blr	x8
   157c4:      	add	x2, x21, #0x20
   157c8:      	mov	w8, #0x4                // =4
   157cc:      	mov	w9, #0x10               // =16
   157d0:      	add	x10, sp, #0x80
   157d4:      	add	x0, sp, #0x80
   157d8:      	mov	w1, #0x10               // =16
   157dc:      	blr	x8
   157e0:      	ldr	w21, [sp, #0x84]
   157e4:      	ldr	x8, [sp, #0x40]
   157e8:      	ldr	x10, [sp, #0x60]
   157ec:      	sub	x12, x10, x8
   157f0:      	ldr	w23, [sp, #0x68]
   157f4:      	subs	w10, w21, w23
   157f8:      	ldr	x9, [sp, #0x88]
   157fc:      	ldr	x25, [sp, #0x8]
   15800:      	csel	w10, wzr, w10, lo
   15804:      	cmp	w23, w21
   15808:      	csel	w11, w23, w21, lo
   1580c:      	cinc	w13, w11, hi
   15810:      	sub	w14, w23, w13
   15814:      	subs	x12, x12, x13
   15818:      	str	w14, [sp, #0x68]
   1581c:      	b.lo	0x158d8 <generic_lsm_path+0xba88>
   15820:      	cmp	x12, #0xfff
   15824:      	b.hi	0x158d8 <generic_lsm_path+0xba88>
   15828:      	cmp	w23, w21
   1582c:      	b.ls	0x15838 <generic_lsm_path+0xb9e8>
   15830:      	mov	w13, #0x2f              // =47
   15834:      	strb	w13, [x8, x12]
   15838:      	add	x19, x8, x12
   1583c:      	cmp	w23, w21
   15840:      	add	x2, x9, x10
   15844:      	and	w1, w11, #0xff
   15848:      	mov	w8, #0x4                // =4
   1584c:      	cinc	x0, x19, hi
   15850:      	blr	x8
   15854:      	ldr	x25, [sp, #0x8]
   15858:      	cmp	w23, w21
   1585c:      	str	x19, [sp, #0x60]
   15860:      	b.ls	0x158d8 <generic_lsm_path+0xba88>
   15864:      	ldr	x8, [sp, #0x78]
   15868:      	str	x8, [sp, #0x48]
   1586c:      	b	0x158bc <generic_lsm_path+0xba6c>
   15870:      	add	x2, x24, #0x10
   15874:      	mov	w8, #0x4                // =4
   15878:      	add	x9, sp, #0x98
   1587c:      	add	x0, sp, #0x98
   15880:      	mov	w1, #0x8                // =8
   15884:      	blr	x8
   15888:      	ldr	x8, [sp, #0x58]
   1588c:      	ldr	x9, [sp, #0x98]
   15890:      	cmp	x8, x9
   15894:      	ldr	x25, [sp, #0x8]
   15898:      	b.eq	0x158d0 <generic_lsm_path+0xba80>
   1589c:      	add	x2, x24, #0x18
   158a0:      	mov	w8, #0x4                // =4
   158a4:      	mov	x0, x22
   158a8:      	mov	w1, #0x8                // =8
   158ac:      	blr	x8
   158b0:      	ldr	x8, [sp, #0x98]
   158b4:      	add	x9, x8, #0x20
   158b8:      	stp	x9, x8, [sp, #0x50]
   158bc:      	ldr	x25, [sp, #0x8]
   158c0:      	subs	w20, w20, #0x80
   158c4:      	add	x19, sp, #0x70
   158c8:      	b.ne	0x9fcc <generic_lsm_path+0x17c>
   158cc:      	b	0x158d8 <generic_lsm_path+0xba88>
   158d0:      	mov	w8, #0x1                // =1
   158d4:      	strb	w8, [sp, #0x6c]
   158d8:      	ldr	w8, [x25, #0x8]
   158dc:      	ldp	x10, x20, [sp, #0x10]
   158e0:      	add	w8, w8, #0x1
   158e4:      	str	w8, [x25, #0x8]
   158e8:      	ldr	w9, [sp, #0x60]
   158ec:      	sub	w9, w9, w10
   158f0:      	str	w9, [x25, #0x4]
   158f4:      	ldrb	w9, [sp, #0x6c]
   158f8:      	cbnz	w9, 0x15930 <generic_lsm_path+0xbae0>
   158fc:      	cmp	w8, #0x8
   15900:      	b.eq	0x15930 <generic_lsm_path+0xbae0>
   15904:      	ldp	x8, x9, [sp, #0x48]
   15908:      	mov	w2, #0x6                // =6
   1590c:      	str	x8, [x20, #0x6458]
   15910:      	ldr	x8, [sp, #0x58]
   15914:      	str	x9, [x20, #0x6460]
   15918:      	adrp	x9, 0x15000 <generic_lsm_path+0xb1b0>
   1591c:      	str	x8, [x20, #0x6468]
   15920:      	mov	w8, #0xc                // =12
   15924:      	ldr	x9, [x9]
   15928:      	ldr	x0, [sp, #0x20]
   1592c:      	b	0x15944 <generic_lsm_path+0xbaf4>
   15930:      	adrp	x9, 0x15000 <generic_lsm_path+0xb1b0>
   15934:      	mov	w2, #0x1                // =1
   15938:      	mov	w8, #0xc                // =12
   1593c:      	ldr	x9, [x9]
   15940:      	ldr	x0, [sp, #0x20]
   15944:      	adrp	x1, 0x15000 <generic_lsm_path+0xb1b0>
   15948:      	ldr	x1, [x1]
   1594c:      	blr	x8
   15950:      	b	0x15cec <generic_lsm_path+0xbe9c>
   15954:      	str	w23, [sp, #0x98]
   15958:      	mov	x3, xzr
   1595c:      	mov	w8, #0x2                // =2
   15960:      	add	x9, sp, #0x30
   15964:      	add	x10, sp, #0x98
   15968:      	add	x1, sp, #0x30
   1596c:      	add	x2, sp, #0x98
   15970:      	mov	x0, x22
   15974:      	blr	x8
   15978:      	ldr	x23, [sp, #0x80]
   1597c:      	mov	w8, #0x8                // =8
   15980:      	mov	w9, #0x4                // =4
   15984:      	add	x10, sp, #0x30
   15988:      	add	x0, sp, #0x30
   1598c:      	mov	w1, #0x8                // =8
   15990:      	add	x2, x23, #0x10
   15994:      	blr	x9
   15998:      	ldr	x8, [sp, #0x30]
   1599c:      	cbnz	x8, 0x159e4 <generic_lsm_path+0xbb94>
   159a0:      	add	x2, x23, #0x18
   159a4:      	mov	w8, #0x8                // =8
   159a8:      	mov	w9, #0x4                // =4
   159ac:      	add	x10, sp, #0x30
   159b0:      	add	x0, sp, #0x30
   159b4:      	mov	w1, #0x8                // =8
   159b8:      	blr	x9
   159bc:      	ldr	x8, [sp, #0x30]
   159c0:      	cmp	x8, x23
   159c4:      	b.eq	0x159e4 <generic_lsm_path+0xbb94>
   159c8:      	adrp	x8, 0x15000 <generic_lsm_path+0xb1b0>
   159cc:      	add	x8, x8, #0x0
   159d0:      	add	x29, x21, #0xff5
   159d4:      	ldr	x8, [x8]
   159d8:      	str	x8, [x29]
   159dc:      	mov	w8, #0x2964             // =10596
   159e0:      	strh	w8, [x29, #0x8]
   159e4:      	mov	w8, #0x23               // =35
   159e8:      	blr	x8
   159ec:      	add	x2, x0, #0xb30
   159f0:      	mov	w8, #0x8                // =8
   159f4:      	mov	w9, #0x4                // =4
   159f8:      	add	x10, sp, #0x98
   159fc:      	add	x0, sp, #0x98
   15a00:      	mov	w1, #0x8                // =8
   15a04:      	blr	x9
   15a08:      	cbz	x0, 0x15a78 <generic_lsm_path+0xbc28>
   15a0c:      	neg	w8, w0
   15a10:      	mov	w9, #0x1                // =1
   15a14:      	add	x1, sp, #0x30
   15a18:      	strh	w8, [sp, #0x30]
   15a1c:      	mov	w8, #0x6                // =6
   15a20:      	mov	x0, x22
   15a24:      	mov	w23, #0x1               // =1
   15a28:      	strh	w8, [sp, #0x32]
   15a2c:      	mov	x8, #0x33               // =51
   15a30:      	movk	x8, #0x4, lsl #32
   15a34:      	stur	x8, [sp, #0x34]
   15a38:      	add	x8, sp, #0x30
   15a3c:      	blr	x9
   15a40:      	cbz	x0, 0x15a54 <generic_lsm_path+0xbc04>
   15a44:      	ldr	w8, [x0]
   15a48:      	add	w8, w8, #0x1
   15a4c:      	str	w8, [x0]
   15a50:      	b	0x15a78 <generic_lsm_path+0xbc28>
   15a54:      	str	w23, [sp, #0x78]
   15a58:      	mov	x3, xzr
   15a5c:      	mov	w8, #0x2                // =2
   15a60:      	add	x9, sp, #0x30
   15a64:      	add	x10, sp, #0x78
   15a68:      	add	x1, sp, #0x30
   15a6c:      	add	x2, sp, #0x78
   15a70:      	mov	x0, x22
   15a74:      	blr	x8
   15a78:      	ldr	x8, [sp, #0x98]
   15a7c:      	mov	w9, #0x6448             // =25672
   15a80:      	ldr	x23, [x20, #0x6440]
   15a84:      	mov	w1, #0x8                // =8
   15a88:      	add	x0, x20, x9
   15a8c:      	mov	w9, #0x4                // =4
   15a90:      	add	x24, x8, #0x18
   15a94:      	add	x2, x8, #0x20
   15a98:      	mov	w8, #0x8                // =8
   15a9c:      	blr	x9
   15aa0:      	cbz	x0, 0x15b10 <generic_lsm_path+0xbcc0>
   15aa4:      	neg	w8, w0
   15aa8:      	mov	w9, #0x1                // =1
   15aac:      	add	x1, sp, #0x30
   15ab0:      	strh	w8, [sp, #0x30]
   15ab4:      	mov	w8, #0x6                // =6
   15ab8:      	mov	x0, x22
   15abc:      	mov	w19, #0x1               // =1
   15ac0:      	strh	w8, [sp, #0x32]
   15ac4:      	mov	x8, #0x38               // =56
   15ac8:      	movk	x8, #0x4, lsl #32
   15acc:      	stur	x8, [sp, #0x34]
   15ad0:      	add	x8, sp, #0x30
   15ad4:      	blr	x9
   15ad8:      	cbz	x0, 0x15aec <generic_lsm_path+0xbc9c>
   15adc:      	ldr	w8, [x0]
   15ae0:      	add	w8, w8, #0x1
   15ae4:      	str	w8, [x0]
   15ae8:      	b	0x15b10 <generic_lsm_path+0xbcc0>
   15aec:      	str	w19, [sp, #0x78]
   15af0:      	mov	x3, xzr
   15af4:      	mov	w8, #0x2                // =2
   15af8:      	add	x9, sp, #0x30
   15afc:      	add	x10, sp, #0x78
   15b00:      	add	x1, sp, #0x30
   15b04:      	add	x2, sp, #0x78
   15b08:      	mov	x0, x22
   15b0c:      	blr	x8
   15b10:      	mov	w8, #0x6450             // =25680
   15b14:      	mov	w9, #0x4                // =4
   15b18:      	mov	w1, #0x8                // =8
   15b1c:      	mov	x2, x24
   15b20:      	add	x0, x20, x8
   15b24:      	mov	w8, #0x8                // =8
   15b28:      	blr	x9
   15b2c:      	cbz	x0, 0x15b9c <generic_lsm_path+0xbd4c>
   15b30:      	neg	w8, w0
   15b34:      	mov	w9, #0x1                // =1
   15b38:      	add	x1, sp, #0x30
   15b3c:      	strh	w8, [sp, #0x30]
   15b40:      	mov	w8, #0x6                // =6
   15b44:      	mov	x0, x22
   15b48:      	mov	w19, #0x1               // =1
   15b4c:      	strh	w8, [sp, #0x32]
   15b50:      	mov	x8, #0x39               // =57
   15b54:      	movk	x8, #0x4, lsl #32
   15b58:      	stur	x8, [sp, #0x34]
   15b5c:      	add	x8, sp, #0x30
   15b60:      	blr	x9
   15b64:      	cbz	x0, 0x15b78 <generic_lsm_path+0xbd28>
   15b68:      	ldr	w8, [x0]
   15b6c:      	add	w8, w8, #0x1
   15b70:      	str	w8, [x0]
   15b74:      	b	0x15b9c <generic_lsm_path+0xbd4c>
   15b78:      	str	w19, [sp, #0x78]
   15b7c:      	mov	x3, xzr
   15b80:      	mov	w8, #0x2                // =2
   15b84:      	add	x9, sp, #0x30
   15b88:      	add	x10, sp, #0x78
   15b8c:      	add	x1, sp, #0x30
   15b90:      	add	x2, sp, #0x78
   15b94:      	mov	x0, x22
   15b98:      	blr	x8
   15b9c:      	mov	w8, #0x6458             // =25688
   15ba0:      	add	x2, x23, #0x8
   15ba4:      	mov	w9, #0x4                // =4
   15ba8:      	mov	w1, #0x8                // =8
   15bac:      	add	x0, x20, x8
   15bb0:      	mov	w8, #0x8                // =8
   15bb4:      	blr	x9
   15bb8:      	cbz	x0, 0x15c28 <generic_lsm_path+0xbdd8>
   15bbc:      	neg	w8, w0
   15bc0:      	mov	w9, #0x1                // =1
   15bc4:      	add	x1, sp, #0x30
   15bc8:      	strh	w8, [sp, #0x30]
   15bcc:      	mov	w8, #0x6                // =6
   15bd0:      	mov	x0, x22
   15bd4:      	mov	w19, #0x1               // =1
   15bd8:      	strh	w8, [sp, #0x32]
   15bdc:      	mov	x8, #0x3a               // =58
   15be0:      	movk	x8, #0x4, lsl #32
   15be4:      	stur	x8, [sp, #0x34]
   15be8:      	add	x8, sp, #0x30
   15bec:      	blr	x9
   15bf0:      	cbz	x0, 0x15c04 <generic_lsm_path+0xbdb4>
   15bf4:      	ldr	w8, [x0]
   15bf8:      	add	w8, w8, #0x1
   15bfc:      	str	w8, [x0]
   15c00:      	b	0x15c28 <generic_lsm_path+0xbdd8>
   15c04:      	str	w19, [sp, #0x78]
   15c08:      	mov	x3, xzr
   15c0c:      	mov	w8, #0x2                // =2
   15c10:      	add	x9, sp, #0x30
   15c14:      	add	x10, sp, #0x78
   15c18:      	add	x1, sp, #0x30
   15c1c:      	add	x2, sp, #0x78
   15c20:      	mov	x0, x22
   15c24:      	blr	x8
   15c28:      	mov	w8, #0x6460             // =25696
   15c2c:      	mov	w9, #0x4                // =4
   15c30:      	mov	w1, #0x8                // =8
   15c34:      	mov	x2, x23
   15c38:      	add	x0, x20, x8
   15c3c:      	mov	w8, #0x8                // =8
   15c40:      	blr	x9
   15c44:      	cbz	x0, 0x15cb4 <generic_lsm_path+0xbe64>
   15c48:      	neg	w8, w0
   15c4c:      	mov	w9, #0x1                // =1
   15c50:      	add	x1, sp, #0x30
   15c54:      	strh	w8, [sp, #0x30]
   15c58:      	mov	w8, #0x6                // =6
   15c5c:      	mov	x0, x22
   15c60:      	mov	w19, #0x1               // =1
   15c64:      	strh	w8, [sp, #0x32]
   15c68:      	mov	x8, #0x3b               // =59
   15c6c:      	movk	x8, #0x4, lsl #32
   15c70:      	stur	x8, [sp, #0x34]
   15c74:      	add	x8, sp, #0x30
   15c78:      	blr	x9
   15c7c:      	cbz	x0, 0x15c90 <generic_lsm_path+0xbe40>
   15c80:      	ldr	w8, [x0]
   15c84:      	add	w8, w8, #0x1
   15c88:      	str	w8, [x0]
   15c8c:      	b	0x15cb4 <generic_lsm_path+0xbe64>
   15c90:      	str	w19, [sp, #0x78]
   15c94:      	mov	x3, xzr
   15c98:      	mov	w8, #0x2                // =2
   15c9c:      	add	x9, sp, #0x30
   15ca0:      	add	x10, sp, #0x78
   15ca4:      	add	x1, sp, #0x30
   15ca8:      	add	x2, sp, #0x78
   15cac:      	mov	x0, x22
   15cb0:      	blr	x8
   15cb4:      	ldr	x8, [x20, #0x6460]
   15cb8:      	mov	w9, #0x1                // =1
   15cbc:      	adrp	x1, 0x15000 <generic_lsm_path+0xb1b0>
   15cc0:      	mov	w2, #0x6                // =6
   15cc4:      	str	w9, [x25]
   15cc8:      	mov	w9, #0xc                // =12
   15ccc:      	sub	x8, x8, #0x20
   15cd0:      	str	x8, [x20, #0x6468]
   15cd4:      	sub	w8, w29, w21
   15cd8:      	stp	w8, wzr, [x25, #0x4]
   15cdc:      	mov	w8, #0x6                // =6
   15ce0:      	ldr	x1, [x1]
   15ce4:      	ldr	x0, [sp, #0x20]
   15ce8:      	blr	x9
   15cec:      	ldp	x20, x19, [sp, #0xd0]
   15cf0:      	mov	w0, wzr
   15cf4:      	ldr	x29, [sp, #0x90]
   15cf8:      	ldp	x22, x21, [sp, #0xc0]
   15cfc:      	ldp	x24, x23, [sp, #0xb0]
   15d00:      	ldp	x30, x25, [sp, #0xa0]
   15d04:      	add	sp, sp, #0xe0
   15d08:      	ret

Disassembly of section lsm/generic_lsm_core:

0000000000000000 <generic_lsm_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_lsm_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x540 <generic_lsm_event+0x540>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	adrp	x0, 0x0 <generic_lsm_event>
      48:      	mov	w8, #0x1                // =1
      4c:      	str	wzr, [x21]
      50:      	mov	x1, x21
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x540 <generic_lsm_event+0x540>
      60:      	ldr	w8, [x0, #0x64]
      64:      	str	w8, [sp, #0x1c]
      68:      	cbz	w8, 0x224 <generic_lsm_event+0x224>
      6c:      	adrp	x22, 0x0 <generic_lsm_event>
      70:      	mov	w8, #0x1                // =1
      74:      	add	x9, sp, #0x1c
      78:      	ldr	x22, [x22]
      7c:      	mov	x24, x0
      80:      	add	x1, sp, #0x1c
      84:      	mov	x0, x22
      88:      	blr	x8
      8c:      	cbz	x0, 0x540 <generic_lsm_event+0x540>
      90:      	mov	x23, x0
      94:      	str	wzr, [sp, #0x84]
      98:      	adrp	x0, 0x0 <generic_lsm_event>
      9c:      	mov	w8, #0x1                // =1
      a0:      	ldr	x0, [x0]
      a4:      	add	x9, sp, #0x84
      a8:      	add	x1, sp, #0x84
      ac:      	blr	x8
      b0:      	cbz	x0, 0xdc <generic_lsm_event+0xdc>
      b4:      	ldr	x8, [x0, #0x20]
      b8:      	mov	w9, #0x7270             // =29296
      bc:      	movk	w9, #0x6367, lsl #16
      c0:      	cmp	x8, x9
      c4:      	b.ne	0xe4 <generic_lsm_event+0xe4>
      c8:      	mov	w8, #0x50               // =80
      cc:      	blr	x8
      d0:      	str	x0, [sp, #0x30]
      d4:      	cbnz	x0, 0x1d8 <generic_lsm_event+0x1d8>
      d8:      	b	0x540 <generic_lsm_event+0x540>
      dc:      	mov	w25, wzr
      e0:      	b	0xe8 <generic_lsm_event+0xe8>
      e4:      	ldr	w25, [x0, #0x10]
      e8:      	mov	w8, #0x23               // =35
      ec:      	blr	x8
      f0:      	str	xzr, [sp, #0x88]
      f4:      	add	x2, x0, #0xcd0
      f8:      	mov	w8, #0x8                // =8
      fc:      	mov	w9, #0x71               // =113
     100:      	add	x10, sp, #0x20
     104:      	add	x0, sp, #0x20
     108:      	mov	w1, #0x8                // =8
     10c:      	blr	x9
     110:      	ldr	x8, [sp, #0x20]
     114:      	cbz	x8, 0x540 <generic_lsm_event+0x540>
     118:      	cmp	w25, #0xb
     11c:      	b.hi	0x540 <generic_lsm_event+0x540>
     120:      	ubfiz	x9, x25, #3, #32
     124:      	mov	w10, #0x8               // =8
     128:      	mov	w11, #0x71              // =113
     12c:      	add	x12, sp, #0x38
     130:      	add	x0, sp, #0x38
     134:      	mov	w1, #0x8                // =8
     138:      	add	x8, x8, x9
     13c:      	ldr	x8, [sp, #0x20]
     140:      	add	x2, x8, x9
     144:      	blr	x11
     148:      	ldr	x8, [sp, #0x38]
     14c:      	cbz	x8, 0x540 <generic_lsm_event+0x540>
     150:      	mov	w9, #0x8                // =8
     154:      	mov	w10, #0x71              // =113
     158:      	add	x11, sp, #0x88
     15c:      	ldr	x2, [sp, #0x38]
     160:      	add	x0, sp, #0x88
     164:      	mov	w1, #0x8                // =8
     168:      	blr	x10
     16c:      	ldr	x8, [sp, #0x88]
     170:      	cbz	x8, 0x540 <generic_lsm_event+0x540>
     174:      	str	xzr, [sp, #0x38]
     178:      	add	x2, x8, #0x100
     17c:      	mov	w8, #0x8                // =8
     180:      	mov	w9, #0x71               // =113
     184:      	add	x10, sp, #0x38
     188:      	add	x0, sp, #0x38
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x9
     194:      	ldr	x8, [sp, #0x38]
     198:      	str	xzr, [sp, #0x38]
     19c:      	cbz	x8, 0x1cc <generic_lsm_event+0x1cc>
     1a0:      	add	x2, x8, #0x60
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	w9, #0x71               // =113
     1ac:      	add	x10, sp, #0x38
     1b0:      	add	x0, sp, #0x38
     1b4:      	mov	w1, #0x8                // =8
     1b8:      	blr	x9
     1bc:      	ldr	x0, [sp, #0x38]
     1c0:      	str	x0, [sp, #0x30]
     1c4:      	cbnz	x0, 0x1d8 <generic_lsm_event+0x1d8>
     1c8:      	b	0x540 <generic_lsm_event+0x540>
     1cc:      	mov	x0, xzr
     1d0:      	str	xzr, [sp, #0x30]
     1d4:      	cbz	xzr, 0x540 <generic_lsm_event+0x540>
     1d8:      	str	x0, [sp, #0x38]
     1dc:      	adrp	x0, 0x0 <generic_lsm_event>
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x9, sp, #0x38
     1e8:      	ldr	x0, [x0]
     1ec:      	add	x1, sp, #0x38
     1f0:      	blr	x8
     1f4:      	cbz	x0, 0x204 <generic_lsm_event+0x204>
     1f8:      	ldr	x8, [x0]
     1fc:      	cbz	x8, 0x204 <generic_lsm_event+0x204>
     200:      	str	x8, [sp, #0x30]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x9, sp, #0x30
     20c:      	add	x1, sp, #0x30
     210:      	mov	x0, x23
     214:      	blr	x8
     218:      	mov	x8, x0
     21c:      	mov	x0, x24
     220:      	cbz	x8, 0x55c <generic_lsm_event+0x55c>
     224:      	ldr	w9, [x0]
     228:      	mov	w8, #0x6420             // =25632
     22c:      	stur	xzr, [x21, #0x4]
     230:      	str	xzr, [x20, #0x5eb8]
     234:      	str	xzr, [x20, #0x5ec0]
     238:      	str	wzr, [x20, x8]
     23c:      	mov	w8, #0x23               // =35
     240:      	str	xzr, [x20, #0x5ec8]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x9, xzr, [x20, #0x60]
     250:      	mov	w9, #0x5eb8             // =24248
     254:      	add	x9, x20, x9
     258:      	strb	wzr, [x9, #0x28]
     25c:      	blr	x8
     260:      	add	x2, x0, #0xb50
     264:      	mov	w25, #0x8               // =8
     268:      	add	x8, sp, #0x88
     26c:      	mov	w9, #0x4                // =4
     270:      	mov	x22, x0
     274:      	add	x0, sp, #0x88
     278:      	mov	w1, #0x8                // =8
     27c:      	add	x23, x20, #0x20
     280:      	mov	w24, #0x4               // =4
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x88]
     28c:      	mov	w9, #0x48               // =72
     290:      	add	x10, sp, #0x38
     294:      	mov	w11, #0x4               // =4
     298:      	ldr	x2, [sp, #0x88]
     29c:      	add	x0, sp, #0x38
     2a0:      	mov	w1, #0x48               // =72
     2a4:      	blr	x11
     2a8:      	ldr	x8, [sp, #0x40]
     2ac:      	mov	w9, #0x4                // =4
     2b0:      	mov	x0, x23
     2b4:      	mov	w1, #0x4                // =4
     2b8:      	add	x8, x8, #0x218
     2bc:      	ldr	x8, [sp, #0x40]
     2c0:      	add	x2, x8, #0x218
     2c4:      	blr	x9
     2c8:      	ldr	x8, [sp, #0x48]
     2cc:      	add	x0, x20, #0x24
     2d0:      	mov	w9, #0x4                // =4
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	add	x8, x8, #0x4d8
     2dc:      	ldr	x8, [sp, #0x48]
     2e0:      	add	x2, x8, #0x4d8
     2e4:      	blr	x9
     2e8:      	ldr	x8, [sp, #0x50]
     2ec:      	add	x0, x20, #0x28
     2f0:      	mov	w9, #0x4                // =4
     2f4:      	mov	w1, #0x4                // =4
     2f8:      	add	x8, x8, #0x58
     2fc:      	ldr	x8, [sp, #0x50]
     300:      	add	x2, x8, #0x58
     304:      	blr	x9
     308:      	str	xzr, [sp, #0x30]
     30c:      	add	x2, x22, #0x938
     310:      	add	x8, sp, #0x30
     314:      	add	x0, sp, #0x30
     318:      	mov	w1, #0x8                // =8
     31c:      	blr	x24
     320:      	ldr	x8, [sp, #0x30]
     324:      	cbz	x8, 0x3a8 <generic_lsm_event+0x3a8>
     328:      	str	wzr, [sp, #0x10]
     32c:      	add	x8, x8, #0x4
     330:      	add	x9, sp, #0x10
     334:      	mov	w10, #0x4               // =4
     338:      	add	x0, sp, #0x10
     33c:      	mov	w1, #0x4                // =4
     340:      	mov	w23, #0x4               // =4
     344:      	ldr	x8, [sp, #0x30]
     348:      	add	x2, x8, #0x4
     34c:      	blr	x10
     350:      	ldr	x8, [sp, #0x30]
     354:      	ldrsw	x9, [sp, #0x10]
     358:      	add	x10, sp, #0x20
     35c:      	mov	w11, #0x4               // =4
     360:      	add	x0, sp, #0x20
     364:      	mov	w1, #0x10               // =16
     368:      	add	x8, x8, x9, lsl #4
     36c:      	mov	w9, #0x10               // =16
     370:      	add	x8, x8, #0x80
     374:      	ldr	x8, [sp, #0x30]
     378:      	ldrsw	x9, [sp, #0x10]
     37c:      	add	x8, x8, x9, lsl #4
     380:      	add	x2, x8, #0x80
     384:      	blr	x11
     388:      	ldr	x8, [sp, #0x28]
     38c:      	add	x0, x20, #0x2c
     390:      	mov	w1, #0x4                // =4
     394:      	add	x8, x8, #0x158
     398:      	ldr	x8, [sp, #0x28]
     39c:      	add	x2, x8, #0x158
     3a0:      	blr	x23
     3a4:      	b	0x3ac <generic_lsm_event+0x3ac>
     3a8:      	str	wzr, [x20, #0x2c]
     3ac:      	ldr	x8, [sp, #0x58]
     3b0:      	add	x0, x20, #0x30
     3b4:      	mov	w9, #0x4                // =4
     3b8:      	mov	w1, #0x4                // =4
     3bc:      	mov	w24, #0x4               // =4
     3c0:      	add	x8, x8, #0x158
     3c4:      	ldr	x8, [sp, #0x58]
     3c8:      	add	x2, x8, #0x158
     3cc:      	blr	x9
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	add	x0, x20, #0x34
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w1, #0x4                // =4
     3e0:      	add	x8, x8, #0x118
     3e4:      	ldr	x8, [sp, #0x60]
     3e8:      	add	x2, x8, #0x118
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x68]
     3f4:      	add	x0, x20, #0x38
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x8, x8, #0x98
     404:      	ldr	x8, [sp, #0x68]
     408:      	add	x2, x8, #0x98
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x70]
     414:      	add	x0, x20, #0x3c
     418:      	mov	w9, #0x4                // =4
     41c:      	mov	w1, #0x4                // =4
     420:      	add	x8, x8, #0x98
     424:      	ldr	x8, [sp, #0x70]
     428:      	add	x2, x8, #0x98
     42c:      	blr	x9
     430:      	ldr	x8, [sp, #0x78]
     434:      	add	x0, x20, #0x40
     438:      	mov	w9, #0x4                // =4
     43c:      	mov	w1, #0x4                // =4
     440:      	add	x8, x8, #0x58
     444:      	ldr	x8, [sp, #0x78]
     448:      	add	x2, x8, #0x58
     44c:      	blr	x9
     450:      	str	xzr, [sp, #0x20]
     454:      	str	xzr, [sp, #0x30]
     458:      	add	x22, x22, #0xae0
     45c:      	mov	w25, #0x8               // =8
     460:      	add	x8, sp, #0x20
     464:      	mov	w9, #0x4                // =4
     468:      	add	x0, sp, #0x20
     46c:      	mov	w1, #0x8                // =8
     470:      	mov	x2, x22
     474:      	blr	x9
     478:      	ldr	x8, [sp, #0x20]
     47c:      	add	x9, sp, #0x30
     480:      	mov	w10, #0x4               // =4
     484:      	add	x0, sp, #0x30
     488:      	mov	w1, #0x8                // =8
     48c:      	add	x8, x8, #0x90
     490:      	ldr	x8, [sp, #0x20]
     494:      	add	x2, x8, #0x90
     498:      	blr	x10
     49c:      	ldr	x8, [sp, #0x30]
     4a0:      	add	x0, x20, #0x44
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	mov	w1, #0x4                // =4
     4ac:      	add	x8, x8, #0x158
     4b0:      	ldr	x8, [sp, #0x30]
     4b4:      	add	x2, x8, #0x158
     4b8:      	blr	x9
     4bc:      	add	x8, sp, #0x38
     4c0:      	mov	w9, #0x4                // =4
     4c4:      	add	x0, sp, #0x38
     4c8:      	mov	w1, #0x8                // =8
     4cc:      	mov	x2, x22
     4d0:      	add	x23, x20, #0x48
     4d4:      	blr	x9
     4d8:      	ldr	x22, [sp, #0x38]
     4dc:      	add	x0, x20, #0x50
     4e0:      	mov	w8, #0x4                // =4
     4e4:      	mov	w1, #0x8                // =8
     4e8:      	add	x2, x22, #0x40
     4ec:      	blr	x8
     4f0:      	add	x0, x20, #0x58
     4f4:      	add	x2, x22, #0x30
     4f8:      	mov	w8, #0x4                // =4
     4fc:      	mov	w1, #0x8                // =8
     500:      	blr	x8
     504:      	add	x2, x22, #0x38
     508:      	mov	x0, x23
     50c:      	mov	w1, #0x8                // =8
     510:      	blr	x24
     514:      	strb	wzr, [x21, #0x10]
     518:      	strb	wzr, [x20, #0x1]
     51c:      	adrp	x1, 0x0 <generic_lsm_event>
     520:      	mov	w8, #0x2                // =2
     524:      	mov	w9, #0xc                // =12
     528:      	mov	x0, x19
     52c:      	str	xzr, [x20, #0x5ee8]
     530:      	str	xzr, [x20, #0x5ef0]
     534:      	ldr	x1, [x1]
     538:      	mov	w2, #0x2                // =2
     53c:      	blr	x9
     540:      	ldp	x20, x19, [sp, #0xc0]
     544:      	mov	w0, wzr
     548:      	ldp	x22, x21, [sp, #0xb0]
     54c:      	ldp	x24, x23, [sp, #0xa0]
     550:      	ldp	x30, x25, [sp, #0x90]
     554:      	add	sp, sp, #0xd0
     558:      	ret
     55c:      	mov	x8, #-0x1               // =-1
     560:      	mov	w9, #0x1                // =1
     564:      	add	x1, sp, #0x10
     568:      	str	x8, [sp, #0x10]
     56c:      	add	x8, sp, #0x10
     570:      	mov	x0, x23
     574:      	mov	w25, #0x1               // =1
     578:      	blr	x9
     57c:      	cbz	x0, 0x540 <generic_lsm_event+0x540>
     580:      	str	w25, [sp, #0x1c]
     584:      	add	x8, sp, #0x1c
     588:      	add	x1, sp, #0x1c
     58c:      	mov	x0, x22
     590:      	blr	x25
     594:      	cbz	x0, 0x540 <generic_lsm_event+0x540>
     598:      	mov	w8, #0x1                // =1
     59c:      	add	x9, sp, #0x30
     5a0:      	add	x1, sp, #0x30
     5a4:      	blr	x8
     5a8:      	mov	x8, x0
     5ac:      	mov	x0, x24
     5b0:      	cbnz	x8, 0x540 <generic_lsm_event+0x540>
     5b4:      	b	0x224 <generic_lsm_event+0x224>
