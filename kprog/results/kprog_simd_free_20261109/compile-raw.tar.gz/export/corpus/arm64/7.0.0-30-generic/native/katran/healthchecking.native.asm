
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/katran/healthchecking.native.o:	file format elf64-littleaarch64

Disassembly of section tc:

0000000000000000 <healthcheck_encap>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x29, [sp, #0x40]
       8:      	stp	x30, x25, [sp, #0x50]
       c:      	stp	x24, x23, [sp, #0x60]
      10:      	stp	x22, x21, [sp, #0x70]
      14:      	stp	x20, x19, [sp, #0x80]
      18:      	ldr	w20, [x0, #0xa8]
      1c:      	mov	w8, #0x3                // =3
      20:      	mov	x19, x0
      24:      	str	wzr, [sp, #0x48]
      28:      	adrp	x0, 0x0 <healthcheck_encap>
      2c:      	add	x1, sp, #0x48
      30:      	stp	w20, w8, [sp, #0x28]
      34:      	mov	w8, #0x1                // =1
      38:      	ldr	x0, [x0]
      3c:      	blr	x8
      40:      	cbz	x0, 0x70 <healthcheck_encap+0x70>
      44:      	ldp	x9, x8, [x19, #0xc8]
      48:      	add	x10, x8, #0xe
      4c:      	ldr	w11, [x19, #0xbc]
      50:      	add	x9, x9, x11
      54:      	cmp	x10, x9
      58:      	b.ls	0x78 <healthcheck_encap+0x78>
      5c:      	ldr	x8, [x0, #0x8]
      60:      	add	x8, x8, #0x1
      64:      	str	x8, [x0, #0x8]
      68:      	mov	w0, #0x2                // =2
      6c:      	b	0x394 <healthcheck_encap+0x394>
      70:      	mov	w0, #-0x1               // =-1
      74:      	b	0x394 <healthcheck_encap+0x394>
      78:      	mov	x23, x0
      7c:      	cbz	w20, 0x134 <healthcheck_encap+0x134>
      80:      	adrp	x0, 0x0 <healthcheck_encap>
      84:      	ldrh	w29, [x8, #0xc]
      88:      	mov	w8, #0x1                // =1
      8c:      	add	x1, sp, #0x28
      90:      	ldr	x0, [x0]
      94:      	blr	x8
      98:      	cbz	x0, 0x134 <healthcheck_encap+0x134>
      9c:      	mov	x20, x0
      a0:      	adrp	x0, 0x0 <healthcheck_encap>
      a4:      	mov	w8, #0x1                // =1
      a8:      	ldr	x0, [x0]
      ac:      	add	x1, sp, #0x2c
      b0:      	blr	x8
      b4:      	cbz	x0, 0x384 <healthcheck_encap+0x384>
      b8:      	mov	x22, x0
      bc:      	str	wzr, [sp, #0x2c]
      c0:      	adrp	x0, 0x0 <healthcheck_encap>
      c4:      	mov	w21, #0x1               // =1
      c8:      	ldr	x0, [x0]
      cc:      	add	x1, sp, #0x2c
      d0:      	blr	x21
      d4:      	cbz	x0, 0x384 <healthcheck_encap+0x384>
      d8:      	mov	x24, x0
      dc:      	str	w21, [sp, #0x2c]
      e0:      	adrp	x0, 0x0 <healthcheck_encap>
      e4:      	add	x1, sp, #0x2c
      e8:      	ldr	x0, [x0]
      ec:      	blr	x21
      f0:      	cbz	x0, 0x384 <healthcheck_encap+0x384>
      f4:      	ldr	w8, [x19, #0xbc]
      f8:      	ldp	x9, x10, [x19, #0xc8]
      fc:      	add	x8, x9, x8
     100:      	mov	w9, #0xdd86             // =56710
     104:      	str	wzr, [sp, #0x20]
     108:      	cmp	w29, w9
     10c:      	stp	xzr, xzr, [sp, #0x10]
     110:      	b.ne	0x148 <healthcheck_encap+0x148>
     114:      	add	x9, x10, #0x36
     118:      	cmp	x9, x8
     11c:      	b.hi	0x184 <healthcheck_encap+0x184>
     120:      	ldur	x11, [x10, #0x26]
     124:      	ldur	x12, [x10, #0x2e]
     128:      	stp	x11, x12, [sp, #0x10]
     12c:      	mov	w11, #0x14              // =20
     130:      	b	0x160 <healthcheck_encap+0x160>
     134:      	ldr	x8, [x23, #0x10]
     138:      	mov	w0, #-0x1               // =-1
     13c:      	add	x8, x8, #0x1
     140:      	str	x8, [x23, #0x10]
     144:      	b	0x394 <healthcheck_encap+0x394>
     148:      	add	x9, x10, #0x22
     14c:      	cmp	x9, x8
     150:      	b.hi	0x184 <healthcheck_encap+0x184>
     154:      	ldur	w11, [x10, #0x1e]
     158:      	str	w11, [sp, #0x10]
     15c:      	mov	w11, #0x17              // =23
     160:      	ldrb	w10, [x10, x11]
     164:      	cmp	w10, #0x11
     168:      	strb	w10, [sp, #0x22]
     16c:      	b.eq	0x24c <healthcheck_encap+0x24c>
     170:      	cmp	w10, #0x6
     174:      	b.ne	0x184 <healthcheck_encap+0x184>
     178:      	add	x10, x9, #0x14
     17c:      	cmp	x10, x8
     180:      	b.ls	0x258 <healthcheck_encap+0x258>
     184:      	str	wzr, [sp, #0x4]
     188:      	ldrb	w8, [x20, #0x10]
     18c:      	ldr	w25, [x19, #0x70]
     190:      	cmp	w8, #0x1
     194:      	str	x0, [sp, #0x8]
     198:      	str	wzr, [x19, #0xa8]
     19c:      	b.ne	0x280 <healthcheck_encap+0x280>
     1a0:      	mov	w8, #0x1                // =1
     1a4:      	adrp	x0, 0x0 <healthcheck_encap>
     1a8:      	add	x1, sp, #0x4c
     1ac:      	str	w8, [sp, #0x4c]
     1b0:      	ldr	x0, [x0]
     1b4:      	blr	x8
     1b8:      	cbz	x0, 0x384 <healthcheck_encap+0x384>
     1bc:      	mov	x21, x0
     1c0:      	mov	w8, #0x32               // =50
     1c4:      	mov	x0, x19
     1c8:      	mov	w1, #0x28               // =40
     1cc:      	mov	w2, #0x1                // =1
     1d0:      	mov	w3, #0x5                // =5
     1d4:      	blr	x8
     1d8:      	cbnz	w0, 0x384 <healthcheck_encap+0x384>
     1dc:      	ldp	x9, x8, [x19, #0xc8]
     1e0:      	add	x10, x8, #0x36
     1e4:      	ldr	w11, [x19, #0xbc]
     1e8:      	add	x9, x9, x11
     1ec:      	cmp	x10, x9
     1f0:      	b.hi	0x384 <healthcheck_encap+0x384>
     1f4:      	mov	w10, #0xdd86            // =56710
     1f8:      	mov	w11, #0x29              // =41
     1fc:      	sub	w9, w25, #0xe
     200:      	strh	w10, [x8, #0xc]
     204:      	cmp	w29, w10
     208:      	mov	w10, #0x4               // =4
     20c:      	rev	w9, w9
     210:      	mov	w13, #0x60              // =96
     214:      	csel	w10, w11, w10, eq
     218:      	ldp	x12, x11, [x21]
     21c:      	lsr	w9, w9, #16
     220:      	stur	w13, [x8, #0xe]
     224:      	strh	w9, [x8, #0x12]
     228:      	mov	w9, #0x40               // =64
     22c:      	strb	w10, [x8, #0x14]
     230:      	strb	w9, [x8, #0x15]
     234:      	stur	x12, [x8, #0x16]
     238:      	stur	x11, [x8, #0x1e]
     23c:      	ldp	x10, x9, [x20]
     240:      	stur	x10, [x8, #0x26]
     244:      	stur	x9, [x8, #0x2e]
     248:      	b	0x368 <healthcheck_encap+0x368>
     24c:      	add	x10, x9, #0x8
     250:      	cmp	x10, x8
     254:      	b.hi	0x184 <healthcheck_encap+0x184>
     258:      	ldrh	w8, [x9, #0x2]
     25c:      	strh	w8, [sp, #0x20]
     260:      	mov	w8, #0x1                // =1
     264:      	str	w8, [sp, #0x4]
     268:      	ldrb	w8, [x20, #0x10]
     26c:      	ldr	w25, [x19, #0x70]
     270:      	cmp	w8, #0x1
     274:      	str	x0, [sp, #0x8]
     278:      	str	wzr, [x19, #0xa8]
     27c:      	b.eq	0x1a0 <healthcheck_encap+0x1a0>
     280:      	str	wzr, [sp, #0x4c]
     284:      	adrp	x0, 0x0 <healthcheck_encap>
     288:      	mov	w8, #0x1                // =1
     28c:      	add	x1, sp, #0x4c
     290:      	ldr	x0, [x0]
     294:      	blr	x8
     298:      	cbz	x0, 0x384 <healthcheck_encap+0x384>
     29c:      	mov	x21, x0
     2a0:      	mov	w8, #0x32               // =50
     2a4:      	mov	x0, x19
     2a8:      	mov	w1, #0x14               // =20
     2ac:      	mov	w2, #0x1                // =1
     2b0:      	mov	w3, #0x3                // =3
     2b4:      	blr	x8
     2b8:      	cbnz	w0, 0x384 <healthcheck_encap+0x384>
     2bc:      	ldp	x9, x8, [x19, #0xc8]
     2c0:      	add	x10, x8, #0x22
     2c4:      	ldr	w11, [x19, #0xbc]
     2c8:      	add	x9, x9, x11
     2cc:      	cmp	x10, x9
     2d0:      	b.hi	0x384 <healthcheck_encap+0x384>
     2d4:      	mov	w11, #0x45              // =69
     2d8:      	ldr	w9, [x21]
     2dc:      	ldr	w10, [x20]
     2e0:      	mov	w12, #0x440             // =1088
     2e4:      	stur	wzr, [x8, #0x12]
     2e8:      	strh	w11, [x8, #0xe]
     2ec:      	add	w11, w25, #0x6
     2f0:      	rev	w11, w11
     2f4:      	strh	w12, [x8, #0x16]
     2f8:      	ldrh	w12, [x8, #0xe]
     2fc:      	lsr	w11, w11, #16
     300:      	strh	w11, [x8, #0x10]
     304:      	stur	w9, [x8, #0x1a]
     308:      	stur	w10, [x8, #0x1e]
     30c:      	add	x11, x12, x11
     310:      	ldrh	w12, [x8, #0x16]
     314:      	add	x11, x11, x12
     318:      	add	x11, x11, w9, uxth
     31c:      	add	x9, x11, x9, lsr #16
     320:      	add	x9, x9, w10, uxth
     324:      	ldrh	w10, [x8, #0x20]
     328:      	add	x9, x9, x10
     32c:      	lsr	x10, x9, #16
     330:      	cmp	x9, #0x10, lsl #12      // =0x10000
     334:      	add	x10, x10, w9, uxth
     338:      	csel	x9, x9, x10, lo
     33c:      	lsr	x10, x9, #16
     340:      	cmp	x9, #0x10, lsl #12      // =0x10000
     344:      	add	x10, x10, w9, uxth
     348:      	csel	x9, x9, x10, lo
     34c:      	lsr	x10, x9, #16
     350:      	cmp	x9, #0x10, lsl #12      // =0x10000
     354:      	add	w10, w10, w9, uxth
     358:      	csel	x9, x9, x10, lo
     35c:      	add	w9, w9, w9, lsr #16
     360:      	mvn	w9, w9
     364:      	strh	w9, [x8, #0x18]
     368:      	ldp	x8, x9, [x19, #0xc8]
     36c:      	add	x10, x9, #0xe
     370:      	ldr	w11, [x19, #0xbc]
     374:      	add	x8, x8, x11
     378:      	cmp	x10, x8
     37c:      	ldr	x10, [sp, #0x8]
     380:      	b.ls	0x3b0 <healthcheck_encap+0x3b0>
     384:      	ldr	x8, [x23, #0x8]
     388:      	mov	w0, #0x2                // =2
     38c:      	add	x8, x8, #0x1
     390:      	str	x8, [x23, #0x8]
     394:      	ldp	x20, x19, [sp, #0x80]
     398:      	ldr	x29, [sp, #0x40]
     39c:      	ldp	x22, x21, [sp, #0x70]
     3a0:      	ldp	x24, x23, [sp, #0x60]
     3a4:      	ldp	x30, x25, [sp, #0x50]
     3a8:      	add	sp, sp, #0x90
     3ac:      	ret
     3b0:      	ldr	w11, [x24]
     3b4:      	ldrh	w12, [x24, #0x4]
     3b8:      	mov	x8, x22
     3bc:      	strh	w12, [x9, #0xa]
     3c0:      	stur	w11, [x9, #0x6]
     3c4:      	ldr	w11, [x10]
     3c8:      	ldrh	w10, [x10, #0x4]
     3cc:      	strh	w10, [x9, #0x4]
     3d0:      	str	w11, [x9]
     3d4:      	ldr	x9, [x23]
     3d8:      	add	x9, x9, #0x1
     3dc:      	str	x9, [x23]
     3e0:      	ldr	w9, [sp, #0x4]
     3e4:      	cbz	w9, 0x42c <healthcheck_encap+0x42c>
     3e8:      	adrp	x0, 0x0 <healthcheck_encap>
     3ec:      	mov	w8, #0x1                // =1
     3f0:      	add	x1, sp, #0x10
     3f4:      	ldr	x0, [x0]
     3f8:      	blr	x8
     3fc:      	mov	x8, x22
     400:      	cbz	x0, 0x42c <healthcheck_encap+0x42c>
     404:      	mov	x1, x0
     408:      	adrp	x0, 0x0 <healthcheck_encap>
     40c:      	mov	w8, #0x1                // =1
     410:      	ldr	x0, [x0]
     414:      	blr	x8
     418:      	mov	x8, x22
     41c:      	cbz	x0, 0x42c <healthcheck_encap+0x42c>
     420:      	ldr	w9, [x0]
     424:      	add	w9, w9, #0x1
     428:      	str	w9, [x0]
     42c:      	ldr	w0, [x8]
     430:      	mov	w8, #0x17               // =23
     434:      	mov	w1, wzr
     438:      	blr	x8
     43c:      	b	0x394 <healthcheck_encap+0x394>
