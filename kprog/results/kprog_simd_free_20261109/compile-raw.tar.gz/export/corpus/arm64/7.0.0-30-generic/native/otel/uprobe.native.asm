
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/uprobe.native.o:	file format elf64-littleaarch64

Disassembly of section uprobe/generic:

0000000000000000 <uprobe__generic>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp, #0x190]
       8:      	stp	x30, x25, [sp, #0x1a0]
       c:      	stp	x24, x23, [sp, #0x1b0]
      10:      	stp	x22, x21, [sp, #0x1c0]
      14:      	stp	x20, x19, [sp, #0x1d0]
      18:      	mov	w8, #0xe                // =14
      1c:      	mov	x19, x0
      20:      	blr	x8
      24:      	mov	x23, x0
      28:      	lsr	x22, x0, #32
      2c:      	cmp	w23, #0x0
      30:      	ccmp	w22, #0x0, #0x4, ne
      34:      	b.ne	0x40 <uprobe__generic+0x40>
      38:      	mov	w0, wzr
      3c:      	b	0x4ac <uprobe__generic+0x4ac>
      40:      	mov	w8, #0x5                // =5
      44:      	blr	x8
      48:      	adrp	x25, 0x0 <uprobe__generic>
      4c:      	mov	x24, x0
      50:      	ldr	x25, [x25]
      54:      	ldr	w8, [x25]
      58:      	cbnz	w8, 0x2a0 <uprobe__generic+0x2a0>
      5c:      	str	wzr, [sp]
      60:      	adrp	x20, 0x0 <uprobe__generic>
      64:      	mov	w8, #0x1                // =1
      68:      	mov	x9, sp
      6c:      	ldr	x20, [x20]
      70:      	mov	x1, sp
      74:      	mov	x0, x20
      78:      	blr	x8
      7c:      	cbz	x0, 0x4a8 <uprobe__generic+0x4a8>
      80:      	mov	w8, #-0x1               // =-1
      84:      	mov	w9, #0x100              // =256
      88:      	mov	x21, x0
      8c:      	strh	wzr, [x0, #0xf20]
      90:      	str	xzr, [x0, #0xed0]
      94:      	mov	w1, wzr
      98:      	str	xzr, [x0, #0xed8]
      9c:      	str	xzr, [x0, #0xee0]
      a0:      	mov	w2, #0x29c              // =668
      a4:      	str	xzr, [x0, #0xee8]
      a8:      	str	xzr, [x0, #0xef0]
      ac:      	str	xzr, [x0, #0xef8]
      b0:      	str	x8, [x0, #0xf18]
      b4:      	str	wzr, [x0, #0x1370]
      b8:      	strh	w9, [x0, #0x1374]
      bc:      	add	x9, x0, #0x2bc
      c0:      	str	xzr, [x0, #0xf28]
      c4:      	str	xzr, [x0, #0xf30]
      c8:      	str	xzr, [x0, #0xf48]
      cc:      	str	xzr, [x0, #0xf50]
      d0:      	str	xzr, [x0, #0xf58]
      d4:      	str	xzr, [x0, #0xf60]
      d8:      	str	xzr, [x0, #0xf68]
      dc:      	add	x0, x0, #0x20
      e0:      	str	x8, [x9]
      e4:      	bl	0xe4 <uprobe__generic+0xe4>
      e8:      	mov	w8, #0x3                // =3
      ec:      	stp	w22, w23, [x21]
      f0:      	str	x24, [x21, #0x8]
      f4:      	add	x0, x21, #0x10
      f8:      	mov	w1, #0x10               // =16
      fc:      	str	w8, [x21, #0x2c4]
     100:      	str	xzr, [x21, #0x2c8]
     104:      	mov	w8, #0x10               // =16
     108:      	blr	x8
     10c:      	tbz	w0, #0x1f, 0x14c <uprobe__generic+0x14c>
     110:      	mov	w8, #0x34               // =52
     114:      	adrp	x0, 0x0 <uprobe__generic>
     118:      	add	x9, sp, #0x150
     11c:      	str	w8, [sp, #0x150]
     120:      	mov	w8, #0x1                // =1
     124:      	add	x1, sp, #0x150
     128:      	ldr	x0, [x0]
     12c:      	blr	x8
     130:      	cbz	x0, 0x144 <uprobe__generic+0x144>
     134:      	ldr	x8, [x0]
     138:      	add	x8, x8, #0x1
     13c:      	str	x8, [x0]
     140:      	b	0x14c <uprobe__generic+0x14c>
     144:      	ldr	w8, [x25]
     148:      	cbnz	w8, 0x988 <uprobe__generic+0x988>
     14c:      	adrp	x1, 0x0 <uprobe__generic>
     150:      	mov	w8, #0x400              // =1024
     154:      	mov	w9, #0x1b               // =27
     158:      	ldr	x1, [x1]
     15c:      	mov	x0, x19
     160:      	mov	w2, #0x400              // =1024
     164:      	blr	x9
     168:      	ldr	w8, [x25]
     16c:      	str	w0, [x21, #0x2bc]
     170:      	cbnz	w8, 0x2d4 <uprobe__generic+0x2d4>
     174:      	ldr	x8, [x19, #0x108]
     178:      	tst	x8, #0xf
     17c:      	b.eq	0x314 <uprobe__generic+0x314>
     180:      	mov	w8, #0x23               // =35
     184:      	blr	x8
     188:      	adrp	x8, 0x0 <uprobe__generic>
     18c:      	mov	w9, #0x71               // =113
     190:      	mov	x10, sp
     194:      	ldr	x8, [x8]
     198:      	mov	w1, #0x8                // =8
     19c:      	ldr	w8, [x8]
     1a0:      	add	x2, x0, x8
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	x0, sp
     1ac:      	blr	x9
     1b0:      	cbnz	x0, 0x1e8 <uprobe__generic+0x1e8>
     1b4:      	adrp	x9, 0x0 <uprobe__generic>
     1b8:      	ldr	x8, [sp]
     1bc:      	ldr	x9, [x9]
     1c0:      	ldr	w9, [x9]
     1c4:      	add	x2, x8, x9
     1c8:      	cbz	x2, 0x1e8 <uprobe__generic+0x1e8>
     1cc:      	mov	w8, #0x150              // =336
     1d0:      	mov	w9, #0x71               // =113
     1d4:      	mov	x10, sp
     1d8:      	mov	x0, sp
     1dc:      	mov	w1, #0x150              // =336
     1e0:      	blr	x9
     1e4:      	cbz	x0, 0x230 <uprobe__generic+0x230>
     1e8:      	mov	w8, #0x52               // =82
     1ec:      	adrp	x0, 0x0 <uprobe__generic>
     1f0:      	add	x9, sp, #0x188
     1f4:      	str	w8, [sp, #0x188]
     1f8:      	mov	w8, #0x1                // =1
     1fc:      	add	x1, sp, #0x188
     200:      	ldr	x0, [x0]
     204:      	blr	x8
     208:      	cbz	x0, 0x21c <uprobe__generic+0x21c>
     20c:      	ldr	x8, [x0]
     210:      	add	x8, x8, #0x1
     214:      	str	x8, [x0]
     218:      	b	0x224 <uprobe__generic+0x224>
     21c:      	ldr	w8, [x25]
     220:      	cbnz	w8, 0x93c <uprobe__generic+0x93c>
     224:      	mov	w22, wzr
     228:      	mov	w8, #0xfa9              // =4009
     22c:      	b	0x3d8 <uprobe__generic+0x3d8>
     230:      	ldr	x8, [sp, #0x108]
     234:      	tst	x8, #0xf
     238:      	b.eq	0x248 <uprobe__generic+0x248>
     23c:      	mov	w22, wzr
     240:      	mov	w8, wzr
     244:      	b	0x3d8 <uprobe__generic+0x3d8>
     248:      	tbnz	w8, #0x4, 0x3d0 <uprobe__generic+0x3d0>
     24c:      	ldp	x10, x8, [sp, #0xf0]
     250:      	str	x8, [x21, #0xed8]
     254:      	ldp	x9, x11, [sp, #0xe0]
     258:      	ldr	x8, [sp, #0xb0]
     25c:      	str	x11, [x21, #0xee0]
     260:      	str	x8, [x21, #0xef0]
     264:      	adrp	x8, 0x0 <uprobe__generic>
     268:      	ldr	x8, [x8]
     26c:      	str	x9, [x21, #0xef8]
     270:      	ldr	x9, [sp, #0x100]
     274:      	strb	wzr, [x21, #0xf21]
     278:      	ldr	x8, [x8]
     27c:      	and	x9, x8, x9
     280:      	and	x8, x10, x8
     284:      	str	x8, [x21, #0xee8]
     288:      	ldr	w8, [sp, #0x118]
     28c:      	str	x9, [x21, #0xed0]
     290:      	cmn	w8, #0x1
     294:      	cset	w8, ne
     298:      	strb	w8, [x21, #0xf20]
     29c:      	b	0x360 <uprobe__generic+0x360>
     2a0:      	adrp	x8, 0x0 <uprobe__generic>
     2a4:      	add	x8, x8, #0x0
     2a8:      	mov	x0, sp
     2ac:      	ldp	x9, x10, [x8]
     2b0:      	ldur	x8, [x8, #0xe]
     2b4:      	mov	w1, #0x16               // =22
     2b8:      	stp	x9, x10, [sp]
     2bc:      	stur	x8, [sp, #0xe]
     2c0:      	mov	w8, #0x16               // =22
     2c4:      	mov	w9, #0x6                // =6
     2c8:      	mov	x10, sp
     2cc:      	blr	x9
     2d0:      	b	0x5c <uprobe__generic+0x5c>
     2d4:      	adrp	x8, 0x0 <uprobe__generic>
     2d8:      	add	x8, x8, #0x0
     2dc:      	mov	x0, sp
     2e0:      	ldp	x9, x10, [x8]
     2e4:      	ldur	x8, [x8, #0xe]
     2e8:      	mov	w1, #0x16               // =22
     2ec:      	stp	x9, x10, [sp]
     2f0:      	stur	x8, [sp, #0xe]
     2f4:      	mov	w8, #0x16               // =22
     2f8:      	mov	w9, #0x6                // =6
     2fc:      	mov	x10, sp
     300:      	ldr	w2, [x21, #0x2bc]
     304:      	blr	x9
     308:      	ldr	x8, [x19, #0x108]
     30c:      	tst	x8, #0xf
     310:      	b.ne	0x180 <uprobe__generic+0x180>
     314:      	tbnz	w8, #0x4, 0x3d0 <uprobe__generic+0x3d0>
     318:      	adrp	x8, 0x0 <uprobe__generic>
     31c:      	ldr	x8, [x8]
     320:      	ldr	x9, [x19, #0x100]
     324:      	ldr	x8, [x8]
     328:      	and	x9, x8, x9
     32c:      	str	x9, [x21, #0xed0]
     330:      	ldr	x9, [x19, #0xf8]
     334:      	str	x9, [x21, #0xed8]
     338:      	ldr	x9, [x19, #0xe8]
     33c:      	str	x9, [x21, #0xee0]
     340:      	ldr	x9, [x19, #0xf0]
     344:      	and	x8, x9, x8
     348:      	str	x8, [x21, #0xee8]
     34c:      	ldr	x8, [x19, #0xb0]
     350:      	str	x8, [x21, #0xef0]
     354:      	ldr	x8, [x19, #0xe0]
     358:      	strh	wzr, [x21, #0xf20]
     35c:      	str	x8, [x21, #0xef8]
     360:      	ldr	w8, [x25]
     364:      	cbnz	w8, 0x8f4 <uprobe__generic+0x8f4>
     368:      	mov	w8, #0x60               // =96
     36c:      	rev	w9, w22
     370:      	str	xzr, [sp, #0x8]
     374:      	adrp	x24, 0x0 <uprobe__generic>
     378:      	stp	w8, w9, [sp]
     37c:      	mov	w8, #0x1                // =1
     380:      	mov	x9, sp
     384:      	mov	x1, sp
     388:      	ldr	x24, [x24]
     38c:      	mov	x0, x24
     390:      	blr	x8
     394:      	cbz	x0, 0x4c8 <uprobe__generic+0x4c8>
     398:      	add	x8, x21, #0xed0
     39c:      	ldr	x23, [x8]
     3a0:      	ldr	w8, [x25]
     3a4:      	cbz	x23, 0x564 <uprobe__generic+0x564>
     3a8:      	cbnz	w8, 0xa18 <uprobe__generic+0xa18>
     3ac:      	lsr	x8, x23, #56
     3b0:      	cbz	x8, 0xa64 <uprobe__generic+0xa64>
     3b4:      	ldr	w8, [x25]
     3b8:      	cbnz	w8, 0xc20 <uprobe__generic+0xc20>
     3bc:      	mov	w8, #0xb                // =11
     3c0:      	mov	w22, wzr
     3c4:      	str	w8, [x21, #0xf18]
     3c8:      	mov	w8, #0xfab              // =4011
     3cc:      	b	0x3d8 <uprobe__generic+0x3d8>
     3d0:      	mov	w22, wzr
     3d4:      	mov	w8, #0xfb0              // =4016
     3d8:      	str	w8, [x21, #0xf1c]
     3dc:      	str	wzr, [sp]
     3e0:      	mov	w8, #0x1                // =1
     3e4:      	mov	x9, sp
     3e8:      	mov	x1, sp
     3ec:      	mov	x0, x20
     3f0:      	blr	x8
     3f4:      	cbz	x0, 0x44c <uprobe__generic+0x44c>
     3f8:      	mov	w20, #0x1374            // =4980
     3fc:      	mov	w2, w22
     400:      	ldrb	w8, [x0, x20]
     404:      	cmp	w8, #0x1d
     408:      	b.lo	0x478 <uprobe__generic+0x478>
     40c:      	mov	w8, #0x5                // =5
     410:      	mov	x21, x0
     414:      	add	x9, sp, #0x150
     418:      	str	w8, [x0, #0xf1c]
     41c:      	mov	w8, #0x44               // =68
     420:      	adrp	x0, 0x0 <uprobe__generic>
     424:      	add	x1, sp, #0x150
     428:      	str	w8, [sp, #0x150]
     42c:      	mov	w8, #0x1                // =1
     430:      	ldr	x0, [x0]
     434:      	blr	x8
     438:      	cbz	x0, 0x464 <uprobe__generic+0x464>
     43c:      	ldr	x8, [x0]
     440:      	add	x8, x8, #0x1
     444:      	str	x8, [x0]
     448:      	b	0x46c <uprobe__generic+0x46c>
     44c:      	adrp	x10, 0x0 <uprobe__generic>
     450:      	mov	x9, xzr
     454:      	mov	w8, #0xc                // =12
     458:      	ldr	x10, [x10]
     45c:      	mov	w2, wzr
     460:      	b	0x490 <uprobe__generic+0x490>
     464:      	ldr	w8, [x25]
     468:      	cbnz	w8, 0x9d0 <uprobe__generic+0x9d0>
     46c:      	ldrb	w8, [x21, x20]
     470:      	mov	w2, wzr
     474:      	mov	x0, x21
     478:      	add	w8, w8, #0x1
     47c:      	adrp	x10, 0x0 <uprobe__generic>
     480:      	mov	w9, w2
     484:      	strb	w8, [x0, x20]
     488:      	mov	w8, #0xc                // =12
     48c:      	ldr	x10, [x10]
     490:      	adrp	x1, 0x0 <uprobe__generic>
     494:      	mov	x0, x19
     498:      	ldr	x1, [x1]
     49c:      	blr	x8
     4a0:      	ldr	w8, [x25]
     4a4:      	cbnz	w8, 0x8a8 <uprobe__generic+0x8a8>
     4a8:      	mov	w0, #-0x1               // =-1
     4ac:      	ldp	x20, x19, [sp, #0x1d0]
     4b0:      	ldr	x29, [sp, #0x190]
     4b4:      	ldp	x22, x21, [sp, #0x1c0]
     4b8:      	ldp	x24, x23, [sp, #0x1b0]
     4bc:      	ldp	x30, x25, [sp, #0x1a0]
     4c0:      	add	sp, sp, #0x1e0
     4c4:      	ret
     4c8:      	str	x23, [sp, #0x188]
     4cc:      	str	w22, [sp, #0x198]
     4d0:      	adrp	x20, 0x0 <uprobe__generic>
     4d4:      	mov	w8, #0x1                // =1
     4d8:      	add	x9, sp, #0x198
     4dc:      	add	x1, sp, #0x198
     4e0:      	ldr	x20, [x20]
     4e4:      	mov	x0, x20
     4e8:      	blr	x8
     4ec:      	mov	w8, #0x5                // =5
     4f0:      	mov	x21, x0
     4f4:      	blr	x8
     4f8:      	cbz	x21, 0x5b8 <uprobe__generic+0x5b8>
     4fc:      	ldr	x8, [x21]
     500:      	mov	w11, #0xe100            // =57600
     504:      	movk	w11, #0x5f5, lsl #16
     508:      	and	x9, x8, #0xffffffffffffffe0
     50c:      	and	x10, x8, #0xf
     510:      	sub	x9, x0, x9
     514:      	lsl	x10, x11, x10
     518:      	cmp	x9, x10
     51c:      	b.hs	0x57c <uprobe__generic+0x57c>
     520:      	ldr	w8, [x25]
     524:      	cbz	w8, 0x38 <uprobe__generic+0x38>
     528:      	adrp	x8, 0x0 <uprobe__generic>
     52c:      	add	x8, x8, #0x0
     530:      	mov	x0, sp
     534:      	ldp	x9, x10, [x8]
     538:      	mov	w1, #0x20               // =32
     53c:      	stp	x9, x10, [sp]
     540:      	ldp	x9, x8, [x8, #0x10]
     544:      	mov	x10, sp
     548:      	stp	x9, x8, [sp, #0x10]
     54c:      	mov	w8, #0x20               // =32
     550:      	mov	w9, #0x6                // =6
     554:      	ldr	w2, [sp, #0x198]
     558:      	blr	x9
     55c:      	mov	w0, wzr
     560:      	b	0x4ac <uprobe__generic+0x4ac>
     564:      	cbnz	w8, 0xbe0 <uprobe__generic+0xbe0>
     568:      	mov	w8, #0x1                // =1
     56c:      	mov	w22, wzr
     570:      	str	w8, [x21, #0xf18]
     574:      	mov	w8, #0xfad              // =4013
     578:      	b	0x3d8 <uprobe__generic+0x3d8>
     57c:      	mov	x11, #0xf200            // =61952
     580:      	and	w21, w8, #0x10
     584:      	movk	x11, #0x2a05, lsl #16
     588:      	movk	x11, #0x1, lsl #32
     58c:      	add	x10, x10, x11
     590:      	cmp	x9, x10
     594:      	b.hs	0x5b8 <uprobe__generic+0x5b8>
     598:      	cmp	w21, #0x0
     59c:      	mov	w9, #0x4                // =4
     5a0:      	mov	w10, #0x8               // =8
     5a4:      	and	w8, w8, #0xf
     5a8:      	csel	w9, w10, w9, eq
     5ac:      	cmp	w9, w8
     5b0:      	cinc	w23, w8, hi
     5b4:      	b	0x5bc <uprobe__generic+0x5bc>
     5b8:      	mov	w23, wzr
     5bc:      	ldr	w8, [x25]
     5c0:      	cbnz	w8, 0xb94 <uprobe__generic+0xb94>
     5c4:      	mov	w9, w21
     5c8:      	and	x10, x23, #0xff
     5cc:      	and	x8, x0, #0xffffffffffffffe0
     5d0:      	mov	x3, xzr
     5d4:      	add	x1, sp, #0x198
     5d8:      	add	x2, sp, #0x150
     5dc:      	mov	x0, x20
     5e0:      	orr	x9, x9, x10
     5e4:      	add	x10, sp, #0x150
     5e8:      	orr	x8, x8, x9
     5ec:      	str	x8, [sp, #0x150]
     5f0:      	mov	w8, #0x2                // =2
     5f4:      	add	x9, sp, #0x198
     5f8:      	blr	x8
     5fc:      	cbz	w0, 0x670 <uprobe__generic+0x670>
     600:      	ldr	w8, [x25]
     604:      	cbnz	w8, 0xc60 <uprobe__generic+0xc60>
     608:      	mov	w8, #0x3d               // =61
     60c:      	adrp	x0, 0x0 <uprobe__generic>
     610:      	add	x9, sp, #0x19c
     614:      	str	w8, [sp, #0x19c]
     618:      	mov	w8, #0x1                // =1
     61c:      	add	x1, sp, #0x19c
     620:      	ldr	x0, [x0]
     624:      	blr	x8
     628:      	cbnz	x0, 0x6cc <uprobe__generic+0x6cc>
     62c:      	ldr	w8, [x25]
     630:      	cbz	w8, 0x38 <uprobe__generic+0x38>
     634:      	adrp	x8, 0x0 <uprobe__generic>
     638:      	add	x8, x8, #0x0
     63c:      	ldp	x9, x10, [x8, #0x10]
     640:      	stp	x9, x10, [sp, #0x10]
     644:      	ldr	x9, [x8, #0x20]
     648:      	mov	x10, sp
     64c:      	str	x9, [sp, #0x20]
     650:      	ldur	x9, [x8, #0x26]
     654:      	stur	x9, [sp, #0x26]
     658:      	ldp	x9, x8, [x8]
     65c:      	stp	x9, x8, [sp]
     660:      	mov	w8, #0x2e               // =46
     664:      	mov	w9, #0x6                // =6
     668:      	ldr	w2, [sp, #0x19c]
     66c:      	b	0x780 <uprobe__generic+0x780>
     670:      	mov	w20, #0x1               // =1
     674:      	adrp	x0, 0x0 <uprobe__generic>
     678:      	mov	x3, xzr
     67c:      	strb	w20, [sp, #0x184]
     680:      	mov	w8, #0x2                // =2
     684:      	add	x9, sp, #0x188
     688:      	add	x10, sp, #0x184
     68c:      	ldr	x0, [x0]
     690:      	add	x1, sp, #0x188
     694:      	add	x2, sp, #0x184
     698:      	blr	x8
     69c:      	cbz	w0, 0x6dc <uprobe__generic+0x6dc>
     6a0:      	ldr	w8, [x25]
     6a4:      	cbnz	w8, 0xd84 <uprobe__generic+0xd84>
     6a8:      	mov	w8, #0x3e               // =62
     6ac:      	adrp	x0, 0x0 <uprobe__generic>
     6b0:      	add	x9, sp, #0x150
     6b4:      	str	w8, [sp, #0x150]
     6b8:      	mov	w8, #0x1                // =1
     6bc:      	add	x1, sp, #0x150
     6c0:      	ldr	x0, [x0]
     6c4:      	blr	x8
     6c8:      	cbz	x0, 0x740 <uprobe__generic+0x740>
     6cc:      	ldr	x8, [x0]
     6d0:      	add	x8, x8, #0x1
     6d4:      	str	x8, [x0]
     6d8:      	b	0x38 <uprobe__generic+0x38>
     6dc:      	str	w20, [sp, #0x19c]
     6e0:      	strb	w20, [sp, #0x198]
     6e4:      	adrp	x0, 0x0 <uprobe__generic>
     6e8:      	mov	w8, #0x2                // =2
     6ec:      	add	x9, sp, #0x19c
     6f0:      	add	x10, sp, #0x198
     6f4:      	ldr	x0, [x0]
     6f8:      	add	x1, sp, #0x19c
     6fc:      	add	x2, sp, #0x198
     700:      	mov	w3, #0x1                // =1
     704:      	blr	x8
     708:      	tbnz	w0, #0x1f, 0x794 <uprobe__generic+0x794>
     70c:      	mov	w8, #0x42               // =66
     710:      	adrp	x0, 0x0 <uprobe__generic>
     714:      	add	x9, sp, #0x150
     718:      	str	w8, [sp, #0x150]
     71c:      	mov	w8, #0x1                // =1
     720:      	add	x1, sp, #0x150
     724:      	ldr	x0, [x0]
     728:      	blr	x8
     72c:      	cbz	x0, 0x7d8 <uprobe__generic+0x7d8>
     730:      	ldr	x8, [x0]
     734:      	add	x8, x8, #0x1
     738:      	str	x8, [x0]
     73c:      	b	0x7e0 <uprobe__generic+0x7e0>
     740:      	ldr	w8, [x25]
     744:      	cbz	w8, 0x38 <uprobe__generic+0x38>
     748:      	adrp	x8, 0x0 <uprobe__generic>
     74c:      	add	x8, x8, #0x0
     750:      	ldp	x9, x10, [x8, #0x10]
     754:      	stp	x9, x10, [sp, #0x10]
     758:      	ldr	x9, [x8, #0x20]
     75c:      	mov	x10, sp
     760:      	str	x9, [sp, #0x20]
     764:      	ldur	x9, [x8, #0x26]
     768:      	stur	x9, [sp, #0x26]
     76c:      	ldp	x9, x8, [x8]
     770:      	stp	x9, x8, [sp]
     774:      	mov	w8, #0x2e               // =46
     778:      	mov	w9, #0x6                // =6
     77c:      	ldr	w2, [sp, #0x150]
     780:      	mov	x0, sp
     784:      	mov	w1, #0x2e               // =46
     788:      	blr	x9
     78c:      	mov	w0, wzr
     790:      	b	0x4ac <uprobe__generic+0x4ac>
     794:      	ldr	w8, [x25]
     798:      	cbz	w8, 0x820 <uprobe__generic+0x820>
     79c:      	adrp	x8, 0x0 <uprobe__generic>
     7a0:      	add	x8, x8, #0x0
     7a4:      	strb	wzr, [sp, #0x18]
     7a8:      	mov	x0, sp
     7ac:      	ldp	x9, x10, [x8]
     7b0:      	ldr	x8, [x8, #0x10]
     7b4:      	mov	w1, #0x19               // =25
     7b8:      	mov	w2, #0x1                // =1
     7bc:      	str	x8, [sp, #0x10]
     7c0:      	stp	x9, x10, [sp]
     7c4:      	mov	w8, #0x19               // =25
     7c8:      	mov	w9, #0x6                // =6
     7cc:      	mov	x10, sp
     7d0:      	blr	x9
     7d4:      	b	0x820 <uprobe__generic+0x820>
     7d8:      	ldr	w8, [x25]
     7dc:      	cbnz	w8, 0xe6c <uprobe__generic+0xe6c>
     7e0:      	mov	w8, #0x1                // =1
     7e4:      	adrp	x1, 0x0 <uprobe__generic>
     7e8:      	mov	w9, #0x4                // =4
     7ec:      	str	w8, [sp, #0x150]
     7f0:      	mov	w8, #-0x1               // =-1
     7f4:      	mov	w10, #0x19              // =25
     7f8:      	add	x11, sp, #0x150
     7fc:      	ldr	x1, [x1]
     800:      	add	x3, sp, #0x150
     804:      	mov	x0, x19
     808:      	mov	w2, #-0x1               // =-1
     80c:      	mov	w4, #0x4                // =4
     810:      	blr	x10
     814:      	tbz	w0, #0x1f, 0x820 <uprobe__generic+0x820>
     818:      	ldr	w8, [x25]
     81c:      	cbnz	w8, 0xe20 <uprobe__generic+0xe20>
     820:      	mov	w8, #0x3f               // =63
     824:      	adrp	x0, 0x0 <uprobe__generic>
     828:      	add	x9, sp, #0x150
     82c:      	str	w8, [sp, #0x150]
     830:      	mov	w8, #0x1                // =1
     834:      	add	x1, sp, #0x150
     838:      	ldr	x0, [x0]
     83c:      	blr	x8
     840:      	cbz	x0, 0x858 <uprobe__generic+0x858>
     844:      	ldr	x8, [x0]
     848:      	add	x8, x8, #0x1
     84c:      	str	x8, [x0]
     850:      	mov	w0, wzr
     854:      	b	0x4ac <uprobe__generic+0x4ac>
     858:      	ldr	w8, [x25]
     85c:      	cbz	w8, 0x38 <uprobe__generic+0x38>
     860:      	adrp	x8, 0x0 <uprobe__generic>
     864:      	add	x8, x8, #0x0
     868:      	mov	x0, sp
     86c:      	ldp	x9, x10, [x8, #0x10]
     870:      	mov	w1, #0x2e               // =46
     874:      	stp	x9, x10, [sp, #0x10]
     878:      	ldr	x9, [x8, #0x20]
     87c:      	mov	x10, sp
     880:      	str	x9, [sp, #0x20]
     884:      	ldur	x9, [x8, #0x26]
     888:      	stur	x9, [sp, #0x26]
     88c:      	ldp	x9, x8, [x8]
     890:      	stp	x9, x8, [sp]
     894:      	mov	w8, #0x2e               // =46
     898:      	mov	w9, #0x6                // =6
     89c:      	ldr	w2, [sp, #0x150]
     8a0:      	blr	x9
     8a4:      	b	0x38 <uprobe__generic+0x38>
     8a8:      	mov	w8, #0x7972             // =31090
     8ac:      	mov	x0, sp
     8b0:      	mov	w1, #0x34               // =52
     8b4:      	mov	w2, w22
     8b8:      	movk	w8, #0xa, lsl #16
     8bc:      	str	w8, [sp, #0x30]
     8c0:      	adrp	x8, 0x0 <uprobe__generic>
     8c4:      	add	x8, x8, #0x0
     8c8:      	ldp	x9, x10, [x8, #0x10]
     8cc:      	stp	x9, x10, [sp, #0x10]
     8d0:      	ldp	x9, x10, [x8, #0x20]
     8d4:      	stp	x9, x10, [sp, #0x20]
     8d8:      	ldp	x9, x8, [x8]
     8dc:      	mov	x10, sp
     8e0:      	stp	x9, x8, [sp]
     8e4:      	mov	w8, #0x34               // =52
     8e8:      	mov	w9, #0x6                // =6
     8ec:      	blr	x9
     8f0:      	b	0x4a8 <uprobe__generic+0x4a8>
     8f4:      	adrp	x8, 0x0 <uprobe__generic>
     8f8:      	add	x8, x8, #0x0
     8fc:      	mov	x0, sp
     900:      	ldp	x9, x10, [x8, #0x10]
     904:      	mov	w1, #0x27               // =39
     908:      	stp	x9, x10, [sp, #0x10]
     90c:      	ldur	x9, [x8, #0x1f]
     910:      	mov	x10, sp
     914:      	stur	x9, [sp, #0x1f]
     918:      	ldp	x8, x9, [x8]
     91c:      	stp	x8, x9, [sp]
     920:      	mov	w8, #0x27               // =39
     924:      	mov	w9, #0x6                // =6
     928:      	ldr	x2, [x21, #0xed0]
     92c:      	ldr	x3, [x21, #0xed8]
     930:      	ldr	x4, [x21, #0xee0]
     934:      	blr	x9
     938:      	b	0x368 <uprobe__generic+0x368>
     93c:      	adrp	x8, 0x0 <uprobe__generic>
     940:      	add	x8, x8, #0x0
     944:      	add	x0, sp, #0x150
     948:      	ldp	x9, x10, [x8, #0x10]
     94c:      	mov	w1, #0x2e               // =46
     950:      	stp	x9, x10, [sp, #0x160]
     954:      	ldr	x9, [x8, #0x20]
     958:      	add	x10, sp, #0x77
     95c:      	str	x9, [sp, #0x170]
     960:      	ldur	x9, [x8, #0x26]
     964:      	stur	x9, [x10, #0xff]
     968:      	ldp	x9, x8, [x8]
     96c:      	add	x10, sp, #0x150
     970:      	stp	x9, x8, [sp, #0x150]
     974:      	mov	w8, #0x2e               // =46
     978:      	mov	w9, #0x6                // =6
     97c:      	ldr	w2, [sp, #0x188]
     980:      	blr	x9
     984:      	b	0x224 <uprobe__generic+0x224>
     988:      	adrp	x8, 0x0 <uprobe__generic>
     98c:      	add	x8, x8, #0x0
     990:      	mov	x0, sp
     994:      	ldp	x9, x10, [x8, #0x10]
     998:      	mov	w1, #0x2e               // =46
     99c:      	stp	x9, x10, [sp, #0x10]
     9a0:      	ldr	x9, [x8, #0x20]
     9a4:      	mov	x10, sp
     9a8:      	str	x9, [sp, #0x20]
     9ac:      	ldur	x9, [x8, #0x26]
     9b0:      	stur	x9, [sp, #0x26]
     9b4:      	ldp	x9, x8, [x8]
     9b8:      	stp	x9, x8, [sp]
     9bc:      	mov	w8, #0x2e               // =46
     9c0:      	mov	w9, #0x6                // =6
     9c4:      	ldr	w2, [sp, #0x150]
     9c8:      	blr	x9
     9cc:      	b	0x14c <uprobe__generic+0x14c>
     9d0:      	adrp	x8, 0x0 <uprobe__generic>
     9d4:      	add	x8, x8, #0x0
     9d8:      	mov	x0, sp
     9dc:      	ldp	x9, x10, [x8, #0x10]
     9e0:      	mov	w1, #0x2e               // =46
     9e4:      	stp	x9, x10, [sp, #0x10]
     9e8:      	ldr	x9, [x8, #0x20]
     9ec:      	mov	x10, sp
     9f0:      	str	x9, [sp, #0x20]
     9f4:      	ldur	x9, [x8, #0x26]
     9f8:      	stur	x9, [sp, #0x26]
     9fc:      	ldp	x9, x8, [x8]
     a00:      	stp	x9, x8, [sp]
     a04:      	mov	w8, #0x2e               // =46
     a08:      	mov	w9, #0x6                // =6
     a0c:      	ldr	w2, [sp, #0x150]
     a10:      	blr	x9
     a14:      	b	0x46c <uprobe__generic+0x46c>
     a18:      	adrp	x8, 0x0 <uprobe__generic>
     a1c:      	add	x8, x8, #0x0
     a20:      	strb	wzr, [sp, #0x30]
     a24:      	mov	x0, sp
     a28:      	ldp	x9, x10, [x8, #0x10]
     a2c:      	mov	w1, #0x31               // =49
     a30:      	stp	x9, x10, [sp, #0x10]
     a34:      	ldp	x9, x10, [x8, #0x20]
     a38:      	stp	x9, x10, [sp, #0x20]
     a3c:      	ldp	x9, x8, [x8]
     a40:      	mov	x10, sp
     a44:      	stp	x9, x8, [sp]
     a48:      	mov	w8, #0x31               // =49
     a4c:      	mov	w9, #0x6                // =6
     a50:      	ldr	w2, [x21, #0x2c0]
     a54:      	blr	x9
     a58:      	ldr	x23, [x21, #0xed0]
     a5c:      	lsr	x8, x23, #56
     a60:      	cbnz	x8, 0x3b4 <uprobe__generic+0x3b4>
     a64:      	cmp	x23, #0xfff
     a68:      	b.hi	0xa88 <uprobe__generic+0xa88>
     a6c:      	ldr	w8, [x25]
     a70:      	cbnz	w8, 0xca4 <uprobe__generic+0xca4>
     a74:      	mov	w8, #0x31               // =49
     a78:      	mov	w22, wzr
     a7c:      	str	w8, [x21, #0xf18]
     a80:      	mov	w8, #0xfae              // =4014
     a84:      	b	0x3d8 <uprobe__generic+0x3d8>
     a88:      	ldr	w8, [x21]
     a8c:      	mov	w9, #0x60               // =96
     a90:      	add	x1, sp, #0x150
     a94:      	mov	x0, x24
     a98:      	str	w9, [sp, #0x150]
     a9c:      	add	x9, sp, #0x150
     aa0:      	rev	w8, w8
     aa4:      	str	w8, [sp, #0x154]
     aa8:      	rev	x8, x23
     aac:      	str	x8, [sp, #0x158]
     ab0:      	mov	w8, #0x1                // =1
     ab4:      	blr	x8
     ab8:      	cbz	x0, 0xb70 <uprobe__generic+0xb70>
     abc:      	ldr	x8, [x0, #0x8]
     ac0:      	and	x9, x8, #0xffffffffffffff
     ac4:      	lsr	x22, x8, #56
     ac8:      	str	x9, [x21, #0xf10]
     acc:      	ldr	x8, [x0]
     ad0:      	str	x8, [x21, #0xf00]
     ad4:      	sub	x8, x23, x9
     ad8:      	str	x8, [x21, #0xf08]
     adc:      	ldr	w8, [x25]
     ae0:      	cbnz	w8, 0xce4 <uprobe__generic+0xce4>
     ae4:      	cmp	w22, #0x1
     ae8:      	b.ne	0x240 <uprobe__generic+0x240>
     aec:      	ldr	x8, [x21, #0xf00]
     af0:      	adrp	x0, 0x0 <uprobe__generic>
     af4:      	ldr	x22, [x21, #0xf08]
     af8:      	mov	w9, #0x1                // =1
     afc:      	add	x1, sp, #0x150
     b00:      	mov	w23, #0x1               // =1
     b04:      	str	x8, [sp, #0x150]
     b08:      	add	x8, sp, #0x150
     b0c:      	ldr	x0, [x0]
     b10:      	blr	x9
     b14:      	cbz	x0, 0xb8c <uprobe__generic+0xb8c>
     b18:      	ldr	x8, [x0]
     b1c:      	cmp	x8, x22
     b20:      	b.hi	0xb30 <uprobe__generic+0xb30>
     b24:      	ldr	x8, [x0, #0x8]
     b28:      	cmp	x8, x22
     b2c:      	b.hs	0xb48 <uprobe__generic+0xb48>
     b30:      	ldr	x8, [x0, #0x10]
     b34:      	cmp	x8, x22
     b38:      	b.hi	0xb68 <uprobe__generic+0xb68>
     b3c:      	ldr	x8, [x0, #0x18]
     b40:      	cmp	x8, x22
     b44:      	b.lo	0xb68 <uprobe__generic+0xb68>
     b48:      	ldr	w8, [x25]
     b4c:      	cbnz	w8, 0xeb4 <uprobe__generic+0xeb4>
     b50:      	ldrh	w8, [x0, #0x20]
     b54:      	ldr	w9, [x21, #0x1370]
     b58:      	lsr	w8, w9, w8
     b5c:      	tbz	w8, #0x0, 0xf08 <uprobe__generic+0xf08>
     b60:      	ldr	w8, [x25]
     b64:      	cbnz	w8, 0xf54 <uprobe__generic+0xf54>
     b68:      	mov	w22, #0x1               // =1
     b6c:      	b	0x240 <uprobe__generic+0x240>
     b70:      	ldr	w8, [x25]
     b74:      	cbnz	w8, 0xdd4 <uprobe__generic+0xdd4>
     b78:      	mov	w8, #0xc                // =12
     b7c:      	mov	w22, wzr
     b80:      	str	w8, [x21, #0xf18]
     b84:      	mov	w8, #0xfac              // =4012
     b88:      	b	0x3d8 <uprobe__generic+0x3d8>
     b8c:      	mov	w22, w23
     b90:      	b	0x240 <uprobe__generic+0x240>
     b94:      	adrp	x8, 0x0 <uprobe__generic>
     b98:      	add	x8, x8, #0x0
     b9c:      	mov	x24, x0
     ba0:      	ldp	x9, x10, [x8]
     ba4:      	mov	x0, sp
     ba8:      	and	w3, w23, #0xff
     bac:      	mov	w1, #0x1f               // =31
     bb0:      	stp	x9, x10, [sp]
     bb4:      	ldr	x9, [x8, #0x10]
     bb8:      	ldur	x8, [x8, #0x17]
     bbc:      	mov	x10, sp
     bc0:      	str	x9, [sp, #0x10]
     bc4:      	stur	x8, [sp, #0x17]
     bc8:      	mov	w8, #0x1f               // =31
     bcc:      	mov	w9, #0x6                // =6
     bd0:      	ldr	w2, [sp, #0x198]
     bd4:      	blr	x9
     bd8:      	mov	x0, x24
     bdc:      	b	0x5c4 <uprobe__generic+0x5c4>
     be0:      	adrp	x8, 0x0 <uprobe__generic>
     be4:      	add	x8, x8, #0x0
     be8:      	strb	wzr, [sp, #0x30]
     bec:      	mov	x0, sp
     bf0:      	ldp	x9, x10, [x8, #0x10]
     bf4:      	mov	w1, #0x31               // =49
     bf8:      	stp	x9, x10, [sp, #0x10]
     bfc:      	ldp	x9, x10, [x8, #0x20]
     c00:      	stp	x9, x10, [sp, #0x20]
     c04:      	ldp	x9, x8, [x8]
     c08:      	mov	x10, sp
     c0c:      	stp	x9, x8, [sp]
     c10:      	mov	w8, #0x31               // =49
     c14:      	mov	w9, #0x6                // =6
     c18:      	blr	x9
     c1c:      	b	0x568 <uprobe__generic+0x568>
     c20:      	mov	w8, #0xa                // =10
     c24:      	mov	x0, sp
     c28:      	mov	w1, #0x22               // =34
     c2c:      	strh	w8, [sp, #0x20]
     c30:      	adrp	x8, 0x0 <uprobe__generic>
     c34:      	add	x8, x8, #0x0
     c38:      	mov	x2, x23
     c3c:      	ldp	x9, x10, [x8]
     c40:      	stp	x9, x10, [sp]
     c44:      	ldp	x9, x8, [x8, #0x10]
     c48:      	mov	x10, sp
     c4c:      	stp	x9, x8, [sp, #0x10]
     c50:      	mov	w8, #0x22               // =34
     c54:      	mov	w9, #0x6                // =6
     c58:      	blr	x9
     c5c:      	b	0x3bc <uprobe__generic+0x3bc>
     c60:      	adrp	x8, 0x0 <uprobe__generic>
     c64:      	add	x8, x8, #0x0
     c68:      	mov	w3, w0
     c6c:      	ldp	x9, x10, [x8]
     c70:      	mov	x0, sp
     c74:      	mov	w1, #0x1d               // =29
     c78:      	stp	x9, x10, [sp]
     c7c:      	ldr	x9, [x8, #0x10]
     c80:      	ldur	x8, [x8, #0x15]
     c84:      	mov	x10, sp
     c88:      	str	x9, [sp, #0x10]
     c8c:      	stur	x8, [sp, #0x15]
     c90:      	mov	w8, #0x1d               // =29
     c94:      	mov	w9, #0x6                // =6
     c98:      	ldr	w2, [sp, #0x198]
     c9c:      	blr	x9
     ca0:      	b	0x608 <uprobe__generic+0x608>
     ca4:      	adrp	x8, 0x0 <uprobe__generic>
     ca8:      	add	x8, x8, #0x0
     cac:      	mov	x0, sp
     cb0:      	ldp	x9, x10, [x8]
     cb4:      	mov	w1, #0x1e               // =30
     cb8:      	mov	x2, x23
     cbc:      	stp	x9, x10, [sp]
     cc0:      	ldr	x9, [x8, #0x10]
     cc4:      	ldur	x8, [x8, #0x16]
     cc8:      	mov	x10, sp
     ccc:      	str	x9, [sp, #0x10]
     cd0:      	stur	x8, [sp, #0x16]
     cd4:      	mov	w8, #0x1e               // =30
     cd8:      	mov	w9, #0x6                // =6
     cdc:      	blr	x9
     ce0:      	b	0xa74 <uprobe__generic+0xa74>
     ce4:      	mov	w8, #0xa                // =10
     ce8:      	mov	x0, sp
     cec:      	mov	w1, #0x32               // =50
     cf0:      	strh	w8, [sp, #0x30]
     cf4:      	adrp	x8, 0x0 <uprobe__generic>
     cf8:      	add	x8, x8, #0x0
     cfc:      	mov	x2, x23
     d00:      	ldp	x9, x10, [x8, #0x10]
     d04:      	mov	w4, w22
     d08:      	stp	x9, x10, [sp, #0x10]
     d0c:      	ldp	x9, x10, [x8, #0x20]
     d10:      	stp	x9, x10, [sp, #0x20]
     d14:      	ldp	x9, x8, [x8]
     d18:      	mov	x10, sp
     d1c:      	stp	x9, x8, [sp]
     d20:      	mov	w8, #0x32               // =50
     d24:      	mov	w9, #0x6                // =6
     d28:      	ldr	x3, [x21, #0xf00]
     d2c:      	blr	x9
     d30:      	ldr	w8, [x25]
     d34:      	cbz	w8, 0xae4 <uprobe__generic+0xae4>
     d38:      	adrp	x8, 0x0 <uprobe__generic>
     d3c:      	add	x8, x8, #0x0
     d40:      	mov	x0, sp
     d44:      	ldp	x9, x10, [x8, #0x10]
     d48:      	mov	w1, #0x2f               // =47
     d4c:      	stp	x9, x10, [sp, #0x10]
     d50:      	ldr	x9, [x8, #0x20]
     d54:      	mov	x10, sp
     d58:      	str	x9, [sp, #0x20]
     d5c:      	ldur	x9, [x8, #0x27]
     d60:      	stur	x9, [sp, #0x27]
     d64:      	ldp	x9, x8, [x8]
     d68:      	stp	x9, x8, [sp]
     d6c:      	mov	w8, #0x2f               // =47
     d70:      	mov	w9, #0x6                // =6
     d74:      	ldr	x2, [x21, #0xf10]
     d78:      	ldr	x3, [x21, #0xf08]
     d7c:      	blr	x9
     d80:      	b	0xae4 <uprobe__generic+0xae4>
     d84:      	adrp	x8, 0x0 <uprobe__generic>
     d88:      	add	x8, x8, #0x0
     d8c:      	ldr	w3, [sp, #0x188]
     d90:      	mov	w4, w0
     d94:      	ldp	x9, x10, [x8, #0x20]
     d98:      	mov	x0, sp
     d9c:      	mov	w1, #0x35               // =53
     da0:      	mov	w2, w22
     da4:      	stp	x9, x10, [sp, #0x20]
     da8:      	ldur	x9, [x8, #0x2d]
     dac:      	stur	x9, [sp, #0x2d]
     db0:      	ldp	x9, x10, [x8]
     db4:      	stp	x9, x10, [sp]
     db8:      	ldp	x8, x9, [x8, #0x10]
     dbc:      	mov	x10, sp
     dc0:      	stp	x8, x9, [sp, #0x10]
     dc4:      	mov	w8, #0x35               // =53
     dc8:      	mov	w9, #0x6                // =6
     dcc:      	blr	x9
     dd0:      	b	0x6a8 <uprobe__generic+0x6a8>
     dd4:      	adrp	x8, 0x0 <uprobe__generic>
     dd8:      	add	x8, x8, #0x0
     ddc:      	strb	wzr, [sp, #0x38]
     de0:      	mov	x0, sp
     de4:      	ldp	x9, x10, [x8, #0x20]
     de8:      	mov	w1, #0x39               // =57
     dec:      	mov	x2, x23
     df0:      	stp	x9, x10, [sp, #0x20]
     df4:      	ldr	x9, [x8, #0x30]
     df8:      	str	x9, [sp, #0x30]
     dfc:      	ldp	x9, x10, [x8]
     e00:      	stp	x9, x10, [sp]
     e04:      	ldp	x8, x9, [x8, #0x10]
     e08:      	mov	x10, sp
     e0c:      	stp	x8, x9, [sp, #0x10]
     e10:      	mov	w8, #0x39               // =57
     e14:      	mov	w9, #0x6                // =6
     e18:      	blr	x9
     e1c:      	b	0xb78 <uprobe__generic+0xb78>
     e20:      	adrp	x8, 0x0 <uprobe__generic>
     e24:      	add	x8, x8, #0x0
     e28:      	mov	w3, w0
     e2c:      	ldp	x9, x10, [x8, #0x20]
     e30:      	mov	x0, sp
     e34:      	mov	w1, #0x36               // =54
     e38:      	mov	w2, #0x1                // =1
     e3c:      	stp	x9, x10, [sp, #0x20]
     e40:      	ldur	x9, [x8, #0x2e]
     e44:      	stur	x9, [sp, #0x2e]
     e48:      	ldp	x9, x10, [x8]
     e4c:      	stp	x9, x10, [sp]
     e50:      	ldp	x8, x9, [x8, #0x10]
     e54:      	mov	x10, sp
     e58:      	stp	x8, x9, [sp, #0x10]
     e5c:      	mov	w8, #0x36               // =54
     e60:      	mov	w9, #0x6                // =6
     e64:      	blr	x9
     e68:      	b	0x820 <uprobe__generic+0x820>
     e6c:      	adrp	x8, 0x0 <uprobe__generic>
     e70:      	add	x8, x8, #0x0
     e74:      	mov	x0, sp
     e78:      	ldp	x9, x10, [x8, #0x10]
     e7c:      	mov	w1, #0x2e               // =46
     e80:      	stp	x9, x10, [sp, #0x10]
     e84:      	ldr	x9, [x8, #0x20]
     e88:      	mov	x10, sp
     e8c:      	str	x9, [sp, #0x20]
     e90:      	ldur	x9, [x8, #0x26]
     e94:      	stur	x9, [sp, #0x26]
     e98:      	ldp	x9, x8, [x8]
     e9c:      	stp	x9, x8, [sp]
     ea0:      	mov	w8, #0x2e               // =46
     ea4:      	mov	w9, #0x6                // =6
     ea8:      	ldr	w2, [sp, #0x150]
     eac:      	blr	x9
     eb0:      	b	0x7e0 <uprobe__generic+0x7e0>
     eb4:      	adrp	x8, 0x0 <uprobe__generic>
     eb8:      	add	x8, x8, #0x0
     ebc:      	mov	x22, x0
     ec0:      	ldp	x9, x10, [x8]
     ec4:      	mov	w1, #0x1e               // =30
     ec8:      	stp	x9, x10, [sp]
     ecc:      	ldr	x9, [x8, #0x10]
     ed0:      	ldur	x8, [x8, #0x16]
     ed4:      	mov	x10, sp
     ed8:      	str	x9, [sp, #0x10]
     edc:      	stur	x8, [sp, #0x16]
     ee0:      	mov	w8, #0x1e               // =30
     ee4:      	mov	w9, #0x6                // =6
     ee8:      	ldrh	w2, [x0, #0x20]
     eec:      	mov	x0, sp
     ef0:      	blr	x9
     ef4:      	mov	x0, x22
     ef8:      	ldrh	w8, [x22, #0x20]
     efc:      	ldr	w9, [x21, #0x1370]
     f00:      	lsr	w8, w9, w8
     f04:      	tbnz	w8, #0x0, 0xb60 <uprobe__generic+0xb60>
     f08:      	mov	x22, x0
     f0c:      	str	wzr, [sp, #0x188]
     f10:      	adrp	x0, 0x0 <uprobe__generic>
     f14:      	mov	w8, #0x1                // =1
     f18:      	ldr	x0, [x0]
     f1c:      	add	x9, sp, #0x188
     f20:      	add	x1, sp, #0x188
     f24:      	blr	x8
     f28:      	cbz	x0, 0xf40 <uprobe__generic+0xf40>
     f2c:      	ldr	x8, [x0]
     f30:      	add	x8, x8, #0x1
     f34:      	str	x8, [x0]
     f38:      	mov	x8, x22
     f3c:      	b	0xf4c <uprobe__generic+0xf4c>
     f40:      	ldr	w9, [x25]
     f44:      	mov	x8, x22
     f48:      	cbnz	w9, 0xf94 <uprobe__generic+0xf94>
     f4c:      	ldrh	w22, [x8, #0x20]
     f50:      	b	0x240 <uprobe__generic+0x240>
     f54:      	mov	w8, #0x656e             // =25966
     f58:      	mov	x0, sp
     f5c:      	mov	w1, #0x1b               // =27
     f60:      	movk	w8, #0xa, lsl #16
     f64:      	stur	w8, [sp, #0x17]
     f68:      	adrp	x8, 0x0 <uprobe__generic>
     f6c:      	add	x8, x8, #0x0
     f70:      	ldp	x9, x10, [x8]
     f74:      	ldr	x8, [x8, #0x10]
     f78:      	stp	x9, x10, [sp]
     f7c:      	str	x8, [sp, #0x10]
     f80:      	mov	w8, #0x1b               // =27
     f84:      	mov	w9, #0x6                // =6
     f88:      	mov	x10, sp
     f8c:      	blr	x9
     f90:      	b	0xb68 <uprobe__generic+0xb68>
     f94:      	adrp	x8, 0x0 <uprobe__generic>
     f98:      	add	x8, x8, #0x0
     f9c:      	mov	x0, sp
     fa0:      	ldp	x9, x10, [x8, #0x10]
     fa4:      	mov	w1, #0x2e               // =46
     fa8:      	stp	x9, x10, [sp, #0x10]
     fac:      	ldr	x9, [x8, #0x20]
     fb0:      	mov	x10, sp
     fb4:      	str	x9, [sp, #0x20]
     fb8:      	ldur	x9, [x8, #0x26]
     fbc:      	stur	x9, [sp, #0x26]
     fc0:      	ldp	x9, x8, [x8]
     fc4:      	stp	x9, x8, [sp]
     fc8:      	mov	w8, #0x2e               // =46
     fcc:      	mov	w9, #0x6                // =6
     fd0:      	ldr	w2, [sp, #0x188]
     fd4:      	blr	x9
     fd8:      	b	0xf38 <uprobe__generic+0xf38>
