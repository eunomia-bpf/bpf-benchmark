
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/native_stack_trace.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/native_tracer_entry:

0000000000000000 <native_tracer_entry>:
       0:      	sub	sp, sp, #0x1f0
       4:      	str	x29, [sp, #0x1a0]
       8:      	stp	x30, x25, [sp, #0x1b0]
       c:      	stp	x24, x23, [sp, #0x1c0]
      10:      	stp	x22, x21, [sp, #0x1d0]
      14:      	stp	x20, x19, [sp, #0x1e0]
      18:      	mov	w8, #0xe                // =14
      1c:      	mov	x19, x0
      20:      	blr	x8
      24:      	mov	x23, x0
      28:      	lsr	x22, x0, #32
      2c:      	cbz	w22, 0x134 <native_tracer_entry+0x134>
      30:      	mov	w8, #0x5                // =5
      34:      	blr	x8
      38:      	adrp	x25, 0x0 <native_tracer_entry>
      3c:      	mov	x24, x0
      40:      	ldr	x25, [x25]
      44:      	ldr	w8, [x25]
      48:      	cbnz	w8, 0x4a0 <native_tracer_entry+0x4a0>
      4c:      	str	wzr, [sp, #0x10]
      50:      	adrp	x20, 0x0 <native_tracer_entry>
      54:      	add	x8, sp, #0x10
      58:      	mov	w9, #0x1                // =1
      5c:      	ldr	x20, [x20]
      60:      	add	x1, sp, #0x10
      64:      	mov	w29, #0x1               // =1
      68:      	mov	x0, x20
      6c:      	blr	x9
      70:      	cbz	x0, 0x6a8 <native_tracer_entry+0x6a8>
      74:      	mov	w8, #-0x1               // =-1
      78:      	mov	w9, #0x100              // =256
      7c:      	mov	x21, x0
      80:      	strh	wzr, [x0, #0xf20]
      84:      	str	xzr, [x0, #0xed0]
      88:      	mov	w1, wzr
      8c:      	str	xzr, [x0, #0xed8]
      90:      	str	xzr, [x0, #0xee0]
      94:      	mov	w2, #0x29c              // =668
      98:      	str	xzr, [x0, #0xee8]
      9c:      	str	xzr, [x0, #0xef0]
      a0:      	str	xzr, [x0, #0xef8]
      a4:      	str	x8, [x0, #0xf18]
      a8:      	str	wzr, [x0, #0x1370]
      ac:      	strh	w9, [x0, #0x1374]
      b0:      	add	x9, x0, #0x2bc
      b4:      	str	xzr, [x0, #0xf28]
      b8:      	str	xzr, [x0, #0xf30]
      bc:      	str	xzr, [x0, #0xf48]
      c0:      	str	xzr, [x0, #0xf50]
      c4:      	str	xzr, [x0, #0xf58]
      c8:      	str	xzr, [x0, #0xf60]
      cc:      	str	xzr, [x0, #0xf68]
      d0:      	add	x0, x0, #0x20
      d4:      	str	x8, [x9]
      d8:      	bl	0xd8 <native_tracer_entry+0xd8>
      dc:      	str	w29, [x21, #0x2c4]
      e0:      	stp	w22, w23, [x21]
      e4:      	add	x0, x21, #0x10
      e8:      	mov	w8, #0x10               // =16
      ec:      	mov	w1, #0x10               // =16
      f0:      	str	x24, [x21, #0x8]
      f4:      	str	xzr, [x21, #0x2c8]
      f8:      	blr	x8
      fc:      	tbz	w0, #0x1f, 0x258 <native_tracer_entry+0x258>
     100:      	mov	w8, #0x34               // =52
     104:      	adrp	x0, 0x0 <native_tracer_entry>
     108:      	add	x9, sp, #0x160
     10c:      	str	w8, [sp, #0x160]
     110:      	mov	w8, #0x1                // =1
     114:      	add	x1, sp, #0x160
     118:      	ldr	x0, [x0]
     11c:      	blr	x8
     120:      	cbz	x0, 0x250 <native_tracer_entry+0x250>
     124:      	ldr	x8, [x0]
     128:      	add	x8, x8, #0x1
     12c:      	str	x8, [x0]
     130:      	b	0x258 <native_tracer_entry+0x258>
     134:      	adrp	x8, 0x0 <native_tracer_entry>
     138:      	ldr	x8, [x8]
     13c:      	ldrb	w8, [x8]
     140:      	cbz	w8, 0x14c <native_tracer_entry+0x14c>
     144:      	mov	w0, wzr
     148:      	b	0x6ac <native_tracer_entry+0x6ac>
     14c:      	mov	w8, #0x5                // =5
     150:      	blr	x8
     154:      	adrp	x24, 0x0 <native_tracer_entry>
     158:      	mov	x22, x0
     15c:      	ldr	x24, [x24]
     160:      	ldr	w8, [x24]
     164:      	cbnz	w8, 0xac8 <native_tracer_entry+0xac8>
     168:      	str	wzr, [sp, #0x10]
     16c:      	adrp	x20, 0x0 <native_tracer_entry>
     170:      	add	x8, sp, #0x10
     174:      	mov	w9, #0x1                // =1
     178:      	ldr	x20, [x20]
     17c:      	add	x1, sp, #0x10
     180:      	mov	w25, #0x1               // =1
     184:      	mov	x0, x20
     188:      	blr	x9
     18c:      	cbz	x0, 0x6a8 <native_tracer_entry+0x6a8>
     190:      	mov	w8, #-0x1               // =-1
     194:      	mov	w9, #0x100              // =256
     198:      	mov	x21, x0
     19c:      	strh	wzr, [x0, #0xf20]
     1a0:      	str	xzr, [x0, #0xed0]
     1a4:      	mov	w1, wzr
     1a8:      	str	xzr, [x0, #0xed8]
     1ac:      	str	xzr, [x0, #0xee0]
     1b0:      	mov	w2, #0x29c              // =668
     1b4:      	str	xzr, [x0, #0xee8]
     1b8:      	str	xzr, [x0, #0xef0]
     1bc:      	str	xzr, [x0, #0xef8]
     1c0:      	str	x8, [x0, #0xf18]
     1c4:      	str	wzr, [x0, #0x1370]
     1c8:      	strh	w9, [x0, #0x1374]
     1cc:      	add	x9, x0, #0x2bc
     1d0:      	str	xzr, [x0, #0xf28]
     1d4:      	str	xzr, [x0, #0xf30]
     1d8:      	str	xzr, [x0, #0xf48]
     1dc:      	str	xzr, [x0, #0xf50]
     1e0:      	str	xzr, [x0, #0xf58]
     1e4:      	str	xzr, [x0, #0xf60]
     1e8:      	str	xzr, [x0, #0xf68]
     1ec:      	add	x0, x0, #0x20
     1f0:      	str	x8, [x9]
     1f4:      	bl	0x1f4 <native_tracer_entry+0x1f4>
     1f8:      	str	w25, [x21, #0x2c4]
     1fc:      	stp	wzr, w23, [x21]
     200:      	add	x0, x21, #0x10
     204:      	mov	w8, #0x10               // =16
     208:      	mov	w1, #0x10               // =16
     20c:      	str	x22, [x21, #0x8]
     210:      	str	xzr, [x21, #0x2c8]
     214:      	blr	x8
     218:      	tbz	w0, #0x1f, 0x3b4 <native_tracer_entry+0x3b4>
     21c:      	mov	w8, #0x34               // =52
     220:      	adrp	x0, 0x0 <native_tracer_entry>
     224:      	add	x9, sp, #0x160
     228:      	str	w8, [sp, #0x160]
     22c:      	mov	w8, #0x1                // =1
     230:      	add	x1, sp, #0x160
     234:      	ldr	x0, [x0]
     238:      	blr	x8
     23c:      	cbz	x0, 0x3ac <native_tracer_entry+0x3ac>
     240:      	ldr	x8, [x0]
     244:      	add	x8, x8, #0x1
     248:      	str	x8, [x0]
     24c:      	b	0x3b4 <native_tracer_entry+0x3b4>
     250:      	ldr	w8, [x25]
     254:      	cbnz	w8, 0xbc8 <native_tracer_entry+0xbc8>
     258:      	adrp	x1, 0x0 <native_tracer_entry>
     25c:      	mov	w8, #0x400              // =1024
     260:      	mov	w9, #0x1b               // =27
     264:      	ldr	x1, [x1]
     268:      	mov	x0, x19
     26c:      	mov	w2, #0x400              // =1024
     270:      	blr	x9
     274:      	ldr	w8, [x25]
     278:      	str	w0, [x21, #0x2bc]
     27c:      	cbnz	w8, 0x4d4 <native_tracer_entry+0x4d4>
     280:      	ldr	x8, [x19, #0x108]
     284:      	tst	x8, #0xf
     288:      	b.eq	0x514 <native_tracer_entry+0x514>
     28c:      	mov	w8, #0x23               // =35
     290:      	blr	x8
     294:      	adrp	x8, 0x0 <native_tracer_entry>
     298:      	mov	w9, #0x71               // =113
     29c:      	add	x10, sp, #0x10
     2a0:      	ldr	x8, [x8]
     2a4:      	mov	w1, #0x8                // =8
     2a8:      	ldr	w8, [x8]
     2ac:      	add	x2, x0, x8
     2b0:      	mov	w8, #0x8                // =8
     2b4:      	add	x0, sp, #0x10
     2b8:      	blr	x9
     2bc:      	cbnz	x0, 0x2f4 <native_tracer_entry+0x2f4>
     2c0:      	adrp	x9, 0x0 <native_tracer_entry>
     2c4:      	ldr	x8, [sp, #0x10]
     2c8:      	ldr	x9, [x9]
     2cc:      	ldr	w9, [x9]
     2d0:      	add	x2, x8, x9
     2d4:      	cbz	x2, 0x2f4 <native_tracer_entry+0x2f4>
     2d8:      	mov	w8, #0x150              // =336
     2dc:      	mov	w9, #0x71               // =113
     2e0:      	add	x10, sp, #0x10
     2e4:      	add	x0, sp, #0x10
     2e8:      	mov	w1, #0x150              // =336
     2ec:      	blr	x9
     2f0:      	cbz	x0, 0x33c <native_tracer_entry+0x33c>
     2f4:      	mov	w8, #0x52               // =82
     2f8:      	adrp	x0, 0x0 <native_tracer_entry>
     2fc:      	add	x9, sp, #0x198
     300:      	str	w8, [sp, #0x198]
     304:      	mov	w8, #0x1                // =1
     308:      	add	x1, sp, #0x198
     30c:      	ldr	x0, [x0]
     310:      	blr	x8
     314:      	cbz	x0, 0x328 <native_tracer_entry+0x328>
     318:      	ldr	x8, [x0]
     31c:      	add	x8, x8, #0x1
     320:      	str	x8, [x0]
     324:      	b	0x330 <native_tracer_entry+0x330>
     328:      	ldr	w8, [x25]
     32c:      	cbnz	w8, 0xb7c <native_tracer_entry+0xb7c>
     330:      	mov	w22, wzr
     334:      	mov	w8, #0xfa9              // =4009
     338:      	b	0x5d8 <native_tracer_entry+0x5d8>
     33c:      	ldr	x8, [sp, #0x118]
     340:      	tst	x8, #0xf
     344:      	b.eq	0x354 <native_tracer_entry+0x354>
     348:      	mov	w22, wzr
     34c:      	mov	w8, wzr
     350:      	b	0x5d8 <native_tracer_entry+0x5d8>
     354:      	tbnz	w8, #0x4, 0x5d0 <native_tracer_entry+0x5d0>
     358:      	ldp	x10, x8, [sp, #0x100]
     35c:      	str	x8, [x21, #0xed8]
     360:      	ldp	x9, x11, [sp, #0xf0]
     364:      	ldr	x8, [sp, #0xc0]
     368:      	str	x11, [x21, #0xee0]
     36c:      	str	x8, [x21, #0xef0]
     370:      	adrp	x8, 0x0 <native_tracer_entry>
     374:      	ldr	x8, [x8]
     378:      	str	x9, [x21, #0xef8]
     37c:      	ldr	x9, [sp, #0x110]
     380:      	strb	wzr, [x21, #0xf21]
     384:      	ldr	x8, [x8]
     388:      	and	x9, x8, x9
     38c:      	and	x8, x10, x8
     390:      	str	x8, [x21, #0xee8]
     394:      	ldr	w8, [sp, #0x128]
     398:      	str	x9, [x21, #0xed0]
     39c:      	cmn	w8, #0x1
     3a0:      	cset	w8, ne
     3a4:      	strb	w8, [x21, #0xf20]
     3a8:      	b	0x560 <native_tracer_entry+0x560>
     3ac:      	ldr	w8, [x24]
     3b0:      	cbnz	w8, 0xee4 <native_tracer_entry+0xee4>
     3b4:      	adrp	x1, 0x0 <native_tracer_entry>
     3b8:      	mov	w8, #0x400              // =1024
     3bc:      	mov	w9, #0x1b               // =27
     3c0:      	ldr	x1, [x1]
     3c4:      	mov	x0, x19
     3c8:      	mov	w2, #0x400              // =1024
     3cc:      	blr	x9
     3d0:      	ldr	w8, [x24]
     3d4:      	str	w0, [x21, #0x2bc]
     3d8:      	cbnz	w8, 0xafc <native_tracer_entry+0xafc>
     3dc:      	str	wzr, [sp, #0x10]
     3e0:      	mov	w8, #0x1                // =1
     3e4:      	add	x9, sp, #0x10
     3e8:      	add	x1, sp, #0x10
     3ec:      	mov	x0, x20
     3f0:      	blr	x8
     3f4:      	cbz	x0, 0x448 <native_tracer_entry+0x448>
     3f8:      	mov	w20, #0x1374            // =4980
     3fc:      	ldrb	w8, [x0, x20]
     400:      	cmp	w8, #0x1d
     404:      	b.lo	0x478 <native_tracer_entry+0x478>
     408:      	mov	w8, #0x5                // =5
     40c:      	mov	x21, x0
     410:      	add	x9, sp, #0x160
     414:      	str	w8, [x0, #0xf1c]
     418:      	mov	w8, #0x44               // =68
     41c:      	adrp	x0, 0x0 <native_tracer_entry>
     420:      	add	x1, sp, #0x160
     424:      	str	w8, [sp, #0x160]
     428:      	mov	w8, #0x1                // =1
     42c:      	ldr	x0, [x0]
     430:      	blr	x8
     434:      	cbz	x0, 0x468 <native_tracer_entry+0x468>
     438:      	ldr	x8, [x0]
     43c:      	add	x8, x8, #0x1
     440:      	str	x8, [x0]
     444:      	b	0x470 <native_tracer_entry+0x470>
     448:      	adrp	x1, 0x0 <native_tracer_entry>
     44c:      	mov	x8, xzr
     450:      	mov	w9, #0xc                // =12
     454:      	ldr	x1, [x1]
     458:      	mov	x0, x19
     45c:      	mov	w2, wzr
     460:      	blr	x9
     464:      	b	0x144 <native_tracer_entry+0x144>
     468:      	ldr	w8, [x24]
     46c:      	cbnz	w8, 0xf2c <native_tracer_entry+0xf2c>
     470:      	ldrb	w8, [x21, x20]
     474:      	mov	x0, x21
     478:      	add	w8, w8, #0x1
     47c:      	adrp	x1, 0x0 <native_tracer_entry>
     480:      	mov	x9, xzr
     484:      	strb	w8, [x0, x20]
     488:      	mov	w8, #0xc                // =12
     48c:      	mov	x0, x19
     490:      	mov	w2, wzr
     494:      	ldr	x1, [x1]
     498:      	blr	x8
     49c:      	b	0x144 <native_tracer_entry+0x144>
     4a0:      	adrp	x8, 0x0 <native_tracer_entry>
     4a4:      	add	x8, x8, #0x0
     4a8:      	add	x0, sp, #0x10
     4ac:      	ldp	x9, x10, [x8]
     4b0:      	ldur	x8, [x8, #0xe]
     4b4:      	mov	w1, #0x16               // =22
     4b8:      	stp	x9, x10, [sp, #0x10]
     4bc:      	stur	x8, [sp, #0x1e]
     4c0:      	mov	w8, #0x16               // =22
     4c4:      	mov	w9, #0x6                // =6
     4c8:      	add	x10, sp, #0x10
     4cc:      	blr	x9
     4d0:      	b	0x4c <native_tracer_entry+0x4c>
     4d4:      	adrp	x8, 0x0 <native_tracer_entry>
     4d8:      	add	x8, x8, #0x0
     4dc:      	add	x0, sp, #0x10
     4e0:      	ldp	x9, x10, [x8]
     4e4:      	ldur	x8, [x8, #0xe]
     4e8:      	mov	w1, #0x16               // =22
     4ec:      	stp	x9, x10, [sp, #0x10]
     4f0:      	stur	x8, [sp, #0x1e]
     4f4:      	mov	w8, #0x16               // =22
     4f8:      	mov	w9, #0x6                // =6
     4fc:      	add	x10, sp, #0x10
     500:      	ldr	w2, [x21, #0x2bc]
     504:      	blr	x9
     508:      	ldr	x8, [x19, #0x108]
     50c:      	tst	x8, #0xf
     510:      	b.ne	0x28c <native_tracer_entry+0x28c>
     514:      	tbnz	w8, #0x4, 0x5d0 <native_tracer_entry+0x5d0>
     518:      	adrp	x8, 0x0 <native_tracer_entry>
     51c:      	ldr	x8, [x8]
     520:      	ldr	x9, [x19, #0x100]
     524:      	ldr	x8, [x8]
     528:      	and	x9, x8, x9
     52c:      	str	x9, [x21, #0xed0]
     530:      	ldr	x9, [x19, #0xf8]
     534:      	str	x9, [x21, #0xed8]
     538:      	ldr	x9, [x19, #0xe8]
     53c:      	str	x9, [x21, #0xee0]
     540:      	ldr	x9, [x19, #0xf0]
     544:      	and	x8, x9, x8
     548:      	str	x8, [x21, #0xee8]
     54c:      	ldr	x8, [x19, #0xb0]
     550:      	str	x8, [x21, #0xef0]
     554:      	ldr	x8, [x19, #0xe0]
     558:      	strh	wzr, [x21, #0xf20]
     55c:      	str	x8, [x21, #0xef8]
     560:      	ldr	w8, [x25]
     564:      	cbnz	w8, 0xb34 <native_tracer_entry+0xb34>
     568:      	mov	w8, #0x60               // =96
     56c:      	rev	w9, w22
     570:      	str	xzr, [sp, #0x18]
     574:      	adrp	x24, 0x0 <native_tracer_entry>
     578:      	stp	w8, w9, [sp, #0x10]
     57c:      	mov	w8, #0x1                // =1
     580:      	add	x9, sp, #0x10
     584:      	add	x1, sp, #0x10
     588:      	ldr	x24, [x24]
     58c:      	mov	x0, x24
     590:      	blr	x8
     594:      	cbz	x0, 0x6c8 <native_tracer_entry+0x6c8>
     598:      	add	x8, x21, #0xed0
     59c:      	ldr	x23, [x8]
     5a0:      	ldr	w8, [x25]
     5a4:      	cbz	x23, 0x760 <native_tracer_entry+0x760>
     5a8:      	cbnz	w8, 0xc58 <native_tracer_entry+0xc58>
     5ac:      	lsr	x8, x23, #56
     5b0:      	cbz	x8, 0xca4 <native_tracer_entry+0xca4>
     5b4:      	ldr	w8, [x25]
     5b8:      	cbnz	w8, 0xe60 <native_tracer_entry+0xe60>
     5bc:      	mov	w8, #0xb                // =11
     5c0:      	mov	w22, wzr
     5c4:      	str	w8, [x21, #0xf18]
     5c8:      	mov	w8, #0xfab              // =4011
     5cc:      	b	0x5d8 <native_tracer_entry+0x5d8>
     5d0:      	mov	w22, wzr
     5d4:      	mov	w8, #0xfb0              // =4016
     5d8:      	str	w8, [x21, #0xf1c]
     5dc:      	str	wzr, [sp, #0x10]
     5e0:      	mov	w8, #0x1                // =1
     5e4:      	add	x9, sp, #0x10
     5e8:      	add	x1, sp, #0x10
     5ec:      	mov	x0, x20
     5f0:      	blr	x8
     5f4:      	cbz	x0, 0x64c <native_tracer_entry+0x64c>
     5f8:      	mov	w20, #0x1374            // =4980
     5fc:      	mov	w2, w22
     600:      	ldrb	w8, [x0, x20]
     604:      	cmp	w8, #0x1d
     608:      	b.lo	0x678 <native_tracer_entry+0x678>
     60c:      	mov	w8, #0x5                // =5
     610:      	mov	x21, x0
     614:      	add	x9, sp, #0x160
     618:      	str	w8, [x0, #0xf1c]
     61c:      	mov	w8, #0x44               // =68
     620:      	adrp	x0, 0x0 <native_tracer_entry>
     624:      	add	x1, sp, #0x160
     628:      	str	w8, [sp, #0x160]
     62c:      	mov	w8, #0x1                // =1
     630:      	ldr	x0, [x0]
     634:      	blr	x8
     638:      	cbz	x0, 0x664 <native_tracer_entry+0x664>
     63c:      	ldr	x8, [x0]
     640:      	add	x8, x8, #0x1
     644:      	str	x8, [x0]
     648:      	b	0x66c <native_tracer_entry+0x66c>
     64c:      	adrp	x10, 0x0 <native_tracer_entry>
     650:      	mov	x9, xzr
     654:      	mov	w8, #0xc                // =12
     658:      	ldr	x10, [x10]
     65c:      	mov	w2, wzr
     660:      	b	0x690 <native_tracer_entry+0x690>
     664:      	ldr	w8, [x25]
     668:      	cbnz	w8, 0xc10 <native_tracer_entry+0xc10>
     66c:      	ldrb	w8, [x21, x20]
     670:      	mov	w2, wzr
     674:      	mov	x0, x21
     678:      	add	w8, w8, #0x1
     67c:      	adrp	x10, 0x0 <native_tracer_entry>
     680:      	mov	w9, w2
     684:      	strb	w8, [x0, x20]
     688:      	mov	w8, #0xc                // =12
     68c:      	ldr	x10, [x10]
     690:      	adrp	x1, 0x0 <native_tracer_entry>
     694:      	mov	x0, x19
     698:      	ldr	x1, [x1]
     69c:      	blr	x8
     6a0:      	ldr	w8, [x25]
     6a4:      	cbnz	w8, 0xa7c <native_tracer_entry+0xa7c>
     6a8:      	mov	w0, #-0x1               // =-1
     6ac:      	ldp	x20, x19, [sp, #0x1e0]
     6b0:      	ldr	x29, [sp, #0x1a0]
     6b4:      	ldp	x22, x21, [sp, #0x1d0]
     6b8:      	ldp	x24, x23, [sp, #0x1c0]
     6bc:      	ldp	x30, x25, [sp, #0x1b0]
     6c0:      	add	sp, sp, #0x1f0
     6c4:      	ret
     6c8:      	str	x23, [sp, #0x198]
     6cc:      	str	w22, [sp, #0x1a8]
     6d0:      	adrp	x20, 0x0 <native_tracer_entry>
     6d4:      	mov	w8, #0x1                // =1
     6d8:      	add	x9, sp, #0x1a8
     6dc:      	add	x1, sp, #0x1a8
     6e0:      	ldr	x20, [x20]
     6e4:      	mov	x0, x20
     6e8:      	blr	x8
     6ec:      	mov	w8, #0x5                // =5
     6f0:      	mov	x21, x0
     6f4:      	blr	x8
     6f8:      	cbz	x21, 0x7b4 <native_tracer_entry+0x7b4>
     6fc:      	ldr	x8, [x21]
     700:      	mov	w11, #0xe100            // =57600
     704:      	movk	w11, #0x5f5, lsl #16
     708:      	and	x9, x8, #0xffffffffffffffe0
     70c:      	and	x10, x8, #0xf
     710:      	sub	x9, x0, x9
     714:      	lsl	x10, x11, x10
     718:      	cmp	x9, x10
     71c:      	b.hs	0x778 <native_tracer_entry+0x778>
     720:      	ldr	w8, [x25]
     724:      	cbz	w8, 0x144 <native_tracer_entry+0x144>
     728:      	adrp	x8, 0x0 <native_tracer_entry>
     72c:      	add	x8, x8, #0x0
     730:      	add	x0, sp, #0x10
     734:      	ldp	x9, x10, [x8]
     738:      	mov	w1, #0x20               // =32
     73c:      	stp	x9, x10, [sp, #0x10]
     740:      	ldp	x9, x8, [x8, #0x10]
     744:      	add	x10, sp, #0x10
     748:      	stp	x9, x8, [sp, #0x20]
     74c:      	mov	w8, #0x20               // =32
     750:      	mov	w9, #0x6                // =6
     754:      	ldr	w2, [sp, #0x1a8]
     758:      	blr	x9
     75c:      	b	0x144 <native_tracer_entry+0x144>
     760:      	cbnz	w8, 0xe20 <native_tracer_entry+0xe20>
     764:      	mov	w8, #0x1                // =1
     768:      	mov	w22, wzr
     76c:      	str	w8, [x21, #0xf18]
     770:      	mov	w8, #0xfad              // =4013
     774:      	b	0x5d8 <native_tracer_entry+0x5d8>
     778:      	mov	x11, #0xf200            // =61952
     77c:      	and	w21, w8, #0x10
     780:      	movk	x11, #0x2a05, lsl #16
     784:      	movk	x11, #0x1, lsl #32
     788:      	add	x10, x10, x11
     78c:      	cmp	x9, x10
     790:      	b.hs	0x7b4 <native_tracer_entry+0x7b4>
     794:      	cmp	w21, #0x0
     798:      	mov	w9, #0x4                // =4
     79c:      	mov	w10, #0x8               // =8
     7a0:      	and	w8, w8, #0xf
     7a4:      	csel	w9, w10, w9, eq
     7a8:      	cmp	w9, w8
     7ac:      	cinc	w23, w8, hi
     7b0:      	b	0x7b8 <native_tracer_entry+0x7b8>
     7b4:      	mov	w23, wzr
     7b8:      	ldr	w8, [x25]
     7bc:      	cbnz	w8, 0xdd4 <native_tracer_entry+0xdd4>
     7c0:      	mov	w9, w21
     7c4:      	and	x10, x23, #0xff
     7c8:      	and	x8, x0, #0xffffffffffffffe0
     7cc:      	mov	x3, xzr
     7d0:      	add	x1, sp, #0x1a8
     7d4:      	add	x2, sp, #0x160
     7d8:      	mov	x0, x20
     7dc:      	orr	x9, x9, x10
     7e0:      	add	x10, sp, #0x160
     7e4:      	orr	x8, x8, x9
     7e8:      	str	x8, [sp, #0x160]
     7ec:      	mov	w8, #0x2                // =2
     7f0:      	add	x9, sp, #0x1a8
     7f4:      	blr	x8
     7f8:      	cbz	w0, 0x86c <native_tracer_entry+0x86c>
     7fc:      	ldr	w8, [x25]
     800:      	cbnz	w8, 0xea0 <native_tracer_entry+0xea0>
     804:      	mov	w8, #0x3d               // =61
     808:      	adrp	x0, 0x0 <native_tracer_entry>
     80c:      	add	x9, sp, #0x1ac
     810:      	str	w8, [sp, #0x1ac]
     814:      	mov	w8, #0x1                // =1
     818:      	add	x1, sp, #0x1ac
     81c:      	ldr	x0, [x0]
     820:      	blr	x8
     824:      	cbnz	x0, 0xa1c <native_tracer_entry+0xa1c>
     828:      	ldr	w8, [x25]
     82c:      	cbz	w8, 0x144 <native_tracer_entry+0x144>
     830:      	adrp	x8, 0x0 <native_tracer_entry>
     834:      	add	x8, x8, #0x0
     838:      	ldp	x9, x10, [x8, #0x10]
     83c:      	stp	x9, x10, [sp, #0x20]
     840:      	ldr	x9, [x8, #0x20]
     844:      	add	x10, sp, #0x10
     848:      	str	x9, [sp, #0x30]
     84c:      	ldur	x9, [x8, #0x26]
     850:      	stur	x9, [sp, #0x36]
     854:      	ldp	x9, x8, [x8]
     858:      	stp	x9, x8, [sp, #0x10]
     85c:      	mov	w8, #0x2e               // =46
     860:      	mov	w9, #0x6                // =6
     864:      	ldr	w2, [sp, #0x1ac]
     868:      	b	0xa6c <native_tracer_entry+0xa6c>
     86c:      	mov	w20, #0x1               // =1
     870:      	adrp	x0, 0x0 <native_tracer_entry>
     874:      	mov	x3, xzr
     878:      	strb	w20, [sp, #0x194]
     87c:      	mov	w8, #0x2                // =2
     880:      	add	x9, sp, #0x198
     884:      	add	x10, sp, #0x194
     888:      	ldr	x0, [x0]
     88c:      	add	x1, sp, #0x198
     890:      	add	x2, sp, #0x194
     894:      	blr	x8
     898:      	cbz	w0, 0x908 <native_tracer_entry+0x908>
     89c:      	ldr	w8, [x25]
     8a0:      	cbnz	w8, 0x1054 <native_tracer_entry+0x1054>
     8a4:      	mov	w8, #0x3e               // =62
     8a8:      	adrp	x0, 0x0 <native_tracer_entry>
     8ac:      	add	x9, sp, #0x160
     8b0:      	str	w8, [sp, #0x160]
     8b4:      	mov	w8, #0x1                // =1
     8b8:      	add	x1, sp, #0x160
     8bc:      	ldr	x0, [x0]
     8c0:      	blr	x8
     8c4:      	cbnz	x0, 0xa1c <native_tracer_entry+0xa1c>
     8c8:      	ldr	w8, [x25]
     8cc:      	cbz	w8, 0x144 <native_tracer_entry+0x144>
     8d0:      	adrp	x8, 0x0 <native_tracer_entry>
     8d4:      	add	x8, x8, #0x0
     8d8:      	ldp	x9, x10, [x8, #0x10]
     8dc:      	stp	x9, x10, [sp, #0x20]
     8e0:      	ldr	x9, [x8, #0x20]
     8e4:      	add	x10, sp, #0x10
     8e8:      	str	x9, [sp, #0x30]
     8ec:      	ldur	x9, [x8, #0x26]
     8f0:      	stur	x9, [sp, #0x36]
     8f4:      	ldp	x9, x8, [x8]
     8f8:      	stp	x9, x8, [sp, #0x10]
     8fc:      	mov	w8, #0x2e               // =46
     900:      	mov	w9, #0x6                // =6
     904:      	b	0xa68 <native_tracer_entry+0xa68>
     908:      	str	w20, [sp, #0x1ac]
     90c:      	strb	w20, [sp, #0x1a8]
     910:      	adrp	x0, 0x0 <native_tracer_entry>
     914:      	mov	w8, #0x2                // =2
     918:      	add	x9, sp, #0x1ac
     91c:      	add	x10, sp, #0x1a8
     920:      	ldr	x0, [x0]
     924:      	add	x1, sp, #0x1ac
     928:      	add	x2, sp, #0x1a8
     92c:      	mov	w3, #0x1                // =1
     930:      	blr	x8
     934:      	tbnz	w0, #0x1f, 0x96c <native_tracer_entry+0x96c>
     938:      	mov	w8, #0x42               // =66
     93c:      	adrp	x0, 0x0 <native_tracer_entry>
     940:      	add	x9, sp, #0x160
     944:      	str	w8, [sp, #0x160]
     948:      	mov	w8, #0x1                // =1
     94c:      	add	x1, sp, #0x160
     950:      	ldr	x0, [x0]
     954:      	blr	x8
     958:      	cbz	x0, 0x9b0 <native_tracer_entry+0x9b0>
     95c:      	ldr	x8, [x0]
     960:      	add	x8, x8, #0x1
     964:      	str	x8, [x0]
     968:      	b	0x9b8 <native_tracer_entry+0x9b8>
     96c:      	ldr	w8, [x25]
     970:      	cbz	w8, 0x9f8 <native_tracer_entry+0x9f8>
     974:      	adrp	x8, 0x0 <native_tracer_entry>
     978:      	add	x8, x8, #0x0
     97c:      	strb	wzr, [sp, #0x28]
     980:      	add	x0, sp, #0x10
     984:      	ldp	x9, x10, [x8]
     988:      	ldr	x8, [x8, #0x10]
     98c:      	mov	w1, #0x19               // =25
     990:      	mov	w2, #0x1                // =1
     994:      	str	x8, [sp, #0x20]
     998:      	stp	x9, x10, [sp, #0x10]
     99c:      	mov	w8, #0x19               // =25
     9a0:      	mov	w9, #0x6                // =6
     9a4:      	add	x10, sp, #0x10
     9a8:      	blr	x9
     9ac:      	b	0x9f8 <native_tracer_entry+0x9f8>
     9b0:      	ldr	w8, [x25]
     9b4:      	cbnz	w8, 0x113c <native_tracer_entry+0x113c>
     9b8:      	mov	w8, #0x1                // =1
     9bc:      	adrp	x1, 0x0 <native_tracer_entry>
     9c0:      	mov	w9, #0x4                // =4
     9c4:      	str	w8, [sp, #0x160]
     9c8:      	mov	w8, #-0x1               // =-1
     9cc:      	mov	w10, #0x19              // =25
     9d0:      	add	x11, sp, #0x160
     9d4:      	ldr	x1, [x1]
     9d8:      	add	x3, sp, #0x160
     9dc:      	mov	x0, x19
     9e0:      	mov	w2, #-0x1               // =-1
     9e4:      	mov	w4, #0x4                // =4
     9e8:      	blr	x10
     9ec:      	tbz	w0, #0x1f, 0x9f8 <native_tracer_entry+0x9f8>
     9f0:      	ldr	w8, [x25]
     9f4:      	cbnz	w8, 0x10f0 <native_tracer_entry+0x10f0>
     9f8:      	mov	w8, #0x3f               // =63
     9fc:      	adrp	x0, 0x0 <native_tracer_entry>
     a00:      	add	x9, sp, #0x160
     a04:      	str	w8, [sp, #0x160]
     a08:      	mov	w8, #0x1                // =1
     a0c:      	add	x1, sp, #0x160
     a10:      	ldr	x0, [x0]
     a14:      	blr	x8
     a18:      	cbz	x0, 0xa2c <native_tracer_entry+0xa2c>
     a1c:      	ldr	x8, [x0]
     a20:      	add	x8, x8, #0x1
     a24:      	str	x8, [x0]
     a28:      	b	0x144 <native_tracer_entry+0x144>
     a2c:      	ldr	w8, [x25]
     a30:      	cbz	w8, 0x144 <native_tracer_entry+0x144>
     a34:      	adrp	x8, 0x0 <native_tracer_entry>
     a38:      	add	x8, x8, #0x0
     a3c:      	ldp	x9, x10, [x8, #0x10]
     a40:      	stp	x9, x10, [sp, #0x20]
     a44:      	ldr	x9, [x8, #0x20]
     a48:      	add	x10, sp, #0x10
     a4c:      	str	x9, [sp, #0x30]
     a50:      	ldur	x9, [x8, #0x26]
     a54:      	stur	x9, [sp, #0x36]
     a58:      	ldp	x9, x8, [x8]
     a5c:      	stp	x9, x8, [sp, #0x10]
     a60:      	mov	w8, #0x2e               // =46
     a64:      	mov	w9, #0x6                // =6
     a68:      	ldr	w2, [sp, #0x160]
     a6c:      	add	x0, sp, #0x10
     a70:      	mov	w1, #0x2e               // =46
     a74:      	blr	x9
     a78:      	b	0x144 <native_tracer_entry+0x144>
     a7c:      	mov	w8, #0x7972             // =31090
     a80:      	add	x0, sp, #0x10
     a84:      	mov	w1, #0x34               // =52
     a88:      	mov	w2, w22
     a8c:      	movk	w8, #0xa, lsl #16
     a90:      	str	w8, [sp, #0x40]
     a94:      	adrp	x8, 0x0 <native_tracer_entry>
     a98:      	add	x8, x8, #0x0
     a9c:      	ldp	x9, x10, [x8, #0x10]
     aa0:      	stp	x9, x10, [sp, #0x20]
     aa4:      	ldp	x9, x10, [x8, #0x20]
     aa8:      	stp	x9, x10, [sp, #0x30]
     aac:      	ldp	x9, x8, [x8]
     ab0:      	add	x10, sp, #0x10
     ab4:      	stp	x9, x8, [sp, #0x10]
     ab8:      	mov	w8, #0x34               // =52
     abc:      	mov	w9, #0x6                // =6
     ac0:      	blr	x9
     ac4:      	b	0x6a8 <native_tracer_entry+0x6a8>
     ac8:      	adrp	x8, 0x0 <native_tracer_entry>
     acc:      	add	x8, x8, #0x0
     ad0:      	add	x0, sp, #0x10
     ad4:      	ldp	x9, x10, [x8]
     ad8:      	ldur	x8, [x8, #0xe]
     adc:      	mov	w1, #0x16               // =22
     ae0:      	stp	x9, x10, [sp, #0x10]
     ae4:      	stur	x8, [sp, #0x1e]
     ae8:      	mov	w8, #0x16               // =22
     aec:      	mov	w9, #0x6                // =6
     af0:      	add	x10, sp, #0x10
     af4:      	blr	x9
     af8:      	b	0x168 <native_tracer_entry+0x168>
     afc:      	adrp	x8, 0x0 <native_tracer_entry>
     b00:      	add	x8, x8, #0x0
     b04:      	add	x0, sp, #0x10
     b08:      	ldp	x9, x10, [x8]
     b0c:      	ldur	x8, [x8, #0xe]
     b10:      	mov	w1, #0x16               // =22
     b14:      	stp	x9, x10, [sp, #0x10]
     b18:      	stur	x8, [sp, #0x1e]
     b1c:      	mov	w8, #0x16               // =22
     b20:      	mov	w9, #0x6                // =6
     b24:      	add	x10, sp, #0x10
     b28:      	ldr	w2, [x21, #0x2bc]
     b2c:      	blr	x9
     b30:      	b	0x3dc <native_tracer_entry+0x3dc>
     b34:      	adrp	x8, 0x0 <native_tracer_entry>
     b38:      	add	x8, x8, #0x0
     b3c:      	add	x0, sp, #0x10
     b40:      	ldp	x9, x10, [x8, #0x10]
     b44:      	mov	w1, #0x27               // =39
     b48:      	stp	x9, x10, [sp, #0x20]
     b4c:      	ldur	x9, [x8, #0x1f]
     b50:      	add	x10, sp, #0x10
     b54:      	stur	x9, [sp, #0x2f]
     b58:      	ldp	x8, x9, [x8]
     b5c:      	stp	x8, x9, [sp, #0x10]
     b60:      	mov	w8, #0x27               // =39
     b64:      	mov	w9, #0x6                // =6
     b68:      	ldr	x2, [x21, #0xed0]
     b6c:      	ldr	x3, [x21, #0xed8]
     b70:      	ldr	x4, [x21, #0xee0]
     b74:      	blr	x9
     b78:      	b	0x568 <native_tracer_entry+0x568>
     b7c:      	adrp	x8, 0x0 <native_tracer_entry>
     b80:      	add	x8, x8, #0x0
     b84:      	add	x0, sp, #0x160
     b88:      	ldp	x9, x10, [x8, #0x10]
     b8c:      	mov	w1, #0x2e               // =46
     b90:      	stp	x9, x10, [sp, #0x170]
     b94:      	ldr	x9, [x8, #0x20]
     b98:      	add	x10, sp, #0x87
     b9c:      	str	x9, [sp, #0x180]
     ba0:      	ldur	x9, [x8, #0x26]
     ba4:      	stur	x9, [x10, #0xff]
     ba8:      	ldp	x9, x8, [x8]
     bac:      	add	x10, sp, #0x160
     bb0:      	stp	x9, x8, [sp, #0x160]
     bb4:      	mov	w8, #0x2e               // =46
     bb8:      	mov	w9, #0x6                // =6
     bbc:      	ldr	w2, [sp, #0x198]
     bc0:      	blr	x9
     bc4:      	b	0x330 <native_tracer_entry+0x330>
     bc8:      	adrp	x8, 0x0 <native_tracer_entry>
     bcc:      	add	x8, x8, #0x0
     bd0:      	add	x0, sp, #0x10
     bd4:      	ldp	x9, x10, [x8, #0x10]
     bd8:      	mov	w1, #0x2e               // =46
     bdc:      	stp	x9, x10, [sp, #0x20]
     be0:      	ldr	x9, [x8, #0x20]
     be4:      	add	x10, sp, #0x10
     be8:      	str	x9, [sp, #0x30]
     bec:      	ldur	x9, [x8, #0x26]
     bf0:      	stur	x9, [sp, #0x36]
     bf4:      	ldp	x9, x8, [x8]
     bf8:      	stp	x9, x8, [sp, #0x10]
     bfc:      	mov	w8, #0x2e               // =46
     c00:      	mov	w9, #0x6                // =6
     c04:      	ldr	w2, [sp, #0x160]
     c08:      	blr	x9
     c0c:      	b	0x258 <native_tracer_entry+0x258>
     c10:      	adrp	x8, 0x0 <native_tracer_entry>
     c14:      	add	x8, x8, #0x0
     c18:      	add	x0, sp, #0x10
     c1c:      	ldp	x9, x10, [x8, #0x10]
     c20:      	mov	w1, #0x2e               // =46
     c24:      	stp	x9, x10, [sp, #0x20]
     c28:      	ldr	x9, [x8, #0x20]
     c2c:      	add	x10, sp, #0x10
     c30:      	str	x9, [sp, #0x30]
     c34:      	ldur	x9, [x8, #0x26]
     c38:      	stur	x9, [sp, #0x36]
     c3c:      	ldp	x9, x8, [x8]
     c40:      	stp	x9, x8, [sp, #0x10]
     c44:      	mov	w8, #0x2e               // =46
     c48:      	mov	w9, #0x6                // =6
     c4c:      	ldr	w2, [sp, #0x160]
     c50:      	blr	x9
     c54:      	b	0x66c <native_tracer_entry+0x66c>
     c58:      	adrp	x8, 0x0 <native_tracer_entry>
     c5c:      	add	x8, x8, #0x0
     c60:      	strb	wzr, [sp, #0x40]
     c64:      	add	x0, sp, #0x10
     c68:      	ldp	x9, x10, [x8, #0x10]
     c6c:      	mov	w1, #0x31               // =49
     c70:      	stp	x9, x10, [sp, #0x20]
     c74:      	ldp	x9, x10, [x8, #0x20]
     c78:      	stp	x9, x10, [sp, #0x30]
     c7c:      	ldp	x9, x8, [x8]
     c80:      	add	x10, sp, #0x10
     c84:      	stp	x9, x8, [sp, #0x10]
     c88:      	mov	w8, #0x31               // =49
     c8c:      	mov	w9, #0x6                // =6
     c90:      	ldr	w2, [x21, #0x2c0]
     c94:      	blr	x9
     c98:      	ldr	x23, [x21, #0xed0]
     c9c:      	lsr	x8, x23, #56
     ca0:      	cbnz	x8, 0x5b4 <native_tracer_entry+0x5b4>
     ca4:      	cmp	x23, #0xfff
     ca8:      	b.hi	0xcc8 <native_tracer_entry+0xcc8>
     cac:      	ldr	w8, [x25]
     cb0:      	cbnz	w8, 0xf74 <native_tracer_entry+0xf74>
     cb4:      	mov	w8, #0x31               // =49
     cb8:      	mov	w22, wzr
     cbc:      	str	w8, [x21, #0xf18]
     cc0:      	mov	w8, #0xfae              // =4014
     cc4:      	b	0x5d8 <native_tracer_entry+0x5d8>
     cc8:      	ldr	w8, [x21]
     ccc:      	mov	w9, #0x60               // =96
     cd0:      	add	x1, sp, #0x160
     cd4:      	mov	x0, x24
     cd8:      	str	w9, [sp, #0x160]
     cdc:      	add	x9, sp, #0x160
     ce0:      	rev	w8, w8
     ce4:      	str	w8, [sp, #0x164]
     ce8:      	rev	x8, x23
     cec:      	str	x8, [sp, #0x168]
     cf0:      	mov	w8, #0x1                // =1
     cf4:      	blr	x8
     cf8:      	cbz	x0, 0xdb0 <native_tracer_entry+0xdb0>
     cfc:      	ldr	x8, [x0, #0x8]
     d00:      	and	x9, x8, #0xffffffffffffff
     d04:      	lsr	x22, x8, #56
     d08:      	str	x9, [x21, #0xf10]
     d0c:      	ldr	x8, [x0]
     d10:      	str	x8, [x21, #0xf00]
     d14:      	sub	x8, x23, x9
     d18:      	str	x8, [x21, #0xf08]
     d1c:      	ldr	w8, [x25]
     d20:      	cbnz	w8, 0xfb4 <native_tracer_entry+0xfb4>
     d24:      	cmp	w22, #0x1
     d28:      	b.ne	0x34c <native_tracer_entry+0x34c>
     d2c:      	ldr	x8, [x21, #0xf00]
     d30:      	adrp	x0, 0x0 <native_tracer_entry>
     d34:      	ldr	x22, [x21, #0xf08]
     d38:      	mov	w9, #0x1                // =1
     d3c:      	add	x1, sp, #0x160
     d40:      	mov	w23, #0x1               // =1
     d44:      	str	x8, [sp, #0x160]
     d48:      	add	x8, sp, #0x160
     d4c:      	ldr	x0, [x0]
     d50:      	blr	x9
     d54:      	cbz	x0, 0xdcc <native_tracer_entry+0xdcc>
     d58:      	ldr	x8, [x0]
     d5c:      	cmp	x8, x22
     d60:      	b.hi	0xd70 <native_tracer_entry+0xd70>
     d64:      	ldr	x8, [x0, #0x8]
     d68:      	cmp	x8, x22
     d6c:      	b.hs	0xd88 <native_tracer_entry+0xd88>
     d70:      	ldr	x8, [x0, #0x10]
     d74:      	cmp	x8, x22
     d78:      	b.hi	0xda8 <native_tracer_entry+0xda8>
     d7c:      	ldr	x8, [x0, #0x18]
     d80:      	cmp	x8, x22
     d84:      	b.lo	0xda8 <native_tracer_entry+0xda8>
     d88:      	ldr	w8, [x25]
     d8c:      	cbnz	w8, 0x1184 <native_tracer_entry+0x1184>
     d90:      	ldrh	w8, [x0, #0x20]
     d94:      	ldr	w9, [x21, #0x1370]
     d98:      	lsr	w8, w9, w8
     d9c:      	tbz	w8, #0x0, 0x11d8 <native_tracer_entry+0x11d8>
     da0:      	ldr	w8, [x25]
     da4:      	cbnz	w8, 0x1224 <native_tracer_entry+0x1224>
     da8:      	mov	w22, #0x1               // =1
     dac:      	b	0x34c <native_tracer_entry+0x34c>
     db0:      	ldr	w8, [x25]
     db4:      	cbnz	w8, 0x10a4 <native_tracer_entry+0x10a4>
     db8:      	mov	w8, #0xc                // =12
     dbc:      	mov	w22, wzr
     dc0:      	str	w8, [x21, #0xf18]
     dc4:      	mov	w8, #0xfac              // =4012
     dc8:      	b	0x5d8 <native_tracer_entry+0x5d8>
     dcc:      	mov	w22, w23
     dd0:      	b	0x34c <native_tracer_entry+0x34c>
     dd4:      	adrp	x8, 0x0 <native_tracer_entry>
     dd8:      	add	x8, x8, #0x0
     ddc:      	mov	x24, x0
     de0:      	ldp	x9, x10, [x8]
     de4:      	add	x0, sp, #0x10
     de8:      	and	w3, w23, #0xff
     dec:      	mov	w1, #0x1f               // =31
     df0:      	stp	x9, x10, [sp, #0x10]
     df4:      	ldr	x9, [x8, #0x10]
     df8:      	ldur	x8, [x8, #0x17]
     dfc:      	add	x10, sp, #0x10
     e00:      	str	x9, [sp, #0x20]
     e04:      	stur	x8, [sp, #0x27]
     e08:      	mov	w8, #0x1f               // =31
     e0c:      	mov	w9, #0x6                // =6
     e10:      	ldr	w2, [sp, #0x1a8]
     e14:      	blr	x9
     e18:      	mov	x0, x24
     e1c:      	b	0x7c0 <native_tracer_entry+0x7c0>
     e20:      	adrp	x8, 0x0 <native_tracer_entry>
     e24:      	add	x8, x8, #0x0
     e28:      	strb	wzr, [sp, #0x40]
     e2c:      	add	x0, sp, #0x10
     e30:      	ldp	x9, x10, [x8, #0x10]
     e34:      	mov	w1, #0x31               // =49
     e38:      	stp	x9, x10, [sp, #0x20]
     e3c:      	ldp	x9, x10, [x8, #0x20]
     e40:      	stp	x9, x10, [sp, #0x30]
     e44:      	ldp	x9, x8, [x8]
     e48:      	add	x10, sp, #0x10
     e4c:      	stp	x9, x8, [sp, #0x10]
     e50:      	mov	w8, #0x31               // =49
     e54:      	mov	w9, #0x6                // =6
     e58:      	blr	x9
     e5c:      	b	0x764 <native_tracer_entry+0x764>
     e60:      	mov	w8, #0xa                // =10
     e64:      	add	x0, sp, #0x10
     e68:      	mov	w1, #0x22               // =34
     e6c:      	strh	w8, [sp, #0x30]
     e70:      	adrp	x8, 0x0 <native_tracer_entry>
     e74:      	add	x8, x8, #0x0
     e78:      	mov	x2, x23
     e7c:      	ldp	x9, x10, [x8]
     e80:      	stp	x9, x10, [sp, #0x10]
     e84:      	ldp	x9, x8, [x8, #0x10]
     e88:      	add	x10, sp, #0x10
     e8c:      	stp	x9, x8, [sp, #0x20]
     e90:      	mov	w8, #0x22               // =34
     e94:      	mov	w9, #0x6                // =6
     e98:      	blr	x9
     e9c:      	b	0x5bc <native_tracer_entry+0x5bc>
     ea0:      	adrp	x8, 0x0 <native_tracer_entry>
     ea4:      	add	x8, x8, #0x0
     ea8:      	mov	w3, w0
     eac:      	ldp	x9, x10, [x8]
     eb0:      	add	x0, sp, #0x10
     eb4:      	mov	w1, #0x1d               // =29
     eb8:      	stp	x9, x10, [sp, #0x10]
     ebc:      	ldr	x9, [x8, #0x10]
     ec0:      	ldur	x8, [x8, #0x15]
     ec4:      	add	x10, sp, #0x10
     ec8:      	str	x9, [sp, #0x20]
     ecc:      	stur	x8, [sp, #0x25]
     ed0:      	mov	w8, #0x1d               // =29
     ed4:      	mov	w9, #0x6                // =6
     ed8:      	ldr	w2, [sp, #0x1a8]
     edc:      	blr	x9
     ee0:      	b	0x804 <native_tracer_entry+0x804>
     ee4:      	adrp	x8, 0x0 <native_tracer_entry>
     ee8:      	add	x8, x8, #0x0
     eec:      	add	x0, sp, #0x10
     ef0:      	ldp	x9, x10, [x8, #0x10]
     ef4:      	mov	w1, #0x2e               // =46
     ef8:      	stp	x9, x10, [sp, #0x20]
     efc:      	ldr	x9, [x8, #0x20]
     f00:      	add	x10, sp, #0x10
     f04:      	str	x9, [sp, #0x30]
     f08:      	ldur	x9, [x8, #0x26]
     f0c:      	stur	x9, [sp, #0x36]
     f10:      	ldp	x9, x8, [x8]
     f14:      	stp	x9, x8, [sp, #0x10]
     f18:      	mov	w8, #0x2e               // =46
     f1c:      	mov	w9, #0x6                // =6
     f20:      	ldr	w2, [sp, #0x160]
     f24:      	blr	x9
     f28:      	b	0x3b4 <native_tracer_entry+0x3b4>
     f2c:      	adrp	x8, 0x0 <native_tracer_entry>
     f30:      	add	x8, x8, #0x0
     f34:      	add	x0, sp, #0x10
     f38:      	ldp	x9, x10, [x8, #0x10]
     f3c:      	mov	w1, #0x2e               // =46
     f40:      	stp	x9, x10, [sp, #0x20]
     f44:      	ldr	x9, [x8, #0x20]
     f48:      	add	x10, sp, #0x10
     f4c:      	str	x9, [sp, #0x30]
     f50:      	ldur	x9, [x8, #0x26]
     f54:      	stur	x9, [sp, #0x36]
     f58:      	ldp	x9, x8, [x8]
     f5c:      	stp	x9, x8, [sp, #0x10]
     f60:      	mov	w8, #0x2e               // =46
     f64:      	mov	w9, #0x6                // =6
     f68:      	ldr	w2, [sp, #0x160]
     f6c:      	blr	x9
     f70:      	b	0x470 <native_tracer_entry+0x470>
     f74:      	adrp	x8, 0x0 <native_tracer_entry>
     f78:      	add	x8, x8, #0x0
     f7c:      	add	x0, sp, #0x10
     f80:      	ldp	x9, x10, [x8]
     f84:      	mov	w1, #0x1e               // =30
     f88:      	mov	x2, x23
     f8c:      	stp	x9, x10, [sp, #0x10]
     f90:      	ldr	x9, [x8, #0x10]
     f94:      	ldur	x8, [x8, #0x16]
     f98:      	add	x10, sp, #0x10
     f9c:      	str	x9, [sp, #0x20]
     fa0:      	stur	x8, [sp, #0x26]
     fa4:      	mov	w8, #0x1e               // =30
     fa8:      	mov	w9, #0x6                // =6
     fac:      	blr	x9
     fb0:      	b	0xcb4 <native_tracer_entry+0xcb4>
     fb4:      	mov	w8, #0xa                // =10
     fb8:      	add	x0, sp, #0x10
     fbc:      	mov	w1, #0x32               // =50
     fc0:      	strh	w8, [sp, #0x40]
     fc4:      	adrp	x8, 0x0 <native_tracer_entry>
     fc8:      	add	x8, x8, #0x0
     fcc:      	mov	x2, x23
     fd0:      	ldp	x9, x10, [x8, #0x10]
     fd4:      	mov	w4, w22
     fd8:      	stp	x9, x10, [sp, #0x20]
     fdc:      	ldp	x9, x10, [x8, #0x20]
     fe0:      	stp	x9, x10, [sp, #0x30]
     fe4:      	ldp	x9, x8, [x8]
     fe8:      	add	x10, sp, #0x10
     fec:      	stp	x9, x8, [sp, #0x10]
     ff0:      	mov	w8, #0x32               // =50
     ff4:      	mov	w9, #0x6                // =6
     ff8:      	ldr	x3, [x21, #0xf00]
     ffc:      	blr	x9
    1000:      	ldr	w8, [x25]
    1004:      	cbz	w8, 0xd24 <native_tracer_entry+0xd24>
    1008:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    100c:      	add	x8, x8, #0x0
    1010:      	add	x0, sp, #0x10
    1014:      	ldp	x9, x10, [x8, #0x10]
    1018:      	mov	w1, #0x2f               // =47
    101c:      	stp	x9, x10, [sp, #0x20]
    1020:      	ldr	x9, [x8, #0x20]
    1024:      	add	x10, sp, #0x10
    1028:      	str	x9, [sp, #0x30]
    102c:      	ldur	x9, [x8, #0x27]
    1030:      	stur	x9, [sp, #0x37]
    1034:      	ldp	x9, x8, [x8]
    1038:      	stp	x9, x8, [sp, #0x10]
    103c:      	mov	w8, #0x2f               // =47
    1040:      	mov	w9, #0x6                // =6
    1044:      	ldr	x2, [x21, #0xf10]
    1048:      	ldr	x3, [x21, #0xf08]
    104c:      	blr	x9
    1050:      	b	0xd24 <native_tracer_entry+0xd24>
    1054:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    1058:      	add	x8, x8, #0x0
    105c:      	ldr	w3, [sp, #0x198]
    1060:      	mov	w4, w0
    1064:      	ldp	x9, x10, [x8, #0x20]
    1068:      	add	x0, sp, #0x10
    106c:      	mov	w1, #0x35               // =53
    1070:      	mov	w2, w22
    1074:      	stp	x9, x10, [sp, #0x30]
    1078:      	ldur	x9, [x8, #0x2d]
    107c:      	stur	x9, [sp, #0x3d]
    1080:      	ldp	x9, x10, [x8]
    1084:      	stp	x9, x10, [sp, #0x10]
    1088:      	ldp	x8, x9, [x8, #0x10]
    108c:      	add	x10, sp, #0x10
    1090:      	stp	x8, x9, [sp, #0x20]
    1094:      	mov	w8, #0x35               // =53
    1098:      	mov	w9, #0x6                // =6
    109c:      	blr	x9
    10a0:      	b	0x8a4 <native_tracer_entry+0x8a4>
    10a4:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    10a8:      	add	x8, x8, #0x0
    10ac:      	strb	wzr, [sp, #0x48]
    10b0:      	add	x0, sp, #0x10
    10b4:      	ldp	x9, x10, [x8, #0x20]
    10b8:      	mov	w1, #0x39               // =57
    10bc:      	mov	x2, x23
    10c0:      	stp	x9, x10, [sp, #0x30]
    10c4:      	ldr	x9, [x8, #0x30]
    10c8:      	str	x9, [sp, #0x40]
    10cc:      	ldp	x9, x10, [x8]
    10d0:      	stp	x9, x10, [sp, #0x10]
    10d4:      	ldp	x8, x9, [x8, #0x10]
    10d8:      	add	x10, sp, #0x10
    10dc:      	stp	x8, x9, [sp, #0x20]
    10e0:      	mov	w8, #0x39               // =57
    10e4:      	mov	w9, #0x6                // =6
    10e8:      	blr	x9
    10ec:      	b	0xdb8 <native_tracer_entry+0xdb8>
    10f0:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    10f4:      	add	x8, x8, #0x0
    10f8:      	mov	w3, w0
    10fc:      	ldp	x9, x10, [x8, #0x20]
    1100:      	add	x0, sp, #0x10
    1104:      	mov	w1, #0x36               // =54
    1108:      	mov	w2, #0x1                // =1
    110c:      	stp	x9, x10, [sp, #0x30]
    1110:      	ldur	x9, [x8, #0x2e]
    1114:      	stur	x9, [sp, #0x3e]
    1118:      	ldp	x9, x10, [x8]
    111c:      	stp	x9, x10, [sp, #0x10]
    1120:      	ldp	x8, x9, [x8, #0x10]
    1124:      	add	x10, sp, #0x10
    1128:      	stp	x8, x9, [sp, #0x20]
    112c:      	mov	w8, #0x36               // =54
    1130:      	mov	w9, #0x6                // =6
    1134:      	blr	x9
    1138:      	b	0x9f8 <native_tracer_entry+0x9f8>
    113c:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    1140:      	add	x8, x8, #0x0
    1144:      	add	x0, sp, #0x10
    1148:      	ldp	x9, x10, [x8, #0x10]
    114c:      	mov	w1, #0x2e               // =46
    1150:      	stp	x9, x10, [sp, #0x20]
    1154:      	ldr	x9, [x8, #0x20]
    1158:      	add	x10, sp, #0x10
    115c:      	str	x9, [sp, #0x30]
    1160:      	ldur	x9, [x8, #0x26]
    1164:      	stur	x9, [sp, #0x36]
    1168:      	ldp	x9, x8, [x8]
    116c:      	stp	x9, x8, [sp, #0x10]
    1170:      	mov	w8, #0x2e               // =46
    1174:      	mov	w9, #0x6                // =6
    1178:      	ldr	w2, [sp, #0x160]
    117c:      	blr	x9
    1180:      	b	0x9b8 <native_tracer_entry+0x9b8>
    1184:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    1188:      	add	x8, x8, #0x0
    118c:      	mov	x22, x0
    1190:      	ldp	x9, x10, [x8]
    1194:      	mov	w1, #0x1e               // =30
    1198:      	stp	x9, x10, [sp, #0x10]
    119c:      	ldr	x9, [x8, #0x10]
    11a0:      	ldur	x8, [x8, #0x16]
    11a4:      	add	x10, sp, #0x10
    11a8:      	str	x9, [sp, #0x20]
    11ac:      	stur	x8, [sp, #0x26]
    11b0:      	mov	w8, #0x1e               // =30
    11b4:      	mov	w9, #0x6                // =6
    11b8:      	ldrh	w2, [x0, #0x20]
    11bc:      	add	x0, sp, #0x10
    11c0:      	blr	x9
    11c4:      	mov	x0, x22
    11c8:      	ldrh	w8, [x22, #0x20]
    11cc:      	ldr	w9, [x21, #0x1370]
    11d0:      	lsr	w8, w9, w8
    11d4:      	tbnz	w8, #0x0, 0xda0 <native_tracer_entry+0xda0>
    11d8:      	mov	x22, x0
    11dc:      	str	wzr, [sp, #0x198]
    11e0:      	adrp	x0, 0x1000 <native_tracer_entry+0x1000>
    11e4:      	mov	w8, #0x1                // =1
    11e8:      	ldr	x0, [x0]
    11ec:      	add	x9, sp, #0x198
    11f0:      	add	x1, sp, #0x198
    11f4:      	blr	x8
    11f8:      	cbz	x0, 0x1210 <native_tracer_entry+0x1210>
    11fc:      	ldr	x8, [x0]
    1200:      	add	x8, x8, #0x1
    1204:      	str	x8, [x0]
    1208:      	mov	x8, x22
    120c:      	b	0x121c <native_tracer_entry+0x121c>
    1210:      	ldr	w9, [x25]
    1214:      	mov	x8, x22
    1218:      	cbnz	w9, 0x1264 <native_tracer_entry+0x1264>
    121c:      	ldrh	w22, [x8, #0x20]
    1220:      	b	0x34c <native_tracer_entry+0x34c>
    1224:      	mov	w8, #0x656e             // =25966
    1228:      	add	x0, sp, #0x10
    122c:      	mov	w1, #0x1b               // =27
    1230:      	movk	w8, #0xa, lsl #16
    1234:      	stur	w8, [sp, #0x27]
    1238:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    123c:      	add	x8, x8, #0x0
    1240:      	ldp	x9, x10, [x8]
    1244:      	ldr	x8, [x8, #0x10]
    1248:      	stp	x9, x10, [sp, #0x10]
    124c:      	str	x8, [sp, #0x20]
    1250:      	mov	w8, #0x1b               // =27
    1254:      	mov	w9, #0x6                // =6
    1258:      	add	x10, sp, #0x10
    125c:      	blr	x9
    1260:      	b	0xda8 <native_tracer_entry+0xda8>
    1264:      	adrp	x8, 0x1000 <native_tracer_entry+0x1000>
    1268:      	add	x8, x8, #0x0
    126c:      	add	x0, sp, #0x10
    1270:      	ldp	x9, x10, [x8, #0x10]
    1274:      	mov	w1, #0x2e               // =46
    1278:      	stp	x9, x10, [sp, #0x20]
    127c:      	ldr	x9, [x8, #0x20]
    1280:      	add	x10, sp, #0x10
    1284:      	str	x9, [sp, #0x30]
    1288:      	ldur	x9, [x8, #0x26]
    128c:      	stur	x9, [sp, #0x36]
    1290:      	ldp	x9, x8, [x8]
    1294:      	stp	x9, x8, [sp, #0x10]
    1298:      	mov	w8, #0x2e               // =46
    129c:      	mov	w9, #0x6                // =6
    12a0:      	ldr	w2, [sp, #0x198]
    12a4:      	blr	x9
    12a8:      	b	0x1208 <native_tracer_entry+0x1208>

Disassembly of section perf_event/unwind_native:

0000000000000000 <perf_unwind_native>:
       0:      	sub	sp, sp, #0x1f0
       4:      	str	x29, [sp, #0x1a0]
       8:      	stp	x30, x25, [sp, #0x1b0]
       c:      	stp	x24, x23, [sp, #0x1c0]
      10:      	stp	x22, x21, [sp, #0x1d0]
      14:      	stp	x20, x19, [sp, #0x1e0]
      18:      	str	x0, [sp, #0x10]
      1c:      	str	wzr, [sp, #0x28]
      20:      	adrp	x0, 0x0 <perf_unwind_native>
      24:      	mov	w8, #0x1                // =1
      28:      	add	x9, sp, #0x28
      2c:      	add	x1, sp, #0x28
      30:      	ldr	x0, [x0]
      34:      	blr	x8
      38:      	cbz	x0, 0x195c <perf_unwind_native+0x195c>
      3c:      	add	x8, x0, #0xee0
      40:      	adrp	x24, 0x0 <perf_unwind_native>
      44:      	adrp	x25, 0x0 <perf_unwind_native>
      48:      	str	x8, [sp, #0x18]
      4c:      	add	x8, x0, #0xed8
      50:      	mov	x22, x0
      54:      	add	x23, x0, #0xed0
      58:      	str	x8, [sp, #0x8]
      5c:      	mov	w19, #0x4               // =4
      60:      	ldr	x24, [x24]
      64:      	ldr	x25, [x25]
      68:      	str	x23, [sp, #0x20]
      6c:      	ldr	w8, [x24]
      70:      	cbnz	w8, 0xe98 <perf_unwind_native+0xe98>
      74:      	mov	w8, #0x5                // =5
      78:      	add	x9, sp, #0x140
      7c:      	add	x1, sp, #0x140
      80:      	str	w8, [sp, #0x140]
      84:      	mov	w8, #0x1                // =1
      88:      	mov	x0, x25
      8c:      	blr	x8
      90:      	cbz	x0, 0x100 <perf_unwind_native+0x100>
      94:      	ldr	x8, [x0]
      98:      	add	x8, x8, #0x1
      9c:      	str	x8, [x0]
      a0:      	ldr	w8, [x24]
      a4:      	cbz	w8, 0x108 <perf_unwind_native+0x108>
      a8:      	mov	w8, #0x6b63             // =27491
      ac:      	adrp	x10, 0x0 <perf_unwind_native>
      b0:      	add	x10, x10, #0x0
      b4:      	add	x0, sp, #0x28
      b8:      	mov	w1, #0x2b               // =43
      bc:      	movk	w8, #0xa, lsl #16
      c0:      	stur	w8, [sp, #0x4f]
      c4:      	ldp	x8, x9, [x10, #0x10]
      c8:      	stp	x8, x9, [sp, #0x38]
      cc:      	ldr	x8, [x10, #0x20]
      d0:      	str	x8, [sp, #0x48]
      d4:      	ldp	x9, x8, [x10]
      d8:      	mov	w10, #0x2b              // =43
      dc:      	stp	x9, x8, [sp, #0x28]
      e0:      	mov	w8, #0x6                // =6
      e4:      	add	x9, sp, #0x28
      e8:      	ldr	x2, [x22, #0xf00]
      ec:      	ldr	x3, [x22, #0xf08]
      f0:      	ldr	w4, [x22, #0x2c0]
      f4:      	blr	x8
      f8:      	b	0x108 <perf_unwind_native+0x108>
      fc:      	nop
     100:      	ldr	w8, [x24]
     104:      	cbnz	w8, 0x10b0 <perf_unwind_native+0x10b0>
     108:      	ldr	w8, [x22, #0x2c0]
     10c:      	cmp	w8, #0x7f
     110:      	b.hs	0x14a4 <perf_unwind_native+0x14a4>
     114:      	ldr	x10, [x22, #0xf08]
     118:      	add	w12, w8, #0x1
     11c:      	ldrb	w9, [x22, #0xf20]
     120:      	ldr	x11, [x22, #0xf00]
     124:      	str	w12, [x22, #0x2c0]
     128:      	mov	w12, #0x18              // =24
     12c:      	umaddl	x8, w8, w12, x22
     130:      	str	x10, [x8, #0x2d8]
     134:      	mov	w10, #0x3               // =3
     138:      	str	x11, [x8, #0x2d0]
     13c:      	strb	w9, [x8, #0x2e1]
     140:      	ldr	x9, [x22, #0xf08]
     144:      	strb	w10, [x8, #0x2e0]
     148:      	strh	wzr, [x8, #0x2e6]
     14c:      	add	x8, x8, #0x2d0
     150:      	stur	wzr, [x8, #0x12]
     154:      	ldr	x8, [x22, #0xf00]
     158:      	str	wzr, [sp, #0x138]
     15c:      	and	x9, x9, #0xffffffffffff0000
     160:      	str	x8, [sp, #0x180]
     164:      	stp	x9, x8, [sp, #0x188]
     168:      	ldr	w8, [x24]
     16c:      	cbnz	w8, 0xedc <perf_unwind_native+0xedc>
     170:      	adrp	x0, 0x0 <perf_unwind_native>
     174:      	mov	w8, #0x1                // =1
     178:      	add	x9, sp, #0x180
     17c:      	ldr	x0, [x0]
     180:      	add	x1, sp, #0x180
     184:      	blr	x8
     188:      	cbz	x0, 0x151c <perf_unwind_native+0x151c>
     18c:      	ldrh	w8, [x0, #0x6]
     190:      	mov	x29, x0
     194:      	cmp	w8, #0xf
     198:      	b.gt	0x1e0 <perf_unwind_native+0x1e0>
     19c:      	cmp	w8, #0xb
     1a0:      	b.gt	0x20c <perf_unwind_native+0x20c>
     1a4:      	cmp	w8, #0x9
     1a8:      	b.gt	0x264 <perf_unwind_native+0x264>
     1ac:      	adrp	x0, 0x0 <perf_unwind_native>
     1b0:      	cmp	w8, #0x8
     1b4:      	ldr	x0, [x0]
     1b8:      	b.eq	0x324 <perf_unwind_native+0x324>
     1bc:      	cmp	w8, #0x9
     1c0:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     1c4:      	adrp	x0, 0x0 <perf_unwind_native>
     1c8:      	ldr	x0, [x0]
     1cc:      	b	0x324 <perf_unwind_native+0x324>
     1d0:      	nop
     1d4:      	nop
     1d8:      	nop
     1dc:      	nop
     1e0:      	cmp	w8, #0x13
     1e4:      	b.gt	0x240 <perf_unwind_native+0x240>
     1e8:      	cmp	w8, #0x11
     1ec:      	b.gt	0x280 <perf_unwind_native+0x280>
     1f0:      	cmp	w8, #0x10
     1f4:      	b.eq	0x2d4 <perf_unwind_native+0x2d4>
     1f8:      	cmp	w8, #0x11
     1fc:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     200:      	adrp	x0, 0x0 <perf_unwind_native>
     204:      	ldr	x0, [x0]
     208:      	b	0x324 <perf_unwind_native+0x324>
     20c:      	cmp	w8, #0xd
     210:      	b.gt	0x29c <perf_unwind_native+0x29c>
     214:      	cmp	w8, #0xc
     218:      	b.eq	0x2e0 <perf_unwind_native+0x2e0>
     21c:      	cmp	w8, #0xd
     220:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     224:      	adrp	x0, 0x0 <perf_unwind_native>
     228:      	ldr	x0, [x0]
     22c:      	b	0x324 <perf_unwind_native+0x324>
     230:      	nop
     234:      	nop
     238:      	nop
     23c:      	nop
     240:      	cmp	w8, #0x15
     244:      	b.gt	0x2b8 <perf_unwind_native+0x2b8>
     248:      	cmp	w8, #0x14
     24c:      	b.eq	0x2ec <perf_unwind_native+0x2ec>
     250:      	cmp	w8, #0x15
     254:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     258:      	adrp	x0, 0x0 <perf_unwind_native>
     25c:      	ldr	x0, [x0]
     260:      	b	0x324 <perf_unwind_native+0x324>
     264:      	cmp	w8, #0xa
     268:      	b.eq	0x2f8 <perf_unwind_native+0x2f8>
     26c:      	cmp	w8, #0xb
     270:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     274:      	adrp	x0, 0x0 <perf_unwind_native>
     278:      	ldr	x0, [x0]
     27c:      	b	0x324 <perf_unwind_native+0x324>
     280:      	cmp	w8, #0x12
     284:      	b.eq	0x304 <perf_unwind_native+0x304>
     288:      	cmp	w8, #0x13
     28c:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     290:      	adrp	x0, 0x0 <perf_unwind_native>
     294:      	ldr	x0, [x0]
     298:      	b	0x324 <perf_unwind_native+0x324>
     29c:      	cmp	w8, #0xe
     2a0:      	b.eq	0x310 <perf_unwind_native+0x310>
     2a4:      	cmp	w8, #0xf
     2a8:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     2ac:      	adrp	x0, 0x0 <perf_unwind_native>
     2b0:      	ldr	x0, [x0]
     2b4:      	b	0x324 <perf_unwind_native+0x324>
     2b8:      	cmp	w8, #0x16
     2bc:      	b.eq	0x31c <perf_unwind_native+0x31c>
     2c0:      	cmp	w8, #0x17
     2c4:      	b.ne	0x17e4 <perf_unwind_native+0x17e4>
     2c8:      	adrp	x0, 0x0 <perf_unwind_native>
     2cc:      	ldr	x0, [x0]
     2d0:      	b	0x324 <perf_unwind_native+0x324>
     2d4:      	adrp	x0, 0x0 <perf_unwind_native>
     2d8:      	ldr	x0, [x0]
     2dc:      	b	0x324 <perf_unwind_native+0x324>
     2e0:      	adrp	x0, 0x0 <perf_unwind_native>
     2e4:      	ldr	x0, [x0]
     2e8:      	b	0x324 <perf_unwind_native+0x324>
     2ec:      	adrp	x0, 0x0 <perf_unwind_native>
     2f0:      	ldr	x0, [x0]
     2f4:      	b	0x324 <perf_unwind_native+0x324>
     2f8:      	adrp	x0, 0x0 <perf_unwind_native>
     2fc:      	ldr	x0, [x0]
     300:      	b	0x324 <perf_unwind_native+0x324>
     304:      	adrp	x0, 0x0 <perf_unwind_native>
     308:      	ldr	x0, [x0]
     30c:      	b	0x324 <perf_unwind_native+0x324>
     310:      	adrp	x0, 0x0 <perf_unwind_native>
     314:      	ldr	x0, [x0]
     318:      	b	0x324 <perf_unwind_native+0x324>
     31c:      	adrp	x0, 0x0 <perf_unwind_native>
     320:      	ldr	x0, [x0]
     324:      	mov	w8, #0x1                // =1
     328:      	add	x9, sp, #0x190
     32c:      	add	x1, sp, #0x190
     330:      	blr	x8
     334:      	cbz	x0, 0x1538 <perf_unwind_native+0x1538>
     338:      	str	w19, [sp, #0x1ac]
     33c:      	ldr	w19, [x29]
     340:      	mov	x21, x0
     344:      	ldr	x23, [x22, #0xf08]
     348:      	ldrh	w8, [x29, #0x4]
     34c:      	str	w19, [sp, #0x13c]
     350:      	cbz	w8, 0x7d8 <perf_unwind_native+0x7d8>
     354:      	add	w25, w19, w8
     358:      	ldr	w8, [x24]
     35c:      	cbnz	w8, 0x1068 <perf_unwind_native+0x1068>
     360:      	add	w8, w25, w19
     364:      	add	x9, sp, #0x140
     368:      	add	x1, sp, #0x140
     36c:      	mov	x0, x21
     370:      	lsr	w8, w8, #1
     374:      	str	w8, [sp, #0x140]
     378:      	mov	w8, #0x1                // =1
     37c:      	blr	x8
     380:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     384:      	ldrh	w8, [x0]
     388:      	ldr	w20, [sp, #0x140]
     38c:      	and	w24, w23, #0xffff
     390:      	cmp	w8, w24
     394:      	b.hi	0x3a0 <perf_unwind_native+0x3a0>
     398:      	add	w19, w20, #0x1
     39c:      	mov	w20, w25
     3a0:      	cmp	w19, w20
     3a4:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     3a8:      	add	w8, w20, w19
     3ac:      	add	x9, sp, #0x140
     3b0:      	add	x1, sp, #0x140
     3b4:      	mov	x0, x21
     3b8:      	lsr	w8, w8, #1
     3bc:      	str	w8, [sp, #0x140]
     3c0:      	mov	w8, #0x1                // =1
     3c4:      	blr	x8
     3c8:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     3cc:      	ldrh	w8, [x0]
     3d0:      	ldr	w25, [sp, #0x140]
     3d4:      	cmp	w8, w24
     3d8:      	b.hi	0x3e4 <perf_unwind_native+0x3e4>
     3dc:      	add	w19, w25, #0x1
     3e0:      	mov	w25, w20
     3e4:      	cmp	w19, w25
     3e8:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     3ec:      	add	w8, w25, w19
     3f0:      	add	x9, sp, #0x140
     3f4:      	add	x1, sp, #0x140
     3f8:      	mov	x0, x21
     3fc:      	lsr	w8, w8, #1
     400:      	str	w8, [sp, #0x140]
     404:      	mov	w8, #0x1                // =1
     408:      	blr	x8
     40c:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     410:      	ldrh	w8, [x0]
     414:      	ldr	w20, [sp, #0x140]
     418:      	cmp	w8, w24
     41c:      	b.hi	0x428 <perf_unwind_native+0x428>
     420:      	add	w19, w20, #0x1
     424:      	mov	w20, w25
     428:      	cmp	w19, w20
     42c:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     430:      	add	w8, w20, w19
     434:      	add	x9, sp, #0x140
     438:      	add	x1, sp, #0x140
     43c:      	mov	x0, x21
     440:      	lsr	w8, w8, #1
     444:      	str	w8, [sp, #0x140]
     448:      	mov	w8, #0x1                // =1
     44c:      	blr	x8
     450:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     454:      	ldrh	w8, [x0]
     458:      	ldr	w25, [sp, #0x140]
     45c:      	cmp	w8, w24
     460:      	b.hi	0x46c <perf_unwind_native+0x46c>
     464:      	add	w19, w25, #0x1
     468:      	mov	w25, w20
     46c:      	cmp	w19, w25
     470:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     474:      	add	w8, w25, w19
     478:      	add	x9, sp, #0x140
     47c:      	add	x1, sp, #0x140
     480:      	mov	x0, x21
     484:      	lsr	w8, w8, #1
     488:      	str	w8, [sp, #0x140]
     48c:      	mov	w8, #0x1                // =1
     490:      	blr	x8
     494:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     498:      	ldrh	w8, [x0]
     49c:      	ldr	w20, [sp, #0x140]
     4a0:      	cmp	w8, w24
     4a4:      	b.hi	0x4b0 <perf_unwind_native+0x4b0>
     4a8:      	add	w19, w20, #0x1
     4ac:      	mov	w20, w25
     4b0:      	cmp	w19, w20
     4b4:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     4b8:      	add	w8, w20, w19
     4bc:      	add	x9, sp, #0x140
     4c0:      	add	x1, sp, #0x140
     4c4:      	mov	x0, x21
     4c8:      	lsr	w8, w8, #1
     4cc:      	str	w8, [sp, #0x140]
     4d0:      	mov	w8, #0x1                // =1
     4d4:      	blr	x8
     4d8:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     4dc:      	ldrh	w8, [x0]
     4e0:      	ldr	w25, [sp, #0x140]
     4e4:      	cmp	w8, w24
     4e8:      	b.hi	0x4f4 <perf_unwind_native+0x4f4>
     4ec:      	add	w19, w25, #0x1
     4f0:      	mov	w25, w20
     4f4:      	cmp	w19, w25
     4f8:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     4fc:      	add	w8, w25, w19
     500:      	add	x9, sp, #0x140
     504:      	add	x1, sp, #0x140
     508:      	mov	x0, x21
     50c:      	lsr	w8, w8, #1
     510:      	str	w8, [sp, #0x140]
     514:      	mov	w8, #0x1                // =1
     518:      	blr	x8
     51c:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     520:      	ldrh	w8, [x0]
     524:      	ldr	w20, [sp, #0x140]
     528:      	cmp	w8, w24
     52c:      	b.hi	0x538 <perf_unwind_native+0x538>
     530:      	add	w19, w20, #0x1
     534:      	mov	w20, w25
     538:      	cmp	w19, w20
     53c:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     540:      	add	w8, w20, w19
     544:      	add	x9, sp, #0x140
     548:      	add	x1, sp, #0x140
     54c:      	mov	x0, x21
     550:      	lsr	w8, w8, #1
     554:      	str	w8, [sp, #0x140]
     558:      	mov	w8, #0x1                // =1
     55c:      	blr	x8
     560:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     564:      	ldrh	w8, [x0]
     568:      	ldr	w25, [sp, #0x140]
     56c:      	cmp	w8, w24
     570:      	b.hi	0x57c <perf_unwind_native+0x57c>
     574:      	add	w19, w25, #0x1
     578:      	mov	w25, w20
     57c:      	cmp	w19, w25
     580:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     584:      	add	w8, w25, w19
     588:      	add	x9, sp, #0x140
     58c:      	add	x1, sp, #0x140
     590:      	mov	x0, x21
     594:      	lsr	w8, w8, #1
     598:      	str	w8, [sp, #0x140]
     59c:      	mov	w8, #0x1                // =1
     5a0:      	blr	x8
     5a4:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     5a8:      	ldrh	w8, [x0]
     5ac:      	ldr	w20, [sp, #0x140]
     5b0:      	cmp	w8, w24
     5b4:      	b.hi	0x5c0 <perf_unwind_native+0x5c0>
     5b8:      	add	w19, w20, #0x1
     5bc:      	mov	w20, w25
     5c0:      	cmp	w19, w20
     5c4:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     5c8:      	add	w8, w20, w19
     5cc:      	add	x9, sp, #0x140
     5d0:      	add	x1, sp, #0x140
     5d4:      	mov	x0, x21
     5d8:      	lsr	w8, w8, #1
     5dc:      	str	w8, [sp, #0x140]
     5e0:      	mov	w8, #0x1                // =1
     5e4:      	blr	x8
     5e8:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     5ec:      	ldrh	w8, [x0]
     5f0:      	ldr	w25, [sp, #0x140]
     5f4:      	cmp	w8, w24
     5f8:      	b.hi	0x604 <perf_unwind_native+0x604>
     5fc:      	add	w19, w25, #0x1
     600:      	mov	w25, w20
     604:      	cmp	w19, w25
     608:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     60c:      	add	w8, w25, w19
     610:      	add	x9, sp, #0x140
     614:      	add	x1, sp, #0x140
     618:      	mov	x0, x21
     61c:      	lsr	w8, w8, #1
     620:      	str	w8, [sp, #0x140]
     624:      	mov	w8, #0x1                // =1
     628:      	blr	x8
     62c:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     630:      	ldrh	w8, [x0]
     634:      	ldr	w20, [sp, #0x140]
     638:      	cmp	w8, w24
     63c:      	b.hi	0x648 <perf_unwind_native+0x648>
     640:      	add	w19, w20, #0x1
     644:      	mov	w20, w25
     648:      	cmp	w19, w20
     64c:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     650:      	add	w8, w20, w19
     654:      	add	x9, sp, #0x140
     658:      	add	x1, sp, #0x140
     65c:      	mov	x0, x21
     660:      	lsr	w8, w8, #1
     664:      	str	w8, [sp, #0x140]
     668:      	mov	w8, #0x1                // =1
     66c:      	blr	x8
     670:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     674:      	ldrh	w8, [x0]
     678:      	ldr	w25, [sp, #0x140]
     67c:      	cmp	w8, w24
     680:      	b.hi	0x68c <perf_unwind_native+0x68c>
     684:      	add	w19, w25, #0x1
     688:      	mov	w25, w20
     68c:      	cmp	w19, w25
     690:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     694:      	add	w8, w25, w19
     698:      	add	x9, sp, #0x140
     69c:      	add	x1, sp, #0x140
     6a0:      	mov	x0, x21
     6a4:      	lsr	w8, w8, #1
     6a8:      	str	w8, [sp, #0x140]
     6ac:      	mov	w8, #0x1                // =1
     6b0:      	blr	x8
     6b4:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     6b8:      	ldrh	w8, [x0]
     6bc:      	ldr	w20, [sp, #0x140]
     6c0:      	cmp	w8, w24
     6c4:      	b.hi	0x6d0 <perf_unwind_native+0x6d0>
     6c8:      	add	w19, w20, #0x1
     6cc:      	mov	w20, w25
     6d0:      	cmp	w19, w20
     6d4:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     6d8:      	add	w8, w20, w19
     6dc:      	add	x9, sp, #0x140
     6e0:      	add	x1, sp, #0x140
     6e4:      	mov	x0, x21
     6e8:      	lsr	w8, w8, #1
     6ec:      	str	w8, [sp, #0x140]
     6f0:      	mov	w8, #0x1                // =1
     6f4:      	blr	x8
     6f8:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     6fc:      	ldrh	w8, [x0]
     700:      	ldr	w25, [sp, #0x140]
     704:      	cmp	w8, w24
     708:      	b.hi	0x714 <perf_unwind_native+0x714>
     70c:      	add	w19, w25, #0x1
     710:      	mov	w25, w20
     714:      	cmp	w19, w25
     718:      	b.hs	0x7bc <perf_unwind_native+0x7bc>
     71c:      	add	w8, w25, w19
     720:      	add	x9, sp, #0x140
     724:      	add	x1, sp, #0x140
     728:      	mov	x0, x21
     72c:      	lsr	w8, w8, #1
     730:      	str	w8, [sp, #0x140]
     734:      	mov	w8, #0x1                // =1
     738:      	blr	x8
     73c:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     740:      	ldrh	w8, [x0]
     744:      	ldr	w20, [sp, #0x140]
     748:      	cmp	w8, w24
     74c:      	b.hi	0x758 <perf_unwind_native+0x758>
     750:      	add	w19, w20, #0x1
     754:      	mov	w20, w25
     758:      	cmp	w19, w20
     75c:      	b.hs	0x7c0 <perf_unwind_native+0x7c0>
     760:      	add	w8, w20, w19
     764:      	add	x9, sp, #0x140
     768:      	add	x1, sp, #0x140
     76c:      	mov	x0, x21
     770:      	lsr	w8, w8, #1
     774:      	str	w8, [sp, #0x140]
     778:      	mov	w8, #0x1                // =1
     77c:      	blr	x8
     780:      	cbz	x0, 0x1478 <perf_unwind_native+0x1478>
     784:      	ldrh	w9, [x0]
     788:      	ldr	w8, [sp, #0x140]
     78c:      	cmp	w9, w24
     790:      	b.hi	0x79c <perf_unwind_native+0x79c>
     794:      	add	w19, w8, #0x1
     798:      	mov	w8, w20
     79c:      	adrp	x24, 0x0 <perf_unwind_native>
     7a0:      	adrp	x25, 0x0 <perf_unwind_native>
     7a4:      	cmp	w19, w8
     7a8:      	ldr	x24, [x24]
     7ac:      	ldr	x25, [x25]
     7b0:      	mov	w20, w8
     7b4:      	b.hs	0x7d0 <perf_unwind_native+0x7d0>
     7b8:      	b	0x1488 <perf_unwind_native+0x1488>
     7bc:      	mov	w20, w25
     7c0:      	adrp	x24, 0x0 <perf_unwind_native>
     7c4:      	adrp	x25, 0x0 <perf_unwind_native>
     7c8:      	ldr	x24, [x24]
     7cc:      	ldr	x25, [x25]
     7d0:      	mov	w19, w20
     7d4:      	cbz	w20, 0x1488 <perf_unwind_native+0x1488>
     7d8:      	sub	w8, w19, #0x1
     7dc:      	add	x9, sp, #0x13c
     7e0:      	add	x1, sp, #0x13c
     7e4:      	str	w8, [sp, #0x13c]
     7e8:      	mov	w8, #0x1                // =1
     7ec:      	mov	x0, x21
     7f0:      	blr	x8
     7f4:      	cbz	x0, 0x1554 <perf_unwind_native+0x1554>
     7f8:      	ldr	w8, [x24]
     7fc:      	cbnz	w8, 0xf1c <perf_unwind_native+0xf1c>
     800:      	ldrh	w9, [x0]
     804:      	and	w8, w23, #0xffff
     808:      	ldr	w10, [x29]
     80c:      	sub	w8, w8, w9
     810:      	ldr	w9, [sp, #0x13c]
     814:      	add	w11, w8, #0x10, lsl #12 // =0x10000
     818:      	cmp	w9, w10
     81c:      	mov	w9, #0x8001             // =32769
     820:      	csel	w21, w11, w8, lo
     824:      	ldrh	w8, [x0, #0x2]
     828:      	cmp	w8, w9
     82c:      	str	w8, [sp, #0x138]
     830:      	b.eq	0x8a0 <perf_unwind_native+0x8a0>
     834:      	ldr	x23, [sp, #0x20]
     838:      	cmp	w8, #0x8, lsl #12       // =0x8000
     83c:      	b.eq	0x15e8 <perf_unwind_native+0x15e8>
     840:      	tbnz	w8, #0xf, 0x8f0 <perf_unwind_native+0x8f0>
     844:      	adrp	x0, 0x0 <perf_unwind_native>
     848:      	mov	w8, #0x1                // =1
     84c:      	add	x9, sp, #0x138
     850:      	ldr	x0, [x0]
     854:      	add	x1, sp, #0x138
     858:      	blr	x8
     85c:      	cbz	x0, 0x15fc <perf_unwind_native+0x15fc>
     860:      	ldr	w20, [x0, #0x4]
     864:      	ldrb	w8, [x0, #0x2]
     868:      	mov	x19, x0
     86c:      	cbz	w8, 0xa04 <perf_unwind_native+0xa04>
     870:      	ldr	w9, [x24]
     874:      	cbnz	w9, 0x1154 <perf_unwind_native+0x1154>
     878:      	and	w9, w8, #0x7f
     87c:      	cmp	w21, w9
     880:      	b.lt	0xa04 <perf_unwind_native+0xa04>
     884:      	tbnz	w8, #0x7, 0x9f4 <perf_unwind_native+0x9f4>
     888:      	mov	w8, #0x8                // =8
     88c:      	add	w20, w8, w20
     890:      	ldr	w8, [x24]
     894:      	cbz	w8, 0xa04 <perf_unwind_native+0xa04>
     898:      	b	0x1230 <perf_unwind_native+0x1230>
     89c:      	nop
     8a0:      	mov	w8, #0x7                // =7
     8a4:      	add	x9, sp, #0x19c
     8a8:      	add	x1, sp, #0x19c
     8ac:      	str	w8, [sp, #0x19c]
     8b0:      	mov	w8, #0x1                // =1
     8b4:      	mov	x0, x25
     8b8:      	blr	x8
     8bc:      	cbz	x0, 0x8dc <perf_unwind_native+0x8dc>
     8c0:      	ldr	x8, [x0]
     8c4:      	ldr	x23, [sp, #0x20]
     8c8:      	add	x8, x8, #0x1
     8cc:      	str	x8, [x0]
     8d0:      	ldr	w8, [sp, #0x138]
     8d4:      	tbz	w8, #0xf, 0x844 <perf_unwind_native+0x844>
     8d8:      	b	0x8f0 <perf_unwind_native+0x8f0>
     8dc:      	ldr	w8, [x24]
     8e0:      	ldr	x23, [sp, #0x20]
     8e4:      	cbnz	w8, 0x11dc <perf_unwind_native+0x11dc>
     8e8:      	ldr	w8, [sp, #0x138]
     8ec:      	tbz	w8, #0xf, 0x844 <perf_unwind_native+0x844>
     8f0:      	and	w8, w8, #0xffff7fff
     8f4:      	cmp	w8, #0x3
     8f8:      	b.eq	0x948 <perf_unwind_native+0x948>
     8fc:      	cmp	w8, #0x4
     900:      	b.ne	0x1678 <perf_unwind_native+0x1678>
     904:      	ldr	x10, [sp, #0x18]
     908:      	mov	w9, #0x70               // =112
     90c:      	add	x11, sp, #0x140
     910:      	mov	w12, #0x10              // =16
     914:      	ldr	x8, [x10]
     918:      	add	x0, sp, #0x140
     91c:      	mov	w1, #0x10               // =16
     920:      	ldr	x2, [x10]
     924:      	blr	x9
     928:      	cbnz	x0, 0x1808 <perf_unwind_native+0x1808>
     92c:      	ldr	x8, [x22, #0xee0]
     930:      	add	x8, x8, #0x10
     934:      	str	x8, [x22, #0xed8]
     938:      	ldp	x8, x9, [sp, #0x140]
     93c:      	str	x8, [x22, #0xee0]
     940:      	str	x9, [x22, #0xed0]
     944:      	b	0xc70 <perf_unwind_native+0xc70>
     948:      	ldr	x10, [sp, #0x8]
     94c:      	mov	w9, #0x70               // =112
     950:      	add	x11, sp, #0x28
     954:      	mov	w12, #0x110             // =272
     958:      	ldr	x8, [x10]
     95c:      	add	x0, sp, #0x28
     960:      	mov	w1, #0x110              // =272
     964:      	add	x8, x8, #0x138
     968:      	ldr	x8, [x10]
     96c:      	add	x2, x8, #0x138
     970:      	blr	x9
     974:      	cbnz	x0, 0x1808 <perf_unwind_native+0x1808>
     978:      	ldp	x9, x8, [sp, #0x120]
     97c:      	str	x9, [x22, #0xed8]
     980:      	ldp	x9, x10, [sp, #0x110]
     984:      	str	x9, [x22, #0xee0]
     988:      	adrp	x9, 0x0 <perf_unwind_native>
     98c:      	ldr	x9, [x9]
     990:      	strh	wzr, [x22, #0xf20]
     994:      	ldr	x9, [x9]
     998:      	and	x8, x9, x8
     99c:      	and	x9, x10, x9
     9a0:      	str	x8, [x22, #0xed0]
     9a4:      	ldr	x8, [sp, #0xd8]
     9a8:      	str	x9, [x22, #0xee8]
     9ac:      	ldr	x9, [sp, #0x108]
     9b0:      	str	x8, [x22, #0xef0]
     9b4:      	ldr	w8, [x24]
     9b8:      	str	x9, [x22, #0xef8]
     9bc:      	cbz	w8, 0xc78 <perf_unwind_native+0xc78>
     9c0:      	adrp	x9, 0x0 <perf_unwind_native>
     9c4:      	add	x9, x9, #0x0
     9c8:      	mov	w10, #0xe               // =14
     9cc:      	ldr	x8, [x9]
     9d0:      	add	x0, sp, #0x140
     9d4:      	mov	w1, #0xe                // =14
     9d8:      	str	x8, [sp, #0x140]
     9dc:      	ldur	x8, [x9, #0x6]
     9e0:      	add	x9, sp, #0x140
     9e4:      	stur	x8, [x9, #0x6]
     9e8:      	mov	w8, #0x6                // =6
     9ec:      	blr	x8
     9f0:      	b	0xc78 <perf_unwind_native+0xc78>
     9f4:      	mov	w8, #-0x8               // =-8
     9f8:      	add	w20, w8, w20
     9fc:      	ldr	w8, [x24]
     a00:      	cbnz	w8, 0x1230 <perf_unwind_native+0x1230>
     a04:      	ldrsb	w9, [x19]
     a08:      	mov	w8, w20
     a0c:      	tbnz	w9, #0x1f, 0xa3c <perf_unwind_native+0xa3c>
     a10:      	and	w9, w9, #0xff
     a14:      	mov	x21, xzr
     a18:      	and	w10, w9, #0x7f
     a1c:      	cmp	w10, #0x2
     a20:      	b.gt	0xa54 <perf_unwind_native+0xa54>
     a24:      	cmp	w10, #0x1
     a28:      	b.eq	0xaf4 <perf_unwind_native+0xaf4>
     a2c:      	ldr	x11, [sp, #0x8]
     a30:      	cmp	w10, #0x2
     a34:      	b.eq	0xaf0 <perf_unwind_native+0xaf0>
     a38:      	b	0xb40 <perf_unwind_native+0xb40>
     a3c:      	and	w8, w20, #0xfffffff8
     a40:      	and	w9, w9, #0xff
     a44:      	mov	x21, xzr
     a48:      	and	w10, w9, #0x7f
     a4c:      	cmp	w10, #0x2
     a50:      	b.le	0xa24 <perf_unwind_native+0xa24>
     a54:      	ldr	x11, [sp, #0x18]
     a58:      	cmp	w10, #0x3
     a5c:      	b.eq	0xaf0 <perf_unwind_native+0xaf0>
     a60:      	cmp	w10, #0x4
     a64:      	b.ne	0xb40 <perf_unwind_native+0xb40>
     a68:      	ldr	w8, [x24]
     a6c:      	cbnz	w8, 0x1354 <perf_unwind_native+0x1354>
     a70:      	ldr	x21, [x22, #0xee8]
     a74:      	cbnz	x21, 0xb40 <perf_unwind_native+0xb40>
     a78:      	mov	w8, #0x3c               // =60
     a7c:      	add	x9, sp, #0x180
     a80:      	add	x1, sp, #0x180
     a84:      	str	w8, [sp, #0x180]
     a88:      	mov	w8, #0x1                // =1
     a8c:      	mov	x0, x25
     a90:      	blr	x8
     a94:      	cbz	x0, 0xe3c <perf_unwind_native+0xe3c>
     a98:      	ldr	x8, [x0]
     a9c:      	add	x8, x8, #0x1
     aa0:      	str	x8, [x0]
     aa4:      	ldr	w8, [x24]
     aa8:      	cbz	w8, 0xb24 <perf_unwind_native+0xb24>
     aac:      	mov	w8, #0xa                // =10
     ab0:      	adrp	x10, 0x0 <perf_unwind_native>
     ab4:      	add	x10, x10, #0x0
     ab8:      	strh	w8, [sp, #0x168]
     abc:      	ldp	x8, x9, [x10, #0x10]
     ac0:      	add	x0, sp, #0x140
     ac4:      	mov	w1, #0x2a               // =42
     ac8:      	stp	x8, x9, [sp, #0x150]
     acc:      	ldr	x8, [x10, #0x20]
     ad0:      	str	x8, [sp, #0x160]
     ad4:      	ldp	x9, x8, [x10]
     ad8:      	mov	w10, #0x2a              // =42
     adc:      	stp	x9, x8, [sp, #0x140]
     ae0:      	mov	w8, #0x6                // =6
     ae4:      	add	x9, sp, #0x140
     ae8:      	ldr	x2, [x23]
     aec:      	b	0x1428 <perf_unwind_native+0x1428>
     af0:      	ldr	x21, [x11]
     af4:      	add	x21, x21, w8, sxtw
     af8:      	tbz	w9, #0x7, 0xb40 <perf_unwind_native+0xb40>
     afc:      	mov	w8, #0x70               // =112
     b00:      	add	x9, sp, #0x180
     b04:      	mov	w10, #0x8               // =8
     b08:      	add	x0, sp, #0x180
     b0c:      	mov	w1, #0x8                // =8
     b10:      	mov	x2, x21
     b14:      	blr	x8
     b18:      	cbz	x0, 0xb2c <perf_unwind_native+0xb2c>
     b1c:      	ldr	w8, [x24]
     b20:      	cbnz	w8, 0x13e4 <perf_unwind_native+0x13e4>
     b24:      	mov	x21, xzr
     b28:      	b	0xb40 <perf_unwind_native+0xb40>
     b2c:      	ldr	x9, [sp, #0x180]
     b30:      	ubfiz	w8, w20, #3, #3
     b34:      	add	x21, x9, x8
     b38:      	nop
     b3c:      	nop
     b40:      	ldrb	w10, [x19, #0x1]
     b44:      	ldr	w20, [x19, #0x8]
     b48:      	sxtb	w8, w10
     b4c:      	and	w9, w20, #0xfffffff8
     b50:      	and	w10, w10, #0x7f
     b54:      	cmp	w8, #0x0
     b58:      	csel	w9, w20, w9, ge
     b5c:      	cmp	w10, #0x2
     b60:      	b.gt	0xb80 <perf_unwind_native+0xb80>
     b64:      	cmp	w10, #0x1
     b68:      	mov	x11, x21
     b6c:      	b.eq	0xbac <perf_unwind_native+0xbac>
     b70:      	ldr	x11, [sp, #0x8]
     b74:      	cmp	w10, #0x2
     b78:      	b.eq	0xba8 <perf_unwind_native+0xba8>
     b7c:      	b	0x1808 <perf_unwind_native+0x1808>
     b80:      	ldr	x11, [sp, #0x18]
     b84:      	cmp	w10, #0x3
     b88:      	b.eq	0xba8 <perf_unwind_native+0xba8>
     b8c:      	cmp	w10, #0x4
     b90:      	b.ne	0x1808 <perf_unwind_native+0x1808>
     b94:      	ldr	w8, [x24]
     b98:      	cbnz	w8, 0x126c <perf_unwind_native+0x126c>
     b9c:      	ldr	x29, [x22, #0xee8]
     ba0:      	cbnz	x29, 0xbe4 <perf_unwind_native+0xbe4>
     ba4:      	b	0x1758 <perf_unwind_native+0x1758>
     ba8:      	ldr	x11, [x11]
     bac:      	add	x29, x11, w9, sxtw
     bb0:      	tbz	w8, #0x1f, 0xbe0 <perf_unwind_native+0xbe0>
     bb4:      	mov	w8, #0x70               // =112
     bb8:      	add	x9, sp, #0x180
     bbc:      	mov	w10, #0x8               // =8
     bc0:      	add	x0, sp, #0x180
     bc4:      	mov	w1, #0x8                // =8
     bc8:      	mov	x2, x29
     bcc:      	blr	x8
     bd0:      	cbnz	x0, 0x1704 <perf_unwind_native+0x1704>
     bd4:      	ldr	x9, [sp, #0x180]
     bd8:      	ubfiz	x8, x20, #3, #3
     bdc:      	add	x29, x9, x8
     be0:      	cbz	x29, 0x1808 <perf_unwind_native+0x1808>
     be4:      	ldrb	w8, [x19, #0x1]
     be8:      	cmp	w8, #0x4
     bec:      	b.ne	0xc00 <perf_unwind_native+0xc00>
     bf0:      	ldrb	w9, [x22, #0xf21]
     bf4:      	mov	x8, x29
     bf8:      	cbz	w9, 0xc28 <perf_unwind_native+0xc28>
     bfc:      	b	0x16a4 <perf_unwind_native+0x16a4>
     c00:      	ldr	w8, [x24]
     c04:      	cbnz	w8, 0x11a4 <perf_unwind_native+0x11a4>
     c08:      	mov	w8, #0x70               // =112
     c0c:      	mov	w9, #0x8                // =8
     c10:      	mov	x0, x23
     c14:      	mov	w1, #0x8                // =8
     c18:      	mov	x2, x29
     c1c:      	blr	x8
     c20:      	ldr	x8, [x23]
     c24:      	cbnz	x0, 0x16dc <perf_unwind_native+0x16dc>
     c28:      	adrp	x9, 0x0 <perf_unwind_native>
     c2c:      	ldr	x9, [x9]
     c30:      	ldr	x9, [x9]
     c34:      	and	x8, x9, x8
     c38:      	str	x8, [x23]
     c3c:      	ldr	w8, [x19, #0x8]
     c40:      	cmp	w8, #0x8
     c44:      	b.ne	0xc6c <perf_unwind_native+0xc6c>
     c48:      	ldrb	w8, [x19, #0x1]
     c4c:      	cmp	w8, #0x4
     c50:      	b.eq	0xc6c <perf_unwind_native+0xc6c>
     c54:      	ldr	x0, [sp, #0x18]
     c58:      	sub	x2, x29, #0x8
     c5c:      	mov	w8, #0x70               // =112
     c60:      	mov	w9, #0x8                // =8
     c64:      	mov	w1, #0x8                // =8
     c68:      	blr	x8
     c6c:      	str	x21, [x22, #0xed8]
     c70:      	mov	w8, #0x101              // =257
     c74:      	strh	w8, [x22, #0xf20]
     c78:      	mov	w8, #0x6                // =6
     c7c:      	add	x9, sp, #0x180
     c80:      	add	x1, sp, #0x180
     c84:      	str	w8, [sp, #0x180]
     c88:      	mov	w8, #0x1                // =1
     c8c:      	mov	x0, x25
     c90:      	blr	x8
     c94:      	cbz	x0, 0xd00 <perf_unwind_native+0xd00>
     c98:      	ldr	x8, [x0]
     c9c:      	add	x8, x8, #0x1
     ca0:      	str	x8, [x0]
     ca4:      	ldr	w8, [x24]
     ca8:      	cbz	w8, 0xd08 <perf_unwind_native+0xd08>
     cac:      	adrp	x10, 0x0 <perf_unwind_native>
     cb0:      	add	x10, x10, #0x0
     cb4:      	add	x0, sp, #0x28
     cb8:      	ldp	x8, x9, [x10]
     cbc:      	mov	w1, #0x1d               // =29
     cc0:      	stp	x8, x9, [sp, #0x28]
     cc4:      	ldr	x8, [x10, #0x10]
     cc8:      	add	x9, sp, #0x28
     ccc:      	str	x8, [sp, #0x38]
     cd0:      	ldur	x8, [x10, #0x15]
     cd4:      	mov	w10, #0x1d              // =29
     cd8:      	stur	x8, [sp, #0x3d]
     cdc:      	mov	w8, #0x6                // =6
     ce0:      	ldr	x9, [sp, #0x8]
     ce4:      	ldr	x2, [x23]
     ce8:      	ldr	x3, [x9]
     cec:      	ldr	x9, [sp, #0x18]
     cf0:      	ldr	x4, [x9]
     cf4:      	blr	x8
     cf8:      	b	0xd08 <perf_unwind_native+0xd08>
     cfc:      	nop
     d00:      	ldr	w8, [x24]
     d04:      	cbnz	w8, 0x1100 <perf_unwind_native+0x1100>
     d08:      	ldr	x21, [x23]
     d0c:      	ldr	w8, [x24]
     d10:      	cbz	x21, 0x1568 <perf_unwind_native+0x1568>
     d14:      	cbnz	w8, 0xf78 <perf_unwind_native+0xf78>
     d18:      	lsr	x8, x21, #56
     d1c:      	cbnz	x8, 0x1580 <perf_unwind_native+0x1580>
     d20:      	cmp	x21, #0xfff
     d24:      	b.ls	0x159c <perf_unwind_native+0x159c>
     d28:      	ldr	w8, [x22]
     d2c:      	mov	w9, #0x60               // =96
     d30:      	adrp	x0, 0x0 <perf_unwind_native>
     d34:      	add	x1, sp, #0x140
     d38:      	str	w9, [sp, #0x140]
     d3c:      	add	x9, sp, #0x140
     d40:      	rev	w8, w8
     d44:      	str	w8, [sp, #0x144]
     d48:      	rev	x8, x21
     d4c:      	str	x8, [sp, #0x148]
     d50:      	mov	w8, #0x1                // =1
     d54:      	ldr	x0, [x0]
     d58:      	blr	x8
     d5c:      	cbz	x0, 0x15b8 <perf_unwind_native+0x15b8>
     d60:      	ldr	x8, [x0, #0x8]
     d64:      	and	x9, x8, #0xffffffffffffff
     d68:      	lsr	x19, x8, #56
     d6c:      	str	x9, [x22, #0xf10]
     d70:      	ldr	x8, [x0]
     d74:      	str	x8, [x22, #0xf00]
     d78:      	sub	x8, x21, x9
     d7c:      	str	x8, [x22, #0xf08]
     d80:      	ldr	w8, [x24]
     d84:      	cbnz	w8, 0xfc8 <perf_unwind_native+0xfc8>
     d88:      	cmp	w19, #0x1
     d8c:      	b.ne	0xe24 <perf_unwind_native+0xe24>
     d90:      	ldr	x8, [x22, #0xf00]
     d94:      	adrp	x0, 0x0 <perf_unwind_native>
     d98:      	ldr	x19, [x22, #0xf08]
     d9c:      	add	x9, sp, #0x140
     da0:      	add	x1, sp, #0x140
     da4:      	mov	w20, #0x1               // =1
     da8:      	str	x8, [sp, #0x140]
     dac:      	mov	w8, #0x1                // =1
     db0:      	ldr	x0, [x0]
     db4:      	blr	x8
     db8:      	cbz	x0, 0xe20 <perf_unwind_native+0xe20>
     dbc:      	ldr	x8, [x0]
     dc0:      	cmp	x8, x19
     dc4:      	b.hi	0xdd4 <perf_unwind_native+0xdd4>
     dc8:      	ldr	x8, [x0, #0x8]
     dcc:      	cmp	x8, x19
     dd0:      	b.hs	0xdec <perf_unwind_native+0xdec>
     dd4:      	ldr	x8, [x0, #0x10]
     dd8:      	cmp	x8, x19
     ddc:      	b.hi	0xe0c <perf_unwind_native+0xe0c>
     de0:      	ldr	x8, [x0, #0x18]
     de4:      	cmp	x8, x19
     de8:      	b.lo	0xe0c <perf_unwind_native+0xe0c>
     dec:      	ldr	w8, [x24]
     df0:      	cbnz	w8, 0x12ac <perf_unwind_native+0x12ac>
     df4:      	ldrh	w8, [x0, #0x20]
     df8:      	ldr	w9, [x22, #0x1370]
     dfc:      	lsr	w8, w9, w8
     e00:      	tbz	w8, #0x0, 0x1300 <perf_unwind_native+0x1300>
     e04:      	ldr	w8, [x24]
     e08:      	cbnz	w8, 0x1394 <perf_unwind_native+0x1394>
     e0c:      	mov	w19, #0x1               // =1
     e10:      	ldr	w8, [sp, #0x1ac]
     e14:      	cmp	w19, #0x1
     e18:      	b.eq	0xe30 <perf_unwind_native+0xe30>
     e1c:      	b	0x15d4 <perf_unwind_native+0x15d4>
     e20:      	mov	w19, w20
     e24:      	ldr	w8, [sp, #0x1ac]
     e28:      	cmp	w19, #0x1
     e2c:      	b.ne	0x15d4 <perf_unwind_native+0x15d4>
     e30:      	subs	w19, w8, #0x1
     e34:      	b.ne	0x6c <perf_unwind_native+0x6c>
     e38:      	b	0x15dc <perf_unwind_native+0x15dc>
     e3c:      	ldr	w8, [x24]
     e40:      	cbz	w8, 0xb24 <perf_unwind_native+0xb24>
     e44:      	adrp	x10, 0x0 <perf_unwind_native>
     e48:      	add	x10, x10, #0x0
     e4c:      	add	x0, sp, #0x140
     e50:      	ldp	x8, x9, [x10, #0x10]
     e54:      	mov	w1, #0x2e               // =46
     e58:      	stp	x8, x9, [sp, #0x150]
     e5c:      	ldr	x8, [x10, #0x20]
     e60:      	add	x9, sp, #0x140
     e64:      	str	x8, [sp, #0x160]
     e68:      	ldur	x8, [x10, #0x26]
     e6c:      	stur	x8, [x9, #0x26]
     e70:      	ldp	x8, x9, [x10]
     e74:      	mov	w10, #0x2e              // =46
     e78:      	stp	x8, x9, [sp, #0x140]
     e7c:      	mov	w8, #0x6                // =6
     e80:      	add	x9, sp, #0x140
     e84:      	ldr	w2, [sp, #0x180]
     e88:      	blr	x8
     e8c:      	ldr	w8, [x24]
     e90:      	cbz	w8, 0xb24 <perf_unwind_native+0xb24>
     e94:      	b	0xaac <perf_unwind_native+0xaac>
     e98:      	adrp	x10, 0x0 <perf_unwind_native>
     e9c:      	add	x10, x10, #0x0
     ea0:      	ldr	w2, [x22, #0x2c0]
     ea4:      	add	x0, sp, #0x28
     ea8:      	ldp	x8, x9, [x10]
     eac:      	mov	w1, #0x1c               // =28
     eb0:      	stp	x8, x9, [sp, #0x28]
     eb4:      	ldr	x8, [x10, #0x10]
     eb8:      	add	x9, sp, #0x28
     ebc:      	mov	w10, #0x1c              // =28
     ec0:      	str	x8, [sp, #0x38]
     ec4:      	mov	w8, #0x3d3d             // =15677
     ec8:      	movk	w8, #0xa, lsl #16
     ecc:      	str	w8, [sp, #0x40]
     ed0:      	mov	w8, #0x6                // =6
     ed4:      	blr	x8
     ed8:      	b	0x74 <perf_unwind_native+0x74>
     edc:      	adrp	x10, 0x0 <perf_unwind_native>
     ee0:      	add	x10, x10, #0x0
     ee4:      	strb	wzr, [sp, #0x160]
     ee8:      	add	x0, sp, #0x140
     eec:      	ldp	x8, x9, [x10]
     ef0:      	mov	w1, #0x21               // =33
     ef4:      	stp	x8, x9, [sp, #0x140]
     ef8:      	ldp	x8, x9, [x10, #0x10]
     efc:      	mov	w10, #0x21              // =33
     f00:      	stp	x8, x9, [sp, #0x150]
     f04:      	mov	w8, #0x6                // =6
     f08:      	add	x9, sp, #0x140
     f0c:      	ldr	x2, [x22, #0xf00]
     f10:      	ldr	x3, [x22, #0xf08]
     f14:      	blr	x8
     f18:      	b	0x170 <perf_unwind_native+0x170>
     f1c:      	adrp	x10, 0x0 <perf_unwind_native>
     f20:      	add	x10, x10, #0x0
     f24:      	mov	x19, x0
     f28:      	ldp	x8, x9, [x10, #0x10]
     f2c:      	mov	w1, #0x2d               // =45
     f30:      	stp	x8, x9, [sp, #0x150]
     f34:      	ldr	x8, [x10, #0x20]
     f38:      	add	x9, sp, #0x140
     f3c:      	str	x8, [sp, #0x160]
     f40:      	ldur	x8, [x10, #0x25]
     f44:      	stur	x8, [x9, #0x25]
     f48:      	ldp	x8, x9, [x10]
     f4c:      	mov	w10, #0x2d              // =45
     f50:      	stp	x8, x9, [sp, #0x140]
     f54:      	mov	w8, #0x6                // =6
     f58:      	add	x9, sp, #0x140
     f5c:      	ldr	w2, [sp, #0x13c]
     f60:      	ldrh	w3, [x0]
     f64:      	ldrh	w4, [x0, #0x2]
     f68:      	add	x0, sp, #0x140
     f6c:      	blr	x8
     f70:      	mov	x0, x19
     f74:      	b	0x800 <perf_unwind_native+0x800>
     f78:      	adrp	x10, 0x0 <perf_unwind_native>
     f7c:      	add	x10, x10, #0x0
     f80:      	strb	wzr, [sp, #0x58]
     f84:      	add	x0, sp, #0x28
     f88:      	ldp	x8, x9, [x10, #0x10]
     f8c:      	mov	w1, #0x31               // =49
     f90:      	stp	x8, x9, [sp, #0x38]
     f94:      	ldp	x8, x9, [x10, #0x20]
     f98:      	stp	x8, x9, [sp, #0x48]
     f9c:      	ldp	x8, x9, [x10]
     fa0:      	mov	w10, #0x31              // =49
     fa4:      	stp	x8, x9, [sp, #0x28]
     fa8:      	mov	w8, #0x6                // =6
     fac:      	add	x9, sp, #0x28
     fb0:      	ldr	w2, [x22, #0x2c0]
     fb4:      	blr	x8
     fb8:      	ldr	x21, [x22, #0xed0]
     fbc:      	lsr	x8, x21, #56
     fc0:      	cbz	x8, 0xd20 <perf_unwind_native+0xd20>
     fc4:      	b	0x1580 <perf_unwind_native+0x1580>
     fc8:      	mov	w8, #0xa                // =10
     fcc:      	adrp	x10, 0x0 <perf_unwind_native>
     fd0:      	add	x10, x10, #0x0
     fd4:      	strh	w8, [sp, #0x58]
     fd8:      	ldp	x8, x9, [x10, #0x10]
     fdc:      	add	x0, sp, #0x28
     fe0:      	mov	w1, #0x32               // =50
     fe4:      	mov	x2, x21
     fe8:      	stp	x8, x9, [sp, #0x38]
     fec:      	ldp	x8, x9, [x10, #0x20]
     ff0:      	mov	w4, w19
     ff4:      	stp	x8, x9, [sp, #0x48]
     ff8:      	ldp	x8, x9, [x10]
     ffc:      	mov	w10, #0x32              // =50
    1000:      	stp	x8, x9, [sp, #0x28]
    1004:      	mov	w8, #0x6                // =6
    1008:      	add	x9, sp, #0x28
    100c:      	ldr	x3, [x22, #0xf00]
    1010:      	blr	x8
    1014:      	ldr	w8, [x24]
    1018:      	cbz	w8, 0xd88 <perf_unwind_native+0xd88>
    101c:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1020:      	add	x10, x10, #0x0
    1024:      	add	x0, sp, #0x28
    1028:      	ldp	x8, x9, [x10, #0x10]
    102c:      	mov	w1, #0x2f               // =47
    1030:      	stp	x8, x9, [sp, #0x38]
    1034:      	ldr	x8, [x10, #0x20]
    1038:      	str	x8, [sp, #0x48]
    103c:      	ldur	x8, [x10, #0x27]
    1040:      	stur	x8, [sp, #0x4f]
    1044:      	ldp	x8, x9, [x10]
    1048:      	mov	w10, #0x2f              // =47
    104c:      	stp	x8, x9, [sp, #0x28]
    1050:      	mov	w8, #0x6                // =6
    1054:      	add	x9, sp, #0x28
    1058:      	ldr	x2, [x22, #0xf10]
    105c:      	ldr	x3, [x22, #0xf08]
    1060:      	blr	x8
    1064:      	b	0xd88 <perf_unwind_native+0xd88>
    1068:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    106c:      	add	x10, x10, #0x0
    1070:      	add	x0, sp, #0x140
    1074:      	ldp	x8, x9, [x10, #0x10]
    1078:      	mov	w1, #0x30               // =48
    107c:      	mov	x2, x19
    1080:      	mov	x3, x25
    1084:      	stp	x8, x9, [sp, #0x150]
    1088:      	ldp	x8, x9, [x10, #0x20]
    108c:      	stp	x8, x9, [sp, #0x160]
    1090:      	ldp	x8, x9, [x10]
    1094:      	mov	w10, #0x30              // =48
    1098:      	stp	x8, x9, [sp, #0x140]
    109c:      	mov	w8, #0x6                // =6
    10a0:      	add	x9, sp, #0x140
    10a4:      	ldrh	w4, [x29, #0x6]
    10a8:      	blr	x8
    10ac:      	b	0x360 <perf_unwind_native+0x360>
    10b0:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    10b4:      	add	x10, x10, #0x0
    10b8:      	add	x0, sp, #0x28
    10bc:      	ldp	x8, x9, [x10, #0x10]
    10c0:      	mov	w1, #0x2e               // =46
    10c4:      	stp	x8, x9, [sp, #0x38]
    10c8:      	ldr	x8, [x10, #0x20]
    10cc:      	str	x8, [sp, #0x48]
    10d0:      	ldur	x8, [x10, #0x26]
    10d4:      	stur	x8, [sp, #0x4e]
    10d8:      	ldp	x8, x9, [x10]
    10dc:      	add	x10, sp, #0x28
    10e0:      	stp	x8, x9, [sp, #0x28]
    10e4:      	mov	w8, #0x6                // =6
    10e8:      	mov	w9, #0x2e               // =46
    10ec:      	ldr	w2, [sp, #0x140]
    10f0:      	blr	x8
    10f4:      	ldr	w8, [x24]
    10f8:      	cbz	w8, 0x108 <perf_unwind_native+0x108>
    10fc:      	b	0xa8 <perf_unwind_native+0xa8>
    1100:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1104:      	add	x10, x10, #0x0
    1108:      	add	x0, sp, #0x140
    110c:      	ldp	x8, x9, [x10, #0x10]
    1110:      	mov	w1, #0x2e               // =46
    1114:      	stp	x8, x9, [sp, #0x150]
    1118:      	ldr	x8, [x10, #0x20]
    111c:      	add	x9, sp, #0x140
    1120:      	str	x8, [sp, #0x160]
    1124:      	ldur	x8, [x10, #0x26]
    1128:      	stur	x8, [x9, #0x26]
    112c:      	ldp	x8, x9, [x10]
    1130:      	mov	w10, #0x2e              // =46
    1134:      	stp	x8, x9, [sp, #0x140]
    1138:      	mov	w8, #0x6                // =6
    113c:      	add	x9, sp, #0x140
    1140:      	ldr	w2, [sp, #0x180]
    1144:      	blr	x8
    1148:      	ldr	w8, [x24]
    114c:      	cbz	w8, 0xd08 <perf_unwind_native+0xd08>
    1150:      	b	0xcac <perf_unwind_native+0xcac>
    1154:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1158:      	add	x10, x10, #0x0
    115c:      	strb	wzr, [sp, #0x160]
    1160:      	add	x0, sp, #0x140
    1164:      	ldp	x8, x9, [x10]
    1168:      	mov	w1, #0x21               // =33
    116c:      	mov	w2, w21
    1170:      	stp	x8, x9, [sp, #0x140]
    1174:      	ldp	x8, x9, [x10, #0x10]
    1178:      	mov	w10, #0x21              // =33
    117c:      	stp	x8, x9, [sp, #0x150]
    1180:      	mov	w8, #0x6                // =6
    1184:      	add	x9, sp, #0x140
    1188:      	ldrb	w3, [x19, #0x2]
    118c:      	blr	x8
    1190:      	ldrb	w8, [x19, #0x2]
    1194:      	and	w9, w8, #0x7f
    1198:      	cmp	w21, w9
    119c:      	b.ge	0x884 <perf_unwind_native+0x884>
    11a0:      	b	0xa04 <perf_unwind_native+0xa04>
    11a4:      	adrp	x9, 0x1000 <perf_unwind_native+0x1000>
    11a8:      	add	x9, x9, #0x0
    11ac:      	mov	w10, #0xd               // =13
    11b0:      	ldr	x8, [x9]
    11b4:      	add	x0, sp, #0x140
    11b8:      	mov	w1, #0xd                // =13
    11bc:      	mov	x2, x29
    11c0:      	str	x8, [sp, #0x140]
    11c4:      	ldur	x8, [x9, #0x5]
    11c8:      	add	x9, sp, #0x140
    11cc:      	stur	x8, [x9, #0x5]
    11d0:      	mov	w8, #0x6                // =6
    11d4:      	blr	x8
    11d8:      	b	0xc08 <perf_unwind_native+0xc08>
    11dc:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    11e0:      	add	x10, x10, #0x0
    11e4:      	add	x0, sp, #0x140
    11e8:      	ldp	x8, x9, [x10, #0x10]
    11ec:      	mov	w1, #0x2e               // =46
    11f0:      	stp	x8, x9, [sp, #0x150]
    11f4:      	ldr	x8, [x10, #0x20]
    11f8:      	add	x9, sp, #0x140
    11fc:      	str	x8, [sp, #0x160]
    1200:      	ldur	x8, [x10, #0x26]
    1204:      	stur	x8, [x9, #0x26]
    1208:      	ldp	x8, x9, [x10]
    120c:      	mov	w10, #0x2e              // =46
    1210:      	stp	x8, x9, [sp, #0x140]
    1214:      	mov	w8, #0x6                // =6
    1218:      	add	x9, sp, #0x140
    121c:      	ldr	w2, [sp, #0x19c]
    1220:      	blr	x8
    1224:      	ldr	w8, [sp, #0x138]
    1228:      	tbz	w8, #0xf, 0x844 <perf_unwind_native+0x844>
    122c:      	b	0x8f0 <perf_unwind_native+0x8f0>
    1230:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1234:      	add	x10, x10, #0x0
    1238:      	strb	wzr, [sp, #0x160]
    123c:      	add	x0, sp, #0x140
    1240:      	ldp	x8, x9, [x10]
    1244:      	mov	w1, #0x21               // =33
    1248:      	stp	x8, x9, [sp, #0x140]
    124c:      	ldp	x8, x9, [x10, #0x10]
    1250:      	mov	w10, #0x21              // =33
    1254:      	stp	x8, x9, [sp, #0x150]
    1258:      	mov	w8, #0x6                // =6
    125c:      	add	x9, sp, #0x140
    1260:      	ldr	w2, [sp, #0x138]
    1264:      	blr	x8
    1268:      	b	0xa04 <perf_unwind_native+0xa04>
    126c:      	mov	w8, #0x726c             // =29292
    1270:      	add	x9, sp, #0x140
    1274:      	mov	w10, #0xc               // =12
    1278:      	add	x0, sp, #0x140
    127c:      	mov	w1, #0xc                // =12
    1280:      	movk	w8, #0xa, lsl #16
    1284:      	str	w8, [sp, #0x148]
    1288:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    128c:      	add	x8, x8, #0x0
    1290:      	ldr	x8, [x8]
    1294:      	str	x8, [sp, #0x140]
    1298:      	mov	w8, #0x6                // =6
    129c:      	blr	x8
    12a0:      	ldr	x29, [x22, #0xee8]
    12a4:      	cbnz	x29, 0xbe4 <perf_unwind_native+0xbe4>
    12a8:      	b	0x1758 <perf_unwind_native+0x1758>
    12ac:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    12b0:      	add	x10, x10, #0x0
    12b4:      	mov	x19, x0
    12b8:      	ldp	x8, x9, [x10]
    12bc:      	mov	w1, #0x1e               // =30
    12c0:      	stp	x8, x9, [sp, #0x28]
    12c4:      	ldr	x8, [x10, #0x10]
    12c8:      	add	x9, sp, #0x28
    12cc:      	str	x8, [sp, #0x38]
    12d0:      	ldur	x8, [x10, #0x16]
    12d4:      	mov	w10, #0x1e              // =30
    12d8:      	stur	x8, [sp, #0x3e]
    12dc:      	mov	w8, #0x6                // =6
    12e0:      	ldrh	w2, [x0, #0x20]
    12e4:      	add	x0, sp, #0x28
    12e8:      	blr	x8
    12ec:      	mov	x0, x19
    12f0:      	ldrh	w8, [x19, #0x20]
    12f4:      	ldr	w9, [x22, #0x1370]
    12f8:      	lsr	w8, w9, w8
    12fc:      	tbnz	w8, #0x0, 0xe04 <perf_unwind_native+0xe04>
    1300:      	str	wzr, [sp, #0x180]
    1304:      	mov	w8, #0x1                // =1
    1308:      	add	x9, sp, #0x180
    130c:      	mov	x19, x0
    1310:      	add	x1, sp, #0x180
    1314:      	mov	x0, x25
    1318:      	blr	x8
    131c:      	cbz	x0, 0x1334 <perf_unwind_native+0x1334>
    1320:      	ldr	x8, [x0]
    1324:      	add	x8, x8, #0x1
    1328:      	str	x8, [x0]
    132c:      	mov	x8, x19
    1330:      	b	0x1340 <perf_unwind_native+0x1340>
    1334:      	ldr	w9, [x24]
    1338:      	mov	x8, x19
    133c:      	cbnz	w9, 0x1430 <perf_unwind_native+0x1430>
    1340:      	ldrh	w19, [x8, #0x20]
    1344:      	ldr	w8, [sp, #0x1ac]
    1348:      	cmp	w19, #0x1
    134c:      	b.eq	0xe30 <perf_unwind_native+0xe30>
    1350:      	b	0x15d4 <perf_unwind_native+0x15d4>
    1354:      	mov	w8, #0x726c             // =29292
    1358:      	add	x9, sp, #0x140
    135c:      	mov	w10, #0xc               // =12
    1360:      	add	x0, sp, #0x140
    1364:      	mov	w1, #0xc                // =12
    1368:      	movk	w8, #0xa, lsl #16
    136c:      	str	w8, [sp, #0x148]
    1370:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1374:      	add	x8, x8, #0x0
    1378:      	ldr	x8, [x8]
    137c:      	str	x8, [sp, #0x140]
    1380:      	mov	w8, #0x6                // =6
    1384:      	blr	x8
    1388:      	ldr	x21, [x22, #0xee8]
    138c:      	cbnz	x21, 0xb40 <perf_unwind_native+0xb40>
    1390:      	b	0xa78 <perf_unwind_native+0xa78>
    1394:      	mov	w8, #0x656e             // =25966
    1398:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    139c:      	add	x10, x10, #0x0
    13a0:      	add	x0, sp, #0x28
    13a4:      	mov	w1, #0x1b               // =27
    13a8:      	movk	w8, #0xa, lsl #16
    13ac:      	stur	w8, [sp, #0x3f]
    13b0:      	ldp	x8, x9, [x10]
    13b4:      	stp	x8, x9, [sp, #0x28]
    13b8:      	ldr	x8, [x10, #0x10]
    13bc:      	add	x9, sp, #0x28
    13c0:      	mov	w10, #0x1b              // =27
    13c4:      	str	x8, [sp, #0x38]
    13c8:      	mov	w8, #0x6                // =6
    13cc:      	blr	x8
    13d0:      	mov	w19, #0x1               // =1
    13d4:      	ldr	w8, [sp, #0x1ac]
    13d8:      	cmp	w19, #0x1
    13dc:      	b.eq	0xe30 <perf_unwind_native+0xe30>
    13e0:      	b	0x15d4 <perf_unwind_native+0x15d4>
    13e4:      	mov	w8, #0x786c             // =30828
    13e8:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    13ec:      	add	x10, x10, #0x0
    13f0:      	add	x0, sp, #0x140
    13f4:      	mov	w1, #0x2c               // =44
    13f8:      	mov	x2, x21
    13fc:      	movk	w8, #0xa, lsl #16
    1400:      	str	w8, [sp, #0x168]
    1404:      	ldp	x8, x9, [x10, #0x10]
    1408:      	stp	x8, x9, [sp, #0x150]
    140c:      	ldr	x8, [x10, #0x20]
    1410:      	str	x8, [sp, #0x160]
    1414:      	ldp	x9, x8, [x10]
    1418:      	mov	w10, #0x2c              // =44
    141c:      	stp	x9, x8, [sp, #0x140]
    1420:      	mov	w8, #0x6                // =6
    1424:      	add	x9, sp, #0x140
    1428:      	blr	x8
    142c:      	b	0xb24 <perf_unwind_native+0xb24>
    1430:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1434:      	add	x10, x10, #0x0
    1438:      	add	x0, sp, #0x28
    143c:      	ldp	x8, x9, [x10, #0x10]
    1440:      	mov	w1, #0x2e               // =46
    1444:      	stp	x8, x9, [sp, #0x38]
    1448:      	ldr	x8, [x10, #0x20]
    144c:      	str	x8, [sp, #0x48]
    1450:      	ldur	x8, [x10, #0x26]
    1454:      	stur	x8, [sp, #0x4e]
    1458:      	ldp	x8, x9, [x10]
    145c:      	add	x10, sp, #0x28
    1460:      	stp	x8, x9, [sp, #0x28]
    1464:      	mov	w8, #0x6                // =6
    1468:      	mov	w9, #0x2e               // =46
    146c:      	ldr	w2, [sp, #0x180]
    1470:      	blr	x8
    1474:      	b	0x132c <perf_unwind_native+0x132c>
    1478:      	adrp	x24, 0x1000 <perf_unwind_native+0x1000>
    147c:      	adrp	x25, 0x1000 <perf_unwind_native+0x1000>
    1480:      	ldr	x24, [x24]
    1484:      	ldr	x25, [x25]
    1488:      	ldr	w8, [x24]
    148c:      	cbnz	w8, 0x19c4 <perf_unwind_native+0x19c4>
    1490:      	mov	w9, #0x9                // =9
    1494:      	mov	w8, #0xfa3              // =4003
    1498:      	mov	w19, wzr
    149c:      	str	w9, [x22, #0xf18]
    14a0:      	b	0x1888 <perf_unwind_native+0x1888>
    14a4:      	ldr	w8, [x24]
    14a8:      	cbnz	w8, 0x1a58 <perf_unwind_native+0x1a58>
    14ac:      	mov	w8, #0x2                // =2
    14b0:      	add	x9, sp, #0x140
    14b4:      	add	x1, sp, #0x140
    14b8:      	str	w8, [sp, #0x140]
    14bc:      	mov	w8, #0x1                // =1
    14c0:      	mov	x0, x25
    14c4:      	blr	x8
    14c8:      	cbz	x0, 0x1688 <perf_unwind_native+0x1688>
    14cc:      	ldr	x8, [x0]
    14d0:      	add	x8, x8, #0x1
    14d4:      	str	x8, [x0]
    14d8:      	ldr	w8, [x24]
    14dc:      	cbz	w8, 0x1690 <perf_unwind_native+0x1690>
    14e0:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    14e4:      	add	x8, x8, #0x0
    14e8:      	add	x0, sp, #0x28
    14ec:      	ldp	x9, x10, [x8]
    14f0:      	mov	w1, #0x1d               // =29
    14f4:      	stp	x9, x10, [sp, #0x28]
    14f8:      	ldr	x9, [x8, #0x10]
    14fc:      	ldur	x8, [x8, #0x15]
    1500:      	add	x10, sp, #0x28
    1504:      	str	x9, [sp, #0x38]
    1508:      	stur	x8, [sp, #0x3d]
    150c:      	mov	w8, #0x1d               // =29
    1510:      	mov	w9, #0x6                // =6
    1514:      	blr	x9
    1518:      	b	0x1690 <perf_unwind_native+0x1690>
    151c:      	ldr	w8, [x24]
    1520:      	cbnz	w8, 0x1a94 <perf_unwind_native+0x1a94>
    1524:      	mov	w9, #0x8                // =8
    1528:      	mov	w8, #0xfa0              // =4000
    152c:      	mov	w19, wzr
    1530:      	str	w9, [x22, #0xf18]
    1534:      	b	0x1888 <perf_unwind_native+0x1888>
    1538:      	ldr	w8, [x24]
    153c:      	cbnz	w8, 0x1ae4 <perf_unwind_native+0x1ae4>
    1540:      	mov	w9, #0x32               // =50
    1544:      	mov	w8, #0xfa2              // =4002
    1548:      	mov	w19, wzr
    154c:      	str	w9, [x22, #0xf18]
    1550:      	b	0x1888 <perf_unwind_native+0x1888>
    1554:      	mov	w9, #0xa                // =10
    1558:      	mov	w8, #0xfa4              // =4004
    155c:      	mov	w19, wzr
    1560:      	str	w9, [x22, #0xf18]
    1564:      	b	0x1888 <perf_unwind_native+0x1888>
    1568:      	cbnz	w8, 0x1b34 <perf_unwind_native+0x1b34>
    156c:      	mov	w8, #0x1                // =1
    1570:      	mov	w19, wzr
    1574:      	str	w8, [x22, #0xf18]
    1578:      	mov	w8, #0xfad              // =4013
    157c:      	b	0x1888 <perf_unwind_native+0x1888>
    1580:      	ldr	w8, [x24]
    1584:      	cbnz	w8, 0x1b74 <perf_unwind_native+0x1b74>
    1588:      	mov	w8, #0xb                // =11
    158c:      	mov	w19, wzr
    1590:      	str	w8, [x22, #0xf18]
    1594:      	mov	w8, #0xfab              // =4011
    1598:      	b	0x1888 <perf_unwind_native+0x1888>
    159c:      	ldr	w8, [x24]
    15a0:      	cbnz	w8, 0x1bb4 <perf_unwind_native+0x1bb4>
    15a4:      	mov	w8, #0x31               // =49
    15a8:      	mov	w19, wzr
    15ac:      	str	w8, [x22, #0xf18]
    15b0:      	mov	w8, #0xfae              // =4014
    15b4:      	b	0x1888 <perf_unwind_native+0x1888>
    15b8:      	ldr	w8, [x24]
    15bc:      	cbnz	w8, 0x1bf4 <perf_unwind_native+0x1bf4>
    15c0:      	mov	w8, #0xc                // =12
    15c4:      	mov	w19, wzr
    15c8:      	str	w8, [x22, #0xf18]
    15cc:      	mov	w8, #0xfac              // =4012
    15d0:      	b	0x1888 <perf_unwind_native+0x1888>
    15d4:      	mov	w8, wzr
    15d8:      	b	0x1888 <perf_unwind_native+0x1888>
    15dc:      	mov	w8, wzr
    15e0:      	mov	w19, #0x1               // =1
    15e4:      	b	0x1888 <perf_unwind_native+0x1888>
    15e8:      	mov	w9, #0xd                // =13
    15ec:      	mov	w8, #0xfa5              // =4005
    15f0:      	mov	w19, wzr
    15f4:      	str	w9, [x22, #0xf18]
    15f8:      	b	0x1888 <perf_unwind_native+0x1888>
    15fc:      	mov	w8, #0x55               // =85
    1600:      	add	x9, sp, #0x180
    1604:      	add	x1, sp, #0x180
    1608:      	str	w8, [sp, #0x180]
    160c:      	mov	w8, #0x1                // =1
    1610:      	mov	x0, x25
    1614:      	blr	x8
    1618:      	cbz	x0, 0x16f4 <perf_unwind_native+0x16f4>
    161c:      	ldr	x8, [x0]
    1620:      	add	x8, x8, #0x1
    1624:      	str	x8, [x0]
    1628:      	ldr	w8, [x24]
    162c:      	cbz	w8, 0x16fc <perf_unwind_native+0x16fc>
    1630:      	mov	w8, #0xa                // =10
    1634:      	add	x0, sp, #0x140
    1638:      	mov	w1, #0x32               // =50
    163c:      	strh	w8, [sp, #0x170]
    1640:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1644:      	add	x8, x8, #0x0
    1648:      	ldp	x9, x10, [x8, #0x10]
    164c:      	stp	x9, x10, [sp, #0x150]
    1650:      	ldp	x9, x10, [x8, #0x20]
    1654:      	stp	x9, x10, [sp, #0x160]
    1658:      	ldp	x9, x8, [x8]
    165c:      	add	x10, sp, #0x140
    1660:      	stp	x9, x8, [sp, #0x140]
    1664:      	mov	w8, #0x32               // =50
    1668:      	mov	w9, #0x6                // =6
    166c:      	blr	x9
    1670:      	mov	w8, #0xfaf              // =4015
    1674:      	b	0x1884 <perf_unwind_native+0x1884>
    1678:      	cmp	w8, #0x1
    167c:      	b.ne	0x169c <perf_unwind_native+0x169c>
    1680:      	mov	w8, wzr
    1684:      	b	0x1884 <perf_unwind_native+0x1884>
    1688:      	ldr	w8, [x24]
    168c:      	cbnz	w8, 0x1c94 <perf_unwind_native+0x1c94>
    1690:      	mov	w19, wzr
    1694:      	mov	w8, #0x2                // =2
    1698:      	b	0x1888 <perf_unwind_native+0x1888>
    169c:      	mov	w8, #0x1                // =1
    16a0:      	b	0x1884 <perf_unwind_native+0x1884>
    16a4:      	mov	w8, #0x51               // =81
    16a8:      	add	x9, sp, #0x180
    16ac:      	add	x1, sp, #0x180
    16b0:      	str	w8, [sp, #0x180]
    16b4:      	mov	w8, #0x1                // =1
    16b8:      	mov	x0, x25
    16bc:      	blr	x8
    16c0:      	cbz	x0, 0x17d4 <perf_unwind_native+0x17d4>
    16c4:      	ldr	x8, [x0]
    16c8:      	mov	w19, wzr
    16cc:      	add	x8, x8, #0x1
    16d0:      	str	x8, [x0]
    16d4:      	mov	w8, #0xfa8              // =4008
    16d8:      	b	0x1888 <perf_unwind_native+0x1888>
    16dc:      	adrp	x9, 0x1000 <perf_unwind_native+0x1000>
    16e0:      	ldr	x9, [x9]
    16e4:      	ldr	x9, [x9]
    16e8:      	and	x8, x9, x8
    16ec:      	str	x8, [x23]
    16f0:      	b	0x1808 <perf_unwind_native+0x1808>
    16f4:      	ldr	w8, [x24]
    16f8:      	cbnz	w8, 0x1ce4 <perf_unwind_native+0x1ce4>
    16fc:      	mov	w8, #0xfaf              // =4015
    1700:      	b	0x1884 <perf_unwind_native+0x1884>
    1704:      	ldr	w8, [x24]
    1708:      	cbz	w8, 0x1808 <perf_unwind_native+0x1808>
    170c:      	mov	w8, #0x786c             // =30828
    1710:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1714:      	add	x10, x10, #0x0
    1718:      	add	x0, sp, #0x140
    171c:      	mov	w1, #0x2c               // =44
    1720:      	mov	x2, x29
    1724:      	movk	w8, #0xa, lsl #16
    1728:      	str	w8, [sp, #0x168]
    172c:      	ldp	x8, x9, [x10, #0x10]
    1730:      	stp	x8, x9, [sp, #0x150]
    1734:      	ldr	x8, [x10, #0x20]
    1738:      	str	x8, [sp, #0x160]
    173c:      	ldp	x9, x8, [x10]
    1740:      	add	x10, sp, #0x140
    1744:      	stp	x9, x8, [sp, #0x140]
    1748:      	mov	w8, #0x2c               // =44
    174c:      	mov	w9, #0x6                // =6
    1750:      	blr	x9
    1754:      	b	0x1808 <perf_unwind_native+0x1808>
    1758:      	mov	w8, #0x3c               // =60
    175c:      	add	x9, sp, #0x190
    1760:      	add	x1, sp, #0x190
    1764:      	str	w8, [sp, #0x190]
    1768:      	mov	w8, #0x1                // =1
    176c:      	mov	x0, x25
    1770:      	blr	x8
    1774:      	cbz	x0, 0x1800 <perf_unwind_native+0x1800>
    1778:      	ldr	x8, [x0]
    177c:      	add	x8, x8, #0x1
    1780:      	str	x8, [x0]
    1784:      	ldr	w8, [x24]
    1788:      	cbz	w8, 0x1808 <perf_unwind_native+0x1808>
    178c:      	mov	w8, #0xa                // =10
    1790:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1794:      	add	x10, x10, #0x0
    1798:      	strh	w8, [sp, #0x168]
    179c:      	ldp	x8, x9, [x10, #0x10]
    17a0:      	add	x0, sp, #0x140
    17a4:      	mov	w1, #0x2a               // =42
    17a8:      	stp	x8, x9, [sp, #0x150]
    17ac:      	ldr	x8, [x10, #0x20]
    17b0:      	str	x8, [sp, #0x160]
    17b4:      	ldp	x9, x8, [x10]
    17b8:      	add	x10, sp, #0x140
    17bc:      	stp	x9, x8, [sp, #0x140]
    17c0:      	mov	w8, #0x2a               // =42
    17c4:      	mov	w9, #0x6                // =6
    17c8:      	ldr	x2, [x23]
    17cc:      	blr	x9
    17d0:      	b	0x1808 <perf_unwind_native+0x1808>
    17d4:      	ldr	w8, [x24]
    17d8:      	cbnz	w8, 0x1d38 <perf_unwind_native+0x1d38>
    17dc:      	mov	w8, #0xfa8              // =4008
    17e0:      	b	0x1884 <perf_unwind_native+0x1884>
    17e4:      	ldr	w8, [x24]
    17e8:      	cbnz	w8, 0x1d84 <perf_unwind_native+0x1d84>
    17ec:      	mov	w9, #0x33               // =51
    17f0:      	mov	w8, #0xfa1              // =4001
    17f4:      	mov	w19, wzr
    17f8:      	str	w9, [x22, #0xf18]
    17fc:      	b	0x1888 <perf_unwind_native+0x1888>
    1800:      	ldr	w8, [x24]
    1804:      	cbnz	w8, 0x1ddc <perf_unwind_native+0x1ddc>
    1808:      	mov	w8, #0xe                // =14
    180c:      	add	x9, sp, #0x180
    1810:      	add	x1, sp, #0x180
    1814:      	str	w8, [sp, #0x180]
    1818:      	mov	w8, #0x1                // =1
    181c:      	mov	x0, x25
    1820:      	blr	x8
    1824:      	cbz	x0, 0x1878 <perf_unwind_native+0x1878>
    1828:      	ldr	x8, [x0]
    182c:      	add	x8, x8, #0x1
    1830:      	str	x8, [x0]
    1834:      	ldr	w8, [x24]
    1838:      	cbz	w8, 0x1880 <perf_unwind_native+0x1880>
    183c:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1840:      	add	x8, x8, #0x0
    1844:      	add	x0, sp, #0x140
    1848:      	ldp	x9, x10, [x8, #0x10]
    184c:      	mov	w1, #0x28               // =40
    1850:      	stp	x9, x10, [sp, #0x150]
    1854:      	ldr	x9, [x8, #0x20]
    1858:      	add	x10, sp, #0x140
    185c:      	str	x9, [sp, #0x160]
    1860:      	ldp	x8, x9, [x8]
    1864:      	stp	x8, x9, [sp, #0x140]
    1868:      	mov	w8, #0x28               // =40
    186c:      	mov	w9, #0x6                // =6
    1870:      	blr	x9
    1874:      	b	0x1880 <perf_unwind_native+0x1880>
    1878:      	ldr	w8, [x24]
    187c:      	cbnz	w8, 0x1c40 <perf_unwind_native+0x1c40>
    1880:      	mov	w8, #0xfa7              // =4007
    1884:      	mov	w19, wzr
    1888:      	str	w8, [x22, #0xf1c]
    188c:      	str	wzr, [sp, #0x28]
    1890:      	adrp	x0, 0x1000 <perf_unwind_native+0x1000>
    1894:      	mov	w8, #0x1                // =1
    1898:      	add	x9, sp, #0x28
    189c:      	add	x1, sp, #0x28
    18a0:      	ldr	x0, [x0]
    18a4:      	blr	x8
    18a8:      	cbz	x0, 0x18fc <perf_unwind_native+0x18fc>
    18ac:      	mov	w20, #0x1374            // =4980
    18b0:      	mov	w2, w19
    18b4:      	ldrb	w8, [x0, x20]
    18b8:      	cmp	w8, #0x1d
    18bc:      	b.lo	0x192c <perf_unwind_native+0x192c>
    18c0:      	mov	w8, #0x5                // =5
    18c4:      	add	x9, sp, #0x140
    18c8:      	mov	x21, x0
    18cc:      	str	w8, [x0, #0xf1c]
    18d0:      	mov	w8, #0x44               // =68
    18d4:      	add	x1, sp, #0x140
    18d8:      	mov	x0, x25
    18dc:      	str	w8, [sp, #0x140]
    18e0:      	mov	w8, #0x1                // =1
    18e4:      	blr	x8
    18e8:      	cbz	x0, 0x1918 <perf_unwind_native+0x1918>
    18ec:      	ldr	x8, [x0]
    18f0:      	add	x8, x8, #0x1
    18f4:      	str	x8, [x0]
    18f8:      	b	0x1920 <perf_unwind_native+0x1920>
    18fc:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1900:      	mov	x9, xzr
    1904:      	mov	w8, #0xc                // =12
    1908:      	ldr	x10, [x10]
    190c:      	ldr	x0, [sp, #0x10]
    1910:      	mov	w2, wzr
    1914:      	b	0x1948 <perf_unwind_native+0x1948>
    1918:      	ldr	w8, [x24]
    191c:      	cbnz	w8, 0x1a10 <perf_unwind_native+0x1a10>
    1920:      	ldrb	w8, [x21, x20]
    1924:      	mov	w2, wzr
    1928:      	mov	x0, x21
    192c:      	add	w8, w8, #0x1
    1930:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1934:      	mov	w9, w2
    1938:      	strb	w8, [x0, x20]
    193c:      	mov	w8, #0xc                // =12
    1940:      	ldr	x10, [x10]
    1944:      	ldr	x0, [sp, #0x10]
    1948:      	adrp	x1, 0x1000 <perf_unwind_native+0x1000>
    194c:      	ldr	x1, [x1]
    1950:      	blr	x8
    1954:      	ldr	w8, [x24]
    1958:      	cbnz	w8, 0x197c <perf_unwind_native+0x197c>
    195c:      	ldp	x20, x19, [sp, #0x1e0]
    1960:      	mov	w0, #-0x1               // =-1
    1964:      	ldr	x29, [sp, #0x1a0]
    1968:      	ldp	x22, x21, [sp, #0x1d0]
    196c:      	ldp	x24, x23, [sp, #0x1c0]
    1970:      	ldp	x30, x25, [sp, #0x1b0]
    1974:      	add	sp, sp, #0x1f0
    1978:      	ret
    197c:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1980:      	add	x8, x8, #0x0
    1984:      	add	x0, sp, #0x28
    1988:      	ldp	x9, x10, [x8, #0x10]
    198c:      	mov	w1, #0x2e               // =46
    1990:      	mov	w2, w19
    1994:      	stp	x9, x10, [sp, #0x38]
    1998:      	ldr	x9, [x8, #0x20]
    199c:      	add	x10, sp, #0x28
    19a0:      	str	x9, [sp, #0x48]
    19a4:      	ldur	x9, [x8, #0x26]
    19a8:      	stur	x9, [sp, #0x4e]
    19ac:      	ldp	x9, x8, [x8]
    19b0:      	stp	x9, x8, [sp, #0x28]
    19b4:      	mov	w8, #0x2e               // =46
    19b8:      	mov	w9, #0x6                // =6
    19bc:      	blr	x9
    19c0:      	b	0x195c <perf_unwind_native+0x195c>
    19c4:      	mov	w8, #0x3f61             // =16225
    19c8:      	add	x9, sp, #0x140
    19cc:      	add	x0, sp, #0x140
    19d0:      	mov	w1, #0x2b               // =43
    19d4:      	movk	w8, #0xa, lsl #16
    19d8:      	stur	w8, [x9, #0x27]
    19dc:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    19e0:      	add	x8, x8, #0x0
    19e4:      	ldp	x9, x10, [x8, #0x10]
    19e8:      	stp	x9, x10, [sp, #0x150]
    19ec:      	ldr	x9, [x8, #0x20]
    19f0:      	add	x10, sp, #0x140
    19f4:      	str	x9, [sp, #0x160]
    19f8:      	ldp	x8, x9, [x8]
    19fc:      	stp	x8, x9, [sp, #0x140]
    1a00:      	mov	w8, #0x2b               // =43
    1a04:      	mov	w9, #0x6                // =6
    1a08:      	blr	x9
    1a0c:      	b	0x1490 <perf_unwind_native+0x1490>
    1a10:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1a14:      	add	x10, x10, #0x0
    1a18:      	add	x0, sp, #0x28
    1a1c:      	ldp	x8, x9, [x10, #0x10]
    1a20:      	mov	w1, #0x2e               // =46
    1a24:      	stp	x8, x9, [sp, #0x38]
    1a28:      	ldr	x8, [x10, #0x20]
    1a2c:      	str	x8, [sp, #0x48]
    1a30:      	ldur	x8, [x10, #0x26]
    1a34:      	stur	x8, [sp, #0x4e]
    1a38:      	ldp	x8, x9, [x10]
    1a3c:      	add	x10, sp, #0x28
    1a40:      	stp	x8, x9, [sp, #0x28]
    1a44:      	mov	w8, #0x2e               // =46
    1a48:      	mov	w9, #0x6                // =6
    1a4c:      	ldr	w2, [sp, #0x140]
    1a50:      	blr	x9
    1a54:      	b	0x1920 <perf_unwind_native+0x1920>
    1a58:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1a5c:      	add	x8, x8, #0x0
    1a60:      	add	x0, sp, #0x28
    1a64:      	ldp	x9, x10, [x8, #0x10]
    1a68:      	mov	w1, #0x25               // =37
    1a6c:      	stp	x9, x10, [sp, #0x38]
    1a70:      	ldur	x9, [x8, #0x1d]
    1a74:      	add	x10, sp, #0x28
    1a78:      	stur	x9, [sp, #0x45]
    1a7c:      	ldp	x8, x9, [x8]
    1a80:      	stp	x8, x9, [sp, #0x28]
    1a84:      	mov	w8, #0x25               // =37
    1a88:      	mov	w9, #0x6                // =6
    1a8c:      	blr	x9
    1a90:      	b	0x14ac <perf_unwind_native+0x14ac>
    1a94:      	mov	w8, #0xa                // =10
    1a98:      	add	x0, sp, #0x140
    1a9c:      	mov	w1, #0x3a               // =58
    1aa0:      	strh	w8, [sp, #0x178]
    1aa4:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1aa8:      	add	x8, x8, #0x0
    1aac:      	ldp	x9, x10, [x8, #0x20]
    1ab0:      	stp	x9, x10, [sp, #0x160]
    1ab4:      	ldr	x9, [x8, #0x30]
    1ab8:      	str	x9, [sp, #0x170]
    1abc:      	ldp	x9, x10, [x8]
    1ac0:      	stp	x9, x10, [sp, #0x140]
    1ac4:      	ldp	x8, x9, [x8, #0x10]
    1ac8:      	add	x10, sp, #0x140
    1acc:      	stp	x8, x9, [sp, #0x150]
    1ad0:      	mov	w8, #0x3a               // =58
    1ad4:      	mov	w9, #0x6                // =6
    1ad8:      	ldp	x2, x3, [sp, #0x180]
    1adc:      	blr	x9
    1ae0:      	b	0x1524 <perf_unwind_native+0x1524>
    1ae4:      	mov	w8, #0x786c             // =30828
    1ae8:      	add	x9, sp, #0x140
    1aec:      	add	x0, sp, #0x140
    1af0:      	mov	w1, #0x33               // =51
    1af4:      	movk	w8, #0xa, lsl #16
    1af8:      	stur	w8, [x9, #0x2f]
    1afc:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1b00:      	add	x8, x8, #0x0
    1b04:      	ldp	x9, x10, [x8, #0x10]
    1b08:      	stp	x9, x10, [sp, #0x150]
    1b0c:      	ldp	x9, x10, [x8, #0x20]
    1b10:      	stp	x9, x10, [sp, #0x160]
    1b14:      	ldp	x9, x8, [x8]
    1b18:      	add	x10, sp, #0x140
    1b1c:      	stp	x9, x8, [sp, #0x140]
    1b20:      	mov	w8, #0x33               // =51
    1b24:      	mov	w9, #0x6                // =6
    1b28:      	ldr	x2, [sp, #0x190]
    1b2c:      	blr	x9
    1b30:      	b	0x1540 <perf_unwind_native+0x1540>
    1b34:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1b38:      	add	x8, x8, #0x0
    1b3c:      	strb	wzr, [sp, #0x58]
    1b40:      	add	x0, sp, #0x28
    1b44:      	ldp	x9, x10, [x8, #0x10]
    1b48:      	mov	w1, #0x31               // =49
    1b4c:      	stp	x9, x10, [sp, #0x38]
    1b50:      	ldp	x9, x10, [x8, #0x20]
    1b54:      	stp	x9, x10, [sp, #0x48]
    1b58:      	ldp	x9, x8, [x8]
    1b5c:      	add	x10, sp, #0x28
    1b60:      	stp	x9, x8, [sp, #0x28]
    1b64:      	mov	w8, #0x31               // =49
    1b68:      	mov	w9, #0x6                // =6
    1b6c:      	blr	x9
    1b70:      	b	0x156c <perf_unwind_native+0x156c>
    1b74:      	mov	w8, #0xa                // =10
    1b78:      	add	x0, sp, #0x28
    1b7c:      	mov	w1, #0x22               // =34
    1b80:      	strh	w8, [sp, #0x48]
    1b84:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1b88:      	add	x8, x8, #0x0
    1b8c:      	mov	x2, x21
    1b90:      	ldp	x9, x10, [x8]
    1b94:      	stp	x9, x10, [sp, #0x28]
    1b98:      	ldp	x9, x8, [x8, #0x10]
    1b9c:      	add	x10, sp, #0x28
    1ba0:      	stp	x9, x8, [sp, #0x38]
    1ba4:      	mov	w8, #0x22               // =34
    1ba8:      	mov	w9, #0x6                // =6
    1bac:      	blr	x9
    1bb0:      	b	0x1588 <perf_unwind_native+0x1588>
    1bb4:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1bb8:      	add	x8, x8, #0x0
    1bbc:      	add	x0, sp, #0x28
    1bc0:      	ldp	x9, x10, [x8]
    1bc4:      	mov	w1, #0x1e               // =30
    1bc8:      	mov	x2, x21
    1bcc:      	stp	x9, x10, [sp, #0x28]
    1bd0:      	ldr	x9, [x8, #0x10]
    1bd4:      	ldur	x8, [x8, #0x16]
    1bd8:      	add	x10, sp, #0x28
    1bdc:      	str	x9, [sp, #0x38]
    1be0:      	stur	x8, [sp, #0x3e]
    1be4:      	mov	w8, #0x1e               // =30
    1be8:      	mov	w9, #0x6                // =6
    1bec:      	blr	x9
    1bf0:      	b	0x15a4 <perf_unwind_native+0x15a4>
    1bf4:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1bf8:      	add	x8, x8, #0x0
    1bfc:      	strb	wzr, [sp, #0x60]
    1c00:      	add	x0, sp, #0x28
    1c04:      	ldp	x9, x10, [x8, #0x20]
    1c08:      	mov	w1, #0x39               // =57
    1c0c:      	mov	x2, x21
    1c10:      	stp	x9, x10, [sp, #0x48]
    1c14:      	ldr	x9, [x8, #0x30]
    1c18:      	str	x9, [sp, #0x58]
    1c1c:      	ldp	x9, x10, [x8]
    1c20:      	stp	x9, x10, [sp, #0x28]
    1c24:      	ldp	x8, x9, [x8, #0x10]
    1c28:      	add	x10, sp, #0x28
    1c2c:      	stp	x8, x9, [sp, #0x38]
    1c30:      	mov	w8, #0x39               // =57
    1c34:      	mov	w9, #0x6                // =6
    1c38:      	blr	x9
    1c3c:      	b	0x15c0 <perf_unwind_native+0x15c0>
    1c40:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1c44:      	add	x10, x10, #0x0
    1c48:      	add	x0, sp, #0x140
    1c4c:      	ldp	x8, x9, [x10, #0x10]
    1c50:      	mov	w1, #0x2e               // =46
    1c54:      	stp	x8, x9, [sp, #0x150]
    1c58:      	ldr	x8, [x10, #0x20]
    1c5c:      	add	x9, sp, #0x140
    1c60:      	str	x8, [sp, #0x160]
    1c64:      	ldur	x8, [x10, #0x26]
    1c68:      	stur	x8, [x9, #0x26]
    1c6c:      	ldp	x8, x9, [x10]
    1c70:      	add	x10, sp, #0x140
    1c74:      	stp	x8, x9, [sp, #0x140]
    1c78:      	mov	w8, #0x2e               // =46
    1c7c:      	mov	w9, #0x6                // =6
    1c80:      	ldr	w2, [sp, #0x180]
    1c84:      	blr	x9
    1c88:      	ldr	w8, [x24]
    1c8c:      	cbz	w8, 0x1880 <perf_unwind_native+0x1880>
    1c90:      	b	0x183c <perf_unwind_native+0x183c>
    1c94:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1c98:      	add	x10, x10, #0x0
    1c9c:      	add	x0, sp, #0x28
    1ca0:      	ldp	x8, x9, [x10, #0x10]
    1ca4:      	mov	w1, #0x2e               // =46
    1ca8:      	stp	x8, x9, [sp, #0x38]
    1cac:      	ldr	x8, [x10, #0x20]
    1cb0:      	str	x8, [sp, #0x48]
    1cb4:      	ldur	x8, [x10, #0x26]
    1cb8:      	stur	x8, [sp, #0x4e]
    1cbc:      	ldp	x8, x9, [x10]
    1cc0:      	add	x10, sp, #0x28
    1cc4:      	stp	x8, x9, [sp, #0x28]
    1cc8:      	mov	w8, #0x2e               // =46
    1ccc:      	mov	w9, #0x6                // =6
    1cd0:      	ldr	w2, [sp, #0x140]
    1cd4:      	blr	x9
    1cd8:      	ldr	w8, [x24]
    1cdc:      	cbz	w8, 0x1690 <perf_unwind_native+0x1690>
    1ce0:      	b	0x14e0 <perf_unwind_native+0x14e0>
    1ce4:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1ce8:      	add	x10, x10, #0x0
    1cec:      	add	x0, sp, #0x140
    1cf0:      	ldp	x8, x9, [x10, #0x10]
    1cf4:      	mov	w1, #0x2e               // =46
    1cf8:      	stp	x8, x9, [sp, #0x150]
    1cfc:      	ldr	x8, [x10, #0x20]
    1d00:      	add	x9, sp, #0x140
    1d04:      	str	x8, [sp, #0x160]
    1d08:      	ldur	x8, [x10, #0x26]
    1d0c:      	stur	x8, [x9, #0x26]
    1d10:      	ldp	x8, x9, [x10]
    1d14:      	add	x10, sp, #0x140
    1d18:      	stp	x8, x9, [sp, #0x140]
    1d1c:      	mov	w8, #0x2e               // =46
    1d20:      	mov	w9, #0x6                // =6
    1d24:      	ldr	w2, [sp, #0x180]
    1d28:      	blr	x9
    1d2c:      	ldr	w8, [x24]
    1d30:      	cbz	w8, 0x16fc <perf_unwind_native+0x16fc>
    1d34:      	b	0x1630 <perf_unwind_native+0x1630>
    1d38:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1d3c:      	add	x10, x10, #0x0
    1d40:      	add	x0, sp, #0x140
    1d44:      	ldp	x8, x9, [x10, #0x10]
    1d48:      	mov	w1, #0x2e               // =46
    1d4c:      	stp	x8, x9, [sp, #0x150]
    1d50:      	ldr	x8, [x10, #0x20]
    1d54:      	add	x9, sp, #0x140
    1d58:      	str	x8, [sp, #0x160]
    1d5c:      	ldur	x8, [x10, #0x26]
    1d60:      	stur	x8, [x9, #0x26]
    1d64:      	ldp	x8, x9, [x10]
    1d68:      	add	x10, sp, #0x140
    1d6c:      	stp	x8, x9, [sp, #0x140]
    1d70:      	mov	w8, #0x2e               // =46
    1d74:      	mov	w9, #0x6                // =6
    1d78:      	ldr	w2, [sp, #0x180]
    1d7c:      	blr	x9
    1d80:      	b	0x17dc <perf_unwind_native+0x17dc>
    1d84:      	adrp	x8, 0x1000 <perf_unwind_native+0x1000>
    1d88:      	add	x8, x8, #0x0
    1d8c:      	add	x0, sp, #0x140
    1d90:      	ldp	x9, x10, [x8, #0x20]
    1d94:      	mov	w1, #0x3f               // =63
    1d98:      	stp	x9, x10, [sp, #0x160]
    1d9c:      	ldr	x9, [x8, #0x30]
    1da0:      	add	x10, sp, #0x140
    1da4:      	str	x9, [sp, #0x170]
    1da8:      	ldur	x9, [x8, #0x37]
    1dac:      	stur	x9, [x10, #0x37]
    1db0:      	ldp	x9, x10, [x8]
    1db4:      	stp	x9, x10, [sp, #0x140]
    1db8:      	add	x10, sp, #0x140
    1dbc:      	ldp	x9, x8, [x8, #0x10]
    1dc0:      	stp	x9, x8, [sp, #0x150]
    1dc4:      	mov	w8, #0x3f               // =63
    1dc8:      	mov	w9, #0x6                // =6
    1dcc:      	ldr	x2, [sp, #0x190]
    1dd0:      	ldrh	w3, [x29, #0x6]
    1dd4:      	blr	x9
    1dd8:      	b	0x17ec <perf_unwind_native+0x17ec>
    1ddc:      	adrp	x10, 0x1000 <perf_unwind_native+0x1000>
    1de0:      	add	x10, x10, #0x0
    1de4:      	add	x0, sp, #0x140
    1de8:      	ldp	x8, x9, [x10, #0x10]
    1dec:      	mov	w1, #0x2e               // =46
    1df0:      	stp	x8, x9, [sp, #0x150]
    1df4:      	ldr	x8, [x10, #0x20]
    1df8:      	add	x9, sp, #0x140
    1dfc:      	str	x8, [sp, #0x160]
    1e00:      	ldur	x8, [x10, #0x26]
    1e04:      	stur	x8, [x9, #0x26]
    1e08:      	ldp	x8, x9, [x10]
    1e0c:      	add	x10, sp, #0x140
    1e10:      	stp	x8, x9, [sp, #0x140]
    1e14:      	mov	w8, #0x2e               // =46
    1e18:      	mov	w9, #0x6                // =6
    1e1c:      	ldr	w2, [sp, #0x190]
    1e20:      	blr	x9
    1e24:      	ldr	w8, [x24]
    1e28:      	cbz	w8, 0x1808 <perf_unwind_native+0x1808>
    1e2c:      	b	0x178c <perf_unwind_native+0x178c>

Disassembly of section kprobe/unwind_native:

0000000000000000 <kprobe_unwind_native>:
       0:      	sub	sp, sp, #0x1f0
       4:      	str	x29, [sp, #0x1a0]
       8:      	stp	x30, x25, [sp, #0x1b0]
       c:      	stp	x24, x23, [sp, #0x1c0]
      10:      	stp	x22, x21, [sp, #0x1d0]
      14:      	stp	x20, x19, [sp, #0x1e0]
      18:      	str	x0, [sp, #0x10]
      1c:      	str	wzr, [sp, #0x28]
      20:      	adrp	x0, 0x0 <kprobe_unwind_native>
      24:      	mov	w8, #0x1                // =1
      28:      	add	x9, sp, #0x28
      2c:      	add	x1, sp, #0x28
      30:      	ldr	x0, [x0]
      34:      	blr	x8
      38:      	cbz	x0, 0x195c <kprobe_unwind_native+0x195c>
      3c:      	add	x8, x0, #0xee0
      40:      	adrp	x24, 0x0 <kprobe_unwind_native>
      44:      	adrp	x25, 0x0 <kprobe_unwind_native>
      48:      	str	x8, [sp, #0x18]
      4c:      	add	x8, x0, #0xed8
      50:      	mov	x22, x0
      54:      	add	x23, x0, #0xed0
      58:      	str	x8, [sp, #0x8]
      5c:      	mov	w19, #0x4               // =4
      60:      	ldr	x24, [x24]
      64:      	ldr	x25, [x25]
      68:      	str	x23, [sp, #0x20]
      6c:      	ldr	w8, [x24]
      70:      	cbnz	w8, 0xe98 <kprobe_unwind_native+0xe98>
      74:      	mov	w8, #0x5                // =5
      78:      	add	x9, sp, #0x140
      7c:      	add	x1, sp, #0x140
      80:      	str	w8, [sp, #0x140]
      84:      	mov	w8, #0x1                // =1
      88:      	mov	x0, x25
      8c:      	blr	x8
      90:      	cbz	x0, 0x100 <kprobe_unwind_native+0x100>
      94:      	ldr	x8, [x0]
      98:      	add	x8, x8, #0x1
      9c:      	str	x8, [x0]
      a0:      	ldr	w8, [x24]
      a4:      	cbz	w8, 0x108 <kprobe_unwind_native+0x108>
      a8:      	mov	w8, #0x6b63             // =27491
      ac:      	adrp	x10, 0x0 <kprobe_unwind_native>
      b0:      	add	x10, x10, #0x0
      b4:      	add	x0, sp, #0x28
      b8:      	mov	w1, #0x2b               // =43
      bc:      	movk	w8, #0xa, lsl #16
      c0:      	stur	w8, [sp, #0x4f]
      c4:      	ldp	x8, x9, [x10, #0x10]
      c8:      	stp	x8, x9, [sp, #0x38]
      cc:      	ldr	x8, [x10, #0x20]
      d0:      	str	x8, [sp, #0x48]
      d4:      	ldp	x9, x8, [x10]
      d8:      	mov	w10, #0x2b              // =43
      dc:      	stp	x9, x8, [sp, #0x28]
      e0:      	mov	w8, #0x6                // =6
      e4:      	add	x9, sp, #0x28
      e8:      	ldr	x2, [x22, #0xf00]
      ec:      	ldr	x3, [x22, #0xf08]
      f0:      	ldr	w4, [x22, #0x2c0]
      f4:      	blr	x8
      f8:      	b	0x108 <kprobe_unwind_native+0x108>
      fc:      	nop
     100:      	ldr	w8, [x24]
     104:      	cbnz	w8, 0x10b0 <kprobe_unwind_native+0x10b0>
     108:      	ldr	w8, [x22, #0x2c0]
     10c:      	cmp	w8, #0x7f
     110:      	b.hs	0x14a4 <kprobe_unwind_native+0x14a4>
     114:      	ldr	x10, [x22, #0xf08]
     118:      	add	w12, w8, #0x1
     11c:      	ldrb	w9, [x22, #0xf20]
     120:      	ldr	x11, [x22, #0xf00]
     124:      	str	w12, [x22, #0x2c0]
     128:      	mov	w12, #0x18              // =24
     12c:      	umaddl	x8, w8, w12, x22
     130:      	str	x10, [x8, #0x2d8]
     134:      	mov	w10, #0x3               // =3
     138:      	str	x11, [x8, #0x2d0]
     13c:      	strb	w9, [x8, #0x2e1]
     140:      	ldr	x9, [x22, #0xf08]
     144:      	strb	w10, [x8, #0x2e0]
     148:      	strh	wzr, [x8, #0x2e6]
     14c:      	add	x8, x8, #0x2d0
     150:      	stur	wzr, [x8, #0x12]
     154:      	ldr	x8, [x22, #0xf00]
     158:      	str	wzr, [sp, #0x138]
     15c:      	and	x9, x9, #0xffffffffffff0000
     160:      	str	x8, [sp, #0x180]
     164:      	stp	x9, x8, [sp, #0x188]
     168:      	ldr	w8, [x24]
     16c:      	cbnz	w8, 0xedc <kprobe_unwind_native+0xedc>
     170:      	adrp	x0, 0x0 <kprobe_unwind_native>
     174:      	mov	w8, #0x1                // =1
     178:      	add	x9, sp, #0x180
     17c:      	ldr	x0, [x0]
     180:      	add	x1, sp, #0x180
     184:      	blr	x8
     188:      	cbz	x0, 0x151c <kprobe_unwind_native+0x151c>
     18c:      	ldrh	w8, [x0, #0x6]
     190:      	mov	x29, x0
     194:      	cmp	w8, #0xf
     198:      	b.gt	0x1e0 <kprobe_unwind_native+0x1e0>
     19c:      	cmp	w8, #0xb
     1a0:      	b.gt	0x20c <kprobe_unwind_native+0x20c>
     1a4:      	cmp	w8, #0x9
     1a8:      	b.gt	0x264 <kprobe_unwind_native+0x264>
     1ac:      	adrp	x0, 0x0 <kprobe_unwind_native>
     1b0:      	cmp	w8, #0x8
     1b4:      	ldr	x0, [x0]
     1b8:      	b.eq	0x324 <kprobe_unwind_native+0x324>
     1bc:      	cmp	w8, #0x9
     1c0:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     1c4:      	adrp	x0, 0x0 <kprobe_unwind_native>
     1c8:      	ldr	x0, [x0]
     1cc:      	b	0x324 <kprobe_unwind_native+0x324>
     1d0:      	nop
     1d4:      	nop
     1d8:      	nop
     1dc:      	nop
     1e0:      	cmp	w8, #0x13
     1e4:      	b.gt	0x240 <kprobe_unwind_native+0x240>
     1e8:      	cmp	w8, #0x11
     1ec:      	b.gt	0x280 <kprobe_unwind_native+0x280>
     1f0:      	cmp	w8, #0x10
     1f4:      	b.eq	0x2d4 <kprobe_unwind_native+0x2d4>
     1f8:      	cmp	w8, #0x11
     1fc:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     200:      	adrp	x0, 0x0 <kprobe_unwind_native>
     204:      	ldr	x0, [x0]
     208:      	b	0x324 <kprobe_unwind_native+0x324>
     20c:      	cmp	w8, #0xd
     210:      	b.gt	0x29c <kprobe_unwind_native+0x29c>
     214:      	cmp	w8, #0xc
     218:      	b.eq	0x2e0 <kprobe_unwind_native+0x2e0>
     21c:      	cmp	w8, #0xd
     220:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     224:      	adrp	x0, 0x0 <kprobe_unwind_native>
     228:      	ldr	x0, [x0]
     22c:      	b	0x324 <kprobe_unwind_native+0x324>
     230:      	nop
     234:      	nop
     238:      	nop
     23c:      	nop
     240:      	cmp	w8, #0x15
     244:      	b.gt	0x2b8 <kprobe_unwind_native+0x2b8>
     248:      	cmp	w8, #0x14
     24c:      	b.eq	0x2ec <kprobe_unwind_native+0x2ec>
     250:      	cmp	w8, #0x15
     254:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     258:      	adrp	x0, 0x0 <kprobe_unwind_native>
     25c:      	ldr	x0, [x0]
     260:      	b	0x324 <kprobe_unwind_native+0x324>
     264:      	cmp	w8, #0xa
     268:      	b.eq	0x2f8 <kprobe_unwind_native+0x2f8>
     26c:      	cmp	w8, #0xb
     270:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     274:      	adrp	x0, 0x0 <kprobe_unwind_native>
     278:      	ldr	x0, [x0]
     27c:      	b	0x324 <kprobe_unwind_native+0x324>
     280:      	cmp	w8, #0x12
     284:      	b.eq	0x304 <kprobe_unwind_native+0x304>
     288:      	cmp	w8, #0x13
     28c:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     290:      	adrp	x0, 0x0 <kprobe_unwind_native>
     294:      	ldr	x0, [x0]
     298:      	b	0x324 <kprobe_unwind_native+0x324>
     29c:      	cmp	w8, #0xe
     2a0:      	b.eq	0x310 <kprobe_unwind_native+0x310>
     2a4:      	cmp	w8, #0xf
     2a8:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     2ac:      	adrp	x0, 0x0 <kprobe_unwind_native>
     2b0:      	ldr	x0, [x0]
     2b4:      	b	0x324 <kprobe_unwind_native+0x324>
     2b8:      	cmp	w8, #0x16
     2bc:      	b.eq	0x31c <kprobe_unwind_native+0x31c>
     2c0:      	cmp	w8, #0x17
     2c4:      	b.ne	0x17e4 <kprobe_unwind_native+0x17e4>
     2c8:      	adrp	x0, 0x0 <kprobe_unwind_native>
     2cc:      	ldr	x0, [x0]
     2d0:      	b	0x324 <kprobe_unwind_native+0x324>
     2d4:      	adrp	x0, 0x0 <kprobe_unwind_native>
     2d8:      	ldr	x0, [x0]
     2dc:      	b	0x324 <kprobe_unwind_native+0x324>
     2e0:      	adrp	x0, 0x0 <kprobe_unwind_native>
     2e4:      	ldr	x0, [x0]
     2e8:      	b	0x324 <kprobe_unwind_native+0x324>
     2ec:      	adrp	x0, 0x0 <kprobe_unwind_native>
     2f0:      	ldr	x0, [x0]
     2f4:      	b	0x324 <kprobe_unwind_native+0x324>
     2f8:      	adrp	x0, 0x0 <kprobe_unwind_native>
     2fc:      	ldr	x0, [x0]
     300:      	b	0x324 <kprobe_unwind_native+0x324>
     304:      	adrp	x0, 0x0 <kprobe_unwind_native>
     308:      	ldr	x0, [x0]
     30c:      	b	0x324 <kprobe_unwind_native+0x324>
     310:      	adrp	x0, 0x0 <kprobe_unwind_native>
     314:      	ldr	x0, [x0]
     318:      	b	0x324 <kprobe_unwind_native+0x324>
     31c:      	adrp	x0, 0x0 <kprobe_unwind_native>
     320:      	ldr	x0, [x0]
     324:      	mov	w8, #0x1                // =1
     328:      	add	x9, sp, #0x190
     32c:      	add	x1, sp, #0x190
     330:      	blr	x8
     334:      	cbz	x0, 0x1538 <kprobe_unwind_native+0x1538>
     338:      	str	w19, [sp, #0x1ac]
     33c:      	ldr	w19, [x29]
     340:      	mov	x21, x0
     344:      	ldr	x23, [x22, #0xf08]
     348:      	ldrh	w8, [x29, #0x4]
     34c:      	str	w19, [sp, #0x13c]
     350:      	cbz	w8, 0x7d8 <kprobe_unwind_native+0x7d8>
     354:      	add	w25, w19, w8
     358:      	ldr	w8, [x24]
     35c:      	cbnz	w8, 0x1068 <kprobe_unwind_native+0x1068>
     360:      	add	w8, w25, w19
     364:      	add	x9, sp, #0x140
     368:      	add	x1, sp, #0x140
     36c:      	mov	x0, x21
     370:      	lsr	w8, w8, #1
     374:      	str	w8, [sp, #0x140]
     378:      	mov	w8, #0x1                // =1
     37c:      	blr	x8
     380:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     384:      	ldrh	w8, [x0]
     388:      	ldr	w20, [sp, #0x140]
     38c:      	and	w24, w23, #0xffff
     390:      	cmp	w8, w24
     394:      	b.hi	0x3a0 <kprobe_unwind_native+0x3a0>
     398:      	add	w19, w20, #0x1
     39c:      	mov	w20, w25
     3a0:      	cmp	w19, w20
     3a4:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     3a8:      	add	w8, w20, w19
     3ac:      	add	x9, sp, #0x140
     3b0:      	add	x1, sp, #0x140
     3b4:      	mov	x0, x21
     3b8:      	lsr	w8, w8, #1
     3bc:      	str	w8, [sp, #0x140]
     3c0:      	mov	w8, #0x1                // =1
     3c4:      	blr	x8
     3c8:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     3cc:      	ldrh	w8, [x0]
     3d0:      	ldr	w25, [sp, #0x140]
     3d4:      	cmp	w8, w24
     3d8:      	b.hi	0x3e4 <kprobe_unwind_native+0x3e4>
     3dc:      	add	w19, w25, #0x1
     3e0:      	mov	w25, w20
     3e4:      	cmp	w19, w25
     3e8:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     3ec:      	add	w8, w25, w19
     3f0:      	add	x9, sp, #0x140
     3f4:      	add	x1, sp, #0x140
     3f8:      	mov	x0, x21
     3fc:      	lsr	w8, w8, #1
     400:      	str	w8, [sp, #0x140]
     404:      	mov	w8, #0x1                // =1
     408:      	blr	x8
     40c:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     410:      	ldrh	w8, [x0]
     414:      	ldr	w20, [sp, #0x140]
     418:      	cmp	w8, w24
     41c:      	b.hi	0x428 <kprobe_unwind_native+0x428>
     420:      	add	w19, w20, #0x1
     424:      	mov	w20, w25
     428:      	cmp	w19, w20
     42c:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     430:      	add	w8, w20, w19
     434:      	add	x9, sp, #0x140
     438:      	add	x1, sp, #0x140
     43c:      	mov	x0, x21
     440:      	lsr	w8, w8, #1
     444:      	str	w8, [sp, #0x140]
     448:      	mov	w8, #0x1                // =1
     44c:      	blr	x8
     450:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     454:      	ldrh	w8, [x0]
     458:      	ldr	w25, [sp, #0x140]
     45c:      	cmp	w8, w24
     460:      	b.hi	0x46c <kprobe_unwind_native+0x46c>
     464:      	add	w19, w25, #0x1
     468:      	mov	w25, w20
     46c:      	cmp	w19, w25
     470:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     474:      	add	w8, w25, w19
     478:      	add	x9, sp, #0x140
     47c:      	add	x1, sp, #0x140
     480:      	mov	x0, x21
     484:      	lsr	w8, w8, #1
     488:      	str	w8, [sp, #0x140]
     48c:      	mov	w8, #0x1                // =1
     490:      	blr	x8
     494:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     498:      	ldrh	w8, [x0]
     49c:      	ldr	w20, [sp, #0x140]
     4a0:      	cmp	w8, w24
     4a4:      	b.hi	0x4b0 <kprobe_unwind_native+0x4b0>
     4a8:      	add	w19, w20, #0x1
     4ac:      	mov	w20, w25
     4b0:      	cmp	w19, w20
     4b4:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     4b8:      	add	w8, w20, w19
     4bc:      	add	x9, sp, #0x140
     4c0:      	add	x1, sp, #0x140
     4c4:      	mov	x0, x21
     4c8:      	lsr	w8, w8, #1
     4cc:      	str	w8, [sp, #0x140]
     4d0:      	mov	w8, #0x1                // =1
     4d4:      	blr	x8
     4d8:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     4dc:      	ldrh	w8, [x0]
     4e0:      	ldr	w25, [sp, #0x140]
     4e4:      	cmp	w8, w24
     4e8:      	b.hi	0x4f4 <kprobe_unwind_native+0x4f4>
     4ec:      	add	w19, w25, #0x1
     4f0:      	mov	w25, w20
     4f4:      	cmp	w19, w25
     4f8:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     4fc:      	add	w8, w25, w19
     500:      	add	x9, sp, #0x140
     504:      	add	x1, sp, #0x140
     508:      	mov	x0, x21
     50c:      	lsr	w8, w8, #1
     510:      	str	w8, [sp, #0x140]
     514:      	mov	w8, #0x1                // =1
     518:      	blr	x8
     51c:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     520:      	ldrh	w8, [x0]
     524:      	ldr	w20, [sp, #0x140]
     528:      	cmp	w8, w24
     52c:      	b.hi	0x538 <kprobe_unwind_native+0x538>
     530:      	add	w19, w20, #0x1
     534:      	mov	w20, w25
     538:      	cmp	w19, w20
     53c:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     540:      	add	w8, w20, w19
     544:      	add	x9, sp, #0x140
     548:      	add	x1, sp, #0x140
     54c:      	mov	x0, x21
     550:      	lsr	w8, w8, #1
     554:      	str	w8, [sp, #0x140]
     558:      	mov	w8, #0x1                // =1
     55c:      	blr	x8
     560:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     564:      	ldrh	w8, [x0]
     568:      	ldr	w25, [sp, #0x140]
     56c:      	cmp	w8, w24
     570:      	b.hi	0x57c <kprobe_unwind_native+0x57c>
     574:      	add	w19, w25, #0x1
     578:      	mov	w25, w20
     57c:      	cmp	w19, w25
     580:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     584:      	add	w8, w25, w19
     588:      	add	x9, sp, #0x140
     58c:      	add	x1, sp, #0x140
     590:      	mov	x0, x21
     594:      	lsr	w8, w8, #1
     598:      	str	w8, [sp, #0x140]
     59c:      	mov	w8, #0x1                // =1
     5a0:      	blr	x8
     5a4:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     5a8:      	ldrh	w8, [x0]
     5ac:      	ldr	w20, [sp, #0x140]
     5b0:      	cmp	w8, w24
     5b4:      	b.hi	0x5c0 <kprobe_unwind_native+0x5c0>
     5b8:      	add	w19, w20, #0x1
     5bc:      	mov	w20, w25
     5c0:      	cmp	w19, w20
     5c4:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     5c8:      	add	w8, w20, w19
     5cc:      	add	x9, sp, #0x140
     5d0:      	add	x1, sp, #0x140
     5d4:      	mov	x0, x21
     5d8:      	lsr	w8, w8, #1
     5dc:      	str	w8, [sp, #0x140]
     5e0:      	mov	w8, #0x1                // =1
     5e4:      	blr	x8
     5e8:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     5ec:      	ldrh	w8, [x0]
     5f0:      	ldr	w25, [sp, #0x140]
     5f4:      	cmp	w8, w24
     5f8:      	b.hi	0x604 <kprobe_unwind_native+0x604>
     5fc:      	add	w19, w25, #0x1
     600:      	mov	w25, w20
     604:      	cmp	w19, w25
     608:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     60c:      	add	w8, w25, w19
     610:      	add	x9, sp, #0x140
     614:      	add	x1, sp, #0x140
     618:      	mov	x0, x21
     61c:      	lsr	w8, w8, #1
     620:      	str	w8, [sp, #0x140]
     624:      	mov	w8, #0x1                // =1
     628:      	blr	x8
     62c:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     630:      	ldrh	w8, [x0]
     634:      	ldr	w20, [sp, #0x140]
     638:      	cmp	w8, w24
     63c:      	b.hi	0x648 <kprobe_unwind_native+0x648>
     640:      	add	w19, w20, #0x1
     644:      	mov	w20, w25
     648:      	cmp	w19, w20
     64c:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     650:      	add	w8, w20, w19
     654:      	add	x9, sp, #0x140
     658:      	add	x1, sp, #0x140
     65c:      	mov	x0, x21
     660:      	lsr	w8, w8, #1
     664:      	str	w8, [sp, #0x140]
     668:      	mov	w8, #0x1                // =1
     66c:      	blr	x8
     670:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     674:      	ldrh	w8, [x0]
     678:      	ldr	w25, [sp, #0x140]
     67c:      	cmp	w8, w24
     680:      	b.hi	0x68c <kprobe_unwind_native+0x68c>
     684:      	add	w19, w25, #0x1
     688:      	mov	w25, w20
     68c:      	cmp	w19, w25
     690:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     694:      	add	w8, w25, w19
     698:      	add	x9, sp, #0x140
     69c:      	add	x1, sp, #0x140
     6a0:      	mov	x0, x21
     6a4:      	lsr	w8, w8, #1
     6a8:      	str	w8, [sp, #0x140]
     6ac:      	mov	w8, #0x1                // =1
     6b0:      	blr	x8
     6b4:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     6b8:      	ldrh	w8, [x0]
     6bc:      	ldr	w20, [sp, #0x140]
     6c0:      	cmp	w8, w24
     6c4:      	b.hi	0x6d0 <kprobe_unwind_native+0x6d0>
     6c8:      	add	w19, w20, #0x1
     6cc:      	mov	w20, w25
     6d0:      	cmp	w19, w20
     6d4:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     6d8:      	add	w8, w20, w19
     6dc:      	add	x9, sp, #0x140
     6e0:      	add	x1, sp, #0x140
     6e4:      	mov	x0, x21
     6e8:      	lsr	w8, w8, #1
     6ec:      	str	w8, [sp, #0x140]
     6f0:      	mov	w8, #0x1                // =1
     6f4:      	blr	x8
     6f8:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     6fc:      	ldrh	w8, [x0]
     700:      	ldr	w25, [sp, #0x140]
     704:      	cmp	w8, w24
     708:      	b.hi	0x714 <kprobe_unwind_native+0x714>
     70c:      	add	w19, w25, #0x1
     710:      	mov	w25, w20
     714:      	cmp	w19, w25
     718:      	b.hs	0x7bc <kprobe_unwind_native+0x7bc>
     71c:      	add	w8, w25, w19
     720:      	add	x9, sp, #0x140
     724:      	add	x1, sp, #0x140
     728:      	mov	x0, x21
     72c:      	lsr	w8, w8, #1
     730:      	str	w8, [sp, #0x140]
     734:      	mov	w8, #0x1                // =1
     738:      	blr	x8
     73c:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     740:      	ldrh	w8, [x0]
     744:      	ldr	w20, [sp, #0x140]
     748:      	cmp	w8, w24
     74c:      	b.hi	0x758 <kprobe_unwind_native+0x758>
     750:      	add	w19, w20, #0x1
     754:      	mov	w20, w25
     758:      	cmp	w19, w20
     75c:      	b.hs	0x7c0 <kprobe_unwind_native+0x7c0>
     760:      	add	w8, w20, w19
     764:      	add	x9, sp, #0x140
     768:      	add	x1, sp, #0x140
     76c:      	mov	x0, x21
     770:      	lsr	w8, w8, #1
     774:      	str	w8, [sp, #0x140]
     778:      	mov	w8, #0x1                // =1
     77c:      	blr	x8
     780:      	cbz	x0, 0x1478 <kprobe_unwind_native+0x1478>
     784:      	ldrh	w9, [x0]
     788:      	ldr	w8, [sp, #0x140]
     78c:      	cmp	w9, w24
     790:      	b.hi	0x79c <kprobe_unwind_native+0x79c>
     794:      	add	w19, w8, #0x1
     798:      	mov	w8, w20
     79c:      	adrp	x24, 0x0 <kprobe_unwind_native>
     7a0:      	adrp	x25, 0x0 <kprobe_unwind_native>
     7a4:      	cmp	w19, w8
     7a8:      	ldr	x24, [x24]
     7ac:      	ldr	x25, [x25]
     7b0:      	mov	w20, w8
     7b4:      	b.hs	0x7d0 <kprobe_unwind_native+0x7d0>
     7b8:      	b	0x1488 <kprobe_unwind_native+0x1488>
     7bc:      	mov	w20, w25
     7c0:      	adrp	x24, 0x0 <kprobe_unwind_native>
     7c4:      	adrp	x25, 0x0 <kprobe_unwind_native>
     7c8:      	ldr	x24, [x24]
     7cc:      	ldr	x25, [x25]
     7d0:      	mov	w19, w20
     7d4:      	cbz	w20, 0x1488 <kprobe_unwind_native+0x1488>
     7d8:      	sub	w8, w19, #0x1
     7dc:      	add	x9, sp, #0x13c
     7e0:      	add	x1, sp, #0x13c
     7e4:      	str	w8, [sp, #0x13c]
     7e8:      	mov	w8, #0x1                // =1
     7ec:      	mov	x0, x21
     7f0:      	blr	x8
     7f4:      	cbz	x0, 0x1554 <kprobe_unwind_native+0x1554>
     7f8:      	ldr	w8, [x24]
     7fc:      	cbnz	w8, 0xf1c <kprobe_unwind_native+0xf1c>
     800:      	ldrh	w9, [x0]
     804:      	and	w8, w23, #0xffff
     808:      	ldr	w10, [x29]
     80c:      	sub	w8, w8, w9
     810:      	ldr	w9, [sp, #0x13c]
     814:      	add	w11, w8, #0x10, lsl #12 // =0x10000
     818:      	cmp	w9, w10
     81c:      	mov	w9, #0x8001             // =32769
     820:      	csel	w21, w11, w8, lo
     824:      	ldrh	w8, [x0, #0x2]
     828:      	cmp	w8, w9
     82c:      	str	w8, [sp, #0x138]
     830:      	b.eq	0x8a0 <kprobe_unwind_native+0x8a0>
     834:      	ldr	x23, [sp, #0x20]
     838:      	cmp	w8, #0x8, lsl #12       // =0x8000
     83c:      	b.eq	0x15e8 <kprobe_unwind_native+0x15e8>
     840:      	tbnz	w8, #0xf, 0x8f0 <kprobe_unwind_native+0x8f0>
     844:      	adrp	x0, 0x0 <kprobe_unwind_native>
     848:      	mov	w8, #0x1                // =1
     84c:      	add	x9, sp, #0x138
     850:      	ldr	x0, [x0]
     854:      	add	x1, sp, #0x138
     858:      	blr	x8
     85c:      	cbz	x0, 0x15fc <kprobe_unwind_native+0x15fc>
     860:      	ldr	w20, [x0, #0x4]
     864:      	ldrb	w8, [x0, #0x2]
     868:      	mov	x19, x0
     86c:      	cbz	w8, 0xa04 <kprobe_unwind_native+0xa04>
     870:      	ldr	w9, [x24]
     874:      	cbnz	w9, 0x1154 <kprobe_unwind_native+0x1154>
     878:      	and	w9, w8, #0x7f
     87c:      	cmp	w21, w9
     880:      	b.lt	0xa04 <kprobe_unwind_native+0xa04>
     884:      	tbnz	w8, #0x7, 0x9f4 <kprobe_unwind_native+0x9f4>
     888:      	mov	w8, #0x8                // =8
     88c:      	add	w20, w8, w20
     890:      	ldr	w8, [x24]
     894:      	cbz	w8, 0xa04 <kprobe_unwind_native+0xa04>
     898:      	b	0x1230 <kprobe_unwind_native+0x1230>
     89c:      	nop
     8a0:      	mov	w8, #0x7                // =7
     8a4:      	add	x9, sp, #0x19c
     8a8:      	add	x1, sp, #0x19c
     8ac:      	str	w8, [sp, #0x19c]
     8b0:      	mov	w8, #0x1                // =1
     8b4:      	mov	x0, x25
     8b8:      	blr	x8
     8bc:      	cbz	x0, 0x8dc <kprobe_unwind_native+0x8dc>
     8c0:      	ldr	x8, [x0]
     8c4:      	ldr	x23, [sp, #0x20]
     8c8:      	add	x8, x8, #0x1
     8cc:      	str	x8, [x0]
     8d0:      	ldr	w8, [sp, #0x138]
     8d4:      	tbz	w8, #0xf, 0x844 <kprobe_unwind_native+0x844>
     8d8:      	b	0x8f0 <kprobe_unwind_native+0x8f0>
     8dc:      	ldr	w8, [x24]
     8e0:      	ldr	x23, [sp, #0x20]
     8e4:      	cbnz	w8, 0x11dc <kprobe_unwind_native+0x11dc>
     8e8:      	ldr	w8, [sp, #0x138]
     8ec:      	tbz	w8, #0xf, 0x844 <kprobe_unwind_native+0x844>
     8f0:      	and	w8, w8, #0xffff7fff
     8f4:      	cmp	w8, #0x3
     8f8:      	b.eq	0x948 <kprobe_unwind_native+0x948>
     8fc:      	cmp	w8, #0x4
     900:      	b.ne	0x1678 <kprobe_unwind_native+0x1678>
     904:      	ldr	x10, [sp, #0x18]
     908:      	mov	w9, #0x70               // =112
     90c:      	add	x11, sp, #0x140
     910:      	mov	w12, #0x10              // =16
     914:      	ldr	x8, [x10]
     918:      	add	x0, sp, #0x140
     91c:      	mov	w1, #0x10               // =16
     920:      	ldr	x2, [x10]
     924:      	blr	x9
     928:      	cbnz	x0, 0x1808 <kprobe_unwind_native+0x1808>
     92c:      	ldr	x8, [x22, #0xee0]
     930:      	add	x8, x8, #0x10
     934:      	str	x8, [x22, #0xed8]
     938:      	ldp	x8, x9, [sp, #0x140]
     93c:      	str	x8, [x22, #0xee0]
     940:      	str	x9, [x22, #0xed0]
     944:      	b	0xc70 <kprobe_unwind_native+0xc70>
     948:      	ldr	x10, [sp, #0x8]
     94c:      	mov	w9, #0x70               // =112
     950:      	add	x11, sp, #0x28
     954:      	mov	w12, #0x110             // =272
     958:      	ldr	x8, [x10]
     95c:      	add	x0, sp, #0x28
     960:      	mov	w1, #0x110              // =272
     964:      	add	x8, x8, #0x138
     968:      	ldr	x8, [x10]
     96c:      	add	x2, x8, #0x138
     970:      	blr	x9
     974:      	cbnz	x0, 0x1808 <kprobe_unwind_native+0x1808>
     978:      	ldp	x9, x8, [sp, #0x120]
     97c:      	str	x9, [x22, #0xed8]
     980:      	ldp	x9, x10, [sp, #0x110]
     984:      	str	x9, [x22, #0xee0]
     988:      	adrp	x9, 0x0 <kprobe_unwind_native>
     98c:      	ldr	x9, [x9]
     990:      	strh	wzr, [x22, #0xf20]
     994:      	ldr	x9, [x9]
     998:      	and	x8, x9, x8
     99c:      	and	x9, x10, x9
     9a0:      	str	x8, [x22, #0xed0]
     9a4:      	ldr	x8, [sp, #0xd8]
     9a8:      	str	x9, [x22, #0xee8]
     9ac:      	ldr	x9, [sp, #0x108]
     9b0:      	str	x8, [x22, #0xef0]
     9b4:      	ldr	w8, [x24]
     9b8:      	str	x9, [x22, #0xef8]
     9bc:      	cbz	w8, 0xc78 <kprobe_unwind_native+0xc78>
     9c0:      	adrp	x9, 0x0 <kprobe_unwind_native>
     9c4:      	add	x9, x9, #0x0
     9c8:      	mov	w10, #0xe               // =14
     9cc:      	ldr	x8, [x9]
     9d0:      	add	x0, sp, #0x140
     9d4:      	mov	w1, #0xe                // =14
     9d8:      	str	x8, [sp, #0x140]
     9dc:      	ldur	x8, [x9, #0x6]
     9e0:      	add	x9, sp, #0x140
     9e4:      	stur	x8, [x9, #0x6]
     9e8:      	mov	w8, #0x6                // =6
     9ec:      	blr	x8
     9f0:      	b	0xc78 <kprobe_unwind_native+0xc78>
     9f4:      	mov	w8, #-0x8               // =-8
     9f8:      	add	w20, w8, w20
     9fc:      	ldr	w8, [x24]
     a00:      	cbnz	w8, 0x1230 <kprobe_unwind_native+0x1230>
     a04:      	ldrsb	w9, [x19]
     a08:      	mov	w8, w20
     a0c:      	tbnz	w9, #0x1f, 0xa3c <kprobe_unwind_native+0xa3c>
     a10:      	and	w9, w9, #0xff
     a14:      	mov	x21, xzr
     a18:      	and	w10, w9, #0x7f
     a1c:      	cmp	w10, #0x2
     a20:      	b.gt	0xa54 <kprobe_unwind_native+0xa54>
     a24:      	cmp	w10, #0x1
     a28:      	b.eq	0xaf4 <kprobe_unwind_native+0xaf4>
     a2c:      	ldr	x11, [sp, #0x8]
     a30:      	cmp	w10, #0x2
     a34:      	b.eq	0xaf0 <kprobe_unwind_native+0xaf0>
     a38:      	b	0xb40 <kprobe_unwind_native+0xb40>
     a3c:      	and	w8, w20, #0xfffffff8
     a40:      	and	w9, w9, #0xff
     a44:      	mov	x21, xzr
     a48:      	and	w10, w9, #0x7f
     a4c:      	cmp	w10, #0x2
     a50:      	b.le	0xa24 <kprobe_unwind_native+0xa24>
     a54:      	ldr	x11, [sp, #0x18]
     a58:      	cmp	w10, #0x3
     a5c:      	b.eq	0xaf0 <kprobe_unwind_native+0xaf0>
     a60:      	cmp	w10, #0x4
     a64:      	b.ne	0xb40 <kprobe_unwind_native+0xb40>
     a68:      	ldr	w8, [x24]
     a6c:      	cbnz	w8, 0x1354 <kprobe_unwind_native+0x1354>
     a70:      	ldr	x21, [x22, #0xee8]
     a74:      	cbnz	x21, 0xb40 <kprobe_unwind_native+0xb40>
     a78:      	mov	w8, #0x3c               // =60
     a7c:      	add	x9, sp, #0x180
     a80:      	add	x1, sp, #0x180
     a84:      	str	w8, [sp, #0x180]
     a88:      	mov	w8, #0x1                // =1
     a8c:      	mov	x0, x25
     a90:      	blr	x8
     a94:      	cbz	x0, 0xe3c <kprobe_unwind_native+0xe3c>
     a98:      	ldr	x8, [x0]
     a9c:      	add	x8, x8, #0x1
     aa0:      	str	x8, [x0]
     aa4:      	ldr	w8, [x24]
     aa8:      	cbz	w8, 0xb24 <kprobe_unwind_native+0xb24>
     aac:      	mov	w8, #0xa                // =10
     ab0:      	adrp	x10, 0x0 <kprobe_unwind_native>
     ab4:      	add	x10, x10, #0x0
     ab8:      	strh	w8, [sp, #0x168]
     abc:      	ldp	x8, x9, [x10, #0x10]
     ac0:      	add	x0, sp, #0x140
     ac4:      	mov	w1, #0x2a               // =42
     ac8:      	stp	x8, x9, [sp, #0x150]
     acc:      	ldr	x8, [x10, #0x20]
     ad0:      	str	x8, [sp, #0x160]
     ad4:      	ldp	x9, x8, [x10]
     ad8:      	mov	w10, #0x2a              // =42
     adc:      	stp	x9, x8, [sp, #0x140]
     ae0:      	mov	w8, #0x6                // =6
     ae4:      	add	x9, sp, #0x140
     ae8:      	ldr	x2, [x23]
     aec:      	b	0x1428 <kprobe_unwind_native+0x1428>
     af0:      	ldr	x21, [x11]
     af4:      	add	x21, x21, w8, sxtw
     af8:      	tbz	w9, #0x7, 0xb40 <kprobe_unwind_native+0xb40>
     afc:      	mov	w8, #0x70               // =112
     b00:      	add	x9, sp, #0x180
     b04:      	mov	w10, #0x8               // =8
     b08:      	add	x0, sp, #0x180
     b0c:      	mov	w1, #0x8                // =8
     b10:      	mov	x2, x21
     b14:      	blr	x8
     b18:      	cbz	x0, 0xb2c <kprobe_unwind_native+0xb2c>
     b1c:      	ldr	w8, [x24]
     b20:      	cbnz	w8, 0x13e4 <kprobe_unwind_native+0x13e4>
     b24:      	mov	x21, xzr
     b28:      	b	0xb40 <kprobe_unwind_native+0xb40>
     b2c:      	ldr	x9, [sp, #0x180]
     b30:      	ubfiz	w8, w20, #3, #3
     b34:      	add	x21, x9, x8
     b38:      	nop
     b3c:      	nop
     b40:      	ldrb	w10, [x19, #0x1]
     b44:      	ldr	w20, [x19, #0x8]
     b48:      	sxtb	w8, w10
     b4c:      	and	w9, w20, #0xfffffff8
     b50:      	and	w10, w10, #0x7f
     b54:      	cmp	w8, #0x0
     b58:      	csel	w9, w20, w9, ge
     b5c:      	cmp	w10, #0x2
     b60:      	b.gt	0xb80 <kprobe_unwind_native+0xb80>
     b64:      	cmp	w10, #0x1
     b68:      	mov	x11, x21
     b6c:      	b.eq	0xbac <kprobe_unwind_native+0xbac>
     b70:      	ldr	x11, [sp, #0x8]
     b74:      	cmp	w10, #0x2
     b78:      	b.eq	0xba8 <kprobe_unwind_native+0xba8>
     b7c:      	b	0x1808 <kprobe_unwind_native+0x1808>
     b80:      	ldr	x11, [sp, #0x18]
     b84:      	cmp	w10, #0x3
     b88:      	b.eq	0xba8 <kprobe_unwind_native+0xba8>
     b8c:      	cmp	w10, #0x4
     b90:      	b.ne	0x1808 <kprobe_unwind_native+0x1808>
     b94:      	ldr	w8, [x24]
     b98:      	cbnz	w8, 0x126c <kprobe_unwind_native+0x126c>
     b9c:      	ldr	x29, [x22, #0xee8]
     ba0:      	cbnz	x29, 0xbe4 <kprobe_unwind_native+0xbe4>
     ba4:      	b	0x1758 <kprobe_unwind_native+0x1758>
     ba8:      	ldr	x11, [x11]
     bac:      	add	x29, x11, w9, sxtw
     bb0:      	tbz	w8, #0x1f, 0xbe0 <kprobe_unwind_native+0xbe0>
     bb4:      	mov	w8, #0x70               // =112
     bb8:      	add	x9, sp, #0x180
     bbc:      	mov	w10, #0x8               // =8
     bc0:      	add	x0, sp, #0x180
     bc4:      	mov	w1, #0x8                // =8
     bc8:      	mov	x2, x29
     bcc:      	blr	x8
     bd0:      	cbnz	x0, 0x1704 <kprobe_unwind_native+0x1704>
     bd4:      	ldr	x9, [sp, #0x180]
     bd8:      	ubfiz	x8, x20, #3, #3
     bdc:      	add	x29, x9, x8
     be0:      	cbz	x29, 0x1808 <kprobe_unwind_native+0x1808>
     be4:      	ldrb	w8, [x19, #0x1]
     be8:      	cmp	w8, #0x4
     bec:      	b.ne	0xc00 <kprobe_unwind_native+0xc00>
     bf0:      	ldrb	w9, [x22, #0xf21]
     bf4:      	mov	x8, x29
     bf8:      	cbz	w9, 0xc28 <kprobe_unwind_native+0xc28>
     bfc:      	b	0x16a4 <kprobe_unwind_native+0x16a4>
     c00:      	ldr	w8, [x24]
     c04:      	cbnz	w8, 0x11a4 <kprobe_unwind_native+0x11a4>
     c08:      	mov	w8, #0x70               // =112
     c0c:      	mov	w9, #0x8                // =8
     c10:      	mov	x0, x23
     c14:      	mov	w1, #0x8                // =8
     c18:      	mov	x2, x29
     c1c:      	blr	x8
     c20:      	ldr	x8, [x23]
     c24:      	cbnz	x0, 0x16dc <kprobe_unwind_native+0x16dc>
     c28:      	adrp	x9, 0x0 <kprobe_unwind_native>
     c2c:      	ldr	x9, [x9]
     c30:      	ldr	x9, [x9]
     c34:      	and	x8, x9, x8
     c38:      	str	x8, [x23]
     c3c:      	ldr	w8, [x19, #0x8]
     c40:      	cmp	w8, #0x8
     c44:      	b.ne	0xc6c <kprobe_unwind_native+0xc6c>
     c48:      	ldrb	w8, [x19, #0x1]
     c4c:      	cmp	w8, #0x4
     c50:      	b.eq	0xc6c <kprobe_unwind_native+0xc6c>
     c54:      	ldr	x0, [sp, #0x18]
     c58:      	sub	x2, x29, #0x8
     c5c:      	mov	w8, #0x70               // =112
     c60:      	mov	w9, #0x8                // =8
     c64:      	mov	w1, #0x8                // =8
     c68:      	blr	x8
     c6c:      	str	x21, [x22, #0xed8]
     c70:      	mov	w8, #0x101              // =257
     c74:      	strh	w8, [x22, #0xf20]
     c78:      	mov	w8, #0x6                // =6
     c7c:      	add	x9, sp, #0x180
     c80:      	add	x1, sp, #0x180
     c84:      	str	w8, [sp, #0x180]
     c88:      	mov	w8, #0x1                // =1
     c8c:      	mov	x0, x25
     c90:      	blr	x8
     c94:      	cbz	x0, 0xd00 <kprobe_unwind_native+0xd00>
     c98:      	ldr	x8, [x0]
     c9c:      	add	x8, x8, #0x1
     ca0:      	str	x8, [x0]
     ca4:      	ldr	w8, [x24]
     ca8:      	cbz	w8, 0xd08 <kprobe_unwind_native+0xd08>
     cac:      	adrp	x10, 0x0 <kprobe_unwind_native>
     cb0:      	add	x10, x10, #0x0
     cb4:      	add	x0, sp, #0x28
     cb8:      	ldp	x8, x9, [x10]
     cbc:      	mov	w1, #0x1d               // =29
     cc0:      	stp	x8, x9, [sp, #0x28]
     cc4:      	ldr	x8, [x10, #0x10]
     cc8:      	add	x9, sp, #0x28
     ccc:      	str	x8, [sp, #0x38]
     cd0:      	ldur	x8, [x10, #0x15]
     cd4:      	mov	w10, #0x1d              // =29
     cd8:      	stur	x8, [sp, #0x3d]
     cdc:      	mov	w8, #0x6                // =6
     ce0:      	ldr	x9, [sp, #0x8]
     ce4:      	ldr	x2, [x23]
     ce8:      	ldr	x3, [x9]
     cec:      	ldr	x9, [sp, #0x18]
     cf0:      	ldr	x4, [x9]
     cf4:      	blr	x8
     cf8:      	b	0xd08 <kprobe_unwind_native+0xd08>
     cfc:      	nop
     d00:      	ldr	w8, [x24]
     d04:      	cbnz	w8, 0x1100 <kprobe_unwind_native+0x1100>
     d08:      	ldr	x21, [x23]
     d0c:      	ldr	w8, [x24]
     d10:      	cbz	x21, 0x1568 <kprobe_unwind_native+0x1568>
     d14:      	cbnz	w8, 0xf78 <kprobe_unwind_native+0xf78>
     d18:      	lsr	x8, x21, #56
     d1c:      	cbnz	x8, 0x1580 <kprobe_unwind_native+0x1580>
     d20:      	cmp	x21, #0xfff
     d24:      	b.ls	0x159c <kprobe_unwind_native+0x159c>
     d28:      	ldr	w8, [x22]
     d2c:      	mov	w9, #0x60               // =96
     d30:      	adrp	x0, 0x0 <kprobe_unwind_native>
     d34:      	add	x1, sp, #0x140
     d38:      	str	w9, [sp, #0x140]
     d3c:      	add	x9, sp, #0x140
     d40:      	rev	w8, w8
     d44:      	str	w8, [sp, #0x144]
     d48:      	rev	x8, x21
     d4c:      	str	x8, [sp, #0x148]
     d50:      	mov	w8, #0x1                // =1
     d54:      	ldr	x0, [x0]
     d58:      	blr	x8
     d5c:      	cbz	x0, 0x15b8 <kprobe_unwind_native+0x15b8>
     d60:      	ldr	x8, [x0, #0x8]
     d64:      	and	x9, x8, #0xffffffffffffff
     d68:      	lsr	x19, x8, #56
     d6c:      	str	x9, [x22, #0xf10]
     d70:      	ldr	x8, [x0]
     d74:      	str	x8, [x22, #0xf00]
     d78:      	sub	x8, x21, x9
     d7c:      	str	x8, [x22, #0xf08]
     d80:      	ldr	w8, [x24]
     d84:      	cbnz	w8, 0xfc8 <kprobe_unwind_native+0xfc8>
     d88:      	cmp	w19, #0x1
     d8c:      	b.ne	0xe24 <kprobe_unwind_native+0xe24>
     d90:      	ldr	x8, [x22, #0xf00]
     d94:      	adrp	x0, 0x0 <kprobe_unwind_native>
     d98:      	ldr	x19, [x22, #0xf08]
     d9c:      	add	x9, sp, #0x140
     da0:      	add	x1, sp, #0x140
     da4:      	mov	w20, #0x1               // =1
     da8:      	str	x8, [sp, #0x140]
     dac:      	mov	w8, #0x1                // =1
     db0:      	ldr	x0, [x0]
     db4:      	blr	x8
     db8:      	cbz	x0, 0xe20 <kprobe_unwind_native+0xe20>
     dbc:      	ldr	x8, [x0]
     dc0:      	cmp	x8, x19
     dc4:      	b.hi	0xdd4 <kprobe_unwind_native+0xdd4>
     dc8:      	ldr	x8, [x0, #0x8]
     dcc:      	cmp	x8, x19
     dd0:      	b.hs	0xdec <kprobe_unwind_native+0xdec>
     dd4:      	ldr	x8, [x0, #0x10]
     dd8:      	cmp	x8, x19
     ddc:      	b.hi	0xe0c <kprobe_unwind_native+0xe0c>
     de0:      	ldr	x8, [x0, #0x18]
     de4:      	cmp	x8, x19
     de8:      	b.lo	0xe0c <kprobe_unwind_native+0xe0c>
     dec:      	ldr	w8, [x24]
     df0:      	cbnz	w8, 0x12ac <kprobe_unwind_native+0x12ac>
     df4:      	ldrh	w8, [x0, #0x20]
     df8:      	ldr	w9, [x22, #0x1370]
     dfc:      	lsr	w8, w9, w8
     e00:      	tbz	w8, #0x0, 0x1300 <kprobe_unwind_native+0x1300>
     e04:      	ldr	w8, [x24]
     e08:      	cbnz	w8, 0x1394 <kprobe_unwind_native+0x1394>
     e0c:      	mov	w19, #0x1               // =1
     e10:      	ldr	w8, [sp, #0x1ac]
     e14:      	cmp	w19, #0x1
     e18:      	b.eq	0xe30 <kprobe_unwind_native+0xe30>
     e1c:      	b	0x15d4 <kprobe_unwind_native+0x15d4>
     e20:      	mov	w19, w20
     e24:      	ldr	w8, [sp, #0x1ac]
     e28:      	cmp	w19, #0x1
     e2c:      	b.ne	0x15d4 <kprobe_unwind_native+0x15d4>
     e30:      	subs	w19, w8, #0x1
     e34:      	b.ne	0x6c <kprobe_unwind_native+0x6c>
     e38:      	b	0x15dc <kprobe_unwind_native+0x15dc>
     e3c:      	ldr	w8, [x24]
     e40:      	cbz	w8, 0xb24 <kprobe_unwind_native+0xb24>
     e44:      	adrp	x10, 0x0 <kprobe_unwind_native>
     e48:      	add	x10, x10, #0x0
     e4c:      	add	x0, sp, #0x140
     e50:      	ldp	x8, x9, [x10, #0x10]
     e54:      	mov	w1, #0x2e               // =46
     e58:      	stp	x8, x9, [sp, #0x150]
     e5c:      	ldr	x8, [x10, #0x20]
     e60:      	add	x9, sp, #0x140
     e64:      	str	x8, [sp, #0x160]
     e68:      	ldur	x8, [x10, #0x26]
     e6c:      	stur	x8, [x9, #0x26]
     e70:      	ldp	x8, x9, [x10]
     e74:      	mov	w10, #0x2e              // =46
     e78:      	stp	x8, x9, [sp, #0x140]
     e7c:      	mov	w8, #0x6                // =6
     e80:      	add	x9, sp, #0x140
     e84:      	ldr	w2, [sp, #0x180]
     e88:      	blr	x8
     e8c:      	ldr	w8, [x24]
     e90:      	cbz	w8, 0xb24 <kprobe_unwind_native+0xb24>
     e94:      	b	0xaac <kprobe_unwind_native+0xaac>
     e98:      	adrp	x10, 0x0 <kprobe_unwind_native>
     e9c:      	add	x10, x10, #0x0
     ea0:      	ldr	w2, [x22, #0x2c0]
     ea4:      	add	x0, sp, #0x28
     ea8:      	ldp	x8, x9, [x10]
     eac:      	mov	w1, #0x1c               // =28
     eb0:      	stp	x8, x9, [sp, #0x28]
     eb4:      	ldr	x8, [x10, #0x10]
     eb8:      	add	x9, sp, #0x28
     ebc:      	mov	w10, #0x1c              // =28
     ec0:      	str	x8, [sp, #0x38]
     ec4:      	mov	w8, #0x3d3d             // =15677
     ec8:      	movk	w8, #0xa, lsl #16
     ecc:      	str	w8, [sp, #0x40]
     ed0:      	mov	w8, #0x6                // =6
     ed4:      	blr	x8
     ed8:      	b	0x74 <kprobe_unwind_native+0x74>
     edc:      	adrp	x10, 0x0 <kprobe_unwind_native>
     ee0:      	add	x10, x10, #0x0
     ee4:      	strb	wzr, [sp, #0x160]
     ee8:      	add	x0, sp, #0x140
     eec:      	ldp	x8, x9, [x10]
     ef0:      	mov	w1, #0x21               // =33
     ef4:      	stp	x8, x9, [sp, #0x140]
     ef8:      	ldp	x8, x9, [x10, #0x10]
     efc:      	mov	w10, #0x21              // =33
     f00:      	stp	x8, x9, [sp, #0x150]
     f04:      	mov	w8, #0x6                // =6
     f08:      	add	x9, sp, #0x140
     f0c:      	ldr	x2, [x22, #0xf00]
     f10:      	ldr	x3, [x22, #0xf08]
     f14:      	blr	x8
     f18:      	b	0x170 <kprobe_unwind_native+0x170>
     f1c:      	adrp	x10, 0x0 <kprobe_unwind_native>
     f20:      	add	x10, x10, #0x0
     f24:      	mov	x19, x0
     f28:      	ldp	x8, x9, [x10, #0x10]
     f2c:      	mov	w1, #0x2d               // =45
     f30:      	stp	x8, x9, [sp, #0x150]
     f34:      	ldr	x8, [x10, #0x20]
     f38:      	add	x9, sp, #0x140
     f3c:      	str	x8, [sp, #0x160]
     f40:      	ldur	x8, [x10, #0x25]
     f44:      	stur	x8, [x9, #0x25]
     f48:      	ldp	x8, x9, [x10]
     f4c:      	mov	w10, #0x2d              // =45
     f50:      	stp	x8, x9, [sp, #0x140]
     f54:      	mov	w8, #0x6                // =6
     f58:      	add	x9, sp, #0x140
     f5c:      	ldr	w2, [sp, #0x13c]
     f60:      	ldrh	w3, [x0]
     f64:      	ldrh	w4, [x0, #0x2]
     f68:      	add	x0, sp, #0x140
     f6c:      	blr	x8
     f70:      	mov	x0, x19
     f74:      	b	0x800 <kprobe_unwind_native+0x800>
     f78:      	adrp	x10, 0x0 <kprobe_unwind_native>
     f7c:      	add	x10, x10, #0x0
     f80:      	strb	wzr, [sp, #0x58]
     f84:      	add	x0, sp, #0x28
     f88:      	ldp	x8, x9, [x10, #0x10]
     f8c:      	mov	w1, #0x31               // =49
     f90:      	stp	x8, x9, [sp, #0x38]
     f94:      	ldp	x8, x9, [x10, #0x20]
     f98:      	stp	x8, x9, [sp, #0x48]
     f9c:      	ldp	x8, x9, [x10]
     fa0:      	mov	w10, #0x31              // =49
     fa4:      	stp	x8, x9, [sp, #0x28]
     fa8:      	mov	w8, #0x6                // =6
     fac:      	add	x9, sp, #0x28
     fb0:      	ldr	w2, [x22, #0x2c0]
     fb4:      	blr	x8
     fb8:      	ldr	x21, [x22, #0xed0]
     fbc:      	lsr	x8, x21, #56
     fc0:      	cbz	x8, 0xd20 <kprobe_unwind_native+0xd20>
     fc4:      	b	0x1580 <kprobe_unwind_native+0x1580>
     fc8:      	mov	w8, #0xa                // =10
     fcc:      	adrp	x10, 0x0 <kprobe_unwind_native>
     fd0:      	add	x10, x10, #0x0
     fd4:      	strh	w8, [sp, #0x58]
     fd8:      	ldp	x8, x9, [x10, #0x10]
     fdc:      	add	x0, sp, #0x28
     fe0:      	mov	w1, #0x32               // =50
     fe4:      	mov	x2, x21
     fe8:      	stp	x8, x9, [sp, #0x38]
     fec:      	ldp	x8, x9, [x10, #0x20]
     ff0:      	mov	w4, w19
     ff4:      	stp	x8, x9, [sp, #0x48]
     ff8:      	ldp	x8, x9, [x10]
     ffc:      	mov	w10, #0x32              // =50
    1000:      	stp	x8, x9, [sp, #0x28]
    1004:      	mov	w8, #0x6                // =6
    1008:      	add	x9, sp, #0x28
    100c:      	ldr	x3, [x22, #0xf00]
    1010:      	blr	x8
    1014:      	ldr	w8, [x24]
    1018:      	cbz	w8, 0xd88 <kprobe_unwind_native+0xd88>
    101c:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1020:      	add	x10, x10, #0x0
    1024:      	add	x0, sp, #0x28
    1028:      	ldp	x8, x9, [x10, #0x10]
    102c:      	mov	w1, #0x2f               // =47
    1030:      	stp	x8, x9, [sp, #0x38]
    1034:      	ldr	x8, [x10, #0x20]
    1038:      	str	x8, [sp, #0x48]
    103c:      	ldur	x8, [x10, #0x27]
    1040:      	stur	x8, [sp, #0x4f]
    1044:      	ldp	x8, x9, [x10]
    1048:      	mov	w10, #0x2f              // =47
    104c:      	stp	x8, x9, [sp, #0x28]
    1050:      	mov	w8, #0x6                // =6
    1054:      	add	x9, sp, #0x28
    1058:      	ldr	x2, [x22, #0xf10]
    105c:      	ldr	x3, [x22, #0xf08]
    1060:      	blr	x8
    1064:      	b	0xd88 <kprobe_unwind_native+0xd88>
    1068:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    106c:      	add	x10, x10, #0x0
    1070:      	add	x0, sp, #0x140
    1074:      	ldp	x8, x9, [x10, #0x10]
    1078:      	mov	w1, #0x30               // =48
    107c:      	mov	x2, x19
    1080:      	mov	x3, x25
    1084:      	stp	x8, x9, [sp, #0x150]
    1088:      	ldp	x8, x9, [x10, #0x20]
    108c:      	stp	x8, x9, [sp, #0x160]
    1090:      	ldp	x8, x9, [x10]
    1094:      	mov	w10, #0x30              // =48
    1098:      	stp	x8, x9, [sp, #0x140]
    109c:      	mov	w8, #0x6                // =6
    10a0:      	add	x9, sp, #0x140
    10a4:      	ldrh	w4, [x29, #0x6]
    10a8:      	blr	x8
    10ac:      	b	0x360 <kprobe_unwind_native+0x360>
    10b0:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    10b4:      	add	x10, x10, #0x0
    10b8:      	add	x0, sp, #0x28
    10bc:      	ldp	x8, x9, [x10, #0x10]
    10c0:      	mov	w1, #0x2e               // =46
    10c4:      	stp	x8, x9, [sp, #0x38]
    10c8:      	ldr	x8, [x10, #0x20]
    10cc:      	str	x8, [sp, #0x48]
    10d0:      	ldur	x8, [x10, #0x26]
    10d4:      	stur	x8, [sp, #0x4e]
    10d8:      	ldp	x8, x9, [x10]
    10dc:      	add	x10, sp, #0x28
    10e0:      	stp	x8, x9, [sp, #0x28]
    10e4:      	mov	w8, #0x6                // =6
    10e8:      	mov	w9, #0x2e               // =46
    10ec:      	ldr	w2, [sp, #0x140]
    10f0:      	blr	x8
    10f4:      	ldr	w8, [x24]
    10f8:      	cbz	w8, 0x108 <kprobe_unwind_native+0x108>
    10fc:      	b	0xa8 <kprobe_unwind_native+0xa8>
    1100:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1104:      	add	x10, x10, #0x0
    1108:      	add	x0, sp, #0x140
    110c:      	ldp	x8, x9, [x10, #0x10]
    1110:      	mov	w1, #0x2e               // =46
    1114:      	stp	x8, x9, [sp, #0x150]
    1118:      	ldr	x8, [x10, #0x20]
    111c:      	add	x9, sp, #0x140
    1120:      	str	x8, [sp, #0x160]
    1124:      	ldur	x8, [x10, #0x26]
    1128:      	stur	x8, [x9, #0x26]
    112c:      	ldp	x8, x9, [x10]
    1130:      	mov	w10, #0x2e              // =46
    1134:      	stp	x8, x9, [sp, #0x140]
    1138:      	mov	w8, #0x6                // =6
    113c:      	add	x9, sp, #0x140
    1140:      	ldr	w2, [sp, #0x180]
    1144:      	blr	x8
    1148:      	ldr	w8, [x24]
    114c:      	cbz	w8, 0xd08 <kprobe_unwind_native+0xd08>
    1150:      	b	0xcac <kprobe_unwind_native+0xcac>
    1154:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1158:      	add	x10, x10, #0x0
    115c:      	strb	wzr, [sp, #0x160]
    1160:      	add	x0, sp, #0x140
    1164:      	ldp	x8, x9, [x10]
    1168:      	mov	w1, #0x21               // =33
    116c:      	mov	w2, w21
    1170:      	stp	x8, x9, [sp, #0x140]
    1174:      	ldp	x8, x9, [x10, #0x10]
    1178:      	mov	w10, #0x21              // =33
    117c:      	stp	x8, x9, [sp, #0x150]
    1180:      	mov	w8, #0x6                // =6
    1184:      	add	x9, sp, #0x140
    1188:      	ldrb	w3, [x19, #0x2]
    118c:      	blr	x8
    1190:      	ldrb	w8, [x19, #0x2]
    1194:      	and	w9, w8, #0x7f
    1198:      	cmp	w21, w9
    119c:      	b.ge	0x884 <kprobe_unwind_native+0x884>
    11a0:      	b	0xa04 <kprobe_unwind_native+0xa04>
    11a4:      	adrp	x9, 0x1000 <kprobe_unwind_native+0x1000>
    11a8:      	add	x9, x9, #0x0
    11ac:      	mov	w10, #0xd               // =13
    11b0:      	ldr	x8, [x9]
    11b4:      	add	x0, sp, #0x140
    11b8:      	mov	w1, #0xd                // =13
    11bc:      	mov	x2, x29
    11c0:      	str	x8, [sp, #0x140]
    11c4:      	ldur	x8, [x9, #0x5]
    11c8:      	add	x9, sp, #0x140
    11cc:      	stur	x8, [x9, #0x5]
    11d0:      	mov	w8, #0x6                // =6
    11d4:      	blr	x8
    11d8:      	b	0xc08 <kprobe_unwind_native+0xc08>
    11dc:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    11e0:      	add	x10, x10, #0x0
    11e4:      	add	x0, sp, #0x140
    11e8:      	ldp	x8, x9, [x10, #0x10]
    11ec:      	mov	w1, #0x2e               // =46
    11f0:      	stp	x8, x9, [sp, #0x150]
    11f4:      	ldr	x8, [x10, #0x20]
    11f8:      	add	x9, sp, #0x140
    11fc:      	str	x8, [sp, #0x160]
    1200:      	ldur	x8, [x10, #0x26]
    1204:      	stur	x8, [x9, #0x26]
    1208:      	ldp	x8, x9, [x10]
    120c:      	mov	w10, #0x2e              // =46
    1210:      	stp	x8, x9, [sp, #0x140]
    1214:      	mov	w8, #0x6                // =6
    1218:      	add	x9, sp, #0x140
    121c:      	ldr	w2, [sp, #0x19c]
    1220:      	blr	x8
    1224:      	ldr	w8, [sp, #0x138]
    1228:      	tbz	w8, #0xf, 0x844 <kprobe_unwind_native+0x844>
    122c:      	b	0x8f0 <kprobe_unwind_native+0x8f0>
    1230:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1234:      	add	x10, x10, #0x0
    1238:      	strb	wzr, [sp, #0x160]
    123c:      	add	x0, sp, #0x140
    1240:      	ldp	x8, x9, [x10]
    1244:      	mov	w1, #0x21               // =33
    1248:      	stp	x8, x9, [sp, #0x140]
    124c:      	ldp	x8, x9, [x10, #0x10]
    1250:      	mov	w10, #0x21              // =33
    1254:      	stp	x8, x9, [sp, #0x150]
    1258:      	mov	w8, #0x6                // =6
    125c:      	add	x9, sp, #0x140
    1260:      	ldr	w2, [sp, #0x138]
    1264:      	blr	x8
    1268:      	b	0xa04 <kprobe_unwind_native+0xa04>
    126c:      	mov	w8, #0x726c             // =29292
    1270:      	add	x9, sp, #0x140
    1274:      	mov	w10, #0xc               // =12
    1278:      	add	x0, sp, #0x140
    127c:      	mov	w1, #0xc                // =12
    1280:      	movk	w8, #0xa, lsl #16
    1284:      	str	w8, [sp, #0x148]
    1288:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    128c:      	add	x8, x8, #0x0
    1290:      	ldr	x8, [x8]
    1294:      	str	x8, [sp, #0x140]
    1298:      	mov	w8, #0x6                // =6
    129c:      	blr	x8
    12a0:      	ldr	x29, [x22, #0xee8]
    12a4:      	cbnz	x29, 0xbe4 <kprobe_unwind_native+0xbe4>
    12a8:      	b	0x1758 <kprobe_unwind_native+0x1758>
    12ac:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    12b0:      	add	x10, x10, #0x0
    12b4:      	mov	x19, x0
    12b8:      	ldp	x8, x9, [x10]
    12bc:      	mov	w1, #0x1e               // =30
    12c0:      	stp	x8, x9, [sp, #0x28]
    12c4:      	ldr	x8, [x10, #0x10]
    12c8:      	add	x9, sp, #0x28
    12cc:      	str	x8, [sp, #0x38]
    12d0:      	ldur	x8, [x10, #0x16]
    12d4:      	mov	w10, #0x1e              // =30
    12d8:      	stur	x8, [sp, #0x3e]
    12dc:      	mov	w8, #0x6                // =6
    12e0:      	ldrh	w2, [x0, #0x20]
    12e4:      	add	x0, sp, #0x28
    12e8:      	blr	x8
    12ec:      	mov	x0, x19
    12f0:      	ldrh	w8, [x19, #0x20]
    12f4:      	ldr	w9, [x22, #0x1370]
    12f8:      	lsr	w8, w9, w8
    12fc:      	tbnz	w8, #0x0, 0xe04 <kprobe_unwind_native+0xe04>
    1300:      	str	wzr, [sp, #0x180]
    1304:      	mov	w8, #0x1                // =1
    1308:      	add	x9, sp, #0x180
    130c:      	mov	x19, x0
    1310:      	add	x1, sp, #0x180
    1314:      	mov	x0, x25
    1318:      	blr	x8
    131c:      	cbz	x0, 0x1334 <kprobe_unwind_native+0x1334>
    1320:      	ldr	x8, [x0]
    1324:      	add	x8, x8, #0x1
    1328:      	str	x8, [x0]
    132c:      	mov	x8, x19
    1330:      	b	0x1340 <kprobe_unwind_native+0x1340>
    1334:      	ldr	w9, [x24]
    1338:      	mov	x8, x19
    133c:      	cbnz	w9, 0x1430 <kprobe_unwind_native+0x1430>
    1340:      	ldrh	w19, [x8, #0x20]
    1344:      	ldr	w8, [sp, #0x1ac]
    1348:      	cmp	w19, #0x1
    134c:      	b.eq	0xe30 <kprobe_unwind_native+0xe30>
    1350:      	b	0x15d4 <kprobe_unwind_native+0x15d4>
    1354:      	mov	w8, #0x726c             // =29292
    1358:      	add	x9, sp, #0x140
    135c:      	mov	w10, #0xc               // =12
    1360:      	add	x0, sp, #0x140
    1364:      	mov	w1, #0xc                // =12
    1368:      	movk	w8, #0xa, lsl #16
    136c:      	str	w8, [sp, #0x148]
    1370:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1374:      	add	x8, x8, #0x0
    1378:      	ldr	x8, [x8]
    137c:      	str	x8, [sp, #0x140]
    1380:      	mov	w8, #0x6                // =6
    1384:      	blr	x8
    1388:      	ldr	x21, [x22, #0xee8]
    138c:      	cbnz	x21, 0xb40 <kprobe_unwind_native+0xb40>
    1390:      	b	0xa78 <kprobe_unwind_native+0xa78>
    1394:      	mov	w8, #0x656e             // =25966
    1398:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    139c:      	add	x10, x10, #0x0
    13a0:      	add	x0, sp, #0x28
    13a4:      	mov	w1, #0x1b               // =27
    13a8:      	movk	w8, #0xa, lsl #16
    13ac:      	stur	w8, [sp, #0x3f]
    13b0:      	ldp	x8, x9, [x10]
    13b4:      	stp	x8, x9, [sp, #0x28]
    13b8:      	ldr	x8, [x10, #0x10]
    13bc:      	add	x9, sp, #0x28
    13c0:      	mov	w10, #0x1b              // =27
    13c4:      	str	x8, [sp, #0x38]
    13c8:      	mov	w8, #0x6                // =6
    13cc:      	blr	x8
    13d0:      	mov	w19, #0x1               // =1
    13d4:      	ldr	w8, [sp, #0x1ac]
    13d8:      	cmp	w19, #0x1
    13dc:      	b.eq	0xe30 <kprobe_unwind_native+0xe30>
    13e0:      	b	0x15d4 <kprobe_unwind_native+0x15d4>
    13e4:      	mov	w8, #0x786c             // =30828
    13e8:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    13ec:      	add	x10, x10, #0x0
    13f0:      	add	x0, sp, #0x140
    13f4:      	mov	w1, #0x2c               // =44
    13f8:      	mov	x2, x21
    13fc:      	movk	w8, #0xa, lsl #16
    1400:      	str	w8, [sp, #0x168]
    1404:      	ldp	x8, x9, [x10, #0x10]
    1408:      	stp	x8, x9, [sp, #0x150]
    140c:      	ldr	x8, [x10, #0x20]
    1410:      	str	x8, [sp, #0x160]
    1414:      	ldp	x9, x8, [x10]
    1418:      	mov	w10, #0x2c              // =44
    141c:      	stp	x9, x8, [sp, #0x140]
    1420:      	mov	w8, #0x6                // =6
    1424:      	add	x9, sp, #0x140
    1428:      	blr	x8
    142c:      	b	0xb24 <kprobe_unwind_native+0xb24>
    1430:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1434:      	add	x10, x10, #0x0
    1438:      	add	x0, sp, #0x28
    143c:      	ldp	x8, x9, [x10, #0x10]
    1440:      	mov	w1, #0x2e               // =46
    1444:      	stp	x8, x9, [sp, #0x38]
    1448:      	ldr	x8, [x10, #0x20]
    144c:      	str	x8, [sp, #0x48]
    1450:      	ldur	x8, [x10, #0x26]
    1454:      	stur	x8, [sp, #0x4e]
    1458:      	ldp	x8, x9, [x10]
    145c:      	add	x10, sp, #0x28
    1460:      	stp	x8, x9, [sp, #0x28]
    1464:      	mov	w8, #0x6                // =6
    1468:      	mov	w9, #0x2e               // =46
    146c:      	ldr	w2, [sp, #0x180]
    1470:      	blr	x8
    1474:      	b	0x132c <kprobe_unwind_native+0x132c>
    1478:      	adrp	x24, 0x1000 <kprobe_unwind_native+0x1000>
    147c:      	adrp	x25, 0x1000 <kprobe_unwind_native+0x1000>
    1480:      	ldr	x24, [x24]
    1484:      	ldr	x25, [x25]
    1488:      	ldr	w8, [x24]
    148c:      	cbnz	w8, 0x19c4 <kprobe_unwind_native+0x19c4>
    1490:      	mov	w9, #0x9                // =9
    1494:      	mov	w8, #0xfa3              // =4003
    1498:      	mov	w19, wzr
    149c:      	str	w9, [x22, #0xf18]
    14a0:      	b	0x1888 <kprobe_unwind_native+0x1888>
    14a4:      	ldr	w8, [x24]
    14a8:      	cbnz	w8, 0x1a58 <kprobe_unwind_native+0x1a58>
    14ac:      	mov	w8, #0x2                // =2
    14b0:      	add	x9, sp, #0x140
    14b4:      	add	x1, sp, #0x140
    14b8:      	str	w8, [sp, #0x140]
    14bc:      	mov	w8, #0x1                // =1
    14c0:      	mov	x0, x25
    14c4:      	blr	x8
    14c8:      	cbz	x0, 0x1688 <kprobe_unwind_native+0x1688>
    14cc:      	ldr	x8, [x0]
    14d0:      	add	x8, x8, #0x1
    14d4:      	str	x8, [x0]
    14d8:      	ldr	w8, [x24]
    14dc:      	cbz	w8, 0x1690 <kprobe_unwind_native+0x1690>
    14e0:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    14e4:      	add	x8, x8, #0x0
    14e8:      	add	x0, sp, #0x28
    14ec:      	ldp	x9, x10, [x8]
    14f0:      	mov	w1, #0x1d               // =29
    14f4:      	stp	x9, x10, [sp, #0x28]
    14f8:      	ldr	x9, [x8, #0x10]
    14fc:      	ldur	x8, [x8, #0x15]
    1500:      	add	x10, sp, #0x28
    1504:      	str	x9, [sp, #0x38]
    1508:      	stur	x8, [sp, #0x3d]
    150c:      	mov	w8, #0x1d               // =29
    1510:      	mov	w9, #0x6                // =6
    1514:      	blr	x9
    1518:      	b	0x1690 <kprobe_unwind_native+0x1690>
    151c:      	ldr	w8, [x24]
    1520:      	cbnz	w8, 0x1a94 <kprobe_unwind_native+0x1a94>
    1524:      	mov	w9, #0x8                // =8
    1528:      	mov	w8, #0xfa0              // =4000
    152c:      	mov	w19, wzr
    1530:      	str	w9, [x22, #0xf18]
    1534:      	b	0x1888 <kprobe_unwind_native+0x1888>
    1538:      	ldr	w8, [x24]
    153c:      	cbnz	w8, 0x1ae4 <kprobe_unwind_native+0x1ae4>
    1540:      	mov	w9, #0x32               // =50
    1544:      	mov	w8, #0xfa2              // =4002
    1548:      	mov	w19, wzr
    154c:      	str	w9, [x22, #0xf18]
    1550:      	b	0x1888 <kprobe_unwind_native+0x1888>
    1554:      	mov	w9, #0xa                // =10
    1558:      	mov	w8, #0xfa4              // =4004
    155c:      	mov	w19, wzr
    1560:      	str	w9, [x22, #0xf18]
    1564:      	b	0x1888 <kprobe_unwind_native+0x1888>
    1568:      	cbnz	w8, 0x1b34 <kprobe_unwind_native+0x1b34>
    156c:      	mov	w8, #0x1                // =1
    1570:      	mov	w19, wzr
    1574:      	str	w8, [x22, #0xf18]
    1578:      	mov	w8, #0xfad              // =4013
    157c:      	b	0x1888 <kprobe_unwind_native+0x1888>
    1580:      	ldr	w8, [x24]
    1584:      	cbnz	w8, 0x1b74 <kprobe_unwind_native+0x1b74>
    1588:      	mov	w8, #0xb                // =11
    158c:      	mov	w19, wzr
    1590:      	str	w8, [x22, #0xf18]
    1594:      	mov	w8, #0xfab              // =4011
    1598:      	b	0x1888 <kprobe_unwind_native+0x1888>
    159c:      	ldr	w8, [x24]
    15a0:      	cbnz	w8, 0x1bb4 <kprobe_unwind_native+0x1bb4>
    15a4:      	mov	w8, #0x31               // =49
    15a8:      	mov	w19, wzr
    15ac:      	str	w8, [x22, #0xf18]
    15b0:      	mov	w8, #0xfae              // =4014
    15b4:      	b	0x1888 <kprobe_unwind_native+0x1888>
    15b8:      	ldr	w8, [x24]
    15bc:      	cbnz	w8, 0x1bf4 <kprobe_unwind_native+0x1bf4>
    15c0:      	mov	w8, #0xc                // =12
    15c4:      	mov	w19, wzr
    15c8:      	str	w8, [x22, #0xf18]
    15cc:      	mov	w8, #0xfac              // =4012
    15d0:      	b	0x1888 <kprobe_unwind_native+0x1888>
    15d4:      	mov	w8, wzr
    15d8:      	b	0x1888 <kprobe_unwind_native+0x1888>
    15dc:      	mov	w8, wzr
    15e0:      	mov	w19, #0x1               // =1
    15e4:      	b	0x1888 <kprobe_unwind_native+0x1888>
    15e8:      	mov	w9, #0xd                // =13
    15ec:      	mov	w8, #0xfa5              // =4005
    15f0:      	mov	w19, wzr
    15f4:      	str	w9, [x22, #0xf18]
    15f8:      	b	0x1888 <kprobe_unwind_native+0x1888>
    15fc:      	mov	w8, #0x55               // =85
    1600:      	add	x9, sp, #0x180
    1604:      	add	x1, sp, #0x180
    1608:      	str	w8, [sp, #0x180]
    160c:      	mov	w8, #0x1                // =1
    1610:      	mov	x0, x25
    1614:      	blr	x8
    1618:      	cbz	x0, 0x16f4 <kprobe_unwind_native+0x16f4>
    161c:      	ldr	x8, [x0]
    1620:      	add	x8, x8, #0x1
    1624:      	str	x8, [x0]
    1628:      	ldr	w8, [x24]
    162c:      	cbz	w8, 0x16fc <kprobe_unwind_native+0x16fc>
    1630:      	mov	w8, #0xa                // =10
    1634:      	add	x0, sp, #0x140
    1638:      	mov	w1, #0x32               // =50
    163c:      	strh	w8, [sp, #0x170]
    1640:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1644:      	add	x8, x8, #0x0
    1648:      	ldp	x9, x10, [x8, #0x10]
    164c:      	stp	x9, x10, [sp, #0x150]
    1650:      	ldp	x9, x10, [x8, #0x20]
    1654:      	stp	x9, x10, [sp, #0x160]
    1658:      	ldp	x9, x8, [x8]
    165c:      	add	x10, sp, #0x140
    1660:      	stp	x9, x8, [sp, #0x140]
    1664:      	mov	w8, #0x32               // =50
    1668:      	mov	w9, #0x6                // =6
    166c:      	blr	x9
    1670:      	mov	w8, #0xfaf              // =4015
    1674:      	b	0x1884 <kprobe_unwind_native+0x1884>
    1678:      	cmp	w8, #0x1
    167c:      	b.ne	0x169c <kprobe_unwind_native+0x169c>
    1680:      	mov	w8, wzr
    1684:      	b	0x1884 <kprobe_unwind_native+0x1884>
    1688:      	ldr	w8, [x24]
    168c:      	cbnz	w8, 0x1c94 <kprobe_unwind_native+0x1c94>
    1690:      	mov	w19, wzr
    1694:      	mov	w8, #0x2                // =2
    1698:      	b	0x1888 <kprobe_unwind_native+0x1888>
    169c:      	mov	w8, #0x1                // =1
    16a0:      	b	0x1884 <kprobe_unwind_native+0x1884>
    16a4:      	mov	w8, #0x51               // =81
    16a8:      	add	x9, sp, #0x180
    16ac:      	add	x1, sp, #0x180
    16b0:      	str	w8, [sp, #0x180]
    16b4:      	mov	w8, #0x1                // =1
    16b8:      	mov	x0, x25
    16bc:      	blr	x8
    16c0:      	cbz	x0, 0x17d4 <kprobe_unwind_native+0x17d4>
    16c4:      	ldr	x8, [x0]
    16c8:      	mov	w19, wzr
    16cc:      	add	x8, x8, #0x1
    16d0:      	str	x8, [x0]
    16d4:      	mov	w8, #0xfa8              // =4008
    16d8:      	b	0x1888 <kprobe_unwind_native+0x1888>
    16dc:      	adrp	x9, 0x1000 <kprobe_unwind_native+0x1000>
    16e0:      	ldr	x9, [x9]
    16e4:      	ldr	x9, [x9]
    16e8:      	and	x8, x9, x8
    16ec:      	str	x8, [x23]
    16f0:      	b	0x1808 <kprobe_unwind_native+0x1808>
    16f4:      	ldr	w8, [x24]
    16f8:      	cbnz	w8, 0x1ce4 <kprobe_unwind_native+0x1ce4>
    16fc:      	mov	w8, #0xfaf              // =4015
    1700:      	b	0x1884 <kprobe_unwind_native+0x1884>
    1704:      	ldr	w8, [x24]
    1708:      	cbz	w8, 0x1808 <kprobe_unwind_native+0x1808>
    170c:      	mov	w8, #0x786c             // =30828
    1710:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1714:      	add	x10, x10, #0x0
    1718:      	add	x0, sp, #0x140
    171c:      	mov	w1, #0x2c               // =44
    1720:      	mov	x2, x29
    1724:      	movk	w8, #0xa, lsl #16
    1728:      	str	w8, [sp, #0x168]
    172c:      	ldp	x8, x9, [x10, #0x10]
    1730:      	stp	x8, x9, [sp, #0x150]
    1734:      	ldr	x8, [x10, #0x20]
    1738:      	str	x8, [sp, #0x160]
    173c:      	ldp	x9, x8, [x10]
    1740:      	add	x10, sp, #0x140
    1744:      	stp	x9, x8, [sp, #0x140]
    1748:      	mov	w8, #0x2c               // =44
    174c:      	mov	w9, #0x6                // =6
    1750:      	blr	x9
    1754:      	b	0x1808 <kprobe_unwind_native+0x1808>
    1758:      	mov	w8, #0x3c               // =60
    175c:      	add	x9, sp, #0x190
    1760:      	add	x1, sp, #0x190
    1764:      	str	w8, [sp, #0x190]
    1768:      	mov	w8, #0x1                // =1
    176c:      	mov	x0, x25
    1770:      	blr	x8
    1774:      	cbz	x0, 0x1800 <kprobe_unwind_native+0x1800>
    1778:      	ldr	x8, [x0]
    177c:      	add	x8, x8, #0x1
    1780:      	str	x8, [x0]
    1784:      	ldr	w8, [x24]
    1788:      	cbz	w8, 0x1808 <kprobe_unwind_native+0x1808>
    178c:      	mov	w8, #0xa                // =10
    1790:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1794:      	add	x10, x10, #0x0
    1798:      	strh	w8, [sp, #0x168]
    179c:      	ldp	x8, x9, [x10, #0x10]
    17a0:      	add	x0, sp, #0x140
    17a4:      	mov	w1, #0x2a               // =42
    17a8:      	stp	x8, x9, [sp, #0x150]
    17ac:      	ldr	x8, [x10, #0x20]
    17b0:      	str	x8, [sp, #0x160]
    17b4:      	ldp	x9, x8, [x10]
    17b8:      	add	x10, sp, #0x140
    17bc:      	stp	x9, x8, [sp, #0x140]
    17c0:      	mov	w8, #0x2a               // =42
    17c4:      	mov	w9, #0x6                // =6
    17c8:      	ldr	x2, [x23]
    17cc:      	blr	x9
    17d0:      	b	0x1808 <kprobe_unwind_native+0x1808>
    17d4:      	ldr	w8, [x24]
    17d8:      	cbnz	w8, 0x1d38 <kprobe_unwind_native+0x1d38>
    17dc:      	mov	w8, #0xfa8              // =4008
    17e0:      	b	0x1884 <kprobe_unwind_native+0x1884>
    17e4:      	ldr	w8, [x24]
    17e8:      	cbnz	w8, 0x1d84 <kprobe_unwind_native+0x1d84>
    17ec:      	mov	w9, #0x33               // =51
    17f0:      	mov	w8, #0xfa1              // =4001
    17f4:      	mov	w19, wzr
    17f8:      	str	w9, [x22, #0xf18]
    17fc:      	b	0x1888 <kprobe_unwind_native+0x1888>
    1800:      	ldr	w8, [x24]
    1804:      	cbnz	w8, 0x1ddc <kprobe_unwind_native+0x1ddc>
    1808:      	mov	w8, #0xe                // =14
    180c:      	add	x9, sp, #0x180
    1810:      	add	x1, sp, #0x180
    1814:      	str	w8, [sp, #0x180]
    1818:      	mov	w8, #0x1                // =1
    181c:      	mov	x0, x25
    1820:      	blr	x8
    1824:      	cbz	x0, 0x1878 <kprobe_unwind_native+0x1878>
    1828:      	ldr	x8, [x0]
    182c:      	add	x8, x8, #0x1
    1830:      	str	x8, [x0]
    1834:      	ldr	w8, [x24]
    1838:      	cbz	w8, 0x1880 <kprobe_unwind_native+0x1880>
    183c:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1840:      	add	x8, x8, #0x0
    1844:      	add	x0, sp, #0x140
    1848:      	ldp	x9, x10, [x8, #0x10]
    184c:      	mov	w1, #0x28               // =40
    1850:      	stp	x9, x10, [sp, #0x150]
    1854:      	ldr	x9, [x8, #0x20]
    1858:      	add	x10, sp, #0x140
    185c:      	str	x9, [sp, #0x160]
    1860:      	ldp	x8, x9, [x8]
    1864:      	stp	x8, x9, [sp, #0x140]
    1868:      	mov	w8, #0x28               // =40
    186c:      	mov	w9, #0x6                // =6
    1870:      	blr	x9
    1874:      	b	0x1880 <kprobe_unwind_native+0x1880>
    1878:      	ldr	w8, [x24]
    187c:      	cbnz	w8, 0x1c40 <kprobe_unwind_native+0x1c40>
    1880:      	mov	w8, #0xfa7              // =4007
    1884:      	mov	w19, wzr
    1888:      	str	w8, [x22, #0xf1c]
    188c:      	str	wzr, [sp, #0x28]
    1890:      	adrp	x0, 0x1000 <kprobe_unwind_native+0x1000>
    1894:      	mov	w8, #0x1                // =1
    1898:      	add	x9, sp, #0x28
    189c:      	add	x1, sp, #0x28
    18a0:      	ldr	x0, [x0]
    18a4:      	blr	x8
    18a8:      	cbz	x0, 0x18fc <kprobe_unwind_native+0x18fc>
    18ac:      	mov	w20, #0x1374            // =4980
    18b0:      	mov	w2, w19
    18b4:      	ldrb	w8, [x0, x20]
    18b8:      	cmp	w8, #0x1d
    18bc:      	b.lo	0x192c <kprobe_unwind_native+0x192c>
    18c0:      	mov	w8, #0x5                // =5
    18c4:      	add	x9, sp, #0x140
    18c8:      	mov	x21, x0
    18cc:      	str	w8, [x0, #0xf1c]
    18d0:      	mov	w8, #0x44               // =68
    18d4:      	add	x1, sp, #0x140
    18d8:      	mov	x0, x25
    18dc:      	str	w8, [sp, #0x140]
    18e0:      	mov	w8, #0x1                // =1
    18e4:      	blr	x8
    18e8:      	cbz	x0, 0x1918 <kprobe_unwind_native+0x1918>
    18ec:      	ldr	x8, [x0]
    18f0:      	add	x8, x8, #0x1
    18f4:      	str	x8, [x0]
    18f8:      	b	0x1920 <kprobe_unwind_native+0x1920>
    18fc:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1900:      	mov	x9, xzr
    1904:      	mov	w8, #0xc                // =12
    1908:      	ldr	x10, [x10]
    190c:      	ldr	x0, [sp, #0x10]
    1910:      	mov	w2, wzr
    1914:      	b	0x1948 <kprobe_unwind_native+0x1948>
    1918:      	ldr	w8, [x24]
    191c:      	cbnz	w8, 0x1a10 <kprobe_unwind_native+0x1a10>
    1920:      	ldrb	w8, [x21, x20]
    1924:      	mov	w2, wzr
    1928:      	mov	x0, x21
    192c:      	add	w8, w8, #0x1
    1930:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1934:      	mov	w9, w2
    1938:      	strb	w8, [x0, x20]
    193c:      	mov	w8, #0xc                // =12
    1940:      	ldr	x10, [x10]
    1944:      	ldr	x0, [sp, #0x10]
    1948:      	adrp	x1, 0x1000 <kprobe_unwind_native+0x1000>
    194c:      	ldr	x1, [x1]
    1950:      	blr	x8
    1954:      	ldr	w8, [x24]
    1958:      	cbnz	w8, 0x197c <kprobe_unwind_native+0x197c>
    195c:      	ldp	x20, x19, [sp, #0x1e0]
    1960:      	mov	w0, #-0x1               // =-1
    1964:      	ldr	x29, [sp, #0x1a0]
    1968:      	ldp	x22, x21, [sp, #0x1d0]
    196c:      	ldp	x24, x23, [sp, #0x1c0]
    1970:      	ldp	x30, x25, [sp, #0x1b0]
    1974:      	add	sp, sp, #0x1f0
    1978:      	ret
    197c:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1980:      	add	x8, x8, #0x0
    1984:      	add	x0, sp, #0x28
    1988:      	ldp	x9, x10, [x8, #0x10]
    198c:      	mov	w1, #0x2e               // =46
    1990:      	mov	w2, w19
    1994:      	stp	x9, x10, [sp, #0x38]
    1998:      	ldr	x9, [x8, #0x20]
    199c:      	add	x10, sp, #0x28
    19a0:      	str	x9, [sp, #0x48]
    19a4:      	ldur	x9, [x8, #0x26]
    19a8:      	stur	x9, [sp, #0x4e]
    19ac:      	ldp	x9, x8, [x8]
    19b0:      	stp	x9, x8, [sp, #0x28]
    19b4:      	mov	w8, #0x2e               // =46
    19b8:      	mov	w9, #0x6                // =6
    19bc:      	blr	x9
    19c0:      	b	0x195c <kprobe_unwind_native+0x195c>
    19c4:      	mov	w8, #0x3f61             // =16225
    19c8:      	add	x9, sp, #0x140
    19cc:      	add	x0, sp, #0x140
    19d0:      	mov	w1, #0x2b               // =43
    19d4:      	movk	w8, #0xa, lsl #16
    19d8:      	stur	w8, [x9, #0x27]
    19dc:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    19e0:      	add	x8, x8, #0x0
    19e4:      	ldp	x9, x10, [x8, #0x10]
    19e8:      	stp	x9, x10, [sp, #0x150]
    19ec:      	ldr	x9, [x8, #0x20]
    19f0:      	add	x10, sp, #0x140
    19f4:      	str	x9, [sp, #0x160]
    19f8:      	ldp	x8, x9, [x8]
    19fc:      	stp	x8, x9, [sp, #0x140]
    1a00:      	mov	w8, #0x2b               // =43
    1a04:      	mov	w9, #0x6                // =6
    1a08:      	blr	x9
    1a0c:      	b	0x1490 <kprobe_unwind_native+0x1490>
    1a10:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1a14:      	add	x10, x10, #0x0
    1a18:      	add	x0, sp, #0x28
    1a1c:      	ldp	x8, x9, [x10, #0x10]
    1a20:      	mov	w1, #0x2e               // =46
    1a24:      	stp	x8, x9, [sp, #0x38]
    1a28:      	ldr	x8, [x10, #0x20]
    1a2c:      	str	x8, [sp, #0x48]
    1a30:      	ldur	x8, [x10, #0x26]
    1a34:      	stur	x8, [sp, #0x4e]
    1a38:      	ldp	x8, x9, [x10]
    1a3c:      	add	x10, sp, #0x28
    1a40:      	stp	x8, x9, [sp, #0x28]
    1a44:      	mov	w8, #0x2e               // =46
    1a48:      	mov	w9, #0x6                // =6
    1a4c:      	ldr	w2, [sp, #0x140]
    1a50:      	blr	x9
    1a54:      	b	0x1920 <kprobe_unwind_native+0x1920>
    1a58:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1a5c:      	add	x8, x8, #0x0
    1a60:      	add	x0, sp, #0x28
    1a64:      	ldp	x9, x10, [x8, #0x10]
    1a68:      	mov	w1, #0x25               // =37
    1a6c:      	stp	x9, x10, [sp, #0x38]
    1a70:      	ldur	x9, [x8, #0x1d]
    1a74:      	add	x10, sp, #0x28
    1a78:      	stur	x9, [sp, #0x45]
    1a7c:      	ldp	x8, x9, [x8]
    1a80:      	stp	x8, x9, [sp, #0x28]
    1a84:      	mov	w8, #0x25               // =37
    1a88:      	mov	w9, #0x6                // =6
    1a8c:      	blr	x9
    1a90:      	b	0x14ac <kprobe_unwind_native+0x14ac>
    1a94:      	mov	w8, #0xa                // =10
    1a98:      	add	x0, sp, #0x140
    1a9c:      	mov	w1, #0x3a               // =58
    1aa0:      	strh	w8, [sp, #0x178]
    1aa4:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1aa8:      	add	x8, x8, #0x0
    1aac:      	ldp	x9, x10, [x8, #0x20]
    1ab0:      	stp	x9, x10, [sp, #0x160]
    1ab4:      	ldr	x9, [x8, #0x30]
    1ab8:      	str	x9, [sp, #0x170]
    1abc:      	ldp	x9, x10, [x8]
    1ac0:      	stp	x9, x10, [sp, #0x140]
    1ac4:      	ldp	x8, x9, [x8, #0x10]
    1ac8:      	add	x10, sp, #0x140
    1acc:      	stp	x8, x9, [sp, #0x150]
    1ad0:      	mov	w8, #0x3a               // =58
    1ad4:      	mov	w9, #0x6                // =6
    1ad8:      	ldp	x2, x3, [sp, #0x180]
    1adc:      	blr	x9
    1ae0:      	b	0x1524 <kprobe_unwind_native+0x1524>
    1ae4:      	mov	w8, #0x786c             // =30828
    1ae8:      	add	x9, sp, #0x140
    1aec:      	add	x0, sp, #0x140
    1af0:      	mov	w1, #0x33               // =51
    1af4:      	movk	w8, #0xa, lsl #16
    1af8:      	stur	w8, [x9, #0x2f]
    1afc:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1b00:      	add	x8, x8, #0x0
    1b04:      	ldp	x9, x10, [x8, #0x10]
    1b08:      	stp	x9, x10, [sp, #0x150]
    1b0c:      	ldp	x9, x10, [x8, #0x20]
    1b10:      	stp	x9, x10, [sp, #0x160]
    1b14:      	ldp	x9, x8, [x8]
    1b18:      	add	x10, sp, #0x140
    1b1c:      	stp	x9, x8, [sp, #0x140]
    1b20:      	mov	w8, #0x33               // =51
    1b24:      	mov	w9, #0x6                // =6
    1b28:      	ldr	x2, [sp, #0x190]
    1b2c:      	blr	x9
    1b30:      	b	0x1540 <kprobe_unwind_native+0x1540>
    1b34:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1b38:      	add	x8, x8, #0x0
    1b3c:      	strb	wzr, [sp, #0x58]
    1b40:      	add	x0, sp, #0x28
    1b44:      	ldp	x9, x10, [x8, #0x10]
    1b48:      	mov	w1, #0x31               // =49
    1b4c:      	stp	x9, x10, [sp, #0x38]
    1b50:      	ldp	x9, x10, [x8, #0x20]
    1b54:      	stp	x9, x10, [sp, #0x48]
    1b58:      	ldp	x9, x8, [x8]
    1b5c:      	add	x10, sp, #0x28
    1b60:      	stp	x9, x8, [sp, #0x28]
    1b64:      	mov	w8, #0x31               // =49
    1b68:      	mov	w9, #0x6                // =6
    1b6c:      	blr	x9
    1b70:      	b	0x156c <kprobe_unwind_native+0x156c>
    1b74:      	mov	w8, #0xa                // =10
    1b78:      	add	x0, sp, #0x28
    1b7c:      	mov	w1, #0x22               // =34
    1b80:      	strh	w8, [sp, #0x48]
    1b84:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1b88:      	add	x8, x8, #0x0
    1b8c:      	mov	x2, x21
    1b90:      	ldp	x9, x10, [x8]
    1b94:      	stp	x9, x10, [sp, #0x28]
    1b98:      	ldp	x9, x8, [x8, #0x10]
    1b9c:      	add	x10, sp, #0x28
    1ba0:      	stp	x9, x8, [sp, #0x38]
    1ba4:      	mov	w8, #0x22               // =34
    1ba8:      	mov	w9, #0x6                // =6
    1bac:      	blr	x9
    1bb0:      	b	0x1588 <kprobe_unwind_native+0x1588>
    1bb4:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1bb8:      	add	x8, x8, #0x0
    1bbc:      	add	x0, sp, #0x28
    1bc0:      	ldp	x9, x10, [x8]
    1bc4:      	mov	w1, #0x1e               // =30
    1bc8:      	mov	x2, x21
    1bcc:      	stp	x9, x10, [sp, #0x28]
    1bd0:      	ldr	x9, [x8, #0x10]
    1bd4:      	ldur	x8, [x8, #0x16]
    1bd8:      	add	x10, sp, #0x28
    1bdc:      	str	x9, [sp, #0x38]
    1be0:      	stur	x8, [sp, #0x3e]
    1be4:      	mov	w8, #0x1e               // =30
    1be8:      	mov	w9, #0x6                // =6
    1bec:      	blr	x9
    1bf0:      	b	0x15a4 <kprobe_unwind_native+0x15a4>
    1bf4:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1bf8:      	add	x8, x8, #0x0
    1bfc:      	strb	wzr, [sp, #0x60]
    1c00:      	add	x0, sp, #0x28
    1c04:      	ldp	x9, x10, [x8, #0x20]
    1c08:      	mov	w1, #0x39               // =57
    1c0c:      	mov	x2, x21
    1c10:      	stp	x9, x10, [sp, #0x48]
    1c14:      	ldr	x9, [x8, #0x30]
    1c18:      	str	x9, [sp, #0x58]
    1c1c:      	ldp	x9, x10, [x8]
    1c20:      	stp	x9, x10, [sp, #0x28]
    1c24:      	ldp	x8, x9, [x8, #0x10]
    1c28:      	add	x10, sp, #0x28
    1c2c:      	stp	x8, x9, [sp, #0x38]
    1c30:      	mov	w8, #0x39               // =57
    1c34:      	mov	w9, #0x6                // =6
    1c38:      	blr	x9
    1c3c:      	b	0x15c0 <kprobe_unwind_native+0x15c0>
    1c40:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1c44:      	add	x10, x10, #0x0
    1c48:      	add	x0, sp, #0x140
    1c4c:      	ldp	x8, x9, [x10, #0x10]
    1c50:      	mov	w1, #0x2e               // =46
    1c54:      	stp	x8, x9, [sp, #0x150]
    1c58:      	ldr	x8, [x10, #0x20]
    1c5c:      	add	x9, sp, #0x140
    1c60:      	str	x8, [sp, #0x160]
    1c64:      	ldur	x8, [x10, #0x26]
    1c68:      	stur	x8, [x9, #0x26]
    1c6c:      	ldp	x8, x9, [x10]
    1c70:      	add	x10, sp, #0x140
    1c74:      	stp	x8, x9, [sp, #0x140]
    1c78:      	mov	w8, #0x2e               // =46
    1c7c:      	mov	w9, #0x6                // =6
    1c80:      	ldr	w2, [sp, #0x180]
    1c84:      	blr	x9
    1c88:      	ldr	w8, [x24]
    1c8c:      	cbz	w8, 0x1880 <kprobe_unwind_native+0x1880>
    1c90:      	b	0x183c <kprobe_unwind_native+0x183c>
    1c94:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1c98:      	add	x10, x10, #0x0
    1c9c:      	add	x0, sp, #0x28
    1ca0:      	ldp	x8, x9, [x10, #0x10]
    1ca4:      	mov	w1, #0x2e               // =46
    1ca8:      	stp	x8, x9, [sp, #0x38]
    1cac:      	ldr	x8, [x10, #0x20]
    1cb0:      	str	x8, [sp, #0x48]
    1cb4:      	ldur	x8, [x10, #0x26]
    1cb8:      	stur	x8, [sp, #0x4e]
    1cbc:      	ldp	x8, x9, [x10]
    1cc0:      	add	x10, sp, #0x28
    1cc4:      	stp	x8, x9, [sp, #0x28]
    1cc8:      	mov	w8, #0x2e               // =46
    1ccc:      	mov	w9, #0x6                // =6
    1cd0:      	ldr	w2, [sp, #0x140]
    1cd4:      	blr	x9
    1cd8:      	ldr	w8, [x24]
    1cdc:      	cbz	w8, 0x1690 <kprobe_unwind_native+0x1690>
    1ce0:      	b	0x14e0 <kprobe_unwind_native+0x14e0>
    1ce4:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1ce8:      	add	x10, x10, #0x0
    1cec:      	add	x0, sp, #0x140
    1cf0:      	ldp	x8, x9, [x10, #0x10]
    1cf4:      	mov	w1, #0x2e               // =46
    1cf8:      	stp	x8, x9, [sp, #0x150]
    1cfc:      	ldr	x8, [x10, #0x20]
    1d00:      	add	x9, sp, #0x140
    1d04:      	str	x8, [sp, #0x160]
    1d08:      	ldur	x8, [x10, #0x26]
    1d0c:      	stur	x8, [x9, #0x26]
    1d10:      	ldp	x8, x9, [x10]
    1d14:      	add	x10, sp, #0x140
    1d18:      	stp	x8, x9, [sp, #0x140]
    1d1c:      	mov	w8, #0x2e               // =46
    1d20:      	mov	w9, #0x6                // =6
    1d24:      	ldr	w2, [sp, #0x180]
    1d28:      	blr	x9
    1d2c:      	ldr	w8, [x24]
    1d30:      	cbz	w8, 0x16fc <kprobe_unwind_native+0x16fc>
    1d34:      	b	0x1630 <kprobe_unwind_native+0x1630>
    1d38:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1d3c:      	add	x10, x10, #0x0
    1d40:      	add	x0, sp, #0x140
    1d44:      	ldp	x8, x9, [x10, #0x10]
    1d48:      	mov	w1, #0x2e               // =46
    1d4c:      	stp	x8, x9, [sp, #0x150]
    1d50:      	ldr	x8, [x10, #0x20]
    1d54:      	add	x9, sp, #0x140
    1d58:      	str	x8, [sp, #0x160]
    1d5c:      	ldur	x8, [x10, #0x26]
    1d60:      	stur	x8, [x9, #0x26]
    1d64:      	ldp	x8, x9, [x10]
    1d68:      	add	x10, sp, #0x140
    1d6c:      	stp	x8, x9, [sp, #0x140]
    1d70:      	mov	w8, #0x2e               // =46
    1d74:      	mov	w9, #0x6                // =6
    1d78:      	ldr	w2, [sp, #0x180]
    1d7c:      	blr	x9
    1d80:      	b	0x17dc <kprobe_unwind_native+0x17dc>
    1d84:      	adrp	x8, 0x1000 <kprobe_unwind_native+0x1000>
    1d88:      	add	x8, x8, #0x0
    1d8c:      	add	x0, sp, #0x140
    1d90:      	ldp	x9, x10, [x8, #0x20]
    1d94:      	mov	w1, #0x3f               // =63
    1d98:      	stp	x9, x10, [sp, #0x160]
    1d9c:      	ldr	x9, [x8, #0x30]
    1da0:      	add	x10, sp, #0x140
    1da4:      	str	x9, [sp, #0x170]
    1da8:      	ldur	x9, [x8, #0x37]
    1dac:      	stur	x9, [x10, #0x37]
    1db0:      	ldp	x9, x10, [x8]
    1db4:      	stp	x9, x10, [sp, #0x140]
    1db8:      	add	x10, sp, #0x140
    1dbc:      	ldp	x9, x8, [x8, #0x10]
    1dc0:      	stp	x9, x8, [sp, #0x150]
    1dc4:      	mov	w8, #0x3f               // =63
    1dc8:      	mov	w9, #0x6                // =6
    1dcc:      	ldr	x2, [sp, #0x190]
    1dd0:      	ldrh	w3, [x29, #0x6]
    1dd4:      	blr	x9
    1dd8:      	b	0x17ec <kprobe_unwind_native+0x17ec>
    1ddc:      	adrp	x10, 0x1000 <kprobe_unwind_native+0x1000>
    1de0:      	add	x10, x10, #0x0
    1de4:      	add	x0, sp, #0x140
    1de8:      	ldp	x8, x9, [x10, #0x10]
    1dec:      	mov	w1, #0x2e               // =46
    1df0:      	stp	x8, x9, [sp, #0x150]
    1df4:      	ldr	x8, [x10, #0x20]
    1df8:      	add	x9, sp, #0x140
    1dfc:      	str	x8, [sp, #0x160]
    1e00:      	ldur	x8, [x10, #0x26]
    1e04:      	stur	x8, [x9, #0x26]
    1e08:      	ldp	x8, x9, [x10]
    1e0c:      	add	x10, sp, #0x140
    1e10:      	stp	x8, x9, [sp, #0x140]
    1e14:      	mov	w8, #0x2e               // =46
    1e18:      	mov	w9, #0x6                // =6
    1e1c:      	ldr	w2, [sp, #0x190]
    1e20:      	blr	x9
    1e24:      	ldr	w8, [x24]
    1e28:      	cbz	w8, 0x1808 <kprobe_unwind_native+0x1808>
    1e2c:      	b	0x178c <kprobe_unwind_native+0x178c>
